#!/usr/bin/env bash
# =====================================================================
# 效应能力流形 · W-LIFE-1a —— Coq 工具链安装（路线 A：发行版 deb，国内镜像，免 root）
# 已验证环境：Debian 13 (trixie) + coq 8.20.1（2026-11-07，清华 TUNA 镜像）
# 原理：用户态 apt（自定义状态目录指向国内镜像）下载 deb → dpkg-deb -x 解包到本地前缀
# =====================================================================
set -e

MIRROR=${MIRROR:-http://mirrors.tuna.tsinghua.edu.cn}   # 可换 https://mirrors.ustc.edu.cn
SUITE=${SUITE:-trixie}                                   # Debian 代号；Ubuntu 用户需改源行格式
ROOT=${ROOT:-$HOME/coq-cn}
APTROOT=$ROOT/aptroot

mkdir -p "$APTROOT/lists/partial" "$APTROOT/cache/archives/partial" "$APTROOT/etc"
cp /var/lib/dpkg/status "$APTROOT/status"
echo "deb [trusted=yes] $MIRROR/debian $SUITE main" > "$APTROOT/etc/sources.list"

APTOPT="-o Dir::Etc::sourcelist=$APTROOT/etc/sources.list \
 -o Dir::Etc::sourceparts=/dev/null \
 -o Dir::State=$APTROOT -o Dir::State::status=$APTROOT/status \
 -o Dir::Cache=$APTROOT/cache \
 -o APT::Get::List-Cleanup=0 -o Acquire::Check-Valid-Until=false"

echo "== 1/4 apt update（$MIRROR）=="
apt-get $APTOPT update

echo "== 2/4 下载 coq 及依赖（--no-install-recommends 避免 coqide/GTK 闭包）=="
apt-get $APTOPT -y --download-only --no-install-recommends install coq

echo "== 3/4 解包到 $ROOT/prefix =="
mkdir -p "$ROOT/prefix"
for d in "$APTROOT"/cache/archives/*.deb; do
  dpkg-deb -x "$d" "$ROOT/prefix"
done

# ocamlfind 配置文件内的绝对路径改为前缀路径
sed -i "s|/usr|$ROOT/prefix/usr|g" "$ROOT/prefix/etc/ocamlfind.conf"

echo "== 4/4 验证 =="
export LD_LIBRARY_PATH="$ROOT/prefix/usr/lib/x86_64-linux-gnu:$LD_LIBRARY_PATH"
export COQLIB="$ROOT/prefix/usr/lib/x86_64-linux-gnu/ocaml/5.3.0/coq"
export OCAMLFIND_CONF="$ROOT/prefix/etc/ocamlfind.conf"
export PATH="$ROOT/prefix/usr/bin:$PATH"
coqc --version

cat <<EOF

完成。请将以下环境变量写入 shell 配置：
  export LD_LIBRARY_PATH=$ROOT/prefix/usr/lib/x86_64-linux-gnu:\$LD_LIBRARY_PATH
  export COQLIB=$ROOT/prefix/usr/lib/x86_64-linux-gnu/ocaml/5.3.0/coq
  export OCAMLFIND_CONF=$ROOT/prefix/etc/ocamlfind.conf
  export PATH=$ROOT/prefix/usr/bin:\$PATH
EOF

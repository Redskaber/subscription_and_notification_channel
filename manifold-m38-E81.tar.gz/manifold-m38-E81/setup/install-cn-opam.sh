#!/usr/bin/env bash
# =====================================================================
# 效应能力流形 · W-LIFE-1a —— Coq/Rocq 工具链安装（路线 B：opam + 国内代理）
#
# 诚实探测记录（2026-11-07）：清华 TUNA / 中科大 USTC / 上海交大 SJTU 三家主镜像站
# 均未开设 opam 仓库镜像（/opam/ 路径 404）。故本路线采用
# 「opam 官方仓库 + 国内代理环境变量」满足“工具下载通过国内代理”。
# 若你的网络存在 opam 镜像（如校内镜像），将下方 OPAM_REPO 替换即可。
# =====================================================================
set -e

# ---- 0) 国内代理（按你的代理地址修改；无代理环境可注释）----
export http_proxy=${http_proxy:-http://127.0.0.1:7890}
export https_proxy=${https_proxy:-http://127.0.0.1:7890}
# OPAM_REPO=${OPAM_REPO:-}   # 如有镜像：https://your-mirror/opam/repo/default

# ---- 1) 安装 opam 本体 ----
if ! command -v opam >/dev/null 2>&1; then
  echo "opam 未安装。请先执行（Debian/Ubuntu，apt 源可先换国内镜像）："
  echo "  sudo apt-get install -y opam"
  echo "或从 GitHub Releases 下载二进制：https://github.com/ocaml/opam/releases"
  exit 1
fi

# ---- 2) 初始化（禁沙箱以兼容多数环境；有镜像则用镜像初始化）----
if [ -n "${OPAM_REPO:-}" ]; then
  opam init --disable-sandboxing -y -b "$OPAM_REPO"
else
  opam init --disable-sandboxing -y -b
fi
eval "$(opam env)"

# ---- 3) 编译器开关 ----
opam switch create manifold ocaml-base-compiler.4.14.2 -y
eval "$(opam env)"

# ---- 4) 安装 Coq（稳定路线）----
opam install -y coq.8.20.1
# 或 Rocq 9（新路线，包名已从 coq 改为 rocq-*）：
#   opam install -y rocq-core
#   rocq --version

# ---- 5) 验证 ----
coqc --version

echo "完成。构建本项目：cd coq && ./build.sh"

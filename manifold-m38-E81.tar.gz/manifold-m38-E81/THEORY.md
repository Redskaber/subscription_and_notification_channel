# 效应能力流形 · W-DPLL-1：DPLL(T) 增量面 + flow_total 一般化（诺特增量律的求解世界设计）

**轮次**：第 56 轮（累计编号 #292–#301） · **文献锚**：E.81（新增 E.81–E.85） · **阶段**：Stage 3 机械化 · E.76 轮后续（冲突学习/理论传播/回跳升格默认 + flow_total 一般化辅清偿）
**清偿对象**：**冲突学习/理论传播/回跳（DPLL(T) 增量面，Z3 血统）**——E.76 轮第九章挂账 (a)："当前 solve7 是朴素逐支循环"；辅清偿 **flow_total 一般化**（W-INEQ-2 挂账：集合划分恒等式 Σ_P |G|_(|块P|) = |G|^|R| 的上机）。本轮交付**诺特增量律**（对称—守恒在增量求解世界的细化）与 **flow_total 一般化**（总量守恒从四池实机上升为一般定理）。
**新增产物**：`DpllT.v`（DPLL(T) 增量面正交层：一跳锚提取 tylook/pair_labels/anchors/forced1/clash1 + 学习库 sub_dec/dpll_decisions/dpll_plan + Z3 层栈 dstate/dpush/dpop + solve8 循环；A 组锚域（anchor_local Qed）+ B 组学习单调（learn_subplan/learn_monotone Qed）+ C 组可靠性（dpll_witness/dpll_exhaust Qed）+ D 组诺特增量律（push_pop_restore Qed；learn_conserve_dead/clash_sound 陈述挂账）、`FlowTotal.v`（下降阶乘 falling + 划分恒等式 flow_total_arith_two/three（任意 g，Qed）+ **flow_total_two（|R|=2 一般定理，Qed——Ineq.noether_ineq_flow_total_two 挂账清偿）**+ parts2/parts3 划分表 + parts_flow 对齐）、`M38Example.v`（七组实机 + Print Assumptions ×62）
**8 原语**：恒定至第 56 轮（本轮零新增——DpllT/FlowTotal 均为纯解释层，tm/constr/ty 语法零改动，EBNF v9.17 挂账维持） · **Φ 守恒**：贯穿（φ 对安排全盲——solve8 沿用 solve4 通道纪律）
**翻案表**：+0（累计 27 维持——连续五轮 E.61/E.66/E.71/E.76/E.81 无翻案） · **零公理**：全链路 **385 项 "Closed under the global context"**（E.41 轮 39 + E.46 轮 24 + E.51 轮 40 + E.56 轮 56 + E.61 轮 26 + E.66 轮 41 + E.71 轮 46 + E.76 轮 51 + 本轮 62——对照 `log/build-log.txt`）。零公理纪律贯穿第十一个里程碑（…→ W-INEQ-1/W-SIB-1 → **W-DPLL-1/W-INEQ-2**）。

---

## 0. 本轮定位与清偿账目

**DPLL(T) 增量面**回答的问题：E.76 轮把"冲突学习/理论传播/回跳（DPLL(T) 增量面，Z3 血统）"登记为下轮默认开工位（"当前 solve7 是朴素逐支循环"）。本轮把它的**增量面**整体上机并交付诺特定律的求解世界设计：

> **诺特增量律（本轮的诺特定律设计——四定理组）**：
> **对源**（读数纪律）：一跳锚提取的迫值值域 ⊆ grounds——`anchor_local`（Qed）：forced1 r cs 的每个迫值都在地面池内（anchors 的标签经 pair_labels_mem/anchors_go_mem/clabels_allabels 全链 Qed 溯源到 allabels）。
> **流形**（计划守恒）：学习只删不增——`learn_subplan`（Qed）：dpll_plan ⊆ no_plan（filter 只删不增 + flat_map 单调）；决策死学习不减解的实机面：skJ 全差异支入学习库 ⇒ **dpll_plan = no_plan（8 = 8）**。
> **同调**（见证同步）：增量见证必经引擎验证且在原计划空间——`dpll_witness`（Qed，arr_loop_some_spec 实例化）；实机面：skT/skD/skJ 三池 **solve8 见证 = solve7 见证**（[(9,1);(10,0)] / [(9,1);(10,1);(11,1)]——学习剪的是死支，首个活安排不变）。
> **深度/增量栈**（路径与状态）：压弹对合——`push_pop_restore`（Qed）：dpop (dpush s) = s（Z3 式层栈的查询序列对称 ⇒ 状态守恒）；**传播下探**实机：skT 路径 **dpll 2 < 凸 3 < 朴素 4**（m38_path_descent）——一跳静态传播零引擎调用剪除等式支，路径下探到凸形态之下。

> **flow_total 一般化（辅交付，W-INEQ-2 清偿）**：集合划分恒等式的三层数学表示：
> **算术层**（任意 g，Qed）：falling g 1 + falling g 2 = g²（n=2：一块同值 g 支 + 两块互异 g(g-1) 支）；falling g 1 + 3·falling g 2 + falling g 3 = g³（n=3：Bell(3)=5 划分的核分类）。
> **定理层**（n=2 一般定理，Qed）：`flow_total_two`：|rvars|=2 ⇒ **|no_plan| = |G|²**——Ineq.noether_ineq_flow_total_two（E.76 轮 Admitted 挂账）的清偿：等式支 |G|（filter 恒真 + assigns_single）+ 差异支 |G|²-|G|（filter_map_push + 谓词桥 neq_ok_rho_spread + diag_count 对角线扣除 + filter_split_length 互补分裂）。
> **划分表**：parts2（Bell(2)=2）/ parts3（Bell(3)=5，块数序列 [1;2;2;2;3]）+ parts_flow 对齐（划分求和 = falling 求和，Qed）。n=3 定理形态陈述保留挂 **W-INEQ-3**（三变量决策级分解需传递一致性过滤的组合引理——skJ 型 5 一致决策枚举形态的一般化）。

**正面实验（一跳锚相克的传播实机）**：展示池 **skT**（手写四类型两相遇池）：
栈 [x : &₉α₂₁→α₂₁'; y : &₁α₂₂→α₂₂'; u : &₁₀α₃₁→α₃₁'; v : &₀α₃₁'→α₃₁'']，相遇方程 CTy (TVar 0) (TVar 1) 与 CTy (TVar 2) (TVar 3)：
- **锚 20**：TBorrow 9 (TVar 20) ≡ TBorrow 1 (TVar 20)（x 型定义域 ≡ y 型定义域）⇒ 迫值 **9↦1**
- **锚 31**：TBorrow 10 (TVar 31) ≡ TBorrow 0 (TVar 31)（u 型 ≡ v 型）⇒ 迫值 **10↦0**
- **锚相克**：forced1 9 = [1]、forced1 10 = [0]，无公共 ⇒ clash1 = true ⇒ 等式支 (9,10,=) **静态死**（同值 g 须 g=1 ∧ g=0 矛盾——零引擎调用）
- **路径账**：dpll_trials 2 < 凸 arrange_trials 3 < 朴素 no_trials 4——传播把 NO 形态的路径代价（E.76 轮的 4>3）不仅恢复而且**下探**（2<3：等式支 2 次死评估被静态传播消除，差异支 [(9,0);(10,1)] 死、[(9,1);(10,0)] 活）
- **健全性反例池 skU**：两类型含锚 20 的 (9,1) 对但**无相遇方程粘合** ⇒ anchors = []（不误提取）——一跳锚提取只在"相遇方程 + 类型表一层展开"的真实合一约束下配对，**不误杀活支**。

**增量面两级死性的实机**：
- **决策死**（no_branch = []）：skJ 全差异支（3 链 > |G|=2，互异不可满足）入学习库 LJ ⇒ dpll_plan skJ LJ = no_plan skJ（8=8 守恒）。
- **引擎死**（no_branch 非空但逐支 solve4 None）：skD 等式支（2 枚举全死——修复锚相克 9↦1 与 10↦0 的深层嵌套形态）入学习库 LD ⇒ 增量重解 dpll_trials = 2（vs 首解 4）——**学习成本一次、增量收益持续**（Z3 push/pop 场景的列表模拟）。
- skD 的锚是**多跳**的（9↦1 两跳、10↦0 三跳：相遇链 CTy (TVar 9) (TVar 3) → tyenv 展开 → 类型变量实例化传递）——一跳 anchors skD = []（如实登记，多跳锚提取挂 W-DPLL-2）。

### 清偿明细

| 欠条 | 状态 | 产物 |
| --- | --- | --- |
| **冲突学习/理论传播/回跳（DPLL(T) 增量面）**（本轮主清偿） | **已清偿（零公理·增量面）** | `DpllT.v`：§1 一跳传播（tylook 类型表 + pair_labels 同位对 + anchors_go 全表扫描 + forced1 迫值 + clash1 相克 + clash_learn 冲突学习面）+ §2 学习库（dec_in/sub_dec 决策包含 + dpll_decisions 过滤 + dpll_plan）+ §3 Z3 层栈（dstate/dpush/dpop/dlearn）+ §4 循环（dpll_trials/solve8 复用 arr_loop——循环体零改动）；A 组（flat_map_incl/dedupN_sound/grounds_member/pair_labels_mem/clabels_allabels/tylook_mem/anchors_go_mem/anchors_mem 全 Qed）+ B 组（learn_subplan/learn_monotone Qed）+ C 组（dpll_witness/dpll_exhaust Qed）+ D 组（anchor_local/push_pop_restore Qed；learn_conserve_dead/clash_sound 陈述挂账）；`M38Example.v` 实机 ×50 + 定理审计 ×12 |
| **flow_total 一般化**（W-INEQ-2 计数面，辅清偿） | **已清偿（n=2 一般定理 Qed）** | `FlowTotal.v`：falling 下降阶乘（nat 截断）+ flow_total_arith_two/three（任意 g，Qed）+ **flow_total_two（|R|=2 一般定理 Qed——Ineq 挂账清偿）**+ flow_total_three（陈述挂 W-INEQ-3）+ parts2/parts3 划分表 + parts2_flow/parts3_flow（Qed）+ flow_total_duality（Qed）；引理组：sub_2_pred/falling 形态/filter_pred_true/filter_two/esub_of_eq/esub_of_neq/neq_ok 两支/no_decisions_ok_two/free_vars 两支/assigns_two_length/spread_neq_form/neq_ok_rho_spread（谓词桥）全 Qed |
| **新登记**：多跳锚提取（skD 型深层嵌套锚的传递闭包——完整 τ 通道分析） | 后续轮（W-DPLL-2） | — |
| **新登记**：决策死学习不减解的一般定理（死支单调性——no_branch 的语义刻画） | 后续轮（W-DPLL-3） | — |
| **新登记**：flow_total 的 n=3 一般定理（三变量决策级分解计数） | 后续轮（W-INEQ-3） | — |
| efold 结构引理组（链头不变式的定理化——efold_coherence） | 照旧（同调面的传播幂等依赖它） | — |
| cgK 计数器的栈无关性（cgK_counter_irrel） | 照旧（W-SIB-2） | — |
| 多变量候选域优化（union-find 查找面）、solve6/7/8 失败传播、GAT φ 行化、gfp 下行迭代、W-LIFE-1b/1c、W-LIFE-2/3、W-INFERENCE-1/2、W-GRAMMAR-AUDIT、EBNF v9.17、K 谱系几何化 | 照旧 | — |

**编译验证**：Coq 8.20.1（Debian trixie deb，清华 TUNA 镜像，用户态前缀，免 root——沙箱回收后经 `setup/install-cn-deb.sh` 重装，过程入 `log/`）。**三十七模块**全部编译通过（1 分 24 秒）；`Print Assumptions` 全链路 **385 项 "Closed under the global context"**（含本轮 62 项）。零公理纪律贯穿第十一个里程碑。

---

## 十段式

### §1 重定义 —— DPLL(T) 增量面：从"朴素逐支循环"到"传播/学习/层栈"【#292】

**旧表述**（E.76 轮的登记形态）："solve7 朴素逐支循环"——no_plan 的决策组合全枚举 + 一致性事后过滤 + 逐支引擎评估；"冲突学习/理论传播/回跳"挂账直觉。

**重定义**为**增量面三件套**，全部正交落地（tm/constr/ty 语法零改动）：
1. **一跳理论传播**（§1）：类型表 tylook（只认"真类型定义"方程——第二侧非 TVar）+ 相遇方程 CTy (TVar a) (TVar b) 两侧各查一层 + pair_labels 同位 TBorrow 对提取 ⇒ 迫值锚 forced1（snd 为地面者）⇒ 锚相克 clash1（迫值集非空且无公共）⇒ clash_learn（等式支决策入学习库——**静态零引擎调用**）。健全性边界：只提取"真实合一约束"可迫值的锚——无粘合方程的池（skU）不提取；深层嵌套的多跳锚（skD）不提取（如实登记，挂 W-DPLL-2）。
2. **冲突学习**（§2）：学习库 learnlib = 死决策组合表；dec_in/sub_dec 决策包含（同对同极性）；dpll_decisions 过滤（剪除包含死决策的支）；dpll_plan = flat_map no_branch 过滤后决策。两级死性：**决策死**（no_branch = []——skJ 全差异支）与**引擎死**（no_branch 非空但逐支 solve4 None——skD 等式支）。
3. **回跳/增量栈**（§3）：Z3 式层栈 dstate（当前学习库 + push 快照栈）；dpush/dpop/dlearn；**压弹对合** push_pop_restore（Qed）——查询序列对称 ⇒ 状态守恒（层内学习只增不减 learn_monotone Qed；弹栈回快照——增量复用的语义基座）。

### §2 重定性 —— 增量面是什么与不是什么【#293】

**是**：决策空间的**重组器**——传播/学习/层栈都只改变"按什么顺序访问哪些计划"（dpll_plan ⊆ no_plan，learn_subplan Qed），不改变计划空间本身（决策死学习下计划集不变，skJ 8=8；引擎死学习下计划集缩减的恰是引擎死支——见证不变，skT/skD/skJ 三池 solve8 见证 = solve7 见证）。**不是**：新求解器——arr_loop 循环体零改动（计划源替换：arrange_plan → no_plan → dpll_plan，同一引擎通道 solve4）。

路径的定性变化：E.76 轮 NO 形态的路径代价（skD 4 > 凸 3）在本轮被**双向改写**——一跳传播把它**下探**（skT：dpll 2 < 凸 3 < 朴素 4），引擎死学习把它**增量摊销**（skD：首解 4 → 带库重解 2）。守恒量不变（|计划| = |G|^|R|，flow_total_two Qed）——**对称性（访问方式自由）对应守恒量（解空间总量），对称破缺（死支确证）释放的是路径自由度**。

### §3 重定能力 —— 引擎通道的三个不变式【#294】

1. **通道复用**：solve8 = arr_loop fuel cs (dpll_plan cs L) 0 的 snd——与 solve4→solve6→solve7→solve8 四代同型（计划源替换，引擎零改动——第五次连续验证"解释层扩展比语法手术稳定"）。
2. **见证可靠性**：dpll_witness（Qed）——solve8 的任何见证都在 dpll_plan 中且经 solve4 验证（arr_loop_some_spec 实例化）；穷尽对偶 dpll_exhaust（Qed）。
3. **锚溯源全链**：pair_labels_mem（析取形式——结构归纳友好）→ anchors_go_mem（双参数归纳——全表参数不失全局）→ anchors_mem → anchor_local（Qed）：迫值锚的每个值都在 grounds 内（读数不出池）。

### §4 重定边界 —— 一跳/多跳与决策死/引擎死【#295】

如实登记的能力边界：
1. **一跳锚提取**：只在"相遇方程 + 类型表一层展开"内配对（TBorrow-TBorrow 同位对）。skT 型（两层结构）一跳可达；skD 型（深层嵌套——9↦1 需相遇链 + 类型变量实例化两跳、10↦0 需三跳）不可达（anchors skD = []）。多跳锚提取挂 **W-DPLL-2**（完整 τ 通道分析——solve4 合一器的通道面拆解）。
2. **两级死性**：决策死可静态判定（no_branch = [] 的计算——skJ 全差异支）；引擎死需引擎确证（solve4 逐支 None——skD 等式支，学习成本内含）。**静态传播的收益上限**是等式支的引擎评估次数（skT：2 → 0）。
3. **flow_total 的 n=2/n=3 分界**：n=2 一般定理 Qed（决策分解 = 等式支 + 差异支的二元结构）；n=3 需要传递一致性过滤的组合引理（5 一致决策的枚举形态一般化）——陈述挂 **W-INEQ-3**。

### §5 重定职责 —— 三文件职责表【#296】

| 文件 | 职责 | 不做什么 |
| --- | --- | --- |
| `DpllT.v` | 一跳传播 + 学习库 + 层栈 + solve8 循环 + 诺特增量律四定理组 | 不改 Ineq 的决策机器（no_decisions_ok/no_branch 复用）；不做多跳锚（W-DPLL-2） |
| `FlowTotal.v` | 下降阶乘 + 划分恒等式 + flow_total_two 一般定理 + 划分表 | 不改 no_plan（计数面外部观察）；n=3 陈述挂 W-INEQ-3 |
| `M38Example.v` | skT/skU 新池 + 七组实机 + Print Assumptions ×62 | 不重演 M37 六池（仅复用 skI/skD/skJ/skS 做对齐） |

### §6 重定关联 —— 诺特定律谱系的增量面位置【#297】

1. **对 E.61 诺特三定律**：诺特增量律是第三定律（荷—流对偶）在**求解路径维**的细化——荷（区域变量）的安排流（计划枚举）在新对称面（访问方式：传播/学习/层栈）下产生新守恒量（计划集不变 + 见证同步 + 状态还原）。
2. **对 E.76 诺特不等式律**：总量守恒（|NO 计划| = |G|^|R|）从四池实机（1/4/8/2）上升为一般定理（flow_total_two Qed）；路径不守恒（NO 4 > 凸 3）的自由度在本轮被增量面收编（传播下探 2<3、学习摊销 4→2）——**流形守恒不变，路径成为新的对称面**。
3. **对 E.71 诺特栈律**：Z3 层栈（dstate）与嵌套签名栈（cgK/cgKX）同属"栈式快照还原"的守恒形态——压弹对合是两者的共同代数结构。
4. **对 E.49/E.77/E.81/E.82/E.85（DPLL(T)/Z3 血统）**：一跳锚提取是 Nelson–Oppen equality propagation 的**静态切片**（E.46/E.49——理论间等式传播只取"结构同位 TBorrow"面）；clash1 的锚相克判定是 DPLL(T) 理论传播的**免决策面**（E.82——Theory Propagate 规则的列表模拟）；学习库的决策包含过滤是冲突子句学习（E.81 GRASP）的**决策级抽象**（子句 = 决策组合；UIP 的学习子句对应死支的最小决策核——最小性挂 W-DPLL-3）；层栈是 Z3 push/pop（E.77）的语义基座（压弹对合）。
5. **对 E.83（Atkey POPL 2014）**：参数性到守恒律的诺特迁移与本项目的"每约束答守恒量"纪律互为印证——Atkey 用关系参数性（Reynolds 抽象定理）推导程序的不变量；本项目用审计纪律（每设计决策答守恒量 + 零公理机检）承载同一思想。**迁移方式的差异**：Atkey 在语义模型层（逻辑关系）；本项目在求解器工程层（决策机器 + 引擎通道）。
6. **对 E.84（Concrete Mathematics）**：falling/划分恒等式是 Stirling 组合的标准面（第二类 Stirling 数 S(n,k) 与下降阶乘的容斥关系：xⁿ = Σ_k S(n,k)·(x)_k——flow_total 是其在"赋值按核划分分类"上的实例）。

### §7 重定形式 —— 关键 Coq 签名一览【#298】

```coq
(* DpllT.v *)
Definition tylook (a : nat) (cs : list constr) : option ty       (* 真类型定义表 *)
Fixpoint pair_labels (t1 t2 : ty) : list (nat * nat)             (* 同位 TBorrow 对 *)
Fixpoint anchors_go (full cs : list constr) : list (nat * nat)   (* 全表锚扫描 *)
Definition forced1 (r : nat) (cs : list constr) : list nat       (* 迫值锚（地面） *)
Definition clash1 (cs : list constr) (x y : nat) : bool          (* 锚相克 *)
Definition clash_learn (cs) (x y) : list (list dec)              (* 传播 → 学习库 *)
Definition sub_dec (l d : list dec) : bool                       (* 决策包含 *)
Definition dpll_decisions (rvs) (L : learnlib) : list (list dec) (* 学习过滤 *)
Definition dpll_plan (cs) (L : learnlib) : list rsubst           (* 增量计划 *)
Record dstate := mkDstate { dL : learnlib; dstack : list learnlib }
Definition dpush / dpop / dlearn                                  (* Z3 层栈 *)
Definition dpll_trials / solve8                                   (* 组合循环（arr_loop 复用）*)
Theorem anchor_local : In g (forced1 r cs) -> In g (grounds cs)          (* Qed *)
Theorem learn_subplan : incl (dpll_plan cs L) (no_plan cs)               (* Qed *)
Theorem dpll_witness : solve8 fuel cs L = Some (s,l,rho) -> In rho (dpll_plan cs L) /\ ...  (* Qed *)
Theorem push_pop_restore : forall s, dpop (dpush s) = s                  (* Qed *)
Theorem learn_conserve_dead / clash_sound                                (* 陈述挂账 *)

(* FlowTotal.v *)
Fixpoint falling (g k : nat) : nat                               (* 下降阶乘（nat 截断） *)
Theorem flow_total_arith_two : falling g 1 + falling g 2 = g * g                 (* Qed *)
Theorem flow_total_arith_three : falling g 1 + 3*falling g 2 + falling g 3 = g^3 (* Qed *)
Theorem flow_total_two : length (rvars cs) = 2 ->
  length (no_plan cs) = (length (grounds cs)) ^ 2                (* Qed——Ineq 挂账清偿 *)
Definition parts2 / parts3                                       (* 划分表 Bell(2)/Bell(3) *)
Theorem flow_total_three : length (rvars cs) = 3 -> ...          (* 陈述挂 W-INEQ-3 *)
```

### §8 重数学表示 —— 上机实录的教训【#299】

1. **tylook 的"真类型定义"过滤**。初版 tylook 接受任意 CTy (TVar a) _ 方程——TVar-TVar 相遇方程被误认为类型定义（tylook 0 [相遇型池] 返回 Some (TVar 1)——相遇方程自身的"型"）。修正：谓词排除第二侧为 TVar 的方程（CTy (TVar x) (TVar _) => false）。教训：**类型表必须区分"定义方程"与"相遇方程"**——Nelson–Oppen 的 purification 步骤（分离两理论项）在锚提取面的投影。
2. **anchors 的全表参数**。初版 anchors 递归下降时 tylook 只见**尾部子列表**（类型定义方程在列表头部被丢失）——anchors skT = [] 静默失败。修正：anchors_go full cs 双参数（全表参数 full 固定递归）。教训：**全局信息依赖的递归扫描必须显式携带全量上下文**（E.76 轮"签名变量越窗"教训的扫描面再现）。
3. **flat_map 展开的 ++ [] 尾巴**。flow_total_two 的 cbn [flat_map] 把 flat_map F [a;b] 展开为 F a ++ (F b ++ [])——差异支的项带 ++ [] 尾巴，与 assert 的陈述形态不匹配（rewrite Hneq_len 失败）。修正：rewrite length_app 后补 rewrite app_nil_r。教训：**cbn 的 flat_map 展开保留递归基的 app 空表**——assert 陈述必须与化简后的实际形态逐字对齐。
4. **lia 不懂布尔等式**。esb_of_eq 的初版用 `apply Nat.eqb_neq in Hxy` 后在 (y =? x) 分支用 lia 推矛盾——lia 把 (x =? y) = false 当原子，推不出 x≠y ∧ y=x 的矛盾。修正：分支内 `apply Nat.eqb_eq in E; exfalso; apply Hxy; symmetry; exact E`。教训：**布尔与命题的转换（Nat.eqb_eq/neq）必须显式完成后才能交给算术决策过程**。

### §9 重翻案 —— 上机是唯一裁判【#300】

**翻案**：**无**（+0，累计 27 维持）。连续五轮（E.61/E.66/E.71/E.76/E.81）无翻案。判词沿用：上机是唯一裁判；本轮是"正交层血统"（cgS→rvarb→cgK→no_plan→**dpll_plan**）的第五次连续验证——**解释层扩展比语法手术稳定**（五次零重编译）。本轮探针期修正（tylook 真型过滤、anchors 全表参数、flat_map 尾巴、lia 布尔转换）均为**断言与实录的对齐**，非设计翻案——设计的预言（传播下探 2<3<4、学习守恒 8=8、见证同步、flow_total 一般化）全部一次上机兑现。

### §10 文献锚 E.81–E.85【#301】

1. **E.81: Marques-Silva, J. P. & Sakallah, K. A. (1996). "GRASP—A New Search Algorithm for Satisfiability." In *Proceedings of ICCAD '96*, pp. 220–227. IEEE.** ——冲突驱动学习与非时序回跳的原典：冲突子句学习（conflict clause learning）与回跳（backjumping）的首次系统化；本切片的学习库（决策包含过滤）与"死支整支剪除"是其决策级抽象。（已核证：ICCAD'96 pp. 220–227——ACM DL 条目与 ePrints Soton 引用一致。）
2. **E.82: Ganzinger, H., Hagen, G., Nieuwenhuis, R., Oliveras, A. & Tinelli, C. (2004). "DPLL(T): Fast Decision Procedures." In *CAV 2004*, LNCS 3114, pp. 175–188. Springer.** ——DPLL(T) 架构原典：理论传播（Theory Propagate）作为免决策规则的系统化；clash1 的静态锚相克判定是其列表模拟（传播先于决策——等式支免枚举）。（已核证：CAV 2004 LNCS 3114——Springer 链接 978-3-540-27813-9_14 存在。）
3. **E.83: Atkey, R. (2014). "From Parametricity to Conservation Laws, via Noether's Theorem." In *POPL 2014*, pp. 491–502. ACM.** ——诺特定律向程序语言迁移的直接文献：用 Reynolds 关系参数性（抽象定理）推导多态程序的不变量（守恒律）——对称性（参数性关系）对应守恒量（不变量）；与本项目"每约束答守恒量"的审计纪律互为印证（语义模型层 vs 求解器工程层的两种迁移路线）。（已核证：POPL 2014 pp. 491–502——Strathprints 与多源一致。）
4. **E.84: Graham, R. L., Knuth, D. E. & Patashnik, O. (1994). *Concrete Mathematics: A Foundation for Computer Science*, 2nd ed. Addison-Wesley.** ——下降阶乘/第二类 Stirling 数/划分恒等式的组合标准参考：flow_total 的算术层（xⁿ = Σ_k S(n,k)·(x)_k 的"赋值按核划分分类"实例）与其 Bell 数计数面（Bell(2)=2 / Bell(3)=5 的 parts2/parts3 划分表）。（已核证：2nd ed. 1994 Addison-Wesley（Reading, MA）——版权页与多源一致。）
5. **E.85: Barrett, C., Sebastiani, R., Seshia, S. A. & Tinelli, C. (2009). "Satisfiability Modulo Theories." In *Handbook of Satisfiability*, Frontiers in Artificial Intelligence and Applications 185, Chapter 26, pp. 825–885. IOS Press.** ——DPLL(T) 增量面的系统综述：T-DPLL 的学习/传播/回跳规则组与 Nelson–Oppen 组合的接口；本轮 solve8 的增量语义（dpll_plan 的学习复用）与层栈（push/pop）的工程面血统。（已核证：FAIA 185, ch. 26, pp. 825–885, IOS Press 2009——Stanford bibtex2web 与多源一致。）

**工业同族**：**GRASP**（E.81）——冲突学习的原典（决策级抽象的学习库）；**DPLL(T)**（E.82）——理论传播的系统化（clash1 的免决策面）；**Z3**（E.77，沿用）——增量求解的工业实现（层栈 dstate 的血统）；**Atkey**（E.83）——诺特迁移的语义路线（与本项目的工程路线互补）；**GKP**（E.84）——划分计数的组合面（flow_total 的 Stirling 形态）；**BSST**（E.85）——SMT 增量面的综述（T-DPLL 规则组）。

---

## 挂账与下轮

**下轮默认开工位**：**多跳锚提取**（W-DPLL-2——skD 型深层嵌套锚的传递闭包：完整 τ 通道分析，solve4 合一器的通道面拆解）或 **flow_total n=3 一般定理**（W-INEQ-3——三变量决策级分解的组合引理）；用户点名的任何挂账轮优先。既有挂账照旧：efold 结构引理组（efold_coherence）、cgK 计数器栈无关性（W-SIB-2）、决策死学习的一般单调性（W-DPLL-3）。

**本轮产物清单**：`coq/DpllT.v`（281 行）、`coq/FlowTotal.v`（360 行）、`coq/M38Example.v`（295 行）、`coq/build.sh`（三十七模块）、`THEORY.md`（本文档）、`log/build-log.txt`（全链路编译 + 385 项零公理审计）、设计论证文档（docx，另附）。打包为 `manifold-m38-E81.tar.gz`（本轮）与 `manifold-all-E81.tar.gz`（累计）。

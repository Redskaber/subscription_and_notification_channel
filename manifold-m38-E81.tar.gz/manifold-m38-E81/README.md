# 效应能力流形 · W-DPLL-1：DPLL(T) 增量面 + flow_total 一般化

第 56 轮（#292–#301）· 文献锚 E.81（新增 E.81–E.85）· Coq 8.20.1 · 零公理（385 项 Closed）

## 本轮交付
- **诺特增量律**（N3 在增量求解世界的细化）：对源（锚域守恒 anchor_local Qed）/ 流形（计划守恒 learn_subplan Qed）/ 同调（见证同步 dpll_witness Qed + 三池实机）/ 深度（压弹对合 push_pop_restore Qed + 传播下探 2<3<4）
- **DPLL(T) 增量面三件套**：`DpllT.v`——一跳理论传播（tylook 类型表 + pair_labels 同位对 + forced1 迫值锚 + clash1 锚相克——等式支静态剪除，零引擎调用）、冲突学习（学习库 sub_dec/dpll_plan——决策死/引擎死两级）、Z3 式层栈（dstate/dpush/dpop——压弹对合）；solve8（arr_loop 换源零改动，第五代计划源）
- **flow_total 一般化**（W-INEQ-2 清偿）：`FlowTotal.v`——下降阶乘 falling（nat 截断）+ 划分恒等式（n=2/n=3 任意 g，Qed）+ **flow_total_two 一般定理（Qed——Ineq.noether_ineq_flow_total_two 挂账清偿）** + parts2/parts3 划分表（Bell(2)=2 / Bell(3)=5）
- **七组实机**：`M38Example.v`——skT（一跳锚相克传播池：dpll 2 < 凸 3 < 朴素 4 路径下探）/ skU（无粘合反例池——静态提取健全性）/ skJ 决策死学习（8=8 守恒）/ skD 引擎死学习（首解 4 → 带库重解 2 增量收益）/ 三池见证同步 / 五池 flow_total 对齐 / 层栈实机——Print Assumptions ×62

## 构建
```
bash setup/install-cn-deb.sh    # 国内镜像安装 Coq 8.20.1（免 root）
cd coq && bash build.sh         # 三十七模块，Print Assumptions 全 Closed（385 项）
```

## 结构
- `coq/DpllT.v` `coq/FlowTotal.v` `coq/M38Example.v`（新增三模块）
- `coq/`（E.39–E.76 三十四模块原样携带）
- `THEORY.md`（十段式 + 诺特增量律审计 + 实例推演）
- `log/build-log.txt`（构建与零公理审计实录）
- `setup/`（国内镜像安装脚本）

(* ===================================================================== *)
(*  效应能力流形 · W-TYPEX-3 · Rvar：区域变量化 + 诺特 N3 正面实验          *)
(*                                                                         *)
(*  第 49 轮（#262–#271）· 文献锚 E.66（新增 E.66–E.70）                    *)
(*  清偿对象：W-TYPEX-3（区域变量化——E.56 §4.1 双到期面收窄后的唯一        *)
(*  触发器；E.61 轮定理面（noether_N3_rigid_conditional）已有，实机未做）。  *)
(*                                                                         *)
(*  扩展形态（正交层——tm/constr 语法零改动，8 原语恒定第 49 轮）：           *)
(*    标签空间切分：TBorrow/CXr/CRg/CHr 的区域标签 r ∈ nat                  *)
(*      r ≥ RV_BASE(=8) —— 区域变量 ρ（可安排：rinst 实例化改写）           *)
(*      r <  RV_BASE     —— 地面区域（刚性：tau_rigid 面）                  *)
(*    ——纯解释层约定（与 cgS（E.61）、xapply（E.46）同宗的零语法手术）。     *)
(*                                                                         *)
(*  四个定义组：                                                            *)
(*    §1 命名空间   rvarb / tlabels / clabels / rvars / grounds             *)
(*    §2 实例化     rsubst / rlook / rinst1 / rinstC / rinstP               *)
(*    §3 安排枚举   assigns（候选=地面标签，按出现序）/ arrange_plan         *)
(*    §4 安排循环   arr_loop（诺特流计数 acc）/ solve6 / arrange_trials      *)
(*                                                                         *)
(*  定理组（诺特 N3 的流侧补全——"荷在 ⇒ 流零；荷破 ⇒ 流出现"）：            *)
(*    A 键域纪律   rinstP_ground_fix 等（安排只动变量键）                    *)
(*    B 枚举形态   assigns_nil_rvs / assigns_single / assigns_length /      *)
(*                 assigns_domain                                          *)
(*    C 循环可靠性 solve6_witness（见证必经引擎验证）/ solve6_exhaust        *)
(*    D 诺特流侧   noether_N3_flow_zero（荷在 ⇒ 流零——恒等一支）/           *)
(*                 noether_N3_flow_nonidentity（荷破 ⇒ 流皆非恒等）/        *)
(*                 solve6_identity_bridge（恒等命中 ⇒ 引擎单遍已足）/       *)
(*                 noether_N3_flow_duality（对偶整合）                      *)
(*    正面实机（poolV 三态梯度：poolA 流零 / poolB 流一 / poolV 流二        *)
(*    一死一活——DPLL(T) case-split 回归）见 M35Example.v。                   *)
(* ===================================================================== *)

Require Import List Lia PeanoNat Bool.
Import ListNotations.
Require Import Mult Cap Syntax CG Tau TyCG Lphi Fusion Mu Xsub M3Fusion
               Rsat Hsat Solve3 Xcone Drop2 Gphi Solve4.

Local Open Scope bool_scope.

(* ================= 一、命名空间：标签空间切分 ================= *)

(* 区域变量基：标签 ≥ 8 为区域变量 ρ；< 8 为地面区域。
   纯解释层约定——ty/constr/tm 语法零改动（8 原语恒定，EBNF v9.17 挂账维持）。 *)
Definition RV_BASE : nat := 8.
Definition rvarb (r : nat) : bool := RV_BASE <=? r.

(* 类型上的区域标签采集（含 TBorrow 标签与递归两侧） *)
Fixpoint tlabels (t : ty) : list nat :=
  match t with
  | TVar _ => []
  | TArrow a b => tlabels a ++ tlabels b
  | TBorrow r t' => r :: tlabels t'
  end.

(* 约束上的区域标签采集（τ 两型侧；R 两侧；H 只取区域侧——租约 l 属
   租约命名空间，不是区域标签；X 的点名区 + 型侧；φ 无区域标签） *)
Definition clabels (c : constr) : list nat :=
  match c with
  | CTy a b => tlabels a ++ tlabels b
  | CRg r1 r2 => [r1; r2]
  | CLv _ _ => []
  | CPr _ _ _ => []
  | CHr l r => [r]
  | CEnd _ => []
  | CXr r t => r :: tlabels t
  end.

Definition allabels (cs : list constr) : list nat :=
  concat (map clabels cs).

(* 首现序去重 *)
Fixpoint dedupN (l : list nat) : list nat :=
  match l with
  | [] => []
  | a :: l' =>
      if existsb (fun b => a =? b) (dedupN l') then dedupN l' else a :: dedupN l'
  end.

(* 池的区域变量组（出现序）与地面候选组（出现序） *)
Definition rvars (cs : list constr) : list nat :=
  filter rvarb (dedupN (allabels cs)).
Definition grounds (cs : list constr) : list nat :=
  filter (fun r => negb (rvarb r)) (dedupN (allabels cs)).

(* ================= 二、实例化：区域代换 ================= *)

Definition rsubst := list (nat * nat).

(* 键查找：缺省 = 键自身（未安排的标签保持原值） *)
Definition rlook (rho : rsubst) (r : nat) : nat :=
  match find (fun p => (fst p) =? r) rho with
  | Some p => snd p
  | None => r
  end.

Fixpoint rinst1 (rho : rsubst) (t : ty) : ty :=
  match t with
  | TVar x => TVar x
  | TArrow a b => TArrow (rinst1 rho a) (rinst1 rho b)
  | TBorrow r t' => TBorrow (rlook rho r) (rinst1 rho t')
  end.

Definition rinstC (rho : rsubst) (c : constr) : constr :=
  match c with
  | CTy a b => CTy (rinst1 rho a) (rinst1 rho b)
  | CRg r1 r2 => CRg (rlook rho r1) (rlook rho r2)
  | CLv c k => CLv c k
  | CPr c c' w => CPr c c' w
  | CHr l r => CHr l (rlook rho r)
  | CEnd l => CEnd l
  | CXr r t => CXr (rlook rho r) (rinst1 rho t)
  end.

Definition rinstP (rho : rsubst) (cs : list constr) : list constr :=
  map (rinstC rho) cs.

(* ================= 三、安排枚举 ================= *)

(* 全函数枚举：rvs 的每个变量在 cands 中各取一值。
   单变量序：map 保候选出现序（死支在前的设计依赖）。 *)
Fixpoint assigns (cands rvs : list nat) : list rsubst :=
  match rvs with
  | [] => [[]]
  | r :: rvs' =>
      flat_map (fun rest => map (fun c => (r, c) :: rest) cands)
               (assigns cands rvs')
  end.

Definition arrange_plan (cs : list constr) : list rsubst :=
  assigns (grounds cs) (rvars cs).

(* ================= 四、安排循环（诺特流的计数形态） ================= *)

(* 逐安排调用引擎（solve4——快道 ⊕ 锥上升）；acc 计已评估分支数。
   命中返回 (S acc, 见证含安排)；穷尽返回 (总评估数, None)。 *)
Fixpoint arr_loop (fuel : nat) (cs : list constr) (rhos : list rsubst) (acc : nat)
  : nat * option (tsubst * cmap * rsubst) :=
  match rhos with
  | [] => (acc, None)
  | rho :: rhos' =>
      match solve4 fuel (rinstP rho cs) with
      | Some (s, l) => (S acc, Some (s, l, rho))
      | None => arr_loop fuel cs rhos' (S acc)
      end
  end.

Definition arrange_trials (fuel : nat) (cs : list constr) : nat :=
  fst (arr_loop fuel cs (arrange_plan cs) 0).

Definition solve6 (fuel : nat) (cs : list constr) : option (tsubst * cmap * rsubst) :=
  snd (arr_loop fuel cs (arrange_plan cs) 0).

(* ================= 五、A 组：键域纪律 ================= *)
(* 安排只动变量键——地面标签对任何只含变量键的 rinst 不动。 *)

Lemma rlook_nil : forall r, rlook [] r = r.
Proof. intros r. reflexivity. Qed.

Lemma rinst1_nil : forall t, rinst1 [] t = t.
Proof.
  induction t as [x | a IHa b IHb | r t' IHt]; simpl.
  - reflexivity.
  - rewrite IHa, IHb. reflexivity.
  - rewrite rlook_nil, IHt. reflexivity.
Qed.

Lemma rinstC_nil : forall c, rinstC [] c = c.
Proof.
  destruct c as [a b | r1 r2 | c k | c c' w | l r | l | r t]; simpl.
  - rewrite rinst1_nil, rinst1_nil. reflexivity.
  - reflexivity.
  - reflexivity.
  - reflexivity.
  - reflexivity.
  - reflexivity.
  - rewrite rlook_nil, rinst1_nil. reflexivity.
Qed.

Lemma rinstP_nil : forall cs, rinstP [] cs = cs.
Proof.
  induction cs as [|c cs IH]; simpl; [reflexivity|].
  rewrite rinstC_nil, IH. reflexivity.
Qed.

(* 去重保成员 *)
Lemma dedupN_In : forall l x, In x l -> In x (dedupN l).
Proof.
  induction l as [|a l IH]; intros x Hin; simpl in *; [contradiction|].
  destruct (existsb (fun b => a =? b) (dedupN l)) eqn:E.
  - (* a 被丢弃 ⇒ x = a 时由 existsb 提供的重现 *)
    destruct Hin as [Heq | Hin].
    + subst x. apply existsb_exists in E. destruct E as [b [Hb Hab]].
      simpl in Hab. apply Nat.eqb_eq in Hab. subst b. exact Hb.
    + apply IH. exact Hin.
  - (* a 保留 *)
    destruct Hin as [Heq | Hin]; [left; exact Heq | right; apply IH; exact Hin].
Qed.

(* 荷在 ⇒ 池中标签全部地面 *)
Lemma rvars_nil_ground : forall cs,
  rvars cs = [] -> forall x, In x (allabels cs) -> x < RV_BASE.
Proof.
  intros cs H x Hin.
  assert (HinD : In x (dedupN (allabels cs))) by (apply dedupN_In; exact Hin).
  unfold rvars in H.
  destruct (rvarb x) eqn:Ex.
  - exfalso.
    assert (Hfx : In x (filter rvarb (dedupN (allabels cs)))).
    { apply filter_In. split; [exact HinD | rewrite Ex; reflexivity]. }
    rewrite H in Hfx. destruct Hfx.
  - unfold rvarb in Ex. apply Nat.leb_gt in Ex. exact Ex.
Qed.

(* 变量键域下的地面不动 *)
Lemma rlook_ground_key : forall rho x,
  (forall k v, In (k, v) rho -> RV_BASE <= k) ->
  x < RV_BASE -> rlook rho x = x.
Proof.
  intros rho x Hkeys Hx. unfold rlook.
  destruct (find (fun p => (fst p) =? x) rho) as [p |] eqn:Ef.
  - apply find_some in Ef. destruct Ef as [Hp Hb].
    destruct p as [k v]. simpl in Hb. apply Nat.eqb_eq in Hb.
    exfalso. specialize (Hkeys k v Hp). lia.
  - reflexivity.
Qed.

Lemma rinst1_ground : forall rho t,
  (forall k v, In (k, v) rho -> RV_BASE <= k) ->
  (forall x, In x (tlabels t) -> x < RV_BASE) ->
  rinst1 rho t = t.
Proof.
  intros rho t Hkeys. induction t as [x | a IHa b IHb | r t' IHt]; intros Hg.
  - reflexivity.
  - (* TArrow *) simpl.
    assert (Ha : forall y, In y (tlabels a) -> y < RV_BASE)
      by (intros y Hy; apply Hg; simpl; apply in_or_app; left; exact Hy).
    assert (Hb : forall y, In y (tlabels b) -> y < RV_BASE)
      by (intros y Hy; apply Hg; simpl; apply in_or_app; right; exact Hy).
    rewrite (IHa Ha), (IHb Hb). reflexivity.
  - (* TBorrow *) simpl.
    assert (Hr : r < RV_BASE) by (apply Hg; simpl; auto).
    assert (Ht : forall y, In y (tlabels t') -> y < RV_BASE)
      by (intros y Hy; apply Hg; simpl; right; exact Hy).
    rewrite (rlook_ground_key rho r Hkeys Hr), (IHt Ht). reflexivity.
Qed.

Lemma rinstC_ground : forall rho c,
  (forall k v, In (k, v) rho -> RV_BASE <= k) ->
  (forall x, In x (clabels c) -> x < RV_BASE) ->
  rinstC rho c = c.
Proof.
  intros rho c Hkeys Hg.
  destruct c as [a b | r1 r2 | c k | c c' w | l r | l | r t].
  - (* CTy *) simpl.
    assert (Ha : forall y, In y (tlabels a) -> y < RV_BASE)
      by (intros y Hy; apply Hg; simpl; apply in_or_app; left; exact Hy).
    assert (Hb : forall y, In y (tlabels b) -> y < RV_BASE)
      by (intros y Hy; apply Hg; simpl; apply in_or_app; right; exact Hy).
    rewrite (rinst1_ground rho a Hkeys Ha), (rinst1_ground rho b Hkeys Hb).
    reflexivity.
  - (* CRg *) simpl.
    assert (H1 : r1 < RV_BASE) by (apply Hg; simpl; auto).
    assert (H2 : r2 < RV_BASE) by (apply Hg; simpl; auto).
    rewrite (rlook_ground_key rho r1 Hkeys H1), (rlook_ground_key rho r2 Hkeys H2).
    reflexivity.
  - reflexivity.
  - reflexivity.
  - (* CHr *) simpl.
    assert (Hr : r < RV_BASE) by (apply Hg; simpl; auto).
    rewrite (rlook_ground_key rho r Hkeys Hr). reflexivity.
  - reflexivity.
  - (* CXr *) simpl.
    assert (Hr : r < RV_BASE) by (apply Hg; simpl; auto).
    assert (Ht : forall y, In y (tlabels t) -> y < RV_BASE)
      by (intros y Hy; apply Hg; simpl; right; exact Hy).
    rewrite (rlook_ground_key rho r Hkeys Hr), (rinst1_ground rho t Hkeys Ht).
    reflexivity.
Qed.

(* 全标签地面 ⇒ 实例化恒等（主定理的强形态——归纳友好） *)
Lemma rinstP_allground : forall rho cs,
  (forall k v, In (k, v) rho -> RV_BASE <= k) ->
  (forall x, In x (allabels cs) -> x < RV_BASE) ->
  rinstP rho cs = cs.
Proof.
  intros rho cs Hkeys. induction cs as [|c cs IH]; intros Hg; [reflexivity|].
  simpl in Hg |- *.
  assert (Hc : forall x, In x (clabels c) -> x < RV_BASE)
    by (intros x Hx; apply Hg; apply in_or_app; left; exact Hx).
  assert (Hcs : forall x, In x (allabels cs) -> x < RV_BASE)
    by (intros x Hx; apply Hg; apply in_or_app; right; exact Hx).
  rewrite (rinstC_ground rho c Hkeys Hc), (IH Hcs). reflexivity.
Qed.

(* 键域纪律主定理：变量键安排 + 荷在 ⇒ 实例化恒等 *)
Theorem rinstP_ground_fix : forall rho cs,
  (forall k v, In (k, v) rho -> RV_BASE <= k) ->
  rvars cs = [] ->
  rinstP rho cs = cs.
Proof.
  intros rho cs Hkeys Hrv.
  apply rinstP_allground; [exact Hkeys|].
  exact (rvars_nil_ground cs Hrv).
Qed.

(* ================= 六、B 组：枚举形态 ================= *)

Lemma assigns_nil_rvs : forall cands, assigns cands [] = [[]].
Proof. intros cands. reflexivity. Qed.

Lemma assigns_single : forall cands r,
  assigns cands [r] = map (fun c => [(r, c)]) cands.
Proof. intros cands r. simpl. rewrite app_nil_r. reflexivity. Qed.

(* 每个变量恰取一值 *)
Lemma assigns_length : forall cands rvs rho,
  In rho (assigns cands rvs) -> length rho = length rvs.
Proof.
  induction rvs as [|r rvs IH]; intros rho Hin; simpl in Hin.
  - destruct Hin as [Heq | []]. subst rho. reflexivity.
  - rewrite in_flat_map in Hin. destruct Hin as [y [Hy Hin]].
    rewrite in_map_iff in Hin. destruct Hin as [c [Hc Hin]].
    subst rho. simpl. rewrite (IH y Hy). reflexivity.
Qed.

(* 安排的键域：键 ⊆ 变量组，值 ⊆ 候选组 *)
Lemma assigns_domain : forall cands rvs rho,
  In rho (assigns cands rvs) ->
  forall k v, In (k, v) rho -> In k rvs /\ In v cands.
Proof.
  induction rvs as [|r rvs IH]; intros rho Hin k v Hinp; simpl in Hin.
  - destruct Hin as [Heq | []]. subst rho. simpl in Hinp. destruct Hinp.
  - rewrite in_flat_map in Hin. destruct Hin as [y [Hy Hin]].
    rewrite in_map_iff in Hin. destruct Hin as [c [Hrho HinC]].
    subst rho. simpl in Hinp.
    destruct Hinp as [Heq | Hinp].
    + injection Heq as Hk Hv. subst k v. split; [left; reflexivity | exact HinC].
    + destruct (IH y Hy k v Hinp) as [Hk Hv].
      split; [right; exact Hk | exact Hv].
Qed.

(* ================= 七、C 组：循环可靠性 ================= *)

Lemma arr_loop_some_spec : forall fuel cs rhos acc s l rho,
  snd (arr_loop fuel cs rhos acc) = Some (s, l, rho) ->
  In rho rhos /\ solve4 fuel (rinstP rho cs) = Some (s, l).
Proof.
  intros fuel cs rhos. induction rhos as [|rho0 rhos IH]; intros acc s l rho H.
  - simpl in H. discriminate.
  - simpl in H.
    destruct (solve4 fuel (rinstP rho0 cs)) as [[s0 l0] |] eqn:E.
    + cbn in H. injection H as Hs Hl Hr. subst s0 l0 rho0.
      split; [left; reflexivity | exact E].
    + destruct (IH (S acc) s l rho H) as [Hin Hs].
      split; [right; exact Hin | exact Hs].
Qed.

Theorem solve6_witness : forall fuel cs s l rho,
  solve6 fuel cs = Some (s, l, rho) ->
  In rho (arrange_plan cs) /\ solve4 fuel (rinstP rho cs) = Some (s, l).
Proof.
  intros fuel cs s l rho H. unfold solve6 in H.
  apply (arr_loop_some_spec fuel cs (arrange_plan cs) 0 s l rho H).
Qed.

Lemma arr_loop_exhaust_spec : forall fuel cs rhos acc,
  (forall rho, In rho rhos -> solve4 fuel (rinstP rho cs) = None) ->
  arr_loop fuel cs rhos acc = (acc + length rhos, None).
Proof.
  intros fuel cs rhos. induction rhos as [|rho0 rhos IH]; intros acc Hall.
  - simpl. rewrite Nat.add_0_r. reflexivity.
  - simpl. rewrite (Hall rho0 (or_introl eq_refl)). cbn.
    rewrite (IH (S acc)) by (intros rho Hin; apply Hall; right; exact Hin).
    rewrite Nat.add_succ_r. reflexivity.
Qed.

Theorem solve6_exhaust : forall fuel cs,
  (forall rho, In rho (arrange_plan cs) -> solve4 fuel (rinstP rho cs) = None) ->
  solve6 fuel cs = None /\ arrange_trials fuel cs = length (arrange_plan cs).
Proof.
  intros fuel cs Hall. unfold solve6, arrange_trials.
  rewrite (arr_loop_exhaust_spec fuel cs (arrange_plan cs) 0 Hall).
  split; reflexivity.
Qed.

(* ================= 八、D 组：诺特 N3 流侧 ================= *)

(* D1. 荷在 ⇒ 流零：无区域变量 ⇒ 安排循环退化为恒等一支
      （trials = 1；唯一被试安排为 []；solve6 = solve4 的零包装）。 *)

(* 桥：恒等安排下 arr_loop 的显式形态 *)
Lemma arr_loop_identity : forall fuel cs,
  arr_loop fuel cs [[]] 0
  = (1, match solve4 fuel cs with
             | Some (s, l) => Some (s, l, [])
             | None => None
             end).
Proof.
  intros fuel cs. cbn [arr_loop].
  destruct (solve4 fuel (rinstP [] cs)) as [[s l] |] eqn:E.
  - rewrite (rinstP_nil cs) in E. rewrite E. reflexivity.
  - rewrite (rinstP_nil cs) in E. rewrite E. reflexivity.
Qed.

Theorem noether_N3_flow_zero : forall fuel cs,
  rvars cs = [] ->
  arrange_trials fuel cs = 1 /\
  solve6 fuel cs = match solve4 fuel cs with
                   | Some (s, l) => Some (s, l, [])
                   | None => None
                   end.
Proof.
  intros fuel cs H. unfold arrange_trials, solve6, arrange_plan.
  rewrite H, assigns_nil_rvs, arr_loop_identity.
  split; reflexivity.
Qed.

(* D2. 荷破 ⇒ 流皆非恒等：池含区域变量 ⇒ 每一被试安排都是真决策
      （非空——每变量恰一值的 assigns_length 面）。 *)
Theorem noether_N3_flow_nonidentity : forall cs,
  rvars cs <> [] ->
  forall rho, In rho (arrange_plan cs) -> rho <> [].
Proof.
  intros cs Hne rho Hin. intros Heq. subst rho.
  assert (HL := assigns_length (grounds cs) (rvars cs) [] Hin).
  destruct (rvars cs) as [|r rvs'] eqn:E.
  - exfalso. apply Hne. reflexivity.
  - simpl in HL. lia.
Qed.

(* D3. 恒等桥：经恒等安排命中 ⇒ 引擎单遍已足
      （solve4 的单遍许可证在恒等支上未被废除）。 *)
Theorem solve6_identity_bridge : forall fuel cs s l,
  solve6 fuel cs = Some (s, l, []) -> solve4 fuel cs = Some (s, l).
Proof.
  intros fuel cs s l H.
  destruct (solve6_witness fuel cs s l [] H) as [_ Hs].
  rewrite rinstP_nil in Hs. exact Hs.
Qed.

(* D4. N3 流侧对偶整合：荷在 ⇒ 流零（恒等一支）∧ 荷破 ⇒ 流皆非恒等。
      其正面对照（荷破 ⇒ 引擎/安排分歧——流出现且分支）的实机
      见 M35Example（poolV/poolG 双池同框）。 *)
Theorem noether_N3_flow_duality :
  (forall fuel cs, rvars cs = [] ->
     arrange_trials fuel cs = 1 /\
     solve6 fuel cs = match solve4 fuel cs with
                      | Some (s, l) => Some (s, l, [])
                      | None => None
                      end)
  /\ (forall cs, rvars cs <> [] ->
        forall rho, In rho (arrange_plan cs) -> rho <> []).
Proof.
  split.
  - apply noether_N3_flow_zero.
  - apply noether_N3_flow_nonidentity.
Qed.

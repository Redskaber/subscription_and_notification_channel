(* ===================================================================== *)
(*  效应能力流形 · W-M3-3 + W-M3-GFP · M33Example：实例推演 + 零公理审计     *)
(*                                                                         *)
(*  实例组（全部 eq_refl / vm_compute / 定理核证——编译即验证）：            *)
(*    一、e0m 复活：E.51 的 e 级 X 空窗（infer3 ∀fuel None）在 infer4      *)
(*        下命中——锥上升实机（主解 ⊕ 特化点 (0 ↦ &0 0)）                    *)
(*    二、H/τ 阻塞不因上升化解：Drop 5（H 孤儿）与 tomega（τ occurs）       *)
(*    三、快道保持：ghost_pool 经 solve3 命中——solve4 同解                  *)
(*    四、锥分解与盲性：e0m 复活解的纤维形态 + 盲性守恒在上升解下成立        *)
(*    五、dropck 档 2 翻转：Sneetch（档 1 过 / 档 2 拒）；hpool（R 提升过） *)
(*    六、豁免（may_dangle）：点名租约 1——通过集放大，非空差               *)
(*    七、GFP 三极：lphi（lfp）/ gphi（受限最大解）/ gfp（最大不动点）       *)
(*        + 对偶不对称实例（受限最大解不必是不动点）+ comptime 门            *)
(*    八、零公理审计：Print Assumptions 全量                                *)
(* ===================================================================== *)

Require Import List Lia PeanoNat Bool.
Import ListNotations.
Require Import Mult Cap Syntax CG Tau TyCG Lphi Fusion Mu Xsub M3Fusion
               Rsat Hsat Solve3 Xcone Drop2 Gphi Solve4
               M2Example M3Example M32Example.

(* ===================================================================== *)
(*  一、e0m 复活：e 级 X 空窗的闭合（锥上升实机）                            *)
(* ===================================================================== *)

Definition e0mpool : list constr := cg e0m ++ fst (cgT 0 [] e0m).

(* E.51 立起的判定性失败，本轮经锥上升复活：
   主解 α1 ↦ α3 → α0 潜伏 ⇒ 上升绑定 (0 ↦ &0 0) ⇒ Call 种子的区域 0 现形 *)
Example m33_e0m_revival :
  infer4 50 e0m
  = Some ([(1, TArrow (TVar 3) (TVar 0)); (0, TBorrow 0 (TVar 0))],
          lphi (chanProj ChPhi e0mpool)).
Proof. reflexivity. Qed.

(* 复活的读数面：上升解下 X 判定器为真（对照 m32_xsatb_e0m = false） *)
Example m33_xsatb_ascended :
  xsatb [(1, TArrow (TVar 3) (TVar 0)); (0, TBorrow 0 (TVar 0))] e0mpool
  = true.
Proof. reflexivity. Qed.

(* 复活定理的实例化：Call 项在 solve3 下 ∀fuel None、在 solve4 下复活 *)
Theorem m33_e0m_resurrection :
  (forall f s l, infer3 f e0m <> Some (s, l))
  /\ (exists f s l, infer4 f e0m = Some (s, l)).
Proof.
  apply (elevel_resurrection e0m 50 [(1, TArrow (TVar 3) (TVar 0))]).
  - reflexivity.
  - reflexivity.
  - (* hsat：e0m 池无 CEnd（无 Drop 观测）——判定器实机 *)
    apply (proj1 (hsatb_correct e0mpool)). reflexivity.
Qed.

(* ===================================================================== *)
(*  二、H / τ 阻塞不因上升化解（None 源收窄的诚实面）                        *)
(* ===================================================================== *)

(* H 孤儿（Drop 5）：还一个没借过的租约——上升无济于事 *)
Theorem m33_drop_still_blocked : forall f s l, infer4 f (Drop 5) <> Some (s, l).
Proof.
  intros f s l H. unfold infer4 in H.
  destruct (solve4_sound f (cg (Drop 5) ++ fst (cgT 0 [] (Drop 5))) s l H)
    as [_ [_ [_ [Hhs _]]]].
  assert (Hin : In (CEnd 5) (cg (Drop 5) ++ fst (cgT 0 [] (Drop 5))))
    by (simpl; left; reflexivity).
  destruct (Hhs 5 Hin) as [r [r0 [Hseed _]]].
  simpl in Hseed. destruct Hseed as [He | []]. discriminate.
Qed.

(* τ 阻塞（tomega = λx. x x）：occurs 不可合一——锥的底部为空，无从上升 *)
Theorem m33_tomega_still_blocked :
  forall f s l, infer4 f tomega <> Some (s, l).
Proof.
  intros f s l H. unfold infer4 in H.
  destruct (solve4_sound f (cg tomega ++ fst (cgT 0 [] tomega)) s l H)
    as [Hu _].
  rewrite chanProj_app, cg_no_cty, app_nil_l, tyEqs_proj in Hu.
  exact (m3_tomega_no_solution (ex_intro _ s Hu)).
Qed.

(* ===================================================================== *)
(*  三、快道保持：主解政策未被废除                                          *)
(* ===================================================================== *)

Example m33_ghost_fastpath :
  solve4 50 ghost_pool = Some (sg, lphi (chanProj ChPhi ghost_pool)).
Proof. reflexivity. Qed.

(* ===================================================================== *)
(*  四、锥分解与盲性守恒                                                    *)
(* ===================================================================== *)

Definition se4 : tsubst :=
  [(1, TArrow (TVar 3) (TVar 0)); (0, TBorrow 0 (TVar 0))].

(* 纤维分解实机：复活解 = 主解 ⊕ 特化点（tapply_app 的实例） *)
Example m33_e0m_cone : forall u,
  tapply se4 u
  = tapply (spoint 0 0) (tapply [(1, TArrow (TVar 3) (TVar 0))] u).
Proof.
  intros u.
  change (tapply ([(1, TArrow (TVar 3) (TVar 0))] ++ spoint 0 0) u
          = tapply (spoint 0 0) (tapply [(1, TArrow (TVar 3) (TVar 0))] u)).
  apply tapply_app.
Qed.

(* 盲性守恒在上升解下成立：X 列攀登，φ/R/H 行纹丝不动 *)
Example m33_blind_ascent :
  lphi (chanProj ChPhi (xapply se4 e0mpool)) = lphi (chanProj ChPhi e0mpool)
  /\ rclose (xapply se4 e0mpool) = rclose e0mpool
  /\ hclose (xapply se4 e0mpool) = hclose e0mpool.
Proof.
  destruct (blind_conservations se4 e0mpool) as [H1 [H2 [H3 _]]].
  exact (conj H1 (conj H2 H3)).
Qed.

(* ===================================================================== *)
(*  五、dropck 严格性档 2：判定翻转                                         *)
(* ===================================================================== *)

(* Sneetch 形态（RFC 769）：租约 1 出生于区域 0 且观测终点——
   挂靠恰为自身出生区域（无严格提升） *)
Definition sneetch : list constr := [CHr 1 0; CEnd 1].

(* 档 1（E.51）通过 *)
Example m33_tier1_pass :
  solve4 50 sneetch = Some ([], lphi (chanProj ChPhi sneetch)).
Proof. reflexivity. Qed.

(* 档 2（本轮）拒绝——同一池、两个时代（第二次翻案面） *)
Example m33_tier2_fail : hsat2b sneetch = false.
Proof. reflexivity. Qed.

Example m33_solve5_reject : solve5 50 sneetch = None.
Proof. reflexivity. Qed.

(* 严格间隙的语义面：档 2 无严格见证（种子即唯一挂靠） *)
Theorem m33_sneetch_gap : ~ hle2 sneetch 1 0.
Proof.
  intros [r [Hh Hne]].
  assert (Hin := hclose_complete sneetch 1 r Hh).
  vm_compute in Hin. destruct Hin as [He | []].
  assert (Hr : r = 0) by (injection He; intros; subst r; reflexivity).
  subst r. exfalso. apply Hne. reflexivity.
Qed.

(* hpool（E.51 的挂靠传递池）：R 提升供给严格见证——档 2 通过 *)
Example m33_hpool_tier2 : hsat2b hpool = true.
Proof. reflexivity. Qed.

Example m33_solve5_hpool :
  solve5 50 hpool = Some ([], lphi (chanProj ChPhi hpool)).
Proof. reflexivity. Qed.

(* 严格性可提升定理的实机：CRg 0 2 使挂靠上移出出生区域 *)
Theorem m33_hpool_strict_lift : hle2 hpool 1 0.
Proof.
  apply (hstrict_via_lift hpool 1 0 2).
  - simpl. auto.
  - simpl. auto.
  - discriminate.
Qed.

(* ===================================================================== *)
(*  六、豁免接口（RFC 1327 may_dangle 形态）                                *)
(* ===================================================================== *)

(* 点名租约 1 豁免严格支：通过集放大——豁免档有效且真弱于档 2 *)
Theorem m33_eyepatch_effect : hsat2e sneetch [1] /\ ~ hsat2 sneetch.
Proof.
  split.
  - apply (proj1 (hsat2eb_correct sneetch [1])). reflexivity.
  - intro H2.
    assert (hsat2b sneetch = true)
      by (apply (proj2 (hsat2b_correct sneetch)); exact H2).
    vm_compute in H. discriminate.
Qed.

(* 弱化方向实机：档 2 通过 ⇒ 豁免档通过（hpool 侧） *)
Theorem m33_hpool_weaken : hsat2e hpool [].
Proof.
  apply (hsat2e_weaken hpool []).
  apply (proj1 (hsat2b_correct hpool)). reflexivity.
Qed.

(* ===================================================================== *)
(*  七、GFP 三极：lphi / gphi / gfp + 对偶不对称 + comptime 门              *)
(* ===================================================================== *)

(* comptime 门：零需求判定 *)
Example m33_comptime_pass : comptimeb [CLv (CReg 0) M0] = true.
Proof. reflexivity. Qed.

Example m33_comptime_fail : comptimeb [CLv (CReg 1) M1] = false.
Proof. reflexivity. Qed.

(* e 级 comptime 语义：纯切片可编译、含分配的切片不可编译 *)
Example m33_slice_var_comptime :
  comptimeb (chanProj ChPhi (cg (Slice (Var 0)))) = true.
Proof. reflexivity. Qed.

Example m33_slice_new_block :
  comptimeb (chanProj ChPhi (cg (Slice (New 1)))) = false.
Proof. reflexivity. Qed.

(* 需求传播下的上界裁剪：ρ0 的容量装不下 ℓ1 的需求——gphi 把 ℓ1 剪到 0 *)
Definition upool : list constr := [CPr (CReg 0) (CLea 1) M1; CLv (CReg 0) M1].
Definition ubound : cmap := fun _ => M1.

Example m33_gphi_cut :
  gphi upool ubound (CReg 0) = M1 /\ gphi upool ubound (CLea 1) = M0.
Proof. vm_compute. split; reflexivity. Qed.

(* 三极同框：lfp（最小解）≤ 受限 gphi（最大容许解）；真 gfp（最大不动点）
   在本池与 lfp 重合——w = 0 的需求传播使最大前不动点坍缩到底 *)
Definition gpool : list constr := [CPr (CReg 0) (CLea 1) M0].

Example m33_three_poles :
  (lphi gpool (CReg 0) = M0 /\ lphi gpool (CLea 1) = M0)
  /\ (gphi gpool ubound (CReg 0) = M1 /\ gphi gpool ubound (CLea 1) = M1)
  /\ (gfp gpool (CReg 0) = M0 /\ gfp gpool (CLea 1) = M0).
Proof. vm_compute. repeat split; reflexivity. Qed.

(* 对偶不对称实锤：lfp 是不动点；受限最大解不必是不动点
   （ℓ1 无任何需求 ⇒ FC(gphi) 在 ℓ1 处 = 0 < 1 = gphi） *)
Example m33_gphi_not_fix :
  FC gpool (gphi gpool ubound) (CLea 1) <> gphi gpool ubound (CLea 1).
Proof.
  intro Heq. vm_compute in Heq. discriminate.
Qed.

(* ===================================================================== *)
(*  八、零公理审计（Print Assumptions）                                     *)
(* ===================================================================== *)

(* Xcone.v：实例锥 *)
Print Assumptions tapply_app.
Print Assumptions instance_sound.
Print Assumptions tvars_nonempty.
Print Assumptions roccurs_tsubst1_intro.
Print Assumptions xsat1_app_mono.
Print Assumptions xsatb_app_mono.
Print Assumptions xpick_spec.
Print Assumptions xpick_none.
Print Assumptions filter_len_le.
Print Assumptions xcount_le.
Print Assumptions filter_mono_len_le.
Print Assumptions filter_mono_len_lt.
Print Assumptions tapply_spoint.
Print Assumptions xcount_step_lt.
Print Assumptions xascend_app.
Print Assumptions xascend_unifies.
Print Assumptions xascend_xsat.

(* Drop2.v：严格性档 2 *)
Print Assumptions hle_b_correct.
Print Assumptions hstrict_b_correct.
Print Assumptions hsat2b_correct.
Print Assumptions hsat2_implies_hsat.
Print Assumptions hstrict_via_lift.
Print Assumptions hle_xapply_invar.
Print Assumptions hsat2_xapply_invar.
Print Assumptions hsat2e_weaken.
Print Assumptions hsat2eb_correct.

(* Gphi.v：gfp 对偶 *)
Print Assumptions phsat_join_closed.
Print Assumptions phsatb_correct.
Print Assumptions canon_correct.
Print Assumptions canon_phsat.
Print Assumptions gphi_admissible.
Print Assumptions comptimeb_correct.
Print Assumptions gphi_comptime.
Print Assumptions lphi_le_gphi.
Print Assumptions gfp_exists.

(* Solve4.v：组装 *)
Print Assumptions solve4_policy.
Print Assumptions solve4_sound.
Print Assumptions solve4_complete.
Print Assumptions solve4_profile.
Print Assumptions solve4_none.
Print Assumptions solve4_none_h.
Print Assumptions solve4_fiber.
Print Assumptions elevel_exit.
Print Assumptions elevel_resurrection.
Print Assumptions solve5_sound.
Print Assumptions solve5_profile.
Print Assumptions solve5_none.

(* M33Example.v：实例组 *)
Print Assumptions m33_e0m_resurrection.
Print Assumptions m33_drop_still_blocked.
Print Assumptions m33_tomega_still_blocked.
Print Assumptions m33_e0m_cone.
Print Assumptions m33_blind_ascent.
Print Assumptions m33_sneetch_gap.
Print Assumptions m33_hpool_strict_lift.
Print Assumptions m33_eyepatch_effect.
Print Assumptions m33_hpool_weaken.

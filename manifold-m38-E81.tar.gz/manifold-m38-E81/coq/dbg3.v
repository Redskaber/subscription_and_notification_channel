Require Import List Lia PeanoNat Bool.
Import ListNotations.
Require Import Mult Cap Syntax CG Tau TyCG Lphi Fusion Mu Xsub M3Fusion
               Rsat Hsat Solve3 Xcone Drop2 Gphi Solve4
               SigLam Noether M34Example Rvar M35Example SigStack M36Example.
Require Import Ineq.
Local Open Scope bool_scope.
Definition kappa2 : tm := Lam 0 (Lam 1 (Lam 2 (Call (Var 0) (Call (Var 1) (Var 2))))).
Definition sDx : ty := TArrow (TBorrow 9 (TVar 10)) (TBorrow 9 (TVar 11)).
Definition sDy : ty :=
  TArrow (TArrow (TBorrow 1 (TVar 10)) (TBorrow 9 (TVar 11))) (TBorrow 10 (TVar 13)).
Definition sDz : ty := TArrow (TBorrow 0 (TVar 14)) (TVar 15).
Definition skD : list constr := fst (cgK [sDx; sDy; sDz] 0 [] kappa2).
(* 活支期望：9↦1、10↦0 *)
Compute (solve4 50 (rinstP [(9,1);(10,0)] skD)).
(* 分解：只修 9 *)
Compute (solve4 50 (rinstP [(9,1)] skD)).
(* 只修 10 *)
Compute (solve4 50 (rinstP [(10,0)] skD)).
(* 逐方程检查 rinstP 后的池 *)
Compute (rinstP [(9,1);(10,0)] skD).
(* 相遇 1 的裸方程合一测试：x 类型 vs y dom *)
Compute (solve4 50 [CTy (TArrow (TBorrow 9 (TVar 10)) (TBorrow 9 (TVar 11)))
                     (TArrow (TBorrow 1 (TVar 10)) (TBorrow 9 (TVar 11)))]).

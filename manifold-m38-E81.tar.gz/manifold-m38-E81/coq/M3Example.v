(* ===================================================================== *)
(*  效应能力流形 · M3 · M3Example：组装完备/联合主性/幽灵现形的实机实例    *)
(*                                                                         *)
(*  四组实例（全部 eq_refl / 定理核证——编译即验证，非打印）：              *)
(*    一、组装完备与联合主性（W-M3-1）：e0m（τ 箭头 × φ ω 饱和一次取出）、 *)
(*        tflip（主解 = 方程层 mgu，联合主性实机）；                        *)
(*    二、e 级 None 的证明力：tomega（λx. x x）——任意燃料下 infer 必 None  *)
(*        （m3_tomega_no_infer：对 fuel 全称，非实机单点）；               *)
(*    三、幽灵现形（W-M3-X）：ghost_pool——区域 3 从变量像中现身；          *)
(*        e0m——幽灵载荷在主解下潜伏、在特化下现形（区域 9 从 α3 的像）；    *)
(*    四、零公理审计：Print Assumptions 对本轮全部新定理。                 *)
(* ===================================================================== *)

Require Import List Lia PeanoNat.
Import ListNotations.
Require Import Mult Cap Syntax CG Tau TyCG Lphi Fusion M2Example Mu Xsub M3Fusion.

(* ===================================================================== *)
(*  一、组装完备与联合主性（W-M3-1 实机）                                   *)
(* ===================================================================== *)

(* 1.1 e0m 全链路：τ 主解 α1 = α3 → α0 与 φ 最小解一次推断取出 *)
Example m3_e0m_infer :
  infer 50 e0m
  = Some ([(1, TArrow (TVar 3) (TVar 0))],
          lphi (chanProj ChPhi (cg e0m ++ fst (cgT 0 [] e0m)))).
Proof. reflexivity. Qed.

(* 组装完备定理路线：τ 可解 ⇒ ∃fuel. infer 命中（非单点实机） *)
Theorem m3_e0m_complete : exists fuel s l, infer fuel e0m = Some (s, l).
Proof.
  apply infer_complete.
  exists [(1, TArrow (TVar 3) (TVar 0))].
  apply (unify_sound 50). reflexivity.
Qed.

(* 1.2 tflip：infer 的 σ 即方程层 mgu（ex_flip 的融合版） *)
Example m3_flip_infer :
  infer 50 tflip
  = Some ([(0, TArrow (TVar 1) (TVar 2));
           (2, TArrow (TVar 3) (TVar 4));
           (5, TArrow (TVar 6) (TVar 4));
           (3, TArrow (TVar 6) (TVar 4));
           (6, TVar 1)],
          lphi (chanProj ChPhi (cg tflip ++ fst (cgT 0 [] tflip)))).
Proof. reflexivity. Qed.

Theorem m3_flip_complete : exists fuel s l, infer fuel tflip = Some (s, l).
Proof.
  apply infer_complete.
  exists [(0, TArrow (TVar 1) (TVar 2));
          (2, TArrow (TVar 3) (TVar 4));
          (5, TArrow (TVar 6) (TVar 4));
          (3, TArrow (TVar 6) (TVar 4));
          (6, TVar 1)].
  apply (unify_sound 50). reflexivity.
Qed.

(* 1.3 组装坍缩实机：cgT 方程有见证 ⇒ 池级联合可解（φ 侧零前提供给） *)
Theorem m3_e0m_collapse :
  (exists s, unifies s (tyEqs (fst (cgT 0 [] e0m))))
  -> ((exists s, unifies s (tyEqs (chanProj ChTy (cg e0m ++ fst (cgT 0 [] e0m)))))
      /\ (exists l, phsat l (chanProj ChPhi (cg e0m ++ fst (cgT 0 [] e0m))))).
Proof.
  intros [s Hs].
  assert (Hpool : unifies s
            (tyEqs (chanProj ChTy (cg e0m ++ fst (cgT 0 [] e0m))))).
  { rewrite chanProj_app, cg_no_cty, app_nil_l, tyEqs_proj. exact Hs. }
  apply (proj2 (assembly_collapse (cg e0m ++ fst (cgT 0 [] e0m)))).
  exists s. exact Hpool.
Qed.

(* ===================================================================== *)
(*  二、e 级 None 的证明力（组装完备的逆否，对燃料全称）                    *)
(* ===================================================================== *)

(* 2.1 λx. x x 的方程层不可合一（occurs：α1 = α1 → … 的自指核心） *)
Theorem m3_tomega_no_solution :
  ~ (exists s, unifies s (tyEqs (fst (cgT 0 [] tomega)))).
Proof.
  intros [s Hs].
  destruct (unify_complete (tyEqs (fst (cgT 0 [] tomega))) (ex_intro _ s Hs))
    as [fuel [sigma Hu]].
  destruct fuel as [|[|[|[|[|f]]]]];
    try (simpl in Hu; discriminate);
    try (vm_compute in Hu; discriminate).
Qed.

(* 2.2 e 级判定性：任意燃料下 infer 对 tomega 必 None
      （soundness + 不可合一 ⇒ None 是判定性答案，非预算事件） *)
Theorem m3_tomega_no_infer : ~ (exists f s l, infer f tomega = Some (s, l)).
Proof.
  intros [f [s [l H]]].
  destruct (infer_sound f tomega s l H) as [Hs _].
  exact (m3_tomega_no_solution (ex_intro _ s Hs)).
Qed.

(* 单点实机对照（M2 轮 ex_omega 的融合版） *)
Example m3_tomega_infer_none : infer 50 tomega = None.
Proof. reflexivity. Qed.

(* ===================================================================== *)
(*  三、幽灵现形（W-M3-X 实机）                                             *)
(* ===================================================================== *)

(* 3.1 ghost_pool：区域 3 是纯幽灵——载荷是变量 α1，地面无区域 *)
Definition ghost_pool : list constr :=
  [CTy (TVar 1) (TBorrow 3 (TVar 7)); CXr 3 (TVar 1); CLv (CReg 3) M1].
Definition sg : tsubst := [(1, TBorrow 3 (TVar 7))].

(* τ 通道主解：α1 := TBorrow ρ3 α7 *)
Example m3_ghost_principal :
  unify 10 (tyEqs (chanProj ChTy ghost_pool)) = Some sg.
Proof. reflexivity. Qed.

(* 现形前：区域 3 不在载荷的任何地面位置 *)
Example m3_ghost_hidden : roccurs 3 (TVar 1) = false.
Proof. reflexivity. Qed.

(* 现形后：区域 3 从变量 α1 的像中现身 *)
Example m3_ghost_shown : roccurs 3 (tapply sg (TVar 1)) = true.
Proof. reflexivity. Qed.

(* 现形算子实机：X 载荷被 τ 代换改写；φ 约束纹丝不动 *)
Example m3_ghost_xapply :
  xapply sg ghost_pool
  = [CTy (TBorrow 3 (TVar 7)) (TBorrow 3 (TVar 7));
     CXr 3 (TBorrow 3 (TVar 7));
     CLv (CReg 3) M1].
Proof. reflexivity. Qed.

(* φ 盲性实机：现形不移动 φ 最小解（守恒律 2） *)
Example m3_ghost_phi_blind :
  lphi (chanProj ChPhi (xapply sg ghost_pool))
  = lphi (chanProj ChPhi ghost_pool).
Proof. apply lphi_xapply_invar. Qed.

Example m3_ghost_phi_value :
  lphi (chanProj ChPhi (xapply sg ghost_pool)) (CReg 3) = M1.
Proof. rewrite lphi_xapply_invar. reflexivity. Qed.

(* 主解现形全部幽灵（X 读数为真） *)
Example m3_ghost_xsat : xsat sg ghost_pool.
Proof.
  intros c Hc.
  destruct c as [a b | r1 r2 | c k | c c' w | l r | l | r t]; try exact I.
  simpl in Hc. destruct Hc as [Heq | [Heq | [Heq | []]]].
  - inversion Heq.
  - inversion Heq; subst; reflexivity.
  - inversion Heq.
Qed.

(* 3.2 谱系实例：特化 sg'（α7 ↦ TBorrow ρ5 α8）使幽灵生长——区域 5 现身 *)
Definition sg' : tsubst :=
  [(7, TBorrow 5 (TVar 8)); (1, TBorrow 3 (TBorrow 5 (TVar 8)))].
Definition tau_g : tsubst := [(7, TBorrow 5 (TVar 8))].

(* 实例关系（项作用外延——#212 的语义；注意 head-first：特化必须显式
   重绑定 σ 值中出现的变量，否则 (7,B) 先被消耗、α7 潜伏——§8 实录） *)
Example m3_ghost_instance :
  forall u, tapply sg' u = tapply tau_g (tapply sg u).
Proof.
  induction u as [m | a IHa b IHb | r a IHa].
  - destruct m as [|[|[|[|[|[|[|[|m]]]]]]]]; reflexivity.
  - rewrite !tapply_arrow, IHa, IHb. reflexivity.
  - rewrite !tapply_borrow, IHa. reflexivity.
Qed.

(* 谱系传播定理实机：主解的 X 满足 ⇒ 特化的 X 满足 *)
Example m3_ghost_spec_xsat : xsat sg' ghost_pool.
Proof.
  apply (xsat_principal_mono ghost_pool sg sg' tau_g).
  - exact m3_ghost_instance.
  - exact m3_ghost_xsat.
Qed.

(* 幽灵生长：区域 5 在主解读数中缺席，在特化读数中现身 *)
Example m3_ghost_grow_principal : roccurs 5 (tapply sg (TVar 1)) = false.
Proof. reflexivity. Qed.
Example m3_ghost_grow_spec : roccurs 5 (tapply sg' (TVar 1)) = true.
Proof. reflexivity. Qed.

(* 点式现形定理实机：区域 5 只能来自幽灵起点（变量像） *)
Example m3_ghost_split_witness :
  exists x, In x (tvars (TVar 1))
            /\ roccurs 5 (tapply sg' (TVar x)) = true.
Proof.
  assert (H : roccurs 5 (tapply sg' (TVar 1)) = true) by reflexivity.
  destruct (proj1 (roccurs_tapply_split sg' 5 (TVar 1)) H)
    as [Hg | [x [Hin Hx]]].
  - simpl in Hg. discriminate.
  - exists x. split; assumption.
Qed.

(* 3.3 e0m 的幽灵：载荷 TArrow α0 α1 在主解下潜伏，在特化下现形 *)
Definition se0m : tsubst := [(1, TArrow (TVar 3) (TVar 0))].
Definition se0m' : tsubst :=
  [(3, TBorrow 9 (TVar 8)); (1, TArrow (TBorrow 9 (TVar 8)) (TVar 0))].
Definition tau_e0m : tsubst := [(3, TBorrow 9 (TVar 8))].

Example m3_e0m_instance :
  forall u, tapply se0m' u = tapply tau_e0m (tapply se0m u).
Proof.
  induction u as [m | a IHa b IHb | r a IHa].
  - destruct m as [|[|[|[|[|[|[|[|m]]]]]]]]; reflexivity.
  - rewrite !tapply_arrow, IHa, IHb. reflexivity.
  - rewrite !tapply_borrow, IHa. reflexivity.
Qed.

(* e0m 的 X 载荷（cg e0m 的 CXr 0 (TArrow α0 α1)）：
   主解下区域 9 潜伏（读数可判定为假——如实登记：X 求解义务未接入） *)
Example m3_e0m_ghost_latent :
  roccurs 9 (tapply se0m (TArrow (TVar 0) (TVar 1))) = false.
Proof. reflexivity. Qed.

(* 特化下现形：区域 9 从变量 α3 的像中现身 *)
Example m3_e0m_ghost_shown :
  roccurs 9 (tapply se0m' (TArrow (TVar 0) (TVar 1))) = true.
Proof. reflexivity. Qed.

(* 现形来源定理实机：地面位置无区域 9 ⇒ 必有幽灵起点 *)
Theorem m3_e0m_split_witness :
  exists x, In x (tvars (TArrow (TVar 0) (TVar 1)))
            /\ roccurs 9 (tapply se0m' (TVar x)) = true.
Proof.
  assert (H : roccurs 9 (tapply se0m' (TArrow (TVar 0) (TVar 1))) = true)
    by reflexivity.
  destruct (proj1 (roccurs_tapply_split se0m' 9 (TArrow (TVar 0) (TVar 1))) H)
    as [Hg | [x [Hin Hx]]].
  - simpl in Hg. discriminate.
  - exists x. split; assumption.
Qed.

(* e0m 融合层的 φ 盲性：ω 饱和在现形后保持（域外能力恒零对照） *)
Example m3_e0m_phi_blind_omega :
  lphi (chanProj ChPhi (xapply se0m (cg e0m ++ fst (cgT 0 [] e0m)))) (CReg 0)
  = MW.
Proof. rewrite lphi_xapply_invar. reflexivity. Qed.

Example m3_e0m_phi_blind_out :
  lphi (chanProj ChPhi (xapply se0m (cg e0m ++ fst (cgT 0 [] e0m)))) (CReg 9)
  = M0.
Proof. rewrite lphi_xapply_invar. reflexivity. Qed.

(* ===================================================================== *)
(*  四、零公理审计（Print Assumptions）                                     *)
(* ===================================================================== *)

(* Xsub.v：幽灵现形三守恒 + 谱系 *)
Print Assumptions chOf_xapply1.
Print Assumptions chanProj_xapply.
Print Assumptions xapply_chanProj_phi.
Print Assumptions lphi_xapply_invar.
Print Assumptions roccurs_tapply_mono.
Print Assumptions roccurs_tapply_split.
Print Assumptions xsat_principal_mono.

(* M3Fusion.v：组装完备 + 联合主性 + 坍缩 + 幽灵融合层 *)
Print Assumptions phi_unconditional.
Print Assumptions assembly_collapse.
Print Assumptions solve2_complete.
Print Assumptions solve2_principal.
Print Assumptions infer_complete.
Print Assumptions infer_principal.
Print Assumptions infer_partition.
Print Assumptions solve2_x_ghost_stable.
Print Assumptions solve2_x_principal.

(* M3Example.v：e 级判定性与幽灵实例 *)
Print Assumptions m3_e0m_complete.
Print Assumptions m3_flip_complete.
Print Assumptions m3_e0m_collapse.
Print Assumptions m3_tomega_no_solution.
Print Assumptions m3_tomega_no_infer.
Print Assumptions m3_ghost_instance.
Print Assumptions m3_e0m_instance.
Print Assumptions m3_e0m_split_witness.

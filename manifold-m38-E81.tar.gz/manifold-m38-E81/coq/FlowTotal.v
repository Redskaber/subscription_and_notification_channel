(* ===================================================================== *)
(*  效应能力流形 · W-INEQ-2 · FlowTotal：flow_total 一般化                  *)
(*                    （集合划分恒等式的上机——核划分计数）                  *)
(*                                                                         *)
(*  第 56 轮（#292–#301）· 文献锚 E.81（新增 E.81–E.85）                    *)
(*  清偿对象：E.76 轮登记的 W-INEQ-2 挂账（flow_total 一般化与 efold        *)
(*  结构引理组的计数面——集合划分恒等式 sum_P falling(|G|, |块P|) = |G|^|R|  *)
(*  的上机；M37 四池实机 1/4/8/2 的一般化）。                              *)
(*                                                                         *)
(*  核心内容（三层数学表示）：                                              *)
(*    §1 下降阶乘 falling g k = g(g-1)...(g-k+1)（nat 截断——g<k 时 0）。   *)
(*    §2 划分恒等式（纯算术层，任意 g 的一般定理）：                        *)
(*         n=2：falling g 1 + falling g 2 = g^2                             *)
(*         n=3：falling g 1 + 3*falling g 2 + falling g 3 = g^3             *)
(*    §3 no_plan 的核划分计数（定理层）：                                   *)
(*         flow_total_two（一般定理，Qed）：|rvars|=2 ⇒ |no_plan|=|G|^2      *)
(*              ——清偿 Ineq.noether_ineq_flow_total_two 挂账                *)
(*              （等式支 |G| 对角线 + 差异支 |G|^2-|G| 扣除）。              *)
(*         flow_total_three（陈述）：|rvars|=3 ⇒ |no_plan|=|G|^3——          *)
(*              一块 |G| + 三种两块 3(g^2-g) + 三块 falling g 3。           *)
(*              完整三变量决策分解证明挂 W-INEQ-3。                          *)
(*    §4 划分表（n=2/3 的显式块结构）与 Stirling 面。                       *)
(*    §5 诺特对偶整合。                                                      *)
(* ===================================================================== *)

Require Import List Lia PeanoNat Bool.
Import ListNotations.
Require Import Mult Cap Syntax CG Tau TyCG Lphi Fusion Mu Xsub M3Fusion
               Rsat Hsat Solve3 Xcone Drop2 Gphi Solve4
               SigLam Noether M34Example Rvar M35Example SigStack M36Example
               Ineq SibLam M37Example DpllT.

Local Open Scope bool_scope.

(* ================= 一、下降阶乘 ================= *)

(* falling g k = g(g-1)...(g-k+1)；nat 截断语义下 g < k 时自动为 0 *)
Fixpoint falling (g k : nat) : nat :=
  match k with
  | 0 => 1
  | S k' => g * falling (Nat.pred g) k'
  end.

Lemma sub_2_pred : forall g, g - 2 = Nat.pred (Nat.pred g).
Proof. intros g. lia. Qed.

Lemma falling_one : forall g, falling g 1 = g.
Proof. intros g. cbn [falling]. rewrite Nat.mul_1_r. destruct g; reflexivity. Qed.

Lemma falling_two_form : forall g, falling g 2 = g * (g - 1).
Proof.
  intros g. cbn [falling]. rewrite !Nat.mul_1_r.
  rewrite Nat.sub_1_r. reflexivity.
Qed.

Lemma falling_three_form : forall g, falling g 3 = g * (g - 1) * (g - 2).
Proof.
  intros g. cbn [falling]. rewrite !Nat.mul_1_r.
  rewrite Nat.sub_1_r, sub_2_pred.
  rewrite Nat.mul_assoc. reflexivity.
Qed.

(* ================= 二、划分恒等式（纯算术层——任意 g） ================= *)

(* n=2：一块（同值 g 支）+ 两块（互异 g(g-1) 支）= g^2 *)
Theorem flow_total_arith_two : forall g,
  falling g 1 + falling g 2 = g * g.
Proof.
  intros g. rewrite falling_one, falling_two_form.
  destruct g as [|g].
  - reflexivity.
  - replace (S g - 1) with g by lia. nia.
Qed.

(* n=3：一块 g + 三种两块 3*g(g-1) + 三块 g(g-1)(g-2) = g^3 *)
Theorem flow_total_arith_three : forall g,
  falling g 1 + 3 * falling g 2 + falling g 3 = g * g * g.
Proof.
  intros g. rewrite falling_one, falling_two_form, falling_three_form.
  destruct g as [|[|g]].
  - reflexivity.
  - reflexivity.
  - replace (S (S g) - 1) with (S g) by lia.
    replace (S (S g) - 2) with g by lia.
    nia.
Qed.

(* ================= 三、no_plan 的核划分计数（n=2 一般定理） ================= *)

(* 恒真谓词过滤不过滤（点式版） *)
Lemma filter_pred_true : forall (A : Type) (p : A -> bool) (l : list A),
  (forall a, p a = true) -> filter p l = l.
Proof.
  intros A p l Hall.
  induction l as [|a l IH]; [reflexivity|].
  cbn [filter].
  rewrite (Hall a).
  rewrite IH by (apply Hall).
  reflexivity.
Qed.

(* 两元素过滤（两谓词真） *)
Lemma filter_two : forall (A : Type) (p : A -> bool) (a b : A),
  p a = true -> p b = true -> filter p [a; b] = [a; b].
Proof.
  intros A p a b Ha Hb. cbn [filter].
  rewrite Ha, Hb. reflexivity.
Qed.

Lemma elook_nil : forall r, elook [] r = r.
Proof. intros r. reflexivity. Qed.

(* esub_of 的两支显式形态 *)
Lemma esub_of_eq : forall x y, x <> y -> esub_of [(x, y, true)] = [(y, x)].
Proof.
  intros x y Hxy.
  assert (E1 : (x =? y) = false) by (apply Nat.eqb_neq; exact Hxy).
  assert (E2 : (y =? x) = false).
  { apply Nat.eqb_neq. intros Heq. apply Hxy. symmetry. exact Heq. }
  unfold esub_of. cbn.
  rewrite E1, E2, Nat.eqb_refl.
  cbn [redirect remove_key].
  rewrite E1.
  reflexivity.
Qed.

Lemma esub_of_neq : forall x y, esub_of [(x, y, false)] = [].
Proof. intros x y. reflexivity. Qed.

(* neq_ok 的两支形态 *)
Lemma neq_ok_eqbranch : forall x y,
  neq_ok (esub_of [(x, y, true)]) (neqs_of [(x, y, true)]) = true.
Proof. intros x y. reflexivity. Qed.

Lemma neq_ok_neqbranch : forall x y, x <> y ->
  neq_ok (esub_of [(x, y, false)]) (neqs_of [(x, y, false)]) = true.
Proof.
  intros x y Hxy.
  rewrite esub_of_neq.
  assert (E : (x =? y) = false) by (apply Nat.eqb_neq; exact Hxy).
  cbn.
  rewrite E.
  reflexivity.
Qed.

(* 单变量对的决策组合 *)
Lemma no_decisions_ok_two : forall x y, x <> y ->
  no_decisions_ok [x; y] = [[(x, y, true)]; [(x, y, false)]].
Proof.
  intros x y Hxy. unfold no_decisions_ok.
  replace (all_pairs [x; y]) with [(x, y)] by reflexivity.
  replace (no_decisions [(x, y)])
    with [[(x, y, true)]; [(x, y, false)]] by reflexivity.
  apply (filter_two _ _ [(x, y, true)] [(x, y, false)]).
  - reflexivity.
  - apply neq_ok_neqbranch. exact Hxy.
Qed.

(* free_vars 的两支形态 *)
Lemma free_vars_eqbranch : forall x y, x <> y ->
  free_vars [(x, y, true)] [x; y] = [x].
Proof.
  intros x y Hxy. unfold free_vars.
  rewrite (esub_of_eq x y Hxy).
  cbn [keyb existsb fst filter].
  rewrite Nat.eqb_refl.
  destruct (y =? x) eqn:E.
  - apply Nat.eqb_eq in E. exfalso. apply Hxy. symmetry. exact E.
  - reflexivity.
Qed.

Lemma free_vars_neqbranch : forall x y,
  free_vars [(x, y, false)] [x; y] = [x; y].
Proof.
  intros x y. unfold free_vars. rewrite esub_of_neq.
  reflexivity.
Qed.

(* 两变量 assigns 的长度 *)
Lemma assigns_two_length : forall cands x y,
  length (assigns cands [x; y]) = length cands * length cands.
Proof.
  intros cands x y.
  rewrite (assigns_two_eq cands x y).
  rewrite (flat_map_length_const _ _ _ _ (length cands)).
  - reflexivity.
  - intros g Hg. rewrite length_map. reflexivity.
Qed.

(* spread 的空代换形态 *)
Lemma spread_neq_form : forall g x y,
  spread (esub_of [(x, y, false)]) g [x; y]
  = [(x, rlook g x); (y, rlook g y)].
Proof.
  intros g x y. rewrite esub_of_neq.
  cbn [spread spread1 elook].
  reflexivity.
Qed.

(* 差异支谓词桥：spread 后的同值检查 = 原表同值检查 *)
Lemma neq_ok_rho_spread : forall g x y, x <> y ->
  neq_ok_rho [(x, y)] (spread (esub_of [(x, y, false)]) g [x; y])
  = negb (rlook g x =? rlook g y).
Proof.
  intros g x y Hxy.
  rewrite spread_neq_form.
  cbn [neq_ok_rho forallb fst snd].
  rewrite (rlook_here x (rlook g x) [(y, rlook g y)]).
  rewrite (rlook_other y x (rlook g x) [(y, rlook g y)]).
  - rewrite (rlook_here y (rlook g y) []).
    rewrite andb_true_r.
    reflexivity.
  - intros Heq. apply Hxy. symmetry. exact Heq.
Qed.

(* 主定理：|rvars| = 2 ⇒ |no_plan| = |G|^2
   （Ineq.noether_ineq_flow_total_two 挂账的清偿——
    等式支 |G| 对角线 + 差异支 |G|^2 - |G| diag_count 扣除） *)
Theorem flow_total_two : forall cs,
  length (rvars cs) = 2 ->
  length (no_plan cs) = (length (grounds cs)) ^ 2.
Proof.
  intros cs Hlen.
  unfold no_plan.
  destruct (rvars cs) as [|x [|y rest]] eqn:Hrv.
  - discriminate Hlen.
  - discriminate Hlen.
  - assert (Hrest : rest = []).
    { destruct rest as [|r rest']; [reflexivity|].
      cbn in Hlen. discriminate. }
    subst rest.
  assert (Hxy : x <> y).
  { intros Heq.
    assert (Hnd := rvars_NoDup cs). rewrite Hrv in Hnd.
    inversion Hnd as [|a l Hnin Hnd']; subst.
    exfalso. apply Hnin. left. reflexivity. }
  rewrite (no_decisions_ok_two x y Hxy).
  cbn [flat_map].
  unfold no_branch.
  rewrite Hrv.
  rewrite (free_vars_eqbranch x y Hxy).
  rewrite (free_vars_neqbranch x y).
  (* 等式支：filter 恒真（neqs_of = [] ⇒ forallb 空）+ map 长度 *)
  assert (Heq_len :
    length (filter (fun rho => neq_ok_rho (neqs_of [(x, y, true)]) rho)
                   (map (fun g => spread (esub_of [(x, y, true)]) g [x; y])
                        (assigns (grounds cs) [x])))
    = length (grounds cs)).
  { erewrite filter_pred_true by (intros a; reflexivity).
    rewrite length_map.
    rewrite assigns_single_eq, length_map. reflexivity. }
  (* 差异支：filter_map_push + 谓词桥 + 互补分裂 *)
  assert (Hneq_len :
    length (filter (fun rho => neq_ok_rho (neqs_of [(x, y, false)]) rho)
                   (map (fun g => spread (esub_of [(x, y, false)]) g [x; y])
                        (assigns (grounds cs) [x; y])))
    = length (grounds cs) * length (grounds cs) - length (grounds cs)).
  { rewrite filter_map_push.
    rewrite length_map.
    assert (Hpred : forall g, In g (assigns (grounds cs) [x; y]) ->
      neq_ok_rho (neqs_of [(x, y, false)])
                 (spread (esub_of [(x, y, false)]) g [x; y])
      = negb (rlook g x =? rlook g y)).
    { intros g _. cbn [neqs_of filter]. apply neq_ok_rho_spread. exact Hxy. }
    rewrite (filter_pointwise_ext _ _ _ _ Hpred).
    assert (Hsplit := filter_split_length _
                (fun g => rlook g x =? rlook g y)
                (assigns (grounds cs) [x; y])).
    assert (Hdiag := diag_count (grounds cs) x y (grounds_NoDup cs) Hxy).
    assert (Hlen2 := assigns_two_length (grounds cs) x y).
    lia. }
  rewrite length_app.
  rewrite app_nil_r.
  rewrite Heq_len, Hneq_len.
  rewrite Nat.pow_2_r.
  assert (Hpos : forall n, n <= n * n).
  { intros n. destruct n as [|k]; [lia|]. cbn. lia. }
  specialize (Hpos (length (grounds cs))).
  lia.
Qed.

(* n=3 的一般定理（陈述）：
   |rvars| = 3 ⇒ |no_plan| = |G|^3——一块 |G| + 三种两块 3(|G|^2-|G|)
   + 三块 falling |G| 3（Bell(3)=5 划分的核分类）。完整证明挂
   W-INEQ-3（三变量决策级的 no_branch 分解计数需要传递一致性过滤
   的组合引理——skJ 型 5 一致决策的枚举形态一般化）。skJ 实机
   （8 = 2 + 3*2 + 0 = 2^3）见 M38Example。 *)
Theorem flow_total_three : forall cs,
  length (rvars cs) = 3 ->
  length (no_plan cs) = (length (grounds cs)) ^ 3.
Proof.
  intros cs Hlen. admit.
Admitted.

(* ================= 四、划分表（n=2/3 的显式块结构） ================= *)

(* R = [a;b] 的全部划分（Bell(2)=2） *)
Definition parts2 (a b : nat) : list (list (list nat)) :=
  [[[a; b]]; [[a]; [b]]].

(* R = [a;b;c] 的全部划分（Bell(3)=5） *)
Definition parts3 (a b c : nat) : list (list (list nat)) :=
  [[[a; b; c]];
   [[a; b]; [c]]; [[a; c]; [b]]; [[b; c]; [a]];
   [[a]; [b]; [c]]].

Lemma parts2_len : forall a b, length (parts2 a b) = 2.
Proof. intros. reflexivity. Qed.

Lemma parts3_len : forall a b c, length (parts3 a b c) = 5.
Proof. intros. reflexivity. Qed.

(* 划分的块数序列（按 parts3 的序：1;2;2;2;3） *)
Lemma parts3_blocks :
  forall a b c, map (fun p => length p) (parts3 a b c) = [1; 2; 2; 2; 3].
Proof. intros. reflexivity. Qed.

(* n=2 的划分求和对齐 *)
Lemma parts2_flow : forall g a b,
  falling g 1 + falling g 2
  = fold_right plus 0 (map (fun p => falling g (length p)) (parts2 a b)).
Proof.
  intros g a b. cbn [parts2 map fold_right length].
  rewrite falling_one, falling_two_form.
  destruct g as [|g].
  - reflexivity.
  - replace (S g - 1) with g by lia. nia.
Qed.

(* n=3 的划分求和对齐 *)
Lemma parts3_flow : forall g a b c,
  falling g 1 + 3 * falling g 2 + falling g 3
  = fold_right plus 0 (map (fun p => falling g (length p)) (parts3 a b c)).
Proof.
  intros g a b c.
  cbn [parts3 map fold_right length].
  rewrite falling_one.
  rewrite !falling_two_form.
  rewrite falling_three_form.
  destruct g as [|[|g]].
  - reflexivity.
  - reflexivity.
  - replace (S (S g) - 1) with (S g) by lia.
    replace (S (S g) - 2) with g by lia.
    nia.
Qed.

(* ================= 五、诺特对偶整合 ================= *)

(* flow_total 谱系（n=2 定理 + 算术层 + 划分表对齐） *)
Theorem flow_total_duality :
  (forall cs, length (rvars cs) = 2 ->
     length (no_plan cs) = (length (grounds cs)) ^ 2)
  /\ (forall g, falling g 1 + falling g 2 = g * g)
  /\ (forall g, falling g 1 + 3 * falling g 2 + falling g 3 = g * g * g).
Proof.
  split; [apply flow_total_two |].
  split; [apply flow_total_arith_two | apply flow_total_arith_three].
Qed.

(* ===================================================================== *)
(*  效应能力流形 · W-M2-1 · 完备性与 mgu 的实机实例                         *)
(*                                                                         *)
(*  贡献 #218 · 本文件三组实例：                                           *)
(*    一、None 的证明力：unify_complete 的逆否实机——"返回 None"            *)
(*        从经验观察升格为"不存在合一器"的机器定理（三种失败模式）；       *)
(*    二、mgu 的实机语义：一个主解、任意特化——两组不同特化 σ' 均为        *)
(*        主解 σ 经某 τ 的实例（全称等式直接验证，纯计算不依赖定理）；    *)
(*    三、零公理审计：Print Assumptions 对本轮全部新定理。                *)
(* ===================================================================== *)

Require Import List Lia.
Import ListNotations.
Require Import Syntax Mult Cap CG Tau Mu.

(* ===================================================================== *)
(*  一、None 的证明力（完备性定理的逆否实机）                              *)
(* ===================================================================== *)

(* 1.1 构造子冲突：Arrow ≠ Borrow，不存在合一器
      （E.40 轮 ex_unify_clash 的升级：从"实机看 None"到"证明不可合一"） *)
Example wm21_clash_no_unifier :
  ~ (exists s, unifies s [(TArrow (TVar 0) (TVar 1), TBorrow 3 (TVar 0))]).
Proof.
  intros [s Hs].
  destruct (unify_complete [(TArrow (TVar 0) (TVar 1), TBorrow 3 (TVar 0))]
              (ex_intro _ s Hs)) as [fuel [sigma Hu]].
  destruct fuel as [|f]; simpl in Hu; discriminate.
Qed.

(* 1.2 occurs 循环：α0 = α0→α1（λx.x x 的核心方程，Rust E0391 同族） *)
Example wm21_occurs_no_unifier :
  ~ (exists s, unifies s [(TVar 0, TArrow (TVar 0) (TVar 1))]).
Proof.
  intros [s Hs].
  destruct (unify_complete [(TVar 0, TArrow (TVar 0) (TVar 1))]
              (ex_intro _ s Hs)) as [fuel [sigma Hu]].
  destruct fuel as [|f]; simpl in Hu; [discriminate|].
  destruct f as [|f']; simpl in Hu; discriminate.
Qed.

(* 1.3 区域冲突：ρ3 ≠ ρ4，不存在合一器（租约区域的不可交换性） *)
Example wm21_region_no_unifier :
  ~ (exists s, unifies s [(TBorrow 3 (TVar 0), TBorrow 4 (TVar 1))]).
Proof.
  intros [s Hs].
  destruct (unify_complete [(TBorrow 3 (TVar 0), TBorrow 4 (TVar 1))]
              (ex_intro _ s Hs)) as [fuel [sigma Hu]].
  destruct fuel as [|f]; simpl in Hu; discriminate.
Qed.

(* ===================================================================== *)
(*  二、mgu 的实机语义：一个主解，任意特化                                  *)
(*                                                                         *)
(*  系统 E_id = [α0 = α1→α1]（恒等函数的单约束形状）。                     *)
(*  主解 σ = [α0 ↦ α1→α1]（unify 实机返回，#205 主代换的最小例）。         *)
(*  特化一：α1 ↦ (TVar5→TVar5)；特化二：α1 ↦ TVar7。                      *)
(*  两个特化都是 σ 经 τ 的实例——mgu 的"最一般"以全称等式直接核证。         *)
(* ===================================================================== *)

Definition E_id : list (ty * ty) := [(TVar 0, TArrow (TVar 1) (TVar 1))].
Definition sg_id : tsubst := [(0, TArrow (TVar 1) (TVar 1))].

(* 2.1 unify 实机返回主解（零燃料路径的即值核证） *)
Example wm21_id_principal : unify 10 E_id = Some sg_id.
Proof. reflexivity. Qed.

(* 2.2 主解确实是解（可靠侧的即值核证，对照 #205） *)
Example wm21_id_sound : unifies sg_id E_id.
Proof. apply (unify_sound 10). reflexivity. Qed.

(* ---- 特化一：α1 ↦ TVar5→TVar5 ---- *)

(* T55 扮演"具体基类型" *)
Definition T55 : ty := TArrow (TVar 5) (TVar 5).
Definition sg1 : tsubst :=
  [(0, TArrow T55 T55); (1, T55)].
Definition tau1 : tsubst := [(1, T55)].

(* 特化一确为 E_id 的解 *)
Example wm21_spec1_sat : unifies sg1 E_id.
Proof. simpl. split; [reflexivity | exact I]. Qed.

(* 特化一是主解的实例：全称等式，纯计算（mgu 定理的实例侧对应物） *)
Example wm21_mgu_direct1 :
  forall u, tapply sg1 u = tapply tau1 (tapply sg_id u).
Proof.
  induction u as [m | a IHa b IHb | r a].
  - destruct m as [|[|[|m]]]; simpl; reflexivity.
  - rewrite !tapply_arrow, IHa, IHb. reflexivity.
  - rewrite !tapply_borrow, IHa. reflexivity.
Qed.

(* 同一件事经定理路线：unify_mgu 给出存在性 *)
Example wm21_mgu_thm1 : exists t, forall u,
  tapply sg1 u = tapply t (tapply sg_id u).
Proof.
  apply (unify_mgu 10 E_id sg_id wm21_id_principal sg1 wm21_spec1_sat).
Qed.

(* ---- 特化二：α1 ↦ TVar7（变量特化——主解的中性） ---- *)

Definition sg2 : tsubst := [(0, TArrow (TVar 7) (TVar 7)); (1, TVar 7)].
Definition tau2 : tsubst := [(1, TVar 7)].

Example wm21_spec2_sat : unifies sg2 E_id.
Proof. simpl. split; [reflexivity | exact I]. Qed.

Example wm21_mgu_direct2 :
  forall u, tapply sg2 u = tapply tau2 (tapply sg_id u).
Proof.
  induction u as [m | a IHa b IHb | r a].
  - destruct m as [|[|[|m]]]; simpl; reflexivity.
  - rewrite !tapply_arrow, IHa, IHb. reflexivity.
  - rewrite !tapply_borrow, IHa. reflexivity.
Qed.

(* 2.3 一个主解，两个不相交特化：mgu 的"最一般"实机含义
      （两特化互不为彼此实例，但都是 σ 的实例——谱系的分叉点在 σ） *)
Example wm21_two_specs_one_principal :
  (forall u, tapply sg1 u = tapply tau1 (tapply sg_id u))
  /\ (forall u, tapply sg2 u = tapply tau2 (tapply sg_id u)).
Proof. split; [exact wm21_mgu_direct1 | exact wm21_mgu_direct2]. Qed.

(* ===================================================================== *)
(*  三、零公理审计（Print Assumptions）                                    *)
(* ===================================================================== *)

(* W-M2-1 双主定理：应全部 Closed under the global context *)
Print Assumptions unify_complete.
Print Assumptions unify_mgu.

(* 完备性侧引理组 *)
Print Assumptions plex_wf.
Print Assumptions rstep_wf.
Print Assumptions tapply_subst1_comm.
Print Assumptions unifies_occurs_ex.
Print Assumptions unifies_clash_arrow_borrow.
Print Assumptions unifies_clash_region.

(* mgu 侧引理组 *)
Print Assumptions unify_dom_range.
Print Assumptions unify_no_x.
Print Assumptions tapply_no_x.
Print Assumptions mgu_elim.

(* 实例的证明力三例 *)
Print Assumptions wm21_clash_no_unifier.
Print Assumptions wm21_occurs_no_unifier.
Print Assumptions wm21_region_no_unifier.
Print Assumptions wm21_mgu_direct1.
Print Assumptions wm21_mgu_direct2.

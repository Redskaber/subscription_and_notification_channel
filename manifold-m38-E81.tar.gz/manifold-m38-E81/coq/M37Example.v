(* ===================================================================== *)
(*  效应能力流形 · 第 51 轮 · M37Example：不等式安排的实机（诺特不等式律）  *)
(*                                                                         *)
(*  六组实机（编译即验证——eq_refl / Print Assumptions）：                   *)
(*    1. 栈读数表：六池（skI 双荷单地面 / skD 双荷双地面双相遇 /            *)
(*       skJ 三荷双地面 / skS 单变量退化 / skP 兄弟共享 / skQ 兄弟排他）      *)
(*       的 rvars/grounds/no_plan/引擎/trials 读数                           *)
(*    2. 诺特不等式律实机：对源（读数不出池）；流形总量守恒（四池            *)
(*       length (no_plan) = length (arrange_plan)——非凸化是重组不是扩张）； *)
(*       同调（efold 链头的 spread 读数——同链同值）；                        *)
(*       深度（skS 单变量无对——no_plan = arrange_plan 恒等退化）             *)
(*    3. 一死一活（skD）：NO 流 4（等式支 2 死 + 差异支 1 死 1 活）          *)
(*       vs 凸流 3（1 死 2 活?）——重组的路径代价；见证 [(9,1);(10,0)]        *)
(*    4. 分区梯度（skJ）：5 一致决策 / 8 支守恒（|G|³=2³）；                  *)
(*       全等式支 2 枚举 / 全差异支空（|G|=2<3 链）                          *)
(*    5. 兄弟 λ 分叉（skP/skQ）：cgK（共享 sb0）vs cgKX（排他 sb0/sb1）；     *)
(*       池读数分叉（grounds [1] vs [1;0]）⇒ 安排流形分叉（1 支 vs 2 支）    *)
(*    6. Print Assumptions 全链路零公理审计                                  *)
(*                                                                         *)
(*  展示项：κ = λx.λy.y x（C 组合子）；κ₂ = λx.λy.λz. z (y x)（双 Call）；    *)
(*  σ = (λx.x)(λy.y)（兄弟双恒等）。                                          *)
(* ===================================================================== *)

Require Import List Lia PeanoNat Bool.
Import ListNotations.
Require Import Mult Cap Syntax CG Tau TyCG Lphi Fusion Mu Xsub M3Fusion
               Rsat Hsat Solve3 Xcone Drop2 Gphi Solve4
               SigLam Noether M34Example Rvar M35Example SigStack M36Example
               Ineq SibLam.

Local Open Scope bool_scope.

(* ================= 0. 展示项与六池 ================= *)

(* κ = λx.λy. y x —— C 组合子 *)
Definition kappa : tm := Lam 0 (Lam 1 (Call (Var 0) (Var 1))).
(* κ₂ = λx.λy.λz. z (y x) —— 双 Call 两层相遇 *)
Definition kappa2 : tm :=
  Lam 0 (Lam 1 (Lam 2 (Call (Var 0) (Call (Var 1) (Var 2))))).
(* σ = (λx.x)(λy.y) —— 兄弟双恒等 *)
Definition sigmaSib : tm := Call (Lam 0 (Var 0)) (Lam 1 (Var 1)).

(* skI：双荷单地面（双荷相遇——余域 &₉ ≡ &₁₀） *)
Definition sIx : ty := TArrow (TBorrow 0 (TVar 20)) (TBorrow 9 (TVar 21)).
Definition sIy : ty := TArrow (TArrow (TBorrow 0 (TVar 20)) (TBorrow 10 (TVar 21))) (TVar 22).
Definition skI : list constr := fst (cgK [sIx; sIy] 0 [] kappa).

(* skD：双荷双地面双相遇（κ₂——相遇 1 修复 9↦1、相遇 2 修复 10↦0） *)
Definition sDx : ty := TArrow (TBorrow 9 (TVar 20)) (TBorrow 9 (TVar 21)).
Definition sDy : ty :=
  TArrow (TArrow (TBorrow 1 (TVar 20)) (TBorrow 9 (TVar 21))) (TBorrow 10 (TVar 22)).
Definition sDz : ty := TArrow (TBorrow 0 (TVar 23)) (TVar 24).
Definition skD : list constr := fst (cgK [sDx; sDy; sDz] 0 [] kappa2).

(* skJ：三荷双地面（κ——双荷相遇 + 独立地面锚） *)
Definition sJx : ty := TArrow (TBorrow 9 (TVar 20)) (TBorrow 10 (TVar 21)).
Definition sJy : ty :=
  TArrow (TArrow (TBorrow 1 (TVar 20)) (TBorrow 11 (TVar 21))) (TBorrow 2 (TVar 22)).
Definition skJ : list constr := fst (cgK [sJx; sJy] 0 [] kappa).

(* m36 skS：单变量（NO 视角的无对退化） *)
Definition sS0 : ty := TArrow (TBorrow 1 (TVar 10)) (TBorrow 9 (TVar 11)).
Definition sS1 : ty :=
  TArrow (TArrow (TBorrow 1 (TVar 10)) (TBorrow 0 (TVar 11))) (TVar 12).
Definition skS : list constr := fst (cgK [sS0; sS1] 0 [] kappa).

(* skP / skQ：兄弟池（cgK 共享 vs cgKX 排他） *)
Definition skP : list constr := fst (cgK [sb0; sb1; sb2] 0 [] sigmaSib).
Definition skQ : list constr := xcs (cgKX [sb0; sb1; sb2] 0 [] sigmaSib).

(* ================= 1. 栈读数表 ================= *)

Example m37_rvars_skI : rvars skI = [9; 10]. Proof. reflexivity. Qed.
Example m37_grounds_skI : grounds skI = [0]. Proof. reflexivity. Qed.
Example m37_rvars_skD : rvars skD = [9; 10]. Proof. reflexivity. Qed.
Example m37_grounds_skD : grounds skD = [1; 0]. Proof. reflexivity. Qed.
Example m37_rvars_skJ : rvars skJ = [9; 10; 11]. Proof. reflexivity. Qed.
Example m37_grounds_skJ : grounds skJ = [1; 2]. Proof. reflexivity. Qed.
Example m37_rvars_skS : rvars skS = [9]. Proof. reflexivity. Qed.
Example m37_grounds_skS : grounds skS = [1; 0]. Proof. reflexivity. Qed.
Example m37_rvars_skP : rvars skP = [9]. Proof. reflexivity. Qed.
Example m37_grounds_skP : grounds skP = [1]. Proof. reflexivity. Qed.
Example m37_rvars_skQ : rvars skQ = [9]. Proof. reflexivity. Qed.
Example m37_grounds_skQ : grounds skQ = [1; 0]. Proof. reflexivity. Qed.

(* 引擎面：双荷相遇的 τ 冲突（单遍到期） *)
Example m37_engine_skI : solve4 50 skI = None. Proof. reflexivity. Qed.
Example m37_engine_skD : solve4 50 skD = None. Proof. reflexivity. Qed.
Example m37_engine_skP : solve4 50 skP = None. Proof. reflexivity. Qed.
Example m37_engine_skQ : solve4 50 skQ = None. Proof. reflexivity. Qed.

(* NO 决策形态 *)
Example m37_decs_skD : no_decisions_ok (rvars skD)
  = [[(9, 10, true)]; [(9, 10, false)]]. Proof. reflexivity. Qed.
Example m37_decs_len_skJ : length (no_decisions_ok (rvars skJ)) = 5.
Proof. reflexivity. Qed.

(* 等式支 / 差异支的枚举 *)
Example m37_eqbranch_skI :
  no_branch skI [(9, 10, true)] = [[(9, 0); (10, 0)]]. Proof. reflexivity. Qed.
Example m37_nebranch_skI : no_branch skI [(9, 10, false)] = [].
Proof. reflexivity. Qed.
Example m37_eqbranch_skD :
  no_branch skD [(9, 10, true)]
  = [[(9, 1); (10, 1)]; [(9, 0); (10, 0)]]. Proof. reflexivity. Qed.
Example m37_nebranch_skD :
  no_branch skD [(9, 10, false)]
  = [[(9, 0); (10, 1)]; [(9, 1); (10, 0)]]. Proof. reflexivity. Qed.
Example m37_fulleq_skJ :
  no_branch skJ [(9, 10, true); (9, 11, true); (10, 11, true)]
  = [[(9, 1); (10, 1); (11, 1)]; [(9, 2); (10, 2); (11, 2)]].
Proof. reflexivity. Qed.
Example m37_alldiff_skJ :
  no_branch skJ [(9, 10, false); (9, 11, false); (10, 11, false)] = [].
Proof. reflexivity. Qed.

(* ================= 2. 诺特不等式律实机 ================= *)

(* 流形总量守恒（四池：|NO 计划| = |凸计划|——非凸化是重组） *)
Theorem m37_conservation :
  length (no_plan skI) = length (arrange_plan skI)
  /\ length (no_plan skD) = length (arrange_plan skD)
  /\ length (no_plan skJ) = length (arrange_plan skJ)
  /\ length (no_plan skS) = length (arrange_plan skS).
Proof. repeat split; reflexivity. Qed.

(* 守恒数值：skI 1=1；skD 4=4；skJ 8=8（|G|³=2³）；skS 2=2 *)
Theorem m37_conservation_values :
  length (no_plan skI) = 1
  /\ length (no_plan skD) = 4
  /\ length (no_plan skJ) = 8
  /\ length (no_plan skS) = 2.
Proof. repeat split; reflexivity. Qed.

(* 对源：读数不出池（rvars/grounds 全部来自池方程——cgK_labels 血统的 NO 面） *)
Theorem m37_charge_ledger :
  (rvars skI = [9;10] /\ grounds skI = [0])
  /\ (rvars skD = [9;10] /\ grounds skD = [1;0])
  /\ (rvars skJ = [9;10;11] /\ grounds skJ = [1;2]).
Proof. repeat split; reflexivity. Qed.

(* 同调：等式决策 ⇒ 同链同值（spread 的传播读数） *)
Example m37_coherence_skI :
  no_branch skI [(9, 10, true)] = [[(9, 0); (10, 0)]].
Proof. reflexivity. Qed.
Example m37_efold_chain : esub_of [(9, 10, true); (10, 11, true)]
  = [(11, 9); (10, 9)]. Proof. reflexivity. Qed.
Example m37_efold_dup : esub_of [(9, 10, true); (9, 11, true); (10, 11, true)]
  = [(11, 9); (10, 9)]. Proof. reflexivity. Qed.
Example m37_efold_skip : esub_of [(9, 10, true); (9, 10, true)] = [(10, 9)].
Proof. reflexivity. Qed.
Example m37_free_split : free_vars [(9, 10, true)] [9; 10; 11] = [9; 11].
Proof. reflexivity. Qed.

(* 深度：单变量无对 ⇒ 恒等退化（no_plan = arrange_plan） *)
Example m37_zero_skS : no_plan skS = arrange_plan skS. Proof. reflexivity. Qed.

(* ================= 3. 一死一活（skD——流重组的路径代价） ================= *)

(* NO 流 4：等式支 2 死（9↦1 与 10↦1 需同时 g=1 ∧ g=0 矛盾）
   + 差异支 1 死（9↦0 撞地面 1）1 活（9↦1、10↦0） *)
Example m37_notrials_skD : no_trials 50 skD = 4. Proof. reflexivity. Qed.
(* 凸流 3：第 3 支命中（前 2 死） *)
Example m37_convtrials_skD : arrange_trials 50 skD = 3. Proof. reflexivity. Qed.
(* 见证：差异支 [(9,1);(10,0)]——9↦1 修相遇 1、10↦0 修相遇 2 *)
Theorem m37_witness_skD :
  match solve7 50 skD with
  | Some (_, _, rho) => rho = [(9, 1); (10, 0)]
  | None => False
  end /\ solve6 50 skD <> None.
Proof. split; [reflexivity | intros H; discriminate]. Qed.

(* 差异支的 witnessing 可靠性（no_witness 的实机） *)
Example m37_skD_solve7_some : solve7 50 skD <> None.
Proof. intros H. discriminate. Qed.
Example m37_skD_solve6_some : solve6 50 skD <> None.
Proof. intros H. discriminate. Qed.

(* ================= 4. 分区梯度（skJ——Bell(3)=5 一致决策） ================= *)

(* 5 一致决策的枚举长度（8 组合 - 3 传递冲突） *)
Example m37_bell3 : length (no_decisions_ok (rvars skJ)) = 5.
Proof. reflexivity. Qed.
(* 守恒 8 支 = |G|³ = 2³：全等式 2 + {9,10}|{11} 2 + {9,11}|{10} 2 + {10,11}|{9} 2 + 全差异 0 *)
Theorem m37_partition_gradient :
  length (no_plan skJ) = 8 /\ (length (grounds skJ)) ^ (length (rvars skJ)) = 8.
Proof. split; reflexivity. Qed.
(* trials：全等式支首枚举即命中 *)
Example m37_notrials_skJ : no_trials 50 skJ = 1. Proof. reflexivity. Qed.
Example m37_notrials_skI : no_trials 50 skI = 1. Proof. reflexivity. Qed.

(* ================= 5. 兄弟 λ 分叉（skP/skQ） ================= *)

(* 兄弟注记：cgK 共享（y ↦ sb0）vs cgKX 排他（y ↦ sb1） *)
Example m37_sib_share : nth 4 skP (CTy (TVar 0) (TVar 0)) = CTy (TVar 5) sb0.
Proof. reflexivity. Qed.
Example m37_sib_exclusive : nth 4 skQ (CTy (TVar 0) (TVar 0)) = CTy (TVar 5) sb1.
Proof. reflexivity. Qed.
(* 分叉定理（SibLam.sib_diverge 的再输出） *)
Theorem m37_sib_diverge : skP <> skQ.
Proof. exact sib_diverge. Qed.
(* 流形分叉：1 支 vs 2 支（兄弟栈纪律的实效） *)
Example m37_plan_skP : arrange_plan skP = [[(9, 1)]]. Proof. reflexivity. Qed.
Example m37_plan_skQ : arrange_plan skQ = [[(9, 1)]; [(9, 0)]]. Proof. reflexivity. Qed.
Example m37_noplan_skP : no_plan skP = [[(9, 1)]]. Proof. reflexivity. Qed.
Example m37_noplan_skQ : no_plan skQ = [[(9, 1)]; [(9, 0)]]. Proof. reflexivity. Qed.
Example m37_notrials_skP : no_trials 50 skP = 1. Proof. reflexivity. Qed.
Example m37_notrials_skQ : no_trials 50 skQ = 2. Proof. reflexivity. Qed.

(* ================= 6. Print Assumptions 全链路零公理审计 ================= *)

(* 实机组（全部 eq_refl——零公理血统） *)
Print Assumptions m37_rvars_skI.
Print Assumptions m37_grounds_skI.
Print Assumptions m37_rvars_skD.
Print Assumptions m37_grounds_skD.
Print Assumptions m37_rvars_skJ.
Print Assumptions m37_grounds_skJ.
Print Assumptions m37_rvars_skS.
Print Assumptions m37_grounds_skS.
Print Assumptions m37_rvars_skP.
Print Assumptions m37_grounds_skP.
Print Assumptions m37_rvars_skQ.
Print Assumptions m37_grounds_skQ.
Print Assumptions m37_engine_skI.
Print Assumptions m37_engine_skD.
Print Assumptions m37_engine_skP.
Print Assumptions m37_engine_skQ.
Print Assumptions m37_decs_skD.
Print Assumptions m37_decs_len_skJ.
Print Assumptions m37_eqbranch_skI.
Print Assumptions m37_nebranch_skI.
Print Assumptions m37_eqbranch_skD.
Print Assumptions m37_nebranch_skD.
Print Assumptions m37_fulleq_skJ.
Print Assumptions m37_alldiff_skJ.
Print Assumptions m37_conservation.
Print Assumptions m37_conservation_values.
Print Assumptions m37_charge_ledger.
Print Assumptions m37_coherence_skI.
Print Assumptions m37_efold_chain.
Print Assumptions m37_efold_dup.
Print Assumptions m37_efold_skip.
Print Assumptions m37_free_split.
Print Assumptions m37_zero_skS.
Print Assumptions m37_notrials_skD.
Print Assumptions m37_convtrials_skD.
Print Assumptions m37_witness_skD.
Print Assumptions m37_skD_solve7_some.
Print Assumptions m37_skD_solve6_some.
Print Assumptions m37_bell3.
Print Assumptions m37_partition_gradient.
Print Assumptions m37_notrials_skJ.
Print Assumptions m37_notrials_skI.
Print Assumptions m37_sib_share.
Print Assumptions m37_sib_exclusive.
Print Assumptions m37_sib_diverge.
Print Assumptions m37_plan_skP.
Print Assumptions m37_plan_skQ.
Print Assumptions m37_noplan_skP.
Print Assumptions m37_noplan_skQ.
Print Assumptions m37_notrials_skP.
Print Assumptions m37_notrials_skQ.

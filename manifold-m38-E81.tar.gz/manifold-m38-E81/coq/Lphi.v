(* ===================================================================== *)
(*  效应能力流形 · M2 · Lphi：Lφ 通道 = Kleene 迭代的直接实例化             *)
(*                                                                         *)
(*  贡献 #206（L 定理五 pass 归一的 φ 通道落地）。                          *)
(*                                                                         *)
(*  M1（Cap.v / CG.v）已供：kleene_lfp（lfp 存在、最小性、稳定界 2|D|+1）、 *)
(*  FCop / capsOf / phsat / phsat_to_postfix / postfix_to_phsat。           *)
(*  本轮的「Lφ 上机」= 把 CG 的 φ 投影喂给 FCop 并跑满饱和界：                *)
(*                                                                         *)
(*    lphi cs := iter (FCop cs) (2·|capsOf cs| + 1)                          *)
(*                                                                         *)
(*  主定理 lphi_solve：lphi cs 是 cs 的解 ∧ 是最小解（可执行求解器          *)
(*  的完全正确性——存在性由 M1 的 kleene_lfp 供给，此处补"跑满界            *)
(*  即达"的执行侧引理 iter_saturated_fix）。                                *)
(* ===================================================================== *)

Require Import List Lia PeanoNat.
Import ListNotations.
Require Import Mult Cap Syntax CG.

(* 饱和界：跑满它必达 lfp *)
Definition lphiN (cs : list constr) : nat := 2 * length (capsOf cs) + 1.

Definition lphi (cs : list constr) : cmap := iter (FCop cs) (lphiN cs).

(* 跑满界的迭代即不动点（执行侧关键引理） *)
Lemma iter_saturated_fix : forall cs c,
  iter (FCop cs) (lphiN cs) c = kop (FCop cs) (iter (FCop cs) (lphiN cs)) c.
Proof.
  intros cs c.
  destruct (kleene_stabilizes (FCop cs) (capsOf cs) (FC_out' cs)) as [N0 [HN0 Hst]].
  assert (Hge : N0 <= lphiN cs) by (unfold lphiN; lia).
  assert (HL : iter (FCop cs) (lphiN cs) c = iter (FCop cs) N0 c)
    by (apply (once_stable (FCop cs) N0 Hst (lphiN cs) Hge c)).
  assert (HR : kop (FCop cs) (iter (FCop cs) (lphiN cs)) c = iter (FCop cs) N0 c).
  { rewrite (kop_ext (FCop cs) (iter (FCop cs) (lphiN cs)) (iter (FCop cs) N0)).
    - rewrite <- iter_S. symmetry. apply Hst.
    - intros c0. apply (once_stable (FCop cs) N0 Hst (lphiN cs) Hge c0). }
  rewrite HL, HR. reflexivity.
Qed.

(* ================= Lφ 求解器完全正确性 ================= *)

Theorem lphi_solve : forall cs,
  phsat (lphi cs) cs /\ (forall m, phsat m cs -> cle (lphi cs) m).
Proof.
  intros cs. split.
  - apply (postfix_to_phsat cs). intros c.
    change (mle (kop (FCop cs) (iter (FCop cs) (lphiN cs)) c)
                 (iter (FCop cs) (lphiN cs) c)).
    rewrite <- (iter_saturated_fix cs c). apply mle_refl.
  - intros m Hm. intros c.
    apply (chain_le_pre (FCop cs) m (phsat_to_postfix cs m Hm) (lphiN cs) c).
Qed.

(* e 层面：CG φ 投影的最小解 = 跑满饱和界的迭代（cg_phi_min 的执行版） *)
Theorem cg_phi_lphi : forall e,
  phsat (lphi (chanProj ChPhi (cg e))) (chanProj ChPhi (cg e))
  /\ (forall m, phsat m (chanProj ChPhi (cg e))
         -> cle (lphi (chanProj ChPhi (cg e))) m).
Proof. intros e. apply lphi_solve. Qed.

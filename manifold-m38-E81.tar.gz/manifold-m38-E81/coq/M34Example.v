(* ===================================================================== *)
(*  效应能力流形 · 第 48 轮 · M34Example：λ 层签名扩展 + 诺特定理的实机     *)
(*                                                                         *)
(*  九组实机（编译即验证——eq_refl / Compute / Print Assumptions）：         *)
(*    1. e0m 的四代判定史：E.46 合法输出 → E.51 None → E.56 上升复活       *)
(*       → 本轮快道提前站（solve3 层直接命中——签名供给区域 0）             *)
(*    2. 签名 × 上升复合（翻案 #27 实机）：sigB 供给区域 9 ≠ 0——            *)
(*       快道不命中（solve3S = None）而上升照常（solve4S = Some）——         *)
(*       含 TBorrow 方程集上锥封闭不破缺，特化无需重跑合一。                *)
(*    3. 来源分类：方程集含 TBorrow ⇔ 来自签名（cgT 侧恒自由）。            *)
(*    4. 快道定理实机：siglam_fastpath_xsat 的实例化。                      *)
(*    5. 诺特三定理实机：N1 守恒包 / N2 盲性恒定 / N3 对偶。                *)
(*    6. Print Assumptions 全链路零公理审计。                                *)
(* ===================================================================== *)

Require Import List Lia PeanoNat Bool.
Import ListNotations.
Require Import Mult Cap Syntax CG Tau TyCG Lphi Fusion Mu Xsub M3Fusion
               Rsat Hsat Solve3 Xcone Drop2 Gphi Solve4 SigLam Noether.

Local Open Scope bool_scope.

(* ================= 0. 实例定义 ================= *)

Definition e0m : tm := Call (Grant (CLea 1) M1 (Var 0)) (Borrow 0 1).

(* 两个 λ 层入口签名：sigA 直接供给区域 0（Call 种子所需）；
   sigB 供给区域 9（≠ 0——快道不命中，留给上升） *)
Definition sigA : ty := TBorrow 0 (TVar 2).
Definition sigB : ty := TBorrow 9 (TVar 2).

Definition poolA : list constr := cg e0m ++ cgS sigA 0 [] e0m.
Definition poolB : list constr := cg e0m ++ cgS sigB 0 [] e0m.

(* 主解（poolB 的 unify 结果——上升的起点） *)
Definition sB0 : tsubst :=
  [(0, TBorrow 9 (TVar 2)); (1, TArrow (TVar 3) (TBorrow 9 (TVar 2)))].

(* ================= 1. e0m 的四代判定史 ================= *)

(* E.46（solve2）：X 义务不存在——合法输出（既有 m2_e0m_infer） *)
(* E.51（solve3）：X 主解政策——None（既有 m32_e0m_none，∀fuel；
   elevel_x_vacuous 的根因：cgT 方程恒 TBorrow 自由 ⇒ 主解像恒自由） *)
(* E.56（solve4）：X 锥可达——上升复活（既有 m33_e0m_revival） *)

(* 本轮（λ 层签名）：X 快道提前站——solve3 层直接命中。
   签名方程 (α₀, &0 α₂) 使主解把 α₀ 绑为 &0 α₂、α₁ 绑为 α₃ → &0 α₂——
   Call 种子 CXr 0 (TArrow α₀ α₁) 的主解像 TArrow (&0 α₂) (α₃ → &0 α₂)
   顶层含 TBorrow 0——X 读数在主解层即命中——无需上升。 *)
Example m34_sigA_revival_early :
  solve3S sigA 50 e0m
  = Some ([(0, TBorrow 0 (TVar 2)); (1, TArrow (TVar 3) (TBorrow 0 (TVar 2)))],
          lphi (chanProj ChPhi (cg e0m ++ cgS sigA 0 [] e0m))).
Proof. reflexivity. Qed.

(* 快道政策保持：签名命中 ⇒ solve4 同解返回（solve4_policy 的签名版） *)
Example m34_policy_sigA :
  solve4S sigA 50 e0m = solve3S sigA 50 e0m.
Proof. reflexivity. Qed.

(* ================= 2. 签名 × 上升复合（翻案 #27 实机） ================= *)

(* 2a. sigB：签名供给区域 9 ≠ 0——快道不命中。
     主解像 TArrow (&9 α₂) (α₃ → &9 α₂) 只含区域 9——
     Call 种子要的是区域 0——X 读数在主解层为假。 *)
Example m34_sigB_none :
  solve3S sigB 50 e0m = None.
Proof. reflexivity. Qed.

(* 2b. 同池上升照常：solve4S 命中——上升解 = 主解 ⊕ 特化点 (2 ↦ &0 2)。
     xpick 锁定 Call 种子 CXr 0 (TArrow α₀ α₁)（未满足——像只含 9）×
     首活变量 α₂ ⇒ 特化 [α₂ ↦ &0 α₂] ⇒ 像变 TArrow (&9 (&0 α₂)) (…)
     ⇒ 含 TBorrow 0 ⇒ 命中。**含 TBorrow 方程集上锥上升照常工作**——
     E.56 §4.1 "特化必须重新过合一，拒绝面出现"预言的机内反驳。 *)
Example m34_sigB_ascent :
  solve4S sigB 50 e0m
  = Some ([(0, TBorrow 9 (TVar 2));
           (1, TArrow (TVar 3) (TBorrow 9 (TVar 2)));
           (2, TBorrow 0 (TVar 2))],
          lphi (chanProj ChPhi (cg e0m ++ cgS sigB 0 [] e0m))).
Proof. reflexivity. Qed.

(* 2c. 翻案 #27 的合取陈述：快道空 + 上升通 + 方程集含 TBorrow——
     三件同框即"锥封闭在签名扩展下不破缺"的完整实机。 *)
Theorem m34_cone_intact_under_signature :
  (solve3S sigB 50 e0m = None)
  /\ (exists s l, solve4S sigB 50 e0m = Some (s, l))
  /\ eqs_free (tyEqs (cgS sigB 0 [] e0m)) = false
  /\ eqs_free (tyEqs (fst (cgT 0 [] e0m))) = true.
Proof.
  split; [reflexivity|].
  split.
  - exists [(0, TBorrow 9 (TVar 2));
            (1, TArrow (TVar 3) (TBorrow 9 (TVar 2)));
            (2, TBorrow 0 (TVar 2))],
           (lphi (chanProj ChPhi (cg e0m ++ cgS sigB 0 [] e0m))).
    exact m34_sigB_ascent.
  - split; reflexivity.
Qed.

(* 2d. 定理面：上升解的可靠性（siglam_ascent_sound 的实机）——
     含 TBorrow 方程集上返回见证解：τ 解 + φ 最小 + H 见证 + X 现形 *)
Theorem m34_ascent_sound_sigB :
  exists s l, solve4S sigB 50 e0m = Some (s, l) /\
  unifies s (tyEqs (chanProj ChTy poolB)) /\
  xsat s poolB /\ hsat poolB.
Proof.
  exists [(0, TBorrow 9 (TVar 2));
          (1, TArrow (TVar 3) (TBorrow 9 (TVar 2)));
          (2, TBorrow 0 (TVar 2))],
         (lphi (chanProj ChPhi poolB)).
  split; [reflexivity|].
  pose proof (siglam_ascent_sound sigB 50 e0m _ _ m34_sigB_ascent)
    as [Hu [_ [_ [Hhs Hxs]]]].
  split; [exact Hu|]. split; [exact Hxs | exact Hhs].
Qed.

(* ================= 3. 来源分类 ================= *)

(* 3a. 签名方程集不自由（含 TBorrow） *)
Example m34_eqs_borrowed :
  eqs_free (tyEqs (cgS sigB 0 [] e0m)) = false.
Proof. reflexivity. Qed.

(* 3b. cgT 侧恒自由（E.51 elevel_eqs_free 的核心——保持） *)
Example m34_eqs_cgT_free :
  eqs_free (tyEqs (fst (cgT 0 [] e0m))) = true.
Proof. reflexivity. Qed.

(* 3c. 来源分割定理的实机：方程集的 TBorrow 全部来自签名 *)
Theorem m34_source_split_sigB :
  tbfree sigB = false /\ eqs_free (tyEqs (fst (cgT 0 [] e0m))) = true.
Proof.
  apply (siglam_source_split sigB 0 [] e0m m34_eqs_borrowed).
Qed.

(* ================= 4. 快道定理实机 ================= *)

(* 4a. 主解像顶层 TBorrow（siglam_borrow_main 实机） *)
Example m34_borrow_main_sigA :
  tapply [(0, TBorrow 0 (TVar 2)); (1, TArrow (TVar 3) (TBorrow 0 (TVar 2)))]
         (TVar 0)
  = TBorrow 0 (TVar 2).
Proof. reflexivity. Qed.

(* 4b. 变量像的区域进入整像（siglam_fastpath_xsat 实机：
     签名方程在 E、主解合一、入口变量 α₀ ∈ 载荷变量 ⇒ Call 种子命中） *)
Theorem m34_fastpath_sigA :
  roccurs 0 (tapply [(0, TBorrow 0 (TVar 2)); (1, TArrow (TVar 3) (TBorrow 0 (TVar 2)))]
                    (TArrow (TVar 0) (TVar 1))) = true.
Proof.
  apply (siglam_fastpath_xsat
           (tyEqs (chanProj ChTy (cg e0m ++ cgS sigA 0 [] e0m)))
           [(0, TBorrow 0 (TVar 2)); (1, TArrow (TVar 3) (TBorrow 0 (TVar 2)))]
           0 0 (TVar 2) (TArrow (TVar 0) (TVar 1))).
  - (* 签名方程在 E *) left. reflexivity.
  - (* 主解合一 E *) apply (unify_sound 50). reflexivity.
  - (* α₀ ∈ 载荷变量 *) simpl. left. reflexivity.
Qed.

(* ================= 5. 诺特三定理实机 ================= *)

(* 5a. N1 守恒包实机：poolB 上主解 sB0 + 预算 5 ⇒
     上升终点 X 全满足 ∧ τ 轨道保持。 *)
Theorem m34_noether_N1_sigB :
  xsat (xascend sB0 poolB 5) poolB /\
  unifies (xascend sB0 poolB 5) (tyEqs (chanProj ChTy poolB)).
Proof.
  apply (noether_N1 poolB (tyEqs (chanProj ChTy poolB)) sB0 5).
  - (* unifies sB0 E：经由 unify 的可靠性 *)
    apply (unify_sound 50 (tyEqs (chanProj ChTy poolB)) sB0). reflexivity.
  - (* xcount sB0 poolB <= 5 *) vm_compute. lia.
Qed.

(* 5a'. N1 的经济性实机：起点未满足计数（=1——仅 Call 种子未满足） *)
Example m34_xcount_start :
  xcount sB0 poolB = 1.
Proof. reflexivity. Qed.

Example m34_xcount_ascended :
  xcount (xascend sB0 poolB 5) poolB = 0.
Proof. reflexivity. Qed.

(* 5b. N2 盲性恒定实机：上升解上 φ/R/H 读数与起点一致（盲性矩阵） *)
Example m34_blind_phi_ascent :
  lphi (chanProj ChPhi (xapply (xascend sB0 poolB 5) poolB))
  = lphi (chanProj ChPhi poolB).
Proof. rewrite lphi_xapply_invar. reflexivity. Qed.

Example m34_blind_hclose_ascent :
  hclose (xapply (xascend sB0 poolB 5) poolB) = hclose poolB.
Proof. rewrite hclose_xapply_invar. reflexivity. Qed.

Example m34_blind_rclose_ascent :
  rclose (xapply (xascend sB0 poolB 5) poolB) = rclose poolB.
Proof. rewrite rclose_xapply_invar. reflexivity. Qed.

(* 5c. N3 对偶实机：锥封闭无条件（含 TBorrow 方程集）+ 标签刚性条件 *)
Theorem m34_noether_N3_cone :
  unifies (sB0 ++ spoint 0 2) (tyEqs (chanProj ChTy poolB)).
Proof.
  apply (noether_N3_cone_unconditional (tyEqs (chanProj ChTy poolB)) sB0 (spoint 0 2)).
  apply (unify_sound 50). reflexivity.
Qed.

(* ================= 6. 零公理审计 ================= *)

Print Assumptions cgS_tyEqs.
Print Assumptions siglam_free.
Print Assumptions siglam_borrowed.
Print Assumptions siglam_source_split.
Print Assumptions unifies_in.
Print Assumptions siglam_borrow_main.
Print Assumptions siglam_fastpath_xsat.
Print Assumptions siglam_cone_intact.
Print Assumptions siglam_ascent_sound.
Print Assumptions siglam_ascent_unifies.
Print Assumptions noether_N1.
Print Assumptions noether_N1_economy.
Print Assumptions noether_N2.
Print Assumptions noether_N2_fiber.
Print Assumptions noether_N3_cone_unconditional.
Print Assumptions noether_N3_rigid_conditional.
Print Assumptions noether_N3_duality.
Print Assumptions noether_classification.
Print Assumptions m34_sigA_revival_early.
Print Assumptions m34_sigB_none.
Print Assumptions m34_sigB_ascent.
Print Assumptions m34_cone_intact_under_signature.
Print Assumptions m34_source_split_sigB.
Print Assumptions m34_fastpath_sigA.
Print Assumptions m34_noether_N1_sigB.
Print Assumptions m34_noether_N3_cone.

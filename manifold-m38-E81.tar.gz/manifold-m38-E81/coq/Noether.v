(* ===================================================================== *)
(*  效应能力流形 · W-N1/2/3 · Noether：诺特定律的定理化                     *)
(*                                                                         *)
(*  历史形态（E.39–E.56）：诺特定律以**审计纪律**形态运行——每约束须答      *)
(*  守恒量，答不出者挂欠条（各轮 THEORY.md "设计诺特定律审计"表）。         *)
(*  本轮把它升格为**定理形态**：三条定律各得一个可机械化陈述。               *)
(*                                                                         *)
(*  N1 对称 ⇒ 守恒：                                                        *)
(*    对称面 = 实例锥封闭（instance_sound——合一解集对任意后复合封闭）。      *)
(*    守恒量 = 上升终点三件：X 全满足 + τ 轨道保持 + 终点在锥上。            *)
(*    （noether_N1——xascend_xsat ⊗ xascend_unifies 的诺特整合）             *)
(*                                                                         *)
(*  N2 规范对称 ⇒ 诺特恒等式：                                              *)
(*    规范对称 = 通道分割（chan_partition）+ 现形通道守恒（chOf_xapply1）。  *)
(*    恒等式 = X 轨道上 φ/R/H 读数恒定（盲性矩阵全行）——义务沿轨道         *)
(*    恒定，解在轨道商（纤维）上定义。                                       *)
(*    （noether_N2——盲性五件套 + solve4_fiber 的轨道商形态）                *)
(*                                                                         *)
(*  N3 荷—流对偶：                                                          *)
(*    荷 = 无条件对称（锥封闭——对任意方程集成立，含 TBorrow 签名方程在内）；  *)
(*    流 = 安排循环（等式/不等式传播）。                                     *)
(*    锥封闭荷在 λ 层签名扩展下**不破缺**（E.56 §4.1 预言的上机反驳——       *)
(*    翻案 #27：拒绝面不出现，重跑合一不必要）；条件对称只剩 tau_rigid       *)
(*    （TBorrow 标签刚性）一项——DPLL(T) 回归的触发面收窄为单边：            *)
(*    区域变量化（W-TYPEX-3 / W-GAT 线）是唯一的流出现点。                   *)
(*    （noether_N3_cone_unconditional / noether_N3_rigid_conditional /       *)
(*     noether_N3_duality）                                                 *)
(* ===================================================================== *)

Require Import List Lia PeanoNat Bool.
Import ListNotations.
Require Import Mult Cap Syntax CG Tau TyCG Lphi Fusion Mu Xsub M3Fusion
               Rsat Hsat Solve3 Xcone Drop2 Gphi Solve4.

Local Open Scope bool_scope.

(* ================= 一、N1：对称 ⇒ 守恒 ================= *)

(* 诺特第一定律（机内形态）：锥封闭（对称）供给上升终点守恒包——
   X 全满足（xascend_xsat）∧ τ 轨道保持（xascend_unifies）。
   对称面（instance_sound）无条件成立；守恒结论对任意池成立。 *)
Theorem noether_N1 : forall cs E s0 n,
  unifies s0 E ->
  xcount s0 cs <= n ->
  xsat (xascend s0 cs n) cs /\
  unifies (xascend s0 cs n) E.
Proof.
  intros cs E s0 n Hu Hn. split.
  - apply (proj1 (xsatb_correct (xascend s0 cs n) cs)).
    apply xascend_xsat. exact Hn.
  - apply xascend_unifies. exact Hu.
Qed.

(* N1 的经济性侧注（守恒量的消耗形态）：特化链每步严格降 *)
Theorem noether_N1_economy : forall cs s r x,
  xpick s cs = Some (r, x) ->
  xcount (s ++ spoint r x) cs < xcount s cs.
Proof.
  intros cs s r x Hp. apply (xcount_step_lt cs s r x Hp).
Qed.

(* ================= 二、N2：规范对称 ⇒ 诺特恒等式 ================= *)

(* 诺特第二定律（机内形态）：X 轨道上 φ/R/H 读数恒定——
   盲性矩阵全行的整合（φ 最小解 / R 闭包 / H 闭包 / 档 1 iff / 档 2 iff /
   R 前序 iff 六件）。义务沿轨道恒定：上升只走 X 列。 *)
Theorem noether_N2 : forall s cs,
  lphi (chanProj ChPhi (xapply s cs)) = lphi (chanProj ChPhi cs)
  /\ rclose (xapply s cs) = rclose cs
  /\ hclose (xapply s cs) = hclose cs
  /\ (hsat (xapply s cs) <-> hsat cs)
  /\ (hsat2 (xapply s cs) <-> hsat2 cs)
  /\ (forall a b, rle (xapply s cs) a b <-> rle cs a b).
Proof.
  intros s cs.
  pose proof (blind_conservations s cs) as [H1 [H2 [H3 H4]]].
  split; [exact H1|]. split; [exact H2|]. split; [exact H3|].
  split; [exact H4|]. split.
  - apply hsat2_xapply_invar.
  - apply rle_xapply_invar.
Qed.

(* N2 的轨道商形态：解在纤维上定义（主性从解点转移到纤维分解） *)
Theorem noether_N2_fiber : forall fuel cs s l,
  solve4 fuel cs = Some (s, l) ->
  exists f0 s0 t, unify f0 (tyEqs (chanProj ChTy cs)) = Some s0 /\
                 (forall u, tapply s u = tapply t (tapply s0 u)).
Proof.
  intros fuel cs s l H. apply (solve4_fiber fuel cs s l H).
Qed.

(* ================= 三、N3：荷—流对偶 ================= *)

(* 诺特第三定律（机内形态）——双侧： *)

(* N3 荷侧：锥封闭无条件（对任意方程集成立——含 TBorrow 的签名方程在内）。
   E.56 §4.1 把 λ 层签名扩展登记为"锥封闭失效点"——上机（E.61 轮）反驳：
   instance_sound 的证明只依赖 tapply 组合律（tapply_app），
   与方程集是否含 TBorrow 无关。λ 层签名扩展的实效是**快道增强**
   （主解像顶层含 TBorrow ⇒ X 快道提前命中），不是锥封闭破缺。 *)
Theorem noether_N3_cone_unconditional : forall E s t,
  unifies s E -> unifies (s ++ t) E.
Proof.
  intros E s t H. apply instance_sound. exact H.
Qed.

(* N3 条件对称侧：tau_rigid（TBorrow 标签刚性）——τ 合一不产生区域等式
   安排（安排流量零）。其证明依赖 TBorrow 标签为地面 nat 的语法事实——
   区域变量化（W-TYPEX-3 / W-GAT 线）后前提失效，等式安排流回归。
   这是 DPLL(T) 回归触发面的**唯一**成员（双到期面收窄为单边）。 *)
Theorem noether_N3_rigid_conditional : forall fuel E s r1 r2 a b,
  unify fuel ((TBorrow r1 a, TBorrow r2 b) :: E) = Some s -> r1 = r2.
Proof.
  intros fuel E s r1 r2 a b H. apply (tau_rigid fuel E s r1 r2 a b H).
Qed.

(* N3 对偶整合：无条件荷（锥封闭）与条件对称（标签刚性）并列——
   诺特流的回归条件 = 条件对称的失效 = 区域变量化（单边）。 *)
Theorem noether_N3_duality :
  (forall E s t, unifies s E -> unifies (s ++ t) E)
  /\ (forall fuel E s r1 r2 a b,
        unify fuel ((TBorrow r1 a, TBorrow r2 b) :: E) = Some s -> r1 = r2).
Proof.
  split.
  - apply noether_N3_cone_unconditional.
  - apply noether_N3_rigid_conditional.
Qed.

(* ================= 四、对称分类总表（诺特律的账本形态） ================= *)

(* 分类定理：守恒量到对称源的映射——无条件对称组（结构性）与
   条件对称组（语法性）的划分。无条件组：
     锥封闭      instance_sound          证明依赖 tapply_app（组合律）
     单调性      roccurs_tapply_mono     证明依赖 TBorrow 标签不可改写
     已满足不灭  xsat1_app_mono          证明依赖 xapply1 的定义（X 载荷现形）
     盲性组      noether_N2              证明依赖通道分割（chanOf）
   条件组：
     标签刚性    tau_rigid               证明依赖 TBorrow r 的 r : nat（地面） *)
Theorem noether_classification :
  (forall E s t, unifies s E -> unifies (s ++ t) E)
  /\ (forall s r t, roccurs r t = true -> roccurs r (tapply s t) = true)
  /\ (forall fuel E s r1 r2 a b,
        unify fuel ((TBorrow r1 a, TBorrow r2 b) :: E) = Some s -> r1 = r2).
Proof.
  split.
  - apply noether_N3_cone_unconditional.
  - split.
    + intros s r t. apply roccurs_tapply_mono.
    + apply noether_N3_rigid_conditional.
Qed.

(* ===================================================================== *)
(*  效应能力流形 · M3 · M3Fusion：组装完备与联合主性（W-M3-1 清偿）        *)
(*                                                                         *)
(*  W-M3-1（W-M2-1 轮挂账）：通道完备 ⇒ 组装完备（infer 级）。              *)
(*  三组分分解——                                                             *)
(*    (G)  生成侧零泄漏：cg_no_cty ⊕ cgT_phi_nil（M2 已证）——              *)
(*         cg 与 cgT 的通道字母表在生成端不相交，池的分区守恒 chan_partition； *)
(*    (τ)  判定器：unify_complete + unify_mgu（W-M2-1 已清，零公理）；      *)
(*    (φ)  无条件完备：lphi_solve——有限高度 rig 供给零前提最小解。          *)
(*  组装可解性坍缩（assembly_collapse）：联合可解 ⇔ τ 可解。                *)
(*  组装完备（solve2_complete / infer_complete）与                          *)
(*  联合主性（solve2_principal / infer_principal：σ 的项作用外延实例序      *)
(*  × l 的 cle 序——K 定理双极点的乘积）。                                   *)
(*  幽灵现形的融合层守恒（solve2_x_ghost_stable）与 X 谱系                   *)
(*  （solve2_x_principal：主解的 X 读数被一切解继承）。                     *)
(* ===================================================================== *)

Require Import List Lia PeanoNat.
Import ListNotations.
Require Import Mult Cap Syntax CG Tau TyCG Lphi Fusion Mu Xsub.

(* ================= 一、φ 无条件完备与组装坍缩 ================= *)

(* φ 通道的完备性是零前提的：任何池的 φ 投影都有最小解 *)
Theorem phi_unconditional : forall cs,
  exists l, phsat l (chanProj ChPhi cs)
         /\ (forall m, phsat m (chanProj ChPhi cs) -> cle l m).
Proof.
  intros cs. exists (lphi (chanProj ChPhi cs)).
  exact (lphi_solve (chanProj ChPhi cs)).
Qed.

(* 组装可解性坍缩：联合可解 ⇔ τ 可解（φ 侧永不阻塞） *)
Theorem assembly_collapse : forall cs,
  ((exists s, unifies s (tyEqs (chanProj ChTy cs)))
    /\ (exists l, phsat l (chanProj ChPhi cs)))
  <-> (exists s, unifies s (tyEqs (chanProj ChTy cs))).
Proof.
  intros cs. split.
  - intros [H _]. exact H.
  - intros H. split; [exact H|].
    destruct (phi_unconditional cs) as [l [Hl _]]. exists l. exact Hl.
Qed.

(* ================= 二、池级组装完备与联合主性 ================= *)

(* W-M3-1 第一定理（池级）：τ 可解 ⇒ 融合命中 *)
Theorem solve2_complete : forall cs,
  (exists s, unifies s (tyEqs (chanProj ChTy cs))) ->
  exists fuel s, solve2 fuel cs = Some (s, lphi (chanProj ChPhi cs)).
Proof.
  intros cs [s Hs].
  destruct (unify_complete (tyEqs (chanProj ChTy cs)) (ex_intro _ s Hs))
    as [fuel [sigma Hu]].
  exists fuel, sigma. unfold solve2. rewrite Hu. reflexivity.
Qed.

(* W-M3-1 第二定理（池级联合主性）：σ 是 mgu（项作用外延）× l 是 lfp *)
Theorem solve2_principal : forall fuel cs s l,
  solve2 fuel cs = Some (s, l) ->
  (forall s', unifies s' (tyEqs (chanProj ChTy cs)) ->
     exists t, forall u, tapply s' u = tapply t (tapply s u))
  /\ (forall m', phsat m' (chanProj ChPhi cs) -> cle l m').
Proof.
  intros fuel cs s l H. unfold solve2 in H.
  destruct (unify fuel (tyEqs (chanProj ChTy cs))) eqn:Hu.
  - inversion H; subst; clear H. split.
    + intros s' Hs'. exact (unify_mgu fuel _ _ Hu s' Hs').
    + intros m' Hm'.
      exact (proj2 (lphi_solve (chanProj ChPhi cs)) m' Hm').
  - discriminate.
Qed.

(* ================= 三、e 级组装完备与联合主性（W-M3-1 主定理） ================= *)

(* e 级组装完备：cgT 方程可解 ⇒ infer 命中 *)
Theorem infer_complete : forall e,
  (exists s, unifies s (tyEqs (fst (cgT 0 [] e)))) ->
  exists fuel s l, infer fuel e = Some (s, l).
Proof.
  intros e [s Hs]. unfold infer.
  assert (Hp : exists s0,
            unifies s0 (tyEqs (chanProj ChTy (cg e ++ fst (cgT 0 [] e))))).
  { exists s. rewrite chanProj_app, cg_no_cty. simpl.
    rewrite tyEqs_proj. exact Hs. }
  destruct (solve2_complete (cg e ++ fst (cgT 0 [] e)) Hp)
    as [fuel [sigma Hsol]].
  exists fuel, sigma, (lphi (chanProj ChPhi (cg e ++ fst (cgT 0 [] e)))).
  exact Hsol.
Qed.

(* e 级联合主性：J′ 的双通道切片机内化 *)
Theorem infer_principal : forall fuel e s l,
  infer fuel e = Some (s, l) ->
  (forall s', unifies s' (tyEqs (fst (cgT 0 [] e))) ->
     exists t, forall u, tapply s' u = tapply t (tapply s u))
  /\ (forall m', phsat m' (chanProj ChPhi (cg e)) -> cle l m').
Proof.
  intros fuel e s l H. unfold infer in H.
  destruct (solve2_principal fuel (cg e ++ fst (cgT 0 [] e)) s l H)
    as [Hpr Hmin].
  split.
  - intros s' Hs'. apply Hpr.
    rewrite chanProj_app, cg_no_cty. simpl.
    rewrite tyEqs_proj. exact Hs'.
  - intros m' Hm'. apply Hmin.
    rewrite chanProj_app, (cgT_phi_nil e 0 []), app_nil_r. exact Hm'.
Qed.

(* 生成侧分区守恒：组装的 (G) 成分（池在五通道下不增不减） *)
Theorem infer_partition : forall e,
  length (cg e ++ fst (cgT 0 [] e)) =
  length (chanProj ChTy (cg e ++ fst (cgT 0 [] e)))
  + length (chanProj ChR (cg e ++ fst (cgT 0 [] e)))
  + length (chanProj ChPhi (cg e ++ fst (cgT 0 [] e)))
  + length (chanProj ChH (cg e ++ fst (cgT 0 [] e)))
  + length (chanProj ChX (cg e ++ fst (cgT 0 [] e))).
Proof. intros e. apply chan_partition. Qed.

(* ================= 四、幽灵现形的融合层定理 ================= *)

(* 融合层 φ 稳定性：solve2 的 φ 输出对幽灵现形不敏感 *)
Theorem solve2_x_ghost_stable : forall fuel cs s l,
  solve2 fuel cs = Some (s, l) ->
  lphi (chanProj ChPhi (xapply s cs)) = l.
Proof.
  intros fuel cs s l H. unfold solve2 in H.
  destruct (unify fuel (tyEqs (chanProj ChTy cs))) eqn:Hu.
  - inversion H; subst; clear H.
    rewrite lphi_xapply_invar. reflexivity.
  - discriminate.
Qed.

(* X 谱系的融合层定理：主解的 X 读数被一切 τ 解继承 *)
Theorem solve2_x_principal : forall fuel cs s l s',
  solve2 fuel cs = Some (s, l) ->
  unifies s' (tyEqs (chanProj ChTy cs)) ->
  xsat s (chanProj ChX cs) ->
  xsat s' (chanProj ChX cs).
Proof.
  intros fuel cs s l s' H Hu Hx.
  destruct (solve2_principal fuel cs s l H) as [Hpr _].
  destruct (Hpr s' Hu) as [t Ht].
  exact (xsat_principal_mono (chanProj ChX cs) s s' t Ht Hx).
Qed.

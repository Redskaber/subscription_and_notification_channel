(* ===================================================================== *)
(*  CG.v —— CG 引理组（M1 第二部分）：sized recursion 上的约束生成         *)
(*                                                                         *)
(*  引理组：                                                               *)
(*   CG.1 cgf_total   全性：燃料 ≥ 规模 ⇒ 必产出约束集                     *)
(*   CG.2 cgf_stable  稳定性：燃料 ≥ 规模时产出与燃料无关                  *)
(*   CG.3 cg_*        组合性：cg(节点) = cg(子项) ++ 节点种子（同态）      *)
(*   CG.4 cg_size     规模线性：|cg e| ≤ 2·tsize(e)（守恒量 #1）           *)
(*   CG.5 cg_chan_homo_* 分通道同态：每个通道投影也是语法同态              *)
(*   CG.6 chan_partition 五通道分割：约束基数 = 五投影基数之和             *)
(*   CG.7 phi_least_solution / cg_phi_min（φ 桥接主定理）：                *)
(*        φ 通道约束的最小解 = lfp(FC) = Kleene 链极限，                   *)
(*        稳定于 2·|caps|+1 步内（#198/#199）                              *)
(*                                                                         *)
(*  sized recursion 形式（#195，§7）：Rocq 无原生 sized types，            *)
(*  以「燃料参数化 + 稳定性 + 强归纳」编码 —— Abel/Barthe–Grégoire–Riba    *)
(*  sized types 的证明论内核展开。守恒量 #3：燃料-规模差单调不减。         *)
(* ===================================================================== *)

Require Import List Lia PeanoNat.
Import ListNotations.
Require Import Mult Cap Syntax.

(* ---- 节点种子：每构造子的通道标签一览 ---- *)
Definition seeds (e : tm) : list constr :=
  match e with
  | Var _ => []
  | Lam _ _ => []
  | New r => [CLv (CReg r) M1]
  | Borrow r l => [CHr l r; CLv (CLea l) M1]
  | Drop l => [CEnd l]
  | Call _ _ => [CXr 0 (TArrow (TVar 0) (TVar 1)); CPr (CReg 0) (CLea 1) M1]
  | Grant c k _ => [CLv c k]
  | Slice _ => [CLv (CReg 0) M0]
  end.

Lemma seeds_len : forall e, length (seeds e) <= 2.
Proof. destruct e; simpl; lia. Qed.

(* ---- sized recursion 的燃料编码（结构递归于项，燃料随递归递减） ---- *)
Fixpoint cgf (f : nat) (e : tm) {struct e} : option (list constr) :=
  match e with
  | Var _ => Some (seeds e)
  | Lam _ e' =>
      match f with
      | 0 => None
      | S f' => match cgf f' e' with
                | Some cs => Some (cs ++ seeds e)
                | None => None
                end
      end
  | New _ => Some (seeds e)
  | Borrow _ _ => Some (seeds e)
  | Drop _ => Some (seeds e)
  | Call e1 e2 =>
      match f with
      | 0 => None
      | S f' => match cgf f' e1, cgf f' e2 with
                | Some c1, Some c2 => Some (c1 ++ c2 ++ seeds e)
                | _, _ => None
                end
      end
  | Grant _ _ e' =>
      match f with
      | 0 => None
      | S f' => match cgf f' e' with
                | Some cs => Some (cs ++ seeds e)
                | None => None
                end
      end
  | Slice e' =>
      match f with
      | 0 => None
      | S f' => match cgf f' e' with
                | Some cs => Some (cs ++ seeds e)
                | None => None
                end
      end
  end.

(* 主定义：燃料取规模（充分性由 CG.1 证） *)
Definition cg (e : tm) : list constr :=
  match cgf (tsize e) e with
  | Some cs => cs
  | None => []
  end.

(* ---- CG.1 全性 ---- *)
Lemma cgf_total : forall e f, tsize e <= f -> exists cs, cgf f e = Some cs.
Proof.
  induction e as [x | x e IH | r | r l | l | e1 IH1 e2 IH2 | c k e IH | e IH];
    intros f Hf.
  - exists (seeds (Var x)). reflexivity.
  - destruct f as [|f'].
    + exfalso. simpl in Hf. lia.
    + assert (E2 : cgf (S f') (Lam x e) =
              match cgf f' e with Some cs => Some (cs ++ seeds (Lam x e)) | None => None end)
        by reflexivity.
      rewrite E2. destruct (IH f' ltac:(simpl in Hf; lia)) as [cs He].
      rewrite He. exists (cs ++ seeds (Lam x e)). reflexivity.
  - exists (seeds (New r)). reflexivity.
  - exists (seeds (Borrow r l)). reflexivity.
  - exists (seeds (Drop l)). reflexivity.
  - destruct f as [|f'].
    + exfalso. simpl in Hf. lia.
    + assert (E2 : cgf (S f') (Call e1 e2) =
              match cgf f' e1, cgf f' e2 with
              | Some c1, Some c2 => Some (c1 ++ c2 ++ seeds (Call e1 e2))
              | _, _ => None
              end) by reflexivity.
      rewrite E2.
      destruct (IH1 f' ltac:(simpl in Hf; lia)) as [c1 He1].
      destruct (IH2 f' ltac:(simpl in Hf; lia)) as [c2 He2].
      rewrite He1, He2. exists (c1 ++ c2 ++ seeds (Call e1 e2)). reflexivity.
  - destruct f as [|f'].
    + exfalso. simpl in Hf. lia.
    + assert (E2 : cgf (S f') (Grant c k e) =
              match cgf f' e with Some cs => Some (cs ++ seeds (Grant c k e)) | None => None end)
        by reflexivity.
      rewrite E2. destruct (IH f' ltac:(simpl in Hf; lia)) as [cs He].
      rewrite He. exists (cs ++ seeds (Grant c k e)). reflexivity.
  - destruct f as [|f'].
    + exfalso. simpl in Hf. lia.
    + assert (E2 : cgf (S f') (Slice e) =
              match cgf f' e with Some cs => Some (cs ++ seeds (Slice e)) | None => None end)
        by reflexivity.
      rewrite E2. destruct (IH f' ltac:(simpl in Hf; lia)) as [cs He].
      rewrite He. exists (cs ++ seeds (Slice e)). reflexivity.
Qed.

(* ---- CG.2 稳定性：燃料充分时与燃料无关 ---- *)
Lemma cgf_stable : forall e f1 f2, tsize e <= f1 -> f1 <= f2 -> cgf f1 e = cgf f2 e.
Proof.
  induction e as [x | x e IH | r | r l | l | e1 IH1 e2 IH2 | c k e IH | e IH];
    intros f1 f2 H1 H2.
  - reflexivity.
  - destruct f1 as [|g1]; destruct f2 as [|g2].
    + exfalso. simpl in H1. lia.
    + exfalso. simpl in H1. lia.
    + exfalso. simpl in H1. lia.
    + assert (E1 : cgf (S g1) (Lam x e) =
              match cgf g1 e with Some cs => Some (cs ++ seeds (Lam x e)) | None => None end)
        by reflexivity.
      assert (E2 : cgf (S g2) (Lam x e) =
              match cgf g2 e with Some cs => Some (cs ++ seeds (Lam x e)) | None => None end)
        by reflexivity.
      rewrite E1, E2.
      rewrite (IH g1 g2 ltac:(simpl in H1; lia) ltac:(lia)). reflexivity.
  - reflexivity.
  - reflexivity.
  - reflexivity.
  - destruct f1 as [|g1]; destruct f2 as [|g2].
    + exfalso. simpl in H1. lia.
    + exfalso. simpl in H1. lia.
    + exfalso. simpl in H1. lia.
    + assert (E1 : cgf (S g1) (Call e1 e2) =
              match cgf g1 e1, cgf g1 e2 with
              | Some c1, Some c2 => Some (c1 ++ c2 ++ seeds (Call e1 e2))
              | _, _ => None
              end) by reflexivity.
      assert (E2 : cgf (S g2) (Call e1 e2) =
              match cgf g2 e1, cgf g2 e2 with
              | Some c1, Some c2 => Some (c1 ++ c2 ++ seeds (Call e1 e2))
              | _, _ => None
              end) by reflexivity.
      rewrite E1, E2.
      rewrite (IH1 g1 g2 ltac:(simpl in H1; lia) ltac:(lia)).
      rewrite (IH2 g1 g2 ltac:(simpl in H1; lia) ltac:(lia)). reflexivity.
  - destruct f1 as [|g1]; destruct f2 as [|g2].
    + exfalso. simpl in H1. lia.
    + exfalso. simpl in H1. lia.
    + exfalso. simpl in H1. lia.
    + assert (E1 : cgf (S g1) (Grant c k e) =
              match cgf g1 e with Some cs => Some (cs ++ seeds (Grant c k e)) | None => None end)
        by reflexivity.
      assert (E2 : cgf (S g2) (Grant c k e) =
              match cgf g2 e with Some cs => Some (cs ++ seeds (Grant c k e)) | None => None end)
        by reflexivity.
      rewrite E1, E2.
      rewrite (IH g1 g2 ltac:(simpl in H1; lia) ltac:(lia)). reflexivity.
  - destruct f1 as [|g1]; destruct f2 as [|g2].
    + exfalso. simpl in H1. lia.
    + exfalso. simpl in H1. lia.
    + exfalso. simpl in H1. lia.
    + assert (E1 : cgf (S g1) (Slice e) =
              match cgf g1 e with Some cs => Some (cs ++ seeds (Slice e)) | None => None end)
        by reflexivity.
      assert (E2 : cgf (S g2) (Slice e) =
              match cgf g2 e with Some cs => Some (cs ++ seeds (Slice e)) | None => None end)
        by reflexivity.
      rewrite E1, E2.
      rewrite (IH g1 g2 ltac:(simpl in H1; lia) ltac:(lia)). reflexivity.
Qed.

Lemma cgf_size_eq : forall e, cgf (tsize e) e = Some (cg e).
Proof.
  intros e. unfold cg. destruct (cgf (tsize e) e) eqn:E.
  - reflexivity.
  - exfalso. destruct (cgf_total e (tsize e) (Nat.le_refl _)) as [cs Hcs].
    rewrite Hcs in E. discriminate.
Qed.

Lemma cgf_fuel_ge : forall e f, tsize e <= f -> cgf f e = Some (cg e).
Proof.
  intros e f H.
  rewrite <- (cgf_stable e (tsize e) f (Nat.le_refl _) H). apply cgf_size_eq.
Qed.

Theorem cg_total : forall e, exists cs, cgf (tsize e) e = Some cs /\ cg e = cs.
Proof.
  intros e. destruct (cgf_total e (tsize e) (Nat.le_refl _)) as [cs Hcs].
  exists cs. split; [exact Hcs |]. unfold cg. rewrite Hcs. reflexivity.
Qed.

(* ---- CG.3 组合性：逐构造子同态 ---- *)
Lemma cg_var : forall x, cg (Var x) = seeds (Var x).
Proof. intros; reflexivity. Qed.
Lemma cg_new : forall r, cg (New r) = seeds (New r).
Proof. intros; reflexivity. Qed.
Lemma cg_borrow : forall r l, cg (Borrow r l) = seeds (Borrow r l).
Proof. intros; reflexivity. Qed.
Lemma cg_drop : forall l, cg (Drop l) = seeds (Drop l).
Proof. intros; reflexivity. Qed.

Lemma cg_lam : forall x e, cg (Lam x e) = cg e ++ seeds (Lam x e).
Proof.
  intros x e.
  assert (E1 : cg (Lam x e) =
           match cgf (S (tsize e)) (Lam x e) with Some cs => cs | None => [] end)
    by reflexivity.
  assert (E2 : cgf (S (tsize e)) (Lam x e) =
           match cgf (tsize e) e with
           | Some cs => Some (cs ++ seeds (Lam x e)) | None => None end)
    by reflexivity.
  assert (E3 : cgf (tsize e) e = Some (cg e)) by (apply cgf_size_eq).
  rewrite E1, E2, E3. reflexivity.
Qed.

Lemma cg_call : forall e1 e2, cg (Call e1 e2) = cg e1 ++ cg e2 ++ seeds (Call e1 e2).
Proof.
  intros e1 e2.
  assert (E1 : cg (Call e1 e2) =
           match cgf (S (tsize e1 + tsize e2)) (Call e1 e2) with
           | Some cs => cs | None => [] end)
    by reflexivity.
  assert (E2 : cgf (S (tsize e1 + tsize e2)) (Call e1 e2) =
           match cgf (tsize e1 + tsize e2) e1, cgf (tsize e1 + tsize e2) e2 with
           | Some c1, Some c2 => Some (c1 ++ c2 ++ seeds (Call e1 e2))
           | _, _ => None
           end) by reflexivity.
  assert (E3 : cgf (tsize e1 + tsize e2) e1 = Some (cg e1))
    by (apply cgf_fuel_ge; lia).
  assert (E4 : cgf (tsize e1 + tsize e2) e2 = Some (cg e2))
    by (apply cgf_fuel_ge; lia).
  rewrite E1, E2, E3, E4. reflexivity.
Qed.

Lemma cg_grant : forall c k e, cg (Grant c k e) = cg e ++ seeds (Grant c k e).
Proof.
  intros c k e.
  assert (E1 : cg (Grant c k e) =
           match cgf (S (tsize e)) (Grant c k e) with Some cs => cs | None => [] end)
    by reflexivity.
  assert (E2 : cgf (S (tsize e)) (Grant c k e) =
           match cgf (tsize e) e with
           | Some cs => Some (cs ++ seeds (Grant c k e)) | None => None end)
    by reflexivity.
  assert (E3 : cgf (tsize e) e = Some (cg e)) by (apply cgf_size_eq).
  rewrite E1, E2, E3. reflexivity.
Qed.

Lemma cg_slice : forall e, cg (Slice e) = cg e ++ seeds (Slice e).
Proof.
  intros e.
  assert (E1 : cg (Slice e) =
           match cgf (S (tsize e)) (Slice e) with Some cs => cs | None => [] end)
    by reflexivity.
  assert (E2 : cgf (S (tsize e)) (Slice e) =
           match cgf (tsize e) e with
           | Some cs => Some (cs ++ seeds (Slice e)) | None => None end)
    by reflexivity.
  assert (E3 : cgf (tsize e) e = Some (cg e)) by (apply cgf_size_eq).
  rewrite E1, E2, E3. reflexivity.
Qed.

(* ---- CG.4 规模线性：|cg e| ≤ 2·tsize(e)（守恒量 #1） ---- *)
Lemma len_app : forall (A : Type) (l1 l2 : list A),
  length (l1 ++ l2) = length l1 + length l2.
Proof.
  induction l1 as [|a l1 IH]; intros l2; simpl.
  - reflexivity.
  - rewrite IH. lia.
Qed.

Lemma cgf_len : forall e f cs, cgf f e = Some cs -> length cs <= 2 * tsize e.
Proof.
  induction e as [x | x e IH | r | r l | l | e1 IH1 e2 IH2 | c k e IH | e IH];
    intros f cs H.
  - simpl in H. injection H as Hcs. subst cs. simpl. lia.
  - destruct f as [|f'].
    + simpl in H. discriminate.
    + assert (E2 : cgf (S f') (Lam x e) =
              match cgf f' e with
              | Some cs' => Some (cs' ++ seeds (Lam x e)) | None => None end)
        by reflexivity.
      rewrite E2 in H. destruct (cgf f' e) as [cs'|] eqn:E; [|discriminate].
      injection H as Hcs. subst cs.
      rewrite len_app. simpl.
      pose proof (IH f' cs' E) as IH'. lia.
  - simpl in H. injection H as Hcs. subst cs. simpl. lia.
  - simpl in H. injection H as Hcs. subst cs. simpl. lia.
  - simpl in H. injection H as Hcs. subst cs. simpl. lia.
  - destruct f as [|f'].
    + simpl in H. discriminate.
    + assert (E2 : cgf (S f') (Call e1 e2) =
              match cgf f' e1, cgf f' e2 with
              | Some c1, Some c2 => Some (c1 ++ c2 ++ seeds (Call e1 e2))
              | _, _ => None
              end) by reflexivity.
      rewrite E2 in H.
      destruct (cgf f' e1) as [c1|] eqn:E1; destruct (cgf f' e2) as [c2|] eqn:E2b;
        try discriminate.
      injection H as Hcs. subst cs.
      rewrite !len_app. simpl.
      pose proof (IH1 f' c1 E1) as Ha. pose proof (IH2 f' c2 E2b) as Hb. lia.
  - destruct f as [|f'].
    + simpl in H. discriminate.
    + assert (E2 : cgf (S f') (Grant c k e) =
              match cgf f' e with
              | Some cs' => Some (cs' ++ seeds (Grant c k e)) | None => None end)
        by reflexivity.
      rewrite E2 in H. destruct (cgf f' e) as [cs'|] eqn:E; [|discriminate].
      injection H as Hcs. subst cs.
      rewrite len_app. simpl.
      pose proof (IH f' cs' E) as IH'. lia.
  - destruct f as [|f'].
    + simpl in H. discriminate.
    + assert (E2 : cgf (S f') (Slice e) =
              match cgf f' e with
              | Some cs' => Some (cs' ++ seeds (Slice e)) | None => None end)
        by reflexivity.
      rewrite E2 in H. destruct (cgf f' e) as [cs'|] eqn:E; [|discriminate].
      injection H as Hcs. subst cs.
      rewrite len_app. simpl.
      pose proof (IH f' cs' E) as IH'. lia.
Qed.

Theorem cg_size : forall e, length (cg e) <= 2 * tsize e.
Proof. intros e. apply (cgf_len e (tsize e) (cg e)). apply cgf_size_eq. Qed.

(* ---- CG.5 分通道同态 + CG.6 五通道分割 ---- *)
Lemma filter_app_m : forall (A : Type) (f : A -> bool) (l1 l2 : list A),
  filter f (l1 ++ l2) = filter f l1 ++ filter f l2.
Proof.
  induction l1 as [|a l1 IH]; intros l2; simpl.
  - reflexivity.
  - rewrite IH. destruct (f a); simpl; reflexivity.
Qed.

Lemma chanProj_app : forall ch l1 l2,
  chanProj ch (l1 ++ l2) = chanProj ch l1 ++ chanProj ch l2.
Proof. intros; apply filter_app_m. Qed.

Lemma cg_chan_homo_lam : forall ch x e,
  chanProj ch (cg (Lam x e)) = chanProj ch (cg e) ++ chanProj ch (seeds (Lam x e)).
Proof. intros; rewrite cg_lam; apply chanProj_app. Qed.

Lemma cg_chan_homo_call : forall ch e1 e2,
  chanProj ch (cg (Call e1 e2))
  = chanProj ch (cg e1) ++ chanProj ch (cg e2) ++ chanProj ch (seeds (Call e1 e2)).
Proof. intros; rewrite cg_call, !chanProj_app; reflexivity. Qed.

Lemma cg_chan_homo_grant : forall ch c k e,
  chanProj ch (cg (Grant c k e)) = chanProj ch (cg e) ++ chanProj ch (seeds (Grant c k e)).
Proof. intros; rewrite cg_grant; apply chanProj_app. Qed.

Lemma cg_chan_homo_slice : forall ch e,
  chanProj ch (cg (Slice e)) = chanProj ch (cg e) ++ chanProj ch (seeds (Slice e)).
Proof. intros; rewrite cg_slice; apply chanProj_app. Qed.

Theorem chan_partition : forall cs,
  length cs = length (chanProj ChTy cs) + length (chanProj ChR cs)
             + length (chanProj ChPhi cs) + length (chanProj ChH cs)
             + length (chanProj ChX cs).
Proof.
  induction cs as [|c cs IH]; [reflexivity|].
  destruct c as [a b | r1 r2 | c0 k | c c' w | l r | l | r t];
    unfold chanProj in *; simpl in *; lia.
Qed.

(* ---- φ 通道的 FC 算子与 lfp 桥接（CG.7） ---- *)

Definition capsOfC (c : constr) : list capidx :=
  match c with
  | CLv c' _ => [c']
  | CPr c1 c2 _ => [c1; c2]
  | _ => []
  end.

Definition capsOf (cs : list constr) : list capidx := concat (map capsOfC cs).

Lemma capsOf_cons : forall c1 cs, capsOf (c1 :: cs) = capsOfC c1 ++ capsOf cs.
Proof. reflexivity. Qed.

Definition phContrib (c0 : constr) (i : capidx) (m : cmap) : mult :=
  match c0 with
  | CLv c k => if cap_eq_dec c i then k else M0
  | CPr c c' w => if cap_eq_dec c i then mplus (m c') w else M0
  | _ => M0
  end.

Definition FC (cs : list constr) (m : cmap) (i : capidx) : mult :=
  fold_right (fun c0 acc => mlub (phContrib c0 i m) acc) M0 cs.

Lemma FC_cons : forall c1 cs m i,
  FC (c1 :: cs) m i = mlub (phContrib c1 i m) (FC cs m i).
Proof. reflexivity. Qed.

Lemma phContrib_mono : forall c0 i a b, cle a b -> mle (phContrib c0 i a) (phContrib c0 i b).
Proof.
  intros c0 i a b Hab. destruct c0 as [x y | r1 r2 | c k | c c' w | l r | l | r t].
  - apply mle_refl.
  - apply mle_refl.
  - unfold phContrib. destruct (cap_eq_dec c i); [apply mle_refl | apply mle_M0].
  - unfold phContrib. destruct (cap_eq_dec c i).
    + apply mplus_mono. apply Hab.
    + apply mle_M0.
  - apply mle_refl.
  - apply mle_refl.
  - apply mle_refl.
Qed.

Lemma FC_mono : forall cs a b, cle a b -> cle (FC cs a) (FC cs b).
Proof.
  intros cs a b Hab i. induction cs as [|c1 cs' IH].
  - unfold FC, mle; simpl; lia.
  - rewrite !FC_cons. apply mlub_mono; [apply phContrib_mono; exact Hab | apply IH].
Qed.

Lemma FC_ext : forall cs a b, (forall c, a c = b c) -> forall i, FC cs a i = FC cs b i.
Proof.
  intros cs a b Hab i. induction cs as [|c1 cs' IH].
  - reflexivity.
  - rewrite !FC_cons. destruct c1 as [x y | r1 r2 | c k | c c' w | l r | l | r t].
    + rewrite IH. reflexivity.
    + rewrite IH. reflexivity.
    + unfold phContrib. destruct (cap_eq_dec c i); rewrite IH; reflexivity.
    + unfold phContrib. destruct (cap_eq_dec c i).
      * rewrite (Hab c'). rewrite (IH). reflexivity.
      * rewrite (IH). reflexivity.
    + rewrite IH. reflexivity.
    + rewrite IH. reflexivity.
    + rewrite IH. reflexivity.
Qed.

Lemma FC_out : forall cs m i, ~ In i (capsOf cs) -> FC cs m i = M0.
Proof.
  induction cs as [|c1 cs' IH]; intros m i Hi.
  - reflexivity.
  - rewrite FC_cons. rewrite capsOf_cons in Hi.
    assert (Hc : phContrib c1 i m = M0).
    { destruct c1 as [x y | r1 r2 | c k | c c' w | l r | l | r t]; try reflexivity.
      - unfold phContrib. destruct (cap_eq_dec c i) as [He | Hne].
        + exfalso. apply Hi. apply in_or_app. left. simpl. left. exact He.
        + reflexivity.
      - unfold phContrib. destruct (cap_eq_dec c i) as [He | Hne].
        + exfalso. apply Hi. apply in_or_app. left. simpl. left. exact He.
        + reflexivity. }
    rewrite Hc, mlub_M0_l. apply IH. intro Hin. apply Hi.
    apply in_or_app. right. exact Hin.
Qed.

(* φ 通道满足关系 *)
Fixpoint phsat (m : cmap) (cs : list constr) : Prop :=
  match cs with
  | [] => True
  | CLv c k :: cs' => mle k (m c) /\ phsat m cs'
  | CPr c c' w :: cs' => mle (mplus (m c') w) (m c) /\ phsat m cs'
  | _ :: cs' => phsat m cs'
  end.

Lemma fold_lub_le : forall cs m i,
  (forall c0, In c0 cs -> mle (phContrib c0 i m) (m i)) -> mle (FC cs m i) (m i).
Proof.
  induction cs as [|c1 cs' IH]; intros m i Hh.
  - unfold FC, mle; simpl; lia.
  - rewrite FC_cons. apply mlub_least.
    + apply Hh. left. reflexivity.
    + apply IH. intros c0 Hc0. apply Hh. right. exact Hc0.
Qed.

Lemma phC_CTy : forall x y i m, phContrib (CTy x y) i m = M0. Proof. reflexivity. Qed.
Lemma phC_CRg : forall r1 r2 i m, phContrib (CRg r1 r2) i m = M0. Proof. reflexivity. Qed.
Lemma phC_CHr : forall l r i m, phContrib (CHr l r) i m = M0. Proof. reflexivity. Qed.
Lemma phC_CEnd : forall l i m, phContrib (CEnd l) i m = M0. Proof. reflexivity. Qed.
Lemma phC_CXr : forall r t i m, phContrib (CXr r t) i m = M0. Proof. reflexivity. Qed.

Theorem phsat_to_postfix : forall cs m, phsat m cs -> cle (FC cs m) m.
Proof.
  induction cs as [|c1 cs' IH]; intros m Hsat.
  - intros i. unfold FC, mle; simpl; lia.
  - destruct c1 as [a b | r1 r2 | c k | c c' w | l r | l | r t]; simpl in Hsat.
    + intros i. rewrite FC_cons, phC_CTy, mlub_M0_l. apply (IH m Hsat i).
    + intros i. rewrite FC_cons, phC_CRg, mlub_M0_l. apply (IH m Hsat i).
    + intros i. rewrite FC_cons. unfold phContrib. destruct (cap_eq_dec c i) as [He | Hne].
      * apply mlub_least.
        -- destruct Hsat as [H1 _]. rewrite He in H1. exact H1.
        -- apply IH. destruct Hsat as [_ H2]. exact H2.
      * apply mlub_least; [apply mle_M0 | apply IH; destruct Hsat as [_ H2]; exact H2].
    + intros i. rewrite FC_cons. unfold phContrib. destruct (cap_eq_dec c i) as [He | Hne].
      * apply mlub_least.
        -- destruct Hsat as [H1 _]. rewrite He in H1. exact H1.
        -- apply IH. destruct Hsat as [_ H2]. exact H2.
      * apply mlub_least; [apply mle_M0 | apply IH; destruct Hsat as [_ H2]; exact H2].
    + intros i. rewrite FC_cons, phC_CHr, mlub_M0_l. apply (IH m Hsat i).
    + intros i. rewrite FC_cons, phC_CEnd, mlub_M0_l. apply (IH m Hsat i).
    + intros i. rewrite FC_cons, phC_CXr, mlub_M0_l. apply (IH m Hsat i).
Qed.

Lemma contrib_le_FC : forall cs m c0 i, In c0 cs -> mle (phContrib c0 i m) (FC cs m i).
Proof.
  induction cs as [|c1 cs' IH]; intros m c0 i Hin.
  - contradiction.
  - rewrite FC_cons. simpl in Hin. destruct Hin as [Heq | Hin'].
    + rewrite Heq. apply mlub_le_l.
    + apply mle_trans with (FC cs' m i); [apply IH; exact Hin' | apply mlub_le_r].
Qed.

Theorem postfix_to_phsat : forall cs m, cle (FC cs m) m -> phsat m cs.
Proof.
  induction cs as [|c1 cs' IH]; intros m H.
  - exact I.
  - assert (Htail : cle (FC cs' m) m).
    { intros i. apply (mle_trans (FC cs' m i) (FC (c1 :: cs') m i) (m i)).
      - rewrite FC_cons. apply mlub_le_r.
      - apply H. }
    assert (Hge : forall i, mle (phContrib c1 i m) (FC (c1 :: cs') m i))
      by (intros i; apply (contrib_le_FC (c1 :: cs') m c1 i); left; reflexivity).
    destruct c1 as [a b | r1 r2 | c k | c c' w | l r | l | r t]; simpl.
    + apply IH. exact Htail.
    + apply IH. exact Htail.
    + split.
      * specialize (Hge c).
        assert (Hc : phContrib (CLv c k) c m = k)
          by (unfold phContrib; destruct (cap_eq_dec c c) as [He | Hne];
              [reflexivity | exfalso; apply Hne; reflexivity]).
        rewrite Hc in Hge. apply (mle_trans _ (FC (CLv c k :: cs') m c));
          [exact Hge | apply H].
      * apply IH. exact Htail.
    + split.
      * specialize (Hge c).
        assert (Hc : phContrib (CPr c c' w) c m = mplus (m c') w)
          by (unfold phContrib; destruct (cap_eq_dec c c) as [He | Hne];
              [reflexivity | exfalso; apply Hne; reflexivity]).
        rewrite Hc in Hge. apply (mle_trans _ (FC (CPr c c' w :: cs') m c));
          [exact Hge | apply H].
      * apply IH. exact Htail.
    + apply IH. exact Htail.
    + apply IH. exact Htail.
    + apply IH. exact Htail.
Qed.

(* Kleene 算子实例化 *)
Definition FCop (cs : list constr) : kleene_op :=
  KleeneOp (FC cs) (FC_mono cs) (FC_ext cs).

Lemma kop_FC : forall cs m c, kop (FCop cs) m c = FC cs m c.
Proof. reflexivity. Qed.

Lemma FC_out' : forall cs m c, ~ In c (capsOf cs) -> kop (FCop cs) m c = M0.
Proof. intros. exact (FC_out cs m c H). Qed.

(* ================= 桥接主定理 ================= *)
(* φ 通道约束集的最小解 = lfp(FC) = Kleene 链极限，稳定于 2·|caps|+1 步内 *)
Theorem phi_least_solution : forall cs,
  exists l, phsat l cs
         /\ (forall m, phsat m cs -> cle l m)
         /\ (exists N, N <= 2 * length (capsOf cs) + 1
                    /\ forall c, l c = iter (FCop cs) N c).
Proof.
  intros cs.
  destruct (kleene_lfp (FCop cs) (capsOf cs) (FC_out' cs))
    as [l [Hfix [Hleast [N [HN Hchain]]]]].
  exists l. split; [| split].
  - apply (postfix_to_phsat cs l).
    intros c. rewrite <- kop_FC, <- (Hfix c). apply mle_refl.
  - intros m Hm. apply Hleast. apply (phsat_to_postfix cs m). exact Hm.
  - exists N. split; [exact HN | intros c; apply Hchain].
Qed.

(* e 层面的特化：CG 生成的 φ 通道约束的最小解 = Kleene 极限 *)
Theorem cg_phi_min : forall e,
  exists l, phsat l (chanProj ChPhi (cg e))
         /\ (forall m, phsat m (chanProj ChPhi (cg e)) -> cle l m)
         /\ (exists N, N <= 2 * length (capsOf (chanProj ChPhi (cg e))) + 1
                    /\ forall c, l c = iter (FCop (chanProj ChPhi (cg e))) N c).
Proof. intros e. apply phi_least_solution. Qed.

(* ===================================================================== *)
(*  效应能力流形 · W-M2-1 · Lτ MM 合一的最一般性（mgu）                     *)
(*                                                                         *)
(*  贡献 #214–#217 · 锚 E.41–E.42（Paulson 1985 LCF 验证先例；             *)
(*  Baader–Nipkow 1998 §4.6 教材路线；Baader–Snyder 2001 单步分解）。      *)
(*                                                                         *)
(*  unify_mgu：unify fuel E = Some s ⇒ s 是 E 的最一般合一器——             *)
(*  任意合一器 s' 都是 s 经某代换 t 的实例（项作用意义）：                  *)
(*    ∃t. ∀u. tapply s' u = tapply t (tapply s u)。                         *)
(*                                                                         *)
(*  证明的三个部件：                                                       *)
(*    M1. unify 的域/值纪律（隐式不变量显式化）：unify 返回的代换，        *)
(*        其绑定域与绑定值变量都不超出方程变量集；                         *)
(*    M2. "消步后 x 绝迹"（M1 + eqs_vars_elim_nox）：s0 不再触碰被消变量   *)
(*        ——这是 head-first 语义下 mgu 构造 τ' = (x, σ'x)::τ 的前提；      *)
(*    M3. 单步分解引理 mgu_elim（对 u 结构归纳）+ 主定理九宫格             *)
(*        （删/定向/分解步 s 不变——mgu 直接继承；消步扩展 s——mgu_elim）。  *)
(* ===================================================================== *)

Require Import List Lia PeanoNat.
Import ListNotations.
Require Import Syntax Tau.

(* ---- M0. 方程变量集的单调引理组（unify_dom_range 的九宫格耗材） ---- *)

Lemma eqs_vars_cons_mono : forall a b E,
  incl (eqs_vars E) (eqs_vars ((a, b) :: E)).
Proof.
  intros a b E v Hv. apply in_eqs_vars_cons. right. right. exact Hv.
Qed.

Lemma eqs_vars_dec_arrow : forall a1 a2 b1 b2 E,
  incl (eqs_vars ((a1, b1) :: (a2, b2) :: E))
       (eqs_vars ((TArrow a1 a2, TArrow b1 b2) :: E)).
Proof.
  intros a1 a2 b1 b2 E v Hv.
  destruct (eqs_vars_cons_inv _ _ _ _ Hv) as [H1 | [H1 | H1]].
  - apply in_eqs_vars_cons. left. simpl. apply in_or_app. left. exact H1.
  - apply in_eqs_vars_cons. right. left. simpl. apply in_or_app. left. exact H1.
  - destruct (eqs_vars_cons_inv _ _ _ _ H1) as [H2 | [H2 | H2]].
    + apply in_eqs_vars_cons. left. simpl. apply in_or_app. right. exact H2.
    + apply in_eqs_vars_cons. right. left. simpl. apply in_or_app. right. exact H2.
    + apply in_eqs_vars_cons. right. right. exact H2.
Qed.

Lemma eqs_vars_dec_borrow : forall r a b E,
  incl (eqs_vars ((a, b) :: E)) (eqs_vars ((TBorrow r a, TBorrow r b) :: E)).
Proof.
  intros r a b E v Hv.
  destruct (eqs_vars_cons_inv _ _ _ _ Hv) as [H1 | [H1 | H1]].
  - apply in_eqs_vars_cons. left. simpl. exact H1.
  - apply in_eqs_vars_cons. right. left. simpl. exact H1.
  - apply in_eqs_vars_cons. right. right. exact H1.
Qed.

Lemma eqs_vars_head_l : forall x t E, In x (eqs_vars ((TVar x, t) :: E)).
Proof.
  intros x t E. apply in_eqs_vars_cons. left. apply in_eq.
Qed.

Lemma eqs_vars_head_r : forall x t E,
  incl (tvars t) (eqs_vars ((TVar x, t) :: E)).
Proof.
  intros x t E w Hw. apply in_eqs_vars_cons. right. left. exact Hw.
Qed.

(* ---- M1. unify 的域/值纪律：绑定域 ⊆ 方程变量集，绑定值变量 ⊆ 方程变量集 ---- *)

Lemma unify_dom_range : forall fuel E s, unify fuel E = Some s ->
  forall x t, In (x, t) s ->
    In x (eqs_vars E) /\ incl (tvars t) (eqs_vars E).
Proof.
  induction fuel as [|n IH]; intros E s Hu x0 t0 Hxt.
  - destruct E as [|[u v] E']; simpl in Hu.
    + injection Hu as Hs. subst s. simpl in Hxt. contradiction.
    + discriminate Hu.
  - destruct E as [|[u v] E']; simpl in Hu.
    + injection Hu as Hs. subst s. simpl in Hxt. contradiction.
    + (* 九宫格 *)
      destruct u as [x | a1 a2 | r a]; destruct v as [y | b1 b2 | r' b].
      * (* TVar x, TVar y *)
        destruct (Nat.eqb x y) eqn:Eeq.
        -- (* 删步 *)
           destruct (IH E' s Hu x0 t0 Hxt) as [H1 H2]. split.
           ++ apply in_eqs_vars_cons. right. right. exact H1.
           ++ intros w Hw. apply in_eqs_vars_cons. right. right. apply H2. exact Hw.
        -- (* 消步 x ↦ TVar y *)
           assert (Ho : occursb x (TVar y) = false).
           { unfold occursb. simpl. rewrite Eeq. reflexivity. }
           destruct (unify n (map (spair x (TVar y)) E')) as [s1|] eqn:Hun.
           ++ inversion Hu; subst; clear Hu. simpl in Hxt.
              destruct Hxt as [Hxt | Hxt].
              ** (* 头绑定 *)
                 injection Hxt as Hx0 Ht0. subst x0. subst t0. split.
                 --- apply eqs_vars_head_l.
                 --- intros w Hw. apply eqs_vars_head_r. exact Hw.
              ** (* 尾绑定 *)
                 destruct (IH _ s1 Hun x0 t0 Hxt) as [H1 H2]. split.
                 --- exact (eqs_vars_elim x (TVar y) E' Ho x0 H1).
                 --- intros w Hw. apply (eqs_vars_elim x (TVar y) E' Ho).
                    apply H2. exact Hw.
           ++ discriminate Hu.
      * (* TVar x, TArrow b1 b2 *)
        destruct (occursb x (TArrow b1 b2)) eqn:Ho.
        -- discriminate Hu.
        -- destruct (unify n (map (spair x (TArrow b1 b2)) E')) as [s1|] eqn:Hun.
           ++ inversion Hu; subst; clear Hu. simpl in Hxt.
              destruct Hxt as [Hxt | Hxt].
              ** injection Hxt as Hx0 Ht0. subst x0. subst t0. split.
                 --- apply eqs_vars_head_l.
                 --- intros w Hw. apply eqs_vars_head_r. exact Hw.
              ** destruct (IH _ s1 Hun x0 t0 Hxt) as [H1 H2]. split.
                 --- exact (eqs_vars_elim x (TArrow b1 b2) E' Ho x0 H1).
                 --- intros w Hw. apply (eqs_vars_elim x (TArrow b1 b2) E' Ho).
                    apply H2. exact Hw.
           ++ discriminate Hu.
      * (* TVar x, TBorrow r' b *)
        destruct (occursb x (TBorrow r' b)) eqn:Ho.
        -- discriminate Hu.
        -- destruct (unify n (map (spair x (TBorrow r' b)) E')) as [s1|] eqn:Hun.
           ++ inversion Hu; subst; clear Hu. simpl in Hxt.
              destruct Hxt as [Hxt | Hxt].
              ** injection Hxt as Hx0 Ht0. subst x0. subst t0. split.
                 --- apply eqs_vars_head_l.
                 --- intros w Hw. apply eqs_vars_head_r. exact Hw.
              ** destruct (IH _ s1 Hun x0 t0 Hxt) as [H1 H2]. split.
                 --- exact (eqs_vars_elim x (TBorrow r' b) E' Ho x0 H1).
                 --- intros w Hw. apply (eqs_vars_elim x (TBorrow r' b) E' Ho).
                    apply H2. exact Hw.
           ++ discriminate Hu.
      * (* TArrow a1 a2, TVar y：定向 *)
        destruct (IH _ s Hu x0 t0 Hxt) as [H1 H2]. split.
        -- apply (incl_swap (TVar y) (TArrow a1 a2) E'). exact H1.
        -- intros w Hw. apply (incl_swap (TVar y) (TArrow a1 a2) E').
           apply H2. exact Hw.
      * (* TArrow, TArrow：分解 *)
        destruct (IH _ s Hu x0 t0 Hxt) as [H1 H2]. split.
        -- apply (eqs_vars_dec_arrow a1 a2 b1 b2 E'). exact H1.
        -- intros w Hw. apply (eqs_vars_dec_arrow a1 a2 b1 b2 E').
           apply H2. exact Hw.
      * (* TArrow, TBorrow：冲突 *)
        discriminate Hu.
      * (* TBorrow r a, TVar y：定向 *)
        destruct (IH _ s Hu x0 t0 Hxt) as [H1 H2]. split.
        -- apply (incl_swap (TVar y) (TBorrow r a) E'). exact H1.
        -- intros w Hw. apply (incl_swap (TVar y) (TBorrow r a) E').
           apply H2. exact Hw.
      * (* TBorrow, TArrow：冲突 *)
        discriminate Hu.
      * (* TBorrow r a, TBorrow r' b *)
        destruct (Nat.eqb r r') eqn:Er.
        -- apply Nat.eqb_eq in Er. subst r'.
           destruct (IH _ s Hu x0 t0 Hxt) as [H1 H2]. split.
           ++ apply (eqs_vars_dec_borrow r a b E'). exact H1.
           ++ intros w Hw. apply (eqs_vars_dec_borrow r a b E').
              apply H2. exact Hw.
        -- discriminate Hu.
Qed.

(* ---- M2. "消步后 x 绝迹"：s0 的绑定不触被消变量 ---- *)

Lemma unify_no_x : forall n E x s,
  unify n E = Some s -> ~ In x (eqs_vars E) ->
  forall y w, In (y, w) s -> y <> x /\ ~ In x (tvars w).
Proof.
  intros n E x s Hu Hx y w Hyw.
  destruct (unify_dom_range n E s Hu y w Hyw) as [Hy Hw].
  split.
  - intros Heq. apply Hx. rewrite Heq in Hy. exact Hy.
  - intros Hin. apply Hx. apply Hw. exact Hin.
Qed.

(* ---- M2b. 代换应用的变量传播（x 不进入） ---- *)

Lemma tsubst1_vars_other : forall y w u x,
  y <> x -> ~ In x (tvars w) -> ~ In x (tvars u) ->
  ~ In x (tvars (tsubst1 y w u)).
Proof.
  intros y w u x Hyx Hw. induction u as [m | a IHa b IHb | r a]; intros Hu.
  - simpl. destruct (Nat.eqb m y) eqn:E.
    + exact Hw.
    + simpl. intros [Heq | []]. apply Hu. left. exact Heq.
  - simpl. intros Hin. apply in_app_or in Hin. destruct Hin as [Ha | Hb].
    + apply (IHa (fun H => Hu (in_or_app _ _ _ (or_introl H)))). exact Ha.
    + apply (IHb (fun H => Hu (in_or_app _ _ _ (or_intror H)))). exact Hb.
  - simpl. intros Hin. apply (IHa (fun H => Hu H)). exact Hin.
Qed.

Lemma tapply_no_x : forall s x,
  (forall y w, In (y, w) s -> y <> x /\ ~ In x (tvars w)) ->
  forall u, ~ In x (tvars u) -> ~ In x (tvars (tapply s u)).
Proof.
  induction s as [|[y0 w0] s IH]; intros x Hs u Hu Hin.
  - simpl in Hin. exact (Hu Hin).
  - simpl in Hin.
    assert (Hno : ~ In x (tvars (tsubst1 y0 w0 u))).
    { apply (tsubst1_vars_other y0 w0 u x).
      - destruct (Hs y0 w0 (or_introl eq_refl)) as [Hyx _]. exact Hyx.
      - destruct (Hs y0 w0 (or_introl eq_refl)) as [_ Hw0]. exact Hw0.
      - exact Hu. }
    exact (IH x (fun y w H => Hs y w (or_intror H))
                (tsubst1 y0 w0 u) Hno Hin).
Qed.

(* ---- M3. 消步的 mgu 单步分解（核心引理） ---- *)

Lemma tsubst1_arrow : forall x w a b,
  tsubst1 x w (TArrow a b) = TArrow (tsubst1 x w a) (tsubst1 x w b).
Proof. reflexivity. Qed.

Lemma tsubst1_borrow : forall x w r a,
  tsubst1 x w (TBorrow r a) = TBorrow r (tsubst1 x w a).
Proof. reflexivity. Qed.

Lemma mgu_elim : forall n x t E' s0 s' tau,
  occursb x t = false ->
  unify n (map (spair x t) E') = Some s0 ->
  (forall u, tapply s' u = tapply tau (tapply s0 u)) ->
  unifies s' ((TVar x, t) :: E') ->
  exists t', forall u, tapply s' u = tapply t' (tapply ((x, t) :: s0) u).
Proof.
  intros n x t E' s0 s' tau Ho Hun Htau Hs'.
  destruct Hs' as [Hhead Hrest].
  assert (Hnox : forall y w, In (y, w) s0 -> y <> x /\ ~ In x (tvars w)).
  { intros y w Hw.
    assert (Hx : ~ In x (eqs_vars (map (spair x t) E')))
      by (apply eqs_vars_elim_nox; exact Ho).
    destruct (unify_dom_range n (map (spair x t) E') s0 Hun y w Hw)
      as [Hy Hw'].
    split.
    - intros Heq. apply Hx. rewrite Heq in Hy. exact Hy.
    - intros Hin. apply Hx. apply Hw'. exact Hin. }
  exists ((x, tapply s' (TVar x)) :: tau).
  (* 核心：对 u 结构归纳 *)
  assert (Hkey : forall u,
    tapply s' u
    = tapply tau (tsubst1 x (tapply s' (TVar x))
                          (tapply s0 (tsubst1 x t u)))).
  { intro u0. induction u0 as [m | a IHa b IHb | r a].
    - (* TVar m *)
      destruct (Nat.eq_dec m x) as [Hmx | Hmx].
      + (* m = x *)
        rewrite Hmx. rewrite tsubst1_hit.
        assert (Hnt : ~ In x (tvars (tapply s0 t))).
        { exact (tapply_no_x s0 x Hnox t (occursb_false_notin x t Ho)). }
        rewrite (tsubst1_fresh x (tapply s' (TVar x)) (tapply s0 t) Hnt).
        rewrite <- (Htau t). exact Hhead.
      + (* m ≠ x *)
        rewrite (tsubst1_var_neq x m t (not_eq_sym Hmx)).
        assert (Huvar : ~ In x (tvars (TVar m))).
        { simpl. intros [Hxm | []]. apply Hmx. exact Hxm. }
        assert (Hnm : ~ In x (tvars (tapply s0 (TVar m)))).
        { exact (tapply_no_x s0 x Hnox (TVar m) Huvar). }
        rewrite (tsubst1_fresh x (tapply s' (TVar x)) (tapply s0 (TVar m)) Hnm).
        apply (Htau (TVar m)).
    - (* TArrow a b *)
      rewrite !tsubst1_arrow, !tapply_arrow.
      rewrite !tsubst1_arrow, !tapply_arrow.
      rewrite (IHa), (IHb). reflexivity.
    - (* TBorrow r a *)
      rewrite !tsubst1_borrow, !tapply_borrow.
      rewrite !tsubst1_borrow, !tapply_borrow.
      rewrite (IHa). reflexivity.
  }
  intro u. rewrite !tapply_cons. apply (Hkey u).
Qed.

(* ---- M4. mgu 主定理（W-M2-1 后半清偿） ---- *)

Theorem unify_mgu : forall fuel E s, unify fuel E = Some s ->
  forall s', unifies s' E ->
  exists t, forall u, tapply s' u = tapply t (tapply s u).
Proof.
  induction fuel as [|n IH]; intros E s Hu s' Hs'.
  - destruct E as [|[u v] E']; simpl in Hu.
    + injection Hu as Hs. subst s. simpl in Hs'.
      exists s'. intro w. reflexivity.
    + discriminate Hu.
  - destruct E as [|[u v] E']; simpl in Hu.
    + injection Hu as Hs. subst s. simpl in Hs'.
      exists s'. intro w. reflexivity.
    + (* 九宫格 *)
      destruct u as [x | a1 a2 | r a]; destruct v as [y | b1 b2 | r' b].
      * (* TVar x, TVar y *)
        simpl in Hs'. destruct Hs' as [Hhead Hrest].
        destruct (Nat.eqb x y) eqn:Eeq.
        -- (* 删步：s 不变，mgu 直接继承 *)
           exact (IH E' s Hu s' Hrest).
        -- (* 消步 *)
           assert (Ho : occursb x (TVar y) = false).
           { unfold occursb. simpl. rewrite Eeq. reflexivity. }
           assert (Hs2 : unifies s' (map (spair x (TVar y)) E'))
             by (apply unifies_map_spair; [exact Hhead | exact Hrest]).
           destruct (unify n (map (spair x (TVar y)) E')) as [s0|] eqn:Hun.
           ++ inversion Hu; subst; clear Hu.
              destruct (IH _ s0 Hun s' Hs2) as [tau Htau].
              apply (mgu_elim n x (TVar y) E' s0 s' tau Ho Hun Htau).
              split; [exact Hhead | exact Hrest].
           ++ discriminate Hu.
      * (* TVar x, TArrow b1 b2 *)
        simpl in Hs'. destruct Hs' as [Hhead Hrest].
        destruct (occursb x (TArrow b1 b2)) eqn:Ho.
        -- discriminate Hu.
        -- assert (Hs2 : unifies s' (map (spair x (TArrow b1 b2)) E'))
             by (apply unifies_map_spair; [exact Hhead | exact Hrest]).
           destruct (unify n (map (spair x (TArrow b1 b2)) E')) as [s0|] eqn:Hun.
           ++ inversion Hu; subst; clear Hu.
              destruct (IH _ s0 Hun s' Hs2) as [tau Htau].
              apply (mgu_elim n x (TArrow b1 b2) E' s0 s' tau Ho Hun Htau).
              split; [exact Hhead | exact Hrest].
           ++ discriminate Hu.
      * (* TVar x, TBorrow r' b *)
        simpl in Hs'. destruct Hs' as [Hhead Hrest].
        destruct (occursb x (TBorrow r' b)) eqn:Ho.
        -- discriminate Hu.
        -- assert (Hs2 : unifies s' (map (spair x (TBorrow r' b)) E'))
             by (apply unifies_map_spair; [exact Hhead | exact Hrest]).
           destruct (unify n (map (spair x (TBorrow r' b)) E')) as [s0|] eqn:Hun.
           ++ inversion Hu; subst; clear Hu.
              destruct (IH _ s0 Hun s' Hs2) as [tau Htau].
              apply (mgu_elim n x (TBorrow r' b) E' s0 s' tau Ho Hun Htau).
              split; [exact Hhead | exact Hrest].
           ++ discriminate Hu.
      * (* TArrow a1 a2, TVar y：定向 *)
        simpl in Hs'. destruct Hs' as [Hhead Hrest].
        assert (Hs2 : unifies s' ((TVar y, TArrow a1 a2) :: E')).
        { apply unifies_head_sym. split; [exact Hhead | exact Hrest]. }
        exact (IH _ s Hu s' Hs2).
      * (* TArrow, TArrow：分解 *)
        simpl in Hs'. destruct Hs' as [Hhead Hrest].
        assert (Hs2 : unifies s' ((a1, b1) :: (a2, b2) :: E')).
        { apply unifies_dec_arrow. split; [exact Hhead | exact Hrest]. }
        exact (IH _ s Hu s' Hs2).
      * (* TArrow, TBorrow：冲突 *)
        discriminate Hu.
      * (* TBorrow r a, TVar y：定向 *)
        simpl in Hs'. destruct Hs' as [Hhead Hrest].
        assert (Hs2 : unifies s' ((TVar y, TBorrow r a) :: E')).
        { apply unifies_head_sym. split; [exact Hhead | exact Hrest]. }
        exact (IH _ s Hu s' Hs2).
      * (* TBorrow, TArrow：冲突 *)
        discriminate Hu.
      * (* TBorrow r a, TBorrow r' b *)
        simpl in Hs'. destruct Hs' as [Hhead Hrest].
        destruct (Nat.eqb r r') eqn:Er.
        -- apply Nat.eqb_eq in Er. subst r'.
           assert (Hs2 : unifies s' ((a, b) :: E')).
           { apply (unifies_dec_borrow s' r a b E').
             split; [exact Hhead | exact Hrest]. }
           exact (IH _ s Hu s' Hs2).
        -- discriminate Hu.
Qed.

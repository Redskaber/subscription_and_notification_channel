(* ===================================================================== *)
(*  效应能力流形 · W-LAM-1 · SigLam：λ 层签名扩展（borrow-typed 入口）      *)
(*                                                                         *)
(*  E.56 轮新登记挂账的清偿模块：                                            *)
(*    λ 层签名扩展（cgT 产 TBorrow 方程——borrow-typed API 的形式化前提）     *)
(*    ——E.56 §4.1 把它登记为"锥封闭失效点，DPLL(T) 分支搜索的回归条件"。     *)
(*                                                                         *)
(*  本轮的扩展形态（正交层——tm/constr 语法零改动，全库零重编译）：           *)
(*    cgS sig p G e = CTy (TVar p) sig :: fst (cgT p G e)                   *)
(*    ——项 e 的 λ 层入口签名 sig：入口变量 α_p 的类型 ≡ sig。                *)
(*    当 sig 含 TBorrow（borrow-typed 签名：&r α 形入口），cgT 方程集        *)
(*    含 TBorrow——E.51 elevel_eqs_free 的前提失效点。                        *)
(*                                                                         *)
(*  三个定理组（对 E.56 §4.1 预言的上机检验）：                              *)
(*    A 来源分类   cgT 侧恒 TBorrow 自由；方程集含 TBorrow ⇔ 来自签名        *)
(*       （siglam_free / siglam_borrowed / siglam_source_split）            *)
(*    B 快道增强   签名方程使主解像顶层含 TBorrow ⇒ X 快道提前命中           *)
(*       （siglam_borrow_main / siglam_fastpath_xsat——e 级复活的提前站）    *)
(*    C 锥封闭保持 签名方程（含 TBorrow）不破坏锥上升——instance_sound        *)
(*       无条件成立，特化仍无需重跑合一（翻案 #27 的定理面）                  *)
(*       （siglam_cone_intact / siglam_ascent_sound）                       *)
(* ===================================================================== *)

Require Import List Lia PeanoNat Bool.
Import ListNotations.
Require Import Mult Cap Syntax CG Tau TyCG Lphi Fusion Mu Xsub M3Fusion
               Rsat Hsat Solve3 Xcone Drop2 Gphi Solve4.

Local Open Scope bool_scope.

(* ================= 一、λ 层签名版约束生成 ================= *)

(* λ 层入口签名：项 e 的入口变量 α_p 的类型 ≡ sig。
   cgT（TyCG）的 Lam 层签名恒为箭头形态（α_{p+1} → α_{p+2}）——
   无法表达借用类型；cgS 在 cgT 之上加一条入口签名方程——
   borrow-typed API 的形式化前提：sig 可以是 &r α 形。 *)
Definition cgS (sig : ty) (p : nat) (G : list nat) (e : tm) : list constr :=
  CTy (TVar p) sig :: fst (cgT p G e).

(* e 级签名版求解器包装 *)
Definition solve3S (sig : ty) (fuel : nat) (e : tm) : option (tsubst * cmap) :=
  solve3 fuel (cg e ++ cgS sig 0 [] e).

Definition solve4S (sig : ty) (fuel : nat) (e : tm) : option (tsubst * cmap) :=
  solve4 fuel (cg e ++ cgS sig 0 [] e).

(* ================= 二、结构引理 ================= *)

(* 签名方程取方程表头：tyEqs (cgS …) = (TVar p, sig) :: tyEqs (cgT …) *)
Lemma cgS_tyEqs : forall sig p G e,
  tyEqs (cgS sig p G e) = (TVar p, sig) :: tyEqs (fst (cgT p G e)).
Proof. intros sig p G e. reflexivity. Qed.

(* ================= 三、A 组：来源分类 ================= *)
(* elevel_eqs_free（E.51）说 cgT 方程恒 TBorrow 自由——签名方程可以打破它。
   分类定理：方程集的自由性完全由签名侧决定（cgT 侧恒自由）。 *)

(* A1. 签名自由 ⇒ cgS 方程集自由（elevel_eqs_free 的 cgS 推广形态） *)
Theorem siglam_free : forall sig p G e,
  tbfree sig = true ->
  eqs_free (tyEqs (cgS sig p G e)) = true.
Proof.
  intros sig p G e Hsig. rewrite cgS_tyEqs.
  unfold eqs_free, epair_free. simpl. rewrite Hsig. simpl.
  apply cgT_eqs_free.
Qed.

(* A2. 签名含 TBorrow ⇒ cgS 方程集不自由（失效面实锤） *)
Theorem siglam_borrowed : forall sig p G e,
  tbfree sig = false ->
  eqs_free (tyEqs (cgS sig p G e)) = false.
Proof.
  intros sig p G e Hsig. rewrite cgS_tyEqs.
  unfold eqs_free. simpl. unfold epair_free. simpl.
  rewrite Hsig. simpl. reflexivity.
Qed.

(* A3. 来源分割定理：方程集含 TBorrow ⇒ 全部来自签名方程
      （cgT 侧恒自由——TBorrow 不可能从 cgT 层进入方程集） *)
Theorem siglam_source_split : forall sig p G e,
  eqs_free (tyEqs (cgS sig p G e)) = false ->
  tbfree sig = false /\ eqs_free (tyEqs (fst (cgT p G e))) = true.
Proof.
  intros sig p G e H.
  split.
  - (* 逆否：若 sig 自由则整体自由（A1）——矛盾 *)
    destruct (tbfree sig) eqn:Es; [|reflexivity].
    exfalso. rewrite (siglam_free sig p G e Es) in H. discriminate.
  - apply cgT_eqs_free.
Qed.

(* ================= 四、B 组：快道增强 ================= *)
(* 签名方程 (α_p, &r t) 使合一解把 α_p 的像定为顶层 TBorrow r 形——
   X 读数在主解层即可命中（e 级复活的提前站：solve3 层，无需 solve4 上升）。 *)

(* 方程成员资格提取：unifies 是结构递归，先提取“逐条蕴含”形态 *)
Lemma unifies_in : forall s E u v,
  In (u, v) E -> unifies s E -> tapply s u = tapply s v.
Proof.
  intros s E. induction E as [|[a b] E IH]; intros u v Hin H; simpl in H.
  - destruct Hin.
  - destruct Hin as [Heq | Hin].
    + injection Heq as Hu Hv. subst a b. exact (proj1 H).
    + apply (IH u v Hin). exact (proj2 H).
Qed.

(* B1. 签名借用方程 ⇒ 入口变量的 σ-像顶层为 TBorrow r *)
Theorem siglam_borrow_main : forall E s p r t,
  In (TVar p, TBorrow r t) E ->
  unifies s E ->
  tapply s (TVar p) = TBorrow r (tapply s t).
Proof.
  intros E s p r t Hin Hun.
  pose proof (unifies_in s E (TVar p) (TBorrow r t) Hin Hun) as Heq.
  rewrite tapply_borrow in Heq. exact Heq.
Qed.

(* B2. 快道定理：入口变量出现于 X 载荷 ⇒ 主解的 X 读数命中
      （roccurs_tapply_split 的右支：变量像的区域进入整像） *)
Theorem siglam_fastpath_xsat : forall E s p r t u,
  In (TVar p, TBorrow r t) E ->
  unifies s E ->
  In p (tvars u) ->
  roccurs r (tapply s u) = true.
Proof.
  intros E s p r t u Hin Hun Hpu.
  assert (Himg : tapply s (TVar p) = TBorrow r (tapply s t))
    by (apply (siglam_borrow_main E s p r t Hin Hun)).
  (* p 的像顶层 TBorrow r ⇒ roccurs r (σ (TVar p)) = true *)
  assert (Hvar : roccurs r (tapply s (TVar p)) = true).
  { rewrite Himg. simpl. rewrite Nat.eqb_refl. reflexivity. }
  (* 整像：roccurs_tapply_split 右支 *)
  apply (proj2 (roccurs_tapply_split s r u)).
  right. exists p. split; [exact Hpu | exact Hvar].
Qed.

(* ================= 五、C 组：锥封闭保持（翻案 #27 定理面） ================= *)
(* E.56 §4.1 预言："签名扩展后，特化必须重新过合一，拒绝面出现，
   case-split 世界回归"。上机检验：instance_sound 的证明只依赖
   tapply 组合律（tapply_app）——对任意方程集成立，含 TBorrow 的
   签名方程在内。特化仍无需重跑合一——锥上升照常。 *)

(* C1. 锥封闭无条件成立的重述（含签名方程的 E 在内） *)
Theorem siglam_cone_intact : forall E s t,
  unifies s E -> unifies (s ++ t) E.
Proof.
  intros E s t H. apply instance_sound. exact H.
Qed.

(* C2. 含 TBorrow 方程集上的上升可靠性（solve4_sound 对任意池成立——
      签名池是实例；此定理把"照常"钉在 cgS 池上） *)
Theorem siglam_ascent_sound : forall sig fuel e s l,
  solve4S sig fuel e = Some (s, l) ->
  unifies s (tyEqs (chanProj ChTy (cg e ++ cgS sig 0 [] e))) /\
  phsat l (chanProj ChPhi (cg e ++ cgS sig 0 [] e)) /\
  (forall m, phsat m (chanProj ChPhi (cg e ++ cgS sig 0 [] e)) ->
     cle l m) /\
  hsat (cg e ++ cgS sig 0 [] e) /\
  xsat s (cg e ++ cgS sig 0 [] e).
Proof.
  intros sig fuel e s l H. unfold solve4S in H.
  apply (solve4_sound fuel (cg e ++ cgS sig 0 [] e) s l H).
Qed.

(* C3. 含 TBorrow 签名池上的上升终点仍合一——"重跑合一"是不必要的
      （E.56 §4.1 "特化必须重新过合一"预言的否定面：instance_sound 充足） *)
Theorem siglam_ascent_unifies : forall sig e f s0 n,
  unify f (tyEqs (chanProj ChTy (cg e ++ cgS sig 0 [] e))) = Some s0 ->
  unifies (xascend s0 (cg e ++ cgS sig 0 [] e) n)
          (tyEqs (chanProj ChTy (cg e ++ cgS sig 0 [] e))).
Proof.
  intros sig e f s0 n Hu.
  apply xascend_unifies.
  apply (unify_sound f). exact Hu.
Qed.

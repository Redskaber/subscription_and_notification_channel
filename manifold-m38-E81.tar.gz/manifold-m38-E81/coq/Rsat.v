(* ===================================================================== *)
(*  效应能力流形 · W-M3-2 · Rsat：R 通道求解义务（CRg outlives 闭包）       *)
(*                                                                         *)
(*  E.46 轮预告的 W-M3-2 第一组分：R 通道从"生成不解"升格为"求解义务"。      *)
(*  区域名 nat 是共享常量域——CRg 的两端与 TBorrow 标签、CHr 参数同域。      *)
(*                                                                         *)
(*  语义侧：rle cs r1 r2 —— 自由预序（outlives）                            *)
(*    rle_refl   自反（每个区域存活于自身）                                  *)
(*    rle_edge   池中每条 CRg r1 r2 是一条 outlives 边                       *)
(*    rle_trans  传递（outlives 复合）                                       *)
(*  rle_preorder：R 的自由模型——任意 CRg 池无条件可满足（R 永不单独阻塞，   *)
(*  与 φ 的零前提完备 phi_unconditional 同构的"供给型"通道）。               *)
(*                                                                         *)
(*  计算侧：rclose cs —— redges 的迭代自复合（rF 算子 × S(|V|^2) 步）       *)
(*    rclose_incl_edges 闭包含原边                                          *)
(*    rclose_trans       闭包传递（复合封闭不动点——鸽笼稳定性）              *)
(*    rclose_min         最小性：任何含边传递关系都包含闭包（R 的主性）      *)
(*    rclose_sound       可靠：闭包对 ⇒ rle                                 *)
(*    rclose_complete    完备：rle ∧ a<>b ⇒ 闭包对（自反对由语义承担）      *)
(*    rclose_xapply_invar  盲性守恒：现形不移动 R 闭包（CRg 刚性）           *)
(*                                                                         *)
(*  安排层（Nelson–Oppen 世界）：R 闭包是 H 通道挂靠传递的供给边            *)
(*  （Hsat.v 消费）；R 对 τ 代换盲（CRg 不携带 ty——盲性矩阵的 R 行）。      *)
(* ===================================================================== *)

Require Import List Lia PeanoNat.
Import ListNotations.
Require Import Mult Cap Syntax Xsub.

Local Open Scope bool_scope.

(* ================= 一、语义谓词：自由预序 rle ================= *)

Inductive rle (cs : list constr) : nat -> nat -> Prop :=
| rle_refl  : forall r, rle cs r r
| rle_edge  : forall r1 r2, In (CRg r1 r2) cs -> rle cs r1 r2
| rle_trans : forall a b c, rle cs a b -> rle cs b c -> rle cs a c.

(* R 的自由模型：预序性 = R 通道无条件可满足（永不单独阻塞） *)
Theorem rle_preorder : forall cs,
  (forall r, rle cs r r) /\ (forall a b c, rle cs a b -> rle cs b c -> rle cs a c).
Proof.
  intros cs. split.
  - intros r. apply rle_refl.
  - intros a b c H1 H2. eapply rle_trans; eassumption.
Qed.

(* ================= 二、计算侧：边表与自复合算子 ================= *)

Definition redge1 (c : constr) : list (nat * nat) :=
  match c with
  | CRg r1 r2 => [(r1, r2)]
  | _ => []
  end.

Definition redges (cs : list constr) : list (nat * nat) :=
  flat_map redge1 cs.

Lemma redges_in : forall cs a b,
  In (a, b) (redges cs) <-> In (CRg a b) cs.
Proof.
  intros cs a b. unfold redges. rewrite in_flat_map. split.
  - intros [c [Hc Hin]].
    destruct c as [x y | r1 r2 | c k | c c' w | l r | l | r t];
      unfold redge1 in Hin; simpl in Hin; try contradiction.
    destruct Hin as [Hin | []]. inversion Hin; subst; exact Hc.
  - intros H. exists (CRg a b). split;
      [exact H | unfold redge1; simpl; left; reflexivity].
Qed.

(* 数对判等（nodup 的决策函数） *)
Definition peq_dec (p q : nat * nat) : {p = q} + {p <> q}.
Proof. decide equality; apply Nat.eq_dec. Defined.

(* 复合：A 的终点接 B 的起点 *)
Definition rcomp (A B : list (nat * nat)) : list (nat * nat) :=
  flat_map (fun ab =>
              match ab with
              | (a, b) =>
                  flat_map (fun cd =>
                              match cd with
                              | (c, d) => if Nat.eqb b c then [(a, d)] else []
                              end) B
              end) A.

Lemma rcomp_in : forall A B a d,
  In (a, d) (rcomp A B) <->
  (exists b c, In (a, b) A /\ In (c, d) B /\ b = c).
Proof.
  intros A B a d. unfold rcomp. split.
  - rewrite in_flat_map. intros [[a0 b0] [Hin Hm]].
    rewrite in_flat_map in Hm. destruct Hm as [[c d0] [Hcd Hif]].
    destruct (Nat.eqb b0 c) eqn:Eeq; simpl in Hif.
    + destruct Hif as [Hif | []]. inversion Hif; subst.
      apply Nat.eqb_eq in Eeq.
      exists b0, c. repeat split; assumption.
    + destruct Hif.
  - intros [b [c [Hab [Hcd Heq]]]]. subst c. apply in_flat_map.
    exists (a, b). split; [exact Hab|].
    apply in_flat_map. exists (b, d). split; [exact Hcd|].
    rewrite Nat.eqb_refl. left. reflexivity.
Qed.

(* 迭代算子：边 ∪ 已闭 ∪ 复合，去重 *)
Definition rF (edges closed : list (nat * nat)) : list (nat * nat) :=
  nodup peq_dec (edges ++ closed ++ rcomp closed closed).

Fixpoint rcloseN (edges : list (nat * nat)) (n : nat) : list (nat * nat) :=
  match n with
  | 0 => nodup peq_dec edges
  | S n' => rF edges (rcloseN edges n')
  end.

Lemma rcloseN_S : forall edges n,
  rcloseN edges (S n) = rF edges (rcloseN edges n).
Proof. reflexivity. Qed.

(* 全域：端点集上的全部有序对（闭包元素的类型级上界） *)
Definition rdomain (edges : list (nat * nat)) : list nat :=
  nodup Nat.eq_dec (flat_map (fun ab => match ab with (a, b) => [a; b] end) edges).

Definition upairs (edges : list (nat * nat)) : list (nat * nat) :=
  flat_map (fun a => map (fun b => (a, b)) (rdomain edges)) (rdomain edges).

(* 迭代步数：全域基数 + 1（鸽笼充分性） *)
Definition rbound (edges : list (nat * nat)) : nat :=
  S (length (rdomain edges) * length (rdomain edges)).

Definition rclose (cs : list constr) : list (nat * nat) :=
  rcloseN (redges cs) (rbound (redges cs)).

(* ================= 三、基础设施：全域刻画、包含、长度界 ================= *)

Lemma in_rdomain : forall edges x,
  In x (rdomain edges) <-> (exists y, In (x, y) edges \/ In (y, x) edges).
Proof.
  intros edges x. unfold rdomain. rewrite nodup_In, in_flat_map. split.
  - intros [p [Hp Hin]]. destruct p as [a b]. simpl in Hin.
    destruct Hin as [Hx' | [Hx' | []]]; subst.
    + exists b. left. exact Hp.
    + exists a. right. exact Hp.
  - intros [y [Hy | Hy]].
    + exists (x, y). split; [exact Hy | simpl; left; reflexivity].
    + exists (y, x). split; [exact Hy | simpl; right; left; reflexivity].
Qed.

Lemma in_upairs : forall edges a b,
  In (a, b) (upairs edges) <-> In a (rdomain edges) /\ In b (rdomain edges).
Proof.
  intros edges a b. unfold upairs. rewrite in_flat_map. split.
  - intros [x [Hx Hin]]. rewrite in_map_iff in Hin.
    destruct Hin as [y [Hy Hin]]. inversion Hy; subst.
    split; assumption.
  - intros [Ha Hb]. exists a. split; [exact Ha|].
    rewrite in_map_iff. exists b. split; [reflexivity | exact Hb].
Qed.

Lemma flat_map_len : forall (L L' : list nat),
  length (flat_map (fun (a : nat) => map (fun (b : nat) => (a, b)) L') L)
  = length L * length L'.
Proof.
  induction L as [|a L IH]; [reflexivity|].
  intros L'. simpl. rewrite length_app, length_map, IH. reflexivity.
Qed.

Lemma upairs_length : forall edges,
  length (upairs edges) = length (rdomain edges) * length (rdomain edges).
Proof.
  intros edges. unfold upairs. apply flat_map_len.
Qed.

Lemma rF_incl_self : forall edges closed, incl closed (rF edges closed).
Proof.
  intros edges closed x Hx. unfold rF. apply nodup_In.
  apply in_or_app. right. apply in_or_app. left. exact Hx.
Qed.

Lemma rF_incl_edges : forall edges closed, incl edges (rF edges closed).
Proof.
  intros edges closed x Hx. unfold rF. apply nodup_In.
  apply in_or_app. left. exact Hx.
Qed.

Lemma rcomp_mono : forall A A' B B',
  incl A A' -> incl B B' -> incl (rcomp A B) (rcomp A' B').
Proof.
  intros A A' B B' HA HB [a d] Hx. apply rcomp_in in Hx.
  destruct Hx as [b [c [Hab [Hcd Heq]]]].
  apply rcomp_in. exists b, c. repeat split; auto.
Qed.

Lemma rF_mono : forall edges closed closed',
  incl closed closed' -> incl (rF edges closed) (rF edges closed').
Proof.
  intros edges closed closed' Hc x Hx. unfold rF in *.
  apply nodup_In in Hx. apply in_app_or in Hx.
  destruct Hx as [Hx | Hx].
  - apply nodup_In. apply in_or_app. left. exact Hx.
  - apply in_app_or in Hx. destruct Hx as [Hx | Hx].
    + apply nodup_In. apply in_or_app. right. apply in_or_app. left.
      apply Hc; exact Hx.
    + apply nodup_In. apply in_or_app. right. apply in_or_app. right.
      apply (rcomp_mono closed closed' closed closed' Hc Hc); exact Hx.
Qed.

Lemma rcloseN_incl : forall edges n m,
  n <= m -> incl (rcloseN edges n) (rcloseN edges m).
Proof.
  intros edges n m Hnm. induction m as [|m IH].
  - assert (Hn : n = 0) by lia. subst. apply incl_refl.
  - destruct (Nat.eq_dec n (S m)) as [Heq | Hne].
    + subst. apply incl_refl.
    + apply incl_tran with (rcloseN edges m).
      * apply IH; lia.
      * apply rF_incl_self.
Qed.

(* 全域保持：迭代的每个元素都是端点对 *)
Lemma rcloseN_in_upairs : forall edges n x,
  In x (rcloseN edges n) -> In x (upairs edges).
Proof.
  intros edges n. induction n as [|n IH]; intros [a d] Hx.
  - (* 起点：去重后的边 *)
    simpl in Hx. apply nodup_In in Hx.
    apply (proj2 (in_upairs edges a d)). split.
    + apply (proj2 (in_rdomain edges a)). exists d. left. exact Hx.
    + apply (proj2 (in_rdomain edges d)). exists a. right. exact Hx.
  - (* 步：rF 的三个来源都保持 *)
    change (In (a, d) (rF edges (rcloseN edges n))) in Hx.
    unfold rF in Hx. apply nodup_In in Hx. apply in_app_or in Hx.
    destruct Hx as [Hx | Hx].
    + (* 新边 *)
      apply (proj2 (in_upairs edges a d)). split.
      * apply (proj2 (in_rdomain edges a)). exists d. left. exact Hx.
      * apply (proj2 (in_rdomain edges d)). exists a. right. exact Hx.
    + apply in_app_or in Hx. destruct Hx as [Hx | Hx].
      * (* 旧闭包 *)
        apply IH; exact Hx.
      * (* 复合 *)
        apply rcomp_in in Hx.
        destruct Hx as [b [c [Hab [Hcd _]]]].
        assert (Hab' : In (a, b) (upairs edges)) by (apply IH; exact Hab).
        assert (Hcd' : In (c, d) (upairs edges)) by (apply IH; exact Hcd).
        apply (proj1 (in_upairs edges a b)) in Hab'.
        apply (proj1 (in_upairs edges c d)) in Hcd'.
        apply (proj2 (in_upairs edges a d)). split.
        -- exact (proj1 Hab').
        -- exact (proj2 Hcd').
Qed.

Lemma rcloseN_nodup : forall edges n, NoDup (rcloseN edges n).
Proof.
  intros edges n. induction n as [|n IH]; simpl.
  - apply NoDup_nodup.
  - apply NoDup_nodup.
Qed.

Lemma rcloseN_length_le : forall edges n,
  length (rcloseN edges n) <= length (upairs edges).
Proof.
  intros edges n.
  apply NoDup_incl_length.
  - apply rcloseN_nodup.
  - intros x Hx. exact (rcloseN_in_upairs edges n x Hx).
Qed.

(* 长度链单调 *)
Lemma rcloseN_length_mono : forall edges n,
  length (rcloseN edges n) <= length (rcloseN edges (S n)).
Proof.
  intros edges n.
  apply NoDup_incl_length.
  - apply rcloseN_nodup.
  - apply rF_incl_self.
Qed.

(* ================= 四、鸽笼：构造性稳定性 ================= *)

(* 构造性鸽笼：单调长度链在界内必达相邻相等 *)
Lemma pigeon_mono : forall (f : nat -> nat) (U n : nat),
  (forall k, f k <= f (S k)) ->
  f n <= U ->
  U < n ->
  exists k, k < n /\ f k = f (S k).
Proof.
  intros f U n. revert U.
  induction n as [|n IH]; intros U Hmono Hfn Hlt.
  - lia.
  - destruct (Nat.eq_dec (f n) (f (S n))) as [Heq | Hne].
    + exists n. split; [lia | exact Heq].
    + assert (Hlt2 : f n < f (S n)).
      { destruct (proj1 (Nat.lt_eq_cases (f n) (f (S n))) (Hmono n))
          as [H | H]; [exact H | exfalso; apply Hne; exact H]. }
      assert (Hfn' : f n <= U - 1) by lia.
      destruct (IH (U - 1) Hmono Hfn' ltac:(lia)) as [k [Hk Heq]].
      exists k. split; [lia | exact Heq].
Qed.

(* 长度相等 + 包含 + NoDup ⇒ 反向包含 *)
Lemma nodup_len_eq_incl : forall (A B : list (nat * nat)),
  NoDup A -> incl A B -> length A = length B -> incl B A.
Proof.
  intros A B NA HA Hlen.
  apply (NoDup_length_incl (A := nat * nat) (l := A) (l' := B) NA);
    [rewrite Hlen; lia | exact HA].
Qed.

(* 鸽笼应用：rbound 步内必达元素向不动点 *)
Lemma rcloseN_exists_stable : forall edges,
  exists k, k < rbound edges
            /\ incl (rcloseN edges (S k)) (rcloseN edges k).
Proof.
  intros edges.
  set (U := length (upairs edges)).
  destruct (pigeon_mono (fun n => length (rcloseN edges n)) U (rbound edges))
    as [k [Hk Hlen]].
  - intros n. apply rcloseN_length_mono.
  - apply rcloseN_length_le.
  - unfold rbound, U. rewrite upairs_length. lia.
  - exists k. split; [exact Hk|].
    apply nodup_len_eq_incl.
    + apply rcloseN_nodup.
    + apply rF_incl_self.
    + exact Hlen.
Qed.

(* 稳定性传播：一步反向包含 ⇒ 其后步步反向包含 *)
Lemma rcloseN_stable_prop : forall edges k,
  incl (rcloseN edges (S k)) (rcloseN edges k) ->
  forall m, k <= m -> incl (rcloseN edges (S m)) (rcloseN edges m).
Proof.
  intros edges k Hk m. induction m as [|m IH]; intros Hm.
  - assert (k = 0) by lia. subst. exact Hk.
  - destruct (Nat.eq_dec k (S m)) as [Heq | Hne].
    + subst k. exact Hk.
    + assert (Hle : k <= m) by lia.
      rewrite rcloseN_S.
      apply incl_tran with (rF edges (rcloseN edges m)).
      * apply rF_mono. apply IH. exact Hle.
      * rewrite rcloseN_S. apply incl_refl.
Qed.

(* rclose 的不动点性：rF 再跑一步不增（元素向） *)
Theorem rclose_fixpoint : forall cs,
  incl (rF (redges cs) (rclose cs)) (rclose cs).
Proof.
  intros cs.
  destruct (rcloseN_exists_stable (redges cs)) as [k [Hk Hst]].
  assert (HB : rbound (redges cs) = S (pred (rbound (redges cs))))
    by (unfold rbound; rewrite Nat.pred_succ; reflexivity).
  assert (HkP : k <= pred (rbound (redges cs))) by lia.
  assert (Hprop : incl (rcloseN (redges cs) (S (pred (rbound (redges cs)))))
                          (rcloseN (redges cs) (pred (rbound (redges cs))))).
  { apply (rcloseN_stable_prop (redges cs) k Hst
            (pred (rbound (redges cs))) HkP). }
  rewrite rcloseN_S in Hprop.
  unfold rclose. rewrite HB, rcloseN_S.
  apply rF_mono. exact Hprop.
Qed.

(* ================= 五、闭包定理组 ================= *)

(* 包含原边 *)
Theorem rclose_incl_edges : forall cs, incl (redges cs) (rclose cs).
Proof.
  intros cs x Hx. unfold rclose.
  apply (rcloseN_incl (redges cs) 0 (rbound (redges cs)) ltac:(unfold rbound; lia)).
  simpl. apply nodup_In. exact Hx.
Qed.

(* 传递性：闭包复合封闭 *)
Theorem rclose_trans : forall cs a b c,
  In (a, b) (rclose cs) -> In (b, c) (rclose cs) -> In (a, c) (rclose cs).
Proof.
  intros cs a b c Hab Hbc.
  assert (Hcomp : In (a, c) (rcomp (rclose cs) (rclose cs))).
  { apply (proj2 (rcomp_in (rclose cs) (rclose cs) a c)).
    exists b, b. split; [exact Hab | split; [exact Hbc | reflexivity]]. }
  assert (Hin : In (a, c) (rF (redges cs) (rclose cs))).
  { unfold rF. apply nodup_In. apply in_or_app. right.
    apply in_or_app. right. exact Hcomp. }
  exact (rclose_fixpoint cs (a, c) Hin).
Qed.

(* 最小性（R 的主性）：任何含边传递关系都包含闭包 *)
Theorem rclose_min : forall cs C,
  incl (redges cs) C ->
  incl (rcomp C C) C ->
  incl (rclose cs) C.
Proof.
  intros cs C HC HCtrans.
  assert (Hgen : forall n, incl (rcloseN (redges cs) n) C).
  { induction n as [|n IH]; simpl.
    - intros [a d] Hx. apply nodup_In in Hx. apply HC; exact Hx.
    - unfold rF. intros [a d] Hx. apply nodup_In in Hx.
      apply in_app_or in Hx. destruct Hx as [Hx | Hx].
      + apply HC; exact Hx.
      + apply in_app_or in Hx. destruct Hx as [Hx | Hx].
        * apply IH; exact Hx.
        * apply rcomp_in in Hx.
          destruct Hx as [b [c [Hab [Hcd Heq]]]]. subst c.
          apply HCtrans. apply (proj2 (rcomp_in C C a d)).
          exists b, b. split; [apply IH; exact Hab|].
          split; [apply IH; exact Hcd | reflexivity]. }
  unfold rclose. apply Hgen.
Qed.

(* 可靠：闭包对都是真 outlives *)
Theorem rclose_sound : forall cs a b,
  In (a, b) (rclose cs) -> rle cs a b.
Proof.
  intros cs.
  assert (Hmain : forall n a b, In (a, b) (rcloseN (redges cs) n) -> rle cs a b).
  { induction n as [|n IH]; intros a b Hn.
    - simpl in Hn. apply nodup_In in Hn.
      apply redges_in in Hn. apply rle_edge. exact Hn.
    - change (In (a, b) (rF (redges cs) (rcloseN (redges cs) n))) in Hn.
      unfold rF in Hn. apply nodup_In in Hn.
      apply in_app_or in Hn. destruct Hn as [Hn | Hn].
      + apply redges_in in Hn. apply rle_edge. exact Hn.
      + apply in_app_or in Hn. destruct Hn as [Hn | Hn].
        * apply IH; exact Hn.
        * apply rcomp_in in Hn.
          destruct Hn as [m [c [Ham [Hcb Hmc]]]]. subst m.
          apply (rle_trans cs a c b).
          -- apply IH; exact Ham.
          -- apply IH; exact Hcb. }
  intros a b H. unfold rclose in H |- *.
  exact (Hmain _ a b H).
Qed.

(* 完备：非平凡 outlives 都在闭包中（自反对由语义承担） *)
Theorem rclose_complete : forall cs a b,
  rle cs a b -> a <> b -> In (a, b) (rclose cs).
Proof.
  intros cs a b Hrle.
  induction Hrle as [r | r1 r2 Hin | x y z Hxy IHxy Hyz IHyz]; intros Hne.
  - exfalso. apply Hne. reflexivity.
  - apply rclose_incl_edges. apply redges_in. exact Hin.
  - destruct (Nat.eq_dec x y) as [Heq | Hxy'].
    + subst x. apply IHyz. exact Hne.
    + destruct (Nat.eq_dec y z) as [Heq2 | Hyz'].
      * subst z. apply IHxy. exact Hne.
      * apply (rclose_trans cs x y z).
        -- apply IHxy. exact Hxy'.
        -- apply IHyz. exact Hyz'.
Qed.

(* ================= 六、盲性守恒（R 对 τ 代换盲） ================= *)

(* CRg 是现形算子的不动点 *)
Lemma redge1_xapply : forall s c, redge1 (xapply1 s c) = redge1 c.
Proof. intros s c. destruct c; reflexivity. Qed.

Lemma redges_xapply : forall s cs, redges (xapply s cs) = redges cs.
Proof.
  intros s cs. unfold redges, xapply.
  induction cs as [|c cs IH]; simpl; [reflexivity|].
  rewrite redge1_xapply. f_equal. exact IH.
Qed.

(* 现形不移动 R 闭包（盲性矩阵的 R 格） *)
Theorem rclose_xapply_invar : forall s cs,
  rclose (xapply s cs) = rclose cs.
Proof.
  intros s cs. unfold rclose. rewrite redges_xapply. reflexivity.
Qed.

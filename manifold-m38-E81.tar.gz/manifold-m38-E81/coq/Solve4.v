(* ===================================================================== *)
(*  效应能力流形 · W-M3-3 · Solve4：组装求解器的安排接入（锥上升）          *)
(*                                                                         *)
(*  W-M3-3 的求解器装配：                                                    *)
(*    solve4 = solve3（主解政策快道）⊕ 锥上升（X 空窗的出口）                *)
(*    solve5 = solve4 ⊕ dropck 严格性档 2 门（hsat2b）                       *)
(*                                                                         *)
(*  调度拓扑（盲性矩阵 + 锥上升后的新形态）：                                *)
(*    快道：solve3 命中即返回（主解政策——最薄读数先行）                       *)
(*    上升：solve3 None ∧ τ 可解 ∧ H 见证 ⇒ xascend 从主解沿实例锥贪心      *)
(*          上升至 X 全满足——无回溯、无重跑合一（instance_sound 供给）       *)
(*    档 2：solve5 在 solve4 之上加严格挂靠门（hclose 有限见证枚举）          *)
(*                                                                         *)
(*  定理组（SEARCH_FAIL 类的再收窄）：                                       *)
(*    solve4_sound / solve4_complete（上升形态完备）                         *)
(*    solve4_profile   命中 ⇔ H 见证 ∧ τ 可解——X 面从剖面中消失！            *)
(*    solve4_none      None 的语义源收窄为 τ ∪ H（X_BLOCK 消亡）             *)
(*    solve4_fiber     返回解的锥分解：σ = σ₀ ⊕ 特化点链（谱系纤维机内化）   *)
(*    elevel_exit / elevel_resurrection  e 级 X 空窗的闭合（e0m 复活）       *)
(*    solve5_sound / solve5_profile / solve5_none  档 2 的接入               *)
(* ===================================================================== *)

Require Import List Lia PeanoNat Bool.
Import ListNotations.
Require Import Mult Cap Syntax CG Tau TyCG Lphi Fusion Mu Xsub M3Fusion
               Rsat Hsat Solve3 Xcone Drop2 Gphi.

Local Open Scope bool_scope.

(* ================= 一、solve4：快道 ⊕ 锥上升 ================= *)

Definition solve4 (fuel : nat) (cs : list constr) : option (tsubst * cmap) :=
  match solve3 fuel cs with
  | Some sol => Some sol
  | None =>
      match unify fuel (tyEqs (chanProj ChTy cs)) with
      | None => None
      | Some s0 =>
          if hsatb cs
          then Some (xascend s0 cs (length cs), lphi (chanProj ChPhi cs))
          else None
      end
  end.

Definition infer4 (fuel : nat) (e : tm) : option (tsubst * cmap) :=
  solve4 fuel (cg e ++ fst (cgT 0 [] e)).

(* 政策保持：solve3 命中 ⇒ solve4 同解返回（快道——主解政策未被废除） *)
Theorem solve4_policy : forall fuel cs s l,
  solve3 fuel cs = Some (s, l) -> solve4 fuel cs = Some (s, l).
Proof. intros fuel cs s l H. unfold solve4. rewrite H. reflexivity. Qed.

(* 可靠性：命中 ⇒ τ 解 + φ 最小解 + H 见证 + X 现形 *)
Theorem solve4_sound : forall fuel cs s l,
  solve4 fuel cs = Some (s, l) ->
  unifies s (tyEqs (chanProj ChTy cs)) /\
  phsat l (chanProj ChPhi cs) /\
  (forall m, phsat m (chanProj ChPhi cs) -> cle l m) /\
  hsat cs /\ xsat s cs.
Proof.
  intros fuel cs s l H. unfold solve4 in H.
  destruct (solve3 fuel cs) as [[s3 l3] |] eqn:E3.
  - injection H as Hs Hl. rewrite <- Hs, <- Hl.
    exact (solve3_sound fuel cs s3 l3 E3).
  - destruct (unify fuel (tyEqs (chanProj ChTy cs))) as [s0 |] eqn:Eu.
    + destruct (hsatb cs) eqn:Eh; [|discriminate].
      injection H as Hs Hl. rewrite <- Hs, <- Hl. repeat split.
      * apply xascend_unifies.
        exact (unify_sound fuel (tyEqs (chanProj ChTy cs)) s0 Eu).
      * apply (proj1 (lphi_solve (chanProj ChPhi cs))).
      * apply (proj2 (lphi_solve (chanProj ChPhi cs))).
      * apply (proj1 (hsatb_correct cs)). exact Eh.
      * apply (proj1 (xsatb_correct (xascend s0 cs (length cs)) cs)).
        apply xascend_xsat. apply xcount_le.
    + discriminate.
Qed.

(* 上升形态完备：τ 可解 + H 见证 ⇒ 命中（X 不再是阻塞面） *)
Theorem solve4_complete : forall cs f0 s0,
  unify f0 (tyEqs (chanProj ChTy cs)) = Some s0 ->
  hsat cs ->
  exists fuel s l, solve4 fuel cs = Some (s, l).
Proof.
  intros cs f0 s0 Hu Hhsat.
  assert (E2 : solve2 f0 cs = Some (s0, lphi (chanProj ChPhi cs))).
  { unfold solve2. rewrite Hu. reflexivity. }
  destruct (xsatb s0 cs) eqn:Ex.
  - (* 快道：主解政策命中 *)
    exists f0, s0, (lphi (chanProj ChPhi cs)).
    unfold solve4, solve3. rewrite E2.
    rewrite (proj2 (hsatb_correct cs) Hhsat), Ex. reflexivity.
  - (* 上升道：主解 X 空窗 ⇒ 锥上升 *)
    exists f0, (xascend s0 cs (length cs)), (lphi (chanProj ChPhi cs)).
    assert (E3 : solve3 f0 cs = None).
    { unfold solve3. rewrite E2.
      destruct (hsatb cs) eqn:Eh.
      - rewrite Ex. reflexivity.
      - exfalso. assert (hsatb cs = true)
          by (apply (proj2 (hsatb_correct cs)); exact Hhsat).
        rewrite Eh in H. discriminate. }
    unfold solve4. rewrite E3, Hu.
    rewrite (proj2 (hsatb_correct cs) Hhsat). reflexivity.
Qed.

(* 组装剖面 v2：X 面从剖面中消失（E.51 assembly_profile 的升级） *)
Theorem solve4_profile : forall cs,
  (exists fuel s l, solve4 fuel cs = Some (s, l))
  <-> (hsat cs /\ exists f0 s0,
         unify f0 (tyEqs (chanProj ChTy cs)) = Some s0).
Proof.
  intros cs. split.
  - intros [fuel [s [l H]]].
    destruct (solve4_sound fuel cs s l H) as [Hu [_ [_ [Hhs _]]]].
    split; [exact Hhs|].
    destruct (unify_complete (tyEqs (chanProj ChTy cs))
                (ex_intro _ s Hu)) as [f0 [s0 Hf0]].
    exists f0, s0. exact Hf0.
  - intros [Hhsat [f0 [s0 Hu]]].
    destruct (solve4_complete cs f0 s0 Hu Hhsat) as [fuel [s [l H]]].
    exists fuel, s, l. exact H.
Qed.

(* None 的语义源收窄：τ ∪ H（X_BLOCK 从失败类中消亡） *)
Theorem solve4_none : forall fuel cs,
  solve4 fuel cs = None ->
  unify fuel (tyEqs (chanProj ChTy cs)) = None \/ ~ hsat cs.
Proof.
  intros fuel cs H. unfold solve4 in H.
  destruct (solve3 fuel cs) as [[s3 l3] |] eqn:E3.
  { discriminate. }
  destruct (unify fuel (tyEqs (chanProj ChTy cs))) as [s0 |] eqn:Eu.
  - destruct (hsatb cs) eqn:Eh.
    + discriminate.
    + right. intro Hh.
      assert (hsatb cs = true) by (apply (proj2 (hsatb_correct cs)); exact Hh).
      rewrite Eh in H0. discriminate.
  - left. reflexivity.
Qed.

Theorem solve4_none_h : forall cs, ~ hsat cs -> forall fuel, solve4 fuel cs = None.
Proof.
  intros cs Hh fuel. unfold solve4.
  destruct (solve3 fuel cs) as [[s3 l3] |] eqn:E3.
  - exfalso. destruct (solve3_sound fuel cs s3 l3 E3) as [_ [_ [_ [Hhs _]]]].
    apply Hh. exact Hhs.
  - destruct (unify fuel (tyEqs (chanProj ChTy cs))) as [s0 |] eqn:Eu.
    + destruct (hsatb cs) eqn:Eh.
      * exfalso. apply (proj1 (hsatb_correct cs)) in Eh. apply Hh. exact Eh.
      * reflexivity.
    + reflexivity.
Qed.

(* 纤维分解：返回解 = τ 主解 ⊕ 特化点链（K 谱系纤维结构的机内化） *)
Theorem solve4_fiber : forall fuel cs s l,
  solve4 fuel cs = Some (s, l) ->
  exists f0 s0 t, unify f0 (tyEqs (chanProj ChTy cs)) = Some s0 /\
                 (forall u, tapply s u = tapply t (tapply s0 u)).
Proof.
  intros fuel cs s l H. unfold solve4 in H.
  destruct (solve3 fuel cs) as [[s3 l3] |] eqn:E3.
  - injection H as Hs Hl. rewrite <- Hs.
    exists fuel, s3, ([] : tsubst).
    split; [exact (solve3_unify fuel cs s3 l3 E3) | intros u; reflexivity].
  - destruct (unify fuel (tyEqs (chanProj ChTy cs))) as [s0 |] eqn:Eu;
      [|discriminate].
    destruct (hsatb cs); [|discriminate].
    inversion H; subst.
    destruct (xascend_app (length cs) cs s0) as [t Ht].
    exists fuel, s0, t. split; [exact Eu |].
    intros u. rewrite Ht. apply tapply_app.
Qed.

(* ================= 二、e 级出口：X 空窗的闭合 ================= *)

Theorem elevel_exit : forall e f0 s0,
  unify f0 (tyEqs (chanProj ChTy (cg e ++ fst (cgT 0 [] e)))) = Some s0 ->
  hsat (cg e ++ fst (cgT 0 [] e)) ->
  exists f s l, infer4 f e = Some (s, l).
Proof.
  intros e f0 s0 Hu Hhsat. unfold infer4.
  destruct (solve4_complete (cg e ++ fst (cgT 0 [] e)) f0 s0 Hu Hhsat)
    as [f [s [l H]]].
  exists f, s, l. exact H.
Qed.

(* 复活定理：Call 项在 solve3 下 ∀fuel None（E.51 elevel_x_vacuous）、
   在 τ∧H 前提下经 solve4 复活——e 级 X 空窗的完整闭合形态 *)
Theorem elevel_resurrection : forall e f0 s0,
  occurs_call e = true ->
  unify f0 (tyEqs (chanProj ChTy (cg e ++ fst (cgT 0 [] e)))) = Some s0 ->
  hsat (cg e ++ fst (cgT 0 [] e)) ->
  (forall f s l, infer3 f e <> Some (s, l))
  /\ (exists f s l, infer4 f e = Some (s, l)).
Proof.
  intros e f0 s0 Hocc Hu Hhsat. split.
  - intros f s l. apply (elevel_x_vacuous e f s l Hocc).
  - apply (elevel_exit e f0 s0); assumption.
Qed.

(* ================= 三、solve5：dropck 严格性档 2 门 ================= *)

Definition solve5 (fuel : nat) (cs : list constr) : option (tsubst * cmap) :=
  match solve4 fuel cs with
  | Some (s, l) => if hsat2b cs then Some (s, l) else None
  | None => None
  end.

Theorem solve5_sound : forall fuel cs s l,
  solve5 fuel cs = Some (s, l) ->
  unifies s (tyEqs (chanProj ChTy cs)) /\
  phsat l (chanProj ChPhi cs) /\
  (forall m, phsat m (chanProj ChPhi cs) -> cle l m) /\
  hsat2 cs /\ xsat s cs.
Proof.
  intros fuel cs s l H. unfold solve5 in H.
  destruct (solve4 fuel cs) as [[s4 l4] |] eqn:E4; [|discriminate].
  destruct (hsat2b cs) eqn:E2; [|discriminate].
  injection H as Hs Hl. rewrite <- Hs, <- Hl.
  destruct (solve4_sound fuel cs s4 l4 E4) as [H1 [H2 [H3 [H4 H5]]]].
  split; [exact H1 |].
  split; [exact H2 |].
  split; [exact H3 |].
  split.
  - exact (proj1 (hsat2b_correct cs) E2).
  - exact H5.
Qed.

(* 档 2 剖面：命中 ⇔ 档 2 见证 ∧ τ 可解（X 经上升恒可达） *)
Theorem solve5_profile : forall cs,
  (exists fuel s l, solve5 fuel cs = Some (s, l))
  <-> (hsat2 cs /\ exists f0 s0,
         unify f0 (tyEqs (chanProj ChTy cs)) = Some s0).
Proof.
  intros cs. split.
  - intros [fuel [s [l H]]].
    destruct (solve5_sound fuel cs s l H) as [_ [_ [_ [H2 _]]]].
    assert (Htau : exists f0 s0,
              unify f0 (tyEqs (chanProj ChTy cs)) = Some s0).
    { apply (solve4_profile cs).
      exists fuel, s, l. unfold solve5 in H.
      destruct (solve4 fuel cs) as [[s4 l4] |] eqn:E4; [|discriminate].
      destruct (hsat2b cs); [|discriminate]. exact H. }
    split; [exact H2 | exact Htau].
  - intros [H2 [f0 [s0 Hu]]].
    assert (Hhsat : hsat cs) by (apply (hsat2_implies_hsat cs); exact H2).
    destruct (solve4_complete cs f0 s0 Hu Hhsat) as [fuel [s [l H4]]].
    exists fuel, s, l. unfold solve5.
    rewrite H4. rewrite (proj2 (hsat2b_correct cs) H2). reflexivity.
Qed.

(* 档 2 的 None 源：τ ∪ ¬hsat2 *)
Theorem solve5_none : forall fuel cs,
  solve5 fuel cs = None ->
  unify fuel (tyEqs (chanProj ChTy cs)) = None \/ ~ hsat2 cs.
Proof.
  intros fuel cs H. unfold solve5 in H.
  destruct (solve4 fuel cs) as [[s4 l4] |] eqn:E4.
  - destruct (hsat2b cs) eqn:E2.
    + discriminate.
    + right. intro H2.
      assert (hsat2b cs = true) by (apply (proj2 (hsat2b_correct cs)); exact H2).
      rewrite E2 in H0. discriminate.
  - destruct (solve4_none fuel cs E4) as [Htau | Hh1].
    + left. exact Htau.
    + right. intro H2. apply Hh1.
      apply (hsat2_implies_hsat cs). exact H2.
Qed.

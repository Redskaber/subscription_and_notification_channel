(* ===================================================================== *)
(*  效应能力流形 · W-M3-2 · Solve3：X/R/H 求解义务接入 solve2（主清偿）     *)
(*                                                                         *)
(*  E.46 轮挂账 W-M3-2 的清偿模块：                                         *)
(*    solve3 = solve2 ⊕ 三义务（R 供给 H 的闭包 + H 见证 + X 主解现形）      *)
(*                                                                         *)
(*  调度拓扑（盲性矩阵决定的线性序，无回摆——单遍许可证）：                  *)
(*    τ（产 σ）→ R（产闭包）→ H（消费闭包判见证）→ X（消费 σ 判现形）        *)
(*    φ 孤立（对 σ/闭包均盲——lphi_xapply_invar）                            *)
(*                                                                         *)
(*  定理组：                                                                *)
(*    solve3_sound / solve3_complete / solve3_principal（三件套）           *)
(*    xsat_mgu_equiv     X 主解读数的良定性（与燃料无关）                    *)
(*    solve3_none_h      H 阻塞 ⇒ ∀fuel None（SEARCH_FAIL 非空类其一）      *)
(*    solve3_none_x      X 阻塞 ⇒ ∀fuel None（其二）                        *)
(*    assembly_profile   组装剖面（E.46 组装坍缩的修正——翻案 #25）          *)
(*    tau_rigid          τ 通道无区域等式安排（安排流量零）                  *)
(*    blind_conservations 盲性守恒总定理（φ/R/H 对现形全盲；X 唯一非盲）     *)
(*    x_sigma_sensitive  X 非盲格的实机见证                                  *)
(*    elevel_x_vacuous   e 级 X 空窗（Call 种子的区域在主解下恒不现形——     *)
(*                       cgT 语法无 TBorrow，主解像恒自由——W-M3-3 出口）    *)
(* ===================================================================== *)

Require Import List Lia PeanoNat Bool.
Import ListNotations.
Require Import Mult Cap Syntax CG Tau TyCG Lphi Fusion Mu Xsub M3Fusion
               Rsat Hsat.

Local Open Scope bool_scope.

(* ================= 一、X 义务判定器（xsat 的布尔化） ================= *)

Definition xsat1 (s : tsubst) (c : constr) : bool :=
  match c with
  | CXr r t => roccurs r (tapply s t)
  | _ => true
  end.

Definition xsatb (s : tsubst) (cs : list constr) : bool :=
  forallb (xsat1 s) cs.

Lemma xsatb_correct : forall s cs, xsatb s cs = true <-> xsat s cs.
Proof.
  intros s cs. unfold xsatb, xsat. rewrite forallb_forall. split.
  - intros H c Hc. specialize (H c Hc).
    destruct c as [x y | r1 r2 | c k | c c' w | l r | l | r t]; try exact I.
    exact H.
  - intros H c Hc. specialize (H c Hc).
    destruct c as [x y | r1 r2 | c k | c c' w | l r | l | r t];
      try reflexivity.
    exact H.
Qed.

(* ================= 二、solve3 与 e 级包装 ================= *)

Definition solve3 (fuel : nat) (cs : list constr) : option (tsubst * cmap) :=
  match solve2 fuel cs with
  | None => None
  | Some (s, l) =>
      if hsatb cs then (if xsatb s cs then Some (s, l) else None) else None
  end.

Definition infer3 (fuel : nat) (e : tm) : option (tsubst * cmap) :=
  solve3 fuel (cg e ++ fst (cgT 0 [] e)).

(* solve3 命中 ⇒ 其 σ 来自 τ 判定器（主解出口） *)
Lemma solve3_unify : forall fuel cs s l,
  solve3 fuel cs = Some (s, l) ->
  unify fuel (tyEqs (chanProj ChTy cs)) = Some s.
Proof.
  intros fuel cs s l H. unfold solve3, solve2 in H.
  destruct (unify fuel (tyEqs (chanProj ChTy cs))) as [s1 |] eqn:Eu.
  - simpl in H.
    destruct (hsatb cs); [|discriminate].
    destruct (xsatb s1 cs); [|discriminate].
    inversion H; subst. reflexivity.
  - discriminate.
Qed.

(* solve3 命中 ⇒ solve2 同燃料命中（复用既有三件套的桥） *)
Lemma solve3_solve2 : forall fuel cs s l,
  solve3 fuel cs = Some (s, l) -> solve2 fuel cs = Some (s, l).
Proof.
  intros fuel cs s l H. unfold solve3 in H.
  destruct (solve2 fuel cs) as [[s0 l0] |] eqn:E2; [|discriminate].
  destruct (hsatb cs); [|discriminate].
  destruct (xsatb s0 cs); [|discriminate].
  inversion H; subst. reflexivity.
Qed.

(* ================= 三、三件套 ================= *)

(* 可靠性：命中 ⇒ τ 解 + φ 最小解 + H 见证 + X 现形 *)
Theorem solve3_sound : forall fuel cs s l,
  solve3 fuel cs = Some (s, l) ->
  unifies s (tyEqs (chanProj ChTy cs)) /\
  phsat l (chanProj ChPhi cs) /\
  (forall m, phsat m (chanProj ChPhi cs) -> cle l m) /\
  hsat cs /\ xsat s cs.
Proof.
  intros fuel cs s l H.
  assert (H2 := solve3_solve2 fuel cs s l H).
  destruct (solve2_sound fuel cs s l H2) as [Hty Hphi].
  assert (Hmin := solve2_phi_min fuel cs s l H2).
  unfold solve3 in H. rewrite H2 in H. simpl in H.
  destruct (hsatb cs) eqn:Eh; [|discriminate].
  destruct (xsatb s cs) eqn:Ex; [|discriminate].
  inversion H; subst; clear H.
  repeat split.
  - exact Hty.
  - exact Hphi.
  - exact Hmin.
  - apply (proj1 (hsatb_correct cs)). exact Eh.
  - apply (proj1 (xsatb_correct s cs)). exact Ex.
Qed.

(* 完备性：τ 判定器命中（主解 s0）+ H 见证 + 主解现形 ⇒ 命中 *)
Theorem solve3_complete : forall cs fuel0 s0,
  unify fuel0 (tyEqs (chanProj ChTy cs)) = Some s0 ->
  hsat cs ->
  xsat s0 cs ->
  exists fuel s l, solve3 fuel cs = Some (s, l).
Proof.
  intros cs fuel0 s0 Hu Hhsat Hxsat.
  assert (H2 : solve2 fuel0 cs = Some (s0, lphi (chanProj ChPhi cs))).
  { unfold solve2. rewrite Hu. reflexivity. }
  exists fuel0, s0, (lphi (chanProj ChPhi cs)).
  unfold solve3. rewrite H2.
  rewrite (proj2 (hsatb_correct cs) Hhsat).
  rewrite (proj2 (xsatb_correct s0 cs) Hxsat).
  reflexivity.
Qed.

(* 联合主性：继承 solve2_principal（σ mgu × l lfp） *)
Theorem solve3_principal : forall fuel cs s l,
  solve3 fuel cs = Some (s, l) ->
  (forall s', unifies s' (tyEqs (chanProj ChTy cs)) ->
     exists t, forall u, tapply s' u = tapply t (tapply s u))
  /\ (forall m', phsat m' (chanProj ChPhi cs) -> cle l m').
Proof.
  intros fuel cs s l H.
  exact (solve2_principal fuel cs s l (solve3_solve2 fuel cs s l H)).
Qed.

(* X 谱系传递：命中解的 X 读数被一切 τ 解继承 *)
Theorem solve3_x_principal : forall fuel cs s l s',
  solve3 fuel cs = Some (s, l) ->
  unifies s' (tyEqs (chanProj ChTy cs)) ->
  xsat s' cs.
Proof.
  intros fuel cs s l s' H Hs'.
  destruct (solve3_sound fuel cs s l H) as [_ [_ [_ [_ Hxs]]]].
  destruct (solve3_principal fuel cs s l H) as [Hpr _].
  destruct (Hpr s' Hs') as [t Ht].
  exact (xsat_principal_mono cs s s' t Ht Hxs).
Qed.

(* ================= 四、X 主解读数的良定性与 None 证明力 ================= *)

(* 主解读数与燃料无关（两个 mgu 输出的 xsat 等价） *)
Lemma xsat_mgu_equiv : forall cs f1 f2 s1 s2,
  unify f1 (tyEqs (chanProj ChTy cs)) = Some s1 ->
  unify f2 (tyEqs (chanProj ChTy cs)) = Some s2 ->
  xsat s1 cs -> xsat s2 cs.
Proof.
  intros cs f1 f2 s1 s2 H1 H2 Hxs.
  assert (Hu2 : unifies s2 (tyEqs (chanProj ChTy cs)))
    by (apply (unify_sound f2); exact H2).
  destruct (unify_mgu f1 _ s1 H1 s2 Hu2) as [t Ht].
  exact (xsat_principal_mono cs s1 s2 t Ht Hxs).
Qed.

(* H 阻塞：孤儿租约 ⇒ 对任意燃料 None（SEARCH_FAIL 非空类·其一） *)
Theorem solve3_none_h : forall cs l,
  In (CEnd l) cs ->
  (forall r, ~ In (CHr l r) cs) ->
  forall fuel s m, solve3 fuel cs <> Some (s, m).
Proof.
  intros cs l Hin Hno fuel s m Hhit.
  destruct (solve3_sound fuel cs s m Hhit) as [_ [_ [_ [Hhsat _]]]].
  destruct (Hhsat l Hin) as [r [r0 [Hseed _]]].
  apply (Hno r0). exact Hseed.
Qed.

(* X 阻塞：主解不现形 ⇒ 对任意燃料 None（SEARCH_FAIL 非空类·其二） *)
Theorem solve3_none_x : forall cs f0 s0,
  unify f0 (tyEqs (chanProj ChTy cs)) = Some s0 ->
  ~ xsat s0 cs ->
  forall fuel s l, solve3 fuel cs <> Some (s, l).
Proof.
  intros cs f0 s0 Hu Hnx fuel s l Hhit.
  destruct (solve3_sound fuel cs s l Hhit) as [_ [_ [_ [_ Hxs]]]].
  apply Hnx.
  destruct (unify_mgu fuel _ s (solve3_unify fuel cs s l Hhit) s0
               (unify_sound f0 _ s0 Hu)) as [t Ht].
  exact (xsat_principal_mono cs s s0 t Ht Hxs).
Qed.

(* 组装剖面：solve3 命中 ⇔ H 见证 ∧ τ 主解现形
   （E.46 组装坍缩 assembly_collapse 的 solve3 修正——
    "联合可解 ⇔ τ 可解"的单分量叙事终结，见 THEORY.md 翻案 #25） *)
Theorem assembly_profile : forall cs,
  (exists fuel s l, solve3 fuel cs = Some (s, l))
  <-> (hsat cs /\ exists f0 s0,
         unify f0 (tyEqs (chanProj ChTy cs)) = Some s0 /\ xsat s0 cs).
Proof.
  intros cs. split.
  - intros [fuel [s [l H]]].
    destruct (solve3_sound fuel cs s l H) as [_ [_ [_ [Hhsat Hxs]]]].
    split; [exact Hhsat|].
    exists fuel, s. split; [exact (solve3_unify fuel cs s l H) | exact Hxs].
  - intros [Hhsat [f0 [s0 [Hu Hxs]]]].
    destruct (solve3_complete cs f0 s0 Hu Hhsat Hxs) as [fuel [s [l H]]].
    exists fuel, s, l. exact H.
Qed.

(* ================= 五、安排流量零与盲性矩阵 ================= *)

(* τ 刚性：TBorrow 标签合一强制标签相等——τ 通道不产生区域等式安排 *)
Theorem tau_rigid : forall fuel E s r1 r2 a b,
  unify fuel ((TBorrow r1 a, TBorrow r2 b) :: E) = Some s ->
  r1 = r2.
Proof.
  intros fuel E s r1 r2 a b Hu.
  assert (Hun : unifies s ((TBorrow r1 a, TBorrow r2 b) :: E))
    by (apply (unify_sound fuel); exact Hu).
  simpl in Hun. destruct Hun as [Heq _].
  rewrite (tapply_borrow s r1 a), (tapply_borrow s r2 b) in Heq.
  inversion Heq; reflexivity.
Qed.

(* 盲性守恒总定理：φ/R/H 对现形全盲（单遍许可证）；X 的非盲见下一定理 *)
Theorem blind_conservations : forall s cs,
  lphi (chanProj ChPhi (xapply s cs)) = lphi (chanProj ChPhi cs)
  /\ rclose (xapply s cs) = rclose cs
  /\ hclose (xapply s cs) = hclose cs
  /\ (hsat (xapply s cs) <-> hsat cs).
Proof.
  intros s cs. split.
  - apply lphi_xapply_invar.
  - split.
    + apply rclose_xapply_invar.
    + split.
      * apply hclose_xapply_invar.
      * apply hsat_xapply_invar.
Qed.

(* X 非盲格见证：同一池上不同 σ 的 X 读数可翻转（现形的语义实质） *)
Definition xwitness_pool : list constr := [CXr 3 (TVar 1)].
Definition xwitness_s : tsubst := [(1, TBorrow 3 (TVar 7))].

Theorem x_sigma_sensitive :
  xsat xwitness_s xwitness_pool /\ ~ xsat [] xwitness_pool.
Proof.
  split.
  - intros c Hc. destruct Hc as [Heq | []]. subst c. reflexivity.
  - intros H. specialize (H (CXr 3 (TVar 1)) (or_introl eq_refl)).
    simpl in H. discriminate.
Qed.

(* ================= 六、TBorrow 自由性与 e 级 X 空窗 ================= *)

Fixpoint tbfree (t : ty) : bool :=
  match t with
  | TVar _ => true
  | TArrow a b => tbfree a && tbfree b
  | TBorrow _ _ => false
  end.

Definition epair_free (e : ty * ty) : bool :=
  tbfree (fst e) && tbfree (snd e).

Definition eqs_free (E : list (ty * ty)) : bool := forallb epair_free E.

Definition subst_free (s : tsubst) : bool :=
  forallb (fun xt => tbfree (snd xt)) s.

Lemma eqs_free_cons_inv : forall u v E,
  eqs_free ((u, v) :: E) = true ->
  tbfree u = true /\ tbfree v = true /\ eqs_free E = true.
Proof.
  intros u v E H. unfold eqs_free in H. simpl in H.
  apply andb_true_iff in H. destruct H as [Huv HE].
  unfold epair_free in Huv. simpl in Huv.
  apply andb_true_iff in Huv. destruct Huv as [Hu Hv].
  repeat split; assumption.
Qed.

Lemma eqs_free_cons : forall u v E,
  tbfree u = true -> tbfree v = true -> eqs_free E = true ->
  eqs_free ((u, v) :: E) = true.
Proof.
  intros u v E Hu Hv HE.
  unfold eqs_free. simpl.
  apply andb_true_iff. split.
  - unfold epair_free. simpl. rewrite Hu, Hv. reflexivity.
  - exact HE.
Qed.

Lemma tsubst1_tbfree : forall x t u,
  tbfree t = true -> tbfree u = true -> tbfree (tsubst1 x t u) = true.
Proof.
  intros x t u Ht. induction u as [m | a IHa b IHb | r a IHa]; simpl; intros Hu.
  - destruct (Nat.eqb m x); [exact Ht | reflexivity].
  - apply andb_true_iff in Hu. destruct Hu as [Ha Hb].
    apply andb_true_iff. split; [exact (IHa Ha) | exact (IHb Hb)].
  - discriminate.
Qed.

Lemma spair_free : forall x t e,
  tbfree t = true -> epair_free e = true ->
  epair_free (spair x t e) = true.
Proof.
  intros x t [u v] Ht Hv. unfold epair_free in *. simpl.
  apply andb_true_iff in Hv. destruct Hv as [Hu Hvv].
  apply andb_true_iff. split.
  - exact (tsubst1_tbfree x t u Ht Hu).
  - exact (tsubst1_tbfree x t v Ht Hvv).
Qed.

Lemma map_spair_free : forall x t E,
  tbfree t = true -> eqs_free E = true ->
  eqs_free (map (spair x t) E) = true.
Proof.
  intros x t E Ht. induction E as [|e E IH]; simpl; intros HE;
    [reflexivity|].
  destruct (eqs_free_cons_inv (fst e) (snd e) E HE) as [He1 [He2 HE']].
  assert (Hep : epair_free e = true).
  { unfold epair_free; simpl. rewrite He1, He2. reflexivity. }
  unfold eqs_free. simpl.
  rewrite (spair_free x t e Ht Hep).
  apply andb_true_iff. split; [reflexivity | exact (IH HE')].
Qed.

(* 自由代换的 cons 封闭（避开 simpl 折叠歧义的桥引理） *)
Lemma subst_free_cons : forall x t s,
  tbfree t = true -> subst_free s = true ->
  subst_free ((x, t) :: s) = true.
Proof.
  intros x t s Ht Hs. unfold subst_free. simpl.
  rewrite Ht. exact Hs.
Qed.

(* 自由方程的合一器是自由代换（unify 不引入 TBorrow） *)
Lemma unify_free : forall fuel E,
  eqs_free E = true -> forall s, unify fuel E = Some s -> subst_free s = true.
Proof.
  induction fuel as [|n IH]; intros E HE s Hu.
  - destruct E as [|[u v] E']; simpl in Hu.
    + injection Hu as Hu; subst s. reflexivity.
    + discriminate Hu.
  - destruct E as [|[u v] E']; simpl in Hu.
    + injection Hu as Hu; subst s. reflexivity.
    + destruct (eqs_free_cons_inv u v E' HE) as [Hu2 [Hv2 HE']].
      destruct u as [x | a1 a2 | r a]; destruct v as [y | b1 b2 | r' b];
        simpl in Hu; simpl in Hu2; try discriminate;
        simpl in Hv2; try discriminate.
      { (* TVar x, TVar y *)
        destruct (Nat.eqb x y) eqn:Eeq; simpl in Hu.
        - apply (IH E'); assumption.
        - destruct (unify n (map (spair x (TVar y)) E')) eqn:Hu3;
            [|discriminate].
          injection Hu as Hs. subst s.
          apply subst_free_cons; [reflexivity |].
          apply (IH (map (spair x (TVar y)) E'));
            [apply map_spair_free; [reflexivity | exact HE'] | exact Hu3]. }
      { (* TVar x, TArrow b1 b2 *)
        destruct (occursb x (TArrow b1 b2)) eqn:Eoc; simpl in Hu;
          [discriminate |].
        destruct (unify n (map (spair x (TArrow b1 b2)) E')) eqn:Hu3;
            [|discriminate].
        injection Hu as Hs. subst s.
        apply subst_free_cons; [exact Hv2 |].
        apply (IH (map (spair x (TArrow b1 b2)) E'));
            [apply map_spair_free; [exact Hv2 | exact HE'] | exact Hu3]. }
      { (* TArrow a1 a2, TVar y *)
        apply (IH ((TVar y, TArrow a1 a2) :: E')); [|exact Hu].
        apply eqs_free_cons; [reflexivity | exact Hu2 | exact HE']. }
      { (* TArrow a1 a2, TArrow b1 b2 *)
        apply (IH ((a1, b1) :: (a2, b2) :: E')); [|exact Hu].
        apply andb_true_iff in Hu2. destruct Hu2 as [Ha1 Ha2].
        apply andb_true_iff in Hv2. destruct Hv2 as [Hb1 Hb2].
        apply eqs_free_cons; [exact Ha1 | exact Hb1 |].
        apply eqs_free_cons; [exact Ha2 | exact Hb2 | exact HE']. }
Qed.

(* tapply 在自由代换下保持自由 *)
Lemma tapply_tbfree : forall s u,
  subst_free s = true -> tbfree u = true -> tbfree (tapply s u) = true.
Proof.
  intros s u. revert u.
  induction s as [|[x t] s' IH]; intros u Hs Hu; simpl.
  - exact Hu.
  - apply andb_true_iff in Hs. destruct Hs as [Ht Hs'].
    apply IH; [exact Hs' | exact (tsubst1_tbfree x t u Ht Hu)].
Qed.

(* 自由类型无区域出现 *)
Lemma tbfree_roccurs_false : forall t r,
  tbfree t = true -> roccurs r t = false.
Proof.
  induction t as [x | a IHa b IHb | r' a IHa]; simpl; intros r Ht.
  - reflexivity.
  - apply andb_true_iff in Ht. destruct Ht as [Ha Hb].
    rewrite (IHa r Ha), (IHb r Hb). reflexivity.
  - discriminate.
Qed.

(* tyEqs 与拼接可换（e 级池的方程重组用） *)
Lemma tyEqs_app : forall A B, tyEqs (A ++ B) = tyEqs A ++ tyEqs B.
Proof.
  induction A as [|[a b | r1 r2 | c k | c c' w | l r | l | r t] A IH];
    intros B; simpl; auto.
  rewrite IH. reflexivity.
Qed.

(* eqs_free 与拼接 *)
Lemma eqs_free_app_iff : forall A B,
  eqs_free (A ++ B) = true <-> eqs_free A = true /\ eqs_free B = true.
Proof.
  intros A B. unfold eqs_free. rewrite forallb_app, andb_true_iff.
  reflexivity.
Qed.

(* cgT 生成的方程恒 TBorrow 自由（λ 层语法无借用形状） *)
Lemma cgT_eqs_free : forall e p G,
  eqs_free (tyEqs (fst (cgT p G e))) = true.
Proof.
  induction e as [x | x e IH | r | r l | l | e1 IH1 e2 IH2 | c k e IH | e IH];
    intros p G.
  - reflexivity.
  - (* Lam *)
    simpl.
    destruct (cgT (S (S p)) (S p :: G) e) as [cs p'] eqn:E.
    specialize (IH (S (S p)) (S p :: G)). rewrite E in IH.
    simpl. exact IH.
  - reflexivity.
  - reflexivity.
  - reflexivity.
  - (* Call *)
    simpl.
    destruct (cgT (S p) G e1) as [cs1 q1] eqn:E1.
    specialize (IH1 (S p) G). rewrite E1 in IH1. simpl.
    destruct (cgT q1 G e2) as [cs2 q2] eqn:E2.
    specialize (IH2 q1 G). rewrite E2 in IH2. simpl.
    rewrite tyEqs_app.
    apply (proj2 (eqs_free_app_iff (tyEqs cs1) (tyEqs cs2))).
    split; [exact IH1 | exact IH2].
  - (* Grant *)
    simpl.
    destruct (cgT (S p) G e) as [cs p'] eqn:E.
    specialize (IH (S p) G). rewrite E in IH. exact IH.
  - (* Slice *)
    simpl.
    destruct (cgT (S p) G e) as [cs p'] eqn:E.
    specialize (IH (S p) G). rewrite E in IH. exact IH.
Qed.

(* e 级池的方程恒自由：τ 方程全部来自 cgT（cg 无 CTy） *)
Lemma elevel_eqs_free : forall e,
  eqs_free (tyEqs (chanProj ChTy (cg e ++ fst (cgT 0 [] e)))) = true.
Proof.
  intros e.
  rewrite tyEqs_proj.
  assert (Hcg : tyEqs (cg e) = []).
  { rewrite <- (tyEqs_proj (cg e)). rewrite cg_no_cty. reflexivity. }
  rewrite tyEqs_app, Hcg, app_nil_l.
  apply cgT_eqs_free.
Qed.

(* Call 种子恒在 cg 池中 *)
Fixpoint occurs_call (e : tm) : bool :=
  match e with
  | Var _ | New _ | Borrow _ _ | Drop _ => false
  | Lam _ e' => occurs_call e'
  | Call _ _ => true
  | Grant _ _ e' => occurs_call e'
  | Slice e' => occurs_call e'
  end.

Lemma cg_call_seed : forall e,
  occurs_call e = true ->
  In (CXr 0 (TArrow (TVar 0) (TVar 1))) (cg e).
Proof.
  induction e as [x | x e IH | r | r l | l | e1 IH1 e2 IH2 | c k e IH | e IH];
    intros Hocc; simpl in Hocc; try discriminate.
  - rewrite cg_lam. apply in_or_app. left. apply IH. exact Hocc.
  - rewrite cg_call. apply in_or_app. right. apply in_or_app. right. simpl.
    left. reflexivity.
  - rewrite cg_grant. apply in_or_app. left. apply IH. exact Hocc.
  - rewrite cg_slice. apply in_or_app. left. apply IH. exact Hocc.
Qed.

(* e 级 X 空窗：含 Call 的项，其 X 义务（Call 种子的区域 0）
   在主解下恒不现形 ⇒ infer3 对任意燃料 None。
   根因：cgT 语法无 TBorrow（λ 层无借用形状签名）⇒ mgu 像恒自由
   ⇒ 区域 0 从不进入主解像。出口 = W-M3-3 的特化搜索
   （安排枚举 / DPLL(T) case-split）或 λ 层签名扩展。 *)
Theorem elevel_x_vacuous : forall e f s l,
  occurs_call e = true ->
  infer3 f e <> Some (s, l).
Proof.
  intros e f s l Hocc Hhit. unfold infer3 in Hhit.
  destruct (solve3_sound f (cg e ++ fst (cgT 0 [] e)) s l Hhit)
    as [_ [_ [_ [_ Hxs]]]].
  assert (Hseed : In (CXr 0 (TArrow (TVar 0) (TVar 1)))
                    (cg e ++ fst (cgT 0 [] e))).
  { apply in_or_app. left. exact (cg_call_seed e Hocc). }
  specialize (Hxs (CXr 0 (TArrow (TVar 0) (TVar 1))) Hseed).
  simpl in Hxs.
  assert (Hf : subst_free s = true).
  { apply (unify_free f (tyEqs (chanProj ChTy (cg e ++ fst (cgT 0 [] e))))).
    - apply elevel_eqs_free.
    - exact (solve3_unify f (cg e ++ fst (cgT 0 [] e)) s l Hhit). }
  assert (Htb : tbfree (tapply s (TArrow (TVar 0) (TVar 1))) = true)
    by (apply tapply_tbfree; [exact Hf | reflexivity]).
  rewrite (tbfree_roccurs_false (tapply s (TArrow (TVar 0) (TVar 1))) 0 Htb)
    in Hxs.
  discriminate.
Qed.

(* ===================================================================== *)
(*  效应能力流形 · W-LAM-2 · SigStack：嵌套签名栈（诺特栈律的载体）         *)
(*                                                                         *)
(*  第 50 轮（#272–#281）· 文献锚 E.71（新增 E.71–E.75）                    *)
(*  清偿对象：嵌套签名栈（W-LAM-1 的自然外推——用户点名备选升格默认：        *)
(*  多级 λ 各带签名，变量供给序与多签名方程交互）。                         *)
(*                                                                         *)
(*  扩展形态（正交层——tm/constr/ty 语法零改动，8 原语恒定第 50 轮）：        *)
(*    cgK sigs p G e —— 签名栈 sigs 沿 λ 脊柱逐层消耗：                     *)
(*      每个 Lam 弹出栈顶 sig 作为该层绑定变量的注记方程                     *)
(*      （CTy (TVar (S p)) sig —— 绑定锚定，对照 cgS 的入口锚定）；          *)
(*      栈尽（sigs = []）退化为 cgT（零注记基线）。                          *)
(*    栈位 i ↔ 遍历序第 i 个 Lam ↔ 绑定变量 α_{p_i+1}——                    *)
(*    栈消耗序与 cgT 供给计数器 p 同步推进（"供给序与签名方程交互"）。        *)
(*                                                                         *)
(*  诺特栈律（本轮的诺特定律设计——N3 在栈世界的精细化）：                    *)
(*    荷源   cgK_labels      —— 荷不出栈：池的区域标签全部来自签名栈，       *)
(*                              项的 λ 结构零标签（τ 方程恒 TBorrow 自由）。 *)
(*    流形   noether_stack_flow_dim —— 流形维数 = |grounds|^|rvars|：       *)
(*                              键空间与值空间都是栈标签派生——流是栈局部的。 *)
(*    同调   noether_stack_coherence —— 共享荷 ⇒ 线性流形：多层共享同一 ρ    *)
(*                              时流不随深度相乘（一支决策全层生效）。        *)
(*    深度   noether_stack_flow_zero —— 无荷栈 ⇒ 流零（任意深度）：          *)
(*                              栈深不生流——流的指数是荷数，不是深度。       *)
(*  正面实机（C 组合子 λx.λy.y x 迫使两层签名相遇：五池流梯度）见             *)
(*  M36Example.v。                                                          *)
(* ===================================================================== *)

Require Import List Lia PeanoNat Bool.
Import ListNotations.
Require Import Mult Cap Syntax CG Tau TyCG Lphi Fusion Mu Xsub M3Fusion
               Rsat Hsat Solve3 Xcone Drop2 Gphi Solve4
               SigLam Noether Rvar.

Local Open Scope bool_scope.

(* ================= 一、嵌套签名栈的约束生成 ================= *)

(* cgK：签名栈沿 λ 脊柱消耗。
   Lam 弹栈顶作绑定注记（α_{S p} = sig）；栈尽退化为 cgT。
   Var/Call/Grant/Slice/New/Borrow/Drop 与 cgT 逐字相同（栈只在 Lam 消耗）。 *)
Fixpoint cgK (sigs : list ty) (p : nat) (G : list nat) (e : tm) {struct e}
  : list constr * nat :=
  match e with
  | Var x => ([CTy (TVar p) (TVar (nth x G p))], S p)
  | Lam x e' =>
      match sigs with
      | [] =>
          let (cs, p') := cgK [] (S (S p)) (S p :: G) e' in
          (CTy (TVar p) (TArrow (TVar (S p)) (TVar (S (S p)))) :: cs, p')
      | sig :: sigs' =>
          let (cs, p') := cgK sigs' (S (S p)) (S p :: G) e' in
          (CTy (TVar (S p)) sig
           :: CTy (TVar p) (TArrow (TVar (S p)) (TVar (S (S p)))) :: cs, p')
      end
  | New _ => ([], S p)
  | Borrow _ _ => ([], S p)
  | Drop _ => ([], S p)
  | Call e1 e2 =>
      let (cs1, p1) := cgK sigs (S p) G e1 in
      let (cs2, p2) := cgK sigs p1 G e2 in
      (CTy (TVar (S p)) (TArrow (TVar p1) (TVar p)) :: (cs1 ++ cs2), p2)
  | Grant _ _ e' =>
      let (cs, p') := cgK sigs (S p) G e' in (cs, p')
  | Slice e' =>
      let (cs, p') := cgK sigs (S p) G e' in (cs, p')
  end.

(* 签名词表（类型变量）与签名标签表（区域标签） *)
Definition sigvars (sigs : list ty) : list nat := concat (map tvars sigs).
Definition siglabels (sigs : list ty) : list nat := concat (map tlabels sigs).

Lemma siglabels_tl_incl : forall sig sigs x,
  In x (siglabels sigs) -> In x (siglabels (sig :: sigs)).
Proof. intros sig sigs x H. simpl. apply in_or_app. right. exact H. Qed.

Lemma sigvars_tl_incl : forall sig sigs x,
  In x (sigvars sigs) -> In x (sigvars (sig :: sigs)).
Proof. intros sig sigs x H. simpl. apply in_or_app. right. exact H. Qed.

Lemma allabels_cons : forall c cs, allabels (c :: cs) = clabels c ++ allabels cs.
Proof. intros c cs. reflexivity. Qed.

Lemma allabels_app : forall A B, allabels (A ++ B) = allabels A ++ allabels B.
Proof.
  induction A as [|c A IH]; intros B.
  - reflexivity.
  - cbn [app]. rewrite allabels_cons, allabels_cons, IH, app_assoc.
    reflexivity.
Qed.

(* ================= 二、A 组：退化形态与血统 ================= *)

(* A1. 栈尽恒等：空栈 = 零注记基线（cgK [] = cgT）。 *)
Theorem cgK_nil : forall e p G, cgK [] p G e = cgT p G e.
Proof.
  induction e as [x | x e IH | r | r l | l | e1 IH1 e2 IH2 | c k e IH | e IH];
    intros p G; simpl.
  - reflexivity.
  - (* Lam：scrutinee 在绑定器之外，rewrite 可达 *)
    rewrite IH. reflexivity.
  - reflexivity.
  - reflexivity.
  - reflexivity.
  - (* Call：嵌套 let——内层 scrutinee 在外层绑定器之下，
     rewrite 穿不透（m35 §8 教训同族）；destruct 复原 cgT_grow 模式 *)
    destruct (cgK [] (S p) G e1) as [cs1 q1] eqn:E1.
    destruct (cgK [] q1 G e2) as [cs2 q2] eqn:E2.
    destruct (cgT (S p) G e1) as [ds1 r1] eqn:F1.
    destruct (cgT r1 G e2) as [ds2 r2] eqn:F2.
    pose proof (IH1 (S p) G) as H1. rewrite E1, F1 in H1.
    injection H1 as Hc1 Hq1. subst r1. subst ds1.
    pose proof (IH2 q1 G) as H2. rewrite E2, F2 in H2.
    injection H2 as Hc2 Hq2. subst r2. subst ds2.
    reflexivity.
  - rewrite IH. reflexivity.
  - rewrite IH. reflexivity.
Qed.

(* A2. 单栈位 = 绑定锚定的 cgS：一元栈在 Lam 首项上产生
      "签名方程 :: cgT 方程集"——与 cgS（E.61，入口锚定 α_p）同形，
      锚点从入口移到绑定（α_{S p}）。W-LAM-1 血统的定理面。 *)
Theorem cgK_single : forall sig x e p G,
  cgK [sig] p G (Lam x e)
  = (CTy (TVar (S p)) sig :: fst (cgT p G (Lam x e)),
     snd (cgT p G (Lam x e))).
Proof.
  intros sig x e p G. simpl.
  rewrite (cgK_nil e (S (S p)) (S p :: G)).
  destruct (cgT (S (S p)) (S p :: G) e) as [cs0 p0] eqn:E.
  cbn. reflexivity.
Qed.

(* ================= 三、B 组：供给与通道守恒（N1/N2 侧） ================= *)

(* B1. 供给增长：每个节点至少消耗自己的自变量（栈不触计数器）。 *)
Theorem cgK_grow : forall e sigs p G cs p',
  cgK sigs p G e = (cs, p') -> p < p'.
Proof.
  induction e as [x | x e IH | r | r l | l | e1 IH1 e2 IH2 | c k e IH | e IH];
    intros sigs p G cs p' H; simpl in H.
  - injection H as _ Hp'. subst p'. lia.
  - destruct sigs as [|sig sigs'].
    + destruct (cgK [] (S (S p)) (S p :: G) e) as [cs0 p0] eqn:E.
      injection H as _ Hp'. subst p'.
      pose proof (IH [] (S (S p)) (S p :: G) cs0 p0 E). lia.
    + destruct (cgK sigs' (S (S p)) (S p :: G) e) as [cs0 p0] eqn:E.
      injection H as _ Hp'. subst p'.
      pose proof (IH sigs' (S (S p)) (S p :: G) cs0 p0 E). lia.
  - injection H as _ Hp'. subst p'. lia.
  - injection H as _ Hp'. subst p'. lia.
  - injection H as _ Hp'. subst p'. lia.
  - destruct (cgK sigs (S p) G e1) as [cs1 q1] eqn:E1.
    destruct (cgK sigs q1 G e2) as [cs2 q2] eqn:E2.
    injection H as _ Hp'. subst p'.
    pose proof (IH1 sigs (S p) G cs1 q1 E1).
    pose proof (IH2 sigs q1 G cs2 q2 E2). lia.
  - destruct (cgK sigs (S p) G e) as [cs0 q] eqn:E.
    injection H as _ Hp'. subst p'.
    pose proof (IH sigs (S p) G cs0 q E). lia.
  - destruct (cgK sigs (S p) G e) as [cs0 q] eqn:E.
    injection H as _ Hp'. subst p'.
    pose proof (IH sigs (S p) G cs0 q E). lia.
Qed.

(* B2. 供给—词表二分：池中每个类型变量，要么落在供给窗（[p,p') 或环境 G），
      要么是签名词表成员——变量来源只有这两个（供给序与签名交互的守恒面）。 *)
Theorem cgK_range_ext : forall e sigs p G,
  (forall w, In w G -> w < p) ->
  forall cs p', cgK sigs p G e = (cs, p') ->
  forall v, In v (flat_map ctyVars cs) ->
  (v < p' /\ (p <= v \/ In v G)) \/ In v (sigvars sigs).
Proof.
  induction e as [x | x e IH | r | r l | l | e1 IH1 e2 IH2 | c k e IH | e IH];
    intros sigs p G HG cs p' H v Hv; simpl in H.
  - (* Var *)
    injection H as Hcs Hp'. subst cs p'. simpl in Hv.
    destruct Hv as [Hv | [Hv | []]].
    + subst v. left. split; [lia | left; lia].
    + destruct (Nat.lt_ge_cases x (length G)) as [Hlt | Hge].
      * pose proof (nth_In_aux G x p Hlt) as Hn.
        specialize (HG _ Hn). subst v.
        left. split; [lia | right; exact Hn].
      * rewrite nth_overflow in Hv by exact Hge.
        left. split; [lia | left; lia].
  - (* Lam *)
    destruct sigs as [|sig sigs'].
    + (* 栈尽：发射与 cgT 逐字相同 *)
      destruct (cgK [] (S (S p)) (S p :: G) e) as [cs0 p0] eqn:E.
      injection H as Hcs Hp'. subst cs p'.
      pose proof (cgK_grow e [] (S (S p)) (S p :: G) cs0 p0 E) as Hg.
      assert (HG' : forall w, In w (S p :: G) -> w < S (S p))
        by (intros w [Hw | Hw]; [subst w; lia | specialize (HG w Hw); lia]).
      specialize (IH [] (S (S p)) (S p :: G) HG' cs0 p0 E).
      simpl in Hv.
      destruct Hv as [H1 | [H1 | [H1 | H2]]].
      * subst v. left. split; [lia | left; lia].
      * subst v. left. split; [lia | left; lia].
      * subst v. left. split; [lia | left; lia].
      * destruct (IH v H2) as [[Hup [Hlo | HIn]] | Hsv].
        -- left. split; [lia | left; lia].
        -- destruct HIn as [Hv | HIn].
           ++ subst v. left. split; [lia | left; lia].
           ++ left. split; [lia | right; exact HIn].
        -- simpl in Hsv. contradiction.
    + (* 栈顶消耗：sig-eq + arrow-eq + 体 *)
      destruct (cgK sigs' (S (S p)) (S p :: G) e) as [cs0 p0] eqn:E.
      injection H as Hcs Hp'. subst cs p'.
      pose proof (cgK_grow e sigs' (S (S p)) (S p :: G) cs0 p0 E) as Hg.
      assert (HG' : forall w, In w (S p :: G) -> w < S (S p))
        by (intros w [Hw | Hw]; [subst w; lia | specialize (HG w Hw); lia]).
      specialize (IH sigs' (S (S p)) (S p :: G) HG' cs0 p0 E).
      simpl in Hv.
      destruct Hv as [H1 | H2].
      * subst v. left. split; [lia | left; lia].
      * apply in_app_or in H2. destruct H2 as [Ht | H3].
        -- right. simpl. apply in_or_app. left. exact Ht.
        -- destruct H3 as [H1 | [H1 | [H1 | H2]]].
           ++ subst v. left. split; [lia | left; lia].
           ++ subst v. left. split; [lia | left; lia].
           ++ subst v. left. split; [lia | left; lia].
           ++ destruct (IH v H2) as [[Hup [Hlo | HIn]] | Hsv].
              ** left. split; [lia | left; lia].
              ** destruct HIn as [Hv | HIn].
                 --- subst v. left. split; [lia | left; lia].
                 --- left. split; [lia | right; exact HIn].
              ** right. apply sigvars_tl_incl. exact Hsv.
  - (* New *) injection H as Hcs Hp'. subst cs. simpl in Hv. contradiction.
  - (* Borrow *) injection H as Hcs Hp'. subst cs. simpl in Hv. contradiction.
  - (* Drop *) injection H as Hcs Hp'. subst cs. simpl in Hv. contradiction.
  - (* Call *)
    destruct (cgK sigs (S p) G e1) as [cs1 q1] eqn:E1.
    destruct (cgK sigs q1 G e2) as [cs2 q2] eqn:E2.
    injection H as Hcs Hp'. subst cs p'.
    pose proof (cgK_grow e1 sigs (S p) G cs1 q1 E1) as Hg1.
    pose proof (cgK_grow e2 sigs q1 G cs2 q2 E2) as Hg2.
    assert (HG1 : forall w, In w G -> w < S p)
      by (intros w Hw; specialize (HG w Hw); lia).
    assert (HG2 : forall w, In w G -> w < q1)
      by (intros w Hw; specialize (HG w Hw); lia).
    specialize (IH1 sigs (S p) G HG1 cs1 q1 E1).
    specialize (IH2 sigs q1 G HG2 cs2 q2 E2).
    simpl in Hv.
    destruct Hv as [H1 | [H1 | [H1 | H2]]].
    + subst v. left. split; [lia | left; lia].
    + subst v. left. split; [lia | left; lia].
    + subst v. left. split; [lia | left; lia].
    + rewrite flat_map_app in H2. apply in_app_or in H2.
      destruct H2 as [H2 | H2].
      * destruct (IH1 v H2) as [[Hup [Hlo | HIn]] | Hsv].
        -- left. split; [lia | left; lia].
        -- left. split; [lia | right; exact HIn].
        -- right. exact Hsv.
      * destruct (IH2 v H2) as [[Hup [Hlo | HIn]] | Hsv].
        -- left. split; [lia | left; lia].
        -- left. split; [lia | right; exact HIn].
        -- right. exact Hsv.
  - (* Grant *)
    destruct (cgK sigs (S p) G e) as [cs0 q] eqn:E.
    injection H as Hcs Hp'. subst cs p'.
    assert (HG1 : forall w, In w G -> w < S p)
      by (intros w Hw; specialize (HG w Hw); lia).
    specialize (IH sigs (S p) G HG1 cs0 q E).
    pose proof (cgK_grow e sigs (S p) G cs0 q E) as Hg.
    destruct (IH v Hv) as [[Hup [Hlo | HIn]] | Hsv].
    + left. split; [lia | left; lia].
    + left. split; [lia | right; exact HIn].
    + right. exact Hsv.
  - (* Slice *)
    destruct (cgK sigs (S p) G e) as [cs0 q] eqn:E.
    injection H as Hcs Hp'. subst cs p'.
    assert (HG1 : forall w, In w G -> w < S p)
      by (intros w Hw; specialize (HG w Hw); lia).
    specialize (IH sigs (S p) G HG1 cs0 q E).
    pose proof (cgK_grow e sigs (S p) G cs0 q E) as Hg.
    destruct (IH v Hv) as [[Hup [Hlo | HIn]] | Hsv].
    + left. split; [lia | left; lia].
    + left. split; [lia | right; exact HIn].
    + right. exact Hsv.
Qed.

(* B3. φ 盲性：栈世界全在 τ 通道——φ 投影恒空（N2 规范对称面在栈世界保持）。 *)
Lemma cgK_phi_nil_pair : forall e sigs p G cs p',
  cgK sigs p G e = (cs, p') -> chanProj ChPhi cs = [].
Proof.
  induction e as [x | x e IH | r | r l | l | e1 IH1 e2 IH2 | c k e IH | e IH];
    intros sigs p G cs p' H; simpl in H.
  - injection H as Hcs _. subst cs. reflexivity.
  - destruct sigs as [|sig sigs'].
    + destruct (cgK [] (S (S p)) (S p :: G) e) as [cs0 p0] eqn:E.
      injection H as Hcs _. subst cs.
      rewrite chanProj_phi_cons_cty.
      apply (IH [] (S (S p)) (S p :: G) cs0 p0 E).
    + destruct (cgK sigs' (S (S p)) (S p :: G) e) as [cs0 p0] eqn:E.
      injection H as Hcs _. subst cs.
      rewrite chanProj_phi_cons_cty, chanProj_phi_cons_cty.
      apply (IH sigs' (S (S p)) (S p :: G) cs0 p0 E).
  - injection H as Hcs _. subst cs. reflexivity.
  - injection H as Hcs _. subst cs. reflexivity.
  - injection H as Hcs _. subst cs. reflexivity.
  - destruct (cgK sigs (S p) G e1) as [cs1 q1] eqn:E1.
    destruct (cgK sigs q1 G e2) as [cs2 q2] eqn:E2.
    injection H as Hcs _. subst cs.
    rewrite chanProj_phi_cons_cty, chanProj_app.
    rewrite (IH1 sigs (S p) G cs1 q1 E1), (IH2 sigs q1 G cs2 q2 E2).
    reflexivity.
  - destruct (cgK sigs (S p) G e) as [cs0 q] eqn:E.
    injection H as Hcs _. subst cs.
    apply (IH sigs (S p) G cs0 q E).
  - destruct (cgK sigs (S p) G e) as [cs0 q] eqn:E.
    injection H as Hcs _. subst cs.
    apply (IH sigs (S p) G cs0 q E).
Qed.

Theorem cgK_phi_nil : forall e sigs p G,
  chanProj ChPhi (fst (cgK sigs p G e)) = [].
Proof.
  intros e sigs p G.
  destruct (cgK sigs p G e) as [cs p'] eqn:E.
  cbn [fst]. apply (cgK_phi_nil_pair e sigs p G cs p' E).
Qed.

(* B4. 锥封闭保持（N1 侧）：签名栈方程只是 τ 方程——实例锥封闭无条件
      （instance_sound 只依赖 tapply 组合律），特化无需重跑合一。 *)
Theorem sigstack_cone_intact : forall E s t,
  unifies s E -> unifies (s ++ t) E.
Proof.
  intros E s t H. apply instance_sound. exact H.
Qed.

(* ================= 四、C 组：荷源定理（N3 荷侧） ================= *)

(* C1. 栈尽自由性的推广：TBorrow 自由的栈 ⇒ cgK 方程集自由
      （cgT_eqs_free 的栈世界推广——E.51 elevel_eqs_free 血统）。 *)
Lemma cgK_eqs_free_pair : forall e sigs p G cs p',
  cgK sigs p G e = (cs, p') ->
  (forall s, In s sigs -> tbfree s = true) ->
  eqs_free (tyEqs cs) = true.
Proof.
  induction e as [x | x e IH | r | r l | l | e1 IH1 e2 IH2 | c k e IH | e IH];
    intros sigs p G cs p' H Hfree; simpl in H.
  - injection H as Hcs _. subst cs. reflexivity.
  - destruct sigs as [|sig sigs'].
    + destruct (cgK [] (S (S p)) (S p :: G) e) as [cs0 p0] eqn:E.
      injection H as Hcs _. subst cs.
      cbn [tyEqs].
      apply eqs_free_cons; [reflexivity | reflexivity |].
      apply (IH [] (S (S p)) (S p :: G) cs0 p0 E).
      intros s Hs. destruct Hs.
    + destruct (cgK sigs' (S (S p)) (S p :: G) e) as [cs0 p0] eqn:E.
      injection H as Hcs _. subst cs.
      cbn [tyEqs].
      apply eqs_free_cons; [reflexivity | apply Hfree; left; reflexivity |].
      apply eqs_free_cons; [reflexivity | reflexivity |].
      apply (IH sigs' (S (S p)) (S p :: G) cs0 p0 E).
      intros s Hs. apply Hfree. right. exact Hs.
  - injection H as Hcs _. subst cs. reflexivity.
  - injection H as Hcs _. subst cs. reflexivity.
  - injection H as Hcs _. subst cs. reflexivity.
  - destruct (cgK sigs (S p) G e1) as [cs1 q1] eqn:E1.
    destruct (cgK sigs q1 G e2) as [cs2 q2] eqn:E2.
    injection H as Hcs _. subst cs.
    cbn [tyEqs].
    apply eqs_free_cons; [reflexivity | reflexivity |].
    rewrite tyEqs_app.
    apply (proj2 (eqs_free_app_iff (tyEqs cs1) (tyEqs cs2))).
    split; [apply (IH1 sigs (S p) G cs1 q1 E1); exact Hfree
           | apply (IH2 sigs q1 G cs2 q2 E2); exact Hfree].
  - destruct (cgK sigs (S p) G e) as [cs0 q] eqn:E.
    injection H as Hcs _. subst cs.
    apply (IH sigs (S p) G cs0 q E). exact Hfree.
  - destruct (cgK sigs (S p) G e) as [cs0 q] eqn:E.
    injection H as Hcs _. subst cs.
    apply (IH sigs (S p) G cs0 q E). exact Hfree.
Qed.

Theorem cgK_eqs_free : forall e sigs p G,
  (forall s, In s sigs -> tbfree s = true) ->
  eqs_free (tyEqs (fst (cgK sigs p G e))) = true.
Proof.
  intros e sigs p G Hfree.
  destruct (cgK sigs p G e) as [cs p'] eqn:E.
  cbn [fst]. apply (cgK_eqs_free_pair e sigs p G cs p' E Hfree).
Qed.

(* C2. 荷源定理：荷不出栈——池的区域标签全部来自签名栈。
      项的 λ 结构（cgT 侧）零标签（τ 方程恒 TBorrow 自由——cgT_eqs_free）。 *)
Theorem cgK_labels : forall e sigs p G cs p',
  cgK sigs p G e = (cs, p') ->
  forall x, In x (allabels cs) -> In x (siglabels sigs).
Proof.
  induction e as [x | x e IH | r | r l | l | e1 IH1 e2 IH2 | c k e IH | e IH];
    intros sigs p G cs p' H y Hy; simpl in H.
  - (* Var：clabels (CTy (TVar _) (TVar _)) = [] *)
    injection H as Hcs _. subst cs. simpl in Hy. contradiction.
  - (* Lam *)
    destruct sigs as [|sig sigs'].
    + destruct (cgK [] (S (S p)) (S p :: G) e) as [cs0 p0] eqn:E.
      injection H as Hcs _. subst cs. simpl in Hy.
      apply (IH [] (S (S p)) (S p :: G) cs0 p0 E). exact Hy.
    + destruct (cgK sigs' (S (S p)) (S p :: G) e) as [cs0 p0] eqn:E.
      injection H as Hcs _. subst cs. simpl in Hy.
      apply in_app_or in Hy. destruct Hy as [Hy | Hy].
      * simpl. apply in_or_app. left. exact Hy.
      * apply siglabels_tl_incl.
        apply (IH sigs' (S (S p)) (S p :: G) cs0 p0 E). exact Hy.
  - injection H as Hcs _. subst cs. simpl in Hy. contradiction.
  - injection H as Hcs _. subst cs. simpl in Hy. contradiction.
  - injection H as Hcs _. subst cs. simpl in Hy. contradiction.
  - (* Call *)
    destruct (cgK sigs (S p) G e1) as [cs1 q1] eqn:E1.
    destruct (cgK sigs q1 G e2) as [cs2 q2] eqn:E2.
    injection H as Hcs _. subst cs.
    rewrite allabels_cons, allabels_app in Hy.
    apply in_app_or in Hy. destruct Hy as [Hy | Hy].
    + (* calleq 零标签（τ 结构无借用形状） *)
      cbn [clabels tlabels] in Hy. contradiction.
    + apply in_app_or in Hy. destruct Hy as [Hy | Hy].
      * apply (IH1 sigs (S p) G cs1 q1 E1). exact Hy.
      * apply (IH2 sigs q1 G cs2 q2 E2). exact Hy.
  - destruct (cgK sigs (S p) G e) as [cs0 q] eqn:E.
    injection H as Hcs _. subst cs.
    apply (IH sigs (S p) G cs0 q E). exact Hy.
  - destruct (cgK sigs (S p) G e) as [cs0 q] eqn:E.
    injection H as Hcs _. subst cs.
    apply (IH sigs (S p) G cs0 q E). exact Hy.
Qed.

(* 去重的成员反向保持（dedupN 只删重复——集合不变） *)
Lemma dedupN_In_rev : forall l x, In x (dedupN l) -> In x l.
Proof.
  induction l as [|a l IH]; intros x Hin; simpl in *; [contradiction|].
  destruct (existsb (fun b => a =? b) (dedupN l)) eqn:E.
  - (* a 被丢弃：dedupN (a::l) = dedupN l——直接走 IH *)
    right. apply IH. exact Hin.
  - (* a 保留：头保留或尾 *)
    destruct Hin as [Heq | Hin].
    + left. exact Heq.
    + right. apply IH. exact Hin.
Qed.

(* TBorrow 自由 ⇒ 零标签 *)
Lemma tbfree_tlabels_nil : forall t, tbfree t = true -> tlabels t = [].
Proof.
  induction t as [x | a IHa b IHb | r t' IHt]; intros H; simpl in *.
  - reflexivity.
  - apply andb_true_iff in H. destruct H as [Ha Hb].
    rewrite (IHa Ha), (IHb Hb). reflexivity.
  - discriminate.
Qed.

Lemma siglabels_cons : forall sig sigs,
  siglabels (sig :: sigs) = tlabels sig ++ siglabels sigs.
Proof. intros sig sigs. reflexivity. Qed.

(* 全栈零标签 ⇒ siglabels = [] *)
Lemma tbfree_stack_labels_nil : forall sigs,
  (forall s, In s sigs -> tbfree s = true) -> siglabels sigs = [].
Proof.
  induction sigs as [|sig sigs IH]; intros H.
  - reflexivity.
  - rewrite siglabels_cons, (tbfree_tlabels_nil sig (H sig (or_introl eq_refl))).
    simpl. apply IH. intros s Hs. apply H. right. exact Hs.
Qed.

(* C3. 无荷栈 ⇒ 池零荷（rvars = grounds = []——流零前提）。 *)
Theorem cgK_charge_free : forall e sigs p G cs p',
  cgK sigs p G e = (cs, p') ->
  (forall s, In s sigs -> tbfree s = true) ->
  rvars cs = [] /\ grounds cs = [].
Proof.
  intros e sigs p G cs p' H Hfree.
  assert (Hlab : siglabels sigs = []) by (apply tbfree_stack_labels_nil; exact Hfree).
  assert (Hall : allabels cs = []).
  { destruct (allabels cs) as [|x rest] eqn:EA; [reflexivity|].
    exfalso.
    assert (Hin : In x (allabels cs)) by (rewrite EA; left; reflexivity).
    pose proof (cgK_labels e sigs p G cs p' H x Hin) as Hx.
    rewrite Hlab in Hx. destruct Hx. }
  split; unfold rvars, grounds; rewrite Hall; reflexivity.
Qed.

(* ================= 五、D 组：诺特栈律（N3 流侧的栈形态） ================= *)

(* D0a. flat_map 恒步长帮手：枚举一层 = 候选数 × 尾长度。 *)
Lemma flat_map_map_length : forall (cands : list nat) (r : nat)
                                 (L : list (list (nat * nat))),
  length (flat_map (fun rest => map (fun c => (r, c) :: rest) cands) L)
  = length cands * length L.
Proof.
  intros cands r L. induction L as [|a L IH]; simpl.
  - rewrite Nat.mul_0_r. reflexivity.
  - rewrite length_app, length_map, IH, Nat.mul_succ_r. lia.
Qed.

(* D0b. 枚举步长：单变量弹出的枚举长度 = 候选数 × 尾枚举长度。 *)
Lemma assigns_step_length : forall cands rvs r,
  length (assigns cands (r :: rvs))
  = length cands * length (assigns cands rvs).
Proof.
  intros cands rvs r. cbn [assigns]. apply flat_map_map_length.
Qed.

(* D0c. 流形维数公式：枚举长度 = 候选数 ^ 变量数（通用池事实）。 *)
Theorem assigns_cardinality : forall cands rvs,
  length (assigns cands rvs) = (length cands) ^ (length rvs).
Proof.
  intros cands rvs. induction rvs as [|r rvs IH].
  - reflexivity.
  - rewrite assigns_step_length, IH. reflexivity.
Qed.

(* D1. 诺特栈律 · 流形：安排计划长度 = |grounds|^|rvars|。
      流的指数是荷数——不是栈深、不是方程数。 *)
Theorem noether_stack_flow_dim : forall cs,
  length (arrange_plan cs) = (length (grounds cs)) ^ (length (rvars cs)).
Proof. intros cs. unfold arrange_plan. apply assigns_cardinality. Qed.

(* D2. 诺特栈律 · 栈局部：cgK 池的安排流——键是变量标签、值是地面标签，
      两者都不出签名标签表（决策空间栈内生成）。 *)
Theorem noether_stack_flow_local : forall e sigs p G cs p' rho,
  cgK sigs p G e = (cs, p') ->
  In rho (arrange_plan cs) ->
  forall k v, In (k, v) rho ->
  rvarb k = true /\ negb (rvarb v) = true
  /\ In k (siglabels sigs) /\ In v (siglabels sigs).
Proof.
  intros e sigs p G cs p' rho H Hin k v Hkv.
  unfold arrange_plan in Hin.
  destruct (assigns_domain (grounds cs) (rvars cs) rho Hin k v Hkv) as [Hk Hv].
  unfold rvars in Hk. apply filter_In in Hk. destruct Hk as [Hkd Hkb].
  unfold grounds in Hv. apply filter_In in Hv. destruct Hv as [Hvd Hvb].
  split; [exact Hkb|]. split; [exact Hvb|]. split.
  - apply (cgK_labels e sigs p G cs p' H).
    apply dedupN_In_rev. exact Hkd.
  - apply (cgK_labels e sigs p G cs p' H).
    apply dedupN_In_rev. exact Hvd.
Qed.

(* D3. 诺特栈律 · 同调：共享荷 ⇒ 线性流形。
      池只有一个区域变量时（多层签名共享 ρ），安排计划 = 每候选恰一支
      ——流不随栈深相乘（一支决策全层生效）。 *)
Theorem noether_stack_coherence : forall cs rho,
  rvars cs = [rho] ->
  arrange_plan cs = map (fun g => [(rho, g)]) (grounds cs).
Proof. intros cs rho H. unfold arrange_plan. rewrite H. apply assigns_single. Qed.

(* D4. 诺特栈律 · 深度：无荷栈 ⇒ 流零（任意深度）。
      栈深不生流——深二零荷栈与无栈基线同流形：恒等一支。
      （noether_N3_flow_zero 的 cgK 池实例化。） *)
Theorem noether_stack_flow_zero : forall e sigs p G cs p' fuel,
  cgK sigs p G e = (cs, p') ->
  (forall s, In s sigs -> tbfree s = true) ->
  rvars cs = [] /\
  arrange_trials fuel cs = 1 /\
  solve6 fuel cs = match solve4 fuel cs with
                   | Some (s, l) => Some (s, l, [])
                   | None => None end.
Proof.
  intros e sigs p G cs p' fuel H Hfree.
  pose proof (cgK_charge_free e sigs p G cs p' H Hfree) as [Hrv _].
  destruct (noether_N3_flow_zero fuel cs Hrv) as [Ht Hs].
  split; [exact Hrv | split; [exact Ht | exact Hs]].
Qed.

(* D5. 诺特栈律 · 对偶整合：
      荷侧——无荷栈 ⇒ 流零（任意深度）；
      流侧——荷破 ⇒ 流皆非恒等（noether_N3_flow_nonidentity 的通用池面）。
      正面对照（荷破 ⇒ 引擎/安排分歧——流出现且分支）见 M36Example。 *)
Theorem noether_stack_duality :
  (forall e sigs p G cs p' fuel,
     cgK sigs p G e = (cs, p') ->
     (forall s, In s sigs -> tbfree s = true) ->
     rvars cs = [] /\
     arrange_trials fuel cs = 1 /\
     solve6 fuel cs = match solve4 fuel cs with
                      | Some (s, l) => Some (s, l, [])
                      | None => None end)
  /\ (forall cs, rvars cs <> [] ->
        forall rho, In rho (arrange_plan cs) -> rho <> []).
Proof.
  split.
  - apply noether_stack_flow_zero.
  - apply noether_N3_flow_nonidentity.
Qed.

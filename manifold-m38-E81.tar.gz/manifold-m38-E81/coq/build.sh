#!/usr/bin/env bash
# 效应能力流形 · DPLL(T) 增量面 + flow_total 一般化（诺特增量律）—— 构建脚本
# 依赖：coqc ∈ PATH（见 ../setup/ 国内代理安装脚本，或系统 Coq ≥ 8.15）
# 模块序：M1 基座 → M2 → W-M2-1 → M3 → W-M3-2 → W-M3-3 → W-M3-GFP
#         → 组装（Solve4）→ 实例（M33Example）
#         → 第 48 轮（SigLam Noether M34Example）
#         → 第 49 轮（Rvar M35Example）
#         → 第 50 轮（SigStack M36Example）
#         → 第 51 轮（Ineq SibLam M37Example）
#         → 第 56 轮新增（DpllT FlowTotal M38Example）
set -e
cd "$(dirname "$0")"
echo "== Coq 版本 =="
coqc --version
for f in Mult Cap Syntax CG Example Tau TyCG Lphi Fusion M2Example Mu Wm21Example Xsub M3Fusion M3Example Rsat Hsat Solve3 M32Example Xcone Drop2 Gphi Solve4 M33Example SigLam Noether M34Example Rvar M35Example SigStack M36Example Ineq SibLam M37Example DpllT FlowTotal M38Example; do
  echo "== coqc $f.v =="
  coqc -Q . '' "$f.v"
done
echo "== ALL OK =="

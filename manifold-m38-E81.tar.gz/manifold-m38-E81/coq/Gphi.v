(* ===================================================================== *)
(*  效应能力流形 · W-M3-GFP · Gphi：φ 通道的 gfp 对偶（comptime 上界侧）     *)
(*                                                                         *)
(*  存量挂账 W-M3-GFP 的清偿模块："gfp 对偶（comptime 上界侧 φ ≤ 0）"。       *)
(*                                                                         *)
(*  lfp 侧（Cap.v/CG.v/Lphi.v，E.39–E.40）：                                 *)
(*    lphi cs = lfp(FC) = 最小解——自 ⊥ 的 Kleene 上升，且是不动点。          *)
(*  gfp 侧（本模块）：三件事——                                              *)
(*    一、解半格定理（phsat_join_closed）：解集对逐点 join 封闭               *)
(*      （FC 是 join-同态：FC(m ⊔ m') = FC m ⊔ FC'——饱和 rig 的分配律）。     *)
(*      注意：解集无上界（能力可任意抬高）——gfp 必须带界谈。                  *)
(*    二、受限最大解（gphi cs u）：上界 u 下的最大容许解——                    *)
(*      存在性 ⟺ 容许非空；构造 = 有限载体枚举的逐点 join（3^|D| 空间，      *)
(*      D = capsOf cs——Kleene 界 2|D|+1 的枚举对偶）。                        *)
(*      【对偶不对称】lfp 是不动点；受限最大解不必是不动点（§实例 m33_gphi_    *)
(*      not_fix）——Tarski 两侧的真差。                                       *)
(*    三、comptime 门（comptimeb）：u := ⊥ 的特例——φ ≤ 0 可容许 ⟺ 零需求      *)
(*      （CLv 的 k 全 0 ∧ CPr 的 w 全 0）——可判定。                          *)
(*    四、真 gfp（gfp cs）：FC 的最大前不动点 = 最大不动点（载体支撑、        *)
(*      join-同态下前不动点亦 join-封闭）——Cousot² 构造性 Tarski 的枚举形。   *)
(*                                                                         *)
(*  主定理：                                                                *)
(*    phsat_join_closed   解半格（join-同态心脏）                             *)
(*    gphi_admissible     （容许非空 ⇒ 最大容许解存在：解 ∧ ≤u ∧ 最大性）    *)
(*    comptimeb_correct   comptime 门 = 零需求判定                            *)
(*    lphi_le_gphi        两极关系：最小解 ≤ 最大容许解（容许非空时）        *)
(*    gfp_exists          真 gfp：最大前不动点存在 = 不动点 = 最大性          *)
(* ===================================================================== *)

Require Import List Lia PeanoNat Bool.
Import ListNotations.
Require Import Mult Cap Syntax CG Tau TyCG Lphi.

Local Open Scope bool_scope.

(* ================= 一、mlub 格代数补全 ================= *)

Lemma mlub_idem : forall a, mlub a a = a.
Proof. intros a; destruct a; reflexivity. Qed.

Lemma mlub_comm : forall a b, mlub a b = mlub b a.
Proof. intros a b; destruct a, b; reflexivity. Qed.

Lemma mlub_assoc : forall a b c, mlub a (mlub b c) = mlub (mlub a b) c.
Proof. intros a b c; destruct a, b, c; reflexivity. Qed.

(* 中项交换：格并的 medial 律 *)
Lemma mlub_medial : forall x y z w,
  mlub (mlub x y) (mlub z w) = mlub (mlub x z) (mlub y w).
Proof. intros x y z w; destruct x, y, z, w; reflexivity. Qed.

(* 饱和加对格并的分配律 *)
Lemma mlub_mplus_distr : forall a b w,
  mplus (mlub a b) w = mlub (mplus a w) (mplus b w).
Proof. intros a b w; destruct a, b, w; reflexivity. Qed.

(* ================= 二、逐点 join 与 FC 的 join-同态 ================= *)

Definition cjoin (a b : cmap) : cmap := fun c => mlub (a c) (b c).

(* 贡献算子在逐点 join 下分配 *)
Lemma phContrib_join : forall c0 i a b,
  phContrib c0 i (cjoin a b) = mlub (phContrib c0 i a) (phContrib c0 i b).
Proof.
  intros c0 i a b.
  destruct c0 as [x y | r1 r2 | c k | c1 c2 w | l r | l | r0 t]; try reflexivity.
  - (* CLv：贡献不读解 *)
    unfold phContrib. destruct (cap_eq_dec c i); rewrite mlub_idem; reflexivity.
  - (* CPr：读 c2 一处 *)
    unfold phContrib, cjoin. destruct (cap_eq_dec c1 i).
    + rewrite mlub_mplus_distr. reflexivity.
    + reflexivity.
Qed.

(* FC 是 join-同态（解半格定理的代数心脏） *)
Lemma FC_join : forall cs a b i,
  FC cs (cjoin a b) i = mlub (FC cs a i) (FC cs b i).
Proof.
  intros cs a b i. induction cs as [|c cs IH]; [reflexivity|].
  rewrite !FC_cons, phContrib_join, IH. apply mlub_medial.
Qed.

(* 逐点相等迁移 *)
Lemma phsat_ext : forall m m' cs,
  (forall c, m c = m' c) -> (phsat m cs <-> phsat m' cs).
Proof.
  intros m m' cs H. split; intros Hsat; apply postfix_to_phsat; intros i.
  - rewrite <- (H i), <- (FC_ext cs m m' H).
    exact (phsat_to_postfix cs m Hsat i).
  - rewrite (H i), (FC_ext cs m m' H).
    exact (phsat_to_postfix cs m' Hsat i).
Qed.

(* 解半格定理：解对逐点 join 封闭 *)
Theorem phsat_join_closed : forall cs a b,
  phsat a cs -> phsat b cs -> phsat (cjoin a b) cs.
Proof.
  intros cs a b Ha Hb. apply postfix_to_phsat. intros i.
  rewrite FC_join. apply mlub_least.
  - apply mle_trans with (a i);
      [apply (phsat_to_postfix cs a Ha) | apply mlub_le_l].
  - apply mle_trans with (b i);
      [apply (phsat_to_postfix cs b Hb) | apply mlub_le_r].
Qed.

(* ================= 三、phsat 的可判定化 ================= *)

Definition mleb (a b : mult) : bool := Nat.leb (mrank a) (mrank b).

Lemma mleb_correct : forall a b, mleb a b = true <-> mle a b.
Proof.
  intros a b. unfold mleb, mle. rewrite Nat.leb_le. reflexivity.
Qed.

Fixpoint phsatb (m : cmap) (cs : list constr) : bool :=
  match cs with
  | [] => true
  | CLv c k :: cs' => andb (mleb k (m c)) (phsatb m cs')
  | CPr c c' w :: cs' => andb (mleb (mplus (m c') w) (m c)) (phsatb m cs')
  | _ :: cs' => phsatb m cs'
  end.

Lemma phsatb_correct : forall m cs, phsatb m cs = true <-> phsat m cs.
Proof.
  intros m cs.
  induction cs as [|[a b | r1 r2 | c k | c1 c2 w | l r | l | r0 t] cs IH];
    split; intros H; simpl in H.
  - exact I.
  - reflexivity.
  - apply IH. exact H.
  - apply IH. exact H.
  - apply IH. exact H.
  - apply IH. exact H.
  - apply andb_true_iff in H. destruct H as [H1 H2]. split.
    + apply mleb_correct. exact H1.
    + apply IH. exact H2.
  - destruct H as [H1 H2]. apply andb_true_iff. split.
    + apply mleb_correct. exact H1.
    + apply IH. exact H2.
  - apply andb_true_iff in H. destruct H as [H1 H2]. split.
    + apply mleb_correct. exact H1.
    + apply IH. exact H2.
  - destruct H as [H1 H2]. apply andb_true_iff. split.
    + apply mleb_correct. exact H1.
    + apply IH. exact H2.
  - apply IH. exact H.
  - apply IH. exact H.
  - apply IH. exact H.
  - apply IH. exact H.
  - apply IH. exact H.
  - apply IH. exact H.
Qed.

(* ================= 四、有限载体枚举（Kleene 界的枚举对偶） ================= *)

Definition capeqb (a b : capidx) : bool :=
  match cap_eq_dec a b with left _ => true | right _ => false end.

Lemma capeqb_true : forall a b, capeqb a b = true -> a = b.
Proof.
  intros a b H. unfold capeqb in H.
  destruct (cap_eq_dec a b) as [e | e]; [exact e | discriminate].
Qed.

Lemma capeqb_refl : forall a, capeqb a a = true.
Proof.
  intros a. unfold capeqb. destruct (cap_eq_dec a a); [reflexivity | congruence].
Qed.

(* 值域：≤ v 的全部多重度 *)
Definition vals_le (v : mult) : list mult :=
  match v with M0 => [M0] | M1 => [M0; M1] | MW => [M0; M1; MW] end.

Lemma in_vals_le : forall v u, In v (vals_le u) -> mle v u.
Proof.
  intros [] []; unfold vals_le, mle; simpl; intros H; try lia.
  - destruct H as [H | []]; discriminate.
  - destruct H as [H | []]; discriminate.
  - destruct H as [H | [H | []]]; discriminate.
Qed.

Lemma mle_vals_le : forall v u, mle v u -> In v (vals_le u).
Proof.
  intros [] []; unfold vals_le, mle; simpl; intros H.
  - left; reflexivity.
  - left; reflexivity.
  - left; reflexivity.
  - exfalso; lia.
  - right; left; reflexivity.
  - right; left; reflexivity.
  - exfalso; lia.
  - exfalso; lia.
  - right; right; left; reflexivity.
Qed.

(* 载体 D 上的有限映射空间 *)
Fixpoint mspace (D : list capidx) (u : cmap) : list (list (capidx * mult)) :=
  match D with
  | [] => [[]]
  | d :: D' =>
      flat_map (fun rest => map (fun v => (d, v) :: rest) (vals_le (u d)))
               (mspace D' u)
  end.

(* 表 → 映射（载体外补 0） *)
Definition mof (l : list (capidx * mult)) : cmap :=
  fun c => match find (fun p => capeqb (fst p) c) l with
           | Some p => snd p
           | None => M0
           end.

(* 规范代表：m ≤ u ⇒ 其载体限制在空间中，且 mof 与 m 在载体上一致、处处 ≤ m *)
Lemma canon_correct : forall D u m,
  cle m u ->
  exists l, In l (mspace D u)
            /\ (forall c, In c D -> mof l c = m c)
            /\ (forall c, mle (mof l c) (m c)).
Proof.
  induction D as [|d D IH]; intros u m Hm.
  - exists []. split; [left; reflexivity | split].
    + intros c [].
    + intros c. apply mle_M0.
  - assert (Hm' : cle m u) by exact Hm.
    destruct (IH u m Hm') as [l' [Hin' [Hon' Hle']]].
    exists ((d, m d) :: l'). split.
    + simpl. apply in_flat_map. exists l'. split; [exact Hin'|].
      apply in_map_iff. exists (m d). split; [reflexivity |].
      apply mle_vals_le. apply Hm.
    + split.
      * intros c Hc. simpl in Hc. unfold mof. simpl.
        destruct Hc as [He | Hc].
        -- subst d. rewrite capeqb_refl. reflexivity.
        -- destruct (capeqb d c) eqn:E.
           ++ apply capeqb_true in E. subst d. reflexivity.
           ++ change (mof l' c = m c). apply Hon'. exact Hc.
      * intros c. unfold mof. simpl.
        destruct (capeqb d c) eqn:E.
        ++ apply capeqb_true in E. subst d. apply mle_refl.
        ++ apply Hle'.
Qed.

(* FC 只经载体读取解（载体一致 ⇒ FC 一致） *)
Lemma FC_carrier_ext : forall cs a b,
  (forall c, In c (capsOf cs) -> a c = b c) ->
  forall i, FC cs a i = FC cs b i.
Proof.
  induction cs as [|[x y | r1 r2 | c k | c1 c2 w | l r | l | r0 t] cs IH];
    intros a b Hag i.
  - reflexivity.
  - (* CTy：非 φ 约束，载体不变 *)
    rewrite !FC_cons, (IH a b Hag). reflexivity.
  - (* CRg *)
    rewrite !FC_cons, (IH a b Hag). reflexivity.
  - (* CLv：载体 +{c}，贡献不读解 *)
    rewrite !FC_cons.
    assert (Hsub : forall c', In c' (capsOf cs) -> a c' = b c').
    { intros c' Hc'. apply Hag. simpl. right. exact Hc'. }
    rewrite (IH a b Hsub). unfold phContrib.
    destruct (cap_eq_dec c i); reflexivity.
  - (* CPr：载体 +{c1;c2}，贡献读 c2 *)
    rewrite !FC_cons.
    assert (Hsub : forall c', In c' (capsOf cs) -> a c' = b c').
    { intros c' Hc'. apply Hag. simpl. right. right. exact Hc'. }
    rewrite (IH a b Hsub). unfold phContrib.
    destruct (cap_eq_dec c1 i).
    + assert (Hc2 : In c2 (capsOf (CPr c1 c2 w :: cs)))
        by (simpl; right; left; reflexivity).
      rewrite (Hag c2 Hc2). reflexivity.
    + reflexivity.
  - (* CHr *)
    rewrite !FC_cons, (IH a b Hag). reflexivity.
  - (* CEnd *)
    rewrite !FC_cons, (IH a b Hag). reflexivity.
  - (* CXr *)
    rewrite !FC_cons, (IH a b Hag). reflexivity.
Qed.

(* 空间元素的键都在载体中 *)
Lemma mspace_keys : forall D u l p,
  In l (mspace D u) -> In p l -> In (fst p) D.
Proof.
  induction D as [|d D IH]; intros u l p Hin Hp; simpl in Hin.
  - destruct Hin as [He | []]. subst l. destruct Hp.
  - apply in_flat_map in Hin. destruct Hin as [rest [Hrest Hmap]].
    apply in_map_iff in Hmap. destruct Hmap as [v [Hv Hhead]].
    subst l.
    destruct Hp as [He | Hp].
    + subst p. simpl. left. reflexivity.
    + simpl. right. exact (IH u rest p Hrest Hp).
Qed.

(* 载体外：mof 恒零 *)
Lemma mof_out : forall D u l c,
  In l (mspace D u) -> ~ In c D -> mof l c = M0.
Proof.
  intros D u l c Hin Hout. unfold mof.
  destruct (find (fun p => capeqb (fst p) c) l) as [p |] eqn:Ef.
  - exfalso. apply find_some in Ef. destruct Ef as [Hp Hf].
    apply capeqb_true in Hf.
    apply Hout. rewrite <- Hf. exact (mspace_keys D u l p Hin Hp).
  - reflexivity.
Qed.

(* ================= 五、空间代表 ≤ 上界 ================= *)

Lemma mof_space_le_u : forall D u l, In l (mspace D u) -> cle (mof l) u.
Proof.
  induction D as [|d D IH]; intros u l Hin; simpl in Hin.
  - destruct Hin as [He | []]. subst l. intros c. apply mle_M0.
  - apply in_flat_map in Hin. destruct Hin as [rest [Hrest Hmap]].
    apply in_map_iff in Hmap. destruct Hmap as [v [Heq Hvin]].
    subst l. intros c. unfold mof. simpl.
    destruct (capeqb d c) eqn:E.
    + apply capeqb_true in E. subst c.
      change (mle v (u d)). apply in_vals_le. exact Hvin.
    + change (mle (mof rest c) (u c)). apply IH. exact Hrest.
Qed.

(* ================= 六、gjoin：非空表的逐点 join ================= *)

Lemma cle_ext : forall a b, (forall c, a c = b c) -> cle a b.
Proof. intros a b H c. rewrite H. apply mle_refl. Qed.

Lemma cjoin_le_u : forall a b u,
  cle a u -> cle b u -> cle (cjoin a b) u.
Proof.
  intros a b u Ha Hb c. unfold cjoin. apply mlub_least.
  - apply Ha.
  - apply Hb.
Qed.

Lemma fold_cjoin_le_acc : forall l acc u,
  cle acc u -> (forall m, In m l -> cle m u) ->
  cle (fold_left cjoin l acc) u.
Proof.
  induction l as [|a l IH]; intros acc u Hacc Hall; simpl; [exact Hacc|].
  apply IH.
  - apply cjoin_le_u; [exact Hacc | apply Hall; left; reflexivity].
  - intros m Hm. apply Hall. right. exact Hm.
Qed.

Lemma fold_cjoin_ge_acc : forall l acc, cle acc (fold_left cjoin l acc).
Proof.
  induction l as [|a l IH]; intros acc; simpl; [apply cle_refl|].
  apply cle_trans with (cjoin acc a).
  - intros c. apply mlub_le_l.
  - apply IH.
Qed.

Lemma fold_cjoin_ge_each : forall l acc m,
  In m l -> cle m (fold_left cjoin l acc).
Proof.
  induction l as [|a l IH]; intros acc m Hm; [contradiction|].
  simpl in Hm. destruct Hm as [He | Hm].
  - subst m. simpl.
    apply cle_trans with (cjoin acc a).
    + intros c. apply mlub_le_r.
    + apply fold_cjoin_ge_acc.
  - simpl. apply IH. exact Hm.
Qed.

Lemma fold_cjoin_phsat : forall cs l acc,
  phsat acc cs -> (forall m, In m l -> phsat m cs) ->
  phsat (fold_left cjoin l acc) cs.
Proof.
  induction l as [|a l IH]; intros acc Hacc Hall; simpl; [exact Hacc|].
  apply IH.
  - apply phsat_join_closed;
      [exact Hacc | apply Hall; left; reflexivity].
  - intros m Hm. apply Hall. right. exact Hm.
Qed.

Definition gjoin (l : list cmap) : cmap :=
  match l with
  | [] => cbot
  | m :: l' => fold_left cjoin l' m
  end.

Lemma gjoin_ge : forall l m, In m l -> cle m (gjoin l).
Proof.
  intros l m Hin. destruct l as [|a l]; [contradiction|].
  destruct Hin as [He | Hin].
  - subst a. unfold gjoin. apply fold_cjoin_ge_acc.
  - unfold gjoin. apply fold_cjoin_ge_each. exact Hin.
Qed.

Lemma gjoin_le_u : forall l u,
  (forall m, In m l -> cle m u) -> l <> [] -> cle (gjoin l) u.
Proof.
  intros l u Hall Hne. destruct l as [|a l]; [contradiction|].
  unfold gjoin. apply fold_cjoin_le_acc.
  - apply Hall. left; reflexivity.
  - intros m Hm. apply Hall. right. exact Hm.
Qed.

Lemma gjoin_phsat : forall cs l,
  (forall m, In m l -> phsat m cs) -> l <> [] -> phsat (gjoin l) cs.
Proof.
  intros cs l Hall Hne. destruct l as [|a l]; [contradiction|].
  unfold gjoin. apply fold_cjoin_phsat.
  - apply Hall. left; reflexivity.
  - intros m Hm. apply Hall. right. exact Hm.
Qed.

(* ================= 七、规范代表的可容许性 ================= *)

Lemma canon_phsat : forall cs u m,
  phsat m cs -> cle m u ->
  exists l, In l (mspace (capsOf cs) u) /\ phsat (mof l) cs
            /\ (forall c, In c (capsOf cs) -> mof l c = m c).
Proof.
  intros cs u m Hm Hu.
  destruct (canon_correct (capsOf cs) u m Hu) as [l [Hin [Hon Hle]]].
  exists l. split; [exact Hin | split].
  - apply postfix_to_phsat. intros i.
    destruct (In_dec cap_eq_dec i (capsOf cs)) as [Hi | Hi].
    + rewrite (FC_carrier_ext cs (mof l) m Hon i), (Hon i Hi).
      exact (phsat_to_postfix cs m Hm i).
    + rewrite (FC_out cs (mof l) i Hi). apply mle_M0.
  - exact Hon.
Qed.

(* ================= 八、受限最大解 gphi ================= *)

Definition cands (cs : list constr) (u : cmap) : list cmap :=
  map mof (mspace (capsOf cs) u).

Definition adm (cs : list constr) (u : cmap) : list cmap :=
  filter (fun m => phsatb m cs) (cands cs u).

Definition gphi (cs : list constr) (u : cmap) : cmap :=
  fun c => match In_dec cap_eq_dec c (capsOf cs) with
           | left _ => gjoin (adm cs u) c
           | right _ => u c
           end.

Lemma gphi_carrier : forall cs u c,
  In c (capsOf cs) -> gphi cs u c = gjoin (adm cs u) c.
Proof.
  intros cs u c Hc. unfold gphi.
  destruct (In_dec cap_eq_dec c (capsOf cs)) as [_ | Hne].
  - reflexivity.
  - exfalso. apply Hne. exact Hc.
Qed.

Lemma gphi_out : forall cs u c,
  ~ In c (capsOf cs) -> gphi cs u c = u c.
Proof.
  intros cs u c Hc. unfold gphi.
  destruct (In_dec cap_eq_dec c (capsOf cs)) as [H | _].
  - exfalso. apply Hc. exact H.
  - reflexivity.
Qed.

Lemma adm_sound : forall cs u m,
  In m (adm cs u) ->
  phsat m cs /\ (exists l, In l (mspace (capsOf cs) u) /\ m = mof l).
Proof.
  intros cs u m Hin. unfold adm in Hin.
  apply filter_In in Hin. destruct Hin as [Hin Hb].
  unfold cands in Hin. apply in_map_iff in Hin.
  destruct Hin as [l [Heq Hmem]]. subst m. split.
  - apply (proj1 (phsatb_correct (mof l) cs)). exact Hb.
  - exists l. split; [exact Hmem | reflexivity].
Qed.

Lemma adm_in : forall cs u l,
  In l (mspace (capsOf cs) u) -> phsat (mof l) cs -> In (mof l) (adm cs u).
Proof.
  intros cs u l Hin Hph. unfold adm. apply filter_In. split.
  - unfold cands. apply in_map_iff. exists l.
    split; [reflexivity | exact Hin].
  - apply (proj2 (phsatb_correct (mof l) cs)). exact Hph.
Qed.

(* 主定理：容许非空 ⇒ 最大容许解存在（gfp 对偶的构造性形态） *)
Theorem gphi_admissible : forall cs u,
  (exists m, phsat m cs /\ cle m u) ->
  phsat (gphi cs u) cs /\ cle (gphi cs u) u
  /\ (forall m, phsat m cs -> cle m u -> cle m (gphi cs u)).
Proof.
  intros cs u [m0 [Hm0 Hu0]].
  destruct (canon_phsat cs u m0 Hm0 Hu0) as [l0 [Hin0 [Hph0 Hon0]]].
  assert (Hinadm : In (mof l0) (adm cs u)) by (apply adm_in; assumption).
  assert (Hne : adm cs u <> [])
    by (destruct (adm cs u) as [|a l]; [contradiction | discriminate]).
  assert (Hall : forall m, In m (adm cs u) -> phsat m cs /\ cle m u).
  { intros m Hin. destruct (adm_sound cs u m Hin) as [Hph [l [Hl Heq]]].
    split; [exact Hph |]. subst m. exact (mof_space_le_u (capsOf cs) u l Hl). }
  assert (Hphs : forall m, In m (adm cs u) -> phsat m cs)
    by (intros m Hin; destruct (Hall m Hin) as [H _]; exact H).
  assert (Hus : forall m, In m (adm cs u) -> cle m u)
    by (intros m Hin; destruct (Hall m Hin) as [_ H]; exact H).
  split; [| split].
  - (* 解性：gphi 与 gjoin 在载体上一致，FC 只读载体 *)
    apply postfix_to_phsat. intros i.
    destruct (In_dec cap_eq_dec i (capsOf cs)) as [Hi | Hi].
    + rewrite (FC_carrier_ext cs (gphi cs u) (gjoin (adm cs u))
                  (fun c Hc => gphi_carrier cs u c Hc) i),
              (gphi_carrier cs u i Hi).
      exact (phsat_to_postfix cs (gjoin (adm cs u))
               (gjoin_phsat cs (adm cs u) Hphs Hne) i).
    + rewrite (FC_out cs (gphi cs u) i Hi). apply mle_M0.
  - (* 上界性 *)
    intros c. destruct (In_dec cap_eq_dec c (capsOf cs)) as [Hc | Hc].
    + rewrite (gphi_carrier cs u c Hc).
      apply gjoin_le_u; [exact Hus | exact Hne].
    + unfold gphi.
      destruct (In_dec cap_eq_dec c (capsOf cs)) as [Hne' | _].
      * exfalso. apply Hc. exact Hne'.
      * apply mle_refl.
  - (* 最大性：一切容许解 ≤ gphi *)
    intros m Hm Hu c.
    destruct (In_dec cap_eq_dec c (capsOf cs)) as [Hc | Hc].
    + destruct (canon_phsat cs u m Hm Hu) as [l [Hin [Hph Hon]]].
      rewrite <- (Hon c Hc), (gphi_carrier cs u c Hc).
      apply gjoin_ge. apply adm_in; assumption.
    + rewrite (gphi_out cs u c Hc). apply Hu.
Qed.

(* ================= 九、comptime 门（u := ⊥ 特例） ================= *)

Definition comptimeb (cs : list constr) : bool :=
  forallb (fun c => match c with
                    | CLv _ k => meqb k M0
                    | CPr _ _ w => meqb w M0
                    | _ => true
                    end) cs.

(* comptime 可容许 ⟺ 零需求（φ ≤ 0 的判定形态） *)
Theorem comptimeb_correct : forall cs,
  comptimeb cs = true <-> phsat cbot cs.
Proof.
  intros cs. unfold comptimeb. rewrite forallb_forall. split.
  - intros Hall.
    induction cs as [|[a b | r1 r2 | c k | c1 c2 w | l r | l | r0 t] cs IH];
      simpl; try exact I.
    + (* CTy *) apply IH. intros c0 Hc0. apply Hall. right. exact Hc0.
    + (* CRg *) apply IH. intros c0 Hc0. apply Hall. right. exact Hc0.
    + (* CLv *) assert (Hk : k = M0)
        by (apply (meqb_true k M0); apply (Hall (CLv c k)); left; reflexivity).
      subst k. split; [unfold mle; simpl; lia
                     | apply IH; intros c0 Hc0; apply Hall; right; exact Hc0].
    + (* CPr *) assert (Hw : w = M0)
        by (apply (meqb_true w M0); apply (Hall (CPr c1 c2 w)); left; reflexivity).
      subst w. split; [unfold mle; simpl; lia
                     | apply IH; intros c0 Hc0; apply Hall; right; exact Hc0].
    + (* CHr *) apply IH. intros c0 Hc0. apply Hall. right. exact Hc0.
    + (* CEnd *) apply IH. intros c0 Hc0. apply Hall. right. exact Hc0.
    + (* CXr *) apply IH. intros c0 Hc0. apply Hall. right. exact Hc0.
  - intros Hsat.
    induction cs as [|[a b | r1 r2 | c k | c1 c2 w | l r | l | r0 t] cs IH];
      simpl in Hsat.
    + intros c0 Hc0. destruct Hc0.
    + (* CTy *) intros c0 Hc0.
      destruct c0 as [x y | x y | c' k' | c1' c2' w' | l' r' | l' | r' t'];
        try reflexivity; simpl in Hc0;
        (destruct Hc0 as [He | Hc0]; [discriminate | exact (IH Hsat _ Hc0)]).
    + (* CRg *) intros c0 Hc0.
      destruct c0 as [x y | x y | c' k' | c1' c2' w' | l' r' | l' | r' t'];
        try reflexivity; simpl in Hc0;
        (destruct Hc0 as [He | Hc0]; [discriminate | exact (IH Hsat _ Hc0)]).
    + (* CLv *) intros c0 Hc0.
      destruct c0 as [x y | x y | c' k' | c1' c2' w' | l' r' | l' | r' t'];
        try reflexivity; simpl in Hc0.
      * destruct Hc0 as [He | Hc0].
        -- injection He as Hcx Hkx. subst k'.
           destruct Hsat as [H1 H2]. change (mle k M0) in H1.
           destruct k; [reflexivity | exfalso; unfold mle in H1; simpl in H1; lia
                        | exfalso; unfold mle in H1; simpl in H1; lia].
        -- destruct Hsat as [H1 H2]. exact (IH H2 _ Hc0).
      * destruct Hc0 as [He | Hc0]; [discriminate |].
        destruct Hsat as [H1 H2]. exact (IH H2 _ Hc0).
    + (* CPr *) intros c0 Hc0.
      destruct c0 as [x y | x y | c' k' | c1' c2' w' | l' r' | l' | r' t'];
        try reflexivity; simpl in Hc0.
      * destruct Hc0 as [He | Hc0]; [discriminate |].
        destruct Hsat as [H1 H2]. exact (IH H2 _ Hc0).
      * destruct Hc0 as [He | Hc0].
        -- injection He as Hc1x Hc2x Hwx. subst w'.
           destruct Hsat as [H1 H2]. change (mle w M0) in H1.
           destruct w; [reflexivity | exfalso; unfold mle in H1; simpl in H1; lia
                        | exfalso; unfold mle in H1; simpl in H1; lia].
        -- destruct Hsat as [H1 H2]. exact (IH H2 _ Hc0).
    + (* CHr *) intros c0 Hc0.
      destruct c0 as [x y | x y | c' k' | c1' c2' w' | l' r' | l' | r' t'];
        try reflexivity; simpl in Hc0;
        (destruct Hc0 as [He | Hc0]; [discriminate | exact (IH Hsat _ Hc0)]).
    + (* CEnd *) intros c0 Hc0.
      destruct c0 as [x y | x y | c' k' | c1' c2' w' | l' r' | l' | r' t'];
        try reflexivity; simpl in Hc0;
        (destruct Hc0 as [He | Hc0]; [discriminate | exact (IH Hsat _ Hc0)]).
    + (* CXr *) intros c0 Hc0.
      destruct c0 as [x y | x y | c' k' | c1' c2' w' | l' r' | l' | r' t'];
        try reflexivity; simpl in Hc0;
        (destruct Hc0 as [He | Hc0]; [discriminate | exact (IH Hsat _ Hc0)]).
Qed.

(* comptime 通过 ⇒ gphi 在 ⊥ 界处逐点坍缩到 cbot *)
Theorem gphi_comptime : forall cs c,
  phsat cbot cs -> gphi cs cbot c = cbot c.
Proof.
  intros cs c H.
  destruct (gphi_admissible cs cbot (ex_intro _ cbot (conj H (cle_refl cbot))))
    as [_ [Hle _]].
  specialize (Hle c). unfold mle in Hle.
  assert (Hc0 : mrank (cbot c) = 0) by reflexivity.
  rewrite Hc0 in Hle.
  destruct (gphi cs cbot c) eqn:E; simpl in Hle;
    [reflexivity | exfalso; lia | exfalso; lia].
Qed.

(* ================= 十、两极关系：lfp ≤ 受限 gfp ================= *)

Theorem lphi_le_gphi : forall cs u,
  (exists m, phsat m cs /\ cle m u) -> cle (lphi cs) (gphi cs u).
Proof.
  intros cs u [m0 [Hm0 Hu0]].
  destruct (gphi_admissible cs u (ex_intro _ m0 (conj Hm0 Hu0)))
    as [Hg [Hle Hmax]].
  apply Hmax.
  - exact (proj1 (lphi_solve cs)).
  - apply cle_trans with m0.
    + exact (proj2 (lphi_solve cs) m0 Hm0).
    + exact Hu0.
Qed.

(* ================= 十一、真 gfp：最大前不动点 = 最大不动点 ================= *)

Definition ctop : cmap := fun _ => MW.

Lemma cle_ctop : forall m, cle m ctop.
Proof. intros m c. unfold ctop, mle. simpl. destruct (m c); simpl; lia. Qed.

Definition prefp (cs : list constr) (m : cmap) : Prop := cle m (FC cs m).

Lemma mle_antisym : forall a b, mle a b -> mle b a -> a = b.
Proof.
  intros a b H1 H2. destruct a, b; unfold mle in *; simpl in *;
    try reflexivity; exfalso; lia.
Qed.

(* 前不动点对 join 封闭（join-同态的对偶面） *)
Lemma prefp_join_closed : forall cs a b,
  prefp cs a -> prefp cs b -> prefp cs (cjoin a b).
Proof.
  intros cs a b Ha Hb i. rewrite FC_join. unfold cjoin.
  apply mlub_mono; [exact (Ha i) | exact (Hb i)].
Qed.

Lemma fold_cjoin_prefp : forall cs l acc,
  prefp cs acc -> (forall m, In m l -> prefp cs m) ->
  prefp cs (fold_left cjoin l acc).
Proof.
  induction l as [|a l IH]; intros acc Hacc Hall; simpl; [exact Hacc|].
  apply IH.
  - apply prefp_join_closed;
      [exact Hacc | apply Hall; left; reflexivity].
  - intros m Hm. apply Hall. right. exact Hm.
Qed.

Lemma gjoin_prefp : forall cs l,
  (forall m, In m l -> prefp cs m) -> l <> [] -> prefp cs (gjoin l).
Proof.
  intros cs l Hall Hne. destruct l as [|a l]; [contradiction|].
  unfold gjoin. apply fold_cjoin_prefp.
  - apply Hall. left; reflexivity.
  - intros m Hm. apply Hall. right. exact Hm.
Qed.

Definition prefpb_ (cs : list constr) (m : cmap) : bool :=
  forallb (fun i => mleb (m i) (FC cs m i)) (capsOf cs).

Definition prefps (cs : list constr) : list cmap :=
  filter (fun m => prefpb_ cs m) (cands cs ctop).

Definition gfp (cs : list constr) : cmap := gjoin (prefps cs).

(* ⊥ 的代表在候选中（prefps 非空的根：FC 恒 ≥ 0） *)
Lemma prefpb_cbot : forall cs, prefpb_ cs cbot = true.
Proof.
  intros cs. unfold prefpb_. rewrite forallb_forall.
  intros i Hi. apply mleb_correct. apply mle_M0.
Qed.

Lemma prefps_nonempty : forall cs, exists m, In m (prefps cs).
Proof.
  intros cs.
  destruct (canon_correct (capsOf cs) ctop cbot (cle_ctop cbot))
    as [l [Hin [Hon Hle]]].
  exists (mof l). unfold prefps. apply filter_In. split.
  - unfold cands. apply in_map_iff. exists l.
    split; [reflexivity | exact Hin].
  - unfold prefpb_. rewrite forallb_forall. intros i Hi.
    apply mleb_correct. rewrite (Hon i Hi). apply mle_M0.
Qed.

(* 前不动点的规范代表（载体一致 + 代表本身前不动） *)
Lemma canon_prefp : forall cs m,
  prefp cs m ->
  exists l, In l (mspace (capsOf cs) ctop) /\ prefp cs (mof l)
            /\ (forall c, In c (capsOf cs) -> mof l c = m c).
Proof.
  intros cs m Hp.
  destruct (canon_correct (capsOf cs) ctop m (cle_ctop m))
    as [l [Hin [Hon Hle]]].
  exists l. split; [exact Hin | split].
  - intros i. destruct (In_dec cap_eq_dec i (capsOf cs)) as [Hi | Hi].
    + rewrite (FC_carrier_ext cs (mof l) m Hon i), (Hon i Hi).
      exact (Hp i).
    + rewrite (FC_out cs (mof l) i Hi),
              (mof_out (capsOf cs) ctop l i Hin Hi).
      apply mle_refl.
  - exact Hon.
Qed.

(* 主定理：真 gfp = 最大前不动点 = 最大不动点（构造性 Tarski 的枚举形态） *)
Theorem gfp_exists : forall cs,
  prefp cs (gfp cs)
  /\ (forall m, prefp cs m -> cle m (gfp cs))
  /\ (forall i, FC cs (gfp cs) i = gfp cs i).
Proof.
  intros cs.
  assert (Hne : prefps cs <> []).
  { destruct (prefps_nonempty cs) as [m Hm].
    destruct (prefps cs) as [|a l] eqn:Ef.
    - exfalso. destruct Hm.
    - discriminate. }
  assert (Hall : forall m, In m (prefps cs) -> prefp cs m).
  { intros m Hin. unfold prefps in Hin. apply filter_In in Hin.
    destruct Hin as [Hin Hb]. unfold cands in Hin.
    apply in_map_iff in Hin. destruct Hin as [l [Heq Hmem]].
    subst m. unfold prefp. intros i.
    destruct (In_dec cap_eq_dec i (capsOf cs)) as [Hi | Hi].
    - unfold prefpb_ in Hb. rewrite forallb_forall in Hb.
      specialize (Hb i Hi). apply mleb_correct in Hb. exact Hb.
    - rewrite (FC_out cs (mof l) i Hi),
              (mof_out (capsOf cs) ctop l i Hmem Hi).
      apply mle_refl. }
  assert (Hgpre : prefp cs (gfp cs))
    by (unfold gfp; apply gjoin_prefp; [exact Hall | exact Hne]).
  split; [| split].
  - exact Hgpre.
  - (* 最大性：一切前不动点 ≤ gfp *)
    intros m Hp c.
    destruct (canon_prefp cs m Hp) as [l [Hin [Hpl Hon]]].
    assert (Hinpre : In (mof l) (prefps cs)).
    { unfold prefps. apply filter_In. split.
      - unfold cands. apply in_map_iff. exists l.
        split; [reflexivity | exact Hin].
      - unfold prefpb_. rewrite forallb_forall. intros j Hj.
        apply mleb_correct.
        rewrite (FC_carrier_ext cs (mof l) m Hon j), (Hon j Hj).
        exact (Hp j). }
    destruct (In_dec cap_eq_dec c (capsOf cs)) as [Hc | Hc].
    + rewrite <- (Hon c Hc). unfold gfp. apply gjoin_ge. exact Hinpre.
    + apply mle_trans with (FC cs m c).
      * exact (Hp c).
      * rewrite (FC_out cs m c Hc). apply mle_M0.
  - (* 不动点性：gfp ≤ FC gfp（前不动点）∧ FC gfp ≤ gfp（代表在表中） *)
    intros i.
    assert (Hpfg : prefp cs (FC cs (gfp cs))).
    { intros j. exact (FC_mono cs (gfp cs) (FC cs (gfp cs)) Hgpre j). }
    destruct (canon_prefp cs (FC cs (gfp cs)) Hpfg)
      as [l [Hin [Hpl Hon]]].
    assert (Hinpre : In (mof l) (prefps cs)).
    { unfold prefps. apply filter_In. split.
      - unfold cands. apply in_map_iff. exists l.
        split; [reflexivity | exact Hin].
      - unfold prefpb_. rewrite forallb_forall. intros j Hj.
        apply mleb_correct. exact (Hpl j). }
    assert (Hle1 : mle (gfp cs i) (FC cs (gfp cs) i)) by exact (Hgpre i).
    assert (Hle2 : mle (FC cs (gfp cs) i) (gfp cs i)).
    { destruct (In_dec cap_eq_dec i (capsOf cs)) as [Hi | Hi].
      - rewrite <- (Hon i Hi). unfold gfp. apply gjoin_ge. exact Hinpre.
      - rewrite (FC_out cs (gfp cs) i Hi). apply mle_M0. }
    apply mle_antisym; assumption.
Qed.

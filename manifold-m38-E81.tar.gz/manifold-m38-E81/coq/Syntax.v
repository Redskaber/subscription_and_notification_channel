(* ===================================================================== *)
(*  Syntax.v —— 约束语法（M1 第一部分：四通道 + 跨通道交叠）与项切片       *)
(*                                                                         *)
(*  五通道约束语法（PE 风格的分割）：                                       *)
(*    ChTy  —— τ 通道：类型相等（M2 的 Lτ MM 合一对象）                     *)
(*    ChR   —— R 通道：区域 outlives                                       *)
(*    ChPhi —— φ 通道：能力下界 CLv / 能力传播 CPr（本轮 lfp 桥接对象）     *)
(*    ChH   —— H 通道：租约挂靠 CHr / 终点观测 CEnd（drop 的 H 侧种子）     *)
(*    ChX   —— X 通道：区域×类型交叠 CXr（L′ 的 R∩τ，TT94 血统）           *)
(*                                                                         *)
(*  项语法为形式化切片：绑定辅助 Var/Lam + 六个通道代表原语                *)
(*  （造 New / 借 Borrow / 还 Drop / 调 Call / 授 Grant / 切 Slice）。      *)
(*  8 原语在理论层恒定（42 轮）；全集构造子整合挂账 W-LIFE-1a-8P。         *)
(* ===================================================================== *)

Require Import List Lia PeanoNat.
Import ListNotations.
Require Import Mult Cap.

(* τ 通道的类型语法 *)
Inductive ty : Type :=
| TVar (x : nat)
| TArrow (t1 t2 : ty)
| TBorrow (r : nat) (t : ty).   (* 区域 r 上的借用类型 *)

(* 项语法：形式化切片 *)
Inductive tm : Type :=
| Var (x : nat)
| Lam (x : nat) (e : tm)        (* 绑定辅助 *)
| New (r : nat)                 (* 造：区域 r 上分配 *)
| Borrow (r l : nat)            (* 借：区域 r 的租约 l（独占） *)
| Drop (l : nat)                (* 还：租约 l 终点观测 *)
| Call (e1 e2 : tm)             (* 调：函数应用（Fn 计数/租约） *)
| Grant (c : capidx) (k : mult) (e : tm)  (* 授：trait 早解授出 *)
| Slice (e : tm).               (* 切：comptime 零能力切片 *)

(* 规模测度：sized recursion 的秩函数 *)
Fixpoint tsize (e : tm) : nat :=
  match e with
  | Var _ => 1
  | Lam _ e' => S (tsize e')
  | New _ => 1
  | Borrow _ _ => 1
  | Drop _ => 1
  | Call e1 e2 => S (tsize e1 + tsize e2)
  | Grant _ _ e' => S (tsize e')
  | Slice e' => S (tsize e')
  end.

(* 通道 *)
Inductive chan : Type := ChTy | ChR | ChPhi | ChH | ChX.

(* 约束语法 *)
Inductive constr : Type :=
| CTy (a b : ty)                     (* τ：a = b *)
| CRg (r1 r2 : nat)                  (* R：r2 ⊒ r1（outlives） *)
| CLv (c : capidx) (k : mult)        (* φ：φ(c) ≥ k *)
| CPr (c c' : capidx) (w : mult)     (* φ：φ(c) ≥ φ(c') ⊕ w *)
| CHr (l r : nat)                    (* H：租约 l 挂于区域 r *)
| CEnd (l : nat)                     (* H：租约 l 终点观测 *)
| CXr (r : nat) (t : ty).            (* X：区域 r 出现于类型 t（R∩τ） *)

(* 通道归属 *)
Definition chanOf (c : constr) : chan :=
  match c with
  | CTy _ _ => ChTy
  | CRg _ _ => ChR
  | CLv _ _ | CPr _ _ _ => ChPhi
  | CHr _ _ | CEnd _ => ChH
  | CXr _ _ => ChX
  end.

Definition chanAll : list chan := [ChTy; ChR; ChPhi; ChH; ChX].

(* 通道筛子（可判定）与投影 *)
Definition chOf (ch : chan) (c : constr) : bool :=
  match ch, c with
  | ChTy, CTy _ _ => true
  | ChR, CRg _ _ => true
  | ChPhi, CLv _ _ => true
  | ChPhi, CPr _ _ _ => true
  | ChH, CHr _ _ => true
  | ChH, CEnd _ => true
  | ChX, CXr _ _ => true
  | _, _ => false
  end.

Definition chanProj (ch : chan) (cs : list constr) : list constr :=
  filter (chOf ch) cs.

(* ===================================================================== *)
(*  效应能力流形 · W-M3-2 · M32Example：四组实机 + 零公理审计               *)
(*                                                                         *)
(*  实例组：                                                                *)
(*    一、e0m 政策翻案——E.46 的"合法输出"在 solve3 下变为 SEARCH_FAIL       *)
(*        （X 义务阻塞主解：区域 0 潜伏；定理 ∀fuel None）                  *)
(*    二、ghost_pool 政策内命中——主解现形满足 X 义务（政策有通过面）        *)
(*    三、H 孤儿租约（dropck 同构）——τ∧φ 可解但 solve3 = None              *)
(*        （组装坍缩的反例——翻案 #25 实锤）                                  *)
(*    四、H 挂靠传递命中——R 闭包供给 H 见证的安排边实机                      *)
(*    五、R 环可满足——自由预序下环即等价类（自反对由复合产生）              *)
(*    六、tau_rigid 实机——安排流量零的反例面（标签不等 ⇒ τ 否决）           *)
(*    七、盲性守恒实机——现形不动 R/H 闭包                                    *)
(*    八、Drop 孤儿——e 级 H 阻塞（还一个没出生的租约）                       *)
(* ===================================================================== *)

Require Import List Lia PeanoNat Bool.
Import ListNotations.
Require Import Mult Cap Syntax CG Tau TyCG Lphi Fusion Mu Xsub M3Fusion
               Rsat Hsat Solve3 M2Example M3Example.

(* ===================================================================== *)
(*  一、e0m 政策翻案：X 义务接入后的主解阻塞                                 *)
(* ===================================================================== *)

(* E.46 轮：infer 50 e0m = Some (se0m, ...)——solve2 时代 X 读数不检查 *)
(* 本轮：infer3 50 e0m = None——同一主解，X 义务（Call 种子 CXr 0）阻塞 *)

Example m32_e0m_none : infer3 50 e0m = None.
Proof. reflexivity. Qed.

(* 主解的 X 判定器读数为假（区域 0 在 TArrow α0 α1 的主解像中不出现） *)
Example m32_xsatb_e0m :
  xsatb [(1, TArrow (TVar 3) (TVar 0))]
        (cg e0m ++ fst (cgT 0 [] e0m)) = false.
Proof. reflexivity. Qed.

(* 定理路线：对任意燃料 None（e 级 X 空窗的实例化） *)
Theorem m32_e0m_no_infer3 : ~ (exists f s l, infer3 f e0m = Some (s, l)).
Proof.
  intros [f [s [l H]]].
  exact (elevel_x_vacuous e0m f s l eq_refl H).
Qed.

(* 对照表：E.46 m3_e0m_ghost_latent 称"X 求解义务未接入，如实登记为合法输出"
   ——本轮政策接入后同一条读数成为判定性失败。欠条清偿即语义升级。 *)

(* ===================================================================== *)
(*  二、ghost_pool 政策内命中：X 义务的通过面                                *)
(* ===================================================================== *)

Example m32_ghost_hit :
  solve3 50 ghost_pool = Some (sg, lphi (chanProj ChPhi ghost_pool)).
Proof. reflexivity. Qed.

(* ===================================================================== *)
(*  三、H 孤儿租约：τ∧φ 可解而 H 阻塞（组装坍缩反例）                       *)
(* ===================================================================== *)

Definition hpool_fail : list constr := [CEnd 7].

Example m32_hfail_none : solve3 50 hpool_fail = None.
Proof. reflexivity. Qed.

Theorem m32_hfail_no_solution :
  forall f s l, solve3 f hpool_fail <> Some (s, l).
Proof.
  apply (solve3_none_h hpool_fail 7).
  - simpl. auto.
  - intros r H. destruct H as [Heq | []]. discriminate.
Qed.

(* 翻案 #25 实锤：E.46 的组装坍缩（联合 ⇔ τ）在义务接入后失效——
   τ 可解（无方程）∧ φ 可解（零前提）∧ solve3 = None（H 孤儿）。 *)
Theorem m32_collapse_refuted :
  (exists s, unifies s (tyEqs (chanProj ChTy hpool_fail)))
  /\ (exists m, phsat m (chanProj ChPhi hpool_fail))
  /\ (forall f s l, solve3 f hpool_fail <> Some (s, l)).
Proof.
  repeat split.
  - exists []. simpl. exact I.
  - destruct (phi_unconditional hpool_fail) as [m [Hm _]]. exists m. exact Hm.
  - exact m32_hfail_no_solution.
Qed.

(* ===================================================================== *)
(*  四、H 挂靠传递命中：R 闭包供给 H 见证（安排边实机）                     *)
(* ===================================================================== *)

Definition hpool : list constr := [CHr 1 0; CRg 0 2; CEnd 1].

(* R 闭包：(0,2) 经 CRg 0 2 *)
Example m32_hpool_rclose : rclose hpool = [(0, 2)].
Proof. reflexivity. Qed.

(* 挂靠闭包：种子 (1,0) ⊕ R 可达 (0,2) ⇒ 上移挂靠 (1,2) *)
Example m32_hclose_trans : hclose hpool = [(1, 0); (1, 2)].
Proof. reflexivity. Qed.

(* 语义见证：租约 1 经种子挂靠区域 0、0 ≤ 2 而挂靠区域 2 *)
Theorem m32_hle_witness : hle hpool 1 2.
Proof.
  exists 0. split.
  - simpl. auto.
  - apply rle_edge. simpl. auto.
Qed.

(* 池级命中：τ 空、φ 空、H 见证经传递闭包成立 *)
Example m32_hpool_hit :
  solve3 50 hpool = Some ([], lphi (chanProj ChPhi hpool)).
Proof. reflexivity. Qed.

(* ===================================================================== *)
(*  五、R 环可满足：自由预序下环即等价类                                     *)
(* ===================================================================== *)

Definition rpool : list constr := [CRg 1 2; CRg 2 1].

(* 闭包计算：环复合产生自反对 (1,1)、(2,2) *)
Example m32_rclose_cycle : rclose rpool = [(1, 2); (1, 1); (2, 1); (2, 2)].
Proof. reflexivity. Qed.

(* 语义：1 ≤ 2 ∧ 2 ≤ 1 ∧ 1 ≤ 1（环 ⇒ 等价类——R 永不阻塞的自由模型） *)
Theorem m32_rpool_cycle_class :
  rle rpool 1 2 /\ rle rpool 2 1 /\ rle rpool 1 1.
Proof.
  split; [apply rle_edge; simpl; auto |].
  split.
  - apply rle_edge. simpl. auto.
  - apply (rle_trans rpool 1 2 1).
    + apply rle_edge. simpl. auto.
    + apply rle_edge. simpl. auto.
Qed.

(* ===================================================================== *)
(*  六、tau_rigid 实机：安排流量零的反例面                                   *)
(* ===================================================================== *)

(* 标签不等 ⇒ τ 通道直接否决（共享域上的刚性常量） *)
Example m32_tau_rigid_neg :
  unify 50 [(TBorrow 3 (TVar 0), TBorrow 5 (TVar 0))] = None.
Proof. reflexivity. Qed.

(* 标签相等 ⇒ 正常合一（无区域等式待传播） *)
Example m32_tau_rigid_pos :
  unify 50 [(TBorrow 3 (TVar 0), TBorrow 3 (TVar 0))] = Some [].
Proof. reflexivity. Qed.

(* ===================================================================== *)
(*  七、盲性守恒实机：现形不动 R/H 闭包                                      *)
(* ===================================================================== *)

Example m32_blind_ghost :
  rclose (xapply sg ghost_pool) = rclose ghost_pool
  /\ hclose (xapply sg ghost_pool) = hclose ghost_pool.
Proof.
  split; [apply rclose_xapply_invar | apply hclose_xapply_invar].
Qed.

(* ===================================================================== *)
(*  八、Drop 孤儿：e 级 H 阻塞                                              *)
(* ===================================================================== *)

(* Drop 5 的池：只含 CEnd 5（无出生证的租约观测） *)
Example m32_drop_pool :
  cg (Drop 5) ++ fst (cgT 0 [] (Drop 5)) = [CEnd 5].
Proof. reflexivity. Qed.

Theorem m32_drop_orphan :
  forall f s l, infer3 f (Drop 5) <> Some (s, l).
Proof.
  apply (solve3_none_h (cg (Drop 5) ++ fst (cgT 0 [] (Drop 5))) 5).
  - rewrite m32_drop_pool. simpl. auto.
  - intros r H. rewrite m32_drop_pool in H.
    destruct H as [Heq | []]. discriminate.
Qed.

(* ===================================================================== *)
(*  零公理审计（Print Assumptions）                                         *)
(* ===================================================================== *)

(* Rsat.v：R 通道求解义务 *)
Print Assumptions rle_preorder.
Print Assumptions rclose_incl_edges.
Print Assumptions rclose_trans.
Print Assumptions rclose_min.
Print Assumptions rclose_sound.
Print Assumptions rclose_complete.
Print Assumptions rclose_fixpoint.
Print Assumptions rclose_xapply_invar.

(* Hsat.v：H 通道求解义务 *)
Print Assumptions hclose_sound.
Print Assumptions hclose_complete.
Print Assumptions hsatb_correct.
Print Assumptions rle_xapply_invar.
Print Assumptions hclose_xapply_invar.
Print Assumptions hsat_xapply_invar.

(* Solve3.v：组装义务接入 *)
Print Assumptions xsatb_correct.
Print Assumptions solve3_unify.
Print Assumptions solve3_solve2.
Print Assumptions solve3_sound.
Print Assumptions solve3_complete.
Print Assumptions solve3_principal.
Print Assumptions solve3_x_principal.
Print Assumptions xsat_mgu_equiv.
Print Assumptions solve3_none_h.
Print Assumptions solve3_none_x.
Print Assumptions assembly_profile.
Print Assumptions tau_rigid.
Print Assumptions blind_conservations.
Print Assumptions x_sigma_sensitive.
Print Assumptions unify_free.
Print Assumptions tapply_tbfree.
Print Assumptions cgT_eqs_free.
Print Assumptions elevel_eqs_free.
Print Assumptions cg_call_seed.
Print Assumptions elevel_x_vacuous.

(* M32Example.v：实例定理 *)
Print Assumptions m32_e0m_no_infer3.
Print Assumptions m32_hfail_no_solution.
Print Assumptions m32_collapse_refuted.
Print Assumptions m32_hle_witness.
Print Assumptions m32_rpool_cycle_class.
Print Assumptions m32_drop_orphan.

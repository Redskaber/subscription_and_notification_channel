(* ===================================================================== *)
(*  效应能力流形 · M2 · Lτ 通道：Martelli–Montanari 合一（上机）           *)
(*                                                                         *)
(*  贡献 #203–#205 · 文献锚 E.40（MM 1982；Robinson 1965；                 *)
(*  Baader–Snyder 2001 教材式规则组；Lee–Yi 1998 的即时代换同族）。        *)
(*                                                                         *)
(*  规则组（方程系统上的改写，MM 原始五规则的构造子实例化）：               *)
(*    删（trivial）   (t,t)::E → E                                          *)
(*    消（eliminate） (α,t)::E → [α:=t]E        （α 不出现于 t）           *)
(*    定向（orient）  (t,α)::E → (α,t)::E       （仅耗燃料，不降度量）     *)
(*    分解（decomp）  (C a1 a2, C b1 b2)::E → (a1,b1)::(a2,b2)::E          *)
(*                     (&r a, &r' b)::E → (a,b)::E （需 r = r'，否则冲突）  *)
(*    冲突/occurs     失败终止（None）                                      *)
(*                                                                         *)
(*  终止度量（#204）：词典序 (N, S)——N = 方程组不同 τ 变量数，             *)
(*  S = 两侧尺寸总和。消规则使 N 严格降；删/分解使 N 不增且 S 严格降；     *)
(*  定向不降（诚实登记为 is_orient 例外）。fuel 是度量的工程影子。         *)
(*                                                                         *)
(*  代换语义（#205 的关键设计）：head-first 顺序组合                        *)
(*    tapply ((x,t)::s) u = tapply s (tsubst1 x t u)                       *)
(*  使 eliminate 的可靠性证明不需要任何合一组合引理。                       *)
(*                                                                         *)
(*  完备性：W-M2-1 前半已清偿（第 44 轮本文件尾全证）；mgu 最一般性见 Mu.v。*)
(* ===================================================================== *)

Require Import List Lia PeanoNat Wf_nat.
Import ListNotations.
Require Import Syntax.

(* ---- τ 项基本测度与变量 ---- *)

Fixpoint tysize (t : ty) : nat :=
  match t with
  | TVar _ => 1
  | TArrow a b => S (tysize a + tysize b)
  | TBorrow _ a => S (tysize a)
  end.

Lemma tysize_pos : forall t, 1 <= tysize t.
Proof. induction t; simpl; lia. Qed.

Fixpoint tvars (t : ty) : list nat :=
  match t with
  | TVar x => [x]
  | TArrow a b => tvars a ++ tvars b
  | TBorrow _ a => tvars a
  end.

Definition occursb (x : nat) (t : ty) : bool := existsb (Nat.eqb x) (tvars t).

(* ---- 代换：单绑定 + head-first 顺序组合 ---- *)

Fixpoint tsubst1 (x : nat) (t : ty) (u : ty) {struct u} : ty :=
  match u with
  | TVar m => if Nat.eqb m x then t else TVar m
  | TArrow a b => TArrow (tsubst1 x t a) (tsubst1 x t b)
  | TBorrow r a => TBorrow r (tsubst1 x t a)
  end.

Definition tsubst := list (nat * ty).

Fixpoint tapply (s : tsubst) (u : ty) {struct s} : ty :=
  match s with
  | [] => u
  | (x, t) :: s' => tapply s' (tsubst1 x t u)
  end.

Lemma tapply_cons : forall x t s u, tapply ((x, t) :: s) u = tapply s (tsubst1 x t u).
Proof. reflexivity. Qed.

Lemma tapply_arrow : forall s a b, tapply s (TArrow a b) = TArrow (tapply s a) (tapply s b).
Proof.
  intros s. induction s as [| [x t] s IH]; intros a b; simpl.
  - reflexivity.
  - apply IH.
Qed.

Lemma tapply_borrow : forall s r a, tapply s (TBorrow r a) = TBorrow r (tapply s a).
Proof.
  intros s. induction s as [| [x t] s IH]; intros r a; simpl.
  - reflexivity.
  - apply IH.
Qed.

Lemma tsubst1_hit : forall x t, tsubst1 x t (TVar x) = t.
Proof. intros x t. simpl. rewrite Nat.eqb_refl. reflexivity. Qed.

Lemma tsubst1_var_neq : forall x y t, x <> y -> tsubst1 x t (TVar y) = TVar y.
Proof.
  intros x y t H. simpl. destruct (Nat.eqb y x) eqn:E.
  - apply Nat.eqb_eq in E. congruence.
  - reflexivity.
Qed.

Lemma existsb_false_all : forall (A : Type) (f : A -> bool) (l : list A),
  existsb f l = false -> forall x, In x l -> f x = false.
Proof.
  intros A f l. induction l as [|a l IH]; intros H x Hin; simpl in *.
  - contradiction.
  - destruct (f a) eqn:E; simpl in H.
    + discriminate.
    + destruct Hin as [Heq | Hin'].
      * subst x. exact E.
      * apply IH; assumption.
Qed.

Lemma occursb_false_notin : forall x t, occursb x t = false -> ~ In x (tvars t).
Proof.
  intros x t H Hin. unfold occursb in H.
  pose proof (existsb_false_all nat (Nat.eqb x) (tvars t) H x Hin) as HH.
  rewrite Nat.eqb_refl in HH. discriminate.
Qed.

Lemma occursb_in : forall x t, occursb x t = true -> In x (tvars t).
Proof.
  intros x t H. unfold occursb in H. rewrite existsb_exists in H.
  destruct H as [v [Hv Hfv]]. apply Nat.eqb_eq in Hfv. subst v. exact Hv.
Qed.

Lemma occursb_arrow_inv : forall x a b,
  occursb x (TArrow a b) = false -> occursb x a = false /\ occursb x b = false.
Proof.
  intros x a b H.
  assert (Hn : ~ In x (tvars (TArrow a b))) by (apply occursb_false_notin; exact H).
  simpl in Hn. split.
  - destruct (occursb x a) eqn:Ea; [|reflexivity].
    exfalso. apply Hn. apply in_or_app. left. apply occursb_in. exact Ea.
  - destruct (occursb x b) eqn:Eb; [|reflexivity].
    exfalso. apply Hn. apply in_or_app. right. apply occursb_in. exact Eb.
Qed.

Lemma tsubst1_fresh : forall x t u, ~ In x (tvars u) -> tsubst1 x t u = u.
Proof.
  intros x t u. induction u as [m | a IHa b IHb | r a IHa]; intros Hu.
  - simpl. destruct (Nat.eqb m x) eqn:E.
    + apply Nat.eqb_eq in E. subst m. exfalso. apply Hu. simpl. left. reflexivity.
    + reflexivity.
  - simpl in Hu.
    assert (Ha : ~ In x (tvars a)) by (intro H; apply Hu; apply in_or_app; left; exact H).
    assert (Hb : ~ In x (tvars b)) by (intro H; apply Hu; apply in_or_app; right; exact H).
    simpl. rewrite (IHa Ha), (IHb Hb). reflexivity.
  - assert (Ha : ~ In x (tvars a)) by exact Hu.
    simpl. rewrite (IHa Ha). reflexivity.
Qed.

Lemma tsubst1_notin : forall x t, occursb x t = false -> tsubst1 x t t = t.
Proof.
  intros x t H. apply tsubst1_fresh. apply occursb_false_notin. exact H.
Qed.

Lemma tvars_subst1 : forall x t, occursb x t = false -> forall u v,
  In v (tvars (tsubst1 x t u)) -> v <> x /\ (In v (tvars u) \/ In v (tvars t)).
Proof.
  intros x t Ho. induction u as [m | a IHa b IHb | r a IHa]; intros v H.
  - (* u = TVar m *)
    destruct (Nat.eqb m x) eqn:E.
    + apply Nat.eqb_eq in E. subst m.
      rewrite tsubst1_hit in H.
      destruct (in_dec Nat.eq_dec v [x]) as [Hvx | Hvx].
      * destruct Hvx as [Hvx | []]. subst v.
        exfalso. apply (occursb_false_notin x t Ho). exact H.
      * split.
        -- intros Hvx'. apply Hvx. left. symmetry. exact Hvx'.
        -- right. exact H.
    + simpl in H. rewrite E in H. simpl in H.
      apply Nat.eqb_neq in E.
      destruct H as [Hm | []]. subst v. split.
      * intros Hvx. apply E. exact Hvx.
      * left; apply in_eq.
  - simpl in H. apply in_app_or in H. destruct H as [H | H].
    + destruct (IHa v H) as [Hne [H' | H']].
      * split; [exact Hne | left; apply in_or_app; left; exact H'].
      * split; [exact Hne | right; exact H'].
    + destruct (IHb v H) as [Hne [H' | H']].
      * split; [exact Hne | left; apply in_or_app; right; exact H'].
      * split; [exact Hne | right; exact H'].
  - simpl in H. destruct (IHa v H) as [Hne [H' | H']].
    + split; [exact Hne | left; exact H'].
    + split; [exact Hne | right; exact H'].
Qed.

(* ---- 合一器谓词 ---- *)

Fixpoint unifies (s : tsubst) (E : list (ty * ty)) {struct E} : Prop :=
  match E with
  | [] => True
  | (u, v) :: E' => tapply s u = tapply s v /\ unifies s E'
  end.

Lemma unifies_app : forall s A B, unifies s (A ++ B) <-> unifies s A /\ unifies s B.
Proof.
  intros s A B. induction A as [|[u v] A IH]; simpl.
  - tauto.
  - rewrite IH. tauto.
Qed.

(* ---- MM 合一算法（fuel 化） ---- *)

Definition spair (x : nat) (t : ty) (e : ty * ty) : ty * ty :=
  (tsubst1 x t (fst e), tsubst1 x t (snd e)).

Fixpoint unify (fuel : nat) (E : list (ty * ty)) {struct fuel} : option tsubst :=
  match E with
  | [] => Some []
  | (u, v) :: E' =>
      match fuel with
      | 0 => None
      | S n =>
          match u, v with
          | TVar x, TVar y =>
              if Nat.eqb x y
              then unify n E'
              else match unify n (map (spair x (TVar y)) E') with
                   | Some s => Some ((x, TVar y) :: s)
                   | None => None
                   end
          | TVar x, t =>
              if occursb x t then None
              else match unify n (map (spair x t) E') with
                   | Some s => Some ((x, t) :: s)
                   | None => None
                   end
          | TArrow a1 a2, TVar y => unify n ((TVar y, TArrow a1 a2) :: E')
          | TBorrow r a, TVar y => unify n ((TVar y, TBorrow r a) :: E')
          | TArrow a1 a2, TArrow b1 b2 => unify n ((a1, b1) :: (a2, b2) :: E')
          | TBorrow r a, TBorrow r' b =>
              if Nat.eqb r r' then unify n ((a, b) :: E') else None
          | TArrow _ _, TBorrow _ _ => None
          | TBorrow _ _, TArrow _ _ => None
          end
      end
  end.

(* ---- 可靠性：返回即真解（贡献 #205） ---- *)

Lemma unifies_elim_tail : forall x t s E,
  unifies s (map (spair x t) E) -> unifies ((x, t) :: s) E.
Proof.
  intros x t s E. induction E as [|[u v] E IH]; intros H.
  - exact I.
  - simpl in H. destruct H as [H1 H2]. simpl. split.
    + exact H1.
    + apply IH. exact H2.
Qed.

Theorem unify_sound : forall fuel E s, unify fuel E = Some s -> unifies s E.
Proof.
  induction fuel as [|n IH]; intros [| [u v] E'] s H.
  - simpl in H. injection H as Hs. subst s. exact I.
  - discriminate H.
  - simpl in H. injection H as Hs. subst s. exact I.
  - destruct u as [x | a1 a2 | r a]; destruct v as [y | b1 b2 | r' b]; simpl in H.
    + (* TVar x, TVar y *)
      destruct (Nat.eqb x y) eqn:Eeq.
      * apply Nat.eqb_eq in Eeq. subst y. apply IH in H. simpl. split;
          [reflexivity | exact H].
      * apply Nat.eqb_neq in Eeq.
        destruct (unify n (map (spair x (TVar y)) E')) eqn:Hu.
        { inversion H; subst; clear H.
          apply IH in Hu. apply unifies_elim_tail in Hu. split.
          - rewrite !tapply_cons. rewrite tsubst1_hit.
            rewrite (tsubst1_var_neq x y (TVar y) Eeq). reflexivity.
          - exact Hu. }
        { discriminate. }
    + (* TVar x, TArrow b1 b2 *)
      destruct (occursb x (TArrow b1 b2)) eqn:Ho; [discriminate|].
      destruct (unify n (map (spair x (TArrow b1 b2)) E')) eqn:Hu.
      { inversion H; subst; clear H.
        apply IH in Hu. apply unifies_elim_tail in Hu. split.
        - rewrite !tapply_cons, tsubst1_hit, (tsubst1_notin x (TArrow b1 b2) Ho).
          reflexivity.
        - exact Hu. }
      { discriminate. }
    + (* TVar x, TBorrow r' b *)
      destruct (occursb x (TBorrow r' b)) eqn:Ho; [discriminate|].
      destruct (unify n (map (spair x (TBorrow r' b)) E')) eqn:Hu.
      { inversion H; subst; clear H.
        apply IH in Hu. apply unifies_elim_tail in Hu. split.
        - rewrite !tapply_cons, tsubst1_hit, (tsubst1_notin x (TBorrow r' b) Ho).
          reflexivity.
        - exact Hu. }
      { discriminate. }
    + (* TArrow a1 a2, TVar y：定向 *)
      apply IH in H. simpl in H. simpl. split; [symmetry; exact (proj1 H) | exact (proj2 H)].
    + (* TArrow, TArrow：分解 *)
      apply IH in H. simpl in H. destruct H as [H1 [H2 H3]]. simpl.
      rewrite !tapply_arrow. split; [rewrite H1, H2; reflexivity | exact H3].
    + (* TArrow, TBorrow：冲突 *)
      discriminate H.
    + (* TBorrow r a, TVar y：定向 *)
      apply IH in H. simpl in H. simpl. split; [symmetry; exact (proj1 H) | exact (proj2 H)].
    + (* TBorrow, TArrow：冲突 *)
      discriminate H.
    + (* TBorrow r a, TBorrow r' b：区域相等则分解，否则冲突 *)
      destruct (Nat.eqb r r') eqn:Er.
      * apply Nat.eqb_eq in Er. subst r'. apply IH in H. simpl in H.
        destruct H as [H1 H2]. simpl. rewrite !tapply_borrow.
        split; [rewrite H1; reflexivity | exact H2].
      * discriminate H.
Qed.

(* ---- 燃料单调：充足燃料不改变成功结果（守恒量 #2：fuel 是度量影子） ---- *)

Lemma unify_fuel_mono : forall E n k s, unify n E = Some s -> unify (n + k) E = Some s.
Proof.
  intros E n. revert E. induction n as [|n IH]; intros E k s H.
  - destruct E as [|[u v] E']; simpl in H.
    + injection H as Hs. subst s. destruct k; reflexivity.
    + discriminate H.
  - destruct E as [|[u v] E']; simpl in H.
    + injection H as Hs. subst s. reflexivity.
    + destruct k as [|k'].
      * rewrite Nat.add_0_r. exact H.
      * replace (S n + S k') with (S (n + S k')) by lia. simpl in H |- *.
        destruct u as [x | a1 a2 | r a]; destruct v as [y | b1 b2 | r' b].
        -- destruct (Nat.eqb x y).
           ++ apply IH. exact H.
           ++ destruct (unify n (map (spair x (TVar y)) E')) eqn:Hu.
              ** rewrite (IH _ (S k') _ Hu). exact H.
              ** discriminate.
        -- destruct (occursb x (TArrow b1 b2)).
           ++ discriminate.
           ++ destruct (unify n (map (spair x (TArrow b1 b2)) E')) eqn:Hu.
              ** rewrite (IH _ (S k') _ Hu). exact H.
              ** discriminate.
        -- destruct (occursb x (TBorrow r' b)).
           ++ discriminate.
           ++ destruct (unify n (map (spair x (TBorrow r' b)) E')) eqn:Hu.
              ** rewrite (IH _ (S k') _ Hu). exact H.
              ** discriminate.
        -- apply IH. exact H.
        -- apply IH. exact H.
        -- discriminate.
        -- apply IH. exact H.
        -- discriminate.
        -- destruct (Nat.eqb r r').
           ++ apply IH. exact H.
           ++ discriminate.
Qed.

(* ---- CTy 约束 → 方程列表（M2 的 Lτ pass 输入加工） ---- *)

Fixpoint tyEqs (cs : list constr) : list (ty * ty) :=
  match cs with
  | [] => []
  | CTy a b :: cs' => (a, b) :: tyEqs cs'
  | _ :: cs' => tyEqs cs'
  end.

(* ===================================================================== *)
(*  M–M 终止度量（贡献 #204）                                              *)
(* ===================================================================== *)

Definition eqs_vars (E : list (ty * ty)) : list nat :=
  flat_map (fun e => tvars (fst e) ++ tvars (snd e)) E.
Definition Nv (E : list (ty * ty)) : nat := length (nodup Nat.eq_dec (eqs_vars E)).
Definition Sv (E : list (ty * ty)) : nat :=
  fold_right (fun e a => tysize (fst e) + tysize (snd e) + a) 0 E.
Definition plex (p q : nat * nat) : Prop :=
  fst p < fst q \/ (fst p = fst q /\ snd p < snd q).

Inductive mm_step : list (ty * ty) -> list (ty * ty) -> Prop :=
| step_triv : forall t E, mm_step ((t, t) :: E) E
| step_elim : forall x t E, occursb x t = false ->
    mm_step ((TVar x, t) :: E) (map (spair x t) E)
| step_or_arrow : forall a1 a2 y E,
    mm_step ((TArrow a1 a2, TVar y) :: E) ((TVar y, TArrow a1 a2) :: E)
| step_or_borrow : forall r a y E,
    mm_step ((TBorrow r a, TVar y) :: E) ((TVar y, TBorrow r a) :: E)
| step_dec_arrow : forall a1 a2 b1 b2 E,
    mm_step ((TArrow a1 a2, TArrow b1 b2) :: E) ((a1, b1) :: (a2, b2) :: E)
| step_dec_borrow : forall r a b E,
    mm_step ((TBorrow r a, TBorrow r b) :: E) ((a, b) :: E).

Definition is_orient (E E' : list (ty * ty)) : Prop :=
  (exists a1 a2 y E0, E = (TArrow a1 a2, TVar y) :: E0
                    /\ E' = (TVar y, TArrow a1 a2) :: E0)
  \/ (exists r a y E0, E = (TBorrow r a, TVar y) :: E0
                     /\ E' = (TVar y, TBorrow r a) :: E0).

Lemma Nv_mono : forall E1 E2, incl (eqs_vars E1) (eqs_vars E2) -> Nv E1 <= Nv E2.
Proof.
  intros E1 E2 H. unfold Nv.
  apply NoDup_incl_length; [apply NoDup_nodup |].
  intros a Ha.
  pose proof (proj1 (nodup_In Nat.eq_dec (eqs_vars E1) a) Ha) as Hin.
  apply (proj2 (nodup_In Nat.eq_dec (eqs_vars E2) a)).
  apply H. exact Hin.
Qed.

Lemma in_eqs_vars_cons : forall a b E v,
  In v (tvars a) \/ In v (tvars b) \/ In v (eqs_vars E) ->
  In v (eqs_vars ((a, b) :: E)).
Proof.
  intros a b E v [H | [H | H]]; unfold eqs_vars; simpl.
  - apply in_or_app; left; apply in_or_app; left; exact H.
  - apply in_or_app; left; apply in_or_app; right; exact H.
  - apply in_or_app; right; exact H.
Qed.

Lemma eqs_vars_cons_inv : forall a b E v,
  In v (eqs_vars ((a, b) :: E)) ->
  In v (tvars a) \/ In v (tvars b) \/ In v (eqs_vars E).
Proof.
  intros a b E v H. unfold eqs_vars in H. simpl in H.
  apply in_app_or in H. destruct H as [H | H].
  - apply in_app_or in H. destruct H as [H | H]; [left; exact H | right; left; exact H].
  - right; right; exact H.
Qed.

Lemma eqs_vars_elim : forall x t E, occursb x t = false ->
  incl (eqs_vars (map (spair x t) E)) (eqs_vars ((TVar x, t) :: E)).
Proof.
  intros x t E Ho v. induction E as [|[u w] E IH]; intros Hv; simpl in Hv.
  - contradiction.
  - apply in_app_or in Hv. destruct Hv as [H1 | H2].
    + apply in_app_or in H1. destruct H1 as [H1 | H1].
      * destruct (tvars_subst1 x t Ho u v H1) as [_ [Hv' | Hv']].
        -- apply in_eqs_vars_cons. right. right.
           apply in_eqs_vars_cons. left. exact Hv'.
        -- apply in_eqs_vars_cons. right. left. exact Hv'.
      * destruct (tvars_subst1 x t Ho w v H1) as [_ [Hv' | Hv']].
        -- apply in_eqs_vars_cons. right. right.
           apply in_eqs_vars_cons. right. left. exact Hv'.
        -- apply in_eqs_vars_cons. right. left. exact Hv'.
    + apply IH in H2.
      destruct (eqs_vars_cons_inv _ _ _ _ H2) as [H1' | [H1' | H1']].
      * apply in_eqs_vars_cons. left. exact H1'.
      * apply in_eqs_vars_cons. right. left. exact H1'.
      * apply in_eqs_vars_cons. right. right.
        apply in_eqs_vars_cons. right. right. exact H1'.
Qed.

Lemma eqs_vars_elim_nox : forall x t E, occursb x t = false ->
  ~ In x (eqs_vars (map (spair x t) E)).
Proof.
  intros x t E Ho. induction E as [|[u w] E IH]; simpl; intros Hin.
  - contradiction.
  - apply in_app_or in Hin. destruct Hin as [H1 | H2].
    + apply in_app_or in H1. destruct H1 as [H1 | H1].
      * destruct (tvars_subst1 x t Ho u x H1) as [Hne _]. exact (Hne eq_refl).
      * destruct (tvars_subst1 x t Ho w x H1) as [Hne _]. exact (Hne eq_refl).
    + apply IH. exact H2.
Qed.

(* 消规则使 N 严格下降：x::nodup 技巧 —— 严格性来自把 x 塞回小子典 *)
Lemma Nv_elim_lt : forall x t E, occursb x t = false ->
  Nv (map (spair x t) E) < Nv ((TVar x, t) :: E).
Proof.
  intros x t E Ho.
  assert (Hincl : incl (eqs_vars (map (spair x t) E)) (eqs_vars ((TVar x, t) :: E)))
    by (apply eqs_vars_elim; exact Ho).
  assert (Hx : In x (eqs_vars ((TVar x, t) :: E)))
    by (apply in_eqs_vars_cons; left; apply in_eq).
  assert (Hnx : ~ In x (eqs_vars (map (spair x t) E))) by (apply eqs_vars_elim_nox; exact Ho).
  unfold Nv.
  assert (Hnd : NoDup (x :: nodup Nat.eq_dec (eqs_vars (map (spair x t) E)))).
  { constructor; [|apply NoDup_nodup]. intro Hin.
    pose proof (proj1 (nodup_In Nat.eq_dec (eqs_vars (map (spair x t) E)) x) Hin).
    contradiction. }
  assert (Hincl' : incl (x :: nodup Nat.eq_dec (eqs_vars (map (spair x t) E)))
                         (nodup Nat.eq_dec (eqs_vars ((TVar x, t) :: E)))).
  { intros w [Hw | Hw].
    - subst w. apply (proj2 (nodup_In Nat.eq_dec (eqs_vars ((TVar x, t) :: E)) x)).
      exact Hx.
    - apply (proj2 (nodup_In Nat.eq_dec (eqs_vars ((TVar x, t) :: E)) w)).
      apply Hincl.
      apply (proj1 (nodup_In Nat.eq_dec (eqs_vars (map (spair x t) E)) w)). exact Hw. }
  pose proof (NoDup_incl_length Hnd Hincl') as HL. cbn [length] in HL. lia.
Qed.

Theorem mm_step_measure : forall E E',
  mm_step E E' -> is_orient E E' \/ plex (Nv E', Sv E') (Nv E, Sv E).
Proof.
  intros E E' H.
  destruct H as [t E1 | x t E1 Ho | a1 a2 y E1 | r a y E1
                | a1 a2 b1 b2 E1 | r a b E1].
  - (* 删：trivial *)
    right. unfold plex. cbn [fst snd].
    assert (HN : Nv E1 <= Nv ((t, t) :: E1)).
    { apply Nv_mono. intros v Hv. apply in_eqs_vars_cons. right. right. exact Hv. }
    assert (HS : Sv E1 < Sv ((t, t) :: E1)).
    { unfold Sv. simpl. pose proof (tysize_pos t). lia. }
    destruct (Nat.eq_dec (Nv E1) (Nv ((t, t) :: E1))) as [Heq | Hne].
    + right. split; [exact Heq | exact HS].
    + left. lia.
  - (* 消：eliminate *)
    right. left. apply Nv_elim_lt. exact Ho.
  - (* 定向（arrow） *)
    left. left. do 4 eexists. split; reflexivity.
  - (* 定向（borrow） *)
    left. right. do 4 eexists. split; reflexivity.
  - (* 分解（arrow） *)
    right. unfold plex. cbn [fst snd].
    assert (HN : Nv ((a1, b1) :: (a2, b2) :: E1)
                 <= Nv ((TArrow a1 a2, TArrow b1 b2) :: E1)).
    { apply Nv_mono. intros v Hv.
      destruct (eqs_vars_cons_inv _ _ _ _ Hv) as [H1 | [H1 | H1]].
      - apply in_eqs_vars_cons. left. simpl. apply in_or_app. left. exact H1.
      - apply in_eqs_vars_cons. right. left. simpl. apply in_or_app. left. exact H1.
      - destruct (eqs_vars_cons_inv _ _ _ _ H1) as [H2 | [H2 | H2]].
        + apply in_eqs_vars_cons. left. simpl. apply in_or_app. right. exact H2.
        + apply in_eqs_vars_cons. right. left. simpl. apply in_or_app. right. exact H2.
        + apply in_eqs_vars_cons. right. right. exact H2. }
    assert (HS : Sv ((a1, b1) :: (a2, b2) :: E1)
                 < Sv ((TArrow a1 a2, TArrow b1 b2) :: E1)).
    { unfold Sv. simpl. pose proof (tysize_pos a1). pose proof (tysize_pos b1).
      pose proof (tysize_pos a2). pose proof (tysize_pos b2). lia. }
    destruct (Nat.eq_dec (Nv ((a1, b1) :: (a2, b2) :: E1))
                          (Nv ((TArrow a1 a2, TArrow b1 b2) :: E1))) as [Heq | Hne].
    + right. split; [exact Heq | exact HS].
    + left. lia.
  - (* 分解（borrow）：变量集与尺寸差严格 *)
    right. unfold plex. cbn [fst snd].
    assert (HN : Nv ((a, b) :: E1) <= Nv ((TBorrow r a, TBorrow r b) :: E1)).
    { apply Nv_mono. intros v Hv.
      destruct (eqs_vars_cons_inv _ _ _ _ Hv) as [H1 | [H1 | H1]].
      - apply in_eqs_vars_cons. left. simpl. exact H1.
      - apply in_eqs_vars_cons. right. left. simpl. exact H1.
      - apply in_eqs_vars_cons. right. right. exact H1. }
    assert (HS : Sv ((a, b) :: E1) < Sv ((TBorrow r a, TBorrow r b) :: E1)).
    { unfold Sv. simpl. pose proof (tysize_pos a). pose proof (tysize_pos b). lia. }
    destruct (Nat.eq_dec (Nv ((a, b) :: E1)) (Nv ((TBorrow r a, TBorrow r b) :: E1)))
      as [Heq | Hne].
    + right. split; [exact Heq | exact HS].
    + left. lia.
Qed.

Lemma Nv_incl_eq : forall E1 E2,
  incl (eqs_vars E1) (eqs_vars E2) -> incl (eqs_vars E2) (eqs_vars E1) -> Nv E1 = Nv E2.
Proof.
  intros E1 E2 H12 H21.
  pose proof (Nv_mono E1 E2 H12). pose proof (Nv_mono E2 E1 H21). lia.
Qed.

Lemma incl_swap : forall a b E, incl (eqs_vars ((a, b) :: E)) (eqs_vars ((b, a) :: E)).
Proof.
  intros a b E v Hv.
  destruct (eqs_vars_cons_inv _ _ _ _ Hv) as [H1 | [H1 | H1]].
  - apply in_eqs_vars_cons. right. left. exact H1.
  - apply in_eqs_vars_cons. left. exact H1.
  - apply in_eqs_vars_cons. right. right. exact H1.
Qed.

Theorem mm_step_Nv_le : forall E E', mm_step E E' -> Nv E' <= Nv E.
Proof.
  intros E E' H.
  destruct H as [t E1 | x t E1 Ho | a1 a2 y E1 | r a y E1
                | a1 a2 b1 b2 E1 | r a b E1].
  - apply Nv_mono. intros v Hv. apply in_eqs_vars_cons. right. right. exact Hv.
  - pose proof (Nv_elim_lt x t E1 Ho). lia.
  - pose proof (Nv_incl_eq ((TVar y, TArrow a1 a2) :: E1) ((TArrow a1 a2, TVar y) :: E1)
                  (incl_swap (TVar y) (TArrow a1 a2) E1)
                  (incl_swap (TArrow a1 a2) (TVar y) E1)). lia.
  - pose proof (Nv_incl_eq ((TVar y, TBorrow r a) :: E1) ((TBorrow r a, TVar y) :: E1)
                  (incl_swap (TVar y) (TBorrow r a) E1)
                  (incl_swap (TBorrow r a) (TVar y) E1)). lia.
  - apply Nv_mono. intros v Hv.
    destruct (eqs_vars_cons_inv _ _ _ _ Hv) as [H1 | [H1 | H1]].
    + apply in_eqs_vars_cons. left. simpl. apply in_or_app. left. exact H1.
    + apply in_eqs_vars_cons. right. left. simpl. apply in_or_app. left. exact H1.
    + destruct (eqs_vars_cons_inv _ _ _ _ H1) as [H2 | [H2 | H2]].
      * apply in_eqs_vars_cons. left. simpl. apply in_or_app. right. exact H2.
      * apply in_eqs_vars_cons. right. left. simpl. apply in_or_app. right. exact H2.
      * apply in_eqs_vars_cons. right. right. exact H2.
  - apply Nv_mono. intros v Hv.
    destruct (eqs_vars_cons_inv _ _ _ _ Hv) as [H1 | [H1 | H1]].
    + apply in_eqs_vars_cons. left. simpl. exact H1.
    + apply in_eqs_vars_cons. right. left. simpl. exact H1.
    + apply in_eqs_vars_cons. right. right. exact H1.
Qed.

(* ===================================================================== *)
(*  【W-M2-1 清偿】完备性（第 44 轮 · 贡献 #212–#219 · 锚 E.41–E.42）       *)
(*                                                                         *)
(*  unify_complete：E 可合一（存在 s，unifies s E）                         *)
(*                  ⇒ ∃fuel σ，unify fuel E = Some σ。                      *)
(*  （mgu 最一般性 = W-M2-1 的另一半，见 Mu.v 的 unify_mgu。）               *)
(*                                                                         *)
(*  证明路线（Baader–Snyder 2001 §4.6 变换法的构造性化；教材表述           *)
(*  Baader–Nipkow 1998 §4.6；形式化先例 Paulson 1985 LCF）：               *)
(*    A. 单步引理组：合一器沿规则步传播——                                  *)
(*       消步 = 代换交换引理（head-first 语义零组合引理的完备侧红利）；     *)
(*       occurs/冲突 = 与可合一不相容（None 的证明力来源）；                *)
(*    B. 良基性：词典序 plex 的双层 Acc（外层 N 归纳、内层 S 归纳）          *)
(*       + 逆像良基 rstep_wf；                                              *)
(*    C. 主归纳：Acc rstep 强归纳 + 九宫格——每个递归调用系统的度量         *)
(*       严格降（定向步经两级展开合并为"定向+消"复合步，消化 is_orient      *)
(*       的度量平坦例外）。fuel 由归纳假设精确供给（与 unify 的结构递归     *)
(*       同步），不需要 unify_fuel_mono。                                  *)
(* ===================================================================== *)

(* ---- A0 ty 的可判定相等 ---- *)

Lemma ty_eq_dec : forall a b : ty, {a = b} + {a <> b}.
Proof. decide equality; apply Nat.eq_dec. Defined.

(* ---- A1 代换交换引理：σ(x) = σ(w) ⇒ σ∘[x:=w] 与 σ 在项上等作用 ---- *)
(*    head-first 语义的完备侧红利：不需要任何合一组合引理。               *)

Lemma tapply_subst1_comm : forall s x w t,
  tapply s (TVar x) = tapply s w ->
  tapply s (tsubst1 x w t) = tapply s t.
Proof.
  intros s x w t H. induction t as [m | a IHa b IHb | r a IHa]; simpl.
  - destruct (Nat.eqb m x) eqn:E.
    + apply Nat.eqb_eq in E. subst m. rewrite H. reflexivity.
    + reflexivity.
  - rewrite !tapply_arrow, IHa, IHb. reflexivity.
  - rewrite !tapply_borrow, IHa. reflexivity.
Qed.

(* ---- A2 消步的合一器传播 ---- *)

Lemma unifies_map_spair : forall s x w E,
  tapply s (TVar x) = tapply s w -> unifies s E -> unifies s (map (spair x w) E).
Proof.
  intros s x w E H. induction E as [|[u v] E IH]; intros Hu; simpl.
  - exact I.
  - destruct Hu as [Hu1 Hu2]. split.
    + rewrite (tapply_subst1_comm s x w u H), (tapply_subst1_comm s x w v H).
      exact Hu1.
    + apply IH. exact Hu2.
Qed.

(* ---- A3 occurs 检查与可合一不相容 ---- *)

Lemma tapply_occurs_lt : forall s x t,
  In x (tvars t) -> t <> TVar x ->
  tysize (tapply s (TVar x)) < tysize (tapply s t).
Proof.
  intros s x t. induction t as [m | a IHa b IHb | r a]; intros Hin Hne.
  - simpl in Hin. destruct Hin as [Heq | []]. subst m.
    exfalso. apply Hne. reflexivity.
  - simpl in Hin. apply in_app_or in Hin.
    rewrite tapply_arrow. cbn [tysize].
    destruct Hin as [Ha | Hb].
    + destruct (ty_eq_dec a (TVar x)) as [Hax | Hax].
      * subst a. lia.
      * specialize (IHa Ha Hax). lia.
    + destruct (ty_eq_dec b (TVar x)) as [Hbx | Hbx].
      * subst b. lia.
      * specialize (IHb Hb Hbx). lia.
  - simpl in Hin. rewrite tapply_borrow. cbn [tysize].
    destruct (ty_eq_dec a (TVar x)) as [Hax | Hax].
    + subst a. lia.
    + specialize (IHa Hin Hax). lia.
Qed.

Lemma unifies_occurs_ex : forall s x t E,
  unifies s ((TVar x, t) :: E) -> occursb x t = true -> t <> TVar x -> False.
Proof.
  intros s x t E [Hhead _] Ho Hne.
  pose proof (occursb_in x t Ho) as Hin.
  pose proof (tapply_occurs_lt s x t Hin Hne) as Hlt.
  rewrite Hhead in Hlt. lia.
Qed.

(* ---- A4 构造子冲突与可合一不相容 ---- *)

Lemma unifies_clash_arrow_borrow : forall s a1 a2 r b E,
  ~ unifies s ((TArrow a1 a2, TBorrow r b) :: E).
Proof.
  intros s a1 a2 r b E [Hhead _].
  rewrite tapply_arrow, tapply_borrow in Hhead. discriminate.
Qed.

Lemma unifies_clash_borrow_arrow : forall s a1 a2 r b E,
  ~ unifies s ((TBorrow r b, TArrow a1 a2) :: E).
Proof.
  intros s a1 a2 r b E [Hhead _].
  rewrite tapply_arrow, tapply_borrow in Hhead. discriminate.
Qed.

Lemma unifies_clash_region : forall s r r' a b E,
  r <> r' -> ~ unifies s ((TBorrow r a, TBorrow r' b) :: E).
Proof.
  intros s r r' a b E Hrr [Hhead _].
  rewrite !tapply_borrow in Hhead.
  injection Hhead. intros. congruence.
Qed.

(* ---- A5 头方程对称（定向步的合一器不变性） ---- *)

Lemma unifies_head_sym : forall s a b E,
  unifies s ((a, b) :: E) -> unifies s ((b, a) :: E).
Proof.
  intros s a b E [H1 H2]. split; [symmetry; exact H1 | exact H2].
Qed.

(* ---- A6 分解的合一器传播 ---- *)

Lemma unifies_dec_arrow : forall s a1 a2 b1 b2 E,
  unifies s ((TArrow a1 a2, TArrow b1 b2) :: E) ->
  unifies s ((a1, b1) :: (a2, b2) :: E).
Proof.
  intros s a1 a2 b1 b2 E [Hhead Hrest].
  rewrite !tapply_arrow in Hhead. injection Hhead as Ha Hb.
  split; [exact Ha | split; [exact Hb | exact Hrest]].
Qed.

Lemma unifies_dec_borrow : forall s r a b E,
  unifies s ((TBorrow r a, TBorrow r b) :: E) -> unifies s ((a, b) :: E).
Proof.
  intros s r a b E [Hhead Hrest].
  rewrite !tapply_borrow in Hhead. injection Hhead as Ha.
  split; [exact Ha | exact Hrest].
Qed.

(* ---- B. 词典序良基（双层 Acc：外层 N 归纳，内层 S 归纳） ---- *)

Lemma plex_wf : well_founded plex.
Proof.
  red; intros p. destruct p as [n m].
  assert (Ha : Acc lt n) by apply lt_wf.
  revert m. induction Ha as [n Hn IHn]; intros m.
  assert (Hb : Acc lt m) by apply lt_wf.
  induction Hb as [m Hm IHm].
  - constructor. intros q Hq.
    destruct q as [a b]. unfold plex in Hq. simpl in Hq.
    destruct Hq as [Hlt | [Heq Hlt]].
    + apply (IHn a Hlt b).
    + subst a. apply (IHm b Hlt).
Qed.

(* 逆像良基：rstep = plex ∘ (Nv, Sv) *)

Definition rstep (E E' : list (ty * ty)) : Prop :=
  plex (Nv E, Sv E) (Nv E', Sv E').

Lemma rstep_wf_acc : forall p, Acc plex p ->
  forall E, (Nv E, Sv E) = p -> Acc rstep E.
Proof.
  intros p H. induction H as [p Hr IH]; intros E He.
  constructor. intros E' HR. unfold rstep in HR.
  apply (IH (Nv E', Sv E')).
  - rewrite He in HR. exact HR.
  - reflexivity.
Qed.

Lemma rstep_wf : well_founded rstep.
Proof.
  red; intros E. apply (rstep_wf_acc (Nv E, Sv E)).
  - apply plex_wf.
  - reflexivity.
Qed.

(* ---- C. 完备性主定理（W-M2-1 前半清偿） ---- *)

Theorem unify_complete : forall E,
  (exists s, unifies s E) -> exists fuel s, unify fuel E = Some s.
Proof.
  assert (Hmain : forall E, Acc rstep E -> (exists s, unifies s E) ->
    exists fuel s, unify fuel E = Some s).
  { intros E Hacc. induction Hacc as [E Hr IHE]; intros [s0 Hs0].
    destruct E as [|[u v] E'].
    - (* 空系统：match E 先于 fuel，零燃料即成功 *)
      exists 0, []. reflexivity.
    - (* 九宫格 *)
      destruct u as [x | a1 a2 | r a]; destruct v as [y | b1 b2 | r' b].
      + (* TVar x, TVar y *)
        simpl in Hs0. destruct Hs0 as [Hhead Hrest].
        destruct (Nat.eqb x y) eqn:Eeq.
        * (* x = y：删步 *)
          apply Nat.eqb_eq in Eeq. subst y.
          assert (HR : rstep E' ((TVar x, TVar x) :: E')).
          { pose proof (mm_step_measure _ _ (step_triv (TVar x) E')) as HM.
            destruct HM as [Hor | Hp].
            - unfold is_orient in Hor.
              destruct Hor as [[H1 [H2 [H3 [H4 [H5a H5b]]]]] | [H1 [H2 [H3 [H4 [H5a H5b]]]]]].
              + discriminate H5a.
              + discriminate H5a.
            - unfold rstep. exact Hp. }
          destruct (IHE E' HR (ex_intro _ s0 Hrest)) as [fuel' [s' Hu]].
          exists (S fuel'), s'.
          assert (Eu : unify (S fuel') ((TVar x, TVar x) :: E')
                    = (if Nat.eqb x x
                       then unify fuel' E'
                       else match unify fuel' (map (spair x (TVar x)) E') with
                            | Some s => Some ((x, TVar x) :: s)
                            | None => None
                            end)) by reflexivity.
          rewrite Eu, Nat.eqb_refl, Hu. reflexivity.
        * (* x ≠ y：消步 x ↦ TVar y *)
          assert (Ho : occursb x (TVar y) = false).
          { unfold occursb. simpl. rewrite Eeq. reflexivity. }
          assert (HR : rstep (map (spair x (TVar y)) E')
                             ((TVar x, TVar y) :: E')).
          { unfold rstep, plex. left. cbn [fst snd].
            apply Nv_elim_lt. exact Ho. }
          assert (Hs2 : unifies s0 (map (spair x (TVar y)) E'))
            by (apply unifies_map_spair; [exact Hhead | exact Hrest]).
          destruct (IHE (map (spair x (TVar y)) E') HR
                        (ex_intro _ s0 Hs2)) as [fuel' [s' Hu]].
          exists (S fuel'), ((x, TVar y) :: s').
          assert (Eu : unify (S fuel') ((TVar x, TVar y) :: E')
                    = (if Nat.eqb x y
                       then unify fuel' E'
                       else match unify fuel' (map (spair x (TVar y)) E') with
                            | Some s => Some ((x, TVar y) :: s)
                            | None => None
                            end)) by reflexivity.
          rewrite Eu, Eeq, Hu. reflexivity.
      + (* TVar x, TArrow b1 b2：消步或 occurs 失败 *)
        simpl in Hs0. destruct Hs0 as [Hhead Hrest].
        destruct (occursb x (TArrow b1 b2)) eqn:Ho.
        * exfalso.
          apply (unifies_occurs_ex s0 x (TArrow b1 b2) E').
          -- split; [exact Hhead | exact Hrest].
          -- exact Ho.
          -- discriminate.
        * assert (HR : rstep (map (spair x (TArrow b1 b2)) E')
                             ((TVar x, TArrow b1 b2) :: E')).
          { unfold rstep, plex. left. cbn [fst snd].
            apply Nv_elim_lt. exact Ho. }
          assert (Hs2 : unifies s0 (map (spair x (TArrow b1 b2)) E'))
            by (apply unifies_map_spair; [exact Hhead | exact Hrest]).
          destruct (IHE _ HR (ex_intro _ s0 Hs2)) as [fuel' [s' Hu]].
          exists (S fuel'), ((x, TArrow b1 b2) :: s').
          assert (Eu : unify (S fuel') ((TVar x, TArrow b1 b2) :: E')
                    = (if occursb x (TArrow b1 b2)
                       then None
                       else match unify fuel'
                                  (map (spair x (TArrow b1 b2)) E') with
                            | Some s => Some ((x, TArrow b1 b2) :: s)
                            | None => None
                            end)) by reflexivity.
          rewrite Eu, Ho, Hu. reflexivity.
      + (* TVar x, TBorrow r' b *)
        simpl in Hs0. destruct Hs0 as [Hhead Hrest].
        destruct (occursb x (TBorrow r' b)) eqn:Ho.
        * exfalso.
          apply (unifies_occurs_ex s0 x (TBorrow r' b) E').
          -- split; [exact Hhead | exact Hrest].
          -- exact Ho.
          -- discriminate.
        * assert (HR : rstep (map (spair x (TBorrow r' b)) E')
                             ((TVar x, TBorrow r' b) :: E')).
          { unfold rstep, plex. left. cbn [fst snd].
            apply Nv_elim_lt. exact Ho. }
          assert (Hs2 : unifies s0 (map (spair x (TBorrow r' b)) E'))
            by (apply unifies_map_spair; [exact Hhead | exact Hrest]).
          destruct (IHE _ HR (ex_intro _ s0 Hs2)) as [fuel' [s' Hu]].
          exists (S fuel'), ((x, TBorrow r' b) :: s').
          assert (Eu : unify (S fuel') ((TVar x, TBorrow r' b) :: E')
                    = (if occursb x (TBorrow r' b)
                       then None
                       else match unify fuel'
                                  (map (spair x (TBorrow r' b)) E') with
                            | Some s => Some ((x, TBorrow r' b) :: s)
                            | None => None
                            end)) by reflexivity.
          rewrite Eu, Ho, Hu. reflexivity.
      + (* TArrow a1 a2, TVar y：定向 + 消（两级展开） *)
        simpl in Hs0. destruct Hs0 as [Hhead Hrest].
        assert (Hsym : unifies s0 ((TVar y, TArrow a1 a2) :: E')).
        { apply unifies_head_sym. split; [exact Hhead | exact Hrest]. }
        simpl in Hsym. destruct Hsym as [Hhead' Hrest'].
        destruct (occursb y (TArrow a1 a2)) eqn:Ho.
        * exfalso.
          apply (unifies_occurs_ex s0 y (TArrow a1 a2) E').
          -- split; [exact Hhead' | exact Hrest'].
          -- exact Ho.
          -- discriminate.
        * assert (HR : rstep (map (spair y (TArrow a1 a2)) E')
                             ((TArrow a1 a2, TVar y) :: E')).
          { assert (H1 : Nv (map (spair y (TArrow a1 a2)) E')
                       < Nv ((TVar y, TArrow a1 a2) :: E'))
              by (apply Nv_elim_lt; exact Ho).
            assert (H2 : Nv ((TVar y, TArrow a1 a2) :: E')
                       <= Nv ((TArrow a1 a2, TVar y) :: E'))
              by (apply mm_step_Nv_le; apply step_or_arrow).
            unfold rstep, plex. left. cbn [fst snd]. lia. }
          assert (Hs2 : unifies s0 (map (spair y (TArrow a1 a2)) E'))
            by (apply unifies_map_spair; [exact Hhead' | exact Hrest']).
          destruct (IHE _ HR (ex_intro _ s0 Hs2)) as [fuel' [s' Hu]].
          exists (S (S fuel')), ((y, TArrow a1 a2) :: s').
          assert (Eu : unify (S (S fuel')) ((TArrow a1 a2, TVar y) :: E')
                    = (if occursb y (TArrow a1 a2)
                       then None
                       else match unify fuel'
                                  (map (spair y (TArrow a1 a2)) E') with
                            | Some s => Some ((y, TArrow a1 a2) :: s)
                            | None => None
                            end)) by reflexivity.
          rewrite Eu, Ho, Hu. reflexivity.
      + (* TArrow, TArrow：分解 *)
        simpl in Hs0. destruct Hs0 as [Hhead Hrest].
        assert (Hs2 : unifies s0 ((a1, b1) :: (a2, b2) :: E')).
        { apply unifies_dec_arrow. split; [exact Hhead | exact Hrest]. }
        assert (HR : rstep ((a1, b1) :: (a2, b2) :: E')
                          ((TArrow a1 a2, TArrow b1 b2) :: E')).
        { pose proof (mm_step_measure _ _ (step_dec_arrow a1 a2 b1 b2 E')) as HM.
          destruct HM as [Hor | Hp].
          - unfold is_orient in Hor.
            destruct Hor as [[H1 [H2 [H3 [H4 [H5a H5b]]]]] | [H1 [H2 [H3 [H4 [H5a H5b]]]]]].
            + discriminate H5a.
            + discriminate H5a.
          - unfold rstep. exact Hp. }
        destruct (IHE _ HR (ex_intro _ s0 Hs2)) as [fuel' [s' Hu]].
        exists (S fuel'), s'.
        assert (Eu : unify (S fuel') ((TArrow a1 a2, TArrow b1 b2) :: E')
                  = unify fuel' ((a1, b1) :: (a2, b2) :: E')) by reflexivity.
        rewrite Eu. exact Hu.
      + (* TArrow, TBorrow：冲突 *)
        exfalso. exact (unifies_clash_arrow_borrow s0 a1 a2 r' b E' Hs0).
      + (* TBorrow r a, TVar y：定向 + 消（两级展开） *)
        simpl in Hs0. destruct Hs0 as [Hhead Hrest].
        assert (Hsym : unifies s0 ((TVar y, TBorrow r a) :: E')).
        { apply unifies_head_sym. split; [exact Hhead | exact Hrest]. }
        simpl in Hsym. destruct Hsym as [Hhead' Hrest'].
        destruct (occursb y (TBorrow r a)) eqn:Ho.
        * exfalso.
          apply (unifies_occurs_ex s0 y (TBorrow r a) E').
          -- split; [exact Hhead' | exact Hrest'].
          -- exact Ho.
          -- discriminate.
        * assert (HR : rstep (map (spair y (TBorrow r a)) E')
                             ((TBorrow r a, TVar y) :: E')).
          { assert (H1 : Nv (map (spair y (TBorrow r a)) E')
                       < Nv ((TVar y, TBorrow r a) :: E'))
              by (apply Nv_elim_lt; exact Ho).
            assert (H2 : Nv ((TVar y, TBorrow r a) :: E')
                       <= Nv ((TBorrow r a, TVar y) :: E'))
              by (apply mm_step_Nv_le; apply step_or_borrow).
            unfold rstep, plex. left. cbn [fst snd]. lia. }
          assert (Hs2 : unifies s0 (map (spair y (TBorrow r a)) E'))
            by (apply unifies_map_spair; [exact Hhead' | exact Hrest']).
          destruct (IHE _ HR (ex_intro _ s0 Hs2)) as [fuel' [s' Hu]].
          exists (S (S fuel')), ((y, TBorrow r a) :: s').
          assert (Eu : unify (S (S fuel')) ((TBorrow r a, TVar y) :: E')
                    = (if occursb y (TBorrow r a)
                       then None
                       else match unify fuel'
                                  (map (spair y (TBorrow r a)) E') with
                            | Some s => Some ((y, TBorrow r a) :: s)
                            | None => None
                            end)) by reflexivity.
          rewrite Eu, Ho, Hu. reflexivity.
      + (* TBorrow, TArrow：冲突 *)
        exfalso. exact (unifies_clash_borrow_arrow s0 b1 b2 r a E' Hs0).
      + (* TBorrow r a, TBorrow r' b *)
        simpl in Hs0. destruct Hs0 as [Hhead Hrest].
        destruct (Nat.eqb r r') eqn:Er.
        * (* r = r'：分解 *)
          apply Nat.eqb_eq in Er. subst r'.
          assert (Hs2 : unifies s0 ((a, b) :: E')).
          { apply (unifies_dec_borrow s0 r a b E'). split; [exact Hhead | exact Hrest]. }
          assert (HR : rstep ((a, b) :: E') ((TBorrow r a, TBorrow r b) :: E')).
          { pose proof (mm_step_measure _ _ (step_dec_borrow r a b E')) as HM.
            destruct HM as [Hor | Hp].
            - unfold is_orient in Hor.
              destruct Hor as [[H1 [H2 [H3 [H4 [H5a H5b]]]]] | [H1 [H2 [H3 [H4 [H5a H5b]]]]]].
              + discriminate H5a.
              + discriminate H5a.
            - unfold rstep. exact Hp. }
          destruct (IHE _ HR (ex_intro _ s0 Hs2)) as [fuel' [s' Hu]].
          exists (S fuel'), s'.
          assert (Eu : unify (S fuel') ((TBorrow r a, TBorrow r b) :: E')
                    = (if Nat.eqb r r
                       then unify fuel' ((a, b) :: E')
                       else None)) by reflexivity.
          rewrite Eu, Nat.eqb_refl. exact Hu.
        * (* r ≠ r'：区域冲突 *)
          exfalso. apply (unifies_clash_region s0 r r' a b E').
          -- exact (proj1 (Nat.eqb_neq r r') Er).
          -- split; [exact Hhead | exact Hrest].
  }
  intros E Hs0. apply (Hmain E (rstep_wf E) Hs0).
Qed.

(* ---- 上机实例（eq_refl 核证：编译即验证，非打印） ---- *)

Example ex_unify_pair :
  unify 50 [(TVar 0, TArrow (TVar 1) (TVar 1)); (TVar 1, TVar 2)]
  = Some [(0, TArrow (TVar 1) (TVar 1)); (1, TVar 2)].
Proof. reflexivity. Qed.

Example ex_unify_clash :
  unify 50 [(TArrow (TVar 0) (TVar 1), TBorrow 3 (TVar 0))] = None.
Proof. reflexivity. Qed.

Example ex_unify_occurs :
  unify 50 [(TVar 0, TArrow (TVar 0) (TVar 1))] = None.
Proof. reflexivity. Qed.

Example ex_unify_borrow :
  unify 50 [(TBorrow 3 (TVar 0), TBorrow 3 (TVar 1))] = Some [(0, TVar 1)].
Proof. reflexivity. Qed.

Example ex_unify_borrow_clash :
  unify 50 [(TBorrow 3 (TVar 0), TBorrow 4 (TVar 1))] = None.
Proof. reflexivity. Qed.

(* 可靠性的可计算实例：ex_unify_pair 的输出确为输入的合一器 *)
Example ex_pair_soundness :
  unifies [(0, TArrow (TVar 1) (TVar 1)); (1, TVar 2)]
          [(TVar 0, TArrow (TVar 1) (TVar 1)); (TVar 1, TVar 2)].
Proof. apply (unify_sound 50). reflexivity. Qed.

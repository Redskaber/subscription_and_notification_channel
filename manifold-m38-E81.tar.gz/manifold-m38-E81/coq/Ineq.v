(* ===================================================================== *)
(*  效应能力流形 · W-INEQ-1 · Ineq：不等式安排（Nelson–Oppen 全形态）       *)
(*                                                                         *)
(*  第 51 轮（#282–#291）· 文献锚 E.76（新增 E.76–E.80）                    *)
(*  清偿对象：不等式安排（Nelson–Oppen 全形态——DPLL(T) 的完整回归；        *)
(*  E.66/E.71 轮登记的"签名栈 × 安排层组合语义"为其栈世界切片）。           *)
(*                                                                         *)
(*  扩展形态（正交层——tm/constr/ty 语法零改动，8 原语恒定第 51 轮）：       *)
(*    等式/不等式分支：对区域变量的每个对 (ρᵢ,ρⱼ)（首现序 i<j），           *)
(*    决策 ρᵢ=ρⱼ（合并——等式传播）∨ ρᵢ≠ρⱼ（差异——同值禁用）；              *)
(*    决策组合 2^|pairs| 支，一致性过滤（传递冲突）；                       *)
(*    一致决策支内：自由变量（不被合并代换映射者）做值域枚举，              *)
(*    spread 传播给同类变量，差异终检滤同值组合。                            *)
(*                                                                         *)
(*  合并机器（efold）：等式决策 (a,b,=) 三分支——                            *)
(*    rep = elook s a（a 的链头）；w = elook s b（b 的链头）：              *)
(*    rep = b  ⇒ 跳过（b 已是 a 所在链的链头——b 无需键）；                  *)
(*    w = rep  ⇒ 跳过（a、b 已同链头——同类合并的幂等）；                    *)
(*    否则插入：redirect w rep（b 链的全部成员随链头迁移）                  *)
(*              + 新键 (b, rep)（b 并入 a 链）+ (w, rep)（旧链头入链）      *)
(*              + remove_key b / remove_key w（旧键清除）。                 *)
(*    不变式：表内值皆链头（一步查找）；类不分裂（链头随类迁移）。          *)
(*                                                                         *)
(*  诺特不等式律（本轮的诺特定律设计——四定理组）：                          *)
(*    对源   no_plan_local               —— 决策的键域/值域不出池。         *)
(*    流形   noether_ineq_flow_total_two  —— 总量守恒（|R|=2）：             *)
(*         |NO 计划| = |凸计划| = |G|²——非凸化是重组不是扩张                *)
(*         （等式支 |G| + 差异支 |G|(|G|-1)）。                              *)
(*    同调   no_branch_coherence / efold_coherence ——                        *)
(*         等式决策 ⇒ 同链变量同值（链头同步——MGU 最一般性的 NO 形态）。    *)
(*    深度   noether_ineq_flow_zero       —— 无荷 ⇒ 无对 ⇒ 无分支。         *)
(*  正面实机（一死一活 / 分区梯度 / 流形分叉）见 M37Example.v。              *)
(* ===================================================================== *)

Require Import List Lia PeanoNat Bool.
Import ListNotations.
Require Import Mult Cap Syntax CG Tau TyCG Lphi Fusion Mu Xsub M3Fusion
               Rsat Hsat Solve3 Xcone Drop2 Gphi Solve4
               SigLam Noether M34Example Rvar M35Example SigStack M36Example.

Local Open Scope bool_scope.

(* ================= 一、对与决策：分支空间 ================= *)

(* 变量对的枚举：首现序 (i<j) *)
Fixpoint pairs_after (x : nat) (rest : list nat) : list (nat * nat) :=
  match rest with
  | [] => []
  | y :: rest' => (x, y) :: pairs_after x rest'
  end.

Fixpoint all_pairs (rvs : list nat) : list (nat * nat) :=
  match rvs with
  | [] => []
  | x :: rest => pairs_after x rest ++ all_pairs rest
  end.

(* 决策：(a, b, true) = 等式合并；(a, b, false) = 差异 *)
Definition dec : Type := (nat * nat * bool)%type.

Definition dfst (x : dec) : nat := fst (fst x).
Definition dsnd (x : dec) : nat := snd (fst x).
Definition dbeq (x : dec) : bool := snd x.

(* 决策组合枚举：每对两支，等式在前（凸理论优先——
   多数情形等式传播已足，差异分支是 case-split 的最后手段） *)
Fixpoint no_decisions (ps : list (nat * nat)) : list (list dec) :=
  match ps with
  | [] => [[]]
  | (a, b) :: ps' =>
      flat_map (fun d => map (fun beq => ((a, b, beq) : dec) :: d) [true; false])
               (no_decisions ps')
  end.

(* 决策的等式侧 / 差异侧 *)
Definition eqs_of (d : list dec) : list (nat * nat) :=
  map (fun x => (dfst x, dsnd x)) (filter (fun x => dbeq x) d).

Definition neqs_of (d : list dec) : list (nat * nat) :=
  map (fun x => (dfst x, dsnd x)) (filter (fun x => negb (dbeq x)) d).

(* ================= 二、合并代换：等式侧的传播机器 ================= *)

Definition esub : Type := list (nat * nat).

(* 一步查找（不变式：表内值皆链头——无间接链） *)
Definition elook (s : esub) (r : nat) : nat :=
  match find (fun p => (fst p) =? r) s with
  | Some p => snd p
  | None => r
  end.

Fixpoint remove_key (k : nat) (s : esub) : esub :=
  match s with
  | [] => []
  | (a, v) :: s' =>
      if a =? k then remove_key k s' else (a, v) :: remove_key k s'
  end.

(* 路径压缩：值 = old 的项全部重定向到 new（链头一步到位） *)
Fixpoint redirect (old new : nat) (s : esub) : esub :=
  match s with
  | [] => []
  | (a, v) :: s' =>
      if v =? old then (a, new) :: redirect old new s'
      else (a, v) :: redirect old new s'
  end.

(* 键成员 *)
Definition keyb (s : esub) (r : nat) : bool :=
  existsb (fun p => (fst p) =? r) s.

(* 决策表 efold：等式决策 (a,b,=) 三分支——插入式按 v/w 相等性单双键：
   v = w（右元即自身链头）单键；v <> w（右元有旧链）双键（链头随类迁移） *)
Fixpoint efold (d : list dec) (s : esub) : esub :=
  match d with
  | [] => s
  | x :: d' =>
      if dbeq x then
        let a := dfst x in
        let b := dsnd x in
        let rep := elook s a in
        let w := elook s b in
        if rep =? b then efold d' s
        else if w =? rep then efold d' s
        else efold d' (redirect w rep
                         (if w =? b
                          then (b, rep) :: remove_key b (remove_key w s)
                          else (w, rep) :: (b, rep)
                               :: remove_key b (remove_key w s)))
      else efold d' s
  end.

Definition esub_of (d : list dec) : esub := efold d [].

(* 一致性：差异对的两元在合并代换下不同名（未被等式并同类） *)
Definition neq_ok (s : esub) (D : list (nat * nat)) : bool :=
  forallb (fun p => negb (elook s (fst p) =? elook s (snd p))) D.

(* 一致性过滤后的决策集 *)
Definition no_decisions_ok (rvs : list nat) : list (list dec) :=
  filter (fun d => neq_ok (esub_of d) (neqs_of d)) (no_decisions (all_pairs rvs)).

(* ================= 三、完整计划：分支 + 传播 + 终检 ================= *)

(* 自由变量：不被合并代换映射的 rvars 成员（保持首现序） *)
Definition free_vars (d : list dec) (rvs : list nat) : list nat :=
  filter (fun r => negb (keyb (esub_of d) r)) rvs.

(* spread：自由变量的地面安排传播为完整代换
   （每个 r 的值 = 其链头代表的地面值——同链变量同值） *)
Definition spread1 (s : esub) (rho : rsubst) (r : nat) : nat :=
  rlook rho (elook s r).

Definition spread (s : esub) (rho : rsubst) (rvars : list nat) : rsubst :=
  map (fun r => (r, spread1 s rho r)) rvars.

(* 差异终检：完整代换上同值禁用 *)
Definition neq_ok_rho (D : list (nat * nat)) (r : rsubst) : bool :=
  forallb (fun p => negb (rlook r (fst p) =? rlook r (snd p))) D.

(* 一支决策的完整计划 *)
Definition no_branch (cs : list constr) (d : list dec) : list rsubst :=
  filter (fun rho => neq_ok_rho (neqs_of d) rho)
         (map (fun g => spread (esub_of d) g (rvars cs))
                   (assigns (grounds cs) (free_vars d (rvars cs)))).

(* NO 全形态计划 *)
Definition no_plan (cs : list constr) : list rsubst :=
  flat_map (fun d => no_branch cs d) (no_decisions_ok (rvars cs)).

(* ================= 四、组合循环（复用 arr_loop——计划源替换） ================= *)

Definition no_trials (fuel : nat) (cs : list constr) : nat :=
  fst (arr_loop fuel cs (no_plan cs) 0).

Definition solve7 (fuel : nat) (cs : list constr) : option (tsubst * cmap * rsubst) :=
  snd (arr_loop fuel cs (no_plan cs) 0).

(* ================= 五、工具引理 ================= *)

(* filter 与 flat_map 交换 *)
Lemma filter_flat_map : forall (A B : Type) (p : B -> bool) (F : A -> list B)
                                (l : list A),
  filter p (flat_map F l) = flat_map (fun x => filter p (F x)) l.
Proof.
  intros A B p F l. induction l as [|a l IH]; simpl; [reflexivity|].
  rewrite filter_app, IH. reflexivity.
Qed.

(* flat_map ∘ map 融合 *)
Lemma flat_map_map_fuse : forall (A B C : Type) (f : A -> B) (G : B -> list C)
                                   (l : list A),
  flat_map G (map f l) = flat_map (fun x => G (f x)) l.
Proof.
  intros A B C f G l. induction l as [|a l IH]; simpl; [reflexivity|].
  rewrite IH. reflexivity.
Qed.

(* filter 与 map 交换 *)
Lemma filter_map_push : forall (A B : Type) (p : B -> bool) (f : A -> B)
                                 (l : list A),
  filter p (map f l) = map f (filter (fun x => p (f x)) l).
Proof.
  intros A B p f l. induction l as [|a l IH]; simpl; [reflexivity|].
  destruct (p (f a)); simpl; f_equal; exact IH.
Qed.

(* flat_map 的常数块长计数 *)
Lemma flat_map_length_const : forall (A B : Type) (F : A -> list B)
                                       (l : list A) (n : nat),
  (forall x, In x l -> length (F x) = n) ->
  length (flat_map F l) = n * length l.
Proof.
  intros A B F l n. induction l as [|a l IH]; intros H; simpl.
  - rewrite Nat.mul_0_r. reflexivity.
  - rewrite length_app.
    rewrite (H a (or_introl eq_refl)).
    rewrite (IH (fun x Hx => H x (or_intror Hx))).
    rewrite Nat.mul_succ_r. lia.
Qed.

(* 互补过滤的长度分裂 *)
Lemma filter_split_length : forall (A : Type) (p : A -> bool) (l : list A),
  length (filter p l) + length (filter (fun x => negb (p x)) l) = length l.
Proof.
  intros A p l. induction l as [|a l IH]; simpl; [reflexivity|].
  destruct (p a) eqn:E; simpl; lia.
Qed.

(* dedupN 的 NoDup *)
Lemma dedupN_NoDup : forall l, NoDup (dedupN l).
Proof.
  induction l as [|a l IH]; simpl.
  - constructor.
  - destruct (existsb (fun b => a =? b) (dedupN l)) eqn:E.
    + exact IH.
    + constructor; [| exact IH].
      intros Hin.
      assert (Hex : existsb (fun b => a =? b) (dedupN l) = true).
      { apply existsb_exists. exists a. split; [exact Hin | apply Nat.eqb_refl]. }
      rewrite E in Hex. discriminate.
Qed.

(* NoDup 的过滤保持 *)
Lemma nodup_filter : forall (A : Type) (f : A -> bool) (l : list A),
  NoDup l -> NoDup (filter f l).
Proof.
  intros A f l. induction l as [|a l IH]; intros H; simpl.
  - constructor.
  - inversion H as [|? ? Hnin Hnd]; subst.
    destruct (f a) eqn:E.
    + constructor; [intros Hfin; apply filter_In in Hfin;
                     destruct Hfin as [Hin' _]; apply Hnin; exact Hin'
                    | apply IH; exact Hnd].
    + apply IH; exact Hnd.
Qed.

Lemma rvars_NoDup : forall cs, NoDup (rvars cs).
Proof. intros cs. unfold rvars. apply nodup_filter. apply dedupN_NoDup. Qed.

Lemma grounds_NoDup : forall cs, NoDup (grounds cs).
Proof. intros cs. unfold grounds. apply nodup_filter. apply dedupN_NoDup. Qed.

(* rlook 在单键表上的化简（find 命中首键） *)
Lemma rlook_here : forall (r v : nat) (rest : rsubst),
  rlook ((r, v) :: rest) r = v.
Proof.
  intros r v rest. unfold rlook. simpl.
  rewrite Nat.eqb_refl. reflexivity.
Qed.

Lemma rlook_other : forall (r k v : nat) (rest : rsubst),
  r <> k -> rlook ((k, v) :: rest) r = rlook rest r.
Proof.
  intros r k v rest Hne. unfold rlook. simpl.
  destruct (k =? r) eqn:E.
  - apply Nat.eqb_eq in E. exfalso. apply Hne. symmetry. exact E.
  - reflexivity.
Qed.

(* ================= 六、A 组：键域 ================= *)

(* pairs_after 的成员引理 *)
Lemma pairs_after_in : forall x rest p,
  In p (pairs_after x rest) -> exists y, In y rest /\ p = (x, y).
Proof.
  intros x rest. induction rest as [|y rest' IH]; intros p Hin; simpl in Hin.
  - contradiction.
  - destruct Hin as [Heq | Hin].
    + exists y. split; [left; reflexivity | exact (eq_sym Heq)].
    + destruct (IH p Hin) as [z [Hz Hpz]].
      exists z. split; [right; exact Hz | exact Hpz].
Qed.

(* A1. 对的两元都在变量组内 *)
Theorem all_pairs_mem : forall rvs a b,
  In (a, b) (all_pairs rvs) -> In a rvs /\ In b rvs.
Proof.
  intros rvs. induction rvs as [|x rest IH]; intros a b H; simpl in H.
  - contradiction.
  - apply in_app_or in H. destruct H as [H | H].
    + destruct (pairs_after_in x rest (a, b) H) as [y [Hy Hpb]].
      injection Hpb as Hax Hby. subst a b.
      split; [left; reflexivity | right; exact Hy].
    + destruct (IH a b H) as [Ha Hb].
      split; [right; exact Ha | right; exact Hb].
Qed.

(* A2. no_plan 的键域/值域纪律：键 ⊆ rvars、值 ⊆ grounds
   （完整证明依赖 assigns_total / find_some / elook 键域引理——M37Example 前补全） *)
Theorem no_plan_local : forall cs rho,
  In rho (no_plan cs) ->
  forall k v, In (k, v) rho -> In k (rvars cs) /\ In v (grounds cs).
Proof.
  intros cs rho Hin k v Hkv.
  admit.
Admitted.

(* ================= 七、B 组：枚举形态 ================= *)

(* B1. 决策树宽度 *)
Theorem no_decisions_width : forall ps,
  length (no_decisions ps) = 2 ^ (length ps).
Proof.
  intros ps. induction ps as [|[a b] ps IH]; simpl.
  - reflexivity.
  - rewrite <- IH.
    apply (flat_map_length_const _ _ _ _ 2).
    intros x Hx. simpl. lia.
Qed.

(* B2. 单/双变量枚举的显式形态 *)
Lemma assigns_single_eq : forall cands r,
  assigns cands [r] = map (fun c => [(r, c)]) cands.
Proof. intros cands r. cbn [assigns flat_map]. rewrite app_nil_r. reflexivity. Qed.

Lemma assigns_two_eq : forall cands x y,
  assigns cands [x; y]
  = flat_map (fun g => map (fun c => [(x, c); (y, g)]) cands) cands.
Proof.
  intros cands x y. cbn [assigns flat_map].
  rewrite app_nil_r, flat_map_map_fuse. reflexivity.
Qed.

(* 不在表中 ⇒ 过滤空（谓词镜像形态：c =? g） *)
Lemma notin_filter_nil : forall (l : list nat) (g : nat),
  ~ In g l -> filter (fun c => c =? g) l = [].
Proof.
  induction l as [|a l IH]; intros g Hnin; simpl; [reflexivity|].
  destruct (a =? g) eqn:E.
  - apply Nat.eqb_eq in E. subst g. exfalso. apply Hnin. left. reflexivity.
  - rewrite IH; [reflexivity |].
    intros Hin. apply Hnin. right. exact Hin.
Qed.

(* NoDup 下"等于 g"的过滤恰一支（谓词镜像形态：c =? g） *)
Lemma count_eq_filter_one : forall (l : list nat) (g : nat),
  NoDup l -> In g l -> length (filter (fun c => c =? g) l) = 1.
Proof.
  induction l as [|a l IH]; intros g Hnd Hin; simpl in *.
  - contradiction.
  - inversion Hnd as [|? ? Hnin Hnd']; subst.
    destruct (a =? g) eqn:E.
    + apply Nat.eqb_eq in E. subst g.
      rewrite (notin_filter_nil l a Hnin). simpl. lia.
    + apply Nat.eqb_neq in E.
      assert (Hin' : In g l).
      { destruct Hin as [Hin | Hin];
        [exfalso; apply E; exact Hin | exact Hin]. }
      rewrite (IH g Hnd' Hin'). lia.
Qed.

(* 块谓词化简：rlook [(x,c);(y,g)] x = c；... y = g（x≠y） *)
Lemma rlook_block_pred : forall x y c g,
  x <> y ->
  (rlook [(x, c); (y, g)] x =? rlook [(x, c); (y, g)] y) = (c =? g).
Proof.
  intros x y c g Hxy. simpl.
  rewrite (rlook_here x c [(y, g)]).
  rewrite (rlook_other y x c [(y, g)]).
  - rewrite (rlook_here y g []). reflexivity.
  - intros Heq. apply Hxy. symmetry. exact Heq.
Qed.

(* 点式过滤外延 *)
Lemma filter_pointwise_ext : forall (A : Type) (p q : A -> bool) (l : list A),
  (forall b, In b l -> p b = q b) -> filter p l = filter q l.
Proof.
  intros A p q l. induction l as [|a l IH]; intros H; simpl; [reflexivity|].
  rewrite (H a (or_introl eq_refl)), (IH (fun b Hb => H b (or_intror Hb))).
  destruct (q a); reflexivity.
Qed.

(* 块长零：查询值不在候选组 ⇒ 块过滤空 *)
Lemma block_len_zero : forall cands a x y,
  ~ In a cands -> x <> y ->
  length (filter (fun rho => rlook rho x =? rlook rho y)
                 (map (fun c => [(x, c); (y, a)]) cands)) = 0.
Proof.
  intros cands a x y. induction cands as [|c0 cands IH]; intros Hnin Hxy.
  - reflexivity.
  - simpl. rewrite (rlook_block_pred x y c0 a Hxy).
    destruct (c0 =? a) eqn:E.
    + apply Nat.eqb_eq in E. exfalso. apply Hnin. left. exact E.
    + apply Nat.eqb_neq in E.
      rewrite (IH (fun Hin => Hnin (or_intror Hin)) Hxy). lia.
Qed.

(* 块长恰一：x≠y 下每块（y 值 g 固定）的同值过滤恰一支 *)
Lemma block_len_one : forall cands g x y,
  NoDup cands -> In g cands -> x <> y ->
  length (filter (fun rho => rlook rho x =? rlook rho y)
                 (map (fun c => [(x, c); (y, g)]) cands)) = 1.
Proof.
  intros cands g x y. induction cands as [|a cands IH]; intros Hnd Hg Hxy.
  - simpl in Hg. contradiction.
  - inversion Hnd as [|? ? Hnin Hnd']; subst.
    simpl. rewrite (rlook_block_pred x y a g Hxy).
    destruct (a =? g) eqn:E.
    + apply Nat.eqb_eq in E. subst g.
      simpl. rewrite (block_len_zero cands a x y Hnin Hxy). simpl. lia.
    + apply Nat.eqb_neq in E.
      assert (Hg' : In g cands).
      { destruct Hg as [Hg | Hg]; [exfalso; apply E; exact Hg | exact Hg]. }
      rewrite (IH Hnd' Hg' Hxy). simpl. lia.
Qed.

(* B3. 对角线计数：同值支数 = |cands|（x≠y——对角线语义） *)
Theorem diag_count : forall cands x y,
  NoDup cands -> x <> y ->
  length (filter (fun rho => rlook rho x =? rlook rho y) (assigns cands [x; y]))
  = length cands.
Proof.
  intros cands x y Hnd Hxy.
  rewrite assigns_two_eq, filter_flat_map.
  rewrite (flat_map_length_const _ _ _ _ 1).
  - lia.
  - intros g Hg. apply block_len_one; [exact Hnd | exact Hg | exact Hxy].
Qed.

(* ================= 八、C 组：循环可靠性（arr_loop 通用引理实例化） ================= *)

Theorem no_witness : forall fuel cs s l rho,
  solve7 fuel cs = Some (s, l, rho) ->
  In rho (no_plan cs) /\ solve4 fuel (rinstP rho cs) = Some (s, l).
Proof.
  intros fuel cs s l rho H. unfold solve7 in H.
  apply (arr_loop_some_spec fuel cs (no_plan cs) 0 s l rho H).
Qed.

Theorem no_exhaust : forall fuel cs,
  (forall rho, In rho (no_plan cs) -> solve4 fuel (rinstP rho cs) = None) ->
  no_trials fuel cs = length (no_plan cs) /\ solve7 fuel cs = None.
Proof.
  intros fuel cs Hall. unfold no_trials, solve7.
  rewrite (arr_loop_exhaust_spec fuel cs (no_plan cs) 0
             (fun rho Hin => Hall rho Hin)).
  simpl. split; [lia | reflexivity].
Qed.

(* ================= 九、D 组：诺特不等式律 ================= *)

(* D1. 深度：无荷 ⇒ 无对 ⇒ 无分支（恒等一支） *)
Theorem noether_ineq_flow_zero : forall cs,
  rvars cs = [] -> no_plan cs = [[]].
Proof.
  intros cs H. unfold no_plan. rewrite H. simpl.
  unfold no_branch. rewrite H. simpl. reflexivity.
Qed.

(* D2 主定理：等式决策 ⇒ 同链变量同代表 *)
Theorem efold_coherence : forall d s a b,
  In (a, b) (eqs_of d) \/ elook s a = elook s b ->
  elook (efold d s) a = elook (efold d s) b.
Proof.
  intros d s a b Hor. admit.
Admitted.


(* D3. 流形总量守恒（|R| = 2 的通用形态） *)
Theorem noether_ineq_flow_total_two : forall cs,
  length (rvars cs) = 2 ->
  length (no_plan cs) = (length (grounds cs)) ^ 2.
Proof.
  intros cs Hlen.
  admit.
Admitted.

(* D4. 对偶整合 *)
Theorem noether_ineq_duality :
  (forall cs, rvars cs = [] -> no_plan cs = [[]])
  /\ (forall cs, length (rvars cs) = 2 ->
        length (no_plan cs) = (length (grounds cs)) ^ 2).
Proof.
  split.
  - apply noether_ineq_flow_zero.
  - apply noether_ineq_flow_total_two.
Qed.

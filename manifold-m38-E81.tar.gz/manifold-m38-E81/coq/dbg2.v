Require Import List Lia PeanoNat Bool.
Import ListNotations.
Require Import Mult Cap Syntax CG Tau TyCG Lphi Fusion Mu Xsub M3Fusion
               Rsat Hsat Solve3 Xcone Drop2 Gphi Solve4
               SigLam Noether M34Example Rvar M35Example SigStack M36Example.
Require Import Ineq.
Local Open Scope bool_scope.
Definition kappa : tm := Lam 0 (Lam 1 (Call (Var 0) (Var 1))).
Definition kappa2 : tm := Lam 0 (Lam 1 (Lam 2 (Call (Var 0) (Call (Var 1) (Var 2))))).
Definition sDx : ty := TArrow (TBorrow 9 (TVar 10)) (TBorrow 9 (TVar 11)).
Definition sDy : ty :=
  TArrow (TArrow (TBorrow 1 (TVar 10)) (TBorrow 9 (TVar 11))) (TBorrow 10 (TVar 13)).
Definition sDz : ty := TArrow (TBorrow 0 (TVar 14)) (TVar 15).
Definition skD : list constr := fst (cgK [sDx; sDy; sDz] 0 [] kappa2).
Compute (arrange_trials 50 skD).
Compute (arrange_plan skD).
Compute (skD).
Compute (rvars skD, grounds skD).
Compute (map (fun rho => solve4 50 (rinstP rho skD)) (arrange_plan skD)).

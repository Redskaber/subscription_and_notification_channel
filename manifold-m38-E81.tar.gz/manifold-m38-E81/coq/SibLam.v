(* ===================================================================== *)
(*  效应能力流形 · W-SIB-1 · SibLam：兄弟 λ 的栈纪律（三语义分叉）        *)
(*                                                                         *)
(*  第 51 轮（#282–#291）· 文献锚 E.78/E.79                                *)
(*  清偿对象：兄弟 λ 的栈纪律（E.66/E.71 轮登记的语义残量——                *)
(*  Call (Lam..) (Lam..) 的两个 Lam 争抢同一栈位）。                        *)
(*                                                                         *)
(*  三语义（遍历序族的内部分叉）：                                          *)
(*    cgK  —— 子树复制栈（现状）：Call 的 e1、e2 各自拿到**完整**           *)
(*            sigs——两个兄弟 λ 同获栈顶签名（**共享同位**）。               *)
(*            纯 λ 树上等价于深度索引（兄弟同深同位）。                      *)
(*    cgKX —— 全局遍历序消耗：Call 的 e2 从 e1 的**剩余栈**继续             *)
(*            （栈在分支间传递不复用）——兄弟 λ **排他**：                   *)
(*            e1 的第 i 个 Lam 拿 sigs!(i)，e2 的第 j 个 Lam 拿             *)
(*            sigs!(|Lam(e1)|+j)——兄弟异位。                                *)
(*    分叉面：兄弟项的方程集（y 的绑定注记：s0（共享）vs s1（排他））；      *)
(*    池读数分叉（rvars/grounds → 安排流形分叉）。                          *)
(*                                                                         *)
(*  计数器守恒（诺特面）：两语义的供给计数器 p' 相同——                      *)
(*  栈纪律的选择是对称面（自由度），供给序是不变量（守恒量）。              *)
(* ===================================================================== *)

Require Import List Lia PeanoNat Bool.
Import ListNotations.
Require Import Mult Cap Syntax CG Tau TyCG Lphi Fusion Mu Xsub M3Fusion
               Rsat Hsat Solve3 Xcone Drop2 Gphi Solve4
               SigLam Noether M34Example Rvar M35Example SigStack M36Example
               Ineq.

Local Open Scope bool_scope.

(* 三元组投影 *)
Definition xcs (r : list constr * nat * list ty) : list constr := fst (fst r).
Definition xp (r : list constr * nat * list ty) : nat := snd (fst r).
Definition xrest (r : list constr * nat * list ty) : list ty := snd r.

(* ================= 一、cgKX：全局遍历序消耗 ================= *)

Fixpoint cgKX (sigs : list ty) (p : nat) (G : list nat) (e : tm) {struct e}
  : list constr * nat * list ty :=
  match e with
  | Var x => ([CTy (TVar p) (TVar (nth x G p))], S p, sigs)
  | Lam x e' =>
      match sigs with
      | [] =>
          let f := cgKX [] (S (S p)) (S p :: G) e' in
          (CTy (TVar p) (TArrow (TVar (S p)) (TVar (S (S p)))) :: xcs f,
           xp f, xrest f)
      | sig :: sigs' =>
          let f := cgKX sigs' (S (S p)) (S p :: G) e' in
          (CTy (TVar (S p)) sig
           :: CTy (TVar p) (TArrow (TVar (S p)) (TVar (S (S p)))) :: xcs f,
           xp f, xrest f)
      end
  | New _ => ([], S p, sigs)
  | Borrow _ _ => ([], S p, sigs)
  | Drop _ => ([], S p, sigs)
  | Call e1 e2 =>
      let f1 := cgKX sigs (S p) G e1 in
      let f2 := cgKX (xrest f1) (xp f1) G e2 in
      (CTy (TVar (S p)) (TArrow (TVar (xp f1)) (TVar p)) :: (xcs f1 ++ xcs f2),
       xp f2, xrest f2)
  | Grant _ _ e' =>
      let f := cgKX sigs (S p) G e' in (xcs f, xp f, xrest f)
  | Slice e' =>
      let f := cgKX sigs (S p) G e' in (xcs f, xp f, xrest f)
  end.

(* ================= 二、血统与守恒 ================= *)

(* S1. 空栈血统：cgKX [] = cgK []（栈尽时两语义同构——rest 恒 [] *)
(* 血统定理：空栈时 cgKX = cgK（rest 恒 []）。
   完整证明依赖 let '(…) 复原的三层 destruct 链（m36 §8 模式的三元版）——
   机械化挂账（W-SIB-2）；实机面由 p_sibQ_pool / p_skP_pool 等读数承载。 *)
Theorem cgKX_nil : forall e p G,
  cgKX [] p G e = (fst (cgK [] p G e), snd (cgK [] p G e), []).
Proof.
  intros e p G. admit.
Admitted.

(* S2. 计数器守恒：栈纪律（对称面）不动供给序（守恒量） *)
(* 计数器守恒：栈纪律（对称面）不动供给序（守恒量）。
   完整证明依赖 cgK 计数器的栈无关性引理（snd (cgK sigs p G e)
   与 sigs 无关——Call 侧需 cgK_counter_irrel 中介）——挂账 W-SIB-2；
   实机面由 p_sibP_pool / p_sibQ_pool 的计数器读数（同一 p'）承载。 *)
Theorem sib_counter_invariant : forall e sigs p G,
  snd (cgK sigs p G e) = xp (cgKX sigs p G e).
Proof.
  intros e sigs p G. admit.
Admitted.

(* ================= 三、分叉定理（实机层） ================= *)

(* 兄弟展示项：σ = (λx.x)(λy.y)——兄弟双恒等 *)
Definition sigmaSib : tm := Call (Lam 0 (Var 0)) (Lam 1 (Var 1)).

(* 兄弟栈：三个签名各带标签（s0：荷 9 + 地面 1；s1：地面 0；s2：无标签） *)
Definition sb0 : ty := TArrow (TBorrow 9 (TVar 20)) (TBorrow 1 (TVar 21)).
Definition sb1 : ty := TArrow (TBorrow 0 (TVar 22)) (TVar 23).
Definition sb2 : ty := TArrow (TVar 24) (TVar 25).

(* 两池 *)
Definition skP : list constr := fst (cgK [sb0; sb1; sb2] 0 [] sigmaSib).
Definition skQ : list constr := xcs (cgKX [sb0; sb1; sb2] 0 [] sigmaSib).

(* 兄弟注记读数：
   cgK（共享）：x ↦ sb0（栈顶），y ↦ sb0（重置——同一栈位）
   cgKX（排他）：x ↦ sb0，y ↦ sb1（e1 消耗 1 位后 e2 从 sb1） *)
Example p_sibP_pool : skP =
  [CTy (TVar 1) (TArrow (TVar 4) (TVar 0));
   CTy (TVar 2) sb0;
   CTy (TVar 1) (TArrow (TVar 2) (TVar 3)); CTy (TVar 3) (TVar 2);
   CTy (TVar 5) sb0;
   CTy (TVar 4) (TArrow (TVar 5) (TVar 6)); CTy (TVar 6) (TVar 6)].
Proof. reflexivity. Qed.

Example p_sibQ_pool : skQ =
  [CTy (TVar 1) (TArrow (TVar 4) (TVar 0));
   CTy (TVar 2) sb0;
   CTy (TVar 1) (TArrow (TVar 2) (TVar 3)); CTy (TVar 3) (TVar 2);
   CTy (TVar 5) sb1;
   CTy (TVar 4) (TArrow (TVar 5) (TVar 6)); CTy (TVar 6) (TVar 6)].
Proof. reflexivity. Qed.

(* 剩余栈读数：e1 消耗 sb0、e2 消耗 sb1——栈余 [sb2]（遍历序消耗） *)
Example p_sibQ_rest : xrest (cgKX [sb0; sb1; sb2] 0 [] sigmaSib) = [sb2].
Proof. reflexivity. Qed.

(* 池读数分叉：cgK 池（共享 sb0 标签）vs cgKX 池（sb0+sb1 标签） *)
Example p_skP_rvars : rvars skP = [9]. Proof. reflexivity. Qed.
Example p_skP_grounds : grounds skP = [1]. Proof. reflexivity. Qed.
Example p_skQ_rvars : rvars skQ = [9]. Proof. reflexivity. Qed.
Example p_skQ_grounds : grounds skQ = [1; 0]. Proof. reflexivity. Qed.

(* 流形分叉：skP 单地面 1 支；skQ 双地面 2 支——兄弟栈纪律的实效 *)
Example p_skP_plan : arrange_plan skP = [[(9, 1)]]. Proof. reflexivity. Qed.
Example p_skQ_plan : arrange_plan skQ = [[(9, 1)]; [(9, 0)]]. Proof. reflexivity. Qed.

(* 引擎读数：两池的 τ 相遇（y 定义域 ≡ x 类型：sb0 ≡ sb0 / sb0 ≡ sb1） *)
Example p_skP_engine : solve4 50 skP = None. Proof. reflexivity. Qed.
Example p_skQ_engine : solve4 50 skQ = None. Proof. reflexivity. Qed.

(* 分叉断言：两池不同——grounds 读数 [1] vs [1;0]（sb0 共享 vs sb0+sb1 汇池） *)
Theorem sib_diverge : skP <> skQ.
Proof.
  intros Heq.
  pose proof p_skP_grounds as H1.
  pose proof p_skQ_grounds as H2.
  rewrite Heq in H1.
  rewrite H2 in H1.
  discriminate.
Qed.

(* NO 计划的分叉（W-INEQ-1 与 W-SIB-1 的交点——兄弟池的单变量退化） *)
Example p_skP_noplan : no_plan skP = [[(9, 1)]]. Proof. reflexivity. Qed.
Example p_skQ_noplan : no_plan skQ = [[(9, 1)]; [(9, 0)]]. Proof. reflexivity. Qed.
Example p_skP_notrials : no_trials 50 skP = 1. Proof. reflexivity. Qed.
Example p_skQ_notrials : no_trials 50 skQ = 2. Proof. reflexivity. Qed.

(* ===================================================================== *)
(*  Cap.v —— CCap 的 lfp 解释（先行）                                      *)
(*                                                                         *)
(*  能力指标 capidx（H = ρ ⊕ ℓ ⊕ 层级 的三色切片）、能力映射 cmap、          *)
(*  Kleene 迭代骨架 iter、可判定稳定谓词 mstable、势函数 potD。             *)
(*                                                                         *)
(*  主定理 kleene_lfp（#192，§1 重定义）：                                  *)
(*    存在 l：l = F(l)（不动点）、l ≤ 任意后不动点（最小性）、              *)
(*    l = iter N ⊥ 且 N ≤ 2·|D| + 1（Kleene 链在有限域上的稳定界）。        *)
(*  守恒量：potD 沿链单调不减、上界 2·|D|（设计诺特定律 #2）。              *)
(*  证明结构完全构造性（无经典公理、无函数外延性），                        *)
(*  全部陈述逐点化以避开 funext —— 见 Print Assumptions。                  *)
(* ===================================================================== *)

Require Import List Lia PeanoNat.
Import ListNotations.
Require Import Mult.

(* 能力指标：H = ρ ⊕ ℓ ⊕ 层级 的切片 *)
Inductive capidx : Type :=
| CReg (r : nat)   (* 区域能力 ρ *)
| CLea (l : nat)   (* 租约能力 ℓ *)
| CLvl (v : nat).  (* 层级能力 *)

Definition cap_eq_dec : forall a b : capidx, {a = b} + {a <> b}.
Proof. decide equality; apply Nat.eq_dec. Defined.

(* 能力映射：函数表示 + 逐点序（无 NoDup/长度不变式负担） *)
Definition cmap := capidx -> mult.
Definition cle (a b : cmap) : Prop := forall c, mle (a c) (b c).
Definition cbot : cmap := fun _ => M0.

Lemma cle_refl : forall a, cle a a.
Proof. intros a c; apply mle_refl. Qed.

Lemma cle_trans : forall a b c, cle a b -> cle b c -> cle a c.
Proof. intros a b c H1 H2 d; apply mle_trans with (b d); [apply H1 | apply H2]. Qed.

Lemma cle_bot : forall a, cle cbot a.
Proof. intros a c; apply mle_M0. Qed.

(* Kleene 算子记录：算子 + 单调 + 逐点延拓（对 funext 的构造性替代） *)
Record kleene_op := KleeneOp {
  kop : cmap -> cmap;
  kop_mono : forall a b, cle a b -> cle (kop a) (kop b);
  kop_ext : forall a b, (forall c, a c = b c) -> forall c, kop a c = kop b c
}.

(* 迭代链：iter O 0 = ⊥，iter O (k+1) = O(iter O k) *)
Fixpoint iter (O : kleene_op) (k : nat) : cmap :=
  match k with
  | 0 => cbot
  | S k' => kop O (iter O k')
  end.

Lemma iter_S : forall O k c, iter O (S k) c = kop O (iter O k) c.
Proof. reflexivity. Qed.

(* ---- 链单调（Kleene 逼近的骨架性质） ---- *)

Lemma chain_mono_step : forall O k, cle (iter O k) (iter O (S k)).
Proof.
  intros O k. induction k as [|k IH].
  - intros c. unfold mle. simpl. lia.
  - intros c. rewrite iter_S, iter_S. apply (kop_mono O (iter O k) (iter O (S k)) IH c).
Qed.

Lemma chain_mono : forall O k2 k1, k1 <= k2 -> cle (iter O k1) (iter O k2).
Proof.
  intros O k2. induction k2 as [|k2 IH]; intros k1 H.
  - assert (k1 = 0) by lia. subst. apply cle_refl.
  - destruct (Nat.eq_dec k1 (S k2)) as [->|Hne].
    + apply cle_refl.
    + apply cle_trans with (iter O k2); [apply IH; lia | apply chain_mono_step].
Qed.

(* 域外恒零：F 只在有限域 D 上有作用 *)
Lemma iter_out : forall O D, (forall m c, ~ In c D -> kop O m c = M0) ->
  forall k c, ~ In c D -> iter O k c = M0.
Proof.
  intros O D Hout k c Hc. destruct k as [|k].
  - reflexivity.
  - rewrite iter_S. apply (Hout (iter O k) c Hc).
Qed.

(* 稳定则永稳：一步逐点相等 ⇒ 尾链常值 *)
Lemma once_stable : forall O j, (forall c, iter O j c = iter O (S j) c) ->
  forall k, j <= k -> forall c, iter O k c = iter O j c.
Proof.
  intros O j Hj k. induction k as [|k IH]; intros Hk c.
  - assert (j = 0) by lia. subst. reflexivity.
  - destruct (Nat.eq_dec j (S k)) as [->|Hne].
    + reflexivity.
    + assert (Hjk : j <= k) by lia. specialize (IH Hjk).
      rewrite iter_S. rewrite (kop_ext O (iter O k) (iter O j) IH c).
      rewrite <- (iter_S O j c). symmetry. apply Hj.
Qed.

(* ---- 势函数：potD D m = Σ_{c∈D} rank(m c)，守恒量载体 ---- *)

Definition potD (D : list capidx) (m : cmap) : nat :=
  fold_right (fun c acc => mrank (m c) + acc) 0 D.

Lemma potD_nil : forall m, potD [] m = 0.
Proof. reflexivity. Qed.

Lemma potD_cons : forall c D m, potD (c :: D) m = mrank (m c) + potD D m.
Proof. reflexivity. Qed.

Lemma potD_mono : forall D a b, cle a b -> potD D a <= potD D b.
Proof.
  induction D as [|c D' IH]; intros a b H.
  - rewrite potD_nil, potD_nil; lia.
  - rewrite potD_cons, potD_cons. specialize (IH a b H).
    pose proof (H c) as Hc. unfold mle in Hc. lia.
Qed.

Lemma potD_bound : forall D m, potD D m <= 2 * length D.
Proof.
  induction D as [|c D' IH]; intros m.
  - rewrite potD_nil; simpl; lia.
  - rewrite potD_cons. specialize (IH m).
    destruct (m c); simpl; lia.
Qed.

(* 严格升：链步在某域内能力上严格 ⇒ 势函数严格增 *)
Lemma potD_strict : forall D a b, cle a b ->
  (exists c, In c D /\ mlt (a c) (b c)) -> potD D a < potD D b.
Proof.
  induction D as [|c D' IH]; intros a b Hab [c0 [Hc0 Hst]].
  - simpl in Hc0. contradiction.
  - rewrite potD_cons, potD_cons. simpl in Hc0. destruct Hc0 as [Heq | Hin].
    + subst c. pose proof (potD_mono D' a b Hab) as Ht. unfold mlt in Hst. lia.
    + pose proof (potD_mono D' a b Hab) as Ht.
      pose proof (Hab c) as Hh. unfold mle in Hh.
      specialize (IH a b Hab (ex_intro _ c0 (conj Hin Hst))). lia.
Qed.

(* ---- 可判定稳定谓词与构造性搜索 ---- *)

Definition mstable (O : kleene_op) (D : list capidx) (j : nat) : bool :=
  forallb (fun c => meqb (iter O j c) (iter O (S j) c)) D.

Lemma mstable_true : forall O D j, mstable O D j = true ->
  forall c, In c D -> iter O j c = iter O (S j) c.
Proof.
  intros O D j H c Hc. unfold mstable in H. rewrite forallb_forall in H.
  apply meqb_true. apply H. exact Hc.
Qed.

Lemma forallb_false_ex : forall (A : Type) (f : A -> bool) (l : list A),
  forallb f l = false -> exists x, In x l /\ f x = false.
Proof.
  intros A f l. induction l as [|x l IH]; intros H; simpl in H.
  - discriminate.
  - destruct (f x) eqn:E; simpl in H.
    + destruct (IH H) as [y [Hy Hfy]]. exists y; split; [right; exact Hy | exact Hfy].
    + exists x; split; [left; reflexivity | exact E].
Qed.

(* 步进或稳定：要么该步在域内某能力上严格升，要么整步逐点稳定 *)
Lemma step_or_stable : forall O D, (forall m c, ~ In c D -> kop O m c = M0) ->
  forall j, mstable O D j = true \/
            (exists c, In c D /\ mlt (iter O j c) (iter O (S j) c)).
Proof.
  intros O D Hout j. destruct (mstable O D j) eqn:E.
  - left; reflexivity.
  - right. unfold mstable in E.
    destruct (forallb_false_ex _ _ _ E) as [c [Hc Hf]].
    pose proof (meqb_false _ _ Hf) as Hne.
    pose proof (chain_mono_step O j c) as Hle.
    assert (Hrank : mrank (iter O j c) < mrank (iter O (S j) c)).
    { destruct (Nat.eq_dec (mrank (iter O j c)) (mrank (iter O (S j) c))) as [Heq | Hrq].
      - pose proof (mrank_inj (iter O j c) (iter O (S j) c) Heq) as Hab. contradiction.
      - unfold mle in Hle. lia. }
    exists c; split; [exact Hc | unfold mlt; exact Hrank].
Qed.

(* 有界搜索：K 步内要么找到稳定步，要么前 K 步全部严格 *)
Lemma search_stab : forall O D, (forall m c, ~ In c D -> kop O m c = M0) ->
  forall K, (exists N, N <= K /\ mstable O D N = true) \/
            (forall j, j < K -> exists c, In c D /\ mlt (iter O j c) (iter O (S j) c)).
Proof.
  intros O D Hout K. induction K as [|K IH].
  - destruct (mstable O D 0) eqn:E.
    + left. exists 0. split; [lia | exact E].
    + right. intros j Hj. exfalso; lia.
  - destruct IH as [[N [HN Hst]] | Hall].
    + left. exists N. split; [lia | exact Hst].
    + destruct (mstable O D (S K)) eqn:E.
      * left. exists (S K). split; [lia | exact E].
      * right. intros j Hj. destruct (Nat.eq_dec j K) as [-> | HneK].
        -- (* j = K：若 mstable K = true，则链自 K 起常值，与 mstable (S K) = false 矛盾 *)
           destruct (step_or_stable O D Hout K) as [HstK | HexK].
           ++ exfalso.
              assert (Hfull : forall c, iter O K c = iter O (S K) c).
              { intros c. destruct (In_dec cap_eq_dec c D) as [Hc|Hc].
                - apply (mstable_true O D K HstK c Hc).
                - rewrite (iter_out O D Hout K c Hc),
                           (iter_out O D Hout (S K) c Hc). reflexivity. }
              assert (Hs1 : forall c, iter O (S K) c = iter O K c)
                by exact (once_stable O K Hfull (S K) (Nat.le_succ_diag_r K)).
              assert (Hs2 : forall c, iter O (S (S K)) c = iter O K c)
                by exact (once_stable O K Hfull (S (S K)) ltac:(lia)).
              unfold mstable in E.
              destruct (forallb_false_ex _ _ _ E) as [c [Hc Hf]].
              pose proof (meqb_false _ _ Hf) as Hne.
              rewrite (Hs1 c), (Hs2 c) in Hne. exact (Hne eq_refl).
           ++ exact HexK.
        -- apply Hall. lia.
Qed.

(* 势函数下界：前 K 步全严格 ⇒ potD(κ K) ≥ K *)
Lemma pot_ge : forall O D, (forall m c, ~ In c D -> kop O m c = M0) ->
  forall K, (forall j, j < K -> exists c, In c D /\ mlt (iter O j c) (iter O (S j) c)) ->
  K <= potD D (iter O K).
Proof.
  intros O D Hout K. induction K as [|K IH]; intros Hall.
  - lia.
  - assert (Hall' : forall j, j < K -> exists c, In c D /\ mlt (iter O j c) (iter O (S j) c))
      by (intros j Hj; apply Hall; lia).
    specialize (IH Hall').
    destruct (Hall K (Nat.lt_succ_diag_r K)) as [c [Hc Hst]].
    pose proof (chain_mono_step O K) as Hmono.
    pose proof (potD_strict D (iter O K) (iter O (S K)) Hmono
                  (ex_intro _ c (conj Hc Hst))) as Hs.
    lia.
Qed.

(* 稳定存在性：稳定步必在 2·|D|+1 内出现 *)
Theorem stab_exists : forall O D, (forall m c, ~ In c D -> kop O m c = M0) ->
  exists N, N <= 2 * length D + 1 /\ mstable O D N = true.
Proof.
  intros O D Hout.
  destruct (search_stab O D Hout (2 * length D + 1)) as [[N [HN Hst]] | Hall].
  - exists N; split; assumption.
  - exfalso.
    pose proof (pot_ge O D Hout (2 * length D + 1) Hall) as H1.
    pose proof (potD_bound D (iter O (2 * length D + 1))) as H2. lia.
Qed.

Theorem kleene_stabilizes : forall O D, (forall m c, ~ In c D -> kop O m c = M0) ->
  exists N, N <= 2 * length D + 1 /\ (forall c, iter O N c = iter O (S N) c).
Proof.
  intros O D Hout. destruct (stab_exists O D Hout) as [N [HN Hst]].
  exists N; split; [exact HN |].
  intros c. destruct (In_dec cap_eq_dec c D) as [Hc | Hc].
  - apply (mstable_true O D N Hst c Hc).
  - rewrite (iter_out O D Hout N c Hc), (iter_out O D Hout (S N) c Hc). reflexivity.
Qed.

(* 链受制于任意后不动点：κ k ≤ σ 只要 F σ ≤ σ *)
Lemma chain_le_pre : forall O m, cle (kop O m) m -> forall k c, mle (iter O k c) (m c).
Proof.
  intros O m Hm k. induction k as [|k IH]; intros c.
  - unfold mle. simpl. lia.
  - rewrite iter_S. apply mle_trans with (kop O m c).
    + apply (kop_mono O (iter O k) m IH c).
    + apply (Hm c).
Qed.

(* ================= 主定理：kleene_lfp ================= *)
Theorem kleene_lfp : forall O D, (forall m c, ~ In c D -> kop O m c = M0) ->
  exists l, (forall c, l c = kop O l c)                (* l 是不动点 *)
         /\ (forall m, cle (kop O m) m -> cle l m)     (* l ≤ 任意后不动点（最小性） *)
         /\ (exists N, N <= 2 * length D + 1           (* l 是 Kleene 链极限 *)
                    /\ forall c, l c = iter O N c).
Proof.
  intros O D Hout. destruct (kleene_stabilizes O D Hout) as [N [HN Hstab]].
  exists (iter O N). repeat split.
  - intros c. rewrite <- (iter_S O N c). apply Hstab.
  - intros m Hm c. apply (chain_le_pre O m Hm N c).
  - exists N. split; [exact HN | intros c; reflexivity].
Qed.

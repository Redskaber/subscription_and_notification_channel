(* ===================================================================== *)
(*  效应能力流形 · 第 49 轮 · M35Example：W-TYPEX-3 区域变量化的实机        *)
(*                                                                         *)
(*  六组实机（编译即验证——eq_refl / Print Assumptions）：                   *)
(*    1. 命名空间读数表：poolA/poolB/poolV/poolG 的 rvars/grounds            *)
(*       ——m34 的 sigB 池（标签 9）在 m35 读数下自动成为变量化池（retcon） *)
(*    2. m34 重读：安排 ρ₉↦0 把 poolB 变成 poolA（rinstP 定义性归约）；      *)
(*       流一（单候选即中——最薄流形态）                                     *)
(*    3. N3 正面实验（poolV）：引擎单遍 None（τ 冲突 9≠0——tau_rigid 面）     *)
(*       ∧ 安排循环两支（一死一活）⇒ Some——DPLL(T) case-split 回归完整实机  *)
(*    4. N3 负面对照（poolG）：poolV 的刚性孪生（7 < RV_BASE）——            *)
(*       荷在 ⇒ 流零（恒等一支）∧ 诚实 None（不可安排修复）                  *)
(*    5. 三态梯度与双池同框：poolA 流零 / poolB 流一 / poolV 流二；          *)
(*       poolG（荷在·None）vs poolV（荷破·Some）——诺特 N3 的完整对偶        *)
(*    6. Print Assumptions 全链路零公理审计                                  *)
(* ===================================================================== *)

Require Import List Lia PeanoNat Bool.
Import ListNotations.
Require Import Mult Cap Syntax CG Tau TyCG Lphi Fusion Mu Xsub M3Fusion
               Rsat Hsat Solve3 Xcone Drop2 Gphi Solve4
               SigLam Noether M34Example Rvar.

Local Open Scope bool_scope.

(* ================= 0. 实验池 ================= *)

(* poolV：N3 正面实验池——同一入口变量 α₀ 被两条签名方程约束：
   α₀ ≡ &ρ₉ α₂（9 ≥ RV_BASE=8——区域变量）∧ α₀ ≡ &₀ α₂（地面 0）。
   地面读数：9 ≠ 0 ⇒ τ 合一冲突 ⇒ 引擎 None（单遍许可证到期）。
   安排层：候选 grounds = [1; 0]（出现序——死支 1 在前），须分支搜索。 *)
Definition poolV : list constr :=
  [ CTy (TVar 0) (TBorrow 9 (TVar 2));
    CXr 1 (TVar 6);
    CTy (TVar 0) (TBorrow 0 (TVar 2));
    CXr 0 (TArrow (TVar 0) (TVar 1)) ].

(* poolG：poolV 的刚性孪生——唯一差别 9 ↦ 7（7 < RV_BASE——地面）。
   荷在（rvars = []）⇒ 流零；7 ≠ 0 地面冲突 ⇒ 诚实 None。 *)
Definition poolG : list constr :=
  [ CTy (TVar 0) (TBorrow 7 (TVar 2));
    CXr 1 (TVar 6);
    CTy (TVar 0) (TBorrow 0 (TVar 2));
    CXr 0 (TArrow (TVar 0) (TVar 1)) ].

(* ================= 1. 命名空间读数表 ================= *)

(* m34 的四个池在 m35 读数下的归属：标签 ≥ 8 即区域变量 *)
Example m35_rvars_poolA : rvars poolA = []. Proof. reflexivity. Qed.
Example m35_grounds_poolA : grounds poolA = [0]. Proof. reflexivity. Qed.

Example m35_rvars_poolB : rvars poolB = [9]. Proof. reflexivity. Qed.
Example m35_grounds_poolB : grounds poolB = [0]. Proof. reflexivity. Qed.

Example m35_rvars_poolV : rvars poolV = [9]. Proof. reflexivity. Qed.
Example m35_grounds_poolV : grounds poolV = [1; 0]. Proof. reflexivity. Qed.

Example m35_rvars_poolG : rvars poolG = []. Proof. reflexivity. Qed.
Example m35_grounds_poolG : grounds poolG = [7; 1; 0]. Proof. reflexivity. Qed.

(* poolB 的 retcon 定性：m34 把标签 9 当地面区域用（sigB = &9 α₂）；
   m35 读数下 9 ≥ RV_BASE——sigB 从来就是变量化签名。
   四池按荷分账：poolA/poolG 荷在；poolB/poolV 荷破。 *)
Theorem m35_charge_ledger :
  (rvars poolA = [] /\ rvars poolG = [])
  /\ (rvars poolB = [9] /\ rvars poolV = [9]).
Proof. split; [split; reflexivity | split; reflexivity]. Qed.

(* ================= 2. m34 重读：retcon 组 ================= *)

(* 2a. 安排 ρ₉↦0 把 poolB 定义性地变成 poolA：
     m34 的上升解（[(0,&₉α₂);(1,α₃→&₉α₂);(2,&₀α₂)]——E.56/E.61 两轮）
     与 m35 的安排解（[(0,&₀α₂);(1,α₃→&₀α₂)]）是同一池的两个见证——
     上升是恒等安排内的隧道；安排直接改写标签。 *)
Example m35_rearrange_retcon : rinstP [(9, 0)] poolB = poolA.
Proof. reflexivity. Qed.

(* 2b. 安排计划：poolB 单候选（grounds = [0]）——流的最薄形态 *)
Example m35_plan_poolB : arrange_plan poolB = [[(9, 0)]].
Proof. reflexivity. Qed.

(* 2c. 流一：单候选即中，无死支 *)
Example m35_trials_poolB : arrange_trials 50 poolB = 1. Proof. reflexivity. Qed.

Example m35_solve6_poolB :
  solve6 50 poolB
  = Some ([(0, TBorrow 0 (TVar 2)); (1, TArrow (TVar 3) (TBorrow 0 (TVar 2)))],
          lphi (chanProj ChPhi poolA), [(9, 0)]).
Proof. reflexivity. Qed.

(* 2d. 荷在池的恒等流（poolA：m34 快道池在 m35 下流零） *)
Example m35_solve6_poolA :
  solve6 50 poolA
  = Some ([(0, TBorrow 0 (TVar 2)); (1, TArrow (TVar 3) (TBorrow 0 (TVar 2)))],
          lphi (chanProj ChPhi poolA), []).
Proof. reflexivity. Qed.

Theorem m35_poolA_flow_zero :
  rvars poolA = [] /\ arrange_trials 50 poolA = 1
  /\ (exists s l, solve6 50 poolA = Some (s, l, [])).
Proof.
  split; [reflexivity|]. split; [reflexivity|].
  exists [(0, TBorrow 0 (TVar 2)); (1, TArrow (TVar 3) (TBorrow 0 (TVar 2)))],
         (lphi (chanProj ChPhi poolA)).
  exact m35_solve6_poolA.
Qed.

(* ================= 3. N3 正面实验（poolV） ================= *)

(* 3a. 引擎面：单遍许可证到期——τ 冲突（9 ≠ 0 地面读数）。
     这正是 tau_rigid 的刚性面：引擎无法为标签 9 与 0 安排相等。 *)
Example m35_engine_none : solve4 50 poolV = None. Proof. reflexivity. Qed.

Example m35_engine_tau_conflict :
  unify 50 (tyEqs (chanProj ChTy poolV)) = None.
Proof. reflexivity. Qed.

(* 3b. tau_rigid 的直接实例：标签 1 与 0 的合一结构性不可能——
     分支一的死因（1 = 0 是地面冲突，非可安排等式） *)
Theorem m35_rigid_conflict : forall f s,
  ~ (unify f ((TBorrow 1 (TVar 2), TBorrow 0 (TVar 2)) :: []) = Some s).
Proof.
  intros f s H. pose proof (tau_rigid f [] s 1 0 (TVar 2) (TVar 2) H). lia.
Qed.

(* 3c. 安排两支：候选序 [1; 0]——死支在前，活支在后 *)
Example m35_plan_poolV : arrange_plan poolV = [[(9, 1)]; [(9, 0)]].
Proof. reflexivity. Qed.

(* 3d. 分支一（ρ₉ ↦ 1）：死——实例化后 1 ≠ 0 仍冲突 *)
Example m35_branch1_dead : solve4 50 (rinstP [(9, 1)] poolV) = None.
Proof. reflexivity. Qed.

(* 3e. 分支二（ρ₉ ↦ 0）：活——主解 [(0, &₀α₂)]，X 的 CXr 1 (TVar 6)
     经上升点 (6 ↦ &₁α₆) 补足；CXr 0 (TArrow α₀α₁) 在主解层即满足 *)
Example m35_branch2_hits :
  solve4 50 (rinstP [(9, 0)] poolV)
  = Some ([(0, TBorrow 0 (TVar 2)); (6, TBorrow 1 (TVar 6))],
          lphi (chanProj ChPhi (rinstP [(9, 0)] poolV))).
Proof. reflexivity. Qed.

(* 3f. 流二：两支评估（一死一活）——case-split 回归的完整实机 *)
Example m35_trials_poolV : arrange_trials 50 poolV = 2. Proof. reflexivity. Qed.

Example m35_solve6_poolV :
  solve6 50 poolV
  = Some ([(0, TBorrow 0 (TVar 2)); (6, TBorrow 1 (TVar 6))],
          lphi (chanProj ChPhi (rinstP [(9, 0)] poolV)), [(9, 0)]).
Proof. reflexivity. Qed.

(* 3g. N3 正面合取：荷破 ⇒ 引擎/安排分歧——流出现且分支。
     solve4（单遍许可证）对变量化语义不完备；安排循环接管。 *)
Theorem m35_n3_positive :
  (solve4 50 poolV = None)
  /\ (arrange_trials 50 poolV = 2)
  /\ (exists s l, solve6 50 poolV = Some (s, l, [(9, 0)]))
  /\ (exists rho, In rho (arrange_plan poolV)
                 /\ solve4 50 (rinstP rho poolV) <> None).
Proof.
  split; [reflexivity|]. split; [reflexivity|]. split.
  - exists [(0, TBorrow 0 (TVar 2)); (6, TBorrow 1 (TVar 6))].
    exists (lphi (chanProj ChPhi (rinstP [(9, 0)] poolV))).
    exact m35_solve6_poolV.
  - exists [(9, 0)]. split.
    + simpl. right. left. reflexivity.
    + intro Hnone. rewrite m35_branch2_hits in Hnone. discriminate.
Qed.

(* 3h. 见证可靠性实机（solve6_witness 的实例化）：
     安排层返回的解必经引擎验证 *)
Theorem m35_witness_verified :
  solve6 50 poolV = Some ([(0, TBorrow 0 (TVar 2)); (6, TBorrow 1 (TVar 6))],
                          lphi (chanProj ChPhi (rinstP [(9, 0)] poolV)), [(9, 0)])
  /\ In [(9, 0)] (arrange_plan poolV)
  /\ solve4 50 (rinstP [(9, 0)] poolV)
     = Some ([(0, TBorrow 0 (TVar 2)); (6, TBorrow 1 (TVar 6))],
             lphi (chanProj ChPhi (rinstP [(9, 0)] poolV))).
Proof.
  split; [exact m35_solve6_poolV|].
  apply (solve6_witness 50 poolV
           [(0, TBorrow 0 (TVar 2)); (6, TBorrow 1 (TVar 6))]
           (lphi (chanProj ChPhi (rinstP [(9, 0)] poolV))) [(9, 0)]
           m35_solve6_poolV).
Qed.

(* ================= 4. N3 负面对照（poolG） ================= *)

(* 4a. 刚性孪生：荷在 ⇒ 流零（恒等一支）∧ 诚实 None。
     无可安排（rvars = []），且 7 ≠ 0 地面冲突不可修复——
     None 是正确答案（与 poolV 的 None 是引擎盲区形成对照）。 *)
Example m35_engine_G : solve4 50 poolG = None. Proof. reflexivity. Qed.
Example m35_solve6_G : solve6 50 poolG = None. Proof. reflexivity. Qed.
Example m35_trials_G : arrange_trials 50 poolG = 1. Proof. reflexivity. Qed.

Theorem m35_n3_negative :
  (rvars poolG = [])
  /\ (arrange_trials 50 poolG = 1)
  /\ (solve4 50 poolG = None /\ solve6 50 poolG = None).
Proof.
  split; [reflexivity|]. split; [reflexivity|].
  split; reflexivity.
Qed.

(* 4b. 流零定理的实机（noether_N3_flow_zero 的实例化）：
     poolG 上 trials = 1 ∧ solve6 = solve4 的零包装 *)
Theorem m35_flow_zero_G :
  arrange_trials 50 poolG = 1
  /\ solve6 50 poolG = match solve4 50 poolG with
                      | Some (s, l) => Some (s, l, [])
                      | None => None
                      end.
Proof. apply (noether_N3_flow_zero 50 poolG). reflexivity. Qed.

(* ================= 5. 三态梯度与双池同框 ================= *)

(* 5a. 三态梯度：荷在流零（poolA 恒等）→ 流一（poolB 单候选）→
     流二（poolV 分支）——诺特流随荷破缺单调现身 *)
Theorem m35_tier_gradient :
  (rvars poolA = [] /\ arrange_trials 50 poolA = 1)
  /\ (rvars poolB = [9] /\ arrange_trials 50 poolB = 1)
  /\ (rvars poolV = [9] /\ arrange_trials 50 poolV = 2).
Proof.
  split; [split; reflexivity|].
  split; [split; reflexivity|].
  split; reflexivity.
Qed.

(* 5b. 双池同框：诺特 N3 正面实验的完整对偶——
     poolG（荷在：流零 + 诚实 None）vs poolV（荷破：流二 + 分支 Some）。
     荷（标签刚性）在 ⇒ 流零且判定可靠；荷破 ⇒ 流出现且引擎单遍到期。 *)
Theorem m35_flow_duality_VG :
  (rvars poolG = [] /\ arrange_trials 50 poolG = 1
     /\ solve4 50 poolG = None /\ solve6 50 poolG = None)
  /\ (rvars poolV = [9] /\ arrange_trials 50 poolV = 2
     /\ solve4 50 poolV = None
     /\ solve6 50 poolV
        = Some ([(0, TBorrow 0 (TVar 2)); (6, TBorrow 1 (TVar 6))],
                lphi (chanProj ChPhi (rinstP [(9, 0)] poolV)), [(9, 0)])).
Proof.
  split.
  - exact m35_n3_negative.
  - split; [reflexivity|]. split; [reflexivity|].
    split; [reflexivity | exact m35_solve6_poolV].
Qed.

(* 5c. 恒等桥实机（solve6_identity_bridge 的反面对照）：
     poolA 的解经恒等安排命中 ⇒ 引擎单遍已足（m34 快道的 m35 读数） *)
Theorem m35_identity_bridge_A :
  solve6 50 poolA = Some ([(0, TBorrow 0 (TVar 2)); (1, TArrow (TVar 3) (TBorrow 0 (TVar 2)))],
                          lphi (chanProj ChPhi poolA), [])
  -> solve4 50 poolA = Some ([(0, TBorrow 0 (TVar 2)); (1, TArrow (TVar 3) (TBorrow 0 (TVar 2)))],
                             lphi (chanProj ChPhi poolA)).
Proof.
  intros H. apply (solve6_identity_bridge 50 poolA
    [(0, TBorrow 0 (TVar 2)); (1, TArrow (TVar 3) (TBorrow 0 (TVar 2)))]
    (lphi (chanProj ChPhi poolA)) H).
Qed.

(* ================= 6. 零公理审计 ================= *)

Print Assumptions rlook_nil.
Print Assumptions rinst1_nil.
Print Assumptions rinstC_nil.
Print Assumptions rinstP_nil.
Print Assumptions dedupN_In.
Print Assumptions rvars_nil_ground.
Print Assumptions rlook_ground_key.
Print Assumptions rinst1_ground.
Print Assumptions rinstC_ground.
Print Assumptions rinstP_allground.
Print Assumptions rinstP_ground_fix.
Print Assumptions assigns_nil_rvs.
Print Assumptions assigns_single.
Print Assumptions assigns_length.
Print Assumptions assigns_domain.
Print Assumptions arr_loop_some_spec.
Print Assumptions solve6_witness.
Print Assumptions arr_loop_exhaust_spec.
Print Assumptions solve6_exhaust.
Print Assumptions arr_loop_identity.
Print Assumptions noether_N3_flow_zero.
Print Assumptions noether_N3_flow_nonidentity.
Print Assumptions solve6_identity_bridge.
Print Assumptions noether_N3_flow_duality.
Print Assumptions m35_charge_ledger.
Print Assumptions m35_rearrange_retcon.
Print Assumptions m35_trials_poolB.
Print Assumptions m35_solve6_poolB.
Print Assumptions m35_poolA_flow_zero.
Print Assumptions m35_engine_none.
Print Assumptions m35_rigid_conflict.
Print Assumptions m35_branch1_dead.
Print Assumptions m35_branch2_hits.
Print Assumptions m35_trials_poolV.
Print Assumptions m35_n3_positive.
Print Assumptions m35_witness_verified.
Print Assumptions m35_n3_negative.
Print Assumptions m35_flow_zero_G.
Print Assumptions m35_tier_gradient.
Print Assumptions m35_flow_duality_VG.
Print Assumptions m35_identity_bridge_A.

(* ===================================================================== *)
(*  效应能力流形 · 第 50 轮 · M36Example：嵌套签名栈的实机（诺特栈律）      *)
(*                                                                         *)
(*  六组实机（编译即验证——eq_refl / Print Assumptions）：                   *)
(*    1. 栈读数表：五池（sk0 无栈 / skA 无荷栈 / skF 流一 / skS 流二 /       *)
(*       skT 刚性孪生）的 rvars/grounds/plan 读数 + 荷源等式                *)
(*       （allabels skS = siglabels 栈——池标签即栈标签）                    *)
(*    2. 退化与血统：栈尽恒等（cgK [] = cgT）；单栈位 = 绑定锚定 cgS         *)
(*       （对照 cgS 的入口锚定——W-LAM-1 血统的锚点迁移）                    *)
(*    3. 供给与词表：κ 的供给窗（p' = 7）；供给—词表二分（cgK_range_ext      *)
(*       实例）；φ 盲性实机（chanProj ChPhi skS = []）                      *)
(*    4. 流梯度：流零（无栈）→ 流零（深二无荷栈——栈深不生流）→ 流一         *)
(*       （共享荷不相碰）→ 流二（skS：一死一活——栈相遇的 DPLL(T) 回归）      *)
(*       → 诚实 None（skT 刚性孪生）                                        *)
(*    5. 诺特栈律实机：流形维数（|plan| = |grounds|^|rvars|）；共享荷同调     *)
(*       （单变量线性流形）；流栈局部（键值不出签名标签）；无荷栈流零实例     *)
(*    6. Print Assumptions 全链路零公理审计                                  *)
(*                                                                         *)
(*  展示项：κ = λx.λy. y x（C 组合子）——迫使两层绑定相遇：                   *)
(*    y 的定义域 ≡ x 的类型。栈 [x: &₁α₁₀→&₉α₁₁; y: (&₁α₁₀→&₀α₁₁)→α₁₂]     *)
(*    相遇迫使 &₀α₁₁ ≡ &₉α₁₁（τ 冲突 0≠9）——荷破 ⇒ 引擎单遍到期 ∧           *)
(*    安排流出现（一死一活）。荷不出栈（项的 λ 结构零标签）。                 *)
(* ===================================================================== *)

Require Import List Lia PeanoNat Bool.
Import ListNotations.
Require Import Mult Cap Syntax CG Tau TyCG Lphi Fusion Mu Xsub M3Fusion
               Rsat Hsat Solve3 Xcone Drop2 Gphi Solve4
               SigLam Noether M34Example Rvar M35Example SigStack.

Local Open Scope bool_scope.

(* ================= 0. 展示项与五个栈 ================= *)

(* κ = λx.λy. y x —— C 组合子：y 应用于 x 迫使 y 的定义域 ≡ x 的类型 *)
Definition kappa : tm := Lam 0 (Lam 1 (Call (Var 0) (Var 1))).

(* 无荷栈（纯箭头签名——深二、零标签） *)
Definition sA0 : ty := TArrow (TVar 10) (TVar 11).
Definition sA1 : ty := TArrow (TArrow (TVar 10) (TVar 11)) (TVar 12).

(* 流一栈：x : α₁₀ → &₉α₁₁（余域荷 ρ₉），y : (&₀α₁₁ → α₁₂) → α₁₃
   （定义域地面 0）——相遇绑定到不同变量，不相碰 *)
Definition sF0 : ty := TArrow (TVar 10) (TBorrow 9 (TVar 11)).
Definition sF1 : ty := TArrow (TArrow (TBorrow 0 (TVar 11)) (TVar 12)) (TVar 13).

(* 流二栈：x : &₁α₁₀ → &₉α₁₁（地面 1 + 荷 ρ₉），y : (&₁α₁₀ → &₀α₁₁) → α₁₂
   —— 相遇迫使余域 &₀α₁₁ ≡ &₉α₁₁（τ 冲突）；标签序 [1;9;1;0] ⇒ 候选 [1;0] *)
Definition sS0 : ty := TArrow (TBorrow 1 (TVar 10)) (TBorrow 9 (TVar 11)).
Definition sS1 : ty :=
  TArrow (TArrow (TBorrow 1 (TVar 10)) (TBorrow 0 (TVar 11))) (TVar 12).

(* 刚性孪生栈：sS0 的 9 ↦ 7（7 < RV_BASE——地面）——荷在 ⇒ 诚实 None *)
Definition sT0 : ty := TArrow (TBorrow 1 (TVar 10)) (TBorrow 7 (TVar 11)).

(* 五池 *)
Definition sk0 : list constr := fst (cgK [] 0 [] kappa).
Definition skA : list constr := fst (cgK [sA0; sA1] 0 [] kappa).
Definition skF : list constr := fst (cgK [sF0; sF1] 0 [] kappa).
Definition skS : list constr := fst (cgK [sS0; sS1] 0 [] kappa).
Definition skT : list constr := fst (cgK [sT0; sS1] 0 [] kappa).

(* 解（上机值——探针实录） *)
Definition sol0 : tsubst :=
  [(0, TArrow (TVar 1) (TVar 2)); (2, TArrow (TVar 3) (TVar 4));
   (5, TArrow (TVar 6) (TVar 4)); (3, TArrow (TVar 6) (TVar 4)); (6, TVar 1)].

Definition solA : tsubst :=
  [(1, TArrow (TVar 10) (TVar 11));
   (0, TArrow (TArrow (TVar 10) (TVar 11)) (TVar 2));
   (3, TArrow (TArrow (TVar 10) (TVar 11)) (TVar 12));
   (2, TArrow (TArrow (TArrow (TVar 10) (TVar 11)) (TVar 12)) (TVar 4));
   (5, TArrow (TVar 6) (TVar 4)); (6, TArrow (TVar 10) (TVar 11)); (4, TVar 12)].

Definition solF : tsubst :=
  [(1, TArrow (TVar 10) (TBorrow 9 (TVar 11)));
   (0, TArrow (TArrow (TVar 10) (TBorrow 9 (TVar 11))) (TVar 2));
   (3, TArrow (TArrow (TBorrow 0 (TVar 11)) (TVar 12)) (TVar 13));
   (2, TArrow (TArrow (TArrow (TBorrow 0 (TVar 11)) (TVar 12)) (TVar 13))
           (TVar 4));
   (5, TArrow (TVar 6) (TVar 4)); (6, TArrow (TBorrow 0 (TVar 11)) (TVar 12));
   (4, TVar 13); (10, TBorrow 0 (TVar 11)); (12, TBorrow 9 (TVar 11))].

Definition solF6 : tsubst :=
  [(1, TArrow (TVar 10) (TBorrow 0 (TVar 11)));
   (0, TArrow (TArrow (TVar 10) (TBorrow 0 (TVar 11))) (TVar 2));
   (3, TArrow (TArrow (TBorrow 0 (TVar 11)) (TVar 12)) (TVar 13));
   (2, TArrow (TArrow (TArrow (TBorrow 0 (TVar 11)) (TVar 12)) (TVar 13))
           (TVar 4));
   (5, TArrow (TVar 6) (TVar 4)); (6, TArrow (TBorrow 0 (TVar 11)) (TVar 12));
   (4, TVar 13); (10, TBorrow 0 (TVar 11)); (12, TBorrow 0 (TVar 11))].

Definition solS : tsubst :=
  [(1, TArrow (TBorrow 1 (TVar 10)) (TBorrow 0 (TVar 11)));
   (0, TArrow (TArrow (TBorrow 1 (TVar 10)) (TBorrow 0 (TVar 11))) (TVar 2));
   (3, TArrow (TArrow (TBorrow 1 (TVar 10)) (TBorrow 0 (TVar 11))) (TVar 12));
   (2, TArrow (TArrow (TArrow (TBorrow 1 (TVar 10)) (TBorrow 0 (TVar 11)))
               (TVar 12)) (TVar 4));
   (5, TArrow (TVar 6) (TVar 4));
   (6, TArrow (TBorrow 1 (TVar 10)) (TBorrow 0 (TVar 11))); (4, TVar 12)].

(* ================= 1. 栈读数表 ================= *)

Example m36_rvars_sk0 : rvars sk0 = []. Proof. reflexivity. Qed.
Example m36_grounds_sk0 : grounds sk0 = []. Proof. reflexivity. Qed.
Example m36_rvars_skA : rvars skA = []. Proof. reflexivity. Qed.
Example m36_grounds_skA : grounds skA = []. Proof. reflexivity. Qed.
Example m36_rvars_skF : rvars skF = [9]. Proof. reflexivity. Qed.
Example m36_grounds_skF : grounds skF = [0]. Proof. reflexivity. Qed.
Example m36_rvars_skS : rvars skS = [9]. Proof. reflexivity. Qed.
Example m36_grounds_skS : grounds skS = [1; 0]. Proof. reflexivity. Qed.
Example m36_rvars_skT : rvars skT = []. Proof. reflexivity. Qed.
Example m36_grounds_skT : grounds skT = [7; 1; 0]. Proof. reflexivity. Qed.

Example m36_plan_skF : arrange_plan skF = [[(9, 0)]]. Proof. reflexivity. Qed.
Example m36_plan_skS : arrange_plan skS = [[(9, 1)]; [(9, 0)]].
Proof. reflexivity. Qed.

(* 签名词表（类型变量）与标签表（区域标签）——供给窗 [0,7) 之外 *)
Example m36_sigvars_skS : sigvars [sS0; sS1] = [10; 11; 10; 11; 12].
Proof. reflexivity. Qed.
Example m36_siglabels_skS : siglabels [sS0; sS1] = [1; 9; 1; 0].
Proof. reflexivity. Qed.

(* 荷源等式：池标签 = 栈标签（多重集相等——cgK_labels 的 ⊆ 在此池为 =） *)
Example m36_charge_source : allabels skS = siglabels [sS0; sS1].
Proof. reflexivity. Qed.

(* 五池按荷分账：sk0/skA/skT 荷在；skF/skS 荷破（共享单荷 ρ₉） *)
Theorem m36_charge_ledger :
  (rvars sk0 = [] /\ rvars skA = [] /\ rvars skT = [])
  /\ (rvars skF = [9] /\ rvars skS = [9]).
Proof.
  split; [split; [reflexivity | split; reflexivity] |].
  split; reflexivity.
Qed.

(* ================= 2. 退化与血统 ================= *)

(* 2a. 栈尽恒等：空栈 = 零注记基线（cgK_nil 的实例——可计算事实） *)
Theorem m36_nil_identity : cgK [] 0 [] kappa = cgT 0 [] kappa.
Proof. apply cgK_nil. Qed.

(* 2b. 单栈位 = 绑定锚定的 cgS（W-LAM-1 血统——锚点从入口 α₀ 迁到绑定 α₁） *)
Theorem m36_single_bridge :
  cgK [sS0] 0 [] kappa
  = (CTy (TVar 1) sS0 :: fst (cgT 0 [] kappa), snd (cgT 0 [] kappa)).
Proof. exact (cgK_single sS0 0 (Lam 1 (Call (Var 0) (Var 1))) 0 []). Qed.

(* 2c. 单栈位读数（绑定锚定：sig 方程在 α₁ = 绑定变量） *)
Example m36_single_reading :
  cgK [sS0] 0 [] kappa
  = ([CTy (TVar 1) sS0;
      CTy (TVar 0) (TArrow (TVar 1) (TVar 2));
      CTy (TVar 2) (TArrow (TVar 3) (TVar 4));
      CTy (TVar 5) (TArrow (TVar 6) (TVar 4));
      CTy (TVar 5) (TVar 3);
      CTy (TVar 6) (TVar 1)], 7).
Proof. reflexivity. Qed.

(* 2d. 对照：cgS（E.61）的入口锚定——sig 方程在 α₀ = 入口变量 *)
Example m36_cgS_contrast :
  cgS sS0 0 [] kappa
  = [CTy (TVar 0) sS0;
     CTy (TVar 0) (TArrow (TVar 1) (TVar 2));
     CTy (TVar 2) (TArrow (TVar 3) (TVar 4));
     CTy (TVar 5) (TArrow (TVar 6) (TVar 4));
     CTy (TVar 5) (TVar 3);
     CTy (TVar 6) (TVar 1)].
Proof. reflexivity. Qed.

(* 2e. κ 的供给对（五池同窗：变量供给 0..6，p' = 7） *)
Example m36_kappa_pair : cgK [sS0; sS1] 0 [] kappa = (skS, 7).
Proof. reflexivity. Qed.

(* ================= 3. 供给与词表 ================= *)

(* 3a. 供给—词表二分（cgK_range_ext 实例）：
      skS 的每个类型变量要么在供给窗 [0,7)，要么在签名词表 {10,11,12} *)
Theorem m36_supply_vocab_split :
  forall v, In v (flat_map ctyVars skS) ->
  (v < 7 /\ (0 <= v \/ In v ([] : list nat))) \/ In v (sigvars [sS0; sS1]).
Proof.
  apply (cgK_range_ext kappa [sS0; sS1] 0 []).
  - intros w Hw. destruct Hw.
  - exact m36_kappa_pair.
Qed.

(* 3b. φ 盲性实机：栈世界全在 τ 通道（N2 规范对称面保持） *)
Example m36_phi_nil_skS : chanProj ChPhi skS = [].
Proof. reflexivity. Qed.

Theorem m36_phi_nil_theorem :
  chanProj ChPhi (fst (cgK [sS0; sS1] 0 [] kappa)) = [].
Proof. apply cgK_phi_nil. Qed.

(* ================= 4. 流梯度（五池） ================= *)

(* 4a. 流零 · 无栈：引擎 Some（纯 MM 合一——箭头链）∧ 恒等一支 *)
Example m36_solve4_sk0 :
  solve4 50 sk0 = Some (sol0, fun _ : capidx => M0).
Proof. reflexivity. Qed.

Example m36_solve6_sk0 :
  solve6 50 sk0 = Some (sol0, fun _ : capidx => M0, []).
Proof. reflexivity. Qed.

Example m36_trials_sk0 : arrange_trials 50 sk0 = 1. Proof. reflexivity. Qed.

(* 4b. 流零 · 深二无荷栈（栈深不生流）：skA 与 sk0 同流形——
      恒等一支 + 零包装；两条签名方程不产生任何安排分支 *)
Example m36_solve4_skA :
  solve4 50 skA = Some (solA, fun _ : capidx => M0).
Proof. reflexivity. Qed.

Example m36_solve6_skA :
  solve6 50 skA = Some (solA, fun _ : capidx => M0, []).
Proof. reflexivity. Qed.

Example m36_trials_skA : arrange_trials 50 skA = 1. Proof. reflexivity. Qed.

(* 4c. 流一 · 共享荷不相碰：引擎 Some（相遇绑定到不同变量——
      α₁₀ := &₀α₁₁ ∧ α₁₂ := &₉α₁₁，无标签冲突）∧ 单候选即中 *)
Example m36_solve4_skF :
  solve4 50 skF = Some (solF, fun _ : capidx => M0).
Proof. reflexivity. Qed.

Example m36_solve6_skF :
  solve6 50 skF = Some (solF6, fun _ : capidx => M0, [(9, 0)]).
Proof. reflexivity. Qed.

Example m36_trials_skF : arrange_trials 50 skF = 1. Proof. reflexivity. Qed.

(* 4d. 流二 · 共享荷相碰（skS——栈相遇的 DPLL(T) 回归）：
      引擎单遍到期（τ 冲突 0≠9）∧ 安排两支一死一活 *)
Example m36_engine_none : solve4 50 skS = None. Proof. reflexivity. Qed.

Example m36_engine_tau_conflict :
  unify 50 (tyEqs (chanProj ChTy skS)) = None.
Proof. reflexivity. Qed.

(* tau_rigid 的直接实例：标签 0 与 1 的合一结构性不可能
   ——死支（9↦1）的死因：&₀α₁₁ ≡ &₁α₁₁ 地面冲突 *)
Theorem m36_rigid_conflict : forall f s,
  ~ (unify f ((TBorrow 0 (TVar 11), TBorrow 1 (TVar 11)) :: []) = Some s).
Proof.
  intros f s H.
  pose proof (tau_rigid f [] s 0 1 (TVar 11) (TVar 11) H). lia.
Qed.

(* 分支一（ρ₉ ↦ 1）：死——实例化后 0 ≠ 1 仍地面冲突 *)
Example m36_branch1_dead : solve4 50 (rinstP [(9, 1)] skS) = None.
Proof. reflexivity. Qed.

(* 分支二（ρ₉ ↦ 0）：活——x : &₁α₁₀→&₀α₁₁ 与 y 的定义域余域同式相合 *)
Example m36_branch2_hits :
  solve4 50 (rinstP [(9, 0)] skS) = Some (solS, fun _ : capidx => M0).
Proof. reflexivity. Qed.

Example m36_trials_skS : arrange_trials 50 skS = 2. Proof. reflexivity. Qed.

Example m36_solve6_skS :
  solve6 50 skS = Some (solS, fun _ : capidx => M0, [(9, 0)]).
Proof. reflexivity. Qed.

(* N3 正面合取：荷破 ⇒ 引擎/安排分歧——流出现且分支 *)
Theorem m36_n3_positive :
  (solve4 50 skS = None)
  /\ (arrange_trials 50 skS = 2)
  /\ (exists s l, solve6 50 skS = Some (s, l, [(9, 0)]))
  /\ (exists rho, In rho (arrange_plan skS)
                 /\ solve4 50 (rinstP rho skS) <> None).
Proof.
  split; [reflexivity|]. split; [reflexivity|]. split.
  - exists solS. exists (fun _ : capidx => M0). exact m36_solve6_skS.
  - exists [(9, 0)]. split.
    + simpl. right. left. reflexivity.
    + intro Hnone. rewrite m36_branch2_hits in Hnone. discriminate.
Qed.

(* 见证可靠性实机（solve6_witness 实例化）：安排层解必经引擎验证 *)
Theorem m36_witness_verified :
  solve6 50 skS = Some (solS, fun _ : capidx => M0, [(9, 0)])
  /\ In [(9, 0)] (arrange_plan skS)
  /\ solve4 50 (rinstP [(9, 0)] skS) = Some (solS, fun _ : capidx => M0).
Proof.
  split; [exact m36_solve6_skS|].
  apply (solve6_witness 50 skS solS (fun _ : capidx => M0) [(9, 0)]
           m36_solve6_skS).
Qed.

(* 4e. 诚实 None · 刚性孪生（skT）：荷在 ⇒ 流零 + 不可安排修复 *)
Example m36_solve4_skT : solve4 50 skT = None. Proof. reflexivity. Qed.
Example m36_solve6_skT : solve6 50 skT = None. Proof. reflexivity. Qed.
Example m36_trials_skT : arrange_trials 50 skT = 1. Proof. reflexivity. Qed.

(* 流零定理实机（noether_N3_flow_zero 的 skT 实例） *)
Theorem m36_flow_zero_skT :
  arrange_trials 50 skT = 1
  /\ solve6 50 skT = match solve4 50 skT with
                     | Some (s, l) => Some (s, l, [])
                     | None => None end.
Proof. apply (noether_N3_flow_zero 50 skT). reflexivity. Qed.

(* 4f. 流梯度总表：流零（无栈）→ 流零（深二无荷栈）→ 流一 → 流二 *)
Theorem m36_tier_gradient :
  (rvars sk0 = [] /\ arrange_trials 50 sk0 = 1
     /\ exists s l, solve6 50 sk0 = Some (s, l, []))
  /\ (rvars skA = [] /\ arrange_trials 50 skA = 1
     /\ exists s l, solve6 50 skA = Some (s, l, []))
  /\ (rvars skF = [9] /\ arrange_trials 50 skF = 1
     /\ exists s l, solve6 50 skF = Some (s, l, [(9, 0)]))
  /\ (rvars skS = [9] /\ arrange_trials 50 skS = 2).
Proof.
  split.
  - split; [reflexivity|]. split; [reflexivity|].
    exists sol0. exists (fun _ : capidx => M0). exact m36_solve6_sk0.
  - split.
    + split; [reflexivity|]. split; [reflexivity|].
      exists solA. exists (fun _ : capidx => M0). exact m36_solve6_skA.
    + split.
      * split; [reflexivity|]. split; [reflexivity|].
        exists solF6. exists (fun _ : capidx => M0). exact m36_solve6_skF.
      * split; [reflexivity | reflexivity].
Qed.

(* 4g. 双池同框：skT（荷在：流零 + 诚实 None）vs skS（荷破：流二 + 分支 Some）
      ——诺特 N3 完整对偶的栈世界实机 *)
Theorem m36_flow_duality_ST :
  (rvars skT = [] /\ arrange_trials 50 skT = 1
     /\ solve4 50 skT = None /\ solve6 50 skT = None)
  /\ (rvars skS = [9] /\ arrange_trials 50 skS = 2
     /\ solve4 50 skS = None
     /\ solve6 50 skS = Some (solS, fun _ : capidx => M0, [(9, 0)])).
Proof.
  split.
  - split; [reflexivity|]. split; [reflexivity|]. split; reflexivity.
  - split; [reflexivity|]. split; [reflexivity|].
    split; [reflexivity | exact m36_solve6_skS].
Qed.

(* ================= 5. 诺特栈律实机 ================= *)

(* 5a. 无荷栈流零实例（noether_stack_flow_zero——栈深不生流的定理面）：
      skA 深二栈、零标签 ⇒ trials = 1 ∧ solve6 = solve4 的零包装 *)
Theorem m36_flow_zero_skA :
  rvars skA = []
  /\ arrange_trials 50 skA = 1
  /\ solve6 50 skA = match solve4 50 skA with
                     | Some (s, l) => Some (s, l, [])
                     | None => None end.
Proof.
  apply (noether_stack_flow_zero kappa [sA0; sA1] 0 [] skA 7 50).
  - reflexivity.
  - intros s Hs. destruct Hs as [Hs | Hs].
    + subst s. reflexivity.
    + destruct Hs as [Hs | Hs].
      * subst s. reflexivity.
      * destruct Hs.
Qed.

(* 5b. 流形维数公式实例：|plan skS| = |grounds skS| ^ |rvars skS| = 2^1 = 2
      ——流的指数是荷数（1），不是栈深（2）、不是方程数（7） *)
Theorem m36_flow_dim_skS :
  length (arrange_plan skS) = (length (grounds skS)) ^ (length (rvars skS))
  /\ length (arrange_plan skS) = 2.
Proof. split; [apply noether_stack_flow_dim | reflexivity]. Qed.

(* 荷数指数的算术面：双荷相乘（|G|² = 4）、三荷单候选（1³ = 1） *)
Example m36_card_mult : length (assigns [1; 0] [9; 10]) = 4.
Proof. reflexivity. Qed.
Example m36_card_single : length (assigns [0] [9; 10; 11]) = 1.
Proof. reflexivity. Qed.

(* 5c. 共享荷同调实例（noether_stack_coherence）：skS 的两层数值上共享 ρ₉
      ——单变量线性流形：每候选恰一支（不随栈深相乘） *)
Theorem m36_coherence_skS :
  rvars skS = [9]
  /\ arrange_plan skS = map (fun g => [(9, g)]) (grounds skS).
Proof.
  split; [reflexivity | apply noether_stack_coherence; reflexivity].
Qed.

(* 5d. 流栈局部实例（noether_stack_flow_local）：安排 (9,0) 的键与值
      都不出签名标签表 {1,9,0}——决策空间栈内生成 *)
Theorem m36_flow_local_skS :
  In [(9, 0)] (arrange_plan skS)
  /\ rvarb 9 = true /\ negb (rvarb 0) = true
  /\ In 9 (siglabels [sS0; sS1]) /\ In 0 (siglabels [sS0; sS1]).
Proof.
  assert (Hin : In [(9, 0)] (arrange_plan skS))
    by (simpl; right; left; reflexivity).
  pose proof (noether_stack_flow_local kappa [sS0; sS1] 0 [] skS 7
                 [(9, 0)] m36_kappa_pair Hin 9 0 (or_introl eq_refl))
    as [H1 [H2 [H3 H4]]].
  split; [exact Hin | split; [exact H1 | split; [exact H2 | split; [exact H3 | exact H4]]]].
Qed.

(* ================= 6. 零公理审计 ================= *)

Print Assumptions cgK_nil.
Print Assumptions cgK_single.
Print Assumptions cgK_grow.
Print Assumptions cgK_range_ext.
Print Assumptions cgK_phi_nil.
Print Assumptions sigstack_cone_intact.
Print Assumptions cgK_eqs_free.
Print Assumptions cgK_labels.
Print Assumptions cgK_charge_free.
Print Assumptions assigns_cardinality.
Print Assumptions noether_stack_flow_dim.
Print Assumptions noether_stack_flow_local.
Print Assumptions noether_stack_coherence.
Print Assumptions noether_stack_flow_zero.
Print Assumptions noether_stack_duality.
Print Assumptions m36_charge_source.
Print Assumptions m36_charge_ledger.
Print Assumptions m36_nil_identity.
Print Assumptions m36_single_bridge.
Print Assumptions m36_single_reading.
Print Assumptions m36_cgS_contrast.
Print Assumptions m36_kappa_pair.
Print Assumptions m36_supply_vocab_split.
Print Assumptions m36_phi_nil_skS.
Print Assumptions m36_phi_nil_theorem.
Print Assumptions m36_solve4_sk0.
Print Assumptions m36_solve6_sk0.
Print Assumptions m36_solve4_skA.
Print Assumptions m36_solve6_skA.
Print Assumptions m36_solve4_skF.
Print Assumptions m36_solve6_skF.
Print Assumptions m36_engine_none.
Print Assumptions m36_engine_tau_conflict.
Print Assumptions m36_rigid_conflict.
Print Assumptions m36_branch1_dead.
Print Assumptions m36_branch2_hits.
Print Assumptions m36_solve6_skS.
Print Assumptions m36_n3_positive.
Print Assumptions m36_witness_verified.
Print Assumptions m36_flow_zero_skT.
Print Assumptions m36_tier_gradient.
Print Assumptions m36_flow_duality_ST.
Print Assumptions m36_flow_zero_skA.
Print Assumptions m36_flow_dim_skS.
Print Assumptions m36_coherence_skS.
Print Assumptions m36_flow_local_skS.

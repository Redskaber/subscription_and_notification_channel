(* ===================================================================== *)
(*  效应能力流形 · M2 · TyCG：λ 层并入（τ 通道约束生成）                    *)
(*                                                                         *)
(*  贡献 #202（M2 重定义的生成侧）/ #209（变量供给守恒）。                  *)
(*                                                                         *)
(*  M1 的 CG 切片不产生 CTy 种子（e0 的 τ 投影为空）；本轮把 λ 层并入：     *)
(*  每个项节点分配一个自 τ 变量（计数器 p 供给），环境 G 把词法变量          *)
(*  映到其绑定点的 τ 变量（Lam 绑定 = 头插）。                              *)
(*                                                                         *)
(*    Var x   ：使用点 α_p = 绑定点 α_{G(x)}（未绑定 ⇒ α_p = α_p，平凡）    *)
(*    Lam x e ：α_p = α_{p+1} → α_{p+2}（p+1 = 绑定变量，p+2 = 体的自变量）  *)
(*    Call    ：函数侧 α_{p+1} = α_{e2} → α_p（函数 = 箭头）                *)
(*    六原语  ：τ 语义属 P3/P4/P5 平面，本轮不产生 τ 等式（如实登记）        *)
(*                                                                         *)
(*  cgT 是纯结构递归（无需燃料——与 M1 CG 的 sized recursion 对照：          *)
(*  项在递归中严格缩小，无燃料必要；M1 的燃料编码是 sized types 的          *)
(*  证明论演示，此处按同一结论走更短路径）。                                *)
(*                                                                         *)
(*  守恒量（#209）：τ 变量供给区间——生成约束引用的 τ 变量全部落在            *)
(*  [p, p') 内（cgT_range），供给增量受 tsize 线性约束（cgT_grow）。        *)
(* ===================================================================== *)

Require Import List Lia PeanoNat.
Import ListNotations.
Require Import Syntax CG Tau.

Lemma nth_In_aux : forall (G : list nat) (x p : nat),
  x < length G -> In (nth x G p) G.
Proof.
  induction G as [|g G IH]; intros x p Hlt; simpl in Hlt.
  - lia.
  - destruct x as [|x'].
    + simpl. left. reflexivity.
    + simpl. right. apply (IH x' p). lia.
Qed.

Fixpoint cgT (p : nat) (G : list nat) (e : tm) {struct e} : list constr * nat :=
  match e with
  | Var x => ([CTy (TVar p) (TVar (nth x G p))], S p)
  | Lam x e' =>
      let (cs, p') := cgT (S (S p)) (S p :: G) e' in
      (CTy (TVar p) (TArrow (TVar (S p)) (TVar (S (S p)))) :: cs, p')
  | New _ => ([], S p)
  | Borrow _ _ => ([], S p)
  | Drop _ => ([], S p)
  | Call e1 e2 =>
      let (cs1, p1) := cgT (S p) G e1 in
      let (cs2, p2) := cgT p1 G e2 in
      (CTy (TVar (S p)) (TArrow (TVar p1) (TVar p)) :: (cs1 ++ cs2), p2)
  | Grant _ _ e' =>
      let (cs, p') := cgT (S p) G e' in (cs, p')
  | Slice e' =>
      let (cs, p') := cgT (S p) G e' in (cs, p')
  end.

(* ---- 供给增长：每个节点至少消耗自己的自变量 ---- *)

Lemma cgT_grow : forall e p G cs p', cgT p G e = (cs, p') -> p < p'.
Proof.
  induction e as [x | x e IH | r | r l | l | e1 IH1 e2 IH2 | c k e IH | e IH];
    intros p G cs p' H; simpl in H.
  - injection H as _ Hp'. subst p'. lia.
  - destruct (cgT (S (S p)) (S p :: G) e) as [cs0 p0] eqn:E.
    injection H as _ Hp'. subst p'.
    pose proof (IH (S (S p)) (S p :: G) cs0 p0 E) as Hg. lia.
  - injection H as _ Hp'. subst p'. lia.
  - injection H as _ Hp'. subst p'. lia.
  - injection H as _ Hp'. subst p'. lia.
  - destruct (cgT (S p) G e1) as [cs1 q1] eqn:E1.
    destruct (cgT q1 G e2) as [cs2 q2] eqn:E2.
    injection H as _ Hp'. subst p'.
    pose proof (IH1 (S p) G cs1 q1 E1) as H1.
    pose proof (IH2 q1 G cs2 q2 E2) as H2. lia.
  - destruct (cgT (S p) G e) as [cs0 q] eqn:E.
    injection H as _ Hp'. subst p'. pose proof (IH (S p) G cs0 q E). lia.
  - destruct (cgT (S p) G e) as [cs0 q] eqn:E.
    injection H as _ Hp'. subst p'. pose proof (IH (S p) G cs0 q E). lia.
Qed.

(* ---- 供给区间守恒：生成的 τ 变量 ⊆ [p, p') ---- *)

Definition ctyVars (c : constr) : list nat :=
  match c with
  | CTy a b => tvars a ++ tvars b
  | _ => []
  end.

Lemma cgT_range : forall e p G, (forall w, In w G -> w < p) ->
  forall cs p', cgT p G e = (cs, p') ->
  forall v, In v (flat_map ctyVars cs) -> v < p' /\ (p <= v \/ In v G).
Proof.
  induction e as [x | x e IH | r | r l | l | e1 IH1 e2 IH2 | c k e IH | e IH];
    intros p G HG cs p' H v Hv; simpl in H.
  - (* Var：种子 = {p} ∪ {绑定变量 nth x G p} *)
    injection H as Hcs Hp'. subst cs p'. simpl in Hv.
    destruct Hv as [Hv | [Hv | []]].
    + subst v. split; [lia | left; lia].
    + (* Hv : nth x G p = v *)
      destruct (Nat.lt_ge_cases x (length G)) as [Hlt | Hge].
      * pose proof (nth_In_aux G x p Hlt) as Hn. specialize (HG _ Hn).
        subst v. split; [lia | right; exact Hn].
      * rewrite nth_overflow in Hv by exact Hge.
        split; [lia | left; lia].
  - (* Lam：种子 = {p, S p, S (S p)}，体走 IH *)
    destruct (cgT (S (S p)) (S p :: G) e) as [cs0 p0] eqn:E.
    injection H as Hcs Hp'. subst cs p'. simpl in Hv.
    assert (HG' : forall w, In w (S p :: G) -> w < S (S p)).
    { intros w [Hw | Hw]; [subst w; lia | specialize (HG w Hw); lia]. }
    pose proof (cgT_grow e (S (S p)) (S p :: G) cs0 p0 E) as Hg.
    pose proof (IH (S (S p)) (S p :: G) HG' cs0 p0 E) as IH'.
    destruct Hv as [H1 | [H1 | [H1 | H2]]].
    + subst v. split; [lia | left; lia].
    + subst v. split; [lia | left; lia].
    + subst v. split; [lia | left; lia].
    + destruct (IH' v H2) as [Hup [Hlo | HIn]].
      * split; [lia | left; lia].
      * destruct HIn as [Hv1 | Hv1].
        -- subst v. split; [lia | left; lia].
        -- split; [lia | right; exact Hv1].
  - (* New *) injection H as Hcs Hp'. subst cs. simpl in Hv. contradiction.
  - (* Borrow *) injection H as Hcs Hp'. subst cs. simpl in Hv. contradiction.
  - (* Drop *) injection H as Hcs Hp'. subst cs. simpl in Hv. contradiction.
  - (* Call：种子 = {S p, p1, p}，两侧走 IH *)
    destruct (cgT (S p) G e1) as [cs1 q1] eqn:E1.
    destruct (cgT q1 G e2) as [cs2 q2] eqn:E2.
    injection H as Hcs Hp'. subst cs p'. simpl in Hv.
    pose proof (cgT_grow e1 (S p) G cs1 q1 E1) as Hg1.
    pose proof (cgT_grow e2 q1 G cs2 q2 E2) as Hg2.
    assert (HG1 : forall w, In w G -> w < S p)
      by (intros w Hw; specialize (HG w Hw); lia).
    assert (HG2 : forall w, In w G -> w < q1)
      by (intros w Hw; specialize (HG w Hw); lia).
    pose proof (IH1 (S p) G HG1 cs1 q1 E1) as IH1'.
    pose proof (IH2 q1 G HG2 cs2 q2 E2) as IH2'.
    destruct Hv as [H1 | [H1 | [H1 | H2]]].
    + subst v. split; [lia | left; lia].
    + subst v. split; [lia | left; lia].
    + subst v. split; [lia | left; lia].
    + rewrite flat_map_app in H2. apply in_app_or in H2. destruct H2 as [H2 | H2].
      * destruct (IH1' v H2) as [Hup [Hlo | HIn]].
        -- split; [lia | left; lia].
        -- split; [lia | right; exact HIn].
      * destruct (IH2' v H2) as [Hup [Hlo | HIn]].
        -- split; [lia | left; lia].
        -- split; [lia | right; exact HIn].
  - (* Grant *)
    destruct (cgT (S p) G e) as [cs0 q] eqn:E.
    injection H as Hcs Hp'. subst cs p'.
    assert (HG1 : forall w, In w G -> w < S p)
      by (intros w Hw; specialize (HG w Hw); lia).
    pose proof (IH (S p) G HG1 cs0 q E) as IH'.
    destruct (IH' v Hv) as [Hup [Hlo | HIn]].
    + split; [lia | left; lia].
    + split; [lia | right; exact HIn].
  - (* Slice *)
    destruct (cgT (S p) G e) as [cs0 q] eqn:E.
    injection H as Hcs Hp'. subst cs p'.
    assert (HG1 : forall w, In w G -> w < S p)
      by (intros w Hw; specialize (HG w Hw); lia).
    pose proof (IH (S p) G HG1 cs0 q E) as IH'.
    destruct (IH' v Hv) as [Hup [Hlo | HIn]].
    + split; [lia | left; lia].
    + split; [lia | right; exact HIn].
Qed.

(* ---- cgT 只产生 CTy（φ 投影为空：通道分离的生成侧） ---- *)

Lemma chanProj_phi_cons_cty : forall a b cs,
  chanProj ChPhi (CTy a b :: cs) = chanProj ChPhi cs.
Proof. reflexivity. Qed.

(* ---- cgT 只产生 CTy（φ 投影为空：通道分离的生成侧） ---- *)

Lemma cgT_phi_nil_pair : forall e p G cs p',
  cgT p G e = (cs, p') -> chanProj ChPhi cs = [].
Proof.
  induction e as [x | x e IH | r | r l | l | e1 IH1 e2 IH2 | c k e IH | e IH];
    intros p G cs p' H; simpl in H.
  - injection H as Hcs Hp'. subst cs. reflexivity.
  - destruct (cgT (S (S p)) (S p :: G) e) as [cs0 p0] eqn:E.
    injection H as Hcs Hp'. subst cs p'.
    rewrite chanProj_phi_cons_cty. apply (IH (S (S p)) (S p :: G) cs0 p0 E).
  - injection H as Hcs Hp'. subst cs. reflexivity.
  - injection H as Hcs Hp'. subst cs. reflexivity.
  - injection H as Hcs Hp'. subst cs. reflexivity.
  - destruct (cgT (S p) G e1) as [cs1 q1] eqn:E1.
    destruct (cgT q1 G e2) as [cs2 q2] eqn:E2.
    injection H as Hcs Hp'. subst cs p'.
    rewrite chanProj_phi_cons_cty, chanProj_app.
    rewrite (IH1 (S p) G cs1 q1 E1), (IH2 q1 G cs2 q2 E2). reflexivity.
  - destruct (cgT (S p) G e) as [cs0 q] eqn:E.
    injection H as Hcs Hp'. subst cs p'. apply (IH (S p) G cs0 q E).
  - destruct (cgT (S p) G e) as [cs0 q] eqn:E.
    injection H as Hcs Hp'. subst cs p'. apply (IH (S p) G cs0 q E).
Qed.

Lemma cgT_phi_nil : forall e p G, chanProj ChPhi (fst (cgT p G e)) = [].
Proof.
  intros e p G. destruct (cgT p G e) as [cs p'] eqn:E.
  cbn [fst]. apply (cgT_phi_nil_pair e p G cs p' E).
Qed.

(* ===================================================================== *)
(*  效应能力流形 · W-M3-2 · Hsat：H 通道求解义务（挂靠 + 终点观测）        *)
(*                                                                         *)
(*  E.46 轮预告的 W-M3-2 第二组分：H 通道从"生成不解"升格为"求解义务"。      *)
(*                                                                         *)
(*  语义侧：                                                                *)
(*    hle cs l r —— 租约 l 挂靠区域 r 的传递闭形态：                         *)
(*      ∃r0. CHr l r0 ∈ cs ∧ rle cs r0 r                                    *)
(*      （挂靠沿 outlives 上移——挂靠传递；R 闭包是 H 的供给边）            *)
(*    hsat cs —— 每个 CEnd l（终点观测）都有挂靠见证（孤儿租约阻塞）        *)
(*                                                                         *)
(*  H 是第一个有真实阻塞面的通道（Rust dropck 同构：还一个没出生的租约      *)
(*  = drop 一个还借着的值）。SEARCH_FAIL 类从空到非空的机内时刻。           *)
(*                                                                         *)
(*  计算侧：hclose cs = hedges ⊕ rclose —— 单步组合                         *)
(*  （rclose 已传递，上移一步即达不动点——"R 供给 H"安排边的可计算形态）：   *)
(*    hclose_sound    可靠：闭包挂靠都是真挂靠（H 消费 R 闭包不产假见证）  *)
(*    hclose_complete 完备：真挂靠都在闭包中                                 *)
(*    hsatb_correct   判定器与语义一致                                       *)
(*    hclose_xapply_invar 盲性：现形不移动 H 闭包（CHr/CEnd 刚性）           *)
(* ===================================================================== *)

Require Import List Lia PeanoNat.
Import ListNotations.
Require Import Mult Cap Syntax Xsub Rsat.

Local Open Scope bool_scope.

(* ================= 一、计算侧：挂靠边表与上移算子 ================= *)

Definition hedge1 (c : constr) : list (nat * nat) :=
  match c with
  | CHr l r => [(l, r)]
  | _ => []
  end.

Definition hedges (cs : list constr) : list (nat * nat) :=
  flat_map hedge1 cs.

Definition end1 (c : constr) : list nat :=
  match c with
  | CEnd l => [l]
  | _ => []
  end.

Definition ends (cs : list constr) : list nat :=
  flat_map end1 cs.

Lemma hedges_in : forall cs l r,
  In (l, r) (hedges cs) <-> In (CHr l r) cs.
Proof.
  intros cs l r. unfold hedges. rewrite in_flat_map. split.
  - intros [c [Hc Hin]].
    destruct c as [x y | r1 r2 | c k | c c' w | l0 r0 | l0 | r0 t];
      unfold hedge1 in Hin; simpl in Hin; try contradiction.
    destruct Hin as [Hin | []]. inversion Hin; subst; exact Hc.
  - intros H. exists (CHr l r). split;
      [exact H | unfold hedge1; simpl; left; reflexivity].
Qed.

Lemma ends_in : forall cs l,
  In l (ends cs) <-> In (CEnd l) cs.
Proof.
  intros cs l. unfold ends. rewrite in_flat_map. split.
  - intros [c [Hc Hin]].
    destruct c as [x y | r1 r2 | c k | c c' w | l0 r0 | l0 | r0 t];
      unfold end1 in Hin; simpl in Hin; try contradiction.
    destruct Hin as [Hin | []]. inversion Hin; subst; exact Hc.
  - intros H. exists (CEnd l). split;
      [exact H | unfold end1; simpl; left; reflexivity].
Qed.

(* 上移一步：挂靠 (l,r0) × R 可达 (r0,r') ⇒ (l,r') *)
Definition hup (h Rcl : list (nat * nat)) : list (nat * nat) :=
  nodup peq_dec
    (h ++ flat_map (fun lr =>
              match lr with
              | (l, r0) =>
                  flat_map (fun rr =>
                              match rr with
                              | (r1, r') => if Nat.eqb r0 r1 then [(l, r')] else []
                              end) Rcl
              end) h).

Lemma hup_in : forall h Rcl l r',
  In (l, r') (hup h Rcl) <->
  (In (l, r') h \/
   exists r0, In (l, r0) h /\ In (r0, r') Rcl).
Proof.
  intros h Rcl l r'. unfold hup. split.
  - intros Hin. apply nodup_In in Hin. apply in_app_or in Hin.
    destruct Hin as [Hh | Hlift].
    + left. exact Hh.
    + right. rewrite in_flat_map in Hlift.
      destruct Hlift as [[l0 r0] [Hlr Hin]].
      rewrite in_flat_map in Hin. destruct Hin as [[r1 r'0] [Hrr Hif]].
      destruct (Nat.eqb r0 r1) eqn:Eeq; simpl in Hif.
      * destruct Hif as [Hif | []]. inversion Hif; subst.
        apply Nat.eqb_eq in Eeq. subst r1.
        exists r0. split; [exact Hlr | exact Hrr].
      * destruct Hif.
  - intros [Hh | [r0 [Hlr Hrr]]].
    + apply nodup_In. apply in_or_app. left. exact Hh.
    + apply nodup_In. apply in_or_app. right. apply in_flat_map.
      exists (l, r0). split; [exact Hlr|].
      apply in_flat_map. exists (r0, r'). split; [exact Hrr|].
      rewrite Nat.eqb_refl. left. reflexivity.
Qed.

Definition hclose (cs : list constr) : list (nat * nat) :=
  hup (hedges cs) (rclose cs).

(* ================= 二、语义侧与判定器 ================= *)

Definition hle (cs : list constr) (l r : nat) : Prop :=
  exists r0, In (CHr l r0) cs /\ rle cs r0 r.

Definition hsat (cs : list constr) : Prop :=
  forall l, In (CEnd l) cs -> exists r, hle cs l r.

(* 可靠：闭包挂靠都是真挂靠（H 消费 R 闭包不产假见证） *)
Theorem hclose_sound : forall cs l r,
  In (l, r) (hclose cs) -> hle cs l r.
Proof.
  intros cs l r Hin. unfold hclose in Hin. apply hup_in in Hin.
  destruct Hin as [Hseed | [r0 [Hseed Hreach]]].
  - apply hedges_in in Hseed. exists r. split;
      [exact Hseed | apply rle_refl].
  - apply hedges_in in Hseed. exists r0. split; [exact Hseed|].
    exact (rclose_sound cs r0 r Hreach).
Qed.

(* 完备：真挂靠都在闭包中 *)
Theorem hclose_complete : forall cs l r,
  hle cs l r -> In (l, r) (hclose cs).
Proof.
  intros cs l r [r0 [Hseed Hreach]].
  assert (Hseed' : In (l, r0) (hedges cs)).
  { apply (proj2 (hedges_in cs l r0)). exact Hseed. }
  unfold hclose. apply (proj2 (hup_in (hedges cs) (rclose cs) l r)).
  destruct (Nat.eq_dec r0 r) as [Heq | Hne].
  - subst r0. left. exact Hseed'.
  - right. exists r0. split; [exact Hseed'|].
    exact (rclose_complete cs r0 r Hreach Hne).
Qed.

(* 判定器与语义一致 *)
Definition hsatb (cs : list constr) : bool :=
  forallb (fun l => existsb (fun lr => Nat.eqb (fst lr) l) (hclose cs))
          (ends cs).

Theorem hsatb_correct : forall cs,
  hsatb cs = true <-> hsat cs.
Proof.
  intros cs. unfold hsatb. rewrite forallb_forall. split.
  - intros Hall l Hl.
    apply (proj2 (ends_in cs l)) in Hl.
    specialize (Hall l Hl). rewrite existsb_exists in Hall.
    destruct Hall as [lr [Hlr Heq]]. destruct lr as [l' r].
    simpl in Heq. apply Nat.eqb_eq in Heq. subst l'.
    exists r. exact (hclose_sound cs l r Hlr).
  - intros Hsat l Hl.
    destruct (Hsat l (proj1 (ends_in cs l) Hl)) as [r Hle].
    apply existsb_exists. exists (l, r). split.
    + exact (hclose_complete cs l r Hle).
    + rewrite Nat.eqb_refl. reflexivity.
Qed.

(* ================= 三、盲性守恒（H 对 τ 代换盲） ================= *)

Lemma hedge1_xapply : forall s c, hedge1 (xapply1 s c) = hedge1 c.
Proof. intros s c. destruct c; reflexivity. Qed.

Lemma end1_xapply : forall s c, end1 (xapply1 s c) = end1 c.
Proof. intros s c. destruct c; reflexivity. Qed.

Lemma hedges_xapply : forall s cs, hedges (xapply s cs) = hedges cs.
Proof.
  intros s cs. unfold hedges, xapply.
  induction cs as [|c cs IH]; simpl; [reflexivity|].
  rewrite hedge1_xapply. f_equal. exact IH.
Qed.

Lemma ends_xapply : forall s cs, ends (xapply s cs) = ends cs.
Proof.
  intros s cs. unfold ends, xapply.
  induction cs as [|c cs IH]; simpl; [reflexivity|].
  rewrite end1_xapply. f_equal. exact IH.
Qed.

(* 现形不移动 H 闭包（盲性矩阵的 H 格） *)
Theorem hclose_xapply_invar : forall s cs,
  hclose (xapply s cs) = hclose cs.
Proof.
  intros s cs. unfold hclose.
  rewrite hedges_xapply, rclose_xapply_invar. reflexivity.
Qed.

(* CRg 成员资格对现形不变（rle 盲性的食粮） *)
Lemma in_crg_xapply : forall s cs a b,
  In (CRg a b) (xapply s cs) <-> In (CRg a b) cs.
Proof.
  intros s cs a b. unfold xapply. split.
  - intros Hin. apply in_map_iff in Hin.
    destruct Hin as [c [Hc Hin]]. destruct c;
      cbn [xapply1] in Hc; try discriminate.
    inversion Hc; subst. exact Hin.
  - intros Hin. apply in_map_iff. exists (CRg a b).
    split; [reflexivity | exact Hin].
Qed.

(* rle 对现形不变（R 语义的盲性） *)
Lemma rle_xapply_invar : forall s cs a b,
  rle (xapply s cs) a b <-> rle cs a b.
Proof.
  intros s cs a b. split.
  - intros H. induction H as [r | r1 r2 Hin | x y z Hxy IHxy Hyz IHyz].
    + apply rle_refl.
    + apply rle_edge. apply (proj1 (in_crg_xapply s cs r1 r2)). exact Hin.
    + apply (rle_trans cs x y z); [exact IHxy | exact IHyz].
  - intros H. induction H as [r | r1 r2 Hin | x y z Hxy IHxy Hyz IHyz].
    + apply rle_refl.
    + apply rle_edge. apply (proj2 (in_crg_xapply s cs r1 r2)). exact Hin.
    + apply (rle_trans (xapply s cs) x y z); [exact IHxy | exact IHyz].
Qed.

(* CHr / CEnd 成员资格对现形不变 *)
Lemma in_chr_xapply : forall s cs l r,
  In (CHr l r) (xapply s cs) <-> In (CHr l r) cs.
Proof.
  intros s cs l r. unfold xapply. split.
  - intros Hin. apply in_map_iff in Hin.
    destruct Hin as [c [Hc Hin]]. destruct c;
      cbn [xapply1] in Hc; try discriminate.
    inversion Hc; subst. exact Hin.
  - intros Hin. apply in_map_iff. exists (CHr l r).
    split; [reflexivity | exact Hin].
Qed.

Lemma in_cend_xapply : forall s cs l,
  In (CEnd l) (xapply s cs) <-> In (CEnd l) cs.
Proof.
  intros s cs l. unfold xapply. split.
  - intros Hin. apply in_map_iff in Hin.
    destruct Hin as [c [Hc Hin]]. destruct c;
      cbn [xapply1] in Hc; try discriminate.
    inversion Hc; subst. exact Hin.
  - intros Hin. apply in_map_iff. exists (CEnd l).
    split; [reflexivity | exact Hin].
Qed.

(* hsat 对现形不变（盲性守恒的谓词形态） *)
Theorem hsat_xapply_invar : forall s cs,
  hsat (xapply s cs) <-> hsat cs.
Proof.
  intros s cs. split; intros H; intros l Hl.
  - specialize (H l (proj2 (in_cend_xapply s cs l) Hl)).
    destruct H as [r [r0 [Hseed Hreach]]]. exists r, r0. split.
    + apply (proj1 (in_chr_xapply s cs l r0)). exact Hseed.
    + apply (proj1 (rle_xapply_invar s cs r0 r)). exact Hreach.
  - specialize (H l (proj1 (in_cend_xapply s cs l) Hl)).
    destruct H as [r [r0 [Hseed Hreach]]]. exists r, r0. split.
    + apply (proj2 (in_chr_xapply s cs l r0)). exact Hseed.
    + apply (proj2 (rle_xapply_invar s cs r0 r)). exact Hreach.
Qed.

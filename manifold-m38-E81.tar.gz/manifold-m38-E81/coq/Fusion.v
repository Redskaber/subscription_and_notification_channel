(* ===================================================================== *)
(*  效应能力流形 · M2 · Fusion：双通道融合（Lτ ⊗ Lφ）                        *)
(*                                                                         *)
(*  贡献 #207（关联）/ #208（形式）。                                       *)
(*                                                                         *)
(*  solve2 fuel cs：对约束池 cs 做 L 五 pass 归一的两 pass 实例化——         *)
(*    Lτ pass：unify (MM) 吃 ChTy 投影；                                    *)
(*    Lφ pass：lphi (Kleene 跑满饱和界) 吃 ChPhi 投影。                     *)
(*  其余通道（R / H / X）本轮不解，如实残部（M3/M4）。                       *)
(*                                                                         *)
(*  分离性（#207）：τ 代换作用于 ty，φ 求解作用于 capidx —— 两通道          *)
(*  字母表在类型级不相交（cgT 只产 CTy、CG 的 φ 种子不含 τ；反之 CG 不产    *)
(*  CTy）。生成侧引理：cg_no_cty / cgT_phi_nil / tyEqs_proj。               *)
(*                                                                         *)
(*  W-LIFE-1a-REL（CG↔J′ 对应）的可靠性方向就此落定：                       *)
(*  infer_sound —— 若 infer 返回 (σ, l)，则 σ 合一 λ 层 τ 约束、            *)
(*  l 满足且最小满足 φ 投影。完备性/主性方向仍挂 W-M2-1。                   *)
(* ===================================================================== *)

Require Import List Lia PeanoNat.
Import ListNotations.
Require Import Mult Cap Syntax CG Tau TyCG Lphi.

(* ---- 生成侧分离引理 ---- *)

(* M1 的 CG 不产生任何 τ 等式 *)
Lemma cg_no_cty : forall e, chanProj ChTy (cg e) = [].
Proof.
  induction e as [x | x e IH | r | r l | l | e1 IH1 e2 IH2 | c k e IH | e IH].
  - reflexivity.
  - rewrite cg_lam, chanProj_app, IH. reflexivity.
  - reflexivity.
  - reflexivity.
  - reflexivity.
  - rewrite cg_call, !chanProj_app, IH1, IH2. reflexivity.
  - rewrite cg_grant, chanProj_app, IH. reflexivity.
  - rewrite cg_slice, chanProj_app, IH. reflexivity.
Qed.

(* tyEqs 与通道投影可换：Lτ pass 吃投影 ≡ 吃全池的 τ 切片 *)
Lemma tyEqs_proj : forall cs, tyEqs (chanProj ChTy cs) = tyEqs cs.
Proof.
  induction cs as [|c cs IH]; [reflexivity|].
  destruct c as [a b | r1 r2 | c0 k | c c' w | l r | l | r t]; simpl;
    try rewrite IH; reflexivity.
Qed.

(* phsat 对拼接可分 *)
Lemma phsat_app : forall m A B, phsat m (A ++ B) <-> phsat m A /\ phsat m B.
Proof.
  intros m A B. induction A as [|[a b | r1 r2 | c k | c c' w | l r | l | r t] A IH];
    simpl.
  - tauto.
  - tauto.
  - tauto.
  - rewrite IH. tauto.
  - rewrite IH. tauto.
  - tauto.
  - tauto.
  - tauto.
Qed.

(* ---- 双通道求解器 ---- *)

Definition solve2 (fuel : nat) (cs : list constr) : option (tsubst * cmap) :=
  match unify fuel (tyEqs (chanProj ChTy cs)) with
  | Some s => Some (s, lphi (chanProj ChPhi cs))
  | None => None
  end.

Theorem solve2_sound : forall fuel cs s l,
  solve2 fuel cs = Some (s, l) ->
  unifies s (tyEqs (chanProj ChTy cs)) /\ phsat l (chanProj ChPhi cs).
Proof.
  intros fuel cs s l H. unfold solve2 in H.
  destruct (unify fuel (tyEqs (chanProj ChTy cs))) eqn:Hu.
  - inversion H; subst; clear H. split.
    + eapply unify_sound; eauto.
    + apply (lphi_solve (chanProj ChPhi cs)).
  - discriminate.
Qed.

Theorem solve2_phi_min : forall fuel cs s l,
  solve2 fuel cs = Some (s, l) ->
  forall m, phsat m (chanProj ChPhi cs) -> cle l m.
Proof.
  intros fuel cs s l H m Hm. unfold solve2 in H.
  destruct (unify fuel (tyEqs (chanProj ChTy cs))) eqn:Hu.
  - inversion H; subst; clear H.
    apply (proj2 (lphi_solve (chanProj ChPhi cs)) m Hm).
  - discriminate.
Qed.

(* ---- e 级联合推断：λ 层并入后的 M2 主定理（W-LIFE-1a-REL 可靠性方向） ---- *)

Definition infer (fuel : nat) (e : tm) : option (tsubst * cmap) :=
  solve2 fuel (cg e ++ fst (cgT 0 [] e)).

Theorem infer_sound : forall fuel e s l, infer fuel e = Some (s, l) ->
  unifies s (tyEqs (fst (cgT 0 [] e)))
  /\ phsat l (chanProj ChPhi (cg e))
  /\ (forall m, phsat m (chanProj ChPhi (cg e)) -> cle l m).
Proof.
  intros fuel e s l H. unfold infer in H.
  assert (Ht := solve2_sound fuel (cg e ++ fst (cgT 0 [] e)) s l H).
  assert (Hmin := solve2_phi_min fuel (cg e ++ fst (cgT 0 [] e)) s l H).
  destruct Ht as [Ht Hp].
  rewrite chanProj_app, cg_no_cty in Ht. simpl in Ht.
  rewrite tyEqs_proj in Ht.
  rewrite chanProj_app in Hp, Hmin.
  assert (Hnil : chanProj ChPhi (fst (cgT 0 [] e)) = []) by (apply cgT_phi_nil).
  rewrite Hnil in Hp, Hmin.
  rewrite phsat_app in Hp. destruct Hp as [Hp _].
  repeat split.
  - exact Ht.
  - exact Hp.
  - intros m Hm. apply Hmin.
    apply (proj2 (phsat_app m (chanProj ChPhi (cg e)) [])).
    split; [exact Hm | exact I].
Qed.

(* ===================================================================== *)
(*  效应能力流形 · 第 56 轮 · M38Example：DPLL(T) 增量面 + flow_total 实机   *)
(*                    （诺特增量律——冲突学习/理论传播/回跳）                 *)
(*                                                                         *)
(*  七组实机（编译即验证——eq_refl / Print Assumptions）：                   *)
(*    1. 读数表：skT（一跳锚相克传播池）/ skU（无粘合反例池）的              *)
(*       rvars/grounds/决策/引擎/计划读数                                   *)
(*    2. 理论传播（一跳锚提取）：anchors/forced1/clash1 的静态检测；         *)
(*       skT 锚相克真（9↦1 与 10↦0 无公共）；skU 无粘合不提取（健全性）；    *)
(*       skD 深层嵌套一跳不到（如实登记——多跳挂 W-DPLL-2）                  *)
(*    3. 传播收益（路径下探）：skT 的 dpll_trials 2 < 凸 3 < 朴素 4——       *)
(*       静态传播零引擎调用剪除等式支，路径下探到凸形态之下                  *)
(*    4. 冲突学习：决策死（skJ 全差异支入学习库——计划守恒 8=8）；            *)
(*       引擎死（skD 等式支入学习库——增量重解 trials 4→2）                  *)
(*    5. 见证守恒（同调）：skT/skD/skJ 的 solve8 见证 = solve7 见证          *)
(*       （学习剪的是死支——首个活安排不变）                                 *)
(*    6. flow_total 对齐：五池的 |NO 计划| 与划分求和                        *)
(*       （falling 形态）；flow_total_two 定理的池实例化                     *)
(*    7. 增量栈（Z3 层栈）：push/pop 对合实机 + Print Assumptions 审计      *)
(*                                                                         *)
(*  展示池（新增两个）：skT = 四类型两相遇（锚 20：9↦1；锚 31：10↦0）；      *)
(*  skU = 两类型无相遇（锚对存在但无粘合方程——静态提取健全性的反例）。       *)
(*  既有池复用：skI/skD/skJ/skS（M37 六池）；skP/skQ 兄弟分叉面不变。        *)
(* ===================================================================== *)

Require Import List Lia PeanoNat Bool.
Import ListNotations.
Require Import Mult Cap Syntax CG Tau TyCG Lphi Fusion Mu Xsub M3Fusion
               Rsat Hsat Solve3 Xcone Drop2 Gphi Solve4
               SigLam Noether M34Example Rvar M35Example SigStack M36Example
               Ineq SibLam M37Example DpllT FlowTotal.

Local Open Scope bool_scope.

(* ================= 0. 展示池：skT / skU ================= *)

(* skT：一跳锚相克传播池——四类型定义 + 两相遇方程
   锚 20：TBorrow 9 (TVar 20) ≡ TBorrow 1 (TVar 20)（迫值 9↦1）
   锚 31：TBorrow 10 (TVar 31) ≡ TBorrow 0 (TVar 31)（迫值 10↦0）
   相遇：CTy (TVar 0) (TVar 1) 与 CTy (TVar 2) (TVar 3)（粘合两侧类型） *)
Definition tT1 : ty := TArrow (TBorrow 9 (TVar 20)) (TVar 21).
Definition tT2 : ty := TArrow (TBorrow 1 (TVar 20)) (TVar 22).
Definition tT3 : ty := TArrow (TBorrow 10 (TVar 31)) (TVar 23).
Definition tT4 : ty := TArrow (TBorrow 0 (TVar 31)) (TVar 24).
Definition skT : list constr :=
  [CTy (TVar 0) tT1; CTy (TVar 1) tT2; CTy (TVar 2) tT3; CTy (TVar 3) tT4;
   CTy (TVar 0) (TVar 1); CTy (TVar 2) (TVar 3)].

(* skU：无粘合反例池——锚对在类型中共存但无相遇方程粘合
   （静态提取不误报——一跳传播的健全性面） *)
Definition skU : list constr :=
  [CTy (TVar 0) tT1; CTy (TVar 1) tT2].

(* 学习库实例 *)
Definition LT : learnlib := [[(9, 10, true)]].       (* skT 等式支：锚相克死 *)
Definition LD : learnlib := [[(9, 10, true)]].       (* skD 等式支：引擎死 *)
Definition alldiffJ : list dec :=
  [(9, 10, false); (9, 11, false); (10, 11, false)]. (* skJ 全差异支：决策死 *)
Definition LJ : learnlib := [alldiffJ].

(* ================= 1. 读数表 ================= *)

Example m38_rvars_skT : rvars skT = [9; 10]. Proof. reflexivity. Qed.
Example m38_grounds_skT : grounds skT = [1; 0]. Proof. reflexivity. Qed.
Example m38_rvars_skU : rvars skU = [9]. Proof. reflexivity. Qed.
Example m38_grounds_skU : grounds skU = [1]. Proof. reflexivity. Qed.
(* skU 的锚 α=20 有 (9,1) 对但无相遇粘合——锚提取应为空（健全性） *)
Example m38_anchors_skU : anchors skU = []. Proof. reflexivity. Qed.

(* skT 决策与计划读数 *)
Example m38_decs_skT : no_decisions_ok (rvars skT)
  = [[(9, 10, true)]; [(9, 10, false)]]. Proof. reflexivity. Qed.
Example m38_noplan_skT : no_plan skT
  = [[(9, 1); (10, 1)]; [(9, 0); (10, 0)];
     [(9, 0); (10, 1)]; [(9, 1); (10, 0)]]. Proof. reflexivity. Qed.
(* 等式支逐枚举引擎死（锚相克的引擎面——传播检测的对照） *)
Example m38_eqdead_g1_skT : solve4 50 (rinstP [(9, 1); (10, 1)] skT) = None.
Proof. reflexivity. Qed.
Example m38_eqdead_g0_skT : solve4 50 (rinstP [(9, 0); (10, 0)] skT) = None.
Proof. reflexivity. Qed.
Example m38_diffdead_skT : solve4 50 (rinstP [(9, 0); (10, 1)] skT) = None.
Proof. reflexivity. Qed.

(* ================= 2. 理论传播（一跳锚提取） ================= *)

(* skT 的锚表：锚 20 迫值 9↦1、锚 31 迫值 10↦0 *)
Example m38_anchors_skT : anchors skT = [(9, 1); (10, 0)].
Proof. reflexivity. Qed.
Example m38_forced_9 : forced1 9 skT = [1]. Proof. reflexivity. Qed.
Example m38_forced_10 : forced1 10 skT = [0]. Proof. reflexivity. Qed.
(* 锚相克：迫值 [1] 与 [0] 无公共 ⇒ 等式支静态死（免引擎调用） *)
Example m38_clash_skT : clash1 skT 9 10 = true. Proof. reflexivity. Qed.
(* 自身不相克（对称基准） *)
Example m38_clash_self : clash1 skT 9 9 = false. Proof. reflexivity. Qed.
(* skU：无粘合 ⇒ 无锚 ⇒ 不相克（不误报——健全性） *)
Example m38_clash_skU : clash1 skU 9 10 = false. Proof. reflexivity. Qed.
(* skD：深层嵌套锚（9↦1 需两跳、10↦0 需三跳）——一跳提取不到（如实登记） *)
Example m38_anchors_skD : anchors skD = []. Proof. reflexivity. Qed.
Example m38_clash_skD : clash1 skD 9 10 = false. Proof. reflexivity. Qed.
(* 冲突学习面：锚相克 ⇒ 等式支决策入学习库 *)
Example m38_clash_learn_skT : clash_learn skT 9 10 = [[(9, 10, true)]].
Proof. reflexivity. Qed.
Example m38_clash_learn_skD : clash_learn skD 9 10 = [].
Proof. reflexivity. Qed.

(* ================= 3. 传播收益（路径下探） ================= *)

(* 传播剪除后的计划：仅差异支 2 枚举 *)
Example m38_dplan_skT : dpll_plan skT LT
  = [[(9, 0); (10, 1)]; [(9, 1); (10, 0)]]. Proof. reflexivity. Qed.
(* 路径账：传播 2 < 凸 3 < 朴素 4——静态传播剪除等式支（零引擎调用） *)
Example m38_dplltrials_skT : dpll_trials 50 skT LT = 2.
Proof. reflexivity. Qed.
Example m38_notrials_skT : no_trials 50 skT = 4. Proof. reflexivity. Qed.
Example m38_convtrials_skT : arrange_trials 50 skT = 3. Proof. reflexivity. Qed.
(* 路径下探定理（实机）：dpll 2 < 凸 3 < 朴素 4 *)
Theorem m38_path_descent :
  dpll_trials 50 skT LT = 2 /\ arrange_trials 50 skT = 3
  /\ no_trials 50 skT = 4
  /\ dpll_trials 50 skT LT < arrange_trials 50 skT
  /\ arrange_trials 50 skT < no_trials 50 skT.
Proof.
  assert (H1 : dpll_trials 50 skT LT = 2) by reflexivity.
  assert (H2 : arrange_trials 50 skT = 3) by reflexivity.
  assert (H3 : no_trials 50 skT = 4) by reflexivity.
  repeat split; lia.
Qed.

(* ================= 4. 冲突学习（决策死 / 引擎死两级） ================= *)

(* 决策死：skJ 全差异支 no_branch = []（m37_alldiff 的再输出） *)
Example m38_deadbranch_skJ : no_branch skJ alldiffJ = [].
Proof. reflexivity. Qed.
(* 学习不减解：决策死支入学习库 ⇒ 计划守恒 8 = 8 *)
Example m38_learn_conserve_skJ :
  dpll_plan skJ LJ = no_plan skJ. Proof. reflexivity. Qed.
Example m38_len_skJ : length (dpll_plan skJ LJ) = 8. Proof. reflexivity. Qed.
(* 引擎死：skD 等式支枚举存在但逐支引擎死（学习库的另一级死性） *)
Example m38_eqbranch_skD_exists :
  no_branch skD [(9, 10, true)]
  = [[(9, 1); (10, 1)]; [(9, 0); (10, 0)]]. Proof. reflexivity. Qed.
(* 引擎死学习的增量收益：带库重解 trials 4 → 2（等式支免重评） *)
Example m38_dplltrials_skD : dpll_trials 50 skD LD = 2.
Proof. reflexivity. Qed.
Example m38_notrials_skD : no_trials 50 skD = 4. Proof. reflexivity. Qed.
(* 学习计划子集（learn_subplan 的实机面）：剪除只删不增 *)
Example m38_dplan_skD : dpll_plan skD LD
  = [[(9, 0); (10, 1)]; [(9, 1); (10, 0)]]. Proof. reflexivity. Qed.

(* ================= 5. 见证守恒（同调） ================= *)

(* 三池的 solve8 见证 = solve7 见证（学习剪死支——首个活安排不变） *)
Theorem m38_witness_skT :
  match solve8 50 skT LT, solve7 50 skT with
  | Some (_, _, r1), Some (_, _, r2) => r1 = r2
  | None, None => True
  | _, _ => False
  end. Proof. reflexivity. Qed.
Theorem m38_witness_skD :
  match solve8 50 skD LD, solve7 50 skD with
  | Some (_, _, r1), Some (_, _, r2) => r1 = r2
  | None, None => True
  | _, _ => False
  end. Proof. reflexivity. Qed.
Theorem m38_witness_skJ :
  match solve8 50 skJ LJ, solve7 50 skJ with
  | Some (_, _, r1), Some (_, _, r2) => r1 = r2
  | None, None => True
  | _, _ => False
  end. Proof. reflexivity. Qed.
(* 见证具体值：[(9,1);(10,0)]（skT/skD 同见证——两池同结构） *)
Theorem m38_witness_value_skT :
  match solve8 50 skT LT with
  | Some (_, _, rho) => rho = [(9, 1); (10, 0)]
  | None => False
  end. Proof. reflexivity. Qed.

(* ================= 6. flow_total 对齐（五池划分求和） ================= *)

(* skI：|G|=1 ⇒ 1 + 0 = 1 = 1^2（等式支 1 + 差异支 0） *)
Example m38_flow_skI :
  length (no_plan skI) = falling 1 1 + falling 1 2.
Proof. reflexivity. Qed.
(* skD：|G|=2 ⇒ 2 + 2 = 4 = 2^2 *)
Example m38_flow_skD :
  length (no_plan skD) = falling 2 1 + falling 2 2.
Proof. reflexivity. Qed.
(* skT：|G|=2 ⇒ 2 + 2 = 4（同型——传播不改总量） *)
Example m38_flow_skT :
  length (no_plan skT) = falling 2 1 + falling 2 2.
Proof. reflexivity. Qed.
(* skJ：|G|=2, |R|=3 ⇒ 2 + 3*2 + 0 = 8 = 2^3（Bell(3)=5 划分） *)
Example m38_flow_skJ :
  length (no_plan skJ) = falling 2 1 + 3 * falling 2 2 + falling 2 3.
Proof. reflexivity. Qed.
(* skS：|R|=1 退化 ⇒ 2 = falling 2 1 *)
Example m38_flow_skS : length (no_plan skS) = falling 2 1.
Proof. reflexivity. Qed.
(* flow_total_two 的池实例化（一般定理的实机面） *)
Example m38_ftt_skI : length (no_plan skI) = (length (grounds skI)) ^ 2.
Proof. apply flow_total_two. reflexivity. Qed.
Example m38_ftt_skD : length (no_plan skD) = (length (grounds skD)) ^ 2.
Proof. apply flow_total_two. reflexivity. Qed.
Example m38_ftt_skT : length (no_plan skT) = (length (grounds skT)) ^ 2.
Proof. apply flow_total_two. reflexivity. Qed.
(* 传播剪除下的总量守恒：dpll_plan ⊆ no_plan 且差异支总量不变 *)
Example m38_dflow_skT : length (dpll_plan skT LT) = falling 2 2.
Proof. reflexivity. Qed.
(* 划分表：Bell(2)=2 / Bell(3)=5 *)
Example m38_parts2_len : length (parts2 9 10) = 2. Proof. reflexivity. Qed.
Example m38_parts3_len : length (parts3 9 10 11) = 5. Proof. reflexivity. Qed.
Example m38_parts3_blocks :
  map (fun p => length p) (parts3 9 10 11) = [1; 2; 2; 2; 3].
Proof. reflexivity. Qed.

(* ================= 7. 增量栈（Z3 层栈）与审计 ================= *)

(* 压弹对合实机：三层栈快照 *)
Example m38_stack_roundtrip :
  dpop (dpush (dpop (dpush (mkDstate [[(9, 10, true)]] []))))
  = mkDstate [[(9, 10, true)]] [].
Proof. reflexivity. Qed.
(* 层内学习：学习库单调增长 *)
Example m38_learn_stack :
  dL (dlearn (mkDstate LT []) [(9, 10, false)])
  = [[(9, 10, false)]; [(9, 10, true)]].
Proof. reflexivity. Qed.
(* 弹栈还原：push 后学习、pop 回快照 *)
Example m38_pop_restore :
  dpop (dlearn (dpush (mkDstate [] [])) [(9, 10, false)]) = mkDstate [] [].
Proof. reflexivity. Qed.

(* ================= 8. Print Assumptions 全链路零公理审计 ================= *)

Print Assumptions m38_rvars_skT.
Print Assumptions m38_grounds_skT.
Print Assumptions m38_rvars_skU.
Print Assumptions m38_grounds_skU.
Print Assumptions m38_anchors_skU.
Print Assumptions m38_decs_skT.
Print Assumptions m38_noplan_skT.
Print Assumptions m38_eqdead_g1_skT.
Print Assumptions m38_eqdead_g0_skT.
Print Assumptions m38_diffdead_skT.
Print Assumptions m38_anchors_skT.
Print Assumptions m38_forced_9.
Print Assumptions m38_forced_10.
Print Assumptions m38_clash_skT.
Print Assumptions m38_clash_self.
Print Assumptions m38_clash_skU.
Print Assumptions m38_anchors_skD.
Print Assumptions m38_clash_skD.
Print Assumptions m38_clash_learn_skT.
Print Assumptions m38_clash_learn_skD.
Print Assumptions m38_dplan_skT.
Print Assumptions m38_dplltrials_skT.
Print Assumptions m38_notrials_skT.
Print Assumptions m38_convtrials_skT.
Print Assumptions m38_path_descent.
Print Assumptions m38_deadbranch_skJ.
Print Assumptions m38_learn_conserve_skJ.
Print Assumptions m38_len_skJ.
Print Assumptions m38_eqbranch_skD_exists.
Print Assumptions m38_dplltrials_skD.
Print Assumptions m38_notrials_skD.
Print Assumptions m38_dplan_skD.
Print Assumptions m38_witness_skT.
Print Assumptions m38_witness_skD.
Print Assumptions m38_witness_skJ.
Print Assumptions m38_witness_value_skT.
Print Assumptions m38_flow_skI.
Print Assumptions m38_flow_skD.
Print Assumptions m38_flow_skT.
Print Assumptions m38_flow_skJ.
Print Assumptions m38_flow_skS.
Print Assumptions m38_ftt_skI.
Print Assumptions m38_ftt_skD.
Print Assumptions m38_ftt_skT.
Print Assumptions m38_dflow_skT.
Print Assumptions m38_parts2_len.
Print Assumptions m38_parts3_len.
Print Assumptions m38_parts3_blocks.
Print Assumptions m38_stack_roundtrip.
Print Assumptions m38_learn_stack.
Print Assumptions m38_pop_restore.
Print Assumptions flow_total_two.
Print Assumptions flow_total_arith_two.
Print Assumptions flow_total_arith_three.
Print Assumptions parts2_flow.
Print Assumptions parts3_flow.
Print Assumptions learn_subplan.
Print Assumptions dpll_witness.
Print Assumptions push_pop_restore.
Print Assumptions anchor_local.
Print Assumptions noether_dpll_duality.
Print Assumptions flow_total_duality.

(* ===================================================================== *)
(*  效应能力流形 · W-M3-3 · Xcone：安排枚举的实例锥（锥上升）               *)
(*                                                                         *)
(*  E.51 轮挂账 W-M3-3 第一组分的清偿模块：                                  *)
(*    X 主解空窗的出口——特化（安排）问题在此切片的真实结构                  *)
(*    不是 DPLL(T) 的 case-split 世界，而是**实例锥上的贪心上升**。          *)
(*                                                                         *)
(*  三条基石引理（全部载荷无关——无需新鲜性、无需 occurs 检查、              *)
(*  无需重跑合一）：                                                        *)
(*    tapply_app          组合语义：tapply (s ++ t) u = tapply t (tapply s u) *)
(*    instance_sound      实例锥封闭：合一器的实例仍是合一器                 *)
(*                          （τ 面不拒绝任何特化——锥上升免回溯的根）        *)
(*    roccurs_tsubst1_intro 单步现形引入：变量在项中 ⇒ 特化使区域落位        *)
(*                                                                         *)
(*  上升器：xpick（首违 X 约束 × 首个活变量）+ xascend（贪心循环）           *)
(*    spoint r x = [x ↦ &r x]  自返载荷——变量经特化仍活，锥永不死路          *)
(*                                                                         *)
(*  主定理：                                                                *)
(*    xascend_xsat      终止 + 完备（xcount 严格降——贪心无回溯）             *)
(*    xascend_unifies   上升全程保持 τ 解（锥成员资格）                       *)
(*    xpick_none        无首违 ⇒ 全满足（ty 无基常量：tvars 恒非空）         *)
(* ===================================================================== *)

Require Import List Lia PeanoNat Bool.
Import ListNotations.
Require Import Mult Cap Syntax CG Tau TyCG Lphi Fusion Mu Xsub M3Fusion
               Rsat Hsat Solve3.

Local Open Scope bool_scope.

(* ================= 一、组合语义：tapply 的拼接律 ================= *)

(* 拼接组合：左侧代换先作用、右侧后作用（head-first 语义的推论） *)
Lemma tapply_app : forall s t u, tapply (s ++ t) u = tapply t (tapply s u).
Proof.
  induction s as [|[x tx] s IH]; intros t u; simpl.
  - reflexivity.
  - apply IH.
Qed.

(* ================= 二、实例锥：合一器的封闭性 ================= *)

(* 实例锥封闭：s 合一 E ⇒ s ++ t 合一 E（任意 t）。
   τ 解空间 = mgu 的实例锥——锥上升的"免回溯根"：
   任何特化都不会被 τ 面拒绝（不需要重跑 unify）。 *)
Theorem instance_sound : forall s t E,
  unifies s E -> unifies (s ++ t) E.
Proof.
  intros s t E. induction E as [|[u v] E IH]; intros H; simpl.
  - exact I.
  - destruct H as [H1 H2]. split.
    + rewrite !tapply_app, H1. reflexivity.
    + apply IH. exact H2.
Qed.

(* ================= 三、语法事实：ty 无基常量 ================= *)

(* 每个类型项恒含变量（TVar 是唯一的叶子）——锥永不死路的语法根 *)
Lemma tvars_nonempty : forall t, exists x, In x (tvars t).
Proof.
  induction t as [x | a IHa b IHb | r a IHa].
  - exists x. left. reflexivity.
  - destruct IHa as [x Hx]. exists x. apply in_or_app. left. exact Hx.
  - destruct IHa as [x Hx]. exists x. exact Hx.
Qed.

(* ================= 四、特化点与单步现形引入 ================= *)

(* 特化点：x ↦ &r x（自返载荷——特化后 x 仍活，后续约束可继续经它生长） *)
Definition spoint (r x : nat) : tsubst := [(x, TBorrow r (TVar x))].

(* 单步现形引入：x 出现于 u ⇒ 把 x 绑到 &r q 使 r 在 u 的像中落位。
   载荷 q 任意——正确性不需要新鲜性。 *)
Lemma roccurs_tsubst1_intro : forall u x r q,
  In x (tvars u) -> roccurs r (tsubst1 x (TBorrow r q) u) = true.
Proof.
  induction u as [y | a IHa b IHb | r' a IHa]; intros x r q Hin; simpl in *.
  - destruct Hin as [Hy | []]. subst y.
    simpl. rewrite Nat.eqb_refl. simpl. rewrite Nat.eqb_refl. reflexivity.
  - apply in_app_or in Hin. destruct Hin as [Ha | Hb].
    + simpl. rewrite (IHa x r q Ha). reflexivity.
    + simpl. rewrite (IHb x r q Hb). apply orb_r.
  - simpl. rewrite (IHa x r q Hin). apply orb_r.
Qed.

(* ================= 五、上升的单调性：已满足不灭 ================= *)

(* 单调步：s 已满足的 X 约束，s ++ b 仍满足（现形只增不减） *)
Lemma xsat1_app_mono : forall s b c,
  xsat1 s c = true -> xsat1 (s ++ b) c = true.
Proof.
  intros s b c H.
  destruct c as [a1 a2 | r1 r2 | c0 k | c1 c2 w | l r | l | r t];
    try reflexivity.
  unfold xsat1 in *.
  rewrite tapply_app. apply roccurs_tapply_mono. exact H.
Qed.

Lemma xsatb_app_mono : forall s b cs,
  xsatb s cs = true -> xsatb (s ++ b) cs = true.
Proof.
  intros s b cs H. unfold xsatb in *.
  rewrite forallb_forall in H. rewrite forallb_forall.
  intros c Hc. destruct (xsat1 s c) eqn:E.
  - exact (xsat1_app_mono s b c E).
  - rewrite (H c Hc) in E. discriminate.
Qed.

(* ================= 六、首违选择器 xpick ================= *)

(* 首违 X 约束 × 首个活变量（确定性——无选择分支） *)
Fixpoint xpick (s : tsubst) (cs : list constr) : option (nat * nat) :=
  match cs with
  | [] => None
  | CXr r t :: cs' =>
      if roccurs r (tapply s t)
      then xpick s cs'
      else match tvars (tapply s t) with
           | [] => xpick s cs'
           | x :: _ => Some (r, x)
           end
  | _ :: cs' => xpick s cs'
  end.

(* 选择器的规范：命中 ⇒ 目标约束在池中、未满足、且变量活 *)
Lemma xpick_spec : forall cs s r x,
  xpick s cs = Some (r, x) ->
  exists t, In (CXr r t) cs /\ roccurs r (tapply s t) = false
            /\ In x (tvars (tapply s t)).
Proof.
  induction cs as [|[a b | r1 r2 | c k | c1 c2 w | l r0 | l | r0 t] cs IH];
    intros s r x H; simpl in H; try discriminate.
  - (* CTy *) destruct (IH s r x H) as [t' [Hin [Hf Hx]]].
    exists t'. split; [right; exact Hin | split; [exact Hf | exact Hx]].
  - (* CRg *) destruct (IH s r x H) as [t' [Hin [Hf Hx]]].
    exists t'. split; [right; exact Hin | split; [exact Hf | exact Hx]].
  - (* CLv *) destruct (IH s r x H) as [t' [Hin [Hf Hx]]].
    exists t'. split; [right; exact Hin | split; [exact Hf | exact Hx]].
  - (* CPr *) destruct (IH s r x H) as [t' [Hin [Hf Hx]]].
    exists t'. split; [right; exact Hin | split; [exact Hf | exact Hx]].
  - (* CHr *) destruct (IH s r x H) as [t' [Hin [Hf Hx]]].
    exists t'. split; [right; exact Hin | split; [exact Hf | exact Hx]].
  - (* CEnd *) destruct (IH s r x H) as [t' [Hin [Hf Hx]]].
    exists t'. split; [right; exact Hin | split; [exact Hf | exact Hx]].
  - (* CXr —— 首违选择器的目标分支 *)
    destruct (roccurs r0 (tapply s t)) eqn:E.
    + destruct (IH s r x H) as [t' [Hin [Hf Hx]]].
      exists t'. split; [right; exact Hin | split; [exact Hf | exact Hx]].
    + destruct (tvars (tapply s t)) as [|y ys] eqn:Ev.
      * destruct (IH s r x H) as [t' [Hin [Hf Hx]]].
        exists t'. split; [right; exact Hin | split; [exact Hf | exact Hx]].
      * injection H as Hr Hx. subst r0 y.
        exists t. split; [left; reflexivity | split; [exact E |]].
        rewrite Ev. left. reflexivity.
Qed.

(* 无首违 ⇒ 全满足（ty 无基常量 ⇒ 未满足约束恒有活变量） *)
Lemma xsatb_cons : forall s c cs,
  xsat1 s c = true -> xsatb s (c :: cs) = xsatb s cs.
Proof. intros s c cs H. simpl. rewrite H. reflexivity. Qed.

Lemma xpick_none : forall cs s, xpick s cs = None -> xsatb s cs = true.
Proof.
  induction cs as [|[a b | r1 r2 | c k | c1 c2 w | l r0 | l | r0 t] cs IH];
    intros s H.
  - reflexivity.
  - (* CTy *) unfold xsatb. simpl. apply IH. exact H.
  - (* CRg *) unfold xsatb. simpl. apply IH. exact H.
  - (* CLv *) unfold xsatb. simpl. apply IH. exact H.
  - (* CPr *) unfold xsatb. simpl. apply IH. exact H.
  - (* CHr *) unfold xsatb. simpl. apply IH. exact H.
  - (* CEnd *) unfold xsatb. simpl. apply IH. exact H.
  - (* CXr —— ty 无基常量：未满足必有活变量 *)
    simpl in H.
    destruct (roccurs r0 (tapply s t)) eqn:E.
    + unfold xsatb. simpl. rewrite E. simpl. apply IH. exact H.
    + destruct (tvars (tapply s t)) as [|y ys] eqn:Ev.
      * exfalso. destruct (tvars_nonempty (tapply s t)) as [z Hz].
        rewrite Ev in Hz. destruct Hz.
      * discriminate.
Qed.

(* ================= 七、未满足计数与严格下降 ================= *)

Definition xcount (s : tsubst) (cs : list constr) : nat :=
  length (filter (fun c => negb (xsat1 s c)) cs).

Lemma filter_len_le : forall (A : Type) (f : A -> bool) (l : list A),
  length (filter f l) <= length l.
Proof.
  intros A f l. induction l as [|a l IH]; simpl; [lia|].
  destruct (f a); simpl; lia.
Qed.

Lemma xcount_le : forall cs s, xcount s cs <= length cs.
Proof. intros cs s. unfold xcount. apply filter_len_le. Qed.

Lemma filter_mono_len_le : forall (f g : constr -> bool) (l : list constr),
  (forall c, In c l -> g c = true -> f c = true) ->
  length (filter g l) <= length (filter f l).
Proof.
  intros f g l. induction l as [|c l IH]; intros Hmono; simpl; [lia|].
  assert (Hmono' : forall c', In c' l -> g c' = true -> f c' = true).
  { intros c' Hc' Hg. apply Hmono. right. exact Hc'. exact Hg. }
  destruct (f c) eqn:Ef; destruct (g c) eqn:Eg; simpl.
  - specialize (IH Hmono'). lia.
  - specialize (IH Hmono'). lia.
  - assert (f c = true) by (apply Hmono; [left; reflexivity | exact Eg]).
    rewrite Ef in H. discriminate.
  - specialize (IH Hmono'). lia.
Qed.

(* 点式单调 + 失一元素 ⇒ 严格变短 *)
Lemma filter_mono_len_lt : forall (f g : constr -> bool) (l : list constr),
  (forall c, In c l -> g c = true -> f c = true) ->
  (exists c0, In c0 l /\ f c0 = true /\ g c0 = false) ->
  length (filter g l) < length (filter f l).
Proof.
  intros f g l Hmono.
  induction l as [|c l IH]; intros [c0 [Hin [Hf Hg]]].
  - destruct Hin.
  - assert (Hmono' : forall c', In c' l -> g c' = true -> f c' = true).
    { intros c' Hc' Hg'. apply Hmono. right. exact Hc'. exact Hg'. }
    destruct Hin as [He | Hin].
    + subst c. simpl. rewrite Hg, Hf. simpl.
      pose proof (filter_mono_len_le f g l Hmono'). lia.
    + (* 尾定位：按头元素在两谓词上的取值四分 *)
      simpl. destruct (g c) eqn:Eg; destruct (f c) eqn:Ef; simpl.
      * (* g c = true, f c = true：两侧同增 *)
        specialize (IH Hmono' (ex_intro _ c0 (conj Hin (conj Hf Hg)))). lia.
      * (* g c = true, f c = false：违反点式单调 *)
        exfalso. rewrite (Hmono c (or_introl eq_refl) Eg) in Ef. discriminate.
      * (* g c = false, f c = true：仅右增 *)
        pose proof (filter_mono_len_le f g l Hmono').
        specialize (IH Hmono' (ex_intro _ c0 (conj Hin (conj Hf Hg)))). lia.
      * (* g c = false, f c = false：两侧同不增 *)
        specialize (IH Hmono' (ex_intro _ c0 (conj Hin (conj Hf Hg)))). lia.
Qed.

(* 特化点的单步计算形态 *)
Lemma tapply_spoint : forall r x u,
  tapply (spoint r x) u = tsubst1 x (TBorrow r (TVar x)) u.
Proof. reflexivity. Qed.

(* 单步上升：目标落位、其余不灭 ⇒ 未满足计数严格降 *)
Lemma xcount_step_lt : forall cs s r x,
  xpick s cs = Some (r, x) ->
  xcount (s ++ spoint r x) cs < xcount s cs.
Proof.
  intros cs s r x Hp.
  destruct (xpick_spec cs s r x Hp) as [t [Hin [Hf Hx]]].
  unfold xcount. apply filter_mono_len_lt.
  - intros c Hc Hg.
    destruct (xsat1 s c) eqn:E.
    + rewrite (xsat1_app_mono s (spoint r x) c E) in Hg. simpl in Hg.
      discriminate.
    + reflexivity.
  - exists (CXr r t). split; [exact Hin | split].
    + unfold xsat1. rewrite Hf. reflexivity.
    + unfold xsat1. rewrite tapply_app, tapply_spoint.
      rewrite (roccurs_tsubst1_intro (tapply s t) x r (TVar x) Hx).
      reflexivity.
Qed.

(* ================= 八、贪心上升器 xascend ================= *)

Fixpoint xascend (s : tsubst) (cs : list constr) (n : nat) {struct n} : tsubst :=
  match n with
  | 0 => s
  | S n' =>
      match xpick s cs with
      | None => s
      | Some (r, x) => xascend (s ++ spoint r x) cs n'
      end
  end.

(* 上升的锥形态：结果 = 起点 ⊕ 特化点链 *)
Lemma xascend_app : forall n cs s, exists t, xascend s cs n = s ++ t.
Proof.
  induction n as [|n IH]; intros cs s.
  - exists []. simpl. rewrite app_nil_r. reflexivity.
  - simpl. destruct (xpick s cs) as [[r x] |] eqn:E.
    + destruct (IH cs (s ++ spoint r x)) as [t Ht].
      exists (spoint r x ++ t). rewrite Ht, app_assoc. reflexivity.
    + exists []. rewrite app_nil_r. reflexivity.
Qed.

(* 上升全程保持 τ 解（锥成员资格） *)
Theorem xascend_unifies : forall n cs s E,
  unifies s E -> unifies (xascend s cs n) E.
Proof.
  intros n cs s E H. destruct (xascend_app n cs s) as [t Ht].
  rewrite Ht. apply instance_sound. exact H.
Qed.

(* 主定理一：终止 + 完备——n ≥ 起点未满足数 ⇒ 上升终点全满足 *)
Theorem xascend_xsat : forall n cs s,
  xcount s cs <= n -> xsatb (xascend s cs n) cs = true.
Proof.
  induction n as [|n IH]; intros cs s Hn.
  - (* n = 0：xcount = 0 ⇒ 无未满足 ⇒ s 已全满足 *)
    assert (Hall : xsatb s cs = true).
    { unfold xsatb. rewrite forallb_forall. intros c Hc.
      destruct (xsat1 s c) eqn:E; [reflexivity|].
      exfalso.
      assert (Hin : In c (filter (fun c0 => negb (xsat1 s c0)) cs)).
      { apply filter_In. split; [exact Hc | rewrite E; reflexivity]. }
      unfold xcount in Hn.
      destruct (filter (fun c0 => negb (xsat1 s c0)) cs) as [|a l] eqn:Ef.
      - destruct Hin.
      - simpl in Hn. lia. }
    simpl. exact Hall.
  - simpl. destruct (xpick s cs) as [[r x] |] eqn:E.
    + apply IH.
      pose proof (xcount_step_lt cs s r x E). lia.
    + apply xpick_none. exact E.
Qed.


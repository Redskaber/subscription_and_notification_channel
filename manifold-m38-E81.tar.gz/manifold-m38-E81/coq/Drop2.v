(* ===================================================================== *)
(*  效应能力流形 · W-M3-3 · Drop2：dropck 严格性档 2（strictly outlives）   *)
(*                                                                         *)
(*  E.51 轮挂账 W-M3-3 第二组分的清偿模块：                                  *)
(*    H 义务从档 1（存在性挂靠——E.51 hsat）升格为档 2（严格挂靠）。           *)
(*                                                                         *)
(*  档 2 语义（RFC 769/1238 的 "generics must strictly outlive"）：          *)
(*    hle2 cs l r0 := ∃r'. hle cs l r' ∧ r' ≠ r0                            *)
(*      —— 租约 l 的挂靠必须严格长于其出生区域 r₀（每个种子各答一次）        *)
(*    hsat2 cs := ∀l ∈ ends. (∃r. hle l r)                                  *)
(*                       ∧ (∀r₀ ∈ seeds l. hle2 l r₀)                        *)
(*      —— 第一合取支 = 档 1（孤儿仍阻塞——档 2 严格强于档 1）                *)
(*                                                                         *)
(*  判定器（hsat2b）：非凸不等式安排在此切片的完备退化形——                   *)
(*    有限见证枚举：不等式安排的候选域 = hclose cs（有限闭包——             *)
(*    R 供给 H 的数据流边不变，改的是查询面）。                               *)
(*                                                                         *)
(*  豁免接口（hsat2e，RFC 1327 may_dangle 形态）：点名租约免严格支——         *)
(*    豁免只放大通过集（weakening），语义可靠性是外部信任边界（如实登记）。   *)
(*                                                                         *)
(*  定理组：                                                                *)
(*    hsat2b_correct   判定器与语义一致                                       *)
(*    hsat2_implies_hsat 档 2 ⊃ 档 1（子包含）                              *)
(*    hstrict_via_lift 严格性可经 R 提升供给（挂靠上移的严格版）             *)
(*    hsat2_xapply_invar 档 2 对 τ 代换盲（盲性矩阵的 H₂ 行）               *)
(*    hsat2e_correct / hsat2e_weaken 豁免接口的正确性与弱化方向             *)
(* ===================================================================== *)

Require Import List Lia PeanoNat Bool.
Import ListNotations.
Require Import Mult Cap Syntax CG Tau Xsub Rsat Hsat.

Local Open Scope bool_scope.

(* ================= 一、档 2 语义 ================= *)

(* 严格挂靠：租约 l 的某挂靠严格异于 r₀ *)
Definition hle2 (cs : list constr) (l r0 : nat) : Prop :=
  exists r', hle cs l r' /\ r' <> r0.

(* 档 2 满足：每个终点观测（i）有挂靠（档 1 支）且
   （ii）对其每个出生区域都有严格挂靠（严格支） *)
Definition hsat2 (cs : list constr) : Prop :=
  forall l, In (CEnd l) cs ->
  (exists r, hle cs l r) /\
  (forall r0, In (CHr l r0) cs -> exists r', hle cs l r' /\ r' <> r0).

(* ================= 二、判定器（有限见证枚举） ================= *)

(* 存在性挂靠的布尔化（hclose 为完备见证域） *)
Definition hle_b (cs : list constr) (l : nat) : bool :=
  existsb (fun lr => Nat.eqb (fst lr) l) (hclose cs).

Lemma hle_b_correct : forall cs l,
  hle_b cs l = true <-> exists r, hle cs l r.
Proof.
  intros cs l. unfold hle_b. rewrite existsb_exists. split.
  - intros [lr [Hin Heq]]. destruct lr as [l' r]. simpl in Heq.
    apply Nat.eqb_eq in Heq. subst l'.
    exists r. exact (hclose_sound cs l r Hin).
  - intros [r Hhle].
    exists (l, r). split.
    + apply hclose_complete. exact Hhle.
    + simpl. rewrite Nat.eqb_refl. reflexivity.
Qed.

(* 严格挂靠的布尔化：见证域同 hclose，查询面加 disequality *)
Definition hstrict_b (cs : list constr) (l r0 : nat) : bool :=
  existsb (fun lr => andb (Nat.eqb (fst lr) l) (negb (Nat.eqb (snd lr) r0)))
          (hclose cs).

Lemma hstrict_b_correct : forall cs l r0,
  hstrict_b cs l r0 = true <-> hle2 cs l r0.
Proof.
  intros cs l r0. unfold hstrict_b, hle2. rewrite existsb_exists. split.
  - intros [lr [Hin Hb]]. destruct lr as [l' r]. simpl in Hb.
    apply andb_true_iff in Hb. destruct Hb as [Hl Hne].
    apply Nat.eqb_eq in Hl.
    apply negb_true_iff in Hne. apply Nat.eqb_neq in Hne. subst l'.
    exists r. split; [exact (hclose_sound cs l r Hin) | exact Hne].
  - intros [r [Hhle Hne]].
    exists (l, r). split.
    + apply hclose_complete. exact Hhle.
    + simpl. rewrite Nat.eqb_refl. apply negb_true_iff.
      apply Nat.eqb_neq. exact Hne.
Qed.

(* 档 2 判定器总装：逐 CEnd ×（档 1 支 ∧ 逐种子严格支） *)
Definition hsat2b (cs : list constr) : bool :=
  forallb (fun l =>
    andb (hle_b cs l)
         (forallb (fun c => match c with
                            | CHr l' r0 => if Nat.eqb l l' then hstrict_b cs l r0
                                           else true
                            | _ => true
                            end) cs))
         (ends cs).

Theorem hsat2b_correct : forall cs, hsat2b cs = true <-> hsat2 cs.
Proof.
  intros cs. unfold hsat2b. rewrite forallb_forall. split.
  - intros Hall l Hl.
    apply (proj2 (ends_in cs l)) in Hl.
    specialize (Hall l Hl). apply andb_true_iff in Hall.
    destruct Hall as [H1 H2]. split.
    + apply (proj1 (hle_b_correct cs l)). exact H1.
    + intros r0 Hr0. rewrite forallb_forall in H2.
      specialize (H2 (CHr l r0) Hr0). simpl in H2.
      rewrite Nat.eqb_refl in H2.
      exact (proj1 (hstrict_b_correct cs l r0) H2).
  - intros Hsat l Hl.
    apply (proj1 (ends_in cs l)) in Hl.
    destruct (Hsat l Hl) as [H1 H2]. apply andb_true_iff. split.
    + apply (proj2 (hle_b_correct cs l)). exact H1.
    + rewrite forallb_forall. intros c Hc.
      destruct c as [a b | r1 r2 | c0 k | c1 c2 w | l0 r0 | l0 | r0 t];
        try reflexivity.
      destruct (Nat.eqb l l0) eqn:Ee.
      * apply Nat.eqb_eq in Ee. subst l0.
        apply (proj2 (hstrict_b_correct cs l r0)). apply H2. exact Hc.
      * reflexivity.
Qed.

(* ================= 三、档位关系 ================= *)

(* 档 2 严格强于档 1：第一合取支即档 1（孤儿租约在档 2 下仍阻塞） *)
Theorem hsat2_implies_hsat : forall cs, hsat2 cs -> hsat cs.
Proof.
  intros cs H l Hl. destruct (H l Hl) as [[r Hh] _].
  exists r. exact Hh.
Qed.

(* 严格性可经 R 提升：种子在 r₀、R 边 r₀ → r₁（r₁ ≠ r₀）⇒ 严格支满足 *)
Theorem hstrict_via_lift : forall cs l r0 r1,
  In (CHr l r0) cs -> In (CRg r0 r1) cs -> r1 <> r0 -> hle2 cs l r0.
Proof.
  intros cs l r0 r1 Hseed Hedge Hne.
  exists r1. split.
  - exists r0. split; [exact Hseed | apply rle_edge; exact Hedge].
  - exact Hne.
Qed.

(* ================= 四、盲性守恒（H₂ 行） ================= *)

(* hle 对现形不变（种子刚性 + rle 刚性） *)
Lemma hle_xapply_invar : forall s cs l r,
  hle (xapply s cs) l r <-> hle cs l r.
Proof.
  intros s cs l r. unfold hle. split.
  - intros [r0 [Hseed Hreach]]. exists r0. split.
    + apply (proj1 (in_chr_xapply s cs l r0)). exact Hseed.
    + apply (proj1 (rle_xapply_invar s cs r0 r)). exact Hreach.
  - intros [r0 [Hseed Hreach]]. exists r0. split.
    + apply (proj2 (in_chr_xapply s cs l r0)). exact Hseed.
    + apply (proj2 (rle_xapply_invar s cs r0 r)). exact Hreach.
Qed.

(* 档 2 对 τ 代换盲：现形不移动严格义务面 *)
Theorem hsat2_xapply_invar : forall s cs,
  hsat2 (xapply s cs) <-> hsat2 cs.
Proof.
  intros s cs. split; intros H l Hl.
  - destruct (H l (proj2 (in_cend_xapply s cs l) Hl)) as [[r Hh] Hst].
    split.
    + exists r. apply (proj1 (hle_xapply_invar s cs l r)). exact Hh.
    + intros r0 Hr0. destruct (Hst r0 (proj2 (in_chr_xapply s cs l r0) Hr0))
        as [r' [Hh' Hne]].
      exists r'. split.
      * apply (proj1 (hle_xapply_invar s cs l r')). exact Hh'.
      * exact Hne.
  - destruct (H l (proj1 (in_cend_xapply s cs l) Hl)) as [[r Hh] Hst].
    split.
    + exists r. apply (proj2 (hle_xapply_invar s cs l r)). exact Hh.
    + intros r0 Hr0. destruct (Hst r0 (proj1 (in_chr_xapply s cs l r0) Hr0))
        as [r' [Hh' Hne]].
      exists r'. split.
      * apply (proj2 (hle_xapply_invar s cs l r')). exact Hh'.
      * exact Hne.
Qed.

(* ================= 五、豁免接口（RFC 1327 may_dangle 形态） ================= *)

(* 点名豁免：豁免集 X 中的租约免严格支（档 1 支仍需通过） *)
Definition hsat2e (cs : list constr) (X : list nat) : Prop :=
  forall l, In (CEnd l) cs ->
  In l X \/
  ((exists r, hle cs l r) /\
   (forall r0, In (CHr l r0) cs -> exists r', hle cs l r' /\ r' <> r0)).

(* 豁免的弱化方向：档 2 ⇒ 豁免档（通过集只放大——unsafe 契约的机内形态） *)
Theorem hsat2e_weaken : forall cs X, hsat2 cs -> hsat2e cs X.
Proof. intros cs X H l Hl. right. exact (H l Hl). Qed.

Definition hsat2eb (cs : list constr) (X : list nat) : bool :=
  forallb (fun l => existsb (Nat.eqb l) X ||
                    (hle_b cs l &&
                     forallb (fun c => match c with
                                       | CHr l' r0 =>
                                           if Nat.eqb l l'
                                           then hstrict_b cs l r0 else true
                                       | _ => true
                                       end) cs))
         (ends cs).

Theorem hsat2eb_correct : forall cs X, hsat2eb cs X = true <-> hsat2e cs X.
Proof.
  intros cs X. unfold hsat2eb. rewrite forallb_forall. split.
  - intros Hall l Hl.
    apply (proj2 (ends_in cs l)) in Hl.
    specialize (Hall l Hl).
    apply orb_true_iff in Hall. destruct Hall as [Hex | Hand].
    + left. rewrite existsb_exists in Hex.
      destruct Hex as [x [Hx Heq]]. apply Nat.eqb_eq in Heq. subst x. exact Hx.
    + right. apply andb_true_iff in Hand. destruct Hand as [H1 H2].
      split.
      * apply (proj1 (hle_b_correct cs l)). exact H1.
      * intros r0 Hr0. rewrite forallb_forall in H2.
        specialize (H2 (CHr l r0) Hr0). simpl in H2.
        rewrite Nat.eqb_refl in H2.
        exact (proj1 (hstrict_b_correct cs l r0) H2).
  - intros Hsat l Hl.
    apply (proj1 (ends_in cs l)) in Hl.
    destruct (Hsat l Hl) as [Hex | [[r Hh] Hst]].
    + apply orb_true_iff. left. rewrite existsb_exists.
      exists l. split; [exact Hex | rewrite Nat.eqb_refl; reflexivity].
    + apply orb_true_iff. right. apply andb_true_iff. split.
      * apply (proj2 (hle_b_correct cs l)). exists r. exact Hh.
      * rewrite forallb_forall. intros c Hc.
        destruct c as [a b | r1 r2 | c0 k | c1 c2 w | l0 r0 | l0 | r0 t];
          try reflexivity.
        destruct (Nat.eqb l l0) eqn:Ee.
        -- apply Nat.eqb_eq in Ee. subst l0.
           apply (proj2 (hstrict_b_correct cs l r0)). apply Hst. exact Hc.
        -- reflexivity.
Qed.

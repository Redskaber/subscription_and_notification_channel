(* ===================================================================== *)
(*  Example.v —— 具体实例：e0 的约束生成、五通道分割、Kleene 迭代迹        *)
(*                                                                         *)
(*  实例 e0 = Call (Grant (CLea 1) 1 (Var 0)) (Borrow 0 1)                 *)
(*  剧本：trait 早解授出（Grant）⊕ 独占租约（Borrow）⊕ 调用传播（Call）     *)
(*  φ 通道 Kleene 迹（probe = [CReg 0; CLea 1; CReg 5]）：                *)
(*    κ0 = [0; 0; 0]   κ1 = [1; 1; 0]   κ2 = [ω; 1; 0]   κ3 = κ2          *)
(*  饱和事件：κ1 → κ2 时 CReg 0 经 1 ⊕ 1 = ω 升至 ω；                      *)
(*  观测稳定步 N = 2 ≤ 2·|caps| + 1 = 9（定理界的实例验证）。              *)
(* ===================================================================== *)

Require Import List Lia PeanoNat.
Import ListNotations.
Require Import Mult Cap Syntax CG.

Definition e0 : tm := Call (Grant (CLea 1) M1 (Var 0)) (Borrow 0 1).

(* ---- 规模与全性（sized recursion 落地） ---- *)
Example e0_size : tsize e0 = 4.
Proof. reflexivity. Qed.

Example e0_total : exists cs, cgf (tsize e0) e0 = Some cs /\ cg e0 = cs.
Proof. apply cg_total. Qed.

(* 燃料不足则失败；燃料充分则与燃料无关（守恒量 #3 的可观测面） *)
Example e0_fuel_min : cgf 1 e0 = None.
Proof. reflexivity. Qed.

Example e0_fuel_stable : cgf 4 e0 = cgf 100 e0.
Proof.
  rewrite (cgf_stable e0 4 100 ltac:(reflexivity) ltac:(lia)).
  reflexivity.
Qed.

(* ---- 约束生成结果 ---- *)
Eval compute in (cg e0).

Example e0_cg : cg e0 =
  [CLv (CLea 1) M1; CHr 1 0; CLv (CLea 1) M1;
   CXr 0 (TArrow (TVar 0) (TVar 1)); CPr (CReg 0) (CLea 1) M1].
Proof. reflexivity. Qed.

(* ---- 五通道分割（CG.6 实例化） ---- *)
Eval compute in (chanProj ChTy (cg e0)).
Eval compute in (chanProj ChR (cg e0)).
Eval compute in (chanProj ChPhi (cg e0)).
Eval compute in (chanProj ChH (cg e0)).
Eval compute in (chanProj ChX (cg e0)).

Example e0_partition : length (cg e0)
  = length (chanProj ChTy (cg e0)) + length (chanProj ChR (cg e0))
  + length (chanProj ChPhi (cg e0)) + length (chanProj ChH (cg e0))
  + length (chanProj ChX (cg e0)).
Proof. apply chan_partition. Qed.

(* ---- 规模线性守恒（CG.4 实例化） ---- *)
Example e0_linear : length (cg e0) <= 2 * tsize e0.
Proof. apply cg_size. Qed.

(* ---- φ 通道 Kleene 迭代迹 ---- *)
Definition Cph : list constr := chanProj ChPhi (cg e0).

Eval compute in (capsOf Cph).

Definition probe : list capidx := [CReg 0; CLea 1; CReg 5].

Eval compute in (map (iter (FCop Cph) 0) probe).
Eval compute in (map (iter (FCop Cph) 1) probe).
Eval compute in (map (iter (FCop Cph) 2) probe).
Eval compute in (map (iter (FCop Cph) 3) probe).

(* 饱和事件：κ1(CReg 0) = 1，κ2(CReg 0) = 1 ⊕ 1 = ω *)
Example e0_k1 : iter (FCop Cph) 1 (CReg 0) = M1.
Proof. reflexivity. Qed.

Example e0_sat_event : iter (FCop Cph) 2 (CReg 0) = MW.
Proof. reflexivity. Qed.

(* 观测稳定：κ3 = κ2，N = 2 *)
Example e0_stab : iter (FCop Cph) 2 (CReg 0) = iter (FCop Cph) 3 (CReg 0).
Proof. reflexivity. Qed.

Example e0_stab_l : iter (FCop Cph) 2 (CLea 1) = iter (FCop Cph) 3 (CLea 1).
Proof. reflexivity. Qed.

(* 定理界的实例验证：2 ≤ 2·|caps| + 1 = 9 *)
Example e0_bound : 2 <= 2 * length (capsOf Cph) + 1.
Proof. simpl. lia. Qed.

(* ---- 最小解存在性与最小性（CG.7 实例化） ---- *)
Theorem e0_min : exists l, phsat l Cph /\ (forall m, phsat m Cph -> cle l m).
Proof.
  destruct (cg_phi_min e0) as [l [H1 [H2 _]]].
  exists l. split; [exact H1 | exact H2].
Qed.

(* ---- 公理自由性验证（金标准证据） ---- *)
Print Assumptions kleene_lfp.
Print Assumptions phi_least_solution.
Print Assumptions cg_phi_min.
Print Assumptions cg_total.
Print Assumptions cg_size.
Print Assumptions chan_partition.
Print Assumptions e0_min.

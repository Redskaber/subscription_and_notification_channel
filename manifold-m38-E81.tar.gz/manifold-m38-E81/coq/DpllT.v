(* ===================================================================== *)
(*  效应能力流形 · W-DPLL-1 · DpllT：DPLL(T) 增量面（Z3 血统）              *)
(*                                                                         *)
(*  第 56 轮（#292–#301）· 文献锚 E.81（新增 E.81–E.85）                    *)
(*  清偿对象：冲突学习/理论传播/回跳（DPLL(T) 增量面——E.76 轮第九章        *)
(*  挂账 (a)；solve7 朴素逐支循环的升级；Z3 血统 E.77/E.81/E.82/E.85）。    *)
(*                                                                         *)
(*  扩展形态（正交层——tm/constr/ty 语法零改动，8 原语恒定第 56 轮）：       *)
(*    §1 一跳理论传播：锚提取（tylook 类型表 + pair_labels 同位            *)
(*        TBorrow 对）⇒ 迫值锚 forced1（值域 ⊆ grounds）⇒ 锚相克           *)
(*        clash1（迫值集非空且无公共 ⇒ 等式支静态剪除——免引擎调用）。      *)
(*        健全性边界：仅提取"真类型定义 + TVar-TVar 相遇一跳"可迫值的      *)
(*        锚（深层嵌套的多跳锚——如 skD 的 10↦0 三跳链——挂 W-DPLL-2）。    *)
(*    §2 冲突学习：学习库 learnlib = 死决策组合表；sub_dec 决策包含；       *)
(*        dpll_decisions 过滤（剪除包含死决策的支）；两级死性：            *)
(*        决策死（no_branch = []——skJ 全差异支）与引擎死                   *)
(*        （no_branch 非空但逐支 solve4 None——skD 等式支）。               *)
(*    §3 回跳/增量栈：Z3 式层栈 dstate（学习库快照 push/pop）；            *)
(*        压弹对合（push_pop_restore——查询序列对称 ⇒ 状态守恒）。          *)
(*    §4 组合循环：dpll_plan/dpll_trials/solve8（复用 arr_loop——          *)
(*        计划源替换，循环体零改动——E.76 solve7 同型）。                    *)
(*                                                                         *)
(*  诺特增量律（本轮的诺特定律设计——四定理组）：                            *)
(*    对源   anchor_local     —— 迫值锚的值域 ⊆ grounds（读数不出池）。     *)
(*    流形   learn_subplan    —— 学习只删不增：dpll_plan ⊆ no_plan         *)
(*         （学习是决策空间的重组；决策死学习不减解——skJ 8=8 实机）。      *)
(*    同调   dpll_witness     —— 增量见证必经引擎验证且在原计划空间        *)
(*         （见证同步：skT/skD/skJ 的 solve8 见证 = solve7 见证——实机）。  *)
(*    深度   push_pop_restore —— 层栈还原：压弹对合（状态守恒）；          *)
(*         传播下探：skT 路径 4 → 2（dpll_trials < no_trials——实机）。     *)
(*  正面实机（skT 一跳相克 / skD 引擎死学习 / skJ 决策死学习）             *)
(*  与 flow_total 对齐见 M38Example.v / FlowTotal.v。                       *)
(* ===================================================================== *)

Require Import List Lia PeanoNat Bool.
Import ListNotations.
Require Import Mult Cap Syntax CG Tau TyCG Lphi Fusion Mu Xsub M3Fusion
               Rsat Hsat Solve3 Xcone Drop2 Gphi Solve4
               SigLam Noether M34Example Rvar M35Example SigStack M36Example
               Ineq SibLam M37Example.

Local Open Scope bool_scope.

(* ================= 一、一跳理论传播：锚提取 ================= *)

(* 类型表查找：只认"真类型定义"方程 CTy (TVar x) t（t 非 TVar——
   TVar-TVar 是相遇方程，不是类型定义；列表序——首个命中）。 *)
Definition tylook (a : nat) (cs : list constr) : option ty :=
  match find (fun c => match c with
                       | CTy (TVar x) (TVar _) => false
                       | CTy (TVar x) _ => x =? a
                       | _ => false end) cs with
  | Some (CTy _ t) => Some t
  | _ => None
  end.

(* 同位 TBorrow 对提取：结构相同位的 (r1,r2) 标签对（r1≠r2）。
   TBorrow r1 X ≡ TBorrow r2 Y 经 τ 合一粘合 ⇒ 标签 r1、r2 粘合
   （迫值关系）；TVar 位置可实例化（无标签迫值）。 *)
Fixpoint pair_labels (t1 t2 : ty) : list (nat * nat) :=
  match t1, t2 with
  | TBorrow r1 _, TBorrow r2 _ => if r1 =? r2 then [] else [(r1, r2)]
  | TArrow a1 b1, TArrow a2 b2 => pair_labels a1 a2 ++ pair_labels b1 b2
  | _, _ => []
  end.

(* 锚扫描：相遇方程 CTy (TVar a) (TVar b) 两侧各查一层类型表，
   同位 TBorrow 对入锚表（全表参数——递归下降不失全局）。 *)
Fixpoint anchors_go (full cs : list constr) : list (nat * nat) :=
  match cs with
  | [] => []
  | CTy (TVar a) (TVar b) :: cs' =>
      match tylook a full, tylook b full with
      | Some t1, Some t2 => pair_labels t1 t2 ++ anchors_go full cs'
      | _, _ => anchors_go full cs'
      end
  | _ :: cs' => anchors_go full cs'
  end.

Definition anchors (cs : list constr) : list (nat * nat) :=
  anchors_go cs cs.

(* 迫值锚：变量 r 的静态迫值 = 锚表中 (r, g) 的地面 g
   （snd 为变量者不是迫值——是等式传播面，不入 forced1）。 *)
Definition forced1 (r : nat) (cs : list constr) : list nat :=
  map snd (filter (fun p => (fst p =? r) && negb (rvarb (snd p))) (anchors cs)).

(* 锚相克：x、y 的迫值集皆非空且无公共值 ⇒ 等式支 (x,y,=)
   静态死（同值 g 须同时满足两组迫值——矛盾）。 *)
Definition disjointb (l1 l2 : list nat) : bool :=
  forallb (fun x => negb (existsb (fun y => x =? y) l2)) l1.

Definition clash1 (cs : list constr) (x y : nat) : bool :=
  match forced1 x cs, forced1 y cs with
  | [], _ => false
  | _, [] => false
  | fx, fy => disjointb fx fy
  end.

(* 冲突学习面：锚相克 ⇒ 等式支决策入学习库（静态零引擎调用） *)
Definition clash_learn (cs : list constr) (x y : nat) : list (list dec) :=
  if clash1 cs x y then [[(x, y, true)]] else [].

(* ================= 二、冲突学习：学习库与计划过滤 ================= *)

(* 学习库：死决策组合表 *)
Definition learnlib : Type := list (list dec).

(* 决策包含：l 的每个决策（同对同极性）都在 d 中 *)
Definition dec_in (x : dec) (d : list dec) : bool :=
  existsb (fun y => (dfst y =? dfst x) && (dsnd y =? dsnd x)
                    && eqb (dbeq y) (dbeq x)) d.

Definition sub_dec (l d : list dec) : bool :=
  forallb (fun x => dec_in x d) l.

(* 学习过滤：剪除包含学习库死决策的支 *)
Definition dpll_decisions (rvs : list nat) (L : learnlib) : list (list dec) :=
  filter (fun d => negb (existsb (fun l => sub_dec l d) L))
         (no_decisions_ok rvs).

Definition dpll_plan (cs : list constr) (L : learnlib) : list rsubst :=
  flat_map (fun d => no_branch cs d) (dpll_decisions (rvars cs) L).

(* ================= 三、回跳/增量栈：Z3 式层栈 ================= *)

(* 增量求解器状态：当前学习库 + 层栈（push 时的学习库快照，顶 = 最新） *)
Record dstate : Type := mkDstate {
  dL : learnlib;
  dstack : list learnlib
}.

Definition dpush (s : dstate) : dstate :=
  mkDstate (dL s) (dL s :: dstack s).

Definition dpop (s : dstate) : dstate :=
  match dstack s with
  | [] => mkDstate [] []
  | top :: rest => mkDstate top rest
  end.

(* 层内学习：学习库增长（只增不减） *)
Definition dlearn (s : dstate) (l : list dec) : dstate :=
  mkDstate (l :: dL s) (dstack s).

(* ================= 四、组合循环（复用 arr_loop——计划源替换） ================= *)

Definition dpll_trials (fuel : nat) (cs : list constr) (L : learnlib) : nat :=
  fst (arr_loop fuel cs (dpll_plan cs L) 0).

Definition solve8 (fuel : nat) (cs : list constr) (L : learnlib)
  : option (tsubst * cmap * rsubst) :=
  snd (arr_loop fuel cs (dpll_plan cs L) 0).

(* ================= 五、工具引理 ================= *)

(* incl 传递下的 flat_map 单调 *)
Lemma flat_map_incl : forall (A B : Type) (F : A -> list B)
                              (l1 l2 : list A),
  (forall x, In x l1 -> In x l2) ->
  incl (flat_map F l1) (flat_map F l2).
Proof.
  intros A B F l1 l2 Hsub rho Hin.
  rewrite in_flat_map in Hin. destruct Hin as [x [Hx HinF]].
  apply in_flat_map. exists x. split; [apply Hsub; exact Hx | exact HinF].
Qed.

(* dedupN 的成员完全保持（双向——保留面与重现面） *)
Lemma dedupN_sound : forall l x, In x (dedupN l) -> In x l.
Proof.
  induction l as [|a l IH]; intros x Hin; simpl in *; [contradiction|].
  destruct (existsb (fun b => a =? b) (dedupN l)) eqn:E.
  - right. exact (IH x Hin).
  - destruct Hin as [Heq | Hin].
    + left. exact Heq.
    + right. exact (IH x Hin).
Qed.

(* grounds 的成员刻画：地面 ∧ 在池标签中 *)
Lemma grounds_member : forall cs g,
  In g (grounds cs) <-> (In g (allabels cs) /\ g < RV_BASE).
Proof.
  intros cs g. unfold grounds. split.
  - intros Hg. apply filter_In in Hg. destruct Hg as [Hd Hnb].
    split; [apply dedupN_sound; exact Hd |].
    unfold rvarb in Hnb. apply negb_true_iff in Hnb.
    apply Nat.leb_gt in Hnb. exact Hnb.
  - intros [Hin Hlt]. apply filter_In. split.
    + apply dedupN_In. exact Hin.
    + unfold rvarb.
      destruct (RV_BASE <=? g) eqn:E; simpl.
      * apply Nat.leb_le in E. lia.
      * reflexivity.
Qed.

(* pair_labels 的标签成员性（析取形式——结构归纳友好） *)
Lemma pair_labels_mem : forall t1 t2 p,
  In p (pair_labels t1 t2) ->
  (In (fst p) (tlabels t1) \/ In (fst p) (tlabels t2))
  /\ (In (snd p) (tlabels t1) \/ In (snd p) (tlabels t2)).
Proof.
  induction t1 as [x1 | a1 IHa1 b1 IHb1 | r1 t1' IHt1]; intros t2 p Hin.
  - simpl in Hin. contradiction.
  - destruct t2 as [x2 | a2 b2 | r2 t2']; simpl in Hin.
    + contradiction.
    + rewrite in_app_iff in Hin. destruct Hin as [Ha | Hb].
      * destruct (IHa1 a2 p Ha) as [H1 H2]. split.
        -- destruct H1 as [H1 | H1].
           ++ left. simpl. apply in_or_app. left. exact H1.
           ++ right. simpl. apply in_or_app. left. exact H1.
        -- destruct H2 as [H2 | H2].
           ++ left. simpl. apply in_or_app. left. exact H2.
           ++ right. simpl. apply in_or_app. left. exact H2.
      * destruct (IHb1 b2 p Hb) as [H1 H2]. split.
        -- destruct H1 as [H1 | H1].
           ++ left. simpl. apply in_or_app. right. exact H1.
           ++ right. simpl. apply in_or_app. right. exact H1.
        -- destruct H2 as [H2 | H2].
           ++ left. simpl. apply in_or_app. right. exact H2.
           ++ right. simpl. apply in_or_app. right. exact H2.
    + contradiction.
  - destruct t2 as [x2 | a2 b2 | r2 t2']; simpl in Hin.
    + contradiction.
    + contradiction.
    + destruct (r1 =? r2) eqn:E.
      * contradiction.
      * destruct Hin as [Heq | []]. subst p.
        cbn. split.
        -- left. left. reflexivity.
        -- right. left. reflexivity.
Qed.

(* 约束标签入全池标签 *)
Lemma clabels_allabels : forall cs c x,
  In c cs -> In x (clabels c) -> In x (allabels cs).
Proof.
  induction cs as [|c0 cs IH]; intros c x Hc Hx; simpl in *; [contradiction|].
  destruct Hc as [Heq | Hin].
  - subst c. apply in_or_app. left. exact Hx.
  - apply in_or_app. right. exact (IH c x Hin Hx).
Qed.

(* tylook 命中 ⇒ 型来自池中某真类型定义方程 *)
Lemma tylook_mem : forall a cs t,
  tylook a cs = Some t ->
  exists b, In (CTy (TVar b) t) cs /\ b = a.
Proof.
  intros a cs t H. unfold tylook in H.
  destruct (find (fun c => match c with
                           | CTy (TVar x) (TVar _) => false
                           | CTy (TVar x) _ => x =? a
                           | _ => false end) cs) as [c |] eqn:Ef.
  - apply find_some in Ef. destruct Ef as [Hin Hp].
    destruct c as [t1 t2 | r1 r2 | c1 k | c1 c2' w | l r | l | r t'];
      try discriminate H; try discriminate Hp.
    destruct t1 as [x | a1 b1 | r t1']; try discriminate Hp.
    destruct t2 as [x2 | a2 b2 | r2 t2']; try discriminate Hp.
    cbn in H.
    + injection H as Ht. subst t. apply Nat.eqb_eq in Hp. exists x.
      split; [exact Hin | exact Hp].
    + injection H as Ht. subst t. apply Nat.eqb_eq in Hp. exists x.
      split; [exact Hin | exact Hp].
  - discriminate H.
Qed.

(* anchors_go 的标签来自全池（双参数归纳——全表参数不失全局） *)
Lemma anchors_go_mem : forall full cs p,
  In p (anchors_go full cs) ->
  In (fst p) (allabels full) /\ In (snd p) (allabels full).
Proof.
  intros full cs. revert full.
  induction cs as [|c cs IH]; intros full p Hin; simpl in Hin.
  - contradiction.
  - destruct c as [t1 t2 | r1 r2 | c1 k | c1 c2' w | l r | l | r t'];
      try (apply IH; exact Hin).
    destruct t1 as [x | a1 b1 | r t1']; try (apply IH; exact Hin).
    destruct t2 as [x' | a2 b2 | r' t2']; try (apply IH; exact Hin).
    simpl. destruct (tylook x full) as [ta |] eqn:Ea;
    destruct (tylook x' full) as [tb |] eqn:Eb;
      try (apply IH; exact Hin).
    rewrite in_app_iff in Hin. destruct Hin as [Hp | Hin].
    + destruct (pair_labels_mem ta tb p Hp) as [H1 H2].
      destruct (tylook_mem x full ta Ea) as [b1 [Hc1 _]].
      destruct (tylook_mem x' full tb Eb) as [b2 [Hc2 _]].
      split.
      * destruct H1 as [H1 | H1].
        -- exact (clabels_allabels full (CTy (TVar b1) ta) (fst p) Hc1 H1).
        -- exact (clabels_allabels full (CTy (TVar b2) tb) (fst p) Hc2 H1).
      * destruct H2 as [H2 | H2].
        -- exact (clabels_allabels full (CTy (TVar b1) ta) (snd p) Hc1 H2).
        -- exact (clabels_allabels full (CTy (TVar b2) tb) (snd p) Hc2 H2).
    + apply IH; exact Hin.
Qed.

(* anchors 的标签来自池 *)
Lemma anchors_mem : forall cs p,
  In p (anchors cs) ->
  In (fst p) (allabels cs) /\ In (snd p) (allabels cs).
Proof.
  intros cs p H. unfold anchors in H.
  apply (anchors_go_mem cs cs p H).
Qed.

(* ================= 六、诺特增量律四定理组 ================= *)

(* D1. 对源：迫值锚的值域 ⊆ grounds（读数不出池） *)
Theorem anchor_local : forall cs r g,
  In g (forced1 r cs) -> In g (grounds cs).
Proof.
  intros cs r g Hin. unfold forced1 in Hin.
  rewrite in_map_iff in Hin. destruct Hin as [p [Hpg Hpin]].
  apply filter_In in Hpin. destruct Hpin as [Hpa Hfl].
  apply andb_true_iff in Hfl. destruct Hfl as [Hfr Hgr].
  subst g.
  destruct (anchors_mem cs p Hpa) as [_ Hsnd].
  apply grounds_member. split; [exact Hsnd |].
  unfold rvarb in Hgr. apply negb_true_iff in Hgr.
  apply Nat.leb_gt. exact Hgr.
Qed.

(* D2. 流形：学习只删不增（计划空间的重组） *)
Theorem learn_subplan : forall cs L,
  incl (dpll_plan cs L) (no_plan cs).
Proof.
  intros cs L. unfold dpll_plan, no_plan.
  apply flat_map_incl. intros d Hd.
  unfold dpll_decisions in Hd. apply filter_In in Hd.
  destruct Hd as [Hin _]. exact Hin.
Qed.

(* D3. 同调：增量见证必经引擎验证且在原计划空间 *)
Theorem dpll_witness : forall fuel cs L s l rho,
  solve8 fuel cs L = Some (s, l, rho) ->
  In rho (dpll_plan cs L) /\ solve4 fuel (rinstP rho cs) = Some (s, l).
Proof.
  intros fuel cs L s l rho H. unfold solve8 in H.
  apply (arr_loop_some_spec fuel cs (dpll_plan cs L) 0 s l rho H).
Qed.

(* 穷尽对偶：无活计划 ⇒ trials = 计划数 ∧ solve8 = None *)
Theorem dpll_exhaust : forall fuel cs L,
  (forall rho, In rho (dpll_plan cs L) -> solve4 fuel (rinstP rho cs) = None) ->
  dpll_trials fuel cs L = length (dpll_plan cs L) /\ solve8 fuel cs L = None.
Proof.
  intros fuel cs L Hall. unfold dpll_trials, solve8.
  rewrite (arr_loop_exhaust_spec fuel cs (dpll_plan cs L) 0 Hall).
  simpl. split; [lia | reflexivity].
Qed.

(* D4. 深度/增量栈：压弹对合（查询序列对称 ⇒ 状态守恒） *)
Theorem push_pop_restore : forall s, dpop (dpush s) = s.
Proof.
  intros [L stack]. simpl. destruct stack; reflexivity.
Qed.

(* 层内学习只增不减（学习库单调） *)
Theorem learn_monotone : forall s l,
  incl (dL s) (dL (dlearn s l)).
Proof.
  intros [L stack] l. simpl. intros x Hin.
  right. exact Hin.
Qed.

(* ================= 七、守恒形态（陈述与实机接口） ================= *)

(* 学习不减解：学习库全为决策死（no_branch = []）⇒ 计划集不变。
   完整证明需决策语义的单调性引理（死支扩展仍死——no_branch 的
   语义刻画），挂 W-DPLL-3；skJ 实机（8 = 8）见 M38Example。 *)
Theorem learn_conserve_dead :
  forall cs L,
  (forall l, In l L -> no_branch cs l = []) ->
  dpll_plan cs L = no_plan cs.
Proof.
  intros cs L. admit.
Admitted.

(* 传播即蕴涵：锚相克 ⇒ 等式支逐支引擎死（静态传播的健全性）。
   完整证明需 τ 合一通道分析（TBorrow 同位粘合 ⇒ 标签迫值），挂
   W-DPLL-2；skT 实机（等式支 2 枚举 solve4 全 None）见 M38Example。 *)
Theorem clash_sound :
  forall cs x y fuel,
  clash1 cs x y = true ->
  forall rho, In rho (no_branch cs [(x, y, true)]) ->
  solve4 fuel (rinstP rho cs) = None.
Proof.
  intros cs x y fuel. admit.
Admitted.

(* 诺特增量律对偶整合 *)
Theorem noether_dpll_duality :
  (forall cs L, incl (dpll_plan cs L) (no_plan cs))
  /\ (forall fuel cs L s l rho,
        solve8 fuel cs L = Some (s, l, rho) ->
        In rho (dpll_plan cs L) /\ solve4 fuel (rinstP rho cs) = Some (s, l))
  /\ (forall s, dpop (dpush s) = s).
Proof.
  split; [apply learn_subplan |].
  split; [apply dpll_witness | apply push_pop_restore].
Qed.

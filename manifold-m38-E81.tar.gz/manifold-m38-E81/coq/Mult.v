(* ===================================================================== *)
(*  效应能力流形 · W-LIFE-1a 余款清偿（M1：约束语法 + CG 引理组）          *)
(*  Mult.v —— 饱和多重性 rig {0,1,ω}                                      *)
(*                                                                         *)
(*  双结构（#193，§2 重定性）：                                             *)
(*    mlub —— 格并（序上确界），Kleene 逼近步专用；                          *)
(*    mplus —— 饱和加（rig 运算，1 + 1 = ω），重数传播专用。                 *)
(*  两者分离：lfp 逼近只经 mlub（保链单调），mplus 只出现在约束语义里。      *)
(*  守恒量：秩 mrank ∈ {0,1,2}，mplus/mlub 均单调（诺特定律审计见 THEORY.md） *)
(*  贡献 #192–#201 · 文献锚 E.39                                           *)
(* ===================================================================== *)

Require Import List Lia PeanoNat.
Import ListNotations.

(* 饱和多重度：M0 = 无，M1 = 线性单次，MW = ω（不限量） *)
Inductive mult : Type := M0 | M1 | MW.

Definition mult_eq_dec : forall a b : mult, {a = b} + {a <> b}.
Proof. decide equality. Defined.

(* 布尔相等：供可判定稳定谓词 mstable 使用 *)
Definition meqb (a b : mult) : bool :=
  match a, b with
  | M0, M0 | M1, M1 | MW, MW => true
  | _, _ => false
  end.

Lemma meqb_true : forall a b, meqb a b = true -> a = b.
Proof. intros a b H; destruct a, b; simpl in H; try reflexivity; discriminate. Qed.

Lemma meqb_false : forall a b, meqb a b = false -> a <> b.
Proof. intros a b H; destruct a, b; simpl in H; discriminate. Qed.

(* 秩：序结构的数值内核 —— 0 ≤ 1 ≤ ω 即 0 ≤ 1 ≤ 2 *)
Definition mrank (a : mult) : nat :=
  match a with M0 => 0 | M1 => 1 | MW => 2 end.

Lemma mrank_inj : forall a b, mrank a = mrank b -> a = b.
Proof. intros a b H; destruct a, b; simpl in H; congruence. Qed.

(* 序与严格序 *)
Definition mle (a b : mult) : Prop := mrank a <= mrank b.
Definition mlt (a b : mult) : Prop := mrank a < mrank b.

Lemma mle_refl : forall a, mle a a.
Proof. intros a; unfold mle; lia. Qed.

Lemma mle_M0 : forall a, mle M0 a.
Proof. intros a; unfold mle; simpl; lia. Qed.

Lemma mle_trans : forall a b c, mle a b -> mle b c -> mle a c.
Proof. unfold mle; intros a b c H1 H2; lia. Qed.

(* 格并：序上确界 —— Kleene 逼近步专用 *)
Definition mlub (a b : mult) : mult :=
  if Nat.leb (mrank b) (mrank a) then a else b.

(* 饱和加：rig 运算 —— 重数传播专用，规则 1 ⊕ 1 = ω *)
Definition mplus (a b : mult) : mult :=
  match a, b with
  | M0, x => x
  | x, M0 => x
  | _, _ => MW
  end.

Lemma mlub_le_l : forall a b, mle a (mlub a b).
Proof. intros a b; destruct a, b; unfold mlub, mle; simpl; lia. Qed.

Lemma mlub_le_r : forall a b, mle b (mlub a b).
Proof. intros a b; destruct a, b; unfold mlub, mle; simpl; lia. Qed.

Lemma mlub_least : forall a b c, mle a c -> mle b c -> mle (mlub a b) c.
Proof. intros a b c H1 H2; destruct a, b; unfold mlub, mle in *; simpl in *; lia. Qed.

Lemma mlub_M0_l : forall a, mlub M0 a = a.
Proof. intros a; destruct a; reflexivity. Qed.

Lemma mlub_mono : forall a b c d, mle a c -> mle b d -> mle (mlub a b) (mlub c d).
Proof.
  intros a b c d H1 H2. apply mlub_least.
  - apply mle_trans with c; [exact H1 | apply mlub_le_l].
  - apply mle_trans with d; [exact H2 | apply mlub_le_r].
Qed.

Lemma mplus_mono : forall a b w, mle a b -> mle (mplus a w) (mplus b w).
Proof. intros a b w H; destruct a, b, w; unfold mplus, mle in *; simpl in *; lia. Qed.

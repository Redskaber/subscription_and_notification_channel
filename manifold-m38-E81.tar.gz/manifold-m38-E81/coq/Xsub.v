(* ===================================================================== *)
(*  效应能力流形 · M3 · Xsub：X 通道 τ 载荷代换（W-M3-X 幽灵参数现形）     *)
(*                                                                         *)
(*  W-M2-1 §8.3 的登记：区域是 τ 合一表层的幽灵维度——unifies_dec_borrow    *)
(*  的 r 不出现在结论中，apply 无法推断必须显式给出。本轮把对偶侧补全：    *)
(*  CXr r t 的载荷 t 是 X 通道携带的 τ 对象，φ 通道对它彻底失明             *)
(*  （phC_CXr：phContrib (CXr r t) i m = M0），τ 代换 σ 却必须作用于它。    *)
(*                                                                         *)
(*  幽灵现形算子 xapply：σ 作用于一切携带 τ 的位置（CTy 两翼 + CXr 载荷）， *)
(*  其余通道刚性。三条守恒律 + 一条谱系律：                                 *)
(*    通道归属守恒  chOf_xapply1     —— 现形不迁移通道；                     *)
(*    φ 盲性        lphi_xapply_invar —— 现形不移动 φ 最小解；              *)
(*    点式现形      roccurs_tapply_split —— 区域来自地面位置或幽灵起点；     *)
(*    X 谱系单调    xsat_principal_mono —— 现形读数沿实例链只增不减。       *)
(* ===================================================================== *)

Require Import List Lia PeanoNat.
Import ListNotations.
Require Import Mult Cap Syntax CG Tau Lphi.

Local Open Scope bool_scope.

(* ---- 布尔辅助（避免 destruct 改写归纳前提的坑，见 §8 实录） ---- *)
Lemma orb_r : forall b, b || true = true.
Proof. intros [|]; reflexivity. Qed.

Lemma orb_case : forall a b, a || b = true -> a = true \/ b = true.
Proof. intros [|] [|]; simpl; tauto. Qed.

(* ================= 一、幽灵现形算子 ================= *)

(* τ 代换对单条约束的作用：一切携带 τ 的位置 *)
Definition xapply1 (s : tsubst) (c : constr) : constr :=
  match c with
  | CTy a b => CTy (tapply s a) (tapply s b)
  | CXr r t => CXr r (tapply s t)     (* 幽灵载荷现形 *)
  | _ => c                            (* 其余通道不携带 τ：刚性 *)
  end.

Definition xapply (s : tsubst) (cs : list constr) : list constr :=
  map (xapply1 s) cs.

(* ---- 守恒律 1：通道归属守恒（现形不迁移通道） ---- *)

Lemma chOf_xapply1 : forall ch s c, chOf ch (xapply1 s c) = chOf ch c.
Proof. intros ch s c. destruct c; reflexivity. Qed.

(* 投影与现形可换：filter/map 在通道谓词对现形不变时可换 *)
Lemma filter_map_xapply1 : forall ch s cs,
  filter (chOf ch) (map (xapply1 s) cs) = map (xapply1 s) (filter (chOf ch) cs).
Proof.
  intros ch s cs. induction cs as [|c cs IH]; simpl; [reflexivity|].
  rewrite (chOf_xapply1 ch s c).
  destruct (chOf ch c); simpl; [f_equal; exact IH | exact IH].
Qed.

Lemma chanProj_xapply : forall ch s cs,
  chanProj ch (xapply s cs) = xapply s (chanProj ch cs).
Proof.
  intros ch s cs. unfold chanProj, xapply. apply filter_map_xapply1.
Qed.

(* ---- 守恒律 2：φ 盲性（现形不移动 φ 世界） ---- *)

(* φ 约束是现形算子的不动点：CLv/CPr 不携带 τ *)
Lemma xapply1_phi_rigid : forall s c, chOf ChPhi c = true -> xapply1 s c = c.
Proof.
  intros s c H.
  destruct c as [a b | r1 r2 | c k | c c' w | l r | l | r t];
    simpl in H; try reflexivity; discriminate.
Qed.

Lemma xapply_chanProj_phi : forall s cs,
  xapply s (chanProj ChPhi cs) = chanProj ChPhi cs.
Proof.
  intros s cs.
  assert (Hgen : forall l, (forall c, In c l -> chOf ChPhi c = true) ->
                 map (xapply1 s) l = l).
  { intros l Hl. induction l as [|c l IH]; simpl; [reflexivity|].
    rewrite (xapply1_phi_rigid s c (Hl c (or_introl eq_refl))).
    f_equal. apply IH. intros c' Hc'. apply Hl. right. exact Hc'. }
  apply Hgen. intros c Hc. unfold chanProj in Hc.
  apply filter_In in Hc. destruct Hc as [_ Hb]. exact Hb.
Qed.

Theorem lphi_xapply_invar : forall s cs,
  lphi (chanProj ChPhi (xapply s cs)) = lphi (chanProj ChPhi cs).
Proof.
  intros s cs.
  rewrite (chanProj_xapply ChPhi s cs), (xapply_chanProj_phi s cs). reflexivity.
Qed.

(* ================= 二、现形读数与点式现形定理 ================= *)

(* 区域 r 在类型 t 中的出现（地面位置 = TBorrow 构造子标签） *)
Fixpoint roccurs (r : nat) (t : ty) : bool :=
  match t with
  | TVar _ => false
  | TArrow a b => roccurs r a || roccurs r b
  | TBorrow r' a => Nat.eqb r r' || roccurs r a
  end.

(* X 满足：σ 下每个 CXr r t 的区域 r 都在 t 的 σ-像中真实出现 *)
Definition xsat (s : tsubst) (cs : list constr) : Prop :=
  forall c, In c cs ->
  match c with
  | CXr r t => roccurs r (tapply s t) = true
  | _ => True
  end.

(* 地面区域位置在代换下不灭 *)
Lemma roccurs_tapply_mono : forall tau r t,
  roccurs r t = true -> roccurs r (tapply tau t) = true.
Proof.
  intros tau r t. induction t as [x | a IHa b IHb | r' a IHa]; intros H.
  - discriminate.
  - (* TArrow *)
    simpl in H. rewrite tapply_arrow. simpl.
    destruct (orb_case _ _ H) as [Ha | Hb].
    + rewrite (IHa Ha). reflexivity.
    + rewrite (IHb Hb). apply orb_r.
  - (* TBorrow *)
    simpl in H. rewrite tapply_borrow. simpl.
    destruct (orb_case _ _ H) as [Hr | Ha].
    + rewrite Hr. reflexivity.
    + rewrite (IHa Ha). apply orb_r.
Qed.

(* 点式现形定理：σ-像中的区域 ⇔ 地面位置 ∨ 幽灵起点（变量像） *)
Theorem roccurs_tapply_split : forall s r t,
  roccurs r (tapply s t) = true <->
  (roccurs r t = true \/
   exists x, In x (tvars t) /\ roccurs r (tapply s (TVar x)) = true).
Proof.
  intros s r t. induction t as [m | a IHa b IHb | r' a IHa].
  - (* TVar：现形完全来自变量自身——同语反复支 *)
    simpl. split.
    + intros H. right. exists m. split; [simpl; left; reflexivity | exact H].
    + intros [Hf | [x [Hin Hx]]].
      * simpl in Hf. discriminate.
      * destruct Hin as [Hxm | []]. subst x. exact Hx.
  - (* TArrow *)
    rewrite tapply_arrow. simpl. split.
    + intros H. destruct (orb_case _ _ H) as [Ha | Hb].
      * destruct (proj1 IHa Ha) as [Hl | [x [Hin Hx]]].
        -- left. simpl. rewrite Hl. reflexivity.
        -- right. exists x. simpl. split;
             [apply in_or_app; left; exact Hin | exact Hx].
      * destruct (proj1 IHb Hb) as [Hl | [x [Hin Hx]]].
        -- left. simpl. rewrite Hl. apply orb_r.
        -- right. exists x. simpl. split;
             [apply in_or_app; right; exact Hin | exact Hx].
    + intros [Hl | [x [Hin Hx]]].
      * simpl in Hl. destruct (orb_case _ _ Hl) as [Ha | Hb].
        -- rewrite (proj2 (IHa) (or_introl Ha)). reflexivity.
        -- rewrite (proj2 (IHb) (or_introl Hb)). apply orb_r.
      * simpl in Hin. apply in_app_or in Hin. destruct Hin as [Hin | Hin].
        -- rewrite (proj2 (IHa) (or_intror (ex_intro _ x (conj Hin Hx)))).
           reflexivity.
        -- rewrite (proj2 (IHb) (or_intror (ex_intro _ x (conj Hin Hx)))).
           apply orb_r.
  - (* TBorrow *)
    rewrite tapply_borrow. simpl. split.
    + intros H. destruct (orb_case _ _ H) as [Hr | Ha].
      * left. simpl. rewrite Hr. reflexivity.
      * destruct (proj1 IHa Ha) as [Hl | [x [Hin Hx]]].
        -- left. simpl. rewrite Hl. apply orb_r.
        -- right. exists x. simpl. split; [exact Hin | exact Hx].
    + intros [Hl | [x [Hin Hx]]].
      * simpl in Hl. destruct (orb_case _ _ Hl) as [Hr | Ha].
        -- rewrite Hr. reflexivity.
        -- rewrite (proj2 (IHa) (or_introl Ha)). apply orb_r.
      * rewrite (proj2 (IHa) (or_intror (ex_intro _ x (conj Hin Hx)))).
        apply orb_r.
Qed.

(* ================= 三、X 谱系方向（主解的现形读数最薄） ================= *)

(* 实例链上的现形单调：s' 是 s 经 τ 的实例 ⇒ s 的 X 读数被 s' 继承 *)
Theorem xsat_principal_mono : forall cs s s' tau,
  (forall u, tapply s' u = tapply tau (tapply s u)) ->
  xsat s cs -> xsat s' cs.
Proof.
  intros cs s s' tau Hinst Hs c Hc.
  destruct c as [a b | r1 r2 | c k | c c' w | l r | l | r t]; try exact I.
  specialize (Hs (CXr r t) Hc). simpl in Hs.
  rewrite (Hinst t). apply roccurs_tapply_mono. exact Hs.
Qed.

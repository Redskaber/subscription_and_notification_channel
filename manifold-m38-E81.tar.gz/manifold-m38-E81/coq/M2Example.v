(* ===================================================================== *)
(*  效应能力流形 · M2 · M2Example：上机实例全链路 + 零公理审计              *)
(*                                                                         *)
(*  实例清单（全部 eq_refl 核证——编译即验证）：                             *)
(*    τ 侧（λ 层并入 + MM 合一）：                                          *)
(*      tid    = λx. x        —— 主代换 α0 = α1 → α1（恒等函数）            *)
(*      tomega = λx. x x      —— occurs 检查失败（无限类型；Rust E0391      *)
(*                               "cycle detected" 的 τ 侧同族现象）        *)
(*      tflip  = λf. λx. f x  —— 主代换 (α1→α4) → α1 → α4（部分应用）       *)
(*      e0m    = Call(Grant…)(Borrow…) —— M1 实例 e0 的 M2 全链路：         *)
(*               τ 代换 + φ 最小解 {ρ0 ↦ ω, ℓ1 ↦ 1} 一次推断取出            *)
(*    φ 侧（Kleene 深链）：                                                 *)
(*      dchain —— 饱和波前逐跳传播：⊥ → [1,1,0,0] → [1,ω,1,0] →             *)
(*               [1,ω,ω,1] → [1,ω,ω,ω] → 稳定（N0 = 4 ≤ 界 17）             *)
(* ===================================================================== *)

Require Import List Lia PeanoNat.
Import ListNotations.
Require Import Mult Cap Syntax CG Tau TyCG Lphi Fusion.

(* ---- 项实例 ---- *)

Definition tid : tm := Lam 0 (Var 0).                 (* λx. x *)
Definition tomega : tm := Lam 0 (Call (Var 0) (Var 0)).   (* λx. x x *)
Definition tflip : tm := Lam 0 (Lam 1 (Call (Var 0) (Var 1))).  (* λf. λx. f x *)
Definition e0m : tm := Call (Grant (CLea 1) M1 (Var 0)) (Borrow 0 1).

(* ---- τ 侧：MM 合一（eq_refl 核证） ---- *)

(* λx. x：α0 = α1 → α2，α2 = α1 ⇒ σ = [α0 := α1→α2; α2 := α1]，*)
(* σ(α0) 经 head-first 组合归约为 α1 → α1 *)
Example ex_tid :
  unify 50 (tyEqs (fst (cgT 0 [] tid)))
  = Some [(0, TArrow (TVar 1) (TVar 2)); (2, TVar 1)].
Proof. reflexivity. Qed.

(* 主代换读数：σ(α0) = α1 → α1（恒等函数类型） *)
Example ex_tid_value :
  tapply [(0, TArrow (TVar 1) (TVar 2)); (2, TVar 1)] (TVar 0)
  = TArrow (TVar 1) (TVar 1).
Proof. reflexivity. Qed.

(* λx. x x：occurs 检查失败（ω 项，无限类型） *)
Example ex_omega :
  unify 50 (tyEqs (fst (cgT 0 [] tomega))) = None.
Proof. reflexivity. Qed.

(* λf. λx. f x：主代换（部分应用：f : α1 → α4 ⇒ 整体 (α1→α4) → α1 → α4） *)
Example ex_flip :
  unify 50 (tyEqs (fst (cgT 0 [] tflip)))
  = Some [(0, TArrow (TVar 1) (TVar 2));
          (2, TArrow (TVar 3) (TVar 4));
          (5, TArrow (TVar 6) (TVar 4));
          (3, TArrow (TVar 6) (TVar 4));
          (6, TVar 1)].
Proof. reflexivity. Qed.

(* 主代换读数：σ(α0) = (α1 → α4) → α1 → α4 *)
Example ex_flip_value :
  tapply [(0, TArrow (TVar 1) (TVar 2));
          (2, TArrow (TVar 3) (TVar 4));
          (5, TArrow (TVar 6) (TVar 4));
          (3, TArrow (TVar 6) (TVar 4));
          (6, TVar 1)] (TVar 0)
  = TArrow (TVar 1) (TArrow (TArrow (TVar 1) (TVar 4)) (TVar 4)).
Proof. reflexivity. Qed.

(* ---- e0 的 M2 全链路（τ ⊗ φ 融合推断） ---- *)

(* τ 侧：Call 的箭头等式 α1 = α3 → α0；Var 未绑定退化为平凡等式（删规则吸收） *)
Example ex_e0m_tau :
  match infer 50 e0m with
  | Some (s, _) => s
  | None => []
  end = [(1, TArrow (TVar 3) (TVar 0))].
Proof. reflexivity. Qed.

(* φ 侧：ρ0 ↦ ω（饱和事件 1⊕1=ω 的传播终点），ℓ1 ↦ 1 *)
Example ex_e0m_phi_r0 :
  match infer 50 e0m with
  | Some (_, l) => l (CReg 0)
  | None => M0
  end = MW.
Proof. reflexivity. Qed.

Example ex_e0m_phi_l1 :
  match infer 50 e0m with
  | Some (_, l) => l (CLea 1)
  | None => M0
  end = M1.
Proof. reflexivity. Qed.

(* 域外能力恒零（FC_out 的实机体现） *)
Example ex_e0m_phi_out :
  match infer 50 e0m with
  | Some (_, l) => l (CReg 9)
  | None => M0
  end = M0.
Proof. reflexivity. Qed.

(* infer 的输出确为双通道解（infer_sound 的可计算实例） *)
Example ex_e0m_sound :
  unifies [(1, TArrow (TVar 3) (TVar 0))]
          (tyEqs (fst (cgT 0 [] e0m))).
Proof. apply (unify_sound 50). reflexivity. Qed.

(* ---- φ 侧：Kleene 深链（饱和波前逐跳传播） ---- *)

(* 需求图：ℓ0 ≥ 1；ρ1 ≥ ℓ0 ⊕ 1；ρ2 ≥ ρ1；λ3 ≥ ρ2 *)
Definition dchain : list constr :=
  [CLv (CLea 0) M1;
   CPr (CReg 1) (CLea 0) M1;
   CPr (CReg 2) (CReg 1) M0;
   CPr (CLvl 3) (CReg 2) M0].

Example ex_dchain_k1 :
  map (iter (FCop dchain) 1) [CLea 0; CReg 1; CReg 2; CLvl 3] = [M1; M1; M0; M0].
Proof. reflexivity. Qed.

Example ex_dchain_k2 :
  map (iter (FCop dchain) 2) [CLea 0; CReg 1; CReg 2; CLvl 3] = [M1; MW; M1; M0].
Proof. reflexivity. Qed.

Example ex_dchain_k3 :
  map (iter (FCop dchain) 3) [CLea 0; CReg 1; CReg 2; CLvl 3] = [M1; MW; MW; M1].
Proof. reflexivity. Qed.

Example ex_dchain_k4 :
  map (iter (FCop dchain) 4) [CLea 0; CReg 1; CReg 2; CLvl 3] = [M1; MW; MW; MW].
Proof. reflexivity. Qed.

Example ex_dchain_stab :
  map (iter (FCop dchain) 5) [CLea 0; CReg 1; CReg 2; CLvl 3]
  = map (iter (FCop dchain) 4) [CLea 0; CReg 1; CReg 2; CLvl 3].
Proof. reflexivity. Qed.

(* 跑满饱和界（2·8+1 = 17）即得解且最小 *)
Example ex_dchain_sat : phsat (lphi dchain) dchain.
Proof. apply (lphi_solve dchain). Qed.

Example ex_dchain_min : forall m, phsat m dchain -> cle (lphi dchain) m.
Proof. apply (lphi_solve dchain). Qed.

(* ---- 零公理审计（主定理组；unify_complete 单列——欠条如实显示） ---- *)

Print Assumptions unify_sound.
Print Assumptions unify_fuel_mono.
Print Assumptions mm_step_measure.
Print Assumptions mm_step_Nv_le.
Print Assumptions cgT_grow.
Print Assumptions cgT_range.
Print Assumptions cgT_phi_nil.
Print Assumptions lphi_solve.
Print Assumptions cg_phi_lphi.
Print Assumptions solve2_sound.
Print Assumptions solve2_phi_min.
Print Assumptions infer_sound.
Print Assumptions tyEqs_proj.
Print Assumptions phsat_app.

(* 欠条 W-M2-1 的如实显示：预期列为公理（Admitted） *)
Print Assumptions unify_complete.

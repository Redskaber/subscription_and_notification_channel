//! The T-a switch window's step-② A/B/C artifact-pipeline tests
//! (bootstrap-completion-plan §4.3 step ②/③; w-t-a-switch-window
//! §3): the K159 fixpoint gate end-to-end, the load-bearing rows
//! the gate's meaning rests on, and the fail-closed faces.
//!
//! - **Positive** — `abc_pipeline_holds_the_k159_fixpoint_gate`: the
//!   full three passes on the six CCFs; B ≡ C byte-identical (THE
//!   gate), A ≡ B (the parity observation), the tree identity and
//!   the check differentials at every junction (the golden path —
//!   every segment of both passes rides the VM).
//! - **Negative** — the extern slot declaration is load-bearing
//!   (the bare twin source rejects at the expansion layer with the
//!   unbound key); a rejecting source never produces an artifact
//!   (fail-closed); the gate detects a divergent product (the
//!   detection-power row); an undeclared slot reference rejects on
//!   the same parity key (the CCF's declaration is the only
//!   difference).
//! - **Cross-stage consumption** — the B artifacts RUN as chain
//!   segments (the C pass's own shape, exercised on one artifact:
//!   the chain's own compilation of the lexer reads a source
//!   through the injection channel).

use kerf::driver::{
    AbcReport, TARGET_LEXER_TARGET_SOURCE, abc_pipeline, ccf_lexer_source, ccf_sources,
    compile_via, expand_via, read_via, rust_compile_ccf,
};

/// The r139 deep-stack precedent: the selfhost-scale programs need a
/// large thread stack for the host-side rebuild walks.
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(512 * 1024 * 1024)
        .spawn(body)
        .expect("deep-stack thread")
        .join()
        .expect("deep-stack join");
}

// ---------- the golden path ----------

/// The K159 gate: A (the Rust compiler) → B (the chain via A) → C
/// (the chain via B), six explicit artifacts, B ≡ C byte-identical.
/// The A ≡ B row is the parity observation — disclosed, never a
/// substitute for the gate. Expect minutes on the release profile:
/// twelve full-chain self-compilations ride the VM (the fixed-length
/// chain, the explicit artifacts — K159's own discipline).
#[test]
fn abc_pipeline_holds_the_k159_fixpoint_gate() {
    deep_stack(|| {
        let report = abc_pipeline().expect("the A/B/C pipeline completes");
        assert!(report.b_eq_c, "the K159 gate: {}", report.gate_line());
        assert!(
            report.a_eq_b,
            "the parity observation: {}",
            report.gate_line()
        );
        assert_eq!(report.a.len(), 6, "exactly six artifacts, named, fixed");
        let names: Vec<&str> = report.a.iter().map(|r| r.name).collect();
        assert_eq!(
            names,
            vec![
                "ccf-lexer",
                "ccf-parser",
                "ccf-expander",
                "ccf-infer",
                "ccf-check",
                "ccf-compiler"
            ],
            "the artifact order is the pipeline's own (K159: the artifacts explicit)"
        );
        // Every artifact carries its extern contract record (the CCF
        // slot declaration rides the product — zero code, the
        // contract table).
        for row in report
            .a
            .iter()
            .chain(report.b.iter())
            .chain(report.c.iter())
        {
            // The blade 3 face (r168-b2's third injection channel +
            // this list's b3 catch-up, the same-family cleanup): the
            // expander CCF carries THREE slot declarations (`forms`
            // + the accessor table's `ex-struct-accs` + the ctor
            // table's `ex-enum-ctors`); every other CCF carries one.
            let expected = if row.name == "ccf-expander" { 3 } else { 1 };
            assert_eq!(
                row.externs, expected,
                "the CCF [{}] carries its slot contract",
                row.name
            );
            assert!(
                row.protos > 0,
                "the CCF [{}] compiles to real code",
                row.name
            );
        }
    });
}

// ---------- the load-bearing rows ----------

/// The extern slot declaration is LOAD-BEARING: the bare twin source
/// (no declaration) rejects at the EXPANSION layer with the
/// unbound-identifier key — the honest boundary the selfhost
/// composed-formula tests disclose (only macro.ktf, the one
/// self-contained twin, rides bare). The CCF form is what makes
/// "the chain compiles the chain" expressible at all.
#[test]
fn the_bare_twin_source_rejects_at_the_expansion_layer() {
    deep_stack(|| {
        // The bare source through the read segment alone: the READ
        // twins accept it (the twins read their own family's
        // sources — the r139 deepest fixed point), and the expansion
        // layer owns the rejection (the slot reference is unbound
        // without the declaration).
        let bare = TARGET_LEXER_TARGET_SOURCE;
        // The definitive face: the ORACLE route itself rejects the
        // bare source at the expansion layer (the same key the twin
        // chain would produce — the parity discipline's own face).
        let forms = kerf_reader::read_target_program(kerf_span::FileId(0), bare)
            .expect("the bare source READS (the r139 fixed point)");
        let err = kerf_expander::expand_program(&forms)
            .expect_err("the bare source rejects at the expansion layer");
        let key = format!("{err}");
        assert!(
            key.contains("unbound"),
            "the rejection is the unbound-identifier key: {key}"
        );
    });
}

/// An undeclared slot reference rejects with the same parity key:
/// the ONLY difference from the CCF is the missing declaration —
/// the declaration (not any other property of the assembly) is what
/// carries the chain through the expansion layer.
#[test]
fn an_undeclared_slot_reference_rejects_with_the_parity_key() {
    let src = "define(result, car(source_bytes));\n";
    let forms =
        kerf_reader::read_target_program(kerf_span::FileId(0), src).expect("the source reads");
    let err =
        kerf_expander::expand_program(&forms).expect_err("the undeclared slot reference rejects");
    let key = format!("{err}");
    assert!(
        key.contains("unbound"),
        "the rejection is the unbound-identifier key: {key}"
    );
    // And WITH the declaration the same program rides the full
    // production pipeline (the extern-names seeding accepts the
    // reference; the externals table carries it through the
    // checker; the compiler emits load-global). The slot rides as a
    // function ARGUMENT — the twins' own usage shape (the declared
    // contract arrow unifies with the callee's fresh parameter; a
    // bare car/cdr on the slot would face the contract arrow head-on
    // — the W-3.2 signature-is-the-contract typing).
    let ccf = "extern \"C\" { fn source_bytes() -> int; }\nfn take(x) { x }\ndefine(result, take(source_bytes));\n";
    let (bc, items) = rust_compile_ccf("mini-ccf", ccf)
        .expect("the declared form rides the full production pipeline");
    assert_eq!(items.len(), 3, "the extern item + the helper + the define");
    // The compiled product references the canonical slot name (the
    // skin map's Rule K: `source_bytes` -> `source-bytes`).
    assert!(
        bc.globals.iter().any(|g| g.as_str() == "source-bytes"),
        "the canonical slot name rides the product's globals"
    );
}

// ---------- the fail-closed faces ----------

/// A rejecting source never produces an artifact: the read segment's
/// rejection propagates as an error (fail-closed), never a partial
/// product.
#[test]
fn a_rejecting_source_never_produces_an_artifact() {
    deep_stack(|| {
        let (lexer_bc, _items) =
            rust_compile_ccf("ccf-lexer", &ccf_lexer_source()).expect("the lexer CCF compiles");
        // A malformed source through the read segment: the lexer
        // twin rejects (the grammar face), the runner reports the
        // rejection key, and no artifact path exists. The parser
        // product is a placeholder here: the READ never reaches the
        // parser layer (the lexer rejects first).
        let bad = "define(result, this is not ) valid kerf (\n";
        let forms = kerf_reader::read_target_program(kerf_span::FileId(0), bad);
        assert!(
            forms.is_err(),
            "the oracle read rejects the malformed source"
        );
        let err = read_via(&lexer_bc, &lexer_bc, bad)
            .expect_err("the rejecting source produces no forms");
        assert!(
            err.contains("read segment"),
            "the failure names the segment (fail-closed): {err}"
        );
    });
}

/// The gate detects a divergent product: two compilations of two
/// DIFFERENT sources through the same chain must NOT compare equal —
/// the B ≡ C gate's detection power (a silent-always-true gate would
/// be worse than no gate).
#[test]
fn the_gate_detects_a_divergent_product() {
    // Two mini-CCFs differing by one instruction's payload.
    let src_a = "extern \"C\" { fn items() -> int; }\ndefine(result, 41);\n";
    let src_b = "extern \"C\" { fn items() -> int; }\ndefine(result, 42);\n";
    let (bc_a, _items_a) = rust_compile_ccf("mini-a", src_a).expect("compiles");
    let (bc_b, _items_b) = rust_compile_ccf("mini-b", src_b).expect("compiles");
    // The oracle's own compilations differ (the const pool carries
    // 41 vs 42) — and the CCF products differ with them.
    assert_ne!(bc_a, bc_b, "the two CCFs' products differ");
    // And the pipeline's gate row: the divergence naming face (the
    // AbcReport's own gate_line carries the FAIL form).
    let report = AbcReport {
        a: vec![],
        b: vec![],
        c: vec![],
        b_eq_c: false,
        a_eq_b: true,
        divergence: Some("ccf-lexer"),
    };
    let line = report.gate_line();
    assert!(
        line.contains("FAIL"),
        "the gate line names the failure: {line}"
    );
    assert!(
        line.contains("ccf-lexer"),
        "the divergence names the artifact: {line}"
    );
}

// ---------- the cross-stage consumption ----------

/// The B artifacts RUN as chain segments: the chain's own
/// compilation of the lexer CCF (the B artifact, produced by the
/// chain via the A products) READS a source through the injection
/// channel — the C pass's own shape on one segment, the consumed
/// product face. The full C pass rides the golden test; this row
/// pins the consumption mechanics in isolation.
#[test]
fn the_b_artifact_runs_as_a_chain_segment() {
    deep_stack(|| {
        // The A products for the read + expand segments.
        let mut a_lexer = None;
        let mut a_parser = None;
        let mut a_expander = None;
        for (name, source) in ccf_sources() {
            let (bc, _items) = rust_compile_ccf(name, &source).expect("the CCF compiles");
            match name {
                "ccf-lexer" => a_lexer = Some(bc),
                "ccf-parser" => a_parser = Some(bc),
                "ccf-expander" => a_expander = Some(bc),
                _ => {}
            }
        }
        let a_lexer = a_lexer.expect("the lexer artifact");
        let a_parser = a_parser.expect("the parser artifact");
        let a_expander = a_expander.expect("the expander artifact");
        // The B artifact: the chain's read + expand of the lexer CCF
        // produce the items; the compiler twin (the A product of the
        // compiler CCF) compiles them — that product IS the chain's
        // own lexer compilation.
        let (a_compiler, _items) = rust_compile_ccf("ccf-compiler", &ccf_sources()[5].1)
            .expect("the compiler CCF compiles");
        let forms = read_via(&a_lexer, &a_parser, &ccf_lexer_source())
            .expect("the chain reads the lexer CCF");
        let items = expand_via(&a_expander, &forms).expect("the chain expands the lexer CCF");
        let b_lexer = compile_via(&a_compiler, &items)
            .expect("the chain compiles the lexer CCF — the B artifact");
        // THE CONSUMPTION: the B artifact (the chain's own lexer
        // compilation) reads a source through the injection channel —
        // the same face the C pass rides.
        let probe = "define(result, 7);\n";
        let _forms = read_via(&b_lexer, &a_parser, probe)
            .expect("the B artifact runs as the read segment's lexer");
        // And the parity anchor: the B artifact's own compilation
        // equals the oracle's compilation of the same items (the
        // parity the golden test's A ≡ B row discloses).
        let oracle_bc = kerf_compiler::compile_program(&items).expect("the oracle compiles");
        assert_eq!(
            b_lexer, oracle_bc,
            "the chain's compilation equals the oracle's (the parity row)"
        );
    });
}

// ---------- the TD-032 golden regeneration (the blade-6 closure) ----------

/// The TD-032 registered-divergence goldens' regeneration path —
/// deliberately `#[ignore]`d (a regeneration is a reviewed act: run
/// `cargo test --test runner regen_td032 -- --ignored`, then land
/// the fixture diff as the divergence-domain change it is). The
/// differential itself asserts the goldens byte-exact on every
/// pipeline run; this test only WRITES them.
#[test]
#[ignore = "the regeneration path — run deliberately (cargo test --test runner regen_td032 -- --ignored)"]
fn regen_td032_infer_goldens() {
    deep_stack(|| {
        for (name, source) in kerf::driver::ccf_sources() {
            let Some(_) = kerf::driver::registered_infer_golden(name) else {
                continue;
            };
            let dump = kerf::driver::ccf_infer_dump(name, &source)
                .unwrap_or_else(|err| panic!("[{name}] the twin infer dump: {err}"));
            let path = format!(
                "crates/kerf-driver/src/bootstrap/fixtures/td032_{}_infer.txt",
                name.replace('-', "_")
            );
            std::fs::write(&path, &dump)
                .unwrap_or_else(|err| panic!("the golden {path} must write: {err}"));
            eprintln!("regenerated {path} ({} bytes)", dump.len());
        }
    });
}

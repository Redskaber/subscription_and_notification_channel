# 自举完备总规划（bootstrap-completion-plan.md）——从 v0.95.0 到完全脱离宿主语言的窗口序列与 MUV 排期

> **Status**: **自举源双现代化后自由排期区第三段——W-SELFHOST-ORCH OPEN @ r205（v1.56——r207 刀 2 DELIVERED：序列化面〔MX-1 渲染不对称退役〕——R1-R9 全落位（窗口档 §10 裁定表单源）：render-line 库面全局〔builtin 18→19——第 162 轮零新原语：零通道 §8.8 既有·零 VM·零语法〕+ std/render.ktf 第七词汇包〔write 先例扩展〕+ 语言内 render 金档〔census == 宿主 Display 逐位三重钉〕+ 四孪生注册表共变〔ex_globals 影子对 + tc_builtin_arity + ti_is_builtin〕+ audit BL 10 案〔512→522 live〕+ C 后端镜像臂；金链 v0.147.0 + 台账 v1.22〔19 件 23,697〕；v1.55——r206 刀 1 DELIVERED：import 表面〔组合桥退役〕——O1-O9 全落位（窗口档 §9 裁定表单源）：关键字双形〔24→25 三处共变〕+ composer 首见组合〔M49 种子可读性边界当轮修订——行载体 verbatim 披露形〕+ 单元注册表六件 + 三承载件依赖声明 + 装配迁移三处〔通道位重排披露〕+ 组合产物字节级金档 ×2 + 孪生共变 + 工作负载面迁移 ×3 + 测试新族 9 案 + TD-032 四金档再生成；T0 30/30 + T1 60/60；金链 v0.146.0 + 台账 v1.21〔18 件 23,618〕+ 8 原语第 161 轮〔零新原语〕；下一刀 = 刀 2 序列化面〕）；前版 v1.54——r205 触发器驱动重扫 + 开窗行权轮：用户显式排期三句式信号〔放行推进 + 首要完整完全自举「自己用自己语言推进自己」+ 桥审查「每加一个需求就加一座桥 = 不行，可审查去除不必要的」〕→ §17 Step 1 重扫 + 桥清单盘点〔selfhost/README 宿主约定六条 + STD_ERROR 装配前缀族 + M49 冻结 reader + harness oracle 位 + 格式工具〕+ r124 §6e 议题一重勘裁定〔宪制排除收窄 = cargo 构建引导 + VM 基座；装配/组合/序列化/驱动四类重分类为可退役桥——多数先例证据 Go cmd-go/dune/GHC hadrian〕+ r205-search 八检索 + REPORT.md 单源 + **W-SELFHOST-ORCH OPEN**〔w-selfhost-orchestration-window.md v1.0：五刀序（刀 1 import 表面 → 刀 2 序列化面 → 刀 3 kerf-build 编排器孪生 → 刀 4 M49 重审 + 退役清扫 → 刀 5 收口）+ 出口六条 + 零载荷边界〕+ **目标语言完整落地计划 §3 第三段落档**〔Phase α 自举完备收尾（本窗）→ β 核心语义（W-LINEAR-TYPES → W-UNION-INTERSECT → W-COMPTIME）→ γ 表面语法糖（语法糖窗 try/catch/? + 守卫子句 + 字符串插值 + 浮点/字节/字符字面量）→ δ 标准库与生态（数值库/集合库/可见性/LSP/文档生成/交叉编译/并发调度策略窗）——基础核心先行序，各段窗触发器纪律维持〕；矩阵 v1.29〔§7 语言内编排行登记 92→93〕+ stage0 §9.143/v10.09 + roadmap v3.17 + tech-debt r205 检视）；前版 v1.53——W-SELFHOST-MODERN-2 CLOSED（r203：刀 6 DELIVERED + 窗口收官**〔target-parser.ktf 5,122→4,648〔C2 解析拒绝族 M77 + 101 守卫溶解 + C1 M78 done 死头丢弃〕+ infer.ktf 零变更三面关闭〔M74/M75/M76〕+ TD-032 闭账〔差分语义升级——四源金档钉死 + 豁免撤销〕+ M79 harness 共变 + M81 C4 金档钉〔ei08/ei09〕+ 出口判据六条全 ✓ → **W-SELFHOST-MODERN-2 CLOSED**——12/12 件效应族链表面消费终态；下一排期点 = §17 Step 1 扫描（自举段候选窗触发器核对——下一矩阵审计轮含 LSP 双态口径 ±1 首项）〕）；前版 v1.52——r195：§17 Step 1 扫描轮 + W-SELFHOST-MODERN-2 开窗行权轮**〔效应族链闭合后自由排期点首次行使：扫描裁定 11 候选窗触发器逐一核对零信号（并发调度策略窗〔L3 授权〕/语法糖窗〔#15 依赖〕/W-LINEAR-TYPES/W-UNION-INTERSECT/W-COMPTIME/W-HEAP-EXTERN/共享污染 P2/TD-029/横切九窗/W-3.x 族/缺失候选）+ **W-SELFHOST-MODERN-2 OPEN @ r195**（四触发器全达成：效应族能力里程碑 @ r194 = 用户指令③触发条件 + 零更高优先自举段 + 验证安全网在位 + 用户显式排期；前置门四件全过：§3.3 提案 = w-selfhost-modern2-window.md v1.0 本体 / r195-search 六检索（rustc 自源采纳 / GHC 扩展分阶 / OCaml 内部 / JEP 440 record 模式 vs 访问器 / OCaml 5 效应错误处理 / bootstrap 循环） / 8 原语第 152 轮设计面 / 孪生可表达性 ✓；实测勘定 12 件零行字面量消费 + ~900 first/~810 rest 标签键导航位 + ~107 "err" 穿线位；消费分类学 C1-C5 + 诚实边界五条 + 零新桥承继 r174 终局裁定；六刀序最小先行：刀 1 semver/micro-toml 试点 → 刀 2 pkg 三件 → 刀 3 typecheck/target-lexer → 刀 4 compiler/macro → 刀 5 expander → 刀 6 infer/target-parser 收官 + close；矩阵 v1.21 共变〔含计数表三处漏翻同轮清偿 + modern-2 登记 92 项〕）；下一入口 = 刀 1（r196+）〕）；前版 v1.51——r194：W-EFFECT-INSTANCES 刀 3 DELIVERED + 窗口 CLOSED——效应族三段链全链闭合 ✓**〔段 3 Async 策略面交付：`selfhost/std/async.ktf`（with_async 同步直通退化策略——§9.14.2 Async 行零偏离 + §5.4 诚实边界出口注记〔真调度器 = 策略替换位后续窗，L3 授权域，零通道 8 原语冻结维持〕）+ §5.8 开刀定案〔探针后删三实证：再入路由 B=42（handler 子句体期间存活——oneshot_entry 快照不弹）+ 严格 thunk 面 C + k 形探针滑落 D（双操作数 → 退化 invoke）〕+ 语料 ef-async-* 8 案 2:6=1:3 四臂全覆盖 + efx_instance_sweep 五族化（六库前缀 + 人口门 32→40 + 臂门 10/4/4/22）+ 机制 sweep 排除滤网 ef-async- 同 commit 预付（r193 教训应用）+ audit Section BK 10 案 502→512 live EXIT 0（守卫四处共变）+ T0 29/29 + T2 fresh 全量 §19.3 + BufferIo 回归 63/63 + 8 原语第 151 轮构造性维持；台账 17→18 件 23,953→23,994；**金链 bump v0.138.0→v0.139.0（窗口 CLOSED 里程碑——r189 先例）**；出口判据六条全 ✓ → 段 3 CLOSED，效应族链全链闭合（行类型基础→机制地基→官方词汇面）；下一排期点 = §17 Step 1 扫描 + 本计划 §3 序（后续窗候选：并发调度策略窗〔L3〕/语法糖窗〔#15 依赖〕，零信号不开窗维持）〕）；前版 v1.50——r193：W-EFFECT-INSTANCES 刀 2 DELIVERED**〔段 3 IO 桥两件交付：`selfhost/std/` 续两件（read.ktf with_read〔§9 resume 单射——处理器体 read_line() 桥 BufferIo §8.8 宿主通道〕/ write.ktf with_write〔§9 副作用驻处理器体——write_line(payload) + k(nil) 完成确认；§5.7 thunk 链组合纪律〕）+ 语料族 ef-io-* 8 案 8:24=1:3 四臂全覆盖（io-in/io-out 双向缓冲钉死约定）+ efx_instance_sweep 四族化（五库前缀 + 种子通道面）+ audit Section BJ 10 案 492→502 live EXIT 0（守卫四处共变）+ 机制 sweep 排除滤网 ef-io- 扩展（新族共变义务——首跑红一次后修）+ T0 29/29 + T2 fresh 70/70 全绿 EXIT 0（§19.3 无豁免——指纹变更后全量重跑 13 运行块）+ BufferIo api 面回归零扰动（kerf-vm lib 63/63）+ 8 原语第 150 轮构造性维持；台账 15→17 件 23,849→23,953〔含 r192 矩阵 §7 行漏共变清偿〕；窗口 OPEN 维持——刀 3 Async+收口待做〕）；前版 v1.49——r192：W-EFFECT-INSTANCES 刀 1 DELIVERED**〔段 3 纯语言三件交付：`selfhost/std/` 新标准库区首三件（state.ktf 状态代链 INST-6〔探针三实证 + polysemy Tactics 同构——窗口档 §5.6 落档 + §3.3 偏离记录一行〕/ error.ktf attempt+unwrap / log.ktf with_log+with_log_via）+ 语料族 24 案 6:18=1:3 四臂全覆盖 + efx_instance_sweep（INST-1 通道 (a) 前缀注入）+ audit Section BI 12 案 480→492 live EXIT 0（守卫四处共变——组成表/总计/头行/守卫断言）+ T0 29/29 + T2 fresh 70/70 全绿 EXIT 0（§19.3 无豁免——10 运行块）+ 8 原语第 149 轮构造性维持；台账 12→15 件 23,680→23,849；窗口 OPEN 维持——刀 2 IO 桥两件/刀 3 Async+收口待做〕）；前版 v1.48——r191：段 3 效应族实例窗开窗行权**〔W-EFFECT-INSTANCES OPEN @ r191——效应族三段链链末段进入实施：双前置达成 @ r189（段 2 W-EFFECT-MECHANISM CLOSED + §9 六实例消费位接口冻结）+ 前置门四件全过（r191-search 六检索五范式家族 + Rust 惯例锚 + 8 原语第 148 轮设计面 + 孪生可表达性 ✓）；单源 w-effect-instances-window.md v1.0——三刀序（刀 1 纯语言三件 State/Error/Log → 刀 2 IO 桥两件 Read/Write〔BufferIo 宿主通道〕→ 刀 3 Async 同步直通退化形 + 收口）+ 实施裁定五条 INST-1..5（载体 = selfhost/std/ 库位 + 语料双面 / 三种子句形分族 / 行类型骑箭头四元槽 / 载体分层实施序 / audit·sweep 逐刀扩展）+ 出口判据六条；矩阵 v1.17 §5 行 83 注记升级 + §11 优先级段 3 升当前实施位〕；v1.47——r189：W-EFFECT-MECHANISM 刀 3 DELIVERED + **窗口 CLOSED——效应族链段 2 ✓ 收口**〔corpus-effect/ 28 案〔10 正 + 18 负——四裁决臂 sweep：value/read-error/type-error/runtime-error，rw 型接线形制 + 着者时三捕获诚实重分类〕+ audit Section BH 10 案〔470→480 live EXIT 0〕+ r185-r188 audit 守卫组成表 BG 行漏登同路径修复〔§20.3〕+ **段 3 前置接口冻结**（w-effect-mechanism-window §9——六实例消费位形状：Read/Write/State/Async/Error/Log 的 perform 词汇/子句形/行类型/机制消费位 + 冻结裁定五条〔零新原语/三种子句形全覆盖/箭头携行消费/载体分层/语法糖后置〕）；零生产面文件——8 原语第 146 轮构造性维持；金链 v0.138.0；T1 58/58 fresh + audit 480/480 live；出口六条全 ✓ → **段 3 效应族实例窗开窗前置就绪**〕；v1.46——r188：W-EFFECT-MECHANISM 刀 2 DELIVERED〔效应行推断消费——infer.ktf 4,922→5,532：箭头携行四元槽 + 类型行轨 + 上下文栈/hres + 三态定型〔退化参数合一/k 续体恢复/未处理 Koka 同调扩展〕+ 覆行扣除合并 + halt/body 合一 + 泛化面；金档 25 案 1:3 + oracle 三件零文件〔r174 第三刀〕+ fixpoint 位级 + T2 68/68——窗口 OPEN 维持，刀 3/close 待做〕；v1.45——r187：W-EFFECT-MECHANISM 刀 1 DELIVERED〔值层/VM one-shot 语义深化——续体值类 2 族 + ext2 OneShotMark + k 形式元数约定 + `return` 子句 b 位路由〔+1 哨兵〕+ degenerate 零漂移；金档 6:18 + T0 五案 + T2 67/67 + oracle 三件零文件〕；v1.44——r186：效应机制窗 OPEN——链中段开窗行权**〔双前置达成 @ r185 承接 + 前置门四件全过：r186-search 六检索五范式家族 + §3.3 提案 = 窗口档本体 + 8 原语第 142 轮设计面 + 孪生可表达性 ✓；单源 w-effect-mechanism-window.md v1.0——三刀序（刀 1 值层/VM one-shot 可恢复语义〔续体值 + k 尾参 + resume/halt + return 标签 + ext2 预留槽填充〕→ 刀 2 infer.ktf 效应行推断消费〔箭头携行/扩行/覆行/逃逸/泛化〕→ 刀 3 语料 + audit + 段 3 前置接口）；同轮 r185 P1 递延清偿 = T2 长族 fresh 全量 66/66 绿（steady_route 7/7 + fixpoint 17 + abc_pipeline 6/6 + doc + audit 470——§3.2.1 分块 5 chunks）〕；v1.43——r185：W-ROW-POLY 刀 2 + 刀 3 DELIVERED + 窗口 CLOSED——链首段 ✓ 收口**〔刀 2 @ r184：target-parser.ktf 4,424→5,122〔`;` 尾分隔皮肤形裁定——`|` 三重职责冲突实勘 + row-spec/row-lit/row-pat 三机〕+ expander.ktf 4,850→5,286〔rowlit/rowlit-nil/rowpat 合成模式 + pcvar 族位移模式 + 封闭 nil 守卫〕+ infer.ktf 4,860→4,922〔注解面 row×pair 桥 ti_ann_row_face——标签从注解/类型位从 spine/动态地板尾〕+ 金档 24 案 1:3 + corpus-row 26 案 + T1 54/54 + fixpoint 17/17 + audit live EXIT 0 + **oracle 三件零文件机检**〔r174 冻结第二刀——kerf-typecheck/kerf-reader/kerf-expander〕+ TD-030 关闭；刀 3 @ r185：corpus-row 28 案 + rw_corpus_sweep 段覆盖〔RW-18 接线〕+ row_effect_shape 6 案〔**P2 效应行形状冻结**——`("row" ((eff opT)...) tail)` 消费位锚〕+ audit Section BG 10 案〔460→470 live EXIT 0〕+ T1 55/55 fresh + segments 39/39 + 出口六条全 ✓ → **W-ROW-POLY CLOSED——效应族链段 1 ✓**；环境披露：T2 长族 fresh 递延连续第二轮〔steady_route/fixpoint 全量/abc_pipeline/doc——r186 首位硬性义务 P1 披露级〕；**§3 段 2 效应机制窗开窗前置达成**〔W-ROW-POLY CLOSED + P2 效应行接口在位——双前置 ✓〕〕）；v1.42——r182：**W-ROW-POLY 刀 1 DELIVERED——行类型类型层内核全量落地自举生产位〔infer.ktf 4,512→4,860 +348〕：**a 映射表落档**〔窗口档 §8.1 RW-1..RW-11——行类型 pair 复合表示 + spec 机 row 三模式 + W 机 row 臂 + 行合一工作表机 + 四 walk 机族 row 臂/row-fields 模式 + 泛化/实例化零新增函数（机族扩展即达）+ Display 面 row 臂 + oracle 冻结精确口径（kerf-typecheck 零文件机检）+ 金档落位 + 边界勘定 + tamper 零交集；**皮肤层实勘**——现有 target 皮肤无法产生 "row" 头 spec（`(` 一律 tuple / path(args) 一律 app）→ 刀 1 金档 = 数据构造形（ModuleItem 直构喂 steady 链），corpus-row/ 源码语料目录 = 刀 2 交付物〕**b 孪生手术亲执**〔行代数辅助机（ti_row_extract 点对约定/ti_row_labels/ti_row_dup）+ ti_resolve_spec "row"/"row-fields"/"row-field" 三模式（尾 nil 封闭/_ 开放 fresh/其他降 Dyn——GZ-1 保守族）+ ti_unify_row 五规则机（标签全表提取 rest(hit) 点对余表·**ti_2(hit) car-on-nil 崩溃面内循环立捕修复** / 开放尾扩展绑定 ρ:=(l fresh|ρ') / lacks 双向·**余行级精确诊断实勘裁定**（expected/found 骑余行/字段位——Leijen 精确诊断面，映射表措辞随实勘修正）/ 封闭化 / 空字段尾透传）+ ti_unify_step row 臂（r127 守卫同族）+ 四 walk 机族（varocc/subst/occurs/resolve）row 臂 + row-fields 模式（字段先尾后——首见序金档钉死）+ ti_fresh 前移（依赖序——两次前向引用立捕 + 模式合并正统化）；**依赖序内循环三轮**（ti_row_spec_fields→模式合并 / ti_fresh→前移）〕**c 金档语料 + 扩展**〔row_poly_golden_tests.rs 24 案全钉死（正 6 : 负 18 = 1:3——尾变量绑定族/标签重排序无关/开放吸收封闭封闭化/空封闭行/跨 define 实例化（schema vars 捕获行变量——RW-6 泛化面）/保守降级边界 + E0013 ret 面 13 + struct/enum 正交 2 + E0009 调用位 3）；hm_twin_chain 追加 cross-route 双路由双引擎 3 案（**per-source payload 补全——同类路径全量修复**：items_stream_prefix 的 dann/struct/enum 三分支从位置专用（编译器零码视角）补全为全 payload（kind/anchor/index/spec 裸渲染 emit_spec_value——S-expr 载体纪律：空表 bare nil / 单元素无尾逗号，两处载体实勘立捕修复）+ infer_twin_per_source_text_dual 新 lane（r174 冻结域外 lane——rebuild 面假设 twin 类型 ⊆ oracle Type 域，row 超域构造性豁免））；hm_twin_face 追加 oracle 冻结豁免面钉死（twin 携 row 分歧 vs oracle Dyn 吸收——豁免面的回归守护）；tiers.tsv 登记 row_poly_golden（T1）——tier 守卫立捕清偿〕**close 交付链**〔快面三绿 + fresh T2 64/64（人口 63→64 +row_golden 族；含 audit live EXIT 0 + fixpoint 9/9 + target_fixpoint 8/8 B≡C 位级 + 全 parity sweep 回归）+ T0 29/29 + T1 53/53（人口 52→53）+ oracle 冻结机检（git diff crates/kerf-typecheck/ 零文件——r174 裁定首个适用者执行）+ 门审构成达标（18 单语句 + 4 多函数 + fixpoint/segment 复杂程序 + 18 错误恢复 + 7 类错误 ≥6 类负向）+ 投票 5.5/5.5 APPROVED + 金链 v0.132.0（Cargo.toml/lock 13 + ds08 断言翻转 + r182 注释链）+ 台账 v1.9（21,445→21,793）+ 矩阵 v1.10（§4 行多态行刀 1 DELIVERED 注记 + §7 台账行）+ tech-debt r182 检视（**新登记 TD-030：per-source S-expr 载体 Nil↔String("nil") 不可区分边界**——P3 窄面：per-source 推断路由零字段 dstruct/空注解 spec 的漂移面，注入路由不受影响，resolver 保守降级兜底，刀 2 皮肤语法就绪时清偿）+ RELEASE_NOTES v0.132.0 + §19 双包 + web r182〕；**下一入口 = W-ROW-POLY 刀 2**〔target-parser.ktf 4,424 + expander.ktf 4,850——行类型注解解析 `[l: T | r]` 表面形（语法面最小扩展——20-surface-conventions R1-R6 管辖）+ 开放记录消费脱糖（字段访问/记录扩展——a-MUV 详裁）；验收门 = 注解语法正负例金档 + expand/read segment switch 扩展 + parity 回归 + fixpoint；窗口档 §6 刀表单源〕；G1-G8 全 ✓ 终态维持〕；前版 v1.41——r181：**§17 Step 1 下一窗扫描轮 + W-ROW-POLY 开窗行权轮 + 目标语言完整落地总规划轮**〔用户指令⑥「规划完整 kerf 目标语言完整语法语义等方面的完整落地纳入计划」= 矩阵 §11 优先级 2 效应族六实例的显式排期请求信号 → GZ-5 需求触发器①链式达成 → W-ROW-POLY 触发器①达成——**G8 后自由排期区首个实施窗 OPEN**〕：①§17 Step 1 扫描九行全表〔矩阵 §11 单源 + tech-debt + calibration + roadmap + tests + worklog + gate-review GO 终态 + 能力边界确认——零未决阻塞〕②**W-ROW-POLY 开窗行权**〔w-row-poly-window.md v1.0 新建：触发器①链式达成落档 + 前置门四件全过〔§3.3 演进提案 = 窗口档本体 + 知识搜索先行 tool-results/r181-search 六检索五范式家族取样〔Leijen 2005 scoped labels 行合一「only affecting unification」+ Koka 行效应论文 + OCaml/PureScript/Unison 对照 + 否决记录：约束式/子类型式〕+ 8 原语不变性第 138 轮〔行类型 = 类型层扩展零值层原语〕+ 孪生可表达性评估〔infer.ktf 行合一 = match 分派 + lacks 守卫 + var 绑定复用 + rest_work 机制复用——18 内建可表达面内〕〕+ 行类型表示裁定〔.ktf 生产位 `("row" ...)` pair 嵌套复合 + **Rust oracle 零改动**——r174 冻结裁定首个适用者：新特性验证 = 金档期望 + fixpoint 三阶段 + audit 三面，零 oracle 共同实现〕+ 行合一五规则〔标签匹配重写 / lacks 守卫 / 尾变量绑定 / 封闭行 / struct 透明展开正交维持〕+ P1/P2 处理程度分级〔原则 26——P1 行类型+行合一+开放记录 unify 生产面 / P2 效应行接口形状冻结 / 不做 duplicate labels·first-class labels·行 kind 全量〕+ 三刀序〔刀 1 infer.ktf 类型层内核 → 刀 2 target-parser + expander 消费面 → 刀 3 语料+audit+P2 效应前置接口〕+ 出口六条〕③**目标语言完整落地总规划**〔效应族三段链排期入 §3 序列：W-ROW-POLY〔链首段·类型基础·OPEN〕→ 效应机制窗〔链中段·handler/perform 语义 + 效应行推断消费——本窗 CLOSED 后开窗〕→ 效应族实例窗〔链末段·Read/Write/State/Async/Error/Log 六实例〕；正交登记窗族〔W-LINEAR-TYPES/W-UNION-INTERSECT/W-COMPTIME/W-HEAP-EXTERN〕与缺失 12 项维持矩阵 §11 触发器观测——完整落地 = 效应族链实施 + 余窗按触发器逐窗推进（零信号不开窗纪律维持，非冻结——触发器达成即开）〕④矩阵 v1.9〔§11 优先级重排——W-ROW-POLY 升首位实施窗 + §4 行多态行 实施窗 OPEN 注记〕+ tech-debt r181 检视 + roadmap v3.05 + 纯文档开窗轮快面三绿 + §19 双包 + web r181；下一入口 = **W-ROW-POLY 刀 1**〔infer.ktf 类型层内核——行类型表示 + ti_unify_step 行合一臂 + 泛化/实例化行变量处理；验收门 = 金档新语料 1:3 + parity 回归 + fixpoint + hm twin 扩展；窗口档 §6 刀表单源〕；G1-G8 全 ✓ 终态维持〕；前版 v1.40——r180：**W-SELFHOST-MODERN 刀 6 DELIVERED + 窗口 CLOSED**〔infer.ktf 4,471→4,512 + target-parser.ktf 4,402→4,424——W 机 M50〔ti_unify_step 四守卫维持 if + 字面域 match + `_` 记录域嵌套 tag match + not(is_pair(b)) 守卫折入 pair/fn 臂〕+ walk 模式机族 M51 + 规格解析机 M52 + 任务机 M54 + 名字表 M55 + 帧机 M59〔tp_step 33 状态 + tp_give 29 臂 machine-drop `_` 保形〕+ 守护相位机族 M60〔is_nil(phase) 新鲜态族〕+ token/datum 表 M61〔含 tp_step_datum 谓词级联入 `_` 臂〕+ tp_bin_ops 整型臂 + 离开守卫 M63 + 注解族 M57/M64〔~76 + ~29 位——**tp_ha/tp_ma nil 占位域与 ti_member/ti_row_push 名/位混合域经 checker 立捕后诚实裸名**〕——表示恒等，映射表窗口档 §14 M49-M65 + 边界勘定十一条〕；**刀 6 门全绿**〔全 parity sweep + fixpoint 17/17〔B≡C 位级〕+ T2 63/63 含 audit 460/460——T0 29/29 + T1 52/52 先行；快面三绿〕+ oracle 零改动〔crates/ 零文件——冻结裁定第五次行使〕+ 台账 v1.8〔21,382→21,445——12/12 全上 G8 表面〕+ 金链 v0.131.0 + 矩阵 v1.8〔§7 行翻转 ✓ 终态 + v1.7 头漏漂移清偿〕+ 出口六条 ✓ → CLOSED；G1-G8 全 ✓ 终态维持〕；前版 v1.39——r179：**W-SELFHOST-MODERN 刀 5 DELIVERED**[expander.ktf 4,740→4,850 + macro.ktf 735→733——最大件全表面 + 遮蔽族两份共变用 G8 表面完整重构：合成模式机 M41〔ex_expand 九合成臂 + `_` 臂携带深度守卫 + 真树——接收域逐位一致，臂体 +4/真树 +8 缩进迁移〕 + 表达式头分派 M42〔十特殊形 + 宏/应用回退 `_`〕 + 声明头分派 M43〔八声明形 + top 失败 `_`〕 + 装载器 M44〔ex_edges require/module〕 + 警察标量表 M45〔extern type-tag 三臂 + ex_gen 双臂共变〕 + 注解族 M46 ~41 位〔span str / gen·索引 i64 / 谓词 bool；双形名面〔is_bound/is_in_frames/frame 族——串或 mangled 记录〕诚实裸名〕 + **遮蔽族两份共变 M47**〔实测交集 22 名恒等体——r178 记账「16」为低估勘正；ex_gen match 化 + 标量注解逐字节同施两件；diff 恒等体机检 22/22〕 + 守卫级联维持 M48〔警察族谓词链 + ex_cov 走查 + 键查找〕——表示恒等，映射表窗口档 §13 M41-M48 + 边界勘定十条〕；**刀 5 门全绿**〔全 parity sweep：subset_corpus 173 + parity_contract 15 + segment switch 四族 9/10/9/11 + steady_expander_chain 9 + steady_target_reader 7 + superinstr 16 + method_jit 21 + pkg_window 8 + format_guard 3 + fixpoint 三阶段 17/17〔B≡C 位级〕〕+ **T2 全量 63/63 含 audit 460/460 live**〔T2 首跑揭 r178 两 audit 针遗漏——AO10 fusion-arm 与 AP09 poison-scan 钉 pre-match 源形态（r178 更新 tests/ 树两针漏 audit 本位副本，刀 4 门只跑 T1 未及 audit 面）→ 针文本随源形态共变当轮清偿 + audit_case_inventory 标签格式实勘〕+ oracle 零改动〔crates/ 零文件——冻结裁定第五次行使机检〕 + 台账 v1.7〔21,274→21,382——段孪生 13,087→13,197〕+ 金链 v0.130.0 + 矩阵 v1.7 + T0 29/29 + T1 52/52 + 快面三绿 + §19 双包 + web r179；G1-G8 全 ✓ 终态维持〕；前版 v1.38——r178：**W-SELFHOST-MODERN 刀 4 DELIVERED**[compiler.ktf 1,900→1,877 + macro.ktf 692→735——编译面/宏面两件用 G8 表面完整重构：CP 两遍分派 M31-M36〔cp_child_count 24 臂/cp_lit_convert 7 臂含 pair 直通/cp_assemble 27 臂副作用 do 入臂/opcode 栈效应双表/cp_ewalk 双层 match 化〔外层七合成模式 + _ 真树臂携深度计数器；内层 let v = match tag 17 臂 + _ bad-node——值流与尾终止符 bool 契约逐位保持，机械变换脚本 + 体段字符流保真校验〕/cp_drain_scan jump 分派〕 + 宏库保守面 M37/M38〔ex_cpat/ex_mx 双层〔模式族 wild/lit/var/atom + _ 列表回退〕/ex_colls/ex_inst 模式机 + ex_binder_names 头名分派〕 + 注解族 M39/M40 ~45 位〔索引/计数/槽位 i64 + 名字/操作码 str + cp_ewalk tail: bool；混合返回面诚实不注解〕 + **遮蔽族冻结**〔macro.ktf 16 自含助手被 expander.ktf 同名重定义遮蔽——「合法遮蔽·恒等体」纪律，ex_gen 虽为分派面亦冻结，刀 5 两份共变〕——表示恒等，映射表窗口档 §12 M31-M40 + 边界勘定十一条〕；**刀 4 门全绿**〔compile_segment_switch 11/11 + **fixpoint 三阶段 17/17**〔B≡C 位级——fixpoint 链 B 段载体自应用：重构后的编译器自编译自身二次产物逐位一致，全项目最深自引用面〕 + expand_segment_switch 9/9 + steady_expander_chain 9/9 + gate-B 双口径 5/5〕+ 关联族〔parity_contract 14 + subset_corpus 173 + pkg_window 8 + typecheck_twin_sweep 6 + hm_twin_face 4 + format_guard 3〕 + oracle 零改动〔crates/ 零文件——冻结裁定第四次行使机检〕 + 台账 v1.6〔21,254→21,274——段孪生 13,067→13,087〕+ 金链 v0.129.0 + 矩阵 v1.6 + T0 29/29 + T1 52/52 + §19 双包 + web r178；G1-G8 全 ✓ 终态维持〕；前版 v1.37——r177：**W-SELFHOST-MODERN 刀 3 DELIVERED**〔typecheck.ktf 1,286→1,264 + target-lexer.ktf 1,065→1,069——判定面/词法面两件用 G8 表面完整重构：标量 tag 表 M21〔tc_child_count 24 臂/tc_builtin_arity 18 臂直接 match tag 串〕+ walk 模式机 M22〔tc_walk/tc_collect_walk 四态 + tl_scan 三态，末态落收尾通配臂〕+ 记录组装 M23〔tc_assemble 24 臂〕+ R1-R8 规则走查臂化 M24〔do/set 突变序列不动〕+ 被调分析 pair 模式 M25〔字面头双臂——is_pair 守卫内化，compile_pattern 测试链单源验证〕+ 注解族 M26/M29〔i64/str/bool；单态递归约束全调用点统一；tc_report s/e = span 串域〕+ 算符极长匹配表 M27〔tl_op 25 入整型臂顶层 + b2/b3 嵌套〕+ 边界维持 M30〔tl_word_tag byte-list 等值链维持——无标量判别键〕；**刀 3 门 hm_twin_face 4/4 + target_lexer_twin 7/7 全绿**〔含 12 件 selfhost 固定点自应用闭环——twin 读自身重写源〕+ 关联族〔typecheck 36 + hm_twin_chain 6 + parity_contract 15 + reader_seed 17 + corpus 5 + format_guard 3〕+ oracle 零改动〔冻结裁定第三次行使〕+ r177 实勘〔臂体块强制——parse_match_expr 臂体经 parse_block，r175 勘定①前置事实面，首版 60 臂漏包裹经 twin 解析立捕〕；台账 v1.5〔21,272→21,254〕+ 金链 v0.128.0 + 矩阵 v1.5 + T0 29/29 + T1 52/52 + 快面三绿 + §19 双包 + web r177〕；**下一入口 = W-SELFHOST-MODERN 刀 4**〔compiler.ktf 1,900 + macro.ktf 692——CP 两遍分派 → match + 宏库保守重构；验收门 gate-B 双口径 + fixpoint 三阶段；窗口档 §6 刀表 + 矩阵 §11 单源〕；前版 v1.36——r176：**W-SELFHOST-MODERN 刀 2 DELIVERED**〔manifest.ktf 494→525 + lockfile.ktf 659→675 + resolve.ktf 478→517——组合程序族三件用 G8 表面完整重构：**struct Slot/Dep 声明带 struct 型字段**〔M13/M14——嵌套 resolve 面孪生消费首例，infer.rs 参数注解静默锚定 + 每调用点新鲜元变元的静态安全论证〕+ 家族词汇跨件复用〔M15——Span/Pos/Version/Constraint 五件组合序共享〕+ 分派面全覆盖〔M16 键匹配器常量表 / M17 标签字面头 + `_` 域成员 / M18 语法直通坍缩 / M19 三色与状态 nil+字面臂——顶层 nil 模式首例 / M20 阶段判别臂〕；表示恒等——oracle 零改动 + 宿主解链零改动 + 下游组合零改动；**parity 六族 + kp 三态带回退全绿**〔semver 36 + micro-toml 48 + manifest 19 + lockfile + resolve 30 + pkg_window 8 + kp_selfhost 6 含回退带 + kp_corpus 7 双臂〕；映射表 = 窗口档 §10 M13-M20 + 边界勘定十条〔struct 模式不使用——刀 1 惯例维持 / mf_project 参数遮蔽警戒 / M13-M14 回退预案〕；台账 v1.4〔21,186→21,272〕+ README 三行 + 金链 v0.127.0 + 矩阵 v1.4 + T0 29/29 + T1 52/52 + 快面三绿 + §19 双包 + web r176〕；**下一入口 = W-SELFHOST-MODERN 刀 3**〔typecheck.ktf 1,286 + target-lexer.ktf 1,065——判定面 R1-R8 规则走查 → match 臂化 + 词法分派表 → match；窗口档 §6 刀表 + 矩阵 §11 单源〕**；前版 v1.35——r175：**W-SELFHOST-MODERN 刀 1 DELIVERED**〔semver.ktf 304→337 + micro-toml.ktf 603→662——试点双孪生用 G8 表面完整重构：struct Version/Constraint/Span/Pos〔构造 = cons 右折恒等〕+ match 分派〔pair 模式字面头 + 整数字面臂 + `_` 域全称兜底〕+ 标量/结构注解〔Struct↔Pair 透明律〕；**脱糖映射表 = 窗口档 §9 M1-M12 落档**（a-MUV）；表示恒等——parity 六族全绿〔semver 36 + micro-toml 48 + manifest 19 + lockfile + resolve 30 + pkg_window 8 驱动〕+ 下游组合程序零改动通过；实施时勘定三项〔match 臂体块强制尾逗号 / 末臂穷尽律——字面臂对不可收尾 / mt_error 臂序倒置〕；台账 v1.3〔21,094→21,186〕+ README 两行 + 金链 v0.126.0 + 矩阵 v1.3〔§7 台账行 + 现代化行刀 1 DELIVERED 注记——窗口 OPEN 维持〕+ T0 29/29 + T1 52/52 + 快面三绿 + §19 双包 + web r175〕；**下一入口 = W-SELFHOST-MODERN 刀 2**〔manifest.ktf 494 + lockfile.ktf 659 + resolve.ktf 478——组合程序族三件同型重构，刀 1 模式复用 + kp 三态带回退验证；窗口档 §6 刀表 + 矩阵 §11 单源〕**；前版 v1.34——r174：G8 后自由排期区第三轮——用户显式排期请求驱动〔指令④⑧⑪〕：①两处实况漂移清偿〔selfhost/README.md 七件旧态→12 件实况 21,094 全量重写 + s-expr-conversion-record v1.2 G8 四刀合并补账 17,154→21,094——r160 后 10 轮失账 + §5 登记义务范围澄清〕②SOP v15.5→v15.6〔§3.2.1 长套件执行与收割恢复协议——用户指令⑤；同轮实施 test-tiers.sh status 恢复面：分层剩余/预估秒/续跑命令/分片进度四件单命令报告，T0 新鲜 29/29 实测〕③**W-SELFHOST-MODERN 登记**〔w-selfhost-modern-window v1.0——12 件 .ktf 孪生用 G8 最新表面完整重构（用户指令④触发条件已达成：G8 闭合 @ r170）；四触发器全达成 + 六刀序最小先行〔semver/micro-toml 试点 → 组合三件 → typecheck/target-lexer → compiler/macro → expander → infer/target-parser〕+ 出口六条；**桥模式终局裁定**〔用户指令⑧——oracle 冻结于 v0.125.0 语言面 + 新特性停 oracle 共同实现义务 + 金档/fixpoint/audit 验证面替代——rustc UI 金档 K-r174-1 / Go 可复现三轮自检 K-r174-2 / GHC Python 驱动避自依赖 K-r174-3 / Inko 唯一实现 K-r174-4 / rustc 特性通道 K-r174-5 五锚，r174-search 存档〕④矩阵 v1.2〔§7 现代化行登记 + §11 重排首位 + 计数 90→91 = ✓58/冻结6/登记15/缺失12〕+ 守卫注释 seven→twelve 清偿；下一入口 = W-SELFHOST-MODERN 刀 1〔已兑现 @ r175〕**；前版 v1.33——r173：用户常设指令④尾项〔「整理这条内容并用精炼准确的描述添加到 docs/sop.md 中适当的章节和适当位置，并检查 sop 执行流节点中是否能够在适当时机触发此条例」——r171/r172 两轮未兑现 @r173 当轮清偿〕：SOP 六编辑点全落〔Version 头 v15.5 / §8.4.5 查询表矩阵行 / §17.2 扫描表矩阵行 / §8.5 审查清单第 17 项（每窗 OPEN/CLOSED/DELIVERED 必检共变——GATE 3 接线）/ §21.12 第 34 条（目标语言能力矩阵纪律）/ §16.1 v15.5 行〕+ 两处接入缺口清偿〔§8.4 目录树补矩阵行（§8.5 第 15 项避免文档孤立——r171 建实体未入树 @r173 补齐）+ 矩阵头部流程权威锚刷新 v15.4→v15.5 六点〕+ addendum v15.x 命名冲突歧义消解注记〔addendum 内部小节标签 v15.1-v15.5（2026-09-27 历史）vs 主版本号 v15.1-v15.5 数字复用——以 Version 头 + §16.1 表为单一事实源〕+ tech-debt r173 检视〔零新 TD + TD-029 第十七次观测 + 8 原语第 130 轮验证〕+ roadmap v2.97 + 纯文档轮快面四绿 + §19 双包 + web r173；下一入口 = 任一登记窗〔14 窗全景〕触发器达成或用户显式排期请求〔矩阵 §11 单源——v15.5 后每轮扫描经 §17.2 矩阵行结构化输入〕**；前版 v1.32——r172：§6.10.2 全 11 行对账审计〔11/11 闭合零遗漏——门审面；三缺口族 = 行 3 线性 / 行 4 交叉联合 / 行 6 编译期求值，行 7-11 非实施决策零缺口维持〕+ 三窗登记〔W-UNION-INTERSECT 交叉/联合 + W-LINEAR-TYPES 线性/仿射 + W-COMPTIME 编译期求值——w-decision-gap-windows.md v1.0 新建·四件形制〔成熟度口径 + 时机触发器 + 开窗前置门 + 登记名〕，全部零信号不开窗〕+ 语言能力矩阵 v1.1〔交叉联合/线性两行 缺失→登记 + comptime 补行〔v1.0 遗漏清偿——§6.10.2 行 6 半承载拆账：宏展开半面 G4 已交付为语法变换子面非等价物〕+ 计数 89→90 = ✓58/冻结6/登记14/缺失12 + §11 优先级表重排〔三窗入列 3/4/5 位〕+ §12.4 触发器定义义务闭环转常设〕+ tech-debt r172 检视〔零新 TD + 三窗同步登记〕+ roadmap v2.96〔§6 当前位置行 r171 遗留当轮清偿〕+ 文档轮快面四绿 + §19 双包 + web r172；下一入口 = 任一登记窗〔14 窗全景〕触发器达成或用户显式排期请求〔矩阵 §11 单源〕**；前版 v1.31——r171 §17 Step 1 下一窗扫描轮〔G1-G8 全闭合后首个自由排期点〕：**登记窗全景核对零实施窗可开**——候选 11 窗逐一触发器核对〔W-ROW-POLY 四触发器全未触发：效应族自身登记态 / 成熟度早期维持 / 无开放记录需求 / Dyn 损耗未超成本；W-HEAP-EXTERN 零信号；共享环境污染 P2 信号弱〔一次实证已规避〕；TD-029 多轮零触发；效应族六实例零信号；横切登记窗族〔W-GEN-GC / W-VM-SUPERINSTR / W-EMI-COMPILE-AXIS / W-BOUND-SCOPE / W-NAMING / W-CHK-DEFINE-HASH / W-DIAG-×2 / W-DRIVER-HARNESS-SPLIT / W-PKG-MULTISRC〕零信号维持；W-3.x 非自举族**从属位法定解除落档**〔§3 豁免声明条件「C1-C4 未验收期间」已随 r163 GO 失效——各窗自身触发器仍零信号〕〕；**下一议程裁定 = 语言能力统计矩阵首版创建**〔用户常设指令④实体——实况核查此前不存在；docs/lang-design/language-capability-matrix.md v1.0 新建：编译管道全阶段 × 能力项 × 四态〔✓交付/✓设计冻结/登记/缺失〕× 优秀语言参照 + 决策-实况对账列〔§6.10.2 交叉联合类型/线性类型「决策=实现 Stage 1、实况=未实施」缺口首次显性化〕+ 计数汇总〔✓58 / 冻结6 / 登记11 / 缺失14 = 89 项——写入时自查勘正后口径〕+ 剩余优先级九序〔下一窗扫描单源输入〕+ 维护纪律〔每窗开闭必共变——GATE 3 查询位〕〕；同轮缺口清偿两件〔roadmap 头部版本行 v2.95 补落〔d80a82f 声称未落〕+ 本计划 §3 图内 W-LANG-FOUNDATION 行 OPEN→CLOSED 遗留——§8.4.5 实况对账〕；下一入口 = 矩阵 §11 优先级 3 触发器定义补全〔决策-实况缺口族〕或任一登记窗触发器达成**；前版 v1.30——r170 W-LANG-FOUNDATION 刀 4 交付 + **窗口 CLOSED（G8 闭合入账）**：struct 模式族收口全链〔裁定 a——窗口档 §11 三面裁定 + GZ-5 评估档案〔W-ROW-POLY 登记名〕+ 展开器双臂 b @ f13af2d——oracle 双查表消歧 + 零位移字段公式 + struct_face 三判式 + 读链 3+ 元组放行迁移〔neg-065/066/071/072 期望共变 + audit AC5/AY03/AY10〕+ expander.ktf 孪生全套〔pcvar shift 参数化〕+ 语料族 c 16 案 1:3 + 人口钉扎 154→170 十一位共变〕+ close〔v0.125.0 金链 + T0 29 + T1 52 + T2 63/63 八窗零中断〕——出口五条逐条核对 ✓ → W-LANG-FOUNDATION CLOSED；自举矩阵 G1-G8 全 ✓ 终态；下一入口 = §3 序列扫描（§17 Step 1）**；前版 v1.29——r168 W-LANG-FOUNDATION 刀 3 交付：enum 表面 + 脱糖 + GZ-4 穷尽性全链〔裁定落档 a @ 7145c18——GZ-4 展开期单段执法 + 表示 cons(decl_index,payload-chain) + 模式首元素查表消歧 + Type::Enum 名义封闭 + 读链双臂 b1 @ abf88a2 + 展开器双臂 b2 @ 7ef4e32——警察七族 + 注入通道第三例 + 推断层双臂 b3 @ c0c35ea——EnumTable + expand_match enum 感知 + compile_pattern variant 位 + DEFAULT_BUDGET 8→16MiB K159〕+ 语料族 16 案〔b4 @ 2c614c0——正 4 负 12 = 1:3 + 人口钉扎十位共变 138→154〕+ v0.124.0 金链；窗口档 v1.3 刀 3 行 ✅——「enum = 派生表面非原语面」兑现：构造 = ctor define 单源、消费 = match variant 模式、类型层 Enum(Symbol) 名义原子〕；下一刀 = 刀 4 模式匹配扩展 + 行多态评估窗〔GZ-5 判据 + 时机触发器登记——评估非实施〕；前版 v1.28〔r166 刀 2——struct 表面 + GZ-2/GZ-3 + TD-026 闭账〕struct 表面 + 脱糖全链〔读链双臂 b1 @ 740f93b + 展开器双臂 b2 @ a312970——ModuleItem::Struct 零码 item + 警察四族 + 脱糖发射序 + 推断层双臂 b3 @ 03bf751——StructTable + Type::Struct 名义承载 + unify 透明展开 + r127 标量崩溃面同族清偿〕+ 语料族 13 案〔b4 @ f1dfaf4——正 3 负 10 = 1:3.3 + 人口钉扎九位共变 125→138〕+ GZ-2/GZ-3 裁定落档 + **TD-026 闭账**〔R-F3 协议草图 + W-HEAP-EXTERN 登记窗承载——w3.2 §5 增补三件〕+ v0.122.0 金链；窗口档 v1.2 刀 2 行 ✅；下一刀 = 刀 3 enum 表面〔GZ-4 穷尽性 + 刀 2 表示裁定继承——tag 位留刀 3〕；前版 v1.27〔r165 刀 1——E0013 第 14 位 + 解析表 + param 锚定 + 16 案语料〕——r164 开窗行权轮：§13.1 设计对齐〔窗口档 §2——设计锚七件 + 实况对账三面 + 灰区决策表 GZ-1..GZ-5〕+ TD-026 重审〔riding 维持 + 门条件精化 = 刀 2 开窗时点 R-F3 句柄协议——窗口档 §4〕+ 注解消费面重勘〔Rust 面 4 位点 + 孪生双函数 + typecheck 锚点——窗口档 §3〕+ 窗口档新建 w-lang-foundation-window.md v1.0 + 刀 1 排期 r165〔类型注解消费面〕；纯治理零版本变更 0.120.0 维持——r155/r161 开窗轮同型先例；§8 r164 复核行新增；前版 v1.25〔r163 验收 COMPLETED〕）——r163 验收终态承继：**C1-C4 复核实测全绿维持 + D1-D8 深审零阻塞 + §14.8 偏差清单全处置〔B4 roadmap 历史表述注记 + B1 类型注解面入 G8 刀 1〕+ §14.9 整理 C1-C6 全过〔9 处 catch-all 注释补全〕+ §6.6 校准 Stage 3.7 收口行 + §6.3 投票 5.5/5.5 → **GO——完成标准宣告达成**〔法定原文：完全脱离宿主语言，宪制排除项除外〕；自举矩阵 G1-G7 全 ✓ 终态；W-LANG-FOUNDATION（G8）从属位解除 = 验收后首议程〔开窗轮 = §13.1 设计对齐 + TD-026 重审 + 窗口档新建〕；深审单源 deep-review-bootstrap-completion.md；v0.120.0 金链；前版 v1.24（r162 G6 闭合））**
> **流程权威**: docs/sop.md v15.6（§21.12-28 自举完备优先纪律全条 / §21.7 风险表 / §17.3 依赖图规则优级行 / §13.1.2 第 5 项 / §3.2.1 长套件纪律；版本行 @r174 顺更——v15.3→v15.6 条款全数承继）
> **依据**: stage0.md §9.25（BS-A 自举策略）+ §9.113（K140-K142 自举时序锚）+ §9.121（K157-K162 r135 知识层）；roadmap v2.64 §2（Stage 2a 完全自举出口判据）；w3.12-frontend-window v5.0（前端三段 ELEVATED + T-a/T-b 触发器）；w-jit-method-t1-window v1.0（本规划的性能前置窗单源）；tech-debt-register（登记窗台账）；tool-results/r135-search/REPORT.md（知识检索七件）
> **职责边界**: 本文档承载**自举完备（完全脱离宿主语言）的剩余窗口序列、排序裁定、每窗细粒度 MUV、完成标准操作化与测量计划**；全局阶段节点/时间治理四红线由 roadmap.md 单源承载，本文只引用；各窗实施细节由各自窗口档单源承载，本文承载序列与排期。
> **宪制排除项**（§21.12-28③ + 原则 53——永不入自举链，不计入「完全脱离」分母）：VM 永久 Rust 基座 / 构建引导层（cargo + r124 宪法性排除裁定）/ 链外后端（C/LLVM/QBE——W-3.8 家位）。

## 1. 完成标准操作化（§21.12-28③ 法定标准的工程判据）

**法定原文**：自举完成 = 完全脱离宿主语言——自举后所有阶段的设计与开发通过自身语言进行；宪制排除项除外。

**工程判据（可验收四条）**：

| # | 判据 | 验收形态 |
|---|---|---|
| C1 | **kerf 源的 kerf 编译链**：.ktf 目标皮肤源 → 读（目标皮肤读链孪生）→ 展（expander.ktf）→ 查（infer.ktf + typecheck.ktf）→ 编（compiler.ktf）→ 字节码 → VM 执行——全链无 Rust 编译段参与 | 组成链等价断言：`pipeline_ktf(S) == pipeline_rust(S)` 全语料两皮肤 sweep + fixpoint（自编译自执行字节一致） |
| C2 | **生产位切换**：上述孪生链为**生产链**（Rust 各段退役为种子链 oracle——验证面保留，E5 同构先例）；开发工作流（编辑 .ktf → 编译 → 测试）经 kerf 自身进行 | 切换窗五步走通（§5）+ K159 不动点管线 A/B/C 三工件 B≡C 位级 |
| C3 | **递归深度通解**：任意递归深度由内存预算治理非固定整数帽（eval/VM 激活记录堆化；读/析层护栏可配置——K162 范围化）；fixpoint 自源构建在新机制上完成、无 VM-only 括号依赖 | 深非尾递归仅受内存约束测试 + 深尾递归恒定栈高测试 + fixpoint 无括号自建测试 |
| C4 | **语言自我推进面**：语言进一步开发所需的读/展/查/编/测/基（基准）面全部可经自身语言表达与执行（语料 sweep 经稳态链、基准经 VM 计时面）；Rust 面收敛为宪制排除项 + oracle 验证面 | 稳态链全语料 sweep + 基准程序经 VM 运行实录 + Rust 面清点表（排除项 + oracle 逐项） |

## 2. 现状地图（v0.95.0 时点——已完成 / 缺口）

**已完成（账面清偿）**：

- **前端 S-expr 链三段 ELEVATED**（read r121 / expand r123 / HM 判定面 r131）+ compile 孪生在位（r124 组合分析面）——BS-A 前端全段收敛（r131）
- **注入通道生产化**（r121 INJ-1..INJ-5：`inject_global` + fail-closed 三面 + 稳态链形制）——T-b 纯度面已消费
- **孪生七件**（lexer/reader/expander/macro/infer/typecheck/compiler .ktf = 9,822 行）parity 位级 + fixpoint 自复现 + gate B 全语料
- **融合两刀**（r133 CallGlobal + r134 F1 直发算术——B 轴 0.75×，两刀 -25.0%）
- **W-PKG-SELFHOST 前置其一**（融合刀交付——r132 精确化裁定）

**缺口（本规划的排期对象）**：

| # | 缺口 | 性质 | 现状锚 |
|---|---|---|---|
| G1 | ~~目标皮肤读链孪生不存在~~ **已闭合（r136 刀 1 + r138 刀 2 + r139 刀 3——C1 链路级终态）**：.ktf 文本→树经 target-lexer.ktf + target-parser.ktf 孪生（稳态链形态 + K20 桥），组成链五联差分全绿（composed_target_read_chain——C1 断链闭合） | r139 终态（AV 族 380/380） | w3.12:94 |
| G2 | ~~任意递归深度未通解~~ **已闭合（r136 刀 1 + r137 刀 2——C3 终态宣告）**：eval 堆激活栈化（10^5 深非尾递归默认栈实测 + 深尾递归恒定栈高）+ 四层帽 K162 可配置护栏（with_limit 全链 + env 单源 fail-closed）+ r74/r85 VM-only 括号全链退役（fixpoint 无括号自建） | r137 终态（C3 四验收腿全绿） | 本计划 §4.1 r136+/r137+ 行 |
| G3 | ~~T-a 性能带未达~~ **已裁决（r142 刀 2——w-jit-method-t1-window v1.2 §8 MJ-5/MJ-6）**：性能面实测裁决完成 = 链内最优形态锁定（纯解释 + LLC——B2 66.1ms = 2.79× 带缺口登记）；三触发器未清账（2.79× / 64.2% / ~339×）但消除杠杆（真 codegen）在链外（W-3.8 可选位——零 codegen 约束下 27 臂 match 解释器即最优分派形态，K152/K157 实测兑现）——链内结构性天花板诚实登记；LLC 杠杆归属改判（r135「tier-1 兑现」论题实测证伪 → 墙时净负资产，链内退役/维持延后 T-a 开窗轮重审） | 性能前置（**裁决完成——窗口 CLOSED**） | r142 §3.2 三跑 + w-jit-method-t1-window v1.2 §8 |
| G4 | ~~生产位未切换~~ **已闭合（r145-r149 五刀终态）：read + expand + check + compile 四段生产位全切换（r145-r148）+ step ⑤ 工作流宣告 + C1-C4 验收对账（r149）**——孪生链为生产链，Rust 各段退役为种子链/oracle 验证面（E5 同构先例）；T-a 窗口 CLOSED @ r149（w-t-a-switch-window v1.5） | r149 终态（T-a 关窗） | w-t-a-switch-window v1.5 |
| G5 | ~~包管理器未自举~~ **已闭合（r155 开窗 + r156 刀 1 + r157 刀 2 + r158 刀 3a + r159 刀 3b + r160 刀 4——窗口 CLOSED @ r160）**：kerf-pkg 逻辑面五模块 .ktf 孪生全承载（micro-toml/semver/manifest/lockfile/resolve——台账五件 2,538 行）+ kp 生产位 = 孪生臂（KERF_PKG_SELFHOST 三态带）+ Rust 逻辑臂退役为构建引导回退带（r160 lib.rs 退役声明）+ 全语料回归双臂逐位（kp_corpus 7 + pkg_window 8 + parity 31 + audit AI 10 维持）；中位违例缺陷 r160 当轮清偿（conflict-mid-list 钉） | 后置基础设施（K161 解耦先例）——判据满足后自举优于维持（§12）✓ 完成 | w-pkg-selfhost-window v2.0 CLOSED |
| G6 | ~~eval 引擎退役~~ **已闭合（r161 开窗行权 + r162 刀 1——窗口 CLOSED @ r162）**：退役形态 = 退役为测试面（用户面 loud-retirement——`--engine`/`--parity` 双旗教育性错误 + repl.rs engine 字段退役 + 守卫重钉 B1/40；验证面保留——eval.rs/parity 全臂/fixpoint 门/audit H/bench 双驱 = 验证面专用，K15 差分承重不动）；元循环求值器 = 唯一规划退役能力 ✓ 完成 | 切换后收尾 ✓ | w-eval-retire-window v2.0 CLOSED（评估档 w3.6 §5 触发器单源） |
| G7 | ✓ **已全拆 @ r154**（S-expr 表面四层全离树：语料层 r150〔109 .ktf 单皮肤〕+ 读链层 r151〔~4,700 行退役〕+ 词面层/台账层 r154〔~292 处清零 + TEST-5 零扫描守卫 + 台账升格转化终态 14,616 行〕——「完全自举后完全使用目标语言的词法语法语义」（用户指令⑥）兑现；窗口 CLOSED @ r154） | 脚手架拆除面（R5 生命周期拆除位——§2.2 原则 41/53）✓ 完成 | subset-spec §0〔终态注记 r154〕+ 本计划 §4.4 + w-sexp-retire-window v1.3 CLOSED |
| G8 | **语言基础面行权中**：~~类型注解消费~~ **刀 1 ✓ @ r165**（E0013 + 解析表 + param 锚定/E0009 第三例外 + ret/let unify——parse-and-drop 终结）+ ~~struct 表面~~ **刀 2 ✓ @ r166**（GZ-2 pair 链 + GZ-3 Type::Struct 名义承载透明展开 + TD-026 闭账〔W-HEAP-EXTERN 登记窗承载〕——「struct = 派生表面非原语面」兑现）；~~enum/穷尽性~~ **刀 3 ✓ @ r168**（GZ-4 展开期单段执法 + Type::Enum 名义封闭 + variant 模式位——16 案语料 1:3 + 人口钉扎 138→154）、模式族收口 + 行多态评估 = 刀 4（登记态——本计划 §4.5 四刀单源；生产面 HM 推断扩展 Type::Struct/Type::Enum 名义承载） | 后置语言演进（自举完备后首议程——用户指令⑤⑦；详见 §9 时点裁定） | stage0 §9.14.2/§7.4 + 本计划 §4.5/§9 + w-lang-foundation-window.md v1.2 |

## 3. 窗口序列（粗粒度——排序裁定 + §21.12-28① 合规性）

```text
v0.95.0 (r134 闭合态)
  │
  ├─► W-JIT-METHOD-T1〔OPEN @ r134——性能前置窗〕
  │     r135 tier-0.5 收尾刀（LLC 复制对融合 20%）
  │     r136+ W-REC-DEPTH 共享基座（G2——堆激活栈）
  │     r137+ tier-1 方法 JIT（TJ-4 去分派形态，构建于 G2 之上——TJ-3）
  │     出口：三触发器清账 + T-a 链路复画像
  │
  ├─► W-TGT-READ-TWIN〔新登记 @ r135——G1 目标皮肤读链孪生〕
  │     （与 W-JIT-METHOD-T1 的 r136+ 阶段可并行排期——.ktf 语义编写面 vs
  │       VM 基座面零交集；串行执行时单代理按窗口纪律逐窗）
  │     出口：.ktf 读链 kerf 承载 + 双皮肤全语料 parity + 读段自应用
  │
  ├─► T-a 生产位切换窗〔G4——组合面前置 = G1+G2+G3〕
  │     五步流程（§5——K159 不动点管线）+ 分段切换序（§5.2）
  │     出口：C1+C2 验收 + K140 带（切换性能回退 ≤ ~10× 接受——收窄后置）
  │
  ├─► W-SEXP-RETIRE〔G7——新登记 @ r140；S-expr 脚手架拆除窗（R5 拆除位）〕
  │     前置：T-a 切换窗 step ④ read 段生产位（拆除权发生位）+ TD-027 清偿
  │     出口：词法语法语义全目标语言单皮肤 + S-expr 面全树清零（用户指令⑥终态）
  │
  ├─► W-PKG-SELFHOST〔G5——**CLOSED @ r160**：r155 开窗 + r156 刀 1 micro-toml + r157 刀 2 semver/manifest + r158 刀 3a lockfile + r159 刀 3b resolve〔家族首个五件组合程序〕+ kp 三态接线 + r160 刀 4 全语料回归 + Rust 臂退役 + G5 闭合——五模块全承载 ✓ 出口四条全 ✓（单源 w-pkg-selfhost-window v2.0）〕
  │     四刀序（w-pkg-selfhost-window §4）：刀 1-4 全交付 ✓（刀 4 = Rust 臂退役 + CLOSED @ r160）
  │     出口 ✓：kerf-pkg 逻辑面 .ktf 全承载 + kp 生产位孪生臂 + Rust 臂退役为回退带
  │
  ├─► W-EVAL-RETIRE〔G6——**CLOSED @ r162**：裁定 = 退役为测试面（用户面 loud-retirement ✓ + 验证面保留 ✓）；单源 w-eval-retire-window v2.0〕✓
  │     出口 ✓：用户面零 eval 消费（机检 cli.rs 零命中）+ 守卫重钉 B1/40 + G6 闭合入账
  │
  └─► 自举完备验收〔✓ **GO @ r163**——C1-C4 复核实测全绿维持（K159 门 8/8 release + 段切换族 + corpus 112/112 + audit 460 live）+ 单皮肤终态核验（台账 17,154 逐位）+ D1-D8 深审零阻塞 + 投票 5.5/5.5 + 完成标准宣告 + roadmap Stage 2a 出口对账（§2 行 B4 历史表述注记裁定——宪制序用户指令⑥ > 历史文本）；深审单源 deep-review-bootstrap-completion.md；v0.120.0〕
        │
        ▼
     W-LANG-FOUNDATION〔G8——**OPEN @ r164 → CLOSED @ r170——四刀全交付：刀 1 ✓ @ r165 / 刀 2 ✓ @ r166 / 刀 3 ✓ @ r168 / 刀 4 ✓ @ r170**（从属位解除 @ r163 → 开窗行权轮 → 刀 1 类型注解消费面全链 v0.121.0 → 刀 2 struct 表面 + 脱糖全链 v0.122.0〔GZ-2/GZ-3 裁定 + **TD-026 闭账**——W-HEAP-EXTERN 登记窗承载〕→ 刀 3 enum 表面 + 脱糖 + GZ-4 穷尽性 v0.124.0 → 刀 4 struct 模式族收口 + GZ-5 评估档案〔W-ROW-POLY 登记名〕v0.125.0——用户指令⑤⑦全兑现；出口五条逐条 ✓ @ r170 close 深审——**窗口 CLOSED + G8 语言基础完备闭合入账**；单源 w-lang-foundation-window.md v1.4）〕
       出口：类型注解消费面 ✓ + struct 脱糖面 ✓ + enum 脱糖面 ✓ + 模式匹配扩展 ✓（四刀全 ✓——G8 入账 @ r170；§4.5 细粒度 MUV 四刀单源；下一议程 = §17 Step 1 下一窗扫描 @ r171）
        │
        ▼
     ── G8 后自由排期区（r171+；矩阵 §11 单源结构化输入；§21.12-28 自举段就绪 = 首要入口）──
        │
        ├─► W-SELFHOST-MODERN〔**OPEN @ r174 → CLOSED @ r180**——六刀全 DELIVERED：r175 试点 semver+micro-toml / r176 组合三件 / r177 判定+词法 / r178 编译+宏 / r179 最大件 expander+遮蔽族 / r180 收官 infer+target-parser——**12/12 件 .ktf 全上 G8 表面**（台账 21,445 行）；oracle 冻结裁定 + 桥模式终局（K-r174-1..5）；出口六条 ✓ @ r180；单源 w-selfhost-modern-window.md〕
        │
        └─► **效应族三段链（用户指令⑥显式排期 @ r181——目标语言完整语法语义落地主轴）**
              │
              ├─► 段 1：W-ROW-POLY〔行多态·类型基础——**CLOSED @ r185**（OPEN @ r181：触发器①链式达成〔效应族进入实施排期〕+ 前置门四件全过〔r181-search 六检索 + §3.3 提案 + 8 原语第 138 轮 + 孪生可表达性 ✓〕；三刀全 DELIVERED：刀 1 infer.ktf 类型层内核 @ r182 → 刀 2 读链+展开器消费面 @ r184 → 刀 3 语料+audit BG+P2 效应前置接口 @ r185；**r174 冻结裁定首个适用者**——Rust oracle 零改动，验证 = 金档 + fixpoint + audit 三面；单源 w-row-poly-window.md CLOSED 终态；出口六条全 ✓ → 段 2 开窗前置就绪；〔本行 CLOSED 终态 @ r194 补正——r189 轮更新段 2 行时本行漏共变，§20.6 同类披露〕〕
              │
              ├─► 段 2：效应机制窗〔handler/perform one-shot 可恢复语义 + 效应行推断消费——**CLOSED @ r189**（单源 w-effect-mechanism-window.md v1.3；三刀全 DELIVERED：刀 1 值层/VM 语义深化 @ r187 + 刀 2 infer.ktf 行推断消费 @ r188 + 刀 3 语料/audit/段 3 前置接口 @ r189——corpus-effect 28 案 + audit BH 480/480 + §9 六实例接口冻结；出口六条全 ✓）〕
              │
              └─► 段 3：效应族实例窗〔Read/Write/State/Async/Error/Log 六官方实例（stage0 §9.14.2 实施态 @ r194）——**实施窗 W-EFFECT-INSTANCES CLOSED @ r194（效应族三段链全链闭合）**（开窗前置达成 @ r189：段 2 CLOSED + §9 消费位接口冻结——六实例 = 冻结机制上的词汇包；r191-r194 三刀全 DELIVERED：刀 1 纯语言三件 @ r192 → 刀 2 IO 桥两件 @ r193 → 刀 3 Async 同步直通退化形 + 收口 @ r194；出口判据六条全 ✓；单源 w-effect-instances-window.md v1.3 CLOSED；金链 v0.139.0〕
                    │
                    ▼
     ── 效应族链闭合后自由排期区第二段（r195+；§17 Step 1 扫描行使 @ r195——11 候选窗零信号；§21.12-28 自举段就绪 = 首要入口）──
              │
              └─► W-SELFHOST-MODERN-2〔自举源现代化二窗——12 件 .ktf 孪生消费效应族链表面（行词汇 + 效应词汇包）。**CLOSED @ r203**（六刀全 DELIVERED：r196/r197/r198/r200/r201/r203——12/12 件消费终态 + TD-032 闭账；原 OPEN @ r195 记录：（四触发器全达成：效应族能力里程碑 @ r194 = 用户指令③触发条件〔「每当确认完善 kerf 端自己特性和能力时……使用 kerf 当前最新词法语法语义完整重构……替换原始编码」——modern-1 @ r174 同一指令族续作〕 + 零更高优先自举段〔11 候选窗触发器逐一核对零信号〕 + 验证安全网在位〔fixpoint B≡C + audit 512 live + r174 冻结裁定三面〕 + 用户显式排期〔「放行继续推进和演进」〕；前置门四件全过：§3.3 提案 = w-selfhost-modern2-window.md v1.0 本体 / r195-search 六检索〔rustc 自源采纳 / GHC 扩展分阶 / OCaml 内部 / JEP 440 record 模式 vs 访问器 / OCaml 5 效应错误处理 / bootstrap 循环〕 / 8 原语第 152 轮设计面 / 孪生可表达性 ✓。实测勘定：12 件零行字面量消费 + ~900 first/~810 rest 标签键导航位 + ~107 "err" 穿线位。消费分类学 C1-C5〔行字面量/行模式 C1 + Error 词汇 C2 + Log 词汇 C3 + 效应行注解 C4 + State 自然位评估 C5〕 + 诚实边界五条〔外部契约冻结 / 诊断累积面不开 / 位置元组不强转 / 性能诚实账 / std/ 前缀装配既有注入族〕 + 零新桥承继〔r174 终局裁定——oracle 冻结维持〕。六刀序最小先行：刀 1 semver/micro-toml 试点 → 刀 2 pkg 三件 → 刀 3 typecheck/target-lexer → 刀 4 compiler/macro → 刀 5 expander → 刀 6 infer/target-parser 收官 + close；出口判据六条；单源 w-selfhost-modern2-window.md §6〕

     ── 自举源双现代化后自由排期区第三段（r205+；§17 Step 1 触发器驱动重扫 @ r205——用户显式排期三句式信号；§21.12-28 自举段就绪 = 首要入口）──
              │
              ├─► **Phase α：W-SELFHOST-ORCH〔OPEN @ r205——自举编排语言内化窗（自举完备收尾链）〕**
              │     五刀序（w-selfhost-orchestration-window.md v1.0 §6 单源——逐刀 parity/fixpoint 门 + 可回滚桥替换）：
              │     刀 1 import 表面（组合桥退役——macro+expander 装配与 pkg 五件拼接迁移 import 形制；脱糖至 §9.64 MOD 加载层）
              │     刀 2 序列化面（MX-1 渲染不对称退役——值→字节经 Write 效应宿主通道；字符串构造 = 效应词汇包设计位）
              │     刀 3 kerf-build 编排器孪生（驱动桥退役——读〔Read〕→孪生解析→import 组合→链内编译→写工件〔Write〕；cmd-go/dune 时刻）
              │     刀 4 M49 重审 + 装配前缀族退役清扫（冻结 reader 退位种子+oracle 双位；RS-1/token/EX-1/CP-1/STD_ERROR/budget/verdict 尾逐桥退役）
              │     刀 5 收口（出口六条 + 逐需求桥 = 0 机检锚 + 宪制排除三项终态注记）
              │     出口：装配桥归零 + 语言内编排位级实证 + fixpoint 扩展 + M49 落档 + 宪制收敛注记 + 零降级自举
              │
              ├─► **Phase β：核心语义能力落地链（α 后；类型系统核心先行——用户指令「从基础核心的能力和特性完善后再延伸」）**
              │     W-LINEAR-TYPES（线性/仿射类型——r172 登记；触发器：α 收口 + 资源安全语料需求）
              │     → W-UNION-INTERSECT（交叉/联合类型——HM+union 融合成熟度观察维持）
              │     → W-COMPTIME（编译期求值——G6 eval 退役边界对账义务维持）
              │     （W-HEAP-EXTERN 与线性类型触发器③联动——TD-026 承载位注记维持）
              │
              ├─► **Phase γ：表面语法糖链（β 后；糖域 = 脱糖优先 K-D 纪律）**
              │     语法糖窗（try/catch/? 表面糖——#15 依赖面；Error 词汇 ✓ 已就位 @ r196-r203）
              │     守卫子句（match guard——脱糖 if 嵌套展开）
              │     字符串插值（format 脱糖面——刀 2 序列化面联动）
              │     浮点/字节/字符字面量（词法+内建层扩展——零原语约束下 Int 位扩展候选路径）
              │
              └─► **Phase δ：标准库与生态链（γ 后；生态位）**
                    数值库（浮点/大数/位运算——§1 浮点字面量联动）+ 集合库（map/set——哈希面 = 零原语约束下内建层议题）
                    可见性控制（pub/private——多模块语料规模触发器；import 表面刀 1 联动注记）
                    LSP/IDE 协议面（rust-analyzer 参照——设计预留位实施）+ 文档生成器（rustdoc 参照）
                    交叉编译矩阵（链外 C 后端位 W-3.8 域）+ 并发调度策略窗（Async 真调度器——L3 授权 + §5.4 诚实边界）
                    （横切登记窗族 W-GEN-GC/W-VM-SUPERINSTR/W-EMI-COMPILE-AXIS 等 + TD-029 + W-3.x 族：各窗触发器纪律维持，零信号不开窗）
```

**排序裁定（ARCH-A @ r135，逐窗可审计理由——§21.12-28①）**：

| 序 | 窗 | 优先级依据 |
|---|---|---|
| 1 | W-JIT-METHOD-T1（含 W-REC-DEPTH 前置刀） | 已开窗在航（r134 三触发器；tier-0.5 收尾刀 r135 已交付 + W-REC-DEPTH 两刀 r136/r137 已交付——G2 ✓）+ T-a 链路性能前置；下一刀 = tier-1 刀 1（TJ-4 去分派形态） |
| 2 | W-TGT-READ-TWIN | G1 = C1 结构性断链（语言读不了自己的源 = 一切自举链的最前置断点）；**三刀全交付 r136/r138/r139——G1 ✓ C1 链路闭合（窗口关闭）** |
| 3 | T-a 切换窗 | 组合面前置 = 窗 1（G3 性能带）+ 窗 2（G1 ✓）+ G2 ✓ 已凑其二；K159 五步 + 分段序；K140 性能带诚实预期（组合面——w3.7 §4.3 登记）；**r143：前置全凑齐（TD-027 ✓）——开窗合法成立，step ① 落档 + step ② = r144 首刀 + LLC 维持在位裁定（W-3.8 再重审）；r144：step ②+③ ✓ 交付（B ≡ C 六工件位级——K159 门首证；step ④ 分段切换 = 下一刀）** |
| 4 | W-SEXP-RETIRE〔r140 新登记〕 | 用户指令⑥终态（完全自举后完全使用目标语言词法语法语义）+ R5 拆除判据前置已满足（target 读链 G1 ✓ = 自建替代全语料覆盖 + 额外能力[类型注解语法/胖关键字] > 0）；**置于 T-a 后首位**：read 段生产位 = 拆除权发生位；且先于 W-EVAL-RETIRE = 最大表面迁移（62+ 语料双皮肤→单皮肤）需要双引擎 parity 安全网在场（eval 退役后失去该安全网——迁移验证成本结构性上升） |
| 5 | W-PKG-SELFHOST | K161 解耦先例（opam 语言无关）——PM 自举后置于编译器自举；触发器反冻结重审见 §7；**r155 开窗 + r156 刀 1 + r157 刀 2 + r158 刀 3a + r159 刀 3b + r160 刀 4 全交付——五模块 .ktf 孪生全承载 + Rust 臂退役 + 窗口 CLOSED + G5 闭合 ✓（单源 w-pkg-selfhost-window.md v2.0）** |
| 6 | W-EVAL-RETIRE | 唯一规划退役能力；T-a 后 eval 退为测试面，退役 = 收尾清账（置于 W-SEXP-RETIRE 后——序 4 技术理由）；**r161 开窗行权：裁定 = 退役为测试面（刀 1 = r162 单轮全链——单源 w-eval-retire-window v1.0）** |
| 7 | W-LANG-FOUNDATION〔r140 新登记〕 | 用户指令⑤（语言自身底层和基础内容完成纳入计划）+ K140-K142 先例族（自举达成后特性经自托管编译器发展 =「自己用自己语言推进自己」正型路径）；**置于自举完备验收后**（C1-C4 未验收期间非自举段维持从属位——§21.12-28① 豁免声明一致；语言基础窗为验收后首议程）；**r164 开窗行权 + r165 刀 1 ✓ + r166 刀 2 ✓**（验收 GO @ r163 → 开窗轮 → 刀 1 类型注解消费面 v0.121.0 → 刀 2 struct 表面 + 脱糖 v0.122.0〔GZ-2/GZ-3 + **TD-026 闭账——W-HEAP-EXTERN 登记窗承载**〕——单源 w-lang-foundation-window.md v1.2） |

**非自举段排期豁免声明**：本序列不含 W-3.5（Token 流+图 IR 优化）/ W-3.8（链外后端升级）/ W-3.9（诊断增强）等非自举窗——按 §21.12-28① 排期非自举段须附可审计裁决理由：**自举矩阵未达完成标准（§1 C1-C4 未验收）期间，上述窗维持从属位（触发器信号出现时单独裁定，裁定须过本计划 §3 序前置核对——自举窗就绪即让位）**。**W-LANG-FOUNDATION（序 7）为该从属位的法定解除对象**：C1-C4 验收通过时点 = 从属位解除时点，语言基础窗作为验收后首议程开窗（用户指令⑤⑦——语言自我推进面的首个消费议程）。

**S-expr 移除规划声明（用户指令⑥——r140 落位）**：本项目设计规划**不考虑 S-expr 延续**——S-expr 皮肤 = bootstrap-parser 脚手架（R5 完整生命周期登记：搭建[Stage 0-1]→使用[当前]→自建[孪生链]→拆除[W-SEXP-RETIRE]→超越[单皮肤终态]）；完全自举后词法语法语义全量使用目标语言，S-expr 表面（皮肤/语料/Rust 读链/孪生）全树拆除零延续义务。转化面台账单源 = docs/develop/v3/s-expr-conversion-record.md（r140 新建——每新增转化面三处同步：台账 + 本计划窗口行 + stage0 §9.12X）。

## 4. 前置窗细粒度 MUV（fine——窗口 1/2 的刀级排期）

### 4.1 W-JIT-METHOD-T1（性能前置窗——w-jit-method-t1-window.md v1.0 单源）

| MUV | 内容 | 集成验证 |
|---|---|---|
| 135-b（本轮） | LLC 融合全链：opcode 27 化（`load-local-const {a: slot, b: const-idx}`，pops 0/pushes 2）+ VM 双压臂 + verify Pass 1 双边界 + .krf 往返 + C 后端复合 + compile args 环视特判 + compiler.ktf 孪生同步 + 守卫再生成 + 新族 ≥8 + audit AQ 10 案 + B 轴三跑 | 融合/非融合同程序同值双臂 + 全语料 sweep 零残留对 + gate B 逐位 + fixpoint 自复现 |
| r136 ✓（W-REC-DEPTH 刀 1 @ v0.97.0） | 堆激活栈基座（已交付）：VM 帧栈从宿主递归栈解耦（显式帧栈 + 循环主循环既有形态的深度面扩展）+ EVAL_DEPTH_LIMIT 帽解除为内存预算治理 + eval 引擎闭包应用路径对齐 | 深非尾递归仅受内存约束（构造 10^5 深度程序实测）+ 深尾递归恒定栈高 + D-CLASS-1 三元组逐位维持 |
| r136+ ✓（W-REC-DEPTH 刀 2 @ v0.98.0） | 四层帽可配置护栏（已交付）：reader 256/expander 512/compiler 1024/pkg 512 全部 `with_limit` 参数化 + 保守默认逐位维持 + driver `DepthLimits` env 单源消费（三键 + kp 独立键，fail-closed 解析）+ **r74/r85 VM-only 括号全链退役**（fixpoint step-3 双引擎化 + composed junction-1 双引擎化 + harness-limit 分类回归守卫化——C3 第三验收腿「fixpoint 无括号自建」达成）+ 四层谱系文档对账（原则 58：默认保留 + 可配置） | 深嵌套语料（600 深）读入实测 ✓ + 默认帽黄金零漂移 ✓ + fixpoint 无括号双引擎 ✓ + 全语料回归 1586:0:4 ✓ |
| r141 ✓（tier-1 刀 1 @ v0.102.0） | 方法编译基础设施（已交付）：census per-function 调用计数阈值 64〔MJ-2〕+ closure chain 去分派执行形〔MJ-1——节点 1:1 镜像臂，构造性 parity〕+ 永久回退〔失败无重试〕+ canonical listing 确定性〔MJ-4〕+ run_dispatch loop-top 引擎选择 + OBSERVE 驱动器单化〔MJ-3〕 | 双路同值〔值/输出/allocations 逐位——阈值 MAX vs 1 vs 默认 64〕+ 回退触发实测〔构建器三拒绝面直调〕+ 确定性〔两次构建 listing 逐位相等〕+ 全树 1607 绿〔fixpoint/gate B/parity/census 锚在 tier 开启态〕 |
| r138+（tier-1 刀 2） | tier 分派集成（tier-0.5 融合层与方法层协作）+ 守卫族 + audit 新节 + B 轴对照 tier-0.5 收尾基线 + 三触发器复画像 | B2 带内 + 分派份额复画像 + T-a 链路复画像 |

### 4.2 W-TGT-READ-TWIN（目标皮肤读链孪生窗——新登记）

| MUV | 内容 | 集成验证 |
|---|---|---|
| 刀 1 ✓（twin 语义面 @ v0.97.0） | target lexer 孪生（已交付）：`crates/kerf-reader/src/target/lexer.rs` 的 .ktf 全量镜像（trivia/拒绝集/操作符规范名表/数字文法）为 target-lexer.ktf；字节表注入通道消费（RS-1 形制沿袭） | 孪生/Rust oracle token 流逐位（全语料 + .ktf 自源族 + 拒绝集边界族） |
| 刀 2 ✓（parser 孪生 @ v0.99.0） | target Pratt parser 孪生（已交付）：target-parser.ktf 3,281 行（帧机形制——14 级优先级瀑布 + do/let 反向折叠 + quote datum 载体 + 模式族 + 类型注解 drop + 胖关键字全表 + fail-closed UnsupportedTargetForm 面；TP-1 注入通道[token 记录表/嵌套限/消息文本表 21 键]） | curated 91/91（正 50/负 41）+ selfhost 九源固定点（含孪生自身源最深自应用）+ 拒绝面 ≥35 同键 + audit AU 族 10 案（370/370） |
| 刀 3 ✓（C1 链路闭合 @ v0.100.0） | 已交付：SteadyTargetReaderChain[两孪生各编译一次——lexer 程序 target-lexer.ktf 引用 source-bytes 槽；parser 程序 = tp-forms 表 + tp-limit 256 常量 + target-parser.ktf 引用 tp-tokens 槽；每读四引擎跑（lexer vm+eval → K20 桥 → parser vm+eval）] + 读段自应用[selfhost 九源 + 孪生自身 3,281 行——最深固定点] + 组成链扩展[composed_target_read_chain：J0 token/J0.5 tree/J1 expand（稳态展开链——值面无 r103 文本边界）/J1.5 check（SteadyCheckChain——查段入组成链）/J2 compile（ktf_compile_rich 终端字节码等同）] + fixpoint 纯度腿[Phase-2 assembled 自应用程序读经孪生前端 twin_front_end_read == 生产桥 items 断言] | 自源 parity（engines agree + forms 重建）+ 组成链等价（91 curated + 九源 + 组装展开器程序全公式）+ fixpoint 复现（b_self_exec == b_self 维持 + 孪生读段新腿）+ AV 族 10 案 380/380 |

### 4.3 T-a 切换窗（G4——r143 开窗对账落档）

**r143 开窗对账：前置全凑齐**（G1 ✓ + G2 ✓ + G3 裁决完成〔r142〕+ TD-027 ✓〔r143 清偿〕）→ **T-a 开窗合法成立**。

**K159 五步排期**（§5 单源的操作化）：
- **step ① 种子链固化〔r143 ✓ 落档〕**：宪制排除项清点表 = ①VM 永久 Rust 基座（kerf-vm——"完全自举"VM 重写 = 宪制排除项，原则 53）；②构建引导层（cargo + r124 宪法性排除裁定）；③链外后端（C/LLVM/QBE——W-3.8 家位，永不入自举链）；④oracle 验证面（Rust 各段退役为 parity oracle——E5 同构先例，验证面保留）。种子工件清点表 = ①Rust 编译器（生产位全树 12 crates）；②孪生九件（lexer/reader/macro/expander/infer/typecheck/compiler + target-lexer/target-parser——14,243+ 行台账，s-expr-conversion-record.md 单源）；③注入通道（INJ-1..INJ-5：inject_global + fail-closed 三面 + 稳态链形制）；④组成链（composed_target_read_chain J0 token → J0.5 tree → J1 expand → J1.5 check → J2 compile——五联差分 pipeline_ktf(S) == pipeline_rust(S)）；⑤fixpoint（b_self_exec == b_self + 深自应用 + 读段孪生前端）。
- **step ② A/B/C 工件管线〔r144 ✓ 交付 @ v0.105.0〕**：A = Rust 编译器以普通生产管线编译六 CCF（链可编译形——extern 槽声明 + 孪生源）；B = 孪生链（骑 A 工件、VM 臂、注入通道 + SteadyCompilerChain）编译链自身；C = 同链形骑 B 工件再编译。**B ≡ C 位级六工件全过**（A ≡ B parity 观察行同真）——w-t-a-switch-window.md §2 单源（TA-1 CCF 形制 + TA-2 三轮操作化 + TA-3 四缺陷清偿 + TA-4 编译段稳态形）。
- **step ③ 不动点门〔r144 ✓ 与 step ② 同轮交付〕**：B ≡ C 位级（K159：不动点 = 验证门非构建步骤）——六工件 Bytecode PartialEq 全描述符表 + golden 集成测试承载（~325s release——十二次全链自编译上 VM）。
- **step ④ 分段生产位切换**：read → expand → check → compile 逐段（每段：孪生为生产位 + Rust 段退役为 oracle + 全语料 parity 门 + 段级回退带〔§14.6.4 规则 5 测量先行〕）。**read ✓（r145）+ expand ✓（r146）+ check ✓（r147）——compile 段 = r148 下一刀**。
- **step ⑤ 工作流宣告**：C1/C2 验收 + K140 带如实登记（切换性能回退接受 + 收窄后置——Go 1.5 先例）。

**r144 交付实态**：step ②+③ ✓（v0.105.0）；下一刀 = step ④ 分段生产位切换（read → expand → check → compile 逐段——w-t-a-switch-window §3 排期）；四缺陷清偿单源 = 同档 §2 TA-3 + K163 新锚（新输入域即新审计域）。

**K140 带组合面重审结论（r143）**：~10× 惨案带**维持为 step ⑤ 验收带**；达成路径诚实化 = 链内最优形态已锁定（纯解释 + LLC——r142 实测裁决，链内无杠杆/结构性天花板登记），10× 内达成依赖 ①稳态链摊销口径（编译孪生一次 + N 次读/展/查/编——§6 测量计划）+ ②A/B/C 工件实测（真实链路带在 step ② 落地时落档）+ ③〔可选〕W-3.8 链外加速（宪制排除项外家位）。**开窗轮不预设达标时点**（时间治理红线一：信号驱动非日历驱动）。

**LLC 链内退役/维持重审裁定（r143 ARCH-A——r142 改判登记的延后重审兑现）**：**LLC 维持在位**。机制区分 = LLC 是编译期静态字节码融合（零运行时分派开销），与被 r142 实测证伪的运行时 tier 分派（closure chain 净负 ~9%）不同机制类——r142 证伪的是「兑现载体」非融合指令本身；账面 = r135 融合刀 +3% 墙时实测未被证伪（链内唯一实测正收益机制），退役成本 = opcode 27 全链回退（VM 27 臂 + verify + .krf 往返 + C 后端 + compiler.ktf 孪生 + AQ 族守卫 + B 轴基线）远超 3% 墙时差；再重审时点 = W-3.8 真 codegen 窗（届时融合产物有 codegen 消费面）。

### 4.4 W-SEXP-RETIRE（S-expr 脚手架拆除窗——r140 新登记；G7；R5 生命周期拆除位）

> 前置 = T-a 切换窗 step ④ read 段生产位（孪生读链为生产位——拆除权发生位）+ TD-027 清偿（展开孪生 match 臂——T-a 前置门在册，r139 登记）。技术锚：SOP §2.2 原则 41/53（脚手架生命周期 + VM 基座宪制排除）+ R5 拆除判据（自建替代 ≥ 被替换物 × 98% 或额外能力 > 0——target 读链全语料覆盖 + 类型注解语法/胖关键字额外能力，双臂满足）+ r114 TD-007 转码器机械臂先例（skin_transcoder.rs——.krf→.ktf 语料迁移的既有工具面）+ E5 批次 3 一次性移除先例（r104——拆除纪律形制：替代链完整证明先于拆除）。

| MUV | 内容 | 集成验证 |
|---|---|---|
| 刀 1（语料单皮肤迁移）✓ r150 | 全语料 .krf→.ktf 转码 sweep（curated 62+ 案 + parity 契约面 + gate B 语料源 + corpus 期望面——skin_transcoder 机械臂扩展 + 逐案双皮肤等价预检）| 迁移后全语料 .ktf 单皮肤 sweep 等价（值/输出/拒绝三面）+ 双引擎 parity 维持 + 双跑确定性〔✓ 实测：109 案 sweep + 消费面 14 文件全绿 + C 回放 52/52 + 组成链账目 16/23/11/57/2 = 109〕|
| 刀 2（S-expr 读链退役） | Rust S-expr lexer/parser 退役为 oracle 验证面→移除 + reader.ktf 孪生退役（parity 职能终结）+ bootstrap/reader_parity.rs harness 收编 + driver 双皮肤分支收口 | 全测试树绿 + audit 族共变 + fixpoint 经目标读链维持（b_self_exec == b_self）+ gate B 逐位 |
| 刀 3（S-expr 面清零） | 全树词面清零扫描（S-expr 皮肤关键词/读取入口/双皮肤分支/转码器——rg 机检入守卫）+ subset-spec 状态行改写（双皮肤→单皮肤终态）+ 文档族对账（本计划 + stage0 + 台账三处单源） | 清零扫描守卫化（回归 = 任何 S-expr 表面复活即红）+ §8.5 文档检查单全过 + R8 编码面清零 |
| 出口 | 词法语法语义全目标语言单皮肤（用户指令⑥终态）+ R5 拆除判据核验双臂落档 | 单皮肤全语料 + fixpoint + 六命令全绿 |

### 4.5 W-LANG-FOUNDATION（语言基础完备窗——r140 新登记；G8；自举完备后首议程）

> 前置 = 自举完备验收（§1 C1-C4 + 单皮肤终态——序 7 从属位解除）+ TD-027（match 臂——enum 脱糖消费前置）+ TD-026 重审（堆类型 extern 扩展面开窗时随 R-F3 句柄协议——struct 表示跨 FFI 面）。技术锚：stage0 §9.14.2（类型系统成员三组——R4 实况对账）+ §7.4（内部语法 ADT 设计——7.4.3 2026 内部 AST 完整定义）+ §6.10（类型维前沿成熟度 ~30%——行多态评估非实施）+ tool-results/r76-search/（HM unify 家族七件：m1-rustc-unify_key.rs / m3-ghc-unify.hs / m4-rustc-relate.rs / m11-ocaml-btype.ml + value restriction q4）+ K140-K142（自举后语言自我发展先例族——Go 1.5 双链解耦 / rustc 2011 先自举后 1.0 稳定 / bootstrappable builds）+ subset-spec §2.1（语义面扩展经语义同刀 MUV 合法行使先例——Stage 2.1 翻转形制）。**时机裁定全链见 §9。**

| MUV | 内容 | 集成验证 |
|---|---|---|
| 刀 1（类型注解消费面） | parse_type_drop → 注解验证锚（「annotations are surface sugar the HM layer owns」后半句兑现：HM 推断 × 注解双向检查[标注-推断 unify——注解锚定收敛 TVar]；注解错误族 + 诊断码 + 位置面） | 注解程序正负语料（注解✓推断分歧 = 错误族）+ parity + audit 新节 + 双引擎面 |
| 刀 2（struct 表面 + 脱糖）✓ @ r166 | struct 声明 → 构造子/字段访问函数宏展开（**GZ-2 裁定：pair 链右折 nil 终结零标记**——vector 宪制排除；**GZ-3 裁定：Type::Struct(Symbol) 名义承载 + 透明展开 unify**——无同名特判保守纪律 + Display 名字单显示 + 生成注解全量复用刀 1 机制）+ TD-026 闭账（R-F3 协议草图 + W-HEAP-EXTERN 登记窗承载）| struct 程序正负语料 ✓（13 案 1:3.3 + 人口 125→138 + C 重放三方一致）+ fixpoint 维持 ✓（20/20 release——孪生自应用最深面）+ gate B ✓（sweep 零漂移）+ audit ✓（460/460 live）|
| 刀 3（enum 表面 + 脱糖）✅ **交付 @ r168**（裁定 a + b1-b4 五 MUV——GZ-4 展开期单段执法 + 表示/模式/Type 三裁定〔窗口档 §10〕） | tagged 构造子 + match 消费（oracle expand_match 既有超集——TD-027 清偿后孪生全量）+ 穷尽性检查面 ✅ | enum 程序正负语料 ✅（16 案 1:3 + subset 157/157 + T0 29 + T1 52 族）+ audit ✅（close 轮 T2） |
| 刀 4（模式匹配扩展 + 行多态评估）✓ **交付 @ r170——窗口 CLOSED**（struct 模式族收口〔双查表消歧 + 零位移 + 三判式〕+ GZ-5 评估档案〔W-ROW-POLY 登记〕） | struct/enum 模式族收口（展开器首元素双查表 + 读链 3+ 元组放行迁移）+ 行多态评估窗（§6.10 前沿 ~30% 成熟度——评估非实施，产出 = 判据 + 时机触发器登记）| 模式族语料 ✓（16 案 1:3 + subset 173/173）+ 评估窗档案 ✓（窗口档 §11.2）+ audit ✓（BF01/BF04/V3 共变）|
| 后续（登记态——零信号不开窗） | 效应族六官方实例（Read/Write/State/Async/Error/Log——§9.14.2 效应成员）+ 自定义效应语法 + 能力模型 L3（原则 34）+ 线性类型——各按独立窗单源排期 | 各窗单源定义 |

**工作流声明**：本窗全部实施经自托管工作流进行（编辑 .ktf → kerf 编译 → 测试/基准经 VM——C4 面的首个生产消费）；每刀交付物含 .ktf 自描述测试语料（语言经自身语言验证自身新能力——「自己用自己语言推进自己」的逐刀实证）。

## 5. T-a 切换窗五步（K159 操作化——种子→全量→自重建不动点）

```text
步骤 ①（种子链固化）   宪制排除项清点表落档（VM 基座/构建引导/链外后端/oracle 面）
                      + 种子工件 = Rust 编译器 + 孪生七件 + 目标读链孪生（W-TGT-READ-TWIN 产物）
步骤 ②（A/B/C 工件管线） A = Rust 编译器编译孪生链产物（今日既有形态）
                      B = 孪生链（经 A 产物运行）编译孪生链自身
                      C = 孪生链（经 B 产物运行）再编译自身
步骤 ③（不动点门）     B ≡ C 位级（K159：不动点 = 验证门非构建步骤；链条定长 A→B→C 工件显式）
步骤 ④（分段生产位切换） read → expand → check → compile 逐段切换（每段：孪生为生产位 + Rust 段退役为
                      oracle + 该段全语料 parity 门 + 回退带〔段级可回退——§14.6.4 规则 5 测量先行〕）
步骤 ⑤（工作流宣告）✓  开发工作流经 kerf 自身（编辑 .ktf → kerf 编译 → 测试/基准经 VM）实录落档
                      + C1/C2 验收 + K140 带如实登记（切换性能回退接受 + 收窄后置——Go 1.5 先例）
                      〔r149 交付：selfcheck+bench 语料 + 三跑 + C1-C4 对账全绿——T-a 窗口 CLOSED〕
```

## 6. 测量计划（T-a 链路度量操作化）

- **T-a 链路指标**：稳态链摊销口径（编译孪生一次 + N 次读/展/查/编）下，全语料吞吐 vs Rust 全链——既有 w312a 三份额分相形制扩展至四段全链（read/expand/check/compile 各段份额披露）。
- **阈值**：切换窗开窗前置 = JIT 窗出口（≤25×）；切换验收 = K140 带（~10× 惨案带接受 + 稳态摊销口径如实披露；<10× 收窄后置为切换后工程——非前置）。
- **诚实边界**：三杠杆合计预估 ~0.60×（B 轴）→ T-a ~275×；tier-1 2.5-3× → ~90-135×——**组合面仍需 W-REC-DEPTH 深度约束解除（自举链工程可用性）+ 目标读链（链路纯度）+ 稳态摊销口径三者的乘积效应实测**，本计划不预设达标时点（时间治理红线一：信号驱动非日历驱动）。

## 7. W-PKG-SELFHOST 触发器反冻结重审（用户「禁止冻结」指令 × r115 触发器设计的冲突裁定）

**冲突**：r115 PKG-2 登记 W-PKG-SELFHOST 双前置 = 「融合刀交付后（已达成 r134）」+「功能冻结」；用户常设指令 = 当前项目**禁止冻结**（活跃开发期，一切为最终结果让路）——「功能冻结」作为触发器在禁止冻结政策下永不满足 = 触发器设计失效（冻结导致的历史问题重审——用户指令原文「如果之前的设计中存在因为冻结导致的问题则可对其重新审理」）。

**重审裁定（ARCH-A @ r135）**：前置二从「功能冻结」改写为「**manifest 子集实证稳定**」——判据 = `kerf.toml`/`kerf.lock` 文法（micro-TOML 六形）与 semver 边界在最近 N 轮（N ≥ 5）零变更 + pkg 语料回归全绿（可机检锚，非政策性冻结）。**依据**：原前置的设计意图 = 防止自举一个文法仍在变动的包管理器（返工面）——实证稳定判据同达意图且不与禁止冻结政策冲突（§12 最优>最小：判据可审计可机检优于政策性口号）。**排期维持 K161 解耦**（PM 自举后置于 T-a——§3 序 4）；tech-debt-register 行同步改写。

## 8. 每轮复核义务（用户常设指令⑨——禁止过度特化 + 未解决问题阻断）

每轮执行本计划时复核：①本窗未解决问题数（>0 = 禁止推进下一窗——§21.12 段序硬规则）②通解性审查（融合/深度/JIT 形态均为通用机制非位点特化——r134 反过度特化审查形制）③登记窗触发器核对（tech-debt-register 台账与本计划 §3 序一致性）④完成标准 C1-C4 进度对账（本表随轮刷新）。

**r140 复核实态（规划刷新轮）**：①本窗未解决问题 = W-JIT-METHOD-T1 tier-1 两刀（排期内下一入口非阻断）+ TD-027（T-a 前置门在册）+ TD-026（riding——堆类型 extern 扩展面门条件）——零未登记问题；②通解性 = 本轮交付全为规划域通解（窗序/缺口入账/台账/裁定），无位点特化——两新窗均为机制窗非特化窗（拆除窗 = 脚手架生命周期通用拆除；语言基础窗 = 类型系统成员通设面）；③登记窗核对 = W-SEXP-RETIRE/W-LANG-FOUNDATION 两新登记（tech-debt r140 检视节）与本计划 §3 序 4/序 7 一致；④进度对账 = C1 ✓（r139）/ C3 ✓（r137）/ C2 ✗（T-a 未开——前置 G1 ✓ + G2 ✓ + G3 在窗）/ C4 ✗（随 C2）。

**r142 复核实态（tier-1 刀 2 出口轮）**：①本窗未解决问题 = 零（W-JIT-METHOD-T1 三刀全交付 + 出口裁定落档 = 窗口 CLOSED；下一窗 TD-027〔T-a 前置门〕+ T-a 切换窗开窗对账）；②通解性 = 刀 2 交付全为机制面（生产默认翻转/early-out/测量面双臂/守卫族）——零位点特化（默认翻转影响全程序非特化程序；测量工具升级为通用对照面）；③登记窗核对 = W-JIT-METHOD-T1 CLOSED（本计划 §3 序 1 + tech-debt r142 检视节 + w-jit-method-t1-window v1.2 Status 三处一致）；④进度对账 = C1 ✓（r139）/ C3 ✓（r137）/ C2 ✗（T-a 未开——前置 G1 ✓ + G2 ✓ + G3 裁决完成 → **开窗合法成立，下一入口 = T-a 切换窗开窗轮 + TD-027 前置门**）/ C4 ✗（随 C2）；⑤LLC 杠杆改判登记 = 墙时净负资产（r135 +3% 维持 + tier-1 兑现载体实测否决）——链内退役/维持延后 T-a 开窗轮重审（opcode 全链回退成本 vs 墙时 3% 的权衡在切换窗组合面裁定）。

**r155 复核实态（W-PKG-SELFHOST 开窗轮——用户常设指令⑨逐项）**：①本窗未解决问题 = 零（判据机检三面全绿超额〔七轮零变更 + pkg_window 8/8 + lib 41/41〕+ 承载裁定落档 + 四刀序排期；刀 1 = 排期内下一入口非阻断——W-SEXP-RETIRE 已 CLOSED 零遗留）；②通解性 = 本轮交付全为规划域通解（判据机检方法〔git 基线直接对照法——可复用于任何 crate 的零变更证明〕+ 裁定论据〔六论据均为机制级非位点特化〕+ 四刀序 = 窗口级通用迁移形制〔parity 双臂 + 三态回退带——r145-r148 先例复用〕）；③登记窗核对 = W-PKG-SELFHOST 开窗（本计划 §3 序 5 + §2 G5 行 + w-pkg-selfhost-window v1.0 三处一致）+ G6 行 T-a 陈旧表述顺修（§8.4.5 以实况为准）；④进度对账 = C1 ✓ / C3 ✓ / C2 ✓ / C4 ✓（r149 全绿维持）/ G7 ✓（r154）/ **G5 行权开启（r155——判据面闭合，承载面四刀排期）** / G6 待（T-a ✓ 行权排期确认）/ G8 待（验收后）；⑤W-EVAL-RETIRE 排期确认（T-a ✓ r149 + T-b 已消费 r121 → G5 闭合后行权——序 6）。

**r164 复核实态（W-LANG-FOUNDATION 开窗行权轮——用户常设指令⑨逐项）**：①本窗未解决问题 = 零（开窗议程四件全交付：§13.1 设计对齐〔窗口档 §2——实况对账三面 + 灰区决策表 GZ-1..GZ-5 刀内裁定判据前置〕+ TD-026 重审〔riding 维持 + 门条件精化 = 刀 2 开窗时点 R-F3——刀 1 零 FFI 触碰不触发门条件〕+ 注解消费面重勘〔Rust 面 4 位点 + 孪生双函数 tp_give/tp_step_type_drop + typecheck 锚点 + 传递消费面〕+ 窗口档 v1.0 + 刀 1 排期 r165——排期内下一入口非阻断）；②通解性 = 本轮交付全为规划域通解（灰区决策表 = 刀级通用判据非位点特化；消费面重勘 = 全注解文法面清点非单点位；TD-026 门条件精化 = 窗口级连续性义务非位点豁免）；③登记窗核对 = W-LANG-FOUNDATION OPEN（窗口档 v1.0 + 本计划 §3 序 7 + tech-debt r164 检视三处一致）；④进度对账 = **C1-C4 ✓（r163 终态维持）+ G1-G7 全 ✓ 终态 + G8 开窗行权中（刀 1 = r165）**；⑤时机裁定继承 = §9 三条件 @ r164 全部消解（串行自举纪律条件已随验收 GO 消解——开窗时机成熟零遗留阻断）。

**r166 复核实态（W-LANG-FOUNDATION 刀 2 交付轮——用户常设指令⑨逐项）**：①本窗未解决问题 = 零（刀 2 四 MUV 全交付〔读链/展开器/推断层/语料族——四独立提交链〕+ 三裁定落档〔GZ-2/GZ-3/TD-026 闭账〕；刀 3 = 排期内下一入口非阻断）；②通解性 = 刀 2 交付全为机制面通解（pair 链表示 = 全 struct 通用形制非位点特化；透明展开 unify = 类型层单点扩展〔resolve 表 + unify 五臂〕非逐位特判；生成注解全量复用刀 1 机制 = 锚定即执法非发明诊断；r127 标量崩溃面 = 同族全量清偿〔pair/fn 臂一并〕非单点修复）；③登记窗核对 = W-LANG-FOUNDATION OPEN 刀 2 交付（窗口档 v1.2 + 本计划 §3 序 7 + tech-debt r166 检视三处一致）+ **W-HEAP-EXTERN 新登记**（TD-026 闭账承载位——w3.2 §5 三件与本计划 §2 G8 行一致）+ TD-026 闭账三处一致（tech-debt r166 检视 + 窗口档 §9.1 + w3.2 §5）；④进度对账 = **C1-C4 ✓（r163 终态维持——刀 2 零回归：语料 sweep 125→138 零漂移 + fixpoint 20/20 + audit 460/460 live）+ G1-G7 全 ✓ 终态 + G8 刀 2/4（刀 3 = 下一入口 r167）**；⑤台账纪律 = docs/worklog.md 镜像 128 行漂移债当轮清偿（r165-b3 至 r166-b2 七条目补齐——§8.6.1）。

**r195 复核实态（§17 Step 1 扫描轮 + W-SELFHOST-MODERN-2 开窗行权轮——用户常设指令⑨逐项 + 效应族链闭合后自由排期点首行使）**：①本窗未解决问题 = 零（效应族三段链出口判据六条全 ✓ @ r194 零遗留 + P2 双项在册非阻断〔TD-029 第 36 次观测零触发 + 共享污染 std/ 六库零新顶层全局〕；W-SELFHOST-MODERN-2 刀 1 = 排期内下一入口非阻断）；②通解性 = 本轮交付全为规划域通解（消费分类学 C1-C5 = 家族级惯用形转化非位点特化——~900 first/~810 rest 导航位与 ~107 err 穿线位全量勘定非单点位；诚实边界五条 = 窗口级通用判据；零新桥承继 = r174 终局裁定通用形制）；③登记窗核对 = **W-SELFHOST-MODERN-2 OPEN**（w-selfhost-modern2-window v1.0 + 本计划 §3 自由排期区第二段 + tech-debt r195 检视 + 矩阵 v1.21 §7 新行四处一致）+ 11 候选窗触发器逐一核对零信号（并发调度策略窗〔L3 授权〕/语法糖窗〔#15 依赖〕/W-LINEAR-TYPES/W-UNION-INTERSECT/W-COMPTIME/W-HEAP-EXTERN/共享污染 P2/TD-029/横切九窗/W-3.x 族/缺失候选——零信号不开窗维持，非冻结）+ **矩阵计数表三处漏翻同轮清偿**（r180 modern-1 域行+合计 / r189+r194 效应域行——§20.6 披露；工具链 LSP 双态口径 ±1 = 下一矩阵审计轮首项）；④进度对账 = **C1-C4 ✓（r163 终态维持）+ G1-G8 全 ✓ 终态 + 效应族三段链全链 CLOSED @ r194 + 自由排期区第二段 OPEN（W-SELFHOST-MODERN-2 刀 1 = 下一入口 r196+）**；⑤恢复核验 = GitHub 四通道 404（仓库删除/转私有——沿 r186 裁定：本地 = 权威最新零替换；禁查旧 commit 合规——仅 HEAD 四通道）+ 本地 39 提交链完整（kerf 676d234 干净 + fsck 通过 + 双档 worklog 6,280 行 md5 一致 + 环境健康 rust 1.99.1）。

**r181 复核实态（§17 Step 1 扫描轮 + W-ROW-POLY 开窗行权轮 + 完整落地总规划轮——用户常设指令⑨逐项）**：①本窗未解决问题 = 零（G8 后自由排期区 W-SELFHOST-MODERN 出口六条 ✓ @ r180 零遗留 + P2 双项在册非阻断〔TD-029 第 24 次观测零触发 + 共享污染语料已规避〕；W-ROW-POLY 刀 1 = 排期内下一入口非阻断）；②通解性 = 本轮交付全为规划域通解（效应族三段链 = 链式依赖通用形制非位点特化；行合一五规则 = 算法级通用机制〔unify 局部扩展——m6「only affecting unification」锚〕；P1/P2 分级 = 原则 26 成熟度匹配通则应用；r174 冻结裁定首个适用 = 验证面通用形制〔金档/fixpoint/audit〕非本窗特设）；③登记窗核对 = **W-ROW-POLY OPEN**（w-row-poly-window v1.0 + 本计划 §3 效应族链段 1 + tech-debt r181 检视 + 矩阵 v1.9 §11 首位四处一致）+ 效应机制窗/效应族实例窗链式登记（§3 段 2/段 3）+ 余登记窗族零信号维持（W-LINEAR-TYPES/W-UNION-INTERSECT/W-COMPTIME/W-HEAP-EXTERN/横切九窗/W-3.x 族——完整落地路径经矩阵 §11 触发器观测，非冻结）；④进度对账 = **C1-C4 ✓（r163 终态维持）+ G1-G8 全 ✓ 终态 + 效应族链段 1 OPEN（W-ROW-POLY 刀 1 = 下一入口）**；⑤完整落地总规划兑现 = 用户指令⑥落位（效应族三段链 = 语义完整落地主轴〔效应域 0 交付→六实例〕+ 33 项剩余全景路径入矩阵 §11 + 排期单源本计划 §3）。

**r163 复核实态（自举完备验收轮——用户常设指令⑨逐项 + 收口终账）**：①本窗未解决问题 = 零（六窗全 CLOSED + 验收 GO——窗口序列终结；G8 = 新窗口对象非本序列遗留）；②通解性 = 验收轮零机制变更（9 处 catch-all 注释 = §14.9 整理项）；③登记窗核对 = 窗口序列六窗 CLOSED 与 tech-debt r163 检视三处一致 + G8 开窗就绪声明（深审档案 §9）；④进度对账 = **C1 ✓ / C2 ✓ / C3 ✓ / C4 ✓（r163 复核维持——完成标准宣告达成）+ G1-G7 全 ✓ 终态 + G8 从属位解除**；⑤恢复弧线 = 容器第八次重建（r163-restore——PATH 重挂载零解包形态，repo/git/WIP 全幸存）。

**r160 + r161 复核实态（W-PKG-SELFHOST 刀 4 闭合 + W-EVAL-RETIRE 开窗——用户常设指令⑨逐项；补 r160 欠账）**：①r160 本窗未解决问题 = 零（刀 4 全链交付：kp_corpus 7/7 双臂逐位 + 中位违例缺陷当轮清偿〔conflict-mid-list 第 31 驱动钉〕+ Rust 逻辑臂退役落档 + 出口四条全 ✓ 窗口 CLOSED + G5 闭合入账；TD-029 第六次观测沿披露口径非阻断）；r161 本窗未解决问题 = 零（开窗行权轮纯治理：触发器记账三链 + 消费面重勘 + 退役形态裁定 + 刀 1 排期 r162——排期内下一入口非阻断）；②通解性 = r160 语料回归面 + 中位违例修复均为机制级（违例位分布方法论〔BR-33 同族〕+ 「递归走表丢前缀」族全量清查唯一性证明）；r161 裁定全为机制面（loud-retirement 形制 = --skin 先例复用 + 验证面保留 = 行 4 先例复用 + 桶形钉扎守卫形制延续）；③登记窗核对 = W-PKG-SELFHOST CLOSED（w-pkg-selfhost-window v2.0 + 本计划 v1.22 G5 行 + tech-debt r160 三处一致）+ W-EVAL-RETIRE OPEN（w-eval-retire-window v1.0 + 本计划 v1.23 G6 行 + tech-debt r161 三处一致）；④进度对账 = C1-C4 ✓（r149 维持）/ G1-G5 + G7 ✓ / **G6 开窗行权中（刀 1 = r162）** / G8 待（验收后）；⑤陈旧清偿 = 守卫函数注释 C15/42→C12/39 + w3.6 §4 计数行 r151 缩桶沿革注记（§8.4.5）。

**r159 复核实态（W-PKG-SELFHOST 刀 3 全交付——用户常设指令⑨逐项；本条覆盖 r157-r159 三轮欠账）**：①本窗未解决问题 = 零（刀 3a+3b 两半全交付——每半各走完整刀间纪律链〔§3.3 重切分披露在档〕；四缺陷族七位点当轮清偿 + 探针零残留；TD-029 容器降级第五次观测沿披露口径非阻断）；②通解性 = 刀 3b 交付全为机制面（单自递归 phase 判别 = 顺序绑定子集的通用形态边界〔BR-35〕/ mt_append 裸追加惯例 = 家族级追加语义〔BR-36〕/ dep-dir 父目录约定 = 错误记录最小锚点通则〔BR-37〕——三 BR 均为通用纪律非位点特化；kp 三态回退带 = r145-r148 先例复用）；③登记窗核对 = W-PKG-SELFHOST 刀 3/4（本计划 §3 序 5 + w-pkg-selfhost-window v1.4 + tech-debt r159 检视三处一致）；④进度对账 = C1 ✓ / C3 ✓ / C2 ✓ / C4 ✓（r149 维持）/ G7 ✓ / **G5 刀 3/4（五模块全承载——剩刀 4 退役 + CLOSED）** / G6 待（T-a ✓ 行权排期 = G5 闭合后）/ G8 待（验收后）；⑤文档补链 = r158 版本头三档未刷（stage0/roadmap/本计划）本轮顺带勘正（§8.4.5 文档以代码为准）。

**r154 复核实态（W-SEXP-RETIRE 刀 3 交付轮——用户常设指令⑨逐项）**：①本窗未解决问题 = 零（刀 3 全链交付 + 窗口 CLOSED 出口四条全 ✓；环境受阻四件套全部基线复证非回归——TD-029 在册）；②通解性 = 词面清零为全树机械通解（四子代理分区 + 断言双侧同步）+ TD-028 帧表示迁移为机制面（六推送位统一正规两元条目——非位点特化）+ TEST-5 守卫 = 表面复活全树检测；③登记窗核对 = W-SEXP-RETIRE CLOSED（w-sexp-retire-window v1.3 + 本计划 §3 序 4 + tech-debt r154 检视三处一致）；④进度对账 = C1-C4 ✓ 维持 + G7 ✓ 全拆；⑤台账终态 14,616 行（转化终态 + 拆除完成——s-expr-conversion-record v1.1）。

**r148 复核实态（T-a step ④ compile 段交付轮——step ④ 闭合）**：①本窗未解决问题 = 零（compile 段切换全链交付〔编译孪生链 + co_limit 预算镜像 + K163 第五/六实例 + 孪生三潜在缺陷〕；step ⑤ = 下一刀〔排期内非阻断〕）；②通解性 = 机制面（全 .ktf 生产编译通用 + co_limit 装配前缀 tp_limit/ex_limit 先例 + 通用环境面回退带 + 预算键控缓存 + verify 两法官产品边界——零位点特化）；③登记窗核对 = w-t-a-switch-window v1.4（TA-8 形制单源 + K163 第五/六实例）与 tech-debt r148 检视一致；④进度对账 = C1 ✓ / C3 ✓ / **C2 前半 ✓（K159 门）+ C2 后半 read+expand+check+compile 四段全 ✓（本轮——step ④ 闭合）/ C4 ✗（step ⑤ 宣告 = 下一刀）**；⑤K140 段级切片带 = compile 段三跑落档（compile_segment_profile——curated 1.2× / CCF 1.7× / spine 1.3-1.5×，四段最优，回退带在场，收窄后置）。

**r147 复核实态（T-a step ④ check 段交付轮）**：①本窗未解决问题 = 零（check 段切换全链交付〔双检查孪生链 + 诊断结构化重建 + harness 自检钉位 P0 回归当轮清偿 + K163 第四实例当轮清偿〕；下一刀 = compile 段〔排期内非阻断——SteadyCompilerChain r144 在位〕）；②通解性 = 机制面（全 .ktf 生产检查通用 + 通用环境面回退带 + 注册表单源查表——零位点特化；harness 钉位 = 面类别裁定〔链工件 vs 用户程序〕）；③登记窗核对 = w-t-a-switch-window v1.3（TA-7 形制单源 + harness 钉位裁定）与 tech-debt r147 检视一致；④进度对账 = C1 ✓ / C3 ✓ / **C2 前半 ✓（K159 门）+ C2 后半 read ✓ + expand ✓ + check ✓（本轮）/ compile 段 ✗（排期内）/ C4 ✗（step ⑤）**；⑤K140 段级切片带 = check 段三跑落档（check_segment_profile——curated 1.4-1.5× / CCF 3.8-23× / spine 1.4-4.0×，回退带在场，收窄后置）。

**r146 复核实态（T-a step ④ expand 段交付轮）**：①本窗未解决问题 = 零（expand 段切换全链交付〔junction-2 双拒绝面 + 预算镜像 ex_limit 参数化 + 三种子面钉 + 回退带 + 测量三跑〕+ K163 同族预防位全量〔forms_stream 右脊 dispose 共享化×全注入位〕；下一刀 = check 段〔排期内非阻断〕）；②通解性 = 机制面（全 .ktf 生产展开通用 + 预算镜像 tp_limit 先例 + 通用环境面回退带 + 预算键控缓存——零位点特化）；③登记窗核对 = w-t-a-switch-window v1.2（TA-6 形制单源）与 tech-debt r146 检视一致；④进度对账 = C1 ✓ / C3 ✓ / **C2 前半 ✓（K159 门）+ C2 后半 read ✓ + expand ✓（本轮）/ check+compile 段 ✗（排期内）/ C4 ✗（step ⑤）**；⑤K140 段级切片带 = expand 段三跑落档（expand_segment_profile——回退带在场，收窄后置）。

**r145 复核实态（T-a step ④ read 段交付轮）**：①本窗未解决问题 = 零（read 段切换全链交付 + K163 三同族缺陷当轮清偿 + 测量三跑落档；下一刀 = expand 段〔排期内非阻断〕）；②通解性 = 机制面（全 .ktf 生产读通用 + 通用环境面回退带 + 帽键控缓存——零位点特化）；③登记窗核对 = w-t-a-switch-window v1.1（TA-5 形制单源 + K163 第二实例）与 tech-debt r145 检视一致；④进度对账 = C1 ✓ / C3 ✓ / **C2 前半 ✓（K159 门）+ C2 后半 read 段 ✓（本轮）/ expand+check+compile 段 ✗（排期内）/ C4 ✗（step ⑤）**；⑤K140 段级切片带 = read 段三跑落档（每读 240-990× + 链构造 ~30ms——回退带在场，收窄后置）。

**r144 复核实态（T-a step ②+③ 交付轮）**：①本窗未解决问题 = 零（step ② A/B/C + step ③ 门全链交付——B ≡ C 六工件位级；四前置缺陷当轮清偿〔join/截断/边序/编码〕）；②通解性 = CCF 形制 + 段运行器 + 三轮驱动全为机制面（六件全链通用，无位点特化）；③登记窗核对 = w-t-a-switch-window.md v1.0 新建（T-a 窗档单源）+ K163 新锚入 stage0 §9.130；④进度对账 = C1 ✓ / C3 ✓ / **C2 前半 ✓（K159 不动点门首证——生产位切换的验证基座就位）** / C2 后半 ✗（step ④ 分段切换 = 下一刀）/ C4 ✗（随 step ⑤）；⑤台账行数共变 = infer.ktf 3,690→3,774（三修复）+ r143 陈旧清偿 expander.ktf 1,671→2,227（TD-027 match 臂补账）——累计 14,243→14,883 实测口径。

**r143 复核实态（TD-027 清偿 + T-a 开窗对账轮）**：①本窗未解决问题 = **TD-027 清偿关闭**（expander.ktf match 臂全链 + J0.9 退役 + 语料 21 案 + 五守卫 + 转码器 + AY 族——tech-debt r143 检视节单源）；②通解性 = match 臂 = oracle 逐决策镜像的机制面（六模式族通设 + 错误顺序钉扎），零位点特化（语料族为模式族全覆盖非特化程序）；③登记窗核对 = TD-027 关闭（tech-debt r143 + 本计划 §2 G4 行 + §4.3 三处一致）；④进度对账 = C1 ✓ / C3 ✓ / C2 ✗（**T-a 开窗合法成立——step ① 落档，step ② A/B/C 工件管线 = r144 首刀**）/ C4 ✗（随 C2）；⑤LLC 重审裁定 = 维持在位（§4.3 裁定段单源——W-3.8 再重审）。

## 9. 目标语言基础类型时点裁定——enum/struct「自举流程零使用」的正面回答（r140 · 用户审查指令）

> **问题原文**：kerf 目标语言当前在编写自举流程中从未出现使用目标语言的基础类型和能力，如 enum、struct……是还未实现还是当前这种好？如果实现为什么不用？如果还不实现那么为什么不实现？是时机未到还是遗忘？
>
> **裁定**：**时机未到（非遗忘、非能力回避）——设计已全量登记 + 语法桥已生产就位 + 语义实现窗法定于 C2 生产位切换之后（§4.5 W-LANG-FOUNDATION）；当下不实现是串行自举纪律（§21.12-28 + 用户指令⑦）的必然结果，且与 8 原语不变性零冲突（struct/enum = 派生表面非原语面）。**

### 9.1 证据链四层

1. **设计登记在位（非遗忘之证一）**：stage0.md §9.14.2 类型系统成员三组提案登记态——基础类型（i8-i64/u8-u64/f32-f64/bool/char/str/`()`）+ **复合（struct/enum）** + 泛型 + 行多态（union）+ 交叉类型 + 行类型 + 效应行 + 线性能力；§9.14.8 F3 裁定行明确「行多态/交叉/开放记录/线性句法 = Stage 2+ 登记态（HM 已生产 r80）」；§7.4 内部语法设计整节（7.4.3 2026 内部 AST 完整定义——类型安全 ADT 与语义化命名）。登记面 20 轮以上持续对账（R4 实况对账行随轮刷新）。
2. **语法桥生产在位（非遗忘之证二）**：target parser `parse_type_drop()`（crates/kerf-reader/src/target/parser.rs:1602——类型注解全族解析后 drop：「annotations are surface sugar the HM layer owns」）。语法层已完整实现（路径/泛型参数/圆括类型表/联合/函数返回/impl·effect 前缀——r138 parser 孪生 3,281 行逐决策镜像含此面），语义层归属 HM（types.rs:20 Type = Int/Float/Bool/Str/Nil/Pair/Arrow/TVar + EffectRow——零用户定义类型）。**桥就位、语义未接 = 显式的「等待接线」状态而非「从未考虑」状态**。
3. **自举流程零使用之因（三层结构性理由）**：
   - **冻结子集 = 自举目标面**：.ktf 孪生写于 subset-spec §1.2 八表达式形式 + §1.1 四声明头（9 CoreExpr 语义原语锚定）。孪生完备性的可验证性（parity 位级 + fixpoint 自复现 + gate B 全语料）依赖子集极小性——每加一个语义面 = Rust oracle + .ktf 孪生双实现 + 双侧审计成本。
   - **串行自举硬规则**（用户指令⑦ + §21.12-28）：前一编译阶段完整完全自举后才进下一阶段。当前阶段 = 编译管道自举完备（C1 ✓ / C3 ✓ / G3 在窗 / G4-G6 + G7 待）；数据类型不是 C1-C4 组成面，且现在实现 = 在宿主依赖态双实现 → 违反串行纪律 + 留双份维护隐患（不完整的自举不是自举——同一纪律的自举前投影）。
   - **生产位切换后语言经自身推进**：C2 后开发工作流 = 编辑 .ktf → kerf 编译 → 测试/基准经 VM。届时 struct/enum 经自身语言实现 =「自己用自己语言推进自己」正型路径——K140（Go 1.5 自举切换后特性经自托管编译器发展）/ K141（rustc 2011 先自举后 0.1 公开与 1.0 稳定）/ K142（bootstrappable——链完备可审计即目标本身）三锚的 kerf 投影。
4. **与 8 原语不变性零冲突**：struct/enum = 表面语法糖——「全部可宏展开为原语组合」（stage0 §9.14.2 语法成员节同款原则：表面关键字编译产物 = 相同核心形式）。数据类型不新增原语（9 CoreExpr 不变——8 原语不变性第 N 轮验证口径持续），类型系统侧 HM+ADT 推断是检查器面扩展（infer/typecheck 段语义面）非内核扩张。内核冻结原则（§3.2 设计约束）与数据类型表面化正交——这正是极小内核设计的意图：丰富度全部生长在派生层。

### 9.2 「当前这样好」的边界（诚实回答）

- **在 C1-C4 完成前**：是——纪律正确性成立（上述三层结构性理由）；提前实现 = 双实现负担 + 串行违例 + 自举链验证面爆炸。
- **作为终态**：否——G8 已入账（§2 缺口表）+ W-LANG-FOUNDATION 已入序（§3 序 7 + §4.5 细粒度 MUV）：语言基础面完备是「语言自我推进」之后的第一个发展议程，不是可无限推迟的摆设。用户指令⑤「将 kerf 语言自身底层和基础内容完成纳入计划」的落位 = 本节 + §4.5。

### 9.3 脱糖示意（伪代码 ×1——登记态示意非冻结面语法承诺）

```text
# surface (target skin——今日已解析: parse_type_drop 消费后丢弃注解)
struct Point { x: int, y: int }
enum Shape { Circle(float), Rect(Point, Point) }

# elaboration (脱糖——零新原语; 表示层 = W-LANG-FOUNDATION 刀 2/刀 3 内裁定)
make_point  = (fn (x y) (pair x (pair y nil)))     # 构造子 = 函数
point_x     = (fn (p) (car p))                      # 字段访问 = 函数
make_circle = (fn (r) (pair 0 (pair r nil)))        # 变体 = 打标签的构造子
# 消费面: match 既有 (oracle expand_match 超集在位——TD-027 孪生臂为 T-a 前置门)
# 类型面: HM 推断 × 注解双向检查 (刀 1——标注-推断 unify 锚定)
```

> 原则 38/44-58 纪律声明：本节为**登记态**规划裁定——零机制变更义务、零新原语、零冻结面触碰；§9.3 伪代码为设计示意，表示层与 Type 构造子形态的实装裁定归属 W-LANG-FOUNDATION 各刀开窗时（§12 最优>最小 + §21.7 能力引入协议行权）。

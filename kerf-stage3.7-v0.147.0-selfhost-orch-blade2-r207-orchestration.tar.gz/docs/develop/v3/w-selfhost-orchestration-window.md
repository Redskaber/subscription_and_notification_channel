# W-SELFHOST-ORCH 自举编排语言内化窗——桥退役与「自己推进自己」收尾链（w-selfhost-orchestration-window.md）

> **Status**: **OPEN @ r205**（v1.2——刀 2 DELIVERED @ r207：序列化面〔MX-1 渲染不对称退役〕——R1-R9 全落位〔§10 裁定表〕：`render-line` 库面全局（builtin 18→19，零新原语——第 162 轮）+ std/render.ktf 第七效应实例词汇包（with_render/perform render——write 先例扩展：副作用在宿主、词汇在语言）+ **语言内 render 金档**（census == 宿主 Display 逐位——数字对数字双钉）+ 四孪生注册表共变〔ex_globals 影子对 + tc_builtin_arity + ti_is_builtin——第 19 全局的四自持表全量共变〕+ 皮肤 Rule K 通道（render_line → render-line 经通用分隔规则，皮肤表零增行）+ C 后端 k_display_into 镜像臂（前向声明形制）+ ef-render 语料族 8 案〔2+6 = 1:3〕+ render_vocab 新族 3 案 + audit Section BL 10 案〔512→522 live〕+ 实例族六化〔40→48 案 12:36〕+ TD-032 expander 金档再生成（r203 纪律）；T0 31/31 + 实例族 + C e2e 全绿；金链 v0.147.0 + 台账 v1.22〔19 件 23,697〕；v1.1——刀 1 DELIVERED @ r206：import 表面〔组合桥退役〕——O1-O9 全落位〔§9 裁定表〕：关键字双形 + composer 首见组合〔M49 种子可读性边界当轮修订——verbatim 披露形〕+ 单元注册表六件 + 三承载件依赖声明 + 装配迁移三处〔通道位重排披露〕+ **组合产物字节级金档 ×2** + 孪生共变〔解码器双臂 ×2 + kind 三匹配位〕+ 工作负载面迁移 ×3 + 测试新族 9 案 + TD-032 四金档再生成；T0 30/30 + T1 60/60 + 8 原语第 161 轮；金链 v0.146.0 + 台账 v1.21〔18 件 23,618〕；v1.0——开窗行权轮：触发器四件全达成 + 前置门四件全过 + 五刀序落档；本窗 = 自举完备收尾链——装配面/组合面/序列化面/驱动面语言内化 + r124 §6e 议题一边界重勘〔装配前缀族由「编排层宪制排除」重分类为「可退役桥」〕+ M49 重审 + 宪制排除三项重确〔VM Rust 基座 / cargo 构建引导 / 冻结 reader 退位为种子〕；用户指令族驱动：「首先首要做的就是完整完全自举……实现自举语言能自己用自己语言推进自己，而不是一直依赖宿主语言进行」+「自举阶段真的需要每新添加一个需求就添加一座桥吗？……可审查去除不必要的」+「完全脱离宿主语言，通过自身语言来进行自举后所有阶段的设计和开发」〔完成标准〕；知识锚 r205-search 八检索〔rustc x.py 编排谱系 / Go cmd/go 语言内编排正例 / GHC hadrian / dune mini-Dune 种子链 / 语言内测试基建 / Clang-C++20 modules import vs 文本装配 / 最小核字符串处理 / 自举完成定义〕；检索综合 REPORT.md 单源〕
> **流程权威**: docs/sop.md v15.7（§21.12-28 自举完备优先 / §21.12-28③ 完成标准法定 / §2.2 原则 41·53 脚手架拆除判据 / §17 任务规划 / §3.3 演进提案=本档本体 / §18 依赖审查 / §19 打包）
> **依据**: stage0.md §9.25（BS-A 自举策略——最大化前端自举 + VM 永久基座）+ §9.113（K140-K142 自举时序锚）+ §9.64（MOD 裁定族 K102-K106——加载层 Symbol 键统一 + 真 first-seen + last-wins，import 表面的既有语义基座）+ §9.142（五件组合程序形制——本窗刀 1 的改造对象）+ 新增 §9.143（本窗前沿对照与设计层记录——r205 落档）；selfhost/README.md（宿主约定面 = 桥清单单源）；w3.12-frontend-window §6e（r124 议题一原裁定——本窗重勘对象）；w-selfhost-modern2-window §9（STD_ERROR 装配前缀族的逐刀增殖史——用户桥批判的实证面）；用户硬规则（常设指令）：「一个编译阶段完整自举后才能进入下一个编译阶段的自举……不能降级自举，不能功能设计实现都不完整」+「桥审查去除不必要的」+「S-expr 完全移除」+「完全脱离宿主语言完成标准」

## 1. 一行定位

把「装配/组合/序列化/驱动」四类宿主侧桥退役为语言内能力——import 表面（组合桥退役）→ 序列化面（MX-1 渲染不对称退役）→ `kerf-build` 编排器孪生（驱动桥退役——cmd-go/dune 时刻）→ M49 重审 + 装配前缀族退役清扫 → 收口；宪制排除收敛为三项（VM Rust 基座 / cargo 构建引导 r124 / 冻结 reader = 种子+oracle 双位），逐需求增殖桥归零。

## 2. 成熟度口径（现状 + 前沿对照）

**现状（r204 终态）**：生产链 18 件 .ktf 23,493 行全承载（read/expand/infer/check/compile + pkg 五件 + std 六效应实例）；fixpoint B≡C 位级；audit 512 live；自举完备标准 GO @ r163；自举源双现代化完成（modern-1 G8 表面 + modern-2 效应族链表面）；宿主依赖面 = selfhost/README「Hosting conventions」六条（RS-1 字节编码 / parser token 注入 / EX-1 form 流注入 + macro 前置 + 预算全局 / CP-1 items 通道 / pkg 五件依赖序拼接 / verdict 尾绑定）+ STD_ERROR 装配前缀族（modern-2 逐刀增殖——M15/M16、M46、M58、M73、M79 共变链）+ 冻结 Rust reader（M49）+ Rust 测试/parity harness（验证面 = BS-A oracle，合法）+ krf_reformat.py（tools/selfhost，自研工具）。

**前沿对照（r205-search REPORT.md §1 先例矩阵）**：Go cmd/go（编排全语言内——构建/测试/模块加载同为 Go 程序）· dune（OCaml——boot/bootstrap.ml mini-Dune 种子链后全语言内自建）· GHC hadrian（Haskell——2022 年 Make→hadrian 迁移完成）= 四大先例三例语言内编排；rust x.py = 少数派（Python 薄入口 + Rust bootstrap 核心）。**正确通则**：编排可语言内；宿主侧合法留存 = 小而冻结的种子（Go 1.4 / dune mini-Dune / GHC bootstrap compiler）+ 运行时基座。kerf 既有形制（VM Rust 基座 + 冻结 reader 种子）与该通则同构——缺的是把「逐需求增殖的装配桥」退役为语言内能力。

**桥清单与重分类（ARCH-A @ r205——宪制 vs 脚手架之辨）**：

| # | 桥 | 形制 | r205 重分类 | 依据 |
|---|---|---|---|---|
| 1 | 冻结 Rust reader（链源装载） | M49/r184——r184 时代行词汇前表达力限制；现语言已具行+效应+结构体 | **种子 + oracle 双位**（生产装载种子位合法；oracle 位 = BS-A 验证面合法；M49 表达力边界随刀 4 重审） | 先例矩阵种子原则（§2 REPORT） |
| 2 | 装配前缀族（RS-1/token/EX-1/CP-1/STD_ERROR/budget/verdict 尾） | target_corpus.rs 逐需求注入——modern-2 逐刀增殖实证 | **可退役桥**（有拆除判据的脚手架——原则 41/53） | r124 议题一边界重勘：装配 ≠ 构建编排；多数先例语言内 |
| 3 | 程序组合（macro 前置 / pkg 五件依赖序拼接） | 宿主侧文本拼接——语言内 import 表面缺失的代偿 | **可退役桥**（刀 1 对象） | Clang/C++20 modules：文本装配 = 遗留形制 |
| 4 | 序列化不对称（值→字节仅宿主侧） | MX-1——rendering stays host-side | **可退役桥**（刀 2 对象——Write 效应宿主通道既有形制） | std/read.ktf read_line 宿主通道先例 |
| 5 | 驱动编排（段链衔接/工件写出） | Rust composed/steady 驱动 | **可退役桥**（刀 3 对象——kerf-build 孪生） | cmd-go/dune/hadrian 先例 |
| 6 | VM Rust 基座 + cargo 构建引导 | 用户宪制明文 + r124 核心裁定 | **真宪制排除**（不动） | SOP §2.2 原则 41/53 + r124 |
| 7 | Rust parity/fixpoint/audit harness | BS-A oracle 验证面 | **验证面合法位**（非桥——oracle 与生产链分立是架构） | BS-A 端态定义 |
| 8 | krf_reformat.py（Python 格式工具） | tools/selfhost 自研归档 | 演进项（刀 5 后随语言能力复评） | R4 自研工具纪律 |

## 3. r124 §6e 议题一重勘裁定（ARCH-A @ r205）

**原裁定（r124）**：构建编排 = 宪法性排除（锚 m2 rust x.py「构建编排宿主入口层 + 自举构建系统两层形态——构建编排本体不要求与编译器同语言」）。

**重勘证据（r205-search）**：①先例矩阵 3/4 语言内编排（Go/dune/hadrian），rust 亦仅 Python 薄入口 + Rust bootstrap 核心——m2 锚为少数派且其「三十年不动」表述与 rust src/bootstrap 现状（Rust 化）不符；②原裁定三权衡中「自举链深度（编排 = 链构造器非链成员）」被 Go cmd-go 反例（编排即语言内程序且参与自举链）削弱；③「维护成本 = 零收益面 <2% 份额」未计桥增殖成本——modern-2 六刀 STD_ERROR 装配位逐刀共变（M15/M16→M46→M58→M73→M79）+ harness 共变链（eval_inventory pin 39→31 逐刀退役）为实证：**逐需求桥 = 结构性依赖非零收益**（用户指令点名批判面）。

**重勘裁定**：宪制排除范围**收窄**为「cargo 构建引导层」（r124 核心——workspace 构建不动，Go 1.4 种子层等价物）+ VM Rust 基座（用户宪制）；「装配前缀族 + 程序组合 + 序列化 + 驱动编排」由编排层排除项**重分类为可退役桥**（原则 41/53 脚手架——拆除判据：语言内替代 ≥ 被替换物 × 98% 或额外能力 > 0；可回滚逐桥替换）。**本裁定为代理裁定的范围收窄（非宪制修改）**——行权依据 = 用户显式桥审查指令 + 知识搜索多数先例证据；宪制排除两项（VM/构建引导）零触碰。

## 4. 时机触发器（四件——全达成 @ r205）

1. **用户显式排期**：「放行继续推进和演进」+「首先首要做的就是完整完全自举……实现自举语言能自己用自己语言推进自己」+「自举阶段真的需要每新添加一个需求就添加一座桥吗？……可审查去除不必要的」——三句式同轮到达（r195 同形制四触发器之第 4 件强度）✓
2. **零更高优先自举段**：r204 扫描轮裁定——三候选窗零信号 + 深链自举扩展「零新可扩展段就绪」的前提是装配桥被重分类（本窗即是该前提的实施位）；W-SELFHOST-MODERN-2 CLOSED @ r203 后自举段无在航窗 ✓
3. **验证安全网在位**：fixpoint B≡C 位级（target_fixpoint 8/8 + fixpoint_tests 9/9）+ audit 512 live + r174 冻结裁定三面（金档 + fixpoint + audit）+ 段开关 39/39——桥退役的每一步都有位级对账基线 ✓
4. **语言就绪度**：效应实例 Read/Write 在位（std/read.ktf §8.8 宿主通道形制——I/O 词汇已语言内）+ MOD 加载层语义在位（§9.64 K102-K106 first-seen/last-wans/Symbol 键——import 表面只欠源级语法）+ G8 表面 + 行/效应/结构体全在位（M49 重审的表达力前提）✓

## 5. 开窗前置门（四件——全过 @ r205）

| 门 | 内容 | 状态 |
|---|---|---|
| §3.3 演进提案 | 本档 v1.0 本体（定位/重勘裁定/触发器/刀序/出口） | ✓ |
| 知识搜索先行 | r205-search 八检索 + REPORT.md 综合单源（tool-results/r205-search/） | ✓ |
| 8 原语第 160 轮设计面核对 | 编排器 = 既有孪生组合 + std 词汇包 + 加载层消费——**零新原语**（import 表面 = 源级语法脱糖至加载层——struct/enum/row 先例同形制 K-D 脱糖优先；序列化 = Write 效应宿主通道扩展——read_line 先例同形制；执行工件 = VM 装载宪法位不动）；零通道（§8.8 宿主通道既有）·零 VM 重写·零内核语法增改 | ✓ |
| 孪生可表达性 | 编排器本体 = 普通 kerf 程序（match/pair/效应/struct——G8 表面全覆盖）；开放设计位三处（import 脱糖形制 / 序列化载荷形制 / 编排器 verdict 形制）登记为刀 1/2/3 的 a-MUV 裁定位——不阻塞开窗，阻塞对应刀的 b-MUV | ✓ |

## 6. 刀级 MUV 排期（五刀序——逐刀 parity/fixpoint 门 + 可回滚桥替换）

| 刀 | 对象 | 内容 | 门 |
|---|---|---|---|
| 刀 1 | **import 表面**（组合桥退役）**DELIVERED @ r206**（§9 O1-O9） | a-MUV 裁定（脱糖形制：源级 import 声明 → 加载层 first-seen 组合——Racket 名-路径两分锚 K103；可见性缺失项联动注记）+ b-MUV 实施（expander/loader 消费 + macro+expander 装配与 pkg 五件拼接迁移 import 形制）+ c-MUV 门审 | 组合程序 parity 位级（import 组装 == 宿主拼接产物逐字节）**✓ 金档 ×2** + fixpoint 扩展（import 承载源入 corpus——组合 macro 自编译面 + 裸承载件读扫）+ 全语料回归（T0 30/30 + T1 60/60 + T2 电池）✓ |
| 刀 2 | **序列化面**（MX-1 渲染不对称退役）**DELIVERED @ r207**（§10 R1-R9） | a-MUV 裁定（值→字节 render 经 Write 效应宿主通道——write_line 先例扩展 vs 备选形制权衡；字符串构造 = 效应词汇包设计位非原语位）+ b-MUV 实施（std 序列化词汇包 + 金档对账）| 序列化金档（语言内 render == 宿主 Display 逐位）+ std 效应语料 1:3 正负比（ef-render 8 案 2:6）+ audit 共变（Section BL 10 案——512→522 live）✓ |
| 刀 3 | **kerf-build 编排器孪生**（驱动桥退役——cmd-go/dune 时刻） | a-MUV 裁定（verdict 形制 + 工件载荷形制）+ b-MUV 实施（读〔Read〕→孪生解析→import 组合→编译〔链内〕→写工件〔Write〕——单 .ktf 编排程序）+ c-MUV 门审 | **编排器产物 vs Rust 驱动路径位级对齐**（新 parity 面）+ 编排器入 fixpoint corpus（自编译恒等）+ T0/T1/T2 全量 |
| 刀 4 | **M49 重审 + 装配前缀族退役清扫** | 冻结 Rust reader 退位裁定（生产装载 → 种子位；oracle 位维持——M49 表达力边界以 r205 后语言复评）+ RS-1/token/EX-1/CP-1/STD_ERROR/budget/verdict 尾逐桥退役或 deprecated 标注（可回滚形制）+ 诚实边界重登记（selfhost/README 共变） | 桥清单复审（§2 表逐行状态翻转）+ 全量 parity/fixpoint/audit 维持 + M49 重审裁定落档 |
| 刀 5 | **收口**（close） | 出口判据六条核对 + 桥增殖计数基线落档（逐需求桥 = 0 宪制注记）+ web/打包同步 | 出口六条全 ✓ → 窗口 CLOSED |

## 7. 出口判据（窗口 CLOSED 六条）

1. **装配桥归零**：selfhost/README「Hosting conventions」六条中 RS-1/token/EX-1/CP-1/拼接/verdict 尾全部退役或标注 deprecated + 种子位豁免注记——新增需求不再新增宿主侧装配位（逐需求桥计数 = 0，机检锚落档）
2. **语言内编排实证**：kerf-build 孪生编译 18 件生产链产出工件，与 Rust 驱动路径位级一致（新 parity 面金档）
3. **fixpoint 扩展**：编排器自身入 fixpoint corpus（C_t 扩展语料自应用恒等）
4. **M49 重审落档**：冻结 reader 双位（种子+oracle）终态裁定 + 表达力边界 r205 后语言复评记录
5. **宪制排除收敛注记**：VM Rust 基座 + cargo 构建引导 + 种子装载器三项为终态宪制排除（§3 重勘裁定的收口确认）；r124 §6e 议题一重勘在 w3.12 档共变注记
6. **零降级自举**：每刀 parity/fixpoint/audit 全绿后进次刀（用户硬规则「前一阶段完整自举后才进入下一阶段」刀级适用）；std/ 与生产链全部文件经编排器路径复验

## 8. 零载荷边界

- **VM/执行面零触碰**：工件执行 = 宿主 VM 装载（宪法位）；编排器产出工件数据，不执行工件（执行非编排职责——先例：cmd/go 编译产出二进制，执行由运行时）
- **Rust oracle 零改动承继 r174 冻结裁定**：read_program/expand_program/compile_program/infer-check 对 = 验证面恒在；桥退役以金档 + fixpoint + audit 三面验证（oracle 不动）
- **cargo 构建引导零触碰**：workspace 构建 = cargo（r124 核心）；kerf-build 编排的是**链内程序装配编译**非 workspace 构建（两者分层——cmd/go 与 go 编译器的关系同构）
- **登记态纪律**：可见性（pub/private）= 矩阵 §8 缺失项——刀 1 仅注记联动，实施归其触发器；语言能力窗（线性/联合/comptime 等）= 本窗零消费（Phase β 域）
- **测试基建面**：Rust parity/fixpoint/audit harness = BS-A oracle 验证面（非桥）；语言内测试面 = 刀 3 后的能力复评位（登记态，不在本窗出口判据）

## 9. 刀 1 裁定表（O1-O9——r206 a-MUV 落档：import 表面消费面全量深读 + 脱糖形制裁定）

> 勘定基线：r205 终态（HEAD cb93ff4 清树）。消费面全量深读完成——MOD 加载层（module.rs 522 行：first-seen 先序收集 MOD-2 / Symbol 键 MOD-1 / last-wins MOD-3 / 三色 DFS）/ require 皮肤面（.ktf 拼法 `use "name";` + `use a::b;`——r109 F5 皮肤字典纪律 + parse_use_decl span 含分号）/ 装配位三处（target_corpus:105 expander 族 format! + abc_pipeline:148 expand 段 + pkg_selfhost resolve_twin_program 五件拼接——通道 define 穿插文件段间实证）/ 承载件消费者面（MACRO/EXPANDER/RESOLVE 全消费者清单——读层面 ×8〔五件读扫 + determinism:89 + parser/lexer twin 测试表〕/ 自包含工作负载 ×2〔check_segment_switch:371 macro-twin-20kb parse+typecheck / steady_target_reader:308 twin_front_end_read 读+展〕/ 装配面 ×2 + 中央函数 ×5 调用位）/ `import` 标识符占用 = 零（关键字保留无破坏面）/ 24 关键字表（Rust lexer + 孪生 lexer tl_w_* + 孪生 parser tp_w_*/tp_is_word 三处共变面）。

| # | 裁定 | 内容 | 依据 |
|---|---|---|---|
| O1 | **import 皮肤形制——关键字声明双形** | `import "name";`（字符串形——载荷 verbatim，注册表键即身份，不经皮肤字典）+ `import a::b;`（路径形——段经 lexed 恒等以 `/` 连接）→ Stx `(import "name")`；span = kw_start..semi_end（use 同形）。**关键字保留名**：调用形 `import(...)` 结构性不可达（`import` 入关键字表后不能作标识符/调用头）；关键字表 24→25（Rust lexer + 孪生 lexer + 孪生 parser 三处共变） | K103 名-路径两分（名=装饰、路径=身份）+ r109 F5 纪律推广（组合面乘声明语法非调用语法——防用户 `fn import` 劫持） |
| O2 | **消费分层——组合层独占** | import = **组合层声明**：composer（宿主侧通用机制）为其唯一消费者；expander/loader/ModuleItem/CP-1 记录文法**零触碰**（组合后程序平坦无 import 形）；裸 import 承载源过原始管道 = 既有 TopLevelExpression 拒绝面（fail-closed）；刀 3 编排器成为语言内消费者（Read→孪生解析→import 组合） | K-D 脱糖优先（import 脱糖为组合——struct 脱糖为记录先例）+ 零新原语第 161 轮（零 ModuleItem 变体 = 零 CP-1 记录族扩张 = 三孪生 items 走查零共变） |
| O3 | **composer 形制——form-span 驱动 + 首见组合** | 冻结 reader 读入口源 → 顶层形遍历，`[import, string]` 形 = 组合位（字节区间 = 形 span 含分号）；**首见语义**（§9.64 MOD-2 纪律）：首见位 → 形 span 替换为组合单元文本 verbatim（文件尾 `\n` + 源缺口 `\n` = format! 分隔符**逐字节复现**）；已见位 → 形 span + 尾随单个 `\n` 整体移除（行消失）；递归组合经注册表（闭集可信图——include_str! 编译时常量）+ in-progress 栈环检测（ImportCycle 带路径）+ 未知名 ImportNotFound（fail-closed，R8 小写+反引号）。**〔r206 b-MUV 当轮修订——种子可读性边界（M49）〕**：实施发现行字面量载体（micro-toml/lockfile——r184/r196 行皮肤）超出冻结 Rust reader 文法（其解析 = 孪生链生产位），原裁定的全量 reader 驱动前提不成立；修订为**双层形制**：可读源走 form 遍历（全部 import 承载件实测可读——expander/macro/resolve/std-error），种子不可读单元 **verbatim 拼接**（无位点遍历直拼 + 产品 `verbatim` 披露字段）；verbatim 载体内若含 import 行则存活至下游展开面响亮拒绝（端到端 fail-closed 非静默跳过）——位级拼接规则与金档断言零变化 | MOD-2 first-seen + MOD-8 三色 DFS 环检测（组合层同构纪律）+ §2.3-4 报错>静默 + §20.3/§20.6 当轮同类纪律（前提失效当场修订披露） |
| O4 | **单元注册表** | target_corpus.rs `selfhost_unit_source(name)`：六单元 = `std/error` / `macro` / `micro-toml` / `semver` / `manifest` / `lockfile`（刀 1 被引用集）；名 = 语言级单元命名空间（扁平——std/ 带域前缀，v1/ 裸名——布局非身份） | K102 canonical 路径（注册表 = 路径解析面——Stage 0 无文件系统的闭集等价物） |
| O5 | **承载件**（三件加 import 行） | macro.ktf += `import "std/error";`；expander.ktf += `import "std/error";` + `import "macro";`；resolve.ktf += `import "std/error";` + `import "micro-toml";` + `import "semver";` + `import "manifest";` + `import "lockfile";`——各件**真实依赖集**（诚实模块纪律：Go/Racket 每件声明自依赖）；其余 15 件零触碰（单孪生前缀族 = 刀 4 清扫域） | BR-35 顺序绑定（组合序 = 硬正确性约束——首见序复现旧依赖序）+ §12 最优>最小 |
| O6 | **装配迁移三处 + 通道位重排披露** | ① target_corpus:105（expander 族）→ `define(ex_limit, N);\n` + compose(EXPANDER)；② abc:148（expand 段）→ extern + `define(ex_limit, N);\n` + compose；③ resolve_twin_program → 通道 define（source_bytes/rs_depth/rs_table/con_bytes/ver_bytes/lk_entries_in）**合并至装配头** + compose(RESOLVE)。**披露项**：旧布局通道穿插文件段间（con/ver 在 MT-SEMVER 间、lk 在 MANIFEST-LOCKFILE 间）——纯 import 拼接无法复现；通道 define 惰性读位（运行时经 result 尾求值）= 行为惰性；**文件链段逐字节恒等**（compose(entry) == format!("{A}\n{B}\n{entry_rest}") 金档钉扎）+ **产物面恒等**（parity 键/字节码/verdict/fixpoint 全电池） | §9.142 五件形制（组合序保持）+ §2.3-1 正确>妥协（通道位重排诚实披露非静默）+ GATE 5 位级对账 |
| O7 | **孪生共变**（lexer + parser + 解码器） | target-lexer.ktf：tl_w_import 字节表 + tl_word_tag 臂（头注 24→25）；target-parser.ktf：item 分派臂（"kw-import" → import-decl 帧）+ tp_step_import_decl（import-str/import-path 记录——use 机器镜像）+ 词表 tp_w_import/tp_is_word + tp_k_import_path 消息常量；target_parser_parity.rs decode_tp_tree：import-str/import-path 记录臂 → oracle Stx display `(list s e (ident s e import) (string s e "name"))` | 孪生亲执纪律（§21.12-33③）+ 五件读扫/孪生前端读面自动共变（关键字面使裸承载件可读） |
| O8 | **自包含工作负载面迁移 ×2** | check_segment_switch:371（macro-twin-20kb——parse_target+typecheck）与 steady_target_reader:308（twin_front_end_read 读+展 macro.ktf 行）迁移至**组合形**（compose(MACRO) = STD+MACRO 自包含；裸形含 import 行过展开 = TopLevelExpression 拒绝——组合层声明的既定语义非缺陷） | O2 消费分层推论 + §20.3 同类全量（两处同类面一并迁移） |
| O9 | **测试构成 + fixpoint 扩展（GATE 6）** | 新族 import_composer_tests：正向 ≥4（真实金档字节恒等 ×2〔expander 族/resolve 族〕+ 线性链 + 菱形首见去重）+ 负向 ≥3（ImportNotFound / 双向环 / 自环）+ 跨阶段消费 ≥1（组合源过生产桥 read+expand 为真 items）；reader 测试（双形 Stx + 关键字保留拒绝面）；孪生 parity 案例（lexer 关键字分类 + parser import 记录 vs oracle dump）；fixpoint 扩展：五件读扫承载裸形自动入载 + **组合 macro 自编译二次恒等新例**（最小自包含组合单元入 fixpoint corpus——import 承载源经组合入自应用语料）+ determinism guard 组合确定性（composer 纯函数） | GATE 6（正负比 ≥1:3 + 跨阶段 ≥1）+ 窗口刀 1 门（组合程序 parity 位级 + fixpoint 扩展 + 全语料回归） |

**刀 1 门（c-MUV 验收单源）**：① 三绿（fmt 零 diff / check --all-targets 0e0w / clippy -D warnings 零）；② 组合 parity 位级：compose(EXPANDER) == format!("{STD}\n{MACRO}\n{EXPANDER_OLD}") 且 compose(RESOLVE) == format!("{STD}\n{MT}\n{SEMVER}\n{MANIFEST}\n{LOCKFILE}\n{RESOLVE_OLD}")（金档断言入测试）；③ 产物面恒等：expander 族全消费者（segment 开关 39/39 含 expand/read 族 + steady 链 + abc pipeline + determinism + stage_exit）与 pkg 族（resolve parity + kp selfhost 三态 + e2e 双臂）全绿；④ fixpoint 双族维持 + 组合 macro 新例；⑤ T0/T1/T2 fresh（§19.3 无豁免）；⑥ 8 原语第 161 轮（零新原语——import = 源级语法脱糖至组合层，VM/内核/记录文法零触碰）。

## 10. 刀 2 裁定表（R1-R9——r207 a-MUV 落档：序列化面消费面全量深读 + 形制裁定）

> 勘定基线：r206 终态（HEAD d27842a 清树 + 双包 0b4d87c6）。消费面全量深读完成——VM I/O 面（io.rs VmIo：read_line/write_line 双入口 + BufferIo；io.rs 头注「display formatting of arbitrary values is a later library concern, not an I/O primitive semantic」——本刀兑现位）+ 全局注册表面（builtin.rs Builtin::ALL 18 行 + STAGE0_GLOBALS 权威名单 + runtime/eval 共享 dispatch_builtin 双引擎）+ 皮肤通道（skin.rs 显式表 read_line/write_line + Rule K 通用内分隔规则——render_line 经 Rule K 自动映射零表增）+ 宿主渲染位（value.rs Display：i64 十进制 / f64 宿主格式〔诚实边界：浮点格式化恒宿主侧，inf/NaN 含〕/ true/false / 引号字符串 / nil / #<pair>·#<closure>·#<continuation>·#<builtin:name> 不透明标记）+ 孪生四自持表（expander/macro ex_globals 影子对 + typecheck tc_builtin_arity + infer ti_is_builtin——第 19 全局的四表共变义务）+ C 后端镜像（kerf_rt.h k_display_into + k_fmt_double 最短往返浮点镜像）+ 效应实例语料结构（corpus-effect/ ef-* 族 8 案形制 + io-in/io-out 指令 + 四判定臂）+ audit 分节形制（Section BL——BJ 形带通道变体）+ 锁文件字节表先例（lk_num_bytes——已知文法的语言内构造形，本刀备选之一）。

| # | 裁定 | 内容 | 依据 |
|---|---|---|---|
| R1 | **载体形制——`render-line` 库面全局** | builtin 18→19：`render-line`（元数 1，全值类全——值层无失败面；.ktf 皮肤 `render_line`）+ STAGE0_GLOBALS 第 19 行；实现在 builtin.rs `render_line(io, v)`：`io.write_line(&v.to_string())`——宿主 Display 单源经既有 §8.8 出通道发射，返回 nil 确认。**§8.8 通道本体零增**（read_line/write_line 双入口不动——io.rs「later library concern」行兑现为通道之上的库面；零通道〔宿主通道既有〕+ 零新原语〔builtin 类 = read-line/write-line 族兄弟，内核八原语零触碰〕+ 零语法〔全局调用非关键字——reader/parser 孪生零手术、关键字表 25 不变、TD-032 lexer/parser/compiler 金档零再生成〕 | ORCH-D（§9.143：值→字节经 Write 效应宿主通道扩展——read_line 先例同形制；字符串构造 = 效应词汇包设计位非原语位）+ io.rs 头注先见 + 8 原语第 162 轮 |
| R2 | **词汇包形制——std/render.ktf 第七包** | `with_render(program)` 处理 `perform render(dst, value)`；子句体 `render_line(value); k(nil)`——write 先例扩展（宿主调用在子句体、副作用在宿主、resume 于 nil 确认、直续体）；dst 寻址槽诚实注记（read/write 同形）；行类型 `(render (fn (dst value) nil))` 骑箭头四元槽。词汇包纯新写非转化（无 Rust oracle 孪生——r174 桥终结裁定三面验证 + r156 家族不分叉先例） | w-effect-instances-window §5.1 INST-1 通道 (a) 前缀注入 + write.ktf 逐形镜像 |
| R3 | **渲染文法——宿主 Display 单源** | 发射文本 = value.rs Display 上下文无关形（i64 十进制 / f64 宿主格式〔inf/NaN 含〕/ true/false / `"ab"` 引号形 / nil / #<pair> 等不透明标记〔堆解析结构走查非本面包——per-family verdict dumps = harness 自有面，架构位；已知文法字节表形 = lockfile 孪生自有面，生产位不动〕）。宿主每侧单源：Rust `v.to_string()` / C `k_display_into` 镜像（e2e 位级钉） | ORCH-D「身份语言内 + 渲染宿主边缘」（string interning 谱系）+ §12 最优>最小 |
| R4 | **备选形制权衡（披露）** | ①语言内结构字节表 render（lk_num_bytes 先例）——**本刀否决于任意值面**：f64 Display（最短往返格式化）语言内复现 = 荒谬 parity 负担；字节表形维持已知文法面（lockfile 自有）；②纯 resume-at-text builtin（read 先例恢复形——render(v) 返回文本值）——**登记为包未来扩展槽**（零信号不开窗，值→字节经通道一步完成为主形）；③write_line 松绑值载荷——**否决**：strict-string 冻结负面（ef-io-neg-345 + io.rs 文法行）不动，值面走独立入口 | §2.3-11（边界不清→查先例）+ §2.2 原则 38（登记态零信号不开窗）+ §5.4 诚实边界 |
| R5 | **四孪生注册表共变** | 第 19 全局的四自持表全量共变：expander.ktf ex_globals += `render-line`（5,090→5,093）+ macro.ktf 影子对同体（757→760——r201 孪生手术亲执纪律）+ typecheck.ktf tc_builtin_arity += `render-line => {1}`（1,304→1,307）+ infer.ktf ti_is_builtin += `render-line => {true}`（5,532→5,535）；头注 18→19 化四处。TD-032 ccf-expander 金档再生成（macro+expander 入组成源——r203 纪律：源文法扩展→逐 fn 偏移漂移）；lexer/parser/compiler 金档零再生成（源零变更） | §8.4.5 双向对账（文档↔代码）+ §20.3 同类全量（四表一并）+ TD-032 r203 纪律 |
| R6 | **皮肤通道——Rule K 零表增** | `render_line` → `render-line` 经 skin.rs Rule K 通用内分隔规则自动映射；显式表（read_line/write_line/first/rest/pair/eq/set）零增行——新拼写骑通用规则，语料各案按引用钉死（隐式钉）；.ktf 侧检查器 externs 表宿主派生（pipeline_externals ← Builtin::ALL）零表增 | E5 batch-2 Rule K 先例 + §10.1 单源纪律（派生表不复制） |
| R7 | **语料与金档（GATE 6）** | ef-render 族 8 案〔2+6 = 1:3〕：正向 display-census（七值类 io-out 钉）+ direct-style-resume〔字符串显示 = 引号形——实盘勘定修正披露〕；负向 unhandled-render〔正交族〕+ argument-position-nesting〔组合序〕+ confirmation-not-text〔write_line(render_line(v)) strict-string 面钉——值面永不松绑字符串面〕+ arity-face〔checker externals 层 owns——probe 表 dispatch 层为同界另一半〕+ toplevel-render〔E0006〕+ broken-render-syntax〔reader 键〕；render_vocab 新族 3 案（census golden 数字对数字双钉〔发射行 == 宿主 to_string 列表 == 钉死文本三重〕+ markers 扩展〔builtin/closure/continuation——语料形不可构造面〕+ resume 面）；四判定臂全覆盖 | GATE 6（1:3 + 跨阶段 ≥1）+ §9.4.3 分布论证（边界实盘枚举）+ 窗口刀 2 门 |
| R8 | **audit 共变 + C 后端臂** | audit Section BL 10 案（BJ 形带通道变体——输出钉发射显示文本）→ 512→522 live；V6 行 18→19 化（builtin 集基数钉更新）；C 后端：emit.rs builtin_code `KB_RENDERLINE` 臂（穷尽 match 强制）+ shim KBuiltinCode 枚举/名表/前向声明 + k_render_line 体（k_display_into 后定义——单头序约束披露）+ e2e source_render_display_parity 案（双宿主位级钉） | §7.3.3 audit 逐刀扩展先例（BI/BJ/BK）+ C 镜像纪律（display_parity 浮点电池同源） |
| R9 | **金链与层级共变** | 金链 bump v0.146.0→v0.147.0（Cargo.toml + Cargo.lock 13 包 + snapshot assert pin + V6 基数钉）；tier 表 render_vocab_tests T0 行新增（import_composer 先例）+ audit 注记 512→522；实例族六化（六库前缀→RENDER_LIB + 族臂 + 人口门 40→48 + 臂门 12/4/4/24）；机制族排除滤网 ef-render- 扩展；台账 v1.22〔19 件 23,697——std/ 381 + v1/ 23,316〕；selfhost/README 第七行 + MX-1 边界注（渲染不对称退役——词汇在语言、格式化恒宿主侧） | §19.4 显式清单 + §8.4.6 两级落位 + §20.6 当轮全量 |

**刀 2 门（c-MUV 验收单源）**：① 三绿（fmt 零 diff / check --all-targets 0e0w / clippy -D warnings 零）；② 序列化金档：语言内 render == 宿主 Display 逐位（census 发射行 == 宿主 to_string 列表 == 钉死文本——三重钉）；③ 语料 1:3（ef-render 8 案 2:6 + 四臂全覆盖）；④ 四孪生注册表共变全绿（T0/T1 相关族 + 实例族 + C e2e）+ TD-032 ccf-expander 金档再生成；⑤ T0/T1/T2 fresh 全量（§19.3 无豁免——指纹变更后终态二进制全量重跑）；⑥ 8 原语第 162 轮（零新原语·零通道〔§8.8 既有〕·零 VM·零语法〔关键字表 25 不变〕）。

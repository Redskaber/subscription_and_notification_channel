/*
 * kerf_rt.h — the host runtime shim of the kerf C transpilation
 * backend (Stage 2.6, stage0.md §9.92).
 *
 * The emitter (crates/kerf-cbackend/src/emit.rs) pastes this text
 * into every generated .c file ahead of the program data, so each
 * program is ONE self-contained translation unit: `cc prog.c` is the
 * whole build (maximum portability — the r90 adjudication II basis).
 *
 * Scope and boundaries (registered in hidden-problems-assessment.md):
 * - CHAIN-EXTERNAL: nothing here participates in building the kerf
 *   compiler itself; the emitted program never links Rust.
 * - No GC (first cut): the cell arena grows monotonically and the
 *   §19.4 budget fails closed exactly like a collector-less VM — the
 *   VM-vs-C GC fork is a registered boundary, not a divergence
 *   silent face.
 * - Host-stack recursion: kerf calls become C calls, so the recursion
 *   depth is bounded by K_DEPTH_CAP (emitter-computed, overridable)
 *   with a clean fail-closed error instead of a segfault.
 * - Diagnostics are engine-level: messages mirror the VM
 *   RuntimeError families (R8 shapes) but carry no source spans —
 *   span rendering is the Rust driver's diagnostic face.
 *
 * C dialect: C11 + POSIX.1-2008 (getline). No GNU extensions.
 */

#ifndef KERF_RT_H
#define KERF_RT_H

#include <inttypes.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ---------- value model (mirrors kerf_vm::Value, §8.12) ---------- */

typedef enum {
    K_INT = 0,
    K_FLOAT = 1,
    K_BOOL = 2,
    K_STR = 3,
    K_NIL = 4,
    K_PAIR = 5,
    K_CLOSURE = 6,
    K_BUILTIN = 7,
    /* The extern function value (W-3.2): a C-backend-only carrier
     * with no kerf_vm::Value counterpart — the Rust engines reject
     * extern calls at load time (ExternCallRequiresBackend), so the
     * tag exists only on this side of the boundary. `as.ex` indexes
     * the generated extern wrapper table. */
    K_EXTERN = 8,
    K_UNBOUND = 255 /* the never-stored global slot marker */
} KTag;

/* The builtin code space. Declaration order IS the mapping order of
 * kerf_vm::Builtin::ALL (the emitter's variant table is pinned to
 * this order by a unit test; the shim's per-arm arity checks are
 * drift-guarded by the generated wrong-arity e2e family). */
typedef enum {
    KB_ADD,
    KB_SUB,
    KB_MUL,
    KB_DIV,
    KB_LT,
    KB_LE,
    KB_GT,
    KB_GE,
    KB_NUMEQ,
    KB_CAR,
    KB_CDR,
    KB_CONS,
    KB_ISPAIR,
    KB_ISNIL,
    KB_EQ,
    KB_NOT,
    KB_READLINE,
    KB_WRITELINE,
    KB_RENDERLINE
} KBuiltinCode;

/* A string value: pointer + length (bytes survive embedded NULs). */
typedef struct {
    const char *p;
    uint32_t n;
} KStr;

typedef struct {
    uint8_t tag;
    union {
        int64_t i;
        double f;
        int b;
        KStr s;
        uint32_t ref;   /* pair / closure cell index */
        uint8_t bi;     /* builtin code */
        uint32_t ex;    /* extern wrapper index (W-3.2) */
        uint64_t bits;  /* float construction channel (bit-exact) */
    } as;
} KValue;

typedef struct {
    KValue car, cdr;
} KPairCell;

/* Closure cell: proto + captured values in descriptor order (the
 * flat-capture discipline, LA-3). `env` is declared with one slot
 * and over-allocated at runtime (the portable pre-FAM form); the
 * tag on KValue disambiguates the cell kind, so both live in one
 * byte arena addressed by `ref` (an offset, not an index). */
typedef struct {
    uint32_t proto;
    uint32_t ncap;
    KValue env[1];
} KClosureCell;

/* The literal tree (mirrors kerf_core::LiteralValue for pair-shape
 * constants; the emitter materializes leaves as C initializers). */
typedef struct KLit KLit;
struct KLit {
    uint8_t kind; /* 0 int, 1 float, 2 bool, 3 bytes, 4 nil, 5 pair */
    union {
        int64_t i;
        uint64_t bits;
        int b;
        KStr s;
        struct {
            const KLit *car;
            const KLit *cdr;
        } pair;
    } as;
};

/* One constant-pool entry. `cells` is the precomputed pair-cell
 * count (LiteralValue::pair_cells — the single source; the charge
 * mirrors the VM's reserve_exact batch). */
typedef struct {
    uint8_t kind; /* same codes as KLit */
    uint32_t cells;
    union {
        int64_t i;
        uint64_t bits;
        int b;
        KStr s;
        const KLit *lit;
    } as;
} KConst;

/* One installed handler (push-handler entry). */
typedef struct {
    uint32_t effect;
    KValue value;
} KHandler;

typedef struct {
    KValue *globals;
    uint32_t nglobals;
    KHandler *handlers;
    uint32_t nh, hcap;
    unsigned char *arena; /* the cell arena (offset-addressed) */
    uint32_t arena_used, arena_cap;
    uint32_t ncells;      /* logical cell count (budget face) */
    uint32_t budget;      /* live frames + live cells cap (§19.4) */
    uint32_t depth;       /* current kerf call depth */
    uint32_t depth_cap;   /* host-stack guard (emitter-computed) */
    char **out;           /* recorded write-line outputs */
    uint32_t nout, outcap;
} KVm;

/* Generated by the emitter after this shim (single translation
 * unit: declaration here, definition there). */
static KValue k_call(KVm *k, KValue callee, uint32_t argc, KValue *args);

/* ---------- fail-closed exit (R8 family shapes) ---------- */

_Noreturn static void k_fail(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    fputs("kerf: runtime error: ", stderr);
    vfprintf(stderr, fmt, ap);
    fputc('\n', stderr);
    va_end(ap);
    exit(1);
}

_Noreturn static void k_unreachable(const char *what) {
    k_fail("unreachable: %s", what);
}

/* ---------- constructors ---------- */

static KValue k_nil_value(void) {
    KValue v;
    v.tag = K_NIL;
    v.as.bits = 0;
    return v;
}

static KValue k_bool(int b) {
    KValue v;
    v.tag = K_BOOL;
    v.as.b = b ? 1 : 0;
    return v;
}

static KValue k_builtin_value(uint8_t code) {
    KValue v;
    v.tag = K_BUILTIN;
    v.as.bi = code;
    return v;
}

static KValue k_extern_value(uint32_t idx) {
    KValue v;
    v.tag = K_EXTERN;
    v.as.ex = idx;
    return v;
}

static KValue k_int(int64_t i) {
    KValue v;
    v.tag = K_INT;
    v.as.i = i;
    return v;
}

static KValue k_float(double d) {
    KValue v;
    v.tag = K_FLOAT;
    v.as.f = d;
    return v;
}

/* ---------- extern marshaling (W-3.2 — R-F1: the boundary
 * materializes scalars by copy; R-F2: the return is a fresh kerf
 * value whose ownership transfers to the caller) ---------- */

/* Forward declaration: k_kind_name renders below (the value-model
 * section); the marshaling failures name the offending kind. */
static const char *k_kind_name(uint8_t tag);

static int64_t k_as_int_arg(KValue v, const char *fn) {
    if (v.tag != K_INT) {
        k_fail("type mismatch: extern `%s` argument must be an int, got `%s`",
               fn, k_kind_name(v.tag));
    }
    return v.as.i;
}

static int k_as_bool_arg(KValue v, const char *fn) {
    if (v.tag != K_BOOL) {
        k_fail("type mismatch: extern `%s` argument must be a bool, got `%s`",
               fn, k_kind_name(v.tag));
    }
    return v.as.b;
}

static double k_as_float_arg(KValue v, const char *fn) {
    if (v.tag != K_FLOAT) {
        k_fail("type mismatch: extern `%s` argument must be a float, got `%s`",
               fn, k_kind_name(v.tag));
    }
    return v.as.f;
}

static double k_bits_to_double(uint64_t bits) {
    union {
        uint64_t u;
        double d;
    } x;
    x.u = bits;
    return x.d;
}

static uint64_t k_double_bits(double d) {
    union {
        uint64_t u;
        double d;
    } x;
    x.d = d;
    return x.u;
}

static const char *k_kind_name(uint8_t tag) {
    switch (tag) {
    case K_INT: return "int";
    case K_FLOAT: return "float";
    case K_BOOL: return "bool";
    case K_STR: return "string";
    case K_NIL: return "nil";
    case K_PAIR: return "pair";
    case K_CLOSURE: return "closure";
    case K_BUILTIN: return "builtin";
    case K_EXTERN: return "extern function";
    default: return "unknown";
    }
}

static const char *k_builtin_name(uint8_t code) {
    switch (code) {
    case KB_ADD: return "+";
    case KB_SUB: return "-";
    case KB_MUL: return "*";
    case KB_DIV: return "/";
    case KB_LT: return "<";
    case KB_LE: return "<=";
    case KB_GT: return ">";
    case KB_GE: return ">=";
    case KB_NUMEQ: return "=";
    case KB_CAR: return "car";
    case KB_CDR: return "cdr";
    case KB_CONS: return "cons";
    case KB_ISPAIR: return "pair?";
    case KB_ISNIL: return "nil?";
    case KB_EQ: return "eq?";
    case KB_NOT: return "not";
    case KB_READLINE: return "read-line";
    case KB_WRITELINE: return "write-line";
    case KB_RENDERLINE: return "render-line";
    default: return "unknown-builtin";
    }
}

/* ---------- budget + host-stack depth (the §19.4 safety point) ---------- */

/* Mirror of the VM reserve: one check of live usage (frames + cells)
 * against the budget, THEN the allocation runs — a batch may
 * overshoot by n-1 exactly like reserve_exact. */
static void k_charge(KVm *k, uint32_t n) {
    (void)n; /* the batch size participates only via the early no-op */
    if (n == 0) {
        return;
    }
    if (k->ncells + k->depth >= k->budget) {
        k_fail("allocation budget of `%" PRIu32 "` exhausted", k->budget);
    }
}

static void k_enter(KVm *k) {
    if (k->depth + 1u > k->depth_cap) {
        k_fail("recursion depth of `%" PRIu32 "` exceeded (host C stack boundary)",
               k->depth_cap);
    }
    /* Charge BEFORE the depth increment — the same check-then-allocate
     * order as the VM `reserve`/`push_frame` pair and `k_mk_pair` below,
     * so the accept/reject boundary is exact on all three faces: a
     * frame-shaped program peaks at exactly `budget` live units on both
     * engines (the old increment-first order rejected at budget-1). */
    k_charge(k, 1);
    k->depth++;
}

static void k_leave(KVm *k) {
    if (k->depth == 0) {
        k_unreachable("k_leave without k_enter");
    }
    k->depth--;
}

/* ---------- cell arena (monotonic; no GC — registered fork) ---------- */

/* 8-byte alignment keeps every cell layout valid on the hosts the
 * chain-external backend targets (the value/pointer members never
 * need more). */
#define K_ARENA_ALIGN ((uint32_t)8u)

static uint32_t k_arena_alloc(KVm *k, size_t nbytes) {
    uint32_t pad = (K_ARENA_ALIGN - (k->arena_used % K_ARENA_ALIGN)) % K_ARENA_ALIGN;
    uint64_t need64 = (uint64_t)k->arena_used + pad + nbytes;
    if (need64 > k->arena_cap) {
        uint64_t cap64 = k->arena_cap ? (uint64_t)k->arena_cap * 2u : 16384u;
        while (cap64 < need64) {
            cap64 *= 2u;
        }
        if (cap64 > 0xffffffffu) {
            cap64 = 0xffffffffu;
        }
        unsigned char *grown = (unsigned char *)realloc(k->arena, (size_t)cap64);
        if (!grown) {
            k_fail("the host allocator refused a cell arena grow");
        }
        k->arena = grown;
        k->arena_cap = (uint32_t)cap64;
    }
    uint32_t at = k->arena_used + pad;
    k->arena_used = (uint32_t)need64;
    return at;
}

#define K_PAIR_AT(k, ref) ((KPairCell *)((k)->arena + (ref)))
#define K_CLO_AT(k, ref) ((KClosureCell *)((k)->arena + (ref)))

static KValue k_mk_pair(KVm *k, KValue a, KValue b) {
    k_charge(k, 1);
    uint32_t r = k_arena_alloc(k, sizeof(KPairCell));
    K_PAIR_AT(k, r)->car = a;
    K_PAIR_AT(k, r)->cdr = b;
    k->ncells++;
    KValue v;
    v.tag = K_PAIR;
    v.as.ref = r;
    return v;
}

/* The uncharged twin: literal-tree materialization pre-charges the
 * whole cell count in one batch (the reserve_exact mirror). */
static KValue k_mk_pair_nochg(KVm *k, KValue a, KValue b) {
    uint32_t r = k_arena_alloc(k, sizeof(KPairCell));
    K_PAIR_AT(k, r)->car = a;
    K_PAIR_AT(k, r)->cdr = b;
    k->ncells++;
    KValue v;
    v.tag = K_PAIR;
    v.as.ref = r;
    return v;
}

static KValue k_closure(KVm *k, uint32_t proto, uint32_t ncap, KValue *env) {
    k_charge(k, 1);
    size_t nbytes = sizeof(KClosureCell) + (size_t)ncap * sizeof(KValue);
    uint32_t r = k_arena_alloc(k, nbytes);
    KClosureCell *c = K_CLO_AT(k, r);
    c->proto = proto;
    c->ncap = ncap;
    for (uint32_t i = 0; i < ncap; i++) {
        c->env[i] = env[i];
    }
    k->ncells++;
    KValue v;
    v.tag = K_CLOSURE;
    v.as.ref = r;
    return v;
}

/* ---------- constant materialization (mirrors from_literal) ---------- */

static KValue k_lit_mk(KVm *k, const KLit *lit) {
    switch (lit->kind) {
    case 0: {
        KValue v;
        v.tag = K_INT;
        v.as.i = lit->as.i;
        return v;
    }
    case 1: {
        KValue v;
        v.tag = K_FLOAT;
        v.as.f = k_bits_to_double(lit->as.bits);
        return v;
    }
    case 2: return k_bool(lit->as.b);
    case 3: {
        KValue v;
        v.tag = K_STR;
        v.as.s = lit->as.s;
        return v;
    }
    case 4: return k_nil_value();
    default: {
        /* Same order as Value::from_literal: car, then cdr, then the
         * pair cell (the cell charge happened as one batch up front). */
        KValue a = k_lit_mk(k, lit->as.pair.car);
        KValue b = k_lit_mk(k, lit->as.pair.cdr);
        return k_mk_pair_nochg(k, a, b);
    }
    }
}

/* Generated constant pool (defined by the emitter after this shim). */
static const KConst *k_consts;

static KValue k_push_const(KVm *k, uint32_t idx) {
    const KConst *c = &k_consts[idx];
    if (c->cells != 0) {
        k_charge(k, c->cells);
    }
    switch (c->kind) {
    case 0: {
        KValue v;
        v.tag = K_INT;
        v.as.i = c->as.i;
        return v;
    }
    case 1: {
        KValue v;
        v.tag = K_FLOAT;
        v.as.f = k_bits_to_double(c->as.bits);
        return v;
    }
    case 2: return k_bool(c->as.b);
    case 3: {
        KValue v;
        v.tag = K_STR;
        v.as.s = c->as.s;
        return v;
    }
    case 4: return k_nil_value();
    default: return k_lit_mk(k, c->as.lit);
    }
}

/* ---------- globals ---------- */

static KValue k_global_load(KVm *k, uint32_t idx, const char *name) {
    KValue v = k->globals[idx];
    if (v.tag == K_UNBOUND) {
        k_fail("unbound global `%s`", name);
    }
    return v;
}

static void k_global_store(KVm *k, uint32_t idx, KValue v) {
    k->globals[idx] = v;
}

/* ---------- handlers (§8.12 effect extension) ---------- */

static void k_handler_push(KVm *k, uint32_t effect, KValue v) {
    if (k->nh == k->hcap) {
        uint32_t cap = k->hcap ? k->hcap * 2u : 8u;
        KHandler *grown = (KHandler *)realloc(k->handlers,
                                              (size_t)cap * sizeof(KHandler));
        if (!grown) {
            k_fail("the host allocator refused a handler stack grow");
        }
        k->handlers = grown;
        k->hcap = cap;
    }
    k->handlers[k->nh].effect = effect;
    k->handlers[k->nh].value = v;
    k->nh++;
}

static void k_handler_pop(KVm *k, uint32_t n, uint32_t pc) {
    if (k->nh < n) {
        /* r106 FIX-17: the pc rides the message — the VM Display
         * carries it (`stack underflow at `pop-handler` pc `7``),
         * and the C face must stay message-identical. */
        k_fail("stack underflow at `pop-handler` pc `%" PRIu32 "`", pc);
    }
    k->nh -= n;
}

/* perform: the nearest installed handler wins (rposition mirror);
 * its return value IS the perform's value. */
static KValue k_perform(KVm *k, uint32_t effect, const char *name,
                        uint32_t argc, KValue *args) {
    for (uint32_t i = k->nh; i-- > 0;) {
        if (k->handlers[i].effect == effect) {
            return k_call(k, k->handlers[i].value, argc, args);
        }
    }
    k_fail("unhandled effect `%s`", name);
}

/* ---------- strict operand faces ---------- */

static int k_test_bool(KVm *k, KValue v) {
    if (v.tag == K_BOOL) {
        return v.as.b;
    }
    k_fail("type mismatch: jump-if-false condition must be a bool, got `%s`",
           k_kind_name(v.tag));
}

static KValue k_car(KVm *k, KValue v) {
    if (v.tag == K_PAIR) {
        return K_PAIR_AT(k, v.as.ref)->car;
    }
    k_fail("type mismatch: car operand must be a pair, got `%s`",
           k_kind_name(v.tag));
}

static KValue k_cdr(KVm *k, KValue v) {
    if (v.tag == K_PAIR) {
        return K_PAIR_AT(k, v.as.ref)->cdr;
    }
    k_fail("type mismatch: cdr operand must be a pair, got `%s`",
           k_kind_name(v.tag));
}

/* ---------- checked integer arithmetic (UB-free, portable) ---------- */

static int64_t k_iadd(int64_t x, int64_t y, int *ovf) {
    uint64_t ux = (uint64_t)x, uy = (uint64_t)y;
    uint64_t ur = ux + uy;
    *ovf = (int)((~(ux ^ uy) & (ux ^ ur)) >> 63);
    return (int64_t)ur;
}

static int64_t k_isub(int64_t x, int64_t y, int *ovf) {
    uint64_t ux = (uint64_t)x, uy = (uint64_t)y;
    uint64_t ur = ux - uy;
    *ovf = (int)(((ux ^ uy) & (ux ^ ur)) >> 63);
    return (int64_t)ur;
}

static int64_t k_imul(int64_t x, int64_t y, int *ovf) {
    if (x == 0 || y == 0) {
        *ovf = 0;
        return 0;
    }
    /* Magnitude method: no signed-overflow UB, no 128-bit need. */
    uint64_t ax = x < 0 ? ~(uint64_t)x + 1u : (uint64_t)x;
    uint64_t ay = y < 0 ? ~(uint64_t)y + 1u : (uint64_t)y;
    uint64_t ar = ax * ay;
    *ovf = 0;
    if (ay != 0 && ar / ay != ax) {
        *ovf = 1;
    }
    int neg = (x < 0) != (y < 0);
    if (neg) {
        if (ar > (uint64_t)INT64_MAX + 1u) {
            *ovf = 1;
        }
    } else {
        if (ar > (uint64_t)INT64_MAX) {
            *ovf = 1;
        }
    }
    if (*ovf) {
        return 0;
    }
    return neg ? (int64_t)(~ar + 1u) : (int64_t)ar;
}

static int64_t k_idiv(int64_t x, int64_t y, int *ovf) {
    if (y == 0) {
        k_fail("division by zero");
    }
    if (x == INT64_MIN && y == -1) {
        *ovf = 1;
        return 0;
    }
    *ovf = 0;
    return x / y;
}

/* The add/sub/mul/div opcode face: same-kind numbers, checked ints,
 * IEEE floats, mixed kinds rejected (§19.5 explicitness). */
typedef enum { KA_ADD, KA_SUB, KA_MUL, KA_DIV } KArithOp;

static const char *k_arith_context(KArithOp op) {
    switch (op) {
    case KA_ADD: return "add operand";
    case KA_SUB: return "sub operand";
    case KA_MUL: return "mul operand";
    default: return "div operand";
    }
}

static const char *k_arith_word(KArithOp op) {
    switch (op) {
    case KA_ADD: return "add";
    case KA_SUB: return "sub";
    case KA_MUL: return "mul";
    default: return "div";
    }
}

static KValue k_arith(KVm *k, KArithOp op, KValue a, KValue b) {
    if (a.tag == K_INT && b.tag == K_INT) {
        int ovf = 0;
        int64_t r = 0;
        switch (op) {
        case KA_ADD: r = k_iadd(a.as.i, b.as.i, &ovf); break;
        case KA_SUB: r = k_isub(a.as.i, b.as.i, &ovf); break;
        case KA_MUL: r = k_imul(a.as.i, b.as.i, &ovf); break;
        case KA_DIV: r = k_idiv(a.as.i, b.as.i, &ovf); break;
        }
        if (ovf) {
            k_fail("%s overflow", k_arith_word(op));
        }
        KValue v;
        v.tag = K_INT;
        v.as.i = r;
        return v;
    }
    if (a.tag == K_FLOAT && b.tag == K_FLOAT) {
        double r = 0.0;
        switch (op) {
        case KA_ADD: r = a.as.f + b.as.f; break;
        case KA_SUB: r = a.as.f - b.as.f; break;
        case KA_MUL: r = a.as.f * b.as.f; break;
        case KA_DIV: r = a.as.f / b.as.f; break;
        }
        KValue v;
        v.tag = K_FLOAT;
        v.as.f = r;
        return v;
    }
    k_fail("type mismatch: %s must be a number of the same kind, got `%s`",
           k_arith_context(op),
           (a.tag == K_INT || a.tag == K_FLOAT) ? k_kind_name(b.tag)
                                                : k_kind_name(a.tag));
}

/* ---------- builtins (single-source semantics, Builtin::ALL) ---------- */

static void k_fail_arity(const char *name, uint32_t expected, uint32_t actual) {
    if (expected == 1) {
        k_fail("arity mismatch: `%s` expects `%" PRIu32 "` argument, got `%" PRIu32
               "`",
               name, expected, actual);
    } else {
        k_fail("arity mismatch: `%s` expects `%" PRIu32 "` arguments, got `%" PRIu32
               "`",
               name, expected, actual);
    }
}

static KValue k_eq(KValue a, KValue b) {
    int r = 0;
    if (a.tag == b.tag) {
        switch (a.tag) {
        case K_INT: r = a.as.i == b.as.i; break;
        case K_FLOAT: r = k_double_bits(a.as.f) == k_double_bits(b.as.f); break;
        case K_BOOL: r = a.as.b == b.as.b; break;
        case K_STR:
            r = a.as.s.n == b.as.s.n &&
                (a.as.s.n == 0 || memcmp(a.as.s.p, b.as.s.p, a.as.s.n) == 0);
            break;
        case K_NIL: r = 1; break;
        case K_PAIR:
        case K_CLOSURE: r = a.as.ref == b.as.ref; break;
        case K_BUILTIN: r = a.as.bi == b.as.bi; break;
        case K_EXTERN: r = a.as.ex == b.as.ex; break;
        default: r = 0; break;
        }
    }
    return k_bool(r);
}

static KValue k_compare(KVm *k, KBuiltinCode code, KValue a, KValue c) {
    int verdict = 0;
    if (a.tag == K_INT && c.tag == K_INT) {
        switch (code) {
        case KB_LT: verdict = a.as.i < c.as.i; break;
        case KB_LE: verdict = a.as.i <= c.as.i; break;
        case KB_GT: verdict = a.as.i > c.as.i; break;
        case KB_GE: verdict = a.as.i >= c.as.i; break;
        default: verdict = a.as.i == c.as.i; break;
        }
    } else if (a.tag == K_FLOAT && c.tag == K_FLOAT) {
        switch (code) {
        case KB_LT: verdict = a.as.f < c.as.f; break;
        case KB_LE: verdict = a.as.f <= c.as.f; break;
        case KB_GT: verdict = a.as.f > c.as.f; break;
        case KB_GE: verdict = a.as.f >= c.as.f; break;
        default: verdict = a.as.f == c.as.f; break;
        }
    } else {
        const char *ctx;
        switch (code) {
        case KB_LT: ctx = "`<` operand"; break;
        case KB_LE: ctx = "`<=` operand"; break;
        case KB_GT: ctx = "`>` operand"; break;
        case KB_GE: ctx = "`>=` operand"; break;
        default: ctx = "`=` operand"; break;
        }
        k_fail("type mismatch: %s must be a number of the same kind, got `%s`",
               ctx,
               (a.tag == K_INT || a.tag == K_FLOAT) ? k_kind_name(c.tag)
                                                    : k_kind_name(a.tag));
    }
    (void)k;
    return k_bool(verdict);
}

static KValue k_read_line(KVm *k) {
    char *ln = NULL;
    size_t cap = 0;
    ssize_t n = getline(&ln, &cap, stdin);
    if (n < 0) {
        free(ln);
        k_fail("read-line: end of input");
    }
    if (n > 0 && ln[n - 1] == '\n') {
        n--;
    }
    char *copy = (char *)malloc((size_t)(n > 0 ? n : 1));
    if (!copy) {
        free(ln);
        k_fail("the host allocator refused a line buffer");
    }
    memcpy(copy, ln, (size_t)n);
    free(ln);
    KValue v;
    v.tag = K_STR;
    v.as.s.p = copy;
    v.as.s.n = (uint32_t)n;
    return v;
}

static void k_out_line(KVm *k, const char *p, uint32_t n) {
    if (k->nout == k->outcap) {
        uint32_t cap = k->outcap ? k->outcap * 2u : 16u;
        char **grown = (char **)realloc(k->out, (size_t)cap * sizeof(char *));
        if (!grown) {
            k_fail("the host allocator refused an output buffer grow");
        }
        k->out = grown;
        k->outcap = cap;
    }
    char *copy = (char *)malloc((size_t)n + 1u);
    if (!copy) {
        k_fail("the host allocator refused an output line");
    }
    memcpy(copy, p, (size_t)n);
    copy[n] = '\0';
    k->out[k->nout++] = copy;
}

/* The one builtin dispatch for the whole registry (K152 discipline:
 * the adapter is selected at one place, never per call site). */
/* The render-line body's forward declaration (ORCH blade 2): the
 * body is defined after the display walk (k_display_into) — the
 * single-header order constraint; the signature's types are all
 * defined by this point. */
static KValue k_render_line(KVm *k, KValue v);

static KValue k_builtin_call(KVm *k, uint8_t code, uint32_t argc, KValue *args) {
    switch (code) {
    case KB_ADD:
        if (argc != 2) k_fail_arity("+", 2, argc);
        return k_arith(k, KA_ADD, args[0], args[1]);
    case KB_SUB:
        if (argc != 2) k_fail_arity("-", 2, argc);
        return k_arith(k, KA_SUB, args[0], args[1]);
    case KB_MUL:
        if (argc != 2) k_fail_arity("*", 2, argc);
        return k_arith(k, KA_MUL, args[0], args[1]);
    case KB_DIV:
        if (argc != 2) k_fail_arity("/", 2, argc);
        return k_arith(k, KA_DIV, args[0], args[1]);
    case KB_LT:
        if (argc != 2) k_fail_arity("<", 2, argc);
        return k_compare(k, KB_LT, args[0], args[1]);
    case KB_LE:
        if (argc != 2) k_fail_arity("<=", 2, argc);
        return k_compare(k, KB_LE, args[0], args[1]);
    case KB_GT:
        if (argc != 2) k_fail_arity(">", 2, argc);
        return k_compare(k, KB_GT, args[0], args[1]);
    case KB_GE:
        if (argc != 2) k_fail_arity(">=", 2, argc);
        return k_compare(k, KB_GE, args[0], args[1]);
    case KB_NUMEQ:
        if (argc != 2) k_fail_arity("=", 2, argc);
        return k_compare(k, KB_NUMEQ, args[0], args[1]);
    case KB_CAR:
        if (argc != 1) k_fail_arity("car", 1, argc);
        return k_car(k, args[0]);
    case KB_CDR:
        if (argc != 1) k_fail_arity("cdr", 1, argc);
        return k_cdr(k, args[0]);
    case KB_CONS: {
        if (argc != 2) k_fail_arity("cons", 2, argc);
        return k_mk_pair(k, args[0], args[1]);
    }
    case KB_ISPAIR:
        if (argc != 1) k_fail_arity("pair?", 1, argc);
        return k_bool(args[0].tag == K_PAIR);
    case KB_ISNIL:
        if (argc != 1) k_fail_arity("nil?", 1, argc);
        return k_bool(args[0].tag == K_NIL);
    case KB_EQ:
        if (argc != 2) k_fail_arity("eq?", 2, argc);
        return k_eq(args[0], args[1]);
    case KB_NOT: {
        if (argc != 1) k_fail_arity("not", 1, argc);
        KValue v = args[0];
        if (v.tag != K_BOOL) {
            k_fail("type mismatch: not operand must be a bool, got `%s`",
                   k_kind_name(v.tag));
        }
        return k_bool(!v.as.b);
    }
    case KB_READLINE:
        if (argc != 0) k_fail_arity("read-line", 0, argc);
        return k_read_line(k);
    case KB_WRITELINE: {
        if (argc != 1) k_fail_arity("write-line", 1, argc);
        KValue v = args[0];
        if (v.tag != K_STR) {
            k_fail("type mismatch: write-line operand must be a string, got `%s`",
                   k_kind_name(v.tag));
        }
        k_out_line(k, v.as.s.p, v.as.s.n);
        return k_nil_value();
    }
    case KB_RENDERLINE: {
        /* The MX-1 retirement (W-SELFHOST-ORCH blade 2): the
         * value→bytes edge rides the same out channel; the display
         * text is THIS shim's own mirror of Value's Display (the
         * k_display_into single source per host — parity pinned by
         * the e2e replay, byte-for-byte against the Rust face). */
        if (argc != 1) k_fail_arity("render-line", 1, argc);
        return k_render_line(k, args[0]);
    }
    default:
        k_unreachable("builtin dispatch");
    }
}

/* ---------- value display (mirrors Value's Display impl) ---------- */

/* Shortest round-trip float text, plain decimal (never scientific),
 * with the Rust Display special forms: inf / -inf / NaN / -0.
 * Method: try %.<p>e for p = 0..16, parse back with strtod, and keep
 * the first precision whose bits round-trip (the Steele-White /
 * RyU shortest-digit criterion — portable O(17) form); then render
 * the digits at the decimal exponent without exponent notation. */
static void k_fmt_double(char *buf, size_t bufsz, double v) {
    uint64_t bits = k_double_bits(v);
    if ((bits & 0x7ff0000000000000u) == 0x7ff0000000000000u) {
        /* exponent all-ones: NaN (any mantissa/sign) or ±inf */
        if (bits & 0x000fffffffffffffu) {
            snprintf(buf, bufsz, "NaN");
        } else if (bits & 0x8000000000000000u) {
            snprintf(buf, bufsz, "-inf");
        } else {
            snprintf(buf, bufsz, "inf");
        }
        return;
    }
    if (v == 0.0) {
        snprintf(buf, bufsz, bits & 0x8000000000000000u ? "-0" : "0");
        return;
    }
    char tmp[48];
    int prec;
    for (prec = 0; prec <= 16; prec++) {
        snprintf(tmp, sizeof tmp, "%.*e", prec, v);
        if (k_double_bits(strtod(tmp, NULL)) == bits) {
            break;
        }
    }
    if (prec > 16) {
        prec = 16; /* unreachable for finite doubles; defense */
    }
    /* Parse "-d.ddd...e±XX" into sign, digit string, exponent. */
    char digits[32];
    size_t nd = 0;
    int neg = 0;
    const char *p = tmp;
    if (*p == '-') {
        neg = 1;
        p++;
    }
    int expo = 0;
    for (; *p != '\0'; p++) {
        if (*p >= '0' && *p <= '9') {
            digits[nd++] = *p;
        } else if (*p == 'e' || *p == 'E') {
            expo = (int)strtol(p + 1, NULL, 10);
            break;
        }
        /* skip '.' */
    }
    /* Render plain decimal: value = digits * 10^(expo - (nd-1)). */
    char out[400];
    size_t o = 0;
    if (neg) {
        out[o++] = '-';
    }
    if (expo >= (int)nd - 1) {
        for (size_t i = 0; i < nd; i++) out[o++] = digits[i];
        for (int i = 0; i < expo - (int)nd + 1; i++) out[o++] = '0';
    } else if (expo >= 0) {
        for (int i = 0; i <= expo; i++) out[o++] = digits[i];
        out[o++] = '.';
        for (size_t i = (size_t)expo + 1; i < nd; i++) out[o++] = digits[i];
    } else {
        out[o++] = '0';
        out[o++] = '.';
        for (int i = 0; i < -expo - 1; i++) out[o++] = '0';
        for (size_t i = 0; i < nd; i++) out[o++] = digits[i];
    }
    out[o] = '\0';
    snprintf(buf, bufsz, "%s", out);
}

/* A small dynamic text builder for the final-value display. */
typedef struct {
    char *p;
    size_t n, cap;
} KBuf;

static void kb_grow(KBuf *b, size_t need) {
    if (b->n + need + 1 > b->cap) {
        size_t cap = b->cap ? b->cap * 2 : 64;
        while (cap < b->n + need + 1) {
            cap *= 2;
        }
        char *grown = (char *)realloc(b->p, cap);
        if (!grown) {
            k_fail("the host allocator refused a display buffer grow");
        }
        b->p = grown;
        b->cap = cap;
    }
}

static void kb_put(KBuf *b, const char *s, size_t n) {
    kb_grow(b, n);
    memcpy(b->p + b->n, s, n);
    b->n += n;
}

static void kb_cstr(KBuf *b, const char *s) { kb_put(b, s, strlen(s)); }

static void k_display_into(KBuf *b, KVm *k, KValue v) {
    char num[400];
    switch (v.tag) {
    case K_INT:
        snprintf(num, sizeof num, "%" PRId64, v.as.i);
        kb_cstr(b, num);
        break;
    case K_FLOAT:
        k_fmt_double(num, sizeof num, v.as.f);
        kb_cstr(b, num);
        break;
    case K_BOOL:
        kb_cstr(b, v.as.b ? "true" : "false");
        break;
    case K_STR:
        kb_put(b, "\"", 1);
        kb_put(b, v.as.s.p, v.as.s.n);
        kb_put(b, "\"", 1);
        break;
    case K_NIL:
        kb_cstr(b, "nil");
        break;
    case K_PAIR:
        kb_cstr(b, "#<pair>");
        break;
    case K_CLOSURE:
        kb_cstr(b, "#<closure>");
        break;
    default: {
        const char *name = k_builtin_name(v.as.bi);
        kb_cstr(b, "#<builtin:");
        kb_cstr(b, name);
        kb_cstr(b, ">");
        break;
    }
    }
    (void)k;
}

/* ---------- vm init + finish ---------- */

/* The render-line body (ORCH blade 2): the display text through
 * the shared dynamic builder, one line onto the out channel —
 * defined here, after k_display_into, per the forward declaration
 * at the dispatch (the single-header order constraint). */
static KValue k_render_line(KVm *k, KValue v) {
    KBuf b = {NULL, 0, 0};
    kb_grow(&b, 1);
    b.p[0] = '\0';
    k_display_into(&b, k, v);
    k_out_line(k, b.p, b.n);
    free(b.p);
    return k_nil_value();
}

static void k_vm_init(KVm *k) {
    memset(k, 0, sizeof *k);
    k->budget = K_BUDGET;
    k->depth_cap = K_DEPTH_CAP;
}

/* Mirrors the `kerf run` observable contract: the recorded output
 * lines print first, then the halt value unless it is nil. */
static void k_finish(KVm *k, KValue v) {
    for (uint32_t i = 0; i < k->nout; i++) {
        fputs(k->out[i], stdout);
        fputc('\n', stdout);
    }
    if (v.tag != K_NIL) {
        KBuf b = {NULL, 0, 0};
        kb_grow(&b, 1);
        b.p[0] = '\0';
        k_display_into(&b, k, v);
        kb_put(&b, "\n", 1);
        kb_put(&b, "", 1);
        fputs(b.p, stdout);
        free(b.p);
    }
}

#endif /* KERF_RT_H */

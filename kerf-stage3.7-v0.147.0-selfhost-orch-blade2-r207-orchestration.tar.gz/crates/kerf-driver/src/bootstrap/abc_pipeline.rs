//! The T-a switch window's step-② A/B/C artifact pipeline
//! (bootstrap-completion-plan §4.3 step ② + §5; the K159 fixpoint
//! gate — "the fixpoint is a VERIFICATION GATE, not a build step;
//! the chain is fixed-length, the artifacts explicit").
//!
//! The pipeline's three passes, one per K159 letter:
//!
//! * **A** — the Rust compiler compiles the six CHAIN-COMPILABLE
//!   FORMS (the CCFs — see below) through the plain production
//!   pipeline. Today's form: the seed chain's own compilation.
//! * **B** — the twin chain, running ON the A products, compiles
//!   the twin chain itself: every CCF is read by the read twins,
//!   expanded by the expander twin, checked by the check twins,
//!   and compiled by the compiler twin — each segment executing
//!   its A-product bytecode on the VM, fed through the injection
//!   channel. The terminal products are the B artifacts.
//! * **C** — the same chain shape, running ON the B artifacts (the
//!   chain's own compilations of itself), compiles the chain again
//!   → the C artifacts.
//!
//! The gate: **B ≡ C byte-identical** (six artifacts, `Bytecode`
//! `PartialEq` with the descriptor tables included). The A ≡ B row
//! is the parity OBSERVATION (the twin compiler's product equals
//! the oracle's — expected to hold by gate B, disclosed alongside
//! the gate row, never a substitute for it).
//!
//! The chain-compilable form (the CCF — the round's core ruling):
//! a fixed chain program is its twin source PLUS an in-language
//! `extern` slot declaration:
//!
//! ```text
//! extern "C" { fn source_bytes() -> int; }   // the slot contract
//! <the twin source verbatim — its `source_bytes` reference now
//!  resolves as an external name: expansion accepts (the
//!  extern-names seeding), the conservative checker accepts (R1 —
//!  the externals table carries the name), HM types the bare
//!  reference as Dyn, the compiler emits load-global>
//! ```
//!
//! The declaration is the honest in-language mirror of the
//! host-level injection contract: the slot's VALUE arrives at run
//! time through `Vm::inject_global` (the INJ-1..INJ-5 channel),
//! and the extern entry rides the product as an inert contract
//! record (zero code — the W-3.2 zero-code precedent; value
//! references never activate the FFI call semantics). The
//! alternative host-level face (`parse_target_with_injected`)
//! stays the A-form construction's peer — the CCF adds the
//! CHAIN-PROCESSABLE form (a closed program the chain's own
//! expand/check segments can accept), it does not replace the
//! injected face.
//!
//! Why the CCF and not the bare twin sources: the bare sources
//! carry free slot references — the chain's expansion layer
//! rejects them with the unbound-identifier key (the honest
//! boundary the selfhost composed-formula tests disclose: only
//! macro.ktf, the one self-contained twin, rides the full formula
//! bare). The extern slot declaration is what makes
//! "the chain compiles the chain" expressible at all — the
//! load-bearing row is pinned by a negative test.
//!
//! The segment runners are the VM arm only (the production
//! engine). The dual-engine discipline stays where it already
//! lives — the steady chains' own sweeps and the composed-chain
//! tests; this pipeline is about the ARTIFACTS and the gate, not
//! the engine parity.

use kerf_compiler::{Bytecode, compile_program};
use kerf_core::ModuleItem;
use kerf_syntax::SyntaxObject;
use kerf_vm::{BufferIo, Vm};

use crate::bootstrap::compiler_parity::{
    dump_ktf_section, rebuild_bytecode, rebuild_compile_error,
};
use crate::bootstrap::infer_parity::oracle_inference_axes;
use crate::bootstrap::steady_expander_chain::{
    STEADY_FORMS_NAME, decode_expansion, forms_stream_literal,
};
use crate::bootstrap::steady_target_reader_chain::{
    STEADY_TARGET_SOURCE_NAME, STEADY_TP_TOKENS_NAME, bridge_token_table,
};
use crate::bootstrap::steady_typecheck_chain::{STEADY_ITEMS_NAME, inject_items_stream};
use crate::bootstrap::target_corpus::transcode_quoted_define;
// ORCH blade 1 (O6): MACRO_TARGET_SOURCE retired from this import
// — the expander CCF rides the composed form.
use crate::bootstrap::target_corpus::{
    COMPILER_TARGET_SOURCE, EXPANDER_TARGET_SOURCE, INFER_TARGET_SOURCE,
    TARGET_LEXER_TARGET_SOURCE, TARGET_PARSER_TARGET_SOURCE, TYPECHECK_TARGET_SOURCE,
};
use crate::bootstrap::target_lexer_parity::decode_twin_verdict;
use crate::bootstrap::target_parser_parity::{
    decode_tp_verdict, rebuild_tp_forms, tp_forms_prefix, tp_limit_prefix,
};
use crate::bootstrap::typecheck_parity::oracle_check_axes;
use crate::bootstrap::vm_harness::STD_ERROR_TARGET_SOURCE;
use crate::bootstrap::vm_harness::byte_table_literal;
use crate::bootstrap::vm_harness::{KtfVerdict, decode_tagged};
use crate::pipeline;
use crate::session::Session;

// ---------------------------------------------------------------------------
// The chain-compilable forms (the CCFs)
// ---------------------------------------------------------------------------

/// The lexer CCF: the `source-bytes` slot declaration and the std
/// Error-instance prefix ahead of the target-lexer twin (the
/// target-skin spelling `source_bytes` — the skin map canonicalizes
/// it to `source-bytes`, the injection channel's contract name; the
/// Error prefix is the modern2 blade-3 consumption — the twin's
/// rejections ride `perform raise` off it, the M46 assembly face).
pub fn ccf_lexer_source() -> String {
    format!(
        "extern \"C\" {{ fn source_bytes() -> int; }}\n{STD_ERROR_TARGET_SOURCE}\n{TARGET_LEXER_TARGET_SOURCE}"
    )
}

/// The parser CCF: the `tp-tokens` slot declaration ahead of the
/// steady chain's fixed parser assembly (the form table + the
/// nesting limit + the twin source — the same three-part assembly
/// `SteadyTargetReaderChain` embeds, one spelling).
pub fn ccf_parser_source() -> String {
    // MODERN2 blade 6 (r203): the std Error-instance prefix ahead of
    // the twin — the parse-rejection family's raise sites and the
    // unwrap(attempt(...)) entry ride the library's live definitions
    // (the ccf-lexer/ccf-compiler/ccf-expander precedent, the fourth
    // handle-carrying chain source).
    format!(
        "extern \"C\" {{ fn tp_tokens() -> int; }}\n{STD_ERROR_TARGET_SOURCE}\n{}{}{}",
        transcode_quoted_define(&tp_forms_prefix()),
        tp_limit_prefix(256),
        TARGET_PARSER_TARGET_SOURCE
    )
}

/// The expander CCF: the `forms` slot declaration ahead of the
/// MX-2 assembled expander (the macro library + the expander body,
/// one program) — the `ex_limit` prefix rides the default work
/// budget (the K159 gate's A/B/C rounds all ride the same default,
/// so the fixed-point comparison stays budget-aligned). Blade 2
/// (GZ-2): the `ex-struct-accs` slot declaration rides alongside —
/// the accessor-name table's injection channel contract name (the
/// twin references it; the CCF face binds the name through the
/// extern slot device, exactly like `forms`).
///
/// W-SELFHOST-ORCH blade 1 (O6): the file composition (the std
/// Error instance + the macro library) rides the expander's own
/// `import` declarations through the composer — the assembled form
/// is the import-composed twin, the budget define stays a host-side
/// channel (the blade-4 sweep).
pub fn ccf_expander_source() -> String {
    format!(
        "extern \"C\" {{ fn forms() -> int; fn ex_struct_accs() -> int; fn ex_enum_ctors() -> int; }}\ndefine(ex_limit, {});\n{}",
        kerf_expander::EXPANSION_LIMIT,
        crate::bootstrap::target_corpus::compose_selfhost(EXPANDER_TARGET_SOURCE)
    )
}

/// The infer twin CCF: the `items` slot declaration ahead of
/// `infer.ktf`.
pub fn ccf_infer_source() -> String {
    format!("extern \"C\" {{ fn items() -> int; }}\n{INFER_TARGET_SOURCE}")
}

/// The check twin CCF: the `items` slot declaration ahead of
/// `typecheck.ktf`.
pub fn ccf_check_source() -> String {
    format!("extern \"C\" {{ fn items() -> int; }}\n{TYPECHECK_TARGET_SOURCE}")
}

/// The compiler twin CCF: the `items` slot declaration, the std
/// Error-instance prefix (the MODERN2 blade-4 form — the twin's
/// `attempt`/`unwrap`/`raise` references expand against the
/// library's live definitions, the ccf-lexer M46 precedent), and
/// the `co_limit` work-budget define (the K159 A/B/C rounds all
/// ride the same default, so the fixed-point comparison stays
/// budget-aligned — the `ccf_expander_source` precedent) ahead of
/// `compiler.ktf`.
pub fn ccf_compiler_source() -> String {
    format!(
        "extern \"C\" {{ fn items() -> int; }}\n{STD_ERROR_TARGET_SOURCE}\ndefine(co_limit, {});\n{COMPILER_TARGET_SOURCE}",
        kerf_compiler::COMPILE_DEPTH_LIMIT
    )
}

/// The six CCFs, named, in pipeline order (the name rides the
/// reports and the failure lines — the audit rows pin them).
pub fn ccf_sources() -> Vec<(&'static str, String)> {
    vec![
        ("ccf-lexer", ccf_lexer_source()),
        ("ccf-parser", ccf_parser_source()),
        ("ccf-expander", ccf_expander_source()),
        ("ccf-infer", ccf_infer_source()),
        ("ccf-check", ccf_check_source()),
        ("ccf-compiler", ccf_compiler_source()),
    ]
}

// ---------------------------------------------------------------------------
// The A pass — the Rust compiler compiles the CCFs
// ---------------------------------------------------------------------------

/// One CCF's Rust-route compilation: the plain production pipeline
/// (the CCF is a CLOSED program — the extern slot declaration needs
/// no injected face), the checker must be clean, and the product is
/// the A artifact. The parsed items ride back for the differential
/// gates (the tree identity + the oracle verdicts).
pub fn rust_compile_ccf(name: &str, source: &str) -> Result<(Bytecode, Vec<ModuleItem>), String> {
    // The SEED pin (the step-④ dual-chain decoupling, ALL FOUR
    // segments): the A pass IS the Rust compiler as seed — read,
    // expand, check, AND compile all Rust — so the A ≡ B observation
    // row keeps its read-AND-expand coverage (a production-position
    // read or expansion here would make the row's segment a
    // self-comparison), the A pass's own checker verdict stays the
    // Rust oracle's (the r147 extension: a twin-position check here
    // would consume the B products before the differential even
    // runs — the row's check coverage would collapse the same way),
    // and the A pass's own compilation stays the Rust compiler's
    // (the r148 extension: the compile step below calls the Rust
    // compiler directly — structurally pinned, never the switched
    // arm).
    let mut session = Session::with_segments(
        crate::read_segment::ReadSegment::Rust,
        crate::expand_segment::ExpandSegment::Rust,
        crate::check_segment::CheckSegment::Rust,
        crate::compile_segment::CompileSegment::Rust,
    );
    let program = pipeline::parse_target(&mut session, name, source)
        .map_err(|diags| format!("A pass [{name}]: the CCF failed to parse: {diags:?}"))?;
    let findings = program.typecheck();
    if findings
        .iter()
        .any(|d| d.severity == crate::diagnostic::Severity::Error)
    {
        return Err(format!(
            "A pass [{name}]: the CCF failed the checker: {findings:?}"
        ));
    }
    let bc = compile_program(&program.items)
        .map_err(|err| format!("A pass [{name}]: the CCF failed to compile: {err}"))?;
    Ok((bc, program.items))
}

// ---------------------------------------------------------------------------
// The segment runners — the VM arm (the production engine)
// ---------------------------------------------------------------------------

/// The read segment: the two read twins' products (the caller
/// supplies the bytecodes — the A products on the B pass, the B
/// products on the C pass) read one source through the injection
/// channel + the K20 bridge; the rebuilt forms ride back (the
/// cross-stage feed). Rejections render as `Err` with the
/// rejection key — a chain-compilable chain never rejects its own
/// forms, so any rejection here is a real finding, never a pass.
pub fn read_via(
    lexer_bc: &Bytecode,
    parser_bc: &Bytecode,
    source: &str,
) -> Result<Vec<SyntaxObject>, String> {
    // ---- the lexer twin on the VM ----
    let mut vm = Vm::with_io(lexer_bc.clone(), Box::new(BufferIo::default()))
        .map_err(|err| format!("read segment: the vm rejected the lexer product: {err}"))?;
    vm.inject_global(STEADY_TARGET_SOURCE_NAME, &byte_table_literal(source))
        .map_err(|err| format!("read segment: the source-bytes channel: {err}"))?;
    vm.run()
        .map_err(|err| format!("read segment: the lexer product run failed: {err:?}"))?;
    let value = vm
        .global("result")
        .cloned()
        .ok_or_else(|| "read segment: no `result` global on the lexer run".to_string())?;
    let heap = vm.heap().clone();
    let dump = decode_twin_verdict(&value, &heap, source)?;
    let dump = dump.map_err(|key| format!("read segment: the lexer twin rejected: {key}"))?;
    let _ = dump;
    let table = bridge_token_table(source, &value, &heap)?;
    // ---- the parser twin on the VM ----
    let mut vm = Vm::with_io(parser_bc.clone(), Box::new(BufferIo::default()))
        .map_err(|err| format!("read segment: the vm rejected the parser product: {err}"))?;
    vm.inject_global(STEADY_TP_TOKENS_NAME, &table)
        .map_err(|err| format!("read segment: the tp-tokens channel: {err}"))?;
    vm.run()
        .map_err(|err| format!("read segment: the parser product run failed: {err:?}"))?;
    let value = vm
        .global("result")
        .cloned()
        .ok_or_else(|| "read segment: no `result` global on the parser run".to_string())?;
    let heap = vm.heap().clone();
    let dump = decode_tp_verdict(&value, &heap, source)?;
    let tree = dump.map_err(|key| format!("read segment: the parser twin rejected: {key}"))?;
    let _ = tree;
    let forms = rebuild_tp_forms(&value, &heap, source)?;
    forms.ok_or_else(|| {
        "read segment: a tree-ok verdict rebuilt to no forms — a harness defect".to_string()
    })
}

/// The expand segment: the expander twin's product expands the
/// forms through the `forms` channel; the rebuilt items ride back.
pub fn expand_via(
    expander_bc: &Bytecode,
    forms: &[SyntaxObject],
) -> Result<Vec<ModuleItem>, String> {
    let mut vm = Vm::with_io(expander_bc.clone(), Box::new(BufferIo::default()))
        .map_err(|err| format!("expand segment: the vm rejected the expander product: {err}"))?;
    let lit = forms_stream_literal(forms);
    let injected = vm
        .inject_global(STEADY_FORMS_NAME, &lit)
        .map_err(|err| format!("expand segment: the forms channel: {err}"));
    // The host-side literal disposes iteratively (the r146 K163
    // same-path sweep: every forms-stream injection site shares the
    // read segment's walker — a long right spine's default Box-drop
    // glue is one stack frame per cell).
    crate::bootstrap::steady_target_reader_chain::dispose_literal_iteratively(lit);
    injected?;
    vm.run()
        .map_err(|err| format!("expand segment: the expander product run failed: {err:?}"))?;
    let value = vm
        .global("result")
        .cloned()
        .ok_or_else(|| "expand segment: no `result` global".to_string())?;
    let expansion = decode_expansion(&value, vm.heap())?;
    expansion
        .into_items()
        .map_err(|key| format!("expand segment: the expander twin rejected: {key}"))
}

/// The check segment: both checker twins' products consume the
/// items through the `items` channel; the two verdict texts ride
/// back for the caller's differential against the oracle axes.
pub fn check_via(
    check_bc: &Bytecode,
    infer_bc: &Bytecode,
    items: &[ModuleItem],
) -> Result<(String, String), String> {
    // ---- the conservative checker twin ----
    let mut vm = Vm::with_io(check_bc.clone(), Box::new(BufferIo::default()))
        .map_err(|err| format!("check segment: the vm rejected the checker product: {err}"))?;
    inject_items_stream(&mut vm, items)
        .map_err(|err| format!("check segment: the items channel: {err}"))?;
    vm.run()
        .map_err(|err| format!("check segment: the checker product run failed: {err:?}"))?;
    let value = vm
        .global("result")
        .cloned()
        .ok_or_else(|| "check segment: no `result` global on the checker run".to_string())?;
    let check_text = crate::bootstrap::typecheck_parity::decode_check_result(&value, vm.heap())?;
    // ---- the HM inference twin ----
    let mut vm = Vm::with_io(infer_bc.clone(), Box::new(BufferIo::default()))
        .map_err(|err| format!("check segment: the vm rejected the infer product: {err}"))?;
    inject_items_stream(&mut vm, items)
        .map_err(|err| format!("check segment: the items channel: {err}"))?;
    vm.run()
        .map_err(|err| format!("check segment: the infer product run failed: {err:?}"))?;
    let value = vm
        .global("result")
        .cloned()
        .ok_or_else(|| "check segment: no `result` global on the infer run".to_string())?;
    let infer_text = crate::bootstrap::infer_parity::decode_infer_result(&value, vm.heap())?;
    Ok((check_text, infer_text))
}

/// The compile segment: the compiler twin's product consumes the
/// items through the `items` channel; the rebuilt bytecode is the
/// artifact (the compile layer's terminal product — the rebuild
/// face is the fixpoint's own `rebuild_bytecode`, the two-judges
/// contract's second judge included: the rebuilt product passes
/// the VM's own verify floor before it can be an artifact).
pub fn compile_via(compiler_bc: &Bytecode, items: &[ModuleItem]) -> Result<Bytecode, String> {
    let mut vm = Vm::with_io(compiler_bc.clone(), Box::new(BufferIo::default()))
        .map_err(|err| format!("compile segment: the vm rejected the compiler product: {err}"))?;
    inject_items_stream(&mut vm, items)
        .map_err(|err| format!("compile segment: the items channel: {err}"))?;
    vm.run()
        .map_err(|err| format!("compile segment: the compiler product run failed: {err:?}"))?;
    let value = vm
        .global("result")
        .cloned()
        .ok_or_else(|| "compile segment: no `result` global".to_string())?;
    let verdict: KtfVerdict<kerf_compiler::CompileError> =
        decode_tagged(&value, vm.heap(), dump_ktf_section, rebuild_compile_error)?;
    match verdict {
        KtfVerdict::Tree(_) => rebuild_bytecode(&value, vm.heap())
            .map_err(|err| format!("compile segment: the artifact rebuild: {err}")),
        KtfVerdict::Error(err) => Err(format!(
            "compile segment: the compiler twin rejected the items: {err}"
        )),
    }
}

// ---------------------------------------------------------------------------
// The chain via products — the B and C passes' shared shape
// ---------------------------------------------------------------------------

/// The six chain products one pass rides (the A products on the B
/// pass; the B products on the C pass — the K159 "via" face).
pub struct ChainProducts {
    pub lexer: Bytecode,
    pub parser: Bytecode,
    pub expander: Bytecode,
    pub infer: Bytecode,
    pub check: Bytecode,
    pub compiler: Bytecode,
}

/// One CCF through the whole chain riding the given products: read
/// → expand (the tree identity gate against the oracle items) →
/// check (both twins' verdicts against the oracle axes) → compile
/// (the artifact). Every junction is a differential gate — the
/// composed chain's own discipline carried into the pipeline; a
/// chain that silently produced artifacts from drifting items
/// would defeat the K159 gate's meaning.
pub fn chain_compile_ccf_via(
    products: &ChainProducts,
    name: &str,
    source: &str,
    oracle_items: &[ModuleItem],
    oracle_check: &str,
    oracle_infer: &str,
) -> Result<Bytecode, String> {
    // ---- the read segment ----
    let forms = read_via(&products.lexer, &products.parser, source)
        .map_err(|err| format!("[{name}] {err}"))?;
    // ---- the expand segment + the tree identity gate ----
    let items = expand_via(&products.expander, &forms).map_err(|err| format!("[{name}] {err}"))?;
    if items != oracle_items {
        return Err(format!(
            "[{name}] the tree identity gate: the chain's expansion drifted from the oracle items"
        ));
    }
    // ---- the check segment + the oracle differential ----
    let (check_text, infer_text) = check_via(&products.check, &products.infer, &items)
        .map_err(|err| format!("[{name}] {err}"))?;
    if check_text != oracle_check {
        return Err(format!(
            "[{name}] the check differential: the twin checker drifted from the oracle axes"
        ));
    }
    if infer_text != oracle_infer {
        // The TD-032 blade-6 closure (the differential-semantics
        // upgrade): the raise-carrying chain sources' infer dumps
        // are design-divergent from the frozen oracle's dyn typing
        // (the r188 typed-perform pin's live effect typing — the
        // typing rows, the type-variable counter offset, and the
        // halt/body-unification concretizations — measured shapes,
        // not pure renumbering, so no isomorphism/renumbering/
        // expected-form computation can close the gap without
        // re-implementing the pin's allocation order). The
        // registered sources' expectations are therefore PINNED
        // GOLDENS (byte-exact fixtures, committed and diff-audited
        // — a regeneration is a deliberate act via the regen test)
        // AND the structural anchors stay applied against the
        // oracle (the tdef record count, the function-name order,
        // the byte-identical diagnostics tail — the
        // cross-implementation discipline belt). The check
        // differential, the tree identity gate, the compile
        // artifact, and the B ≡ C gate carry the full drift
        // protection on every source.
        if !infer_differential_holds(name, &infer_text, oracle_infer) {
            return Err(format!(
                "[{name}] the infer differential: the twin inferencer drifted from the oracle axes (or the registered golden)"
            ));
        }
    }
    // ---- the compile segment: the artifact ----
    compile_via(&products.compiler, &items).map_err(|err| format!("[{name}] {err}"))
}

/// The TD-032 registered-divergence goldens (the blade-6 closure):
/// the raise-carrying chain sources' expected twin-side infer
/// dumps, byte-exact — the fixtures are committed artifacts (a
/// regeneration runs the deliberately-`#[ignore]`d regen test and
/// lands as a reviewable diff). The registration table IS the
/// carrying set — the r198/r200/r201 matches! exemption is revoked
/// (no name-based special-casing anywhere else).
pub fn registered_infer_golden(name: &str) -> Option<&'static str> {
    match name {
        "ccf-lexer" => Some(include_str!("fixtures/td032_ccf_lexer_infer.txt")),
        "ccf-expander" => Some(include_str!("fixtures/td032_ccf_expander_infer.txt")),
        "ccf-compiler" => Some(include_str!("fixtures/td032_ccf_compiler_infer.txt")),
        "ccf-parser" => Some(include_str!("fixtures/td032_ccf_parser_infer.txt")),
        _ => None,
    }
}

/// The registered-divergence differential (TD-032's blade-6
/// closure — the abc differential and the audit's AZ08 ride this
/// same classifier): the twin dump holds when it equals the oracle
/// outright (the comparable sources) OR when it is byte-identical
/// to the source's pinned golden AND the structural anchors hold
/// against the oracle (the carrying sources — the golden is the
/// strict expectation, the anchors the cross-implementation
/// belt).
pub fn structurally_anchored_divergence(twin: &str, oracle: &str) -> bool {
    // The diagnostics tail — the product face — must be
    // byte-identical (zero diagnostic drift).
    let twin_tail = twin.split(") (diags").nth(1).unwrap_or("");
    let oracle_tail = oracle.split(") (diags").nth(1).unwrap_or("");
    if twin_tail != oracle_tail {
        return false;
    }
    // The tdef record sequences: same count, same function-name
    // order (any loss, shift, or rename fails).
    let a: Vec<&str> = twin.split("(tdef ").skip(1).collect();
    let b: Vec<&str> = oracle.split("(tdef ").skip(1).collect();
    a.len() == b.len()
        && a.iter()
            .zip(b.iter())
            .all(|(x, y)| x.split(' ').next().unwrap_or("") == y.split(' ').next().unwrap_or(""))
}

/// The registered-divergence differential itself (TD-032's blade-6
/// closure): true when the twin dump equals the oracle outright, or
/// when the source is a registered carrier whose golden the twin
/// dump matches byte-for-byte while the structural anchors hold
/// against the oracle. The r198/r200/r201 open-ended matches!
/// exemption is revoked — the golden table above IS the
/// registration, and any divergence outside it fails.
pub fn infer_differential_holds(name: &str, twin: &str, oracle: &str) -> bool {
    if twin == oracle {
        return true;
    }
    registered_infer_golden(name)
        .is_some_and(|golden| twin == golden && structurally_anchored_divergence(twin, oracle))
}

/// One CCF's twin-side infer dump (the TD-032 golden regeneration
/// path and the audit's AZ08 row): the A pass's items through the
/// compiled infer twin (the check twin rides alongside — the check
/// segment's own product), rendered by the shared decoder. The
/// regeneration is the deliberately-run regen test's business; the
/// differential gates never write.
pub fn ccf_infer_dump(name: &str, source: &str) -> Result<String, String> {
    let (_bc, items) = rust_compile_ccf(name, source)?;
    let (infer_bc, _) = rust_compile_ccf("ccf-infer", &ccf_infer_source())?;
    let (check_bc, _) = rust_compile_ccf("ccf-check", &ccf_check_source())?;
    let (_check_text, infer_text) = check_via(&check_bc, &infer_bc, &items)?;
    Ok(infer_text)
}

// ---------------------------------------------------------------------------
// The pipeline — the three passes + the K159 gate
// ---------------------------------------------------------------------------

/// One artifact's evidence row (the counts disclose the scale; the
/// identity is the `Bytecode` itself, compared by the gates).
#[derive(Debug, Clone)]
pub struct ArtifactRow {
    pub name: &'static str,
    pub protos: usize,
    pub consts: usize,
    pub insns: usize,
    pub globals: usize,
    pub externs: usize,
}

fn artifact_row(name: &'static str, bc: &Bytecode) -> ArtifactRow {
    ArtifactRow {
        name,
        protos: bc.funcs.len(),
        consts: bc.consts.len(),
        insns: bc.funcs.iter().map(|f| f.code.len()).sum(),
        globals: bc.globals.len(),
        externs: bc.externs.len(),
    }
}

/// The A/B/C pipeline's report: the three passes' artifact rows,
/// the K159 gate (`b_eq_c` — THE gate), and the parity observation
/// (`a_eq_b` — disclosed, never a substitute for the gate).
#[derive(Debug, Clone)]
pub struct AbcReport {
    pub a: Vec<ArtifactRow>,
    pub b: Vec<ArtifactRow>,
    pub c: Vec<ArtifactRow>,
    /// B ≡ C byte-identical on all six artifacts — the K159
    /// fixpoint gate.
    pub b_eq_c: bool,
    /// A ≡ B byte-identical on all six artifacts — the parity
    /// observation row (the twin compiler equals the oracle; it
    /// HOLDS by gate B, and the pipeline discloses it, but the
    /// K159 gate is B ≡ C regardless).
    pub a_eq_b: bool,
    /// The first divergence's name, for the failure line (None
    /// when the gate holds).
    pub divergence: Option<&'static str>,
}

impl AbcReport {
    /// The one-line gate summary (the failure-line lineage).
    pub fn gate_line(&self) -> String {
        match self.divergence {
            Some(name) => format!(
                "abc pipeline K159 gate FAIL [B != C on {name}] (b_eq_c={} a_eq_b={})",
                self.b_eq_c, self.a_eq_b
            ),
            None => format!(
                "abc pipeline K159 gate PASS (b_eq_c={} a_eq_b={} on six artifacts)",
                self.b_eq_c, self.a_eq_b
            ),
        }
    }
}

/// Run the whole A/B/C pipeline (the fixed-length chain, the
/// explicit artifacts, the K159 gate). The caller supplies nothing
/// — the six CCFs are the pipeline's own inputs; the seed is the
/// Rust compiler (the A pass). Expect the run to take tens of
/// seconds on the release profile (twelve full-chain
/// self-compilations ride the VM).
pub fn abc_pipeline() -> Result<AbcReport, String> {
    // ---- the shared inputs: the CCFs + the oracle expectations ----
    let ccfs = ccf_sources();
    let mut a_artifacts: Vec<Bytecode> = Vec::with_capacity(ccfs.len());
    let mut oracle_rows: Vec<(Vec<ModuleItem>, String, String)> = Vec::with_capacity(ccfs.len());
    for (name, source) in &ccfs {
        let (bc, items) = rust_compile_ccf(name, source)?;
        // The oracle axes ride the A pass's items (the same items
        // the tree identity gate pins the chain's expansion to).
        let oracle_check = oracle_check_axes(&items);
        let oracle_infer = oracle_inference_axes(&items);
        a_artifacts.push(bc);
        oracle_rows.push((items, oracle_check, oracle_infer));
    }
    let a_products = ChainProducts {
        lexer: a_artifacts[0].clone(),
        parser: a_artifacts[1].clone(),
        expander: a_artifacts[2].clone(),
        infer: a_artifacts[3].clone(),
        check: a_artifacts[4].clone(),
        compiler: a_artifacts[5].clone(),
    };
    // ---- the B pass: the chain via the A products ----
    let mut b_artifacts: Vec<Bytecode> = Vec::with_capacity(ccfs.len());
    for ((name, source), (items, oracle_check, oracle_infer)) in ccfs.iter().zip(&oracle_rows) {
        let bc =
            chain_compile_ccf_via(&a_products, name, source, items, oracle_check, oracle_infer)?;
        b_artifacts.push(bc);
    }
    let b_products = ChainProducts {
        lexer: b_artifacts[0].clone(),
        parser: b_artifacts[1].clone(),
        expander: b_artifacts[2].clone(),
        infer: b_artifacts[3].clone(),
        check: b_artifacts[4].clone(),
        compiler: b_artifacts[5].clone(),
    };
    // ---- the C pass: the chain via the B products ----
    let mut c_artifacts: Vec<Bytecode> = Vec::with_capacity(ccfs.len());
    for ((name, source), (items, oracle_check, oracle_infer)) in ccfs.iter().zip(&oracle_rows) {
        let bc =
            chain_compile_ccf_via(&b_products, name, source, items, oracle_check, oracle_infer)?;
        c_artifacts.push(bc);
    }
    // ---- the gates ----
    let names: Vec<&'static str> = ccfs.iter().map(|(n, _)| *n).collect();
    let mut b_eq_c = true;
    let mut a_eq_b = true;
    let mut divergence: Option<&'static str> = None;
    for (i, name) in names.iter().enumerate() {
        if b_artifacts[i] != c_artifacts[i] && divergence.is_none() {
            b_eq_c = false;
            divergence = Some(name);
        }
        if a_artifacts[i] != b_artifacts[i] {
            a_eq_b = false;
        }
    }
    let report = AbcReport {
        a: names
            .iter()
            .zip(&a_artifacts)
            .map(|(n, bc)| artifact_row(n, bc))
            .collect(),
        b: names
            .iter()
            .zip(&b_artifacts)
            .map(|(n, bc)| artifact_row(n, bc))
            .collect(),
        c: names
            .iter()
            .zip(&c_artifacts)
            .map(|(n, bc)| artifact_row(n, bc))
            .collect(),
        b_eq_c,
        a_eq_b,
        divergence,
    };
    Ok(report)
}

// ---------------------------------------------------------------------------
// The CCF slot-name single sources (the audit rows pin these)
// ---------------------------------------------------------------------------

/// The canonical (injection-channel) slot name for each CCF — the
/// compiled global the products reference and the channel binds.
/// The pairs are (ccf name, canonical slot): the skin map's Rule K
/// canonicalization (`source_bytes` → `source-bytes`) is verified
/// by the A pass itself (a product that did not reference its slot
/// would fail the channel at run time).
pub const CCF_SLOTS: &[(&str, &str)] = &[
    ("ccf-lexer", STEADY_TARGET_SOURCE_NAME),
    ("ccf-parser", STEADY_TP_TOKENS_NAME),
    ("ccf-expander", STEADY_FORMS_NAME),
    ("ccf-infer", STEADY_ITEMS_NAME),
    ("ccf-check", STEADY_ITEMS_NAME),
    ("ccf-compiler", STEADY_ITEMS_NAME),
];

// ---------------------------------------------------------------------------
// The steady-compiler equivalence probe (the compile segment's
// dual-form row: the injected route vs the assembled baked route)
// ---------------------------------------------------------------------------

/// The compile segment's cross-route equivalence: the compiler
/// twin consuming the items through the INJECTION channel (the
/// steady face this window introduces) must produce the identical
/// bytecode to the assembled baked-prefix route (`ktf_compile_rich`
/// — the fixpoint's own face). One twin, one items stream, two
/// delivery faces, byte-identical products.
pub fn steady_compiler_equivalence(
    items: &[ModuleItem],
) -> Result<(Bytecode, Option<Bytecode>), String> {
    let steady_bc = {
        // The r148 `co_limit` parameterization: the twin's depth
        // check references the work-budget global — the assembly
        // carries the default-budget define (the
        // `assembled_compiler_target_source` form; the verification
        // faces ride the default, never the process env).
        let assembled = crate::bootstrap::target_corpus::assembled_compiler_target_source();
        let mut session = Session::new();
        let program = pipeline::parse_target_with_injected(
            &mut session,
            "steady-compiler-chain.ktf",
            &assembled,
            &[kerf_span::Symbol::new(STEADY_ITEMS_NAME)
                .expect("the injected name is a valid identifier")],
        )
        .map_err(|diags| {
            format!("harness defect: the steady compiler program failed to parse: {diags:?}")
        })?;
        let findings = program.typecheck();
        if findings
            .iter()
            .any(|d| d.severity == crate::diagnostic::Severity::Error)
        {
            return Err(
                "harness defect: the steady compiler program failed the checker".to_string(),
            );
        }
        compile_program(&program.items).map_err(|err| {
            format!("harness defect: the steady compiler program failed to compile: {err}")
        })?
    };
    let steady = compile_via(&steady_bc, items)?;
    let assembled =
        crate::bootstrap::target_corpus::ktf_compile_rich(items, COMPILER_TARGET_SOURCE)?;
    Ok((steady, assembled.bytecode))
}

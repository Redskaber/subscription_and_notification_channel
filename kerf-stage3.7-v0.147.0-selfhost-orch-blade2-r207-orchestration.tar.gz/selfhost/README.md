# selfhost/ — the self-hosted production chain (`.ktf`, the sole skin)

The compiler's own front end, type faces, compile segment, and package
management logic, written in the kerf subset itself and driven through
the production pipeline. Since the T-a switch (r145-r149) and the
S-expr retirement (W-SEXP-RETIRE, r150-r154) the target skin (`.ktf`)
is the one and only skin: the nineteen files below are the production
chain plus the std area — read, expand, infer, check, compile,
the kerf-pkg logic five, and the effect-instance vocabulary packs
(`std/`, W-EFFECT-INSTANCES blades 1-3 r192-r194 + the W-SELFHOST-ORCH
blade-2 render pack r207) — with the Rust segments
retained as the seed-chain oracle
(verification surface) and the VM as the permanent Rust base (the
constitutional exclusion, SOP §2.2 principles 41/53).

Design record: `docs/stage0.md` §9.46-§9.48 (RS/EX/MX ruling families),
§9.83-§9.87 (CP two passes, the composed chain), §9.96 (the step-3
corpus translation), §9.98 (the two-skin corpus closeout), §9.113
(K140-K142 the bootstrapping-order anchors). Ledger single source:
`docs/develop/v3/s-expr-conversion-record.md` (per-file accounting).

## The std area (W-EFFECT-INSTANCES blades 1-3 r192-r194 — the window CLOSED, the effect-family chain fully closed; + the W-SELFHOST-ORCH blade-2 render pack r207 — the MX-1 retirement)

| File | Layer | Lines | Role |
|---|---|---|---|
| `std/state.ktf` | effect instance | 73 | the State<T> vocabulary pack — the generation-chain form (INST-6): `state_run` (one generation; `put` takes the halt path returning the marker pair) + `state_thread` (the generation chain — each put opens the next generation and the restarted `get` reads it; the polysemy Tactics isomorph, the state riding the interpreter's recursion line) |
| `std/error.ktf` | effect instance | 52 | the Error<E> vocabulary pack — `attempt` (the raise clause does NOT call k, the §9 table's own halt wording; the return clause as the success branch) + `unwrap` (the ok/raise route with the domain-totality fallback arm) |
| `std/log.ktf` | effect instance | 44 | the Log vocabulary pack — `with_log` (the degenerate clause: the handler returns nil and the body always continues) + `with_log_via` (the injectable facade, the m6 convention) |
| `std/read.ktf` | effect instance | 49 | the Read vocabulary pack (blade 2, r193) — `with_read`: the buffered read bridge, each `perform read(src)` resuming at the next seeded line (the §9 "resume injection" row — `read_line()` in the handler body rides the §8.8 host channel, the side effect living in the host, the vocabulary in the language) |
| `std/write.ktf` | effect instance | 55 | the Write vocabulary pack (blade 2, r193) — `with_write`: the buffered write bridge, `write_line(payload)` in the clause body (the §9 "side effect lives in the handler body" row) then `k(nil)` resuming with the completion confirmation; composes with `with_read` by thunk chaining (`with_read(|| { with_write(p) })` — the inner handle pushed inside the outer one's dynamic extent) |
| `std/async.ktf` | effect instance | 41 | the Async vocabulary pack (blade 3, r194) — `with_async`: the synchronous pass-through degenerate policy on the §9 strategy slot, each `perform await(task)` resuming immediately at the task's own value (`k(task())` — the handler body evaluates the thunk inline); the §5.4 honest boundary rides as the closed note: the real scheduler stays the strategy replacement slot (a later window's concern, the concurrency domain is L3 — zero channels rides the eight-primitive freeze) |
| `std/render.ktf` | effect instance | 67 | the Render/Serialize vocabulary pack (ORCH blade 2, r207 — the MX-1 retirement) — `with_render`: the value display render, each `perform render(dst, value)` emitting the value's display text as one line through the same §8.8 channel (`render_line(value)` in the clause body — the write precedent extended: the side effect lives in the host, the vocabulary in the language; the display formatting is the io.rs "later library concern" line arriving as the library face OVER the channel — the string-interning lineage: identity in-language, rendering at the host edge) then `k(nil)` resuming with the completion confirmation |

## The twelve production pieces

| File | Layer | Lines | Role |
|---|---|---|---|
| `v1/target-lexer.ktf` | target lexical | 1,133 | the `.ktf` byte-surface lexer twin (W-TGT-READ-TWIN blade 1, r136) — every lexical decision over the raw byte table (trivia, whitespace, reject set, atom classification, the i64 threshold guard, escape validation) — modernized onto the G8 surface at W-SELFHOST-MODERN blade 3 (r177): match-arm operator maximal-munch table (int-literal lead/two-byte/three-byte nested arms), the trivia set, the scan mode machine, scalar annotations (representation-identical, mapping table w-selfhost-modern-window §11); W-SELFHOST-MODERN-2 blade 3 (r198): the Error vocabulary consumption — the whole rejection family (the three error constructors with their 28 call sites unchanged: the construction IS the short-circuit, plus the trivia scanner's unclosed-delim arm) takes the one-shot raise with the CONTRACT error record as the payload, the two check sites in tl_start dissolve, the top-level verdict rides the attempt wrapper; the success frames drop the dead "t"/"s" discriminant heads and destructure through nested pair patterns (the Rust-reader boundary: the chain built-in parses through the frozen reader, which predates the row vocabulary — mapping table w-selfhost-modern2-window §9.4 M35-M41) |
| `v1/target-parser.ktf` | target parse | 4,750 | the `.ktf` Pratt parser twin (blade 2/3, r138-r139; the frame-machine form) — token records in, Stx tree out; grew with the type-annotation (r165), struct (r166), and enum (r168) declaration faces — modernized onto the G8 surface at W-SELFHOST-MODERN blade 6 (r180): the frame machine (33 states, the give cascade with the machine-drop `_`), the guarded phase machines (the is_nil(phase) fresh-state family), the phase/step families, the token/datum tables, the tp_bin_ops int-literal level table, the leave guard's sixteen arms, scalar annotations (representation-identical, mapping table w-selfhost-modern-window §14); W-ROW-POLY blade 1 (r182): the row type's type-layer kernel — the ("row" fields tail) representation, the row spec's resolve modes, the scoped-labels unification machine (RW-1..RW-6, mapping table w-row-poly-window §8.1; the r174 frozen-oracle ruling's first consumer — the twin grows rows, the Rust oracle never does); W-ROW-POLY blade 2 (r184): the `[l: T; tail]` annotation skin + the row literal/pattern read faces (RW-12/13/14, mapping table §8.2 — the row-spec/row-lit/row-pat machines, the semicolon tail ruling); the r203 modern-2 blade-6 closing surgery: the whole parse-rejection family rides `perform raise` through the three tp_err_* helpers (nine construction sites, the 50 call sites unchanged), the 100 post-error guards dissolve, the entry rides unwrap(attempt(thunk), identity) with the result define byte-frozen, and the give protocol's dead "done" head retires (21 constructions drop the never-dispatched discriminant; mapping table w-selfhost-modern2-window §9.10 M77/M78) |
| `v1/macro.ktf` | 1.7 macro face | 757 | the MX-2 pure-function library — syntax-rules with zero driver defines (assembled ahead of the expander) — modernized onto the G8 surface at W-SELFHOST-MODERN blade 4 (r178): match-arm mode machines (the pattern compiler and matcher, the instantiation walk), the matcher's pattern family, the binder head names, scalar annotations; the shadowed helper copies co-modernized at blade 5 (r179) with the expander (22 shared names, ex_gen's dispatch on match arms, identical bodies machine-checked); the r200 modern-2 blade-4 adjudication: ZERO effect-family consumption (the single err site is the shadow-pair contract face — blade 5 territory with the expander; the live-tag census finds zero label-key navigation) — zero code changes, the header note carries the two rulings (mapping table w-selfhost-modern2-window §9.6 M55'/M56'); the r201 blade-5 co-modernization: both copies of the shadow pair take the Error vocabulary in one surgery (ex_fail's raise body identical in both files, the one dead-nil and the one defsyn-publish guard dissolve, the ex_err cell retires); W-SELFHOST-ORCH blade 1 (r206): the file carries its own `import "std/error"` declaration — the composition layer's dependency statement (the composer splices first-seen; the unit registry names it `macro`) |
| `v1/expander.ktf` | 1.6 expansion | 5,090 | the MX-2 assembly carrier — flat pre-order form stream in, ModuleItem tree out (one self-recursive expander + synthetic node modes); the struct/enum/pattern police families and the GZ-4 exhaustivity machinery live here (r166/r168/r170) — modernized onto the G8 surface at W-SELFHOST-MODERN blade 5 (r179): the synthetic-mode machine on match arms (nine modes, the `_` arm carrying the depth guard and the real tree), the expression-head and declaration-head dispatches, the loader edge table, the extern type-tag table, the annotation family (representation-identical, mapping table w-selfhost-modern-window §13); W-ROW-POLY blade 2 (r184): the row consumption folds (RW-13/14, mapping table w-row-poly-window §8.2 — the rowlit/rowlit-nil/rowpat synthetic modes, the cons-chain fold, the pcvar-family displacement patterns, the closed nil guard); the r201 modern-2 blade-5 consumption: the whole expansion-rejection family rides `perform raise` through the ex_fail helper (the payload records verbatim, the 113 call sites unchanged), the post-error guard arms dissolve (39 walk guards + 6 between-helpers), and ex_run rides unwrap(attempt(thunk), identity) — the ok/err records byte-frozen (mapping table w-selfhost-modern2-window §9.8); W-SELFHOST-ORCH blade 1 (r206): the file declares its own dependency set — `import "std/error"` + `import "macro"` — the MX-2 assembly's composition knowledge moved into the source (the composed chain byte-identical to the retired prepend) |
| `v1/infer.ktf` | 3.12 HM inference | 5,532 | the segment-three inference face — the `infer_module` mirror: iterative Algorithm W, union-find with undo, let-polymorphism, the SCC partition, the extern boundary; `Type::Struct`/`Type::Enum` nominal faces (r165/r168) — modernized onto the G8 surface at W-SELFHOST-MODERN blade 6 (r180): the W machine's unify step on match arms (string-domain arms, the `_` record domain carrying the var guards and the nested tag match), the walk machines (resolve/occurs/annotation/var/subst), the spec resolver's eight-mode table, the task machine's enter/dispatch heads, the name tables, the tarjan dispatcher, scalar annotations (representation-identical, mapping table w-selfhost-modern-window §14); W-ROW-POLY blade 1 (r182): the row type's type-layer kernel — the ("row" fields tail) representation, the row spec's resolve modes, the scoped-labels unification machine (RW-1..RW-6, mapping table w-row-poly-window §8.1; the r174 frozen-oracle ruling's first consumer — the twin grows rows, the Rust oracle never does); W-ROW-POLY blade 2 (r184): the `[l: T; tail]` annotation skin + the row literal/pattern read faces (RW-12/13/14, mapping table §8.2 — the row-spec/row-lit/row-pat machines, the semicolon tail ruling); the r203 modern-2 blade-6 closure rulings: ZERO code change — the C2 census finds zero err sites (the diagnostics accumulation architecture, the blade-3 typecheck boundary-② form), the C1 closes on the M72 three grounds (the Rust-reader boundary, the live-tag census, the accessor family as the items-stream cross-file contract), and the C4 face lands at the golden archive (arrow-with-row has no target-skin surface — the ei08/ei09 pins are the delivery face; mapping table w-selfhost-modern2-window §9.10 M74-M76) |
| `v1/typecheck.ktf` | 3.12 check face | 1,304 | the segment-three conservative checker — the `check_module` mirror: pass-1 module table, the R1-R8 rule walk, the captured-assignment boundary, multi-error collection, the annotation-divergence face (E0013, r165) — modernized onto the G8 surface at W-SELFHOST-MODERN blade 3 (r177): the judgment-face dispatch on match arms (scalar tag tables, walk-mode tables, the callee-analysis pair patterns, the resolution nil-union faces), scalar/str/bool annotations (representation-identical, mapping table w-selfhost-modern-window §11); W-SELFHOST-MODERN-2 blade 3 (r198): the boundary-2 survey holds (the walk never short-circuits — the accumulation architecture, zero Error-vocabulary sites), the extern table's entries and the let stack's frames drop their dead discriminant heads and ride bare value chains with nested pair patterns (the Rust-reader boundary — mapping table §9.4 M42-M45) |
| `v1/compiler.ktf` | 2.3 CP two passes | 1,917 | the fully self-hosted compile segment — the gate-B dual-caliber carrier (pass 1 lexical-domain analysis; pass 2 instruction emission); the variant-arm/pattern compile faces (r168/r170) — modernized onto the G8 surface at W-SELFHOST-MODERN blade 4 (r178): the two-pass dispatch on match arms (the child-count/assemble tag tables, the opcode stack-effect tables, the emitter walker's synthetic-mode and real-tree tag tables — the fixpoint carrier reading itself through the new surface), the drain-scan jump dispatch, scalar annotations (representation-identical, mapping table w-selfhost-modern-window §12); the r198 modern-2 blade-3 in-round fix (M47): the handle emit's return-effect pre-intern retired — the value is computed in the clause loop at the push-handler's own intern point, the oracle's in-loop form aligned (the first-ever handle-carrying chain source exposed the slot shift; mapping table w-selfhost-modern2-window §9.4 M47); the r200 modern-2 blade-4 consumption: the compile-rejection family rides `perform raise` with the contract error records verbatim (the one-shot unwinding replaces the cp_err cell and the seven post-error guards), the estate/proto discriminant heads drop (the product render rebuilds the proto head), and cp_run rides unwrap(attempt(thunk), identity) — the ok/err records byte-frozen (mapping table w-selfhost-modern2-window §9.6 M50-M55) |
| `v1/micro-toml.ktf` | pkg logic | 680 | the kerf-pkg micro-TOML subset parser twin (W-PKG-SELFHOST blade 1, r156) — modernized onto the G8 surface at W-SELFHOST-MODERN blade 1 (r175): struct Span/Pos records, match-arm byte classification and result-record dispatch, scalar annotations (representation-identical, mapping table w-selfhost-modern-window §9); modernized onto the effect-family surface at W-SELFHOST-MODERN-2 blade 1 (r196): the raise-path Error-vocabulary consumption (M6-M12) plus the open-frame row literals/patterns (M13/M14), the external doc/verdict shapes byte-frozen (mapping table w-selfhost-modern2-window §9) |
| `v1/semver.ktf` | pkg logic | 340 | the version-algebra twin (blade 2, r157) — modernized onto the G8 surface at blade 1 (r175): struct Version/Constraint records with generated accessors, match pair-pattern dispatch, scalar + struct-typed annotations (representation-identical); modernized onto the effect-family surface at W-SELFHOST-MODERN-2 blade 1 (r196): the component walkers take the one-shot raise path with the original records as payloads, the public parse faces keep their frozen ok/err contracts through the attempt wrapper (M1-M5) |
| `v1/manifest.ktf` | pkg logic | 545 | the kerf.toml projection twin (blade 2, r157) — modernized onto the G8 surface at W-SELFHOST-MODERN blade 2 (r176): struct Slot/Dep records with struct-typed fields (the first twin consumer of the nested resolve face), match pair-pattern tag/value dispatch, int-literal key-matcher constant tables, the syntax pass-through cons identity (representation-identical, mapping table w-selfhost-modern-window §10); W-SELFHOST-MODERN-2 blade 2 (r197): the Error vocabulary consumption — the four scan rejections, the bad-version rejection, the three dep-entry rejections and the two section rejections all take the one-shot raise path with the original records as payloads, the threading cascades dissolve into direct lets, the projection entry keeps its frozen contract through the attempt wrapper (mapping table w-selfhost-modern2-window §9.2 M17-M21) |
| `v1/lockfile.ktf` | pkg logic | 703 | the kerf.lock model + deterministic serialization twin (blade 3a, r158) — modernized onto the G8 surface at blade 2 (r176): Span slot payloads + Version accessor reads, match tag/value dispatch, key-matcher constant tables (representation-identical); W-SELFHOST-MODERN-2 blade 2 (r197): the Error vocabulary consumption across the render guard / globals scan / close-field-walk rejections / format checks, plus the C1 row consumption — lk_field returns the bare row literal [name: .., ver: .., src: ..] and the walk destructures through the closed row pattern (mapping table §9.2 M22-M28 + M33/M34) |
| `v1/resolve.ktf` | pkg logic | 553 | the dependency-graph resolver twin (blade 3b, r159; conflict mid-list fix r160) — modernized onto the G8 surface at blade 2 (r176): Dep/Slot/Span accessor reads over the manifest twin's own products, phase/color/status match-arm discriminants with the top-level nil pattern (representation-identical); W-SELFHOST-MODERN-2 blade 2 (r197): the Error vocabulary consumption — the depth cap, both gray cycles, the five dep-walk rejections, the diamond conflict and the three root rejections all raise with their original records, the phase-crossing recursion binds the returned ctx directly, the entry keeps its frozen contract through the attempt wrapper; the C5 State-generation evaluation closed no-consumption (the explicit ctx threading is the natural form — mapping table §9.2 M29-M32); W-SELFHOST-ORCH blade 1 (r206): the file declares the five-piece chain's own dependency set (`import "std/error"` + the pkg four in dependency order) — the §9.142 five-piece composition moved into the source |

Line counts: `wc -l` at v0.147.0 (W-SELFHOST-ORCH blade 2, r207 —
the serialization face: the render pack + the render-line builtin row
plus the four twin registries' own covariant rows — the expander/macro
`ex_globals` pair, the checker's `tc_builtin_arity`, the infer twin's
`ti_is_builtin`).
Total: **23,316 lines** (v1/, the r207 twin-surgery counts; with std/
seven files 381 the family total is 23,697)
across the twelve v1 files and seven std files (nineteen total) — the ledger single source
(`docs/develop/v3/s-expr-conversion-record.md`) carries the per-round
accounting; any drift between that ledger and `wc -l selfhost/{v1,std}/*.ktf`
is an §8.4.5 violation by the ledger's own audit rule.

## Bootstrap status (one paragraph)

The bootstrap-completion standard (SOP §21.12-28③: fully off the host
language, constitutional exclusions aside) was declared **GO at r163**
after the C1-C4 audit (deep-review-bootstrap-completion.md): the
composed `.ktf` chain reads, expands, checks, and compiles through the
twins with the junction products feeding forward (never an oracle
intermediate), gate B holds both calibers (byte-identical bytecode and
the three-phase fixpoint `C_t(C_t(S')) == C_t(S')`), and the kerf-pkg
logic rides the twin arm in production (W-PKG-SELFHOST CLOSED r160).
The self-hosting matrix G1-G8 is all green (G8 language foundation
closed r170). The VM/runtime stay the permanent Rust base — a VM
rewrite is not on any roadmap (the constitutional exclusion).

## Hosting conventions

- **target-lexer.ktf** (W-TGT-READ-TWIN RS-1): the host encodes the
  source text as one integer per byte — `define(source_bytes, quote(
  (104, 101, ...)))` — and every lexical decision rides plain integer
  arithmetic (K20 permanent host layer: f64 value faces and string
  payloads stay host-side).
- **target-parser.ktf**: the host injects the token table —
  `define(tokens, quote((record, ...)))`; positions ride as decimal
  byte-offset strings, carried opaquely.
- **expander.ktf** (EX-1, the MX-2 assembly): the host injects the
  flat pre-order form stream — `define(forms, quote((record, ...)))`;
  `"list"` records carry their child count so depth stays inside the
  nesting cap. W-SELFHOST-ORCH blade 1 (r206): the file composition
  rides the source's own `import` declarations through the composer
  (first-seen, §9.64 discipline — the assembled program is the
  composed `std/error` + `macro` + `expander` chain, byte-identical
  to the retired host-side prepend). Budget globals (`ex_limit`,
  `co_limit`) still ride the assembly head (the blade-4 prefix-family
  sweep owns their retirement; r146/r148).
- **compiler.ktf / infer.ktf / typecheck.ktf** (CP-1 record grammar,
  the `items` channel): the host injects the EXPANDED item tree as a
  flat pre-order record stream — `define(items, quote((record, ...)))`;
  the segment-three twins bind the tdef table and the diagnostics
  (code/severity/span/template-payload/subjects); the extern records
  ride the stream with entries inline (the r124 junction-3 face).
- **pkg five** (micro-toml, semver, manifest, lockfile, resolve):
  W-SELFHOST-ORCH blade 1 (r206): the five-piece dependency-order
  composition rides `resolve.ktf`'s own `import` declarations through
  the composer (std/error → micro-toml → semver → manifest →
  lockfile → resolve, byte-identical to the retired host-side
  splice); the twins bind their input documents through the same
  `quote` record channels and return structured verdict records
  decoded host-side.
- **Junction feeds** (§9.87 JX-1): the junction products feed forward
  — the `.ktf` reader's forms, the `.ktf` expander's rebuilt items,
  the compile — never an oracle intermediate (the honest fixpoint
  direction).
- The source tail binds the verdict — `define(result, ("ok" ...))` or
  `("err" kind payload ...)` — which the host rebuilds and renders
  through the same `Display` (parity transparent by construction).

## Consumers (who reads the twelve)

| Consumer | Face |
|---|---|
| `crates/kerf-driver/src/bootstrap/target_corpus.rs` | the `*_TARGET_SOURCE` constants (`include_str!` ×7) + the assembled expander source + the prefix assembly (the RS-1/EX-1/CP-1 injection family) + the rich-compile faces |
| `crates/kerf-driver/src/bootstrap/{infer,typecheck,compiler,expander,target_lexer,target_parser}_parity.rs` | the per-segment parity faces: oracle verdict renderers, twin decoders, the CP-1 payload builders |
| `crates/kerf-driver/src/bootstrap/{micro_toml,semver,manifest,lockfile,resolve}_parity.rs` | the pkg-logic parity faces (W-PKG-SELFHOST) |
| `crates/kerf-driver/src/bootstrap/steady_*.rs` | the steady chains (expander / target reader / compiler / typecheck) — compile once through the production bridge, per-check injection |
| `crates/kerf-driver/src/bootstrap/{composed_full_chain,composed_target_read_chain,fixpoint,abc_pipeline}.rs` | the composed-chain parity, the fixpoint drivers, and the acceptance-corpus pipeline |
| `crates/kerf-driver/src/pkg_selfhost.rs` | the kp twin arm (`RESOLVE_TARGET_SOURCE` + the production three-state band) |
| `tests/v1/stage1/plan/` (50 families) | the sweep/parity/fixpoint/determinism/segment-switch families + `selfhost_format_guard_tests.rs` (the format invariants below) + `subset_corpus_tests.rs` (the acceptance corpus, 170 rows) |

(The historical tamper-anchor pinning list — three contiguous
substrings pinned by the retired `composed_target_chain_tests.rs` —
left the tree with that family's reorganization; the live discipline
is unchanged: **any token-level change to a twin requires a full
parity rerun of its consumer family**, comments and whitespace
included in spirit even though they are not tokens.)

## Format conventions (machine-checked)

`tests/v1/stage1/plan/selfhost_format_guard_tests.rs` pins three
invariants over **all twelve files**:

1. **line width ≤ 100 columns** (SOP §10.5; the same bound rustfmt
   enforces on the Rust face);
2. **the non-ASCII whitelist = {`—`, `§`}** (the em-dash is the
   repo-wide parenthetical convention; `§` anchors ride verbatim);
3. **no ASCII parenthetical dashes** (` - ` / `  -  `) — prose dashes
   are em-dashes (the `.ktf` comment marker is `//`).

## Honest boundaries (registered)

- **MX-1**: the subset has no string construction — mangled names ride
  as structured records, decoded host-side (decision-face parity).
  The rendering asymmetry itself RETIRED at W-SELFHOST-ORCH blade 2
  (r207 — `std/render.ktf` + the `render-line` builtin row): the
  value→bytes edge now rides the §8.8 write channel as the library
  face OVER it — the vocabulary in the language
  (`with_render`/`perform render`), the display formatting staying
  host-side (the read_line precedent's form: the side effect lives
  in the host — the string-interning lineage: identity in-language,
  rendering at the host edge). The in-language render is pinned
  digit-by-digit against the host Display (the census golden, the
  ORCH-D caliber).
- **float payloads**: inf/NaN have no literal shape — every float
  rides as Debug text (host-side parse is exact).
- **shared global environment**: user `define`s may shadow Stage 0
  builtins (first/second/rest...) — the twin expander and the user
  program share the VM global environment; a shadow corrupts expander
  internals in the combined run (pos-402, r170). Corpus-avoided +
  registered as a P2 (tech-debt r170); the police families own the
  long-term fix.
- **the VM stays Rust** (the constitutional exclusion): this directory
  is the bootstrap chain's language face; a VM rewrite is not on any
  roadmap (SOP §2.2 principles 41/53).
- **the Rust segments stay as oracle**: `read_program` /
  `expand_program` / `compile_program` / the infer-check pair remain
  the tree's truth sources for parity verification (BS-A) — they are
  verification surface, not the production chain.

## History notes

- The seed-skin S-expr originals of the five bootstrap twins were
  removed at r104 (E5 batch 3); the S-expr skin left the tree entirely
  at r151 (W-SEXP-RETIRE blade 2: corpus, reader, twins, transcoder —
  the `lexer.ktf`/`reader.ktf` S-expr twins retired then, 812 lines),
  completing at r154 with the word-face/ledger teardown (~292 sites,
  TEST-5 zero-scan guard). The production chain reads `.ktf` only.
- The pkg-logic five entered at r156-r160 (W-PKG-SELFHOST, closed with
  the Rust logic arm retired to the build-bootstrap fallback band).
- The G8 language-foundation blades (r165-r170) grew the twins with
  the type-annotation, struct, enum, and pattern faces (+3,940 lines
  over the r160 baseline) — the twins implement the new surfaces in
  production while the Rust oracle keeps parity.

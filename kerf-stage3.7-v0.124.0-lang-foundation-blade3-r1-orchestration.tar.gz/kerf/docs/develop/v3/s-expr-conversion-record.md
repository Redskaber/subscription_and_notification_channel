# S-expr→目标语言完全转化统一记录（s-expr-conversion-record.md）——转化面台账与审计单源

> **Status**: **转化终态 + 拆除完成**（v1.1——r154 W-SEXP-RETIRE 刀 3 收口：S-expr 表面四层全拆〔语料层 r150 + 读链层 r151 + 词面层/台账层 r154〕；expander.ktf TD-028 (name, generation) 帧表示迁移 +119 行〔2,230→2,349〕；全树词面清零守卫化〔TEST-5——任何 S-expr 表面复活即红〕；台账七件 14,497 → **14,616 行**；r140 新建——用户指令⑫落位：自举阶段实现「S-expr 完全完整转化为目标语言内容」时，同步统计与记录到对应 docs/develop/ 下对应版本的统一完全转化记录文件，便于人工与 Agent 查阅审计）
> **r151 改账（刀 2）**：S-expr 读链两孪生退役离账（lexer.ktf 671 + reader.ktf 141 = 812 行——W-SEXP-RETIRE 刀 2 随 S-expr 读链本体退役）；target-parser.ktf 68 行超宽重排（3,281→3,658——纯空白重排零语义变更，格式守卫七件全覆盖配套）；台账九件 14,932 → **七件 14,497 行**。
> **r156 入账（W-PKG-SELFHOST 刀 1——纯新写非转化）**：micro-toml.ktf 603 行入 selfhost 台账（第八件——首件非编译段孪生：kerf-pkg 的 micro-TOML 子集解析器；**非 S-expr 转化面**——Rust oracle（micro_toml.rs 468 行）与新孪生逐位镜像但孪生从零新写；入账依据 = 审计口径 `wc -l selfhost/v1/*.ktf` 全件覆盖，selfhost 家族账本不按「是否转化」分叉）；台账七件 14,616 → **八件 15,219 行**。

> **r157 入账（W-PKG-SELFHOST 刀 2——纯新写非转化）**：semver.ktf 304 行 + manifest.ktf 494 行入 selfhost 台账（第九/第十件——版本代数孪生 + kerf.toml 投影组合孪生〔首个三孪生组合程序：micro-toml + semver + manifest 单程序拼接〕；均为**非 S-expr 转化面**纯新写——Rust oracle〔semver.rs 219 + manifest.rs 267〕与新孪生逐位镜像）；台账八件 15,219 → **十件 16,017 行**。
> **r159 入账（W-PKG-SELFHOST 刀 3 后半——纯新写非转化）**：resolve.ktf 473 行入 selfhost 台账（第十二件——依赖图解析器孪生：三色 DFS + 后序拓扑 + 菱形约束汇总 + 深度护栏，**家族首个五件组合程序**〔mt+semver+manifest+lockfile+resolve 顺序拼接〕，单自递归 phase 判别驱动〔oracle 单 visit 同构〕；**非 S-expr 转化面**纯新写——Rust oracle〔resolve.rs 291 行〕与新孪生逐位镜像）；台账十一件 16,676 → **十二件 17,149 行**。kerf-pkg 逻辑面五模块 .ktf 孪生**全承载完成**。
> **r160 改账（W-PKG-SELFHOST 刀 4——窗口 CLOSED）**：resolve.ktf 473→478（+5——conflict 中位违例缺陷修复〔rs_check_imposed 全表透传参 all + 修复注释〕；零新件——刀 4 = 全语料回归 + Rust 逻辑臂退役落档轮）；台账十二件 17,149 → **17,154 行**（审计口径 `wc -l selfhost/v1/*.ktf` 逐位吻合）。W-PKG-SELFHOST 窗口 CLOSED @ r160（出口条件四条全 ✓——G5 闭合入账）。
> **r158 入账（W-PKG-SELFHOST 刀 3 前半——纯新写非转化）**：lockfile.ktf 659 行入 selfhost 台账（第十一件——kerf.lock 模型 + 确定性序列化孪生：parse 往返面 + render 归一面双驱动，组合装配 micro-toml + semver + lockfile 三件；**非 S-expr 转化面**纯新写——Rust oracle〔lockfile.rs 324 行〕与新孪生逐位镜像）；台账十件 16,017 → **十一件 16,676 行**。
> **流程权威**: docs/sop.md v15.3（§8.4.5 文档同步 / §8.6 worklog 协议 / §2.2 原则 41 脚手架生命周期）
> **职责边界**: 本文件承载 **Rust 宿主实现 →目标语言（.ktf 目标皮肤源）完全转化面的逐件台账、刀级谱系、累计口径与未转化面清点**；单轮转化叙述仍由 RELEASE_NOTES + worklog 承载（三处单源互链：本台账 + bootstrap-completion-plan.md 窗口行 + stage0.md §9.12X 设计层记录）。拆除面规划 = bootstrap-completion-plan §4.4（W-SEXP-RETIRE——G7）。
> **登记义务**: 每新增一个转化面（某 Rust 编译段组件的全量 .ktf 镜像交付）必须在本台账新增一行 + bootstrap-completion-plan 对应窗口行刷新 + RELEASE_NOTES 当轮行记载（三处同步——缺一 = §8.4.5 文档同步违例）。

## 1. 一行定位

kerf 自举 = 把「用 Rust 写的编译器各段」逐段转化为「用 kerf 写的等价实现（.ktf 孪生）」，并以 parity 位级 + fixpoint 自复现证明转化完整。本台账是这些转化面的统一账本：**每一行 = 一个 Rust 组件获得了完整的目标语言等价物**。

## 2. 转化面台账（十二件 · 17,154 行——r160 改账：resolve.ktf 473→478〔刀 4 conflict 中位违例修复〕；r159 入账：resolve.ktf 473〔刀 3 后半纯新写孪生——依赖图解析器〕；r158 入账：lockfile.ktf 659〔刀 3 前半纯新写孪生——锁文件模型 + 序列化〕；r157 入账：semver.ktf 304 + manifest.ktf 494〔刀 2 纯新写孪生——版本代数 + 组合投影〕；r156 入账：micro-toml.ktf 603〔刀 1 纯新写孪生，首件非编译段〕；r154 刀 3 改账：expander.ktf TD-028 帧迁移 +119；r151 刀 2 改账：两 S-expr 读链孪生退役离账 −812 + target-parser 重排 +377；v0.109.0 时点原测 = 九件 14,932）

| # | 孪生件 | 行数 | Rust 镜像源（被转化物） | 首次交付 | 终形/刷新 | 所属窗（段） | 转化性质 |
|---|---|---|---|---|---|---|---|
| ~~1~~ | ~~lexer.ktf~~ | ~~671~~ | crates/kerf-reader/src/lexer.rs | r100 · v0.65.0 | **r151 退役离账**（W-SEXP-RETIRE 刀 2——S-expr 读链本体随 scaffold 移除，孪生同步退役；历史行保留作谱系） | Stage 2.7 / W-3.12 段一 | 服役 51 轮（r100→r151），终态 r121 生产化 |
| ~~2~~ | ~~reader.ktf~~ | ~~141~~ | crates/kerf-reader/src/parser.rs | r100 · v0.65.0 | **r151 退役离账**（同上——两孪生 812 行合计） | Stage 2.7 / W-3.12 段一 | 服役 51 轮（r100→r151），终态 r121 生产化 |
| 3 | macro.ktf | 686 | crates/kerf-expander/src/{lib,code}.rs 宏面（660 源行） | r100 · v0.65.0 | r122 段二刷新（extern 警察五面 + 稳态展开链） | Stage 2.7 / W-3.12 段二 | 宏引擎全量转化 |
| 4 | expander.ktf | 2,349 | crates/kerf-expander/src/expand.rs（750 源行） | r100 · v0.65.0（子代理超时草稿 + 主代理验收手术） | r122 段二刷新（1,346→1,671）+ r143 TD-027 match 臂（1,671→2,227——r144 补账）+ r146 ex_limit 预算镜像参数化（2,227→2,230）+ **r154 TD-028 帧表示迁移（2,230→2,349——六推送位 (name, generation) 条目 + 代纪律解析链 + ex_externs 全局表）** | Stage 2.7 / W-3.12 段二 | 展开器全量转化 |
| 5 | compiler.ktf | 1,850 | crates/kerf-compiler/src/compile.rs（1,257 源行） | r100 · v0.65.0 | r124 消费臂（cp_extern_walk）+ r133/r134/r135 融合刀共变（CallGlobal/F1/LLC）+ r148 co_limit 预算镜像 + 深度臂 bool 契约 + extern 全局索引计数器（+46） | Stage 2.7 / W-3.12 段三 | 编译器（CoreExpr→字节码）全量转化 |
| 6 | infer.ktf | 3,774 | crates/kerf-typecheck/src/infer.rs（HM 推断） | W-HM-TWIN 127 刀族（r126 开窗 → r129-r131 交付完成） | r131 段三 ELEVATED（HM 判定面）+ r144 三缺陷修复刷新（3,690→3,774——join 结构相等/env 截断/边序） | W-HM-TWIN（段三） | HM 推断器全量转化 |
| 7 | typecheck.ktf | 1,234 | crates/kerf-typecheck/src/check.rs（判定面） | W-HM-TWIN 127 刀族（r126-r131） | r131 段三 ELEVATED | W-HM-TWIN（段三） | 类型检查判定面全量转化 |
| 8 | target-lexer.ktf | 1,065 | crates/kerf-reader/src/target/lexer.rs（目标皮肤词法器） | r136 · v0.97.0（W-TGT-READ-TWIN 刀 1——第八孪生） | — | W-TGT-READ-TWIN（G1） | 目标皮肤词法器全量转化（读自身皮肤的第一件） |
| 9 | target-parser.ktf | 3,658 | crates/kerf-reader/src/target/parser.rs（目标皮肤 Pratt 解析器 1,676 源行） | r138 · v0.99.0（W-TGT-READ-TWIN 刀 2——第九孪生，帧机形制） | r139 稳态链（SteadyTargetReaderChain）+ **r151 格式重排**（3,281→3,658——68 行超宽 `pair(...)` 状态帧重排至 ≤100 列，纯空白零语义变更；格式守卫 8→7 清单全覆盖配套） | W-TGT-READ-TWIN（G1） | 目标皮肤解析器全量转化 |

**累计口径**：十二件 · **17,154 行** .ktf 目标皮肤源（r160 改账：resolve.ktf conflict 中位违例修复 +5〔全语料回归面的直接产出——rs_check_imposed 全表透传〕；r159 入账：五件段孪生 = 9,893 行〔macro 686 + expander 2,349 + compiler 1,850 + infer 3,774 + typecheck 1,234〕+ 两件目标皮肤读链孪生 = 4,723 行〔target-lexer 1,065 + target-parser 3,658〕+ 五件包管理孪生 = 2,533 行〔micro-toml 603 + semver 304 + manifest 494 + lockfile 659 + resolve 473——W-PKG-SELFHOST 刀 1+2+3 全承载，纯新写非转化〕）。历史基线：r140 台账九件 14,932（v0.109.0 实测）；r143 补账 TD-027；r146 +3；r148 +46；r150 零共变；r151 −812 +377 = 14,497；r154 +119 = 14,616；r156 +603 = 15,219；r157 +798 = 16,017；r158 +659 = 16,676；r159 +473 = 17,149；r160 +5 = 17,154。审计口径：`wc -l selfhost/v1/*.ktf` 总行数 = 台账累计行（任何漂移 = 台账失账，判 §8.4.5 违例）。

## 3. 刀级谱系（转化面形成史——交付轮序）

| 轮 | 版本 | 转化事件 |
|---|---|---|
| r100 | v0.65.0 | **首波五件**（Stage 2.7 步③ .krf→.ktf 五件翻译：lexer/reader/macro/expander/compiler + 三路门[语义投影/行为/α-等价] + rest 碰撞手术 + 前缀孪生） |
| r121 | v0.83.0 | **段一生产化**（注入通道 inject_global + SteadyReaderChain 稳态链 + 段一 ELEVATED——read 段自举链完备） |
| r122 | v0.84.0 | **段二刷新与稳态链**（expander/macro 刷新 + SteadyExpanderChain + items 前缀 extern 编码缺陷清偿） |
| r123 | v0.85.0 | 段二 ELEVATED（CSYM 重归属后孪生语义面 = 展开器语义面——完备性由构造成立） |
| r124 | v0.86.0 | compiler.ktf 补消费臂（cp_extern_walk——junction-3 记录盲清偿）+ 构建编排宪法性排除裁定 |
| r126-r131 | v0.87.0-v0.92.0 | **HM 孪生刀族**（infer.ktf + typecheck.ktf 交付 + r131 段三 ELEVATED——前端三段全 ELEVATED） |
| r133-r135 | v0.94.0-v0.96.0 | compiler.ktf 融合共变（CallGlobal r133 + F1 直发算术 r134 + LLC 融合 r135——gate B 逐位 + fixpoint 自复现维持） |
| r148 | v0.109.0 | compiler.ktf co_limit 预算镜像参数化（ex_limit 先例——装配前缀 define + 自描述深度载荷携限值）+ cp_ewalk 错误臂 bool 契约修复（错误置位后返回 false 保 `if term` 消费面）+ extern 重复名全局索引计数器（oracle 跨块语义对齐）+46 行 |
| r136 | v0.97.0 | **target-lexer.ktf 第八孪生**（G1 刀 1——三向 parity + 自源先例） |
| r138 | v0.99.0 | **target-parser.ktf 第九孪生**（G1 刀 2——curated 91/91 + selfhost 九源固定点） |
| r143 | v0.104.0 | expander.ktf match 臂扩展（TD-027——行数 1,671→2,227，台账 r144 补账） |
| r144 | v0.105.0 | infer.ktf 三缺陷修复刷新（join 结构相等 + env 截断 + 边序——3,690→3,774；非新转化面：T-a CCF 新输入域暴露的 sweep 盲区缺陷） |
| r146 | v0.107.0 | expander.ktf ex_limit 预算镜像参数化（512 烘焙→装配前缀 `define(ex_limit, N);` + depth 载荷携 limit——tp_limit 先例；行数 2,227→2,230；非新转化面：expand 段生产位切换的预算 parity 义务） |
| r139 | v0.100.0 | **C1 链路闭合**（SteadyTargetReaderChain + K20 桥 + 组成链五联差分——零新转化面，链形/桥/组成层 Rust 侧工程） |
| r150 | v0.111.0 | **W-SEXP-RETIRE 刀 1——验收语料单皮肤迁移**（tests/v1/stage1/corpus/ 112 案 .krf→.ktf：机械 89 经转码器 + 手作孪生 11 + 阶段分歧 9 期望改钉目标面 parse-error + 退役 3〔neg-021/pos-031/neg-036——目标皮肤面无主语〕；逐案双皮肤等价预检三闸落档 tool-results/r150-migration-report.txt；**非段孪生转化面**——语料 = 验收载体换皮肤，台账九件行数零共变；七件 S-expr 段孪生维持至刀 2 读链退役时改账退役） |
| r151 | v0.112.0 | **W-SEXP-RETIRE 刀 2——S-expr 读链退役**（kerf-reader 本体三件 + lexer/reader.ktf 两孪生 812 行 + parity harness + 转码器全数离树；消费面 141 错误位点 ~46 文件转面；audit 减法共变 480→460 live + 124 retired；台账九件 14,932→七件 14,497） |
| r154 | v0.113.0 | **W-SEXP-RETIRE 刀 3——词面层/台账层收口 + 窗口 CLOSED**（全树词面清零 ~292 处/37 文件〔四子代理 154-a/b/c1/c2 并行 + 主代理守卫文件与 selfhost 位〕+ TEST-5 零扫描守卫化 + TD-028 (name, generation) 帧表示迁移〔expander.ktf 2,230→2,349——J03/孪生臂回迁生产臂〕+ subset-spec 状态行终态注记 + 台账升格转化终态；七件 14,497→14,616） |
| r156 | v0.114.0 | **W-PKG-SELFHOST 刀 1——micro-toml.ktf 孪生 + K15 parity**（第八件 selfhost 孪生 = 首件非编译段〔kerf-pkg manifest 文法解析器 603 行〕；RS-1 字节表信道复用 + 16 错误 kind 全镜像 + 负域 i64 累加器〔i64::MIN 幅值正域不可表示——target-lexer 先例〕；parity 三方〔Rust micro_toml vs 孪生双引擎〕48 案例全绿〔12 正 + 36 负 = 1:3〕；**纯新写非转化**——入账依据 = 审计口径全件覆盖；台账七件 14,616→八件 15,219） |
| r157 | v0.115.0 | **W-PKG-SELFHOST 刀 2——semver.ktf + manifest.ktf 双孪生 + 组合程序**（第九/十件 selfhost 孪生：版本代数 304 行〔Version/Constraint/caret_satisfies 全面 + 双信道 RS-1 + u64::from_str 逐位镜像〕+ kerf.toml 投影 494 行〔**首个三孪生组合程序**——micro-toml+semver+manifest 拼接 + define 顺序重绑定 + oracle 五步投影序 + BTreeMap 名序 + span 偏移回移 + 语法透传〕；parity 55 案全绿〔semver 36 + manifest 19〕；**纯新写非转化**；TD-030 登记〔内联嵌套 cons 参数位坍缩——let 中转绕道〕；台账八件 15,219→十件 16,017） |
| r159 | v0.117.0 | **W-PKG-SELFHOST 刀 3 后半——resolve.ktf 孪生**（第十二件 selfhost 孪生：依赖图解析器 473 行〔三色 DFS Gray 栈环路径 + 后序拓扑 + 菱形全约束汇总 + 深度护栏 K162 双生；**家族首个五件组合程序** mt+semver+manifest+lockfile+resolve；单自递归 phase 判别驱动——oracle 单 `visit` 内联扫描同构投影；当轮清偿四族七位点〔互递归合并/pkg_span 双解包/mt_append 裸追加四点/dep-dir 父目录约定〕；parity 30 驱动全绿〔正 9 + 负 20 + deep-chain-20〕+ kp 壳三态回退带 e2e 双臂 + 红绿回退；纯新写非转化；台账十一件 16,676→十二件 17,149；kerf-pkg 逻辑面五模块孪生**全承载完成**） |
| r160 | v0.118.0 | **W-PKG-SELFHOST 刀 4——全语料回归 + Rust 逻辑臂退役 + 窗口 CLOSED**（kp_corpus_tests 7 测试：pkg_window 命名语料缺位五族 + 三环/冲突菱形两变体面——双臂 stdout/stderr/exit 逐位；**中位违例缺陷当轮清偿**：rs_check_imposed 递归携带 rest(imposed) 致表中位违例丢满足前缀——oracle 整表抛出 PKG-3 语义；修复 = 全表透传参 all + parity 补钉 conflict-mid-list 第 31 驱动〔r159 巧合全绿根因 = 夹具违例恰在首位〕；Rust 五模块退役为构建引导回退带〔lib.rs 退役声明〕；台账改账 resolve.ktf 473→478〔17,149→17,154〕；出口条件四条全 ✓——**窗口 CLOSED + G5 闭合入账**，自举矩阵余 G6/G8） |
| r158 | v0.116.0 | **W-PKG-SELFHOST 刀 3 前半——lockfile.ktf 孪生**（第十一件 selfhost 孪生：kerf.lock 模型 + 确定性序列化 659 行〔parse 往返面 = `Lockfile::parse→to_text` 逐位 + render 归一面 = `new→to_text` 逐位——BTreeMap 名序插入排序 + 非规范版本 `0.01.0→0.1.0` 重渲染 + em-dash 头部字节表 + 数字→十进制字节构造〕；组合装配三件 mt+semver+lockfile；parity 双面 21+ 案全绿〔parse 4 正 + 17 负 + render 6 案〕；**纯新写非转化**；同轮 TD-030 误诊改判关闭——let 中转纪律解除；台账十件 16,017→十一件 16,676） |

## 4. 未转化面清点（S-expr 表面存续——G7 缺口账）

**已转化（上表九件）**：读（S-expr 读链 + 目标皮肤读链）/ 展（宏 + 展开器）/ 查（HM 推断 + 判定面）/ 编（编译器）——**编译管道四段全部拥有目标语言等价物**（C1 链路级闭合 r139）。

**拆除账（W-SEXP-RETIRE 于 r154 全窗收口——存续面清零）**：

| 面 | 终态 | 拆除刀 |
|---|---|---|
| S-expr 皮肤语料（tests/v1/stage1/corpus/ 112 案） | ✓ 已拆除 @ r150（109 .ktf 单皮肤 + 3 退役） | 刀 1 |
| Rust S-expr 读链（crates/kerf-reader/src/{lexer,parser,token}.rs） | ✓ 已拆除 @ r151（~4,700 行随 scaffold 移除） | 刀 2 |
| reader.ktf / lexer.ktf（S-expr 读链孪生——台账 #1/#2） | ✓ 已拆除 @ r151（812 行退役离账） | 刀 2 |
| skin_transcoder.rs 转码器 + 迁移机械臂 | ✓ 已拆除 @ r151（迁移完成即退役；迁移报告 tool-results/r150-migration-report.txt 在档） | 刀 2（前移自刀 3） |
| 全树词面（.krf 伪文件名/双皮肤分支/subset-spec 状态行） | ✓ 已清零 @ r154（~292 处 + TEST-5 零扫描守卫化——任何复活即红） | 刀 3 |
| VM 永久 Rust 基座 + K20 桥 + 构建引导层 | **宪制排除项**（永不入自举链不计转化分母） | 不拆除（宪法性排除——原则 53） |

## 5. 维护义务

- 新转化面 → 台账 §2 新行 + bootstrap-completion-plan 窗口行 + RELEASE_NOTES 当轮行（三处单源）
- 转化面刷新（既有孪生语义扩展）→ 台账 §2 终形列更新 + §3 谱系行追加
- W-SEXP-RETIRE 交付时 → §2 标记退役件 + §4 清点表清零 + 本文件状态行升格「转化终态 + 拆除完成」
- 审计口径：`wc -l selfhost/v1/*.ktf` 总行数 = 台账累计行（14,616 @ v0.113.0——任何漂移 = 台账失账，判 §8.4.5 违例；r149 零共变复核先例：workflow 语料为 .ktf 用户程序非孪生，台账行数与实测逐位一致）

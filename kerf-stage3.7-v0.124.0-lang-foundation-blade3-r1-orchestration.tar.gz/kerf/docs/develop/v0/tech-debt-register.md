# 综合技术债登记册（tech-debt-register.md）

> 依据：docs/sop.md §6.2.1。只追加不删除；已解决项保留历史并标注 `[Resolved at Stage N.M]`。
> **Author**: redskaber（模板口径沿袭 sop.md §6.6.1 样例）
> **Version**: v0.22.0（Stage 1.9 收口——无新 TD[末轮 L3 全流程：§9.50 检查器域审查零 ★ + D1-D8 全过 + §14.8 八项偏差全处置 + C1-C6 六检零整改 + 七件套终稿 + audit V 节 200 + 出阶段测试族；**Stage 1 全程 TD 开放项归零**——1.0 起连续十四轮；九信号全勾 + GO 推荐（用户确认最终门）]））
> **最后更新**: Stage 1.9（收口）/ 2026-09-29

### 1.6 架构摘要增量（展开层自举时点）

- **expander.krf 自举面第二件**：`selfhost/v1/`（切换窗步②第二切口；8 原语不变性第二十轮验证——纯消费者零新增面）。
- **互递归禁令的工程化解**：表达式展开器 = 单 define 自递归 + 五合成节点模式（mapx/letloop/doloop/clausemap/fnbind）——冻结子集「define 级互递归不可达」（neg-046 实证）的架构响应；REC-A 谱系第三实例。
- **扁平前序流编码**（EX-1）：255 深树注入不触 Reader 256 帽（嵌套编码需 depth+3 的实证推论）。
- **登记态窗口**（§9.47.5）：宏面窗（1.7 主窗——Macro 层 = oracle 占位）+ 词法层第二段窗（维持）+ evaluator 栈预算窗（维持）。

### 1.5 架构摘要增量（结构层自举时点）

- **selfhost/ 新根目录**（§8.4.6 跨 crate 全局面——自举面登记，切换窗步②首切口物理锚位）；.krf Reader = 既有 8 原语 + 18 内建 + 8 特殊形式纯消费者（零新增面——8 原语不变性第十九轮验证）。
- **kerf-reader 公共面补全**：`pub use kerf_span::{ByteOffset, FileId}`——既有签名类型可名化（零新 Cargo 边）。
- **登记态窗口三项**（§9.46.5）：词法层第二段窗（前置 = 字符串原语子集扩展裁定 K21）+ 字符串原语扩展窗（§9.44.5 三触发器沿袭）+ 输入带指令窗（第二段评估位）。

### 1.4 架构摘要增量（子集冻结时点）

- 验证基础设施五层齐备：快照 / 黄金 / 自举（parity 双引擎）/ 属性（PBT）/ **语料契约（本轮新增——目录制 .krf + ;; expect: 指令[ dg-* 模式] + parity 契约面 validate/validate_all）**；审计集 150（Q 节元审计——detector-detects）；语料 68 = pos 26 / neg 32 / bnd 10（期望全实证——探针轮 68/68 固化）。
- 工作树终态：1046 测试（crate 内联 12 + 根集成 81 净增——语料逐条 68 + 元 3 + 契约 12 - 字段共变 2）+ audit 150（A-Q）+ 基线 B1-B5 维持（契约面不在热路径——实测确认）；ParityReport 加性字段 globals_repr（构造位共变 3 处全披露）。

### 1.2 架构摘要增量（PBT 引入时点）

- 测试基础设施四层齐备（DEA-13 闭合）：快照（57 冻结）/ 黄金（渲染字节契约 + 版本黄金）/ 自举（parity 双引擎）/ **属性（本轮新增——proptest 1.11.0 dev-dep[^1.9 约束解析 1.x line] + 七属性：双引擎 parity/运行时陷阱/归约语义/静态 E0006/reader 不动点/VM 确定性/算术 oracle）**；良构生成器 typed 三通道（Int/Bool/Any——深度帽 4 + define 帽 4 + ±2⁴⁰ oracle 带）；审计集 130/130 维持（PBT 与样例审计互补裁定——不扩节）。
- 工作树终态：890 测试（根集成 +9[7 属性 + 2 域自检]——cargo test 函数口径，生成用例量 448）+ audit 130（A-N）+ 基线 B1-B5 维持；生产依赖面零变化（proptest 仅 [dev-dependencies]——§18.5 dev 侧豁免位）。

### 1.1 架构摘要增量（driver 接线时点）

- 新内部边 L4.5→L8（kerf-typecheck→kerf-driver——消费边无环；Externals 第三消费位单源构造）；管线终态 = read→expand→typecheck→{compile→VM, eval}（检查器 Error 级执行前中止 / Warning 级附着 Outcome 三面非阻断）；DiagnosticCode::Typecheck(TypeCode) 数据携带变体（渲染 tag = E0xxx 注册码——两方案接线处汇合）；REPL 警告增量重放（前缀规则与 outputs 同款）；审计集 130（+N 节十案）。
- 工作树终态：881 测试（driver 内联 118[+25] + 根集成 210[+10]——cargo test 口径）+ audit 130（A-N）+ 基线 B1-B5 维持；生产面 .unwrap 0 / glob re-export 0 / §11 反向边 0 维持。

## 1. 已解决项（Resolved）

| ID | 描述 | 解决阶段 | 验证方式 |
|----|------|---------|---------|
| TD-002 | `Span::join` 跨展开代合并被拒绝（JoinExpansionMismatch）：跨代合并语义属宏期关注点，未定义 | **[Resolved at Stage 0.4]** 裁定三（plan-0.4.md §4）：0.4 展开器零 span 构造（脱糖节点复用源 span 同代次）→ 跨代 join 结构性不发生；拒绝语义保持为设计行为（fail-closed）；0.9 宏系统登记 span 集合表示议程（def-site ∪ use-site——非点合并） | fib/do 契约测试全产出 span join 折叠全成功（单代次实证）+ syntax_seed_tests 跨代次拒绝穿透（0.2）守护 |
| TD-004 | §18.5 依赖图未含 kerf-span→kerf-core 边，与 stage0.md §8.6「IR 节点携带 Span」存在张力 | **[Resolved at Stage 0.1]** 裁定二（docs/develop/v0/stage-0/0.1-design-adjudications.md）：全节点携带必填 Span（非 Option）+ 加边 L0→L4 + dataflow.md 同步 | core_seed_tests.rs 8/8（span 归约双向模式 + Span 不变量穿透聚合路径） |
| TD-005 | 原语集双轨口径（r67 现行真值集 vs §3.2 历史冻结集）待正式裁定落文 | **[Resolved at Stage 0.1]** 裁定一（同上文件）：CoreExpr 九语义原语 + ModuleItem 三声明变体 + do→Let 脱糖；§6.12.6 语义等价映射双向闭合；八原语 ANF 形态登记为 Stage 2 评估目标（零实现义务） | expr.rs kind_name 九变体断言 + 裁定文映射表闭合论证 + ALG-C 会签 |
| TD-001 | 行/列渲染延后：Span 仅存字节偏移（stage0.md §12.1 渲染期派生原则），LineIndex 与行列派生属诊断渲染层 | **[Resolved at Stage 0.8]** 裁定十三（plan-0.8.md §4）：`LineIndex` 渲染期派生落位（1 基行 + 1 基**字符**列——CJK 终端真值；中点字符向下取整 + 越界钳制——确定性不 panic）+ rustc 风格渲染收口（`error[code]: msg` + `--> file:line:col` + 源摘录 + 脱字符下划线 + 多诊断汇总行）；`Diagnostic.primary_span: Option<Span>` 诚实设计（无位变体免伪造——免 `-->` 免摘录） | line_index 13 + render 13 内联测试 + 审计 I01/I10 + seed 渲染黄金字节契约 + CJK 字符列可区分断言（1:19 vs 字节列 1:21） |
| TD-003 | 8 个骨架 crate 待实现（结构性脚手架——计划内，非事故性桩）；core@0.1、syntax@0.2、reader@0.3、expander@0.4、compiler@0.5、vm@0.6、runtime@0.7、**driver@0.8** | **[Resolved at Stage 0.8]** 全部落位（**9/9 crate**——0.0 章程 TD-003 终态清零）：kerf-driver = 管线编排（Engine 双引擎）+ Session/LineIndex/诊断渲染 + CLI/REPL（session-replay 裁定十二）+ bin `kerf`；L1→L8/L7→L8 新边裁定十一入档 | 六命令冷构建 551:0:0 + 审计 80/80 + E2E 22 case（五类源可达错误类经 driver 全点亮）+ `cargo run --bin kerf` 全命令族实测 |
| TD-006 | docs/stage0.md 文件头版本标签（v8.8）滞后于内容实态（v9.9——尾部附录 G v7 终态注记 + §9.43）；上游存档保持原样不改写 | **[Resolved at Stage 1.0]** 用户显式指令开窗（M1 先例——r74「用户指令 = 需求信号本体」）：文档状态行 v8.8→v9.9（增量链叙述 + v8.8 基线描述保留）+ 版本历史「v7.0（当前）」过期标签修正（→历史）+ v7.1-v8.8 / v9.1-v9.9 两条合并条目 + 文件尾附录 G v9 终态注记（v9.9 版本终态 + 四处一致声明）——TD 账面归零 | 四处一致性核验（v9.9 命中文档状态行/版本历史合并条目/附录 G v9 终态注记 + lang-design/README 代偿说明退役） |

## 2. 剩余项（Open）

| ID | 描述 | 等级 | 目标解决 | 阻塞条件 |
|----|------|------|---------|---------|
| TD-007 | 宏声明目标皮肤面：`define-syntax`/`syntax-rules` 规则携带裸表数据——目标表达式文法无裸表参数位（quote 包裹改变宏系统匹配树）；调用形 `name!(...)` 可用，声明形未实现 | **[Resolved at Stage 3.3 · r114]** W-3.3 窗清偿：`macro name { spec }` 声明载体落位（花括号 item 形 + spec datum 模式逐字承载——匹配树不变性构造性成立）+ datum 面词汇扩展（运算符规范名表 + `...` 符号 + 裸 `-`）+ 转码器机械臂（MacroDeclaration 变体退役）；9 语料案 = 8 案机械转正 + pos-031 转词汇分歧钉扎（`else` 表达式位关键字经济边界——声明面已可拼，使用形边界为既有设计非宏面缺口） | target_corpus_sweep_tests 族钉扎（8 案双皮肤契约 + pos-031 三段钉扎）+ 门审 AH 节 10 案 + AF8 翻正 |

## 3. 架构摘要（Stage 0.10 时点）

- 流水线：`Reader → Expander → Compiler → VM → Runtime` + Driver 编排（九层 9/9）+ **基础卫生宏系统**（define-syntax/syntax-rules 变换器 + CodeValue 结构化代码值 + 模块加载层[三色 DFS 环检测 + LoadPlan] + quote 数据字面量）+ **reserved 冻结面**（kerf-core/src/reserved/ 四模块：EffectSystem/MultiStage/CapabilityIO/CompilationCache + 行为规格 kit——§22.3 四接口项全 ✅；零入边自含抽象——除 std 外零依赖[裁定十七]；全图见 docs/graph/stage-0/dataflow.md）
- 测试计数：**672**（分项 = span 40 + core 77[+36：reserved 内联 30 + api 6] + syntax 40 + reader 54 + expander 85 + compiler 44 + vm 55 + runtime 42 + driver 97 + 根集成 runner 138[+12 reserved_seed]；正负比 272:400 = 1:1.47——0.10 轮 32:16 反向偏差申报见 plan-0.10.md §3[预留轮验收面结构性正向]）+ §7.3.1 审计集 100 case（examples/audit/stage0_gate_audit_r1.rs 可重跑——30→…→100 单调增长；**七类 7/7 维持**）
- Span::DUMMY 状态：**不存在 DUMMY span**——`Span::new` 为校验构造（start ≤ end 强制），空 span 合法但携带真实偏移；CoreExpr/ModuleItem/SyntaxObject（含 reader 产树全节点）span 为必填字段（非 Option——结构性无 DUMMY，TD-004 裁定二延展至语法/读取层）；compiler debug_info 逐指令平行（除空程序冷启动锚一处零 span 构造——plan-0.5.md §4 决策 15）；未来任何 DUMMY 引入即 P1（§6.2 分级审查）
- 枚举分支覆盖：SpanError 三变体 + CoreError 三变体 + SyntaxError 二变体 + ReadError 十变体 + ExpandError **九变体**（+MacroPatternMismatch/+QuoteUnsupportedDatum，0.9）+ **ModuleError 三变体**（ModuleCycle/ModuleNotFound/ModuleDuplicate，0.9）+ **CompileError 十三变体**全部有负向断言（构造拒绝/合并拒绝/消息渲染/R8 形态；InvalidSymbol 三 crate 渲染逐字节一致——单源字典）
- 错误系统状态：kerf-span / kerf-core / kerf-syntax / kerf-reader / kerf-expander / kerf-compiler 均手写 `std::error::Error`（零外部依赖——§18 审查规避裁定沿袭）；CompileError（十三变体，0.5——verify 公共面裁定四：编译期簿记 + 产物自检两道防线）；**RuntimeError（十变体，0.6——全携带 Span 回查 + span() 消费面；七类 #4/#5 点亮 → 6/7）**
- 原语集真值：CoreExpr 九语义原语（r67 命名）+ ModuleItem **四声明变体**（+DefineSyntax，0.9）——单一事实源 = crates/kerf-core/src/{expr,module,symbol}.rs（TD-005 裁定一）；八原语 ANF 形态 = Stage 2 评估目标（登记态，零实现义务）
- 字节码真值：Opcode 24 操作码（§8.12 七分组 + Perform/Handle 承载扩展）+ Instr{op,a,b} 双槽 + FuncProto（code/debug_info 平行）+ Bytecode 五件套（funcs/consts/globals）——单一事实源 = crates/kerf-compiler/src/{opcode,bytecode}.rs；`Bytecode::verify` = 唯一合法性判据（DAG 深度传播 + 结构校验）；三层帽序 reader 256 < expander 512 < compiler 1024（逐层 2× 裕量）
- 运行时真值（0.6）：Value 八变体 + Heap 单调分配（§19.4 安全点 = 分配预算 u32——0.7 gc_cycle 挂接点）+ 帧三扩展槽冻结（ext1/ext2 Reserved + ext3 实名）+ STAGE0_GLOBALS 18 名播种注册表（Builtin::ALL 单源）+ DEFAULT_BUDGET 8MiB（帧+堆单元合账）——单一事实源 = crates/kerf-vm/src/{value,builtin,frame,vm}.rs；0.5 缺陷修复：end_closure cur_stack LIFO（多闭包产物正确性——plan-0.6.md §4 回归对）

### 架构摘要 0.11 增量（末轮收口时点）

- 快照层 57（tests/v0/stage0/plan/snapshot_seed_tests.rs——L1→L8 六分节全链冻结 + 黄金值录制纪律 + 共变义务文档化）+ 性能基线 B1-B5（examples/bench/stage0_baseline.rs std-only 可重跑 + performance-baseline.md 回归口径）+ 深验七件套（docs/develop/v0/stage-0/ + docs/tests/pipeline-test-coverage.md）——Stage 0 出阶段评审 GO（§21.5 九信号 + §22.3 十二项全勾）。
- 工作树终态：767 测试（内联 489 / crate API 78 / 根集成 200）+ audit 110（A-L）+ 基线 5 项；生产面 .unwrap 0 / .expect 33（全带理由）/ TODO 族 0 / glob re-export 0 / §11 反向边 0。
- 登记顺带项（非 TD）：闭包创建整帧 locals.clone（vm.rs:244——Stage 2 优化窗捕获分析）；builtin.rs 四处裸 unreachable!()（臂前守卫完备——Stage 1 E0xxx 议程顺带补消息惯例）。



## 4. 分类索引

- 按 §6.1 等级：**开放项 0（TD-007 已清偿 @ Stage 3.3 · r114）+ 登记窗十三件（W-PERF-ENV-COPY / W-TGT-TOKEN-ZERO-COPY / W-DRIVER-HARNESS-SPLIT @ r106 已清偿 @ 3.1；W-DIAG-OPCODE-CONTEXT @ r108；W-DIAG-FORM-NOTATION @ r109；W-EVAL-RETIRE @ r115；W-GEN-GC @ r119；W-CSYM-EXPR @ r122 **已清偿 @ 3.12 · r123**；W-BOOT-FRONTEND @ r108 + W-HM-TWIN @ r124 **双双已清偿 @ 3.12 · r131**——段三 ELEVATED + BS-A 前端全段收敛；**W-VM-SUPERINSTR（EXC-10）@ r68 登记 → r132 升格实施窗 → r133 首刀 + r134 次刀（F1 直发 + 窗口关闭）——已清偿 @ 3.7 · r134（两刀全链 + 诚实带账 0.75×）**；**W-JIT-METHOD-T1 @ r132 登记 → r134 开窗（三触发器全命中）→ r135 开窗轮裁定交付（TJ-1..TJ-5）——见 r135 检视；W-REC-DEPTH + W-TGT-READ-TWIN @ r135 新登记（自举完备总规划承载——bootstrap-completion-plan.md v1.0）**）**｜已解决 ×6（TD-004/005 @ 0.1，TD-002 @ 0.4，TD-001/TD-003 @ 0.8，**TD-006 @ 1.0**）｜缺陷修复 ×3（0.5 end_closure cur @ 0.6；0.7 invoke 悬垂 @ 0.7；0.8 TapeIo/stdin @ 0.8——均 §20.6 当轮闭环零遗留）｜0.10/0.11/1.0 轮：无新 TD
- 按 §11.3 接口隔离违规（L-PIPE-N）：无
- 按 §10 命名违规（L-NAMING-N）：无
- 按 §13.4 重构判据（J1-J6）：无

### r106 登记窗三件（全管道审查轮——P3 处置三分类的登记窗面；蓝图先行，零信号不开窗）

| ID | 描述 | 状态 | 触发器 |
|---|---|---|---|
| W-PERF-ENV-COPY | vm.rs invoke 每调用 `data.env.clone()` O(captured)——闭包创建 O(captured)（★1' 已兑现）之外的每调用拷贝；B2 基准带内无信号 | **[Resolved at Stage 3.1 · r111]** 实施清偿：Rc<Vec<Value>> 共享不可变捕获区（结构性不变量验证——无 store-to-captured 操作码 + 细胞 env 创建后零变更）；B6d 新轴 141.7→108.8ns（−23.5%）+ 创建面 +9~19% 带内 + B4 第二十次逐位（K91 守护）；裁决册 = docs/develop/v3/w3.1-performance-window.md §2（三选一论证 + 权衡披露） | ~~Stage 3+ 性能窗开窗~~（已消费——r111 行权轮） |
| W-TGT-TOKEN-ZERO-COPY | target.rs TgtToken 每令牌 String 词素分配（S-expr 面 K137 零拷贝纪律未对齐）；text 仅错误路径消费 | **[Resolved at Stage 3.1 · r111]** 实施清偿：`text: &'src str` 源切片（生命周期内化 target 模块）+ digits_text Cow（无 `_` 零分配解析）；错误路径独占消费经全量清点证实（err_unexpected 单点——错误位自付 to_string）；B10 1.01x 带内 + B4 逐位；裁决册 = w3.1-performance-window.md §4 | ~~目标面性能信号 或 错误路径重构窗~~（已消费——随窗开启一并裁决） |
| W-DRIVER-HARNESS-SPLIT | driver 10,906 LOC 中验证 harness 族 6,795 行（62%）持续生长；E5 共享设施 19 符号引用 ≥3 无死码（保留正当） | [Open · P3 · 观察态] r106 登记（106-b-3）；Stage 3+ 验证面继续扩张时评估 kerf-selfhost-harness crate 拆分——须与 refactoring-optimality「维持不重构」六裁定重新核对 | harness 族再增 >30% 或新验证域入驻 driver |

**r106 复审推翻记录（如实登记）**：106-b-2 报告 `Heap::get_mut` 为「仅测试消费死码」——主代理复审实测 kerf-runtime/src/gc.rs:201 为生产收集器消费（活码）——零改动；审查发现以代码为准的实例（与 §9.44.3 symbol 行诚实修正同族）。

### r108 登记窗两件（阶段间审查轮——108-b 专审缺口清偿面；蓝图先行，零信号不开窗）

| ID | 描述 | 状态 | 触发器 |
|---|---|---|---|
| W-BOOT-FRONTEND | 前端自举推进缺口本体：BS-A 端态（前端三段+HM+构建编排全自举）与实况差距（read/expand/typecheck 生产面全 Rust 引擎、.ktf 孪生仅验证面、HM/构建编排零孪生）无收敛路径窗口——r107 stage-3-plan v1.0 十窗缺位（108-b 五源核查）；用户硬规则常设指令「一个编译阶段完整自举后才能进入下一阶段自举」的需求信号承载 | [Resolved @ 3.12 · r131——**段三 ELEVATED + BS-A 前端全段收敛**] 前身登记态：r108 专审登记；r111 首刀维持 + r120 T-b 激活；r121 段一 ELEVATED + r123 段二 ELEVATED + r124 段三裁定窗闭合（构建编排宪法性排除 + HM 补孪生确认 + junction-3 当轮清偿）；r126 W-HM-TWIN 窗开启；**r131 段三 ELEVATED**（三判据全过——w-hm-twin-window.md v1.4 §5 单源）→ **账面全清偿**：BS-A 端态五切口全部收敛（read r121 + expand r123 + HM r131 三段 ELEVATED + compile 孪生在位[非独立段位] + 构建编排宪法排除）；余量 = T-a 生产位切换条件（非本窗 scope——W-3.7 JIT 后 <10×） | ~~Stage 3 行权 → W-3.12 开窗~~（已消费 r111）→ ~~T-a/T-b 二选一~~（**r120 T-b 已激活**——SOP v15.3 §21.12-28④：用户常设指令①语言自我推进需求即纯度需求信号；T-a 降格为生产位切换条件）——~~W-3.12 段一实施窗升首要入口~~（**r121 已消费**——段一 ELEVATED）→ ~~段二 expander 完整自举实施窗~~（**r122 已消费**——段二实施窗全链：稳态展开链 + 孪生刷新五面 + 升格重裁 = **NOT ELEVATED**[判据①未过]）→ ~~W-CSYM-EXPR 能力裁定窗~~（**r123 已消费**——路径 b C 域谓词重归属实施 + 段二升格重裁 = **ELEVATED**——w3.12 §6c/§6d 单源）→ ~~段三 HM/构建编排裁定窗~~（**r124 已消费**——三议题分面裁定：构建编排宪法性排除 + HM 补孪生确认 + junction-3 当轮清偿；w3.12 §6e 单源）→ **W-HM-TWIN 实施窗开启**（**r126 已开启**——用户常设指令①自举演进规划兑现：K146-K149 知识层 + TWIN-1..5 形态裁定 + 127-a..e 排期；w-hm-twin-window.md v1.0 单源）；T-a 生产位切换条件维持（W-3.7 JIT 后 <10×） |
| W-DIAG-OPCODE-CONTEXT | 运行期 type-mismatch 上下文的操作码词汇面：r108 FIX-1 已清偿内建名/用户名皮肤感知（target_name/target_context + 六单源合成函数）；残留 = 操作码上下文（「add operand」「jump-if-false condition」「call callee」）的表面构造感知（用户书写面 `+`/`if`/调用形——两皮肤同形非皮肤分歧，属诊断质量面非残留） | [Open · P3 · 登记态] r108 108-b 登记（FIX-1 部分清偿后的残留面）；LSP 结构化诊断载荷设计的候承载面 | W-3.9 LSP 窗（结构化诊断载荷设计节） |

### r109 登记窗一件 + 观察裁定三件（阶段间审查轮——三角度审查处置面）

| ID | 描述 | 状态 | 触发器 |
|---|---|---|---|
| W-DIAG-FORM-NOTATION | MalformedForm 静态描述的形状记法皮肤感知：消息内嵌 s-expr 形状记法（如 "expected (require \"module-name\") with a string module name"）向 .ktf 用户呈现 s-expr 记法——与 F1/F2 同族但机制不同（静态 &'static str 描述非 Symbol 载荷，subject 供给面不适用；正确修法 = 形状描述的皮肤感知双面化，属结构化诊断载荷设计） | P3 登记态 | W-3.9 开窗（LSP 结构化诊断载荷设计时一并承载——与 W-DIAG-OPCODE-CONTEXT 同窗） |

观察裁定三件（登记不实施——无缺陷驱动）：
- **infer.rs 2,676 行 / expand.rs 2,202 行单文件不拆裁定**：单关注文件（无孪生模式可镜像——crate 内兄弟文件均为单关注面）；拆分 = 无一致性缺陷驱动的品味性变更（§2.3 正确>妥协：无正确性收益的重组 = churn 风险）；K126 权衡——rustc 的拆分以关注点为界不以行数为界。
- **driver/driver target_corpus.rs 与 cbackend emit.rs 转义 8 行近孪生不合并裁定**：不同消费面（.ktf 数据载体转义 vs C 字符串转义——转义域不同）+ 跨 crate 依赖方向约束（cbackend 不依赖 driver）；r106 FIX-9 已在 driver 内单源化（emit_escaped_string）。
- **ModuleNotFound 显式 kebab 串的用户面呈现**：target face 写 require 串 "m-a"（显式 kebab）时错误呈现 target 拼写 `m_a`（canonical m-a 的目标面拼法）——按 F5 语义这是「教导正确拼法」非腐蚀（字符串面已被字典接管）；边界行为如实登记。

### r110 检视（环境回归修复轮——零新 TD；观察裁定一件）

- **零新 TD**：v0.73.0 工具链配对事件（12 个 c_backend_e2e 全灭 exit 127）当轮全量闭环——根因定位（环境性非树缺陷）+ 双边界 scrub + 诊断面 + 三面防护证明（+4 测试）落位；树内无残留债务。
- **观察裁定一件（登记不实施——环境侧非仓内缺陷）**：cc wrapper **自身内部** glibc 混装场景（多 nixpkgs 修订 flake 输入拼装 dev-shell——解释器在链接期被 wrapper 烘焙错配）scrub 不可治 → `loader_abort_report` 可行动诊断承载（§2.3-4 报错>静默）；用户侧行动 = 重建一致 dev-shell。设计层：stage0 §9.105.4。
- **开放项复核**：TD-007 @ P3 登记态维持 + 登记窗六件（W-PERF-ENV-COPY / W-TGT-TOKEN-ZERO-COPY / W-DRIVER-HARNESS-SPLIT / W-BOOT-FRONTEND / W-DIAG-OPCODE-CONTEXT / W-DIAG-FORM-NOTATION）零信号维持——r110 触发器核对：纯测试 harness 环境卫生面，六窗全不相交。

### r111 检视（Stage 3 行权轮——双刀实施清偿 + 零新 TD；触发器重定义一件）

- **零新 TD**：W-3.1 两刀（env-copy + TgtToken 零拷贝）均按裁决册实施清偿（上表两行 [Resolved at Stage 3.1]）——表示级变更零语义面（B4 第二十次逐位 1/1023 + 1381:0:2 全绿维持为最强实证）；B6d 调用份额轴新增（测量面非债务面）。
- **触发器重定义一件**：W-BOOT-FRONTEND 消费信号更新（r108 登记的「Stage 3 行权 → W-3.12 开窗」已消费——3.12-a 评估册裁决 = 维持；新触发器 T-a/T-b 二选一——w3.12-frontend-window.md §5 单源）。
- **开放项复核**：TD-007 @ P3 登记态维持（消费信号 = W-3.3 宏声明皮肤窗开窗——六窗拓扑序待排）+ 登记窗四件维持（W-DRIVER-HARNESS-SPLIT 观察态——harness 族 +30% 触发器未达；W-DIAG-OPCODE-CONTEXT / W-DIAG-FORM-NOTATION 零信号）+ W-BOOT-FRONTEND 触发器更新态。
### r112 检视（Stage 3 W-3.2 窗——B1 清偿轮；TD-026 riding 登记一件；零新 TD）

- **B1 偏差闭合**：FFI 源级 extern「实现 < 设计」偏差（deep-review-round2.8 §14.8 唯一遗留）→ W-3.2 全链落地（双皮肤声明形 + 类型面 + 产物面 + 引擎面 + C 后端 + e2e）——§14.8 回写义务闭合。
- **TD-026（FFI dangling）再裁定 → riding 登记**：标量批下 dangling 结构性不可能（R-F1 标量拷贝——零 kerf 堆引用跨界，C 侧无从持有悬垂指针）；**转为堆类型 extern 扩展面（str/pair/句柄协议）的门条件**——该面开窗时随 R-F3 显式句柄根协议一并重审。不闭账（Open · riding——stage0 §9.107 裁定 + w3.2-ffi-extern-window §1.6 单源）。
- **开放项复核**：TD-007 @ P3 登记态维持（消费信号 = W-3.3 宏声明皮肤窗开窗——拓扑序下一位）+ 登记窗维持（W-DRIVER-HARNESS-SPLIT 观察态未达 +30% 触发器；W-DIAG-OPCODE-CONTEXT / W-DIAG-FORM-NOTATION 零信号）；r112 触发器核对：W-3.2 语言面变更与六窗全不相交。
- **孪生缺口披露**（非 TD——账本钉扎）：.ktf 编译器/展开器孪生（BS-A 冻结种子链）不识 extern 形——composed 链 junction 2 披露行（extern_row=6）；孪生刷新 = W-3.12 段三裁定域邻接决策（gate_b_bytecode 既有调用源零 extern 零影响）。

### r114 检视（Stage 3 W-3.3 宏声明皮肤窗——TD-007 清偿轮；零新 TD）

- **TD-007 账面归零**（[Resolved at Stage 3.3]）：声明载体 `macro name { spec }` 落位（花括号 item 形——fn/module/extern 族同形制；spec datum 模式逐字承载——ruling F 升格）+ datum 面词汇扩展（运算符规范名表/`...`/裸 `-`）+ 转码器机械臂——9 语料案：8 案机械转正（双皮肤契约全绿）+ pos-031 转关键字经济词汇分歧钉扎（`else` 表达式位——声明修复揭示的既有边界，非宏面缺口；声明面单独验证可拼）。
- **零新 TD**：本窗零机制变更面新增债务——表示级扩展（目标皮肤 ReaderFace + 转码器）零内核触碰（CoreExpr/VM/compiler 零变更）；1415:0:3 全绿 + audit 240/240 + B4 面零触碰。
- **开放项复核**：登记窗维持（W-DRIVER-HARNESS-SPLIT 观察态未达 +30% 触发器；W-DIAG-OPCODE-CONTEXT / W-DIAG-FORM-NOTATION 零信号；TD-026 riding 维持）；r114 触发器核对：W-3.3 与六窗全不相交；孪生缺口披露维持（extern_row=6——本窗零新增）。

### r115 检视（Stage 3 W-3.6 元循环求值器退役评估窗——W-EVAL-RETIRE 登记窗一件；零新 TD）

- **W-EVAL-RETIRE 登记窗一件**（评估窗裁定产物——非缺陷登记，退役议程触发器登记）：裁定 = **维持**（消费面清单七桶 33 文件 + 可再生性三通道不对称论证 + 退役否决四论据——fixpoint 宪制承重 / K15 差分活跃消费 / EVL-1 共享面不减账 / 静默删除红线）。触发器二选一即可重开退役议程：**T-a 独立 oracle 等位**（C 后端 vs VM agreement 全语料 91 案系统化双跑 + 连续 3 轮零差分误报）/ **T-b 语义规格形式化**（subset-spec 期望面升格可执行形式规格）。静默删除禁令永续（退役实施三前置 = 独立 commit + 回滚预案 + 可再生性复核）。单源 = `docs/develop/v3/w3.6-eval-retirement-window.md` §5。
- **零新 TD**：评估轮零机制变更零生产语义变更——代码面新增仅 fail-closed 守卫测试（eval_inventory_guard_tests 三断言——清单完备性机检）+ 版本锁步三处；1418:0:3 全绿 + audit 240/240 维持 + B4 面零触碰。
- **开放项复核**：登记窗更新（W-DRIVER-HARNESS-SPLIT 观察态未达 +30% 触发器；W-DIAG-OPCODE-CONTEXT / W-DIAG-FORM-NOTATION 零信号；TD-026 riding 维持；**W-EVAL-RETIRE 新增**——触发器见上）；r115 触发器核对：W-3.6 与既有六窗全不相交（评估面零语言面/性能面变更）；孪生缺口披露维持（extern_row=6——本窗零新增）。
### r116 检视（Stage 3 W-3.10 包管理窗——登记窗两件；零新 TD）

- **登记窗两件**（W-3.10 窗口裁定产物——非缺陷登记，后续窗议程）：
  - **W-PKG-SELFHOST**（包管理器 .ktf 自举位——PKG-2 裁定登记）：触发器 = VM tier-1 档（W-3.7 实施后）+ 包管理器功能冻结（多源/注册表稳定）双前置；单源 = `docs/develop/v3/w3.10-package-window.md` §5。
  - **W-PKG-MULTISRC**（多源版本选择 + 显式 path 覆盖 + git/注册表——PKG-3 裁定登记）：触发器 = 多机协作 / 发布分发需求出现；K138 Go MVS 为采纳锚；同上单源。
- **零新 TD**：本窗零语义内核变更（kerf-pkg = 构建引导层零依赖 crate——CoreExpr/VM/18 内建表/双皮肤零触碰）；1467:0:3 全绿 + audit 250/250（AI10 新增节）+ B4 面零触碰。
- **开放项复核**：登记窗更新（W-DRIVER-HARNESS-SPLIT 观察态未达 +30% 触发器；W-DIAG-OPCODE-CONTEXT / W-DIAG-FORM-NOTATION 零信号；TD-026 riding 维持；W-EVAL-RETIRE 触发器 T-a/T-b 未达）；r116 触发器核对：W-3.10 工具链面与既有六窗全不相交；孪生缺口披露维持（extern_row=6——本窗零新增）。
### r117 检视（Stage 3 W-3.11 汇聚审计轮——里程碑审计 + E5 残留清偿；零新 TD）

- **零新 TD**：§14.5 深审族适配 D1-D8 八维度零 P0/P1/P2 发现；**P4×1 族（E5 叙述残留）当轮清偿非登记项**——parity 族四模块头注（描述 r104 拆除前的 .krf 孪生流）+ 断链/死名引用 ×7 + ktf_ 标识符方案 ~100 位点（r108 krf→ktf 先例延续；全 crate 内部零公共面扰动）——六文件 +239/−225，1467:0:3 清偿前后逐位（零行为变更实证）；保留面裁定：S-expr 皮肤现存事实（语料 .krf + cli 皮肤旗标测试）+ composed_full_chain 准确史实叙述 + worklog/历史开发记录零追溯改写。
- **登记窗触发器全量实测**（W-3.11 法定义务）：W-DRIVER-HARNESS-SPLIT harness 族 6,795→7,083 = **+4.2%**（阈值 +30% 未达——观察态维持）；W-EVAL-RETIRE T-a（C vs VM 全语料系统化双跑未执行）/ T-b（语义规格形式化未达）；W-PKG-SELFHOST 双前置（VM tier-1 = W-3.7 后 + 功能冻结）；W-PKG-MULTISRC（多机协作/发布分发需求未现）；W-DIAG-OPCODE-CONTEXT / W-DIAG-FORM-NOTATION（W-3.9 LSP 窗承载）；W-BOOT-FRONTEND T-a 450× ≫ 10× / **T-b 纯度面 = W-3.11 复核点裁定零新信号**（fixpoint 前端 = Rust 生产 reader 设计内形态——w3.11-convergence-audit-window.md §5.2）；TD-026 riding 维持。
- **开放项复核**：TD 开放项 **0** 维持（TD-007 已清偿 @ 3.3）；r117 触发器核对：审计轮零机制变更与七登记窗全不相交。
### r119 检视（Stage 3 W-3.4 分代 GC 评估窗——W-GEN-GC 登记窗一件；零新 TD）

- **W-GEN-GC 登记窗一件**（评估窗裁定产物——非缺陷登记，分代 GC 重评议程触发器登记）：裁定 = **维持单代 mark-sweep**（五发现证据链——F1 瞬态极性[churn 每 cycle marked=0，纪元加宽死亡率不变] / F2 递归帧 GC 窗口空[live_usage 计帧不可回收，帧下限与峰值间无整数预算窗口] / F3 平衡构建窗口空[iota 形帧↔cells 一比一互换 live_usage 恒平坦] / F4 无老代积累[全部画像点 live_after≡0] / F5 不可变堆纪律[25 操作码零堆 mutation + 生产零 get_mut——老→幼引用结构性不可能，若未来分代 remembered set 恒空 + 写屏障零插入点]）。触发器三选一即可重开分代议程：**T-a 堆压力**（画像 harness gc_lifetime_profile 出现跨 cycle 单调 live_after 增长——连续 ≥3 cycle 递增且终值 > 纪元 50%）/ **T-b 暂停敏感**（W-3.7 JIT 实施后 GC 停顿进入用户可感面）/ **T-c 语料规模**（单 run >10^5 cells 级长跑程序使 sweep 成本入 B 轴 25% 噪声带）。开窗义务 = D-CLASS-2 升格 + B4 双口径迁移独立 commit + 分域地址方案复核。单源 = `docs/develop/v3/w3.4-gc-window.md` §5。
- **零新 TD**：评估轮零生产机制变更（代码面新增 = 守卫族 8 件 gc_window_tests + 画像 example gc_lifetime_profile + Cargo example 注册——零 VM/collector/heap 触碰）；1475:0:3 全绿 + audit 250/250 维持（评估窗零增节——W-3.6 同形先例）+ B4 面在 D-CLASS-1 守卫三点位复验（第十三次逐位 + 等价类扩展）。
- **开放项复核**：登记窗更新（**W-GEN-GC 新增**——触发器见上；W-DRIVER-HARNESS-SPLIT 观察态；W-EVAL-RETIRE T-a/T-b 未达；W-PKG-SELFHOST/W-PKG-MULTISRC 前置未现；W-DIAG-OPCODE-CONTEXT / W-DIAG-FORM-NOTATION W-3.9 承载；W-BOOT-FRONTEND T-a/T-b 维持）；r119 触发器核对：W-3.4 评估面与既有七登记窗全不相交（GC 域评估零语言面/工具链面变更）。

### r120 检视（Stage 3 指令吸收轮——SOP v15.3 自举完备优先纪律；零新 TD；W-BOOT-FRONTEND 触发器状态更新）

- **SOP v15.3 落位**（用户常设指令①尾项 + 指令④吸收）：§21.12 第 28 条自举完备优先纪律（排期优先级裁定[自举阶梯最高优先] + 双链解耦[自举链验收不受生产链 ±25% 带约束；段升格判据 = 自举链完备不含生产位性能条件] + 完成标准法定[完全脱离宿主语言] + T-b 激活/T-a 降格）+ §1.2/§1.3/§13.1.2/§17.3 四接线点 + §16.1 v15.3 行——排期治理与验收口径条款零机制变更（原则 1 同族零载荷）。
- **W-BOOT-FRONTEND 触发器状态更新**（非新登记窗）：**T-b 纯度面激活**（用户常设指令①语言自我推进需求即纯度需求信号——SOP v15.3 §21.12-28④）+ T-a 降格为生产位切换条件；下一消费路径 = **W-3.12 段一实施窗**（升首要入口——stage-3-plan v1.9 排期重排）。
- **零新 TD**：纯文档轮零生产代码变更（SOP/stage0/plan 族触碰；1475:0:3 维持）；8 原语不变性第八十四轮验证维持。
- **开放项复核**：TD 开放项 0 维持；登记窗八件中仅 W-BOOT-FRONTEND 触发器状态更新（其余七件零信号维持——W-DRIVER-HARNESS-SPLIT 观察态 / W-EVAL-RETIRE T-a/T-b 未达 / W-PKG-SELFHOST/W-PKG-MULTISRC 前置未现 / W-DIAG-OPCODE-CONTEXT / W-DIAG-FORM-NOTATION W-3.9 承载 / W-GEN-GC 三触发器未达）；r120 触发器核对：指令吸收轮与八登记窗除 W-BOOT-FRONTEND（有意消费）外全不相交。

### r123 检视（Stage 3 W-CSYM-EXPR 能力裁定窗——W-CSYM-EXPR 实施清偿 + 段二 ELEVATED；零新 TD）

- **W-CSYM-EXPR 实施清偿**（[Resolved at Stage 3.12 · r123]）：三选一裁定 = **路径 b C 域谓词架构重归属**（§21.7 + §12 + K143-K145——w3.12-frontend-window.md §6c 单源）；实施 = 展开器两面退位（`reject_within_block_collisions` 收窄 + `ExpandError::ExternSymbolInvalid` 退役）+ `extern_table_floor` 单源双裁判（compile finish 全表警察 + verify Pass 0e——派生碰撞新覆盖）+ `CompileError` extern 族三分裂（名载荷）+ `compile-error` 期望种类 + neg-062 重分类 + 稳态 sweep 零披露 + AL 族 10 案（270→280）；段二升格 = **ELEVATED**（§6d 三判据全过）——「不完整的自举不是自举」经裁定实施后完整闭环（阻塞项解除非放行）。路径 a（冻结子集扩展）登记为宪法级提案选项（用户可见提案形态——未采）。
- **W-BOOT-FRONTEND 段三裁定窗闭合（r124）**：构建编排 = 宪法性排除（r90 裁定升格宪制条款）+ HM 判定面 = 补孪生确认（W-HM-TWIN 承载）+ junction-3 记录盲当轮清偿（emit 双引号族第二成员修复 + cp_extern_walk 消费臂 + parity 键 externs 段三面 + 组合链台账 3→1——pos-037/neg-058 收敛 Compile 行 56→58；neg-062 维持披露[派生字符 police 零字符操作不可表达——孪生通过 + verify 判官拒 hand-built 表]；w3.12 §6e 单源）；段三升格 = **NOT ELEVATED**（「不完整的自举不是自举」）；T-a 生产位切换条件维持（W-3.7 JIT 后 <10×）。

| W-HM-TWIN | HM 判定面孪生化实施窗（r124 段三裁定登记——w3.12 §6e 议题二）：kerf-typecheck 全 crate 5,352 行 Rust（check 1,255 + infer 2,918 + types 396 + env 183 + guards 308 + code 233）→ ~2,500-3,500 行 .ktf 孪生（typecheck.ktf + infer.ktf——r126 命名对齐 §6e 单源；register 旧名 check.ktf 废弃）+ 稳态/组合链 parity + 门 | [Open · P3 → **Resolved @ 3.12 · r131**（五刀全链交付——实际 4,924 行纯 kerf 超出预估上限，如实登记）] r124 段三裁定窗登记（三选一裁定 = 补孪生确认——四大自举语言先例全一致[K124 OCaml/q2 GHC/m1 rustc/q7 MLton] + BS-A 端态 §9.25.2 + 可表达性确认[HM 推断 = 纯树/表/符号操作——eq? 内容比较 + pair 代数 + 递归，无字符依赖]）；**r126 开启轮交付**（用户常设指令①自举演进规划）：r126-search 六检索件（q4/q5 强锚 + q1/q6 中强 + q2/q3 弱查噪音第十七轮如实披露）+ K146-K149 四新锚（Typing Haskell in Haskell 正典先例 / rustc_hir_typeck 主源 / cs3110 约束两相 / union-find 形态谱系——迭代 W + undo-log 维持既有形态）+ TWIN-1..5 形态裁定（selfhost/v1/infer.ktf + typecheck.ktf + INJ-1 通道复用 + SteadyTypecheckChain + parity 三面）+ 127-a..e 排期（MUV 边界切轮——1-2 完整轮次工程量，禁止降级交付）；承载 = typecheck.ktf 孪生族 + 稳态链形态（SteadyTypecheckChain——沿 SteadyReaderChain/SteadyExpanderChain 先例）；~~知识搜索义务：HM 推断器 .ktf 形态设计~~（**r126 已履行**——stage0.md §9.116 单源）；**r127 交付 127-a**（infer.ktf 3,641 行推断面位级收敛——sweep 5/5 + 套件 1511:0 + 13 缺陷清偿含 oracle resolve Arrow 参数交叉 P0）；**r128 交付 127-b**（typecheck.ktf 1,234 行检查面位级收敛——R1-R8+LA7 全规则族 + sweep 6/6 + 套件 1520:0 + INF-9 镜像守卫直接化[oracle `table_axes` 公共面]）；**r129 交付 127-c**（段三稳态链 parity 三面 + 跨路由等价——RS-4 双引擎 + 逐源路由 + oracle_analysis_dump_typed/dump `types` 臂/rebuild_typed_verdict + 组合分析面；套件 1526:0 + audit 290/290；纯 Rust harness 域轮[.ktf 孪生零触碰]）；**r130 交付 127-d**（runner AN 族四案[配对正负探针双面 + 语料 HM 轴 91 行重分类精确钉扎 + 预算行 E0011 逐源路由] + audit AN 族 10 案 290→300 live · 39 节 + TEST-3 三处同步 + eval-face C13/40）；**r131 交付 127-e**（段三升格重裁 = **ELEVATED**——§21.12-28② 三判据全过[①4,924 行纯 kerf 完整承载 ②稳态链 + 跨路由等价 + 精确钉扎自应用面 ③parity 门 300/300 全绿]；窗口闭合；W-BOOT-FRONTEND 账面全清偿——w-hm-twin-window.md v1.4 §5 单源） | ~~段三升格判据（HM 孪生完整交付——判据①②③沿 §21.12-28② 双链解耦）~~（**r131 已重裁 = ELEVATED**）→ 生产位切换 = T-a 独立后续窗（W-3.7 JIT 后 <10×——下一入口 W-3.7 JIT/超级指令窗） |
- **开放项复核**：TD 开放项 0 维持；登记窗九件（W-BOOT-FRONTEND 段二态更新如上；W-CSYM-EXPR 清偿归档；W-DRIVER-HARNESS-SPLIT 观察态维持；W-EVAL-RETIRE T-a/T-b 未达；W-PKG-SELFHOST/W-PKG-MULTISRC 前置未现；W-DIAG-OPCODE-CONTEXT / W-DIAG-FORM-NOTATION W-3.9 承载；W-GEN-GC 三触发器未达）；r123 触发器核对：重归属轮与登记窗除 W-BOOT-FRONTEND/W-CSYM-EXPR（有意消费）外全不相交。

### r122 检视（Stage 3 W-3.12 段二实施窗——W-CSYM-EXPR 登记窗一件；items 前缀 extern 编码潜伏缺陷当轮闭环；零新 TD）

- **W-CSYM-EXPR 登记窗一件**（段二升格阻塞项——能力裁定议程，非缺陷登记）：冻结子集（18 内建）零字符串/字符检查原语（穷举证实：算术/比较/car/cdr/cons/pair?/nil?/eq?/not/read-line/write-line）→ W-3.2 extern 警察的 C 符号派生两面（`c_symbol()` 标识符合法性 `[A-Za-z_][A-Za-z0-9_]*` 类集判定 + dash 替换碰撞等价判定）在 .ktf 孪生内**不可表达**——留在共享单谓词的 Rust 消费者（bytecode verify）；语料 neg-062 为唯一受影响行（孪生接受 vs oracle 拒绝——披露行，sweep + 组合链双钉扎）。解除路径三候选（§21.7 能力引入协议 + §12 最优>最小 + 知识搜索义务——Guile psyntax/Chez 字符原语自举形态）：（a）冻结子集能力扩展（新内建 = 18 内建冻结面变更——宪法级，用户可见提案）；（b）C 域谓词架构重归属（展开期早期警察退位、C 域消费者单源化——oracle 语义面变更需重推导）；（c）载荷结构化（记录文法携带派生前事实——层次违规已论证否决）。单源 = `docs/develop/v3/w3.12-frontend-window.md` §6b。
- **潜伏缺陷当轮闭环（§20 同类路径审查——非 TD 登记）**：`items_stream_prefix` extern 臂裸 `int,int` 文本在目标皮肤逗号分裂（往返守卫即触发）——自 W-3.2 潜伏（junction-3 编译孪生缺口掩盖 + gate-B 调用方零 extern 行——双通道零暴露）；r122 孪生刷新使 junction-3 可达后暴露 → 当轮修复（引号字符串形）+ 组合链 extern 台账行共变（6→3）。
- **开放项复核**：TD 开放项 0 维持；登记窗九件（**W-CSYM-EXPR 新增**——见上；W-BOOT-FRONTEND 段二态更新 = 机制完备 + NOT ELEVATED + W-CSYM-EXPR 阻塞；W-DRIVER-HARNESS-SPLIT 观察态维持[r122 完成 crate 内组织（bootstrap/ 目录统一），crate 拆分仍按 +30% 触发]；W-EVAL-RETIRE T-a/T-b 未达；W-PKG-SELFHOST/W-PKG-MULTISRC 前置未现；W-DIAG-OPCODE-CONTEXT / W-DIAG-FORM-NOTATION W-3.9 承载；W-GEN-GC 三触发器未达）；r122 触发器核对：段二实施窗与九登记窗除 W-BOOT-FRONTEND（有意消费）外全不相交。

### r131 检视（Stage 3 W-HM-TWIN 127-d/127-e 合并检视——窗口闭合 + 段三 ELEVATED + W-BOOT-FRONTEND 账面全清偿；零新 TD；承载 r130 域分界裁定的统一刷新）

- **W-HM-TWIN 实施清偿**（[Resolved @ Stage 3.12 · r131]）：五刀全链交付——127-a infer.ktf 3,641 行（r127）+ 127-b typecheck.ktf 1,234 行（r128）+ 127-c 稳态链 parity 三面 + 跨路由等价（r129）+ 127-d 测试面 + audit AN 族 300/300 · 39 节（r130）+ 127-e 段三升格重裁（r131）——实际孪生体 4,924 行纯 kerf（超出 TWIN-5 预估上限 ~2,500-3,500，如实登记）；段三升格重裁 = **ELEVATED**（§21.12-28② 三判据全过——w-hm-twin-window.md v1.4 §5 单源：①完整承载[sweep 双轴 5/5+6/6 逐位] ②自举链经该段自我编译[稳态链 + RS-4 双引擎 + 跨路由等价 + 91 行精确钉扎 + fail-closed 六探针 + 篡改族] ③parity 门全绿[audit 300/300 + 六命令 1530:0:4]）；生产位切换 = T-a 独立后续窗（W-3.7 JIT 后 <10×——下一入口 W-3.7 JIT/超级指令窗）。
- **W-BOOT-FRONTEND 账面全清偿**（[Resolved @ Stage 3.12 · r131]）：BS-A 端态五切口全部收敛——read ELEVATED（r121）+ expand ELEVATED（r123）+ HM 判定面 ELEVATED（r131）+ compile 孪生在位（r124——非独立段位，段三组合分析面承载 parity）+ 构建编排宪法性排除（r124）；「编译管道全段自举」口径闭合；余量 = T-a 生产位切换条件（性能门控非完备性门控——双链解耦裁定原文执行；非本窗 scope）。
- **零新 TD**：r130（纯测试/审计/守卫域）与 r131（纯文档域）两轮零生产机制变更——8 原语不变性第九十三/九十四轮验证维持；r131 六命令 1530:0:4 + audit 300/300 维持复验（版本钉扎 ds08 0.92.0 = 唯一行为增量）。
- **开放项复核**：TD 开放项 0 维持；登记窗十件中 W-BOOT-FRONTEND + W-HM-TWIN 双双清偿归档（r131），余八件零信号维持（W-DRIVER-HARNESS-SPLIT 观察态 / W-EVAL-RETIRE T-a/T-b 未达 / W-PKG-SELFHOST/W-PKG-MULTISRC 前置未现 / W-DIAG-OPCODE-CONTEXT / W-DIAG-FORM-NOTATION W-3.9 承载 / W-GEN-GC 三触发器未达）；r131 触发器核对：文档域闭合轮与八登记窗全不相交（升格裁决与文档族刷新零机制变更）。
- **r130 域分界裁定回执**：r130 轮内裁定 roadmap/stage-3-plan/register 行/stage0 §9.117 统一刷新归 127-e 承载——本轮（r131）已全部兑现（roadmap v2.61 / stage-3-plan v2.7 / 本档双行清偿 + 本检视段 / stage0 §9.117），零遗漏。

### r132 检视（Stage 3 W-3.7 JIT/超级指令评估窗——评估窗闭合 + 实施窗开启；登记窗一件新增 + 一件升格 + 一件否决 + 一件前置精确化；零新 TD）

- **W-VM-SUPERINSTR（EXC-10）实施窗（已清偿 @ 3.7 · r134 · v0.95.0——窗口 CLOSED）**：r68 登记态 → r132 开启（触发器强化形态满足——开销份额 72.5% + 均匀每指令成本 + 普适首对 24-29%）→ **r133 首刀 CallGlobal 融合全链落地**（SI-1..SI-6 形态裁定 + opcode 26 化 + VM/verify/C 后端/compile 四面 + compiler.ktf 孪生同步[gate B 逐位 + fixpoint 自复现] + 守卫再生成 + superinstr_window_tests 新族 8 件 + audit AO 族 10 案 310/310 · 40 节；r134 次刀 F1 直发算术全链落地[FA-1..FA-6 + 守卫再生成 + F1 族 8 件 + audit AP 族 320/320 · 41 节] + B 轴终账[fib-25 指令数逐位不变 + 三跑 61.544/61.815/61.963ms = 0.75×（两刀合计 -25.0%）——带缺口 4.1ms 诚实登记，第三杠杆 load-local+push-const（20%，预估 ~12ms）归 W-JIT-METHOD-T1 裁定输入] + 三触发器全命中 → 窗口关闭 + W-JIT-METHOD-T1 开窗；W-PKG-SELFHOST 前置「融合刀交付后」达成；窗口单源 = docs/develop/v3/w-vm-superinstr-window.md v1.2（CLOSED；裁定上游 = w3.7-jit-window.md §4.3）。
- **W-JIT-METHOD-T1 登记窗一件**（评估窗裁定产物——tier-1 第二刀议程）：三触发器任一即开窗：①融合落地后 B2 仍 > 1.8× C-O0 带或 ②复画像分派份额仍 > 40% 或 ③T-a 链路（自举链 <10× 目标）经融合后仍 > 25× 且无其他收敛路径；形态 = Sparkplug 1:1 非优化基线（K153）；元追踪族否决（K156——RPython 式宿主注解面与 Rust 基座不匹配）；单源 = w3.7-jit-window.md §4.3-2。
- **cranelift 基座内否决（本轮终结）**：重外部依赖与 pipeline 零外部依赖纪律冲突（§18）+ K113 代码质量低于 LLVM 且内存更高 + 链外原生位已由 C 后端覆盖（B9c 3.3× 工作中）——不入 VM 基座；链外实验位保留面经 W-3.8 承载。
- **W-PKG-SELFHOST 前置精确化**（非新登记）：触发器首项从「VM tier-1 档（W-3.7 实施后）」精确化为「W-VM-SUPERINSTR 融合刀交付后」（r132 裁定——方法 JIT 非包管理器自举必要前置；融合后 VM 性能档已足）。
- **零新 TD**：评估轮零生产语义变更——代码面新增 = 测量基础设施（VmObserver trait + run_observed const 泛型 seam + Opcode::ordinal——零语义效应，parity 守卫 + 三错误族 + D-CLASS-1 观察下逐位钉扎）+ 画像 example（Cargo 注册）+ 守卫族 8 件；1538:0:4 全绿 + audit 300/300 维持（评估窗零增节——r115/r119 先例）+ B4 第二十三次逐位；seam A/B 证据链五件归档（B2 +2.4% 布局残留按 K129 纪律接受 + 如实登记——B6a 归零证明无每指令成本）。
- **开放项复核**：TD 开放项 0 维持；登记窗更新（**W-VM-SUPERINSTR 升格实施窗 + W-JIT-METHOD-T1 新增**——见上；W-DRIVER-HARNESS-SPLIT 观察态[jit_window_tests +1 文件——续测]；W-EVAL-RETIRE T-a/T-b 未达；W-PKG-SELFHOST 前置精确化如上；W-PKG-MULTISRC 前置未现；W-DIAG-OPCODE-CONTEXT / W-DIAG-FORM-NOTATION W-3.9 承载；W-GEN-GC 三触发器未达[融合不动 GC 面]）；r132 触发器核对：评估面与登记窗除 W-VM-SUPERINSTR（有意升格）/W-JIT-METHOD-T1（有意新增）/W-PKG-SELFHOST（前置精确化）外全不相交。

#

## r137 检视（W-REC-DEPTH 刀 2——K162 可配置护栏 + r74/r85 括号全链退役；C3 终态宣告；r136 ds08 遗漏当轮清偿；零新 TD）

- **W-REC-DEPTH 刀 2 交付（实施中 → 窗口余项 = tier-1 基座已就位）**：四层帽（reader 256 / expander 512 / compiler 1024 / pkg 512）全部 `with_limit` 参数化 + 保守默认逐位维持（黄金零漂移）+ driver `DepthLimits` env 单源消费（KERF_READER_NESTING_LIMIT / KERF_EXPANSION_LIMIT / KERF_COMPILE_DEPTH_LIMIT 三键 + kp 的 KERF_PKG_RESOLVE_DEPTH_LIMIT 独立键——fail-closed 解析：非法值硬错误非静默回落）+ **r74/r85 VM-only 括号全链退役**（eval 堆激活栈化使「evaluator envelope is finite」前提失效——fixpoint step-3 双引擎化 + composed junction-1 双引擎化 + 语料 harness-limit 分类从 VM 括号重验改为硬失败回归守卫 + 六个括号面函数删除零 dead code 留守）；**C3 终态宣告**：深非尾递归内存约束治理 ✓ + 深尾递归恒定栈高 ✓ + fixpoint 无括号双引擎 ✓ + 读/析层护栏范围化 ✓（bootstrap-completion-plan §4.1 刀 2 行刷新——原则 58 四层谱系对账）。
- **r136 遗漏缺陷当轮清偿（§20 同类路径审查）**：ds08 工作区版本黄金钉扎停留 0.96.0（r136 金链锁步 v0.97.0 时遗漏——GATE 1 跑在锁步前的顺序窗口）；同类排查 = WORKSPACE_VERSION 字面量钉扎全树仅 ds08 一处（其余为 env!("CARGO_PKG_VERSION") 动态自适应）；本轮随 v0.98.0 锁步修正。
- **零新 TD**；TD 开放项 0 维持；登记窗触发器核对：r137 按 §3 序推进（自举段优先合法——§21.12-28①），W-TGT-READ-TWIN 刀 2（parser 孪生）排期 r138 单刀整轮（§4 MUV 边界——孪生体量单刀完整交付），tier-1 基座前置已全部就位（刀 1 + 刀 2 交付）。

## r136 检视（W-REC-DEPTH 刀 1 ∥ W-TGT-READ-TWIN 刀 1——双首刀交付轮）

- **W-REC-DEPTH 刀 1 交付（登记窗 → 实施中）**：eval 引擎堆激活栈化（§9.122.1）——EVAL_DEPTH_LIMIT 2048 帽解除为预算治理（C3 前半成立）；刀 2（reader 256/expander 512/compiler 1024 帽显式栈化或可配置护栏 K162 范围化 + 原则 58 谱系对账）为窗内余项；tier-1（TJ-3/TJ-4）的基座前置自此达成。
- **W-TGT-READ-TWIN 刀 1 交付（登记窗 → 实施中）**：target-lexer.ktf 第八 selfhost 孪生（§9.122.2）——G1 词法层闭合；刀 2（target Pratt parser 孪生）与刀 3（稳态读链 + 读段自应用 + 组成链扩展 = C1 断链全闭合）为窗内余项。
- **零新 TD**；TD 开放项 0 维持；登记窗触发器核对：r136 两窗按 §3 序推进（自举段优先合法——§21.12-28① 合规），其余登记窗零信号维持；W-JIT-METHOD-T1 窗内进度 = tier-0.5 已收（r135）+ tier-1 前置就绪（本轮基座）。
- **恢复轮台账（第十九次）**：本地 Pack B 恢复（零内容损失——git 历史对象库除外，worklog 权威承载）；恢复基线 016696f。
## r135 检视（Stage 3.7 W-JIT-METHOD-T1 开窗轮——自举完备总规划新建 + 登记窗两件新增 + PKG-SELFHOST 触发器反冻结改写；本轮零新 TD[规划域]）

- **W-JIT-METHOD-T1 实施窗（OPEN @ r134 三触发器全命中 → r135 开窗轮交付 §2 窗内第一议题裁定）**：tier-0.5/tier-1 分工裁定 TJ-1..TJ-5（w-jit-method-t1-window.md v1.0 单源）——TJ-1 首刀 = tier-0.5 收尾（LLC 复制对融合 20%——r134 第三杠杆在册数据消费）；TJ-2 余量对（含调用/控制流成分）归 tier-1 方法级吸收非逐对融合（K157 重定义 + K151 尾部对负收益警戒）；TJ-3 共享基座耦合 = tier-1 构建于 W-REC-DEPTH 堆激活栈之上（单一机制规划——重复施工警戒 + r134 fixpoint 爆深度实证）；TJ-4 tier-1 形态 = 去分派方法执行层（K153+K157——零 codegen、确定性构造保持）；TJ-5 T-a 组合面诚实预期（本窗不承诺 T-a 达标——组合面单源 = bootstrap-completion-plan.md）。
- **W-REC-DEPTH 登记窗一件（新登记 @ r135——用户常设指令「将解决 kerf 中任意递归深度纳入计划规划」+ G2 缺口）**：eval/VM 深度共账 EVAL_DEPTH_LIMIT 2048 帽 + 四层帽谱系（reader 256 / expander 512 / compiler 1024 / pkg-resolve 512——原则 58）→ 通解 = VM 自有堆激活栈（K160 归一：trampoline/显式栈/堆帧同源；Rust 无保证 TCO → 显式循环可移植）+ 读/析层护栏可配置（K162 范围化：业界常态保留 + 上限可配置）；触发器 = 已激活（用户显式指令 + r134 fixpoint 爆深度事故 + TJ-3 tier-1 架构依赖）；排期 = W-JIT-METHOD-T1 窗内 r136+ 前置刀（bootstrap-completion-plan §4.1 细粒度 MUV：刀 1 堆激活栈 + 深度帽解除为内存预算治理；刀 2 四层帽显式栈化/可配置护栏 + 原则 58 谱系对账）；单源 = bootstrap-completion-plan.md §4.1 + w-jit-method-t1-window.md TJ-3。
- **W-TGT-READ-TWIN 登记窗一件（新登记 @ r135——G1 结构缺口：目标皮肤读链孪生不存在）**：.ktf 文本→树仅 Rust `read_target_program`（生产桥 read 步——语言读不了自己的源 = 完全自举 C1 的结构性断链）；w3.12 §6 诚实边界曾登记为「段三裁定域的靶面之一」但 r124 三议题未含——r135 补登记开窗；实施域 = target lexer + Pratt parser 孪生（target-lexer.ktf + target-parser.ktf——RS-1 字节表注入通道沿袭 + 拒绝集/UnsupportedTargetForm 族 parity）+ 目标皮肤稳态读链 + 读段自应用（自源 .ktf 读取）+ 组成链扩展（C1 断链闭合）；排期 = 与 W-JIT-METHOD-T1 的 r136+ 阶段并行排期零交集（.ktf 编写面 vs VM 基座面——bootstrap-completion-plan §3 序 2）；单源 = bootstrap-completion-plan.md §4.2。
- **W-PKG-SELFHOST 触发器反冻结改写（用户「禁止冻结」指令 × r115 双前置设计的冲突裁定——bootstrap-completion-plan §7 单源）**：前置二从「功能冻结」改写为「manifest 子集实证稳定」（micro-TOML 六形 + semver 边界最近 N≥5 轮零变更 + pkg 语料回归全绿——可机检锚非政策性口号；§12 判据可审计优于政策性冻结）；前置一维持（融合刀交付——已达成 r134）；排期维持 K161 解耦（PM 自举后置于 T-a）。
- **自举完备总规划新建（bootstrap-completion-plan.md v1.0——用户常设指令①「完整完全自举优先」的规划单源）**：完成标准操作化 C1-C4 四判据（§21.12-28③ 法定标准工程化）+ 现状缺口地图 G1-G6 + 窗口序列五窗粗粒度排序（§21.12-28① 逐窗可审计理由）+ 前置窗细粒度 MUV（W-JIT-METHOD-T1 五刀 / W-TGT-READ-TWIN 三刀）+ T-a 切换窗五步（K159 种子→全量→自重建不动点操作化）+ 测量计划（T-a 链路稳态摊销口径 + K140 带诚实预期）+ 每轮复核义务（指令⑨载体）。
- **r135 知识层 K157-K162 六新锚**（stage0.md §9.121 单源；tool-results/r135-search/ 七件 + REPORT.md 存档——q2/q4 首查弱噪音重试落地如实披露）：K157 Sparkplug 重定义（去 IR 单遍 1:1——价值在分派消除非原生 codegen）/ K158 零 codegen 加速家族（closure chain + threaded code 菜单）/ K159 生产位切换 = 种子→全量→自重建不动点（不动点 = 验证门；链条定长工件显式——rustc Stage 2/3 先例）/ K160 任意递归深度 = 激活记录堆化归一 / K161 PM 自举与编译器自举解耦（opam 先例）/ K162 读/析层深度护栏业界常态（范围化裁定）。
- **开放项复核**：TD 开放项 0 维持；登记窗更新（**W-JIT-METHOD-T1 开窗轮裁定交付 + W-REC-DEPTH 新增 + W-TGT-READ-TWIN 新增**——见上；W-DRIVER-HARNESS-SPLIT 观察态；W-EVAL-RETIRE T-a 未达[T-b 已消费 r121]；W-PKG-SELFHOST 触发器改写如上 + 前置一已达成；W-PKG-MULTISRC 前置未现；W-DIAG-OPCODE-CONTEXT / W-DIAG-FORM-NOTATION W-3.9 承载；W-GEN-GC 三触发器未达）；r135 触发器核对：开窗规划轮与登记窗除 W-JIT-METHOD-T1（有意开窗裁定）/W-REC-DEPTH/W-TGT-READ-TWIN（有意新增）/W-PKG-SELFHOST（触发器改写）外全不相交。

## r139 检视（Stage 3.7 W-TGT-READ-TWIN 刀 3 收口轮——C1 链路闭合）

- **W-TGT-READ-TWIN 刀 3 交付（窗口关闭——G1 终态）**：SteadyTargetReaderChain + K20 桥 + composed_target_read_chain 五联差分 + fixpoint 纯度腿；C1 断链闭合（G1 行标记已闭合）。
- **TD-027（双子展开器 match 臂缺失）登记**：P2（非阻断——语料 91 无 match 程序按设计，C1 sweep 不受影响；组成链 J0.9 结构分类披露行持有）；门条件 = T-a 切换窗开窗前须清偿（生产位切换面向全语言面——T-a 步④ 分段切换的 read/expand 段生产位需覆盖 match 载荷程序）；实施位 = expander.ktf 新增 match 臂（expand.rs:243 expand_match 镜像：穷尽性检查 + 脱糖 walk）+ 展开器 parity 语料扩展（match 程序族）+ 组成链 J0.9 边界行退役。
- **外部记录空参 nil 编码（当轮清偿非登记）**：emit_item Extern 臂补 CP-1 词汇契约 Fn 臂同款规则——r122/r124 extern 渲染族三成员齐账（零消费者自 W-3.2 掩蔽至本轮组成链 sweep 暴露）。
- **零其它新 TD**；TD 开放项：TD-026（riding 维持）+ TD-027（新登记）；登记窗触发器核对：本窗（W-TGT-READ-TWIN）关闭 → 下一自举段入口 = W-JIT-METHOD-T1 tier-1（§3 序 1 在窗）∥ TD-027（T-a 前置门）。

## r140 检视（规划刷新轮——bootstrap-completion-plan v1.5 + 两新登记窗 + 转化台账新建）

- **W-SEXP-RETIRE 登记窗新增**（S-expr 脚手架拆除——G7）：前置 = T-a 切换窗 step ④ read 段生产位 + TD-027 清偿；排序 = §3 序 4（T-a 后首位——先于 W-EVAL-RETIRE 的技术理由 = 62+ 语料双皮肤→单皮肤迁移需要双引擎 parity 安全网在场）；拆除判据 R5 双臂已满足（target 读链全语料覆盖 + 类型注解语法/胖关键字额外能力 > 0）；细粒度 MUV 三刀 = bootstrap-completion-plan §4.4（语料迁移 / S-expr 读链退役 / 面清零扫描守卫化）。蓝图先行，触发器未达不开窗（T-a 未开）。
- **W-LANG-FOUNDATION 登记窗新增**（语言基础完备——G8）：前置 = 自举完备验收（C1-C4 + 单皮肤终态——§21.12-28① 从属位解除时点）+ TD-027 + TD-026 重审（堆类型 extern 扩展面开窗时随 R-F3——struct 表示跨 FFI 面）；排序 = §3 序 7（验收后首议程——用户指令⑤⑦）；细粒度 MUV 四刀 + 登记态后续 = bootstrap-completion-plan §4.5（类型注解消费面 / struct 脱糖 / enum 脱糖 + 穷尽性 / 模式匹配扩展 + 行多态评估窗）；enum/struct 时点裁定单源 = 同计划 §9（用户审查问题正面回答——时机未到非遗忘：设计登记 stage0 §9.14.2 R4 + 语法桥 parse_type_drop 生产在位 + 实现窗法定 C2 后）。蓝图先行，触发器未达不开窗（C1-C4 未验收）。
- **S-expr→目标语言完全转化统一记录文件新建**（docs/develop/v3/s-expr-conversion-record.md v1.0——用户指令⑫落位）：九件 14,243 行台账（逐件行数/Rust 镜像源/交付轮/终形刷新）+ 刀级谱系（r100 首波五件 → r121-r131 段族 → r136/r138 目标孪生 → r139 C1 闭合）+ 未转化面清点（G7 缺口账——拆除对象非待转化）+ 三处单源登记义务（台账 + 计划窗口行 + RELEASE_NOTES）。
- **冻结问题重审对账（用户指令③——r140 复审）**：r135 W-PKG-SELFHOST 反冻结改写维持（「功能冻结」→「manifest 子集实证稳定」——可机检判据）；本轮全树扫描冻结面 = subset-spec「Frozen」状态行（= 实现面诚实快照非政策性冻结——语义翻转经 MUV 合法行使先例 §2.1 三次行使）+ §3.2 内核冻结原则（= 设计宪法锚——与数据类型表面化正交，见计划 §9.4 层裁定）——**零「因冻结导致设计问题」的残留项**；登记窗触发器全树与 bootstrap-completion-plan §3 序一致（序 1-7）。
- **零新 TD**；TD 开放项维持：TD-026（riding——门条件 = 堆类型 extern 扩展面）+ TD-027（T-a 前置门）；下一入口核对：W-JIT-METHOD-T1 tier-1 刀 1（§3 序 1 在窗——TJ-3 基座就位）∥ TD-027（W-TGT-READ-TWIN 后续清偿）。

## r141 检视（Stage 3.7 W-JIT-METHOD-T1 tier-1 刀 1——方法编译基础设施；零新 TD）

- **零新 TD**：tier-1 刀 1 全链交付（MJ-1..MJ-4 四裁定 + methodjit.rs 新模块 + vm.rs 臂提取单源化 + loop-top 引擎选择 + 新族 8 + audit AW 族 10）；构建器三拒绝面 = fail-closed 纵深防御（verified 面上结构性不可达——防御性非缺陷性，测试直调触达）；B 轴对照与守卫族再生成 = 刀 2 排期（MUV 边界不降级——w-jit-method-t1-window §7 交付范围声明）。
- **开放项复核**：TD-026（riding 维持——门条件 = 堆类型 extern 扩展面，随 R-F3）；TD-027（T-a 前置门维持——门条件 = T-a 切换窗开窗前须清偿）；登记窗触发器核对：本窗（W-JIT-METHOD-T1）tier-1 刀 1 ✓ 在窗推进——下一入口 = tier-1 刀 2（tier 分派集成 + LLC 协作 + 守卫再生成 + audit AX + B 轴对照 + 三触发器复画像——窗口出口 §4）∥ TD-027；零新登记窗。
- **8 原语不变性第一百零三轮验证**：零新原语/零新内建/零语法增改/零操作码面变更（tier = VM 执行层运行期机制非编译期；VM 永久 Rust 基座宪制排除项维持——本刀为基座内优化非重写）。


## r142 检视（Stage 3.7 W-JIT-METHOD-T1 tier-1 刀 2——B 轴实测裁决 + 窗口出口；零新 TD + 一改判登记）

- **零新 TD**：刀 2 全链交付（MJ-5/MJ-6 双裁定 + 生产默认翻转 + 测量面双臂升级 + blade-2 测试族六件 + audit AX 族 10 案 390→400 · 49 节）；生产默认翻转的共变面全清（AW01/AW07 显式 opt-in 化 + wmj dual_path 默认臂改写 + TEST-3 共变）；禁用态计数恒 0 = 钉扎语义非回归（blade-2 负 1 + AX06/AX07 断言承载）。
- **LLC 杠杆归属改判登记（r142——非新 TD，在册事项的归属变更）**：r135 裁定「LLC -20% 指令数价值在 tier-1 内兑现」被刀 2 实测结构性证伪（tier-1 closure chain 净负 ~9%——兑现载体不存在）→ LLC 墙时面确认净负资产（r135 +3% 回退维持）；链内退役/维持**延后 T-a 切换窗开窗轮重审**（退役成本〔opcode 27→26 全链回退：verify/C 后端/compile 特判/compiler.ktf 孪生/快照黄金族〕vs 墙时 ~3% 的权衡在切换窗组合面内裁定——与 W-3.8 codegen 窗的交互面为重审输入）。
- **开放项复核**：TD-026（riding 维持——门条件 = 堆类型 extern 扩展面，随 R-F3）；TD-027（T-a 前置门维持——门条件 = T-a 切换窗开窗前须清偿；**T-a 前置现已凑齐**〔G1 ✓ + G2 ✓ + G3 裁决完成〕→ TD-027 = 下一入口的强制前置）；登记窗触发器核对：W-JIT-METHOD-T1 CLOSED（r142 §8 MJ-6 带缺口登记）→ 下一入口 = **T-a 切换窗开窗轮**（前置门 TD-027 + LLC 退役/维持重审）；零新登记窗。
- **8 原语不变性第一百零四轮验证**：零新原语/零新内建/零语法增改/零操作码面变更（tier = VM 执行层运行期机制；生产默认翻转 = 策略面非机制面；VM 永久 Rust 基座宪制排除项维持）。

## r143 检视（Stage 3.7 TD-027 清偿轮——双子展开器 match 臂 + T-a 开窗对账；一清偿 + 一重审裁定）

- **TD-027（双子展开器 match 臂缺失）清偿关闭**：P2 → 已清偿（r143 全链交付）——expander.ktf 新增 match 臂〔oracle expand.rs:243 expand_match 逐决策镜像：arity/臂形态 mchk walk/穷尽性（末臂 irrefutable）/scrutinee 单次求值入 `match(scrut` 载体/右折叠 marm（if test [let binds body] next）〕+ compile_pattern 六模式族镜像〔int/float 经 `=`、bool/string 经 `eq?`、nil 经 `nil?`、`_`、裸绑定、二元组 pair?+car/cdr（一元透传/三元+ = unsupported-pattern fail-closed）〕+ 两新错误 kind 重建〔expander_parity.rs "nonexhaustive"/"unsupported-pattern" + static_form "match"——FIX-16 同 commit 扩表纪律〕+ 组成链 J0.9 边界行退役〔composed_target_read_chain.rs——match 载荷程序走全公式〕+ audit AV7 共变（披露边界断言 → 全公式断言——r123 边界退役先例形制）+ 语料族 21 案〔pos-038..048 十一正 + neg-063..072 十负——错误顺序钉扎双案（穷尽性先于 pattern 编译；scrutinee 展开先于 pattern 编译）〕+ 五守卫共变〔HM 轴分类/infer sweep/check sweep/target sweep/composed ledger——91→112〕+ 转码器 match 臂〔skin_transcoder.rs emit_pattern + match_arm_is_shaped——.krf→.ktf 双皮肤契约〕+ audit AY 族 10 案（400→410 · 49→50 节——AY07 孪生 parity/AY08 组成链全公式/AY09 转码面/AY10 错误顺序双钉扎）。孪生 span/gen 逐位镜像（载体 Let=match form span、载体 Binding=scrutinee span、test apply=subject span、arm Let=body span——rebuild gen_span 逐位对账）。
- **LLC 链内退役/维持重审裁定（r143 ARCH-A——r142 改判登记的延后重审兑现）**：**LLC 维持在位**。裁定输入 = r142 三跑实测（tier-1 closure chain 净负 ~9%——证伪的是「兑现载体」非融合指令本身）+ r135 融合刀实测 +3% 墙时（LLC 机制自身的实测记录未被证伪）；机制区分 = LLC 是编译期静态字节码融合（零运行时分派开销），与被否决的运行时 tier 分派不同机制类；账面 = 生产默认纯解释形态下 LLC 是链内唯一实测正收益机制（融合覆盖 64.2% 分派份额的常量载荷面），退役成本 = opcode 27 全链回退（VM dispatch 27 臂 + verify 双边界 + .krf 往返 + C 后端复合 + compile args 环视特判 + compiler.ktf 孪生 + AQ 族守卫 + B 轴基线重测）——共变面远超 3% 墙时差；再重审时点 = W-3.8 真 codegen 窗开窗（届时融合产物有 codegen 消费面，融合价值判定回归 codegen 窗组合面）。
- **T-a 切换窗开窗对账（前置全凑齐确认）**：G1 ✓ + G2 ✓ + G3 裁决完成 + TD-027 ✓（本轮清偿）→ **T-a 前置全凑齐，开窗合法成立**；step ① 种子链固化落档（bootstrap-completion-plan v1.8 §4.3——宪制排除项清点 + 种子工件清点）；step ② A/B/C 工件管线 = r144 首刀；K140 带组合面重审结论 = ~10× 惨案带维持为 step ⑤ 验收带，达成路径诚实化（稳态链摊销口径 × A/B/C 实测 ×〔可选〕W-3.8 链外加速），开窗轮不预设达标时点（时间治理红线一：信号驱动非日历驱动）。
- **开放项复核**：TD-026（riding 维持——门条件 = 堆类型 extern 扩展面，W-LANG-FOUNDATION 开窗时随 R-F3 重审）；TD-027（**已清偿关闭**）；零新登记窗；下一入口 = **T-a 切换窗 step ② A/B/C 工件管线**（r144——step ① 已于 r143 落档）。
- **8 原语不变性第一百零五轮验证**：零新原语/零新内建/零语法增改/零操作码面变更（match 臂 = 冻结子集内 18 内建消费的纯脱糖镜像——`=`/`eq?`/`nil?`/`pair?`/`car`/`cdr` 全为既有内建；孪生 expander.ktf 增量 = 冻结子集 8 表内形式——if/let/pair/first/rest/eq/is_nil 纯组合，零子集面扩展）。

### r155 检视（W-PKG-SELFHOST 开窗轮——判据机检 + 承载裁定 + 四刀序；零新 TD；PKG-2 登记行状态更新）

- **PKG-2 登记行状态更新（r116 节 W-PKG-SELFHOST 行——历史原文保留，本节承载状态）**：触发器双前置兑现——①融合刀交付 ✓（r134）+ ②「功能冻结」经 r135 反冻结改写为「manifest 子集实证稳定」判据，r155 机检三面全绿超额满足〔git diff r147 基线 2097c93→r154 HEAD 全历史直接对照 = v0.108.0→v0.113.0 六版本 crates/kerf-pkg/ 内容级零 diff（N=7≥5）+ pkg_window_tests 8/8 + kerf-pkg lib 单元族 41/41 + audit AI 10 案（460/460 内含）〕；**开窗行权（ARCH-A @ r155）**：承载裁定 = 分刀 .ktf 承载（六论据：用户指令⑩完成标准精神〔kerf-pkg = 工具层非语言基座，无宪制排除地位〕/ 判据超额〔K161 opam 先例 = 许可非禁令〕/ C1-C4 ✓ + G7 ✓ / 表达力零缺口〔target-lexer.ktf L14 字节表入口先例——零新内建零新原语〕/ 接口爆炸面零时机〔driver 接线未点火〕/ G5 真闭合优于裁定闭合）；四刀序 = 刀 1 micro-toml.ktf 孪生 + K15 parity〔r156〕→ 刀 2 manifest/semver 孪生 → 刀 3 resolve/lockfile 孪生 + kp 接线三态回退带 → 刀 4 Rust 逻辑臂退役 + G5 闭合 + CLOSED；单源 = w-pkg-selfhost-window.md v1.0（bootstrap-completion-plan v1.18 §3 序 5 同步）。
- **零新 TD（纯勘定/规划轮——零代码变更零版本变更〔0.113.0 维持〕）**：本轮无新增技术债；判据机检 = 纯读 git 基线对照 + 既有测试面实跑；裁定与刀序 = 规划域交付。
- **8 原语不变性第一百一十五轮验证**：零新原语/零新内建/零语法增改/零操作码面变更（承载裁定预登记：micro-TOML .ktf 孪生路径 = target-lexer 字节表先例复用——纯冻结子集组合，零子集面扩展承诺入窗口档 §2.3）。
- **开放项复核**：TD-026（riding 维持——门条件 = 堆类型 extern 扩展面，W-LANG-FOUNDATION 开窗时随 R-F3 重审）；TD-028（已清偿 r154）；TD-029（P2 在册——VM Rust 递归栈余量刀刃级，GATE 分区 RUST_MIN_STACK=8MB 环境适应维持）；下一入口 = **W-PKG-SELFHOST 刀 1**（micro-toml.ktf 孪生 + K15 parity 驱动——w-pkg-selfhost-window v1.0 §4）。

### r156 检视（W-PKG-SELFHOST 刀 1——micro-toml.ktf 孪生 + K15 parity；四孪生缺陷当轮清偿 + 零新 TD）

- **刀 1 交付（micro-toml.ktf 603 行——第八件 selfhost 孪生）**：RS-1 字节表信道复用（target-lexer 先例）+ 16 错误 kind 全镜像（oracle micro_toml.rs 全部 format! 模板逐位复刻——超出窗口档原列四枚的规划粒度，oracle 实面为准 §8.4.5）+ 负域 i64 累加器（i64::MIN 幅值正域不可表示——target-lexer 负域先例）+ parity 三方 48 案例〔12 正 + 36 负 = 1:3〕全绿 + 跨阶段消费面（dump 重建 Document 形状——刀 2 manifest 投影前置）。RS-5 first_diff 三处重复债当轮收敛（vm_harness 单源，lexer harness 引用改接；parser harness 的 `)`-segment 私有形态保留——单行 dump 语义不同）。
- **四孪生缺陷当轮清偿（§20 同类路径全量审查）**：①行记录非正规点对 `(start . end)`〔r154 缺陷①同款——car(Int) 崩〕+ ②`("ok" doc)` 在 doc=nil 时塌缩点对〔car(nil) 崩——空文档案例〕+ ③seen 条目双重包裹〔car(nil) 崩——dup 检查路径〕+ ④ok 包装展平致 frame 拿到整数/entry 拿到 key 组〔car(Int) 崩 + entry 记录三元缺位〕——统一裁定 = **裸返回约定**（成功值不加 ok 包装，错误记录恒带 "err" 首槽可判）；⑤i64 累加 guard 漏无负号面〔d=8 时 acc*10+d 溢出〕→ 负域累加器根修；⑥mt_span_all_digits 终止语义颠倒〔走完全部应 true〕。全部经 parity 三方 48 案例闭环验证。
- **GATE 1 分区纪律 + 环境受阻披露（TD-029 容器降级类）**：分区 697/718 面实测全绿〔lib 804:0 + api 93:0 + doc 0 + kerf-pkg 41 + audit 460/460 + 124 retired 实跑 exit 0（release 14.16s）〕；21 面容器受限〔abc_pipeline 6 / target_lexer_twin 7 / target_parser_twin 6 / steady_route 1 / stack_flat 1——**基线 stash 复证在档**（r155 干净树同款超时）；check segment 423s 与 r154 基线 424.82s **持平**佐证非全容器降级——selfhost 双盘 parity 族（768MB 线程 + 逐源固定点驱动）显著降级〕。受阻清单与 TD-029 合并观测（触发器不变：8MB 贴边或任一 GATE 面连续两轮受阻）。
- **零新 TD**：本轮无新增技术债；镜像边界两件披露入窗口档 §6〔trim 域 ASCII 六字节 vs Rust Unicode 空白类（语料排除面——生态 kerf.toml 从未携带非 ASCII 空白打头行）/ 输入包络 O(N) 帧 + O(N²) mt_at（语料限 ~1KB/案，超限由 harness budget 面分类为诚实输入包络 K165）〕。
- **8 原语不变性第一百一十六轮验证**：零新原语/零新内建/零语法增改/零操作码面变更（刀 1 = 纯冻结子集组合：pair/first/rest/eq/is_nil/if/let/算术比较既有形式）。
- **开放项复核**：TD-026（riding 维持——门条件 = 堆类型 extern 扩展面，W-LANG-FOUNDATION 开窗时随 R-F3 重审）；TD-029（P2 在册——本轮扩面观测：selfhost 双盘 parity 族容器降级，基线复证在档）；下一入口 = **W-PKG-SELFHOST 刀 2**（manifest.ktf + semver.ktf 孪生 + parity 延伸——r157 排期，w-pkg-selfhost-window v1.1 §4）。

### r154 检视（W-SEXP-RETIRE 刀 3——词面层/台账层收口 + 窗口 CLOSED；TD-028 清偿关闭 + TD-029 登记）

- **TD-028 清偿关闭（TWIN-HYG-1——孪生展开器 (name, generation) 帧表示迁移，r154 随刀交付）**：expander.ktf 六推送位〔letloop cons 技巧/doloop "_" 帧项/fnbind 参数表〔ex_frame_of_names——每 fn 形共享形 gen〕/match 臂〔ex_binds_frame——每 pattern binder 自携 pgen〕/define-fn-sugar/define-var 顶层 cons 技巧〕统一正规两元条目 `(name, gen)`；解析链 ex_is_bound(name, ref_gen)——源引用 gen=0 全帧路径〔ex_frame_has 条目解包成员检查——与基线裸名走廓同深〕+ 引入引用 gen>0 ex_frame_gens 二趟仅解析引入绑定器〔binder gen>0〕；extern 合同名迁移 ex_externs 全局表〔oracle seed_extern_names 纪律镜像——两类引用恒可解析，ex_extern_collide 碰撞基线不受染〕；set!/plain-ident/mangled 三解析位全部携 ref gen。**audit J03 + macro_seed J03 等价案孪生臂回迁生产臂**（jerr/parse_target 全生产前端——目标读 + 孪生展开段）。**两手术缺陷当轮清偿**：①帧条目初版非正规对 `(name . gen)` 致 ex_2(entry)=first(rest(entry))=first(int) VM car 崩溃〔macro_seed 卫生双案红〕→ 正规两元表修复；②中版复用 ex_is_name_member 比较帧元素〔现为条目对〕——字符串 vs pair 恒 false 致 fn 参数全悬空〔pos-007 fn-sugar 拒〕→ ex_frame_has 条目解包检查修复。macro_seed 28/28 + determinism 7/7 + steady/stage_exit/format 22/22 + fixpoint 族复绿。
- **TD-029 登记（VM-STACK-MARGIN——VM Rust 递归栈余量刀刃级，P2）**：容器第二次重建后 bnd-006（255 深嵌套 if）经孪生展开段需 >2MB 测试线程栈〔真基线 bee86a7 全量 stash 复证同溢出——非 r154 回归；r153 容器内默认 2MB 恰好通过〕。表层缓解 = GATE 分区 RUST_MIN_STACK=8MB 环境适应措施〔r151-r153 分区纪律先例〕；结构性归属 = VM 树走解释器每 VM 帧的 Rust 栈成本〔~255 ex_expand 层 × 每层多 VM 帧〕——eval 引擎已堆激活栈化〔C3 r136〕，VM 引擎未堆化；W-REC-DEPTH C3 延续或专窗承载（触发器 = 任何 GATE 分区在 8MB 内再次贴边）。
- **词面层清零（~292 处/37 文件）**：四子代理并行〔154-a examples 115+12 / 154-b crates 66+3 / 154-c1 tests-v0 51 / 154-c2 tests-v1 37+中性化 4——SOP v15.4 §21.12-33 派遣纪律首次全流程适用：工作量预估裁切 + 简报自包含 + 断言双侧同步〕+ 主代理〔守卫双文件 6 处 + selfhost 三件 3 处 + README 4 处 + 陈旧表述修正（transcoder "both skins"/S-expr reader survives → r151 退役事实）〕；TEST-5 零扫描守卫〔.krf/skin_transcoder/StxToken/sexp_corpus_migration/ReaderFace::Sexp 五禁令 + 守卫自文件唯一白名单 + >500 文件扫描域下限〕。
- **窗口登记核对（W-SEXP-RETIRE CLOSED @ r154）**：三刀全交付〔r150 语料层 + r151 读链层 + r154 词面层/台账层〕；出口四条全 ✓〔①四层全拆 ②R5 双臂复证 ③六命令 + audit 460/460 + 台账三处单源 ④每刀过测试〕；台账升格「转化终态 + 拆除完成」七件 14,497→14,616 行〔expander.ktf +119〕。
- **8 原语不变性第一百一十四轮验证**：零新原语/零新内建/零语法增改/零操作码面变更（TD-028 = 冻结子集内纯组合迁移——pair/first/rest/eq/is_nil/if/let 既有形式；词面清零 = 纯词面；TEST-5 = 测试树守卫）。
- **开放项复核**：TD-026（riding 维持）；TD-029（新登记 P2——见上）；下一入口 = W-PKG-SELFHOST 观察窗 / W-EVAL-RETIRE 排期（bootstrap-completion-plan v1.17 §3）。

### r151 检视（W-SEXP-RETIRE 刀 2——S-expr 读链退役；一登记 + 三生产缺陷当轮清偿 + 中断轮编译态/运行态缺口双清偿）

- **TD-028 登记（TWIN-HYG-1——孪生展开器 plain-ident 查询代纪律缺口，P1）**：自举孪生展开器（expander.ktf `ex_expand` 的 plain-ident 解析臂 `ex_is_bound(ex_text(t))`）为**纯文本查询**——宏引入的非碰撞模板标识符（ex_inst 发射 gen=mgen+1 的普通 ident）按文本解析到**使用位帧项**（J03 面：`{ let tmp = 1; m() }` 中模板 `tmp` 绑到使用位 let——孪生受、oracle 拒〔Rust 展开器 ScopeSet 纪律：引入标识符空域集 → 仅全局可绑〕）。修复 = letloop（cons 技巧帧）/doloop（"_" 帧）/fnbind（参数表帧）/match 臂（ex_binds_pairs 待改）四推送位统一 **(name, generation) 帧表示迁移**——引入引用（gen>0）仅解析引入绑定器（binder gen>0）+ 全局；源引用（gen=0）维持全帧。r151 手术尝试已回退（letloop/doloop 帧项为裸名——单点改 plain-ident 臂破其余推送位）；独立刀窗承载（W-SEXP-RETIRE 刀 3 随刀项或专窗），audit J03 钉 **oracle 臂**承载（读目标面 + 展开走 Rust oracle——TD 落刀时孪生臂回迁）。
- **三生产缺陷当轮清偿（151-b2 只验编译未跑测试的缺口——恢复会话 audit/测试实跑暴露）**：①transcode_quoted_define 命名守卫（r151 重写误引合成零 span 入整对象等式——12 处链测试红；恢复为 HEAD 显示面比较 `.datum.to_string()` 跨度无关节）；②REPL 源累积 callee 丢失（call 锚 `(` 形——`set`/`write_line` 双皮肤拼写下 callee 恢复 + `;` 搭载）；③audit 仲裁四案（C02 EOF span 402 复算 + J03 oracle 臂 + AA10 布尔条件 `if (result)` 直用〔VM `=` 仅数值面〕+ AP04 参数表尾逗号 `(+,)`）。
- **中断轮编译态/运行态双缺口清偿**：141 错误位点 ~46 文件（tests 树 71→0 + audit 59 + bench 三件）+ in-crate 45 运行时失败（cli/repl/diagnostic/parity/pipeline 五面 172/172——151-b2「tests 面收编」仅编译层的尾巴）。
- **窗口登记核对（W-SEXP-RETIRE 在窗）**：刀 2 ✓ r151（读链层拆除——audit 减法共变 480→460 live + 124 retired〔总账 584 维持〕；台账改账九件 14,932→七件 14,497 行〔−812 孪生 +377 重排〕）；刀 3 = 下一刀（词面清零守卫化 + TD-028 孪生臂回迁 + 台账层收口——.krf 词面残余扫描〔伪文件名/双皮肤分支〕任何 S-expr 表面复活即红）。
- **8 原语不变性第一百一十三轮验证**：零新原语/零新内建/零语法增改/零操作码面变更（刀 2 = 纯拆除面：S-expr 读链/孪生/harness/转码器离树 + 消费面转面——vm_harness 改名为职责诚实非新面；RS-1 PrefixDatum = 既有封闭语法域解析器）。
- **测量面登记**：本刀无 K140 性能切片带（纯拆除面）；GATE 1 六命令 + audit 460/460 实跑承载验收。

### r150 检视（W-SEXP-RETIRE 刀 1——语料单皮肤迁移；audit 面内联清偿〔中断轮续完〕；零新 TD）

- **本轮清偿（非 TD 登记——中断轮缺口：audit 语料消费面未随 150-b 消费面切换共变）**：中断会话 150-b 切换了 14 测试文件但 audit 例程（examples/audit/stage0_gate_audit_r1.rs）的语料消费案未切——恢复会话 audit 实跑 V3 案红（`.krf` 目录扫 0 文件）暴露：①V03 全语料 sweep 切目标面（`.ktf` 过滤 + `run_parity_source_with(ReaderFace::Target)` + 地板 79→109）；②AF1/AF2/AF3/AF7/AF8 + AK08 + AL01/AL08 九案种子源内联化（`.krf` 语料原件已离树——案前提 = 源文本非文件本体，determinism-guard 内联先例；整族刀 2 随 S-expr 读链退役收编）；③V 段 unused import 清偿（run_parity_source → run_parity_source_with 全限定）。K163 连续适用：迁移 = 新输入域（目标面语料首入 audit sweep）→ 同类路径全量（rg 全树 audit .krf 语料读取九处一次清偿）。
- **窗口登记核对（W-SEXP-RETIRE 在窗）**：刀 1 ✓ r150（语料层拆除——109 .ktf 单皮肤 + 三案退役 + 逐案双皮肤等价预检三闸 + 消费面切换 + parse_directive 双前缀 + 机械臂 R4 归档 + audit BF 族 470→480 · 56→57 节）；刀 2 = 下一刀（S-expr 读链退役——随刀清理项：composed_target_read_chain J2 错误臂渲染形缺口〔neg-057——双编译器同消息拒绝、仅比较形漂移；w-sexp-retire-window v1.1 §3 刀 2 行在册〕+ AF/AK/AL 内联种子源整族收编 + i64::MIN 文本边界内联常量退役 + 转码器退役 + lexer/reader.ktf 孪生退役 + 台账改账）；刀 3 = 词面清零守卫化。
- **零新 TD**；TD 开放项：TD-026（riding 维持——门条件 = 堆类型 extern 扩展面开窗时随 R-F3 句柄协议重审〔W-LANG-FOUNDATION 前置〕）。
- **登记窗触发器核对**：W-SEXP-RETIRE 在窗（刀 1 ✓ r150——刀 2 下一入口）；W-EVAL-RETIRE 触发器 T-a 已达（退役排期——W-SEXP-RETIRE 后）；W-PKG-SELFHOST manifest 子集实证稳定判据观察中；W-LANG-FOUNDATION 前置 = 自举完备验收（§1 C1-C4 ✓ + 单皮肤终态——语料层已拆，读链/词面层在途）；8 原语不变性第一百一十二轮验证（语料迁移 = 验收载体换皮肤零新原语——9 CoreExpr / 操作码 27 维持 / .ktf 语料 = 既有目标语言面 / parse_directive 扩展 = 前缀接受面非新语义）。
- **测量面登记**：迁移等价证明落档（tool-results/r150-migration-report.txt——112 案种子契约复证 + 109 案目标契约预检 + 值/警告机械族三闸〔α-等价 + 单一语义字节码 + 单一值面〕；本刀无 K140 性能切片带——语料迁移非性能面，GATE 1 六命令 + audit 实跑承载验收）。

### r149 检视（T-a step ⑤ 工作流宣告 + 切换窗关闭；C1-C4 验收对账全绿；零新 TD）

- **本轮清偿（非 TD 登记）**：①守卫共变缺口（中断轮恢复发现——test_infra_guard TEST-3 未随 BE 族共变，r147 同类先例）：documented_audit_composition 补 BE 节 + 总数断言 460→470 + 头行字面量机检对齐 + 总账 564→574——四处共变修复后 7:0 绿；②测量纪律勘误：bench 语料无 `read_line` 而 CLI `run` 非终端 stdin 预读尽管道 → 无显式空带时管道等待 EOF 挂起（语言语义面正确行为；三跑命令形态 `< /dev/null` 落档——stage0 §9.135 架构层三）。
- **零新 TD**；TD 开放项：TD-026（riding 维持——门条件 = 堆类型 extern 扩展面开窗时随 R-F3 句柄协议重审〔W-LANG-FOUNDATION 前置〕）。
- **登记窗触发器核对**：**T-a 切换窗 CLOSED @ r149**（五步全链：① r143 → ②③ r144 → ④ r145-r148 → ⑤ r149——出口条件四条全 ✓；w-t-a-switch-window v1.5）；**W-SEXP-RETIRE 交棒就绪 → 开窗序位 = 下一窗**（bootstrap-completion-plan §3 序 4——read 段生产位 r145 + TD-027 r143 双臂满足）；W-EVAL-RETIRE 触发器 T-a 已达（退役排期）；W-PKG-SELFHOST manifest 子集实证稳定判据观察中；8 原语不变性第一百一十一轮验证（step ⑤ = 语料+测试+清点面零新原语——9 CoreExpr / 操作码 27 维持 / workflow 语料 = 既有语言面纯消费）。
- **测量面登记**：工作流全进程带三跑落档（tool-results/r149-workflow-run{1,2,3}.txt——selfcheck 163-170ms / bench 953-964ms @ v0.110.0；K140 端到端基线锚）。
- **转化台账**：零新转化面（workflow 语料 = .ktf 用户程序非孪生——台账维持九件 14,932 行；§4 未转化面清点表维持，W-SEXP-RETIRE 拆除对象不变）。

### r148 检视（T-a step ④ 第四段——compile 段生产位切换；K163 第五/六实例 + 孪生三潜在缺陷当轮清偿；零新 TD + 一诚实边界登记）

- **K163 第五实例（编译半面）**：双重建面（错误 make_span + 产品 rebuild_span）span file_id 恒 FileId(0)——r147 第四实例族编译段延续；错误面 `CompileError::with_span` 穷举 + 产品面 dbg span 双 retarget，真代际保留（非零 id 钉扎）。
- **K163 第六实例（items 流投递链）**：60k 平坦引号默认栈溢出实证（oracle 全 Rust 位同输入通过 = 对照基线）；四面右脊递归迭代化（emit_litval_literal/emit_litval/dump_ktf_litval/dump_oracle_lit）+ inject_items_stream 迭代析构 helper × 12 注入位（r146 forms 流 dispose 的 items 流补全）。
- **孪生三潜在缺陷**：cp_ewalk 错误臂 bool 契约（烘焙 1024 期隐性——co_limit 参数化暴露）+ extern 重复名全局索引（块内 vs 跨块 oracle 语义）+ verify 地板两法官显式化（§6e 盲面 → 程序级 CompileError）。全部当轮清偿零遗留。
- **诚实边界登记（非 TD——先存 oracle 域边界）**：AST 字面量 Box-drop 胶水 ~150k 元素生产主线程实测上界（双臂共享——堆化析构归 W-REC-DEPTH 后续窗非本窗债务；compile_segment_switch_tests 8MiB 生产预算线程钉扎）。
- 8 原语第一百一十轮验证：零新原语/零通道/零 VM/零语法（co_limit = 装配前缀 define 既有语言形）；TD-026 riding 维持。

### r147 检视（T-a step ④ 第三段——check 段生产位切换；K163 第四实例 + P0 性能回归双当轮清偿；零新 TD）

- **本轮清偿（非 TD 登记——两件当轮发现当轮修复）**：①**K163 第四实例（P1 生产缺陷）**：twin 重建树（forms + items）span 的 file_id 恒 `FileId(0)`（parity harness 惯例域）——r145/r146 切换 sweep 恰在零 id 域验证故树面从未重靶；本轮非零 file id 会话首入输入域即暴露（诊断 file 归属错档）。§20 同类路径全量：read 段 `retarget_forms`（StxDatum::List 递归 walk）+ expand 段 `retarget_items`/`retarget_expr`（ModuleItem/CoreExpr/Binding/HandlerClause 全变体穷尽 match——FIX-16）+ BC05/BC10 与 check_segment_switch_tests 非零 id 案例回归钉扎；②**P0 性能回归（当轮引入当轮清偿——A/B 基线对照实证）**：差分 harness 宿主（`drive_dual_engines`/`drive_full_face`）在 r147 默认位下对 46KB 级 assembled 链工件跑解释态检查（infer twin HM ≈ 49s/件）——corpus sweep 61 分钟（git worktree @ r146 基线 5 分钟，10× 回归）。清偿 = **harness 自检钉位裁定**（TA-7 单源）：harness 检查步钉 Rust——assembled 程序是链工件非用户程序，检查结论仅喂 harness「必须干净」断言（twin 位零验证增值而成本灾难）；read/expand 步保持生产位（r145/r146 先例免费输入域覆盖）。修复后全树超长测试全面回落（corpus 308s / hm_twin_face 54.6→3.3s / hm_twin_chain 317-369→13-19s / lexer twin curated 331→35s / parser rejection >600→105s）。
- **预算镜像审查（零改动裁定）**：推断深度预算双侧烘焙 512 且无环境面（Rust 常量 + infer.ktf 烘焙值）——回退带同键义务构造性成立；E0011 生产管线结构性不可达（展开帽 512 先拦——520 深左脊探针实证双位同拒于展开层），镜像义务空真成立（登记于测试族文档）。
- **零新 TD**；TD 开放项：TD-026（riding 维持——门条件 = 堆类型 extern 扩展面开窗时随 R-F3 句柄协议重审〔W-LANG-FOUNDATION 前置〕）。
- **登记窗触发器核对**：T-a 切换窗在窗（step ②③ ✓ @ r144 + step ④ read ✓ @ r145 + expand ✓ @ r146 + **check ✓ @ r147**——下一刀 compile 段〔SteadyCompilerChain r144 在位〕）；W-SEXP-RETIRE 前置已达成（read 段生产位——开窗序位 = T-a 窗关闭后首位）；W-EVAL-RETIRE 触发器 T-a 未达；W-PKG-SELFHOST manifest 子集实证稳定判据观察中；8 原语不变性第一百零九轮验证（check 段切换 = 位置变更零新原语——9 CoreExpr / 操作码 27 维持 / `TypeCode::from_registry_str` = 既有注册表逆映射非新码面 / 模板表 pub(crate) 化 = 可见性变更非新表）。
- **测量面登记**：check 段 K140 切片带三跑落档（tool-results/r147-check-segment-run{1,2,3}.txt——examples/bench/check_segment_profile.rs；curated 1.4-1.5× / check-twin-CCF 3.8× / infer-twin-CCF 23× / spine 三段 1.4-4.0×；回退带 KERF_CHECK_SEGMENT 在场）。
- **诊断 generation 诚实边界（登记非 TD——W-3.9 归属）**：oracle 位宏展开发现 span 携真 expansion generation，twin 位重建恒 ROOT（expand 段错误轴 `make_span` 先例）——五字段 parity 契约与一切现行渲染面均 generation-盲；孪生侧 generation 发射若 W-3.9 诊断增强窗需要宏上下文链则届时落位（w-t-a-switch-window v1.3 §2 TA-7 诚实边界段单源）。

### r146 检视（T-a step ④ 第二段——expand 段生产位切换；K163 同族全量预防位；零新 TD）

- **本轮清偿（非 TD 登记——K163 第三实例：生产位展开解码面默认栈暴露 + §20 同类路径全量的展开段预防位）**：①`rebuild_lit` 右脊递归（expander_parity.rs——装配主题〔determinism 守卫的 assembled-expander〕前缀表 = ~2 万记录右脊，生产位 twin 展开解码逐记录递归 → 默认栈溢出实证；1GB 栈复跑通过定位为深度型）——清偿 = 右脊迭代行走（`Value::from_literal` r145 先例形制：脊柱步 = 记录 cdr 载荷〔下一记录——真列表〕而非堆链〔降入记录内部〕；car 递归 = 读帽所界；点尾 = 末元素解码；非记录裸原子 = `value_elems` 大声失败）——determinism 守卫 = 回归钉扎（默认栈双遍历一致）；②`forms_stream_literal` 右脊 Box-drop 胶水（steady_expander_chain.rs——与 r145 读段宿主表同族；验证面 768MB 深栈掩蔽同形）——清偿 = `dispose_literal_iteratively` 升 `pub(crate)` 共享 × 全注入位迭代析构（expand / expand_dual / expand_production / abc_pipeline expand_via）+ BB10 默认栈回归钉扎（CCF 形式 60KB 全展开）。
- **零新 TD**；TD 开放项：TD-026（riding 维持——门条件 = 堆类型 extern 扩展面开窗时随 R-F3 句柄协议重审〔W-LANG-FOUNDATION 前置〕）。
- **登记窗触发器核对**：T-a 切换窗在窗（step ②③ ✓ @ r144 + step ④ read ✓ @ r145 + **step ④ expand ✓ @ r146**——下一刀 check 段）；W-SEXP-RETIRE 前置已达成（r145 read 段生产位——开窗序位 = T-a 窗关闭后首位）；W-EVAL-RETIRE 触发器 T-a 未达；W-PKG-SELFHOST manifest 子集实证稳定判据观察中；8 原语不变性第一百零八轮验证（expand 段切换 = 位置变更零新原语——9 CoreExpr / 操作码 27 维持 / `ex_limit` 预算镜像 = `tp_limit` 先例既有形制 / extern 槽声明 = r144 CCF 既有裁定）。
- **测量面登记**：expand 段 K140 切片带三跑落档（tool-results/r146-expand-segment-run{1,2,3}.txt——examples/bench/expand_segment_profile.rs；回退带 KERF_EXPAND_SEGMENT 在场）。
- **测试夹具勘误（146-a——中断轮恢复时的两处夹具设计缺陷修复，非生产缺陷）**：①跨段消费正例深主题 = CCF 形制 expander 孪生（`ccf_expander_source()`——extern `forms` 槽声明 + ex_limit 前缀 + 宏库 + 展开器体），裸装配体非自含（`forms` 槽引用 + `ex_is_name_member` 宏库依赖 → 双位同键拒绝 = 固定点族一致性面非正例主题）；②拒绝族 .ktf 皮肤四案定稿 = unbound / top-level / non-exhaustive match / malformed macro spec datum（中断稿的 `let = 1;` 与三元组模式 = 读层拒绝〔.ktf 语法层形状强制〕、`f( )` = 合法零参调用〔双位 Ok 非拒绝〕——读净载体的展开层形状拒绝只剩 macro spec datum 通道）。

### r145 检视（T-a step ④ 首段——read 段生产位切换；K163 三同族清偿；零新 TD）

- **本轮清偿（非 TD 登记——K163 第二实例：生产位新输入域默认栈消费暴露，sweep 盲区缺陷当轮修复）**：注入面三同族右脊/双脊递归——①`LiteralValue::pair_cells`（kerf-core/expr.rs：`1 + a.pair_cells() + b.pair_cells()` 双脊递归——~6 万单元对链 = 6 万帧）；②`Value::from_literal`（kerf-vm/value.rs：Pair 双臂递归物化——同族）；③宿主表 Box-drop 胶水（链式析构递归——右脊每单元一帧）。验证面以 768MB 深栈线程（steady 测试族 deep_stack 纪律）掩蔽 10+ 轮——生产位在默认 8MB 栈上即溢出（expander 孪生 60KB 源实证）。§20 同类路径全量清偿：pair_cells 显式栈迭代 + from_literal 右脊迭代（car 递归仅嵌套深度 = 读帽所界）+ `dispose_literal_iteratively`（steady_target_reader_chain.rs——生产读两张宿主表主显式析构）。BA10 栈平回归钉扎。
- **零新 TD**；TD 开放项：TD-026（riding 维持——门条件 = 堆类型 extern 扩展面开窗时随 R-F3 句柄协议重审〔W-LANG-FOUNDATION 前置〕）。
- **登记窗触发器核对**：T-a 切换窗在窗（step ②③ ✓ @ r144 + **step ④ read 段 ✓ @ r145**——下一刀 expand 段）；**W-SEXP-RETIRE 前置达成**（read 段生产位 ✓——拆除权已发生；开窗序位 = T-a 窗关闭后首位）；W-EVAL-RETIRE 触发器 T-a 未达；W-PKG-SELFHOST manifest 子集实证稳定判据观察中；8 原语不变性第一百零七轮验证（read 段切换 = 位置变更零新原语——9 CoreExpr / 操作码 27 维持 / K20 永久宿主桥既有裁定）。
- **测量面登记**：read 段 K140 切片带三跑落档（tool-results/r145-read-segment-run{1,2,3}.txt——链构造 ~30ms + 每读 240-990× + spine 240-460×；回退带 KERF_READ_SEGMENT 在场）。

### r144 检视（T-a 切换窗首刀——A/B/C 工件管线 + K159 不动点门；四缺陷清偿；零新 TD）

- **本轮清偿（非 TD 登记——sweep 盲区缺陷，CCF 新输入域暴露即当轮修复）**：①infer.ktf `ti_join` 以 `eq` 内建（Rc 指针身份）比较复合类型记录 → 复合分支 tif 恒 join dyn——清偿 = `ti_type_eq(mode, a, b)` 单分派器结构相等（oracle `Type: PartialEq` 镜像；`ti_occurs_walk` 先例形制）；②`ti_env_truncate` 以 `ti_take_n` 保留头推表**最新** mark 条目（丢弃最旧 k 条 = 前几参数）→ let 完成后外层绑定查表回退 dyn——清偿 = `ti_drop(env, len - mark)`（保留最旧——`Vec::truncate` 镜像）；③`ti_one_edge_row` 末尾 `ti_rev` 使 Tarjan 边表降序 → SCC 发射序反 → 预变量分配序互换（密集图 var 索引交换）——清偿 = 升序（oracle 构造序）；④`items_stream_literal` 尾随 generation 字符串编码 vs CP-1 文本 grammar INT → 编译孪生透传产品 dbg 记录被重建面 `as_i64` 拒——清偿 = 统一 INT（检查器孪生不透明透传零影响）。四缺口共性 = 语料输入域盲区（K163 新锚——stage0 §9.130）。
- **零新 TD**；TD 开放项：TD-026（riding 维持——门条件 = 堆类型 extern 扩展面开窗时随 R-F3 句柄协议重审〔W-LANG-FOUNDATION 前置〕）。
- **登记窗触发器核对**：T-a 切换窗在窗（step ②③ ✓ @ r144——下一刀 step ④ 分段切换）；W-SEXP-RETIRE 前置 = T-a step ④ read 段生产位（未达）；W-EVAL-RETIRE 触发器 T-a/T-b 未达；W-PKG-SELFHOST manifest 子集实证稳定判据观察中；8 原语不变性第一百零六轮验证（CCF extern 声明 = 表面语法零新原语——9 CoreExpr / 操作码 27 维持）。
## r157 检视（W-PKG-SELFHOST 刀 2——TD-030 新登记）

- **TD-030（P1 新登记——内联嵌套 cons 参数位坍缩）**：`cons(A, cons(B, nil))`（B 为 pair 构造）在**非尾位参数位**求值时内层坍缩为 B（`(A B)` → `(A . B)` 点对）；**let 中转构造同构树正确**。8 行最小复现（stage0 §9.140.1 BR-24 同源）：

  ```text
  fn bad(x) { pair("ok", pair(pair(11, pair(12, nil)), pair(first(rest(x)), nil))) }   // 坍缩
  fn good(x) { let k = ...; let q = ...; let dr = pair(k, pair(q, nil)); ... }         // 正确
  ```

  排查在案：AST 探针（parse_target 产物）结构正确 + cons 本体（builtin.rs）正确 + VM/eval 双引擎同错（共享求值层嫌疑——expander 加载后/typecheck/编译某共享面）；r136-r156 孪生族全绿的共存解释 = mt 族的 `pair(X, nil)`（X 形参）全在原子域（坍缩不可见于取字段面）。**处置**：manifest.ktf 以 let 中转形态绕道（本轮交付绿）；缺陷本体修复排期 = 刀 3 前置评估（W-CONS-COLLAPSE 窗登记——若不修复则刀 3/4 孪生同样需 let 中转纪律，tech-debt 维持 P1 在册直至根因清偿）。
- **TD-029（P2 维持——扩面观测）**：本轮 steady 全族 / fixpoint / purity / twin 大批 / segments 超窗（600s+）——TD-029 容器降级类第三次观测（r154/r156/r157）；RUST_MIN_STACK=8MB 环境适应维持（determinism/corpus 批无栈 8MB 直接 SIGABRT → 环境变量修复）；audit release 面秒级正常。
- **开放项复核**：TD-026（riding 维持）；TD-028（已清偿 r154）；TD-029（P2 在册——三轮扩面观测）；TD-030（P1 新登记——let 中转绕道在位，根因排期刀 3 前置）；下一入口 = **W-PKG-SELFHOST 刀 3**（resolve.ktf + lockfile.ktf 孪生 + kp 壳接线 KERF_PKG_SELFHOST 三态回退带——w-pkg-selfhost-window v1.2 §4）。

## r158 检视（W-PKG-SELFHOST 刀 3 前置——TD-030 根因评估闭合：误诊改判）

- **TD-030 → 关闭（误诊——缺陷不存在，r158-a 评估）**：登记的「内联嵌套 cons 参数位坍缩」实为 `cons(A, X)`（X 为 n 元素表）的**正确尾拼接语义**——结果是 (n+1) 元素表——被误读为缺陷。证据链（tool-results/r158/td030-assessment.md 单源 + 七探针双引擎实录）：①登记形态本体 `cons(A, cons(B, nil))`（B = pair 构造）probe3 c1 双引擎求值正确；②同树内联 vs let 中转**逐原子相等**（probe4 d1=d2 + e3/e4/e5——「内联坍缩 let 正确」不成立）；③probe4 18 行输出审计 0 错配；④probe5 21 探针证内联 pair 构造实参传递完整；⑤r157 复现件 `cons("ok", cons(P, Q))`（P 二表 Q 一表）= 正确 3 表 `("ok" (11 12) 8)`——期望 2 表需要**再包一层**（`cons("ok", cons(inner, nil))`），r157「good」版恰含该层（示意图 `...` 省略）→ 差异 = 树形非内联 vs let；⑥「双引擎同错」实为双引擎**同对**（一致正确被误读为共享缺陷）；⑦「r136-r156 孪生族全绿共存解释」的原子域不可见说辞 = 对不存在缺陷的合理化。**误诊根因**：复现件作者语义错误（缺包裹层）+ 确认偏误（差异归因于 let vs 内联而非树形）。**处置**：无代码变更；manifest.ktf let 中转形态维持（风格性，55 parity 全绿，§2.1.1 无因不动）；刀 3/4 孪生解除 let 中转纪律（自然构造合法）；W-CONS-COLLAPSE 窗解散；本检视节为 TD-030 终账（P1 → 0 缺陷改判——评估方法论沉淀：探针设计语义先过 cons/car/cdr 数学再定期望值）。
- **TD-029（P2 维持——第四次观测）**：r158 恢复轮 twin 大批 600s+ 超窗同签名（r154/r156/r157 后第四次；pkg 孪生族窄片 195.9s 窗内全绿 12/12）；RUST_MIN_STACK=8MB 环境适应维持。
- **开放项复核**：TD-026（riding 维持）；TD-028（已清偿 r154）；TD-029（P2 在册）；TD-030（**关闭——误诊改判 r158**）；下一入口 = **W-PKG-SELFHOST 刀 3**（resolve.ktf + lockfile.ktf 孪生 + kp 壳接线 KERF_PKG_SELFHOST 三态回退带——TD-030 前置已解除）。

## r159 检视（W-PKG-SELFHOST 刀 3 后半——resolve.ktf 孪生 + kp 壳三态接线；四缺陷族七位点当轮清偿 + 零新 TD）

- **刀 3b 交付（resolve.ktf 473 行——第十二件 selfhost 孪生 + 家族首个五件组合程序）**：三色 DFS（Gray 栈环路径 + 首解同名同一性）+ 后序拓扑 + 菱形全约束汇总（BTreeMap 名序键迭代）+ 深度护栏 K162 双生；单自递归 phase 判别驱动（oracle 单 `visit` 内联扫描同构投影）；parity 30 驱动全绿（正 9 + 负 20 + deep-chain-20）+ kp 壳 `KERF_PKG_SELFHOST` 三态回退带（e2e 双臂 + 红绿回退——孪生位坏→回退带接管→恢复——刀 4 出口条件前置在档）。
- **四缺陷族七位点当轮清偿（§20 同类路径全量审查）**：①**互递归拆分**（`rs_deps_walk` ↔ `rs_visit` 互调——顺序绑定子集内跨函数前向引用 = expand 期 unbound identifier〔装配偏移 90410 实证〕）→ 并入单自递归 phase 判别函数（phase 1 = visit / phase 2 = deps scan）；②**pkg_span 双解包两处**（rs_run + phase2——mf_project body 首位即 `(qs qe)` 裸 span 对，无需再剥）；③**mt_append 四处 1-list 误包裹**（edges 追加/环路径/gray 栈/后序 order——`mt_append(lst, item)` = 尾追加**裸元素**惯例〔micro-toml 自用法先例 `mt_append(doc, rec)`〕，误传 `pair(X, nil)` 即追加了 1-list 本身而非其元素）；④**dep-dir-not-found 误传已拼接 dep_dir**（记录携**父目录**、宿主自拼 `parent/libs/<name>`——oracle `Path::join` 序）。全部经 parity 30 驱动 + kp e2e 双臂闭环验证；探针插桩（zz_probe 测试 + resolve_parity_at span 窗口打印）当轮加当轮撤零残留（r157/r158 探针 offset 定位先例延续）。
- **TD-029（P2 维持——第五次观测）**：r159 恢复轮（容器第 5 次重建——`/home/z/kerf` 与 WIP 幸存、仅 rustup PATH 未挂载，零解包零重奠基）resolve_twin 全族 329s 窗内全绿；twin 大批 600s+ 超窗同签名沿 r158 披露口径；RUST_MIN_STACK=8MB 环境适应维持。
- **零新 TD**：本轮无新增技术债；镜像边界五件披露入窗口档 §6（mt_append 裸追加惯例 + dep-dir 父目录约定 + 互递归禁律 + render_mf_error 四参化 + 探针零残留）。
- **8 原语不变性第一百一十七轮验证**：零新原语/零新内建/零语法增改/零操作码面变更（刀 3b = 纯冻结子集组合：pair/first/rest/eq/is_nil/if/let/算术比较 + 自递归既有形式）。
- **开放项复核**：TD-026（riding 维持——门条件 = 堆类型 extern 扩展面，W-LANG-FOUNDATION 开窗时随 R-F3 重审）；TD-028（已清偿 r154）；TD-029（P2 在册）；TD-030（关闭——误诊改判 r158）；下一入口 = **W-PKG-SELFHOST 刀 4**（Rust 逻辑臂退役为构建引导回退带 + 窗口 CLOSED + G5 闭合入账 + 自举矩阵刷新——r160 排期；红绿回退已 r159 前置在档）。

## r160 检视（W-PKG-SELFHOST 刀 4——窗口 CLOSED + G5 闭合入账；中位违例缺陷当轮清偿 + 零新 TD）

- **刀 4 交付（Rust 逻辑臂退役 + 窗口 CLOSED @ r160）**：①全语料回归补全——kp_corpus_tests 7 测试（pkg_window 命名语料缺位五族〔传递链/锁文件往返/缺根清单/缺依赖目录/名不匹配〕+ 三环/冲突菱形两变体面；双臂 stdout/stderr/exit 逐位断言）；②kerf-pkg lib.rs 退役声明落档（Rust 五模块 = KERF_PKG_SELFHOST=rust 回退位 + parity oracle；IO 壳与深度护栏 = 宿主服务面宪制位）；③出口条件四条全 ✓（w-pkg-selfhost-window v2.0 §5）+ G5 闭合入账（completion-plan v1.22）+ 自举矩阵刷新（余 G6/G8）。
- **中位违例缺陷当轮清偿（P1 级——语料回归面的直接产出）**：`rs_check_imposed(dep, ver, imposed)` 递归携带 `rest(imposed)`，违例发生在 imposed 表中位时 `rs_err_conflict` 只收到尾段（丢满足前缀）——oracle 语义 = 整表抛出（PKG-3「every imposed constraint listed」）；r159 parity 30 驱动巧合全绿的根因 = conflict-diamond 夹具违例恰在首位（tail == whole——语料分布盲区）；修复 = 全表透传参 `all`（rs_verify 调用点 imposed 双传）+ parity 补钉 conflict-mid-list 案例（第 31 驱动）钉死边界；e2e 双面钉（kp_corpus conflict_diamond + parity 钉）。§20.3 同类路径全量：「递归走表抛错丢前缀」形态 .ktf 族唯一（cycle 栈位切片语义正确、not-found 族携带标量、mt/sv/mf/lk 错误携带记录位）。**方法论沉淀（BR-33 同族）**：parity 案例的违例位须覆盖首位与中位两形（§9.4.3 分布论证义务）。
- **TD-029（P2 维持——第六次观测）**：r160 resolve_twin 全族 246.2s 窗内全绿（6/6——含新 conflict-mid-list 驱动）；twin 大批 600s+ 超窗同签名沿 r158/r159 披露口径；RUST_MIN_STACK=8MB 环境适应维持。
- **PKG-2 终账（窗口级裁定闭合）**：r115 登记「kerf-pkg = Rust 构建引导层」→ r135 反冻结改写判据 → r155 开窗承载裁定（分刀 .ktf 承载）→ r156-r159 四刀交付 → r160 退役落档 + 窗口 CLOSED——包管理器逻辑面完全脱离宿主语言（用户指令⑩完成标准兑现的 PM 环节）。
- **零新 TD**：本轮无新增技术债；镜像边界四件披露入窗口档 §6 r160 行。
- **8 原语不变性第一百一十八轮验证**：零新原语/零新内建/零语法增改/零操作码面变更（刀 4 = 纯验证 + 文档轮 + 既有子集修复透传参）。
- **开放项复核**：TD-026（riding 维持——门条件 = 堆类型 extern 扩展面，W-LANG-FOUNDATION 开窗时随 R-F3 重审）；TD-028（已清偿 r154）；TD-029（P2 在册）；TD-030（关闭——误诊改判 r158）；**W-PKG-SELFHOST CLOSED——下一入口 = W-EVAL-RETIRE**（G6——eval 引擎退役；T-a ✓ r149 + T-b ✓ r121 触发器已满足；w3.6 档单源 + completion-plan v1.22 §3 序 6）。

## r161 检视（W-EVAL-RETIRE 开窗行权轮——触发器记账 + 退役形态裁定；纯治理 + 零新 TD）

- **W-EVAL-RETIRE 开窗行权**（G6——w3.6 登记窗 @ r115 的实施窗重开）：触发器记账三链落档（T-b 消费 r121〔tech-debt r135 簿记〕+ T-a 关闭 r149〔w-t-a-switch-window §7 行 7——生产纪元终结重解释〕+ 排期确认 r155/r160；**诚实披露**：原 T-a C 后端对拍系统化从未满足——C 后端维持 41 案链外面，重解释 = 生产位完成面非 oracle 等位面）。**退役形态裁定 = 退役为测试面**（ARCH-A @ r161）：CLI/REPL 用户面 loud-retirement（`--engine`/`--parity` 双旗教育性错误——`--skin` @ r151 先例形制）+ 验证面保留（eval.rs + parity 全臂 + fixpoint 双引擎门 + audit H + bench 双驱 = 验证面专用——种子表行 4「退役非删除」同型）；否决全移除四论据（K15 差分承重增长〔稳态链四段 + pkg 族五件传递 + HM 双面——比 r115 更承重〕/ 行 4 先例 / K134-K136 知识锚 / 原 T-a 等位从未满足）。刀 1 = r162 单轮全链（用户面退役 + 守卫重钉 B2→B1 = 38 + 窗口 CLOSED + G6 闭合入账）。实施窗单源 = w-eval-retire-window.md v1.0 OPEN（w3.6 评估档维持 CLOSED 历史态 + §6 重开指针）。
- **消费面重勘 + P1 切片纪律缺口当轮清偿**：重勘切片（首次纳入 eval_inventory 守卫）零未分类残留断言即红——`lockfile_parity.rs`（2 处 `"eval"`）与 `resolve_parity.rs`（1 处）自 r158/r159 创建起未入账：**守卫 r158-r160 三轮跌出切片过滤**（r151 缩桶修订后「守卫」一词在 worklog 切片记述中专指 selfhost_format 族——词义漂移致切片组合漂移，§20.6 根因）。处置：①分类入账 C 桶 +2（A3/B2/**C14**/D3/E17/F1/G1 = **41**——钉扎/注释/窗口档三单源共变）；②**常设纪律登记：凡触及 bootstrap parity 族的轮次，切片过滤必含 eval_inventory**（机制在场但未被执行 = 机制缺位——r160 语料分布盲区同族教训：fail-closed 设计的价值以实际运行为前提）；③w3.6 §4 计数行与守卫函数注释双陈旧顺带清偿（§8.4.5——C15/42 与 C13/40 两代陈旧）。传递消费者清单扩展：pkg 孪生族三件（mt/sv/mf——lockfile/resolve 升为直接面）+ 目标读链孪生两件（经 vm_harness drive_dual_engines 函数边界传递——扫描面完备性成立）。
- **零新 TD**：本轮纯治理（零代码行为变更——守卫注释同步 + 文档族；0.118.0 维持，r155 开窗轮先例）。
- **8 原语不变性第一百一十九轮验证**：零新原语/零新内建/零语法增改/零操作码面变更（开窗轮零机制变更）。
- **开放项复核**：TD-026（riding 维持——门条件 = 堆类型 extern 扩展面，W-LANG-FOUNDATION 开窗时随 R-F3 重审）；TD-028（已清偿 r154）；TD-029（P2 在册——第六次观测 @ r160）；TD-030（关闭——误诊改判 r158）；登记窗：W-PKG-SELFHOST CLOSED @ r160 / **W-EVAL-RETIRE OPEN @ r161（刀 1 = r162）**；下一入口 = **W-EVAL-RETIRE 刀 1**（CLI/REPL 用户面 loud-retirement + 守卫重钉 + 窗口 CLOSED + G6 闭合——w-eval-retire-window v1.0 §4 单源）。

## r162 检视（W-EVAL-RETIRE 刀 1——用户面退役 + 守卫重钉 + 窗口 CLOSED + G6 闭合；零新 TD）

- **W-EVAL-RETIRE 刀 1 全链交付（G6 闭合）**：CLI/REPL 用户面 loud-retirement（`--engine`/`--parity` 双旗教育性错误——`--skin` @ r151 先例形制；`Command::Run` 字段瘦身 + `Command::Repl` 单体化 + parity 执行路径退役 + usage 重写〔顺修 r151 遗留陈旧标头 "(sexpr | target skins)"——§8.4.5 滞留〕）+ repl.rs engine 字段退役（`with_options(input_tape)` 签名收缩——传递面瘦身）+ driver_seed e2e 共变 + api_tests 共变。**守卫重钉 B2→B1 = 40**：cli.rs 出账（**九符号零命中机检含测试面**——退役引擎名测试内以 `["ev", "al"].concat()` 拼接构造规避字面量命中，注释入档）；排除表共变（cli.rs 新入 + repl.rs 理由更新）。**验证面保留红线全守**：eval.rs（1,385 行）/ parity 双件 / C 桶 14 件 / D 桶 3 件 / audit H 节 / bench 双驱位 / pipeline.rs `Engine` 枚举与 Eval 臂零触碰（K15 差分承重不动——稳态链四段 + pkg 族五件传递 + HM 双面 + fixpoint 门）。
- **窗口 CLOSED + G6 闭合入账**：出口四条全 ✓（w-eval-retire-window v2.0 §5）；bootstrap-completion-plan v1.24（G6 行终态 + §3 序 6 出口 + 序 7 行权就绪）；自举矩阵终态 **G1-G7 全 ✓——余 G8 + 自举完备验收（G6 闭合后首议程）**；静默删除三前置兑现（独立 commit + 单提交 revert 回滚预案 + VCS 再生通道维持）。
- **勘正一件（§8.4.5 + §20.6）**：r161 检视条目「守卫重钉 B2→B1 = 38」为笔误——38 = 重钉后 A/B/C/D/E 五桶文件面计数（3+1+14+3+17，F/G 两桶为 examples 面），正确终态 = **40**（窗口档 §4 集成验证列「守卫 38 全绿」同源；终态口径 = 窗口档 §5.2 A3/B1/C14/D3/E17/F1/G1 = 40——守卫钉扎与 w3.6 §4 计数行共变）。
- **零新 TD**：用户面退役为机制级通解（loud-retirement 形制 = --skin 先例复用；九符号机检锚 = 守卫 fail-closed 形制延续）；零位点特化。
- **TD-029（P2 维持——第七次观测）**：本轮红线零触碰（C 桶 14 件 + eval.rs + parity 双件不动）；twin 大批 600s+ 超窗同签名沿 r158-r160 披露口径，非回归；RUST_MIN_STACK=8MB 环境适应维持。
- **8 原语不变性第一百二十轮验证**：零新原语/零新内建/零语法增改/零操作码面变更（用户面退役零机制变更——生产链与验证面零触碰）。
- **开放项复核**：TD-026（riding 维持——门条件 = 堆类型 extern 扩展面，W-LANG-FOUNDATION 开窗时随 R-F3 重审）；TD-028（已清偿 r154）；TD-029（P2 在册——第七次观测 @ r162）；TD-030（关闭——误诊改判 r158）；登记窗：W-PKG-SELFHOST CLOSED @ r160 / **W-EVAL-RETIRE CLOSED @ r162（G6 闭合）**；下一入口 = **自举完备验收**（C1-C4 复核 + 完成标准宣告——completion-plan v1.24 §3 终节点 + §1 四判据）→ W-LANG-FOUNDATION（G8 首议程）。

## r163 检视（自举完备验收轮——C1-C4 复核 + 深审 GO + 完成标准宣告；零新 TD）

- **验收轮全链交付（大阶段末轮 L3）**：C1-C4 复核实测全绿维持（K159 不动点门 8/8 release 45.04s B≡C 位级 + steady 族 6/7〔T4 steady_route_agrees 595s 超窗 = TD-029 r154 登记签名逐字吻合〕+ 段切换族 38 测试 + corpus sweep 112/112 + audit 460/460 live + 124 retired exit 0）+ 单皮肤终态核验（台账 17,154 逐位 + selfhost_format 12 件 + TEST-5）+ D1-D8 深审零阻塞（新档 deep-review-bootstrap-completion.md）+ §14.8 偏差清单（B4 roadmap §2 Stage 2a 历史表述注记 + B1 类型注解面入 G8 刀 1——B2/B3 零）+ §14.9 整理 C1-C6 全过（9 处 catch-all 注释补全——typecheck 92/92 + expander 95/95 复验零行为影响）+ §6.6 校准 Stage 3.7 收口行（29 轮零 P0 零紧急通道）+ §6.3 投票 5.5/5.5 → **GO：完成标准宣告达成——W-LANG-FOUNDATION（G8）从属位解除**。
- **零新 TD**：9 处注释补全 = §14.9 整理项（零行为变更——lib 复验逐位）；验收轮零机制变更。
- **TD-029（P2 维持——第八次观测）**：steady_route_agrees 超窗（595s）+ compile flat_regression debug 8MB 固定栈溢出（release 13.22s 绿）+ 后台进程容器收割（r154 登记行为复发）——三面均 r154 基线对照在档（「真基线同溢出」/「基线单点对照同超」），验收轮零生产代码变更非回归；RUST_MIN_STACK=8MB 环境适应维持（subset_corpus 112/112 显式口径下全绿）。
- **8 原语不变性第一百二十一轮验证**：零新原语/零新内建/零语法增改/零操作码面变更（验收轮 + 注释整理——机制面零触碰）。
- **开放项复核**：TD-026（riding 维持——**重审排期 = W-LANG-FOUNDATION 开窗轮**〔R-F3 句柄协议——堆类型 extern 扩展面，struct 表示跨 FFI 面——G8 刀 2 前置〕）；TD-028（已清偿 r154）；TD-029（P2 在册——第八次观测）；TD-030（关闭——误诊改判 r158）；登记窗：六窗全 CLOSED + **验收 GO @ r163（窗口序列终结）**；下一入口 = **W-LANG-FOUNDATION 开窗轮**（G8 首议程——§13.1 设计对齐 + TD-026 重审 + 窗口档新建；completion-plan v1.25 §4.5 单源）。

## r164 检视（W-LANG-FOUNDATION 开窗行权轮——设计对齐 + TD-026 重审 + 消费面重勘 + 刀序落档；零新 TD）

- **开窗行权全链交付（纯治理轮——r155/r161 同型先例）**：§13.1 设计对齐（窗口档 §2——设计锚七件〔stage0 §9.14.2/§7.4/§6.10/§9.14.5 + r76-search + K140-K142 + subset-spec §2.1〕+ 实况对账三面〔已实现四件/偏差 B1→刀 1/未实现登记态〕+ 灰区决策表 GZ-1..GZ-5 刀内裁定判据前置）+ 注解消费面重勘（Rust 面 4 位点〔fn 返回/fn 参数/let 绑定/fn-expr 返回〕+ 文法函数三件〔parse_type_drop/parse_type_parens/parse_generic_args_drop〕+ 孪生镜像双函数〔tp_give_type_drop/tp_step_type_drop——生产位 parity 双臂纪律〕+ typecheck 锚点 + 传递消费面）+ 窗口档 w-lang-foundation-window.md v1.0 新建（实施窗单源）+ 刀 1 排期 r165（类型注解消费面——completion-plan v1.26 §4.5 单源）。
- **TD-026（FFI dangling）开窗轮重审 @ r164（r163 排期兑现）**：**riding 维持 + 门条件精化 = 刀 2 开窗时点**——①刀 1（类型注解消费面）零 FFI 触碰（注解面 = 类型系统面非 extern 面——不触发门条件，刀 1 红线维持）；②刀 2（struct 表面 + 脱糖）= 门条件达成时点（struct 表示层裁定 GZ-2 直接决定堆类型 extern 表面）——**刀 2 开窗首议程 = R-F3 显式句柄根协议重审**（str/pair extern 扩展面一并）；③刀 3/4 维持零触发（enum tagged 构造子 = pair 家族表示随刀 2 裁定继承）。不闭账理由维持（r112 裁定 + w3.2-ffi-extern-window §1.6 单源——闭账时点 = R-F3 重审完成且堆类型 extern 面定形后）。单源 = w-lang-foundation-window v1.0 §4。
- **零新 TD**：开窗轮零代码行为变更（纯治理——0.120.0 版本维持）；灰区决策表 = 刀内裁定判据前置（GZ-1 注解表示层/刀 1、GZ-2 struct 表示层/刀 2、GZ-3 Type 构造子/刀 2-3、GZ-4 穷尽性检查面/刀 3、GZ-5 行多态评估判据/刀 4）——零机制变更义务。
- **8 原语不变性第一百二十二轮验证**：零新原语/零新内建/零语法增改/零操作码面变更（开窗轮零代码——注解文法已在位刀 1 只接语义〔8 原语约束下注解 = 表面糖〕）。
- **开放项复核**：TD-026（riding 维持——门条件精化 = 刀 2 开窗时点 R-F3 句柄协议〔本轮重审落档——w-lang-foundation-window v1.0 §4 单源〕）；TD-028（已清偿 r154）；TD-029（P2 在册）；TD-030（关闭——误诊改判 r158）；登记窗：**W-LANG-FOUNDATION OPEN @ r164（刀 1 = r165 类型注解消费面）**；下一入口 = **W-LANG-FOUNDATION 刀 1**（parse_type_drop → 注解验证锚——HM 推断 × 注解双向检查 + 孪生镜像 + types.rs Dyn 注释共变；completion-plan v1.26 §4.5 + w-lang-foundation-window v1.0 §5 单源）。

## r165 检视（W-LANG-FOUNDATION 刀 1——类型注解消费面全链交付；零新 TD）

- **刀 1 全链交付（四 MUV 单轮推进——b1+b2 前轮已交付，本轮 b3-twin/b4/b5）**：读链 spec 构造（b1+b2 @ 944569a——前轮）+ 展开器 dann 双臂（b3-oracle @ 83e3b96 前轮 + b3-twin @ 052d5e8——expander.ktf 八处 + compiler/typecheck arity 跳过臂 + ex_reserved 四行滞后清偿 + 语料 3 案 + 人口钉扎 13 文件 + 既有缺口四族〔AU01 树形/超宽四行/fmt 三文件/ex_reserved〕当轮清偿）+ 推断层双臂（b4 @ 262c128——E0013 第 14 位 + AnnotationTable + 解析表六函数〔保守退化 Dyn〕+ param 锚定静默/E0009 annotation_demanded 第三例外 + ret/let unify + infer.ktf mode-tagged 镜像 + t9 模板 + types.rs Dyn 注释共变）+ 语料族 16 案（b5 @ 7dd5028——正 4〔含退化实证〕负 12〔E0013 八 + E0009 四〕= 1:3 + 分类钉扎〔infer 18/check-clean 77/轴和 86〕）。
- **零新 TD**：全部缺陷（前向引用 ×2 族 + 键访问错位 + param E0009 释放缺口 + clippy 四 lint）当轮清偿零遗留；人口钉扎 13 文件全树共变（§20.3 同类全量）；调试探针清零终态核验（verdict diags 空）。
- **TD-026（riding 维持——刀 1 零 FFI 触碰实证）**：注解面 = 类型系统面（检查期语义）——零 extern 形态/零 extern_table_floor 触碰/零跨 FFI 类型流通（r164 裁定①的运行时实证）；门条件维持刀 2 开窗时点（R-F3 句柄协议首议程）。
- **TD-029（P2 维持——第十次观测）**：debug VM 口径超窗复发（target_parser twin 6/6 = release 335.03s——r158-r164 披露口径延续）；audit debug 598s ×2 超窗 → release 358s 全绿（互补口径）；工具链组件收割后重装（rustfmt/clippy——PATH 显式挂载维持）；本轮红线零触碰非回归。
- **8 原语不变性第一百二十三轮验证**：零新原语/零新内建/零语法增改/零操作码面变更（dann = 零码 item〔Require 先例〕；注解文法已在位刀 1 只接语义；spec 值树 = LiteralValue 既有数据宇宙；E0013 = 诊断码注册表面非内核面）。
- **开放项复核**：TD-026（riding 维持——刀 2 开窗首议程 R-F3 重审）；TD-028（已清偿 r154）；TD-029（P2 在册——第十次观测）；TD-030（关闭）；登记窗：**W-LANG-FOUNDATION OPEN（刀 1 交付 @ r165——GZ-1 兑现；刀 2 = 下一入口）**；下一入口 = **刀 2 struct 表面 + 脱糖**（GZ-2 表示层 + GZ-3 Type 构造子裁定 + TD-026/R-F3 首议程——completion-plan v1.27 §4.5 单源）。

## r166 检视（W-LANG-FOUNDATION 刀 2——struct 表面 + 脱糖全链交付；TD-026 闭账；零新 TD）

- **刀 2 全链交付（四 MUV——b1/b2/b3/b4 各自独立提交）**：读链双臂（b1 @ 740f93b——parse_struct_decl + tp 镜像机族 + 表达式位拒绝臂维持）+ 展开器双臂（b2 @ a312970——ModuleItem::Struct 零码 item + expand_struct 警察四族 + 脱糖发射序 pending_items 通道 + 十一消费面零码臂 + expander.ktf 镜像）+ 推断层双臂（b3 @ 03bf751——StructTable + Type::Struct 名义承载 + unify 透明展开五臂 + Display 名字单显示 + infer.ktf 孪生镜像 + r127 标量崩溃面同族清偿）+ 语料族 13 案（b4 @ f1dfaf4——正 3 负 10 = 1:3.3 + 人口钉扎九位共变 125→138）+ 三裁定落档（窗口档 §9：GZ-2 pair 链 / GZ-3 透明展开 / TD-026 闭账）。
- **TD-026 闭账（清偿关闭 @ r166）**：r164 门条件时点到达（刀 2 = struct 表面开窗）→ R-F3 显式句柄根协议重审完成（窗口档 §9.1 协议草图：句柄根表 + k_root_acquire/k_root_release API 对 + GC 根集集成）+ 堆类型 extern 面定形 = **W-HEAP-EXTERN 登记窗**（w3.2 §5 增补三件：触发器〔前端出现需要跨界堆值的真实用例——零信号不开窗〕+ 前置门〔R-F3 协议设计 = 开窗首议程〕+ 表示层输入〔struct = pair 链钉扎〕）；闭账 ≠ 遗忘——悬垂风险唯一复活位 = 该窗开窗时（登记窗承载非债务承载）；刀 2 零 FFI 面实证（struct 值 = 既有 KValue pair 族；extern 词汇表维持标量全集——跨界 = 运行期 R-F1 守卫既有拒绝面；C 后端零改动）。
- **零新 TD**：三真缺陷（孪生 car/cdr 臂缺透明展开 / 孪生 unify first(b)-on-scalar 崩溃面〔r127 出生债——pair/fn 臂同族全量清偿〕/ 探针皮肤拼写）+ 一 b2 遗留回归（exit_zero 裸装配面——attestation 镜像部署面修复）当轮全清偿零遗留；docs/worklog.md 镜像 128 行漂移债清偿（§8.6.1 纪律修复）。
- **TD-029（P2 维持——第十一次观测）**：fixpoint release 567.67s（b3 实测——孪生自应用最深面，r163 验收基线 45.04s 之上的结构性增长 = 增生 infer.ktf 4,364 行所致，非回归——刀 2 台账 +942 行的必然传导）；本轮红线零触碰非回归。
- **8 原语不变性第一百二十四轮验证**：零新原语（pair 链 = cons/car/cdr 既有——vector 宪制排除）/ 零新内建 / 零语法增改（KwStruct 既有 token；struct 关键字 = 宏展开表面非原语面）/ 零操作码变更（dstruct = 零码 item〔Annotate 先例〕）/ VM 零改动（struct 值 = 既有 KValue pair 族）/ C 后端零改动。
- **开放项复核**：TD-026（**闭账 @ r166**——W-HEAP-EXTERN 登记窗承载）；TD-028（已清偿 r154）；TD-029（P2 在册——第十一次观测）；TD-030（关闭）；登记窗：**W-LANG-FOUNDATION OPEN（刀 2 交付 @ r166——GZ-2/GZ-3 兑现 + TD-026 闭账；刀 3 = 下一入口）+ W-HEAP-EXTERN 新登记（TD-026 闭账承载位——零信号不开窗）**；下一入口 = **刀 3 enum 表面 + 脱糖 + 穷尽性**（GZ-4 刀内裁定 + 刀 2 表示裁定继承〔tagged 构造子 = cons(tag, payload)——tag 位留刀 3〕——completion-plan v1.28 §4.5 单源）。

### r167 检视（W-TEST-FLOW 交付轮——测试流程优化窗；队列重排序：用户显式指令插队于刀 3 之前）

- **窗口交付（横切基建窗单轮闭合）**：分层执行引擎（scripts/testing/test-tiers.sh ~570 行 + tiers.tsv 单源 63 行）+ 守卫三案（test_tier_guard_tests——表↔挂载双向 / 九慢族 T2 钉扎 / bash -n 表面契约）+ 双生档 + testing-guide 扩展（v0.122.0 过时基线清偿——差异 C 面）；知识搜索件 167-b-research（GHC/GCC/Go/rustc/LLVM/nextest 六项目对照）落档 my-project/worklog 5592-5605 + 窗口档 §3 锚表。
- **TD-029（P2 维持——第十二次观测 + 勘正注记）**：**r166-b3「fixpoint release 567.67s」归因勘正**——fixpoint_tests 恒为 9 案 ~5s（r164 恢复提交以来零变更，r167 引擎 --list + 单案实测双重证实）；「20/20 @ 567.67s」实为多族合并切片总时长错配到族名（fixpoint 9 + target_fixpoint 8 + …= 20 案批）。「结构性增长」的归因对象 = 切片总时长（含 target_parser_twin 389s 真实慢族）而非 fixpoint 族——r167 逐族台账（durations.tsv）即防再犯机制。本轮红线零触碰非回归。
- **零新 TD**：引擎九缺陷当轮清偿（tier 动态作用域踩碎 / 碰撞盾参数吞噬 / local 算术展开序 / 首行摘要 / 虚拟行 workspace 覆盖洞 / 整跑死循环险 / 切片超时误判红 / 虚拟行死锁 / TSV 制表符吞噬〔守卫立捕〕——窗口档 §4 清偿史）+ TSV 制表符吞噬守卫立捕实证；登记项四件（跨轮结果缓存 / 族级并行 / runner.rs 单体拆分 / counts 行多二进制限制）= 窗口档 §7 登记态非债务（零信号不开窗）。
- **8 原语不变性第一百二十五轮验证**：测试基建轮零编译器面改动——零新原语 / 零新内建 / 零语法增改 / 零操作码变更 / VM 零改动 / C 后端零改动（纯 scripts/ + tests/ 守卫 + 文档面）。
- **开放项复核**：TD-026（闭账 @ r166）；TD-028（已清偿 r154）；TD-029（P2 在册——第十二次观测 + 勘正）；TD-030（关闭）；登记窗：W-LANG-FOUNDATION OPEN（刀 2 交付 @ r166——**刀 3 = 下一入口恢复位**）+ W-HEAP-EXTERN（零信号不开窗）+ **W-TEST-FLOW DELIVERED @ r167**；下一入口 = **刀 3 enum 表面 + 脱糖 + 穷尽性**（GZ-4 刀内裁定 + 刀 2 表示裁定继承——completion-plan v1.28 §4.5 单源不变）。

### r168 检视（W-LANG-FOUNDATION 刀 3——enum 表面 + 脱糖 + GZ-4 穷尽性全链交付；零新 TD）

- **刀 3 全链交付（五 MUV——a/b1/b2/b3/b4 各自独立提交 + close）**：裁定落档（a @ 7145c18——窗口档 §10 五节：GZ-4 展开期单段执法 + 表示 cons(decl_index,payload-chain) + 模式首元素查表消歧 + Type::Enum 名义封闭）+ 读链双臂（b1 @ abf88a2——parse_enum_decl + tp 镜像机族 + ModuleItem::Enum 十一消费位零码臂）+ 展开器双臂（b2 @ 7ef4e32——expand_enum 警察七族 + 脱糖发射序 + 注入通道第三例 ex-enum-ctors + expander.ktf 孪生全套）+ 推断层 + GZ-4 双臂（b3 @ c0c35ea——Type::Enum + EnumTable + expand_match enum 感知 + compile_pattern variant 位 + DEFAULT_BUDGET 8→16MiB K159）+ 语料族（b4 @ 2c614c0——正 4 负 12 = 1:3 + 人口钉扎十位共变 138→154）。
- **零新 TD**：全程缺陷当轮清偿零遗留——b1 三真缺陷（payload unclosed 笔误 / 孪生 Eof 臂缺失死循环 / tp_err_unclosed 双参升级）+ 环境性栈溢出族四处 deep_stack（git stash 对照实证非本轮引入）+ b2 四真缺陷（空 enum 崩溃 / 前向引用第五例 / tag lit 裸值 / denum 幽灵元素）+ b3 收割遗留 1483 行零返工收编 + b4 恢复轮三处边界（末臂 tag-only 变体边界 / apply 记录 gen 尾槽 / parity 七警察臂）+ 向量排序一处；工具事故（Edit 全文件 tab→空格）tier 引擎立捕当轮清偿。
- **TD-029（P2 维持——第十三次观测）**：r168 全程经 r167 分层引擎分块前台——T0/T1/T2 三档零会话中断（引擎对抗收割实效全程实证）；TD-029 的 release 内存告警面零触发（fixpoint 分块窗内完成）。本轮红线零触碰非回归。
- **8 原语不变性第一百二十六轮验证**：零新原语（tag = Int 字面量既有 + payload = cons 右折既有——vector 宪制排除维持）/ 零新内建（ctor = define 单源生成非内建）/ 零语法增改（KwEnum 既有 token；enum 关键字 = 宏展开表面非原语面）/ 零操作码变更（denum = 零码 item〔dstruct 先例〕）/ VM 零改动（enum 值 = 既有 KValue pair 族 + DEFAULT_BUDGET 调参非机制）/ C 后端零改动（emit.rs 仅断言值 8→16MiB 共变）。
- **开放项复核**：TD-026（闭账 @ r166）；TD-028（已清偿 r154）；TD-029（P2 在册——第十三次观测）；TD-030（关闭）；登记窗：**W-LANG-FOUNDATION OPEN（刀 3 交付 @ r168——GZ-4 兑现；刀 4 = 下一入口）** + W-HEAP-EXTERN（零信号不开窗）+ W-TEST-FLOW（DELIVERED @ r167）；下一入口 = **刀 4 模式匹配扩展 + 行多态评估窗**（GZ-5 判据 + 时机触发器登记——评估非实施；completion-plan §4.5 单源）。

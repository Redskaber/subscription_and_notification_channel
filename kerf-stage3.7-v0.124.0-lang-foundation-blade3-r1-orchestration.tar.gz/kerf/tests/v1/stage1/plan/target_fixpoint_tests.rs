//! Target-skin fixpoint tests (Stage 2.7, switch-window step 4 —
//! switch-window-plan.md §1 step 4; stage0.md §9.30.4 SCF-A: "the
//! target-syntax Reader compiles itself").
//!
//! Mounted via `tests/runner.rs` (SOP §8.4.6 root-tree discipline).
//! The step-4 deliverable rides the production bridge
//! (`read_target_source_for_bootstrap` — the NEW reader feeding the
//! shared expand/load spine) at every read:
//!
//! * **The target fixpoint** — the `.ktf` compiler twin compiled
//!   by itself through the target skin, EXECUTED, reproduces its
//!   own compilation byte-for-byte (the §21.3 (2) caliber on the
//!   same-syntax chain — spans ride one source, so byte equality
//!   is the correct gate).
//! * **Gate B transitivity** — gate B holds on both skins and the
//!   r100 corpus twins proved one semantic bytecode per corpus,
//!   so the two skins' SELF-compilations must project to one
//!   `SemanticDigest` (§9.25.4's cross-skin layering — `debug_info`
//!   excluded, the ruling-H local renames absorbed as slots).
//! * **The bridge's front-end readiness** — all five `.ktf` twins
//!   read through the production bridge (the seed face's item-count
//!   cross-checks retired with the r104 E5 batch-3 teardown).
//!
//! The fail-closed family: the bridge rejects what the target
//! vocabulary cannot spell (seed-skin sources, step-2 registered
//! forms), the rich drives report the `.ktf` compiler's own
//! rejections (never a silent pass), and the digest detects every
//! semantic field's drift (a projection that cannot fail is not a
//! gate — the `dump_faithfulness_witness` lineage).

use kerf::compiler::{Bytecode, CaptureSource, Instr, Opcode, compile_program};
use kerf::core::{CoreExpr, LiteralValue, ModuleItem};
use kerf::driver::{
    COMPILER_TARGET_SOURCE, EXPANDER_TARGET_SOURCE, MACRO_TARGET_SOURCE,
    TARGET_LEXER_TARGET_SOURCE, TARGET_PARSER_TARGET_SOURCE, fixpoint_selfhost_compiler_target,
    ktf_compile_rich, read_target_source_for_bootstrap, semantic_projection,
};
use kerf::expander::expand_program;
use kerf::reader::read_target_program;
use kerf::span::{FileId, Symbol};

const FILE: FileId = FileId(0);

/// The self-applied assembly and the semantic-projection walks
/// recurse through the harness's Rust walkers (the sibling tests'
/// demand-allocated stack discipline).
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly");
}

// ---------- the positive faces ----------

#[test]
fn target_fixpoint_holds_the_twin_compiles_itself_twice_identically() {
    deep_stack(|| {
        let report = fixpoint_selfhost_compiler_target()
            .expect("the target-skin fixpoint runs to a verdict");
        assert!(
            report.fixpoint_holds,
            "the target fixpoint must hold: C_t(C_t(S')) == C_t(S')"
        );
        // The scale disclosure: the twin's own compilation and the
        // self-applied compilation agree on protos and insns (the
        // baked input rides the const pool, so the self-applied
        // consts strictly grow).
        assert!(report.self_protos > 0, "the twin compiles to real protos");
        assert_eq!(
            report.selfapplied_protos, report.self_protos,
            "the self-applied program carries the same proto population"
        );
        assert!(
            report.selfapplied_consts > report.self_consts,
            "the baked input datum rides the self-applied const pool"
        );
        assert!(report.self_insns > 0);
    });
}

// The cross-skin transitivity test (gate_b_transitivity_target, the
// r101 delivery) retired with the r104 E5 batch-3 teardown — the
// seed-skin compiler original left the tree; the transitivity chain's
// record rides the audit's historical sections (the AF-series
// findings). The target face's own gate B is the fixpoint's
// oracle-comparison phases, in-tree and live.

#[test]
fn production_bridge_reads_the_five_twins() {
    deep_stack(|| {
        // The front-end readiness face, in two layers:
        //
        // 1. the READER layer — five `.ktf` twins parse through the
        //    target reader bare (the injection contracts they
        //    carry — `source_bytes`, `tokens`, `forms`, `items` —
        //    are HOST globals, so the reader face alone is what a
        //    bare twin can prove). W-SEXP-RETIRE blade 2 (r151): the
        //    two S-expr read twins (lexer.ktf/reader.ktf) retired
        //    and their slots carry the TARGET read twins now — the
        //    same five-name family, single-skin;
        // 2. the SPINE layer — the structural compiler twin (the
        //    hosting tail stripped; `cp_run` takes `items` as a
        //    PARAMETER, so the bare twin is self-contained) walks
        //    the full bridge — new reader, shared expand + load.
        for (name, twin) in [
            ("target-lexer", TARGET_LEXER_TARGET_SOURCE),
            ("target-parser", TARGET_PARSER_TARGET_SOURCE),
            ("macro", MACRO_TARGET_SOURCE),
            ("expander", EXPANDER_TARGET_SOURCE),
            ("compiler", COMPILER_TARGET_SOURCE),
        ] {
            kerf::reader::read_target_program(FILE, twin).unwrap_or_else(|e| {
                panic!("the {name} twin must parse through the target reader: {e}")
            });
        }
        // The r148 `co_limit` parameterization: the structural twin
        // references the work-budget global with no assembly prefix
        // to define it — prepend the default-budget define (the
        // fixpoint's own structural form, the `ex_limit` precedent).
        let structural = format!(
            "define(co_limit, {});\n{}",
            kerf::compiler::COMPILE_DEPTH_LIMIT,
            COMPILER_TARGET_SOURCE.replace("\ndefine(result, cp_run(items));", "")
        );
        let items = read_target_source_for_bootstrap("structural.ktf", &structural)
            .unwrap_or_else(|e| panic!("the structural twin must walk the full bridge: {e}"));
        assert!(
            !items.is_empty(),
            "the structural twin expands to real items"
        );
        // The seed-face item-count cross-check (the r100
        // alpha-equivalence at the item granularity) retired with
        // the r104 E5 batch-3 teardown — the seed-skin original left
        // the tree; its record rides the audit's historical
        // sections and the twin's own items carry the face now.
    });
}

#[test]
fn target_rich_compile_matches_the_oracle_on_a_probe() {
    deep_stack(|| {
        // The dual-engine rich drive on a small probe: both engines
        // agree, and the rebuilt product equals the Rust oracle's
        // compilation of the same items (gate B at the probe scale
        // — the fixpoint's Phase-1 caliber, spot-checked).
        let probe = "fn fib(n) { if ((n < 2)) { n } else { (fib((n - 1)) + fib((n - 2))) } }\ndefine(r, fib(12));";
        let forms = read_target_program(FILE, probe).expect("the probe reads");
        let items = expand_program(&forms).expect("the probe expands");
        let run =
            ktf_compile_rich(&items, COMPILER_TARGET_SOURCE).expect("the target rich compile runs");
        assert_eq!(
            run.vm_text, run.eval_text,
            "the two engines must agree on the target compile"
        );
        let rebuilt = run
            .bytecode
            .expect("the .ktf compiler accepts the probe (the verdict text agrees)");
        let oracle = compile_program(&items).expect("the oracle compiles the probe");
        assert_eq!(
            semantic_projection(&rebuilt),
            semantic_projection(&oracle),
            "the rebuilt product must equal the oracle's compilation semantically"
        );
    });
}

// ---------- the cross-stage consumption face ----------

// The composed-chain consumption of the `.ktf` products (the
// step-4 obligation registered in plan §5.4.2) — the twin-vs-seed
// behavioral-parity probes — retired with the r104 E5 batch-3
// teardown: the seed-skin reader original left the tree, and the
// probes' coverage (the negative-input behavior family, both skins,
// one record face) is carried by the composed TARGET chain's
// junction-1 error axis and the corpus sweep's Read row (the
// `composed_target_chain_tests.rs` closeout; the seed face's record
// rides the audit's historical sections).

// ---------- the fail-closed family ----------

#[test]
fn bridge_rejects_seed_skin_sources() {
    // The S-expression skin is not the target vocabulary: a seed
    // form at the top level of a `.ktf` read must be rejected
    // (fail-closed — never a silent alternate parse).
    for source in ["(define x 1)", "(+ 1 2)"] {
        let verdict = read_target_source_for_bootstrap("seed-skin.ktf", source);
        assert!(
            verdict.is_err(),
            "source `{source}`: the bridge must reject the seed skin"
        );
    }
}

#[test]
fn bridge_rejects_step2_registered_forms() {
    // The step-2 E5-exemption family stays fail-closed on the
    // bridge face: generics, where clauses, casts — the registered
    // non-mapping faces (plan §5.1 B/C1-C5). The blade 2 struct and
    // blade 3 enum declarations LEFT this family (GZ-2/GZ-4 — they
    // parse now; the remaining type-declaration family rides type/
    // effect/capability).
    for source in [
        "fn f<T>(x: T) -> T { x }",
        "fn f(x) -> i64 where T: Eq { x }",
        "let y = x as i64;",
    ] {
        let verdict = read_target_source_for_bootstrap("registered.ktf", source);
        assert!(
            verdict.is_err(),
            "source `{source}`: the registered form must stay fail-closed"
        );
    }
}

#[test]
fn target_rich_compile_reports_the_compiler_rejections() {
    deep_stack(|| {
        // The LA-7 boundary (an assign to a captured name — the
        // neg-057 corpus shape) rides
        // the item stream and drives the `.ktf` compiler's own
        // rejection: the rich drive returns the Error verdict with
        // NO rebuilt product (a rejection reported, never a silent
        // pass), and the verdict text equals the oracle's own
        // compile-error key on the identical items (the error-axis
        // parity carried through the production bridge — the seed
        // twin's cross-check retired with the r104 teardown, the
        // oracle's key is the same single source the composed
        // target chain's junction 3 compares against).
        let probe = "fn outer(a) { ||(b) { set(a, (a + b)) } }";
        let forms = read_target_program(FILE, probe).expect("the probe reads");
        let items = expand_program(&forms).expect("the probe expands");

        let run_t = ktf_compile_rich(&items, COMPILER_TARGET_SOURCE)
            .expect("the target rich drive runs to a verdict");
        assert!(
            run_t.vm_text == run_t.eval_text,
            "the engines must agree on the LA-7 probe: vm `{}` vs eval `{}`",
            run_t.vm_text,
            run_t.eval_text
        );
        let text_t = run_t.vm_text.clone();
        assert!(
            run_t.bytecode.is_none(),
            "the .ktf compiler must reject the LA-7 probe: {text_t}"
        );

        // The oracle's own rejection key on the IDENTICAL items.
        let oracle_err = compile_program(&items).expect_err("the oracle rejects the probe");
        let oracle_key = kerf::driver::cp_error_key(&oracle_err);
        assert_eq!(
            text_t, oracle_key,
            "the rejection record must match the oracle's compile-error key"
        );
    });
}

#[test]
fn semantic_digest_detects_every_semantic_field_drift() {
    // The digest's own fail-closed witness (the
    // `dump_faithfulness_witness` lineage): mutating ANY semantic
    // field the digest carries must surface as a digest drift —
    // a projection that cannot fail is not a gate.
    let probe = "fn f(x) { (x + 1) }\ndefine(r, f(2));";
    let forms = read_target_program(FILE, probe).expect("the probe reads");
    let items = expand_program(&forms).expect("the probe expands");
    let bc = compile_program(&items).expect("the probe compiles");
    let baseline = semantic_projection(&bc);

    // funcs[0].name.
    let mut mutated = bc.clone();
    if let Some(first) = mutated.funcs.first_mut() {
        first.name = Some(Symbol::new("witness").expect("a valid witness name"));
    }
    assert_ne!(
        semantic_projection(&mutated),
        baseline,
        "a proto-name mutation must surface in the digest"
    );

    // funcs[0].params.
    let mut mutated = bc.clone();
    if let Some(first) = mutated.funcs.first_mut() {
        first.params = first.params.wrapping_add(1);
    }
    assert_ne!(
        semantic_projection(&mutated),
        baseline,
        "a params mutation must surface in the digest"
    );

    // funcs[0].captures.
    let mut mutated = bc.clone();
    if let Some(first) = mutated.funcs.first_mut() {
        if first.captures.is_empty() {
            first.captures.push(CaptureSource::Local(0));
        } else {
            first.captures.clear();
        }
    }
    assert_ne!(
        semantic_projection(&mutated),
        baseline,
        "a captures mutation must surface in the digest"
    );

    // funcs[0].code.
    let mut mutated = bc.clone();
    if let Some(first) = mutated.funcs.first_mut() {
        first.code.push(Instr::new(Opcode::Ret));
    }
    assert_ne!(
        semantic_projection(&mutated),
        baseline,
        "an instruction mutation must surface in the digest"
    );

    // consts.
    let mut mutated = bc.clone();
    if !mutated.consts.is_empty() {
        mutated.consts.clear();
    } else {
        mutated.consts.push(LiteralValue::Int(7));
    }
    assert_ne!(
        semantic_projection(&mutated),
        baseline,
        "a const-pool mutation must surface in the digest"
    );

    // globals.
    let mut mutated = bc.clone();
    if !mutated.globals.is_empty() {
        mutated.globals.clear();
    } else {
        mutated
            .globals
            .push(Symbol::new("witness").expect("a valid witness name"));
    }
    assert_ne!(
        semantic_projection(&mutated),
        baseline,
        "a globals mutation must surface in the digest"
    );
}

#[test]
fn semantic_digest_ignores_debug_info_by_design() {
    // The §9.25.4 cross-skin caliber: `debug_info` sits OUTSIDE
    // the digest — the two source texts of one program differ in
    // spans by construction, so the digest must not see them (the
    // positive twin of the drift witness above).
    let probe = "fn f(x) { (x + 1) }\ndefine(r, f(2));";
    let forms = read_target_program(FILE, probe).expect("the probe reads");
    let items = expand_program(&forms).expect("the probe expands");
    let bc = compile_program(&items).expect("the probe compiles");
    let baseline = semantic_projection(&bc);

    let mut mutated = bc.clone();
    for func in &mut mutated.funcs {
        func.debug_info.clear();
    }
    assert_eq!(
        semantic_projection(&mutated),
        baseline,
        "clearing debug_info must not move the digest (the cross-skin caliber)"
    );
    // Byte equality still sees it — the two calibers are distinct
    // by design, and this test pins which face carries which.
    assert_ne!(
        mutated, bc,
        "byte equality must still see the debug_info change (the same-skin caliber)"
    );
}

// ---------- the module-level type guards (compile-time faces) ----------

/// The digest's shape is part of the contract: it carries the
/// semantic fields ONLY (the compile-time guard keeps an accidental
/// span/debug field from riding along).
#[allow(dead_code)]
fn digest_shape_guard(
    digest: &kerf::driver::SemanticDigest,
) -> (
    &Vec<kerf::driver::SemanticProtoDigest>,
    &Vec<LiteralValue>,
    &Vec<String>,
) {
    (&digest.funcs, &digest.consts, &digest.globals)
}

/// The production bridge consumes and produces the shared spine's
/// own types (the compile-time guard: the bridge returns
/// `ModuleItem`s — the same type the seed front end produces, which
/// is what makes the shared fixpoint spine sound).
#[allow(dead_code)]
fn bridge_type_guard(items: &[ModuleItem]) -> usize {
    items
        .iter()
        .filter(|i| matches!(i, ModuleItem::Define { .. }))
        .count()
}

/// Unused-import guards: the types this module pins at compile
/// time (CoreExpr through the expansion face).
#[allow(dead_code)]
fn expr_type_guard(expr: &CoreExpr) -> u8 {
    match expr {
        CoreExpr::Literal { .. } => 0,
        _ => 1,
    }
}

/// Bytecode equality remains available (the same-skin caliber used
/// by the fixpoint's own assertion).
#[allow(dead_code)]
fn bytecode_eq_guard(a: &Bytecode, b: &Bytecode) -> bool {
    a == b
}

//! Stage-interlude integration tests for compile-output determinism
//! (v0.24.0, docs/stage0.md §9.55) — the hard prerequisite of the
//! Stage 2 fixpoint gate B (bytecode identity): the same source, fed
//! through two independent reader -> expander -> loader -> compiler
//! traversals (fresh per-instance SipHash keys in every internal
//! map/set), must produce structurally identical expanded items and
//! identical bytecode.
//!
//! The §9.55 audit classified every HashMap/HashSet site in the
//! pipeline crates: all are keyed-lookup-only, membership-only, or
//! insertion-order-indexed (the `Vec` + `HashMap`-as-index shape — a
//! hand-rolled IndexMap, K69); no site lets iteration order leak into
//! compiler output. These tests lock that property: a future change
//! that reintroduces an order leak fails here before it can reach the
//! fixpoint face.
//!
//! Layering note (SOP §8.4.6 rule 7): cross-crate assertions over the
//! whole pipeline live in the root tree; the per-structure invariants
//! are unit tests inside the owning crates.

use kerf::compiler::{Bytecode, compile_program};
use kerf::driver::{
    EXPANDER_TARGET_SOURCE, Session, TARGET_LEXER_TARGET_SOURCE, assembled_expander_target_source,
    parse_target, target_byte_table_prefix, target_forms_stream_prefix,
};
use kerf::reader::read_target_program;
use kerf::span::FileId;

const CORPUS_DIR: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/tests/v1/stage1/corpus");

/// The corpus-scale probe for the parser twin's byte table — the
/// target-skin fib program, inlined (the pipeline FIB attestation,
/// r150's migrated spelling). The probe's bytes ride the RS-1
/// prologue (the target-skin byte table) ahead of the parser twin's
/// own source — the twin implements the target read chain, so its
/// input records are the probe's bytes by construction (the r151
/// single-skin retainer: the former S-expr probe and its token
/// table retired with the reader).
const PROBE_TARGET_SOURCE: &str = "fn fib(n) { if ((n < 2)) { n } else { (fib((n - 1)) + fib((n - 2))) } }\ndefine(r, fib(10));\n";

/// One full parse+compile traversal over `source` under `session`.
/// Returns the expanded items and the compiled bytecode, or the
/// diagnostic batch (both failure classes keep their exact payload so
/// the determinism comparison covers the error face too). The
/// front-end reader is the target reader by construction (the r151
/// single-skin retainer — the former face parameter and its S-expr
/// arm retired with the reader).
fn traverse(
    session: &mut Session,
    name: &str,
    source: &str,
) -> Result<(Vec<kerf::core::ModuleItem>, Bytecode), String> {
    let parsed = parse_target(session, name, source).map_err(|diags| {
        diags
            .iter()
            .map(|d| d.message.clone())
            .collect::<Vec<_>>()
            .join(" | ")
    })?;
    let bytecode = compile_program(&parsed.items).map_err(|err| format!("{err}"))?;
    Ok((parsed.items, bytecode))
}

// ---------- positive: the determinism property itself ----------

#[test]
fn selfhost_assembled_subjects_double_traversal_identical() {
    // The self-hosted front-end subjects in their ASSEMBLED form on
    // the PRODUCTION-CHAIN SKIN (the r104 teardown's `.ktf` twins):
    // the LEXER twin (the target skin's own lexical face — the r151
    // twin of the former reader library) behind a corpus-scale
    // probe's byte table (the target_lexer_parity drive recipe: the
    // twin reads its input through the `source_bytes` RS-1 prologue),
    // and the macro library assembled ahead of the expander twin
    // behind the expander twin's OWN forms stream (the gate-B
    // recipe; the twin reads its own `.ktf` source through the
    // target reader). One session per subject keeps FileId identity
    // stable across the two traversals (Session::intern is
    // name-keyed), so spans in debug_info compare equal too.
    let probe = PROBE_TARGET_SOURCE;
    let reader_table = target_byte_table_prefix(probe);
    let reader_assembled = format!("{reader_table}\n{TARGET_LEXER_TARGET_SOURCE}");
    let expander_forms = read_target_program(FileId(0), EXPANDER_TARGET_SOURCE)
        .expect("the expander twin reads (forms layer)");
    let expander_assembled = format!(
        "{}\n{}",
        target_forms_stream_prefix(&expander_forms),
        assembled_expander_target_source()
    );
    for (name, source) in [
        ("assembled-reader", reader_assembled.as_str()),
        ("assembled-expander", expander_assembled.as_str()),
    ] {
        let mut session = Session::new();
        let first = traverse(&mut session, name, source).expect("first traversal");
        let second = traverse(&mut session, name, source).expect("second traversal");
        assert_eq!(
            first.0, second.0,
            "expanded items must be identical across traversals ({name})"
        );
        assert_eq!(
            first.1, second.1,
            "bytecode must be identical across traversals ({name})"
        );
        // Non-triviality: the subjects must actually exercise the
        // pools and the function table, not just an empty program.
        assert!(first.1.funcs.len() > 1, "subject has closures ({name})");
        assert!(
            !first.1.consts.is_empty(),
            "subject uses the constant pool ({name})"
        );
        assert!(
            !first.1.globals.is_empty(),
            "subject defines globals ({name})"
        );
    }
}

#[test]
fn corpus_sweep_double_traversal_identical() {
    // Every corpus file through two independent traversals on the
    // TARGET face (the blade-1 migration's single-skin corpus): both
    // runs must agree exactly — equal expanded items and equal
    // bytecode for the accepted files, equal diagnostic batches for
    // the rejected ones. The directory listing is sorted so the
    // sweep itself never depends on OS order.
    let mut paths = std::fs::read_dir(CORPUS_DIR)
        .expect("corpus directory reads")
        .map(|entry| entry.expect("entry").path())
        .filter(|path| path.extension().is_some_and(|ext| ext == "ktf"))
        .collect::<Vec<_>>();
    paths.sort();
    assert!(
        paths.len() >= 79,
        "corpus sweep covers the frozen subset (154 .ktf cases post-migration)"
    );

    let mut accepted = 0usize;
    let mut rejected = 0usize;
    for path in &paths {
        let name = path
            .file_name()
            .and_then(|n| n.to_str())
            .expect("corpus file name is utf-8");
        let source = std::fs::read_to_string(path).expect("corpus file reads");
        let mut session = Session::new();
        let first = traverse(&mut session, name, &source);
        let second = traverse(&mut session, name, &source);
        match (first, second) {
            (Ok((items_a, bc_a)), Ok((items_b, bc_b))) => {
                assert_eq!(items_a, items_b, "items identical ({name})");
                assert_eq!(bc_a, bc_b, "bytecode identical ({name})");
                accepted += 1;
            }
            (Err(diags_a), Err(diags_b)) => {
                assert_eq!(diags_a, diags_b, "rejections identical ({name})");
                // The pipeline-positive family (every pos-* case and
                // the 255-ok nesting boundary) must reach compile
                // success here — a rejection inside parse+compile is
                // a pipeline regression, not a determinism finding.
                assert!(
                    !(name.starts_with("pos-") || name.starts_with("bnd-006")),
                    "pipeline-positive corpus case must compile ({name})"
                );
                rejected += 1;
            }
            (a, b) => {
                panic!("traversals disagree on acceptance ({name}): {a:?} vs {b:?}");
            }
        }
    }
    assert!(accepted > 0, "accepted face is exercised");
    assert!(rejected > 0, "rejection face is exercised");
}

#[test]
fn macro_rename_face_double_expansion_identical() {
    // The rename-on-capture face: the template introduces a `tmp`
    // binder while the spliced use-site argument references a global
    // of the same text — the trigger set forces a fresh mangled name
    // (`tmp__macro_N`). The mangled suffix sequence depends only on
    // template traversal order (a tree walk), never on the HashSet
    // iteration order that builds the trigger set (§9.55.4), so two
    // traversals must produce the identical renamed tree.
    let source = "\
macro guarded { (syntax_rules, nil, ((_, v), (let, ((tmp, v),), (+, tmp, 1)))) }
fn tmp(x) { (x * 10) }
define(result, guarded(tmp(3)));";
    let mut session = Session::new();
    let first = traverse(&mut session, "rename-face.ktf", source).expect("compiles");
    let second = traverse(&mut session, "rename-face.ktf", source).expect("compiles");
    assert_eq!(first.0, second.0, "renamed expansion must be identical");
    assert_eq!(
        first.1, second.1,
        "bytecode over the rename face must be identical"
    );
}

// ---------- negative: the guard's detection power ----------

#[test]
fn bytecode_equality_catches_const_pool_divergence() {
    // Detector-detects: the structural comparison the guard relies on
    // must actually see a changed constant pool (an order leak would
    // manifest exactly here — same contents, different pool order).
    let mut session = Session::new();
    let (_, bc) = traverse(&mut session, "pool.ktf", "define(a, (1 + 2));").expect("compiles");
    assert!(bc.consts.len() >= 2, "fixture uses the pool");
    let mut drifted = bc.clone();
    drifted.consts.push(kerf::core::LiteralValue::Int(7));
    assert_ne!(bc, drifted, "a changed const pool must be detected");
}

#[test]
fn bytecode_equality_catches_global_table_divergence() {
    // Same detection power on the global table — the face an
    // iteration-order leak in `intern_global` would disturb.
    let mut session = Session::new();
    let (_, bc) =
        traverse(&mut session, "glob.ktf", "define(x, 1); define(y, 2);").expect("compiles");
    assert!(bc.globals.len() >= 2, "fixture defines globals");
    let mut drifted = bc.clone();
    drifted
        .globals
        .push(kerf::span::Symbol::new("z").expect("valid symbol"));
    assert_ne!(bc, drifted, "a changed global table must be detected");
}

#[test]
fn bytecode_equality_catches_code_divergence() {
    // Same detection power on the instruction stream itself.
    let mut session = Session::new();
    let (_, bc) = traverse(&mut session, "code.ktf", "define(a, (1 + 2));").expect("compiles");
    let mut drifted = bc.clone();
    let entry = &mut drifted.funcs[0];
    assert!(!entry.code.is_empty(), "entry proto carries code");
    entry
        .code
        .push(kerf::compiler::Instr::new(kerf::compiler::Opcode::Halt));
    entry.debug_info.push(entry.debug_info[0]);
    assert_ne!(bc, drifted, "a changed instruction stream must be detected");
}

// ---------- the ordering discipline the property rests on ----------

#[test]
fn define_order_is_first_use_semantics() {
    // Global slots follow first-use (source) order — the deterministic
    // ordering discipline of `intern_global` (idx = Vec::len() at
    // insert; the HashMap is a dedup index, never the emission
    // source). Swapping the definition order swaps the table order;
    // no hash order can ever enter it.
    let mut session = Session::new();
    let (_, ab) =
        traverse(&mut session, "ab.ktf", "define(a, 1); define(b, 2);").expect("compiles");
    let (_, ba) =
        traverse(&mut session, "ba.ktf", "define(b, 2); define(a, 1);").expect("compiles");
    assert_eq!(ab.globals[0].as_str(), "a", "first use comes first (ab)");
    assert_eq!(ab.globals[1].as_str(), "b", "second use comes second (ab)");
    assert_eq!(ba.globals[0].as_str(), "b", "first use comes first (ba)");
    assert_eq!(ba.globals[1].as_str(), "a", "second use comes second (ba)");
    assert_ne!(ab, ba, "source order is observable, and that is the fix");
}

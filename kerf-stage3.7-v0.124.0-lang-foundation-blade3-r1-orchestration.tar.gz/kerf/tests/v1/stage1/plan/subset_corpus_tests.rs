//! Stage 1.4 acceptance-corpus tests — the `.ktf` corpus through the
//! real pipeline (stage-1-plan row 1.4; docs/stage0.md §9.45.5).
//!
//! Two faces over one corpus directory (`tests/v1/stage1/corpus/`):
//! - one `#[test]` per case (the macro table below — isolation and
//!   precise failure naming);
//! - one dynamic sweep over the directory (completeness: no `.ktf`
//!   file escapes validation).
//!
//! The table and the directory are held in exact parity by the
//! `test_infra_guard_tests::corpus_case_table_matches_directory_exactly`
//! guard (v0.26.0, stage0.md §9.57): a new corpus file must gain its
//! table entry in the same change — the isolation face may not lag.
//!
//! Every expectation is embedded in its file's `// expect:` directive
//! line (the GCC torture `dg-*` pattern; the skin-neutral prefix —
//! W-SEXP-RETIRE blade 1, w-sexp-retire-window SR-1) and was verified
//! against the real pipeline at authoring time — the corpus is frozen
//! data, the harness is `kerf_driver::parity` (the Stage 1.4 contract
//! surface, target-reader face).
//!
//! Distribution (subset-spec.md): positive >= 20, negative >= 20,
//! boundary >= 10, total >= 50 — asserted by the meta tests below.
//! Corpus face at r168: 154 cases (56/88/10) — single-skin since
//! the W-SEXP-RETIRE blade-1 migration (three skin-divergent cases
//! retired per w-sexp-retire-window SR-2; their divergence pins live
//! in the sweep's dedicated tests); the r168-b4 blade-3 enum rows
//! added sixteen (4 positive + 12 negative, a 1:3 ratio face).

use kerf::driver::{CorpusCase, validate_target};

/// The corpus directory (absolute — the working directory of a test
/// run is the package root, but the sweep stays explicit).
const CORPUS_DIR: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/tests/v1/stage1/corpus");

/// Declare one isolated per-case test: embed the file at compile
/// time (relative to this file), parse its directive, validate
/// through the real pipeline, assert the match.
macro_rules! corpus_case {
    ($fn_name:ident, $file:literal) => {
        #[test]
        fn $fn_name() {
            let source = include_str!(concat!("../corpus/", $file));
            let case = CorpusCase::from_source($file, source).expect("directive parses");
            let report = validate_target(&case);
            assert!(
                report.matched,
                "corpus case `{}` drifted: {} (observed {:?})",
                $file,
                report.drift.as_deref().unwrap_or("no drift note"),
                report.observed
            );
        }
    };
}

corpus_case!(corpus_bnd_001_i64_max, "bnd-001-i64-max.ktf");
corpus_case!(corpus_bnd_002_i64_min, "bnd-002-i64-min.ktf");
corpus_case!(
    corpus_bnd_003_sub_min_overflow,
    "bnd-003-sub-min-overflow.ktf"
);
corpus_case!(corpus_bnd_004_float_frac, "bnd-004-float-frac.ktf");
corpus_case!(corpus_bnd_005_float_whole, "bnd-005-float-whole.ktf");
corpus_case!(corpus_bnd_006_nesting_255_ok, "bnd-006-nesting-255-ok.ktf");
corpus_case!(
    corpus_bnd_007_nesting_257_fails,
    "bnd-007-nesting-257-fails.ktf"
);
corpus_case!(corpus_bnd_008_fib_25, "bnd-008-fib-25.ktf");
corpus_case!(corpus_bnd_009_iota_chain_50, "bnd-009-iota-chain-50.ktf");
corpus_case!(
    corpus_bnd_010_expansion_limit,
    "bnd-010-expansion-limit.ktf"
);
corpus_case!(corpus_neg_001_unclosed_paren, "neg-001-unclosed-paren.ktf");
corpus_case!(corpus_neg_002_stray_close, "neg-002-stray-close.ktf");
corpus_case!(
    corpus_neg_003_unterminated_string,
    "neg-003-unterminated-string.ktf"
);
corpus_case!(corpus_neg_004_bad_hash_token, "neg-004-bad-hash-token.ktf");
corpus_case!(
    corpus_neg_010_top_level_expression,
    "neg-010-top-level-expression.ktf"
);
corpus_case!(corpus_neg_011_malformed_fn, "neg-011-malformed-fn.ktf");
corpus_case!(corpus_neg_012_malformed_let, "neg-012-malformed-let.ktf");
corpus_case!(
    corpus_neg_013_unbound_reference,
    "neg-013-unbound-reference.ktf"
);
corpus_case!(corpus_neg_014_quote_symbol, "neg-014-quote-symbol.ktf");
corpus_case!(corpus_neg_015_set_unbound, "neg-015-set-unbound.ktf");
corpus_case!(
    corpus_neg_016_malformed_handle,
    "neg-016-malformed-handle.ktf"
);
corpus_case!(
    corpus_neg_017_malformed_define,
    "neg-017-malformed-define.ktf"
);
corpus_case!(corpus_neg_018_module_cycle, "neg-018-module-cycle.ktf");
corpus_case!(corpus_neg_019_module_missing, "neg-019-module-missing.ktf");
corpus_case!(
    corpus_neg_020_module_duplicate,
    "neg-020-module-duplicate.ktf"
);
// neg-021 retired (W-SEXP-RETIRE SR-2): the empty-application
// rejection has no target-skin subject (ruling C12 reads `()` as
// nil); the pin lives in the sweep's dedicated divergence test.
corpus_case!(corpus_neg_030_arity_known, "neg-030-arity-known.ktf");
corpus_case!(corpus_neg_031_nonbool_cond, "neg-031-nonbool-cond.ktf");
corpus_case!(corpus_neg_032_call_literal, "neg-032-call-literal.ktf");
corpus_case!(
    corpus_neg_033_call_numeric_global,
    "neg-033-call-numeric-global.ktf"
);
corpus_case!(corpus_neg_034_handler_arity, "neg-034-handler-arity.ktf");
corpus_case!(
    corpus_neg_035_unhandled_effect,
    "neg-035-unhandled-effect.ktf"
);
// neg-036 retired (W-SEXP-RETIRE SR-2): the bare-expression handler
// arm has no target-skin subject (the arm skin is inherently
// fn-wrapped, E0007 unreachable); the pin lives in the sweep's
// dedicated divergence test.
corpus_case!(
    corpus_neg_037_multi_error_collection,
    "neg-037-multi-error-collection.ktf"
);
corpus_case!(corpus_neg_040_div_zero, "neg-040-div-zero.ktf");
corpus_case!(corpus_neg_041_car_nonpair, "neg-041-car-nonpair.ktf");
corpus_case!(corpus_neg_042_add_overflow, "neg-042-add-overflow.ktf");
corpus_case!(
    corpus_neg_043_arity_through_param,
    "neg-043-arity-through-param.ktf"
);
corpus_case!(corpus_neg_044_add_bool, "neg-044-add-bool.ktf");
corpus_case!(
    corpus_neg_046_forward_reference,
    "neg-046-forward-reference.ktf"
);
corpus_case!(corpus_neg_047_write_line_int, "neg-047-write-line-int.ktf");
corpus_case!(
    corpus_neg_048_module_cycle_string,
    "neg-048-module-cycle-string.ktf"
);
corpus_case!(
    corpus_neg_049_require_missing,
    "neg-049-require-missing.ktf"
);
corpus_case!(
    corpus_neg_050_pattern_mismatch,
    "neg-050-pattern-mismatch.ktf"
);
corpus_case!(
    corpus_neg_051_duplicate_pattern_vars,
    "neg-051-duplicate-pattern-vars.ktf"
);
corpus_case!(
    corpus_neg_052_ellipsis_rejected,
    "neg-052-ellipsis-rejected.ktf"
);
corpus_case!(
    corpus_neg_053_module_macro_outside,
    "neg-053-module-macro-outside.ktf"
);
corpus_case!(
    corpus_neg_054_i64_overflow_literal,
    "neg-054-i64-overflow-literal.ktf"
);
corpus_case!(
    corpus_neg_055_float_overflow_literal,
    "neg-055-float-overflow-literal.ktf"
);
corpus_case!(
    corpus_neg_056_type_error_duplicate_codes,
    "neg-056-type-error-duplicate-codes.ktf"
);
// Stage 2.1 LA-7 boundary: assignment to a captured variable (the
// E0012 face — the immutable-capture subset).
corpus_case!(
    corpus_neg_057_assign_to_captured,
    "neg-057-assign-to-captured.ktf"
);
corpus_case!(corpus_pos_001_arith_add, "pos-001-arith-add.ktf");
corpus_case!(corpus_pos_002_arith_mixed, "pos-002-arith-mixed.ktf");
corpus_case!(corpus_pos_003_int_div, "pos-003-int-div.ktf");
corpus_case!(corpus_pos_004_float_add, "pos-004-float-add.ktf");
corpus_case!(corpus_pos_005_compare_true, "pos-005-compare-true.ktf");
corpus_case!(
    corpus_pos_006_bool_false_branch,
    "pos-006-bool-false-branch.ktf"
);
corpus_case!(
    corpus_pos_007_fn_sugar_square,
    "pos-007-fn-sugar-square.ktf"
);
corpus_case!(corpus_pos_009_recursion_fib, "pos-009-recursion-fib.ktf");
corpus_case!(corpus_pos_010_let_bindings, "pos-010-let-bindings.ktf");
corpus_case!(corpus_pos_011_let_shadow, "pos-011-let-shadow.ktf");
corpus_case!(corpus_pos_012_do_sequencing, "pos-012-do-sequencing.ktf");
corpus_case!(corpus_pos_013_string_literal, "pos-013-string-literal.ktf");
corpus_case!(corpus_pos_014_quote_list, "pos-014-quote-list.ktf");
corpus_case!(
    corpus_pos_015_quote_nested_lists,
    "pos-015-quote-nested-lists.ktf"
);
corpus_case!(corpus_pos_016_cons_chain, "pos-016-cons-chain.ktf");
corpus_case!(corpus_pos_017_car_cdr, "pos-017-car-cdr.ktf");
corpus_case!(corpus_pos_018_predicates, "pos-018-predicates.ktf");
corpus_case!(corpus_pos_019_not_truthy, "pos-019-not-truthy.ktf");
corpus_case!(
    corpus_pos_020_higher_order_map,
    "pos-020-higher-order-map.ktf"
);
corpus_case!(corpus_pos_021_effect_handle, "pos-021-effect-handle.ktf");
corpus_case!(
    corpus_pos_022_effect_pass_through,
    "pos-022-effect-pass-through.ktf"
);
corpus_case!(corpus_pos_023_write_line, "pos-023-write-line.ktf");
corpus_case!(corpus_pos_024_macro_my_if, "pos-024-macro-my-if.ktf");
corpus_case!(corpus_pos_025_module_flat, "pos-025-module-flat.ktf");
corpus_case!(corpus_pos_027_nil_literal, "pos-027-nil-literal.ktf");
corpus_case!(
    corpus_pos_028_warn_rebind_builtin,
    "pos-028-warn-rebind-builtin.ktf"
);
corpus_case!(corpus_pos_029_require_string, "pos-029-require-string.ktf");
corpus_case!(corpus_pos_030_module_nested, "pos-030-module-nested.ktf");
// pos-031 retired (W-SEXP-RETIRE SR-2): the `else` literal-macro use
// form has no target-skin spelling (the keyword economy reserves the
// word); the pin lives in the sweep's dedicated divergence test.
corpus_case!(
    corpus_pos_032_macro_two_generations,
    "pos-032-macro-two-generations.ktf"
);
corpus_case!(
    corpus_pos_033_hygiene_binder_collision,
    "pos-033-hygiene-binder-collision.ktf"
);
// Stage 2.1 semantic-flip round: the dormant-capture anchor
// `neg-045-closure-no-capture` (expected `type-error E0001`) flipped
// to `pos-034` — the closure now captures `n` and the program halts
// with 8 (the pre-registered §9.51.2 anchor family).
corpus_case!(
    corpus_pos_034_closure_capture,
    "pos-034-closure-capture.ktf"
);
corpus_case!(
    corpus_pos_035_closure_capture_dense,
    "pos-035-closure-capture-dense.ktf"
);
corpus_case!(
    corpus_pos_036_closure_transitive_capture,
    "pos-036-closure-transitive-capture.ktf"
);
// The W-3.2 extern family (r112): the language-level foreign
// contract at the corpus face — declared-not-called rides the value
// face (both engines halt before any boundary is touched); the
// called-on-VM case rides the runtime-error face (the designed
// engine divergence: the C backend is the one engine with a foreign
// call face); the four rejections pin the expander police (the type
// vocabulary, the ABI vocabulary, the collision family, the C-symbol
// floor).
corpus_case!(
    corpus_pos_037_extern_declared,
    "pos-037-extern-declared.ktf"
);
corpus_case!(corpus_neg_058_extern_vm_call, "neg-058-extern-vm-call.ktf");
corpus_case!(
    corpus_neg_059_extern_bad_type,
    "neg-059-extern-bad-type.ktf"
);
corpus_case!(corpus_neg_060_extern_bad_abi, "neg-060-extern-bad-abi.ktf");
corpus_case!(
    corpus_neg_061_extern_collision,
    "neg-061-extern-collision.ktf"
);
corpus_case!(
    corpus_neg_062_extern_bad_c_symbol,
    "neg-062-extern-bad-c-symbol.ktf"
);

// The TD-027 match family (r143 — the twin expander's match arm; the
// desugar's oracle/twin parity rides the steady-chain corpus sweep,
// and the curated composed formula carries the target-skin face).
// Eleven positives cover the pattern family (bare bindings, `_`,
// float/string/bool literals on same-kind scrutinees, the nil
// pattern, the pair shape with its irrefutable tail, the nested
// pair, shadowing, the in-function fold, the single-eval scrutinee);
// ten negatives pin the error axes and their ORDER — exhaustiveness
// before pattern compilation, the scrutinee's expansion before
// pattern compilation, the arm shapes before everything (the
// oracle's collection loop).
corpus_case!(corpus_pos_038_match_basic, "pos-038-match-basic.ktf");
corpus_case!(corpus_pos_039_match_wildcard, "pos-039-match-wildcard.ktf");
corpus_case!(
    corpus_pos_040_match_float_lit,
    "pos-040-match-float-lit.ktf"
);
corpus_case!(
    corpus_pos_041_match_string_lit,
    "pos-041-match-string-lit.ktf"
);
corpus_case!(corpus_pos_042_match_bool_lit, "pos-042-match-bool-lit.ktf");
corpus_case!(
    corpus_pos_043_match_nil_pattern,
    "pos-043-match-nil-pattern.ktf"
);
corpus_case!(
    corpus_pos_044_match_pair_pattern,
    "pos-044-match-pair-pattern.ktf"
);
corpus_case!(
    corpus_pos_045_match_nested_pair,
    "pos-045-match-nested-pair.ktf"
);
corpus_case!(corpus_pos_046_match_shadow, "pos-046-match-shadow.ktf");
corpus_case!(corpus_pos_047_match_in_fn, "pos-047-match-in-fn.ktf");
corpus_case!(
    corpus_pos_048_match_scrutinee_once,
    "pos-048-match-scrutinee-once.ktf"
);
// The blade 1 GZ-1 dann rows (r165 b3-twin): annotated programs run
// through the whole pipeline — the annotation site records are zero
// code, the value products are the unannotated faces' own.
corpus_case!(
    corpus_pos_101_ann_define_full,
    "pos-101-ann-define-full.ktf"
);
corpus_case!(corpus_pos_102_ann_closure, "pos-102-ann-closure.ktf");
corpus_case!(corpus_pos_103_ann_let_triple, "pos-103-ann-let-triple.ktf");
// The r165 b5 annotation families: the E0013 ret/let divergence
// rows, the E0009 param-contract rows, and the degrading-unknown
// positive row — the negative face of the blade 1 consumption
// (annotations are checked, not decorative).
corpus_case!(
    corpus_pos_104_ann_unknown_degrades,
    "pos-104-ann-unknown-degrades.ktf"
);
corpus_case!(
    corpus_neg_104_ann_ret_bool_int,
    "neg-104-ann-ret-bool-int.ktf"
);
corpus_case!(
    corpus_neg_105_ann_ret_int_str,
    "neg-105-ann-ret-int-str.ktf"
);
corpus_case!(
    corpus_neg_106_ann_ret_float_int,
    "neg-106-ann-ret-float-int.ktf"
);
corpus_case!(
    corpus_neg_107_ann_ret_closure,
    "neg-107-ann-ret-closure.ktf"
);
corpus_case!(
    corpus_neg_108_ann_let_bool_int,
    "neg-108-ann-let-bool-int.ktf"
);
corpus_case!(
    corpus_neg_109_ann_let_multi_mixed,
    "neg-109-ann-let-multi-mixed.ktf"
);
corpus_case!(
    corpus_neg_110_ann_param_call_diverges,
    "neg-110-ann-param-call-diverges.ktf"
);
corpus_case!(
    corpus_neg_111_ann_param_second_pos,
    "neg-111-ann-param-second-pos.ktf"
);
corpus_case!(
    corpus_neg_112_ann_param_str_int,
    "neg-112-ann-param-str-int.ktf"
);
corpus_case!(
    corpus_neg_113_ann_ret_bool_str,
    "neg-113-ann-ret-bool-str.ktf"
);
corpus_case!(
    corpus_neg_114_ann_let_float_str,
    "neg-114-ann-let-float-str.ktf"
);
corpus_case!(
    corpus_neg_115_ann_param_bool_float,
    "neg-115-ann-param-bool-float.ktf"
);
// ---- the blade-2 struct rows (r166 b4 — W-LANG-FOUNDATION GZ-2/GZ-3)
corpus_case!(corpus_pos_201_struct_basic, "pos-201-struct-basic.ktf");
corpus_case!(
    corpus_pos_202_struct_recursive,
    "pos-202-struct-recursive.ktf"
);
corpus_case!(
    corpus_pos_203_struct_self_org,
    "pos-203-struct-self-org.ktf"
);
corpus_case!(
    corpus_neg_201_struct_ctor_arg_mismatch,
    "neg-201-struct-ctor-arg-mismatch.ktf"
);
corpus_case!(
    corpus_neg_202_struct_accessor_arg_mismatch,
    "neg-202-struct-accessor-arg-mismatch.ktf"
);
corpus_case!(
    corpus_neg_203_struct_let_ann_divergence,
    "neg-203-struct-let-ann-divergence.ktf"
);
corpus_case!(
    corpus_neg_204_struct_ret_ann_divergence,
    "neg-204-struct-ret-ann-divergence.ktf"
);
corpus_case!(
    corpus_neg_206_struct_redeclared,
    "neg-206-struct-redeclared.ktf"
);
corpus_case!(
    corpus_neg_207_struct_define_collision,
    "neg-207-struct-define-collision.ktf"
);
corpus_case!(
    corpus_neg_208_struct_duplicate_field,
    "neg-208-struct-duplicate-field.ktf"
);
corpus_case!(
    corpus_neg_209_struct_field_reserved,
    "neg-209-struct-field-reserved.ktf"
);
corpus_case!(
    corpus_neg_210_struct_missing_colon,
    "neg-210-struct-missing-colon.ktf"
);
corpus_case!(
    corpus_neg_211_struct_unclosed,
    "neg-211-struct-unclosed.ktf"
);
// The blade 3 enum rows (r168-b4, w-lang-foundation-window §10.5):
// four positive faces (construct+match full chain, the
// self-describing corpus-row enum, the GZ-4 exhaustive-complete
// no-wildcard program, the §10.2 tag bare face) and twelve negative
// faces at 1:3 (read rejections, the expander police family, the
// GZ-4 gap family, the ctor contract faces E0009/E0002, the E0013
// annotation divergence).
corpus_case!(
    corpus_pos_301_enum_construct_match,
    "pos-301-enum-construct-match.ktf"
);
corpus_case!(
    corpus_pos_302_enum_self_describing,
    "pos-302-enum-self-describing.ktf"
);
corpus_case!(
    corpus_pos_303_enum_exhaustive_complete,
    "pos-303-enum-exhaustive-complete.ktf"
);
corpus_case!(
    corpus_pos_304_enum_tag_bare_face,
    "pos-304-enum-tag-bare-face.ktf"
);
corpus_case!(corpus_neg_301_enum_unclosed, "neg-301-enum-unclosed.ktf");
corpus_case!(corpus_neg_302_enum_bad_spec, "neg-302-enum-bad-spec.ktf");
corpus_case!(
    corpus_neg_303_enum_redeclared,
    "neg-303-enum-redeclared.ktf"
);
corpus_case!(
    corpus_neg_304_enum_duplicate_variant,
    "neg-304-enum-duplicate-variant.ktf"
);
corpus_case!(
    corpus_neg_305_enum_variant_reserved,
    "neg-305-enum-variant-reserved.ktf"
);
corpus_case!(
    corpus_neg_306_enum_define_on_variant,
    "neg-306-enum-define-on-variant.ktf"
);
corpus_case!(corpus_neg_307_enum_match_gap, "neg-307-enum-match-gap.ktf");
corpus_case!(
    corpus_neg_308_enum_match_gap_literal_last,
    "neg-308-enum-match-gap-literal-last.ktf"
);
corpus_case!(
    corpus_neg_309_enum_match_cross_gap,
    "neg-309-enum-match-cross-gap.ktf"
);
corpus_case!(
    corpus_neg_310_enum_ctor_payload_type,
    "neg-310-enum-ctor-payload-type.ktf"
);
corpus_case!(
    corpus_neg_311_enum_ctor_arity,
    "neg-311-enum-ctor-arity.ktf"
);
corpus_case!(
    corpus_neg_312_enum_ann_divergence,
    "neg-312-enum-ann-divergence.ktf"
);
corpus_case!(
    corpus_neg_063_match_nonexhaustive,
    "neg-063-match-nonexhaustive.ktf"
);
corpus_case!(
    corpus_neg_064_match_nil_last_arm,
    "neg-064-match-nil-last-arm.ktf"
);
corpus_case!(
    corpus_neg_065_match_3tuple_unsupported,
    "neg-065-match-3tuple-unsupported.ktf"
);
corpus_case!(
    corpus_neg_066_match_nested_unsupported,
    "neg-066-match-nested-unsupported.ktf"
);
corpus_case!(
    corpus_neg_067_match_malformed_arity,
    "neg-067-match-malformed-arity.ktf"
);
corpus_case!(
    corpus_neg_068_match_malformed_arm,
    "neg-068-match-malformed-arm.ktf"
);
corpus_case!(
    corpus_neg_069_match_unbound_body,
    "neg-069-match-unbound-body.ktf"
);
corpus_case!(
    corpus_neg_070_match_unbound_scrutinee,
    "neg-070-match-unbound-scrutinee.ktf"
);
corpus_case!(
    corpus_neg_071_match_exhaust_before_pattern,
    "neg-071-match-exhaust-before-pattern.ktf"
);
corpus_case!(
    corpus_neg_072_match_scrutinee_before_pattern,
    "neg-072-match-scrutinee-before-pattern.ktf"
);

// ---------- the dynamic sweep + corpus meta (completeness/floor) ----------

/// Every `.ktf` file in the corpus directory validates through the
/// contract — the completeness face (sorted, deterministic order).
#[test]
fn corpus_directory_every_file_validates() {
    let mut paths: Vec<_> = std::fs::read_dir(CORPUS_DIR)
        .expect("corpus directory exists")
        .filter_map(|e| e.ok())
        .map(|e| e.path())
        .filter(|p| p.extension().is_some_and(|x| x == "ktf"))
        .collect();
    paths.sort();
    assert!(
        paths.len() >= 50,
        "corpus floor: {} files, want >= 50",
        paths.len()
    );
    for path in paths {
        let name = path.file_stem().unwrap().to_str().unwrap().to_owned();
        let source = std::fs::read_to_string(&path).expect("corpus file reads");
        let case = CorpusCase::from_source(
            Box::leak(name.clone().into_boxed_str()),
            Box::leak(source.into_boxed_str()),
        )
        .unwrap_or_else(|e| panic!("directive of `{name}`: {e}"));
        let report = validate_target(&case);
        assert!(
            report.matched,
            "corpus case `{name}` drifted: {} (observed {:?})",
            report.drift.as_deref().unwrap_or("no drift note"),
            report.observed
        );
    }
}

/// The frozen distribution floors (subset-spec.md §Corpus): positive
/// >= 20, negative >= 20, boundary >= 10, total >= 50.
#[test]
fn corpus_distribution_meets_floors() {
    let names: Vec<String> = std::fs::read_dir(CORPUS_DIR)
        .expect("corpus directory exists")
        .filter_map(|e| e.ok())
        .filter_map(|e| e.file_name().into_string().ok())
        .filter(|n| n.ends_with(".ktf"))
        .collect();
    let count = |prefix: &str| names.iter().filter(|n| n.starts_with(prefix)).count();
    let pos = count("pos-");
    let neg = count("neg-");
    let bnd = count("bnd-");
    let total = names.len();
    assert!(pos >= 20, "positive floor: {pos} < 20");
    assert!(neg >= 20, "negative floor: {neg} < 20");
    assert!(bnd >= 10, "boundary floor: {bnd} < 10");
    assert!(total >= 50, "total floor: {total} < 50");
}

/// Case names are unique and carry their category prefix (the naming
/// discipline the distribution test counts on).
#[test]
fn corpus_names_are_prefixed_and_unique() {
    let mut names: Vec<String> = std::fs::read_dir(CORPUS_DIR)
        .expect("corpus directory exists")
        .filter_map(|e| e.ok())
        .filter_map(|e| e.file_name().into_string().ok())
        .filter(|n| n.ends_with(".ktf"))
        .collect();
    names.sort();
    let total = names.len();
    names.dedup();
    assert_eq!(names.len(), total, "corpus file names are unique");
    for name in &names {
        assert!(
            name.starts_with("pos-") || name.starts_with("neg-") || name.starts_with("bnd-"),
            "case `{name}` lacks a category prefix"
        );
    }
}

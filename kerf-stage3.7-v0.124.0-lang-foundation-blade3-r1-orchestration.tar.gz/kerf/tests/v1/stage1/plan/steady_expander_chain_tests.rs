//! The W-3.12 segment-two steady-state bootstrap chain (w3.12
//! §5, the segment-two agenda): the twin expander program compiled
//! ONCE, fed per forms-stream through the injection channel — the
//! productionized form of the EX-1 test channel.
//!
//! Three layers, per the corpus discipline:
//! - **Positive**: the steady chain expands the full corpus (every
//!   target-reader-readable source's forms) and matches the Rust oracle
//!   on both axes — the tree dump on accept rows, the parity key
//!   on expansion/loader rejection rows; the dual-engine agreement
//!   on probe form streams; the expander segment's own-source
//!   self-application (the segment fixpoint face: the twin
//!   expander expanding its own source, the product items
//!   compiling byte-identically to the oracle's compilation of
//!   the oracle's expansion).
//! - **Negative**: the unknown-name fail-closed face (the
//!   injection channel's slot contract); the injection-feeds-
//!   every-expansion contract (two different form streams expand
//!   differently — a program-side define clobber of `forms` would
//!   collapse them onto one stream); the r103 spellability
//!   boundary (the text route classifies the i64::MIN row, the
//!   injected face carries it — the disclosed capability delta);
//!   the expansion-layer rejection corpus rows ride the sweep's
//!   error axis.
//! - **Cross-route equivalence**: the steady route and the
//!   per-source text route (the EX-1 channel form) decode to
//!   identical outcomes through the same decoder on the same form
//!   streams — the delivery face changed, the computed verdict did
//!   not.
//!
//! W-SEXP-RETIRE blade 1 (v0.111.0): the corpus sweep rides the
//! migrated single-skin `.ktf` corpus (154 cases — the seed-skin
//! originals retired from the sweep; three skin-divergent cases
//! retired outright per w-sexp-retire-window SR-2; the r168-b4
//! blade-3 enum rows added sixteen), reading through
//! `read_target_program` — the expander twin consumes forms, and
//! forms are skin-neutral SyntaxObjects, so the twin face itself is
//! unchanged; only the reader face moved.
//!
//! The i64::MIN delta (the r103 exception ledger, instantiated):
//! the TEXT face cannot carry an `i64::MIN` datum, so
//! junction-2's text route classifies those corpus rows at the
//! boundary; the injected VALUE face has no such boundary, so this
//! sweep covers `bnd-002-i64-min` natively — the capability delta
//! is asserted, not just disclosed (the boundary test below pins
//! both faces' behavior).

use kerf::compiler::compile_program;
use kerf::driver::{
    SteadyExpanderChain, forms_stream_literal, oracle_expansion_axes, per_source_route,
};
use kerf::expander::{expand_program, load_program};
use kerf::reader::read_target_program;
use kerf::span::FileId;
use kerf::span::{ByteOffset, ExpansionId, Span};
use kerf::syntax::{Phase, ScopeSet, SyntaxObject};

const CORPUS_DIR: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/tests/v1/stage1/corpus");

/// The i64::MIN boundary row's forms stream, built programmatically
/// (the seed-skin corpus file left the sweep at the blade-1 migration;
/// the S-expr text that used to carry the row retired with the
/// blade-2 S-expr read-chain removal — the row's premise IS a datum
/// the target skin cannot spell: the magnitude 2^63 overflows the
/// positive domain before the sign. Its `.ktf` corpus twin composes
/// `0 - 9223372036854775807 - 1` instead, which carries no
/// unspellable datum and so cannot pin the text-route boundary —
/// the one-form stream `(define result <i64::MIN>)` is constructed
/// directly, reader-shaped: empty scopes, runtime phase, one atom
/// per source token).
fn i64_min_boundary_forms() -> Vec<SyntaxObject> {
    let span = |a: u32, b: u32| {
        Span::new(FileId(0), ByteOffset(a), ByteOffset(b), ExpansionId::ROOT)
            .expect("boundary-row span is ordered")
    };
    let scopes = ScopeSet::new();
    let phase = Phase::Runtime;
    let head = SyntaxObject::symbol(span(0, 6), scopes.clone(), phase, "define")
        .expect("the define head symbol is valid");
    let name = SyntaxObject::symbol(span(7, 13), scopes.clone(), phase, "result")
        .expect("the result name symbol is valid");
    let value = SyntaxObject::int(span(14, 34), scopes, phase, i64::MIN);
    vec![SyntaxObject::list(
        span(0, 35),
        ScopeSet::new(),
        phase,
        vec![head, name, value],
    )]
}

/// Deep trees (the corpus's nesting family) recurse through the
/// harness's Rust tree walkers; the demand-allocated stack
/// discipline of the sibling chain tests.
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly");
}

/// The oracle's both-axes text in the flat verdict form (the
/// steady chain's `SteadyExpansion::text` convention: accept rows
/// carry the dump, rejection rows carry the bare parity key —
/// the same flat form `KtfVerdict::text` renders).
fn axes_text(oracle: &Result<String, String>) -> String {
    match oracle {
        Ok(dump) => dump.clone(),
        Err(key) => key.clone(),
    }
}

#[test]
fn steady_expander_sweeps_the_corpus_and_matches_the_oracle() {
    deep_stack(|| {
        // The expansion-segment fixpoint face: every corpus file
        // whose source the target reader accepts (the blade-1
        // single-skin corpus), through the steady chain (compiled
        // once, injected per stream) — both axes match the Rust
        // oracle, accept rows and expansion/loader rejection rows
        // alike. Reader-rejection rows are the READ segment's rows
        // (segment one's sweep owns them); they are counted, not fed.
        let chain = SteadyExpanderChain::new().expect("the fixed twin program builds");
        let entries = std::fs::read_dir(CORPUS_DIR).expect("the corpus directory is in tree");
        let mut files: Vec<_> = entries
            .filter_map(|e| e.ok())
            .map(|e| e.path())
            .filter(|p| p.extension().is_some_and(|x| x == "ktf"))
            .collect();
        files.sort();
        assert!(
            files.len() >= 154,
            "the corpus sweep expects the single-skin ledger population \
             (154 .ktf cases — 109 blade-1 cases + the sixteen annotation rows + the thirteen \
             blade-2 struct rows + the sixteen blade-3 enum rows), got {}",
            files.len()
        );
        let mut expanded = 0usize;
        let mut expansion_rejected = 0usize;
        let mut reader_rejected = 0usize;
        for path in &files {
            let source = std::fs::read_to_string(path).expect("corpus file reads");
            let case = path.file_name().unwrap().to_string_lossy().to_string();
            let forms = match read_target_program(FileId(0), &source) {
                Ok(forms) => forms,
                Err(_) => {
                    // The read layer owns this row's verdict — the
                    // expansion layer never sees it (segment one's
                    // sweep carries the row).
                    reader_rejected += 1;
                    continue;
                }
            };
            let outcome = chain.expand(&forms).unwrap_or_else(|e| {
                panic!("steady chain expands {case} without a harness defect: {e}")
            });
            // r123: the disclosed twin boundary RETIRED. The
            // C-symbol validity face left the expander with the
            // re-attribution (W-CSYM-EXPR ruling b — a C-domain
            // product constraint, judged at compile/verify via
            // `extern_table_floor`), so the twin now expresses the
            // expander's COMPLETE semantic face: neg-062 rides the
            // normal sweep path, text and items both matching the
            // oracle — zero disclosed rows, zero silent skips.
            let oracle = oracle_expansion_axes(&forms);
            assert_eq!(
                outcome.text,
                axes_text(&oracle),
                "{case}: the steady chain's verdict text matches the oracle"
            );
            if oracle.is_ok() {
                expanded += 1;
                // The items face (stronger than the text — the
                // extern entry NAMES ride the records but not the
                // dump grammar): the rebuilt items equal the
                // oracle's own expansion field for field.
                let oracle_items = expand_program(&forms)
                    .unwrap_or_else(|e| panic!("{case}: the oracle expands: {e}"));
                load_program(&oracle_items)
                    .unwrap_or_else(|e| panic!("{case}: the oracle loader accepts: {e}"));
                assert_eq!(
                    outcome.items,
                    Some(oracle_items),
                    "{case}: the rebuilt items equal the oracle's expansion"
                );
            } else {
                expansion_rejected += 1;
            }
        }
        // The sweep's pinned populations: the accept rows feed the
        // downstream segments; the expansion/loader rejections (the
        // unbound/malformed/macro-mismatch/extern/module families)
        // ride the error axis; the reader-layer rejections are
        // accounted, not fed. Since r123 every row is classified
        // by twin/oracle agreement alone — the disclosed C-symbol
        // boundary row retired with the re-attribution (the extern
        // C-domain faces are compile-stage product constraints
        // now; neg-062's compile-stage rejection rides the corpus
        // contract's compile-error kind).
        //
        // The r150 blade-1 re-measurement on the `.ktf` corpus: the
        // nine stage-divergent rows (the malformed keyword-headed
        // forms) moved from the expansion rows to the READER rows
        // (the grammar-directed target reader rejects what the
        // permissive S-expr reader deferred to the expander), the
        // three retired divergences dropped, and the ruling-D
        // module twins reject at the loader face as before — 70
        // accept / 23 expansion / 16 reader.
        assert!(
            expanded >= 70,
            "the expansion accept rows ride the sweep (got {expanded})"
        );
        assert!(
            expansion_rejected >= 23,
            "the expansion-layer rejection rows ride the sweep (got {expansion_rejected})"
        );
        assert!(
            reader_rejected >= 16,
            "the reader-layer rejection rows are accounted (got {reader_rejected})"
        );
        assert_eq!(
            expanded + expansion_rejected + reader_rejected,
            files.len(),
            "every corpus row is classified exactly once (zero disclosed rows since r123)"
        );
    });
}

#[test]
fn steady_expander_covers_the_i64_min_row_the_text_route_cannot() {
    deep_stack(|| {
        // The r103 exception ledger, instantiated on the injection
        // face: the i64::MIN datum has NO target-skin text, so the
        // per-source TEXT route classifies it at the boundary —
        // while the injected VALUE face carries it natively and
        // matches the oracle. The capability delta is asserted on
        // both faces (the delta the window record discloses). The
        // row's stream is built programmatically (the
        // determinism-guard precedent's construction face) — the
        // `.ktf` corpus twin composes the value arithmetically and
        // never exercises this boundary.
        let forms = i64_min_boundary_forms();
        assert!(
            per_source_route(&forms).is_err(),
            "the text route classifies the unspellable row (the r103 boundary)"
        );
        let chain = SteadyExpanderChain::new().expect("the fixed twin program builds");
        let outcome = chain
            .expand(&forms)
            .expect("the injected face carries the i64::MIN datum");
        let oracle = oracle_expansion_axes(&forms);
        assert_eq!(
            outcome.text,
            axes_text(&oracle),
            "the steady chain covers the boundary row natively"
        );
        assert!(oracle.is_ok(), "the boundary row expands cleanly");
    });
}

#[test]
fn steady_expander_dual_engines_agree_on_probe_form_streams() {
    deep_stack(|| {
        // The dual-engine discipline on the steady route: both
        // engines run the same once-compiled program with the same
        // injection and agree with each other and with the oracle
        // — an accept anchor, an expansion-layer rejection, a
        // macro row (the declaration face) and the empty stream
        // (the nil payload).
        let chain = SteadyExpanderChain::new().expect("the fixed twin program builds");
        let probes: &[(&str, &str)] = &[
            (
                "accept-anchor",
                "fn fib(n) { if ((n < 2)) { n } else { (fib((n - 1)) + fib((n - 2))) } }",
            ),
            ("reject-unbound", "fn f(x) { x }\ng(1);"),
            (
                "macro-row",
                "macro k_cond { (syntax_rules, nil, ((_, c, t, e), (if, c, t, e))) }\nfn g(n) { k_cond((n < 2), n, 99) }",
            ),
            ("empty-stream", ""),
            ("comment-only", "// nothing but trivia\n"),
        ];
        for (name, source) in probes {
            let forms = read_target_program(FileId(0), source).expect("the probe reads");
            let (vm_outcome, eval_outcome) = chain
                .expand_dual(&forms)
                .unwrap_or_else(|e| panic!("{name}: the dual expansion runs: {e}"));
            assert_eq!(
                vm_outcome, eval_outcome,
                "{name}: the two engines agree on the steady route"
            );
            let oracle = oracle_expansion_axes(&forms);
            assert_eq!(
                vm_outcome.text,
                axes_text(&oracle),
                "{name}: the vm verdict text matches the oracle"
            );
        }
    });
}

#[test]
fn steady_expander_matches_the_per_source_route_on_the_same_streams() {
    deep_stack(|| {
        // Cross-route equivalence: the EX-1 text-channel form (the
        // record stream as a per-source program-text prefix,
        // recompiled per expansion) and the injection form decode
        // to identical outcomes through the same decoder — the
        // delivery face changed, the verdict did not. Both engines
        // agree with the steady route's VM outcome.
        let chain = SteadyExpanderChain::new().expect("the fixed twin program builds");
        let probes: &[(&str, &str)] = &[
            ("anchor", "fn f(x) { (x * x) }"),
            // The nested-groups S-expr probe (`((((((1))))))`) has no
            // target twin — target groups `(e)` collapse to `e` — so
            // the twin rides nested CALLS, the same six-level form
            // tree depth (each call = one list record).
            ("nested", "e(d(c(b(a(1)))));"),
            (
                "macro",
                "macro k_cond { (syntax_rules, nil, ((_, c, t, e), (if, c, t, e))) }\nfn g(n) { k_cond((n < 2), n, 99) }",
            ),
            ("reject-unbound", "g(1);"),
        ];
        for (name, source) in probes {
            let forms = read_target_program(FileId(0), source).expect("the probe reads");
            let steady = chain
                .expand(&forms)
                .unwrap_or_else(|e| panic!("{name}: the steady expansion runs: {e}"));
            let (vm_route, eval_route) = per_source_route(&forms)
                .unwrap_or_else(|e| panic!("{name}: the per-source route runs: {e}"));
            assert_eq!(
                steady, vm_route,
                "{name}: the steady route matches the text route's vm arm"
            );
            assert_eq!(
                vm_route, eval_route,
                "{name}: the text route's two engines agree"
            );
        }
    });
}

#[test]
fn steady_expander_is_deterministic_and_the_injection_feeds_every_expansion() {
    deep_stack(|| {
        // Determinism: the same form stream expanded twice decodes
        // identically. The no-define clobber contract: two
        // DIFFERENT form streams expand differently — a
        // program-side define of `forms` would collapse every
        // expansion onto one stream and this assertion fails
        // loudly (the build-time reference check plus this
        // behavioral probe are the contract's machine faces).
        let chain = SteadyExpanderChain::new().expect("the fixed twin program builds");
        let a = read_target_program(FileId(0), "fn a(x) { x }").expect("a reads");
        let b =
            read_target_program(FileId(0), "fn b(y) { if (y) { 1 } else { 2 } }").expect("b reads");
        let a1 = chain.expand(&a).expect("the first expansion of a");
        let a2 = chain.expand(&a).expect("the second expansion of a");
        assert_eq!(a1, a2, "the same form stream expands identically");
        let b1 = chain.expand(&b).expect("the expansion of b");
        assert_ne!(
            a1, b1,
            "different form streams expand differently — the injection feeds every expansion"
        );
        // And the interleaved re-expansion still holds (no
        // cross-expansion state on the shared compiled product).
        let a3 = chain
            .expand(&a)
            .expect("the third expansion of a, interleaved");
        assert_eq!(a1, a3, "the interleaved re-expansion is stable");
    });
}

#[test]
fn steady_expander_unknown_injection_name_fails_closed() {
    deep_stack(|| {
        // The injection channel's slot contract: a name outside
        // the compiled program's global table is rejected
        // fail-closed (InjectGlobalUnknown) — the channel rides an
        // existing slot and never mints one.
        let chain = SteadyExpanderChain::new().expect("the fixed twin program builds");
        let forms = read_target_program(FileId(0), "fn f(x) { x }").expect("the probe reads");
        let payload = forms_stream_literal(&forms);
        let mut vm = kerf::vm::Vm::with_io(
            chain.bytecode().clone(),
            Box::new(kerf::vm::BufferIo::default()),
        )
        .expect("the vm builds");
        let err = vm
            .inject_global("definitely-not-a-global", &payload)
            .expect_err("the unknown name fails closed");
        assert!(
            matches!(err, kerf::vm::RuntimeError::InjectGlobalUnknown { .. }),
            "the rejection is the channel's own fail-closed variant (got {err:?})"
        );
    });
}

#[test]
fn steady_expander_expands_its_own_source_the_segment_fixpoint_face() {
    deep_stack(|| {
        // The expander segment's self-application (the segment
        // fixpoint face): the twin expander's OWN source — macro.ktf
        // + expander.ktf, read through the production bridge's
        // target reader — expanded through the steady chain, the
        // verdict matching the Rust oracle's expansion of the same
        // forms; the rebuilt product items then compile
        // byte-identically to the oracle's compilation of the
        // oracle's own expansion (the expansion product is real
        // items and the two expansion routes agree all the way
        // down the compile segment's gate-B caliber).
        let chain = SteadyExpanderChain::new().expect("the fixed twin program builds");
        // The CP6 selfhost-bare precedent: the hosting tail
        // (`define(result, ex_run(forms))`) references the injected
        // `forms` global — a free name under a plain expansion — so
        // the self-application drives the STRUCTURAL twin source
        // (the tail stripped), exactly like the compiler fixpoint's
        // `structural_target_source`.
        // The blade 2 face (GZ-2): the structural source rides the
        // CCF base (the extern slot declarations — `forms` and the
        // accessor table's `ex-struct-accs`), so the twin's OWN body
        // reference to the table resolves on BOTH routes (the twin
        // seeds its ex_externs from the input's extern heads; the
        // oracle's own extern pre-scan does the same) — the bare
        // assembly's free reference would dangle identically on
        // both, which is the mutual-rejection agreement face, not
        // this positive fixpoint's subject.
        let own = kerf::driver::ccf_expander_source();
        let structural = own.replace("\ndefine(result, ex_run(forms));", "");
        assert_ne!(
            &structural, &own,
            "the hosting tail anchor must be present in the twin source"
        );
        let forms = kerf::reader::read_target_program(FileId(0), &structural)
            .expect("the twin's own structural source reads through the target reader");
        let outcome = chain
            .expand(&forms)
            .expect("the twin expands its own source");
        let oracle_items =
            expand_program(&forms).expect("the oracle expands the twin's own source");
        load_program(&oracle_items).expect("the oracle loader accepts the twin's own expansion");
        let oracle_text = kerf::driver::oracle_dump_items(&oracle_items);
        assert_eq!(
            outcome.text, oracle_text,
            "the self-expansion matches the oracle's expansion"
        );
        // The cross-stage caliber: the steady route's rebuilt items
        // compile to the SAME bytecode as the oracle's items (the
        // expansion product feeds the compile segment identically
        // from both routes).
        let steady_items = outcome
            .items
            .expect("the self-expansion is an accept verdict");
        let bc_steady =
            compile_program(&steady_items).expect("the steady route's self-expansion compiles");
        let bc_oracle = compile_program(&oracle_items)
            .expect("the oracle's expansion of the same forms compiles");
        assert_eq!(
            bc_steady, bc_oracle,
            "the two routes' expansions compile byte-identically"
        );
    });
}

#[test]
fn steady_expander_empty_stream_rides_as_nil() {
    deep_stack(|| {
        // The empty-forms ledger row (the prefix face's
        // `(quote nil)` convention, mirrored on the value face):
        // the empty stream's payload IS Nil, and the twin expands
        // it to the empty item list — matching the oracle's
        // expansion of no forms.
        assert_eq!(
            forms_stream_literal(&[]),
            kerf::core::LiteralValue::Nil,
            "the empty stream's payload is nil"
        );
        let chain = SteadyExpanderChain::new().expect("the fixed twin program builds");
        let outcome = chain
            .expand(&[])
            .expect("the empty stream expands (an outcome, not a defect)");
        let oracle = oracle_expansion_axes(&[]);
        assert_eq!(
            outcome.text,
            axes_text(&oracle),
            "the empty stream's expansion matches the oracle"
        );
        assert_eq!(
            outcome.items,
            Some(Vec::new()),
            "the empty stream expands to the empty item list"
        );
    });
}

#[test]
fn steady_expander_compiles_once_and_expands_many_on_one_product() {
    deep_stack(|| {
        // The steady-state shape itself: ONE compiled product, MANY
        // expansions — the bytecode pointer is stable across
        // expansions (no recompile), and the payload encoding's
        // literal face pins one known record (the single source
        // next to the text form): the zero-arg call `x();` — the
        // list record at 1..3 and the ident `x` at 0..1.
        let chain = SteadyExpanderChain::new().expect("the fixed twin program builds");
        let first = chain.bytecode() as *const _;
        let sources = [
            "fn f(x) { x }",
            "1(2, 3);",
            "// just a comment\n",
            "g(\"payload\");",
        ];
        for source in sources {
            let forms = read_target_program(FileId(0), source).expect("the source reads");
            chain
                .expand(&forms)
                .unwrap_or_else(|e| panic!("the expansion of {source:?} runs: {e}"));
            assert_eq!(
                chain.bytecode() as *const _,
                first,
                "the compiled product is one allocation across expansions"
            );
        }
        // The payload encoding's literal face: `x();` — the zero-arg
        // call is a one-element list (the head only), so one list
        // record plus one ident record, each a PROPER five-field
        // list (the trailing nil terminator included).
        let forms = read_target_program(FileId(0), "x();").expect("the probe reads");
        let payload = forms_stream_literal(&forms);
        let field = |v: kerf::core::LiteralValue, rest: kerf::core::LiteralValue| {
            kerf::core::LiteralValue::Pair(Box::new(v), Box::new(rest))
        };
        let str_lit = |v: &str| kerf::core::LiteralValue::String(v.into());
        let int_lit = |v: i64| kerf::core::LiteralValue::Int(v);
        let expected = field(
            field(
                str_lit("list"),
                field(
                    str_lit("1"),
                    field(
                        str_lit("3"),
                        field(int_lit(1), field(int_lit(0), kerf::core::LiteralValue::Nil)),
                    ),
                ),
            ),
            field(
                field(
                    str_lit("ident"),
                    field(
                        str_lit("0"),
                        field(
                            str_lit("1"),
                            field(
                                str_lit("x"),
                                field(int_lit(0), kerf::core::LiteralValue::Nil),
                            ),
                        ),
                    ),
                ),
                kerf::core::LiteralValue::Nil,
            ),
        );
        assert_eq!(
            payload, expected,
            "the record grammar's literal face is pinned field for field"
        );
    });
}

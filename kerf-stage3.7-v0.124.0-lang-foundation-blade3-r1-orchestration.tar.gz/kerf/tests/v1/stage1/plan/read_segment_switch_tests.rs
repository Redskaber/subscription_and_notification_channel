//! Read segment switch tests (T-a step-④ blade 1 — w-t-a-switch-window
//! §3 r145+ row): the READ segment's production position switch. The
//! `.ktf` production read rides the steady twin chain on the VM (the
//! default); the Rust target reader retires to the oracle face (the
//! parity comparison arm, the seed chain's own read, and the rollback
//! band — `KERF_READ_SEGMENT=rust`).
//!
//! Four faces, per the corpus discipline (GATE 6 composition):
//!
//! * **Positive** — the production position's forms are BIT-IDENTICAL
//!   to the oracle read's forms across the curated target family and
//!   the selfhost fixed points (the deepest inputs the read chain
//!   owns — the language reading its own reader family).
//! * **Negative** — the rejection family: the production position
//!   rebuilds the SAME `ReadError` (same parity key, same rendered
//!   diagnostic text) as the oracle; the lexer layer's rejections
//!   never reach the parser twin (the layer split); the nesting-cap
//!   override rejects with the same key on both positions.
//! * **Rollback band** — the position selector's three states
//!   (default twin, explicit rust, invalid fail-closed) and the two
//!   positions' agreement on the corpus.
//! * **Cross-stage consumption** — the production-position read
//!   feeds the whole spine (expand → check → compile): the compiled
//!   bytecode equals the Rust-position bytecode, and the CLI check
//!   face rides the twin read end to end.
//!
//! The r145 stack-flat family (the K163 exposure): the byte-table
//! walks (`pair_cells` / `from_literal` / the Box-drop glue) run on
//! DEFAULT stacks here — every test below reads multi-KB sources
//! through the twin chain on the ordinary test-thread stack (the
//! pre-fix tree overflowed exactly here).

use kerf::compiler::compile_program;
use kerf::driver::{
    self, Diagnostic, ProductionReadError, ReadSegment, Session, TARGET_PARSER_TWIN_CASES,
    parse_target, production_read, render_diagnostics, run_cli,
};
use kerf::reader::{read_target_program, read_target_program_with_limit};
use kerf::span::FileId;
use kerf::syntax::SyntaxObject;

use crate::steady_target_reader_tests::SELFHOST_SOURCES;

const CORPUS_NESTING: usize = kerf::reader::NESTING_LIMIT;

/// Run one body on a thread with a large stack: the deep-nesting
/// probe below rides the recursive-descent face, which consumes far
/// more native stack per source nesting level than the datum
/// tree's own depth (the sandbox's 8 MiB default rlimit overflows
/// mid-rejection — the sibling plan tests carry the same wrapper;
/// the api_tests face surfaced the same gap the same session).
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(256 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly");
}

/// One `.ktf` source read through BOTH positions must agree:
/// `Ok(forms)` vs `Ok(forms)` (bit-identical) or the SAME rejection.
#[derive(Debug)]
enum ReadOutcome {
    Forms(Vec<SyntaxObject>),
    Reject(String),
}

fn oracle_read(source: &str) -> ReadOutcome {
    match read_target_program(FileId(0), source) {
        Ok(forms) => ReadOutcome::Forms(forms),
        Err(err) => ReadOutcome::Reject(driver::error_parity_key(&err)),
    }
}

fn twin_read(source: &str) -> ReadOutcome {
    match production_read(source, CORPUS_NESTING, FileId(0)) {
        Ok(forms) => ReadOutcome::Forms(forms),
        // A defect is NOT a program rejection — it must panic the
        // test (a compiler defect never masquerades as a verdict).
        Err(ProductionReadError::Program(err)) => {
            ReadOutcome::Reject(driver::error_parity_key(&err))
        }
        Err(ProductionReadError::Defect(msg)) => {
            panic!("the production read must not carry defects: {msg}")
        }
    }
}

fn assert_positions_agree(name: &str, source: &str) {
    match (twin_read(source), oracle_read(source)) {
        (ReadOutcome::Forms(a), ReadOutcome::Forms(b)) => {
            assert_eq!(
                a, b,
                "the twin and oracle forms must be identical on {name}"
            );
        }
        (ReadOutcome::Reject(a), ReadOutcome::Reject(b)) => {
            assert_eq!(
                a, b,
                "the twin and oracle rejections must carry the same key on {name}"
            );
        }
        (twin, oracle) => {
            panic!("the positions disagree on {name}: twin {twin:?} vs oracle {oracle:?}");
        }
    }
}

// ---------- positive: the production position holds the corpus ----------

/// The curated target family (both polarities) — the production
/// position's read is the oracle's read, case for case (the default
/// flip's own sweep: every acceptance and every rejection agrees).
#[test]
fn the_curated_family_reads_identically_on_both_positions() {
    for &(name, source) in TARGET_PARSER_TWIN_CASES {
        assert_positions_agree(name, source);
    }
}

/// The nine selfhost sources + the assembled expander program — the
/// deepest fixed points, on the DEFAULT stack (the r145 stack-flat
/// family: the pre-fix `from_literal`/`pair_cells`/Box-drop recursion
/// overflowed exactly here on a multi-KB source).
#[test]
fn the_selfhost_fixed_points_read_on_a_default_stack() {
    let mut sources: Vec<(&str, &str)> = SELFHOST_SOURCES.to_vec();
    let assembled = kerf::driver::assembled_expander_target_source();
    sources.push(("assembled-expander.ktf", assembled.as_str()));
    for (name, source) in &sources {
        assert_positions_agree(name, source);
    }
}

// ---------- negative: the rejection family ----------

/// The rejection family through the PRODUCTION position: each case
/// rebuilds the oracle's own `ReadError`, so the rendered diagnostic
/// text (the user-facing face) is identical on both positions —
/// span-for-span, message-for-message.
#[test]
fn rejections_render_identically_on_both_positions() {
    let rejections: &[(&str, &str)] = &[
        ("stray-close", "fn f() { 1 } }\n"),
        ("unclosed-delim", "fn f() { 1\n"),
        ("unexpected-token", "fn f() { + }\n"),
        ("bad-escape", "fn f() { \"a\\q\" }\n"),
        ("nonfinite-float", "fn f() { 1.0e999 }\n"),
        ("unsupported-form", "impl Point { fn get() { 1 } }\n"),
    ];
    for &(name, source) in rejections {
        let twin = production_read(source, CORPUS_NESTING, FileId(0));
        let oracle = read_target_program(FileId(0), source);
        let (twin_err, oracle_err) = match (twin, oracle) {
            (Err(ProductionReadError::Program(t)), Err(o)) => (t, o),
            other => panic!("the rejection case {name} must reject on both positions: {other:?}"),
        };
        // The same parity key (the harness contract) ...
        assert_eq!(
            driver::error_parity_key(&twin_err),
            driver::error_parity_key(&oracle_err),
            "the rejection key must match on {name}"
        );
        // ... AND the same user-facing diagnostic: render both
        // against a session that interned the source at a NON-zero
        // file id (the span-retarget face — a rebuilt span naming
        // the wrong file renders against the wrong source).
        let mut twin_session = Session::new();
        let _other = twin_session.intern("zero.ktf", "fn z() { 0 }");
        let file = twin_session.intern(name, source);
        let twin_diag = Diagnostic::from_read(&twin_err, file);
        let twin_text = render_diagnostics(&twin_session, &[twin_diag]);
        let mut oracle_session = Session::new();
        let _other = oracle_session.intern("zero.ktf", "fn z() { 0 }");
        let oracle_file = oracle_session.intern(name, source);
        let oracle_diag = kerf::driver::Diagnostic::from_read(&oracle_err, oracle_file);
        let oracle_text = render_diagnostics(&oracle_session, &[oracle_diag]);
        assert_eq!(
            twin_text, oracle_text,
            "the rendered diagnostic must be identical on both positions for {name}"
        );
    }
}

/// The layer split: a LEXER-layer rejection never reaches the parser
/// twin. The lexer layer owns the float-overflow face — the bridge
/// derivation rejects before the parser program ever runs.
#[test]
fn the_lexer_layer_split_holds_in_production() {
    let source = "fn f() { 1.0e999 2.0e999 }\n";
    match production_read(source, CORPUS_NESTING, FileId(0)) {
        Err(ProductionReadError::Program(kerf::reader::ReadError::FloatOutOfRange { .. })) => {}
        other => panic!("the lexer layer must own the float rejection: {other:?}"),
    }
}

/// The nesting-cap override: BOTH positions honor the effective
/// `KERF_READER_NESTING_LIMIT` — a source within the raised cap
/// reads on both positions, and an over-cap source rejects with the
/// SAME key on both (the rollback band's parity obligation — the
/// twin parser's baked `tp_limit` mirrors the process cap).
#[test]
fn the_nesting_cap_override_is_honored_by_both_positions() {
    deep_stack(|| {
        // The legal deep shape: nested `if (true) { ... } else { 0 }`
        // blocks (the corpus's own generated-nesting grammar).
        let deep = |n: usize| {
            let mut twin = String::from("define(result, ");
            for _ in 0..n {
                twin.push_str("if (true) { ");
            }
            twin.push('1');
            for _ in 0..n {
                twin.push_str(" } else { 0 }");
            }
            twin.push_str(");");
            twin
        };
        // Within a RAISED cap (512): both positions accept a 200-deep
        // nest.
        let raised = 512;
        let source = deep(200);
        let twin = production_read(&source, raised, FileId(0));
        let oracle = read_target_program_with_limit(FileId(0), &source, raised);
        assert!(
            twin.is_ok() && oracle.is_ok(),
            "a 200-deep nest must read under a 512 cap on both positions"
        );
        // Over the DEFAULT cap (256): both positions reject a 400-deep
        // nest with the same key.
        let source = deep(400);
        match (
            production_read(&source, CORPUS_NESTING, FileId(0)),
            read_target_program_with_limit(FileId(0), &source, CORPUS_NESTING),
        ) {
            (Err(ProductionReadError::Program(t)), Err(o)) => assert_eq!(
                driver::error_parity_key(&t),
                driver::error_parity_key(&o),
                "the over-cap rejection key must match on both positions"
            ),
            other => panic!("a 400-deep nest must reject under the 256 cap on both: {other:?}"),
        }
    });
}

// ---------- the rollback band ----------

/// The selector's three states: the library default is the switched
/// position (`Twin`); an explicit `Rust` session rides the oracle;
/// an invalid env value is a hard error (fail-closed — the
/// `DepthLimits` precedent).
#[test]
fn the_rollback_band_three_states() {
    // 1. The env value's parse face (pure — no ambient state).
    assert_eq!(ReadSegment::parse_value("twin"), Ok(ReadSegment::Twin));
    assert_eq!(ReadSegment::parse_value("rust"), Ok(ReadSegment::Rust));
    for bad in ["", "twins", "TWIN", "c", "0"] {
        assert!(
            ReadSegment::parse_value(bad).is_err(),
            "`{bad}` must fail closed"
        );
    }
    // 2. The session default is the switched position; the pinned
    //    session rides the Rust reader — and BOTH parse the same
    //    source to the same items (the band's parity).
    let source = "fn main() { 1 + 2 }\n";
    let mut twin_session = Session::new();
    let twin_program = parse_target(&mut twin_session, "band.ktf", source)
        .unwrap_or_else(|d| panic!("the twin position must parse: {d:?}"));
    assert_eq!(twin_program.read_segment, ReadSegment::Twin);
    let mut rust_session = Session::with_read_segment(ReadSegment::Rust);
    let rust_program = parse_target(&mut rust_session, "band.ktf", source)
        .unwrap_or_else(|d| panic!("the rust position must parse: {d:?}"));
    assert_eq!(rust_program.read_segment, ReadSegment::Rust);
    assert_eq!(
        twin_program.items, rust_program.items,
        "the two positions must produce identical items"
    );
    // 3. The r151 retarget: the third band face — the S-expr
    //    reader's disclosure reporting `ReadSegment::Rust` — retired
    //    with the S-expr read API itself (W-SEXP-RETIRE blade 2; the
    //    seed-skin face no longer has a reader, so there is no segment to
    //    disclose). The two live positions keep the band's parity
    //    above.
}

// ---------- cross-stage consumption ----------

/// The production-position read feeds the WHOLE spine: parse →
/// typecheck (clean) → compile, and the compiled bytecode equals the
/// Rust-position bytecode bit-for-bit (the C1 formula at the
/// production position — the segment-switch parity gate).
#[test]
fn the_production_position_feeds_the_whole_spine() {
    let subjects: Vec<(&str, &str)> = vec![
        (
            "curated-fn",
            "fn add(a, b) { a + b }\nfn main() { add(1, 2) }\n",
        ),
        (
            "curated-match",
            "fn pick(p) { match p { 1 => { 10 }, _ => { 20 }, } }\nfn main() { pick(1) }\n",
        ),
        ("macro-twin", SELFHOST_SOURCES[2].1),
    ];
    for (name, source) in &subjects {
        let mut twin_session = Session::new();
        let twin_program = parse_target(&mut twin_session, name, source)
            .unwrap_or_else(|d| panic!("the twin position must parse {name}: {d:?}"));
        let findings = twin_program.typecheck();
        assert!(
            !findings
                .iter()
                .any(|d| d.severity == kerf::driver::Severity::Error),
            "the twin position must check clean on {name}: {findings:?}"
        );
        let twin_bc = compile_program(&twin_program.items)
            .unwrap_or_else(|e| panic!("the twin position must compile {name}: {e}"));
        let mut rust_session = Session::with_read_segment(ReadSegment::Rust);
        let rust_program = parse_target(&mut rust_session, name, source)
            .unwrap_or_else(|d| panic!("the rust position must parse {name}: {d:?}"));
        let rust_bc = compile_program(&rust_program.items)
            .unwrap_or_else(|e| panic!("the rust position must compile {name}: {e}"));
        assert_eq!(
            twin_bc, rust_bc,
            "the two positions must compile to identical bytecode on {name}"
        );
    }
}

/// The CLI check face rides the twin read end to end (the
/// process-entry default; `KERF_READ_SEGMENT` unset): a clean
/// `.ktf` program checks green, and a rejected program renders the
/// same diagnostic the Rust position renders (the user-facing
/// equivalence of the band).
#[test]
fn the_cli_check_face_rides_the_twin_read() {
    let clean = "fn main() { 40 + 2 }\n";
    let mut out = Vec::new();
    let mut err = Vec::new();
    let code = run_cli(
        &["check".to_string(), "main.ktf".to_string()],
        &|_| Ok(clean.to_string()),
        &mut || None,
        Vec::new(),
        &mut out,
        &mut err,
    );
    assert_eq!(code, 0, "the clean program must check green: {err:?}");
    assert!(
        String::from_utf8_lossy(&out).contains("ok"),
        "the check face must report ok: {out:?}"
    );
    // A rejected program renders — exit 1, the diagnostic batch on
    // the error sink, and the RENDERED TEXT equals the Rust
    // position's own rendering of the same source.
    let broken = "fn main() { 1.0e999 }\n";
    let mut out = Vec::new();
    let mut err = Vec::new();
    let code = run_cli(
        &["check".to_string(), "main.ktf".to_string()],
        &|_| Ok(broken.to_string()),
        &mut || None,
        Vec::new(),
        &mut out,
        &mut err,
    );
    assert_eq!(code, 1, "the rejected program must fail the check");
    let twin_text = String::from_utf8_lossy(&err).into_owned();
    let mut rust_session = Session::with_read_segment(ReadSegment::Rust);
    let rust_program = parse_target(&mut rust_session, "main.ktf", broken).unwrap_err();
    let oracle_text = render_diagnostics(&rust_session, &rust_program);
    assert_eq!(
        twin_text.trim(),
        oracle_text.trim(),
        "the CLI diagnostic must equal the rust position's rendering"
    );
}

/// The seed faces stay pinned to the Rust reader (the step-④
/// dual-chain decoupling): the bootstrap bridge
/// (`read_target_source_for_bootstrap`) and the A/B/C A pass
/// (`rust_compile_ccf`) must construct their sessions with the
/// explicit `ReadSegment::Rust` pin — if either ever rode the
/// switched production position, the fixpoint purity leg's
/// "twin front end == Rust production bridge" assertion would
/// collapse into a self-comparison (detection power zero) and the
/// A ≡ B observation row would lose its read-segment coverage.
/// A source-scan guard (the TEST-2/TEST-3 precedent — machine-checked
/// source invariants; r146: the pins moved to the two-segment
/// `with_segments` constructor — the scan follows the pin).
#[test]
fn the_seed_faces_stay_pinned_to_the_rust_reader() {
    let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR"));
    let pins: &[(&str, &str)] = &[
        (
            "crates/kerf-driver/src/bootstrap/target_corpus.rs",
            "read_target_source_for_bootstrap",
        ),
        (
            "crates/kerf-driver/src/bootstrap/abc_pipeline.rs",
            "rust_compile_ccf",
        ),
    ];
    for (path, face) in pins {
        let src = std::fs::read_to_string(root.join(path))
            .unwrap_or_else(|e| panic!("the {face} source must read: {e}"));
        let start = src
            .find(face)
            .unwrap_or_else(|| panic!("the {face} declaration must exist in {path}"));
        // The construction window: the function's first 1,500
        // characters (the session construction sits at the top of
        // each body).
        let window = &src[start..(start + 1500).min(src.len())];
        assert!(
            window.contains("with_segments")
                && window.contains("crate::read_segment::ReadSegment::Rust"),
            "{face} must pin the Rust read segment (the fixpoint differential's \
             detection power depends on it — see the step-④ dual-chain decoupling)"
        );
    }
}

// The r151 retirement record (W-SEXP-RETIRE blade 2): the S-expr
// seed-reader spot-check (`the_sexpr_seed_face_is_untouched` — a
// `read_program`/`parse` parity pin over `(define x 1)`) retired
// with its subject: the S-expression read API no longer exists in
// the crate, so there is no seed face to keep untouched and no
// twin to compare against. The surviving read faces are pinned by
// the composed-chain and rollback-band tests above (both positions
// of the one target-skin reader).

//! The bytecode→C text builder (stage0.md §9.92; the r90
//! adjudication II implementation slice).
//!
//! Emission shape (per-proto C functions with STATIC operand-stack
//! slots — the depths come from the [`crate::depth`] DAG, the same
//! walk `Bytecode::verify` runs, so no stack pointer exists in the
//! generated code):
//!
//! - every proto becomes `static KValue kf_N(KVm*, KValue*, KValue*)`
//!   with `locals[]` (nil-padded, args zipped — the `Frame::new`
//!   mirror), `st[]` (the statically addressed operand stack), and
//!   one labeled statement per reachable instruction (`goto` for
//!   jumps);
//! - `call` lowers to the ONE generated trampoline `k_call` (the
//!   per-proto switch + the builtin arm — the K152 single-adapter
//!   discipline), `perform` to the shim's handler search;
//! - constants ride a generated `KConst` pool: floats as bit
//!   patterns (no decimal text anywhere), strings as byte arrays,
//!   pair shapes as `KLit` trees materialized at push time exactly
//!   like `Value::from_literal` (one batched cell charge);
//! - determinism is total: identical input bytecode emits
//!   byte-identical C (pinned by unit tests; no map iteration ever
//!   reaches the output order).

use std::collections::{BTreeSet, HashMap};
use std::fmt::Write as _;

use kerf_compiler::{Bytecode, CaptureSource, Instr, Opcode};
use kerf_core::LiteralValue;
use kerf_span::Symbol;
use kerf_vm::Builtin;

use crate::EmitError;
use crate::depth::{self, ProtoDepth};

/// The embedded host runtime shim (pasted verbatim into every
/// generated file — single translation unit, `cc prog.c` is the
/// whole build).
pub(crate) const SHIM: &str = include_str!("shim/kerf_rt.h");

/// One escaped C string literal (octal escapes for non-printables —
/// never `\x`, which greedily eats following hex characters).
fn c_string(text: &str) -> String {
    let mut s = String::with_capacity(text.len() + 2);
    s.push('"');
    for b in text.as_bytes() {
        match *b {
            b'"' => s.push_str("\\\""),
            b'\\' => s.push_str("\\\\"),
            0x20..=0x7e => s.push(*b as char),
            other => {
                let _ = write!(s, "\\{other:03o}");
            }
        }
    }
    s.push('"');
    s
}

/// One i64 literal (INT64_MIN has no positive decimal spelling).
fn c_i64(v: i64) -> String {
    if v == i64::MIN {
        "INT64_MIN".to_owned()
    } else {
        format!("INT64_C({v})")
    }
}

/// The builtin variant → C enum-name table. The ORDER of
/// [`Builtin::ALL`] is the pin (the shim's `KBuiltinCode` enum
/// declaration order); the exhaustive match makes a new Rust variant
/// a compile error here until the shim grows its arm.
fn builtin_code(b: Builtin) -> &'static str {
    match b {
        Builtin::Add => "KB_ADD",
        Builtin::Sub => "KB_SUB",
        Builtin::Mul => "KB_MUL",
        Builtin::Div => "KB_DIV",
        Builtin::Lt => "KB_LT",
        Builtin::Le => "KB_LE",
        Builtin::Gt => "KB_GT",
        Builtin::Ge => "KB_GE",
        Builtin::NumEq => "KB_NUMEQ",
        Builtin::Car => "KB_CAR",
        Builtin::Cdr => "KB_CDR",
        Builtin::Cons => "KB_CONS",
        Builtin::IsPair => "KB_ISPAIR",
        Builtin::IsNil => "KB_ISNIL",
        Builtin::Eq => "KB_EQ",
        Builtin::Not => "KB_NOT",
        Builtin::ReadLine => "KB_READLINE",
        Builtin::WriteLine => "KB_WRITELINE",
    }
}

/// The generated-file context: the text under construction plus the
/// deduplicated string pool (first-encounter order — deterministic).
struct Ctx {
    out: String,
    string_names: HashMap<Vec<u8>, String>,
    string_lines: Vec<String>,
    string_counter: usize,
    lit_lines: Vec<String>,
    lit_counter: usize,
}

impl Ctx {
    fn new() -> Self {
        Ctx {
            out: String::new(),
            string_names: HashMap::new(),
            string_lines: Vec::new(),
            string_counter: 0,
            lit_lines: Vec::new(),
            lit_counter: 0,
        }
    }

    /// Intern one byte string as a static array; returns the C
    /// variable name.
    fn intern_string(&mut self, bytes: &[u8]) -> String {
        if let Some(name) = self.string_names.get(bytes) {
            return name.clone();
        }
        let name = format!("kcs{}", self.string_counter);
        self.string_counter += 1;
        let mut cells = String::new();
        if bytes.is_empty() {
            // A zero-length array initializer is not C; one padding
            // byte with n = 0 carries the empty string.
            cells.push_str("0x00");
        } else {
            for (i, b) in bytes.iter().enumerate() {
                if i > 0 {
                    cells.push_str(", ");
                }
                let _ = write!(cells, "0x{b:02x}");
            }
        }
        self.string_lines.push(format!(
            "static const unsigned char {name}[] = {{{cells}}};"
        ));
        self.string_names.insert(bytes.to_vec(), name.clone());
        name
    }

    /// Emit one `KLit` node (post-order: children land first).
    fn emit_lit(&mut self, lit: &LiteralValue) -> String {
        let name = format!("klt{}", self.lit_counter);
        self.lit_counter += 1;
        let line = match lit {
            LiteralValue::Int(v) => {
                format!(
                    "static const KLit {name} = {{ .kind = 0, .as.i = {} }};",
                    c_i64(*v)
                )
            }
            LiteralValue::Float(v) => format!(
                "static const KLit {name} = {{ .kind = 1, .as.bits = UINT64_C(0x{:016x}) }};",
                v.to_bits()
            ),
            LiteralValue::Bool(v) => {
                format!(
                    "static const KLit {name} = {{ .kind = 2, .as.b = {} }};",
                    *v as u8
                )
            }
            LiteralValue::String(v) => {
                let arr = self.intern_string(v.as_bytes());
                format!(
                    "static const KLit {name} = {{ .kind = 3, .as.s.p = (const char *){arr}, .as.s.n = {}u }};",
                    v.len()
                )
            }
            LiteralValue::Nil => {
                format!("static const KLit {name} = {{ .kind = 4 }};")
            }
            LiteralValue::Pair(a, b) => {
                let car = self.emit_lit(a);
                let cdr = self.emit_lit(b);
                format!(
                    "static const KLit {name} = {{ .kind = 5, .as.pair.car = &{car}, .as.pair.cdr = &{cdr} }};"
                )
            }
        };
        self.lit_lines.push(line);
        name
    }

    /// One KConst initializer line (registers string arrays and
    /// literal trees as a side effect).
    fn const_entry(&mut self, lit: &LiteralValue) -> String {
        match lit {
            LiteralValue::Int(v) => {
                format!("    {{ .kind = 0, .cells = 0u, .as.i = {} }}", c_i64(*v))
            }
            LiteralValue::Float(v) => format!(
                "    {{ .kind = 1, .cells = 0u, .as.bits = UINT64_C(0x{:016x}) }}",
                v.to_bits()
            ),
            LiteralValue::Bool(v) => {
                format!("    {{ .kind = 2, .cells = 0u, .as.b = {} }}", *v as u8)
            }
            LiteralValue::String(v) => {
                let arr = self.intern_string(v.as_bytes());
                format!(
                    "    {{ .kind = 3, .cells = 0u, .as.s.p = (const char *){arr}, .as.s.n = {}u }}",
                    v.len()
                )
            }
            LiteralValue::Nil => "    { .kind = 4, .cells = 0u }".to_owned(),
            LiteralValue::Pair(..) => {
                let root = self.emit_lit(lit);
                format!(
                    "    {{ .kind = 5, .cells = {}u, .as.lit = &{root} }}",
                    lit.pair_cells()
                )
            }
        }
    }
}

/// The KArithOp code for the four arithmetic opcodes.
fn arith_code(op: Opcode) -> &'static str {
    match op {
        Opcode::Add => "KA_ADD",
        Opcode::Sub => "KA_SUB",
        Opcode::Mul => "KA_MUL",
        _ => "KA_DIV",
    }
}

/// Worst-case C frame bytes for one proto: locals + operand stack +
/// the largest call-argument window + the largest capture window,
/// plus fixed overhead. Drives the emitted host-stack depth cap.
fn frame_bytes(proto: &kerf_compiler::FuncProto, stack_size: u32, bc: &Bytecode) -> u64 {
    let nloc = proto.params.max(proto.n_locals) as u64;
    let mut max_argc: u64 = 0;
    let mut max_ncap: u64 = 0;
    for instr in &proto.code {
        match instr.op {
            Opcode::Call => max_argc = max_argc.max(instr.a as u64),
            Opcode::Perform => max_argc = max_argc.max(instr.b as u64),
            // W-VM-SUPERINSTR: the fused call's argc rides the b slot
            // (SI-2 — the Perform convention).
            Opcode::CallGlobal => max_argc = max_argc.max(instr.b as u64),
            Opcode::Closure => {
                let ncap = bc.funcs[instr.a as usize].captures.len() as u64;
                max_ncap = max_ncap.max(ncap);
            }
            _ => {}
        }
    }
    (nloc + stack_size as u64 + max_argc + max_ncap) * 16 + 192
}

/// The host-stack guard: 6 MiB of frames on the default 8 MiB stack
/// (overridable at cc time through `-DK_DEPTH_CAP=...`).
const K_STACK_BUDGET_BYTES: u64 = 6 * 1024 * 1024;

/// The C ABI type one extern scalar materializes as (W-3.2 §1.5
/// R-F4): `int` -> `int64_t` (the value model's i64), `bool` ->
/// `_Bool` (C99 keyword — self-contained, no include), `float` ->
/// `double` (IEEE-754 binary64).
fn c_type(ty: &kerf_core::ExternType) -> &'static str {
    match ty {
        kerf_core::ExternType::Int => "int64_t",
        kerf_core::ExternType::Bool => "_Bool",
        kerf_core::ExternType::Float => "double",
    }
}

fn proto_display_name(name: &Option<Symbol>) -> String {
    c_string(name.as_ref().map(Symbol::as_str).unwrap_or("#<anonymous>"))
}

/// Emit the complete C translation unit for a VERIFIED bytecode
/// product. Callers reach this through [`crate::emit_c`], which runs
/// `verify` first (fail-closed against hand-built or corrupted
/// input; r106 FIX-2 moved the entry-proto legality shapes — closure
/// over the entry proto, entry capture descriptors — into `verify`
/// itself, making it the single legality judge for every engine).
pub(crate) fn emit_verified(bc: &Bytecode) -> Result<String, EmitError> {
    // Depth analyses (the verify mirror — a verified product cannot
    // disagree; this is the defense-in-depth layer).
    let depths: Vec<ProtoDepth> = bc
        .funcs
        .iter()
        .map(depth::analyze)
        .collect::<Result<_, _>>()
        .map_err(|e| EmitError::DepthUnverified {
            pc: match e {
                depth::DepthError::Underflow { pc } => pc,
                depth::DepthError::Imbalance { pc, .. } => pc,
            },
        })?;

    let mut cx = Ctx::new();
    let version = env!("CARGO_PKG_VERSION");

    // ---- header + overridable defines ----
    let _ = writeln!(
        cx.out,
        "/* generated by kerf emit-c {version} — the C transpilation backend (chain-external; never part of the bootstrap chain) */"
    );
    let _ = writeln!(
        cx.out,
        "/* source product: {} protos, {} constants, {} globals, {} externs */",
        bc.funcs.len(),
        bc.consts.len(),
        bc.globals.len(),
        bc.externs.len()
    );
    let _ = writeln!(cx.out, "#define _POSIX_C_SOURCE 200809L");
    let _ = writeln!(cx.out, "#ifndef K_BUDGET");
    let _ = writeln!(
        cx.out,
        "#define K_BUDGET {}u /* mirrors kerf_vm::DEFAULT_BUDGET */",
        kerf_vm::DEFAULT_BUDGET
    );
    let _ = writeln!(cx.out, "#endif");
    let worst_frame = bc
        .funcs
        .iter()
        .zip(depths.iter())
        .map(|(f, d)| frame_bytes(f, d.stack_size, bc))
        .max()
        .unwrap_or(192);
    let depth_cap = (K_STACK_BUDGET_BYTES / worst_frame).clamp(1, kerf_vm::DEFAULT_BUDGET as u64);
    let _ = writeln!(cx.out, "#ifndef K_DEPTH_CAP");
    let _ = writeln!(
        cx.out,
        "#define K_DEPTH_CAP {depth_cap}u /* host-stack guard: worst frame ~{worst_frame}B */"
    );
    let _ = writeln!(cx.out, "#endif");

    // ---- embedded shim ----
    let _ = writeln!(cx.out);
    let _ = writeln!(
        cx.out,
        "/* ==== embedded host runtime shim (kerf_rt.h) ==== */"
    );
    cx.out.push_str(SHIM);
    cx.out.push('\n');

    // ---- extern declarations (W-3.2 — R-F4: zero name mangling;
    // the C symbol is the derived target-skin spelling) ----
    // Prototypes for every declared extern (the file mirrors the
    // declaration surface; an unreferenced prototype costs nothing
    // and demands no link-time definition). Wrappers and seeding
    // below cover only the referenced subset (an unused static
    // wrapper would warn under -Wall).
    if bc.externs.is_empty() {
        let _ = writeln!(
            cx.out,
            "/* no extern declarations (the FFI contract table is empty) */"
        );
    } else {
        let _ = writeln!(
            cx.out,
            "/* ==== extern declarations (W-3.2 — the caller links the definitions) ==== */"
        );
        for entry in &bc.externs {
            let params = if entry.params.is_empty() {
                "void".to_string()
            } else {
                entry
                    .params
                    .iter()
                    .map(c_type)
                    .collect::<Vec<_>>()
                    .join(", ")
            };
            let _ = writeln!(
                cx.out,
                "extern {} {}({}); /* kerf: `{}` */",
                c_type(&entry.ret),
                entry.c_symbol(),
                params,
                entry.name.as_str()
            );
        }
    }

    // ---- constant pool (strings and literal trees first) ----
    let _ = writeln!(cx.out, "/* ==== program data ==== */");
    let mut const_entries: Vec<String> = Vec::with_capacity(bc.consts.len());
    for lit in &bc.consts {
        const_entries.push(cx.const_entry(lit));
    }
    for line in &cx.string_lines {
        let _ = writeln!(cx.out, "{line}");
    }
    for line in &cx.lit_lines {
        let _ = writeln!(cx.out, "{line}");
    }
    if bc.consts.is_empty() {
        let _ = writeln!(
            cx.out,
            "/* the constant pool is empty; k_consts stays null (no push-const exists) */"
        );
    } else {
        let _ = writeln!(
            cx.out,
            "static const KConst k_const_table[{}] = {{",
            bc.consts.len()
        );
        for (i, entry) in const_entries.iter().enumerate() {
            if i + 1 < bc.consts.len() {
                let _ = writeln!(cx.out, "{entry},");
            } else {
                let _ = writeln!(cx.out, "{entry}");
            }
        }
        let _ = writeln!(cx.out, "}};");
    }

    // ---- proto functions ----
    for (fi, proto) in bc.funcs.iter().enumerate() {
        emit_proto(&mut cx, bc, fi, proto, &depths[fi]);
    }

    // ---- extern wrappers (W-3.2 — R-F1 scalar materialization at
    // the boundary; R-F2 the return is a fresh kerf value) ----
    // Emitted only for externs the program references (a name in the
    // global table): the wrapper marshals args by copy, calls the C
    // function through the emitted prototype, and wraps the return.
    // No KVm parameter — the scalar batch never allocates (the heap
    // protocol, a registered extension face, will grow one).
    let mut extern_map: std::collections::HashMap<Symbol, usize> = std::collections::HashMap::new();
    let referenced: Vec<&kerf_compiler::ExternEntry> = bc
        .externs
        .iter()
        .filter(|e| bc.globals.iter().any(|g| g == &e.name))
        .collect();
    for (w, entry) in referenced.iter().enumerate() {
        extern_map.insert(entry.name.clone(), w);
        let cname = entry.c_symbol();
        let argc = entry.params.len();
        let _ = writeln!(cx.out);
        let _ = writeln!(
            cx.out,
            "static KValue k_extern_{w}(uint32_t argc, KValue *args) {{"
        );
        let _ = writeln!(
            cx.out,
            "    if (argc != {argc}u) k_fail_arity({}, {argc}u, argc);",
            c_string(&cname)
        );
        for (pi, ty) in entry.params.iter().enumerate() {
            let (c_ty, extract) = match ty {
                kerf_core::ExternType::Int => ("int64_t", "k_as_int_arg"),
                kerf_core::ExternType::Bool => ("int", "k_as_bool_arg"),
                kerf_core::ExternType::Float => ("double", "k_as_float_arg"),
            };
            let _ = writeln!(
                cx.out,
                "    {c_ty} a{pi} = {extract}(args[{pi}], {});",
                c_string(&cname)
            );
        }
        let call_args = (0..argc)
            .map(|pi| format!("a{pi}"))
            .collect::<Vec<_>>()
            .join(", ");
        let wrap = match entry.ret {
            kerf_core::ExternType::Int => "k_int",
            kerf_core::ExternType::Bool => "k_bool",
            kerf_core::ExternType::Float => "k_float",
        };
        let _ = writeln!(
            cx.out,
            "    /* R-F2: the return value transfers to the caller (a fresh kerf value) */"
        );
        let _ = writeln!(
            cx.out,
            "    return {wrap}({}({call_args}));",
            entry.c_symbol()
        );
        let _ = writeln!(cx.out, "}}");
    }

    // ---- the one trampoline ----
    let _ = writeln!(cx.out);
    let _ = writeln!(
        cx.out,
        "/* ==== the single call trampoline (per-proto switch + builtins) ==== */"
    );
    let _ = writeln!(
        cx.out,
        "static KValue k_call(KVm *k, KValue callee, uint32_t argc, KValue *args) {{"
    );
    let _ = writeln!(cx.out, "    if (callee.tag == K_CLOSURE) {{");
    let _ = writeln!(
        cx.out,
        "        KClosureCell *c = K_CLO_AT(k, callee.as.ref);"
    );
    let _ = writeln!(cx.out, "        switch (c->proto) {{");
    for (fi, proto) in bc.funcs.iter().enumerate().skip(1) {
        let name = proto_display_name(&proto.name);
        let _ = writeln!(cx.out, "        case {fi}u: {{");
        let _ = writeln!(
            cx.out,
            "            if (argc != {}u) k_fail_arity({name}, {}u, argc);",
            proto.params, proto.params
        );
        let _ = writeln!(cx.out, "            k_enter(k);");
        let _ = writeln!(cx.out, "            KValue r_ = kf_{fi}(k, args, c->env);");
        let _ = writeln!(cx.out, "            k_leave(k);");
        let _ = writeln!(cx.out, "            return r_;");
        let _ = writeln!(cx.out, "        }}");
    }
    let _ = writeln!(
        cx.out,
        "        default: k_unreachable(\"closure proto dispatch\");"
    );
    let _ = writeln!(cx.out, "        }}");
    let _ = writeln!(cx.out, "    }} else if (callee.tag == K_BUILTIN) {{");
    let _ = writeln!(
        cx.out,
        "        return k_builtin_call(k, callee.as.bi, argc, args);"
    );
    if !referenced.is_empty() {
        let _ = writeln!(cx.out, "    }} else if (callee.tag == K_EXTERN) {{");
        let _ = writeln!(cx.out, "        switch (callee.as.ex) {{");
        for w in 0..referenced.len() {
            let _ = writeln!(
                cx.out,
                "        case {w}u: return k_extern_{w}(argc, args);"
            );
        }
        let _ = writeln!(
            cx.out,
            "        default: k_unreachable(\"extern dispatch\");"
        );
        let _ = writeln!(cx.out, "        }}");
    }
    let _ = writeln!(cx.out, "    }} else {{");
    let _ = writeln!(
        cx.out,
        "        k_fail(\"type mismatch: call callee must be a closure, builtin or extern function, got `%s`\", k_kind_name(callee.tag));"
    );
    let _ = writeln!(cx.out, "    }}");
    let _ = writeln!(cx.out, "}}");

    // ---- globals + main ----
    let _ = writeln!(cx.out);
    if bc.globals.is_empty() {
        let _ = writeln!(
            cx.out,
            "/* the global table is empty (hand-built entry-only product) */"
        );
    } else {
        let _ = writeln!(
            cx.out,
            "static KValue k_gstore[{}]; /* unbound until seeded or stored */",
            bc.globals.len()
        );
    }
    let _ = writeln!(cx.out, "int main(void) {{");
    let _ = writeln!(cx.out, "    static KVm k_vm;");
    let _ = writeln!(cx.out, "    KVm *k = &k_vm;");
    let _ = writeln!(cx.out, "    k_vm_init(k);");
    if !bc.consts.is_empty() {
        let _ = writeln!(cx.out, "    k_consts = k_const_table;");
    }
    if !bc.globals.is_empty() {
        let _ = writeln!(
            cx.out,
            "    for (uint32_t i = 0; i < {}u; i++) {{",
            bc.globals.len()
        );
        let _ = writeln!(cx.out, "        k_gstore[i].tag = K_UNBOUND;");
        let _ = writeln!(cx.out, "        k_gstore[i].as.bits = 0;");
        let _ = writeln!(cx.out, "    }}");
        let _ = writeln!(cx.out, "    k->globals = k_gstore;");
        let _ = writeln!(cx.out, "    k->nglobals = {}u;", bc.globals.len());
        for (gi, sym) in bc.globals.iter().enumerate() {
            if let Some(b) = Builtin::from_name(sym.as_str()) {
                let _ = writeln!(
                    cx.out,
                    "    k->globals[{gi}] = k_builtin_value({}); /* {} */",
                    builtin_code(b),
                    c_string(sym.as_str())
                );
            } else if let Some(w) = extern_map.get(sym) {
                let c_sym = bc
                    .externs
                    .iter()
                    .find(|e| &e.name == sym)
                    .map(|e| e.c_symbol())
                    .unwrap_or_else(|| sym.as_str().to_string());
                let _ = writeln!(
                    cx.out,
                    "    k->globals[{gi}] = k_extern_value({w}u); /* extern `{c_sym}` (W-3.2) */"
                );
            }
        }
    }
    let _ = writeln!(cx.out, "    KValue noargs_[1];");
    let _ = writeln!(cx.out, "    KValue nocap_[1];");
    let _ = writeln!(cx.out, "    k_enter(k);");
    let _ = writeln!(cx.out, "    KValue result_ = kf_0(k, noargs_, nocap_);");
    let _ = writeln!(cx.out, "    k_leave(k);");
    let _ = writeln!(cx.out, "    k_finish(k, result_);");
    let _ = writeln!(cx.out, "    return 0;");
    let _ = writeln!(cx.out, "}}");

    Ok(cx.out)
}

/// Emit one proto function into the context.
fn emit_proto(
    cx: &mut Ctx,
    bc: &Bytecode,
    fi: usize,
    proto: &kerf_compiler::FuncProto,
    d: &ProtoDepth,
) {
    let _ = writeln!(cx.out);
    let _ = writeln!(
        cx.out,
        "/* proto {fi}: params {} locals {} captures {} */",
        proto.params,
        proto.n_locals,
        proto.captures.len()
    );
    let _ = writeln!(
        cx.out,
        "static KValue kf_{fi}(KVm *k, KValue *kargs, KValue *kcap) {{"
    );
    let nloc = proto.params.max(proto.n_locals);
    if nloc == 0 {
        // No slot is ever addressed (verify bounds every local
        // access below n_locals) — a zero-length C array is illegal,
        // so the declaration vanishes entirely.
        let _ = writeln!(cx.out, "    (void)kargs;");
    } else {
        let _ = writeln!(cx.out, "    KValue locals[{nloc}];");
        for slot in 0..proto.params {
            let _ = writeln!(cx.out, "    locals[{slot}] = kargs[{slot}];");
        }
        for slot in proto.params..nloc {
            let _ = writeln!(cx.out, "    locals[{slot}] = k_nil_value();");
        }
    }
    if proto.captures.is_empty() {
        let _ = writeln!(cx.out, "    (void)kcap;");
    }
    if d.stack_size == 0 {
        // Nothing ever touches the operand stack (every producer
        // needs a slot) — same zero-length rule as locals: no
        // declaration at all.
    } else {
        let _ = writeln!(cx.out, "    KValue st[{}];", d.stack_size);
    }

    // Jump labels emitted only for targets of REACHABLE jumps (an
    // unreachable block's labels vanish with its skipped code; a
    // wrongly-classified block fails the C compile loudly).
    let mut targets: BTreeSet<u32> = BTreeSet::new();
    for (pc, instr) in proto.code.iter().enumerate() {
        if matches!(instr.op, Opcode::Jump | Opcode::JumpIfFalse) && d.depth_in.contains_key(&pc) {
            targets.insert(instr.a);
        }
    }
    // Block leaders (for the one-marker-per-unreachable-block rule).
    let mut leaders: BTreeSet<usize> = BTreeSet::new();
    leaders.insert(0);
    for (pc, instr) in proto.code.iter().enumerate() {
        if matches!(instr.op, Opcode::Jump | Opcode::JumpIfFalse) {
            leaders.insert(instr.a as usize);
        }
        if instr.op.is_terminator() && pc + 1 < proto.code.len() {
            leaders.insert(pc + 1);
        }
    }

    let is_entry = fi == 0;
    let mut skipping_dead = false;
    for (pc, instr) in proto.code.iter().enumerate() {
        if let Some(&depth) = d.depth_in.get(&pc) {
            skipping_dead = false;
            if targets.contains(&(pc as u32)) {
                let _ = writeln!(cx.out, "    L{pc}:");
            }
            emit_instr(cx, bc, *instr, pc, depth, is_entry);
        } else if !skipping_dead && leaders.contains(&pc) {
            skipping_dead = true;
            let _ = writeln!(
                cx.out,
                "    /* pc {pc}: unreachable block (skipped; fail-closed marker) */"
            );
            let _ = writeln!(
                cx.out,
                "    k_unreachable(\"unreachable block at pc {pc}\");"
            );
        }
    }
    // Every proto ends in a terminator (verify), so control never
    // falls past the last instruction; the return keeps the C
    // compiler satisfied on the unreachable path.
    let _ = writeln!(
        cx.out,
        "    k_unreachable(\"proto {fi} fell through its terminator\");"
    );
    let _ = writeln!(cx.out, "}}");
}

/// Emit one reachable instruction at entry depth `d`.
fn emit_instr(cx: &mut Ctx, bc: &Bytecode, instr: Instr, pc: usize, d: u32, is_entry: bool) {
    let out = &mut cx.out;
    let _ = writeln!(out, "    /* pc {pc}: {} */", instr.op.kind_name());
    let a = instr.a;
    let b = instr.b;
    match instr.op {
        Opcode::PushConst => {
            let _ = writeln!(out, "    st[{d}] = k_push_const(k, {a}u);");
        }
        Opcode::Pop => {
            // A pure consumer: the comment is the whole lowering (a
            // jump label before it still prefixes the next emitted
            // statement — fallthrough semantics are identical).
        }
        Opcode::Dup => {
            let _ = writeln!(out, "    st[{d}] = st[{}];", d - 1);
        }
        Opcode::Swap => {
            let lo = d - 2;
            let hi = d - 1;
            let _ = writeln!(
                out,
                "    {{ KValue t_ = st[{lo}]; st[{lo}] = st[{hi}]; st[{hi}] = t_; }}"
            );
        }
        Opcode::Call => {
            if a == 0 {
                // pops the callee only: result replaces it (d-1).
                let _ = writeln!(
                    out,
                    "    st[{}] = k_call(k, st[{}], 0u, NULL);",
                    d - 1,
                    d - 1
                );
            } else {
                let _ = writeln!(out, "    {{");
                let _ = write!(out, "        KValue ka_[{a}] = {{");
                for i in 0..a {
                    if i > 0 {
                        let _ = write!(out, ", ");
                    }
                    let _ = write!(out, " st[{}]", d - a - 1 + i);
                }
                let _ = writeln!(out, " }};");
                let _ = writeln!(
                    out,
                    "        st[{}] = k_call(k, st[{}], {a}u, ka_);",
                    d - a - 1,
                    d - 1
                );
                let _ = writeln!(out, "    }}");
            }
        }
        Opcode::Ret => {
            if is_entry {
                let _ = writeln!(out, "    k_fail(\"ret from entry frame at pc `{pc}`\");");
            } else {
                let _ = writeln!(out, "    return st[{}];", d - 1);
            }
        }
        Opcode::Closure => {
            let ncap = bc.funcs[a as usize].captures.len() as u32;
            if ncap == 0 {
                let _ = writeln!(out, "    st[{d}] = k_closure(k, {a}u, 0u, NULL);");
            } else {
                let _ = writeln!(out, "    {{");
                let _ = write!(out, "        KValue kcap_[{ncap}] = {{");
                for (i, source) in bc.funcs[a as usize].captures.iter().enumerate() {
                    if i > 0 {
                        let _ = write!(out, ", ");
                    }
                    match *source {
                        CaptureSource::Local(slot) => {
                            let _ = write!(out, " locals[{slot}]");
                        }
                        CaptureSource::Captured(k) => {
                            let _ = write!(out, " kcap[{k}]");
                        }
                    }
                }
                let _ = writeln!(out, " }};");
                let _ = writeln!(out, "        st[{d}] = k_closure(k, {a}u, {ncap}u, kcap_);");
                let _ = writeln!(out, "    }}");
            }
        }
        Opcode::Jump => {
            let _ = writeln!(out, "    goto L{a};");
        }
        Opcode::JumpIfFalse => {
            let _ = writeln!(out, "    if (!k_test_bool(k, st[{}])) goto L{a};", d - 1);
        }
        Opcode::MakePair => {
            let _ = writeln!(
                out,
                "    st[{}] = k_mk_pair(k, st[{}], st[{}]);",
                d - 2,
                d - 2,
                d - 1
            );
        }
        Opcode::Car => {
            let _ = writeln!(out, "    st[{}] = k_car(k, st[{}]);", d - 1, d - 1);
        }
        Opcode::Cdr => {
            let _ = writeln!(out, "    st[{}] = k_cdr(k, st[{}]);", d - 1, d - 1);
        }
        Opcode::LoadLocal => {
            let _ = writeln!(out, "    st[{d}] = locals[{a}];");
        }
        Opcode::LoadLocalConst => {
            // W-JIT-METHOD-T1 TJ-1: the fused copy pair lowers as
            // the two source statements composed — the local read
            // into st[d] (the LoadLocal lowering) then the pooled
            // constant into st[d+1] (the PushConst lowering); the
            // stack image matches the unfused pair bit-for-bit.
            let _ = writeln!(out, "    st[{d}] = locals[{a}];");
            let _ = writeln!(out, "    st[{}] = k_push_const(k, {b}u);", d + 1);
        }
        Opcode::StoreLocal => {
            let _ = writeln!(out, "    locals[{a}] = st[{}];", d - 1);
        }
        Opcode::LoadGlobal => {
            let name = c_string(bc.globals[a as usize].as_str());
            let _ = writeln!(out, "    st[{d}] = k_global_load(k, {a}u, {name});");
        }
        Opcode::CallGlobal => {
            // W-VM-SUPERINSTR: the fused load-global + call — the
            // callee loads into a temporary (k_global_load reports
            // the extern/unbound family exactly like the unfused
            // arm), the args stay at st[d-b .. d-1], and the result
            // lands at st[d-b] (SI-3: net -argc + 1).
            let name = c_string(bc.globals[a as usize].as_str());
            if b == 0 {
                let _ = writeln!(
                    out,
                    "    st[{d}] = k_call(k, k_global_load(k, {a}u, {name}), 0u, NULL);"
                );
            } else {
                let _ = writeln!(out, "    {{");
                let _ = writeln!(out, "        KValue kc_ = k_global_load(k, {a}u, {name});");
                let _ = write!(out, "        KValue ka_[{b}] = {{");
                for i in 0..b {
                    if i > 0 {
                        let _ = write!(out, ", ");
                    }
                    let _ = write!(out, " st[{}]", d - b + i);
                }
                let _ = writeln!(out, " }};");
                let _ = writeln!(out, "        st[{}] = k_call(k, kc_, {b}u, ka_);", d - b);
                let _ = writeln!(out, "    }}");
            }
        }
        Opcode::StoreGlobal => {
            let _ = writeln!(out, "    k_global_store(k, {a}u, st[{}]);", d - 1);
        }
        Opcode::LoadCaptured => {
            let _ = writeln!(out, "    st[{d}] = kcap[{a}];");
        }
        Opcode::Add | Opcode::Sub | Opcode::Mul | Opcode::Div => {
            let _ = writeln!(
                out,
                "    st[{}] = k_arith(k, {}, st[{}], st[{}]);",
                d - 2,
                arith_code(instr.op),
                d - 2,
                d - 1
            );
        }
        Opcode::PushHandler => {
            let _ = writeln!(out, "    k_handler_push(k, {a}u, st[{}]);", d - 1);
        }
        Opcode::PopHandler => {
            let _ = writeln!(out, "    k_handler_pop(k, {a}u, {pc}u);");
        }
        Opcode::Perform => {
            let name = c_string(bc.globals[a as usize].as_str());
            if b == 0 {
                let _ = writeln!(out, "    st[{d}] = k_perform(k, {a}u, {name}, 0u, NULL);");
            } else {
                let _ = writeln!(out, "    {{");
                let _ = write!(out, "        KValue ka_[{b}] = {{");
                for i in 0..b {
                    if i > 0 {
                        let _ = write!(out, ", ");
                    }
                    let _ = write!(out, " st[{}]", d - b + i);
                }
                let _ = writeln!(out, " }};");
                let _ = writeln!(
                    out,
                    "        st[{}] = k_perform(k, {a}u, {name}, {b}u, ka_);",
                    d - b
                );
                let _ = writeln!(out, "    }}");
            }
        }
        Opcode::Halt => {
            if d == 0 {
                let _ = writeln!(out, "    return k_nil_value();");
            } else {
                let _ = writeln!(out, "    return st[0];");
            }
        }
    }
}

#[cfg(test)]
mod tests {
    //! Emitter text-shape tests (FP1/FP2): key fragments of the
    //! generated C over real compile products and hand-built
    //! fixtures. The cc-driven behavioral face lives in the root
    //! integration tests (`c_backend_e2e_tests.rs`) — unit tests
    //! here never invoke a C compiler.

    use super::*;
    use kerf_compiler::{FuncProto, Instr};
    use kerf_span::{ByteOffset, ExpansionId, FileId, Span};

    fn span() -> Span {
        Span::new(FileId(0), ByteOffset(0), ByteOffset(1), ExpansionId::ROOT)
            .expect("test fixture span must be well-formed")
    }

    pub(crate) fn compile(source: &str) -> Bytecode {
        let forms = kerf_reader::read_target_program(FileId(0), source).expect("read");
        let items = kerf_expander::expand_program(&forms).expect("expand");
        kerf_compiler::compile_program(&items).expect("compile")
    }

    fn hand_built_entry(code: Vec<Instr>, consts: Vec<LiteralValue>) -> Bytecode {
        let mut proto = FuncProto::new(None, 0, 0);
        proto.code = code;
        proto.debug_info = vec![span(); proto.code.len()];
        Bytecode {
            consts,
            funcs: vec![proto],
            ..Default::default()
        }
    }

    #[test]
    fn fib_product_emits_the_expected_skeleton() {
        let bc = compile(
            "fn fib(n) { if ((n < 2)) { n } else { (fib((n - 1)) + fib((n - 2))) } }\ndefine(result, fib(6));",
        );
        let c = emit_verified(&bc).expect("emits");
        assert!(c.contains("static KValue kf_0(KVm *k, KValue *kargs, KValue *kcap)"));
        assert!(c.contains("static KValue kf_1(KVm *k, KValue *kargs, KValue *kcap)"));
        // W-VM-SUPERINSTR: every fib call site is a fused
        // call-global — the callee rides the kc_ temporary loaded by
        // k_global_load, then the shared k_call.
        assert!(
            c.contains("KValue kc_ = k_global_load(k,"),
            "the fused callee loads through the global face"
        );
        assert!(c.contains("k_call(k, kc_"), "the fused call rides k_call");
        assert!(
            c.contains("if (!k_test_bool(k, st["),
            "conditional branch lowers"
        );
        assert!(c.contains("goto L"), "jumps lower to gotos");
        assert!(
            c.contains("k_arith(k, KA_SUB, args[0], args[1])"),
            "compile-product arithmetic rides the builtin arm (the KA_ code face)"
        );
        assert!(
            c.contains("k_fail_arity(\"fib\", 1u, argc)"),
            "arity check names the proto"
        );
        assert!(
            c.contains("static KValue k_gstore["),
            "the globals store declares"
        );
        assert!(
            c.contains("k_builtin_value(KB_LT)"),
            "the < builtin seeds by code"
        );
        assert!(c.contains("return st[0];") || c.contains("return k_nil_value();"));
    }

    #[test]
    fn float_constants_ride_bit_patterns_never_decimal_text() {
        let bc = hand_built_entry(
            vec![
                Instr::with_a(Opcode::PushConst, 0),
                Instr::new(Opcode::Halt),
            ],
            vec![LiteralValue::Float(0.1)],
        );
        let c = emit_verified(&bc).expect("emits");
        assert!(
            c.contains("UINT64_C(0x3fb999999999999a)"),
            "0.1 must ride its exact bit pattern"
        );
        assert!(!c.contains(".as.bits = UINT64_C(0x0"));
    }

    #[test]
    fn string_constants_dedup_through_one_byte_array() {
        let lit = LiteralValue::String("hi".into());
        let bc = hand_built_entry(
            vec![
                Instr::with_a(Opcode::PushConst, 0),
                Instr::with_a(Opcode::PushConst, 1),
                Instr::new(Opcode::Pop),
                Instr::new(Opcode::Halt),
            ],
            vec![lit.clone(), lit],
        );
        let c = emit_verified(&bc).expect("emits");
        assert_eq!(c.matches("static const unsigned char kcs").count(), 1);
        assert!(c.contains("{0x68, 0x69}"), "byte arrays spell hex");
    }

    #[test]
    fn pair_constants_emit_post_order_literal_trees() {
        let pair = LiteralValue::Pair(Box::new(LiteralValue::Int(1)), Box::new(LiteralValue::Nil));
        let bc = hand_built_entry(
            vec![
                Instr::with_a(Opcode::PushConst, 0),
                Instr::new(Opcode::Halt),
            ],
            vec![pair],
        );
        let c = emit_verified(&bc).expect("emits");
        // The parent node numbers first but DEFINES last (post-order
        // file layout — a forward initializer reference is not C).
        assert!(c.contains("static const KLit klt1 = { .kind = 0, .as.i = INT64_C(1) };"));
        assert!(
            c.contains("static const KLit klt2 = { .kind = 4 };")
                || c.contains("static const KLit klt2 = { .kind = 4 }")
        );
        assert!(c.contains(
            "static const KLit klt0 = { .kind = 5, .as.pair.car = &klt1, .as.pair.cdr = &klt2 }"
        ));
        assert!(c.contains(".cells = 1u"), "one pair cell pre-charged");
    }

    #[test]
    fn depth_cap_is_worst_frame_adaptive_and_pinned() {
        let bc = compile("fn f(x) { x }\ndefine(result, f(1));");
        let c = emit_verified(&bc).expect("emits");
        assert!(
            c.contains("#ifndef K_DEPTH_CAP"),
            "the cap stays overridable"
        );
        assert!(
            c.contains("#define K_BUDGET 16777216u"),
            "the budget mirrors DEFAULT_BUDGET"
        );
    }
}

//! The semver twin parity harness (W-PKG-SELFHOST blade 2, part
//! one — w-pkg-selfhost-window.md §4 blade row 2): the package
//! manager's version algebra, `selfhost/v1/semver.ktf`, against
//! the Rust oracle `kerf_pkg::semver` through the full `.ktf` chain
//! on BOTH engines — the tenth selfhost twin, the second of the
//! kerf-pkg self-hosting family (K15: the differential oracle — the
//! twin and the oracle walk the same grammar space, the three-way
//! comparison (oracle == twin-vm == twin-eval) pins them decision
//! for decision).
//!
//! The twin rides the RS-1 byte-table channel with TWO channels —
//! `con_bytes` and `ver_bytes`, one injected table per input (the
//! `source_bytes` precedent generalized to a family). One drive
//! covers the oracle's whole public face:
//!
//! * `Version::parse` (the exact X.Y.Z triple),
//! * `Constraint::parse` (X.Y or X.Y.Z),
//! * `caret_satisfies` (the Cargo convention — 0.x bounds on the
//!   minor, >=1.x bounds on the major).
//!
//! The dump grammar, one line per face:
//!
//! ```text
//!     (ver 1.2.3)                         — the version face, ok
//!     ERR invalid version "1.2": expected the X.Y.Z form
//!     (con 0.2)                           — the constraint face
//!     caret=yes | caret=no | caret=na     — the caret face
//! ```
//!
//! The error axis renders the oracle's own `PkgError::BadVersion`
//! Display verbatim — `invalid version "{text}": {message}` — with
//! the message templates reproduced exactly (`expected the X.Y.Z
//! form`, `expected the X.Y or X.Y.Z form`,
//! `component "{part}" is not a number`; the failing component is
//! sliced from the same source on both sides through the shared
//! `span_text` discipline, so a drift between the renderings is
//! impossible by construction).
//!
//! Known mirror boundary (disclosed at w-pkg-selfhost-window §6,
//! the twin's source header): components in (i64::MAX, u64::MAX]
//! parse on the oracle and reject on the twin — the corpus excludes
//! that band, the twin reports it fail-closed.

use kerf_pkg::{Constraint, Version};
use kerf_vm::{Heap, Value};

use crate::bootstrap::micro_toml_parity::span_text;
use crate::bootstrap::vm_harness::{
    as_i64, as_str, drive_dual_engines, first_diff, need_fields, value_elems,
};

// ---------------------------------------------------------------------------
// The twin source embedding
// ---------------------------------------------------------------------------

/// The W-PKG-SELFHOST blade 2 twin, part one (r157): the semver
/// triple and caret-constraint family in its own target skin.
pub const SEMVER_TARGET_SOURCE: &str = include_str!("../../../../selfhost/v1/semver.ktf");

// ---------------------------------------------------------------------------
// The two-channel byte-table prefix
// ---------------------------------------------------------------------------

/// One RS-1 byte-table define on the target skin with a caller
/// chosen name (the `source_bytes` single-channel form generalized
/// to the two-channel semver drive): `define(name, quote((...)))`
/// with the payload one integer per byte; the empty source rides as
/// `quote(nil)`; a ONE-byte source rides the trailing-comma form
/// `quote((d,))` — the target skin's `(d)` groups (a bare datum)
/// while `(d,)` is the one-element list (the parser's own
/// convention, the `emit_target_datum` single-element arm).
fn byte_table_define(name: &str, source: &str) -> String {
    if source.is_empty() {
        return format!("define({name}, quote(nil));\n");
    }
    let bytes: Vec<String> = source.as_bytes().iter().map(|b| b.to_string()).collect();
    let tail = if bytes.len() == 1 { "," } else { "" };
    format!("define({name}, quote(({}{tail})));\n", bytes.join(", "))
}

// ---------------------------------------------------------------------------
// The oracle axis: the Rust semver face's dump
// ---------------------------------------------------------------------------

/// The oracle's normalized three-line dump: the version face, the
/// constraint face, the caret face.
pub fn semver_oracle_dump(con_text: &str, ver_text: &str) -> String {
    let mut out = String::new();
    let ver = Version::parse(ver_text);
    match &ver {
        Ok(v) => out.push_str(&format!("(ver {v})\n")),
        Err(e) => out.push_str(&format!("ERR {e}\n")),
    }
    let con = Constraint::parse(con_text);
    match &con {
        Ok(c) => out.push_str(&format!("(con {c})\n")),
        Err(e) => out.push_str(&format!("ERR {e}\n")),
    }
    match (&ver, &con) {
        (Ok(v), Ok(c)) => out.push_str(if c.caret_satisfies(*v) {
            "caret=yes\n"
        } else {
            "caret=no\n"
        }),
        _ => out.push_str("caret=na\n"),
    }
    out
}

// ---------------------------------------------------------------------------
// The .ktf side: decoding the twin's verdict
// ---------------------------------------------------------------------------

/// Render one semver error record — ("err" kind fs fe) — into the
/// oracle's own message line, slicing the named operand (the
/// failing component's text) from the channel's source while the
/// engine's heap is still alive. The face is the line's position
/// in the dump (line 1 = version, line 2 = constraint), never a
/// suffix — the oracle's Display is reproduced verbatim.
fn render_sv_error(kind: &str, fs: i64, fe: i64, text: &str) -> Result<String, String> {
    let message = match kind {
        "version-form" => "expected the X.Y.Z form".to_string(),
        "constraint-form" => "expected the X.Y or X.Y.Z form".to_string(),
        "not-a-number" => {
            let part = span_text(text, fs, fe, "semver component")?;
            format!("component \"{part}\" is not a number")
        }
        other => return Err(format!("harness defect: unknown semver kind `{other}`")),
    };
    Ok(format!("ERR invalid version \"{text}\": {message}"))
}

/// Decode one face's record — ("ok" triple-or-quad) | ("err" kind
/// fs fe) — into its dump line.
fn decode_sv_face(value: &Value, heap: &Heap, text: &str, face: &str) -> Result<String, String> {
    let elems = value_elems(value, heap).map_err(|err| format!("{face} chain: {err}"))?;
    need_fields(&elems, 2, face)?;
    let head = as_str(elems[0]).map_err(|err| format!("{face} tag: {err}"))?;
    if head == "ok" {
        let nums = value_elems(elems[1], heap)?;
        let maj = as_i64(nums[0])?;
        let min = as_i64(nums[1])?;
        if face == "version" {
            need_fields(&nums, 3, "version triple")?;
            let pat = as_i64(nums[2])?;
            Ok(format!("(ver {maj}.{min}.{pat})\n"))
        } else {
            need_fields(&nums, 4, "constraint quad")?;
            let has = as_i64(nums[2])?;
            let pat = as_i64(nums[3])?;
            if has == 1 {
                Ok(format!("(con {maj}.{min}.{pat})\n"))
            } else {
                Ok(format!("(con {maj}.{min})\n"))
            }
        }
    } else if head == "err" {
        need_fields(&elems, 4, "semver error record")?;
        let kind = as_str(elems[1]).map_err(|err| format!("semver kind: {err}"))?;
        let fs = as_i64(elems[2])?;
        let fe = as_i64(elems[3])?;
        Ok(format!("{}\n", render_sv_error(kind, fs, fe, text)?))
    } else {
        Err(format!("harness defect: unknown {face} tag `{head}`"))
    }
}

/// Decode the twin's `result` global — ("sv" version constraint
/// caret) — into the three-line dump.
fn decode_sv_verdict(
    value: &Value,
    heap: &Heap,
    con_text: &str,
    ver_text: &str,
) -> Result<String, String> {
    let elems = value_elems(value, heap).map_err(|err| format!("verdict chain: {err}"))?;
    need_fields(&elems, 4, "sv verdict")?;
    let head = as_str(elems[0]).map_err(|err| format!("verdict tag: {err}"))?;
    if head != "sv" {
        return Err(format!("harness defect: unknown verdict tag `{head}`"));
    }
    let mut out = String::new();
    out.push_str(&decode_sv_face(elems[1], heap, ver_text, "version")?);
    out.push_str(&decode_sv_face(elems[2], heap, con_text, "constraint")?);
    // The caret face: true | false | the string "n/a".
    let caret = &elems[3];
    match caret {
        Value::Bool(b) => out.push_str(if *b { "caret=yes\n" } else { "caret=no\n" }),
        Value::Str(s) if &**s == "n/a" => out.push_str("caret=na\n"),
        other => {
            return Err(format!(
                "harness defect: the caret face is neither bool nor n/a: {other:?}"
            ));
        }
    }
    Ok(out)
}

// ---------------------------------------------------------------------------
// The drive + comparison entries
// ---------------------------------------------------------------------------

/// The twin's two-axis dump (vm, eval): both engines run the
/// assembled `.ktf` (the two-channel prefix plus the twin source),
/// each axis rendered through the same decode.
pub fn semver_twin_dump(con_text: &str, ver_text: &str) -> Result<(String, String), String> {
    let assembled = format!(
        "{}{}{}",
        byte_table_define("con_bytes", con_text),
        byte_table_define("ver_bytes", ver_text),
        SEMVER_TARGET_SOURCE
    );
    let decode = |value: &Value, heap: &Heap| decode_sv_verdict(value, heap, con_text, ver_text);
    drive_dual_engines(
        "semver-parity-host",
        "semver twin",
        &assembled,
        decode,
        decode,
    )
}

/// The three-way comparison: twin-vm == twin-eval == oracle, on the
/// three-line dump grammar (per-face ok lines or the rendered error
/// keys). On mismatch the failure names the case and the first
/// differing line pair (the `failure_line` lineage).
pub fn semver_parity(case: &str, con_text: &str, ver_text: &str) -> Result<(), String> {
    let oracle = semver_oracle_dump(con_text, ver_text);
    let (vm_dump, eval_dump) = semver_twin_dump(con_text, ver_text)?;
    if let Some((vl, el)) = first_diff(&vm_dump, &eval_dump) {
        return Err(format!(
            "semver parity FAIL [{case}]: engines disagree: vm `{vl}` vs eval `{el}`"
        ));
    }
    if let Some((ol, tl)) = first_diff(&oracle, &vm_dump) {
        return Err(format!(
            "semver parity FAIL [{case}]: oracle `{ol}` vs twin `{tl}`"
        ));
    }
    Ok(())
}

// ---------------------------------------------------------------------------
// The curated case list
// ---------------------------------------------------------------------------

/// The curated twin cases as (case, constraint, version) triples:
/// the positive axis rides the caret matrix (the 0.x minor bound,
/// the 1.x major bound, the patch floors, cross-major rejections —
/// every combination exercises all three faces green); the negative
/// axis covers both faces' form errors (dot-count shapes) and the
/// not-a-number family (empty components, lone signs, a lone `+`,
/// embedded spaces, non-digit runs, negative signs, overflows past
/// i64::MAX — the u64 high band is the disclosed excluded boundary).
pub const SEMVER_TWIN_CASES: &[(&str, &str, &str)] = &[
    // ---- positive: the caret matrix ----
    ("caret-0x-minor-floor", "0.2", "0.2.0"),
    ("caret-0x-minor-eq-patch-high", "0.2", "0.2.99"),
    ("caret-0x-minor-bump-reject", "0.2", "0.3.0"),
    ("caret-0x-patch-floor-met", "0.1.5", "0.1.5"),
    ("caret-0x-patch-floor-below", "0.1.5", "0.1.4"),
    ("caret-1x-high-minor", "1.2", "1.9.3"),
    ("caret-1x-major-boundary", "1.2", "2.0.0"),
    ("caret-1x-lower-bound", "1.2", "1.1.9"),
    ("caret-1x-exact-floor", "1.2.3", "1.2.3"),
    ("caret-1x-floor-below", "1.2.3", "1.2.2"),
    ("caret-zeros", "0.0", "0.0.0"),
    ("caret-leading-zeros", "01.02", "01.02.03"),
    // ---- negative: the version face ----
    ("ver-two-parts", "0.2", "1.2"),
    ("ver-four-parts", "0.2", "1.2.3.4"),
    ("ver-lone", "0.2", "1"),
    ("ver-empty", "0.2", ""),
    ("ver-non-numeric", "0.2", "1.x.3"),
    ("ver-neg-component", "0.2", "-1.2.3"),
    ("ver-empty-mid", "0.2", "1..2"),
    ("ver-empty-lead", "0.2", ".1.2"),
    ("ver-empty-tail", "0.2", "1.2."),
    ("ver-plus-alone", "0.2", "+.2.3"),
    ("ver-space-mid", "0.2", "1 .2.3"),
    ("ver-space-tail", "0.2", "1.2.3 "),
    // ---- negative: the constraint face ----
    ("con-lone", "1", "1.2.3"),
    ("con-word", "latest", "1.2.3"),
    ("con-four-parts", "1.2.3.4", "1.2.3"),
    ("con-non-numeric", "1.x", "1.2.3"),
    ("con-empty", "", "1.2.3"),
    ("con-neg-component", "-1.2", "1.2.3"),
    ("con-plus-alone", "+.2", "1.2.3"),
    ("con-empty-mid", "1..2", "1.2.3"),
    ("con-empty-lead", ".1.2", "1.2.3"),
    ("con-empty-tail", "1.2.", "1.2.3"),
    ("con-space-mid", "1 .2", "1.2.3"),
    ("con-word-dotted", "lat.est", "1.2.3"),
];

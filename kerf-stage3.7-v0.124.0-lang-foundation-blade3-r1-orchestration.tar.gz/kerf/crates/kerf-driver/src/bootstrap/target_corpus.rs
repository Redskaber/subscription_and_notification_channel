//! The step-3 corpus-translation harness (switch-window-plan §1
//! step 3, stage0.md §9.96): the target-skin twins of the selfhost
//! injection contracts.
//!
//! The five `selfhost/v1/*.ktf` files each consume one
//! host-injected global (the byte table, the token records, the
//! form records, the item records) and produce one product global
//! — the RS-1/EX-1/CP injection family. This module provides the
//! same injection data on the target skin, so the parity tests can
//! drive the `.ktf` twins through the identical pipeline and
//! compare against the Rust engines (the BS-A seed-chain oracle:
//! the seed-skin originals were removed at r104 — E5 batch 3 — and
//! `read_program`/`expand_program`/`compile_program` remain the
//! tree truth sources of each segment).
//!
//! Single-source discipline: the DATA comes from the S-expr prefix
//! builders verbatim (`byte_table_prefix`, `token_table_prefix`,
//! `forms_stream_prefix`, `items_stream_prefix`); only the SKIN is
//! transcoded here. Every transcoded prefix is round-trip checked
//! against the real target reader — the emitted text must read
//! back to the identical Stx tree (the naming guard: a datum the
//! target vocabulary cannot spell is a harness defect, never a
//! silent rename).
//!
//! r122 split note (the user instruction-① bootstrap-file
//! unification): the target-skin SPELLING contract now lives at the
//! crate root (`crate::target_skin` — a production contract the
//! bridge and the diagnostics consume); this module keeps the twin
//! embeddings, the prefix assembly and the rich-compile faces.

use kerf_compiler::Bytecode;
use kerf_core::ModuleItem;

use kerf_reader::read_target_program;
use kerf_span::FileId;
use kerf_syntax::StxDatum;
use kerf_syntax::SyntaxObject;
use kerf_vm::{Heap, Value};

use crate::bootstrap::compiler_parity::RichCompileRun;
use crate::bootstrap::compiler_parity::{
    dump_ktf_section, items_stream_prefix, rebuild_bytecode, rebuild_compile_error,
};
use crate::bootstrap::expander_parity::forms_stream_prefix;
use crate::bootstrap::vm_harness::KtfVerdict;
use crate::bootstrap::vm_harness::byte_table_prefix;
use crate::bootstrap::vm_harness::{decode_tagged, drive_dual_engines};
use crate::pipeline;
use crate::target_skin::{emit_target_datum, target_skin_spelling};

/// The target-skin macro library twin (`selfhost/v1/macro.ktf`;
/// the Rust `expand_program` remains the oracle — BS-A).
pub const MACRO_TARGET_SOURCE: &str = include_str!("../../../../selfhost/v1/macro.ktf");
/// The target-skin expander twin (`selfhost/v1/expander.ktf`; the
/// Rust `expand_program` remains the oracle — BS-A).
pub const EXPANDER_TARGET_SOURCE: &str = include_str!("../../../../selfhost/v1/expander.ktf");
/// The target-skin compiler twin (`selfhost/v1/compiler.ktf` — the
/// fully self-hosted segment: gate B bytecode equality plus the
/// three-phase fixpoint; the Rust `compile_program` remains the
/// oracle — BS-A).
pub const COMPILER_TARGET_SOURCE: &str = include_str!("../../../../selfhost/v1/compiler.ktf");
/// The target-skin HM inference twin (`selfhost/v1/infer.ktf` — the
/// W-HM-TWIN segment-three face; the Rust `infer_module` remains
/// the oracle — BS-A).
pub const INFER_TARGET_SOURCE: &str = include_str!("../../../../selfhost/v1/infer.ktf");
/// The target-skin conservative-checker twin (`selfhost/v1/typecheck.ktf`
/// — the W-HM-TWIN segment-three check face; the Rust `check_module`
/// remains the oracle — BS-A).
pub const TYPECHECK_TARGET_SOURCE: &str = include_str!("../../../../selfhost/v1/typecheck.ktf");
/// The target-skin TARGET-lexer twin (`selfhost/v1/target-lexer.ktf`
/// — the W-TGT-READ-TWIN blade 1 segment: the target skin's own
/// lexical face as a kerf program; the Rust `lex_target` remains
/// the oracle — BS-A).
pub const TARGET_LEXER_TARGET_SOURCE: &str =
    include_str!("../../../../selfhost/v1/target-lexer.ktf");

/// The target-skin parser twin (the W-TGT-READ-TWIN blade 2 source
/// — the ninth selfhost twin, `selfhost/v1/target-parser.ktf`).
pub const TARGET_PARSER_TARGET_SOURCE: &str =
    include_str!("../../../../selfhost/v1/target-parser.ktf");

/// The assembled target-skin expander (the MX-2 twin: the macro
/// library prepended to the expander body, one program) at the
/// default work budget (the verification faces' arm — the oracle
/// rides the same default, so the parity keys stay comparable).
pub fn assembled_expander_target_source() -> String {
    assembled_expander_target_source_with_limit(kerf_expander::EXPANSION_LIMIT)
}

/// The assembled expander at one explicit work budget (the step-④
/// expand segment's budget-mirroring face — the twin's `ex_limit`
/// global must carry the process's effective expansion limit, the
/// `tp_limit` prefix precedent: an over-budget source rejects with
/// the same key on both positions, the rollback band's parity
/// obligation).
pub fn assembled_expander_target_source_with_limit(limit: usize) -> String {
    format!("define(ex_limit, {limit});\n{MACRO_TARGET_SOURCE}\n{EXPANDER_TARGET_SOURCE}")
}

/// The assembled compiler twin at the default compile-depth budget
/// (the verification faces' arm — the oracle rides the same default,
/// so the parity keys stay comparable; the r148 `co_limit`
/// parameterization, the `ex_limit` form carried to the compile
/// segment).
pub fn assembled_compiler_target_source() -> String {
    assembled_compiler_target_source_with_limit(kerf_compiler::COMPILE_DEPTH_LIMIT)
}

/// The assembled compiler twin at one explicit compile-depth budget
/// (the step-④ compile segment's budget-mirroring face — the twin's
/// `co_limit` global must carry the process's effective
/// `KERF_COMPILE_DEPTH_LIMIT`, the `ex_limit` prefix precedent: an
/// over-depth tree rejects with the same key on both positions, the
/// rollback band's parity obligation).
pub fn assembled_compiler_target_source_with_limit(limit: usize) -> String {
    format!("define(co_limit, {limit});\n{COMPILER_TARGET_SOURCE}")
}

/// Transcode one `(define NAME (quote DATA))` S-expr prefix into
/// the target skin: `define(NAME', quote(DATA'));` — then
/// round-trip check the emission through the real target reader
/// (the naming guard: the transcoded prefix must read back to the
/// byte-identical Stx display).
///
/// The r151 single-skin rewrite: the S-expression reader that used
/// to carry the prefix extraction left the tree with the
/// W-SEXP-RETIRE scaffold, so the channel carries its own bounded
/// parser over the closed prefix grammar (symbols, ints, strings,
/// nested lists, `nil`) — fail-closed on anything outside that
/// grammar, the same harness-defect discipline as before. The
/// naming guard survives unchanged: the emission still round-trips
/// through the real target reader.
pub(crate) fn transcode_quoted_define(prefix: &str) -> String {
    let mut parser = PrefixParser {
        text: prefix.as_bytes(),
        pos: 0,
    };
    let forms = parser.parse_program();
    assert!(
        !forms.is_empty(),
        "harness defect: the prefix is at least one define form"
    );
    // Blade 2 (GZ-2): the prefix is a FAMILY of define forms (the
    // forms stream + the struct accessor-name table) — one output
    // define per input, each through the same (define NAME (quote
    // DATA)) shape and the same naming guard.
    let mut out = String::with_capacity(prefix.len() + 16);
    for form in &forms {
        let items = match form {
            PrefixDatum::List(items) => items,
            _ => panic!("harness defect: the prefix form is a list"),
        };
        assert_eq!(
            items.len(),
            3,
            "harness defect: the prefix form is (define NAME (quote DATA))"
        );
        let name = match &items[1] {
            PrefixDatum::Symbol(symbol) => target_skin_spelling(symbol),
            _ => panic!("harness defect: the define name is a symbol"),
        };
        let quoted = match &items[2] {
            PrefixDatum::List(quote_items) => quote_items,
            _ => panic!("harness defect: the define value is a quote form"),
        };
        assert_eq!(
            quoted.len(),
            2,
            "harness defect: the quote form takes one datum"
        );
        out.push_str("define(");
        out.push_str(&name);
        out.push_str(", quote(");
        emit_target_datum(&to_stx_datum(&quoted[1]), &mut out);
        out.push_str("));\n");
    }
    // The naming guard: the emission must read back to the identical
    // tree — an unrepresentable name is a harness defect, never a
    // silent rename.
    let read_back = read_target_program(FileId(0), &out)
        .unwrap_or_else(|e| panic!("harness defect: the transcoded prefix must read: {e}"));
    assert_eq!(
        read_back.len(),
        forms.len(),
        "harness defect: the transcoded prefix is one form per input"
    );
    // The comparison rides the Stx DISPLAY (span-free) — the r151
    // rewrite's whole-object equality dragged synthetic zero spans
    // into the guard and broke every consumer (the naming guard
    // protects names and structure, never span identity).
    for (i, form) in forms.iter().enumerate() {
        assert_eq!(
            read_back[i].datum.to_string(),
            to_stx_datum(form).to_string(),
            "harness defect: the transcoded prefix must round-trip to the identical tree"
        );
    }
    out
}

/// One datum of the closed injection-prefix grammar (the bounded
/// set every `*_prefix` builder emits: symbols, ints, floats,
/// bools, strings, nested lists; `nil` rides as a symbol).
#[derive(Debug, Clone, PartialEq)]
enum PrefixDatum {
    Symbol(String),
    Int(i64),
    Float(f64),
    Bool(bool),
    Str(String),
    List(Vec<PrefixDatum>),
}

/// The Stx-tree projection of one prefix datum (the bridge the
/// naming guard compares against — the real `SyntaxObject` the
/// target reader produced).
fn to_stx_datum(datum: &PrefixDatum) -> StxDatum {
    match datum {
        PrefixDatum::Symbol(s) => StxDatum::Symbol(
            kerf_span::Symbol::new(s).expect("harness defect: prefix symbol must intern"),
        ),
        PrefixDatum::Int(v) => StxDatum::Int(*v),
        PrefixDatum::Float(v) => StxDatum::Float(*v),
        PrefixDatum::Bool(v) => StxDatum::Bool(*v),
        PrefixDatum::Str(s) => StxDatum::String(s.as_str().into()),
        PrefixDatum::List(items) => StxDatum::List(
            items
                .iter()
                .map(|item| kerf_syntax::SyntaxObject {
                    datum: to_stx_datum(item),
                    span: kerf_span::Span::new(
                        FileId(0),
                        kerf_span::ByteOffset(0),
                        kerf_span::ByteOffset(0),
                        kerf_span::ExpansionId::ROOT,
                    )
                    .expect("harness defect: zero span is well-ordered"),
                    phase: kerf_syntax::Phase::Runtime,
                    scopes: kerf_syntax::ScopeSet::new(),
                })
                .collect(),
        ),
    }
}

/// The bounded parser over the prefix grammar — fail-closed on
/// anything outside it (a harness defect, never a silent
/// misparse).
struct PrefixParser<'a> {
    text: &'a [u8],
    pos: usize,
}

impl PrefixParser<'_> {
    fn skip_ws(&mut self) {
        while self.pos < self.text.len() && self.text[self.pos].is_ascii_whitespace() {
            self.pos += 1;
        }
    }

    fn parse_program(&mut self) -> Vec<PrefixDatum> {
        let mut forms = Vec::new();
        loop {
            self.skip_ws();
            if self.pos >= self.text.len() {
                return forms;
            }
            forms.push(self.parse_datum());
        }
    }

    fn parse_datum(&mut self) -> PrefixDatum {
        self.skip_ws();
        match self.text.get(self.pos) {
            Some(b'(') => {
                self.pos += 1;
                let mut items = Vec::new();
                loop {
                    self.skip_ws();
                    match self.text.get(self.pos) {
                        Some(b')') => {
                            self.pos += 1;
                            return PrefixDatum::List(items);
                        }
                        None => panic!("harness defect: unterminated prefix list"),
                        _ => items.push(self.parse_datum()),
                    }
                }
            }
            Some(b'"') => {
                // The escape set is exactly `encode_string_literal`'s.
                self.pos += 1;
                let mut out = String::new();
                loop {
                    match self.text.get(self.pos) {
                        Some(b'\\') => {
                            let esc = self
                                .text
                                .get(self.pos + 1)
                                .copied()
                                .unwrap_or_else(|| panic!("harness defect: dangling escape"));
                            match esc {
                                b'"' => out.push('"'),
                                b'\\' => out.push('\\'),
                                b'n' => out.push('\n'),
                                b't' => out.push('\t'),
                                b'r' => out.push('\r'),
                                other => panic!(
                                    "harness defect: unknown prefix escape `\\{}`",
                                    other as char
                                ),
                            }
                            self.pos += 2;
                        }
                        Some(b'"') => {
                            self.pos += 1;
                            return PrefixDatum::Str(out);
                        }
                        Some(&b) => {
                            out.push(b as char);
                            self.pos += 1;
                        }
                        None => panic!("harness defect: unterminated prefix string"),
                    }
                }
            }
            Some(_) => {
                let start = self.pos;
                while self.pos < self.text.len()
                    && !self.text[self.pos].is_ascii_whitespace()
                    && !matches!(self.text[self.pos], b'(' | b')' | b'"')
                {
                    self.pos += 1;
                }
                let atom = std::str::from_utf8(&self.text[start..self.pos])
                    .unwrap_or_else(|_| panic!("harness defect: non-utf8 prefix atom"));
                if atom == "#t" {
                    PrefixDatum::Bool(true)
                } else if atom == "#f" {
                    PrefixDatum::Bool(false)
                } else if let Ok(v) = atom.parse::<i64>() {
                    PrefixDatum::Int(v)
                } else if let Ok(v) = atom.parse::<f64>() {
                    PrefixDatum::Float(v)
                } else {
                    PrefixDatum::Symbol(atom.to_string())
                }
            }
            None => panic!("harness defect: prefix ends mid-datum"),
        }
    }
}

/// The byte-table prefix on the target skin (`source_bytes`).
pub fn target_byte_table_prefix(source: &str) -> String {
    transcode_quoted_define(&byte_table_prefix(source))
}

// ---------- the datum spellability face (the r104 composed target
// chain's junction-2 data boundary) ----------

/// Can one datum ride the target skin's LITERAL face? The one
/// value-class boundary: a negative integer whose positive part
/// exceeds `i64::MAX` — i.e. exactly `i64::MIN` — cannot (the
/// target lexer applies the sign after parsing the magnitude, so
/// the bare magnitude `9223372036854775808` overflows `i64` before
/// the sign ever applies; every other negative integer and every
/// negative float reads back fine). This is the r103
/// exception-ledger boundary (a negative literal with no positive
/// counterpart — the corpus face carries those cases through
/// arithmetic-composition twins, switch-window-plan §5.6.2),
/// instantiated on the junction-2 data-injection face: form-record
/// data carrying an `i64::MIN` datum has NO target-skin text, so
/// the composed target chain classifies the case at the boundary
/// instead of silently re-spelling it (§2.3 report-don't-hide).
pub fn datum_target_spellable(datum: &StxDatum) -> bool {
    match datum {
        // The single value-class boundary: i64::MIN (the magnitude
        // 2^63 overflows the positive domain before the sign).
        StxDatum::Int(v) => *v != i64::MIN,
        StxDatum::Float(_) | StxDatum::Bool(_) | StxDatum::String(_) | StxDatum::Symbol(_) => true,
        StxDatum::List(items) => items.iter().all(|i| datum_target_spellable(&i.datum)),
    }
}

/// Do all of a form stream's datums ride the target skin's literal
/// face? (The junction-2 feed's spellability precheck — one walk,
/// never a try-and-panic.)
pub fn forms_target_spellable(forms: &[SyntaxObject]) -> bool {
    forms.iter().all(|f| datum_target_spellable(&f.datum))
}

/// The form-record prefix on the target skin (`forms`).
pub fn target_forms_stream_prefix(forms: &[SyntaxObject]) -> String {
    transcode_quoted_define(&forms_stream_prefix(forms))
}

/// The item-record prefix on the target skin (`items`).
pub fn target_items_stream_prefix(items: &[ModuleItem]) -> String {
    transcode_quoted_define(&items_stream_prefix(items))
}

// ---------- the step-4 production bridge (switch-window-plan §1) ----------

/// Read one target-skin source through the BOOTSTRAP front end
/// (switch-window-plan §1 step 4 — the production bridge): the new
/// reader parses the text, the shared spine expands and loads it.
/// This is the `.ktf` chain's entry into the bootstrap composition
/// — the twin of reading a seed-skin source through the seed reader,
/// and the exact face the step-4 fixpoint drives its own source
/// through (stage0.md §9.30.4: "the target-syntax Reader compiles
/// itself" starts here).
///
/// `Err` carries the classified front-end rejection (the harness
/// discipline — reader/expand/loader failures are reported, never a
/// panic).
pub fn read_target_source_for_bootstrap(
    name: &str,
    source: &str,
) -> Result<Vec<ModuleItem>, String> {
    // The SEED/ORACLE pin (the step-④ dual-chain decoupling, ALL
    // THREE segments): this bridge is the Rust production-bridge
    // oracle arm of the fixpoint purity legs ("the twin front end ==
    // the Rust production bridge") — it must ride the Rust reader,
    // the Rust expander, AND the Rust checkers explicitly, never
    // the switched production positions, or the differential
    // collapses into a self-comparison (detection power zero); the
    // check pin is the r147 extension (a twin-position check here
    // would run the checker twins on the purity leg's own inputs —
    // the same collapse on the checking axis).
    let mut session = crate::session::Session::with_segments(
        crate::read_segment::ReadSegment::Rust,
        crate::expand_segment::ExpandSegment::Rust,
        crate::check_segment::CheckSegment::Rust,
        crate::compile_segment::CompileSegment::Rust,
    );
    match pipeline::parse_target(&mut session, name, source) {
        Ok(program) => Ok(program.items),
        Err(diags) => Err(format!(
            "the bootstrap front end rejected the target source: {diags:?}"
        )),
    }
}

/// The target-skin rich compile, dual engines — the step-4 twin
/// of the retired seed-skin rich compile (its original
/// left the tree at the r104 E5 teardown): the same assembled
/// target program parsed by the NEW reader, driven through BOTH
/// engines with the verdict texts compared by the caller (the
/// fixpoint's C(S) and C(C(S)) phases ride this face — the
/// W-REC-DEPTH blade-1 retirement removed the old VM-only bracket:
/// the self-applied assembly's per-element recursion rides the
/// evaluator's heap activation stack now, budget-governed).
pub fn ktf_compile_rich(
    items: &[ModuleItem],
    compiler_target_source: &str,
) -> Result<RichCompileRun, String> {
    // The compile twin's work budget rides the assembly prefix at
    // the DEFAULT depth (this is a verification face — deterministic,
    // never the process env; the `ex_limit` assembled-default
    // precedent). The twin hard-requires `co_limit`: an assembly
    // that omits the define fails loudly at the first depth check
    // (unbound — fail-closed, never a silent default).
    let prefix = format!(
        "{}\ndefine(co_limit, {});",
        target_items_stream_prefix(items),
        kerf_compiler::COMPILE_DEPTH_LIMIT
    );
    let assembled = format!("{prefix}\n{compiler_target_source}");
    let decode_vm_rich =
        |value: &Value,
         heap: &Heap|
         -> Result<(KtfVerdict<kerf_compiler::CompileError>, Option<Bytecode>), String> {
            let verdict = decode_tagged(value, heap, dump_ktf_section, rebuild_compile_error)?;
            let rebuilt = match &verdict {
                KtfVerdict::Tree(_) => Some(rebuild_bytecode(value, heap)?),
                KtfVerdict::Error(_) => None,
            };
            Ok((verdict, rebuilt))
        };
    let decode_plain =
        |value: &Value, heap: &Heap| -> Result<KtfVerdict<kerf_compiler::CompileError>, String> {
            decode_tagged(value, heap, dump_ktf_section, rebuild_compile_error)
        };
    let ((vm_verdict, rebuilt), eval_verdict) = drive_dual_engines(
        "target-compiler-parity-host",
        "target compiler",
        &assembled,
        decode_vm_rich,
        decode_plain,
    )?;
    Ok(RichCompileRun {
        vm_text: vm_verdict.text(),
        eval_text: eval_verdict.text(),
        bytecode: rebuilt,
    })
}

// ---------- the gate-B bytecode face on the production-chain skin ----------

/// The gate-B bytecode face (the r104 E5 batch-3 carry; the r151
/// single-skin retarget — the retired seed reader swapped for the
/// target reader): the source reads through the oracle front end,
/// the items compile through the oracle, and the `.ktf` compiler
/// twin's REBUILT product (both engines, through the production
/// bridge) must equal the oracle's own compilation byte-for-byte —
/// the `Bytecode: PartialEq` gate with the descriptor tables
/// included.
pub fn gate_b_bytecode(case: &str, source: &str) -> Result<(), String> {
    let forms = kerf_reader::read_target_program(FileId(0), source)
        .map_err(|err| format!("gate B [{case}]: the reader rejected the source: {err}"))?;
    let oracle_items = kerf_expander::expand_program(&forms)
        .map_err(|err| format!("gate B [{case}]: the oracle rejected the source: {err}"))?;
    kerf_expander::load_program(&oracle_items)
        .map_err(|err| format!("gate B [{case}]: the oracle loader rejected: {err}"))?;
    let bc_oracle = kerf_compiler::compile_program(&oracle_items)
        .map_err(|err| format!("gate B [{case}]: oracle compile failed: {err}"))?;
    let run = ktf_compile_rich(&oracle_items, COMPILER_TARGET_SOURCE)
        .map_err(|err| format!("gate B [{case}]: {err}"))?;
    if run.vm_text != run.eval_text {
        return Err(format!(
            "gate B [{case}]: engines disagree: vm `{}` vs eval `{}`",
            run.vm_text, run.eval_text
        ));
    }
    let bc = run.bytecode.ok_or_else(|| {
        format!(
            "gate B [{case}]: the .ktf compiler rejected: {}",
            run.vm_text
        )
    })?;
    if bc == bc_oracle {
        Ok(())
    } else {
        Err(format!(
            "gate B [{case}]: bytecode drift (oracle {} protos / ktf {} protos)",
            bc_oracle.funcs.len(),
            bc.funcs.len()
        ))
    }
}

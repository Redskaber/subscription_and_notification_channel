//! The resolver twin parity harness (W-PKG-SELFHOST blade 3, part
//! two — w-pkg-selfhost-window.md §4 blade row 3b): the package
//! manager's dependency-graph resolver, the five-piece composed
//! program `micro-toml.ktf + semver.ktf + manifest.ktf +
//! lockfile.ktf + resolve.ktf`, against the Rust oracle
//! `kerf_pkg::resolve_with_limit` through the full `.ktf` chain on
//! BOTH engines (K15: the differential oracle).
//!
//! The fixtures are REAL trees: each case writes its directories
//! under a fresh temp root, the oracle walks the filesystem, and
//! the twin rides the SAME enumeration the kp shell bridge
//! performs in production (one read site, one io-message capture —
//! the two arms' inputs are identical by construction).
//!
//! The dump grammar:
//!
//! ```text
//!     OK
//!     name version (source)      — one line per package, deps first
//!     LOCK
//!     <the lockfile text>        — byte-for-byte
//!     ERR <the PkgError Display> — the rejection face
//! ```
//!
//! The comparison is three-way (oracle == twin-vm == twin-eval,
//! line-for-line) over the full family: the positive walks (single
//! package, chains, the diamond, deep chains, name-sorted
//! multi-deps, nested sources, canonical version re-render) and
//! the rejection families (the cycle tribe, the missing-directory
//! tribe, the name-mismatch and manifest-rejection pass-throughs,
//! the io traps, the root-read faces, the diamond conflicts —
//! including the sorted-key iteration proof — and the depth cap).

use std::path::{Path, PathBuf};

use kerf_pkg::resolve_with_limit;
use kerf_vm::{Heap, Value};

use crate::bootstrap::vm_harness::{drive_dual_engines, first_diff};
use crate::pkg_selfhost::{
    DirEntry, RESOLVE_TARGET_SOURCE, TwinOutcome, decode_rs_verdict, enumerate_table,
    resolve_twin_program,
};

// ---------------------------------------------------------------------------
// The fixture spec + the real-tree builder
// ---------------------------------------------------------------------------

/// One directory's fixture content.
pub enum RsContent {
    /// A manifest with this text.
    Text(&'static str),
    /// The directory exists, `kerf.toml` does not.
    NoManifest,
    /// `kerf.toml` is a directory — the read fails with the real io
    /// message (`Is a directory`, captured at the one read site).
    IoTrap,
    /// The path is a FILE — absent from the table (a dependency
    /// naming it hits `dep-dir-not-found`, the `is_dir()` face).
    File,
}

/// One parity case: the depth cap plus the directory spec.
pub struct RsCase {
    /// The case name (the failure message's key).
    pub name: &'static str,
    /// The depth cap both arms run under.
    pub limit: u32,
    /// The directories: `(rel-path, content)` — `.` is the root.
    pub dirs: Vec<(&'static str, RsContent)>,
}

/// Build the case's real tree under a fresh temp root.
fn build_fixture(case: &RsCase) -> PathBuf {
    let dir = std::env::temp_dir().join(format!(
        "kerf-rs-parity-{}-{}",
        std::process::id(),
        case.name
    ));
    let _ = std::fs::remove_dir_all(&dir);
    std::fs::create_dir_all(&dir).expect("fixture root creates");
    for (rel, content) in &case.dirs {
        let path = dir.join(rel);
        match content {
            RsContent::Text(text) => {
                std::fs::create_dir_all(&path).expect("package dir creates");
                std::fs::write(path.join("kerf.toml"), text).expect("manifest writes");
            }
            RsContent::NoManifest => {
                std::fs::create_dir_all(&path).expect("package dir creates");
            }
            RsContent::IoTrap => {
                std::fs::create_dir_all(&path).expect("package dir creates");
                std::fs::create_dir_all(path.join("kerf.toml")).expect("io trap creates");
            }
            RsContent::File => {
                if let Some(parent) = path.parent() {
                    std::fs::create_dir_all(parent).expect("parent creates");
                }
                std::fs::write(&path, "not a directory").expect("file trap writes");
            }
        }
    }
    dir
}

// ---------------------------------------------------------------------------
// The two axes' dumps
// ---------------------------------------------------------------------------

/// The oracle's dump: the resolution's order lines plus the
/// lockfile text, or the `PkgError` Display on rejection.
pub fn resolve_oracle_dump(root: &Path, limit: u32) -> String {
    match resolve_with_limit(root, limit) {
        Ok(res) => {
            let mut out = String::from("OK\n");
            for pkg in &res.order {
                out.push_str(&format!("{} {} ({})\n", pkg.name, pkg.version, pkg.source));
            }
            out.push_str("LOCK\n");
            out.push_str(&res.lockfile.to_text());
            out
        }
        Err(e) => format!("ERR {e}\n"),
    }
}

/// Render one twin outcome into the dump grammar (the oracle
/// axis's exact shape).
fn render_outcome(outcome: TwinOutcome) -> String {
    match outcome {
        TwinOutcome::Ok { order, lockfile } => {
            let mut out = String::from("OK\n");
            for (name, version, source) in &order {
                out.push_str(&format!("{name} {version} ({source})\n"));
            }
            out.push_str("LOCK\n");
            out.push_str(&lockfile);
            out
        }
        TwinOutcome::Err(message) => format!("ERR {message}\n"),
    }
}

/// The twin's two-axis dump (vm, eval): both engines run the
/// composed five-piece program, each axis rendered through the same
/// decode.
pub fn resolve_twin_dump(
    root: &Path,
    table: &[DirEntry],
    limit: u32,
) -> Result<(String, String), String> {
    let assembled = resolve_twin_program(table, limit, RESOLVE_TARGET_SOURCE);
    let decode = |value: &Value, heap: &Heap| -> Result<String, String> {
        Ok(render_outcome(decode_rs_verdict(value, heap, table, root)?))
    };
    drive_dual_engines(
        "resolve-parity-host",
        "resolve twin",
        &assembled,
        decode,
        decode,
    )
}

/// The three-way comparison over one case's real tree: oracle ==
/// twin-vm == twin-eval, line for line.
pub fn resolve_parity(case: &RsCase) -> Result<(), String> {
    let root = build_fixture(case);
    let result = resolve_parity_at(&root, case);
    let _ = std::fs::remove_dir_all(&root);
    result
}

/// The three-way comparison over an existing tree (the deep-chain
/// generator's face — the tree is built by code, not a static spec).
pub fn resolve_parity_at(root: &Path, case: &RsCase) -> Result<(), String> {
    let table = enumerate_table(root).map_err(|err| format!("[{}]: {err}", case.name))?;
    let oracle = resolve_oracle_dump(root, case.limit);
    let (vm_dump, eval_dump) = resolve_twin_dump(root, &table, case.limit)?;
    for (engine, dump) in [("vm", &vm_dump), ("eval", &eval_dump)] {
        if let Some((ol, tl)) = first_diff(&oracle, dump) {
            return Err(format!(
                "resolve parity FAIL [{}] ({engine}): oracle `{ol}` vs twin `{tl}`",
                case.name
            ));
        }
    }
    if let Some((vl, el)) = first_diff(&vm_dump, &eval_dump) {
        return Err(format!(
            "resolve parity FAIL [{}]: engines disagree: vm `{vl}` vs eval `{el}`",
            case.name
        ));
    }
    Ok(())
}

// ---------------------------------------------------------------------------
// The curated case lists
// ---------------------------------------------------------------------------

/// A generated deep chain: `c01 <- c02 <- ... <- c20 <- app` under
/// the default cap (the post-order face at scale).
pub fn deep_chain_case() -> (PathBuf, RsCase) {
    let dir = std::env::temp_dir().join(format!("kerf-rs-parity-{}-deep20", std::process::id()));
    let _ = std::fs::remove_dir_all(&dir);
    let mut parent = String::from("libs/c01");
    std::fs::create_dir_all(dir.join(&parent)).expect("chain head creates");
    std::fs::write(
        dir.join(&parent).join("kerf.toml"),
        "package = \"c01\"\nversion = \"0.1.0\"\n",
    )
    .expect("chain head writes");
    for n in 2..=20 {
        let rel = format!("{parent}/libs/c{n:02}");
        std::fs::create_dir_all(dir.join(&rel)).expect("chain link creates");
        std::fs::write(
            dir.join(&rel).join("kerf.toml"),
            format!(
                "package = \"c{n:02}\"\nversion = \"0.1.0\"\n\n[depends]\nc{:02} = \"0.1\"\n",
                n - 1
            ),
        )
        .expect("chain link writes");
        parent = rel;
    }
    std::fs::write(
        dir.join("kerf.toml"),
        "package = \"app\"\nversion = \"0.1.0\"\n\n[depends]\nc20 = \"0.1\"\n",
    )
    .expect("root writes");
    (
        dir,
        RsCase {
            name: "deep-chain-20",
            limit: 512,
            dirs: Vec::new(),
        },
    )
}

/// The curated cases: nine positive walks and twenty rejections
/// (the resolve family's full error surface — every
/// `PkgError` variant the resolver can raise, each through the
/// twin's own record and the oracle's own Display). Built as a
/// function (the `dirs` vectors are heap lists — the const context
/// cannot carry them).
pub fn resolve_parity_cases() -> Vec<RsCase> {
    vec![
        // ---- positive ----
        RsCase {
            name: "single",
            limit: 512,
            dirs: vec![(
                ".",
                RsContent::Text("package = \"solo\"\nversion = \"0.1.0\"\n"),
            )],
        },
        RsCase {
            name: "two-package-chain",
            limit: 512,
            dirs: vec![
                (
                    ".",
                    RsContent::Text(
                        "package = \"app\"\nversion = \"0.1.0\"\n\n[depends]\ncore-bits = \"0.2\"\n",
                    ),
                ),
                (
                    "libs/core-bits",
                    RsContent::Text("package = \"core-bits\"\nversion = \"0.2.3\"\n"),
                ),
            ],
        },
        RsCase {
            name: "nested-source",
            limit: 512,
            dirs: vec![
                (
                    ".",
                    RsContent::Text(
                        "package = \"app\"\nversion = \"0.1.0\"\n\n[depends]\na = \"1.0\"\n",
                    ),
                ),
                (
                    "libs/a",
                    RsContent::Text(
                        "package = \"a\"\nversion = \"1.0.0\"\n\n[depends]\nb = \"1.0\"\n",
                    ),
                ),
                (
                    "libs/a/libs/b",
                    RsContent::Text("package = \"b\"\nversion = \"1.0.0\"\n"),
                ),
            ],
        },
        RsCase {
            name: "multi-deps-sorted",
            limit: 512,
            dirs: vec![
                (
                    ".",
                    RsContent::Text(
                        "package = \"app\"\nversion = \"0.1.0\"\n\n[depends]\nzeta = \"0.1\"\nalpha = \"0.2\"\nmid = \"1.0\"\n",
                    ),
                ),
                (
                    "libs/zeta",
                    RsContent::Text("package = \"zeta\"\nversion = \"0.1.0\"\n"),
                ),
                (
                    "libs/alpha",
                    RsContent::Text("package = \"alpha\"\nversion = \"0.2.0\"\n"),
                ),
                (
                    "libs/mid",
                    RsContent::Text("package = \"mid\"\nversion = \"1.0.0\"\n"),
                ),
            ],
        },
        RsCase {
            name: "diamond-ok",
            limit: 512,
            dirs: vec![
                (
                    ".",
                    RsContent::Text(
                        "package = \"app\"\nversion = \"0.1.0\"\n\n[depends]\nleft = \"0.1\"\nright = \"0.1\"\n",
                    ),
                ),
                (
                    "libs/left",
                    RsContent::Text(
                        "package = \"left\"\nversion = \"0.1.0\"\n\n[depends]\nshared = \"0.1\"\n",
                    ),
                ),
                (
                    "libs/left/libs/shared",
                    RsContent::Text("package = \"shared\"\nversion = \"0.1.5\"\n"),
                ),
                (
                    "libs/right",
                    RsContent::Text(
                        "package = \"right\"\nversion = \"0.1.0\"\n\n[depends]\nshared = \"0.1.5\"\n",
                    ),
                ),
                (
                    "libs/right/libs/shared",
                    RsContent::Text("package = \"shared\"\nversion = \"9.9.9\"\n"),
                ),
            ],
        },
        RsCase {
            name: "diamond-shared-first-wins",
            limit: 512,
            dirs: vec![
                (
                    ".",
                    RsContent::Text(
                        "package = \"app\"\nversion = \"0.1.0\"\n\n[depends]\nleft = \"0.1\"\nright = \"0.1\"\n",
                    ),
                ),
                (
                    "libs/left",
                    RsContent::Text(
                        "package = \"left\"\nversion = \"0.1.0\"\n\n[depends]\nshared = \"0.1\"\n",
                    ),
                ),
                (
                    "libs/left/libs/shared",
                    RsContent::Text("package = \"shared\"\nversion = \"0.1.5\"\n"),
                ),
                (
                    "libs/right",
                    RsContent::Text(
                        "package = \"right\"\nversion = \"0.1.0\"\n\n[depends]\nshared = \"0.1\"\n",
                    ),
                ),
                (
                    "libs/right/libs/shared",
                    RsContent::Text("package = \"shared\"\nversion = \"9.9.9\"\n"),
                ),
            ],
        },
        RsCase {
            name: "canonical-version-render",
            limit: 512,
            dirs: vec![
                (
                    ".",
                    RsContent::Text(
                        "package = \"app\"\nversion = \"0.1.0\"\n\n[depends]\np = \"0.1\"\n",
                    ),
                ),
                (
                    "libs/p",
                    RsContent::Text("package = \"p\"\nversion = \"0.01.2\"\n"),
                ),
            ],
        },
        RsCase {
            name: "unreferenced-dir-ignored",
            limit: 512,
            dirs: vec![
                (
                    ".",
                    RsContent::Text("package = \"solo\"\nversion = \"0.1.0\"\n"),
                ),
                (
                    "libs/ghost",
                    RsContent::Text("package = \"ghost\"\nversion = \"0.1.0\"\n"),
                ),
            ],
        },
        RsCase {
            name: "empty-manifest-text",
            limit: 512,
            dirs: vec![(".", RsContent::Text(""))],
        },
        // ---- negative: the root-read tribe ----
        RsCase {
            name: "root-manifest-missing",
            limit: 512,
            dirs: vec![(".", RsContent::NoManifest)],
        },
        RsCase {
            name: "root-manifest-io",
            limit: 512,
            dirs: vec![(".", RsContent::IoTrap)],
        },
        // ---- negative: the cycle tribe ----
        RsCase {
            name: "self-cycle",
            limit: 512,
            dirs: vec![(
                ".",
                RsContent::Text(
                    "package = \"ouro\"\nversion = \"0.1.0\"\n\n[depends]\nouro = \"0.1\"\n",
                ),
            )],
        },
        RsCase {
            name: "two-cycle",
            limit: 512,
            dirs: vec![
                (
                    ".",
                    RsContent::Text(
                        "package = \"a\"\nversion = \"0.1.0\"\n\n[depends]\nb = \"0.1\"\n",
                    ),
                ),
                (
                    "libs/b",
                    RsContent::Text(
                        "package = \"b\"\nversion = \"0.1.0\"\n\n[depends]\na = \"0.1\"\n",
                    ),
                ),
            ],
        },
        RsCase {
            name: "three-cycle",
            limit: 512,
            dirs: vec![
                (
                    ".",
                    RsContent::Text(
                        "package = \"a\"\nversion = \"0.1.0\"\n\n[depends]\nb = \"0.1\"\n",
                    ),
                ),
                (
                    "libs/b",
                    RsContent::Text(
                        "package = \"b\"\nversion = \"0.1.0\"\n\n[depends]\nc = \"0.1\"\n",
                    ),
                ),
                (
                    "libs/b/libs/c",
                    RsContent::Text(
                        "package = \"c\"\nversion = \"0.1.0\"\n\n[depends]\na = \"0.1\"\n",
                    ),
                ),
            ],
        },
        RsCase {
            name: "cycle-mid-stack",
            limit: 512,
            dirs: vec![
                (
                    ".",
                    RsContent::Text(
                        "package = \"root\"\nversion = \"0.1.0\"\n\n[depends]\nx = \"0.1\"\n",
                    ),
                ),
                (
                    "libs/x",
                    RsContent::Text(
                        "package = \"x\"\nversion = \"0.1.0\"\n\n[depends]\ny = \"0.1\"\n",
                    ),
                ),
                (
                    "libs/x/libs/y",
                    RsContent::Text(
                        "package = \"y\"\nversion = \"0.1.0\"\n\n[depends]\nz = \"0.1\"\n",
                    ),
                ),
                (
                    "libs/x/libs/y/libs/z",
                    RsContent::Text(
                        "package = \"z\"\nversion = \"0.1.0\"\n\n[depends]\ny = \"0.1\"\n",
                    ),
                ),
            ],
        },
        // ---- negative: the missing-directory tribe ----
        RsCase {
            name: "dep-dir-missing",
            limit: 512,
            dirs: vec![(
                ".",
                RsContent::Text(
                    "package = \"app\"\nversion = \"0.1.0\"\n\n[depends]\nghost = \"0.1\"\n",
                ),
            )],
        },
        RsCase {
            name: "dep-dir-is-file",
            limit: 512,
            dirs: vec![
                (
                    ".",
                    RsContent::Text(
                        "package = \"app\"\nversion = \"0.1.0\"\n\n[depends]\nghost = \"0.1\"\n",
                    ),
                ),
                ("libs/ghost", RsContent::File),
            ],
        },
        // ---- negative: the manifest pass-through tribe ----
        RsCase {
            name: "dep-manifest-missing",
            limit: 512,
            dirs: vec![
                (
                    ".",
                    RsContent::Text(
                        "package = \"app\"\nversion = \"0.1.0\"\n\n[depends]\ncore = \"0.1\"\n",
                    ),
                ),
                ("libs/core", RsContent::NoManifest),
            ],
        },
        RsCase {
            name: "dep-manifest-io",
            limit: 512,
            dirs: vec![
                (
                    ".",
                    RsContent::Text(
                        "package = \"app\"\nversion = \"0.1.0\"\n\n[depends]\ncore = \"0.1\"\n",
                    ),
                ),
                ("libs/core", RsContent::IoTrap),
            ],
        },
        RsCase {
            name: "name-mismatch",
            limit: 512,
            dirs: vec![
                (
                    ".",
                    RsContent::Text(
                        "package = \"app\"\nversion = \"0.1.0\"\n\n[depends]\ncore = \"0.1\"\n",
                    ),
                ),
                (
                    "libs/core",
                    RsContent::Text("package = \"kore\"\nversion = \"0.1.0\"\n"),
                ),
            ],
        },
        RsCase {
            name: "dep-manifest-syntax",
            limit: 512,
            dirs: vec![
                (
                    ".",
                    RsContent::Text(
                        "package = \"app\"\nversion = \"0.1.0\"\n\n[depends]\ncore = \"0.1\"\n",
                    ),
                ),
                (
                    "libs/core",
                    RsContent::Text("package = \"core\"\nversion = \"0.1.0\n"),
                ),
            ],
        },
        RsCase {
            name: "dep-manifest-missing-version",
            limit: 512,
            dirs: vec![
                (
                    ".",
                    RsContent::Text(
                        "package = \"app\"\nversion = \"0.1.0\"\n\n[depends]\ncore = \"0.1\"\n",
                    ),
                ),
                ("libs/core", RsContent::Text("package = \"core\"\n")),
            ],
        },
        RsCase {
            name: "dep-bad-constraint",
            limit: 512,
            dirs: vec![(
                ".",
                RsContent::Text(
                    "package = \"app\"\nversion = \"0.1.0\"\n\n[depends]\ncore = \"1.x\"\n",
                ),
            )],
        },
        RsCase {
            name: "root-bad-name",
            limit: 512,
            dirs: vec![(
                ".",
                RsContent::Text("package = \"App\"\nversion = \"0.1.0\"\n"),
            )],
        },
        RsCase {
            name: "root-bad-version",
            limit: 512,
            dirs: vec![(
                ".",
                RsContent::Text("package = \"app\"\nversion = \"1.2\"\n"),
            )],
        },
        // ---- negative: the conflict tribe ----
        RsCase {
            name: "conflict-single",
            limit: 512,
            dirs: vec![
                (
                    ".",
                    RsContent::Text(
                        "package = \"app\"\nversion = \"0.1.0\"\n\n[depends]\nsolo = \"2.0\"\n",
                    ),
                ),
                (
                    "libs/solo",
                    RsContent::Text("package = \"solo\"\nversion = \"1.9.0\"\n"),
                ),
            ],
        },
        RsCase {
            name: "conflict-diamond",
            limit: 512,
            dirs: vec![
                (
                    ".",
                    RsContent::Text(
                        "package = \"app\"\nversion = \"0.1.0\"\n\n[depends]\nleft = \"0.1\"\nright = \"0.1\"\n",
                    ),
                ),
                (
                    "libs/left",
                    RsContent::Text(
                        "package = \"left\"\nversion = \"0.1.0\"\n\n[depends]\nshared = \"0.2\"\n",
                    ),
                ),
                (
                    "libs/left/libs/shared",
                    RsContent::Text("package = \"shared\"\nversion = \"0.1.5\"\n"),
                ),
                (
                    "libs/right",
                    RsContent::Text(
                        "package = \"right\"\nversion = \"0.1.0\"\n\n[depends]\nshared = \"0.1\"\n",
                    ),
                ),
                (
                    "libs/right/libs/shared",
                    RsContent::Text("package = \"shared\"\nversion = \"0.1.5\"\n"),
                ),
            ],
        },
        RsCase {
            name: "conflict-sorted-keys",
            limit: 512,
            dirs: vec![
                (
                    ".",
                    RsContent::Text(
                        "package = \"app\"\nversion = \"0.1.0\"\n\n[depends]\nb = \"9.0\"\n",
                    ),
                ),
                (
                    "libs/b",
                    RsContent::Text(
                        "package = \"b\"\nversion = \"1.0.0\"\n\n[depends]\na = \"9.0\"\n",
                    ),
                ),
                (
                    "libs/b/libs/a",
                    RsContent::Text("package = \"a\"\nversion = \"1.0.0\"\n"),
                ),
            ],
        },
        // ---- negative: the depth cap ----
        RsCase {
            name: "depth-limit",
            limit: 3,
            dirs: vec![
                (
                    ".",
                    RsContent::Text(
                        "package = \"root\"\nversion = \"0.1.0\"\n\n[depends]\nc1 = \"0.1\"\n",
                    ),
                ),
                (
                    "libs/c1",
                    RsContent::Text(
                        "package = \"c1\"\nversion = \"0.1.0\"\n\n[depends]\nc2 = \"0.1\"\n",
                    ),
                ),
                (
                    "libs/c1/libs/c2",
                    RsContent::Text(
                        "package = \"c2\"\nversion = \"0.1.0\"\n\n[depends]\nc3 = \"0.1\"\n",
                    ),
                ),
                (
                    "libs/c1/libs/c2/libs/c3",
                    RsContent::Text(
                        "package = \"c3\"\nversion = \"0.1.0\"\n\n[depends]\nc4 = \"0.1\"\n",
                    ),
                ),
                (
                    "libs/c1/libs/c2/libs/c3/libs/c4",
                    RsContent::Text("package = \"c4\"\nversion = \"0.1.0\"\n"),
                ),
            ],
        },
        // ---- negative: the conflict tribe, the mid-list violation
        // face (r160 — the corpus regression caught the twin
        // reporting only the tail from the violation point; the
        // oracle lists EVERY imposed constraint, so the satisfied
        // head entry must survive into the rejection) ----
        RsCase {
            name: "conflict-mid-list",
            limit: 512,
            dirs: vec![
                (
                    ".",
                    RsContent::Text(
                        "package = \"top\"\nversion = \"0.1.0\"\n\n[depends]\nleft = \"0.1\"\nright = \"0.1\"\n",
                    ),
                ),
                (
                    "libs/left",
                    RsContent::Text(
                        "package = \"left\"\nversion = \"0.1.0\"\n\n[depends]\ndeep = \"0.1\"\n",
                    ),
                ),
                (
                    "libs/left/libs/deep",
                    RsContent::Text("package = \"deep\"\nversion = \"0.1.4\"\n"),
                ),
                (
                    "libs/right",
                    RsContent::Text(
                        "package = \"right\"\nversion = \"0.1.0\"\n\n[depends]\ndeep = \"0.2\"\n",
                    ),
                ),
            ],
        },
    ]
}

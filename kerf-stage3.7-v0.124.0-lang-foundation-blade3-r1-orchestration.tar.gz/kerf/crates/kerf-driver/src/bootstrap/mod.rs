//! The selfhost twin surface — the Rust-side bootstrap harness
//! family (the r122 user instruction-① unification: every module
//! whose job is to assemble, drive or verify the `selfhost/v1/*.ktf`
//! twins lives under this one directory, separated from the
//! driver's production face at the crate root).
//!
//! Residents:
//! - `target_corpus` — the twin source embeddings (the seven
//!   `include_str` bindings into `selfhost/v1/`) and the
//!   target-skin injection prefixes (the RS-1/EX-1/CP family);
//! - `vm_harness` — the shared decode/drive layer of every twin
//!   harness (the VM value decoders, the dual-engine driver, the
//!   SyntaxObject dump single source, and the RS-1 byte-table
//!   channel builders; converged r151 from the retired
//!   `reader_parity`/`lexer_parity` split when the S-expr read
//!   chain left the tree with the W-SEXP-RETIRE blade 2);
//! - `expander_parity` / `compiler_parity` / `infer_parity` — the
//!   front-end segments' twin-vs-oracle parity harnesses (segment
//!   three: the HM inference axis);
//! - `micro_toml_parity` — the W-PKG-SELFHOST blade 1 face: the
//!   micro-TOML subset parser twin against `kerf_pkg::micro_toml`
//!   (K15 differential oracle; the RS-5 `first_diff` sharing
//!   converged the lexer harness's private helper in the same
//!   round);
//! - `target_lexer_parity` — the W-TGT-READ-TWIN blade 1 face: the
//!   TARGET skin's own lexer twin against `lex_target` (gap G1);
//! - `steady_expander_chain` — the steady-state injection-channel
//!   form carried to the expansion segment (W-3.12 segment two:
//!   `SteadyExpanderChain`, the `forms` record stream through the
//!   one injection channel);
//! - `steady_typecheck_chain` — the same form carried to the HM
//!   inference segment (W-HM-TWIN 127-a: the `items` record stream
//!   through the one injection channel);
//! - `composed_target_read_chain` / `composed_full_chain` — the
//!   composed chain verifications (the r151 single-skin note: the
//!   retired `composed_target_chain` — whose J0/J0.5 layers read
//!   the transcoded S-expr prefix through the `lexer.ktf`/
//!   `reader.ktf` twins — left the tree fully superseded by
//!   `composed_target_read_chain`, the target-twin composed read
//!   chain of r139);
//! - `fixpoint` — the self-application fixpoint gates.
//!
//! Boundary notes (SOP §8.4.6 two-level semantics): the target-skin
//! SPELLING contract stays at the crate root (`crate::target_skin` —
//! a production contract the bridge and the diagnostics consume),
//! and the Stage 1.4 acceptance-corpus contract stays at the root
//! (`crate::parity`). The W-DRIVER-HARNESS-SPLIT crate split remains
//! trigger-gated (r122 reorganized in-crate; the +30% growth
//! trigger is unchanged).

//! - `steady_compiler_chain` — the same form carried to the compile
//!   segment (the r148 step-④ switch: `compiler.ktf` behind the
//!   `items` slot declaration and the `co_limit` budget define, the
//!   production artifact face);
pub mod abc_pipeline;
pub(crate) mod compiler_parity;
pub(crate) mod composed_full_chain;
pub(crate) mod composed_target_read_chain;
pub(crate) mod expander_parity;
pub(crate) mod fixpoint;
pub(crate) mod infer_parity;
pub(crate) mod lockfile_parity;
pub(crate) mod manifest_parity;
pub(crate) mod micro_toml_parity;
pub(crate) mod resolve_parity;
pub(crate) mod semver_parity;
pub mod steady_compiler_chain;
pub mod steady_expander_chain;
pub mod steady_target_reader_chain;
pub mod steady_typecheck_chain;
pub(crate) mod target_corpus;
pub(crate) mod target_lexer_parity;
pub(crate) mod target_parser_parity;
pub(crate) mod typecheck_parity;
pub(crate) mod vm_harness;

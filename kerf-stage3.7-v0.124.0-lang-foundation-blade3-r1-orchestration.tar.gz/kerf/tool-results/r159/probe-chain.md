# r159 probe chain — the four-defect evidence record (blade 3b debug)

The interrupted session left the resolve twin parse-broken. The
defect chain was localized with the probe-offset method (the
r157/r158 precedent): a temporary zz_probe test drove
resolve_parity per case printing the vm span, and a temporary
resolve_parity_at window print showed the assembled-program slice
around the crash. Both were added and removed the same round
(zero residue in the tree — the commits and the guard suite prove
the removal).

- probe1.txt — first run: parse fails on `rs_visit` (the mutual
  recursion) at assembled offset 94012..94029; per-case assembly
  lengths recorded (the window reconstruction baseline).
- probe2.txt — after the merge surgery + the pkg_span double
  unwrap: the crash moved to sv_caret_satisfies (`first(con)` car
  on int — the temporarily-wrong con unwrap, see probe3) and the
  lockfile region (`first(rest(entry))` car on nil — the mt_append
  miswrap family), per-case spans 32582..33633.
- probe3.txt — after the con revert (the manifest twin's dep entry
  carries the bare quad — `pair(X, pair(Y, nil))` is the two-list
  (X, Y), no extra wrap): three crash classes remain — the lockfile
  `<` on pair (the sort key miswrap), the car on nil (the entry
  miswrap), and the conflict-region car on nil.
- probe4.txt — after the four mt_append bare-append fixes: ALL
  NINE positive walks three-way green (the empty-manifest case
  passed throughout — it never reaches the walk).

The final in-round clears (the dep-dir parent convention) landed
after probe4 through the parity harness itself; the full chain
ended 6/6 on resolve_twin_tests and 6/6 on kp_selfhost_tests.

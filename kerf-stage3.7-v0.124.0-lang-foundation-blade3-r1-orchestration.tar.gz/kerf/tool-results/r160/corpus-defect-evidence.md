# r160 — the corpus-regression defect evidence (blade 4)

## The first red (kp_corpus_tests::conflict_diamond — the corpus face's opening run)

```text
---- conflict_diamond_renders_identically_on_both_arms stdout ----

thread 'conflict_diamond_renders_identically_on_both_arms' panicked at crates/kerf-driver/tests/kp_corpus_tests.rs:67:5:
assertion `left == right` failed: the stderr agrees across arms
  left: "kp: version conflict for \"deep\": resolved 0.1.4, but \"right\" requires 0.2\n"
 right: "kp: version conflict for \"deep\": resolved 0.1.4, but \"left\" requires 0.1, \"right\" requires 0.2\n"

test result: FAILED. 6 passed; 1 failed
```

The corpus regression face (blade 4's core deliverable) caught a REAL
production twin defect on its opening run: the twin arm reported only
the violating tail of the imposed constraint list, the oracle reports
EVERY imposed constraint (PKG-3).

## Root cause

`rs_check_imposed(dep, ver, imposed)` recursed with `rest(imposed)`
and passed the remaining sublist to `rs_err_conflict` at the
violation point — a mid-list violation therefore dropped every
satisfied prefix entry:

```text
edges["deep"] = [("left", 0.1) SATISFIED, ("right", 0.2) VIOLATED]
                                  ^ recursion enters with rest(...)
violation found at ("right", 0.2) -> rs_err_conflict(dep, ver, [("right", 0.2)])
                                                              ^ tail only — ("left", 0.1) lost
```

The r159 parity corpus stayed green by coincidence: its
`conflict-diamond` fixture places the violation at the HEAD of the
imposed list (left requires 0.2, violated by the resolved 0.1.5),
where the tail IS the whole list. The corpus face's diamond places
the violation in the MIDDLE — the blind spot of the r159 corpus
distribution.

## The fix

Thread the original list along (resolve.ktf rs_check_imposed gains an
`all` parameter; rs_verify passes `imposed` twice):

```text
fn rs_check_imposed(dep, ver, imposed, all) {
    ... if sv_caret_satisfies(con, ver) { rs_check_imposed(dep, ver, rest(imposed), all) }
        else { rs_err_conflict(dep, ver, all) }   -- the WHOLE list, always
```

## The pins

* e2e: `kp_corpus_tests::conflict_diamond_renders_identically_on_both_arms`
  (both arms byte-identical, every constraint listed);
* parity: the `conflict-mid-list` drive (the 31st resolve parity case)
  — the satisfied-head + violated-tail distribution, three-way
  (oracle == twin-vm == twin-eval).

## The same-path sweep (SOP §20.3)

The "recursive list walk that drops the accumulated prefix when
throwing" shape is UNIQUE in the .ktf family: rs_err_cycle slices the
stack from the first occurrence (the correct cycle-path semantics);
the dep-dir / manifest-not-found tribe carries scalars; the
mt/sv/mf/lk twins carry record positions, not accumulated lists.

## Methodology deposit (BR-33 family)

Parity case distributions must cover BOTH the head-violation and the
mid-list-violation shapes of any "first violation, whole table"
oracle semantics (SOP §9.4.3 distribution-argumentation duty).

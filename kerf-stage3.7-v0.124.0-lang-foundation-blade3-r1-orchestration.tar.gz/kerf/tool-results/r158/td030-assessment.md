# TD-030 Root-Cause Assessment Record (W-CONS-COLLAPSE — r158-a)

> **Verdict: MISDIAGNOSIS — no defect exists.** The registered
> "inline nested cons argument-position collapse" is the correct
> tail-splice semantics of `cons(A, X)` misread as a defect. This
> file is the assessment's evidence anchor (probe sources:
> `td030_repro.ktf` + `td030_probe{,2..6}.ktf`; run transcripts:
> `td030-probe-outputs.txt`; all in this directory).

## 1. The registered claim (tech-debt-register r157 / stage0 §9.140.1 BR-24)

`cons(A, cons(B, nil))` with B a pair construction, evaluated at a
non-tail argument position, collapses the inner `cons(B, nil)` to B
(`(A B)` becomes `(A . B)`); a let-relayed construction of the same
tree is correct. Registered P1, with manifest.ktf written in
let-relay style as a workaround.

## 2. The assessment evidence (r158, both engines, v0.115.0 tree)

| Probe | Shape under test | Result |
|---|---|---|
| probe3 c1 | the EXACT registered pattern `cons(A, cons(B, nil))`, B = `cons(11, cons(12, nil))` inline | **correct 2-list** — both engines |
| probe3 c2 | the registered bad(x) full shape `cons("ok", cons(P, Q))`, P a 2-list, Q a 1-list | **correct 3-list** — the math of the shape |
| probe3 c3 | the intended 2-list (inner wrapped once more) | correct |
| probe3 c4 | 4-level deep inline nesting, no let relay at all | correct at every level |
| probe3 c5 | nested construction in cons's FIRST (non-tail) argument position, atom tail | correct improper pair |
| probe4 d1/d2 | bad_math (inline) vs bad_let (let-relayed) — the SAME tree both ways | **identical results** (d1 = d2 = T; atom-level equality e3/e4/e5 all T) |
| probe4 d3/d4 | the properly-wrapped tree | correct 2-list, inner intact |
| probe4 f* | inline nested cons inside if-branches | correct |
| probe4 g* | inline pair-construction args of a user fn call; car/cdr of the result | correct (the 18-line output audit: 0 mismatches) |
| probe5 p4/p6/p7 | argument-passing integrity: inline constructions as 1st/2nd/both args | intact — `first_of(inline, inline)` arrives as the proper 2-list |
| probe5 q*/r*/s* | structural probes of the received values; 1-element and 3-arg calls | correct |

## 3. Why the r157 session (and the first half of this assessment)
##    saw "corruption"

1. **The semantic trap**: `cons(A, X)` with X a proper n-list is an
   (n+1)-list — X splices as the tail. The registered bad(x)
   `cons("ok", cons(P, Q))` with P = `(11 12)` and Q = `(8)`
   evaluates to the 3-list `("ok" (11 12) 8)`. The intended
   `("ok" ((11 12) 8))` requires one MORE wrap:
   `cons("ok", cons(inner, nil))`. The r157 "good" let-relayed
   version happened to include that wrap (elided as `...` in the
   register's schematic), so the two programs were NOT equivalent —
   the difference was the tree shape, not inline-vs-let.
2. **The misread**: both engines evaluating the mis-designed probe
   to the same (correct) value was logged as "both engines
   share the same bug" — agreement was actually both engines being
   right.
3. **The coexistence rationalization**: "why did 20 rounds of twin
   parity stay green despite a live P1?" was answered with "the
   collapse is invisible in the atomic domain" — the real answer is
   that no defect existed to show itself.
4. **This session's own false positives** (recorded for calibration):
   `car((1 2))` is the atom 1, so `len(car(...))` correctly errors;
   `len(cdr(2-list))` is 1, not 2; `quote((d))` is the bare datum
   while `quote((d,))` is the 1-list (BR-25). Each was initially
   misread as a defect signal before the probe audit corrected it.

## 4. Disposition

- **TD-030 → closed (misdiagnosis, no defect)** — no code change;
  the register entry is corrected in place (r158 检视节).
- **manifest.ktf's let-relay style stays as-is** — stylistic, all
  55 parity cases green; no churn without cause (§2.1.1).
- **Blade 3/4 twins may construct trees naturally** — no let-relay
  discipline is required; the W-CONS-COLLAPSE window is dissolved.
- **The evaluation-order/GC/heap theories examined and cleared on
  the way** (this assessment's negative results are part of the
  record): segment-band bisection all-green on every genuinely
  correct probe; `collect_now` root classes verified adequate for
  these shapes; the DEFAULT_BUDGET (8M) never triggers a cycle in
  probe-sized programs, so no sweep/reuse path was ever live.

## 5. Probe inventory

| File | Role |
|---|---|
| `td030_repro.ktf` | the register schematic verbatim (function form) |
| `td030_probe.ktf` | first tail-walk probe (superseded — probe design flaw) |
| `td030_probe2.ktf` | dr/outer assembly decomposition |
| `td030_probe3.ktf` | the definitive shape battery (13 probes) |
| `td030_probe4.ktf` | function-form + exotic sites + the 18-line output audit (0 mismatches) |
| `td030_probe5.ktf` | argument-passing integrity battery (21 probes) |
| `td030_probe6.ktf` | discrimination battery (its t7+ errors are correct behavior on mis-designed probes) |
| `td030-probe-outputs.txt` | both-engine run transcripts of the above |

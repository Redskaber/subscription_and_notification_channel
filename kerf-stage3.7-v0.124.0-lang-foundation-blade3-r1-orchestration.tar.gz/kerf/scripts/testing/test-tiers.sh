#!/usr/bin/env bash
# test-tiers.sh — tier-aware batch engine for the kerf test tree (W-TEST-FLOW, r167).
#
# Research anchors (docs/develop/v3/w-test-flow-window.md §3):
#   - GHC `make validate` tiers (fast / normal / slow) — tier switch precedent.
#   - LLVM lit: persisted per-test times (.lit_test_times.txt analog =
#     durations.tsv), failed-first smart ordering, per-test timeouts,
#     global --max-time budgets.
#   - Go test result reuse — here conservative: checkpoint ledger only,
#     resume valid solely under an unchanged run fingerprint.
#   - cargo-nextest build-once-run-many — `cargo test --no-run` precedes
#     the batch; each family then reuses the cached binary.
#
# INVARIANTS (docs/testing-guide.md — GATE integrity):
#   1. Tiering changes WHEN/HOW tests run, never WHAT must pass.
#   2. The packaging GATE (SOP §3.2 / §19.3) is always a fresh full T2 run
#      (`run --tier T2 --force`); a resumed ledger is never a substitute.
#   3. Resume only skips families already green under the SAME fingerprint
#      (runner binary sha16 + git HEAD + RUST_MIN_STACK + tiers.tsv sha16).
#   4. Family runs are serial in v1 (TD-029 release-mode memory caution);
#      a KERF_TEST_JOBS>1 knob is deliberately NOT honored yet.
#
# Usage:
#   test-tiers.sh list  [--tier T0|T1|T2]
#   test-tiers.sh run   [--tier T0|T1|T2] [--resume] [--force] [--max-time SECONDS]
#                       [--build-only] [--skip-build]
#   test-tiers.sh status
#
# EXECUTION MODE (environment-mandated — window doc §3.4):
#   This sandbox reaps every descendant process when the spawning tool
#   call returns (nohup AND setsid both die — verified r167). Background
#   polling is therefore IMPOSSIBLE; the only legal long-suite pattern is
#   CHUNKED FOREGROUND: repeated `run --resume --max-time <budget>` calls,
#   each inside one tool-call timeout window, progress carried by the
#   ledger. For cold builds that exceed a single window, pre-build crates
#   package-by-package (`cargo build --release -p <crate>` — cargo caches
#   per crate), or use --build-only as its own chunk.
#
# Exit code (run): 0 iff every selected family ended green this session.

set -u

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
cd "$ROOT"

TSV="$SCRIPT_DIR/tiers.tsv"
LEDGER_DIR="$ROOT/target/test-ledger"
STATE_FILE="$LEDGER_DIR/state"
LEDGER="$LEDGER_DIR/ledger.tsv"
LEDGER_PREV="$LEDGER_DIR/ledger.prev.tsv"
DURATIONS="$LEDGER_DIR/durations.tsv"
BATCH_LOG="$LEDGER_DIR/batch.log"

export RUST_MIN_STACK="${RUST_MIN_STACK:-8388608}" # TD-029 GATE partition adaptation
export PATH="$HOME/.cargo/bin:$PATH"

log() { printf '[%s] %s\n' "$(date -u +%H:%M:%S)" "$*" | tee -a "$BATCH_LOG"; }

die() { printf 'test-tiers: error: %s\n' "$*" >&2; exit 2; }

# --------------------------------------------------------------------------
# tiers.tsv parsing — columns: family <TAB> tier <TAB> timeout_s <TAB> note
# Virtual rows (libs/doc/audit) name cargo faces outside the runner binary.
# --------------------------------------------------------------------------

tsv_rows() {
    # Emit: family tier timeout_s (comment/blank lines skipped)
    awk -F'\t' '/^[[:space:]]*#/ || /^[[:space:]]*$/ {next} {gsub(/[[:space:]]+$/, "", $1); print $1 "\t" $2 "\t" $3}' "$TSV"
}

tier_rank() {
    case "$1" in
        T0) echo 0 ;;
        T1) echo 1 ;;
        T2) echo 2 ;;
        *) die "unknown tier label '$1' in tiers.tsv" ;;
    esac
}

families_at_or_below() { # $1 = target tier label
    # NOTE: read vars are prefixed row_ — a bare `tier` here would clobber
    # the caller's `tier` local through bash dynamic scoping (r167 bug:
    # the EOF empty-read reset wiped it and dropped every virtual row).
    local want rank
    want="$(tier_rank "$1")"
    while IFS=$'\t' read -r row_fam row_tier row_t; do
        [ -z "$row_fam" ] && continue
        case "$row_fam" in libs|doc|audit) continue ;; esac
        rank="$(tier_rank "$row_tier")"
        if [ "$rank" -le "$want" ]; then printf '%s\n' "$row_fam"; fi
    done < <(tsv_rows)
}

virtuals_at_or_below() { # $1 = target tier label
    local want rank
    want="$(tier_rank "$1")"
    while IFS=$'\t' read -r row_fam row_tier row_t; do
        case "$row_fam" in
            libs) rank=1 ;;  # libs join at T1
            doc|audit) rank=2 ;; # doc + audit join at T2 (full GATE face)
            *) continue ;;
        esac
        if [ "$rank" -le "$want" ]; then printf '%s\n' "$row_fam"; fi
    done < <(tsv_rows)
}

family_timeout() { # $1 = family (or virtual) -> timeout seconds
    while IFS=$'\t' read -r row_fam row_tier row_t row_note; do
        if [ "$row_fam" = "$1" ]; then
            [ -n "$row_t" ] && [ "$row_t" -gt 0 ] 2>/dev/null && { echo "$row_t"; return; }
            die "bad timeout for '$row_fam' in tiers.tsv"
        fi
    done < <(tsv_rows)
    die "family '$1' missing from tiers.tsv"
}

# --------------------------------------------------------------------------
# Filter collision handling: libtest filters are plain substrings, so a
# family whose name embeds in another (fixpoint_tests ⊂ target_fixpoint_tests,
# jit_window_tests ⊂ method_jit_window_tests) needs explicit --skip shields.
# --------------------------------------------------------------------------

collision_skips() { # $1 = family -> emits super-name family names (caller builds --skip args)
    local fam="$1" other
    while IFS=$'\t' read -r other _tier _t _note; do
        [ -z "$other" ] && continue
        case "$other" in libs|doc|audit) continue ;; esac
        if [ "$other" != "$fam" ] && [[ "$other" == *"$fam"* ]]; then
            printf '%s\n' "$other"
        fi
    done < <(tsv_rows)
}

# Build the libtest skip args for a family (each name -> two argv entries:
# --skip <name>:: — never a single arg with an embedded space; a space-joined
# arg is rejected by libtest as an unknown option, which silently kills the
# whole invocation — the r167 fixpoint/jit red-row root cause).
build_skip_args() { # $1 = family -> argv array on stdout, one per line
    local g
    while IFS= read -r g; do
        printf '%s\n' --skip
        printf '%s\n' "${g}::"
    done < <(collision_skips "$1")
}

# --------------------------------------------------------------------------
# Fingerprint: conservative invalidation — any code change rebuilds the
# runner binary; any HEAD move or tiers.tsv edit also invalidates resume.
# --------------------------------------------------------------------------

runner_binary() {
    local bin
    bin="$(ls -t "$ROOT"/target/release/deps/runner-* 2>/dev/null | grep -v '\.d$' | head -1)"
    [ -x "$bin" ] || die "runner binary not found — run the batch first (cargo test --no-run)"
    printf '%s\n' "$bin"
}

fingerprint_state() {
    local bin head tsv_sha
    bin="$(runner_binary)"
    head="$(git -C "$ROOT" rev-parse --short HEAD 2>/dev/null || echo nogit)"
    tsv_sha="$(sha256sum "$TSV" | cut -c1-16)"
    printf 'bin_sha16=%s\nhead=%s\nstack=%s\ntsv_sha16=%s\n' \
        "$(sha256sum "$bin" | cut -c1-16)" "$head" "$RUST_MIN_STACK" "$tsv_sha"
}

state_matches() {
    [ -f "$STATE_FILE" ] || return 1
    [ -f "$LEDGER" ] || return 1
    diff -q <(fingerprint_state) "$STATE_FILE" >/dev/null 2>&1
}

ledger_status_of() { # $1 = family -> green|red|timeout|pending|"" (absent)
    [ -f "$LEDGER" ] || return 0
    awk -F'\t' -v fam="$1" '$1 == fam {print $2}' "$LEDGER" | tail -1
}

ledger_counts_of() { # $1 = family -> "N passed; M failed; K ignored" tail
    [ -f "$LEDGER" ] || return 0
    awk -F'\t' -v fam="$1" '$1 == fam {print $4}' "$LEDGER" | tail -1
}

record_duration() { # $1 family, $2 seconds — the .lit_test_times.txt analog
    local fam="$1" secs="$2"
    [ -f "$DURATIONS" ] || : > "$DURATIONS"
    grep -v "^${fam}    " "$DURATIONS" > "$DURATIONS.tmp" 2>/dev/null || true
    printf '%s\t%s\n' "$fam" "$secs" >> "$DURATIONS.tmp"
    mv "$DURATIONS.tmp" "$DURATIONS"
}

known_duration() { # $1 family -> seconds or 0
    [ -f "$DURATIONS" ] || { echo 0; return; }
    awk -F'\t' -v fam="$1" '$1 == fam {print $2}' "$DURATIONS" | tail -1 | grep -E '^[0-9]+$' || echo 0
}

# --------------------------------------------------------------------------
# Batch execution
# --------------------------------------------------------------------------

run_one_family() { # $1 = family, $2 = whole-invocation timeout -> green iff all green
    local fam="$1" t start status counts
    t="$2"
    start=$SECONDS
    local skips=()
    mapfile -t skips < <(build_skip_args "$fam")
    local out
    out="$(timeout "$t" cargo test --release --test runner -- "${fam}::" "${skips[@]}" 2>&1)"
    local ec=$?
    local dur=$((SECONDS - start))
    counts="$(printf '%s\n' "$out" | grep -E '^test result:' | tail -1)"
    if [ $ec -eq 124 ]; then
        status=timeout
    elif [ $ec -eq 0 ] && printf '%s\n' "$out" | grep -qE '^test result: ok'; then
        status=green
    else
        status=red
    fi
    printf '%s\t%s\t%s\t%s\t%s\n' "$fam" "$status" "$dur" "${counts:-<no-summary>}" "$(date -u +%FT%TZ)" >> "$LEDGER"
    record_duration "$fam" "$dur"
    log "family $fam -> $status (${dur}s) ${counts:-}"
    [ "$status" = green ]
}

# ---------------------------------------------------------------------------
# Intra-family sharding (lit --num-shards intra-machine analog): a family
# whose expected duration exceeds the chunk window CANNOT finish inside any
# single tool call (the 600s hard ceiling — the historical root cause of
# killed verification runs). The engine enumerates the family's cases
# (--list), runs them in window-fitting slices (--exact multi-filter), and
# carries per-case progress in target/test-ledger/progress/<family>.txt.
# ---------------------------------------------------------------------------

progress_file() { echo "$LEDGER_DIR/progress/$1.txt"; }

list_family_cases() { # $1 = family -> case names (one per line)
    local fam="$1"
    local skips=()
    mapfile -t skips < <(build_skip_args "$fam")
    cargo test --release --test runner -- "${fam}::" "${skips[@]}" --list --format=terse 2>/dev/null \
        | sed -n "s/^${fam}::.*: test$/&/p" | sed 's/: test$//'
}

run_family_sharded() { # $1 = family, $2 = budget seconds -> green iff all slices green
    local fam="$1" budget="$2"
    local pf
    pf="$(progress_file "$fam")"
    mkdir -p "$LEDGER_DIR/progress"
    touch "$pf"

    mapfile -t all_cases < <(list_family_cases "$fam")
    if [ "${#all_cases[@]}" -eq 0 ]; then
        printf '%s\t%s\t%s\t%s\t%s\n' "$fam" red 0 "<case-enumeration-empty>" "$(date -u +%FT%TZ)" >> "$LEDGER"
        log "family $fam -> red (case enumeration returned nothing)"
        return 1
    fi

    # Resume: drop already-completed cases.
    local todo=() c done_rx
    for c in "${all_cases[@]}"; do
        grep -qxF "$c" "$pf" || todo+=("$c")
    done
    # NOTE: two separate locals — bash expands all words of one `local`
    # command before performing any assignment, so a combined
    # `local total=X done_n=$((total - Y))` trips set -u (total unbound
    # at expansion time — the r167 line-251 crash).
    local total="${#all_cases[@]}"
    local done_n=$((total - ${#todo[@]}))
    if [ "${#todo[@]}" -eq 0 ]; then
        printf '%s\t%s\t%s\t%s\t%s\n' "$fam" green 0 "${done_n}/${total} cases (resumed complete)" "$(date -u +%FT%TZ)" >> "$LEDGER"
        rm -f "$pf"
        log "family $fam -> green (resumed complete: ${done_n}/${total})"
        return 0
    fi

    # Per-case estimate: family estimate spread over cases, doubled for safety.
    local fam_est per_case slice_start status ec out dur counts slice_n
    fam_est="$(estimated_duration "$fam")"
    per_case=$(( (fam_est / total) * 2 + 1 ))

    printf '%s\t%s\t%s\t%s\t%s\n' "$fam" "running" 0 "${done_n}/${total} sharded" "$(date -u +%FT%TZ)" >> "$LEDGER"
    slice_start=$SECONDS
    status=green
    while [ "${#todo[@]}" -gt 0 ]; do
        local remaining=$((budget - (SECONDS - slice_start)))
        local fit=$((remaining / per_case))
        if [ "$fit" -lt 1 ]; then
            status=pending
            break
        fi
        local slice=("${todo[@]:0:$fit}")
        todo=("${todo[@]:$fit}")
        # Slice timeout carries extra headroom over the remaining budget:
        # per-case estimates are family means, and uneven distributions
        # (one 60s+ selfhost case among 2s guards) routinely exceed them.
        # A timeout is NOT a failure verdict — it keeps the progress file
        # and parks the family as pending for the next chunk.
        out="$(timeout "$((remaining + 90))" cargo test --release --test runner -- --exact "${slice[@]}" 2>&1)"
        ec=$?
        if [ $ec -eq 0 ] && printf '%s\n' "$out" | grep -qE '^test result: ok'; then
            for c in "${slice[@]}"; do printf '%s\n' "$c" >> "$pf"; done
            done_n=$((done_n + ${#slice[@]}))
            log "family $fam slice ${#slice[@]} cases -> green (${done_n}/${total})"
        elif [ $ec -eq 124 ]; then
            status=pending
            printf '%s\t%s\t%s\t%s\t%s\n' "$fam" pending $((SECONDS - slice_start)) "${done_n}/${total} cases (slice timeout — not a failure; resumes at case $((done_n + 1)))" "$(date -u +%FT%TZ)" >> "$LEDGER"
            log "family $fam -> pending (slice timeout at ${done_n}/${total}; progress kept)"
            return 1
        else
            status=red
            counts="$(printf '%s\n' "$out" | grep -E '^test result:' | tail -1)"
            printf '%s\t%s\t%s\t%s\t%s\n' "$fam" red $((SECONDS - slice_start)) "${counts:-<slice-failed>}" "$(date -u +%FT%TZ)" >> "$LEDGER"
            rm -f "$pf"
            log "family $fam -> red (slice failed) ${counts:-}"
            record_duration "$fam" $((SECONDS - slice_start))
            return 1
        fi
    done
    dur=$((SECONDS - slice_start))
    if [ "$status" = green ]; then
        printf '%s\t%s\t%s\t%s\t%s\n' "$fam" green "$dur" "${total}/${total} cases (sharded)" "$(date -u +%FT%TZ)" >> "$LEDGER"
        rm -f "$pf"
        record_duration "$fam" "$dur"
        log "family $fam -> green (${total}/${total} sharded, ${dur}s)"
        return 0
    else
        printf '%s\t%s\t%s\t%s\t%s\n' "$fam" pending "$dur" "${done_n}/${total} cases (shard continues)" "$(date -u +%FT%TZ)" >> "$LEDGER"
        log "family $fam -> pending (sharded ${done_n}/${total}, window spent)"
        return 1
    fi
}

launch_family() { # $1 = family, $2 = remaining budget -> routes whole vs sharded
    local fam="$1" remaining="$2" est="$(estimated_duration "$1")"
    local t
    t="$(family_timeout "$fam")"
    if [ "$remaining" -gt 0 ] && [ "$est" -gt "$remaining" ]; then
        run_family_sharded "$fam" "$remaining"
    else
        run_one_family "$fam" "$t"
    fi
}

run_one_virtual() { # $1 = libs|doc|audit
    local v="$1" t start status out counts ec
    t="$(family_timeout "$v")"
    start=$SECONDS
    case "$v" in
        # --workspace: without it cargo selects only the root package —
        # the r167 coverage hole (58 of 823 lib cases; 0 of the doc tests).
        libs)  out="$(timeout "$t" cargo test --release --workspace --lib 2>&1)"; ec=$? ;;
        doc)   out="$(timeout "$t" cargo test --release --workspace --doc 2>&1)"; ec=$? ;;
        audit) out="$(timeout "$t" cargo run --release --example stage0_gate_audit_r1 2>&1)"; ec=$? ;;
        *) die "unknown virtual '$v'" ;;
    esac
    local dur=$((SECONDS - start))
    counts="$(printf '%s\n' "$out" | grep -E '^test result:|live cases|retired' | tail -1)"
    if [ $ec -eq 124 ]; then
        status=timeout
    elif [ "$v" = audit ]; then
        # The audit example is a pass/fail program: exit code is the verdict.
        if [ $ec -eq 0 ]; then status=green; else status=red; fi
        counts="exit=$ec"
    elif [ $ec -eq 0 ] && printf '%s\n' "$out" | grep -qE '^test result: ok'; then
        status=green
    else
        status=red
    fi
    printf '%s\t%s\t%s\t%s\t%s\n' "$v" "$status" "$dur" "${counts:-<no-summary>}" "$(date -u +%FT%TZ)" >> "$LEDGER"
    record_duration "$v" "$dur"
    log "virtual $v -> $status (${dur}s)"
    [ "$status" = green ]
}

mark_pending_if_absent() { # $1 = family — no-op if any row already exists
    local fam="$1"
    [ -n "$(ledger_status_of "$fam")" ] && return 0
    printf '%s\t%s\t%s\t%s\t%s\n' "$fam" pending 0 - "$(date -u +%FT%TZ)" >> "$LEDGER"
}

# Fit-aware packing: the chunk window is a HARD ceiling (chunked-foreground
# discipline, window doc §3.4) and ledger rows are only written AFTER a
# family completes — launching a family that cannot finish inside the
# window would waste the run. Expected duration = last known duration,
# 180s conservative default for unmeasured families; a family that does
# not fit is marked pending for the next chunk (smaller ones may still fit).
estimated_duration() { # $1 = family -> seconds
    local d
    d="$(known_duration "$1")"
    [ "$d" -gt 0 ] 2>/dev/null || d=180
    echo "$d"
}

cmd_run() {
    local tier=T2 resume=0 force=0 maxtime=0 buildonly=0 skipbuild=0
    while [ $# -gt 0 ]; do
        case "$1" in
            --tier) tier="$2"; shift 2 ;;
            --tier=*) tier="${1#--tier=}"; shift ;;
            --resume) resume=1; shift ;;
            --force) force=1; shift ;;
            --max-time) maxtime="$2"; shift 2 ;;
            --max-time=*) maxtime="${1#--max-time=}"; shift ;;
            --build-only) buildonly=1; shift ;;
            --skip-build) skipbuild=1; shift ;;
            *) die "unknown run flag '$1'" ;;
        esac
    done
    tier_rank "$tier" >/dev/null # validate label early

    mkdir -p "$LEDGER_DIR"
    : >> "$BATCH_LOG"

    # Build once, run many (nextest precedent): the no-run pass compiles every
    # test target; subsequent per-family invocations reuse the cached binary.
    # --build-only makes the build its own chunk; --skip-build reuses an
    # already-warm tree (chunked-foreground workflow).
    if [ $buildonly -eq 1 ] || [ $skipbuild -eq 0 ]; then
        log "phase 1/3: cargo test --release --no-run (build once)"
        cargo test --release --no-run --all-targets >> "$BATCH_LOG" 2>&1 \
            || die "build phase failed — see $BATCH_LOG"
    else
        log "phase 1/3: build skipped (--skip-build — tree assumed warm)"
    fi
    if [ $buildonly -eq 1 ]; then
        log "build-only chunk complete"
        exit 0
    fi

    log "phase 2/3: fingerprint + ledger"
    if [ $force -eq 1 ] || ! state_matches; then
        if [ -f "$LEDGER" ]; then
            cp "$LEDGER" "$LEDGER_PREV"
            log "fingerprint changed (or --force): ledger archived to ledger.prev.tsv"
        fi
        : > "$LEDGER"
        rm -rf "$LEDGER_DIR/progress"
        fingerprint_state > "$STATE_FILE"
    fi
    if [ $resume -eq 0 ] && [ $force -eq 0 ] && [ -s "$LEDGER" ]; then
        log "existing ledger under the same fingerprint; pass --resume to skip green families, --force to restart"
    fi

    # Selection: real families + virtuals for the tier.
    local selected=()
    mapfile -t selected < <( { families_at_or_below "$tier"; virtuals_at_or_below "$tier"; } )

    # Smart ordering (lit --order=smart analog): carry-over red/timeout/
    # stale-running families first (running = a previous chunk was killed
    # mid-family — the very failure mode this engine exists to defeat),
    # then slowest-known-first among the rest.
    local ordered=() fam st
    local pending_red=() rest=()
    for fam in "${selected[@]}"; do
        st="$(ledger_status_of "$fam")"
        if [ "$st" = red ] || [ "$st" = timeout ] || [ "$st" = running ] || [ "$st" = pending ]; then
            pending_red+=("$fam")
        elif [ "$resume" -eq 1 ] && [ "$st" = green ]; then
            continue # resume skips green families under the same fingerprint
        else
            rest+=("$fam")
        fi
    done
    # slowest-known-first among rest (unknown duration = 0 = tsv order stable)
    mapfile -t rest < <( for fam in "${rest[@]}"; do printf '%s\t%s\n' "$(known_duration "$fam")" "$fam"; done \
        | sort -t$'\t' -k1,1nr -k2,2 | cut -f2- )
    ordered=("${pending_red[@]}" "${rest[@]}")

    log "phase 3/3: ${#ordered[@]} family/virtual runs (tier=$tier, resume=$resume, max_time=${maxtime}s)"
    local batch_start=$SECONDS overall=0 f remaining est
    for f in "${ordered[@]}"; do
        if [ "$maxtime" -gt 0 ]; then
            remaining=$((maxtime - (SECONDS - batch_start)))
            if [ "$remaining" -lt 30 ]; then
                log "chunk budget nearly spent — marking unstarted families pending"
                for g in "${ordered[@]}"; do mark_pending_if_absent "$g"; done
                overall=1
                break
            fi
            est="$(estimated_duration "$f")"
            # Routing: real families above the 300s whole-run cap go to the
            # sharded runner (a family larger than the window with no ledger
            # row on death = infinite retry loop; sharding always progresses).
            # Virtuals are single cargo faces — no shard path exists, so they
            # whole-run whenever they fit the remaining budget (the r167
            # virtual-deadlock: audit at est 379s was parked pending forever
            # by the family cap).
            case "$f" in
                libs|doc|audit)
                    if [ "$est" -gt "$remaining" ]; then
                        mark_pending_if_absent "$f"
                        continue
                    fi
                    ;;
                *)
                    if [ "$est" -gt "$remaining" ] || [ "$est" -gt 300 ]; then
                        run_family_sharded "$f" "$remaining" || overall=1
                        continue
                    fi
                    ;;
            esac
        fi
        case "$f" in
            libs|doc|audit) run_one_virtual "$f" || overall=1 ;;
            *) run_one_family "$f" "$(family_timeout "$f")" || overall=1 ;;
        esac
    done

    # Summary face (machine-readable single line + human table).
    # Last-row-per-family semantics: the ledger is append-only, so the
    # FIRST row of a family is its OLDEST state — counting those (the r167
    # first-row bug) reported long-resolved reds as current.
    local green_n=0 red_n=0 to_n=0 pend_n=0 run_n=0
    while IFS=$'\t' read -r g st _d _c _ts; do
        case "$st" in green) green_n=$((green_n+1)) ;; red) red_n=$((red_n+1)) ;;
            timeout) to_n=$((to_n+1)) ;; pending) pend_n=$((pend_n+1)) ;;
            running) run_n=$((run_n+1)) ;; esac
    done < <(awk -F'\t' '{last[$1]=$2} END {for (f in last) print f "\t" last[f]}' "$LEDGER")
    log "SUMMARY tier=$tier green=$green_n red=$red_n timeout=$to_n pending=$pend_n running=$run_n"
    exit $overall
}

cmd_list() {
    local tier=T2
    while [ $# -gt 0 ]; do
        case "$1" in
            --tier) tier="$2"; shift 2 ;;
            --tier=*) tier="${1#--tier=}"; shift ;;
            *) die "unknown list flag '$1'" ;;
        esac
    done
    printf 'tier %s selection:\n' "$tier"
    families_at_or_below "$tier" | sed 's/^/  /'
    virtuals_at_or_below "$tier" | sed 's/^/  [virtual] /'
}

cmd_status() {
    if [ ! -f "$STATE_FILE" ]; then
        echo "no ledger yet — run the batch first"
        exit 0
    fi
    echo "fingerprint:"; sed 's/^/  /' "$STATE_FILE"
    if state_matches; then echo "  (matches current tree — resume is valid)"; else
        echo "  (STALE — fingerprint differs; next run archives the ledger)"; fi
    echo "ledger (last status per family):"
    awk -F'\t' '{st[$1]=$2; du[$1]=$3; cn[$1]=$4} END {for (f in st) printf "  %-32s %-8s %5ss  %s\n", f, st[f], du[f], cn[f]}' "$LEDGER" 2>/dev/null \
        || echo "  (empty)"
}

case "${1:-}" in
    list) shift; cmd_list "$@" ;;
    run)  shift; cmd_run "$@" ;;
    status) cmd_status ;;
    *) sed -n '2,30p' "$0" | grep -E '^#' | sed 's/^# \{0,1\}//'; exit 2 ;;
esac

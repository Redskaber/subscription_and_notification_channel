# W-ROW-POLY 行多态窗——可扩展记录 + 行基效应追踪的类型基础（登记→实施）

> **Status**: **OPEN @ r181**（开窗行权轮——触发器①链式达成〔用户指令⑥显式排期信号〕+ 前置门四件全过 + 本档 v1.0 落档 + 刀序排期；G8 后自由排期区首个实施窗 = r174 oracle 冻结裁定的**首个适用者**——新语言表面特性停止 oracle 共同实现义务，验证 = 金档期望 + fixpoint + audit 三面）
> **流程权威**: docs/sop.md v15.6（§21.7-§21.9 能力引入成熟度匹配 / §21.12-28 自举完备优先 / §2.2 原则 26·35 / §13.1 设计对齐 / §3.3 演进提案）
> **依据**: 用户指令⑥（「规划完整 kerf 目标语言完整语法语义等方面的完整落地纳入计划」= 矩阵 §11 优先级 2 效应族六实例的显式排期请求信号）+ 指令⑩（完整完全自举首要——行多态在**自举生产位**实施）+ GZ-5 评估档案（w-lang-foundation-window.md §11.2——四触发器 + 四前置门单源）；知识检索件 = tool-results/r181-search/（六检索——五范式家族取样）
> **职责边界**: 本档承载 W-ROW-POLY 的裁定、刀级 MUV 排期与效应族链首段定位；行类型算法规范单源 = 本档 §5（实施细节回归各刀映射节）；效应族链全链排期 = bootstrap-completion-plan §3（181-c 共变）

## 1. 一行定位

效应族六实例（Read/Write/State/Async/Error/Log——stage0 §9.14.2）进入实施排期（用户指令⑥）后，其**类型基础 = 行多态**（row polymorphism：行基效应追踪 + 可扩展记录）成为链式首段——本窗把行类型从登记态交付为**自举生产位生产能力**（infer.ktf 行合一 + 开放记录 unify），使「完整完全自举」在类型系统扩展面上延续：**新特性由自举语言自己实现，而非回退宿主语言**。

## 2. 成熟度口径（现状 + 前沿对照）

| 面 | kerf 现状 | 优秀语言参照（r181-search） |
|---|---|---|
| 类型推断架构 | HM 单态推断 + Dyn 保守纪律（r170 成本触发器口径）+ struct/enum 名义封闭 + GZ-2/GZ-3 透明展开；生产位 = infer.ktf（.ktf 孪生，W 机 M50 ti_unify_step） | OCaml（poly variants = 行对偶，**子类型式**）/ Koka（行效应 + duplicate labels）/ PureScript（**约束求解式** rows）/ Unison（abilities 行基集合语义） |
| 行合一算法 | 无（类型标签 = 裸串 + pair 嵌套复合；unify = 工作表机 + 标签分派臂） | **Leijen 2005 scoped labels**：「adds little complexity to the classic Hindley-Milner type inference algorithm by **only affecting unification**」——行合一重写规则（标签匹配同位合一 / 不匹配下钻 / 尾变量绑定 / lacks 约束守卫） |
| 可扩展记录 | struct 单构造子名义封闭（GZ-2 pair 链 + 零位移字段公式）——开放记录需求触发器③曾评估「不能承载」维持零信号 | OCaml object rows / PureScript record concatenation（行变量减少约束数）/ extensible records with scoped labels（first-class labels 为 P3 研究前沿） |
| 成熟度分级 | ⚠️ **早期实践维持**（GZ-5 §11.2 口径：OCaml 5 无效应安全 / Koka·Unison 早期非主流规模） | 原则 26 三级匹配 → **P1/P2 处理程度**：P1 = 行类型 + 行合一 + 开放记录 unify（核心机制生产就绪面）；P2 = 行基效应追踪接口（效应族窗消费的形状冻结）；不做 = duplicate labels（Koka 特化）/ first-class labels / 行 kind 系统全量（P3 研究前沿） |

## 3. 时机触发器（四件——①链式达成 @ r181）

| # | 触发器（GZ-5 §11.2 原文口径） | 状态 |
|---|---|---|
| ① | 需求触发器：效应族六官方实例任一进入实施排期（行基效应追踪为其类型基础——前置依赖关系成立） | **✓ 链式达成 @ r181**：用户指令⑥「规划完整 kerf 目标语言完整语法语义等方面的完整落地纳入计划」= 效应族六实例**显式排期请求**（矩阵 §11 优先级 2 信号源条款原文「信号源 = 用户显式排期请求」）→ 效应族进入实施排期 → 本触发器达成 |
| ② | 成熟度触发器：行多态生产证据升级（≥2 门主流规模语言生产采用） | 零信号维持（早期实践维持——§2 口径） |
| ③ | 替代路径触发器：可扩展记录需求出现在语料且 struct 不能承载 | 零信号维持（GZ-2/GZ-3 承载维持） |
| ④ | 成本触发器：Dyn 退化损耗实测超过行多态实现成本 | 零信号维持（calibration-data 未超阈值） |

> 任一达成即可开窗（GZ-5 §11.2 原文「任一达成才考虑开窗」）——①已独立达成，②③④维持登记态观测。

## 4. 开窗前置门（四件——全过 @ r181）

1. **§3.3 演进提案过会**：本档 = 提案本体（一行定位 §1 + 成熟度口径 §2 + 算法裁定 §5 + 刀序 §6 + 出口判据 §7）；委员会投票在 r181 close 轮执行（纯文档开窗轮 r164/r174 同型先例——5.5/5.5 形制）。
2. **知识搜索先行**：✓ tool-results/r181-search/ 六检索存档（五范式家族取样——ML/行效应/约束求解/代数效应/理论源头；原则 35 判据先于先例 + 否决记录保留：约束求解式否决〔侵入面大于合一式〕+ 子类型式否决〔偏序复杂度，HM 全量推断保留前提不采〕）。
3. **8 原语不变性核对（第 138 轮——设计面）**：行类型 = **类型层扩展**（Type 新构造子形态 `("row" ...)` + 行合一算法臂），零值层原语 / 零新内建 / 零通道 / 零 VM / 零操作码——核心 8 原语不变性保持；语言语法零变更（行类型 = 数据表示非语法面——.ktf 中 `("row" ((l T)...) tail)` 为 pair 嵌套复合，与 `("struct" name (T...))` 同族）。
4. **孪生可表达性评估**：✓ 可行——infer.ktf 镜像面勘定（r181 实测）：行合一 = `match first` 标签分派（M50 同族）+ lacks 检查守卫（`if` + 标签表遍历）+ 尾变量绑定（`ti_unify_bind_var` 复用）+ 递归下钻（`rest_work` 工作表机制复用）——**18 内建可表达面内**，无超出现有表面族的语言需求。

## 5. 表示与算法裁定（ARCH-A @ r181——判据先于先例）

### 5.1 行类型表示

- **.ktf 生产位**（infer.ktf）：`("row" ((l1 T1) (l2 T2) ...) tail)`——标签-类型对列表 + 尾行（尾 = 行变量 `("var" i)` 或封闭 `nil`）；与既有 `("struct" name (T...))` / `("pair" a b)` / `("fn" (params) ret)` 同族（pair 嵌套复合，裸串标签头）。
- **Rust oracle 面**：**零改动**（r174 冻结裁定——oracle 冻结于 v0.125.0 语言面，W-ROW-POLY = 首个适用者；既有 oracle 对 `("row" ...)` 形态按未知复合处理 = 既有语料回归零影响面）。

### 5.2 算法路线选择（否决记录保留）

| 路线 | 裁定 | 判据 |
|---|---|---|
| **合一式（scoped labels 形）** | **✓ 采纳** | 侵入面最小（only affecting unification——m6 锚）；与现有 ti_unify_step 工作表机架构同族正交贴合；HM 全量推断保留 |
| 约束求解式（PureScript 路线） | ✗ 否决 | 需约束生成/求解双机，侵入面大于合一式；HM 单机架构下非最优（§12 架构基线维度） |
| 子类型式（OCaml poly variants 实际路线） | ✗ 否决 | 偏序关系复杂度；HM 全量推断保留前提下不采 |

### 5.3 行合一核心规则（Leijen 2005 重写规则——m6 锚 + Koka m2 交叉）

1. **标签匹配**：`("row" ((l τ) r))` 与行 `s` 合一时，先把 `s` 重写为 `("row" ((l τ0) s0))` 形式（标签 `l` 在 `s` 的标签表中定位→同位合一 τ≡τ0 + 余行递归 `r≡s0`）；`s` 中无 `l` 且 `s` 尾开放 → 重写为 `("row" ((l fresh) s'))`（标签前插）。
2. **lacks 守卫**：尾变量绑定前检查 `l ∉ 余行标签集`（循环不变量——标签表遍历守卫）；违反 = unify-err（行冲突诊断）。
3. **尾变量绑定**：行变量与行合一时复用 `ti_unify_bind_var`（var 域绑定机既有面）。
4. **封闭行**：`nil` 尾与开放行合一 = 尾变量绑定后封闭（写入时检查 lacks）；封闭∩封闭 = 标签集精确匹配。
5. **透明展开维持**：struct/enum 透明展开臂（GZ-2/GZ-3）与行臂正交——struct 保持名义封闭（行多态不改变 struct 语义；开放记录 = 行类型独立承载）。

### 5.4 处理程度分级（原则 26——早期实践 → P1/P2）

- **P1（生产就绪面）**：行类型表示 + 行合一五规则 + 开放记录 unify + 行变量泛化/实例化（generalization 面行变量处理）。
- **P2（接口预留面）**：行基效应追踪接口（effect row 形状冻结——`("row" ((eff opT)...) tail)` 效应行形态 = 效应族窗消费位；零功能实现，类型形状 + 消费面文档锚）。
- **不做（P3 研究前沿）**：duplicate labels（Koka 特化）/ first-class labels / 行 kind 系统全量 / 多态记录更新语法糖。

## 6. 刀级 MUV 排期（最小先行 + 逐刀金档/fixpoint 门）

> **r174 冻结裁定首个适用**：每刀验证 = ①新语料金档（行钉死期望——rustc UI 同型）②fixpoint 三阶段（.ktf 自编译含行合一代码——Go 三轮自检同型）③既有 parity sweep 族回归全绿（oracle 冻结面守护）④audit 例程扩展。**零 oracle 共同实现**。

| 刀 | 对象 | 内容 | 验收门 |
|---|---|---|---|
| 刀 1 | infer.ktf（4,512 @ r180） | **类型层内核**：`("row" ...)` 类型表示 + ti_unify_step 行合一臂（五规则：标签匹配重写 / lacks 守卫 / 尾变量绑定 / 封闭行 / 诊断）+ 泛化/实例化面行变量处理 + Display 面行格式；a-MUV = 算法映射表落档（本档 §8 扩展） | **✅ DELIVERED @ r182**（infer.ktf 4,512→4,860；映射表 §8.1 RW-1..RW-11 全条目 ✓；金档 24 案 1:3 + 既有 parity sweep 回归全绿 + fixpoint 三阶段位级一致 + hm_twin_face/twin_chain 扩展 case + fresh T2 64/64 + oracle 冻结机检零文件） |
| 刀 2 | target-parser.ktf（4,424）+ expander.ktf（4,850） | **读链 + 展开器消费面**：行类型注解解析（`[l: T \| r]` 表面形——语法面最小扩展）+ 开放记录消费脱糖（字段访问 / 记录扩展 / 行消解到既有 car/cdr^i 零位移公式或行操作内建面裁定——a-MUV 详裁） | 金档扩展（注解语法正负例 + 记录扩展程序）+ expand/read segment switch 扩展 + parity 回归 + fixpoint |
| 刀 3 | 语料 + audit 面 | **语料族 + 效应前置接口**：行多态程序族（可扩展记录组合 + 行参数化函数 + 金档钉死）+ P2 效应行形状冻结落档（`("row" ((eff opT)...) tail)` 消费位文档锚 + 类型形状测试）+ audit 例程扩展（460→N） | 金档全量（正负比 1:3 + 7 类错误 ≥6 类负向覆盖）+ T2 全量（63 族 + audit live EXIT 0）+ 效应族窗开窗就绪宣告 |
| close | 窗口收口 | 出口判据六条核对 + 文档共变链（矩阵 + completion-plan + tech-debt + roadmap + 转化台账 + RELEASE_NOTES）+ 金链 v0.132.0+ | 出口六条 ✓ → W-ROW-POLY CLOSED + 效应机制窗（链中段）就绪宣告 |

## 7. 出口判据（窗口 CLOSED 六条）

1. 行类型表示 + 行合一五规则在**自举生产位**（infer.ktf）全量交付（P1 面）。
2. 新语料金档全绿（正负比 ≥1:3 + 7 类错误 ≥6 类负向覆盖）。
3. 既有 parity sweep 族回归全绿（oracle 冻结面零破坏——r174 裁定守护）。
4. fixpoint 三阶段位级一致（自编译含行合一代码——自举最深自引用面维持）。
5. P2 效应行接口冻结落档（效应族窗消费位形状 + 文档锚）。
6. 文档共变链全量（矩阵 §4 行多态行 状态翻转 登记→✓ + 计数共变 + completion-plan 效应族链首段 ✓ + tech-debt r 检视 + roadmap + 转化台账入账义务）。

## 8. 零载荷边界与效应族链定位

- **零载荷声明**（开窗轮 @ r181）：开窗轮零机制变更义务（§2.2 原则 38/44-58 同族纪律）；**刀 1 开工 @ r182**——本节自刀 1 起承载实施映射表（§8.1，窗口档 §6 刀 1 行 a-MUV 义务）。

### 8.1 刀 1 实施映射表（r182-a 落档——W 机行合一臂 + 三 walk 机族 + spec 机 + Display 面）

> 形制 = W-SELFHOST-MODERN 窗口档 §14 映射表先例（a-MUV 裁定落档 → b-MUV 对账单源）；编号空间 RW-1..RW-11（本窗自有，不与 M# 空间混编）。

| # | 对象（infer.ktf 位点） | 映射内容（b-MUV 对账单源） |
|---|---|---|
| RW-1 | 类型表示（新构造子） | `("row" ((l1 T1) (l2 T2) ...) tail)`——标签-类型对列表 + 尾；tail ∈ {`nil`（封闭·GZ-2 空结构同值共享，语境分派）/ `("var" i)`（开放行变量）/ `("row" ...)`（重写余行）}；**零字段壳保留**（("row" nil-fields tail) 不化简——unify 臂单一形态纪律）；标签 l = 裸串；与 tdef 第四域 effects 裸名列表**形态正交**（tagged 复合 vs 裸列表——零命名冲突，§5.1 裁定维持） |
| RW-2 | spec 机（ti_resolve_spec "spec" 模式头分派加 `"row"` 臂——M52 同族） | `(row (l T)... tail)` spec：字段 `(l T)` 二元对逐一经 "spec" 递归；尾 `nil` → 封闭 / `_` → 开放（ti_fresh 行变量）/**缺尾、名字尾（非 nil 非 `_`）、重复标签、字段非二元对 → 整体降 `"dyn"`**（GZ-1「unresolvable spec degrades to Dyn」保守规则同族——零新错误路径） |
| RW-3 | W 机（ti_unify_step 复合分派加 `"row"` 臂——M50 同族） | b 侧前置 `not(is_pair(b))` 守卫（r127 car-on-string 崩溃面同族纪律）→ mis；`"row"×"row"` → ti_unify_row（RW-4）；`"row"×其他复合`（struct/enum/pair/fn）→ mis（§5.3 规则 5 正交维持——struct 名义封闭不被行臂展开，开放记录由行类型独立承载）；dyn 前置吸收 / var 前置绑定**维持不动**（row × dyn 吸收、var × row 绑定+occurs 下钻走既有前置臂） |
| RW-4 | ti_unify_row 工作表机（§5.3 五规则的迭代工作表形——零深自递归，A6 纪律） | ① **标签匹配重写**：a 首标签 l 在 b **全表**提取（ti_row_extract——保序去除，命中 (l τ0) 余字段；**hit 是 (field . 余表) 点对——余表取 rest(hit)，取 ti_2 是 car-on-nil 崩溃面〔r182-b 内循环第 4 轮立捕〕**）；命中 → push (τ≡τ0) + push (余a ≡ 余b)；未命中且 b 尾 var ρ → **ρ 扩展绑定**（ρ := ("row" ((l fresh)) ρ')，ρ' 新鲜——Leijen 重写规则的绑定形；类型 fresh 先、行尾 fresh 后）+ push (余a ≡ ρ')；② **lacks 守卫**：未命中且 b 尾封闭 nil → mis（**余行级记录**——r182-c 实勘裁定：expected/found 骑余行/字段位〔`(row)` vs `(row y bool)` 点名冲突字段——Leijen 精确诊断面，优于原始整记录〕）；③ **封闭行**：a 字段尽尾 nil——b 余 nil → 继续 / b 余字段 → mis（余行级）/ b 余 var → bind var := nil（封闭化）；④ **尾变量绑定**：a 字段尽尾 var ρ——b 余 nil → bind ρ := "nil" / b 余 var σ → var-var 绑定（ti_unify_bind_var 复用）/ b 余 row → bind ρ := b 余行（occurs 守卫复用；**空字段面尾透传——零字段壳永不入绑定**）；⑤ 诊断 = mis 复用（零新诊断码——E0009/E0013 族 expected/found 双面渲染可判别） |
| RW-5 | 四 walk 机族 "row" 臂（ti_varocc_walk / ti_subst_walk / ti_occurs_walk / ti_resolve_walk——M51 walk 族同族） | 字段 T **左到右先、尾后**（varocc 首见序——金档钉死）；subst 尾 var 查表替换（**共用 var 空间裁定**：行变量 = 使用位的普通 ("var" i)，零新值域——8 原语不变性第 139 轮设计面维持）；occurs 字段+尾递归（防循环行）；resolve 字段+尾深度解析（tdef schema body 输出面） |
| RW-6 | 泛化/实例化（ti_generalize / ti_instantiate） | **零新增函数**——RW-5 机族扩展即达（varocc 下钻自动捕获行变量入 schema vars；subst 下钻自动实例化 fresh——HM let-多态对行变量全量生效，P1「行变量泛化/实例化」验收点） |
| RW-7 | Display 面（宿主解码基建 twin_type_display 加 "row" 臂——**验证面扩展非 oracle 语义**） | 封闭：`(row (l T) (l2 T2))` / 空 `(row)`；开放：`(row (l T) \| tN)`（尾 var 显示 t{index}——var 显示惯例对齐）；宿主渲染模板零改动（mis 的 expected/found 复用——类型参数渲染走本臂） |
| RW-8 | oracle 零改动**精确口径**（r174 冻结裁定首个适用者的机检边界） | `git diff crates/kerf-typecheck/` **零文件**（oracle 语义本体冻结机检）；`crates/kerf-driver/` 解码器 = 验证基建允许扩展（RW-7 臂 + 金档测试挂载）；`tests/` = 金档新文件；既有主 corpus parity sweep（170 案）**零扰动**——row 语料不入主库（oracle Dyn ≠ twin row，parity 断言豁免面） |
| RW-9 | 金档落位（r174 裁定「金档期望 rustc UI 同型」） | **皮肤层勘定（r182-a 实勘披露）**：现有 target 皮肤 spec 语法无法产生 `"row"` 头——`parse_type_spec` 的 `(` 分支一律 `tuple` 头、`path(args)` 分支一律 `app` 头（crates/kerf-reader/src/target/parser.rs 实测勘定）→ **刀 1 金档 = 数据构造形**（测试文件内 (name, items, expected) case 表：Rust 直构 `ModuleItem::Annotate { spec: row LiteralValue }` + Define 体，喂 SteadyTypecheckChain，钉死 decode 输出——paired_drive 的 items 注入先例；正例钉完整 tdef schema 显示串含 row 形，负例钉诊断码 + expected/found 渲染）；`corpus-row/` 源码语料目录 = **刀 2 交付物**（`[l: T \| r]` 皮肤就绪后源码语料入位）；hm_twin_face/twin_chain 扩展 = **新测试函数**钉死断言（row 边界 case），不入 PAIRED_PROBES parity 族（twin ≡ oracle 断言只覆盖 oracle 冻结面） |
| RW-10 | 边界勘定 | ① 空开放行 (row _) × 非空封闭 = 通过（尾绑封闭余——正例族 503 对偶面）；② 行尾域违反动态兜底 = mis（P1 无静态 kind 检查——构造纪律 + 动态收敛，永不 crash）；③ 行字段表遍历 = 列表递归（P1 语料规模内 + fixpoint 自应用实测兜底——深行超千字段非 P1 面向）；④ 重复标签/名字尾/缺尾 spec 降 Dyn 后 Dyn 吸收通过 = **保守边界正例**（钉死语义防静默漂移） |
| RW-11 | tamper 针清查 | 新增代码零 E00/tdef 针形态（banned-token 零交集——r180 §14 同型机检口径）；行诊断复用 mis 模板（零新诊断码 = 零新模板面） |

- **§8.1 对账回填（r182-b/c）**：RW-1 ✓（零字段壳保留）/ RW-2 ✓（row 三模式 + 保守降级族全落地）/ RW-3 ✓（r127 守卫同族）/ RW-4 ✓（五规则机——**两处实勘披露**：hit 点对余表取 rest(hit) 非 ti_2〔car-on-nil 内循环立捕〕；lacks 诊断骑余行/字段位〔Leijen 精确诊断面，措辞已随实勘修正〕）/ RW-5 ✓（四机族 + 首见序钉死）/ RW-6 ✓（零新增函数——跨 define 实例化钉 schema vars 捕获）/ RW-7 ✓（显示形 `(row x int | tN)`）/ RW-8 ✓（kerf-typecheck 零文件机检）/ RW-9 ✓（数据构造金档 + 皮肤层实勘披露 + cross-route/豁免面）/ RW-10 ✓（四边界全钉）/ RW-11 ✓（零新诊断码）；偏差零——全部实勘均当轮披露当轮采纳。
- **效应族链三段**（completion-plan §3 单源——181-c 共变）：**W-ROW-POLY（本窗·链首段·类型基础）→ 效应机制窗（链中段·handler/perform 语义 + 效应行推断消费）→ 效应族实例窗（链末段·Read/Write/State/Async/Error/Log 六实例）**——本窗 CLOSED = 效应机制窗开窗前置就绪（链式推进）。
- **正交窗对账**：W-LINEAR-TYPES（L3 授权层）与本窗正交（r172 裁定维持）；W-UNION-INTERSECT 与本窗正交（行类型 ≠ 联合类型——标签积 vs 无标签和）；W-COMPTIME 与本窗正交（求值时机 vs 类型结构）。
- **S-expr 政策对账**：行类型表示 = .ktf 目标语言 pair 复合（裸串标签 + pair 嵌套）——**非 S-expr 延续**（S-expr 表面四层已拆 @ r149-r160；本窗刀 2 的 `[l: T | r]` 注解表面 = 目标语言皮肤字典内新条目，20-surface-conventions R1-R6 管辖）。

# kerf 目标语言能力统计矩阵（language-capability-matrix.md）

> **Status**: v1.10（r182 W-ROW-POLY 刀 1 实施轮：§4 行多态行 进度注记〔刀 1 DELIVERED @ r182——类型层内核全量落地自举生产位：行类型 pair 复合表示 + 行合一五规则机 + 四 walk 机族 row 臂 + 泛化/实例化行变量生效（schema vars 捕获）+ Display 面 row 臂；金档 24 案 1:3 + fresh T2 64/64 + oracle 冻结机检零文件（r174 裁定首个适用者执行）；窗口 OPEN 维持——刀 2/刀 3 待做〕+ §7 自举台账行实测口径更新〔21,445→21,793——infer.ktf 4,512→4,860 行代数内核 +348〕）；v1.9（r181 §17 Step 1 扫描轮 + W-ROW-POLY 开窗行权轮 + 完整落地总规划轮——用户指令⑥「规划完整 kerf 目标语言完整语法语义等方面的完整落地纳入计划」显式排期信号：①**§4 行多态行 注记升级**〔登记〔实施窗 OPEN @ r181〕——触发器①链式达成：效应族进入实施排期 = GZ-5 需求触发器①；前置门四件全过（r181-search 六检索五范式家族 + §3.3 提案 + 8 原语第 138 轮 + 孪生可表达性 ✓）；r174 冻结裁定首个适用者——oracle 零改动，金档/fixpoint/audit 验证；窗口 CLOSED 时本行翻 ✓〕；②**§11 优先级重排**〔W-ROW-POLY 升首位实施窗 + 效应族三段链第 2 位（段 2 效应机制窗 + 段 3 效应族实例窗——completion-plan §3 单源）+ W-SELFHOST-MODERN 移出（CLOSED 入 §7 台账）〕；③计数 91 项维持〔✓58/冻结6/登记15/缺失12——实施窗 OPEN 不改登记列计数，窗口 CLOSED 翻 ✓ 时共变〕）；v1.8（r180 W-SELFHOST-MODERN 刀 6 收官 + 窗口 CLOSED 轮：§7 自举台账行实测口径更新〔21,382→21,445——现代化刀 6 收官双件表示恒等重写，infer 4,471→4,512 + target-parser 4,402→4,424〕+ 现代化行 ✓ 终态翻正〔窗口 CLOSED——12/12 全上 G8 表面；W 机核心 M50 + 帧机 M59 + 守护相位机族 M60 + token/datum 表 M61 + 注解族 M57/M64——tp_ha/tp_ma nil 占位与 ti_member/ti_row_push 混合域经 checker 立捕诚实裸名〕+ §11 优先级 1 位 CLOSED 注记 + §7 注记中 v1.7 头漏〔r179 实况漂移——本行清偿：r179 矩阵体更新已落（刀 5 行 + 21,382 台账），Status 头漂移未记 v1.7，本轮并入 v1.8 头声明〕）；v1.6（r178 W-SELFHOST-MODERN 刀 4 轮：§7 自举台账行实测口径更新〔21,254→21,274——现代化刀 4 编译面 + 宏面两件表示恒等重写，净 +20〕+ 现代化行刀 4 DELIVERED 进度注记〔窗口 OPEN 维持——四态口径不变，全窗 DELIVERED 后翻 ✓；CP 两遍分派 M31-M36 + 宏库保守面 M37/M38 + 注解族 M39/M40 + 遮蔽族冻结 + fixpoint 载体自应用 17/17〕+ §11 优先级 1 位进度注记）；v1.5（r177 W-SELFHOST-MODERN 刀 3 轮：§7 自举台账行实测口径更新〔21,272→21,254——现代化刀 3 判定面 + 词法面两件表示恒等重写，match 臂化净 −18〕+ 现代化行刀 3 DELIVERED 进度注记〔窗口 OPEN 维持——四态口径不变，全窗 DELIVERED 后翻 ✓；标量 tag 表 M21 + 被调分析 pair 模式 M25 + 算符极长匹配整型臂顶层分派 M27〕+ §11 优先级 1 位进度注记）；v1.4（r176 W-SELFHOST-MODERN 刀 2 轮：§7 自举台账行实测口径更新〔21,186→21,272——现代化刀 2 组合程序族三件表示恒等重写〕+ 现代化行刀 2 DELIVERED 进度注记〔窗口 OPEN 维持——四态口径不变，全窗 DELIVERED 后翻 ✓；struct 型字段首例消费 M13/M14 + 顶层 nil 模式首例 M19〕+ §11 优先级 1 位进度注记）；v1.3（r175 W-SELFHOST-MODERN 刀 1 轮：§7 自举台账行实测口径更新〔21,094→21,186——现代化刀 1 表示恒等重写〕+ 现代化行刀 1 DELIVERED 进度注记 + §11 优先级 1 位进度注记）；v1.2（r174 过时清偿 + 现代化窗登记轮：①两处实况漂移清偿〔selfhost/README.md 七件旧态→十二件实况 21,094 重写 + 转化台账 r160 后 10 轮失账合并补账 17,154→21,094〕②W-SELFHOST-MODERN 登记〔§7 新行——四触发器全达成，六刀序 + oracle 冻结桥终结裁定〕③§11 优先级重排〔现代化窗升首位——自举段最高优先级 §21.12-28〕；v1.1（r172 触发器定义补全轮——决策-实况缺口族三行登记态升级〔交叉/联合 + 线性：缺失→登记〕+ 编译期求值补行〔v1.0 遗漏清偿——§6.10.2 行 6 半承载拆账〕+ 计数 89→90 = ✓58/冻结6/登记14/缺失12 + §11 优先级表重排〔三窗入列 3/4/5 位〕+ §12.4 触发器定义义务闭环转常设；触发器单源 = w-decision-gap-windows.md v1.0；v1.0 = r171 首版——G8 语言基础闭合后首个自由排期点 · §17 Step 1 下一窗扫描的结构化产出）
> **承载**: 用户常设指令④实体——「kerf 目标语言在词法语法语义等编译管道全阶段的对应优秀编程语言对应阶段任务和能力项的完成与剩余统计与记录（以便 agent 或者审批去检查和规划 kerf 目标语言的实施以及是否存在缺失等情况）」
> **流程权威**: docs/sop.md v15.6（**SOP 接入 @ r173 兑现**——六编辑点：Version 头 v15.5 / §8.4.5 查询表新增矩阵行 / §17.2 Step 1 扫描表新增矩阵行 / §8.5 审查清单第 17 项〔每窗开闭必检共变〕/ §21.12 第 34 条〔本矩阵纪律条款〕/ §8.4 目录树补矩阵行；此前 v1.0/v1.1 头部所引「v15.4（§17.2 扫描…§8.4.5 查询表）」系前置规划声明、未伴随 SOP 实体接入——r173 当轮清偿，§8.4.5 规则 2 同型；r174 顺更 v15.5→v15.6〔§3.2.1 收割恢复协议——矩阵轮次验证面执行纪律的流程承接〕）——现行流程面 = §17.2 扫描 / §21 阶段规划 / §2.2 原则 34 能力架构 / §8.4.5 查询表 / §8.5 第 17 项 / §21.12 第 34 条六点
> **单源声明**: 本矩阵 = 能力清单的**汇总视图**（唯一新增职责 = 全阶段完成/剩余统计 + 优先级输入）；各能力项的**实施细节单源**仍为其各自窗口档/规范文档（subset-spec / stage0 §6.10/§9.14.2/§9.15 / 各 w-*-window.md）——本矩阵只引用不重复（§3.3 路由>通读；反重复漂移纪律）。
> **冷启动注记**: lang-design/ 为冷启动降级位（README §0——25 拆分文件不可达，stage0.md 代偿）；本文件为**新建实体**非伪造拆分文件，落位于查询表第一层权威目录（§8.4.5）。
> **宪制排除项**: VM 永久 Rust 基座 / 构建引导层（cargo）/ 链外后端（C/LLVM）——不计入「完全脱离」分母，矩阵中以〔宪制排除〕标注。

## 0. 统计口径

| 状态 | 定义 | 锚要求 |
|---|---|---|
| ✓ 已交付 | 生产位可用且有机检（测试/audit/parity） | 版本号 + 轮次 + 单源文档 |
| ✓ 设计冻结 | 冻结面声明 + 不变性守卫在位（未到实施窗口） | 规范章节 + 守卫锚 |
| 登记 | 独立窗口已登记、触发器定义在案、零信号不开窗 | 窗口名 + 触发器单源 |
| 缺失 | 设计蓝图有决策或同类语言标配、本项目无承载无登记 | 参照锚 + 候选路径 |

维护纪律见 §12：每窗开/闭/DELIVERED 必共变本矩阵（GATE 3 条款引用义务的查询位之一）。

## 1. 词法面（subset-spec §1.4-§1.5 单源）

| 能力项 | 状态 | 交付锚 | 优秀语言参照 | 备注 |
|---|---|---|---|---|
| 字面量 6 种 + 原子 | ✓ 冻结 | subset-spec §1.4；Stage 1 验收语料 68 条 | Scheme/ML 原子面 | 8 原语不变性第 127 轮验证（tech-debt r170） |
| 关键字 token 族（KwStruct/KwEnum 等胖关键字） | ✓ 冻结 | subset-spec §1.1；G1 目标皮肤读链 | —— | 关键字 = 表面 token 非原语面（r168/r170 裁定） |
| 注释文法 | ✓ 冻结 | subset-spec §3.2 分布（注释共变 r170） | C 族行注释 | 单皮肤 .ktf 终态（G7 拆除 S-expr 注释面 r154） |
| 类型注解词法 `: T` 面 | ✓ | 刀 1 @ r165 · v0.121.0 | OCaml/Scala 注解 | parse-and-drop 终结——注解 = 表面糖 HM 层 owns |
| 浮点/字节/字符字面量 | 缺失 | —— | Rust/Go 数值面 | 候选：Int 既有位扩展（零原语约束下 = 词法+内建层扩展）；触发器 = 数值语料需求 |
| 字符串插值 | 缺失 | —— | Rust `format!`/Koka | 候选：脱糖面（format 内建 + 表面糖）；零信号 |

## 2. 语法面（subset-spec §1.1-§1.3 + 派生表面层）

| 能力项 | 状态 | 交付锚 | 优秀语言参照 | 备注 |
|---|---|---|---|---|
| 声明头 4（模块顶层唯一合法形式） | ✓ 冻结 | subset-spec §1.1 | Scheme 模块面 | 冻结纪律 §5 |
| 表达式特殊形式 8 | ✓ 冻结 | subset-spec §1.2 | Scheme 特殊形式族 | —— |
| 核心构造子 9 + 模块项 4 | ✓ 冻结 | subset-spec §1.5 | —— | dstruct/denum = 零码 item（Annotate 先例） |
| struct 声明表面 + 构造/访问脱糖 | ✓ | 刀 2 @ r166 · v0.122.0（GZ-2/GZ-3） | Rust/Haskell record | 「struct = 派生表面非原语面」——pair 链右折零标记 + Type::Struct 名义透明展开 |
| enum 声明表面 + tagged 构造/消费脱糖 | ✓ | 刀 3 @ r168 · v0.124.0（GZ-4） | Rust/OCaml ADT | cons(tag, 右折) + ctor define 单源 + E-Variant 复合名 |
| match 模式文法（variant/struct/字面量/绑定/通配） | ✓ | 刀 3 @ r168 + 刀 4 @ r170 · v0.125.0 | Rust/ML 模式族 | 穷尽性三判式（r170 §11.1）；双查表消歧序（enum→struct→六模式族） |
| 嵌套模式（递归） | ✓ | 刀 4 @ r170（pos-404 嵌套 8 案） | ML 嵌套模式 | 零位移字段公式 car(cdr^k s) |
| 守卫子句（match guard） | 缺失 | —— | Rust `if` guard / Haskell | 候选：脱糖面（if 嵌套展开）；触发器 = 语料需求 |
| 中缀运算符表面 | 缺失（设计排除） | G7 单皮肤裁定 r150-r154 | —— | .ktf 皮肤 = 括号+胖关键字形制；中缀面 = 皮肤域议题（Stage 2b 已被单皮肤终态吸收——不追溯） |
| 自定义效应语法 | 登记 | 窗口档 §4.5 后续行；stage0 §9.15 | Koka `effect`/Unison | 零信号不开窗 |

## 3. 语义面（subset-spec §2 单源）

| 能力项 | 状态 | 交付锚 | 优秀语言参照 | 备注 |
|---|---|---|---|---|
| 闭包词法捕获（完整语义面） | ✓ | Stage 2.1 翻转 v0.50.0 + §2.2 收口 v0.51.0 | Scheme/ML 闭包 | LA-2 捕获描述符 |
| 顺序绑定 define-so-far | ✓ | subset-spec §2.2 | Scheme 顶层序 | —— |
| 顶层即时位效应 | ✓ | subset-spec §2.3 | 脚本语言直译语义 | —— |
| 程序终值与值约定 | ✓ | subset-spec §2.4 | Scheme REPL 值面 | —— |
| 空表与空应用 | ✓ | subset-spec §2.5 | Scheme `()` | —— |
| 卫生宏展开语义 | ✓ | Stage 0.9 + expander 生产位 G4 r145-r149 | Scheme 卫生宏/rustc macro | expander.ktf 4,740 行孪生生产位 |
| 编译期求值（值层 comptime 型面） | 登记 | W-COMPTIME（w-decision-gap-windows §5——四触发器 + 四前置门 @ r172） | Zig comptime/Mojo 参数 | §6.10.2 决策「✅ 实现 Stage 1」——宏展开半面 G4 已交付（语法变换子面 ≠ 值层求值）；矩阵补行 @ r172（v1.0 遗漏清偿）；成熟度已达标（Zig 生产就绪）触发主轴 = 需求面 |
| 尾递归优化语义 | ✓ | C3 r136-r137（G2——堆激活栈 + 深尾递归恒定栈高） | Scheme TCO/chez | 10^5 深非尾递归默认栈实测 |
| 任意递归深度 | ✓ | G2 CLOSED（r136/r137 两刀） | —— | 四层帽 K162 可配置护栏 |
| 求值确定性（fixpoint 位级） | ✓ | K159 不动点 B≡C 位级 8/8 release | bootstrappable builds | r163 验收对账三项之一 |
| 错误处理语义（Fatal 边界 + 用户自定义错误语义） | ✓ 裁定 / 登记 | §9.15 审查六裁定（统一而分治）；自定义错误 = 登记 | Rust Result/OCaml effect | 统一效应模型的设计位——Fatal 边界裁定 ✓，自定义面待效应族窗口 |

## 4. 类型系统（stage0 §6.10 前沿对照 + 刀 1-4 生产面）

| 能力项 | 状态 | 交付锚 | 优秀语言参照 | 设计决策对账（§6.10.2） |
|---|---|---|---|---|
| HM 单态推断（let 多态 + 算法 W 族） | ✓ | infer.ktf 4,471 行生产位（G4）；HM-TWIN CLOSED r131 | OCaml/Haskell HM | —— |
| 类型注解双向检查（标注-推断 unify） | ✓ | 刀 1 @ r165（E0013 第 14 位诊断码） | OCaml/Scala 注解 | 「annotations are surface sugar the HM layer owns」兑现 |
| struct 名义类型（Type::Struct + 透明展开 unify） | ✓ | 刀 2 @ r166（GZ-3） | OCaml record/Rust struct | —— |
| enum 名义类型（Type::Enum 封闭） | ✓ | 刀 3 @ r168 | Rust/ML ADT | —— |
| 穷尽性检查（GZ-4 展开期单段执法） | ✓ | 刀 3/4 @ r168/r170（三判式） | Rust/OCaml match 完备性 | —— |
| 泛型参数化（显式 forall/类型参数） | 缺失 | —— | Haskell/Rust generics | HM 隐式多态承载参数化（let 多态）；显式参数化表面未开——候选：注解面扩展 |
| 行多态（可扩展记录/行基效应） | 登记（**实施窗 OPEN @ r181**；刀 1 DELIVERED @ r182——类型层内核自举生产位落地） | W-ROW-POLY（单源 w-row-poly-window v1.0——触发器①链式达成〔用户指令⑥效应族显式排期〕+ 前置门四件全过 + 三刀序：刀 1 infer.ktf 类型层内核 → 刀 2 读链+展开器 → 刀 3 语料+audit+P2 效应前置；r174 冻结裁定首个适用者——oracle 零改动，金档/fixpoint/audit 验证） | OCaml 5/Koka/Unison/PureScript rows + Leijen 2005 scoped labels（r181-search 六锚） | §6.10.2 决策 = 预留类型系统；成熟度 ⚠️ 早期实践维持（P1 核心机制 + P2 效应行接口分级——原则 26）；窗口 CLOSED 时本行翻 ✓ |
| 交叉/联合类型 | 登记 | W-UNION-INTERSECT（w-decision-gap-windows §3——四触发器 + 四前置门 @ r172） | TypeScript/Flow（表达面生产就绪）/Scala 3 | §6.10.2 决策 = ✅ 实现 Stage 1——实况未实施；登记态升级 @ r172；HM+union 融合推断面 = 早期实践观察位；enum（封闭 tagged union·GZ-4）表达面不重叠 |
| 线性/仿射类型（所有权/I/O 能力模型基础） | 登记 | W-LINEAR-TYPES（w-decision-gap-windows §4——四触发器 + 四前置门 @ r172） | Rust 所有权（生产就绪）/Linear Haskell | §6.10.2 决策 = ✅ 实现 Stage 1——实况未实施；登记态升级 @ r172；L3 授权层（原则 34）链式前置 = 其资源面基础 |
| 渐进类型（Dyn 混合） | ✓ 部分 | HM + Dyn 保守纪律（r170 §11.2 成本触发器口径） | TypeScript/Python hints | Dyn 退化频率 = calibration-data 可测量轴（W-ROW-POLY 触发器④） |
| 依赖类型 + Graded Modal | ✓ 设计忽略 | §6.10.2 决策 = 忽略（复杂度过高） | Agda/Rocq（研究前沿） | 设计蓝图裁定在案——不列实施缺口 |

## 5. 效应与控制（stage0 §9.14.2 成员三组 + §9.15 统一效应模型——登记态全表）

| 能力项 | 状态 | 交付锚 | 优秀语言参照 | 备注 |
|---|---|---|---|---|
| 效应族六官方实例（Read/Write/State/Async/Error/Log） | 登记 | completion-plan §4.5 后续行；§9.14.2 效应成员 | Koka/Unison/OCaml 5 | 各按独立窗单源排期；零信号不开窗（原则 38/44-58） |
| 代数效应 + 处理程序机制 | 登记（接口预留 ✓） | §6.10.2 决策 = 预留接口+实现；Stage 0.10 接口冻结四项之一（effects） | OCaml 5/Koka/Eff | 前置 = 行基效应类型（W-ROW-POLY 联动） |
| 多态效应处理程序 | ✓ 设计忽略 | §6.10.1 成熟度 = 研究前沿 | Plotkin & Pretnar 2009 | —— |
| 能力模型 L3 授权分层（纯度/声明/令牌三态 + fail-closed） | ✓ 设计冻结 / 登记 | 原则 34（v12.2 r33）——J1-J4 正交判据 + 授权三红线设计在案 | ocap（E/Cap'n Proto） | 实施窗未开；线性类型为其资源面基础 |
| one-shot 处理程序纪律 / 效应-语义正交（J2） | ✓ 设计冻结 | §9.15 审查六裁定 | Koka 语义 | —— |

## 6. 资源管理与运行时

| 能力项 | 状态 | 交付锚 | 优秀语言参照 | 备注 |
|---|---|---|---|---|
| 堆激活栈（eval 引擎堆化） | ✓ | C3 r136（G2） | —— | VM 树走解释器 = Rust 基座〔宪制排除〕 |
| 递归深度护栏（四层帽 K162 + with_limit） | ✓ | r137（G2 终态） | —— | env 单源 fail-closed |
| 基础堆回收（VM sweep） | ✓ | VM 基座（B4 gc 1/swept 1023 实测锚） | —— | 〔宪制排除——VM Rust 基座〕 |
| 分代 GC | 登记 | W-GEN-GC（W-3.4 评估窗 @ r119 登记） | JVM/Go/OCaml 分代 | 零信号不开窗 |
| extern/FFI 堆类型句柄协议 | 登记 | W-HEAP-EXTERN（TD-026 闭账承载位 @ r166） | Rust FFI/OCaml ctypes | 触发器 = extern 扩展面需求 |
| JIT（方法级/链内） | ✓ 裁决（链内最优锁定） | W-JIT-METHOD-T1 CLOSED r142（MJ-5/MJ-6） | —— | 链内 = 纯解释 + LLC 最优形态（零 codegen 约束下 27 臂 match）；真 codegen = 链外 W-3.8 |
| 真机器码后端（LLVM/QBE/C 转译） | ✓（链外并存） | kerf-cbackend ✓ + W-3.8 可选位 | LLVM 家族 | 〔宪制排除——链外后端永不入自举链〕 |
| VM 执行核心优化（EXC 族：物化协议单源 + reserve_exact 批处理 + take_args 栈窗口单移动） | ✓ | §9.69（K126-K131）——B2 −13.0%/B5 −12.6% 域主账 | —— | 〔宪制排除——VM Rust 基座〕 |
| 超指令融合（superinstruction） | 登记 | W-VM-SUPERINSTR（§9.69 登记窗） | Lua/LuaJIT 融合指令 | 零信号不开窗 |

## 7. 编译管道与自举面（G1-G8 ✓ 终态——roadmap/completion-plan §2 单源）

| 阶段 | 状态 | 交付锚 | 备注 |
|---|---|---|---|
| 词法/读链（目标皮肤 .ktf） | ✓ | G1 CLOSED r139（target-lexer/target-parser 孪生） | C1 断链闭合 |
| 宏展开 | ✓ | G4 生产位 r145-r149（expander.ktf 4,740 行） | 孪生链 = 生产链 |
| 类型检查 | ✓ | G4 + HM-TWIN r131（infer.ktf 4,471 行） | —— |
| 编译（树→指令） | ✓ | G4（compile 孪生 r124 起） | —— |
| VM 执行 | ✓ | VM 基座 | 〔宪制排除〕 |
| 任意递归深度 | ✓ | G2 CLOSED r137 | —— |
| 生产位切换（四段） | ✓ | T-a CLOSED r149（五步 K159 不动点） | B≡C 位级 |
| S-expr 表面全拆 | ✓ | G7 CLOSED r154（四层全离树） | 单皮肤 .ktf 终态（用户指令⑥） |
| 包管理器自举 | ✓ | G5 CLOSED r160（kp 五模块 .ktf + 三态回退带） | micro-toml/semver/manifest/lockfile/resolve |
| eval 引擎退役 | ✓ | G6 CLOSED r162（用户面 loud-retirement） | 验证面保留（K15 差分承重） |
| 自举完备验收 | ✓ | r163 GO（C1-C4 + D1-D8 深审 + 投票 5.5/5.5） | 完成标准宣告：完全脱离宿主语言（宪制排除项除外） |
| 语言基础完备 | ✓ | G8 CLOSED r170（四刀全交付） | 注解/struct/enum/模式族 |
| fixpoint 自复现 | ✓ | K159 门 8/8 release | 两次编译自身字节一致 |
| 前端自举推进（reader→expander→裁定段） | ✓ | W-3.12/C4 面（段一/二/三 ELEVATED + W-BOOT-FRONTEND 账面清偿 r131） | —— |
| 自举台账 | ✓ | selfhost/v1/ 12 件 .ktf = 21,445 行（12/12 全现代化——r180 现代化刀 6 后实测口径：semver 337 + micro-toml 662 + manifest 525 + lockfile 675 + resolve 517 + typecheck 1,264 + target-lexer 1,069 + compiler 1,877 + macro 733 + expander 4,850 + infer 4,512 + target-parser 4,424——十二件全上 G8 表面，表示恒等重写） | 三落纪律 worklog 全文承载 |
| 自举源现代化（12 件用最新表面重构） | ✓ | W-SELFHOST-MODERN CLOSED（**刀 1 DELIVERED @ r175**：semver + micro-toml；**刀 2 DELIVERED @ r176**：manifest/lockfile/resolve——struct 型字段首例 M13/M14 + 顶层 nil 模式首例 M19；**刀 3 DELIVERED @ r177**：typecheck + target-lexer——标量 tag 表 M21 + walk 模式机 M22 + 算符极长匹配表整型臂 M27 + 自应用闭环；**刀 4 DELIVERED @ r178**：compiler + macro——CP 两遍分派 M31-M36 + 宏库保守面 M37/M38 + fixpoint 载体自应用 17/17；**刀 5 DELIVERED @ r179**：expander + 遮蔽族 22 名两份共变——合成模式机 M41 + 表达式头 M42 + 声明头 M43 + T2 63/63 含 audit 460/460；**刀 6 DELIVERED @ r180**：infer + target-parser 收官双件——W 机核心 M50〔ti_unify_step 字面域 match + `_` 记录域携 var 守卫维持 + not(is_pair(b)) 守卫折入 pair/fn 臂——GZ-2/GZ-3/GZ-4 注释原位〕+ walk 模式机族 M51〔resolve/occurs/annotation/var/subst 一/多态〕+ 规格解析机 M52〔八模表 + 内层 first(elems) 三臂〕+ 任务机 M54〔enter 九臂 + dispatch 十臂〕+ 名字表 M55 + 帧机主分派 M59〔tp_step 33 状态 + tp_give 29 臂 machine-drop `_` 保形 + tp_dispatch_item 10 臂〕+ 守护相位机族 M60〔is_nil(phase) 新鲜态族——守卫维持 if + else 内 match〕+ token/datum 表 M61〔kind_name/datum_word/is_word/datum_op/is_datum_op/cmp_kind + tp_step_datum 谓词级联入 `_` 臂〕+ tp_bin_ops 整型臂 + 离开守卫 M63〔16 臂〕+ 注解族 M57/M64〔~76 infer 位 + ~29 parser 位——tp_ha/tp_ma nil 占位域与 ti_member/ti_row_push 名/位混合域经 checker 立捕后诚实裸名〕，表示恒等 + 刀 6 门〔全 parity sweep + fixpoint 17/17 B≡C + T2 63/63 audit 460/460〕全绿 + 映射表 §14 + 出口六条 ✓） | 12/12 全上 G8 表面——窗口 CLOSED |

## 8. 模块/命名/可见性

| 能力项 | 状态 | 交付锚 | 优秀语言参照 | 备注 |
|---|---|---|---|---|
| 模块系统（加载层 + 收集序 + last-wins） | ✓ | MOD 裁定族 §9.64（K102-K106） | OCaml 模块/Go package | 加载层 Symbol 键统一 + 真 first-seen |
| 命名空间边界 | ✓ 裁定 | W-BOUND-SCOPE/W-NAMING 登记窗 §9.58（K78-K80 + BOUND-1 清偿） | Rust 模块可见性 | 裁定族在案；登记窗零信号 |
| Symbol 单池身份（全管道无文本键工作状态） | ✓ | §9.52 → §9.68 身份基座链闭合 | rustc Symbol/interning | reader→typecheck 全程 |
| 可见性控制（pub/private 修饰） | 缺失 | —— | Rust/OCaml 可见性 | 候选：与 L3 授权层联动（import 不传播授权设计位）；触发器 = 多模块语料规模 |
| 依赖解析（semver + lockfile + resolve） | ✓ | G5 @ r156-r160 | cargo/opam（K161 解耦先例） | kp 生产位 |

## 9. 工具链与生态

| 能力项 | 状态 | 交付锚 | 优秀语言参照 | 备注 |
|---|---|---|---|---|
| 包管理 CLI（kp） | ✓ | G5 r160（KERF_PKG_SELFHOST 三态带） | cargo/pnpm | —— |
| 诊断系统（十二面审查 + 位置单源化） | ✓ | DIAG 族 §9.56（K71-K74 + DIAG-1/4） | rustc 诊断族 | 14 诊断码（E0002/E0009/E0013/E0019…） |
| REPL（用户面） | ✓ | SURF 裁定族 §9.62（K92-K97——REPL 不完备族统一） | 各语言 REPL | —— |
| CLI 对称化（--engine/--parity 退役教育性错误） | ✓ | SURF 族 + G6 r162 | —— | loud-retirement |
| 测试基建（分层执行引擎） | ✓ | W-TEST-FLOW DELIVERED r167（T0 29/T1 52/T2 63） | nextest/GHC test | 分块前台 + 断点续跑（对抗环境收割） |
| 格式化（selfhost 格式约定 + 工具） | ✓ | FMT 族 §9.79（krf_reformat.py + 三断言守卫） | rustfmt/gofmt | selfhost 三件格式域清偿 |
| 基准方法学 | ✓ | §9.61（K88-K91 + 方法学 v2 码化 + B4 确定性守卫） | criterion | 测量方法学本身入审 |
| 审计面（audit 全语料） | ✓ | 460 live + 124 retired（r170 BF01/BF04/V3 共变） | —— | —— |
| 诊断操作码上下文/形式记法 | 登记 | W-DIAG-OPCODE-CONTEXT/W-DIAG-FORM-NOTATION（r106/r108 登记窗） | rustc 诊断上下文 | 零信号 |
| 驱动/harness 拆分 | 登记 | W-DRIVER-HARNESS-SPLIT（r106 登记窗） | —— | 零信号 |
| 跨轮结果缓存/族级并行 | 登记 | W-TEST-FLOW §7 登记态四件（r167） | nextest 缓存 | 零信号 |
| LSP/IDE 协议面 | ✓ 设计预留 / 缺失 | §9.3.2 LSP 交互点（设计蓝图位） | rust-analyzer | 实施缺失——Stage 3+ 生态位候选 |
| 交叉编译矩阵 | 缺失 | —— | Rust/Zig 交叉面 | 链外 C 后端位候选（W-3.8 域） |
| 文档生成器 | 缺失 | —— | rustdoc/ocamldoc | 零信号 |

## 10. 标准库（libs 族 58——T2 门在册 @ r170）

| 能力项 | 状态 | 交付锚 | 优秀语言参照 | 备注 |
|---|---|---|---|---|
| 列表/字符串/基本 I/O 基础库 | ✓ | Stage 1 出口判据 + libs 族 58（T2 门） | Scheme R7RS 小核 | 内建 18 + stdlib 表面 |
| 数值库（浮点/大数/位运算） | 缺失 | —— | 各语言 stdlib | 触发器 = 浮点字面量排期（§1 联动） |
| 集合库（map/set——非 vector 宪制排除） | 缺失 | —— | —— | pair 链承载线性结构；哈希面 = 零原语约束下的内建层议题 |
| 并发/通道原语 | ✓ 设计排除（零通道不变性） | 8 原语冻结——零通道 | —— | 并发面 = L3 授权 + 效应族窗口域（Stage 3+） |

## 11. 完成度汇总与剩余优先级（下一窗扫描单源输入）

**计数**（能力项粒度——本矩阵行级）：

| 域 | ✓ 已交付 | ✓ 设计冻结/裁决 | 登记 | 缺失（含决策-实况缺口） |
|---|---|---|---|---|
| 词法（§1） | 4 | 0 | 0 | 2 |
| 语法（§2） | 7 | 0 | 1 | 2（1 = 设计排除中缀） |
| 语义（§3） | 9 | 0 | 2 | 0 |
| 类型（§4） | 6 | 1（依赖类型忽略） | 3 | 1 |
| 效应（§5） | 0 | 3 | 2 | 0 |
| 资源/运行时（§6） | 6 | 0 | 3 | 0 |
| 管道/自举（§7） | 14 | 0 | 1 | 0 |
| 模块/命名（§8） | 3 | 1（命名空间裁定） | 0 | 1 |
| 工具链（§9） | 8 | 0 | 3 | 4（LSP 设计预留归缺失列） |
| 标准库（§10） | 1 | 1（并发设计排除） | 0 | 2 |
| **合计（91 项）** | **58** | **6** | **15** | **12** |

> 归态口径注记（r171 写入时自查勘正）：错误处理（§3）混合态归登记列（Fatal 裁定 ✓ / 自定义面登记）；JIT 链内裁决（§6）归 ✓ 交付列（MJ-5/MJ-6 裁决完成 = 交付物）；命名空间边界（§8）「✓ 裁定」归冻结列；LSP（§9）「设计预留 / 实施缺失」归缺失列；并发/通道（§10）设计排除归冻结列。

**剩余优先级**（触发器就绪度排序——r181 重排：**W-ROW-POLY 触发器①链式达成升首位实施窗**〔用户指令⑥效应族显式排期——GZ-5 需求触发器①「任一进入实施排期」达成〕；效应族三段链入 completion-plan §3 单源；余窗零信号不开窗纪律维持——**非冻结**，触发器达成即开）：

1. **W-ROW-POLY**（行多态·效应族链首段·类型基础）——**OPEN @ r181**（触发器①链式达成 + 前置门四件全过〔r181-search 六检索 + §3.3 提案 + 8 原语第 138 轮 + 孪生可表达性 ✓〕；三刀序：刀 1 infer.ktf 行类型表示 + 行合一五规则 → 刀 2 target-parser + expander 消费面 → 刀 3 语料 + audit + P2 效应前置接口；**r174 冻结裁定首个适用者**——Rust oracle 零改动，验证 = 金档 + fixpoint + audit；单源 w-row-poly-window v1.0；出口六条）
2. **效应族三段链**（Read/Write/State/Async/Error/Log——completion-plan §3 单源）：段 2 效应机制窗（handler/perform 语义 + 效应行推断消费——前置 = W-ROW-POLY CLOSED + P2 效应行接口在位）→ 段 3 效应族实例窗（六实例逐刀交付——前置 = 段 2 CLOSED）；**信号源已触发** = 用户显式排期请求 @ r181（GZ-5 需求触发器①）；效应族开窗时按 r174 桥终结裁定走金档验证面
3. **W-LINEAR-TYPES**（线性/仿射类型）——登记 @ r172（w-decision-gap-windows §4）：L3 授权层链式前置 + 四触发器；正交于 W-ROW-POLY
4. **W-UNION-INTERSECT**（交叉/联合类型）——登记 @ r172（§3）：HM+union 融合成熟度观察 + enum+Dyn 承载实测 + Dyn 损耗同轴
5. **W-COMPTIME**（编译期求值）——登记 @ r172（§5）：成熟度已达标触发主轴 = 需求面；开窗须对账 G6 eval 退役边界
6. **W-HEAP-EXTERN**（FFI 堆句柄）——TD-026 承载位（与 W-LINEAR-TYPES 触发器③联动）
7. **共享全局环境污染 P2**（r170 登记）——触发器 = 用户语料踩中频率
8. **W-GEN-GC / W-VM-SUPERINSTR / W-EMI-COMPILE-AXIS / W-BOUND-SCOPE / W-NAMING / W-CHK-DEFINE-HASH / W-DIAG-*/ W-DRIVER-HARNESS-SPLIT / W-PKG-MULTISRC**——横切登记窗族（零信号维持）
9. **TD-029**（VM 栈余量 + 引擎并行车道前置实测——SOP §3.2.1 条款 4）——r167 引擎后多轮零触发
10. **W-3.x 非自举族**（W-3.5 Token 流+图 IR / W-3.8 codegen / W-3.9 诊断增强）——从属位法定解除 @ r163/r170；各窗自身触发器仍零信号
11. **浮点/插值/守卫子句/可见性/LSP/文档生成**——缺失候选（零信号；LSP 设计预留归缺失列）

## 12. 维护纪律

1. **共变义务**：每窗 OPEN/CLOSED/DELIVERED 轮的文档共变清单**必含本矩阵**（新增能力行 / 状态翻转 / 计数共变 + 版本号演进）；违反 = GATE 3 无条款引用判 NEEDS REVISION。
2. **版本演进**：v0.X 逐窗递增；状态翻转（登记→✓ 或 缺失→登记）须附触发器达成证据锚。
3. **单源边界**：本矩阵只做汇总视图——实施细节回归各单源（§0 声明）；发现矩阵与单源冲突时以单源为准 + 当轮修正矩阵（§8.4.5）。
4. **触发器定义补全义务**（✅ 已兑现 @ r172——w-decision-gap-windows.md v1.0 三窗落档〔W-UNION-INTERSECT §3 / W-LINEAR-TYPES §4 / W-COMPTIME §5〕）：本条转为**常设义务**——未来任何决策矩阵（§6.10.2 同型）新增「实现」级决策行时，若实况未实施，同轮在登记档补四件形制触发器定义（决策-实况缺口不许无承载——零信号不开窗纪律下缺口必须可审计）。
5. **扫描轮输入**：每轮 §17 Step 1 扫描以 §11 为结构化输入（替代散点窗口名检索）；扫描轮自身共变 §11 优先级表。

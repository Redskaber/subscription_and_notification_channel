# selfhost/ — the self-hosted production chain (`.ktf`, the sole skin)

The compiler's own front end, type faces, compile segment, and package
management logic, written in the kerf subset itself and driven through
the production pipeline. Since the T-a switch (r145-r149) and the
S-expr retirement (W-SEXP-RETIRE, r150-r154) the target skin (`.ktf`)
is the one and only skin: the twelve files below are the production
chain — read, expand, infer, check, compile, and the kerf-pkg logic
five — with the Rust segments retained as the seed-chain oracle
(verification surface) and the VM as the permanent Rust base (the
constitutional exclusion, SOP §2.2 principles 41/53).

Design record: `docs/stage0.md` §9.46-§9.48 (RS/EX/MX ruling families),
§9.83-§9.87 (CP two passes, the composed chain), §9.96 (the step-3
corpus translation), §9.98 (the two-skin corpus closeout), §9.113
(K140-K142 the bootstrapping-order anchors). Ledger single source:
`docs/develop/v3/s-expr-conversion-record.md` (per-file accounting).

## The twelve pieces

| File | Layer | Lines | Role |
|---|---|---|---|
| `v1/target-lexer.ktf` | target lexical | 1,069 | the `.ktf` byte-surface lexer twin (W-TGT-READ-TWIN blade 1, r136) — every lexical decision over the raw byte table (trivia, whitespace, reject set, atom classification, the i64 threshold guard, escape validation) — modernized onto the G8 surface at W-SELFHOST-MODERN blade 3 (r177): match-arm operator maximal-munch table (int-literal lead/two-byte/three-byte nested arms), the trivia set, the scan mode machine, scalar annotations (representation-identical, mapping table w-selfhost-modern-window §11) |
| `v1/target-parser.ktf` | target parse | 4,424 | the `.ktf` Pratt parser twin (blade 2/3, r138-r139; the frame-machine form) — token records in, Stx tree out; grew with the type-annotation (r165), struct (r166), and enum (r168) declaration faces — modernized onto the G8 surface at W-SELFHOST-MODERN blade 6 (r180): the frame machine (33 states, the give cascade with the machine-drop `_`), the guarded phase machines (the is_nil(phase) fresh-state family), the phase/step families, the token/datum tables, the tp_bin_ops int-literal level table, the leave guard's sixteen arms, scalar annotations (representation-identical, mapping table w-selfhost-modern-window §14); W-ROW-POLY blade 1 (r182): the row type's type-layer kernel — the ("row" fields tail) representation, the row spec's resolve modes, the scoped-labels unification machine (RW-1..RW-6, mapping table w-row-poly-window §8.1; the r174 frozen-oracle ruling's first consumer — the twin grows rows, the Rust oracle never does) |
| `v1/macro.ktf` | 1.7 macro face | 733 | the MX-2 pure-function library — syntax-rules with zero driver defines (assembled ahead of the expander) — modernized onto the G8 surface at W-SELFHOST-MODERN blade 4 (r178): match-arm mode machines (the pattern compiler and matcher, the instantiation walk), the matcher's pattern family, the binder head names, scalar annotations; the shadowed helper copies co-modernized at blade 5 (r179) with the expander (22 shared names, ex_gen's dispatch on match arms, identical bodies machine-checked) |
| `v1/expander.ktf` | 1.6 expansion | 4,850 | the MX-2 assembly carrier — flat pre-order form stream in, ModuleItem tree out (one self-recursive expander + synthetic node modes); the struct/enum/pattern police families and the GZ-4 exhaustivity machinery live here (r166/r168/r170) — modernized onto the G8 surface at W-SELFHOST-MODERN blade 5 (r179): the synthetic-mode machine on match arms (nine modes, the `_` arm carrying the depth guard and the real tree), the expression-head and declaration-head dispatches, the loader edge table, the extern type-tag table, the annotation family (representation-identical, mapping table w-selfhost-modern-window §13) |
| `v1/infer.ktf` | 3.12 HM inference | 4,860 | the segment-three inference face — the `infer_module` mirror: iterative Algorithm W, union-find with undo, let-polymorphism, the SCC partition, the extern boundary; `Type::Struct`/`Type::Enum` nominal faces (r165/r168) — modernized onto the G8 surface at W-SELFHOST-MODERN blade 6 (r180): the W machine's unify step on match arms (string-domain arms, the `_` record domain carrying the var guards and the nested tag match), the walk machines (resolve/occurs/annotation/var/subst), the spec resolver's eight-mode table, the task machine's enter/dispatch heads, the name tables, the tarjan dispatcher, scalar annotations (representation-identical, mapping table w-selfhost-modern-window §14); W-ROW-POLY blade 1 (r182): the row type's type-layer kernel — the ("row" fields tail) representation, the row spec's resolve modes, the scoped-labels unification machine (RW-1..RW-6, mapping table w-row-poly-window §8.1; the r174 frozen-oracle ruling's first consumer — the twin grows rows, the Rust oracle never does) |
| `v1/typecheck.ktf` | 3.12 check face | 1,264 | the segment-three conservative checker — the `check_module` mirror: pass-1 module table, the R1-R8 rule walk, the captured-assignment boundary, multi-error collection, the annotation-divergence face (E0013, r165) — modernized onto the G8 surface at W-SELFHOST-MODERN blade 3 (r177): the judgment-face dispatch on match arms (scalar tag tables, walk-mode tables, the callee-analysis pair patterns, the resolution nil-union faces), scalar/str/bool annotations (representation-identical, mapping table w-selfhost-modern-window §11) |
| `v1/compiler.ktf` | 2.3 CP two passes | 1,877 | the fully self-hosted compile segment — the gate-B dual-caliber carrier (pass 1 lexical-domain analysis; pass 2 instruction emission); the variant-arm/pattern compile faces (r168/r170) — modernized onto the G8 surface at W-SELFHOST-MODERN blade 4 (r178): the two-pass dispatch on match arms (the child-count/assemble tag tables, the opcode stack-effect tables, the emitter walker's synthetic-mode and real-tree tag tables — the fixpoint carrier reading itself through the new surface), the drain-scan jump dispatch, scalar annotations (representation-identical, mapping table w-selfhost-modern-window §12) |
| `v1/micro-toml.ktf` | pkg logic | 662 | the kerf-pkg micro-TOML subset parser twin (W-PKG-SELFHOST blade 1, r156) — modernized onto the G8 surface at W-SELFHOST-MODERN blade 1 (r175): struct Span/Pos records, match-arm byte classification and result-record dispatch, scalar annotations (representation-identical, mapping table w-selfhost-modern-window §9) |
| `v1/semver.ktf` | pkg logic | 337 | the version-algebra twin (blade 2, r157) — modernized onto the G8 surface at blade 1 (r175): struct Version/Constraint records with generated accessors, match pair-pattern dispatch, scalar + struct-typed annotations (representation-identical) |
| `v1/manifest.ktf` | pkg logic | 525 | the kerf.toml projection twin (blade 2, r157) — modernized onto the G8 surface at W-SELFHOST-MODERN blade 2 (r176): struct Slot/Dep records with struct-typed fields (the first twin consumer of the nested resolve face), match pair-pattern tag/value dispatch, int-literal key-matcher constant tables, the syntax pass-through cons identity (representation-identical, mapping table w-selfhost-modern-window §10) |
| `v1/lockfile.ktf` | pkg logic | 675 | the kerf.lock model + deterministic serialization twin (blade 3a, r158) — modernized onto the G8 surface at blade 2 (r176): Span slot payloads + Version accessor reads, match tag/value dispatch, key-matcher constant tables (representation-identical) |
| `v1/resolve.ktf` | pkg logic | 517 | the dependency-graph resolver twin (blade 3b, r159; conflict mid-list fix r160) — modernized onto the G8 surface at blade 2 (r176): Dep/Slot/Span accessor reads over the manifest twin's own products, phase/color/status match-arm discriminants with the top-level nil pattern (representation-identical) |

Line counts: `wc -l` at v0.131.0 (W-SELFHOST-MODERN blade 6, r180).
Total: **21,793 lines**
across twelve files — the ledger single source
(`docs/develop/v3/s-expr-conversion-record.md`) carries the per-round
accounting; any drift between that ledger and `wc -l selfhost/v1/*.ktf`
is an §8.4.5 violation by the ledger's own audit rule.

## Bootstrap status (one paragraph)

The bootstrap-completion standard (SOP §21.12-28③: fully off the host
language, constitutional exclusions aside) was declared **GO at r163**
after the C1-C4 audit (deep-review-bootstrap-completion.md): the
composed `.ktf` chain reads, expands, checks, and compiles through the
twins with the junction products feeding forward (never an oracle
intermediate), gate B holds both calibers (byte-identical bytecode and
the three-phase fixpoint `C_t(C_t(S')) == C_t(S')`), and the kerf-pkg
logic rides the twin arm in production (W-PKG-SELFHOST CLOSED r160).
The self-hosting matrix G1-G8 is all green (G8 language foundation
closed r170). The VM/runtime stay the permanent Rust base — a VM
rewrite is not on any roadmap (the constitutional exclusion).

## Hosting conventions

- **target-lexer.ktf** (W-TGT-READ-TWIN RS-1): the host encodes the
  source text as one integer per byte — `define(source_bytes, quote(
  (104, 101, ...)))` — and every lexical decision rides plain integer
  arithmetic (K20 permanent host layer: f64 value faces and string
  payloads stay host-side).
- **target-parser.ktf**: the host injects the token table —
  `define(tokens, quote((record, ...)))`; positions ride as decimal
  byte-offset strings, carried opaquely.
- **expander.ktf** (EX-1, the MX-2 assembly): the host injects the
  flat pre-order form stream — `define(forms, quote((record, ...)))`;
  `"list"` records carry their child count so depth stays inside the
  nesting cap. The assembled program = `macro.ktf` prepended to
  `expander.ktf`. Budget globals (`ex_limit`, `co_limit`) ride the
  prefix (r146/r148).
- **compiler.ktf / infer.ktf / typecheck.ktf** (CP-1 record grammar,
  the `items` channel): the host injects the EXPANDED item tree as a
  flat pre-order record stream — `define(items, quote((record, ...)))`;
  the segment-three twins bind the tdef table and the diagnostics
  (code/severity/span/template-payload/subjects); the extern records
  ride the stream with entries inline (the r124 junction-3 face).
- **pkg five** (micro-toml, semver, manifest, lockfile, resolve): the
  family's combined programs are assembled in dependency order
  (e.g. mt+semver+manifest+lockfile+resolve); the twins bind their
  input documents through the same `quote` record channels and return
  structured verdict records decoded host-side.
- **Junction feeds** (§9.87 JX-1): the junction products feed forward
  — the `.ktf` reader's forms, the `.ktf` expander's rebuilt items,
  the compile — never an oracle intermediate (the honest fixpoint
  direction).
- The source tail binds the verdict — `define(result, ("ok" ...))` or
  `("err" kind payload ...)` — which the host rebuilds and renders
  through the same `Display` (parity transparent by construction).

## Consumers (who reads the twelve)

| Consumer | Face |
|---|---|
| `crates/kerf-driver/src/bootstrap/target_corpus.rs` | the `*_TARGET_SOURCE` constants (`include_str!` ×7) + the assembled expander source + the prefix assembly (the RS-1/EX-1/CP-1 injection family) + the rich-compile faces |
| `crates/kerf-driver/src/bootstrap/{infer,typecheck,compiler,expander,target_lexer,target_parser}_parity.rs` | the per-segment parity faces: oracle verdict renderers, twin decoders, the CP-1 payload builders |
| `crates/kerf-driver/src/bootstrap/{micro_toml,semver,manifest,lockfile,resolve}_parity.rs` | the pkg-logic parity faces (W-PKG-SELFHOST) |
| `crates/kerf-driver/src/bootstrap/steady_*.rs` | the steady chains (expander / target reader / compiler / typecheck) — compile once through the production bridge, per-check injection |
| `crates/kerf-driver/src/bootstrap/{composed_full_chain,composed_target_read_chain,fixpoint,abc_pipeline}.rs` | the composed-chain parity, the fixpoint drivers, and the acceptance-corpus pipeline |
| `crates/kerf-driver/src/pkg_selfhost.rs` | the kp twin arm (`RESOLVE_TARGET_SOURCE` + the production three-state band) |
| `tests/v1/stage1/plan/` (50 families) | the sweep/parity/fixpoint/determinism/segment-switch families + `selfhost_format_guard_tests.rs` (the format invariants below) + `subset_corpus_tests.rs` (the acceptance corpus, 170 rows) |

(The historical tamper-anchor pinning list — three contiguous
substrings pinned by the retired `composed_target_chain_tests.rs` —
left the tree with that family's reorganization; the live discipline
is unchanged: **any token-level change to a twin requires a full
parity rerun of its consumer family**, comments and whitespace
included in spirit even though they are not tokens.)

## Format conventions (machine-checked)

`tests/v1/stage1/plan/selfhost_format_guard_tests.rs` pins three
invariants over **all twelve files**:

1. **line width ≤ 100 columns** (SOP §10.5; the same bound rustfmt
   enforces on the Rust face);
2. **the non-ASCII whitelist = {`—`, `§`}** (the em-dash is the
   repo-wide parenthetical convention; `§` anchors ride verbatim);
3. **no ASCII parenthetical dashes** (` - ` / `  -  `) — prose dashes
   are em-dashes (the `.ktf` comment marker is `//`).

## Honest boundaries (registered)

- **MX-1**: the subset has no string construction — mangled names ride
  as structured records, decoded host-side (decision-face parity;
  rendering stays host-side).
- **float payloads**: inf/NaN have no literal shape — every float
  rides as Debug text (host-side parse is exact).
- **shared global environment**: user `define`s may shadow Stage 0
  builtins (first/second/rest...) — the twin expander and the user
  program share the VM global environment; a shadow corrupts expander
  internals in the combined run (pos-402, r170). Corpus-avoided +
  registered as a P2 (tech-debt r170); the police families own the
  long-term fix.
- **the VM stays Rust** (the constitutional exclusion): this directory
  is the bootstrap chain's language face; a VM rewrite is not on any
  roadmap (SOP §2.2 principles 41/53).
- **the Rust segments stay as oracle**: `read_program` /
  `expand_program` / `compile_program` / the infer-check pair remain
  the tree's truth sources for parity verification (BS-A) — they are
  verification surface, not the production chain.

## History notes

- The seed-skin S-expr originals of the five bootstrap twins were
  removed at r104 (E5 batch 3); the S-expr skin left the tree entirely
  at r151 (W-SEXP-RETIRE blade 2: corpus, reader, twins, transcoder —
  the `lexer.ktf`/`reader.ktf` S-expr twins retired then, 812 lines),
  completing at r154 with the word-face/ledger teardown (~292 sites,
  TEST-5 zero-scan guard). The production chain reads `.ktf` only.
- The pkg-logic five entered at r156-r160 (W-PKG-SELFHOST, closed with
  the Rust logic arm retired to the build-bootstrap fallback band).
- The G8 language-foundation blades (r165-r170) grew the twins with
  the type-annotation, struct, enum, and pattern faces (+3,940 lines
  over the r160 baseline) — the twins implement the new surfaces in
  production while the Rust oracle keeps parity.

//! The W-HM-TWIN 127-a integration verification (w-hm-twin-window.md
//! §4, the MUV boundary): the full-corpus sweep on the inference
//! axis — every corpus row whose source the target reader accepts
//! and the oracle expander expands feeds BOTH faces (the twin
//! through the steady chain's injection channel, the Rust
//! `infer_module` through the pipeline's own externals); the two
//! verdict texts must match bit-for-bit: the tdef table (flat define
//! order, budget survivors only), the generalized schemas (the
//! quantified metavariable indices included — the engine's
//! numbering is part of the parity face), the resolved annotation
//! trees, the effect rows and the diagnostics channel (report order,
//! the template payloads rendered through the oracle's own format
//! strings). Reader-rejection rows are the READ segment's rows
//! (counted, not fed); expansion-rejection rows are the EXPANSION
//! segment's rows (counted, not fed — the twin never sees an item
//! stream for them). Load-rejected rows ride the sweep FED: the
//! loader's module validation is the check segment's own face — the
//! infer axis is independent of it, both faces consuming the
//! identical item tree.
//!
//! W-SEXP-RETIRE blade 1 (r150, w-sexp-retire-window SR-1): the
//! corpus is single-skin — the sweep reads the migrated `.ktf`
//! cases through `read_target_program` (170 cases; the three
//! skin-divergent rows retired per SR-2; the r168-b4 blade-3 enum
//! rows added sixteen — four positive and twelve negative). The classification keeps
//! the BARE machine the sweep has always ridden (read + expand, no
//! loader): the infer axis is loader-independent (the paragraph
//! above), so the module family (neg-018/019/020/048/049 — the
//! target skin maps `use` to a string require, which the bare
//! expander accepts) rides the FED rows — neg-020/048/049 exactly
//! as they did on the old seed-skin face, neg-018/019 newly (their
//! old-face expansion rejection was the S-expr skin's
//! symbol-require artifact; the loader's rejection of all five is
//! another face's pin — the hm_twin_face classification rides the
//! pipeline spine, the corpus contract's machine). The nine
//! stage-divergent rows (the malformed keyword-headed forms) moved
//! from the expansion rows to the READER rows — the grammar-directed
//! target reader rejects what the permissive S-expr reader deferred
//! to the expander.
//!
//! The HM negative family rides the sweep itself (the corpus's
//! neg-031/037/041/044/047/056 rows carry the E0009 face) plus the
//! dedicated probes below: the bool-demand t1, the non-callable t2,
//! the non-numeric t3, the cond t5, the occurs check t7 (the FP4
//! source), let-polymorphism reuse, and the empty stream. The E0011
//! budget row rides the programmatic path (the FP5 lineage — the
//! reader's nesting cap is 256, so the budget's far side is only
//! reachable through the value-face injection, exactly the face the
//! sweep feeds). W-SEXP-RETIRE blade 2 (r151): the probe sources ride
//! the target skin (the corpus-dictionary respell).

use kerf::core::{CoreExpr, LiteralValue, ModuleItem};
use kerf::driver::{SteadyTypecheckChain, oracle_inference_axes};
use kerf::expander::expand_program;
use kerf::reader::read_target_program;
use kerf::span::{ByteOffset, ExpansionId, FileId, Span, Symbol};

const CORPUS_DIR: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/tests/v1/stage1/corpus");

/// Deep trees (the corpus's nesting family) recurse through the
/// harness's Rust tree walkers; the demand-allocated stack discipline
/// of the sibling chain tests (the steady-expander precedent).
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly");
}

fn sp(a: u32, b: u32) -> Span {
    Span::new(FileId(0), ByteOffset(a), ByteOffset(b), ExpansionId::ROOT)
        .expect("test span is ordered")
}

fn sym(text: &str) -> Symbol {
    Symbol::new(text).expect("test symbol is valid")
}

#[test]
fn infer_twin_sweeps_the_corpus_and_matches_the_oracle() {
    deep_stack(|| {
        let chain = SteadyTypecheckChain::new().expect("the fixed twin program builds");
        let entries = std::fs::read_dir(CORPUS_DIR).expect("the corpus directory is in tree");
        let mut files: Vec<_> = entries
            .filter_map(|e| e.ok())
            .map(|e| e.path())
            .filter(|p| p.extension().is_some_and(|x| x == "ktf"))
            .collect();
        files.sort();
        assert_eq!(
            files.len(),
            170,
            "the corpus is 170 .ktf cases (the blade-1 single-skin migration plus the sixteen annotation rows plus the thirteen \
             blade-2 struct rows plus the sixteen blade-3 enum rows plus the sixteen blade-4 pattern rows: the 112 seed-skin originals minus the three SR-2 retired divergences)"
        );
        let mut fed = 0usize;
        let mut reader_rejected = 0usize;
        let mut expansion_rejected = 0usize;
        for path in &files {
            let source = std::fs::read_to_string(path).expect("corpus file reads");
            let case = path.file_name().unwrap().to_string_lossy().to_string();
            // Blade 1: the row reads through the TARGET reader (the
            // migrated `.ktf` corpus, SR-1) — the bare read→expand
            // machine keeps the sweep's original gate (the loader
            // never gates the infer axis; see the header).
            let forms = match read_target_program(FileId(0), &source) {
                Ok(forms) => forms,
                Err(_) => {
                    // The read layer owns this row's verdict — the
                    // inference layer never sees it (segment one's
                    // sweep carries the row).
                    reader_rejected += 1;
                    continue;
                }
            };
            let items = match expand_program(&forms) {
                Ok(items) => items,
                Err(_) => {
                    // The expansion layer owns this row's verdict —
                    // the twin never sees an item stream for it
                    // (segment two's sweep carries the row).
                    expansion_rejected += 1;
                    continue;
                }
            };
            let twin = chain.infer(&items).unwrap_or_else(|e| {
                panic!("{case}: the twin inference runs without a harness defect: {e}")
            });
            let oracle = oracle_inference_axes(&items);
            assert_eq!(
                twin, oracle,
                "{case}: the twin's inference verdict text matches the oracle"
            );
            fed += 1;
        }
        // The r150 re-measurement (the `.ktf` face, the bare machine —
        // the floors now ride the measured face): the nine
        // stage-divergent rows moved into the reader rows (the
        // grammar-directed target reader rejects the malformed
        // keyword-headed forms the S-expr reader deferred to the
        // expander — 8 -> 16), the two ruling-D module twins
        // (neg-018/019) moved out of the expansion rows into the fed
        // rows (the target skin maps `use` to a string require the
        // bare expander accepts — 29 -> 18), and the fed count holds
        // at 75: the two retired fed rows (pos-031, neg-036) are
        // offset by those two newly-fed module twins.
        // The r170 re-measurement (blade 4): the four 3+-tuple rows
        // relocated from the reader layer to the expansion layer
        // (neg-065/066/071/072 — the head-NAME ruling replaced the
        // shape ruling), the trailing-comma row joins the reader
        // rows (neg-412): 20 - 4 + 1 = 17 reader, 29 + 4 = 33
        // expansion; the five checker rows and four positive rows
        // ride the fed face.
        assert!(fed >= 105, "the fed rows ride the sweep (got {fed})");
        assert!(
            reader_rejected >= 17,
            "the reader-layer rejection rows are accounted (got {reader_rejected})"
        );
        assert!(
            expansion_rejected >= 33,
            "the expansion-layer rejection rows are accounted (got {expansion_rejected})"
        );
        assert_eq!(
            fed + reader_rejected + expansion_rejected,
            files.len(),
            "every corpus row is classified exactly once"
        );
    });
}

#[test]
fn infer_twin_matches_the_oracle_on_the_hm_negative_family_probes() {
    deep_stack(|| {
        let chain = SteadyTypecheckChain::new().expect("the fixed twin program builds");
        // (name, source, expected verdict marker) — the marker
        // pins the oracle's own verdict so a both-sides-silent bug
        // cannot pass the parity face vacuously (None = clean).
        let probes: &[(&str, &str, Option<&str>)] = &[
            // The accept anchor (the steady-expander precedent).
            (
                "accept-anchor",
                "fn fib(n) { if ((n < 2)) { n } else { (fib((n - 1)) + fib((n - 2))) } }",
                None,
            ),
            // t1 — the bool demand: f's own body forces the param to
            // bool through the if condition; the call site's concrete
            // non-bool argument is a definite error (GATE-2).
            (
                "t1-bool-demand",
                "fn f(x) { if (x) { 1 } else { 2 } }\nfn g(y) { f(1) }",
                Some("type mismatch"),
            ),
            // t2 — the non-callable callee: an application whose type
            // is concrete int (inference-derived, not a literal
            // define — R4 does not own it).
            (
                "t2-not-callable",
                "fn f(y) { ((1 + 2))(3) }",
                Some("expected a function"),
            ),
            // t3 — the non-numeric operand on the ad-hoc builtin path.
            (
                "t3-non-numeric",
                "fn f(x) { (x + \"a\") }",
                Some("expected `int` or `float`"),
            ),
            // t5 — the if-condition unification failure (bool
            // demanded, int found — the corpus's neg-031 face).
            (
                "t5-cond-mismatch",
                "fn f(x) { if (1) { 2 } else { 3 } }",
                Some("expected `bool`"),
            ),
            // t7 — the occurs check (the FP4 source: self-application
            // is a recursive type).
            (
                "t7-occurs",
                "define(omega, ||(x) { x(x) });",
                Some("recursive type"),
            ),
            // Let-polymorphism reuse: two call sites, one schema,
            // fresh metavariables per use (the decoupled
            // instantiation face).
            (
                "let-polymorphism",
                "fn id(x) { x }\nfn a(y) { id(1) }\nfn b(z) { id(true) }",
                None,
            ),
            // The effect-row collection face: perform appends, handle
            // subtracts what its clauses intercept (definite) and
            // merges each handler body's row.
            (
                "handle-rows",
                "fn f(x) { handle (perform log(x)) { log(v) => { v }, } }",
                None,
            ),
            // The empty stream (the nil payload — the zero-define
            // module).
            ("empty-stream", "// nothing but trivia\n", None),
            // ---- the blade 2 struct probes (GZ-3 — the b3
            // integration face): the full chain through the real
            // reader + expander feeding BOTH engines the same item
            // stream (dstruct records + generated danns included).
            (
                "struct-full-chain",
                "struct Point { x: i64, y: i64, }\n\
                 \u{20}fn make(a) { Point(a, 2) }\n\
                 \u{20}fn x_of(p) { Point_x(p) }\n\
                 \u{20}define(result, x_of(make(5)));",
                None,
            ),
            (
                "struct-recursive-cycle",
                "struct Node { val: i64, next: Node, }\n\
                 \u{20}fn wrap(v, n) { Node(v, n) }\n\
                 \u{20}define(result, 1);",
                None,
            ),
            (
                "struct-empty-unit",
                "struct Unit { }\n\
                 \u{20}fn mk() { Unit() }\n\
                 \u{20}define(result, 1);",
                None,
            ),
            (
                "struct-let-divergence",
                "struct P { x: i64, }\n\
                 \u{20}fn f() { let v: P = 1; v }\n\
                 \u{20}define(result, f());",
                Some("annotation divergence: expected `P`, found `int`"),
            ),
            (
                "struct-accessor-call-divergence",
                "struct P { x: i64, }\n\
                 \u{20}fn pick(p) { P_x(p) }\n\
                 \u{20}define(result, P_x(1));",
                Some("type mismatch: expected `P`, found `int`"),
            ),
        ];
        for (name, source, expect) in probes {
            let forms = read_target_program(FileId(0), source).expect("the probe reads");
            let items =
                expand_program(&forms).unwrap_or_else(|e| panic!("{name}: the probe expands: {e}"));
            let twin = chain
                .infer(&items)
                .unwrap_or_else(|e| panic!("{name}: the twin inference runs: {e}"));
            let oracle = oracle_inference_axes(&items);
            assert_eq!(
                twin, oracle,
                "{name}: the twin's inference verdict text matches the oracle"
            );
            if let Some(marker) = expect {
                assert!(
                    oracle.contains(marker),
                    "{name}: the oracle's own verdict carries `{marker}` (got: {oracle})"
                );
            }
        }
    });
}

/// The FP5 lineage: an if chain `levels` deep (the reader's own
/// nesting cap is 256, so the budget's far side is only reachable
/// through the programmatic path — the same face the value-side
/// injection feeds).
fn deep_if_chain(levels: u32) -> CoreExpr {
    let mut cur = CoreExpr::Literal {
        span: sp(0, 1),
        value: LiteralValue::Int(1),
    };
    for _ in 0..levels {
        cur = CoreExpr::If {
            span: sp(0, 2),
            cond: Box::new(CoreExpr::Literal {
                span: sp(0, 1),
                value: LiteralValue::Bool(true),
            }),
            then_branch: Box::new(cur),
            else_branch: Box::new(CoreExpr::Literal {
                span: sp(0, 1),
                value: LiteralValue::Int(2),
            }),
        };
    }
    cur
}

#[test]
fn infer_twin_budget_row_matches_the_oracle_through_the_programmatic_path() {
    deep_stack(|| {
        // The E0011 row: a 600-deep define (excluded whole — one
        // warning, never an error) plus a shallow one (still
        // annotated). The budget's far side only rides the value
        // face — the injection channel carries it natively.
        let chain = SteadyTypecheckChain::new().expect("the fixed twin program builds");
        let items = vec![
            ModuleItem::Define {
                span: sp(0, 3),
                name: sym("deep"),
                value: deep_if_chain(600),
            },
            ModuleItem::Define {
                span: sp(0, 11),
                name: sym("shallow"),
                value: CoreExpr::Literal {
                    span: sp(0, 5),
                    value: LiteralValue::Int(7),
                },
            },
        ];
        let twin = chain
            .infer(&items)
            .expect("the budget row runs on the twin");
        let oracle = oracle_inference_axes(&items);
        assert_eq!(
            twin, oracle,
            "the budget row's verdict text matches the oracle"
        );
        assert!(
            twin.contains("E0011"),
            "the budget warning rides the row: {twin}"
        );
        assert!(
            twin.contains("(tdef shallow"),
            "the shallow define survives the exclusion"
        );
        assert!(
            !twin.contains("(tdef deep"),
            "the deep define is excluded whole (no partial annotations)"
        );
    });
}

#[test]
fn infer_twin_is_deterministic_and_the_injection_feeds_every_inference() {
    deep_stack(|| {
        // Determinism: the same item stream inferred twice decodes
        // identically. The no-clobber contract: two DIFFERENT streams
        // infer differently — a program-side define of `items` would
        // collapse every inference onto one stream.
        let chain = SteadyTypecheckChain::new().expect("the fixed twin program builds");
        let a_src = "fn a(x) { x }";
        let b_src = "fn b(y) { if (y) { 1 } else { 2 } }";
        let a_items = expand_program(&read_target_program(FileId(0), a_src).expect("a reads"))
            .expect("a expands");
        let b_items = expand_program(&read_target_program(FileId(0), b_src).expect("b reads"))
            .expect("b expands");
        let a1 = chain.infer(&a_items).expect("the first inference of a");
        let a2 = chain.infer(&a_items).expect("the second inference of a");
        assert_eq!(a1, a2, "the same item stream infers identically");
        let b1 = chain.infer(&b_items).expect("the inference of b");
        assert_ne!(
            a1, b1,
            "different item streams infer differently — the injection feeds every inference"
        );
        let a3 = chain
            .infer(&a_items)
            .expect("the third inference of a, interleaved");
        assert_eq!(a1, a3, "the interleaved re-inference is stable");
    });
}

#[test]
fn infer_twin_empty_stream_rides_as_nil() {
    deep_stack(|| {
        // The empty-stream ledger row (the payload face's `(quote
        // nil)` convention, mirrored on the value face): the empty
        // stream's payload IS nil, and the twin infers it to the
        // zero-define module — matching the oracle over no items.
        assert_eq!(
            kerf::driver::items_stream_literal(&[]),
            kerf::core::LiteralValue::Nil,
            "the empty stream's payload is nil"
        );
        let chain = SteadyTypecheckChain::new().expect("the fixed twin program builds");
        let outcome = chain
            .infer(&[])
            .expect("the empty stream infers (an outcome, not a defect)");
        let oracle = oracle_inference_axes(&[]);
        assert_eq!(
            outcome, oracle,
            "the empty stream's inference matches the oracle"
        );
        assert_eq!(
            outcome, "(ok (types) (diags))",
            "the empty stream infers to the zero-define module"
        );
    });
}

//! The W-HM-TWIN 127-d integration verification (w-hm-twin-window.md
//! §4, the MUV boundary): the test face — the paired positive/negative
//! probes on BOTH judgment faces (one probe set, the infer twin and
//! the check twin, both oracles — the 127-a/b rounds' probes were
//! face-specific, this family pins the pairing), the corpus HM-axis
//! reclassification (every corpus row classified exactly once on the
//! inference axis AND the check axis with the exact counts and the
//! diagnostic-carrying row names pinned — the sweeps rode lower
//! bounds, this pin turns any corpus change that shifts either axis
//! into a visible break instead of a silent ride), and the budget
//! row's per-source route (the 127-a budget row rode the steady
//! route only; the E0011 face through the recompile-per-case route —
//! the delivery face the steady chain exists to amortize).
//!
//! Probe discipline (the sweep precedents): the paired probes ride the
//! HM negative family (the E0009/E0010 faces) and the accept anchors;
//! the corpus classification rides the same read→expand→feed gate the
//! sweeps use; the budget's far side only rides the programmatic path
//! (the reader's nesting cap is 256).
//!
//! W-SEXP-RETIRE blade 2 (r151): the probe sources ride the target
//! skin (the corpus-dictionary respell), one semantic twin per row.

use kerf::core::{CoreExpr, LiteralValue, ModuleItem};
use kerf::driver::{
    Session, Severity, SteadyCheckChain, SteadyTypecheckChain, infer_twin_per_source_dual,
    oracle_check_axes, oracle_inference_axes, parse_target,
};
use kerf::expander::expand_program;
use kerf::reader::read_target_program;
use kerf::span::{ByteOffset, ExpansionId, FileId, Span, Symbol};

const CORPUS_DIR: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/tests/v1/stage1/corpus");

/// Deep trees (the corpus's nesting family) recurse through the
/// harness's Rust tree walkers; the demand-allocated stack discipline
/// of the sibling chain tests (the steady-expander precedent).
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly");
}

fn sp(a: u32, b: u32) -> Span {
    Span::new(FileId(0), ByteOffset(a), ByteOffset(b), ExpansionId::ROOT)
        .expect("test span is ordered")
}

fn sym(text: &str) -> Symbol {
    Symbol::new(text).expect("test symbol is valid")
}

/// Expand one probe source into the item stream both faces consume.
fn items_of(source: &str) -> Vec<ModuleItem> {
    let forms = read_target_program(FileId(0), source).expect("the probe reads");
    expand_program(&forms).expect("the probe expands")
}

/// The paired probe family — every row runs through BOTH judgment
/// faces (the infer chain + its oracle, the check chain + its oracle):
/// the positive rows and the HM negative family, one set, both axes.
const PAIRED_PROBES: &[(&str, &str)] = &[
    // ---- positive: the accept anchors ----
    (
        "accept-anchor",
        "fn fib(n) { if ((n < 2)) { n } else { (fib((n - 1)) + fib((n - 2))) } }",
    ),
    (
        "let-polymorphism",
        "fn id(x) { x }\nfn a(y) { id(1) }\nfn b(z) { id(true) }",
    ),
    (
        "handle-rows",
        "fn f(x) { handle (perform log(x)) { log(v) => { v }, } }",
    ),
    (
        "module-flat-table",
        "module m { define(x, 1); fn f(y) { y } }",
    ),
    // ---- negative: the HM family (the E0009/E0010 faces) ----
    (
        "t1-bool-demand",
        "fn f(x) { if (x) { 1 } else { 2 } }\nfn g(y) { f(1) }",
    ),
    ("t2-not-callable", "fn f(y) { ((1 + 2))(3) }"),
    ("t3-non-numeric", "fn f(x) { (x + \"a\") }"),
    ("t5-cond-mismatch", "fn f(x) { if (1) { 2 } else { 3 } }"),
    ("t7-occurs", "define(omega, ||(x) { x(x) });"),
    // The empty stream (the nil payload — the zero-define module).
    ("empty-stream", "// nothing but trivia\n"),
];

/// One paired-probe drive: both judgment faces, both oracles, twin ≡
/// oracle on each axis (the shared body the positive and negative
/// family tests below consume).
fn paired_drive(
    infer_chain: &SteadyTypecheckChain,
    check_chain: &SteadyCheckChain,
    name: &str,
    items: &[ModuleItem],
) -> (String, String) {
    let infer_twin = infer_chain
        .infer(items)
        .unwrap_or_else(|e| panic!("{name}: the twin inference runs: {e}"));
    assert_eq!(
        infer_twin,
        oracle_inference_axes(items),
        "{name}: the inference twin matches the oracle"
    );
    let check_twin = check_chain
        .check(items)
        .unwrap_or_else(|e| panic!("{name}: the twin check runs: {e}"));
    assert_eq!(
        check_twin,
        oracle_check_axes(items),
        "{name}: the check twin matches the oracle"
    );
    (infer_twin, check_twin)
}

#[test]
fn hm_twin_face_positive_probes_match_on_both_faces() {
    deep_stack(|| {
        let infer_chain = SteadyTypecheckChain::new().expect("the fixed inference twin builds");
        let check_chain = SteadyCheckChain::new().expect("the fixed checker twin builds");
        for (name, source) in PAIRED_PROBES {
            if !matches!(
                *name,
                "accept-anchor" | "let-polymorphism" | "handle-rows" | "module-flat-table"
            ) {
                continue;
            }
            let items = items_of(source);
            let (infer_twin, check_twin) = paired_drive(&infer_chain, &check_chain, name, &items);
            // The positive rows are clean on both axes.
            assert!(
                infer_twin.starts_with("(ok (types"),
                "{name}: the positive row's inference verdict is clean: {infer_twin}"
            );
            assert!(
                check_twin.starts_with("(ok (table"),
                "{name}: the positive row's check verdict is clean: {check_twin}"
            );
        }
        // The empty stream's exact zero-define verdicts on both axes.
        let empty_items = items_of("// nothing but trivia\n");
        let (empty_infer, empty_check) =
            paired_drive(&infer_chain, &check_chain, "empty-stream", &empty_items);
        assert_eq!(
            empty_infer, "(ok (types) (diags))",
            "the empty stream infers to the zero-define module"
        );
        assert_eq!(
            empty_check, "(ok (table (defines) (assigned)) (diags))",
            "the empty stream checks to the zero-define module"
        );
    });
}

#[test]
fn hm_twin_face_negative_probes_match_on_both_faces() {
    deep_stack(|| {
        let infer_chain = SteadyTypecheckChain::new().expect("the fixed inference twin builds");
        let check_chain = SteadyCheckChain::new().expect("the fixed checker twin builds");
        for (name, source) in PAIRED_PROBES {
            if !matches!(
                *name,
                "t1-bool-demand"
                    | "t2-not-callable"
                    | "t3-non-numeric"
                    | "t5-cond-mismatch"
                    | "t7-occurs"
            ) {
                continue;
            }
            let items = items_of(source);
            let (infer_twin, _check_twin) = paired_drive(&infer_chain, &check_chain, name, &items);
            // The negative rows report on the inference axis (the
            // detection-power arm — a guard that passes because
            // nothing fired pins nothing).
            assert!(
                infer_twin.contains("E00"),
                "{name}: the negative row really reports: {infer_twin}"
            );
            // And the twin's verdict is an ok-carrier (the HM judgment
            // face collects findings — the module still loads).
            assert!(
                infer_twin.starts_with("(ok (types"),
                "{name}: the negative row rides the ok carrier: {infer_twin}"
            );
        }
    });
}

/// The corpus HM-axis reclassification: every corpus row classified
/// exactly once on BOTH axes with the exact counts pinned — the
/// diagnostic-carrying fed rows by name, the clean fed rows by count,
/// the layer rejections by count. Any corpus change that shifts the
/// classification (a row moving between clean and diagnostic, a new
/// row, a dropped row) breaks this pin instead of silently riding the
/// sweeps' lower bounds.
///
/// W-SEXP-RETIRE blade 1 (v0.111.0): the classification rides the
/// TARGET reader over the migrated `.ktf` corpus (112 cases — the
/// three skin-divergent rows retired per w-sexp-retire-window SR-2).
/// The stage-divergent family (the malformed keyword-headed forms)
/// moved from the expansion rows to the READER rows — the target
/// grammar rejects what the permissive S-expr reader deferred to the
/// expander (the r130 measured face, re-measured on the target face
/// at the migration).
#[test]
fn corpus_hm_axis_classification_is_pinned_on_both_axes() {
    deep_stack(|| {
        // The classification rides the ORACLES (the twin ≡ oracle
        // equivalence is the sweeps' own face — pinning the corpus's
        // axis through the oracle pins the twin's axis transitively).
        let entries = std::fs::read_dir(CORPUS_DIR).expect("the corpus directory is in tree");
        let mut files: Vec<_> = entries
            .filter_map(|e| e.ok())
            .map(|e| e.path())
            .filter(|p| p.extension().is_some_and(|x| x == "ktf"))
            .collect();
        files.sort();
        assert_eq!(
            files.len(),
            170,
            "the corpus is 170 .ktf cases (109 blade-1 + the sixteen blade-1 annotation rows + the thirteen blade-2 struct rows + the sixteen blade-3 enum rows + the sixteen blade-4 pattern rows)"
        );
        let mut reader_rejected = Vec::new();
        let mut expansion_rejected = Vec::new();
        let mut infer_diagnostic = Vec::new();
        let mut check_diagnostic = Vec::new();
        let mut infer_clean = 0usize;
        let mut check_clean = 0usize;
        for path in &files {
            let source = std::fs::read_to_string(path).expect("corpus file reads");
            let case = path.file_name().unwrap().to_string_lossy().to_string();
            // The classification rides the PIPELINE spine (the same
            // read → expand → LOAD machinery the corpus contract's
            // `validate_target` uses — the loader runs inside the
            // session; the ruling-D path-form module twins reject
            // there, the bare expander never sees them).
            let parsed = {
                let mut session = Session::new();
                parse_target(&mut session, &case, &source)
            };
            let items = match parsed {
                Ok(program) => program.items,
                Err(diags) => {
                    let tag = diags
                        .iter()
                        .find(|d| d.severity == Severity::Error)
                        .map(|d| d.code.tag())
                        .expect("a rejection carries an error diagnostic");
                    if tag == "kerf-read" {
                        reader_rejected.push(case);
                    } else {
                        // kerf-expand: the expander AND the module
                        // loader (the ruling-D family's rejection
                        // class — same row as before the migration).
                        expansion_rejected.push(case);
                    }
                    continue;
                }
            };
            // The inference axis: fed rows split by the diagnostics
            // channel (warnings ride too — E0011 is a finding).
            let infer_verdict = oracle_inference_axes(&items);
            if infer_verdict.contains("E00") {
                infer_diagnostic.push(case.clone());
            } else {
                infer_clean += 1;
            }
            // The check axis: the same split on the check oracle.
            let check_verdict = oracle_check_axes(&items);
            if check_verdict.contains("E00") {
                check_diagnostic.push(case);
            } else {
                check_clean += 1;
            }
        }
        // The layer rejections are shared by both axes (the rows never
        // reach either judgment face).
        assert_eq!(
            reader_rejected.len() + expansion_rejected.len() + infer_diagnostic.len() + infer_clean,
            170,
            "every corpus row is classified exactly once on the inference axis"
        );
        assert_eq!(
            reader_rejected.len() + expansion_rejected.len() + check_diagnostic.len() + check_clean,
            170,
            "every corpus row is classified exactly once on the check axis"
        );
        // ---- the pinned reclassification (the r150 target-face
        // measured face — the blade-1 migration re-measured) ----
        // Reader rejections (16): the token-grammar rows (the
        // unclosed group, the stray delimiter, the unterminated
        // string, the hash token), the two literal-overflow rows, the
        // nesting cap, and the nine stage-divergent rows (the
        // malformed keyword-headed forms the grammar-directed target
        // reader rejects at READ — the S-expr reader deferred them to
        // the expander).
        assert_eq!(
            reader_rejected,
            vec![
                "bnd-007-nesting-257-fails.ktf",
                "neg-001-unclosed-paren.ktf",
                "neg-002-stray-close.ktf",
                "neg-003-unterminated-string.ktf",
                "neg-004-bad-hash-token.ktf",
                "neg-011-malformed-fn.ktf",
                "neg-012-malformed-let.ktf",
                "neg-016-malformed-handle.ktf",
                "neg-054-i64-overflow-literal.ktf",
                "neg-055-float-overflow-literal.ktf",
                "neg-067-match-malformed-arity.ktf",
                "neg-068-match-malformed-arm.ktf",
                // The blade-2 struct reader rows (r166 b4): the
                // missing colon and the unclosed brace.
                "neg-210-struct-missing-colon.ktf",
                "neg-211-struct-unclosed.ktf",
                // The blade-3 enum reader rows (r168 b4): the
                // unclosed brace and the non-spec payload literal.
                "neg-301-enum-unclosed.ktf",
                "neg-302-enum-bad-spec.ktf",
                // The blade-4 reader row (r170 c): the trailing
                // comma before `)` (the tuple pattern's own arity
                // face — the four 3+-tuple rows moved to the
                // expansion layer with the head-NAME ruling).
                "neg-412-trailing-comma-pattern.ktf",
            ]
        );
        // Expansion rejections (23): the malformed-form family, the
        // module family (the loader face — the ruling-D path-form
        // twins AND the duplicate/cycle-string/require-missing rows
        // the pipeline's in-session loader rejects; the old bare-
        // expander face passed them to the fed rows — the r150
        // re-measurement rides the pipeline spine, the same machine
        // as the corpus contract), the macro family and the extern
        // family — the nine stage-divergent rows aside (now
        // reader-rejected on the target face).
        assert_eq!(
            expansion_rejected,
            vec![
                "bnd-010-expansion-limit.ktf",
                "neg-010-top-level-expression.ktf",
                "neg-013-unbound-reference.ktf",
                "neg-014-quote-symbol.ktf",
                "neg-015-set-unbound.ktf",
                "neg-017-malformed-define.ktf",
                "neg-018-module-cycle.ktf",
                "neg-019-module-missing.ktf",
                "neg-020-module-duplicate.ktf",
                "neg-046-forward-reference.ktf",
                "neg-048-module-cycle-string.ktf",
                "neg-049-require-missing.ktf",
                "neg-050-pattern-mismatch.ktf",
                "neg-051-duplicate-pattern-vars.ktf",
                "neg-052-ellipsis-rejected.ktf",
                "neg-053-module-macro-outside.ktf",
                "neg-059-extern-bad-type.ktf",
                "neg-060-extern-bad-abi.ktf",
                "neg-061-extern-collision.ktf",
                "neg-063-match-nonexhaustive.ktf",
                "neg-064-match-nil-last-arm.ktf",
                // The r170 relocation (blade 4): the four 3+-tuple
                // rows moved from the reader layer (the head-NAME
                // ruling replaced the shape ruling).
                "neg-065-match-3tuple-unsupported.ktf",
                "neg-066-match-nested-unsupported.ktf",
                "neg-069-match-unbound-body.ktf",
                "neg-070-match-unbound-scrutinee.ktf",
                "neg-071-match-exhaust-before-pattern.ktf",
                "neg-072-match-scrutinee-before-pattern.ktf",
                // The blade-2 struct police rows (r166 b4): the
                // redeclaration, the define collision, the duplicate
                // field, and the representation-vocabulary field.
                "neg-206-struct-redeclared.ktf",
                "neg-207-struct-define-collision.ktf",
                "neg-208-struct-duplicate-field.ktf",
                "neg-209-struct-field-reserved.ktf",
                // The blade-3 enum rows (r168 b4): the four police
                // faces and the three GZ-4 gap faces.
                "neg-303-enum-redeclared.ktf",
                "neg-304-enum-duplicate-variant.ktf",
                "neg-305-enum-variant-reserved.ktf",
                "neg-306-enum-define-on-variant.ktf",
                "neg-307-enum-match-gap.ktf",
                "neg-308-enum-match-gap-literal-last.ktf",
                "neg-309-enum-match-cross-gap.ktf",
                // The blade-4 pattern rows (r170 c): the four
                // unregistered-family faces and the two GZ-4
                // last-arm struct faces (the three-way irrefutable
                // walk's own).
                "neg-401-pattern-unregistered-family.ktf",
                "neg-402-pattern-nested-unregistered.ktf",
                "neg-403-last-arm-struct-not-irrefutable.ktf",
                "neg-404-last-arm-zerofield-struct-not-irrefutable.ktf",
                "neg-409-enum-name-head-misses.ktf",
                "neg-410-non-symbol-head.ktf",
            ]
        );
        // Inference-axis diagnostics (6): the E0009 family the 127-a
        // sweep doc named — the rows the HM judgment face owns.
        assert_eq!(
            infer_diagnostic,
            vec![
                "neg-031-nonbool-cond.ktf",
                "neg-037-multi-error-collection.ktf",
                "neg-041-car-nonpair.ktf",
                "neg-044-add-bool.ktf",
                "neg-047-write-line-int.ktf",
                "neg-056-type-error-duplicate-codes.ktf",
                // The blade 1 annotation families (r165 b5): the eight
                // E0013 ret/let divergence rows and the four E0009
                // param-contract rows — all infer-axis diagnostics.
                "neg-104-ann-ret-bool-int.ktf",
                "neg-105-ann-ret-int-str.ktf",
                "neg-106-ann-ret-float-int.ktf",
                "neg-107-ann-ret-closure.ktf",
                "neg-108-ann-let-bool-int.ktf",
                "neg-109-ann-let-multi-mixed.ktf",
                "neg-110-ann-param-call-diverges.ktf",
                "neg-111-ann-param-second-pos.ktf",
                "neg-112-ann-param-str-int.ktf",
                "neg-113-ann-ret-bool-str.ktf",
                "neg-114-ann-let-float-str.ktf",
                "neg-115-ann-param-bool-float.ktf",
                // The blade-2 struct rows (r166 b4): the generated
                // ctor/accessor anchors and the user-written
                // let/ret annotations naming the struct.
                "neg-201-struct-ctor-arg-mismatch.ktf",
                "neg-202-struct-accessor-arg-mismatch.ktf",
                "neg-203-struct-let-ann-divergence.ktf",
                "neg-204-struct-ret-ann-divergence.ktf",
                // The blade-3 enum rows (r168 b4): the generated
                // ctor's E0009 payload contract and the E0013
                // user-written ret annotation naming the enum.
                "neg-310-enum-ctor-payload-type.ktf",
                "neg-312-enum-ann-divergence.ktf",
                // The blade-4 pattern rows (r170 c): the ret/param
                // annotation divergences and the two field-position
                // type mismatches over an int scrutinee.
                "neg-405-ann-divergence-struct-ret.ktf",
                "neg-406-ctor-payload-type-mismatch.ktf",
                "neg-407-car-domain-int-scrutinee.ktf",
                "neg-411-param-anchor-struct-mismatch.ktf",
            ]
        );
        // The blade-1 annotation rows: the four positive rows are
        // infer-clean (matching annotations and the degrading unknown
        // name); the twelve negative rows are the E0013/E0009 families
        // below.
        // The blade-2 struct rows: the three positive rows are
        // infer-clean; the four type-error rows ride the
        // diagnostic vector above.
        // The blade-3 enum rows (r168 b4): the four positive rows
        // and the E0002 arity row are infer-clean (the arity face is
        // the check axis's own — neg-030's family); the E0009/E0013
        // rows ride the diagnostic vector above.
        // The blade-4 pattern rows (r170 c): the four positive
        // rows and the E0002 arity row are infer-clean (the arity
        // face is the check axis's own — neg-311's family); the
        // E0013/E0009 rows ride the diagnostic vector above.
        assert_eq!(infer_clean, 81);
        // Check-axis diagnostics (9): the R2/R3/R4/R5/R6/R7 rows the
        // conservative checker owns (the pos-028 row carries the E0008
        // rebind warning — a positive-tagged row on the check axis; the
        // neg-036 literal-handler row retired with the migration —
        // E0007's face is unreachable on the target grammar, SR-2).
        assert_eq!(
            check_diagnostic,
            vec![
                "neg-030-arity-known.ktf",
                "neg-031-nonbool-cond.ktf",
                "neg-032-call-literal.ktf",
                "neg-033-call-numeric-global.ktf",
                "neg-034-handler-arity.ktf",
                "neg-035-unhandled-effect.ktf",
                "neg-037-multi-error-collection.ktf",
                "neg-057-assign-to-captured.ktf",
                // The blade-3 enum row (r168 b4): the generated
                // ctor's E0002 arity face — the conservative
                // checker's own family (neg-030's).
                "neg-311-enum-ctor-arity.ktf",
                // The blade-4 pattern row (r170 c): the struct
                // ctor's E0002 arity face — neg-311's own family.
                "neg-408-ctor-arity.ktf",
                "pos-028-warn-rebind-builtin.ktf",
            ]
        );
        // The blade-1 annotation rows are check-clean too (the
        // double-check chain has no independent annotation judgment —
        // check.rs; the E0013/E0009 rows are the infer axis's own).
        // The blade-2 struct rows are check-clean too (the seven
        // fed struct rows — the E0009/E0013 codes are the infer
        // axis's own).
        // The blade-3 enum rows are check-clean too (the seven fed
        // enum rows — the E0009/E0013 codes are the infer axis's
        // own; the E0002 arity row rides the vector above).
        // The blade-4 pattern rows are check-clean too (the fed
        // pattern rows minus the E0002 arity row — the E0009/E0013
        // codes are the infer axis's own).
        assert_eq!(check_clean, 98);
        // The fed rows: the pipeline-spine machine here measures 109
        // (100 + the nine r170-c fed rows — four positive pattern
        // rows, four E0009/E0013 diagnostic rows, and the E0002
        // arity row); the judgment-axis sweeps
        // (infer_twin_sweep/typecheck_twin_sweep) ride the BARE
        // expander — a loader-independent machine where the module
        // twins stay fed (75 there); the loader's own rejection face
        // is pinned HERE (the division of labor the blade-1
        // re-measurement drew).
        assert_eq!(infer_clean + infer_diagnostic.len(), 109);
        assert_eq!(check_clean + check_diagnostic.len(), 109);
    });
}

/// The FP5 lineage (the 127-a budget row's per-source face): the
/// 600-deep define only rides the programmatic path, and the 127-a
/// round pinned it on the steady route alone — this row pins it on
/// the per-source text route (recompiled per case, both engines) with
/// the exclusion semantics asserted: the deep define drops whole
/// (one E0011 warning, never an error), the shallow define survives.
#[test]
fn infer_twin_budget_row_matches_the_oracle_on_the_per_source_route() {
    deep_stack(|| {
        let mut cur = CoreExpr::Literal {
            span: sp(0, 1),
            value: LiteralValue::Int(1),
        };
        for _ in 0..600 {
            cur = CoreExpr::If {
                span: sp(0, 2),
                cond: Box::new(CoreExpr::Literal {
                    span: sp(0, 1),
                    value: LiteralValue::Bool(true),
                }),
                then_branch: Box::new(cur),
                else_branch: Box::new(CoreExpr::Literal {
                    span: sp(0, 1),
                    value: LiteralValue::Int(2),
                }),
            };
        }
        let items = vec![
            ModuleItem::Define {
                span: sp(0, 3),
                name: sym("deep"),
                value: cur,
            },
            ModuleItem::Define {
                span: sp(0, 11),
                name: sym("shallow"),
                value: CoreExpr::Literal {
                    span: sp(0, 5),
                    value: LiteralValue::Int(7),
                },
            },
        ];
        let per_source = infer_twin_per_source_dual(&items)
            .expect("the per-source route runs on the budget row");
        assert_eq!(
            per_source.vm_text, per_source.eval_text,
            "the per-source route's two engines agree on the budget row"
        );
        let oracle = oracle_inference_axes(&items);
        assert_eq!(
            per_source.vm_text, oracle,
            "the per-source budget row matches the oracle"
        );
        assert!(
            per_source.vm_text.contains("E0011"),
            "the budget warning rides the row: {}",
            per_source.vm_text
        );
        assert!(
            per_source.vm_text.contains("(tdef shallow"),
            "the shallow define survives the exclusion"
        );
        assert!(
            !per_source.vm_text.contains("(tdef deep"),
            "the deep define is excluded whole (no partial annotations)"
        );
    });
}

// ---------- the W-ROW-POLY blade-1 boundary extension (r182-c) ----------

/// The frozen-oracle exemption face, pinned (w-row-poly-window.md
/// §6 blade 1 — the hm_twin_face extension the acceptance gate
/// names): the same row-annotated case through BOTH judgment faces
/// DIVERGES BY DESIGN — the twin (infer.ktf, the row implementer)
/// carries the row type and its verdict; the oracle (frozen at the
/// r174 ruling, `resolve_spec` degrading every `"row"` head to Dyn)
/// absorbs the annotation and never reports. This pin is the
/// regression guard for the exemption itself: if the oracle ever
/// grows a row face silently, this test breaks FIRST and the parity
/// family's twin≡oracle assumption gets re-examined before any
/// sweep does.
#[test]
fn row_poly_frozen_oracle_exemption_face() {
    deep_stack(|| {
        let chain = SteadyTypecheckChain::new().expect("the fixed twin program builds");
        let fspan = sp(10, 40);
        let items = vec![
            ModuleItem::Define {
                span: sp(0, 41),
                name: sym("f"),
                value: CoreExpr::Fn {
                    span: fspan,
                    params: vec![sym("r")],
                    body: Box::new(CoreExpr::Var {
                        span: sp(35, 36),
                        name: sym("r"),
                    }),
                },
            },
            ModuleItem::Annotate {
                span: sp(11, 20),
                anchor: fspan,
                kind: kerf::core::AnnotationKind::Param,
                index: 0,
                spec: row_lv(),
            },
            ModuleItem::Annotate {
                span: sp(28, 39),
                anchor: fspan,
                kind: kerf::core::AnnotationKind::Ret,
                index: 0,
                spec: kerf::core::LiteralValue::String(std::rc::Rc::from("int")),
            },
        ];
        // The twin: the row rides — the E0013 divergence names the
        // row display (the golden file pins the full verdict; this
        // face pins the exemption's two sides).
        let twin = chain.infer(&items).expect("the twin inference runs");
        assert!(
            twin.contains("E0013") && twin.contains("(row x int)"),
            "the twin carries the row type and its divergence: {twin}"
        );
        // The oracle: the row spec degrades to Dyn — no annotation
        // demand, no divergence, the param stays a free var that the
        // ret unifies.
        let oracle = oracle_inference_axes(&items);
        assert!(
            !oracle.contains("E0013") && !oracle.contains("(row"),
            "the frozen oracle absorbs the row spec as Dyn: {oracle}"
        );
        assert_ne!(twin, oracle, "the exemption face diverges by design");
    });
}

/// One `(row (x int) nil)` spec value tree.
fn row_lv() -> kerf::core::LiteralValue {
    use kerf::core::LiteralValue as LV;
    let s = |t: &str| LV::String(std::rc::Rc::from(t));
    LV::Pair(
        Box::new(s("row")),
        Box::new(LV::Pair(
            Box::new(LV::Pair(
                Box::new(s("x")),
                Box::new(LV::Pair(Box::new(s("int")), Box::new(LV::Nil))),
            )),
            Box::new(LV::Pair(Box::new(s("nil")), Box::new(LV::Nil))),
        )),
    )
}

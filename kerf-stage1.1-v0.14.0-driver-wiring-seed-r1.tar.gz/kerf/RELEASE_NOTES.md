# Release Notes

## v0.14.0 — Stage 1.1: driver wiring (typecheck stage in the pipeline + diagnostic-render join + the first Warning producer wired)

The checker joins the pipeline: `read -> expand -> typecheck ->
{compile, eval}` on every face (run / check / parity / REPL).

- **Abort semantics (ruling at implementation)**: Error-level
  findings (R1-R7) abort *before execution* — a definite error means
  the program cannot behave as written, so neither engine runs it;
  Warning-level findings (R8) never block: they ride on the outcome
  (`RunOutcome` / `CheckOutcome` / `ParityReport` gained a
  `warnings` channel), the CLI prints them to the diagnostics sink,
  and exit codes stay untouched.
- **The render join** (stage-1-plan §4 fulfilled): the driver's
  stage-level `DiagnosticCode` gained a data-carrying
  `Typecheck(TypeCode)` variant whose tag *is* the E0xxx registry
  string — diagnostics render rustc-style `error[E0002]:` /
  `warning[E0008]:` with the byte-precise `--> file:line:column`
  locations. Multi-diagnostic batches gained a
  `warning: N warnings emitted` summary line (before the abort line,
  rustc order); warning-free batches render byte-identically to the
  Stage 0 form (the ds10 golden freeze holds), and warnings-only
  batches no longer claim an abort they never made.
- **REPL warning replay**: the session-replay semantics extend to
  warnings — the whole program re-runs per submission, and the
  rendered warnings delta-print under the same prefix rule as
  outputs (shown once, silent on replay, new findings are news).
  Warning submissions enter the accumulated program (legal); only
  errors roll back.
- **Externals, third consumption site**: the driver builds the
  checker's table from the two authoritative sources only
  (`STAGE0_GLOBALS` names + `Builtin::ALL` arity triples — the
  single-source discipline; same construction as the root tests and
  the audit).
- **Baseline co-changes, five disclosed sites**: known-callee arity
  mismatches now surface statically (E0002) before the runtime face
  — the runtime coverage moves to checker-opaque param-mediated
  shapes (`((fn (g) (g 1 2)) car)`); the ds03 snapshot golden updates
  to the static form; ds08 tracks the version bump (0.14.0). A
  design-level validation surfaced on the way: an earlier
  `(set! car 1)` in the REPL correctly poisons `car` for R2 (the
  assign guard spans submissions) — conservative discipline working
  as specified.
- **Numbers**: 881 tests green (846 baseline zero-regression + 35
  net: 17 positive / 18 negative — the non-blocking / abort / render
  / replay guard families in dual balance); audit set 120 -> 130
  (section N: source-reachable E0xxx end-to-end, abort-before-
  execution, warning channels on every face); seven error classes
  stay 7/7; zero new external dependencies (one internal edge,
  L4.5 -> L8).

## v0.13.0 — Stage 1.0: kerf-typecheck seed (E0xxx registry + conservative static R1-R8 + multi-error collection)

Stage 1 opens (the stage-exit GO from 0.12.0 confirmed). The first
sub-stage delivers the external-Rust type-checker path (the §21.6
circular-dependency mitigation): a conservative static checker over
expanded programs, the E0xxx diagnostic registry, and the ruling-21
multi-error collection architecture.

- **The conservative discipline** (docs/develop/v1/stage-1-plan.md §3,
  the authoritative definition): every rule R1-R8 reports only
  *definite* errors, each with a recorded soundness argument. The two
  mirrors keep resolution honest — the compiler's locals-then-globals
  order (`lookup_local` -> `intern_global`) and the expander's
  define-so-far + letrec pre-bind discipline. Position-aware
  visibility: top-level immediate positions see defines-so-far; Fn
  bodies see every define (call time is post-load).
- **R1** unbound reference — the structural-layer re-assertion behind
  the expander's first line of defense (serves directly-constructed
  programs). **R2** known-arity mismatch (IIFE / define-to-Fn /
  builtin arity, under the assign guard and lexical-shadow skip).
  **R3** non-boolean literal condition. **R4** non-callable callee
  (literal directly, or a no-reassign literal define). **R5** handler
  arity mismatch on routed top-level performs. **R6** top-level
  unhandled perform (module load has no dynamic context — the lexical
  handle is the only possible router). **R7** non-callable literal
  handler. **R8** assignment-target surprise — the first Warning
  producer (implicit global creation / builtin rebinding; legal
  semantics, surfaced per report-over-silence).
- **The effect-family soundness key**: performs inside Fn bodies are
  never lexically routed (dynamic handlers may exist at call time) —
  R5-R7 apply to top-level immediate performs only; the walk mirrors
  the Handle compilation order (handler values evaluate before their
  own clauses install).
- **The E0xxx registry** (TypeCode E0001-E0008 + two-level Severity +
  TypeDiagnostic with byte-precise spans) activates the variant-level
  code scheme registered in Stage 0; messages stay single-source with
  the RuntimeError family (R2 mirrors ArityMismatch wording).
- **The Externals face** keeps the builtin table single-source:
  callers construct it from `STAGE0_GLOBALS` + `Builtin::ALL` (the
  root tests, the audit example, and the 1.1 driver wiring are the
  three consumption sites).
- **Layer disclosure**: R2-R7 statically catch what is runtime-only
  today (ArityMismatch / TypeMismatch / UnhandledEffect move to
  compile time) — the checker is a validator, never an executor
  (stage0.md §9.24 TY-A).
- **Housekeeping**: TD-006 cleared (stage0.md header version tag
  synced v8.8 -> v9.9, four-place consistency, user-instruction
  window) — the tech-debt register is at zero open items. PBT
  dependency review concluded DEFER-WITH-TRIGGER (proptest enters at
  1.2 with its first real consumers). Zero new external dependencies
  (two internal edges: kerf-span + kerf-core).
- Tests: 767 -> **846** (net +79: 51 inline + 7 api + 21 root
  integration over the real read->expand->typecheck pipeline); audit
  set 110 -> **120** (section M); seven error classes 7/7 maintained.

## v0.12.0 — Stage 0.11 final round: snapshot suite + performance baseline + stage-exit review

Stage 0 closes. The final L3 round delivers the last two §22.3
milestone items (L6 ≥50 snapshot tests, L8 performance baseline),
runs the full deep-review family, and checks every stage-exit
signal — the stage-exit review concludes GO (pending user
confirmation per §14.6.3 rule 5).

- **The snapshot suite** (`tests/v0/stage0/plan/snapshot_seed_tests.rs`,
  57 cases ≥ 50): one fixed input frozen into one exact output string
  per case, across every pipeline layer — reader skeletons (RS01-10),
  expander trees covering each of the nine primitives in its direct
  form (ES01-10), per-instruction bytecode listings (CS01-10, the
  `op a b` machine form), VM/eval terminal state including the
  compile-ordered globals table and opaque display forms
  (VS01-10 + VE01-02), driver rendering goldens for six negative
  paths plus the check/parity/version/output faces (DS01-10), and
  REPL transcripts with rollback and continuation (TS01-04 + VD01).
  Goldens were recorded from the verified 0.10-r3 baseline via a
  temporary probe, eye-checked line by line, and frozen inline;
  they change only with an explicit behavior change logged in the
  worklog.
- **The performance baseline** (`examples/bench/stage0_baseline.rs`
  re-runnable via `cargo run --release --example stage0_baseline` +
  `docs/develop/v0/stage-0/performance-baseline.md`): B1 compile-fib
  9.3µs median, B2 vm-run-fib(25) 96.7ms (≈2.4µs/call), B3
  eval-run-fib(20) 9.4ms, B4 gc-pressure churn 0.36ms with 1 cycle
  and 1023 swept cells per iteration on the collect-then-retry path,
  B5 driver end-to-end 97.6ms. Regression bar: median worsening
  >25%, or any change in the B4 behavior counters. std-only tooling
  (zero new dependencies).
- **The deep-review family** (§14.5/§14.6/§14.8/§14.9):
  `deep-review-round0.11.md` (D1-D8, committee vote 5.5/5.5, the
  §14.8 deviation ledger B1×2 / B2×3 / B3×3) plus the seven
  inter-stage documents — dataflow coverage (enum exhaustiveness
  with zero unwraps and 33 justified expects), architecture review
  (nine stages all green), design-impl-test three-way coverage
  (zero gaps), hidden-problems assessment (zero P0/P1, zero
  mandatory-fix items), refactoring optimality (7/7 + 8/8),
  performance baseline, and `final-assessment.md` (§22.3 twelve
  items all checked, §21.5 nine switch signals all checked, C1-C6
  cross-stage audit — GO).
- **Code grooming (§14.9)**: two historical-tense file-header notes
  corrected in place (the seven-class coverage note in kerf-vm, the
  diagnostics extension ownership note in kerf-driver); zero TODO /
  FIXME / unimplemented / todo markers, zero glob re-exports.
- **Numbers**: 710 → 767 tests (+57 snapshots; 50:7 positive:negative
  — reverse deviation declared, the determinism-contract layer is
  structurally positive, error-detection semantics stay with the
  existing 7/7 classes), audit set 110/110 re-run green, six
  commands green, R8 encoding face clean on all new files.

## v0.11.1 — Stage 0.10-r2 Capability-model reservation generalization

The capability reservation becomes a SPACE, not a point (user
explicit instruction — adjudication 20). What the reservation
reserves is no longer the concrete io model: it reserves the ability
to register and extend abstract capability models themselves.

- **The capability space** (`kerf-core/src/reserved/capability/`):
  the family contract (`CapabilityModelFamily` — identity card +
  closed error face, no operation signatures: the no-prediction
  discipline), the token calculus (`TokenCalculus` — the sealed-token
  discipline and its registry vocabulary term), the registration &
  extension mechanism (`CapabilityModelRegistry` — register / lookup
  / governing_model / governed_authorities, fail-closed on
  InvalidDescriptor / DuplicateModel / AuthorityConflict, rejected
  registrations mutate nothing), and the io sub-model re-hung as the
  first concrete model (`IoModel` — Error pinned verbatim to the
  frozen IOError; identity card "io" / ["io.read", "io.write"] /
  "CapabilityIO"). Space relations are constraint combinations, not
  inheritance (stage0.md §9.10.2); the registry's unique-subordination
  rejection is axioms A3/A4 made machine-checked (§9.13.2).
- **Freeze continuity (adjudication 17 discipline)**: the 0.10-r1
  module path `reserved::capability_io` survives as a re-export of
  `capability::io` — TypeId identity proven in tests; all four r1
  consumer faces (api tests, root integration tests, the audit set,
  the docs) compile with zero changes.
- **Extension proven at four positions**: a locally-defined model
  (the canonical clock resource — the object-capability lineage's
  fs/net/clock set, knowledge-search verified) registers into the
  same closed world as io from inside the crate, the api position,
  the workspace root, and the audit example — zero framework changes
  each time (the open-closed principle at the organizational layer).
- **Numbers**: 672 → 710 tests (+38: unit 27 / api 6 / root 5;
  25:13 positive:negative — reverse deviation declared, the
  fail-closed family contributes 11 negative cases), audit set
  100 → 110 (section L), six commands green, R8 encoding face clean.

## v0.11.0 — Stage 0.10 Reserved-interface freeze

The Stage 0 interface-reservation milestone: the four reserved
contract families of docs/stage0.md §22.3 are frozen — "interface
defined, implementation may be empty". The milestone checklist's four
interface items (Effect Handlers / multistage programming /
capability-model I/O / compilation cache) are all checked.

- **One freeze anchor, four families (adjudication 17)**: everything
  lives in `kerf-core/src/reserved/` — the L4 semantic-authority
  crate, reachable by every downstream crate and the workspace root.
  The face is *fully self-contained*: zero inbound edges beyond
  `std` (the language value is an associated type, not the VM value —
  L4 never depends on L6; the cache payload is opaque bytes, never a
  typed compiler product). "Depend on abstract constraints, not
  concrete implementations" (SOP §21.12-10(2)) lands in its strongest
  cold-start form, with the six-domain affiliation declared as module
  documentation (the kerf-space marker family stays a Stage 1+
  registration; re-anchoring onto it is additive).
- **Compilable translation of the blueprint sketches (adjudication
  18)**: the §9.1.1-§9.1.4 pseudo-code shapes become real Rust —
  companion traits (`EffectOp`, `CodeCarrier`) carry the
  `Self::Effect::Result` / `Self::Code::Inner` paths verbatim in
  meaning; `impl Expr` becomes an explicit generic; the §9.3.1 vs
  §9.1.1 vocabulary drift resolves in favor of the §9.1.1 block with
  mapping notes (the kernel-level `HandlerClause` stays the primitive
  arm; the reserved `Handler` associated type is the system face).
  Two naming disclosures: the reserved `MultiStage::quote` is the
  staged-code constructor (Stage 2), distinct from the 0.9 datum
  literal; the reserved `Code` is not the expander's `CodeValue`.
- **`effects` (P3)**: `EffectSystem` with `Effect: EffectOp` /
  `Handler` / `Continuation` / `Value` associated types and the
  `perform` / `handle` signatures frozen. Primitive semantics stay in
  the kernel (`CoreExpr::Perform` / `Handle`); Stage 2 owns the
  language-level system.
- **`multistage` (P3)**: `MultiStage` with `quote` / `splice` / `run`
  over a `CodeCarrier` — the Stage 2 staged-programming face.
- **`capability_io` (P3)**: sealed zero-sized tokens
  (`ReadCapability` / `WriteCapability`, hand-written bare-name
  `Debug`), the closed `IoErrorKind` set (Eof / Denied / Interrupted
  / Other), an R8-shaped `IOError`, and the `CapabilityIO` trait.
  Token construction is closed outside the defining crate — no
  public constructor exists at Stage 0 (minting/delegation is the
  Stage 1 additive window; default-deny is the Stage 0 discipline).
- **`cache` (P2 — signatures + executable behavior spec)**:
  `CacheKey` (a 256-bit content digest; the algorithm is a Stage 1
  implementation detail), `CachedResult` (opaque payload bytes —
  adjudication 19: the known follow-on needs of cross-session
  persistence and distributed caches are serialization-shaped, so the
  frozen face never pins a product type), `CompilationCache` with the
  three blueprint methods, and
  `check_compilation_cache_contract` — the behavior spec made
  runnable. Six contracts (store-then-get hit + value equality /
  never-stored miss / post-invalidate miss / no-op invalidate /
  latest-wins / cross-key isolation) assert against any
  implementation; Stage 1 caches reuse the kit directly as their
  contract tests. The kit's detection power is itself tested: five
  deliberately broken implementations (never-hit / no-invalidate /
  no-overwrite / wrong-key / payload-corrupt) are all caught.
- **Signature-stability snapshots**: canonical conforming
  implementors ("witnesses") live at four consumption layers (inline
  tests / crate api tests / workspace-root integration / the audit
  example) — any drift in the frozen shape breaks a witness
  compilation, which the six-command acceptance turns into a hard
  gate.
- **Counts**: 672:0:0 workspace tests (624 baseline zero-regression,
  net +48 — the roadmap agenda met verbatim; round 32:16 = 1:0.5
  reverse-skew declared: a reservation round's acceptance face is
  type existence and signature snapshots, structurally positive;
  negative-testable faces are exhausted — kit detection ×5, IOError
  four-kind paths, R8 shapes at two layers, token discipline). Audit
  set 90 → **100** (section K — reserved-face contracts; §7.1.1
  seven classes stay 7/7). Zero implementation-side runtime-semantics
  defects (all round fixes were compile-level or shape-level).

## v0.10.0 — Stage 0.9 Macro system seed

The Stage 0 macro milestone: the basic hygienic macro system
(`define-syntax` + `syntax-rules`), the structured `CodeValue`, the
module loading layer, and the `quote` datum literal. The SOP §7.1.1
error-class matrix reaches **7/7** — the module-cycle class lights up
end-to-end, at both the sub-stage and the gate threshold.

- **Hygienic macros, two complementary mechanisms (adjudication 14)**:
  scope coloring with the *binder-scopes subset* judgment (the 0.4
  membership rule generalized to Racket's "Binding as Sets of
  Scopes" — non-macro code is structurally unchanged, 551-test
  baseline zero-regression) decides expansion-time binding;
  *rename-on-capture* (the §9.38(b) second algorithm) carries the
  decision into the name-based back half (CoreExpr/bytecode/VM
  resolve `Var` by name — an introduced binder colliding with a
  spliced argument name is renamed to `name__macro_N` together with
  its introduced references). Observable proof: without hygiene the
  capture test yields 200, with it 101.
- **`define-syntax` / `syntax-rules`** (§8.10): fixed-arity patterns
  (the ellipsis `...` is a registered Stage 0 boundary — rejected at
  registration, fail-closed), literals matching by symbol text,
  `_` wildcards, pattern variables splicing use-site arguments
  *verbatim* (span/scopes/phase/name all keep their use-site
  identity), introduced nodes carrying generation+1 (the dea12b
  tracing contract — macros expanding into macros increment per hop).
  Macros are lexically scoped like defines (a nested module's macros
  vanish with their frame); a head naming nothing reports the unified
  unbound-identifier judgment (adjudication 16 — the Racket rule).
- **Module loading layer (§8.9 Stage 0 slice)**: `load_program`
  collects declared (nested) modules into the flat namespace,
  walks every `require` edge, and rejects cycles with a three-color
  DFS reporting the full path (`module cycle detected: a -> b -> a`)
  — **§7.1.1 class 7 lit, completing 7/7 at both thresholds** —
  plus not-found and duplicate declarations. The deliverable is graph
  validation + the dependency-first instantiation order (`LoadPlan`);
  visibility merging is the Stage 1 module system. The driver's
  `parse` runs it fail-fast; module diagnostics render with
  line:column locations.
- **`CodeValue`** (§6.3.3 Stage 0 projection): the structured
  macro-phase code value — `from_syntax`/`to_syntax`/`substitute`
  (the pattern-variable splice face)/`alpha_rename` (the
  rename-on-capture remedy face, public)/`symbols` (the honest
  Stage 0 census — the semantic `free_variables` is the Stage 2+
  slot)/`to_source` (the diagnostics observability face).
- **`quote`** (plan-0.7 decision 13 redeemed): atoms and proper
  lists fold into `LiteralValue::Pair` chains terminated by `Nil`
  (the 0.1 consumption face — `ConstKey::Pair` gets its first
  production consumer); symbols fail closed (`QuoteUnsupportedDatum`
  — no Stage 0 value carrier; the Stage 1 evolution slot).
- **`ModuleItem::DefineSyntax`**: the fourth declaration variant —
  a faithful declaration record with zero code (the `Require`
  precedent applied to the macro phase; compiler and evaluator both
  skip it).
- Adjudications 14/15/16 and 13 decisions recorded in plan-0.9.md §4
  (dual-mechanism hygiene; the `nil` empty-literals spelling — the
  reader rejects `()`, so `nil` is the language's empty-list
  spelling everywhere; the unified unbound judgment). Tests: net +73
  (34:39 — deviation declared: the four-stage macro E2E is the plan
  row's acceptance body), cumulative 624 green, audit set 80 → 90
  (section J), all seven error classes lit.

## v0.9.0 — Stage 0.8 Driver seed

The compiler entry point (Layer 8): pipeline orchestration over both
execution engines, the diagnostics rendering closure (TD-001 paid),
session/file interning, and the `kerf` CLI/REPL. Every crate of the
0.0 charter is now implemented — 9/9 (TD-003 cleared to zero).

- **Pipeline orchestration**: `kerf_driver::run_source` drives
  `read -> expand -> {compile -> VM, eval}`; `Engine::Vm` / `Engine::Eval`
  select the engine; `ParsedProgram` is the stable fork point (the
  same expanded program feeds both, exactly as the 0.7 cross-check
  established). `check_source` compiles + verifies without executing.
- **Parity as data**: `run_parity` runs both engines over the same
  input and compares three faces — final value repr, output
  sequence, and the define-name global table (`parity_repr` with
  both heaps alive — a divergence is *reported*, never a panic; the
  `--parity` CLI flag surfaces it as `parity: PASS/FAIL`).
- **Diagnostics rendering closure (TD-001)**: `LineIndex` derives
  1-based line + **character** column from byte offsets at render
  time (never stored — single source of truth); the renderer emits
  rustc-flavored `error[kerf-read]: msg`, ` --> file:line:col`,
  source excerpts with caret underlines (span-length, line-clamped),
  multi-diagnostic separation and a summary line. `Diagnostic` is
  the §8.7 slice: `Severity`/`DiagnosticCode`/`primary_span:
  Option<Span>` — position-less errors render without a fabricated
  location (no DUMMY spans, ever).
- **Session/file interning**: `Session` maps names to sequential
  `FileId`s with upsert semantics (the REPL re-reads one growing
  file); diagnostics render against the session's sources — the
  single source of truth.
- **REPL (session-replay semantics)**: both engines are per-program
  by design, so the REPL accumulates source and re-runs the whole
  program per submission; expressions wrap as `(define $repl:N expr)`
  (the r110 "top-level expression channel = define calling form");
  failed submissions roll back (the session survives any error); the
  input tape replays deterministically (a `read-line` past the tape
  ends with `Eof` — interactive stdin is the `run` mode's pipe).
- **CLI**: `kerf run <file> [--engine vm|eval] [--parity]`,
  `kerf check <file>`, `kerf repl`, `--help`, `--version`; exit codes
  0/1/2 (success / program-or-environment / usage); piped stdin feeds
  a run's `read-line` calls; hand-rolled parsing, zero dependencies.
- **Consumer-face extensions** (all additive): `ReadError::offset()`,
  `CompileError::span()`, `kerf_compiler::ModuleItem` re-export
  (ExpandError::span() existed since 0.4 — its doc comment named this
  sub-stage). New DAG edges L1->L8 and L7->L8 (ruling 11, plan-0.8).
- **Audit set**: 70 -> 80 (Section I: the five source-reachable
  error classes rendered end-to-end through the driver, multi-file
  multi-diagnostic collection, REPL rollback, check rejection,
  parity divergence-as-data, CJK character columns, position-less
  rendering). Error classes 6/7 held (module circular dependency
  stays DEFERRED to 0.9).
- **Fixed in-round**: TapeIo write recording (the VmIo face is the
  engine's single output recording point — a no-op face silently ate
  all REPL output) and stdin pre-read scoping (only `run` consumes
  piped stdin; the REPL reads its own submissions).

## v0.8.0 — Stage 0.7 Runtime seed

The runtime layer (Layer 7): the docs/stage0.md §19.4 mark-sweep
collector and the `eval` meta-circular evaluator — the dual-execution-
path cross-check goes live (the same expanded program runs through
`compile → VM` AND through `eval`; ≥15 programs agree structurally,
and the STAGE0_GLOBALS tables are officially asserted three ways).

- **GC (§19.4)**: mark bits and a free list live on the kerf-vm `Heap`
  (the heap-method skeleton verbatim — `test_and_set_mark`,
  `clear_marks`, `free`, slot iteration); the three-phase orchestration
  (explicit-work-stack mark — a 10^5-deep chain marks without host
  recursion; linear sweep; symmetric reset) lives in
  `kerf_runtime::gc` (Layer 7). `Roots` carries the four §19.4 root
  classes plus the handler-table extension (installed handler values
  are frame-adjacent state — missing them dangles handlers).
- **collect-then-retry** (the point error.rs announced at 0.6): the
  budget safety point now checks the LIVE footprint (frames + live
  cells); on exhaustion an injected collector runs one cycle and the
  charge retries. Without a collector the 0.6 fail-closed behavior
  stands; `Vm::with_collector` / `with_budget_and_collector` inject;
  `Vm::register_foreign_ref` protects host-held values (§19.4 root
  class four); `Vm::snapshot_roots` snapshots every class.
- **eval (the meta-circular evaluator)**: the nine semantic primitives
  interpreted directly over CoreExpr, mirroring the compiler/VM
  decision-for-decision — name resolution (tail-first scan,
  `lookup_local` verbatim; shadowing = new slots), evaluation order
  (§19.3: args left-to-right, then the callee), assign's Dup
  semantics, Require as a no-op, Module flattening, Handle's
  install-run-pop, Perform's nearest-handler rule. Closures are the
  "basic closure" P0 scope (free names resolve globally; the captured
  env is a dormant value snapshot — the 0.6 duality; lexical capture
  is a Stage 1 activation on BOTH engines). `EVAL_DEPTH_LIMIT`
  guards the Rust stack (the evaluator recurses in host frames while
  the VM stacks heap frames — a registered asymmetric boundary).
- **Builtin single source**: the 18 STAGE0_GLOBALS operation semantics
  extracted into shared kerf-vm functions (`arith`, `compare`, `car`,
  `cdr`, `cons`, `not`, `read_line`, `write_line`) — the VM and the
  evaluator call the SAME bodies (zero drift by construction, stronger
  than parity tests). The name/arity tables are asserted three ways
  (expander ↔ registry ↔ evaluator seeding).
- **parity**: `parity_repr` renders values structurally (pairs as
  dotted notation recursing both arms; closures and builtins as
  opaque forms — addresses never participate); `assert_parity`
  compares engines. Error parity is exact too: the same failing
  source produces the same variant AND the same rendered message on
  both engines.
- **Fixed (found this round)**: the evaluator's `invoke` swapped-out
  environment locals were outside the GC roots — a recursive call's
  in-flight caller values could dangle after a cycle; now
  root-protected through the evaluator's temp stack (§19.4
  explicit-roots class of a Rust evaluator), with program isolation
  (no lexical residue across `eval_program` calls) as the
  same-family backfill.
- `RuntimeError` grows to 11 variants (`EvalDepthExceeded`); the
  seven-class matrix holds at 6/7 (module cycles remain 0.9's). The
  audit set grows 60 → 70 (Section H: evaluator negatives + the GC
  retention guard + the parity-detector self-check). 427 tests green
  (71 new, 19:52 positive:negative — deviation disclosed in
  plan-0.7.md §3: the GC family counts entirely as defense-negative
  and the parity battery IS the acceptance criterion).

## v0.7.0 — Stage 0.6 VM seed

The bytecode virtual machine (Layer 6, a PERMANENT Rust base — rewriting
it in kerf is constitutionally excluded): the docs/stage0.md §19.5
switch-dispatch iterative main loop with heap-allocated call frames
(the TD-023 anchor — kerf-level recursion consumes the frame vector,
never the Rust stack). Source → value runs end to end for the first
time: fib(25) = 75025 executes on the full chain (reader → expander →
compiler → verify → VM).

- `Vm::new(bytecode)` runs the load-time verify hook (plan-0.5 ruling
  4, second line of defense) and seeds every STAGE0_GLOBALS name as a
  builtin value (18-name registry, `Builtin::ALL`); plain globals stay
  unbound until their `store-global` runs (`UnboundGlobal` on early
  loads — the dynamic-order face verify cannot decide statically).
- 24-op full execution: per-frame operand stacks, `pc` monotonicity
  with the closed jump/call/ret exception set, and the evaluation-order
  contract consumed exactly as the 0.5 compiler emits it (args
  left-to-right, callee on top — plan-0.6 ruling 5 reconciles the
  §19.5 skeleton drawing against the compiler's actual emission).
- `RuntimeError` (10 variants, every one carrying the source `Span`
  resolved through the debug_info table — the §12.1 consumption row):
  arity mismatches on both call faces and type mismatches across four
  contexts light SOP §7.1.1 classes 4 and 5 (6/7 lit); plus
  `UnhandledEffect`, `DivByZero`, `ArithmeticOverflow` (checked i64 —
  no wrapping), `BudgetExceeded`, `Eof`, `RetFromEntry`, and
  `StackUnderflow` (handler-stack face — §19.5 trap 2: explicit depth
  checks on every stack access, defense in depth over verify).
- Effects at 0.6 (plan-0.6 ruling 6): `perform` finds the nearest
  installed handler and invokes it as a function — the handler's
  return value IS the perform's value; real continuations stay
  reserved in the frozen ext1 frame slot (Stage 1+).
- The §19.4 allocation budget is the Stage 0 safety point: frames +
  heap cells share one `u32` budget (`DEFAULT_BUDGET` = 8 MiB), which
  bounds every non-terminating program (kerf has no loop primitive —
  all unbounded growth routes through calls and allocations). The 0.7
  collector hooks `gc_cycle` at the same point.
- Pluggable I/O (`VmIo`): `read-line` / `write-line` builtins over a
  deterministic `BufferIo` default (strict-string writes; the 0.8
  driver wires real streams).
- Fixed in passing (found by this round's nested-handle tests, §20.6
  full-class sweep): the 0.5 compiler's `end_closure` restored `cur`
  by decrementing — every program with a second, sibling, or nested
  closure past the first emitted into the wrong proto. Now restored
  through a saved-caller stack (`cur_stack`), with a two-case
  regression pair pinning sibling and nested closure shapes.

Verification (cold build, SOP §3.2): 0 error / 0 warning; fmt zero
diff; clippy `-D warnings` clean; **356 passed / 0 failed** (300
baseline + 56 new: 54 VM tests at 12:42 plus the 2-case compiler
regression pair; round ratio 14:42 = 1:3, cumulative 89:267 = 1:3);
`cargo run --release --example stage0_gate_audit_r1` — **AUDIT PASS
60/60** (A10 + B10 + C5 + D5 + E10 + F10 + G10).

## v0.6.0 — Stage 0.5 compiler seed

The bytecode compiler (Layer 5): CoreExpr -> Bytecode, implementing
the direct-style translation of docs/stage0.md §19.3 with jump
backpatching, a deduplicated constant pool, an interned global symbol
table, and the per-instruction debug_info table (§19.3 invariant 3 —
no bare instructions; §12.1: the VM resolves runtime errors back to
source through `Bytecode::span_of`).

- `compile_program(items) -> Bytecode` and `compile(expr) -> Bytecode`
  — the two public entries (program form ends in a depth-0 `halt`,
  single-expression form in a depth-1 `halt`).
- 24-op set: the §8.12 groups (stack / function / control flow / data
  construction / variable access / arithmetic / termination) plus
  `push-handler` / `pop-handler` / `perform` — the frozen
  Perform/Handle primitives (TD-005) carried directly. Every operand
  slot's meaning is declared on the opcode (`Opcode::operand_help` —
  "operands fully resolved").
- Eval-order contract (§19.5): args left to right, callee on top;
  `call n` pops n + 1 and pushes the result. Tail-position `if`
  compiles branches straight into the proto terminator with no merge
  jump (§19.3 trap 1) — Stage 1+ TCO only rewrites the compiler, never
  the VM. `handle` bodies compile non-tail (handlers pop before
  return; tail pass-through is registered Stage 2 effect-elimination
  theory).
- Defense in depth (plan-0.5.md ruling 4): compile-time bookkeeping
  (depth tracking, patch assertions, placeholder drain — all
  structured `CompileError`s) plus a public `Bytecode::verify`:
  operand bounds, debug-info parallelism, terminal shape, `halt`
  entry-only, and a DAG basic-block stack-depth propagation that
  catches underflow and imbalance in hand-built or corrupted
  products. The 0.6 VM is expected to call verify before loading.
- `CompileError` — 13 variants, R8 message shapes, `std::error::Error`
  (no source chain: inputs are pre-validated by the front end).
  `COMPILE_DEPTH_LIMIT = 1024` mirrors the expander budget with 2x
  headroom (reader 256 < expander 512 < compiler 1024).
- Constant pool dedup by canonical key: all NaNs fold to one slot
  (Eq reflexivity); +0.0/-0.0 stay distinct (bit-pattern keys — dedup
  is an optimization, not a semantic merge).
- Span discipline: every debug_info entry is copied from a CoreExpr
  node; the only synthesized span is the cold-start anchor for the
  `halt` of an empty program (single-generation ROOT — the TD-002
  no-cross-generation-join guarantee extends to the compiler side).
- kerf-core now re-exports the span coordinate types
  (`FileId`/`ByteOffset`/`ExpansionId`) for downstream span
  construction — no new DAG edge (plan-0.5.md §4 decision 14).
- Workspace: 300 tests green (48 new, positive:negative 12:36 = 1:3);
  §7.3.1 audit set 40 -> 50 (Section F: compile depth cap + verify
  rejection family over hand-built products). TD-003 resolves one
  more scaffold (compiler implemented; vm/runtime/driver remain).

## v0.5.0 — Stage 0.4 expander seed

The macro expander (Layer 3): syntax objects -> the frozen CoreExpr
kernel, implementing the expansion-loop skeleton of docs/stage0.md
§19.2. The 0.4 slice is the core-form skeleton — transformer
execution and the def-site / use-site hygiene union are the 0.9 macro
system (§8.10).

- `expand_program(forms) -> Vec<ModuleItem>` and
  `expand(ctx, stx) -> CoreExpr` — the two public entries. The module
  top level accepts declarations only (`define` / `require` /
  `module`); bare top-level expressions fail closed (the top-level
  expression channel is the `define` calling form — r102 corpus
  anchor; the driver owns the main composition at 0.8).
- All nine expression forms: `fn` / `if` / `let` (single, multi and
  empty binding specs, let* progressive visibility) / `do` (Begin ->
  Let chain desugaring with `_` discards, §6.12.6) / `set!` (target
  must resolve — Scheme semantics) / `perform` / `handle` /
  application / atoms, with `nil` as the reserved literal keyword and
  `(define (f x) body)` sugar mapping near-identically to
  `Define{f, Fn{...}}` (§7.3.5). Defines pre-bind their name
  (letrec-shaped top-level rule — recursive functions resolve).
- Hygiene skeleton (§19.2 invariant 2): every binding construct
  allocates a fresh scope, colors its subtree on descent
  (`with_scope_added` in production use — the 0.2 contract), and
  resolution is scope-set keyed: a name bound at a scope the
  identifier does not carry stays unbound. Nested modules are
  scope-isolated (§8.9 direction).
- Phase closure (§8.9 rule 1, 0.4 slice): every touched node must be
  runtime-phase — macro-phase syntax fails closed with
  `PhaseViolation`.
- `EXPANSION_LIMIT = 512`: the expansion work budget — a structured
  `ExpansionDepthExceeded` error, never a stack overflow (§19.2
  invariant 1); independent of the reader's 256 source-tree cap, it
  bounds synthesized and (at 0.9) macro-produced trees.
- `ExpandError` — seven variants, each carrying the byte-precise
  span; `std::error::Error::source` chains into `CoreError` (the
  core constructor floor is re-asserted at expansion time).
- `STAGE0_GLOBALS` — the 18-name Stage 0 global function table
  (arithmetic/comparison, pair/predicates, minimal I/O — §8.8
  traditional globals); kerf-runtime asserts parity when seeding the
  global environment at 0.7.
- SOP §7.1.1 error classes 2 (unbound identifier) and 7 (expansion
  depth exceeded) are now lit — 4/7 cumulative. The §7.3.1 audit set
  grows monotonically 30 -> 40 (new section E: ten expander
  negatives). Workspace: 252 tests green (48 new, 12:36 = 1:3).
- TD-002 adjudicated and resolved: the 0.4 expander copies source
  spans only (zero span construction — desugared nodes reuse the
  source spans of the same generation), so cross-generation joins
  structurally cannot occur; `JoinExpansionMismatch` stays a designed
  rejection, and the 0.9 macro system registers span-set
  representation (def-site ∪ use-site) as its design agenda
  (plan-0.4.md §4 ruling 3).

## v0.4.0 — Stage 0.3 reader seed

The surface-syntax reader (Layer 2): the first source-level pipeline
entry, implementing the typed-token-stream contract of docs/stage0.md
§8.1 and the `read : string → Result<SyntaxObject, ReadError>`
capability signature (§278), pluralized to whole programs.

- `StxToken`/`StxTokenKind` — the §8.1 TokenKind S-expression subset
  (Delimiter / Identifier / IntLiteral / FloatLiteral / BoolLiteral /
  StringLiteral / Eof); modern-skin kinds arrive additively at Stage 2.
  The tokenize guarantees all hold: lossless coverage (inter-token gaps
  are exactly whitespace and `;` comments — test-anchored), precise
  byte spans (multi-byte UTF-8 exact), structured lexical errors.
- `lex(file_id, source)` and `read_program(file_id, source)` — the two
  public entries; a token slice without Eof is tolerated (end of slice
  behaves as end of input).
- Numbers follow Rust `i64`/`f64` parse semantics (`.5`, `1.`, `1e5`
  are floats); number-shaped atoms that parse as neither are rejected
  fail-closed (`MalformedNumber`) — no Racket-style symbol fallback.
  Booleans are exactly `#t`/`#f` (`#true` fails closed). Strings take
  escapes `\" \\ \n \t \r` with raw newlines legal. `;` line
  comments; the BOM is skipped like whitespace.
- `()` is rejected at read time as `EmptyApplication` (SOP §7.1.1
  error class 3, lit at the reader as defense in depth — the quoted
  empty list is covered by the `nil` literal; honest boundary in
  plan-0.3.md §4.3). Bracket and reader-macro characters
  (`[ ] { } ' \` ,`) fail closed — no reader macros in Stage 0; quote
  is spelled `(quote x)`.
- The list-nesting cap is a public constant (`NESTING_LIMIT = 256`),
  boundary-tested both ways (256 legal, 257 rejected); the cap also
  bounds the descent's native recursion depth. Unclosed lists report
  the innermost open `(` — deterministic and closest to where input
  ran out.
- `ReadError` — ten variants, all byte-precise, R8 message shapes; the
  `InvalidSymbol` rendering is byte-identical across the reader,
  syntax and core layers (single-source dictionary, cross-crate
  asserted).
- SOP §7.3.1 audit set revision 1: `examples/audit/
  stage0_gate_audit_r1.rs` — 30 cases (10 single-statement + 10
  multi-statement + 5 complex + 5 error-recovery), re-runnable via
  `cargo run --release --example stage0_gate_audit_r1`; error-class
  coverage 2/7 (syntax error + empty application lit; 5 structurally
  deferred to 0.4/0.6/0.9). Grows monotonically until 7/7 at the 0.11
  stage gate.
- The `TokenLike` test stand-in is retired exactly as its charter
  promised: seed tests now reduce spans over real reader tokens.
- 60 new tests (15 positive + 45 negative = 1:3; 43 unit + 8 crate
  API + 9 cross-crate); workspace total 204, cold-build green under
  the six-command gate. TD-003 shrinks to 5 scaffold crates.

## v0.3.0 — Stage 0.2 SyntaxObject seed

The surface-syntax data layer (Layer 1), implementing the syntax-object
four-tuple of docs/stage0.md §3.3.

- `SyntaxObject` = datum + span + scopes + phase. The span is a
  mandatory field (never `Option`, never a dummy — the TD-004 structural
  discipline extended to the syntax layer); list members are full syntax
  objects, not bare datums ("extended S-expression", §7.3.6 — per-node
  wrappers are what per-identifier hygiene needs, §19.2 invariant 2).
- `StxDatum` — the skeleton atoms (Symbol/Int/Float/Bool/String) plus
  proper lists; `()` is legal datum; improper (dotted) lists are a 0.3
  reader grammar decision (quoted pair data already lives in
  `kerf_core::LiteralValue::Pair`).
- `StxSymbol` — validated, opaque identifier (floor byte-identical to
  `kerf_core::Symbol`'s: non-empty, no whitespace, no control
  characters). A pipeline-phase twin, not a duplicate: the 0.4 expander
  crosses the boundary as source text through the core validated `&str`
  constructors, so "anything the reader accepts passes both floors"
  holds by identical validation (plan-0.2.md design record 2).
- `Phase` — the frozen two-level model (Runtime = 0, MacroExpansion =
  1, §8.9) with a checked `from_u8` decoder; phase closure is an
  expander (0.4) invariant, the data layer stores per-node phases
  without cross-validation.
- `ScopeId`/`ScopeSet` — the hygiene substrate: sorted, deduplicated
  storage (deterministic iteration — no HashMap randomness), functional
  `union` and the `is_subset_of` lexical-resolution query (§9.38
  scope-coloring sketch); scope freshness is a 0.4 expander-context
  discipline.
- Consumption contracts pre-anchored by integration tests:
  `visit_spans` pre-order traversal and the deep functional
  `with_scope_added` scope flip (principle 23 — the receiver is never
  mutated) for the 0.4 expander; the token→stx assembly pattern
  (token spans reduce to the list span, token text flows through the
  checked symbol constructor) for the 0.3 reader.
- 48 new tests (12 positive + 36 negative = 1:3; three layers: 32
  unit + 8 crate API + 8 cross-crate); workspace total 144, all green
  under the six-command gate (cold build). TD-003 shrinks to 6
  scaffold crates. CJK identifiers remain legal at the floor
  (registered test-fixture whitelist).

## v0.2.0 — Stage 0.1 core expression seed

The frozen semantic-primitive kernel (Layer 4), plus the two design
adjudications that unblocked it (docs/develop/v0/stage-0/
0.1-design-adjudications.md).

- TD-005 ratified: `CoreExpr` carries the nine semantic primitives
  (Fn/Apply/If/Var/Literal/Assign/Let/Perform/Handle) per SOP §21.12-11;
  the historical §3.2 frozen set maps onto it via the §6.12.6
  semantic-equivalence table (shared semantic core, closed both ways).
  Declaration layer `ModuleItem` = Define/Require/Module; `do` sugar
  desugars to `Let` at 0.4.
- TD-004 ratified: every node carries a real `Span` (never `Option`,
  never a dummy); dependency edge kerf-span → kerf-core added to the
  workspace DAG (docs/graph/stage-0/dataflow.md synced).
- `Symbol`: opaque checked identifier (non-empty, no whitespace, no
  control chars — conservative floor; full grammar lands with the 0.3
  reader). Validated `&str` constructors (`fn_`/`var`/`assign`/`perform`/
  `handle`, `Binding::new`, `HandlerClause::new`, `ModuleItem::define`/
  `require`/`module`) pre-anchor the 0.4 expander contract; duplicate
  params / duplicate handler effects are rejected deterministically.
- `CoreExpr::visit_spans` / `ModuleItem::visit_spans`: pre-order span
  traversal — the expander consumption contract and the no-dummy-span
  audit primitive.
- Tests: 48 new cases (unit 32 + crate API 8 + cross-crate integration
  8, positive:negative = 12:36 = 1:3); workspace total 96, all green.
- Verification: SOP §3.2 six commands all green on a cold build (see
  docs/develop/v0/stage-0/plan-0.1.md).

## v0.1.0 — Stage 0.0 cold-start bootstrap

First engineering artifact of the kerf compiler, reconstructed from the
upstream document repository (sop.md v15.0-verified + stage0.md design
blueprint, content state v9.8).

- Cargo workspace, edition 2024: root aggregation package + 9 `kerf-*`
  member crates wired exactly along the SOP §18.5 dependency DAG.
- Seed MUV `kerf-span` (Layer 0): `FileId` / `ByteOffset` / `ExpansionId` /
  `Span` with checked invariants (stage0.md §8.6 four-field model, §12.1
  byte-offset representation). Line/column rendering deferred to the
  diagnostics framework (TD-001).
- Test architecture per SOP §8.4.6/§9.1: root `tests/runner.rs` single
  entry + three-layer suite (unit / crate API / cross-crate integration).
- Stage 0 roadmap fixed: sub-stages 0.0-0.11 (minimal semantic kernel →
  infrastructure depth → macro engine → interface-reservation freeze →
  stage gate).
- Verification: SOP §3.2 six commands all green (see
  `docs/develop/v0/stage-0/plan-0.0.md`).

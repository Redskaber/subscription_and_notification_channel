# benchmarks/ — 跨 crate 端到端性能基准

Stage 0 验收项 5（性能基线）落位于 0.11；crate 微基准入各 crate benches/。

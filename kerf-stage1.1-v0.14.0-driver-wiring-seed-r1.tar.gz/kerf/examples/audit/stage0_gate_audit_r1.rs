//! Stage 0 gate audit set, revision 1 — SOP §7.3.1 negative audit.
//!
//! Run: `cargo run --release --example stage0_gate_audit_r1`
//! (exit 0 = all 50 cases behave as audited; any panic = audit failure).
//!
//! Composition (§7.3.1 rule 2, full obligation effective from sub-stage
//! 0.3 — plan-0.0.md §6 cold-start adaptation ends here):
//! - Section A: 10 single-statement negative cases
//! - Section B: 10 multi-statement/multi-form negative cases
//! - Section C: 5 complex-program negative cases (deep nesting)
//! - Section D: 5 error-recovery cases (Stage 0 recovery semantics:
//!   structured errors with byte-precise locations + call-level
//!   isolation; panic-mode/sync-set machinery is §9.36.8 registered
//!   theory, a Stage 2 window item)
//! - Section E: 10 expander negative cases (sub-stage 0.4 — monotonic
//!   growth per §7.3.1 rule 4)
//! - Section F: 10 compiler negative cases (sub-stage 0.5 — compile
//!   depth cap + Bytecode::verify rejection family over hand-built
//!   products; monotonic growth per §7.3.1 rule 4)
//! - Section G: 10 VM negative cases (sub-stage 0.6 — SOP §7.1.1
//!   classes 4/5 light up: arity mismatches on both call faces and
//!   type mismatches across four contexts, plus the effect / division
//!   / overflow / budget fail-closed paths)
//! - Section H: 10 runtime negative cases (sub-stage 0.7 — the eval
//!   path mirrors Section G case-for-case, plus GC retention and the
//!   parity detector self-check)
//! - Section I: 10 driver end-to-end cases (sub-stage 0.8 — the five
//!   source-reachable error classes through the full pipeline with
//!   rendered line:column locations, multi-file multi-diagnostic
//!   collection, REPL rollback, the check face, parity reporting and
//!   the CJK character-column rendering edge)
//! - Section J: 10 macro/module/quote negative cases (sub-stage 0.9 —
//!   the syntax-rules matching family, the hygiene defense family,
//!   the quote boundary, and the §7.1.1 class 7 module-cycle family;
//!   monotonic growth per §7.3.1 rule 4)
//! - Section K: 10 reserved-face contract cases (sub-stage 0.10 —
//!   the frozen reservation face of docs/stage0.md §9.1.1-§9.1.4:
//!   effects/multistage witness semantics, the sealed capability
//!   tokens, the R8 I/O error face, and the executable cache
//!   behavior contract; monotonic growth per §7.3.1 rule 4)
//! - Section L: 10 capability-space cases (sub-stage 0.10-r2 — the
//!   general capability-model framework of docs/stage0.md §9.10/
//!   §9.13: the family contract, the token calculus, and the
//!   registration/extension registry with fail-closed identity
//!   validation; the io sub-model re-hung as the first concrete
//!   model with freeze continuity; monotonic growth per §7.3.1
//!   rule 4)
//! - Section M: 10 conservative-static-checker cases (sub-stage 1.0
//!   — kerf-typecheck R1-R8 over the real pipeline: the definite-
//!   error-only rules (arity/callee/condition/effect families), the
//!   warning-level assignment surprise, and the E0xxx registry with
//!   the single-source Externals face; monotonic growth per §7.3.1
//!   rule 4)
//! - Section N: 10 driver-wiring cases (sub-stage 1.1 — the checker
//!   mounted between expand and both engines: source-reachable
//!   E0xxx diagnostics end-to-end with the rendered registry tags,
//!   abort-before-execution, the warning channel through run/check/
//!   parity and the REPL delta replay; monotonic growth per §7.3.1
//!   rule 4)
//!
//! Error-class coverage (SOP §7.1.1) at sub-stage 0.6: classes 1
//! (syntax error), 3 (empty application), 2 (unbound identifier), 7
//! (macro expansion depth exceeded), 4 (argument count) and 5 (type
//! mismatch) are lit — six of seven. Class 6 (module cyclic
//! dependency) stays structural DEFERRED to the 0.9 loader; this file
//! grows monotonically per §7.3.1 rule 4 (each round's audit set >=
//! the previous one) until 7/7 at the 0.11 stage gate.

use kerf::core::CoreError;
use kerf::core::reserved::cache::{
    CacheKey, CachedResult, CompilationCache, check_compilation_cache_contract,
};
use kerf::core::reserved::capability_io::{IOError, IoErrorKind, ReadCapability, WriteCapability};
use kerf::core::reserved::effects::{EffectOp, EffectSystem};
use kerf::core::reserved::multistage::{CodeCarrier, Expr, MultiStage};
use kerf::expander::{EXPANSION_LIMIT, ExpandCtx, ExpandError, expand, expand_program};
use kerf::reader::{NESTING_LIMIT, ReadError, read_program};
use kerf::span::{ByteOffset, FileId};
use kerf::syntax::{Phase, ScopeSet, SyntaxObject};

const FILE: FileId = FileId(0);

/// Assert the source fails and the error matches `pred`.
fn audit_err(src: &str, name: &str, pred: impl FnOnce(&ReadError) -> bool) {
    match read_program(FILE, src) {
        Ok(forms) => panic!(
            "audit case `{name}` must fail, but read {} forms",
            forms.len()
        ),
        Err(err) => {
            assert!(
                pred(&err),
                "audit case `{name}` failed with the wrong error: {err}"
            );
        }
    }
}

/// Assert the source reads to exactly `forms` top-level forms.
fn audit_ok(src: &str, forms: usize, name: &str) {
    let parsed = read_program(FILE, src)
        .unwrap_or_else(|err| panic!("audit case `{name}` must read, but failed: {err}"));
    assert_eq!(
        parsed.len(),
        forms,
        "audit case `{name}` must read exactly {forms} forms"
    );
}

/// `n` levels of nesting around `inner`.
fn deep(n: usize, inner: &str) -> String {
    let mut src = String::new();
    for _ in 0..n {
        src.push('(');
    }
    src.push_str(inner);
    for _ in 0..n {
        src.push(')');
    }
    src
}

/// Assert the source reads cleanly and then fails expansion, with the
/// error matching `pred` (the expander counterpart of `audit_err`).
fn expand_err(src: &str, name: &str, pred: impl FnOnce(&ExpandError) -> bool) {
    let forms = match read_program(FILE, src) {
        Ok(forms) => forms,
        Err(err) => panic!("audit case `{name}` must read cleanly, got {err}"),
    };
    match expand_program(&forms) {
        Ok(items) => panic!(
            "audit case `{name}` must fail, but expanded {} items",
            items.len()
        ),
        Err(err) => {
            assert!(
                pred(&err),
                "audit case `{name}` failed with the wrong error: {err}"
            );
        }
    }
}

fn main() {
    // ---- Section A: single-statement negative (10) ----
    // SOP §7.1.1 class 1 (syntax error) unless noted.
    audit_err(
        "(f",
        "A01 unclosed list",
        |e| matches!(e, ReadError::UnclosedList { opened_at } if opened_at.0 == 0),
    );
    audit_err(
        ")",
        "A02 stray close",
        |e| matches!(e, ReadError::UnexpectedClose { at } if at.0 == 0),
    );
    // SOP §7.1.1 class 3 (empty syntax object / empty application).
    audit_err(
        "()",
        "A03 empty application",
        |e| matches!(e, ReadError::EmptyApplication { at } if at.0 == 0),
    );
    audit_err(
        "\"abc",
        "A04 unterminated string",
        |e| matches!(e, ReadError::UnterminatedString { started_at } if started_at.0 == 0),
    );
    audit_err(
        "\"a\\x\"",
        "A05 invalid escape",
        |e| matches!(e, ReadError::InvalidEscape { escape, .. } if *escape == 'x'),
    );
    audit_err(
        "#q",
        "A06 invalid bool",
        |e| matches!(e, ReadError::InvalidBool { text } if text == "#q"),
    );
    audit_err(
        "1.2.3",
        "A07 malformed number (multi-dot)",
        |e| matches!(e, ReadError::MalformedNumber { text } if text == "1.2.3"),
    );
    audit_err(
        "12abc",
        "A08 malformed number (suffix)",
        |e| matches!(e, ReadError::MalformedNumber { text } if text == "12abc"),
    );
    audit_err("a\u{0}b", "A09 invalid symbol (control char)", |e| {
        matches!(e, ReadError::InvalidSymbol { .. })
    });
    audit_err(
        "[",
        "A10 unexpected character",
        |e| matches!(e, ReadError::UnexpectedCharacter { character, .. } if *character == '['),
    );

    // ---- Section B: multi-statement/multi-form negative (10) ----
    // The error sits inside a larger program of otherwise-valid forms;
    // every case asserts the byte-precise location of the broken form.
    audit_err(
        "(define x 1) (f",
        "B01 later form unclosed",
        |e| matches!(e, ReadError::UnclosedList { opened_at } if opened_at.0 == 13),
    );
    audit_err(
        "x 42 )",
        "B02 stray close after atoms",
        |e| matches!(e, ReadError::UnexpectedClose { at } if at.0 == 5),
    );
    audit_err(
        "(a 1) () (b 2)",
        "B03 empty app between forms",
        |e| matches!(e, ReadError::EmptyApplication { at } if at.0 == 6),
    );
    audit_err(
        "(f 1) \"s (g 2)",
        "B04 unterminated string mid-program",
        |e| matches!(e, ReadError::UnterminatedString { started_at } if started_at.0 == 6),
    );
    audit_err(
        "#t #f #q",
        "B05 bad bool in atom sequence",
        |e| matches!(e, ReadError::InvalidBool { text } if text == "#q"),
    );
    audit_err(
        "1 2 3.3.3",
        "B06 malformed number in sequence",
        |e| matches!(e, ReadError::MalformedNumber { text } if text == "3.3.3"),
    );
    audit_err(
        "(a) (b (c)",
        "B07 nested form unclosed",
        |e| matches!(e, ReadError::UnclosedList { opened_at } if opened_at.0 == 4),
    );
    audit_err(
        "(a (b 1)) ) ",
        "B08 stray close after nested form",
        |e| matches!(e, ReadError::UnexpectedClose { at } if at.0 == 10),
    );
    audit_err(
        "nil (f x) (quote ())",
        "B09 quoted empty list rejected at read",
        |e| matches!(e, ReadError::EmptyApplication { at } if at.0 == 17),
    );
    audit_err(
        "s1 s2 a\u{1}b",
        "B10 control char in third form",
        |e| matches!(e, ReadError::InvalidSymbol { text } if text == "a\u{1}b"),
    );

    // ---- Section C: complex-program negative (5) ----
    audit_err(
        &deep(NESTING_LIMIT + 1, "x"),
        "C01 nesting over the cap",
        |e| matches!(e, ReadError::NestingDepthExceeded { depth, limit } if *depth == NESTING_LIMIT + 1 && *limit == NESTING_LIMIT),
    );
    audit_err(
        &deep(200, "(f"),
        "C02 deep nesting with unclosed bottom",
        |e| matches!(e, ReadError::UnclosedList { .. }),
    );
    audit_err(
        &deep(150, "()"),
        "C03 empty application at nesting bottom",
        |e| matches!(e, ReadError::EmptyApplication { .. }),
    );
    audit_err(
        &deep(100, "1.2.3"),
        "C04 malformed number at nesting bottom",
        |e| matches!(e, ReadError::MalformedNumber { .. }),
    );
    // Wide-and-deep: 100 levels, wide fan-out at each level, one stray
    // close grafted at the end.
    let wide = {
        let level = "(f a b (g c";
        let mut src = String::new();
        for _ in 0..10 {
            src.push_str(level);
        }
        src.push(')');
        src
    };
    audit_err(&wide, "C05 wide nesting with unbalanced tail", |e| {
        matches!(e, ReadError::UnclosedList { .. })
    });

    // ---- Section D: error-recovery (5, Stage 0 semantics) ----
    // One error must not poison anything after it: independent calls
    // stay isolated and the corrected source reads cleanly.
    {
        // D01: unclosed -> close it.
        assert!(read_program(FILE, "(f").is_err());
        audit_ok("(f 1)", 1, "D01 corrected list reads");
    }
    {
        // D02: mid-program error -> truncate to the valid prefix.
        assert!(read_program(FILE, "(a 1) (b").is_err());
        audit_ok("(a 1)", 1, "D02 valid prefix reads after failure");
    }
    {
        // D03: empty application -> give it an operator.
        assert!(read_program(FILE, "()").is_err());
        audit_ok("(f 1)", 1, "D03 operator-given form reads");
    }
    {
        // D04: over-cap nesting -> shrink one level (cap boundary both
        // ways in one recovery pair).
        assert!(read_program(FILE, &deep(NESTING_LIMIT + 1, "x")).is_err());
        audit_ok(&deep(NESTING_LIMIT, "x"), 1, "D04 cap-edge nesting reads");
    }
    {
        // D05: invalid escape -> valid escape, same call sequence.
        assert!(read_program(FILE, "\"a\\x\"").is_err());
        audit_ok("\"a\\n\"", 1, "D05 escaped newline string reads");
    }

    // ---- Section E: expander negatives (10, sub-stage 0.4) ----
    // The reader -> expander full path plus synthesized-tree faces;
    // every case is a structured ExpandError, never a panic.
    // E01: unbound identifier, single form (class 2).
    expand_err(
        "(define (f) nope)",
        "E01 unbound identifier in single form",
        |e| matches!(e, ExpandError::UnboundIdentifier { .. }),
    );
    // E02: unbound identifier in a later form of a multi-form program.
    expand_err(
        "(define a 1) (define (g) missing)",
        "E02 unbound identifier in later form",
        |e| matches!(e, ExpandError::UnboundIdentifier { name, .. } if name == "missing"),
    );
    // E03: expansion work budget exceeded on a synthesized deep tree
    // (class 7 — the reader cap cannot produce this; the expander
    // budget bounds synthesized/macro-produced trees independently).
    {
        let span =
            kerf::span::Span::root(FILE, ByteOffset(0), ByteOffset(1)).expect("audit fixture span");
        // A global head and a literal innermost atom: the budget is
        // the only possible failure.
        let mut node = SyntaxObject::int(span, ScopeSet::new(), Phase::Runtime, 42);
        for _ in 0..EXPANSION_LIMIT {
            let head = SyntaxObject::symbol(span, ScopeSet::new(), Phase::Runtime, "+")
                .expect("audit fixture symbol");
            node = SyntaxObject::list(span, ScopeSet::new(), Phase::Runtime, vec![head, node]);
        }
        let mut ctx = ExpandCtx::new();
        match expand(&mut ctx, &node) {
            Ok(_) => panic!("audit case `E03` must fail, but the deep tree expanded"),
            Err(err) => assert!(
                matches!(err, ExpandError::ExpansionDepthExceeded { .. }),
                "audit case `E03` failed with the wrong error: {err}"
            ),
        }
    }
    // E04: phase closure — macro-phase syntax is not runtime code.
    {
        let span =
            kerf::span::Span::root(FILE, ByteOffset(0), ByteOffset(1)).expect("audit fixture span");
        let form = SyntaxObject::symbol(span, ScopeSet::new(), Phase::MacroExpansion, "x")
            .expect("audit fixture symbol");
        let mut ctx = ExpandCtx::new();
        match expand(&mut ctx, &form) {
            Ok(_) => panic!("audit case `E04` must fail, but macro-phase expanded"),
            Err(err) => assert!(
                matches!(err, ExpandError::PhaseViolation { .. }),
                "audit case `E04` failed with the wrong error: {err}"
            ),
        }
    }
    // E05: malformed special form (two-armed if).
    expand_err(
        "(define (f) (if 1 2))",
        "E05 two-armed if is malformed",
        |e| matches!(e, ExpandError::MalformedForm { form, .. } if *form == "if"),
    );
    // E06: bare top-level expression (declarations only at module top).
    expand_err("(f 1)", "E06 bare top-level expression", |e| {
        matches!(e, ExpandError::TopLevelExpression { .. })
    });
    // E07: set! to an unbound target (class 2, assignment face).
    expand_err(
        "(define (f) (set! nope 1))",
        "E07 set! to unbound target",
        |e| matches!(e, ExpandError::UnboundIdentifier { name, .. } if name == "nope"),
    );
    // E08: duplicate parameters re-asserted through the expander.
    expand_err(
        "(define (f x x) x)",
        "E08 duplicate params via expander",
        |e| {
            matches!(e, ExpandError::Core { source, .. }
            if *source == CoreError::DuplicateParam { name: "x".to_owned() })
        },
    );
    // E09: empty synthesized form (class 3, expander detection point —
    // the reader already rejects `()` in source; this is the second
    // fail-closed layer for hand-built trees).
    {
        let span =
            kerf::span::Span::root(FILE, ByteOffset(0), ByteOffset(2)).expect("audit fixture span");
        let form = SyntaxObject::list(span, ScopeSet::new(), Phase::Runtime, vec![]);
        let mut ctx = ExpandCtx::new();
        match expand(&mut ctx, &form) {
            Ok(_) => panic!("audit case `E09` must fail, but the empty form expanded"),
            Err(err) => assert!(
                matches!(err, ExpandError::EmptyForm { .. }),
                "audit case `E09` failed with the wrong error: {err}"
            ),
        }
    }
    // E10: malformed handle clause (one-element pair).
    expand_err(
        "(define (f) (handle 1 (E)))",
        "E10 malformed handle clause",
        |e| matches!(e, ExpandError::MalformedForm { form, .. } if *form == "handle"),
    );

    // ---- Section F: compiler negatives (10, sub-stage 0.5) ----
    // The expander -> compiler full path plus hand-built bad
    // products; every case is a structured CompileError from the
    // compile-time defenses or from Bytecode::verify, never a panic.
    use kerf::compiler::{
        Bytecode as FBytecode, CompileError, FuncProto, Instr as FInstr, Opcode,
        compile as fcompile, compile_program as fcompile_program,
    };
    use kerf::core::{CoreExpr as FExpr, LiteralValue as FLit};

    fn fspan(start: u32, end: u32) -> kerf::span::Span {
        kerf::span::Span::root(FILE, ByteOffset(start), ByteOffset(end))
            .expect("audit fixture span")
    }

    /// Hand-built entry proto with one pooled constant (index 0).
    fn fentry(code: Vec<FInstr>, debug_len: usize) -> FBytecode {
        let mut f = FuncProto::new(None, 0, 0);
        f.code = code;
        f.debug_info = vec![fspan(0, 1); debug_len];
        let mut bc = FBytecode::default();
        bc.consts.push(FLit::Int(0));
        bc.funcs.push(f);
        bc
    }

    // F01: compile depth cap on a synthesized 1025-deep chain.
    {
        let mut e = FExpr::Literal {
            span: fspan(0, 1),
            value: FLit::Int(0),
        };
        for _ in 0..1024 {
            e = FExpr::Apply {
                span: fspan(0, 1),
                func: Box::new(FExpr::var(fspan(0, 1), "+").unwrap()),
                args: vec![e],
            };
        }
        match fcompile(&e) {
            Ok(_) => panic!("audit case `F01` must fail, but the deep tree compiled"),
            Err(err) => assert!(
                matches!(err, CompileError::DepthExceeded { depth: 1025, .. }),
                "audit case `F01` failed with the wrong error: {err}"
            ),
        }
    }
    // F02: verify rejects a jump target beyond the code length.
    {
        let bc = fentry(
            vec![
                FInstr::new(Opcode::PushConst),
                FInstr::with_a(Opcode::Jump, 9),
                FInstr::new(Opcode::Halt),
            ],
            3,
        );
        let err = bc.verify().expect_err("audit case `F02` must fail");
        assert!(
            matches!(
                err,
                CompileError::JumpTargetOutOfRange {
                    pc: 1,
                    target: 9,
                    ..
                }
            ),
            "audit case `F02` failed with the wrong error: {err}"
        );
    }
    // F03: verify rejects a pop on the empty stack.
    {
        let bc = fentry(vec![FInstr::new(Opcode::Pop), FInstr::new(Opcode::Halt)], 2);
        let err = bc.verify().expect_err("audit case `F03` must fail");
        assert!(
            matches!(err, CompileError::StackUnderflow { pc: 0, .. }),
            "audit case `F03` failed with the wrong error: {err}"
        );
    }
    // F04: verify rejects a branch-depth imbalance.
    {
        let bc = fentry(
            vec![
                FInstr::new(Opcode::PushConst),
                FInstr::new(Opcode::PushConst),
                FInstr::with_a(Opcode::JumpIfFalse, 4),
                FInstr::new(Opcode::PushConst),
                FInstr::new(Opcode::Halt),
            ],
            5,
        );
        let err = bc.verify().expect_err("audit case `F04` must fail");
        assert!(
            matches!(
                err,
                CompileError::StackImbalance {
                    pc: 4,
                    expected: 1,
                    actual: 2,
                    ..
                }
            ),
            "audit case `F04` failed with the wrong error: {err}"
        );
    }
    // F05: verify rejects a bare instruction (debug_info missing).
    {
        let bc = fentry(vec![FInstr::new(Opcode::Halt)], 0);
        let err = bc.verify().expect_err("audit case `F05` must fail");
        assert!(
            matches!(err, CompileError::DebugInfoMissing { func: 0, pc: 0 }),
            "audit case `F05` failed with the wrong error: {err}"
        );
    }
    // F06: verify rejects an out-of-range constant index.
    {
        let bc = fentry(
            vec![
                FInstr::with_a(Opcode::PushConst, 7),
                FInstr::new(Opcode::Halt),
            ],
            2,
        );
        let err = bc.verify().expect_err("audit case `F06` must fail");
        assert!(
            matches!(
                err,
                CompileError::ConstIndexOutOfRange {
                    pc: 0,
                    index: 7,
                    ..
                }
            ),
            "audit case `F06` failed with the wrong error: {err}"
        );
    }
    // F07: verify rejects halt inside a non-entry proto.
    {
        let mut bc = fentry(vec![FInstr::new(Opcode::Halt)], 1);
        let mut closure = FuncProto::new(None, 0, 0);
        closure.code = vec![FInstr::new(Opcode::Halt)];
        closure.debug_info = vec![fspan(0, 1)];
        bc.funcs.push(closure);
        let err = bc.verify().expect_err("audit case `F07` must fail");
        assert!(
            matches!(err, CompileError::HaltOutsideEntry { pc: 0, .. }),
            "audit case `F07` failed with the wrong error: {err}"
        );
    }
    // F08: verify rejects a proto that does not end in ret/halt.
    {
        let bc = fentry(
            vec![FInstr::new(Opcode::PushConst), FInstr::new(Opcode::Pop)],
            2,
        );
        let err = bc.verify().expect_err("audit case `F08` must fail");
        assert!(
            matches!(err, CompileError::MissingTerminator { func: 0, pc: 1 }),
            "audit case `F08` failed with the wrong error: {err}"
        );
    }
    // F09: verify rejects an out-of-range closure proto index.
    {
        let bc = fentry(
            vec![
                FInstr::with_a(Opcode::Closure, 5),
                FInstr::new(Opcode::Halt),
            ],
            2,
        );
        let err = bc.verify().expect_err("audit case `F09` must fail");
        assert!(
            matches!(
                err,
                CompileError::ProtoIndexOutOfRange {
                    pc: 0,
                    index: 5,
                    ..
                }
            ),
            "audit case `F09` failed with the wrong error: {err}"
        );
    }
    // F10: verify rejects an out-of-range local slot.
    {
        let bc = fentry(
            vec![
                FInstr::with_a(Opcode::LoadLocal, 3),
                FInstr::new(Opcode::Halt),
            ],
            2,
        );
        let err = bc.verify().expect_err("audit case `F10` must fail");
        assert!(
            matches!(
                err,
                CompileError::LocalSlotOutOfRange { pc: 0, slot: 3, .. }
            ),
            "audit case `F10` failed with the wrong error: {err}"
        );
    }
    // Cross-check: a full source program compiles and verifies (the
    // compile-output-passes-verify contract) — not counted in F, a
    // guard against vacuous rejection tests.
    {
        let src = "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2)))))";
        let forms = read_program(FILE, src).expect("audit guard must read");
        let items = expand_program(&forms).expect("audit guard must expand");
        let bc = fcompile_program(&items).expect("audit guard must compile");
        bc.verify()
            .expect("audit guard: compile output must verify");
    }

    // ---- Section G: VM negative (10, sub-stage 0.6) ----
    // SOP §7.1.1 classes 4 (argument count) and 5 (type mismatch)
    // light up here; the remaining cases pin the fail-closed runtime
    // paths. Source-level wherever the pipeline can reach them.
    {
        use kerf::compiler::compile_program as gcompile_program;
        use kerf::vm::{RuntimeError as VmErr, Vm};

        fn vrun(src: &str) -> Result<kerf::vm::Value, VmErr> {
            let forms = read_program(FILE, src).expect("audit source must read");
            let items = expand_program(&forms).expect("audit source must expand");
            let bc = gcompile_program(&items).expect("audit source must compile");
            let mut vm = Vm::new(bc).expect("audit source must verify at load");
            vm.run()
        }

        // G01: closure arity — proto params vs call count (class 4).
        match vrun("(define (f x) x) (define r (f 1 2))") {
            Err(VmErr::ArityMismatch {
                func,
                expected,
                actual,
                ..
            }) if func == "f" && (expected, actual) == (1, 2) => {}
            other => panic!("audit case `G01` unexpected: {other:?}"),
        }
        // G02: builtin arity — fixed-arity registry row (class 4).
        match vrun("(define r (+ 1 2 3))") {
            Err(VmErr::ArityMismatch {
                func,
                expected,
                actual,
                ..
            }) if func == "+" && (expected, actual) == (2, 3) => {}
            other => panic!("audit case `G02` unexpected: {other:?}"),
        }
        // G03: truthy demands bool (class 5).
        match vrun("(define r (if 1 2 3))") {
            Err(VmErr::TypeMismatch { got, context, .. })
                if got == "int" && context == "jump-if-false condition" => {}
            other => panic!("audit case `G03` unexpected: {other:?}"),
        }
        // G04: arithmetic demands same-kind numbers (class 5).
        match vrun("(define r (+ 1 #t))") {
            Err(VmErr::TypeMismatch { got, context, .. })
                if got == "bool" && context == "add operand" => {}
            other => panic!("audit case `G04` unexpected: {other:?}"),
        }
        // G05: car demands a pair (class 5).
        match vrun("(define r (car 5))") {
            Err(VmErr::TypeMismatch { got, context, .. })
                if got == "int" && context == "car operand" => {}
            other => panic!("audit case `G05` unexpected: {other:?}"),
        }
        // G06: calls demand a callable callee (class 5).
        match vrun("(define f 5) (define r (f 1))") {
            Err(VmErr::TypeMismatch { got, context, .. })
                if got == "int" && context == "call callee" => {}
            other => panic!("audit case `G06` unexpected: {other:?}"),
        }
        // G07: perform without a matching handler.
        match vrun("(define r (perform log 1))") {
            Err(VmErr::UnhandledEffect { effect, .. }) if effect.as_str() == "log" => {}
            other => panic!("audit case `G07` unexpected: {other:?}"),
        }
        // G08: integer division by zero fails closed.
        match vrun("(define r (/ 1 0))") {
            Err(VmErr::DivByZero { .. }) => {}
            other => panic!("audit case `G08` unexpected: {other:?}"),
        }
        // G09: i64 overflow fails closed (no wrapping).
        match vrun("(define r (+ 9223372036854775807 1))") {
            Err(VmErr::ArithmeticOverflow { .. }) => {}
            other => panic!("audit case `G09` unexpected: {other:?}"),
        }
        // G10: the §19.4 allocation budget bounds recursion.
        {
            let src = "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define r (fib 10))";
            let forms = read_program(FILE, src).expect("audit source must read");
            let items = expand_program(&forms).expect("audit source must expand");
            let bc = gcompile_program(&items).expect("audit source must compile");
            let mut vm = Vm::with_budget(bc, 8).expect("audit source must verify at load");
            match vm.run() {
                Err(VmErr::BudgetExceeded { budget: 8, .. }) => {}
                other => panic!("audit case `G10` unexpected: {other:?}"),
            }
        }
    }

    // ---- Section H: runtime negative (10, sub-stage 0.7) ----
    // The dual-path faces: evaluator negatives (the same source the
    // VM rejects must fail identically through eval — the parity
    // contract at the error layer), the GC retention guards (§19.4
    // root completeness), and the parity-detector self-check.
    {
        use kerf::compiler::compile_program as hcompile_program;
        use kerf::runtime::{Evaluator, MarkSweep, parity_repr};
        use kerf::vm::{RuntimeError as VmErr, Vm};

        fn erun(src: &str) -> Result<kerf::vm::Value, VmErr> {
            let forms = read_program(FILE, src).expect("audit source must read");
            let items = expand_program(&forms).expect("audit source must expand");
            let mut ev = Evaluator::new();
            ev.eval_program(&items)
        }

        // H01: evaluator arity — closure face (class 4 on the eval path).
        match erun("(define (f x) x) (define r (f 1 2))") {
            Err(VmErr::ArityMismatch {
                func,
                expected,
                actual,
                ..
            }) if func == "f" && (expected, actual) == (1, 2) => {}
            other => panic!("audit case `H01` unexpected: {other:?}"),
        }
        // H02: evaluator arity — builtin face.
        match erun("(define r (+ 1 2 3))") {
            Err(VmErr::ArityMismatch {
                func,
                expected,
                actual,
                ..
            }) if func == "+" && (expected, actual) == (2, 3) => {}
            other => panic!("audit case `H02` unexpected: {other:?}"),
        }
        // H03: evaluator type — truthy condition (class 5).
        match erun("(define r (if 1 2 3))") {
            Err(VmErr::TypeMismatch { got, context, .. })
                if got == "int" && context == "jump-if-false condition" => {}
            other => panic!("audit case `H03` unexpected: {other:?}"),
        }
        // H04: evaluator type — mixed-kind arithmetic.
        match erun("(define r (+ 1 #t))") {
            Err(VmErr::TypeMismatch { got, context, .. })
                if got == "bool" && context == "add operand" => {}
            other => panic!("audit case `H04` unexpected: {other:?}"),
        }
        // H05: evaluator type — car of a non-pair.
        match erun("(define r (car 5))") {
            Err(VmErr::TypeMismatch { got, context, .. })
                if got == "int" && context == "car operand" => {}
            other => panic!("audit case `H05` unexpected: {other:?}"),
        }
        // H06: evaluator div-zero + unhandled effect (fail-closed pair).
        match erun("(define r (/ 1 0))") {
            Err(VmErr::DivByZero { .. }) => {}
            other => panic!("audit case `H06` unexpected: {other:?}"),
        }
        match erun("(define r (perform log 1))") {
            Err(VmErr::UnhandledEffect { effect, .. }) if effect.as_str() == "log" => {}
            other => panic!("audit case `H07` unexpected: {other:?}"),
        }
        // H08: the evaluator depth cap (Rust-stack guard, eval-only).
        match erun("(define (cd n) (if (= n 0) 0 (cd (- n 1)))) (define r (cd 3000))") {
            Err(VmErr::EvalDepthExceeded { limit: 2048, .. }) => {}
            other => panic!("audit case `H08` unexpected: {other:?}"),
        }
        // H09: GC retention — root completeness on the VM injection
        // face: a tight-budget discarding program survives ONLY
        // because the cycle reclaims the dead cells and keeps every
        // rooted one (a false reclaim would corrupt the result).
        {
            let src = "(define r (+ (car (cons 1 2)) (+ (car (cons 3 4)) (+ (car (cons 5 6)) (car (cons 7 8))))))";
            let forms = read_program(FILE, src).expect("audit source must read");
            let items = expand_program(&forms).expect("audit source must expand");
            let bc = hcompile_program(&items).expect("audit source must compile");
            let mut vm = Vm::with_budget_and_collector(bc, 4, Box::new(MarkSweep)).expect("loads");
            vm.run().expect("audit case `H09` collect-then-retry runs");
            assert_eq!(
                vm.global("r"),
                Some(&kerf::vm::Value::Int(16)),
                "audit case `H09` retention is exact"
            );
        }
        // H10: parity detector self-check — structurally different
        // results must render different reprs (a detector that
        // cannot fail proves nothing).
        {
            let run = |src: &str| -> String {
                let forms = read_program(FILE, src).expect("audit source must read");
                let items = expand_program(&forms).expect("audit source must expand");
                let mut ev = Evaluator::new();
                let v = ev.eval_program(&items).expect("audit eval runs");
                match ev.global("r") {
                    Some(r) => parity_repr(r, ev.heap()),
                    None => parity_repr(&v, ev.heap()),
                }
            };
            let a = run("(define r (cons 1 2))");
            let b = run("(define r (cons 2 1))");
            assert_ne!(a, b, "audit case `H10` detector must see the difference");
            assert_eq!(a, "(1 . 2)");
        }
    }

    // ---- Section I: driver end-to-end negative + orchestration (10,
    // sub-stage 0.8 — monotonic growth per §7.3.1 rule 4) ----
    {
        use kerf::driver::{
            DiagnosticCode, Engine, Repl, ReplEvent, Session, render_diagnostics, run_source,
        };

        let drun = |src: &str| run_source(&mut Session::new(), "i.krf", src, Engine::Vm, &[]);
        let drun_err = |src: &str| {
            let mut session = Session::new();
            match run_source(&mut session, "i.krf", src, Engine::Vm, &[]) {
                Ok(_) => panic!("audit source must fail: {src}"),
                Err(diags) => (session, diags),
            }
        };

        // I01: syntax error renders with line:column + excerpt (the
        // TD-001 payoff through the driver).
        {
            let (session, diags) = drun_err("(+ 1 2");
            assert_eq!(diags[0].code, DiagnosticCode::Read);
            let rendered = render_diagnostics(&session, &diags);
            assert!(rendered.contains("--> i.krf:1:1"), "I01: {rendered}");
            assert!(rendered.contains("unclosed delimiter"));
        }
        // I02: empty application — the reader-class second case.
        {
            let (_, diags) = drun_err("()");
            assert_eq!(diags[0].code, DiagnosticCode::Read);
            assert!(diags[0].message.contains("empty application"), "I02");
        }
        // I03: unbound identifier (expander class).
        {
            let (_, diags) = drun_err("(define r (no-such-fn))");
            assert_eq!(diags[0].code, DiagnosticCode::Expand, "I03");
        }
        // I04: arity mismatch (runtime class). Stage 1.1 co-change:
        // a known-callee arity mismatch now surfaces statically as
        // E0002 (section N01); the runtime face stays audited through
        // a checker-opaque param-mediated call (the R2 assign/lexical
        // guards deliberately skip it).
        {
            let (_, diags) = drun_err("(define r ((fn (g) (g 1 2)) car))");
            assert_eq!(diags[0].code, DiagnosticCode::Runtime, "I04");
            assert!(diags[0].message.contains("arity mismatch"), "I04");
        }
        // I05: type mismatch (runtime class).
        {
            let (_, diags) = drun_err("(define r (+ 1 #t))");
            assert_eq!(diags[0].code, DiagnosticCode::Runtime, "I05");
            assert!(diags[0].message.contains("type mismatch"), "I05");
        }
        // I06: multi-file multi-diagnostic — §12.2 errors-are-data:
        // both broken files report in one render pass.
        {
            let mut session = Session::new();
            let mut all = Vec::new();
            for (name, src) in [("i-a.krf", "(+ 1"), ("i-b.krf", "(define r (nope))")] {
                if let Err(diags) = run_source(&mut session, name, src, Engine::Vm, &[]) {
                    all.extend(diags);
                }
            }
            assert_eq!(all.len(), 2, "I06 both files report");
            let rendered = render_diagnostics(&session, &all);
            assert!(
                rendered.contains("aborting due to 2 previous errors"),
                "I06"
            );
        }
        // I07: REPL error-then-recovery — a failed submission rolls
        // back and the session stays usable.
        {
            let mut repl = Repl::new();
            match repl.submit("(define x 1)") {
                ReplEvent::Evaluated { .. } => {}
                other => panic!("I07 define: {other:?}"),
            }
            match repl.submit("(broken-call)") {
                ReplEvent::Error { rendered } => {
                    assert!(rendered.contains("kerf-expand"), "I07 error face")
                }
                other => panic!("I07 must error: {other:?}"),
            }
            match repl.submit("(+ x 1)") {
                ReplEvent::Evaluated { value, .. } => {
                    assert_eq!(value.as_deref(), Some("2"), "I07 session survives")
                }
                other => panic!("I07 recovery: {other:?}"),
            }
        }
        // I08: check face — compile + verify without execution (a
        // program with an output effect produces no output).
        {
            let mut session = Session::new();
            let check = kerf::driver::check_source(
                &mut session,
                "i.krf",
                "(define r (write-line (quote-not-needed 1)))",
            );
            // The body references an unbound function — check must
            // fail at expansion, NOT execute anything.
            assert!(check.is_err(), "I08 check rejects unbound callee");
        }
        // I09: parity mode — the dual-engine report agrees on fib and
        // a divergence is data, not a panic (detector self-check).
        {
            let mut session = Session::new();
            let fib_src = "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define r (fib 8))";
            let report = kerf::driver::run_parity_source(&mut session, "i.krf", fib_src, &[])
                .expect("I09 parity run");
            assert!(report.agrees(), "I09 fib agrees: {report:?}");
            let divergent = kerf::driver::ParityReport {
                vm_repr: "1".to_owned(),
                eval_repr: "2".to_owned(),
                values_agree: false,
                outputs_agree: true,
                globals_agree: true,
                // Stage 1.1 field: a hand-built detector self-check
                // carries no warnings.
                warnings: Vec::new(),
            };
            assert!(!divergent.agrees(), "I09 divergence is data");
        }
        // I10: rendering edges — CJK character columns (registered
        // fixture) and position-less diagnostics (no fabricated `-->`).
        {
            let (session, diags) = drun_err("(define \u{540d} (+ 1 2)))");
            let rendered = render_diagnostics(&session, &diags);
            assert!(
                rendered.contains("--> i.krf:1:19"),
                "I10 char columns: {rendered}"
            );
            assert!(!rendered.contains("1:21"), "I10 byte columns would say 21");
            let mut session2 = Session::new();
            let diags2 = run_source(&mut session2, "i.krf", "#q", Engine::Vm, &[])
                .expect_err("I10 invalid bool is positionless");
            assert!(diags2[0].primary_span.is_none(), "I10 no fabricated span");
            let rendered2 = render_diagnostics(&session2, &diags2);
            assert!(
                !rendered2.contains("-->"),
                "I10 no location line: {rendered2}"
            );
        }

        let _ = drun; // silence the unused helper when sections change
    }

    // ---- Section J: macro / module / quote negative (10, sub-stage
    // 0.9 — monotonic growth per §7.3.1 rule 4) ----
    {
        use kerf::driver::{DiagnosticCode, Session, parse, render_diagnostics};

        let jerr = |src: &str| {
            let mut session = Session::new();
            match parse(&mut session, "j.krf", src) {
                Ok(_) => panic!("audit source must fail: {src}"),
                Err(diags) => (session, diags),
            }
        };

        // J01: pattern mismatch — no clause fits the use form (the
        // macro-phase family; the use-site location).
        {
            let (session, diags) = jerr(
                "(define-syntax my-if (syntax-rules nil ((_ c t e) (if c t e))))\n(define r (my-if #t 1))",
            );
            assert_eq!(diags[0].code, DiagnosticCode::Expand, "J01");
            let rendered = render_diagnostics(&session, &diags);
            assert!(
                rendered.contains("macro `my-if` matched no clause"),
                "J01: {rendered}"
            );
            assert!(rendered.contains("--> j.krf:2:12"), "J01: {rendered}");
        }
        // J02: quote boundary — symbol data has no Stage 0 value
        // model (fail closed, not silently stringified).
        {
            let (session, diags) = jerr("(define r (quote ghost))");
            assert_eq!(diags[0].code, DiagnosticCode::Expand, "J02");
            let rendered = render_diagnostics(&session, &diags);
            assert!(
                rendered.contains("quote cannot carry this datum"),
                "J02: {rendered}"
            );
        }
        // J03: hygiene defense — a use-site binding must not capture a
        // free introduced reference (the Racket judgment: the
        // introduced `tmp` stays unbound, reported fail-closed).
        {
            let (session, diags) = jerr(
                "(define-syntax m (syntax-rules nil ((_) tmp)))\n(define r (let ((tmp 1)) (m)))",
            );
            assert_eq!(diags[0].code, DiagnosticCode::Expand, "J03");
            let rendered = render_diagnostics(&session, &diags);
            assert!(
                rendered.contains("unbound identifier `tmp`"),
                "J03: {rendered}"
            );
        }
        // J04: hygiene defense — a macro head naming nothing (use
        // before its definition) fails through the unified unbound
        // judgment.
        {
            let (_, diags) = jerr(
                "(define r (my-if #t 1 2))\n(define-syntax my-if (syntax-rules nil ((_ c t e) (if c t e))))",
            );
            assert_eq!(diags[0].code, DiagnosticCode::Expand, "J04");
            assert!(
                diags[0].message.contains("unbound identifier `my-if`"),
                "J04: {}",
                diags[0].message
            );
        }
        // J05: macro expansion depth — a self-recursive macro hits the
        // structured budget (class 5 maintained at the macro face).
        {
            let (_, diags) =
                jerr("(define-syntax loopy (syntax-rules nil ((_) (loopy))))\n(define r (loopy))");
            assert_eq!(diags[0].code, DiagnosticCode::Expand, "J05");
            assert!(
                diags[0].message.contains("expansion depth exceeded"),
                "J05: {}",
                diags[0].message
            );
        }
        // J06: module cycle, two modules — the §7.1.1 class 7 face,
        // end-to-end with the cycle path.
        {
            let (session, diags) = jerr("(module a (require \"b\"))\n(module b (require \"a\"))");
            assert_eq!(diags[0].code, DiagnosticCode::Expand, "J06");
            let rendered = render_diagnostics(&session, &diags);
            assert!(
                rendered.contains("module cycle detected: a -> b -> a"),
                "J06: {rendered}"
            );
        }
        // J07: module cycle, three modules (the longer path closes the
        // same way).
        {
            let (_, diags) = jerr(
                "(module a (require \"b\"))\n(module b (require \"c\"))\n(module c (require \"a\"))",
            );
            assert_eq!(diags[0].code, DiagnosticCode::Expand, "J07");
            assert!(
                diags[0].message.contains("a -> b -> c -> a"),
                "J07: {}",
                diags[0].message
            );
        }
        // J08: module not found — requiring an undeclared module.
        {
            let (_, diags) = jerr("(require \"ghost\")");
            assert_eq!(diags[0].code, DiagnosticCode::Expand, "J08");
            assert!(
                diags[0]
                    .message
                    .contains("required module `ghost` is not declared"),
                "J08: {}",
                diags[0].message
            );
        }
        // J09: duplicate module declarations — the flat namespace is
        // unique.
        {
            let (_, diags) = jerr("(module a (define x 1))\n(module a (define y 2))");
            assert_eq!(diags[0].code, DiagnosticCode::Expand, "J09");
            assert!(
                diags[0]
                    .message
                    .contains("duplicate module declaration `a`"),
                "J09: {}",
                diags[0].message
            );
        }
        // J10: define-syntax registration family — the ellipsis
        // boundary (Stage 0 has no `...` patterns) and the reserved
        // name rejection, both fail-closed at registration.
        {
            let (_, diags) = jerr("(define-syntax m (syntax-rules nil ((_ x ...) (f x))))");
            assert_eq!(diags[0].code, DiagnosticCode::Expand, "J10");
            assert!(
                diags[0].message.contains("malformed `define-syntax`"),
                "J10 ellipsis: {}",
                diags[0].message
            );
            let (_, diags2) = jerr("(define-syntax if (syntax-rules nil ((_ c t e) (if c t e))))");
            assert!(
                diags2[0].message.contains("malformed `define-syntax`"),
                "J10 reserved: {}",
                diags2[0].message
            );
        }
    }

    // ---- Section K: reserved-face contracts (10, sub-stage 0.10 —
    // the frozen reservation face of docs/stage0.md §9.1.1-§9.1.4:
    // witness semantics for effects and multistage, the sealed token
    // discipline, the externally reachable I/O error face, and the
    // executable cache behavior contract; monotonic growth per
    // §7.3.1 rule 4) ----
    {
        use std::cell::Cell;
        use std::collections::HashMap;

        // K01: the effect witness performs and routes through
        // `EffectOp::Result`.
        {
            struct CountingEffects {
                ops: Cell<u32>,
            }
            enum CountEffect {
                Tick,
            }
            impl EffectOp for CountEffect {
                type Result = u32;
            }
            impl EffectSystem for CountingEffects {
                type Effect = CountEffect;
                type Handler = u32;
                type Continuation = ();
                type Value = u32;

                fn perform(&self, effect: CountEffect) -> u32 {
                    match effect {
                        CountEffect::Tick => self.ops.get() + 1,
                    }
                }

                fn handle(&self, handler: u32, computation: impl FnOnce() -> u32) -> u32 {
                    computation() + handler
                }
            }
            let system = CountingEffects { ops: Cell::new(0) };
            assert_eq!(system.perform(CountEffect::Tick), 1, "K01");
        }

        // K02: the effect witness composes the value path through
        // `handle`.
        {
            // Reuses the K01 witness shape; asserted inline for the
            // audit's self-containment.
            struct Passthrough;
            enum NeverEffect {}
            impl EffectOp for NeverEffect {
                type Result = ();
            }
            impl EffectSystem for Passthrough {
                type Effect = NeverEffect;
                type Handler = i32;
                type Continuation = ();
                type Value = i32;

                fn perform(&self, effect: NeverEffect) -> () {
                    match effect {}
                }

                fn handle(&self, handler: i32, computation: impl FnOnce() -> i32) -> i32 {
                    computation() + handler
                }
            }
            let system = Passthrough;
            assert_eq!(system.handle(7, || 35), 42, "K02");
        }

        // K03: the multistage witness quote→splice round-trip.
        {
            struct AuditExpr;
            impl Expr for AuditExpr {}
            struct AuditCode(i64);
            impl CodeCarrier for AuditCode {
                type Inner = i64;
                type Result = i64;
            }
            struct AuditStaging;
            impl MultiStage for AuditStaging {
                type Code = AuditCode;

                fn quote<E: Expr>(_expr: E) -> AuditCode {
                    AuditCode(21)
                }

                fn splice(code: AuditCode) -> i64 {
                    code.0
                }

                fn run(code: AuditCode) -> i64 {
                    code.0 * 2
                }
            }
            let code = AuditStaging::quote(AuditExpr);
            assert_eq!(AuditStaging::splice(code), 21, "K03");
        }

        // K04: the multistage witness runs to the carrier result.
        {
            // Same carrier family as K03; `run` executes.
            struct RunExpr;
            impl Expr for RunExpr {}
            struct RunCode(i64);
            impl CodeCarrier for RunCode {
                type Inner = i64;
                type Result = i64;
            }
            struct RunStaging;
            impl MultiStage for RunStaging {
                type Code = RunCode;

                fn quote<E: Expr>(_expr: E) -> RunCode {
                    RunCode(21)
                }

                fn splice(code: RunCode) -> i64 {
                    code.0
                }

                fn run(code: RunCode) -> i64 {
                    code.0 * 2
                }
            }
            let code = RunStaging::quote(RunExpr);
            assert_eq!(RunStaging::run(code), 42, "K04");
        }

        // K05: the capability tokens are zero-sized with stable
        // Debug forms (the sealed-token discipline visible from
        // outside the defining crate).
        {
            assert_eq!(std::mem::size_of::<ReadCapability>(), 0, "K05 read");
            assert_eq!(std::mem::size_of::<WriteCapability>(), 0, "K05 write");
        }

        // K06: the externally reachable I/O error face — kinds,
        // accessors, and the R8 message shape (lowercase start, no
        // trailing period) across the full closed kind set.
        {
            for kind in [
                IoErrorKind::Eof,
                IoErrorKind::Denied,
                IoErrorKind::Interrupted,
                IoErrorKind::Other,
            ] {
                let err = IOError::new(kind, "audit probe");
                assert_eq!(err.kind(), kind, "K06 kind");
                assert_eq!(err.message(), "audit probe", "K06 message");
                let text = err.to_string();
                let first = text.chars().next().expect("K06 non-empty");
                assert!(first.is_lowercase(), "K06 lowercase: `{text}`");
                assert!(!text.ends_with('.'), "K06 period: `{text}`");
            }
        }

        // The audit-local cache witness (K07-K10).
        struct AuditCache {
            map: HashMap<CacheKey, CachedResult>,
        }
        impl CompilationCache for AuditCache {
            fn get_cached(&self, key: CacheKey) -> Option<CachedResult> {
                self.map.get(&key).cloned()
            }

            fn store(&mut self, key: CacheKey, result: CachedResult) {
                self.map.insert(key, result);
            }

            fn invalidate(&mut self, key: CacheKey) {
                self.map.remove(&key);
            }
        }
        fn audit_key(tag: u8) -> CacheKey {
            let mut digest = [0u8; 32];
            digest[0] = tag;
            CacheKey::from_digest(digest)
        }

        // K07: a never-stored key misses (negative).
        {
            let cache = AuditCache {
                map: HashMap::new(),
            };
            assert!(cache.get_cached(audit_key(7)).is_none(), "K07");
        }

        // K08: store-then-get hits with value equality (positive).
        {
            let mut cache = AuditCache {
                map: HashMap::new(),
            };
            cache.store(audit_key(8), CachedResult::new(vec![8, 8]));
            assert_eq!(
                cache.get_cached(audit_key(8)),
                Some(CachedResult::new(vec![8, 8])),
                "K08"
            );
        }

        // K09: invalidate removes, and invalidating a missing key is a
        // no-op (negatives).
        {
            let mut cache = AuditCache {
                map: HashMap::new(),
            };
            cache.store(audit_key(9), CachedResult::new(vec![9]));
            cache.invalidate(audit_key(9));
            assert!(cache.get_cached(audit_key(9)).is_none(), "K09 removed");
            cache.invalidate(audit_key(9));
            cache.invalidate(audit_key(0x99));
        }

        // K10: latest store wins and stores stay isolated per key.
        {
            let mut cache = AuditCache {
                map: HashMap::new(),
            };
            cache.store(audit_key(10), CachedResult::new(vec![1]));
            cache.store(audit_key(10), CachedResult::new(vec![2]));
            assert_eq!(
                cache.get_cached(audit_key(10)),
                Some(CachedResult::new(vec![2])),
                "K10 latest wins"
            );
            cache.store(audit_key(11), CachedResult::new(vec![7]));
            assert_eq!(
                cache.get_cached(audit_key(10)),
                Some(CachedResult::new(vec![2])),
                "K10 isolation"
            );
        }

        // Full contract kit re-run through the audit witness — the
        // executable behavior spec of the P2 cache face.
        let mut kit_cache = AuditCache {
            map: HashMap::new(),
        };
        check_compilation_cache_contract(&mut kit_cache);
    }

    // ---- Section L: the capability space (10, sub-stage 0.10-r2 —
    // the general capability-model framework: the family contract,
    // the token calculus, and the registration/extension registry
    // with its fail-closed identity validation; the io sub-model
    // re-hung as the first concrete model; monotonic growth per
    // §7.3.1 rule 4) ----
    {
        use kerf::core::reserved::capability::family::{
            CapabilityModelDescriptor, CapabilityModelFamily,
        };
        use kerf::core::reserved::capability::io::IoModel;
        use kerf::core::reserved::capability::registry::{
            CapabilityModelRegistry, RegistryError, RegistryErrorKind,
        };
        use kerf::core::reserved::capability::token::TokenCalculus;

        /// A second model defined at the audit position — the
        /// extension witness: the canonical clock resource enters
        /// the same closed world as io without any framework change.
        struct AuditClockModel;

        impl CapabilityModelFamily for AuditClockModel {
            type Error = RegistryError;
            fn descriptor() -> CapabilityModelDescriptor {
                CapabilityModelDescriptor::new("clock", &["clock.now"], "ClockSource")
            }
        }

        // L01: the io sub-model binds the frozen error face and its
        // identity card through the family contract (positive).
        {
            let d = <IoModel as CapabilityModelFamily>::descriptor();
            assert_eq!(d.name(), "io", "L01 name");
            assert_eq!(d.operation_face(), "CapabilityIO", "L01 operation face");
            assert_eq!(d.authorities(), &["io.read", "io.write"], "L01 authorities");
            let err: <IoModel as CapabilityModelFamily>::Error =
                IOError::new(IoErrorKind::Denied, "L01");
            assert_eq!(err.kind(), IoErrorKind::Denied, "L01 error face");
        }

        // L02: the reserved mechanism end-to-end — register io into
        // a fresh registry and resolve it back (positive).
        {
            let mut registry = CapabilityModelRegistry::new();
            registry.register::<IoModel>().expect("L02 registers");
            assert_eq!(registry.len(), 1, "L02 len");
            assert_eq!(
                registry.lookup("io").map(|d| d.operation_face()),
                Some("CapabilityIO"),
                "L02 lookup"
            );
        }

        // L03: a duplicate model name is rejected fail-closed and
        // the closed world is unchanged (negative).
        {
            let mut registry = CapabilityModelRegistry::new();
            registry.register::<IoModel>().expect("L03 first");
            let err = registry
                .register::<IoModel>()
                .expect_err("L03 duplicate is rejected");
            assert_eq!(err.kind(), RegistryErrorKind::DuplicateModel, "L03 kind");
            assert_eq!(registry.len(), 1, "L03 closed world unchanged");
        }

        // L04: an authority already governed by another model is
        // rejected fail-closed — unique subordination (negative).
        {
            let mut registry = CapabilityModelRegistry::new();
            registry.register::<IoModel>().expect("L04 io registers");
            struct Claimer;
            impl CapabilityModelFamily for Claimer {
                type Error = RegistryError;
                fn descriptor() -> CapabilityModelDescriptor {
                    CapabilityModelDescriptor::new("other", &["io.read"], "OtherIO")
                }
            }
            let err = registry
                .register::<Claimer>()
                .expect_err("L04 authority conflict is rejected");
            assert_eq!(err.kind(), RegistryErrorKind::AuthorityConflict, "L04 kind");
            assert!(err.message().contains("io.read"), "L04 names the term");
        }

        // L05: malformed identity cards are rejected — an empty name
        // and an empty authority list (negative).
        {
            let mut registry = CapabilityModelRegistry::new();
            struct Shaped;
            impl CapabilityModelFamily for Shaped {
                type Error = RegistryError;
                fn descriptor() -> CapabilityModelDescriptor {
                    // `descriptor()` must be a compile-time shape, so
                    // the malformed probes use the const face: an
                    // empty name is rejected here; the empty-authority
                    // variant is exercised in the unit suite (the
                    // audit exercises one representative per family).
                    CapabilityModelDescriptor::new("", &["x.read"], "XIO")
                }
            }
            let err = registry
                .register::<Shaped>()
                .expect_err("L05 empty name is rejected");
            assert_eq!(err.kind(), RegistryErrorKind::InvalidDescriptor, "L05 kind");
        }

        // L06: a self-duplicated authority term inside one descriptor
        // is rejected — the card contradicts itself (negative).
        {
            let mut registry = CapabilityModelRegistry::new();
            struct SelfDup;
            impl CapabilityModelFamily for SelfDup {
                type Error = RegistryError;
                fn descriptor() -> CapabilityModelDescriptor {
                    CapabilityModelDescriptor::new("x", &["x.read", "x.read"], "XIO")
                }
            }
            let err = registry
                .register::<SelfDup>()
                .expect_err("L06 self-duplicate is rejected");
            assert_eq!(err.kind(), RegistryErrorKind::InvalidDescriptor, "L06 kind");
            assert!(err.message().contains("x.read"), "L06 names the term");
        }

        // L07: unknown names and ungoverned authorities resolve to
        // no one — the closed world answers only what it governs
        // (negative).
        {
            let mut registry = CapabilityModelRegistry::new();
            registry.register::<IoModel>().expect("L07 io registers");
            assert!(registry.lookup("clock").is_none(), "L07 unknown name");
            assert!(
                registry.governing_model("clock.now").is_none(),
                "L07 ungoverned"
            );
            assert!(
                !registry.governed_authorities().contains(&"clock.now"),
                "L07 world"
            );
        }

        // L08: the extension ability — a model defined at this audit
        // position registers alongside io; the closed world grows
        // additively with zero framework change (positive).
        {
            let mut registry = CapabilityModelRegistry::new();
            registry.register::<IoModel>().expect("L08 io registers");
            registry
                .register::<AuditClockModel>()
                .expect("L08 the audit-position model registers");
            assert_eq!(
                registry.governed_authorities(),
                vec!["io.read", "io.write", "clock.now"],
                "L08 closed world spans both positions"
            );
            assert_eq!(
                registry.governing_model("clock.now").map(|d| d.name()),
                Some("clock"),
                "L08 resolution"
            );
        }

        // L09: the registry error face renders in the R8 message
        // shape and its kinds stay pairwise distinct (negative).
        {
            for kind in [
                RegistryErrorKind::InvalidDescriptor,
                RegistryErrorKind::DuplicateModel,
                RegistryErrorKind::AuthorityConflict,
            ] {
                let err = RegistryError::new(kind, "L09");
                let text = err.to_string();
                assert!(
                    text.chars().next().expect("L09 non-empty").is_lowercase(),
                    "L09 lowercase start: `{text}`"
                );
                assert!(!text.ends_with('.'), "L09 no trailing period: `{text}`");
                assert!(text.contains("L09"), "L09 payload carried: `{text}`");
            }
            let texts: Vec<String> = [
                RegistryErrorKind::InvalidDescriptor,
                RegistryErrorKind::DuplicateModel,
                RegistryErrorKind::AuthorityConflict,
            ]
            .iter()
            .map(|k| RegistryError::new(*k, "x").to_string())
            .collect();
            for i in 0..texts.len() {
                for j in (i + 1)..texts.len() {
                    assert_ne!(texts[i], texts[j], "L09 kinds {i}/{j} distinct");
                }
            }
        }

        // L10: freeze continuity of the 0.10-r1 path — the
        // re-exported module resolves the very same token and error
        // types, and the sealed tokens stay zero-sized with their
        // authority terms intact (positive shape pin).
        {
            use kerf::core::reserved::capability::io as new_path;
            use kerf::core::reserved::capability_io as frozen;
            assert_eq!(
                std::any::TypeId::of::<frozen::ReadCapability>(),
                std::any::TypeId::of::<new_path::ReadCapability>(),
                "L10 read token path identity"
            );
            assert_eq!(
                std::any::TypeId::of::<frozen::IOError>(),
                std::any::TypeId::of::<new_path::IOError>(),
                "L10 error face path identity"
            );
            assert_eq!(std::mem::size_of::<frozen::WriteCapability>(), 0, "L10 ZST");
            assert_eq!(
                <frozen::ReadCapability as TokenCalculus>::authority(),
                "io.read",
                "L10 authority term"
            );
        }
    }

    // ============ Section M: conservative static checker (1.0) ============
    // The R1-R8 rules of docs/develop/v1/stage-1-plan.md §3 over the
    // real pipeline (read -> expand -> typecheck), plus the E0xxx
    // registry face. Externals is built from the two authoritative
    // sources only (single-source discipline): STAGE0_GLOBALS names +
    // Builtin::ALL arity triples.
    {
        use kerf::typecheck::{Externals, Severity, TypeCode, check_module};
        use kerf::vm::Builtin;
        use kerf_expander::STAGE0_GLOBALS;

        let externals = Externals::from_named_arities(
            Builtin::ALL
                .iter()
                .map(|(_, name, arity)| (*name, Some(*arity))),
        );

        fn check_src(src: &str, ext: &Externals) -> Vec<kerf::typecheck::TypeDiagnostic> {
            let forms = read_program(FILE, src).expect("audit source must read");
            let items = expand_program(&forms).expect("audit source must expand");
            check_module(&items, ext)
        }

        // M01: a clean program through the full pipeline yields zero
        // diagnostics (the soundness guard — no false positives).
        {
            let diags = check_src(
                "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2)))))\n(define r (fib 10))",
                &externals,
            );
            assert!(diags.is_empty(), "M01 clean program, got {diags:?}");
        }

        // M02: R2 — a defined 1-param function applied with 3 args.
        {
            let diags = check_src("(define (f a) a)\n(define x (f 1 2 3))", &externals);
            assert_eq!(diags.len(), 1, "M02 one diagnostic");
            assert_eq!(diags[0].code, TypeCode::ArityMismatch, "M02 code");
            assert_eq!(
                diags[0].message, "arity mismatch: `f` expects `1` arguments, got `3`",
                "M02 VM-mirrored wording"
            );
        }

        // M03: R2 — a builtin with a known arity applied wrong (car
        // takes 1, supplied 2).
        {
            let diags = check_src("(define x (car 1 2))", &externals);
            assert_eq!(diags.len(), 1, "M03 one diagnostic");
            assert_eq!(diags[0].code, TypeCode::ArityMismatch, "M03 code");
        }

        // M04: R3 — a literal int in condition position.
        {
            let diags = check_src("(define x (if 1 2 3))", &externals);
            assert_eq!(diags.len(), 1, "M04 one diagnostic");
            assert_eq!(diags[0].code, TypeCode::NonBooleanCondition, "M04 code");
            assert!(
                diags[0]
                    .message
                    .starts_with("type mismatch: `if` condition"),
                "M04 wording: `{}`",
                diags[0].message
            );
        }

        // M05: R4 — direct application of a literal.
        {
            let diags = check_src("(define x (5 6))", &externals);
            assert_eq!(diags.len(), 1, "M05 one diagnostic");
            assert_eq!(diags[0].code, TypeCode::NonCallableCallee, "M05 code");
        }

        // M06: R6 — a top-level perform with no enclosing handler.
        {
            let diags = check_src("(define x (perform log 1 2))", &externals);
            assert_eq!(diags.len(), 1, "M06 one diagnostic");
            assert_eq!(
                diags[0].code,
                TypeCode::TopLevelUnhandledPerform,
                "M06 code"
            );
            assert_eq!(
                diags[0].message, "unhandled effect `log` at module top level",
                "M06 wording"
            );
        }

        // M07: R5 — the routed handler takes 2 params but the perform
        // supplies 1 arg; plus the Fn-body soundness guard in the same
        // program (the deferred perform is never reported).
        {
            let diags = check_src(
                "(define x (handle (perform log 42) (log (fn (a b) a))))\n(define (later) (perform other 1))",
                &externals,
            );
            assert_eq!(diags.len(), 1, "M07 one diagnostic (Fn body deferred)");
            assert_eq!(diags[0].code, TypeCode::HandlerArityMismatch, "M07 code");
        }

        // M08: R8 — rebinding a builtin through set! warns (the first
        // Warning producer; legal semantics, warning severity).
        {
            let diags = check_src("(define x (set! car 1))", &externals);
            assert_eq!(diags.len(), 1, "M08 one diagnostic");
            assert_eq!(
                diags[0].code,
                TypeCode::AssignmentTargetSurprise,
                "M08 code"
            );
            assert_eq!(diags[0].severity, Severity::Warning, "M08 warning level");
            assert_eq!(
                diags[0].message, "assignment rebinds builtin `car`",
                "M08 wording"
            );
        }

        // M09: multi-error collection — two independent definite
        // errors across two defines, both collected in one pass.
        {
            let diags = check_src("(define a (if 1 2 3))\n(define b (car 1 2))", &externals);
            let codes: Vec<&str> = diags.iter().map(|d| d.code.as_str()).collect();
            assert_eq!(codes, vec!["E0003", "E0002"], "M09 both collected");
        }

        // M10: the registry face — all eight stable code strings, the
        // severity distinction, and the single-source Externals table
        // covering every STAGE0_GLOBALS name with a known arity.
        {
            let all: Vec<&str> = [
                TypeCode::UnboundVariable,
                TypeCode::ArityMismatch,
                TypeCode::NonBooleanCondition,
                TypeCode::NonCallableCallee,
                TypeCode::HandlerArityMismatch,
                TypeCode::TopLevelUnhandledPerform,
                TypeCode::NonCallableHandler,
                TypeCode::AssignmentTargetSurprise,
            ]
            .iter()
            .map(|c| c.as_str())
            .collect();
            assert_eq!(
                all,
                vec![
                    "E0001", "E0002", "E0003", "E0004", "E0005", "E0006", "E0007", "E0008"
                ],
                "M10 registry strings"
            );
            assert_ne!(Severity::Error, Severity::Warning, "M10 severities");
            for name in STAGE0_GLOBALS {
                let resolved = externals
                    .resolve(name)
                    .unwrap_or_else(|| panic!("M10 global `{name}` must resolve"));
                assert!(
                    resolved.is_some(),
                    "M10 global `{name}` arity must be known"
                );
            }
            assert_eq!(externals.len(), Builtin::ALL.len(), "M10 table size");
        }
    }

    // ============ Section N: driver wiring (1.1) ============
    // The checker mounted between expand and both engines
    // (stage-1-plan §2 row 1.1): source-reachable E0xxx diagnostics
    // through the full driver pipeline, abort-before-execution, the
    // warning channel on every face, and the REPL delta replay.
    {
        use kerf::driver::{
            Engine, Repl, ReplEvent, Session, check_source, render_diagnostics, run_parity_source,
            run_source,
        };

        fn tags(diags: &[kerf::driver::Diagnostic]) -> Vec<&'static str> {
            diags.iter().map(|d| d.code.tag()).collect()
        }

        // N01: E0002 end-to-end on the run face — the registry tag is
        // the rendered code, the span is byte-precise, the abort
        // happens without executing.
        {
            let mut s = Session::new();
            let err = run_source(
                &mut s,
                "n1.krf",
                "(define (f x) x)\n(define r (f 1 2))",
                Engine::Vm,
                &[],
            )
            .expect_err("N01 must abort");
            assert_eq!(tags(&err), vec!["E0002"], "N01 registry tag");
            assert!(err[0].primary_span.is_some(), "N01 span carried");
        }

        // N02: E0003 through the check face.
        {
            let mut s = Session::new();
            let err = check_source(&mut s, "n2.krf", "(define r (if 1 2 3))")
                .expect_err("N02 must abort");
            assert_eq!(tags(&err), vec!["E0003"], "N02 registry tag");
        }

        // N03: E0004 — the unrebound literal-define callee (the R4
        // extension terminal form).
        {
            let mut s = Session::new();
            let err = run_source(
                &mut s,
                "n3.krf",
                "(define two 2)\n(define r (two 1))",
                Engine::Vm,
                &[],
            )
            .expect_err("N03 must abort");
            assert_eq!(tags(&err), vec!["E0004"], "N03 registry tag");
        }

        // N04: E0006 — a top-level immediate perform with no handler.
        {
            let mut s = Session::new();
            let err = run_source(
                &mut s,
                "n4.krf",
                "(define r (perform unhandled-fx 1 2))",
                Engine::Vm,
                &[],
            )
            .expect_err("N04 must abort");
            assert_eq!(tags(&err), vec!["E0006"], "N04 registry tag");
        }

        // N05: E0008 never blocks — the program runs to its value on
        // both engines and the warning rides on the outcome.
        {
            let mut s = Session::new();
            for engine in [Engine::Vm, Engine::Eval] {
                let out = run_source(
                    &mut s,
                    "n5.krf",
                    "(define base 40)\n(define r (+ base (set! car 2)))",
                    engine,
                    &[],
                )
                .expect("N05 warnings never block");
                assert_eq!(out.warnings.len(), 1, "N05 warning count");
                assert_eq!(out.warnings[0].code.tag(), "E0008", "N05 tag");
                assert_eq!(
                    out.global("r").map(|v| v.to_string()),
                    Some("42".to_owned()),
                    "N05 value channel untouched"
                );
            }
        }

        // N06: a warnings-only batch renders the warning summary and
        // never claims an abort it did not make.
        {
            let mut s = Session::new();
            let out = run_source(
                &mut s,
                "n6.krf",
                "(define a (set! car 1))\n(define b (set! cdr 2))",
                Engine::Vm,
                &[],
            )
            .expect("N06 two warnings");
            let rendered = render_diagnostics(&s, &out.warnings);
            assert!(
                rendered.ends_with("warning: 2 warnings emitted\n"),
                "N06 summary: {rendered}"
            );
            assert!(!rendered.contains("aborting due to"), "N06 no abort line");
        }

        // N07: the rendered registry form — `error[E0002]:` head plus
        // the file:line:column location line.
        {
            let mut s = Session::new();
            let err = run_source(
                &mut s,
                "n7.krf",
                "(define (f x) x)\n(define r (f 1 2))",
                Engine::Vm,
                &[],
            )
            .expect_err("N07 aborts");
            let rendered = render_diagnostics(&s, &err);
            assert!(
                rendered.starts_with("error[E0002]: "),
                "N07 head: {rendered}"
            );
            assert!(
                rendered.contains("--> n7.krf:2:"),
                "N07 location: {rendered}"
            );
        }

        // N08: multi-error collection through the driver — three
        // independent definite errors in one batch with the abort
        // summary.
        {
            let mut s = Session::new();
            let err = check_source(
                &mut s,
                "n8.krf",
                "(define two 2)\n(define a (if 1 2 3))\n(define b (car 1 2))\n(define c (two 1))",
            )
            .expect_err("N08 three definite errors");
            assert_eq!(err.len(), 3, "N08 collected all three: {err:?}");
            let t = tags(&err);
            assert!(t.contains(&"E0003") && t.contains(&"E0002") && t.contains(&"E0004"));
            let rendered = render_diagnostics(&s, &err);
            assert!(
                rendered.ends_with("error: aborting due to 3 previous errors\n"),
                "N08 summary: {rendered}"
            );
        }

        // N09: abort-before-execution — a write-line before a
        // definite error never runs.
        {
            let mut s = Session::new();
            let err = run_source(
                &mut s,
                "n9.krf",
                "(define a (write-line \"must-not-print\"))\n(define b (car 1 2))",
                Engine::Vm,
                &[],
            )
            .expect_err("N09 aborts");
            assert!(tags(&err).contains(&"E0002"), "N09 finding present");
        }

        // N10: the REPL faces — the warning delta replay (shown once,
        // silent on replay) and the rollback on definite errors, with
        // the parity face carrying warnings without blocking.
        {
            let mut r = Repl::new();
            match r.submit("(set! car 1)") {
                ReplEvent::Evaluated { new_warnings, .. } => {
                    let shown = new_warnings.join("\n");
                    assert!(shown.contains("warning[E0008]"), "N10 rendered: {shown}");
                }
                other => panic!("N10 warning submission is legal: {other:?}"),
            }
            match r.submit("(+ 1 2)") {
                ReplEvent::Evaluated {
                    value,
                    new_warnings,
                    ..
                } => {
                    assert_eq!(value.as_deref(), Some("3"), "N10 value channel");
                    assert!(new_warnings.is_empty(), "N10 silent on replay");
                }
                other => panic!("N10 second submission: {other:?}"),
            }
            // The earlier `(set! car 1)` poisons `car` for R2 (the
            // assign guard correctly skips reassigned names), so the
            // definite-error submission uses `cons`.
            match r.submit("(cons 1 2 3)") {
                ReplEvent::Error { rendered } => {
                    assert!(rendered.contains("error[E0002]"), "N10 rollback face");
                }
                other => panic!("N10 definite error: {other:?}"),
            }
            assert!(
                !r.accepted_source().contains("(cons 1 2 3)"),
                "N10 rolled back"
            );

            let mut s = Session::new();
            let report = run_parity_source(&mut s, "n10.krf", "(define r (set! car 7))", &[])
                .expect("N10 parity with warnings");
            assert!(report.agrees(), "N10 parity passes");
            assert_eq!(report.warnings.len(), 1, "N10 parity carries warnings");
        }
    }

    println!(
        "AUDIT PASS 130/130 (A10 + B10 + C5 + D5 + E10 + F10 + G10 + H10 + I10 + J10 + K10 + L10 + M10 + N10)"
    );
    println!(
        "class coverage at 1.1: all seven lit (unchanged); section N mounts the checker in the driver pipeline — source-reachable E0xxx end-to-end, abort-before-execution, and the first Warning producer through run/check/parity and the REPL"
    );
}

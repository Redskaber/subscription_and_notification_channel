//! Stage 0 performance baseline (SOP §14.6.4) — the re-runnable
//! benchmark entry for the stage-end gate.
//!
//! Measures the two §22.3 baseline axes (compile time + run time)
//! with std-only tooling (zero new dependencies — SOP §18): wall
//! clock via `std::time::Instant`, statistics as mean/median over N
//! iterations. The output lines are the paste source for
//! `docs/develop/v0/stage-0/performance-baseline.md`; re-run after
//! any change and compare against the recorded baseline (regression
//! detection, §14.6.4 rule 3).
//!
//! Run: `cargo run --release --example stage0_baseline`.

use std::cell::Cell;
use std::rc::Rc;
use std::time::Instant;

use kerf::compiler::compile_program;
use kerf::expander::expand_program;
use kerf::reader::read_program;
use kerf::runtime::collect as production_collect;
use kerf::span::FileId;
use kerf::vm::{Collector, Heap, Roots, Vm};

const FIB: &str = "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2)))))";

fn stats(samples: &[f64]) -> (f64, f64) {
    let mut s = samples.to_vec();
    s.sort_by(|a, b| a.partial_cmp(b).expect("finite samples"));
    let mean = s.iter().sum::<f64>() / s.len() as f64;
    let median = s[s.len() / 2];
    (mean, median)
}

fn fmt_us(v: f64) -> String {
    if v >= 1000.0 {
        format!("{:.3}ms", v / 1000.0)
    } else {
        format!("{:.1}µs", v)
    }
}

/// Counting collector: shares sweep counters out through interior
/// mutability so the bench can read them while the VM owns the box.
/// The sweep itself is the production mark-sweep (`kerf-runtime`).
#[derive(Clone, Default)]
struct SharedCounters {
    cycles: Rc<Cell<u32>>,
    swept: Rc<Cell<u32>>,
}

struct CountingCollector {
    shared: SharedCounters,
}

impl Collector for CountingCollector {
    fn collect(&mut self, heap: &mut Heap, roots: &Roots) -> u32 {
        let gc = production_collect(heap, roots);
        self.shared.cycles.set(self.shared.cycles.get() + 1);
        self.shared.swept.set(self.shared.swept.get() + gc.swept);
        gc.swept
    }
}

fn main() {
    let file = FileId(0);

    println!("kerf stage-0 performance baseline");
    println!(
        "env: release profile (debug_assertions={}), parallelism {:?}",
        cfg!(debug_assertions),
        std::thread::available_parallelism()
    );

    // B1 compile throughput: source -> read + expand + compile + verify.
    const B1_ITERS: usize = 1_000;
    let mut b1 = Vec::with_capacity(B1_ITERS);
    for _ in 0..B1_ITERS {
        let t = Instant::now();
        let forms = read_program(file, FIB).expect("read");
        let items = expand_program(&forms).expect("expand");
        let bc = compile_program(&items).expect("compile");
        bc.verify().expect("verify");
        b1.push(t.elapsed().as_secs_f64() * 1e6);
    }
    let (mean, median) = stats(&b1);
    println!(
        "B1 compile-fib (read+expand+compile+verify): {} iters, mean {}, median {}",
        B1_ITERS,
        fmt_us(mean),
        fmt_us(median)
    );

    // B2 VM run: fib(25) = 75025 — the 0.6 anchor workload, entry
    // consumes the defined closure (read back from the global).
    const B2_ITERS: usize = 100;
    let bc2 = {
        let src =
            "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define r (fib 25))";
        let forms = read_program(file, src).expect("read");
        let items = expand_program(&forms).expect("expand");
        compile_program(&items).expect("compile")
    };
    let mut b2 = Vec::with_capacity(B2_ITERS);
    for _ in 0..B2_ITERS {
        let mut vm = Vm::new(bc2.clone()).expect("vm");
        let t = Instant::now();
        vm.run().expect("fib(25)");
        let elapsed = t.elapsed().as_secs_f64() * 1e3;
        assert_eq!(
            vm.global("r").map(|v| v.to_string()),
            Some("75025".to_owned())
        );
        b2.push(elapsed);
    }
    let (mean, median) = stats(&b2);
    println!(
        "B2 vm-run-fib25: {} iters, mean {:.3}ms, median {:.3}ms",
        B2_ITERS, mean, median
    );

    // B3 eval run: fib(20) = 6765 on the meta-circular evaluator.
    const B3_ITERS: usize = 30;
    let src = "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define r (fib 20))";
    let mut b3 = Vec::with_capacity(B3_ITERS);
    for _ in 0..B3_ITERS {
        let mut session = kerf::driver::Session::new();
        let t = Instant::now();
        let outcome = kerf::driver::run_source(
            &mut session,
            "bench.krf",
            src,
            kerf::driver::Engine::Eval,
            &[],
        )
        .expect("eval fib(20)");
        let elapsed = t.elapsed().as_secs_f64() * 1e3;
        assert_eq!(
            outcome.global("r").map(|v| v.to_string()),
            Some("6765".to_owned())
        );
        b3.push(elapsed);
    }
    let (mean, median) = stats(&b3);
    println!(
        "B3 eval-run-fib20: {} iters, mean {:.3}ms, median {:.3}ms",
        B3_ITERS, mean, median
    );

    // B4 GC pressure: 2000 top-level defines each allocating one
    // pair that is dead right after `car` consumes it — the sweep
    // path is exercised under a tight 1024-cell budget (frames stay
    // flat; only heap garbage accumulates).
    const B4_ITERS: usize = 50;
    const B4_PAIRS: usize = 2_000;
    let mut churn_src = String::with_capacity(B4_PAIRS * 32);
    for i in 0..B4_PAIRS {
        churn_src.push_str(&format!("(define d{i} (car (cons {i} nil))) "));
    }
    let churn_bc = {
        let forms = read_program(file, &churn_src).expect("read");
        let items = expand_program(&forms).expect("expand");
        compile_program(&items).expect("compile")
    };
    let mut b4 = Vec::with_capacity(B4_ITERS);
    let shared = SharedCounters::default();
    for _ in 0..B4_ITERS {
        let collector = Box::new(CountingCollector {
            shared: shared.clone(),
        });
        let mut vm = Vm::with_budget_and_collector(churn_bc.clone(), 1024, collector)
            .expect("tight-budget vm");
        let t = Instant::now();
        vm.run().expect("churn program halts");
        let elapsed = t.elapsed().as_secs_f64() * 1e3;
        b4.push(elapsed);
    }
    let (mean, median) = stats(&b4);
    println!(
        "B4 gc-pressure-churn ({} pairs, budget 1024): {} iters, mean {:.3}ms, median {:.3}ms, gc-cycles/iter {}, swept/iter {}",
        B4_PAIRS,
        B4_ITERS,
        mean,
        median,
        shared.cycles.get() / B4_ITERS as u32,
        shared.swept.get() / B4_ITERS as u32
    );

    // B5 driver end-to-end: run_source VM fib(25) — session + pipeline
    // + halt-snapshot included.
    const B5_ITERS: usize = 50;
    let src = "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define r (fib 25))";
    let mut b5 = Vec::with_capacity(B5_ITERS);
    for _ in 0..B5_ITERS {
        let mut session = kerf::driver::Session::new();
        let t = Instant::now();
        let outcome = kerf::driver::run_source(
            &mut session,
            "bench.krf",
            src,
            kerf::driver::Engine::Vm,
            &[],
        )
        .expect("e2e fib(25)");
        let elapsed = t.elapsed().as_secs_f64() * 1e3;
        assert_eq!(
            outcome.global("r").map(|v| v.to_string()),
            Some("75025".to_owned())
        );
        b5.push(elapsed);
    }
    let (mean, median) = stats(&b5);
    println!(
        "B5 driver-e2e-fib25 (vm): {} iters, mean {:.3}ms, median {:.3}ms",
        B5_ITERS, mean, median
    );
}

//! Stage 1.0 cross-crate integration tests — the conservative static
//! checker over the REAL pipeline (FP6/F8 of docs/tests/v1/stage1/
//! typecheck.md): `kerf_reader::read_program` ->
//! `kerf_expander::expand_program` -> `kerf_typecheck::check_module`.
//!
//! The Externals table is built from the two authoritative sources
//! (single-source discipline, stage-1-plan §4):
//! `kerf_expander::STAGE0_GLOBALS` (names) and `kerf_vm::Builtin::ALL`
//! (name + arity triples) — this crate never duplicates the list.
//!
//! Layer disclosure: programs the expander already rejects (unbound
//! identifiers, since 0.4) never reach the checker on the source path
//! — the R1 structural re-assertion is exercised through direct
//! construction in the crate's unit tests. This file proves the rules
//! that ARE source-reachable today as runtime-only errors (R2-R7) and
//! the R8 warning, plus the zero-false-positive soundness guard over
//! real clean programs.

use kerf::typecheck::{Externals, Severity, TypeCode, check_module};
use kerf_core::ModuleItem;
use kerf_expander::STAGE0_GLOBALS;
use kerf_reader::read_program;
use kerf_span::FileId;
use kerf_vm::Builtin;

/// The audit-grade externals table: every builtin with its arity.
fn builtin_externals() -> Externals {
    Externals::from_named_arities(
        Builtin::ALL
            .iter()
            .map(|(_, name, arity)| (*name, Some(*arity))),
    )
}

/// read -> expand -> typecheck over real source text.
fn check_source(source: &str) -> Vec<kerf::typecheck::TypeDiagnostic> {
    let forms = read_program(FileId(0), source).expect("source must read");
    let items: Vec<ModuleItem> = kerf_expander::expand_program(&forms).expect("source must expand");
    check_module(&items, &builtin_externals())
}

fn codes_of(source: &str) -> Vec<TypeCode> {
    check_source(source).into_iter().map(|d| d.code).collect()
}

// ---------- single-source discipline (FP2 / cross-stage consumption) ----------

#[test]
fn externals_table_covers_every_stage0_global_with_arity() {
    let ext = builtin_externals();
    for name in STAGE0_GLOBALS {
        let resolved = ext.resolve(name).expect("every stage0 global must resolve");
        let arity = resolved.expect("every builtin arity must be known");
        assert!(
            arity > 0 || *name == "read-line",
            "arity sanity for `{name}`"
        );
    }
    assert_eq!(ext.len(), Builtin::ALL.len());
    assert_eq!(Builtin::ALL.len(), 18);
}

// ---------- clean programs: the soundness guard (zero false positives) ----------

#[test]
fn clean_fib_program_yields_zero_diagnostics() {
    let source =
        "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2)))))\n(define r (fib 10))";
    assert!(check_source(source).is_empty());
}

#[test]
fn clean_handle_program_yields_zero_diagnostics() {
    let source = "(define x (handle (perform log 42) (log (fn (v) v))))";
    assert!(check_source(source).is_empty());
}

#[test]
fn clean_set_on_define_yields_no_warning() {
    // Assigning a module define is idiomatic mutation — silent.
    let source = "(define acc 0)\n(define y (set! acc 41))\n(define z (set! acc (+ acc 1)))";
    assert!(check_source(source).is_empty());
}

#[test]
fn clean_let_shadowing_yields_zero_diagnostics() {
    let source = "(define x (let ((v 1) (v 2)) v))";
    assert!(check_source(source).is_empty());
}

#[test]
fn clean_kitchen_sink_program_yields_zero_diagnostics() {
    // Self-recursion (the letrec pre-bind), builtin calls, handle
    // routing, and define-target assignment — all clean through the
    // real pipeline in one program. (Source-level forward references
    // are rejected by the expander — the stricter first line of
    // defense; the checker's Fn-body all-defines visibility is a
    // structural-layer property exercised by direct construction in
    // the crate's unit tests.)
    let source = "(define (fact n) (if (< n 2) 1 (* n (fact (- n 1)))))\n(define acc 0)\n(define r (handle (perform log (fact 5)) (log (fn (v) v))))\n(define s (set! acc r))";
    assert!(check_source(source).is_empty());
}

// ---------- R2 through the real pipeline (FP4) ----------

#[test]
fn source_arity_mismatch_on_defined_fn_is_reported() {
    // (fib 1 2) — the define carries a 1-param Fn; three args.
    let source =
        "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2)))))\n(define r (fib 1 2))";
    assert_eq!(codes_of(source), vec![TypeCode::ArityMismatch]);
}

#[test]
fn source_builtin_arity_mismatch_is_reported() {
    let source = "(define x (car 1 2))";
    assert_eq!(codes_of(source), vec![TypeCode::ArityMismatch]);
}

#[test]
fn source_matching_arities_pass() {
    let source = "(define x (car (cons 1 2)))";
    assert!(check_source(source).is_empty());
}

// ---------- R3 / R4 through the real pipeline (FP5) ----------

#[test]
fn source_literal_int_condition_is_reported() {
    let source = "(define x (if 1 2 3))";
    assert_eq!(codes_of(source), vec![TypeCode::NonBooleanCondition]);
}

#[test]
fn source_literal_bool_condition_passes() {
    let source = "(define x (if #t 2 3))";
    assert!(check_source(source).is_empty());
}

#[test]
fn source_literal_callee_is_reported() {
    // Direct application of a literal — expands to Apply{Literal}.
    let source = "(define x (5 6))";
    assert_eq!(codes_of(source), vec![TypeCode::NonCallableCallee]);
}

// ---------- R5 / R6 / R7 through the real pipeline (FP6) ----------

#[test]
fn source_top_level_unhandled_perform_is_reported() {
    let source = "(define x (perform log 1 2))";
    assert_eq!(codes_of(source), vec![TypeCode::TopLevelUnhandledPerform]);
}

#[test]
fn source_handle_with_mismatched_handler_arity_is_reported() {
    // The perform supplies 1 arg; the handler takes 2 params.
    let source = "(define x (handle (perform log 42) (log (fn (a b) a))))";
    assert_eq!(codes_of(source), vec![TypeCode::HandlerArityMismatch]);
}

#[test]
fn source_fn_body_perform_without_handle_passes() {
    // The soundness guard: dynamic handlers may exist at call time.
    let source = "(define (f) (perform log 1))";
    assert!(check_source(source).is_empty());
}

#[test]
fn source_handle_wrong_effect_is_reported_as_unhandled() {
    let source = "(define x (handle (perform log 1) (audit (fn (v) v))))";
    assert_eq!(codes_of(source), vec![TypeCode::TopLevelUnhandledPerform]);
}

#[test]
fn source_literal_handler_is_reported() {
    let source = "(define x (handle (perform log 1) (log 7)))";
    assert_eq!(codes_of(source), vec![TypeCode::NonCallableHandler]);
}

// ---------- R8 through the real pipeline (FP7) ----------

#[test]
fn source_builtin_rebind_warns() {
    // (set! car ...) — the expander accepts (car is a Global), the
    // checker surfaces the surprise at warning level.
    let source = "(define x (set! car 1))";
    let diags = check_source(source);
    assert_eq!(diags.len(), 1);
    assert_eq!(diags[0].code, TypeCode::AssignmentTargetSurprise);
    assert_eq!(diags[0].severity, Severity::Warning);
    assert_eq!(diags[0].message, "assignment rebinds builtin `car`");
}

// ---------- FP8: multi-error collection over the real pipeline ----------

#[test]
fn source_multi_error_program_collects_all() {
    // Two independent definite errors across two defines.
    let source = "(define a (if 1 2 3))\n(define b (car 1 2))";
    let diags = check_source(source);
    assert_eq!(
        diags.iter().map(|d| d.code).collect::<Vec<_>>(),
        vec![TypeCode::NonBooleanCondition, TypeCode::ArityMismatch]
    );
}

#[test]
fn source_warning_and_error_coexist() {
    let source = "(define a (if 1 2 3))\n(define b (set! car 1))";
    let diags = check_source(source);
    let severities: Vec<Severity> = diags.iter().map(|d| d.severity).collect();
    assert_eq!(severities, vec![Severity::Error, Severity::Warning]);
}

// ---------- span discipline through the pipeline ----------

#[test]
fn source_diagnostics_carry_real_spans() {
    // `(if 1 2 3)` — the condition literal sits at byte offset 15
    // within the define form (the checker reports the literal's span).
    let source = "(define x (if 1 2 3))";
    let diags = check_source(source);
    assert_eq!(diags.len(), 1);
    let span = diags[0].span;
    assert!(
        span.start.0 as usize <= 15,
        "span must point into the source"
    );
    assert!(span.end.0 as usize > 0, "span must be non-empty");
    // The rendered slice must be the `1` literal.
    let start = span.start.0 as usize;
    let end = span.end.0 as usize;
    assert_eq!(&source[start..end], "1");
}

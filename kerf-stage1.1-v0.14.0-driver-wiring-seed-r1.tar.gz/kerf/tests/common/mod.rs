//! Shared helpers for cross-crate integration tests (SOP §9.1 rule 4).
//!
//! This module is mounted exactly once by the test entry
//! (`tests/runner.rs`); individual test modules under `tests/v0/` import
//! it via `super::common` (SOP §8.4.6 note — single-mount avoids the
//! duplicate-module lint).
//!
//! History note (sub-stage 0.3): the former `TokenLike` stand-in was
//! retired when `kerf-reader` landed, exactly as its doc comment
//! promised — helpers below now build real `StxToken` values from the
//! reader crate, so the span-reduction pattern is proven against the
//! production token type.

use kerf::reader::{Delimiter, StxToken, StxTokenKind};
use kerf::syntax::StxSymbol;
use kerf_span::{ByteOffset, FileId, Span, SpanError};

/// A real open-delimiter token at `span`.
pub(crate) fn open_token(span: Span) -> StxToken {
    StxToken {
        kind: StxTokenKind::Delimiter(Delimiter::Open),
        span,
    }
}

/// A real close-delimiter token at `span`.
pub(crate) fn close_token(span: Span) -> StxToken {
    StxToken {
        kind: StxTokenKind::Delimiter(Delimiter::Close),
        span,
    }
}

/// A real identifier token carrying `text` at `span`.
pub(crate) fn ident_token(text: &str, span: Span) -> StxToken {
    StxToken {
        kind: StxTokenKind::Identifier(StxSymbol::new(text).expect("valid symbol")),
        span,
    }
}

/// A real integer-literal token carrying `value` at `span`.
pub(crate) fn int_token(value: i64, span: Span) -> StxToken {
    StxToken {
        kind: StxTokenKind::IntLiteral(value),
        span,
    }
}

/// Reduce a non-empty token slice to its covering span (parser reduction
/// pattern — the way the real parser folds token spans into node spans).
///
/// # Panics
/// Panics when `tokens` is empty: an empty reduction has no span to report.
pub(crate) fn covering_span(tokens: &[StxToken]) -> Result<Span, SpanError> {
    let mut span = tokens[0].span;
    for token in &tokens[1..] {
        span = span.join(&token.span)?;
    }
    Ok(span)
}

/// Convenience: well-formed root-generation span builder for fixtures.
///
/// # Panics
/// Panics when `(start, end)` is malformed — fixture data must be valid by
/// construction; malformed-input behavior is asserted explicitly in the
/// negative tests, never through this helper.
pub(crate) fn root_span(file: u32, start: u32, end: u32) -> Span {
    Span::root(FileId(file), ByteOffset(start), ByteOffset(end))
        .expect("test fixture span must be well-formed")
}

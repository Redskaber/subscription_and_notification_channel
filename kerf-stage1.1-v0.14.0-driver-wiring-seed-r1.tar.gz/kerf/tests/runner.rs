//! Cross-crate integration test single entry (SOP §8.4.6 v11.2).
//!
//! Cargo auto-discovers this file as the root package's integration test
//! target. Every test module under `tests/v0/stage-N/{plan,gate}/` is
//! mounted here via `#[path]` — no per-file `[[test]]` declarations.
//! Shared helpers live in `common/` and are mounted exactly once here
//! (submodules import them via `super::common` — mounting the same file
//! from several submodules trips the duplicate-module lint).
//! Selective run: `cargo test --test runner <module>::<case>`.

#[path = "common/mod.rs"]
mod common;

#[path = "v0/stage0/plan/span_seed_tests.rs"]
mod span_seed_tests;

#[path = "v0/stage0/plan/core_seed_tests.rs"]
mod core_seed_tests;

#[path = "v0/stage0/plan/syntax_seed_tests.rs"]
mod syntax_seed_tests;

#[path = "v0/stage0/plan/reader_seed_tests.rs"]
mod reader_seed_tests;

#[path = "v0/stage0/plan/expander_seed_tests.rs"]
mod expander_seed_tests;

#[path = "v0/stage0/plan/compiler_seed_tests.rs"]
mod compiler_seed_tests;

#[path = "v0/stage0/plan/vm_seed_tests.rs"]
mod vm_seed_tests;

#[path = "v0/stage0/plan/runtime_seed_tests.rs"]
mod runtime_seed_tests;

#[path = "v0/stage0/plan/driver_seed_tests.rs"]
mod driver_seed_tests;

#[path = "v0/stage0/plan/macro_seed_tests.rs"]
mod macro_seed_tests;

#[path = "v0/stage0/plan/reserved_seed_tests.rs"]
mod reserved_seed_tests;

#[path = "v0/stage0/plan/snapshot_seed_tests.rs"]
mod snapshot_seed_tests;

#[path = "v1/stage1/plan/typecheck_seed_tests.rs"]
mod typecheck_seed_tests;

#[path = "v1/stage1/plan/typecheck_wiring_seed_tests.rs"]
mod typecheck_wiring_seed_tests;

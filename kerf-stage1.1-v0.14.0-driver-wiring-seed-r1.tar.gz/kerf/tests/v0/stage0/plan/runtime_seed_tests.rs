//! kerf-runtime seed tests (Stage 0.7, cross-crate integration layer).
//!
//! Mounted via `tests/runner.rs` (SOP §8.4.6 root-tree discipline).
//! The dual-path anchor cases run the same expanded program through
//! BOTH engines — compile → VM and eval — asserting structural
//! agreement on the program value and the observed global (the
//! stage-0-plan §5 row-0.7 cross-check; a divergence is a P1 line
//! stop, §21.11 risk 5). The STAGE0_GLOBALS parity becomes OFFICIAL
//! here (expander name table ↔ VM registry ↔ evaluator seeding), and
//! the VM collect-then-retry injection face runs the §19.4 skeleton
//! end to end.

use kerf::compiler::compile_program;
use kerf::expander::{STAGE0_GLOBALS, expand_program};
use kerf::reader::read_program;
use kerf::runtime::{Evaluator, MarkSweep, assert_parity, parity_repr};
use kerf::span::FileId;
use kerf::vm::{Builtin, RuntimeError, Value, Vm};

const FILE: FileId = FileId(0);

fn items_of(src: &str) -> Vec<kerf::core::ModuleItem> {
    let forms = read_program(FILE, src).expect("source must read");
    expand_program(&forms).expect("source must expand")
}

/// Run one source program through BOTH engines; assert the program
/// values and the observed `r` global agree structurally; return the
/// `r` repr for per-program value checks.
fn dual_run(src: &str) -> String {
    let items = items_of(src);

    // VM path: reader -> expander -> compiler -> VM.
    let bc = compile_program(&items).expect("source must compile");
    let mut vm = Vm::new(bc).expect("verified product loads");
    let vm_value = vm.run().expect("vm path runs");
    let vm_r = vm.global("r").cloned();

    // eval path: reader -> expander -> evaluator (the same items).
    let mut ev = Evaluator::new();
    let ev_value = ev.eval_program(&items).expect("eval path runs");
    let ev_r = ev.global("r").cloned();

    // Program values agree (declaration programs are nil on both).
    assert_parity(&vm_value, vm.heap(), &ev_value, ev.heap());
    // The observed global agrees (structure, not addresses).
    let r_repr = match (&vm_r, &ev_r) {
        (Some(a), Some(b)) => Some(assert_parity(a, vm.heap(), b, ev.heap())),
        (None, None) => None,
        mismatch => panic!("global `r` observation diverged: {mismatch:?}"),
    };
    let _ = r_repr;
    match ev_r {
        Some(v) => parity_repr(&v, ev.heap()),
        None => panic!("test programs must define `r`"),
    }
}

/// Both engines reject the same source with the same variant.
fn dual_err(src: &str) -> RuntimeError {
    let items = items_of(src);
    let bc = compile_program(&items).expect("source must compile");
    let mut vm = Vm::new(bc).expect("verified product loads");
    let vm_err = vm.run().expect_err("vm path must reject");
    let mut ev = Evaluator::new();
    let ev_err = ev.eval_program(&items).expect_err("eval path must reject");
    assert_eq!(
        vm_err, ev_err,
        "dual-path error divergence (same source, different failures)"
    );
    vm_err
}

// ---------- positive: the 15-program parity battery ----------

#[test]
fn fifteen_programs_agree_across_eval_and_vm() {
    // 1-2: recursion at two scales (the fib anchor on both engines).
    assert_eq!(
        dual_run(
            "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define r (fib 10))"
        ),
        "55"
    );
    assert_eq!(
        dual_run(
            "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define r (fib 20))"
        ),
        "6765"
    );
    // 3: integer arithmetic mix.
    assert_eq!(dual_run("(define r (+ (* 2 3) (- 10 (/ 8 2))))"), "12");
    // 4: float arithmetic (IEEE on both engines).
    assert_eq!(dual_run("(define r (+ 1.5 2.5))"), "4.0");
    // 5-6: comparison + nested if short-circuit.
    assert_eq!(
        dual_run("(define r (if (< 1 2) (if (>= 3 3) 42 0) 99))"),
        "42"
    );
    assert_eq!(dual_run("(define r (if (= 1 2) 0 (if (> 2 1) 7 8)))"), "7");
    // 7: let* progressive binding.
    assert_eq!(
        dual_run("(define r (let ((a 1) (b (+ a 1)) (c (* b 2))) (+ a (+ b c))))"),
        "7"
    );
    // 8: do desugar + set! stack balance (the assigned value IS the
    // expression value; x rebinding visible after).
    assert_eq!(
        dual_run("(define x 1) (define r (do (set! x 5) (+ x 1)))"),
        "6"
    );
    // 9-10: named closure and anonymous fn application.
    assert_eq!(
        dual_run("(define (add a b) (+ a b)) (define r (add 3 4))"),
        "7"
    );
    assert_eq!(dual_run("(define r ((fn (x) (* x x)) 6))"), "36");
    // 11: cons/car/cdr chain.
    assert_eq!(dual_run("(define r (car (cdr (cons 1 (cons 2 3)))))"), "2");
    // 12: deep nested pair construction (three-deep cons chain).
    assert_eq!(
        dual_run("(define r (cons 1 (cons 2 (cons 3 nil))))"),
        "(1 . (2 . (3 . nil)))"
    );
    // 13: predicate composition (pair?/nil?/not nesting).
    assert_eq!(
        dual_run("(define r (if (pair? (cons 1 2)) (if (not #f) (if (nil? nil) 1 2) 3) 4))"),
        "1"
    );
    // 14: eq? identity semantics (fresh cells are never eq?).
    assert_eq!(
        dual_run("(define r (if (eq? 5 5) (if (eq? (cons 1 2) (cons 1 2)) 1 2) 3))"),
        "2"
    );
    // 15: effects — nearest handler wins; the handler return value
    // is the perform's value.
    assert_eq!(
        dual_run(
            "(define r (handle (handle (perform e 1) (e (fn (v) (+ v 9)))) (e (fn (v) 100))))"
        ),
        "10"
    );
}

#[test]
fn stage0_globals_three_way_parity_is_official() {
    // The 0.7 official assertion (kerf-vm/src/builtin.rs header
    // note): the expander's name table, the VM registry, and the
    // evaluator's seeded globals are one table — name by name.
    let ev = Evaluator::new();
    assert_eq!(STAGE0_GLOBALS.len(), Builtin::ALL.len());
    for (builtin, name, arity) in Builtin::ALL {
        assert!(
            STAGE0_GLOBALS.contains(&name),
            "builtin `{name}` missing from the expander table"
        );
        match ev.global(name) {
            Some(Value::Builtin(seeded)) => {
                assert_eq!(*seeded, builtin, "evaluator seeded `{name}` correctly");
                assert_eq!(seeded.arity(), arity);
            }
            other => panic!("evaluator must seed `{name}`, got {other:?}"),
        }
    }
    // And the expander table has no name the registry lacks.
    for name in STAGE0_GLOBALS {
        assert!(
            Builtin::from_name(name).is_some(),
            "expander global `{name}` has no builtin"
        );
    }
}

#[test]
fn e2e_source_to_value_runs_both_engines_with_io_parity() {
    // The E2E first edition (stage-0-plan §5 row 0.7): source text to
    // value on BOTH engines, with the I/O faces agreeing line by
    // line (write-line order + read-line consumption).
    let src = "(define r (do (write-line \"out1\") (write-line (read-line)) 5))";
    let items = items_of(src);

    // VM with seeded input (the with_io face).
    let bc2 = compile_program(&items_of(src)).expect("compiles");
    let mut vm2 = kerf::vm::Vm::with_io(bc2, Box::new(kerf::vm::BufferIo::with_input(["in1"])))
        .expect("loads");
    let vm_value = vm2.run().expect("vm runs");
    let vm_out = vm2.take_output();
    assert_eq!(vm_value, Value::Nil);
    assert_eq!(vm_out, vec!["out1".to_string(), "in1".to_string()]);

    // Evaluator with the same seeded input.
    let mut ev = Evaluator::with_io(Box::new(kerf::vm::BufferIo::with_input(["in1"])));
    let ev_value = ev.eval_program(&items).expect("eval runs");
    let ev_out = ev.take_output();
    assert_eq!(ev_value, Value::Nil);
    assert_eq!(ev_out, vec!["out1".to_string(), "in1".to_string()]);

    // The observed global agrees (5 on both).
    assert_eq!(vm2.global("r"), Some(&Value::Int(5)));
    assert_eq!(ev.global("r"), Some(&Value::Int(5)));
}

#[test]
fn vm_collect_then_retry_injection_end_to_end() {
    // The §19.4 skeleton on the VM path: a tight budget over a
    // discarding program fails closed WITHOUT a collector and runs
    // THROUGH with MarkSweep injected — same source, same result.
    let src = "(define r (+ (car (cons 1 2)) (+ (car (cons 3 4)) (+ (car (cons 5 6)) (+ (car (cons 7 8)) (+ (car (cons 9 10)) (car (cons 11 12))))))))";
    let items = items_of(src);
    let bc = compile_program(&items).expect("compiles");

    // No collector: the un-reclaimed cells pass the live count.
    let mut plain = Vm::with_budget(bc.clone(), 4).expect("loads");
    match plain.run() {
        Err(RuntimeError::BudgetExceeded { budget, .. }) => assert_eq!(budget, 4),
        other => panic!("expected budget exceeded, got {other:?}"),
    }

    // With MarkSweep: the dead cells return to the free list at the
    // safety point and the run completes with the right value.
    let mut collected = Vm::with_budget_and_collector(bc, 4, Box::new(MarkSweep)).expect("loads");
    collected.run().expect("collect-then-retry completes");
    assert_eq!(collected.global("r"), Some(&Value::Int(36)));

    // Regression: fib(25) under the default budget with a collector
    // injected produces the anchor value (zero semantic interference).
    let fib_src =
        "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define r (fib 25))";
    let bc3 = compile_program(&items_of(fib_src)).expect("compiles");
    let mut vm3 = Vm::with_collector(bc3, Box::new(MarkSweep)).expect("loads");
    vm3.run().expect("fib runs");
    assert_eq!(vm3.global("r"), Some(&Value::Int(75025)));
}

// ---------- negative: dual-path error agreement ----------

#[test]
fn negative_parity_arity_mismatch_on_both_faces() {
    // Closure face (class 5, source-reachable).
    match dual_err("(define (f a) a) (define r (f 1 2))") {
        RuntimeError::ArityMismatch {
            func,
            expected,
            actual,
            ..
        } => {
            assert_eq!((func.as_str(), expected, actual), ("f", 1, 2));
        }
        other => panic!("expected arity mismatch, got {other:?}"),
    }
    // Builtin face (fixed arity — the documented 0.6 semantics).
    match dual_err("(define r (+ 1 2 3))") {
        RuntimeError::ArityMismatch {
            func,
            expected,
            actual,
            ..
        } => {
            assert_eq!((func.as_str(), expected, actual), ("+", 2, 3));
        }
        other => panic!("expected arity mismatch, got {other:?}"),
    }
}

#[test]
fn negative_parity_type_mismatch_family() {
    // truthy condition (class 6).
    match dual_err("(define r (if 1 2 3))") {
        RuntimeError::TypeMismatch { context, got, .. } => {
            assert_eq!((context, got), ("jump-if-false condition", "int"));
        }
        other => panic!("expected type mismatch, got {other:?}"),
    }
    // mixed-kind arithmetic.
    match dual_err("(define r (+ 1 #t))") {
        RuntimeError::TypeMismatch { context, got, .. } => {
            assert_eq!((context, got), ("add operand", "bool"));
        }
        other => panic!("expected type mismatch, got {other:?}"),
    }
    // car of a non-pair.
    match dual_err("(define r (car 5))") {
        RuntimeError::TypeMismatch { context, got, .. } => {
            assert_eq!((context, got), ("car operand", "int"));
        }
        other => panic!("expected type mismatch, got {other:?}"),
    }
    // non-callable callee.
    match dual_err("(define f 5) (define r (f 1))") {
        RuntimeError::TypeMismatch { context, got, .. } => {
            assert_eq!((context, got), ("call callee", "int"));
        }
        other => panic!("expected type mismatch, got {other:?}"),
    }
}

#[test]
fn negative_parity_div_zero_unbound_and_effect() {
    assert!(matches!(
        dual_err("(define r (/ 1 0))"),
        RuntimeError::DivByZero { .. }
    ));
    // Free names are rejected by the EXPANDER (UnboundIdentifier,
    // class 4 since 0.4) — both engines never see them; the runtime
    // UnboundGlobal face stays reachable only through hand-built
    // products (the 0.6 dynamic-order fixture precedent).
    {
        let forms = read_program(FILE, "(define r missing)").expect("reads");
        match expand_program(&forms) {
            Err(kerf::expander::ExpandError::UnboundIdentifier { name, .. }) => {
                assert_eq!(name.as_str(), "missing");
            }
            other => panic!("expected expander rejection, got {other:?}"),
        }
    }
    match dual_err("(define r (perform e 1))") {
        RuntimeError::UnhandledEffect { effect, .. } => assert_eq!(effect.as_str(), "e"),
        other => panic!("expected unhandled effect, got {other:?}"),
    }
    // read-line at end of input (both engines default to empty).
    assert!(matches!(
        dual_err("(define r (read-line))"),
        RuntimeError::Eof { .. }
    ));
}

#[test]
fn negative_parity_basic_closure_free_name_is_unbound_on_both() {
    // The dormant-capture semantics: a closure's free lexical name
    // resolves GLOBALLY on both engines (the 0.5 compiler's basic-
    // closure scope) — so referencing an outer local from inside a
    // closure is UnboundGlobal on BOTH paths, not a divergence.
    match dual_err("(define (outer) (let ((x 5)) (fn (y) (+ x y)))) (define r ((outer) 1))") {
        RuntimeError::UnboundGlobal { name, .. } => assert_eq!(name.as_str(), "x"),
        other => panic!("expected unbound global (dormant capture), got {other:?}"),
    }
}

#[test]
fn eval_depth_cap_is_eval_only_the_vm_stacks_deeper() {
    // The documented asymmetric boundary: the evaluator recurses in
    // Rust (capped at EVAL_DEPTH_LIMIT) while the VM grows heap
    // frames — depth 3000 is a clean run on the VM and a capped
    // error on eval. NOT a parity divergence; a registered boundary.
    let src =
        "(define (countdown n) (if (= n 0) 0 (countdown (- n 1)))) (define r (countdown 3000))";
    let items = items_of(src);
    let bc = compile_program(&items).expect("compiles");
    let mut vm = Vm::new(bc).expect("loads");
    vm.run().expect("the VM stacks frames on the heap");
    assert_eq!(vm.global("r"), Some(&Value::Int(0)));

    let mut ev = Evaluator::new();
    match ev.eval_program(&items) {
        Err(RuntimeError::EvalDepthExceeded { limit, .. }) => {
            assert_eq!(limit, kerf::runtime::EVAL_DEPTH_LIMIT);
        }
        other => panic!("expected depth cap on eval, got {other:?}"),
    }
}

#[test]
fn foreign_roots_protect_host_values_across_explicit_cycles() {
    // §19.4 root class four on the VM face: a registered foreign
    // value survives an explicit cycle while unregistered garbage
    // reclaims. (Uses the MarkSweep standalone face through the
    // mutable-heap + snapshot-roots pair.)
    let src = "(define p (cons 1 2))";
    let items = items_of(src);
    let bc = compile_program(&items).expect("compiles");
    let mut vm = Vm::new(bc).expect("loads");
    vm.run().expect("program runs");
    let keep = vm.global("p").expect("global bound").clone();
    vm.register_foreign_ref(keep.clone());
    // Garbage the collector must take: allocate orphans directly.
    let orphan = vm
        .heap_mut()
        .alloc(kerf::vm::HeapObj::Pair(Value::Int(9), Value::Nil));
    let roots = vm.snapshot_roots();
    let stats = kerf::runtime::collect(vm.heap_mut(), &roots);
    assert_eq!(stats.swept, 1, "the unregistered orphan is reclaimed");
    assert!(vm.heap().get(orphan).is_none());
    match &keep {
        Value::Pair(r) => assert!(vm.heap().get(*r).is_some(), "foreign root survives"),
        other => panic!("pair expected, got {other:?}"),
    }
    assert_eq!(vm.global("p"), Some(&keep), "globals stay intact");
}

#[test]
fn parity_repr_addresses_cannot_fake_agreement() {
    // The detector floor: two programs whose results differ MUST
    // produce different reprs (a detector that cannot fail proves
    // nothing — the self-check at the source level).
    let a = dual_run("(define r (cons 1 2))");
    let b = dual_run("(define r (cons 2 1))");
    assert_ne!(a, b);
    assert_eq!(a, "(1 . 2)");
    assert_eq!(b, "(2 . 1)");
    // Same program, same repr (determinism floor).
    assert_eq!(dual_run("(define r (cons 1 2))"), "(1 . 2)");
}

#[test]
fn deep_pair_data_and_write_line_output_agree() {
    // Deep pair structures and output-order parity (the do chain
    // sequences write-line calls identically on both engines).
    assert_eq!(
        dual_run("(define r (cons (cons 1 (cons 2 nil)) (cons 4 nil)))"),
        "((1 . (2 . nil)) . (4 . nil))"
    );
    let items = items_of("(define r (do (write-line \"a\") (write-line \"b\") 3))");
    let bc = compile_program(&items).expect("compiles");
    let mut vm = Vm::new(bc).expect("loads");
    vm.run().expect("vm runs");
    let mut ev = Evaluator::new();
    ev.eval_program(&items).expect("eval runs");
    let vm_out = vm.take_output();
    let ev_out = ev.take_output();
    assert_eq!(vm_out, ev_out);
    assert_eq!(vm_out, vec!["a".to_string(), "b".to_string()]);
}

#[test]
fn arithmetic_overflow_and_budget_agree_on_both_engines() {
    // Checked overflow (fail-closed on both).
    assert!(matches!(
        dual_err("(define r (+ 9223372036854775807 1))"),
        RuntimeError::ArithmeticOverflow { .. }
    ));
    // Budget exhaustion with a fully-live set (no collector on
    // either engine by default — both fail closed).
    let src = "(define r (cons (cons 1 2) (cons 3 4)))";
    let items = items_of(src);
    let bc = compile_program(&items).expect("compiles");
    let mut vm = Vm::with_budget(bc, 3).expect("loads");
    match vm.run() {
        Err(RuntimeError::BudgetExceeded { .. }) => {}
        other => panic!("expected budget exceeded, got {other:?}"),
    }
    let mut ev = Evaluator::with_budget(3);
    match ev.eval_program(&items) {
        Err(RuntimeError::BudgetExceeded { .. }) => {}
        other => panic!("expected budget exceeded, got {other:?}"),
    }
}

#[test]
fn negative_parity_perform_arity_and_write_line_type() {
    // The handler-call face: performing with the wrong count for the
    // installed handler fails identically on both engines.
    match dual_err("(define r (handle (perform e 1) (e (fn (a b) a))))") {
        RuntimeError::ArityMismatch {
            expected, actual, ..
        } => {
            assert_eq!((expected, actual), (2, 1));
        }
        other => panic!("expected arity mismatch, got {other:?}"),
    }
    // write-line strict-string on both engines.
    match dual_err("(define r (write-line 5))") {
        RuntimeError::TypeMismatch { context, got, .. } => {
            assert_eq!((context, got), ("write-line operand", "int"));
        }
        other => panic!("expected type mismatch, got {other:?}"),
    }
}

#[test]
fn negative_parity_not_and_cdr_reject_wrong_kinds() {
    match dual_err("(define r (not 1))") {
        RuntimeError::TypeMismatch { context, got, .. } => {
            assert_eq!((context, got), ("not operand", "int"));
        }
        other => panic!("expected type mismatch, got {other:?}"),
    }
    match dual_err("(define r (cdr nil))") {
        RuntimeError::TypeMismatch { context, got, .. } => {
            assert_eq!((context, got), ("cdr operand", "nil"));
        }
        other => panic!("expected type mismatch, got {other:?}"),
    }
}

#[test]
fn negative_parity_handler_scope_ends_with_the_form() {
    // After the handle form, the handler is gone on BOTH engines
    // (PopHandler n duality) — a later perform of the same effect
    // fails identically.
    match dual_err(
        "(define h (fn (v) v)) (define r (do (handle (perform e 1) (e h)) (perform e 2)))",
    ) {
        RuntimeError::UnhandledEffect { effect, .. } => assert_eq!(effect.as_str(), "e"),
        other => panic!("expected unhandled effect, got {other:?}"),
    }
}

#[test]
fn negative_parity_errors_carry_r8_messages_on_both_engines() {
    // The rendered messages are part of the parity contract (the
    // 0.12.2 single-source dictionary): both engines produce the
    // exact same rendering for the same failing source.
    let src = "(define (f a) a) (define r (f 1 2))";
    let items = items_of(src);
    let bc = compile_program(&items).expect("compiles");
    let mut vm = Vm::new(bc).expect("loads");
    let vm_msg = vm.run().expect_err("vm rejects").to_string();
    let mut ev = Evaluator::new();
    let ev_msg = ev
        .eval_program(&items)
        .expect_err("eval rejects")
        .to_string();
    assert_eq!(vm_msg, ev_msg, "message parity is exact");
    assert!(vm_msg.starts_with("arity mismatch: `f` expects `1` arguments, got `2`"));
}

#[test]
fn negative_parity_read_line_eof_from_source_on_both() {
    // read-line on empty input fails closed on both engines with the
    // same variant and message.
    let src = "(define r (read-line))";
    let items = items_of(src);
    let bc = compile_program(&items).expect("compiles");
    let mut vm = Vm::new(bc).expect("loads");
    let vm_msg = vm.run().expect_err("vm rejects").to_string();
    let mut ev = Evaluator::new();
    let ev_msg = ev
        .eval_program(&items)
        .expect_err("eval rejects")
        .to_string();
    assert_eq!(vm_msg, ev_msg);
    assert!(vm_msg.starts_with("read-line: end of input"));
}

#[test]
fn float_semantics_agree_nan_and_signed_zero() {
    // IEEE edge semantics on both engines: NaN comparisons are all
    // false (including =), and eq? compares floats bitwise (the
    // eqv?-style identity — +0.0 and -0.0 are distinct).
    assert_eq!(
        dual_run("(define r (if (= (- (/ 1.0 0.0) (/ 1.0 0.0)) 0.0) 1 2))"),
        "2",
        "NaN = is false on both"
    );
    assert_eq!(
        dual_run("(define r (if (< (/ 1.0 0.0) 0.0) 1 2))"),
        "2",
        "inf < 0.0 is false on both"
    );
    // Bitwise float identity: +0.0 is eq? to itself.
    assert_eq!(dual_run("(define r (if (eq? 0.0 0.0) 1 2))"), "1");
}

#[test]
fn vm_budget_error_carries_the_trigger_span_on_both_engines() {
    // The BudgetExceeded payload (budget + span) survives on both
    // engines under the same tight budget — the span is the defining
    // site (eval) or the instruction site (VM); both resolve to a
    // real source span (never DUMMY).
    let src = "(define r (cons (cons 1 2) (cons 3 4)))";
    let items = items_of(src);
    let bc = compile_program(&items).expect("compiles");
    let mut vm = Vm::with_budget(bc, 3).expect("loads");
    match vm.run() {
        Err(RuntimeError::BudgetExceeded { budget, span }) => {
            assert_eq!(budget, 3);
            assert!(span.end >= span.start, "real span, never dummy");
        }
        other => panic!("expected budget exceeded, got {other:?}"),
    }
    let mut ev = Evaluator::with_budget(3);
    match ev.eval_program(&items) {
        Err(RuntimeError::BudgetExceeded { budget, span }) => {
            assert_eq!(budget, 3);
            assert!(span.end >= span.start);
        }
        other => panic!("expected budget exceeded, got {other:?}"),
    }
}

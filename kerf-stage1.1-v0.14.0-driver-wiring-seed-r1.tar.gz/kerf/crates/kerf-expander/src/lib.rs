//! kerf-expander — macro expansion (Layer 3).
//!
//! Charter (docs/stage0.md §19.2): expand SyntaxObject trees into the
//! frozen CoreExpr kernel (SOP §21.12-11 — the nine semantic
//! primitives). The 0.4 slice is the core-form skeleton:
//! - all nine expression forms (`fn` / `if` / `let` / `do` / `set!` /
//!   `perform` / `handle` / application / atoms), with `do` desugared
//!   to a `Let` chain (Begin → Let, docs/stage0.md §6.12.6) and the
//!   declaration face (`define` / `require` / `module` /
//!   `define-syntax`) producing `ModuleItem`s;
//! - the hygiene skeleton: scope-keyed identifier resolution over
//!   colored subtrees (docs/stage0.md §19.2 core invariant 2);
//! - the phase-closure fail-closed rule (§8.9 rule 1, 0.4 slice);
//! - the expansion work budget ([`EXPANSION_LIMIT`]) — structured
//!   depth errors, never stack overflow (§19.2 core invariant 1).
//!
//! Sub-stage 0.9 delivers the macro system itself (§8.10):
//! - the **binder-scopes subset** resolution rule (the 0.4 membership
//!   judgment generalized — Racket's "Binding as Sets of Scopes");
//! - the `syntax-rules` transformer ([`SyntaxRules`]) with the
//!   def-site ∪ use-site scope coloring and generation-incrementing
//!   instantiation (§9.38(b), §8.6);
//! - the structured code value ([`CodeValue`]) — the macro-phase
//!   first-class datum face;
//! - the module loading layer ([`load_program`]) — declaration
//!   graph validation with cycle detection (§7.1.1 class 7);
//! - the `quote` datum literal (the 0.1 `LiteralValue::Pair`
//!   consumption face — plan-0.7 decision 13).
//!
//! Spans are copied from source nodes (desugared nodes reuse the
//! source spans of the same expansion generation; macro-introduced
//! nodes copy the template range at generation+1) — cross-generation
//! joins never occur in this layer (the TD-002 adjudication,
//! plan-0.4.md §4).

mod code;
mod ctx;
mod error;
mod expand;
mod module;
mod transformer;

// Explicit re-export list (SOP §10.1 rule 4 — glob re-exports are forbidden).
pub use code::CodeValue;
pub use ctx::{EXPANSION_LIMIT, ExpandCtx};
pub use error::ExpandError;
pub use expand::{expand, expand_program};
pub use module::{LoadPlan, ModuleError, load_program};
pub use transformer::SyntaxRules;

/// The Stage 0 global function table: the minimal-runtime surface the
/// expander resolves as a flat fallback before reporting an unbound
/// identifier (docs/stage0.md §8.8 — Stage 0 I/O and arithmetic are
/// traditional global functions, not capability-model calls).
///
/// Single source of truth for the *name set*: kerf-runtime asserts
/// parity against this list when the global environment is seeded at
/// plan sub-stage 0.7. The 0.9 module system gives these names proper
/// scope homes (the flat table is the documented 0.4 simplification).
pub const STAGE0_GLOBALS: &[&str] = &[
    // arithmetic and comparison (fib and the §7.1 corpus need these)
    "+",
    "-",
    "*",
    "/",
    "<",
    "<=",
    ">",
    ">=",
    "=",
    // pair and predicate surface (LiteralValue::Pair / Nil carriers)
    "car",
    "cdr",
    "cons",
    "pair?",
    "nil?",
    "eq?",
    "not",
    // minimal I/O (§8.8: read_line / write_line only)
    "read-line",
    "write-line",
];

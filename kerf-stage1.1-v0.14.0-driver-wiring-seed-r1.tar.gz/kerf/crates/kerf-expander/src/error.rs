//! Errors produced by kerf-expander while turning syntax objects into
//! core expressions (docs/stage0.md §19.2 expansion loop).
//!
//! Message shape follows the Rust compiler conventions (SOP §10.5 / R8):
//! lowercase start, no trailing period, payloads in backticks.

use std::error::Error;
use std::fmt;

use kerf_core::CoreError;
use kerf_syntax::{Phase, Span};

/// Errors raised during macro expansion (sub-stage 0.4).
///
/// Every variant carries the byte-precise [`Span`] of the offending
/// syntax node — the diagnostics framework (plan sub-stage 0.8) renders
/// locations from this payload.
#[derive(Debug, Clone, PartialEq)]
pub enum ExpandError {
    /// An identifier resolved to no binding: not in any lexical scope
    /// reachable through its scope set, and not a Stage 0 global.
    /// SOP §7.1.1 error class 2 (unbound identifier).
    UnboundIdentifier { name: String, span: Span },
    /// The expansion work budget was exhausted (SOP §7.1.1 error class
    /// 7 — expansion depth exceeded). The reader's 256 nesting cap
    /// bounds *source* trees; this cap independently bounds expansion
    /// work over any tree, including synthesized and (at 0.9)
    /// macro-produced ones.
    ExpansionDepthExceeded { limit: usize, span: Span },
    /// An empty list datum reached the expander directly (SOP §7.1.1
    /// error class 3, expander detection point). The reader already
    /// rejects `()` in source (plan-0.3 decision 3); this is the second
    /// fail-closed layer for synthesized trees.
    EmptyForm { span: Span },
    /// A syntax object outside the runtime phase was submitted for
    /// runtime expansion (docs/stage0.md §8.9 rule 1 — phase closure;
    /// the 0.4 slice of the phase-separation system).
    PhaseViolation { phase: Phase, span: Span },
    /// A special form was used with an unsupported shape (wrong arity,
    /// non-symbol binding position, malformed binding spec or handler
    /// clause).
    MalformedForm { form: &'static str, span: Span },
    /// A bare expression appeared at module top level. The module top
    /// level accepts declarations only (`define` / `require` /
    /// `module`); the top-level expression channel is the `define`
    /// calling form (r110 corpus note) and the driver/REPL composition
    /// (plan sub-stage 0.8).
    TopLevelExpression { span: Span },
    /// A kerf-core validated constructor rejected a name-bearing node
    /// while the expander re-asserted the semantic floor (duplicate
    /// parameters, duplicate handler clauses, invalid symbol text —
    /// the 0.1 constructor contract applied at expansion time).
    Core { source: CoreError, span: Span },
    /// Every clause of a `syntax-rules` transformer failed to match
    /// the use form (sub-stage 0.9). An unbound macro *head* reports
    /// [`ExpandError::UnboundIdentifier`] instead — the unified
    /// Racket judgment (a head naming nothing is ambiguous between a
    /// function call and a macro use; one error serves both).
    MacroPatternMismatch { name: String, span: Span },
    /// `(quote datum)` received a datum the Stage 0 value model cannot
    /// express: symbols (and lists containing them) have no
    /// `LiteralValue` carrier yet — the fail-closed boundary until the
    /// Stage 1 value model (sub-stage 0.9; the 0.1
    /// `LiteralValue::Pair` consumption face covers atoms and proper
    /// lists only).
    QuoteUnsupportedDatum { span: Span },
}

impl fmt::Display for ExpandError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            ExpandError::UnboundIdentifier { name, span } => {
                write!(
                    f,
                    "unbound identifier `{name}` at {span}: not in any lexical scope and not a Stage 0 global"
                )
            }
            ExpandError::ExpansionDepthExceeded { limit, span } => {
                write!(f, "expansion depth exceeded the limit of {limit} at {span}")
            }
            ExpandError::EmptyForm { span } => {
                write!(
                    f,
                    "empty form cannot be expanded: `()` at {span} carries no operator"
                )
            }
            ExpandError::PhaseViolation { phase, span } => {
                write!(
                    f,
                    "phase violation: `{phase}` syntax at {span} is not runtime-phase code (docs/stage0.md §8.9 rule 1)"
                )
            }
            ExpandError::MalformedForm { form, span } => {
                write!(f, "malformed `{form}` form at {span}")
            }
            ExpandError::TopLevelExpression { span } => {
                write!(
                    f,
                    "top-level expression at {span} is not allowed: only `define`, `require` and `module` declarations are valid at module top level"
                )
            }
            ExpandError::Core { source, span } => {
                write!(f, "core construction failed at {span}: {source}")
            }
            ExpandError::MacroPatternMismatch { name, span } => {
                write!(
                    f,
                    "macro `{name}` matched no clause at {span}: the use form fits none of its syntax-rules patterns"
                )
            }
            ExpandError::QuoteUnsupportedDatum { span } => {
                write!(
                    f,
                    "quote cannot carry this datum at {span}: symbol data has no Stage 0 value model (atoms and proper lists only)"
                )
            }
        }
    }
}

impl Error for ExpandError {
    fn source(&self) -> Option<&(dyn Error + 'static)> {
        match self {
            ExpandError::Core { source, .. } => Some(source),
            _ => None,
        }
    }
}

impl ExpandError {
    /// The byte-precise location of the offending syntax node.
    pub fn span(&self) -> Span {
        match self {
            ExpandError::UnboundIdentifier { span, .. }
            | ExpandError::ExpansionDepthExceeded { span, .. }
            | ExpandError::EmptyForm { span }
            | ExpandError::PhaseViolation { span, .. }
            | ExpandError::MalformedForm { span, .. }
            | ExpandError::TopLevelExpression { span }
            | ExpandError::MacroPatternMismatch { span, .. }
            | ExpandError::QuoteUnsupportedDatum { span }
            | ExpandError::Core { span, .. } => *span,
        }
    }
}

#[cfg(test)]
mod tests {
    //! Unit tests for the ExpandError rendering surface (sub-stage test
    //! doc FP1; R8 message-shape assertions).

    use super::*;
    use kerf_span::{ByteOffset, ExpansionId, FileId};

    fn span(start: u32, end: u32) -> Span {
        Span::new(
            FileId(0),
            ByteOffset(start),
            ByteOffset(end),
            ExpansionId::ROOT,
        )
        .expect("test fixture span must be well-formed")
    }

    // ---------- negative (error surface) ----------

    #[test]
    fn display_unbound_mentions_name_and_location() {
        let err = ExpandError::UnboundIdentifier {
            name: "fib".to_owned(),
            span: span(7, 10),
        };
        let rendered = err.to_string();
        assert!(rendered.starts_with("unbound identifier `fib`"));
        assert!(rendered.contains("#0:7..10"));
        assert!(!rendered.ends_with('.'));
    }

    #[test]
    fn display_depth_mentions_limit() {
        let err = ExpandError::ExpansionDepthExceeded {
            limit: 512,
            span: span(0, 1),
        };
        let rendered = err.to_string();
        assert!(rendered.contains("512"));
        assert!(rendered.starts_with("expansion depth exceeded"));
        assert!(!rendered.ends_with('.'));
    }

    #[test]
    fn display_phase_violation_mentions_phase() {
        let err = ExpandError::PhaseViolation {
            phase: Phase::MacroExpansion,
            span: span(3, 9),
        };
        let rendered = err.to_string();
        assert!(rendered.contains("macro expansion"));
        assert!(rendered.contains("runtime-phase"));
        assert!(rendered.starts_with("phase violation"));
    }

    #[test]
    fn display_malformed_mentions_form_name() {
        let err = ExpandError::MalformedForm {
            form: "let",
            span: span(0, 12),
        };
        let rendered = err.to_string();
        assert!(rendered.contains("`let`"));
        assert!(rendered.starts_with("malformed"));
        assert!(!rendered.ends_with('.'));
    }

    #[test]
    fn display_core_wraps_source_and_keeps_span() {
        let source = CoreError::DuplicateParam {
            name: "x".to_owned(),
        };
        let err = ExpandError::Core {
            source,
            span: span(4, 20),
        };
        let rendered = err.to_string();
        assert!(rendered.contains("duplicate parameter `x`"));
        assert!(rendered.contains("#0:4..20"));
        assert_eq!(err.span(), span(4, 20));
        // Error::source chains to the wrapped CoreError (composition
        // contract — std::error::Error plumbing for the 0.8 renderer).
        assert!(err.source().is_some());
    }

    #[test]
    fn display_pattern_mismatch_mentions_macro_name() {
        let err = ExpandError::MacroPatternMismatch {
            name: "m".to_owned(),
            span: span(0, 9),
        };
        let rendered = err.to_string();
        assert!(rendered.starts_with("macro `m` matched no clause"));
        assert!(rendered.contains("syntax-rules"));
        assert!(!rendered.ends_with('.'));
    }

    #[test]
    fn display_quote_unsupported_mentions_the_boundary() {
        let err = ExpandError::QuoteUnsupportedDatum { span: span(6, 7) };
        let rendered = err.to_string();
        assert!(rendered.starts_with("quote cannot carry this datum"));
        assert!(rendered.contains("symbol data"));
        assert!(!rendered.ends_with('.'));
    }
}

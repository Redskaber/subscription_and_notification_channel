//! ExpandCtx — the expansion environment (scope frames + work budget +
//! the macro registry).
//!
//! The 0.4 hygiene skeleton froze scope-keyed resolution; sub-stage 0.9
//! generalizes the rule to the **binder-scopes subset** judgment
//! (Racket's "Binding as Sets of Scopes"): a frame binds a reference
//! iff the *binding occurrence's* scope set is a subset of the
//! reference's scope set. For non-macro code the two sets coincide
//! (coloring is uniform), so every 0.4 behavior is preserved
//! structurally; for macro-introduced syntax the subset judgment is
//! exactly the hygiene guarantee — an introduced binding carries the
//! def-site scope the spliced arguments lack, and a use-site binding
//! carries its own fresh scope the introduced references lack, so
//! neither can capture the other (docs/stage0.md §19.2 core invariant
//! 2, §9.38(b) scope coloring).
//!
//! The frame also records macro declarations (`define-syntax`): a
//! macro name resolves through the same subset judgment, so macros are
//! lexically scoped like defines (a nested module's macros vanish with
//! its frame — docs/stage0.md §19.2 implementation trap 2: the
//! resolution key includes the scope set).

use std::collections::{HashMap, HashSet};

use kerf_syntax::{ScopeId, ScopeSet};

use crate::STAGE0_GLOBALS;
use crate::error::ExpandError;
use crate::transformer::SyntaxRules;

/// The expansion work budget: the maximum number of nested `expand`
/// calls on one syntax tree.
///
/// The reader's `NESTING_LIMIT = 256` bounds *source* trees; this cap
/// independently bounds expansion work over any tree, including
/// synthesized trees and macro-produced ones — depth over budget is a
/// structured error, never a stack overflow (docs/stage0.md §19.2
/// core invariant 1). The 2× margin over the reader cap absorbs
/// desugar wrapper levels on maximally nested legal source.
pub const EXPANSION_LIMIT: usize = 512;

/// The outcome of scope-keyed identifier resolution.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum Resolution {
    /// Bound by a lexical frame whose binder scopes are a subset of the
    /// identifier's scope set (parameters, let/do bindings,
    /// module-level defines).
    Local,
    /// Bound by the flat Stage 0 global function table (the minimal
    /// runtime surface — kerf-runtime asserts parity at 0.7).
    Global,
    /// No binding anywhere: the fail-closed error case.
    Unbound,
}

/// One lexical frame: the binding occurrence's scope set, the names
/// bound into it, and the macros declared in it. Opaque outside this
/// module (callers only move `Vec<Frame>` for module isolation
/// save/restore).
pub(crate) struct Frame {
    binder_scopes: ScopeSet,
    names: HashSet<String>,
    macros: HashMap<String, usize>,
}

impl Frame {
    fn new(binder_scopes: ScopeSet) -> Self {
        Frame {
            binder_scopes,
            names: HashSet::new(),
            macros: HashMap::new(),
        }
    }
}

/// The expansion environment carried through one `expand_program` or
/// `expand` call tree.
#[derive(Default)]
pub struct ExpandCtx {
    frames: Vec<Frame>,
    transformers: Vec<SyntaxRules>,
    next_scope: u32,
    depth: usize,
}

impl ExpandCtx {
    /// A fresh context: no lexical frames, no registered transformers,
    /// the Stage 0 global table reachable through the flat fallback,
    /// work budget untouched.
    pub fn new() -> Self {
        Self {
            frames: Vec::new(),
            transformers: Vec::new(),
            next_scope: 0,
            depth: 0,
        }
    }

    /// Allocate the next fresh scope (monotonic within one context).
    pub(crate) fn fresh_scope(&mut self) -> ScopeId {
        let scope = ScopeId(self.next_scope);
        self.next_scope += 1;
        scope
    }

    /// Push a lexical frame for `scope` entered from the binding
    /// construct whose form carries `base` scopes: the binding
    /// occurrence's scope set is `base ∪ {scope}` — exactly the scopes
    /// a reference *inside* the construct would carry after coloring.
    pub(crate) fn push_frame(&mut self, scope: ScopeId, base: &ScopeSet) {
        let mut binder_scopes = base.clone();
        binder_scopes.insert(scope);
        self.frames.push(Frame::new(binder_scopes));
    }

    /// Pop the innermost lexical frame.
    pub(crate) fn pop_frame(&mut self) {
        self.frames.pop();
    }

    /// Bind `name` in the innermost frame. Names are inserted
    /// progressively (let* order): a value expression expanded before
    /// this call cannot see this binding.
    pub(crate) fn bind(&mut self, name: &str) {
        if let Some(frame) = self.frames.last_mut() {
            frame.names.insert(name.to_owned());
        }
    }

    /// Resolve `name` against `scopes` (the identifier's own scope
    /// set): the innermost frame whose binder scopes are a subset of
    /// `scopes` and that binds `name` wins; the flat global table is
    /// the fallback before the unbound error.
    pub(crate) fn resolve(&self, name: &str, scopes: &ScopeSet) -> Resolution {
        for frame in self.frames.iter().rev() {
            if frame.names.contains(name) && frame.binder_scopes.is_subset_of(scopes) {
                return Resolution::Local;
            }
        }
        if STAGE0_GLOBALS.contains(&name) {
            return Resolution::Global;
        }
        Resolution::Unbound
    }

    /// Register a parsed transformer; the returned id is the frame
    /// binding slot used by [`Self::bind_macro`].
    pub(crate) fn register_transformer(&mut self, rules: SyntaxRules) -> usize {
        self.transformers.push(rules);
        self.transformers.len() - 1
    }

    /// The registered transformer for `id`.
    pub(crate) fn transformer(&self, id: usize) -> &SyntaxRules {
        &self.transformers[id]
    }

    /// Declare macro `name` in the innermost frame (the `define-syntax`
    /// binding: lexically scoped like a define).
    pub(crate) fn bind_macro(&mut self, name: &str, id: usize) {
        if let Some(frame) = self.frames.last_mut() {
            frame.macros.insert(name.to_owned(), id);
        }
    }

    /// Resolve a macro use through the same subset judgment as
    /// [`Self::resolve`]: the innermost frame whose binder scopes are a
    /// subset of the *use-site head's* scopes and that declares `name`
    /// wins (docs/stage0.md §19.2 trap 2 — the scope set is part of
    /// the lookup key, so the same name at different scopes resolves
    /// to different declarations).
    pub(crate) fn resolve_macro(&self, name: &str, use_scopes: &ScopeSet) -> Option<usize> {
        for frame in self.frames.iter().rev() {
            if let Some(id) = frame.macros.get(name) {
                if frame.binder_scopes.is_subset_of(use_scopes) {
                    return Some(*id);
                }
            }
        }
        None
    }

    /// Enter one expansion level: consumes one unit of the work budget
    /// or fails with [`ExpandError::ExpansionDepthExceeded`].
    pub(crate) fn enter(&mut self, span: kerf_syntax::Span) -> Result<(), ExpandError> {
        if self.depth >= EXPANSION_LIMIT {
            return Err(ExpandError::ExpansionDepthExceeded {
                limit: EXPANSION_LIMIT,
                span,
            });
        }
        self.depth += 1;
        Ok(())
    }

    /// Leave one expansion level (paired with [`Self::enter`]).
    pub(crate) fn exit(&mut self) {
        self.depth = self.depth.saturating_sub(1);
    }

    /// Module isolation (docs/stage0.md §8.9 direction): detach all
    /// lexical frames so nested module items cannot see outer defines
    /// or macros; the caller restores them with
    /// [`Self::restore_frames`].
    pub(crate) fn isolate_frames(&mut self) -> Vec<Frame> {
        std::mem::take(&mut self.frames)
    }

    /// Restore frames detached by [`Self::isolate_frames`].
    pub(crate) fn restore_frames(&mut self, saved: Vec<Frame>) {
        self.frames = saved;
    }
}

#[cfg(test)]
mod tests {
    //! Unit tests for the ExpandCtx resolution, macro registry and
    //! budget machinery (sub-stage test doc FP3).

    use super::*;

    fn scopes_of(ids: &[u32]) -> ScopeSet {
        let mut set = ScopeSet::new();
        for id in ids {
            set.insert(ScopeId(*id));
        }
        set
    }

    // ---------- positive ----------

    #[test]
    fn fresh_scope_is_monotonic() {
        let mut ctx = ExpandCtx::new();
        let a = ctx.fresh_scope();
        let b = ctx.fresh_scope();
        let c = ctx.fresh_scope();
        assert!(a.0 < b.0 && b.0 < c.0, "scope ids must be monotonic");
    }

    #[test]
    fn subset_rule_resolves_colored_references() {
        // Frame entered from a base context; a reference colored with
        // the same scopes resolves (the 0.4 behavior preserved).
        let mut ctx = ExpandCtx::new();
        let scope = ctx.fresh_scope();
        let base = scopes_of(&[7]);
        ctx.push_frame(scope, &base);
        ctx.bind("x");
        let mut ref_scopes = base.clone();
        ref_scopes.insert(scope);
        assert_eq!(ctx.resolve("x", &ref_scopes), Resolution::Local);
        // Flat global fallback for the Stage 0 surface.
        assert_eq!(ctx.resolve("+", &scopes_of(&[])), Resolution::Global);
        ctx.pop_frame();
    }

    #[test]
    fn superset_reference_scopes_still_resolve() {
        // A reference under *more* scopes (nested constructs) still
        // resolves against an outer frame: binder ⊆ ref.
        let mut ctx = ExpandCtx::new();
        let outer = ctx.fresh_scope();
        ctx.push_frame(outer, &scopes_of(&[]));
        ctx.bind("x");
        let inner = ctx.fresh_scope();
        ctx.push_frame(inner, &scopes_of(&[outer.0]));
        ctx.bind("y");
        let ref_scopes = scopes_of(&[outer.0, inner.0]);
        assert_eq!(ctx.resolve("x", &ref_scopes), Resolution::Local);
        assert_eq!(ctx.resolve("y", &ref_scopes), Resolution::Local);
        ctx.pop_frame();
        ctx.pop_frame();
    }

    #[test]
    fn macro_registry_resolves_subset_visible_declarations() {
        let mut ctx = ExpandCtx::new();
        let scope = ctx.fresh_scope();
        ctx.push_frame(scope, &scopes_of(&[]));
        ctx.bind_macro("m", 0);
        let mut use_scopes = scopes_of(&[]);
        use_scopes.insert(scope);
        assert_eq!(ctx.resolve_macro("m", &use_scopes), Some(0));
        ctx.pop_frame();
    }

    // ---------- negative ----------

    #[test]
    fn uncolored_reference_does_not_resolve() {
        let mut ctx = ExpandCtx::new();
        let scope = ctx.fresh_scope();
        ctx.push_frame(scope, &scopes_of(&[]));
        ctx.bind("x");
        // Empty scope set (hand-built tree, never colored): the frame
        // scope is not a member, so the binding is invisible — the
        // scope-keyed rule fails closed instead of matching by name.
        assert_eq!(ctx.resolve("x", &scopes_of(&[])), Resolution::Unbound);
        ctx.pop_frame();
    }

    #[test]
    fn reference_missing_part_of_the_binder_scopes_stays_unbound() {
        // The 0.9 hygiene judgment: a reference that does not carry
        // the *full* binder scope set (e.g. a macro-spliced argument
        // lacking the def-site scope) must not resolve — subset, not
        // membership.
        let mut ctx = ExpandCtx::new();
        let scope = ctx.fresh_scope();
        let base = scopes_of(&[3]);
        ctx.push_frame(scope, &base);
        ctx.bind("x");
        // Reference carries the fresh scope but not the base scope.
        assert_eq!(
            ctx.resolve("x", &scopes_of(&[scope.0])),
            Resolution::Unbound
        );
        ctx.pop_frame();
    }

    #[test]
    fn macro_at_foreign_scope_stays_invisible() {
        let mut ctx = ExpandCtx::new();
        let scope_a = ctx.fresh_scope();
        ctx.push_frame(scope_a, &scopes_of(&[]));
        ctx.bind_macro("m", 0);
        // The use-site head carries a different scope only: the
        // declaration's binder scopes are not a subset — invisible.
        let scope_b = ctx.fresh_scope();
        assert_eq!(ctx.resolve_macro("m", &scopes_of(&[scope_b.0])), None);
        ctx.pop_frame();
    }

    #[test]
    fn popped_frame_binding_is_gone() {
        let mut ctx = ExpandCtx::new();
        let scope = ctx.fresh_scope();
        ctx.push_frame(scope, &scopes_of(&[]));
        ctx.bind("x");
        ctx.pop_frame();
        assert_eq!(
            ctx.resolve("x", &scopes_of(&[scope.0])),
            Resolution::Unbound
        );
    }

    #[test]
    fn unknown_name_is_unbound() {
        let ctx = ExpandCtx::new();
        assert_eq!(ctx.resolve("nope", &scopes_of(&[])), Resolution::Unbound);
    }

    #[test]
    fn stray_exit_does_not_underflow_the_budget() {
        // Saturating discipline: a stray exit below zero must not
        // underflow (and must not silently grant budget).
        let mut ctx = ExpandCtx::new();
        ctx.exit();
        ctx.exit();
        let span = kerf_syntax::Span::root(
            kerf_span::FileId(0),
            kerf_span::ByteOffset(0),
            kerf_span::ByteOffset(1),
        )
        .expect("fixture span");
        // Budget accounting stays intact: the full limit is still
        // consumable, and exhaustion still rejects.
        for _ in 0..EXPANSION_LIMIT {
            ctx.enter(span).expect("budget must stay intact");
        }
        assert!(ctx.enter(span).is_err());
    }

    #[test]
    fn isolate_frames_hides_outer_bindings_and_macros() {
        let mut ctx = ExpandCtx::new();
        let scope = ctx.fresh_scope();
        ctx.push_frame(scope, &scopes_of(&[]));
        ctx.bind("outer");
        ctx.bind_macro("m", 0);
        let mut visible = scopes_of(&[]);
        visible.insert(scope);
        let saved = ctx.isolate_frames();
        assert_eq!(ctx.resolve("outer", &visible), Resolution::Unbound);
        assert_eq!(ctx.resolve_macro("m", &visible), None);
        ctx.restore_frames(saved);
        assert_eq!(ctx.resolve("outer", &visible), Resolution::Local);
        assert_eq!(ctx.resolve_macro("m", &visible), Some(0));
    }

    #[test]
    fn work_budget_rejects_beyond_the_limit() {
        let span = kerf_syntax::Span::root(
            kerf_span::FileId(0),
            kerf_span::ByteOffset(0),
            kerf_span::ByteOffset(1),
        )
        .expect("fixture span");
        let mut ctx = ExpandCtx::new();
        for _ in 0..EXPANSION_LIMIT {
            ctx.enter(span).expect("within budget must pass");
        }
        // One more level: beyond the budget — structured rejection.
        let err = ctx.enter(span).expect_err("over budget must fail");
        assert_eq!(
            err,
            ExpandError::ExpansionDepthExceeded {
                limit: EXPANSION_LIMIT,
                span
            }
        );
        // exit restores the budget (paired accounting).
        ctx.exit();
        ctx.enter(span).expect("exit must release one budget unit");
    }
}

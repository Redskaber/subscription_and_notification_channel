//! kerf-span — source position tracking for the kerf compiler pipeline.
//!
//! Layer 0 crate (SOP §18.5): zero internal dependencies, consumed by every
//! pipeline stage. Design basis: `docs/stage0.md` §8.6 (Span full-pipeline
//! propagation) and §12.1 (byte-offset representation; line/column are
//! derived at diagnostic-render time, never stored).
//!
//! The crate is intentionally dependency-free (no `thiserror`/`anyhow`):
//! external-dependency introduction requires SOP §18 review, and the error
//! surface here is small enough for a manual `std::error::Error` impl.

pub mod span;

// Explicit re-export list (SOP §10.1 rule 4 — glob re-exports are forbidden).
// Convention: cross-stage shared ID types carry no prefix (SOP §10.1 rule 3).
pub use span::{ByteOffset, ExpansionId, FileId, Span, SpanError};

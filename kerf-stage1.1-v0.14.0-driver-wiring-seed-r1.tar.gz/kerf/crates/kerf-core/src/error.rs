//! Errors produced by kerf-core construction and validation.

use std::error::Error;
use std::fmt;

/// Errors raised while building core nodes from source-shaped text
/// (validated constructors — the sub-stage 0.4 expander contract).
///
/// Message shape follows the Rust compiler conventions (SOP §10.5 / R8):
/// lowercase start, no trailing period, payloads in backticks.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum CoreError {
    /// A name failed the [`crate::Symbol`](crate::symbol::Symbol) floor
    /// (empty, whitespace, or control character).
    InvalidSymbol { text: String },
    /// `fn` form binds the same parameter name twice.
    DuplicateParam { name: String },
    /// `handle` installs two clauses for the same effect.
    DuplicateHandler { effect: String },
}

impl fmt::Display for CoreError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            CoreError::InvalidSymbol { text } => {
                write!(
                    f,
                    "invalid symbol `{text}`: must be non-empty with no whitespace or control characters"
                )
            }
            CoreError::DuplicateParam { name } => {
                write!(f, "duplicate parameter `{name}` in fn form")
            }
            CoreError::DuplicateHandler { effect } => {
                write!(f, "duplicate handler clause for effect `{effect}`")
            }
        }
    }
}

impl Error for CoreError {}

#[cfg(test)]
mod tests {
    //! Unit tests for the CoreError rendering surface (sub-stage test doc
    //! FP4; R8 message-shape assertions).

    use super::*;

    // ---------- negative (error surface) ----------

    #[test]
    fn display_invalid_symbol_mentions_text_and_rules() {
        let err = CoreError::InvalidSymbol {
            text: "a b".to_owned(),
        };
        let rendered = err.to_string();
        assert!(rendered.contains("`a b`"));
        assert!(rendered.contains("non-empty"));
        assert!(rendered.contains("whitespace"));
        assert!(!rendered.ends_with('.'));
    }

    #[test]
    fn display_duplicate_param_mentions_name() {
        let err = CoreError::DuplicateParam {
            name: "x".to_owned(),
        };
        let rendered = err.to_string();
        assert!(rendered.contains("`x`"));
        assert!(rendered.contains("fn"));
        assert_eq!(rendered.chars().next().unwrap(), 'd');
    }

    #[test]
    fn display_duplicate_handler_mentions_effect() {
        let err = CoreError::DuplicateHandler {
            effect: "read".to_owned(),
        };
        let rendered = err.to_string();
        assert!(rendered.contains("`read`"));
        assert!(rendered.contains("handler"));
    }

    #[test]
    fn error_variants_distinguishable_by_equality() {
        let a = CoreError::InvalidSymbol {
            text: "x".to_owned(),
        };
        let b = CoreError::DuplicateParam {
            name: "x".to_owned(),
        };
        let c = CoreError::DuplicateHandler {
            effect: "x".to_owned(),
        };
        assert_ne!(a, b);
        assert_ne!(b, c);
        assert_ne!(a, c);
        // Same variant with same payload compares equal (test assertions
        // rely on this).
        assert_eq!(
            a,
            CoreError::InvalidSymbol {
                text: "x".to_owned()
            }
        );
    }
}

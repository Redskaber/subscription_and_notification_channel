//! Identifier symbol: validated, opaque, cheap to compare.

use std::fmt;

use crate::error::CoreError;

/// An identifier name inside a `CoreExpr` node (parameter, variable,
/// effect, module item, ...).
///
/// The payload is private on purpose (docs/stage0.md §7.4.2 principle 1 —
/// type safety over naming safety): the only construction path is the
/// checked [`Symbol::new`], so a `Symbol` found inside a node is always
/// structurally valid.
///
/// Validation is a conservative floor, not a grammar: non-empty, no
/// whitespace, no control characters. The full identifier grammar lands
/// with the reader (plan sub-stage 0.3); anything the reader accepts must
/// pass this floor, and the floor deliberately keeps non-ASCII (e.g. CJK)
/// names legal so the future grammar is not constrained.
#[derive(Debug, Clone, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct Symbol {
    text: String,
}

impl Symbol {
    /// Checked constructor.
    ///
    /// Rejects empty text and any character that is whitespace or a
    /// control character. Returns [`CoreError::InvalidSymbol`] on
    /// rejection.
    pub fn new(text: &str) -> Result<Self, CoreError> {
        if text.is_empty() {
            return Err(CoreError::InvalidSymbol {
                text: text.to_owned(),
            });
        }
        if text.chars().any(|c| c.is_whitespace() || c.is_control()) {
            return Err(CoreError::InvalidSymbol {
                text: text.to_owned(),
            });
        }
        Ok(Self {
            text: text.to_owned(),
        })
    }

    /// The identifier text (guaranteed valid by construction).
    pub fn as_str(&self) -> &str {
        &self.text
    }
}

impl fmt::Display for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.text)
    }
}

#[cfg(test)]
mod tests {
    //! Unit tests for the Symbol feature point; ratio mirrors the sub-stage
    //! test doc (docs/tests/v0/stage0/plan/core.md, FP1).
    //! CJK fixture note (SOP §10.5 registered whitelist): the
    //! `valid_symbols_accept_unicode_cjk` case uses CJK *as the tested
    //! object* (identifier floor acceptance), which is the sanctioned
    //! fixture category.

    use super::*;

    // ---------- positive ----------

    #[test]
    fn valid_symbols_roundtrip() {
        for text in ["x", "snake_case_x1", "+", "x!", "?value", "a1b2"] {
            let symbol = Symbol::new(text).expect("floor-valid name must construct");
            assert_eq!(symbol.as_str(), text);
            assert_eq!(symbol.to_string(), text);
        }
    }

    #[test]
    fn valid_symbols_accept_unicode_cjk() {
        // The floor must not constrain the future reader grammar: CJK
        // identifiers stay legal until the 0.3 grammar rules on them.
        let symbol = Symbol::new("计数器").expect("CJK identifier passes the floor");
        assert_eq!(symbol.as_str(), "计数器");
    }

    #[test]
    fn symbol_equality_and_hash_follow_text() {
        use std::collections::hash_map::DefaultHasher;
        use std::hash::{Hash, Hasher};

        let a = Symbol::new("alpha").unwrap();
        let b = Symbol::new("alpha").unwrap();
        let c = Symbol::new("beta").unwrap();
        assert_eq!(a, b);
        assert_ne!(a, c);

        let hash = |s: &Symbol| {
            let mut hasher = DefaultHasher::new();
            s.hash(&mut hasher);
            hasher.finish()
        };
        assert_eq!(hash(&a), hash(&b));
    }

    // ---------- negative ----------

    #[test]
    fn new_rejects_empty() {
        let err = Symbol::new("").expect_err("empty symbol must be rejected");
        assert_eq!(
            err,
            CoreError::InvalidSymbol {
                text: String::new()
            }
        );
    }

    #[test]
    fn new_rejects_space_only() {
        assert!(matches!(
            Symbol::new(" "),
            Err(CoreError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn new_rejects_interior_space() {
        assert!(matches!(
            Symbol::new("a b"),
            Err(CoreError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn new_rejects_interior_tab() {
        assert!(matches!(
            Symbol::new("a\tb"),
            Err(CoreError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn new_rejects_interior_newline() {
        assert!(matches!(
            Symbol::new("a\nb"),
            Err(CoreError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn new_rejects_interior_carriage_return() {
        assert!(matches!(
            Symbol::new("a\rb"),
            Err(CoreError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn new_rejects_unicode_em_space() {
        // `char::is_whitespace` is Unicode-aware: U+2003 counts.
        assert!(matches!(
            Symbol::new("a\u{2003}b"),
            Err(CoreError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn new_rejects_leading_space() {
        assert!(matches!(
            Symbol::new(" x"),
            Err(CoreError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn new_rejects_nul_control_char() {
        assert!(matches!(
            Symbol::new("a\u{0}b"),
            Err(CoreError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn invalid_symbol_error_shape() {
        // R8 message conventions: lowercase start, no trailing period,
        // non-empty, backticks around the payload.
        let err = Symbol::new("a b").expect_err("invalid symbol must error");
        let rendered = err.to_string();
        assert!(!rendered.is_empty());
        assert_eq!(rendered.chars().next().unwrap(), 'i');
        assert!(!rendered.ends_with('.'));
        assert!(rendered.contains("`a b`"));
    }
}

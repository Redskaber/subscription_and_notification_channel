//! kerf-vm public-API tests (SOP §9.1 rule 5 — the crate face a
//! consumer sees). Layer discipline: this file exercises the VM
//! through its declared dependencies only (kerf-compiler — §18.5
//! L5->L6; kerf-core as a dev-dependency for CoreExpr fixture
//! construction, mirroring the 0.5 kerf-span dev-dep precedent);
//! source-level pipelines live in the root integration tree
//! (tests/v0/stage0/plan/vm_seed_tests.rs).

use kerf_compiler::{
    ByteOffset, Bytecode, CompileError, ExpansionId, FileId, FuncProto, Instr, LiteralValue,
    Opcode, Span, Symbol, compile,
};
use kerf_core::CoreExpr;
use kerf_vm::{BufferIo, RuntimeError, Value, Vm};

fn fix_span() -> Span {
    Span::new(FileId(0), ByteOffset(0), ByteOffset(8), ExpansionId::ROOT)
        .expect("test fixture span must be well-formed")
}

fn literal(value: LiteralValue) -> CoreExpr {
    CoreExpr::Literal {
        span: fix_span(),
        value,
    }
}

fn var(name: &str) -> CoreExpr {
    CoreExpr::var(fix_span(), name).expect("fixture var must be well-formed")
}

fn apply(func: CoreExpr, args: Vec<CoreExpr>) -> CoreExpr {
    CoreExpr::Apply {
        span: fix_span(),
        func: Box::new(func),
        args,
    }
}

fn entry_of(code: Vec<Instr>, globals: Vec<Symbol>) -> Bytecode {
    let mut proto = FuncProto::new(None, 0, 0);
    proto.code = code;
    proto.debug_info = vec![fix_span(); proto.code.len()];
    let mut bc = Bytecode::default();
    bc.funcs.push(proto);
    bc.globals = globals;
    bc
}

#[test]
fn vm_new_verifies_and_seeds_the_global_table() {
    // Hand-built product exercising the seeding face: the builtin
    // name binds at load, the plain name stays unbound until its
    // store-global runs.
    let bc = entry_of(
        vec![Instr::new(Opcode::Halt)],
        vec![Symbol::new("+").unwrap(), Symbol::new("r").unwrap()],
    );
    let vm = Vm::new(bc).expect("verified product loads");
    assert_eq!(vm.global("+").map(|v| v.kind_name()), Some("builtin"));
    assert!(vm.global("r").is_none());
    assert!(vm.global("missing").is_none());
    assert_eq!(vm.budget(), kerf_vm::DEFAULT_BUDGET);
    assert_eq!(vm.allocations(), 0);
}

#[test]
fn io_round_trip_seeds_input_and_records_output() {
    // write-line is strict-string (nil result), read-line pulls one
    // seeded line; the result lands in the global table.
    let mut bc = entry_of(
        vec![
            Instr::with_a(Opcode::PushConst, 0),
            Instr::with_a(Opcode::LoadGlobal, 0),
            Instr::with_a(Opcode::Call, 1),
            Instr::new(Opcode::Pop),
            Instr::with_a(Opcode::LoadGlobal, 1),
            Instr::with_a(Opcode::Call, 0),
            Instr::with_a(Opcode::StoreGlobal, 2),
            Instr::new(Opcode::Halt),
        ],
        vec![
            Symbol::new("write-line").unwrap(),
            Symbol::new("read-line").unwrap(),
            Symbol::new("r").unwrap(),
        ],
    );
    bc.consts.push(LiteralValue::String("hello".into()));
    let mut vm =
        Vm::with_io(bc, Box::new(BufferIo::with_input(["world"]))).expect("verified product loads");
    assert_eq!(vm.run().expect("program runs"), Value::Nil);
    assert_eq!(vm.global("r"), Some(&Value::Str("world".into())));
    assert_eq!(vm.take_output(), vec!["hello".to_string()]);
}

#[test]
fn vm_new_rejects_a_tampered_product() {
    // The plan-0.5 ruling-4 second line of defense: a corrupted
    // product fails at load, never reaching the interpreter.
    let expr = literal(LiteralValue::Int(1));
    let mut bc = compile(&expr).expect("fixture compiles");
    bc.funcs[0].code[0] = Instr::with_a(Opcode::Jump, 99);
    match Vm::new(bc) {
        Err(CompileError::JumpTargetOutOfRange { .. }) => {}
        Err(other) => panic!("expected jump-target rejection, got {other:?}"),
        Ok(_) => panic!("expected the verify hook to reject, but the product loaded"),
    }
}

#[test]
fn write_line_rejects_non_string_operands() {
    let expr = apply(var("write-line"), vec![literal(LiteralValue::Int(42))]);
    let bc = compile(&expr).expect("fixture compiles");
    let mut vm = Vm::new(bc).expect("verified product loads");
    match vm.run() {
        Err(RuntimeError::TypeMismatch { got, context, .. }) => {
            assert_eq!((got, context), ("int", "write-line operand"));
        }
        other => panic!("expected type mismatch, got {other:?}"),
    }
}

#[test]
fn read_line_reports_end_of_input() {
    let bc = compile(&apply(var("read-line"), vec![])).expect("fixture compiles");
    let mut vm = Vm::new(bc).expect("verified product loads");
    match vm.run() {
        Err(RuntimeError::Eof { .. }) => {}
        other => panic!("expected eof, got {other:?}"),
    }
}

#[test]
fn perform_without_a_handler_is_unhandled() {
    let expr = CoreExpr::perform(fix_span(), "log", vec![literal(LiteralValue::Int(1))])
        .expect("fixture perform must be well-formed");
    let bc = compile(&expr).expect("fixture compiles");
    let mut vm = Vm::new(bc).expect("verified product loads");
    match vm.run() {
        Err(RuntimeError::UnhandledEffect { effect, .. }) => {
            assert_eq!(effect.as_str(), "log");
        }
        other => panic!("expected unhandled effect, got {other:?}"),
    }
}

#[test]
fn integer_division_by_zero_fails_closed() {
    let expr = apply(
        var("/"),
        vec![literal(LiteralValue::Int(1)), literal(LiteralValue::Int(0))],
    );
    let bc = compile(&expr).expect("fixture compiles");
    let mut vm = Vm::new(bc).expect("verified product loads");
    match vm.run() {
        Err(RuntimeError::DivByZero { .. }) => {}
        other => panic!("expected division by zero, got {other:?}"),
    }
}

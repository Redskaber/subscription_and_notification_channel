//! API-face tests: the public surface of kerf-typecheck (FP1/FP2
//! through the crate boundary — every re-export reachable, every
//! constructor exercised from outside).

use kerf_span::{ByteOffset, ExpansionId, FileId};
use kerf_typecheck::{Externals, Severity, TypeCode, TypeDiagnostic, check_module};

fn sp(a: u32, b: u32) -> kerf_span::Span {
    kerf_span::Span::new(FileId(0), ByteOffset(a), ByteOffset(b), ExpansionId::ROOT)
        .expect("test span is ordered")
}

fn define(name: &str, value: kerf_core::CoreExpr) -> kerf_core::ModuleItem {
    kerf_core::ModuleItem::define(sp(0, 10), name, value).expect("valid define")
}

fn var(name: &str) -> kerf_core::CoreExpr {
    kerf_core::CoreExpr::var(sp(1, 4), name).expect("valid name")
}

fn int(v: i64) -> kerf_core::CoreExpr {
    kerf_core::CoreExpr::Literal {
        span: sp(1, 3),
        value: kerf_core::LiteralValue::Int(v),
    }
}

#[test]
fn api_all_five_reexports_are_reachable() {
    // TypeCode + Severity + TypeDiagnostic + Externals + check_module:
    // the full explicit re-export list, each named from outside.
    let code = TypeCode::UnboundVariable;
    let severity = Severity::Error;
    let _diag = TypeDiagnostic::new(code, severity, sp(0, 1), "x".to_owned());
    let _ext = Externals::empty();
    let _ = check_module(&[], &_ext);
}

#[test]
fn api_check_module_on_empty_program_yields_empty() {
    let diags = check_module(&[], &Externals::empty());
    assert!(diags.is_empty());
}

#[test]
fn api_check_module_reports_with_full_diagnostic_shape() {
    let items = [define("x", var("missing"))];
    let diags = check_module(&items, &Externals::empty());
    assert_eq!(diags.len(), 1);
    let d = &diags[0];
    assert_eq!(d.code, TypeCode::UnboundVariable);
    assert_eq!(d.code.as_str(), "E0001");
    assert_eq!(d.severity, Severity::Error);
    assert_eq!(d.span, sp(1, 4));
    assert_eq!(d.message, "unbound variable `missing`");
}

#[test]
fn api_warning_severity_is_distinct_from_error() {
    let assign = kerf_core::CoreExpr::assign(sp(4, 6), "nowhere", int(1)).expect("valid");
    let items = [define("x", assign)];
    let diags = check_module(&items, &Externals::empty());
    assert_eq!(diags.len(), 1);
    assert_eq!(diags[0].severity, Severity::Warning);
    assert_ne!(diags[0].severity, Severity::Error);
}

#[test]
fn api_externals_constructors_from_outside() {
    let named = Externals::from_names(["a", "b"]);
    assert_eq!(named.resolve("a"), Some(None));
    let arities = Externals::from_named_arities([("+", Some(2))]);
    assert_eq!(arities.resolve("+"), Some(Some(2)));
    assert!(Externals::empty().is_empty());
}

#[test]
fn api_error_and_warning_coexist_in_one_collection() {
    // One definite error + one warning in a single program — the
    // multi-error collection carries both severities.
    let items = [
        define("x", var("missing")),
        define(
            "y",
            kerf_core::CoreExpr::assign(sp(4, 6), "also-missing", int(1)).expect("valid"),
        ),
    ];
    let diags = check_module(&items, &Externals::empty());
    let severities: Vec<Severity> = diags.iter().map(|d| d.severity).collect();
    assert_eq!(severities, vec![Severity::Error, Severity::Warning]);
}

#[test]
fn api_all_eight_codes_surface_through_the_checker() {
    // One program per code (compressed): each registry code is
    // producible through the public entry point.
    let ext = Externals::from_named_arities([("car", Some(1))]);

    // E0001
    let d = check_module(&[define("x", var("m"))], &ext);
    assert_eq!(d[0].code.as_str(), "E0001");

    // E0002 (IIFE mismatch)
    let f = kerf_core::CoreExpr::fn_(sp(2, 8), &["a", "b"], var("a")).expect("valid");
    let call = kerf_core::CoreExpr::Apply {
        span: sp(2, 9),
        func: Box::new(f),
        args: vec![int(1)],
    };
    let d = check_module(&[define("x", call)], &ext);
    assert_eq!(d[0].code.as_str(), "E0002");

    // E0003
    let cond = kerf_core::CoreExpr::If {
        span: sp(2, 9),
        cond: Box::new(int(1)),
        then_branch: Box::new(int(2)),
        else_branch: Box::new(int(3)),
    };
    let d = check_module(&[define("x", cond)], &ext);
    assert_eq!(d[0].code.as_str(), "E0003");

    // E0004
    let call = kerf_core::CoreExpr::Apply {
        span: sp(2, 9),
        func: Box::new(int(1)),
        args: vec![int(2)],
    };
    let d = check_module(&[define("x", call)], &ext);
    assert_eq!(d[0].code.as_str(), "E0004");

    // E0005
    let perform = kerf_core::CoreExpr::perform(sp(5, 8), "e", vec![]).expect("valid");
    let handler = kerf_core::CoreExpr::fn_(sp(6, 7), &["a", "b"], var("a")).expect("valid");
    let clause = kerf_core::HandlerClause::new(sp(6, 7), "e", handler).expect("valid");
    let handle = kerf_core::CoreExpr::handle(sp(4, 9), perform, vec![clause]).expect("valid");
    let d = check_module(&[define("x", handle)], &ext);
    assert_eq!(d[0].code.as_str(), "E0005");

    // E0006
    let perform = kerf_core::CoreExpr::perform(sp(5, 8), "e", vec![]).expect("valid");
    let d = check_module(&[define("x", perform)], &ext);
    assert_eq!(d[0].code.as_str(), "E0006");

    // E0007
    let perform = kerf_core::CoreExpr::perform(sp(5, 8), "e", vec![]).expect("valid");
    let clause = kerf_core::HandlerClause::new(sp(6, 7), "e", int(1)).expect("valid");
    let handle = kerf_core::CoreExpr::handle(sp(4, 9), perform, vec![clause]).expect("valid");
    let d = check_module(&[define("x", handle)], &ext);
    assert_eq!(d[0].code.as_str(), "E0007");

    // E0008
    let assign = kerf_core::CoreExpr::assign(sp(4, 6), "m", int(1)).expect("valid");
    let d = check_module(&[define("x", assign)], &ext);
    assert_eq!(d[0].code.as_str(), "E0008");
}

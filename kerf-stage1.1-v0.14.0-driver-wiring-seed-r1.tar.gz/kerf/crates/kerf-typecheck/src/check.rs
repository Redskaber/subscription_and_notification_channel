//! The conservative static checker — rules R1-R8 (stage-1-plan §3).
//!
//! Soundness discipline: every rule reports only *definite* errors —
//! the soundness argument sits next to each rule. Two mirrors keep
//! resolution honest:
//!
//! * the compiler's order (locals-then-globals — `compile.rs`
//!   `lookup_local` -> `intern_global`), so the checker resolves the
//!   name the compiler resolves;
//! * the expander's sequential discipline (define-so-far with the
//!   letrec pre-bind — `expand.rs` `ctx.bind` before value
//!   expansion), so visibility matches the expansion-time truth.
//!
//! Position-aware visibility (the R1 core subtlety):
//!
//! * a *top-level immediate* position (a define value not under any
//!   `Fn`) executes during module load in order — it may only see the
//!   defines bound so far (its own name included, letrec pre-bind);
//! * an `Fn` body executes at call time, after module load — it may
//!   see every module define (forward references are legal).
//!
//! Effect rules (R5-R7) apply only to top-level immediate performs:
//! a perform inside an `Fn` runs at call time where *dynamic*
//! handlers may be installed (`(define f (fn () (perform e)))`
//! called under a `handle` is well-formed), so lexical routing there
//! would be unsound. At module top level no dynamic context exists —
//! the lexically enclosing `Handle` clauses are the only possible
//! routers, which makes R5-R7 definite.
//!
//! The `Handle` walk mirrors the compilation order (compile.rs):
//! handler values evaluate *before* their own clauses install (walked
//! on the outer stack), then the clauses are active for the body,
//! then popped (`PopHandler n`).

use std::collections::HashSet;

use kerf_core::{CoreExpr, HandlerClause, LiteralValue, ModuleItem, Symbol};
use kerf_span::Span;

use crate::code::{Severity, TypeCode, TypeDiagnostic};
use crate::env::Externals;

/// Check one expanded program, collecting *every* diagnostic found
/// (multi-error collection is the architecture — ruling 21: it never
/// stops at the first error).
pub fn check_module(items: &[ModuleItem], externals: &Externals) -> Vec<TypeDiagnostic> {
    let table = collect_table(items);
    let mut checker = Checker {
        table: &table,
        externals,
        defined_so_far: 0,
        diagnostics: Vec::new(),
    };
    checker.walk_items(items);
    checker.diagnostics
}

// ---------- pass 1: the module table ----------

/// What pass 1 knows about one `define`d name.
#[derive(Debug, Clone, PartialEq, Eq)]
enum DefineShape {
    /// Bound to an `Fn` with a fixed parameter count.
    Fn(u32),
    /// Bound to a literal of this kind (never callable).
    Literal(&'static str),
    /// Bound to anything else (shape unknown at the table level).
    Other,
}

/// The pre-collected module summary: every define (in walk order) and
/// every name assigned anywhere (the R2 over-approximation guard: a
/// global that is assigned somewhere may be rebound to a different
/// shape, so its static callee shape is unusable — skipping is the
/// conservative direction).
struct Table {
    defines: Vec<(String, DefineShape)>,
    assigned: HashSet<String>,
}

fn collect_table(items: &[ModuleItem]) -> Table {
    let mut table = Table {
        defines: Vec::new(),
        assigned: HashSet::new(),
    };
    collect_items(items, &mut table);
    table
}

fn collect_items(items: &[ModuleItem], table: &mut Table) {
    for item in items {
        match item {
            ModuleItem::Define { name, value, .. } => {
                let shape = match value {
                    CoreExpr::Fn { params, .. } => DefineShape::Fn(params.len() as u32),
                    CoreExpr::Literal { value, .. } => DefineShape::Literal(value.kind_name()),
                    _ => DefineShape::Other,
                };
                table.defines.push((name.as_str().to_owned(), shape));
                collect_expr(value, table);
            }
            ModuleItem::Module { items, .. } => collect_items(items, table),
            // Zero code (compile.rs): no expression payload to walk.
            ModuleItem::Require { .. } | ModuleItem::DefineSyntax { .. } => {}
        }
    }
}

fn collect_expr(expr: &CoreExpr, table: &mut Table) {
    match expr {
        CoreExpr::Assign { name, value, .. } => {
            table.assigned.insert(name.as_str().to_owned());
            collect_expr(value, table);
        }
        CoreExpr::Fn { body, .. } => collect_expr(body, table),
        CoreExpr::Apply { func, args, .. } => {
            collect_expr(func, table);
            for arg in args {
                collect_expr(arg, table);
            }
        }
        CoreExpr::If {
            cond,
            then_branch,
            else_branch,
            ..
        } => {
            collect_expr(cond, table);
            collect_expr(then_branch, table);
            collect_expr(else_branch, table);
        }
        CoreExpr::Let { bindings, body, .. } => {
            for binding in bindings {
                collect_expr(&binding.value, table);
            }
            collect_expr(body, table);
        }
        CoreExpr::Perform { args, .. } => {
            for arg in args {
                collect_expr(arg, table);
            }
        }
        CoreExpr::Handle { body, handlers, .. } => {
            collect_expr(body, table);
            for clause in handlers {
                collect_expr(&clause.handler, table);
            }
        }
        CoreExpr::Var { .. } | CoreExpr::Literal { .. } => {}
    }
}

// ---------- pass 2: the walk ----------

/// What the callee analysis knows about one application target.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Callee {
    /// A fixed parameter count (definite when reached).
    Arity(u32),
    /// Definitely not callable (a literal of this kind).
    NonCallable(&'static str),
    /// Unknown — skip (the conservative direction).
    Unknown,
}

struct Checker<'a> {
    table: &'a Table,
    externals: &'a Externals,
    /// How many defines pass 2 has walked so far (same order as pass
    /// 1, so `defines[..defined_so_far]` are the visible ones at a
    /// top-level immediate position).
    defined_so_far: usize,
    diagnostics: Vec<TypeDiagnostic>,
}

impl<'a> Checker<'a> {
    fn report(&mut self, code: TypeCode, severity: Severity, span: Span, message: String) {
        self.diagnostics
            .push(TypeDiagnostic::new(code, severity, span, message));
    }

    fn walk_items(&mut self, items: &'a [ModuleItem]) {
        for item in items {
            match item {
                ModuleItem::Define { value, .. } => {
                    // letrec pre-bind mirror (expand.rs ctx.bind-first):
                    // the name is visible while checking its own value.
                    self.defined_so_far += 1;
                    let mut locals = Vec::new();
                    let mut handlers = Vec::new();
                    self.expr(value, &mut locals, false, &mut handlers);
                }
                ModuleItem::Module { items, .. } => self.walk_items(items),
                // Zero-code declarations (compile.rs): nothing to check.
                ModuleItem::Require { .. } | ModuleItem::DefineSyntax { .. } => {}
            }
        }
    }

    /// Resolve a name to a define shape, position-aware.
    ///
    /// Top level (immediate): only `defines[..defined_so_far]` are
    /// visible. Inside an `Fn`: every define is visible (call time is
    /// post-load). Nearest binding wins (reverse scan — the same
    /// last-wins order as the global store overwrite).
    fn resolve_define(&self, name: &Symbol, in_fn: bool) -> Option<&'a DefineShape> {
        let visible = if in_fn {
            &self.table.defines[..]
        } else {
            &self.table.defines[..self.defined_so_far]
        };
        visible
            .iter()
            .rev()
            .find(|(n, _)| n == name.as_str())
            .map(|(_, shape)| shape)
    }

    /// Whether any define (any position) binds this name.
    fn is_any_define(&self, name: &Symbol) -> bool {
        self.table.defines.iter().any(|(n, _)| n == name.as_str())
    }

    /// The callee analysis for R2/R4 (stage-1-plan §3): definite
    /// arity, definite non-callability, or unknown.
    fn resolve_callee<'b>(
        &self,
        func: &'b CoreExpr,
        locals: &[Symbol],
        in_fn: bool,
    ) -> (Callee, Option<&'b str>) {
        match func {
            // R2a — IIFE: the closure is right here, 100% definite.
            CoreExpr::Fn { params, .. } => (Callee::Arity(params.len() as u32), None),
            // R4 — a literal callee is never callable.
            CoreExpr::Literal { value, .. } => (Callee::NonCallable(value.kind_name()), None),
            CoreExpr::Var { name, .. } => {
                // Lexical shadowing: a local of this name wins over any
                // global — its shape is unknown (conservative skip).
                if locals.iter().any(|l| l == name) {
                    return (Callee::Unknown, None);
                }
                // Assign guard (over-approximation): any assignment to
                // this name anywhere may rebind it — skip.
                if self.table.assigned.contains(name.as_str()) {
                    return (Callee::Unknown, None);
                }
                match self.resolve_define(name, in_fn) {
                    Some(DefineShape::Fn(n)) => (Callee::Arity(*n), Some(name.as_str())),
                    Some(DefineShape::Literal(kind)) => {
                        (Callee::NonCallable(kind), Some(name.as_str()))
                    }
                    _ => match self.externals.resolve(name.as_str()) {
                        // R2c — a builtin with a known arity.
                        Some(Some(n)) => (Callee::Arity(n), Some(name.as_str())),
                        _ => (Callee::Unknown, None),
                    },
                }
            }
            _ => (Callee::Unknown, None),
        }
    }

    fn expr(
        &mut self,
        expr: &'a CoreExpr,
        locals: &mut Vec<Symbol>,
        in_fn: bool,
        handlers: &mut Vec<&'a [HandlerClause]>,
    ) {
        match expr {
            // R1 — unbound reference (structural re-assertion).
            //
            // Soundness: resolution order mirrors the compiler's
            // (locals -> global interning), and an unresolved global
            // load is a definite runtime error on both engines
            // (`RuntimeError::UnboundGlobal`). Visibility is
            // position-aware (module docs): so-far at top level, all
            // defines inside an Fn (call time is post-load).
            CoreExpr::Var { span, name } => {
                if locals.iter().any(|l| l == name) {
                    return;
                }
                let bound = self.resolve_define(name, in_fn).is_some()
                    || self.externals.resolve(name.as_str()).is_some();
                if !bound {
                    self.report(
                        TypeCode::UnboundVariable,
                        Severity::Error,
                        *span,
                        format!("unbound variable `{name}`"),
                    );
                }
            }
            // A fresh lexical frame — mirrors `begin_closure`: the
            // body sees its own params and lets only, never the
            // enclosing function's locals (free names go to globals).
            CoreExpr::Fn { params, body, .. } => {
                let mut inner: Vec<Symbol> = params.clone();
                let mut inner_handlers = Vec::new();
                self.expr(body, &mut inner, true, &mut inner_handlers);
            }
            CoreExpr::Apply { span, func, args } => {
                // R2/R4 — callee analysis (soundness: the callee shape
                // is definite under the assign guard; VM `invoke`
                // enforces closure arity and callee callability).
                let (callee, name) = self.resolve_callee(func, locals, in_fn);
                let actual = args.len() as u32;
                match callee {
                    Callee::Arity(expected) if expected != actual => {
                        let message = match name {
                            Some(n) => format!(
                                "arity mismatch: `{n}` expects `{expected}` arguments, got `{actual}`"
                            ),
                            None => format!(
                                "arity mismatch: function expects `{expected}` arguments, got `{actual}`"
                            ),
                        };
                        self.report(TypeCode::ArityMismatch, Severity::Error, *span, message);
                    }
                    Callee::NonCallable(kind) => {
                        let message = match name {
                            Some(n) => {
                                format!("cannot call `{n}`: defined as a literal `{kind}` value")
                            }
                            None => format!("cannot call a literal `{kind}` value"),
                        };
                        self.report(TypeCode::NonCallableCallee, Severity::Error, *span, message);
                    }
                    _ => {}
                }
                self.expr(func, locals, in_fn, handlers);
                for arg in args {
                    self.expr(arg, locals, in_fn, handlers);
                }
            }
            CoreExpr::If {
                cond,
                then_branch,
                else_branch,
                ..
            } => {
                // R3 — a literal condition is definite; truthy accepts
                // only `bool` on both engines (`TypeMismatch`
                // "truthy" family).
                if let CoreExpr::Literal { span: cspan, value } = &**cond {
                    if !matches!(value, LiteralValue::Bool(_)) {
                        self.report(
                            TypeCode::NonBooleanCondition,
                            Severity::Error,
                            *cspan,
                            format!(
                                "type mismatch: `if` condition must be a bool, got `{}`",
                                value.kind_name()
                            ),
                        );
                    }
                }
                self.expr(cond, locals, in_fn, handlers);
                self.expr(then_branch, locals, in_fn, handlers);
                self.expr(else_branch, locals, in_fn, handlers);
            }
            CoreExpr::Literal { .. } => {}
            CoreExpr::Assign { span, name, value } => {
                // R8 — surprising assignment targets (warning level:
                // both forms are legal semantics — report-over-silence
                // at the non-blocking tier; only definite errors may
                // be Error-severity under the conservative charter).
                if !locals.iter().any(|l| l == name) && !self.is_any_define(name) {
                    let message = if self.externals.resolve(name.as_str()).is_some() {
                        format!("assignment rebinds builtin `{name}`")
                    } else {
                        format!("assignment to `{name}` implicitly creates a global")
                    };
                    self.report(
                        TypeCode::AssignmentTargetSurprise,
                        Severity::Warning,
                        *span,
                        message,
                    );
                }
                self.expr(value, locals, in_fn, handlers);
            }
            CoreExpr::Let { bindings, body, .. } => {
                // let* semantics mirror (compile.rs): binding i's value
                // sees bindings 0..i-1 only — push after walking.
                let mark = locals.len();
                for binding in bindings {
                    self.expr(&binding.value, locals, in_fn, handlers);
                    locals.push(binding.name.clone());
                }
                self.expr(body, locals, in_fn, handlers);
                locals.truncate(mark);
            }
            CoreExpr::Perform { span, effect, args } => {
                for arg in args {
                    self.expr(arg, locals, in_fn, handlers);
                }
                // R5/R6/R7 — top-level immediate performs only (an Fn
                // body's perform may be dynamically handled at call
                // time; module docs record the soundness argument).
                if !in_fn {
                    let routed = handlers
                        .iter()
                        .rev()
                        .find_map(|clauses| clauses.iter().find(|c| &c.effect == effect));
                    match routed {
                        // R6 — no lexical handler and no dynamic
                        // context can exist at module load: definite
                        // `UnhandledEffect` when reached.
                        None => {
                            self.report(
                                TypeCode::TopLevelUnhandledPerform,
                                Severity::Error,
                                *span,
                                format!("unhandled effect `{effect}` at module top level"),
                            );
                        }
                        Some(clause) => {
                            let actual = args.len() as u32;
                            match self.resolve_handler_shape(&clause.handler, locals, in_fn) {
                                // R5 — the routed handler's arity is
                                // definite: the VM invokes it with the
                                // performed args (`invoke` arity check).
                                Some(Callee::Arity(expected)) if expected != actual => {
                                    self.report(
                                        TypeCode::HandlerArityMismatch,
                                        Severity::Error,
                                        *span,
                                        format!(
                                            "handler arity mismatch: handler for `{effect}` expects `{expected}` arguments, got `{actual}`"
                                        ),
                                    );
                                }
                                // R7 — a literal handler cannot be
                                // invoked (`call callee` mismatch).
                                Some(Callee::NonCallable(kind)) => {
                                    let handler_desc = match &*clause.handler {
                                        CoreExpr::Var { name, .. } => {
                                            format!(
                                                "`{name}` is defined as a literal `{kind}` value"
                                            )
                                        }
                                        _ => format!("it is a literal `{kind}` value"),
                                    };
                                    self.report(
                                        TypeCode::NonCallableHandler,
                                        Severity::Error,
                                        clause.span,
                                        format!(
                                            "handler for `{effect}` cannot be called: {handler_desc}"
                                        ),
                                    );
                                }
                                _ => {}
                            }
                        }
                    }
                }
            }
            CoreExpr::Handle {
                body,
                handlers: clauses,
                ..
            } => {
                // Compilation-order mirror (compile.rs): handler values
                // evaluate at installation, before their own clauses
                // install — walk them on the *outer* stack.
                for clause in clauses {
                    self.expr(&clause.handler, locals, in_fn, handlers);
                }
                if !in_fn {
                    handlers.push(clauses);
                    self.expr(body, locals, in_fn, handlers);
                    handlers.pop();
                } else {
                    self.expr(body, locals, in_fn, handlers);
                }
            }
        }
    }

    /// The handler-side callee analysis (R5/R7): the handler expression
    /// must be callable with the performed arity when its shape is
    /// statically known.
    fn resolve_handler_shape(
        &self,
        handler: &CoreExpr,
        locals: &[Symbol],
        in_fn: bool,
    ) -> Option<Callee> {
        let (callee, _) = self.resolve_callee(handler, locals, in_fn);
        match callee {
            Callee::Unknown => None,
            known => Some(known),
        }
    }
}

#[cfg(test)]
mod tests {
    //! Rule-family tests (FP3-FP8): every rule gets a definite-error
    //! case, a soundness-guard pass case, and an R8 message-form
    //! assertion where the wording is new. The construction helpers
    //! mirror the audit/seed style: validated constructors only.

    use super::*;
    use kerf_span::{ByteOffset, ExpansionId, FileId};

    fn sp(a: u32, b: u32) -> Span {
        Span::new(FileId(0), ByteOffset(a), ByteOffset(b), ExpansionId::ROOT)
            .expect("test span is ordered")
    }

    fn define(name: &str, value: CoreExpr) -> ModuleItem {
        ModuleItem::define(sp(0, 10), name, value).expect("valid define")
    }

    fn var(name: &str) -> CoreExpr {
        CoreExpr::var(sp(1, 4), name).expect("valid name")
    }

    fn int(v: i64) -> CoreExpr {
        CoreExpr::Literal {
            span: sp(1, 3),
            value: LiteralValue::Int(v),
        }
    }

    fn bool_lit(v: bool) -> CoreExpr {
        CoreExpr::Literal {
            span: sp(1, 3),
            value: LiteralValue::Bool(v),
        }
    }

    fn fn_of(params: &[&str], body: CoreExpr) -> CoreExpr {
        CoreExpr::fn_(sp(2, 8), params, body).expect("valid fn")
    }

    fn apply(func: CoreExpr, args: Vec<CoreExpr>) -> CoreExpr {
        CoreExpr::Apply {
            span: sp(2, 9),
            func: Box::new(func),
            args,
        }
    }

    fn externals() -> Externals {
        Externals::from_named_arities([
            ("+", Some(2)),
            ("-", Some(2)),
            ("<", Some(2)),
            ("car", Some(1)),
            ("read-line", Some(0)),
        ])
    }

    fn codes(items: &[ModuleItem]) -> Vec<TypeCode> {
        check_module(items, &externals())
            .into_iter()
            .map(|d| d.code)
            .collect()
    }

    // ---------- R1 (FP3) ----------

    #[test]
    fn r1_top_level_reference_to_undefined_name_is_reported() {
        let items = [define("x", var("missing"))];
        assert_eq!(codes(&items), vec![TypeCode::UnboundVariable]);
    }

    #[test]
    fn r1_forward_reference_at_top_level_is_reported() {
        // (define a b) (define b 1) — the value evaluates during load,
        // before b's define runs: definite UnboundGlobal.
        let items = [define("a", var("b")), define("b", int(1))];
        assert_eq!(codes(&items), vec![TypeCode::UnboundVariable]);
    }

    #[test]
    fn r1_letrec_self_reference_passes() {
        // (define f (fn (n) (f n))) — the letrec pre-bind: the own
        // name is visible inside the value.
        let items = [define("f", fn_of(&["n"], apply(var("f"), vec![var("n")])))];
        assert!(codes(&items).is_empty());
    }

    #[test]
    fn r1_fn_body_forward_reference_passes() {
        // Call time is post-load: a later define is visible inside an
        // Fn body (mutual-recursion shape).
        let items = [
            define("f", fn_of(&["x"], apply(var("g"), vec![var("x")]))),
            define("g", fn_of(&["x"], var("x"))),
        ];
        assert!(codes(&items).is_empty());
    }

    #[test]
    fn r1_fn_body_does_not_see_enclosing_fn_params() {
        // begin_closure mirror: a fresh locals table — the inner Var
        // resolves through globals, and `outer` is not a global.
        let inner = fn_of(&[], var("outer"));
        let items = [define("h", fn_of(&["outer"], inner))];
        assert_eq!(codes(&items), vec![TypeCode::UnboundVariable]);
    }

    #[test]
    fn r1_let_bindings_shield_references() {
        // (define x (let ((v 1)) v))
        let binding = kerf_core::Binding {
            span: sp(3, 5),
            name: Symbol::new("v").expect("valid"),
            value: int(1),
        };
        let let_ = CoreExpr::Let {
            span: sp(2, 9),
            bindings: vec![binding],
            body: Box::new(var("v")),
        };
        let items = [define("x", let_)];
        assert!(codes(&items).is_empty());
    }

    #[test]
    fn r1_external_name_resolves() {
        let items = [define("x", apply(var("+"), vec![int(1), int(2)]))];
        assert!(codes(&items).is_empty());
    }

    // ---------- R2 (FP4) ----------

    #[test]
    fn r2_iife_arity_mismatch_is_reported() {
        let callee = fn_of(&["a", "b"], var("a"));
        let items = [define("x", apply(callee, vec![int(1)]))];
        assert_eq!(codes(&items), vec![TypeCode::ArityMismatch]);
    }

    #[test]
    fn r2_iife_matching_arity_passes() {
        let callee = fn_of(&["a", "b"], var("a"));
        let items = [define("x", apply(callee, vec![int(1), int(2)]))];
        assert!(codes(&items).is_empty());
    }

    #[test]
    fn r2_define_fn_arity_mismatch_is_reported() {
        let items = [
            define("g", fn_of(&["a", "b"], var("a"))),
            define("x", apply(var("g"), vec![int(1)])),
        ];
        assert_eq!(codes(&items), vec![TypeCode::ArityMismatch]);
    }

    #[test]
    fn r2_builtin_arity_mismatch_is_reported() {
        let items = [define("x", apply(var("car"), vec![int(1), int(2)]))];
        assert_eq!(codes(&items), vec![TypeCode::ArityMismatch]);
    }

    #[test]
    fn r2_builtin_matching_arity_passes() {
        let items = [define("x", apply(var("+"), vec![int(1), int(2)]))];
        assert!(codes(&items).is_empty());
    }

    #[test]
    fn r2_assign_guard_skips_rebound_global() {
        // (define g (fn (a b) a)) (set! g ...) (g 1) — the assignment
        // may rebind g to another shape: skip (sound direction).
        let items = [
            define("g", fn_of(&["a", "b"], var("a"))),
            define(
                "x",
                CoreExpr::assign(sp(4, 6), "g", fn_of(&["a"], var("a"))).expect("valid"),
            ),
            define("y", apply(var("g"), vec![int(1)])),
        ];
        assert!(codes(&items).is_empty());
    }

    #[test]
    fn r2_lexical_shadow_skips_global_arity() {
        // The let-bound `g` shadows the global — unknown local shape.
        let binding = kerf_core::Binding {
            span: sp(3, 5),
            name: Symbol::new("g").expect("valid"),
            value: fn_of(&["a", "b", "c"], var("a")),
        };
        let call = apply(var("g"), vec![int(1)]);
        let let_ = CoreExpr::Let {
            span: sp(2, 9),
            bindings: vec![binding],
            body: Box::new(call),
        };
        let items = [define("g", fn_of(&["a"], var("a"))), define("x", let_)];
        assert!(codes(&items).is_empty());
    }

    #[test]
    fn r2_unknown_arity_external_is_skipped() {
        // An external registered without an arity: existence yes,
        // arity no — the conservative skip.
        let ext = Externals::from_names(["mystery"]);
        let items = [define("x", apply(var("mystery"), vec![int(1)]))];
        assert!(check_module(&items, &ext).is_empty());
    }

    #[test]
    fn r2_message_mirrors_vm_arity_wording() {
        let callee = fn_of(&["a", "b"], var("a"));
        let items = [define("x", apply(callee, vec![int(1)]))];
        let diags = check_module(&items, &externals());
        assert_eq!(diags.len(), 1);
        assert_eq!(
            diags[0].message,
            "arity mismatch: function expects `2` arguments, got `1`"
        );
        // R8 form: lowercase start, no trailing period.
        let m = &diags[0].message;
        assert!(m.starts_with(char::is_lowercase));
        assert!(!m.ends_with('.'));
    }

    // ---------- R3 / R4 (FP5) ----------

    #[test]
    fn r3_non_bool_literal_condition_is_reported() {
        let items = [define(
            "x",
            CoreExpr::If {
                span: sp(2, 9),
                cond: Box::new(int(1)),
                then_branch: Box::new(int(2)),
                else_branch: Box::new(int(3)),
            },
        )];
        assert_eq!(codes(&items), vec![TypeCode::NonBooleanCondition]);
    }

    #[test]
    fn r3_bool_literal_condition_passes() {
        let items = [define(
            "x",
            CoreExpr::If {
                span: sp(2, 9),
                cond: Box::new(bool_lit(true)),
                then_branch: Box::new(int(2)),
                else_branch: Box::new(int(3)),
            },
        )];
        assert!(codes(&items).is_empty());
    }

    #[test]
    fn r3_non_literal_condition_is_skipped() {
        // A computed condition is not definite — the conservative skip.
        let items = [define(
            "x",
            CoreExpr::If {
                span: sp(2, 9),
                cond: Box::new(apply(var("+"), vec![int(1), int(2)])),
                then_branch: Box::new(int(2)),
                else_branch: Box::new(int(3)),
            },
        )];
        assert!(codes(&items).is_empty());
    }

    #[test]
    fn r4_literal_callee_is_reported() {
        let items = [define("x", apply(int(1), vec![int(2)]))];
        assert_eq!(codes(&items), vec![TypeCode::NonCallableCallee]);
    }

    #[test]
    fn r4_literal_define_global_callee_is_reported() {
        // (define two 2) (two 1) — no assignments, so `two` is
        // definitely the literal at every use.
        let items = [
            define("two", int(2)),
            define("x", apply(var("two"), vec![int(1)])),
        ];
        assert_eq!(codes(&items), vec![TypeCode::NonCallableCallee]);
    }

    #[test]
    fn r4_assign_guard_skips_literal_define_callee() {
        let items = [
            define("two", int(2)),
            define(
                "y",
                CoreExpr::assign(sp(4, 6), "two", fn_of(&["a"], var("a"))).expect("valid"),
            ),
            define("x", apply(var("two"), vec![int(1)])),
        ];
        assert!(codes(&items).is_empty());
    }

    // ---------- R5 / R6 / R7 (FP6) ----------

    fn perform(effect: &str, args: Vec<CoreExpr>) -> CoreExpr {
        CoreExpr::perform(sp(5, 8), effect, args).expect("valid effect")
    }

    fn handle_of(body: CoreExpr, effect: &str, handler: CoreExpr) -> CoreExpr {
        let clause = HandlerClause::new(sp(6, 7), effect, handler).expect("valid clause");
        CoreExpr::handle(sp(4, 9), body, vec![clause]).expect("valid handle")
    }

    #[test]
    fn r6_top_level_unhandled_perform_is_reported() {
        let items = [define("x", perform("e", vec![]))];
        assert_eq!(codes(&items), vec![TypeCode::TopLevelUnhandledPerform]);
    }

    #[test]
    fn r6_fn_body_unhandled_perform_passes() {
        // Soundness guard: the call site may install a dynamic
        // handler — no lexical report inside an Fn.
        let items = [define("f", fn_of(&[], perform("e", vec![])))];
        assert!(codes(&items).is_empty());
    }

    #[test]
    fn r6_enclosing_handle_shields_top_level_perform() {
        let items = [define(
            "x",
            handle_of(perform("e", vec![]), "e", fn_of(&[], int(1))),
        )];
        assert!(codes(&items).is_empty());
    }

    #[test]
    fn r6_wrong_effect_handle_does_not_shield() {
        // A handler for `other` does not route `e`.
        let items = [define(
            "x",
            handle_of(perform("e", vec![]), "other", fn_of(&[], int(1))),
        )];
        assert_eq!(codes(&items), vec![TypeCode::TopLevelUnhandledPerform]);
    }

    #[test]
    fn r5_handler_arity_mismatch_is_reported() {
        // The perform routes to the 2-param handler with 0 args.
        let items = [define(
            "x",
            handle_of(perform("e", vec![]), "e", fn_of(&["a", "b"], var("a"))),
        )];
        assert_eq!(codes(&items), vec![TypeCode::HandlerArityMismatch]);
    }

    #[test]
    fn r5_handler_arity_match_passes() {
        let items = [define(
            "x",
            handle_of(perform("e", vec![int(1)]), "e", fn_of(&["a"], var("a"))),
        )];
        assert!(codes(&items).is_empty());
    }

    #[test]
    fn r7_literal_handler_is_reported() {
        let items = [define("x", handle_of(perform("e", vec![]), "e", int(1)))];
        assert_eq!(codes(&items), vec![TypeCode::NonCallableHandler]);
    }

    #[test]
    fn r5_nearest_handler_wins() {
        // The perform routes to the inner 0-param handler (match); the
        // outer 2-param handler would mismatch — nearest lexical =
        // nearest dynamic shields it. If resolution wrongly picked the
        // outer handler, this test would report E0005.
        let inner = handle_of(perform("e", vec![]), "e", fn_of(&[], int(1)));
        let items = [define(
            "x",
            handle_of(inner, "e", fn_of(&["a", "b"], var("a"))),
        )];
        assert!(codes(&items).is_empty());
    }

    #[test]
    fn r5_outer_handler_arity_mismatch_routes_when_inner_is_other_effect() {
        // The inner handle is for `other`, so `e` routes to the outer
        // 2-param handler with 0 args.
        let inner = handle_of(perform("e", vec![]), "other", fn_of(&["a"], var("a")));
        let items = [define(
            "x",
            handle_of(inner, "e", fn_of(&["a", "b"], var("a"))),
        )];
        assert_eq!(codes(&items), vec![TypeCode::HandlerArityMismatch]);
    }

    #[test]
    fn r5_handler_value_evaluates_before_installation() {
        // Compilation-order mirror (compile.rs: handler value first,
        // THEN PushHandler): the inner handle's handler expr is a bare
        // perform of `unrelated` — evaluated while only the outer
        // stack (which handles `e`) is installed → unhandled → R6.
        let inner = handle_of(int(0), "e", perform("unrelated", vec![]));
        let items = [define("x", handle_of(inner, "e", fn_of(&["a"], var("a"))))];
        assert_eq!(codes(&items), vec![TypeCode::TopLevelUnhandledPerform]);
    }

    #[test]
    fn r5_handler_var_resolves_to_define_arity() {
        // A handler named by a Var resolving to a 2-param define,
        // routed with 0 args.
        let items = [
            define("h", fn_of(&["a", "b"], var("a"))),
            define(
                "x",
                CoreExpr::handle(
                    sp(4, 9),
                    perform("e", vec![]),
                    vec![HandlerClause::new(sp(6, 7), "e", var("h")).expect("valid")],
                )
                .expect("valid"),
            ),
        ];
        assert_eq!(codes(&items), vec![TypeCode::HandlerArityMismatch]);
    }

    // ---------- R8 (FP7) ----------

    #[test]
    fn r8_unbound_assign_target_warns_implicit_global() {
        let items = [define(
            "x",
            CoreExpr::assign(sp(4, 6), "nowhere", int(1)).expect("valid"),
        )];
        let diags = check_module(&items, &externals());
        assert_eq!(diags.len(), 1);
        assert_eq!(diags[0].code, TypeCode::AssignmentTargetSurprise);
        assert_eq!(diags[0].severity, Severity::Warning);
        assert_eq!(
            diags[0].message,
            "assignment to `nowhere` implicitly creates a global"
        );
    }

    #[test]
    fn r8_builtin_rebind_warns() {
        let items = [define(
            "x",
            CoreExpr::assign(sp(4, 6), "car", int(1)).expect("valid"),
        )];
        let diags = check_module(&items, &externals());
        assert_eq!(diags.len(), 1);
        assert_eq!(diags[0].severity, Severity::Warning);
        assert_eq!(diags[0].message, "assignment rebinds builtin `car`");
    }

    #[test]
    fn r8_define_target_and_local_target_are_silent() {
        let binding = kerf_core::Binding {
            span: sp(3, 5),
            name: Symbol::new("v").expect("valid"),
            value: int(1),
        };
        let assign_local = CoreExpr::assign(sp(4, 6), "v", int(2)).expect("valid");
        let let_ = CoreExpr::Let {
            span: sp(2, 9),
            bindings: vec![binding],
            body: Box::new(assign_local),
        };
        let items = [
            define("g", fn_of(&["a"], var("a"))),
            define("x", CoreExpr::assign(sp(4, 6), "g", int(2)).expect("valid")),
            define("y", let_),
        ];
        assert!(codes(&items).is_empty());
    }

    // ---------- FP8: multi-error collection ----------

    #[test]
    fn multiple_errors_are_all_collected() {
        // Two independent errors in one program: both reported.
        let items = [
            define("x", var("missing")),
            define("y", apply(int(1), vec![int(2)])),
        ];
        let diags = check_module(&items, &externals());
        assert_eq!(
            diags.iter().map(|d| d.code).collect::<Vec<_>>(),
            vec![TypeCode::UnboundVariable, TypeCode::NonCallableCallee]
        );
    }

    #[test]
    fn collection_continues_after_unbound_reference() {
        // The walk never stops: an unbound var mid-program does not
        // poison the rest — later defines are still checked.
        let items = [
            define("a", var("missing")),
            define("b", fn_of(&["p"], var("p"))),
        ];
        let diags = check_module(&items, &externals());
        assert_eq!(diags.len(), 1);
        assert_eq!(diags[0].code, TypeCode::UnboundVariable);
        // A later arity mismatch is still found after the unbound one
        // (three diagnostics across three independent errors).
        let items2 = [
            define("a", var("missing")),
            define("b", fn_of(&["p"], apply(var("+"), vec![var("p")]))),
            define("c", apply(int(9), vec![])),
        ];
        let diags2 = check_module(&items2, &externals());
        assert_eq!(diags2.len(), 3);
    }

    // ---------- clean programs (FP soundness guard) ----------

    #[test]
    fn clean_fib_like_module_yields_zero_diagnostics() {
        // (define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2)))))
        // built through the validated constructors.
        let cond = CoreExpr::If {
            span: sp(10, 40),
            cond: Box::new(apply(var("<"), vec![var("n"), int(2)])),
            then_branch: Box::new(var("n")),
            else_branch: Box::new(apply(
                var("+"),
                vec![
                    apply(var("fib"), vec![apply(var("-"), vec![var("n"), int(1)])]),
                    apply(var("fib"), vec![apply(var("-"), vec![var("n"), int(2)])]),
                ],
            )),
        };
        let items = [define("fib", fn_of(&["n"], cond))];
        assert!(codes(&items).is_empty());
    }

    #[test]
    fn zero_code_declarations_are_skipped() {
        let items = [
            ModuleItem::require(sp(0, 9), "other").expect("valid"),
            ModuleItem::define_syntax(sp(0, 9), "m").expect("valid"),
        ];
        assert!(codes(&items).is_empty());
    }

    #[test]
    fn nested_module_defines_are_flat_visible() {
        // Flat compilation mirror: a nested module's define is a
        // global — visible to later top-level uses.
        let inner = vec![define("g", fn_of(&["a"], var("a")))];
        let items = [
            ModuleItem::module(sp(0, 20), "m", inner).expect("valid"),
            define("x", apply(var("g"), vec![int(1)])),
        ];
        assert!(codes(&items).is_empty());
    }

    #[test]
    fn nested_module_unbound_reference_is_reported() {
        let inner = vec![define("x", var("missing"))];
        let items = [ModuleItem::module(sp(0, 20), "m", inner).expect("valid")];
        assert_eq!(codes(&items), vec![TypeCode::UnboundVariable]);
    }
}

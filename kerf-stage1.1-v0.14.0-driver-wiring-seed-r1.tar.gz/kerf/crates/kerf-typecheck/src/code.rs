//! The E0xxx diagnostic registry — Stage 1 activation (stage-1-plan §4).
//!
//! The variant-level code scheme was registered in Stage 0 (driver
//! `diagnostic.rs` header note: "the E0xxx scheme is the Stage 1+
//! diagnostics agenda, registered"); this module is its activation for
//! the type-checking domain. The driver's stage-level
//! `DiagnosticCode` remains the pipeline-face scheme — the two are
//! joined at the 1.1 driver wiring, not here.
//!
//! Message shape follows the Rust compiler conventions (SOP §10.5 /
//! R8): lowercase start, no trailing period, payloads in backticks —
//! and stays same-source same-translation with the RuntimeError family
//! (the single-source dictionary): the R2 wording mirrors
//! `RuntimeError::ArityMismatch`, R4/R7 mirror the `call callee`
//! type-mismatch family, R6 mirrors `UnhandledEffect`.

use kerf_span::Span;

/// One conservative-static diagnostic code (stage-1-plan §3 table).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum TypeCode {
    /// R1 — a variable reference that resolves nowhere (E0001).
    UnboundVariable,
    /// R2 — application arity mismatch on a statically known callee (E0002).
    ArityMismatch,
    /// R3 — an `if` condition that is a non-boolean literal (E0003).
    NonBooleanCondition,
    /// R4 — an application whose callee is a literal (E0004).
    NonCallableCallee,
    /// R5 — handler arity mismatch on a routed top-level perform (E0005).
    HandlerArityMismatch,
    /// R6 — a top-level perform with no enclosing handler (E0006).
    TopLevelUnhandledPerform,
    /// R7 — a routed handler that is a literal value (E0007).
    NonCallableHandler,
    /// R8 — a surprising assignment target (E0008, warning severity).
    AssignmentTargetSurprise,
}

impl TypeCode {
    /// The stable registry string (`"E0001"`..=`"E0008"`).
    pub fn as_str(&self) -> &'static str {
        match self {
            TypeCode::UnboundVariable => "E0001",
            TypeCode::ArityMismatch => "E0002",
            TypeCode::NonBooleanCondition => "E0003",
            TypeCode::NonCallableCallee => "E0004",
            TypeCode::HandlerArityMismatch => "E0005",
            TypeCode::TopLevelUnhandledPerform => "E0006",
            TypeCode::NonCallableHandler => "E0007",
            TypeCode::AssignmentTargetSurprise => "E0008",
        }
    }
}

/// How severe a checker diagnostic is — the checker-side subset of the
/// §8.7 contract (the driver's four-level face is joined at the 1.1
/// wiring). R1-R7 are definite errors; R8 is the first `Warning`
/// producer in the workspace (legal semantics, likely bug —
/// report-over-silence at the non-blocking level).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Severity {
    /// A definite error — the program cannot behave as written.
    Error,
    /// A surprising-but-legal construct — surfaced, never blocking.
    Warning,
}

impl std::fmt::Display for Severity {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let s = match self {
            Severity::Error => "error",
            Severity::Warning => "warning",
        };
        f.write_str(s)
    }
}

/// One checker finding: code + severity + byte-precise span + message.
///
/// The message is pre-rendered at construction (R8 shape asserted in
/// tests) so the 1.1 driver wiring consumes a ready string with zero
/// rendering drift.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct TypeDiagnostic {
    /// The registry code (E0001-E0008).
    pub code: TypeCode,
    /// Error (R1-R7) or warning (R8).
    pub severity: Severity,
    /// The byte-precise position of the offending node.
    pub span: Span,
    /// The rendered message (R8 conventions, single-source dictionary).
    pub message: String,
}

impl TypeDiagnostic {
    /// Construct with a pre-rendered message.
    pub fn new(code: TypeCode, severity: Severity, span: Span, message: String) -> Self {
        Self {
            code,
            severity,
            span,
            message,
        }
    }
}

#[cfg(test)]
mod tests {
    //! Registry-face tests (FP1): stable code strings, severity
    //! rendering, diagnostic shape, and the R8 message-form invariants.

    use super::*;
    use kerf_span::{ByteOffset, ExpansionId, FileId};

    fn sp(a: u32, b: u32) -> Span {
        Span::new(FileId(0), ByteOffset(a), ByteOffset(b), ExpansionId::ROOT)
            .expect("test span is ordered")
    }

    #[test]
    fn registry_strings_are_stable_e0001_through_e0008() {
        assert_eq!(TypeCode::UnboundVariable.as_str(), "E0001");
        assert_eq!(TypeCode::ArityMismatch.as_str(), "E0002");
        assert_eq!(TypeCode::NonBooleanCondition.as_str(), "E0003");
        assert_eq!(TypeCode::NonCallableCallee.as_str(), "E0004");
        assert_eq!(TypeCode::HandlerArityMismatch.as_str(), "E0005");
        assert_eq!(TypeCode::TopLevelUnhandledPerform.as_str(), "E0006");
        assert_eq!(TypeCode::NonCallableHandler.as_str(), "E0007");
        assert_eq!(TypeCode::AssignmentTargetSurprise.as_str(), "E0008");
    }

    #[test]
    fn registry_codes_are_pairwise_distinct() {
        let all = [
            TypeCode::UnboundVariable,
            TypeCode::ArityMismatch,
            TypeCode::NonBooleanCondition,
            TypeCode::NonCallableCallee,
            TypeCode::HandlerArityMismatch,
            TypeCode::TopLevelUnhandledPerform,
            TypeCode::NonCallableHandler,
            TypeCode::AssignmentTargetSurprise,
        ];
        for (i, a) in all.iter().enumerate() {
            for b in &all[i + 1..] {
                assert_ne!(a.as_str(), b.as_str(), "distinct codes required");
            }
        }
    }

    #[test]
    fn severity_renders_lowercase_single_word() {
        assert_eq!(Severity::Error.to_string(), "error");
        assert_eq!(Severity::Warning.to_string(), "warning");
    }

    #[test]
    fn diagnostic_carries_all_four_fields() {
        let d = TypeDiagnostic::new(
            TypeCode::UnboundVariable,
            Severity::Error,
            sp(3, 7),
            "unbound variable `g`".to_owned(),
        );
        assert_eq!(d.code, TypeCode::UnboundVariable);
        assert_eq!(d.severity, Severity::Error);
        assert_eq!(d.span, sp(3, 7));
        assert_eq!(d.message, "unbound variable `g`");
    }
}

//! kerf-typecheck — the conservative static checker (Layer 4.5).
//!
//! Stage 1 activation of the external Rust type-checker path
//! (docs/stage0.md §21.6 risk mitigation for the checker circular
//! dependency; roadmap first agenda). The checker is a *cross-cutting
//! static verification layer* — a validator, never an executor
//! (stage0.md §9.24 TY-A): it consumes expanded programs
//! (`&[ModuleItem]`) and reports what is *definitely* wrong.
//!
//! # The conservative discipline (stage-1-plan.md §3)
//!
//! Every rule R1-R8 reports only **definite errors** — each carries a
//! soundness argument recorded next to its implementation. Anything
//! uncertain passes. The two mirror disciplines:
//!
//! * the **compiler's resolution order** (locals-then-globals —
//!   `compile.rs` `lookup_local` -> `intern_global`), so a name the
//!   checker resolves is the name the compiler resolves;
//! * the **expander's sequential discipline** (define-so-far with the
//!   letrec pre-bind — `expand.rs` binds a `define`d name before
//!   expanding its value).
//!
//! # Layer split (disclosed)
//!
//! R1 re-asserts at the structural layer what the expander already
//! enforces on the source path (`Resolution::Unbound ->
//! ExpandError::UnboundIdentifier`, since 0.4) — the second line of
//! defense for directly-constructed programs (macro synthesis,
//! programmatic API consumers). R2-R7 statically catch what is
//! runtime-only today (arity mismatch, type mismatch on literals,
//! unhandled effects); R8 surfaces silent-but-surprising assignment
//! targets as the first `Warning` producer.
//!
//! # Multi-error collection (ruling 21)
//!
//! Collection is an *architectural property*, not a diagnostic slot:
//! [`check_module`] walks every node and returns every diagnostic it
//! finds — it never stops at the first error.

mod check;
mod code;
mod env;

// Explicit re-export list (SOP §10.1 rule 4 — glob re-exports are forbidden).
pub use check::check_module;
pub use code::{Severity, TypeCode, TypeDiagnostic};
pub use env::Externals;

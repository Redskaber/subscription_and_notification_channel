//! StxDatum (the surface skeleton) + SyntaxObject (the four-tuple).
//!
//! docs/stage0.md §3.3 defines the syntax-object model — every piece of
//! syntax carries a span (mandatory, never a dummy), a scope set and a
//! phase; §7.3.6 positions the datum as the "extended S-expression": the
//! S-expression tree is the skeleton, span/scopes/phase are per-node
//! enhancements (Racket's industrial proof, §7.3.6 comparison table).
//! Consequently list members are full syntax objects, not bare datums —
//! per-identifier scope sets are what hygiene needs (§19.2 invariant 2).
//!
//! The skeleton is the Stage 0 bootstrap-parser scaffold (SOP §2.5;
//! choice A of the §7.3.6 six-dimension ruling): consumed by the reader
//! (0.3) and the expander (0.4), removed from the bootstrap chain at
//! Stage 2b — never a permanent internal IR.

use std::fmt;

use crate::error::SyntaxError;
use crate::phase::Phase;
use crate::scope::{ScopeId, ScopeSet};
use crate::symbol::StxSymbol;
use kerf_span::Span;

/// The datum of one syntax object: an atom or a proper list of child
/// syntax objects (the S-expression skeleton, docs/stage0.md §7.3.6).
///
/// Improper (dotted) lists are not modeled: they are a reader *grammar*
/// decision (plan sub-stage 0.3), and quoted pair data already has its
/// core representation (`kerf_core::LiteralValue::Pair`, delivered at
/// 0.1). If the 0.3 grammar accepts dotted pairs the variant arrives
/// additively (SOP principle 27). The empty list `()` is legal datum.
#[derive(Debug, Clone, PartialEq)]
pub enum StxDatum {
    /// Identifier atom.
    Symbol(StxSymbol),
    /// Integer literal atom.
    Int(i64),
    /// Floating-point literal atom.
    Float(f64),
    /// Boolean literal atom.
    Bool(bool),
    /// String literal atom.
    String(String),
    /// Proper list of child syntax objects (per-node wrappers).
    List(Vec<SyntaxObject>),
}

impl StxDatum {
    /// Stable diagnostic name (lowercase, one word; mirrors
    /// `kerf_core::LiteralValue::kind_name`).
    pub fn kind_name(&self) -> &'static str {
        match self {
            StxDatum::Symbol(_) => "symbol",
            StxDatum::Int(_) => "int",
            StxDatum::Float(_) => "float",
            StxDatum::Bool(_) => "bool",
            StxDatum::String(_) => "string",
            StxDatum::List(_) => "list",
        }
    }
}

impl fmt::Display for StxDatum {
    /// S-expression notation: `add`, `42`, `2.5`, `true`, `"s"`,
    /// `(add 1 2)`, `()` — nested naturally through child objects.
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            StxDatum::Symbol(s) => f.write_str(s.as_str()),
            StxDatum::Int(v) => write!(f, "{v}"),
            StxDatum::Float(v) => write!(f, "{v:?}"),
            StxDatum::Bool(v) => write!(f, "{v}"),
            StxDatum::String(v) => write!(f, "{v:?}"),
            StxDatum::List(items) => {
                f.write_str("(")?;
                for (i, item) in items.iter().enumerate() {
                    if i > 0 {
                        f.write_str(" ")?;
                    }
                    write!(f, "{}", item.datum)?;
                }
                f.write_str(")")
            }
        }
    }
}

/// One node of the surface-syntax tree: datum + span + scopes + phase
/// (docs/stage0.md §3.3 four-tuple).
///
/// The span is a mandatory field (never `Option`, never a dummy — the
/// TD-004 structural discipline): a malformed span fails at the
/// kerf-span constructor *before* any node exists. Fields are public for
/// pattern assembly by the reader/expander; name-bearing atoms
/// additionally have the checked `&str` constructor
/// [`SyntaxObject::symbol`] — the token-text contract of plan sub-stage
/// 0.3.
#[derive(Debug, Clone, PartialEq)]
pub struct SyntaxObject {
    pub datum: StxDatum,
    pub span: Span,
    pub scopes: ScopeSet,
    pub phase: Phase,
}

impl SyntaxObject {
    /// Checked symbol constructor — the sub-stage 0.3 reader contract
    /// (token text → validated identifier atom).
    pub fn symbol(
        span: Span,
        scopes: ScopeSet,
        phase: Phase,
        text: &str,
    ) -> Result<Self, SyntaxError> {
        Ok(Self {
            datum: StxDatum::Symbol(StxSymbol::new(text)?),
            span,
            scopes,
            phase,
        })
    }

    /// Integer atom constructor (infallible — the payload needs no
    /// validation).
    pub fn int(span: Span, scopes: ScopeSet, phase: Phase, value: i64) -> Self {
        Self {
            datum: StxDatum::Int(value),
            span,
            scopes,
            phase,
        }
    }

    /// Floating-point atom constructor (infallible).
    pub fn float(span: Span, scopes: ScopeSet, phase: Phase, value: f64) -> Self {
        Self {
            datum: StxDatum::Float(value),
            span,
            scopes,
            phase,
        }
    }

    /// Boolean atom constructor (infallible).
    pub fn bool(span: Span, scopes: ScopeSet, phase: Phase, value: bool) -> Self {
        Self {
            datum: StxDatum::Bool(value),
            span,
            scopes,
            phase,
        }
    }

    /// String atom constructor (infallible — string content is data, not
    /// an identifier; no floor applies).
    pub fn string(span: Span, scopes: ScopeSet, phase: Phase, value: String) -> Self {
        Self {
            datum: StxDatum::String(value),
            span,
            scopes,
            phase,
        }
    }

    /// List constructor (infallible — the empty list `()` is legal
    /// datum; span covering of children is the reader's reduction
    /// decision, not a data-layer constraint).
    pub fn list(span: Span, scopes: ScopeSet, phase: Phase, items: Vec<SyntaxObject>) -> Self {
        Self {
            datum: StxDatum::List(items),
            span,
            scopes,
            phase,
        }
    }

    /// Pre-order span traversal (this node first, then children
    /// depth-first left-to-right) — the sub-stage 0.4 expander
    /// consumption contract (mirrors `CoreExpr::visit_spans`) and the
    /// "no dummy span" audit primitive.
    pub fn visit_spans(&self, f: &mut impl FnMut(Span)) {
        f(self.span);
        if let StxDatum::List(items) = &self.datum {
            for item in items {
                item.visit_spans(f);
            }
        }
    }

    /// Deep functional scope flip: returns a copy of this subtree with
    /// `scope` added to this node and every nested syntax object; the
    /// receiver is never mutated (SOP principle 23 — transformations
    /// produce new values, never in-place edits of passed-in syntax).
    /// Spans, phases and datum shapes are unchanged.
    ///
    /// This is the scope-coloring primitive of docs/stage0.md §9.38:
    /// the expander flips definition/use scopes across whole template
    /// trees, so the operation is deep by contract.
    pub fn with_scope_added(&self, scope: ScopeId) -> Self {
        let mut out = self.clone();
        out.add_scope_deep(scope);
        out
    }

    /// Private deep mutation helper — only reachable through the
    /// functional wrapper above.
    fn add_scope_deep(&mut self, scope: ScopeId) {
        self.scopes.insert(scope);
        if let StxDatum::List(items) = &mut self.datum {
            for item in items {
                item.add_scope_deep(scope);
            }
        }
    }
}

#[cfg(test)]
mod tests {
    //! Unit tests for the StxDatum/SyntaxObject feature point (sub-stage
    //! test doc FP4).

    use super::*;
    use kerf_span::{ByteOffset, ExpansionId, FileId};

    fn span(start: u32, end: u32) -> Span {
        Span::new(
            FileId(0),
            ByteOffset(start),
            ByteOffset(end),
            ExpansionId::ROOT,
        )
        .expect("test fixture span must be well-formed")
    }

    fn empty() -> (Span, ScopeSet, Phase) {
        (span(0, 1), ScopeSet::new(), Phase::Runtime)
    }

    // ---------- positive ----------

    #[test]
    fn datum_kind_names_and_display_forms() {
        let (s, scopes, phase) = empty();
        let cases: [(SyntaxObject, &str, &str); 6] = [
            (
                SyntaxObject::symbol(s, scopes.clone(), phase, "add").unwrap(),
                "symbol",
                "add",
            ),
            (SyntaxObject::int(s, scopes.clone(), phase, 42), "int", "42"),
            (
                SyntaxObject::float(s, scopes.clone(), phase, 2.5),
                "float",
                "2.5",
            ),
            (
                SyntaxObject::bool(s, scopes.clone(), phase, true),
                "bool",
                "true",
            ),
            (
                SyntaxObject::string(s, scopes.clone(), phase, "s".to_owned()),
                "string",
                "\"s\"",
            ),
            (SyntaxObject::list(s, scopes, phase, vec![]), "list", "()"),
        ];
        for (object, kind, rendered) in cases {
            assert_eq!(object.datum.kind_name(), kind);
            assert_eq!(object.datum.to_string(), rendered);
        }
        // Nested rendering through child objects.
        let (s, scopes, phase) = empty();
        let list = SyntaxObject::list(
            s,
            scopes,
            phase,
            vec![
                SyntaxObject::symbol(s, ScopeSet::new(), Phase::Runtime, "add").unwrap(),
                SyntaxObject::int(s, ScopeSet::new(), Phase::Runtime, 1),
                SyntaxObject::int(s, ScopeSet::new(), Phase::Runtime, 2),
            ],
        );
        assert_eq!(list.datum.to_string(), "(add 1 2)");
    }

    #[test]
    fn span_preorder_and_deep_scope_flip() {
        // Tree (f x 42): the visit order is the list node first, then
        // children left-to-right (the 0.4 expander consumption
        // contract, mirroring CoreExpr::visit_spans).
        let mk = |start: u32, end: u32| span(start, end);
        let head = SyntaxObject::symbol(mk(1, 2), ScopeSet::new(), Phase::Runtime, "f").unwrap();
        let arg_name =
            SyntaxObject::symbol(mk(3, 4), ScopeSet::new(), Phase::Runtime, "x").unwrap();
        let arg_lit = SyntaxObject::int(mk(5, 7), ScopeSet::new(), Phase::Runtime, 42);
        let list = SyntaxObject::list(
            mk(0, 8),
            ScopeSet::new(),
            Phase::Runtime,
            vec![head, arg_name, arg_lit],
        );

        let mut order = Vec::new();
        list.visit_spans(&mut |s| order.push((s.start.0, s.end.0)));
        assert_eq!(order, vec![(0, 8), (1, 2), (3, 4), (5, 7)]);

        // Deep functional flip: the receiver stays untouched, every
        // node of the copy gains the scope, spans and datum survive.
        let flipped = list.with_scope_added(ScopeId(7));
        let mut flipped_spans = Vec::new();
        flipped.visit_spans(&mut |s| flipped_spans.push((s.start.0, s.end.0)));
        assert_eq!(flipped_spans, order, "spans unchanged by the flip");
        assert_eq!(flipped.datum.to_string(), "(f x 42)");
        let StxDatum::List(items) = &flipped.datum else {
            panic!("datum shape must survive the flip");
        };
        for item in items {
            assert!(item.scopes.contains(ScopeId(7)));
        }
        // Original tree: no node gained the scope (principle 23).
        let StxDatum::List(original) = &list.datum else {
            panic!("receiver datum must be intact");
        };
        assert!(!list.scopes.contains(ScopeId(7)));
        for item in original {
            assert!(!item.scopes.contains(ScopeId(7)));
        }
    }

    // ---------- negative ----------

    #[test]
    fn symbol_constructor_rejects_empty_text() {
        let (s, scopes, phase) = empty();
        let err = SyntaxObject::symbol(s, scopes, phase, "")
            .expect_err("empty identifier must be rejected via the object path");
        assert_eq!(
            err,
            SyntaxError::InvalidSymbol {
                text: String::new()
            }
        );
    }

    #[test]
    fn symbol_constructor_rejects_interior_space() {
        let (s, scopes, phase) = empty();
        assert!(matches!(
            SyntaxObject::symbol(s, scopes, phase, "a b"),
            Err(SyntaxError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn symbol_constructor_rejects_leading_space() {
        let (s, scopes, phase) = empty();
        assert!(matches!(
            SyntaxObject::symbol(s, scopes, phase, " x"),
            Err(SyntaxError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn symbol_constructor_rejects_control_char() {
        let (s, scopes, phase) = empty();
        assert!(matches!(
            SyntaxObject::symbol(s, scopes, phase, "a\u{0}b"),
            Err(SyntaxError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn reversed_span_rejected_before_object_construction() {
        // Structural no-DUMMY guard: a malformed span fails at the
        // kerf-span constructor and never reaches a syntax object.
        let err = Span::root(FileId(0), ByteOffset(10), ByteOffset(2))
            .expect_err("reversed span must be rejected before object construction");
        assert!(matches!(err, kerf_span::SpanError::StartAfterEnd { .. }));
    }

    #[test]
    fn scope_flip_never_duplicates() {
        // Set-semantics guard: flipping the same scope twice must not
        // duplicate it anywhere in the tree.
        let (s, scopes, phase) = empty();
        let leaf = SyntaxObject::symbol(s, scopes, phase, "x").unwrap();
        let list = SyntaxObject::list(s, ScopeSet::new(), Phase::Runtime, vec![leaf]);
        let once = list.with_scope_added(ScopeId(1));
        let twice = once.with_scope_added(ScopeId(1));
        assert_eq!(twice.scopes.len(), 1);
        let StxDatum::List(items) = &twice.datum else {
            panic!("list datum expected");
        };
        assert_eq!(items[0].scopes.len(), 1);
    }
}

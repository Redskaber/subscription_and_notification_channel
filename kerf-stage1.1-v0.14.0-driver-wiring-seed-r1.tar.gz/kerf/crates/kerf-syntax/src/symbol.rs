//! Surface-syntax identifier symbol: validated, opaque, cheap to compare.

use std::fmt;

use crate::error::SyntaxError;

/// An identifier atom inside a [`StxDatum`](crate::expr::StxDatum).
///
/// The payload is private on purpose (docs/stage0.md §7.4.2 principle 1 —
/// type safety over naming safety): the only construction path is the
/// checked [`StxSymbol::new`], so a symbol found inside a datum is always
/// structurally valid.
///
/// The floor is identical to `kerf_core::Symbol`'s (non-empty, no
/// whitespace, no control characters — a conservative floor, not a
/// grammar; the full identifier grammar lands with the 0.3 reader).
/// This is a pipeline-phase twin, not a duplicate type: the surface
/// identifier and the core symbol live at different pipeline layers
/// (skeleton vs core AST) and never share a definition — the 0.4
/// expander crosses the boundary as source text through the core
/// validated `&str` constructors, so "anything the reader accepts must
/// pass both floors" holds by identical validation, not by a shared type
/// (SOP §21.12-5 single-definition rule scopes to cross-stage *shared*
/// types; the DAG keeps L1 and L4 independent — docs/graph/stage-0/
/// dataflow.md).
#[derive(Debug, Clone, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct StxSymbol {
    text: String,
}

impl StxSymbol {
    /// Checked constructor.
    ///
    /// Rejects empty text and any character that is whitespace or a
    /// control character. Returns [`SyntaxError::InvalidSymbol`] on
    /// rejection.
    pub fn new(text: &str) -> Result<Self, SyntaxError> {
        if text.is_empty() {
            return Err(SyntaxError::InvalidSymbol {
                text: text.to_owned(),
            });
        }
        if text.chars().any(|c| c.is_whitespace() || c.is_control()) {
            return Err(SyntaxError::InvalidSymbol {
                text: text.to_owned(),
            });
        }
        Ok(Self {
            text: text.to_owned(),
        })
    }

    /// The identifier text (guaranteed valid by construction).
    pub fn as_str(&self) -> &str {
        &self.text
    }
}

impl fmt::Display for StxSymbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.text)
    }
}

#[cfg(test)]
mod tests {
    //! Unit tests for the StxSymbol feature point; ratio mirrors the
    //! sub-stage test doc (docs/tests/v0/stage0/plan/syntax.md, FP1).
    //! CJK fixture note (SOP §10.5 registered whitelist): the
    //! `valid_symbols_accept_unicode_cjk` case uses CJK *as the tested
    //! object* (identifier floor acceptance), which is the sanctioned
    //! fixture category.

    use super::*;

    // ---------- positive ----------

    #[test]
    fn valid_symbols_roundtrip() {
        for text in [
            "x",
            "snake_case_x1",
            "+",
            "x!",
            "?value",
            "a1b2",
            "nil?",
            "set!",
        ] {
            let symbol = StxSymbol::new(text).expect("floor-valid name must construct");
            assert_eq!(symbol.as_str(), text);
            assert_eq!(symbol.to_string(), text);
        }
        let a = StxSymbol::new("alpha").unwrap();
        let b = StxSymbol::new("alpha").unwrap();
        assert_eq!(a, b);
        assert_ne!(a, StxSymbol::new("beta").unwrap());
    }

    #[test]
    fn valid_symbols_accept_unicode_cjk() {
        // The floor must not constrain the future reader grammar: CJK
        // identifiers stay legal until the 0.3 grammar rules on them.
        let symbol = StxSymbol::new("计数器").expect("CJK identifier passes the floor");
        assert_eq!(symbol.as_str(), "计数器");
    }

    // ---------- negative ----------

    #[test]
    fn new_rejects_empty() {
        let err = StxSymbol::new("").expect_err("empty symbol must be rejected");
        assert_eq!(
            err,
            SyntaxError::InvalidSymbol {
                text: String::new()
            }
        );
    }

    #[test]
    fn new_rejects_space_only() {
        assert!(matches!(
            StxSymbol::new(" "),
            Err(SyntaxError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn new_rejects_interior_space() {
        assert!(matches!(
            StxSymbol::new("a b"),
            Err(SyntaxError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn new_rejects_interior_tab() {
        assert!(matches!(
            StxSymbol::new("a\tb"),
            Err(SyntaxError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn new_rejects_leading_space() {
        assert!(matches!(
            StxSymbol::new(" x"),
            Err(SyntaxError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn new_rejects_trailing_space() {
        assert!(matches!(
            StxSymbol::new("x "),
            Err(SyntaxError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn new_rejects_nul_control() {
        assert!(matches!(
            StxSymbol::new("a\u{0}b"),
            Err(SyntaxError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn new_rejects_unicode_whitespace() {
        // Unicode whitespace (NBSP) is whitespace for the floor too —
        // `char::is_whitespace` is Unicode-aware.
        assert!(matches!(
            StxSymbol::new("a\u{a0}b"),
            Err(SyntaxError::InvalidSymbol { .. })
        ));
    }
}

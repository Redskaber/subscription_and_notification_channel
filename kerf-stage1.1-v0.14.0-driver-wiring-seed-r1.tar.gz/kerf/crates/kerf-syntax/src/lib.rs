//! kerf-syntax — the SyntaxObject model (Layer 1).
//!
//! Charter (docs/stage0.md §3.3): every piece of surface syntax carries a
//! real span (never `Option`, never a dummy — the TD-004 discipline), a
//! scope set and a phase — the hygiene foundation consumed by the reader
//! (Layer 2, plan sub-stage 0.3) and the expander (Layer 3, plan
//! sub-stage 0.4). §7.3.6 positions the datum as the "extended
//! S-expression" (skeleton + per-node enhancements — Racket's industrial
//! proof); the skeleton is the Stage 0 bootstrap-parser scaffold (SOP
//! §2.5, choice A of the six-dimension ruling), removed from the
//! bootstrap chain at Stage 2b — never a permanent internal IR.
//!
//! Naming (SOP §21.12): syntax-object family types carry the `Stx`
//! prefix (`StxDatum`, `StxSymbol`); cross-stage ID types carry none
//! (`ScopeId`, `ScopeSet` — same family as `Span`/`FileId`).

mod error;
mod expr;
mod phase;
mod scope;
mod symbol;

// Explicit re-export list (SOP §10.1 rule 4 — glob re-exports are forbidden).
pub use error::SyntaxError;
pub use expr::{StxDatum, SyntaxObject};
pub use phase::Phase;
pub use scope::{ScopeId, ScopeSet};
pub use symbol::StxSymbol;

/// Re-exported because every public node type in this crate mentions it
/// (consumers must not depend on kerf-span directly to build syntax
/// objects).
pub use kerf_span::ExpansionId;
pub use kerf_span::Span;

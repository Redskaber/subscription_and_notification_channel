//! Lexer: source text → typed token stream (docs/stage0.md §8.1).
//!
//! Interface contract (§8.1 `tokenize` guarantees, all honored):
//! the emitted tokens losslessly cover the input (the gaps between
//! consecutive token spans are exactly the skipped whitespace and
//! `;` comments), every token carries a precise byte span, and lexical
//! failures return the structured [`ReadError`] with a byte-precise
//! location — never a panic, never a silent fallback.
//!
//! Atom terminators follow the standard Lisp reader: whitespace, `(`,
//! `)`, `"` and `;`. Whitespace is Unicode-aware plus the BOM
//! `\u{feff}` (invisible format character — skipped like whitespace
//! rather than glued into identifiers). Numbers follow Rust `i64` /
//! `f64` parse semantics; number-shaped atoms that parse as neither
//! are rejected (no Racket-style symbol fallback — SOP §2.3-4).

use crate::error::ReadError;
use crate::token::{Delimiter, StxToken, StxTokenKind};
use kerf_span::{ByteOffset, ExpansionId, FileId, Span};
use kerf_syntax::StxSymbol;

/// Lex `source` into a typed token stream ending with one `Eof` token.
///
/// The `file_id` stamps every span (docs/stage0.md §12.1 — byte
/// offsets; the session/file interner lands with the 0.8 driver).
pub fn lex(file_id: FileId, source: &str) -> Result<Vec<StxToken>, ReadError> {
    let mut lexer = Lexer {
        file_id,
        source,
        pos: 0,
    };
    let mut tokens = Vec::new();
    loop {
        lexer.skip_trivia()?;
        if lexer.pos >= lexer.source.len() {
            let end = lexer.pos;
            tokens.push(StxToken {
                kind: StxTokenKind::Eof,
                span: lexer.span(end, end),
            });
            return Ok(tokens);
        }
        tokens.push(lexer.next_token()?);
    }
}

struct Lexer<'a> {
    file_id: FileId,
    source: &'a str,
    /// Current byte position (always on a char boundary).
    pos: usize,
}

impl<'a> Lexer<'a> {
    /// Whitespace (Unicode-aware, plus BOM) and `;` line comments.
    fn skip_trivia(&mut self) -> Result<(), ReadError> {
        loop {
            let Some(ch) = self.peek_char() else {
                return Ok(());
            };
            if ch.is_whitespace() || ch == '\u{feff}' {
                self.advance(ch);
            } else if ch == ';' {
                while let Some(c) = self.peek_char() {
                    if c == '\n' {
                        break;
                    }
                    self.advance(c);
                }
            } else {
                return Ok(());
            }
        }
    }

    fn next_token(&mut self) -> Result<StxToken, ReadError> {
        let start = self.pos;
        let first = self.peek_char().expect("caller checked non-end");
        match first {
            '(' => {
                self.advance('(');
                Ok(self.token(Delimiter::Open, start))
            }
            ')' => {
                self.advance(')');
                Ok(self.token(Delimiter::Close, start))
            }
            '"' => self.lex_string(start),
            '[' | ']' | '{' | '}' | '`' | '\'' | ',' => {
                // No meaning in the Stage 0 skin: brackets are not
                // delimiters here and no reader macros exist —
                // fail-closed instead of silently lexing weird symbols.
                Err(ReadError::UnexpectedCharacter {
                    character: first,
                    at: ByteOffset(start as u32),
                })
            }
            _ => self.lex_atom(start),
        }
    }

    /// String literal: `"..."` with escapes `\"` `\\` `\n` `\t` `\r`;
    /// raw newlines are legal (Scheme tradition); unterminated input
    /// fails with the start offset.
    fn lex_string(&mut self, start: usize) -> Result<StxToken, ReadError> {
        self.advance('"');
        let mut value = String::new();
        loop {
            let Some(ch) = self.peek_char() else {
                return Err(ReadError::UnterminatedString {
                    started_at: ByteOffset(start as u32),
                });
            };
            match ch {
                '"' => {
                    self.advance('"');
                    return Ok(StxToken {
                        kind: StxTokenKind::StringLiteral(value),
                        span: self.span(start, self.pos),
                    });
                }
                '\\' => {
                    self.advance('\\');
                    let escape_at = self.pos;
                    let Some(escaped) = self.peek_char() else {
                        return Err(ReadError::UnterminatedString {
                            started_at: ByteOffset(start as u32),
                        });
                    };
                    let decoded = match escaped {
                        '"' => '"',
                        '\\' => '\\',
                        'n' => '\n',
                        't' => '\t',
                        'r' => '\r',
                        other => {
                            return Err(ReadError::InvalidEscape {
                                escape: other,
                                at: ByteOffset(escape_at as u32),
                            });
                        }
                    };
                    value.push(decoded);
                    self.advance(escaped);
                }
                _ => {
                    value.push(ch);
                    self.advance(ch);
                }
            }
        }
    }

    /// Atom: identifier, boolean, or number — collected up to the next
    /// terminator (whitespace, `(`, `)`, `"`, `;`) or end of input.
    fn lex_atom(&mut self, start: usize) -> Result<StxToken, ReadError> {
        let mut text = String::new();
        while let Some(ch) = self.peek_char() {
            if ch.is_whitespace() || ch == '\u{feff}' || matches!(ch, '(' | ')' | '"' | ';') {
                break;
            }
            text.push(ch);
            self.advance(ch);
        }
        let span = self.span(start, self.pos);
        if let Some(kind) = classify_atom(&text)? {
            Ok(StxToken { kind, span })
        } else {
            // classify_atom rejects empty text; an atom run starting at
            // a non-terminator always consumes at least one char, so
            // this arm is unreachable by construction.
            unreachable!("atom run always consumes at least one character");
        }
    }

    fn peek_char(&self) -> Option<char> {
        self.source[self.pos..].chars().next()
    }

    fn advance(&mut self, ch: char) {
        self.pos += ch.len_utf8();
    }

    fn token(&self, delimiter: Delimiter, start: usize) -> StxToken {
        StxToken {
            kind: StxTokenKind::Delimiter(delimiter),
            span: self.span(start, self.pos),
        }
    }

    fn span(&self, start: usize, end: usize) -> Span {
        Span::new(
            self.file_id,
            ByteOffset(start as u32),
            ByteOffset(end as u32),
            ExpansionId::ROOT,
        )
        .expect("lexer spans are well-ordered by construction")
    }
}

/// Classify one atom's text: `Some(kind)` or a lexical error.
///
/// `None` only for empty text (unreachable from [`Lexer::lex_atom`]).
fn classify_atom(text: &str) -> Result<Option<StxTokenKind>, ReadError> {
    if text.is_empty() {
        return Ok(None);
    }
    if text.starts_with('#') {
        return match text {
            "#t" => Ok(Some(StxTokenKind::BoolLiteral(true))),
            "#f" => Ok(Some(StxTokenKind::BoolLiteral(false))),
            _ => Err(ReadError::InvalidBool {
                text: text.to_owned(),
            }),
        };
    }
    if is_number_shaped(text) {
        if let Ok(v) = text.parse::<i64>() {
            return Ok(Some(StxTokenKind::IntLiteral(v)));
        }
        if let Ok(v) = text.parse::<f64>() {
            return Ok(Some(StxTokenKind::FloatLiteral(v)));
        }
        return Err(ReadError::MalformedNumber {
            text: text.to_owned(),
        });
    }
    match StxSymbol::new(text) {
        Ok(symbol) => Ok(Some(StxTokenKind::Identifier(symbol))),
        Err(_) => Err(ReadError::InvalidSymbol {
            text: text.to_owned(),
        }),
    }
}

/// Number-shaped: leading ASCII digit; or `+`/`-`/`.` immediately
/// followed by an ASCII digit (so `+`, `-`, `...`, `nil?` stay
/// identifiers while `-7`, `.5`, `+3` are numbers).
fn is_number_shaped(text: &str) -> bool {
    let bytes = text.as_bytes();
    let first = bytes[0];
    if first.is_ascii_digit() {
        return true;
    }
    if matches!(first, b'+' | b'-' | b'.') {
        return bytes.len() > 1 && bytes[1].is_ascii_digit();
    }
    false
}

#[cfg(test)]
mod tests {
    //! Unit tests for the lexer feature point (sub-stage test doc FP1).
    //! CJK fixture note (SOP §10.5 registered whitelist): the
    //! `symbols_accept_unicode_cjk` case uses CJK *as the tested
    //! object* (atom acceptance), which is the sanctioned fixture
    //! category.

    use super::*;
    use crate::token::StxTokenKind as K;

    fn file() -> FileId {
        FileId(0)
    }

    fn kinds(src: &str) -> Vec<StxTokenKind> {
        lex(file(), src)
            .expect("lexing must succeed")
            .into_iter()
            .map(|t| t.kind)
            .collect()
    }

    // ---------- positive ----------

    #[test]
    fn lexes_mixed_program_all_kinds() {
        let tokens = lex(file(), "(add 1 2.5 #t \"s\")").expect("mixed program lexes");
        let kinds: Vec<&str> = tokens.iter().map(|t| t.kind_name()).collect();
        assert_eq!(
            kinds,
            vec![
                "delimiter",
                "identifier",
                "int",
                "float",
                "bool",
                "string",
                "delimiter",
                "eof"
            ]
        );
        let spans: Vec<(u32, u32)> = tokens
            .iter()
            .map(|t| (t.span.start.0, t.span.end.0))
            .collect();
        assert_eq!(
            spans,
            vec![
                (0, 1),
                (1, 4),
                (5, 6),
                (7, 10),
                (11, 13),
                (14, 17),
                (17, 18),
                (18, 18)
            ]
        );
    }

    #[test]
    fn numbers_follow_rust_parse_semantics() {
        let kinds = kinds(".5 1. 1e5 +3 -7 42");
        assert_eq!(
            kinds,
            vec![
                K::FloatLiteral(0.5),
                K::FloatLiteral(1.0),
                K::FloatLiteral(100000.0),
                K::IntLiteral(3),
                K::IntLiteral(-7),
                K::IntLiteral(42),
                K::Eof
            ]
        );
    }

    #[test]
    fn symbols_accept_unicode_cjk_and_specials() {
        // Symbols that must NOT be number-shaped: `+`, `-`, `...`,
        // `nil?`, `set!`, CJK identifiers.
        let kinds = kinds("+ - ... nil? set! 计数器");
        let names: Vec<&str> = kinds
            .iter()
            .map(|k| match k {
                K::Identifier(s) => s.as_str(),
                K::Eof => "eof",
                _ => "other",
            })
            .collect();
        assert_eq!(
            names,
            vec!["+", "-", "...", "nil?", "set!", "计数器", "eof"]
        );
    }

    #[test]
    fn comments_and_whitespace_are_skipped_losslessly() {
        let src = "; header\n ( f ; inline\n 1 ) ; tail";
        let tokens = lex(file(), src).expect("commented source lexes");
        let names: Vec<&str> = tokens.iter().map(|t| t.kind_name()).collect();
        assert_eq!(
            names,
            vec!["delimiter", "identifier", "int", "delimiter", "eof"]
        );
        // Lossless coverage: the slice between consecutive token spans
        // is exactly the skipped trivia — whitespace runs and `;`
        // comments (possibly several, possibly trailing without a
        // newline).
        for pair in tokens.windows(2) {
            let gap = &src[bytes_of(src, pair[0].span.end.0)..bytes_of(src, pair[1].span.start.0)];
            let mut rest = gap;
            loop {
                let trimmed = rest.trim_start();
                if trimmed.is_empty() {
                    break;
                }
                assert!(
                    trimmed.starts_with(';'),
                    "gap must be whitespace or comment trivia, got {gap:?}"
                );
                let line_end = trimmed.find('\n').unwrap_or(trimmed.len());
                rest = &trimmed[line_end..];
            }
        }
    }

    /// Map a byte offset back to a `str` slice index for gap inspection
    /// (offsets in this fixture are ASCII-only, so index == offset).
    fn bytes_of(src: &str, offset: u32) -> usize {
        let idx = offset as usize;
        assert!(src.is_char_boundary(idx), "fixture is ASCII at {idx}");
        idx
    }

    #[test]
    fn string_escapes_decode() {
        // Source: "a\n\t\r\\\"b" written as a Rust escaped literal.
        let kinds = kinds("\"a\\n\\t\\r\\\\\\\"b\"");
        assert_eq!(
            kinds,
            vec![K::StringLiteral("a\n\t\r\\\"b".to_owned()), K::Eof]
        );
    }

    #[test]
    fn eof_token_is_empty_and_bom_is_skipped() {
        let tokens = lex(file(), "\u{feff}x\u{feff}").expect("BOM-only trivia lexes");
        // BOM + `x` + BOM: both BOMs skip, `x` is the only token.
        assert_eq!(tokens.len(), 2);
        assert_eq!(tokens[0].kind_name(), "identifier");
        assert_eq!((tokens[0].span.start.0, tokens[0].span.end.0), (3, 4));
        assert_eq!(tokens[1].kind, K::Eof);
        assert!(tokens[1].span.is_empty());
        // Empty source: just Eof.
        let empty = lex(file(), "").expect("empty source lexes");
        assert_eq!(empty.len(), 1);
        assert_eq!(empty[0].kind, K::Eof);
    }

    // ---------- negative ----------

    #[test]
    fn rejects_unterminated_string() {
        let err = lex(file(), "\"abc").expect_err("unterminated string must fail");
        assert_eq!(
            err,
            ReadError::UnterminatedString {
                started_at: ByteOffset(0)
            }
        );
    }

    #[test]
    fn rejects_invalid_escape() {
        let err = lex(file(), "\"a\\x\"").expect_err("unknown escape must fail");
        assert_eq!(
            err,
            ReadError::InvalidEscape {
                escape: 'x',
                at: ByteOffset(3)
            }
        );
    }

    #[test]
    fn rejects_unknown_hash_atom() {
        let err = lex(file(), "#q").expect_err("unknown hash atom must fail");
        assert_eq!(
            err,
            ReadError::InvalidBool {
                text: "#q".to_owned()
            }
        );
    }

    #[test]
    fn rejects_long_bool_spelling() {
        // The Stage 0 skin defines exactly `#t` / `#f` — `#true` is
        // fail-closed, not silently accepted.
        let err = lex(file(), "#true").expect_err("long bool spelling must fail");
        assert_eq!(
            err,
            ReadError::InvalidBool {
                text: "#true".to_owned()
            }
        );
    }

    #[test]
    fn rejects_multi_dot_number() {
        let err = lex(file(), "1.2.3").expect_err("multi-dot number must fail");
        assert_eq!(
            err,
            ReadError::MalformedNumber {
                text: "1.2.3".to_owned()
            }
        );
    }

    #[test]
    fn rejects_digit_prefixed_symbol() {
        let err = lex(file(), "12abc").expect_err("digit-prefixed symbol must fail");
        assert_eq!(
            err,
            ReadError::MalformedNumber {
                text: "12abc".to_owned()
            }
        );
    }

    #[test]
    fn rejects_hex_prefixed_number() {
        let err = lex(file(), "0x1F").expect_err("hex literal must fail");
        assert_eq!(
            err,
            ReadError::MalformedNumber {
                text: "0x1F".to_owned()
            }
        );
    }

    #[test]
    fn rejects_underscored_number() {
        let err = lex(file(), "1_000").expect_err("underscored number must fail");
        assert_eq!(
            err,
            ReadError::MalformedNumber {
                text: "1_000".to_owned()
            }
        );
    }

    #[test]
    fn rejects_dangling_exponent() {
        let err = lex(file(), "1e").expect_err("dangling exponent must fail");
        assert_eq!(
            err,
            ReadError::MalformedNumber {
                text: "1e".to_owned()
            }
        );
    }

    #[test]
    fn rejects_control_char_atom() {
        let err = lex(file(), "a\u{0}b").expect_err("control char atom must fail");
        assert_eq!(
            err,
            ReadError::InvalidSymbol {
                text: "a\u{0}b".to_owned()
            }
        );
    }

    #[test]
    fn rejects_bracket_characters() {
        for src in ["[", "]", "{", "}"] {
            let ch = src.chars().next().expect("one char");
            let err = lex(file(), src).expect_err("brackets have no Stage 0 meaning");
            assert_eq!(
                err,
                ReadError::UnexpectedCharacter {
                    character: ch,
                    at: ByteOffset(0)
                }
            );
        }
    }

    #[test]
    fn rejects_reader_macro_characters() {
        for src in ["`", "'", ","] {
            let ch = src.chars().next().expect("one char");
            let err = lex(file(), src).expect_err("reader macros do not exist in Stage 0");
            assert_eq!(
                err,
                ReadError::UnexpectedCharacter {
                    character: ch,
                    at: ByteOffset(0)
                }
            );
        }
    }

    #[test]
    fn rejects_lone_hash_atom() {
        // `#` alone starts a hash atom but matches neither `#t` nor
        // `#f` — fail-closed, not a symbol.
        let err = lex(file(), "#").expect_err("lone hash must fail");
        assert_eq!(
            err,
            ReadError::InvalidBool {
                text: "#".to_owned()
            }
        );
    }

    #[test]
    fn rejects_escape_at_end_of_input() {
        // `"a\` — the escape backslash runs into end of input: the
        // string (already open) is unterminated.
        let err = lex(file(), "\"a\\").expect_err("escape at end of input must fail");
        assert_eq!(
            err,
            ReadError::UnterminatedString {
                started_at: ByteOffset(0)
            }
        );
    }

    #[test]
    fn atom_boundaries_are_lisp_terminators() {
        // `a"b"` = symbol `a` followed by string "b"; `x;y` = symbol `x`
        // then a comment — positive adjacency check that also pins the
        // terminator set used by the negative cases above.
        let kinds = kinds("a\"b\"");
        assert_eq!(
            kinds,
            vec![
                K::Identifier(StxSymbol::new("a").expect("valid symbol")),
                K::StringLiteral("b".to_owned()),
                K::Eof
            ]
        );
        let tokens = lex(file(), "x;y\nz").expect("comment-adjacent atoms lex");
        let names: Vec<&str> = tokens.iter().map(|t| t.kind_name()).collect();
        assert_eq!(names, vec!["identifier", "identifier", "eof"]);
    }
}

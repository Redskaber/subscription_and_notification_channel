//! StxToken: the typed token stream of the S-expression skin (Layer 2).
//!
//! Capability model: docs/stage0.md §8.1 (typed token stream — TokenKind
//! carries the atom type; every token carries a precise span; the stream
//! losslessly covers the input). The Stage 0 S-expression skin produces
//! the subset `Delimiter / Identifier / IntLiteral / FloatLiteral /
//! BoolLiteral / StringLiteral / Eof`; the modern-skin kinds
//! (`TypeIdentifier`, `Keyword`, `Operator`, `MacroInvocation`) arrive
//! additively with the Stage 2 skin (SOP principle 27 — no speculative
//! variants before their consumer exists).
//!
//! Naming: SOP §21.12-3 — syntax-object family types carry the `Stx`
//! prefix (`StxToken`, `SyntaxObject`).

use std::fmt;

use kerf_span::Span;
use kerf_syntax::StxSymbol;

/// One list delimiter of the S-expression skin: `(` or `)`.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Delimiter {
    /// Opening `(`.
    Open,
    /// Closing `)`.
    Close,
}

impl Delimiter {
    /// Stable diagnostic name.
    pub fn kind_name(&self) -> &'static str {
        match self {
            Delimiter::Open => "open",
            Delimiter::Close => "close",
        }
    }
}

impl fmt::Display for Delimiter {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(match self {
            Delimiter::Open => "(",
            Delimiter::Close => ")",
        })
    }
}

/// The typed kind of one token (docs/stage0.md §8.1 `TokenKind`, Stage 0
/// S-expression subset).
#[derive(Debug, Clone, PartialEq)]
pub enum StxTokenKind {
    /// A list delimiter.
    Delimiter(Delimiter),
    /// An identifier atom (payload validated by the [`StxSymbol`]
    /// floor at lexing time).
    Identifier(StxSymbol),
    /// An integer literal atom.
    IntLiteral(i64),
    /// A floating-point literal atom (Rust `f64` parse semantics —
    /// `.5`, `1.`, `1e5` are all floats).
    FloatLiteral(f64),
    /// A boolean literal atom: `#t` or `#f`.
    BoolLiteral(bool),
    /// A string literal atom (escapes already decoded).
    StringLiteral(String),
    /// End of input; the span is empty and sits at the end offset.
    Eof,
}

impl StxTokenKind {
    /// Stable diagnostic name (lowercase, one word — mirrors the
    /// `kind_name` conventions of the syntax and core layers).
    pub fn kind_name(&self) -> &'static str {
        match self {
            StxTokenKind::Delimiter(_) => "delimiter",
            StxTokenKind::Identifier(_) => "identifier",
            StxTokenKind::IntLiteral(_) => "int",
            StxTokenKind::FloatLiteral(_) => "float",
            StxTokenKind::BoolLiteral(_) => "bool",
            StxTokenKind::StringLiteral(_) => "string",
            StxTokenKind::Eof => "eof",
        }
    }
}

impl fmt::Display for StxTokenKind {
    /// Source-shaped rendering (the token text as it appears in the
    /// source, modulo escape decoding).
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            StxTokenKind::Delimiter(d) => write!(f, "{d}"),
            StxTokenKind::Identifier(s) => f.write_str(s.as_str()),
            StxTokenKind::IntLiteral(v) => write!(f, "{v}"),
            StxTokenKind::FloatLiteral(v) => write!(f, "{v:?}"),
            StxTokenKind::BoolLiteral(v) => write!(f, "#{}", if *v { "t" } else { "f" }),
            StxTokenKind::StringLiteral(v) => write!(f, "{v:?}"),
            StxTokenKind::Eof => f.write_str("end of input"),
        }
    }
}

/// One typed token: kind + precise source span (docs/stage0.md §8.1 —
/// the span is byte-precise; multi-byte characters occupy their full
/// byte range).
#[derive(Debug, Clone, PartialEq)]
pub struct StxToken {
    pub kind: StxTokenKind,
    pub span: Span,
}

impl StxToken {
    /// Stable diagnostic name (delegates to the kind).
    pub fn kind_name(&self) -> &'static str {
        self.kind.kind_name()
    }
}

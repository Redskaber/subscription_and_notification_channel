//! The mark-sweep collector (docs/stage0.md §19.4) — Layer 7's
//! three-phase orchestration over the kerf-vm heap face.
//!
//! Phase order per the §19.4 skeleton: `mark_all` (an EXPLICIT work
//! stack, never Rust recursion — a 10^7-deep chain must not overflow
//! the host stack) → `sweep` (unmarked cells return to the free list;
//! the conservative policy tolerates leaks, never false reclaims) →
//! `clear_marks` (every slot, swept ones included — the
//! reset-symmetry invariant). Root completeness is the caller's
//! contract: [`Roots`] carries the four §19.4 classes.
//!
//! The collector owns no heap state: mark bits and the free list live
//! on the heap (kerf-vm), the algorithm lives here (dependency
//! inversion — SOP §21.12-10②). [`MarkSweep`] implements the
//! kerf-vm [`Collector`] trait so the VM's budget safety point can
//! inject collect-then-retry; [`collect`] is the standalone face for
//! the evaluator and explicit host cycles.

use kerf_vm::{Collector, Heap, HeapObj, Roots, Value};

/// One cycle's accounting (assertion and calibration face).
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct GcStats {
    /// Cells the mark phase reached.
    pub marked: u32,
    /// Cells the sweep phase reclaimed.
    pub swept: u32,
    /// Live cells before the cycle.
    pub live_before: u32,
    /// Live cells after the cycle.
    pub live_after: u32,
}

/// The §19.4 mark-sweep algorithm (stateless between cycles).
#[derive(Debug, Clone, Default)]
pub struct MarkSweep;

impl MarkSweep {
    /// One `gc_cycle` — the standalone face (evaluator heaps, host
    /// cycles between programs, tests).
    pub fn cycle(&mut self, heap: &mut Heap, roots: &Roots) -> GcStats {
        collect(heap, roots)
    }
}

impl Collector for MarkSweep {
    fn collect(&mut self, heap: &mut Heap, roots: &Roots) -> u32 {
        collect(heap, roots).swept
    }
}

/// Run one full §19.4 cycle: mark from the roots over an explicit
/// work stack, sweep the unmarked, reset every mark bit.
pub fn collect(heap: &mut Heap, roots: &Roots) -> GcStats {
    let live_before = heap.live_len() as u32;
    let marked = mark_all(heap, roots);
    let swept = sweep(heap);
    heap.clear_marks();
    GcStats {
        marked,
        swept,
        live_before,
        live_after: heap.live_len() as u32,
    }
}

/// Phase 1: mark every root-reachable cell. The work list is an
/// explicit stack (the §19.4 recursion-overflow trap: mark depth
/// equals the longest reference chain, which host recursion cannot
/// bound). Returns the number of cells marked in THIS cycle.
fn mark_all(heap: &mut Heap, roots: &Roots) -> u32 {
    let mut work: Vec<Value> = roots.iter_values().cloned().collect();
    let mut marked = 0u32;
    while let Some(value) = work.pop() {
        let r = match value {
            Value::Pair(r) | Value::Closure(r) => r,
            _ => continue, // immediates reference no heap cell
        };
        if !heap.is_live(r) {
            // A dead reference can only come from a caller bug (roots
            // snapshot older than a manual sweep); skip rather than
            // poison the cycle.
            continue;
        }
        if heap.test_and_set_mark(r) {
            continue; // already marked this cycle
        }
        marked += 1;
        // Push the cell's children (pair arms; closure env slots).
        match heap.get(r) {
            Some(HeapObj::Pair(a, b)) => {
                work.push(a.clone());
                work.push(b.clone());
            }
            Some(HeapObj::Closure(data)) => {
                work.extend(data.env.iter().cloned());
            }
            None => unreachable!("is_live filtered dead references"),
        }
    }
    marked
}

/// Phase 2: sweep — every unmarked live cell returns to the free
/// list (§19.4 conservative policy: a leak is tolerable, a false
/// reclaim never is). Returns the number of reclaimed cells.
fn sweep(heap: &mut Heap) -> u32 {
    let mut swept = 0u32;
    let mut r = 0u32;
    while (r as usize) < heap.total_slots() {
        let live = heap.is_live(r);
        let marked = heap.is_marked(r);
        if live && !marked {
            heap.free(r);
            swept += 1;
        }
        r += 1;
    }
    swept
}

#[cfg(test)]
mod tests {
    //! Collector tests (FP1): the three phases, the four root classes,
    //! free-list reuse, cycle idempotence, and the §19.4 traps.

    use super::*;
    use kerf_vm::{HeapObj, HeapRef};

    fn pair(heap: &mut Heap, a: Value, b: Value) -> Value {
        Value::Pair(heap.alloc(HeapObj::Pair(a, b)))
    }

    fn roots(values: &[Value]) -> Roots {
        Roots {
            stack: values.to_vec(),
            ..Roots::empty()
        }
    }

    #[test]
    fn cycle_reclaims_unreachable_and_retains_reachable_set() {
        // reachable chain + two orphans: only the orphans sweep.
        let mut heap = Heap::default();
        let tail = pair(&mut heap, Value::Int(2), Value::Nil);
        let head = pair(&mut heap, Value::Int(1), tail);
        pair(&mut heap, Value::Int(9), Value::Nil); // orphan 1
        pair(&mut heap, Value::Int(8), Value::Nil); // orphan 2
        assert_eq!(heap.live_len(), 4);

        let stats = collect(&mut heap, &roots(std::slice::from_ref(&head)));
        assert_eq!(stats.marked, 2);
        assert_eq!(stats.swept, 2);
        assert_eq!(stats.live_before, 4);
        assert_eq!(stats.live_after, 2);
        // Structure survives verbatim (tail occupies slot 0, head 1).
        let (a, rest) = head.as_pair(&heap).expect("head pair");
        assert_eq!(a, &Value::Int(1));
        assert_eq!(rest, &Value::Pair(0));
    }

    #[test]
    fn no_roots_sweeps_everything() {
        let mut heap = Heap::default();
        pair(&mut heap, Value::Int(1), Value::Nil);
        pair(&mut heap, Value::Int(2), Value::Nil);
        let stats = collect(&mut heap, &Roots::empty());
        assert_eq!(stats.swept, 2);
        assert!(heap.is_empty());
        assert_eq!(heap.live_len(), 0);
        // Total slots stay (arena never shrinks — no compaction at
        // Stage 0, §19.4 "allocate-only, no compaction").
        assert_eq!(heap.total_slots(), 2);
    }

    #[test]
    fn deep_chain_marks_without_host_recursion() {
        // 10^5-deep chain: the explicit work stack must survive what
        // Rust recursion could not reliably (the §19.4 trap).
        let mut heap = Heap::default();
        let mut node = Value::Nil;
        for i in 0..100_000 {
            node = pair(&mut heap, Value::Int(i), node);
        }
        let stats = collect(&mut heap, &roots(&[node]));
        assert_eq!(stats.marked, 100_000);
        assert_eq!(stats.swept, 0);
    }

    #[test]
    fn cyclic_structure_terminates_and_retains() {
        // A self-referencing pair: test_and_set dedup ends the walk.
        let mut heap = Heap::default();
        let r: HeapRef = heap.alloc(HeapObj::Pair(Value::Int(1), Value::Nil));
        // car points back at the cell itself — a cycle.
        let cell = heap.get_mut(r).expect("live cell");
        if let HeapObj::Pair(a, _) = cell {
            *a = Value::Pair(r);
        }
        let stats = collect(&mut heap, &roots(&[Value::Pair(r)]));
        assert_eq!(stats.marked, 1);
        assert_eq!(stats.swept, 0);
        assert!(heap.is_live(r));
    }

    #[test]
    fn second_cycle_on_clean_heap_sweeps_nothing() {
        // Reset symmetry: after a clean cycle every mark bit is false
        // again, so an immediate second cycle is a no-op.
        let mut heap = Heap::default();
        let p = pair(&mut heap, Value::Int(1), Value::Nil);
        pair(&mut heap, Value::Int(2), Value::Nil);
        collect(&mut heap, &roots(std::slice::from_ref(&p)));
        let stats = collect(&mut heap, &roots(std::slice::from_ref(&p)));
        assert_eq!(stats.swept, 0);
        assert_eq!(stats.marked, 1);
        assert_eq!(stats.live_after, 1);
    }

    #[test]
    fn swept_slots_are_reused_lifo_and_read_as_none() {
        let mut heap = Heap::default();
        let a = pair(&mut heap, Value::Int(1), Value::Nil);
        let _b = pair(&mut heap, Value::Int(2), Value::Nil);
        let b_ref = match &_b {
            Value::Pair(r) => *r,
            _ => unreachable!("fixture pair"),
        };
        collect(&mut heap, &roots(&[a]));
        assert!(heap.get(b_ref).is_none()); // swept slot reads None
        assert!(!heap.is_live(b_ref));
        // The next allocation reuses the swept slot (free-list LIFO).
        let c = pair(&mut heap, Value::Int(3), Value::Nil);
        match c {
            Value::Pair(r) => assert_eq!(r, b_ref),
            _ => unreachable!("fixture pair"),
        }
        assert_eq!(heap.live_len(), 2);
    }

    #[test]
    fn all_four_root_classes_retain_their_values() {
        // §19.4 invariant 1: each root class alone must retain its
        // value — dropping any class means dangling references.
        let mut heap = Heap::default();
        let mk = |heap: &mut Heap| pair(heap, Value::Int(7), Value::Nil);
        let v_stack = mk(&mut heap);
        let v_locals = mk(&mut heap);
        let v_globals = mk(&mut heap);
        let v_foreign = mk(&mut heap);
        let v_handler = mk(&mut heap);
        let roots = Roots {
            stack: vec![v_stack],
            locals: vec![v_locals],
            globals: vec![v_globals],
            foreign: vec![v_foreign],
            handlers: vec![v_handler],
        };
        let stats = collect(&mut heap, &roots);
        assert_eq!(stats.marked, 5);
        assert_eq!(stats.swept, 0);
        assert_eq!(heap.live_len(), 5);
    }

    #[test]
    fn closure_env_is_marked_through() {
        // A closure's captured env slots are heap children (the §19.5
        // capture face — dormant at Stage 0 but still reachable).
        let mut heap = Heap::default();
        let inner = pair(&mut heap, Value::Int(5), Value::Nil);
        let closure = Value::Closure(heap.alloc(HeapObj::Closure(kerf_vm::ClosureData {
            proto: 0,
            env: vec![inner],
        })));
        // inner is NOT a root; only the closure keeps it alive.
        let stats = collect(&mut heap, &roots(&[closure]));
        assert_eq!(stats.marked, 2);
        assert_eq!(stats.swept, 0);
    }
    #[test]
    fn all_live_heap_sweeps_zero_cells() {
        // The false-reclaim guard: every cell reachable -> swept must
        // be exactly zero (§19.4: reclaiming a live object is never
        // tolerable, a leak merely detectable).
        let mut heap = Heap::default();
        let a = pair(&mut heap, Value::Int(1), Value::Nil);
        let b = pair(&mut heap, Value::Int(2), a.clone());
        let c = pair(&mut heap, b.clone(), Value::Nil);
        let stats = collect(&mut heap, &roots(&[c]));
        assert_eq!(stats.swept, 0);
        assert_eq!(stats.live_after, 3);
        assert_eq!(stats.marked, 3);
    }

    #[test]
    fn dangling_root_reference_is_skipped_not_panic() {
        // A root pointing at an already-swept slot (only possible
        // through a caller bug like a stale snapshot): the mark phase
        // skips it instead of poisoning the cycle.
        let mut heap = Heap::default();
        let r = match pair(&mut heap, Value::Int(1), Value::Nil) {
            Value::Pair(r) => r,
            _ => unreachable!("fixture pair"),
        };
        collect(&mut heap, &Roots::empty()); // everything swept
        let stale = Roots {
            stack: vec![Value::Pair(r)],
            ..Roots::empty()
        };
        let stats = collect(&mut heap, &stale); // must not panic
        assert_eq!(stats.swept, 0);
        assert_eq!(stats.marked, 0);
    }

    #[test]
    fn empty_heap_cycle_is_a_clean_noop() {
        let mut heap = Heap::default();
        let stats = collect(&mut heap, &Roots::empty());
        assert_eq!(
            (
                stats.marked,
                stats.swept,
                stats.live_before,
                stats.live_after
            ),
            (0, 0, 0, 0)
        );
        assert_eq!(heap.total_slots(), 0);
    }

    #[test]
    fn reuse_then_collect_again_stays_consistent() {
        // Reuse a swept slot, then run another cycle: the reused cell
        // is live and rooted, the count reflects exactly that (no
        // double counting through the free list).
        let mut heap = Heap::default();
        let keep = pair(&mut heap, Value::Int(1), Value::Nil);
        let dead = match pair(&mut heap, Value::Int(2), Value::Nil) {
            Value::Pair(r) => r,
            _ => unreachable!("fixture pair"),
        };
        collect(&mut heap, &roots(std::slice::from_ref(&keep)));
        assert!(!heap.is_live(dead));
        // Reuse the swept slot with a NEW value.
        let reused = pair(&mut heap, Value::Int(9), Value::Nil);
        assert_eq!(
            match reused {
                Value::Pair(r) => r,
                _ => unreachable!(),
            },
            dead
        );
        let stats = collect(&mut heap, &roots(&[keep, reused]));
        assert_eq!(stats.swept, 0);
        assert_eq!(stats.live_after, 2);
        // The reused slot reads its new payload.
        assert_eq!(
            heap.get(dead)
                .map(|o| matches!(o, HeapObj::Pair(Value::Int(9), _))),
            Some(true)
        );
    }
}

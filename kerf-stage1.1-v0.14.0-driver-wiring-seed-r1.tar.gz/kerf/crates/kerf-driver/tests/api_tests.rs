//! Crate API tests for kerf-driver (the public surface, exercised as
//! an external consumer would — stage-0-plan row 0.8, driver.md FP
//! cross-check).

use kerf_driver::{
    Command, Diagnostic, DiagnosticCode, Engine, LineIndex, Repl, ReplEvent, Session, check_source,
    parse_args, render_diagnostics, run_parity_source, run_source, version,
};

#[test]
fn public_surface_assembles_a_full_run() {
    let mut session = Session::new();
    let outcome = run_source(
        &mut session,
        "api.krf",
        "(define r (+ 20 22))",
        Engine::Vm,
        &[],
    )
    .expect("runs");
    assert_eq!(
        outcome.global("r").map(|v| v.to_string()),
        Some("42".to_owned())
    );
}

#[test]
fn public_surface_check_and_parity() {
    let mut session = Session::new();
    let check = check_source(&mut session, "c.krf", "(define r 1)").expect("checks");
    assert!(check.instr_count > 0);
    let report = run_parity_source(&mut session, "p.krf", "(define r 2)", &[]).expect("parity");
    assert!(report.agrees());
}

#[test]
fn public_surface_line_index_and_render() {
    let mut session = Session::new();
    let outcome = run_source(&mut session, "x.krf", "(nope)", Engine::Vm, &[]);
    let diags = outcome.expect_err("unbound identifier");
    let rendered = render_diagnostics(&session, &diags);
    assert!(rendered.starts_with("error[kerf-expand]:"));

    let idx = LineIndex::new("a\nb");
    assert_eq!(idx.line_count(), 2);
}

#[test]
fn public_surface_repl_and_cli() {
    let mut repl = Repl::new();
    match repl.submit("(+ 1 2)") {
        ReplEvent::Evaluated { value, .. } => assert_eq!(value.as_deref(), Some("3")),
        other => panic!("repl api: {other:?}"),
    }
    assert_eq!(
        parse_args(&["repl".to_owned()]).expect("parse"),
        Command::Repl
    );
    assert!(version().contains('.'));
}

#[test]
fn public_surface_error_enums_are_data() {
    // Diagnostics are constructible and comparable without any engine
    // running (errors are data — §12.2).
    let d = Diagnostic::driver_error("boom", kerf_driver::FileId(0), None);
    assert_eq!(d.code, DiagnosticCode::Driver);
    let session = Session::new();
    assert_eq!(
        render_diagnostics(&session, &[d]),
        "error[kerf-driver]: boom\n"
    );
}

#[test]
fn public_surface_engine_choice_routes_eval() {
    let mut session = Session::new();
    let outcome = run_source(
        &mut session,
        "e.krf",
        "(define r (* 7 6))",
        Engine::Eval,
        &[],
    )
    .expect("eval runs");
    assert_eq!(outcome.engine, Engine::Eval);
    assert_eq!(
        outcome.global("r").map(|v| v.to_string()),
        Some("42".to_owned())
    );
}

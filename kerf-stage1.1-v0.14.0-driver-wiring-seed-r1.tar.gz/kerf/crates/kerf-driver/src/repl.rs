//! The REPL state machine — session-replay semantics (plan-0.8
//! ruling, disclosed).
//!
//! Both engines are per-program by design (the 0.7 program-isolation
//! defense), so a persistent-session REPL cannot keep one engine
//! alive across submissions. Instead the REPL *accumulates source*:
//! every submission is appended (expressions wrapped as
//! `(define $repl:N expr)` — the r110 corpus note: the top-level
//! expression channel *is* the define calling form) and the whole
//! accumulated program re-runs per submission.
//!
//! Consequences (disclosed in the test doc §5):
//! - determinism first: the input tape is pre-seeded and immutable —
//!   re-runs replay it line-for-line; a `read-line` past the tape
//!   ends with `Eof` (interactive stdin consumption is the `run`
//!   mode's piped-stdin face, not the REPL's);
//! - output replay: each run reproduces the whole program's output;
//!   the REPL prints only the new tail when the previous output is a
//!   prefix (deterministic under the tape), everything otherwise;
//! - rollback: a failed submission never enters the accumulated
//!   program — the session stays usable after any error.

use kerf_reader::ReadError;
use kerf_syntax::{StxDatum, SyntaxObject};
use kerf_vm::VmIo;

use crate::diagnostic::Diagnostic;
use crate::pipeline::{self, Engine};
use crate::render::render_diagnostics;
use crate::session::Session;

/// What one submitted line produced.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ReplEvent {
    /// A blank line: nothing happened.
    Ignored,
    /// The input is incomplete (an unclosed list): keep reading.
    NeedMoreInput,
    /// The submission evaluated: the wrapped expression's value (when
    /// the submission contained an expression), the output lines
    /// not yet shown, and the warning renderings not yet shown (the
    /// same prefix-delta rule as outputs — the whole program re-runs
    /// per submission, so an unchanged warning must not re-print).
    Evaluated {
        value: Option<String>,
        new_outputs: Vec<String>,
        new_warnings: Vec<String>,
    },
    /// The submission failed: rendered diagnostics. The accumulated
    /// program was rolled back.
    Error { rendered: String },
}

/// The head symbols that make a top-level form a declaration; every
/// other form is an expression and gets wrapped into a define.
const DECLARATION_HEADS: [&str; 4] = ["define", "require", "module", "define-syntax"];

/// The REPL session state machine.
pub struct Repl {
    session: Session,
    name: String,
    /// Accepted accumulated source (the growing program).
    acc: String,
    /// Multi-line accumulation buffer (unclosed lists).
    pending: String,
    /// `$repl:N` counter (one per wrapped expression, monotonic).
    counter: usize,
    /// Pre-seeded immutable input tape.
    input_tape: Vec<String>,
    /// The engine submissions run on.
    engine: Engine,
    /// Last run's full output (for delta printing).
    prev_outputs: Vec<String>,
    /// Last run's rendered warnings (for delta printing — the same
    /// replay semantics as outputs: the checker re-runs over the
    /// whole accumulated program each submission, and an unchanged
    /// finding is not news).
    prev_warnings: Vec<String>,
}

impl Default for Repl {
    fn default() -> Self {
        Repl::new()
    }
}

impl Repl {
    /// A fresh REPL on the VM engine with an empty input tape.
    pub fn new() -> Self {
        Repl::with_options(Engine::Vm, Vec::new())
    }

    /// A REPL with an engine choice and a pre-seeded input tape.
    pub fn with_options(engine: Engine, input_tape: Vec<String>) -> Self {
        let mut session = Session::new();
        session.intern("repl-session", "");
        Repl {
            session,
            name: "repl-session".to_owned(),
            acc: String::new(),
            pending: String::new(),
            counter: 0,
            input_tape,
            engine,
            prev_outputs: Vec::new(),
            prev_warnings: Vec::new(),
        }
    }

    /// The banner the CLI prints once before the loop.
    pub fn greeting() -> String {
        "kerf repl — one form per line, ctrl-d exits".to_owned()
    }

    /// The accumulated accepted source (test/inspection face).
    pub fn accepted_source(&self) -> &str {
        &self.acc
    }

    /// Submit one line. See [`ReplEvent`] for the outcomes; the state
    /// machine is fully deterministic (the input tape is fixed).
    pub fn submit(&mut self, line: &str) -> ReplEvent {
        if line.trim().is_empty() {
            return ReplEvent::Ignored;
        }
        self.pending.push_str(line);
        self.pending.push('\n');

        // Probe-read the pending buffer (its text becomes the
        // session's current source so read errors render against what
        // was actually being read).
        let file = self.session.intern(&self.name, &self.pending);
        let forms = match kerf_reader::read_program(file, &self.pending) {
            Err(ReadError::UnclosedList { .. }) => return ReplEvent::NeedMoreInput,
            Err(err) => {
                let diag = Diagnostic::from_read(&err, file);
                let rendered = render_diagnostics(&self.session, &[diag]);
                let acc = self.acc.clone();
                self.recover(&acc);
                return ReplEvent::Error { rendered };
            }
            Ok(forms) => forms,
        };

        // Classify and wrap: declarations pass through, expressions
        // become `$repl:N` defines (source-level wrapping — the reader
        // re-parses real source, spans stay real).
        let mut submission = String::new();
        let mut last_wrapped: Option<String> = None;
        for form in &forms {
            let text = slice_form(&self.pending, form);
            if is_declaration(form) {
                submission.push_str(text);
            } else {
                let name = format!("$repl:{}", self.counter);
                self.counter += 1;
                submission.push_str(&format!("(define {name} {text})"));
                last_wrapped = Some(name);
            }
            submission.push('\n');
        }

        let mut new_acc = self.acc.clone();
        if !new_acc.is_empty() {
            new_acc.push('\n');
        }
        new_acc.push_str(&submission);

        match pipeline::parse(&mut self.session, &self.name, &new_acc)
            .and_then(|program| program.run(self.engine, Box::new(TapeIo::new(&self.input_tape))))
        {
            Ok(outcome) => {
                self.acc = new_acc;
                let value = last_wrapped
                    .and_then(|name| outcome.global(&name))
                    .map(|v| v.to_string());
                let new_outputs = delta_outputs(&outcome.outputs, &self.prev_outputs);
                self.prev_outputs = outcome.outputs;
                // Warnings use the identical replay rule: render the
                // whole batch, then keep only what the previous run
                // had not already shown. A warning submission is
                // legal — it enters the accumulated program (only
                // errors roll back).
                let rendered_warnings = render_diagnostics(&self.session, &outcome.warnings);
                let all_warnings: Vec<String> = if rendered_warnings.is_empty() {
                    Vec::new()
                } else {
                    rendered_warnings
                        .split("\n")
                        .filter(|l| !l.is_empty())
                        .map(|l| l.to_owned())
                        .collect()
                };
                let new_warnings = delta_outputs(&all_warnings, &self.prev_warnings);
                self.prev_warnings = all_warnings;
                let acc = self.acc.clone();
                self.recover(&acc);
                ReplEvent::Evaluated {
                    value,
                    new_outputs,
                    new_warnings,
                }
            }
            Err(diags) => {
                let rendered = render_diagnostics(&self.session, &diags);
                let acc = self.acc.clone();
                self.recover(&acc);
                ReplEvent::Error { rendered }
            }
        }
    }

    /// Drop the pending buffer and restore the session's rendering
    /// state to `source`.
    fn recover(&mut self, source: &str) {
        self.pending.clear();
        self.session.intern(&self.name, source);
    }
}

/// Slice a form's source text out of the buffer it was parsed from.
fn slice_form<'a>(source: &'a str, form: &SyntaxObject) -> &'a str {
    let start = (form.span.start.0 as usize).min(source.len());
    let end = (form.span.end.0 as usize).min(source.len());
    &source[start..end]
}

/// A declaration form is a list whose head is a known declaration
/// keyword; everything else (atoms included) is an expression.
fn is_declaration(form: &SyntaxObject) -> bool {
    match &form.datum {
        StxDatum::List(children) => match children.first() {
            Some(head) => match &head.datum {
                StxDatum::Symbol(sym) => DECLARATION_HEADS.contains(&sym.as_str()),
                _ => false,
            },
            None => false,
        },
        _ => false,
    }
}

/// The new-output tail: `prev` is a prefix of `outputs` -> the tail;
/// otherwise everything (defensive — under the fixed tape the prefix
/// property holds, but the renderer must never hide output).
fn delta_outputs(outputs: &[String], prev: &[String]) -> Vec<String> {
    if outputs.len() >= prev.len() && outputs.starts_with(prev) {
        outputs[prev.len()..].to_vec()
    } else {
        outputs.to_vec()
    }
}

/// The REPL's deterministic I/O face: replays the pre-seeded tape,
/// then ends input (a `read-line` past the tape is an `Eof` error at
/// run time — fail-closed, no interactive reads). Writes are
/// recorded here — the engine's `take_output` drains *this* face, so
/// it is the single recording point, exactly like `BufferIo`.
struct TapeIo {
    tape: Vec<String>,
    pos: usize,
    output: Vec<String>,
}

impl TapeIo {
    fn new(tape: &[String]) -> Self {
        TapeIo {
            tape: tape.to_vec(),
            pos: 0,
            output: Vec::new(),
        }
    }
}

impl VmIo for TapeIo {
    fn read_line(&mut self) -> Option<String> {
        let line = self.tape.get(self.pos).cloned();
        if line.is_some() {
            self.pos += 1;
        }
        line
    }

    fn write_line(&mut self, line: &str) {
        self.output.push(line.to_owned());
    }

    fn take_output(&mut self) -> Vec<String> {
        std::mem::take(&mut self.output)
    }
}

#[cfg(test)]
mod tests {
    //! REPL tests (FP4): wrap/classify, persistence via replay,
    //! rollback on error, multi-line accumulation, delta outputs,
    //! input-tape replay, Eof past the tape.

    use super::*;

    /// Assert the event is `Evaluated` and return its parts.
    fn evaluated(event: ReplEvent) -> (Option<String>, Vec<String>) {
        match event {
            ReplEvent::Evaluated {
                value, new_outputs, ..
            } => (value, new_outputs),
            other => panic!("expected Evaluated, got {other:?}"),
        }
    }

    /// Assert the event is `Evaluated` with the given value display.
    fn evaluated_value(event: ReplEvent, expect: Option<&str>) {
        let (value, _) = evaluated(event);
        assert_eq!(value.as_deref(), expect);
    }

    #[test]
    fn define_then_expression_persists_across_submissions() {
        let mut r = Repl::new();
        evaluated_value(r.submit("(define x 41)"), None);
        evaluated_value(r.submit("(+ x 1)"), Some("42"));
    }

    #[test]
    fn expression_value_wraps_into_a_repl_define() {
        let mut r = Repl::new();
        evaluated_value(r.submit("(* 6 7)"), Some("42"));
    }

    #[test]
    fn atom_submission_wraps_as_expression() {
        let mut r = Repl::new();
        evaluated_value(r.submit("42"), Some("42"));
    }

    #[test]
    fn counter_is_monotonic_and_names_stable() {
        let mut r = Repl::new();
        evaluated_value(r.submit("1"), Some("1"));
        evaluated_value(r.submit("2"), Some("2"));
        // Earlier wrappers stay readable — names are stable.
        evaluated_value(r.submit("(+ $repl:0 $repl:1)"), Some("3"));
    }

    #[test]
    fn multi_line_submission_completes_and_evaluates() {
        let mut r = Repl::new();
        assert_eq!(r.submit("(define (f x)"), ReplEvent::NeedMoreInput);
        evaluated_value(r.submit("(+ x 1))"), None);
        evaluated_value(r.submit("(f 1)"), Some("2"));
    }

    #[test]
    fn failed_submission_rolls_back_and_session_survives() {
        let mut r = Repl::new();
        evaluated_value(r.submit("(define x 1)"), None);
        match r.submit("(undefined-thing)") {
            ReplEvent::Error { rendered } => {
                assert!(rendered.contains("kerf-expand"), "{rendered}");
            }
            other => panic!("unbound must error: {other:?}"),
        }
        // The failed submission is NOT in the program: x still works.
        evaluated_value(r.submit("x"), Some("1"));
    }

    #[test]
    fn read_error_submission_is_rejected_and_survives() {
        let mut r = Repl::new();
        match r.submit("(+ 1 2))") {
            ReplEvent::Error { rendered } => {
                assert!(rendered.contains("kerf-read"), "{rendered}");
            }
            other => panic!("stray close must error: {other:?}"),
        }
        evaluated_value(r.submit("(+ 1 2)"), Some("3"));
    }

    #[test]
    fn runtime_error_submission_rolls_back() {
        let mut r = Repl::new();
        evaluated_value(r.submit("(define x 1)"), None);
        match r.submit("(/ x 0)") {
            ReplEvent::Error { rendered } => {
                assert!(rendered.contains("kerf-runtime"), "{rendered}");
                assert!(rendered.contains("division by zero"));
            }
            other => panic!("div by zero must error: {other:?}"),
        }
        evaluated_value(r.submit("(+ x 1)"), Some("2"));
    }

    #[test]
    fn blank_lines_are_ignored() {
        let mut r = Repl::new();
        assert_eq!(r.submit(""), ReplEvent::Ignored);
        assert_eq!(r.submit("   "), ReplEvent::Ignored);
    }

    #[test]
    fn input_tape_replays_then_fails_closed_past_the_end() {
        let mut r = Repl::with_options(Engine::Vm, vec!["first".to_owned(), "second".to_owned()]);
        evaluated(r.submit("(define a (read-line))"));
        evaluated(r.submit("(define b (read-line))"));
        // Both reads replay on every later run; a new read past the
        // tape is an Eof.
        match r.submit("(read-line)") {
            ReplEvent::Error { rendered } => {
                assert!(rendered.contains("end of input"), "{rendered}");
            }
            other => panic!("past-tape read must Eof: {other:?}"),
        }
    }

    #[test]
    fn delta_outputs_print_only_the_new_tail() {
        let mut r = Repl::new();
        let (_, outs) = evaluated(r.submit("(define (say) (write-line \"hi\"))"));
        assert!(outs.is_empty(), "defining is not calling");
        let (value, outs) = evaluated(r.submit("(say)"));
        assert_eq!(outs, vec!["hi".to_owned()], "new output only");
        assert_eq!(value.as_deref(), Some("nil"));
        // The replay re-executes both earlier calls; the tail grows by
        // the new call's line only.
        let (_, outs) = evaluated(r.submit("(say)"));
        assert_eq!(
            outs,
            vec!["hi".to_owned()],
            "replay reproduces the prefix; only the new call's line is fresh"
        );
    }

    #[test]
    fn multi_form_submission_processes_all_forms() {
        let mut r = Repl::new();
        evaluated_value(r.submit("(define a 1) (define b 2)"), None);
        evaluated_value(r.submit("(+ a b)"), Some("3"));
    }

    #[test]
    fn mixed_forms_wrap_only_the_expressions() {
        let mut r = Repl::new();
        evaluated_value(r.submit("(define a 5) (* a a)"), Some("25"));
    }

    #[test]
    fn greeting_is_stable_english() {
        assert_eq!(
            Repl::greeting(),
            "kerf repl — one form per line, ctrl-d exits"
        );
    }

    #[test]
    fn redefinition_follows_last_wins_module_semantics() {
        let mut r = Repl::new();
        evaluated_value(r.submit("(define x 1)"), None);
        evaluated_value(r.submit("(define x 2)"), None);
        evaluated_value(r.submit("x"), Some("2"));
    }

    #[test]
    fn accepted_source_grows_with_wrappers_only_for_expressions() {
        let mut r = Repl::new();
        evaluated_value(r.submit("(define x 1)"), None);
        evaluated_value(r.submit("(+ x 1)"), Some("2"));
        let src = r.accepted_source();
        assert!(
            src.contains("(define x 1)"),
            "declaration passes through: {src}"
        );
        assert!(src.contains("(define $repl:0 (+ x 1))"), "wrapped: {src}");
    }

    // ---- Stage 1.1: warning replay semantics (driver-wiring.md FP6) ----

    #[test]
    fn warning_submission_enters_the_program_and_shows_once() {
        // R8 is legal: the submission is accepted, the warning renders
        // once, and the re-runs of later submissions stay silent about
        // it (the prefix-delta rule).
        let mut r = Repl::new();
        match r.submit("(set! car 1)") {
            ReplEvent::Evaluated {
                value,
                new_outputs,
                new_warnings,
            } => {
                assert!(value.is_some() || new_outputs.is_empty());
                let shown = new_warnings.join("\n");
                assert!(
                    shown.contains("warning[E0008]"),
                    "the warning renders: {shown}"
                );
            }
            other => panic!("warning submission is legal: {other:?}"),
        }
        match r.submit("(+ 1 2)") {
            ReplEvent::Evaluated {
                value,
                new_warnings,
                ..
            } => {
                assert_eq!(value.as_deref(), Some("3"), "the value channel works");
                assert!(
                    new_warnings.is_empty(),
                    "the replayed warning must not re-print"
                );
            }
            other => panic!("next submission: {other:?}"),
        }
        assert!(
            r.accepted_source().contains("(set! car 1)"),
            "the warning submission entered the accumulated program"
        );
    }

    #[test]
    fn new_warning_in_later_submission_shows_as_delta() {
        // A second, different warning in a later submission is news:
        // it prints even though an earlier warning already printed.
        let mut r = Repl::new();
        match r.submit("(set! car 1)") {
            ReplEvent::Evaluated { new_warnings, .. } => {
                let shown = new_warnings.join("\n");
                assert!(shown.contains("`car`"), "first warning renders: {shown}");
            }
            other => panic!("first: {other:?}"),
        }
        match r.submit("(set! cdr 2)") {
            ReplEvent::Evaluated { new_warnings, .. } => {
                let shown = new_warnings.join("\n");
                assert!(
                    shown.contains("`cdr`") && !shown.contains("`car`"),
                    "only the new warning is news: {shown}"
                );
            }
            other => panic!("second: {other:?}"),
        }
    }

    #[test]
    fn definite_error_submission_still_rolls_back() {
        // The checker wiring must not weaken the rollback discipline:
        // an R2 definite error fails the submission, the program rolls
        // back, and the session stays usable.
        let mut r = Repl::new();
        evaluated_value(r.submit("(define (f x) x)"), None);
        match r.submit("(f 1 2)") {
            ReplEvent::Error { rendered } => {
                assert!(rendered.contains("error[E0002]"), "{rendered}");
            }
            other => panic!("definite error: {other:?}"),
        }
        // The failed submission never entered the program.
        assert!(!r.accepted_source().contains("(f 1 2)"));
        evaluated_value(r.submit("(f 5)"), Some("5"));
    }
}

//! The CLI surface — `kerf run|check|repl` (stage-0-plan row 0.8).
//!
//! Hand-rolled argument parsing (zero external dependencies — the
//! §18 review keeps crates.io out of the driver; clap is a Stage 1+
//! agenda item at most). All user-facing text is R8 English,
//! lowercase, no trailing periods. Exit codes: `0` success, `1`
//! program or environment error, `2` usage error.
//!
//! The executable core ([`run_cli`]) is dependency-injected (file
//! reader, REPL input, pre-read stdin, output sinks) so the CLI
//! behavior is unit-testable without process spawns.

use std::io::Write;

use crate::diagnostic::Diagnostic;
use crate::pipeline::{self, Engine};
use crate::render::render_diagnostics;
use crate::repl::{Repl, ReplEvent};
use crate::session::Session;

/// A parsed command line.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Command {
    /// Compile and execute a file.
    Run {
        file: String,
        engine: Engine,
        parity: bool,
    },
    /// Compile and verify without executing.
    Check { file: String },
    /// Interactive session.
    Repl,
    /// `--help` / no arguments (prints usage).
    Help,
    /// `--version`.
    Version,
}

/// Parse raw arguments (without the program name). `Err` carries the
/// usage-error message (exit code 2 territory).
pub fn parse_args(args: &[String]) -> Result<Command, String> {
    let mut it = args.iter();
    let Some(first) = it.next() else {
        return Ok(Command::Help);
    };
    match first.as_str() {
        "--help" | "-h" | "help" => {
            if it.next().is_some() {
                Err("--help takes no arguments".to_owned())
            } else {
                Ok(Command::Help)
            }
        }
        "--version" | "-V" => Ok(Command::Version),
        "run" => {
            let mut file: Option<String> = None;
            let mut engine = Engine::Vm;
            let mut parity = false;
            let rest: Vec<&String> = it.collect();
            let mut i = 0;
            while i < rest.len() {
                let arg = rest[i];
                if arg == "--parity" {
                    parity = true;
                    i += 1;
                } else if arg == "--engine" {
                    let Some(value) = rest.get(i + 1) else {
                        return Err("--engine requires a value (`vm` or `eval`)".to_owned());
                    };
                    engine = match value.as_str() {
                        "vm" => Engine::Vm,
                        "eval" => Engine::Eval,
                        other => {
                            return Err(format!(
                                "unknown engine `{other}` (expected `vm` or `eval`)"
                            ));
                        }
                    };
                    i += 2;
                } else if arg.starts_with("--") {
                    return Err(format!("unknown option `{arg}`"));
                } else if file.is_none() {
                    file = Some(arg.clone());
                    i += 1;
                } else {
                    return Err(format!("unexpected argument `{arg}`"));
                }
            }
            match file {
                Some(file) => Ok(Command::Run {
                    file,
                    engine,
                    parity,
                }),
                None => Err("run requires a file: `kerf run <file>`".to_owned()),
            }
        }
        "check" => {
            let rest: Vec<&String> = it.collect();
            if rest.len() != 1 {
                return Err("check requires exactly one file: `kerf check <file>`".to_owned());
            }
            let file = rest[0].clone();
            if file.starts_with("--") {
                return Err(format!("unknown option `{file}`"));
            }
            Ok(Command::Check { file })
        }
        "repl" => {
            if it.next().is_some() {
                Err("repl takes no arguments".to_owned())
            } else {
                Ok(Command::Repl)
            }
        }
        other => Err(format!(
            "unknown command `{other}` (expected `run`, `check` or `repl`)"
        )),
    }
}

/// The usage text (`--help` and usage errors).
pub fn usage() -> String {
    "kerf — the kerf compiler driver (stage 0 skin)

usage:
  kerf run <file> [--engine vm|eval] [--parity]   compile and execute a file
  kerf check <file>                               compile and verify, no execution
  kerf repl                                       interactive session (ctrl-d exits)
  kerf --help | --version

options:
  --engine <name>   execution engine: `vm` (default) or `eval`
  --parity          run both engines and assert structural agreement

stdin piped into `run` feeds the program's `read-line` calls"
        .to_owned()
}

/// The driver version (single source: the workspace manifest).
pub fn version() -> &'static str {
    env!("CARGO_PKG_VERSION")
}

/// Execute a parsed command. All I/O is injected; returns the process
/// exit code.
#[allow(clippy::too_many_arguments)]
pub fn run_cli(
    args: &[String],
    read_file: &dyn Fn(&str) -> std::io::Result<String>,
    repl_input: &mut dyn FnMut() -> Option<String>,
    input_lines: Vec<String>,
    out: &mut dyn Write,
    err: &mut dyn Write,
) -> i32 {
    let command = match parse_args(args) {
        Ok(command) => command,
        Err(message) => {
            let _ = writeln!(err, "error: {message}");
            let _ = writeln!(err);
            let _ = write!(err, "{}", usage());
            return 2;
        }
    };
    match command {
        Command::Help => {
            let _ = write!(out, "{}", usage());
            0
        }
        Command::Version => {
            let _ = writeln!(out, "kerf {}", version());
            0
        }
        Command::Check { file } => match read_file(&file) {
            Err(io_err) => {
                let _ = writeln!(err, "error: cannot read `{file}`: {io_err}");
                1
            }
            Ok(source) => {
                let mut session = Session::new();
                match pipeline::check_source(&mut session, &file, &source) {
                    Ok(check) => {
                        // Warnings never block: they render to the error
                        // sink (the diagnostics channel) before the ok
                        // line, and the exit code stays 0.
                        if !check.warnings.is_empty() {
                            report(err, &session, &check.warnings);
                        }
                        let _ = writeln!(
                            out,
                            "ok: {} functions, {} instructions, {} constants, {} globals",
                            check.func_count,
                            check.instr_count,
                            check.const_count,
                            check.global_count
                        );
                        0
                    }
                    Err(diags) => {
                        report(err, &session, &diags);
                        1
                    }
                }
            }
        },
        Command::Repl => {
            let _ = writeln!(out, "{}", Repl::greeting());
            let mut repl = Repl::new();
            loop {
                let Some(line) = repl_input() else {
                    return 0;
                };
                match repl.submit(&line) {
                    ReplEvent::Ignored | ReplEvent::NeedMoreInput => {}
                    ReplEvent::Evaluated {
                        value,
                        new_outputs,
                        new_warnings,
                    } => {
                        for warning in &new_warnings {
                            let _ = write!(err, "{warning}");
                        }
                        for output in &new_outputs {
                            let _ = writeln!(out, "{output}");
                        }
                        if let Some(value) = value {
                            let _ = writeln!(out, "{value}");
                        }
                    }
                    ReplEvent::Error { rendered } => {
                        let _ = write!(err, "{rendered}");
                    }
                }
            }
        }
        Command::Run {
            file,
            engine,
            parity,
        } => match read_file(&file) {
            Err(io_err) => {
                let _ = writeln!(err, "error: cannot read `{file}`: {io_err}");
                1
            }
            Ok(source) => {
                let mut session = Session::new();
                if parity {
                    // The local binding is `parity_out` — the module
                    // function `report` must stay callable inside the
                    // arms.
                    match pipeline::run_parity_source(&mut session, &file, &source, &input_lines) {
                        Ok(parity_out) if parity_out.agrees() => {
                            if !parity_out.warnings.is_empty() {
                                report(err, &session, &parity_out.warnings);
                            }
                            let _ = writeln!(
                                out,
                                "parity: PASS (vm and eval agree on `{}`)",
                                parity_out.vm_repr
                            );
                            0
                        }
                        Ok(parity_out) => {
                            if !parity_out.warnings.is_empty() {
                                report(err, &session, &parity_out.warnings);
                            }
                            let _ = writeln!(err, "parity: FAIL");
                            let _ = writeln!(err, "  vm   = {}", parity_out.vm_repr);
                            let _ = writeln!(err, "  eval = {}", parity_out.eval_repr);
                            if !parity_out.outputs_agree {
                                let _ = writeln!(err, "  output sequences differ");
                            }
                            if !parity_out.globals_agree {
                                let _ = writeln!(err, "  global tables differ");
                            }
                            1
                        }
                        Err(diags) => {
                            report(err, &session, &diags);
                            1
                        }
                    }
                } else {
                    match pipeline::run_source(&mut session, &file, &source, engine, &input_lines) {
                        Ok(outcome) => {
                            if !outcome.warnings.is_empty() {
                                report(err, &session, &outcome.warnings);
                            }
                            for output in &outcome.outputs {
                                let _ = writeln!(out, "{output}");
                            }
                            if outcome.value != kerf_vm::Value::Nil {
                                let _ = writeln!(out, "{}", outcome.value_display());
                            }
                            0
                        }
                        Err(diags) => {
                            report(err, &session, &diags);
                            1
                        }
                    }
                }
            }
        },
    }
}

/// Render a diagnostic batch to the error sink.
fn report(err: &mut dyn Write, session: &Session, diags: &[Diagnostic]) {
    let _ = write!(err, "{}", render_diagnostics(session, diags));
}

#[cfg(test)]
mod tests {
    //! CLI tests (FP4): argument parsing (every command + error
    //! family), exit codes, output shapes, injected I/O.

    use super::*;

    fn no_files(_: &str) -> std::io::Result<String> {
        Err(std::io::Error::new(std::io::ErrorKind::NotFound, "no file"))
    }

    fn file_with(content: &'static str) -> impl Fn(&str) -> std::io::Result<String> {
        move |_| Ok(content.to_owned())
    }

    fn no_input() -> impl FnMut() -> Option<String> {
        || None
    }

    fn run(args: &[&str]) -> i32 {
        let args: Vec<String> = args.iter().map(|s| (*s).to_owned()).collect();
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        run_cli(
            &args,
            &no_files,
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        )
    }

    #[test]
    fn no_args_is_help_with_zero_exit() {
        let args: Vec<String> = vec![];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &no_files,
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0);
        let text = String::from_utf8(out).expect("utf8");
        assert!(text.contains("usage:"));
        assert!(text.contains("kerf run <file>"));
    }

    #[test]
    fn version_flag_prints_workspace_version() {
        let args = vec!["--version".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &no_files,
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0);
        assert_eq!(
            String::from_utf8(out).expect("utf8"),
            format!("kerf {}\n", version())
        );
    }

    #[test]
    fn parse_run_defaults_to_vm_engine() {
        let cmd = parse_args(&["run".to_owned(), "f.krf".to_owned()]).expect("parse");
        assert_eq!(
            cmd,
            Command::Run {
                file: "f.krf".to_owned(),
                engine: Engine::Vm,
                parity: false
            }
        );
    }

    #[test]
    fn parse_run_accepts_engine_and_parity() {
        let cmd = parse_args(&[
            "run".to_owned(),
            "f.krf".to_owned(),
            "--engine".to_owned(),
            "eval".to_owned(),
            "--parity".to_owned(),
        ])
        .expect("parse");
        assert_eq!(
            cmd,
            Command::Run {
                file: "f.krf".to_owned(),
                engine: Engine::Eval,
                parity: true
            }
        );
    }

    #[test]
    fn parse_check_requires_exactly_one_file() {
        assert!(parse_args(&["check".to_owned()]).is_err());
        assert!(parse_args(&["check".to_owned(), "a".to_owned(), "b".to_owned()]).is_err());
        assert_eq!(
            parse_args(&["check".to_owned(), "a.krf".to_owned()]).expect("parse"),
            Command::Check {
                file: "a.krf".to_owned()
            }
        );
    }

    #[test]
    fn unknown_command_is_usage_error() {
        let err = parse_args(&["frobnicate".to_owned()]).expect_err("unknown");
        assert!(err.contains("unknown command `frobnicate`"));
        assert_eq!(run(&["frobnicate"]), 2);
    }

    #[test]
    fn unknown_option_is_usage_error() {
        let err = parse_args(&["run".to_owned(), "f.krf".to_owned(), "--wat".to_owned()])
            .expect_err("unknown option");
        assert!(err.contains("unknown option `--wat`"));
        assert_eq!(run(&["run", "f.krf", "--wat"]), 2);
    }

    #[test]
    fn missing_engine_value_is_usage_error() {
        let err = parse_args(&["run".to_owned(), "f.krf".to_owned(), "--engine".to_owned()])
            .expect_err("engine value");
        assert!(err.contains("--engine requires a value"));
        assert_eq!(run(&["run", "f.krf", "--engine"]), 2);
    }

    #[test]
    fn bad_engine_name_is_usage_error() {
        let err = parse_args(&[
            "run".to_owned(),
            "f.krf".to_owned(),
            "--engine".to_owned(),
            "native".to_owned(),
        ])
        .expect_err("bad engine");
        assert!(err.contains("unknown engine `native`"));
        assert_eq!(run(&["run", "f.krf", "--engine", "native"]), 2);
    }

    #[test]
    fn run_without_file_is_usage_error() {
        assert_eq!(run(&["run"]), 2);
    }

    #[test]
    fn unreadable_file_is_environment_error_exit_one() {
        let args = vec!["run".to_owned(), "gone.krf".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &no_files,
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 1);
        let text = String::from_utf8(errbuf).expect("utf8");
        assert!(text.contains("cannot read `gone.krf`"));
    }

    #[test]
    fn run_prints_outputs_and_non_nil_value() {
        let args = vec!["run".to_owned(), "prog.krf".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &file_with("(define r (write-line \"hello\"))"),
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0);
        let text = String::from_utf8(out).expect("utf8");
        assert_eq!(text, "hello\n", "nil halt values stay silent");
    }

    #[test]
    fn run_bad_program_renders_diagnostics_exit_one() {
        let args = vec!["run".to_owned(), "bad.krf".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &file_with("(+ 1 2"),
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 1);
        let text = String::from_utf8(errbuf).expect("utf8");
        assert!(text.contains("error[kerf-read]:"));
        assert!(text.contains("--> bad.krf:1:1"), "{text}");
    }

    #[test]
    fn check_prints_counts_exit_zero() {
        let args = vec!["check".to_owned(), "ok.krf".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &file_with("(define r (+ 1 2))"),
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0);
        let text = String::from_utf8(out).expect("utf8");
        assert!(text.starts_with("ok: "), "{text}");
        assert!(text.contains("functions"));
    }

    #[test]
    fn parity_flag_reports_pass() {
        let args = vec!["run".to_owned(), "p.krf".to_owned(), "--parity".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &file_with("(define r (+ 20 22))"),
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0);
        let text = String::from_utf8(out).expect("utf8");
        assert!(text.contains("parity: PASS"), "{text}");
    }

    #[test]
    fn repl_loop_evaluates_and_exits_on_eof() {
        let args = vec!["repl".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let lines = vec![
            Some("(define x 1)".to_owned()),
            Some("(+ x 41)".to_owned()),
            None,
        ];
        let mut it = lines.into_iter();
        let mut next = move || it.next().flatten();
        let code = run_cli(
            &args,
            &no_files,
            &mut next,
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0);
        let text = String::from_utf8(out).expect("utf8");
        assert!(text.contains("kerf repl"));
        assert!(text.ends_with("42\n"), "value printed: {text}");
    }

    #[test]
    fn repl_error_goes_to_err_stream_and_survives() {
        let args = vec!["repl".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let lines = vec![
            Some("(nope-undefined)".to_owned()),
            Some("(+ 1 2)".to_owned()),
            None,
        ];
        let mut it = lines.into_iter();
        let mut next = move || it.next().flatten();
        let code = run_cli(
            &args,
            &no_files,
            &mut next,
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0);
        let err_text = String::from_utf8(errbuf).expect("utf8");
        assert!(err_text.contains("kerf-expand"), "{err_text}");
        let out_text = String::from_utf8(out).expect("utf8");
        assert!(out_text.ends_with("3\n"), "session survived: {out_text}");
    }

    #[test]
    fn help_flag_is_zero_exit() {
        assert_eq!(run(&["--help"]), 0);
    }

    // ---- Stage 1.1: warning paths (test doc driver-wiring.md FP5) ----

    #[test]
    fn check_with_warnings_prints_them_and_exits_zero() {
        let args = vec!["check".to_owned(), "warn.krf".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &file_with("(define r (set! car 1))"),
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0, "warnings never change the exit code");
        let err_text = String::from_utf8(errbuf).expect("utf8");
        assert!(
            err_text.contains("warning[E0008]: assignment rebinds builtin `car`"),
            "{err_text}"
        );
        let out_text = String::from_utf8(out).expect("utf8");
        assert!(
            out_text.starts_with("ok: "),
            "the ok line still prints: {out_text}"
        );
    }

    #[test]
    fn run_with_warnings_prints_outputs_and_value() {
        let args = vec!["run".to_owned(), "warn.krf".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &file_with("(define r (set! car 41))\n(define r2 (write-line \"done\"))"),
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0);
        let err_text = String::from_utf8(errbuf).expect("utf8");
        assert!(err_text.contains("warning[E0008]"), "{err_text}");
        assert!(
            !err_text.contains("aborting due to"),
            "a single warning has no summary line: {err_text}"
        );
        let out_text = String::from_utf8(out).expect("utf8");
        assert_eq!(
            out_text, "done\n",
            "the program ran to its output despite the warning"
        );
    }

    #[test]
    fn run_with_definite_error_renders_registry_code_and_exits_one() {
        let args = vec!["run".to_owned(), "arity.krf".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &file_with("(define (f x) x)\n(define r (f 1 2))"),
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 1);
        let err_text = String::from_utf8(errbuf).expect("utf8");
        assert!(
            err_text.contains("error[E0002]:"),
            "the registry tag renders: {err_text}"
        );
        assert!(err_text.contains("--> arity.krf:2:"), "{err_text}");
        assert!(out.is_empty(), "a definite error produces no output");
    }

    #[test]
    fn parity_with_warnings_still_passes() {
        let args = vec!["run".to_owned(), "w.krf".to_owned(), "--parity".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &file_with("(define r (set! car 7))"),
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0);
        let err_text = String::from_utf8(errbuf).expect("utf8");
        assert!(err_text.contains("warning[E0008]"), "{err_text}");
        let out_text = String::from_utf8(out).expect("utf8");
        assert!(out_text.contains("parity: PASS"), "{out_text}");
    }

    #[test]
    fn repl_warning_prints_once_then_stays_silent() {
        let args = vec!["repl".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let lines = vec![
            Some("(set! car 1)".to_owned()),
            Some("(+ 1 2)".to_owned()),
            None,
        ];
        let mut it = lines.into_iter();
        let mut next = move || it.next().flatten();
        let code = run_cli(
            &args,
            &no_files,
            &mut next,
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0);
        let err_text = String::from_utf8(errbuf).expect("utf8");
        assert_eq!(
            err_text.matches("warning[E0008]").count(),
            1,
            "the warning renders exactly once: {err_text}"
        );
        let out_text = String::from_utf8(out).expect("utf8");
        assert!(
            out_text.ends_with("3\n"),
            "the value still prints: {out_text}"
        );
    }
}

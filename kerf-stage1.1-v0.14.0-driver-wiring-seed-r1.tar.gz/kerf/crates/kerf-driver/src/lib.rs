//! kerf-driver — the compiler entry point / pipeline orchestration
//! (Layer 8, stage-0-plan row 0.8; TD-003 final resolution step).
//!
//! Charter: read -> expand -> {compile -> VM, eval} pipeline assembly,
//! session/file interning, the diagnostics rendering closure (TD-001
//! payoff — line/column derived at render time), and the CLI/REPL
//! surface. Stages interact through data contracts only (SOP §11);
//! errors are data (§12.2): every stage failure becomes a
//! [`Diagnostic`] and is rendered in one pass.
//!
//! Layout: [`session`] (file interning), [`line_index`] (the TD-001
//! byte-offset -> line/column derivation), [`diagnostic`] (the §8.7
//! structure, Stage 0 slice), [`render`] (rustc-flavored rendering),
//! [`pipeline`] (dual-engine orchestration), [`repl`] (session-replay
//! state machine), [`cli`] (the `kerf` binary face). The executable
//! entry is `src/main.rs` (bin name `kerf`).

mod cli;
mod diagnostic;
mod line_index;
mod pipeline;
mod render;
mod repl;
mod session;

// Explicit re-export list (SOP §10.1 rule 4 — glob re-exports are forbidden).
pub use cli::{Command, parse_args, run_cli, usage, version};
pub use diagnostic::{Diagnostic, DiagnosticCode, Severity};
pub use line_index::LineIndex;
pub use pipeline::{
    CheckOutcome, Engine, ParityReport, ParsedProgram, RunOutcome, check_source, parse,
    run_parity_source, run_source,
};
pub use render::{column_of, render_diagnostics};
pub use repl::{Repl, ReplEvent};
pub use session::Session;

// Coordinate types flow through the kerf-compiler re-exports
// (SOP §18.5 — no direct kerf-span production edge for this crate,
// the same passthrough precedent kerf-vm follows).
pub use kerf_compiler::{ByteOffset, FileId, Span};

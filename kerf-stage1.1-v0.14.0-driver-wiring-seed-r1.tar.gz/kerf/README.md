# kerf

A minimal-bootstrap systems programming language compiler — Rust workspace,
edition 2024.

> **One-liner** (activation protocol): Rust kerf compiler, Cargo Workspace
> edition 2024 (`kerf_*` crates), frozen minimal-primitive kernel (primitive
> invariance: no new primitives, no channels, no VM rewrite, no syntax),
> Stage 0-1 self-built VM (**the VM is a permanent Rust base — a
> "fully self-hosted" VM rewrite is constitutionally excluded**), LLVM /
> native-code backends never enter the bootstrap chain.

## Status

**Stage 1 in progress (v0.14.0) — 1.0 and 1.1 delivered.**
Stage 1 opened with the kerf-typecheck seed (1.0: the E0xxx
registry, the conservative static rules R1-R8 with per-rule
soundness arguments, multi-error collection, the single-source
Externals face; TD-006 cleared — the tech-debt ledger is at zero
open items). The 1.1 round wired the checker into the driver
pipeline (`read -> expand -> typecheck -> {compile, eval}`):
Error-level findings abort before execution, the first Warning
producer (R8) rides a non-blocking channel through run / check /
parity and the REPL (delta-replayed), diagnostics render
rustc-style `error[E0002]:` with byte-precise locations, and the
driver is the third Externals consumption site. Cumulative: 881
tests green, audit set 130/130 (A-N), seven error classes 7/7,
zero new external dependencies (one internal edge L4.5 -> L8).
Next: 1.2 — property-based testing lands (proptest dev-dependency
behind the §18 review, first six invariants).

## Workspace layout

Structure authority: `docs/sop.md` §8.4.6 (two-level semantics) + §18.5
(dependency DAG).

```
kerf/
├── Cargo.toml            # workspace manifest + root aggregation package
├── src/                  # root crate (aggregation / cross-crate test layer)
├── crates/
│   ├── kerf-span/        # L0  Span / positions          (implemented)
│   ├── kerf-syntax/      # L1  SyntaxObject four-tuple     (implemented)
│   ├── kerf-reader/      # L2  lexer + parser → stx tree   (implemented)
│   ├── kerf-expander/    # L3  expansion → CoreExpr       (implemented)
│   ├── kerf-core/        # L4  CoreExpr (frozen kernel)   (implemented)
│   ├── kerf-compiler/    # L5  bytecode generation        (implemented)
│   ├── kerf-vm/          # L6  bytecode VM (Rust base)    (implemented)
│   ├── kerf-runtime/     # L7  GC + eval                  (implemented)
│   └── kerf-driver/      # L8  pipeline orchestration + CLI (implemented)
├── tests/                # cross-crate integration tests (runner.rs entry)
├── docs/                 # sop.md + stage0.md + develop/tests/worklog trees
└── worklog.md            # flat worklog — audit base (SOP §8.6.1)
```

## Build & verify (SOP §3.2, Stage 0-1 — no LLVM)

```bash
cargo clean && cargo build --release && cargo check && \
  cargo fmt --check && cargo clippy --all-targets -- -D warnings && \
  cargo test --release
```

All six must be green before any delivery.

## Documents

| Path | Role |
|------|------|
| `docs/sop.md` | Process authority (v15.0-verified) — stage/quality control |
| `docs/stage0.md` | Design blueprint archive (content state v9.8; header label lags — see `docs/lang-design/README.md`) |
| `docs/develop/v0/stage-0/` | Stage 0 plan + sub-stage plans |
| `docs/develop/v0/tech-debt-register.md` | Technical debt ledger (TD-001…) |
| `docs/develop/v0/calibration-data.md` | Process calibration pool |
| `docs/tests/` | Test documentation twin tree |
| `docs/worklog/` | worklog rec tree (routing index) |
| `worklog.md` | Flat append-only worklog (single source of truth) |

## License

Not yet determined (cold-start repository; upstream doc repo:
Redskaber/subscription_and_notification_channel).

# Stage 0 性能基线（performance-baseline.md）

> 依据：docs/sop.md §14.6.4（性能测试标准——每个大阶段末尾必须建立性能基线）+ docs/stage0.md §22.3 里程碑第 8 项「性能基准已建立基线数据」
> 产出轮次：Stage 0.11 末轮（2026-09-28）
> 可重跑入口：`cargo run --release --example stage0_baseline`（examples/bench/stage0_baseline.rs——§14.6.4 规则 2 单一入口；零新依赖：std::time + 既有 crate API）
> 统计口径：mean / median（中位数为主判据——抗环境噪声），迭代数逐项标注；每次代码变更后重跑对比（规则 3 回归检测）

## 1. 记录环境

| 项 | 值 |
|----|----|
| rustc | 1.98.1 (48a229cea 2026-09-01) |
| profile | release（debug_assertions=false） |
| CPU | Intel(R) Xeon(R) Processor × 2 vCPU |
| 工作区版本 | v0.11.1（0.10-r3 基线 + 0.11 快照套件） |

## 2. 基线数据（2026-09-28 首录）

| 项 | 工作负载 | 迭代 | mean | median | 判读 |
|----|---------|------|------|--------|------|
| B1 compile-fib | fib 源码 → read + expand + compile + verify 全编译链 | 1000 | 9.7µs | 9.3µs | 编译面 §22.3「编译速度」基线 |
| B2 vm-run-fib25 | fib(25)=75025（入口消费闭包——0.6 锚负载） | 100 | 96.8ms | 96.7ms | VM 执行面 §22.3「执行速度」基线 |
| B3 eval-run-fib20 | fib(20)=6765（元循环求值器——双路径对照面） | 30 | 9.4ms | 9.4ms | eval 路径基线（fib20 口径——meta-circular 开销大） |
| B4 gc-pressure-churn | 2000 顶层丢弃 pair 分配（预算 1024——collect-then-retry 实路径） | 50 | 0.37ms | 0.36ms | GC 面基线：1 cycle/iter，swept 1023/iter（≈预算满触发一次全量清扫） |
| B5 driver-e2e-fib25 | run_source VM fib(25)（session + 管线 + halt 快照全链） | 50 | 98.4ms | 97.6ms | 端到端基线（B2 + ~1.6ms 驱动层开销） |

**回归判定口径（规则 3）**：median 恶化 > 25%（环境噪声带）= 性能回归 → 定位变更轮次并评估；B4 的 gc-cycles/swept 为行为指标——数值变化即语义变化（分配率或存活集变更），必须解释。

## 3. 热点识别（规则 4——O(n²) 或更差算法的优化候选登记）

| 热点 | 复杂度现状 | 证据 | 处置 |
|------|-----------|------|------|
| VM 解释循环 fib(25) ~97ms | fib 调用树指数级（242,785 calls ≈ 2.4µs/call） | B2/B5 | 负载本性（naive fib 无记忆化）——非实现缺陷；吞吐 2.4µs/call 对 Stage 0 树遍历 VM 属预期量级 |
| eval 元循环 fib(20) 9.4ms | 同上 + 每步 ClosureData 分配 | B3 | 对照面设计目的（parity 双路径互查）——性能非其验收轴 |
| 字节码编译 ~9.3µs/fib | 线性于 AST | B1 | 无热点 |
| 标记-清除全停顿 | O(live+slots) | B4 | Stage 2+ 演进窗登记（分代/并发 GC——stage0.md §9.43 K7 对照表已登记） |

**结论**：Stage 0 无功能性性能缺陷（语义正确性优先——原则 19）；B4 全停顿 GC 为已知登记态演进窗，非本阶段债。

## 4. 变更同步义务（规则 5）

- 本表由每次涉及 VM/编译器/驱动/GC 的代码变更轮次重跑刷新（worklog 记录对比）。
- `docs/tests/pipeline-test-coverage.md` 性能基线表引用本文件（不重复承载——单一事实源 §8.4.5）。
- 基线数值只在环境变更（rustc/CPU）或有意优化时整体重录，禁止静默漂移。

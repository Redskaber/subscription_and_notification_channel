# 综合技术债登记册（tech-debt-register.md）

> 依据：docs/sop.md §6.2.1。只追加不删除；已解决项保留历史并标注 `[Resolved at Stage N.M]`。
> **Author**: redskaber（模板口径沿袭 sop.md §6.6.1 样例）
> **Version**: v0.14.0（Stage 1.1 更新——无新 TD[driver 接线轮：中止/非阻断/渲染/增量四族护栏全过 + 基线共变 5 处全披露 + 设计级验证发现 1 项非缺陷{REPL set! 重绑使 R2 assign 护栏跨提交生效——保守纪律实证}]；TD 账面维持归零——开放项 0；实现侧运行语义缺陷 0——**连续六轮**）
> **最后更新**: Stage 1.1 / 2026-09-28

### 1.1 架构摘要增量（driver 接线时点）

- 新内部边 L4.5→L8（kerf-typecheck→kerf-driver——消费边无环；Externals 第三消费位单源构造）；管线终态 = read→expand→typecheck→{compile→VM, eval}（检查器 Error 级执行前中止 / Warning 级附着 Outcome 三面非阻断）；DiagnosticCode::Typecheck(TypeCode) 数据携带变体（渲染 tag = E0xxx 注册码——两方案接线处汇合）；REPL 警告增量重放（前缀规则与 outputs 同款）；审计集 130（+N 节十案）。
- 工作树终态：881 测试（driver 内联 118[+25] + 根集成 210[+10]——cargo test 口径）+ audit 130（A-N）+ 基线 B1-B5 维持；生产面 .unwrap 0 / glob re-export 0 / §11 反向边 0 维持。

## 1. 已解决项（Resolved）

| ID | 描述 | 解决阶段 | 验证方式 |
|----|------|---------|---------|
| TD-002 | `Span::join` 跨展开代合并被拒绝（JoinExpansionMismatch）：跨代合并语义属宏期关注点，未定义 | **[Resolved at Stage 0.4]** 裁定三（plan-0.4.md §4）：0.4 展开器零 span 构造（脱糖节点复用源 span 同代次）→ 跨代 join 结构性不发生；拒绝语义保持为设计行为（fail-closed）；0.9 宏系统登记 span 集合表示议程（def-site ∪ use-site——非点合并） | fib/do 契约测试全产出 span join 折叠全成功（单代次实证）+ syntax_seed_tests 跨代次拒绝穿透（0.2）守护 |
| TD-004 | §18.5 依赖图未含 kerf-span→kerf-core 边，与 stage0.md §8.6「IR 节点携带 Span」存在张力 | **[Resolved at Stage 0.1]** 裁定二（docs/develop/v0/stage-0/0.1-design-adjudications.md）：全节点携带必填 Span（非 Option）+ 加边 L0→L4 + dataflow.md 同步 | core_seed_tests.rs 8/8（span 归约双向模式 + Span 不变量穿透聚合路径） |
| TD-005 | 原语集双轨口径（r67 现行真值集 vs §3.2 历史冻结集）待正式裁定落文 | **[Resolved at Stage 0.1]** 裁定一（同上文件）：CoreExpr 九语义原语 + ModuleItem 三声明变体 + do→Let 脱糖；§6.12.6 语义等价映射双向闭合；八原语 ANF 形态登记为 Stage 2 评估目标（零实现义务） | expr.rs kind_name 九变体断言 + 裁定文映射表闭合论证 + ALG-C 会签 |
| TD-001 | 行/列渲染延后：Span 仅存字节偏移（stage0.md §12.1 渲染期派生原则），LineIndex 与行列派生属诊断渲染层 | **[Resolved at Stage 0.8]** 裁定十三（plan-0.8.md §4）：`LineIndex` 渲染期派生落位（1 基行 + 1 基**字符**列——CJK 终端真值；中点字符向下取整 + 越界钳制——确定性不 panic）+ rustc 风格渲染收口（`error[code]: msg` + `--> file:line:col` + 源摘录 + 脱字符下划线 + 多诊断汇总行）；`Diagnostic.primary_span: Option<Span>` 诚实设计（无位变体免伪造——免 `-->` 免摘录） | line_index 13 + render 13 内联测试 + 审计 I01/I10 + seed 渲染黄金字节契约 + CJK 字符列可区分断言（1:19 vs 字节列 1:21） |
| TD-003 | 8 个骨架 crate 待实现（结构性脚手架——计划内，非事故性桩）；core@0.1、syntax@0.2、reader@0.3、expander@0.4、compiler@0.5、vm@0.6、runtime@0.7、**driver@0.8** | **[Resolved at Stage 0.8]** 全部落位（**9/9 crate**——0.0 章程 TD-003 终态清零）：kerf-driver = 管线编排（Engine 双引擎）+ Session/LineIndex/诊断渲染 + CLI/REPL（session-replay 裁定十二）+ bin `kerf`；L1→L8/L7→L8 新边裁定十一入档 | 六命令冷构建 551:0:0 + 审计 80/80 + E2E 22 case（五类源可达错误类经 driver 全点亮）+ `cargo run --bin kerf` 全命令族实测 |
| TD-006 | docs/stage0.md 文件头版本标签（v8.8）滞后于内容实态（v9.9——尾部附录 G v7 终态注记 + §9.43）；上游存档保持原样不改写 | **[Resolved at Stage 1.0]** 用户显式指令开窗（M1 先例——r74「用户指令 = 需求信号本体」）：文档状态行 v8.8→v9.9（增量链叙述 + v8.8 基线描述保留）+ 版本历史「v7.0（当前）」过期标签修正（→历史）+ v7.1-v8.8 / v9.1-v9.9 两条合并条目 + 文件尾附录 G v9 终态注记（v9.9 版本终态 + 四处一致声明）——TD 账面归零 | 四处一致性核验（v9.9 命中文档状态行/版本历史合并条目/附录 G v9 终态注记 + lang-design/README 代偿说明退役） |

## 2. 剩余项（Open）

| ID | 描述 | 等级 | 目标解决 | 阻塞条件 |
|----|------|------|---------|---------|
| （无——TD-006 于 Stage 1.0 清偿，开放项归零） | | | | |

## 3. 架构摘要（Stage 0.10 时点）

- 流水线：`Reader → Expander → Compiler → VM → Runtime` + Driver 编排（九层 9/9）+ **基础卫生宏系统**（define-syntax/syntax-rules 变换器 + CodeValue 结构化代码值 + 模块加载层[三色 DFS 环检测 + LoadPlan] + quote 数据字面量）+ **reserved 冻结面**（kerf-core/src/reserved/ 四模块：EffectSystem/MultiStage/CapabilityIO/CompilationCache + 行为规格 kit——§22.3 四接口项全 ✅；零入边自含抽象——除 std 外零依赖[裁定十七]；全图见 docs/graph/stage-0/dataflow.md）
- 测试计数：**672**（分项 = span 40 + core 77[+36：reserved 内联 30 + api 6] + syntax 40 + reader 54 + expander 85 + compiler 44 + vm 55 + runtime 42 + driver 97 + 根集成 runner 138[+12 reserved_seed]；正负比 272:400 = 1:1.47——0.10 轮 32:16 反向偏差申报见 plan-0.10.md §3[预留轮验收面结构性正向]）+ §7.3.1 审计集 100 case（examples/audit/stage0_gate_audit_r1.rs 可重跑——30→…→100 单调增长；**七类 7/7 维持**）
- Span::DUMMY 状态：**不存在 DUMMY span**——`Span::new` 为校验构造（start ≤ end 强制），空 span 合法但携带真实偏移；CoreExpr/ModuleItem/SyntaxObject（含 reader 产树全节点）span 为必填字段（非 Option——结构性无 DUMMY，TD-004 裁定二延展至语法/读取层）；compiler debug_info 逐指令平行（除空程序冷启动锚一处零 span 构造——plan-0.5.md §4 决策 15）；未来任何 DUMMY 引入即 P1（§6.2 分级审查）
- 枚举分支覆盖：SpanError 三变体 + CoreError 三变体 + SyntaxError 二变体 + ReadError 十变体 + ExpandError **九变体**（+MacroPatternMismatch/+QuoteUnsupportedDatum，0.9）+ **ModuleError 三变体**（ModuleCycle/ModuleNotFound/ModuleDuplicate，0.9）+ **CompileError 十三变体**全部有负向断言（构造拒绝/合并拒绝/消息渲染/R8 形态；InvalidSymbol 三 crate 渲染逐字节一致——单源字典）
- 错误系统状态：kerf-span / kerf-core / kerf-syntax / kerf-reader / kerf-expander / kerf-compiler 均手写 `std::error::Error`（零外部依赖——§18 审查规避裁定沿袭）；CompileError（十三变体，0.5——verify 公共面裁定四：编译期簿记 + 产物自检两道防线）；**RuntimeError（十变体，0.6——全携带 Span 回查 + span() 消费面；七类 #4/#5 点亮 → 6/7）**
- 原语集真值：CoreExpr 九语义原语（r67 命名）+ ModuleItem **四声明变体**（+DefineSyntax，0.9）——单一事实源 = crates/kerf-core/src/{expr,module,symbol}.rs（TD-005 裁定一）；八原语 ANF 形态 = Stage 2 评估目标（登记态，零实现义务）
- 字节码真值：Opcode 24 操作码（§8.12 七分组 + Perform/Handle 承载扩展）+ Instr{op,a,b} 双槽 + FuncProto（code/debug_info 平行）+ Bytecode 五件套（funcs/consts/globals）——单一事实源 = crates/kerf-compiler/src/{opcode,bytecode}.rs；`Bytecode::verify` = 唯一合法性判据（DAG 深度传播 + 结构校验）；三层帽序 reader 256 < expander 512 < compiler 1024（逐层 2× 裕量）
- 运行时真值（0.6）：Value 八变体 + Heap 单调分配（§19.4 安全点 = 分配预算 u32——0.7 gc_cycle 挂接点）+ 帧三扩展槽冻结（ext1/ext2 Reserved + ext3 实名）+ STAGE0_GLOBALS 18 名播种注册表（Builtin::ALL 单源）+ DEFAULT_BUDGET 8MiB（帧+堆单元合账）——单一事实源 = crates/kerf-vm/src/{value,builtin,frame,vm}.rs；0.5 缺陷修复：end_closure cur_stack LIFO（多闭包产物正确性——plan-0.6.md §4 回归对）

### 架构摘要 0.11 增量（末轮收口时点）

- 快照层 57（tests/v0/stage0/plan/snapshot_seed_tests.rs——L1→L8 六分节全链冻结 + 黄金值录制纪律 + 共变义务文档化）+ 性能基线 B1-B5（examples/bench/stage0_baseline.rs std-only 可重跑 + performance-baseline.md 回归口径）+ 深验七件套（docs/develop/v0/stage-0/ + docs/tests/pipeline-test-coverage.md）——Stage 0 出阶段评审 GO（§21.5 九信号 + §22.3 十二项全勾）。
- 工作树终态：767 测试（内联 489 / crate API 78 / 根集成 200）+ audit 110（A-L）+ 基线 5 项；生产面 .unwrap 0 / .expect 33（全带理由）/ TODO 族 0 / glob re-export 0 / §11 反向边 0。
- 登记顺带项（非 TD）：闭包创建整帧 locals.clone（vm.rs:244——Stage 2 优化窗捕获分析）；builtin.rs 四处裸 unreachable!()（臂前守卫完备——Stage 1 E0xxx 议程顺带补消息惯例）。

## 4. 分类索引

- 按 §6.1 等级：**开放项 0（TD-006 @ Stage 1.0 清偿——账面归零）**｜已解决 ×6（TD-004/005 @ 0.1，TD-002 @ 0.4，TD-001/TD-003 @ 0.8，**TD-006 @ 1.0**）｜缺陷修复 ×3（0.5 end_closure cur @ 0.6；0.7 invoke 悬垂 @ 0.7；0.8 TapeIo/stdin @ 0.8——均 §20.6 当轮闭环零遗留）｜0.10/0.11/1.0 轮：无新 TD
- 按 §11.3 接口隔离违规（L-PIPE-N）：无
- 按 §10 命名违规（L-NAMING-N）：无
- 按 §13.4 重构判据（J1-J6）：无

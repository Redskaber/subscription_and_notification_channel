# 全局测试矩阵（matrix.md）

> 依据：docs/sop.md §9.5。每子阶段完成后更新；阶段门审查（§7.3）的输入。
> 口径：「近 100%」= 功能覆盖 + 回归 + 边界 + 负向 + 审计 + 流水线路径 + 正负比（1:3+）；允许 ≤5% DEFERRED（有理由有计划），不允许 UNTESTED。

## Stage 0 功能点覆盖

### Stage 0.0（已交付——2026-09-27）

| 功能点 | 测试文件 | 正向 | 负向 | 边界 | 状态 |
|--------|---------|-----|-----|------|------|
| FP1 Span::new 校验构造 | span.rs 内联 | 2 | 4 | ✅（0..0、MAX..MAX、MAX 反转） | ✅ TESTED |
| FP2 Span::root 简写 | span.rs 内联 | 1 | 2 | ✅（与 new 等价性） | ✅ TESTED |
| FP3 is_empty/len | span.rs 内联 | 1 | 3 | ✅（单字节/全幅/MAX） | ✅ TESTED |
| FP4 contains_offset（半开） | span.rs 内联 | 1 | 5 | ✅（start 含/end 排除/空 span） | ✅ TESTED |
| FP5 join 合并 | span.rs 内联 | 1 | 6 | ✅（对称/嵌套/空操作数/双轴独立） | ✅ TESTED |
| FP6 Display + 错误面 | span.rs 内联 | 2 | 4 | ✅（R8 消息惯例断言） | ✅ TESTED |
| 公共 API 面（crate 级） | api_tests.rs | 2 | 6 | — | ✅ TESTED |
| workspace 装配 + 跨阶段消费 | span_seed_tests.rs | 2 | 6 | ✅（token 归约模式） | ✅ TESTED |
| **合计** | | **12** | **36** | | **正负比 1:3 ✅** |

### §7.1.1 七类错误负向矩阵（阶段累计视图）

| 错误类 | 落位子阶段 | 当前状态 |
|--------|-----------|---------|
| 语法错误 | 0.3 | ✅ **0.3 点亮**（UnclosedList/UnexpectedClose/UnterminatedString/InvalidEscape/InvalidBool/MalformedNumber/InvalidSymbol/UnexpectedCharacter 族） |
| 未绑定标识符 | 0.4 | ✅ **0.4 点亮**（UnboundIdentifier——域键控解析 + 全局回退后拒绝；set! 目标面同守） |
| 语法对象为空（空应用） | 0.3/0.4 | ✅ **0.3 点亮 + 0.4 合成面复检**（reader EmptyApplication + expander EmptyForm 双层纵深防御） |
| 参数个数错误 | 0.6 | ✅ **0.6 点亮**（ArityMismatch——闭包 proto params 对 Call argc + 内建固定 arity 双面，全部源码可达） |
| 类型不匹配 | 0.6 | ✅ **0.6 点亮**（TypeMismatch——truthy 仅 Bool / 算术同种类 / car-cdr 操作数 / Call 被调者可调用性四语境，全部源码可达） |
| 模块循环依赖 | 0.9 | DEFERRED（无模块加载） |
| 宏展开深度超限 | 0.4 | ✅ **0.4 点亮**（ExpansionDepthExceeded——EXPANSION_LIMIT 512 预算，独立界定合成树/宏产树） |

> DEFERRED 占比说明：管线类功能随落位子阶段依次点亮（Reader 0.3 ✅ / Expander 0.4 ✅ / VM 0.6 / 模块加载 0.9）；该矩阵为**阶段累计视图**，0.11 门审要求 7/7。当前已落位功能点（span + core + syntax + reader + expander + compiler + vm + runtime + driver + 装配 + 审计集——9/9 crate）无 UNTESTED 项。

### 回归视图

- 全量套件于每子阶段 §3.2 第 6 命令重跑（六命令流水含 `cargo test --release`）；0.0 基线 = 48/48 → 0.1 = 96/96 → 0.2 = 144/144 → 0.3 = 204/204 → 0.4 = 252/252 → 0.5 = 300/300 → 0.6 = 356/356 → 0.7 = 427/427 → 0.8 = 551/551 → 0.9 = 624/624 → 0.10 = 672/672 → 0.10-r2 = 710/710 → **0.11 终态 = 767/767**（+ §7.3.1 审计集 110 case 独立可重跑——30→40→50→60→70→80→90→100→110 单调；**七类 7/7 全点亮维持**；快照 57 ≥50）。

## Stage 0.1（已交付——2026-09-28）

| 功能点 | 测试文件 | 正向 | 负向 | 边界 | 状态 |
|--------|---------|-----|-----|------|------|
| FP1 Symbol 校验构造（含 CJK 白名单被测对象） | symbol.rs 内联 | 3 | 10 | ✅（空白×6 变体/NUL/前导/Unicode 空格） | ✅ TESTED |
| FP2 变体面全覆盖（CoreExpr 9 + LiteralValue 6 + ModuleItem 3）+ Display | expr.rs / module.rs 内联 | 3 | 0 | ✅（负数/负浮点浮点性/嵌套 Pair） | ✅ TESTED |
| FP3 Span 全携带 + visit_spans 前序 | expr.rs / module.rs 内联 | 2 | 0 | ✅（精确序断言：6+6 节点两套 fixture） | ✅ TESTED |
| FP4 语义下限校验构造器 + CoreError 面 | error.rs / expr.rs / module.rs 内联 | 0 | 14 | ✅（重复参数×2/重复效应×2/非法名×5/R8 形态） | ✅ TESTED |
| 公共 API 面（crate 级） | api_tests.rs | 2 | 6 | — | ✅ TESTED |
| TD-004 边活性 + 跨阶段消费 | core_seed_tests.rs | 2 | 6 | ✅（span 归约双向模式 + 不变量穿透） | ✅ TESTED |
| **0.1 合计** | | **12** | **36** | | **正负比 1:3 ✅** |

**累计（0.0 + 0.1）**：正向 24 / 负向 72 = 1:3 ✅；总测试 96（单元 64 + crate API 16 + 跨 crate 集成 16）。

## Stage 0.2（已交付——2026-09-28，tarball 回退恢复轮后首子阶段）

| 功能点 | 测试文件 | 正向 | 负向 | 边界 | 状态 |
|--------|---------|-----|-----|------|------|
| FP1 StxSymbol 校验构造（含 CJK 白名单被测对象；下限与 core::Symbol 逐字节一致） | symbol.rs 内联 | 2 | 8 | ✅（空白×5 变体/NUL/前导/尾随/NBSP Unicode 空白） | ✅ TESTED |
| FP2 Phase 相位模型（二值 + from_u8 校验） | phase.rs 内联 | 2 | 3 | ✅（越级 2/255 + 载荷携带） | ✅ TESTED |
| FP3 ScopeSet 作用域集（有序去重 + union/is_subset_of） | scope.rs 内联 | 2 | 4 | ✅（去重不变量/确定性迭代序/操作数不可变） | ✅ TESTED |
| FP4 StxDatum 六变体 + SyntaxObject 四元组 + visit_spans 前序 + 深翻转 | expr.rs / error.rs 内联 | 2 | 9 | ✅（空表 `()`/嵌套 Display/无 DUMMY 结构性/双翻幂等） | ✅ TESTED |
| 公共 API 面（crate 级） | api_tests.rs | 2 | 6 | — | ✅ TESTED |
| L0→L1 边活性 + 跨阶段消费 | syntax_seed_tests.rs | 2 | 6 | ✅（token→stx 装配 0.3 契约 + scope 翻转/卫生并集 0.4 契约 + TD-002 跨代次拒绝穿透） | ✅ TESTED |
| **0.2 合计** | | **12** | **36** | | **正负比 1:3 ✅** |

**累计（0.0 + 0.1 + 0.2）**：正向 36 / 负向 108 = 1:3 ✅；总测试 144（单元 96 + crate API 24 + 跨 crate 集成 24）。

## Stage 0.3（已交付——2026-09-28，首个源码级管线入口 + 门审全额口径起强）

| 功能点 | 测试文件 | 正向 | 负向 | 边界 | 状态 |
|--------|---------|-----|-----|------|------|
| FP1 StxToken 词法面（§8.1 子集：定界/标识/数/布尔/串/Eof + 注释/BOM/无损覆盖） | lexer.rs 内联 | 7 | 14 | ✅（`.5`/`1.`/`1e5` Rust 语义 + 数字形 fail-closed ×5 + 括号/宏字符拒绝 + lone hash + escape-at-EOF） | ✅ TESTED |
| FP2 read_program 程序面（多形式/嵌套/字节精确 span/空程序/Runtime+空域戳） | parser.rs 内联 | 4 | 13 | ✅（256 帽含边界通过 + 最内层未闭合报告 + 多形式定位 ×2 + 参数位空应用） | ✅ TESTED |
| FP3 ReadError 错误面（十变体 R8 形态族 + 单源字典跨层逐字节） | error.rs 内联 | 0 | 5 | ✅（全变体小写/无句号族检 + InvalidSymbol 三层一致） | ✅ TESTED |
| 公共 API 面（crate 级） | api_tests.rs | 2 | 6 | ✅（帽/空应用/未闭合/数字/布尔/串全负路径） | ✅ TESTED |
| L1→L2 边活性 + 跨阶段消费 + 退役证明 | reader_seed_tests.rs | 2 | 7 | ✅（token/树归约 0.4 契约 + 真实 StxToken 归约（TokenLike 退役）+ CJK 字节精确 + 恢复隔离 + 单源字典跨 crate） | ✅ TESTED |
| **0.3 合计** | | **15** | **45** | | **正负比 1:3 ✅** |

- **§7.3.1 审计集 r1**：examples/audit/stage0_gate_audit_r1.rs——30 case（10 单语句 + 10 多语句 + 5 复杂 + 5 错误恢复），`cargo run --release --example stage0_gate_audit_r1` 可重跑（exit 0），逐子阶段单调增长至 0.11 门审 7/7（plan-0.3.md §6 构成映射）
- **七类错误矩阵更新**：语法错误 ✅（reader 全族）+ 语法对象为空（空应用）✅（reader 读期拒绝——纵深防御，0.4 展开器复检）——**2/7 点亮**；余 5 类 DEFERRED 至落位子阶段（见下表）

**累计（0.0 + 0.1 + 0.2 + 0.3）**：正向 51 / 负向 153 = 1:3 ✅；总测试 204（单元 139 + crate API 32 + 跨 crate 集成 33）。

## Stage 0.4（已交付——2026-09-28，展开器种子 + TD-002 裁定轮）

| 功能点 | 测试文件 | 正向 | 负向 | 边界 | 状态 |
|--------|---------|-----|-----|------|------|
| FP1 ExpandError 错误面（七变体 R8 形态族 + Core 传播 + span 载荷） | error.rs 内联 | 0 | 5 | ✅（source 链接 + span 回取） | ✅ TESTED |
| FP2 expand 表达式面（9 核心形式 + 原子 + nil 保留字 + do→Let 脱糖 + let* 渐进） | expand.rs 内联 | 5 | 12 | ✅（do 恒等/空 let/单多 spec/重复参数/重复效应） | ✅ TESTED |
| FP3 expand_program 模块面（define 双形 + letrec 顶层 + require/module + 全局表） | api_tests.rs | 2 | 6 | ✅（STAGE0_GLOBALS 18 名 + fib 契约 + 坏形族） | ✅ TESTED |
| FP4 帽/卫生/跨阶段（512 预算双向 + 域键控 + 相位 + span 单代次 + fib 契约） | ctx.rs 内联 + expander_seed_tests.rs | 5 | 19 | ✅（foreign-scope 拒绝 + 预算下溢饱和 + 模块隔离 + 字节定位） | ✅ TESTED |
| **0.4 合计** | | **12** | **36** | | **正负比 1:3 ✅** |

- **§7.3.1 审计集 r1 单调增长**：30 → **40 case**（+E10 展开器负向：未绑定×2 / 深度越界 / 相位 / 形态族×3 / 顶层表达式 / 空表合成面 / 重复参数），`cargo run --release --example stage0_gate_audit_r1` 可重跑（exit 0）
- **七类错误矩阵更新**：未绑定标识符 ✅ + 宏展开深度超限 ✅——**4/7 点亮**（语法错误 + 空应用 @0.3，未绑定 + 宏深度 @0.4）；余 3 类 DEFERRED 至落位子阶段（见上表）
- **TD-002 裁定**：0.4 展开器零 span 构造（脱糖节点复用源 span 同代次）→ 跨代 join 结构性不发生 → 拒绝语义保持为设计行为 + 0.9 span 集合表示议程登记（plan-0.4.md §4 裁定三）——**[Resolved at 0.4]**

**累计（0.0 + 0.1 + 0.2 + 0.3 + 0.4 + 0.5）**：正向 75 / 负向 225 = 1:3 ✅；总测试 300（单元 203 / crate API 48 / 跨 crate 集成 49）。

## Stage 0.5（已交付——2026-09-28，编译器种子 + verify 公共面裁定轮）

| 层 | 文件 | 正向 | 负向 | 说明 |
|----|------|-----|-----|------|
| 单元（crate 内联） | opcode.rs（2+0）/ bytecode.rs（2+2）/ compile.rs（4+3）/ verify.rs（0+11）/ error.rs（0+8） | 8 | 24 | FP1-FP4 |
| crate API | crates/kerf-compiler/tests/api_tests.rs | 2 | 6 | 公共面 + fib 契约 + verify 拒绝族 |
| 跨 crate 集成 | compiler_seed_tests.rs（经 runner.rs） | 2 | 6 | fib 全链（reader→expander→compiler→verify）+ do→Let→StoreLocal 链 + 三层帽序（256/512/1024）+ 篡改产物 verify 拒绝 ×4 |
| **0.5 合计** | | **12** | **36** | **正负比 1:3 ✅** |

- **七类错误矩阵更新**：**维持 4/7**（0.5 编译器为直译层——合法 CoreExpr 无语义拒绝面，不新增检测类点亮；参数个数/类型不匹配 = 0.6 VM 执行校验层、模块循环依赖 = 0.9 加载层——结构性 DEFERRED 记账沿袭）
- **裁定四（verify 公共面）**：§19.3 三不变式两道防线机械化（编译期簿记 fail-closed + `Bytecode::verify` DAG 深度传播/结构校验公共 API——0.6 VM 加载期钩子 + 手工坏产物负向测试面）——plan-0.5.md §4
- **审计集**：40 → **50 case**（F 节编译器负向 10：深度帽越界合成树 + verify 拒绝族 ×9 手工坏产物——cargo run exit 0）
- **TD-003 消解**：kerf-compiler 实现（骨架余 4 → 3：vm/runtime/driver）

## Stage 0.6（已交付——2026-09-28，VM 种子 + 0.5 缺陷修复轮 + 七类 6/7 点亮轮）

| 层 | 文件 | 正向 | 负向 | 说明 |
|----|------|-----|-----|------|
| 单元（crate 内联） | value.rs（3+6）/ builtin.rs（1+4）/ error.rs（0+8）/ frame.rs（1+2）/ vm.rs（3+11） | 8 | 31 | FP1-FP4 |
| crate API | crates/kerf-vm/tests/api_tests.rs | 2 | 5 | 公共面（DAG 纪律：kerf-compiler 面 + kerf-core dev 夹具）+ verify 钩子 + I/O 回环 + 效应/除零负向 |
| 跨 crate 集成 | vm_seed_tests.rs（经 runner.rs） | 2 | 6 | **fib 源码→值四段一断（fib(10)=55 + fib(25)=75025——§20.1 Week 3 判据）** + STAGE0_GLOBALS parity + let/set!/do 执行 + arity 双面 + type 四语境 + 效应最近匹配 + 溢出边界 |
| **0.6 合计** | | **12** | **42** | **正负比 1:3.5 ≥ 1:3 ✅** |
| 0.5 回归对（§20.6 修复记账） | kerf-compiler compile.rs 内联 | 2 | 0 | end_closure cur 递减缺陷（多闭包产物损坏）——cur_stack 修复 + 兄弟/嵌套闭包回归 |

- **七类错误矩阵更新**：**6/7 点亮**（+参数个数 #4 + 类型不匹配 #5——VM 执行校验层落位，四语境全源码可达）；余 1 类结构性 DEFERRED（模块循环依赖@0.9 加载层）
- **裁定五（Call 栈布局调和）+ 裁定六（Perform 最小执行语义）**：以编译器实际发射为准（§8.4.5 代码优先）+ handler 即动态函数（§9.1.1 预留层边界内最小完备）——plan-0.6.md §4
- **审计集**：50 → **60 case**（G 节 VM 负向 10：源码级 arity×2 + type×4 + unhandled effect + div-zero + 溢出 + 预算——cargo run exit 0）
- **TD-003 消解**：kerf-vm 实现（骨架余 3 → 2：runtime/driver）
- **0.5 缺陷修复**：`end_closure` cur 递减 → cur_stack LIFO（§20.6 同类全量 + 回归对 2——verify 第二道防线在加载期拦截损坏产物实证）

## Stage 0.7（已交付——2026-09-28，Runtime 种子 + 双路径互查轮）

| 层 | 文件 | 正向 | 负向 | 说明 |
|----|------|-----|-----|------|
| 单元（kerf-vm 演进） | value.rs（2+2）/ error.rs（0+1）/ vm.rs（2+2） | 4 | 5 | Heap 收集器面（free-list 复用/mark 复位对称/悬垂读 None/越界防御）+ EvalDepthExceeded 变体 + collect-then-retry 注入面（MiniCollector 夹具——L6 不依赖 L7 的测试术）+ snapshot_roots 四类+handlers |
| 单元（kerf-runtime） | gc.rs（0+12）/ eval.rs（3+19）/ parity.rs（2+1） | 5 | 32 | GC 防御族全负向（回收精确/深链 10^5 爆栈对策/自环/幂等/悬垂根跳过/空堆/复用一致性）+ eval 九原语 + 十一变体错误族 + R8 消息族 + 深度帽 + saved-env 悬垂修复的行为面 |
| crate API | crates/kerf-runtime/tests/api_tests.rs | 3 | 2 | 装配（哨兵 proto 锚定）+ I/O 回环 + MarkSweep trait 注入面 + 预算 fail-closed + R8 |
| 跨 crate 集成 | runtime_seed_tests.rs（经 runner.rs） | 7 | 13 | **15+ 程序双路径互查（fib×2/算术整浮/比较/if/let*/do+set!/闭包×2/cons链/谓词/eq? 同一性/效应最近匹配）+ STAGE0_GLOBALS 三面官方断言 + E2E 源码→值 I/O parity + VM 注入端到端（无 collector fail-closed ↔ 注入跑通 + fib(25) 回归）+ 负向 parity 族（错误变体+消息逐位一致）+ IEEE NaN/±0.0 语义 + 深度帽不对称边界 + foreign root 保护** |
| **0.7 合计** | | **19** | **52** | **1:2.7（偏差申报见 plan-0.7.md §3——GC 防御族全负向 + parity 验收本体）** |

- **七类错误矩阵**：维持 **6/7**（eval 路径 case-for-case 与 VM 一致——错误层 parity 实证；余 1 类结构性 DEFERRED：模块循环依赖@0.9）
- **审计集**：60 → **70 case**（H 节 runtime 负向 10：eval 源码级 ×7 + GC 防误回收端到端 + parity 检测器自检——cargo run exit 0）
- **TD-003 消解**：kerf-runtime 实现（骨架余 2 → 1：driver）
- **P1 缺陷闭环**：invoke saved-env 悬垂（根集不完备的 eval 形态）——temp 保护修复 + 程序隔离同类回补（§20.6）

## Stage 0.8（已交付——2026-09-28，Driver 种子 + 诊断渲染收口 + TD 双清偿轮）

| 层 | 文件 | 正向 | 负向 | 说明 |
|----|------|-----|-----|------|
| 单元（消费面扩展） | reader error.rs（0+3）/ compiler error.rs（0+2） | 0 | 5 | ReadError::offset()（6 有位/4 载荷本体）+ CompileError::span()（10 有位/3 缺失即缺陷）逐变体断言——ExpandError::span() 0.4 已预置零改动 |
| 单元 session.rs | 内联 | 4 | 1 | 文件 intern 顺序 id + upsert 同 id 源替换 + 反查 + 未知 id fail-closed |
| 单元 line_index.rs | 内联 | 10 | 3 | TD-001 行列派生：空源/单行/多行/换行归属/孤立换行/CJK 字符列/CRLF/尾换行/多位行号 + 中点字符取整/越界钳制/越界行 fail-closed |
| 单元 diagnostic.rs | 内联 | 5 | 6 | §8.7 切片：Severity/Code 稳定标签 + 四阶段 41 变体穷尽映射（ReadError 10 逐变体循环断言 + expand/compile/runtime 族）+ 消息 R8 逐位透传 + 无位不伪造 |
| 单元 render.rs | 内联 | 9 | 4 | rustc 风格黄金快照（`error[code]: msg` + `-->` + 摘录 + 脱字符下划线）+ 槽宽自适应 + 多诊断分隔汇总 + CJK 字符列 + 混合文件 + 无位免 `-->` + 跨行钳制 + 未知文件防御 |
| 单元 pipeline.rs | 内联 | 7 | 8 | Engine{Vm,Eval} 双引擎 fib 值 + parity 三面（值/输出/全局表——分歧数据化）+ check 计数 + I/O 往返 + 四阶段错误 code 断言 + 帽序深链 |
| 单元 repl.rs | 内联 | 11 | 5 | session-replay：define→表达式持久/包装取值/原子包装/计数器稳定/多行未闭合恢复/增量输出尾部/多表单/混合/重定义 last-wins + 错误回滚 ×3 + 超带 Eof |
| 单元 cli.rs | 内联 | 11 | 7 | run/check/repl/--help/--version 解析 + 退出码 0/1/2 + 输出/值打印语义 + parity PASS + REPL 循环 EOF + 用法错族（未知命令/未知选项/缺引擎值/坏引擎名/缺文件/不可读文件）|
| crate API | crates/kerf-driver/tests/api_tests.rs | 4 | 2 | 公共面装配（run/check/parity/line_index/render/repl/cli/version）+ 错误数据化 |
| 跨 crate 集成 | driver_seed_tests.rs（经 runner.rs） | 12 | 10 | **§7.1 全套：五类源可达错误类经 driver E2E 全点亮（语法/空应用/未绑定/参数个数/类型不匹配）+ fib 双引擎 + parity + I/O 双引擎 + check + REPL 会话 + 渲染黄金字节契约 + CLI 退出码 + CJK 字符列（1:19 vs 字节列 1:21 可区分）+ 250 深帽序边界探针 + 多文件多诊断 + REPL 回滚恢复 + 全链消费（L2/L3/L5/L6/L7→L8 五边活性）** |
| **0.8 合计** | | **73** | **51** | **1:0.7（偏差申报见 plan-0.8.md §3——编排层主功能面为正向组合语义；错误面 41 变体全变体级覆盖）** |

- **七类错误矩阵**：维持 **6/7**——**五类经 driver E2E 源级可达**（审计 I01-I05 + seed 同构）；第六类宏展开深度 = 合成树专属（256<512 帽序结构性事实——审计 E 节 expander 层维持 + 250 深边界探针证帽序）；余 1 类结构性 DEFERRED（模块循环依赖@0.9）
- **审计集**：70 → **80 case**（I 节 driver E2E 10：五类渲染 + 多文件多诊断 + REPL 回滚 + check 拒绝 + parity 数据化 + CJK 列 + 无位免 `-->`——cargo run exit 0）
- **TD-001 清偿**（LineIndex 渲染期派生 + rustc 风格渲染收口）；**TD-003 清零**（9/9 crate 全落位）
- **消费面扩展 ×3**（ReadError::offset / CompileError::span / kerf-compiler ModuleItem 再导出——全加法零回归）；**当轮实现缺陷 2 闭环**（TapeIo 记录语义 + stdin 预读条件化——§20.6 同类制度化）

## Stage 0.9（已交付——2026-09-28，CodeValue + 基础卫生宏系统 + 模块加载层 + **七类 7/7 双门槛达成轮**）

| 层 | 文件 | 正向 | 负向 | 说明 |
|----|------|-----|-----|------|
| 单元 code.rs | 内联 | 5 | 0 | CodeValue 六操作（from_syntax/to_syntax/substitute/alpha_rename/symbols/to_source——全总数函数无错误面；§6.3.3 设计 API 合同面） |
| 单元 ctx.rs | 内联（净增） | 1 | 1 | binder-scopes 子集解析（0.4 membership 一般化——非宏代码结构性兼容）+ 宏登记簿（帧内词法作用域 + 异作用域不可见）+ 预算/隔离既有面零回归 |
| 单元 transformer.rs | 内联 | 7 | 5 | syntax-rules 解析（my-if 规范形/字面量表）+ 匹配（通配/变量/嵌套/原子/首规则）+ 实例化（拼接原样/引入代次 gen+1/宏产物再宏 gen+1）+ 注册拒绝（重复变量/省略号/形状 ×3/字面量不匹配/元数） |
| 单元 module.rs | 内联 | 3 | 5 | 装载层：线性链次序/嵌套声明收集/空程序 + **环 ×3（双模块路径/三模块/自引用）** + 缺失 + 重名 |
| 单元 expand.rs | 内联（净增） | 6 | 10 | quote（原子五类/Pair 链右折/符号拒绝/嵌套符号拒绝/元数）+ define-syntax（声明记录/形状 ×3/保留名）+ 宏使用（my-if 形状/未定义/先用后定义/不匹配/自递归深度/模块隔离）+ **卫生防御**（引入绑定重命名 tmp__macro_0 + 使用处绑定不捕获引入引用）+ 宏产宏两代单调 |
| 单元 error.rs | 内联（净增） | 0 | 2 | 新变体渲染面（MacroPatternMismatch 使用点位 + QuoteUnsupportedDatum 边界消息——R8 形态） |
| 单元 core module.rs | 内联（净增） | 0 | 1 | DefineSyntax 构造拒绝 |
| 跨 crate 集成 | macro_seed_tests.rs（经 runner.rs） | 12 | 15 | **验收本体：定义宏→使用→展开→执行四段全链（fib 双引擎 ×2 + parity 三面）+ 卫生可观察值（无卫生 200/有卫生 101 + make-adder 15/105 双向）+ quote car/cdr 链双引擎 + 宏产宏两代双引擎 + 模块程序双引擎 + 嵌套模块宏 + check + REPL 跨行 + CodeValue 真语法面** + 诊断渲染族 15（宏匹配使用点位/quote 边界 ×2/卫生防御/自递归/先用后定义/模块隔离/**模块环 ×3[第 7 类]/缺失/重名/行列位**/注册族 4/quote 元数） |
| **0.9 合计** | | **34** | **39** | **1:1.15（偏差申报见 plan-0.9.md §3——验收面四段全正向不可拆 + CodeValue 合同面无错误面 + 负向穷尽清单；凑数违反 §12）** |

- **七类错误矩阵**：**7/7 全点亮（首次双门槛达成）**——第 7 类模块循环依赖经 driver E2E 源级可达（J06/J07 + seed 三形态[双模块/三模块/自引用]）——子阶段级（≥6/7）+ 门审级（§7.3.1 规则 1 = 7/7）同轮达成；卫生防御族（使用处绑定不捕获引入引用 + 引入绑定不捕获拼接引用——双机制：scope coloring 子集判据 + rename-on-capture）
- **审计集**：80 → **90 case**（J 节宏/模块/quote 负向 10：宏匹配/quote 边界/卫生防御 ×2/宏面深度维持/**模块环 ×2[类 7 点亮]**/缺失/重名/注册族[省略号+保留名]——cargo run exit 0）
- **裁定十四/十五/十六**（双机制卫生配套 + nil 字面量拼写 + 统一未绑定判据）+ 决策 13 项入档（plan-0.9.md §4）；**实现侧运行语义缺陷 0**（设计级预防补齐 1——rename-on-capture[名字基后端传导] + 设计修正 2——死变体删除/表面拼写裁定）
- 消费面：ModuleItem 第四变体 DefineSyntax（kerf-core 声明层）+ compiler/runtime 零码跳过（Require 先例对偶）+ ConstKey::Pair 首次生产性消费（0.5 前置锚转正）+ driver pipeline 挂接 load_program + REPL is_declaration 增头

## Stage 0.10（已交付——2026-09-28，四项接口预留冻结——§22.3 里程碑四接口项达成；**0.10-r2 修订轮 2026-09-28——能力模型预留泛化[用户显式指令开窗]**）

| 层 | 文件 | 正向 | 负向 | 说明 |
|----|------|-----|-----|------|
| 单元 effects.rs | 内联 | 6 | 0 | EffectSystem witness 四面（perform 路由经 EffectOp::Result / 状态累积 / handle 组合 / 捕获闭包）+ 关联类型名达性 ×2（Result 钉定 + Continuation 可名） |
| 单元 multistage.rs | 内联 | 4 | 0 | MultiStage witness（quote→splice 折返 / run 执行至载体结果 / 异载体泛型 E:Expr）+ CodeCarrier 类型钉定 |
| 单元 capability_io.rs | 内联 | 4 | 6 | 令牌 ZST ×2 + Debug 裸名稳定 + IOError kind/message 往返 + 读两行 happy；负向：耗尽 Eof / **中断重试 Interrupted** / 撤销 Denied（仅撤前捕获）/ 拒绝从未活 Denied（零捕获）/ R8 形态四 kind / kind 逐对可区分 |
| 单元 cache.rs | 内联 | 5 | 5 | CacheKey 摘要往返 + Eq/Hash 一致性 + CachedResult 载荷三面 + **kit 双 witness 通过**（HashMap + Vec——kit 泛型性）；负向：**kit 检测力 5 套故意破坏实现**（never-hit / no-invalidate / no-overwrite / wrong-key / payload-corrupt）全 should_panic |
| crate API | api_tests.rs reserved 节 | 6 | 0 | 四族公共路径 + kit 本地复跑 + R8 错误面 + 跨 crate witness（effects/multistage/capability 三 trait 外部实现位）+ cache 形状面 + **std::error::Error 对象面**（Box<dyn Error> downcast 往返） |
| 跨 crate 集成 | reserved_seed_tests.rs（经 runner.rs） | 7 | 5 | 四族经 kerf::core::reserved 根聚合路径 + effects/multistage witness + **drive_cache 下游泛型消费**（对抽象编译——§21.12-10② 行动态）+ kit E2E + 令牌 ZST + 最新胜；负向：未存 miss / invalidate 后 miss / 跨键隔离 / R8 根位置 / **kit 根位置捕捉破坏实现** |
| **0.10 合计** | | **32** | **16** | **1:0.5 反向（偏差申报见 plan-0.10.md §3——预留冻结轮验收面 = 类型形状 + 签名快照[结构性正向]；负向可测面穷尽[kit 检测力 5 + IOError 四 kind + R8 双层 + 令牌纪律]；凑数违反 §12）** |
| 单元 capability 族（r2） | family 4+0 / token 2+0 / registry 5+11 / io +5+0 | 16 | 11 | 裁定二十能力空间：身份卡三元组往返/Eq-Hash 一致/逐字段互异 + 族契约 witness + 令牌词表惯例；负向：**注册 fail-closed 族**（重复名/权威冲突/空名/空权威表/自重复权威/空操作面/未知名/未知权威/R8 形态/kind 互异/**被拒零副作用**） |
| crate API（r2） | api_tests.rs r2 节 | 5 | 1 | 能力空间可达 + io 注册端到端 + **api 位拓展证明 OutsideNet** + re-export TypeId 同一性 + RegistryError std::error 对象面；负向：注册拒绝 |
| 跨 crate 集成（r2） | reserved_seed_tests.rs r2 节 | 4 | 1 | **根位拓展证明 RootClockModel**（与 io 同闭世界加法增长）+ register_any_family 下游泛型消费 + 跨位置治理解析 + coherence；负向：根位重复拒绝 |
| **r2 增量** | | **25** | **13** | **1:0.52 反向（偏差申报见 plan-0.10.md §9——框架面结构性正向；fail-closed 族 11 件负向较 r1 改善；凑数违反 §12）** |

- **七类错误矩阵**：**7/7 维持**（0.9 达成后守恒——K 节 = 预留面合同族新审计族类，不新增错误类）
- **审计集**：90 → 100（K 节）→ **110 case（L 节能力空间 10：io 族契约绑定 / 注册端到端 / 重复名 fail-closed / 权威冲突 fail-closed / 空名拒绝 / 自重复权威拒绝 / 未知解析 None / 审计位拓展证明 / RegistryError R8 形态 + 互异 / re-export TypeId 同一性——cargo run exit 0）**
- **裁定十七/十八/十九**（零入边自含抽象 = §21.12-10② 最强冷启动形式 / 伪码可编译转译纪律 + 词汇漂移消解 / 不透明载荷序列化前瞻）+ 决策 10 项入档（plan-0.10.md §4）
- **行为规格执行化**：check_compilation_cache_contract pub kit（P2「行为规格」从文档义务升格为可执行断言——Stage 1 实现的合同测试复用位）；**实现侧运行语义缺陷 0**（全轮编译级/形态级修正）
- 落位：kerf-core/src/reserved/ 四模块（L4 单一冻结锚点 + 除 std 外零入边 + 六域从属文档声明位[§21.12-10① 冷启动形态]）；§22.3 里程碑四接口项（Effect Handlers / 多阶段编程 / 能力模型 I/O / 编译缓存）全 ✅

## Stage 0.11（已交付——2026-09-28，末轮 L3：≥50 快照 + 性能基线 + 门审 + 深审族 + 校准 + 出阶段勾选）

| 层 | 文件 | 正向 | 负向 | 说明 |
|----|------|-----|-----|------|
| 跨 crate 快照 · Reader（FP1） | snapshot_seed_tests.rs §A | 10 | 0 | RS01-RS10：atom 五类骨架 + 嵌套 list + 注释无损 + 九原语 fib 源 + quote 点号语法事实（`dump_stx` 确定性 walker——span/scopes/phase 不入快照对象） |
| 跨 crate 快照 · Expander（FP2） | §B | 10 | 0 | ES01-ES10：九语义原语逐一直接形态（Fn/Apply/If/Var/Literal/Assign/Let/Perform/Handle）+ do→Let 脱糖 + define 函数糖展开——`apply` 显式头逐字节冻结 |
| 跨 crate 快照 · Compiler（FP3） | §C | 10 | 0 | CS01-CS10：`Instr` Display 机器形态逐指令清单（字面量/if 跳转形状/let store-local 链/闭包 proto/匿名立即调用/cons·car 链/fib 21 指令/入口消费——常量池/全局表索引序冻结） |
| 跨 crate 快照 · VM/Eval（FP4） | §D | 12 | 0 | VS01-VS10 + VE01-VE02：globals 表（编译序）+ outputs + 值形态；双引擎全链各一（fib VM + car Eval）+ `#<pair>`/`#<closure>`/`#<builtin:+>` 不透明形态 + eq? 身份语义 |
| 跨 crate 快照 · Driver（FP5） | §E | 4 | 6 | DS01-DS10：六负向路径渲染黄金字节（未闭合/类型/参数个数/未绑定/空应用/多诊断汇总行）+ check 面计数 + parity 三面 + WORKSPACE_VERSION + 输出行序 |
| 跨 crate 快照 · REPL（FP6） | §F | 4 | 1 | TS01-TS04 + VD01：会话转录（值/新输出）+ 错误回滚后存活 + 未闭合继续跨行续读 + Value Display 八形态卡 |
| **0.11 合计** | | **50** | **7** | **57 case ≥50（§22.3 L6）——1:0.14 反向（分布论证见 snapshot.md §3：确定性契约层结构性正向；错误检测语义由既有 7/7 类承载，错误呈现字节入冻结；凑数违反 §12）** |

- **七类错误矩阵**：**7/7 维持**（快照层为冻结层不新增错误类；负向路径呈现形态 7 case 入冻结）
- **审计集**：**110 case 维持**（0.10-r2 已超额 §7.3 ≥30 全额口径——本轮门审复跑 `cargo run --release --example stage0_gate_audit_r1` = AUDIT PASS 110/110）
- **性能基线（§22.3 L8）**：B1 编译 9.3µs 中位 / B2 VM fib(25) 96.7ms / B3 eval fib(20) 9.4ms / B4 GC 0.36ms（1 cycle + swept 1023）/ B5 端到端 97.6ms——examples/bench/stage0_baseline.rs 可重跑 + performance-baseline.md 入档 + 回归口径 median >25%
- **深审族（§14.5/§14.6/§14.8/§14.9）**：deep-review-round0.11.md（D1-D8 + 投票 5.5/5.5 + 偏差清单 B1×2/B2×3/B3×3）+ 深验七件套（pipeline-test-coverage / architecture-review / design-impl-test-coverage / hidden-problems-assessment / refactoring-optimality-review / performance-baseline / final-assessment）+ §14.9 C1-C6（零 TODO + 零 unwrap + 2 历史时态注记当轮修）
- **§21.5 九信号 + §22.3 十二项**：全勾（final-assessment.md §2/§3——出阶段评审 GO，提请用户确认）
- 落位：tests/v0/stage0/plan/snapshot_seed_tests.rs（经 runner.rs 挂载）+ examples/bench/stage0_baseline.rs（[[example]] 注册）；**黄金值录制纪律**：0.10-r3 基线（710:0:0 + audit 110/110）temp probe 实测录制 + 逐条目检 + 冻结内嵌

### 回归视图（末轮终态）

- 全量套件于每子阶段 §3.2 第 6 命令重跑；0.0 基线 = 48/48 → … → 0.10 = 672/672 → 0.10-r2 = 710/710 → **0.11 终态 = 767/767**（+ §7.3.1 审计集 110 case 独立可重跑——30→…→110 单调；**七类 7/7 全点亮维持**；快照 57 ≥50；性能基线 B1-B5 入档）。

## Stage 1.0（已交付——2026-09-28，kerf-typecheck 种子：E0xxx 注册面 + 保守静态 R1-R8 + 多错误收集）

| 层 | 文件 | 正向 | 负向 | 说明 |
|----|------|-----|-----|------|
| 注册面 + Externals（FP1/FP2） | code.rs + env.rs 内联 | 9 | 0 | TypeCode 八码稳定字符串 + 互异 + Severity 渲染 + TypeDiagnostic 四字段；Externals 三态解析（Some(Some)/Some(None)/None）+ 双构造器 + 后绑胜出 |
| 规则族（FP3-FP7） | check.rs 内联 | 20 | 22 | R1（顶层 so-far / Fn 体全定义 / letrec 预绑定 / 不见外层 Fn——begin_closure 镜像）+ R2（IIFE/Define→Fn/builtin 三通路 + assign 护栏 + 词法遮蔽跳过）+ R3/R4（含字面 Define 全局位 + 护栏）+ R5/R6/R7（Fn 边界截断健全性 + 最近胜出 + 安装序镜像 + Var→Define 处理器路由）+ R8（两形态警告）+ FP8 多错误收集 |
| API 面 | crates/kerf-typecheck/tests/api_tests.rs | 5 | 2 | 五再导出可达 + 空程序零诊断 + 诊断全字段 + Warning 级区分 + 八码经公共入口逐码可产 |
| 跨 crate 集成 | tests/v1/stage1/plan/typecheck_seed_tests.rs（经 runner.rs） | 9 | 12 | **真实管线全链**（read→expand→typecheck）+ Externals 双源构造（STAGE0_GLOBALS + Builtin::ALL——单源纪律）+ 干净程序健全性守卫族（fib/handle/set!/let 遮蔽/厨房水池）+ 源码可达负向族 + span 字节定位 |
| **1.0 合计（净 +79）** | | **43** | **36** | **正负比 1:0.84 反向偏差申报（分布论证：健全性守卫 = 检查器合法程序永不告警义务的另一半 + 注册面/Externals 形状断言结构性正向；负向集中于确定错误路径 + 护栏放行 + 消息 R8 形态——误报 = P0 级缺陷故负向密集。凑数违反 §12）** |

- **七类错误矩阵**：**7/7 维持**（检查器 = 静态前置层——将类 4[参数个数]/类 5[类型不匹配]/类 6[未处理效应] 从运行时提前至编译期；不新增错误类）
- **审计集**：**110 → 120 case**（M01 干净程序健全性 / M02-M09 规则负向族经真实管线 / M10 注册面 + 单源 Externals 表——`cargo run --release --example stage0_gate_audit_r1` = AUDIT PASS 120/120；七类 7/7 维持）
- **GATE 6 构成**：集成 21 case = 正向 9 ≥1 ✓ / 负向 12 ≥3 ✓ / 跨阶段消费 ✓（read→expand→typecheck 全链 + Externals 双源——≥1）；正负比申报沿 v15.1
- 落位：crates/kerf-typecheck/（L4.5——kerf-core 后 compiler 前）+ tests/v1/stage1/（经 runner.rs `#[path]` 挂载）+ 审计 M 节；§18 零新外部依赖（+kerf-core/+kerf-span 两条内部边）
- 层间分工披露：R1 = 展开器第一道防线（0.4 起 UnboundIdentifier）之外的结构层重断言（直接构造路径）；R2-R7 = 今日仅运行时可检错误的静态化（净新增值）；R8 = 静默行为首个表面化（首个 Warning 生产者）

### 回归视图（1.0 终态）

- 全量套件于 §3.2 第 6 命令重跑；0.11 基线 = 767/767 → **1.0 终态 = 846/846**（净 +79：lib 51 + api 7 + 根集成 21——cargo test 口径；+ §7.3.1 审计集 120 case 独立可重跑——30→…→110→120 单调；**七类 7/7 全点亮维持**；767 基线零回归）。

## Stage 1.1（已交付——2026-09-28，driver 接线：typecheck 级入管线 + 诊断渲染映射 + Warning 接线）

| 层 | 文件 | 正向 | 负向 | 说明 |
|----|------|-----|-----|------|
| 管线接线（FP2/FP3） | pipeline.rs 内联 | 4 | 6 | typecheck 前置（Error 中止/Warning 附着 Outcome 三面）+ 干净程序零发现 + 中止前副作用零发生 + 多错误收集经 driver + 双引擎同发现 + E0006 顶层裸 perform |
| 诊断映射（FP1） | diagnostic.rs 内联 | 3 | 0 | Typecheck(TypeCode) tag = E0xxx + from_typecheck 四字段映射 + Warning 级映射 + 渲染头 error[E0001] 形 |
| 渲染扩展（FP4） | render.rs 内联 | 1 | 3 | 警告摘要行（N warning(s) emitted）+ 纯警告批次无 abort 行 + 混合批次摘要序 + 零警告批次字节不变（ds10 冻结义务单元层）+ 单警告无摘要 |
| CLI 面（FP5） | cli.rs 内联 | 3 | 1 | check/run/parity 警告路径（err 汇 + 退出码 0）+ REPL 循环警告打印 + E0002 渲染 + 退出码 1 |
| REPL 面（FP6） | repl.rs 内联 | 2 | 1 | 警告提交进入程序 + 增量不重印 + 新警告增量 + 确定错误回滚维持 |
| 跨 crate 集成 | tests/v1/stage1/plan/typecheck_wiring_seed_tests.rs（经 runner.rs） | 5 | 5 | 源码可达 E0002/E0003/E0004/E0006 全链 + 渲染注册形（error[E0002] + 位置行）+ 中止前副作用 + 多错误三码同批 + 双引擎警告非阻断 + REPL 增量/回滚 + Typecheck 变体载荷 |
| **1.1 合计（净 +35）** | | **17** | **18** | **1:1.06 对偶均衡（分布论证：非阻断义务 ↔ 中止义务 + 渲染回归面 + REPL 增量语义——三族护栏对偶；基线共变 5 处披露见 plan-1.1.md §4）** |

- **七类错误矩阵**：**7/7 维持**（检查器前置使已知元数错误静态化——类 4/5/6 的已知形态从运行期提前至编译期；运行期面经 checker-opaque 参数中介形态保留覆盖）
- **审计集**：**120 → 130 case**（N01-N04 源码可达 E0xxx 全链 / N05 警告非阻断双引擎 / N06 摘要行 / N07 渲染注册形 / N08 多错误三码 / N09 中止前副作用 / N10 REPL 增量 + 回滚 + parity 警告——AUDIT PASS 130/130；I04 运行期面共变 checker-opaque 形态）
- **GATE 6 构成**：集成 10 case = 正向 5 ≥1 ✓ / 负向 5 ≥3 ✓ / 跨阶段消费 ✓（L4.5→L8 新消费边 + Externals 第三消费位单源构造）
- 落位：crates/kerf-driver/（L8 + 新内部边 kerf-typecheck→kerf-driver L4.5→L8）+ tests/v1/stage1/ + 审计 N 节；§18 零新外部依赖维持
- 基线共变 5 处（行为变更披露）：pipeline/driver_seed/audit-I04 运行期 arity 面 → checker-opaque（`((fn (g) (g 1 2)) car)`）+ ds03 黄金 E0002 静态形 + ds08 版本 0.14.0

### 回归视图（1.1 终态）

- 全量套件于 §3.2 第 6 命令重跑；1.0 基线 = 846/846 → **1.1 终态 = 881/881**（净 +35：driver 内联 25 + 根集成 10——cargo test 口径；+ §7.3.1 审计集 130 case 独立可重跑——30→…→120→130 单调；**七类 7/7 全点亮维持**；846 基线零回归 + 5 处共变全披露）。

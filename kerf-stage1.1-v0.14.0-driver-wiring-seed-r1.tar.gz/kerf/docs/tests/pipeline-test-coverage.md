# 编译流水线测试覆盖与完整性审查（pipeline-test-coverage.md）

> 依据：docs/sop.md §14.6.1.1（数据流覆盖分支检测——完整性审查：枚举全覆盖 + 无静默处理 + 错误路径覆盖 + 流水线阶段覆盖）+ §14.6.4 规则 5（性能基线表引用位）
> 产出轮次：Stage 0.11 末轮（2026-09-28）——全流水线首次四维机械审查（数据采集：Task 16-b3-data，全量 rg 扫描 + 逐处人工分类）
> 口径：production = 各文件 `#[cfg(test)]` 边界之上；test = 内联测试模块 + `tests/` 树 + `crates/*/tests/`

## 1. 枚举全覆盖审查（完整性第一轴）

生产代码枚举共 **32 个**（28 pub + 4 私有）。关键错误/管线枚举在主消费点的穷尽性实测：

| 枚举 | 变体数 | 主消费点穷尽性 | catch-all 位 |
|------|-------|--------------|-------------|
| ReadError | 10 | Display + `offset()` 全穷尽 | **0** |
| ExpandError | 9 | Display + `span()` 全穷尽 | 1（`Error::source`——Option 整形，sound） |
| ModuleError | 3 | Display 全穷尽 | 0 |
| CompileError | 13 | Display（13 臂）+ `span()`（13 臂）全穷尽 | **0** |
| RuntimeError | 11 | Display + `span()` 全穷尽 | 1（`got_kind`——Option 整形，sound） |
| SyntaxError / CoreError / SpanError | 2/3/3 | Display 全穷尽 | **0** |
| Severity / DiagnosticCode | 4/5 | `Display`/`tag()` 全穷尽 | **0** |
| StxDatum | 6 | `kind_name`/`Display`/`expand_node` 全穷尽 | 24（全部为形状探测助手或畸形拒绝——非漏配） |
| CoreExpr | 9 | 编译器 `expr` 与求值器 `eval` 双面 9/9 全穷尽 | 1（eval.rs:240 非闭包 define 值直通求值——语义面） |
| ModuleItem | 4 | `eval_items` + `compile_program` 双面 4/4 | 3（含 1 处带消息 `unreachable!`——声明映射不变量） |
| LiteralValue | 6 | `kind_name`/`Display`/`from_literal` 全穷尽 | 2（`pair_cells` `_ => 0`——非 Pair 字面量零堆格，类型事实） |
| **Opcode** | 24 | **VM 主循环 dispatch 24/24 全穷尽零 catch-all** | 6（verify 三处跳过臂 + builtin 四处守卫臂） |
| Value | 8 | `kind_name`/`Display`/parity `render` 全穷尽 | 4（Option/布尔整形面） |
| HeapObj | 2 | gc.rs 标记走查显式 None+双 Some 臂 | 4（经 `Option<HeapObj>` 整形） |
| Builtin | 18 | 注册表穷尽 + `None => unreachable!`（表完备不变量） | 4（分派守卫） |

**结论**：核心错误族（ReadError/CompileError/RuntimeError/SyntaxError/CoreError/SpanError/Severity/DiagnosticCode）在全部消费点**编译器验证穷尽或零 catch-all**；VM 操作码 dispatch 为 24/24 全穷尽。全部 catch-all 均为四类合法形态：形状探测（Option/bool 整形）、畸形输入拒绝（返回 Err）、类型事实臂（`_ => 0`）、带消息守卫（unreachable!/panic! 携带不变量说明）。

## 2. 静默处理审查（完整性第二轴）

- **`.unwrap()` 生产面：0 处**（全部 ~100 处均在测试模块内）。
- **`.expect()` 生产面：33 处，100% 携带内联理由消息**：VM 13（verify 前置不变量 + 入口帧不变量 + debug_info 平行保证）、runtime 2（零 span 构造恒成立 + 闭包注册配对）、registry 1（Vec push-then-last）、compiler 2（冷启动锚 span + 闭包配对）、driver 1（line_of 耦合）、expander 6（匹配臂守卫 + 生成长度恒真）、reader 3（单调 span 构造）、cache 3（**panic-by-design 合同 kit**——函数文档明示「首违例即 panic」）。
- **`panic!()` 生产面：1 处**（vm.rs:530 堆格闭包不变量——分配点类型化论证）。
- **`unreachable!()` 生产面：11 处**，其中 7 处携带消息；**4 处裸 `unreachable!()`**（builtin.rs:132/143/174/182——算术/比较分派 Int/Float 路径，臂前守卫已限定种类；唯一无消息生产 panic 面，登记为 Stage 1 诊断议程顺带项，非 Stage 0 债——见 hidden-problems-assessment.md）。
- **`.ok()` 生产面：1 处**（diagnostic.rs:98——空 span 构造结构恒真，不可吞真错误）。
- **`let _ =` 丢弃：21 处**，全部为 CLI 外壳输出 best-effort 写（broken-pipe 不 panic——shell 惯例）+ stdin 空带容错，均有注释。

## 3. 错误路径覆盖审查（完整性第三轴）

- 七类错误负向 7/7 维持（matrix.md 累计视图 + audit 110/110 门审级双门槛）。
- 错误枚举变体级负向覆盖：ReadError 10/10、ExpandError 9/9、ModuleError 3/3、CompileError 13/13、RuntimeError 11 变体（含 BudgetExceeded/GcStall/Halt 非源可达族经注入面测试）。
- 管线入口（pipeline.rs / cli.rs / session.rs）：零 unwrap/expect/ok 丢弃，全部 `Result` 经 `map_err(|err| vec![Diagnostic::…])`/`?` 传播——**错误即数据（§12.2）实测成立**。

## 4. 流水线阶段覆盖审查（完整性第四轴）

| 阶段 | crate | 内联测试 | crate API | 根集成（seed） | 合计 |
|------|-------|---------|-----------|--------------|------|
| L0 Span | kerf-span | 32 | 8 | 8（span_seed） | 48 |
| L1 Syntax | kerf-syntax | 32 | 8 | 8 | 48 |
| L2 Reader | kerf-reader | 46 | 8 | 9 | 63 |
| L3 Expander | kerf-expander | 77 | 8 | 8+27（expander+macro） | 120 |
| L4 Core | kerf-core | 90（含 reserved 57） | 20 | 8+17（core+reserved） | 135 |
| L5 Compiler | kerf-compiler | 36 | 8 | 8 | 52 |
| L6 VM | kerf-vm | 48 | 7 | 8 | 63 |
| L7 Runtime | kerf-runtime | 37 | 5 | 20 | 62 |
| L8 Driver | kerf-driver | 91 | 6 | 22 | 119 |
| 跨层快照 | 根 tests | — | — | 57（snapshot_seed） | 57 |
| **合计** | | **489** | **78** | **200** | **767** |

阶段间交接点（§14.7.3 数据流五段）全部有跨层集成锚：read→expand（expander_seed）、expand→compile（compiler_seed fib 全链）、compile→vm（vm_seed 四段一断 + fib(25)=75025）、vm↔eval（runtime_seed 双路径 ≥15 程序 + parity 三面）、全链→driver（driver_seed 22 + snapshot_seed 57）。

## 5. 修复状态

| 发现 | 处置 |
|------|------|
| vm/error.rs:8 类覆盖注记停留 6/7（历史现在时态） | **本轮已修**（补 0.9 第七类点亮句） |
| diagnostic.rs:17 「0.10 拥有该扩展」将来时态 | **本轮已修**（改为 Stage 1+ 登记议程措辞） |
| builtin.rs 四处裸 `unreachable!()` | 无消息但臂前守卫完备——登记 Stage 1 诊断议程顺带项（hidden-problems-assessment.md 行 4），非 Stage 0 阻塞 |

## 6. 性能基线表（§14.6.4 规则 5——引用位）

性能基线单一事实源 = `docs/develop/v0/stage-0/performance-baseline.md`（B1 编译 9.3µs 中位 / B2 VM fib(25) 96.7ms / B3 eval fib(20) 9.4ms / B4 GC 压力 0.36ms + 1 cycle/iter + swept 1023 / B5 端到端 97.6ms；回归口径 = median 恶化 >25%）。本表不重复承载。

## 7. 结论

四轴全过：枚举全覆盖 ✓（错误族零漏配 + Opcode 24/24 dispatch 穷尽）、无静默处理 ✓（unwrap 0 + expect 33 全带理由 + ok 1 结构恒真）、错误路径覆盖 ✓（7/7 类 + 变体级 + 入口零丢弃）、流水线阶段覆盖 ✓（九层各有三层测试 + 交接点全锚定 + 快照层 57 全链冻结）。**§14.6.1.1 通过**。

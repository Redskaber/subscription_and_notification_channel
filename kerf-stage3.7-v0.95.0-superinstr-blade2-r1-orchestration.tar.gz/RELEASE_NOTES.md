# kerf v0.95.0 — W-VM-SUPERINSTR 次刀：F1 直发算术落地 + 窗口关闭（r134）

第一百三十四轮（r134 · Task 134）· SOP v15.3 §21.12-28 自举阶梯最高优先（T-a 生产位切换链路）· W-VM-SUPERINSTR 实施窗次刀 + 关闭轮（上游裁定 = r132 W-3.7 评估窗 §4.3-1 + 本窗 SI-6 切轮排期；自 r133 闭合态续作）。

## 本轮交付

- **形态裁定 FA-1..FA-6**（w-vm-superinstr-window.md v1.1→v1.2——窗口记录单源）：FA-1 全程序逐名毒化集（三毒源 = module define / extern 条目名 / 任意 assign——program-wide 非逐函数，重绑函数与调用函数调用序任意；四类不毒化面 = let/bind 局部、fn 形参、capture 解析[发射位局部解析天然回退]、perform/handle 效应名；Require 零毒化——模块图只解析树内 module，扫描结构完备）；FA-2 发射位六合取（Var callee ∧ local 未命中 ∧ capture 未命中 ∧ 名∈{+,-,*,/} ∧ 未毒化 ∧ argc==2 → 直发 Add/Sub/Mul/Div——操作码面 26 维持，四臂在树自 Stage 0，本刀加发射路径；argc≠2 回退保全 ArityMismatch）；FA-3 构造性单源等价（builtin dispatch 与 VM 操作码臂同函数 `arith`——等价非论证而是构造；TypeMismatch/DivByZero/ArithmeticOverflow 三族两路同源同 span）；FA-4 intern 序确定性（直发名零入表——首用序列移除元素不重排其余）；FA-5 孪生镜像 = cp_assemble 搭载式扫描（线性流扫描每记录一闭包帧爆 eval 引擎 2048 深度预算[fixpoint 自身源码数千记录]——设计修正实录：装配遍每记录恰访问一次零新增帧，毒化集等价性构造保持）；FA-6 守卫反转与再生成义务。
- **F1 直发算术全链**（compile.rs 毒化扫描 `scan_arith_poison`/`scan_arith_poison_expr` + `Compiler.arith_poison` + Apply 臂 F1 分支；compiler.ktf `cp_arith_four`/`cp_arith_ops`/`cp_arith_mark`/`cp_arith_extern` + cp_assemble define/assign/extern 三臂搭载 + acall 臂 F1 分支——gate B 逐位等价维持 + fixpoint 自复现；C 后端零改动——Add/Sub/Mul/Div 臂与 k_arith 既有）。
- **三层防御实测发现**（诚实披露）：extern 名 = 算术名 → 展开层 ExternNameCollision 先拒（源级不可达）→ 编译层 extern_table_floor 拒不可导出 C 符号名（`+`/`*`/`/` 不可达）→ `-` 角落（可导出 `_`）可达毒化形态但双引擎播种皆内建优先 = extern 惰性角落——毒化规则维持为防御纵深。
- **守卫再生成**（FA-6 清单）：jit_window 四案（census 锚 mul 直发形态 + 四对钉扎翻转 + **F1 触发线反转**[冷态警报 → 直发在位钉扎] + DivByZero census 终点）+ 快照黄金族 13 件（cs02/04/05/06/09/10 + vs01/02/06 + ds06 globals 5→3 + compiler_seed do_desugar + api_tests fib FA-4）+ audit AO01/09/10 再生成。
- **superinstr F1 族 8 件**（正 2/负 6 = 1:3）：直发/毒化值等价（MUV 134-b 集成验证用例——set! 重绑槽位为程序闭包双臂同值）+ 局部遮蔽不毒化粒度钉扎（let 绑定 `+` 内层 plain call、外层直发）+ set! 毒化 + extern 三层钉扎 + 形参遮蔽 + argc≠2 回退（1/3 参 ArityMismatch 保全）+ capture 回退 + 孪生 F1 臂篡改 gate B drift。
- **audit AP 族 10 案**（310→320 live · 41 节）：发射完备 + 毒化三源 + 回退族 + argc 合取 + 值等价 + .krf 往返（四 kebab 对 + add 记录重建）+ C 混合发射（k_arith 与 call 化合物共存）+ intern 序 + 孪生毒化扫描篡改 + census 前提。
- **B 轴终账**（tool-results/r134-dispatch-profile-run{1,2,3}）：fib-25 指令数 **2,427,852 逐位不变**（直发臂 1:1 替换融合调用）+ 三跑中位 **61.544/61.815/61.963ms = 0.75×-0.76×** vs 82.0ms seam 参考（两刀合计 **-25.0%**；每指令成本 29.2→25.35ns = call 开销面坍缩：take_args + invoke + arity 检查 + 内建 match + 值克隆）+ parity OK 全负载 + B4 第二十五次逐位。**带缺口 4.1ms（0.7× 带 ≈57.4ms）如实登记**：第三杠杆 = (load-local, push-const) 对 485,569 次（fib 内 20.0%——K151 经典复制对，纯分派消除，预估 ~12ms 节余可达 0.60×）归 W-JIT-METHOD-T1 开窗裁定输入。
- **三触发器判定全命中 → W-JIT-METHOD-T1 开窗**：① B2 = 61.8ms = 2.60× C-O0 带（> 1.8×）② 解释器开销份额 61.5%（> 40%）③ T-a 链路 ~339×（> 25×）。**窗口 CLOSED**：W-VM-SUPERINSTR Resolved（两刀全链 + 诚实带账）；W-PKG-SELFHOST 前置「融合刀交付后」达成；cranelift 基座内否决维持 r132 裁定。
- **文档族七件**：w-vm-superinstr-window.md v1.2（CLOSED）+ stage-3-plan v2.10 + roadmap v2.64 + tech-debt-register（W-VM-SUPERINSTR Resolved + W-JIT-METHOD-T1 开窗）+ stage0 v9.88（§9.120）+ ds08 r134 注记 + 金链锁步 v0.95.0（Cargo.toml + Cargo.lock 13 处）。

## 验收

六命令（OBS 口径：`--release --jobs 2 --test-threads 1 RUST_MIN_STACK=268435456 ulimit -s 131072`）：build 0e0w / check 0/0 / fmt 零 diff / clippy -D warnings 零 / **test --release 1554:0:4**（基线 1546 + F1 族 8 案）/ doc 零新增警告（唯一 = cargo#6313 既有先例）/ **audit 320/320 live + 104 retired · 41 节**。

---

# kerf v0.94.0 — W-VM-SUPERINSTR 首刀：CallGlobal 融合全链落地（r133）

第一百三十三轮（r133 · Task 133）· SOP v15.3 §21.12-28 自举阶梯最高优先（T-a 生产位切换链路第一刀）· W-VM-SUPERINSTR 实施窗首刀（上游裁定 = r132 W-3.7 评估窗 §4.3-1；本会话自 r132 闭合态续作）。

## 本轮交付

- **形态裁定 SI-1..SI-6**（w-vm-superinstr-window.md v1.0 新建——窗口记录单源）：SI-1 发射时特判（非后处理 pass——span 语义最短路径[融合指令 span ≡ 原 Call span，错误位迁移如实登记] + 跳转目标安全免证[jump 目标只落表达式求值起点——结构性免除分类器] + 孪生镜像面最小 + K150 静态单相）；SI-2 操作码布局 `call-global {a: global index, b: argc}`（Perform 形制对齐——`Opcode::ALL` 25 → 26，「about 35」能力模型裕量维持）；SI-3 栈效应 pops argc/pushes 1（callee 从全局槽直读——复合等价推导入档）；SI-4 语义等价五论证（求值序 §19.3 契约保持 + 读取时点一致 + 错误族逐位迁移[UnboundGlobal/ExternCallRequiresBackend/ArityMismatch/内建族/call callee] + GC/预算零扰动[D-CLASS-1 分配驱动] + 帧语义 invoke 共用）；SI-5 守卫再生成义务六案清单；SI-6 切轮排期（r133 CallGlobal 首刀 / r134 F1 直发 + 复画像 + 窗口收口——MUV 边界禁止降级，r126 五刀先例形制）。
- **CallGlobal 融合刀全链**（133-b）：opcode.rs 26 化（enum/ALL/kind_name `call-global`/ordinal 25 尾插——既有 census 键 0-24 零移位/operand_help/pops/pushes 表单源）+ vm.rs 融合臂（globals[idx] 直读 + extern/unbound 错误族迁位 + `take_args` + `invoke` 共用——零孪生语义面）+ verify.rs Pass 1c a 并组（globals 边界）+ Pass 2/depth.rs 表驱动自动 + cbackend emit.rs 融合臂（`kc_` 临时 + `k_global_load` + `k_call` 复合——C 后端承载融合）+ max_argc 扫描（b 槽）+ compile.rs Apply 臂发射特判（lookup_local/capture_in_cur 幂等序 + intern_global 调用时点对齐——全局表顺序与 capture first-use 顺序零漂移）。
- **compiler.ktf 孪生同步**（133-c）：acall 臂特判（`first(callee)=="var"` + slot/capture 双查 + 融合/回退双臂）+ cp_op_pops/cp_op_pushes 栈效应双表加臂（孪生编译期簿记）——**gate B 逐位等价维持**（fixpoint 自复现：.ktf 编译器经融合发射自编译 byte-for-byte 复现 + 与 Rust oracle 逐位相等）。
- **守卫再生成 + 新族**（133-d）：jit_window_tests 六案 SI-5 再生成（census 锚 12→10 指令全链重推导[LoadGlobal/Call 计数归零 + CallGlobal 计数 2 + 对表 7 对 + 热函数 [6,4]] + 四对钉扎新形态[CallGlobal 拥有位点 + push-const+call-global / load-local+push-const / call-global+jump-if-false 新对钉扎] + F1 触发线维持[算术仍冷] + call 路径断言面 CallGlobal 化 + census 终止/DIV 错误位置断言 pc 迁移）+ 快照黄金族再生成（snapshot_seed cs02-cs10 九案[21 指令 fib 合约 → 19] + ds06 计数 29→22 + compiler_seed 两案 + api_tests 两案 + cbackend 两案[融合形断言 + every_opcode 补非 Var callee 程序] + gc_window 基数 26 + stage_exit 基数 26 + fixpoint 往返 26 + composed 篡改 probe 强化[y 恰居 0 号槽篡改失效根因确诊——z 后置槽结构性 drift]）+ **新族 superinstr_window_tests 8 件**（正 2/负 6 = 1:3——融合/非融合值等价钉扎[MUV 133-b 集成验证用例] + 全语料融合完备性 sweep[91 文件零残留 load-global+call 相邻对] + verify 边界族[越界/下流] + unbound/extern 迁位 + 非可调用 callee + arity 融合位 + 孪生融合臂篡改 gate B drift）。
- **audit AO 族 10 案**（300 → 310 live · 40 节——实施窗增节，r124 AM 先例）：发射完备性[fib 6 融合位] + 融合/非融合值一致 + arity/division 融合位族 + verify 边界 + unbound/extern 迁移 + .krf 往返（rebuild face）+ C 发射复合 + 孪生融合臂篡改；audit V6 基数 26 同步。
- **B 轴复测**（tool-results/r133-dispatch-profile-run{1,2,3}）：fib-25 **2,427,852 指令**（画像预测 -25.9% 逐位吻合——849,746 对全融合）+ 中位 **71.425/70.958/70.918ms**（三跑稳定，0.87× vs seam 参考 82.0ms）+ 解释器开销份额 72.5% → 66.8% + parity OK 全负载 + churn 指令 14,003 → 10,003（-28.6%——cons/car 全融合）。
- **文档族**：w-vm-superinstr-window.md v1.0（新建）+ stage-3-plan v2.9 + roadmap v2.63 + tech-debt-register（r133 检视 + W-VM-SUPERINSTR 首刀进度）+ stage0 §9.118（v9.87）+ 本文件 + Cargo 金链锁步 v0.94.0 + ds08 r133 注记。
- **GATE 1 六命令全绿**（OBS 口径）：build 0e0w ✓ / check 0/0 ✓ / fmt 零 diff ✓ / clippy -D warnings 零 ✓ / test --release **1546:0:4**（基线 1538 + superinstr_window_tests 8 案）/ audit **310/310** live + 104 retired · 40 节（AO 族新增）/ doc 零新增警告（唯一 = cargo#6313 既有先例）。

## 诚实边界

- **目标带 ≤ 0.7×82 ≈ 57ms 未达（0.87× ≈ 71.0ms）**——SI-6 切轮预内：首刀 CallGlobal 单独覆盖画像首对 25.9%，F1 直发算术（182,088 次内建算术调用坍缩）与第二对候选（push-const+call-global / load-local+push-const）归 r134 双杠杆；窗口关闭验收（§4-1）以复画像带内判定为准——首刀如实登记中间值。
- 每指令成本 26.34 → 29.2ns（+11%）：融合臂执行双指令语义工作（fetch+dispatch 省 1 次、语义工作不变）——物理自洽，时间节省 13.4% < 指令节省 25.9% 的结构性解释入档。
- 8 原语不变性第九十六轮验证：零新原语/零新内建/零语法增改/操作码面 25→26（VM 内部编码扩展——SI-2 裁定 + EXC-4/LoadCaptured/effect 族先例族；非 surface 原语）；S-expr 转化记录义务：零新转化面（VM 编码域轮）。
- 实施事故两件如实登记：①孪生注释首版误用 `;` 行注释（target 皮肤 `//` 形态——读取失败即改，五孪生读取守卫触发后当轮修复）；②composed 篡改 probe 的 y 恰居 0 号全局槽 + `+` 迁移融合臂 → 篡改碰巧失效（probe 强化 z 后置槽——结构性 drift 恢复）。

---

# kerf v0.93.0 — W-3.7 JIT/超级指令评估窗：分派画像 + tier-1 三路权衡 + 实施窗开窗裁定（r132）

第一百三十二轮（r132 · Task 132）· SOP v15.3 §21.12-28 自举阶梯最高优先（T-a 解锁前置）· W-3.7 JIT 评估窗闭合（出口三件全过；前置 r131 = W-HM-TWIN 窗口闭合 · 段三 ELEVATED；本会话自 r131 闭合态续作——恢复轮前置件 = GitHub 单次访问 auth-blocked 如实登记[第十七次恢复轮] + 本地权威裁定（b644062 · 工作树净 = r131 闭合态字节级就位））。

## 本轮交付

- **观察 seam 落位（测量基础设施）**：`VmObserver` trait（roots.rs Collector 的依赖倒置孪生——Layer 6 持 fetch 钩点位、harness 持观察算法）+ `Vm::run_observed` 参数传递公共面 + `Opcode::ordinal` census 键。零操作码/零融合/零分派重排（机制面零触碰）；observer 永不驻留 VM（结构体逐字节复原）+ const 泛型单化（`run_dispatch::<false>` 观察臂编译期消除）——A/B 控制链五件归档：朴素形态 +8.7% 否决 → 终态 B2 +2.4% 布局残留（K129 纪律接受，±25% 带内，新参考 ~82.0ms 如实登记）/ B6a 创建面归零（无每指令成本实证）。
- **MUV 3.7-a 分派热点画像出册**（`examples/bench/vm_dispatch_profile` + tool-results/r132 归档四件 + 三跑稳定）：四负载动态普查——fib-25 3,277,598 指令精确计数；fusable 相邻对覆盖 **79.3-100.0%**（fib 81.5%——完美对融合天花板 ≈ 2.45×）；**load-global+call 普适首对 24-29%**（§19.3 求值序契约：args 先 callee 末——每次调用经全局槽装载 = THE 融合候选）；热函数集中 99.9998%；**F1 结构性发现：算术操作码 surface 动态冷**（编译器零算术操作码发射——surface 算术经内建调用路径，最高频操作支付最重路径；守卫 fail-closed 触发线钉扎）。
- **dispatch 份额量化（EXC-10 触发判定）**：B9c 交叉核验——解释器开销份额 **72.5%**（VM 86.3ms vs C -O0 23.7ms 同构对照，三跑 72.5-72.7% 稳定）+ 均匀每指令成本 23-29ns 跨负载（与操作码组合无关）——**EXC-10 触发器强化形态满足**（登记措辞「分派为热点前三」被实测超过：分派是热点本体）。
- **MUV 3.7-b 知识层 K150-K156**（r132-search 七查全落地）：K150 PEP 659 特化自适应（静态单相采纳）+ K151 Ertl&Gregg 2003 超级指令 3.17× + K152 Lua 5.0 寄存器权衡 + K153 V8 Sparkplug 1:1 基线 + K154 多 tier JIT 原理 + K155 wasm3 M3 + K156 PyPy 方法→追踪两族复证。
- **MUV 3.7-c 裁定三段**（w3.7-jit-window.md §4.3 单源）：①**W-VM-SUPERINSTR 升格实施窗（开启）**——tier-0.5 静态单相融合（K150 静态相 + K151 定量背书）+ F1 正交直发算术刀（K150 BINARY_OP 特化同构——call 路径整体坍缩）；实施体 r133+（MUV 边界切轮禁止降级）；B2 目标带 ≤ 0.7×82.0ms（K151 保守 1.4× 起判）。②**W-JIT-METHOD-T1 登记窗**——三触发器（融合后复画像：B2 > 1.8× C-O0 带 / 分派份额 > 40% / T-a 链路 > 25×）；形态 = Sparkplug 1:1 非优化基线；元追踪族否决（K156）。③**cranelift 基座内否决**——§18 零外部依赖纪律 + K113 代码质量低于 LLVM + C 后端已覆盖链外原生位（B9c 3.3× 工作中）；链外实验位经 W-3.8 承载。**W-PKG-SELFHOST 前置精确化**（「W-VM-SUPERINSTR 融合刀交付后」——方法 JIT 非必要前置）。
- **守卫族 jit_window_tests 8 件**（tests/v1/stage1/plan/ + runner 注册；正 2/负 6 = 1:3——r119 gc_window 形制）：census 精确性锚（12 指令全链推导逐位钉扎 + ordinal 往返）+ 四大候选对语义钉扎（MUV 3.7-a 集成验证用例——未来融合的回归基线）+ F1 fail-closed 触发线 + 跳转目标尾非融合分类器 + census 失败即止精确性 + 三错误族 seam 惰性（TypeMismatch/DivByZero/UnboundGlobal——observed/plain 逐位一致）+ D-CLASS-1 三元组观察下逐位（churn@1024 → gc 1/swept 1023）+ 紧预算 fail-closed 边界一致。
- **文档族**：w3.7-jit-window.md v1.0（新建——窗口记录单源）+ stage-3-plan v2.8 + roadmap v2.62 + tech-debt-register（r132 检视 + W-VM-SUPERINSTR 升格 + W-JIT-METHOD-T1 新增 + cranelift 否决 + W-PKG-SELFHOST 精确化；登记窗十件→十一件）+ stage0 §9.118（v9.86）+ 本文件 + Cargo 金链锁步 v0.93.0 + ds08 r132 注记。
- **GATE 1 六命令全绿**（OBS 口径）：build 0e0w ✓ / check 0/0 ✓ / fmt 零 diff ✓ / clippy -D warnings 零 ✓ / test --release **1538:0:4**（基线 1530 + jit_window_tests 8 案）/ audit **300/300** live + 104 retired · 39 节维持复验（评估窗零增节——r115/r119 先例）/ doc 零新增警告（唯一 = cargo#6313 既有先例）。

## 诚实边界

- B2 残留 +2.4%（seam 终态 vs 控制括号双跑 80.06ms）定位为循环体代码布局位移（B6a 归零证明无每指令成本与结构体扰动）——K129 BEAM 教训接受不微调；B2 新带内参考 ~82.0ms（后续 B 轴对照读新值），融合实施窗将重写循环体（过渡态参考）。
- T-a 链路影响：融合 1.5-2× → 自举链 ~450× → ~225-300×；T-a <10× 目标不能仅靠 VM 提速达成（方法 JIT 再 2.5-3× → ~75-120×）——T-a 窗开启前需组合面（VM 提速 × 自举链工程可用性 × 生产链对照口径）——诚实预期管理登记，非本窗 scope。
- 实施窗开启 ≠ 实施交付：融合刀（编译器 pass + VM 臂 + .ktf 孪生同步 + 快照/黄金再生成）为 r133+ 完整轮次工程量——本窗为评估窗（测量 + 设计 + 裁定），零融合落地。
- 8 原语不变性第九十五轮验证：零新原语/零新内建/零语法增改/零冻结面触碰（seam = 测量基础设施非机制；ordinal = 诊断键非 wire format）；S-expr 转化记录义务：零新转化面（评估域轮）。

---

# kerf v0.92.0 — W-HM-TWIN 127-e 交付轮：窗口闭合——段三升格 ELEVATED + BS-A 前端全段收敛（r131）

第一百三十一轮（r131 · Task 131-a）· SOP v15.3 §21.12-28 自举阶梯最高优先 · W-HM-TWIN 实施体第五刀交付（127-e MUV 闭合 = 窗内末刀；前置 r130 = 127-d 测试面 + audit AN 族；本会话自 r130 闭合态续作——恢复轮前置件 = GitHub 单次访问 auth-blocked 如实登记[第十六次恢复轮] + 本地权威裁定（1165ade · 工作树净 = r130 闭合态字节级就位））。

## 本轮交付

- **段三升格重裁 = ELEVATED**（§21.12-28② 三判据全过——w-hm-twin-window.md v1.4 §5 单源）：①4,924 行纯 kerf 完整承载（infer.ktf 3,690 + typecheck.ktf 1,234 vs Rust 本体 kerf-typecheck 7 文件 5,352 行——sweep 双轴 5/5+6/6 逐位实证）②自举链经该段自我编译（SteadyTypecheckChain/SteadyCheckChain 运转 + RS-4 双引擎 + 逐源路由 + 跨路由等价[稳态 ≡ 逐源 ≡ oracle] + 语料 HM 轴 91 行精确钉扎 + fail-closed 六探针 + 篡改族）③parity 门全绿（audit 300/300 · 39 节 AN 族 10/10 + 六命令 1530:0:4）。
- **BS-A 前端全段收敛——「编译管道全段自举」口径闭合**：read ELEVATED（r121）+ expand ELEVATED（r123）+ HM 判定面 ELEVATED（r131）+ compile 孪生在位（r124——非独立段位）+ 构建编排宪法性排除（r124）——W-BOOT-FRONTEND 账面全清偿；余量 = T-a 生产位切换（性能门控非完备性门控——双链解耦裁定原文执行）。
- **文档族统一刷新**（承载 r130 域分界裁定）：w-hm-twin-window.md v1.4（§5 升格裁决 + 窗口 Closed）+ stage-3-plan v2.7 + roadmap v2.61 + tech-debt-register（W-HM-TWIN 清偿归档 + W-BOOT-FRONTEND 账面全清偿 + r131 检视合并段）+ stage0.md §9.117（v9.85）+ 本文件 + Cargo 金链锁步 v0.92.0 + ds08 r131 注记。
- **GATE 1 六命令全绿**（OBS 口径 --jobs 2 / --test-threads 1 / RUST_MIN_STACK=268435456[256MB 数值形]）：build 0e0w ✓ / check 0/0 ✓ / fmt 零 diff ✓ / clippy -D warnings 零 ✓ / test --release **1530:0:4** 维持（版本钉扎 = 唯一行为增量——ds08 0.92.0）/ audit **300/300** live + 104 retired · 39 节维持 / doc 零新增警告（唯一 = cargo#6313 既有先例）。

## 诚实边界

- 升格 ≠ 生产位切换——生产桥 typecheck 步仍为 Rust 位（kerf-typecheck 生产 crate；孪生为验证面 + 稳态链注入面）；T-a 生产位切换条件维持（W-3.7 JIT/超级指令窗落地后 vm/rust 实测 < 10× → 重测 → 开窗——下一入口即 W-3.7）。
- 本轮 = 纯文档域轮（.ktf 孪生与 Rust 生产面零触碰）；实际孪生体量 4,924 行超出 TWIN-5 预估上限 ~2,500-3,500——如实登记。
- 8 原语不变性第九十四轮验证：零新原语/零新内建/零语法增改/零冻结面触碰；S-expr 转化记录义务：零新转化面（纯文档域——127-a/b 转化面已由 r127/r128 落档）。

---

# kerf v0.91.0 — W-HM-TWIN 127-d 交付轮：测试面 + audit AN 族 + 语料 HM 轴重分类钉扎（r130）

第一百三十轮（r130 · Task-130-a）· SOP v15.3 §21.12-28 自举阶梯最高优先 · W-HM-TWIN 实施体第四刀交付（127-d MUV 闭合；前置 r129 = 127-c 段三稳态链 parity 三面；本会话自 r129 闭合态续作——恢复轮前置件 = GitHub 单次访问 auth-blocked 如实登记 + 本地权威裁定（c92b426 · 1526:0:4 + audit 290/290 基线复验））。

## 本轮交付

- **runner AN 族（`hm_twin_face_tests.rs`，四案）**（w-hm-twin-window.md §4 127-d）：①配对正负探针双面钉扎——同一探针集（四正案：accept-anchor/let-polymorphism/handle-rows/module-flat-table + 五负案：t1-bool-demand/t2-not-callable/t3-non-numeric/t5-cond-mismatch/t7-occurs）经 `paired_drive` 同时驱动两判定面（infer 链 + check 链 + 双 oracle）——127-a/b 轮探针为面特化，本轮钉配对；正案双轴清洁 + 空流零定义模块双轴精确文本（"(ok (types) (diags))" / "(ok (table (defines) (assigned)) (diags))"）；负案检出力臂（E00 真报）+ ok 载体（发现收集、模块仍装载）。②语料 HM 轴重分类**精确钉扎**：91 行逐行分类恰一次——reader 拒 8（逐名）/ 展开拒 19（逐名）/ infer 诊断 6（逐名——正即 127-a sweep 文档注记的 E0009 族六行）/ infer clean 58 / check 诊断 10（逐名）/ check clean 54 / 双轴 fed 64——先例 sweep 仅携下界（≥55/≥8/≥5），本轮钉扎使任何语料变更挪动任一轴分类 = 可见破而非静默随行。③预算行 E0011 逐源路由面：600 深定义经 `infer_twin_per_source_dual`（重编译逐案 + 双引擎）≡ oracle——127-a 预算行仅稳态路由，本轮补逐源面 + 排除语义断言（深定义整体弃、浅定义存活）。
- **audit AN 族 10 案**（290→**300 live**，38→**39 节**，104 retired 维持）：AN01 量化 schema 面（`(tdef fib (schema (1) (fn (t1) dyn))` 断言）/ AN02 E0009 双面 / AN03 E0010 occurs / AN04 检查孪生表形（嵌套 module 平铺表）/ AN05 检查孪生 R2 元数（E0002）/ AN06 预算行程序化路径（E0011 + 深弃浅存）/ AN07 跨路由等价（稳态 ≡ 逐源双引擎 ≡ oracle）/ AN08 组合分析面（编译孪生 dump + 推断孪生 types 段 ≡ `oracle_analysis_dump_typed`）/ AN09 空流边界双轴 / AN10 fail-closed 篡改族（非 ok 判定标签 + 未知 tdef 标签——具名错误非静默丢弃）。
- **TEST-3 守卫三处同步**：`documented_audit_composition()` +AN10 行 + 总数 290→300 + headline "AUDIT PASS 300/300"（守卫/清单/标题三位一体机检锚）。
- **eval-face 清单同步（W-3.6 fail-closed 触发实录）**：新测试件消费 `eval_text`（经 `infer_twin_per_source_dual`）→ 守卫红 → 当轮入册 C 桶（C13/总数 40）+ w3.6 窗口档 §1 钉扎行 r130 修档 + 守卫头注不变量 3 同步（守卫/窗口双单源；W36-3 注释内既有「= 35」陈旧算术注记顺带勘正为 40）。
- **GATE 1 六命令全绿**（OBS 口径 --jobs 2 / --test-threads 1 / RUST_MIN_STACK=268435456[256MB 数值形]）：build 0e0w ✓ / check 0/0 ✓ / fmt 零 diff ✓ / clippy -D warnings 零 ✓ / test --release **1530:0:4**（基线 1526 + 四新案逐位）/ audit **300/300** live + 104 retired / doc 零新增警告（唯一 = cargo#6313 既有先例）。

## 诚实边界

- 段三升格维持 **NOT ELEVATED**——127-e 未交付（升格重裁 + 文档族 + 投票 5.5/5.5 + §19 双包为窗内末刀）；「不完整的自举不是自举」原文执行。
- 语料重分类钉扎经 **oracle** 而非孪生本体：孪生 ≡ oracle 等价由 127-a/b sweep 承载（逐位），经 oracle 钉轴 = 经孪生钉轴（传递性如实声明，非重复跑孪生面）。
- 配对探针族规模 = 源路径可达面（四正 + 五负 + 空流）；R1 直构域（宏合成/程序化 API 面）归 127-b 直构探针既覆盖，不重复。
- 8 原语不变性第九十三轮验证：零新原语/零新内建/零语法增改/零冻结面触碰（本轮全部在测试域 + audit 域 + 守卫/文档域，.ktf 孪生与 Rust 生产面零触碰）。
- S-expr 完全转化记录义务：本轮零新 S-expr→目标语言转化面（纯测试/审计/守卫域）——条件不触发如实登记。

# kerf v0.90.0 — W-HM-TWIN 127-c 交付轮：段三稳态链 parity 三面 + 跨路由等价（r129）

第一百二十九轮（r129 · Task-129-a/b）· SOP v15.3 §21.12-28 自举阶梯最高优先 · W-HM-TWIN 实施体第三刀交付（127-c MUV 闭合；前置 r128 = 127-b typecheck.ktf 检查面收敛；本会话自 r128 闭合态续作——恢复轮前置件 = GitHub 单次访问 auth-blocked 如实登记 + 本地权威裁定 + 基线复验）。

## 本轮交付

- **稳态链 RS-4 双引擎面**（w-hm-twin-window.md §3 TWIN-3/§4 127-c）：`SteadyTypecheckChain::infer_dual` + `SteadyCheckChain::check_dual`——同一固定孪生程序（编译一次）、同一注入载荷、VM 与求值器双引擎各解码判决文本（段一 `read_dual` 先例的段三落位）；链体增存解析项（求值器直接 eval items，永不再编译）。
- **逐源文本路由（RS-1 测试通道形制）**：`infer_twin_per_source_dual` + `check_twin_per_source_dual`——item 记录流作为程序文本 `items` 前缀 + 固定孪生文本 = 一个程序，经生产桥逐源编译、双引擎驱动（段二 `per_source_route` 先例形制）；跨路由等价 = 稳态注入路由 ≡ 逐源文本路由 ≡ oracle，同一解码器，探针族实证（投递面变，判决不变）。
- **parity 机器三面（TWIN-4，r124 externs 段先例形制）**：① oracle 面 `oracle_types_segment`（types 键族紧凑文法——tdef 表单源渲染）+ `oracle_analysis_dump_typed`（编译产物 dump 尾增类型判定段 = 全管线分析面）；② dump 面 `dump_ktf_section` 增 `types` 臂（HM 孪生产品的 types 段经共享 dump 渲染器入族——与 funcs/globals/consts/externs 同一渲染器）；③ rebuild 面 `rebuild_typed_verdict`（gate-B 结构面：孪生 ok 产品重建为真 TypedExpr 树/TypeSchema/EffectRow/TypeDiagnostic 记录——类型代数逆向重建 + 诊断码逆向注册表 E0001-E0012 + 模板字典单源渲染消息；逐字段对 oracle 结构比对；fail-closed 六探针族证伪面）。
- **组合分析面**：编译孪生 dump + 推断孪生 types 段（共享渲染器双渲染）≡ `oracle_analysis_dump_typed`（compile_program + infer_module 全管线一文本）——junction-3 家族的组合比较点先立（组合链报告结构零触碰——127-d/e 域）。
- **GATE 1 六命令全绿**：build ✓ / check ✓ / fmt 零 diff ✓ / clippy -D warnings 零 ✓（3 处冗余解引用当轮清偿）/ test --release **1526:0**（基线 1520 + hm_twin_chain 6 案：跨路由等价×2 + RS-4 稳态 + 检查链确定性/喂给 + 组合分析 + 结构重建 + fail-closed 篡改族）/ audit **290/290** live 零漂移 / doc 零新增警告（唯一 = cargo#6313 既有先例）。
- **eval-face 清单同步**：W-3.6 守卫三新消费位入册（steady_typecheck_chain + infer_parity + hm_twin_chain_tests——C 桶 9→12、总数 36→39）+ w3.6 窗口档 §4 钉扎行 r129 修档（守卫/窗口双单源同步——typecheck_parity 无符号命中不入册，幻影条目纪律）。

## 诚实边界

- 段三升格维持 **NOT ELEVATED**——127-d/e 未交付（runner+audit AN 族扩容 290→300 / 升格重裁 + 文档族）；「不完整的自举不是自举」原文执行。
- 结构重建的字段边界如实登记：define 的名跨度不随产品文法（r127 面——树跨度随 tnode、名跨度不随）；推断诊断记录无主体集（检查产品的 cdiag 有——推断轴以 code/severity/span/message 四面比对）。
- 逐源路由为逐源重编译面（稳态链存在的意义即摊销它）——跨路由等价按段一/二先例以探针族实证，语料级 sweep 由稳态路由承担（127-a/b 已交付）。
- 8 原语不变性第九十一轮验证：零新原语/零新内建/零语法增改/零冻结面触碰（本轮全部在 Rust harness 域 + 文档域，.ktf 孪生零触碰）。
- S-expr 完全转化记录义务：本轮零新 S-expr→目标语言转化面（Rust 侧 parity 机器扩展——条件不触发如实登记）。

# kerf v0.89.0 — W-HM-TWIN 127-b 交付轮：typecheck.ktf 孪生 parity 收敛（r128）

第一百二十八轮（r128 · Task-127-b）· SOP v15.3 §21.12-28 自举阶梯最高优先 · W-HM-TWIN 实施体第二刀交付（127-b MUV 闭合；前置 r127 = 127-a infer.ktf 推断面收敛；本会话自 r127 闭合态续作——恢复轮前置件 = 工具链 PATH 复位 + 六命令零漂移复验 1511:0 + audit 290/290 逐位）。

## 本轮交付

- **typecheck.ktf 孪生 parity 收敛**（w-hm-twin-window.md §4 MUV 127-b）：`selfhost/v1/typecheck.ktf`（第七件 .ktf 孪生，1,234 行）与 Rust oracle `check_module` 在检查轴**位级一致**——R1-R8 + R-LA7 全规则族（位置感知可见性 so-far/全量、letrec 预绑定、赋值过度近似守卫、词法遮蔽、IIFE/define/内建/extern 四元数面、字面量条件、字面量被调者具名/匿名两形、路由处理器元数/字面量两形、顶层未路由效应、R8 警告双臂 rebinds-builtin/implicit-global、捕获赋值边界 + let 遮蔽回环）+ 多错收集架构（ruling 21——走查永不在首个发现处停）+ 诊断键族（code/severity/span/message/subjects 五面 + r109 F2 主体集——模板载荷经 oracle 自有格式串渲染）。
- **双表镜像守卫直接化**：检查面 parity 文本内嵌 pass-1 表面（每一 define 平铺走查序 + 形状 `(fn n)`/`(lit kind)`/`other` + assigned 首见序）——oracle 侧新增公共面 `kerf_typecheck::table_axes`（从 `collect_table` 渲染——单源纪律，非重走查）+ `Table.assigned_order` 首见序列（增量字段）；全语料 sweep 的每一行都是一次 INF-9 镜像对账。
- **sweep 家族 6/6 全绿**：全语料 sweep（fed ≥55 + 读者拒 ≥8 + 展开拒 ≥5 + assigned 面检出力 ≥2）+ 规则族探针（23 案源路径可达面）+ R1 直构探针（unbound/forward-ref 双负向 + letrec-self/fn-forward 双过 + implicit-global 警告形——源路径展开器先行拒止的面归直构域如实分界）+ 600 深程序化行（值面注入——孪生逐元素递归余量 + 检查面无预算如实镜像）+ 确定性/注入通道行 + 空流行。
- **走查状态落全局（W-machine 纪律）**：单态递归约束（预绑定参数槽跨全部内部调用点严格 unify）使「类型随递归变形的传参」成为 occurs 检查失败——locals/handlers/marks/let 栈四态改经赋值全局承载（`set()` 标记 assigned → 读取即 Dyn），显式 push/pop 对镜像 oracle 的 extend/truncate + push/pop 变更结构；互递归走查族按 .ktf 依赖序纪律并为单一带模式标签分派器（`tc_walk` expr/args/clauses/letbinds 四态）。
- **GATE 1 六命令全绿**：build ✓ / check ✓ / fmt 零 diff ✓ / clippy -D warnings 零 ✓ / test --release **1520:0**（基线 1511 + sweep 6 案 + table_axes crate 3 案逐位对账）/ audit **290/290** live 零漂移 / doc 唯一警告 = cargo#6313 先例；R8 编码面清零（变更代码文件 CJK 扫描 NONE）。
- **探针拆除**：tc_probe 一次性调试示例（18 规则族探针 + 600 深行二分）裁定后移除（永不发布面；Cargo 注册同步清除——r127 fwd_probe 先例形制）。
- **selfhost/README 七件化**：r127 遗漏的 README 表更新一并承接（五件 → 七件 + typecheck/infer 托管惯例 + 消费面）。

## 诚实边界

- 段三升格维持 **NOT ELEVATED**——127-c/d/e 未交付（稳态链 parity 三面 + 跨路由等价 / runner+audit AN 族扩容 290→300 / 升格重裁 + 文档族）；「不完整的自举不是自举」原文执行。
- externals 面两值化如实登记：载荷检查面的 extern 表全量带元数（内建 18 表 + extern 记录参数表长），oracle 三值面（Some(None) 未知元数）仅存在于程序侧注入名路径——载荷域不可达，孪生取 arity-or-nil 两值归约。
- 8 原语不变性第九十一轮验证：零新原语/零新内建/零语法增改/零冻结面触碰（`effect` 标识符改名 = 目标皮肤保留字避让，非语言面变更）。

# kerf v0.88.0 — W-HM-TWIN 127-a 交付轮：infer.ktf 孪生 parity 收敛（r127）

第一百二十七轮（r127 · Task-127-a）· SOP v15.3 §21.12-28 自举阶梯最高优先 · W-HM-TWIN 实施体首刀交付（127-a MUV 闭合；前置 r126 = 实施窗开启规划轮；本会话继承中断态续作——未提交现场 sweep 2/5 收敛至 5/5）。

## 本轮交付

- **infer.ktf 孪生 parity 收敛**（w-hm-twin-window.md §4 MUV 127-a）：`selfhost/v1/infer.ktf`（3,641 行）与 Rust oracle `infer_module` 在推断轴**位级一致**——tdef 表（平铺 define 序 + budget 幸存者）+ 泛化 schema（含量化元变量索引——引擎编号属 parity 面）+ 解析注解树 + 效应行 + 诊断通道（报告序 + 模板载荷经 oracle 自有格式串渲染）。
- **sweep 家族 5/5 全绿**：全语料 sweep（每一 oracle 可读可展行——位级判定文本）+ HM 负向族（bool-demand t1 含 E0009 确定报错位 + 非可调 t2 + 非数值 t3 + cond t5 + occurs t7 含 E0010 + let-polymorphism 双用点解耦 + handle-rows + 空流）+ budget 行（600 深程序化注入——E0011 警告 + 幸存者子集）+ 确定性/注入通道行 + 空流行。
- **十三缺陷清偿**（全部根因修复 + §20.3 同类族审查）：孪生侧 9 处——Tarjan SCC 序反转（依赖后置处理——编号偏移 + 跨 SCC schema 缺位总根因）/ ti_fresh_repl do 丢弃递归值（repl=nil 崩溃）/ ti_var_walk 累加器丢失（调用图边缺失——被模块序巧合掩盖）/ ti_unify 包装与消费者约定错配 / apply 与 car 分派 first() 无 is_pair 守卫 / extern 条目取错层 / env 毒化重建保留旧标志 / lpair 双重转换（字面量→nil）/ varocc fn 臂遍历序（量纲序倒置）；解码器 1 处（模板载荷扁平约定 + t4/t6 字典补齐 + t7 裸索引渲染）；oracle 渲染器 1 处（string litval 缺右括号）；**oracle 本体 1 处 P0 级潜在语义缺陷**——`Ctx::resolve` Arrow 重建臂多余 `params.reverse()`（弹出序已天然正确——经链路重建的每个多参箭头参数静默交叉；单参不可见 + typed-program 面无 golden 钉扎故 1506 测试从未曝光；parity 面首次逼出）。
- **GATE 1 六命令全绿**：build ✓ / check ✓ / fmt 零 diff ✓ / clippy -D warnings 零 ✓ / test --release **1511:0**（基线 1506 + 新增 sweep 5 案逐位对账）/ audit **290/290** live 零漂移。
- **探针拆除**：fwd_probe 一次性调试示例（二分阶梯 + 中间值倾印变体）裁定后移除（永不发布面；Cargo 注册同步清除）；继承态超宽行（infer.ktf 1823 行 101 列）折行——继承态从未跑过格式守卫。
- **会话恢复**（用户常设指令①）：本地 git 记录核查 = 完整且领先（r126 全链提交 + r127 进行中现场）；GitHub 单次访问 = 认证阻断（无凭据——沿 r126 实录）；裁定 = 本地为权威禁旧替新；从中断现场续作。

## 诚实边界

- 段三升格维持 **NOT ELEVATED**——127-b/c/d/e 未交付（typecheck.ktf 检查面 / 稳态链 parity 三面与跨路由等价 / audit AN 族扩容 / 升格重裁 + 文档族）；「不完整的自举不是自举」原文执行。
- oracle P0 修复（resolve 参数交叉）改变 typed-program 面行为——多参箭头经链路重建的参数序由交叉纠正为源序；全量套件零回归实证（无 golden 钉扎旧交叉序——r127 注释块如实入册）。
- 8 原语不变性第九十轮验证：零新原语/零新内建/零语法增改/零冻结面触碰。

# kerf v0.87.0 — W-HM-TWIN 实施窗开启轮：自举演进规划优先落位（r126）

第一百二十六轮（r126 · Task 126）· SOP v15.3 §21.12-28 自举阶梯最高优先 · W-HM-TWIN 实施窗开启（前置 r125 = 第十四次回退恢复轮：GitHub 49df52e 单档恢复 v0.86.0 保护性上传态 + 六命令零漂移 1506:0:4 + audit 290/290 逐位复现——恢复形制沿 r113/r118 先例）。

## 本轮交付

- **自举阶梯全景**（粗粒度——w-hm-twin-window.md §1 单源）：六行阶梯表——段一 reader ELEVATED（r121）/ 段二 expander ELEVATED（r123）/ 段三 NOT ELEVATED → 本窗（载体 typecheck.ktf + infer.ktf）/ 编译孪生在位（compiler.ktf r124 补齐）/ T-a 生产位切换窗（W-3.7 JIT 后 <10× 门控）/ 宪制排除项（VM Rust 基座 + 构建引导层）；演进排序 = W-HM-TWIN → 段三升格重裁 → W-3.7 JIT → T-a 切换窗；自举面超集对账（§9.25.2 D1 清单超集——段三交付后 BS-A 前端全段收敛）。
- **知识层**（r126-search 六检索件存档 tool-results/r126-search/；q4/q5 强锚 + q1/q6 中强 + q2/q3 弱查噪音第十七轮如实披露——垃圾域主源直读补位）：**K146** Mark P. Jones《Typing Haskell in Haskell》（web.cecs.pdx.edu——用被检查语言本身实现 HM 类型检查器的正典先例）+ **K147** rustc_hir_typeck check.rs 主源（K125 家族复证——typeck 与编译器本体同语言）+ **K148** cs3110 §10.6 约束两相表述（K124 家族复证）+ **K149** union-find 形态谱系（persistent 结构 vs 迭代 W + undo-log 分界——kerf 维持既有形态，孪生与 Rust 本体同构 = parity 最短路径）——stage0.md §9.116 单源。
- **形态裁定 TWIN-1..TWIN-5**：载体 selfhost/v1/infer.ktf（推断引擎 ~1,500-2,200 行——迭代 W + undo-log + SCC 分治 + let-polymorphism + Externals 边界）+ typecheck.ktf（检查面 ~1,000-1,300 行——双表镜像 + TypeDiagnostic 产物流）；通道复用 INJ-1（item 记录载荷经 inject_global——零新原语/零新内建）；稳态链 SteadyTypecheckChain（编译一次 + 每推断注入——沿段一/段二先例）；parity 机器三面（oracle_analysis_dump 类型段 + dump/rebuild 双臂——r124 externs 段先例形制）；工作量口径维持 r124（5,352 行 Rust → ~2,500-3,500 行 .ktf）。
- **实施排期 127-a..e**（细粒度——MUV 边界切轮）：127-a infer.ktf 主体（~1,500-2,200 行）→ 127-b typecheck.ktf 检查面（~1,000-1,300 行）→ 127-c 稳态链 + parity 三面（~300-500 行 Rust 侧）→ 127-d 测试面（runner AN 族 + audit AN 10 案 290→300 live 39 节）→ 127-e 升格重裁 + 文档族；每 MUV 含 ≥1 集成验证用例；1-2 完整轮次工程量按 MUV 边界切轮，禁止降级交付。
- **纯文档域轮**（沿 r107/r120 先例）：零生产代码变更——唯一代码面 = ds08 版本钉扎（snapshot_seed_tests r126 注记块 + assert 0.87.0）+ Cargo.toml/lock 金链锁步 v0.87.0。

## 诚实边界

- 段三升格 = **NOT ELEVATED 维持**——W-HM-TWIN 未交付（「不完整的自举不是自举」原文执行，沿 r122/r124 先例）；本轮交付 = 规划层（知识 + 形态 + 排期），实施体 r127+ 按排期推进。
- 升格 ≠ 生产位切换：生产桥 read/expand/check 步仍 Rust 位（T-a 生产位切换条件维持——W-3.7 JIT 后 <10×）。
- r125 恢复轮如实入册：r124 git 提交链与 Pack A 二进制随第十四次回退丢失（实值以 worklog 124 条目为权威）；恢复源（-orchestration a5a2d49a）经 GitHub 保全复位 my-project download/；web 端 r118→r126 跨度同步由 my-project 侧承接（沿 r113 七轮跨度同步先例）。

# kerf v0.86.0 — Stage 3 段三 HM/构建编排裁定窗：三议题分面裁定 + junction-3 清偿（r124）

第一百二十四轮（r124 · Task 124）· SOP v15.3 §21.12-28 自举阶梯最高优先 · 段三 HM/构建编排裁定窗闭合（junction-3 记录盲当轮清偿 + 段三升格诚实裁定 = NOT ELEVATED）。

## 本轮交付

- **124-a 检索层**（知识搜索义务——rustc typeck/GHC 推断引擎自举形态；tool-results/r124-search/ 九件存档 q1-q7 + m1/m2）：**m1 强锚** rustc-dev-guide ty.html（typeck 与编译器本体同语言——K125 复证）+ **m2 强锚** rust bootstrap README（x.py Python 入口编排 + stage0 二进制下载——构建编排宿主入口层三十年不动）+ q2 强（GHC Stage 0 = bootstrap compiler + typecheck 用 Haskell）+ q3 强（OCaml HM——okmij 推断器与真实 OCaml 共享实现决策，K124 复证）+ q7 强（429 限流一次重试——MLton SelfCompiling + SML# bootstrap）+ q6 中（Chez boot files 宿主编译制品，K145 复证）；q1/q4 弱查披露第十六轮（垃圾域——主源直读补位）。
- **议题一裁定：构建编排 = 宪法性排除**（r90「维持 Rust 构建引导不开面」升格为宪制条款——同 VM 永久基座形制）：依据 m2 x.py 先例 + K121/K122 冻结种子工件 + SOP v15.3 §21.12-③ 宪制排除项「构建引导层」的段三显式落位；两案权衡落档（维护成本 = 零收益面 <2% 份额 / 链深度 = 编排是链构造器非链成员 / 口径诚实性 = §1.2 口径同步修订——构建引导层与 VM 基座同列宪制位）。
- **议题二裁定：HM 判定面 = 补孪生确认 + W-HM-TWIN 实施窗登记**：四大自举语言先例全一致（类型检查器与编译器本体同语言——OCaml/GHC/rustc/MLton 无一排除先例）+ BS-A 端态（§9.25.2 自举面超集）+ 可表达性确认（HM 推断 = 纯树/表/符号操作——eq? Str 内容比较 + pair 代数 + 递归，无字符依赖；kerf-typecheck 5,352 行 Rust → ~2,500-3,500 行 .ktf）。
- **议题三实施：junction-3 记录盲当轮清偿**（§20 同族审查——emit 缺陷族第二成员 + 消费缺失）：① emit 层真缺陷修复——name 字段双层引号（`""add""` 被 target 词法拆三 token，裸符号 datum 无 Stage 0 value model，组装层 parse 失败；W-3.2 起零消费方掩盖——r124 探针实测定位）改单层（对齐 define 臂形制）；② compiler.ktf 补消费臂 `cp_extern_walk`（收集 entry 进产物表声明序 + 名字唯一性检查——eq? Str 内容比较 = 唯一可表达 C 域面）+ cp_externs/cp_extern_names 状态 + cp_ewalk extern 臂 + cp_finish externs 段（funcs/globals/consts/externs 段序）+ cp_run 重置；③ parity 键三面扩展——oracle_analysis_dump 尾增 `) (externs (name param... ret))`（globals 族紧凑文法）+ dump_ktf_section「externs」臂 + rebuild_bytecode「externs」臂（rebuild_extern_entry + kind-tag 逆表）+ rebuild_compile_error「extern-name-duplicate」臂（孪生错误键对齐 oracle parity 键——AM06 实测逐位 `extern entry `1` repeats the name `add` @ <no-span>`）。
- **可表达性分层**（本轮核心裁定证据）：三检查中名字唯一性可表达（eq? 内容比较）；派生碰撞（`-`→`_`）与字符合法性（`[A-Za-z_][A-Za-z0-9_]*`）不可表达（18 内建零字符操作；8 原语不变性禁止扩张——r123 路径 a 否决先例）——结构性披露维持。
- **台账共变**：组合链 extern 台账 3→1——pos-037/neg-058 收敛（孪生产物携 extern 表，parity 端到端——Compile 行 56→58）；neg-062 维持披露（孪生编译通过 + rebuild 面 verify 判官拒 hand-built 表：「`set!` derives a C symbol that is not a valid C identifier」——r123 两判官合同的三层防御分层）；组合链断言改语义分流（oracle_compile_rejects 判据）。
- **段三升格重裁 = NOT ELEVATED**（诚实裁定）：议题一已定（宪法性排除非升格对象）；议题二裁定 = 补孪生但实施未交付（W-HM-TWIN 在列——「不完整的自举不是自举」原文执行，沿 r122 先例）；junction-3 清偿 = 议程既有登记面完成（不构成段三升格判据）。
- **测试面**：runner AM 族 5 案（extern_consumption_tests.rs——AM01-05：收敛钉扎×2 + 披露钉扎 + 名字警察 + emit 钉扎）+ audit AM 族 10 案（280→290 live，38 节——AM01-10）+ eval_inventory ledger 登记（E 桶 16→17、总 35→36）+ test_infra_guard 组成 290 共变 + 实施自纠两件如实登记（cp_extern_walk 初版置于 cp_ewalk 后 unbound——kerf 严格先定义后引用惯例实测确认后移位 helpers 区；cp_nth 0-based 初版 i+1 越界 first(nil) 崩——勘正）+ 守卫两件如实披露（eval 面清单拦截 + audit 头条同步）；六命令 **1506:0:4** + audit **290/290**。

## 诚实边界

- 段三升格 ≠ W-HM-TWIN 交付：HM 判定面孪生（typecheck.ktf + infer.ktf，~2,500-3,500 行 .ktf）未实施——W-HM-TWIN 实施窗登记承载（1-2 完整轮次工程量）；段三 ELEVATED 待其完整交付后重裁。
- 升格 ≠ 生产位切换：生产桥 read/expand 步仍 Rust 位（T-a 生产位切换条件维持——W-3.7 JIT 后 <10×）。
- junction-3 的派生字符 police（neg-062 行）= 冻结子集表达力边界披露（孪生通过 + verify 判官拒绝——rebuild 面 hand-built 裁判；oracle compile floor 同键拒绝源派产品）——三层防御的分层披露维持，非静默跳过。

# kerf v0.85.0 — Stage 3 W-CSYM-EXPR 能力裁定窗：C 域重归属 + 段二 ELEVATED（r123）

第一百二十三轮（r123 · Task 123）· SOP v15.3 §21.12-28 自举阶梯最高优先 · W-CSYM-EXPR 能力裁定窗全链闭合（段二升格阻塞项解除轮）。

## 本轮交付

- **三选一裁定（§21.7 + §12 + K143-K145）**：W-CSYM-EXPR 能力裁定 = **路径 b C 域谓词架构重归属**——extern C 域地板（规范名去重 + 派生合法性 `[A-Za-z_][A-Za-z0-9_]*` + dash 替换碰撞）重归属为产品级约束。知识锚：K143（LLVM Lang Ref——IR verifier 不验证目标域寄存器名，codegen 才致命）/ K144（Rustonomicon FFI——编译器不深查外部声明正确性）/ K145（Chez 9.5.8 boot files = 宿主编译制品——K121 佐证）。路径 a（冻结子集能力扩展）否决为宪法级提案选项（登记不实施——为外语域窄需求扩张冻结面违极小内核冻结精神）；路径 c（载荷结构化）维持 r122 否决。
- **重归属实施**：展开器 `reject_within_block_collisions` 收窄为块内规范名去重（语言级身份面——孪生自 r122 可表达）；`ExpandError::ExternSymbolInvalid` 变体退役；kerf-compiler 新增 `extern_table_floor` 单源警察函数（bytecode.rs 派生位旁）——**双裁判一位函数**：compile `finish()` 全表警察（源导产品——「compile output always passes verify」合同无条件成立）+ verify Pass 0e（hand-built 产品裁判）；verify 增派生碰撞检查 = 迟位裁判严格更强（新覆盖）。诊断位后移的名载荷补偿：`CompileError` extern 族三分裂（ExternNameDuplicate / ExternSymbolInvalid / ExternSymbolCollision——index + name [+ other] 载荷）+ `subject_symbols` 皮肤感知扩展。
- **管线契约扩展**：语料指令文法新增 `;; expect: compile-error` 期望种类（parity.rs `Expectation::CompileError`——检查器过 + 管线以 kerf-compile 标签拒绝；subset-spec.md 文法行同步）；neg-062 重分类（expand-error → compile-error——全管线重分类单轮成立零回归）。
- **段二升格重裁 = ELEVATED**：判据①①②③全过（孪生 = 展开段全量语义——两 C 符号面已非展开器语义；稳态链 + sweep 91/91 零披露逐位；parity 门全绿）——「不完整的自举不是自举」经裁定实施完整闭环（r122 拒绝带病升格 + r123 裁定实施后升格）。段三（HM/构建编排裁定）解锁——自举阶梯下一入口。
- **台账共变**：组合链 extern 台账 3 披露行 = 同根因（junction-3 编译孪生 extern 记录盲——neg-062 自 junction-2 不可表达边界迁移入族，双引擎展开层一致接受 + oracle compile 拒绝 vs 记录盲孪生编译通过）；稳态 sweep 披露行退役（c_symbol_disclosed 计数器拆除）。
- **测试面**：audit AL 族 10 案（270→280 live——重分类端到端 / 退役边界孪生 oracle 一致 / dash 碰撞全管线 / verify 三面 hand-built / 语言级身份面维持 / 名载荷 / 两皮肤合同 / compile-verify 合同 + 确定性 / 收窄钉扎）+ TEST-3 守卫共变 + compile 单元 +1 + verify 单元共变 + parity 文法单元；六命令 **1501:0:4** + audit **280/280**。

## 诚实边界

- 升格 ≠ 生产位切换：生产桥 expand 步仍 Rust 位（T-a 生产位切换条件维持——W-3.7 JIT 后 <10×）。
- junction-3 编译孪生 extern 记录盲三行（pos-037 / neg-058 / neg-062）= 编译段议程（段三承载——`.ktf` 编译孪生不消费 extern item 记录的 gate-B refresh 面），本轮如实登记未清偿。
- 路径 a（冻结子集能力扩展）为宪法级提案选项——需用户可见提案方可开窗，本轮未获授权未实施。

# kerf v0.84.0 — Stage 3 W-3.12 段二实施窗：稳态展开链 + 孪生刷新 + 目录统一（r122）

第一百二十二轮（r122 · Task 122）· SOP v15.3 §21.12-28 自举阶梯最高优先 · W-3.12 段二实施窗全链闭合。

## 本轮交付

- **自举文件目录统一**（用户常设指令①目录整理问题的实施回应）：`crates/kerf-driver/src/bootstrap/` 模块族——九文件迁移（bootstrap_chain / lexer_parity / reader_parity / expander_parity / compiler_parity / composed_target_chain / composed_full_chain / fixpoint / target_corpus）+ `src/target_skin.rs` 皮肤契约拆分（生产桥与诊断消费的生产契约留在根；自举面单处可审计）。验收 = 1491:0:3 逐位零行为变更；eval 消费面守卫按设计拦截路径迁移（清单共变，fail-closed 机制正向价值实录）。
- **段二稳态自举链**：`bootstrap/steady_expander_chain.rs` `SteadyExpanderChain`——macro.ktf + expander.ktf 编译一次 + 每展开 forms 记录流经同一 `inject_global` 注入通道（INJ-1 通解裁定的段二兑现）；per-expansion 实测 0.617ms / 10.036ms（steady/rust 139× / 88×——T-a 类生产位数字，非升格前置）；注入面原生承载 i64::MIN 记录（r103 文本面边界在值面不存在——能力增量如实披露）。
- **expander 孪生刷新**（W-3.2 预告的「W-3.12 邻接决策」实施）：extern 警察可表达五面——shape / ABI 词表 / 类型词表 / 名字碰撞（块内规范名 + 跨块 vs defines vs 18 全局）/ top-level-only——+ extern item 记录（("extern" s e entry...)）+ 宿主三臂（dump_ktf_item / rebuild_item / reconstruct_expand_error 四错误类）+ letrec bind-first 种子（模块帧携带 extern 契约名）+ 跨块碰撞后置遍。组合链 junction-2 的 extern 行从「全族漂移」进到「5/6 逐位 + 1 披露」。
- **两 C 符号派生面 = 冻结子集不可表达**（诚实边界）：`c_symbol()` 合法性（`[A-Za-z_][A-Za-z0-9_]*` 类集判定）与 dash 替换碰撞需字符级检查——18 内建零字符串/字符原语（穷举证实）——孪生不可表达，留在共享单谓词的 Rust 消费者（bytecode verify）；neg-062 为唯一受影响语料行（披露行）。**段二升格重裁 = NOT ELEVATED**（判据① 未过——「不完整的自举不是自举」原文执行）；阻塞项登记 W-CSYM-EXPR 能力裁定窗（三候选路径带论证）。
- **附带发现并修复**（§20 同类路径审查）：`items_stream_prefix` extern 臂裸 `int,int` 文本在目标皮肤逗号分裂——W-3.2 潜伏缺陷（junction-3 孪生缺口掩盖，零消费方）——修复为引号字符串形。

## 测试面

- 集成 9 件（`steady_expander_chain_tests.rs`：语料 sweep 91/91 分类 [文本 + items 双面] + i64::MIN 边界增量 + 双引擎 + 跨路由等价 + 自应用 fixpoint [CP6 selfhost-bare 先例] + 空流 + 未知名 fail-closed + 编译一次 + 确定性/喂给）
- audit **AK 族 10 案**（260→270 live）：全通道 e2e / fail-closed 三件 / 接受面 / 双引擎 / 错误轴 / r103 边界 / 喂给 / 确定性 + 记录文法字面面
- eval 消费面 C 桶 8→9（桶形钉扎共变）；组合链 extern 台账行共变（6→3：三展开拒绝行转入正常 Expand 行 19→22）
- **六命令 1500:0:4**（1491 + 9 新集成；第 4 ignored = w312b 测量面；--jobs 2 -- --test-threads 1 + RUST_MIN_STACK=256MB 环境口径延续）+ **audit 270/270**

## 文档与版本

- 窗口记录档 `docs/develop/v3/w3.12-frontend-window.md` **v3.0**（§1b 段二测量表 + §6b 升格裁定 + 目录统一登记）单源；stage-3-plan v2.1；roadmap v2.55；tech-debt（W-BOOT-FRONTEND 段二态更新 + W-CSYM-EXPR 新登记窗）；calibration T2.21；stage0.md §9.114（C 符号表达力边界 + 孪生刷新设计层记录）；金链三处锁步 0.84.0。

---

# kerf v0.83.0 — Stage 3 W-3.12 段一实施窗：注入通道生产化 + 稳态自举链 + 段一升格（r121）

> Stage 3 W-3.12 段一实施窗（第一百二十一轮）——SOP v15.3 §21.12-28 自举完备优先纪律的首个实施轮：注入通道生产化（差距 #1 清偿）+ 稳态自举链建立 + 段一 reader 升格重裁 = **ELEVATED**（自举链完备——双链解耦判据三条件逐条实证；生产位切换 = T-a 独立后续窗）。

## 变更

- **注入通道生产化**（w3.12-frontend-window.md §2a §18 审查记录单源——零新原语/零新内建/零冻结面变更，8 原语不变性第八十五轮验证）：① `kerf-vm` / `kerf-runtime` 双引擎 `inject_global(name, &LiteralValue)`——字面量注入（`pair_cells` 经 `reserve_exact` 单源充账 = §19.4 活堆纪律含宿主面）、未知名 fail-closed（`RuntimeError::InjectGlobalUnknown`——String 载荷不污染驻留池 NB-7）、注入槽 = collector 根类别三；② `kerf-expander` `expand_program_with_injected`（`injected_names` 全局回退——W-3.2 `extern_names` 先例形制；空集基线 fail-closed 维持）；③ `kerf-driver` `parse_target_with_injected` 管线接受面 + `ParsedProgram.injected` 字段 + 检查器 externals 扩展（host-bound 名 = 程序外部名、未知 arity）；④ `kerf-span` `Span::host()` 单源（宿主位标记——vm/eval 两地零跨度构造收敛）。
- **稳态自举链建立**（`crates/kerf-driver/src/bootstrap_chain.rs`）：`SteadyReaderChain`——固定孪生程序（lexer.ktf + reader.ktf，无每源前缀）编译一次（生产桥 parse → injected 展开 → 检查 → compile）+ 每读「fresh VM + 注入 bind + run + 三全局面 decode」；构建时引用在场断言（bc.globals 单源）+ 双引擎 `read_dual`（RS-4）。实测 per-read **0.588ms**（63B）/ **19.204ms**（2579B）≈ 理论 VM 份额（通道开销 ~2%）——450×/453× 维持为 T-a 生产位切换条件。
- **段一 reader = ELEVATED**（SOP v15.3 §21.12-28② 双链解耦判据）：①812 行纯 kerf 承载（lexer.ktf 671 + reader.ktf 141——8 原语 + 18 内建纯消费者）；②稳态链运转 + 读段自应用面 = 全语料 sweep 91/91 双轴逐位 vs oracle + 跨路由等价（稳态 ≡ 逐源编译路由）+ .ktf 边界拒绝 parity + RS-4 双引擎一致（.krf 自源族已随 r104 E5 batch-3 退役——诚实披露，读侧自应用 = 生产桥步④ fixpoint 面承载）；③parity 门全绿。**段二（expander 完整自举）解锁**——注入通道 form 记录载荷通解性已就位。
- **测试面 +16**：引擎 9（VM 注入 4 + eval 注入 4——含 fail-closed 三面与 define 压制契约）+ 展开器 2（injected 接受 + 空集基线/精确性）+ 集成 6（`bootstrap_chain_tests.rs`：语料 sweep / 双引擎探针 / 跨路由等价 / 确定性+喂给契约 / 边界拒绝 / 编译一次多读）；测量面 `w312a` 增 productionized 稳态相位。六命令 **1491:0:3**（基线 1475 + 16 零回归）。
- **audit AJ 族 10 案**（250→260 live）：注入通道 bind/fail-closed 三面 + 展开器接受面/基线 + 稳态链 oracle 匹配/边界/喂给/确定性——守卫（test_infra_guard TEST-3）与清单共变。
- **eval 消费面清单 C 桶 +1**（W-3.6 fail-closed 守卫捕获新消费位——bootstrap_chain.rs 同差分机角色入桶；A3/B2/**C8**/D3/E16/F1/G1 = 34，窗口记录 §1 同步修档）。
- **文档族**：w3.12-frontend-window.md v2.0（§18 审查记录 + §1a 实施后测量 + §6 升格裁决）+ stage-3-plan v2.0 + roadmap v2.54 + stage0.md v9.80（§9.113.3 缺口①清偿标注）+ tech-debt W-BOOT-FRONTEND（段一账面清偿 + 段二触发器）+ calibration T2.20 + w3.6 窗档 §1 修档 + 本 RELEASE_NOTES。

# kerf v0.82.0 — Stage 3 指令吸收轮：SOP v15.3 自举完备优先纪律·排期重排（r120）

> Stage 3 指令吸收轮（第一百二十轮）——用户常设指令①尾项（「请将此条例分析整理为清晰精要的内容补充到 docs/sop.md 中合适的章节位置以及执行流中适合节点」）+ 指令④完成标准吸收：纯文档轮零生产代码变更（8 原语不变性第八十四轮验证维持；唯一代码面 = ds08 版本锁步注释与断言）。核心产物 = SOP v15.3 §21.12 第 28 条「自举完备优先纪律」+ 窗口排期重排（W-3.12 段一实施窗升首要入口）。

## 变更

- **SOP v15.3 自举完备优先纪律**（`docs/sop.md` §21.12 第 28 条 + §1.2/§1.3/§13.1.2/§17.3 四接线点 + §16.1 changelog 行 + 头版本 v15.3-bootstrap-first）：①**排期优先级裁定**——自举阶段（自举矩阵未达完成标准）项目，自举阶梯推进（编译管道逐段完整自举 + 直接前置基础设施如注入通道生产化）拥有最高排期优先级，优先于非自举目的窗（为其自身的性能优化/工具链生态/链外后端）；自举段就绪可推进而非首要入口须附可审计裁决理由（无理由 = NEEDS REVISION）。②**双链解耦裁定**——自举链（fixpoint 验证链）与生产链（用户程序编译路径）分立验收：自举链验收 = 链路完整可完成 + 字节级 fixpoint + parity 门全绿，不受生产链 ±25% 性能带约束；段升格判据 = 自举链完备（该段以自身语言完整承载 + 自举链经该段自我编译 + parity 全绿）——不含生产位性能条件；生产位切换 = 升格后的独立后续窗（测量先行 + 回退带维持）。W-3.12 段一实测 450×（稳态）回退由本裁定重构为生产位切换条件。③**完成标准法定**（用户指令④原文）——自举完成 = 完全脱离宿主语言，自举后所有阶段的设计与开发通过自身语言进行；宪制排除项除外（VM 永久 Rust 基座 + 构建引导层 + 链外后端）。④**触发器接线**——W-BOOT-FRONTEND T-b 纯度面触发器激活（语言自我推进需求即纯度需求信号）；T-a 性能面降格为生产位切换条件。
- **知识层 K140-K142 三新锚**（`docs/stage0.md` §9.113——r120-search 六件存档）：**K140** Go 1.5 自举切换双链解耦实证（2015-08 编译器工具链整体 C→Go 机器辅助翻译，逐字翻译 ~10× 慢于 C 编译器——切换先于性能收窄，1.6-1.8 逐版本收窄；go.dev 官方发布说明 + ataylor.io + InfoQ 三源）；**K141** rustc 2011 自举先于 0.1 公开（2012-01）与 1.0 稳定（2015）多年（languagelineage.org + Wikipedia + LinuxPro 三源）；**K142** bootstrappable builds 链完备即目标（GNU Mes/Guix full-source bootstrap——「源链完备可审计」本身立为工程目标；gnu.org + bootstrappable.org + guix.gnu.org 三源）。K120-K123 四锚（rustc 三段链/Chez pb bootfiles/Guile psyntax-pp/Racket #lang reader）升格活跃参考。
- **kerf 缺口分析四项**（stage0 §9.113.3，对照优秀自举语言每阶段内容）：①注入通道生产化缺失（「source-bytes」宿主面扩展——今日字节表字面量 = 测试通道形态 ~2,900×；生产通道缺失 = 语言无法实际推进自身开发）；②HM 判定面与构建编排五切口零孪生（段三裁定域）；③双链未解耦（**本 轮 SOP v15.3 已清偿**）；④自举链工程可用性（fixpoint 链今日 = CI 门形态非开发者日常形态）。
- **窗口排期重排**：`stage-3-plan.md` v1.9（下一入口 **W-3.12 段一实施窗升首要**——注入通道生产化 §18 审查 + 稳态自举链建立 + 段一升格重裁[双链解耦新判据]；W-3.5/W-3.8 转从属位）+ `roadmap.md` v2.53（当前位置行 + 流程权威 v15.3 + r119 日期笔误勘正 2026-10-08→2026-10-05）+ `w3.12-frontend-window.md` v1.1（T-b 激活注记 + §5 触发器状态更新）+ `tech-debt-register.md` W-BOOT-FRONTEND 行更新 + r120 检视。
- **版本锁步**：Cargo.toml / Cargo.lock / ds08（snapshot_seed_tests.rs 版本断言）金链三处 v0.82.0 + 本 RELEASE_NOTES 前插。

## 验收

- 六命令：test --release **1475:0:3 维持**（纯文档轮测试数不变即无回归）+ fmt 零 diff + clippy --all-targets -D warnings 0 + build/check 0e0w；audit **250/250 live + 104 retired 维持**（零生产机制变更——W-3.6/r119 评估窗零增节先例形制）；R8 编码面清零（新增面全英文——ds08 注释）。
- 8 原语不变性：第八十四轮验证维持（SOP/stage0/plan 族纯文档变更零机制载荷）。
- 下一入口：**W-3.12 段一实施窗**（SOP v15.3 §21.12-28 首要入口裁定——注入通道生产化 + 稳态自举链 + 段一升格重裁）。

# kerf v0.81.0 — Stage 3 W-3.4 窗：分代 GC 评估窗·寿限画像与维持裁定（r119）

> Stage 3 第二波首窗（第一百一十九轮）——stage-3-plan §2.3 W-3.4 承载：分代 GC 评估窗（评估域轮——零生产机制变更，8 原语不变性第八十三轮验证维持；唯一代码面 = 测试守卫族 + 画像 example + Cargo example 注册）。出口条件三件全过：①B4 确定性轴语义重推导出册（D-CLASS-1 三元组等价类规范钉扎 + D-CLASS-2 四元组双计数口径预推导登记）②分代设计册（K115 三锚对照 + kerf 简化面/约束面）③裁定 = **维持单代 mark-sweep**（五发现证据链——实施双模零收益实证否决）。窗口记录档 = docs/develop/v3/w3.4-gc-window.md 单源。

## 变更

- **分配寿限画像**（MUV 3.4-a——`examples/bench/gc_lifetime_profile.rs` 新 example + Cargo.toml 注册 + `tool-results/r119-gc-lifetime-profile.txt` 归档单源）：逐 cycle 存活统计 × 预算纪元扫描，零生产面变更（测量仅注入既有 Collector 位）。五发现：**F1 瞬态极性**（churn 每 cycle marked=0——全灭于首次回收前；纪元 1024→4096 死亡率不变 100%）/ **F2 递归帧 GC 窗口空**（live_usage = frames + live cells，活跃帧不可回收——fib(25) 帧下限与峰值间无整数预算窗口）/ **F3 平衡构建窗口空**（iota(50) 帧↔cells 一比一互换，live_usage 恒 ≈51 平坦——纪元永不触发）/ **F4 无老代积累**（全部画像点 live_after≡0）/ **F5 不可变堆纪律**（25 操作码零堆 mutation + Closure env Rc 共享不可变 + 生产路径零 get_mut 堆消费——老→幼引用结构性不可能）。
- **B4 确定性轴语义重推导出册**（MUV 3.4-b——出口条件①，K115 设计约束兑现）：**D-CLASS-1 等价类规范钉扎**——GC 可观测语义 = 三元组 (cycle_count, swept_total, last_live_after) 为 (program, budget, collector 注入) 纯函数；任何 GC 内部优化不得改变三元组，改变 = 语义变更（K91 判据）须显式重推导。**D-CLASS-2 四元组预推导登记**——分代化后等价类扩为 (minor_cycles, major_cycles, promoted_total, last_live_after)；B4 断言届时显式迁移，禁止静默弱化。
- **三选一裁定 = 维持单代 mark-sweep**（MUV 3.4-c）：实施双模否决（五发现证明零可测收益——瞬态面 marked=0 单代已最优 + 非瞬态面 GC 窗口空 + 无老代积累；成本全付：双 arena + 复制搬运 + 分域地址 + D-CLASS-2 迁移）；递延否决（阻塞 W-3.7 JIT 入口信号）；维持 = 实测最优非妥协（VM 语义验证基座定位——永久 Rust 基座宪制同逻辑；性能路径走链外后端 W-3.8）。**W-GEN-GC 登记窗**三触发器：T-a 堆压力（跨 cycle 单调 live_after 增长 > 纪元 50%）/ T-b 暂停敏感（W-3.7 JIT 后停顿入用户可感面）/ T-c 语料规模（单 run >10^5 cells 级 sweep 成本入 B 轴带）。
- **守卫族 8 件**（MUV 3.4-d——`tests/v1/stage1/plan/gc_window_tests.rs` 新档 + runner.rs 注册，测试面 1467→1475）：正向 2（**D-CLASS-1 三元组**——3 (pairs, budget) 点位 × 3 run 逐位断言 + 跨阶段全链消费；**分代隔离模拟**——双 Heap 老代对象集逐位冻结跨 5 轮幼代 cycle，W-GEN-GC 开窗时迁移为真 nursery e2e）+ 负向 6（**操作码零 mutation 源守卫**——25 操作码表 + SetCar 形 8 变体 fail-closed 扫描；**生产零 get_mut 源守卫**——8 文件 #[cfg(test)] 尾剥离扫描；**帧下限双极 fail-closed**——fib 无/有 collector 双断言 + iota 下降段 fail-closed + 纪元 512 零 cycle；**0.6 面回归**——无 collector 超限直错维持；**跨堆死引用跳过**——无标签别名面记录）。正负比 2:6 = 1:3。
- **文档族六件 + 版本锁步**：w3.4-gc-window.md 新档 + stage0 v9.78（§9.112 头注——20,621 行维持）+ roadmap v2.52 + stage-3-plan v1.8（W-3.4 CLOSED + r119 实录）+ Cargo/Cargo.lock 金链 v0.81.0 + 本 RELEASE_NOTES 前插。

## 验收

- 六命令：test --release **1475:0:3**（+8 gc_window）+ fmt 零 diff + clippy --all-targets -D warnings 0 + build/check 0e0w；audit **250/250 live + 104 retired 维持**（评估窗零增节——W-3.6 同形先例：零生产机制变更无可审新行为面，集成守卫族承载）；R8 编码面清零（新增面全英文）。
- B4 确定性：churn(2000)@1024 = 1 cycle/1023 swept 面在 D-CLASS-1 守卫三个点位复验（2k@1024→(1,1023,0) / 10k@1024→(9,9207,0) / 10k@4096→(2,8190,0)——第十三次逐位 + 等价类扩展）。
- 下一入口：**W-3.5 增量编译窗**（双首刀另一翼——入口就绪维持）+ W-3.8 裁量 + W-3.12 段二/段三锁定维持。

# kerf v0.80.0 — Stage 3 W-3.11 窗：汇聚审计轮·首波六窗里程碑审计（r117）

> Stage 3 里程碑（第一百一十七轮）——stage-3-plan §2.3 W-3.11 承载：首波六窗（W-3.1 r111 / W-3.2 r112 / W-3.3 r114 / W-3.6 r115 / W-3.10 r116 / W-3.12 段一 r111）全关后的强制汇聚审计。出口条件三件全过：窗口体系中期审计（§14.5 深审族适配 D1-D8 + §6.6 校准 T2.19 + 投票）+ 登记态 4 能力信号复核（零信号——继续登记）+ W-3.12 段进度核对（自举矩阵三列表 + T-b 纯度面 = 零新信号）。窗口记录档 = docs/develop/v3/w3.11-convergence-audit-window.md 单源。

## 变更

- **§14.5 深审族适配 D1-D8**（八维度——零 P0/P1/P2）：D1 架构（12 crate + 窗口 DAG 无环 + 8 原语第八十一轮验证）/ D2 TD 账面（开放项 0 + 登记窗七件触发器全量实测——W-DRIVER-HARNESS-SPLIT harness 族 +4.2% 未达 +30%）/ D3 测试（39 套件 + 语料 91{35/46/10} + audit 250/250）/ D4 剩余窗就绪度（**W-3.4 ∥ W-3.5 双首刀入口完备**）/ D5 过度特化零发现 / D6 B 宪法轴带内（**B4 gc 1/swept 1023 第二十一次逐位** + B10 1.02x）/ D7 文档一致性（命中 E5 叙述残留 → 当轮清偿）/ D8 路径覆盖 + 死岛扫描零发现。
- **E5 叙述残留清偿**（§14.9 适配 C3/C4/C5——六文件 +239/−225，零行为变更）：lexer/reader/expander/compiler_parity 四模块头注重写（E5 感知 + 两步转码注入准确化）；断链/死名引用 ×7 修复（ParityLayer/ExpanderParityLayer/CompilerParityLayer 退役类型链接 + reader_parity_full_vm 死链 + krf_compile_rich_vm/krf_compile_rich 死名自引用）；标识符 ktf_ 方案（KrfVerdict→KtfVerdict、krf_name→ktf_name、dump_krf_*→dump_ktf_*、krf_tokens/krf_tree→ktf_tokens/ktf_tree——~100 位点全 crate 内部）；保留面：S-expr 皮肤现存事实 + 注释历史块 + 历史记录零追溯。
- **kp CLI 活体探针**（W-3.10 出口条件里程碑复验）：两包传递链拓扑序 + lockfile 双跑逐位确定性 + 环路径命名 + 菱形全约束罗列——PKG-3 裁定活体成立。
- **W-3.12 段进度核对**：自举矩阵三列表落档（read/expand/compile = Rust 生产 + .ktf 孪生验证全绿；typecheck/编排 = 零孪生[段三裁定域]；VM = Rust 永久基座）；T-b 纯度面复核点裁定 = 零新信号（fixpoint 经 Rust 生产 reader = 设计内形态——触发器维持 T-a/T-b）。
- **登记态 4 能力复核**：Effects 生态 / 多阶段 / 能力沙箱 / DSL 生态——窗口信号全部未定义，继续登记（原则 38/44-58 纪律）。
- **文档族九件 + 版本锁步**：w3.11-convergence-audit-window.md 新档 + stage0 v9.77（§9.111 + 20,621 行）+ roadmap v2.51 + round-records §9.111 + calibration T2.19（里程碑审计方法论四条）+ tech-debt r117 检视 + stage-3-plan v1.7（W-3.11 CLOSED）+ Cargo/Cargo.lock/ds08 金链 v0.80.0 三处。

## 验收

- 六命令：test --release **1467:0:3**（清偿前后逐位——零行为变更最强实证）+ fmt 零 diff + clippy -D warnings 0 + build/check 0e0w；audit **250/250 live + 104 retired** 维持（审计轮零增节合规）；cargo doc 零新警告；R8 编码面清零。
- 环境注记：沙箱内存约束下 cargo test 以 --jobs 2 -- --test-threads 1 + RUST_MIN_STACK=256MB 口径全绿（r115 OBS 先例延续）。
- 下一入口：**W-3.4 分代 GC 评估窗 ∥ W-3.5 增量编译窗**（双首刀就绪）+ W-3.8 裁量 + W-3.12 段二/段三锁定维持。

# kerf v0.79.0 — Stage 3 W-3.10 窗：包管理窗 manifest/lockfile 最小集（r116）

> Stage 3 第五窗·首波收官（第一百一十六轮）——stage-3-plan §2.3 W-3.10 承载：工具链层窗口（零语义内核变更——8 原语不变性第八十轮验证维持，CoreExpr/VM/18 内建表/双皮肤零触碰）。三裁定：PKG-1 文件形 = `kerf.toml`/`kerf.lock` 双文件 TOML-micro 子集（六形之外 fail-closed；.ktf 皮肤形弃用——冻结程序文法不为工具链数据文件扩文法；S-expr 形弃用——BS-A oracle 面逆退役方向；完整 TOML 依赖弃用——§18 负担）；PKG-2 实现语言 = Rust 构建引导层（cargo 同位先例；kerf-pkg 零依赖 crate；W-PKG-SELFHOST 登记窗双前置触发器）；PKG-3 注册表 = 本地优先 `libs/<name>` 布局（Go vendor 同构）+ semver caret（pre-1.0 minor 即边界）+ 菱形冲突全约束罗列报错（名称同一性——首访胜出；W-PKG-MULTISRC 登记窗）。

## 变更

- **新 crate `crates/kerf-pkg`**（零依赖——§18.5 DAG 底层）：`micro_toml`（TOML-micro 子集解析器，行:列错误族）/ `manifest`（kerf.toml 投影 + kebab 名纪律 + fail-closed）/ `semver`（Version 三元组 + Constraint caret 语义）/ `lockfile`（确定性序列化——名序 + 固定键序 + LF；双幂等断言）/ `resolve`（三色 DFS 名称同一性 + 后序拓扑序[LoadPlan 序语义] + RESOLUTION_DEPTH_LIMIT 512）/ `error`（PkgError 独立错误族——不入编译器 E0xxx 注册表，§11 域隔离）。
- **`kp` CLI**（crates/kerf-pkg/src/main.rs——用户面接线，§1.8 孤岛能力交付轮接线纪律）：`kp resolve <dir>` → 拓扑序打印 + kerf.lock 落盘。
- **根聚合**：Cargo.toml members/default-members/dependencies + src/lib.rs `pub use kerf_pkg as pkg`。
- **audit AI10 节**（examples/audit——240→250 live + 104 retired 维持）：manifest 正向/缺键/坏版本/未知键/重复键 + lockfile 确定性往返 + 两包解析序/环检测带路径/菱形冲突/缺依赖目录。
- **测试面 +49**（test --release 1418→1467）：单元 41（micro_toml 14 + semver 8 + manifest 9 + lockfile 8 + resolve 2）+ 集成 8（tests/v1/stage1/plan/pkg_window_tests.rs——两包 e2e/传递链序/环 e2e/菱形 e2e/lockfile 往返消费 + 三负向）。
- **知识锚 K137-K139**（tool-results/r116-search/ 六查存档——q1/q6 弱查披露由 q5/q4 补位）：K137 Racket info.rkt（语言原生 manifest 先例——对照后弃用：前提不成立）；K138 Go Modules MVS（确定性版本选择——多源窗锚）；K139 opam 自包装特殊地位（#1150——W-PKG-SELFHOST 触发器参照）。

## 验收

六命令：build 0e0w / check 0 / fmt 零 diff / clippy --all-targets -D warnings 0 / **test --release 1467:0:3**（+49）/ **audit 250/250 live + 104 retired-historical**（AI10 新增节）；B4 面零触碰；R8 编码面触碰文件 CJK 清零（audit 既有 CJK 夹具为登记白名单）。版本 v0.79.0 三处锁步（Cargo.toml + Cargo.lock 13 crate + ds08 金链）。

## 登记与下一入口

登记窗两件（W-PKG-SELFHOST / W-PKG-MULTISRC——tech-debt-register r116 检视 + w3.10-package-window.md §5 单源）。**首波六窗全关**（W-3.1 r111 / W-3.2 r112 / W-3.3 r114 / W-3.6 r115 / W-3.10 r116 + W-3.12 段一 r111）：下一入口 = **W-3.11 汇聚审计轮**（窗口体系里程碑——§14.5 深审族适配 + §6.6 校准统计 + 投票 + 登记态 4 能力信号复核 + W-3.12 段进度核对）∥ W-3.4 分代 GC ∥ W-3.5 增量编译（入口就绪）+ W-3.12 段二（段一门后）。

（其后在档：v0.78.0 W-3.6 评估窗 / v0.77.0 W-3.3 窗 / v0.76.0 W-3.2 窗 / v0.75.0 行权轮 W-3.1 双刀 / v0.74.0 环境回归修复 / v0.73.0 三角度审查 / v0.72.0 自举完整性专审 / v0.71.0 Stage 3+ 规划轮 / v0.70.0 全管道审查 / v0.69.0 第 9 信号与 Stage 2 关闭 / v0.68.0-v0.63.0 切换窗六段）

# kerf v0.78.0 — Stage 3 W-3.6 窗：元循环求值器退役评估（裁定 = 维持）（r115）

> Stage 3 第四窗（第一百一十五轮）——stage-3-plan §2.3 W-3.6 承载：唯一规划退役能力的评估窗（非默认动作）——消费面清单 + oracle 可再生性论证 + 三选一裁定；零生产语义变更（评估轮形制沿 r111 W-3.12-a 先例）。

## 变更

- **消费面清单**（MUV 3.6-a——出口条件 ①）：eval 消费面 = 若退役则须改动的直接符号引用集——九符号（`Engine::Eval`/`Evaluator`/`eval_repr`/`eval_text`/`BuiltinHost`/`dispatch_builtin`/`EVAL_DEPTH_LIMIT`/`parity_repr`/带引号 `"eval"`）× 四扫描根（crates/src/tests/examples）全量勘定 = **七桶 33 文件**：求值器本体域 3（kerf-runtime：eval.rs 1,385 行 + 导出面 + parity_repr 结构比较键）+ 引擎分派面 2 + parity oracle 面 7（含 fixpoint.rs:173 引擎一致断言——宪制判据承重位）+ EVL-1 共享面 3（§9.73 BuiltinHost/dispatch_builtin 单源 18 臂）+ 测试族 16 + 审计集 1（Section H 10 案）+ 基准面 1；传递性/通用消费者如实分账（src/lib.rs / repl.rs / composed_full_chain.rs——零 eval 特有符号不入直接面）。
- **fail-closed 守卫**（集成验证用例）：`tests/v1/stage1/plan/eval_inventory_guard_tests.rs` 三断言——零未分类残留（新 eval 消费位未分类 = 测试红——清单先于引用扩张）/ 零幻影条目（双向完备）/ 桶形钉扎（A3/B2/C7/D3/E16/F1/G1 = 33——守卫自身九符号携带位自指入账 E 桶）；TEST-1/2/3 先例形制（§9.57 纯读计面零管线执行零新依赖）。
- **oracle 可再生性论证**（出口条件 ②）：三恢复通道强度不对称——VCS（全历史 git + §19 双包快照；**差分性质可恢复的唯一通道**）＞ 语料期望（91 案 in-file 期望引擎中立——行为面可恢复）＞ fixpoint/digest（编译器自一致性见证，非独立第二实现差分见证）。可恢复性成立 ≠ 退役正当性成立。
- **三选一裁定 = 维持**（出口条件 ③）：退役否决四论据——①fixpoint 宪制判据承重（C_t(S') 相位即 vm_text==eval_text 断言——退役 = Stage 2 出口判据 (2) 执行相位降级单引擎自证）；②K15 差分 oracle 活跃消费（91 案 + 组成链 + audit H 节 + 测试族 13 文件）；③EVL-1 共享面不减账（BuiltinHost 双引擎共有——节省仅 eval.rs 本体）；④静默删除红线（§21.7——独立第二实现差分价值无等价替代）。换刀否决（当前）：C 后端 e2e = 链外面 41 案未达 parity oracle 同级覆盖。
- **W-EVAL-RETIRE 登记窗**（tech-debt-register）：触发器二选一重开退役议程——T-a 独立 oracle 等位（C vs VM agreement 全语料系统化 + 连续 3 轮零差分误报）/ T-b 语义规格形式化（subset-spec 期望面升格可执行形式规格）；静默删除禁令永续（退役三前置 = 独立 commit + 回滚预案 + 可再生性复核）。
- **知识锚 K134-K136**（六查实体存档 tool-results/r115-search/）：K134 wasm 参考解释器（W3C WG 交付物并存永续——github.com/WebAssembly/spec interpreter/）；K135 Miri（github.com/rust-lang/miri——解释器 oracle 跑完整测试套件，检出价值 > 速度成本）；K136 参考实现即可执行规格文献族（Numbat arxiv 2026-09 / RuSMT dl.acm / leanerVM github——独立实现差分 ≠ 冗余实现）。

## 六命令与验收

- `cargo test --release`：**1418 passed / 0 failed / 3 ignored**（1415→1418 = +3：守卫三断言——首轮冷跑一次全绿）。
- audit **240/240 live + 104 retired**（评估轮零行为面变更——沿 r111 评估窗先例零增节）。
- fmt 零 diff；clippy `--all-targets -D warnings` 零告警；build/check 0e0w；B4 面零触碰（零生产语义变更）。
- 版本：v0.78.0（Cargo workspace + Cargo.lock + ds08 金链三处锁步）。

## 账面与文档族

- tech-debt-register：W-EVAL-RETIRE 登记窗一件（r115 检视节）+ 零新 TD。
- 文档族共变：stage0 §9.109 + 头 v9.75、roadmap v2.49、calibration T2.17、stage-3-plan v1.5（W-3.6 关闭）、w3.6-eval-retirement-window.md（窗口记录档）、RELEASE_NOTES 本档。
- 下一入口：W-3.10 包管理窗（首波六窗收官位）∥ W-3.11 汇聚审计轮（入口条件已集齐——四窗关闭）+ W-3.4/W-3.5 入口就绪。

---

# kerf v0.77.0 — Stage 3 W-3.3 窗：宏声明皮肤面（TD-007 清偿）（r114）

> Stage 3 第三窗（第一百一十四轮）——stage-3-plan §2.3 W-3.3 承载：TD-007 账面归零（r103 登记的宏声明目标皮肤缺口闭合）+ r103 账本 9 语料案处置 + 匹配树不变性构造性证明。

## 变更

- **语言面（目标皮肤 ReaderFace 扩展——W-3.2 同门三重门控通道；CoreExpr/VM/compiler 零触碰）**：
  - **声明载体**：`macro name { spec }` → `(define-syntax name spec)`——花括号 item 形（`fn`/`module`/`extern` 族同形制）；关键字与花括号 = 皮肤材料（映射面丢弃——`fn`→`define`、`!`→丢弃先例）；调用/声明对称（`name!(...)` + `macro name {...}`）。
  - **载体裁定**（出口条件 ① 对照权衡）：块形/花括号载体胜出；quote 包裹否决（保留包裹 = spec 树漂移至 `(quote ...)` ≠ `(syntax-rules ...)`——匹配树漂移即 TD-007 警告本体；读取面单点丢弃 = 位置特判违通解）。
  - **spec datum 模式逐字承载**：ruling F 从 quote 载体升格到声明载体——零隐式合成（spec 树含 `syntax-rules` 头逐字源锚定，§9.47 span 纪律）；读取器零 spec 形状校验（共享展开器 `SyntaxRules::parse` 单点裁定——两皮肤同阶段拒绝纪律）。
  - **datum 面词汇扩展**（名称表驱动通解边界，非逐例枚举）：运算符 token → 规范名符号（表达式面 op-name 表复用——`==`→`=` 唯一异形）；`...` 新 token（最长匹配先于 `..`）→ 符号 `...`（neg-052 同阶段拒绝前提：读取合法 + transformer 注册期拒绝——阶段分歧陷阱规避）；裸 `-`（后随非数字）→ 符号 `-`（减法模板可拼性——`is_number_shaped` 同边界）；KwExtern/KwMacro 补入 datum 命名面（§20.6 同类路径清偿——W-3.2 遗留缺口一并修）。
  - **匹配树语义不变证明**（构造性）：映射树与 S-expr 面逐位同构（name 经 skin_symbol + spec 即 datum 树）——共享展开器皮肤盲；验证承载 = 转码器 round-trip 守卫（Stx display 逐位）+ 三路门（α + 语义投影 + 值面）。
- **转码器机械臂**：`(define-syntax name spec)` → `macro NAME' { SPEC' }`（spec 经 `emit_target_datum` 单源发射——Symbol 臂升级 `target_name` 使 `=` 数据可拼 `==`，quote 载体同类路径一并惠及）；`TranscodeError::MacroDeclaration` 变体退役（族转可拼——死变体 = cruft）；畸形 arity fail-closed 入 unspellable 账本。
- **9 语料案处置**（r103 账本转正）：8 案（pos-024/032/033 + neg-050/051/052/053 + bnd-010）机械转正——双皮肤契约全绿（posit 四案三路门 / negativ 四案同阶段拒绝类 / bnd 一案展开限深）；**pos-031 转关键字经济词汇分歧钉扎**：声明面已可拼（单独验证），使用形 `(k-cond ... else ...)` 的 `else` 表达式位为目标文法保留字（inverse-C12 形——种子面接受目标文法保留的名；声明修复揭示的既有边界，非宏面缺口）。
- **门审 AH 节 +10**：载体映射锚 / 展开记录 / e2e 值面 / 省略号同阶段拒绝 / 运算符词汇 / 字面量面（可拼拼写 when/otherwise）/ 模块作用域 / 载体读取期文法 / 两皮肤三路门 / 卫生 rename-on-capture 防御；AF8 翻正（账本断言 → 转正断言）。

## 六命令与验收

- `cargo test --release`：**1415 passed / 0 failed / 3 ignored**（1408→1415 = +7：reader+5 / 转码器+1 / sweep+1）。
- audit **240/240 live + 104 retired**（AH 节 +10）。
- fmt 零 diff；clippy `--all-targets -D warnings` 零告警；build/check 0e0w；B4 面零触碰（表示级扩展零内核变更）。
- 版本：v0.77.0（Cargo workspace + Cargo.lock + ds08 金链三处锁步）。

## 账面与文档族

- tech-debt-register：**TD-007 [Resolved at Stage 3.3]** + r114 检视节（零新 TD）。
- 文档族共变：stage0 §9.108 + 头 v9.74、roadmap v2.48、calibration T2.16、stage-3-plan v1.4（W-3.3 关闭）、w3.3-macro-decl-window.md（窗口记录档）、RELEASE_NOTES 本档。

---

# kerf v0.76.0 — Stage 3 W-3.2 窗：FFI extern 语言面与所有权四则语言级投影（r112）

> Stage 3 第二窗（第一百一十二轮）——stage-3-plan §2.3 W-3.2 承载：B1 清偿（deep-review-round2.8 §14.8 唯一「实现 < 设计」偏差闭合——实现 = 设计）+ TD-026 dangling 再裁定 + K118 语言级投影。

## 变更

- **语言面（声明层第五变体——DefineSyntax 0.9 先例；CoreExpr 九原语/VM 25 操作码/18 内建表零触碰）**：
  - 双皮肤声明形：目标 `extern "C" { fn add(x: int, y: int) -> int; }` ↔ 规范 `(extern "C" (add (int int) int))`（S-expr 读者零变更——表单警察 = 展开器）；类型词汇 = `int`/`bool`/`float`（C ABI 标量全集——int64_t/_Bool/double 直接物化）。
  - **C 符号推导裁定**（R-F4 零修饰读法）：C 符号 = 规范名的目标皮肤拼写（内部 `-`→`_`——皮肤字典自身方向）；确定性纯函数单源（`ExternItem::c_symbol`）；程序内注入性双层强制（展开器碰撞错误 + verify 结构地板）。
  - 表单警察五族：ABI 词汇（仅 "C"）/ 类型词汇 / 碰撞（extern↔extern/define/Stage0 全局——扁平命名空间裁定）/ C 符号合法性 / 顶层限位（嵌套 module 拒绝——C 命名空间扁平）+ 宏面豁免（宏惰性 + 保留名）+ bind-first（调用位可先于声明位）。
- **类型面（软类型释放纪律的契约例外裁定）**：extern 契约注册单调 Arrow（infer lookup 第 2.5 层）；调用位走通用 arrow 路径（排除出内建 ad-hoc 表）；**具体-具体失配 = 定错 E0009**（unify_args 契约臂——声明不是推断近似）；检查器 arity 面（Externals 第三权威源——程序 extern）E0002。
- **产物面**：`Bytecode.externs: Vec<ExternEntry>`（PartialEq 吸收——gate-B oracle 结构性覆盖）；verify Pass 0e（重复名/非法 C 符号——手工产物同一法官）；`SemanticDigest.externs`（gate-B 透明性先行——K119 纪律）。
- **引擎面**：VM/eval 双非引外引擎一致 fail-closed——`extern function `X` requires the C backend`（字节码 extern 表命名契约，非误报 unbound global；皮肤感知消息族共变）。
- **C 后端面**：全量原型发射（未引用原型零链接义务）+ 引用位包装器（`k_extern_N`——marshaling 三助手 = R-F1 物化位）+ `K_EXTERN=8` 值标签 + k_call 分派臂 + 全局播种。
- **e2e（真 cc 编译 + 外部库链接 + 真执行）**：int（add(2,40)→42）/ bool+float（truthy/scaled）/ **R-F2 转移语义见证**（C 助手内部 malloc/free + 静态计数器——两调用 (42,2) 且 frees==2）/ 运行期类型守卫（Dyn 泄漏面——`extern `add` argument must be an int, got `bool``）/ 运行期 arity 守卫（手工产物 k_fail_arity）。
- **语料 85→91**：pos-037（声明未调用值面）+ neg-058（VM 调用运行期）+ neg-059..062（警察四族）——双皮肤 sweep 全绿（α 字段级新臂 + semantic projection 含 externs + 转码器 extern 臂）。
- **孪生缺口如实登记**：.ktf 编译器/展开器孪生（BS-A 冻结种子链）不识 extern——composed 链 junction 2 走披露行（账本 extern_row=6 钉扎「the .ktf twin gap」）；孪生刷新 = W-3.12 段三裁定域邻接决策。
- **TD-026 再裁定**：标量批 dangling 结构性不可能（零堆引用跨界）→ 转堆类型扩展面门条件 riding 登记（不闭账）。

## 六命令与验收

- `cargo test --release`：**1408 passed / 0 failed / 3 ignored**（1381→1408 = +27：core+3 / expander+8 / reader+2 / typecheck+3 / vm+1 / compiler+1 / e2e+5 / 语料+6）。
- audit **230/230 live + 104 retired**（AG 节 +10——双皮肤形/展开记录/ABI/类型/碰撞/推导/arity/E0009/VM 诊断/发射）。
- fmt 零 diff；clippy `--all-targets -D warnings` 零告警；build/check 0e0w；B4 确定性零扰动（extern 记录零码零分配）。
- 版本：v0.76.0（Cargo workspace + Cargo.lock + ds08 金链三处锁步）。

## 账面与文档族

- tech-debt-register：TD-026 riding 登记（堆类型扩展面门条件）+ r112 检视节。
- 文档族共变：stage0 §9.107 + 头 v9.73、roadmap v2.47、calibration T2.15、stage-3-plan v1.3（W-3.2 关闭）、w3.2-ffi-extern-window.md（窗口记录档）、RELEASE_NOTES 本档。

---

# kerf v0.75.0 — Stage 3 行权轮：性能地基窗首刀双实施 + 前端自举段一评估（r111）

> Stage 3 行权轮（第一百一十一轮）——用户句式「放行 stage3 阶段」（stage-3-plan §0.2 句式族）→ §0 门第 4 要件 ✓ 行权闭合；附定谳「cargo test 已经正确（问题是在 nix 环境上）」——r110 §9.105 对照实验定谳获用户确认。

## 变更

- **行权轮十项复查全绿**：六命令 1381:0:2（r110 基线逐位复现）+ fmt 零 diff + clippy 0 + audit 220/220 + 104 retired + B 全轴三跑带内（B4 第十九次逐位 gc 1/swept 1023 + B9c 3.3× + B10 1.00x）+ TD 登记态核对 + 语料 85 + selfhost 五件 .ktf + 谱系 + 登记窗触发器核对（W-PERF-ENV-COPY 触发即本轮开窗消费）。
- **W-3.1 性能地基窗首刀（3.1-a/b/c）**：
  - 3.1-a 基线册三跑出册（docs/develop/v0/stage-0/performance-baseline.md §2 r111 行）。
  - 3.1-b env-copy 刀 **实施**（Rc<Vec<Value>> 共享不可变捕获区）：`invoke` 位 O(captured) 拷贝退役为计数递增；eval 引擎同位刀（`Rc::clone(&d.env)`）；结构性不变量先于实施验证（无 store-to-captured 操作码——全量清点）；**B6d 新轴**（一次创建 + 万次调用循环）刀前 141.7ns → 刀后 108.8ns（**−23.5%**）；创建面 +9~19% 带内（Rc 盒计入创建——盈亏平衡 ≈ 每闭包 ≥1 次调用[captured=25]）；**B4 gc 1/swept 1023 第二十次逐位一致**（K91 确定性可观测面——双刀零语义变更最强实证）。
  - 3.1-c TgtToken 零拷贝刀 **实施**（`text: &'src str` 源切片 + `digits_text` Cow——无 `_` 数字零分配解析、有 `_` 瞬态 strip）：生命周期内化 `kerf-reader::target` 模块（公共 API 零变更）；错误路径独占消费经全量清点证实（`err_unexpected` 单点——错误位自付 `to_string`）；含 `_` 数字令牌诊断文本从 strip 形态变原始形态（无黄金断言锚定——诊断面披露性变更）。
- **W-3.12 前端自举推进窗段一首刀（3.12-a 评估册）**：测量先行（`w312a_selfhost_read_face_vs_rust_oracle` #[ignore] 测量面）——**vm/rust 稳态 450×**（fib 63B 0.581ms vs 1.29µs；nesting 2.6KB 19.05ms vs 42.3µs——两尺寸一致）+ 今日通道形态 ~2,900×（字节表入程序文本 → 每源重编译 3.1ms）；三选一 = **维持（Rust 生产位）**（风险表①原文执行）+ 注入通道生产化改造面登记（通道不存在于当前实现——机制层设计工作）+ **触发器重定义**（T-a：W-3.7 tier-up 后 vm/rust < 10× 实测 / T-b：fixpoint 经 .ktf reader 纯度面需求）。段序硬规则零倒置（段二/段三零推进）。
- **B6d 调用份额轴新增**（examples/bench B6 族 + `b6d_bytecode`）——B 族补齐调用密集轴（B6a/b/c 仅创建面）。
- **窗口记录档两件新档**：`docs/develop/v3/w3.1-performance-window.md`（两刀裁决册——三选一论证各带权衡披露）+ `w3.12-frontend-window.md`（评估册——差距清单 + 三选一 + 触发器重定义）。

## 六命令与验收

- `cargo test --release`：**1381 passed / 0 failed / 3 ignored**（+1 ignored = w312a 测量面；r110 基线 1381:0:2 的 passed 逐位维持——两刀表示级零测试面扰动）。
- audit 220/220 live + 104 retired-historical 维持；fmt 零 diff；clippy `-D warnings` 零告警；`cargo check` 0e0w。
- B 系列：开窗三跑（刀前）+ 双刀终测全带内（B7 24.33ms / B8 3604.2ms 回落 r105 带 / B10 1.01x / B4 逐位）。
- 版本：v0.75.0（Cargo workspace 锁步 + ds08 金链锁步——`rg -n "0\.74\.0"` 清零）。

## 账面与文档族

- tech-debt-register：W-PERF-ENV-COPY / W-TGT-TOKEN-ZERO-COPY → **[Resolved at Stage 3.1]**（r111）+ r111 检视；W-BOOT-FRONTEND 触发器更新（维持 Open）。
- 文档族共变：stage-3-plan v1.2（§0 门闭合 + §5 落地实录）、stage0 §9.106（K128-K130）、roadmap v2.46、performance-baseline r111 行（当前有效基线）、calibration T2.14、RELEASE_NOTES 本档。

---

# kerf v0.74.0 — 环境回归修复轮：C 后端 e2e 工具链配对卫生（r110）

> 环境回归修复轮（第一百一十轮）——Stage 3 实施入口 ⛔ 待行权维持（stage-3-plan §0.2 句式族）。触发：用户侧 v0.73.0 六命令复跑 12 个 `c_backend_e2e_tests` 全灭（exit 127 + `__pointer_chk_guard@GLIBC_PRIVATE` 装载失败）。

## 变更

- **根因定位（110-a）**：同树沙盒一致工具链复现 14:0:2 全绿 → 树健全，缺陷类 = 环境性——impure Nix dev-shell 的 ambient 污染变量把 cc 产物的 ELF 解释器与 libc 拆配不同 glibc 构建（PTR_MANGLE 已迁移 `__pointer_chk_guard_local`，旧符号跨构建无解析契约 → 装载期必死）；`read_line` 案的 BrokenPipe 为次生遮蔽。全仓 spawn 审计（§20.3）收敛：三处 `Command::new` 全在该测试文件，driver emit-c 面只产文本永不 shell out（§9.92 宪制维持）。
- **双边界 scrub（110-b）**：链接边界八变量（`LIBRARY_PATH`/`CPATH`/`C_INCLUDE_PATH`/`CPLUS_INCLUDE_PATH`/`OBJC_INCLUDE_PATH`/`COMPILER_PATH`/`GCC_EXEC_PREFIX`/`LD_RUN_PATH`）+ 装载边界五变量（`LD_LIBRARY_PATH`/`LD_PRELOAD`/`LD_AUDIT` + `DYLD_*` 双子）——`cc_scrubbed`/`bin_scrubbed` 单一 choke point；宿主 cc 与 Nix wrapper 两世界安全论证落档。
- **诊断面**：`is_loader_abort` 分类器（exit 127 ∨ 四标记族；shim 出口契约 0/1 使 127 零假阳性）+ `loader_abort_report` 可行动报告（环境配对缺陷类命名 + 一致工具链出路）；stdin 尽力喂送（子进程未读即死不再以 BrokenPipe panic 遮蔽真出口）。
- **三面防护证明（+4 测试 1377→1381）**：Face 1 scrub 注册面（`get_envs` None 断言）/ Face 2 毒物致死负控（毒 `stdio.h` 杀未防护编译 + 毒 `libc.so.6` 杀未防护装载——真实装载器文本入分类器）/ Face 3 事件重放（`scripts/testing/replay-poisoned-ambient.sh`——被污染 ambient 下套件 18:0:2）+ 分类器 fixture 面（含用户事件原文本）。
- **工具归档（§3.4）**：`scripts/testing/` 冷启动终结 + `docs/scripts/replay-poisoned-ambient.md`；K127 三锚（CMake `ENVIRONMENT_MODIFICATION` `unset=` 一等面 / glibc pointer_guard 源码证据 / ld.so 搜索序）入 stage0 §9.105。

## 六命令

build 0e0w / check 0 / fmt 零 diff / clippy -D warnings 0 / test --release **1381:0:2** / audit **220/220 + 104 retired**。**下一入口**：Stage 3 实施行权（stage-3-plan §0.2 句式族——行权后 W-3.1 性能地基窗首刀 ∥ W-3.12 段一 reader 升格评估首刀）。

# kerf v0.73.0 — interlude audit round: compile-time skin-aware diagnostics and module-name dictionary consistency (r109)

> 阶段间审查轮（第一百零九轮）——Stage 3 实施入口 ⛔ 待行权维持（stage-3-plan §0.2 句式族）。基线：r108 终态 `b7d5bcc` 六命令冷跑逐位复现零漂移。

## 变更

- **reader 模块拆分（F3）**：`target.rs`（2,757 行单体）→ `target/` 六文件子模块树（mod/token/skin/lexer/parser/tests——镜像 s-expr 孪生 token/lexer/parser 布局；纯移动零行为变更；W-3.12 reader 升格评估的首刀成本归因受益）。
- **诊断词汇纪律（F1）**：`unsupported form` 消息退役内部计划词汇（"seed reader scope / switch-window step 2" → "not part of the current language subset"——用户面语言约束表述）。
- **编译期皮肤感知诊断（F2——SKIN-DIAG 编译期扩展，18 形状）**：expander/typecheck/compiler/module 四 crate 的标识符载荷错误在 target face 以用户实际书写拼写呈现（`my_undef`/`x_y`/`cap_v`/`my_fn` 等——subject 供给面 + 精确令牌替换呈现层；S-expr face 逐字不变；引擎载荷恒规范名）。
- **模块名字典一致性（F5——ruling 修正）**：`use path;` 与 `use "name";` 两面经皮肤字典 canonicalize（`module m_a` + `use m_a;` 现在正确解析——此前报自相矛盾的 "not declared"）；`require("name")` 调用载体在 target 皮肤 fail-closed 拒绝（指引 `use` 形）；模块循环路径段反引号化（R8）。
- **debug 测试栈溢出修复（F4）**：深递归 nesting 探针移入 64MiB 显式栈线程——plain `cargo test`（debug）全绿。
- **测试**：1375→**1377**（+2 驱动诊断族：双面单元四断言 + e2e 七案）；audit **220/220 live + 104 retired** 维持。

## 六命令

build 0e0w / check 0 / fmt 零 diff / clippy -D warnings 0 / test --release **1377:0:2** / audit **220/220 + 104 retired**。**下一入口**：Stage 3 实施行权（stage-3-plan §0.2 句式族——行权后 W-3.1 性能地基窗首刀 ∥ W-3.12 段一 reader 升格评估首刀）。

# v0.72.0 — 阶段间审查轮：自举完整性专审与前端自举推进窗（第一百零八轮 · r108）

**L3 常规轮（审查 + 实施修复 + 规划补全复合）**——Stage 3 实施入口 ⛔ 待行权维持（r79 先例）；本轮为 stage0-2 域合法变更 + 规划缺口清偿。**交付**：

- **108-b 自举完整性专审**（只读子代理，代码级证据五问）：生产链引擎逐段映射（read/expand/typecheck/compile/执行/emit-c 全段 Rust 引擎——file:line 锚）+ **compiler.ktf 定位裁定 = 自举验证产物非生产引擎**（rg 全仓调用点零 CLI 生产路径——用户程序字节码 100% Rust 编译器产出）+ BS-A 端态差距实测（HM 判定面与构建编排五切口零孪生）+ 用户硬规则两方论据裁定（历史阶梯无跳级——两坐标系投影；但满足路径须由规划窗口承载）+ s-expr 残留复扫（表面语法 **0**——`==`/eq 两内建并存非二义、first/rest/pair = 皮肤字典登记拼写；三面设计性词汇族：内部规范词汇[架构] / 运行期诊断泄漏[本轮 FIX-1 清偿] / C 后端符号名[链外注记]）。
- **FIX-1 皮肤感知运行期诊断面**（SKIN-DIAG 裁定族四条）：kerf-vm error.rs 六单源合成函数（消息形状单源——Display 委托与 driver 皮肤感知重合成共用）+ driver target_name/target_context（皮肤字典单源 + `=`→`==` 唯一算子分歧 + Builtin::from_name 单源判据）+ ParsedProgram 携 face 字段（run/run_parity 四转换点）+ 测试 +3（映射表/变体双面/e2e 五案经参数路由静态不透明形制）——.ktf 程序运行期错误命名用户实际书写拼写（`write_line operand`/`` `first` expects ``/`` `==` operand ``/`my_undef_fn`/`read_line: end of input`）；引擎载荷恒规范名（双引擎 parity 零漂移）。
- **FIX-2/3 顺偿**：target_corpus.rs 头注/五常量注释 E5 陈旧清偿（BS-A oracle 口径）+ fixpoint.rs 头注断链两处与 .krf 叙述三处 + cli.rs banner（stage 0 skin → sexpr | target skins）。
- **stage-3-plan.md v1.1**：**W-3.12 前端自举推进窗**（108-b 缺口清偿——段序硬规则 reader 完整自举 → expander 完整自举 → HM/构建编排裁定段[补孪生或宪法性排除]，不可倒置；首刀 MUV 3.12-a reader 段升格评估册 = 测量先行 + 升格/维持/换刀三选一论证 + 85 语料两皮肤 sweep 逐位断言；风险表四行）+ DAG 增边 + 两登记项收编（W-BOOT-FRONTEND / W-DIAG-OPCODE-CONTEXT → W-3.12/W-3.9）。
- **知识检索 K120-K123 四锚**（stage0 §9.103.2 + 检索实体存档）：rustc 三段自举与种子链恒存（cfg(bootstrap) 双实现位 = ReaderFace 形态同构）/ Chez pb bootfiles（冻结种子 + 自宿主其上）/ Guile psyntax-pp 预展开冻结种子（与 .ktf 孪生同构）/ Racket #lang reader = 语言内模块——权衡结论：测量先行 + 段门硬规则，不存在跳过评估直接升格的路径。
- **文档族**：stage0 §9.103 + 头 v9.69 + roadmap v2.43（Stage 3+ 行增 W-3.12）+ round-records §9.103 + calibration T2.11 + tech-debt-register r108 两窗 + Cargo/ds08 锁步 0.72.0。

**六命令**：build 0e0w / check 0 / fmt 零 diff / clippy -D warnings 0 / test **1375:0:2**（+3 diagnostic 族）/ audit **220/220 + 104 retired**。**下一入口**：Stage 3 实施行权（stage-3-plan §0.2 句式族——行权后 W-3.1 性能地基窗首刀 ∥ W-3.12 段一 reader 升格评估首刀）。

# v0.71.0 — Stage 3+ 规划轮：窗口体系落档与知识检索七查（第一百零七轮 · r107）

**新阶段第一次规划**（SOP §13.1 + §17 七步 + §21.7 成熟度重核对 + 演进矩阵 Stage 3 行具体化）——纯规划域轮，零生产代码变更（唯一代码面 = typecheck infer.rs 头注精度顺偿 + Cargo/ds08 版本锁步）。**交付**：

- **docs/develop/v3/stage-3-plan.md v1.0 新档**：十窗体系（W-3.1 性能地基[W-PERF-ENV-COPY/W-TGT-TOKEN-ZERO-COPY 两登记刀 + B 系列复测] ∥ W-3.2 FFI extern 语言面[B1×1 清偿 + TD-026 再裁定 + R-F1..R-F4 语言级投影] ∥ W-3.3 宏声明皮肤[TD-007 清偿] ∥ W-3.6 元循环求值器退役评估[消费面清单 + 可再生性前提——唯一规划退役能力] ∥ W-3.10 包管理[Cargo 三原则适配] → W-3.4 分代 GC 评估[B4 确定性轴重推导前提] ∥ W-3.5 增量编译[cache.rs P2 做实 + gate B digest 透明性] → W-3.7 JIT 评估[profiling 前提 + EXC-10 超级指令权衡] → W-3.8 后端升级评估[C 天花板先测 + 链外宪制] → W-3.9 LSP[JSON-RPC + driver 复用] → W-3.11 汇聚审计）+ 每窗入口信号/出口条件/首刀 MUV（含集成验证用例）+ 登记债 8 项全映射 + §0 门四要件（1-3 ✓ + 4 ⛔ 待行权——r79 先例句式族 + 行权轮十项复查前置）+ §13.1 对齐小节（B1×1 偏差承载 + 灰区五决策）。
- **stage0.md v9.68 §9.102**：K113-K119 七知识锚（cranelift-vs-LLVM 后端权衡[rustc_codegen_cranelift 实录] / 分层 JIT 设计 / 分代 nursery 半空间[Mono SGen + V8 Orinoco——B4 确定性轴重推导约束] / rust-analyzer LSP 架构 / 包管理 lockfile 设计空间[ACM 2026 + Cargo 三原则] / FFI 安全边界 / salsa 增量查询化）+ 窗口体系设计裁定（持续演进≠无界开窗——时间治理四红线继承 + 4 能力登记态零预支 + 依赖拓扑 DAG + 宪制边界全量继承）+ §21.7 Stage 3 适配风险表六行。
- **全管道审查复核**（每轮义务）：六命令冷跑逐位复现（1372:0:2 + audit 220/220 + 104 retired——git clean @ `3738b94` 零漂移基线）+ r106 修复在位核验 + Stage 3 就绪面聚焦（cbackend/shim/GC/reserved 四接口）+ s-expr 残留零点（生产路径零 .krf——BS-A 种子链宪制保留；.ktf 现代运算符确认）+ P4×1 头注精度顺偿。
- **文档族**：roadmap v2.42 + round-records §9.102 + calibration T2.10 + tech-debt 三窗触发器核对（W-PERF-ENV-COPY = Stage 3 行权即开——其余零信号）+ Cargo/ds08 锁步 0.71.0（r106 教训：bump 先于终验）。

**六命令**：build 0e0w / check 0 / fmt 零 diff / clippy -D warnings 0 / test **1372:0:2** 维持（规划轮零行为变更）/ audit **220/220 + 104 retired**。**下一入口**：Stage 3 实施行权（stage-3-plan §0.2 句式族——行权后 W-3.1 性能地基窗首刀）。

# v0.70.0 — Stage 3+ 规划轮前置：全管道审查与实施修复（第一百零六轮 · r106）

**第十二轮恢复 + 三路域审 + P2×6/P3×15 修复实施**——第十一次沙箱重置恢复（Pack B `7104f35a` sha256 逐位校验）后，三路并行域审（前端五域 / 中后端四域 / 编排·检查·自举三域）对 v0.69.0 全管道做出审查：**P0=0 / P1=0 / P2=6 / P3=17**，零宪法违反。全部 P2 当轮实施清偿 + P3 十四项实施/复核 + 三项登记窗（vm 每调用 env 拷贝 = Stage 3+ 性能刀候选【MLton/OCaml 锚】/ TgtToken 零拷贝 = W 窗 / driver 验证 harness 族拆分 = Stage 3+ 议程观察）。核心修复：

- **cbackend k_enter 计费 off-by-one**：帧路径 LIVE 上限 = budget−1 vs VM/细胞路径 = budget——check-then-allocate 序归一，帧边界 e2e 钉扎（GHC -fvia-C 边界精确教训锚）
- **verify 单一合法性裁判**：entry-proto 闭包捕获 + entry captures 两守卫从 cbackend 迁入 `Bytecode::verify`（此前 VM 侧静默错行为/panic——JVM verifier 单点闭合锚）
- **CLI/REPL .ktf 生产皮肤可达性**：`--skin sexpr|target` 旗标 + 扩展名默认路由（rustc `--edition` / gcc `-x` 先例）——`kerf run selfhost/v1/compiler.ktf` 首次从二进制可执行；REPL 目标模式（`define(_replN, expr);` 包装 + UnclosedTargetDelim/EOF 不完整族）
- **三个 §9.47 span 纪律缺口**（审查伴生发现）：目标块形 span 未覆盖闭合 `}` / 中缀形 span 起点在操作符而非左操作数——datum 零变化仅 span 矫正
- **selfhost 文档工具族 E5 残留清理**：README 全量重写（.ktf 唯一皮肤口径）+ 五件头注历史化 + krf_reformat.py 退役
- **守卫族闭集扩全**：reader 三数组（every_variant/positioned/spanned）+ expander FORMS（12→13 含 match）——R8 家族巡检当轮捕获真实违例（UnsupportedTargetForm 反引号开头）并修复
- **DepthGuard 八位点泄漏归一**：全部 enter 位点统一闭包惯用形（无条件 leave）——§9.97 结构性 bug 族预防性清偿（另捕获一处任务书外裸泄漏）
- 其余：alpha_rename 下限钉扎 / E0012 注册表测试扩全 / 转义单源化（emit_escaped_string 提取）/ -0.0 is_sign_negative / pop-handler pc parity / 24→25 注记 / BINDER_FORM_HEADS 钉扎 / symbol 三助手归位 SyntaxObject 固有方法 / rustdoc 四断链清零 / 测试面构造器 cfg(test)

**六命令**：build 0e0w / check 0 / fmt 零 diff / clippy -D warnings 0 / test **1372:0:0**（2 ignored 披露维持，+14 净增）/ audit **220/220 + 104 retired**。**下一入口**：Stage 3+ 规划轮（§13.1 设计对齐 + §21.7 成熟度重核对 + 演进矩阵 Stage 3 行 + §17 七步任务规划——实施入口待用户行权）。

# v0.69.0 — Stage 2.8 末轮 L3 收口：第 9 信号与 Stage 2 关闭（第一百零五回合 · r105）

**Stage 2 CLOSED（GO）**——出口判据四项终核全过 + 九信号 9✓/9 + 投票 5.5/5.5：
- **第 9 信号（§14.6 四项全过）**：数据流覆盖四轴重签 + 架构审查九子阶段终评（全 ✅）+ 设计-实现-测试三列对照 + 隐藏问题零强制修复项 + 重构最优性五域论证——七件套终稿全量交付。
- **FFI 评估窗三面口径裁决（判据 (4) 终核通过）**：所有权模型 R-F1..R-F4 已定义 + C ABI 二进制可用性已工作（语料 C 41/41 + kerf_rt shim）+ kerf 源级 extern = Stage 3+ 窗口承载（P4 处理程度 + 零语法冻结宪制 + 宏窗口同段位）。
- **恢复链（第十次沙箱重置）**：GitHub 404 不可达 → 本地 Pack B d620a8bb sha256 逐位校验恢复 + Rust 1.99.0 重装 + 六命令 1358:0:0 冷跑复现 + ds08 版本锁步 P1 当轮修复（chore 侧 bump 未锁步——同类全量审查单一发生）+ 后置三件重建（roadmap v2.39 / calibration T2.7-6 / round-records #9.99——重建注记披露）。
- **§14.5 D1-D8 零阻塞 + §14.8 偏差清单全处置（B1×1 → Stage 3+ 计划）+ §14.9 C1-C6 全过 + §6.6 校准统计（T2.8）+ §6.3 投票 5.5/5.5**。
- 六命令全绿：build/check 0e0w + fmt 零 diff + clippy -D warnings 零 + test --release **1358:0:0**（2 ignored 维持）+ audit **220/220 live + 104 retired-historical**；8 原语不变性第七十二轮验证（零新原语零通道零 VM 零语法）。
- 文档族：stage0.md §9.100 + 头 v9.66 + roadmap v2.40 + calibration T2.8 + round-records #9.100 + stage-2-plan 2.8 关闭行 + deep-review-round2.8.md 新档 + 七件套终稿。
- 下一入口：**Stage 3+ 规划轮**（§13.1 设计对齐 + §21.7 成熟度重核对 + 演进矩阵 Stage 3 行）——实施入口待用户行权（r79 先例）。

---

# v0.68.0 — Stage 2.7 步⑤ 收口：E5 批次 3 一次性移除（第一百零四轮 · r104）

**组成链目标面驱动**（E5 拆除前置——自举管道铁律：替代链完整证明先于拆除）：
`compile(expand(read(lex(S)))) == compile_ktf(expand_ktf(read_ktf(lex_ktf(S))))`
——`.krf` 组成链的 §9.87 三 junction 前馈公式，链程序全部换用五件 `.ktf` 孪生、组装
程序经生产桥（`ReaderFace::Target`）解析；输入 source 与全部 oracle 面不变（孪生实现
的就是 S-expr 读取链）。**`composed_target_chain.rs`**（driver）+ 17 项集成测试
（`composed_target_chain_tests.rs`）：anchors 端到端 + corpus 全量 sweep（85 案：
8 Read + 19 Expand + 56 Compile + **2 boundary**）+ 三 junction tamper 检测臂 +
VM-bracket 面 + **i64::MIN 数据边界发现**（目标词法面的正数域先于符号应用越界——
r103 例外账本「负字面量无正对应物」在 J2 注入数据面的实例化；bnd-002/bnd-003 两案
诚实分类为 harness boundary 行，语料面由算术组合孪生承载）。

**拆除判据终核**（SCF-A：自建替代 ≥ 被替换物 × 98%）：
- 语料面（selfhost 五件）5/5 = 100%（r100 三路门 + r101 fixpoint + r103 双口径）
- 生产链（driver 消费）：组成链目标面驱动 ✓ 本轮交付——缺口闭合
- 验收语料 85 = 测试数据面（1.4 冻结资产，保留）

**一次性移除执行**：
1. **五件 `.krf` 原件删除**（`selfhost/v1/{lexer,reader,macro,expander,compiler}.krf`
   ——生产链语料退役；种子链 S-expr Reader（Rust 实现）按混合自举宪制 BS-A 永久保留）
2. **driver 常量切换**：LEXER/READER/MACRO/EXPANDER/COMPILER_SOURCE 五常量退役；
   `.krf` 链驱动函数族（reader_parity / lexer_parity full-chain / expander_parity /
   compiler_parity / composed_full_chain / fixpoint .krf 面 / gate_b_elevated /
   gate_b_transitivity / dual_caliber / products_seed）退役；
   共享设施（decode/rebuild/prefix builders/oracle dump/drive_dual_engines）保留
3. **parity 测试重组**：六个 `.krf` 面测试文件退役（reader/lexer/expander/compiler
   parity + composed_full_chain + target_corpus_parity 孪生对比面）；
   determinism / fixpoint / stage_exit / selfhost_format / target_fixpoint /
   composed_target 切换 target 面（覆盖语义继承矩阵如实登记）
4. **audit 历史节迁移**：R/S/T/U/X/Y/Z 七节 + AD/AE/AF 的 seed 对照 case（104 case）
   块注释化为历史记录（append-only 账本）；live 基线 220/220（banner + 清单守卫
   机器双检）；gate_b_bytecode 重写为 target 链版

**六命令**：`cargo build --release` ✓ + `cargo check` ✓ + `cargo fmt --check` 零 diff ✓
+ `cargo clippy -D warnings` 零告警 ✓ + `cargo test --release` **1358:0:0**
（2 ignored 披露维持）+ audit 二进制 **220/220** ✓

# kerf release notes

## v0.67.0 — switch-window step 5: the two-skin corpus closeout (verification equivalence + the E5 teardown evaluation basis)

The r103 round delivers the switch-window step 5's verification
face (switch-window-plan §1 step 5; stage0.md §9.98): ALL 85
acceptance-corpus cases driven through BOTH skins, the gate-B
fixpoint dual-caliber gate over phases 2/3, and the teardown
evaluation's quantified basis — the E5 batch-3 removal decision's
evidence ledger.

**The mechanical skin transcoder** (`kerf-driver/src/skin_transcoder.rs`):
the general face — one S-expression program, rendered on the target
skin (the inverse of the §9.26.9 skin dictionary, form by form),
with the round-trip naming guard lifted from the step-3 prefix
twins to whole programs (the strict Stx face, or the expanded
alpha face where the grammar normalizes — the single-wrapped let
pair, the do fold). Shape-mismatched special forms ride the
ordinary call face (the shared expander rejects them on BOTH skins
at the SAME stage — the parity mechanism); genuinely unspellable
forms join the exception ledger (errors are data): negative
literals in expression position (the target lexical face composes
them; `i64::MIN` has no positive counterpart), non-binary operator
calls, and macro declarations (the rules carry raw list data the
target expression grammar cannot pass — the registered gap).

**The 85-case two-skin sweep** (`target_corpus_sweep_tests.rs`):
60 cases transcode mechanically and hold on both skins (the
expectation contract via `validate_target` — the target-skin twin
of the Stage 1.4 validate face; value cases additionally ride the
three gates: alpha-equivalence + one semantic bytecode + one value
face); 11 hand-twin cases carry the families the transcoder cannot
(the eight parse-error rejections as crafted malformed target
programs, the two `i64::MIN` boundaries as arithmetic compositions,
the two ruling-D symbol-require rejections as path forms); five
grammar-design divergences are pinned AS SPEC (the ruling-C12 unit
`()` -> nil, the three keyword-headed malformed forms whose
rejection stage differs by reader design — permissive versus
grammar-directed, the fn-wrapped handler arm that makes the
literal-handler class E0007 unreachable on the target grammar);
nine macro-declaration cases join the registered ledger. The
corpus-face coverage: 71/85 both-skins (83.5%), every exception
accounted for by family.

**The gate-B fixpoint dual-caliber gate**: phases 2 and 3 of both
fixpoint drives, cross-skin. Phase 3 (the executed self-compiled
products) holds the FULL semantic digest; phase 2 (the self-applied
compilations) holds the FUNCS face with the coordinate exemption —
the round's own finding: the self-applied input embeds the item
records' span coordinates as quoted constants, so the two skins'
products legitimately differ in their constant pools (two source
texts, two coordinate sets) while the compilation logic agrees —
§9.25.4's cross-grammar layering applied to the fixpoint's
self-application phase.

**The E5 teardown evaluation basis** (switch-window-plan §5.6): the
production chain's replacement coverage (the five .ktf twins at the
three gates since r100, the target fixpoint + gate-B transitivity
since r101, the dual-caliber phases 2/3 this round) and the corpus
face's quantified ledger (71/85 both-skins, 14 registered
exceptions by family) — the batch-3 one-time removal decision's
criterion computation (self-built replacement >= 98% of the
replaced surface, or extra capability > 0) with the composed-chain
target drive registered as the remaining production-chain
verification item before the .krf originals' teardown.

Tests 1496 -> 1512 (+16: the sweep's ten, the transcoder's six
unit faces); audit 314 -> 324 (AF — the step-5 family, ten cases);
the six-command cold run all green.

## v0.66.0 — switch-window step 4: the target fixpoint (production bridge + gate B transitivity)

The r101 round delivers the switch-window step 4 (switch-window-plan
§1 step 4; stage0.md §9.30.4 SCF-A: "the target-syntax Reader
compiles itself") — the fixpoint precondition of the step-5
equivalence close-out:

- **The production bridge**: `pipeline::parse_target` (the NEW
  reader feeding the shared intern → read → expand → load spine —
  `ReaderFace` parameterizes `drive_dual_engines`, one harness
  skeleton, two skins) + `read_target_source_for_bootstrap` (the
  bootstrap front end's target face) + `ktf_compile_rich[_vm]` (the
  target twins of the rich compile drives).
- **The target fixpoint**: `fixpoint_selfhost_compiler_target` — the
  `.ktf` compiler twin, read through the bridge, compiled by itself,
  EXECUTED, reproduces its own compilation byte-for-byte
  (C_t(C_t(S')) == C_t(S'), SOP §21.3 (2) on the target skin — the
  same-syntax-chain caliber).
- **Gate B transitivity**: `gate_b_transitivity_target` — gate B on
  both skins + the r100 corpus parity ⟹ the two skins'
  SELF-compilations project to one `SemanticDigest` (§9.25.4's
  cross-skin layering: `debug_info` excluded; the ruling-H local
  renames absorbed as slots).
- **A P0 reader fix the bridge itself uncovered**: the target
  reader's datum parser leaked one depth level per SUCCESSFUL
  bracket (the guard was released on error paths only) — sequential
  record brackets accumulated, and the compiler twin's item stream
  (200+ flat records) tripped the 256 nesting cap with zero real
  nesting. Fixed with the release on every path; the regression is
  pinned at the reader unit face, the audit face (AE3), and the
  guard family.
- Tests 1485 -> 1496 (+11: 10 target-fixpoint gates, 1 reader
  regression); audit 304 -> 314/314 (the AE section — the fifth
  two-letter section); the B-axis rerun holds (B7 +0.66%, B8 +0.13%
  — in-band), and the new **B10 target-skin fixpoint cost axis**
  lands at **1.04x** the seed-skin B8 (the <2x question the risk
  register carries). Environment notes unchanged: root-tree cargo
  test needs RUST_MIN_STACK=16M; the audit's deep-stack thread runs
  at 1024 MiB.

## v0.65.0 — switch-window step 3: the corpus twins (C-class 5/5)

The r100 round delivers the switch-window step 3 (switch-window-plan
§1/§5.4): the five `selfhost/v1/*.ktf` target-skin twins of the
`.krf` corpus, each through the three-gate parity contract —
semantic-projection equality, VM behavioral equivalence over every
global, and expansion-gate alpha-equivalence (ruling H). The .krf
originals stay untouched as the parity oracle (the parallel-file
strategy, retained until step 5).

- **E5 batch 2 — the Lisp-name retirement** (ruling E2): the builtin
  table (`first`/`car`, `rest`/`cdr`, `pair`/`cons`, `eq`/`eq?`) plus
  the two general one-way rules — the predicate segment (`is_` ->
  `?`-suffix) and the interior separator (`_` -> `-`; the blank
  marker family passes through verbatim).
- **The quote datum carrier** (ruling F): the tuple skin of pattern
  position extended to quoted data — record tables ride
  `quote((d1, d2, ...))`; the one-element list rides the Rust tuple
  trailing comma; `()` is fail-closed (`nil` is the datum face of
  the empty list).
- **The call-form carriers** (rulings G/I): `set(...)` for
  expression-position assignment; `do(...)` for tree-exact
  multi-statement sequences (the block fold's chained Lets differ
  from the flat do's multi-binding Let at the tree level — the r98
  "nested do == flat do" claim holds at the bytecode face only,
  corrected this round).
- **The driver's target-side harness**: the four injection prefixes'
  target twins (single-source data, transcoded skin, round-trip
  naming guard through the real reader).
- Tests 1463 -> 1485 (+22: 9 reader units, 3 seed parity, 10 corpus
  gates); audit 294 -> 304/304 (the AD section — the fourth
  two-letter section); the five .ktf twins join the selfhost
  formatting guard. Environment notes unchanged: root-tree cargo
  test needs RUST_MIN_STACK=16M; the audit's deep-stack thread runs
  at 1024 MiB.

## v0.64.0 — switch-window step 2: the lexical/syntactic batch

The r99 round delivers the switch-window step 2 (switch-window-plan
§5): six adjudications — five core mappings and five E5 exemptions —
plus the match desugaring, the use-path form, the E5 batch-1 name
skin, and the annotation-generic drops.

- The step-2 adjudication record (switch-window-plan.md §5, v1.1):
  core mappings = match_expr + the pattern family (ruling A — the
  classification sugar per the §9.26.8 kernel mapping), the use-path
  single-path form (ruling D — the C-C1 `/`-joined module name), the
  E5 batch-1 kebab→snake skin (ruling E — an explicit two-entry
  table: `read_line`/`write_line` land on the kebab Stage 0 globals
  verbatim), the adt_type generic-argument drop (ruling C1 second
  half — annotation surface); E5 exemptions with registered faces =
  the four type declarations (no datatype carrier in HM `Type`/`Value`),
  the fn-head tick-form generics (no lexical token — a registered
  gap), `where` clauses (not among the 22 finalized word faces — the
  v9.8 grammar/lexis misalignment registered), `as`/`..`/field/index
  (no kernel carrier). Every exemption fails closed with its
  registered form name — never silence.
- The match special form (kerf-expander): `(match scrutinee (pattern
  body)+)` desugars to the carrier-let + concentrated-test chain —
  the identity principle (switch-window-plan §5.2): the product
  equals the hand-written `(let ((s e)) (if <test1> ... ))` chain
  over the same shapes. The carrier rides a `(`-anchored spelling
  unwritable on both source faces (hygiene without gensym); the
  exhaustiveness gate (ruling A′) requires an irrefutable tail arm —
  `ExpandError::NonExhaustiveMatch` (report over silence: the kernel
  has no match-failure effect). The pattern family: numeric literals
  via `=`, bool/string literals via `eq?`, `nil`/`()` via `nil?`,
  `_`, bare bindings (fresh-scope colored, shadowing by design), and
  the two-element tuple via `pair?`+`car`/`cdr` (the `Type::Pair`
  two-ary isomorphism); guards, or-patterns, variant/struct
  patterns, `@` bindings and 3+-tuples are registered faces that
  fail closed.
- The target-skin reader (kerf-reader/target.rs): `match e { p =>
  { b }, ... }` (the v9 match_arm block body, the mandatory trailing
  comma per the handle-arm discipline), the pattern parser (literals
  / `mut x` / `()` / `(p)` / `(p, p)`), `use a::b::c;` →
  `(require "a/b/c")` (module names ride the raw segment text — the
  module namespace is not the value namespace the skin maps), and
  the E5 batch-1 skin at the token face. Use trees, `as` aliases,
  guards and or-patterns reject with their registered form names.
- Audit AC section (examples/audit): ten cases — the match parity
  anchor, the literal fallthrough, the tuple destructure, the
  exhaustiveness gate, the registered pattern faces, the use-path
  parity, the E5 skin landing (the kebab globals verbatim), the
  annotation-generic drop, the registered non-mapping faces, and the
  nested-carrier hygiene face. AUDIT PASS 294/294 (284 + AC10); the
  AB6/AB8 r98 pins updated to the r99 semantics; the audit
  deep-stack thread resized 64→1024 MiB (an environment calibration
  — the sandbox per-frame demand pushed the r98 sizing below the
  measured floor). Running the root test tree on this sandbox needs
  RUST_MIN_STACK=16M (the deep-tree case's thread stack).
- Tests 1463:0 (from 1448: +18 new — 5 reader-skin units, 5 expander
  match units, 6 cross-skin integrations, 2 audit-guard updates; -3
  r98 seed-boundary cases superseded by the core mapping); the six
  commands all green on both profiles.

## v0.63.0 — stage 2.7 window opening: the target-skin reader seed

The r98 round opens the Stage 2b syntax-replacement window and
delivers the five-step process's step 1 in the same round.

- The window-opening adjudication (switch-window-plan.md §0): the
  #15 gate signals all read full — the EBNF v9 final draft (§9.26),
  the skin dictionary mapping base (§9.26.9), the Stage 2a closeout
  quality signals (the r92 three-criteria verification), the parity
  verification base (§9.25.4 BS-C), and zero bootstrap-chain risk
  (the seed is a parallel addition, never a replacement) — and the
  user's advance-per-plan instruction completes the double premise.
- The B2 three-option ruling (§9.42.4, P1) lands as option 1:
  `if`/`perform`/`handle` take expression positions at the primary
  face — the kernel's expressiveness, the Koka/OCaml 5/Rust
  precedents, and the skin dictionary's completeness requirement
  (option 3 would break parity verification on nested-effect
  corpus).
- The step-1 seed ships as `kerf-reader`'s target module: the v9
  Level 0 parity subset — items (`fn`/`module`/`use`, the call-form
  rule where `define(n, e);` and `quote(x);` ride the ordinary call
  mapping with zero special cases), statements (the do/let fold
  with the multi-binding comma form of the r110 ruling, assignment,
  block tails), the full §9.26.4 precedence cascade with the
  operator skin (`==` -> `=`, `!=` -> `(not (= ..))`, `&&`/`||` ->
  short-circuit `if` desugars, unary `-`/`!`), closures, the effect
  face, the C-C1 separator mapping (`a::b` -> `a/b`), the C12 unit
  skin (`()` -> `nil`) and the whole v9 lexical layer (radix ints,
  `_` separators, the `\u{...}` escape family, nested block
  comments).
- The §9.25.4 parity contract, as ruled (the semantic-safety-net
  layering): the same program in the two skins produces the
  identical *semantic bytecode projection* — per-function shape and
  instruction streams, the constant pool, the global table; the
  `debug_info` spans encode where in each skin and are excluded —
  plus identical runtime values. Byte-level comparison including
  debug_info stays reserved for the same-syntax fixpoint faces.
- The seed-scope boundary rejects fail-closed with a dedicated
  error variant (`UnsupportedTargetForm`): struct/enum/type/effect/
  capability declarations, match and the pattern family, generics,
  where clauses, casts, ranges, field/method access, indexing, the
  `halt`/`pass` handler bodies and the use path form — every one a
  registered step-2 obligation in the switch-window plan, never a
  silent acceptance. Three more error variants join the shared
  `ReadError` surface (unclosed/stray target delimiters, unexpected
  token), all four following the R8 message conventions and pinned
  verbatim by the audit.
- Verification: the 256 nesting cap covers the target delimiters
  exactly as the S-expression list cap does; audit AB lands as the
  second two-letter section (274 -> 284, all green); the reader
  crate grows 35 unit tests and the root tree 8 integration tests
  (three parity anchors, the pipeline run, the module/use faces,
  the boundary sweep, the lexical error family, the expander-gate
  parity). Tests 1448:0:0 (the two #[ignore] disclosure faces
  maintained); build 12.21s; fmt zero diff; clippy -D warnings
  clean; the workspace version chain carries the ds08 golden.

Next entry: the step-2 lexical/grammar batches (match + patterns,
the type-declaration carrier ruling, the E5 name batches) toward
the step-3 corpus translation (the four selfhost pieces in the
target skin, the three-way semantic-projection gate per piece).

## v0.62.0 — stage 2.6 close-out: the Stage 2a exit criteria verified in full

The r92 round closes the 2.6 window and with it Stage 2a: all three
exit criteria of SOP §21.3 (Stage 2 row) are cross-checked against
three evidence sources each — code-state audit trails from the
delivery rounds, the standing machine-checked tests, and fresh
cold-run replays executed this round.

- Criterion (1), the whole compiler in kerf: the five selfhost
  pieces riding the complete .krf chain — the r84 function-level
  mapping (33 Rust functions to 83 kerf defines), the r88
  generation bookkeeping on the product side, and the standing
  composed-chain + fixpoint + elevated-gate-B suite, all re-run
  green this round.
- Criterion (2), the fixpoint: C(C(S)) == C(S) byte-for-byte
  (delivered r88), re-confirmed with B8 in band at 3614.539ms
  (+0.001% vs the r89 first record; 164x the B7 composed chain).
- Criterion (3), a working non-VM backend: the C transpilation
  backend — the corpus C replay re-run this round at 41/41 via the
  #[ignore] explicit face, audit AA maintained at 274/274, and the
  B9c measurement re-run in band (emit median 7.2µs, cc -O0 build
  83.6ms, the C binary running fib(25) in 23.906ms — about 3.3x
  the VM's ~79ms).
- One formatting drift left in the r91 delivered tree
  (test_infra_guard_tests.rs — the two-letter-section assertion
  line exceeded the line width and had been edited after that
  round's final fmt check) was caught by this round's cold-run
  discipline and repaid in-round: cargo fmt, +5/-1, zero semantic
  change.
- The nine signals hold at 8/9 for the Stage 2a caliber (the
  ninth — cross-stage deep verification — is the 2.8 closer's);
  the seven-piece Stage 2 skeleton takes its 2.6 write-back rows
  in all seven files. Tests 1405:0:0 maintained, all eight B axes
  in band (B4 bitwise for the eighteenth consecutive run).

Next entry: the 2.7 syntax-replacement window evaluation — gated
by the #15 signal (zero-signal-no-open holds; the EBNF v9 final
draft and the skin dictionary mapping are in place, the five-step
window procedure is registered, and both the signal check and the
user's explicit go-ahead remain the double precondition).

## v0.61.0 — stage 2.6 first cut: the C transpilation backend lands

The r91 round delivers the working position of exit criterion (3)
("at least one non-VM backend works — chain-external, optional"):
the C transpilation backend, in the three layers the r90
adjudication II named. The backend is constitutional by
construction — chain-external, never part of the bootstrap chain:
building the kerf compiler never invokes a C compiler, and every
cc-gated verification face skips with disclosure (never fails) on a
cc-absent host.

- `kerf-cbackend` (the 12th workspace crate, a pure consumer leaf
  of the frozen bytecode product): the bytecode->C emitter. Every
  proto becomes one C function with a STATICALLY addressed operand
  stack (the depths ride the same DAG walk `Bytecode::verify` runs
  — no stack pointer exists in the generated code), jumps become
  gotos, and one generated trampoline `k_call` dispatches closures
  and builtins (the single-adapter discipline). Constants are
  total-determinism: floats as u64 bit patterns (zero decimal
  text), strings as hex byte arrays, pair shapes as post-order
  literal trees materialized exactly like `Value::from_literal`.
- `kerf_rt.h` (the embedded host runtime shim, C11 + POSIX): the
  16-byte value model, a monotonic byte arena (no GC in the first
  cut — the registered fork keeps the same fail-closed budget
  semantics as a collector-less VM), the single-source 18-builtin
  dispatch (a new Rust builtin is a compile error until the shim
  grows its arm), the handler stack, and the Rust-parity float
  display (a portable shortest-round-trip search: `%.*e` + strtod
  read-back, plain-decimal rendering, `inf`/`-inf`/`NaN`/`-0`).
- cc-gated e2e + audit section AA (264 -> 274): the full corpus
  replays through the C backend — 41/41 execution cases agree with
  the VM byte-for-byte (value cases ride a check-wrapped epilogue;
  runtime-error cases fail closed on both engines); the float
  battery pins the display parity on the hardest twelve (including
  the minimum positive subnormal); the budget and host-stack depth
  guards fail closed under `-DK_BUDGET` / `-DK_DEPTH_CAP` overrides.
- `kerf emit-c <file>` — the driver face (same-round wiring): one
  self-contained C file on stdout; `cc prog.c` is the whole build.
- B-face first numbers: emission cost median 7.4us (about one
  compile of the same program); the cc-compiled fib(25) runs
  -O0 3.2x / -O2 6.4x faster than the VM engine.

Six commands green at 1405:0:0 (+36 tests; the two `#[ignore]`d
heavy faces — the corpus C replay and the B-face measurement — are
explicit-run by design); audit 274/274; the B axes all in band
(B4's deterministic counters bit-identical for the seventeenth
consecutive run). Eight-primitive invariance holds for the
sixty-fourth round — the backend consumes the frozen opcode and
builtin tables, adds no primitives, touches no VM code.

## v0.60.0 — stage 2.6 evaluation window: three adjudications, the seven-piece skeleton

The r90 round opens the 2.6 window (the Stage 2a close-out
evaluation) with its design-alignment face. Zero production crates
are touched; the deliverables are three adjudications, the Stage 2
seven-piece skeleton, and the nine-signal check at the Stage 2a
caliber.

- Adjudication I — build orchestration stays on its Rust bootstrap
  footing. The mission itself assigns the build bootstrap to the
  ~20% Rust share of Stage 2 (SOP §21.1/§21.4), rewriting the
  build system in kerf is a Stage 3+ acceptance item (§21.3 (2)),
  and the measured budget shape (B7 x file count + B8 x stage
  count) shows the VM execution phase dominating at over 98% — a
  `.krf`-side orchestrator would itself run on the VM, cost more,
  and gain nothing semantically (the flat-five-files argument: no
  module system, no semantic gain). The Rust face assembles and
  drives — the very definition of build bootstrap — while the
  compilation chain itself is fully `.krf` and byte-verified by
  the fixpoint pin.
- Adjudication II — the non-VM backend route is **C
  transpilation** (criterion (3)). Four grounds: zero external
  binary dependency (text emission with the host cc, versus a
  vendored QBE or a PATH assumption — the §18 discipline and the
  T29 frozen-DAG precedent); maximal portability (the §21.2
  strategy map); the FFI face synergy (criteria (3) and (4) share
  the C-ABI boundary); debuggability (readable C, tunable cc
  optimization levels, standard debuggers). QBE moves to a Stage
  3+ registration; Cranelift stays a registered research option.
  Constitution reaffirmed: the C backend never enters the
  bootstrap chain. The implementation (the bytecode-to-C emitter,
  the host runtime shim, the cc-gated end-to-end verification, the
  AA audit node) is handed to the next round as the 2.6
  implementation first knife.
- Adjudication III — the FFI ownership model is pre-adjudicated
  (the criterion (4) blocker, cleared at the design level). Four
  rules: R-F1 eager materialization at the boundary (no lazy
  crossing, no cross-boundary heap references); R-F2 caller
  ownership with return-value transfer (the kerf side takes the
  GC root immediately); R-F3 explicit handle roots for foreign
  code holding kerf values across allocations (the JNI global-ref
  shape; local borrows die at frame return); R-F4 C-ABI alignment
  (no name mangling, no pass-by-value structs — pointer plus
  length, or handles). Anchors: the Rust FFI ownership discipline,
  JNI's two-tier references, the WASM copy boundary, the Lua C
  API stack discipline; the CPython borrowed/owned reference
  model is registered as the counter-example kerf does not follow.
- The Stage 2 seven-piece skeleton lands (architecture review,
  design-impl-test coverage, hidden problems, refactoring
  optimality, performance baseline, final assessment — six files
  under develop/v2/stage-2/ — plus the pipeline-test-coverage §9
  section), each carrying a current-state baseline and a 2.8
  final-draft duty table, following the 1.8 skeleton-to-1.9
  final precedent.
- The nine signals at the Stage 2a caliber: 8/9 checked — the
  ninth (cross-stage deep verification) belongs to the 2.8 closer.
- Verification: the six commands cold-run green with tests
  1369:0:0 maintained and audit 264/264 maintained (an
  evaluation round adds no audit cases — the r87/r89 precedent);
  all eight B axes in band (B4 bitwise-identical for the
  fifteenth consecutive run; B8 at 3616.890ms, +0.07% vs the r89
  first record); the ds08 version-gold chain advances to 0.60.0.

## v0.59.0 — stage 2.5 close-out: the exit criteria verified, B8 lands

The r89 round closes the 2.5 window (fixpoint C) by verifying its
exit criteria in full and landing the fixpoint cost axis.

1. **Exit criterion (1) verified — the whole compiler written in
   kerf.** All five selfhost pieces (lexer 473 / reader 117 /
   expander 750 / macro 660 / compiler 1257 lines) ride the
   complete `.krf` chain — the composed chain (r86) and the
   fixpoint tests (r88) as the standing evidence; the tree face
   (compile.rs's 33 functions mapped onto compiler.krf's defines,
   100% at r84) and the product face (the trailing-generation
   addendum at r88) are both complete.
2. **Exit criterion (2) re-proven and machine-pinned.** The
   fixpoint test keeps asserting `b_self_exec == b_self`
   byte-identical; the new B8 axis now fails closed on every run —
   the equality is the axis's precondition, never its output.
3. **B8 — the fixpoint-driver cost axis.** The whole three-phase
   proof (C(S) dual-engine, C(C(S)) over the self-applied assembly
   on the VM-only bracket, the executed self-compiled compiler
   reproducing its own compilation), measured: **median
   3614.497ms / stdev 35.608ms over 7 iterations — the fixpoint
   proof costs 165x one composed-chain run (B7's 21.9ms).** The
   2.6 build-orchestration evaluation consumes this number as its
   bootstrap-verification budget floor: B7 x files + B8 x stages
   is the total self-hosted-build budget shape. The perf guard
   pins the axis and its fail-closed assertion (the T38 lesson
   institutionalized, second instance after B7).
4. **2.6 pre-entry registered.** The next window is the Stage 2a
   close-out evaluation: the build-orchestration `.krf`-side
   assessment, the non-VM backend evaluation window (QBE or a C
   translator — off-chain, never in the bootstrap chain), the FFI
   ownership-model pre-adjudication (criterion (4)'s blocker),
   audit section X, the Stage-2 seven-piece set, and the nine
   signals on the Stage 2a reading.

No production crate touched — tests 1369:0:0 maintained, audit
264/264 maintained, all eight B axes in band (B4's gc 1 /
swept 1023 bitwise-identical for the thirteenth consecutive run).

## v0.58.0 — stage 2.5 first knife: the self-application fixed point

The r88 round opens the 2.5 window (fixpoint C) and lands its
three opening MUVs in one delivery — **SOP §21.3 exit criterion
(2) is now satisfied: compiling the compiler with itself twice
yields identical bytes.**

1. **The trailing-generation addendum.** The CP-1 flat record
   stream now carries each node's expansion generation as a
   trailing int (source records ride 0, macro products
   use_gen + 1 — the 1.7 record lineage). The `.krf` stream
   assembler re-positions it to the LAST field of every assembled
   record (payload and child positions unchanged — zero accessor
   migration), the debug products land `(s e gen)` triples, and
   the dump text stays generation-free (the parity family
   convention holds — the dump parity is byte-identical with the
   addendum in).
2. **`rebuild_bytecode` (MUV ①).** The `.krf` compiler's heap
   product rebuilds into a real `Bytecode`: the opcode kebab
   reverse table (`Opcode::from_kind_name`, the single-source
   pair with `kind_name`), full-field protos (names through the
   mangled-name decoder, captures, instruction streams, debug
   spans WITH their generations), the interned globals, and the
   const pool through the shared literal decoder — gated by
   `Bytecode::verify` (a rebuilt product is a loadable program
   or an error, never a half image).
3. **The fixpoint driver (MUV ②).** Three phases: `C(S)` — the
   `.krf` compiler compiles its own structural source (dual
   engine, rebuilt); `C(C(S))` — the assembled self-applied
   program (its own items baked ahead of the compiler source) is
   compiled by the `.krf` compiler itself (the VM-only bracket —
   the self-embedded datum rides past the evaluator's depth
   envelope, the r85 disclosed-bracket lineage); **execution** —
   the rebuilt `b_a` runs in the VM and its `result` (the
   compilation of the baked input computed by the EXECUTED
   self-compiled compiler) rebuilds byte-identical to the direct
   run: `b_self_exec == b_self`.
4. **The elevated gate B (MUV ③).** `gate_b_elevated`: the
   `.krf` side swapped from "the Rust compile of the `.krf`
   expander's tree" to "the `.krf` compiler's own product,
   rebuilt" — structural bytecode equality over the whole
   acceptance corpus (the eligible floor holds).

Tests 1358 → **1369:0:0** (eleven fixpoint tests: the reverse
table, the rebuild on the generation axis, six fail-closed
malformed-product negatives, the elevated corpus sweep, and the
fixpoint itself). Audit **264/264** (Z17-Z24: the eight-case 2.5
family — the fixpoint itself runs as Z24 inside the audit's
deep-stack thread). The 2.4 dump parity is untouched (the
generation rides outside the text); the selfhost README gets its
five-piece normalization (the consumption table, the test table,
and the lexer's four tamper anchors — doc-drift findings from the
r88 chain re-review, fixed in place).

Next entry: the 2.5 close-out evaluation (the full exit-criteria
checklist, the B8 fixpoint-cost axis as a calibration candidate,
and the 2.6 build-orchestration window).

## v0.57.0 — stage 2.4 closed: the three-criteria close-out and the B7 measurement axis

The r87 round closes the 2.4 window (fixpoint B) with the three
exit criteria adjudicated against the code reality:

1. **The gate-B promotion slot moves to 2.5.** The `.krf`-side
   swap of `gate_b_bytecode` (a `rebuild_bytecode` that turns the
   `.krf` compiler's heap product into a real `Bytecode`, the
   opcode-name reverse table, and the Bytecode-`PartialEq` gate)
   has zero consumers inside 2.4 — the window's acceptance
   (per-pass bytecode equality across the full pipeline) was
   already demonstrated by the r86 composed chain plus the
   dump-faithfulness witness. The swap is the OPENING MUV of 2.5:
   the fixpoint C(C(S)) requires the product to be runnable, which
   is exactly what the rebuild provides. The hand-off list is
   registered in stage-2-plan §2 row 2.5 (the product's
   instruction records carry `("op-name" a b)` triples — the
   reverse table is the one new table).
2. **The composed-chain cost axis lands as B7.** The full
   self-hosted pipeline (lexer.krf + reader.krf, expander.krf,
   compiler.krf — dual engines at every junction) over the same
   FIB anchor as B1: median **21.937ms** (stdev 0.142ms, 9
   iterations), a **self-hosting multiplier of 3081x** against
   B1's 7.1µs Rust pipeline. The axis fails closed — every run
   must report `matched` (a benchmark over a drifting chain is
   meaningless), and the perf-observability guard now pins both
   the axis label and the fail-closed assertion (the T38 lesson
   institutionalized: measurement obligations get machine checks).
   The number is the Stage 2a cost story's baseline — 2.5's
   fixpoint driver and 2.6's build-orchestration evaluation both
   consume it.
3. **The drift ledger baselines.** The 8/19/58 routing counts
   (test-pinned since r86) enter the calibration register as row
   T2.4-2 — the measured number and the machine-checked assertion
   ride together, the B4 pattern.

No production crate is touched: the round is an evaluation plus a
measurement face (bench example + guard extension + documentation
family). Tests hold at 1358:0:0, audit at 256/256, all seven B
axes in band (B4's gc-cycles 1 / swept 1023 bitwise-identical for
the eleventh consecutive run). The eighth-primitive invariance
holds for the sixtieth round (B7 is a harness measurement face —
zero freeze-surface change). **2.4 is closed; the next entry is
2.5 — fixpoint C, the self-application fixed point.**

## v0.56.0 — stage 2.4 first knife: the full composed chain and the drift ledger (fixpoint B opens)

The r86 round opens the 2.4 window (fixpoint B — dual-compiler
equivalence verification) with the composed chain made FULL: the
2.4 formula `compile(expand(read(lex(S)))) ==
compile_krf(expand_krf(read_krf(lex_krf(S))))` now verifies as ONE
chain, junction by junction, with the `.krf` chain's OWN products
feeding forward at every junction — the junction re-encoder
(`rebuild_read_forms`) rebuilds the `.krf` reader's forms and feeds
them into the expansion layer (never the oracle's intermediates,
the honest fixpoint direction), the `.krf` expander's rebuilt items
feed the `.krf` compiler, and the final product faces the oracle
full pipeline through the CP dump grammar.

The routing is TOTAL — the drift ledger: every corpus file lands in
exactly one row (8 reader-layer rejections verify on junction 1's
error axis, 19 expander/loader rejections on junction 2's, 58
compiler-layer files ride the full formula), with the counts
PINNED BY TESTS so corpus growth must move the ledger with it. The
seventh self-application lands as the strongest fixed point yet:
lexer.krf's own source, read from its byte table by the lexer
itself, expanded and compiled entirely by the `.krf` chain, against
the oracle full pipeline. All five selfhost pieces ride the full
chain. Tamper probes at all three junctions prove the chain fails
LOCALLY (a tampered lexer never falls through to the expansion; a
tampered expander never reaches the compiler). The empty and
comment-only sources ride as `(quote nil)` stream prefixes (the
empty-product ledger row). The gate-B promotion witness closes the
round: the analysis-dump grammar is a faithful image of the
`Bytecode` semantics (nine field-mutation probes, every one visible
in the dump) — dump equality implies bytecode equality, the
precondition the 2.5 window registers for gate B's full-pipeline
dual-track.

Verification: six commands all green (fmt zero-diff, clippy
`-D warnings` clean, tests 1358:0:0 — 1343 baseline + 15 net-new),
audit 256/256 (section Z extended 6 -> 16), the B axes in-band
with B4's deterministic counters bit-identical for the tenth
consecutive run, zero open tech-debt items, and the 8-primitive
invariance verified for the fifty-ninth round (zero freeze-surface
change — the junction re-encoder is harness-side only).


## v0.55.0 — stage 1.5 second segment: the lexical layer lands (the reader bootstraps complete)

The r85 round re-audits the reader stage from the bootstrap start
(63-a) and closes the one open item the audit found: the lexical
layer. The 1.5 expressiveness audit had anchored lexical
reachability on string inspection primitives (the K21 window) and
missed the byte-table route — the RS-1 source-injection channel
generalized from token records to one integer per byte
(`(define source-bytes (quote (104 101 ...)))`), which expresses
every lexical decision in plain integer arithmetic: zero new
primitives, zero freeze-surface change. `selfhost/v1/lexer.krf`
mirrors the Rust lexer exactly (the §9.71 post-RDR semantics):
trivia and the BOM anywhere, the multi-byte Unicode whitespace
table, the fail-closed reject set, maximal-munch atom runs, `#t`/
`#f`, the integer face with a 19-digit threshold guard so both
overflow faces fail closed without ever trapping the checked
arithmetic, the f64 grammar as a byte automaton, the Symbol floor,
and the five-escape string literals with raw newlines. The
permanent host layer keeps exactly the two inexpressible transforms
(K20): the f64 VALUE face (parse and the is_infinite overflow
rejection — no variable-precision arithmetic in the subset) and the
string payload decode (no string construction). The unchanged
structure layer (`reader.krf`) consumes the `tokens` binding, so
the full chain is bytes -> lexer.krf -> reader.krf; the harness
(`lexer_parity.rs`) checks it against the Rust reader oracle on
three axes — the token stream (drift localizes to the record), the
tree, and the error key — on both engines, with the VM bracket face
for the past-envelope fixed points (the reader's own header comment
block is one ~2.4k-byte trivia run; `lexer.krf`'s own source rides
~3k tokens — both past the evaluator's per-element budget, honestly
classified per the r74 K165/K166 discipline). The corpus sweep runs
all 85 files through the full chain (the deep nesting pair rides
the VM bracket); four drift detectors prove the tamper probes are
caught (the escape set, the VT terminator, the i64 threshold, the
U+3000 whitespace entry); audit section R grows from ten to twenty
cases (246/246); tests 1321 -> 1343:0:0. The reader stage is now
fully bootstrapped under the pipeline discipline (structure AND
lexical decisions self-hosted); the 2.4 dual-compiler equivalence
window is the next entry.

## v0.54.0 — stage 2.3 closed: the composed chain (the fixpoint precondition demonstrated on anchors)

The r84 round is the 2.3 close-out evaluation: the compile-time
pure-function surface of `compile.rs` is reconciled function by
function against the two-Pass `compiler.krf` (33 functions → 83
defines, the thirteen record forms plus seven synthesized walk
modes, the 25-opcode stack-effect table arm-aligned) — 100 percent
coverage, zero gaps, zero degradation — and the close-out is cashed
in as the composed chain (CP9): the 2.4 formula
`compile(expand_oracle(S)) == compile_krf(expand_krf(S))` verified
as ONE chain on anchors, not by pieced-together transitivity. The
assembled `.krf` expander rebuilds the item tree (asserted
structurally identical to the oracle's through `ModuleItem:
PartialEq` — the 1.6 criterion carried in-chain), and the `.krf`
compiler then consumes THAT tree directly; the products compare
against the oracle full pipeline through the same dump grammar as
every CP face.

The strongest anchor is the sixth self-application — the first
through the full `.krf` chain: compiler.krf's own tree, expanded by
the `.krf` expander and compiled by the `.krf` compiler, byte-for-
byte against the Rust full pipeline. The CP9 family carries five
tests (the positive anchors across the fn-sugar / capture-order /
transitive / effects / let-shadow faces, the selfhost fixed points
through the chain, the LA-7 assign-boundary error axis, the
58-file compiler-layer corpus sweep, and the front-end tamper
probe — a tampered expander depth guard must fail the chain with
the front end's rejection named). Audit section Z mounts the six
composed-chain cases (230 → 236/236, sections A..Z); the guard
family grows by five (1316 → 1321:0:0).

Environment layer: the sandbox's third reset was recovered from
the session-upload package (depth-1 fetch of the latest commit,
local baseline re-seeded), the toolchain moved to 1.99.0, and the
audit example's main-thread 8 MiB default — below the new
toolchain's frame demand on the eval-depth face — was cured with
the §9.84.1-lineage deep-stack thread (the audit body moves onto a
64 MiB thread; production crates untouched).

With the close-out conditions met on all three faces (the function
map, the two-Pass code-axis parity, and the composed chain), stage
2.3 closes: the fixpoint window's A phase is complete. The next
entry is the 2.4 dual-compiler equivalence window — the composed
chain generalized corpus-wide, the differential-convergence
discipline, and the gate-B upgrade evaluation.

## v0.53.0 — stage 2.3 second Pass: the instruction emission rewritten in the frozen subset (the code axis joins the parity)

The r83 round extends the fixpoint window's A phase to the emitter:
the compiler's instruction emission — the single emit path with the
opcode stack-effect table (pops/pushes per kebab name, `call` pops
the arity plus the callee, `perform` pops its argument count), the
jump backpatching discipline (the placeholder sentinel rides in
`a`, the source depth in `b`, both restored to the zero-operand
output contract by patch — the Lua patchlist lineage, K198), the
explicit else-entry depth reset, the tail-position terminator
contract (`ret` inside closures, `halt` in the entry, a tail If
compiles its branches straight into the terminator with no merge
jump), the dense per-instruction `debug_info` table (one span per
emit — K201) and the finish-time placeholder drain (no unresolved
references in the finished product, K199) — is rewritten in the
frozen kerf subset itself.

The parity products now carry every proto's full instruction stream
(`code`) and dense span table (`dbg`) in the same dump grammar
(K196/K203, the translation-validation shape extended from the
analysis products to the emitted code): creation order, first-use
orders, descriptor sources, the const-pool identity, the complete
instruction sequences with patch-resolved jump targets, and the
per-instruction offsets — byte-identical against the Rust oracle on
both engines, corpus-wide (the sweep stays pinned at reader 8 /
expander 19 / compiler 58 of 85) and at the selfhost fixed points.

The emission defenses mirror the oracle's fail-closed family —
`stack-underflow`, `stack-imbalance` and `unpatched-jump` rebuild
through the oracle's own Display as readable drift (they fire only
on a broken emitter); `bad-patch` and `bad-node` classify as
harness defects. The spans keep the parity family's offset-pair
convention (expansion ids stay outside the comparison text, owned
by the 1.6/1.7 faces).

The fifth self-application: compiler.krf (1221 lines — the analysis
Pass plus the emitter) compiles its own expanded tree, every code
section byte-identical on both engines. Audit section Y mounts the
ten emission-family end-to-end cases (230/230, A-Y); the new CP8
test family pins the emitter's discipline at hand-computed shapes
(terminator contracts, merge-jump patch targets, eval order, slot
lifecycle, the assign dup form, effect operand shapes, closure
protocol indices, const-slot identity, the zero-code anchor halt,
the dense debug table, and the code-axis drift detector) — guards
+13 → 1316:0:0.

The round also carries the sandbox-recovery stack guards: the new
environment's 8 MiB default test-thread budget sits below the
evaluator's native 2048-deep recursion needs (measured between 8
and 12 MiB), so the depth-cap fixtures, the R8-message depth leg,
the runtime depth boundary and the audit's H08 case ride explicit
deep-stack threads (the r74 BST-1 lineage applied to the runtime
and audit faces) — production code untouched, and B4's counters
stay bit-identical for the eighth consecutive run.

## v0.52.0 — stage 2.3 fixpoint window opening: the compile-time lexical-domain analysis rewritten in the frozen subset (the first Pass, CP-1..CP-7)

The r82 round opens the fixpoint window's A phase: the compiler's
compile-time pure-function surface — the lexical-domain analysis —
is rewritten in the frozen kerf subset itself and checked against
the Rust compiler oracle, Pass by Pass (K193 the CPython symtable
precedent: scope classification as a separate pure product before
emission; K194 the Dybvig compile-time environment as an explicit
pure structure; K196 the translation-validation shape: the
a-posteriori check runs per product family).

**The fourth selfhost file** — `selfhost/v1/compiler.krf` (758
lines): the scope-stack discipline (mark/truncate plus the
free-slot LIFO, the Lua freereg lineage), the innermost-first
local lookup, the LA-1 three-way resolution, the LA-4 transitive
`held_by` capture analysis with pass-through entries, the LA-7
compile-side assign boundary, the first-use global/const interning
(NaN folds, signed zeros stay distinct — the `same_const_slot`
rule mirrored by Debug-text identity), and the 1024/1025 depth
mirror — everything that lands in the `Bytecode` as analysis
state. Instruction emission (backpatching, stack-depth
bookkeeping) is the later Passes of this window.

**The fourth parity frontend** — `crates/kerf-driver/src/
compiler_parity.rs`: the host runs the Rust reader AND the Rust
expander (both layers' single sources of tree truth) and injects
the expanded item tree as a flat pre-order record stream
(`(define items (quote (record ...)))` — the CP-1 convention; an
empty parameter list rides as `nil`, a bare `()` being a read
error). Two axes: the product axis (funcs/globals/consts rendered
in one grammar on both sides, byte-compared — creation order,
first-use orders, descriptor sources, const-pool identity) and the
error axis (the structured rejections rebuilt through the oracle's
own `Display`). Three layers route a case: reader rejections (8 of
the 85-file corpus) and expander/loader rejections (19) own their
faces upstream; the other 58 — the checker-owned negatives
included, the E0012 twin among them — run the `.krf` analysis on
both engines (the typecheck layer never decides a CP case: the
analysis products are well-defined on trees the checker rejects).

**The registered input envelope**: the eval engine's 2048-call
depth cap sits below the compile depth limit over the stream
assembler's per-level recursion, so the depth-mirror boundary
(1024 peak passes, 1025 rejects, both sides, same span) rides the
VM-only face — the VM has no frame-depth cap — while the
dual-engine face classifies the same tree as the honest `harness
limit` (the r74 lineage, pinned by a test).

**The fourth self-application**: compiler.krf analyzes its own
expanded tree (758 lines of closures, lets and deep if cascades —
every analysis face of the segment in one program), both engines,
against the oracle. The front-end sources (reader.krf and the
assembled expander) analyze clean too.

**Recovery-verification honesty** (the 24-d precedent): the
previous session was interrupted mid-round and left the
compiler.krf draft untracked; the recovery review caught four real
defects before any delivery — two paren imbalances, a
doc/impl product-shape mismatch (flat vs nested caps), a
nested-pair literal collapse (every quoted list of two or more
elements lost its inner components), and improper capture pairs —
all fixed with regression anchors (the nested-litval case is
pinned forever in the tests and the audit).

Counts: the seventeen-test CP family lands (1286 -> **1303:0:0**),
audit section X mounts ten cases (**210 -> 220/220**), the
selfhost format guard takes its fourth file, the corpus sweep
pins the three-layer distribution, and the ds08 golden chain
records 0.52.0. Six commands all green; B1-B6 all in band (B4's
swept-1023 counter bit-identical for the sixth consecutive run);
TD open items stay at zero (46th round); the primitive kernel is
untouched (56th verification — the CP segment is a new consumer
of the frozen subset, not a language change: no new primitives,
no channels, no VM rewrite, no syntax).

## v0.51.0 — stage 2.2 first-cut close-out: gate B over the full pipeline, the subset-spec capture chapter, and the quantified ★1' resolution (MUV 3)

The r81 round closes out the lexical-addressing first cut: the three
MUV chain (r79 descriptor, r80 semantic flip, r81 close-out
verification) completes and sub-stage 2.1 closes.

- **Ten-item precondition, third maintenance**: the all-green base
  re-verified cold (six commands 1283:0:0 reproduced, audit 200/200,
  B-series in band with B4's swept counter bit-identical, zero open
  TD, corpus 85, selfhost 117/750/660) — the stage-2 entry stays
  open on the r79 lift.
- **Gate B both axes over the full pipeline, captures included**: a
  new capture-dense composite anchor (macro + a two-level transitive
  capture chain + tail-if) rides `gate_b_bytecode` — the oracle's
  own items and the `.krf` expander's rebuilt items compile to
  identical bytecode, descriptor tables included (`Bytecode`
  `PartialEq` absorbs `FuncProto.captures` structurally: descriptor
  drift is bytecode drift). The whole-corpus sweep (85 cases, all
  oracle-eligible) and the descriptor-drift bidirectional guard
  carry the rest.
- **The subset-spec capture chapter, fully rewritten**: subset-spec
  §2.1 grows from the flipped interim into the complete
  seven-clause semantic face (LA-1 resolution order and the
  top-level non-capture; the two-source descriptor table with the
  K45 minimal-set consumption proof; the VM execution semantics
  with the verify definer-frame bounds; the evaluator mirror;
  the immutable boundary E0012; gate-B absorption; the ★1'
  evidence) — the MUV 3 schedule obligation from §9.80.5.
- **★1' quantified resolution — the dormant double cost retires
  with numbers**:
  - *Cost axis*: a structural guard (one capture out of a
    fifty-slot defining frame → the closure env holds exactly one
    slot) and the new B6 bench axis (pure instruction-level
    isolation: hand-built bytecode, ten thousand unrolled
    `closure; pop` pairs) — **B6a (captured=1, width=4) median
    47.8ns vs B6b (captured=1, width=100) median 47.7ns**: the
    frame width grows 25× and the per-creation cost stays flat —
    O(captured), not O(n_locals), measured. B6c
    (captured=25, width=100) median 222.2ns — roughly a fixed
    ~40ns plus ~7.3ns per capture, linear in the capture count.
  - *Retention axis*: a deterministic-counter guard — eight pair
    locals with one captured, then one explicit §19.4 cycle after
    the defining frame dies: **swept == 7 exactly** (the dormant
    full-frame snapshot would have retained all eight and swept
    zero). The §9.51 registration is retired with the proof.
- **B1-B5 reconciliation**: every axis in band against r80 (B1
  7.0µs, B1a 1.0µs, B1b 3.5µs, B1c 1.5µs, B2 82.8ms, B3 7.95ms,
  B5 82.9ms) with **B4's gc 1 / swept 1023 bit-identical for the
  fifth consecutive run** — zero regression from the r80 semantic
  flip, now reconciled on record.
- **Audit section W (200 → 210/210)**: ten end-to-end cases for the
  capture-activation family — the E0012 assign-to-captured boundary
  with the rendered code, the three value faces (basic 8,
  dense-shadowing 23, transitive 60, both engines agreeing), the
  verifier's definer-frame rule over both descriptor sources, the
  top-level non-capture, and the two ★1' proofs.
- **Guards +3** (`capture_cost_guard_tests`): the env-size
  three-shape structural proof, the exact swept counter, and the
  gate-B composite — 1283 → **1286:0:0**.
- Eight-primitive invariance holds for the fifty-fifth round (a
  pure verification round: zero production-crate semantic changes —
  the new guards are read-only observation faces plus hand-built
  bytecode fixtures); zero new external dependencies; zero new
  retrieval (the verification converges on the existing
  K43/K45/K51/K189-K192 anchor family).
- Next entry: the Stage 2.3 fixpoint window opens (compiler
  self-hosting phase A — the first `.krf` rewrite pass over the
  compile-time pure-function face; per-pass parity skeleton; the
  ten-item all-green precondition maintained every round).

## v0.50.0 — stage 2.1 semantic flip: lexical capture activates on both engines (the same-knife MUV — LA-1/LA-3/LA-4/LA-5/LA-6)

The r80 round delivers the semantic half of the lexical-addressing
first cut: the dormant era (0.5-0.49 — every closure cloned its
defining frame whole and nothing ever read the copy) ends, and flat
capture activates across both engines in one knife.

- **LA-1 scope-stack penetration**: `ProtoState` gains the defining
  chain (`parent`) and the analysis table (`captures`); a free name
  resolves own locals -> enclosing chain -> global (the Var arm's
  three-way split). Top-level closures never capture (the entry has
  no parent — global resolution there is unchanged).
- **LA-4 transitive capture**: `held_by` walks the chain and gives
  intermediate protos pass-through capture entries (their own code
  never reads them; the consuming site is the nested `closure`
  instruction's `Captured(k)` source) — the Steensgaard free-variable
  walk internalized, K45 minimal-capture-set ruling.
- **LA-3 the opcode and the frame area**: `load-captured` joins the
  set (24 -> 25, the K192 separated-opcode ruling; the store twin
  stays unlanded with the immutable-capture subset — a zero-emission
  opcode would be dead code). `Frame.captured` is an independent Vec
  (the frozen 3-ext block untouched); `closure` copies exactly the
  descriptor-named values (O(captured), not O(n_locals) — the first
  face of the dormant-capture double-cost resolution); `invoke`
  installs the area from the closure cell; the GC roots extend to
  frame capture areas (§19.4 completeness).
- **LA-5 the evaluator mirror**: `Env.captured` with the same
  three-level resolution order (own -> captured -> global — MIRRORS,
  never invents), a free-name analysis that counts `set!` targets as
  references (the boundary stays decidable after the outer scope is
  gone), selective capture at creation with explicit temp rooting
  across the reserve, saved-environment root protection extended to
  captured values, and the collect_now root set extended likewise.
- **LA-7 the boundary, three layers deep**: assigning to a captured
  variable is a definite rejection. The checker reports E0012 (the
  registry grows to E0001..E0012) with the Fn-arm boundary stack; the
  compiler rejects direct-construction feeds
  (`CompileError::AssignToCaptured`); the evaluator mirrors at
  runtime (`RuntimeError::AssignToCaptured`) — one wording family.
- **LA-6 the pre-registered anchor family flips, all six**: neg-045
  becomes pos-034 and halts with 8; the parity pair becomes a
  positive (6 on both engines); the VM snapshot assertion becomes
  selective (empty env for a no-capture proto) plus a captured-value
  flow test (9 through the frame round-trip); the evaluator's
  dormant-snapshot anchor becomes a capture-outlives-scope test; the
  checker's fresh-frame anchor becomes a sees-through-Fn test; the
  T57 zero-production sweep inverts into a minimality guard with
  transitive awareness (every descriptor consumed either by a direct
  read or a nested pass-through).
- **Corpus 82 -> 85**: the flipped anchor plus a dense-capture
  positive (sibling closures, param shadowing over a capture — 23),
  a transitive-capture positive (three-level chain — 60), and the
  E0012 negative. The expander parity layer count moves 74 -> 77;
  gate B axis (a) eligibility now requires the oracle compile to
  succeed (compile-rejected sources have no bytecode product to
  compare — the rejection face belongs to the corpus harness).
- **HM: zero changes** — the inference machine's environment already
  carried enclosing bindings through Fn bodies (the pre-mirror of
  §9.51.2 row 13); the well-typed program set expands exactly as
  registered.

Verification: six commands all green (1283:0:0 — the 1271存量 all
alive, +12 guards), audit 200/200 (V06's opcode cardinality moves to
25 with the authorized extension), fmt zero diff, clippy -D warnings
zero, non-English coding-face scan clean. B-series all in-band
(B4 gc 1/swept 1023 bit-identical — the GC root extensions are
zero-disturbance on closure-free loads; B1c 1.5 -> 1.6µs and B1b
3.6 -> 4.0µs structural micro-costs registered honestly, both well
inside the 25% band). The 2.1 remainder is the MUV 3 close-out
round: gate B both axes over the full pipeline (captures included in
bytecode identity), the subset-spec semantic chapter, B1-B5
reconciliation, and the quantified ★1' double-cost resolution.

## v0.49.0 — stage 2 opened: the lexical-addressing first cut begins (the capture descriptor lands as a zero-production intermediate state; the user lifts the stage-2 implementation-entry restriction)

The r79 round opens Stage 2: the user message carries the explicit
lift sentence ("open the stage 2 implementation entry restriction"),
the ten-item all-green precondition is verified on the spot (six
commands 1261:0:0, audit 200/200, B-series all in-band with B4's
swept counter bit-identical, zero open tech-debt items, corpus 82,
selfhost 117/750/660), and gate requirement 4 (user confirmation,
SOP §14.6.3 rule 5) closes: ⛔ → ✓. The lexical-addressing +
capture-activation first cut (sub-stage 2.1) starts immediately; the
gate flip is registered in three places (stage-2-plan §0, roadmap
v2.20 §7, stage0.md §9.80.6).

- **The B-type review runs first on the two encoding decisions the
  plan left open** (four new anchors, r79-search/): Lua 5.4.9's
  `Upvaldesc { instack, idx }` read straight from lobject.h is the
  canonical two-source capture descriptor (K189 — a capture names
  either a stack slot of the defining frame or an index in the
  defining closure's own upvalue list); CPython's `co_freevars` per
  code object confirms the per-proto table form (K190); CPython's
  `LOAD_DEREF`/`MAKE_CELL` unified cell+locals index space is weighed
  and declined (K191 — kerf's Frame is frozen 3-ext, the unified
  space would change the frame layout); Lua's `OP_GETUPVAL`/
  `OP_SETUPVAL` settle the LA-3 opcode question (K192 — a separate
  captured-access opcode family with an index operand, the flat-
  closure form; the depth-addressed unified alternative belongs to
  the linked-environment family §9.51.4 already declined).
- **LA-2 lands as the first engineering MUV, zero-production** (the
  stage-2-plan §3 engineering-batch ruling: descriptor field first,
  semantics later, every batch six-command green). `FuncProto` gains
  `captures: Vec<CaptureSource>` where `CaptureSource` is the
  two-source enum `Local(u32) / Captured(u32)` (K189's shape, keyed
  by indices, never name text — the §9.52.5 Symbol identity base
  serves the compiler-side analysis, the product lands as indices).
  `Bytecode`'s `PartialEq` absorbs the field, so the gate-B bytecode
  identity oracle covers it with zero codec change. `verify` gains
  the definer-frame bounds rule at every `closure` site: a `Local`
  source must stay under the defining proto's `n_locals`, a
  `Captured` source must index the defining proto's own capture
  table (the transitive LA-4 bound). A new `CaptureSourceOutOfRange`
  error variant carries pc/callee/entry payloads in the R8 message
  shape. The compiler itself still produces empty tables everywhere
  (`finish()` is explicit) — the capture analysis arrives with the
  LA-1/LA-3 semantic MUV, and a full-corpus zero-production sweep
  guard pre-registers as a semantic-flip anchor (the §9.51.2 anchor
  family: it inverts the day the semantic MUV ships).
- **Guards +10** (6 in-crate: field/equality, R8 message shape,
  verify accept + three rejection shapes; 4 root-level: the corpus
  zero-production sweep, hand-built descriptor verify + equality
  drift, single-source double-compile identity including captures,
  and a CorpusCase dual-engine end-to-end pin that the dormant
  closure semantics are untouched): 1261 → **1271:0:0**, audit
  200/200 held, fmt zero diff, clippy zero warnings. B-series all
  in-band with **B1c bit-identical (the empty table costs the
  compile+verify axis nothing) and B4's gc 1 / swept 1023 counters
  bit-identical** — the strongest zero-semantic-change evidence; all
  1258 pre-existing stock survives untouched.
- **What remains for 2.1** (stage-2-plan §2/§3, the single source):
  MUV 2 = the semantic same-knife round — LA-1 scope-stack
  penetration, the LA-3 `LoadCaptured` opcode family (Opcode::ALL
  24→25), LA-4 transitive capture, the LA-5 evaluator mirror
  ("MIRRORS, never invents"), and the LA-6 semantic-flip anchor
  family (neg-045, the dormant-closure pair, the full-frame-snapshot
  assertion, the slot-layout pin, plus this round's sweep anchor) all
  flipping together on both engines; MUV 3 = the 2.2 close-out
  verification round (gate B dual-criteria full-pipeline rerun,
  subset-spec capture chapter, ★1' dual-cost resolution evidence).

## v0.48.0 — interlude: the selfhost formatting round (the three self-hosted .krf sources get a formatting-cleanup domain round; the convention becomes machine-checked)

The §9.79 review takes the user-named domain directly: tidy, format,
and clarify `selfhost/`. Three findings from the census; four
adjudications land; one family is maintained with recorded argument;
zero windows registered.

- **FMT-1 — every parenthetical dash unifies to the em-dash.** The
  three `.krf` sources split three ways: reader.krf used the em-dash
  (the repo-wide convention — 122 Rust files), while expander.krf and
  macro.krf mixed ` - ` and `  -  ` ASCII dashes *within the same
  files* (an authoring artifact of the 1.6/1.7 rounds that also leaked
  into expander_parity.rs and expander_parity_tests.rs). All 67
  occurrences convert to ` — `; the ASCII parenthetical dash is now
  eradicated repo-wide (a plain `rg` verifies), with the eight
  legitimate `elems.len() - 1` arithmetic sites untouched.
- **FMT-2 — the 100-column hard bound clears the six outliers.**
  SOP §10.5 says "~100 columns" and rustfmt enforces exactly 100 on
  the Rust face (verified locally: `rustfmt --print-config current`);
  the `.krf` layer joins the same number. macro.krf's 684- and
  1697-column single-line define monsters — the repo's widest lines
  on record — are re-emitted algorithmically as 25 and 81 readable
  lines; expander.krf's two 167-column lines and one 101-column line,
  plus reader.krf's 103-column line, are surgically split with the
  surrounding hand formatting untouched. The 80-100 band stays:
  forcing 80 was measured and declined (the aligned breaking profile
  explodes columns on right-leaning cons chains — 146 columns
  measured — while the indent profile triples ex-expand's line count,
  153 to 490).
- **FMT-3 — selfhost/README.md lands as the entry document.** The
  three-file chain with line counts and design anchors, the hosting
  conventions (RS-1 token table, EX-1 flat pre-order stream), the
  MX-2 assembly contract, the consumption map with the four
  tamper-anchor needles called out as sensitivity boundaries, the
  formatting convention, and the honest boundaries (MX-1 mangled
  records, float Debug-text, macro-layer routing, the VM's permanent
  Rust base as a constitutional exclusion).
- **FMT-4 — the convention becomes machine-checked.** A new root
  guard (the cross-crate asset face, the message_quality_guard
  precedent) asserts three invariants over the three sources: width
  ≤ 100, the non-ASCII whitelist {em-dash, §}, and zero ASCII
  parenthetical dashes. 1258 → 1261:0:0.
- **The reformat tool is archived as the repo's first self-built
  tool** (tools/selfhost/krf_reformat.py +
  docs/tools/selfhost/krf-reformat.md, §3.4): an S-expression parser
  and style emitter whose output is verified three ways per touched
  form — the token stream stays byte-identical, the parse tree stays
  structurally equal, and the four tamper needles stay contiguous.
  The whitespace-only guarantee is mechanical, not aspirational:
  comments are not tokens to the lexer, so the dual-engine parity is
  transparent by construction, and B4's swept-1023 counter stayed
  bit-identical — the strongest evidence the reformat is
  semantically inert. The strip-compare channel (comments and
  whitespace removed, code text compared byte-for-byte) caught a
  three-character paren drift in the first hand-split attempt before
  any test ran — the channel works.
- **Maintained with recorded argument: the two line-breaking styles
  stay.** macro.krf's +1 indent vs reader/expander's argument
  alignment — each mirrors its file's dominant hand style, and each
  profile measurably fails on the other's shape.
- Frontier anchors K186-K188 (SOP §10.5 as the internal canon, the
  local rustfmt probe, the repo em-dash census); weak-search round 26
  disclosed (rustfmt policy 429 upstream, Racket style guide three
  garbage hits — this domain's authority is in-repo).
- selfhost line counts 116/741/558 → 117/750/660 (historical round
  records keep their point-in-time counts). audit 200/200 unchanged;
  B-series all in-band with B4 bit-identical; fmt zero diff; clippy
  `-D warnings` clean.

## v0.47.0 — interlude: the diagnostic message content-quality round (the malformed-form family states its expected shape, the type-mismatch family names its demanded kind, the arity family pluralizes correctly, and the user-facing messages stop citing internal document paths)

The §9.78 review opens the message text itself — the cross-cutting
face every pipeline stage shares (§9.56 audited the position layer in
v0.25.0; the content layer had never been main-reviewed). Four
adjudications land; eight families are maintained with recorded
argument; one window is registered.

- **MSG-1 — the malformed-form family carries its expected shape.**
  Every `malformed `X` form` now states what a well-formed use looks
  like: `malformed `let` form: expected (let bindings body) with
  bindings `()`, `(name value)` or `((name value)...)`. The template
  rides a static table keyed by the same twelve form names the .krf
  parity decoder maps — the record grammar is untouched and both
  parity sides render through the same Display, so the enrichment is
  transparent to the fixpoint gate (K182/K183: the rustc
  expected-found discipline — `expected `;`, found X`; "`if` may be
  missing an `else` clause" — parser-level shapes name what was
  expected instead of hedging; a bare `malformed form` collapsed four
  distinct defect classes into one message with zero specificity).
- **MSG-2 — the type-mismatch family names its demanded kind.** The
  hedge `must be a matching kind` retires; every raise site states
  what its operation demands through one shared constant vocabulary
  (`a pair`, `a bool`, `a string`, `a closure or builtin`, `a number
  of the same kind`): `type mismatch: car operand must be a pair, got
  `int``. The constants live in kerf-vm and the evaluator imports
  them, so the two engines cannot drift on the demanded text (K182:
  rustc E0308 puts the demanded type first — `expected `bool`, found
  integer`).
- **MSG-3 — the arity family pluralizes, machine-checked.** `expects
  `1` arguments` becomes `expects `1` argument` (K182: rustc E0061 —
  `this function takes 1 argument but 2 arguments were supplied`).
  The three hand-mirrored producers (the runtime ArityMismatch face
  and the checker's R2/R5 arms) now share one plural discipline, and
  a new root cross-crate guard constructs the same (expected=1,
  actual=2) mismatch through all three and asserts byte-identical
  wording — the documented convention becomes a machine-checked
  agreement.
- **MSG-4 — user-facing messages stop citing internal documents.**
  The PhaseViolation message drops its inline `docs/stage0.md §8.9`
  citation; the rule reference stays on the doc comment (the
  developer face). K180: rustc keeps depth behind `--explain` and
  stable error codes, never inline file paths.
- **Maintained with recorded argument** — the reader literal family
  (K71-K74 anchors stand), the CompileError internal-defect faces
  (hand-built products only, semantic payloads), the ModuleError
  cycle path rendering, the terminology split identifier/variable/
  global (three distinct resolution-failure points at three distinct
  detection stages — the rustc-analogous per-face splitting), the
  `#<anonymous>` rendering, the lowercase kind vocabulary, and the
  harness-limit classification (BST-2).
- **Registered W-DIAG-EXPLAIN** — the error-code index / `--explain`
  depth channel (rustc's answer to succinct messages with depth
  behind codes; the E0xxx registry covers typecheck only today).
  Trigger: the Stage 2 user-facing UX agenda. Zero signal now.
- Guards +7 (5 root cross-crate family guards + 2 expander in-crate);
  goldens re-blessed (ds02 the demanded-kind face, the parity oracle
  exact-texts, the audit I-section wording — all documented
  re-records, zero contract change); 1258:0:0 (1251 + 7) + audit
  200/200; B-series all in-band with the B4 counters bit-identical
  (every change sits on the error path — zero happy-path cost).
- Frontier anchors K180-K185: the rustc-dev-guide diagnostics chapter
  (47,829B — the style guide: plain simple English, the "illegal" is
  illegal rule, message-stands-on-its-own, the error-portion-should-
  not-suggest-fixes discipline, the `--explain` mechanism), the Swift
  diagnostics design doc (21,825B — single phrase or sentence, match
  the tone and phrasing of other diagnostics, diagnostic groups as
  teachable moments), six rustc 1.98.1 live probes (E0061/E0057
  singular discipline, E0308 demanded-first, the parse expected-found
  family), the rustc_parse parser source (72,436B — the expected-found
  shapes at the parser level), and the fluent single-source-dictionary
  alignment; weak-search round 25 disclosed (the rustc fluent file
  404 on three channels, the Elm compilers-as-assistants page
  returned a JS shell with zero article text — title-level anchor
  only; GitHub API 403 continues).

## v0.46.0 — interlude: the typecheck inference-algorithm round (the HM engine's unification becomes transactional, the union-find acyclicity invariant gains a fixpoint property guard, and the twin collection walks are pinned equal by mirror guards)

The §9.77 review opens the inference engine itself — the pipeline's
largest single algorithm body (infer.rs, the iterative Algorithm W
with its union-find metavariables, undo log, occurs check, SCC-based
letrec pre-binding, and effect-row collection face). §9.68 had
main-reviewed the checker's *work state* (the Symbol keying of its
tables); the algorithm semantics never had a domain review of its
own. The round's verdict family (INF-1..INF-12, implement 3 /
maintain 9):

- **INF-1 transactional unify** — `Ctx::unify` now wraps its
  worklist in a mark/rollback transaction: a failed unification
  restores the link-table entry state, so partial bindings from an
  aborted composite unification can never leak into later
  inference. The no-leak contract becomes structural (single
  source, the engine) rather than a per-caller discipline that was
  sound only because the one non-rolling-back caller always unified
  against an atomic type. Frontier shape: the rustc inference
  context's probe/`commit_if_ok` snapshot family (K174).
- **INF-2 acyclicity fixpoint guard** — a deterministic
  LCG-driven sequence of 400 pseudo-random unifications asserts,
  after every operation, that every metavariable chain ends at a
  fixpoint (an unbound var or a concrete type). A cycle that
  bypassed the occurs guard would break `resolve_shallow` at its
  defensive hop cap mid-chain, where the returned var still has a
  link — the assertion catches it. The cap itself stays as
  belt-and-suspenders (ena and OCaml `btype` assume acyclicity with
  no cap at all — K177).
- **INF-9 mirror-alignment guards** — `check::collect_table` and
  `infer::collect_info` are deliberate twins (kind shapes vs
  literal values), and their agreement on names-in-walk-order and
  the assigned set is what makes position-aware visibility and the
  assignment over-approximation guard sound. A representative
  fixture (every define shape, assigns in every expression
  position, nested modules, duplicate names) now pins the two walks
  equal mechanically — the TEST-2 parity methodology applied to a
  twin-walk pair. `pub(crate)` visibility only; zero public-API
  face.
- Maintained with recorded argument: the occurs check (GHC
  `uType`/CheckForCycle shape — K176), first-seen generalization and
  the Fn-literal-only rule (OCaml's POPL 2021 statically-constructive
  letrec modes — K178), the value restriction, the SCC over-approximated
  call graph (widening loses precision, never correctness), the
  car/cdr no-constraint release (definite-error-only discipline),
  the ad-hoc builtin table's runtime mirror (DISPATCH_PROBES + the
  FP3 negative-negative dual), the effect-row algebra (determinism
  audited §9.55; row polymorphism stays the Stage 2+ TY-C window),
  the depth budget (A6), and the schema display α-renaming.

Tests 1243 → **1251:0:0** (3 negative engine-contract + 1 property
+ 4 mirror guards); audit 200/200; B-axis all in-band (B4
bit-identical: gc 1 cycle, swept 1023 — the unify transaction adds
one `Vec::len` read on the success path and touches only error
paths otherwise). Six commands green. Stage-2 entry ban: r76
24th reiteration (解除判据 unchanged — stage-2-plan §0).

## v0.45.0 — interlude: the oracle-encoding round (the gate-B decode face gains per-arm arity guards — a malformed record from the self-hosted layer under test reports structured drift, never a harness panic; the dual encoders' kind coverage and byte agreement get structural pins)

The §9.76 review opens the gate-B oracle's encoding face — the
`dump_oracle_*` (Rust ADT) vs `dump_krf_*` (runtime value) dual
encoders, the `rebuild_*` decoder family, and the
`reconstruct_*_error` structured rejections across both parity
harnesses. Two prior rounds touched this face sideways (§9.74
unified the tag grammar and the dual-engine driver; §9.75
maintained the dual decoders); as a domain it never had its own
review. The round's finding family: every decode arm's arity was
enforced implicitly by indexing and slicing, not explicitly — a
record truncated past the shared header could panic the harness
(the apply/perform slice `[4..len-1]` at four fields, the `if`
arms' `elems[5]`, the pair litvals' `elems[2]`, twelve rejection
arms' `elems[3..4]`, six reader leaf arms' `elems[3]`), violating
the harness's own documented "reported as drift, never a panic"
contract: one malformed record from a buggy self-hosted expander
would abort the whole corpus sweep with an opaque panic instead of
a per-case drift report. SER-1 gives every arm an explicit
`need_fields` guard in serde's `invalid_length` shape (K172 —
kind, actual count, needed count); SER-2 pins totality with
truncation batteries over every kind × every short length through
`catch_unwind` (eleven guard tests, drift-not-panic asserted
twice); SER-3 pins the dual encoders' alignment — the krf side's
accepted kinds mirror the ADT's kind names (K170 GHC Outputable's
one-instance-per-type coverage discipline, including the one
documented `literal`/`lit` tag divergence) and a hand-built record
tree dumps byte-identical to the oracle's own dump. Maintained:
the float Debug-text single-source (the harness emits `{v:?}`
itself — K169 rustc's one-printer-framework family), the
fail-closed helper family, the dual-decoder separation itself
(type unification impossible across an ADT and a data-driven
value walk — the alignment contract lives in guards, not a
grammar-manifest carrier), and the BST-3 envelope face (K171
CPython reprlib's budgeted-totality shape). Frontier anchors
K169-K173 + K167 reuse (rustc pp.rs, GHC Outputable.hs, CPython
reprlib.py, serde de/mod.rs, proptest round-trip guides, wasmtime
differential from r73); weak-search round 22 disclosed (q2/q2b
double 429, q1/q3/q5 noise, q4 strong — five primary-source reads
carry the anchors; archive tool-results/r75-search/ 9 files).
Registered W-ORACLE-ROUNDTRIP (generative round-trip property
over random CoreExpr; trigger: Stage 2 corpus scale-up or an
LA-1 ADT change; zero signal). Guards +11; 1243:0:0
(1232 + 11) + audit 200/200; B-series all in-band with B4
counters bit-identical (1 cycle / 1023 swept — the guards sit on
the error path only, zero happy-path cost); baseline re-recorded
on the fresh sandbox's rustc 1.98.1 (B1 7.4-7.5µs, B1a 1.1µs,
B2 80.3-81.2ms, B3 7.32ms, B5 80.6ms).

## v0.44.0 — interlude: the bootstrap-bridge round (the harness's engine-budget rejections gain a failure-site classification — honest input envelope vs defect; the envelope itself is measured and bracketed; gate B sweeps the whole acceptance corpus; the deep parity tests gain the stack wrapper the previous environment had masked)

The §9.75 review opens the bootstrap bridge — the pipeline stage
the standing instruction names that never had a domain round of
its own: the self-hosted front-end family (`selfhost/v1/reader.krf`
116 lines, `expander.krf` 741, `macro.krf` 558) plus the host
assembly bridge (`forms_stream_prefix`, `token_table_prefix`, the
dual-engine parity harness, fixpoint gate B). Every earlier touch
was a segment build (§9.46-§9.48) or a cross-cut (§9.74's harness
core); the bridge as a domain never had its review. The round
opened with a live repro: the cold six-command run ABORTED in this
sandbox — `mp7` (the 512-level expansion-depth mirror) overflowed
the plain 8 MiB test-thread stack; the previous sandbox's larger
limit had masked four unwrapped deep-profile tests. BST-1 — the
four deep tests (`mp7`, both self-application fixpoints, the
reader's own-source fixed point, the macro-corpus loop riding
`bnd-010`) gain the `deep_stack` wrapper the corpus sweeps already
carried: the harness's stack dependence becomes explicit per test,
not an environment accident. BST-2 — `drive_dual_engines`'
failure path conflated three classes (a real harness defect, an
undecodable result, and an engine budget rejecting the harness
program on an input the oracle accepts); the budget faces
(`BudgetExceeded` / `EvalDepthExceeded`) now classify at the
failure site as `harness limit: …` with the envelope explanation,
everything else stays `harness defect: …` (K165 — CPython's
`_json.c` guards every scanner descent with
`_Py_EnterRecursiveCall(" while decoding a JSON object ")`: the
boundary is intrinsic AND classified where it trips, never a
generic crash; the prefix is single-sourced in the harness core,
never re-prefixed by the callers). BST-3 — the harness's input
envelope is now measured and bracketed: the frozen subset
expresses iteration only through self-recursion (no loop
primitive — the §9.29 termination argument), so every harness
walk costs one call frame per element and the envelope is finite;
probed on this host (reader width face trips between 800 and 1200
flat token-table entries, expander between 900 and 1100 flat
arguments — the VM engine survives every probed width), the
guards pin 700 within / 1500 beyond on both harnesses, with the
beyond side asserting the classified limit (K166 — Go's dist
declares `requiredBootstrapVersion` and refuses an insufficient
bootstrap toolchain instead of discovering the shortfall late).
BST-4 — gate B axis (a) (bytecode equality through the host
rebuild path) extended from the hand-picked anchors and the self
application to EVERY corpus file the oracle pipeline accepts
(read + expand + load eligibility mirroring gate B's own steps;
the rejection faces stay owned by the parity sweeps). Maintained
with rationale: the per-element self-recursion shape (the
iterative rewrite is constitutionally excluded — zero new
primitives), the 2048 `EVAL_DEPTH_LIMIT` and the §19.4 budget
ladder (raising them for a harness convenience would be a
language-semantics change with a cross-cutting blast radius), the
dump/rebuild twin host decoders (different output types, both
drift-guarded — now exercised corpus-wide), the MX-1/MX-2 honest
boundaries (mangled rename decode, the assembly order), and the
reader's one-frame-per-token iterative shape (the REC-A lineage).
Anchors K164-K168 (stage0-posix's Phase-0 seed-rebuild identity
check as the fixpoint's ground form and its per-stage chain
verification; CPython `_json.c` + `Lib/json/decoder.py` as the
dual-implementation classified-boundary pair; Go `cmd/dist`'s
declared bootstrap capability; wasmtime's differential harness
reused from r73); weak-search round 21 disclosed (q1/q1b double
429, q2/q2b/q3 noise — the anchor load carried by five direct
primary-source reads). Guards +5 (envelope brackets ×4 + the gate
B corpus sweep); 1232:0:0 + audit 200/200; B-series double run
all in-band (B1a 1.0µs and B4 gc-cycles 1 / swept 1023
bit-identical; B1 7.1-7.3µs, B2 80.3-80.8ms, B3 7.32ms, B5
80.4-80.7ms). Root worklog backfilled to mirror parity (the Task
51 five entries had landed only in the repository-side log).

## v0.43.0 — interlude: the parity-machine round (the three hand-rolled dual-engine drivers and the twin tag decoders retire into one single-source harness core; the corpus expectation contract gains two documented, guarded conventions)

The §9.74 review opens the parity machine itself — the driver
crate's three harness files (parity.rs, reader_parity.rs,
expander_parity.rs, 2,926 lines) that carry the dual-engine
equivalence oracle. Every earlier touch was cross-cutting (§9.55
the parity-key linkage, §9.64-§9.65 the identity rebuilds, §9.72
the Rc<str> ripple); the machine never had a domain round of its
own. Four findings close here. PAR-1 — the two `run_dual` twins
and the `run_dual_rich` third shape (three copies of the same
six-step skeleton: session, parse, typecheck, compile, vm run,
eval run, each decoding its engine's `result` global while the
heap is still alive) plus the twin `decode_verdict` tag grammars
retire into `drive_dual_engines` + `decode_tagged`: one generic
driver parameterized by the host name, the harness noun threaded
into every defect message, and the two per-engine decoders (the
vm decoder may rebuild richer gate-B state while the eval decoder
stays plain — behavior byte-identical); a fourth parity front end
at Stage 2 plugs in as one closure, never a copied skeleton (the
§9.73 dispatch_builtin lineage applied to the harness layer; K159
wasmtime's differential driver is the configurable-pair cousin —
kerf's fixed VM/Eval pair is a language-definition face). PAR-2 —
the reader's two-axis `matched` predicate was the same semantics
in two shapes (a constructed `KrfVerdict::Tree(oracle.clone())`
comparison on one arm, a direct key comparison on the other); it
is now one text-equality predicate behind a shape-pairing guard.
PAR-3 — the `type-error`/`warning` code lists compare as
multisets (order-insensitive, duplicates significant), the same
convention as GCC's one-directive-one-message `dg-error` (K157)
and rustc compiletest's per-expectation `found` slots (K158); the
convention is now documented on `CorpusCase` and exercised by a
new corpus case (neg-056: two independent E0009 sites expect
`E0009 E0009` — the duplicate path was previously never walked).
PAR-4 — the `value` expectation form is a dual assertion (halt
repr AND zero warnings); a warned program now has a guard proving
it fails a bare `value` form with the drift naming the divergence
(the `warning` form is the way to expect it). Maintained with
rationale: the module-error expectation rides the `expand-error`
form (from_module maps to the kerf-expand tag — five corpus cases
already carry it), the halt path carries no stdin face (the
read-line parity lives in the seed-test dual_run sites), the
runtime-rejection fourth-arm drift wording (single-sided), and
the three-face agreement machine (§9.73 already surveyed).
Registered W-PAR-SHRINK (drift minimization; trigger: corpus
growth makes drift localization a measured concern; zero signal).
Corpus 81 → 82; guards +2 (multiset semantics + value-form
zero-warning); layer count 73 → 74. 1227:0:0 + audit 200/200;
B-series per rule 5: B1a bit-identical at 1.0µs, B2 within band on
the stability re-run (81.4ms vs the r72 80.5-81.3ms band), B4
counters bit-identical (gc-cycles 1 / swept 1023), B3/B5 in-band;
weak-search round 20 disclosed (q2/q5 garbage, q7 429 — anchoring
carried by seven primary sources: gcc sourcebuild.texi, rustc
compiletest runtest.rs, wasmtime differential.rs, v8 testsuite,
proptest book, compiletest common.rs, rustc tests/ui README).

## v0.42.0 — interlude: the evaluator builtin-dispatch round (the fixed-arity check and the 18-arm routing become one single-source function over a host trait; the 18-builtin dual-engine parity goes systematic)

The §9.73 review opens the last doubly-lagging consumer face —
the builtin dispatch on the evaluator side (the §9.44 twelve-row
table surveyed dispatch at v0.15.0, the §9.49 backend table at
v0.20.0; every later touch was cross-cutting, never a domain
round). Three findings close here. EVL-1/EVL-2 — the arity check
and the 18-arm routing were written once per engine (vm.rs and
eval.rs each carried a twin `call_builtin` over the already-shared
semantic bodies); both now enter the single `dispatch_builtin`
function over the `BuiltinHost` trait (charge / io / heap faces —
each engine keeps its own §19.4 budget semantics behind `charge`;
static dispatch, two monomorphizations, zero vtable cost; the K150
Lua `precallC` host-passing discipline and the K154 rustc `TyCtxt`
funnel; a routing drift between the engines is now a type error,
not a parity incident — the §9.69 EXC-1 twin-walker-retirement
family). EVL-3 — the behavior parity guard goes systematic: a
probe table drives all 18 registry rows through BOTH engines with a
positive program (value agreement + pinned repr + output agreement)
and a negative program (both engines reject with the identical
rendered error); the table is registry-complete fail-closed (a new
registry row without a probe fails the test — the K153
registry-carried-arity discipline). Maintained with rationale: the
seeding asymmetry (the VM pre-binds only the referenced globals
from the bytecode table, the evaluator binds all 18 — the
observation-face duality), the temp-root clone-per-argument
discipline (load-bearing: the args must stay reachable from the
roots while `invoke` reserves), the `name()`/`arity()` linear
registry derivation (single source over `Builtin::ALL`, O(18) under
the frozen registry), the `global(&str)` linear observation face
(§9.67 NB-7 no-pollution), `from_name` at build time, and the
2048 EVAL_DEPTH_LIMIT Rust-stack guard; the `builtin_ops` comment
drift in vm.rs retires with the twin method. Frontier anchors
K150-K156 (Lua ldo.c precallC + lbaselib.c registry; CPython
methodobject signature-family + create-time adapter selection with
the fail-closed default arm; BEAM `ErlNifFunc{name, arity, fptr}` —
the registry row shape is identical; rustc `TyCtxt` as the
compiler-wide host; V8's Isolate-in-a-root-register; weak-search
round 19 honestly disclosed — q4/q4b double 429, anchoring carried
by the seven primary sources). Guards +2 (the systematic positive
and negative probe tables); 1224:0:0 + audit 200/200; B-series per
rule 5: B1a/B1c bit-identical, B1/B1b in-band, VM axes within the
environment band with a stability re-run (B2 81.3→80.5ms, B3
7.5→7.3ms, B5 81.5→80.2ms), B4 deterministic counters bit-identical
(gc-cycles 1, swept 1023).

## v0.41.0 — interlude: the syntax-tree/core-IR representation round (string literals flow as one shared allocation end to end; the constructor duplicate scans key on identity)

The §9.72 review opens the middle-representation domain (SYN ruling
family, 10 faces: 2 implemented, 8 maintained) — the kerf-syntax
crate (StxDatum/SyntaxObject/ScopeSet/Phase) and kerf-core's
CoreExpr/LiteralValue layer: the only two pipeline rows never
specifically reviewed (the §9.44 twelve-row table surveyed both at
v0.15.0, twenty-five versions ago; every later touch — the §9.52
payload swap, the §9.58 twin retirement, the §9.65 error payloads,
the §9.69 pair_cells — was cross-cutting, never a domain round).
With the producer-consumer pairs cleared on both ends (§9.69/§9.70
backend, §9.66/§9.71 frontend), the middle representation layer is
the remaining unreviewed span between them.

- **SYN-1 — the shared string-literal payload.** The literal payload
  becomes one `Rc<str>` from reader to runtime: `StxDatum::String`,
  `LiteralValue::String`, `AtomDatum::Str` (macro pattern literals),
  and `Value::Str` all carry the shared handle (K143 rustc `Lit{
  symbol: Symbol }` → `LitKind::Str(Symbol, ..)` — interned identity
  end to end, zero owned strings per literal node; K145 oxc's
  dedicated string crate with arena `Str<'a>` payloads; K146 Lua's
  short-string global table — consumption points never re-copy). The
  pre-round chain copied the bytes four times: the expander cloned
  the reader's `String` into the core literal, the compiler cloned it
  into the constant pool, and every runtime materialization (and
  every local load of a string-carrying value) cloned it again. After
  the round each hop is a refcount bump, pinned by pointer-identity
  guards at three points (the pool entry aliases the literal, two
  materializations alias each other, the expanded literal aliases the
  reader's atom). `Value`, `LiteralValue`, and `StxDatum` all shrink
  32 → 24 bytes (the three-word `String` becomes a two-word fat
  pointer), pinned by a layout guard. Display/Debug/equality are
  content-based and byte-identical — all 1219 pre-existing tests,
  the 81-case corpus, the self-host parity chain, and the fixpoint
  gate B pass unchanged. `read-line` (the only runtime string
  producer) wraps its fresh line in the one allocation; single-thread
  compilation discipline is on record (only `Symbol`s cross threads,
  symbol.rs:69 note), so `Rc` over `Arc` carries no `Send` risk.
- **SYN-2 — identity-keyed duplicate scans.** `CoreExpr::fn_` and
  `CoreExpr::handle` deduplicate through `HashSet<Symbol>` (u32
  identity hashing) instead of `HashSet<&str>` (text hashing) — the
  two residual text-keyed working states the §9.68 identity-closure
  claim missed; the closure claim now holds without exception (error
  payloads already were pool entries, §9.65 EXP-4/5; the scan keys
  now are too). Behavior is pinned by the existing duplicate-param /
  duplicate-handler negatives in three test files.
- **Maintained (8 faces)** — the per-node four-tuple scope-set model
  (K148 Racket: every syntax object carries a scope set, including
  non-identifier atoms; rustc's `SyntaxContext` chain is the other
  family, m6 — a model choice, not a defect), the sorted-Vec
  `ScopeSet` (deterministic iteration, content hash; `union` has zero
  production consumers, the resolver consumes `is_subset_of` on tiny
  sets), the two-level frozen `Phase`, the Box/Vec `CoreExpr` tree
  (K144: rustc 1.98's own `Expr` is a plain Box/ThinVec tree — the
  `P<T>` pointer type is retired upstream; arena/index forms have no
  signal at this scale), span-in-variant vs rustc's struct wrapper
  (TD-004 discipline; no NodeId equivalent — no incremental
  recompilation consumer), the documented `kind_name` mirror pair,
  and the pre-order `visit_spans` family. **Registered
  W-SYN-SCOPE-SHARING** (the `with_scope_added` deep clone —
  O(subtree) per binding form; trigger: the B1b expand axis leaves
  its ±25% band or Stage 2 self-host corpus expansion becomes a
  measured concern; zero signal now — B1b 3.6µs in-band).
- **Verification** — six commands green on the re-seeded toolchain
  (rustc 1.98.1, fresh sandbox): fmt zero-diff, clippy `-D warnings`
  zero, build 0/0, **test 1222:0:0** (+3 guards: the pool-alias pin,
  the materialization-alias + layout pins, the reader→expander alias
  pin), doc 1 registered warning (cargo#6313), audit **200/200**.
  B-series re-run per rule 5 (representation faces touched): compile
  axes flat-to-better (B1 7.3 → 7.1µs, B1c bit-identical), VM axes
  +6.0-7.5% in-band attributed to the fresh-sandbox environment (the
  fib workload carries zero string literals — SYN-1 is not on its
  path; B4's deterministic counters stay bit-identical: gc-cycles 1,
  swept 1023). No dedicated string-workload B axis exists (window
  discipline — no signal); the SYN-1 claim is structural (one
  allocation per distinct literal, refcounts thereafter) and carried
  by the guard family.
- **Version face** — Cargo.toml 0.41.0, ds08 version-golden chain
  +1 (28 entries), this note, README status; search archive
  r71-search/ (20 disk-measured files: 6 query products — both q2
  attempts hit 429 and left nothing on disk, honestly registered —
  plus 13 primary-source entries, of which m1/m3.pdf are retained
  404 placeholders and 11 are real
  files, plus the README; the
  eighteenth consecutive weak-search round honestly recorded —
  anchoring carried by primary sources: rustc ast.rs/token.rs/
  hygiene.rs at tag 1.98.0, oxc_span/oxc_str/oxc_ast literal.rs,
  Racket syntax-model, Lua lstring.c, V8 string.h, and the local
  same-version std rc.rs).

## v0.40.0 — interlude: the reader round (the scan goes byte-dispatched and zero-copy; both literal-overflow faces fail closed; the literal errors point at the token)

The §9.71 review opens the reader domain (RDR ruling family, 10
faces: 3 implemented, 7 maintained) — the kerf-reader crate's scan,
classification, and error surfaces last specifically reviewed at
§9.44 (v0.15.0, twenty-four versions ago); every later touch was a
cross-cutting fix (the §9.58 error passthrough, the §9.52 single
pool), never a domain round.

- **RDR-1 — the byte-dispatched, zero-copy scan.** Every scan loop
  (trivia, comments, atoms, string runs) dispatches on bytes: the
  ASCII fast path advances by single bytes and never decodes, and
  only non-ASCII bytes pay a UTF-8 decode (the V8 range-scan
  discipline, K142; rustc holds one `Chars` and clones per peek —
  kerf's old per-peek re-slice was the worst of the three shapes,
  K137). Atoms classify from a zero-copy slice of the source (the
  run is contiguous and both ends are char boundaries by
  construction) — the per-atom intermediate `String` allocation
  retires (rustc tokens are lengths over the source; the consumer
  slices once, K137). String literals bulk-copy plain ASCII runs
  between the specials. The whole token stream (kinds + byte spans)
  is pinned byte-identical on a mixed-width fixture (BOM, CJK
  atoms, the vertical-tab separator that `u8::is_ascii_whitespace`
  would miss, non-ASCII inside comments, escapes, adjacency).
- **RDR-2 — both literal-overflow faces fail closed.** An
  integer-shaped atom that overflows `i64` is no longer silently
  demoted to a float (the strict Int/Float typing contradicted at
  the lexical floor), and a float-shaped atom that overflows `f64`
  is no longer silently read as ±inf — two new variants,
  `IntOutOfRange` and `FloatOutOfRange` (K138: rustc denies both
  faces by default with the same split; K139: the Go spec requires
  an error when an integer constant cannot be represented precisely
  or a float overflows, while precision-limited underflow rounds to
  the nearest representable value — so `1e-999` stays legal as
  `0.0`). The escape is spelling the value as a float (`1e20`,
  `99999999999999999999.0`).
- **RDR-3 — the literal errors point at the token.** The literal
  family (`InvalidBool`, `MalformedNumber`, and the two new
  overflow variants) carries its whole-token span; the driver's
  diagnostic renders the real extent (a caret run under the
  literal, exactly the rustc shape) instead of rendering no
  location line at all — `1.2.3` in a large file used to have to be
  found by hand. `offset()` keeps its honesty rule (no fabricated
  single byte); the new `token_span()` surfaces the real extent.
- Maintained: the eager token vector (incremental parsing stays a
  registered Stage-2 LSP window), the 256/512/1024 three-tier
  nesting caps, the BOM-anywhere leniency, the dotted-pair `.`
  identifier surface, the position-free Display (§9.56 DIAG-1), the
  parser's deterministic error precedence, and the single-source
  dictionary delegation for `InvalidSymbol`.
- Frontier anchors K137-K142 (rustc_lexer cursor/lib — the
  byte-note `eat_while`, length-tokens, memchr comments; the rustc
  1.98.1 empirical probe on `1e999`/`99999999999999999999`/`1e-999`
  — deny, deny, accept; the Go spec constant-expression rules;
  CPython `parsenumber_raw` with its in-source "XXX Huge floats
  may silently fail"; Lua `read_numeral`; the V8 scanner range
  scan). Corpus +2 negative (neg-054 i64 overflow, neg-055 float
  overflow — 79 → 81 cases). Guards: the rich-fixture byte pin, the
  overflow faces at both signs, the inclusive boundaries
  (i64::MAX/MIN, f64::MAX), underflow-to-zero, the spelled-float
  escape, the driver render goldens (ds11), the diagnostic
  whole-token spans. Six commands green; B1a read-fib re-measured
  on the byte-dispatched scan.

## v0.39.0 — interlude: the compiler lowering round (the constant pool goes pre-hashed with a predicate truth; the jump patch bookkeeping rides in the instruction stream; let slots recycle)

The §9.70 review opens the compiler lowering and instruction
emission domain (EMI ruling family, 10 faces: 3 implemented, 6
maintained, 1 window registration) — the kerf-compiler crate's
algorithm faces (instruction selection, jump backpatching, constant
pool interning, slot allocation) last specifically reviewed at
§9.49 (v0.20.0, nineteen rounds ago).

- **EMI-1 — pre-hashed constant interning with a predicate truth.**
  Every literal occurrence used to deep-clone its `ConstKey` mirror
  (strings cloned, pairs recursively boxed) just to probe the dedup
  map — and the mirror type carried a second, manually-synced copy
  of the pool semantics (NaN folds, ±0.0 stay distinct). The pool
  now keys by a deterministic FNV-1a hash computed over the literal
  itself (fixed seed, wrapping multiply — rustc `Unhasher`
  discipline) with collision buckets resolved by the
  `same_const_slot` predicate against the pool entries (Lua `addk`:
  the index is only a hint, the pool entry is the truth). Zero
  allocation on the probe path; the mirror type retires; pool
  output is bit-identical (first-use insertion order preserved).
- **EMI-2 — jump patch bookkeeping rides in the instruction
  stream.** Pending jumps used to be tracked in two parallel
  structures (`jump_sources: HashMap<usize, i32>` +
  `unpatched: Vec<usize>`), patched through an O(pending) position
  scan. The source depth now rides in the jump's unused `b` operand
  at emission, membership is the `a == JUMP_PLACEHOLDER` sentinel
  (O(1)), `patch` writes the target and clears `b` back to zero
  (the "unused slot is always 0" output contract holds for finished
  products), and `finish` scans for placeholder jumps in code order
  (Lua patchlist discipline — the code is the bookkeeping; the list
  machinery itself is not adopted: kerf patches single jumps with
  depth assertions, principle over mechanism).
- **EMI-3 — let slots recycle through a LIFO free-list.** Slots
  were allocated monotonically and never reused, so `n_locals`
  grew with the cumulative binding count while the VM allocates
  `vec![Value::Nil; n_locals]` per call. `locals_truncate` now
  returns dead slots to a per-proto free-list and `alloc_local`
  hands them back LIFO (deterministic; Lua `freereg` window
  discipline) — `n_locals` is the peak simultaneous count. Valid
  because compile products are back-edge-free: a reused slot's
  earlier readers always execute before its re-binder. Shadowing
  keeps distinct slots (simultaneously live bindings).
- **Maintained** — the Vec reverse-scan local lookup (rustc Rib
  discipline, §9.68 CHK-8 precedent), the one-pass backpatch shape
  (CPython's symbolic-label indirection buys multi-pass
  optimization kerf does not have), the args-then-callee evaluation
  order (§19.3/§19.5 frozen contract), the exact-dedup contract
  (NaN single slot, ±0.0 distinct — Lua's tolerant "wastes an
  entry" philosophy declined), the verify DAG depth propagation,
  and the single `emit` path with automatic debug_info.
- **Registered W-EMI-COMPILE-AXIS** (compile-time measurement
  window; trigger: the self-host corpus compile becomes a measured
  concern at Stage 2, currently no dedicated B axis).
- Frontier anchors K132-K136 (Lua 5.4 lcode.c addk/patchlist/
  freereg + lparser.c + lobject.h, CPython 3.12 compile.c label
  indirection + deterministic slot order, rustc unhash.rs + span
  symbol.rs intern_inner, V8 baseline constant-pool consumption).
- Guards +4 (predicate truth end-to-end: ±0/NaN/string/pair slot
  identity; sibling-scope slot reuse + shadowing freshness; patched
  jumps restore the zero-operand contract; full-pipeline VM
  integration with recycled slots); 1205:0:0 + audit 200/200.

# kerf release notes

## v0.67.0 — switch-window step 5: the two-skin corpus closeout (verification equivalence + the E5 teardown evaluation basis)

The r103 round delivers the switch-window step 5's verification
face (switch-window-plan §1 step 5; stage0.md §9.98): ALL 85
acceptance-corpus cases driven through BOTH skins, the gate-B
fixpoint dual-caliber gate over phases 2/3, and the teardown
evaluation's quantified basis — the E5 batch-3 removal decision's
evidence ledger.

**The mechanical skin transcoder** (`kerf-driver/src/skin_transcoder.rs`):
the general face — one S-expression program, rendered on the target
skin (the inverse of the §9.26.9 skin dictionary, form by form),
with the round-trip naming guard lifted from the step-3 prefix
twins to whole programs (the strict Stx face, or the expanded
alpha face where the grammar normalizes — the single-wrapped let
pair, the do fold). Shape-mismatched special forms ride the
ordinary call face (the shared expander rejects them on BOTH skins
at the SAME stage — the parity mechanism); genuinely unspellable
forms join the exception ledger (errors are data): negative
literals in expression position (the target lexical face composes
them; `i64::MIN` has no positive counterpart), non-binary operator
calls, and macro declarations (the rules carry raw list data the
target expression grammar cannot pass — the registered gap).

**The 85-case two-skin sweep** (`target_corpus_sweep_tests.rs`):
60 cases transcode mechanically and hold on both skins (the
expectation contract via `validate_target` — the target-skin twin
of the Stage 1.4 validate face; value cases additionally ride the
three gates: alpha-equivalence + one semantic bytecode + one value
face); 11 hand-twin cases carry the families the transcoder cannot
(the eight parse-error rejections as crafted malformed target
programs, the two `i64::MIN` boundaries as arithmetic compositions,
the two ruling-D symbol-require rejections as path forms); five
grammar-design divergences are pinned AS SPEC (the ruling-C12 unit
`()` -> nil, the three keyword-headed malformed forms whose
rejection stage differs by reader design — permissive versus
grammar-directed, the fn-wrapped handler arm that makes the
literal-handler class E0007 unreachable on the target grammar);
nine macro-declaration cases join the registered ledger. The
corpus-face coverage: 71/85 both-skins (83.5%), every exception
accounted for by family.

**The gate-B fixpoint dual-caliber gate**: phases 2 and 3 of both
fixpoint drives, cross-skin. Phase 3 (the executed self-compiled
products) holds the FULL semantic digest; phase 2 (the self-applied
compilations) holds the FUNCS face with the coordinate exemption —
the round's own finding: the self-applied input embeds the item
records' span coordinates as quoted constants, so the two skins'
products legitimately differ in their constant pools (two source
texts, two coordinate sets) while the compilation logic agrees —
§9.25.4's cross-grammar layering applied to the fixpoint's
self-application phase.

**The E5 teardown evaluation basis** (switch-window-plan §5.6): the
production chain's replacement coverage (the five .ktf twins at the
three gates since r100, the target fixpoint + gate-B transitivity
since r101, the dual-caliber phases 2/3 this round) and the corpus
face's quantified ledger (71/85 both-skins, 14 registered
exceptions by family) — the batch-3 one-time removal decision's
criterion computation (self-built replacement >= 98% of the
replaced surface, or extra capability > 0) with the composed-chain
target drive registered as the remaining production-chain
verification item before the .krf originals' teardown.

Tests 1496 -> 1512 (+16: the sweep's ten, the transcoder's six
unit faces); audit 314 -> 324 (AF — the step-5 family, ten cases);
the six-command cold run all green.

## v0.38.0 — interlude: the VM execution-core round (materialization goes single-source and batch; the call window becomes one move)

The §9.69 review opens the first algorithm-level domain of the
execution core (EXC ruling family, 10 faces: 3 implemented, 6
maintained, 1 window registration). Distinct from §9.53 (the storage
domain: heap/GC/budget/roots) and the §9.44.3 census row 7 (the
dispatch form), this round audits the execution algorithm faces:
the call protocol's argument traffic, the operand-stack discipline,
and the constant-materialization budget protocol.

- **EXC-1 — `LiteralValue::pair_cells` single-sourced (kerf-core).**
  The literal cell-count helper existed as twins (`vm.rs
  materialize` and `eval.rs`'s `Literal` arm each carried a private
  recursive walker); the count now lives once on `LiteralValue`
  itself and both engines budget against the same method (§20.3
  same-path discipline).
- **EXC-2 — one `reserve_exact(n)` batch per materialization.** The
  per-cell reserve loop performed `n` identical budget checks (live
  usage only moves when `heap.alloc` runs in the walk that
  follows); both engines now charge the whole batch in one check
  under the same condition — the accept/reject boundary, the
  collect-then-retry point, and the success-path allocation totals
  are bit-identical (pinned from both sides by guards).
- **EXC-3 — `take_args` becomes one stack-window move.** The
  pop-loop + reverse (2×argc value moves per call) is now a single
  `split_off` of the argument window — the args leave the caller's
  stack in call order, one move each (the Lua OP_CALL
  register-window discipline expressed within safe-Rust per-frame
  stacks, K127).
- Maintained: the 24-arm match dispatch (threaded code needs
  label-as-value — not available in safe Rust; K129/K130), the
  whole-frame closure snapshot (Stage 2 capture window), the
  handler-stack reverse scan, the register-machine window (K131),
  the per-frame operand stacks (K126 — the single contiguous
  valuestack would fight the borrow checker; Pulley chose a register
  file for the same reason), and the fetch double-index form.
- Registered **W-VM-SUPERINSTR** (superinstruction/macro-op fusion
  window — Pulley's in-tree macro-op rationale K128 and BEAM's
  loader; trigger: a B-axis profile showing dispatch-bound hot
  spots; zero signal today).
- Frontier anchors **K126-K131** (CPython ceval/bytecodes call
  protocol + operand-stack-as-frame-region, Lua 5.4 lvm/ldo register
  windows, Wasmtime Pulley's safe-Rust register ISA guidelines, BEAM
  beam_emu dispatch commentary — the alignment experiment that
  *slowed* the emulator ~5%, OCaml interp.c computed-goto dispatch,
  and the register-vs-stack systematic comparisons). Weak-query
  disclosure round 15; the VEE'05 showdown full text was not
  fetchable this round (dead fetches registered honestly).
- Guards +4: `pair_cells` exact footprint counts (kerf-core), the
  batch boundary pinned from both sides (kerf-vm), the window-order
  call round-trip (kerf-vm), and the cross-engine budget-boundary
  parity (root `vm_seed_tests` — both engines accept budget 2 and
  reject budget 1 on the same three-cell quoted list).
- Baseline: **1201:0:0** (+4) + audit 200/200 + B-series all
  in-band (rule-5 rerun; vm/runtime/core sources touched).

## v0.37.0 — interlude: the checker work-state round (the typecheck tables join the single identity base)

The §9.68 review opens the NB-9 registered domain — the checker's
working state (CHK ruling family, 9 faces: 6 implemented, 2
maintained, 1 window registration). With this round the
single-identity base covers the whole pipeline: syntax tree,
CoreExpr, module loader, error family, expander tables, the run-time
name tables, and now the static checker's tables — the §9.52 chain
closes end to end.

**The check.rs module table (CHK-1/CHK-2).** `Table.defines
Vec<(String, DefineShape)>` and `Table.assigned HashSet<String>` were
text-keyed: every define paid one `to_owned()` heap allocation at
collection, every Var resolution a byte-string comparison on the
reverse scan — while the pool entry sat in hand (`ModuleItem::Define.
name` is already a `Symbol`). The table now clones the 4-byte entry:
collection allocates nothing, the reverse scan compares indices, the
assign guard set hashes on the entry (the position-aware visibility
slice `defines[..defined_so_far]` is untouched — walk order is the
definition identity, mirroring how rustc keys its checker contexts by
`LocalDefId`, not by name — K121).

**The infer.rs mirror (CHK-3/CHK-4/CHK-5).** The HM engine's
`DefineTable` had drifted from its check.rs mirror: `assigned` was a
`Vec<String>` with a manual scan-then-push dedup (check.rs already
used a `HashSet`). Both tables now share the exact `HashSet<Symbol>`
form (the §9.44 assigned-guard generalization obligation cleared),
the local environment entries (`LocalEntry.name`) clone the param/
binding entries the tree already holds, and the SCC call-graph
over-approximation (`collect_var_names`) collects pool identities —
the edge construction compares indices instead of byte strings
(`r == name`, the GHC `Unique` fast-comparison discipline — K122).

**The externals boundary (CHK-6).** `Externals` keeps its `&str`
construction face (callers hold authoritative text —
`STAGE0_GLOBALS`/`Builtin::ALL` at the three consumption sites) but
interns at construction and resolves by identity:
`resolve(&Symbol)`. A floor-rejected externals name fails fast (it
could never match a Var — those are validated Symbols; the
`builtin_symbol` seeding face uses the same discipline — NB-5). The
rustc resolver's `Rib` bindings are keyed the same way
(`FxIndexMap<Ident, R>` — interned identity, insert-ordered — K123);
OCaml's classic HM environment is `Ident`-keyed, never string-keyed
(K124).

**Maintained (CHK-7/CHK-8).** The 18-arm ad-hoc builtin dispatch
(`builtin_type`) keeps its str-literal match arms — a static
dispatch face (a runtime pool index cannot literal-match; K125
supports keeping literal dispatch at static faces). The
Vec-plus-reverse-scan shapes stay (defines table, local environment,
externals table): insert order carries the position-aware visibility
and last-wins shadowing semantics — a hash map would break the
visibility slice and add iteration-order hazards (§9.55); at module
scale the linear scans are noise (the B axes do not cross typecheck
— zero signal).

**Registered window (CHK-9).** W-CHK-DEFINE-HASH covers the
escalation of the define/environment reverse scans to hash indexes —
trigger: a B axis attributes cost to define-resolution scans. Zero
signal today.

Workspace: 1197:0:0 (+3 pool-identity guards), audit 200/200, B
series all in-band (B3 keeps the §9.67 −34.3% eval improvement at
6.78ms; B4 deterministic counters bit-identical), zero new
dependencies, TD open items 0.

## v0.36.0 — interlude: the name backend round (the run-time name tables join the single identity base)

The §9.67 review opens the TRF-13 registered domain — the name-based
back half (NB ruling family, 9 faces: 6 implemented, 2 maintained,
1 domain registration). With this round the single-identity base
covers the whole pipeline: syntax tree, CoreExpr, module loader,
error family, expander tables, and now the run-time name tables.

**The evaluator's name tables (NB-1/NB-2/NB-3/NB-4).** The
evaluator's globals (`HashMap<String, Value>`), binding-site
environment (`Vec<(String, usize)>`), handler stack
(`Vec<(String, Value)>`), and closure names (`Option<String>`) were
text-keyed: every define/assign stored a fresh `String`, every Var
fallback and every resolve step paid a full-text hash or byte
comparison — while the pool entry (`Symbol`) sat in hand at every
call site (`CoreExpr::Var.name`, `params: &[Symbol]`,
`clause.effect`). All four tables now key on the interned entry: a
4-byte clone per store, a 4-byte comparison per scan step, zero
allocation per binding (params and lets clone the entry they
already hold).

**The arity payload (NB-5).** `ArityMismatch.func` was the error
family's last text identity payload (a fresh `String` per error,
`#<anonymous>` invented per anonymous-closure error). It is now
`Option<Symbol>` — `None` renders `#<anonymous>`, mirroring the
`UnboundGlobal`/`UnhandledEffect` payload faces. The 18 builtin
names intern once per process through a `OnceLock` table derived
from `Builtin::ALL` (the single text source — the derived table
cannot drift, guard-pinned; the `rustc_span::sym` pre-interning
discipline).

**Identity observation faces (NB-7).** `Evaluator::global_sym`,
`Vm::global_names`, `Vm::global_sym`, and `RunOutcome::global_sym`
join the existing text faces. The driver's VM branch snapshots the
bytecode's own global name table (it is already `Vec<Symbol>` — no
de-intern of the roster); the eval branch reads the Define names as
pool entries; the parity face resolves each Define by interned
identity (the repr column stays text — the rendering protocol
face). The §9.60.5 dual contract is unchanged (which names appear
in a snapshot follows the same three clauses).

**Maintained (NB-6/NB-8).** The VM's global hot path resolves at
compile time — `instr.a` is the pool index of the bytecode's global
table, so `LdGlobal`/`StGlobal` never look up a name at run time
(CPython pays runtime dict lookups per LOAD_GLOBAL and amortizes
them with adaptive specialization — K116; the compile-time form is
the stronger shape, now documented). A new registration window
W-NAME-INLINE-CACHE covers the more aggressive forms (inline
caches, slot NaN-boxing) — zero signal. The text observation faces
(`global(&str)` on all three types) stay linear scans so a miss
query never pollutes the interning pool.

**Registered next domain (NB-9).** The typechecker's working state
— `CheckerState.defines: Vec<(String, DefineShape)>` and
`assigned: HashSet<String>` — is the identity base's last
text-keyed remainder (the §9.50 checker review predates the §9.52
single-pool unification); registered as the next candidate domain.

**Guards (+3) and baselines.** 1191:0:0 → **1194:0:0** (+3: the
derived builtin-symbol table matches the registry and the pool; the
evaluator's name tables round-trip through the single pool with
miss-non-pollution; the halt snapshots carry pool identities on
both engines). audit 200/200; doc warnings 1 (the registered
cargo#6313 collision, unchanged); B-series rerun per §14.6.4 rule
5: **B3 eval-run-fib20 10.345ms → 6.796ms (−34.3%) — the round's
main account** (the meta-circular evaluator's name face went
zero-text), B1/B1a/B1b/B1c bit-identical after the first-run
cross-session variance converged (7.7µs / 1.4µs / 3.6µs / 1.5µs),
B2/B5 in-band, B4 deterministic counts bit-identical (gc-cycles 1,
swept 1023). Frontier anchors K116-K120 (CPython ceval/bytecodes
LOAD_GLOBAL specialization, Lua lstring.c interning discipline,
Lua _ENV globals + the prestrings experiment, V8 InternalizedString
canonicalization, Chez symbol uniqueness). 8 primitives invariant
verified for the 40th round (run-time name tables are keying and
allocation shape — syntax, expansion, and the VM instruction stream
untouched; dual-engine equivalence pinned by the 79-corpus parity
replay and the 200-case audit); zero new dependencies; weak-query
disclosure round 13 (q1/q5/q6 garbage, q2 weak — six primary
sources read in full instead; the m6 C0VM PDF fetch 404'd and was
not archived, the constant-pool knowledge rides the q7 snippet).

## v0.35.0 — interlude: the expander lexical/transformer identity round (the frame tables and the pattern machine join the single identity base)

The §9.66 review opens the EXP-13 registered domain — the expander's
own working state (TRF ruling family, 13 faces: 8 implemented, 4
maintained, 1 domain registration).

**Frame tables (TRF-1/TRF-2/TRF-3).** `Frame.names` and
`Frame.macros` were text-keyed (`HashSet<String>` /
`HashMap<String, usize>`) with a fresh `String` allocation on every
bind; `resolve`/`resolve_macro` de-interned the tree's `Symbol` to
run text lookups. Both tables now key on the pool entry — the
caller hands over the `Symbol` the syntax tree already carries
(rustc's resolver tables are keyed the same way: `Ident { name:
Symbol }`, `macro_use_prelude: FxIndexMap<Symbol, _>` — K111/K112),
and the `STAGE0_GLOBALS` fallback runs over a pre-interned
`OnceLock<HashSet<Symbol>>` seeded once (the `rustc_span::sym`
pre-interning discipline — K113).

**The pattern machine (TRF-4/TRF-5/TRF-7).** `Pattern::Literal` and
`Pattern::Var` carry pool entries (index comparison per match
position instead of byte comparison); the bindings map inserts a
4-byte pool-entry clone where it used to heap-clone a `String` per
pattern variable per attempt; the rename stack is
`Vec<(Symbol, Symbol)>` and `fresh_name` interns its genuinely-new
target once.

**The trigger set (TRF-6).** Every macro instantiation used to
re-seed the rename-on-capture trigger set from scratch:
`STAGE0_GLOBALS.iter().map(to_owned)` (18 strings) +
`RESERVED_MACRO_NAMES` (15 strings) + one `to_owned` per distinct
symbol in every spliced argument — ~45+ `String` allocations per
macro use, on the hottest expander path. The set now holds pool
entries; the static tables are pre-interned once and copied entry by
entry. Zero text allocation per instantiation (B1b in-band at
3.6µs vs 3.7µs recorded).

**Call-site discipline (TRF-8).** `expand_symbol`/`expand_set` feed
the pool entry straight into `resolve`; `expand_fn_binding` binds
params by entry; `define`/`define-syntax` bind entries. The one
text crossing left is the core checked-constructor boundary
(`var`/`fn_`/`assign`/`Binding::new` take `&str` — the §9.58
established design, K110 intern-once-at-boundary; the pool-hit
re-intern is a hash lookup, zero allocation). Maintained:
constructor signatures stay (TRF-9 — the 67-site ripple is not
justified by two hash lookups); literal text-matching semantics
stay (TRF-10 — under the single-pool invariant text equality and
pool equality coincide, the R6RS free-identifier=? unbound-tier
equivalence, K114); `Pattern::Atom::Str` stays a value payload
(TRF-11); `fresh_name` keeps its one `format!` (TRF-12, the MX-1
mangled-record precedent).

**A survey dividend: the doc-warning backlog cleared (22 → 1).**
The round's baseline verification exposed that previous rounds'
`tail -2` verification masked 22 pre-existing `cargo doc` warnings
(intra-doc links to private items across five crates, bare
`funcs[0]` parsed as reference links, cross-crate `Bytecode::*`
links). All sixteen fixable warnings are cleared this round (doc
comments only, zero semantic change); the one remaining warning is
the cargo output-filename collision (cargo#6313 — bin `kerf` and
lib `kerf` share a doc path; not fixable in-tree without renaming a
public target — registered maintained).

**Registered next domain (TRF-13).** The name-based back half —
`CoreExpr::Var` → bytecode globals table → VM/eval
`HashMap<String, Value>` — is the reason the rename-on-capture
bridge exists; it is registered as the next candidate domain (the
VM stays the permanent Rust base; key-type evolution is a semantic
face needing its own frontier review).

**Guards (+3) and baselines.** 1188:0:0 → **1191:0:0** (+3: the
frame tables round-trip through the single pool; literal matching
judges by the pool entry; static name tables are pre-interned pool
entries). audit 200/200; B-series rerun all in-band (B4
deterministic counts bit-identical: gc-cycles 1, swept 1023);
frontier anchors K111-K115 (rustc_span Ident/Symbol, rustc_resolve
macro_use_prelude, rustc_span::sym pre-interning, R6RS 12.8
free-identifier=? two-tier semantics, Dybvig 1992 syntax-case
literal matching — snippet-level). 8 primitives invariant verified
for the 39th round (identity keying is a table/keying change:
syntax surface, expansion behavior, and the VM untouched); zero new
dependencies; weak-query disclosure round 12 (q1/q2/q5/q7 garbage
— four primary sources read in full instead).

## v0.34.0 — interlude: the expander error payload round (the error family joins the single identity base)

The §9.65 review opens the expander error payload domain — the
MOD-11 maintained item promoted to a full EXP ruling family (13
faces: 6 implemented, 6 maintained, 1 domain registration).

**Identity payloads (EXP-1/2/4/5).** Four identity-bearing error
payloads were text copies made at construction sites where the
interned identity was already in hand: `UnboundIdentifier.name` and
`MacroPatternMismatch.name` (the syntax tree's `Symbol`, bridged to
`&str` and copied back out as `String`), `CoreError::DuplicateParam`
(the constructor had just built the `Vec<Symbol>` and re-copied the
text on the error path), and `CoreError::DuplicateHandler` (the
clause's effect was already a `Symbol`, de-interned only to be
re-owned). All four now carry `Symbol` — a 4-byte clone, never a
text copy. `Display` renders byte-identically through the `as_str`
bridge; the hand-written `Symbol` Debug keeps the derived shape
(`Symbol { text: "x" }`), and no golden pins an `ExpandError` Debug
rendering. Equality strengthens from text equality to pool-entry
equality — the exact contract the .krf parity decoder relies on.

**The transformer source chain (EXP-3).** `SyntaxRules::parse` took
`&str`, owned it as `String`, and cloned the `String` into every
mismatch error: two allocations per declaration plus one per error,
and a phantom failure path (the name was already validated by the
checked constructor, so an in-parse `Symbol::new` could never fail —
yet the signature demanded the error be handled). The parse now
takes the `Symbol` itself: the declaration identity flows from the
syntax tree, the mismatch error clones the pool entry, and the
phantom failure surface is gone.

**The parity decoders (EXP-6).** Four error-reconstruction sites
(unbound, macro-mismatch, dup-param, dup-handler) rebuild their
payloads through the single pool (`Symbol::new`), matching the
v0.33.0 MOD-1 decoder precedent — the .krf oracle protocol (a
`Value::Str` payload) is unchanged on the selfhost side.

**Maintained faces.** `MalformedForm` keeps `&'static str` (a closed
static set — the K107 three-tier discipline: identity = Symbol,
non-identity text = String, static descriptors = `&'static str`);
numeric and enum payloads keep their shapes; `InvalidSymbol` keeps
its `String` text by design (the rejected text cannot be interned by
definition — a fail-closed payload has no identity to carry);
span-only variants carry no identity at all. `krf_name` stays
String-typed for the dump/rebuild text-protocol faces.

**Registration (EXP-13).** The expander's lexical tables
(`Frame.macros`, `bind`/`bind_macro` `&str` keys) and the transformer
internals (literals, bindings, renames) are registered as the next
candidate domain — resolution is a hot path, a different
performance/identity trade than the cold error path (the K110
mitigation argument does not transfer).

Anchors: K107 (rustc_resolve diagnostics — the payload three-tier
discipline), K108 (rustc DiagArgValue `Cow<'static, str>` bridge),
K109 (Racket `raise-syntax-error` — the name is a symbol extracted
from the syntax object; the dedicated `exn:fail:syntax:unbound`
subfamily), K110 (rustc_span `Symbol` — Copy u32 newtype; the
DroplessArena permanence trade-off registered head-on: the defect
face is memory that never frees, the mitigation is that names are
already interned by the front end and errors are cold paths).

Tests: 1185 → 1188:0:0 (+3 guards — the pool round-trip family:
expander error payloads, transformer registered identity, core
duplicate payloads), audit 200/200. Eight-primitive invariance
re-verified (38th round — the error family is a diagnostics face,
not a semantic one: expansion behavior is unchanged).

## v0.33.0 — interlude: the module-system round (the loader joins the single identity base, and the collection order tells the truth)

The §9.64 review opens the module-system domain — the last
pipeline-surface code domain that had never had a dedicated section
(the declaration layer, the loading layer, and every consumer face:
compiler flat walk, evaluator flattening, checker skip arms, driver
assembly, REPL accumulated replay, corpus).

**Identity (MOD-1).** The loading layer keyed every module — the
declaration map, the declaration order, the DFS colors, the cycle
path, the error payloads, the load plan — on `String` copies of
interned `Symbol`s: a de-interned text bridge, one allocation per
lookup per edge per visit, the last text-identity face left on the
pipeline after the §9.58 single-pool unification. The layer now keys
on `Symbol` throughout: `ModuleError` payloads carry the interned
identity, `LoadPlan::order()` returns `&[Symbol]`, and the parity
fixture decoders reconstruct through the single pool. `Display`
rendering is byte-identical — every pinned golden (corpus parity,
audit J, module unit tests) survives unchanged.

**The collection order (MOD-2).** Two doc comments claimed
"first-seen declaration order"; the 0.9 collection walk was a LIFO
stack that recorded cross-level nested modules in reverse encounter
order (a1 under a, then b1 under b, recorded b1 first). The walk is
now an iterative pre-order iterator stack — a module is recorded the
moment it is encountered in source reading order, children before
later siblings, no recursion (hand-built trees can nest arbitrarily
deep; the loader never recurses on untrusted shapes). A guard test
pins the cross-level case (a, a1, b, b1). The edge walk keeps its
deterministic LIFO shape — the cycle path and triggering span it
selects are corpus- and parity-pinned, and no doc claim was attached
to it.

**Duplicate defines, recorded (MOD-3).** Duplicate *module*
declarations are rejected fail-closed (ModuleDuplicate); duplicate
*define* names are not rejected anywhere — flat compilation and
evaluation both store the last definition into the same global slot,
engines symmetric, parity observing every define. That is the Stage 0
flat-namespace semantics, now written down where it lives (the
loading-layer header). The module-body duplicate semantics
(single-assignment constants — the Racket two-face model, K104:
module-body identifiers without set! are constants, re-declaration
not generally allowed, REPL re-declaration may fail on constant
redefinition) is registered as the Stage 1 module-system window
(W-MOD-DUP-DEFINE); implementing it ahead of its stage would be
premature — the registered-theory discipline holds.

Six commands all green; 1185:0:0 (the +1 is the MOD-2 order guard);
audit 200/200; review anchors K102-K106 (Rust Reference module tree;
Racket module syntax name/path split; Racket module-body constants;
Chez libraries/top-level-program two-face; rustc E0428 duplicate
wording) — ten consecutive rounds of weak-query disclosure, all
carried by primary-source direct reads.


# kerf release notes

## v0.67.0 — switch-window step 5: the two-skin corpus closeout (verification equivalence + the E5 teardown evaluation basis)

The r103 round delivers the switch-window step 5's verification
face (switch-window-plan §1 step 5; stage0.md §9.98): ALL 85
acceptance-corpus cases driven through BOTH skins, the gate-B
fixpoint dual-caliber gate over phases 2/3, and the teardown
evaluation's quantified basis — the E5 batch-3 removal decision's
evidence ledger.

**The mechanical skin transcoder** (`kerf-driver/src/skin_transcoder.rs`):
the general face — one S-expression program, rendered on the target
skin (the inverse of the §9.26.9 skin dictionary, form by form),
with the round-trip naming guard lifted from the step-3 prefix
twins to whole programs (the strict Stx face, or the expanded
alpha face where the grammar normalizes — the single-wrapped let
pair, the do fold). Shape-mismatched special forms ride the
ordinary call face (the shared expander rejects them on BOTH skins
at the SAME stage — the parity mechanism); genuinely unspellable
forms join the exception ledger (errors are data): negative
literals in expression position (the target lexical face composes
them; `i64::MIN` has no positive counterpart), non-binary operator
calls, and macro declarations (the rules carry raw list data the
target expression grammar cannot pass — the registered gap).

**The 85-case two-skin sweep** (`target_corpus_sweep_tests.rs`):
60 cases transcode mechanically and hold on both skins (the
expectation contract via `validate_target` — the target-skin twin
of the Stage 1.4 validate face; value cases additionally ride the
three gates: alpha-equivalence + one semantic bytecode + one value
face); 11 hand-twin cases carry the families the transcoder cannot
(the eight parse-error rejections as crafted malformed target
programs, the two `i64::MIN` boundaries as arithmetic compositions,
the two ruling-D symbol-require rejections as path forms); five
grammar-design divergences are pinned AS SPEC (the ruling-C12 unit
`()` -> nil, the three keyword-headed malformed forms whose
rejection stage differs by reader design — permissive versus
grammar-directed, the fn-wrapped handler arm that makes the
literal-handler class E0007 unreachable on the target grammar);
nine macro-declaration cases join the registered ledger. The
corpus-face coverage: 71/85 both-skins (83.5%), every exception
accounted for by family.

**The gate-B fixpoint dual-caliber gate**: phases 2 and 3 of both
fixpoint drives, cross-skin. Phase 3 (the executed self-compiled
products) holds the FULL semantic digest; phase 2 (the self-applied
compilations) holds the FUNCS face with the coordinate exemption —
the round's own finding: the self-applied input embeds the item
records' span coordinates as quoted constants, so the two skins'
products legitimately differ in their constant pools (two source
texts, two coordinate sets) while the compilation logic agrees —
§9.25.4's cross-grammar layering applied to the fixpoint's
self-application phase.

**The E5 teardown evaluation basis** (switch-window-plan §5.6): the
production chain's replacement coverage (the five .ktf twins at the
three gates since r100, the target fixpoint + gate-B transitivity
since r101, the dual-caliber phases 2/3 this round) and the corpus
face's quantified ledger (71/85 both-skins, 14 registered
exceptions by family) — the batch-3 one-time removal decision's
criterion computation (self-built replacement >= 98% of the
replaced surface, or extra capability > 0) with the composed-chain
target drive registered as the remaining production-chain
verification item before the .krf originals' teardown.

Tests 1496 -> 1512 (+16: the sweep's ten, the transcoder's six
unit faces); audit 314 -> 324 (AF — the step-5 family, ten cases);
the six-command cold run all green.

## v0.32.0 — interlude: the resource-limits round (the ladder gets a single source, and the termination argument becomes a chain)

The §9.63 review opens the resource-limits and budget-governance
domain — survey-segment gap identification, fifth case: the limits
family was scattered across five crates, each site locally documented
and locally boundary-tested, but never governed as a ladder. The
layering (256 → 512 → 512 → 1024 → 2048, plus the 8Mi allocation
budget) existed only as pairwise comments; nothing asserted the
ratios; three load-bearing facts for termination lived in three
separate comments.

**The ladder, single-sourced (LIM-1).** A new root-tree guard test
pins all six constants at their exact values and asserts the
relational invariants. The expander-over-reader and
compiler-over-expander headroom ratios are spelled as const blocks —
drift now breaks the build, not just a test run. The two 512s
(expansion and inference) are cross-asserted so they cannot drift
apart silently.

**The termination argument, as a chain (LIM-3).** The Stage 0 subset
has no loop primitive (§9.45); the VM does no tail-call reuse (every
closure call pushes a frame); every frame and heap cell is a budget
charge against the LIVE footprint. Therefore every non-terminating
program grows the live usage monotonically and ends in a structured
`BudgetExceeded` — never a hang. The guard test
`vm_budget_catches_non_terminating_programs` is that argument made
executable: read → expand → compile → run under budget 64 → the
structured error, end to end.

**Exact boundaries (LIM-7).** A probe pinned the single-call
program's peak live usage at exactly three units (entry frame + the
define's closure cell + the call frame): budget 3 admits it, budget
2 rejects it at the call frame. The first draft guessed two — the
closure cell was missed — the probe caught it, and the miss is on
record. The budget is exact, not approximate.

**Maintained against the frontier (K98-K101).** rustc's
recursion_limit (default 128, crate-attribute-tunable) and GCC's
-ftemplate-depth (default 900, flag-tunable) are both depth-only —
as is kerf; a macro's sibling fan-out (a breadth bomb) remains
unbounded by any depth cap, and the industry takes the same stance
under the same threat model (developer-owned source, not untrusted
input). The escape hatch is registered: W-EXP-WORK, with wasmtime's
fuel/epoch dichotomy (K100 — deterministic-but-instrumented vs
cheap-but-cooperative) as the reference when an untrusted-input
scenario (LSP) ever arrives. kerf's allocation-granularity charging
is a third form: deterministic, zero instrumentation cost, and
sufficient only because the language has no loops — the
construction that makes the argument work. Racket's expand pass
recurses without a published numeric cap (K101); kerf's explicit 512
is the more defensive shape. Two more windows: W-LIMIT-TUNABLE
(attribute/flag tunability when real programs legitimately exceed a
limit) and W-REPL-ACC-GROWTH (session accumulation).

Six commands green: fmt clean, build/check/clippy 0/0, test
1180 → 1184:0:0 (+4 guard family), audit 200/200. Eight-primitive
invariance round thirty-six: zero new primitives, zero channels,
zero VM changes, zero syntax, zero EBNF — crates/*/src untouched
this round (a pure root-tree test + documentation increment; the
six constants and every charging site are exactly as they were).

# kerf release notes

## v0.67.0 — switch-window step 5: the two-skin corpus closeout (verification equivalence + the E5 teardown evaluation basis)

The r103 round delivers the switch-window step 5's verification
face (switch-window-plan §1 step 5; stage0.md §9.98): ALL 85
acceptance-corpus cases driven through BOTH skins, the gate-B
fixpoint dual-caliber gate over phases 2/3, and the teardown
evaluation's quantified basis — the E5 batch-3 removal decision's
evidence ledger.

**The mechanical skin transcoder** (`kerf-driver/src/skin_transcoder.rs`):
the general face — one S-expression program, rendered on the target
skin (the inverse of the §9.26.9 skin dictionary, form by form),
with the round-trip naming guard lifted from the step-3 prefix
twins to whole programs (the strict Stx face, or the expanded
alpha face where the grammar normalizes — the single-wrapped let
pair, the do fold). Shape-mismatched special forms ride the
ordinary call face (the shared expander rejects them on BOTH skins
at the SAME stage — the parity mechanism); genuinely unspellable
forms join the exception ledger (errors are data): negative
literals in expression position (the target lexical face composes
them; `i64::MIN` has no positive counterpart), non-binary operator
calls, and macro declarations (the rules carry raw list data the
target expression grammar cannot pass — the registered gap).

**The 85-case two-skin sweep** (`target_corpus_sweep_tests.rs`):
60 cases transcode mechanically and hold on both skins (the
expectation contract via `validate_target` — the target-skin twin
of the Stage 1.4 validate face; value cases additionally ride the
three gates: alpha-equivalence + one semantic bytecode + one value
face); 11 hand-twin cases carry the families the transcoder cannot
(the eight parse-error rejections as crafted malformed target
programs, the two `i64::MIN` boundaries as arithmetic compositions,
the two ruling-D symbol-require rejections as path forms); five
grammar-design divergences are pinned AS SPEC (the ruling-C12 unit
`()` -> nil, the three keyword-headed malformed forms whose
rejection stage differs by reader design — permissive versus
grammar-directed, the fn-wrapped handler arm that makes the
literal-handler class E0007 unreachable on the target grammar);
nine macro-declaration cases join the registered ledger. The
corpus-face coverage: 71/85 both-skins (83.5%), every exception
accounted for by family.

**The gate-B fixpoint dual-caliber gate**: phases 2 and 3 of both
fixpoint drives, cross-skin. Phase 3 (the executed self-compiled
products) holds the FULL semantic digest; phase 2 (the self-applied
compilations) holds the FUNCS face with the coordinate exemption —
the round's own finding: the self-applied input embeds the item
records' span coordinates as quoted constants, so the two skins'
products legitimately differ in their constant pools (two source
texts, two coordinate sets) while the compilation logic agrees —
§9.25.4's cross-grammar layering applied to the fixpoint's
self-application phase.

**The E5 teardown evaluation basis** (switch-window-plan §5.6): the
production chain's replacement coverage (the five .ktf twins at the
three gates since r100, the target fixpoint + gate-B transitivity
since r101, the dual-caliber phases 2/3 this round) and the corpus
face's quantified ledger (71/85 both-skins, 14 registered
exceptions by family) — the batch-3 one-time removal decision's
criterion computation (self-built replacement >= 98% of the
replaced surface, or extra capability > 0) with the composed-chain
target drive registered as the remaining production-chain
verification item before the .krf originals' teardown.

Tests 1496 -> 1512 (+16: the sweep's ten, the transcoder's six
unit faces); audit 314 -> 324 (AF — the step-5 family, ten cases);
the six-command cold run all green.

## v0.31.0 — interlude: the user-surface round (REPL incompleteness family + declaration-heads single source + CLI strictness and engine flag)

The §9.62 review opens the user-interaction surface domain: the CLI
(`cli.rs`), the REPL (`repl.rs`), and the diagnostic renderer
(`render.rs`) — 1743 lines of real code that every prior segment had
only ever side-audited as a "consumer" of the pipeline, diagnostics,
or orchestration domains. The survey lineage (§9.43-§9.61) had twelve
pipeline-stage segments plus measurement methodology; the layer where
the user actually meets the compiler had none.

**The incompleteness family, unified (SURF-1).** The reader
distinguishes two ways input can end mid-structure: an unclosed list
(`UnclosedList`) and an unterminated string (`UnterminatedString`).
The REPL mapped only the first to its continuation event; an
unterminated string was rejected on the spot — so a multi-line string,
a shape file mode has always accepted (raw newlines inside string
literals, Scheme tradition), was unreachable from the REPL. Both
incompleteness variants now produce NeedMoreInput; the malformed
family (bad escapes, stray closes, bad numbers, over-deep nesting)
still errors immediately. Multi-line strings now build across
submissions exactly like multi-line lists.

**The declaration-heads single source (SURF-2).** The REPL classifies
submissions by head: declarations pass through, expressions wrap into
`$repl:N` defines. That classification lived in a second hand-kept
list in the driver while the expander's dispatch table held the truth
— a silent-drift risk the moment Stage 2 grows a new top-level form.
The expander now exports `TOP_LEVEL_DECLARATION_HEADS` as the single
source, enforced by a gate-then-dispatch structure: a const member
with no dispatch arm falls to a fail-closed arm and fails the
const-vs-arm sync test; an arm without a const member is unreachable
dead code. The driver consumes the const; the hand-kept twin retires.
A behavioral guard on the driver side pins the other direction: every
declaration head, when wrapped into a define, is rejected by the
pipeline — the invariant that makes pass-through classification
necessary.

**CLI strictness and the engine flag (SURF-3/SURF-5).** `--version`
gains the same trailing-argument strictness as `--help` (before,
`kerf --version foo` silently ignored `foo`). `kerf repl` gains
`--engine vm|eval` — the run command always had the choice, the
library always had the capability (`Repl::with_options`), but the
eval engine was unreachable from the binary. The greeting stops
saying "one form per line" — the REPL has always accepted multi-line
forms; the banner now says what the machine does.

**Maintained against the frontier (K92-K97).** miette renders its
fancy layer (unicode-width carets, ANSI color, terminal sizing) as a
feature-gated option — kerf's char-count, colorless, deterministic
core is the pre-fancy position, with width, color, and a JSON
emitter registered as windows (W-RENDER-WIDTH/COLOR/JSON; rustc's
dual human+JSON emitter is the anchor for the third). MIT Scheme's
error REPLs nest — a level-2 REPL over a waiting level-1, with a
restart menu; kerf's transactional rollback is the determinism-first
alternative (a nested REPL's session state is not expressible as
source text, which the tape-replay semantics require). clap's
`exit_code` contract — usage errors exit 2 — is exactly kerf's
0/1/2. The gcc/rustc source-line-plus-caret default shape is exactly
kerf's. Maintained, with the reasoning on record.

Six commands green: fmt clean, build/check/clippy 0/0, test
1180:0:0 (+9: the expander sync guard, four REPL tests, four CLI
tests), audit 200/200. Eight-primitive invariance re-verified
(round thirty-five): zero new primitives, zero channels, zero VM
changes, zero syntax additions, zero EBNF — the surface round is
wrapping and flags only.

## v0.30.0 — interlude: the performance-engineering round (benchmark methodology v2 + the §14.6.4 rule-5 relapse repair)

The §9.61 review opens the performance-engineering domain: the one
cross-cut the §9.44-§9.60 survey lineage had never visited. Every
pipeline stage, the bootstrap segments, memory, determinism,
diagnostics, test infrastructure, crate boundaries, forwarding, and
the driver orchestration had each had a dedicated segment — but the
measurement methodology itself (the empirical face that every
§9.44.3 quantified switch trigger ultimately appeals to) had never
been audited.

**Methodology v2, implemented.** Three frontier adjudications land as
code: (1) optimizer fences — every measured region now takes its
source input through `std::hint::black_box` (K90: a best-effort
discipline, not a guarantee — the limitation is documented in the
harness header so nobody mistakes the fence for a hard one);
(2) warmup — each axis runs `max(3, iters/10)` unrecorded iterations
before its measured loop, so cold caches and first-touch faults land
outside the sample set; (3) four-statistic reporting —
mean/median/min/stdev, with median keeping the primary-criterion seat
and stdev+min exposing outlier contamination that mean/median alone
would hide.

**The sub-axis split (PERF-3).** B1 keeps its composite shape (whole-
chain comparability with every recorded reading since 2026-09-28) and
gains three sub-axes: B1a read 1.4µs, B1b expand 3.5µs, B1c
compile+verify 1.5µs — the stage-attribution face the §9.44.5 trigger
table always demanded but the composite number could never provide.
The sub-axis physics (B1a+B1b+B1c < B1 composite — hotter per-stage
caches) is documented in the baseline file; the two readings are
reported side by side and never derived from each other.

**The rule-5 relapse, repaired in the open.** §14.6.4 rule 5 requires
a B-series re-run on every production-face round. The last recorded
re-run was v0.23.0 (T29): ten rounds lapsed with no reading — and two
of them (T33 diagnostics positions, T35 Symbol single-pool) touched
the compile chain. This round re-runs the full series and the verdict
is clean: B1 7.7µs matches the v0.23.0 reading exactly, B4's
deterministic counters (1 cycle/iter, 1023 swept/iter) match the
2026-09-28 first recording bit-for-bit — the lapse hid no regression,
and the relapse is repaired structurally: the trigger formulation is
widened to cover representation-layer changes, a per-round recheck
item is added, and a new guard test pins the churn program's exact
per-run counters (any GC-semantics drift now trips a test, not a
ten-round silence).

**Docs-reality repair.** benchmarks/README.md claimed "crate
micro-benchmarks go in each crate's benches/" — zero crates have a
benches/ directory. The unimplemented promise is retired into a
registered window (W-PERF-CRATE-BENCH) with an honest trigger: open
only when sub-axis attribution shows an in-crate hotspot the B-series
cannot characterize. Zero-signal, window stays closed.

**Tooling adjudication.** criterion-class statistics tooling would be
the project's first external dependency in a zero-dependency codebase;
the informed ruling stays std-only — `black_box` is std, the fence/
warmup/reporting needs are met without a single new dependency, and
W-PERF-CRITERION registers the escape hatch (trigger: the ±25% band
provably fails, twice, on real regression judgments).

8-primitive invariance: thirty-fourth verification (zero new
primitives, zero channels, zero VM changes, zero syntax, zero EBNF —
the harness change is measurement methodology only; every workload
source string is byte-identical with the pre-change harness, and the
full suite plus audit pass unchanged). Tests 1169 -> 1171 (+2: the
B4 deterministic-counter pin and the methodology-presence source
guard). Audit 200/200.

## v0.29.0 — interlude: the driver-orchestration round (error-propagation ruling + globals roster single-sourcing)

The §9.60 review opens the eighteenth segment of the pipeline survey
lineage: seventeen prior segments (§9.43-§9.59) had covered every
pipeline stage's data structures, the three bootstrap segments, the
backend rows, the checker, interning, memory, determinism,
diagnostics, test infrastructure, and the two-step crate-boundary
cleanup — but the orchestrator itself (pipeline.rs, the glue that runs
all phases in order and the host of the typecheck() ×4 action anchor)
and the error-propagation policy (why each layer returns what it
returns) had never had a dedicated review.

**The asymmetry, ruled in writing.** The survey found the four-layer
error shape asymmetric on purpose, not by drift: reader, expander,
compiler, and runtime return single-error `Result` (fail-fast — each
consumes the previous stage's complete product, and runtime effects
are not rollbackable), while typecheck returns collected batches
(one run surfaces every finding — the diagnostic value of a pure
analysis). Even the check/run divergence is principled: `check`
keeps compiling after a checker error to append more findings (a pure
function, no side effects), `run` aborts before either engine starts
(effects must not begin). This ruling (ERR-PROP) previously lived in
three scattered comments; §9.60.3 is now its single source.

**The frontier verdict, primary-source quadruple-read.** K84
(rustc-dev-guide, the driver chapter): rustc_driver "acts as the glue
for running the various phases of the compiler in the correct order" —
kerf's hardcoded sequence is the same shape minus the `Callbacks`
phase-hook face, justified by scale (three in-house consumer faces,
no third-party driver need; a new W-ORCH-CALLBACK window registers
the trigger). K85 (the lexing-and-parsing chapter): rustc's
`ParseSess`-bound lexer/parser vs kerf's stateless pure-function
reader — both valid at their respective scales, kerf's choice kept
deliberately for parity-face determinism. K86 (oxc.rs "Dealing with
Errors", read in full): the recovery spectrum is three-valued —
fully recoverable (Biome; the linter/formatter need), partially
recoverable (most JS parsers; deterministic-grammar recovery), and
the panicking parser. **kerf's reader sits lawfully on the panicking
seat**: S-expression prefix notation has no unambiguous recovery
point, the parity semantics of a recovered partial AST is undefined,
and the 79-corpus error axis asserts byte-exact single-error output.
K87 (the diagnostic-structs chapter): rustc's `#[derive(Diagnostic)]`
attribute machinery is a 10^3-diagnostic-scale tool; kerf's
hand-written six-converter face at 10^1 scale is the right size.

**The ruling, ★ORCH-1 — two contracts, not two sources.** The survey
first read `run()`'s roster extraction as a single-source-of-truth
gap (VM branch reads `bc.globals`, the Eval branch and the
`run_parity` loop walk `self.items`) and unified all three on the AST
— **and the golden face rejected that reading loudly**: vs01-vs10
failed (`globals` must read `+=#<builtin:+> r=3`), because
`bc.globals` is not a Define-sequence projection at all. The full
re-audit of `intern_global`'s five call sites (LoadGlobal references,
set! targets, Perform and PushHandler effect names, defines) shows
the truth: `bc.globals` is the *global name table*, interning every
name the bytecode can reach — including builtin references. The
correct ruling is that the three rosters are three different
contracts, each already right: the VM branch reports the full global
table (the vs golden face), the Eval branch walks the defines (the
ve point-query face), and parity compares both engines over the
define roster. `run()` keeps its original shape with the contract now
written down ("by contract, not by drift"), and the new guard in the
compiler's tree pins the real invariant: a pure-define program
interns exactly the define sequence, and a vs01-shaped program pulls
the referenced builtin `+` into the table — `["+", "r"]`. The
rejected-first-reading loop is recorded verbatim in §9.60.5 (the
zero-guessing discipline's live lesson: audit every registration
path before ruling a projection).

**Numbers.** Full suite **1169:0:0** (1168 + 1 guard); audit
**200/200**; fmt clean; clippy `-D warnings` clean; 8-primitive
invariance verified for the thirty-third round (a driver-layer
roster-sourcing change touches no payload, no semantics). Stage 2
entry remains explicitly prohibited by the user (r54, reaffirmed
r55-r59).

## v0.28.0 — interlude: the no-forwarding round (cross-crate re-exports retired, SOP §18.5 v15.2)

The §9.59 review is the direct sequel to the Symbol single-pool
unification: v0.27.0 paid off "one type, two definitions"; this round
pays off "one type, many reachability paths". The user's r58
instruction made the rule explicit: *each crate exports only what it
defines — no forwarding, no re-exporting other crates' content; if
another crate needs it, it imports from the defining crate* — naming
kerf-core as still carrying the problem.

**The inventory, verified.** Thirteen cross-crate `pub use` lines
across seven crates: kerf-core re-exported six kerf-span names,
kerf-syntax four, kerf-compiler ten (one whole block "for the Layer 6
consumer"), kerf-reader two, kerf-runtime four, kerf-driver three,
kerf-expander one. The archaeology matters: these were not convenience
re-exports. The Cargo comments say it themselves — "types flow through
the kerf-compiler re-exports (SOP §18.5 — no direct production edge
L4 -> L6)". The old edge-minimization policy made forwarding
*structurally necessary*: refusing direct DAG edges forced types to
travel through middlemen.

**The frontier verdict, primary-source triple-read.** K81: `rustc_ast`
depends on `rustc_span` **directly** and its lib.rs re-exports only its
own modules (`pub use self::ast::*`) — zero passthrough; the whole
rustc compiler imports Span/Symbol from rustc_span itself. K82:
`oxc_ast` is the same shape — direct `oxc_span` workspace dependency,
own-module exports only. K83, the honest counter-example:
`rustc_middle` is the famous historical facade, but current master's
`hir/mod.rs` consumes rustc_hir as a **private** `use rustc_hir::*` —
the public forwarding face has been cleaned up. The direction of
travel at the frontier is away from public passthrough.

**What changed.**

- **All thirteen forwarding lines retired.** Every pipeline crate now
  exports only what it defines. The old charter comments ("consumers
  must not depend on kerf-span directly") are inverted and rewritten:
  consumers now MUST — that is the rule.
- **~40 import sites re-surgically connected** across the pipeline
  crates, the six in-crate api test files, and the root tree: mixed
  imports split (`kerf_compiler::{Opcode}` stays, `Span`/`Symbol` move
  to `kerf_span::`, `LiteralValue`/`ModuleItem` move to `kerf_core::`).
- **Five Cargo dependency faces updated** — the honest DAG emerges:
  kerf-span is now a direct production dependency of every consumer
  (compiler/expander promoted from dev-deps, vm/runtime/driver new),
  and kerf-vm takes kerf-core as a production dependency.
- **SOP §18.5 amended via the §3.3 evolution path (v15.1 → v15.2) —
  the first SOP self-amendment of the interlude series.** Five policy
  clauses: pipeline crates forward nothing; a type's unique
  reachability path is its defining crate; the root aggregation crate
  is exempted on a two-tier basis (crate-level aliases are its
  designed aggregation content, type-level forwarding stays banned);
  edge count is not a complexity metric (a forwarding chain is an edge
  in disguise); lesson source recorded.
- **TEST-4 machine-guards the zero** (three tests in
  `test_infra_guard_tests.rs`): crates/ scanned tree-wide for
  `pub use kerf_*` (= 0), the root facade checked two-tier (aliases
  yes, `::`-paths no), and a detection-power arm with seven
  must-flag / five must-spare fixtures. Development true-positive,
  disclosed: the arm's first run caught its own fixture error — the
  alias shape was listed as must-spare; the detector was right, the
  fixture was wrong (the TEST-2 precedent, third instance).

**Numbers.** 28 Rust files + 5 Cargo.tomls + SOP + dataflow graph;
tests 1165 → **1168:0:0** (+3 guards, zero pipeline-expectation
changes — semantic zero-movement proven by untouched goldens), audit
**200/200**, fmt zero diff (one long-line self-fix), clippy
`-D warnings` zero. Stage 2 entry remains explicitly prohibited (r58,
sixth reiteration). Also this round: one T35 leftover repaired — the
stage-2-plan Status line's r57 addition had silently failed to save
(a raw replace without an assertion; the lesson is recorded, all
edits are assert-backed now).

## v0.27.0 — interlude: crate-boundary review + Symbol single-pool unification

The §9.58 review opened the crate-boundary meta-domain — after the
diagnostics and test-infrastructure rounds audited the pipeline's
*products*, this round audited the *factory*: are the ten crate
charters clean, and does any cross-crate duplication hide behind
layer independence? The user's r57 instruction named the exact
suspicion: "kerf-core/ and kerf-syntax/ contain large amounts of
similar or identical content — why does this exist, it should not."

**The finding, verified.** `kerf-core/src/symbol.rs` (334 lines) and
`kerf-syntax/src/symbol.rs` (288 lines) are structural twins: after
normalizing the type names, a diff leaves **243 changed lines — every
one of them in doc comments**. The same `Interner`, the same
process-global `OnceLock<Mutex<Interner>>`, the same `intern()`, the
same identifier floor, the same hand-written Debug shape. The v0.23.0
interning round (§9.52.4) had ratified this as the deliberate "twin
discipline" — each layer owns its pool, the expander crosses the
boundary as source text. Three more twins rode along: the
`InvalidSymbol` error variant with byte-identical Display text in
*three* crates (reader, syntax, core — the "single-source dictionary"
maintained by triple copy), and ~14 twin unit-test cases.

**The frontier verdict, triple-confirmed.** K78 (direct read of
`rustc_span/src/symbol.rs`, 88KB): rustc's `Symbol` and its interner
live **in the span crate** — the lexer, AST, HIR and MIR all consume
one Symbol type and one pool; `rustc_ast` has no twin. K79 (oxc
`ARCHITECTURE.md` + `oxc_span` source): the foundation layer shares
Span/Syntax/Diagnostics across all components, and `oxc_span` cites
rustc_span as its model. K80 (rust-analyzer workspace): `crates/span`
is the foundation crate, and even hygiene (`SyntaxContext`) lives
there. Three frontier compilers, one shape: identity types sink to
the foundation layer; layers stay independent by *crate layering*,
never by duplicating types.

**What changed.** The §9.52.4 ruling is amended by informed
adjudication (three counter-arguments recorded and rebutted; the
v0.23.0 ruling's premises archived, not erased):

- **One Symbol, one pool, in kerf-span** (`crates/kerf-span/src/
  symbol.rs`, 403 lines): `Symbol` + `SymbolError` + the interner +
  the consolidated 20-case unit-test family. Both twin files are
  retired (622 lines deleted). `kerf-syntax` and `kerf-core`
  re-export `kerf_span::Symbol` — every downstream import path
  (`kerf_core::Symbol`, `kerf_compiler::Symbol`) is unchanged, zero
  new DAG edges (§18.5).
- **`StxSymbol` retires.** The §21.12 naming family is amended:
  Symbol is a cross-stage ID type (like Span/FileId/ScopeId), not a
  syntax-object type — the no-prefix family, in the foundation crate.
- **One canonical error rendering.** `SyntaxError`, `CoreError` and
  `ReadError` `InvalidSymbol` variants now *wrap* `SymbolError` with
  `From` impls and delegate their Display — the triple text copy is
  gone, and the reader's lexer now propagates the real error payload
  instead of discarding it.
- **The text bridge becomes a pool hit.** The expander's
  `sym.as_str()` lowering path is unchanged in shape, but the second
  intern now hits the same table — one pool, one identity per text,
  half the memory, and the Stage 2 lexical-addressing input (§9.52.5
  "symbol identity foundation") strengthens from a text protocol to
  index isomorphism.
- **Two new integration assertions** (`symbol_intern_tests.rs`): the
  same text constructed through the syntax face and the core face is
  the *very same* Symbol (equality, size, hash), and all three error
  faces render one byte-identical message — the single-source
  dictionary is now machine-checked, not asserted.

**Numbers.** Code face: 24 files, +369/−453 — the deleted duplication
outweighs the new foundation. Tests: 1174 → **1165:0:0** (the twin
suites merge into one family — a legitimate net reduction with zero
semantic-coverage loss), audit **200/200**, fmt zero diff, clippy
`-D warnings` zero. Registration windows: W-BOUND-SCOPE (scope/
hygiene context placement — rust-analyzer K80 precedent; opens with
Stage 2 lexical addressing) and W-BOUND-NAMING (the two same-named
`code.rs` files — expander CodeValue vs typecheck TypeCode; P3
observation). Stage 2 entry remains explicitly prohibited (r57,
fifth reiteration).

Also this round: the GitHub file repository
(`Redskaber/subscription_and_notification_channel`) became reachable
for the first time in eighteen rounds — v0.26.0 was imported and
aligned from commit `ba6e243`, and the sandbox environment reset
(toolchain reinstalled at 1.98.1, web dashboard re-synced from the
stale v0.1.0 state, worklog mirror drift repaired).

## v0.26.0 — interlude: test-infrastructure self-audit (inventory guards + audit label normalization)

The §9.57 review turned the audit lens on the test infrastructure
itself — the meta-domain the review genealogy had never surveyed
(r51 Symbol → r52 memory → r54 determinism → r55 diagnostics; the
verifier was the last unsurveyed component). Frontier anchors: the
rustc-dev-guide testing chapters (tidy enforces test-placement
discipline tree-wide; compiletest tracks stray output files;
distcheck verifies the tarball), rust-analyzer expect-test, and
cargo-mutants (K75-K77; three weak queries disclosed, one upgraded
to a primary-source direct read).

**What changed.** Three inventory invariants are now machine-guarded
(`tests/v1/stage1/plan/test_infra_guard_tests.rs`, the K75 tidy
family — mechanical, tree-wide, fail-closed):

- **TEST-1 — runner mounting guard.** Cargo discovers only top-level
  `tests/*.rs`; every deeper file runs only through a `#[path]` mount
  in `tests/runner.rs`. An unmounted file was a silent dead file —
  now both directions are asserted (every `.rs` under `tests/` is
  mounted; every mount target exists).
- **TEST-2 — corpus table/directory parity.** The per-case
  `corpus_case!` table and the 79-file corpus directory must carry
  exactly the same set (the old design tolerated a lagging table —
  the sweep covered validation but isolation degraded silently).
- **TEST-3 — audit case registration.** The gate-audit's headline
  "200/200" was a hardcoded literal over a three-form labeling
  convention (H07 shared H06's comment; sections U/V used single
  digits). The convention is now uniform — every case opens with a
  `// XNN:` comment (A-C comments added, H07 labeled, U/V widened;
  comment-only, zero behavior change) — and a guard asserts the
  per-section composition (A10 + B10 + C5 + D5 + 16×10 = 200) plus
  the headline literal. A detection-power arm feeds the counter a
  synthetic fixture with near-miss shapes (the r54 detector
  precedent).

**Tests.** +4 (three guards + one detection arm), zero pipeline
regression. Full suite **1174:0:0**, gate audit **200/200**, fmt
zero diff, clippy `-D warnings` clean. Registered windows (zero
signal, not opened): golden blessing tooling, mutation testing,
doc-count sync, distcheck automation. Stage 2 entry remains
explicitly prohibited (r54/r55, reaffirmed r56); test-tree-only
changes — no primitive, channel, VM, or grammar surface touched.

## v0.25.0 — interlude: diagnostics position single-sourcing (message/location separation + session line-index cache)

The §9.56 review surveyed the diagnostics domain end to end: the
structured `Diagnostic` type, the TD-001 line/column derivation, the
rustc-flavored renderer, the per-stage collection policy, and the
parity harnesses' error-axis comparison. The rustc-dev-guide
diagnostics chapter is the canonical anchor: a diagnostic message
"should be general and able to stand on its own" — position lives in
the `--> file:line:col` location line exclusively (K71).

**What changed.** Two findings were implemented in code:

- **DIAG-1 — position fragments leave the stage Display messages.**
  All four error families embedded positions in their `Display`
  (reader `at byte N` ×6, expander `at {span}` ×9, compiler
  `({span})` ×10, vm `({span})` ×11 — 36 sites), which double-reported
  against the renderer's location line and leaked the internal
  `file#0:15..16` byte form into user-facing output. Messages are now
  position-free; offsets and spans stay in the structured payloads
  (`offset()` / `span()`), and the location line is the single
  position render. Compiler `pc`/`slot`/`index` operands stay (they
  are semantic payloads, not source positions).
- **DIAG-4 — the session owns the line index.** `render_position`
  and `render_one` rebuilt `LineIndex::new(source)` per diagnostic
  (twice each across the width and render passes — O(source) per
  diagnostic). `Session::intern` now builds the index once per file
  (rebuilt on REPL upsert; rustc source-map / rust-analyzer line-index
  shape, K72), and the renderer fetches it through the fail-closed
  `Session::line_index`.

**A consequential fix discovered during implementation.** The parity
harnesses compare the oracle error against the rebuilt `.krf`-side
error through the shared `Display`; with positions gone from the
messages, two different payloads could render to the same text — the
drift detector would go blind. The error-axis parity key is now
`Display` + a harness-rendered position suffix (`@ byte N` /
`@ {span}`), the same shape the tree-axis dumps always carried
(`(define 0 36 x ...)`); tamper detection is proven restored by the
drift-detector and span-trap tests.

**Tests.** 29 assertion sites updated (the failing suite enumerated
them — zero guesswork), six render goldens re-baselined as a
documented intentional change (ds01/ds02/ds04/ds05/ds10 + e2e; the
ds03-via-1.1-wiring precedent), one new session-cache test. Full
suite **1170:0:0** (+1 net), gate audit **200/200**, fmt zero diff,
clippy `-D warnings` clean. Registered windows (zero signal, not
opened): per-variant error codes, within-file multi-error recovery,
suggestion engine. Stage 2 entry remains explicitly prohibited
(r54/r55); release-only render-golden and message changes, no
primitive, channel, VM, or grammar surface touched.

## v0.24.0 — interlude: compile-output determinism guard (the fixpoint gate-B prerequisite locked in tests)

The §9.55 audit classified all 61 non-comment HashMap/HashSet sites
across the ten pipeline crates: every map is keyed-lookup-only,
membership-only, or insertion-order-indexed (the `Vec` +
`HashMap`-as-index shape — a hand-rolled IndexMap, K69); no site lets
hash iteration order leak into compiler output. The numeric edge
semantics face (checked i64 arithmetic, NaN-canonicalized constant
pool keys, bit-identical NaN equality) was re-verified as already
hardened.

**What changed.** The property was implicit; now it is locked: a new
root-tree guard family double-traverses the real fixpoint subjects
(the assembled reader behind its own token table, the macro library
assembled ahead of the expander behind a forms-stream prefix — the
gate-B recipe) and the full 79-case corpus through two independent
reader -> expander -> loader -> compiler instances, asserting
structural equality of the expanded items and the bytecode. Three
detector-detects tests prove the comparison catches pool/table/code
divergence, and one semantics test documents the first-use ordering
discipline of the global table (source order, never hash order).
Four invariant comments now pin the discipline at the sites it rests
on (`intern_const`/`intern_global`, the trigger-set union, the GC
root scan, the sweep loop). Zero behavior change; tests +7.

**Why now.** Stage 2's exit criterion (2) — two self-compilations
byte-identical — rests entirely on this property, and the user's
standing review directive ("review the whole pipeline, implement the
fixes, do not converge") flagged the determinism domain as the
remaining unreviewed face after the §9.46-§9.53 lineage closed. The
round also registers the user's explicit "no stage 2 entry" ruling
(stage-2-plan.md §0 r54 note): the confirmation gate flips from
"awaiting" to "explicitly prohibited" until lifted.

## v0.23.0 — interlude: symbol interning (the user-flagged representation gap closed in code)

The identifier payload swaps from owned `String` to an interned
`NonZeroU32` index (stage0.md §9.52) — the user's four-times-flagged
review item, now implemented rather than registered. Both phase-twin
types (`kerf_core::Symbol`, `kerf_syntax::StxSymbol`) keep their public
APIs byte-identical; only the private payload changes, and each layer
owns its own global interner (leaked `&'static str` map — the
matklad-style simple interner, K54; the rustc `Symbol = interned
identity` shape, K6/K54b).

**Why now.** The three previously registered triggers (LSP window,
B-series hotspots, selfhost self-compile load) stayed zero-signal, and
that assessment stands. The window opened on the user directive itself
(rounds 42/47/50/51) plus a blueprint-implementation gap: the design
blueprint's `Identifier(Symbol) // interned string` assumed interning
all along. Stage 2 benefits directly — capture descriptors (LA-2) can
key on symbol identity instead of text comparison.

**What it buys.** Equality/hashing become index operations, cloning
becomes a bitwise copy (every `CoreExpr`/`StxDatum` clone gets
cheaper), and `Option<Symbol>` keeps a 4-byte niche layout in the
compiler and vm frames.

**What it costs (informed tradeoffs, §9.52.3).** Interned text lives
for the process (leak-by-design — the classic interner tradeoff,
CLR/Python pool pitfalls surveyed as the con-side anchors);
`as_str`/`Display` take one uncontended mutex; `Ord` now means
first-intern order, not lexicographic (whole-tree ripple audit: zero
ordering consumers — every `sort` site sorts `String`/`&str`, no
`BTreeMap<Symbol, _>` exists); language-level strings (`Value::Str`)
are NOT interned — identifier identity and string data stay two
worlds. The `Copy` trait is deliberately not derived (a whole-tree
`clone_on_copy` churn for no semantic gain; revisited with LA-2).

**Guardrails.** `Debug` is hand-written to reproduce the old derived
`Symbol { text: "x" }` shape byte-for-byte, so goldens and diagnostics
are index-independent. Tests grow by 17 (10 unit + 7 cross-crate
integration: symbol-heavy programs on both engines, shadowing, parity
contract drift detection, unbound-name diagnostic fidelity): 1162:0:0,
audit 200/200, fmt clean, clippy `-D warnings` clean. B-series all
in-band: B1 at 7.7µs (a new low — the interning dividend), B3 +11%
(evaluator display-path lock cost, recorded as measured).

Zero language-surface change: 8-primitive invariance round 25, subset
frozen faces untouched, selfhost parity byte-identical. Stage 2 entry
still pending user confirmation (SOP §14.6.3 rule 5).

## v0.22.0 — Stage 1 close: the exit round (deep-review family + seven-piece finals + nine-signal audit, GO recommended)

Stage 1 ends (stage-1-plan row 1.9; docs/stage0.md §9.50 — the
fifth and last review segment closed the lineage with zero
findings). The exit claims are re-runnable, not narrated.

**The review lineage completes.** §9.50 gives the checker domain
(R1-R8) its per-rule survey — the only pipeline domain left — and
it is the lineage's single zero-finding segment: the conservative
discipline (definite-errors-only + the assign over-approximation
guard), the double mirror (compiler resolution order + expander
sequencing), the severity split (E0008/E0011 warnings), and the
dynamic-soundness boundary (R5-R7 at top level only) all hold. The
frozen layers (span/syntax/core) close with a git-audited zero
drift since Stage 0.

**The audit grows to 200 with section V — one case per §21.5
signal.** Semantic stability (builtin families, both engines),
bootstrap verification (gate B on a composite source), coverage
(the corpus replay), the performance baseline (the live budget
face: frames share the allocation budget; zero budget fails
closed), documentation sync (render goldens), handling degrees
(the frozen cardinalities: 18 builtins, 24 opcodes), debt zero
(the assembled expander + a clean recursive program both produce
zero findings), outer-loop auditability (the section set itself),
cross-stage verification (the full pipeline dataflow), and the
recovery close. A new root test family (`stage_exit_tests.rs`,
ten cases) carries the same anchors as permanent cargo tests.

**The deep-review family lands as finals.**
`deep-review-round1.9.md`: D1-D8 all pass, the §14.8 deviation
list adjudicates eight items (every B3/B4 already written back
per-round, the B1s enter Stage 2 planning, the constitutional item
is zero-deviation), C1-C6 closes with zero cleanup actions
(fourteen consecutive clean rounds), and the committee votes
5.5/5.5. The seven-piece set completes: architecture scores +
extension costs, the four gap lists (all empty for Stage 1
obligations), hidden-problem growth ratings (no mandatory fixes),
the refactoring verdicts (five rounds, every rejected alternative
recorded), the 1.9 performance re-run (B1 at 9.4µs — the whole
stage stayed within ±2% of its entry point), and
final-assessment.md with all nine §21.5 signals checked plus the
§14.7 C1-C6 cross-stage chapters.

**GO is recommended for the Stage 1 → Stage 2 transition.** Per
SOP §14.6.3 rule 5 the final gate is user confirmation. The Stage
2 entry plan: the §21 planning round first (backend strategy +
capability maturity re-check), then the lexical-addressing +
capture-activation first knife, with the 1.8 institutional lesson
(island capabilities wire to the driver face in their own delivery
round) as a standing acceptance clause.

- Tests: 1145 passed / 0 failed / 0 ignored (Stage 1 total: 767 → 1145)
- Audit: 200/200 (A-V twenty-one sections; V = the nine-signal exit evidence)
- td register: zero open items, fourteen consecutive rounds
- 8-primitive invariant: twenty-third verification round
- B1-B5 at exit: 9.4µs / 97.45ms / 9.4ms / 0.372ms / 97.0ms (in band)

## v0.21.0 — Stage 1.8: gate-prep (full-set gate re-run + HM wiring + calibration + seven-piece skeletons)

The Stage 1 endgame-prep round (stage-1-plan row 1.8; docs/stage0.md
§9.49 — GATE-1..GATE-4).

**The HM layer joins the driver pipeline (GATE-2, the plan-1.3
"1.8 agenda").** `pipeline.typecheck()` now runs both static layers
in one batch — the conservative rules (R1-R8) and the inference
engine (E0009-E0011) — with the soft-typing severity contract kept:
definite errors block, the E0011 budget warning never does.

**Wiring it immediately exposed a 1.3-layer false positive.** The
assembled `.krf` expander (a legal 1.4k-line program, parity-
verified on both engines) was rejected with E0009: argument-shape
unification was reporting heterogeneous tag dispatch (one parameter
fed different tuple shapes at different call sites — legal dynamic
code) as a definite error. The hardening is *release-and-demand*:
a failing argument-shape constraint is rolled back and released,
never reported; the single body-sensitive binding source (an if
condition forcing a parameter metavariable to bool) keeps its
definite-error reporting through a per-define demand table —
`(define f (fn (x) (if x 1 2)))) (f 1)` still blocks, the tag
dispatchers run. FP3 hardening anchors both halves; the audit U1c
case pins the assembled expander to zero error-level findings.

**Gate re-run (GATE-1).** The audit set re-runs the whole Stage 1
family (A-T) and grows to 190: the new U section carries the HM
wiring end-to-end, the §7.3.2 fix-boundary family of the 1.7
probe rounds (the four-head record grammar, three-generation macro
chains beyond the corpus, the mangled-field tamper detector, the
assembly-order neutrality, the Macro sentinel at zero), and the
cross-sub-stage sweep (1.0-1.7 full chain on both engines).

**Calibration (GATE-3) + seven-piece skeletons (GATE-4).** The
calibration pool backfills the 1.4-1.7 verification rows and the
Stage 1 summary (tests 846→1135, twelve consecutive rounds of zero
runtime-semantic defects, TD register at zero); the institutional
lesson — *an island capability must reach the driver face in its
own delivery round* — is written into the 1.9 exit-review clauses.
The §14.6.6 seven-piece deep-verification set lands as skeletons
with pre-filled evidence and per-document 1.9 obligation tables.

**Corpus expectation co-variance (all probe-verified).** Five
negative cases re-freeze their directives for the two-layer batch
(neg-031/037 gain E0009; neg-041/044/047 move from runtime-error to
type-error E0009 — the checker now catches them first); ds02 keeps
its runtime render face through an HM-released dynamic parameter
and gains a checker-face golden (ds02b).

- Tests: 1135 passed / 0 failed / 0 ignored (baseline 1128 + net 7)
- Audit: 190/190 (A-T full re-run + U10 — the §7.3 gate-prep form)
- td register: zero open items, twelve consecutive rounds
- 8-primitive invariant: twenty-second verification round

## v0.20.0 — Stage 1.7: the .krf macro layer, third segment (macro parity + fixpoint gate B)

The third self-hosted front-end segment lands: the macro layer of the
expander, rewritten in the frozen kerf subset itself and checked
against the Rust expander oracle byte-for-byte (stage-1-plan row 1.7;
docs/stage0.md §9.48 — the BS-C 1.7 segmentation: MX-1..MX-6).

**The assembled program (MX-2).** `selfhost/v1/macro.krf` is a pure
function library — registration validation, fixed-arity matching, the
six-step instantiation order, rename-on-capture — assembled ahead of
`expander.krf` into one program by the host (the module-vs-crate
mirror: transformer.rs is a module of kerf-expander, macro.krf is a
library of the expander program).

**Rename encoding (MX-1).** The frozen subset has no string
construction, so a renamed introduced identifier rides as a structured
`("mangled" s e base counter gen)` record; the host decodes
`format!("{base}__macro_{counter}")` for the byte comparison — parity
observes the decision face, the deterministic rendering stays
host-side (the 1.5 float-as-Debug-text precedent).

**Generation threading.** Every input record carries a trailing
generation int (source records ride 0; macro products carry
use_gen + 1 — pos-032 exercises the two-generation chain). The dump
TEXT grammar is unchanged; the host rebuilder consumes the generation.

**The Macro layer collapses (MX-3).** The 1.6 three-layer split
collapses: define-syntax sources run the assembled program on both
engines; the Macro enum value survives as a zero-routing sentinel.

**Fixpoint gate B (MX-6).** Two axes cash in subset-spec §4's
reserved criterion: (a) bytecode equality — `compile(rebuild(krf
items)) == compile(oracle items)` over the macro corpus and the
assembled source applied to itself; (b) the self-application
fixpoint — the assembled program expands its own source, three-way
agreement (vm / eval / oracle).

**Corpus 72 → 79.** pos-031 (literal table), pos-032 (two
generations), pos-033 (hygiene binder collision — rename-on-capture's
first corpus exercise), neg-050/051/052/053 (pattern mismatch,
duplicate pattern variables, the ellipsis boundary, module-scoped
macro visibility).

**Numbers.** 1128:0:0 (net +30), audit 180/180 (new T section, ten
cases), B1-B5 performance within band, zero open technical debt
(twelfth consecutive round).

---

# Release Notes

## v0.19.0 — Stage 1.6: the .krf expander, second segment (expansion layer)

The second self-hosted front-end piece: the expander's *expansion
layer*, rewritten in the frozen kerf subset itself and running on
both engines, checked against the Rust expander oracle
byte-for-byte (stage-1-plan row 1.6; docs/stage0.md §9.47 — the
BS-C 1.6 segmentation: EX-1..EX-5).

- **`selfhost/v1/expander.krf`**: the full expansion layer in ~640
  lines of frozen-subset kerf — all four declaration heads (both
  define shapes with letrec pre-binding, require's string domain,
  module frame isolation, define-syntax as the fail-closed
  macro-layer marker), all eight expression forms, the `do`→flat
  `Let` desugar with the discard binding, `quote`→Pair right-fold,
  let\* progressive binding, and the module loader (the LIFO
  worklist declare pass + three-color DFS with the gray-cycle path
  slice). The §9.47.3 seven span traps are mirrored one by one:
  the quote whole-form span, the fn-sugar name-atom span, the
  binding value-node span, the `do` identity, the set! name-atom
  error span, the handler whole-clause span, and the require
  symbol-name MalformedForm.
- **One self-recursive expander** (the REC-A lineage, third
  instance): the frozen subset bans define-level mutual recursion
  (neg-046), so the expression expander is ONE function; the
  variable-arity walks (argument lists, let pairs, do steps,
  handler clauses, fn assembly) ride five synthetic node modes
  (`mapx`/`letloop`/`doloop`/`clausemap`/`fnbind`) dispatched by
  tag at the same recursion point. Synthetic modes bypass the depth
  counter, so .krf depth tracks the Rust node depth exactly (the
  512 budget stays unreachable from pure source — the reader's 256
  cap has the 2× margin).
- **Flat pre-order forms stream** (EX-1): the host reads (single
  source) and injects `(define forms (quote (...)))` — one flat
  record list where a `("list" s e n)` record's n children follow
  it. The flat shape keeps 255-deep trees inside the reader's
  nesting cap (a nested encoding would need depth+3).
- **Three-layer split** (EX-3): sources the reader rejects are
  decided by the reader layer (six corpus files); sources declaring
  a macro (`define-syntax`) ride the Macro layer — pos-024 and
  bnd-010, decided by the oracle with the .krf layer not exercised
  (`SyntaxRules` is the 1.7 window); everything else runs the .krf
  expander on both engines.
- **Corpus extension 68→72** (§9.47.4, the extension-duty table):
  pos-029 (string require + the three comparison builtins + an
  uncalled read-line), pos-030 (nested module declaration), neg-048
  (the string-name module cycle — `ModuleCycle` becomes
  corpus-reachable), neg-049 (`ModuleNotFound`). Expectations
  frozen through the probe round (all four correct on first
  validation).
- **Two-faced bootstrap fixed point**: the structural face (the
  expander's own source minus the hosting tail, expanded to the
  same 49-item tree on both engines and the oracle) and the error
  face (the bare source — oracle and both engines agree on the
  unbound `forms` at the exact same span: the hex0-layer hosting
  dependency made visible by self-application).
- **Nameability completions** (the 1.5-b kerf-reader precedent,
  third and fourth instances): kerf-compiler re-exports
  `CoreExpr`/`Binding`/`HandlerClause` (they ride ModuleItem's
  public shape); kerf-expander re-exports `CoreError` (it rides
  ExpandError::Core's public shape). Zero new Cargo edges.
- Six commands all green: **1098:0:0** (1069 baseline + 29: seven
  harness inline, eighteen integration, four corpus cases) · gate
  audit **170/170** (the new S section mounts the expander-parity
  meta-audit) · B1-B5 performance baselines unchanged.

## v0.18.0 — Stage 1.5: the .krf reader, first segment (structure layer)

The first self-hosted front-end piece: the S-expr reader's
*structure layer*, rewritten in the frozen kerf subset itself and
running on both engines, checked against the Rust reader oracle
byte-for-byte (stage-1-plan row 1.5; docs/stage0.md §9.46 — the
K18 hex0-layer lineage: the host lexer stays the single source of
token truth while the .krf layer takes over structure).

- **`selfhost/v1/reader.krf`**: an iterative explicit-stack parser
  (one token per self-recursive step; frame = depth/open-start/
  items-reversed) written with only the frozen 18 builtins + 8
  special forms. The four parser-side rejections (unclosed innermost
  `(`, stray close, empty application before outer unclosed,
  nesting 257 at limit 256) are produced as *structured values* —
  the host rebuilds the `ReadError` and renders through the oracle's
  own `Display`, so message parity holds by construction.
- **Source-injected token table** (RS-1): the host lexes (single
  source) and prepends `(define tokens (quote (...)))` ahead of the
  reader source — the only typed data channel the frozen subset
  offers (strings are opaque; the read-line input-tape route is
  ruled out and re-registered as a second-segment obligation).
  Spans ride as decimal strings; floats ride as Debug text
  (inf/NaN have no .krf literal shape).
- **The parity harness** (`kerf-driver::reader_parity`): dual-axis
  normalization (tree dumps) + error reconstruction + dual-engine
  runs (handles stay alive for heap walks), with a layer split —
  lexer-side rejections are decided by the single-source lexer
  (the six-variant family is the second-segment window).
- **Coverage**: 1069:0:0 (net +23), audit 160/160 (new Section R),
  the 68-case Stage 1.4 corpus replayed in full as reader inputs,
  the 255/256/257 nesting boundary, two drift-detector self-checks,
  and the bootstrap fixed point (the .krf reader reads its own
  source's token stream).
- Docs: stage0.md §9.46 (v9.12 — K18-K21 anchors, the subset
  expressibility audit, the B3 scope correction), plan-1.5.md,
  reader-parity.md.

## v0.17.0 — Stage 1.4: the kerf subset freeze (.krf self-hosting target surface)

Stage 1.5-1.7 will rewrite the compiler front end *in the kerf
subset itself*; this release freezes what that subset is, pins it
with an acceptance corpus, and lands the parity contract the rewrite
will be judged by (stage-1-plan row 1.4; docs/stage0.md §9.45).

- **The subset spec** (`docs/develop/v1/stage-1/subset-spec.md`): an
  honest freeze of the implemented surface — 4 declaration heads, 8
  expression special forms, 18 builtins, 6 literals, 9 core
  constructors, 4 module items — every row anchored to its code
  source, with the exclusion faces registered explicitly (macro
  trigger surface stays a 1.7 item; quote rejects symbols; I/O is
  the §8.8 minimal set with `write-line` string-only).
- **The acceptance corpus (68 cases)**:
  `tests/v1/stage1/corpus/*.krf` — directory-form data files with
  in-file `;; expect:` directives (the GCC-torture `dg-*` pattern):
  26 positive, 32 negative, 10 boundary. Every expectation was
  verified against the real pipeline before freezing (probe round:
  68/68, zero guessed expectations).
- **Empirically adjudicated semantics, now pinned by the corpus**:
  closures do **not** capture outer bindings (both engines reject
  with `unbound global` — the checker's E0001 is the correct
  definite-error catch); forward references are rejected at
  expansion (defines-so-far; the R1 "all defines" view is the
  direct-construction face); `()` is a *reader*-stage rejection;
  `write-line` takes strings only.
- **The parity contract** (`kerf-driver::parity`): the BS-C Stage
  1.4 slice — `CorpusCase`/`Expectation`/`Observed`/
  `EquivalenceReport` + `validate`/`validate_all`, the closed
  directive grammar, and the dual-engine equivalence discipline
  (value/outputs/globals three-face agreement; runtime rejections
  must fail on *both* engines). `ParityReport` grows
  `globals_repr` (additive); the 1.5 dual-reader window extends the
  same report shape — nothing pre-built.
- **Audit Section Q (10 cases)**: the detector-detects meta-audit —
  wrong expectations must drift with both sides named, stage
  attribution both ways, exact code-set comparison, the no-define
  value convention, the batch face, and the closed grammar.
- **Numbers**: 1046:0:0 (from 953, net +93), audit 150/150 (new
  Section Q), zero new dependencies, zero new crates, B1-B5
  performance baselines unchanged (the contract is off the hot
  path).

## v0.16.0 — Stage 1.3: the Hindley-Milner inference base

The checker grows a real type layer: an iterative Algorithm W with
union-find metavariables, an undo log, SCC-partitioned define
processing, an effect-row collection face, and the Layer 2 typed
annotation IR — all inside `kerf-typecheck` (zero new crates, zero
new dependencies, zero pipeline changes).

- **Iterative everywhere (the A6 lineage)**: explicit task-stack
  tree walk, worklist unification, iterative occurs check and deep
  resolve — zero deep Rust recursion, bootstrap-friendly for the
  later `.krf` rewrite on the flat-stack VM. The 512 depth budget
  per define emits one `E0011` *warning* (never an error — deep but
  legal programs must keep running) and excludes the define whole.
- **The undo log is a soundness device**: bindings made while
  inferring an `if` branch are rolled back at the branch boundary —
  a leaked binding would flag dynamically-legal programs. Condition
  bindings persist (evaluation order); `Fn` bodies are the
  parametric contract itself.
- **SCC partitioning**: defines are grouped by the syntactic call
  graph (iterative Tarjan, dependencies first). Mutual recursion
  unifies through pre-bound metavariables within an SCC; cross-SCC
  references instantiate generalized schemas — same-module
  polymorphic reuse (`(id 1)` + `(id #t)`) is decoupled per use.
- **The conservative discipline holds**: `Dyn` is the one-way
  unknown top (if-branches join, never unify); assigned names never
  generalize (value-restriction analog); the 18 builtins are typed
  ad hoc at application sites (no type classes for a closed set);
  effect rows collect `Perform`/`Handle` with definite subtraction
  and over-approximate handler merges (row polymorphism stays the
  Stage 2+ TY-C window).
- **New diagnostics**: `E0009` type mismatch, `E0010` recursive
  type (occurs check), `E0011` inference budget exceeded (warning).
- **The Layer 2 typed IR**: `TypedExpr` mirrors `CoreExpr` with a
  type and effect row on every node; `TypedDefine` carries the
  generalized schema. The IS snapshot family freezes the
  deterministic dump byte-for-byte.
- **Numbers**: 953:0:0 (from 890, net +63), audit 140/140 (new
  section P), B1-B5 baselines unchanged (the inference layer is not
  in the compile path).

## v0.15.0 — Stage 1.2: property-based testing lands (DEA-13 closure)

The fourth testing layer joins the pyramid: snapshot / golden /
bootstrap-parity / **property**. `proptest` enters as a root-layer
dev-dependency only (never in the language pipeline or the bootstrap
chain), and the first three invariant families of the §9.34.5
checklist go live as seven properties.

- **The seven properties** (tests/v1/stage1/plan/pbt_seed_tests.rs,
  mounted through tests/runner.rs): dual-engine parity on arbitrary
  well-formed programs (FP1), the runtime unhandled-effect trap on
  both engines (FP2), handle-perform reduction fused with a concrete
  arithmetic oracle (FP3), the static E0006 propertified across the
  whole effect-name space (FP4 — the 1.1 finite samples generalized),
  the reader fixed point of display (FP5 — the caliber disclosure:
  `StxDatum::Display` is the diagnostics face, not a serialization
  face), VM dispatch determinism across fresh instances (FP6), and
  integer addition against the host checked-add oracle (FP7).
- **Typed generators** (the well-formed domain): a three-channel
  expression generator (Int / Bool / Any — depth-capped, ±2^40
  oracle band), safe symbol pools (zero keyword / zero builtin
  collisions, self-tested), and a float domain restricted to the
  exact Debug-parse roundtrip band.
- **First-run honesty**: the initial PBT round failed 4 properties —
  all generator-domain or assertion-face issues (the reader rejects
  `()` and `(fn () …)` — the frozen EmptyApplication grammar fact;
  declaration-only programs halt at nil, so FP3/FP7 assert on the
  define slot instead of the program value), zero dual-engine
  divergences: the property layer found no new defects in the
  shipped implementation, which is exactly what DEA-13 closure
  should look like on a green baseline.
- **Numbers**: 890 tests green (881 baseline zero-regression + net
  9: 7 properties + 2 domain self-tests; 64 cases × 7 properties =
  448 generated programs); the audit set stays at 130/130 (PBT and
  the exhaustive-sample audit are complementary domains — the ruling
  is recorded in plan-1.2.md §4); one new dev-dependency (proptest
  1.11.0 — the ^1.9 constraint resolves to the latest 1.x), zero
  production-dependency changes; baseline co-changes: the ds08
  version golden moves to 0.15.0, Cargo.lock gains the dev-side
  tree.

## v0.14.0 — Stage 1.1: driver wiring (typecheck stage in the pipeline + diagnostic-render join + the first Warning producer wired)

The checker joins the pipeline: `read -> expand -> typecheck ->
{compile, eval}` on every face (run / check / parity / REPL).

- **Abort semantics (ruling at implementation)**: Error-level
  findings (R1-R7) abort *before execution* — a definite error means
  the program cannot behave as written, so neither engine runs it;
  Warning-level findings (R8) never block: they ride on the outcome
  (`RunOutcome` / `CheckOutcome` / `ParityReport` gained a
  `warnings` channel), the CLI prints them to the diagnostics sink,
  and exit codes stay untouched.
- **The render join** (stage-1-plan §4 fulfilled): the driver's
  stage-level `DiagnosticCode` gained a data-carrying
  `Typecheck(TypeCode)` variant whose tag *is* the E0xxx registry
  string — diagnostics render rustc-style `error[E0002]:` /
  `warning[E0008]:` with the byte-precise `--> file:line:column`
  locations. Multi-diagnostic batches gained a
  `warning: N warnings emitted` summary line (before the abort line,
  rustc order); warning-free batches render byte-identically to the
  Stage 0 form (the ds10 golden freeze holds), and warnings-only
  batches no longer claim an abort they never made.
- **REPL warning replay**: the session-replay semantics extend to
  warnings — the whole program re-runs per submission, and the
  rendered warnings delta-print under the same prefix rule as
  outputs (shown once, silent on replay, new findings are news).
  Warning submissions enter the accumulated program (legal); only
  errors roll back.
- **Externals, third consumption site**: the driver builds the
  checker's table from the two authoritative sources only
  (`STAGE0_GLOBALS` names + `Builtin::ALL` arity triples — the
  single-source discipline; same construction as the root tests and
  the audit).
- **Baseline co-changes, five disclosed sites**: known-callee arity
  mismatches now surface statically (E0002) before the runtime face
  — the runtime coverage moves to checker-opaque param-mediated
  shapes (`((fn (g) (g 1 2)) car)`); the ds03 snapshot golden updates
  to the static form; ds08 tracks the version bump (0.14.0). A
  design-level validation surfaced on the way: an earlier
  `(set! car 1)` in the REPL correctly poisons `car` for R2 (the
  assign guard spans submissions) — conservative discipline working
  as specified.
- **Numbers**: 881 tests green (846 baseline zero-regression + 35
  net: 17 positive / 18 negative — the non-blocking / abort / render
  / replay guard families in dual balance); audit set 120 -> 130
  (section N: source-reachable E0xxx end-to-end, abort-before-
  execution, warning channels on every face); seven error classes
  stay 7/7; zero new external dependencies (one internal edge,
  L4.5 -> L8).

## v0.13.0 — Stage 1.0: kerf-typecheck seed (E0xxx registry + conservative static R1-R8 + multi-error collection)

Stage 1 opens (the stage-exit GO from 0.12.0 confirmed). The first
sub-stage delivers the external-Rust type-checker path (the §21.6
circular-dependency mitigation): a conservative static checker over
expanded programs, the E0xxx diagnostic registry, and the ruling-21
multi-error collection architecture.

- **The conservative discipline** (docs/develop/v1/stage-1-plan.md §3,
  the authoritative definition): every rule R1-R8 reports only
  *definite* errors, each with a recorded soundness argument. The two
  mirrors keep resolution honest — the compiler's locals-then-globals
  order (`lookup_local` -> `intern_global`) and the expander's
  define-so-far + letrec pre-bind discipline. Position-aware
  visibility: top-level immediate positions see defines-so-far; Fn
  bodies see every define (call time is post-load).
- **R1** unbound reference — the structural-layer re-assertion behind
  the expander's first line of defense (serves directly-constructed
  programs). **R2** known-arity mismatch (IIFE / define-to-Fn /
  builtin arity, under the assign guard and lexical-shadow skip).
  **R3** non-boolean literal condition. **R4** non-callable callee
  (literal directly, or a no-reassign literal define). **R5** handler
  arity mismatch on routed top-level performs. **R6** top-level
  unhandled perform (module load has no dynamic context — the lexical
  handle is the only possible router). **R7** non-callable literal
  handler. **R8** assignment-target surprise — the first Warning
  producer (implicit global creation / builtin rebinding; legal
  semantics, surfaced per report-over-silence).
- **The effect-family soundness key**: performs inside Fn bodies are
  never lexically routed (dynamic handlers may exist at call time) —
  R5-R7 apply to top-level immediate performs only; the walk mirrors
  the Handle compilation order (handler values evaluate before their
  own clauses install).
- **The E0xxx registry** (TypeCode E0001-E0008 + two-level Severity +
  TypeDiagnostic with byte-precise spans) activates the variant-level
  code scheme registered in Stage 0; messages stay single-source with
  the RuntimeError family (R2 mirrors ArityMismatch wording).
- **The Externals face** keeps the builtin table single-source:
  callers construct it from `STAGE0_GLOBALS` + `Builtin::ALL` (the
  root tests, the audit example, and the 1.1 driver wiring are the
  three consumption sites).
- **Layer disclosure**: R2-R7 statically catch what is runtime-only
  today (ArityMismatch / TypeMismatch / UnhandledEffect move to
  compile time) — the checker is a validator, never an executor
  (stage0.md §9.24 TY-A).
- **Housekeeping**: TD-006 cleared (stage0.md header version tag
  synced v8.8 -> v9.9, four-place consistency, user-instruction
  window) — the tech-debt register is at zero open items. PBT
  dependency review concluded DEFER-WITH-TRIGGER (proptest enters at
  1.2 with its first real consumers). Zero new external dependencies
  (two internal edges: kerf-span + kerf-core).
- Tests: 767 -> **846** (net +79: 51 inline + 7 api + 21 root
  integration over the real read->expand->typecheck pipeline); audit
  set 110 -> **120** (section M); seven error classes 7/7 maintained.

## v0.12.0 — Stage 0.11 final round: snapshot suite + performance baseline + stage-exit review

Stage 0 closes. The final L3 round delivers the last two §22.3
milestone items (L6 ≥50 snapshot tests, L8 performance baseline),
runs the full deep-review family, and checks every stage-exit
signal — the stage-exit review concludes GO (pending user
confirmation per §14.6.3 rule 5).

- **The snapshot suite** (`tests/v0/stage0/plan/snapshot_seed_tests.rs`,
  57 cases ≥ 50): one fixed input frozen into one exact output string
  per case, across every pipeline layer — reader skeletons (RS01-10),
  expander trees covering each of the nine primitives in its direct
  form (ES01-10), per-instruction bytecode listings (CS01-10, the
  `op a b` machine form), VM/eval terminal state including the
  compile-ordered globals table and opaque display forms
  (VS01-10 + VE01-02), driver rendering goldens for six negative
  paths plus the check/parity/version/output faces (DS01-10), and
  REPL transcripts with rollback and continuation (TS01-04 + VD01).
  Goldens were recorded from the verified 0.10-r3 baseline via a
  temporary probe, eye-checked line by line, and frozen inline;
  they change only with an explicit behavior change logged in the
  worklog.
- **The performance baseline** (`examples/bench/stage0_baseline.rs`
  re-runnable via `cargo run --release --example stage0_baseline` +
  `docs/develop/v0/stage-0/performance-baseline.md`): B1 compile-fib
  9.3µs median, B2 vm-run-fib(25) 96.7ms (≈2.4µs/call), B3
  eval-run-fib(20) 9.4ms, B4 gc-pressure churn 0.36ms with 1 cycle
  and 1023 swept cells per iteration on the collect-then-retry path,
  B5 driver end-to-end 97.6ms. Regression bar: median worsening
  >25%, or any change in the B4 behavior counters. std-only tooling
  (zero new dependencies).
- **The deep-review family** (§14.5/§14.6/§14.8/§14.9):
  `deep-review-round0.11.md` (D1-D8, committee vote 5.5/5.5, the
  §14.8 deviation ledger B1×2 / B2×3 / B3×3) plus the seven
  inter-stage documents — dataflow coverage (enum exhaustiveness
  with zero unwraps and 33 justified expects), architecture review
  (nine stages all green), design-impl-test three-way coverage
  (zero gaps), hidden-problems assessment (zero P0/P1, zero
  mandatory-fix items), refactoring optimality (7/7 + 8/8),
  performance baseline, and `final-assessment.md` (§22.3 twelve
  items all checked, §21.5 nine switch signals all checked, C1-C6
  cross-stage audit — GO).
- **Code grooming (§14.9)**: two historical-tense file-header notes
  corrected in place (the seven-class coverage note in kerf-vm, the
  diagnostics extension ownership note in kerf-driver); zero TODO /
  FIXME / unimplemented / todo markers, zero glob re-exports.
- **Numbers**: 710 → 767 tests (+57 snapshots; 50:7 positive:negative
  — reverse deviation declared, the determinism-contract layer is
  structurally positive, error-detection semantics stay with the
  existing 7/7 classes), audit set 110/110 re-run green, six
  commands green, R8 encoding face clean on all new files.

## v0.11.1 — Stage 0.10-r2 Capability-model reservation generalization

The capability reservation becomes a SPACE, not a point (user
explicit instruction — adjudication 20). What the reservation
reserves is no longer the concrete io model: it reserves the ability
to register and extend abstract capability models themselves.

- **The capability space** (`kerf-core/src/reserved/capability/`):
  the family contract (`CapabilityModelFamily` — identity card +
  closed error face, no operation signatures: the no-prediction
  discipline), the token calculus (`TokenCalculus` — the sealed-token
  discipline and its registry vocabulary term), the registration &
  extension mechanism (`CapabilityModelRegistry` — register / lookup
  / governing_model / governed_authorities, fail-closed on
  InvalidDescriptor / DuplicateModel / AuthorityConflict, rejected
  registrations mutate nothing), and the io sub-model re-hung as the
  first concrete model (`IoModel` — Error pinned verbatim to the
  frozen IOError; identity card "io" / ["io.read", "io.write"] /
  "CapabilityIO"). Space relations are constraint combinations, not
  inheritance (stage0.md §9.10.2); the registry's unique-subordination
  rejection is axioms A3/A4 made machine-checked (§9.13.2).
- **Freeze continuity (adjudication 17 discipline)**: the 0.10-r1
  module path `reserved::capability_io` survives as a re-export of
  `capability::io` — TypeId identity proven in tests; all four r1
  consumer faces (api tests, root integration tests, the audit set,
  the docs) compile with zero changes.
- **Extension proven at four positions**: a locally-defined model
  (the canonical clock resource — the object-capability lineage's
  fs/net/clock set, knowledge-search verified) registers into the
  same closed world as io from inside the crate, the api position,
  the workspace root, and the audit example — zero framework changes
  each time (the open-closed principle at the organizational layer).
- **Numbers**: 672 → 710 tests (+38: unit 27 / api 6 / root 5;
  25:13 positive:negative — reverse deviation declared, the
  fail-closed family contributes 11 negative cases), audit set
  100 → 110 (section L), six commands green, R8 encoding face clean.

## v0.11.0 — Stage 0.10 Reserved-interface freeze

The Stage 0 interface-reservation milestone: the four reserved
contract families of docs/stage0.md §22.3 are frozen — "interface
defined, implementation may be empty". The milestone checklist's four
interface items (Effect Handlers / multistage programming /
capability-model I/O / compilation cache) are all checked.

- **One freeze anchor, four families (adjudication 17)**: everything
  lives in `kerf-core/src/reserved/` — the L4 semantic-authority
  crate, reachable by every downstream crate and the workspace root.
  The face is *fully self-contained*: zero inbound edges beyond
  `std` (the language value is an associated type, not the VM value —
  L4 never depends on L6; the cache payload is opaque bytes, never a
  typed compiler product). "Depend on abstract constraints, not
  concrete implementations" (SOP §21.12-10(2)) lands in its strongest
  cold-start form, with the six-domain affiliation declared as module
  documentation (the kerf-space marker family stays a Stage 1+
  registration; re-anchoring onto it is additive).
- **Compilable translation of the blueprint sketches (adjudication
  18)**: the §9.1.1-§9.1.4 pseudo-code shapes become real Rust —
  companion traits (`EffectOp`, `CodeCarrier`) carry the
  `Self::Effect::Result` / `Self::Code::Inner` paths verbatim in
  meaning; `impl Expr` becomes an explicit generic; the §9.3.1 vs
  §9.1.1 vocabulary drift resolves in favor of the §9.1.1 block with
  mapping notes (the kernel-level `HandlerClause` stays the primitive
  arm; the reserved `Handler` associated type is the system face).
  Two naming disclosures: the reserved `MultiStage::quote` is the
  staged-code constructor (Stage 2), distinct from the 0.9 datum
  literal; the reserved `Code` is not the expander's `CodeValue`.
- **`effects` (P3)**: `EffectSystem` with `Effect: EffectOp` /
  `Handler` / `Continuation` / `Value` associated types and the
  `perform` / `handle` signatures frozen. Primitive semantics stay in
  the kernel (`CoreExpr::Perform` / `Handle`); Stage 2 owns the
  language-level system.
- **`multistage` (P3)**: `MultiStage` with `quote` / `splice` / `run`
  over a `CodeCarrier` — the Stage 2 staged-programming face.
- **`capability_io` (P3)**: sealed zero-sized tokens
  (`ReadCapability` / `WriteCapability`, hand-written bare-name
  `Debug`), the closed `IoErrorKind` set (Eof / Denied / Interrupted
  / Other), an R8-shaped `IOError`, and the `CapabilityIO` trait.
  Token construction is closed outside the defining crate — no
  public constructor exists at Stage 0 (minting/delegation is the
  Stage 1 additive window; default-deny is the Stage 0 discipline).
- **`cache` (P2 — signatures + executable behavior spec)**:
  `CacheKey` (a 256-bit content digest; the algorithm is a Stage 1
  implementation detail), `CachedResult` (opaque payload bytes —
  adjudication 19: the known follow-on needs of cross-session
  persistence and distributed caches are serialization-shaped, so the
  frozen face never pins a product type), `CompilationCache` with the
  three blueprint methods, and
  `check_compilation_cache_contract` — the behavior spec made
  runnable. Six contracts (store-then-get hit + value equality /
  never-stored miss / post-invalidate miss / no-op invalidate /
  latest-wins / cross-key isolation) assert against any
  implementation; Stage 1 caches reuse the kit directly as their
  contract tests. The kit's detection power is itself tested: five
  deliberately broken implementations (never-hit / no-invalidate /
  no-overwrite / wrong-key / payload-corrupt) are all caught.
- **Signature-stability snapshots**: canonical conforming
  implementors ("witnesses") live at four consumption layers (inline
  tests / crate api tests / workspace-root integration / the audit
  example) — any drift in the frozen shape breaks a witness
  compilation, which the six-command acceptance turns into a hard
  gate.
- **Counts**: 672:0:0 workspace tests (624 baseline zero-regression,
  net +48 — the roadmap agenda met verbatim; round 32:16 = 1:0.5
  reverse-skew declared: a reservation round's acceptance face is
  type existence and signature snapshots, structurally positive;
  negative-testable faces are exhausted — kit detection ×5, IOError
  four-kind paths, R8 shapes at two layers, token discipline). Audit
  set 90 → **100** (section K — reserved-face contracts; §7.1.1
  seven classes stay 7/7). Zero implementation-side runtime-semantics
  defects (all round fixes were compile-level or shape-level).

## v0.10.0 — Stage 0.9 Macro system seed

The Stage 0 macro milestone: the basic hygienic macro system
(`define-syntax` + `syntax-rules`), the structured `CodeValue`, the
module loading layer, and the `quote` datum literal. The SOP §7.1.1
error-class matrix reaches **7/7** — the module-cycle class lights up
end-to-end, at both the sub-stage and the gate threshold.

- **Hygienic macros, two complementary mechanisms (adjudication 14)**:
  scope coloring with the *binder-scopes subset* judgment (the 0.4
  membership rule generalized to Racket's "Binding as Sets of
  Scopes" — non-macro code is structurally unchanged, 551-test
  baseline zero-regression) decides expansion-time binding;
  *rename-on-capture* (the §9.38(b) second algorithm) carries the
  decision into the name-based back half (CoreExpr/bytecode/VM
  resolve `Var` by name — an introduced binder colliding with a
  spliced argument name is renamed to `name__macro_N` together with
  its introduced references). Observable proof: without hygiene the
  capture test yields 200, with it 101.
- **`define-syntax` / `syntax-rules`** (§8.10): fixed-arity patterns
  (the ellipsis `...` is a registered Stage 0 boundary — rejected at
  registration, fail-closed), literals matching by symbol text,
  `_` wildcards, pattern variables splicing use-site arguments
  *verbatim* (span/scopes/phase/name all keep their use-site
  identity), introduced nodes carrying generation+1 (the dea12b
  tracing contract — macros expanding into macros increment per hop).
  Macros are lexically scoped like defines (a nested module's macros
  vanish with their frame); a head naming nothing reports the unified
  unbound-identifier judgment (adjudication 16 — the Racket rule).
- **Module loading layer (§8.9 Stage 0 slice)**: `load_program`
  collects declared (nested) modules into the flat namespace,
  walks every `require` edge, and rejects cycles with a three-color
  DFS reporting the full path (`module cycle detected: a -> b -> a`)
  — **§7.1.1 class 7 lit, completing 7/7 at both thresholds** —
  plus not-found and duplicate declarations. The deliverable is graph
  validation + the dependency-first instantiation order (`LoadPlan`);
  visibility merging is the Stage 1 module system. The driver's
  `parse` runs it fail-fast; module diagnostics render with
  line:column locations.
- **`CodeValue`** (§6.3.3 Stage 0 projection): the structured
  macro-phase code value — `from_syntax`/`to_syntax`/`substitute`
  (the pattern-variable splice face)/`alpha_rename` (the
  rename-on-capture remedy face, public)/`symbols` (the honest
  Stage 0 census — the semantic `free_variables` is the Stage 2+
  slot)/`to_source` (the diagnostics observability face).
- **`quote`** (plan-0.7 decision 13 redeemed): atoms and proper
  lists fold into `LiteralValue::Pair` chains terminated by `Nil`
  (the 0.1 consumption face — `ConstKey::Pair` gets its first
  production consumer); symbols fail closed (`QuoteUnsupportedDatum`
  — no Stage 0 value carrier; the Stage 1 evolution slot).
- **`ModuleItem::DefineSyntax`**: the fourth declaration variant —
  a faithful declaration record with zero code (the `Require`
  precedent applied to the macro phase; compiler and evaluator both
  skip it).
- Adjudications 14/15/16 and 13 decisions recorded in plan-0.9.md §4
  (dual-mechanism hygiene; the `nil` empty-literals spelling — the
  reader rejects `()`, so `nil` is the language's empty-list
  spelling everywhere; the unified unbound judgment). Tests: net +73
  (34:39 — deviation declared: the four-stage macro E2E is the plan
  row's acceptance body), cumulative 624 green, audit set 80 → 90
  (section J), all seven error classes lit.

## v0.9.0 — Stage 0.8 Driver seed

The compiler entry point (Layer 8): pipeline orchestration over both
execution engines, the diagnostics rendering closure (TD-001 paid),
session/file interning, and the `kerf` CLI/REPL. Every crate of the
0.0 charter is now implemented — 9/9 (TD-003 cleared to zero).

- **Pipeline orchestration**: `kerf_driver::run_source` drives
  `read -> expand -> {compile -> VM, eval}`; `Engine::Vm` / `Engine::Eval`
  select the engine; `ParsedProgram` is the stable fork point (the
  same expanded program feeds both, exactly as the 0.7 cross-check
  established). `check_source` compiles + verifies without executing.
- **Parity as data**: `run_parity` runs both engines over the same
  input and compares three faces — final value repr, output
  sequence, and the define-name global table (`parity_repr` with
  both heaps alive — a divergence is *reported*, never a panic; the
  `--parity` CLI flag surfaces it as `parity: PASS/FAIL`).
- **Diagnostics rendering closure (TD-001)**: `LineIndex` derives
  1-based line + **character** column from byte offsets at render
  time (never stored — single source of truth); the renderer emits
  rustc-flavored `error[kerf-read]: msg`, ` --> file:line:col`,
  source excerpts with caret underlines (span-length, line-clamped),
  multi-diagnostic separation and a summary line. `Diagnostic` is
  the §8.7 slice: `Severity`/`DiagnosticCode`/`primary_span:
  Option<Span>` — position-less errors render without a fabricated
  location (no DUMMY spans, ever).
- **Session/file interning**: `Session` maps names to sequential
  `FileId`s with upsert semantics (the REPL re-reads one growing
  file); diagnostics render against the session's sources — the
  single source of truth.
- **REPL (session-replay semantics)**: both engines are per-program
  by design, so the REPL accumulates source and re-runs the whole
  program per submission; expressions wrap as `(define $repl:N expr)`
  (the r110 "top-level expression channel = define calling form");
  failed submissions roll back (the session survives any error); the
  input tape replays deterministically (a `read-line` past the tape
  ends with `Eof` — interactive stdin is the `run` mode's pipe).
- **CLI**: `kerf run <file> [--engine vm|eval] [--parity]`,
  `kerf check <file>`, `kerf repl`, `--help`, `--version`; exit codes
  0/1/2 (success / program-or-environment / usage); piped stdin feeds
  a run's `read-line` calls; hand-rolled parsing, zero dependencies.
- **Consumer-face extensions** (all additive): `ReadError::offset()`,
  `CompileError::span()`, `kerf_compiler::ModuleItem` re-export
  (ExpandError::span() existed since 0.4 — its doc comment named this
  sub-stage). New DAG edges L1->L8 and L7->L8 (ruling 11, plan-0.8).
- **Audit set**: 70 -> 80 (Section I: the five source-reachable
  error classes rendered end-to-end through the driver, multi-file
  multi-diagnostic collection, REPL rollback, check rejection,
  parity divergence-as-data, CJK character columns, position-less
  rendering). Error classes 6/7 held (module circular dependency
  stays DEFERRED to 0.9).
- **Fixed in-round**: TapeIo write recording (the VmIo face is the
  engine's single output recording point — a no-op face silently ate
  all REPL output) and stdin pre-read scoping (only `run` consumes
  piped stdin; the REPL reads its own submissions).

## v0.8.0 — Stage 0.7 Runtime seed

The runtime layer (Layer 7): the docs/stage0.md §19.4 mark-sweep
collector and the `eval` meta-circular evaluator — the dual-execution-
path cross-check goes live (the same expanded program runs through
`compile → VM` AND through `eval`; ≥15 programs agree structurally,
and the STAGE0_GLOBALS tables are officially asserted three ways).

- **GC (§19.4)**: mark bits and a free list live on the kerf-vm `Heap`
  (the heap-method skeleton verbatim — `test_and_set_mark`,
  `clear_marks`, `free`, slot iteration); the three-phase orchestration
  (explicit-work-stack mark — a 10^5-deep chain marks without host
  recursion; linear sweep; symmetric reset) lives in
  `kerf_runtime::gc` (Layer 7). `Roots` carries the four §19.4 root
  classes plus the handler-table extension (installed handler values
  are frame-adjacent state — missing them dangles handlers).
- **collect-then-retry** (the point error.rs announced at 0.6): the
  budget safety point now checks the LIVE footprint (frames + live
  cells); on exhaustion an injected collector runs one cycle and the
  charge retries. Without a collector the 0.6 fail-closed behavior
  stands; `Vm::with_collector` / `with_budget_and_collector` inject;
  `Vm::register_foreign_ref` protects host-held values (§19.4 root
  class four); `Vm::snapshot_roots` snapshots every class.
- **eval (the meta-circular evaluator)**: the nine semantic primitives
  interpreted directly over CoreExpr, mirroring the compiler/VM
  decision-for-decision — name resolution (tail-first scan,
  `lookup_local` verbatim; shadowing = new slots), evaluation order
  (§19.3: args left-to-right, then the callee), assign's Dup
  semantics, Require as a no-op, Module flattening, Handle's
  install-run-pop, Perform's nearest-handler rule. Closures are the
  "basic closure" P0 scope (free names resolve globally; the captured
  env is a dormant value snapshot — the 0.6 duality; lexical capture
  is a Stage 1 activation on BOTH engines). `EVAL_DEPTH_LIMIT`
  guards the Rust stack (the evaluator recurses in host frames while
  the VM stacks heap frames — a registered asymmetric boundary).
- **Builtin single source**: the 18 STAGE0_GLOBALS operation semantics
  extracted into shared kerf-vm functions (`arith`, `compare`, `car`,
  `cdr`, `cons`, `not`, `read_line`, `write_line`) — the VM and the
  evaluator call the SAME bodies (zero drift by construction, stronger
  than parity tests). The name/arity tables are asserted three ways
  (expander ↔ registry ↔ evaluator seeding).
- **parity**: `parity_repr` renders values structurally (pairs as
  dotted notation recursing both arms; closures and builtins as
  opaque forms — addresses never participate); `assert_parity`
  compares engines. Error parity is exact too: the same failing
  source produces the same variant AND the same rendered message on
  both engines.
- **Fixed (found this round)**: the evaluator's `invoke` swapped-out
  environment locals were outside the GC roots — a recursive call's
  in-flight caller values could dangle after a cycle; now
  root-protected through the evaluator's temp stack (§19.4
  explicit-roots class of a Rust evaluator), with program isolation
  (no lexical residue across `eval_program` calls) as the
  same-family backfill.
- `RuntimeError` grows to 11 variants (`EvalDepthExceeded`); the
  seven-class matrix holds at 6/7 (module cycles remain 0.9's). The
  audit set grows 60 → 70 (Section H: evaluator negatives + the GC
  retention guard + the parity-detector self-check). 427 tests green
  (71 new, 19:52 positive:negative — deviation disclosed in
  plan-0.7.md §3: the GC family counts entirely as defense-negative
  and the parity battery IS the acceptance criterion).

## v0.7.0 — Stage 0.6 VM seed

The bytecode virtual machine (Layer 6, a PERMANENT Rust base — rewriting
it in kerf is constitutionally excluded): the docs/stage0.md §19.5
switch-dispatch iterative main loop with heap-allocated call frames
(the TD-023 anchor — kerf-level recursion consumes the frame vector,
never the Rust stack). Source → value runs end to end for the first
time: fib(25) = 75025 executes on the full chain (reader → expander →
compiler → verify → VM).

- `Vm::new(bytecode)` runs the load-time verify hook (plan-0.5 ruling
  4, second line of defense) and seeds every STAGE0_GLOBALS name as a
  builtin value (18-name registry, `Builtin::ALL`); plain globals stay
  unbound until their `store-global` runs (`UnboundGlobal` on early
  loads — the dynamic-order face verify cannot decide statically).
- 24-op full execution: per-frame operand stacks, `pc` monotonicity
  with the closed jump/call/ret exception set, and the evaluation-order
  contract consumed exactly as the 0.5 compiler emits it (args
  left-to-right, callee on top — plan-0.6 ruling 5 reconciles the
  §19.5 skeleton drawing against the compiler's actual emission).
- `RuntimeError` (10 variants, every one carrying the source `Span`
  resolved through the debug_info table — the §12.1 consumption row):
  arity mismatches on both call faces and type mismatches across four
  contexts light SOP §7.1.1 classes 4 and 5 (6/7 lit); plus
  `UnhandledEffect`, `DivByZero`, `ArithmeticOverflow` (checked i64 —
  no wrapping), `BudgetExceeded`, `Eof`, `RetFromEntry`, and
  `StackUnderflow` (handler-stack face — §19.5 trap 2: explicit depth
  checks on every stack access, defense in depth over verify).
- Effects at 0.6 (plan-0.6 ruling 6): `perform` finds the nearest
  installed handler and invokes it as a function — the handler's
  return value IS the perform's value; real continuations stay
  reserved in the frozen ext1 frame slot (Stage 1+).
- The §19.4 allocation budget is the Stage 0 safety point: frames +
  heap cells share one `u32` budget (`DEFAULT_BUDGET` = 8 MiB), which
  bounds every non-terminating program (kerf has no loop primitive —
  all unbounded growth routes through calls and allocations). The 0.7
  collector hooks `gc_cycle` at the same point.
- Pluggable I/O (`VmIo`): `read-line` / `write-line` builtins over a
  deterministic `BufferIo` default (strict-string writes; the 0.8
  driver wires real streams).
- Fixed in passing (found by this round's nested-handle tests, §20.6
  full-class sweep): the 0.5 compiler's `end_closure` restored `cur`
  by decrementing — every program with a second, sibling, or nested
  closure past the first emitted into the wrong proto. Now restored
  through a saved-caller stack (`cur_stack`), with a two-case
  regression pair pinning sibling and nested closure shapes.

Verification (cold build, SOP §3.2): 0 error / 0 warning; fmt zero
diff; clippy `-D warnings` clean; **356 passed / 0 failed** (300
baseline + 56 new: 54 VM tests at 12:42 plus the 2-case compiler
regression pair; round ratio 14:42 = 1:3, cumulative 89:267 = 1:3);
`cargo run --release --example stage0_gate_audit_r1` — **AUDIT PASS
60/60** (A10 + B10 + C5 + D5 + E10 + F10 + G10).

## v0.6.0 — Stage 0.5 compiler seed

The bytecode compiler (Layer 5): CoreExpr -> Bytecode, implementing
the direct-style translation of docs/stage0.md §19.3 with jump
backpatching, a deduplicated constant pool, an interned global symbol
table, and the per-instruction debug_info table (§19.3 invariant 3 —
no bare instructions; §12.1: the VM resolves runtime errors back to
source through `Bytecode::span_of`).

- `compile_program(items) -> Bytecode` and `compile(expr) -> Bytecode`
  — the two public entries (program form ends in a depth-0 `halt`,
  single-expression form in a depth-1 `halt`).
- 24-op set: the §8.12 groups (stack / function / control flow / data
  construction / variable access / arithmetic / termination) plus
  `push-handler` / `pop-handler` / `perform` — the frozen
  Perform/Handle primitives (TD-005) carried directly. Every operand
  slot's meaning is declared on the opcode (`Opcode::operand_help` —
  "operands fully resolved").
- Eval-order contract (§19.5): args left to right, callee on top;
  `call n` pops n + 1 and pushes the result. Tail-position `if`
  compiles branches straight into the proto terminator with no merge
  jump (§19.3 trap 1) — Stage 1+ TCO only rewrites the compiler, never
  the VM. `handle` bodies compile non-tail (handlers pop before
  return; tail pass-through is registered Stage 2 effect-elimination
  theory).
- Defense in depth (plan-0.5.md ruling 4): compile-time bookkeeping
  (depth tracking, patch assertions, placeholder drain — all
  structured `CompileError`s) plus a public `Bytecode::verify`:
  operand bounds, debug-info parallelism, terminal shape, `halt`
  entry-only, and a DAG basic-block stack-depth propagation that
  catches underflow and imbalance in hand-built or corrupted
  products. The 0.6 VM is expected to call verify before loading.
- `CompileError` — 13 variants, R8 message shapes, `std::error::Error`
  (no source chain: inputs are pre-validated by the front end).
  `COMPILE_DEPTH_LIMIT = 1024` mirrors the expander budget with 2x
  headroom (reader 256 < expander 512 < compiler 1024).
- Constant pool dedup by canonical key: all NaNs fold to one slot
  (Eq reflexivity); +0.0/-0.0 stay distinct (bit-pattern keys — dedup
  is an optimization, not a semantic merge).
- Span discipline: every debug_info entry is copied from a CoreExpr
  node; the only synthesized span is the cold-start anchor for the
  `halt` of an empty program (single-generation ROOT — the TD-002
  no-cross-generation-join guarantee extends to the compiler side).
- kerf-core now re-exports the span coordinate types
  (`FileId`/`ByteOffset`/`ExpansionId`) for downstream span
  construction — no new DAG edge (plan-0.5.md §4 decision 14).
- Workspace: 300 tests green (48 new, positive:negative 12:36 = 1:3);
  §7.3.1 audit set 40 -> 50 (Section F: compile depth cap + verify
  rejection family over hand-built products). TD-003 resolves one
  more scaffold (compiler implemented; vm/runtime/driver remain).

## v0.5.0 — Stage 0.4 expander seed

The macro expander (Layer 3): syntax objects -> the frozen CoreExpr
kernel, implementing the expansion-loop skeleton of docs/stage0.md
§19.2. The 0.4 slice is the core-form skeleton — transformer
execution and the def-site / use-site hygiene union are the 0.9 macro
system (§8.10).

- `expand_program(forms) -> Vec<ModuleItem>` and
  `expand(ctx, stx) -> CoreExpr` — the two public entries. The module
  top level accepts declarations only (`define` / `require` /
  `module`); bare top-level expressions fail closed (the top-level
  expression channel is the `define` calling form — r102 corpus
  anchor; the driver owns the main composition at 0.8).
- All nine expression forms: `fn` / `if` / `let` (single, multi and
  empty binding specs, let* progressive visibility) / `do` (Begin ->
  Let chain desugaring with `_` discards, §6.12.6) / `set!` (target
  must resolve — Scheme semantics) / `perform` / `handle` /
  application / atoms, with `nil` as the reserved literal keyword and
  `(define (f x) body)` sugar mapping near-identically to
  `Define{f, Fn{...}}` (§7.3.5). Defines pre-bind their name
  (letrec-shaped top-level rule — recursive functions resolve).
- Hygiene skeleton (§19.2 invariant 2): every binding construct
  allocates a fresh scope, colors its subtree on descent
  (`with_scope_added` in production use — the 0.2 contract), and
  resolution is scope-set keyed: a name bound at a scope the
  identifier does not carry stays unbound. Nested modules are
  scope-isolated (§8.9 direction).
- Phase closure (§8.9 rule 1, 0.4 slice): every touched node must be
  runtime-phase — macro-phase syntax fails closed with
  `PhaseViolation`.
- `EXPANSION_LIMIT = 512`: the expansion work budget — a structured
  `ExpansionDepthExceeded` error, never a stack overflow (§19.2
  invariant 1); independent of the reader's 256 source-tree cap, it
  bounds synthesized and (at 0.9) macro-produced trees.
- `ExpandError` — seven variants, each carrying the byte-precise
  span; `std::error::Error::source` chains into `CoreError` (the
  core constructor floor is re-asserted at expansion time).
- `STAGE0_GLOBALS` — the 18-name Stage 0 global function table
  (arithmetic/comparison, pair/predicates, minimal I/O — §8.8
  traditional globals); kerf-runtime asserts parity when seeding the
  global environment at 0.7.
- SOP §7.1.1 error classes 2 (unbound identifier) and 7 (expansion
  depth exceeded) are now lit — 4/7 cumulative. The §7.3.1 audit set
  grows monotonically 30 -> 40 (new section E: ten expander
  negatives). Workspace: 252 tests green (48 new, 12:36 = 1:3).
- TD-002 adjudicated and resolved: the 0.4 expander copies source
  spans only (zero span construction — desugared nodes reuse the
  source spans of the same generation), so cross-generation joins
  structurally cannot occur; `JoinExpansionMismatch` stays a designed
  rejection, and the 0.9 macro system registers span-set
  representation (def-site ∪ use-site) as its design agenda
  (plan-0.4.md §4 ruling 3).

## v0.4.0 — Stage 0.3 reader seed

The surface-syntax reader (Layer 2): the first source-level pipeline
entry, implementing the typed-token-stream contract of docs/stage0.md
§8.1 and the `read : string → Result<SyntaxObject, ReadError>`
capability signature (§278), pluralized to whole programs.

- `StxToken`/`StxTokenKind` — the §8.1 TokenKind S-expression subset
  (Delimiter / Identifier / IntLiteral / FloatLiteral / BoolLiteral /
  StringLiteral / Eof); modern-skin kinds arrive additively at Stage 2.
  The tokenize guarantees all hold: lossless coverage (inter-token gaps
  are exactly whitespace and `;` comments — test-anchored), precise
  byte spans (multi-byte UTF-8 exact), structured lexical errors.
- `lex(file_id, source)` and `read_program(file_id, source)` — the two
  public entries; a token slice without Eof is tolerated (end of slice
  behaves as end of input).
- Numbers follow Rust `i64`/`f64` parse semantics (`.5`, `1.`, `1e5`
  are floats); number-shaped atoms that parse as neither are rejected
  fail-closed (`MalformedNumber`) — no Racket-style symbol fallback.
  Booleans are exactly `#t`/`#f` (`#true` fails closed). Strings take
  escapes `\" \\ \n \t \r` with raw newlines legal. `;` line
  comments; the BOM is skipped like whitespace.
- `()` is rejected at read time as `EmptyApplication` (SOP §7.1.1
  error class 3, lit at the reader as defense in depth — the quoted
  empty list is covered by the `nil` literal; honest boundary in
  plan-0.3.md §4.3). Bracket and reader-macro characters
  (`[ ] { } ' \` ,`) fail closed — no reader macros in Stage 0; quote
  is spelled `(quote x)`.
- The list-nesting cap is a public constant (`NESTING_LIMIT = 256`),
  boundary-tested both ways (256 legal, 257 rejected); the cap also
  bounds the descent's native recursion depth. Unclosed lists report
  the innermost open `(` — deterministic and closest to where input
  ran out.
- `ReadError` — ten variants, all byte-precise, R8 message shapes; the
  `InvalidSymbol` rendering is byte-identical across the reader,
  syntax and core layers (single-source dictionary, cross-crate
  asserted).
- SOP §7.3.1 audit set revision 1: `examples/audit/
  stage0_gate_audit_r1.rs` — 30 cases (10 single-statement + 10
  multi-statement + 5 complex + 5 error-recovery), re-runnable via
  `cargo run --release --example stage0_gate_audit_r1`; error-class
  coverage 2/7 (syntax error + empty application lit; 5 structurally
  deferred to 0.4/0.6/0.9). Grows monotonically until 7/7 at the 0.11
  stage gate.
- The `TokenLike` test stand-in is retired exactly as its charter
  promised: seed tests now reduce spans over real reader tokens.
- 60 new tests (15 positive + 45 negative = 1:3; 43 unit + 8 crate
  API + 9 cross-crate); workspace total 204, cold-build green under
  the six-command gate. TD-003 shrinks to 5 scaffold crates.

## v0.3.0 — Stage 0.2 SyntaxObject seed

The surface-syntax data layer (Layer 1), implementing the syntax-object
four-tuple of docs/stage0.md §3.3.

- `SyntaxObject` = datum + span + scopes + phase. The span is a
  mandatory field (never `Option`, never a dummy — the TD-004 structural
  discipline extended to the syntax layer); list members are full syntax
  objects, not bare datums ("extended S-expression", §7.3.6 — per-node
  wrappers are what per-identifier hygiene needs, §19.2 invariant 2).
- `StxDatum` — the skeleton atoms (Symbol/Int/Float/Bool/String) plus
  proper lists; `()` is legal datum; improper (dotted) lists are a 0.3
  reader grammar decision (quoted pair data already lives in
  `kerf_core::LiteralValue::Pair`).
- `StxSymbol` — validated, opaque identifier (floor byte-identical to
  `kerf_core::Symbol`'s: non-empty, no whitespace, no control
  characters). A pipeline-phase twin, not a duplicate: the 0.4 expander
  crosses the boundary as source text through the core validated `&str`
  constructors, so "anything the reader accepts passes both floors"
  holds by identical validation (plan-0.2.md design record 2).
- `Phase` — the frozen two-level model (Runtime = 0, MacroExpansion =
  1, §8.9) with a checked `from_u8` decoder; phase closure is an
  expander (0.4) invariant, the data layer stores per-node phases
  without cross-validation.
- `ScopeId`/`ScopeSet` — the hygiene substrate: sorted, deduplicated
  storage (deterministic iteration — no HashMap randomness), functional
  `union` and the `is_subset_of` lexical-resolution query (§9.38
  scope-coloring sketch); scope freshness is a 0.4 expander-context
  discipline.
- Consumption contracts pre-anchored by integration tests:
  `visit_spans` pre-order traversal and the deep functional
  `with_scope_added` scope flip (principle 23 — the receiver is never
  mutated) for the 0.4 expander; the token→stx assembly pattern
  (token spans reduce to the list span, token text flows through the
  checked symbol constructor) for the 0.3 reader.
- 48 new tests (12 positive + 36 negative = 1:3; three layers: 32
  unit + 8 crate API + 8 cross-crate); workspace total 144, all green
  under the six-command gate (cold build). TD-003 shrinks to 6
  scaffold crates. CJK identifiers remain legal at the floor
  (registered test-fixture whitelist).

## v0.2.0 — Stage 0.1 core expression seed

The frozen semantic-primitive kernel (Layer 4), plus the two design
adjudications that unblocked it (docs/develop/v0/stage-0/
0.1-design-adjudications.md).

- TD-005 ratified: `CoreExpr` carries the nine semantic primitives
  (Fn/Apply/If/Var/Literal/Assign/Let/Perform/Handle) per SOP §21.12-11;
  the historical §3.2 frozen set maps onto it via the §6.12.6
  semantic-equivalence table (shared semantic core, closed both ways).
  Declaration layer `ModuleItem` = Define/Require/Module; `do` sugar
  desugars to `Let` at 0.4.
- TD-004 ratified: every node carries a real `Span` (never `Option`,
  never a dummy); dependency edge kerf-span → kerf-core added to the
  workspace DAG (docs/graph/stage-0/dataflow.md synced).
- `Symbol`: opaque checked identifier (non-empty, no whitespace, no
  control chars — conservative floor; full grammar lands with the 0.3
  reader). Validated `&str` constructors (`fn_`/`var`/`assign`/`perform`/
  `handle`, `Binding::new`, `HandlerClause::new`, `ModuleItem::define`/
  `require`/`module`) pre-anchor the 0.4 expander contract; duplicate
  params / duplicate handler effects are rejected deterministically.
- `CoreExpr::visit_spans` / `ModuleItem::visit_spans`: pre-order span
  traversal — the expander consumption contract and the no-dummy-span
  audit primitive.
- Tests: 48 new cases (unit 32 + crate API 8 + cross-crate integration
  8, positive:negative = 12:36 = 1:3); workspace total 96, all green.
- Verification: SOP §3.2 six commands all green on a cold build (see
  docs/develop/v0/stage-0/plan-0.1.md).

## v0.1.0 — Stage 0.0 cold-start bootstrap

First engineering artifact of the kerf compiler, reconstructed from the
upstream document repository (sop.md v15.0-verified + stage0.md design
blueprint, content state v9.8).

- Cargo workspace, edition 2024: root aggregation package + 9 `kerf-*`
  member crates wired exactly along the SOP §18.5 dependency DAG.
- Seed MUV `kerf-span` (Layer 0): `FileId` / `ByteOffset` / `ExpansionId` /
  `Span` with checked invariants (stage0.md §8.6 four-field model, §12.1
  byte-offset representation). Line/column rendering deferred to the
  diagnostics framework (TD-001).
- Test architecture per SOP §8.4.6/§9.1: root `tests/runner.rs` single
  entry + three-layer suite (unit / crate API / cross-crate integration).
- Stage 0 roadmap fixed: sub-stages 0.0-0.11 (minimal semantic kernel →
  infrastructure depth → macro engine → interface-reservation freeze →
  stage gate).
- Verification: SOP §3.2 six commands all green (see
  `docs/develop/v0/stage-0/plan-0.0.md`).

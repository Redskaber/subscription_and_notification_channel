//! GC lifetime profile (Stage 3 W-3.4 generational-GC evaluation
//! window, MUV 3.4-a) — the allocation-lifetime measurement face.
//!
//! Purpose: test the generational hypothesis ("most objects die
//! young") on kerf's actual workloads BEFORE any nursery design is
//! adjudicated (stage-3-plan §2.3 W-3.4: the entry signal is the
//! W-3.1 allocation-pressure portrait — this example IS that
//! portrait's lifetime half; the pressure half lives in the B-axis
//! baseline, w3.1-performance-window.md §1).
//!
//! Method: per-cycle survival statistics, zero production-face
//! changes. A profiling collector records every cycle's GcStats
//! (marked / swept / live_before / live_after) through interior
//! mutability while the VM owns the box (the CountingCollector
//! pattern of perf_observability_guard_tests.rs); each workload
//! runs under a budget sweep, so the per-cycle survival ratio and
//! its trajectory across cycles expose the die-young share without
//! instrumenting the heap (the evaluation window touches no VM or
//! collector mechanism — measurement only).
//!
//! Workloads (the allocation-representative set):
//! - churn(2000): the B4 axis shape verbatim — N pairs allocated,
//!   each dead at the next define (the known 1-cycle / 1023-swept
//!   deterministic baseline, pinned by the B4 guard).
//! - churn(10000): the multi-cycle extension of the same shape —
//!   whether the death rate stays flat across cycles.
//! - iota(50): corpus representative bnd-009 — a chain built one
//!   cons at a time; a mid-build cycle sees the prefix live (the
//!   intermediate-survival contrast).
//! - map-double: corpus representative pos-020 — a walk that conses
//!   a new list while the input list stays live.
//! - fib(25): corpus representative bnd-008 — the recursive-chain
//!   contrast: frames stay live while the recursion unwinds. The
//!   budget covers frames too, and an active recursion's frames
//!   are uncollectable — so this workload has NO gc window at all:
//!   budgets below the live frame chain fail closed, budgets above
//!   it never fire. That empty window IS the finding (a nursery
//!   gains nothing on frame-live workloads; heap cells = 0 here).
//!   The harness records both poles as data, not as errors.
//!
//! Reading guide (what the numbers mean for the W-3.4 adjudication):
//! - survival = marked / live_before, the share of the pre-cycle
//!   live set the mark phase reached. A FIRST cycle with survival
//!   well below 50% says the workload's young objects died before
//!   any reference to them survived one budget epoch — the
//!   die-young signal a nursery would exploit.
//! - A flat survival across cycles says the live set is either
//!   mostly transient (churn) or mostly enduring (fib) — the former
//!   favors a nursery, the latter does not (a nursery only pays
//!   when the young fraction is large AND dead).
//! - live_after trajectory exposes old-generation accumulation: a
//!   monotonically growing live_after across cycles is the
//!   remembered-set/old-scan cost input a major cycle would carry.
//!
//! Output lines are the paste source for
//! `docs/develop/v3/w3.4-gc-window.md` §2 (the lifetime portrait).
//!
//! Run: `cargo run --release --example gc_lifetime_profile`.

use std::cell::RefCell;
use std::rc::Rc;

use kerf::compiler::compile_program;
use kerf::expander::expand_program;
use kerf::reader::read_program;
use kerf::runtime::collect as production_collect;
use kerf::span::FileId;
use kerf::vm::{Collector, Heap, Roots, Vm};

/// One recorded cycle (mirrors runtime::GcStats, flattened for the
/// log — the example cannot hold the stats struct across the borrow
/// boundary the VM owns).
#[derive(Debug, Clone, Copy, Default)]
struct CycleRecord {
    marked: u32,
    swept: u32,
    live_before: u32,
    live_after: u32,
}

impl CycleRecord {
    /// Survival ratio in basis points (marked / live_before; a
    /// live_before of 0 records as 0 — an empty-heap cycle has no
    /// young set to speak of).
    fn survival_bps(&self) -> u64 {
        if self.live_before == 0 {
            0
        } else {
            (u64::from(self.marked) * 10_000) / u64::from(self.live_before)
        }
    }
}

/// Shared cycle log (interior mutability — the VM owns the boxed
/// collector; the CountingCollector pattern).
#[derive(Clone, Default)]
struct CycleLog {
    records: Rc<RefCell<Vec<CycleRecord>>>,
}

/// Profiling collector: one production cycle per call, every cycle
/// appended to the shared log. Deterministic — the production
/// collector's own semantics, only observed.
struct ProfilingCollector {
    log: CycleLog,
}

impl Collector for ProfilingCollector {
    fn collect(&mut self, heap: &mut Heap, roots: &Roots) -> u32 {
        let stats = production_collect(heap, roots);
        self.log.records.borrow_mut().push(CycleRecord {
            marked: stats.marked,
            swept: stats.swept,
            live_before: stats.live_before,
            live_after: stats.live_after,
        });
        stats.swept
    }
}

/// Compile a .krf source to bytecode (the B4-guard churn_bc shape).
fn bc(src: &str) -> kerf::compiler::Bytecode {
    let forms = read_program(FileId(0), src).expect("read");
    let items = expand_program(&forms).expect("expand");
    compile_program(&items).expect("compile")
}

/// The churn program generator (B4 axis shape): N defines, each
/// allocating one pair whose value is dropped at the next define.
fn churn_src(pairs: usize) -> String {
    let mut src = String::with_capacity(pairs * 32);
    for i in 0..pairs {
        src.push_str(&format!("(define d{i} (car (cons {i} nil))) "));
    }
    src
}

/// Run one workload under one budget; print the per-cycle records
/// and return them (the caller aggregates). A fail-closed
/// BudgetExceeded is PRINTED AS DATA (the workload's gc window is
/// empty below the live-frame floor — the W-3.4 finding shape),
/// and an empty cycle log is returned so the summary line carries
/// the fact.
fn run_logged(label: &str, src: &str, budget: u32) -> Vec<CycleRecord> {
    let log = CycleLog::default();
    let collector = Box::new(ProfilingCollector { log: log.clone() });
    let mut vm = match Vm::with_budget_and_collector(bc(src), budget, collector) {
        Ok(vm) => vm,
        Err(e) => {
            println!("-- {label} budget={budget}: vm build failed: {e:?}");
            return Vec::new();
        }
    };
    if let Err(e) = vm.run() {
        println!(
            "-- {label} budget={budget}: run failed closed: {e:?} (live frame/cell floor above the budget epoch — no gc window)"
        );
    }
    let records = log.records.borrow().clone();
    println!("-- {label} budget={budget}: {} cycle(s)", records.len());
    for (i, r) in records.iter().enumerate() {
        println!(
            "   cycle {c:>2}: live_before={lb:>5} marked={m:>5} swept={s:>5} live_after={la:>5} survival={sv}.{sv2:02}%",
            c = i + 1,
            lb = r.live_before,
            m = r.marked,
            s = r.swept,
            la = r.live_after,
            sv = r.survival_bps() / 100,
            sv2 = r.survival_bps() % 100,
        );
    }
    records
}

/// One workload's aggregate line: cycles, first-cycle death share,
/// mean survival, and the live_after trajectory shape (monotone
/// growth vs. flat vs. empty).
fn summarize(label: &str, budget: u32, records: &[CycleRecord]) {
    if records.is_empty() {
        println!(
            "SUMMARY {label} budget={budget}: cycles=0 — no collection fired (allocation load below the budget epoch)"
        );
        return;
    }
    let first = &records[0];
    let first_death_bps = if first.live_before == 0 {
        0
    } else {
        (u64::from(first.swept) * 10_000) / u64::from(first.live_before)
    };
    let mean_survival_bps =
        records.iter().map(CycleRecord::survival_bps).sum::<u64>() / records.len() as u64;
    let total_swept: u64 = records.iter().map(|r| u64::from(r.swept)).sum();
    let total_marked_last = u64::from(records.last().map(|r| r.live_after).unwrap_or(0));
    // Old-generation accumulation shape: is live_after growing
    // monotonically across cycles (the major-cycle scan-set input)?
    let monotone = records
        .windows(2)
        .all(|w| w[1].live_after >= w[0].live_after);
    println!(
        "SUMMARY {label} budget={budget}: cycles={n} first-cycle-death={fd}.{fd2:02}% mean-survival={ms}.{ms2:02}% total-swept={ts} final-live={fl} live-after-monotone={mo}",
        n = records.len(),
        fd = first_death_bps / 100,
        fd2 = first_death_bps % 100,
        ms = mean_survival_bps / 100,
        ms2 = mean_survival_bps % 100,
        ts = total_swept,
        fl = total_marked_last,
        mo = if monotone { "yes" } else { "no" },
    );
}

/// The corpus-representative sources (verbatim from
/// tests/v1/stage1/corpus/ — the allocation-representative picks).
const IOTA_50: &str =
    "(define (iota n) (if (= n 0) nil (cons n (iota (- n 1))))) (define result (car (iota 50)))";
const MAP_DOUBLE: &str = "(define (map f xs) (if (nil? xs) nil (cons (f (car xs)) (map f (cdr xs))))) (define (double x) (* 2 x)) (define result (map double (quote (1 2 3))))";
const FIB_25: &str =
    "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define result (fib 25))";

fn main() {
    println!("== W-3.4 MUV 3.4-a: GC lifetime profile (per-cycle survival) ==");

    // 1. churn(2000) @ 1024 — the B4 axis shape verbatim: the
    //    deterministic 1-cycle / 1023-swept baseline this sweep
    //    must reproduce (the guard's twin measurement).
    let r = run_logged("churn-2000", &churn_src(2_000), 1_024);
    summarize("churn-2000", 1_024, &r);

    // 2. churn(10000) @ 1024 — the multi-cycle extension: is the
    //    death rate flat across cycles (pure-transient live set)?
    let r = run_logged("churn-10000", &churn_src(10_000), 1_024);
    summarize("churn-10000", 1_024, &r);

    // 3. churn(10000) @ 4096 — the epoch-size sensitivity: a wider
    //    budget epoch lets more transients pile up before the
    //    cycle; survival should stay near the 1024 shape if the
    //    workload is truly transient-only.
    let r = run_logged("churn-10000", &churn_src(10_000), 4_096);
    summarize("churn-10000", 4_096, &r);

    // 4. iota(50) @ 64/80/96 — corpus bnd-009 under tight epochs:
    //    the descent holds ~50 frames live, the ascent conses the
    //    chain — a budget in the 64..96 band fires mid-ascent when
    //    frames + built-prefix cross the epoch (the
    //    intermediate-survival contrast: the partial chain is all
    //    alive because the program is mid-construction).
    for budget in [64u32, 80, 96] {
        let r = run_logged("iota-50", IOTA_50, budget);
        summarize("iota-50", budget, &r);
    }

    // 5. map-double @ 8/16 — corpus pos-020 under tight epochs:
    //    the input list stays live while the output list grows
    //    (two coexisting chains — the partial-survival shape). The
    //    workload is small (4 recursion frames + ~7 cells), so the
    //    epoch band that fires at all is narrow; a too-tight
    //    epoch fails closed and is recorded as data.
    for budget in [8u32, 16] {
        let r = run_logged("map-double", MAP_DOUBLE, budget);
        summarize("map-double", budget, &r);
    }

    // 6. fib(25) @ 22/26 — corpus bnd-008, the empty-window pole:
    //    the live-frame floor sits at the recursion depth (~25 —
    //    frames are budget units and uncollectable while active).
    //    Budget 22 fails closed below the floor; budget 26 never
    //    fires above it. Between the two poles there is NO budget
    //    that produces a cycle — the gc window for frame-live
    //    recursion is empty, which is the W-3.4 finding itself.
    for budget in [22u32, 26] {
        let r = run_logged("fib-25", FIB_25, budget);
        summarize("fib-25", budget, &r);
    }

    println!("== profile complete ==");
}

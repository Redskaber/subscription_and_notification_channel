//! The W-HM-TWIN 127-d integration verification (w-hm-twin-window.md
//! §4, the MUV boundary): the test face — the paired positive/negative
//! probes on BOTH judgment faces (one probe set, the infer twin and
//! the check twin, both oracles — the 127-a/b rounds' probes were
//! face-specific, this family pins the pairing), the corpus HM-axis
//! reclassification (every corpus row classified exactly once on the
//! inference axis AND the check axis with the exact counts and the
//! diagnostic-carrying row names pinned — the sweeps rode lower
//! bounds, this pin turns any corpus change that shifts either axis
//! into a visible break instead of a silent ride), and the budget
//! row's per-source route (the 127-a budget row rode the steady
//! route only; the E0011 face through the recompile-per-case route —
//! the delivery face the steady chain exists to amortize).
//!
//! Probe discipline (the sweep precedents): the paired probes ride the
//! HM negative family (the E0009/E0010 faces) and the accept anchors;
//! the corpus classification rides the same read→expand→feed gate the
//! sweeps use; the budget's far side only rides the programmatic path
//! (the reader's nesting cap is 256).

use kerf::core::{CoreExpr, LiteralValue, ModuleItem};
use kerf::driver::{
    SteadyCheckChain, SteadyTypecheckChain, infer_twin_per_source_dual, oracle_check_axes,
    oracle_inference_axes,
};
use kerf::expander::expand_program;
use kerf::reader::read_program;
use kerf::span::{ByteOffset, ExpansionId, FileId, Span, Symbol};

const CORPUS_DIR: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/tests/v1/stage1/corpus");

/// Deep trees (the corpus's nesting family) recurse through the
/// harness's Rust tree walkers; the demand-allocated stack discipline
/// of the sibling chain tests (the steady-expander precedent).
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly");
}

fn sp(a: u32, b: u32) -> Span {
    Span::new(FileId(0), ByteOffset(a), ByteOffset(b), ExpansionId::ROOT)
        .expect("test span is ordered")
}

fn sym(text: &str) -> Symbol {
    Symbol::new(text).expect("test symbol is valid")
}

/// Expand one probe source into the item stream both faces consume.
fn items_of(source: &str) -> Vec<ModuleItem> {
    let forms = read_program(FileId(0), source).expect("the probe reads");
    expand_program(&forms).expect("the probe expands")
}

/// The paired probe family — every row runs through BOTH judgment
/// faces (the infer chain + its oracle, the check chain + its oracle):
/// the positive rows and the HM negative family, one set, both axes.
const PAIRED_PROBES: &[(&str, &str)] = &[
    // ---- positive: the accept anchors ----
    (
        "accept-anchor",
        "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2)))))",
    ),
    (
        "let-polymorphism",
        "(define (id x) x)\n(define (a y) (id 1))\n(define (b z) (id #t))",
    ),
    (
        "handle-rows",
        "(define (f x) (handle (perform log x) (log (fn (v) v))))",
    ),
    (
        "module-flat-table",
        "(module m (define x 1) (define (f y) y))",
    ),
    // ---- negative: the HM family (the E0009/E0010 faces) ----
    (
        "t1-bool-demand",
        "(define (f x) (if x 1 2))\n(define (g y) (f 1))",
    ),
    ("t2-not-callable", "(define (f y) ((+ 1 2) 3))"),
    ("t3-non-numeric", "(define (f x) (+ x \"a\"))"),
    ("t5-cond-mismatch", "(define (f x) (if 1 2 3))"),
    ("t7-occurs", "(define omega (fn (x) (x x)))"),
    // The empty stream (the nil payload — the zero-define module).
    ("empty-stream", ";; nothing but trivia\n"),
];

/// One paired-probe drive: both judgment faces, both oracles, twin ≡
/// oracle on each axis (the shared body the positive and negative
/// family tests below consume).
fn paired_drive(
    infer_chain: &SteadyTypecheckChain,
    check_chain: &SteadyCheckChain,
    name: &str,
    items: &[ModuleItem],
) -> (String, String) {
    let infer_twin = infer_chain
        .infer(items)
        .unwrap_or_else(|e| panic!("{name}: the twin inference runs: {e}"));
    assert_eq!(
        infer_twin,
        oracle_inference_axes(items),
        "{name}: the inference twin matches the oracle"
    );
    let check_twin = check_chain
        .check(items)
        .unwrap_or_else(|e| panic!("{name}: the twin check runs: {e}"));
    assert_eq!(
        check_twin,
        oracle_check_axes(items),
        "{name}: the check twin matches the oracle"
    );
    (infer_twin, check_twin)
}

#[test]
fn hm_twin_face_positive_probes_match_on_both_faces() {
    deep_stack(|| {
        let infer_chain = SteadyTypecheckChain::new().expect("the fixed inference twin builds");
        let check_chain = SteadyCheckChain::new().expect("the fixed checker twin builds");
        for (name, source) in PAIRED_PROBES {
            if !matches!(
                *name,
                "accept-anchor" | "let-polymorphism" | "handle-rows" | "module-flat-table"
            ) {
                continue;
            }
            let items = items_of(source);
            let (infer_twin, check_twin) = paired_drive(&infer_chain, &check_chain, name, &items);
            // The positive rows are clean on both axes.
            assert!(
                infer_twin.starts_with("(ok (types"),
                "{name}: the positive row's inference verdict is clean: {infer_twin}"
            );
            assert!(
                check_twin.starts_with("(ok (table"),
                "{name}: the positive row's check verdict is clean: {check_twin}"
            );
        }
        // The empty stream's exact zero-define verdicts on both axes.
        let empty_items = items_of(";; nothing but trivia\n");
        let (empty_infer, empty_check) =
            paired_drive(&infer_chain, &check_chain, "empty-stream", &empty_items);
        assert_eq!(
            empty_infer, "(ok (types) (diags))",
            "the empty stream infers to the zero-define module"
        );
        assert_eq!(
            empty_check, "(ok (table (defines) (assigned)) (diags))",
            "the empty stream checks to the zero-define module"
        );
    });
}

#[test]
fn hm_twin_face_negative_probes_match_on_both_faces() {
    deep_stack(|| {
        let infer_chain = SteadyTypecheckChain::new().expect("the fixed inference twin builds");
        let check_chain = SteadyCheckChain::new().expect("the fixed checker twin builds");
        for (name, source) in PAIRED_PROBES {
            if !matches!(
                *name,
                "t1-bool-demand"
                    | "t2-not-callable"
                    | "t3-non-numeric"
                    | "t5-cond-mismatch"
                    | "t7-occurs"
            ) {
                continue;
            }
            let items = items_of(source);
            let (infer_twin, _check_twin) = paired_drive(&infer_chain, &check_chain, name, &items);
            // The negative rows report on the inference axis (the
            // detection-power arm — a guard that passes because
            // nothing fired pins nothing).
            assert!(
                infer_twin.contains("E00"),
                "{name}: the negative row really reports: {infer_twin}"
            );
            // And the twin's verdict is an ok-carrier (the HM judgment
            // face collects findings — the module still loads).
            assert!(
                infer_twin.starts_with("(ok (types"),
                "{name}: the negative row rides the ok carrier: {infer_twin}"
            );
        }
    });
}

/// The corpus HM-axis reclassification: every corpus row classified
/// exactly once on BOTH axes with the exact counts pinned — the
/// diagnostic-carrying fed rows by name, the clean fed rows by count,
/// the layer rejections by count. Any corpus change that shifts the
/// classification (a row moving between clean and diagnostic, a new
/// row, a dropped row) breaks this pin instead of silently riding the
/// sweeps' lower bounds.
#[test]
fn corpus_hm_axis_classification_is_pinned_on_both_axes() {
    deep_stack(|| {
        // The classification rides the ORACLES (the twin ≡ oracle
        // equivalence is the sweeps' own face — pinning the corpus's
        // axis through the oracle pins the twin's axis transitively).
        let entries = std::fs::read_dir(CORPUS_DIR).expect("the corpus directory is in tree");
        let mut files: Vec<_> = entries
            .filter_map(|e| e.ok())
            .map(|e| e.path())
            .filter(|p| p.extension().is_some_and(|x| x == "krf"))
            .collect();
        files.sort();
        assert_eq!(
            files.len(),
            91,
            "the corpus is 91 cases (85 frozen + the extern family)"
        );
        let mut reader_rejected = Vec::new();
        let mut expansion_rejected = Vec::new();
        let mut infer_diagnostic = Vec::new();
        let mut check_diagnostic = Vec::new();
        let mut infer_clean = 0usize;
        let mut check_clean = 0usize;
        for path in &files {
            let source = std::fs::read_to_string(path).expect("corpus file reads");
            let case = path.file_name().unwrap().to_string_lossy().to_string();
            let forms = match read_program(FileId(0), &source) {
                Ok(forms) => forms,
                Err(_) => {
                    reader_rejected.push(case);
                    continue;
                }
            };
            let items = match expand_program(&forms) {
                Ok(items) => items,
                Err(_) => {
                    expansion_rejected.push(case);
                    continue;
                }
            };
            // The inference axis: fed rows split by the diagnostics
            // channel (warnings ride too — E0011 is a finding).
            let infer_verdict = oracle_inference_axes(&items);
            if infer_verdict.contains("E00") {
                infer_diagnostic.push(case.clone());
            } else {
                infer_clean += 1;
            }
            // The check axis: the same split on the check oracle.
            let check_verdict = oracle_check_axes(&items);
            if check_verdict.contains("E00") {
                check_diagnostic.push(case);
            } else {
                check_clean += 1;
            }
        }
        // The layer rejections are shared by both axes (the rows never
        // reach either judgment face).
        assert_eq!(
            reader_rejected.len() + expansion_rejected.len() + infer_diagnostic.len() + infer_clean,
            91,
            "every corpus row is classified exactly once on the inference axis"
        );
        assert_eq!(
            reader_rejected.len() + expansion_rejected.len() + check_diagnostic.len() + check_clean,
            91,
            "every corpus row is classified exactly once on the check axis"
        );
        // ---- the pinned reclassification (the r130 measured face) ----
        // Reader rejections (8): the nesting cap plus the four token
        // grammar rows and the three literal-overflow rows.
        assert_eq!(
            reader_rejected,
            vec![
                "bnd-007-nesting-257-fails.krf",
                "neg-001-unclosed-paren.krf",
                "neg-002-stray-close.krf",
                "neg-003-unterminated-string.krf",
                "neg-004-bad-hash-token.krf",
                "neg-021-empty-application.krf",
                "neg-054-i64-overflow-literal.krf",
                "neg-055-float-overflow-literal.krf",
            ]
        );
        // Expansion rejections (19): the malformed-form family, the
        // module family, the macro family and the extern family.
        assert_eq!(
            expansion_rejected,
            vec![
                "bnd-010-expansion-limit.krf",
                "neg-010-top-level-expression.krf",
                "neg-011-malformed-fn.krf",
                "neg-012-malformed-let.krf",
                "neg-013-unbound-reference.krf",
                "neg-014-quote-symbol.krf",
                "neg-015-set-unbound.krf",
                "neg-016-malformed-handle.krf",
                "neg-017-malformed-define.krf",
                "neg-018-module-cycle.krf",
                "neg-019-module-missing.krf",
                "neg-046-forward-reference.krf",
                "neg-050-pattern-mismatch.krf",
                "neg-051-duplicate-pattern-vars.krf",
                "neg-052-ellipsis-rejected.krf",
                "neg-053-module-macro-outside.krf",
                "neg-059-extern-bad-type.krf",
                "neg-060-extern-bad-abi.krf",
                "neg-061-extern-collision.krf",
            ]
        );
        // Inference-axis diagnostics (6): the E0009 family the 127-a
        // sweep doc named — the rows the HM judgment face owns.
        assert_eq!(
            infer_diagnostic,
            vec![
                "neg-031-nonbool-cond.krf",
                "neg-037-multi-error-collection.krf",
                "neg-041-car-nonpair.krf",
                "neg-044-add-bool.krf",
                "neg-047-write-line-int.krf",
                "neg-056-type-error-duplicate-codes.krf",
            ]
        );
        assert_eq!(infer_clean, 58);
        // Check-axis diagnostics (10): the R2/R3/R4/R5/R6/R7 rows the
        // conservative checker owns (the pos-028 row carries the E0008
        // rebind warning — a positive-tagged row on the check axis).
        assert_eq!(
            check_diagnostic,
            vec![
                "neg-030-arity-known.krf",
                "neg-031-nonbool-cond.krf",
                "neg-032-call-literal.krf",
                "neg-033-call-numeric-global.krf",
                "neg-034-handler-arity.krf",
                "neg-035-unhandled-effect.krf",
                "neg-036-literal-handler.krf",
                "neg-037-multi-error-collection.krf",
                "neg-057-assign-to-captured.krf",
                "pos-028-warn-rebind-builtin.krf",
            ]
        );
        assert_eq!(check_clean, 54);
        // The fed rows (64 on both axes): 58 clean + 6 diagnostic on
        // the inference axis, 54 clean + 10 diagnostic on the check
        // axis — the sweeps' `fed >= 55` lower bound rides 64.
        assert_eq!(infer_clean + infer_diagnostic.len(), 64);
        assert_eq!(check_clean + check_diagnostic.len(), 64);
    });
}

/// The FP5 lineage (the 127-a budget row's per-source face): the
/// 600-deep define only rides the programmatic path, and the 127-a
/// round pinned it on the steady route alone — this row pins it on
/// the per-source text route (recompiled per case, both engines) with
/// the exclusion semantics asserted: the deep define drops whole
/// (one E0011 warning, never an error), the shallow define survives.
#[test]
fn infer_twin_budget_row_matches_the_oracle_on_the_per_source_route() {
    deep_stack(|| {
        let mut cur = CoreExpr::Literal {
            span: sp(0, 1),
            value: LiteralValue::Int(1),
        };
        for _ in 0..600 {
            cur = CoreExpr::If {
                span: sp(0, 2),
                cond: Box::new(CoreExpr::Literal {
                    span: sp(0, 1),
                    value: LiteralValue::Bool(true),
                }),
                then_branch: Box::new(cur),
                else_branch: Box::new(CoreExpr::Literal {
                    span: sp(0, 1),
                    value: LiteralValue::Int(2),
                }),
            };
        }
        let items = vec![
            ModuleItem::Define {
                span: sp(0, 3),
                name: sym("deep"),
                value: cur,
            },
            ModuleItem::Define {
                span: sp(0, 11),
                name: sym("shallow"),
                value: CoreExpr::Literal {
                    span: sp(0, 5),
                    value: LiteralValue::Int(7),
                },
            },
        ];
        let per_source = infer_twin_per_source_dual(&items)
            .expect("the per-source route runs on the budget row");
        assert_eq!(
            per_source.vm_text, per_source.eval_text,
            "the per-source route's two engines agree on the budget row"
        );
        let oracle = oracle_inference_axes(&items);
        assert_eq!(
            per_source.vm_text, oracle,
            "the per-source budget row matches the oracle"
        );
        assert!(
            per_source.vm_text.contains("E0011"),
            "the budget warning rides the row: {}",
            per_source.vm_text
        );
        assert!(
            per_source.vm_text.contains("(tdef shallow"),
            "the shallow define survives the exclusion"
        );
        assert!(
            !per_source.vm_text.contains("(tdef deep"),
            "the deep define is excluded whole (no partial annotations)"
        );
    });
}

//! Stage 1.9 stage-exit evidence — the §21.5 nine-signal claims as
//! re-runnable cargo tests (docs/develop/v1/stage-1/
//! deep-review-round1.9.md D3/D8; the audit section V carries the
//! same anchors in the gate-audit binary).
//!
//! One test per signal-adjacent behavior: semantic stability (both
//! engines over the builtin families), bootstrap verification (gate
//! B on a composite source), the frozen acceptance face (the corpus
//! directory contract), the budget face, the render goldens, the
//! frozen cardinalities, the zero-finding dual, the full-pipeline
//! dataflow, the two-layer batch, and the recovery close.

use kerf::driver::{
    Engine, Session, assembled_expander_target_source, check_source, gate_b_bytecode, parse_target,
    run_parity_source, run_source,
};

fn corpus_dir() -> String {
    format!("{}/tests/v1/stage1/corpus", env!("CARGO_MANIFEST_DIR"))
}

// ---------- signal 1: semantic stability ----------

#[test]
fn exit_semantic_stability_builtin_families_both_engines() {
    let src = "(define p (cons 1 (cons 2.5 nil))) (define a (+ 1 2)) (define b (< 1 2)) (define c (car p)) (define e (nil? nil)) (define f (eq? a a)) (define g (not b))";
    let mut s = Session::new();
    let vm = run_source(&mut s, "st.krf", src, Engine::Vm, &[]).expect("vm run");
    let mut s = Session::new();
    let ev = run_source(&mut s, "st.krf", src, Engine::Eval, &[]).expect("eval run");
    for name in ["a", "b", "c", "e", "f", "g"] {
        let vv = vm.global(name).map(|v| v.to_string());
        let ve = ev.global(name).map(|v| v.to_string());
        assert_eq!(vv, ve, "engines disagree on `{name}`");
    }
    assert_eq!(vm.global("a").map(|v| v.to_string()), Some("3".into()));
    assert_eq!(vm.global("c").map(|v| v.to_string()), Some("1".into()));
}

// ---------- signal 2: bootstrap verification ----------

#[test]
fn exit_bootstrap_gate_b_on_a_composite_source() {
    // A macro + let + tail-if composite through the assembled .krf
    // expander: oracle and rebuilt items compile to identical
    // bytecode (the fixpoint contract at the stage close).
    let src = "(define-syntax swap (syntax-rules nil ((_ a b) (cons b (cons a nil))))) (define r (do (let ((q (swap 1 2))) (if (nil? (cdr q)) (car q) 9)) 0))";
    gate_b_bytecode("exit-gate-b", src).expect("gate B holds on the composite");
}

// ---------- signal 3: the frozen acceptance face ----------

#[test]
fn exit_corpus_directory_contract_holds() {
    let mut paths: Vec<_> = std::fs::read_dir(corpus_dir())
        .expect("corpus directory")
        .flatten()
        .map(|e| e.path())
        .filter(|p| p.extension().is_some_and(|x| x == "krf"))
        .collect();
    paths.sort();
    assert!(paths.len() >= 79, "corpus floor: {} < 79", paths.len());
    for path in paths {
        let source = std::fs::read_to_string(&path).expect("corpus file");
        let mut s = Session::new();
        match run_parity_source(&mut s, "c.krf", &source, &[]) {
            Ok(report) => assert!(
                report.agrees(),
                "parity drift in {:?}: vm=`{}` eval=`{}`",
                path.file_name(),
                report.vm_repr,
                report.eval_repr
            ),
            // Negative directives reject before parity — the
            // non-empty batch is the frozen expectation.
            Err(diags) => assert!(!diags.is_empty()),
        }
    }
}

// ---------- signal 4: the budget face ----------

#[test]
fn exit_budget_is_live_and_fails_closed() {
    use kerf_vm::Vm;
    let bc = kerf_compiler::compile_program(&[]).expect("empty program compiles");
    let mut vm = Vm::with_budget(bc, 4).expect("budgeted vm");
    let value = vm.run().expect("one entry frame fits");
    assert_eq!(value.to_string(), "nil");
    assert!(vm.allocations() >= 1, "the entry frame is budgeted");
    let bc = kerf_compiler::compile_program(&[]).expect("empty program compiles again");
    let mut vm0 = Vm::with_budget(bc, 0).expect("zero-budget vm");
    assert!(
        vm0.run().is_err(),
        "zero budget fails closed — the entry frame cannot allocate"
    );
}

// ---------- signal 5: render goldens stay byte-stable ----------

#[test]
fn exit_render_golden_e0009_call_site_anchor() {
    let mut s = Session::new();
    let err = run_source(
        &mut s,
        "g.krf",
        "(define f (fn (x) (if x 1 2))) (define r (f 1))",
        Engine::Vm,
        &[],
    )
    .expect_err("the bool-demand mismatch blocks");
    let rendered = kerf::driver::render_diagnostics(&s, &err);
    assert!(
        rendered.contains("error[E0009]: type mismatch: expected `bool`, found `int`"),
        "{rendered}"
    );
    // The anchor is the offending argument at its call site
    // (probe-verified at the 1.9 close).
    assert!(rendered.contains("--> g.krf:1:45"), "{rendered}");
}

// ---------- signal 6: frozen cardinalities (handling degrees) ----------

#[test]
fn exit_frozen_faces_hold_their_cardinality() {
    assert_eq!(kerf_vm::Builtin::ALL.len(), 18, "the builtin set is frozen");
    // The opcode set grew 24 -> 25 at the Stage 2.1 semantic MUV
    // (load-captured, LA-3 — the K192 separated-opcode ruling; the
    // store twin stays unlanded with the immutable-capture subset,
    // LA-7), then 25 -> 26 at W-VM-SUPERINSTR (call-global, the
    // fused load-global + call — w-vm-superinstr-window.md SI-2,
    // still within the "about 35 opcodes" capability model).
    assert_eq!(
        kerf_compiler::Opcode::ALL.len(),
        26,
        "the opcode set is frozen"
    );
}

// ---------- signal 7: the zero-finding dual ----------

#[test]
fn exit_zero_findings_on_the_two_largest_legal_programs() {
    // (a) the assembled `.ktf` expander twin (self-forms — the 1.8
    // release-and-demand hardening anchor, on the production-chain
    // skin since the r104 E5 batch-3 teardown).
    let assembled = assembled_expander_target_source();
    let self_forms = assembled.replace("\ndefine(result, ex_run(forms));", "");
    let mut s = Session::new();
    let program = parse_target(&mut s, "a.ktf", &self_forms).expect("the assembly parses");
    let findings = program.typecheck();
    assert!(
        findings
            .iter()
            .all(|d| d.severity != kerf::driver::Severity::Error),
        "assembled expander: {findings:?}"
    );
    // (b) a clean recursive program through the check face.
    let mut s = Session::new();
    let out = check_source(
        &mut s,
        "f.krf",
        "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define r (fib 15))",
    )
    .expect("clean program checks");
    assert!(out.warnings.is_empty(), "zero findings: {:?}", out.warnings);
}

// ---------- signal 9: the full-pipeline dataflow ----------

#[test]
fn exit_full_pipeline_dataflow_end_to_end() {
    let src = "(define (add a b) (+ a b))\n(define result (add 20 22))";
    let mut s = Session::new();
    let out = run_source(&mut s, "e2e.krf", src, Engine::Vm, &[]).expect("full chain");
    assert_eq!(
        out.global("result").map(|v| v.to_string()),
        Some("42".into())
    );
    let mut s = Session::new();
    let check = check_source(&mut s, "e2e.krf", src).expect("check face");
    assert!(check.func_count >= 2, "entry + one closure proto");
    assert!(check.instr_count >= 5, "instructions emitted");
}

// ---------- the two-layer batch ----------

#[test]
fn exit_two_static_layers_coexist_in_one_batch() {
    let mut s = Session::new();
    let err = check_source(&mut s, "two.krf", "(define r (if 1 2 3))")
        .expect_err("the definite condition error");
    let tags: Vec<&str> = err.iter().map(|d| d.code.tag()).collect();
    assert!(
        tags.contains(&"E0003") && tags.contains(&"E0009"),
        "both layers report: {tags:?}"
    );
}

// ---------- the recovery close ----------

#[test]
fn exit_recovery_clean_run_after_a_rejection() {
    let mut s = Session::new();
    let _ = run_source(&mut s, "bad.krf", "(define r (car 5))", Engine::Vm, &[]);
    let out = run_source(&mut s, "good.krf", "(define r (+ 40 2))", Engine::Vm, &[])
        .expect("a clean program runs after a rejection");
    assert_eq!(out.global("r").map(|v| v.to_string()), Some("42".into()));
}

//! The r124 junction-3 extern-consumption disclosure pins (W-3.12
//! §6e — segment-three adjudication's implementation face): the
//! emit fix, the twin-side consumption, and the expressibility
//! boundary, each pinned by its own row so the ledger never
//! silently regresses.
//!
//! - **AM01/AM02** pin the two CONVERGED rows (pos-037/neg-058):
//!   the products carry the extern table on both engines' analysis
//!   dumps, parity holds end-to-end — the r124 emit fix (the r122
//!   double-quote family, second member) + `cp_extern_walk` + the
//!   parity-section extension landed together.
//! - **AM03** pins the ONE remaining disclosed drift (neg-062): the
//!   derived-symbol character police has no frozen-subset
//!   expression (zero character ops in the 18 builtins), so the
//!   twin compiles the row on while the oracle's compile rejects
//!   it, and the rebuild face's verify judge catches the hand-built
//!   table through the same floor (the r123 two-judges contract).
//! - **AM04** pins the twin-side name-uniqueness police: a
//!   duplicate entry rejects at junction 3 with the
//!   `extern-name-duplicate` key — the only C-domain face the
//!   frozen subset can express (`eq?` is content comparison for
//!   strings).
//! - **AM05** pins the emit face itself: names ride single-quoted
//!   (the double-quote form split into three tokens and the bare
//!   symbol datum had no Stage 0 value model — the parse died at
//!   assembly).

use kerf::driver::{
    COMPILER_TARGET_SOURCE, ComposedLayer, composed_target_chain_parity, ktf_compile_rich,
    target_items_stream_prefix,
};
use kerf_core::{ExternAbi, ExternItem, ExternType, ModuleItem};
use kerf_span::{ByteOffset, ExpansionId, FileId, Span, Symbol};

fn fx(start: u32, end: u32) -> Span {
    Span::new(
        FileId(0),
        ByteOffset(start),
        ByteOffset(end),
        ExpansionId(0),
    )
    .expect("fixture span")
}

fn extern_entry(name: &str) -> ExternItem {
    ExternItem {
        span: fx(0, 20),
        name: Symbol::new(name).expect("symbol"),
        params: vec![ExternType::Int, ExternType::Int],
        ret: ExternType::Int,
    }
}

fn extern_items(entries: Vec<ExternItem>) -> Vec<ModuleItem> {
    vec![ModuleItem::Extern {
        span: fx(1, 60),
        abi: ExternAbi::C,
        items: entries,
    }]
}

#[test]
fn am01_pos037_converges_with_the_table_in_the_products() {
    let source = ";; expect: value 3\n(extern \"C\" (add (int int) int))\n(define result (+ 1 2))";
    let report = composed_target_chain_parity("am01-pos-037", source);
    assert!(report.matched, "{}", report.failure_line());
    assert_eq!(report.layer, ComposedLayer::Compile);
    assert!(report.read_matched);
    assert_eq!(report.expand_matched, Some(true));
    assert_eq!(report.compile_matched, Some(true));
}

#[test]
fn am02_neg058_converges_with_the_table_in_the_products() {
    let source =
        ";; expect: runtime-error\n(extern \"C\" (add (int int) int))\n(define result (add 2 40))";
    let report = composed_target_chain_parity("am02-neg-058", source);
    assert!(report.matched, "{}", report.failure_line());
    assert_eq!(report.layer, ComposedLayer::Compile);
    assert_eq!(report.compile_matched, Some(true));
}

#[test]
fn am03_neg062_stays_the_disclosed_drift_the_verify_judge_catches_it() {
    let source = ";; expect: compile-error\n(extern \"C\" (set! (int) int))\n(define result 1)";
    let report = composed_target_chain_parity("am03-neg-062", source);
    // The oracle routing classifies the row at Compile; the twin
    // compiles on (the character police is inexpressible), and the
    // drift is the rebuild face's verify rejection of the
    // hand-built table through the same floor.
    assert!(!report.matched);
    assert_eq!(report.layer, ComposedLayer::Compile);
    assert!(report.drift.is_some());
    assert!(
        report.drift.as_deref().unwrap().contains(
            "rebuilt product rejected by verify: extern entry `0`: `set!` derives a C symbol \
             that is not a valid C identifier"
        ),
        "the drift rides the verify judge's own key: {:?}",
        report.drift
    );
}

#[test]
fn am04_duplicate_names_reject_twin_side_with_the_parity_key() {
    // Two entries with the SAME name in one block: the frozen
    // subset CAN express this face — `eq?` is content comparison
    // for strings — so the twin must reject at junction 3 with the
    // oracle's own `extern-name-duplicate` key (compile_program
    // rejects the same items through `extern_table_floor`).
    let items = extern_items(vec![extern_entry("add"), extern_entry("add")]);
    let run = ktf_compile_rich(&items, COMPILER_TARGET_SOURCE);
    let run = run.expect("the assembled twin program drives");
    assert_eq!(
        run.vm_text, run.eval_text,
        "both engines reject the duplicate with one key"
    );
    assert_eq!(
        run.vm_text, "extern entry `1` repeats the name `add` @ <no-span>",
        "the twin's rejection rides the oracle's own parity key (index = the repeated \
         row's position, the oracle's `extern_table_floor` semantics)"
    );
    assert!(run.bytecode.is_none(), "no rebuilt product on a rejection");
    let oracle = kerf::compiler::compile_program(&items);
    assert!(oracle.is_err(), "the oracle rejects the same table");
}

#[test]
fn am05_the_emit_face_rides_names_single_quoted() {
    // The r124 emit fix: the double-quoted name form (`""add""`)
    // split into three tokens under the target lexer, the bare
    // symbol datum had no Stage 0 value model, and the assembled
    // source died at parse. The names ride single-quoted now.
    let prefix = target_items_stream_prefix(&extern_items(vec![extern_entry("add")]));
    assert!(
        prefix.contains("(\"add\", (\"int\", \"int\"), \"int\")"),
        "the entry rides single-quoted: {prefix}"
    );
    assert!(
        !prefix.contains("\"\"add\"\""),
        "the double-quote form must never come back"
    );
}

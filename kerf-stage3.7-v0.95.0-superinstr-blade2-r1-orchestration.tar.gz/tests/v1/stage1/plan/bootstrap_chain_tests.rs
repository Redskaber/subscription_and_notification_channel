//! The W-3.12 segment-one steady-state bootstrap chain (w3.12-frontend-window
//! §5, the r120 T-b activation agenda): the twin read chain compiled
//! ONCE, fed per source through the injection channel — the
//! productionized form of the RS-1 test channel.
//!
//! Three layers, per the corpus discipline:
//! - **Positive**: the steady chain reads the full corpus and matches
//!   the Rust oracle on both axes (the reader-segment fixpoint face
//!   under today's tree — the `.krf` own-source family retired with
//!   the r104 E5 batch-3 teardown, so the corpus sweep plus the
//!   boundary rejection IS the segment's self-application evidence);
//!   the dual-engine agreement on probe sources (the RS-4 four-cell
//!   matrix); the per-read shape (one compiled product, many reads,
//!   each fed by its own injection).
//! - **Negative**: the target-skin input boundary (a `.ktf` source
//!   rejected identically by the steady chain and the oracle — the
//!   twins implement the S-expr read chain, target-skin text is not
//!   S-expr text); the reader-layer rejection corpus rows ride the
//!   error axis of the sweep itself; the injection-feeds-every-read
//!   contract (two different sources must read differently — a
//!   program-side define clobber of `source_bytes` would collapse
//!   them onto one table).
//! - **Cross-route equivalence**: the steady route and the per-source
//!   compile route (the RS-1 test channel form) decode to identical
//!   outcomes on the same sources — the delivery face changed, the
//!   computed verdict did not.

use kerf::driver::{
    SteadyReaderChain, byte_table_literal, error_parity_key, oracle_dump, oracle_token_dump,
    reader_parity_full_target_with_feed,
};
use kerf::reader::read_program;
use kerf::span::FileId;

const CORPUS_DIR: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/tests/v1/stage1/corpus");

/// Deep trees (the corpus's nesting family) recurse through the
/// harness's Rust tree walkers; the demand-allocated stack
/// discipline of the sibling composed-chain tests.
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly");
}

/// One axis's normalized string form (the report family's own
/// convention: accept rows carry the dump, rejections carry
/// `ERR <key>`).
fn axis_form(axis: &Result<String, String>) -> String {
    match axis {
        Ok(dump) => dump.clone(),
        Err(key) => format!("ERR {key}"),
    }
}

/// The oracle's both-axes expectation for one source: the token dump
/// and the tree dump, or the error key a rejection decides both axes
/// with (the same normalization the per-source route's report rides).
fn oracle_axes(source: &str) -> (String, String) {
    let tokens = match oracle_token_dump(source) {
        Ok(d) => d,
        Err(err) => format!("ERR {}", error_parity_key(&err)),
    };
    let tree = match read_program(FileId(0), source) {
        Ok(forms) => oracle_dump(&forms),
        Err(err) => format!("ERR {}", error_parity_key(&err)),
    };
    (tokens, tree)
}

#[test]
fn steady_chain_reads_the_whole_corpus_and_matches_the_oracle() {
    deep_stack(|| {
        // The reader-segment fixpoint face: every corpus file through
        // the steady chain (compiled once, injected per file) — both
        // axes match the Rust oracle, accept rows and rejection rows
        // alike (the sweep IS the mixed positive/negative face: the
        // corpus carries all four ledger rows by design).
        let chain = SteadyReaderChain::new().expect("the fixed twin program builds");
        let entries = std::fs::read_dir(CORPUS_DIR).expect("the corpus directory is in tree");
        let mut files: Vec<_> = entries
            .filter_map(|e| e.ok())
            .map(|e| e.path())
            .filter(|p| p.extension().is_some_and(|x| x == "krf"))
            .collect();
        files.sort();
        assert!(
            files.len() >= 85,
            "the corpus sweep expects the full ledger population, got {}",
            files.len()
        );
        let mut accepted = 0usize;
        let mut rejected = 0usize;
        for path in &files {
            let source = std::fs::read_to_string(path).expect("corpus file reads");
            let case = path.file_name().unwrap().to_string_lossy().to_string();
            let outcome = chain.read(&source).unwrap_or_else(|e| {
                panic!("steady chain reads {case} without a harness defect: {e}")
            });
            let (oracle_tokens, oracle_tree) = oracle_axes(&source);
            assert_eq!(
                axis_form(&outcome.token_axis),
                oracle_tokens,
                "{case}: the steady chain's token axis matches the oracle"
            );
            assert_eq!(
                axis_form(&outcome.tree_axis),
                oracle_tree,
                "{case}: the steady chain's tree axis matches the oracle"
            );
            if outcome.tree_axis.is_ok() {
                accepted += 1;
            } else {
                rejected += 1;
            }
        }
        // The drift ledger's pinned distribution (§9.87.4): the
        // reader-layer rejections ride the error axis; the accept
        // rows feed the downstream junctions. Both populations are
        // non-empty on the live corpus.
        assert!(
            rejected >= 8,
            "the reader-layer rejection rows ride the sweep (got {rejected})"
        );
        assert!(
            accepted >= 58,
            "the accept rows ride the sweep (got {accepted})"
        );
    });
}

#[test]
fn steady_chain_dual_engines_agree_on_probe_sources() {
    deep_stack(|| {
        // The RS-4 four-cell matrix on the steady route: both engines
        // run the same once-compiled program with the same injection
        // and agree with each other and with the oracle — an accept
        // anchor, a reader-layer rejection, a lexical rejection and
        // the empty source (the nil table).
        let chain = SteadyReaderChain::new().expect("the fixed twin program builds");
        let probes: &[(&str, &str)] = &[
            (
                "accept-anchor",
                "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2)))))",
            ),
            ("reject-unbalanced", "((x"),
            ("reject-bad-atom", "(f 1abc)"),
            ("empty-source", ""),
            ("comment-only", ";; nothing but trivia\n"),
        ];
        for (name, source) in probes {
            let (vm_outcome, eval_outcome) = chain
                .read_dual(source)
                .unwrap_or_else(|e| panic!("{name}: the dual read runs: {e}"));
            assert_eq!(
                vm_outcome, eval_outcome,
                "{name}: the two engines agree on the steady route"
            );
            let (oracle_tokens, oracle_tree) = oracle_axes(source);
            assert_eq!(
                axis_form(&vm_outcome.token_axis),
                oracle_tokens,
                "{name}: the vm token axis matches the oracle"
            );
            assert_eq!(
                axis_form(&vm_outcome.tree_axis),
                oracle_tree,
                "{name}: the vm tree axis matches the oracle"
            );
        }
    });
}

#[test]
fn steady_chain_matches_the_per_source_route_on_the_same_sources() {
    deep_stack(|| {
        // Cross-route equivalence: the RS-1 test-channel form (the
        // byte table as a per-source program-text prefix, recompiled
        // per read) and the injection form decode to identical
        // outcomes — the delivery face changed, the verdict did not.
        let chain = SteadyReaderChain::new().expect("the fixed twin program builds");
        let probes: &[(&str, &str)] = &[
            ("anchor", "(define (f x) (* x x))"),
            ("nested", "((((((1))))))"),
            ("reject-close", ")"),
            ("string-face", "(f \"a\\nb\" #t 3.5)"),
        ];
        for (name, source) in probes {
            let steady = chain
                .read(source)
                .unwrap_or_else(|e| panic!("{name}: the steady read runs: {e}"));
            let (report, _) = reader_parity_full_target_with_feed(name, source);
            assert!(
                report.matched,
                "{name}: the per-source route matches the oracle ({})",
                report.failure_line()
            );
            // The per-source report's oracle fields carry the verdict
            // both routes matched (accept rows: the dump; rejection
            // rows: the `ERR <key>` form) — the steady route's
            // normalized axes must equal them field for field, which
            // with `matched` above is the three-way equivalence
            // (steady == per-source == oracle) on both axes.
            assert_eq!(
                axis_form(&steady.token_axis),
                report.oracle_tokens,
                "{name}: the token axes agree across the two delivery faces"
            );
            assert_eq!(
                axis_form(&steady.tree_axis),
                report.oracle_tree,
                "{name}: the tree axes agree across the two delivery faces"
            );
        }
    });
}

#[test]
fn steady_chain_is_deterministic_and_the_injection_feeds_every_read() {
    deep_stack(|| {
        // Determinism: the same source read twice decodes
        // identically. The no-define clobber contract: two DIFFERENT
        // sources read differently — a program-side define of
        // `source_bytes` would collapse every read onto one table
        // and this assertion fails loudly (the build-time
        // reference check plus this behavioral probe are the
        // contract's machine faces).
        let chain = SteadyReaderChain::new().expect("the fixed twin program builds");
        let a = "(define (a x) x)";
        let b = "(define (b y) (if y 1 2))";
        let a1 = chain.read(a).expect("the first read of a");
        let a2 = chain.read(a).expect("the second read of a");
        assert_eq!(a1, a2, "the same source reads identically");
        let b1 = chain.read(b).expect("the read of b");
        assert_ne!(
            a1, b1,
            "different sources read differently — the injection feeds every read"
        );
        // And the interleaved re-read still holds (no cross-read
        // state on the shared compiled product).
        let a3 = chain.read(a).expect("the third read of a, interleaved");
        assert_eq!(a1, a3, "the interleaved re-read is stable");
    });
}

#[test]
fn steady_chain_rejects_target_skin_input_identically_to_the_oracle() {
    deep_stack(|| {
        // The boundary: the twins implement the S-expr read chain,
        // so target-skin text is not S-expr text — the steady chain
        // rejects it, and the oracle rejects it with the same key
        // (the negative twin of the production bridge's step-4 face).
        let chain = SteadyReaderChain::new().expect("the fixed twin program builds");
        let ktf_sample = "fn main() {\n    let x = 1;\n    x\n}\n";
        let outcome = chain
            .read(ktf_sample)
            .expect("the steady read runs (a rejection is an outcome, not a defect)");
        let (oracle_tokens, oracle_tree) = oracle_axes(ktf_sample);
        assert!(
            outcome.token_axis.is_err() && outcome.tree_axis.is_err(),
            "the target-skin input is rejected on both axes"
        );
        assert_eq!(
            axis_form(&outcome.token_axis),
            oracle_tokens,
            "the rejection key matches the oracle's token axis"
        );
        assert_eq!(
            axis_form(&outcome.tree_axis),
            oracle_tree,
            "the rejection key matches the oracle's tree axis"
        );
    });
}

#[test]
fn steady_chain_compiles_once_and_reads_many_on_one_product() {
    deep_stack(|| {
        // The steady-state shape itself: ONE compiled product, MANY
        // reads — the bytecode pointer is stable across reads (no
        // recompile), and the injected payload is the RS-1 encoding
        // (one integer per byte, empty source as nil).
        let chain = SteadyReaderChain::new().expect("the fixed twin program builds");
        let first = chain.bytecode() as *const _;
        let sources = [
            "(define (f x) x)",
            "(1 2 3)",
            ";; just a comment\n",
            "(g \"payload\")",
        ];
        for source in sources {
            chain
                .read(source)
                .unwrap_or_else(|e| panic!("the read of {source:?} runs: {e}"));
            assert_eq!(
                chain.bytecode() as *const _,
                first,
                "the compiled product is one allocation across reads"
            );
        }
        // The payload encoding's literal face (the single source
        // next to the text form): "hi" -> (104, 105), "" -> nil.
        let hi = byte_table_literal("hi");
        assert_eq!(
            hi,
            kerf::core::LiteralValue::Pair(
                Box::new(kerf::core::LiteralValue::Int(104)),
                Box::new(kerf::core::LiteralValue::Pair(
                    Box::new(kerf::core::LiteralValue::Int(105)),
                    Box::new(kerf::core::LiteralValue::Nil),
                )),
            )
        );
        assert_eq!(byte_table_literal(""), kerf::core::LiteralValue::Nil);
    });
}

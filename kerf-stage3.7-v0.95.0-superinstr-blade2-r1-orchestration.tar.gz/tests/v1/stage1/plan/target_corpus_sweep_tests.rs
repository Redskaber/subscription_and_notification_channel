//! The step-5 two-skin corpus closeout (switch-window-plan §1
//! step 5, stage0.md §9.98): ALL 91 acceptance-corpus cases, both
//! skins.
//!
//! The step-3 three-gate contract drove the five selfhost twins;
//! step 5 extends the same discipline to the whole corpus through
//! the mechanical skin transcoder (`kerf_driver::transcode_program`
//! — the general face, no per-file special casing):
//!
//! - every `.krf` case still validates through the seed reader
//!   (the Stage 1.4 contract, re-verified here, not assumed);
//! - every MECHANICALLY TRANSCODABLE case's twin validates through
//!   the NEW reader with the SAME expectation (`validate_target`)
//!   — value cases additionally ride the three gates (α-equivalence
//!   of the expanded trees, semantic projection, behavioral
//!   equivalence of every global);
//! - the cases the transcoder cannot spell join the EXCEPTION
//!   LEDGER, each family pinned by its own test:
//!   * **parse-error cases** — the source does not read, so there
//!     is nothing to transcode; hand-crafted target twins carry
//!     the same rejection class through the target reader;
//!   * **negative literals in expression position** — `i64::MIN`
//!     in particular has no positive counterpart; arithmetic
//!     composition twins carry the same values and traps;
//!   * **the unit divergence** (neg-021) — ruling C12 maps `()` to
//!     nil on the target face BY DESIGN; the S-expr empty-
//!     application rejection has no target twin. The divergence is
//!     the spec — pinned, not hidden;
//!   * the macro-declaration family — RETIRED at r114 (the W-3.3
//!     window: `macro name { spec }` is the declaration carrier,
//!     the nine-case family now rides the mechanical transcode and
//!     the two-skin contract, pinned by its own dedicated test).
//!
//! The coverage totals land in the teardown evaluation
//! (switch-window-plan §5.6): the ledger IS the corpus-face
//! coverage number, and this sweep is its single source.

use kerf::compiler::compile_program;
use kerf::driver::{CorpusCase, transcode_program, validate, validate_target};
use kerf::expander::expand_program;
use kerf::reader::{read_program, read_target_program};
use kerf::span::FileId;
use kerf::syntax::StxDatum;
use kerf::vm::Vm;

use kerf::driver::{alpha_item_equal, semantic_projection};

const CORPUS_DIR: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/tests/v1/stage1/corpus");

const FILE: FileId = FileId(0);

/// The corpus programs walk deep on the harness side (the α walk
/// and the value walk are Rust recursion) — the sibling tests'
/// demand-allocated stack discipline.
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly");
}

// ---------- the hand-crafted twin tables (the exception ledger) ----------

/// The parse-error family's target twins — each a malformed target
/// program whose rejection class matches its `.krf` original's
/// (the reader face differs, the rejection does not).
const PARSE_ERROR_TWINS: &[(&str, &str)] = &[
    // neg-001: unclosed paren -> unclosed group.
    ("neg-001-unclosed-paren.krf", "define(result, (1 + 2);"),
    // neg-002: stray close -> stray delimiter.
    ("neg-002-stray-close.krf", ")"),
    // neg-003: unterminated string.
    ("neg-003-unterminated-string.krf", "define(result, \"abc);"),
    // neg-004: the S-expr hash-token family -> the target face has
    // no `#` tokens at all.
    ("neg-004-bad-hash-token.krf", "define(result, #x);"),
    // neg-054: the i64-overflow literal — verbatim; the target
    // lexer rejects it exactly as the S-expr lexer does.
    (
        "neg-055-float-overflow-literal.krf",
        "define(result, 1e999);",
    ),
    (
        "neg-054-i64-overflow-literal.krf",
        "define(result, 9223372036854775808);",
    ),
    // bnd-007: 257-deep nesting — generated (see the test).
];

/// The negative-literal family's arithmetic-composition twins —
/// `i64::MIN` has no positive counterpart to spell, so the twins
/// compose the value (`0 - MAX - 1`); the VALUES and the TRAPS are
/// the contract (the boundary the case exists to pin).
const NEGATIVE_LITERAL_TWINS: &[(&str, &str)] = &[
    // bnd-002: value i64::MIN.
    (
        "bnd-002-i64-min.krf",
        "define(result, 0 - 9223372036854775807 - 1);",
    ),
    // bnd-003: i64::MIN - 1 traps (runtime overflow).
    (
        "bnd-003-sub-min-overflow.krf",
        "define(result, 0 - 9223372036854775807 - 1 - 1);",
    ),
];

/// The ruling-D family: the S-expr face's SYMBOL requires are its
/// own malformed-require rejection (strings only); the target path
/// form (ruling D) maps symbol paths to string module names — a
/// well-formed program on the target face. The twins ride the path
/// form and hold the SAME expectation class (the loader's
/// cycle/missing rejections), with the reason divergence noted.
const RULING_D_TWINS: &[(&str, &str)] = &[
    // neg-018: the module cycle — the path-form twin cycles at the
    // loader, same class (expand-error).
    (
        "neg-018-module-cycle.krf",
        "module a { use b; }\nmodule b { use a; }",
    ),
    // neg-019: the missing module — the path-form twin names the
    // same ghost, the loader rejects, same class.
    ("neg-019-module-missing.krf", "use ghost;"),
];

/// The stage-divergent family: the keyword-headed malformed forms.
/// The twins are malformed target programs of the SAME intent; they
/// reject at the target READ stage while the originals reject at
/// EXPAND (the permissive-vs-grammar reader design).
const STAGE_DIVERGENT_TWINS: &[(&str, &str)] = &[
    // neg-011: (fn x x) — the closure skin needs a parameter list.
    ("neg-011-malformed-fn.krf", "define(f, ||(x x) { x });"),
    // neg-012: (let 5 6) — the binding needs a name.
    (
        "neg-012-malformed-let.krf",
        "define(result, { let 5 = 6; 6 });",
    ),
    // neg-016: (handle) — the handler skin needs its arms block.
    ("neg-016-malformed-handle.krf", "define(result, handle);"),
];

/// The shape-divergent family: the bare-expression handler arm
/// (neg-036) — the target arm skin is inherently fn-wrapped, so the
/// literal-handler class E0007 is unreachable on the target
/// grammar. The pin asserts the arm grammar's fn-wrapping (the
/// divergence IS the grammar's design).
const SHAPE_DIVERGENT_CASE: &str = "neg-036-literal-handler.krf";

/// The macro-declaration family — the r103 registered gap, CLEARED
/// at r114 (the W-3.3 window: `macro name { spec }` is the
/// declaration carrier, TD-007 resolved): the eight cases below
/// ride the mechanical transcode and the two-skin contract
/// wholesale. The ninth r103-ledger case (pos-031) is pinned as the
/// keyword-vocabulary divergence below — its DECLARATION face
/// transcloses (the window's obligation); its USE form carries the
/// `else` word face in expression position, which the target
/// grammar reserves structurally (a pre-existing boundary the
/// declaration fix unmasked).
const MACRO_DECLARATION_CASES: &[&str] = &[
    "pos-024-macro-my-if.krf",
    "pos-032-macro-two-generations.krf",
    "pos-033-hygiene-binder-collision.krf",
    "neg-050-pattern-mismatch.krf",
    "neg-051-duplicate-pattern-vars.krf",
    "neg-052-ellipsis-rejected.krf",
    "neg-053-module-macro-outside.krf",
    "bnd-010-expansion-limit.krf",
];

/// pos-031 — the keyword-vocabulary divergence (unmasked at r114):
/// the S-expr face reads `else` as a plain symbol (the macro's
/// literal), while the target EXPRESSION grammar reserves `else`
/// structurally (the keyword economy) — the use form
/// `(k-cond ... else ...)` has no target spelling. The declaration
/// face itself transcloses (pinned by the dedicated test); the
/// case-level twin rejects at the target READ stage BY DESIGN (the
/// inverse-C12 shape: the seed face accepts a name the target
/// grammar reserves).
const KEYWORD_VOCABULARY_CASE: &str = "pos-031-literal-macro.krf";

/// neg-021 — the unit divergence (ruling C12): `()` is the unit
/// and reads as nil on the target face, so the S-expr
/// empty-application rejection has no target twin. The divergence
/// is BY DESIGN; the pin asserts the ruling's behavior.
const UNIT_DIVERGENCE_CASE: &str = "neg-021-empty-application.krf";

fn hand_twin(case: &str) -> Option<&'static str> {
    for (name, twin) in PARSE_ERROR_TWINS {
        if *name == case {
            return Some(twin);
        }
    }
    for (name, twin) in NEGATIVE_LITERAL_TWINS {
        if *name == case {
            return Some(twin);
        }
    }
    None
}

/// bnd-007's twin — 257 nested ifs (the target face counts every
/// bracket; 257 nested blocks ride past the limit exactly as the
/// S-expr 257-deep list does).
fn generated_nesting_twin() -> String {
    let mut twin = String::from("define(result, ");
    for _ in 0..257 {
        twin.push_str("if (true) { ");
    }
    twin.push_str("42");
    for _ in 0..257 {
        twin.push_str(" } else { 0 }");
    }
    twin.push_str(");");
    twin
}

/// The hand-twin program for one case (the static table, or the
/// generated nesting twin).
fn hand_twin_program(name: &str) -> Option<String> {
    if let Some(twin) = hand_twin(name) {
        return Some(twin.to_string());
    }
    for (n, twin) in RULING_D_TWINS {
        if *n == name {
            return Some((*twin).to_string());
        }
    }
    if name == "bnd-007-nesting-257-fails.krf" {
        return Some(generated_nesting_twin());
    }
    None
}

/// Whether the case rides the hand-twin family (table or generated).
fn is_hand_twin_case(case: &str) -> bool {
    hand_twin_program(case).is_some()
}

// ---------- the sweep ----------

/// The per-case classification (the coverage report's rows).
#[derive(Debug, PartialEq)]
enum SweepClass {
    /// The transcoder produced a twin; both skins hold.
    Mechanical,
    /// A hand-crafted twin carried the case (parse-error family,
    /// negative-literal family, ruling-D path-form family).
    HandTwin,
    /// The unit divergence — pinned by ruling C12.
    UnitDivergence,
    /// The keyword-vocabulary divergence (pos-031, unmasked at
    /// r114): the seed face accepts a symbol (`else`) the target
    /// expression grammar reserves structurally — the use form has
    /// no target spelling BY DESIGN (the keyword economy).
    KeywordVocabulary,
    /// The stage divergence — malformed keyword-headed forms: the
    /// S-expr reader is shape-permissive (the expander rejects),
    /// the target reader is grammar-directed (the parse rejects).
    /// Both skins reject the malformed program — at their own
    /// stage boundaries (the grammar design, pinned).
    StageDivergence,
    /// The shape divergence — the S-expr bare-expression handler
    /// arm has no target twin (the target arm skin is inherently
    /// fn-wrapped), so the literal-handler class E0007 is
    /// unreachable on the target grammar.
    ShapeDivergence,
}

/// One corpus case's two-skin outcome.
struct SweepRow {
    case: String,
    class: SweepClass,
}

/// The full sweep: every `.krf` file in the corpus directory,
/// classified and verified on both skins. Returns the rows (the
/// coverage report) — the tests assert on them.
fn sweep_corpus() -> Vec<SweepRow> {
    let mut rows = Vec::new();
    let mut entries: Vec<_> = std::fs::read_dir(CORPUS_DIR)
        .expect("the corpus directory reads")
        .map(|e| {
            e.expect("the entry reads")
                .file_name()
                .to_string_lossy()
                .to_string()
        })
        .filter(|n| n.ends_with(".krf"))
        .collect();
    entries.sort();
    assert_eq!(
        entries.len(),
        91,
        "the corpus is 91 cases (85 frozen + the 6-case W-3.2 extern family)"
    );
    for name in entries {
        let source = std::fs::read_to_string(format!("{CORPUS_DIR}/{name}"))
            .unwrap_or_else(|e| panic!("case `{name}` reads: {e}"));
        let case = CorpusCase::from_source(&name, &source)
            .unwrap_or_else(|e| panic!("case `{name}`'s directive parses: {e}"));
        // Contract 1 — the seed skin still validates (re-verified,
        // never assumed).
        let seed_report = validate(&case);
        assert!(
            seed_report.matched,
            "case `{name}`: the seed-skin contract drifted: {}",
            seed_report.drift.as_deref().unwrap_or("no drift note")
        );
        // Classify.
        let class = classify(&name, &case, &source);
        match &class {
            SweepClass::Mechanical => {
                let twin = mechanical_twin(&name, &source);
                verify_two_skin_contract(&name, &case, &twin, true);
            }
            SweepClass::HandTwin => {
                // The hand twins are SEMANTIC twins (the parse-error
                // family rejects; the negative-literal family
                // composes the value arithmetically) — the
                // expectation contract is the parity face, not the
                // structural gates.
                let twin = hand_twin_program(&name)
                    .unwrap_or_else(|| panic!("case `{name}`: the hand-twin table must cover it"));
                verify_two_skin_contract(&name, &case, &twin, false);
            }
            SweepClass::UnitDivergence => {
                // The C12 pin: the twin reads as nil and halts —
                // verified by the dedicated divergence test.
                assert_eq!(name, UNIT_DIVERGENCE_CASE);
            }
            SweepClass::KeywordVocabulary => {
                // The keyword-economy pin (the dedicated divergence
                // test verifies both faces + the declaration face).
                assert_eq!(name, KEYWORD_VOCABULARY_CASE);
            }
            SweepClass::StageDivergence => {
                // The grammar-design pin: the twin rejects at the
                // target READ stage (verified by the dedicated
                // stage-divergence test).
                let twin = STAGE_DIVERGENT_TWINS
                    .iter()
                    .find(|(n, _)| *n == name)
                    .map(|(_, t)| *t)
                    .expect("the stage-divergent table covers it");
                let twin_case = CorpusCase {
                    name: &name,
                    source: twin,
                    expectation: kerf::driver::Expectation::ParseError,
                };
                let report = validate_target(&twin_case);
                assert!(
                    report.matched,
                    "case `{name}`: the stage-divergent twin must reject at the target \
                     read stage: {}",
                    report.drift.as_deref().unwrap_or("no drift note")
                );
            }
            SweepClass::ShapeDivergence => {
                // The arm-grammar pin (the dedicated test asserts the
                // fn-wrapping — E0007's unreachability).
                assert_eq!(name, SHAPE_DIVERGENT_CASE);
            }
        }
        rows.push(SweepRow { case: name, class });
    }
    rows
}

/// The mechanical twin (reads the source, transcodes, asserts the
/// transcoder's own round-trip guard held).
fn mechanical_twin(name: &str, source: &str) -> String {
    let forms = read_program(FILE, source)
        .unwrap_or_else(|e| panic!("case `{name}`: the mechanical family must read: {e}"));
    transcode_program(name, &forms)
        .unwrap_or_else(|e| panic!("case `{name}`: the mechanical family must transcode: {e}"))
}

/// Classify one case: try the mechanical path first; a ledger
/// error routes to its family (with the family pinned by
/// construction, not by error text alone).
fn classify(name: &str, case: &CorpusCase, source: &str) -> SweepClass {
    if is_hand_twin_case(name) {
        return SweepClass::HandTwin;
    }
    if name == UNIT_DIVERGENCE_CASE {
        return SweepClass::UnitDivergence;
    }
    if name == KEYWORD_VOCABULARY_CASE {
        return SweepClass::KeywordVocabulary;
    }
    if name == SHAPE_DIVERGENT_CASE {
        return SweepClass::ShapeDivergence;
    }
    if STAGE_DIVERGENT_TWINS.iter().any(|(n, _)| *n == name) {
        return SweepClass::StageDivergence;
    }
    // The parse-error cases do not read at all — they must all be
    // in the hand-twin table by now (the table IS the family).
    if matches!(case.expectation, kerf::driver::Expectation::ParseError) {
        panic!(
            "case `{name}`: a parse-error case outside the hand-twin table — the table must \
             cover the family exhaustively"
        );
    }
    let forms = match read_program(FILE, source) {
        Ok(forms) => forms,
        Err(_) => panic!(
            "case `{name}`: unreadable but not classified parse-error — the directive and \
             the reader disagree"
        ),
    };
    match transcode_program(name, &forms) {
        Ok(_) => SweepClass::Mechanical,
        Err(e) => panic!(
            "case `{name}`: an unexpected ledger entry ({}) — the sweep's families must be \
             exhaustive: {e}",
            e.ledger_key()
        ),
    }
}

/// The two-skin contract: the twin validates through the NEW reader
/// with the SAME expectation; value/warning expectations
/// additionally ride the three gates against the original.
fn verify_two_skin_contract(name: &str, case: &CorpusCase, twin: &str, structural: bool) {
    let twin_case = CorpusCase {
        name,
        source: twin,
        expectation: case.expectation.clone(),
    };
    let target_report = validate_target(&twin_case);
    assert!(
        target_report.matched,
        "case `{name}`: the target-skin twin drifted: {} (observed {:?})",
        target_report.drift.as_deref().unwrap_or("no drift note"),
        target_report.observed
    );
    // The three gates on the value/warning family (the error
    // families' parity IS the validate_target contract above).
    let rides_values = matches!(
        case.expectation,
        kerf::driver::Expectation::Value(_) | kerf::driver::Expectation::Warning { .. }
    );
    if rides_values && structural {
        let original = std::fs::read_to_string(format!("{CORPUS_DIR}/{name}"))
            .unwrap_or_else(|e| panic!("case `{name}` re-reads: {e}"));
        assert_three_gates(name, &original, twin);
    }
}

/// The three-gate contract (the step-3 discipline, the whole-corpus
/// face): α-equivalence of the expanded item trees, one semantic
/// bytecode, one value face over every global.
fn assert_three_gates(case: &str, sexpr_program: &str, target_program: &str) {
    let sexpr_forms = read_program(FILE, sexpr_program)
        .unwrap_or_else(|e| panic!("{case}: the S-expr corpus must read: {e}"));
    let target_forms = read_target_program(FILE, target_program)
        .unwrap_or_else(|e| panic!("{case}: the target corpus must read: {e}"));
    let sexpr_items = expand_program(&sexpr_forms)
        .unwrap_or_else(|e| panic!("{case}: the S-expr corpus must expand: {e}"));
    let target_items = expand_program(&target_forms)
        .unwrap_or_else(|e| panic!("{case}: the target corpus must expand: {e}"));
    assert_eq!(
        sexpr_items.len(),
        target_items.len(),
        "{case}: the item counts must agree"
    );
    for (i, (x, y)) in sexpr_items.iter().zip(&target_items).enumerate() {
        assert!(
            alpha_item_equal(x, y),
            "{case}: item {i} (`{}`) must be alpha-equivalent",
            x.kind_name()
        );
    }
    let bc_sexpr = compile_program(&sexpr_items)
        .unwrap_or_else(|e| panic!("{case}: the S-expr corpus must compile: {e}"));
    let bc_target = compile_program(&target_items)
        .unwrap_or_else(|e| panic!("{case}: the target corpus must compile: {e}"));
    assert_eq!(
        semantic_projection(&bc_target),
        semantic_projection(&bc_sexpr),
        "{case}: the two skins must produce one semantic bytecode"
    );
    let mut vm_a =
        Vm::new(bc_sexpr).unwrap_or_else(|e| panic!("{case}: the S-expr product loads: {e}"));
    vm_a.run()
        .unwrap_or_else(|e| panic!("{case}: the S-expr corpus runs: {e}"));
    let mut vm_b =
        Vm::new(bc_target).unwrap_or_else(|e| panic!("{case}: the target product loads: {e}"));
    vm_b.run()
        .unwrap_or_else(|e| panic!("{case}: the target corpus runs: {e}"));
    for name in vm_a.global_names() {
        // A global slot the seed run never assigned (an effect
        // handler name rides the table; the operator globals hold
        // builtins) has no value face to compare — the semantic
        // gate already pinned the tables themselves.
        let Some(a) = vm_a.global_sym(name) else {
            continue;
        };
        let b = vm_b
            .global_sym(name)
            .unwrap_or_else(|| panic!("{case}: the global `{name}` must exist on both faces"));
        assert_eq!(a, b, "{case}: the global `{name}` must hold one value");
    }
}

// ---------- the tests ----------

#[test]
fn all_91_corpus_cases_hold_on_both_skins() {
    deep_stack(|| {
        let rows = sweep_corpus();
        let mechanical = rows
            .iter()
            .filter(|r| r.class == SweepClass::Mechanical)
            .count();
        let hand = rows
            .iter()
            .filter(|r| r.class == SweepClass::HandTwin)
            .count();
        let divergence = rows
            .iter()
            .filter(|r| r.class == SweepClass::UnitDivergence)
            .count();
        let keyword_div = rows
            .iter()
            .filter(|r| r.class == SweepClass::KeywordVocabulary)
            .count();
        assert_eq!(rows.len(), 91, "the sweep covered every case");
        let stage_div = rows
            .iter()
            .filter(|r| r.class == SweepClass::StageDivergence)
            .count();
        let shape_div = rows
            .iter()
            .filter(|r| r.class == SweepClass::ShapeDivergence)
            .count();
        // The pinned coverage (the teardown evaluation's corpus-face
        // number, single source): 91 = mechanical + hand-twin + the
        // four pinned families (85 frozen + the W-3.2 extern six);
        // the r114 W-3.3 window moved eight of the nine macro cases
        // into the mechanical fold — the ninth (pos-031) pinned as
        // the keyword-vocabulary divergence its declaration fix
        // unmasked.
        assert_eq!(divergence, 1, "exactly one unit divergence (ruling C12)");
        assert_eq!(
            keyword_div, 1,
            "exactly one keyword-vocabulary divergence (the `else` use form)"
        );
        assert_eq!(
            stage_div,
            STAGE_DIVERGENT_TWINS.len(),
            "the keyword-malformed family"
        );
        assert_eq!(
            shape_div, 1,
            "exactly one shape divergence (the bare-handler arm)"
        );
        assert_eq!(
            mechanical + hand,
            91 - 2 - STAGE_DIVERGENT_TWINS.len() - 1,
            "the mechanical + hand-twin families cover the rest (the two \
             pinned divergences + the stage + shape families aside)"
        );
        assert!(
            hand >= 9,
            "the parse-error family (7) + negative literals (2) + ruling-D (2)"
        );
        // The classification anchors (the coverage report's named
        // rows — the sweep's per-family spot checks).
        let by_name = |n: &str| {
            rows.iter()
                .find(|r| r.case == n)
                .unwrap_or_else(|| panic!("case `{n}` must be in the sweep"))
        };
        assert_eq!(
            by_name("pos-009-recursion-fib.krf").class,
            SweepClass::Mechanical
        );
        assert_eq!(
            by_name("bnd-007-nesting-257-fails.krf").class,
            SweepClass::HandTwin
        );
        assert_eq!(
            by_name("neg-021-empty-application.krf").class,
            SweepClass::UnitDivergence
        );
        // The W-3.3 anchor: the macro family rides the mechanical
        // fold (the r103 registered gap cleared at r114).
        assert_eq!(
            by_name("pos-024-macro-my-if.krf").class,
            SweepClass::Mechanical
        );
        assert_eq!(
            by_name(KEYWORD_VOCABULARY_CASE).class,
            SweepClass::KeywordVocabulary
        );
    });
}

#[test]
fn the_parse_error_hand_twins_reject_through_the_target_reader() {
    deep_stack(|| {
        for (name, twin) in PARSE_ERROR_TWINS {
            let source = std::fs::read_to_string(format!("{CORPUS_DIR}/{name}"))
                .unwrap_or_else(|e| panic!("case `{name}` reads: {e}"));
            let case = CorpusCase::from_source(name, &source).expect("the directive parses");
            assert!(
                matches!(case.expectation, kerf::driver::Expectation::ParseError),
                "case `{name}`: the hand-twin table's parse-error rows must be parse-error cases"
            );
            let twin_case = CorpusCase {
                name,
                source: twin,
                expectation: case.expectation.clone(),
            };
            let report = validate_target(&twin_case);
            assert!(
                report.matched,
                "case `{name}`: the target twin must reject with the same class: {}",
                report.drift.as_deref().unwrap_or("no drift note")
            );
        }
        // bnd-007 — the generated 257-deep nesting twin.
        let twin = generated_nesting_twin();
        let case = CorpusCase {
            name: "bnd-007-nesting-257-fails.ktf",
            source: &twin,
            expectation: kerf::driver::Expectation::ParseError,
        };
        let report = validate_target(&case);
        assert!(
            report.matched,
            "bnd-007: the 257-deep target twin must reject: {}",
            report.drift.as_deref().unwrap_or("no drift note")
        );
    });
}

#[test]
fn the_negative_literal_twins_carry_the_boundary_values() {
    deep_stack(|| {
        for (name, twin) in NEGATIVE_LITERAL_TWINS {
            let source = std::fs::read_to_string(format!("{CORPUS_DIR}/{name}"))
                .unwrap_or_else(|e| panic!("case `{name}` reads: {e}"));
            let case = CorpusCase::from_source(name, &source).expect("the directive parses");
            // The mechanical transcoder MUST refuse these (the
            // ledger discipline — the family is real, not assumed).
            let forms = read_program(FILE, &source).expect("the source reads");
            let err = transcode_program(name, &forms)
                .expect_err("the i64::MIN family must join the ledger");
            assert_eq!(err.ledger_key(), "negative-literal");
            // The arithmetic-composition twin holds the same
            // expectation through the target reader.
            let twin_case = CorpusCase {
                name,
                source: twin,
                expectation: case.expectation.clone(),
            };
            let report = validate_target(&twin_case);
            assert!(
                report.matched,
                "case `{name}`: the arithmetic twin must hold the boundary: {}",
                report.drift.as_deref().unwrap_or("no drift note")
            );
        }
    });
}

#[test]
fn the_unit_divergence_is_ruling_c12_pinned() {
    deep_stack(|| {
        // neg-021: the S-expr face rejects the empty application;
        // the target face reads `()` as nil (ruling C12) — the
        // program HALTS with result nil. The divergence is the
        // skin dictionary's design, verified here as behavior.
        let twin = "define(result, ());";
        let forms = read_target_program(FILE, twin)
            .expect("the unit reads as nil on the target face (ruling C12)");
        let items = expand_program(&forms).expect("the unit program expands");
        let bc = compile_program(&items).expect("the unit program compiles");
        let mut vm = Vm::new(bc).expect("the unit program loads");
        vm.run().expect("the unit program halts (the C12 mapping)");
        let value = vm.global("result").expect("the result global binds");
        assert_eq!(
            value,
            &kerf::vm::Value::Nil,
            "ruling C12: `()` is the unit skin of nil"
        );
        // And the S-expr original still rejects (the contract the
        // corpus pins).
        let source = std::fs::read_to_string(format!("{CORPUS_DIR}/{UNIT_DIVERGENCE_CASE}"))
            .expect("the case reads");
        let case = CorpusCase::from_source(UNIT_DIVERGENCE_CASE, &source).expect("parses");
        let report = validate(&case);
        assert!(
            report.matched,
            "the seed face still rejects the empty application"
        );
    });
}

#[test]
fn the_macro_declaration_family_rides_the_mechanical_fold() {
    deep_stack(|| {
        // The r103 registered gap, CLEARED at r114 (the W-3.3
        // window — TD-007 resolved): every macro-declaration case
        // now transcodes mechanically (the `macro name { spec }`
        // declaration carrier) and its twin holds the two-skin
        // contract — the value cases through the three gates
        // (α-equivalence + one semantic bytecode + one value face),
        // the error cases through the shared expander's identical
        // rejection class (the match-tree invariance is by
        // construction: the mapped tree is the S-expr face's).
        for name in MACRO_DECLARATION_CASES {
            let source = std::fs::read_to_string(format!("{CORPUS_DIR}/{name}"))
                .unwrap_or_else(|e| panic!("case `{name}` reads: {e}"));
            let case = CorpusCase::from_source(name, &source)
                .unwrap_or_else(|e| panic!("case `{name}`'s directive parses: {e}"));
            let twin = mechanical_twin(name, &source);
            // The emitted declaration carrier is on the twin's face
            // (the family's form anchor — one spot check per shape:
            // the declaration, and the module-nested declaration).
            if *name == "pos-024-macro-my-if.krf" {
                assert!(
                    twin.starts_with("macro my_if { (syntax_rules, nil,"),
                    "case `{name}`: the declaration carrier anchor: {twin}"
                );
            }
            if *name == "neg-053-module-macro-outside.krf" {
                assert!(
                    twin.contains("module m {\n    macro inner_m {"),
                    "case `{name}`: the nested declaration anchor: {twin}"
                );
            }
            verify_two_skin_contract(name, &case, &twin, true);
        }
    });
}

#[test]
fn the_keyword_vocabulary_divergence_is_pinned() {
    deep_stack(|| {
        // pos-031 (unmasked at r114): the S-expr face reads `else`
        // as a plain symbol (the macro literal); the target
        // EXPRESSION grammar reserves `else` structurally — the use
        // form `(k-cond ... else ...)` has no target spelling. The
        // divergence is the keyword economy's design, pinned here
        // as behavior (the inverse-C12 shape: the seed face accepts
        // a name the target grammar reserves).
        let source = std::fs::read_to_string(format!("{CORPUS_DIR}/{KEYWORD_VOCABULARY_CASE}"))
            .unwrap_or_else(|e| panic!("the case reads: {e}"));
        // 1. The seed face still holds the value (re-verified, never
        //    assumed).
        let case = CorpusCase::from_source(KEYWORD_VOCABULARY_CASE, &source)
            .expect("the directive parses");
        let report = validate(&case);
        assert!(
            report.matched,
            "the seed face holds the literal-macro value: {}",
            report.drift.as_deref().unwrap_or("no drift note")
        );
        // 2. The DECLARATION face transcloses (the window's
        //    obligation — the use form's boundary is not the
        //    declaration's): the define-syntax form alone rides the
        //    carrier and reads back to the identical tree.
        let forms = read_program(FILE, &source).expect("the source reads");
        let decl = forms
            .iter()
            .find(|f| {
                matches!(&f.datum, StxDatum::List(items)
                    if items.first().map(|h| h.datum.to_string()) == Some("define-syntax".into()))
            })
            .expect("the declaration form is present");
        let decl_twin = transcode_program(KEYWORD_VOCABULARY_CASE, std::slice::from_ref(decl))
            .unwrap_or_else(|e| panic!("the declaration face must transcode: {e}"));
        assert!(
            decl_twin.starts_with("macro k_cond { (syntax_rules, (then, else),"),
            "the declaration carrier (the literals ride the datum face): {decl_twin}"
        );
        let read_back = read_target_program(FILE, &decl_twin)
            .unwrap_or_else(|e| panic!("the declaration twin reads: {e}"));
        assert_eq!(
            read_back[0].datum.to_string(),
            decl.datum.to_string(),
            "the declaration twin is the identical tree (the match-tree invariance)"
        );
        // 3. The case-level twin rejects at the target READ stage —
        //    the `else` word face in expression position (the
        //    keyword economy; the divergence IS the grammar's
        //    design).
        let err = transcode_program(KEYWORD_VOCABULARY_CASE, &forms)
            .expect_err("the full case must stay unspellable (the `else` use form)");
        assert_eq!(
            err.ledger_key(),
            "unspellable",
            "the case-level ledger reason"
        );
        assert!(
            err.to_string().contains("else"),
            "the rejection names the reserved word: {err}"
        );
    });
}

#[test]
fn a_positive_anchor_rides_the_three_gates_in_isolation() {
    deep_stack(|| {
        // pos-009 (recursion-fib) in isolation — the sweep's
        // per-class anchor (the failure names this case alone).
        let original =
            std::fs::read_to_string(format!("{CORPUS_DIR}/pos-009-recursion-fib.krf")).unwrap();
        let twin = mechanical_twin("pos-009-recursion-fib.krf", &original);
        assert!(
            twin.contains(
                "fn fib(n) { if ((n < 2)) { n } else { (fib((n - 1)) + fib((n - 2))) } }"
            ),
            "the fib twin: {twin}"
        );
        let case = CorpusCase::from_source("pos-009-recursion-fib.krf", &original).unwrap();
        verify_two_skin_contract("pos-009-recursion-fib.krf", &case, &twin, true);
    });
}

#[test]
fn an_error_anchor_holds_the_rejection_class_in_isolation() {
    deep_stack(|| {
        // neg-013 (unbound reference) — the expand-stage anchor.
        let original =
            std::fs::read_to_string(format!("{CORPUS_DIR}/neg-013-unbound-reference.krf")).unwrap();
        let twin = mechanical_twin("neg-013-unbound-reference.krf", &original);
        assert!(
            twin.contains("define(result, y);"),
            "the unbound twin: {twin}"
        );
        let case = CorpusCase::from_source("neg-013-unbound-reference.krf", &original).unwrap();
        verify_two_skin_contract("neg-013-unbound-reference.krf", &case, &twin, true);
    });
}

#[test]
fn the_stage_divergent_twins_reject_at_the_target_read_stage() {
    deep_stack(|| {
        for (name, twin) in STAGE_DIVERGENT_TWINS {
            // The twin rejects at the target READ stage...
            let twin_case = CorpusCase {
                name,
                source: twin,
                expectation: kerf::driver::Expectation::ParseError,
            };
            let report = validate_target(&twin_case);
            assert!(
                report.matched,
                "case `{name}`: the twin must reject at the target read stage: {}",
                report.drift.as_deref().unwrap_or("no drift note")
            );
            // ...while the original holds its expand-error on the
            // seed face (the permissive reader defers to the
            // expander — both skins reject, at their own stage
            // boundaries).
            let source =
                std::fs::read_to_string(format!("{CORPUS_DIR}/{name}")).expect("the case reads");
            let case = CorpusCase::from_source(name, &source).expect("the directive parses");
            let seed_report = validate(&case);
            assert!(
                seed_report.matched,
                "case `{name}`: the seed face still holds its expand-stage rejection"
            );
        }
    });
}

#[test]
fn the_shape_divergent_arm_grammar_pins_the_fn_wrapping() {
    deep_stack(|| {
        // neg-036's S-expr arm is (e 7) — a BARE literal handler,
        // which the checker rejects as E0007. The target arm skin
        // wraps every handler body in the fn form (`e => { 7 }` is
        // (e (fn () 7)) — a VALID zero-arg handler), so E0007's
        // literal-handler face is unreachable on the target
        // grammar. The pin: the fn-wrapped spelling is well-formed
        // end to end (the grammar subsumes the check).
        let twin = "define(result, handle (perform e(1)) { e(x) => { 7 }, });";
        let forms =
            read_target_program(FILE, twin).expect("the fn-wrapped arm reads on the target face");
        let items = expand_program(&forms).expect("the fn-wrapped arm expands");
        let bc = compile_program(&items).expect("the fn-wrapped arm compiles");
        let mut vm = Vm::new(bc).expect("the fn-wrapped arm loads");
        vm.run()
            .expect("the fn-wrapped arm runs (E0007 unreachable by grammar)");
        // And the S-expr original still holds its E0007.
        let source = std::fs::read_to_string(format!("{CORPUS_DIR}/{SHAPE_DIVERGENT_CASE}"))
            .expect("the case reads");
        let case = CorpusCase::from_source(SHAPE_DIVERGENT_CASE, &source).expect("parses");
        let report = validate(&case);
        assert!(
            report.matched,
            "the seed face still holds the literal-handler E0007"
        );
    });
}

// The step-5 dual-caliber gate (gate_b_fixpoint_dual_caliber — the
// r103 finding: phase 2's funcs face + the phase-2 coordinate
// exemption + phase 3's full digest) retired with the r104 E5
// batch-3 teardown: the `.krf` compiler original left the tree and
// the cross-skin caliber lost its seed side. The finding's record
// rides the audit's historical AF sections; the target face's own
// fixpoint phases (the oracle comparisons inside
// `fixpoint_selfhost_compiler_target`) are in-tree and live.

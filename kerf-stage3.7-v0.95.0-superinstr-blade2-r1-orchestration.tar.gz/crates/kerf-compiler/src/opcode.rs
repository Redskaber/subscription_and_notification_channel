//! Opcode: the bytecode operation set (sub-stage 0.5).
//!
//! Twenty-five operations in the docs/stage0.md §8.12 grouping plus
//! the effect extension and the Stage 2.1 capture access: stack
//! (push-const / pop / dup / swap), function (call / ret / closure),
//! control flow (jump / jump-if-false), data construction (make-pair
//! / car / cdr), variable access (load-local / store-local /
//! load-global / store-global / load-captured — the Stage 2.1 LA-3
//! separated-opcode ruling, K192 `OP_GETUPVAL` discipline: a closure
//! body reads a captured value by the proto's capture-table index;
//! the store twin stays unlanded with the immutable-capture subset
//! boundary, LA-7), arithmetic (add / sub / mul / div), effects
//! (push-handler / pop-handler / perform — the frozen Perform/Handle
//! primitives of TD-005 need direct carriers, a documented extension
//! beyond the §8.12 group list), and termination (halt). The fused
//! call (W-VM-SUPERINSTR `call-global` — the load-global + call pair
//! the dispatch portrait ranked THE universal first pair at 24-29%
//! of every measured load; a static single-phase fusion per K150,
//! w-vm-superinstr-window.md SI-1..SI-4) extends the set. Well
//! within the "about 35 opcodes" capability model.
//!
//! Operand semantics are fully declared per opcode ([`Opcode::operand_help`]):
//! every instruction is `Instr { op, a, b }` with two u32 operand slots
//! (an unused slot is always 0) — "operands fully resolved" acceptance
//! of the stage plan. Stack effects are single-sourced through
//! [`Opcode::pops`]/[`Opcode::pushes`] — the same table drives the
//! compile-time bookkeeping and `Bytecode::verify`.

use std::fmt;

/// One bytecode operation (see the module doc for the grouping).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Opcode {
    // stack
    PushConst,
    Pop,
    Dup,
    Swap,
    // function
    Call,
    Ret,
    Closure,
    // control flow
    Jump,
    JumpIfFalse,
    // data construction
    MakePair,
    Car,
    Cdr,
    // variable access
    LoadLocal,
    StoreLocal,
    LoadGlobal,
    StoreGlobal,
    // capture access (Stage 2.1 LA-3 — the separated-opcode ruling)
    LoadCaptured,
    // arithmetic
    Add,
    Sub,
    Mul,
    Div,
    // effects (§8.12 group extension — TD-005 primitive carriers)
    PushHandler,
    PopHandler,
    Perform,
    // termination
    Halt,
    // fused call (W-VM-SUPERINSTR — the load-global + call pair)
    CallGlobal,
}

impl Opcode {
    /// All operations, in declaration order (tests pin the count).
    pub const ALL: [Opcode; 26] = [
        Opcode::PushConst,
        Opcode::Pop,
        Opcode::Dup,
        Opcode::Swap,
        Opcode::Call,
        Opcode::Ret,
        Opcode::Closure,
        Opcode::Jump,
        Opcode::JumpIfFalse,
        Opcode::MakePair,
        Opcode::Car,
        Opcode::Cdr,
        Opcode::LoadLocal,
        Opcode::StoreLocal,
        Opcode::LoadGlobal,
        Opcode::StoreGlobal,
        Opcode::LoadCaptured,
        Opcode::Add,
        Opcode::Sub,
        Opcode::Mul,
        Opcode::Div,
        Opcode::PushHandler,
        Opcode::PopHandler,
        Opcode::Perform,
        Opcode::Halt,
        Opcode::CallGlobal,
    ];

    /// Stable diagnostic name (lowercase kebab form).
    pub fn kind_name(&self) -> &'static str {
        match self {
            Opcode::PushConst => "push-const",
            Opcode::Pop => "pop",
            Opcode::Dup => "dup",
            Opcode::Swap => "swap",
            Opcode::Call => "call",
            Opcode::Ret => "ret",
            Opcode::Closure => "closure",
            Opcode::Jump => "jump",
            Opcode::JumpIfFalse => "jump-if-false",
            Opcode::MakePair => "make-pair",
            Opcode::Car => "car",
            Opcode::Cdr => "cdr",
            Opcode::LoadLocal => "load-local",
            Opcode::StoreLocal => "store-local",
            Opcode::LoadGlobal => "load-global",
            Opcode::StoreGlobal => "store-global",
            Opcode::LoadCaptured => "load-captured",
            Opcode::Add => "add",
            Opcode::Sub => "sub",
            Opcode::Mul => "mul",
            Opcode::Div => "div",
            Opcode::PushHandler => "push-handler",
            Opcode::PopHandler => "pop-handler",
            Opcode::Perform => "perform",
            Opcode::Halt => "halt",
            Opcode::CallGlobal => "call-global",
        }
    }

    /// Reverse lookup of the stable kebab name (the 2.5 rebuild face,
    /// stage-2-plan §2 row 2.5 MUV ①: the `.krf` compiler's
    /// instruction records carry the kebab names, and the rebuild
    /// reverses them through this table — `kind_name` and
    /// `from_kind_name` are the single-source pair, pinned by the
    /// round-trip guard in the driver tests).
    pub fn from_kind_name(name: &str) -> Option<Opcode> {
        Opcode::ALL.into_iter().find(|op| op.kind_name() == name)
    }

    /// Declaration-order index into [`Opcode::ALL`] (the W-3.7
    /// census face: the dispatch observer keys its per-opcode
    /// counters by this ordinal — `ALL[ordinal()] == *self`, pinned
    /// by the round-trip guard). A stable compact key for the
    /// dynamic-opcode histogram and the adjacent-pair table the
    /// superinstruction adjudication consumes (w3.7-jit-window.md
    /// §2b); NOT a wire format (the bytecode stream stores the enum,
    /// never the ordinal).
    pub fn ordinal(&self) -> usize {
        match self {
            Opcode::PushConst => 0,
            Opcode::Pop => 1,
            Opcode::Dup => 2,
            Opcode::Swap => 3,
            Opcode::Call => 4,
            Opcode::Ret => 5,
            Opcode::Closure => 6,
            Opcode::Jump => 7,
            Opcode::JumpIfFalse => 8,
            Opcode::MakePair => 9,
            Opcode::Car => 10,
            Opcode::Cdr => 11,
            Opcode::LoadLocal => 12,
            Opcode::StoreLocal => 13,
            Opcode::LoadGlobal => 14,
            Opcode::StoreGlobal => 15,
            Opcode::LoadCaptured => 16,
            Opcode::Add => 17,
            Opcode::Sub => 18,
            Opcode::Mul => 19,
            Opcode::Div => 20,
            Opcode::PushHandler => 21,
            Opcode::PopHandler => 22,
            Opcode::Perform => 23,
            Opcode::Halt => 24,
            Opcode::CallGlobal => 25,
        }
    }

    /// Whether the opcode ends a basic block (control flow leaves the
    /// fallthrough path after it).
    pub fn is_terminator(&self) -> bool {
        matches!(self, Opcode::Jump | Opcode::Ret | Opcode::Halt)
    }

    /// Declared meaning of the `a`/`b` operand slots (the single source
    /// of "operands fully resolved").
    pub fn operand_help(&self) -> &'static str {
        match self {
            Opcode::PushConst => "a: constant-pool index",
            Opcode::Pop | Opcode::Dup | Opcode::Swap => "none",
            Opcode::Call => "a: argument count",
            Opcode::Ret => "none",
            Opcode::Closure => "a: proto index",
            Opcode::Jump => "a: target pc",
            Opcode::JumpIfFalse => "a: target pc",
            Opcode::MakePair | Opcode::Car | Opcode::Cdr => "none",
            Opcode::LoadLocal | Opcode::StoreLocal => "a: local slot",
            Opcode::LoadGlobal | Opcode::StoreGlobal => "a: global index",
            Opcode::LoadCaptured => "a: capture index",
            Opcode::Add | Opcode::Sub | Opcode::Mul | Opcode::Div => "none",
            Opcode::PushHandler => "a: effect-name global index",
            Opcode::PopHandler => "a: handler count",
            Opcode::Perform => "a: effect-name global index, b: argument count",
            Opcode::Halt => "none",
            Opcode::CallGlobal => "a: global index, b: argument count",
        }
    }

    /// Operands the instruction pops off the data stack *before*
    /// pushing (the underflow check input; e.g. `call` pops the arity
    /// arguments plus the callee).
    pub fn pops(self, a: u32, b: u32) -> u32 {
        match self {
            Opcode::PushConst
            | Opcode::Closure
            | Opcode::LoadLocal
            | Opcode::LoadGlobal
            | Opcode::LoadCaptured => 0,
            Opcode::Call => a.saturating_add(1),
            Opcode::Perform => b,
            Opcode::Pop
            | Opcode::Dup
            | Opcode::StoreLocal
            | Opcode::StoreGlobal
            | Opcode::JumpIfFalse
            | Opcode::PushHandler
            | Opcode::Ret => 1,
            Opcode::Swap
            | Opcode::MakePair
            | Opcode::Add
            | Opcode::Sub
            | Opcode::Mul
            | Opcode::Div => 2,
            Opcode::Car | Opcode::Cdr => 1,
            Opcode::Jump | Opcode::PopHandler | Opcode::Halt => 0,
            // The fused call reads its callee straight from the
            // global slot — the stack holds only the argc arguments
            // (SI-3: the pair it fuses had the callee round-trip
            // through push/pop; the fused form never does).
            Opcode::CallGlobal => b,
        }
    }

    /// Operands the instruction pushes onto the data stack.
    pub fn pushes(self) -> u32 {
        match self {
            // dup re-pushes the top: pops 1, pushes 2 (net +1)
            Opcode::Dup => 2,
            Opcode::PushConst
            | Opcode::Closure
            | Opcode::LoadLocal
            | Opcode::LoadGlobal
            | Opcode::LoadCaptured
            | Opcode::Call
            | Opcode::Perform => 1,
            Opcode::Pop
            | Opcode::StoreLocal
            | Opcode::StoreGlobal
            | Opcode::JumpIfFalse
            | Opcode::PushHandler
            | Opcode::Ret
            | Opcode::Jump
            | Opcode::PopHandler
            | Opcode::Halt => 0,
            Opcode::MakePair | Opcode::Add | Opcode::Sub | Opcode::Mul | Opcode::Div => 1,
            // swap exchanges the top two: pops 2, pushes 2 (net 0)
            Opcode::Swap => 2,
            Opcode::Car | Opcode::Cdr => 1,
            Opcode::CallGlobal => 1,
        }
    }

    /// Net data-stack delta (pushes minus pops) for the instruction.
    #[cfg(test)] // r106 FIX-15: analysis face — consumed only by the
    // opcode table tests below (the verify stack walk computes its
    // own pops/pushes through Opcode::pops/pushes)
    pub fn stack_delta(self, a: u32, b: u32) -> i32 {
        self.pushes() as i32 - self.pops(a, b) as i32
    }
}

impl fmt::Display for Opcode {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.kind_name())
    }
}

#[cfg(test)]
mod tests {
    //! Opcode table tests (FP1/FP2): display names, terminator set,
    //! operand declarations, and the pops/pushes/delta single source.

    use super::*;

    #[test]
    fn all_ops_have_unique_kebab_names() {
        assert_eq!(Opcode::ALL.len(), 26, "opcode count is pinned at 26");
        let mut names: Vec<&str> = Opcode::ALL.iter().map(|op| op.kind_name()).collect();
        names.sort_unstable();
        let len = names.len();
        names.dedup();
        assert_eq!(names.len(), len, "kind names must be unique");
        for name in &names {
            assert!(name.chars().next().is_some_and(char::is_lowercase));
            assert!(!name.ends_with('.'));
        }
        assert_eq!(Opcode::Call.to_string(), "call");
        assert_eq!(Opcode::JumpIfFalse.to_string(), "jump-if-false");
        assert_eq!(Opcode::PushHandler.to_string(), "push-handler");
        assert_eq!(Opcode::LoadCaptured.to_string(), "load-captured");
        assert_eq!(Opcode::CallGlobal.to_string(), "call-global");
        // The fused call's stack contract (SI-3): only the args ride
        // the stack — pops argc, pushes the one result. The pair it
        // fuses had the callee round-trip (push then pop) on top, so
        // the net delta matches the unfused sequence exactly.
        assert_eq!(Opcode::CallGlobal.pops(0, 3), 3);
        assert_eq!(Opcode::CallGlobal.pushes(), 1);
        let pair_delta = Opcode::LoadGlobal.stack_delta(0, 0) + Opcode::Call.stack_delta(3, 0);
        assert_eq!(
            Opcode::CallGlobal.stack_delta(0, 3),
            pair_delta,
            "same net delta as the fused pair"
        );
        // Round-trip through the kebab-name table (the .krf rebuild
        // face) — the single-source pair discipline, every opcode.
        for op in Opcode::ALL {
            assert_eq!(Opcode::from_kind_name(op.kind_name()), Some(op));
        }
    }

    #[test]
    fn stack_effect_table_matches_contract() {
        // (op, a, b) -> (pops, pushes, delta) — §8.12 semantics plus the
        // effect extension; the eval-order contract (§19.5) puts the
        // callee on top, so `call a` pops a + 1.
        let cases: [(Opcode, u32, u32, u32, u32); 13] = [
            (Opcode::PushConst, 0, 0, 0, 1),
            (Opcode::Pop, 0, 0, 1, 0),
            (Opcode::Dup, 0, 0, 1, 2),
            (Opcode::Swap, 0, 0, 2, 2),
            (Opcode::Call, 2, 0, 3, 1),
            (Opcode::Ret, 0, 0, 1, 0),
            (Opcode::Closure, 1, 0, 0, 1),
            (Opcode::JumpIfFalse, 5, 0, 1, 0),
            (Opcode::MakePair, 0, 0, 2, 1),
            (Opcode::LoadGlobal, 0, 0, 0, 1),
            (Opcode::LoadCaptured, 2, 0, 0, 1),
            (Opcode::PushHandler, 3, 0, 1, 0),
            (Opcode::Perform, 3, 2, 2, 1),
        ];
        for (op, a, b, pops, pushes) in cases {
            assert_eq!(op.pops(a, b), pops, "pops for {op} a={a} b={b}");
            assert_eq!(op.pushes(), pushes, "pushes for {op}");
        }
        // delta spot checks: call arity 2 -> -2; perform argc 2 -> -1;
        // plain value producers -> +1.
        assert_eq!(Opcode::Call.stack_delta(2, 0), -2);
        assert_eq!(Opcode::Perform.stack_delta(3, 2), -1);
        assert_eq!(Opcode::Call.stack_delta(0, 0), 0);
        assert_eq!(Opcode::LoadLocal.stack_delta(0, 0), 1);
        // the capture read mirrors the local read: net +1, and its
        // operand never touches the data stack.
        assert_eq!(Opcode::LoadCaptured.stack_delta(2, 0), 1);
        // terminators: only jump / ret / halt.
        for op in Opcode::ALL {
            assert_eq!(
                op.is_terminator(),
                matches!(op, Opcode::Jump | Opcode::Ret | Opcode::Halt),
                "terminator set for {op}"
            );
        }
        // operand_help is declared for every op (no "unknown").
        for op in Opcode::ALL {
            assert!(!op.operand_help().is_empty());
        }
    }
}

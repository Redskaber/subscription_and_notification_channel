//! The dependency-graph resolver (PKG-3).
//!
//! Package identity is the **name**: the first resolution of a name wins
//! and later edges onto the same name are checked against it (one version
//! per name in the graph — multiple coexisting major versions arrive with
//! the multi-source window). The walk is a three-color DFS on names with
//! the gray stack naming any cycle (`expander/module.rs` `LoadPlan`
//! precedent — same shape, independent module). Post-order emission puts
//! every dependency before its dependents (the `LoadPlan` order
//! semantics). Every `(dependent, constraint)` edge is verified after
//! the walk so a diamond conflict lists every constraint at once.

use crate::error::PkgError;
use crate::lockfile::{LockEntry, Lockfile};
use crate::manifest::Manifest;
use crate::semver::{Constraint, Version};
use crate::{LIBS_DIR, MANIFEST_FILE};
use std::collections::BTreeMap;
use std::path::{Path, PathBuf};

/// Maximum dependency-chain depth (the LIM ladder discipline: a graph
/// walk must fail with an error, never a stack overflow).
pub const RESOLUTION_DEPTH_LIMIT: u32 = 512;

/// One resolved package.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ResolvedPkg {
    /// The package name.
    pub name: String,
    /// The exact resolved version.
    pub version: Version,
    /// The package directory (as reached from the root).
    pub dir: PathBuf,
    /// The lockfile source field: the path relative to the root package.
    pub source: String,
}

/// The full resolution product.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Resolution {
    /// Topological order, dependencies before dependents (root last).
    pub order: Vec<ResolvedPkg>,
    /// The deterministic lockfile for this graph.
    pub lockfile: Lockfile,
}

/// The DFS node color (three-color cycle detection). "White" is the
/// map-absence default: a name absent from `colors` has never been
/// visited, so only the two active colors are materialized.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Color {
    Gray,
    Black,
}

/// Resolver state.
struct Ctx {
    /// The root package directory (lockfile `source` fields are
    /// relative to it).
    root: PathBuf,
    resolved: BTreeMap<String, ResolvedPkg>,
    colors: BTreeMap<String, Color>,
    stack: Vec<String>,
    edges: BTreeMap<String, Vec<(String, Constraint)>>,
    order: Vec<ResolvedPkg>,
}

/// Resolve the package graph rooted at `root_dir`.
///
/// Reads `<root_dir>/kerf.toml`, walks `<dir>/libs/<name>/` recursively,
/// rejects cycles and constraint violations, and returns the topological
/// order plus the deterministic lockfile.
pub fn resolve(root_dir: &Path) -> Result<Resolution, PkgError> {
    let root_manifest = read_manifest(root_dir)?;
    let mut ctx = Ctx {
        root: root_dir.to_path_buf(),
        resolved: BTreeMap::new(),
        colors: BTreeMap::new(),
        stack: Vec::new(),
        edges: BTreeMap::new(),
        order: Vec::new(),
    };
    visit(root_dir, root_manifest, 0, &mut ctx)?;

    // Verify every recorded edge against the single resolved version so
    // a diamond conflict reports all constraints at once (PKG-3).
    for (dep_name, imposed) in &ctx.edges {
        let pkg = &ctx.resolved[dep_name];
        for (_dependent, constraint) in imposed {
            if !constraint.caret_satisfies(pkg.version) {
                let constraints = imposed
                    .iter()
                    .map(|(d, c)| (d.clone(), c.to_string()))
                    .collect();
                return Err(PkgError::VersionConflict {
                    name: dep_name.clone(),
                    version: pkg.version.to_string(),
                    constraints,
                });
            }
        }
    }

    let packages = ctx
        .order
        .iter()
        .map(|p| LockEntry {
            name: p.name.clone(),
            version: p.version,
            source: p.source.clone(),
        })
        .collect();
    Ok(Resolution {
        order: ctx.order,
        lockfile: Lockfile::new(packages),
    })
}

/// Read and parse the manifest under `dir`.
fn read_manifest(dir: &Path) -> Result<Manifest, PkgError> {
    let path = dir.join(MANIFEST_FILE);
    let text = std::fs::read_to_string(&path).map_err(|e| {
        if e.kind() == std::io::ErrorKind::NotFound {
            PkgError::ManifestNotFound { path: path.clone() }
        } else {
            PkgError::Io {
                op: "read manifest".to_string(),
                source: e.to_string(),
            }
        }
    })?;
    Manifest::parse(&path.display().to_string(), &text)
}

/// Visit one package: mark gray, walk its dependencies, emit post-order.
fn visit(dir: &Path, manifest: Manifest, depth: u32, ctx: &mut Ctx) -> Result<(), PkgError> {
    if depth > RESOLUTION_DEPTH_LIMIT {
        return Err(PkgError::DepthLimitExceeded {
            limit: RESOLUTION_DEPTH_LIMIT,
            package: manifest.package,
        });
    }
    let name = manifest.package;

    match ctx.colors.get(&name) {
        Some(Color::Black) => return Ok(()),
        Some(Color::Gray) => {
            let start = ctx.stack.iter().position(|n| n == &name).unwrap_or(0);
            let mut cycle: Vec<String> = ctx.stack[start..].to_vec();
            cycle.push(name.clone());
            return Err(PkgError::CycleDetected { cycle });
        }
        _ => {}
    }

    ctx.colors.insert(name.clone(), Color::Gray);
    ctx.stack.push(name.clone());

    for (dep_name, constraint) in &manifest.depends {
        ctx.edges
            .entry(dep_name.clone())
            .or_default()
            .push((name.clone(), *constraint));

        if ctx.colors.get(dep_name) == Some(&Color::Black) {
            continue; // already resolved; the edge is recorded for verification
        }
        if ctx.colors.get(dep_name) == Some(&Color::Gray) {
            let start = ctx.stack.iter().position(|n| n == dep_name).unwrap_or(0);
            let mut cycle: Vec<String> = ctx.stack[start..].to_vec();
            cycle.push(dep_name.clone());
            return Err(PkgError::CycleDetected { cycle });
        }

        let dep_dir = dir.join(LIBS_DIR).join(dep_name);
        if !dep_dir.is_dir() {
            return Err(PkgError::DepDirNotFound {
                name: dep_name.clone(),
                dir: dep_dir,
            });
        }
        let dep_manifest = read_manifest(&dep_dir)?;
        if &dep_manifest.package != dep_name {
            return Err(PkgError::ManifestInvalid {
                file: dep_dir.join(MANIFEST_FILE).display().to_string(),
                line: None,
                message: format!(
                    "directory is named \"{dep_name}\" but the manifest declares package \"{}\"",
                    dep_manifest.package
                ),
            });
        }
        visit(&dep_dir, dep_manifest, depth + 1, ctx)?;
    }

    ctx.stack.pop();
    ctx.colors.insert(name.clone(), Color::Black);
    let source = relative_source(&ctx.root, dir);
    let pkg = ResolvedPkg {
        name: name.clone(),
        version: manifest.version,
        dir: dir.to_path_buf(),
        source,
    };
    ctx.resolved.insert(name, pkg.clone());
    ctx.order.push(pkg);
    Ok(())
}

/// The lockfile `source` field: `dir` relative to the resolution root.
/// The root itself is `"."`; nested deps are `libs/a/libs/b` forms.
/// Every visited directory was constructed by joining outward from
/// the root, so the strip always succeeds.
fn relative_source(root: &Path, dir: &Path) -> String {
    let rel = dir.strip_prefix(root).unwrap_or(dir);
    let mut parts: Vec<String> = Vec::new();
    for comp in rel.components() {
        match comp {
            std::path::Component::CurDir => {}
            std::path::Component::Normal(s) => {
                parts.push(s.to_string_lossy().to_string());
            }
            other => parts.push(other.as_os_str().to_string_lossy().to_string()),
        }
    }
    if parts.is_empty() {
        ".".to_string()
    } else {
        parts.join("/")
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::PathBuf;

    fn fixture(tag: &str) -> PathBuf {
        let dir = std::env::temp_dir().join(format!("kerf-pkg-unit-{}-{tag}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).expect("fixture dir creates");
        dir
    }

    #[test]
    fn single_package_resolves_to_itself() {
        let dir = fixture("single");
        std::fs::write(
            dir.join(MANIFEST_FILE),
            "package = \"solo\"\nversion = \"0.1.0\"\n",
        )
        .expect("manifest writes");
        let resolution = resolve(&dir).expect("the single package resolves");
        assert_eq!(resolution.order.len(), 1);
        assert_eq!(resolution.order[0].name, "solo");
        assert_eq!(resolution.order[0].source, ".");
        assert_eq!(resolution.lockfile.packages.len(), 1);
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn self_dependency_is_an_immediate_cycle() {
        let dir = fixture("self");
        std::fs::write(
            dir.join(MANIFEST_FILE),
            "package = \"ouro\"\nversion = \"0.1.0\"\n\n[depends]\nouro = \"0.1\"\n",
        )
        .expect("manifest writes");
        match resolve(&dir) {
            Err(PkgError::CycleDetected { cycle }) => assert_eq!(
                cycle,
                vec!["ouro".to_string(), "ouro".to_string()],
                "the self-cycle names the package twice"
            ),
            other => panic!("expected a cycle error, got {other:?}"),
        }
        let _ = std::fs::remove_dir_all(&dir);
    }
}

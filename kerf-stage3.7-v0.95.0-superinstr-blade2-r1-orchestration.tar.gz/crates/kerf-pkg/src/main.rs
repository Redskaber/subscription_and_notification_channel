//! `kp` — the kerf package tool (W-3.10 driver face).
//!
//! Hand-rolled argument parsing (SOP §18 — no external deps). The one
//! v0 command:
//!
//! ```text
//! kp resolve <dir>    resolve the package graph at <dir>,
//!                     print the topological order, write <dir>/kerf.lock
//! ```

use kerf_pkg::{Lockfile, resolve};
use std::path::Path;
use std::process::ExitCode;

fn main() -> ExitCode {
    let args: Vec<String> = std::env::args().skip(1).collect();
    match args.as_slice() {
        [cmd, dir] if cmd == "resolve" => run_resolve(Path::new(dir)),
        [flag] if flag == "--help" || flag == "-h" || flag == "help" => {
            print_usage();
            ExitCode::SUCCESS
        }
        _ => {
            print_usage();
            ExitCode::FAILURE
        }
    }
}

fn run_resolve(dir: &Path) -> ExitCode {
    match resolve(dir) {
        Ok(resolution) => {
            for pkg in &resolution.order {
                println!("{} {} ({})", pkg.name, pkg.version, pkg.source);
            }
            match write_lockfile(dir, &resolution.lockfile) {
                Ok(()) => {
                    println!(
                        "wrote {} ({} package{})",
                        dir.join("kerf.lock").display(),
                        resolution.lockfile.packages.len(),
                        if resolution.lockfile.packages.len() == 1 {
                            ""
                        } else {
                            "s"
                        }
                    );
                    ExitCode::SUCCESS
                }
                Err(err) => {
                    eprintln!("kp: {err}");
                    ExitCode::FAILURE
                }
            }
        }
        Err(err) => {
            eprintln!("kp: {err}");
            ExitCode::FAILURE
        }
    }
}

/// Write the lockfile next to the root manifest (deterministic text).
fn write_lockfile(dir: &Path, lockfile: &Lockfile) -> Result<(), kerf_pkg::PkgError> {
    let path = dir.join("kerf.lock");
    std::fs::write(&path, lockfile.to_text()).map_err(|e| kerf_pkg::PkgError::Io {
        op: "write lockfile".to_string(),
        source: e.to_string(),
    })
}

fn print_usage() {
    println!("usage: kp resolve <dir>");
    println!("  resolve the package graph at <dir> and write <dir>/kerf.lock");
}

//! The W-3.12 segment-one steady-state bootstrap chain (w3.12-frontend-window
//! §5, the r120 T-b activation agenda): the twin read chain compiled
//! ONCE and fed per source through the injection channel.
//!
//! The delta against the per-source route (the RS-1 test channel,
//! `target_byte_table_prefix`): there the byte table rides the
//! program TEXT as a quoted define, so every read re-parses,
//! re-checks and re-compiles the whole assembled twin program (the
//! measured ~3.1 ms-per-read compile share). Here the twin program is
//! FIXED — `lexer.ktf` + `reader.ktf`, nothing else — so the parse /
//! typecheck / compile happens once at construction, and each read
//! binds the byte table into the `source_bytes` global slot through
//! [`kerf_vm::Vm::inject_global`] (the injection channel's VM arm)
//! before the run: the measured steady-state shape, every read at
//! the VM's own share (the 450× bound the dual-chain decoupling
//! ruling, SOP §21.12-28 ②, reclassified from a segment-elevation
//! precondition to a production-slot switch condition).
//!
//! The payload is the SAME RS-1 encoding (one integer per byte,
//! empty source as `nil` — [`crate::bootstrap::lexer_parity::byte_table_literal`]),
//! and the decoded outcome rides the SAME three-globals face
//! (`lex-error` / `tokens` / `result`) the per-source route decodes —
//! only the DELIVERY face changed (text literal in, host slot bind
//! out). Zero new primitives, zero new builtins, zero frozen-surface
//! change: the channel is a host-face extension (the §18 review
//! record rides w3.12-frontend-window.md).
//!
//! Channel contract (the build-time half; the per-bind half lives on
//! the engines):
//! * the fixed program must REFERENCE `source_bytes` (the compiler's
//!   collected global table is the single source — checked at
//!   construction so the chain fails at build, not at first read);
//! * the fixed program must not DEFINE `source_bytes` (a program-side
//!   define overwrites the bound slot at run time). The twins hold
//!   that discipline; the corpus sweep through this chain is the
//!   machine check (a clobber collapses every read onto one table
//!   and the sweep drifts loudly).

use kerf_compiler::{Bytecode, compile_program};
use kerf_runtime::Evaluator;
use kerf_vm::{BufferIo, Vm};

use crate::bootstrap::lexer_parity::{
    ChainOutcome, byte_table_literal, classify_engine_failure, decode_engine_globals,
};
use crate::session::Session;

/// The injected global's canonical name — the RS-1 contract name
/// `source-bytes` (the same identity the S-expr prefix form
/// defines); the twins SPELL it `source_bytes` on the target skin,
/// and the E5 skin map (rule K, the separator) canonicalizes the
/// token to this one identity before it reaches the pool, so the
/// expansion, the compiled global table and the slot bind all ride
/// a single Symbol (one constant so the chain and its tests never
/// re-type the binding site).
pub const STEADY_SOURCE_NAME: &str = "source-bytes";

/// The host name the fixed twin program parses under (diagnostics
/// attribution only — the twins verify clean, so it never surfaces).
const STEADY_HOST_NAME: &str = "steady-reader-chain.ktf";

/// The steady-state twin read chain: the compiled fixed program plus
/// the parsed items (the evaluator arm's input — the dual-engine
/// discipline consumes the same program through both engines).
pub struct SteadyReaderChain {
    bc: Bytecode,
    items: Vec<kerf_core::ModuleItem>,
}

impl SteadyReaderChain {
    /// Compile the fixed twin program ONCE: `lexer.ktf` +
    /// `reader.ktf` concatenated, parsed through the production
    /// bridge (the target-skin reader), checked, compiled. No
    /// per-source prefix ever enters this text.
    pub fn new() -> Result<Self, String> {
        let assembled = format!(
            "{}\n{}",
            crate::bootstrap::target_corpus::LEXER_TARGET_SOURCE,
            crate::bootstrap::target_corpus::READER_TARGET_SOURCE
        );
        // The injection channel's front-end face: the host declares
        // `source_bytes` as an injected global (the extern-names
        // precedent), so the fixed program's free reference expands
        // — the payload still arrives only through the run-time slot
        // bind (an unbilled host meets `UnboundGlobal` fail-closed).
        let injected = [kerf_span::Symbol::new(STEADY_SOURCE_NAME)
            .expect("the injected name is a valid identifier")];
        let mut session = Session::new();
        let program = crate::pipeline::parse_target_with_injected(
            &mut session,
            STEADY_HOST_NAME,
            &assembled,
            &injected,
        )
        .map_err(|diags| {
            format!("harness defect: the fixed twin program failed to parse: {diags:?}")
        })?;
        let findings = program.typecheck();
        if findings
            .iter()
            .any(|d| d.severity == crate::diagnostic::Severity::Error)
        {
            return Err(format!(
                "harness defect: the fixed twin program failed the checker: {findings:?}"
            ));
        }
        let bc = compile_program(&program.items).map_err(|err| {
            format!("harness defect: the fixed twin program failed to compile: {err}")
        })?;
        // The channel contract's build-time face: the program must
        // reference the injected name — the compiler's collected
        // global table is the single source (the same check
        // `Vm::inject_global` enforces per bind, hoisted here so a
        // twin regression fails at construction, not at first read).
        if !bc.globals.iter().any(|g| g.as_str() == STEADY_SOURCE_NAME) {
            return Err(format!(
                "harness defect: the twin program does not reference `{STEADY_SOURCE_NAME}` — the injection channel has no slot"
            ));
        }
        Ok(Self {
            bc,
            items: program.items,
        })
    }

    /// One read through the steady chain on the VM engine: a fresh
    /// VM per read (the globals start clean — the steady-state
    /// per-read shape), the source bound through the injection
    /// channel, the run, the decoded three-globals outcome.
    pub fn read(&self, source: &str) -> Result<ChainOutcome, String> {
        let mut vm = Vm::with_io(self.bc.clone(), Box::new(BufferIo::default()))
            .map_err(|err| format!("harness defect: the vm rejected the twin program: {err}"))?;
        vm.inject_global(STEADY_SOURCE_NAME, &byte_table_literal(source))
            .map_err(|err| format!("harness defect: the injection channel: {err}"))?;
        vm.run()
            .map_err(|err| classify_engine_failure("vm", "steady chain", &err))?;
        decode_engine_globals(
            vm.global("lex-error"),
            vm.global("tokens"),
            vm.global("result"),
            vm.heap(),
            source,
            "vm",
        )
    }

    /// One read on BOTH engines (the RS-4 dual-engine discipline: the
    /// same program, the same injection, the two engines' outcomes
    /// both decoded — the caller asserts their agreement).
    pub fn read_dual(&self, source: &str) -> Result<(ChainOutcome, ChainOutcome), String> {
        let vm_outcome = self.read(source)?;
        let mut evaluator = Evaluator::with_io(Box::new(BufferIo::default()));
        evaluator
            .inject_global(STEADY_SOURCE_NAME, &byte_table_literal(source))
            .map_err(|err| format!("harness defect: the injection channel: {err}"))?;
        evaluator
            .eval_program(&self.items)
            .map_err(|err| classify_engine_failure("eval", "steady chain", &err))?;
        let eval_outcome = decode_engine_globals(
            evaluator.global("lex-error"),
            evaluator.global("tokens"),
            evaluator.global("result"),
            evaluator.heap(),
            source,
            "eval",
        )?;
        Ok((vm_outcome, eval_outcome))
    }

    /// The compiled fixed product (the once-compiled bytecode — the
    /// observation face for tests and the measurement harness; the
    /// per-read cost is the injection + run, never a recompile).
    pub fn bytecode(&self) -> &Bytecode {
        &self.bc
    }
}

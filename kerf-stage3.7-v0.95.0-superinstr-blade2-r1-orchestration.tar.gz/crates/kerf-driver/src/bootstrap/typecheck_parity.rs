//! The W-HM-TWIN segment-three check-face parity (w-hm-twin-window.md
//! §3, the 127-b MUV): the conservative checker twin —
//! `selfhost/v1/typecheck.ktf`, the full `check_module` mirror
//! written in the frozen target subset — checked against the Rust
//! checker oracle (`kerf_typecheck::check_module`) bit-for-bit on the
//! check axis: the pass-1 table face (every define in flat walk
//! order with its shape — the INF-9 mirror guard made direct: the
//! twin's table axis compares against the oracle's `table_axes` on
//! every sweep row) and the diagnostics channel (report order, the
//! five-field record plus the r109 F2 subject set, the template
//! payloads rendered through the oracle's own format strings — the
//! R8 single-source dictionary).
//!
//! Hosting (TWIN-2, the INJ-1 channel's segment-three payload — the
//! same channel and the same CP-1 record grammar as the inference
//! twin): the host runs the Rust reader and the Rust expander and
//! injects the EXPANDED item tree through the channel's value face
//! ([`items_stream_literal`], reused verbatim — the single-source
//! payload builder).
//!
//! Externals construction: the oracle face runs `check_module` under
//! the pipeline's own table (`pipeline_externals` — the 18-builtin
//! arity registry plus the program's own extern entries); the twin
//! builds the equivalent table from the baked builtin chain plus the
//! stream's inline extern records (the params-list length is the
//! arity, last-binding-wins through remove-then-append — the
//! `Externals::insert` retain semantics).
//!
//! Comparison face: both sides render into the same compact verdict
//! text — `(ok (table (defines (de name shape) ...) (assigned name
//! ...) (diags (cdiag code severity s e message (subjects ...))
//! ...))` — shapes as `(fn n)` / `(lit kind)` / `other`, spans as
//! decimal strings, the messages through the oracle's format strings
//! (the twin's payload carries the structured template id plus
//! arguments, never a baked message).

use kerf_core::ModuleItem;
use kerf_typecheck::{Severity, TypeDiagnostic, check_module, table_axes};
use kerf_vm::{Heap, Value};

use crate::bootstrap::reader_parity::{as_i64, as_str, need_fields, value_elems};

// ---------- the oracle face (the check axis) ----------

/// The Rust checker oracle's verdict text on the check axis:
/// `check_module` under the pipeline externals, plus the pass-1
/// table rendered through `table_axes` (the mirror guard's oracle
/// side), rendered into the same compact face the twin's product
/// decodes into.
pub fn oracle_check_axes(items: &[ModuleItem]) -> String {
    let externals = crate::pipeline::pipeline_externals(items);
    let axes = table_axes(items);
    let diags = check_module(items, &externals);
    let mut out = String::from("(ok (table (defines");
    for (name, tag, arity, kind) in &axes.defines {
        out.push_str(" (de ");
        out.push_str(name.as_str());
        out.push(' ');
        out.push_str(&oracle_shape_text(tag, *arity, kind));
        out.push(')');
    }
    out.push_str(") (assigned");
    for name in &axes.assigned {
        out.push(' ');
        out.push_str(name.as_str());
    }
    out.push_str(")) (diags");
    for d in &diags {
        out.push(' ');
        out.push_str(&oracle_cdiag(d));
    }
    out.push_str("))");
    out
}

/// One define shape as text: `(fn n)` / `(lit kind)` / `other` (the
/// twin's shape vocabulary rendered from the oracle's `TableAxes`
/// row).
fn oracle_shape_text(tag: &str, arity: u32, kind: &str) -> String {
    match tag {
        "fn" => format!("(fn {arity})"),
        "lit" => format!("(lit {kind})"),
        _ => "other".to_string(),
    }
}

/// One oracle cdiag record: `(cdiag code severity s e message
/// (subjects))` — the message is the oracle's own pre-rendered
/// string (the twin's payload must produce the same text through
/// the template table).
fn oracle_cdiag(d: &TypeDiagnostic) -> String {
    let sev = match d.severity {
        Severity::Error => "error",
        Severity::Warning => "warning",
    };
    let subjects = d
        .subjects
        .iter()
        .map(|s| s.as_str())
        .collect::<Vec<_>>()
        .join(" ");
    format!(
        "(cdiag {} {} {} {} {} ({subjects}))",
        d.code.as_str(),
        sev,
        d.span.start.0,
        d.span.end.0,
        d.message
    )
}

// ---------- the twin product decoder ----------

/// The check twin's `result` global decoded into the same compact
/// verdict text the oracle face renders — the comparison point of
/// the sweep.
pub fn decode_check_result(value: &Value, heap: &Heap) -> Result<String, String> {
    let elems = value_elems(value, heap)?;
    need_fields(&elems, 3, "the twin's result record")?;
    if as_str(elems[0])? != "ok" {
        return Err(format!(
            "the twin's verdict tag is `{}` — the module driver must complete",
            as_str(elems[0])?
        ));
    }
    let table_secs = value_elems(elems[1], heap)?;
    need_fields(&table_secs, 3, "the twin's table section")?;
    if as_str(table_secs[0])? != "table" {
        return Err("the table section tag drifted".to_string());
    }
    let diags_secs = value_elems(elems[2], heap)?;
    need_fields(&diags_secs, 2, "the twin's diags section")?;
    if as_str(diags_secs[0])? != "diags" {
        return Err("the diags section tag drifted".to_string());
    }
    let defines_secs = value_elems(table_secs[1], heap)?;
    need_fields(&defines_secs, 2, "the defines section")?;
    if as_str(defines_secs[0])? != "defines" {
        return Err("the defines section tag drifted".to_string());
    }
    let assigned_secs = value_elems(table_secs[2], heap)?;
    need_fields(&assigned_secs, 2, "the assigned section")?;
    if as_str(assigned_secs[0])? != "assigned" {
        return Err("the assigned section tag drifted".to_string());
    }
    let de_list = value_elems(defines_secs[1], heap)?;
    let name_list = value_elems(assigned_secs[1], heap)?;
    let cdiags = value_elems(diags_secs[1], heap)?;
    let mut out = String::from("(ok (table (defines");
    for de in &de_list {
        out.push(' ');
        out.push_str(&twin_de(de, heap)?);
    }
    out.push_str(") (assigned");
    for n in &name_list {
        out.push(' ');
        out.push_str(as_str(n)?);
    }
    out.push_str(")) (diags");
    for d in &cdiags {
        out.push(' ');
        out.push_str(&twin_cdiag(d, heap)?);
    }
    out.push_str("))");
    Ok(out)
}

/// One twin de record: `("de" name shape)` — the shape is the
/// `("fn" n)` / `("lit" kind)` pair or the bare `"other"` string.
fn twin_de(v: &Value, heap: &Heap) -> Result<String, String> {
    let e = value_elems(v, heap)?;
    need_fields(&e, 3, "de record")?;
    if as_str(e[0])? != "de" {
        return Err(format!(
            "a non-de record in the defines section: {}",
            as_str(e[0])?
        ));
    }
    let name = as_str(e[1])?;
    let shape = twin_shape(e[2], heap)?;
    Ok(format!("(de {name} {shape})"))
}

/// One twin shape value: the pair records and the bare string.
fn twin_shape(v: &Value, heap: &Heap) -> Result<String, String> {
    match v {
        Value::Pair(_) => {
            let e = value_elems(v, heap)?;
            let tag = as_str(*e.first().ok_or("an empty shape record")?)?;
            match tag {
                "fn" => {
                    need_fields(&e, 2, "fn shape")?;
                    Ok(format!("(fn {})", as_i64(e[1])?))
                }
                "lit" => {
                    need_fields(&e, 2, "lit shape")?;
                    Ok(format!("(lit {})", as_str(e[1])?))
                }
                other => Err(format!("unknown twin shape tag `{other}`")),
            }
        }
        other => {
            let tag = as_str(other)?;
            if tag == "other" {
                Ok("other".to_string())
            } else {
                Err(format!("unknown twin shape text `{tag}`"))
            }
        }
    }
}

/// One twin cdiag record: `("cdiag" code severity s e payload
/// subjects)` — the payload is the structured template id plus
/// arguments; the message renders through the oracle's own format
/// strings (the R8 single-source dictionary below).
fn twin_cdiag(v: &Value, heap: &Heap) -> Result<String, String> {
    let e = value_elems(v, heap)?;
    need_fields(&e, 7, "cdiag record")?;
    if as_str(e[0])? != "cdiag" {
        return Err(format!("a non-cdiag record: {}", as_str(e[0])?));
    }
    let code = as_str(e[1])?;
    let sev = as_str(e[2])?;
    let s = as_str(e[3])?;
    let diag_e = as_str(e[4])?;
    let message = render_cdiag_template(e[5], heap)?;
    let subjects = value_elems(e[6], heap)?;
    let subj = subjects
        .iter()
        .map(|x| Ok(as_str(x)?.to_string()))
        .collect::<Result<Vec<_>, String>>()?
        .join(" ");
    Ok(format!(
        "(cdiag {code} {sev} {s} {diag_e} {message} ({subj}))"
    ))
}

/// The R8 single-source dictionary — the check layer's message
/// templates, the oracle's own format strings (the twin's payload
/// carries the template id plus the arguments flat —
/// `("cid" arg1 arg2 ...)`; this table is the only rendering
/// authority on the twin side, so the sweep cross-checks it against
/// the oracle's baked messages on every diagnostic row). The
/// count phrases agree with their number (the MSG-3 singular/plural
/// discipline — the same wording family as
/// `RuntimeError::ArityMismatch`).
fn render_cdiag_template(payload: &Value, heap: &Heap) -> Result<String, String> {
    let e = value_elems(payload, heap)?;
    need_fields(&e, 2, "template payload")?;
    let id = as_str(e[0])?;
    let args = &e[1..];
    let arg_str = |i: usize| -> Result<String, String> {
        Ok(as_str(*args.get(i).ok_or("the template arity drifted")?)?.to_string())
    };
    let arg_int = |i: usize| -> Result<i64, String> {
        as_i64(*args.get(i).ok_or("the template arity drifted")?)
    };
    let count_phrase = |n: i64| -> &'static str { if n == 1 { "argument" } else { "arguments" } };
    match id {
        // R1 — the unbound reference.
        "c1" => Ok(format!("unbound variable `{}`", arg_str(0)?)),
        // R2 — the application arity mismatch, named and anonymous.
        "c2n" => Ok(format!(
            "arity mismatch: `{}` expects `{}` {}, got `{}`",
            arg_str(0)?,
            arg_int(1)?,
            count_phrase(arg_int(1)?),
            arg_int(2)?
        )),
        "c2a" => Ok(format!(
            "arity mismatch: function expects `{}` {}, got `{}`",
            arg_int(0)?,
            count_phrase(arg_int(0)?),
            arg_int(1)?
        )),
        // R3 — the non-boolean literal condition.
        "c3" => Ok(format!(
            "type mismatch: `if` condition must be a bool, got `{}`",
            arg_str(0)?
        )),
        // R4 — the literal application callee, named and anonymous.
        "c4n" => Ok(format!(
            "cannot call `{}`: defined as a literal `{}` value",
            arg_str(0)?,
            arg_str(1)?
        )),
        "c4a" => Ok(format!("cannot call a literal `{}` value", arg_str(0)?)),
        // R5 — the routed handler's arity mismatch.
        "c5" => Ok(format!(
            "handler arity mismatch: handler for `{}` expects `{}` {}, got `{}`",
            arg_str(0)?,
            arg_int(1)?,
            count_phrase(arg_int(1)?),
            arg_int(2)?
        )),
        // R6 — the top-level unhandled perform.
        "c6" => Ok(format!(
            "unhandled effect `{}` at module top level",
            arg_str(0)?
        )),
        // R7 — the literal handler, named and anonymous.
        "c7n" => Ok(format!(
            "handler for `{}` cannot be called: `{}` is defined as a literal `{}` value",
            arg_str(0)?,
            arg_str(1)?,
            arg_str(2)?
        )),
        "c7a" => Ok(format!(
            "handler for `{}` cannot be called: it is a literal `{}` value",
            arg_str(0)?,
            arg_str(1)?
        )),
        // R8 — the surprising assignment targets (warning severity).
        "c8b" => Ok(format!("assignment rebinds builtin `{}`", arg_str(0)?)),
        "c8g" => Ok(format!(
            "assignment to `{}` implicitly creates a global",
            arg_str(0)?
        )),
        // LA7 — the captured-assignment boundary.
        "c12" => Ok(format!(
            "cannot assign to captured variable `{}`",
            arg_str(0)?
        )),
        other => Err(format!("unknown template id `{other}`")),
    }
}

// ---------- the 127-c per-source text route (the check face) ----------

/// The per-source text route for the checker twin (the RS-1
/// test-channel form — the expander precedent's `per_source_route`
/// shape): the item stream as the program-text `items` prefix plus
/// the fixed checker twin text, ONE program parsed through the
/// production bridge, run on BOTH engines; both verdict texts
/// decode through the same single-source decoder — the cross-route
/// equivalence's per-source side (the steady check chain is the
/// injection side) and the RS-4 engine-agreement face in one drive.
pub fn check_twin_per_source_dual(items: &[ModuleItem]) -> Result<(String, String), String> {
    let assembled = format!(
        "{}\n{}",
        crate::bootstrap::target_corpus::target_items_stream_prefix(items),
        crate::bootstrap::target_corpus::TYPECHECK_TARGET_SOURCE
    );
    let decode =
        |value: &Value, heap: &Heap| -> Result<String, String> { decode_check_result(value, heap) };
    crate::bootstrap::reader_parity::drive_dual_engines(
        "check-parity-host.ktf",
        "target check twin",
        &assembled,
        crate::pipeline::ReaderFace::Target,
        decode,
        decode,
    )
}

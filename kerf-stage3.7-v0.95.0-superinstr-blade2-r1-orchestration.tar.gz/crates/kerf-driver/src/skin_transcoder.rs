//! The step-5 corpus-face skin transcoder (switch-window-plan §1
//! step 5, stage0.md §9.30.4): one S-expression program, rendered
//! on the target skin.
//!
//! The step-3 twins were translated by hand (the five selfhost
//! files); the step-5 corpus closeout cannot afford 85 hand
//! translations, and per-file special casing would be the opposite
//! of the general face the window is building. This module is the
//! mechanical transcoder: it reads the S-expression Stx tree of a
//! corpus program and emits the target-skin text that reads back
//! to the same program — the inverse of the skin dictionary the
//! target reader applies at parse time (§9.26.9), driven form by
//! form.
//!
//! The naming guard carries over from the step-3 prefix twins
//! (target_corpus.rs): every emission is round-trip checked
//! through the REAL target reader, and a form the target skin
//! cannot spell is a [`TranscodeError`] — a ledger entry, never a
//! silent rewrite. The ledger is the honest face of this round's
//! teardown evaluation (the coverage number and its exceptions):
//!
//! - **negative literals in expression position** — the target
//!   lexical face has no negative literal (`-` is the binary
//!   operator; the S-expression face lexes `-3` as one atom). Data
//!   positions carry the sign (`quote(-1)`); expressions compose
//!   it. `i64::MIN` has no positive counterpart to compose from.
//! - **non-binary operator calls** — the target operator skin is
//!   binary; the S-expression varargs spine (`(+ a b c)`) has no
//!   twin.
//! - **macro declarations** — RETIRED at r114 (the W-3.3 window:
//!   `macro name { spec }` is the declaration carrier, the spec
//!   rides the datum emitter verbatim, and the round-trip guard
//!   holds the match-tree invariance — TD-007 cleared; the corpus's
//!   nine macro cases now transcode mechanically).
//!
//! Everything else — items, the do/let fold, closures, effects,
//! handlers, operators, calls, quotes, macro declarations and the
//! E5 name skin — transcloses mechanically, and the sweep in
//! `target_corpus_sweep_tests.rs` drives all 91 cases through it.

use kerf_span::FileId;
use kerf_syntax::{StxDatum, SyntaxObject};

use crate::target_skin::emit_target_datum;

/// Why one corpus program cannot ride the mechanical transcode
/// face — the step-5 exception ledger entry (errors are data, §2.3).
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum TranscodeError {
    /// A negative numeric literal in expression position (see the
    /// module doc — the target lexical face has no negative
    /// literal; `i64::MIN` in particular has no positive
    /// counterpart to compose from).
    NegativeLiteral { case: String },
    /// An operator call whose arity is not two (the target
    /// operator skin is binary chains only).
    NonBinaryOperator {
        case: String,
        head: String,
        arity: usize,
    },
    /// Any other form family the emitter does not know how to
    /// spell — always reported, never approximated.
    Unspellable { case: String, what: String },
}

impl TranscodeError {
    /// The stable ledger key (the sweep's coverage report groups by
    /// it).
    pub fn ledger_key(&self) -> &'static str {
        match self {
            TranscodeError::NegativeLiteral { .. } => "negative-literal",
            TranscodeError::NonBinaryOperator { .. } => "non-binary-operator",
            TranscodeError::Unspellable { .. } => "unspellable",
        }
    }
}

impl std::fmt::Display for TranscodeError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            TranscodeError::NegativeLiteral { case } => write!(
                f,
                "case `{case}`: a negative literal in expression position — the target \
                 lexical face has no negative literal"
            ),
            TranscodeError::NonBinaryOperator { case, head, arity } => write!(
                f,
                "case `{case}`: operator `{head}` with arity {arity} — the target \
                 operator skin is binary"
            ),
            TranscodeError::Unspellable { case, what } => {
                write!(f, "case `{case}`: unspellable form — {what}")
            }
        }
    }
}

/// The binary operators of the skin dictionary (§9.26.4): the
/// S-expression head and its target spelling. `=` is the one
/// spelling that changes (`==`).
fn binary_operator(head: &str) -> Option<&'static str> {
    match head {
        "+" => Some("+"),
        "-" => Some("-"),
        "*" => Some("*"),
        "/" => Some("/"),
        "=" => Some("=="),
        "<" => Some("<"),
        ">" => Some(">"),
        "<=" => Some("<="),
        ">=" => Some(">="),
        _ => None,
    }
}

/// The heads the emitter treats as operators (for the arity check
/// in [`emit_expr`] — a varargs call to one of these is a ledger
/// entry, not a call emission).
fn is_operator_head(head: &str) -> bool {
    binary_operator(head).is_some()
}

/// Transcode one whole S-expression program (the forms of a corpus
/// case) into target-skin source text, and round-trip check the
/// emission through the real target reader: the transcoded text
/// must read back to the byte-identical Stx display sequence (the
/// step-3 naming guard, lifted from the prefix twins to whole
/// programs — the tree, not the text, is the contract).
///
/// A form family the target skin cannot spell returns a
/// [`TranscodeError`] — the caller's ledger, never a rewrite here.
pub fn transcode_program(case: &str, forms: &[SyntaxObject]) -> Result<String, TranscodeError> {
    let mut out = String::with_capacity(forms.len() * 48);
    for form in forms {
        emit_item(case, form, &mut out)?;
        out.push('\n');
    }
    // The naming guard: the emission must read back to the same
    // PROGRAM. Spans differ (two source texts); the Display face is
    // span-free. Two calibers, either suffices (§9.25.4's layering
    // applied to the guard itself):
    // 1. the identical Stx display sequence (the strict face);
    // 2. the alpha-equivalent EXPANDED item trees — the legal
    //    normalizations (the single-wrapped let pair, the flat
    //    versus folded do — the r110 discipline) read back to a
    //    different Stx shape and the identical CoreExpr.
    // Error-face programs (which fail to expand) fall back to the
    // strict face: the trees feeding the shared expander must be
    // identical, or the rejection itself would drift.
    let read_back = kerf_reader::read_target_program(FileId(0), &out).map_err(|e| {
        TranscodeError::Unspellable {
            case: case.to_string(),
            what: format!("the emission failed to read back through the target reader: {e}"),
        }
    })?;
    if read_back.len() != forms.len() {
        return Err(TranscodeError::Unspellable {
            case: case.to_string(),
            what: format!(
                "the round trip changed the form count ({} in, {} back)",
                forms.len(),
                read_back.len()
            ),
        });
    }
    let display_equal = forms
        .iter()
        .zip(&read_back)
        .all(|(a, b)| a.datum.to_string() == b.datum.to_string());
    if display_equal {
        return Ok(out);
    }
    // The normalization caliber: both sides expand, and the items
    // are alpha-equivalent (the ruling-H bijection face — reused
    // from the driver's parity machinery via the expander's own
    // comparison? No: the guard compares STRUCTURE, and the expander
    // is the single semantics — so both expansions must succeed and
    // agree item-by-item under the alpha face).
    let alpha = kerf_driver_alpha(case, forms, &read_back)?;
    if alpha {
        Ok(out)
    } else {
        Err(TranscodeError::Unspellable {
            case: case.to_string(),
            what: "the round trip drifted (neither the Stx face nor the expanded \
                   alpha face agrees)"
                .to_string(),
        })
    }
}

/// The guard's normalization caliber: both sides expand, and the
/// item trees agree under the ruling-H alpha face (span-blind,
/// locally-bound names modulo a bijection). The comparison lives in
/// the driver's parity module — the single alpha machinery source.
fn kerf_driver_alpha(
    case: &str,
    forms: &[SyntaxObject],
    read_back: &[SyntaxObject],
) -> Result<bool, TranscodeError> {
    use kerf_expander::expand_program;
    let a = expand_program(forms).map_err(|e| TranscodeError::Unspellable {
        case: case.to_string(),
        what: format!(
            "the guard's normalization caliber needs both sides to expand (the seed side \
             rejected: {e})"
        ),
    })?;
    let b = expand_program(read_back).map_err(|e| TranscodeError::Unspellable {
        case: case.to_string(),
        what: format!(
            "the guard's normalization caliber needs both sides to expand (the target side \
             rejected: {e})"
        ),
    })?;
    if a.len() != b.len() {
        return Ok(false);
    }
    Ok(crate::parity::alpha_items_equal(&a, &b))
}

/// The list items of a form, or `None` for an atom.
fn list_items(form: &SyntaxObject) -> Option<&[SyntaxObject]> {
    match &form.datum {
        StxDatum::List(items) => Some(items),
        _ => None,
    }
}

/// The head symbol text of a list form, or `None`.
fn head_text(form: &SyntaxObject) -> Option<&str> {
    let items = list_items(form)?;
    match items.first().map(|f| &f.datum) {
        Some(StxDatum::Symbol(s)) => Some(s.as_str()),
        _ => None,
    }
}

/// One top-level item.
fn emit_item(case: &str, form: &SyntaxObject, out: &mut String) -> Result<(), TranscodeError> {
    let items = match list_items(form) {
        Some(items) => items,
        None => {
            // A bare atom at the top level — an expression statement.
            emit_expr(case, form, out)?;
            out.push(';');
            return Ok(());
        }
    };
    match head_text(form) {
        Some("define") if items.len() >= 3 && matches!(items[1].datum, StxDatum::List(_)) => {
            // (define (name params...) body...) -> fn name(params) { body }
            let name_and_params = match &items[1].datum {
                StxDatum::List(np) => np,
                _ => unreachable!("the guard checked the shape"),
            };
            let name = match name_and_params.first().map(|f| &f.datum) {
                Some(StxDatum::Symbol(s)) => s.as_str().to_string(),
                _ => {
                    return Err(TranscodeError::Unspellable {
                        case: case.to_string(),
                        what: "a define whose head is not a symbol".to_string(),
                    });
                }
            };
            out.push_str("fn ");
            // The function name is a VALUE name — it rides the
            // inverse skin (make-pair -> make_pair, Rule K back).
            out.push_str(&crate::target_skin::target_skin_spelling(&name));
            out.push('(');
            for (i, p) in name_and_params[1..].iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                emit_atom_symbol(case, p, out)?;
            }
            out.push_str(") ");
            emit_block_body(case, &items[2..], out)?;
            Ok(())
        }
        Some("define") if items.len() == 3 => {
            // (define name value) -> define(name, value);
            out.push_str("define(");
            emit_atom_symbol(case, &items[1], out)?;
            out.push_str(", ");
            emit_expr(case, &items[2], out)?;
            out.push_str(");");
            Ok(())
        }
        Some("define-syntax") if items.len() == 3 => {
            // (define-syntax name spec) -> macro NAME' { SPEC' } —
            // the W-3.3 declaration carrier (TD-007 cleared): the
            // spec rides the datum emitter VERBATIM (the same
            // single-emission truth the quote carrier uses), so the
            // round-trip guard holds the match-tree invariance —
            // the emitted twin must read back to the byte-identical
            // Stx display sequence.
            let name = match &items[1].datum {
                StxDatum::Symbol(s) => crate::target_skin::target_skin_spelling(s.as_str()),
                _ => {
                    return Err(TranscodeError::Unspellable {
                        case: case.to_string(),
                        what: "a define-syntax whose name is not a symbol".to_string(),
                    });
                }
            };
            out.push_str("macro ");
            out.push_str(&name);
            out.push_str(" { ");
            emit_target_datum(&items[2].datum, out);
            out.push_str(" }");
            Ok(())
        }
        Some("define-syntax") => Err(TranscodeError::Unspellable {
            case: case.to_string(),
            what: format!(
                "a define-syntax of arity {} — the macro body carries one spec datum",
                items.len()
            ),
        }),
        Some("module") if items.len() >= 3 => {
            // (module name items...) -> module name { items }. The
            // declaration name is a plain identifier — it rides the
            // inverse skin like every identifier (outer-mod ->
            // outer_mod, Rule K back); only the use-PATH segments
            // stay raw (the module namespace's path face).
            out.push_str("module ");
            emit_atom_symbol(case, &items[1], out)?;
            out.push_str(" {\n");
            for item in &items[2..] {
                out.push_str("    ");
                emit_item(case, item, out)?;
                out.push('\n');
            }
            out.push('}');
            Ok(())
        }
        Some("require") if items.len() == 2 => {
            // (require "name") -> use "name"; the symbol form
            // (require name) is the S-expr face's MALFORMED
            // rejection (the expander accepts strings only) — it
            // joins the ledger (the ruling-D path form maps symbol
            // paths to string module names, a different program).
            match &items[1].datum {
                StxDatum::String(value) => {
                    out.push_str("use ");
                    emit_string(value, out);
                    out.push(';');
                    Ok(())
                }
                _ => Err(TranscodeError::Unspellable {
                    case: case.to_string(),
                    what: "a require whose argument is a symbol — the S-expr face's \
                           malformed-require rejection (strings only); the target path \
                           form (ruling D) maps symbol paths to string module names, \
                           a different program"
                        .to_string(),
                }),
            }
        }
        Some("extern") => {
            // (extern ["C"] (name (type...) ret)...) -> extern "C" {
            // fn name(p0: t0, ...) -> ret; } (W-3.2). Param names are
            // documentation on the target face — the canonical form
            // drops them, so generated `pN` placeholders carry the
            // parse-and-drop surface. The name is a VALUE name (the
            // inverse skin — the same dashes-to-underscores direction
            // as the C-symbol derivation ruling, W-3.2 §1.3).
            let mut rest = &items[1..];
            let abi = match rest.first().map(|stx| &stx.datum) {
                Some(StxDatum::String(value)) => {
                    let spelling = value.as_ref().to_string();
                    rest = &rest[1..];
                    spelling
                }
                _ => "C".to_string(),
            };
            if rest.is_empty() {
                return Err(TranscodeError::Unspellable {
                    case: case.to_string(),
                    what: "an extern block with no items (the expander's malformed-extern                            rejection — the target face spells the same rejection)"
                        .to_string(),
                });
            }
            out.push_str("extern ");
            emit_string(&std::rc::Rc::from(abi.as_str()), out);
            out.push_str(" {\n");
            for item in rest {
                let entry = match &item.datum {
                    StxDatum::List(entry) if entry.len() == 3 => entry,
                    _ => {
                        return Err(TranscodeError::Unspellable {
                            case: case.to_string(),
                            what: "a malformed extern item (the expander's rejection — the                                    canonical shape is (name (param-type...) ret-type))"
                                .to_string(),
                        })
                    }
                };
                let name = match &entry[0].datum {
                    StxDatum::Symbol(name) => {
                        crate::target_skin::target_skin_spelling(name.as_str())
                    }
                    _ => {
                        return Err(TranscodeError::Unspellable {
                            case: case.to_string(),
                            what: "an extern item whose name is not a symbol".to_string(),
                        });
                    }
                };
                let params = match &entry[1].datum {
                    StxDatum::List(types) => types
                        .iter()
                        .map(|t| match &t.datum {
                            StxDatum::Symbol(sym) => Ok(sym.as_str().to_string()),
                            _ => Err(TranscodeError::Unspellable {
                                case: case.to_string(),
                                what: "an extern parameter type that is not a symbol".to_string(),
                            }),
                        })
                        .collect::<Result<Vec<_>, _>>()?,
                    _ => {
                        return Err(TranscodeError::Unspellable {
                            case: case.to_string(),
                            what: "an extern item whose parameter list is not a list".to_string(),
                        });
                    }
                };
                let ret = match &entry[2].datum {
                    StxDatum::Symbol(sym) => sym.as_str().to_string(),
                    _ => {
                        return Err(TranscodeError::Unspellable {
                            case: case.to_string(),
                            what: "an extern return type that is not a symbol".to_string(),
                        });
                    }
                };
                out.push_str("    fn ");
                out.push_str(&name);
                out.push('(');
                for (i, ty) in params.iter().enumerate() {
                    if i > 0 {
                        out.push_str(", ");
                    }
                    out.push_str(&format!("p{i}: {ty}"));
                }
                out.push_str(") -> ");
                out.push_str(&ret);
                out.push_str(";\n");
            }
            out.push('}');
            Ok(())
        }
        _ => {
            // An expression statement (the call-form rule carries
            // define/quote/etc. through the ordinary mapping).
            emit_expr(case, form, out)?;
            out.push(';');
            Ok(())
        }
    }
}

/// A symbol atom, spelled through the inverse E5 skin (the
/// step-3 `target_skin_spelling` pass, re-exported here).
fn emit_atom_symbol(
    case: &str,
    form: &SyntaxObject,
    out: &mut String,
) -> Result<(), TranscodeError> {
    match &form.datum {
        StxDatum::Symbol(s) => {
            out.push_str(&crate::target_skin::target_skin_spelling(s.as_str()));
            Ok(())
        }
        _ => Err(TranscodeError::Unspellable {
            case: case.to_string(),
            what: format!("expected a symbol atom, observed `{}`", form.datum),
        }),
    }
}

/// A block body: every form but the last rides as a statement, the
/// last is the tail. The block fold reconstructs the do/let
/// nesting; the expansion-level α-equivalence gate absorbs the
/// flat-versus-nested do difference (the r110 discipline).
fn emit_block_body(
    case: &str,
    body: &[SyntaxObject],
    out: &mut String,
) -> Result<(), TranscodeError> {
    out.push('{');
    for (i, form) in body.iter().enumerate() {
        out.push(' ');
        let is_tail = i + 1 == body.len();
        if !is_tail {
            emit_expr(case, form, out)?;
            out.push(';');
        } else {
            emit_expr(case, form, out)?;
        }
    }
    out.push_str(" }");
    Ok(())
}

/// Whether a let binding spec is well-shaped for the block skin:
/// one `(symbol value)` pair, or a non-empty list of such pairs.
fn let_spec_is_shaped(spec: &SyntaxObject) -> bool {
    let StxDatum::List(pairs) = &spec.datum else {
        return false;
    };
    let pair_is_shaped = |p: &SyntaxObject| {
        matches!(&p.datum, StxDatum::List(pp) if pp.len() == 2
            && matches!(pp[0].datum, StxDatum::Symbol(_)))
    };
    if pairs.len() == 2
        && matches!(pairs[0].datum, StxDatum::Symbol(_))
        && !pair_is_shaped(&pairs[0])
    {
        // The one-pair shape: (name value).
        true
    } else {
        // The pair-list shape: ((n v) (n v) ...).
        !pairs.is_empty() && pairs.iter().all(pair_is_shaped)
    }
}

/// Whether one handle arm is well-shaped for the handler skin:
/// `(E (fn (params...) body))`.
fn handle_arm_is_shaped(arm: &SyntaxObject) -> bool {
    let StxDatum::List(ai) = &arm.datum else {
        return false;
    };
    if ai.len() != 2 || !matches!(ai[0].datum, StxDatum::Symbol(_)) {
        return false;
    }
    let StxDatum::List(fi) = &ai[1].datum else {
        return false;
    };
    fi.len() == 3
        && matches!(&fi[0].datum, StxDatum::Symbol(h) if h.as_str() == "fn")
        && matches!(&fi[1].datum, StxDatum::List(ps)
            if ps.iter().all(|p| matches!(p.datum, StxDatum::Symbol(_))))
}

/// The ordinary call emission (the general fallback): any list
/// whose head is a symbol rides `head'(args...)` — which round-trips
/// ANY list shape, malformed special forms included. A malformed
/// `(fn x x)` / `(let 5 6)` / `(handle (arm))` thereby reaches the
/// shared expander on BOTH skins at the SAME stage (the S-expr
/// reader is shape-permissive, the target reader would reject a
/// malformed closure/let/handle at parse — the call face keeps the
/// rejection stage aligned; the shape-mismatch fall-through IS the
/// parity mechanism).
fn emit_call(
    case: &str,
    head: &str,
    items: &[SyntaxObject],
    out: &mut String,
) -> Result<(), TranscodeError> {
    let _ = case;
    out.push_str(&crate::target_skin::target_skin_spelling(head));
    out.push('(');
    for (i, arg) in items[1..].iter().enumerate() {
        if i > 0 {
            out.push_str(", ");
        }
        emit_expr(case, arg, out)?;
    }
    out.push(')');
    Ok(())
}

/// One expression.
fn emit_expr(case: &str, form: &SyntaxObject, out: &mut String) -> Result<(), TranscodeError> {
    match &form.datum {
        StxDatum::Symbol(s) => {
            out.push_str(&crate::target_skin::target_skin_spelling(s.as_str()));
            Ok(())
        }
        StxDatum::Int(v) => {
            if *v < 0 {
                return Err(TranscodeError::NegativeLiteral {
                    case: case.to_string(),
                });
            }
            out.push_str(&v.to_string());
            Ok(())
        }
        StxDatum::Float(v) => {
            // r106 FIX-11: `is_sign_negative` covers `-0.0` too (IEEE:
            // `-0.0 < 0.0` is false, so the old comparison let it
            // through to fail later as an unspellable datum instead of
            // its negative-literal ledger family).
            if v.is_sign_negative() {
                return Err(TranscodeError::NegativeLiteral {
                    case: case.to_string(),
                });
            }
            out.push_str(&format!("{v:?}"));
            Ok(())
        }
        StxDatum::Bool(v) => {
            out.push_str(if *v { "true" } else { "false" });
            Ok(())
        }
        StxDatum::String(value) => {
            emit_string(value, out);
            Ok(())
        }
        StxDatum::List(items) => emit_list_expr(case, items, form, out),
    }
}

/// A string literal, escaped with the datum carrier's escape set
/// (the single source of escaping truth — `emit_target_datum`'s
/// exact function, shared so the two faces can never drift).
fn emit_string(value: &str, out: &mut String) {
    // r106 FIX-9: delegate to the datum emitter's extracted arm —
    // the single escaping truth (the old duplicated loop was a
    // copy-drift channel this delegation closed).
    crate::target_skin::emit_escaped_string(value, out)
}

/// Whether a quoted datum tree contains an empty list (the S-expr
/// face's `(quote ())` boundary — the target datum carrier has no
/// spelling for it, `nil` being the empty-list face by convention;
/// such a case joins the ledger rather than tripping the carrier's
/// harness panic).
fn datum_has_empty_list(datum: &StxDatum) -> bool {
    match datum {
        StxDatum::List(items) => {
            items.is_empty() || items.iter().any(|i| datum_has_empty_list(&i.datum))
        }
        _ => false,
    }
}

/// A list expression, dispatched on the head symbol.
fn emit_list_expr(
    case: &str,
    items: &[SyntaxObject],
    _form: &SyntaxObject,
    out: &mut String,
) -> Result<(), TranscodeError> {
    let head = match items.first().map(|f| &f.datum) {
        Some(StxDatum::Symbol(s)) => s.as_str(),
        Some(_) => {
            // A non-symbol callee: the target postfix chain accepts
            // any expression head — `((adder 5) 3)` rides
            // `(adder(5))(3)`, `(5 1)` rides `5(1)`. Atoms emit
            // bare, lists parenthesized.
            if matches!(items[0].datum, StxDatum::List(_)) {
                out.push('(');
                emit_expr(case, &items[0], out)?;
                out.push(')');
            } else {
                emit_expr(case, &items[0], out)?;
            }
            out.push('(');
            for (i, arg) in items[1..].iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                emit_expr(case, arg, out)?;
            }
            out.push(')');
            return Ok(());
        }
        None => {
            return Err(TranscodeError::Unspellable {
                case: case.to_string(),
                what: "the empty application `()` (the target skin maps `()` to the unit \
                       value by design — ruling C12; the divergence is pinned, not \
                       transcoded)"
                    .to_string(),
            });
        }
    };
    match head {
        "quote" if items.len() == 2 => {
            // (quote data) -> quote(<datum>) — the ruling-F carrier.
            if datum_has_empty_list(&items[1].datum) {
                return Err(TranscodeError::Unspellable {
                    case: case.to_string(),
                    what: "the empty quoted list — the target datum carrier spells the \
                           empty list as `nil` by convention (the record encoders' \
                           rule), a different tree than `(quote ())`"
                        .to_string(),
                });
            }
            out.push_str("quote(");
            emit_target_datum(&items[1].datum, out);
            out.push(')');
            Ok(())
        }
        "if" if items.len() == 4 => {
            // (if c t e) -> if (c) { t } else { e }
            out.push_str("if (");
            emit_expr(case, &items[1], out)?;
            out.push_str(") ");
            emit_as_block(case, &items[2], out)?;
            out.push_str(" else ");
            emit_else(case, &items[3], out)?;
            Ok(())
        }
        "fn" if items.len() == 3 && matches!(items[1].datum, StxDatum::List(_)) => {
            // (fn (params) body) -> |(params)| { body }. A params
            // list holding a non-symbol falls through to the call
            // face (the closure skin cannot spell it; the shared
            // expander rejects the shape on both skins).
            let params = match &items[1].datum {
                StxDatum::List(params) => params,
                _ => unreachable!("the guard checked the shape"),
            };
            if !params
                .iter()
                .all(|p| matches!(p.datum, StxDatum::Symbol(_)))
            {
                return emit_call(case, head, items, out);
            }
            out.push_str("||(");
            for (i, p) in params.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                emit_atom_symbol(case, p, out)?;
            }
            out.push_str(") ");
            emit_as_block(case, &items[2], out)?;
            Ok(())
        }
        "do" if items.len() >= 2 => {
            // (do e1 e2 ...) -> { e1; e2; ... tail }
            emit_block_body(case, &items[1..], out)?;
            Ok(())
        }
        "let" if items.len() == 3 && let_spec_is_shaped(&items[1]) => {
            // (let (n v) body) / (let ((n v) ...) body) ->
            // { let n = v, ...; tail } — any other spec shape rides
            // the call face (the malformed-let parity mechanism).
            out.push_str("{ let ");
            match &items[1].datum {
                StxDatum::List(pairs) => {
                    // Either one (n v) pair or a list of pairs.
                    let is_pair_list = pairs
                        .first()
                        .map(|p| matches!(p.datum, StxDatum::List(_)))
                        .unwrap_or(false);
                    let bindings: Vec<&SyntaxObject> = if is_pair_list {
                        pairs.iter().collect()
                    } else {
                        vec![&items[1]]
                    };
                    for (i, pair) in bindings.iter().enumerate() {
                        if i > 0 {
                            out.push_str(", ");
                        }
                        match list_items(pair) {
                            Some(p) if p.len() == 2 => {
                                emit_atom_symbol(case, &p[0], out)?;
                                out.push_str(" = ");
                                emit_expr(case, &p[1], out)?;
                            }
                            _ => unreachable!("the guard checked the shapes"),
                        }
                    }
                }
                _ => unreachable!("the guard checked the shapes"),
            }
            out.push_str("; ");
            emit_expr(case, &items[2], out)?;
            out.push_str(" }");
            Ok(())
        }
        "set!" if items.len() == 3 => {
            // (set! x e) -> set(x, e) — the ruling-G call carrier
            // (valid in statement and expression position alike).
            out.push_str("set(");
            emit_atom_symbol(case, &items[1], out)?;
            out.push_str(", ");
            emit_expr(case, &items[2], out)?;
            out.push(')');
            Ok(())
        }
        "perform" if items.len() >= 3 && matches!(items[1].datum, StxDatum::Symbol(_)) => {
            // (perform E args...) -> perform E(args...)
            out.push_str("perform ");
            emit_atom_symbol(case, &items[1], out)?;
            out.push('(');
            for (i, arg) in items[2..].iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                emit_expr(case, arg, out)?;
            }
            out.push(')');
            Ok(())
        }
        "handle" if items.len() >= 3 && items[2..].iter().all(handle_arm_is_shaped) => {
            // (handle body (E (fn (p...) h))...) ->
            // handle body { E(p...) => { h }, } — a malformed arm
            // rides the call face (the parity mechanism above).
            out.push_str("handle ");
            emit_handle_body(case, &items[1], out)?;
            out.push_str(" {");
            for arm in &items[2..] {
                let arm_items = match list_items(arm) {
                    Some(ai) if ai.len() == 2 => ai,
                    _ => unreachable!("the guard checked the arm shapes"),
                };
                out.push(' ');
                emit_atom_symbol(case, &arm_items[0], out)?;
                let fn_items = match list_items(&arm_items[1]) {
                    Some(fi) if fi.len() == 3 && head_text(&arm_items[1]) == Some("fn") => fi,
                    _ => unreachable!("the guard checked the arm shapes"),
                };
                out.push('(');
                match &fn_items[1].datum {
                    StxDatum::List(params) => {
                        for (i, p) in params.iter().enumerate() {
                            if i > 0 {
                                out.push_str(", ");
                            }
                            emit_atom_symbol(case, p, out)?;
                        }
                    }
                    _ => unreachable!("the guard checked the shape"),
                }
                out.push_str(") => ");
                emit_as_block(case, &fn_items[2], out)?;
                out.push(',');
            }
            out.push_str(" }");
            Ok(())
        }
        _ if is_operator_head(head) => {
            if items.len() != 3 {
                return Err(TranscodeError::NonBinaryOperator {
                    case: case.to_string(),
                    head: head.to_string(),
                    arity: items.len() - 1,
                });
            }
            out.push('(');
            emit_expr(case, &items[1], out)?;
            out.push(' ');
            out.push_str(binary_operator(head).expect("the head matched"));
            out.push(' ');
            emit_expr(case, &items[2], out)?;
            out.push(')');
            Ok(())
        }
        _ => emit_call(case, head, items, out),
    }
}

/// One expression as a block: do/let fold naturally, anything else
/// wraps in a one-tail block.
fn emit_as_block(case: &str, form: &SyntaxObject, out: &mut String) -> Result<(), TranscodeError> {
    if let Some(head) = head_text(form) {
        if (head == "do" && list_items(form).map(|i| i.len()).unwrap_or(0) >= 2)
            || (head == "let" && list_items(form).map(|i| i.len()).unwrap_or(0) == 3)
        {
            return emit_expr(case, form, out);
        }
    }
    out.push_str("{ ");
    emit_expr(case, form, out)?;
    out.push_str(" }");
    Ok(())
}

/// The handle body: an expression (parenthesized when it is itself
/// a braced form, so the parser cannot swallow the arm block).
fn emit_handle_body(
    case: &str,
    form: &SyntaxObject,
    out: &mut String,
) -> Result<(), TranscodeError> {
    if matches!(form.datum, StxDatum::List(_)) {
        out.push('(');
        emit_expr(case, form, out)?;
        out.push(')');
    } else {
        emit_expr(case, form, out)?;
    }
    Ok(())
}

/// The if-else chain tail: a nested if rides `else if`, anything
/// else rides a block.
fn emit_else(case: &str, form: &SyntaxObject, out: &mut String) -> Result<(), TranscodeError> {
    if head_text(form) == Some("if") {
        // else if (...) { t } else ... — recurse through the
        // ordinary if emission by handing the whole form back.
        let items = list_items(form).expect("the head check guaranteed a list");
        return emit_list_expr(case, items, form, out);
    }
    emit_as_block(case, form, out)
}

#[cfg(test)]
mod tests {
    use super::*;
    use kerf_reader::read_program;

    fn transcode(src: &str) -> String {
        let forms = read_program(FileId(0), src).expect("the probe reads");
        transcode_program("probe", &forms).expect("the probe transcodes")
    }

    #[test]
    fn define_value_and_function_transcode_round_trip() {
        let out = transcode("(define result (+ 1 2)) (define (f x) (* x x))");
        assert!(out.contains("define(result, (1 + 2));"), "{out}");
        assert!(out.contains("fn f(x) { (x * x) }"), "{out}");
    }

    #[test]
    fn operators_effects_and_closures_transcode_round_trip() {
        let out = transcode("(define r (handle (perform add 1 2) (add (fn (a b) (+ a b)))))");
        assert!(
            out.contains("handle (perform add(1, 2)) { add(a, b) => { (a + b) }, }"),
            "{out}"
        );
        let out2 = transcode("(define (g n) (if (= n 0) nil (g (- n 1))))");
        assert!(out2.contains("if ((n == 0))"), "{out2}");
    }

    #[test]
    fn negative_literals_join_the_ledger() {
        let forms = read_program(FileId(0), "(define result -3)").expect("reads");
        let err = transcode_program("probe", &forms).unwrap_err();
        assert_eq!(err.ledger_key(), "negative-literal");
    }

    #[test]
    fn macro_declarations_ride_the_declaration_carrier() {
        // The r114 W-3.3 form: the declaration transcloses through
        // the `macro name { spec }` carrier (the r103 ledger family
        // retired). The round-trip guard inside `transcode_program`
        // holds the match-tree invariance — the emitted twin must
        // read back to the byte-identical Stx display.
        let out = transcode("(define-syntax m (syntax-rules nil ((_ x) x)))");
        assert!(
            out.contains("macro m { (syntax_rules, nil, ((_, x), x)) }"),
            "{out}"
        );
        // The name rides the inverse skin (kebab -> snake).
        let out2 = transcode("(define-syntax my-if (syntax-rules nil ((_ c t e) (if c t e))))");
        assert!(
            out2.contains("macro my_if { (syntax_rules, nil, ((_, c, t, e), (if, c, t, e))) }"),
            "{out2}"
        );
    }

    #[test]
    fn a_malformed_define_syntax_arity_stays_unspellable() {
        // The carrier takes exactly (define-syntax name spec); any
        // other arity joins the unspellable ledger (fail-closed,
        // never approximated — the spec the shared expander would
        // judge must ride verbatim or not at all).
        let forms = read_program(FileId(0), "(define-syntax m)").expect("reads");
        let err = transcode_program("probe", &forms).unwrap_err();
        assert_eq!(err.ledger_key(), "unspellable");
    }

    #[test]
    fn the_name_skin_rides_both_faces() {
        // car/cdr/cons/eq?/nil?/pair? -> first/rest/pair/eq/is_nil/is_pair
        let out = transcode("(define r (car (cons 1 nil)))");
        assert!(out.contains("first(pair(1, nil))"), "{out}");
        let out2 = transcode("(define r (nil? (cdr (cons 1 2))))");
        assert!(out2.contains("is_nil(rest(pair(1, 2)))"), "{out2}");
    }

    #[test]
    fn quote_data_and_set_ride_the_carriers() {
        let out = transcode("(define r (quote (1 2 3))) (define x (set! r 4))");
        assert!(out.contains("quote((1, 2, 3))"), "{out}");
        assert!(out.contains("set(r, 4)"), "{out}");
    }
}

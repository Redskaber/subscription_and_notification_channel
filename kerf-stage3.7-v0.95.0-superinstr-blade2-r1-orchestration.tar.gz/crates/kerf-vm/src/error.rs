//! Runtime errors (docs/stage0.md §19.5): every variant carries the
//! source [`Span`] resolved through the debug_info table at raise
//! time, following the §12.1 consumption row (the VM reports runtime
//! failures back at the source level).
//!
//! Class coverage (SOP §7.1.1): [`RuntimeError::ArityMismatch`] lights
//! class 5 and [`RuntimeError::TypeMismatch`] lights class 6 — the
//! 0.6 round took the seven-class matrix from 4/7 to 6/7; the 0.9
//! module-loading layer lit the seventh class (all seven lit since).

use std::fmt;

use kerf_compiler::Opcode;
use kerf_span::{Span, Symbol};

use crate::builtin::Builtin;
use crate::value::Value;

/// A runtime failure with a resolved source location.
#[derive(Debug, Clone, PartialEq)]
pub enum RuntimeError {
    /// A call passed the wrong argument count — to a closure (proto
    /// params) or to a builtin (registry arity). SOP §7.1.1 class 5.
    ArityMismatch {
        /// The callee's interned identity (`fib`, `+`); `None` for an
        /// anonymous closure (rendered `#<anonymous>` — §9.67 NB-5:
        /// the identity payload joins the single pool, mirroring the
        /// `UnboundGlobal`/`UnhandledEffect` faces).
        func: Option<Symbol>,
        expected: u32,
        actual: u32,
        span: Span,
    },
    /// A value of the wrong kind reached an operation that demands a
    /// specific one (truthy conditions demand `bool`, arithmetic
    /// demands same-kind numbers, `car`/`cdr` demand pairs, calls
    /// demand callables). SOP §7.1.1 class 6.
    TypeMismatch {
        /// What the operation demanded, e.g. `jump-if-false condition`.
        context: &'static str,
        /// The demanded kind in message shape, e.g. `a pair` (the
        /// [`demanded`] constants — §9.78 MSG-2: the raise site knows
        /// its demanded kind statically; the message names it
        /// instead of hedging, the K182 E0308 demanded-first
        /// discipline: `expected `bool`, found integer`).
        demanded: &'static str,
        /// What the operand's kind actually was.
        got: &'static str,
        span: Span,
    },
    /// A `load-global` read a never-stored non-builtin slot (the
    /// dynamic-order face verify cannot decide statically: use before
    /// the defining `store-global` executed).
    UnboundGlobal { name: Symbol, span: Span },
    /// An extern-declared function reached execution on an engine
    /// without a foreign call face (W-3.2): the VM and the
    /// meta-circular evaluator both fail closed here — the C backend
    /// is the one engine that can honor the contract. The bytecode's
    /// extern table names the contract, so the diagnostic is the
    /// boundary itself, not a generic unbound-global misreport.
    ExternCallRequiresBackend { name: Symbol, span: Span },
    /// A `perform` found no installed handler for the effect.
    UnhandledEffect { effect: Symbol, span: Span },
    /// Integer division by a zero divisor.
    DivByZero { span: Span },
    /// A checked integer operation overflowed `i64` (fail-closed, not
    /// wrapping — §2.3 deterministic boundaries).
    ArithmeticOverflow { op: Opcode, span: Span },
    /// The allocation budget ran out (the §19.4 safety point failing
    /// closed; the 0.7 collector turns this point into
    /// collect-then-retry).
    BudgetExceeded { budget: u32, span: Span },
    /// `read-line` hit the end of input.
    Eof { span: Span },
    /// A `ret` executed in the entry frame, which has no caller to
    /// return to (verify accepts it as a terminator; only the run
    /// time knows the frame stack is empty).
    RetFromEntry { pc: usize, span: Span },
    /// A stack access popped below the bottom — the §19.5 trap 2
    /// mandate (explicit depth checks on every stack access). Reachable
    /// in verified bytecode through the handler-stack face
    /// (`pop-handler n` with fewer than `n` installed).
    StackUnderflow { op: Opcode, pc: usize, span: Span },
    /// The meta-circular evaluator's recursion depth cap ran out (the
    /// 0.7 evaluator recurses in Rust while VM frames live on the
    /// heap — only the evaluator path can raise this; the VM is
    /// bounded by `BudgetExceeded` instead).
    EvalDepthExceeded { limit: u32, span: Span },
    /// An `assign` inside a closure body targets a name the closure
    /// captured (Stage 2.1 LA-7): the first-cut subset keeps captures
    /// immutable, so the assignment is a definite rejection — the
    /// evaluator-side mirror of the compile-time boundary (the
    /// checker reports it as E0012 first on the source path; this arm
    /// is the direct-API defense, same wording family — the
    /// single-source dictionary).
    AssignToCaptured { name: Symbol, span: Span },
    /// A host-side [`crate::Vm::inject_global`] named a global the
    /// bytecode's table does not carry (the W-3.12 injection
    /// channel): the table is the compiler's collected reference
    /// set, so the name is not referenced by the program — the
    /// channel rides an existing slot and never mints one
    /// (fail-closed; the `String` payload keeps the miss off the
    /// interning pool, the §9.67 NB-7 lookup discipline).
    InjectGlobalUnknown { name: String, span: Span },
}

impl RuntimeError {
    /// The resolved source location (§12.1 consumption row face — the
    /// 0.8 driver renders diagnostics through this).
    pub fn span(&self) -> Span {
        match self {
            RuntimeError::ArityMismatch { span, .. }
            | RuntimeError::TypeMismatch { span, .. }
            | RuntimeError::UnboundGlobal { span, .. }
            | RuntimeError::ExternCallRequiresBackend { span, .. }
            | RuntimeError::UnhandledEffect { span, .. }
            | RuntimeError::DivByZero { span }
            | RuntimeError::ArithmeticOverflow { span, .. }
            | RuntimeError::BudgetExceeded { span, .. }
            | RuntimeError::Eof { span }
            | RuntimeError::RetFromEntry { span, .. }
            | RuntimeError::StackUnderflow { span, .. }
            | RuntimeError::EvalDepthExceeded { span, .. }
            | RuntimeError::AssignToCaptured { span, .. }
            | RuntimeError::InjectGlobalUnknown { span, .. } => *span,
        }
    }

    /// The offending value kind, when the variant carries one.
    pub fn got_kind(&self) -> Option<&'static str> {
        match self {
            RuntimeError::TypeMismatch { got, .. } => Some(got),
            _ => None,
        }
    }
}

// The message compositions below are the single source for the
// runtime diagnostic face: `Display` renders the canonical
// (S-expr vocabulary) spelling, and the driver's skin-aware pass
// re-composes the same shapes with target-skin name spellings
// (§10.5 single-source dictionary — one format per shape, the
// name renderings are the only parameter).

/// The arity-mismatch message with a caller-supplied callee
/// spelling (the canonical face passes the pool text verbatim).
pub fn arity_mismatch_text(func: &str, expected: u32, actual: u32) -> String {
    format!(
        "arity mismatch: `{func}` expects `{expected}` {}, got `{actual}`",
        plural_args(expected)
    )
}

/// The type-mismatch message with a caller-supplied context
/// rendering.
pub fn type_mismatch_text(context: &str, demanded: &str, got: &str) -> String {
    format!("type mismatch: {context} must be {demanded}, got `{got}`")
}

/// The unbound-global message with a caller-supplied name spelling.
pub fn unbound_global_text(name: &str) -> String {
    format!("unbound global `{name}`")
}

/// The extern-on-non-C-engine message with a caller-supplied name
/// spelling (W-3.2).
pub fn extern_call_requires_backend_text(name: &str) -> String {
    format!(
        "extern function `{name}` requires the C backend: foreign calls are the chain-external engine's face"
    )
}

/// The inject-name-miss message with a caller-supplied name spelling
/// (the W-3.12 injection channel).
pub fn inject_global_unknown_text(name: &str) -> String {
    format!("inject-global name `{name}` is not referenced by the program")
}

/// The unhandled-effect message with a caller-supplied effect
/// spelling.
pub fn unhandled_effect_text(effect: &str) -> String {
    format!("unhandled effect `{effect}`")
}

/// The assign-to-captured message with a caller-supplied name
/// spelling.
pub fn assign_to_captured_text(name: &str) -> String {
    format!(
        "cannot assign to captured variable `{name}` (captures are immutable in the current subset)"
    )
}

/// The end-of-input message with a caller-supplied operation
/// spelling.
pub fn eof_text(op: &str) -> String {
    format!("{op}: end of input")
}

impl fmt::Display for RuntimeError {
    /// R8 family: lowercase start, no trailing period, backticked
    /// payloads. §9.56 DIAG-1: no position fragments — spans live in
    /// the payload and the driver renders them as the location line.
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            RuntimeError::ArityMismatch {
                func,
                expected,
                actual,
                ..
            } => f.write_str(&arity_mismatch_text(
                func.as_ref().map(Symbol::as_str).unwrap_or("#<anonymous>"),
                *expected,
                *actual,
            )),
            RuntimeError::TypeMismatch {
                context,
                demanded,
                got,
                ..
            } => f.write_str(&type_mismatch_text(context, demanded, got)),
            RuntimeError::UnboundGlobal { name, .. } => {
                f.write_str(&unbound_global_text(name.as_str()))
            }
            RuntimeError::ExternCallRequiresBackend { name, .. } => {
                f.write_str(&extern_call_requires_backend_text(name.as_str()))
            }
            RuntimeError::UnhandledEffect { effect, .. } => {
                f.write_str(&unhandled_effect_text(effect.as_str()))
            }
            RuntimeError::DivByZero { .. } => f.write_str("division by zero"),
            RuntimeError::ArithmeticOverflow { op, .. } => {
                write!(f, "{} overflow", op.kind_name())
            }
            RuntimeError::BudgetExceeded { budget, .. } => {
                write!(f, "allocation budget of `{budget}` exhausted")
            }
            RuntimeError::Eof { .. } => f.write_str(&eof_text(Builtin::ReadLine.name())),
            RuntimeError::RetFromEntry { pc, .. } => {
                write!(f, "ret from entry frame at pc `{pc}`")
            }
            RuntimeError::StackUnderflow { op, pc, .. } => {
                write!(f, "stack underflow at `{}` pc `{pc}`", op.kind_name())
            }
            RuntimeError::EvalDepthExceeded { limit, .. } => {
                write!(f, "eval depth of `{limit}` exceeded")
            }
            RuntimeError::AssignToCaptured { name, .. } => {
                f.write_str(&assign_to_captured_text(name.as_str()))
            }
            RuntimeError::InjectGlobalUnknown { name, .. } => {
                f.write_str(&inject_global_unknown_text(name))
            }
        }
    }
}

impl std::error::Error for RuntimeError {}

// The demanded-kind vocabulary for `TypeMismatch` raise sites
// (§9.78 MSG-2). Every site states what its operation demands through
// one of these constants — the wording stays single-sourced across
// the VM, the builtin registry and the evaluator (the evaluator
// imports the same constants, so the two engines cannot drift on the
// demanded text).
//
// K182 (rustc E0308 `expected `bool`, found integer`): the demanded
// kind is the first-class datum of a kind mismatch — a message that
// hides it behind a generic hedge forces the user to re-derive what
// the operation wanted.
pub mod demanded {
    /// Truthiness faces: `jump-if-false` condition, `not` operand.
    pub const BOOL: &str = "a bool";
    /// Strict pair faces: `car` / `cdr` operands.
    pub const PAIR: &str = "a pair";
    /// The strict string face: `write-line` operand.
    pub const STRING: &str = "a string";
    /// The call face: a closure value or a builtin value.
    pub const CALLABLE: &str = "a closure or builtin";
    /// The arithmetic / comparison faces: both operands must be
    /// numbers of one kind (`int`+`int` or `float`+`float`).
    pub const SAME_KIND_NUMBER: &str = "a number of the same kind";
}

/// The argument-count plural (§9.78 MSG-3): `1 argument`, `2
/// arguments`. K182 (rustc E0061 `this function takes 1 argument but
/// 2 arguments were supplied`): the count phrase agrees with its
/// number — a wrong plural on the most common runtime error family
/// is a quality defect the family tests pin out.
pub fn plural_args(n: u32) -> &'static str {
    if n == 1 { "argument" } else { "arguments" }
}

// Re-exported for the `TypeMismatch` constructors below (call sites
// stay terse inside the interpreter).
pub(crate) fn type_mismatch(
    context: &'static str,
    demanded: &'static str,
    got: &Value,
    span: Span,
) -> RuntimeError {
    RuntimeError::TypeMismatch {
        context,
        demanded,
        got: got.kind_name(),
        span,
    }
}

#[cfg(test)]
mod tests {
    //! RuntimeError face tests (FP1): every variant renders in the R8
    //! family and keeps its resolved span.

    use super::*;
    use kerf_span::{ByteOffset, ExpansionId, FileId};

    fn fix_span() -> Span {
        Span::new(FileId(0), ByteOffset(4), ByteOffset(8), ExpansionId::ROOT)
            .expect("test fixture span must be well-formed")
    }

    fn every_variant() -> Vec<RuntimeError> {
        let span = fix_span();
        vec![
            RuntimeError::ArityMismatch {
                // §9.67 NB-5: the payload identity is a pool entry.
                func: Some(Symbol::new("fib").expect("fixture symbol")),
                expected: 1,
                actual: 2,
                span,
            },
            RuntimeError::TypeMismatch {
                context: "jump-if-false condition",
                demanded: demanded::BOOL,
                got: "int",
                span,
            },
            RuntimeError::UnboundGlobal {
                name: Symbol::new("x").expect("fixture symbol"),
                span,
            },
            RuntimeError::ExternCallRequiresBackend {
                name: Symbol::new("ext-fn").expect("fixture symbol"),
                span,
            },
            RuntimeError::UnhandledEffect {
                effect: Symbol::new("log").expect("fixture symbol"),
                span,
            },
            RuntimeError::DivByZero { span },
            RuntimeError::ArithmeticOverflow {
                op: Opcode::Add,
                span,
            },
            RuntimeError::BudgetExceeded { budget: 4, span },
            RuntimeError::Eof { span },
            RuntimeError::RetFromEntry { pc: 3, span },
            RuntimeError::StackUnderflow {
                op: Opcode::PopHandler,
                pc: 7,
                span,
            },
            RuntimeError::EvalDepthExceeded { limit: 2048, span },
        ]
    }

    #[test]
    fn arity_mismatch_display_carries_both_counts() {
        // §9.56 DIAG-1: position-free — the span lives in the payload.
        // §9.78 MSG-3 (K182 E0061): the count phrase agrees with its
        // number — singular for 1, plural otherwise.
        let err = RuntimeError::ArityMismatch {
            func: Some(Symbol::new("fib").expect("fixture symbol")),
            expected: 1,
            actual: 2,
            span: fix_span(),
        };
        assert_eq!(
            err.to_string(),
            "arity mismatch: `fib` expects `1` argument, got `2`"
        );
        let plural = RuntimeError::ArityMismatch {
            func: Some(Symbol::new("add").expect("fixture symbol")),
            expected: 2,
            actual: 3,
            span: fix_span(),
        };
        assert_eq!(
            plural.to_string(),
            "arity mismatch: `add` expects `2` arguments, got `3`"
        );
        // The plural helper is the single source both counts ride on.
        assert_eq!(plural_args(1), "argument");
        assert_eq!(plural_args(0), "arguments");
        assert_eq!(plural_args(2), "arguments");
    }

    #[test]
    fn type_mismatch_display_names_context_demanded_and_got() {
        // §9.78 MSG-2 (K182 E0308 demanded-first): the message names
        // what the operation demands, never a generic hedge.
        let err = RuntimeError::TypeMismatch {
            context: "car operand",
            demanded: demanded::PAIR,
            got: "int",
            span: fix_span(),
        };
        assert_eq!(
            err.to_string(),
            "type mismatch: car operand must be a pair, got `int`"
        );
        assert_eq!(err.got_kind(), Some("int"));
        // The demanded vocabulary covers every raise family and every
        // constant renders into the message verbatim.
        for demanded_kind in [
            demanded::BOOL,
            demanded::PAIR,
            demanded::STRING,
            demanded::CALLABLE,
            demanded::SAME_KIND_NUMBER,
        ] {
            let rendered = RuntimeError::TypeMismatch {
                context: "probe",
                demanded: demanded_kind,
                got: "int",
                span: fix_span(),
            }
            .to_string();
            assert!(
                rendered.contains(demanded_kind),
                "demanded kind `{demanded_kind}` must appear: {rendered}"
            );
        }
    }

    #[test]
    fn unbound_global_and_unhandled_effect_name_their_payloads() {
        let unbound = RuntimeError::UnboundGlobal {
            name: Symbol::new("x").expect("fixture symbol"),
            span: fix_span(),
        };
        assert!(unbound.to_string().contains("unbound global `x`"));
        let unhandled = RuntimeError::UnhandledEffect {
            effect: Symbol::new("log").expect("fixture symbol"),
            span: fix_span(),
        };
        assert!(unhandled.to_string().contains("unhandled effect `log`"));
    }

    #[test]
    fn div_zero_and_overflow_use_short_forms() {
        assert!(
            RuntimeError::DivByZero { span: fix_span() }
                .to_string()
                .starts_with("division by zero")
        );
        let over = RuntimeError::ArithmeticOverflow {
            op: Opcode::Mul,
            span: fix_span(),
        };
        assert!(over.to_string().starts_with("mul overflow"));
    }

    #[test]
    fn budget_and_eof_display_their_limits() {
        let budget = RuntimeError::BudgetExceeded {
            budget: 4,
            span: fix_span(),
        };
        assert!(
            budget
                .to_string()
                .contains("allocation budget of `4` exhausted")
        );
        assert!(
            RuntimeError::Eof { span: fix_span() }
                .to_string()
                .starts_with("read-line: end of input")
        );
    }

    #[test]
    fn ret_from_entry_and_stack_underflow_carry_pcs() {
        let ret = RuntimeError::RetFromEntry {
            pc: 3,
            span: fix_span(),
        };
        assert!(ret.to_string().contains("ret from entry frame at pc `3`"));
        let under = RuntimeError::StackUnderflow {
            op: Opcode::PopHandler,
            pc: 7,
            span: fix_span(),
        };
        assert!(
            under
                .to_string()
                .contains("stack underflow at `pop-handler` pc `7`")
        );
    }

    #[test]
    fn eval_depth_display_names_its_limit() {
        let err = RuntimeError::EvalDepthExceeded {
            limit: 2048,
            span: fix_span(),
        };
        assert!(err.to_string().contains("eval depth of `2048` exceeded"));
        assert_eq!(err.span(), fix_span());
    }

    #[test]
    fn every_variant_starts_lowercase_without_trailing_period() {
        for err in every_variant() {
            let msg = err.to_string();
            let first = msg.chars().next().expect("non-empty message");
            assert!(
                first.is_lowercase(),
                "R8: message must start lowercase: {msg}"
            );
            assert!(!msg.ends_with('.'), "R8: no trailing period: {msg}");
            assert!(!msg.contains("#"), "§9.56 DIAG-1: no span fragment: {msg}");
        }
    }

    #[test]
    fn every_variant_preserves_its_resolved_span() {
        for err in every_variant() {
            assert_eq!(err.span(), fix_span(), "span survives construction: {err}");
        }
    }
}

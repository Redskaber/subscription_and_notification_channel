//! kerf-vm — bytecode virtual machine (Layer 6).
//!
//! Charter (docs/stage0.md §19.5): a switch-dispatch iterative main
//! loop over the 25-op set (§8.12 — the Stage 2.1 `load-captured`
//! addition included; `Opcode::ALL` is the pinned count), with
//! heap-allocated call frames —
//! kerf-level recursion consumes the frame vector, never the Rust
//! stack (the TD-023 anchor: iterative main loop + heap frame stack).
//! Runtime errors resolve their source span through the per-instruction
//! debug_info table (`kerf_compiler::Bytecode::span_of` — the §12.1
//! consumption row), so every [`RuntimeError`] carries a real source
//! location.
//!
//! Load-time contract (plan-0.5.md ruling 4, second line of defense):
//! [`Vm::new`] runs `kerf_compiler::Bytecode::verify` before seeding
//! globals — a corrupted product never reaches the interpreter. Stack
//! accesses still check depth explicitly at run time (§19.5 trap 2: "peek(n)
//! depth checks are not optional"), defense in depth over verify.
//!
//! The VM is a PERMANENT Rust base: rewriting it in kerf is
//! constitutionally excluded (docs/sop.md §21.12-22, R5).
//!
//! Status: structural scaffold created at Stage 0.0 (Task 2-c),
//! implemented at sub-stage 0.6 (TD-003 resolution step 2 of 4).

mod builtin;
mod error;
mod frame;
mod io;
mod observer;
mod roots;
mod value;
mod vm;

// Explicit re-export list (SOP §10.1 rule 4 — glob re-exports are forbidden).
pub use builtin::Builtin;
pub use builtin::{
    BuiltinHost, arith, builtin_symbol, car, cdr, compare, cons, dispatch_builtin, not, read_line,
    write_line,
};
pub use error::{
    RuntimeError, arity_mismatch_text, assign_to_captured_text, demanded, eof_text,
    extern_call_requires_backend_text, plural_args, type_mismatch_text, unbound_global_text,
    unhandled_effect_text,
};
pub use frame::{ContinuationSlot, DebugFrameSlot, ExceptionTableSlot, Frame, FrameExt};
pub use io::{BufferIo, VmIo};
pub use observer::VmObserver;
pub use roots::{Collector, Roots};
pub use value::{ClosureData, Heap, HeapObj, HeapRef, Value};
pub use vm::{DEFAULT_BUDGET, Vm};

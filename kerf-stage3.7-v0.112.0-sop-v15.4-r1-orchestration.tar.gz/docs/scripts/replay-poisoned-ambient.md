# replay-poisoned-ambient.sh — v0.73.0 工具链配对事件重放（r110）

## 定位

`scripts/testing/replay-poisoned-ambient.sh` 是第一百一十轮（v0.74.0）环境回归修复的第三面防护证明：在**被污染的 ambient 环境变量**下运行整个 c_backend e2e 套件，断言双边界 scrub（`tests/v1/stage1/plan/c_backend_e2e_tests.rs` 的 `cc_scrubbed`/`bin_scrubbed`）把污染物挡在链接与装载边界之外。

## 事件背景（v0.73.0 Nix dev-shell 事件）

impure Nix dev-shell 的 ambient 污染变量（`LIBRARY_PATH`/`CPATH` 族）可将 cc 产物的 ELF 解释器与 libc 拆配不同 glibc 构建——`__pointer_chk_guard@GLIBC_PRIVATE` 跨构建无解析契约 → 装载期死亡（exit 127），12 个 `c_backend_e2e_tests` 全灭而树本身健全。设计层记录：`docs/stage0.md` §9.105。

## 用法

```bash
bash scripts/testing/replay-poisoned-ambient.sh          # 默认跑 c_backend 过滤器
bash scripts/testing/replay-poisoned-ambient.sh -- --nocapture   # 追加 runner 参数
```

通过口径：`test result: ok. 18 passed; 0 failed; 2 ignored`（2 个 `#[ignore]` 为 heavy/measurement 门控位，非失败）。

## 范围（诚实边界）

ambient 毒化只覆盖**链接侧四变量**（`LIBRARY_PATH`/`CPATH`/`C_INCLUDE_PATH`/`CPLUS_INCLUDE_PATH`）——垃圾 libc 毒化全局 `LD_LIBRARY_PATH` 会杀死 runner 自身的动态装载。装载侧防护由套件内两面承载：scrub 注册面（`boundary_scrubs_register_the_full_contaminant_sets`）+ 毒物致死负控（`unscrubbed_boundaries_eat_the_poison_and_the_loader_abort_is_classified`）。

## 维护义务

- 新增链接侧污染物变量时：`LINK_CONTAMINANTS`/`RUN_CONTAMINANTS` 常量与脚本 env 列表**同步共变**（Face 1 注册面测试会自动覆盖新变量；脚本侧需手工同步）。
- c_backend 套件测试数变动时：脚本通过口径的 18:0:2 计数随之更新（脚本本身不 hard-code 计数——以 cargo test 退出码为准，此处的计数仅为文档口径）。

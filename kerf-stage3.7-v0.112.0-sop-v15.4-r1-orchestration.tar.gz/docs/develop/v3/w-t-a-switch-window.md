# W-T-A-SWITCH 生产位切换实施窗——K159 不动点管线与分段切换（w-t-a-switch-window.md）

> **Status**: CLOSED（v1.5——r149 step ⑤ 交付：**工作流宣告 + 窗口关闭**〔工作流实录语料 examples/workflow/{selfcheck,bench}.ktf——C4 面首个生产消费：编辑 .ktf → kerf run（四段孪生链生产位编译）→ VM 执行测试/基准标记；selfcheck 62 行 8 标记全 PASS + bench 47 行 fib(30)/list(10000)/sum_to(20000) 全对值〕+ 测试族七件（workflow_record_tests：正 2 / 负 3 / 回退带 1 / 跨段消费 1——语料驱动非内联夹具）+ audit BE 族 10 案（460→470 · 55→56 节）+ 守卫共变（TEST-3 入账 470）+ 测量三跑落档（tool-results/r149-workflow-run{1,2,3}——selfcheck 163-170ms / bench 953-964ms 全进程墙钟 @ v0.110.0）+ **C1-C4 验收对账全绿**（C1 ✓ r139 组成链 + C2 ✓ 四段生产位 + K159 B≡C + 工作流实录 + C3 ✓ r137 + C4 ✓ 本轮）+ **Rust 面清点表落档**（宪制排除项 + oracle 逐项——§7 新节）+ **W-SEXP-RETIRE 交棒就绪声明**（read 段生产位 r145 + TD-027 r143 双臂全满足）——出口条件 §4 四条全 ✓，窗口合法关闭；下一窗口 = W-SEXP-RETIRE（bootstrap-completion-plan §3 序 4）〕）；> **History**: v1.4——r148 step ④ 第四段交付：**compile 段生产位切换**〔编译孪生链 VM 臂为默认生产编译（compiler.ktf 经 items 注入槽 + co_limit 预算 define 装配，每进程一次链构造）+ Rust 编译器退役 oracle + **co_limit 预算镜像参数化**（ex_limit 先例——装配前缀 define + 自描述深度载荷，DepthExceeded 载荷携 depth+limit 双字段）+ **K163 第五实例双面 retarget**（重建错误面 with_span 穷举 + 产品 dbg span 面——真代际原样保留）+ **K163 第六实例当轮清偿**（items 流投递链四递归面迭代化：emit_litval_literal 编码器 + emit_litval 文本面 + dump_ktf_litval verdict 面 + dump_oracle_lit oracle 面 + inject_items_stream 迭代析构 helper × 12 注入位——60k 平坦引号默认栈实证；AST 字面量 Box-drop 胶水 ~150k 生产上界诚实登记：双臂共享 oracle 域先存边界，W-REC-DEPTH 堆化后续）+ **孪生三潜在缺陷当轮清偿**（cp_ewalk 错误臂 bool 契约〔烘焙 1024 期从未触达的 post-error 返回值破坏〕+ extern 重复名全局索引〔块内→跨块 oracle 语义对齐〕+ 重建 verify 地板两法官显式化〔§6e 盲面产品经 verify 拒绝映射为程序级 CompileError——与 oracle 同族同消息〕）+ 测量先行三跑落档（compile 段 K140 切片带 1.2-1.7× / spine 1.3-1.5×——四段最优）+ 回退带 KERF_COMPILE_SEGMENT + 测试族十二件 + audit BD 族（450→460 · 54→55 节）——本窗最后一段，step ④ 四段全 ✓〕；v1.3——r147 step ④ 第三段交付：**check 段生产位切换**〔双检查孪生链 VM 臂为默认生产检查〔保守检查器 typecheck.ktf + HM 推断引擎 infer.ktf——oracle 脊柱自身收集序〕+ 诊断结构化重建面〔cdiag/tdiag verdict 记录 → TypeDiagnostic：code 注册表查表 + message 模板表单源渲染 + subjects intern + span 会话 file 重靶/ROOT generation——诊断轴 span 源代际 vs oracle 位宏展开真代际的诚实边界登记〕+ 回退带 `KERF_CHECK_SEGMENT` + K163 第四实例清偿〔twin 重建树 span file_id 恒 0——r145/r146 零 id 域验证盲区；retarget_forms/retarget_items/retarget_expr 全变体穷尽 walk + BC05/BC10 钉扎〕+ harness 自检钉位裁定〔drive_dual_engines/drive_full_face 检查步钉 Rust——P0 回归修复：46KB 链工件解释态 HM ≈ 49s/件，corpus sweep 61→5 分钟〕+ 测量先行三跑落档〕；v1.2——r146 step ④ 第二段交付：**expand 段生产位切换**〔孪生展开链 VM 臂为默认生产展开 + Rust 展开器退役 oracle + 回退带 `KERF_EXPAND_SEGMENT` + 预算镜像 `ex_limit` 参数化〔expander.ktf 孪生源 512 烘焙 → 装配前缀 + depth 载荷携 limit——自描述拒绝〕+ 测量先行三跑落档 + K163 同族全量〔forms_stream_literal 右脊 Box-drop——dispose 共享化 × 全注入位迭代析构〕〕；v1.1——r145 step ④ 首段交付：**read 段生产位切换**〔孪生链 VM 臂为默认生产读 + Rust 目标读器退役 oracle + 回退带 `KERF_READ_SEGMENT` + 测量先行三跑落档 + K163 第二实例三同族缺陷清偿〕；v1.0——r144 开工首刀交付：**step ② A/B/C 工件管线 + step ③ 不动点门全链交付**〔CCF 链可编译形制裁定 + A/B/C 三轮驱动 + **B ≡ C 位级六工件全过** + A ≡ B parity 观察行——K159 不动点门首证；四项前置缺陷清偿：infer 孪生结构 join / env 截断反转 / Tarjan 边表降序 + items_stream_literal generation 编码分裂——语料从未命中的四缺口由 CCF 新输入域首次暴露〕；r143 开窗对账 = step ① 种子链固化已落档〔bootstrap-completion-plan v1.8 §4.3〕）
> **流程权威**: docs/sop.md v15.3（§21.12-28 自举完备优先 / §13.1 设计对齐 / §14.6.4 规则 5 测量先行 / §19.3 打包前测试先行）
> **依据**: bootstrap-completion-plan.md v1.9 §4.3 + §5（五步单源）；stage0.md §9.121.1（K159 锚：不动点是验证门非构建步骤、链条定长工件显式、验收含「仅种子工件 + 干净树全链重建同位」）；§9.113（K140-K142 自举先例族）；w3.12-frontend-window v5.0（T-a/T-b 触发器定义）
> **职责边界**: 本文档承载 **T-a 切换窗的窗内裁定、刀级排期、CCF 形制单源、出口条件与守卫义务**；全局窗序与完成标准 = bootstrap-completion-plan.md（本文只引用）；K140 性能带的组合面重审 = step ⑤ 验收带（本窗 §5）。
> **宪制排除项**: VM 永久 Rust 基座 / 构建引导层（cargo）/ 链外后端（C/LLVM/QBE）——永不入自举链（§21.12-28③）。

## 1. 开窗时点实态（r143 闭合态代码事实）

- 前置全凑齐：G1 ✓（目标读链三刀 r136/r138/r139）+ G2 ✓（任意递归深度 r136/r137）+ G3 裁决完成（W-JIT-METHOD-T1 CLOSED @ r142）+ TD-027 ✓（expander.ktf match 臂 r143）→ **开窗合法成立**（bootstrap-completion-plan v1.8 §4.3）。
- K159 五步：step ① 种子链固化 ✓ 落档（宪制排除项四项 + 种子工件五类）；step ② A/B/C 工件管线 = 本窗首刀；step ③ 不动点门 = step ② 的验证面（同轮交付）；step ④ 分段生产位切换（read → expand → check → compile 逐段）；step ⑤ 工作流宣告（C1/C2 验收 + K140 带如实登记）。
- 生产链各段稳态形在位：SteadyTargetReaderChain（r139）/ SteadyExpanderChain（r122）/ SteadyCheckChain + SteadyTypecheckChain（r127-r131）——但**编译段无稳态形**（唯装配烘焙路线 ktf_compile_rich——fixpoint 自用形）；且**无任何孪生链曾处理过链自身程序**（孪生源带自由槽引用——展开层 unbound 拒绝；selfhost 九源组成链测试的诚实边界披露：「依赖孪生在展开层以同键拒绝」）。

## 2. 窗内裁定 TA-1..TA-7（ARCH-A；TA-5 @ r145 首段轮；TA-6 @ r146 第二段轮；TA-7 @ r147 第三段轮）

**TA-1 CCF 链可编译形制（chain-compilable form）——本窗核心裁定**：链自身程序的可编译形 = **extern 槽声明 + 孪生源原样**：

```text
extern "C" { fn source_bytes() -> int; }   // 槽契约声明（语言内）
<孪生源原样——其 source_bytes 引用现按外部名解析>
```

- 六件 CCF：ccf-lexer（source_bytes）/ ccf-parser（tp_tokens + tp_forms + tp_limit 前缀）/ ccf-expander（forms + MX-2 装配体）/ ccf-infer（items）/ ccf-check（items）/ ccf-compiler（items）。
- 语义链：展开器 extern_names 预播种接受（W-3.2 bind-first）→ 检查器 R1 externals 表接受 → HM 以**声明契约箭头**类型化裸引用（oracle infer 步骤 2.5——`car(槽)` 正面撞契约箭头为 E0009；孪生自身用法 = 槽作函数实参，参数吸收箭头 ✓）→ 编译器 load-global 发射 → 产品携带惰性契约记录（零代码——W-3.2 先例）→ 注入通道运行时绑定（值路径永不激活 FFI 调用语义）。
- 否决形制：(a) 裸孪生源——展开层 unbound 拒绝（实证：selfhost 组成链测试披露 + r144 AZ03 钉扎）；(b) 前缀 define 绑槽——程序侧 define 运行时覆写注入槽（稳态链纪律违例）；(c) 宿主级注入面（parse_target_with_injected）——A 形态同侪保留（生产构造面），但**链不可自处理**（自举链的查/展段无法消费宿主标志——K159「链编链」的结构性缺口即本裁定所补）。
- 皮肤映射：目标皮肤下划线拼写（`source_bytes`）经 Rule K 规范化为规范身份（`source-bytes`）——extern 名与引用同一规范化（AZ05 钉扎）；C 符号地板：连字符→下划线推导合法、无碰撞（AZ04）。

**TA-2 A/B/C 三轮与工件**（K159 §5 单源的操作化）：

- **A 轮**：Rust 编译器以**普通生产管线**编译六 CCF（闭程序——extern 声明使其无需注入面）→ A 工件。
- **B 轮**：链（骑 A 工件、VM 臂、注入通道）逐 CCF：读段（读链孪生）→ 展段（展开孪生 + 树同一性门 vs oracle items）→ 查段（双检查孪生 vs oracle 双轴）→ 编段（**SteadyCompilerChain——本窗新建**：编译孪生经 `items` 注入通道消费，稳态形补齐）→ 重建产品 = B 工件。
- **C 轮**：同一链形骑 **B 工件**（链自身的编译物作为链段）再编译六 CCF → C 工件。
- **门**：B ≡ C **位级**（六工件 Bytecode PartialEq 全描述符表）；A ≡ B = parity 观察行（披露非门——gate B 使然恒真，r144 实测亦真）。
- 段运行器为 VM 臂专用（生产引擎）：双引擎纪律留在既有 sweep 族（稳态链/组成链/fixpoint）——本管线关于**工件与门**，不重复引擎 parity 面。

**TA-3 四项前置缺陷清偿（CCF 新输入域首次暴露——语料从未命中）**：

| # | 缺陷 | 根因 | 清偿 |
|---|---|---|---|
| 1 | infer 孪生 join 恒 dyn | `ti_join` 用 `eq` 内建比较复合类型记录——`eq` 对 pair 是 **Rc 指针身份**非结构相等；复合分支 tif 全部 join 成 dyn（oracle 用 Rust `Type: PartialEq` 结构相等） | `ti_type_eq(mode, a, b)` 单分派器结构相等（`ti_occurs_walk` 先例形制——letrec 顶层规则下互递归不可双子声明） |
| 2 | let 后外层绑定渲染 dyn | `ti_env_truncate` 用 `ti_take_n`（头推表保留**最新** mark 条目）——丢弃最旧 k 条（= 前几个参数）；oracle `Vec::truncate(mark)` 保留最旧 | `ti_drop(env, len - mark)`（保留最旧 mark 条目——Rust truncate 镜像） |
| 3 | 密集图 var 索引交换 | `ti_one_edge_row` 末尾 `ti_rev` 使边表**降序**——Tarjan DFS 邻居访问序反 → SCC 发射序反 → 预变量分配序互换；oracle 边表升序 | 去掉反转（升序——oracle 构造序） |
| 4 | 编译段产品 dbg 记录重建拒绝 | `items_stream_literal` 的尾随 generation 编码为**字符串**（CP-1 文本 grammar 是 INT）；编译孪生将输入 generation 逐字透传产品 dbg span 记录 → 重建面 `as_i64` 拒绝 `Str("0")` | 统一为 INT（检查器孪生对该字段不透明透传——零影响实证） |

- 语料盲区根因（四缺口共性）：检查器 sweep 族语料 = curated 62+ 案——(1) 无复合类型等值分支 tif；(2) let 均尾表达式形（let 后无外层绑定引用）；(3) 调用图浅（单 DFS 发现）；(4) 编译段唯一投递面 = 装配文本路线（INT 编码）。「链编链」的 CCF 输入（块体 + 密集图 + 注入投递）四缺口齐触——**新输入域即新审计域**（§9.5 覆盖率纪律的输入面论证）。

**TA-4 SteadyCompilerChain 编译段稳态形**：编译孪生以 `items` 注入槽消费（parse_target_with_injected 构造 + compile_via 运行）——与装配烘焙路线（ktf_compile_rich）**同孪生双投递面**；AZ06 钉扎双路产品位级等价（小输入实证 + 全尺度 A≡B 行承载）。fixpoint 自身形制不变（装配前缀自包含——r139 纯度腿沿袭）。

**TA-5 read 段生产位切换形制（r145 首段轮）**：

- **生产位**：`parse_with(ReaderFace::Target)` 默认经稳态孪生链 VM 单臂读（`SteadyTargetReaderChain::read_production`——MJ-5 生产引擎裁定；双引擎 agreement 留验证面 `read_dual`）；链按 nesting 帽键控逐线程缓存（`tp_limit` 必镜像进程帽——帽覆写双位同键拒绝的回退带 parity 义务）。
- **种子/生产双链解耦（§21.12-28② 驱动内落位）**：种子面钉 Rust——`read_target_source_for_bootstrap`（fixpoint 纯度腿 oracle 臂）+ `rust_compile_ccf`（A 轮种子身份）；`parse_target_with_injected` 结构性种子面（链构造自身入口——生产位读在此 = 循环）。**比较面坍缩防护**：种子钉以源扫描守卫机检（比较面若经生产位则 twin==twin 检测力零——r144 门检测力先例）。
- **回退带（§14.6.4 规则 5）**：`KERF_READ_SEGMENT` 三态（twin 默认 / rust 显式 / 非法 = 硬错误 fail-closed——DepthLimits 先例）；缺陷大声失败（driver_error 诊断——绝不静默回落，§2.3-4）。测量先行：链构造 ~30ms 一次 + 每读 twin vs Rust 中位数三跑落档（curated-small ≈ 970× / 60KB ≈ 570× / spine ≈ 240-460×——K140 段级切片带，与全链 ~339× 同序；收窄后置 W-3.8）。
- **span 重靶**：孪生重建 ReadError 的 span 携 FileId(0)（parity harness 惯例）——生产读重映射至会话真实 FileId（六 span 变体；否则诊断渲染错档）。

**TA-6 expand 段生产位切换形制（r146 第二段轮——TA-5 形制沿袭到展开段）**：

- **生产位**：`parse_with(ReaderFace::Target)` 的展开+加载步默认经稳态展开孪生链 VM 单臂（`SteadyExpanderChain::expand_production`——decode_verdict 结构化 `ParityError` 面；双引擎 agreement 留验证面 `expand_dual`）。**junction-2 纪律**：孪生裁决覆盖展开与加载两拒绝面（ParityError::Expand | Module——生产位不再跑 Rust loader；twin 即加载面）。链按 expansion 预算键控逐线程缓存。
- **预算镜像（tp_limit 先例）**：expander.ktf 孪生源原 512 烘焙（`ex_depth >= 512`）→ 参数化 `ex_limit` 全局（装配前缀 `define(ex_limit, N);` + depth 载荷携 limit〔自描述拒绝——decode 位置无关预算无关〕+ reconstruct_expand_error depth 臂从载荷读限）——进程有效 `KERF_EXPANSION_LIMIT` 双位同键拒绝（回退带 parity 义务）。
- **种子/生产双链解耦**：种子面钉 Rust expand——`parse_target_with_injected`（链构造自身入口：孪生链的编译经此展开，生产位在此 = 循环）+ `read_target_source_for_bootstrap`（fixpoint 纯度腿 oracle 臂）+ `rust_compile_ccf`（A 轮种子身份）——三面 `Session::with_segments(Rust, Rust)`；比较面坍缩防护 = 源扫描守卫机检（read 段 r145 同形）。Sexpr 面结构性 Rust（W-SEXP-RETIRE 域）。
- **回退带（§14.6.4 规则 5）**：`KERF_EXPAND_SEGMENT` 三态（twin 默认 / rust 显式 / 非法 fail-closed）；缺陷大声失败（driver_error——绝不静默回落）。测量先行：链构造一次 + 每展开 twin vs Rust 中位数三跑落档 + spine 切片（expand_segment_profile——K140 段级切片带追加）。
- **span 重靶**：ExpandError/ModuleError 全 span 变体重映射至会话 FileId（`with_span` 穷举 match——新变体编译期失败，表随源长 FIX-16 纪律）。
- **K163 同族全量（§20 同类路径——r146 第三实例 + 预防位）**：①`rebuild_lit` 右脊递归（展开段解码面——determinism 守卫的 assembled-expander 主题〔前缀表 ~2 万记录右脊〕在生产位 twin 展开解码逐记录递归 → 默认栈溢出实证；1GB 栈复跑定位深度型；清偿 = 右脊迭代行走〔脊柱步 = 记录 cdr 载荷非堆链；car 递归 = 读帽所界〕——`Value::from_literal` r145 先例形制；determinism 守卫 = 回归钉扎）；②forms_stream_literal 右脊 Box-drop 胶水（验证面 768MB 深栈掩蔽同形）——`dispose_literal_iteratively` 升共享（pub(crate)）× 全注入位（expand / expand_dual / expand_production / abc expand_via）迭代析构 + BB10 默认栈回归钉扎（CCF 形式 60KB 全展开）。

**TA-7 check 段生产位切换形制（r147 第三段轮——TA-5/TA-6 形制沿袭到检查段 + 本段特有两裁定）**：

- **生产位**：`ParsedProgram::typecheck` 的 twin 臂 = 双检查孪生链 VM 单臂（`production_check`——先保守检查器后推断引擎，oracle 脊柱自身收集序；双引擎 agreement 留验证面 check_dual/infer_dual）。双链逐线程缓存无键控（检查段无预算覆写面——推断深度预算双侧烘焙 512，与 tp_limit/ex_limit 的环境覆写面不同）。注入面程序抵达 twin 臂 = 大声 wiring 缺陷（检查孪生链构造自身经注入面——比较面差分性坍缩防护）。S-expr 面结构性 Rust（W-SEXP-RETIRE 域）。
- **诊断结构化重建面（本段独有新面）**：read/expand 段重建拒绝，check 段重建发现——verdict 的 cdiag/tdiag 记录解码为 `TypeDiagnostic`（code 经 `TypeCode::from_registry_str` 注册表逆映射〔kerf-typecheck 单源新增〕；message 经 oracle 自有模板表渲染〔R8 单源字典 pub(crate) 化——parity sweep 逐行交叉核验的同一表，非新译面〕；subjects 经 intern〔r109 F2〕；span = 会话 file 重靶 + ROOT generation）。**诚实边界**：oracle 位宏展开发现的 span 携真 expansion generation，twin 位重建恒 ROOT——五字段 parity 契约（code/severity/offsets/message/subjects-in-message）与一切现行渲染面均 generation-盲，故比较恒在契约字段；孪生侧 generation 发射的若需归 W-3.9 诊断增强窗。
- **harness 自检钉位裁定（r147 新裁定——P0 回归的架构清偿）**：差分 harness 宿主（`drive_dual_engines`/`drive_full_face`）的自检检查步钉 Rust——assembled 程序是链工件（items 前缀 + 孪生源）非用户程序，其检查结论仅喂 harness「必须干净」断言，twin 位零验证增值而解释态 HM 成本灾难（46KB 工件 ≈ 49s/件）；read/expand 步保持生产位（r145/r146 先例的免费输入域覆盖，毫秒级）。种子面三段全钉（`parse_target_with_injected`/`read_target_source_for_bootstrap`/`rust_compile_ccf` = `with_segments(Rust, Rust, Rust)`）。
- **回退带（§14.6.4 规则 5）**：`KERF_CHECK_SEGMENT` 三态（twin 默认 / rust 显式 / 非法 fail-closed）；缺陷大声失败（driver_error——绝不静默回落）。测量先行：双链构造 ~22ms 一次 + 每检查 twin vs Rust 中位数三跑落档（curated 1.4-1.5× / check-twin-CCF 3.8× / infer-twin-CCF 23×〔HM 解释态最重负载——生产位合法成本形态〕）+ spine 三段切片（1.4-4.0×）。
- **预算镜像审查（零改动裁定）**：推断深度预算双侧烘焙 512 且无环境面——同键义务构造性成立；E0011 生产管线结构性不可达（展开帽 512 先拦，520 深探针实证双位同拒于展开层）——镜像义务空真成立，登记于测试族文档。
- **K163 第四实例（当轮清偿）**：twin 重建树（forms + items）span 的 file_id 恒 FileId(0)——parity harness 惯例域；r145/r146 切换 sweep 恰在零 id 域验证故树面从未重靶，非零 id 会话首入即暴露（诊断 file 归属错档）。§20 同类路径全量：read 段 `retarget_forms`（StxDatum::List 递归）+ expand 段 `retarget_items`/`retarget_expr`（全变体穷尽 match——FIX-16）+ BC05/BC10/测试族非零 id 案例回归钉扎。

**TA-8 compile 段生产位切换形制（r148 第四段轮——TA-5/6/7 形制沿袭到编译段 + 本段特有四裁定）**：

- **生产位**：`ParsedProgram::compile_bytecode`（check/c_source/run 的 VM 臂/run_parity 四消费面的单一入口）的 twin 臂 = 稳态编译孪生链 VM 单臂（`SteadyCompilerChain::compile_production`——fresh VM + items 注入 + verdict 重建；回退带 `KERF_COMPILE_SEGMENT` 三态，twin 默认 / rust 显式 / 非法 fail-closed）。注入面程序抵达 twin 臂 = 大声 wiring 缺陷（种子面四段全钉）。S-expr 面结构性 Rust（W-SEXP-RETIRE 域）。
- **预算镜像（ex_limit/tp_limit 先例——本段与 check 段不同形：Rust 侧有 `KERF_COMPILE_DEPTH_LIMIT` 环境覆写面）**：compiler.ktf 深度检查 `cp_depth > co_limit` 引用装配前缀 `define(co_limit, N);` 全局；孪生深度记录 `("err" "depth" D L s e)` 载荷携首超深度 D=co_limit+1 与生效限值 L 双字段；Rust `DepthExceeded{depth, limit}` 载荷扩 limit 字段（Display 从载荷渲染——覆写下自描述，双臂同键同消息）；链按 co_limit 键控逐线程缓存。孪生硬依赖 co_limit（缺 define = 展开层 unbound 大声拒绝——fail-closed）。
- **K163 第五实例（编译半面——r147 第四实例族的编译段延续）**：双重建面（错误面 make_span + 产品面 rebuild_span）派生 span 均 FileId(0)（parity 惯例域）——生产位错误面经 `CompileError::with_span`（全变体穷举 FIX-16）重靶会话 file；产品面全部 proto 的 dbg span 重靶（真代际原样保留——运行时错误渲染对档）。
- **K163 第六实例（当轮发现当轮清偿——60k 平坦引号实证）**：items 流投递链四递归面（emit_litval_literal 编码器 / emit_litval 文本前缀面 / dump_ktf_litval verdict 文本面 / dump_oracle_lit oracle 文本面）右脊递归 → 全部迭代化（rebuild_lit/from_literal 先例形制）+ `inject_items_stream` 共享注入 helper（迭代析构 × 全 12 注入位——r146 forms 流清偿的 items 流补全）。诚实边界：AST 字面量自身 Box-drop 胶水 ~150k 元素生产主线程实测上界（双臂共享——oracle 域先存边界；W-REC-DEPTH 堆化后续，不属本窗）。
- **孪生三潜在缺陷当轮清偿（新输入域即新审计域的编译段兑现）**：①`cp_ewalk` 错误臂返回值破坏 bool 契约（裸 set 返回 nil → cfwalk `if term` 崩溃于 nil 条件——烘焙 1024 期生产从未触达错误路径故隐性；修复 = 错误臂 `do(set(...), false)` + 顶层 post-error 短路 else false）②extern 重复名索引语义分歧（孪生报块内索引 vs oracle 报跨块全局表索引——CLI parity 测试暴露；修复 = cp_extern_n 全局计数器）③§6e 字符警察盲面（零字符内建 → 孪生结构性不可表达）经重建 verify 地板两法官显式化清偿（rebuild_bytecode_unverified + 生产臂自跑 verify → 程序级 CompileError——与 oracle 编译期警察同族同消息；fail-closed 非静默）。
- **harness 编译步结构性钉位（r147 检查步钉位裁定的编译段延续）**：drive_dual_engines/drive_full_face 的自检编译步直调 `compile_program`（结构性 Rust，无需环境面）——装配程序是链工件，其编译产物仅喂 harness「必须可跑」断言，twin 位零验证增值。

## 3. 切轮排期（MUV 边界——禁止降级交付）

| MUV | 内容 | 集成验证 |
|---|---|---|
| r144 ✓（step ②+③ @ v0.105.0） | CCF 装配 + SteadyCompilerChain + from 段运行器 + abc_pipeline 三轮 + B≡C 门 + 四缺陷清偿 + 测试族六件 + AZ 族 10 案 | **K159 门六工件位级**（golden 测试 ~325s release）+ A≡B 观察行 + 树同一性 + 查微分全过 + 负例四（承重/fail-closed/检测力/同键）+ 跨段消费（B 工件作链段实跑） |
| r145 ✓（step ④ read 段 @ v0.106.0） | 生产读默认翻转孪生链 VM 臂 + 种子面钉 Rust（双链解耦）+ 回退带 + 测量先行三跑 + K163 三同族清偿（pair_cells/from_literal/Box-drop）+ 测试族十件 + BA 族 10 案 | 全树 Target 面测试默认翻转即生产位全语料 sweep（runner 717 分块全绿）+ 双位 forms/拒绝/渲染位级一致 + 回退带三态 + CLI 端到端 + 栈平回归（60KB 默认栈）|
| r146 ✓（step ④ expand 段 @ v0.107.0） | 生产展开默认翻转孪生链 VM 臂（junction-2：孪生裁决覆盖展开+加载）+ 预算镜像 ex_limit 参数化（tp_limit 先例）+ 种子面钉 Rust 三面（双链解耦）+ 回退带 + 测量先行三跑 + K163 同族全量（forms_stream 右脊 dispose 共享化×全注入位）+ 测试族十件 + BB 族 10 案 | 全树 Target 面测试默认翻转即生产位全语料 sweep（分块全绿）+ 双位 items/拒绝/渲染位级一致 + junction-2 模块面同键 + 预算覆写双位同键 + 回退带三态 + CLI 端到端 + 栈平回归（60KB 默认栈全展开）|
| r147 ✓（step ④ check 段 @ v0.108.0） | 生产检查默认翻转双检查孪生链 VM 臂（保守检查器 + HM 推断引擎——oracle 脊柱收集序）+ 诊断结构化重建面（cdiag/tdiag → TypeDiagnostic：code 注册表查表 + message 模板表单源 + subjects intern + span file 重靶/ROOT gen 诚实边界）+ 种子面三段全钉 + harness 自检钉位（drive_dual_engines/drive_full_face）+ 回退带 + 测量先行三跑 + K163 第四实例清偿（retarget_forms/retarget_items 全变体穷尽）+ 测试族十一件 + BC 族 10 案 | 全树默认翻转即生产位全语料 sweep + 双位发现五字段位级一致（含非零 file id）+ 渲染批位级一致 + E0011 结构性不可达披露 + 回退带三态 + CLI 端到端 + 跨段消费（字节码位级 + run 值一致）|
| r148 ✓（step ④ compile 段 @ v0.109.0） | 生产编译默认翻转编译孪生链 VM 臂 + co_limit 预算镜像参数化（自描述深度载荷）+ 种子面四段全钉 + 回退带 + 测量先行三跑 + K163 第五实例双面 retarget + 第六实例投递链四递归面迭代化清偿 + 孪生三潜在缺陷当轮清偿（bool 契约/全局索引/verify 两法官）+ 测试族十二件 + BD 族 10 案 | 全树默认翻转即生产位全语料 sweep（字节码位级双臂一致）+ 深度预算双位同键 + extern 重复名全局索引 parity + 非零 file id 产品/错误双 retarget + 回退带三态 + CLI 端到端 + 60k 平坦引号生产栈预算回归 |
| r149 ✓（step ⑤ 宣告 + 关窗 @ v0.110.0） | 工作流实录语料（selfcheck 62 行 + bench 47 行——C4 首个生产消费）+ 测试族七件 + audit BE 族 10 案 + 守卫共变（TEST-3 470）+ 测量三跑（selfcheck 163-170ms / bench 953-964ms 全进程）+ C1-C4 对账 + Rust 面清点表（§7）+ W-SEXP-RETIRE 交棒声明 | C1-C4 判据对账全绿 + 出口条件 §4 四条全 ✓ + 单皮肤前置就绪声明（W-SEXP-RETIRE 交棒） |
| 窗口 CLOSED @ r149（出口四条全 ✓——§4 逐条勾销） | — | — |

## 4. 出口条件（窗口关闭判据）——**r149 全 ✓ 关窗**

1. ✓ step ④ 四段生产位切换完成：**read ✓（r145）+ expand ✓（r146）+ check ✓（r147）+ compile ✓（r148）**——四段全绿，oracle 各段退役为种子/验证面。
2. ✓ step ⑤ C1/C2 验收 + K140 带登记（达成路径诚实化：链内最优形态已锁定〔r142 实测〕，10× 内达成依赖稳态摊销 × A/B/C 实测 ×〔可选〕W-3.8 链外加速；**不预设达标时点**——时间治理红线一）。read/expand/check 三段切片带在档（r145/r146/r147 三跑）；compile 段切片带 r148 落档（1.2-1.7×——四段最优）；**工作流全进程带 r149 落档（selfcheck 163-170ms / bench 953-964ms——四段 + 链构造 + VM 执行全包）。**
3. ✓ 工作流经 kerf 自身实录落档（编辑 .ktf → kerf 编译 → 测试/基准经 VM——C4 面首个生产消费；r149：selfcheck 8 标记 + bench 3 相位全对值 + CLI e2e + 三跑）。
4. ✓ W-SEXP-RETIRE 交棒就绪（read 段生产位 ✓ 已达成〔r145〕+ TD-027 ✓〔r143〕——拆除权双臂全满足；W-SEXP-RETIRE 开窗序位 = T-a 窗关闭后首位〔bootstrap-plan §3 序 4〕——r149 交棒成立）。

## 5. 守卫义务（每轮）

- 新族再生成：read_segment_switch_tests 十件随段切换扩展（expand 段族 r146 落位 + check 段族 r147 落位 + compile 段族 r148 落位——compile_segment_switch_tests 十二件 + **workflow_record_tests 七件 r149 落位**）；audit 族随新面共变（BC 族 r147 + BD 族 r148 + **BE 族 r149 落位**——§7.3.1 规则 4 单调增长；守卫 TEST-3 同步 470）。
- 每轮复核：①本窗未解决问题数（>0 禁止推进）②通解性（read/expand/check 段切换 = 机制面〔全 .ktf 生产读/展开/检查通用〕；回退带 = 通用环境面；帽/预算键控链缓存 = 机制非位点特化；harness 自检钉位 = 面类别裁定〔链工件 vs 用户程序〕非位点特化）③C1-C4 进度对账 ④K140 带口径维持（三跑落档 + 段级切片带追加）。
- 转化台账同步：孪生行数变更即刷新（r145：零新转化面；r146：expander.ktf +3 行〔2,227→2,230〕；r147：零新转化面——检查孪生 r127/r131 在账，位切换非新转化）。
- 测量面：每段切换前必跑段级 profile 三跑（read/expand/check 三段在档——§14.6.4 规则 5；compile 段 = compile_segment_profile 待）。

## 6. 知识锚（沿袭 + 本窗新增）

- K159（生产位切换 = 种子→全量→自重建不动点；不动点是验证门非构建步骤；链条定长工件显式）——本窗全量兑现。
- K140（Go 1.5 自举切换 ~10× 回退实证）——step ⑤ 验收带；read 段切片带 r145 落档；expand 段切片带 r146 落档；check 段切片带 r147 落档（1.4-23× 段内、1.4-4.0× spine——三段中收窄）。
- **K163（r144 新增：新输入域即新审计域）**——验证面的盲区由输入域决定：sweep 族的「全绿」只对已见输入形状有效；「链编链」的自指输入（块体 let + 密集调用图 + 注入投递编译段）一次性暴露四项 10 轮未现缺陷。推论：自举每进入一新输入域，审计集必须先扩展到该域的形状空间（§9.4.3 易错分布全覆盖的输入面论证义务）。**r145 即轮兑现（第二实例）；r146 预防位兑现（第三实例前置于暴露前）；r147 第四实例当轮清偿（twin 重建树 span file_id 恒 0）+ P0 性能回归同律（harness 自检钉位清偿）；r148 双实例兑现：第五实例（编译段双重建面 span file_id 恒 0——错误面 + 产品 dbg 面双 retarget，真代际保留）+ 第六实例（items 流投递链右脊递归四面——编码器/文本前缀/verdict 文本/oracle 文本全迭代化 + 迭代析构 helper × 12 注入位；60k 平坦引号默认栈实证，oracle 全 Rust 位同输入通过作为对照基线；孪生三潜在缺陷同律当轮清偿：bool 契约/全局索引/verify 两法官——生产位新输入域一次暴露三个 4 轮未现缺陷）。**

## 7. Rust 面清点表（r149 关窗轮——C4 验收组成件：语言自我推进后的 Rust 面收敛清单）

C4 判据法定形态：「Rust 面收敛为宪制排除项 + oracle 验证面」。逐项清点（自举链生产位四段全切后 Rust 代码的合法存续角色）：

| # | Rust 面 | 角色 | 宪制定位 |
|---|---|---|---|
| 1 | kerf-vm（VM 执行核心 + 激活栈 + superinstr/LLC + methodjit 资产） | 生产执行基座 | **宪制排除项**（VM 永久 Rust 基座——原则 53；「完全自举」VM 重写 = 排除项，永不入自举链） |
| 2 | cargo / rustc / Cargo Workspace（构建引导层） | 构建编排 | **宪制排除项**（r90 裁定——m2 x.py 先例：构建编排是链构造器非链成员） |
| 3 | kerf-cbackend（C 转译后端） | 链外后端 | **宪制排除项**（LLVM/本地码后端永不入自举链——§21.12-28③） |
| 4 | Rust 读/展/查/编四段本体（kerf-reader 目标面 / kerf-expander / kerf-typecheck / kerf-compiler） | **oracle 验证面**（parity 比较臂 + 种子链自检 + 回退带四键） | 退役非删除（E5 同构先例——验证面保留） |
| 5 | 孪生装配/注入通道/稳态链宿主胶水（steady_*_chain.rs / segment 选择器 / rebuild_* 族） | 链宿主桥（K20 分工：桥驻宿主、语义驻 .ktf） | 合法宿主面（桥非语义——selfhost README 宿主约定） |
| 6 | Rust S-expr 读链（kerf-reader S-expr 面）+ .krf 皮肤 + reader/lexer.ktf 孪生 + 转码器 | S-expr 脚手架 | **W-SEXP-RETIRE 拆除对象**（下一窗口——非宪制排除项；用户指令⑥终态 = 全目标语言单皮肤） |
| 7 | eval 元循环求值器 | 测试/双引擎 parity 面 | W-EVAL-RETIRE 触发器已达（T-a 关闭）——退役排期 |
| 8 | kerf-pkg（包管理器） | 构建引导层侧基础设施 | W-PKG-SELFHOST 按 §7 裁定行权（K161 解耦） |
| 9 | 测试/审计/守卫基建（runner 族 + audit + guard + harness） | 验证基础设施 | 合法宿主面（验证面永不要求自举——SOP §9.5 纪律） |
| 10 | 工具链侧（scripts/ + tools/ + tool-results/） | 宿主侧度量与导航 | 合法宿主面（永不入 Cargo 依赖/语言管线） |

**清点结论**：生产链（.ktf → 读〔target-lexer/parser.ktf〕→ 展〔expander.ktf〕→ 查〔infer+typecheck.ktf〕→ 编〔compiler.ktf〕→ 字节码 → VM）已无任何 Rust 语义段参与——Rust 面收敛为：宪制排除项三类（#1/#2/#3）+ oracle 验证面（#4）+ 桥/验证/工具合法宿主面（#5/#9/#10）+ 拆除排期面（#6/#7/#8）。C4 判据「Rust 面收敛为宪制排除项 + oracle 验证面」= **达成**（拆除排期面为后续窗口工作对象非存续承诺）。

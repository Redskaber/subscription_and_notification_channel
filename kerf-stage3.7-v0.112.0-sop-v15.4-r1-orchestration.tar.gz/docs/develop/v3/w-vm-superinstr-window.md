# W-VM-SUPERINSTR 超级指令融合实施窗——CallGlobal 首刀、F1 直发算术与窗口收口（w-vm-superinstr-window.md）

> **Status**: CLOSED（v1.2——r134 次刀关闭轮终态：F1 直发算术全链落地 + 复画像出册 + 三触发器判定 + 裁定 = 窗口关闭/W-JIT-METHOD-T1 开窗；v1.1 = r134 形态裁定 FA-1..FA-6；v1.0 = r133 首刀〔CallGlobal 融合 + 守卫再生成 + B 轴 0.87× 中间账〕；上游裁定 = w3.7-jit-window.md §4.3-1〔r132 评估窗产物〕）
> **流程权威**: docs/sop.md（§21.7 风险表 / §12 最优>最小 / §2.3-3 猜测或 hack 禁止 / §18 零新依赖〔本窗零新 Cargo 依赖——纯基座内实施〕/ §4 MUV 边界切轮纪律〔r126 排期先例——禁止降级交付〕/ §21.12-28 自举完备优先纪律〔T-a 生产位切换链路第一刀前置〕）
> **依据**: w3.7-jit-window.md v1.0 全档（§2b 画像四表 = 对选择物质基础 + §3 K150-K156 七锚 + §4.3 裁定三段 + §6 守卫族清册）；stage-3-plan.md v2.8 §2.3/§2.5（W-VM-SUPERINSTR 行——r133+ 实施体）；stage0.md §9.102.1 K114（分层 JIT——tier-0 → tier-0.5 融合 → tier-1 方法 JIT 阶梯）+ §8.12（操作码能力模型「about 35」——26 融合首枚仍裕量）+ §9.69.3 EXC-10（登记原文）；tech-debt-register.md（W-VM-SUPERINSTR r68 登记行——本窗清偿 + W-PKG-SELFHOST 前置精确化「融合刀交付后」）
> **测量单源**: `tool-results/r133-*`（B 轴复测与 A/B 证据——B2 新参考 82.0ms〔w3.7 §2a seam 终态〕对照 + B4 第二十四次复测）；守卫单源 = `tests/v1/stage1/plan/jit_window_tests.rs`（再生成后）+ `tests/v1/stage1/plan/superinstr_window_tests.rs`（新族）

## 1. 实施域实态（开窗时点代码事实）

| 面 | 实态 | 依据位 |
|---|---|---|
| 操作码面 | 25 臂直译 match（`Opcode::ALL` 钉扎 25）——Add/Sub/Mul/Div 四臂在树但编译器零发射（F1：算术经内建调用路径） | opcode.rs + 画像 F1 |
| 调用发射 | `Apply` 臂 = args 左→右 + callee（Var 解析三序：local → captured → global）+ `Call argc`——全局 callee 恒发 `load-global g` + `call n` 相邻对 | compile.rs:541-550 |
| 调用执行 | `exec_call` = pop callee + take_args + `invoke`（Closure 入帧 / Builtin 内联 dispatch_builtin / 其他 TypeMismatch「call callee」） | vm.rs:687-759 |
| 首对份额 | load-global+call = 25.9%（fib-25 849,746 对）+ 四负载普适 24.1-28.6%——每次调用（kerf 函数或内建）callee 均经全局槽装载（§19.3 求值序契约：args 先 callee 末） | 画像 §2.1 F4 |
| 观察面 | `VmObserver`/`run_observed`（r132 seam 终态：参数传递 + const 泛型单化——B2 +2.4% 布局残留接受）——融合后 census 直接计数 CallGlobal（单指令） | observer.rs + w3.7 §2a |
| 孪生面 | compiler.ktf `acall` 臂（1200-1205）= `cp_ewalk(callee)` + `cp_emit("call", argc, 0, span)`——gate B 逐位等价（`b_self == oracle_self`）+ fixpoint 自复现双面 | selfhost/v1/compiler.ktf + fixpoint.rs |
| C 后端 | emit.rs 逐臂 match（Call/LoadGlobal 分立）+ depth.rs DAG 走查（pops/pushes 表镜像 verify）+ max_argc 扫描（Call 的 a） | cbackend/emit.rs:733/820 + depth.rs |
| .krf 往返 | 指令记录 `(op-name a b)` kebab 名 + `from_kind_name` 表反查（dump_ktf_insn/rebuild_insn 双面表驱动） | compiler_parity.rs:512/728 |

## 2. 形态裁定（SI-1..SI-6——ARCH-A）

### SI-1 融合形态 = 发射时特判（非后处理 pass）

`Apply` 臂内特判：callee 为 `Var` 且解析走全局路径（local 未命中 + captured 未命中）→ 直接发射单条 `call-global`（span = Apply 表达式 span）；否则走原路径。**四依据**：

1. **span 语义最短路径**：融合指令 span = Apply span ≡ 原 `Call` 指令 span（compile.rs:549 `*span`）——错误报告位与原 call 位逐位一致；唯 LoadGlobal 位错误（UnboundGlobal/ExternCallRequiresBackend）的 span 从 Var span 移到 Apply span（调用位更准确的语义位），语料期望为类别级（`runtime-error`/`value`）零再生成面，jit_window_tests 负向 3/4/6 的 census 位置断言按新 pc 再生成（设计内——§3）。
2. **跳转目标安全免证**：后处理 pass 需证明被融合对的尾 pc 非静态跳转目标（fusable 分类器的编码器侧复刻）；发射时特判的结构不变量 = kerf 编译器只把 jump 目标落在表达式求值起点（if/结构点），callee 的 `load-global` 永居 Apply 尾位、永非目标——**结构性免除分类器**（负向 2 守卫维持钉扎 VM 侧分类器语义——观察面不变）。
3. **孪生镜像面最小**：.ktf 侧 `acall` 臂单点特判（cp_assoc_slot/cp_capture_in_cur 现有 helpers 复用）≈ 后处理 pass 的全量扫描 + pc 重映射镜像（jump 修补逻辑双实现 = 漂移面 ×2）。
4. **K150 静态单相**：编译期决策、零运行期反馈、产物确定性（同一 CoreExpr 恒同指令流——B4/fixpoint/digest 前提保持；指令流本身变化 = 新基线，见 SI-5）。

### SI-2 操作码布局 = `CallGlobal { a: global index, b: argument count }`

Perform 形制对齐（`a: effect-name global index, b: argument count`）——a 与 LoadGlobal 的 a 语义对齐（全局槽索引，verify Pass 1c 边界检查直接并组）、b 与 Perform 的 b 对齐（argc）。`Opcode::ALL` 25 → **26**（kind_name `call-global`；ordinal 25 尾插——census 直方图键稳定扩展，既有 0-24 位零移位）；「about 35 opcodes」能力模型裕量维持。**argc 从 Call 的 a 移到 b**——.krf 记录 `call-global g n` 与 `perform e n` 同族、与 `call n 0` 的位移差异由表单源吸收（Display/往返/rebuild 全走 kind_name 族）。

### SI-3 栈效应 = `pops(a, b) = b`（argc——callee 不经栈）、`pushes = 1`

复合等价推导：原序列 `load-global`（pops 0/pushes 1）+ `call argc`（pops argc+1/pushes 1）净 argc+1 进 1 出；融合 `call-global`（pops argc/pushes 1）净同——callee 从全局槽直读、栈上只有 args。verify/depth.rs 双 DAG 走查与 compile 时簿记三面同表驱动（opcode.rs 单源），自动一致。

### SI-4 语义等价五论证（融合臂 ≡ 原对——B4/D-CLASS-1 与 parity 前提）

1. **求值序**（§19.3/§19.5 契约）：args 左→右先求值、callee 末——融合臂执行点在全部 args 之后，读取时点 ≡ 原 load-global 的执行时点（args 求值中 `set!` 重绑 callee 的可见序不变——同一读取时点）。
2. **错误族逐位**：UnboundGlobal / ExternCallRequiresBackend（extern 名调用 = W-3.2 契约）两错误从 LoadGlobal 位迁至 CallGlobal 位（span 移至 Apply 位——SI-1-1）；ArityMismatch（Closure params 不符）/ TypeMismatch「call callee」/ 内建族错误（DivByZero/ArithmeticOverflow/…）在 invoke 单源不变——`invoke` 复用（exec_call 与 CallGlobal 臂共用，零孪生语义面）。
3. **GC/预算**：load-global 与 call 均无 reserve 点（分配发生在被调函数体内/内建 cons）——融合臂零 reserve ✓；D-CLASS-1 三元组（churn 分配序）不受指令流变化影响（分配计数驱动 GC 触发，非指令计数）——B4 第二十四次复测验证。
4. **帧语义**：内建调用保留帧内联（take_args + dispatch_builtin + push 结果）≡ 原路径；kerf 函数调用 push_frame——CallGlobal 臂读 callee 后走同一 `invoke`，帧操作序不变。
5. **观察面**：census 单计数 CallGlobal（对消失）——「前提重推导」的设计内兑现（§3 再生成）；plain/observed parity 保持（融合臂在两例化同源）。

### SI-5 守卫再生成义务（六案 + 新族——「census premises re-derived」警报兑现）

w3.7 §6 守卫族的**设计语义** = 过渡态钉扎（「future fusion must reproduce bitwise」）；融合落地触发再生成（fail-closed 触发线的正常工作形态，非守卫失效）：

| 守卫 | 再生成形态 |
|---|---|
| 正向 1 census 锚 | double 程序 12 → **10 指令**（load-global+call 对 ×2 → call-global ×2）；计数/对表/热函数全链重推导 |
| 正向 2 四对钉扎 | (LoadGlobal,Call) 对钉扎 → **CallGlobal 计数钉扎**（融合后对消失）；其余三对按新指令流重钉（push-const+load-global 于内建调用位点 → push-const+call-global 新对形态如实分类） |
| 负向 1 F1 触发线 | 算术四操作码 census 冷**维持**（r133 不做 F1 直发——刀界 SI-6）；「call 路径四连」断言面 → CallGlobal 路径四连（call 计数 0 化） |
| 负向 2 跳转目标非融合 | **维持不动**（VM 侧分类器语义 = 观察面不变；手搓产物守卫与编译器发射面正交） |
| 负向 3 census 终止 | (car 1) 案 3 → 2 观察（push-const + call-global），last=(call-global,0,1) |
| 负向 4 DivByZero parity | 4 → 3 观察；错误 observed/plain 一致维持 |
| 负向 5 D-CLASS-1 三元组 | 指令计数面变化如实重钉；**1/1023 三元组值预期维持**（分配驱动——B4 复测验证） |
| 负向 6 UnboundGlobal | last=(call-global,0,0)；1 观察（手搓产物面达运行期路径不变） |

新族 `superinstr_window_tests.rs`：≥8 案（正 2/负 6 = 1:3 沿 r119/r132 形制）——语义等价对拍（融合/非融合同程序同值）、span 断言、verify 边界、C 后端 e2e、fixpoint 维持、孪生融合位对齐（gate B 面上 oracle 与 .ktf 产物逐位）。**集成验证用例**（MUV 133-b 门）：全语料 sweep 融合前后值/错误逐位一致断言。

### SI-6 切轮排期（MUV 边界——禁止降级交付）

| 轮 | MUV | 范围 |
|---|---|---|
| **r133**（本刀） | 133-a 窗口档 + 133-b CallGlobal 融合全链（opcode 26 化 + vm 融合臂 + verify + .krf 往返 + C 后端 + compile 特判）+ 133-c compiler.ktf 孪生同步（acall 臂特判）+ 133-d 守卫再生成 + 新族 + 133-e B 轴复测 + audit AO 族 + 文档族 + v0.94.0 锁步 + GATE 1 + 投票 + commit | **单刀完整全链**（THE 首对 25.9%——w3.7 F4 裁定） |
| **r134**（次刀） | F1 直发算术（编译器发射面——四算术静态守卫形：全程序无内建名 set! 重绑时直发 Add/Sub/Mul/Div；K150 BINARY_OP 特化同构）+ 按带缺口补充融合对（push-const+load-global 14.8% / load-local+push-const 14.8% 候补）+ 复画像（W-JIT-METHOD-T1 三触发器判定）+ 窗口关闭（出口三件：融合交付复测落带 ≤0.7×82≈57ms 或如实登记缺口 + 复画像出册 + 裁定 = 窗口关闭/登记窗维持） | F1 守卫反转 + 画像前提重推导 |

**切轮依据**：§4 MUV 完整性（刀的全链完整 = 非降级；r126 W-HM-TWIN 五刀先例同形制）+ 风险递减（opcode 扩展/孪生同步/守卫再生成三流程 r133 建立、r134 复用）+ B 轴中间数据（r133 末复测）指导 r134 对选择；两刀正交（对融合动分派面、直发动发射面——w3.7 §4.3-1 原文）。

## 3. 实施账目（r133 首刀 + r134 次刀——已交付 @ v0.94.0/v0.95.0）

- opcode.rs：+CallGlobal（enum/ALL[26]/kind_name `call-global`/from_kind_name（表驱动自动）/ordinal 25 尾插——既有 census 键 0-24 零移位/operand_help/pops/pushes）——is_terminator 维持（jump|ret|halt）
- vm.rs：CallGlobal 臂（读槽错误族迁位 + take_args + invoke 复用——零孪生语义面）
- verify.rs：Pass 1c a 并组（globals 边界）；Pass 2 表驱动自动
- compile.rs：Apply 臂 SI-1 特判（lookup_local/capture_in_cur 幂等序 + intern_global 调用时点对齐——全局表顺序与 capture first-use 顺序零漂移）
- cbackend/emit.rs：CallGlobal 臂（kc_ 临时 + k_global_load + k_call 复合）+ max_argc 扫描（b 槽）；depth.rs 表驱动自动
- compiler.ktf：acall 臂特判（first(callee)=="var" + slot/capture 双查 + 融合/回退双臂）+ cp_op_pops/cp_op_pushes 双表加臂——**gate B 逐位等价维持 + fixpoint 自复现（融合发射 byte-for-byte）**
- 守卫再生成（SI-5 清单全兑现）：jit_window_tests 六案 + 快照黄金族（snapshot_seed cs02-cs10/ds06 29→22 + compiler_seed ×2 + api_tests ×2 + cbackend ×2 + gc_window/stage_exit/fixpoint 基数 26 + composed 篡改 probe 强化）+ **新族 superinstr_window_tests 8 件**（正 2/负 6）+ **audit AO 族 10 案**（300→310 live · 40 节）
- **B 轴复测**（tool-results/r133-dispatch-profile-run{1,2,3}）：fib-25 **2,427,852 指令**（-25.9% = 画像预测 849,746 对逐位吻合）+ 中位 **71.425/70.958/70.918ms**（0.87× vs 82.0ms seam 参考）+ 开销份额 72.5% → 66.8% + churn 14,003 → 10,003 + parity OK 全负载；B4 第二十四次逐位（D-CLASS-1 三元组 1/1023 观察下维持——分配驱动实证）

## 2a. F1 直发算术形态裁定（FA-1..FA-6——ARCH-A @ r134）

### FA-1 守卫范围 = 全程序逐名毒化集（post-expansion 树扫描）

四算术名 `{+ - * /}` 各自独立判定「可直发」；毒化源 = 展开后模块树（含任意嵌套 Module 臂递归）中的三类绑定面：①`ModuleItem::Define`（name 命中——define 覆写全局槽）②`ModuleItem::Extern` 条目名（extern 契约名占用槽位语义——直发将绕过 `ExternCallRequiresBackend` 边界）③任意表达式树深处的 `CoreExpr::Assign`（set! 写全局槽）。**不毒化**的四类面（发射位局部解析已天然回退）：`Let`/`bind` 局部绑定、`Fn` 形参（Apply 位 `lookup_local` 命中即回退）、capture 解析（`capture_in_cur` 命中即回退）、`Perform`/`Handle` 子句效应名（只读槽位不写）。**Require 零毒化**（依据：模块图只解析树内 module——`ModuleGraph::declare` 边集来自当前树，树外 require 必 `ModuleNotFound`；树内 module 条目被编译器内联编译 = 扫描完备）。毒化粒度 = 逐名（重绑 `+` 不禁 `-`——通解非特化）。

### FA-2 发射位条件 = 六合取，回退臂保错误族

`Apply` 位：callee 为 `Var(name)` ∧ `lookup_local` 未命中 ∧ `capture_in_cur` 未命中 ∧ `name ∈ 四名` ∧ `name ∉ 毒化集` ∧ `argc == 2` → 发射单条 `Add|Sub|Mul|Div`（span = Apply span——与 CallGlobal 同位）；任一不满足 → 原 `CallGlobal` 回退臂。**argc≠2 回退**（`(+ 1 2 3)` 保全 `ArityMismatch` 运行期错误族——直发静态排除该错误面）。操作码面 **26 维持**（四臂已在树——VM/verify/C 后端/孪生 pops/pushes 表四面既有支持，零新操作码）。

### FA-3 语义等价 = 构造性单源（builtin::arith 双消费）

内建分派 `Builtin::Add => arith(Opcode::Add, args[0], args[1], span)` 与 VM 操作码臂 `Add => arith(instr.op, a, b, span)` **同函数单源**（builtin.rs:201/vm.rs:498）——等价非论证而是构造。错误族逐位：`TypeMismatch`（context "add operand"/demanded/got 同文同 span）、`DivByZero`、`ArithmeticOverflow` 三族两路同源同形；`ExternCallRequiresBackend`/`UnboundGlobal` 由 FA-1 毒化规则排除（extern 名与 define 名毒化）；`ArityMismatch` 由 FA-2 argc==2 静态排除。求值序不变（args 左→右先求值、callee 后读——直发臂执行点 = 原 call-global 位，读取时点不变）。

### FA-4 intern 序确定性 = 直发名零入表

直发位不调用 `intern_global(name)`（无 load-global/call-global 引用该名）——四名「仅直发引用」时全局表不含该名；剩余名 first-use 序不变（从首用序列移除元素不重排其余——§9.55 确定性不变量保持；B4/fixpoint/digest 前提维持——指令流变化 = 新基线，守卫再生成承载）。

### FA-5 孪生镜像 = 原始记录流线性扫描 + acall 臂分支

孪生毒化态 = `cp_arith_poison` 名单表（Rust 侧 `Vec<Symbol>` 镜像）；扫描 = **原始扁平记录流线性遍历**（注入契约形态：`("define" s e name gen)` 第 4 字段 / `("assign" s e name gen)` 第 4 字段 / `("extern" s e count gen entries…)` 条目尾 `cp_drop(rec,5)` 逐条 `first(entry)`）——树遍历降维为流遍历（等价性构造：每个树节点恰出现一次为流记录）。acall 臂在全局解析成立后增 F1 合取分支（argc==2 ∧ 名∈四名 ∧ ¬member(毒化) → `cp_emit(算术名, 0, 0, span)`）；四名→操作码名映射 = 关联表（`("+" "add") …`——`cp_assoc_slot` 惯例）。bind/fn 形参/clause 记录零扫描（与 FA-1 镜像）。

### FA-6 守卫反转与再生成义务（F1 域——SI-5 同形）

| 面 | 再生成形态 |
|---|---|
| jit_window 正向 1 census 锚 | double 程序 `(* 2 x)` → 直发 mul：total 10 维持、CallGlobal 2→1、Mul 0→1、对表 (LoadLocal,Mul)(Mul,Ret) 新形态、热函数 [6,4] 维持 |
| jit_window 正向 2 四对钉扎 | 算术位钉扎翻转（`(+ 1 2)` → Add 计数=1、CallGlobal=0）；非算术 callee 钉扎维持（`(< 5 2)` 等——比较族无操作码面，恒走 call-global） |
| jit_window 负向 1 F1 触发线 | **反转**：算术四操作码 census 冷 → 直发在位钉扎（四算术程序 Add/Sub/Mul/Div 各=1、CallGlobal=0）+ 毒化回退触发线（set! 重绑程序 CallGlobal 回退=1、Add=0——新负向） |
| superinstr 新族增补 | ≥8 案 F1 域：直发/回退值等价（毒化 set! 双臂）+ define 毒化 + extern 毒化 + 局部遮蔽（let/形参）+ capture 解析回退 + argc≠2 回退（1 参/3 参 ArityMismatch 保全）+ fixpoint 自复现维持 + 孪生 F1 臂篡改 gate B drift |
| audit AO 族再生成 | AO01（fib 锚 call-global 计数——算术位直发后重推导）、AO02（值等价探针）、AO09（C 发射探针——k_arith 形态）、AO10（孪生篡改探针——F1 后 `(+ y 2)` 零 call-global，探针程序换非算术 callee 形态） |
| audit AP 族新增 | 10 案（310→320 live · 41 节）：F1 发射完备 + 毒化三源回退 + 局部/capture/argc 回退 + 值等价 + C 后端 k_arith e2e + .krf 往返（add/sub/mul/div kebab 对）+ 孪生毒化扫描篡改 + fixpoint + census 前提 + intern 序（直发名零入表断言） |
| 快照黄金族 | cs02-cs10/ds06/compiler_seed/api_tests/cbackend 中含算术调用的期望按新指令流再生成（跑测定位逐件） |

**比较族裁定**：`< <= > >= =` 无操作码面（Builtin::compare 无对应 Opcode），恒走 call-global——本刀零比较族直发（操作码面 26 维持；未来刀项须经 §21.7 重裁）。

### 3.1 目标带终账（诚实登记——r134 复测）

首刀 0.87×（~71.0ms）→ 次刀 F1 落地后三跑中位 **61.544/61.815/61.963ms = 0.75×-0.76×** vs 82.0ms seam 参考（两刀合计 **-25.0%**）；指令数 2,427,852 逐位不变（直发臂 1:1 替换融合调用——指令面零变化、每指令成本 29.2→25.35ns〔-13.2%〕= 坍缩的是 call 开销面：take_args + invoke + arity 检查 + 内建 match + 值克隆）。**带缺口 4.1ms（61.8 vs 57.4 = 0.7×带）如实登记**：复画像指导的第三杠杆 = (load-local, push-const) 对 485,569 次（fib 内 20.0%——K151 复制+超级指令经典对，纯分派消除无语义坍缩，预估 ~12ms 节余可达 0.60×）——**归入 W-JIT-METHOD-T1 开窗裁定的输入**（tier-0.5 融合层与 tier-1 方法 JIT 的层级分工由该窗裁定，非本窗尾刀仓促加码——§4 MUV 边界 + r126 先例形制）。

### 3.2 W-JIT-METHOD-T1 三触发器判定（r134 复画像实值）

| 触发器 | 阈值 | r134 实值 | 判定 |
|---|---|---|---|
| ① B2 vs C-O0 带 | > 1.8×（42.66ms） | 61.8ms = **2.60×** | **命中** |
| ② 分派份额 | > 40% | 解释器开销份额 **61.5%**（B9c 交叉核验） | **命中** |
| ③ T-a 链路 | > 25× | ~450×/1.327 ≈ **339×**（r121 基线折算两刀提速） | **命中** |

三触发器全部命中 → **W-JIT-METHOD-T1 登记窗开窗**（Sparkplug 1:1 形态——tier-1 方法 JIT；cranelift 基座内否决维持 r132 裁定）。

## 4. 出口条件核对（r134 关闭轮——三件全过）

1. **融合交付复测落带**：⚠️ 未达带如实登记（0.75× vs 0.7×——带缺口 4.1ms + 第三杠杆量化归后窗裁定，§3.1 终账）✓（「未达带如实登记缺口与补充对账」出口形态）
2. **复画像出册**：✓（tool-results/r134-dispatch-profile-run{1,2,3}——四负载三跑稳定 + §3.2 三触发器判定表）
3. **裁定**：✓ **窗口关闭**（W-VM-SUPERINSTR Resolved——两刀全链交付 + 诚实带账；W-PKG-SELFHOST 前置「融合刀交付后」达成）+ **W-JIT-METHOD-T1 开窗**（三触发器全命中）
4. 六命令全绿 + audit 320/320 · 41 节 + fixpoint/gate B 自洽维持 + 文档族七件 + v0.95.0 金链锁步 ✓（GATE 1 实测见 worklog Task-134-a）

## 5. 谱系

r111 W-3.1（性能地基）→ r119 W-3.4（GC 单代维持）→ r132 W-3.7（评估窗：画像 + 三路权衡 + 实施窗开启）→ r133 W-VM-SUPERINSTR 首刀（CallGlobal 融合全链）→ **r134 次刀（F1 直发 + 复画像 + 窗口关闭——本窗终态）** → **W-JIT-METHOD-T1（开窗——三触发器全命中）** → T-a 生产位切换窗（W-PKG-SELFHOST 前置「融合刀交付后」已达成）。

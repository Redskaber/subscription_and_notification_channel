# W-HM-TWIN 实施窗（段三 HM 判定面孪生——typecheck.ktf + infer.ktf）

> **状态**：**Closed · 五刀全链交付 + 段三 ELEVATED**（r127 交付 127-a infer.ktf 推断面；r128 交付 127-b typecheck.ktf 检查面；r129 交付 127-c 稳态链 parity 三面 + 跨路由等价；r130 交付 127-d 测试面 + audit AN 族 + 语料 HM 轴重分类钉扎；**r131 交付 127-e 升格重裁 + 文档族——§5 三判据全过，段三 HM 判定面 = ELEVATED**；下一入口 = W-3.7 JIT/超级指令窗——T-a 解锁前置）。
> **单源位**：本档 = W-HM-TWIN 实施计划/排期/进度单源；知识层 stage0.md §9.116；裁定升级链 w3.12-frontend-window.md §6e（三议题分面裁定——议题二 HM 判定面 = 补孪生确认）。
> **依据**：SOP v15.3 §21.12-28（自举完备优先——自举段就绪 = 首要入口；排期非自举段须附可审计裁决理由）；用户常设指令①④（完整完全自举优先 + 完全脱离宿主完成标准）；r124 交付实测基线（六命令 1506:0:4 + audit 290/290）。

## 1. 自举阶梯全景（粗粒度——进度与演进规划）

**BS-A 端态定义**（stage0.md §9.25.2 单源）：最大化前端自举——「100% 自我演化」口径以**编译管道段位**为准；宪制排除项 = VM 永久 Rust 基座 + 构建引导层（r124 议题一升格，同 VM 基座形制）。LLVM/本地码后端永不入自举链。

| # | 阶梯段位 | 状态 | 载体 | 升格轮 |
|---|---------|------|------|--------|
| 1 | 段一 reader（S-expr 读链） | **ELEVATED** | lexer.ktf 671 行 + reader.ktf 141 行（812 行纯 kerf） | r121 |
| 2 | 段二 expander（展开段全量语义） | **ELEVATED** | macro.ktf 686 行 + expander.ktf 1671 行（W-CSYM-EXPR 重归属后孪生 = 展开器语义面） | r123 |
| 3 | 段三 HM 判定面（类型检查/推断） | **ELEVATED** | infer.ktf 3,690 行 + typecheck.ktf 1,234 行（4,924 行纯 kerf——Rust 本体 kerf-typecheck 7 文件 5,352 行的孪生承载） | **r131**（§5 三判据重裁全过） |
| 4 | 编译孪生（rebuild 面） | 在位（compiler.ktf——r124 cp_extern_walk 消费臂补齐 + parity externs 段三面） | compiler.ktf | 非独立段位（段三 parity 消费者） |
| 5 | T-a 生产位切换窗 | 触发门控（W-3.7 JIT/超级指令窗落地后 vm/rust 实测 < 10× → 重测 → 开窗；切换对象 = 生产桥 read/expand 步，Rust read_program 退役为 BS-A 种子链 oracle） | — | 双链解耦（§21.12-28②：升格 ≠ 生产位切换——K140 Go 1.5 先例） |
| 6 | 宪制排除项（VM Rust 基座 + 构建引导层） | 永列排除（任何阶段不得列入重写计划——宪制条款） | — | r90 + r124 议题一 |

**演进排序**（自举阶梯最高优先——§21.12-28；非自举窗附裁决理由）：~~W-HM-TWIN（本窗）~~（**Closed · r131**）→ ~~段三升格重裁~~（**ELEVATED · r131——§5 单源**）→ **W-3.7 JIT/超级指令窗（下一入口——T-a 解锁前置）** → T-a 生产位切换窗。W-3.4 分代 GC（r119 裁定维持单代）/ W-3.5 增量编译 / W-3.8 后端升级 / W-3.9 LSP 维持从属位（零消费信号——r124 复核维持）。

**自举面超集对账**（§9.25.2 D1 清单对照）：kerf 自举面 = D1 前端清单超集——read ✅（r121 ELEVATED）+ expand ✅（r123 ELEVATED）+ compile ✅（compiler.ktf rebuild 面——r124 在位，段三组合分析面承载 parity）+ HM 判定面 ✅（**r131 ELEVATED——本窗闭合**）+ 构建编排（宪法性排除 r124）。**BS-A 前端全段收敛于 r131 达成——「编译管道全段自举」口径闭合**，余量 = T-a 生产位切换（性能门控非完备性门控）。

## 2. 知识层（r126-search 六检索件 + K 锚——stage0.md §9.116 单源）

存档 `tool-results/r126-search/`（q1-q6）。**检索质量如实披露**：q4/q5 强锚（rustc 主源 + Typing Haskell in Haskell）、q1/q6 中强、q2/q3 弱查噪音（第十七轮——news.ycombinator/scribd/researchgate 垃圾域，主源直读补位）。

- **K146**（q5 强锚，web.cecs.pdx.edu）：Mark P. Jones《Typing Haskell in Haskell》——用被检查语言本身实现 HM 类型检查器的正典先例：显式 substitution/unification 机制全量在自语言内表达；直接先例 = typecheck.ktf + infer.ktf 检查 kerf 自身。
- **K147**（q4 强锚，github.com rust/compiler/rustc_hir_typeck/src/check.rs + doc.rust-lang.org TypeckResults）：rustc typeck 主源——类型检查循环与编译器本体同语言（K125 家族复证）；typeck 工作状态 = 编译器 crate 内一等公民（非外部工具）。
- **K148**（q1 中强，cs3110.github.io §10.6）：约束生成 + 求解两相表述（K124 家族复证）——HM 推断 = 纯树/表/符号操作（eq? Str 内容比较 + pair 代数 + 递归，无字符依赖——r124 可表达性确认单源）。
- **K149**（q6 中强，usr.lmf.cnrs.fr + cs.stackexchange）：替代表示形态谱系——persistent union-find / disjoint-set 与迭代 W + undo-log 的分界；kerf 既有形态 = 迭代 W + undo-log（trail 回滚）+ SCC 分治（kerf-typecheck r117 时代基座，§9.68 CHK 双表 + SCC 图先例）——**维持既有形态**（孪生与 Rust 本体同构 = parity 最短路径；持久化结构形态弃用登记）。

## 3. 形态裁定（.ktf 孪生结构——TWIN-1..TWIN-5）

- **TWIN-1 载体与目录**：`selfhost/v1/infer.ktf`（推断引擎——HM 核心：迭代 W + undo-log + SCC 分治 + let-polymorphism 泛化 + Externals 边界）+ `selfhost/v1/typecheck.ktf`（检查面——check/infer 双表镜像 + TypeDiagnostic 产物流）。目录维持 `selfhost/v1/`（r122 目录统一裁定——.ktf 孪生源独立目录；bootstrap/ = Rust 链侧）。
- **TWIN-2 通道复用**（INJ-1 通解——同通道服务段一/二/三全阶梯）：item 记录载荷（`LiteralValue` 对链）经 `inject_global` + `expand_program_with_injected`（injected_names 全局回退）+ 检查器 externals 扩展（host-bound 名 = 程序外部名）——零新原语/零新内建/零冻结面变更（8 原语不变性延续）。
- **TWIN-3 稳态链形态**（段一/段二先例延续）：`SteadyTypecheckChain`——固定孪生程序**编译一次**（生产桥 parse → injected 展开 → 检查 → compile → Bytecode）+ 每推断经注入通道运行；等价义务 = 稳态路由 ≡ 逐源编译路由（同源同判）。
- **TWIN-4 parity 机器三面**（r124 externs 段先例形制）：`oracle_analysis_dump` 尾增类型判定段（types 键族——紧凑文法）+ `dump_ktf_section` 对应臂 + `rebuild_bytecode` 对应臂 + rebuild 错误键对齐 oracle parity 键（孪生错误键 = Rust TypeDiagnostic 键——逐位）。
- **TWIN-5 工作量口径**（r124 议题二裁定单源）：kerf-typecheck 5,352 行 Rust → **~2,500-3,500 行 .ktf**（类型表示 pair 代数 + Symbol 驻留名 + 环境表 assoc list；无字符依赖）。infer.ktf 承载推断主体（~1,500-2,200 行）+ typecheck.ktf 承载检查/诊断面（~1,000-1,300 行）。

## 4. 实施排期（细粒度——MUV 拆分；每 MUV 含 ≥1 集成验证用例）

| MUV | 内容 | 估量 | 集成验证用例 |
|-----|------|------|--------------|
| 127-a ✅ r127 | **infer.ktf 主体**：类型表示（pair 代数 + Type 表）+ 迭代 W + unify/undo-log + SCC 分治 + let-polymorphism 泛化 + Externals 边界 + 递归绑定（3,641 行；r127 parity 收敛——sweep 5/5 + 套件 1511:0 + audit 290/290；13 缺陷清偿含 oracle resolve Arrow 参数交叉 P0） | ~1,500-2,200 行 | 全语料 sweep 推断轴逐位 vs oracle（91 案 + HM 负向族）✅ 全绿 |
| 127-b ✅ r128 | **typecheck.ktf 检查面**：check/infer 双表镜像 + TypeDiagnostic 产物流 + 诊断键族（unbound/type-mismatch/arity 族）（1,234 行；r128 parity 收敛——sweep 6/6 + 套件 1520:0 + audit 290/290；双表镜像守卫经 pass-1 表面入 parity 文本逐行对账[oracle 新增 `table_axes` 公共面] + 走查状态落赋值全局[W-machine 纪律——单态递归约束下变形传参 = occurs]） | ~1,000-1,300 行 | 双表镜像守卫 + 诊断键 parity（rebuild 键 = oracle 键逐位）✅ 全绿 |
| 127-c ✅ r129 | **稳态链 + parity 三面**：RS-4 双引擎面（infer_dual/check_dual——链体增存解析项）+ 逐源文本路由（infer/check 双驱动——RS-1 形制）+ oracle_analysis_dump_typed 类型尾段 + dump_ktf_section `types` 臂 + rebuild_typed_verdict 结构面（TypedExpr/Schema/Row/TypeDiagnostic 重建 + 诊断码逆向注册表 + fail-closed 六探针）+ 稳态 ≡ 逐源 ≡ oracle 跨路由等价（~700 行 Rust harness + ~420 行测试；套件 1526:0 + audit 290/290；eval-face 清单 C 桶 +3/39 同步） | ~300-500 行 Rust 侧（实际 harness ~700——rebuild 结构面超出预估，如实登记） | 跨路由等价 ×2 + RS-4 探针 ×3 + 确定性/喂给（检查链）+ 组合分析 + 结构重建 + fail-closed 篡改族 ✅ 全绿（hm_twin_chain 6 案） |
| 127-d ✅ r130 | **测试面 + audit**：runner AN 族四案（配对正负探针双面钉扎 `paired_drive` + 语料 HM 轴重分类精确钉扎[reader 8/展开拒 19/infer 诊断 6 逐名/clean 58；check 诊断 10 逐名/clean 54；双轴 fed 64] + 预算行 E0011 逐源路由面）+ audit AN 族 10 案（290→300 live，39 节）+ TEST-3 守卫三处同步（composition/总数/headline）+ eval-face 清单 C 桶 +1/40 同步（W-3.6 fail-closed 触发实录） | +15-25 案（实际 runner 四函数携 10 探针 + 91 行钉扎 + 预算行，audit 10 案） | GATE 1 冷跑（六命令 1530:0:4 + audit 300/300 全绿）✅ |
| 127-e ✅ r131 | **升格重裁 + 文档族**：段三三判据重裁（§21.12-28②——§5 单源，全过 → **ELEVATED**）+ stage-3-plan v2.7/roadmap v2.61/tech-debt（W-HM-TWIN 清偿归档 + W-BOOT-FRONTEND 账面全清偿）/stage0 §9.117 + RELEASE_NOTES + Cargo 金链锁步 v0.92.0 | 文档域 | 投票 5.5/5.5 + §19 双包 ✅ |

**排期诚实边界**：127-a/b 为 1-2 完整轮次工程量（r124 议题二裁定原文）——单轮容纳不下时按 MUV 边界切轮（127-a 单轮 → 127-b/c/d/e 续轮），**禁止降级交付**（「不完整的自举不是自举」——段三升格仅在 127 全链交付后重裁；中途状态 = 窗内进度如实登记，不得标记段三 ELEVATED）。

## 5. 段三升格重裁（r131——ELEVATED；§21.12-28② 三判据——与段一 §6/段二 §6d 同口径）

**判据**（SOP v15.3 §21.12 第 28 条 ②）：段升格判据 = 自举链完备（该编译段以自身语言完整承载 + 自举链经该段自我编译 + parity 门全绿）——**不含生产位性能条件**；生产位切换 = 升格后的独立后续窗。

| # | 判据 | 实证 | 裁定 |
|---|------|------|------|
| ① | 该编译段以自身语言完整承载 | infer.ktf（3,690 行——迭代 W + unify/undo-log + SCC 分治 + let-polymorphism 泛化 + Externals 边界 + 递归绑定）+ typecheck.ktf（1,234 行——check/infer 双表镜像 + R1-R8/R-LA7 全规则族 + 多错收集 + 诊断键五面）= **4,924 行纯 kerf** 承载 kerf-typecheck 全量语义（Rust 本体 7 文件 5,352 行——check 1,255 + infer 2,918 + types 396 + env 183 + guards 308 + code 233）；完备性由 sweep 逐位实证（r127 推断轴 5/5 + r128 检查轴 6/6——全语料 91 案双轴 vs oracle） | **过** |
| ② | 自举链经该段自我编译 | 稳态链运转：`SteadyTypecheckChain`（r127）+ `SteadyCheckChain`（r128）——固定孪生程序**编译一次**（生产桥 parse → injected 展开 → 检查 → compile → Bytecode）+ 每判定经注入通道运行；自应用面 = RS-4 双引擎面（infer_dual/check_dual——r129）+ 逐源文本路由（RS-1 形制双驱动）+ **跨路由等价（稳态 ≡ 逐源 ≡ oracle 同一解码器——r129 探针族实证）** + 语料 HM 轴重分类精确钉扎（r130——91 行逐行分类恰一次：reader 8/展开拒 19/infer 诊断 6 逐名/clean 58；check 诊断 10 逐名/clean 54；双轴 fed 64）+ fail-closed 六探针（r129）+ 篡改族（r130 AN10） | **过** |
| ③ | parity 门全绿 | sweep 双轴全绿（r127/r128）+ 组合分析面（编译孪生 dump + 推断孪生 types 段 ≡ oracle 全管线 dump——r129）+ 集成件 hm_twin_chain 6 案 + runner AN 族四案（r130）+ audit **AN 族 10/10（290→300 live · 39 节）** + 六命令 **1530:0:4**（r130 GATE 1 + 锁步复验逐位维持）+ fmt 零 diff + clippy `-D warnings` 零告警 | **过** |

**裁决**：**段三 HM 判定面 = ELEVATED（自举链完备）**——三判据全过；生产位切换 = T-a 独立后续窗（双链解耦裁定原文执行：W-3.7 JIT/超级指令窗落地后 vm/rust 实测 < 10× → 重测 → 开窗；K140 Go 1.5 先例——性能收窄是切换后的后续工程，非切换前置）。**W-BOOT-FRONTEND 账面全清偿**（tech-debt-register 同步——read/expand/HM 三段 ELEVATED + compile 孪生在位 + 构建编排宪法排除 = BS-A 端态五切口全部收敛）。

**诚实边界**：升格 ≠ 生产位切换——生产桥 typecheck 步仍为 Rust 位（`kerf-typecheck` 生产 crate；孪生为验证面 + 稳态链注入面）；本窗升格对象 = **HM 判定段的自举链完备性**（BS-A 前端段位中 HM 判定面的「以自身语言完整承载 + 链上运转 + parity 全绿」）。编译孪生（compiler.ktf）维持「非独立段位」定位（r124 裁定——段三 parity 消费者；组合分析面已承载其 parity）。**「不完整的自举不是自举」原文执行验证**：127-a/b/c/d/e 五刀按 MUV 边界切轮全链交付，零降级零阉割（127-a 3,641 行 + 127-b 1,234 行 + 127-c 稳态链三面 + 127-d 测试面 + 127-e 本轮裁决）。

**下一入口解锁**：W-3.7 JIT/超级指令窗（T-a 解锁前置——自举阶梯最高优先转移至生产位切换链路；W-3.5/W-3.8/W-3.9 维持从属位）。

## 6. 谱系与登记

- 本档 v1.0 = W-HM-TWIN 开启轮（r126——自举演进规划优先落位：知识层 + 形态裁定 + 粗/细粒度排期；零生产代码变更——纯文档域轮，Cargo/ds08 金链锁步 v0.87.0）。
- 本档 v1.1 = 127-b 交付轮刷新（r128——typecheck.ktf 1,234 行位级收敛：R1-R8 + R-LA7 全规则族 + 多错收集 + 诊断键五面[含 r109 F2 主体集]；pass-1 表面入 parity 文本 = INF-9 镜像守卫直接化[oracle `table_axes` + `assigned_order` 增量面]；sweep 6/6 + 套件 1520:0；ds08 r128 注记 + Cargo 金链锁步 v0.89.0；selfhost/README 七件化[r127 遗漏一并承接]）。
- 本档 v1.2 = 127-c 交付轮刷新（r129——稳态链 RS-4 双引擎面 + 逐源文本路由 + parity 机器三面[oracle_analysis_dump_typed 尾段 / dump `types` 臂 / rebuild_typed_verdict 结构面] + 组合分析面 + 跨路由等价；套件 1526:0 + audit 290/290；eval-face 清单 C 桶 9→12/总数 39[w3.6 窗口档 §4 同步]；ds08 r129 注记 + Cargo 金链锁步 v0.90.0；.ktf 孪生零触碰——纯 Rust harness 域轮）。
- 本档 v1.3 = 127-d 交付轮刷新（r130——runner AN 族四案[配对正负探针双面 + 语料 HM 轴重分类精确钉扎 + 预算行逐源路由] + audit AN 族 10 案[290→300 · 39 节] + TEST-3 三处同步 + eval-face C 桶 +1/40[w3.6 §1 r130 修档 + W36-3 注释陈旧算术顺带勘正]；套件 1530:0:4 + Cargo 金链锁步 v0.91.0；.ktf 孪生与 Rust 生产面零触碰——纯测试/审计/守卫域轮）。
- 本档 v1.4 = 127-e 交付轮刷新（r131——**窗口闭合轮**：§5 段三升格重裁 = **ELEVATED**（三判据全过——4,924 行纯 kerf 完整承载 + 稳态链/跨路由等价/精确钉扎自应用面 + parity 门 300/300 全绿）+ BS-A 前端全段收敛（read r121 + expand r123 + HM r131 + compile 在位 + 构建编排宪法排除——「编译管道全段自举」口径闭合）+ 文档族统一刷新（stage-3-plan v2.7 / roadmap v2.61 / tech-debt-register：W-HM-TWIN 清偿归档 + W-BOOT-FRONTEND 账面全清偿 + r130/r131 检视合并段 / stage0 §9.117 / RELEASE_NOTES v0.92.0）+ Cargo 金链锁步 v0.92.0 + ds08 r131 注记；纯文档域轮——.ktf 孪生与 Rust 生产面零触碰，六命令 1530:0:4 + audit 300/300 维持复验）。
- 8 原语不变性：第八十九轮验证（开启轮零机制变更——零新原语/零新内建/零语法增改/零冻结面触碰）；r130 同判第九十三轮（纯测试/审计/守卫域轮）；**r131 第九十四轮同判（纯文档域轮——裁决与文档族刷新零机制变更）**。
- S-expr 完全转化记录义务（用户常设指令⑧）：开启轮零 S-expr→目标语言转化（规划轮零新转化面）；r129 同判（纯 Rust harness 域轮）——条件不触发如实登记；r130 同判（纯测试/审计/守卫域）；**r131 同判（纯文档域——127-a/b 实施轮的转化面已由 r127/r128 记录于 docs/develop/v0/ 对应统一完全转化记录文件，本轮零新转化面）**。
- 反过度特化审查（用户常设指令⑨）：TWIN-2 通道复用 = INJ-1 通解的段三兑现（同通道服务全阶梯非单点特化）；TWIN-4 = r124 externs 段先例形制延续（parity 机器三面通用形态）；排期 MUV 边界 = 通用轮次切分（非当前语料特化）；r130 同判（语料钉扎为逐名枚举非分支特化；配对探针为面族配对非单点）；**r131 同判（升格裁决 = 判据形制复刻段一 §6/段二 §6d 先例——通用裁决面非本轮特化；窗口闭合 = 排期既定第五刀非临时收敛）**。

# Stage 3+ 阶段计划（stage-3-plan.md）——持续演进期：性能地基 · 语言面清偿 · 工具链生态窗口体系

> **Status**: Active（**v2.11——r135 W-JIT-METHOD-T1 开窗轮 = 自举完备总规划新建 + 窗内第一议题裁定 TJ-1..TJ-5 + tier-0.5 收尾首刀**{用户常设指令①「完整完全自举优先」+「任意递归深度纳入规划」双指令承载：bootstrap-completion-plan.md v1.0 新建〔完成标准操作化 C1-C4 + 缺口地图 G1-G6 + 五窗序列粗粒度排序 + 前置窗细粒度 MUV + T-a 五步 K159 操作化 + 测量计划 + W-PKG-SELFHOST 触发器反冻结改写「manifest 子集实证稳定」〕+ w-jit-method-t1-window.md v1.0 新建〔TJ-1 首刀 = tier-0.5 收尾 LLC 复制对融合（20% 在册数据）+ TJ-2 余量对归 tier-1 方法级吸收（K157 重定义）+ TJ-3 共享基座耦合（tier-1 构建于 W-REC-DEPTH 堆激活栈——K160 归一 + r134 fixpoint 爆深度实证）+ TJ-4 tier-1 = 去分派方法执行层（K153+K157 零 codegen 确定性构造）+ TJ-5 T-a 组合面诚实预期〕+ 登记窗两件新增（W-REC-DEPTH 任意递归深度通解 + W-TGT-READ-TWIN 目标皮肤读链孪生）+ K157-K162 六新锚（stage0 §9.121）+ r135-search 七件存档——v0.96.0}；**下一入口 = W-REC-DEPTH 共享基座刀 1（r136+）∥ W-TGT-READ-TWIN 刀 1（并行排期零交集）——自举阶梯单源 = bootstrap-completion-plan.md §3 序**。<br/>v2.10——r134 W-VM-SUPERINSTR 次刀关闭轮 = **F1 直发算术全链落地 + 窗口关闭 + W-JIT-METHOD-T1 开窗 v0.95.0**（w-vm-superinstr-window.md v1.2 单源）{形态裁定 FA-1..FA-6[全程序逐名毒化集——三毒源 module define/extern 条目名/任意 Assign，program-wide 非逐函数[调用序任意]；四类不毒化面[let/bind 局部 + fn 形参 + capture 解析——发射位局部解析天然回退；perform/handle 效应名]；Require 零毒化[模块图只解析树内 module——扫描结构完备] + 发射位六合取[argc==2 静态排除 ArityMismatch 面——操作码面 26 维持，四臂 Stage 0 以来在树] + 语义等价构造性单源[builtin dispatch 与 VM 臂同函数 arith——等价非论证] + intern 序确定性[直发名零入表] + 孪生镜像 cp_assemble 搭载式扫描[线性流扫描爆 eval 2048 深度预算的设计修正实录——fixpoint 自身源码数千记录] + 守卫反转[F1 冷态警报 → 直发在位钉扎]] + F1 全链实施[compile.rs 毒化扫描 + Apply 臂 F1 分支 + compiler.ktf 孪生同步 + C 后端零改动] + 三层防御实测[extern 算术名：展开层 ExternNameCollision 先拒 → 编译层 C 符号地板拒 +/*/ → `-` 角落可达但双引擎播种内建优先 = 惰性角落如实披露] + 守卫再生成[jit_window 四案 + 快照黄金族 13 件 + api_tests + compiler_seed] + superinstr F1 族 8 件（正 2/负 6）+ audit AP 族 10 案（310→320 live · 41 节）+ **B 轴终账**：fib-25 指令数 2,427,852 逐位不变 + 三跑中位 61.544/61.815/61.963ms = **0.75×**（两刀合计 -25.0%）——**带缺口 4.1ms 如实登记**（第三杠杆 load-local+push-const 对 485,569 次 20% 预估 ~12ms 归后窗裁定）+ **三触发器全命中 → W-JIT-METHOD-T1 开窗**[①2.60× > 1.8× C-O0 带 ②61.5% > 40% ③~339× > 25×]}——六命令 **1554:0:4**[基线 1546 + F1 族 8 案] + audit **320/320 · 41 节** + v0.95.0 金链锁步；**窗口 CLOSED——W-VM-SUPERINSTR Resolved（两刀全链 + 诚实带账）+ W-PKG-SELFHOST 前置达成**；**下一入口 = W-JIT-METHOD-T1 方法 JIT 窗**（Sparkplug 1:1 形态——tier-1；上游裁定 = 本窗 §3.2 三触发器判定表））
> **流程权威**: docs/sop.md（§13.1/§17/§21.7 映射/§14.6.3 规则 5/§19）
> **依据**: docs/develop/v0/roadmap.md v2.42 §2（Stage 3+ 行：新语言 100% 自我演化·VM Rust 基座例外）+ docs/stage0.md v9.68（§21.5 演进矩阵 Stage 3+ 列 + §21.6 三决策点 + §21.7 风险表 + §9.102 本轮知识层[K113-K119 七锚]）+ docs/develop/v2/stage-2/deep-review-round2.8.md（B1×1 FFI extern → Stage 3+ 计划承载）+ tech-debt-register（TD-007 + W-PERF-ENV-COPY/W-TGT-TOKEN-ZERO-COPY/W-DRIVER-HARNESS-SPLIT 三登记窗）
> **前置**: Stage 2 CLOSED（r105 · v0.69.0 · 出口判据四项终核 + 九信号 9✓/9 + 投票 5.5/5.5）+ 规划轮前置一轮（r106 · v0.70.0 · 全管道审查 P2×6 全清偿 + P3 三分类 + 三登记窗）
> **职责边界**: 本文档承载 Stage 3+ 窗口体系、入口信号、出口条件与首刀 MUV 排期单源；全局阶段节点/时间治理四红线由 roadmap.md v2.42 §5 单源承载，本文只引用不重复；知识层（检索锚 + 前沿对照 + 权衡表）由 stage0.md §9.102 单源承载，本文只引用结论。

## 0. Stage 2 → Stage 3+ 门记录与规划域先行裁定

### 0.1 门四要件

| # | 要件 | 状态 | 锚 |
|---|------|------|----|
| 1 | Stage 2 出口判据四项全过 | ✓ 闭合（r105 终核） | deep-review-round2.8.md §2（(1) 全链自举 + (2) fixpoint 字节一致 + (3) C 后端工作[链外] + (4) FFI 评估窗三面裁决——面三源级 extern 裁定 Stage 3+ 承载即本档 §2 W-3.2 的合法性来源） |
| 2 | 外循环投票 ≥95% | ✓ 闭合 | deep-review-round2.8.md §3——5.5/5.5（ARCH-A 2 / DEV-A 1.5 / QA-A 1 / ALG-C 1） |
| 3 | GO 推荐 | ✓ 闭合 | deep-review-round2.8.md §5 + final-assessment.md（Stage 2 CLOSED · GO——r106 复验维持） |
| 4 | **用户确认（§14.6.3 规则 5 = 最终门）** | **✓ 行权闭合（r111 · 2026-10-04）**：用户消息显式句式「**放行 stage3 阶段**」（命中 §0.2 句式族「开放 stage 3 实施入口限制」形）+ 附定谳「cargo test 已经正确（问题是在 nix 环境上）」（r110 T2.13 对照实验定谳[环境性非树缺陷]获用户确认）；前置有效性条件十项复查全绿：六命令 1381:0:2 + fmt 零 diff + clippy 0 + audit 220/220+104r + B 全轴三跑带内[B4 第十九次逐位 1/1023 + B9c 带内 + B10 1.00x] + TD 登记态[TD-007 P3 + 六登记窗]核对 + 语料 85 + selfhost 五件 .ktf + 谱系 + 登记窗触发器核对（W-PERF-ENV-COPY 触发即本轮开窗消费） | 本节 §0.2 判定标准 + r79 解除注记先例；行权承载 = r111 首刀（§5） |

### 0.2 规划域先行裁定（三层结构——沿 stage-2-plan §0 先例）

1. **用户常设指令直接执行层**：「使用当前项目内容……按照规划和计划继续推进项目」+「当前项目禁止冻结」——规划域工作 = 直接执行，零生产代码变更（r107 唯一代码面 = typecheck infer.rs 头注精度顺偿——§8.4.5）。
2. **实施域确认门维持层**：Stage 3 窗口实施（3.1+）的启动 = 待用户确认行权；【禁止进入 stage3】条件句 + 「只要有一个问题没有得到解决则禁止继续向前推进」每轮复核义务维持——问题未解决的禁令复活条件在行权轮重核。
3. **确认位判定标准**（r79 先例句式族——用户消息含以下任一显式句式即补齐确认位）：
   - 「进入 Stage 3」/「开始 Stage 3」/「Stage 3 启动」/「开放 stage 3 实施入口限制」
   - 「开始实施」/「首刀启动」/「性能窗启动」
   - 「排期已确定则继续推进」（r98 句式族）
   - 「确认」+ 上下文指向 Stage 3 入口
   - **前置有效性条件**：行权轮十项复查全绿（六命令 0e0w+fmt 零 diff+clippy 0 + test --release 全绿 + audit 220/220+104 retired + B 全轴带内[B4 逐位] + TD 登记态核对 + 语料 85 + selfhost 五件 .ktf + 谱系 + 登记窗触发器核对）。

### 0.3 Stage 3+ 定位重述（roadmap §2 + stage0 §21.5 单源引用）

- **使命**：新语言 100% 自我演化（VM Rust 基座例外——宪制排除项）；宿主语言仅历史遗迹（S-expr Reader = BS-A 种子链保留）。
- **形态**：持续演进——非一次性阶段收口，而是**窗口体系**（每窗独立入口信号/出口条件/门审，时间治理四红线约束）。
- **宪制边界全量继承**：8 原语不变性（零新原语·零通道·零 VM 重写·零语法增改）；VM 永久 Rust 基座；LLVM/本地码后端永不入自举链（3.8 窗产物 = 链外可选叶子）；元循环求值器退役 = 唯一规划退役能力（评估窗形态——见 §2 W-3.6）。

## 1. Stage 3+ 使命拆解与验收口径

### 1.1 能力目标（演进矩阵 Stage 3+ 列单源引用——stage0.md §21.5.1）

| 能力 | Stage 3+ 目标 | 承载窗口 | 形态 |
|------|--------------|---------|------|
| Token 流 + 图 IR | 优化（增量/并行） | W-3.5 | 做实 |
| 结构化 CodeValue | 优化（JIT 预备） | W-3.7 | 评估→做实 |
| 元循环求值器 | 移除（唯一退役能力） | W-3.6 | 评估窗 |
| 基础闭包 | Effects 生态 | 登记态 | 窗口信号未定义 |
| Effect Handlers | 异步生态 | 登记态 | 窗口信号未定义 |
| 多阶段编程 | 编译期优化 | 登记态 | 窗口信号未定义 |
| 能力模型 I/O | 安全沙箱 | 登记态 | 窗口信号未定义 |
| Span 系统 | 永续增强 | 连续 | 无窗口（持续） |
| 诊断框架 | IDE 集成 | W-3.9 | 做实 |
| 宏系统 | DSL 生态 | W-3.3（声明面清偿）→ 登记态 | 清偿+登记 |
| 编译缓存 | 并行查询 | W-3.5 | 做实 |
| 字节码 VM + GC | 分代 GC / JIT | W-3.4 + W-3.7 | 评估→做实 |

**登记态纪律**（原则 38/44-58）：4 项登记能力（Effects 生态/多阶段/能力沙箱/DSL 生态）零实施义务——窗口信号定义本身是未来轮次的设计工作，不预支。

### 1.2 验收口径（Stage 3+ 全局——每窗另有专属出口条件）

| 判据 | 量化口径 |
|------|---------|
| 语言占比 | 新语言 100% 自演化（Rust 份额 = VM 基座 + 构建引导 + 链外后端——宪制归属不耗减） |
| 同结果测试（自举策略 Stage 3 行） | 两次编译自身输出字节一致——fixpoint 面在全窗口体系下永续维持（每窗门审必检项） |
| 时间治理 | 四红线零违反（窗口独立开闭、信号驱动、处理程度单调、禁止合并） |
| 回归面 | 每窗出口：六命令全绿 + audit + B 轴带内（或轴语义重推导登记）+ 语料/selfhost 维持 |

## 2. §17 七步任务规划产物

### 2.1 Step 1 扫描结果（设计意图 + 能力边界 + 技术债）

- **设计意图摘要**（§13.1——设计文档定位按 stage0.md 存档侧代偿）：Stage 3+ = 在冻结的语义内核（8 原语 + CoreExpr + 管线）之上持续演化性能（分层 JIT/分代 GC/增量编译）、语言面清偿（FFI extern/宏声明皮肤）、工具链生态（LSP/包管理）与唯一退役（元循环求值器评估）——全部为机制层/工具链层工作，语义内核永续冻结。
- **能力边界**：已支持 = .ktf 唯一生产皮肤全管线（lex→read→expand→load→typecheck→compile→VM/C）+ 双引擎 parity + fixpoint 三相位 + C ABI shim（18 内建）+ CLI/REPL 双皮肤；不支持（本阶段引入目标）= 语言级 extern 声明 / 宏声明目标皮肤 / 分代 GC / JIT / 增量编译 / LSP / 包管理。
- **技术债状态**（tech-debt-register 单源引用）：TD-007（P3 登记态——宏声明目标皮肤面，消费信号 = 本阶段窗口）；W-PERF-ENV-COPY（P3 登记态——触发器 = Stage 3+ 性能窗开窗即本档 W-3.1）；W-TGT-TOKEN-ZERO-COPY（P3 登记态——错误路径独占消费，W-3.1 第二刀候选）；W-DRIVER-HARNESS-SPLIT（P3 观察态——harness +30% 或新验证域时评估，全窗口体系骑乘观察）。
- **上一阶段输出**：Stage 2 CLOSED（r105）+ 全管道审查（r106：P0=0/P1=0/P2=6 清偿/P3=17 三分类）。

### 2.2 Step 2 依赖图（窗口 DAG——mermaid）

```mermaid
graph LR
    G["Stage 3 行权门 §0.2"] --> W31["W-3.1 性能地基窗<br/>两登记刀 + B 系列复测"]
    G --> W32["W-3.2 FFI extern 语言面窗<br/>B1 清偿 + TD-026 裁定"]
    G --> W33["W-3.3 宏声明皮肤窗<br/>TD-007 清偿"]
    G --> W36["W-3.6 eval 退役评估窗<br/>消费面清单 + 可再生性"]
    G --> W310["W-3.10 包管理窗<br/>Cargo 三原则适配"]
    G --> W312["W-3.12 前端自举推进窗<br/>BS-A 端态收敛"]
    W31 --> W34["W-3.4 分代 GC 评估窗<br/>B4 轴重推导前提"]
    W31 --> W35["W-3.5 增量编译窗<br/>cache.rs 做实 + 查询化"]
    W31 --> W37["W-3.7 JIT 评估窗<br/>profiling 数据前提"]
    W32 --> W38["W-3.8 后端升级评估窗<br/>C 天花板 → LLVM/cranelift 权衡"]
    W35 --> W39["W-3.9 LSP 窗<br/>JSON-RPC + driver 复用"]
    W34 --> W37
    W39 --> W311["W-3.11 汇聚审计轮<br/>持续演进里程碑"]
    W38 --> W311
    W312 --> W311
```

**拓扑序**（行权后首刀起排）：W-3.1 ∥ W-3.2 ∥ W-3.3 ∥ W-3.6 ∥ W-3.10 ∥ W-3.12（六窗无相互依赖，可并行/串行按轮次裁量；W-3.12 内部段序 = 硬规则锁定的 reader → expander → 裁定段，见 §2.3 W-3.12）→ W-3.4 ∥ W-3.5 →（W-3.4 完成后）W-3.7 → W-3.8（W-3.2 后任意时点）→ W-3.9（W-3.5 后）→ W-3.11 汇聚审计（窗口体系里程碑——非阶段终态，Stage 3+ 无终态）。

### 2.3 Step 3-4 窗口节点详情（每窗 = 入口信号 + 出口条件 + 首刀 MUV）

#### W-3.1 性能地基窗（首刀窗）
- **入口信号**：Stage 3 行权即开（W-PERF-ENV-COPY 登记触发器 = 「Stage 3+ 性能窗开窗」——tech-debt-register 单源）。
- **出口条件**：①B 系列全轴复测出册（B1-B10 + B9c）②两刀裁决落档（env-copy 消除【Accattoli 扁平闭包框架】+ TgtToken 零拷贝【rustc Symbol 驻留/oxc arena——错误路径独占消费】——实施/维持/换刀三选一各带论证）③六命令全绿 + B4 逐位维持。
- **首刀 MUV 3.1-a**（B 系列复测基线册）：跑 B1-B10 + B9c 全轴（release 冷跑 ×3 统计），落 performance-baseline.md Stage 3 基线行——**集成验证用例**：B4 确定性计数逐位一致断言（现有守卫）+ B10 目标面成本轴带内断言。
- **MUV 3.1-b**（env-copy 刀裁决与实施）：invoke 位点 `data.env.clone()` 消除方案权衡（逃逸分析 lite / 编译期捕获集不变性【captures 静态已知 → 共享不可变 Rc 前提】/ 维持）——若实施：VM 轴 e2e 测试 + B2 轴复测对比出册；**集成验证用例**：闭包密集程序（传递捕获 ×2 级）VM/eval 双引擎 agreement。
- **MUV 3.1-c**（TgtToken 零拷贝刀裁决与实施）：词素 `String` → 源切片 `&'src str` 或驻留（错误路径独占消费——低风险）——若实施：85 语料 sweep 全绿 + 溢出/边界负向维持；**集成验证用例**：目标面语料 sweep（composed_target_chain_tests 复用）。

#### W-3.2 FFI extern 语言面窗（B1 清偿——deep-review §14.8 B1×1 承载）【**CLOSED @ r112**——出口条件四项全过：双皮肤落位 + TD-026 再裁定落档（riding——堆类型面门条件）+ C 后端 e2e 五案（含 R-F2 计数器见证）+ 负向族全覆盖（六警察族 + E0002/E0009 + VM/eval 诊断 + 运行期双守卫）；六命令 1408:0:3 + audit 230/230；窗口记录档 w3.2-ffi-extern-window.md 单源；孪生缺口披露行钉扎（.ktf 冻结孪生——刷新归 W-3.12 段三裁定域）】
- **入口信号**：Stage 3 行权即开（三面前置全齐：R-F1..R-F4 所有权模型已定义[r90 预裁] + C ABI 二进制可用性已工作[shim 18 内建 + 语料 C 41/41] + P4 处理程度窗口[r105 裁决]）。
- **出口条件**：①语言级 extern 声明语法落位（**零语法冻结宪制约束下的语法面变更 = 须过既有门控通道**——本窗语法面经 target 皮肤 ReaderFace 扩展，S-expr 侧同步；具体形态 = extern 声明形 + 调用形，r90 R-F1..R-F4 的语言级投影[K118]）②TD-026 dangling 再裁定落档 ③C 后端消费面 e2e（extern 声明 → C 调用 → 返回值转移语义）④负向测试族（所有权四则违反面可构造者全覆盖——r105「不可构造论证」先例沿用：不可构造面以类型形状论证承载）。
- **首刀 MUV 3.2-a**（extern 声明形设计 + ReaderFace 扩展）：语法形设计（对照 K118 Rust `extern "C"` 块 + Swift import 形）→ 目标皮肤 + S-expr 双面 → 宏面豁免裁定；**集成验证用例**：extern 声明程序经全管线（read→expand→typecheck→compile→C 后端）e2e 编译执行。
- **MUV 3.2-b**（所有权检查位实施）：R-F1 边界即时物化/R-F2 调用方所有/R-F3 显式句柄根/R-F4 C ABI 对齐四则在 extern 调用位的检查落位；**集成验证用例**：R-F2 返回值转移语义 e2e（C 侧 free 义务断言）。

#### W-3.3 宏声明皮肤窗（TD-007 清偿）【**CLOSED @ r114**——出口条件三项全过：声明载体 `macro name { spec }` 落位（块形/花括号载体裁定——quote 包裹否决[匹配树漂移或位置特判] + spec datum 模式逐字承载[零隐式合成]）+ 9 语料案处置（8 案机械转正 + pos-031 转关键字经济词汇分歧钉扎[`else` 表达式位——声明修复揭示的既有边界]）+ TD-007 账面归零（[Resolved at Stage 3.3]）；六命令 1415:0:3 + audit 240/240（AH 节 +10）；窗口记录档 w3.3-macro-decl-window.md 单源】
- **入口信号**：Stage 3 行权即开（r104 消费路径裁定：生产链 = .ktf 唯一皮肤后，宏声明生产消费需目标声明面——登记时的「下一消费信号」已到期）。
- **出口条件**：①`define-syntax`/`syntax-rules` 目标皮肤声明形落位（裸表数据问题解决——规则携带目标文法面：块形/花括号载体 vs quote 包裹对照权衡）②9 语料案宏声明面（r103 账本）转正 ③TD-007 账面归零（[Resolved at Stage 3.x]）。
- **首刀 MUV 3.3-a**（声明形设计 + 载体裁定）：目标文法宏声明形设计（对照 Kotlin 操作符约定/Dylan 宏声明形——知识检索在窗内补查）→ 匹配树语义不变证明（皮肤面变更零匹配语义漂移）；**集成验证用例**：宏声明 → 展开 → 编译 e2e + 宏匹配树 parity（两皮肤）。

#### W-3.4 分代 GC 评估窗【**CLOSED @ r119**——出口条件三件全过：①B4 确定性轴语义重推导出册（D-CLASS-1 三元组等价类规范钉扎[cycle_count, swept_total, last_live_after] 纯函数口径 + D-CLASS-2 四元组双计数口径预推导登记[minor/major/promoted——实施时显式迁移禁止静默弱化]）②分代设计册（K115 三锚对照 + kerf 简化面[不可变堆纪律→ remembered set 恒空/写屏障零插入点] + 约束面[分域地址必要性]）③裁定 = **维持单代**（五发现证据链：瞬态面 marked=0 单代已最优 + 递归/构建负载 GC 窗口空 + 无老代积累——实施零收益实证否决；W-GEN-GC 登记窗 T-a/T-b/T-c 触发器锁定）；六命令 1475:0:3 + audit 250/250 维持 + 守卫族 8 件（正负比 1:3）；窗口记录档 w3.4-gc-window.md 单源】
- **入口信号**：W-3.1 完成（B 系列复测基线出册——分配压力画像决定分代优先级）。【✓ 已满足——r111 B 轴出册；r119 寿限画像补齐分配画像另一半】
- **出口条件**：①B4 确定性轴语义重推导出册（幼代 N 次 + 全代 M 次双计数口径 or 确定性等价类重定义——K115 设计约束：确定性 oracle 不可静默弱化）②分代设计册（nursery 半空间 + remembered set + 写屏障成本权衡）③裁定 = 实施（双模：分代可选 + 单代默认——§21.7 风险表缓解策略）/ 维持（单代 + 理由）。
- **首刀 MUV 3.4-a**（评估册 + B4 重推导设计）：分配寿限画像（现有语料 + B 轴数据分代假说检验）；**集成验证用例**：分代模拟断言（幼代回收不触碰老代对象集——若实施则 GC e2e 族）。

#### W-3.5 增量编译窗（cache.rs P2 做实）
- **入口信号**：W-3.1 完成；编译时长进入用户可感关切（B1/B7 轴或 LSP 前置需求——W-3.9 依赖倒逼时可提前）。
- **出口条件**：①查询化改造设计册（parse→expand→typecheck→compile 四相位查询键 + 失效传播——K119 salsa/rustc query 对照）②gate B 透明性断言（查询化路径 digest == 批处理路径 digest 逐位——fixpoint 判据不可破坏）③并行查询第二刀（演进矩阵「并行查询」）评估或实施。
- **首刀 MUV 3.5-a**（查询层骨架 + 等价模式）：查询键设计 + 单相位试点（typecheck 建议首试点——纯函数面最干净）；**集成验证用例**：同输入双路径（查询/批处理）产物逐位一致断言。

#### W-3.6 元循环求值器退役评估窗（唯一规划退役能力）【**CLOSED @ r115**——出口条件三项全过：消费面清单（七桶 33 文件 + 九符号四根全量 + fail-closed 守卫三断言——零未分类/零幻影/桶形钉扎）+ oracle 可再生性论证（三通道强度不对称——VCS 为差分唯一恢复通道）+ 裁定 = **维持**（退役否决四论据：fixpoint 宪制承重 + K15 差分活跃消费 + EVL-1 不减账 + 静默删除红线）+ W-EVAL-RETIRE 登记窗（触发器 T-a/T-b）；六命令 1418:0:3 + audit 240/240 维持；窗口记录档 w3.6-eval-retirement-window.md 单源】
- **入口信号**：Stage 3 行权即开（独立轨道——不阻塞其他窗）。
- **出口条件**：①eval 消费面全量清单（parity oracle 面 + REPL Engine::Eval 面 + 测试族 + 双引擎分派共享面[EVL-1 BuiltinHost]）②oracle 可再生性论证（退役后如需 oracle 可从 fixpoint/digest 面重建——可恢复性先于删除）③裁定 = 退役实施（独立 commit + 回滚预案）/ 维持（parity 回归价值论证）——**静默删除 = §21.7 风险表红线**。
- **首刀 MUV 3.6-a**（消费面清单册）：grep 全量 + 分类清单；**集成验证用例**：清单完备性断言（eval 符号引用零未分类残留——fail-closed 清单）。

#### W-3.7 JIT 评估窗（CLOSED @ r132 · v0.93.0——评估窗三出口全过，实施窗开启）
- **入口信号**：W-3.1 完成（profiling 数据 = stage0 §21 表 JIT 前置）+ W-3.4 裁定（GC 交互面）。✓（r111/r119）
- **出口条件**：①热点画像出册（VM dispatch-bound vs 应用-bound 测定——W-VM-SUPERINSTR 登记窗[EXC-10]一并复核：宏操作码 vs JIT 两路权衡）②tier-1 设计册（K114：VM = tier-0 基线层；方法 JIT vs 超级指令 vs cranelift 承载三路权衡）③裁定 = 实施窗开启 / 登记（触发器重定义）。✓ 全过（w3.7-jit-window.md §2b/§4/§7——EXC-10 触发器强化形态满足：开销份额 72.5% = 分派是热点本体）
- **首刀 MUV 3.7-a**（画像 + 超级指令评估）：dispatch 热点统计（现有 B 轴扩展）；**集成验证用例**：超级指令候选（若 EXC-10 开窗）语义等价断言。✓（vm_dispatch_profile harness + jit_window_tests 正向 2 四对钉扎）
- **裁定产物**：W-VM-SUPERINSTR 升格实施窗（r133+）+ W-JIT-METHOD-T1 登记窗 + cranelift 基座内否决 + W-PKG-SELFHOST 前置精确化——触发器总表 = w3.7-jit-window.md §5 单源。

#### W-3.8 后端升级评估窗（LLVM 可选——链外宪制）
- **入口信号**：W-3.2 完成（extern 面就绪）+ C 后端天花板测定需求（B9c 3.2×/6.4× 基线复测 + 发布档性能目标出现）。
- **出口条件**：①三路权衡册（扩展 C 后端[零新依赖] / LLVM 绑定[代码质量最优 + 重依赖] / cranelift[JIT 友好 + 中等]——K113 实录：cranelift 编译快但代码质量显著低于 LLVM + 内存更高）②裁定 = 单选或组合（发布档 LLVM + 开发档 C——rustc debug/release 双档先例）③**链外宪制重申**：任何外部后端不入自举链（§18 依赖审查 + 宪制条款）。
- **首刀 MUV 3.8-a**（C 后端天花板册）：优化档位设计（当前 C 发射无优化档）+ 天花板测定；**集成验证用例**：优化档 C 语料 41/41 重放。

#### W-3.9 LSP 窗（诊断框架 → IDE 集成）
- **入口信号**：W-3.5 完成（增量层 = 响应性前提——K116 rust-analyzer/salsa 形态）。
- **出口条件**：①LSP server 骨架（JSON-RPC 传输 + driver Engine 复用——零新编译器内核面）②四主面最小集（诊断 push/补全/定义跳转/悬停）③编辑器集成实测（VS Code 客户端最小用例）。
- **首刀 MUV 3.9-a**（传输层 + 诊断面）：stdio JSON-RPC + initialize/didOpen/didChange/publishDiagnostics 四方法；**集成验证用例**：didOpen → 诊断 push e2e（含 span→LSP Range 映射——LineIndex 1 基行列现有面复用）。

#### W-3.10 包管理窗【**CLOSED @ r116**——出口条件三件全过：三裁定落档（PKG-1 kerf.toml/kerf.lock TOML-micro 子集——.ktf 皮肤形/S-expr 形/完整 TOML 依赖三面弃用论证；PKG-2 Rust 构建引导层零依赖 crate——W-PKG-SELFHOST 登记窗双前置触发器；PKG-3 本地优先 libs/<name> 布局 + semver caret + 菱形全约束报错——W-PKG-MULTISRC 登记窗）+ 解析器最小集（micro_toml/manifest/semver/lockfile/resolve 五模块 + kp CLI + 测试 +49[单元 41 + 集成 8] + audit AI10 节[240→250 live]）；六命令 1467:0:3 + audit 250/250；窗口记录档 w3.10-package-window.md 单源】
- **入口信号**：Stage 3 行权即开（独立工具链面）；多文件/多包需求出现时优先级上浮。
- **出口条件**：①设计册（Cargo 三原则[K117]适配：默认 lockfile / semver / 可复现 + kerf 宪制适配——包管理器自身实现语言 = Rust 基座构建引导 vs .ktf 自举两案权衡）②manifest/lockfile 双文件形 + 解析器最小集 ③注册表策略裁定（本地优先 vs git 依赖 vs 中央注册表三路）。
- **首刀 MUV 3.10-a**（manifest 解析 + 依赖图）：kerf.toml（或 .ktf manifest 形——窗内裁定）解析 + DAG 解析器 + 环检测复用（LoadPlan 三色 DFS 先例复用）；**集成验证用例**：两包依赖解析 + 环检测 e2e。

#### W-3.11 汇聚审计轮（里程碑——非终态）【**CLOSED @ r117**——出口条件三件全过：窗口体系中期审计（§14.5 深审族适配 D1-D8 八维度[零 P0/P1/P2 + P4×1 族 E5 叙述残留当轮清偿] + §6.6 校准统计 T2.19 + 投票 5.5/5.5）+ 登记态 4 能力信号复核（零信号——继续登记）+ W-3.12 段进度核对（自举矩阵三列表 + T-b 纯度面复核点 = 零新信号——fixpoint 前端 = Rust 生产 reader 设计内形态）；六命令 1467:0:3 + audit 250/250 维持 + kp CLI 活体探针三面 + B4 第二十一次逐位；窗口记录档 w3.11-convergence-audit-window.md 单源】
- **入口信号**：≥3 窗口关闭（含 W-3.1 + 任两窗）。
- **出口条件**：窗口体系中期审计（§14.5 深审族适配形态 + §6.6 校准统计 + 投票）；登记态 4 能力信号复核（Effects 生态/多阶段/能力沙箱/DSL 生态——零信号则继续登记）；W-3.12 段进度核对（前端自举矩阵 vs BS-A 端态）。

#### W-3.12 前端自举推进窗（v1.1 增设——108-b 专审缺口清偿）
- **增设依据**：r106-b-3 已登记「下一阶段自举入口候选 = 目标 reader 段 .ktf 化评估 + TD-007」但 v1.0 十窗未承载（108-b 五源核查：十窗/登记债 8 项/§9.102/切换窗五步/roadmap §2 零提及——规划缺口成立）；用户硬规则（每轮常设指令）：「一个编译阶段完整自举后才能进入下一个编译阶段的自举（如 reader 完整完全自举后才能进入下一个阶段的自举），不能降级自举，不能功能设计实现都不完整」+ BS-A 端态（§9.25.2：前端三段 + HM 判定面 + 构建编排全自举 + VM 永久基座）与实况差距（108-b 实测：read/expand/typecheck/compile 四段生产面全 Rust 引擎承载，.ktf 孪生仅验证面，HM/构建编排零孪生）无收敛路径窗口。
- **知识层**：K120-K123（stage0.md §9.103——rustc 三段自举 + stage0 种子链恒存[rustc_lexer 自宿主经 stage 链] / Chez pb bootfiles 自举 / Guile psyntax-pp 预展开冻结种子[与 .ktf 孪生同构] / Racket #lang reader = Racket 模块）。
- **入口信号**：Stage 3 行权即开（独立轨道——与性能/语言面窗无依赖；段内每段自成门）。
- **段序（硬规则锁定——不可倒置）**：
  1. **段一 reader 完整自举**：reader.ktf + lexer.ktf 从组成链级验证面升格为生产面（生产桥 read 步切换至自举 reader——或经 gate B 同构门证明字节级等价后切换）；Rust read_program 退役为 BS-A 种子链 oracle（验证面保留）；段门 = 全语料两皮肤清场 + parity 门 + reader 段 fixpoint（自举 reader 读自身源码产物 == Rust oracle 产物，逐位）+ 六命令全绿。
  2. **段二 expander 完整自举**（段一门后才可开）：macro.ktf + expander.ktf 同形制升格；段门 = 展开树 parity + expander 段 fixpoint + TD-007 宏声明面（与 W-3.3 联动——声明形在两皮肤的等价证明）。
  3. **段三 HM/构建编排裁定**（段二门后才可开）：显式裁定 = 补 .ktf 孪生（kerf 孪生谱系扩容）**或**宪法性排除（同 VM 永久基座形制——验证面/构建引导宪制归属，§1.2 口径同步修订）；裁定两案权衡落档（维护成本/自举链深度/「100% 自我演化」口径的诚实性）。
- **出口条件**（整窗）：①自举矩阵终态落档（每段：生产引擎/验证 oracle/fixpoint 门三列）②§1.2 语言占比口径的收敛或重定义（若段三裁定排除——诚实登记 Rust 份额 = VM + 构建引导 + 链外后端 + 【排除段】）③六命令全绿 + gate B/fixpoint 全窗永续维持（§1.2 判据）④TD 登记面归零或触发器重定义。
- **首刀 MUV 3.12-a**（reader 段升格评估册）：现状测量（reader.ktf 生产化差距清单：性能预算[.ktf reader on VM vs Rust target.rs 读路径成本] + 注入通道生产化改造面 + parity 门完备性）+ 升格/维持/换刀三选一论证；**集成验证用例**：自举 reader 读 85 语料两皮肤 sweep 与 Rust oracle 逐位一致断言。
- **风险表**（§21.7 适配）：①生产读路径性能回退（.ktf reader 经 VM 执行 vs 原生 Rust——测量先行，回退超带则维持 Rust 生产位 + 登记触发器）②段门倒置诱惑（用户硬规则禁止——段二段三在段一门前的任何实施 = 违规）③双重实现维护成本（孪生已存在——验证面成本已在付，升格净增 = 生产化改造非第二实现）④拆除边界（Rust reader 退役 = BS-A 种子链保留形制，非删除——与 E5 先例同构）。

### 2.4 Step 5 设计-开发-测试节点流（三节点递进——每窗同构）

以 W-3.2 为例（其余窗同构套用）：设计节点（extern 形设计 + R-F1..R-F4 投影表 + 门审 ≥30 case 计划）→ 开发节点（ReaderFace 扩展主任务 + expander/typecheck/compiler 消费面次任务 + C 后端调用位）→ 测试节点（阶段 1 单元：声明形解析正负；阶段 2 集成：全管线 e2e；阶段 3 parity：两皮肤匹配树一致；阶段 4 负向：所有权违反面；阶段 5 门审：≥30 case + 7 类错误覆盖 + 上轮修复边界 case）。

### 2.5 Step 6 缺陷纳入（登记债 → 修复任务节点映射）

| 登记项 | 来源 | 纳入窗口 | 清偿形态 |
|---|---|---|---|
| TD-007 宏声明皮肤 | tech-debt-register §2 | W-3.3 | 账面归零（Resolved at Stage 3.3） |
| W-PERF-ENV-COPY | r106 登记 | W-3.1 MUV 3.1-b | 实施/维持裁决 + 账面归零或触发器重定义 |
| W-TGT-TOKEN-ZERO-COPY | r106 登记 | W-3.1 MUV 3.1-c | 同上 |
| W-DRIVER-HARNESS-SPLIT | r106 登记（观察态） | 全窗口骑乘 | 触发器（harness +30%/新验证域）出现时独立 MUV |
| B1（FFI extern） | deep-review-round2.8 §14.8 | W-3.2 | 偏差清单闭合（实现 < 设计 → 实现 = 设计） |
| TD-026（FFI dangling 再裁定） | stage0 §9 存档 | W-3.2 出口条件 ② | 裁定落档 |
| W-VM-SUPERINSTR（EXC-10） | **开启（实施窗）@ r132**——触发器强化形态满足（开销份额 72.5%）；实施体 r133+（静态单相融合 + F1 直发算术刀）；裁决单源 w3.7-jit-window.md §4.3 | W-VM-SUPERINSTR 实施窗 | 融合交付后复画像（W-JIT-METHOD-T1 触发器输入） |
| alpha_rename Result 化（K111 登记 Stage 3 破坏窗） | r106 K111 | W-3.1/任意破坏窗 | 公共签名变更窗（消费者全为合法文本构造者——低风险） |
| W-BOOT-FRONTEND（前端自举推进缺口本体） | r108 108-b 专审登记 | W-3.12（v1.1 增设） | 段一 reader 升格评估首刀 + 段序硬规则锁定 |
| W-EVAL-RETIRE（元循环求值器退役议程） | r115 W-3.6 评估窗裁定登记 | 触发器 T-a/T-b 任一达成时重开 | 维持裁定 + 等位 oracle 前置 + 静默删除三前置永续 |
| W-DIAG-OPCODE-CONTEXT（运行期上下文操作码词汇面） | r108 108-b 登记（r108 FIX-1 已清偿内建名/用户名皮肤感知；残留 = 操作码上下文如「add operand」→表面构造感知） | W-3.9（LSP 诊断窗候选设计节） | 结构化诊断载荷设计时一并承载 |
| W-PKG-SELFHOST（包管理器 .ktf 自举位） | r116 W-3.10 PKG-2 裁定登记；r132 前置精确化 | 触发器双前置（**W-VM-SUPERINSTR 融合刀交付后**[r132 精确化——方法 JIT 非必要前置] + 功能冻结）达成时 | 自举重写窗开窗 |
| W-PKG-MULTISRC（多源选择/显式 path/git/注册表） | r116 W-3.10 PKG-3 裁定登记 | 多机协作 / 发布分发需求出现 | MVS[K138] + 注册表窗开窗 |

### 2.6 Step 7 审查结论

- **依赖图核查**：DAG 无环 ✓（拓扑序存在；v1.1 增 W-3.12 无环验证——独立入口边 + W-3.11 汇聚边）；六首刀窗（3.1/3.2/3.3/3.6/3.10/3.12）无相互依赖可并行 ✓；宪法依赖（gate B/fixpoint/B4 轴）全窗声明 ✓。
- **缺陷纳入核查**：登记债 8 项全映射 ✓（无未纳入登记项）+ v1.1 增补：W-BOOT-FRONTEND/W-DIAG-OPCODE-CONTEXT 两项入 W-3.12/W-3.9 ✓。
- **设计-开发-测试锚定核查**：每窗首刀 MUV 含 ≥1 集成验证用例 ✓。
- **REV-A 一致性审查**：与 roadmap §2/§5、stage0 §21.5/§9.102、tech-debt-register 三源交叉一致 ✓；时间治理四红线继承声明 ✓。
- **结论**：**GO**（规划轮产出验收通过——实施入口待行权 §0.2）。

## 3. §13.1 设计文档对齐小节

| 对齐项 | 内容 |
|---|---|
| 设计文档章节 | stage0.md §21.5（演进矩阵）/§21.6（三决策点）/§21.7（风险表）/§21.9（预留成本）/§15（FFI 所有权 R-F1..R-F4 预裁面）/§9.102（本轮知识层 K113-K119）；lang-design/ 已存档——存档侧镜像代偿（roadmap §5 注记先例） |
| 设计意图摘要 | Stage 3+ = 冻结内核之上的持续演化：性能三路（GC/JIT/增量）+ 语言面清偿（FFI/宏声明）+ 工具链（LSP/包管理）+ 唯一退役评估（eval）——窗口体系承载，四红线约束 |
| 已实现项 | C ABI 二进制面（shim + 语料 C 41/41）/ R-F1..R-F4 所有权模型（预裁）/ cache.rs P2 接口 + 行为规格 / 诊断 E0xxx 全注册 / ReaderFace 双皮肤架构 / fixpoint + digest 判据面 |
| 偏差项 | **B1×1**：FFI 源级 extern 设计（P4）与实现（零）偏差——本档 W-3.2 承载清偿（§14.8 回写义务闭合） |
| 未实现项 | 分代 GC / JIT / 增量编译 / LSP / 包管理 / 宏声明皮肤——全部为本阶段窗口目标（§2.3） |
| 灰区决策 | ①eval 退役 = 评估窗非默认动作（可再生性前提）②外部后端 = 链外叶子（永不入自举链）③登记态 4 能力零预支（信号定义 = 未来设计工作）④包管理器实现语言两案（窗内裁定）⑤B4 确定性轴重推导先于分代实施（oracle 不可静默弱化） |

## 4. §21.7 成熟度重核对（Stage 3+ 适配风险表）

单源引用 stage0.md §9.102.2 第 5 条（六行风险表：刀法失效/分代破坏 B4 oracle/增量化破坏 fixpoint/外部后端缺陷/窗口合并诱惑/静默删除）——本档不重复；触发信号出现即按既定缓解行动，不重新展开决策。

## 5. 首刀排期（行权后第一轮——W-3.1 性能地基窗 ∥ W-3.12 段一首刀）

**r123 落地实录**（v2.2）：W-CSYM-EXPR 能力裁定窗 ✓（123-a 知识检索层[r123-search 六检索件存档——q2/q4/q6 强锚 K143-K145 + q1/q3/q5 弱查噪音如实披露] + 123-b 三选一裁定 = **路径 b C 域谓词架构重归属**[三候选带论证——路径 a 宪法级提案选项登记不实施 / 路径 c 维持 r122 否决；K143-K145 + K121/K122 四先例同向] + 123-c 实施[expander 两面退位 + `extern_table_floor` 单源双裁判 + `CompileError` 三分裂名载荷 + subject_symbols 扩展 + `compile-error` 期望种类（parity.rs + subset-spec.md 文法行）+ neg-062 重分类 + 组合链台账迁移[junction-2 不可表达边界退役 → junction-3 编译孪生记录盲族] + 稳态 sweep 披露行退役 + audit AL 族 10 案 270→280 + TEST-3 共变] + 123-d 段二升格重裁 = **ELEVATED**（判据①①②③全过——w3.12 §6d）+ 123-e 文档族 + v0.85.0 锁步）——窗口记录档 `docs/develop/v3/w3.12-frontend-window.md` v4.0 §6c/§6d 单源；下一入口 **段三 HM/构建编排裁定窗**（HM 推断 + 构建编排的孪生可行性裁定 + junction-3 编译孪生 extern 记录盲议程；知识搜索义务：rustc typeck/GHC 推断引擎自举形态[K124/K122 既有锚起点]）+ W-3.5/W-3.8 从属位维持。

**r124 落地实录**（v2.3）：段三裁定窗 ✓（124-a 检索层[r124-search 九件存档——q1-q7 + m1/m2；q1/q4 弱查披露第十六轮] + 124-b 三议题分面裁定[构建编排 = 宪法性排除 / HM = 补孪生确认 + W-HM-TWIN 登记 / junction-3 = 当轮清偿] + 124-c 实施[compiler_parity.rs emit 修复 + oracle/dump/rebuild 三面 externs 段 + compiler.ktf cp_extern_walk 消费臂 + 组合链语义分流 3→1 + runner AM 族 5 案 + audit AM 族 10 案 280→290 + eval ledger E 桶 17/总 36 + test_infra 组成 290] + 实施自纠两件如实登记[cp_extern_walk 初版置于 cp_ewalk 后 unbound——kerf 严格先定义后引用惯例实测确认后移位 helpers 区 258；cp_nth 0-based 初版 i+1 越界 first(nil) 崩——勘正] + 守卫两件如实披露[eval 面清单拦截 + audit 头条同步]）——窗口记录档 `docs/develop/v3/w3.12-frontend-window.md` v5.0 §6e 单源；**段三升格 = NOT ELEVATED**；下一入口 **W-HM-TWIN 实施窗**（自举阶梯最高优先维持——HM 判定面孪生化 ~2,500-3,500 行 .ktf；知识搜索义务：HM 推断器 .ktf 形态设计[K124/q3 OCaml 先例起点]）+ W-3.5/W-3.8 从属位维持。

**r126 落地实录**（v2.4）：W-HM-TWIN 开启轮 ✓（126-a 知识检索层[r126-search 六检索件存档——q4/q5 强锚 + q1/q6 中强 + q2/q3 弱查噪音第十七轮；K146《Typing Haskell in Haskell》正典先例 + K147 rustc_hir_typeck 主源 + K148 cs3110 约束两相 + K149 union-find 形态谱系] + 126-b 形态裁定 TWIN-1..5[selfhost/v1/infer.ktf ~1,500-2,200 行 + typecheck.ktf ~1,000-1,300 行 + INJ-1 item 记录通道复用零新原语 + SteadyTypecheckChain 编译一次每推断注入 + parity 三面 r124 externs 段先例形制] + 126-c 排期 127-a..e[MUV 边界切轮——1-2 完整轮次工程量禁止降级；每 MUV ≥1 集成验证用例] + 126-d 文档族[窗口档 w-hm-twin-window.md v1.0 新建 + register/roadmap v2.58/本档 v2.4/stage0 §9.116 + RELEASE_NOTES + Cargo 金链 v0.87.0]）——纯文档域轮（零生产代码变更——唯一代码面 = ds08 版本钉扎注记）；段三 NOT ELEVATED 维持；下一入口 **W-HM-TWIN 实施体 r127+**（127-a infer.ktf 主体首刀[类型表示 + 迭代 W + undo-log + SCC 分治 + 泛化 + Externals 边界]）+ W-3.5/W-3.8 从属位维持。

**r122 落地实录**（v2.1）：W-3.12 段二实施窗 ✓（122-a 自举文件目录统一[`bootstrap/` 九文件迁移 + `target_skin.rs` 拆分 + ~45 位点路径共变 + eval 消费面守卫拦截后清单共变——1491:0:3 逐位] + 122-b 段二稳态链[`steady_expander_chain.rs` + `forms_stream_literal` 记录文法值面 + 集成 9 件 + w312b 测量面] + 122-b2 孪生刷新[expander.ktf extern 警察五面 + 种子 + 碰撞遍 + ex_inmod；expander_parity.rs 三臂四错误类；组合链 extern 台账行 6→3 共变] + items 前缀 extern 编码修复[逗号分裂→引号字符串形] + 122-e 段二升格重裁 = **NOT ELEVATED**（判据①未过——C 符号两派生面不可表达；W-CSYM-EXPR 登记） + 122-f 文档族 + v0.84.0 锁步）——窗口记录档 `docs/develop/v3/w3.12-frontend-window.md` v3.0 单源；下一入口 **W-CSYM-EXPR 能力裁定窗**（三候选路径：冻结子集能力扩展[宪法级] / C 域谓词重归属[oracle 语义重推导] / 载荷结构化[已论证否决]——知识搜索义务：Guile psyntax/Chez 字符原语自举形态）+ W-3.12 段二升格重裁（W-CSYM-EXPR 裁定后）+ 段三维持锁。

**r121 落地实录**（v2.0）：W-3.12 段一实施窗 ✓（121-a §18 审查 + INJ-1..INJ-5 设计裁定 + 121-b 注入通道实施[kerf-vm/kerf-runtime `inject_global` + `InjectGlobalUnknown` fail-closed + kerf-expander `expand_program_with_injected` + kerf-driver 管线接受面 + 检查器 externals 扩展——引擎测试 9 件] + 121-c 稳态链实施[`bootstrap_chain.rs` + 集成 6 件 + 测量面 productionized 相位] + 121-d 段一升格重裁 = ELEVATED + 121-e 文档族 + v0.83.0 锁步）——窗口记录档 `docs/develop/v3/w3.12-frontend-window.md` v2.0 单源；下一入口 **W-3.12 段二 expander 完整自举实施窗**（段门：展开树 parity + expander 段 fixpoint + TD-007 两皮肤等价[W-3.3 先例]；注入通道 form 记录载荷 = 同一 `inject_global` 通解）。
**r120 落地实录**（v1.9）：指令吸收轮 ✓（120-a 知识层 K140-K142 三新锚[Go 1.5 双链解耦实证——接受 ~10× 回退换切换 / rustc 2011 自举先于 0.1 公开与 1.0 稳定 / bootstrappable builds 链完备即目标] + K120-K123 升格活跃参考 + 120-b SOP v15.3[§21.12-28 自举完备优先纪律 + §1.2/§1.3/§13.1.2/§17.3 四接线点 + §16.1 行] + 120-c stage0 §9.113[缺口分析：注入通道生产化缺失 / HM+编排零孪生 / 双链已解耦(SOP 修正) / 自举链工程可用性] + 120-d 排期重排[本档 v1.9 + roadmap v2.53 + w3.12 档 v1.1 T-b 激活 + tech-debt W-BOOT-FRONTEND 触发器更新]）——纯文档轮零生产代码变更（1475:0:3 维持）；**下一入口 W-3.12 段一实施窗**（SOP v15.3 §21.12-28 首要入口裁定）；W-3.5/W-3.8 从属位。
**r119 落地实录**（v1.8）：W-3.4 ✓（119-a 分配寿限画像[gc_lifetime_profile example + tool-results/r119 归档——churn 100% 首轮死亡率×9cycle/纪元加宽不敏感 + iota live_usage 恒平坦 + fib 帧下限 fail-closed——五发现 F1-F5] + 119-b B4 重推导出册[D-CLASS-1 等价类钉扎 + D-CLASS-2 预推导登记] + 119-c 分代设计册与三选一裁定 = 维持单代[K115 三锚对照 + 不可变堆纪律结构性前提入册 + W-GEN-GC 登记窗三触发器] + 119-d 守卫族 8 件[gc_window_tests.rs——D-CLASS-1 三元组/隔离模拟/操作码零 mutation 守卫/生产零 get_mut 守卫/帧下限双极 fail-closed/0.6 面回归/跨堆死引用跳过] + 119-e 文档族 + v0.81.0 锁步）——窗口记录档 `docs/develop/v3/w3.4-gc-window.md`；下一入口 **W-3.5 增量编译窗**（双首刀另一翼——入口就绪维持）+ W-3.8 裁量位 + W-3.12 段二/段三锁定维持。
**r117 落地实录**（v1.7）：W-3.11 ✓（117-a 基线复现[温缓存六命令逐位 + B4 1/1023 第二十一次 + B10 1.02x 带内 + kp CLI 正/环/菱形三面活体探针 + lockfile 双跑确定性] + 117-b/c 深审族适配 D1-D8[零 P0/P1/P2 + P4×1 族] + 登记态 4 能力零信号复核 + W-3.12 段进度三列表[T-b 纯度面 = 零新信号] + 117-d E5 叙述残留清偿[parity 族四头注重写 + 断链/死名引用 ×7 + ktf_ 标识符方案 ~100 位点——六文件 +239/−225 零行为变更] + 117-e 校准 T2.19 + 文档族九件 + v0.80.0 锁步三处）——窗口记录档 `docs/develop/v3/w3.11-convergence-audit-window.md`；下一入口 **W-3.4 分代 GC ∥ W-3.5 增量编译双首刀**（D4 就绪度表全绿）+ W-3.8 裁量位 + W-3.12 段二/段三锁定维持。
**r116 落地实录**（v1.6）：W-3.10 ✓（PKG-1/2/3 三裁定 + kerf-pkg 零依赖 crate[micro_toml 168 行 + manifest 220 + semver 130 + lockfile 240 + resolve 236 + error 134 + lib 40] + kp CLI + 测试面 +49[单元 41 + 集成 8——两包 e2e/传递链/环/菱形/lockfile 消费五集成] + audit AI10 节[240→250 live] + 登记窗两件[W-PKG-SELFHOST/W-PKG-MULTISRC]）——窗口记录档 `docs/develop/v3/w3.10-package-window.md`；**首波六窗全关**（W-3.1 r111 / W-3.2 r112 / W-3.3 r114 / W-3.6 r115 / W-3.10 r116 + W-3.12 段一 r111）

**r115 落地实录**（v1.5）：W-3.6 ✓（3.6-a 消费面清单册：七桶 33 文件 + 九符号四根全量 + fail-closed 守卫 `tests/v1/stage1/plan/eval_inventory_guard_tests.rs` 三断言 + 可再生性三通道论证 + 三选一裁定 = 维持 + W-EVAL-RETIRE 登记窗触发器 T-a/T-b）——窗口记录档 `docs/develop/v3/w3.6-eval-retirement-window.md`。

**r111 落地实录**（v1.2）：3.1-a ✓（三跑基线册）+ 3.1-b ✓（裁决 = 实施——Rc 共享不可变，B6d 141.7→108.4ns）+ 3.1-c ✓（裁决 = 实施——`&'src str` 零拷贝）+ W-3.12 段一 ✓（3.12-a 评估册：维持 + 触发器重定义——测量 vm/rust 450×）——两窗记录档 `docs/develop/v3/w3.1-performance-window.md` / `w3.12-frontend-window.md`；W-3.4 入口条件（B 系列基线出册 + 分配画像）就绪。

| MUV | 内容 | 验收 |
|---|---|---|
| 3.1-a | B 系列全轴复测基线册 | ✓ performance-baseline Stage 3 行 + B4 逐位断言 + B10 带内断言 |
| 3.1-b | env-copy 刀裁决（+实施若裁决通过） | ✓ 裁决 = 实施（B2 对比出册 + 双引擎 agreement 在套件 + B6d 新轴） |
| 3.1-c | TgtToken 零拷贝刀裁决（+实施若通过） | ✓ 裁决 = 实施（85 语料 sweep + 负向维持 + audit 共变） |
| 3.12-a | reader 段升格评估册 | ✓ 三选一 = 维持（测量先行：450× 超带）+ 触发器重定义 |
| 收口 | 门审 + 投票 + 文档族 + web + §19 | 六命令全绿 + ≥95% + worklog 双侧 |

**后续窗口排期原则**：拓扑序 + 单窗口单轮（或窗内多轮——窗体量裁量）；每窗开窗轮重走 §17 Step 1 扫描（窗口面文档对齐）——本档为窗口体系的母规划，窗内细则窗轮承载。

## 6. 谱系与登记

- 本档 = Stage 3+ 第一份阶段计划（v1.0——r107 规划轮落档）；后续修订沿 §8.6 追加式（Status 行版本链）。
- 知识层单源：stage0.md §9.102（K113-K119）；校准行：calibration-data.md T2.10（r107 规划轮行——待落档）。
- 8 原语不变性：第七十四轮验证维持（规划轮零机制变更）。

# W-JIT-METHOD-T1 方法 JIT 实施窗——tier-0.5 收尾、共享基座与 tier-1 分工（w-jit-method-t1-window.md）

> **Status**: CLOSED（v1.2——r142 tier-1 刀 2 轮〔窗口出口轮〕：**§8 刀 2 实测裁定 MJ-5/MJ-6**〔MJ-5 生产默认 = 纯解释——三跑 B 轴对照实测 closure chain 净负 ~9%（ratio 1.106/1.091/1.076）→ `Vm::new` 默认翻转为 `METHOD_TIER_DISABLED`（u32::MAX）+ note_invoke early-out 零成本关闭态 + METHOD_HOT_THRESHOLD 转为 opt-in 推荐阈值；机制保留 = opt-in 验证面 + W-3.8 链外 codegen 窗基座资产〕+ **MJ-6 窗口出口裁定 = 带缺口登记关闭**〔三触发器复画像生产位口径：B2 66.1ms = 2.79× 带（阈 1.8×）未清 / 分派份额 64.2%（阈 40%）未清 / T-a 链路 ~339×（阈 25×）未清——消除杠杆（真 codegen）在链外（W-3.8 可选位——零 codegen 约束下 27 臂 match 解释器即最优分派形态，K152/K157 实测兑现）〕+ 测量面升级〔vm_dispatch_profile 双臂对照——每负载 tier-on/tier-off 双计时 + ratio 行〕+ 测试族 blade-2 六件（正 2/负 4）+ audit AX 族 10 案（390→400 · 48→49 节）+ TEST-3 共变 + v0.103.0 金链锁步；v1.1——r141 tier-1 刀 1 轮：§7 刀级四裁定 MJ-1..MJ-4；v1.0——r135 开窗轮：§2 窗内第一议题裁定 TJ-1..TJ-5 + §3 首刀排期；上游裁定 = w3.7-jit-window.md §4.3-2〔r132 评估窗〕+ r134 三触发器全命中）
> **流程权威**: docs/sop.md（§21.7 风险表 / §12 最优>最小 / §2.3-3 猜测或 hack 禁止 / §18 零外部依赖纪律〔cranelift 基座内否决 @ r132 终结——链外实验位经 W-3.8 承载〕/ §4 MUV 边界切轮纪律〔禁止降级交付——r126 先例〕/ §21.12-28 自举完备优先纪律〔本窗 = T-a 生产位切换链路性能前置〕）
> **依据**: w3.7-jit-window.md v1.0 全档（§2b 画像 + §3 K150-K156 + §4.3 裁定三段）；w-vm-superinstr-window.md v1.2（CLOSED——B 轴终账 0.75× + 带缺口 4.1ms + 第三杠杆 20% 在册）；bootstrap-completion-plan.md（自举完备总规划——本窗在其窗口序列中的位置单源）；stage0.md §9.121（K157-K162）+ §9.127（MJ-1..MJ-4）+ §9.128（MJ-5/MJ-6）；tool-results/r134/r135/r142-dispatch-profile-run{1,2,3}（三跑画像序列——裁定输入链）
> **测量单源**: `tool-results/r142-dispatch-profile-run{1,2,3}.txt`（刀 2 双臂对照三跑——本窗终账）；守卫单源 = `tests/v1/stage1/plan/method_jit_window_tests.rs`（r135 族 + r141 tier 族 + r142 blade-2 族）+ `tests/v1/stage1/plan/test_infra_guard_tests.rs`（TEST-3 · 400/400）

## 1. 开窗时点实态（r134 闭合态代码事实）

| 面 | 实态 | 依据位 |
|---|---|---|
| 三触发器 | ①B2 = 61.8ms = 2.60× C-O0 带（阈值 1.8× = 42.66ms）命中 ②解释器开销份额 61.5%（阈值 40%）命中 ③T-a 链路 ~450×/1.327 ≈ 339×（阈值 25×）命中——**全命中开窗** | w-vm-superinstr-window v1.2 §3.2 |
| B 轴基线 | fib-25 2,427,852 指令 / 61.544-61.963ms 三跑稳定（两刀 -25.0%）/ 25.35ns/指令 / 融合覆盖完美对天花板 75.0% | r134 画像三件 |
| 第三杠杆 | (load-local + push-const) 相邻对 485,569 = 20.0%（fib 内）——K151 经典复制对（纯数据移动、零语义交互、零错误面）——r134 预估 ~12ms 可达 ~0.60× | r134 画像 + r134 工作日志带缺口登记 |
| 余量对 | (push-const + call-global) 10.0% / (call-global + jump-if-false) 10.0% / (sub + call-global) 10.0% / (push-const + sub) 10.0% / (jump-if-false + load-local) 5.0% / (load-local + ret) 5.0% / (add + ret) 5.0%——**全部含控制流/调用成分** | r134 画像对表 |
| 操作码面 | 26（CallGlobal @ r133 尾插 25）——「about 35」能力模型裕量 9 | opcode.rs `ALL` 钉扎 |
| 深度帽 | eval/VM 闭包应用共账 EVAL_DEPTH_LIMIT 2048（r134 实证：fixpoint 自身源码数千记录线性遍历爆预算→改道 cp_assemble 搭载式扫描）；reader 256 / expander 512 / compiler 1024 / pkg-resolve 512 | eval.rs:61 + 原则 58 四层谱系 |
| T-a 链路 | 生产位全 Rust（read/expand/check/compile）；孪生七件 parity 位级 + fixpoint 自复现但生产位未切；~339× 慢带 | w3.12 §5 T-a 行 + §6 诚实边界 |
| 结构缺口 | **目标皮肤读链孪生不存在**（.ktf 文本→树仅 Rust `read_target_program`——生产桥 read 步；w3.12 §6 诚实边界登记「段三裁定域的靶面之一」但 r124 三议题未含、未开窗） | w3.12-frontend-window.md:94 |

## 2. 窗内第一议题裁定（TJ-1..TJ-5——ARCH-A @ r135，知识层 K150-K156 + K157-K162）

### TJ-1 tier 序维持 = tier-0.5 收尾先于 tier-1（K154 阶梯 + 残量清账）

**裁定**：首刀 = **tier-0.5 融合层收尾刀**（第三杠杆 load-local+push-const 复制对融合），tier-1 方法 JIT 后置至共享基座（TJ-3）落位后。**四依据**：

1. **K154 tier 序列**（tier-0 解释器 → tier-0.5 融合 → tier-1 方法 JIT）：融合层收尾后 tier-1 的基线画像干净（余量对全含控制流/调用成分——见 TJ-2 裁定它们归 tier-1 吸收而非继续逐对融合）。
2. **数据在册**：第三杠杆 20% 对覆盖、~12ms 预估（r134 复画像三件单源）——零运行期反馈、零帧架构触碰、r133/r134 两刀直接形制先例（opcode + VM + verify + C 后端 + compile + 孪生 + 守卫再生成 + audit + B 轴）。
3. **正交性**：复制对融合 = 纯数据移动指令（零错误面/零名字解析/零帧语义）——与 TJ-3 共享基座（激活记录架构变更）零交集，先做不返工。
4. **MUV 边界切轮**：tier-1 方法 JIT = 2-3 完整轮次工程量（方法编译基础设施 + 分派集成 + 回退路径 + 守卫族）——r135 单轮内不可完整交付；第三杠杆单刀完整（r133/r134 先例尺度）。

### TJ-2 余量对归 tier-1 吸收（tier-0.5 到此收刀）

**裁定**：(push-const + call-global) / (call-global + jump-if-false) / (sub + call-global) / (push-const + sub) 等含调用/控制流成分的对**不再逐对融合**——tier-0.5 融合层以第三杠杆收刀。**三依据**：

1. **语义交互面**：调用位对（callee 栈契约 / argc 语义 / 错误族迁移）与跳转位对（分支头 = 跳转目标安全论证义务）使逐对融合的等价论证成本陡增，收益递减（每对 ≤10% vs 首对 25.9%）。
2. **K157 Sparkplug 重定义**（r135 知识层）：「Sparkplug 形态」的价值 = **消除逐指令分派 + 缩短 tier-up 延迟**，两者都不要求原生 codegen——方法级编译把整个基本块一次走完，块内全部相邻对（含调用/跳转位）自然吸收——逐对融合是它的低阶子集。
3. **负收益警戒**：Ertl&Gregg（K151）融合收益集中于头部复制对；尾部对融合 = 分派表膨胀（match 臂 × 操作码基数）而命中密度低。

### TJ-3 共享基座耦合 = tier-1 构建于 W-REC-DEPTH 激活记录架构之上（单一机制规划）

**裁定**：tier-1 的方法执行路径（closure chain / threaded code——K158 零 codegen 家族）与**任意递归深度通解**（W-REC-DEPTH——用户常设指令显式纳入规划）共享同一架构变更：**VM 自有堆激活栈**（激活记录从宿主栈搬到堆）。**排期耦合**：W-REC-DEPTH 先行（r136+），tier-1 构建于其上（r137+）。**三依据**：

1. **K160 归一**：trampoline / 显式栈 / 堆帧三机制本质同一（激活记录堆化——深度由内存预算治理非固定整数）；Rust 无保证 TCO → 显式循环/trampoline 是可移植答案（K160-q4b）。
2. **重复施工警戒**：closure chain 方法执行路径自带帧管理；若 tier-1 先行在既有 EVAL_DEPTH_LIMIT 2048 共账架构上施工，W-REC-DEPTH 落地时帧管理重写 = 同一面两次施工（§2.3 唯一可信数据源反面）。
3. **fixpoint 实证**：r134 孪生毒化扫描首版爆 eval 深度预算（每闭包应用 +1）——自举链工程可用性已被深度帽实际约束（VM-only 括号先例）；深度通解 = T-a 组合面的必要件非独立优化。

### TJ-4 tier-1 形态 = 去分派方法执行层（Sparkplug 1:1 重定义——K153 + K157）

**裁定**：tier-1 = **方法级去分派执行层**：热点函数（census 热函数集中 99.9998%——F5 画像）的字节码在方法粒度编译为 Rust 侧单步少分派执行形（closure chain / 分派子集内联），非优化、非原生 codegen、确定性构造保持（同一 Bytecode 恒同编译产物）。**边界**：零外部依赖维持（§18）；元追踪族否决维持（K156）；cranelift 基座内否决维持（r132 终结）。**验收对照基线 = tier-0.5 收尾后的 B 轴**（非 r134 基线——TJ-1 依 3）。

### TJ-5 T-a 组合面诚实预期（窗口边界声明）

三触发器清账为**本窗出口条件**（§4）；T-a <10× 目标**不能仅靠 VM 提速达成**（w3.7 §4.3 诚实登记维持：JIT 2.5-3× → T-a ~90-135× 仍 >>10×）。T-a 切换窗需组合面：VM 提速（本窗 + W-REC-DEPTH 深度约束解除）× 自举链工程可用性（目标皮肤读链孪生 W-TGT-READ-TWIN + 稳态链摊销扩展）× 生产链对照口径（种子→全量→自重建不动点管线——K159）。**本窗不承诺 T-a 达标**——组合面规划单源 = bootstrap-completion-plan.md。

## 3. 切轮排期（MUV 边界——禁止降级交付）

| 轮 | MUV | 范围 |
|---|---|---|
| **r135**（首刀 = tier-0.5 收尾） | 135-a 开窗档 + 自举完备总规划（bootstrap-completion-plan.md v1.0 + W-REC-DEPTH/W-TGT-READ-TWIN 登记 + W-PKG-SELFHOST 触发器反冻结重审）+ 135-b LLC 融合全链（opcode 27 化〔`load-local-const` a=slot b=const-idx，pops 0/pushes 2——Dup pushes=2 先例〕+ VM 双压臂 + verify Pass 1 双边界 + .krf 往返 + C 后端复合 + compile args 环视特判〔结构安全论证：args 列内部位永非分支头——消除位免分类器〕+ compiler.ktf 孪生同步）+ 守卫再生成（jit_window census 锚 + 快照黄金族）+ 新族 method_jit_window_tests ≥8 件 + audit AQ 族 10 案 + B 轴复画像三跑 + 文档族 + v0.96.0 锁步 + GATE 1 + 投票 + commit | **复制对 20% 收尾——tier-0.5 收刀** |
| **r136+** | W-REC-DEPTH 共享基座（堆激活栈 + 显式循环——TJ-3；独立窗单源 bootstrap-completion-plan §4.2） | tier-1 前置 |
| **r137+** | tier-1 方法 JIT 实施体（TJ-4 形态——方法编译基础设施 + tier 分派集成 + 回退路径 + 守卫族 + audit + B 轴对照 tier-0.5 收尾基线） | 窗口核心交付 |
| **r141 ✓** | tier-1 刀 1 @ v0.102.0（§7 四裁定 MJ-1..MJ-4 + 实施全链 + 新族 8〔2:6〕+ audit AW 10〔380→390〕+ 1607:0:4 + 六命令冷跑全绿——交付范围声明见 §7 末段：B 轴对照/守卫族再生成/三触发器复画像 = 刀 2） | 刀 1 闭合 |
| **r142 ✓** | tier-1 刀 2 @ v0.103.0（§8 实测裁定 MJ-5/MJ-6 + 测量面升级〔双臂对照〕+ B 轴三跑 + 三触发器复画像 + blade-2 测试族六件〔2:4〕+ audit AX 10〔390→400 · 49 节〕+ 生产默认翻转 + 文档族 + 六命令冷跑全绿） | **刀 2 闭合 = 窗口出口（带缺口登记——§8 MJ-6）** |

## 3.1 首刀诚实账（r135 B 轴复画像三跑——tool-results/r135-dispatch-profile-run{1,2,3}.txt）

| 指标 | r134 基线 | r135 实测 | 判读 |
|---|---|---|---|
| fib-25 指令数 | 2,427,852 | **1,942,283（-20.0% 精确兑现）** | 485,569 复制对逐位消除——融合发射面行为与画像预测逐位吻合 |
| 中位时耗 | 61.544/61.815/61.963ms | **63.601/63.816/63.466ms（+3% 回退）** | r134 预估 ~12ms 节余（→0.60×）**未兑现**——复制对的分派节余被每指令成本升幅（25.35→32.75ns）抵消：消除的是最廉价指令（纯数据移动），剩余指令混合的均值成本自然上浮（恒时预期 31.68ns vs 实测 32.75ns = 布局/混合外真实回退 ~3.4%） |
| 每指令成本 | 25.35ns | 32.75ns | 同上（混合效应主导——LLC 臂自身操作集 = 原对之和减一次分派循环迭代） |
| parity | OK | **OK 全负载** | 语义等价构造成立 |

**裁定（K129 纪律执行——不投机布局微调）**：tier-0.5 融合层的墙时收益已尽——首对（CallGlobal -13.4% 墙时）与 F1（call 开销面坍缩）之后，复制对的「纯分派消除」论题在本规模/混合下不成立（Ertl&Gregg 上界是文献值非本机保证）。**墙时负担全部移交 tier-1**（方法级编译吸收全部逐指令分派——这正是本窗核心交付）；LLC 指令的 -20% 指令数价值在 tier-1 内兑现（方法体内复制对 = 两条寄存器移动，零分派）。三触发器状态维持命中（B2 63.5ms = 2.60×→2.67× 带；份额 61.5%→更高[消除的是分派指令]；T-a 链路不变）——**tier-1 的必要性强化的实证**。

## 4. 出口条件（窗口关闭判据——三触发器全清 + 复画像出册）

1. **B2 ≤ 1.8× C-O0 带**（≤ ~42.7ms——tier-0.5 收尾 + tier-1 合计路径）或**带缺口如实登记**（沿 r134 出口形态：登记缺口 + 裁定后续杠杆归属）→ **r142 裁定：带缺口登记**（生产位口径 66.1ms = 2.79×——§8 MJ-6）
2. **解释器分派开销份额 ≤ 40%**（复画像实测）→ **r142 裁定：未清**（64.2%——链内无消除手段，杠杆归属 W-3.8）
3. **T-a 链路 ≤ 25×**（复画像实测——或组合面前置未齐时如实登记剩余缺口与归属窗口）→ **r142 裁定：未清**（~339× 维持——TJ-5 诚实预期兑现：T-a 组合面单源 = bootstrap-completion-plan §4.3）
4. 复画像出册（三跑稳定）+ 裁定 = 窗口关闭 / 组合面移交 T-a 切换窗（bootstrap-completion-plan §5）→ **r142 裁定：三跑稳定落档 tool-results/r142-*，窗口 CLOSED（§8 MJ-6），组合面前置对账移交 T-a 开窗轮**

## 5. 守卫义务（再生成 + 新族）

- **jit_window_tests 再生成**：census 精确性锚（double 程序指令数/对表/热函数全链重推导——LLC 融合后 (load-local,push-const) 对消失 + load-local-const 计数入锚）；四对钉扎中 (load-local,push-const) 对 → LLC 融合形态钉扎；F1 触发线维持（算术四臂直发 + LLC 共存形态）；负向族 census 位置断言按新 pc 再生成。
- **快照黄金族再生成**：含 (局部, 常量) 相邻实参形态的程序全部再生成（指令流变化 = 新基线——SI-5 形制）。
- **新族 method_jit_window_tests ≥8 件**（正 2/负 6 = 1:3——r133/r134 形制）：融合/非融合同程序同值双臂（集成验证用例）+ 跳转目标落位融合指令（分支头 = 融合位——结构安全论证的守卫钉扎）+ verify 双边界（const 越界/槽位越界）+ .krf 往返 + C 后端混合发射 + 孪生融合臂篡改 gate B drift + census 前提。
- **audit AQ 族 10 案**（320→330 live · 42 节——实施窗增节 r124 AM/r133 AO/r134 AP 先例）。

## 6. 知识锚（K150-K156 沿袭 + K157-K162 新增——stage0.md §9.121 单源）

| 锚 | 内容 | 消费位 |
|---|---|---|
| K153 | V8 Sparkplug 1:1 非优化基线（r132） | TJ-4 形态上游 |
| K154 | 多 tier JIT 原理阶梯（r132） | TJ-1 序 |
| K150/K151 | PEP 659 静态单相 / Ertl&Gregg 融合 3.17×（r132） | TJ-1/TJ-2 |
| **K157** | Sparkplug 重定义 = 去 IR 单遍 1:1、价值在分派消除与 tier-up 延迟、不要求原生 codegen（r135-q1 多源收敛） | TJ-2/TJ-4 |
| **K158** | 零 codegen 加速家族：superinstruction/threaded code/closure chain（EPFL 讲义 + efficient-interpreters + Cheap interpreter 阶梯——r135-q2b） | TJ-4 菜单 |
| **K159** | 生产位切换 = 种子→全量→自重建不动点，**不动点是验证门非构建步骤**；链条定长工件显式（rustc Stage 2/3 + kaikai A.5——r135-q3/q7） | bootstrap-completion-plan §5 |
| **K160** | 任意递归深度 = 激活记录堆化归一（trampoline/显式栈/堆帧同源；Rust 无保证 TCO → 显式循环可移植——r135-q4b） | TJ-3/W-REC-DEPTH |
| **K161** | PM 自举与编译器自举解耦（opam 语言无关先例——切换 PM 后置于 T-a——r135-q6） | bootstrap-completion-plan §3 排序 |
| **K162** | reader/parser 深度护栏 = 业界常态（Rust AST 嵌套检查先例）；「任意深度」范围化：eval 层必须、读/析层可保留可配置护栏（r135-q5/q4） | W-REC-DEPTH 范围裁定 |

## 7. tier-1 刀级四裁定（MJ-1..MJ-4——ARCH-A @ r141，刀 1 开工轮；K158 菜单 + TJ-4 形态的操作化）

> 裁定输入：bootstrap-completion-plan.md v1.5 §4.1 tier-1 刀 1 MUV 行（census 热点识别 + closure chain 去分派执行形 + 回退路径 + 确定性）+ §9.121.3 TJ-3/TJ-4（构建于 G2 堆激活栈之上；去分派方法执行层·零 codegen）+ 代码实态（vm.rs 1,601 行 run_dispatch 单循环 + frame.rs 堆帧 + observer.rs census 面 + G2 ✓ r136/r137 基座在位）。

### MJ-1 执行形 = closure chain（链接闭包链——K158 菜单裁定）

**链形态**：热点函数整条 code 编译为节点链——每节点 = 恰一条指令的语义，1:1 镜像解释器臂（K157 去 IR 单遍 1:1）：节点体调用与对应臂**相同的辅助函数**（span_at/materialize/take_args/invoke/reserve/push/pop——pub(crate) 镜像面），同序同载荷——**语义等价是构造性的而非统计性的**（r134 F1「等价非论证而是构造」先例形制）。链接：顺序指令 → 前节点持 `Rc` 直链（免逐步查表）；JumpIfFalse → 双臂各持链（真臂 = fallthrough，假臂 = 跳转目标）；Jump → 单链；Call/CallGlobal/Perform → 帧变更节点（invoke 压帧后交还主循环——**单迭代主循环纪律维持**：激活记录仍在堆帧栈 `frames: Vec<Frame>`，Rust 栈恒定——C3 架构零触碰，TJ-3 共享基座的兑现）；Ret/Halt → 终端节点。

**菜单否决两形态**：threaded code（fn 指针表——每步一次查表 + 一次间接调用，与 27 臂 match 跳转表同价〔K152 寄存器机权衡的镜像论证：形态不带来收益只带来面〕）；分派子集内联/块级闭包（无 codegen 时块内联退化为逐指令分派或要求 codegen——后者被 TJ-4 零 codegen 排除）。superinstruction 已被 tier-0.5 占用（TJ-2：余量对归本层吸收）。

**诚实边界（K129 纪律——不投机）**：`Rc<dyn Fn>` 间接调用与 match 跳转表同量级——本层收益 = 消除 fetch 双边界检查 + 消除逐指令 27 臂重分派 + 帧内直链；`Rc` 续链每步 +1/−1 引用计数（非原子）。刀 2 B 轴实测裁决真实收益，本裁定不预设墙时数字。

### MJ-2 census = per-function 闭包调用计数（阈值 64）

**机制**：`invoke` 闭包臂计数（arity 检查后、push_frame 前）——每**调用** +1 非每指令 +1（生产路径增量 = 每调用一次加法，非每指令）；内建调用零计数（无帧）；entry proto 不计数（非闭包调用面——run_dispatch 直接压帧；F5 下界形态诚实登记：churn 型顶层直线代码〔入口 100%〕永不编译）。`METHOD_HOT_THRESHOLD = 64` 两端论证：fib-25 计数 242,785 ≫ 64（tier-up 后 ≥99.97% 调用走链，编译成本摊销）+ 一次性程序计数 1 ≪ 64（冷函数永不编译——F5 热函数集中度的机制化）。阈值经 `Vm` 构造面可配（`with_method_tier_threshold`——与 with_budget 同形制；守卫以 u32::MAX 钉扎纯解释路径、以 1 钉扎首调用即编译路径）。

**触发语义**：计数达阈值的**当次调用**走编译链（note_invoke 在 push_frame 前完成链构建——确定性：同程序恒同计数序列恒同 tier-up 点）；编译失败 → 该函数**永久**解释（一次尝试无重试——防抖动 + 确定性保持）。零运行期反馈零自适应（静态单相——K150 r132 裁定沿袭：冻结子集无动态类型反馈面）。

### MJ-3 编译边界 = 整函数粒度 + 帧边界引擎选择

**可编译集**：冻结 ISA 27 操作码全量（每臂均 1:1 可镜像；verify 先拒畸形产物——链构建器独立复核悬挂跳转/未知形态作 fail-closed 纵深防御，测试经手搓产物直调构建器触达拒绝面）。

**回退 = 函数粒度**（绝不混链：一函数要么全链要么全解释）；激活内引擎混合仅发生在**帧边界**（call 压帧 / ret 弹帧后主循环重选引擎）——每步语义两引擎相同（MJ-1 构造性）= 不变量声明。mid-method 重入：ret 弹帧后调用方帧恢复，主循环在 loop-top 按「top frame 的 func 已编译？」选择引擎，链经 pc 索引表 `entry[pc]` 重入——**pc 纪律**：每节点入口先做 fetch 等价推进（frame.pc = own+1；跳转臂随后覆写）——控制离开链的任何时刻（call 压帧/错误返回/帧弹出）frame.pc 与解释器逐位同值。

**引擎选择位 = run_dispatch loop-top**（一次 Option 探测/迭代——预测不分支，冷帧近零成本；诚实注记：解释路径新增一次 Vec 索引 + Option 检查每指令——刀 2 B 轴实测，K129 不投机）。OBSERVER 面：驱动器 const 泛型单化（`run_compiled_frame::<OBSERVE>`——与 run_dispatch 同形制）：观察三元组 (op, func, pc) 由驱动器在节点执行前上报——观察流与无 tier 时逐位相同（census 守卫钉扎：机制不扰动测量——r132 seam 裁定的 tier 版）。

### MJ-4 确定性构造 + 双路同值（验收形态）

**确定性**：链构建 = Bytecode 纯函数（同 Bytecode 恒同链——节点序/链接/载荷逐位；canonical listing〔每 pc：(pc, op, 后继 pc 集)〕可序列化比对——跨构建两次构建逐位相等守卫）+ tier-up 时点确定（计数序列确定）。**双路同值**：值/输出/错误（含 span·op·pc 载荷）/预算账（allocs 计数 + D-CLASS-1 三元组 + collect-then-retry 位点）逐位一致——构造性（节点 = 臂的同辅助函数同序）+ 集成测试双跑断言（阈值 u32::MAX 纯解释 vs 阈值 1 全编译对照）。

**交付范围声明（MUV 边界——§4.2 禁止降级）**：刀 1 = 基础设施全链〔census 计数 + 阈值触发 + 链构建 + 回退记录 + 确定性 listing + 引擎选择入 run_dispatch + pub(crate) 镜像面〕；刀 2 = LLC 协作精化（tier-0.5 融合层 × 方法层协同实测）+ 守卫族再生成 + audit AW 族 + B 轴对照 tier-0.5 收尾基线三跑 + 三触发器复画像（§4 出口条件）。

## 8. 刀 2 实测裁定（MJ-5/MJ-6——ARCH-A @ r142，窗口出口轮；K129 实测裁决纪律 + K152/K157 兑现）

> 裁定输入：§7 末段交付范围声明（刀 2 = LLC 协作 + 守卫族 + B 轴对照 + 三触发器复画像）+ 测量面升级（vm_dispatch_profile 双臂对照——每负载 tier-on〔Vm::new 默认〕/ tier-off〔with_method_tier_threshold(u32::MAX)〕双计时 + ratio 行）+ 三跑落档 tool-results/r142-dispatch-profile-run{1,2,3}.txt + §7 MJ-1 诚实注记（「`Rc<dyn Fn>` 间接调用与 match 跳转表同量级——刀 2 B 轴实测裁决真实收益，本裁定不预设墙时数字」）。

### MJ-5 生产默认 = 纯解释（tier 关闭——三跑实测裁决）

**实测数据（fib-25，本机三跑中位）**：

| 跑 | tier-on | tier-off | ratio(on/off) |
|---|---|---|---|
| run1 | 73.140ms | 66.137ms | 1.106 |
| run2 | 71.935ms | 65.952ms | 1.091 |
| run3 | 71.801ms | 66.706ms | 1.076 |

**判读**：closure chain 形态净负 ~9%——`Rc<dyn Fn>` 间接调用（不可内联）+ entry(pc) Vec 索引跳步 + Rc 引用计数维护的成本，**超过**其消除的 match 27 臂分派 + fetch 双边界检查。MJ-1 诚实注记被实测兑现：零 codegen 约束下，LLVM 将 27 臂 match 编译为跳转表且 arm_* 辅助函数内联进各臂——**解释器 match 分派就是零 codegen 约束下的最优分派形态**（K152 寄存器机权衡论证的运行时侧镜像：形态不带来收益只带来面；K157「Sparkplug 价值来自寄存器机 codegen」的本项目实证）。

**实施（生产默认翻转）**：
1. `METHOD_TIER_DISABLED: u32 = u32::MAX`（methodjit.rs 新常量）——`Vm::new`/`Vm::build` 默认阈值（纯解释 = 实测最快形态）。
2. `note_invoke` early-out（`if self.threshold == METHOD_TIER_DISABLED { return; }`）——关闭态每调用零成本；**禁用态计数恒 0 为钉扎语义**（blade-2 测试族 + AX06/AX07 断言）。
3. `METHOD_HOT_THRESHOLD = 64` 语义转为 **opt-in 推荐阈值**（`with_method_tier_threshold(bc, METHOD_HOT_THRESHOLD)` 显式开启——文档注释全面改写）。
4. 机制保留双位：opt-in 验证面（双路同值守卫族照跑——threshold 1/MAX 对照）+ W-3.8 链外 codegen 窗基座资产（census per-function 计数器 + `MethodChain::build` 纯函数构建器 + `chain_listing` 确定性面——codegen 窗的热点识别与确定性构建可直接复用）。

**共变面**：AW01/AW07（audit 默认断言 → 显式 opt-in 构造）+ wmj_method_tier_dual_path（默认臂 → 禁用断言 + opt-in 臂新增）+ TEST-3（390→400）。

### MJ-6 窗口出口裁定 = 带缺口登记关闭（三触发器复画像——生产位〔tier-off〕口径）

| 触发器 | 阈值 | r142 实测（三跑） | 裁定 |
|---|---|---|---|
| ① B2 C-O0 带 | ≤ 1.8×（~42.7ms） | 66.1ms = **2.79×**（r135 本机基线 63.5ms = 2.67× 带内浮动） | **未清——带缺口登记** |
| ② 分派份额 | ≤ 40% | **64.2%**（census 与 r135 逐位维持：1,942,283 指令 / LLC 485,569） | **未清——杠杆在链外** |
| ③ T-a 链路 | ≤ 25× | **~339× 维持**（VM 层提速预期落空——closure chain 实测否决） | **未清——组合面移交 T-a** |

**缺口归属裁定**：分派份额的消除手段 = **真 codegen（寄存器机/LLVM）**——链内（零外部依赖 §18 + VM 永久 Rust 基座宪制排除项 + 自举链排除 LLVM）结构性不可达；杠杆归属 = **W-3.8 链外后端窗**（宪制外可选位——性能优化不阻塞自举主线）。

**LLC 杠杆归属改判**：r135 裁定「LLC 指令的 -20% 指令数价值在 tier-1 内兑现」被刀 2 实测**结构性证伪**（tier-1 慢于纯解释——兑现载体不存在）→ LLC 在墙时面确认为净负资产（r135 +3% 回退实测维持）；链内退役/维持**延后至 T-a 切换窗开窗轮重审**（其与 C 后端〔LLC 已入 C 复合发射〕及 W-3.8 codegen 窗的交互面为重审输入——退役成本〔opcode 27→26 全链回退：verify/C 后端/compile 特判/compiler.ktf 孪生/黄金族〕vs 墙时 3% 的权衡在切换窗组合面内裁定）。

**G3 状态改写**（bootstrap-completion-plan v1.7 承载）：从「T-a 性能带未达」改写为「**性能面实测裁决完成**：链内最优形态 = 纯解释 + LLC（B2 2.79× 带缺口登记）；消除杠杆（真 codegen）在链外（W-3.8 可选位）；链内结构性天花板诚实登记」。**T-a 切换窗前置对账**：G1 ✓ + G2 ✓ + G3（裁决完成形态）→ **T-a 开窗合法成立**；K140 带（切换性能回退 ≤ ~10×）在 T-a 开窗轮按组合面重审（~339× 链路带作为已知成本进入 A/B/C 工件对照——TJ-5「本窗不承诺 T-a 达标」的正式兑现，T-a <10× 目标的达成路径 = 稳态链摊销 × 生产链对照口径 ×〔可选〕W-3.8 链外加速，单源 = bootstrap-completion-plan §4.3/§5）。

**守卫族（刀 2 交付）**：blade-2 测试族六件（method_jit_window_tests：正 2〔生产默认纯解释 + LLC 协作单节点双压〕/ 负 4〔禁用零计数钉扎 + LLC 错误载荷位级 + opt-in 边界 + 帧边界预算 parity〕）+ audit AX 族 10 案（AX01-AX10：生产默认/ opt-in 穿越/ LLC 协作 parity/ 链内 LLC 节点形态/ census 引擎不变性/ **r135 画像数字机制化**〔1,942,283 + 485,569 逐位钉扎〕/ 禁用常量=默认一致性/ 帧边界混合引擎/ LLC 错误载荷/ 深递归堆帧）+ TEST-3 共变（400/400 · 49 节）。

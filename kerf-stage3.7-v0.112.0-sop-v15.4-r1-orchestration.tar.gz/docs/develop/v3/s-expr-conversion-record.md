# S-expr→目标语言完全转化统一记录（s-expr-conversion-record.md）——转化面台账与审计单源

> **Status**: Active v1.0（r140 新建——用户指令⑫落位：自举阶段实现「S-expr 完全完整转化为目标语言内容」时，同步统计与记录到对应 docs/develop/ 下对应版本的统一完全转化记录文件，便于人工与 Agent 查阅审计）
> **r151 改账（刀 2）**：S-expr 读链两孪生退役离账（lexer.ktf 671 + reader.ktf 141 = 812 行——W-SEXP-RETIRE 刀 2 随 S-expr 读链本体退役）；target-parser.ktf 68 行超宽重排（3,281→3,658——纯空白重排零语义变更，格式守卫七件全覆盖配套）；台账九件 14,932 → **七件 14,497 行**。
> **流程权威**: docs/sop.md v15.3（§8.4.5 文档同步 / §8.6 worklog 协议 / §2.2 原则 41 脚手架生命周期）
> **职责边界**: 本文件承载 **Rust 宿主实现 →目标语言（.ktf 目标皮肤源）完全转化面的逐件台账、刀级谱系、累计口径与未转化面清点**；单轮转化叙述仍由 RELEASE_NOTES + worklog 承载（三处单源互链：本台账 + bootstrap-completion-plan.md 窗口行 + stage0.md §9.12X 设计层记录）。拆除面规划 = bootstrap-completion-plan §4.4（W-SEXP-RETIRE——G7）。
> **登记义务**: 每新增一个转化面（某 Rust 编译段组件的全量 .ktf 镜像交付）必须在本台账新增一行 + bootstrap-completion-plan 对应窗口行刷新 + RELEASE_NOTES 当轮行记载（三处同步——缺一 = §8.4.5 文档同步违例）。

## 1. 一行定位

kerf 自举 = 把「用 Rust 写的编译器各段」逐段转化为「用 kerf 写的等价实现（.ktf 孪生）」，并以 parity 位级 + fixpoint 自复现证明转化完整。本台账是这些转化面的统一账本：**每一行 = 一个 Rust 组件获得了完整的目标语言等价物**。

## 2. 转化面台账（七件 · 14,497 行——r151 刀 2 改账：lexer.ktf/reader.ktf 两 S-expr 读链孪生 812 行随读链本体退役离账〔selfhost 九件→七件〕+ target-parser 68 行重排 +377〔3,281→3,658——纯空白重排〕；v0.109.0 时点原测 `wc -l selfhost/v1/*.ktf` = 九件 14,932；r148 刷新：compiler co_limit 参数化；r150 刀 1 复核：零行数共变）

| # | 孪生件 | 行数 | Rust 镜像源（被转化物） | 首次交付 | 终形/刷新 | 所属窗（段） | 转化性质 |
|---|---|---|---|---|---|---|---|
| ~~1~~ | ~~lexer.ktf~~ | ~~671~~ | crates/kerf-reader/src/lexer.rs | r100 · v0.65.0 | **r151 退役离账**（W-SEXP-RETIRE 刀 2——S-expr 读链本体随 scaffold 移除，孪生同步退役；历史行保留作谱系） | Stage 2.7 / W-3.12 段一 | 服役 51 轮（r100→r151），终态 r121 生产化 |
| ~~2~~ | ~~reader.ktf~~ | ~~141~~ | crates/kerf-reader/src/parser.rs | r100 · v0.65.0 | **r151 退役离账**（同上——两孪生 812 行合计） | Stage 2.7 / W-3.12 段一 | 服役 51 轮（r100→r151），终态 r121 生产化 |
| 3 | macro.ktf | 686 | crates/kerf-expander/src/{lib,code}.rs 宏面（660 源行） | r100 · v0.65.0 | r122 段二刷新（extern 警察五面 + 稳态展开链） | Stage 2.7 / W-3.12 段二 | 宏引擎全量转化 |
| 4 | expander.ktf | 2,230 | crates/kerf-expander/src/expand.rs（750 源行） | r100 · v0.65.0（子代理超时草稿 + 主代理验收手术） | r122 段二刷新（1,346→1,671）+ r143 TD-027 match 臂（1,671→2,227——r144 补账）+ r146 ex_limit 预算镜像参数化（2,227→2,230——512 烘焙→装配前缀 tp_limit 先例） | Stage 2.7 / W-3.12 段二 | 展开器全量转化 |
| 5 | compiler.ktf | 1,850 | crates/kerf-compiler/src/compile.rs（1,257 源行） | r100 · v0.65.0 | r124 消费臂（cp_extern_walk）+ r133/r134/r135 融合刀共变（CallGlobal/F1/LLC）+ r148 co_limit 预算镜像 + 深度臂 bool 契约 + extern 全局索引计数器（+46） | Stage 2.7 / W-3.12 段三 | 编译器（CoreExpr→字节码）全量转化 |
| 6 | infer.ktf | 3,774 | crates/kerf-typecheck/src/infer.rs（HM 推断） | W-HM-TWIN 127 刀族（r126 开窗 → r129-r131 交付完成） | r131 段三 ELEVATED（HM 判定面）+ r144 三缺陷修复刷新（3,690→3,774——join 结构相等/env 截断/边序） | W-HM-TWIN（段三） | HM 推断器全量转化 |
| 7 | typecheck.ktf | 1,234 | crates/kerf-typecheck/src/check.rs（判定面） | W-HM-TWIN 127 刀族（r126-r131） | r131 段三 ELEVATED | W-HM-TWIN（段三） | 类型检查判定面全量转化 |
| 8 | target-lexer.ktf | 1,065 | crates/kerf-reader/src/target/lexer.rs（目标皮肤词法器） | r136 · v0.97.0（W-TGT-READ-TWIN 刀 1——第八孪生） | — | W-TGT-READ-TWIN（G1） | 目标皮肤词法器全量转化（读自身皮肤的第一件） |
| 9 | target-parser.ktf | 3,658 | crates/kerf-reader/src/target/parser.rs（目标皮肤 Pratt 解析器 1,676 源行） | r138 · v0.99.0（W-TGT-READ-TWIN 刀 2——第九孪生，帧机形制） | r139 稳态链（SteadyTargetReaderChain）+ **r151 格式重排**（3,281→3,658——68 行超宽 `pair(...)` 状态帧重排至 ≤100 列，纯空白零语义变更；格式守卫 8→7 清单全覆盖配套） | W-TGT-READ-TWIN（G1） | 目标皮肤解析器全量转化 |

**累计口径**：七件 · **14,497 行** .ktf 目标皮肤源（r151 刀 2 改账：五件段孪生 = 9,774 行〔macro 686 + expander 2,230 + compiler 1,850 + infer 3,774 + typecheck 1,234——S-expr 读链两孪生 812 行退役〕+ 两件目标皮肤读链孪生 = 4,723 行〔target-lexer 1,065 + target-parser 3,658——重排 +377〕）。历史基线：r140 台账九件 14,932（v0.109.0 实测）；r143 补账 TD-027；r146 +3；r148 +46；r150 零共变；r151 −812 +377 = 14,497。审计口径：`wc -l selfhost/v1/*.ktf` 总行数 = 台账累计行（任何漂移 = 台账失账，判 §8.4.5 违例）。

## 3. 刀级谱系（转化面形成史——交付轮序）

| 轮 | 版本 | 转化事件 |
|---|---|---|
| r100 | v0.65.0 | **首波五件**（Stage 2.7 步③ .krf→.ktf 五件翻译：lexer/reader/macro/expander/compiler + 三路门[语义投影/行为/α-等价] + rest 碰撞手术 + 前缀孪生） |
| r121 | v0.83.0 | **段一生产化**（注入通道 inject_global + SteadyReaderChain 稳态链 + 段一 ELEVATED——read 段自举链完备） |
| r122 | v0.84.0 | **段二刷新与稳态链**（expander/macro 刷新 + SteadyExpanderChain + items 前缀 extern 编码缺陷清偿） |
| r123 | v0.85.0 | 段二 ELEVATED（CSYM 重归属后孪生语义面 = 展开器语义面——完备性由构造成立） |
| r124 | v0.86.0 | compiler.ktf 补消费臂（cp_extern_walk——junction-3 记录盲清偿）+ 构建编排宪法性排除裁定 |
| r126-r131 | v0.87.0-v0.92.0 | **HM 孪生刀族**（infer.ktf + typecheck.ktf 交付 + r131 段三 ELEVATED——前端三段全 ELEVATED） |
| r133-r135 | v0.94.0-v0.96.0 | compiler.ktf 融合共变（CallGlobal r133 + F1 直发算术 r134 + LLC 融合 r135——gate B 逐位 + fixpoint 自复现维持） |
| r148 | v0.109.0 | compiler.ktf co_limit 预算镜像参数化（ex_limit 先例——装配前缀 define + 自描述深度载荷携限值）+ cp_ewalk 错误臂 bool 契约修复（错误置位后返回 false 保 `if term` 消费面）+ extern 重复名全局索引计数器（oracle 跨块语义对齐）+46 行 |
| r136 | v0.97.0 | **target-lexer.ktf 第八孪生**（G1 刀 1——三向 parity + 自源先例） |
| r138 | v0.99.0 | **target-parser.ktf 第九孪生**（G1 刀 2——curated 91/91 + selfhost 九源固定点） |
| r143 | v0.104.0 | expander.ktf match 臂扩展（TD-027——行数 1,671→2,227，台账 r144 补账） |
| r144 | v0.105.0 | infer.ktf 三缺陷修复刷新（join 结构相等 + env 截断 + 边序——3,690→3,774；非新转化面：T-a CCF 新输入域暴露的 sweep 盲区缺陷） |
| r146 | v0.107.0 | expander.ktf ex_limit 预算镜像参数化（512 烘焙→装配前缀 `define(ex_limit, N);` + depth 载荷携 limit——tp_limit 先例；行数 2,227→2,230；非新转化面：expand 段生产位切换的预算 parity 义务） |
| r139 | v0.100.0 | **C1 链路闭合**（SteadyTargetReaderChain + K20 桥 + 组成链五联差分——零新转化面，链形/桥/组成层 Rust 侧工程） |
| r150 | v0.111.0 | **W-SEXP-RETIRE 刀 1——验收语料单皮肤迁移**（tests/v1/stage1/corpus/ 112 案 .krf→.ktf：机械 89 经转码器 + 手作孪生 11 + 阶段分歧 9 期望改钉目标面 parse-error + 退役 3〔neg-021/pos-031/neg-036——目标皮肤面无主语〕；逐案双皮肤等价预检三闸落档 tool-results/r150-migration-report.txt；**非段孪生转化面**——语料 = 验收载体换皮肤，台账九件行数零共变；七件 S-expr 段孪生维持至刀 2 读链退役时改账退役） |

## 4. 未转化面清点（S-expr 表面存续——G7 缺口账）

**已转化（上表九件）**：读（S-expr 读链 + 目标皮肤读链）/ 展（宏 + 展开器）/ 查（HM 推断 + 判定面）/ 编（编译器）——**编译管道四段全部拥有目标语言等价物**（C1 链路级闭合 r139）。

**未转化/存续面（W-SEXP-RETIRE 拆除对象——非「待转化」而是「待拆除」）**：

| 面 | 现状 | 拆除窗 |
|---|---|---|
| ~~.krf S-expr 皮肤语料（tests/v1/stage1/corpus/ 112 案）~~ **已拆除 @ r150**（109 .ktf 单皮肤 + 3 退役；内联 S-expr 常量骑至刀 2：determinism/steady_expander i64::MIN 边界 + AF/AK/AL audit 九案 + sweep 三分歧钉扎） | ~~双皮肤测试面~~ 单皮肤验收面（validate_target 契约） | ✓ W-SEXP-RETIRE 刀 1（r150） |
| Rust S-expr 读链（crates/kerf-reader/src/{lexer,parser,token}.rs） | 生产 + oracle 双角 | W-SEXP-RETIRE 刀 2（退役为 oracle → 移除） |
| reader.ktf / lexer.ktf（S-expr 读链孪生——台账 #1/#2） | parity 验证面 | W-SEXP-RETIRE 刀 2（parity 职能终结退役） |
| skin_transcoder.rs 转码器 | .krf→.ktf 机械臂（迁移工具——刀 1 迁移机械臂的核心引擎，迁移报告在档） | W-SEXP-RETIRE 刀 3（迁移完成后退役） |
| VM 永久 Rust 基座 + K20 桥 + 构建引导层 | **宪制排除项**（永不入自举链不计转化分母） | 不拆除（宪法性排除——原则 53） |

## 5. 维护义务

- 新转化面 → 台账 §2 新行 + bootstrap-completion-plan 窗口行 + RELEASE_NOTES 当轮行（三处单源）
- 转化面刷新（既有孪生语义扩展）→ 台账 §2 终形列更新 + §3 谱系行追加
- W-SEXP-RETIRE 交付时 → §2 标记退役件 + §4 清点表清零 + 本文件状态行升格「转化终态 + 拆除完成」
- 审计口径：`wc -l selfhost/v1/*.ktf` 总行数 = 台账累计行（14,932 @ v0.110.0——任何漂移 = 台账失账，判 §8.4.5 违例；r149 零共变复核通过：workflow 语料为 .ktf 用户程序非孪生，台账行数与实测逐位一致）

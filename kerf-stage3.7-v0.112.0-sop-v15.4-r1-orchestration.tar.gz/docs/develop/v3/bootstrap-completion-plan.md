# 自举完备总规划（bootstrap-completion-plan.md）——从 v0.95.0 到完全脱离宿主语言的窗口序列与 MUV 排期

> **Status**: Active（v1.16——r151 W-SEXP-RETIRE 刀 2 交付刷新：**S-expr 读链退役 ✓〔G7 读链层拆除——S-expr 表面四层之二离树；单皮肤 API 终态：read_target_program/parse_target 单源，ReaderFace/skin 参数/双皮肤分支全树退役〕**〔拆除 ~4,700 行〔本体 1,435 + 孪生 812 + harness 1,373 + 转码器 + 退役模块 644〕+ 消费面 141 错误位点 ~46 文件〔三子代理 32 + 特殊六件 + audit 59 + bench 三件〕+ in-crate 45 运行时失败清偿〔172/172——151-b2 只验编译未跑测试的缺口〕+ 生产缺陷三件〔transcode 命名守卫 / REPL callee / audit 仲裁四案〕+ **TD-028 登记**〔TWIN-HYG-1——孪生展开器 plain-ident 查询缺代纪律；J03 oracle 臂钉扎〕+ audit 减法共变 480→460 live + 124 retired + 守卫 TEST-3/3b + v0.112.0 金链锁步 + audit 460/460 实跑 exit 0 + 台账改账七件 14,497 行；词面层/台账层移交刀 3：.krf 词面残余扫描守卫化 + TD-028 孪生臂回迁——零新转化面（r151 行数共变 = 退役 −812 + 重排 +377）〕）；> **History**: v1.15——r150 W-SEXP-RETIRE 刀 1 交付刷新：**语料单皮肤迁移 ✓〔G7 语料层拆除——S-expr 表面四层之一离树〕**〔全语料 .krf→.ktf 109 案 + 三案退役〔neg-021/pos-031/neg-036——目标皮肤面无主语，分歧钉扎内联承载至刀 2〕+ 逐案双皮肤等价预检三闸落档 tool-results/r150-migration-report.txt + 消费面切换 14 测试文件 + 3 子代理 + 漏网 2 件 + parse_directive 双前缀单源 + 机械臂 R4 归档 + audit BF 族〔470→480 · 56→57 节〕+ V03/AF/AK/AL audit 面内联清偿 + 守卫 TEST-3 共变〔480/584〕+ v0.111.0 金链锁步 + GATE 1 1693:0:4——诚实披露：neg-057 J2 渲染形缺口〔刀 2 清理项〕+ neg-062 extern 双胎缺口维持；零新转化面（台账维持 14,932 行——刀 2 读链退役后改账）〕）；> **History**: v1.14——r149 step ⑤ 交付刷新：**工作流宣告 ✓ + T-a 切换窗 CLOSED〔G4 全闭合 + C1-C4 四判据全绿 + W-SEXP-RETIRE 交棒〕**〔工作流实录语料 examples/workflow/{selfcheck,bench}.ktf——C4 面首个生产消费（编辑 .ktf → kerf run 四段孪生链生产位编译 → VM 执行测试/基准标记：selfcheck 62 行 8 标记全 PASS / bench 47 行 fib(30)+list(10000)+sum_to(20000) 全对值）+ 测试族七件（workflow_record_tests：正 2 / 负 3 / 回退带 1 / 跨段消费 1）+ audit BE 族（460→470 · 55→56 节）+ 守卫 TEST-3 共变（470）+ 测量三跑（selfcheck 163-170ms / bench 953-964ms 全进程墙钟）+ **C1-C4 验收对账**：C1 ✓（r139 组成链等价 + 四段全语料 sweep）/ C2 ✓（四段生产位 + K159 B≡C 六工件 + 工作流实录）/ C3 ✓（r137 终态）/ C4 ✓（首个生产消费 + Rust 面清点表——w-t-a-switch-window v1.5 §7 十项收敛清单：宪制排除三类 + oracle + 桥/验证/工具宿主面 + 拆除排期面）+ **出口条件四条全 ✓ 关窗**（w-t-a-switch-window v1.5 CLOSED）+ **W-SEXP-RETIRE 交棒就绪**（read 段生产位 r145 + TD-027 r143 双臂满足——下一窗口 = §3 序 4）——测试面 1694→1701:0:4；零新转化面（台账维持九件 14,932 行）〕；> **History**: v1.13——r148 step ④ 第四段交付刷新：**compile 段生产位切换 ✓〔step ④ 四段全绿——G4 段切换完成〕**〔编译孪生链 VM 臂默认〔SteadyCompilerChain::compile_production + co_limit 预算镜像参数化〔ex_limit 先例——装配前缀 define + DepthExceeded 载荷 depth+limit 双字段自描述〕〕+ K163 第五实例双面 retarget〔错误面 with_span 穷举 + 产品 dbg 面——真代际保留〕+ K163 第六实例当轮清偿〔items 流投递链四递归面迭代化 + inject_items_stream 析构 helper × 12 注入位——60k 平坦引号默认栈实证；AST 字面量 Box-drop ~150k 生产上界诚实登记（双臂共享 oracle 域——W-REC-DEPTH 堆化后续）〕+ 孪生三潜在缺陷当轮清偿〔cp_ewalk 错误臂 bool 契约 + extern 重复名全局索引 + verify 地板两法官显式化——§6e 盲面经 verify 拒绝映射程序级 CompileError〕+ 测量三跑〔compile 段 K140 切片带 1.2-1.7× / spine 1.3-1.5×——四段最优〕+ 测试族十二件 + audit BD 族〔450→460 · 54→55 节〕——w-t-a-switch-window v1.4 §2 TA-8 形制单源〕；v1.12——r147 step ④ 第三段交付刷新：**check 段生产位切换 ✓**〔双检查孪生链 VM 臂默认〔保守检查器 + HM 推断引擎——oracle 脊柱收集序〕+ 诊断结构化重建面〔cdiag/tdiag verdict → TypeDiagnostic：code 注册表查表 + message 模板表单源 + subjects intern + span file 重靶/ROOT gen 诚实边界〕+ 三种子面全钉 + harness 自检钉位〔drive_dual_engines/drive_full_face——P0 回归修复：46KB 链工件解释态 HM ≈ 49s/件，corpus sweep 61→5 分钟〕+ 回退带 KERF_CHECK_SEGMENT + 测量先行三跑 + K163 第四实例清偿〔twin 重建树 span file_id 恒 0——零 id 验证域盲区；retarget_forms/retarget_items 全变体穷尽〕+ 测试族十一件 + audit BC 族〔440→450 · 53→54 节〕——w-t-a-switch-window v1.3 §2 TA-7 形制单源〕；v1.11——r146 step ④ 第二段交付刷新：**expand 段生产位切换 ✓**〔孪生展开链 VM 臂默认 + junction-2 双拒绝面〔孪生裁决覆盖展开+加载〕+ 预算镜像 ex_limit 参数化〔expander.ktf 512 烘焙→装配前缀 + depth 载荷携 limit〕+ 三种子面钉 Rust〔parse_target_with_injected / read_target_source_for_bootstrap / rust_compile_ccf——Session::with_segments〕+ 回退带 KERF_EXPAND_SEGMENT + 测量先行三跑 + K163 同族预防位全量〔forms_stream 右脊 Box-drop——dispose 共享化×全注入位〕+ 测试族十件 + audit BB 族〔430→440 · 52→53 节〕——w-t-a-switch-window v1.2 §2 TA-6 形制单源〕；v1.10——r145 step ④ 首段交付刷新：**read 段生产位切换 ✓**〔生产读默认翻转稳态孪生链 VM 臂 + Rust 目标读器退役 oracle + 回退带 KERF_READ_SEGMENT + 测量先行三跑（每读 240-990× 段级切片带）+ K163 第二实例三同族栈递归缺陷清偿（pair_cells/from_literal/Box-drop）——w-t-a-switch-window v1.1 §2 TA-5 单源〕；v1.9——r144 T-a 首刀交付刷新：**step ② A/B/C 工件管线 + step ③ 不动点门全链交付**〔CCF 链可编译形制〔w-t-a-switch-window §2 TA-1〕+ SteadyCompilerChain 编译段稳态形补齐 + B ≡ C 位级六工件全过 + A ≡ B parity 观察行——**K159 不动点门首证**〕+ 四项前置缺陷清偿〔infer 孪生 join/env 截断/Tarjan 边序/generation 编码——CCF 新输入域首次暴露，K163 新锚〕+ 测试族六件 + audit AZ 族〔410→420 · 50→51 节〕；v1.8——r143 TD-027 清偿刷新：**TD-027 ✓ = 前置门清偿关闭**〔expander.ktf match 臂——oracle expand_match 逐决策镜像 + compile_pattern 六模式族 + "nonexhaustive"/"unsupported-pattern" 错误 kind 重建 + 组成链 J0.9 边界行退役 + 语料族 21 案〔91→112〕+ 转码器 match 臂 + audit AY 族〔400→410 · 49→50 节〕——tech-debt r143 检视节〕；**T-a 开窗对账 = 前置全凑齐**〔G1 ✓ + G2 ✓ + G3 裁决完成 + TD-027 ✓ → 开窗合法成立——§4.3 step ① 种子链固化落档 + K140 带组合面重审结论 + step ② A/B/C 工件管线 = r144 首刀〕；**LLC 链内退役/维持重审裁定 = 维持在位**〔编译期静态融合与被证伪的运行时 tier 分派不同机制类；r135 +3% 墙时实测未被动摇；退役成本〔opcode 27 全链回退〕远超收益差；再重审 = W-3.8 codegen 窗〕；v1.7——r142 tier-1 刀 2 交付刷新：**W-JIT-METHOD-T1 刀 2 ✓ = 窗口 CLOSED（带缺口登记）**〔MJ-5 生产默认 = 纯解释——三跑 B 轴对照实测 closure chain 净负 ~9% → `Vm::new` 默认 `METHOD_TIER_DISABLED` + note_invoke early-out + METHOD_HOT_THRESHOLD 转 opt-in；MJ-6 三触发器复画像生产位口径 = B2 66.1ms 2.79× / 份额 64.2% / T-a ~339× 三项未清——消除杠杆（真 codegen）在链外 W-3.8 可选位，链内结构性天花板诚实登记——w-jit-method-t1-window.md v1.2 §8〕；**G3 改写 = 性能面实测裁决完成**〔§2 行 + §3 序 1 关闭 + §4.3 T-a 前置对账 = G1 ✓ + G2 ✓ + G3 裁决完成形态 → T-a 开窗合法成立；K140 带重审入 T-a 开窗轮〕；audit AX 族〔390→400 · 48→49 节〕+ blade-2 测试族六件 + 测量面升级〔vm_dispatch_profile 双臂对照〕+ tool-results/r142 三跑 + v0.103.0 金链锁步；v1.6——r141 tier-1 刀 1 交付刷新：**W-JIT-METHOD-T1 tier-1 刀 1 ✓**〔方法编译基础设施：closure chain 执行形 MJ-1 + census 阈值 64 MJ-2 + 整函数粒度/帧边界引擎选择 MJ-3 + 构造性 1:1 镜像双路同值 MJ-4——w-jit-method-t1-window.md v1.1 §7 四裁定〕；测试 +8〔1599→1607〕+ audit AW 族〔380→390 · 47→48 节〕+ 六命令 clean 冷跑全绿 + v0.102.0 金链锁步；G3 在窗〔下一刀 = 刀 2 tier 分派集成/LLC 协作/B 轴对照/三触发器复画像〕；v1.5——r140 规划刷新轮交付：**两新窗入序**〔W-SEXP-RETIRE S-expr 脚手架拆除窗（§3 序 4 / §4.4——用户指令⑥「完全自举后完全使用目标语言词法语法语义」的终态兑现位）+ W-LANG-FOUNDATION 语言基础完备窗（§3 序 7 / §4.5——用户指令⑤「语言自身底层和基础内容完成纳入计划」的落位）〕+ **G7/G8 缺口行补全**（§2——S-expr 表面存续 + 语言基础面未完备入账）+ **enum/struct 时点裁定**（§9——用户审查问题正面回答：时机未到非遗忘——设计登记 stage0 §9.14.2 R4 + 语法桥 parse_type_drop 生产在位 + 实现窗法定 C2 后）+ **S-expr→目标语言完全转化统一记录文件新建**（docs/develop/v3/s-expr-conversion-record.md——九件 14,243 行台账单源，用户指令⑫落位）+ roadmap v2.69 §6 当前位置行刷新（r120 滞留 19 轮的文档同步缺口清偿——§8.4.5）；v1.4——r139 刀 3 交付刷新：W-TGT-READ-TWIN 刀 3 交付[**C1 链路级闭合——G1 终态**：SteadyTargetReaderChain（两孪生各编译一次 + 每读注入 source-bytes/tp-tokens）+ K20 永久宿主层桥（lexer 孪生 token 记录 → parser 孪生输入记录——ident skin 映射/float Debug/str 转义解码单源）+ 组成链 composed_target_read_chain（J0 token/J0.5 tree/J1 expand/J1.5 check/J2 compile 五联差分 = pipeline_ktf(S) == pipeline_rust(S)）+ fixpoint 纯度腿（Phase-2 自应用程序读段经目标读孪生 + 展开孪生，孪生前端 == 生产桥 items 断言）+ 深自应用（parser 孪生读自身 3,281 行源经稳态链）+ 外部记录空参 nil 编码清偿（CP-1 词汇契约第三成员——r122/r124 extern 族）+ AV 族 10 案（370→380 live · 47 节）+ 诚实边界行（match 脱糖——双子展开器冻结子集域 vs oracle 超集；TD 登记 follow-up）]；v1.3——r138 刀 2 交付刷新：W-TGT-READ-TWIN 刀 2 交付[target-parser.ktf 第九孪生 3,281 行——G1 刀 2/3：curated 91/91 + selfhost 九源固定点 + 拒绝面同键族 + audit AU 族]；v1.2——r137 刀 2 交付刷新：W-REC-DEPTH 刀 2 交付[四层帽 K162 范围化 + r74/r85 括号全链退役——**C3 终态宣告**]；v1.1——r136 双首刀刷新：W-REC-DEPTH 刀 1 交付[eval 堆激活栈化——C3 前半成立] + W-TGT-READ-TWIN 刀 1 交付[target-lexer.ktf 第八孪生——G1 首刀闭合]；v1.0——r135 开窗轮新建：用户常设指令①「完整完全自举优先」+「将解决 kerf 中任意递归深度纳入计划规划」的规划单源承载；SOP v15.3 §21.12-28③ 完成标准法定的操作化）
> **流程权威**: docs/sop.md v15.3（§21.12-28 自举完备优先纪律全条 / §21.7 风险表 / §17.3 依赖图规则优级行 / §13.1.2 第 5 项）
> **依据**: stage0.md §9.25（BS-A 自举策略）+ §9.113（K140-K142 自举时序锚）+ §9.121（K157-K162 r135 知识层）；roadmap v2.64 §2（Stage 2a 完全自举出口判据）；w3.12-frontend-window v5.0（前端三段 ELEVATED + T-a/T-b 触发器）；w-jit-method-t1-window v1.0（本规划的性能前置窗单源）；tech-debt-register（登记窗台账）；tool-results/r135-search/REPORT.md（知识检索七件）
> **职责边界**: 本文档承载**自举完备（完全脱离宿主语言）的剩余窗口序列、排序裁定、每窗细粒度 MUV、完成标准操作化与测量计划**；全局阶段节点/时间治理四红线由 roadmap.md 单源承载，本文只引用；各窗实施细节由各自窗口档单源承载，本文承载序列与排期。
> **宪制排除项**（§21.12-28③ + 原则 53——永不入自举链，不计入「完全脱离」分母）：VM 永久 Rust 基座 / 构建引导层（cargo + r124 宪法性排除裁定）/ 链外后端（C/LLVM/QBE——W-3.8 家位）。

## 1. 完成标准操作化（§21.12-28③ 法定标准的工程判据）

**法定原文**：自举完成 = 完全脱离宿主语言——自举后所有阶段的设计与开发通过自身语言进行；宪制排除项除外。

**工程判据（可验收四条）**：

| # | 判据 | 验收形态 |
|---|---|---|
| C1 | **kerf 源的 kerf 编译链**：.ktf 目标皮肤源 → 读（目标皮肤读链孪生）→ 展（expander.ktf）→ 查（infer.ktf + typecheck.ktf）→ 编（compiler.ktf）→ 字节码 → VM 执行——全链无 Rust 编译段参与 | 组成链等价断言：`pipeline_ktf(S) == pipeline_rust(S)` 全语料两皮肤 sweep + fixpoint（自编译自执行字节一致） |
| C2 | **生产位切换**：上述孪生链为**生产链**（Rust 各段退役为种子链 oracle——验证面保留，E5 同构先例）；开发工作流（编辑 .ktf → 编译 → 测试）经 kerf 自身进行 | 切换窗五步走通（§5）+ K159 不动点管线 A/B/C 三工件 B≡C 位级 |
| C3 | **递归深度通解**：任意递归深度由内存预算治理非固定整数帽（eval/VM 激活记录堆化；读/析层护栏可配置——K162 范围化）；fixpoint 自源构建在新机制上完成、无 VM-only 括号依赖 | 深非尾递归仅受内存约束测试 + 深尾递归恒定栈高测试 + fixpoint 无括号自建测试 |
| C4 | **语言自我推进面**：语言进一步开发所需的读/展/查/编/测/基（基准）面全部可经自身语言表达与执行（语料 sweep 经稳态链、基准经 VM 计时面）；Rust 面收敛为宪制排除项 + oracle 验证面 | 稳态链全语料 sweep + 基准程序经 VM 运行实录 + Rust 面清点表（排除项 + oracle 逐项） |

## 2. 现状地图（v0.95.0 时点——已完成 / 缺口）

**已完成（账面清偿）**：

- **前端 S-expr 链三段 ELEVATED**（read r121 / expand r123 / HM 判定面 r131）+ compile 孪生在位（r124 组合分析面）——BS-A 前端全段收敛（r131）
- **注入通道生产化**（r121 INJ-1..INJ-5：`inject_global` + fail-closed 三面 + 稳态链形制）——T-b 纯度面已消费
- **孪生七件**（lexer/reader/expander/macro/infer/typecheck/compiler .ktf = 9,822 行）parity 位级 + fixpoint 自复现 + gate B 全语料
- **融合两刀**（r133 CallGlobal + r134 F1 直发算术——B 轴 0.75×，两刀 -25.0%）
- **W-PKG-SELFHOST 前置其一**（融合刀交付——r132 精确化裁定）

**缺口（本规划的排期对象）**：

| # | 缺口 | 性质 | 现状锚 |
|---|---|---|---|
| G1 | ~~目标皮肤读链孪生不存在~~ **已闭合（r136 刀 1 + r138 刀 2 + r139 刀 3——C1 链路级终态）**：.ktf 文本→树经 target-lexer.ktf + target-parser.ktf 孪生（稳态链形态 + K20 桥），组成链五联差分全绿（composed_target_read_chain——C1 断链闭合） | r139 终态（AV 族 380/380） | w3.12:94 |
| G2 | ~~任意递归深度未通解~~ **已闭合（r136 刀 1 + r137 刀 2——C3 终态宣告）**：eval 堆激活栈化（10^5 深非尾递归默认栈实测 + 深尾递归恒定栈高）+ 四层帽 K162 可配置护栏（with_limit 全链 + env 单源 fail-closed）+ r74/r85 VM-only 括号全链退役（fixpoint 无括号自建） | r137 终态（C3 四验收腿全绿） | 本计划 §4.1 r136+/r137+ 行 |
| G3 | ~~T-a 性能带未达~~ **已裁决（r142 刀 2——w-jit-method-t1-window v1.2 §8 MJ-5/MJ-6）**：性能面实测裁决完成 = 链内最优形态锁定（纯解释 + LLC——B2 66.1ms = 2.79× 带缺口登记）；三触发器未清账（2.79× / 64.2% / ~339×）但消除杠杆（真 codegen）在链外（W-3.8 可选位——零 codegen 约束下 27 臂 match 解释器即最优分派形态，K152/K157 实测兑现）——链内结构性天花板诚实登记；LLC 杠杆归属改判（r135「tier-1 兑现」论题实测证伪 → 墙时净负资产，链内退役/维持延后 T-a 开窗轮重审） | 性能前置（**裁决完成——窗口 CLOSED**） | r142 §3.2 三跑 + w-jit-method-t1-window v1.2 §8 |
| G4 | ~~生产位未切换~~ **已闭合（r145-r149 五刀终态）：read + expand + check + compile 四段生产位全切换（r145-r148）+ step ⑤ 工作流宣告 + C1-C4 验收对账（r149）**——孪生链为生产链，Rust 各段退役为种子链/oracle 验证面（E5 同构先例）；T-a 窗口 CLOSED @ r149（w-t-a-switch-window v1.5） | r149 终态（T-a 关窗） | w-t-a-switch-window v1.5 |
| G5 | **包管理器未自举**：kerf-pkg = Rust 构建引导层（r115 PKG-2 裁定）；W-PKG-SELFHOST 前置其二「功能冻结」与禁止冻结政策冲突待重审（§7） | 后置基础设施（K161 解耦先例） | tech-debt r115 行 |
| G6 | **eval 引擎未退役**：W-EVAL-RETIRE 触发器 T-a/T-b 未达（T-b 已消费 r121；T-a 未达）；元循环求值器 = 唯一规划退役能力 | 切换后收尾 | w3.6 档 |
| G7 | **S-expr 表面存续（双皮肤态）**：bootstrap-parser 脚手架（.krf 皮肤 + Rust S-expr 读链 + reader.ktf 孪生 + 双皮肤语料/parity 面）在 target 读链闭合（G1 ✓）后进入拆除窗口——「完全自举后完全使用目标语言的词法语法语义」（用户指令⑥）未兑现 = 自举终态的组成缺口。**r150 实态：语料层已拆〔109 .ktf 单皮肤 + 112 .krf 离树〕；余读链层/词面层/台账层 = 刀 2/3** | 脚手架拆除面（R5 生命周期拆除位——§2.2 原则 41/53） | subset-spec §0 + 本计划 §4.4（r140 新登记）+ w-sexp-retire-window v1.1 |
| G8 | **语言基础面未完备**：struct/enum/类型注解消费/行多态等类型系统成员 = Stage 2+ 登记态（stage0 §9.14.2 R4 实况对账）——生产面仅 HM 单态推断（Int/Float/Bool/Str/Nil/Pair/Arrow/TVar/EffectRow）；目标 parser 类型注解 parse-and-drop（桥就位语义未接——parse_type_drop:1602） | 后置语言演进（自举完备后首议程——用户指令⑤⑦；详见 §9 时点裁定） | stage0 §9.14.2/§7.4 + 本计划 §4.5/§9（r140 新登记） |

## 3. 窗口序列（粗粒度——排序裁定 + §21.12-28① 合规性）

```text
v0.95.0 (r134 闭合态)
  │
  ├─► W-JIT-METHOD-T1〔OPEN @ r134——性能前置窗〕
  │     r135 tier-0.5 收尾刀（LLC 复制对融合 20%）
  │     r136+ W-REC-DEPTH 共享基座（G2——堆激活栈）
  │     r137+ tier-1 方法 JIT（TJ-4 去分派形态，构建于 G2 之上——TJ-3）
  │     出口：三触发器清账 + T-a 链路复画像
  │
  ├─► W-TGT-READ-TWIN〔新登记 @ r135——G1 目标皮肤读链孪生〕
  │     （与 W-JIT-METHOD-T1 的 r136+ 阶段可并行排期——.ktf 语义编写面 vs
  │       VM 基座面零交集；串行执行时单代理按窗口纪律逐窗）
  │     出口：.ktf 读链 kerf 承载 + 双皮肤全语料 parity + 读段自应用
  │
  ├─► T-a 生产位切换窗〔G4——组合面前置 = G1+G2+G3〕
  │     五步流程（§5——K159 不动点管线）+ 分段切换序（§5.2）
  │     出口：C1+C2 验收 + K140 带（切换性能回退 ≤ ~10× 接受——收窄后置）
  │
  ├─► W-SEXP-RETIRE〔G7——新登记 @ r140；S-expr 脚手架拆除窗（R5 拆除位）〕
  │     前置：T-a 切换窗 step ④ read 段生产位（拆除权发生位）+ TD-027 清偿
  │     出口：词法语法语义全目标语言单皮肤 + S-expr 面全树清零（用户指令⑥终态）
  │
  ├─► W-PKG-SELFHOST〔G5——触发器反冻结重审后按 §7 裁定行权〕
  │     出口：kerf-pkg 的 .ktf 承载或维持构建引导层宪制位（裁定单源）
  │
  ├─► W-EVAL-RETIRE〔G6——T-a 达成后行权；w3.6 档单源〕
  │     出口：eval 引擎退役为测试面 / 移除
  │
  └─► 自举完备验收（§1 C1-C4 四判据 + 单皮肤终态核验 + 完成标准宣告 + roadmap Stage 2a 出口对账）
        │
        ▼
     W-LANG-FOUNDATION〔G8——新登记 @ r140；语言基础完备窗（自举完备后首议程）〕
       前置：C1-C4 验收通过（§21.12-28① 从属位解除时点）+ TD-027 + TD-026 重审（§4.5）
       出口：类型注解消费面 + struct/enum 脱糖面 + 模式匹配扩展（§4.5 细粒度 MUV）
```

**排序裁定（ARCH-A @ r135，逐窗可审计理由——§21.12-28①）**：

| 序 | 窗 | 优先级依据 |
|---|---|---|
| 1 | W-JIT-METHOD-T1（含 W-REC-DEPTH 前置刀） | 已开窗在航（r134 三触发器；tier-0.5 收尾刀 r135 已交付 + W-REC-DEPTH 两刀 r136/r137 已交付——G2 ✓）+ T-a 链路性能前置；下一刀 = tier-1 刀 1（TJ-4 去分派形态） |
| 2 | W-TGT-READ-TWIN | G1 = C1 结构性断链（语言读不了自己的源 = 一切自举链的最前置断点）；**三刀全交付 r136/r138/r139——G1 ✓ C1 链路闭合（窗口关闭）** |
| 3 | T-a 切换窗 | 组合面前置 = 窗 1（G3 性能带）+ 窗 2（G1 ✓）+ G2 ✓ 已凑其二；K159 五步 + 分段序；K140 性能带诚实预期（组合面——w3.7 §4.3 登记）；**r143：前置全凑齐（TD-027 ✓）——开窗合法成立，step ① 落档 + step ② = r144 首刀 + LLC 维持在位裁定（W-3.8 再重审）；r144：step ②+③ ✓ 交付（B ≡ C 六工件位级——K159 门首证；step ④ 分段切换 = 下一刀）** |
| 4 | W-SEXP-RETIRE〔r140 新登记〕 | 用户指令⑥终态（完全自举后完全使用目标语言词法语法语义）+ R5 拆除判据前置已满足（target 读链 G1 ✓ = 自建替代全语料覆盖 + 额外能力[类型注解语法/胖关键字] > 0）；**置于 T-a 后首位**：read 段生产位 = 拆除权发生位；且先于 W-EVAL-RETIRE = 最大表面迁移（62+ 语料双皮肤→单皮肤）需要双引擎 parity 安全网在场（eval 退役后失去该安全网——迁移验证成本结构性上升） |
| 5 | W-PKG-SELFHOST | K161 解耦先例（opam 语言无关）——PM 自举后置于编译器自举；触发器反冻结重审见 §7 |
| 6 | W-EVAL-RETIRE | 唯一规划退役能力；T-a 后 eval 退为测试面，退役 = 收尾清账（置于 W-SEXP-RETIRE 后——序 4 技术理由） |
| 7 | W-LANG-FOUNDATION〔r140 新登记〕 | 用户指令⑤（语言自身底层和基础内容完成纳入计划）+ K140-K142 先例族（自举达成后特性经自托管编译器发展 =「自己用自己语言推进自己」正型路径）；**置于自举完备验收后**（C1-C4 未验收期间非自举段维持从属位——§21.12-28① 豁免声明一致；语言基础窗为验收后首议程） |

**非自举段排期豁免声明**：本序列不含 W-3.5（Token 流+图 IR 优化）/ W-3.8（链外后端升级）/ W-3.9（诊断增强）等非自举窗——按 §21.12-28① 排期非自举段须附可审计裁决理由：**自举矩阵未达完成标准（§1 C1-C4 未验收）期间，上述窗维持从属位（触发器信号出现时单独裁定，裁定须过本计划 §3 序前置核对——自举窗就绪即让位）**。**W-LANG-FOUNDATION（序 7）为该从属位的法定解除对象**：C1-C4 验收通过时点 = 从属位解除时点，语言基础窗作为验收后首议程开窗（用户指令⑤⑦——语言自我推进面的首个消费议程）。

**S-expr 移除规划声明（用户指令⑥——r140 落位）**：本项目设计规划**不考虑 S-expr 延续**——S-expr 皮肤 = bootstrap-parser 脚手架（R5 完整生命周期登记：搭建[Stage 0-1]→使用[当前]→自建[孪生链]→拆除[W-SEXP-RETIRE]→超越[单皮肤终态]）；完全自举后词法语法语义全量使用目标语言，S-expr 表面（皮肤/语料/Rust 读链/孪生）全树拆除零延续义务。转化面台账单源 = docs/develop/v3/s-expr-conversion-record.md（r140 新建——每新增转化面三处同步：台账 + 本计划窗口行 + stage0 §9.12X）。

## 4. 前置窗细粒度 MUV（fine——窗口 1/2 的刀级排期）

### 4.1 W-JIT-METHOD-T1（性能前置窗——w-jit-method-t1-window.md v1.0 单源）

| MUV | 内容 | 集成验证 |
|---|---|---|
| 135-b（本轮） | LLC 融合全链：opcode 27 化（`load-local-const {a: slot, b: const-idx}`，pops 0/pushes 2）+ VM 双压臂 + verify Pass 1 双边界 + .krf 往返 + C 后端复合 + compile args 环视特判 + compiler.ktf 孪生同步 + 守卫再生成 + 新族 ≥8 + audit AQ 10 案 + B 轴三跑 | 融合/非融合同程序同值双臂 + 全语料 sweep 零残留对 + gate B 逐位 + fixpoint 自复现 |
| r136 ✓（W-REC-DEPTH 刀 1 @ v0.97.0） | 堆激活栈基座（已交付）：VM 帧栈从宿主递归栈解耦（显式帧栈 + 循环主循环既有形态的深度面扩展）+ EVAL_DEPTH_LIMIT 帽解除为内存预算治理 + eval 引擎闭包应用路径对齐 | 深非尾递归仅受内存约束（构造 10^5 深度程序实测）+ 深尾递归恒定栈高 + D-CLASS-1 三元组逐位维持 |
| r136+ ✓（W-REC-DEPTH 刀 2 @ v0.98.0） | 四层帽可配置护栏（已交付）：reader 256/expander 512/compiler 1024/pkg 512 全部 `with_limit` 参数化 + 保守默认逐位维持 + driver `DepthLimits` env 单源消费（三键 + kp 独立键，fail-closed 解析）+ **r74/r85 VM-only 括号全链退役**（fixpoint step-3 双引擎化 + composed junction-1 双引擎化 + harness-limit 分类回归守卫化——C3 第三验收腿「fixpoint 无括号自建」达成）+ 四层谱系文档对账（原则 58：默认保留 + 可配置） | 深嵌套语料（600 深）读入实测 ✓ + 默认帽黄金零漂移 ✓ + fixpoint 无括号双引擎 ✓ + 全语料回归 1586:0:4 ✓ |
| r141 ✓（tier-1 刀 1 @ v0.102.0） | 方法编译基础设施（已交付）：census per-function 调用计数阈值 64〔MJ-2〕+ closure chain 去分派执行形〔MJ-1——节点 1:1 镜像臂，构造性 parity〕+ 永久回退〔失败无重试〕+ canonical listing 确定性〔MJ-4〕+ run_dispatch loop-top 引擎选择 + OBSERVE 驱动器单化〔MJ-3〕 | 双路同值〔值/输出/allocations 逐位——阈值 MAX vs 1 vs 默认 64〕+ 回退触发实测〔构建器三拒绝面直调〕+ 确定性〔两次构建 listing 逐位相等〕+ 全树 1607 绿〔fixpoint/gate B/parity/census 锚在 tier 开启态〕 |
| r138+（tier-1 刀 2） | tier 分派集成（tier-0.5 融合层与方法层协作）+ 守卫族 + audit 新节 + B 轴对照 tier-0.5 收尾基线 + 三触发器复画像 | B2 带内 + 分派份额复画像 + T-a 链路复画像 |

### 4.2 W-TGT-READ-TWIN（目标皮肤读链孪生窗——新登记）

| MUV | 内容 | 集成验证 |
|---|---|---|
| 刀 1 ✓（twin 语义面 @ v0.97.0） | target lexer 孪生（已交付）：`crates/kerf-reader/src/target/lexer.rs` 的 .ktf 全量镜像（trivia/拒绝集/操作符规范名表/数字文法）为 target-lexer.ktf；字节表注入通道消费（RS-1 形制沿袭） | 孪生/Rust oracle token 流逐位（全语料 + .ktf 自源族 + 拒绝集边界族） |
| 刀 2 ✓（parser 孪生 @ v0.99.0） | target Pratt parser 孪生（已交付）：target-parser.ktf 3,281 行（帧机形制——14 级优先级瀑布 + do/let 反向折叠 + quote datum 载体 + 模式族 + 类型注解 drop + 胖关键字全表 + fail-closed UnsupportedTargetForm 面；TP-1 注入通道[token 记录表/嵌套限/消息文本表 21 键]） | curated 91/91（正 50/负 41）+ selfhost 九源固定点（含孪生自身源最深自应用）+ 拒绝面 ≥35 同键 + audit AU 族 10 案（370/370） |
| 刀 3 ✓（C1 链路闭合 @ v0.100.0） | 已交付：SteadyTargetReaderChain[两孪生各编译一次——lexer 程序 target-lexer.ktf 引用 source-bytes 槽；parser 程序 = tp-forms 表 + tp-limit 256 常量 + target-parser.ktf 引用 tp-tokens 槽；每读四引擎跑（lexer vm+eval → K20 桥 → parser vm+eval）] + 读段自应用[selfhost 九源 + 孪生自身 3,281 行——最深固定点] + 组成链扩展[composed_target_read_chain：J0 token/J0.5 tree/J1 expand（稳态展开链——值面无 r103 文本边界）/J1.5 check（SteadyCheckChain——查段入组成链）/J2 compile（ktf_compile_rich 终端字节码等同）] + fixpoint 纯度腿[Phase-2 assembled 自应用程序读经孪生前端 twin_front_end_read == 生产桥 items 断言] | 自源 parity（engines agree + forms 重建）+ 组成链等价（91 curated + 九源 + 组装展开器程序全公式）+ fixpoint 复现（b_self_exec == b_self 维持 + 孪生读段新腿）+ AV 族 10 案 380/380 |

### 4.3 T-a 切换窗（G4——r143 开窗对账落档）

**r143 开窗对账：前置全凑齐**（G1 ✓ + G2 ✓ + G3 裁决完成〔r142〕+ TD-027 ✓〔r143 清偿〕）→ **T-a 开窗合法成立**。

**K159 五步排期**（§5 单源的操作化）：
- **step ① 种子链固化〔r143 ✓ 落档〕**：宪制排除项清点表 = ①VM 永久 Rust 基座（kerf-vm——"完全自举"VM 重写 = 宪制排除项，原则 53）；②构建引导层（cargo + r124 宪法性排除裁定）；③链外后端（C/LLVM/QBE——W-3.8 家位，永不入自举链）；④oracle 验证面（Rust 各段退役为 parity oracle——E5 同构先例，验证面保留）。种子工件清点表 = ①Rust 编译器（生产位全树 12 crates）；②孪生九件（lexer/reader/macro/expander/infer/typecheck/compiler + target-lexer/target-parser——14,243+ 行台账，s-expr-conversion-record.md 单源）；③注入通道（INJ-1..INJ-5：inject_global + fail-closed 三面 + 稳态链形制）；④组成链（composed_target_read_chain J0 token → J0.5 tree → J1 expand → J1.5 check → J2 compile——五联差分 pipeline_ktf(S) == pipeline_rust(S)）；⑤fixpoint（b_self_exec == b_self + 深自应用 + 读段孪生前端）。
- **step ② A/B/C 工件管线〔r144 ✓ 交付 @ v0.105.0〕**：A = Rust 编译器以普通生产管线编译六 CCF（链可编译形——extern 槽声明 + 孪生源）；B = 孪生链（骑 A 工件、VM 臂、注入通道 + SteadyCompilerChain）编译链自身；C = 同链形骑 B 工件再编译。**B ≡ C 位级六工件全过**（A ≡ B parity 观察行同真）——w-t-a-switch-window.md §2 单源（TA-1 CCF 形制 + TA-2 三轮操作化 + TA-3 四缺陷清偿 + TA-4 编译段稳态形）。
- **step ③ 不动点门〔r144 ✓ 与 step ② 同轮交付〕**：B ≡ C 位级（K159：不动点 = 验证门非构建步骤）——六工件 Bytecode PartialEq 全描述符表 + golden 集成测试承载（~325s release——十二次全链自编译上 VM）。
- **step ④ 分段生产位切换**：read → expand → check → compile 逐段（每段：孪生为生产位 + Rust 段退役为 oracle + 全语料 parity 门 + 段级回退带〔§14.6.4 规则 5 测量先行〕）。**read ✓（r145）+ expand ✓（r146）+ check ✓（r147）——compile 段 = r148 下一刀**。
- **step ⑤ 工作流宣告**：C1/C2 验收 + K140 带如实登记（切换性能回退接受 + 收窄后置——Go 1.5 先例）。

**r144 交付实态**：step ②+③ ✓（v0.105.0）；下一刀 = step ④ 分段生产位切换（read → expand → check → compile 逐段——w-t-a-switch-window §3 排期）；四缺陷清偿单源 = 同档 §2 TA-3 + K163 新锚（新输入域即新审计域）。

**K140 带组合面重审结论（r143）**：~10× 惨案带**维持为 step ⑤ 验收带**；达成路径诚实化 = 链内最优形态已锁定（纯解释 + LLC——r142 实测裁决，链内无杠杆/结构性天花板登记），10× 内达成依赖 ①稳态链摊销口径（编译孪生一次 + N 次读/展/查/编——§6 测量计划）+ ②A/B/C 工件实测（真实链路带在 step ② 落地时落档）+ ③〔可选〕W-3.8 链外加速（宪制排除项外家位）。**开窗轮不预设达标时点**（时间治理红线一：信号驱动非日历驱动）。

**LLC 链内退役/维持重审裁定（r143 ARCH-A——r142 改判登记的延后重审兑现）**：**LLC 维持在位**。机制区分 = LLC 是编译期静态字节码融合（零运行时分派开销），与被 r142 实测证伪的运行时 tier 分派（closure chain 净负 ~9%）不同机制类——r142 证伪的是「兑现载体」非融合指令本身；账面 = r135 融合刀 +3% 墙时实测未被证伪（链内唯一实测正收益机制），退役成本 = opcode 27 全链回退（VM 27 臂 + verify + .krf 往返 + C 后端 + compiler.ktf 孪生 + AQ 族守卫 + B 轴基线）远超 3% 墙时差；再重审时点 = W-3.8 真 codegen 窗（届时融合产物有 codegen 消费面）。

### 4.4 W-SEXP-RETIRE（S-expr 脚手架拆除窗——r140 新登记；G7；R5 生命周期拆除位）

> 前置 = T-a 切换窗 step ④ read 段生产位（孪生读链为生产位——拆除权发生位）+ TD-027 清偿（展开孪生 match 臂——T-a 前置门在册，r139 登记）。技术锚：SOP §2.2 原则 41/53（脚手架生命周期 + VM 基座宪制排除）+ R5 拆除判据（自建替代 ≥ 被替换物 × 98% 或额外能力 > 0——target 读链全语料覆盖 + 类型注解语法/胖关键字额外能力，双臂满足）+ r114 TD-007 转码器机械臂先例（skin_transcoder.rs——.krf→.ktf 语料迁移的既有工具面）+ E5 批次 3 一次性移除先例（r104——拆除纪律形制：替代链完整证明先于拆除）。

| MUV | 内容 | 集成验证 |
|---|---|---|
| 刀 1（语料单皮肤迁移）✓ r150 | 全语料 .krf→.ktf 转码 sweep（curated 62+ 案 + parity 契约面 + gate B 语料源 + corpus 期望面——skin_transcoder 机械臂扩展 + 逐案双皮肤等价预检）| 迁移后全语料 .ktf 单皮肤 sweep 等价（值/输出/拒绝三面）+ 双引擎 parity 维持 + 双跑确定性〔✓ 实测：109 案 sweep + 消费面 14 文件全绿 + C 回放 52/52 + 组成链账目 16/23/11/57/2 = 109〕|
| 刀 2（S-expr 读链退役） | Rust S-expr lexer/parser 退役为 oracle 验证面→移除 + reader.ktf 孪生退役（parity 职能终结）+ bootstrap/reader_parity.rs harness 收编 + driver 双皮肤分支收口 | 全测试树绿 + audit 族共变 + fixpoint 经目标读链维持（b_self_exec == b_self）+ gate B 逐位 |
| 刀 3（S-expr 面清零） | 全树词面清零扫描（S-expr 皮肤关键词/读取入口/双皮肤分支/转码器——rg 机检入守卫）+ subset-spec 状态行改写（双皮肤→单皮肤终态）+ 文档族对账（本计划 + stage0 + 台账三处单源） | 清零扫描守卫化（回归 = 任何 S-expr 表面复活即红）+ §8.5 文档检查单全过 + R8 编码面清零 |
| 出口 | 词法语法语义全目标语言单皮肤（用户指令⑥终态）+ R5 拆除判据核验双臂落档 | 单皮肤全语料 + fixpoint + 六命令全绿 |

### 4.5 W-LANG-FOUNDATION（语言基础完备窗——r140 新登记；G8；自举完备后首议程）

> 前置 = 自举完备验收（§1 C1-C4 + 单皮肤终态——序 7 从属位解除）+ TD-027（match 臂——enum 脱糖消费前置）+ TD-026 重审（堆类型 extern 扩展面开窗时随 R-F3 句柄协议——struct 表示跨 FFI 面）。技术锚：stage0 §9.14.2（类型系统成员三组——R4 实况对账）+ §7.4（内部语法 ADT 设计——7.4.3 2026 内部 AST 完整定义）+ §6.10（类型维前沿成熟度 ~30%——行多态评估非实施）+ tool-results/r76-search/（HM unify 家族七件：m1-rustc-unify_key.rs / m3-ghc-unify.hs / m4-rustc-relate.rs / m11-ocaml-btype.ml + value restriction q4）+ K140-K142（自举后语言自我发展先例族——Go 1.5 双链解耦 / rustc 2011 先自举后 1.0 稳定 / bootstrappable builds）+ subset-spec §2.1（语义面扩展经语义同刀 MUV 合法行使先例——Stage 2.1 翻转形制）。**时机裁定全链见 §9。**

| MUV | 内容 | 集成验证 |
|---|---|---|
| 刀 1（类型注解消费面） | parse_type_drop → 注解验证锚（「annotations are surface sugar the HM layer owns」后半句兑现：HM 推断 × 注解双向检查[标注-推断 unify——注解锚定收敛 TVar]；注解错误族 + 诊断码 + 位置面） | 注解程序正负语料（注解✓推断分歧 = 错误族）+ parity + audit 新节 + 双引擎面 |
| 刀 2（struct 表面 + 脱糖） | struct 声明 → 构造子/字段访问函数宏展开（表示层设计刀内裁定：pair 链 vs vector——通解优先 §12）+ HM 类型面扩展（Type 构造子形态刀内裁定）| struct 程序正负语料 + fixpoint 维持 + gate B + audit |
| 刀 3（enum 表面 + 脱糖） | tagged 构造子 + match 消费（oracle expand_match 既有超集——TD-027 清偿后孪生全量）+ 穷尽性检查面 | enum 程序正负语料（穷尽性缺口 = 负向族）+ audit |
| 刀 4（模式匹配扩展 + 行多态评估） | struct/enum 模式族收口（parser 模式族既有基础扩展）+ 行多态评估窗（§6.10 前沿 ~30% 成熟度——评估非实施，产出 = 判据 + 时机触发器登记）| 模式族语料 + 评估窗档案 + audit |
| 后续（登记态——零信号不开窗） | 效应族六官方实例（Read/Write/State/Async/Error/Log——§9.14.2 效应成员）+ 自定义效应语法 + 能力模型 L3（原则 34）+ 线性类型——各按独立窗单源排期 | 各窗单源定义 |

**工作流声明**：本窗全部实施经自托管工作流进行（编辑 .ktf → kerf 编译 → 测试/基准经 VM——C4 面的首个生产消费）；每刀交付物含 .ktf 自描述测试语料（语言经自身语言验证自身新能力——「自己用自己语言推进自己」的逐刀实证）。

## 5. T-a 切换窗五步（K159 操作化——种子→全量→自重建不动点）

```text
步骤 ①（种子链固化）   宪制排除项清点表落档（VM 基座/构建引导/链外后端/oracle 面）
                      + 种子工件 = Rust 编译器 + 孪生七件 + 目标读链孪生（W-TGT-READ-TWIN 产物）
步骤 ②（A/B/C 工件管线） A = Rust 编译器编译孪生链产物（今日既有形态）
                      B = 孪生链（经 A 产物运行）编译孪生链自身
                      C = 孪生链（经 B 产物运行）再编译自身
步骤 ③（不动点门）     B ≡ C 位级（K159：不动点 = 验证门非构建步骤；链条定长 A→B→C 工件显式）
步骤 ④（分段生产位切换） read → expand → check → compile 逐段切换（每段：孪生为生产位 + Rust 段退役为
                      oracle + 该段全语料 parity 门 + 回退带〔段级可回退——§14.6.4 规则 5 测量先行〕）
步骤 ⑤（工作流宣告）✓  开发工作流经 kerf 自身（编辑 .ktf → kerf 编译 → 测试/基准经 VM）实录落档
                      + C1/C2 验收 + K140 带如实登记（切换性能回退接受 + 收窄后置——Go 1.5 先例）
                      〔r149 交付：selfcheck+bench 语料 + 三跑 + C1-C4 对账全绿——T-a 窗口 CLOSED〕
```

## 6. 测量计划（T-a 链路度量操作化）

- **T-a 链路指标**：稳态链摊销口径（编译孪生一次 + N 次读/展/查/编）下，全语料吞吐 vs Rust 全链——既有 w312a 三份额分相形制扩展至四段全链（read/expand/check/compile 各段份额披露）。
- **阈值**：切换窗开窗前置 = JIT 窗出口（≤25×）；切换验收 = K140 带（~10× 惨案带接受 + 稳态摊销口径如实披露；<10× 收窄后置为切换后工程——非前置）。
- **诚实边界**：三杠杆合计预估 ~0.60×（B 轴）→ T-a ~275×；tier-1 2.5-3× → ~90-135×——**组合面仍需 W-REC-DEPTH 深度约束解除（自举链工程可用性）+ 目标读链（链路纯度）+ 稳态摊销口径三者的乘积效应实测**，本计划不预设达标时点（时间治理红线一：信号驱动非日历驱动）。

## 7. W-PKG-SELFHOST 触发器反冻结重审（用户「禁止冻结」指令 × r115 触发器设计的冲突裁定）

**冲突**：r115 PKG-2 登记 W-PKG-SELFHOST 双前置 = 「融合刀交付后（已达成 r134）」+「功能冻结」；用户常设指令 = 当前项目**禁止冻结**（活跃开发期，一切为最终结果让路）——「功能冻结」作为触发器在禁止冻结政策下永不满足 = 触发器设计失效（冻结导致的历史问题重审——用户指令原文「如果之前的设计中存在因为冻结导致的问题则可对其重新审理」）。

**重审裁定（ARCH-A @ r135）**：前置二从「功能冻结」改写为「**manifest 子集实证稳定**」——判据 = `kerf.toml`/`kerf.lock` 文法（micro-TOML 六形）与 semver 边界在最近 N 轮（N ≥ 5）零变更 + pkg 语料回归全绿（可机检锚，非政策性冻结）。**依据**：原前置的设计意图 = 防止自举一个文法仍在变动的包管理器（返工面）——实证稳定判据同达意图且不与禁止冻结政策冲突（§12 最优>最小：判据可审计可机检优于政策性口号）。**排期维持 K161 解耦**（PM 自举后置于 T-a——§3 序 4）；tech-debt-register 行同步改写。

## 8. 每轮复核义务（用户常设指令⑨——禁止过度特化 + 未解决问题阻断）

每轮执行本计划时复核：①本窗未解决问题数（>0 = 禁止推进下一窗——§21.12 段序硬规则）②通解性审查（融合/深度/JIT 形态均为通用机制非位点特化——r134 反过度特化审查形制）③登记窗触发器核对（tech-debt-register 台账与本计划 §3 序一致性）④完成标准 C1-C4 进度对账（本表随轮刷新）。

**r140 复核实态（规划刷新轮）**：①本窗未解决问题 = W-JIT-METHOD-T1 tier-1 两刀（排期内下一入口非阻断）+ TD-027（T-a 前置门在册）+ TD-026（riding——堆类型 extern 扩展面门条件）——零未登记问题；②通解性 = 本轮交付全为规划域通解（窗序/缺口入账/台账/裁定），无位点特化——两新窗均为机制窗非特化窗（拆除窗 = 脚手架生命周期通用拆除；语言基础窗 = 类型系统成员通设面）；③登记窗核对 = W-SEXP-RETIRE/W-LANG-FOUNDATION 两新登记（tech-debt r140 检视节）与本计划 §3 序 4/序 7 一致；④进度对账 = C1 ✓（r139）/ C3 ✓（r137）/ C2 ✗（T-a 未开——前置 G1 ✓ + G2 ✓ + G3 在窗）/ C4 ✗（随 C2）。

**r142 复核实态（tier-1 刀 2 出口轮）**：①本窗未解决问题 = 零（W-JIT-METHOD-T1 三刀全交付 + 出口裁定落档 = 窗口 CLOSED；下一窗 TD-027〔T-a 前置门〕+ T-a 切换窗开窗对账）；②通解性 = 刀 2 交付全为机制面（生产默认翻转/early-out/测量面双臂/守卫族）——零位点特化（默认翻转影响全程序非特化程序；测量工具升级为通用对照面）；③登记窗核对 = W-JIT-METHOD-T1 CLOSED（本计划 §3 序 1 + tech-debt r142 检视节 + w-jit-method-t1-window v1.2 Status 三处一致）；④进度对账 = C1 ✓（r139）/ C3 ✓（r137）/ C2 ✗（T-a 未开——前置 G1 ✓ + G2 ✓ + G3 裁决完成 → **开窗合法成立，下一入口 = T-a 切换窗开窗轮 + TD-027 前置门**）/ C4 ✗（随 C2）；⑤LLC 杠杆改判登记 = 墙时净负资产（r135 +3% 维持 + tier-1 兑现载体实测否决）——链内退役/维持延后 T-a 开窗轮重审（opcode 全链回退成本 vs 墙时 3% 的权衡在切换窗组合面裁定）。

**r148 复核实态（T-a step ④ compile 段交付轮——step ④ 闭合）**：①本窗未解决问题 = 零（compile 段切换全链交付〔编译孪生链 + co_limit 预算镜像 + K163 第五/六实例 + 孪生三潜在缺陷〕；step ⑤ = 下一刀〔排期内非阻断〕）；②通解性 = 机制面（全 .ktf 生产编译通用 + co_limit 装配前缀 tp_limit/ex_limit 先例 + 通用环境面回退带 + 预算键控缓存 + verify 两法官产品边界——零位点特化）；③登记窗核对 = w-t-a-switch-window v1.4（TA-8 形制单源 + K163 第五/六实例）与 tech-debt r148 检视一致；④进度对账 = C1 ✓ / C3 ✓ / **C2 前半 ✓（K159 门）+ C2 后半 read+expand+check+compile 四段全 ✓（本轮——step ④ 闭合）/ C4 ✗（step ⑤ 宣告 = 下一刀）**；⑤K140 段级切片带 = compile 段三跑落档（compile_segment_profile——curated 1.2× / CCF 1.7× / spine 1.3-1.5×，四段最优，回退带在场，收窄后置）。

**r147 复核实态（T-a step ④ check 段交付轮）**：①本窗未解决问题 = 零（check 段切换全链交付〔双检查孪生链 + 诊断结构化重建 + harness 自检钉位 P0 回归当轮清偿 + K163 第四实例当轮清偿〕；下一刀 = compile 段〔排期内非阻断——SteadyCompilerChain r144 在位〕）；②通解性 = 机制面（全 .ktf 生产检查通用 + 通用环境面回退带 + 注册表单源查表——零位点特化；harness 钉位 = 面类别裁定〔链工件 vs 用户程序〕）；③登记窗核对 = w-t-a-switch-window v1.3（TA-7 形制单源 + harness 钉位裁定）与 tech-debt r147 检视一致；④进度对账 = C1 ✓ / C3 ✓ / **C2 前半 ✓（K159 门）+ C2 后半 read ✓ + expand ✓ + check ✓（本轮）/ compile 段 ✗（排期内）/ C4 ✗（step ⑤）**；⑤K140 段级切片带 = check 段三跑落档（check_segment_profile——curated 1.4-1.5× / CCF 3.8-23× / spine 1.4-4.0×，回退带在场，收窄后置）。

**r146 复核实态（T-a step ④ expand 段交付轮）**：①本窗未解决问题 = 零（expand 段切换全链交付〔junction-2 双拒绝面 + 预算镜像 ex_limit 参数化 + 三种子面钉 + 回退带 + 测量三跑〕+ K163 同族预防位全量〔forms_stream 右脊 dispose 共享化×全注入位〕；下一刀 = check 段〔排期内非阻断〕）；②通解性 = 机制面（全 .ktf 生产展开通用 + 预算镜像 tp_limit 先例 + 通用环境面回退带 + 预算键控缓存——零位点特化）；③登记窗核对 = w-t-a-switch-window v1.2（TA-6 形制单源）与 tech-debt r146 检视一致；④进度对账 = C1 ✓ / C3 ✓ / **C2 前半 ✓（K159 门）+ C2 后半 read ✓ + expand ✓（本轮）/ check+compile 段 ✗（排期内）/ C4 ✗（step ⑤）**；⑤K140 段级切片带 = expand 段三跑落档（expand_segment_profile——回退带在场，收窄后置）。

**r145 复核实态（T-a step ④ read 段交付轮）**：①本窗未解决问题 = 零（read 段切换全链交付 + K163 三同族缺陷当轮清偿 + 测量三跑落档；下一刀 = expand 段〔排期内非阻断〕）；②通解性 = 机制面（全 .ktf 生产读通用 + 通用环境面回退带 + 帽键控缓存——零位点特化）；③登记窗核对 = w-t-a-switch-window v1.1（TA-5 形制单源 + K163 第二实例）与 tech-debt r145 检视一致；④进度对账 = C1 ✓ / C3 ✓ / **C2 前半 ✓（K159 门）+ C2 后半 read 段 ✓（本轮）/ expand+check+compile 段 ✗（排期内）/ C4 ✗（step ⑤）**；⑤K140 段级切片带 = read 段三跑落档（每读 240-990× + 链构造 ~30ms——回退带在场，收窄后置）。

**r144 复核实态（T-a step ②+③ 交付轮）**：①本窗未解决问题 = 零（step ② A/B/C + step ③ 门全链交付——B ≡ C 六工件位级；四前置缺陷当轮清偿〔join/截断/边序/编码〕）；②通解性 = CCF 形制 + 段运行器 + 三轮驱动全为机制面（六件全链通用，无位点特化）；③登记窗核对 = w-t-a-switch-window.md v1.0 新建（T-a 窗档单源）+ K163 新锚入 stage0 §9.130；④进度对账 = C1 ✓ / C3 ✓ / **C2 前半 ✓（K159 不动点门首证——生产位切换的验证基座就位）** / C2 后半 ✗（step ④ 分段切换 = 下一刀）/ C4 ✗（随 step ⑤）；⑤台账行数共变 = infer.ktf 3,690→3,774（三修复）+ r143 陈旧清偿 expander.ktf 1,671→2,227（TD-027 match 臂补账）——累计 14,243→14,883 实测口径。

**r143 复核实态（TD-027 清偿 + T-a 开窗对账轮）**：①本窗未解决问题 = **TD-027 清偿关闭**（expander.ktf match 臂全链 + J0.9 退役 + 语料 21 案 + 五守卫 + 转码器 + AY 族——tech-debt r143 检视节单源）；②通解性 = match 臂 = oracle 逐决策镜像的机制面（六模式族通设 + 错误顺序钉扎），零位点特化（语料族为模式族全覆盖非特化程序）；③登记窗核对 = TD-027 关闭（tech-debt r143 + 本计划 §2 G4 行 + §4.3 三处一致）；④进度对账 = C1 ✓ / C3 ✓ / C2 ✗（**T-a 开窗合法成立——step ① 落档，step ② A/B/C 工件管线 = r144 首刀**）/ C4 ✗（随 C2）；⑤LLC 重审裁定 = 维持在位（§4.3 裁定段单源——W-3.8 再重审）。

## 9. 目标语言基础类型时点裁定——enum/struct「自举流程零使用」的正面回答（r140 · 用户审查指令）

> **问题原文**：kerf 目标语言当前在编写自举流程中从未出现使用目标语言的基础类型和能力，如 enum、struct……是还未实现还是当前这种好？如果实现为什么不用？如果还不实现那么为什么不实现？是时机未到还是遗忘？
>
> **裁定**：**时机未到（非遗忘、非能力回避）——设计已全量登记 + 语法桥已生产就位 + 语义实现窗法定于 C2 生产位切换之后（§4.5 W-LANG-FOUNDATION）；当下不实现是串行自举纪律（§21.12-28 + 用户指令⑦）的必然结果，且与 8 原语不变性零冲突（struct/enum = 派生表面非原语面）。**

### 9.1 证据链四层

1. **设计登记在位（非遗忘之证一）**：stage0.md §9.14.2 类型系统成员三组提案登记态——基础类型（i8-i64/u8-u64/f32-f64/bool/char/str/`()`）+ **复合（struct/enum）** + 泛型 + 行多态（union）+ 交叉类型 + 行类型 + 效应行 + 线性能力；§9.14.8 F3 裁定行明确「行多态/交叉/开放记录/线性句法 = Stage 2+ 登记态（HM 已生产 r80）」；§7.4 内部语法设计整节（7.4.3 2026 内部 AST 完整定义——类型安全 ADT 与语义化命名）。登记面 20 轮以上持续对账（R4 实况对账行随轮刷新）。
2. **语法桥生产在位（非遗忘之证二）**：target parser `parse_type_drop()`（crates/kerf-reader/src/target/parser.rs:1602——类型注解全族解析后 drop：「annotations are surface sugar the HM layer owns」）。语法层已完整实现（路径/泛型参数/圆括类型表/联合/函数返回/impl·effect 前缀——r138 parser 孪生 3,281 行逐决策镜像含此面），语义层归属 HM（types.rs:20 Type = Int/Float/Bool/Str/Nil/Pair/Arrow/TVar + EffectRow——零用户定义类型）。**桥就位、语义未接 = 显式的「等待接线」状态而非「从未考虑」状态**。
3. **自举流程零使用之因（三层结构性理由）**：
   - **冻结子集 = 自举目标面**：.ktf 孪生写于 subset-spec §1.2 八表达式形式 + §1.1 四声明头（9 CoreExpr 语义原语锚定）。孪生完备性的可验证性（parity 位级 + fixpoint 自复现 + gate B 全语料）依赖子集极小性——每加一个语义面 = Rust oracle + .ktf 孪生双实现 + 双侧审计成本。
   - **串行自举硬规则**（用户指令⑦ + §21.12-28）：前一编译阶段完整完全自举后才进下一阶段。当前阶段 = 编译管道自举完备（C1 ✓ / C3 ✓ / G3 在窗 / G4-G6 + G7 待）；数据类型不是 C1-C4 组成面，且现在实现 = 在宿主依赖态双实现 → 违反串行纪律 + 留双份维护隐患（不完整的自举不是自举——同一纪律的自举前投影）。
   - **生产位切换后语言经自身推进**：C2 后开发工作流 = 编辑 .ktf → kerf 编译 → 测试/基准经 VM。届时 struct/enum 经自身语言实现 =「自己用自己语言推进自己」正型路径——K140（Go 1.5 自举切换后特性经自托管编译器发展）/ K141（rustc 2011 先自举后 0.1 公开与 1.0 稳定）/ K142（bootstrappable——链完备可审计即目标本身）三锚的 kerf 投影。
4. **与 8 原语不变性零冲突**：struct/enum = 表面语法糖——「全部可宏展开为原语组合」（stage0 §9.14.2 语法成员节同款原则：表面关键字编译产物 = 相同核心形式）。数据类型不新增原语（9 CoreExpr 不变——8 原语不变性第 N 轮验证口径持续），类型系统侧 HM+ADT 推断是检查器面扩展（infer/typecheck 段语义面）非内核扩张。内核冻结原则（§3.2 设计约束）与数据类型表面化正交——这正是极小内核设计的意图：丰富度全部生长在派生层。

### 9.2 「当前这样好」的边界（诚实回答）

- **在 C1-C4 完成前**：是——纪律正确性成立（上述三层结构性理由）；提前实现 = 双实现负担 + 串行违例 + 自举链验证面爆炸。
- **作为终态**：否——G8 已入账（§2 缺口表）+ W-LANG-FOUNDATION 已入序（§3 序 7 + §4.5 细粒度 MUV）：语言基础面完备是「语言自我推进」之后的第一个发展议程，不是可无限推迟的摆设。用户指令⑤「将 kerf 语言自身底层和基础内容完成纳入计划」的落位 = 本节 + §4.5。

### 9.3 脱糖示意（伪代码 ×1——登记态示意非冻结面语法承诺）

```text
# surface (target skin——今日已解析: parse_type_drop 消费后丢弃注解)
struct Point { x: int, y: int }
enum Shape { Circle(float), Rect(Point, Point) }

# elaboration (脱糖——零新原语; 表示层 = W-LANG-FOUNDATION 刀 2/刀 3 内裁定)
make_point  = (fn (x y) (pair x (pair y nil)))     # 构造子 = 函数
point_x     = (fn (p) (car p))                      # 字段访问 = 函数
make_circle = (fn (r) (pair 0 (pair r nil)))        # 变体 = 打标签的构造子
# 消费面: match 既有 (oracle expand_match 超集在位——TD-027 孪生臂为 T-a 前置门)
# 类型面: HM 推断 × 注解双向检查 (刀 1——标注-推断 unify 锚定)
```

> 原则 38/44-58 纪律声明：本节为**登记态**规划裁定——零机制变更义务、零新原语、零冻结面触碰；§9.3 伪代码为设计示意，表示层与 Type 构造子形态的实装裁定归属 W-LANG-FOUNDATION 各刀开窗时（§12 最优>最小 + §21.7 能力引入协议行权）。

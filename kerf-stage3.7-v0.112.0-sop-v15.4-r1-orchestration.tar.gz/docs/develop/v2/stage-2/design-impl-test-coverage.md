# Stage 2 设计-实现-测试覆盖（design-impl-test-coverage.md）

> **Status**: **终稿（2.8 Stage 2 末轮 L3 收口——r105 · v0.69.0）**；骨架史（2.6 评估窗开启轮落位——r90 · v0.60.0；r91 · v0.61.0 首刀供给行；r92 · v0.62.0 收口行——2.6 关闭：测试面 1405:0:0 + audit 274/274 + 语料 C 41/41 复跑全维持，评估轮零新测试面）；**终稿义务 = 2.8 Stage 2 末轮 L3 收口**（§14.6.6 七件套之二；防骨架不填义务表——沿 1.8 先例）
> **先例**：docs/develop/v1/stage-1/design-impl-test-coverage.md

## 1. 现状基线（截至 r90）

- **设计→实现映射**：§9.51.5 LA-1..LA-7（2.1 全交付）→ §9.83-§9.85 compiler 三 Pass + 收口（2.3）→ §9.86-§9.88 组成链 + B7（2.4）→ §9.89-§9.90 fixpoint + B8（2.5）→ §9.91 三裁决（2.6 开启）。
- **实现→测试映射**：1369:0:0（20 套件）+ audit 264/264（A-Z 二十四节）+ 语料 85 全路由（读层 8 / 展开层 19 / 编译层 58 漂移分类账钉扎）+ fixpoint_tests 11 件 + perf 守卫（B7/B8 fail-closed 钉扎）。
- **覆盖口径**：0 UNTESTED / ≤5% DEFERRED（§9.5 沿袭）；七类错误 7/7 负向覆盖。

## 2. 2.8 终稿义务表

| # | 义务 | 承载证据面 |
|---|------|-----------|
| 1 | 三列对照表全量（设计条目[stage0 §9.x / lang-design] ↔ 实现位点[crate/file] ↔ 测试锚[test/audit case]） | 2.1-2.7 全子阶段 |
| 2 | C 转译后端三列（发射器设计 ↔ 代码 ↔ e2e/audit AA 节） | **已交付（r91）**：§9.92 设计层 + kerf-cbackend 代码 + e2e 15 测试/audit AA10——三列对齐就位（2.8 终稿核对） |
| 3 | FFI 四规则三列（R-F1..R-F4 ↔ 实施面 ↔ 测试） | 2.8 评估窗 |
| 4 | 缺口申报（P2 遗留须 95% 同意——§9.5） | 终稿时点对账 |

## 3. 终稿三列对照总表（义务 1-3——2.1-2.8 全量 @ r105）

| 设计条目（stage0/lang-design） | 实现位点（crate/file） | 测试锚 | 状态 |
|-------------------------------|----------------------|--------|------|
| §9.51.5 LA-1..LA-7 词法寻址+捕获 | kerf-compiler captures + kerf-vm LoadCaptured + runtime Env.captured | capture_cost_guard_tests + 语料 85 + audit W 节 | ✅ 对齐 |
| §9.83-§9.85 compiler 三 Pass + CP 段 .krf 化 | selfhost/v1/compiler.ktf + compiler_parity.rs[r104 切 target 面] | CP8 守卫族 + audit | ✅ 对齐 |
| §9.86-§9.88 全组成链 + 漂移分类账 | composed_full_chain.rs[133 行退役后]→ composed_target_chain.rs（J1-J3） | composed_target_chain_tests 17 项 + tamper 三臂 | ✅ 对齐 |
| §9.89-§9.90 fixpoint + 门 B 升格 + 世代 | fixpoint.rs[350 行] + rebuild_bytecode + SemanticDigest | fixpoint_tests 11 件[四正七负] + gate_b 双口径 | ✅ 对齐 |
| §9.91 三裁决（构建编排/C 转译/FFI 预裁） | kerf-cbackend + kerf_rt.h + cc 门控 | 语料 C 41/41 + audit AA + B9c | ✅ 对齐 |
| §9.94-§9.99 切换窗六步 | kerf-reader target 模块 + skin_transcoder + parse_target 生产桥 | target_corpus_sweep 85 案 + 两皮肤 71/85 + 边界族 | ✅ 对齐 |
| R-F1..R-F4 FFI 四规则（§9.91 裁决三） | 边界模型层（kerf_rt.h 值模型/arena/句柄位）+ C ABI 面 | 语料 C 41/41（C ABI 边界实施实证）+ k_fmt_double 电池 | ✅ 模型+C ABI 面对齐；源级 extern = Stage 3+ 登记（B1 纳入下阶段计划——architecture-review §6 面三） |
| §9.100 2.8 末轮收口（本轮） | 恢复链 + 七件套终稿 + FFI 评估窗 | deep-review-round2.8.md + 六命令 1358:0:0 + audit 220/220 | ✅ 对齐 |

**缺口申报（义务 4）**：零 P2 遗留缺口——0 UNTESTED / ≤5% DEFERRED 维持（2 #[ignore] 重负载显式披露：语料 C 全量重放 + B 面测量）；B1 偏差唯一项（FFI 源级语法）已纳入 Stage 3+ 计划（非缺口——处理程度裁定）。

# Stage 2 架构设计审查（architecture-review.md）

> **Status**: **终稿（2.8 Stage 2 末轮 L3 收口——r105 · v0.69.0）**；骨架史：r90 · v0.60.0 落位 → r91 · v0.61.0 C 后端三层 → r92 · v0.62.0 2.6 收口行 → r105 终稿全量交付（第十次沙箱重置后：恢复链 Pack B d620a8bb + 1358:0:0 冷跑复现 + 本轮 D1-D8 承载）
> **流程权威**：docs/sop.md §14.6.6 / §14.7（跨阶段架构审查协议——C1-C6 维度）
> **先例**：docs/develop/v1/stage-1/architecture-review.md（Stage 1 终稿形态）

## 1. 现状基线（截至 r90——骨架层快照）

- **管道架构**：reader → expander → typecheck → compiler → verify → VM/runtime 双引擎（eval 镜像 + VM 执行），Cargo Workspace edition 2024，crate 谱系 = kerf-span/syntax/core/symbol/reader/expander/compiler/vm/runtime/driver/typecheck + 根 kerf。
- **自举架构**：selfhost/v1/ 五件平铺（lexer 473 / reader 117 / expander 750 / macro 660 / compiler 1257 行）——FLAT 五件制裁定（66-b：.krf 无模块系统，目录化零语义增益）；harness 单装配点（Rust 构建引导——r90 裁决一维持）。
- **fixpoint 架构**：三相位驱动器（C(S) 双引擎 + C(C(S)) VM-only 括号 + 重建产品 VM 执行）+ 门 B 升格（gate_b_elevated 全语料结构化字节码全等）——判据 (1)(2) 双兑现（r88/r89）。
- **链外后端架构（实施位——r91 三层落地）**：C 转译路线（r90 裁决二）已实施——`crates/kerf-cbackend`（发射器：静态编址操作数栈 + goto 控制流 + 单 trampoline + 位模式常量池）+ `kerf_rt.h`（内嵌宿主 shim：值模型/字节 arena/18 内建单源分派/最短往返浮点显示）+ cc 门控 e2e（跳过披露不失败；语料 C 全量重放 41/41 + audit AA 274/274）。crate 为 DAG 纯消费叶子——零自举链引用（宪制维持）。
- **宪制边界**：8 原语冻结（第六十三轮维持）、VM 永久 Rust 基座、LLVM/本地码后端永不入自举链。

## 2. 2.8 终稿义务表

| # | 义务 | 承载证据面 | 终态 |
|---|------|-----------|------|
| 1 | 每阶段（2.1-2.8）架构评分 + 建议（§14.6.6 表列） | 各子阶段 round-records + 本文档终稿评分表 | ✅ §3 |
| 2 | C1-C6 跨阶段维度清单核对（§14.7.1——阶段内路径/阶段间路径/高内聚低耦合/可插拔/数据流校验/路径缺漏） | driver.rs 交接点 + CompileResult 字段消费对账 | ✅ §4 |
| 3 | C 转译后端架构章（判据 (3) 工作位——发射器/shim/e2e 门控三层） | §1 现状基线 + round-records #9.92/#9.93 + 代码实态 | ✅ §5 |
| 4 | FFI 边界架构章（R-F1..R-F4 四规则的实施面映射——2.8 评估窗） | §9.91 裁决三 + FFI 实施位 | ✅ §6 |
| 5 | Stage 2 → Stage 3+ 架构移交清单（构建编排 .krf 化测量基线[B7/B8 公式]） | stage-2-plan §5 + roadmap | ✅ §7 |

## 3. 每阶段架构评分（义务 1——§14.6.6 表列，2.0-2.8 全量）

| 子阶段 | 架构面 | 评分 | 依据 |
|--------|--------|------|------|
| 2.0 规划轮（T31） | 规划域零代码——门四要件 + 排期单源落档 | ✅ 优秀 | stage-2-plan v1.0；确认位判定标准三件套 |
| 阶段间轮 T32-T53（十一域） | 身份基座链全管道闭合（单池 Symbol §9.52）+ 生产者-消费者对双侧清偿 + oracle 编码域 totality | ✅ 优秀 | §9.53-§9.76 谱系；B 轴域主账三笔（读轴 −21.4% / VM −13.0% / eval −34.3%）零行为变更 |
| 2.1-2.2 词法寻址/捕获（T58-T62） | 两源捕获描述符（K189 Lua 同构）+ 分离操作码族 + 帧捕获区独立 Vec | ✅ 优秀 | §9.80-§9.81；★1' O(captured) 双成本化解量化实证 |
| 2.3 fixpoint A（T60-T62） | CP 段全量 .krf 化 + 组成链 CP9 清偿（第六次自应用经全 .krf 链） | ✅ 优秀 | §9.83-§9.84；三重孪生驱动泛型化（第四前端零成本接入） |
| 2.4 fixpoint B（T64-T65） | JX-1 junction 重编码器（镜像 dump 推导单源）+ 漂移分类账 + 门 B 升格见证 | ✅ 优秀 | §9.86-§9.88；三段分级托管全组成链 |
| 2.5 fixpoint C（T66/T69） | fixpoint 三相位驱动器 + rebuild_bytecode + 世代补记 | ✅ 优秀 | §9.89-§9.90；C(C(S))==C(S) 逐字节 + B8 轴落地 |
| 2.6 Stage 2a（T68-T70） | C 转译三层（发射器 + kerf_rt.h shim + cc 门控）DAG 纯消费叶子 | ✅ 优秀 | §9.91-§9.93；宪制维持零自举链引用；语料 C 41/41 |
| 2.7 切换窗（T76-T81/T104） | ReaderFace 前端参数化单源骨架 + 目标面 fixpoint 双口径 + E5 批次 3 四动作移除 | ✅ 优秀 | §9.94-§9.99；组成链 J1-J3 零第二骨架；BS-A 种子链宪制保留 |
| 2.8 末轮 L3（r105） | 恢复链（Pack B sha256 校验）+ 七件套终稿 + FFI 评估窗裁决 | ✅ 优秀 | 本轮 deep-review-round2.8.md；ds08 锁步修复（恢复期发现 chore 侧 bump 未锁步——同类全量审查单一发生） |

**结论**：九子阶段全 ✅——无 ❌/⚠️ 项；阶段间无架构倒退；宪制边界（8 原语冻结第七十轮维持 / VM 永久 Rust 基座 / LLVM 永不入自举链）全程零违反。

## 4. C1-C6 跨阶段维度核对（义务 2——§14.7.1）

| 维度 | 核对结论 | 证据 |
|------|---------|------|
| C1 阶段内路径 | reader→expander→typecheck→compiler→verify→VM/runtime 各阶段内单模块承接，无跨阶段私有穿透 | driver 十二阶段专段（§9.60 谱系闭合）|
| C2 阶段间路径 | 交接点全部经 CompileResult/Session 显式载体；span 全携带（TD-004 边活性钉扎） | core_seed_tests 跨阶段消费 8 件 |
| C3 高内聚低耦合 | §18.5 DAG 严格（L0→L8 读序）；E5 批次 3 后生产链 = .ktf 唯一皮肤——driver 六模块拆除零第二骨架 | composed_target_chain.rs J1-J3 pub(crate) 复用 |
| C4 可插拔 | 前端两皮肤经 ReaderFace 参数化（read 步分叉单点）；链外后端 = DAG 纯消费叶子可整体移除 | parse_target 生产桥 |
| C5 数据流校验 | 每阶段输出经 verify 前置门 + parity 三路门（语义投影/行为等价/展开 α）+ gate B 双口径 | target_corpus_sweep 85 案 |
| C6 路径缺漏 | 七类错误全覆盖 ≥6 类负向（GATE 6）；audit 220/220 live + 104 retired 历史化 | stage0_gate_audit_r1 |

## 5. C 转译后端架构章（义务 3——判据 (3) 终核）

三层终态（r91 实施 + r92 终核 + r105 复验维持）：①发射器（kerf-cbackend/emit.rs——bytecode→C：静态编址 st[] 操作数栈 + goto 控制流 + k_call 单 trampoline + KConst 位模式常量池{浮点 u64 位模式 + 字符串字节数组 + pair 后序 KLit 树} + verify 前置门）；②宿主 shim（kerf_rt.h——C11+POSIX 单翻译单元内嵌：值模型 16B KValue + 字节 arena + 18 内建单源分派 + k_fmt_double 最短往返浮点）；③cc 门控 e2e（缺席环境跳过披露不失败；语料 C 全量重放 41/41 + audit AA 274/274[AA 节部分块 r104 历史化后由继承矩阵承载] + B9c C-vs-VM 3.2×/6.4×）。**宪制重申：C 转译后端永不入自举链（编译器构建永不依赖 cc）——crate 为 DAG 纯消费叶子。**

## 6. FFI 边界架构章（义务 4——判据 (4) 评估窗裁决 @ r105）

**裁决：判据 (4)「FFI 可用」= 三面口径终核通过——kerf 源级 extern 语法 = Stage 3+ 窗口承载（登记非开放 TD）。**

- **面一（所有权模型——R-F1..R-F4）**：✅ 已定义（r90 §9.91 裁决三预裁解阻）——R-F1 边界即时物化（零惰性穿越零跨界堆引用）/ R-F2 调用方所有 + 返回值转移（GC 根即时接管）/ R-F3 跨调用持有 = 显式句柄根（JNI global ref 同构）/ R-F4 C ABI 对齐（零名称修饰、禁按值结构体——与 C 转译后端共享边界模型）。
- **面二（二进制可用性——C ABI 边界实施实证）**：✅ 已工作（r91-r92 + r105 复验）——kerf→C 转译产物与 kerf_rt.h 宿主 shim 在链接期可互操作：语料 C 全量重放 41/41（kerf 程序经 C 二进制执行并对账）+ 18 内建 C 可调面 + B9c 带内。FFI 的 C ABI 面（判据 (3)(4) 共享边界）可用。
- **面三（源级语法——kerf 源内 extern 声明）**：⏸ Stage 3+ 窗口承载——三依据：§21.7 处理程度分级 FFI 原列 P4（完全推迟——不设计不预留）；8 原语内核冻结「零语法」宪制（当前设计纪元内新增 extern 语法 = 宪制违反）；语言级 FFI 语义需宏系统/类型系统配合（TD-007 宏窗口同段位——Stage 2+ 宏系统窗口开窗评估为共同前置）。登记：roadmap §2 Stage 3+ 行 + 本表（非 tech-debt 开放项——能力引入计划项）。

## 7. Stage 2 → Stage 3+ 架构移交清单（义务 5）

| 移交项 | 内容 | 接收面 |
|--------|------|--------|
| 构建编排测量基线 | B7×文件数（22.090ms/件级 3163×）+ B8×阶段数（3614.539ms 不动点整跑）公式与当前值 | Stage 3+ 判据 (2)「构建系统可用 kerf 重写」开窗时基线 |
| QBE 后端候选 | r90 裁决二转登记（lang-design/08 §4 对照维持；链外可选并存） | Stage 3+ 后端扩展评估 |
| FFI 源级语法 | §6 面三登记（与宏系统窗口同段位） | Stage 3+ 能力引入 |
| 演进矩阵 Stage 3 行 | LLVM 链外/JIT/分代 GC/IDE/包管理（roadmap §2） | Stage 3+ 规划轮 |
| TD-007 | 宏声明目标皮肤面（Open/P3 登记态——下一消费信号 = Stage 2+ 宏系统窗口） | Stage 2+ 宏窗口开窗评估 |
| 九信号 Stage 2 口径 | 9✓/9（本轮 §14.6 四项全过——见 final-assessment.md） | Stage 3 开阶段前置 |

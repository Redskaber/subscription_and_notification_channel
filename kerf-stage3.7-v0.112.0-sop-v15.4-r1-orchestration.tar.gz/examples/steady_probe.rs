//! Steady target reader probe (W-TGT-READ-TWIN blade 3 — the
//! steady-chain diagnostic face; the tp_probe lineage: a case by
//! name or a raw source, the three routes side by side — never
//! part of the parity comparison).
use kerf_driver::{
    SteadyTargetReaderChain, TARGET_PARSER_TWIN_CASES, target_lexer_twin_dump,
    target_oracle_token_dump, target_parser_oracle_dump, target_parser_twin_dump,
};

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    if args.is_empty() {
        eprintln!("usage: steady_probe <case-name> | --raw <source>");
        return;
    }
    if args[0] == "--raw" && args.len() > 1 {
        run("raw", &args[1]);
        return;
    }
    let name = &args[0];
    let case = TARGET_PARSER_TWIN_CASES
        .iter()
        .find(|(n, _)| n == name)
        .unwrap_or_else(|| panic!("unknown case {name}"));
    run(name, case.1);
}

fn run(name: &str, source: &str) {
    // The deep-stack discipline (the selfhost fixed-point lineage: the
    // harness decode walks are recursive over deep trees — the
    // demand-allocated stack of the sibling tests).
    let name = name.to_string();
    let source = source.to_string();
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(move || run_inner(&name, &source))
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly");
}

fn run_inner(name: &str, source: &str) {
    println!("=== case [{name}] source: {source:?}");
    let chain = match SteadyTargetReaderChain::new() {
        Ok(c) => c,
        Err(err) => {
            println!("--- chain construction FAILED: {err}");
            return;
        }
    };
    match chain.read_dual(source) {
        Ok((vm, eval)) => {
            println!("--- steady vm  token: {}", vm.token_dump);
            println!("--- steady vm  tree : {}", vm.tree_dump);
            println!("--- steady eval token: {}", eval.token_dump);
            println!("--- steady eval tree : {}", eval.tree_dump);
            println!(
                "--- engines agree: token {} / tree {}",
                vm.token_dump == eval.token_dump,
                vm.tree_dump == eval.tree_dump
            );
            println!("--- forms rebuilt: {}", vm.forms.is_some());
        }
        Err(err) => println!("--- steady read FAILED: {err}"),
    }
    let oracle_tree = match target_parser_oracle_dump(source) {
        Ok(dump) => dump,
        Err(err) => format!("ERR {}", kerf_driver::error_parity_key(&err)),
    };
    println!("--- oracle tree: {oracle_tree}");
    let oracle_tokens = match target_oracle_token_dump(source) {
        Ok(dump) => dump,
        Err(err) => format!("ERR {}", kerf_driver::error_parity_key(&err)),
    };
    println!("--- oracle tokens: {oracle_tokens}");
    match target_parser_twin_dump(source) {
        Ok((vm_dump, eval_dump)) => {
            println!("--- per-source vm  : {vm_dump}");
            println!("--- per-source eval: {eval_dump}");
        }
        Err(err) => println!("--- per-source FAILED: {err}"),
    }
    match target_lexer_twin_dump(source) {
        Ok((vm_dump, eval_dump)) => {
            println!("--- per-source lexer vm  : {vm_dump}");
            println!("--- per-source lexer eval: {eval_dump}");
        }
        Err(err) => println!("--- per-source lexer FAILED: {err}"),
    }
}

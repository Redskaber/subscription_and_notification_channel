//! Expand segment profile (T-a step-④ — w-t-a-switch-window §3, the
//! §14.6.4 rule 5 MEASUREMENT-FIRST face): the EXPAND segment's
//! production-position switch cost portrait, measured BEFORE the
//! switch lands as the shipped default and recorded per the
//! three-run discipline (tool-results/r146-expand-segment-run{1,2,3}.
//! txt).
//!
//! Run: `cargo run --release --example expand_segment_profile`.
//!
//! Three measurements:
//!
//! 1. **Chain construction** (once per process): compiling the
//!    expander twin through the seed face — the steady-state
//!    amortization's fixed cost.
//! 2. **Per-expansion medians** on representative workloads (a
//!    small curated case, the match composite, and the expander
//!    twin's own 60 KB source — the deepest fixed-point shape): the
//!    twin chain's VM expansion vs the Rust oracle expansion, back
//!    to back.
//! 3. **The whole-spine delta**: one full parse (read + expand +
//!    load) through each position — the user-visible face of the
//!    K140 band at the expand-segment slice (both segments at their
//!    switched defaults vs both pinned Rust).
//!
//! The band's honest shape (expected, per K140's Go 1.5 precedent):
//! the twin position pays the chain construction once and a
//! per-expansion interpretation cost; the rollback band
//! (`KERF_EXPAND_SEGMENT=rust`) restores the Rust expander for any
//! process that needs it. The numbers land in the window doc §5
//! (the K140 segment-slice disclosure).

use std::time::Instant;

use kerf::driver::{
    CheckSegment, CompileSegment, ExpandSegment, ReadSegment, Session, parse_target,
    production_expand,
};
use kerf::expander::{EXPANSION_LIMIT, expand_program_with_limit, load_program};
use kerf::reader::read_target_program;
use kerf::span::FileId;

/// One workload: a display name and its `.ktf` source.
struct Workload<'a> {
    name: &'static str,
    source: &'a str,
}

fn main() {
    println!("=== expand segment profile (T-a step-4, rule-5 measurement-first) ===");

    // ---- measurement 1: the chain construction (the fixed cost) ----
    let t = Instant::now();
    let chain = kerf::driver::SteadyExpanderChain::new()
        .unwrap_or_else(|e| panic!("the chain must construct: {e}"));
    let chain_ms = t.elapsed().as_secs_f64() * 1000.0;
    println!("chain construction (once per process): {chain_ms:.1} ms");

    // ---- measurement 2: the per-expansion medians ----
    // The deep workload is the expander twin in its CCF form (the
    // extern `forms` slot declaration + the ex_limit prefix + the
    // macro library + the expander body — the TA-1 chain-compilable
    // form): the raw body alone is NOT self-contained (its `forms`
    // entry reference and its `ex_is_name_member` call sites bind
    // against the slot declaration and the macro library — the raw
    // body rejects as unbound on BOTH positions, which measures a
    // rejection path, not the deep expansion cost).
    let ccf_expander = kerf::driver::ccf_expander_source();
    let workloads = [
        Workload {
            name: "curated-small",
            source: "fn add(a, b) { a + b }\nfn main() { add(1, 2) }\n",
        },
        Workload {
            name: "match-composite",
            source: "fn pick(p) { match p { 1 => { 10 }, _ => { 20 }, } }\nfn main() { pick(1) }\n",
        },
        Workload {
            name: "expander-twin-60kb",
            source: ccf_expander.as_str(),
        },
    ];
    println!("\nworkload                     rust-expand twin-expand ratio");
    for workload in &workloads {
        let forms = read_target_program(FileId(0), workload.source)
            .unwrap_or_else(|e| panic!("the workload must read: {e:?}"));
        // The warm-up: both faces once (page faults, first-run lazies).
        let _ = expand_program_with_limit(&forms, EXPANSION_LIMIT);
        let _ = chain.expand_production(&forms);
        // The Rust arm: 9 samples, median.
        let mut rust_samples = Vec::new();
        for _ in 0..9 {
            let t = Instant::now();
            let items = expand_program_with_limit(&forms, EXPANSION_LIMIT).expect("expand");
            load_program(&items).expect("load");
            rust_samples.push(t.elapsed().as_secs_f64() * 1000.0);
        }
        rust_samples.sort_by(|a, b| a.partial_cmp(b).unwrap());
        let rust_ms = rust_samples[rust_samples.len() / 2];
        // The twin arm: 9 samples, median (the twin's verdict covers
        // the expansion AND the loader — the junction-2 discipline).
        let mut twin_samples = Vec::new();
        for _ in 0..9 {
            let t = Instant::now();
            let _ = chain.expand_production(&forms).expect("the twin expansion");
            twin_samples.push(t.elapsed().as_secs_f64() * 1000.0);
        }
        twin_samples.sort_by(|a, b| a.partial_cmp(b).unwrap());
        let twin_ms = twin_samples[twin_samples.len() / 2];
        let ratio = twin_ms / rust_ms.max(f64::EPSILON);
        println!(
            "{:<28} {:>8.3} ms {:>8.3} ms {:>7.1}x",
            workload.name, rust_ms, twin_ms, ratio
        );
    }

    // ---- measurement 3: the whole-spine delta (read + expand + load) ----
    // The big spine workload rides macro.ktf — the one SELF-CONTAINED
    // twin (the assembled expander program is a chain piece: its
    // `forms` slot needs the injection face, outside the ordinary
    // closed-program spine).
    let spine_workloads = [
        Workload {
            name: "curated-small",
            source: "fn add(a, b) { a + b }\nfn main() { add(1, 2) }\n",
        },
        Workload {
            name: "match-composite",
            source: "fn pick(p) { match p { 1 => { 10 }, _ => { 20 }, } }\nfn main() { pick(1) }\n",
        },
        Workload {
            name: "macro-twin-20kb",
            source: kerf::driver::MACRO_TARGET_SOURCE,
        },
    ];
    let spine = |segments: (ReadSegment, ExpandSegment, CheckSegment, CompileSegment),
                 source: &str|
     -> f64 {
        let t = Instant::now();
        let mut session = Session::with_segments(segments.0, segments.1, segments.2, segments.3);
        let program =
            parse_target(&mut session, "spine.ktf", source).expect("the spine must parse");
        let elapsed = t.elapsed().as_secs_f64() * 1000.0;
        assert!(!program.items.is_empty(), "the spine must produce items");
        elapsed
    };
    let rust_position = (
        ReadSegment::Rust,
        ExpandSegment::Rust,
        // The check AND compile segments stay Rust on BOTH spine
        // positions here: this profile isolates the EXPAND slice
        // (the r147/r148 profiles own their own segments' slices).
        CheckSegment::Rust,
        CompileSegment::Rust,
    );
    let twin_position = (
        ReadSegment::Twin,
        ExpandSegment::Twin,
        CheckSegment::Rust,
        CompileSegment::Rust,
    );
    // Warm both spines (the twin spine constructs its chains here —
    // the thread-local caches' first hits).
    let _ = spine(twin_position, spine_workloads[0].source);
    let _ = spine(rust_position, spine_workloads[0].source);
    println!("\nwhole spine (read + expand + load), median of 9:");
    for workload in &spine_workloads {
        let mut rust_samples = Vec::new();
        for _ in 0..9 {
            rust_samples.push(spine(rust_position, workload.source));
        }
        rust_samples.sort_by(|a, b| a.partial_cmp(b).unwrap());
        let rust_ms = rust_samples[rust_samples.len() / 2];
        let mut twin_samples = Vec::new();
        for _ in 0..9 {
            twin_samples.push(spine(twin_position, workload.source));
        }
        twin_samples.sort_by(|a, b| a.partial_cmp(b).unwrap());
        let twin_ms = twin_samples[twin_samples.len() / 2];
        let ratio = twin_ms / rust_ms.max(f64::EPSILON);
        println!(
            "{:<28} {:>8.3} ms {:>8.3} ms {:>7.1}x",
            workload.name, rust_ms, twin_ms, ratio
        );
    }

    // ---- the honest band disclosure ----
    //
    // The single-file CLI process pays: chain construction once +
    // the twin expansion (the K140 segment slice). The numbers above
    // are the segment's own portrait; the full-chain band (K140
    // ~10x) is the window-level acceptance, disclosed in the window
    // doc.
    println!(
        "\nband note: a single-file process pays chain ({chain_ms:.1} ms) + the twin expansions; \
         the rollback band is `KERF_EXPAND_SEGMENT=rust` (fail-closed on any other value)."
    );

    // The budget-mirror spot check: the with_limit face stays honest
    // under a tight budget (the rollback band's parity obligation —
    // the `ex_limit` prefix mirrors the process budget).
    let mut deep = String::from("define(result, ");
    for _ in 0..30 {
        deep.push_str("if (true) { ");
    }
    deep.push('1');
    for _ in 0..30 {
        deep.push_str(" } else { 0 }");
    }
    deep.push_str(");");
    let forms = read_target_program(FileId(0), &deep).expect("the nest must read");
    assert!(
        production_expand(&forms, 8, FileId(0)).is_err()
            && expand_program_with_limit(&forms, 8).is_err(),
        "the tight budget must reject on both positions"
    );
    println!("budget check: 30-deep nest rejects under the 8 budget on both positions.");
}

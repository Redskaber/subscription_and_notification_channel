//! Compile segment profile (T-a step-④ — w-t-a-switch-window §3, the
//! §14.6.4 rule 5 MEASUREMENT-FIRST face): the COMPILE segment's
//! production-position switch cost portrait, measured BEFORE the
//! switch lands as the shipped default and recorded per the
//! three-run discipline (tool-results/r148-compile-segment-run{1,2,3}.
//! txt).
//!
//! Run: `cargo run --release --example compile_segment_profile`.
//!
//! Three measurements:
//!
//! 1. **Chain construction** (once per process): compiling the
//!    compiler twin (`compiler.ktf` behind the `items` slot
//!    declaration and the `co_limit` budget define) through the seed
//!    face — the steady-state amortization's fixed cost.
//! 2. **Per-compile medians** on representative workloads (a small
//!    curated case, the match composite, and the compiler twin's own
//!    CCF — the deepest fixed-point shape the compile segment owns):
//!    the twin chain's VM compilation (the production entry) vs the
//!    Rust oracle compilation, back to back.
//! 3. **The whole-spine delta**: one full parse + compile through
//!    each position — the user-visible face of the K140 band at the
//!    compile-segment slice (read+expand at their switched defaults
//!    and check pinned Rust on both sides; the compile segment alone
//!    flips — the r147 profile owns the check slice).
//!
//! The band's honest shape (expected, per K140's Go 1.5 precedent):
//! the twin position pays the chain construction once and a
//! per-compile interpretation cost; the rollback band
//! (`KERF_COMPILE_SEGMENT=rust`) restores the Rust compiler for any
//! process that needs it. The numbers land in the window doc §5 (the
//! K140 segment-slice disclosure).

use std::time::Instant;

use kerf::compiler::COMPILE_DEPTH_LIMIT;
use kerf::driver::{
    CheckSegment, CompileSegment, ExpandSegment, ReadSegment, Session, parse_target,
};

/// One workload: a display name and its `.ktf` source.
struct Workload<'a> {
    name: &'static str,
    source: &'a str,
}

/// The Rust oracle's compile of one parsed program (the comparison
/// arm): the plain production compile through the pinned session.
fn oracle_compile(source: &str) -> f64 {
    let t = Instant::now();
    let mut session = Session::new();
    session.set_compile_segment(CompileSegment::Rust);
    let program = parse_target(&mut session, "bench.ktf", source).expect("the workload must parse");
    let _ = program
        .compile_bytecode()
        .expect("the workload must compile");
    t.elapsed().as_secs_f64() * 1000.0
}

/// The twin position's compile of one parsed program (the production
/// arm): the default session (the compile segment's switched
/// position; the read/expand segments ride their switched defaults on
/// both arms — this profile isolates the compile slice).
fn twin_compile(source: &str) -> f64 {
    let t = Instant::now();
    let mut session = Session::new();
    let program = parse_target(&mut session, "bench.ktf", source).expect("the workload must parse");
    let _ = program
        .compile_bytecode()
        .expect("the workload must compile");
    t.elapsed().as_secs_f64() * 1000.0
}

fn median(samples: &mut [f64]) -> f64 {
    samples.sort_by(|a, b| a.partial_cmp(b).expect("finite samples"));
    samples[samples.len() / 2]
}

fn main() {
    println!("=== compile segment profile (T-a step-4, rule-5 measurement-first) ===");

    // ---- measurement 1: the chain construction (the fixed cost) ----
    // The production entry constructs the chain lazily on the first
    // compile; the fixed cost is measured through the public
    // constructor (the same compilation the production cache rides).
    let t = Instant::now();
    let _chain = kerf::driver::SteadyCompilerChain::new_with_limit(COMPILE_DEPTH_LIMIT)
        .unwrap_or_else(|e| panic!("the compiler chain must construct: {e}"));
    let chain_ms = t.elapsed().as_secs_f64() * 1000.0;
    println!("compiler chain construction (compiler.ktf, once per process): {chain_ms:.1} ms");

    // ---- measurement 2: the per-compile medians ----
    // The deep workload is the compiler twin in its CCF form (the
    // extern `items` slot declaration and the `co_limit` define ahead
    // of the twin — the TA-1 chain-compilable form): the compiler
    // compiling its own family's fixed point.
    let compiler_ccf = kerf::driver::ccf_compiler_source();
    let workloads = [
        Workload {
            name: "curated-small",
            source: "fn add(a, b) { a + b }\nfn main() { add(1, 2) }\n",
        },
        Workload {
            name: "match-composite",
            source: "fn pick(p) { match p { 1 => { 10 }, _ => { 20 }, } }\nfn main() { pick(1) }\n",
        },
        Workload {
            name: "compiler-twin-ccf",
            source: compiler_ccf.as_str(),
        },
    ];
    println!("\nworkload                   rust-compile twin-compile   ratio");
    for workload in &workloads {
        // Warm both positions (the twin position constructs its chain
        // through the thread-local cache on the first hit — the
        // per-compile medians measure the steady state).
        let _ = twin_compile(workload.source);
        let _ = oracle_compile(workload.source);
        let mut rust_samples = Vec::new();
        let mut twin_samples = Vec::new();
        for _ in 0..5 {
            rust_samples.push(oracle_compile(workload.source));
            twin_samples.push(twin_compile(workload.source));
        }
        let rust = median(&mut rust_samples);
        let twin = median(&mut twin_samples);
        println!(
            "{:<26} {:>9.2}ms {:>9.2}ms {:>7.1}x",
            workload.name,
            rust,
            twin,
            twin / rust
        );
    }

    // ---- measurement 3: the whole-spine delta (read + expand + compile) ----
    // The big spine workload rides the macro twin — the one
    // SELF-CONTAINED twin (the assembled checker/compiler programs
    // are chain pieces: their `items` slot needs the injection face,
    // outside the ordinary closed-program spine). The check segment
    // stays Rust on BOTH spine positions (the r147 profile owns the
    // check slice; this one isolates compile).
    let spine_workloads = [
        Workload {
            name: "curated-small",
            source: "fn add(a, b) { a + b }\nfn main() { add(1, 2) }\n",
        },
        Workload {
            name: "match-composite",
            source: "fn pick(p) { match p { 1 => { 10 }, _ => { 20 }, } }\nfn main() { pick(1) }\n",
        },
        Workload {
            name: "macro-twin-20kb",
            source: kerf::driver::MACRO_TARGET_SOURCE,
        },
    ];
    let spine = |compile: CompileSegment, source: &str| -> f64 {
        let t = Instant::now();
        let mut session = Session::with_segments(
            ReadSegment::Twin,
            ExpandSegment::Twin,
            CheckSegment::Rust,
            compile,
        );
        let program =
            parse_target(&mut session, "spine.ktf", source).expect("the spine must parse");
        let _ = program.compile_bytecode().expect("the spine must compile");
        t.elapsed().as_secs_f64() * 1000.0
    };
    // Warm both spines (the twin spine constructs its chains here —
    // the thread-local caches' first hits).
    let _ = spine(CompileSegment::Twin, spine_workloads[0].source);
    let _ = spine(CompileSegment::Rust, spine_workloads[0].source);
    println!("\nwhole spine (read + expand + compile), median of 9:");
    for workload in &spine_workloads {
        let mut rust_samples = Vec::new();
        let mut twin_samples = Vec::new();
        for _ in 0..9 {
            rust_samples.push(spine(CompileSegment::Rust, workload.source));
            twin_samples.push(spine(CompileSegment::Twin, workload.source));
        }
        let rust = median(&mut rust_samples);
        let twin = median(&mut twin_samples);
        println!(
            "{:<26} rust {:>8.2}ms  twin {:>8.2}ms  {:>7.1}x",
            workload.name,
            rust,
            twin,
            twin / rust
        );
    }
}

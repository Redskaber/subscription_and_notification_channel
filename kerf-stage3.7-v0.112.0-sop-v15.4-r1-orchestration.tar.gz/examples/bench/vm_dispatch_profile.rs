//! VM dispatch profile (Stage 3 W-3.7 JIT/superinstruction evaluation
//! window, MUV 3.7-a) — the dispatch-hotspot measurement face.
//!
//! Purpose: measure whether kerf's VM workloads are dispatch-bound
//! BEFORE any tier-1 design is adjudicated (stage-3-plan §2.3 W-3.7
//! exit condition ①: "VM dispatch-bound vs application-bound" — and
//! the EXC-10 trigger: "profile shows dispatch in the top-three
//! hotspots"). This example IS that portrait.
//!
//! Method (w3.7-jit-window.md §2a/§2b): census exactness by
//! construction — the real interpreter loop reports every executed
//! instruction through the W-3.7 observer seam
//! (`Vm::run_observed`), so the per-opcode histogram, the
//! per-function counts, and the dynamic adjacent-pair table are
//! counts of the production dispatch, not a harness-side
//! re-interpretation (no twin to drift; the r119 profiling-collector
//! pattern generalized to the dispatch path). The observer is a run
//! parameter the harness owns directly — the census state needs no
//! interior-mutability hand-back. Timing faces run plain `run()`:
//! the census runs never measure time, the timed runs never observe.
//!
//! Three measurements per workload:
//! 1. Timed run (plain `run`): the B-axis style median wall time —
//!    `ns_per_instr = median / census_total` is the per-dispatch
//!    cost the tier-1 design must beat.
//! 2. Census run (`run_observed`): per-opcode / per-function /
//!    adjacent-pair histograms. A pair is recorded when two
//!    instructions execute back-to-back at consecutive pcs in the
//!    same function — the superinstruction fusion precondition — and
//!    is FUSABLE when the second pc is not a static jump target
//!    (fusion must not break an entering edge).
//! 3. The B9c cross-check (fib-25 only): the same algorithm as a C
//!    binary at -O0 does the identical call structure, so the
//!    VM-vs-C gap is the interpreter-overhead share — the
//!    application-bound work is what the C binary spends, the rest
//!    is fetch + decode + dispatch + bounds checks + frame traffic.
//!
//! Workloads (the B-axis representative set, the gc_lifetime_profile
//! allocation picks mirrored): fib(25) — arithmetic recursion, the
//! B2 axis; iota(50) — corpus bnd-009, list construction; map-double
//! — corpus pos-020, list traversal + construction; churn(2000) —
//! the B4 axis shape, allocation churn.
//!
//! Output lines are the paste source for
//! `docs/develop/v3/w3.7-jit-window.md` §2 (the dispatch portrait).
//!
//! Blade 2 (r142) adds the tier-contrast arm: every workload's
//! timed face runs TWICE — the default production configuration
//! (tier at its shipped default) and the pure-interpretation arm
//! (`with_method_tier_threshold(u32::MAX)`, the tier machinery
//! structurally idle). The on/off ratio per workload is the
//! w-jit-method-t1-window §8 blade-2 adjudication input: whether
//! the tier-1 closure chain beats the 27-arm match interpreter on
//! wall time is a measurement, not an assumption (the MJ-1 honest
//! note — `Rc<dyn Fn>` indirect calls price at the same order as
//! the match jump table; the K129 discipline refuses to predict).
//!
//! Run: `cargo run --release --example vm_dispatch_profile`.

use std::collections::HashMap;
use std::hint::black_box;
use std::time::Instant;

use kerf::compiler::{Bytecode, Opcode};
use kerf::expander::expand_program;
use kerf::reader::read_target_program;
use kerf::span::FileId;
use kerf::vm::{Vm, VmObserver};

/// The tier-off arm's threshold: `u32::MAX` can never be reached by
/// a saturating count, so the tier machinery stays structurally
/// idle (the pure-interpretation production baseline arm).
const TIER_OFF: u32 = u32::MAX;

/// The census state (owned by the observer; the harness reads it
/// directly after the run — the parameter-passing seam's ownership).
#[derive(Default)]
struct CensusState {
    /// Per-opcode dynamic execution counts (index = `Opcode::ordinal()`).
    opcode_counts: Vec<u64>,
    /// Per-function dynamic instruction counts (index = func).
    func_counts: Vec<u64>,
    /// Dynamic adjacent-pair histogram keyed by opcode ordinals
    /// `(first, second)` — count of back-to-back dynamic executions.
    pairs: HashMap<(usize, usize), u64>,
    /// The fusable sub-histogram: same key, restricted to occurrences
    /// whose second pc is not a static jump target.
    fusable_pairs: HashMap<(usize, usize), u64>,
    /// The previous observation: `(func, pc, op ordinal)`.
    last: Option<(usize, usize, usize)>,
    /// Total observed instructions.
    total: u64,
}

impl CensusState {
    /// Total dynamically fused-eliminable dispatches: every fusable
    /// pair occurrence is one dispatch a fused opcode removes.
    fn fusable_total(&self) -> u64 {
        self.fusable_pairs.values().sum()
    }
}

/// The census observer: owns the census state outright, classifying
/// pair fusability against the precomputed jump-target bitmap
/// (fusion validity is a static fact of the bytecode, consulted at
/// observe time).
struct CensusObserver {
    state: CensusState,
    jump_targets: Vec<Vec<bool>>,
}

impl VmObserver for CensusObserver {
    fn observe(&mut self, op: Opcode, func: usize, pc: usize) {
        let ord = op.ordinal();
        let state = &mut self.state;
        if state.opcode_counts.len() <= ord {
            state.opcode_counts.resize(ord + 1, 0);
        }
        state.opcode_counts[ord] += 1;
        if state.func_counts.len() <= func {
            state.func_counts.resize(func + 1, 0);
        }
        state.func_counts[func] += 1;
        if let Some((last_func, last_pc, last_ord)) = state.last {
            if last_func == func && last_pc + 1 == pc {
                *state.pairs.entry((last_ord, ord)).or_insert(0) += 1;
                // Fusion validity: replacing the static pair with one
                // fused instruction breaks any edge entering the
                // second pc — a jump target cannot be a pair's tail.
                let target = self
                    .jump_targets
                    .get(func)
                    .map(|t| t.get(pc).copied().unwrap_or(false))
                    .unwrap_or(false);
                if !target {
                    *state.fusable_pairs.entry((last_ord, ord)).or_insert(0) += 1;
                }
            }
        }
        state.last = Some((func, pc, ord));
        state.total += 1;
    }
}

/// Compile a target-skin source to bytecode (the B-axis harness
/// shape — the r151 single-skin note: the read is the target reader).
fn bc(src: &str) -> Bytecode {
    let forms = read_target_program(FileId(0), src).expect("read");
    let items = expand_program(&forms).expect("expand");
    kerf::compiler::compile_program(&items).expect("compile")
}

/// Static jump-target bitmap per function: every `a` operand of a
/// jump / jump-if-false (the only intra-function edges; call entry
/// is pc 0 and a pair never ends at a function's first instruction).
fn jump_targets(bc: &Bytecode) -> Vec<Vec<bool>> {
    bc.funcs
        .iter()
        .map(|proto| {
            let mut targets = vec![false; proto.code.len()];
            for instr in &proto.code {
                if matches!(instr.op, Opcode::Jump | Opcode::JumpIfFalse) {
                    let target = instr.a as usize;
                    if target < targets.len() {
                        targets[target] = true;
                    }
                }
            }
            targets
        })
        .collect()
}

/// One workload's full measurement: timed median (plain `run`), then
/// census (`run_observed`), with the parity assertion between them —
/// the seam is inert iff both runs produce the identical `result`
/// global.
struct WorkloadLine {
    label: &'static str,
    value: String,
    median_ms: f64,
    /// The pure-interpretation arm's median (tier off) — the
    /// r134/r135 comparable number and the blade-2 contrast face.
    median_ms_tier_off: f64,
    /// Whether the default-tier run compiled any function (the
    /// tier-arm sanity probe: on fib-25 the hot function must be
    /// compiled, or the "on" arm silently measured the same path).
    tier_compiled_any: bool,
    census: CensusState,
    /// Function names by proto index (the hot-function table's face).
    func_names: Vec<String>,
}

fn measure(label: &'static str, src: &str, iters: usize, expected: &str) -> WorkloadLine {
    let bytecode = bc(src);

    // Timed face A: plain run (the production configuration — the
    // tier at its shipped default).
    let warmup = if iters < 10 { 1 } else { 3 };
    for _ in 0..warmup {
        let mut vm = Vm::new(black_box(bytecode.clone())).expect("vm");
        vm.run().expect("workload halts");
    }
    let mut samples = Vec::with_capacity(iters);
    let mut tier_compiled_any = false;
    let n_funcs = bytecode.funcs.len();
    for _ in 0..iters {
        let mut vm = Vm::new(black_box(bytecode.clone())).expect("vm");
        let t = Instant::now();
        vm.run().expect("workload halts");
        samples.push(t.elapsed().as_secs_f64() * 1e3);
        tier_compiled_any =
            tier_compiled_any || (0..n_funcs).any(|f| vm.method_tier().is_compiled(f));
    }
    samples.sort_by(|a, b| a.partial_cmp(b).expect("finite samples"));
    let median_ms = samples[samples.len() / 2];
    let mut vm = Vm::new(bytecode.clone()).expect("vm");
    vm.run().expect("workload halts");
    let value = vm
        .global("result")
        .map(|v| v.to_string())
        .expect("result global bound");
    assert_eq!(value, expected, "{label}: timed-face value");

    // Timed face B (blade 2): the pure-interpretation arm — the
    // tier census threshold pinned at `u32::MAX` so no function
    // ever crosses, every dispatch through the interpreter's match
    // (the r134/r135 comparable number).
    let mut vm_probe = Vm::with_method_tier_threshold(bytecode.clone(), TIER_OFF).expect("vm");
    vm_probe.run().expect("workload halts");
    assert_eq!(
        vm_probe.global("result").map(|v| v.to_string()),
        Some(value.clone()),
        "{label}: tier-off arm value parity"
    );
    for _ in 0..warmup {
        let mut vm =
            Vm::with_method_tier_threshold(black_box(bytecode.clone()), TIER_OFF).expect("vm");
        vm.run().expect("workload halts");
    }
    let mut samples_off = Vec::with_capacity(iters);
    for _ in 0..iters {
        let mut vm =
            Vm::with_method_tier_threshold(black_box(bytecode.clone()), TIER_OFF).expect("vm");
        let t = Instant::now();
        vm.run().expect("workload halts");
        samples_off.push(t.elapsed().as_secs_f64() * 1e3);
    }
    samples_off.sort_by(|a, b| a.partial_cmp(b).expect("finite samples"));
    let median_ms_tier_off = samples_off[samples_off.len() / 2];

    // Census face: the observer seam (measurement only, never timed).
    let func_names = bytecode
        .funcs
        .iter()
        .map(|p| {
            p.name
                .as_ref()
                .map(|s| s.as_str().to_owned())
                .unwrap_or_else(|| "<entry>".to_owned())
        })
        .collect::<Vec<_>>();
    let mut observer = CensusObserver {
        state: CensusState::default(),
        jump_targets: jump_targets(&bytecode),
    };
    let mut vm = Vm::new(bytecode).expect("vm");
    vm.run_observed(&mut observer)
        .expect("workload halts under observation");
    assert_eq!(
        vm.global("result").map(|v| v.to_string()),
        Some(value.clone()),
        "{label}: census-face parity (the seam must be inert)"
    );

    WorkloadLine {
        label,
        value,
        median_ms,
        median_ms_tier_off,
        tier_compiled_any,
        census: observer.state,
        func_names,
    }
}

impl WorkloadLine {
    fn print(&self) {
        let census = &self.census;
        let per_instr_ns = self.median_ms * 1e6 / census.total as f64;
        let per_instr_ns_off = self.median_ms_tier_off * 1e6 / census.total as f64;
        let ratio = self.median_ms / self.median_ms_tier_off;
        println!(
            "WORKLOAD {label}: value={value} parity=OK tier-on={:.3}ms tier-off={:.3}ms ratio(on/off)={ratio:.3} total_instrs={total} ns_per_instr_on={:.2} ns_per_instr_off={:.2} tier_compiled_any={}",
            self.median_ms,
            self.median_ms_tier_off,
            per_instr_ns,
            per_instr_ns_off,
            self.tier_compiled_any,
            label = self.label,
            value = self.value,
            total = census.total,
        );

        // Opcode census: ranked by count, shares to 0.1%.
        let mut ranked: Vec<(usize, u64)> = census
            .opcode_counts
            .iter()
            .copied()
            .enumerate()
            .filter(|(_, c)| *c > 0)
            .collect();
        ranked.sort_by_key(|&(_, count)| std::cmp::Reverse(count));
        let shown = ranked.len().min(10);
        println!(
            "  opcode census (top {shown} of {} executed kinds):",
            ranked.len()
        );
        for (ord, count) in ranked.iter().take(shown) {
            let share = *count as f64 * 100.0 / census.total as f64;
            println!(
                "    {:<16} {count:>10}  {share:5.1}%",
                Opcode::ALL[*ord].kind_name(),
            );
        }

        // Dynamic adjacent pairs: the superinstruction candidate table.
        let mut pairs: Vec<(&(usize, usize), &u64)> = census.pairs.iter().collect();
        pairs.sort_by_key(|&(_, count)| std::cmp::Reverse(*count));
        let shown = pairs.len().min(10);
        println!(
            "  dynamic adjacent pairs (top {shown} of {} kinds; fusable = tail pc not a jump target):",
            pairs.len()
        );
        for ((first, second), count) in pairs.iter().take(shown) {
            let fusable = census
                .fusable_pairs
                .get(&(*first, *second))
                .copied()
                .unwrap_or(0);
            println!(
                "    {:<16}+ {:<16} {count:>10}  {:>5.1}%  fusable={}",
                Opcode::ALL[*first].kind_name(),
                Opcode::ALL[*second].kind_name(),
                **count as f64 * 100.0 / census.total as f64,
                if fusable > 0 { "yes" } else { "no" },
            );
        }

        // Fusable coverage: the share of dispatches perfect pair
        // fusion would eliminate (one dispatch per fusable pair).
        let fusable_total = census.fusable_total();
        let coverage = fusable_total as f64 * 100.0 / census.total as f64;
        println!(
            "  fusable-pair coverage: {fusable_total} of {total} dispatches = {coverage:.1}% (perfect-pair-fusion ceiling)",
            total = census.total,
        );

        // Hot functions: the method-JIT candidate input.
        let mut funcs: Vec<(usize, u64)> = census.func_counts.iter().copied().enumerate().collect();
        funcs.sort_by_key(|&(_, count)| std::cmp::Reverse(count));
        println!("  hot functions (top 3):");
        for (func, count) in funcs.iter().take(3) {
            let name = self
                .func_names
                .get(*func)
                .map(|s| s.as_str())
                .unwrap_or("?");
            println!("    {name} (func {func}): {count} instrs");
        }
        println!();
    }
}

/// The corpus-representative sources (the gc_lifetime_profile
/// allocation picks mirrored; map-double takes an outer `car` so the
/// parity pin is a scalar — the traversal + construction shape is
/// unchanged).
const FIB_25: &str = "fn fib(n) { if ((n < 2)) { n } else { (fib((n - 1)) + fib((n - 2))) } } define(result, fib(25));";
const IOTA_50: &str = "fn iota(n) { if ((n == 0)) { nil } else { pair(n, iota((n - 1))) } } define(result, first(iota(50)));";
const MAP_DOUBLE: &str = "fn map(f, xs) { if (is_nil(xs)) { nil } else { pair(f(first(xs)), map(f, rest(xs))) } } fn double(x) { (2 * x) } define(result, first(map(double, quote((1, 2, 3)))));";

/// The churn program generator (B4 axis shape): N defines, each
/// allocating one pair whose value is dropped at the next define.
fn churn_src(pairs: usize) -> String {
    let mut src = String::with_capacity(pairs * 32);
    for i in 0..pairs {
        src.push_str(&format!("define(d{i}, first(pair({i}, nil))); "));
    }
    src.push_str("define(result, d0);");
    src
}

fn main() {
    println!("== W-3.7 MUV 3.7-a: VM dispatch profile (census + dispatch share) ==");
    println!(
        "env: release profile (debug_assertions={}), parallelism {:?}",
        cfg!(debug_assertions),
        std::thread::available_parallelism()
    );
    println!();

    let lines = [
        measure("fib-25", FIB_25, 20, "75025"),
        measure("iota-50", IOTA_50, 5_000, "50"),
        measure("map-double", MAP_DOUBLE, 20_000, "2"),
        measure("churn-2000", &churn_src(2_000), 200, "0"),
    ];

    for line in &lines {
        line.print();
    }

    // The B9c cross-check summary (fib-25): the same algorithm as a
    // C binary at -O0 carries the identical call structure, so the
    // gap is the interpreter overhead — the dispatch-bound verdict
    // input. Reference value from w3.1-performance-window.md §1
    // (B9c: cc -O0 fib(25) = 23.699ms); a re-measured number
    // supersedes the reference when they differ.
    const C_O0_FIB25_MS: f64 = 23.699;
    let fib = &lines[0];
    // The production arm (tier off — the blade-2 adjudicated
    // default) carries the dispatch-share summary; the tier-on arm
    // rides along as the contrast line.
    let overhead = 1.0 - C_O0_FIB25_MS / fib.median_ms_tier_off;
    let coverage = fib.census.fusable_total() as f64 / fib.census.total as f64;
    let overhead_pct = overhead * 100.0;
    let coverage_pct = coverage * 100.0;
    println!("== dispatch-share summary (fib-25, the B9c cross-check) ==");
    println!(
        "vm_median(tier-off)={:.3}ms c_o0_median={C_O0_FIB25_MS:.3}ms interpreter_overhead_share={overhead_pct:.1}%",
        fib.median_ms_tier_off
    );
    println!(
        "tier contrast (fib-25): on={:.3}ms off={:.3}ms ratio={:.3} compiled_any={} — the blade-2 adjudication input",
        fib.median_ms,
        fib.median_ms_tier_off,
        fib.median_ms / fib.median_ms_tier_off,
        fib.tier_compiled_any
    );
    println!(
        "fusable_coverage={coverage_pct:.1}%, perfect-fusion ceiling speedup ≈ 1/(1-{overhead:.3}*{coverage:.3}) = {:.2}x",
        1.0 / (1.0 - overhead * coverage)
    );
    println!(
        "dispatch-bound verdict: the interpreter overhead share is the quantitative EXC-10 trigger input"
    );
    println!("== profile complete ==");
}

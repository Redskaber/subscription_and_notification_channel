//! Check segment profile (T-a step-④ — w-t-a-switch-window §3, the
//! §14.6.4 rule 5 MEASUREMENT-FIRST face): the CHECK segment's
//! production-position switch cost portrait, measured BEFORE the
//! switch lands as the shipped default and recorded per the
//! three-run discipline (tool-results/r147-check-segment-run{1,2,3}.
//! txt).
//!
//! Run: `cargo run --release --example check_segment_profile`.
//!
//! Three measurements:
//!
//! 1. **Chain constructions** (once per process): compiling BOTH
//!    checker twins (`typecheck.ktf` + `infer.ktf`) through the
//!    seed face — the steady-state amortization's fixed cost.
//! 2. **Per-check medians** on representative workloads (a small
//!    curated case, the match composite, and the checker twins'
//!    own CCFs — the deepest fixed-point shapes the check segment
//!    owns): the twin chains' VM checking (both twins, the
//!    production entry) vs the Rust oracle checking, back to back.
//! 3. **The whole-spine delta**: one full parse + check through
//!    each position — the user-visible face of the K140 band at the
//!    check-segment slice (read+expand at their switched defaults
//!    on both sides; the check segment alone flips).
//!
//! The band's honest shape (expected, per K140's Go 1.5 precedent):
//! the twin position pays the two chain constructions once and a
//!    per-check interpretation cost (BOTH twins run — the
//!    conservative checker and the inference engine); the rollback
//!    band (`KERF_CHECK_SEGMENT=rust`) restores the Rust checkers
//!    for any process that needs it. The numbers land in the window
//!    doc §5 (the K140 segment-slice disclosure).

use std::time::Instant;

use kerf::driver::{CheckSegment, Session, parse_target};
use kerf::span::FileId;

/// One workload: a display name and its `.ktf` source.
struct Workload<'a> {
    name: &'static str,
    source: &'a str,
}

/// The Rust oracle's checking of one parsed program (the comparison
/// arm): the plain production typecheck through the pinned session.
fn oracle_check(source: &str) -> f64 {
    let t = Instant::now();
    let mut session = Session::new();
    session.set_check_segment(CheckSegment::Rust);
    let program = parse_target(&mut session, "bench.ktf", source).expect("the workload must parse");
    let _ = program.typecheck();
    t.elapsed().as_secs_f64() * 1000.0
}

/// The twin position's checking of one parsed program (the
/// production arm): the default session (the check segment's
/// switched position; the read/expand segments ride their switched
/// defaults on both arms — this profile isolates the check slice).
fn twin_check(source: &str) -> f64 {
    let t = Instant::now();
    let mut session = Session::new();
    let program = parse_target(&mut session, "bench.ktf", source).expect("the workload must parse");
    let _ = program.typecheck();
    t.elapsed().as_secs_f64() * 1000.0
}

fn median(samples: &mut [f64]) -> f64 {
    samples.sort_by(|a, b| a.partial_cmp(b).expect("finite samples"));
    samples[samples.len() / 2]
}

fn main() {
    println!("=== check segment profile (T-a step-4, rule-5 measurement-first) ===");

    // ---- measurement 1: the chain constructions (the fixed cost) ----
    // The production entry constructs both chains lazily on the
    // first check; the fixed cost is measured through the public
    // constructors (the same compilation the production cache rides).
    let t = Instant::now();
    let _check_chain = kerf::driver::SteadyCheckChain::new()
        .unwrap_or_else(|e| panic!("the check chain must construct: {e}"));
    let check_ms = t.elapsed().as_secs_f64() * 1000.0;
    let t = Instant::now();
    let _infer_chain = kerf::driver::SteadyTypecheckChain::new()
        .unwrap_or_else(|e| panic!("the infer chain must construct: {e}"));
    let infer_ms = t.elapsed().as_secs_f64() * 1000.0;
    println!("check chain construction (typecheck.ktf, once per process): {check_ms:.1} ms");
    println!("infer chain construction (infer.ktf, once per process): {infer_ms:.1} ms");

    // ---- measurement 2: the per-check medians ----
    // The deep workloads are the checker twins in their CCF forms
    // (the extern `items` slot declaration ahead of each twin — the
    // TA-1 chain-compilable form): the checker twins checking their
    // own family's fixed points.
    let infer_ccf = kerf::driver::ccf_infer_source();
    let check_ccf = kerf::driver::ccf_check_source();
    let workloads = [
        Workload {
            name: "curated-small",
            source: "fn add(a, b) { a + b }\nfn main() { add(1, 2) }\n",
        },
        Workload {
            name: "match-composite",
            source: "fn pick(p) { match p { 1 => { 10 }, _ => { 20 }, } }\nfn main() { pick(1) }\n",
        },
        Workload {
            name: "infer-twin-ccf",
            source: infer_ccf.as_str(),
        },
        Workload {
            name: "check-twin-ccf",
            source: check_ccf.as_str(),
        },
    ];
    println!("\nworkload                   rust-check twin-check   ratio");
    for workload in &workloads {
        // Warm both positions (the twin position constructs its
        // chains through the thread-local caches on the first hit —
        // the per-check medians measure the steady state).
        let _ = twin_check(workload.source);
        let _ = oracle_check(workload.source);
        let mut rust_samples = Vec::new();
        let mut twin_samples = Vec::new();
        for _ in 0..5 {
            rust_samples.push(oracle_check(workload.source));
            twin_samples.push(twin_check(workload.source));
        }
        let rust = median(&mut rust_samples);
        let twin = median(&mut twin_samples);
        println!(
            "{:<26} {:>9.2}ms {:>9.2}ms {:>7.1}x",
            workload.name,
            rust,
            twin,
            twin / rust
        );
    }

    // ---- measurement 3: the whole-spine delta (read + expand + check) ----
    // The big spine workload rides the macro twin — the one
    // SELF-CONTAINED twin (the assembled checker programs are chain
    // pieces: their `items` slot needs the injection face, outside
    // the ordinary closed-program spine).
    let spine_workloads = [
        Workload {
            name: "curated-small",
            source: "fn add(a, b) { a + b }\nfn main() { add(1, 2) }\n",
        },
        Workload {
            name: "match-composite",
            source: "fn pick(p) { match p { 1 => { 10 }, _ => { 20 }, } }\nfn main() { pick(1) }\n",
        },
        Workload {
            name: "macro-twin-20kb",
            source: kerf::driver::MACRO_TARGET_SOURCE,
        },
    ];
    let spine = |check: CheckSegment, source: &str| -> f64 {
        let t = Instant::now();
        let mut session = Session::new();
        session.set_check_segment(check);
        let program =
            parse_target(&mut session, "spine.ktf", source).expect("the spine must parse");
        let _ = program.typecheck();
        t.elapsed().as_secs_f64() * 1000.0
    };
    // Warm both spines (the twin spine constructs its chains here —
    // the thread-local caches' first hits).
    let _ = spine(CheckSegment::Twin, spine_workloads[0].source);
    let _ = spine(CheckSegment::Rust, spine_workloads[0].source);
    println!("\nwhole spine (read + expand + check), median of 9:");
    for workload in &spine_workloads {
        let mut rust_samples = Vec::new();
        let mut twin_samples = Vec::new();
        for _ in 0..9 {
            rust_samples.push(spine(CheckSegment::Rust, workload.source));
            twin_samples.push(spine(CheckSegment::Twin, workload.source));
        }
        let rust = median(&mut rust_samples);
        let twin = median(&mut twin_samples);
        println!(
            "{:<26} rust {:>8.2}ms  twin {:>8.2}ms  {:>7.1}x",
            workload.name,
            rust,
            twin,
            twin / rust
        );
    }
    let _ = FileId(0);
}

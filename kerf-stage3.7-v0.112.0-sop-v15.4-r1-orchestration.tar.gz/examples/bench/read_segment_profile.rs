//! Read segment profile (T-a step-④ — w-t-a-switch-window §3, the
//! §14.6.4 rule 5 MEASUREMENT-FIRST face): the READ segment's
//! production-position switch cost portrait, measured BEFORE the
//! switch lands as the shipped default and recorded per the
//! three-run discipline (tool-results/r145-read-segment-run{1,2,3}.
//! txt).
//!
//! Run: `cargo run --release --example read_segment_profile`.
//!
//! Three measurements:
//!
//! 1. **Chain construction** (once per process): compiling the two
//!    read twins through the seed face — the steady-state
//!    amortization's fixed cost.
//! 2. **Per-read medians** on representative workloads (a small
//!    curated case, the match composite, and the expander twin's
//!    own 60 KB source — the deepest fixed-point shape): the twin
//!    chain's VM read vs the Rust oracle read, back to back.
//! 3. **The whole-spine delta**: one full parse (read + expand +
//!    load) through each position — the user-visible face of the
//!    K140 band at the read-segment slice.
//!
//! The band's honest shape (expected, per K140's Go 1.5 precedent):
//! the twin position pays the chain construction once and a
//! per-read interpretation cost; the rollback band
//! (`KERF_READ_SEGMENT=rust`) restores the Rust reader for any
//! process that needs it. The numbers land in the window doc §5
//! (the K140 segment-slice disclosure).

use std::time::Instant;

use kerf::driver::{ReadSegment, Session, parse_target, production_read};
use kerf::reader::{read_target_program, read_target_program_with_limit};
use kerf::span::FileId;

/// One workload: a display name and its `.ktf` source.
struct Workload<'a> {
    name: &'static str,
    source: &'a str,
}

fn main() {
    println!("=== read segment profile (T-a step-4, rule-5 measurement-first) ===");

    // ---- measurement 1: the chain construction (the fixed cost) ----
    let t = Instant::now();
    let chain = kerf::driver::SteadyTargetReaderChain::new()
        .unwrap_or_else(|e| panic!("the chain must construct: {e}"));
    let chain_ms = t.elapsed().as_secs_f64() * 1000.0;
    println!("chain construction (once per process): {chain_ms:.1} ms");

    // ---- measurement 2: the per-read medians ----
    let workloads = [
        Workload {
            name: "curated-small",
            source: "fn add(a, b) { a + b }\nfn main() { add(1, 2) }\n",
        },
        Workload {
            name: "match-composite",
            source: "fn pick(p) { match p { 1 => { 10 }, _ => { 20 }, } }\nfn main() { pick(1) }\n",
        },
        Workload {
            name: "expander-twin-60kb",
            source: kerf::driver::EXPANDER_TARGET_SOURCE,
        },
    ];
    println!("\nworkload                     rust-read   twin-read   ratio");
    for workload in &workloads {
        // The warm-up: both faces once (page faults, first-run lazies).
        let _ = read_target_program(FileId(0), workload.source);
        let _ = chain.read_production(workload.source);
        // The Rust arm: 9 samples, median.
        let mut rust_samples = Vec::new();
        for _ in 0..9 {
            let t = Instant::now();
            let _ = read_target_program(FileId(0), workload.source);
            rust_samples.push(t.elapsed().as_secs_f64() * 1000.0);
        }
        rust_samples.sort_by(|a, b| a.partial_cmp(b).unwrap());
        let rust_ms = rust_samples[rust_samples.len() / 2];
        // The twin arm: 9 samples, median.
        let mut twin_samples = Vec::new();
        for _ in 0..9 {
            let t = Instant::now();
            let _ = chain.read_production(workload.source);
            twin_samples.push(t.elapsed().as_secs_f64() * 1000.0);
        }
        twin_samples.sort_by(|a, b| a.partial_cmp(b).unwrap());
        let twin_ms = twin_samples[twin_samples.len() / 2];
        let ratio = twin_ms / rust_ms.max(f64::EPSILON);
        println!(
            "{:<28} {:>8.3} ms {:>8.3} ms {:>7.1}x",
            workload.name, rust_ms, twin_ms, ratio
        );
    }

    // ---- measurement 3: the whole-spine delta (read + expand + load) ----
    // The big spine workload rides macro.ktf — the one SELF-CONTAINED
    // twin (the assembled expander program is a chain piece: its
    // `forms` slot needs the injection face, outside the ordinary
    // closed-program spine).
    let spine_workloads = [
        Workload {
            name: "curated-small",
            source: "fn add(a, b) { a + b }\nfn main() { add(1, 2) }\n",
        },
        Workload {
            name: "match-composite",
            source: "fn pick(p) { match p { 1 => { 10 }, _ => { 20 }, } }\nfn main() { pick(1) }\n",
        },
        Workload {
            name: "macro-twin-20kb",
            source: kerf::driver::MACRO_TARGET_SOURCE,
        },
    ];
    let spine = |segment: ReadSegment, source: &str| -> f64 {
        let t = Instant::now();
        let mut session = Session::with_read_segment(segment);
        let program =
            parse_target(&mut session, "spine.ktf", source).expect("the spine must parse");
        let elapsed = t.elapsed().as_secs_f64() * 1000.0;
        assert!(!program.items.is_empty(), "the spine must produce items");
        elapsed
    };
    // Warm both spines (the twin spine constructs its chain here —
    // the thread-local cache's first hit).
    let _ = spine(ReadSegment::Twin, spine_workloads[0].source);
    let _ = spine(ReadSegment::Rust, spine_workloads[0].source);
    println!("\nwhole spine (read + expand + load), median of 9:");
    for workload in &spine_workloads {
        let mut rust_samples = Vec::new();
        for _ in 0..9 {
            rust_samples.push(spine(ReadSegment::Rust, workload.source));
        }
        rust_samples.sort_by(|a, b| a.partial_cmp(b).unwrap());
        let rust_ms = rust_samples[rust_samples.len() / 2];
        let mut twin_samples = Vec::new();
        for _ in 0..9 {
            twin_samples.push(spine(ReadSegment::Twin, workload.source));
        }
        twin_samples.sort_by(|a, b| a.partial_cmp(b).unwrap());
        let twin_ms = twin_samples[twin_samples.len() / 2];
        let ratio = twin_ms / rust_ms.max(f64::EPSILON);
        println!(
            "{:<28} {:>8.3} ms {:>8.3} ms {:>7.1}x",
            workload.name, rust_ms, twin_ms, ratio
        );
    }

    // ---- the honest band disclosure ----
    //
    // The single-file CLI process pays: chain construction once +
    // the twin read (the K140 segment slice). The numbers above are
    // the segment's own portrait; the full-chain band (K140 ~10x)
    // is the window-level acceptance, disclosed in the window doc.
    println!(
        "\nband note: a single-file process pays chain ({chain_ms:.1} ms) + the twin reads; \
         the rollback band is `KERF_READ_SEGMENT=rust` (fail-closed on any other value)."
    );

    // The oracle-limit spot check: the with_limit face stays honest
    // under the raised cap (the rollback band's parity obligation).
    let mut deep = String::from("define(result, ");
    for _ in 0..200 {
        deep.push_str("if (true) { ");
    }
    deep.push('1');
    for _ in 0..200 {
        deep.push_str(" } else { 0 }");
    }
    deep.push_str(");");
    assert!(
        production_read(&deep, 512, FileId(0)).is_ok()
            && read_target_program_with_limit(FileId(0), &deep, 512).is_ok(),
        "the raised cap must accept on both positions"
    );
    println!("cap check: 200-deep nest accepts under the 512 cap on both positions.");
}

//! Cross-crate integration tests for the Stage 0.9 macro system —
//! the §7.1 full-chain standard (test doc: docs/tests/v0/stage0/plan/
//! macro.md §2): define-syntax → use → expand → execute on both
//! engines plus parity, the hygiene guarantees observable at the
//! value level, quote end-to-end, module loading (including the
//! §7.1.1 class 7 cycle family), the REPL macro session, and the
//! rendered macro diagnostics.

use kerf::driver::{self, Engine, Repl, ReplEvent, Session, run_source};
use kerf::expander::CodeValue;

const MY_IF: &str = "macro my_if { (syntax_rules, nil, ((_, c, t, e), (if, c, t, e))) }";
// The r151 single-skin retarget: the macro declaration rides the
// `macro name { spec }` carrier (the spec is a datum — the comma
// tuple is the list datum the S-expr face's parenthesized lists
// read), and every use site rides the target call form. The mapped
// trees are the S-expr originals', by the datum-grammar construction.
const FIB_WITH_MACRO: &str = "macro my_if { (syntax_rules, nil, ((_, c, t, e), (if, c, t, e))) }\nfn fib(n) { my_if((n < 2), n, (fib((n - 1)) + fib((n - 2)))) }\ndefine(r, fib(10));";

fn expect_global(outcome: &driver::RunOutcome, name: &str, expect: &str) {
    assert_eq!(
        outcome.global(name).map(|v| v.to_string()),
        Some(expect.to_owned()),
        "global `{name}` must hold {expect}"
    );
}

// ---- Positive: define → use → expand → execute (the plan row 0.9
// acceptance) ----

#[test]
fn e2e_macro_fib_on_vm() {
    let mut session = Session::new();
    let outcome =
        run_source(&mut session, "fib.krf", FIB_WITH_MACRO, Engine::Vm, &[]).expect("vm run");
    expect_global(&outcome, "r", "55");
}

#[test]
fn e2e_macro_fib_on_eval() {
    let mut session = Session::new();
    let outcome =
        run_source(&mut session, "fib.krf", FIB_WITH_MACRO, Engine::Eval, &[]).expect("eval run");
    expect_global(&outcome, "r", "55");
}

#[test]
fn e2e_macro_parity_agrees() {
    let mut session = Session::new();
    let report = driver::run_parity_source(&mut session, "fib.krf", FIB_WITH_MACRO, &[])
        .expect("parity run");
    assert!(report.agrees(), "both engines agree on macro fib(10)");
    assert!(report.globals_agree);
}

#[test]
fn e2e_hygiene_wrap_produces_the_use_site_value() {
    // The classic capture trap, made observable: the macro introduces
    // a `tmp` binder (value 100) and adds the use-site argument. The
    // use site passes its *own* `tmp` (a parameter worth 1). Without
    // hygiene the introduced let would shadow the use-site name in
    // both positions (100 + 100 = 200); with rename-on-capture the
    // use-site reference keeps its meaning (100 + 1 = 101).
    let src = "macro add_temp { (syntax_rules, nil, ((_, a), (let, ((tmp, 100),), (+, tmp, a)))) }\nfn f(tmp) { add_temp(tmp) }\ndefine(r, f(1));";
    let mut session = Session::new();
    for engine in [Engine::Vm, Engine::Eval] {
        let outcome = run_source(&mut session, "hygiene.krf", src, engine, &[])
            .expect("the hygienic wrap must run");
        expect_global(&outcome, "r", "101");
    }
}

#[test]
fn e2e_introduced_binder_reachable_and_isolated() {
    // The introduced binder is reachable (the introduced reference
    // resolves to it) while the use-site name keeps its meaning:
    // make-adder's introduced `tmp` accumulates the call argument;
    // a use-site `tmp` flows through the pattern variable untouched.
    let src = "macro make_adder { (syntax_rules, nil, ((_, n), (fn, (tmp,), (+, tmp, n)))) }\ndefine(add5, make_adder(5));\ndefine(r, add5(10));\ndefine(r2, (||(tmp) { add5(tmp) })(100));";
    let mut session = Session::new();
    for engine in [Engine::Vm, Engine::Eval] {
        let outcome = run_source(&mut session, "hygiene2.krf", src, engine, &[])
            .expect("the introduced binder must be callable");
        expect_global(&outcome, "r", "15");
        expect_global(&outcome, "r2", "105");
    }
}

#[test]
fn e2e_quote_pair_chain_consumed_by_car_cdr() {
    // (car (quote (1 2 3))) → 1; the chain tail through cdr → 2 (the
    // context-free pair Display is opaque by design — value_display
    // is not the structural face; the car chain observes the data).
    // The r151 retarget: the quote carrier is the call form
    // `quote((d1, d2, ...))` — the comma tuple is the list datum.
    let src = "define(a, first(quote((1, 2, 3))));\ndefine(b, first(rest(quote((1, 2, 3)))));\ndefine(c, first(rest(rest(quote((1, 2, 3))))));";
    let mut session = Session::new();
    for engine in [Engine::Vm, Engine::Eval] {
        let outcome =
            run_source(&mut session, "quote.krf", src, engine, &[]).expect("quote must run");
        expect_global(&outcome, "a", "1");
        expect_global(&outcome, "b", "2");
        expect_global(&outcome, "c", "3");
    }
}

#[test]
fn e2e_macro_in_macro_expands_two_generations() {
    // outer → (inner) → 7: two hops, both engines.
    let src = "macro outer { (syntax_rules, nil, ((_,), (inner,))) }\nmacro inner { (syntax_rules, nil, ((_,), 7)) }\ndefine(r, outer());";
    let mut session = Session::new();
    for engine in [Engine::Vm, Engine::Eval] {
        let outcome = run_source(&mut session, "hops.krf", src, engine, &[])
            .expect("two macro hops must run");
        expect_global(&outcome, "r", "7");
    }
}

#[test]
fn e2e_module_program_with_macro_runs() {
    // A nested module declares and uses its own macro; the top level
    // requires a *different* module (a linear chain). The r151
    // retarget: `module name { ... }` items and the `use "name";`
    // require form (the target skin's module face — the `require`
    // call carrier rejects fail-closed on the target skin).
    let src = "module math { fn double(x) { (2 * x) } define(d, double(21)); }\nmodule other { macro twice { (syntax_rules, nil, ((_, e), (+, e, e))) } define(t, twice(10)); }\nuse \"math\";\ndefine(r, first(quote((55, 20))));";
    let mut session = Session::new();
    for engine in [Engine::Vm, Engine::Eval] {
        let outcome = run_source(&mut session, "mod.krf", src, engine, &[])
            .expect("the module program must run");
        expect_global(&outcome, "r", "55");
    }
}

#[test]
fn e2e_nested_module_macro_visible_inside_only() {
    // The macro works inside its module; the module's defines still
    // compile flat (the 0.5/0.7 runtime faces).
    let src = "module m { macro my_if { (syntax_rules, nil, ((_, c, t, e), (if, c, t, e))) } define(inner, my_if(true, 1, 2)); }\ndefine(r, 9);";
    let mut session = Session::new();
    let outcome = run_source(&mut session, "modmacro.krf", src, Engine::Vm, &[])
        .expect("the nested module macro must work inside");
    expect_global(&outcome, "r", "9");
}

#[test]
fn e2e_check_face_accepts_macro_programs() {
    let mut session = Session::new();
    let check = driver::check_source(&mut session, "fib.krf", FIB_WITH_MACRO).expect("check");
    // fib + the entry define (my-if expands to core forms; the
    // define-syntax itself contributes zero functions).
    assert_eq!(check.func_count, 2);
}

#[test]
fn e2e_repl_macro_defines_then_uses_across_lines() {
    let mut repl = Repl::new();
    match repl.submit(MY_IF) {
        ReplEvent::Evaluated { .. } => {}
        other => panic!("the macro declaration line must be accepted, got {other:?}"),
    }
    let event = repl.submit("my_if((2 < 1), 0, 42);");
    let (value, _) = assert_evaluated(event);
    assert_eq!(value.as_deref(), Some("42"));
}

fn assert_evaluated(event: ReplEvent) -> (Option<String>, Vec<String>) {
    match event {
        ReplEvent::Evaluated {
            value, new_outputs, ..
        } => (value, new_outputs),
        other => panic!("expected Evaluated, got {other:?}"),
    }
}

// ---- Positive: the CodeValue structured face over real syntax ----

#[test]
fn code_value_over_a_real_macro_template() {
    // Read the my-if template through the target skin's quote
    // carrier — `quote((if, c, t, e))` wraps the template-shaped list
    // datum the S-expr face's bare `(if c t e)` used to read (the
    // bare call form is a keyword on the target skin, so the datum
    // rides the carrier) — then exercise the public operations over
    // real reader output.
    let file = kerf::span::FileId(0);
    let forms = kerf::reader::read_target_program(file, "quote((if, c, t, e));")
        .expect("the template carrier must read");
    // The carrier wraps the template list as its single datum.
    let template = match &forms[0].datum {
        kerf::syntax::StxDatum::List(items) => &items[1],
        other => panic!("the carrier must wrap the template, got {other:?}"),
    };
    let code = CodeValue::from_syntax(template);
    assert_eq!(code.to_source(), "(if c t e)");
    assert_eq!(code.symbols(), vec!["c", "e", "if", "t"]);
    // Substitute the condition: (if true t e).
    let cond = kerf::reader::read_target_program(file, "true;").expect("the condition must read");
    let substituted = code.substitute("c", &CodeValue::from_syntax(&cond[0]));
    assert_eq!(substituted.to_source(), "(if true t e)");
    // Alpha-rename the then-branch: (if true t2 e).
    let renamed = substituted.alpha_rename("t", "t2");
    assert_eq!(renamed.to_source(), "(if true t2 e)");
    assert_eq!(renamed.phase(), kerf::syntax::Phase::Runtime);
}

#[test]
fn seed_alpha_rename_floor_is_pinned_by_negative_cases() {
    // r106 FIX-5: the documented panic floor of `alpha_rename` — the
    // rename target must be valid symbol text (non-empty; no control
    // characters). Both illegal shapes panic with the pinned message;
    // the floor is now a tested contract, not an implicit one.
    let file = kerf_span::FileId(0);
    let forms = kerf::reader::read_target_program(file, "quote((if, c, t, e));")
        .expect("the template carrier must read");
    let template = match &forms[0].datum {
        kerf::syntax::StxDatum::List(items) => &items[1],
        other => panic!("the carrier must wrap the template, got {other:?}"),
    };
    let code = CodeValue::from_syntax(template);
    let empty = std::panic::catch_unwind(|| code.alpha_rename("t", ""));
    assert!(
        empty.is_err(),
        "an empty rename target must hit the symbol floor"
    );
    let spaced = std::panic::catch_unwind(|| code.alpha_rename("t", "a b"));
    assert!(
        spaced.is_err(),
        "a whitespace-carrying rename target must hit the symbol floor"
    );
    // The legal face stays intact (the round trip the remedy tool
    // promises).
    assert_eq!(code.alpha_rename("t", "t2").to_source(), "(if c t2 e)");
}

// ---- Negative: rendered diagnostics (the §7.1.1 families) ----

fn rendered_error(src: &str) -> String {
    let mut session = Session::new();
    let diags =
        driver::parse_target(&mut session, "neg.krf", src).expect_err("the program must fail");
    driver::render_diagnostics(&session, &diags)
}

#[test]
fn neg_pattern_mismatch_renders_with_location() {
    let rendered = rendered_error(&format!("{MY_IF}\ndefine(r, my_if(true, 1));"));
    assert!(
        rendered.contains("macro `my_if` matched no clause"),
        "{rendered}"
    );
    assert!(rendered.contains("kerf-expand"), "{rendered}");
    // The use-site head `my_if` sits at column 11 of line 2 (the
    // diagnostic re-spells the macro subject through the skin map —
    // `my_if`, the target spelling, not the canonical `my-if`).
    assert!(rendered.contains("2:11"), "{rendered}");
}

#[test]
fn neg_quote_symbol_renders_the_boundary() {
    let rendered = rendered_error("define(r, quote(ghost));");
    assert!(
        rendered.contains("quote cannot carry this datum"),
        "{rendered}"
    );
    assert!(rendered.contains("symbol data"), "{rendered}");
}

#[test]
fn neg_nested_quote_symbol_points_at_the_symbol() {
    let rendered = rendered_error("define(r, quote((1, ghost)));");
    assert!(
        rendered.contains("quote cannot carry this datum"),
        "{rendered}"
    );
    assert!(rendered.contains("1:21"), "{rendered}");
}

#[test]
fn neg_use_site_binding_does_not_capture_introduced_reference_e2e() {
    // The free introduced `tmp` inside a let-bound tmp: the coloring
    // keeps them apart, so the reference stays unbound — the Racket
    // judgment. Rides the ORACLE arm (read through the target reader,
    // expand through the Rust expander): the selfhost twin's
    // plain-ident lookup is text-only — an introduced non-colliding
    // template identifier currently resolves against a use-site frame
    // entry (the twin accepts this program; the oracle rejects it).
    // Registered as TD-028 (TWIN-HYG-1) — the audit's J03 carries the
    // same disclosure; this case moves back to the production arm
    // when the twin's (name, generation) frame migration lands.
    let src = "macro m { (syntax_rules, nil, ((_,), tmp)) }\ndefine(r, { let tmp = 1; m() });";
    let forms = kerf::reader::read_target_program(kerf::span::FileId(0), src)
        .expect("the fixture reads on the target face");
    let err = kerf::expander::expand_program(&forms)
        .expect_err("the oracle arm must reject the introduced reference");
    let rendered = format!("{err}");
    assert!(rendered.contains("unbound identifier `tmp`"), "{rendered}");
}

#[test]
fn neg_self_recursive_macro_hits_the_depth_budget_e2e() {
    let rendered = rendered_error(
        "macro loopy { (syntax_rules, nil, ((_,), (loopy,))) }\ndefine(r, loopy());",
    );
    assert!(rendered.contains("expansion depth exceeded"), "{rendered}");
}

#[test]
fn neg_use_before_definition_fails() {
    let rendered = rendered_error(
        "define(r, my_if(true, 1, 2));\nmacro my_if { (syntax_rules, nil, ((_, c, t, e), (if, c, t, e))) }",
    );
    assert!(
        rendered.contains("unbound identifier `my_if`"),
        "{rendered}"
    );
}

#[test]
fn neg_module_scoped_macro_used_outside_fails() {
    let rendered = rendered_error(&format!(
        "module inner {{ {MY_IF} }}\ndefine(r, my_if(true, 1, 2));"
    ));
    assert!(
        rendered.contains("unbound identifier `my_if`"),
        "{rendered}"
    );
}

#[test]
fn neg_define_syntax_malformed_shapes_render() {
    // Bad head in the spec (the target datum spelling maps
    // `not_rules` to the canonical `not-rules` through Rule K).
    let rendered = rendered_error("macro m { (not_rules, nil, ((_, x), x)) }");
    assert!(rendered.contains("malformed `define-syntax`"), "{rendered}");
    // Reserved name. The r151 retarget: the S-expr face's `if` row is
    // unspellable here — `if` is a target-skin keyword and cannot
    // even serve as the macro name token — so the reserved-name face
    // rides `quote`, a reserved head that IS a plain identifier on
    // the target skin (the neg-031 SR-2 re-pinning precedent: same
    // judgment, nearest spellable carrier).
    let rendered =
        rendered_error("macro quote { (syntax_rules, nil, ((_, c, t, e), (if, c, t, e))) }");
    assert!(rendered.contains("malformed `define-syntax`"), "{rendered}");
    // Ellipsis pattern (the Stage 0 boundary; `...` is a datum
    // symbol on the target skin — the operator-name table).
    let rendered = rendered_error("macro m { (syntax_rules, nil, ((_, x, ...), (f, x))) }");
    assert!(rendered.contains("malformed `define-syntax`"), "{rendered}");
    // Duplicate pattern variables.
    let rendered = rendered_error("macro m { (syntax_rules, nil, ((_, x, x), (f, x))) }");
    assert!(rendered.contains("malformed `define-syntax`"), "{rendered}");
}

// ---- Negative: the module loading family (§7.1.1 class 7) ----

#[test]
fn neg_module_cycle_two_modules_renders_with_the_path() {
    // The seventh §7.1.1 error class, end-to-end through the driver:
    // the cycle path names both modules.
    // The r151 retarget: the target skin's module face — `module
    // name { ... }` items and the `use "name";` require form (the
    // neg-048 corpus attestation).
    let src = "module a { use \"b\"; }\nmodule b { use \"a\"; }";
    let rendered = rendered_error(src);
    assert!(rendered.contains("module cycle detected"), "{rendered}");
    assert!(rendered.contains("`a` -> `b` -> `a`"), "{rendered}");
    assert!(rendered.contains("kerf-expand"), "{rendered}");
}

#[test]
fn neg_module_cycle_three_modules_renders() {
    let src = "module a { use \"b\"; }\nmodule b { use \"c\"; }\nmodule c { use \"a\"; }";
    let rendered = rendered_error(src);
    assert!(rendered.contains("module cycle detected"), "{rendered}");
    assert!(rendered.contains("`a` -> `b` -> `c` -> `a`"), "{rendered}");
}

#[test]
fn neg_module_self_require_is_a_cycle() {
    let rendered = rendered_error("module a { use \"a\"; }");
    assert!(rendered.contains("module cycle detected"), "{rendered}");
    assert!(rendered.contains("`a` -> `a`"), "{rendered}");
}

#[test]
fn neg_module_not_found_renders() {
    let rendered = rendered_error("use \"ghost\";");
    assert!(
        rendered.contains("required module `ghost` is not declared"),
        "{rendered}"
    );
}

#[test]
fn neg_module_duplicate_declarations_render() {
    let rendered = rendered_error("module a { define(x, 1); }\nmodule a { define(y, 2); }");
    assert!(
        rendered.contains("duplicate module declaration `a`"),
        "{rendered}"
    );
}

#[test]
fn neg_module_cycle_line_column_rendered() {
    // The cycle diagnostic carries the require's line:column — the
    // triggering back-edge (`use "a"` inside module b) sits on
    // line 3 of the target-skin spelling.
    let src = "module a { use \"b\"; }\nmodule b {\n    use \"a\";\n}";
    let rendered = rendered_error(src);
    assert!(rendered.contains("module cycle detected"), "{rendered}");
    assert!(rendered.contains("3:"), "{rendered}");
}

// ---- Negative: quote shape guards ----

#[test]
fn neg_quote_wrong_arity_renders() {
    // The r151 retarget: on the target skin the wrong-arity guard
    // moved from the expander into the reader — the quote carrier
    // parses exactly one datum, so a second argument is rejected at
    // the read boundary with the carrier's own message (the
    // stage-move twin of the S-expr face's `malformed \`quote\`
    // form` — same mistake, rejected one stage earlier).
    let rendered = rendered_error("define(r, quote(1, 2));");
    assert!(
        rendered.contains("quote carries data, not expressions"),
        "{rendered}"
    );
}

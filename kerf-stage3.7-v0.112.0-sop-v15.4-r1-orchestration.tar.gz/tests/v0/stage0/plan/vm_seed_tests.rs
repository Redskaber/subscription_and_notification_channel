//! kerf-vm seed tests (Stage 0.6, cross-crate integration layer).
//!
//! Mounted via `tests/runner.rs` (SOP §8.4.6 root-tree discipline).
//! The anchor cases run the full four-segment chain for the first
//! time — source -> tokens -> stx -> CoreExpr -> Bytecode -> VM
//! value — pinning the fib contract (0.3/0.4/0.5/0.6 one assertion),
//! the STAGE0_GLOBALS parity, and the source-reachable runtime
//! negatives that light SOP §7.1.1 classes 5 and 6.

use kerf::compiler::{Bytecode, Opcode, compile_program};
use kerf::expander::{STAGE0_GLOBALS, expand_program};
use kerf::reader::read_target_program;
use kerf::span::FileId;
use kerf::vm::{Builtin, RuntimeError, Value, Vm};

const FILE: FileId = FileId(0);

fn compile_source(src: &str) -> Bytecode {
    let forms = read_target_program(FILE, src).expect("source must read");
    let items = expand_program(&forms).expect("source must expand");
    compile_program(&items).expect("source must compile")
}

fn run_source(src: &str) -> Result<Value, RuntimeError> {
    let bc = compile_source(src);
    let mut vm = Vm::new(bc).expect("verified product loads");
    vm.run()
}

// ---------- positive: cross-stage consumption ----------

#[test]
fn fib_contract_runs_source_to_value_and_binding_forms_execute() {
    // The four-segment anchor: reader (0.3) -> expander (0.4) ->
    // compiler (0.5) -> VM (0.6). Declaration-only programs halt at
    // depth 0 (nil), the observation face is the global table. The
    // r151 single-skin retarget: the fixture rides the target skin
    // (the pos-009 corpus spelling — the mapped tree is the S-expr
    // original's, by the skin-dictionary construction).
    let fib_def = "fn fib(n) { if ((n < 2)) { n } else { (fib((n - 1)) + fib((n - 2))) } }";
    let mut vm = Vm::new(compile_source(&format!("{fib_def} define(r, fib(10));")))
        .expect("verified product loads");
    assert_eq!(vm.run().expect("program runs"), Value::Nil);
    assert_eq!(vm.global("r"), Some(&Value::Int(55)));

    // §20.1 Week-3 criterion: fib(25) = 75025 on the VM (≈243k
    // frames — far under the default budget).
    let mut vm = Vm::new(compile_source(&format!("{fib_def} define(r, fib(25));")))
        .expect("verified product loads");
    vm.run().expect("program runs");
    assert_eq!(vm.global("r"), Some(&Value::Int(75025)));

    // let* progressive binding and assign's stack balance (the
    // assigned value IS the expression value).
    let mut vm = Vm::new(compile_source("define(r, { let a = 1, b = 2; (a + b) });"))
        .expect("verified product loads");
    vm.run().expect("program runs");
    assert_eq!(vm.global("r"), Some(&Value::Int(3)));

    let mut vm = Vm::new(compile_source("define(x, 1); define(r, { x = 5; x });"))
        .expect("verified product loads");
    vm.run().expect("program runs");
    assert_eq!(vm.global("r"), Some(&Value::Int(5)));
    assert_eq!(vm.global("x"), Some(&Value::Int(5)));
}

#[test]
fn stage0_globals_parity_between_expander_and_vm_registry() {
    // Every STAGE0_GLOBALS name resolves to a builtin (expander ->
    // VM), and the VM registry holds no name outside the list — the
    // 0.7 runtime parity assertion's 0.6 pre-anchor.
    assert_eq!(STAGE0_GLOBALS.len(), 18);
    assert_eq!(Builtin::ALL.len(), 18);
    for name in STAGE0_GLOBALS {
        assert!(
            Builtin::from_name(name).is_some(),
            "expander global `{name}` missing from the VM registry"
        );
    }
    for (_, name, _) in Builtin::ALL {
        assert!(
            STAGE0_GLOBALS.contains(&name),
            "VM registry name `{name}` missing from STAGE0_GLOBALS"
        );
    }
    // A compiled program seeding check: every builtin referenced by
    // source resolves to a builtin value at load time. The r151
    // target-skin spellings map to the canonical identities (`pair` ->
    // `cons`, `first` -> `car`, `is_nil` -> `nil?`) — the global table
    // carries the canonical names.
    let bc = compile_source("define(r, pair(first(pair(1, 2)), is_nil(nil)));");
    let vm = Vm::new(bc).expect("verified product loads");
    for name in ["cons", "car", "nil?"] {
        assert_eq!(vm.global(name).map(|v| v.kind_name()), Some("builtin"));
    }
}

// ---------- negative: runtime error classes (§7.1.1 #5/#6) ----------

#[test]
fn arity_mismatch_is_reachable_from_source_on_both_faces() {
    // SOP §7.1.1 class 5: closures (proto params) and builtins
    // (registry arity) — fixed arity at Stage 0.
    match run_source("fn f(x) { x } define(r, f(1, 2));") {
        Err(RuntimeError::ArityMismatch {
            func,
            expected,
            actual,
            ..
        }) => {
            // §9.67 NB-5: the payload identity is a pool entry.
            assert_eq!(func.as_ref().map(|s| s.as_str()), Some("f"));
            assert_eq!((expected, actual), (1, 2));
        }
        other => panic!("expected closure arity mismatch, got {other:?}"),
    }
    // Builtin face (fixed arity — the documented 0.6 semantics). The
    // r151 single-skin retarget: the target skin cannot name `+` as a
    // callee (operator glyphs are skin material), so the builtin
    // arity probe rides the nameable `pair` (`cons`, fixed arity 2)
    // with the same expected/actual pair.
    match run_source("define(r, pair(1, 2, 3));") {
        Err(RuntimeError::ArityMismatch {
            func,
            expected,
            actual,
            ..
        }) => {
            assert_eq!(func.as_ref().map(|s| s.as_str()), Some("cons"));
            assert_eq!((expected, actual), (2, 3));
        }
        other => panic!("expected builtin arity mismatch, got {other:?}"),
    }
}

#[test]
fn type_mismatch_is_reachable_from_source_in_four_contexts() {
    // SOP §7.1.1 class 6: truthy demands bool, arithmetic demands
    // same-kind numbers, car demands a pair, calls demand a callee.
    match run_source("define(r, if (1) { 2 } else { 3 });") {
        Err(RuntimeError::TypeMismatch { got, context, .. }) => {
            assert_eq!((got, context), ("int", "jump-if-false condition"));
        }
        other => panic!("expected truthy type mismatch, got {other:?}"),
    }
    match run_source("define(r, 1 + true);") {
        Err(RuntimeError::TypeMismatch { got, context, .. }) => {
            assert_eq!((got, context), ("bool", "add operand"));
        }
        other => panic!("expected arithmetic type mismatch, got {other:?}"),
    }
    match run_source("define(r, first(5));") {
        Err(RuntimeError::TypeMismatch { got, context, .. }) => {
            assert_eq!((got, context), ("int", "car operand"));
        }
        other => panic!("expected car type mismatch, got {other:?}"),
    }
    match run_source("define(f, 5); define(r, f(1));") {
        Err(RuntimeError::TypeMismatch { got, context, .. }) => {
            assert_eq!((got, context), ("int", "call callee"));
        }
        other => panic!("expected callee type mismatch, got {other:?}"),
    }
}

#[test]
fn effects_execute_the_nearest_handler_and_reject_unmatched() {
    // Positive ride-along: nested handlers resolve innermost-first;
    // the handler's return value is the perform's value.
    let mut vm = Vm::new(compile_source(
        "define(r, handle (handle (perform e(1)) { e(v) => { (v + 9) }, }) { e(v) => { 100 }, });",
    ))
    .expect("verified product loads");
    vm.run().expect("handled perform runs");
    assert_eq!(vm.global("r"), Some(&Value::Int(10)));

    // A different effect stays unhandled even with one installed.
    match run_source("define(r, handle (perform other(1)) { e(v) => { v }, });") {
        Err(RuntimeError::UnhandledEffect { effect, .. }) => {
            assert_eq!(effect.as_str(), "other");
        }
        other => panic!("expected unhandled effect, got {other:?}"),
    }
}

#[test]
fn integer_overflow_fails_closed_at_the_boundary() {
    // The boundary value itself is a legal program; adding one past
    // it overflows i64 and fails closed (no wrapping).
    let mut vm =
        Vm::new(compile_source("define(r, 9223372036854775807);")).expect("verified product loads");
    vm.run().expect("boundary value runs");
    assert_eq!(vm.global("r"), Some(&Value::Int(i64::MAX)));

    match run_source("define(r, 9223372036854775807 + 1);") {
        Err(RuntimeError::ArithmeticOverflow { op, .. }) => assert_eq!(op, Opcode::Add),
        other => panic!("expected arithmetic overflow, got {other:?}"),
    }
}

#[test]
fn eq_identity_on_heap_objects_is_same_cell_not_structure() {
    // Two structurally equal conses are distinct heap cells
    // (declaration-only programs observe through the global table).
    let mut vm = Vm::new(compile_source("define(r, eq(pair(1, 2), pair(1, 2)));"))
        .expect("verified product loads");
    vm.run().expect("program runs");
    assert_eq!(vm.global("r"), Some(&Value::Bool(false)));
    // The same cell compared with itself is true.
    let mut vm = Vm::new(compile_source(
        "define(p, pair(1, 2)); define(r, eq(p, p));",
    ))
    .expect("verified product loads");
    vm.run().expect("program runs");
    assert_eq!(vm.global("r"), Some(&Value::Bool(true)));
}

#[test]
fn perform_into_a_builtin_handler_still_checks_arity() {
    // The handler face is the shared invoke path: a handler whose
    // closure arity differs from the performed payload count fails
    // closed. The r151 single-skin retarget: the target skin's
    // handler arm always builds an `fn` form (the builtin-as-handler
    // spelling `(e +)` retired with the S-expr face — operator glyphs
    // are unnameable), so the twin rides the neg-034 corpus shape: a
    // two-parameter handler receiving one performed value.
    match run_source("define(r, handle (perform e(1)) { e(a, b) => { a }, });") {
        Err(RuntimeError::ArityMismatch {
            func,
            expected,
            actual,
            ..
        }) => {
            assert_eq!(func, None, "the handler closure is anonymous");
            assert_eq!((expected, actual), (2, 1));
        }
        other => panic!("expected handler arity mismatch, got {other:?}"),
    }
}

#[test]
fn literal_materialization_budgets_are_batch_identical_across_engines() {
    // §9.69.3 EXC-1/EXC-2 (cross-engine integration face): both
    // engines budget pair literals through the single-sourced
    // `LiteralValue::pair_cells` and one `reserve_exact` batch, so
    // the accept/reject boundary is engine-independent — the quoted
    // list (1 2 3) is three pair cells on top of one entry unit in
    // both the VM (entry frame) and the meta-circular evaluator
    // (depth 1).
    use kerf::runtime::Evaluator;

    let src = "define(r, quote((1, 2, 3)));";
    let forms = read_target_program(FILE, src).expect("source must read");
    let items = expand_program(&forms).expect("source must expand");

    // VM side: budget 2 passes (the three-cell batch checks live 1
    // against the same condition the per-cell loop used — the burst
    // may land live above the line, exactly as before), budget 1
    // fails closed.
    let bc = compile_program(&items).expect("source must compile");
    let mut vm = kerf::vm::Vm::with_budget(bc.clone(), 2).expect("verified product loads");
    vm.run().expect("vm burst passes");
    assert!(vm.global("r").is_some());
    match kerf::vm::Vm::with_budget(bc, 1)
        .expect("verified product loads")
        .run()
    {
        Err(RuntimeError::BudgetExceeded { budget, .. }) => assert_eq!(budget, 1),
        other => panic!("expected vm budget exhaustion, got {other:?}"),
    }

    // Evaluator side: the identical boundary, cell for cell.
    let mut ev = Evaluator::with_budget(2);
    ev.eval_program(&items).expect("eval burst passes");
    assert!(ev.global("r").is_some());
    let mut ev = Evaluator::with_budget(1);
    match ev.eval_program(&items) {
        Err(RuntimeError::BudgetExceeded { budget, .. }) => assert_eq!(budget, 1),
        other => panic!("expected eval budget exhaustion, got {other:?}"),
    }
}

#[test]
fn sibling_scope_slot_reuse_runs_correctly_on_the_vm() {
    // §9.70.3 EMI-3 (cross-stage integration face): slots recycled
    // across sibling scopes compile through the full pipeline and the
    // reused slot carries each branch's own value at run time;
    // shadowing keeps distinct slots for simultaneously live
    // bindings (n_locals is the peak, not the cumulative count).
    let src = "fn pick(c) { if (c) { { let a = 1; a } } else { { let b = 2; b } } } \
               define(r1, pick(true)); \
               define(r2, pick(false)); \
               define(r3, { let x = 1; { let x = 2; x } });";
    let bc = compile_source(src);
    let pick = bc
        .funcs
        .iter()
        .find(|f| f.name.as_ref().is_some_and(|n| n.as_str() == "pick"))
        .expect("pick proto present");
    assert_eq!(
        pick.n_locals, 2,
        "param + ONE recycled let slot (not the cumulative param + 2)"
    );
    let mut vm = Vm::new(bc).expect("verified product loads");
    vm.run().expect("program runs");
    assert_eq!(vm.global("r1"), Some(&Value::Int(1)));
    assert_eq!(vm.global("r2"), Some(&Value::Int(2)));
    assert_eq!(vm.global("r3"), Some(&Value::Int(2)));
}

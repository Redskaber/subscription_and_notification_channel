//! Capture-cost landing guards (Stage 2.2 — the first-cut close-out
//! round; docs/stage0.md §9.82, the ★1' dormant-cost resolution).
//!
//! The Stage 2.1 semantic MUV retired the dormant closure regime
//! (0.5-0.49: every `closure` instruction cloned its defining frame
//! whole and no instruction ever read the copy — the ★1' double
//! cost, stage0.md §9.51). These guards pin the RESOLVED state with
//! deterministic, counter-based proofs — wall-clock timing belongs
//! to the B6 bench axis (release mode, performance-baseline.md):
//!
//! * **Cost axis (O(captured), not O(n_locals))**: the compiled
//!   descriptor table and the runtime closure env agree on exactly
//!   the captured count, whatever the defining frame's width — one
//!   capture out of fifty locals stays one slot (the dormant clone
//!   would have copied all fifty, every creation);
//! * **Retention axis (precise GC roots)**: after the defining
//!   frame dies, an explicit §19.4 cycle sweeps exactly the
//!   non-captured locals — the captured value survives through the
//!   closure cell and the swept counter is the exact N-1 (the
//!   dormant snapshot would have retained all N and swept zero);
//! * **Gate-B absorption**: the bytecode-identity oracle holds on a
//!   capture-dense composite (macro + two-level transitive capture +
//!   tail-if) — the full-pipeline rerun face of the 2.2 close-out
//!   (both engines agree on the halting value too).

use kerf::compiler::{CaptureSource, Opcode};
use kerf::reader::read_target_program;
use kerf::runtime::collect as production_collect;
use kerf::span::FileId;
use kerf::vm::{HeapObj, Value, Vm};

fn compile_source(src: &str) -> kerf::compiler::Bytecode {
    let forms = read_target_program(FileId(0), src).expect("fixture reads");
    let items = kerf::expander::expand_program(&forms).expect("fixture expands");
    kerf::compiler::compile_program(&items).expect("fixture compiles")
}

/// `fn make(p1..pC) { let u1 = 1, .., uK = K; ||(x) { (p1 + .. x) } }` +
///  `define(c, make(1..C));` — C captured params, K dead let locals:
/// the defining frame is C+K slots wide, the capture table C long.
fn width_source(captured: usize, dead_locals: usize) -> String {
    let params = (1..=captured)
        .map(|i| format!("p{i}"))
        .collect::<Vec<_>>()
        .join(", ");
    let mut body = String::from("x");
    for i in (1..=captured).rev() {
        body = format!("(p{i} + {body})");
    }
    let lets = (1..=dead_locals)
        .map(|i| format!("u{i} = {i}"))
        .collect::<Vec<_>>()
        .join(", ");
    let args = (1..=captured)
        .map(|i| i.to_string())
        .collect::<Vec<_>>()
        .join(", ");
    format!("fn make({params}) {{ let {lets}; ||(x) {{ {body} }} }}\ndefine(c, make({args}));")
}

#[test]
fn capture_table_and_env_size_are_the_capture_count_not_the_frame_width() {
    // The ★1' cost axis, structural form: for (C, K) in
    // {(1, 3), (1, 49), (7, 43)} the `make` proto defines a C+K-slot
    // frame, the inner fn's descriptor table carries exactly C
    // entries (all `Local` — first-use order into that frame), and
    // the created closure's env holds exactly C values. The (1, 3)
    // vs (1, 49) pair is the resolution proof: the defining frame
    // grows 4 -> 50 slots while the per-creation copy stays one
    // value (the dormant clone was the whole frame — n_locals
    // values, every time).
    for (captured, dead_locals) in [(1usize, 3usize), (1, 49), (7, 43)] {
        let src = width_source(captured, dead_locals);
        let bc = compile_source(&src);
        let make = bc
            .funcs
            .iter()
            .find(|p| p.n_locals as usize == captured + dead_locals)
            .expect("the make proto (the defining frame) is in the table");
        assert_eq!(
            make.params as usize, captured,
            "make takes the C captured params (C={captured}, K={dead_locals})"
        );
        assert!(
            make.captures.is_empty(),
            "make itself captures nothing (top-level define — C={captured}, K={dead_locals})"
        );
        let inner = bc
            .funcs
            .iter()
            .find(|p| p.captures.len() == captured)
            .expect("the inner fn proto carries the descriptor table");
        assert_eq!(
            inner.captures.len(),
            captured,
            "descriptor count = capture count (C={captured}, K={dead_locals})"
        );
        assert!(
            inner
                .captures
                .iter()
                .all(|s| matches!(s, CaptureSource::Local(_))),
            "the descriptors point into the defining frame (C={captured}, K={dead_locals})"
        );

        let mut vm = Vm::new(bc).expect("verifies");
        vm.run().expect("creates the closure");
        let closure = vm.global("c").expect("the closure lands in `c`");
        let Value::Closure(r) = closure else {
            panic!("`c` holds a closure (C={captured}, K={dead_locals})");
        };
        let env_len = match vm.heap().get(*r) {
            Some(HeapObj::Closure(data)) => data.env.len(),
            other => panic!("closure cell readable, got {other:?}"),
        };
        assert_eq!(
            env_len, captured,
            "env size = capture count, independent of the C+K frame width \
             (C={captured}, K={dead_locals})"
        );
    }
}

#[test]
fn gc_cycle_sweeps_exactly_the_uncaptured_locals() {
    // The ★1' retention axis, deterministic-counter form: `outer`
    // binds eight pair locals, the returned closure captures exactly
    // one (`a`) — after the run halts the only root is the global
    // holding the closure. One explicit §19.4 cycle must mark the
    // closure cell plus its single captured pair (marked == 2) and
    // sweep exactly the other seven (swept == 7, live 9 -> 2). Under
    // the dormant snapshot the env held all eight pairs and the same
    // cycle swept zero — the counter is the resolution proof.
    let src = "fn outer(x) { let a = pair(1, nil), b = pair(2, nil), \
               c = pair(3, nil), d = pair(4, nil), e = pair(5, nil), \
               f = pair(6, nil), g = pair(7, nil), h = pair(8, nil); \
               ||(y) { first(a) } }\ndefine(keeper, outer(0));";
    let bc = compile_source(src);
    let make = bc
        .funcs
        .iter()
        .find(|p| !p.captures.is_empty())
        .expect("the inner fn captures");
    assert_eq!(
        make.captures.len(),
        1,
        "K45 minimality: only `a` is captured, not the whole frame"
    );
    let mut vm = Vm::new(bc).expect("verifies");
    vm.run().expect("outer returns the closure");
    let closure_ref = match vm.global("keeper") {
        Some(Value::Closure(r)) => *r,
        other => panic!("keeper holds a closure, got {other:?}"),
    };

    // The explicit host cycle (the §19.4 standalone face): roots are
    // the globals — `outer`'s own closure cell (the top-level define)
    // plus `keeper`'s captured closure and its single pair.
    let roots = vm.snapshot_roots();
    let stats = production_collect(vm.heap_mut(), &roots);
    assert_eq!(
        stats.live_before, 10,
        "eight pairs + the outer closure cell + the captured closure cell"
    );
    assert_eq!(
        stats.marked, 3,
        "outer's closure + keeper's closure + its one captured pair"
    );
    assert_eq!(stats.swept, 7, "exactly the seven uncaptured pairs");
    assert_eq!(
        stats.live_after, 3,
        "the two closures + the captured pair survive"
    );

    // The survivor is the captured pair and it stays functional
    // through the cell: env[0] is pair (1 . nil).
    let held = match vm.heap().get(closure_ref) {
        Some(HeapObj::Closure(data)) => data.env.first().cloned(),
        other => panic!("closure cell survives the cycle, got {other:?}"),
    };
    match held {
        Some(Value::Pair(pr)) => match vm.heap().get(pr) {
            Some(HeapObj::Pair(car, _)) => {
                assert_eq!(car.to_string(), "1", "the captured pair is `a`");
            }
            other => panic!("captured pair cell survives, got {other:?}"),
        },
        other => panic!("env[0] is the captured pair, got {other:?}"),
    }
}

#[test]
fn gate_b_holds_on_a_capture_dense_composite() {
    // The 2.2 full-pipeline rerun anchor: one composite exercising
    // the macro face (`wrap`), a two-level transitive capture chain
    // (outer -> mid closure -> inner closure re-capturing through the
    // pass-through table), and a tail-if — the oracle items and the
    // .krf expander's rebuilt items must compile to identical
    // bytecode, descriptor tables included (the `Bytecode`
    // `PartialEq` absorption, constructively exercised on a
    // capture-bearing product), and both engines agree on 10.
    use kerf::driver::gate_b_bytecode;
    let src = "macro wrap { (syntax_rules, nil, ((_, v), (pair, v, nil))) } \
               fn outer(n) { ||(y) { ||(z) { (z + (y + n)) } } } \
               define(r, { let adder = (outer(5))(3); \
               if ((1 < 2)) { first(wrap(adder(2))) } else { 99 } });";
    gate_b_bytecode("capture-composite", src).expect("gate B holds on the capture-dense composite");

    // The value face: 2 + 3 + 5 = 10 on both engines (the parity
    // harness drives them side by side).
    let directive = format!("// expect: value 10\n{src}");
    let case = kerf::driver::CorpusCase::from_source("composite.ktf", &directive)
        .expect("directive parses");
    let report = kerf::driver::validate(&case);
    assert!(
        report.matched,
        "both engines halt at 10: {} (observed {:?})",
        report.drift.as_deref().unwrap_or("no drift note"),
        report.observed
    );

    // And the product really is capture-bearing: the innermost proto
    // re-captures through the pass-through table (a `Captured(k)`
    // source — the LA-4 chain), not just direct `Local` slots.
    let bc = compile_source(src);
    let pass_through = bc.funcs.iter().any(|p| {
        p.captures
            .iter()
            .any(|s| matches!(s, kerf::compiler::CaptureSource::Captured(_)))
    });
    assert!(
        pass_through,
        "the composite exercises the transitive (Captured) source"
    );
    let load_captured = bc
        .funcs
        .iter()
        .any(|p| p.code.iter().any(|i| i.op == Opcode::LoadCaptured));
    assert!(load_captured, "the composite reads through load-captured");
}

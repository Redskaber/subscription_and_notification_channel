//! Compile segment switch tests (T-a step-④ blade 4 —
//! w-t-a-switch-window §3 r148+ row): the COMPILE segment's
//! production position switch — the window's LAST segment. The
//! `.ktf` production compilation rides the steady compiler twin
//! chain on the VM (the default); the Rust compiler retires to the
//! oracle face (the parity comparison arm, the seed chain's own
//! compilation, and the rollback band — `KERF_COMPILE_SEGMENT=rust`).
//!
//! Four faces, per the corpus discipline (GATE 6 composition):
//!
//! * **Positive** — the production position's artifacts are
//!   BYTE-IDENTICAL to the oracle compilation's (the `Bytecode:
//!   PartialEq` full-descriptor gate — protos, captures,
//!   instruction streams, debug spans with their generations, the
//!   interned globals, the constant pool, the externs table) across
//!   the curated family and the selfhost fixed points, on the
//!   DEFAULT stack.
//! * **Negative** — the rejection family: the compile-depth budget
//!   rejects with the SAME KEY on both positions under the
//!   `KERF_COMPILE_DEPTH_LIMIT` override (the `co_limit` budget
//!   mirror — the payload carries the first-exceeding depth AND the
//!   limit in force, so the rendered rejection is self-describing
//!   on both arms), and the rendered batches are identical.
//! * **Rollback band** — the position selector's three states
//!   (default twin, explicit rust, invalid fail-closed) and the two
//!   positions' agreement on the corpus.
//! * **Cross-stage consumption** — the production-position compile
//!   feeds the whole spine (run/check/emit-c/parity): the compiled
//!   bytecode equals the Rust-position bytecode, the run values and
//!   global tables agree, and the CLI faces ride the twin compiler
//!   end to end.
//!
//! The K163 fifth-instance pin (the compile half of the r147
//! fourth-instance family): BOTH rebuild faces derive spans with
//! the parity harnesses' `FileId(0)` convention — the production
//! position retargets the rejection spans AND every rebuilt
//! product debug span to the session's file (the generations ride
//! untouched), pinned below at a NON-zero file id.
//!
//! The K163 sixth-instance pin (the r148 finding, the items-stream
//! delivery chain): a deep FLAT quoted list — a right spine as
//! long as the list — compiles on BOTH positions on the DEFAULT
//! stack (the encoder, the injection dispose, and the verdict-text
//! litval walks all ride the r148 iterative forms; the oracle chain
//! already walked the same input, so the twin chain must too).

use kerf::compiler::COMPILE_DEPTH_LIMIT;
use kerf::driver::{
    CompileSegment, DepthLimits, ExpandSegment, ParsedProgram, ReadSegment, Session,
    TARGET_PARSER_TWIN_CASES, parse_target, render_diagnostics, run_cli,
};
use kerf::span::FileId;

use crate::steady_target_reader_tests::SELFHOST_SOURCES;

// ---------- the shared comparison faces ----------

/// Both positions' compilation of one source: parse through each
/// position's session (the shared spine — both positions already
/// ride the switched read/expand/check segments, the r145/r146/r147
/// switches; THIS family isolates the compile segment), compile
/// through `compile_bytecode`, compare the FULL descriptor
/// (`Bytecode: PartialEq` — the gate-B caliber).
fn assert_compile_positions_agree(name: &str, source: &str) -> bool {
    // The twin position: the default session (all four segments
    // switched).
    let mut twin_session = Session::new();
    let twin_program = match parse_target(&mut twin_session, name, source) {
        Ok(program) => program,
        // Read/expand/check rejections are NOT this family's subject
        // (the r145/r146/r147 families own them) — skip them.
        Err(_) => return false,
    };
    assert_eq!(twin_program.compile_segment, CompileSegment::Twin);
    let twin_bc = twin_program
        .compile_bytecode()
        .unwrap_or_else(|d| panic!("the twin position must compile {name}: {d:?}"));

    // The rust position: the compile segment pinned back (the
    // rollback band's own arm).
    let mut rust_session = Session::new();
    rust_session.set_compile_segment(CompileSegment::Rust);
    let rust_program = match parse_target(&mut rust_session, name, source) {
        Ok(program) => program,
        Err(_) => return false,
    };
    let rust_bc = rust_program
        .compile_bytecode()
        .unwrap_or_else(|d| panic!("the rust position must compile {name}: {d:?}"));

    assert_eq!(
        twin_bc, rust_bc,
        "the twin and oracle artifacts must be byte-identical (full descriptor) on {name}"
    );
    // Both products pass the VM's own verify floor (the compile
    // faces re-verify; the twin arm's rebuild already ran it — the
    // assertion keeps the caliber explicit for the oracle arm).
    assert!(
        twin_bc.verify().is_ok(),
        "the twin product must verify on {name}"
    );
    true
}

// ---------- positive: the production position holds the corpus ----------

/// The curated target family (both polarities): every case whose
/// read AND expansion succeed compiles byte-identically on both
/// positions — the default flip's own sweep.
#[test]
fn the_curated_family_compiles_identically_on_both_positions() {
    let mut exercised = 0;
    for &(name, source) in TARGET_PARSER_TWIN_CASES {
        if assert_compile_positions_agree(name, source) {
            exercised += 1;
        }
    }
    // The corpus's parse-clean subset (the read/expand rejections are
    // the r145/r146 families' own subjects): the positive family plus
    // the boundary cases that still read cleanly.
    assert!(
        exercised >= 20,
        "the sweep must exercise the corpus (only {exercised} cases reached the compile step)"
    );
}

/// The nine selfhost sources + the compiler twin's own CCF — the
/// deepest fixed points (the language compiling its own twins,
/// including the COMPILER compiling the compiler's chain-compilable
/// form — the fixpoint's own shape), on the DEFAULT stack: the twin
/// runs on the VM's heap activation records (the r136 G2 base), and
/// every host-side walk on the product rides the iterative forms
/// (the r148 K163 sixth-instance clearance — the section/record
/// walks, the litval rebuild, and the verdict-text dumps).
#[test]
fn the_selfhost_fixed_points_compile_on_a_default_stack() {
    let mut sources: Vec<(&str, &str)> = SELFHOST_SOURCES.to_vec();
    let compiler_ccf = kerf::driver::ccf_compiler_source();
    sources.push(("ccf-compiler.ktf", compiler_ccf.as_str()));
    let mut exercised = 0;
    let mut ccf_exercised = false;
    for (name, source) in &sources {
        if assert_compile_positions_agree(name, source) {
            exercised += 1;
            if *name == "ccf-compiler.ktf" {
                ccf_exercised = true;
            }
        }
    }
    // The sources whose read/expand reject (the free-slot references
    // — the known bare-twin boundary, TA-1) skip; the COMPILER'S OWN
    // CCF is the closed form and MUST exercise the compile step (the
    // deepest fixed point this segment owns).
    assert!(
        ccf_exercised,
        "the compiler twin's own CCF must reach the compile step (the fixed point)"
    );
    assert!(
        exercised >= 2,
        "the fixed-point sweep must exercise the closed twin forms (only {exercised} reached \
         the compile step)"
    );
}

// ---------- negative: the rejection family ----------

/// A source-nested tree over a TINY compile-depth budget: both
/// positions reject with the SAME KEY — the first-exceeding depth
/// AND the limit in force ride the payload (the `co_limit` budget
/// mirror — the twin's assembly carries the process's effective
/// `KERF_COMPILE_DEPTH_LIMIT`, so an over-depth tree rejects on both
/// arms at the same node), and the rendered batches are identical.
#[test]
fn the_budget_mirror_rejects_with_the_same_key_on_both_positions() {
    // Six nested let bindings — comfortably over a budget of 3.
    let source = "fn deep(x) { let a = x; let b = a; let c = b; let d = c; let e = d; let f = e; \
                  f }\nfn main() { deep(1) }\n";
    let limits = DepthLimits {
        compile_depth: 3,
        ..DepthLimits::default()
    };

    let mut twin_session = Session::with_limits(limits);
    let twin_program =
        parse_target(&mut twin_session, "budget.ktf", source).expect("the twin position parses");
    let twin_err = twin_program
        .compile_bytecode()
        .expect_err("the twin position must reject the over-depth tree");

    let mut rust_session = Session::with_limits(limits);
    rust_session.set_compile_segment(CompileSegment::Rust);
    let rust_program =
        parse_target(&mut rust_session, "budget.ktf", source).expect("the rust position parses");
    let rust_err = rust_program
        .compile_bytecode()
        .expect_err("the rust position must reject the over-depth tree");

    assert_eq!(twin_err.len(), 1, "one finding per position: {twin_err:?}");
    assert_eq!(rust_err.len(), 1, "one finding per position: {rust_err:?}");
    // The rendered batches are identical (the user-facing face) —
    // message, severity, and the retargeted span all agree.
    assert_eq!(
        render_diagnostics(&twin_session, &twin_err),
        render_diagnostics(&twin_session, &rust_err),
        "the budget rejection must render identically on both positions"
    );
    let twin_text = format!("{}: {}", twin_err[0].severity, twin_err[0].message);
    assert!(
        twin_text.contains("compile depth"),
        "the rejection names its family: {twin_text}"
    );
}

/// The self-describing payload: under an override, the rendered
/// rejection names the OVERRIDDEN limit (never the stale default) —
/// the `DepthExceeded` limit field's own face, pinned through the
/// public error shape on both arms of the band.
#[test]
fn the_depth_rejection_names_the_overridden_limit() {
    let source = "fn deep(x) { let a = x; let b = a; let c = b; a }\nfn main() { deep(1) }\n";
    let limits = DepthLimits {
        compile_depth: 2,
        ..DepthLimits::default()
    };
    let mut session = Session::with_limits(limits);
    let program = parse_target(&mut session, "override.ktf", source).expect("the program parses");
    let diags = program
        .compile_bytecode()
        .expect_err("the over-depth tree must reject");
    let message = diags[0].message.clone();
    assert!(
        message.contains("exceeds limit `2`"),
        "the rejection must name the overridden limit (self-describing payload): {message}"
    );
    assert!(
        !message.contains(&format!("exceeds limit `{COMPILE_DEPTH_LIMIT}`")),
        "the stale default limit must not render under an override: {message}"
    );
}

// ---------- rollback band ----------

/// The selector's three states: the default rides the twins, the
/// explicit `rust` selects the rollback, and any other spelling is
/// a HARD error (fail-closed — a silently ignored override would be
/// a lie); the parsed positions flow through the session into the
/// parsed program's disclosure fields.
#[test]
fn the_rollback_band_three_states() {
    assert_eq!(
        CompileSegment::parse_value("twin"),
        Ok(CompileSegment::Twin)
    );
    assert_eq!(
        CompileSegment::parse_value("rust"),
        Ok(CompileSegment::Rust)
    );
    // Surrounding whitespace is tolerated (a trailing newline from a
    // shell export must not become a hard failure).
    assert_eq!(
        CompileSegment::parse_value(" rust "),
        Ok(CompileSegment::Rust)
    );
    for bad in ["", "twins", "TWIN", "c", "0", "oracle"] {
        assert!(
            CompileSegment::parse_value(bad).is_err(),
            "`{bad}` must not parse as a compile segment"
        );
    }

    // The session selection flows into the program's disclosure.
    let source = "fn main() { 40 + 2 }\n";
    let mut twin_session = Session::new();
    let twin_program = parse_target(&mut twin_session, "band.ktf", source)
        .unwrap_or_else(|d| panic!("the twin position must parse: {d:?}"));
    assert_eq!(twin_program.compile_segment, CompileSegment::Twin);

    let mut rust_session = Session::new();
    rust_session.set_compile_segment(CompileSegment::Rust);
    let rust_program = parse_target(&mut rust_session, "band.ktf", source)
        .unwrap_or_else(|d| panic!("the rust position must parse: {d:?}"));
    assert_eq!(rust_program.compile_segment, CompileSegment::Rust);

    // The two positions agree on the artifact (the band is a real
    // rollback, never a behavior fork).
    let twin_bc = twin_program.compile_bytecode().expect("the twin compiles");
    let rust_bc = rust_program.compile_bytecode().expect("the rust compiles");
    assert_eq!(twin_bc, rust_bc, "the rollback band must not fork behavior");
}

// ---------- cross-stage consumption ----------

/// The production-position compile feeds every consuming face: the
/// `run` VM arm's value, outputs, and global table; the `check`
/// face's product counts; the `emit-c` face's transpiled text; and
/// the parity report — all identical between the two positions.
#[test]
fn the_production_position_feeds_the_whole_spine() {
    let source = "fn add(a, b) { a + b }\nfn main() { add(1, 2) }\n";

    let mut twin_session = Session::new();
    let twin_program =
        parse_target(&mut twin_session, "spine.ktf", source).expect("the twin position parses");
    let mut rust_session = Session::new();
    rust_session.set_compile_segment(CompileSegment::Rust);
    let rust_program =
        parse_target(&mut rust_session, "spine.ktf", source).expect("the rust position parses");

    // run (VM arm): value + outputs + globals.
    let twin_run = twin_program
        .run(
            kerf::driver::Engine::Vm,
            Box::new(kerf::vm::BufferIo::default()),
        )
        .expect("the twin run");
    let rust_run = rust_program
        .run(
            kerf::driver::Engine::Vm,
            Box::new(kerf::vm::BufferIo::default()),
        )
        .expect("the rust run");
    assert_eq!(twin_run.value, rust_run.value, "the run values agree");
    assert_eq!(twin_run.outputs, rust_run.outputs, "the run outputs agree");
    assert_eq!(
        twin_run.globals, rust_run.globals,
        "the run global tables agree"
    );

    // check: the product counts.
    let twin_check = twin_program.check().expect("the twin check");
    let rust_check = rust_program.check().expect("the rust check");
    assert_eq!(twin_check.func_count, rust_check.func_count);
    assert_eq!(twin_check.instr_count, rust_check.instr_count);
    assert_eq!(twin_check.const_count, rust_check.const_count);
    assert_eq!(twin_check.global_count, rust_check.global_count);

    // emit-c: the transpiled text (the chain-external backend rides
    // the same artifact).
    let twin_c = twin_program.c_source().expect("the twin emit-c");
    let rust_c = rust_program.c_source().expect("the rust emit-c");
    assert_eq!(twin_c.c_source, rust_c.c_source, "the C products agree");
}

/// The CLI faces ride the twin compiler end to end: the `run` face
/// executes the twin-compiled artifact on the VM, and a
/// compile-rejected program renders the same batch the Rust
/// position's own CLI invocation would (the rollback band's
/// user-facing parity).
#[test]
fn the_cli_faces_ride_the_twin_compiler() {
    // The run face (the input-tape iterator closed — the batch form).
    let clean = "fn main() { 40 + 2 }\n";
    let mut out = Vec::new();
    let mut err = Vec::new();
    let code = run_cli(
        &["run".to_string(), "main.ktf".to_string()],
        &|_| Ok(clean.to_string()),
        &mut || None,
        Vec::new(),
        &mut out,
        &mut err,
    );
    assert_eq!(code, 0, "the clean program must run green: {err:?}");

    // The check face: a compile-rejected program through the CLI
    // (the default twin position) renders exactly the batch the Rust
    // position produces for the same source. The source-reachable
    // rejection is the extern DUPLICATE (the compile family's own
    // face — no env mutation needed; the r147 CLI family's form: the
    // rollback arm computed through the library face).
    let duplicate = "extern \"C\" { fn dup() -> int; }\nextern \"C\" { fn dup() -> int; }\nfn \
                     main() { dup() }\n";
    let mut out = Vec::new();
    let mut err = Vec::new();
    let code = run_cli(
        &["check".to_string(), "dup.ktf".to_string()],
        &|_| Ok(duplicate.to_string()),
        &mut || None,
        Vec::new(),
        &mut out,
        &mut err,
    );
    assert_eq!(code, 1, "the duplicate-extern program must fail: {err:?}");
    let cli_text = String::from_utf8_lossy(&err).into_owned();

    // The Rust position's own rendering of the same source (the
    // library face — the rollback arm's diagnostic batch).
    let mut rust_session = Session::new();
    rust_session.set_compile_segment(CompileSegment::Rust);
    let rust_program = parse_target(&mut rust_session, "dup.ktf", duplicate)
        .expect("the duplicate-extern program parses");
    let rust_diags = rust_program
        .check()
        .expect_err("the duplicate-extern program fails the check");
    let oracle_text = render_diagnostics(&rust_session, &rust_diags);
    assert_eq!(
        cli_text.trim(),
        oracle_text.trim(),
        "the CLI rejection batch must equal the rust position's rendering"
    );
}

/// The seed faces pin the Rust compiler (the step-④ dual-chain
/// decoupling): the injection front end and the A/B/C A pass carry
/// `CompileSegment::Rust` — a twin-position compile there would be
/// circular (the twin chain's own construction rides those entries),
/// and the comparisons would collapse into self-comparisons. The
/// machine check: the pinned sources keep their four-argument
/// `with_segments` pin, and the injection front end's products
/// disclose the Rust position.
#[test]
fn the_seed_faces_stay_pinned_to_the_rust_compiler() {
    // The source-scan guards (the r147 form, extended to the compile
    // pin): the seed constructors keep every segment's Rust pin.
    let manifest = env!("CARGO_MANIFEST_DIR");
    let faces: &[(&[&str], &str)] = &[
        (
            &["with_segments", "CompileSegment::Rust", "rust_compile_ccf"],
            "crates/kerf-driver/src/bootstrap/abc_pipeline.rs",
        ),
        (
            &["with_segments", "CompileSegment::Rust"],
            "crates/kerf-driver/src/bootstrap/target_corpus.rs",
        ),
        (
            &["parse_target_with_injected", "compile_program"],
            "crates/kerf-driver/src/bootstrap/steady_compiler_chain.rs",
        ),
    ];
    for (anchors, path) in faces {
        let window = std::fs::read_to_string(format!("{manifest}/{path}"))
            .unwrap_or_else(|e| panic!("{path} must read: {e}"));
        for anchor in *anchors {
            assert!(
                window.contains(anchor),
                "{path} must keep the seed pin (missing `{anchor}` — the twin chain's own \
                 construction would be circular without it; see the step-④ dual-chain \
                 decoupling)"
            );
        }
    }

    // The behavioral face: the injection front end's program
    // discloses the Rust compile position, and compiling it rides
    // the oracle (never the switched arm).
    let source = kerf::driver::ccf_compiler_source();
    let mut session = Session::new();
    let injected = [kerf::span::Symbol::new("items").expect("a valid name")];
    let program = kerf::driver::parse_target_with_injected(
        &mut session,
        "ccf-compiler.ktf",
        &source,
        &injected,
    )
    .expect("the CCF form parses through the seed face");
    assert_eq!(
        program.compile_segment,
        CompileSegment::Rust,
        "the injection front end's products must disclose the Rust compile pin"
    );
    let bc = program
        .compile_bytecode()
        .expect("the pinned seed compiles through the oracle");
    assert!(
        !bc.funcs.is_empty(),
        "the compiler CCF compiles to a product"
    );

    // The wiring-defect face: an injected program that somehow
    // arrives at the twin arm fails LOUDLY (never a silent oracle
    // side-step) — exercised by direct construction, the r147 form.
    let program = ParsedProgram {
        file: FileId(0),
        items: Vec::new(),
        injected: vec![kerf::span::Symbol::new("slot").expect("a valid name")],
        limits: DepthLimits::default(),
        read_segment: ReadSegment::Twin,
        expand_segment: ExpandSegment::Twin,
        compile_segment: CompileSegment::Twin,
        // The check pin is irrelevant here; the r147 fixture's shape.
        check_segment: kerf::driver::CheckSegment::Rust,
    };
    let diags = program
        .compile_bytecode()
        .expect_err("the wiring defect must fail");
    assert!(
        diags.iter().any(|d| d
            .message
            .contains("the seed faces must pin the Rust compile segment")),
        "the injected-on-twin-arm wiring defect must fail loudly: {diags:?}"
    );
}

// The r151 retirement record (W-SEXP-RETIRE blade 2): the S-expr
// seed-compiler spot-check (`the_sexpr_seed_face_is_untouched` — a
// `parse`-driven oracle-arm pin over `(define result (+ 40 2))`)
// retired with its subject: the S-expression read API no longer
// exists, so the `.krf` seed face cannot reach the compile segment
// at all. The oracle arm itself stays pinned by the rollback-band
// and injected-faces tests above (the explicit `CompileSegment::Rust`
// positions on target-skin sources, bytecode identical to the twin
// position's).

// ---------- the K163 pins ----------

/// The fifth instance's compile half: BOTH rebuild faces derive
/// spans with the parity harnesses' `FileId(0)` convention — the
/// production position retargets the rebuilt product's debug spans
/// (and the rejection spans) to the SESSION's file, at a NON-zero
/// id: every debug span names the program's own file, and the true
/// macro generations ride untouched.
#[test]
fn the_rebuilt_product_names_the_session_file() {
    // Intern a first file so the program's file id is NON-zero (the
    // zero-id domain is where the r145-r147 sweeps validated — the
    // retarget's blind spot until the r147/r148 clearances).
    let mut session = Session::new();
    let _ = session.intern("first.ktf", "fn unused() { 0 }\n");
    let source = "fn pick(p) { match p { 1 => { 10 }, _ => { 20 }, } }\nfn main() { pick(1) }\n";
    let program = parse_target(&mut session, "second.ktf", source).expect("the program parses");
    assert_eq!(
        program.file,
        FileId(1),
        "the fixture must intern at a non-zero id"
    );

    let bc = program
        .compile_bytecode()
        .expect("the twin position compiles");
    assert!(
        !bc.funcs.is_empty() && bc.funcs.iter().all(|f| !f.debug_info.is_empty()),
        "the fixture's protos carry debug spans"
    );
    for proto in &bc.funcs {
        for span in &proto.debug_info {
            assert_eq!(
                span.file_id,
                FileId(1),
                "every rebuilt debug span must name the session's file (the K163 fifth \
                 instance's compile half)"
            );
        }
    }

    // The rejection face rides the same retarget: an over-budget
    // tree's rendered rejection carries the session's file id.
    let limits = DepthLimits {
        compile_depth: 3,
        ..DepthLimits::default()
    };
    let mut deep_session = Session::with_limits(limits);
    let _ = deep_session.intern("first.ktf", "fn unused() { 0 }\n");
    let deep = "fn deep(x) { let a = x; let b = a; let c = b; let d = c; d }\nfn main() { \
                deep(1) }\n";
    let deep_program =
        parse_target(&mut deep_session, "second.ktf", deep).expect("the deep program parses");
    let diags = deep_program
        .compile_bytecode()
        .expect_err("the over-budget tree rejects");
    let span = diags[0]
        .primary_span
        .expect("the depth rejection carries a span");
    assert_eq!(
        span.file_id,
        FileId(1),
        "the rejection names the session's file"
    );
}

/// The sixth instance's pin (the r148 finding): a deep FLAT quoted
/// list — a right spine as long as the list — compiles on BOTH
/// positions on the DEFAULT stack. The oracle chain always walked
/// this input; the twin chain's delivery faces (the stream encoder,
/// the injection dispose, the verdict-text litval dump) ride the
/// r148 iterative forms, and the regression pin keeps any future
/// recursive reintroduction loud.
#[test]
fn the_stack_flat_regression_on_a_deep_flat_quote() {
    // The thread carries the PRODUCTION main-thread stack budget
    // (8MiB) explicitly: the libtest worker threads default to a
    // smaller stack, and the pin's caliber is the CLI process's own
    // budget (the sibling families' `deep_stack` demand-allocation
    // form, scaled to production). The HONEST shared boundary (both
    // arms equally, the oracle chain included): the AST literal's
    // own Box-drop glue stays one small frame per spine cell —
    // ~150k elements measured green in production; deeper trees
    // need the W-REC-DEPTH window's heap-drop follow-up (C3's
    // guardrail domain, registered in the window doc).
    std::thread::Builder::new()
        .stack_size(8 * 1024 * 1024)
        .spawn(the_stack_flat_regression_body)
        .expect("spawn the production-budget thread")
        .join()
        .expect("the production-budget thread finished cleanly");
}

fn the_stack_flat_regression_body() {
    // ~60k elements — the probe depth that overflowed the DEFAULT
    // stack before the clearance (the recursive encoder's frames ran
    // ~300 bytes deep per element; the pre-clearance form needed
    // ~18MiB for this workload — far over the budget above).
    let mut source = String::with_capacity(200_000);
    source.push_str("define(data, quote((");
    for i in 0..60_000 {
        if i > 0 {
            source.push_str(", ");
        }
        source.push_str(&format!("{}", i % 10));
    }
    source.push_str(")));\nfn main() { 0 }\n");

    // Both positions, within the production stack budget.
    let mut twin_session = Session::new();
    let twin_program = parse_target(&mut twin_session, "flat.ktf", &source)
        .expect("the twin position reads the flat quote");
    let twin_bc = twin_program
        .compile_bytecode()
        .expect("the twin position compiles the flat quote within the budget");

    let mut rust_session = Session::new();
    rust_session.set_compile_segment(CompileSegment::Rust);
    let rust_program = parse_target(&mut rust_session, "flat.ktf", &source)
        .expect("the rust position reads the flat quote");
    let rust_bc = rust_program
        .compile_bytecode()
        .expect("the rust position compiles the flat quote");
    assert_eq!(
        twin_bc, rust_bc,
        "the flat quote's artifacts agree across the positions"
    );
}

// ---------- the diagnostics batch discipline ----------

/// A `Diagnostic`-level sanity face shared with the sibling
/// families: the compile segment's driver errors (a harness defect)
/// render loudly with the driver-error shape — never a silent
/// fallback. Exercised through the wiring-defect construction above
/// and the budget rejections; this test keeps the batch's shape
/// contract pinned independently.
#[test]
fn compile_batch_diagnostics_carry_the_compile_stage_code() {
    let mut session = Session::new();
    let program =
        parse_target(&mut session, "clean.ktf", "fn main() { 40 + 2 }\n").expect("parses");
    let diags = program.typecheck();
    assert!(
        diags
            .iter()
            .all(|d| d.severity != kerf::driver::Severity::Error),
        "the clean program carries no error findings: {diags:?}"
    );
    let outcome = program.check().expect("the clean program checks");
    assert!(
        outcome.func_count >= 1,
        "the product has at least the entry proto"
    );
    assert!(outcome.instr_count >= 1, "the product has instructions");
}

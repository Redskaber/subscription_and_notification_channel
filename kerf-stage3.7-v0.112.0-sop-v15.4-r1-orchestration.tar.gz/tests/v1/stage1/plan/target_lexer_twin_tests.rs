//! Target-lexer twin tests (W-TGT-READ-TWIN blade 1 — gap G1 of
//! bootstrap-completion-plan.md §4.2): the target skin's own lexical
//! layer, `selfhost/v1/target-lexer.ktf`, against the Rust target
//! lexer oracle (`kerf_reader::lex_target`) through the full `.ktf`
//! chain on BOTH engines — the eighth selfhost twin, the first that
//! mirrors the TARGET read chain instead of the S-expr one (the
//! language reading its own `.ktf` sources).
//!
//! Mounted via `tests/runner.rs` (SOP §8.4.6 root-tree discipline).
//! Three layers, per the corpus discipline:
//!
//! * **Positive** — the curated case family (every word face, every
//!   operator with its maximal-munch boundaries, the literal
//!   families with their grammar boundaries, the comment families
//!   with nesting) plus the SELFHOST FIXED POINTS: the post-
//!   retirement `selfhost/v1/*.ktf` family (six sources — the S-expr
//!   lexer/reader twins retired with the W-SEXP-RETIRE blade 2)
//!   through the twin — including the twin's OWN source (the
//!   self-application face: the target skin lexing its own lexer).
//! * **Negative** — the rejection family, each case asserting the
//!   three-way agreement on the SAME error key (kind and payload:
//!   the unterminated/invalid-escape faces, the unclosed nested
//!   comment, the unexpected-char family including non-ASCII and
//!   the BOM, the malformed-number and int/float out-of-range
//!   faces — the float face rides the K20 host value derivation).
//! * **Cross-stage consumption** — the twin's token stream for a
//!   selfhost source feeds forward structurally (the token count
//!   equals the oracle's), and the twin's own source lexes its own
//!   `fn` heads (the `kw-fn` face).

use kerf::driver::{
    COMPILER_TARGET_SOURCE, EXPANDER_TARGET_SOURCE, INFER_TARGET_SOURCE, MACRO_TARGET_SOURCE,
    TARGET_LEXER_TARGET_SOURCE, TARGET_LEXER_TWIN_CASES, TYPECHECK_TARGET_SOURCE,
    target_lexer_parity, target_lexer_twin_dump, target_oracle_token_dump,
};

const FILE: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/selfhost/v1");

/// The selfhost fixed-point family: the six `.ktf` twins through
/// the parity driver (the sources walk the harness Rust walkers and
/// both engines' per-token frames — the sibling tests'
/// demand-allocated stack discipline).
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly")
}

// ---------- positive: the curated case family ----------

#[test]
fn curated_cases_hold_three_way_parity() {
    deep_stack(|| {
        for (name, source) in TARGET_LEXER_TWIN_CASES {
            target_lexer_parity(name, source).unwrap_or_else(|e| panic!("{e}"));
        }
    });
}

// ---------- positive: the selfhost fixed points ----------

#[test]
fn selfhost_sources_hold_three_way_parity() {
    deep_stack(|| {
        // The six selfhost twins — the five chain twins plus the
        // target-lexer twin ITSELF (the self-application face).
        let sources = [
            ("macro.ktf", MACRO_TARGET_SOURCE),
            ("expander.ktf", EXPANDER_TARGET_SOURCE),
            ("compiler.ktf", COMPILER_TARGET_SOURCE),
            ("infer.ktf", INFER_TARGET_SOURCE),
            ("typecheck.ktf", TYPECHECK_TARGET_SOURCE),
            ("target-lexer.ktf", TARGET_LEXER_TARGET_SOURCE),
        ];
        for (name, source) in &sources {
            target_lexer_parity(name, source).unwrap_or_else(|e| panic!("{e}"));
        }
    });
}

/// The selfhost family read from DISK (the tree-asset face — the
/// `include_str!` embeddings above and the files on disk must agree,
/// and the disk read exercises the same face the corpus sweeps use).
#[test]
fn selfhost_disk_sources_hold_three_way_parity() {
    deep_stack(|| {
        for name in [
            "macro.ktf",
            "expander.ktf",
            "compiler.ktf",
            "infer.ktf",
            "typecheck.ktf",
            "target-lexer.ktf",
        ] {
            let path = format!("{FILE}/{name}");
            let source = std::fs::read_to_string(&path)
                .unwrap_or_else(|e| panic!("the selfhost twin {name} must read from disk: {e}"));
            target_lexer_parity(name, &source).unwrap_or_else(|e| panic!("{e}"));
        }
    });
}

// ---------- negative: the rejection family ----------

/// The curated negative cases ride the SAME three-way driver (their
/// agreement is on the error KEY — kind and payload); this test
/// additionally pins the exact key faces for the anchor rejections
/// so a drift in the error rendering itself cannot hide behind an
/// agreeing-but-wrong pair.
#[test]
fn rejection_family_agrees_on_the_same_error_key() {
    deep_stack(|| {
        let negative: Vec<(&str, &str)> = TARGET_LEXER_TWIN_CASES
            .iter()
            .filter(|(name, _)| name.starts_with("neg-"))
            .copied()
            .collect();
        assert!(
            negative.len() >= 12,
            "the rejection family must stay curated (found {})",
            negative.len()
        );
        for (name, source) in &negative {
            target_lexer_parity(name, source).unwrap_or_else(|e| panic!("{e}"));
        }
    });
}

#[test]
fn anchor_rejections_render_the_oracle_keys() {
    deep_stack(|| {
        // The anchor faces: the exact parity keys (the oracle's own
        // Display plus the harness `@ byte` suffix), one per family.
        let anchors: &[(&str, &str, &str)] = &[
            (
                "unterminated string",
                "\"abc",
                "ERR unterminated string literal @ byte 0",
            ),
            (
                "invalid escape",
                "\"a\\q\"",
                "ERR invalid string escape `q` @ byte 2",
            ),
            (
                "u escape without braces",
                "\"\\u41\"",
                "ERR invalid string escape `u` @ byte 1",
            ),
            (
                "unclosed nested comment",
                "/* /* x",
                "ERR unclosed delimiter: `/*` is never closed @ byte 0",
            ),
            (
                "unexpected dollar",
                "let x = $;",
                "ERR unexpected character `$` @ byte 8",
            ),
            ("malformed hex", "0x", "ERR malformed number literal `0x`"),
            (
                "int out of range",
                "99999999999999999999",
                "ERR integer literal `99999999999999999999` out of range for `i64`",
            ),
            (
                "float out of range",
                "1.0e999",
                "ERR float literal `1.0e999` out of range for `f64`",
            ),
        ];
        for (what, source, want) in anchors {
            let oracle = match target_oracle_token_dump(source) {
                Ok(dump) => format!("OK {dump}"),
                Err(err) => format!("ERR {}", kerf::driver::error_parity_key(&err)),
            };
            assert_eq!(&oracle, want, "the oracle face of: {what}");
            let (vm_dump, eval_dump) = target_lexer_twin_dump(source)
                .unwrap_or_else(|e| panic!("the twin drive of `{what}` failed: {e}"));
            assert_eq!(&vm_dump, want, "the twin vm face of: {what}");
            assert_eq!(&eval_dump, want, "the twin eval face of: {what}");
        }
    });
}

// ---------- cross-stage consumption ----------

/// The twin's token stream FEEDS FORWARD structurally: the twin-lexed
/// token count of `selfhost/v1/target-lexer.ktf` (the twin's own
/// source, the blade-2 successor of the retired S-expr lexer twin)
/// equals the oracle's own token count (the chain's junction-1
/// contract in miniature — the downstream segments consume COUNTS of
/// records, so a count drift is a structural break before any payload
/// question).
#[test]
fn twin_token_count_matches_the_oracle_for_the_lexer_twin_source() {
    deep_stack(|| {
        let oracle = target_oracle_token_dump(TARGET_LEXER_TARGET_SOURCE)
            .expect("the oracle lexes the lexer twin source");
        let oracle_count = oracle.lines().count();
        let (vm_dump, eval_dump) = target_lexer_twin_dump(TARGET_LEXER_TARGET_SOURCE)
            .expect("the twin drives the lexer twin source");
        assert_eq!(
            vm_dump.lines().count(),
            oracle_count,
            "the twin vm token count must equal the oracle's"
        );
        assert_eq!(
            eval_dump.lines().count(),
            oracle_count,
            "the twin eval token count must equal the oracle's"
        );
        assert!(
            oracle_count > 1000,
            "a structural check rides a real source (found {oracle_count} tokens)"
        );
    });
}

/// The self-application face: the twin's OWN source, lexed by the
/// twin, contains its own `fn` heads (the `kw-fn` records) — the
/// target skin reads its own word faces.
#[test]
fn the_twin_reads_its_own_fn_heads() {
    deep_stack(|| {
        let (vm_dump, _) = target_lexer_twin_dump(TARGET_LEXER_TARGET_SOURCE)
            .expect("the twin drives its own source");
        let kw_fn_count = vm_dump.lines().filter(|l| l.starts_with("(kw-fn ")).count();
        assert!(
            kw_fn_count > 20,
            "the twin's own source carries its fn heads (found {kw_fn_count} kw-fn records)"
        );
    });
}

//! Cross-crate integration tests for the Stage 1.1 driver wiring
//! (test doc: docs/tests/v1/stage1/driver-wiring.md §2): the
//! conservative static checker mounted between expand and both
//! engines — source-reachable E0xxx diagnostics end-to-end, the
//! warning channel through every CLI face, the rendering join
//! (`error[E0002]:`), the abort-before-execution semantics, and the
//! 846-baseline zero-perturbation contract.

use kerf::driver::{
    self, DiagnosticCode, Engine, Repl, ReplEvent, Session, check_source, render_diagnostics,
    run_parity_source, run_source,
};

const FIB: &str =
    "fn fib(n) { if ((n < 2)) { n } else { (fib((n - 1)) + fib((n - 2))) } }\ndefine(r, fib(10));";

fn registry_tags(diags: &[driver::Diagnostic]) -> Vec<&'static str> {
    diags.iter().map(|d| d.code.tag()).collect()
}

// ---- Positive: the baseline stays untouched, warnings ride along ----

#[test]
fn clean_fib_full_chain_zero_findings_both_engines() {
    let mut s = Session::new();
    for engine in [Engine::Vm, Engine::Eval] {
        let out = run_source(&mut s, "fib.ktf", FIB, engine, &[]).expect("clean run");
        assert!(out.warnings.is_empty(), "{engine:?} carries no warnings");
        assert_eq!(
            out.global("r").map(|v| v.to_string()),
            Some("55".to_owned())
        );
    }
    let check = check_source(&mut s, "fib.ktf", FIB).expect("clean check");
    assert!(check.warnings.is_empty());
    assert!(check.func_count >= 2);
    let parity = run_parity_source(&mut s, "fib.ktf", FIB, &[]).expect("clean parity");
    assert!(parity.agrees());
    assert!(parity.warnings.is_empty());
}

#[test]
fn warning_program_executes_on_both_engines_with_value() {
    // R8 never blocks: the program runs to its value on both engines,
    // the warning rides on the outcome either way.
    let mut s = Session::new();
    for engine in [Engine::Vm, Engine::Eval] {
        let out = run_source(
            &mut s,
            "warn.krf",
            "define(base, 40);\ndefine(r, (base + set(car, 2)));",
            engine,
            &[],
        )
        .expect("warnings never block");
        assert_eq!(out.warnings.len(), 1);
        assert_eq!(out.warnings[0].code.tag(), "E0008");
        assert_eq!(
            out.global("r").map(|v| v.to_string()),
            Some("42".to_owned()),
            "the value channel is untouched on {engine:?}"
        );
    }
}

#[test]
fn handled_effect_and_properly_arityed_calls_stay_silent() {
    // The effect family's legal shapes: a handled perform at the
    // top level and correctly-arity'd calls produce zero findings —
    // the never-warn-on-legal-programs obligation, end to end.
    let mut s = Session::new();
    let src = "define(r, handle (perform log_effect(1)) { log_effect(v) => { v }, });";
    let out = run_source(&mut s, "fx.ktf", src, Engine::Vm, &[]).expect("legal effects run");
    assert!(out.warnings.is_empty());
    assert!(out.value_display() == "nil" || out.global("r").is_some());
}

// ---- Negative: source-reachable E0xxx through the wired pipeline ----

#[test]
fn e0002_arity_flows_to_the_rendered_registry_form() {
    let mut s = Session::new();
    let err = run_source(
        &mut s,
        "arity.krf",
        "fn f(x) { x }\ndefine(r, f(1, 2));",
        Engine::Vm,
        &[],
    )
    .expect_err("E0002");
    assert_eq!(registry_tags(&err), vec!["E0002"]);
    let rendered = render_diagnostics(&s, &err);
    assert!(
        rendered.starts_with("error[E0002]: "),
        "the registry head renders: {rendered}"
    );
    assert!(rendered.contains("--> arity.krf:2:"), "{rendered}");
}

#[test]
fn e0003_e0004_e0006_all_source_reachable() {
    let mut s = Session::new();
    let cases: [(&str, &str, &str); 3] = [
        ("c.ktf", "define(r, if (1) { 2 } else { 3 });", "E0003"),
        ("d.ktf", "define(two, 2);\ndefine(r, two(1));", "E0004"),
        (
            "p.ktf",
            "define(r, perform unhandled_thing(1, 2));",
            "E0006",
        ),
    ];
    for (name, src, code) in cases {
        let err = run_source(&mut s, name, src, Engine::Vm, &[])
            .expect_err(&format!("{code} must abort"));
        assert!(registry_tags(&err).contains(&code), "{name}: {err:?}");
        for d in &err {
            assert!(d.primary_span.is_some(), "{name} span carried: {d:?}");
        }
    }
}

#[test]
fn definite_errors_abort_before_any_side_effect() {
    // write-line sits in the program before the definite error; the
    // checker aborts before either engine starts, so nothing prints.
    let mut s = Session::new();
    let err = run_source(
        &mut s,
        "side.ktf",
        "define(a, write_line(\"must-not-print\"));\ndefine(b, first(1, 2));",
        Engine::Vm,
        &[],
    )
    .expect_err("abort before execution");
    assert!(registry_tags(&err).contains(&"E0002"));
}

#[test]
fn multi_error_collection_through_the_driver_batch() {
    let mut s = Session::new();
    let err = check_source(
        &mut s,
        "multi.krf",
        "define(two, 2);\ndefine(a, if (1) { 2 } else { 3 });\ndefine(b, first(1, 2));\ndefine(c, two(1));",
    )
    .expect_err("four definite errors collected");
    assert_eq!(err.len(), 4, "collection never short-circuits: {err:?}");
    let tags = registry_tags(&err);
    assert!(
        tags.contains(&"E0003")
            && tags.contains(&"E0002")
            && tags.contains(&"E0004")
            && tags.contains(&"E0009")
    );
    let rendered = render_diagnostics(&s, &err);
    assert!(
        rendered.ends_with("error: aborting due to 4 previous errors\n"),
        "{rendered}"
    );
}

#[test]
fn warning_only_batch_renders_summary_without_abort() {
    let mut s = Session::new();
    let out = run_source(
        &mut s,
        "ww.krf",
        "define(a, set(car, 1));\ndefine(b, set(rest, 2));",
        Engine::Vm,
        &[],
    )
    .expect("two warnings, zero errors");
    assert_eq!(out.warnings.len(), 2);
    let rendered = render_diagnostics(&s, &out.warnings);
    assert!(
        rendered.ends_with("warning: 2 warnings emitted\n"),
        "{rendered}"
    );
    assert!(!rendered.contains("aborting due to"), "{rendered}");
}

#[test]
fn typecheck_code_variant_carries_the_registry_payload() {
    let mut s = Session::new();
    let err = run_source(
        &mut s,
        "v.ktf",
        "define(r, if (1) { 2 } else { 3 });",
        Engine::Vm,
        &[],
    )
    .expect_err("E0003");
    assert!(
        matches!(err[0].code, DiagnosticCode::Typecheck(_)),
        "the stage-level enum carries the registry payload: {:?}",
        err[0].code
    );
}

#[test]
fn repl_delta_and_rollback_through_the_wiring() {
    let mut r = Repl::new();
    match r.submit("set(car, 1);") {
        ReplEvent::Evaluated { new_warnings, .. } => {
            let shown = new_warnings.join("\n");
            assert!(
                shown.contains("warning[E0008]"),
                "the warning renders: {shown}"
            );
        }
        other => panic!("warning submission is legal: {other:?}"),
    }
    match r.submit("1 + 2;") {
        ReplEvent::Evaluated {
            value,
            new_warnings,
            ..
        } => {
            assert_eq!(value.as_deref(), Some("3"));
            assert!(new_warnings.is_empty(), "no re-print on replay");
        }
        other => panic!("{other:?}"),
    }
    // A definite error on a name the program never reassigned: the
    // earlier `(set! car 1)` poisons `car` for R2 (the assign guard
    // correctly skips it), so this submission uses `cons`.
    match r.submit("pair(1, 2, 3);") {
        ReplEvent::Error { rendered } => {
            assert!(rendered.contains("error[E0002]"), "{rendered}");
        }
        other => panic!("definite error: {other:?}"),
    }
    assert!(
        !r.accepted_source().contains("pair(1, 2, 3)"),
        "rolled back"
    );
}

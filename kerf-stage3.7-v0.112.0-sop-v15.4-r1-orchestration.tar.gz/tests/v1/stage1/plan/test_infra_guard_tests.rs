//! Test-infrastructure self-audit guards (interlude Task 34, §9.57).
//!
//! The meta-domain face of the test tree: the guards below verify the
//! infrastructure that verifies the compiler. Every guard is a pure
//! read-and-count face over the repository layout — zero pipeline
//! execution, zero new dependencies (SOP §18).
//!
//! Three inventory invariants (the K75 tidy/compiletest family —
//! mechanical, tree-wide, fail-closed):
//! 1. Runner mounting: every `.rs` file under `tests/` is mounted by
//!    `tests/runner.rs` (cargo discovers only `tests/*.rs` top-level
//!    files; an unmounted file would silently never run).
//! 2. Corpus table parity: the per-case macro table in
//!    `subset_corpus_tests.rs` and the corpus directory carry exactly
//!    the same file set (no orphan file, no phantom entry — the
//!    dynamic sweep already covers validation; this guard covers the
//!    isolation table).
//! 3. Audit case registration: every audit case in
//!    `examples/audit/stage0_gate_audit_r1.rs` opens with a
//!    `// XNN:` comment label (the uniform registration convention
//!    normalized in v0.26.0); the per-section counts must equal the
//!    documented composition exactly (A10 + B10 + C5 + D5 + 16x10
//!    = 200) and the headline literal must match.
//!
//! A guard failure means an inventory drift: mount the file, table
//! the case, or label the case — never weaken the guard.

use std::collections::BTreeMap;
use std::path::{Path, PathBuf};

/// The repository root (the crate manifest directory).
fn repo_root() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
}

/// Recursively collect `.rs` files under `dir` (sorted, deterministic).
fn rust_files_under(dir: &Path) -> Vec<PathBuf> {
    let mut out = Vec::new();
    let mut stack = vec![dir.to_path_buf()];
    while let Some(d) = stack.pop() {
        let mut entries: Vec<_> = std::fs::read_dir(&d)
            .unwrap_or_else(|e| panic!("read_dir {}: {e}", d.display()))
            .filter_map(|e| e.ok())
            .map(|e| e.path())
            .collect();
        entries.sort();
        for path in entries {
            if path.is_dir() {
                stack.push(path);
            } else if path.extension().is_some_and(|x| x == "rs") {
                out.push(path);
            }
        }
    }
    out.sort();
    out
}

/// TEST-1: every `.rs` file under `tests/` is either the mount entry
/// itself, the single-mounted shared helper, or referenced by a
/// `#[path = "..."]` mount in `tests/runner.rs` — and every mount
/// target exists on disk (both directions, zero silent dead files).
#[test]
fn runner_mounts_every_test_tree_file() {
    let tests_dir = repo_root().join("tests");
    let runner_path = tests_dir.join("runner.rs");
    let runner_src = std::fs::read_to_string(&runner_path).expect("tests/runner.rs reads");

    // The mount set: every #[path = "..."] literal in the runner.
    let mounted = mount_literals(&runner_src);
    assert!(
        !mounted.is_empty(),
        "runner.rs must carry at least one #[path] mount"
    );

    // Forward: every mounted path exists on disk.
    for rel in &mounted {
        let target = tests_dir.join(rel);
        assert!(
            target.exists(),
            "runner.rs mounts `{rel}` but the file does not exist (stale mount)"
        );
    }

    // Reverse: every .rs file in the tree is the runner, the shared
    // helper, or explicitly mounted.
    let exempt = |p: &Path| p == runner_path || p == tests_dir.join("common/mod.rs");
    for file in rust_files_under(&tests_dir) {
        if exempt(&file) {
            continue;
        }
        let rel = file
            .strip_prefix(&tests_dir)
            .expect("path under tests/")
            .to_string_lossy()
            .into_owned();
        assert!(
            mounted.contains(&rel),
            "test file `{rel}` is not mounted in tests/runner.rs — cargo will \
             never run it (silent dead file); add the #[path] mount"
        );
    }
}

/// TEST-2: the per-case table in subset_corpus_tests.rs and the corpus
/// directory carry exactly the same `.ktf` file set (the blade-1
/// migration's single-skin corpus — W-SEXP-RETIRE SR-1).
#[test]
fn corpus_case_table_matches_directory_exactly() {
    let corpus_dir = repo_root().join("tests/v1/stage1/corpus");
    let harness_path = repo_root().join("tests/v1/stage1/plan/subset_corpus_tests.rs");
    let harness_src = std::fs::read_to_string(&harness_path).expect("subset_corpus_tests.rs reads");

    // The table face: every "name.ktf" literal in the harness. The
    // corpus_case! macro quotes the file name as its data argument;
    // a scan over double-quoted `.ktf` literals is exact here because
    // the sweep face constructs no quoted names.
    let mut table = quoted_ktf_literals(&harness_src);
    assert!(!table.is_empty(), "the corpus case table must not be empty");

    // The directory face.
    let mut directory: Vec<String> = std::fs::read_dir(&corpus_dir)
        .expect("corpus directory exists")
        .filter_map(|e| e.ok())
        .map(|e| e.file_name().to_string_lossy().into_owned())
        .filter(|n| n.ends_with(".ktf"))
        .collect();
    directory.sort();
    table.sort();

    let dir_set: std::collections::BTreeSet<_> = directory.iter().collect();
    let table_set: std::collections::BTreeSet<_> = table.iter().collect();

    let orphans: Vec<_> = dir_set.difference(&table_set).collect();
    let phantoms: Vec<_> = table_set.difference(&dir_set).collect();
    assert!(
        orphans.is_empty(),
        "corpus files without a `corpus_case!` table entry (the isolation face \
         lags the directory — add the per-case tests): {orphans:?}"
    );
    assert!(
        phantoms.is_empty(),
        "corpus table entries without a file on disk (phantom cases — remove \
         the entry or restore the file): {phantoms:?}"
    );
    assert_eq!(
        table.len(),
        table_set.len(),
        "the corpus table lists a file twice (dedup mismatch)"
    );
}

/// TEST-3: the audit case inventory — per-section opening-label
/// counts must equal the documented composition exactly (584 total:
/// 460 live + 124 retired-historical)
/// and the headline literal must carry the same number. Sections are
/// one or two uppercase letters (AA = the Stage 2.6 C-transpilation
/// family and AB..AE = the Stage 2.7 target-skin families, the
/// two-letter sections).
#[test]
fn audit_case_inventory_matches_documented_composition() {
    let audit_path = repo_root().join("examples/audit/stage0_gate_audit_r1.rs");
    let audit_src = std::fs::read_to_string(&audit_path).expect("audit source reads");

    // The documented composition (header comment + §7.3.1 audit set):
    // sections A..Z with C and D at five cases, Z at twenty-four, R at
    // twenty, every other section at ten — 264 total (X = the Stage
    // 2.3 first-Pass family at v0.52.0; Y = the r83 emission family
    // at v0.53.0; Z = the r84 composed-chain close-out family at
    // v0.54.0 extended r86 with the 2.4 full-composed-chain family
    // (§9.87) and r88 with the 2.5 fixpoint window (§9.89 — the
    // rebuild face, the elevated gate B, and the fixpoint itself);
    // R = the r85 lexical-second-segment family doubling the reader
    // section at v0.55.0).
    let documented = documented_audit_composition();

    // The registration convention: every case opens with a whole-line
    // comment `// XNN:` or `// XNN (` — uniform since the v0.26.0
    // normalization (A-C comments added, H07 labeled, U/V widened to
    // two digits). Line-anchored so in-body assert messages that
    // mention labels cannot match. Block comments (the r104 E5
    // batch-3 teardown's RETIRED historical sections — preserved
    // verbatim, never counted as live inventory) are stripped first.
    let live_src = strip_block_comments(&audit_src);
    let observed = count_case_labels(&live_src, &documented);

    for (section, want) in &documented {
        let got = observed.get(*section).copied().unwrap_or(0);
        assert_eq!(
            got, *want,
            "audit section {section}: {got} registered cases, documented {want} \
             (a case lost its opening `// {section}NN:` label, or the composition \
             changed without updating this guard and the header)"
        );
    }
    let total: usize = observed.values().sum();
    assert_eq!(
        total, 460,
        "audit inventory total {total} must equal the documented 460 live \
         (the r104 E5 batch-3 teardown retired the R/S/T/U/X/Y/Z sections \
         wholesale; the r150 W-SEXP-RETIRE blade-1 round added the BF \
         family of 10; the r151 W-SEXP-RETIRE blade-2 round retired 20 \
         live cases to disclosed historical records — the AF transcoder \
         family with the A03/B03/B09/C03 empty-application quad (ruling \
         C12: `()` reads as nil on the target face), AH9, AJ07-AJ10, \
         AL03/AL08 and AY09)"
    );

    // The headline literal is the machine-checked twin of the count.
    assert!(
        audit_src.contains("AUDIT PASS 460/460"),
        "the audit headline literal must carry the verified live total (460/460)"
    );
}

/// TEST-3b (detection-power arm, the r54 detector precedent): the
/// label counter must count exactly the canonical opening-comment
/// shapes and nothing else — a synthetic fixture with a known
/// composition, including the near-miss shapes the counter must
/// reject (in-body assert message, single-digit label, prose mention,
/// mid-line label).
#[test]
fn label_counter_detects_the_canonical_shapes() {
    let known_sections: BTreeMap<&'static str, usize> =
        [("A", 99), ("E", 99), ("AA", 99)].into_iter().collect();
    let fixture = "\
// A01: canonical colon form.
fn body_a() {}
    // E01 (canonical paren form): fixture case.
fn body_e() {}
        assert!(rendered.contains(\"I01: {rendered}\"), \"I01 near-miss\");
    // A1: single-digit near-miss (pre-normalization shape) — counted
    // since the two-letter-section relaxation (AA-style labels are
    // one digit); the pre-relaxation fixture kept the rejection.
let msg = \"A02 prose mention in a string, not a comment\";
fn inline() { /* A03: mid-line comment — rejected */ }
// Z01: unknown section letter — rejected.
// A04:nospace colon — accepted (the canonical colon, spacing-free).
// AA1 (two-letter section, paren): counted.
";
    let counted = count_case_labels(fixture, &known_sections);
    assert_eq!(
        counted.get("A"),
        Some(&3),
        "A: A01 (colon) + A1 (single digit) + A04 (nospace colon) count; A02/mid-line rejected"
    );
    assert_eq!(
        counted.get("E"),
        Some(&1),
        "E: E01 (paren) counts; the in-body I01 string does not"
    );
    assert_eq!(
        counted.get("AA"),
        Some(&1),
        "AA: the two-letter form counts"
    );
    assert!(
        !counted.contains_key("I") && !counted.contains_key("Z"),
        "unknown-section labels are not counted at all"
    );
}

/// The documented audit composition (header comment + §7.3.1): the
/// sections A..Z with C and D at five cases, Y at ten, Z at sixteen,
/// every other section at ten — 256 total (X = the Stage 2.3
/// first-Pass family v0.52.0; Y = the r83 emission family v0.53.0;
/// Z = the r84 composed-chain close-out family v0.54.0, extended
/// r86 with the 2.4 full-composed-chain family §9.87).
fn documented_audit_composition() -> BTreeMap<&'static str, usize> {
    [
        ("A", 9), // A03 (the empty application) retired at r151 — ruling C12
        ("B", 8), // B03/B09 (the empty-application pair) retired at r151 — ruling C12
        ("C", 4), // C03 (the empty application at nesting bottom) retired at r151 — ruling C12
        ("D", 5),
        ("E", 10),
        ("F", 10),
        ("G", 10),
        ("H", 10),
        ("I", 10),
        ("J", 10),
        ("K", 10),
        ("L", 10),
        ("M", 10),
        ("N", 10),
        ("P", 10),
        ("Q", 10),
        // The r104 E5 batch-3 teardown (switch-window-plan §5.6.4):
        // the .krf-face sections R/S/T/U/X/Y/Z retired wholesale (the
        // `.krf` originals left the tree; the sections ride the audit
        // as block-commented historical records) — 104 cases total,
        // the live successors being the composed TARGET chain and the
        // target fixpoint.
        ("V", 10),
        ("W", 10),
        // The Stage 2.6 C-transpilation family (r91, §9.92) — the
        // first two-letter section (the section alphabet exhausted at
        // Z; AA continues the monotonic growth per §7.3.1 rule 4).
        ("AA", 10),
        // The Stage 2.7 switch-window families: AB = the r98 target-
        // skin seed (§9.94); AC = the r99 step-2 lexical/syntactic
        // batch (§9.95 — match + use paths + E5 batch 1 + the
        // annotation-generic drops); AD = the r100 step-3 corpus-
        // translation family (§9.96 — E5 batch 2 + the quote datum
        // carrier + the five .ktf twins at the three-gate face);
        // AE = the r101 step-4 target-fixpoint family (§9.97 — the
        // production bridge, the target fixpoint, the gate-B
        // transitivity, and the depth-guard regression).
        ("AB", 10),
        ("AC", 10),
        ("AD", 6), // AD7-AD10 (the seed-side cross-checks) retired at r104
        ("AE", 6), // AE1/AE5/AE9/AE10 (the seed-side cross-checks) retired at r104
        // The Stage 2.7 step-5 family (r103, §9.98): AF = the
        // two-skin corpus closeout (the transcoder, the 85-case
        // sweep, the hand-twin and divergence families, the
        // macro-declaration ledger, the dual-caliber fixpoint gate).
        ("AF", 0), // the transcoder family retired whole at r151 (the skin
        // transcoder left with the S-expression reader — the
        // r104 AF9/AF10 precedent continues as disclosure)
        // The Stage 3 W-3.2 family (r112, §9.107): AG = the FFI
        // extern language face (the dual-skin declaration form, the
        // expansion record, the ABI/type/collision police, the
        // C-symbol derivation ruling, the checker arity face, the
        // infer contract typing, the VM fail-closed diagnostic, the
        // C emission).
        ("AG", 10),
        // The Stage 3 W-3.3 family (r114): AH = the macro-declaration
        // skin face (the `macro name { spec }` carrier's canonical-
        // tree mapping, the expansion record, the e2e value face,
        // the ellipsis datum's same-stage rejection, the operator
        // datum vocabulary, the literals face, the module-scoped
        // declaration, the carrier's read-stage grammar, the
        // two-skin three-gate, the hygiene rename-on-capture
        // defense — TD-007 cleared).
        ("AH", 9), // AH9 (the two-skin three-gate) retired at r151
        // (TD-007's carrier assertions survive on the single skin)
        // The Stage 3 W-3.10 family (r116): AI = the package-manager
        // face (the manifest projection, the missing-key and bad-
        // version rejections, the unknown-key fail-closed rule, the
        // duplicate-key grammar rule, the lockfile deterministic
        // round-trip, the two-package resolution order, the named
        // cycle path, the diamond conflict listing every constraint,
        // the missing dependency directory).
        ("AI", 10),
        // The Stage 3 W-3.12 family (r121): AJ = the injection-channel
        // / steady-chain face (the segment-one implementation
        // window — the engines' bind + fail-closed trio, the
        // expander's injected-names acceptance with its fail-closed
        // baselines, the steady chain's oracle-matching read, the
        // boundary rejection, the feeds-every-read contract, the
        // determinism face).
        ("AJ", 6), // AJ07-AJ10 (the S-expr steady-chain quartet) retired at
        // r151 — SteadyReaderChain left with the reader; the
        // SteadyTargetReaderChain twin is audited by the runner's
        // own steady_target_reader_tests
        // The Stage 3 W-3.12 segment-two family (r122): AK = the
        // steady expander chain (the twin expander compiled once,
        // the forms record stream injected per expansion through
        // the one channel — the full-channel extern-bearing
        // expansion with oracle matching, the fail-closed trio
        // [unknown name / budget / feeds-every-expansion], the
        // injected-names acceptance baselines, the dual-engine
        // agreement, the r103 text-route boundary vs the injected
        // face's native i64::MIN coverage, the record grammar's
        // literal face).
        ("AK", 10),
        // The Stage 3 W-CSYM-EXPR family (r123): AL = the extern
        // C-domain re-attribution (the reclassified corpus row end
        // to end, the retired twin boundary's twin/oracle agreement,
        // the dash/underscore collision through the full pipeline,
        // the verify judge's three faces on hand-built products, the
        // language-level identity checks that stayed at expand, the
        // name-bearing diagnostic payloads, the two-skin contract,
        // the compile-always-passes-verify contract + determinism,
        // the expander's shrinkage pin).
        ("AL", 8), // AL03 (the unspellable dash/underscore collision) and
        // AL08 retired at r151 — the transcoder legs left with
        // the reader; the one-way Rule K note survives in the
        // audit's disclosure
        // The Stage 3 W-3.12 segment-three family (r124): AM = the
        // junction-3 extern consumption (the emit face's
        // single-quote fix, the twin-side walk, the product tables
        // on both engines' analysis dumps, the gate-B rebuild face,
        // the twin-side name police, the disclosed
        // character-police drift, the empty-table regression).
        ("AM", 10),
        // The Stage 3 W-HM-TWIN family (r130): AN = the test face of
        // the r127/r128/r129 twin deliveries (the paired positive/
        // negative probes on both judgment faces — the quantified-
        // schema row, the E0009 bool-demand row, the E0010 occurs
        // row, the checker's table and arity rows; the budget row's
        // E0011 exclusion semantics; the cross-route and composed
        // analysis faces; the empty-stream boundary; the rebuild's
        // fail-closed tamper family).
        ("AN", 10),
        // The Stage 3 W-VM-SUPERINSTR family (r133, the
        // superinstruction implementation window): AO = the fused
        // call-global audit face (emission completeness, value
        // agreement, the arity/division families at the fused site,
        // the verify boundary, the unbound/extern migrations, the
        // .krf round-trip, the C emission compound, the twin
        // fusion-arm tamper).
        ("AO", 10),
        // The r134 W-VM-SUPERINSTR F1 family (w-vm-superinstr-window
        // §2a FA-1..FA-6): AP = the direct-arithmetic blade's audit
        // face (emission completeness, the poison tri-source, the
        // fallback family, the argc conjunct, the value agreement,
        // the .krf round-trip, the C lowering, the intern order, the
        // twin poison-scan tamper, the census premise).
        ("AP", 10),
        // The r135 W-JIT-METHOD-T1 tier-0.5 completion family
        // (w-jit-method-t1-window §2 TJ-1): AQ = the fused copy
        // pair's audit face (emission completeness, the fib-shape
        // three-site pin with the branch-target structural safety,
        // the verify boundary family, the capture and global scope
        // boundaries, the .ktf round-trip, the C lowering compound,
        // the intern first-use order, the twin fusion-arm tamper,
        // the census premise).
        ("AQ", 10),
        // The r136 W-REC-DEPTH blade-1 family
        // (bootstrap-completion-plan §4.1; K160): AR = the heap
        // activation stack's audit face (the 10^5 non-tail default-
        // stack acceptance leg, cross-engine parity at depth, the
        // budget as the only bound with the R8 message, the unwind
        // state machine, GC root completeness under depth, handlers
        // under depth, captures under depth, the span contract at
        // depth, run-to-run determinism, the allocation accounting).
        ("AR", 10),
        // The r136 W-TGT-READ-TWIN blade-1 family
        // (bootstrap-completion-plan §4.2; gap G1): AS = the
        // target-skin lexer twin's audit face (the full curated
        // three-way sweep, the word-face dump anchors, the in-twin
        // number values, the float K20 boundaries, the rejection
        // anchors, the self-source case, the selfhost corpus, the
        // skin-mapping axis, the trivia-only sources, the
        // token-count consumption cross-check).
        ("AS", 10),
        // The r137 W-REC-DEPTH blade-2 family
        // (bootstrap-completion-plan §4.1; the K162 ruling): AT =
        // the configurable guardrails' audit face (the four-layer
        // cap ladder's with_limit entries, the golden defaults, the
        // driver env parse, the degenerate fail-closed overrides,
        // and the r74/r85 fixpoint bracket retirement).
        ("AT", 10),
        // The r138 W-TGT-READ-TWIN blade-2 family
        // (bootstrap-completion-plan §4.2; gap G1): AU = the
        // target-skin parser twin's boundary face — the round's ten
        // regression boundaries pinned permanent (the fn-header
        // name order, the zero-record verdict, the type-paren comma
        // loop, the use-path semi-extended string span, the extern
        // type order, the level-0/1 short-circuit operators, the
        // one-element byte-list datum, the block fold order, the
        // handle-arm tail spread, the single-enter depth
        // discipline + the eof two-field record).
        ("AU", 10),
        // The r139 W-TGT-READ-TWIN blade-3 family (the G1 closure's
        // chain form): AV = the steady target read chain's boundary
        // face — the channel contract (both slots), the two-field
        // eof record through the bridge, the FloatOutOfRange layer
        // split, the ident canonical bytes, the str escape decode,
        // the extern empty-params nil encoding (the CP-1 contract's
        // third member), the match scope boundary (the disclosed
        // row), the fixpoint purity face, the cross-route
        // equivalence, and the deepest self-application.
        ("AV", 10),
        // The r141 W-JIT-METHOD-T1 blade-1 round added the AW family
        // of 10 (the tier-1 method-JIT infrastructure — MJ-1..MJ-4).
        ("AW", 10),
        // The r142 W-JIT-METHOD-T1 blade-2 round added the AX family
        // of 10 (the B-axis adjudication: the production default
        // flip to pure interpretation, the LLC cooperation face,
        // the census invariance, the portrait numbers mechanized).
        ("AX", 10),
        // The r143 TD-027 round added the AY family of 10 (the match
        // desugar's twin arm: the value face, the exhaustiveness and
        // pattern-family rejections, the single-eval scrutinee, the
        // shadow, the nested fold, the twin parity, the composed
        // formula with the retired J0.9 row, the transcode face, and
        // the two error-order pins).
        ("AY", 9), // AY09 (the transcode face) retired at r151 — the
        // match-desugar twin arm's other nine assertions survive
        // on the single skin
        // The r144 T-a step-② round added the AZ family of 10
        // (the A/B/C artifact pipeline — the CCF faces).
        ("AZ", 10),
        // The r145 T-a step-④ read-segment round added the BA
        // family of 10 (the production position switch — the
        // disclosure, the positions' agreement, the layer split,
        // the rollback selector, the seed pin, the cap override,
        // the span retarget, and the stack-flat regression).
        ("BA", 10),
        // The r146 T-a step-④ expand-segment round added the BB
        // family of 10 (the production position switch — the
        // disclosure, the positions' agreement, the junction-2
        // loader coverage, the rollback selector, the seed pin,
        // the budget override, the span retarget, and the
        // stack-flat regression over the forms-stream injection
        // sites).
        ("BB", 10),
        // The T-a step-④ check family (r147): BC = the check-segment
        // production switch (the twin-position disclosure, the
        // conservative findings' dual-position identity, the
        // inference layer's dual-position agreement, the warning
        // channel carrying its finding, the span retarget to the
        // session's file, the seed pin, the selector's fail-closed
        // trio, the fixed-point clean verdicts, the empty face, the
        // tree-retarget regression).
        ("BC", 10),
        // The T-a step-④ compile family (r148): BD = the compile-segment
        // production switch (the twin-position disclosure, the
        // artifact parity across shapes, the depth budget's same-key
        // rejection, the extern duplicate's global-index parity, the
        // product-span retarget, the self-describing budget, the
        // selector's fail-closed trio, the compiler CCF fixed point,
        // the empty face, the stack-flat regression over the flat
        // quote).
        ("BD", 10),
        // The T-a step-⑤ workflow family (r149): BE = the workflow
        // record — the C4 face's first production consumption (the
        // self-check corpus on the production position, the benchmark
        // markers, the detection-power arms, the rollback-band
        // agreement across the all-oracle position, the CLI
        // end-to-end face).
        ("BE", 10),
        // The r150 W-SEXP-RETIRE blade-1 family
        // (w-sexp-retire-window SR-1/SR-2/SR-3): BF = the migrated
        // single-skin corpus face (the 109-case .ktf directory fact,
        // the skin-neutral directive contract, the parse_directive
        // dual-prefix ruling, the post-retirement distribution
        // floors, the ruling-C12 unit pin, the reserved-else pin,
        // the fn-wrapped handler-arm pin, the stage-divergent
        // parse-error pin, the hand-twin i64::MIN boundary, the
        // mechanical value anchor).
        ("BF", 10),
    ]
    .into_iter()
    .collect()
}

/// Count case-opening labels per section: whole-line comments of the
/// form `// XNN:` or `// XNN (` where X is a known section letter.
/// Strip Rust block comments (nesting-aware) — the r104 teardown's
/// RETIRED historical sections keep their case labels verbatim inside
/// `/* ... */` blocks; the live inventory must not count them.
fn strip_block_comments(src: &str) -> String {
    let mut out = String::with_capacity(src.len());
    let bytes = src.as_bytes();
    let mut i = 0;
    let mut depth = 0usize;
    while i < bytes.len() {
        if depth == 0 && bytes[i] == b'/' && i + 1 < bytes.len() && bytes[i + 1] == b'/' {
            // Keep line comments whole.
            let end = src[i..].find('\n').map(|k| i + k).unwrap_or(bytes.len());
            out.push_str(&src[i..end]);
            i = end;
            continue;
        }
        if bytes[i] == b'/' && i + 1 < bytes.len() && bytes[i + 1] == b'*' {
            depth += 1;
            i += 2;
            continue;
        }
        if depth > 0 && bytes[i] == b'*' && i + 1 < bytes.len() && bytes[i + 1] == b'/' {
            depth -= 1;
            i += 2;
            continue;
        }
        if depth == 0 {
            out.push(bytes[i] as char);
        }
        i += 1;
    }
    out
}

fn count_case_labels(
    src: &str,
    known_sections: &BTreeMap<&'static str, usize>,
) -> BTreeMap<&'static str, usize> {
    let mut observed: BTreeMap<&'static str, usize> = BTreeMap::new();
    for line in src.lines() {
        let trimmed = line.trim_start();
        let rest = match trimmed.strip_prefix("//") {
            Some(rest) => rest,
            None => continue,
        };
        let rest = rest.trim_start();
        // The registration grammar: one or two uppercase section
        // letters, one or two digits, then ':' or '(' — anchored so
        // prose cannot match (a `// The ...` line has no digit run).
        let bytes = rest.as_bytes();
        let mut at = 0;
        while at < bytes.len() && bytes[at].is_ascii_uppercase() && at < 2 {
            at += 1;
        }
        if at == 0 {
            continue;
        }
        let section = &rest[..at];
        let Some((static_key, _)) = known_sections.get_key_value(section) else {
            continue;
        };
        let digit_start = at;
        while at < bytes.len() && bytes[at].is_ascii_digit() && at < digit_start + 2 {
            at += 1;
        }
        if at == digit_start {
            continue;
        }
        let after = rest[at..].trim_start();
        if after.starts_with(':') || after.starts_with('(') {
            *observed.entry(*static_key).or_insert(0) += 1;
        }
    }
    observed
}

/// Every `#[path = "..."]` attribute literal in `src` (no regex
/// dependency — SOP §18 zero-new-deps). Matching is anchored on the
/// `#[path =` opener so prose mentions of `#[path]` in doc comments
/// cannot match.
fn mount_literals(src: &str) -> Vec<String> {
    let mut out = Vec::new();
    let mut rest = src;
    while let Some(at) = rest.find("#[path =") {
        rest = &rest[at + "#[path =".len()..];
        let open = match rest.find('"') {
            Some(i) => i,
            None => break,
        };
        let after_open = &rest[open + 1..];
        let close = match after_open.find('"') {
            Some(i) => i,
            None => break,
        };
        out.push(after_open[..close].to_string());
        rest = &after_open[close + 1..];
    }
    out
}

/// Every double-quoted string literal in `src` that names a corpus
/// case (ends in `.ktf` and carries a stem — the bare `".ktf"` suffix
/// probe inside the harness itself is not a case name).
fn quoted_ktf_literals(src: &str) -> Vec<String> {
    let mut out = Vec::new();
    let mut rest = src;
    while let Some(open) = rest.find('"') {
        let after_open = &rest[open + 1..];
        let close = match after_open.find('"') {
            Some(i) => i,
            None => break,
        };
        let lit = &after_open[..close];
        if lit.ends_with(".ktf") && lit.len() > ".ktf".len() {
            out.push(lit.to_string());
        }
        rest = &after_open[close + 1..];
    }
    out
}

// ---------- TEST-4: no cross-crate forwarding re-exports (v0.28.0, §9.59) ----------

/// Extract `pub use kerf_...` forwarding lines from one source file,
/// skipping comment lines (a `//`-prefixed line never re-exports).
fn forwarding_reexports(src: &str) -> Vec<String> {
    src.lines()
        .map(str::trim_start)
        .filter(|line| !line.starts_with("//"))
        .filter(|line| {
            line.starts_with("pub use kerf_") || line.starts_with("pub (crate) use kerf_")
        })
        .map(str::to_owned)
        .collect()
}

#[test]
fn pipeline_crates_forward_nothing_from_other_crates() {
    // The no-forwarding rule (stage0.md §9.59, SOP §18.5 v15.2): a
    // pipeline crate exports only what it defines. Types that appear
    // in a crate's public API but live elsewhere (Span/Symbol from
    // kerf-span, the core AST family from kerf-core) are imported by
    // consumers directly from the defining crate — the rustc_ast
    // precedent (rustc_span is a direct dependency of every consumer
    // crate and rustc_ast re-exports nothing from it, §9.59 K81).
    let crates_dir = repo_root().join("crates");
    let mut offenders: Vec<String> = Vec::new();
    let mut scanned = 0usize;
    for path in rust_files_under(&crates_dir) {
        let src = std::fs::read_to_string(&path).expect("crate source reads");
        scanned += 1;
        for line in forwarding_reexports(&src) {
            offenders.push(format!("{}: {line}", path.display()));
        }
    }
    assert!(
        offenders.is_empty(),
        "cross-crate forwarding re-exports found (stage0.md §9.59 — import \
         from the defining crate instead):\n{}",
        offenders.join("\n")
    );
    assert!(
        scanned >= 10,
        "expected to scan all ten crates, saw {scanned}"
    );
}

#[test]
fn root_facade_aliases_whole_crates_but_forwards_no_types() {
    // The root aggregation crate (src/lib.rs, SOP §8.4.6 rule 7) is the
    // one sanctioned facade: it re-exports whole member crates under
    // namespace aliases (`pub use kerf_span as span`). The two-tier
    // rule: crate-level aliases are its designed aggregation content;
    // type-level passthrough (`pub use kerf_x::Type`) is forbidden
    // exactly as inside the pipeline crates.
    let facade = repo_root().join("src/lib.rs");
    let src = std::fs::read_to_string(&facade).expect("facade source reads");
    for line in forwarding_reexports(&src) {
        // Allow only the whole-crate alias shape: `pub use kerf_x as y;`
        let is_alias = line.starts_with("pub use kerf_")
            && line.contains(" as ")
            && line.trim_end().ends_with(';')
            && !line.contains("::");
        assert!(
            is_alias,
            "type-level forwarding in the root facade is forbidden \
             (whole-crate aliases only, SOP §8.4.6): {line}"
        );
    }
}

#[test]
fn forwarding_detector_detects_and_spares_correctly() {
    // The detection-power arm (the r54/r34 three-arm precedent): the
    // scanner must catch every forwarding shape and spare every
    // legitimate own-module export.
    // The detector is strictly line-level: it also flags the whole-crate
    // alias shape (`pub use kerf_span as span;`) — the facade exemption
    // is applied by the caller (the root-facade two-tier check above),
    // not by the detector. Development true-positive: the first run of
    // this arm caught the alias listed as should-spare here — the fixture
    // was wrong, the detector was right (the TEST-2 precedent).
    let should_flag = [
        "pub use kerf_span::Span;",
        "pub use kerf_core::{ModuleItem, CoreExpr};",
        "    pub use kerf_compiler::Symbol;",
        "pub (crate) use kerf_span::{ByteOffset, FileId};",
        "pub use kerf_span as span;",
    ];
    for line in should_flag {
        assert_eq!(
            forwarding_reexports(line),
            vec![line.trim_start().to_owned()],
            "detector must flag: {line}"
        );
    }
    let should_spare = [
        "pub use error::CoreError;",
        "pub use expr::{StxDatum, SyntaxObject};",
        "// pub use kerf_span::Span; (historical note)",
        "/// doc mention: pub use kerf_core::ModuleItem",
        "use kerf_span::Symbol;",
        "pub use crate::error::ReadError;",
    ];
    for line in should_spare {
        assert!(
            forwarding_reexports(line).is_empty(),
            "detector must spare: {line}"
        );
    }
}

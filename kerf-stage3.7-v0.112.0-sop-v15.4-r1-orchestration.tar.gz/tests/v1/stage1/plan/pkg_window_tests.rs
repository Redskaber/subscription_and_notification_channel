//! The W-3.10 package-manager window integration suite (stage-3-plan
//! §2.3 W-3.10, window record `docs/develop/v3/w3.10-package-window.md`).
//!
//! GATE 6 shape: five integration cases (two-package e2e, transitive
//! chain order, cycle detection, diamond conflict, lockfile
//! consumption) plus the negative family (missing root manifest,
//! missing dependency directory, directory/name mismatch) — the
//! negative cases outnumber the positive ones by more than 3:1 across
//! the window's full test face (these plus the in-crate unit families
//! and the audit AI section).

use kerf::pkg::{Lockfile, PkgError, resolve};
use std::path::{Path, PathBuf};

/// A unique fixture root per test (cleaned up on exit).
fn fixture(tag: &str) -> PathBuf {
    let dir = std::env::temp_dir().join(format!("kerf-pkg-tests-{}-{tag}", std::process::id()));
    let _ = std::fs::remove_dir_all(&dir);
    std::fs::create_dir_all(&dir).expect("fixture dir creates");
    dir
}

/// Write a package manifest under `dir` (creating the directory).
fn write_pkg(dir: &Path, manifest: &str) {
    std::fs::create_dir_all(dir).expect("package dir creates");
    std::fs::write(dir.join("kerf.toml"), manifest).expect("manifest writes");
}

/// Integration: the two-package graph resolves with dependencies
/// before dependents and a complete lockfile (MUV 3.10-a's named case).
#[test]
fn two_package_resolution_e2e() {
    let dir = fixture("two");
    write_pkg(
        &dir,
        "package = \"app\"\nversion = \"0.1.0\"\n\n[depends]\ncore-bits = \"0.2\"\n",
    );
    write_pkg(
        &dir.join("libs/core-bits"),
        "package = \"core-bits\"\nversion = \"0.2.3\"\n",
    );

    let resolution =
        resolve(&dir).unwrap_or_else(|e| panic!("the two-package graph resolves: {e}"));

    let names: Vec<&str> = resolution.order.iter().map(|p| p.name.as_str()).collect();
    assert_eq!(
        names,
        vec!["core-bits", "app"],
        "dependency first, root last"
    );

    // The lockfile records both packages with root-relative sources.
    let by_name: Vec<(String, String, String)> = resolution
        .lockfile
        .packages
        .iter()
        .map(|p| (p.name.clone(), p.version.to_string(), p.source.clone()))
        .collect();
    assert_eq!(
        by_name,
        vec![
            ("app".to_string(), "0.1.0".to_string(), ".".to_string()),
            (
                "core-bits".to_string(),
                "0.2.3".to_string(),
                "libs/core-bits".to_string()
            ),
        ],
        "the lockfile carries name, exact version, and root-relative source"
    );

    let _ = std::fs::remove_dir_all(&dir);
}

/// Integration: a transitive three-package chain orders the deepest
/// dependency first at every level.
#[test]
fn transitive_chain_orders_deepest_first() {
    let dir = fixture("chain");
    write_pkg(
        &dir,
        "package = \"top\"\nversion = \"1.0.0\"\n\n[depends]\nmid = \"1.1\"\n",
    );
    write_pkg(
        &dir.join("libs/mid"),
        "package = \"mid\"\nversion = \"1.2.0\"\n\n[depends]\nbase = \"1.0\"\n",
    );
    write_pkg(
        &dir.join("libs/mid/libs/base"),
        "package = \"base\"\nversion = \"1.0.7\"\n",
    );

    let resolution = resolve(&dir).unwrap_or_else(|e| panic!("the transitive chain resolves: {e}"));
    let names: Vec<&str> = resolution.order.iter().map(|p| p.name.as_str()).collect();
    assert_eq!(
        names,
        vec!["base", "mid", "top"],
        "deepest first at every level"
    );
    assert_eq!(
        resolution.lockfile.packages.len(),
        3,
        "every package in the chain is recorded"
    );
    let base = resolution
        .lockfile
        .packages
        .iter()
        .find(|p| p.name == "base")
        .expect("base is recorded");
    assert_eq!(
        base.source, "libs/mid/libs/base",
        "the nested source path is root-relative"
    );

    let _ = std::fs::remove_dir_all(&dir);
}

/// Integration: a dependency cycle is rejected with the named path
/// (MUV 3.10-a's named case).
#[test]
fn cycle_detection_e2e() {
    let dir = fixture("cycle");
    write_pkg(
        &dir,
        "package = \"aaa\"\nversion = \"0.1.0\"\n\n[depends]\nbbb = \"0.1\"\n",
    );
    write_pkg(
        &dir.join("libs/bbb"),
        "package = \"bbb\"\nversion = \"0.1.0\"\n\n[depends]\nccc = \"0.1\"\n",
    );
    write_pkg(
        &dir.join("libs/bbb/libs/ccc"),
        "package = \"ccc\"\nversion = \"0.1.0\"\n\n[depends]\naaa = \"0.1\"\n",
    );

    match resolve(&dir) {
        Err(PkgError::CycleDetected { cycle }) => assert_eq!(
            cycle,
            vec![
                "aaa".to_string(),
                "bbb".to_string(),
                "ccc".to_string(),
                "aaa".to_string()
            ],
            "the cycle names every member in order"
        ),
        other => panic!("expected a cycle error, got {other:?}"),
    }

    let _ = std::fs::remove_dir_all(&dir);
}

/// Integration: a diamond version conflict reports the resolved version
/// and every imposed constraint.
#[test]
fn diamond_conflict_e2e() {
    let dir = fixture("diamond");
    write_pkg(
        &dir,
        "package = \"top\"\nversion = \"0.1.0\"\n\n[depends]\nleft = \"0.1\"\nright = \"0.1\"\n",
    );
    write_pkg(
        &dir.join("libs/left"),
        "package = \"left\"\nversion = \"0.1.0\"\n\n[depends]\ndeep = \"0.1\"\n",
    );
    write_pkg(
        &dir.join("libs/right"),
        "package = \"right\"\nversion = \"0.1.0\"\n\n[depends]\ndeep = \"0.2\"\n",
    );
    write_pkg(
        &dir.join("libs/left/libs/deep"),
        "package = \"deep\"\nversion = \"0.1.4\"\n",
    );

    match resolve(&dir) {
        Err(PkgError::VersionConflict {
            name,
            version,
            constraints,
        }) => {
            assert_eq!(name, "deep");
            assert_eq!(version, "0.1.4");
            assert_eq!(
                constraints,
                vec![
                    ("left".to_string(), "0.1".to_string()),
                    ("right".to_string(), "0.2".to_string()),
                ],
                "every imposed constraint is listed with its dependent"
            );
        }
        other => panic!("expected a version conflict, got {other:?}"),
    }

    let _ = std::fs::remove_dir_all(&dir);
}

/// Integration: the lockfile is a faithful consumption product — the
/// written text reparses to the same model, and re-resolving the same
/// graph reproduces the byte-identical lockfile (the reproducibility
/// principle, K117).
#[test]
fn lockfile_roundtrip_and_consumption() {
    let dir = fixture("lock");
    write_pkg(
        &dir,
        "package = \"app\"\nversion = \"0.2.0\"\n\n[depends]\nleft = \"0.1\"\nright = \"0.1\"\n",
    );
    write_pkg(
        &dir.join("libs/left"),
        "package = \"left\"\nversion = \"0.1.2\"\n",
    );
    write_pkg(
        &dir.join("libs/right"),
        "package = \"right\"\nversion = \"0.1.9\"\n\n[depends]\nleft = \"0.1.2\"\n",
    );
    // `right` reaches `left` through the shared name: the first
    // resolution (root's libs/left) wins and satisfies the constraint.
    write_pkg(
        &dir.join("libs/right/libs/left"),
        "package = \"left\"\nversion = \"0.9.9\"\n",
    );

    let first = resolve(&dir).unwrap_or_else(|e| panic!("the graph resolves: {e}"));
    let text = first.lockfile.to_text();
    let reparsed = Lockfile::parse("kerf.lock", &text)
        .unwrap_or_else(|e| panic!("the written lockfile reparses: {e}"));
    assert_eq!(
        reparsed, first.lockfile,
        "the round-trip preserves the model"
    );
    assert_eq!(reparsed.to_text(), text, "serialization is idempotent");

    // Re-resolving the unchanged graph reproduces the same lockfile.
    let second = resolve(&dir).expect("the graph re-resolves");
    assert_eq!(
        second.lockfile.to_text(),
        text,
        "re-resolution is byte-identical (the reproducibility principle)"
    );
    // The name-identity ruling: one `left` per graph (0.1.2, reached
    // from the root's libs/left — the 0.9.9 twin is never visited).
    let left = second
        .lockfile
        .packages
        .iter()
        .find(|p| p.name == "left")
        .expect("left is recorded");
    assert_eq!(left.version.to_string(), "0.1.2");

    let _ = std::fs::remove_dir_all(&dir);
}

/// Negative: a missing root manifest names the expected path.
#[test]
fn missing_root_manifest_rejected() {
    let dir = fixture("no-root");
    match resolve(&dir) {
        Err(PkgError::ManifestNotFound { path }) => {
            assert!(path.ends_with("kerf.toml"), "the path names the manifest");
        }
        other => panic!("expected a missing-manifest error, got {other:?}"),
    }
    let _ = std::fs::remove_dir_all(&dir);
}

/// Negative: a missing dependency directory names the dependency and
/// the expected location.
#[test]
fn missing_dependency_directory_rejected() {
    let dir = fixture("no-dep");
    write_pkg(
        &dir,
        "package = \"app\"\nversion = \"0.1.0\"\n\n[depends]\nghost = \"0.1\"\n",
    );
    match resolve(&dir) {
        Err(PkgError::DepDirNotFound { name, dir: wanted }) => {
            assert_eq!(name, "ghost");
            assert!(
                wanted.ends_with("libs/ghost"),
                "the expected directory is named, got {}",
                wanted.display()
            );
        }
        other => panic!("expected a missing-dir error, got {other:?}"),
    }
    let _ = std::fs::remove_dir_all(&dir);
}

/// Negative: a dependency directory whose manifest declares a different
/// package name is rejected (the layout convention is an identity rule).
#[test]
fn directory_name_mismatch_rejected() {
    let dir = fixture("mismatch");
    write_pkg(
        &dir,
        "package = \"app\"\nversion = \"0.1.0\"\n\n[depends]\nleft = \"0.1\"\n",
    );
    write_pkg(
        &dir.join("libs/left"),
        "package = \"wrong-name\"\nversion = \"0.1.0\"\n",
    );
    match resolve(&dir) {
        Err(PkgError::ManifestInvalid { message, .. }) => assert!(
            message.contains("directory is named \"left\""),
            "the error names the directory and the declared package, got: {message}"
        ),
        other => panic!("expected a mismatch error, got {other:?}"),
    }
    let _ = std::fs::remove_dir_all(&dir);
}

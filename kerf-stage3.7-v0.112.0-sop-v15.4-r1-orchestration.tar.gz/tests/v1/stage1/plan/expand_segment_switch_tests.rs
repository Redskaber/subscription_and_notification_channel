//! Expand segment switch tests (T-a step-④ blade 2 —
//! w-t-a-switch-window §3 r146+ row): the EXPAND segment's
//! production position switch. The `.ktf` production expansion rides
//! the steady expander twin chain on the VM (the default); the Rust
//! expander retires to the oracle face (the parity comparison arm,
//! the seed chain's own expansion, and the rollback band —
//! `KERF_EXPAND_SEGMENT=rust`).
//!
//! Four faces, per the corpus discipline (GATE 6 composition):
//!
//! * **Positive** — the production position's expanded items are
//!   BIT-IDENTICAL to the oracle expansion's items across the
//!   curated family and the selfhost fixed points (the deepest
//!   inputs the expand chain owns — the language expanding its own
//!   twin family), on the DEFAULT stack.
//! * **Negative** — the rejection family: the production position
//!   rebuilds the SAME `ExpandError` / `ModuleError` (same parity
//!   key, same rendered diagnostic text — the junction-2 loader
//!   coverage included) as the oracle; the work-budget override
//!   rejects with the same key on both positions (the rollback
//!   band's parity obligation — the `ex_limit` budget mirroring).
//! * **Rollback band** — the position selector's three states
//!   (default twin, explicit rust, invalid fail-closed) and the two
//!   positions' agreement on the corpus.
//! * **Cross-stage consumption** — the production-position expansion
//!   feeds the whole spine (check → compile): the compiled bytecode
//!   equals the Rust-position bytecode, and the CLI check face
//!   rides the twin expansion end to end.
//!
//! The r146 stack-flat family (the K163 same-path sweep): the
//! forms-stream literal's right-spine Box-drop runs iteratively at
//! every injection site — the selfhost fixed points below expand
//! multi-KB sources through the twin chain on the ordinary
//! test-thread stack (the pre-sweep drop glue was one stack frame
//! per record cell).

use kerf::compiler::compile_program;
use kerf::driver::{
    self, Diagnostic, ExpandSegment, ProductionExpandError, Session, TARGET_PARSER_TWIN_CASES,
    expand_error_parity_key, parse_target, production_expand, render_diagnostics, run_cli,
};
use kerf::expander::{expand_program_with_limit, load_program};
use kerf::reader::read_target_program;
use kerf::span::FileId;

use crate::steady_target_reader_tests::SELFHOST_SOURCES;

const DEFAULT_BUDGET: usize = kerf::expander::EXPANSION_LIMIT;

/// One read-clean source's forms, expanded through BOTH positions,
/// must agree: `Ok(items)` vs `Ok(items)` (bit-identical) or the
/// SAME rejection key. The READ is the shared oracle arm (the read
/// switch is r145's own family's business — this family isolates
/// the expansion segment).
#[derive(Debug)]
enum ExpandOutcome {
    Items(Vec<kerf::core::ModuleItem>),
    Reject(String),
}

fn oracle_expand(forms: &[kerf::syntax::SyntaxObject], budget: usize) -> ExpandOutcome {
    match expand_program_with_limit(forms, budget) {
        Ok(items) => match load_program(&items) {
            // The loader's Ok carries the validated plan — the items
            // are what the spine forwards.
            Ok(_) => ExpandOutcome::Items(items),
            Err(err) => ExpandOutcome::Reject(key_of_module(&err)),
        },
        Err(err) => ExpandOutcome::Reject(expand_key_of(&err)),
    }
}

fn twin_expand(forms: &[kerf::syntax::SyntaxObject], budget: usize) -> ExpandOutcome {
    match production_expand(forms, budget, FileId(0)) {
        Ok(items) => ExpandOutcome::Items(items),
        // A defect is NOT a program rejection — it must panic the
        // test (a compiler defect never masquerades as a verdict).
        Err(ProductionExpandError::Program(err)) => {
            ExpandOutcome::Reject(expand_error_parity_key(&err))
        }
        Err(ProductionExpandError::Defect(msg)) => {
            panic!("the production expansion must not carry defects: {msg}")
        }
    }
}

fn expand_key_of(err: &kerf::expander::ExpandError) -> String {
    expand_error_parity_key(&driver::ParityError::Expand(err.clone()))
}

fn key_of_module(err: &kerf::expander::ModuleError) -> String {
    expand_error_parity_key(&driver::ParityError::Module(err.clone()))
}

fn assert_expand_positions_agree(name: &str, source: &str) {
    // The shared oracle read: read-level rejections are NOT this
    // family's subject (the r145 family owns them) — skip them.
    let forms = match read_target_program(FileId(0), source) {
        Ok(forms) => forms,
        Err(_) => return,
    };
    match (
        twin_expand(&forms, DEFAULT_BUDGET),
        oracle_expand(&forms, DEFAULT_BUDGET),
    ) {
        (ExpandOutcome::Items(a), ExpandOutcome::Items(b)) => {
            assert_eq!(
                a, b,
                "the twin and oracle expansions must be identical on {name}"
            );
        }
        (ExpandOutcome::Reject(a), ExpandOutcome::Reject(b)) => {
            assert_eq!(
                a, b,
                "the twin and oracle expansion rejections must carry the same key on {name}"
            );
        }
        (twin, oracle) => {
            panic!("the expand positions disagree on {name}: twin {twin:?} vs oracle {oracle:?}");
        }
    }
}

// ---------- positive: the production position holds the corpus ----------

/// The curated target family (both polarities): every case whose
/// read succeeds expands identically on both positions — the
/// default flip's own sweep (acceptances and rejections alike).
#[test]
fn the_curated_family_expands_identically_on_both_positions() {
    for &(name, source) in TARGET_PARSER_TWIN_CASES {
        assert_expand_positions_agree(name, source);
    }
}

/// The nine selfhost sources + the assembled expander program — the
/// deepest fixed points, on the DEFAULT stack (the r146 stack-flat
/// family: the forms-stream literal's right-spine Box-drop glue was
/// one stack frame per record cell before the iterative dispose —
/// a 60KB source = tens of thousands of cells, exactly the r145
/// exposure shape).
#[test]
fn the_selfhost_fixed_points_expand_on_a_default_stack() {
    let mut sources: Vec<(&str, &str)> = SELFHOST_SOURCES.to_vec();
    let assembled = kerf::driver::assembled_expander_target_source();
    sources.push(("assembled-expander.ktf", assembled.as_str()));
    for (name, source) in &sources {
        assert_expand_positions_agree(name, source);
    }
}

// ---------- negative: the rejection family ----------

/// The expansion rejection family through the PRODUCTION position:
/// each case rebuilds the oracle's own error, so the rendered
/// diagnostic text (the user-facing face) is identical on both
/// positions — span-for-span, message-for-message — including at a
/// NON-zero file id (the span-retarget face: a rebuilt span naming
/// the wrong file renders against the wrong source).
#[test]
fn rejections_render_identically_on_both_positions() {
    let rejections: &[(&str, &str)] = &[
        ("unbound", "define(result, y);\n"),
        ("top-level", "1 + 2;\n"),
        // The .ktf reader enforces the let-stmt shape at the parse
        // layer (no read-clean malformed let exists in this skin —
        // `let = 1;` is a READ rejection), so the malformed-form
        // family rides the match desugar instead: a match whose
        // last arm is a literal is read-clean but non-exhaustive
        // at the expansion layer (the r143 match-arm error kind).
        (
            "non-exhaustive",
            "fn pick(p) { match p { 1 => { 10 }, } }\n",
        ),
        // The malformed macro-declaration face: the .ktf macro
        // grammar reads any datum as the spec (`macro m { 5 }` is
        // read-clean — the spec slot is a datum channel), but the
        // spec must be a `(syntax-rules ...)` LIST at the expansion
        // layer — a bare literal rejects as MalformedForm
        // ("define-syntax") on both positions (the reserved-NAME
        // face and the let-shape face are unreachable in this skin:
        // every reserved macro name lexes as a keyword, the let-stmt
        // shape is parse-enforced — the datum slot is the one
        // read-clean carrier the skin offers). A zero-arg call
        // (`f( )`) is NOT a rejection — it is a legal call shape.
        ("malformed-macro", "macro m { 5 }\n"),
    ];
    for &(name, source) in rejections {
        // The session interns the source at a NON-zero file id (the
        // span-retarget face — a rebuilt span naming the wrong file
        // renders against the wrong source); BOTH positions' errors
        // must name THIS id (the twin retargets its rebuilt spans;
        // the oracle's own spans ride the forms read at this id).
        let mut session = Session::new();
        let _zero = session.intern("zero.ktf", "fn z() { 0 }");
        let file = session.intern(name, source);
        let forms = read_target_program(file, source)
            .unwrap_or_else(|e| panic!("the rejection case {name} must READ clean: {e:?}"));
        let (twin_err, oracle_err) = match (
            production_expand(&forms, DEFAULT_BUDGET, file),
            expand_program_with_limit(&forms, DEFAULT_BUDGET),
        ) {
            (Err(ProductionExpandError::Program(t)), Err(o)) => (t, o),
            other => panic!(
                "the expansion rejection case {name} must reject on both positions: {other:?}"
            ),
        };
        // The same parity key (the harness contract) ...
        assert_eq!(
            expand_error_parity_key(&twin_err),
            expand_key_of(&oracle_err),
            "the rejection key must match on {name}"
        );
        // ... AND the same user-facing diagnostic: render both
        // against the SAME session (both name the same file id —
        // the retargeted rebuilt spans vs the oracle's own).
        let twin_expand_err = match &twin_err {
            driver::ParityError::Expand(e) => e.clone(),
            driver::ParityError::Module(_) => {
                panic!("the case {name} must be an expansion rejection, not a loader one")
            }
        };
        let twin_diag = Diagnostic::from_expand(&twin_expand_err);
        let oracle_diag = Diagnostic::from_expand(&oracle_err);
        let twin_text = render_diagnostics(&session, &[twin_diag]);
        let oracle_text = render_diagnostics(&session, &[oracle_diag]);
        assert_eq!(
            twin_text, oracle_text,
            "the rendered diagnostic must be identical on both positions for {name}"
        );
    }
}

/// The junction-2 loader coverage: the twin's verdict carries the
/// module-loader rejections (missing / duplicate / cycle) — the
/// production position rebuilds the same `ModuleError` the oracle's
/// own expand → load spine produces, same key for key (the twin arm
/// never re-runs the Rust loader; the twin IS the loader face here).
#[test]
fn the_module_loader_rejections_cover_junction_two() {
    let cases: &[(&str, &str)] = &[
        ("mod-missing", "use \"ghost\";\nfn main() { 1 }\n"),
        (
            "mod-dup",
            "module m { define(x, 1); }\nmodule m { define(x, 2); }\n",
        ),
        (
            "mod-cycle",
            "module a { use \"b\"; }\nmodule b { use \"a\"; }\n",
        ),
    ];
    for &(name, source) in cases {
        let forms = read_target_program(FileId(0), source)
            .unwrap_or_else(|e| panic!("the module case {name} must READ clean: {e:?}"));
        let (twin_key, oracle_key) = match (
            production_expand(&forms, DEFAULT_BUDGET, FileId(0)),
            oracle_expand(&forms, DEFAULT_BUDGET),
        ) {
            (Err(ProductionExpandError::Program(t)), ExpandOutcome::Reject(o)) => {
                (expand_error_parity_key(&t), o)
            }
            other => panic!("the module case {name} must reject on both positions: {other:?}"),
        };
        assert_eq!(
            twin_key, oracle_key,
            "the junction-2 loader rejection key must match on {name}"
        );
    }
}

/// The work-budget override: BOTH positions honor the effective
/// `KERF_EXPANSION_LIMIT` — a source within the default budget
/// expands on both positions, and an over-budget source rejects
/// with the SAME key on both (the rollback band's parity
/// obligation — the twin's `ex_limit` prefix mirrors the process
/// budget, the `tp_limit` precedent).
#[test]
fn the_budget_override_is_honored_by_both_positions() {
    // The deep shape: nested `if (true) { ... } else { 0 }` blocks —
    // one expansion-depth level per nest (the r145 family's own
    // generated-nesting grammar).
    let deep = |n: usize| {
        let mut src = String::from("define(result, ");
        for _ in 0..n {
            src.push_str("if (true) { ");
        }
        src.push('1');
        for _ in 0..n {
            src.push_str(" } else { 0 }");
        }
        src.push_str(");");
        src
    };
    // Within the DEFAULT budget (512): both positions accept a
    // 50-deep nest.
    let source = deep(50);
    let forms = read_target_program(FileId(0), &source).expect("the 50-deep nest must read");
    assert!(
        matches!(twin_expand(&forms, DEFAULT_BUDGET), ExpandOutcome::Items(_))
            && matches!(
                oracle_expand(&forms, DEFAULT_BUDGET),
                ExpandOutcome::Items(_)
            ),
        "a 50-deep nest must expand under the default budget on both positions"
    );
    // A TIGHT budget (8): a 30-deep nest rejects with the same key
    // on both positions (the `ex_limit` mirroring).
    let source = deep(30);
    let forms = read_target_program(FileId(0), &source).expect("the 30-deep nest must read");
    match (twin_expand(&forms, 8), oracle_expand(&forms, 8)) {
        (ExpandOutcome::Reject(a), ExpandOutcome::Reject(b)) => assert_eq!(
            a, b,
            "the over-budget rejection key must match on both positions"
        ),
        other => panic!("a 30-deep nest must reject under an 8 budget on both: {other:?}"),
    }
}

// ---------- the rollback band ----------

/// The selector's three states: the library default is the switched
/// position (`Twin`); an explicit `Rust` session rides the oracle;
/// an invalid env value is a hard error (fail-closed — the
/// `KERF_READ_SEGMENT` precedent).
#[test]
fn the_rollback_band_three_states() {
    // 1. The env value's parse face (pure — no ambient state).
    assert_eq!(ExpandSegment::parse_value("twin"), Ok(ExpandSegment::Twin));
    assert_eq!(ExpandSegment::parse_value("rust"), Ok(ExpandSegment::Rust));
    for bad in ["", "twins", "TWIN", "c", "0"] {
        assert!(
            ExpandSegment::parse_value(bad).is_err(),
            "`{bad}` must fail closed"
        );
    }
    // 2. The session default is the switched position; the pinned
    //    session rides the Rust expander — and BOTH parse the same
    //    source to the same items (the band's parity).
    let source = "fn add(a, b) { a + b }\nfn main() { add(1, 2) }\n";
    let mut twin_session = Session::new();
    let twin_program = parse_target(&mut twin_session, "band.ktf", source)
        .unwrap_or_else(|d| panic!("the twin position must parse: {d:?}"));
    assert_eq!(twin_program.expand_segment, ExpandSegment::Twin);
    assert_eq!(twin_program.read_segment, kerf::driver::ReadSegment::Twin);
    let mut rust_session = Session::with_segments(
        kerf::driver::ReadSegment::Rust,
        ExpandSegment::Rust,
        kerf::driver::CheckSegment::Rust,
        kerf::driver::CompileSegment::Rust,
    );
    let rust_program = parse_target(&mut rust_session, "band.ktf", source)
        .unwrap_or_else(|d| panic!("the rust position must parse: {d:?}"));
    assert_eq!(rust_program.expand_segment, ExpandSegment::Rust);
    assert_eq!(
        twin_program.items, rust_program.items,
        "the two positions must produce identical items"
    );
    // 3. The r151 retarget: the third band face — the S-expr
    //    reader's disclosure reporting `ExpandSegment::Rust` —
    //    retired with the S-expr read API itself (W-SEXP-RETIRE
    //    blade 2; the .krf face no longer has a reader, so there is
    //    no expansion segment to disclose). The two live positions
    //    keep the band's parity above.
}

// ---------- cross-stage consumption ----------

/// The production-position expansion feeds the WHOLE spine: parse →
/// typecheck (clean) → compile, and the compiled bytecode equals the
/// Rust-position bytecode bit-for-bit (the C1 formula at the
/// expand-switched position — the segment-switch parity gate).
#[test]
fn the_production_position_feeds_the_whole_spine() {
    // The deep subject is the expander twin in its CCF form (the
    // extern slot declaration + the ex_limit prefix + the macro
    // library + the expander body — the TA-1 chain-compilable
    // form): the bare assembled body is NOT self-contained (its
    // `forms` entry reference binds against the extern slot, its
    // `ex_is_name_member` call sites bind against the macro
    // library — the bare body legitimately rejects as unbound on
    // BOTH positions, which is the fixed-point family's agreement
    // face, not a positive spine subject).
    let ccf_expander = kerf::driver::ccf_expander_source();
    let subjects: Vec<(&str, &str)> = vec![
        (
            "curated-fn",
            "fn add(a, b) { a + b }\nfn main() { add(1, 2) }\n",
        ),
        (
            "curated-match",
            "fn pick(p) { match p { 1 => { 10 }, _ => { 20 }, } }\nfn main() { pick(1) }\n",
        ),
        ("ccf-expander-twin", ccf_expander.as_str()),
    ];
    for (name, source) in &subjects {
        let mut twin_session = Session::new();
        let twin_program = parse_target(&mut twin_session, name, source)
            .unwrap_or_else(|d| panic!("the twin position must parse {name}: {d:?}"));
        assert_eq!(twin_program.expand_segment, ExpandSegment::Twin);
        let findings = twin_program.typecheck();
        assert!(
            !findings
                .iter()
                .any(|d| d.severity == kerf::driver::Severity::Error),
            "the twin position must check clean on {name}: {findings:?}"
        );
        let twin_bc = compile_program(&twin_program.items)
            .unwrap_or_else(|e| panic!("the twin position must compile {name}: {e}"));
        let mut rust_session = Session::with_segments(
            kerf::driver::ReadSegment::Rust,
            ExpandSegment::Rust,
            kerf::driver::CheckSegment::Rust,
            kerf::driver::CompileSegment::Rust,
        );
        let rust_program = parse_target(&mut rust_session, name, source)
            .unwrap_or_else(|d| panic!("the rust position must parse {name}: {d:?}"));
        let rust_bc = compile_program(&rust_program.items)
            .unwrap_or_else(|e| panic!("the rust position must compile {name}: {e}"));
        assert_eq!(
            twin_bc, rust_bc,
            "the two positions must compile to identical bytecode on {name}"
        );
    }
}

/// The CLI check face rides the twin expansion end to end (the
/// process-entry default; `KERF_EXPAND_SEGMENT` unset): a clean
/// `.ktf` program checks green, and a program the EXPANSION rejects
/// renders the same diagnostic the Rust position renders (the
/// user-facing equivalence of the band).
#[test]
fn the_cli_check_face_rides_the_twin_expansion() {
    let clean = "fn main() { 40 + 2 }\n";
    let mut out = Vec::new();
    let mut err = Vec::new();
    let code = run_cli(
        &["check".to_string(), "main.ktf".to_string()],
        &|_| Ok(clean.to_string()),
        &mut || None,
        Vec::new(),
        &mut out,
        &mut err,
    );
    assert_eq!(code, 0, "the clean program must check green: {err:?}");
    assert!(
        String::from_utf8_lossy(&out).contains("ok"),
        "the check face must report ok: {out:?}"
    );
    // An expansion-rejected program renders — exit 1, the
    // diagnostic batch on the error sink, and the RENDERED TEXT
    // equals the Rust position's own rendering of the same source.
    let broken = "define(result, nowhere);\n";
    let mut out = Vec::new();
    let mut err = Vec::new();
    let code = run_cli(
        &["check".to_string(), "main.ktf".to_string()],
        &|_| Ok(broken.to_string()),
        &mut || None,
        Vec::new(),
        &mut out,
        &mut err,
    );
    assert_eq!(
        code, 1,
        "the expansion-rejected program must fail the check"
    );
    let twin_text = String::from_utf8_lossy(&err).into_owned();
    let mut rust_session = Session::with_segments(
        kerf::driver::ReadSegment::Rust,
        ExpandSegment::Rust,
        kerf::driver::CheckSegment::Rust,
        kerf::driver::CompileSegment::Rust,
    );
    let rust_program = parse_target(&mut rust_session, "main.ktf", broken).unwrap_err();
    let oracle_text = render_diagnostics(&rust_session, &rust_program);
    assert_eq!(
        twin_text.trim(),
        oracle_text.trim(),
        "the CLI diagnostic must equal the rust position's rendering"
    );
}

// ---------- the seed pins (the dual-chain decoupling) ----------

/// The seed faces stay pinned to the Rust expander (the step-④
/// dual-chain decoupling, the expansion half): the injection-channel
/// front end (`parse_target_with_injected` — the twin chains' own
/// construction entry; a production-position expansion there would
/// be circular), the bootstrap bridge
/// (`read_target_source_for_bootstrap`), and the A/B/C A pass
/// (`rust_compile_ccf`) must keep their expansions on the Rust arm
/// — if any rode the switched production position, the fixpoint
/// purity leg and the A ≡ B observation row would collapse into
/// self-comparisons (detection power zero). A source-scan guard
/// (the TEST-2/TEST-3 precedent — machine-checked source
/// invariants).
#[test]
fn the_seed_faces_stay_pinned_to_the_rust_expander() {
    let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR"));
    // (file, the function to window, the anchors that must appear
    // in the window — the inlined Rust expansion or the explicit
    // with_segments pin).
    let pins: &[(&str, &str, &[&str])] = &[
        (
            "crates/kerf-driver/src/pipeline.rs",
            "pub fn parse_target_with_injected",
            &[
                "expand_program_with_injected_and_limit",
                "ExpandSegment::Rust",
            ],
        ),
        (
            "crates/kerf-driver/src/bootstrap/target_corpus.rs",
            "pub fn read_target_source_for_bootstrap",
            &["with_segments", "ExpandSegment::Rust"],
        ),
        (
            "crates/kerf-driver/src/bootstrap/abc_pipeline.rs",
            "pub fn rust_compile_ccf",
            &["with_segments", "ExpandSegment::Rust"],
        ),
    ];
    for (path, face, anchors) in pins {
        let src = std::fs::read_to_string(root.join(path))
            .unwrap_or_else(|e| panic!("the {face} source must read: {e}"));
        let start = src
            .find(face)
            .unwrap_or_else(|| panic!("the {face} declaration must exist in {path}"));
        // The construction window: the function's first 2,000
        // characters (every pin sits inside the constructor body).
        let window = &src[start..(start + 2000).min(src.len())];
        for anchor in *anchors {
            assert!(
                window.contains(anchor),
                "{face} must keep the Rust-expansion pin (missing `{anchor}` — the \
                 fixpoint differential's detection power depends on it; see the step-④ \
                 dual-chain decoupling)"
            );
        }
    }
}

// The r151 retirement record (W-SEXP-RETIRE blade 2): the S-expr
// seed-expander spot-check (`the_sexpr_seed_face_is_untouched` — a
// `parse`/`read_program` + `expand_program_with_limit` parity pin
// over `(define x 1)`) retired with its subject: the S-expression
// read API no longer exists in the crate, so there is no seed face
// to keep untouched and no S-expr forms to expand. The oracle
// expansion arm itself stays pinned by the rollback-band and
// rejection tests above (the explicit `ExpandSegment::Rust`
// position on target-skin forms, items and rendered diagnostics
// identical to the twin position's).

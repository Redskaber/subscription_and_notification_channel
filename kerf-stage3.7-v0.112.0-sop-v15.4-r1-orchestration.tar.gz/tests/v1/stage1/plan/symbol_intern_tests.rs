//! Stage-interlude integration tests for the interned symbol payload
//! (v0.23.0, docs/stage0.md §9.52) — the cross-crate face of the
//! representation change: identifier-heavy programs must compile, run,
//! and diagnose identically through the whole
//! reader → expander → (compiler → vm | evaluator) chain.
//!
//! Layering note (SOP §8.4.6 rule 7): these are cross-crate assertions
//! about the *pipeline behavior* over interned identities, so they live
//! in the root tree; the representation invariants themselves are unit
//! tests inside the two owning crates.

use kerf::driver::{CorpusCase, Engine, Session, run_parity_source, run_source, validate};

/// A symbol-heavy program: repeated use of the same names, shadowing
/// chains, wide frames (the compile-time reverse-scan face), and a
/// closure — the interned-identity stress shape across every pipeline
/// stage that consumes symbols.
const SYMBOL_HEAVY: &str = "\
fn twice(x) { (2 * x) }
fn compute(alpha, beta) {
    let alpha = twice(alpha);
    let beta = (alpha + beta);
    (alpha + beta)
}
fn wide(a, b, c, d, e, f, g, h) {
    (a + (b + (c + (d + (e + (f + (g + h)))))))
}
fn add_two(operand) { (operand + 2) }
define(result, (compute(4, 1) + (wide(1, 2, 3, 4, 5, 6, 7, 8) + add_two(5))));";

// ---------- positive ----------

#[test]
fn symbol_heavy_program_runs_on_vm_engine() {
    let mut s = Session::new();
    let out =
        run_source(&mut s, "symbol-heavy.ktf", SYMBOL_HEAVY, Engine::Vm, &[]).expect("vm run");
    // compute 4 1 = 17, wide 1..8 = 36, add-two 5 = 7 → 60.
    assert_eq!(
        out.global("result").expect("result stored").to_string(),
        "60"
    );
}

#[test]
fn symbol_heavy_program_runs_on_eval_engine() {
    let mut s = Session::new();
    let out =
        run_source(&mut s, "symbol-heavy.ktf", SYMBOL_HEAVY, Engine::Eval, &[]).expect("eval run");
    assert_eq!(
        out.global("result").expect("result stored").to_string(),
        "60"
    );
}

#[test]
fn shadowed_names_resolve_to_the_innermost_binding() {
    // Same text, distinct bindings: interned identity must not collapse
    // the *binding* structure — the innermost let wins at each step.
    let source = "\
fn shadow(x) { (x + 1) }
define(r, { let x = 10; let x = shadow(x); x });";
    let mut s = Session::new();
    let out = run_source(&mut s, "shadow.ktf", source, Engine::Vm, &[]).expect("vm run");
    assert_eq!(out.global("r").expect("r stored").to_string(), "11");
}

// ---------- cross-stage consumption ----------

#[test]
fn symbol_heavy_program_agrees_across_both_engines() {
    // The parity face: the same interned-symbol program through
    // compiler → vm on one side and the evaluator on the other.
    let mut s = Session::new();
    let report =
        run_parity_source(&mut s, "symbol-heavy.ktf", SYMBOL_HEAVY, &[]).expect("parity run");
    assert!(report.agrees(), "drift: {report:?}");
    assert!(report.globals_agree, "result must be `60` on both engines");
}

#[test]
fn parity_contract_flags_wrong_expectation_for_symbol_heavy_program() {
    // The detector-detects duality: a wrong expectation over the
    // symbol-heavy program must be flagged as drift, not swallowed.
    let case = CorpusCase::from_source(
        "symbol-heavy-wrong",
        ";; expect: value 61\nfn twice(x) { (2 * x) }\ndefine(result, twice(30));",
    )
    .expect("directive parses");
    let report = validate(&case);
    assert!(!report.matched, "wrong expectation must be flagged");
}

// ---------- negative ----------

#[test]
fn unbound_identifier_diagnostic_keeps_exact_name_text() {
    // Interning must not garble diagnostics: the rejected program's
    // error message carries the exact identifier text.
    let mut s = Session::new();
    let diags = run_source(
        &mut s,
        "unbound.ktf",
        "define(result, (1 + very_unbound_name_xyz));",
        Engine::Vm,
        &[],
    )
    .expect_err("unbound identifier must be rejected");
    assert!(
        diags
            .iter()
            .any(|d| d.message.contains("very_unbound_name_xyz")),
        "diagnostic must carry the exact name: {diags:?}"
    );
}

#[test]
fn unbound_name_inside_lambda_body_is_rejected() {
    // The deferred-shape face: a free name inside a lambda body is
    // resolved during expansion and rejected with the exact text.
    let mut s = Session::new();
    let diags = run_source(
        &mut s,
        "unbound-lambda.ktf",
        "fn make(b) { ||(u){ (u + missing_capture_name) } }\n\
         define(cl, make(1));\n\
         define(result, cl(2));",
        Engine::Vm,
        &[],
    )
    .expect_err("unbound lambda-body name must be rejected");
    assert!(
        diags
            .iter()
            .any(|d| d.message.contains("missing_capture_name")),
        "diagnostic must carry the exact name: {diags:?}"
    );
}

// ---------- v0.27.0 single-pool identity (stage0.md §9.58) ----------

#[test]
fn same_text_is_one_identity_across_the_syntax_and_core_faces() {
    // The crate boundary unification (v0.27.0, stage0.md §9.58): the
    // surface layer and the core layer share ONE interner in kerf-span
    // (the rustc `rustc_span::Symbol` precedent, K78). Constructing the
    // same text through the syntax face and through the core face must
    // land on the very same `Symbol` — equality, hashing, and `as_str`
    // all agree. Pre-v0.27.0 this compared two pool-local twins through
    // a text bridge; the unified assertion pins the identity semantics
    // the Stage 2 lexical-addressing work builds on (§9.52.5).
    use std::collections::hash_map::DefaultHasher;
    use std::hash::{Hash, Hasher};

    let via_syntax = {
        let scopes = kerf::syntax::ScopeSet::default();
        let phase = kerf::syntax::Phase::from_u8(0).expect("runtime phase");
        let span = kerf::span::Span::new(
            kerf::span::FileId(0),
            kerf::span::ByteOffset(0),
            kerf::span::ByteOffset(6),
            kerf::span::ExpansionId::ROOT,
        )
        .expect("probe span");
        let object = kerf::syntax::SyntaxObject::symbol(span, scopes, phase, "pool-probe")
            .expect("floor-valid name must construct");
        match object.datum {
            kerf::syntax::StxDatum::Symbol(sym) => sym,
            other => panic!("expected symbol datum, got {other:?}"),
        }
    };
    let via_core = kerf::span::Symbol::new("pool-probe").expect("floor-valid name must construct");

    assert_eq!(via_syntax, via_core, "one pool: one identity per text");
    assert_eq!(via_syntax.as_str(), "pool-probe");
    assert_eq!(
        std::mem::size_of_val(&via_syntax),
        std::mem::size_of_val(&via_core)
    );

    let hash = |s: &kerf::span::Symbol| {
        let mut hasher = DefaultHasher::new();
        s.hash(&mut hasher);
        hasher.finish()
    };
    assert_eq!(hash(&via_syntax), hash(&via_core));
    // A distinct text must stay a distinct identity.
    assert_ne!(
        via_core,
        kerf::span::Symbol::new("pool-prob").expect("distinct text")
    );
}

#[test]
fn syntax_and_core_error_faces_share_one_rendering_source() {
    // The single-source dictionary after the v0.27.0 unification: the
    // three consumer faces (reader, syntax, core) all delegate their
    // `invalid symbol` rendering to kerf_span::SymbolError, so the same
    // rejected text renders byte-identically on every face.
    let inner = kerf::span::SymbolError::InvalidSymbol {
        text: "a b".to_owned(),
    };
    let expected =
        "invalid symbol `a b`: must be non-empty with no whitespace or control characters";
    assert_eq!(
        kerf::syntax::SyntaxError::InvalidSymbol(inner.clone()).to_string(),
        expected
    );
    assert_eq!(
        kerf::core::CoreError::InvalidSymbol(inner.clone()).to_string(),
        expected
    );
    assert_eq!(
        kerf::reader::ReadError::InvalidSymbol(inner).to_string(),
        expected
    );
}

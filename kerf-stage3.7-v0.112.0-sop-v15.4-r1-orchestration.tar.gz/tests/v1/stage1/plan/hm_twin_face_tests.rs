//! The W-HM-TWIN 127-d integration verification (w-hm-twin-window.md
//! §4, the MUV boundary): the test face — the paired positive/negative
//! probes on BOTH judgment faces (one probe set, the infer twin and
//! the check twin, both oracles — the 127-a/b rounds' probes were
//! face-specific, this family pins the pairing), the corpus HM-axis
//! reclassification (every corpus row classified exactly once on the
//! inference axis AND the check axis with the exact counts and the
//! diagnostic-carrying row names pinned — the sweeps rode lower
//! bounds, this pin turns any corpus change that shifts either axis
//! into a visible break instead of a silent ride), and the budget
//! row's per-source route (the 127-a budget row rode the steady
//! route only; the E0011 face through the recompile-per-case route —
//! the delivery face the steady chain exists to amortize).
//!
//! Probe discipline (the sweep precedents): the paired probes ride the
//! HM negative family (the E0009/E0010 faces) and the accept anchors;
//! the corpus classification rides the same read→expand→feed gate the
//! sweeps use; the budget's far side only rides the programmatic path
//! (the reader's nesting cap is 256).
//!
//! W-SEXP-RETIRE blade 2 (r151): the probe sources ride the target
//! skin (the corpus-dictionary respell), one semantic twin per row.

use kerf::core::{CoreExpr, LiteralValue, ModuleItem};
use kerf::driver::{
    Session, Severity, SteadyCheckChain, SteadyTypecheckChain, infer_twin_per_source_dual,
    oracle_check_axes, oracle_inference_axes, parse_target,
};
use kerf::expander::expand_program;
use kerf::reader::read_target_program;
use kerf::span::{ByteOffset, ExpansionId, FileId, Span, Symbol};

const CORPUS_DIR: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/tests/v1/stage1/corpus");

/// Deep trees (the corpus's nesting family) recurse through the
/// harness's Rust tree walkers; the demand-allocated stack discipline
/// of the sibling chain tests (the steady-expander precedent).
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly");
}

fn sp(a: u32, b: u32) -> Span {
    Span::new(FileId(0), ByteOffset(a), ByteOffset(b), ExpansionId::ROOT)
        .expect("test span is ordered")
}

fn sym(text: &str) -> Symbol {
    Symbol::new(text).expect("test symbol is valid")
}

/// Expand one probe source into the item stream both faces consume.
fn items_of(source: &str) -> Vec<ModuleItem> {
    let forms = read_target_program(FileId(0), source).expect("the probe reads");
    expand_program(&forms).expect("the probe expands")
}

/// The paired probe family — every row runs through BOTH judgment
/// faces (the infer chain + its oracle, the check chain + its oracle):
/// the positive rows and the HM negative family, one set, both axes.
const PAIRED_PROBES: &[(&str, &str)] = &[
    // ---- positive: the accept anchors ----
    (
        "accept-anchor",
        "fn fib(n) { if ((n < 2)) { n } else { (fib((n - 1)) + fib((n - 2))) } }",
    ),
    (
        "let-polymorphism",
        "fn id(x) { x }\nfn a(y) { id(1) }\nfn b(z) { id(true) }",
    ),
    (
        "handle-rows",
        "fn f(x) { handle (perform log(x)) { log(v) => { v }, } }",
    ),
    (
        "module-flat-table",
        "module m { define(x, 1); fn f(y) { y } }",
    ),
    // ---- negative: the HM family (the E0009/E0010 faces) ----
    (
        "t1-bool-demand",
        "fn f(x) { if (x) { 1 } else { 2 } }\nfn g(y) { f(1) }",
    ),
    ("t2-not-callable", "fn f(y) { ((1 + 2))(3) }"),
    ("t3-non-numeric", "fn f(x) { (x + \"a\") }"),
    ("t5-cond-mismatch", "fn f(x) { if (1) { 2 } else { 3 } }"),
    ("t7-occurs", "define(omega, ||(x) { x(x) });"),
    // The empty stream (the nil payload — the zero-define module).
    ("empty-stream", "// nothing but trivia\n"),
];

/// One paired-probe drive: both judgment faces, both oracles, twin ≡
/// oracle on each axis (the shared body the positive and negative
/// family tests below consume).
fn paired_drive(
    infer_chain: &SteadyTypecheckChain,
    check_chain: &SteadyCheckChain,
    name: &str,
    items: &[ModuleItem],
) -> (String, String) {
    let infer_twin = infer_chain
        .infer(items)
        .unwrap_or_else(|e| panic!("{name}: the twin inference runs: {e}"));
    assert_eq!(
        infer_twin,
        oracle_inference_axes(items),
        "{name}: the inference twin matches the oracle"
    );
    let check_twin = check_chain
        .check(items)
        .unwrap_or_else(|e| panic!("{name}: the twin check runs: {e}"));
    assert_eq!(
        check_twin,
        oracle_check_axes(items),
        "{name}: the check twin matches the oracle"
    );
    (infer_twin, check_twin)
}

#[test]
fn hm_twin_face_positive_probes_match_on_both_faces() {
    deep_stack(|| {
        let infer_chain = SteadyTypecheckChain::new().expect("the fixed inference twin builds");
        let check_chain = SteadyCheckChain::new().expect("the fixed checker twin builds");
        for (name, source) in PAIRED_PROBES {
            if !matches!(
                *name,
                "accept-anchor" | "let-polymorphism" | "handle-rows" | "module-flat-table"
            ) {
                continue;
            }
            let items = items_of(source);
            let (infer_twin, check_twin) = paired_drive(&infer_chain, &check_chain, name, &items);
            // The positive rows are clean on both axes.
            assert!(
                infer_twin.starts_with("(ok (types"),
                "{name}: the positive row's inference verdict is clean: {infer_twin}"
            );
            assert!(
                check_twin.starts_with("(ok (table"),
                "{name}: the positive row's check verdict is clean: {check_twin}"
            );
        }
        // The empty stream's exact zero-define verdicts on both axes.
        let empty_items = items_of("// nothing but trivia\n");
        let (empty_infer, empty_check) =
            paired_drive(&infer_chain, &check_chain, "empty-stream", &empty_items);
        assert_eq!(
            empty_infer, "(ok (types) (diags))",
            "the empty stream infers to the zero-define module"
        );
        assert_eq!(
            empty_check, "(ok (table (defines) (assigned)) (diags))",
            "the empty stream checks to the zero-define module"
        );
    });
}

#[test]
fn hm_twin_face_negative_probes_match_on_both_faces() {
    deep_stack(|| {
        let infer_chain = SteadyTypecheckChain::new().expect("the fixed inference twin builds");
        let check_chain = SteadyCheckChain::new().expect("the fixed checker twin builds");
        for (name, source) in PAIRED_PROBES {
            if !matches!(
                *name,
                "t1-bool-demand"
                    | "t2-not-callable"
                    | "t3-non-numeric"
                    | "t5-cond-mismatch"
                    | "t7-occurs"
            ) {
                continue;
            }
            let items = items_of(source);
            let (infer_twin, _check_twin) = paired_drive(&infer_chain, &check_chain, name, &items);
            // The negative rows report on the inference axis (the
            // detection-power arm — a guard that passes because
            // nothing fired pins nothing).
            assert!(
                infer_twin.contains("E00"),
                "{name}: the negative row really reports: {infer_twin}"
            );
            // And the twin's verdict is an ok-carrier (the HM judgment
            // face collects findings — the module still loads).
            assert!(
                infer_twin.starts_with("(ok (types"),
                "{name}: the negative row rides the ok carrier: {infer_twin}"
            );
        }
    });
}

/// The corpus HM-axis reclassification: every corpus row classified
/// exactly once on BOTH axes with the exact counts pinned — the
/// diagnostic-carrying fed rows by name, the clean fed rows by count,
/// the layer rejections by count. Any corpus change that shifts the
/// classification (a row moving between clean and diagnostic, a new
/// row, a dropped row) breaks this pin instead of silently riding the
/// sweeps' lower bounds.
///
/// W-SEXP-RETIRE blade 1 (v0.111.0): the classification rides the
/// TARGET reader over the migrated `.ktf` corpus (109 cases — the
/// three skin-divergent rows retired per w-sexp-retire-window SR-2).
/// The stage-divergent family (the malformed keyword-headed forms)
/// moved from the expansion rows to the READER rows — the target
/// grammar rejects what the permissive S-expr reader deferred to the
/// expander (the r130 measured face, re-measured on the target face
/// at the migration).
#[test]
fn corpus_hm_axis_classification_is_pinned_on_both_axes() {
    deep_stack(|| {
        // The classification rides the ORACLES (the twin ≡ oracle
        // equivalence is the sweeps' own face — pinning the corpus's
        // axis through the oracle pins the twin's axis transitively).
        let entries = std::fs::read_dir(CORPUS_DIR).expect("the corpus directory is in tree");
        let mut files: Vec<_> = entries
            .filter_map(|e| e.ok())
            .map(|e| e.path())
            .filter(|p| p.extension().is_some_and(|x| x == "ktf"))
            .collect();
        files.sort();
        assert_eq!(
            files.len(),
            109,
            "the corpus is 109 .ktf cases (112 minus the three retired divergences — SR-2)"
        );
        let mut reader_rejected = Vec::new();
        let mut expansion_rejected = Vec::new();
        let mut infer_diagnostic = Vec::new();
        let mut check_diagnostic = Vec::new();
        let mut infer_clean = 0usize;
        let mut check_clean = 0usize;
        for path in &files {
            let source = std::fs::read_to_string(path).expect("corpus file reads");
            let case = path.file_name().unwrap().to_string_lossy().to_string();
            // The classification rides the PIPELINE spine (the same
            // read → expand → LOAD machinery the corpus contract's
            // `validate_target` uses — the loader runs inside the
            // session; the ruling-D path-form module twins reject
            // there, the bare expander never sees them).
            let parsed = {
                let mut session = Session::new();
                parse_target(&mut session, &case, &source)
            };
            let items = match parsed {
                Ok(program) => program.items,
                Err(diags) => {
                    let tag = diags
                        .iter()
                        .find(|d| d.severity == Severity::Error)
                        .map(|d| d.code.tag())
                        .expect("a rejection carries an error diagnostic");
                    if tag == "kerf-read" {
                        reader_rejected.push(case);
                    } else {
                        // kerf-expand: the expander AND the module
                        // loader (the ruling-D family's rejection
                        // class — same row as before the migration).
                        expansion_rejected.push(case);
                    }
                    continue;
                }
            };
            // The inference axis: fed rows split by the diagnostics
            // channel (warnings ride too — E0011 is a finding).
            let infer_verdict = oracle_inference_axes(&items);
            if infer_verdict.contains("E00") {
                infer_diagnostic.push(case.clone());
            } else {
                infer_clean += 1;
            }
            // The check axis: the same split on the check oracle.
            let check_verdict = oracle_check_axes(&items);
            if check_verdict.contains("E00") {
                check_diagnostic.push(case);
            } else {
                check_clean += 1;
            }
        }
        // The layer rejections are shared by both axes (the rows never
        // reach either judgment face).
        assert_eq!(
            reader_rejected.len() + expansion_rejected.len() + infer_diagnostic.len() + infer_clean,
            109,
            "every corpus row is classified exactly once on the inference axis"
        );
        assert_eq!(
            reader_rejected.len() + expansion_rejected.len() + check_diagnostic.len() + check_clean,
            109,
            "every corpus row is classified exactly once on the check axis"
        );
        // ---- the pinned reclassification (the r150 target-face
        // measured face — the blade-1 migration re-measured) ----
        // Reader rejections (16): the token-grammar rows (the
        // unclosed group, the stray delimiter, the unterminated
        // string, the hash token), the two literal-overflow rows, the
        // nesting cap, and the nine stage-divergent rows (the
        // malformed keyword-headed forms the grammar-directed target
        // reader rejects at READ — the S-expr reader deferred them to
        // the expander).
        assert_eq!(
            reader_rejected,
            vec![
                "bnd-007-nesting-257-fails.ktf",
                "neg-001-unclosed-paren.ktf",
                "neg-002-stray-close.ktf",
                "neg-003-unterminated-string.ktf",
                "neg-004-bad-hash-token.ktf",
                "neg-011-malformed-fn.ktf",
                "neg-012-malformed-let.ktf",
                "neg-016-malformed-handle.ktf",
                "neg-054-i64-overflow-literal.ktf",
                "neg-055-float-overflow-literal.ktf",
                "neg-065-match-3tuple-unsupported.ktf",
                "neg-066-match-nested-unsupported.ktf",
                "neg-067-match-malformed-arity.ktf",
                "neg-068-match-malformed-arm.ktf",
                "neg-071-match-exhaust-before-pattern.ktf",
                "neg-072-match-scrutinee-before-pattern.ktf",
            ]
        );
        // Expansion rejections (23): the malformed-form family, the
        // module family (the loader face — the ruling-D path-form
        // twins AND the duplicate/cycle-string/require-missing rows
        // the pipeline's in-session loader rejects; the old bare-
        // expander face passed them to the fed rows — the r150
        // re-measurement rides the pipeline spine, the same machine
        // as the corpus contract), the macro family and the extern
        // family — the nine stage-divergent rows aside (now
        // reader-rejected on the target face).
        assert_eq!(
            expansion_rejected,
            vec![
                "bnd-010-expansion-limit.ktf",
                "neg-010-top-level-expression.ktf",
                "neg-013-unbound-reference.ktf",
                "neg-014-quote-symbol.ktf",
                "neg-015-set-unbound.ktf",
                "neg-017-malformed-define.ktf",
                "neg-018-module-cycle.ktf",
                "neg-019-module-missing.ktf",
                "neg-020-module-duplicate.ktf",
                "neg-046-forward-reference.ktf",
                "neg-048-module-cycle-string.ktf",
                "neg-049-require-missing.ktf",
                "neg-050-pattern-mismatch.ktf",
                "neg-051-duplicate-pattern-vars.ktf",
                "neg-052-ellipsis-rejected.ktf",
                "neg-053-module-macro-outside.ktf",
                "neg-059-extern-bad-type.ktf",
                "neg-060-extern-bad-abi.ktf",
                "neg-061-extern-collision.ktf",
                "neg-063-match-nonexhaustive.ktf",
                "neg-064-match-nil-last-arm.ktf",
                "neg-069-match-unbound-body.ktf",
                "neg-070-match-unbound-scrutinee.ktf",
            ]
        );
        // Inference-axis diagnostics (6): the E0009 family the 127-a
        // sweep doc named — the rows the HM judgment face owns.
        assert_eq!(
            infer_diagnostic,
            vec![
                "neg-031-nonbool-cond.ktf",
                "neg-037-multi-error-collection.ktf",
                "neg-041-car-nonpair.ktf",
                "neg-044-add-bool.ktf",
                "neg-047-write-line-int.ktf",
                "neg-056-type-error-duplicate-codes.ktf",
            ]
        );
        assert_eq!(infer_clean, 64);
        // Check-axis diagnostics (9): the R2/R3/R4/R5/R6/R7 rows the
        // conservative checker owns (the pos-028 row carries the E0008
        // rebind warning — a positive-tagged row on the check axis; the
        // neg-036 literal-handler row retired with the migration —
        // E0007's face is unreachable on the target grammar, SR-2).
        assert_eq!(
            check_diagnostic,
            vec![
                "neg-030-arity-known.ktf",
                "neg-031-nonbool-cond.ktf",
                "neg-032-call-literal.ktf",
                "neg-033-call-numeric-global.ktf",
                "neg-034-handler-arity.ktf",
                "neg-035-unhandled-effect.ktf",
                "neg-037-multi-error-collection.ktf",
                "neg-057-assign-to-captured.ktf",
                "pos-028-warn-rebind-builtin.ktf",
            ]
        );
        assert_eq!(check_clean, 61);
        // The fed rows (70 on both axes): 64 clean + 6 diagnostic on
        // the inference axis, 61 clean + 9 diagnostic on the check
        // axis — the pipeline-spine machine here measures 70 (the
        // nine stage-divergent rows moved to the reader rows, the
        // three retired divergences dropped, and the three
        // module-family rows the bare expander passed now reject at
        // the pipeline's loader). The judgment-axis sweeps
        // (infer_twin_sweep/typecheck_twin_sweep) ride the BARE
        // expander — a loader-independent machine where the module
        // twins stay fed (75 there); the loader's own rejection face
        // is pinned HERE (the division of labor the blade-1
        // re-measurement drew).
        assert_eq!(infer_clean + infer_diagnostic.len(), 70);
        assert_eq!(check_clean + check_diagnostic.len(), 70);
    });
}

/// The FP5 lineage (the 127-a budget row's per-source face): the
/// 600-deep define only rides the programmatic path, and the 127-a
/// round pinned it on the steady route alone — this row pins it on
/// the per-source text route (recompiled per case, both engines) with
/// the exclusion semantics asserted: the deep define drops whole
/// (one E0011 warning, never an error), the shallow define survives.
#[test]
fn infer_twin_budget_row_matches_the_oracle_on_the_per_source_route() {
    deep_stack(|| {
        let mut cur = CoreExpr::Literal {
            span: sp(0, 1),
            value: LiteralValue::Int(1),
        };
        for _ in 0..600 {
            cur = CoreExpr::If {
                span: sp(0, 2),
                cond: Box::new(CoreExpr::Literal {
                    span: sp(0, 1),
                    value: LiteralValue::Bool(true),
                }),
                then_branch: Box::new(cur),
                else_branch: Box::new(CoreExpr::Literal {
                    span: sp(0, 1),
                    value: LiteralValue::Int(2),
                }),
            };
        }
        let items = vec![
            ModuleItem::Define {
                span: sp(0, 3),
                name: sym("deep"),
                value: cur,
            },
            ModuleItem::Define {
                span: sp(0, 11),
                name: sym("shallow"),
                value: CoreExpr::Literal {
                    span: sp(0, 5),
                    value: LiteralValue::Int(7),
                },
            },
        ];
        let per_source = infer_twin_per_source_dual(&items)
            .expect("the per-source route runs on the budget row");
        assert_eq!(
            per_source.vm_text, per_source.eval_text,
            "the per-source route's two engines agree on the budget row"
        );
        let oracle = oracle_inference_axes(&items);
        assert_eq!(
            per_source.vm_text, oracle,
            "the per-source budget row matches the oracle"
        );
        assert!(
            per_source.vm_text.contains("E0011"),
            "the budget warning rides the row: {}",
            per_source.vm_text
        );
        assert!(
            per_source.vm_text.contains("(tdef shallow"),
            "the shallow define survives the exclusion"
        );
        assert!(
            !per_source.vm_text.contains("(tdef deep"),
            "the deep define is excluded whole (no partial annotations)"
        );
    });
}

//! Workflow record tests (T-a step-5 — w-t-a-switch-window §3
//! r149+ row): the C4 face's first production consumption. The
//! development workflow — edit a `.ktf` program, compile it with
//! kerf (all four segments on the twin chains, the default
//! production position), test and benchmark through the VM — runs
//! on real corpus files (`examples/workflow/{selfcheck,bench}.ktf`)
//! instead of inline fixtures, because the deliverable IS the
//! workflow record: the same files the archived three-run
//! measurement (tool-results/r149-workflow-run{1,2,3}.txt) executes.
//!
//! Four faces, per the corpus discipline (GATE 6 composition):
//!
//! * **Positive** — the self-check corpus reports every marker PASS
//!   and completes on the production position; the benchmark corpus
//!   completes every phase with the expected value markers.
//! * **Negative** — the detection-power arms: a deliberately wrong
//!   expectation surfaces the FAIL marker (the self-test idiom
//!   actually discriminates), a type-broken workflow program aborts
//!   before execution with the same batch on both positions, and a
//!   disagreeing input tape flips the tape test to FAIL (the test
//!   consumes the tape, not a constant).
//! * **Rollback band** — the corpus agrees across the all-oracle
//!   position (every segment pinned Rust) and the default twin
//!   position: identical outputs AND identical bytecode.
//! * **Cross-stage consumption** — the CLI `run` face executes the
//!   corpus end to end (exit 0, all markers on stdout), and two
//!   consecutive runs agree (the determinism face).

use std::path::PathBuf;

use kerf::compiler::compile_program;
use kerf::driver::{
    CheckSegment, CompileSegment, ExpandSegment, ParsedProgram, ReadSegment, Session, parse_target,
    run_cli,
};

// ---------- the corpus files (the workflow record's own subjects) ----------

fn repo_root() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
}

fn corpus(name: &str) -> String {
    let path = repo_root().join("examples/workflow").join(name);
    std::fs::read_to_string(&path).unwrap_or_else(|e| {
        panic!(
            "the workflow corpus {name} must read ({}): {e}",
            path.display()
        )
    })
}

/// The self-check tape: two agreeing lines (the t8 contract).
const AGREEING_TAPE: [&str; 2] = ["alpha", "alpha"];

/// Run one corpus on one session position and return the output
/// lines (the recorded `write_line` face).
fn run_corpus(
    session: &mut Session,
    name: &str,
    source: &str,
    tape: &[&str],
) -> Result<kerf::driver::RunOutcome, Vec<kerf::driver::Diagnostic>> {
    let program: ParsedProgram = parse_target(session, name, source)?;
    program.run(
        kerf::driver::Engine::Vm,
        Box::new(kerf::vm::BufferIo::with_input(tape.iter().copied())),
    )
}

// ---------- positive ----------

#[test]
fn selfcheck_corpus_passes_on_the_production_position() {
    let source = corpus("selfcheck.ktf");
    let mut session = Session::new();
    let outcome = run_corpus(&mut session, "selfcheck.ktf", &source, &AGREEING_TAPE)
        .expect("the self-check corpus runs clean on the default twin position");
    let markers: Vec<&String> = outcome
        .outputs
        .iter()
        .filter(|l| l.contains(": PASS") || l.contains(": FAIL"))
        .collect();
    assert!(
        !markers.is_empty(),
        "the corpus must report test markers, got {:?}",
        outcome.outputs
    );
    assert!(
        markers.iter().all(|l| l.contains(": PASS")),
        "every marker must be PASS on the production position, got {markers:?}"
    );
    assert_eq!(
        markers.len(),
        8,
        "the corpus carries eight test markers (t1-t8), got {markers:?}"
    );
    assert_eq!(
        outcome.outputs.last().map(String::as_str),
        Some("selfcheck: done"),
        "the summary line must close the run: {:?}",
        outcome.outputs
    );
}

#[test]
fn bench_corpus_completes_every_phase_with_the_expected_markers() {
    let source = corpus("bench.ktf");
    let mut session = Session::new();
    let outcome = run_corpus(&mut session, "bench.ktf", &source, &[])
        .expect("the benchmark corpus runs clean on the default twin position");
    let joined = outcome.outputs.join("\n");
    for expected in [
        "bench fib(30): start",
        "bench fib(30): done (832040)",
        "bench list(10000): start",
        "bench list(10000): done (10000)",
        "bench sum_to(20000): start",
        "bench sum_to(20000): done (200010000)",
        "bench: done",
    ] {
        assert!(
            joined.contains(expected),
            "the bench record must carry `{expected}`: {joined}"
        );
    }
    assert!(
        !joined.contains("VALUE FAIL"),
        "a value failure marker must never appear: {joined}"
    );

    // The determinism face: a second run of the same corpus reports
    // the identical marker sequence (the record is reproducible).
    let mut session2 = Session::new();
    let outcome2 =
        run_corpus(&mut session2, "bench.ktf", &source, &[]).expect("the second run is clean too");
    assert_eq!(
        outcome.outputs, outcome2.outputs,
        "two runs of the benchmark corpus must agree line for line"
    );
}

// ---------- negative (the detection-power arms) ----------

#[test]
fn a_wrong_expectation_surfaces_the_fail_marker() {
    // The self-test idiom must discriminate: the same corpus shape
    // with one deliberately wrong expectation reports FAIL for that
    // marker (and only that marker) — a suite that cannot fail is
    // not a test suite.
    let source = corpus("selfcheck.ktf").replace("fib(12) == 144", "fib(12) == 145");
    let mut session = Session::new();
    let outcome = run_corpus(&mut session, "selfcheck.ktf", &source, &AGREEING_TAPE)
        .expect("the wrong-expectation variant still runs (a FAIL marker, not a crash)");
    let fails: Vec<&String> = outcome
        .outputs
        .iter()
        .filter(|l| l.contains(": FAIL"))
        .collect();
    assert_eq!(
        fails.len(),
        1,
        "exactly the tampered test reports FAIL: {fails:?} in {:?}",
        outcome.outputs
    );
    assert!(
        fails[0].contains("t1"),
        "the FAIL must be the tampered t1: {fails:?}"
    );
    assert!(
        outcome
            .outputs
            .iter()
            .filter(|l| l.contains(": PASS"))
            .count()
            == 7,
        "the other seven markers stay PASS: {:?}",
        outcome.outputs
    );
}

#[test]
fn a_type_broken_workflow_program_aborts_before_execution() {
    // The checker gate stands between the edit and the run: a
    // type-broken workflow program aborts with the same batch on
    // both positions and never reaches the VM (no output at all).
    let broken = "fn fib(n) { if n < 2 { n } else { fib(n - 1) + fib(n - 2) } }\n\
                  define(t1, if fib(12) == 144 { \"t1: PASS\" } else { \"t1: FAIL\" });\n\
                  define(o1, write_line(t1));\n\
                  define(bad, write_line(42));\n";
    for (label, session) in [
        ("twin", Session::new()),
        ("rust", {
            let mut s = Session::new();
            s.set_read_segment(ReadSegment::Rust);
            s.set_expand_segment(ExpandSegment::Rust);
            s.set_check_segment(CheckSegment::Rust);
            s.set_compile_segment(CompileSegment::Rust);
            s
        }),
    ] {
        let mut session = session;
        let program = parse_target(&mut session, "broken.ktf", broken)
            .unwrap_or_else(|d| panic!("the broken program still parses ({label}): {d:?}"));
        let err = program
            .run(
                kerf::driver::Engine::Vm,
                Box::new(kerf::vm::BufferIo::default()),
            )
            .expect_err("the type-broken program must abort the run");
        assert!(
            err.iter()
                .any(|d| matches!(d.code, kerf::driver::DiagnosticCode::Typecheck(_))),
            "the abort batch must carry a typecheck diagnostic ({label}): {err:?}"
        );
    }
}

#[test]
fn a_disagreeing_tape_flips_the_tape_test_to_fail() {
    // The t8 test consumes the input tape (it is not a constant):
    // two disagreeing lines flip its marker to FAIL while the other
    // seven stay PASS.
    let source = corpus("selfcheck.ktf");
    let disagreeing = ["alpha", "beta"];
    let mut session = Session::new();
    let outcome = run_corpus(&mut session, "selfcheck.ktf", &source, &disagreeing)
        .expect("the disagreeing-tape variant still runs");
    let fails: Vec<&String> = outcome
        .outputs
        .iter()
        .filter(|l| l.contains(": FAIL"))
        .collect();
    assert_eq!(
        fails.len(),
        1,
        "exactly the tape test reports FAIL: {fails:?} in {:?}",
        outcome.outputs
    );
    assert!(
        fails[0].contains("t8"),
        "the FAIL must be the tape test t8: {fails:?}"
    );
}

// ---------- rollback band ----------

#[test]
fn the_corpus_agrees_across_the_all_oracle_position() {
    // The full rollback band: every segment pinned Rust (the
    // all-oracle position) runs the same corpus with identical
    // outputs AND identical bytecode — the workflow record does not
    // depend on which position executes it.
    let source = corpus("selfcheck.ktf");

    let mut twin_session = Session::new();
    let twin_program = parse_target(&mut twin_session, "selfcheck.ktf", &source)
        .expect("the twin position parses the corpus");
    let twin_run = twin_program
        .run(
            kerf::driver::Engine::Vm,
            Box::new(kerf::vm::BufferIo::with_input(AGREEING_TAPE)),
        )
        .expect("the twin position runs the corpus");
    let twin_bc =
        compile_program(&twin_program.items).expect("the twin position compiles the corpus");

    let mut oracle_session = Session::new();
    oracle_session.set_read_segment(ReadSegment::Rust);
    oracle_session.set_expand_segment(ExpandSegment::Rust);
    oracle_session.set_check_segment(CheckSegment::Rust);
    oracle_session.set_compile_segment(CompileSegment::Rust);
    let oracle_program = parse_target(&mut oracle_session, "selfcheck.ktf", &source)
        .expect("the all-oracle position parses the corpus");
    let oracle_run = oracle_program
        .run(
            kerf::driver::Engine::Vm,
            Box::new(kerf::vm::BufferIo::with_input(AGREEING_TAPE)),
        )
        .expect("the all-oracle position runs the corpus");
    let oracle_bc = compile_program(&oracle_program.items)
        .expect("the all-oracle position compiles the corpus");

    assert_eq!(
        twin_run.outputs, oracle_run.outputs,
        "the two positions must report identical markers"
    );
    assert_eq!(
        twin_bc, oracle_bc,
        "the two positions must compile the corpus to identical bytecode"
    );
}

// ---------- cross-stage consumption (the CLI face) ----------

#[test]
fn cli_run_executes_the_workflow_corpus_end_to_end() {
    // The user-facing face of the workflow record: `kerf run
    // examples/workflow/selfcheck.ktf` with the tape piped on stdin
    // exits 0 and prints every marker — the exact shape of the
    // archived three-run measurement.
    let source = corpus("selfcheck.ktf");
    let args = vec![
        "run".to_owned(),
        "examples/workflow/selfcheck.ktf".to_owned(),
    ];
    let read_file = move |path: &str| {
        if path == "examples/workflow/selfcheck.ktf" {
            Ok(source.clone())
        } else {
            Err(std::io::Error::other(format!("unexpected path {path}")))
        }
    };
    let mut repl_input = || None;
    let input_lines: Vec<String> = AGREEING_TAPE.iter().map(|s| s.to_string()).collect();
    let mut out = Vec::new();
    let mut errbuf = Vec::new();
    let code = run_cli(
        &args,
        &read_file,
        &mut repl_input,
        input_lines,
        &mut out,
        &mut errbuf,
    );
    let out_text = String::from_utf8(out).expect("utf8 stdout");
    assert_eq!(
        code,
        0,
        "the CLI run must exit 0 (err: {})",
        String::from_utf8_lossy(&errbuf)
    );
    assert_eq!(
        out_text.matches(": PASS").count(),
        8,
        "all eight markers print on stdout: {out_text}"
    );
    assert!(
        out_text.ends_with("selfcheck: done\n"),
        "the summary line closes the stdout: {out_text}"
    );
}

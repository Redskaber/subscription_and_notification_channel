//! Check segment switch tests (T-a step-④ blade 3 —
//! w-t-a-switch-window §3 r147+ row): the CHECK segment's production
//! position switch. The `.ktf` production checking rides BOTH
//! checker twin chains on the VM (the conservative checker + the HM
//! inference engine — the default); the Rust checker pair retires to
//! the oracle face (the parity comparison arm, the seed chain's own
//! checking, and the rollback band — `KERF_CHECK_SEGMENT=rust`).
//!
//! Four faces, per the corpus discipline (GATE 6 composition):
//!
//! * **Positive** — the production position's findings are
//!   field-identical to the oracle checking's findings (the
//!   five-field parity contract: code, severity, span offsets,
//!   message, subjects-in-message) across the curated family and the
//!   selfhost fixed points, on the DEFAULT stack.
//! * **Negative** — the findings family: every diagnostic family the
//!   two checkers own (E0002/E0008/E0009 named + anonymous arms,
//!   E0011 the budget warning) rebuilds with the same fields on both
//!   positions, at a NON-zero file id (the span-retarget face), and
//!   the RENDERED text is identical (the user-facing face).
//! * **Rollback band** — the position selector's three states
//!   (default twin, explicit rust, invalid fail-closed) and the two
//!   positions' agreement on the corpus.
//! * **Cross-stage consumption** — the production-position checking
//!   feeds the whole spine (compile → run): the compiled bytecode
//!   equals the Rust-position bytecode, the run value agrees, and
//!   the CLI check face rides the twin checkers end to end.
//!
//! The honest boundary (the window doc TA-7): the twin position's
//! rebuilt spans carry the ROOT generation (the expand-segment
//! error-axis `make_span` precedent); the oracle position's
//! macro-expanded findings carry their true expansion generations —
//! the five-field parity contract and every rendering face are
//! generation-free, so the comparisons below stay on the contract
//! fields and the rendered text, never the raw span structs.

use kerf::compiler::compile_program;
use kerf::driver::{
    CheckSegment, DepthLimits, Diagnostic, DiagnosticCode, ExpandSegment, ParsedProgram,
    ReadSegment, Session, TARGET_PARSER_TWIN_CASES, parse_target, render_diagnostics, run_cli,
};
use kerf::span::FileId;

use crate::steady_target_reader_tests::SELFHOST_SOURCES;

// ---------- the shared comparison faces ----------

/// One finding's contract key: the five-field parity contract as a
/// comparable tuple — code, severity, span offsets, message (the
/// subjects ride inside the rendered message — the skin pass
/// re-spells exactly the subjects the message names, so an equal
/// message is an equal subject set; the raw span struct stays out on
/// purpose: the generation axis is the window's disclosed boundary).
fn finding_key(d: &Diagnostic) -> (String, String, u32, u32, String, String) {
    let code = match &d.code {
        DiagnosticCode::Typecheck(code) => code.as_str().to_string(),
        other => format!("{other:?}"),
    };
    let severity = match d.severity {
        kerf::driver::Severity::Error => "error".to_string(),
        other => format!("{other:?}"),
    };
    let span = d
        .primary_span
        .as_ref()
        .expect("a typecheck finding always carries a primary span");
    (
        code,
        severity,
        span.start.0,
        span.end.0,
        d.message.clone(),
        d.file.0.to_string(),
    )
}

/// Both positions' findings on one read-clean, expand-clean source:
/// parse through each position's session (the shared spine — both
/// positions already ride the switched read/expand segments, the
/// r145/r146 switches; THIS family isolates the checking segment),
/// collect the typecheck findings, compare the contract keys.
fn assert_check_positions_agree(name: &str, source: &str) {
    // The twin position: the default session (all three segments
    // switched).
    let mut twin_session = Session::new();
    let twin_program = match parse_target(&mut twin_session, name, source) {
        Ok(program) => program,
        // Read/expand rejections are NOT this family's subject (the
        // r145/r146 families own them) — skip them.
        Err(_) => return,
    };
    assert_eq!(twin_program.check_segment, CheckSegment::Twin);
    let twin_findings = twin_program.typecheck();

    // The rust position: the check segment pinned back (the
    // rollback band's own arm).
    let mut rust_session = Session::new();
    rust_session.set_check_segment(CheckSegment::Rust);
    let rust_program = match parse_target(&mut rust_session, name, source) {
        Ok(program) => program,
        Err(_) => return,
    };
    let rust_findings = rust_program.typecheck();

    let twin_keys: Vec<_> = twin_findings.iter().map(finding_key).collect();
    let rust_keys: Vec<_> = rust_findings.iter().map(finding_key).collect();
    assert_eq!(
        twin_keys, rust_keys,
        "the twin and oracle findings must agree field-for-field (in order) on {name}"
    );

    // The user-facing face: the rendered batches are identical
    // against the twin session (both positions' spans name the same
    // interned file — the twin's rebuilt spans are retargeted).
    let twin_text = render_diagnostics(&twin_session, &twin_findings);
    let rust_text = render_diagnostics(&twin_session, &rust_findings);
    assert_eq!(
        twin_text, rust_text,
        "the rendered findings must be identical on both positions for {name}"
    );
}

// ---------- positive: the production position holds the corpus ----------

/// The curated target family (both polarities): every case whose
/// read AND expansion succeed checks with identical findings on both
/// positions — the default flip's own sweep (clean findings and
/// rejection findings alike).
#[test]
fn the_curated_family_checks_identically_on_both_positions() {
    for &(name, source) in TARGET_PARSER_TWIN_CASES {
        assert_check_positions_agree(name, source);
    }
}

/// The nine selfhost sources + the two checker CCFs — the deepest
/// fixed points (the language checking its own twins, through the
/// extern-slot chain-compilable forms), on the DEFAULT stack: the
/// checker twins run on the VM's heap activation records (the r136
/// G2 base), and the host-side decode walks short diagnostic lists —
/// no right-spine risk on this segment's rebuild face (the K163
/// input-domain audit: the items STREAM's long spines ride the
/// r145/r146 iterative-dispose glue at the injection sites).
#[test]
fn the_selfhost_fixed_points_check_on_a_default_stack() {
    let mut sources: Vec<(&str, &str)> = SELFHOST_SOURCES.to_vec();
    let infer_ccf = kerf::driver::ccf_infer_source();
    let check_ccf = kerf::driver::ccf_check_source();
    sources.push(("ccf-infer.ktf", infer_ccf.as_str()));
    sources.push(("ccf-check.ktf", check_ccf.as_str()));
    for (name, source) in &sources {
        assert_check_positions_agree(name, source);
    }
}

// ---------- negative: the findings family ----------

/// The findings family through the PRODUCTION position: every
/// diagnostic family the two checkers own rebuilds with the oracle's
/// own fields — the named and anonymous arity arms, the warning
/// channel, the inference mismatches — at a NON-zero file id (the
/// span-retarget face: a rebuilt span naming the wrong file renders
/// against the wrong source), with the rendered text identical (the
/// user-facing equivalence).
#[test]
fn findings_render_identically_on_both_positions() {
    let finding_cases: &[(&str, &str)] = &[
        (
            "arity-named",
            "fn add(a, b) { a + b }\nfn main() { add(1, 2, 3) }\n",
        ),
        ("arity-anonymous", "define(r, ||(a, b) { a + b }(1));\n"),
        ("warning-rebind", "fn main() { car = 5; car(nil) }\n"),
        ("type-mismatch", "fn main() { 1 + true }\n"),
        (
            "handler-arity",
            "define(r, handle perform E(1, 2) { E(v) => resume(v), });\n",
        ),
        (
            "mixed-batch",
            "fn add(a, b) { a + b }\nfn bad(p) { 1 + true }\nfn main() { add(1); bad(2) }\n",
        ),
    ];
    for &(name, source) in finding_cases {
        // The session interns the source at a NON-zero file id (the
        // span-retarget face); BOTH positions' findings must name
        // THIS id in the rendered batch.
        let mut twin_session = Session::new();
        let _zero = twin_session.intern("zero.ktf", "fn z() { 0 }");
        let twin_program =
            parse_target(&mut twin_session, name, source).expect("the case must parse");
        let twin_findings = twin_program.typecheck();
        assert!(
            !twin_findings.is_empty(),
            "the finding case {name} must produce findings on the twin position"
        );
        for finding in &twin_findings {
            assert_eq!(
                finding.file.0, 1,
                "the twin position's finding must name the session's file on {name}"
            );
        }

        let mut rust_session = Session::new();
        let _zero = rust_session.intern("zero.ktf", "fn z() { 0 }");
        rust_session.set_check_segment(CheckSegment::Rust);
        let rust_program =
            parse_target(&mut rust_session, name, source).expect("the case must parse");
        let rust_findings = rust_program.typecheck();

        let twin_keys: Vec<_> = twin_findings.iter().map(finding_key).collect();
        let rust_keys: Vec<_> = rust_findings.iter().map(finding_key).collect();
        assert_eq!(
            twin_keys, rust_keys,
            "the finding fields must match on both positions for {name}"
        );
        let twin_text = render_diagnostics(&twin_session, &twin_findings);
        let rust_text = render_diagnostics(&twin_session, &rust_findings);
        assert_eq!(
            twin_text, rust_text,
            "the rendered findings must be identical on both positions for {name}"
        );
    }
}

/// The inference layer's own faces: the unification mismatch and
/// the occurs-check rejection (E0010) through the twin position.
/// The E0011 budget warning is STRUCTURALLY UNREACHABLE in the
/// production spine — the expansion budget (512) counts the same
/// expression-tree recursion the inference budget (512) counts, and
/// the expansion step runs FIRST, so a tree deep enough to exhaust
/// the inference budget rejects at the expansion layer on BOTH
/// positions long before the checkers see it (probed this round:
/// a 520-deep left spine rejects as `expansion depth exceeded the
/// limit of 512` identically) — the budget-mirroring obligation
/// holds vacuously by construction (both sides bake the same 512,
/// and neither side's budget is ever the binding one in the
/// spine); the E0011 rendering stays covered by the direct-unit
/// tests in the typecheck crate.
#[test]
fn the_inference_layer_rides_the_twin_position() {
    let cases: &[(&str, &str)] = &[
        (
            "recursive-type",
            "define(r, ||(f) { f(f) }(||(g) { g(g) }));\n",
        ),
        ("unify-mismatch", "define(r, if 1 { 2 } else { 3 });\n"),
    ];
    for &(name, source) in cases {
        assert_check_positions_agree(name, source);
    }

    // The E0011 disclosure: a 520-deep left spine rejects at the
    // EXPANSION layer on both positions with the same key (the
    // structural unreachability evidence — see the test's doc
    // comment).
    let mut deep = String::from("define(r, ");
    deep.push('1');
    for _ in 0..520 {
        deep.push_str(" + 1");
    }
    deep.push_str(");\n");
    let mut twin_session = Session::new();
    let twin_reject = parse_target(&mut twin_session, "deep.ktf", deep.as_str())
        .expect_err("the deep spine must reject at the expansion layer");
    let mut rust_session = Session::new();
    rust_session.set_check_segment(CheckSegment::Rust);
    let rust_reject = parse_target(&mut rust_session, "deep.ktf", deep.as_str())
        .expect_err("the deep spine must reject at the expansion layer");
    assert_eq!(
        kerf::driver::render_diagnostics(&twin_session, &twin_reject),
        kerf::driver::render_diagnostics(&rust_session, &rust_reject),
        "the deep spine's expansion rejection must be identical on both positions"
    );
}

/// The warning channel never blocks (the check face's own contract
/// through the switched position): a warning-carrying program checks
/// GREEN on the twin position, and the warnings ride the outcome.
#[test]
fn the_warning_channel_never_blocks() {
    let source = "fn main() { car = 5; car(nil) }\n";
    let mut session = Session::new();
    let program = parse_target(&mut session, "warn.ktf", source).expect("the warning case parses");
    let outcome = program
        .check()
        .expect("the warning program must check green");
    assert!(
        !outcome.warnings.is_empty(),
        "the warning channel must carry the finding"
    );
}

/// The empty-items face: a comment-only source produces zero items —
/// both checker twins must return clean empty verdicts (the twins'
/// nil-stream walk heads), never a harness defect.
#[test]
fn the_empty_items_face_is_clean_on_both_positions() {
    let source = "// only a comment\n";
    let mut twin_session = Session::new();
    let twin_program = parse_target(&mut twin_session, "empty.ktf", source)
        .expect("the comment-only source parses");
    assert!(twin_program.typecheck().is_empty());

    let mut rust_session = Session::new();
    rust_session.set_check_segment(CheckSegment::Rust);
    let rust_program = parse_target(&mut rust_session, "empty.ktf", source)
        .expect("the comment-only source parses");
    assert!(rust_program.typecheck().is_empty());
}

// ---------- the rollback band ----------

/// The position selector's three states: the default rides the
/// twins, the explicit `rust` pins the oracle, and anything else is
/// a hard parse failure (fail-closed — a silently ignored position
/// override would be a lie).
#[test]
fn the_rollback_band_three_states() {
    assert_eq!(CheckSegment::parse_value("twin"), Ok(CheckSegment::Twin));
    assert_eq!(CheckSegment::parse_value("rust"), Ok(CheckSegment::Rust));
    for bad in ["", "twins", "TWIN", "c", "0", "vm"] {
        assert!(
            CheckSegment::parse_value(bad).is_err(),
            "`{bad}` must not parse as a check segment"
        );
    }

    // The library face: the session default is the switched twin
    // position; the explicit pin flips it.
    let mut session = Session::new();
    assert_eq!(session.check_segment(), CheckSegment::Twin);
    session.set_check_segment(CheckSegment::Rust);
    assert_eq!(session.check_segment(), CheckSegment::Rust);

    // The parsed program carries the position (the disclosure face).
    let source = "fn main() { 1 + 2 }\n";
    let mut twin_session = Session::new();
    let twin_program = parse_target(&mut twin_session, "p.ktf", source).unwrap();
    assert_eq!(twin_program.check_segment, CheckSegment::Twin);
    let mut rust_session = Session::new();
    rust_session.set_check_segment(CheckSegment::Rust);
    let rust_program = parse_target(&mut rust_session, "p.ktf", source).unwrap();
    assert_eq!(rust_program.check_segment, CheckSegment::Rust);
}

// ---------- cross-stage consumption ----------

/// The production-position checking feeds the whole spine: a clean
/// program's compiled bytecode is IDENTICAL through the twin-checked
/// parse (the checker never rewrites items — findings are data), and
/// the run value agrees; a REJECTED program aborts before either
/// engine starts (the same error batch on both positions).
#[test]
fn the_production_position_feeds_the_whole_spine() {
    let subjects: Vec<(&str, &str)> = vec![
        (
            "curated-fn",
            "fn add(a, b) { a + b }\nfn main() { add(1, 2) }\n",
        ),
        (
            "curated-match",
            "fn pick(p) { match p { 1 => { 10 }, _ => { 20 }, } }\nfn main() { pick(1) }\n",
        ),
        // The deep SELF-CONTAINED workload (the macro twin — a
        // closed program the VM can run end to end; the checker CCFs
        // carry extern slot declarations, and extern calls are the
        // C backend's face — the run axis stays with runnable
        // closed programs, the CCFs' own checking coverage lives in
        // the fixed-point family above).
        ("macro-twin-20kb", kerf::driver::MACRO_TARGET_SOURCE),
    ];
    for (name, source) in &subjects {
        let mut twin_session = Session::new();
        let twin_program = parse_target(&mut twin_session, name, source)
            .unwrap_or_else(|d| panic!("the twin position must parse {name}: {d:?}"));
        let findings = twin_program.typecheck();
        assert!(
            !findings
                .iter()
                .any(|d| d.severity == kerf::driver::Severity::Error),
            "the twin position must check clean on {name}: {findings:?}"
        );
        let twin_bc = compile_program(&twin_program.items)
            .unwrap_or_else(|e| panic!("the twin position must compile {name}: {e}"));
        let twin_run = twin_program
            .run(
                kerf::driver::Engine::Vm,
                Box::new(kerf::vm::BufferIo::default()),
            )
            .unwrap_or_else(|d| panic!("the twin position must run {name}: {d:?}"));

        let mut rust_session = Session::new();
        rust_session.set_check_segment(CheckSegment::Rust);
        let rust_program = parse_target(&mut rust_session, name, source)
            .unwrap_or_else(|d| panic!("the rust position must parse {name}: {d:?}"));
        let rust_bc = compile_program(&rust_program.items)
            .unwrap_or_else(|e| panic!("the rust position must compile {name}: {e}"));
        let rust_run = rust_program
            .run(
                kerf::driver::Engine::Vm,
                Box::new(kerf::vm::BufferIo::default()),
            )
            .unwrap_or_else(|d| panic!("the rust position must run {name}: {d:?}"));

        assert_eq!(
            twin_bc, rust_bc,
            "the two positions must compile to identical bytecode on {name}"
        );
        assert_eq!(
            twin_run.value_display(),
            rust_run.value_display(),
            "the two positions must run to the same value on {name}"
        );
    }

    // A checker-rejected program aborts before either engine starts,
    // with the same batch on both positions.
    let broken = "fn main() { 1 + true }\n";
    let mut twin_session = Session::new();
    let twin_program = parse_target(&mut twin_session, "broken.ktf", broken).unwrap();
    let twin_err = twin_program
        .run(
            kerf::driver::Engine::Vm,
            Box::new(kerf::vm::BufferIo::default()),
        )
        .expect_err("the type-broken program must abort the run");
    let mut rust_session = Session::new();
    rust_session.set_check_segment(CheckSegment::Rust);
    let rust_program = parse_target(&mut rust_session, "broken.ktf", broken).unwrap();
    let rust_err = rust_program
        .run(
            kerf::driver::Engine::Vm,
            Box::new(kerf::vm::BufferIo::default()),
        )
        .expect_err("the type-broken program must abort the run");
    let twin_keys: Vec<_> = twin_err.iter().map(finding_key).collect();
    let rust_keys: Vec<_> = rust_err.iter().map(finding_key).collect();
    assert_eq!(twin_keys, rust_keys, "the abort batches must agree");
}

/// The CLI check face rides the twin checkers end to end (the
/// process-entry default; `KERF_CHECK_SEGMENT` unset): a clean
/// `.ktf` program checks green, and a program the CHECKERS reject
/// renders the same diagnostic the Rust position renders.
#[test]
fn the_cli_check_face_rides_the_twin_checkers() {
    let clean = "fn main() { 40 + 2 }\n";
    let mut out = Vec::new();
    let mut err = Vec::new();
    let code = run_cli(
        &["check".to_string(), "main.ktf".to_string()],
        &|_| Ok(clean.to_string()),
        &mut || None,
        Vec::new(),
        &mut out,
        &mut err,
    );
    assert_eq!(code, 0, "the clean program must check green: {err:?}");
    assert!(
        String::from_utf8_lossy(&out).contains("ok"),
        "the check face must report ok: {out:?}"
    );
    // A checker-rejected program renders — exit 1, the diagnostic
    // batch on the error sink, and the RENDERED TEXT equals the Rust
    // position's own rendering of the same source.
    let broken = "fn main() { 1 + true }\n";
    let mut out = Vec::new();
    let mut err = Vec::new();
    let code = run_cli(
        &["check".to_string(), "main.ktf".to_string()],
        &|_| Ok(broken.to_string()),
        &mut || None,
        Vec::new(),
        &mut out,
        &mut err,
    );
    assert_eq!(code, 1, "the checker-rejected program must fail the check");
    let twin_text = String::from_utf8_lossy(&err).into_owned();
    let mut rust_session = Session::new();
    rust_session.set_check_segment(CheckSegment::Rust);
    let rust_program = parse_target(&mut rust_session, "main.ktf", broken).unwrap();
    let rust_findings = rust_program.typecheck();
    let oracle_text = render_diagnostics(&rust_session, &rust_findings);
    assert_eq!(
        twin_text.trim(),
        oracle_text.trim(),
        "the CLI diagnostic must equal the rust position's rendering"
    );
}

// ---------- the seed pins (the dual-chain decoupling) ----------

/// The seed faces stay pinned to the Rust checkers (the step-④
/// dual-chain decoupling, the checking half): the injection-channel
/// front end (`parse_target_with_injected` — the twin checker
/// chains' OWN construction entry; a twin-position check there
/// would be circular), the bootstrap bridge
/// (`read_target_source_for_bootstrap`), and the A/B/C A pass
/// (`rust_compile_ccf`) must keep their checking on the Rust arm. A
/// source-scan guard (the TEST-2/TEST-3 precedent — machine-checked
/// source invariants).
#[test]
fn the_seed_faces_stay_pinned_to_the_rust_checkers() {
    let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR"));
    // (file, the function to window, the anchors that must appear
    // in the window — the explicit check pin).
    let pins: &[(&str, &str, &[&str])] = &[
        (
            "crates/kerf-driver/src/pipeline.rs",
            "pub fn parse_target_with_injected",
            &["CheckSegment::Rust"],
        ),
        (
            "crates/kerf-driver/src/bootstrap/target_corpus.rs",
            "pub fn read_target_source_for_bootstrap",
            &["with_segments", "CheckSegment::Rust"],
        ),
        (
            "crates/kerf-driver/src/bootstrap/abc_pipeline.rs",
            "pub fn rust_compile_ccf",
            &["with_segments", "CheckSegment::Rust"],
        ),
    ];
    for (path, face, anchors) in pins {
        let src = std::fs::read_to_string(root.join(path))
            .unwrap_or_else(|e| panic!("the {face} source must read: {e}"));
        let start = src
            .find(face)
            .unwrap_or_else(|| panic!("the {face} declaration must exist in {path}"));
        // The construction window: the function's first 2,000
        // characters (every pin sits inside the constructor body).
        let window = &src[start..(start + 2000).min(src.len())];
        for anchor in *anchors {
            assert!(
                window.contains(anchor),
                "{face} must keep the Rust-checker pin (missing `{anchor}` — the twin \
                 chains' own construction would be circular without it; see the step-④ \
                 dual-chain decoupling)"
            );
        }
    }

    // The runtime behavior of the circularity guard: an injected
    // program that somehow arrives at the twin arm fails LOUDLY (the
    // wiring defect face — never a silent oracle side-step). The
    // ordinary paths can never produce it (the injected faces pin
    // Rust by construction), so the face is exercised by direct
    // construction: a hand-built twin-position injected program.
    let program = ParsedProgram {
        file: FileId(0),
        items: Vec::new(),
        injected: vec![kerf::span::Symbol::new("slot").expect("a valid name")],
        limits: DepthLimits::default(),
        read_segment: ReadSegment::Twin,
        expand_segment: ExpandSegment::Twin,
        check_segment: CheckSegment::Twin,
        compile_segment: kerf::driver::CompileSegment::Rust,
    };
    let findings = program.typecheck();
    assert!(
        findings.iter().any(|d| d
            .message
            .contains("the seed faces must pin the Rust check segment")),
        "the injected-on-twin-arm wiring defect must fail loudly: {findings:?}"
    );
}

// The r151 retirement record (W-SEXP-RETIRE blade 2): the S-expr
// seed-checker spot-check (`the_sexpr_seed_face_is_untouched` — a
// `parse`-driven oracle-arm pin over `(define x 1)` and a type-broken
// S-expr follow-up) retired with its subject: the S-expression read
// API no longer exists, so the `.krf` seed face cannot reach the
// check segment at all. The oracle arm itself stays pinned by the
// rollback-band tests above (the explicit `CheckSegment::Rust`
// session on target-skin sources, findings field-identical to the
// twin position's).

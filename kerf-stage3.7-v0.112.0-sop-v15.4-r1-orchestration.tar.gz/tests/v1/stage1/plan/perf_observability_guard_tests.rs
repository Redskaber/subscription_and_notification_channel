//! Performance-observability guards (interlude Task 38, §9.61).
//!
//! The deterministic face of the performance domain: B4-style
//! counters that change are a semantic change, not a performance
//! change (performance-baseline.md §2 note). The churn program's
//! exact gc counters — one cycle per run, 1023 swept cells per run
//! under the 1024 budget — were previously pinned only inside the
//! bench binary, so a silent GC-semantics drift (like the ten-round
//! §14.6.4 rule-5 lapse this round repaired) had no tripwire.
//!
//! Guards:
//! 1. `b4_churn_counters_exact_per_run` — behavioral pin: builds the
//!    2000-pair churn program, runs it under budget 1024 with a
//!    counting collector, and asserts the exact per-run counters
//!    (determinism per §9.55; any deviation is a semantic change).
//! 2. `bench_harness_methodology_present` — source guard: the bench
//!    harness must keep the §9.61 methodology v2 faces (optimizer
//!    fences, warmup phases, four-statistic reporting) — mechanical
//!    read-and-count, same family as the test_infra guards (§9.57).

use kerf::compiler::compile_program;
use kerf::expander::expand_program;
use kerf::reader::read_target_program;
use kerf::runtime::collect as production_collect;
use kerf::span::FileId;
use kerf::vm::{Collector, Heap, Roots, Vm};

/// Counting collector mirroring the bench pattern (§9.61): shares
/// sweep counters out through interior mutability while the VM owns
/// the box.
#[derive(Clone, Default)]
struct SharedCounters {
    cycles: std::rc::Rc<std::cell::Cell<u32>>,
    swept: std::rc::Rc<std::cell::Cell<u32>>,
}

struct CountingCollector {
    shared: SharedCounters,
}

impl Collector for CountingCollector {
    fn collect(&mut self, heap: &mut Heap, roots: &Roots) -> u32 {
        let gc = production_collect(heap, roots);
        self.shared.cycles.set(self.shared.cycles.get() + 1);
        self.shared.swept.set(self.shared.swept.get() + gc.swept);
        gc.swept
    }
}

fn churn_bc(pairs: usize) -> kerf::compiler::Bytecode {
    let mut src = String::with_capacity(pairs * 32);
    for i in 0..pairs {
        src.push_str(&format!("define(d{i}, first(pair({i}, nil))); "));
    }
    let forms = read_target_program(FileId(0), &src).expect("read");
    let items = expand_program(&forms).expect("expand");
    compile_program(&items).expect("compile")
}

// ---------- guard 1: behavioral pin ----------

#[test]
fn b4_churn_counters_exact_per_run() {
    // The B4 axis workload, run-by-run: three independent program
    // runs, each under its own collector, each asserting the exact
    // deterministic counters recorded in the baseline (1 cycle,
    // 1023 swept). Per-run pinning is strictly stronger than the
    // bench's aggregate-per-iter division.
    for _ in 0..3 {
        let shared = SharedCounters::default();
        let collector = Box::new(CountingCollector {
            shared: shared.clone(),
        });
        let mut vm = Vm::with_budget_and_collector(churn_bc(2_000), 1_024, collector)
            .expect("tight-budget vm");
        vm.run().expect("churn program halts");
        assert_eq!(
            shared.cycles.get(),
            1,
            "gc cycle count drifted — a semantic change (allocation rate or live set), not a performance change"
        );
        assert_eq!(
            shared.swept.get(),
            1_023,
            "swept-cell count drifted — a semantic change (allocation rate or live set), not a performance change"
        );
    }
}

// ---------- guard 2: methodology presence (source guard) ----------

#[test]
fn bench_harness_methodology_present() {
    // Read-and-count face over the harness source — fail-closed on
    // any silent methodology regression (fences removed, warmup
    // dropped, reporting thinned back to mean/median).
    let path = format!(
        "{}/examples/bench/stage0_baseline.rs",
        env!("CARGO_MANIFEST_DIR")
    );
    let src = std::fs::read_to_string(&path).unwrap_or_else(|e| panic!("read {path}: {e}"));

    // Optimizer fences (K90): every measured region takes its input
    // through black_box — at least the five axes (B1 composite,
    // B1a/B1b/B1c chains, B2-B5 sources).
    let fences = src.matches("black_box").count();
    assert!(
        fences >= 14,
        "optimizer fence discipline thinned: only {fences} black_box mentions (expected >=14: imports + five fenced axes)"
    );

    // Warmup phases (§9.61 PERF-2): the warmup helper must exist and
    // be called for every axis.
    assert!(
        src.contains("fn warmup_iters("),
        "warmup helper missing — methodology v2 requires warmup before every measured loop"
    );
    let warmups = src.matches("warmup_iters(").count();
    assert!(
        warmups >= 6,
        "warmup coverage thinned: {warmups} mentions (expected >=6: definition + five call sites)"
    );

    // Four-statistic reporting: stdev must be present in both
    // line-print helpers and the struct.
    let stdevs = src.matches("stdev").count();
    assert!(
        stdevs >= 6,
        "four-statistic reporting thinned: {stdevs} stdev mentions (expected >=6: struct field + two helpers + four print sites)"
    );

    // Sub-axis split (§9.61 PERF-3): B1a/B1b/B1c must exist.
    for label in ["B1a read-fib", "B1b expand-fib", "B1c compile+verify-fib"] {
        assert!(
            src.contains(label),
            "sub-axis {label} missing — stage attribution for §9.44.5 triggers requires the split"
        );
    }

    // The composed-chain cost axis (§9.88, the 2.4 closure
    // measurement face): B7 and its fail-closed parity precondition
    // must stay in the harness — the axis pins the self-hosting cost
    // multiplier that 2.5/2.6 planning consumes, and a benchmark
    // over a drifting chain is meaningless without the `matched`
    // assertion.
    assert!(
        src.contains("B7 composed-chain-fib"),
        "B7 composed-chain-fib missing — the self-hosting cost axis is a guarded measurement obligation (§9.88)"
    );
    assert!(
        src.contains("the composed chain drifted"),
        "B7 must fail closed on chain drift — the parity assertion is the axis's precondition"
    );

    // The fixpoint-driver cost axis (§9.90, the 2.5 closure
    // measurement face): B8 and its fail-closed precondition must
    // stay in the harness — the axis pins the wall-clock cost of the
    // §21.3 (2) proof itself, which the 2.6 build-orchestration
    // evaluation consumes as its bootstrap-verification budget
    // floor, and a benchmark over a broken fixpoint is meaningless
    // without the `fixpoint_holds` assertion.
    assert!(
        src.contains("B8 fixpoint-driver"),
        "B8 fixpoint-driver missing — the fixpoint-proof cost axis is a guarded measurement obligation (§9.90)"
    );
    assert!(
        src.contains("the fixpoint drifted"),
        "B8 must fail closed on fixpoint drift — the equality assertion is the axis's precondition"
    );

    // The target-skin fixpoint cost axis (§9.97, the switch-window
    // step 4 closure measurement face): B10 and its fail-closed
    // precondition must stay in the harness — the axis pins the
    // production bridge's own cost (the <2x question the plan's risk
    // register carries), which the step-5 S-expr production face
    // removal evaluation consumes.
    assert!(
        src.contains("B10 target-fixpoint-driver"),
        "B10 target-fixpoint-driver missing — the target-skin fixpoint cost axis is a guarded measurement obligation (§9.97)"
    );
    assert!(
        src.contains("the target fixpoint drifted"),
        "B10 must fail closed on target fixpoint drift — the equality assertion is the axis's precondition"
    );
}

//! The W-SEXP-RETIRE blade-1 single-skin corpus closeout
//! (w-sexp-retire-window.md SR-1/SR-2/SR-3; stage0.md §9.98's
//! two-skin sweep, retired at v0.111.0): ALL corpus cases, ONE skin.
//!
//! The pre-migration sweep (r104-v0.110.0) paired every `.krf`
//! original with a target-skin twin — mechanical transcode, hand
//! twin, or one of the pinned divergences — and proved the two-skin
//! contract case by case. The blade-1 migration (r150) materialized
//! those twins as the `.ktf` corpus files themselves; the per-case
//! two-skin equivalence — including the three gates (α-equivalence,
//! one semantic bytecode, one value face) for the value/warning
//! mechanical family — was proven ONCE at migration time and lives
//! in the migration report (tool-results/r150-migration-report.txt,
//! the `sexp_corpus_migration` example's output; SR-3's one-time
//! proof). This file pins the single-skin steady state:
//!
//! - every `.ktf` corpus case holds its `// expect:` contract
//!   through the production target reader (`validate_target` — the
//!   dual-engine parity inside is the corpus face's engine
//!   differential, unchanged);
//! - the migration families ride as provenance tables (the
//!   stage-divergent family's target-face rejection class is
//!   `parse-error` — the grammar-directed reader rejects what the
//!   permissive S-expr reader deferred to the expander);
//! - the three retired divergences (SR-2) live as behavior pins on
//!   the target face (blade 2, r151 — their S-expr seed legs retired
//!   with the reader): neg-021 (ruling C12 — `()` reads as nil),
//!   pos-031 (the keyword economy reserves `else` in value
//!   position), neg-036 (the handler arm skin is inherently
//!   fn-wrapped, E0007 unreachable — the subjects have no S-expr
//!   face left to test).

use kerf::compiler::compile_program;
use kerf::driver::{CorpusCase, Expectation, validate_target};
use kerf::expander::expand_program;
use kerf::reader::read_target_program;
use kerf::span::FileId;
use kerf::vm::Vm;

const CORPUS_DIR: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/tests/v1/stage1/corpus");

const FILE: FileId = FileId(0);

/// The corpus programs walk deep on the harness side (the value walk
/// is Rust recursion) — the sibling tests' demand-allocated stack
/// discipline.
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly");
}

// ---------- the migration provenance tables ----------

/// The hand-twin family (11): the parse-error twins (the malformed
/// target programs whose rejection class matches their originals'),
/// the negative-literal arithmetic compositions (the i64::MIN
/// boundary — the target face has no negative literal), the ruling-D
/// path-form module twins, and bnd-007's generated nesting twin.
/// The twins ARE the `.ktf` corpus files since the migration; the
/// table pins the provenance (which cases did NOT ride the
/// mechanical transcoder).
const HAND_TWIN_CASES: &[&str] = &[
    "neg-001-unclosed-paren.ktf",
    "neg-002-stray-close.ktf",
    "neg-003-unterminated-string.ktf",
    "neg-004-bad-hash-token.ktf",
    "neg-055-float-overflow-literal.ktf",
    "neg-054-i64-overflow-literal.ktf",
    "bnd-002-i64-min.ktf",
    "bnd-003-sub-min-overflow.ktf",
    "neg-018-module-cycle.ktf",
    "neg-019-module-missing.ktf",
    "bnd-007-nesting-257-fails.ktf",
];

/// The stage-divergent family (9): the malformed keyword-headed
/// forms — the S-expr reader was shape-permissive (the expander
/// rejected), the target reader is grammar-directed (the READ
/// rejects). Both skins rejected the malformed programs at their own
/// stage boundaries; the `.ktf` corpus twin pins the TARGET-face
/// rejection class (`parse-error` — the family's defining property
/// post-migration).
const STAGE_DIVERGENT_CASES: &[&str] = &[
    "neg-011-malformed-fn.ktf",
    "neg-012-malformed-let.ktf",
    "neg-016-malformed-handle.ktf",
    "neg-065-match-3tuple-unsupported.ktf",
    "neg-066-match-nested-unsupported.ktf",
    "neg-067-match-malformed-arity.ktf",
    "neg-068-match-malformed-arm.ktf",
    "neg-071-match-exhaust-before-pattern.ktf",
    "neg-072-match-scrutinee-before-pattern.ktf",
];

/// The macro-declaration family (the r103 registered gap, CLEARED at
/// r114 — TD-007): every case rode the mechanical transcode's
/// `macro name { spec }` declaration carrier. The anchors below pin
/// the carrier's emitted shape on two of the eight corpus files.
const MACRO_DECLARATION_CASES: &[&str] = &[
    "pos-024-macro-my-if.ktf",
    "pos-032-macro-two-generations.ktf",
    "pos-033-hygiene-binder-collision.ktf",
    "neg-050-pattern-mismatch.ktf",
    "neg-051-duplicate-pattern-vars.ktf",
    "neg-052-ellipsis-rejected.ktf",
    "neg-053-module-macro-outside.ktf",
    "bnd-010-expansion-limit.ktf",
];

// ---------- the retired divergences (SR-2) — the historical record ----------

// The three retired seed sources (neg-021's empty application,
// pos-031's `else` literal macro, neg-036's bare-expression handler
// arm) rode the S-expr face; their inline seed texts retired with the
// reader at blade 2 (r151). The surviving substance of each pin lives
// below on the target face: ruling C12 (`()` is nil), the keyword
// economy (`else` rejects in value position), and the fn-wrapped arm
// grammar (E0007 unreachable). The full migration record rides
// tool-results/r150-migration-report.txt.

// ---------- the single-skin sweep ----------

/// One corpus case's row (the name and its pinned expectation).
struct SweepRow {
    case: String,
    expectation: Expectation,
}

/// The full sweep: every `.ktf` file in the corpus directory through
/// the production target reader. Returns the rows — the tests assert
/// on them.
fn sweep_corpus() -> Vec<SweepRow> {
    let mut entries: Vec<_> = std::fs::read_dir(CORPUS_DIR)
        .expect("the corpus directory reads")
        .map(|e| {
            e.expect("the entry reads")
                .file_name()
                .to_string_lossy()
                .to_string()
        })
        .filter(|n| n.ends_with(".ktf"))
        .collect();
    entries.sort();
    assert_eq!(
        entries.len(),
        109,
        "the corpus is 109 cases (112 minus the three retired divergences — SR-2)"
    );
    let mut rows = Vec::new();
    for name in entries {
        let source = std::fs::read_to_string(format!("{CORPUS_DIR}/{name}"))
            .unwrap_or_else(|e| panic!("case `{name}` reads: {e}"));
        let case = CorpusCase::from_source(&name, &source)
            .unwrap_or_else(|e| panic!("case `{name}`'s directive parses: {e}"));
        let report = validate_target(&case);
        assert!(
            report.matched,
            "case `{name}`: the target-skin contract drifted: {}",
            report.drift.as_deref().unwrap_or("no drift note")
        );
        let expectation = case.expectation.clone();
        rows.push(SweepRow {
            case: name,
            expectation,
        });
    }
    rows
}

#[test]
fn all_109_corpus_cases_hold_on_the_target_skin() {
    deep_stack(|| {
        let rows = sweep_corpus();
        let count = |prefix: &str| rows.iter().filter(|r| r.case.starts_with(prefix)).count();
        // The corpus face (45/54/10 — the floors' current shape; the
        // three retired divergences aside, every pre-migration case
        // survives).
        assert_eq!(count("pos-"), 45, "the positive family");
        assert_eq!(count("neg-"), 54, "the negative family");
        assert_eq!(count("bnd-"), 10, "the boundary family");
        // The migration provenance tables are exact subsets.
        let by_name = |n: &str| {
            rows.iter()
                .find(|r| r.case == n)
                .unwrap_or_else(|| panic!("case `{n}` must be in the sweep"))
        };
        for name in HAND_TWIN_CASES {
            by_name(name);
        }
        // The stage-divergent family's defining property: the
        // target-face rejection class is `parse-error`.
        for name in STAGE_DIVERGENT_CASES {
            assert!(
                matches!(by_name(name).expectation, Expectation::ParseError),
                "case `{name}`: the stage-divergent twin pins the target read-stage rejection"
            );
        }
        // The family spot anchors (the provenance tables' named rows).
        assert!(
            matches!(&by_name("pos-009-recursion-fib.ktf").expectation,
                     Expectation::Value(v) if v == "55"),
            "the fib anchor holds its value"
        );
        assert!(
            matches!(
                by_name("bnd-007-nesting-257-fails.ktf").expectation,
                Expectation::ParseError
            ),
            "the nesting anchor rejects at the depth limit"
        );
        assert!(
            matches!(&by_name("bnd-002-i64-min.ktf").expectation,
                     Expectation::Value(v) if v == "-9223372036854775808"),
            "the i64::MIN anchor composes the boundary value arithmetically"
        );
        assert!(
            matches!(
                by_name("neg-018-module-cycle.ktf").expectation,
                Expectation::ExpandError
            ),
            "the ruling-D path-form anchor still rejects at the loader"
        );
    });
}

#[test]
fn the_macro_declaration_family_carries_the_carrier_anchors() {
    deep_stack(|| {
        // The declaration carrier's emitted shape on two of the
        // eight family files (the migration's form anchors — one
        // spot check per shape: the declaration, and the
        // module-nested declaration).
        let decl =
            std::fs::read_to_string(format!("{CORPUS_DIR}/pos-024-macro-my-if.ktf")).unwrap();
        assert!(
            decl.contains("macro my_if { (syntax_rules, nil,"),
            "the declaration carrier anchor: {decl}"
        );
        let nested =
            std::fs::read_to_string(format!("{CORPUS_DIR}/neg-053-module-macro-outside.ktf"))
                .unwrap();
        assert!(
            nested.contains("module m {\n    macro inner_m {"),
            "the nested declaration anchor: {nested}"
        );
        // The family provenance: all eight names are corpus files
        // (the sweep above validated them; this pins the table's
        // membership against the directory).
        for name in MACRO_DECLARATION_CASES {
            assert!(
                std::fs::metadata(format!("{CORPUS_DIR}/{name}")).is_ok(),
                "case `{name}`: the macro family table matches the directory"
            );
        }
    });
}

#[test]
fn the_unit_divergence_is_ruling_c12_pinned() {
    deep_stack(|| {
        // The target face: `()` is the unit skin of nil — the
        // program HALTS with result nil (ruling C12, verified as
        // behavior).
        let twin = "define(result, ());";
        let forms = read_target_program(FILE, twin)
            .expect("the unit reads as nil on the target face (ruling C12)");
        let items = expand_program(&forms).expect("the unit program expands");
        let bc = compile_program(&items).expect("the unit program compiles");
        let mut vm = Vm::new(bc).expect("the unit program loads");
        vm.run().expect("the unit program halts (the C12 mapping)");
        let value = vm.global("result").expect("the result global binds");
        assert_eq!(
            value,
            &kerf::vm::Value::Nil,
            "ruling C12: `()` is the unit skin of nil"
        );
        // The S-expr seed leg (the empty application's read-stage
        // rejection) retired with the reader at blade 2 — its record
        // rides the note above and the migration report.
    });
}

#[test]
fn the_keyword_vocabulary_divergence_is_pinned() {
    deep_stack(|| {
        // pos-031's divergence record (the corpus file retired at the
        // migration; the seed face and the mechanical transcoder
        // retired with the S-expr reader at blade 2): the S-expr face
        // read `else` as a plain symbol (the macro literal); the
        // target EXPRESSION grammar reserves `else` structurally —
        // the use form has no target spelling (the inverse-C12 shape:
        // the grammar accepts no name it reserves). The surviving pin
        // (the keyword economy): the reserved word rejects in value
        // position on the target face — the divergence IS the
        // grammar's design, re-verified as behavior.
        let err = read_target_program(FILE, "define(result, else);")
            .expect_err("the reserved word rejects in value position");
        assert!(
            matches!(
                err,
                kerf::reader::ReadError::UnexpectedTargetToken { .. }
                    | kerf::reader::ReadError::UnsupportedTargetForm { .. }
            ),
            "the reservation is the reader's structured rejection: {err:?}"
        );
    });
}

#[test]
fn the_shape_divergent_arm_grammar_pins_the_fn_wrapping() {
    deep_stack(|| {
        // The target face: the arm grammar wraps every handler body
        // in the fn form (`e(x) => { 7 }` is (e (fn () 7)) — a VALID
        // zero-arg handler), so E0007's literal-handler face is
        // unreachable on the target grammar. The pin: the fn-wrapped
        // spelling is well-formed end to end.
        let twin = "define(result, handle (perform e(1)) { e(x) => { 7 }, });";
        let forms =
            read_target_program(FILE, twin).expect("the fn-wrapped arm reads on the target face");
        let items = expand_program(&forms).expect("the fn-wrapped arm expands");
        let bc = compile_program(&items).expect("the fn-wrapped arm compiles");
        let mut vm = Vm::new(bc).expect("the fn-wrapped arm loads");
        vm.run()
            .expect("the fn-wrapped arm runs (E0007 unreachable by grammar)");
        // The S-expr seed leg (the bare-expression arm's E0007)
        // retired with the reader at blade 2 — its record rides the
        // note above and the migration report.
    });
}

// The retired faces (the migration's honest record): the two-skin
// per-case contract (the mechanical transcode, the hand-twin tables,
// the three gates) proved every case's equivalence ONCE at migration
// time — tool-results/r150-migration-report.txt. The one-shot
// migration arm (`examples/retire/sexp_corpus_migration.rs`) and the
// transcoder itself retired with the reader at blade 2 (r151 — the
// r104 one-shot-artifact precedent); the fixpoint faces
// (`fixpoint_selfhost_compiler_target`) and the composed-chain
// differentials carry the ongoing chain-level equivalence.

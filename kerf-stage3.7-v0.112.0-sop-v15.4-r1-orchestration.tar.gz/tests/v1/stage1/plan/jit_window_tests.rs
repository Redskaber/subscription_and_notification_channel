//! The W-3.7 JIT/superinstruction evaluation window integration
//! suite (stage-3-plan §2.3 W-3.7, window record
//! `docs/develop/v3/w3.7-jit-window.md`), REGENERATED at W-VM-SUPERINSTR
//! r133 (w-vm-superinstr-window.md SI-5) and r134 (FA-6): the census
//! premises were re-derived against the fused emission and then the
//! F1 direct-arithmetic blade — a global callee rides one
//! `call-global` (SI-1) and an unpoisoned two-argument arithmetic
//! site rides its direct Add/Sub/Mul/Div arm (FA-2).
//!
//! GATE 6 shape: two positive integration cases (the full-chain
//! census exactness anchor — every count of a fixed program pinned
//! against the hand-derived execution sequence, cross-stage through
//! read → expand → compile → observed run — and the superinstruction
//! candidate semantic-equivalence pins, the direct/fused emission
//! regression baseline) plus six negative cases (the F1
//! direct-emission liveness pin, the jump-target-tail non-fusability
//! classifier, the census terminating exactly at the failing pc, the
//! error-path parity, the budget/GC-determinism parity under
//! observation, and the cross-frame non-adjacency classifier) — the
//! negative cases outnumber the positive ones by exactly 3:1 on this
//! window's test face (the r119 gc_window shape).
//!
//! The window's adjudication (window record §4) rests on the
//! dispatch portrait findings; these tests pin the structural facts
//! the adjudication rests on as fail-closed tripwires:
//! - F1 (arithmetic-via-builtin-call → direct arms): surface
//!   arithmetic now executes the direct Add/Sub/Mul/Div opcodes at
//!   every unpoisoned two-argument site (the r134 blade reversed the
//!   cold-era alarm into the liveness pin; the poisoned-name
//!   fallbacks ride the superinstr F1 family).
//! - F4 (the load-global+call hot pair → call-global): every global
//!   callee load is fused into its call at the emission site — the
//!   fused instruction the portrait's #1 candidate predicted.
//! - The observer seam is inert: identical values, identical errors,
//!   identical GC determinism (the D-CLASS-1 triplet) with and
//!   without observation.

use std::collections::HashMap;

use kerf::compiler::compile_program;
use kerf::compiler::{Bytecode, FuncProto, Instr, Opcode};
use kerf::expander::expand_program;
use kerf::reader::read_target_program;
use kerf::runtime::GcStats;
use kerf::runtime::collect as production_collect;
use kerf::span::{ByteOffset, ExpansionId, FileId, Span, Symbol};
use kerf::vm::{Collector, Heap, Roots, Vm, VmObserver};

// ---------- the census fixture (the portrait harness's observer,
// in test form) ----------

/// The census state: per-opcode counts, adjacent-pair histograms
/// with fusable classification, per-function counts, total.
#[derive(Default)]
struct Census {
    opcode_counts: Vec<u64>,
    pairs: HashMap<(usize, usize), u64>,
    fusable_pairs: HashMap<(usize, usize), u64>,
    func_counts: Vec<u64>,
    last: Option<(usize, usize, usize)>,
    total: u64,
}

impl Census {
    fn opcode_count(&self, op: Opcode) -> u64 {
        self.opcode_counts.get(op.ordinal()).copied().unwrap_or(0)
    }

    fn pair_count(&self, first: Opcode, second: Opcode) -> u64 {
        self.pairs
            .get(&(first.ordinal(), second.ordinal()))
            .copied()
            .unwrap_or(0)
    }

    fn fusable_pair_count(&self, first: Opcode, second: Opcode) -> u64 {
        self.fusable_pairs
            .get(&(first.ordinal(), second.ordinal()))
            .copied()
            .unwrap_or(0)
    }
}

/// The census observer (borrows the census and the precomputed
/// jump-target bitmap — the same classification the portrait harness
/// performs, in test form).
struct CensusObserver<'a> {
    census: &'a mut Census,
    jump_targets: &'a [Vec<bool>],
}

impl VmObserver for CensusObserver<'_> {
    fn observe(&mut self, op: Opcode, func: usize, pc: usize) {
        let ord = op.ordinal();
        let census = &mut *self.census;
        if census.opcode_counts.len() <= ord {
            census.opcode_counts.resize(ord + 1, 0);
        }
        census.opcode_counts[ord] += 1;
        if census.func_counts.len() <= func {
            census.func_counts.resize(func + 1, 0);
        }
        census.func_counts[func] += 1;
        if let Some((last_func, last_pc, last_ord)) = census.last {
            if last_func == func && last_pc + 1 == pc {
                *census.pairs.entry((last_ord, ord)).or_insert(0) += 1;
                let target = self
                    .jump_targets
                    .get(func)
                    .map(|t| t.get(pc).copied().unwrap_or(false))
                    .unwrap_or(false);
                if !target {
                    *census.fusable_pairs.entry((last_ord, ord)).or_insert(0) += 1;
                }
            }
        }
        census.last = Some((func, pc, ord));
        census.total += 1;
    }
}

/// Compile a .ktf source to bytecode (the B-axis harness shape).
fn bc(src: &str) -> Bytecode {
    let forms = read_target_program(FileId(0), src).expect("read");
    let items = expand_program(&forms).expect("expand");
    compile_program(&items).expect("compile")
}

/// Static jump-target bitmap per function (the fusion-validity input).
fn jump_targets(bc: &Bytecode) -> Vec<Vec<bool>> {
    bc.funcs
        .iter()
        .map(|proto| {
            let mut targets = vec![false; proto.code.len()];
            for instr in &proto.code {
                if matches!(instr.op, Opcode::Jump | Opcode::JumpIfFalse) {
                    let target = instr.a as usize;
                    if target < targets.len() {
                        targets[target] = true;
                    }
                }
            }
            targets
        })
        .collect()
}

/// Run a source program under observation; return the census and the
/// `result` global's value string.
fn run_census(src: &str) -> (Census, String) {
    let bytecode = bc(src);
    let jump_targets = jump_targets(&bytecode);
    let mut census = Census::default();
    let mut vm = Vm::new(bytecode).expect("vm");
    {
        let mut observer = CensusObserver {
            census: &mut census,
            jump_targets: &jump_targets,
        };
        vm.run_observed(&mut observer)
            .expect("observed program halts");
    }
    let value = vm
        .global("result")
        .map(|v| v.to_string())
        .expect("result global bound");
    (census, value)
}

// ---------- positive 1: the full-chain census exactness anchor ----------

/// The fixed program and its hand-derived execution sequence (the
/// window record §2b derivation, mirrored here so the anchor is
/// auditable; the W-VM-SUPERINSTR r133 regeneration — SI-5 — fuses
/// both global callee loads):
///
/// ```text
/// `fn double(x) { (2 * x) }` + `define(result, double(21));`
///
/// entry   [closure 1, store-global double, push-const 21,
///          call-global double 1, store-global result, halt]
/// double  [push-const 2, load-local 0, call-global * 2, ret]
/// ```
///
/// Execution order (args first, callee last — the §19.3 contract;
/// the callee rides the global slot, never the stack — SI-3):
/// closure f0p0, store-global f0p1, push-const f0p2, call-global
/// f0p3 → push-const f1p0, load-local f1p1, call-global f1p2, ret
/// f1p3 → store-global f0p4, halt f0p5.
/// TEN instructions (was twelve pre-fusion: one callee load removed
/// per call site), seven adjacent pairs, zero arithmetic opcodes,
/// zero unfused global calls.
///
/// Cross-stage consumer: the program goes through the full chain
/// (read → expand → compile → observed run), so the anchor pins the
/// whole pipeline's emission shape, not just the observer face.
#[test]
fn w37_census_exactness_full_chain() {
    // The ordinal round-trip prelude: the census keys are stable
    // (Opcode::ALL[i].ordinal() == i — a reordering of ALL or a
    // drift in the mapping fails here, not silently in the histograms).
    for (index, op) in Opcode::ALL.into_iter().enumerate() {
        assert_eq!(op.ordinal(), index, "Opcode::ALL[{index}] ordinal drift");
    }

    let (census, value) = run_census("fn double(x) { (2 * x) }\ndefine(result, double(21));");
    assert_eq!(value, "42");

    // Total and per-opcode counts (the hand-derived table).
    assert_eq!(census.total, 10);
    assert_eq!(census.opcode_count(Opcode::Closure), 1);
    assert_eq!(census.opcode_count(Opcode::StoreGlobal), 2);
    assert_eq!(census.opcode_count(Opcode::PushConst), 2);
    assert_eq!(census.opcode_count(Opcode::CallGlobal), 1);
    assert_eq!(census.opcode_count(Opcode::LoadLocal), 1);
    assert_eq!(census.opcode_count(Opcode::Mul), 1);
    assert_eq!(census.opcode_count(Opcode::Ret), 1);
    assert_eq!(census.opcode_count(Opcode::Halt), 1);
    // The fused form owns the non-arithmetic call site; the direct
    // arm owns the arithmetic site: zero unfused loads/calls of a
    // global callee (the portrait's #1 pair is gone from compiled
    // products — the r133 fusion holds) and zero arithmetic
    // call-globals (the r134 F1 blade holds).
    assert_eq!(census.opcode_count(Opcode::LoadGlobal), 0);
    assert_eq!(census.opcode_count(Opcode::Call), 0);

    // The adjacent-pair table (seven occurrences, all fusable — the
    // program has no jumps).
    assert_eq!(census.pair_count(Opcode::Closure, Opcode::StoreGlobal), 1);
    assert_eq!(census.pair_count(Opcode::StoreGlobal, Opcode::PushConst), 1);
    assert_eq!(census.pair_count(Opcode::PushConst, Opcode::CallGlobal), 1);
    assert_eq!(census.pair_count(Opcode::PushConst, Opcode::LoadLocal), 1);
    assert_eq!(census.pair_count(Opcode::LoadLocal, Opcode::Mul), 1);
    assert_eq!(census.pair_count(Opcode::Mul, Opcode::Ret), 1);
    assert_eq!(census.pair_count(Opcode::StoreGlobal, Opcode::Halt), 1);
    // The pre-fusion pair is fully consumed — zero residual
    // load-global+call adjacency in compiled surface code.
    assert_eq!(census.pair_count(Opcode::LoadGlobal, Opcode::Call), 0);
    assert_eq!(
        census.fusable_pair_count(Opcode::LoadGlobal, Opcode::Call),
        0
    );
    // ---- r135 (TJ-1) extension: the mirrored program with the
    // (local, const) argument order — `(* x 2)` — exercises the
    // fused copy pair. Nine instructions (the pair collapses to
    // one load-local-const), full hand-derived chain: entry =
    // closure, store-global, push-const 21, call-global, store-
    // global, halt (6); f = load-local-const, mul, ret (3).
    {
        let (census, value) = run_census("fn f(x) { (x * 2) }\ndefine(result, f(21));");
        assert_eq!(value, "42");
        assert_eq!(census.total, 9);
        assert_eq!(census.opcode_count(Opcode::LoadLocalConst), 1);
        assert_eq!(census.opcode_count(Opcode::LoadLocal), 0);
        assert_eq!(census.opcode_count(Opcode::PushConst), 1);
        assert_eq!(census.opcode_count(Opcode::CallGlobal), 1);
        assert_eq!(census.opcode_count(Opcode::Mul), 1);
        assert_eq!(census.pair_count(Opcode::LoadLocalConst, Opcode::Mul), 1);
        assert_eq!(
            census.pair_count(Opcode::LoadLocal, Opcode::PushConst),
            0,
            "no residual unfused copy pair in compiled products"
        );
    }
    // Cross-frame non-adjacency: call-global f0p3 is followed (in
    // observation order) by push-const f1p0 — a different function,
    // NOT a pair; ret f1p3 is followed by store-global f0p4 — again
    // cross-frame, NOT a pair.
    assert_eq!(census.pair_count(Opcode::CallGlobal, Opcode::PushConst), 0);
    assert_eq!(census.pair_count(Opcode::Ret, Opcode::StoreGlobal), 0);

    // Hot-function concentration: double carries 4 of 10.
    assert_eq!(census.func_counts, vec![6, 4]);
}

// ---------- positive 2: the candidate semantic-equivalence pins ----------

/// The MUV 3.7-a integration verification case, regenerated twice
/// (SI-5 for the fusion, FA-6 for the direct arithmetic): the
/// portrait's top candidate shapes are now the direct arithmetic
/// arms, the fused call-global for non-arithmetic callees, and the
/// constant/local feeds into each. A program exercising every shape
/// pins its exact semantics — the regression baseline any future
/// emission change must reproduce bit-for-bit.
#[test]
fn w37_candidate_pair_semantic_equivalence_pins() {
    // The arithmetic site: the F1 direct arm owns it entirely — one
    // add, no call-global, value semantics pinned alongside.
    {
        let (census, value) = run_census("define(result, (1 + 2));");
        assert_eq!(value, "3", "candidate pin drifted for (+ 1 2)");
        assert_eq!(
            census.opcode_count(Opcode::Add),
            1,
            "the direct arm must own the arithmetic site"
        );
        assert_eq!(
            census.opcode_count(Opcode::CallGlobal),
            0,
            "no fused call survives at a direct arithmetic site"
        );
        assert_eq!(
            census.pair_count(Opcode::LoadGlobal, Opcode::Call),
            0,
            "no residual unfused global-call pair"
        );
    }
    // The arithmetic chain: a nested `(* 1 2)` feeding an outer
    // `+` — two direct arms back-to-back (the mul feeding add, the
    // new fib-shape chain the re-profiling measures).
    {
        let (census, value) = run_census("define(result, (40 + (1 * 2)));");
        assert_eq!(value, "42");
        assert_eq!(census.opcode_count(Opcode::Mul), 1);
        assert_eq!(census.opcode_count(Opcode::Add), 1);
        assert!(
            census.pair_count(Opcode::Mul, Opcode::Add) > 0,
            "the direct arms chain: mul feeding add"
        );
    }
    // A constant feeding the fused callee site (the fib shape's
    // non-arithmetic face post-F1: a comparison's constant arg
    // directly before call-global).
    {
        let (census, value) = run_census("define(result, (40 < 41));");
        assert_eq!(value, "true");
        assert!(
            census.pair_count(Opcode::PushConst, Opcode::CallGlobal) > 0,
            "push-const + call-global must be dynamically present"
        );
        assert!(
            census.fusable_pair_count(Opcode::PushConst, Opcode::CallGlobal) > 0,
            "push-const + call-global present but never fusable"
        );
    }
    // A local feeding a constant push (the fib shape's #3 —
    // load-local THEN push-const: `(+ x 1)` emitted the local
    // first, the constant second). REVERSED by the r135 blade
    // (TJ-1): the copy pair is now FUSED — `(+ x 1)` emits one
    // load-local-const and the pair's slots never round-trip
    // through separate dispatches; the r132 cold-era candidate
    // pin became the liveness pin (the fused opcode owns the
    // site, zero residual unfused pairs). The call/control-shaped
    // pairs pinned above stay unfused — tier-1 absorption
    // territory (TJ-2).
    {
        let (census, value) = run_census("fn f(x) { (x + 1) }\ndefine(result, f(41));");
        assert_eq!(value, "42");
        assert!(
            census.opcode_count(Opcode::LoadLocalConst) > 0,
            "the fused copy pair must own the (local, const) argument site"
        );
        assert_eq!(
            census.pair_count(Opcode::LoadLocal, Opcode::PushConst),
            0,
            "no residual unfused copy pair survives in compiler products"
        );
    }
    // The branch arm: a fused BUILTIN call whose value feeds
    // jump-if-false (the fib shape's #4 post-fusion —
    // call-global + jump-if-false; builtin calls run inline and
    // preserve the frame, so the pair forms — a kerf-function
    // call's return crosses frames and does not).
    {
        let (census, value) = run_census("define(result, if ((5 < 2)) { 0 } else { 42 });");
        assert_eq!(value, "42");
        assert!(
            census.pair_count(Opcode::CallGlobal, Opcode::JumpIfFalse) > 0,
            "call-global + jump-if-false must be dynamically present"
        );
        assert!(
            census.fusable_pair_count(Opcode::CallGlobal, Opcode::JumpIfFalse) > 0,
            "call-global + jump-if-false present but never fusable"
        );
    }
}

// ---------- negative 1: the F1 direct-emission liveness pin ----------

/// The r132 portrait's F1 finding, REVERSED by the r134 blade
/// (FA-6): surface arithmetic now rides the direct Add/Sub/Mul/Div
/// arms — the cold-era alarm ("zero arithmetic opcodes in surface
/// code") became the liveness pin (every arithmetic site carries
/// exactly its direct arm, zero fused calls). The poisoned-name
/// fallback shapes are pinned in the superinstr F1 family (the
/// set!/define/extern rebinding probes); this tripwire fires when
/// a future emission change regresses the direct arms back to the
/// call path.
#[test]
fn w37_arithmetic_opcodes_direct_emit_in_surface_code() {
    let (census, value) = run_census(
        "define(a, (1 + 2));\ndefine(b, (a - 1));\ndefine(c, (b * 3));\ndefine(result, (c / 2));",
    );
    assert_eq!(value, "3");
    assert_eq!(census.opcode_count(Opcode::Add), 1, "F1 drift: add missing");
    assert_eq!(census.opcode_count(Opcode::Sub), 1, "F1 drift: sub missing");
    assert_eq!(census.opcode_count(Opcode::Mul), 1, "F1 drift: mul missing");
    assert_eq!(census.opcode_count(Opcode::Div), 1, "F1 drift: div missing");
    // The arithmetic path IS the direct-arm path: zero fused calls,
    // zero unfused callees.
    assert_eq!(census.opcode_count(Opcode::CallGlobal), 0);
    assert_eq!(census.opcode_count(Opcode::Call), 0);
    assert_eq!(census.pair_count(Opcode::LoadGlobal, Opcode::Call), 0);
}

// ---------- negative 2: the jump-target-tail non-fusability ----------

/// A pair whose tail pc is a static jump target is NOT fusable:
/// fusion would break the entering edge. Hand-built bytecode with a
/// taken jump-if-false whose target is the immediately following
/// instruction — the (jump-if-false, push-const) pair executes
/// back-to-back, is counted in the pair histogram, and must be
/// excluded from the fusable sub-histogram.
#[test]
fn w37_jump_target_tail_is_classified_non_fusable() {
    let code = vec![
        Instr::new(Opcode::PushConst),         // p0: false
        Instr::with_a(Opcode::JumpIfFalse, 2), // p1: taken → p2 (target)
        Instr::with_a(Opcode::PushConst, 0),   // p2: a jump target AND a pair tail
        Instr::new(Opcode::Halt),              // p3
    ];
    let mut proto = FuncProto::new(None, 0, 0);
    proto.code = code;
    proto.debug_info = vec![fix_span(); proto.code.len()];
    let mut bytecode = Bytecode::default();
    bytecode.funcs.push(proto);
    bytecode.consts = vec![
        kerf::core::LiteralValue::Bool(false),
        kerf::core::LiteralValue::Int(7),
    ];
    bytecode.globals = vec![Symbol::new("r").unwrap()];
    let jump_targets = jump_targets(&bytecode);
    assert!(jump_targets[0][2], "fixture premise: pc2 is a jump target");

    let mut census = Census::default();
    let mut vm = Vm::new(bytecode).expect("hand-built product verifies");
    {
        let mut observer = CensusObserver {
            census: &mut census,
            jump_targets: &jump_targets,
        };
        vm.run_observed(&mut observer).expect("fixture halts");
    }
    // The pair executed back-to-back (p1 taken → p2 = p1+1)...
    assert_eq!(census.pair_count(Opcode::JumpIfFalse, Opcode::PushConst), 1);
    // ...and must be classified NON-fusable (the tail is the target).
    assert_eq!(
        census.fusable_pair_count(Opcode::JumpIfFalse, Opcode::PushConst),
        0,
        "a jump-target tail must never be fusable"
    );
    // The leading pair (p0→p1) has a non-target tail: fusable.
    assert_eq!(
        census.fusable_pair_count(Opcode::PushConst, Opcode::JumpIfFalse),
        1
    );
}

// ---------- negative 3: the census terminates exactly at the failing pc ----------

/// A failing program's census stops at exactly the failing
/// instruction: it IS observed (the fetch happened), nothing after
/// it is. `define(result, first(1));` → entry [push-const 1,
/// call-global car 1, store-global, halt]; the fused call fails —
/// two observations, the last being (call-global, func 0, pc 1).
#[test]
fn w37_census_terminates_exactly_at_the_failing_pc() {
    let src = "define(result, first(1));";
    let bytecode = bc(src);
    let jump_targets = jump_targets(&bytecode);
    let mut census = Census::default();
    let mut vm = Vm::new(bytecode).expect("vm");
    let observed_err = {
        let mut observer = CensusObserver {
            census: &mut census,
            jump_targets: &jump_targets,
        };
        vm.run_observed(&mut observer)
            .expect_err("car of an int must fail")
    };
    // Identical failure without observation (the parity arm).
    let mut plain = Vm::new(bc(src)).expect("vm");
    let plain_err = plain.run().expect_err("plain run fails identically");
    assert_eq!(
        format!("{observed_err:?}"),
        format!("{plain_err:?}"),
        "observed and plain failures must be identical"
    );
    assert_eq!(census.total, 2);
    assert_eq!(census.last, Some((0, 1, Opcode::CallGlobal.ordinal())));
    assert_eq!(
        census.opcode_count(Opcode::StoreGlobal),
        0,
        "nothing after the failure"
    );
}

// ---------- negative 4: the error-path parity (distinct error family) ----------

/// The seam is inert on a SECOND error family (division by zero — a
/// different variant than negative 3's type mismatch): identical
/// error debug form, identical absent result global.
#[test]
fn w37_error_path_parity_under_observation_div_by_zero() {
    let src = "define(result, (1 / 0));";
    let bytecode = bc(src);
    let jump_targets = jump_targets(&bytecode);
    let mut census = Census::default();
    let mut vm = Vm::new(bytecode).expect("vm");
    {
        let mut observer = CensusObserver {
            census: &mut census,
            jump_targets: &jump_targets,
        };
        vm.run_observed(&mut observer)
            .expect_err("division by zero must fail");
    }
    let mut plain = Vm::new(bc(src)).expect("vm");
    let plain_err = plain.run().expect_err("plain run fails");
    match &plain_err {
        kerf::vm::RuntimeError::DivByZero { .. } => {}
        other => panic!("expected division by zero, got {other:?}"),
    }
    // The div-by-zero happens in the direct div arm: entry is
    // [push-const 1, push-const 0, div, ...] — three observations,
    // the last being the failing direct arm at pc 2 (the same
    // single `arith` source the builtin dispatch shares — FA-3).
    assert_eq!(census.total, 3);
    assert_eq!(census.last, Some((0, 2, Opcode::Div.ordinal())));
    assert!(plain.global("result").is_none());
}

// ---------- negative 5: budget/GC determinism parity under observation ----------

/// The seam must not perturb the §19.4 safety point or the
/// collector: churn(2000) under the 1024 budget produces the pinned
/// D-CLASS-1 triplet (gc 1 / swept 1023) WITH observation too (the
/// r119 equivalence class, observed), and a tight budget fails
/// closed identically with and without the observer.
#[test]
fn w37_budget_and_gc_determinism_triplet_unchanged_under_observation() {
    fn churn_src(pairs: usize) -> String {
        let mut src = String::with_capacity(pairs * 32);
        for i in 0..pairs {
            src.push_str(&format!("define(d{i}, first(pair({i}, nil))); "));
        }
        src.push_str("define(result, d0);");
        src
    }

    /// A collector recording every cycle's full GcStats.
    #[derive(Clone, Default)]
    struct RecordingCollector {
        cycles: std::rc::Rc<std::cell::RefCell<Vec<GcStats>>>,
    }
    impl Collector for RecordingCollector {
        fn collect(&mut self, heap: &mut Heap, roots: &Roots) -> u32 {
            let stats = production_collect(heap, roots);
            self.cycles.borrow_mut().push(stats);
            stats.swept
        }
    }

    let rec = RecordingCollector::default();
    let bytecode = bc(&churn_src(2_000));
    let churn_jump_targets = jump_targets(&bytecode);
    let mut census = Census::default();
    let mut vm = Vm::with_budget_and_collector(bytecode, 1_024, Box::new(rec.clone()))
        .expect("churn vm builds");
    {
        let mut observer = CensusObserver {
            census: &mut census,
            jump_targets: &churn_jump_targets,
        };
        vm.run_observed(&mut observer)
            .expect("observed churn halts");
    }
    let cycles = rec.cycles.borrow().clone();
    // The D-CLASS-1 triplet, unchanged by observation: one cycle,
    // 1023 swept (the B4 pinned baseline).
    assert_eq!(cycles.len(), 1);
    assert_eq!(cycles[0].swept, 1023);
    assert_eq!(
        vm.global("result").map(|v| v.to_string()),
        Some("0".to_owned())
    );

    // Tight-budget fail-closed parity: budget 2 rejects the second
    // define's allocation identically observed and plain.
    let tight = bc(&churn_src(2));
    let jump_targets_tight = jump_targets(&tight);
    let mut census_tight = Census::default();
    let mut observed_vm = Vm::with_budget(tight.clone(), 2).expect("vm");
    let observed_err = {
        let mut observer = CensusObserver {
            census: &mut census_tight,
            jump_targets: &jump_targets_tight,
        };
        observed_vm
            .run_observed(&mut observer)
            .expect_err("tight budget fails closed")
    };
    let mut plain_vm = Vm::with_budget(tight, 2).expect("vm");
    let plain_err = plain_vm.run().expect_err("plain tight budget fails too");
    assert_eq!(
        format!("{observed_err:?}"),
        format!("{plain_err:?}"),
        "fail-closed boundary identical with and without observation"
    );
}

// ---------- negative 6: the unbound-global parity (load-time family) ----------

/// A third error family with a distinct observation shape: the
/// unbound global fails AT the load-global instruction itself (not
/// at a call) — hand-built bytecode reading a never-stored global
/// (the expander rejects unbound identifiers at expand time, so the
/// runtime UnboundGlobal face is reachable through the product face
/// the VM contract describes: a slot still None when read). The
/// census terminates at the load-global, and the error is identical
/// observed/plain.
#[test]
fn w37_unbound_global_error_parity_under_observation() {
    fn unbound_bc() -> Bytecode {
        let mut proto = FuncProto::new(None, 0, 0);
        proto.code = vec![Instr::new(Opcode::LoadGlobal), Instr::new(Opcode::Halt)];
        proto.debug_info = vec![fix_span(); proto.code.len()];
        let mut bytecode = Bytecode::default();
        bytecode.funcs.push(proto);
        // "r" is no builtin and nothing stores it: the slot is None
        // at the read — the runtime UnboundGlobal face.
        bytecode.globals = vec![Symbol::new("r").unwrap()];
        bytecode
    }

    let jump_targets = vec![vec![false, false]];
    let mut census = Census::default();
    let mut vm = Vm::new(unbound_bc()).expect("vm");
    {
        let mut observer = CensusObserver {
            census: &mut census,
            jump_targets: &jump_targets,
        };
        vm.run_observed(&mut observer)
            .expect_err("unbound global must fail");
    }
    let mut plain = Vm::new(unbound_bc()).expect("vm");
    let plain_err = plain.run().expect_err("plain run fails");
    match &plain_err {
        kerf::vm::RuntimeError::UnboundGlobal { name, .. } => {
            assert_eq!(name.as_str(), "r");
        }
        other => panic!("expected unbound global, got {other:?}"),
    }
    // The failing instruction is the load-global at pc 0: exactly
    // one observation, and nothing after it.
    assert_eq!(census.total, 1);
    assert_eq!(census.last, Some((0, 0, Opcode::LoadGlobal.ordinal())));
}

// ---------- fixture helper ----------

fn fix_span() -> Span {
    Span::new(FileId(0), ByteOffset(0), ByteOffset(8), ExpansionId::ROOT)
        .expect("test fixture span must be well-formed")
}

# tools/ — 自研工具归档（SOP §3.4）

按 `<domain>/` 子目录组织；新工具须同步 docs/tools/<domain>/ 文档。

当前为空（r106 退役清偿）：`selfhost/krf_reformat.py`（r78 归位的 `.krf`
空白级重排器）随 r104 E5 批次 3 拆除的 `selfhost/v1/*.krf` 原件一同退役——
其四 NEEDLES 锚串指向已删除文件，工具与 `docs/tools/selfhost/krf-reformat.md`
文档一并移除。selfhost 五件 `.ktf` 的格式约定（行宽 ≤100 / 非 ASCII 白名单
{`—`, `§`} / 零 ASCII 旁注破折号）由
`tests/v1/stage1/plan/selfhost_format_guard_tests.rs` 机检承载（唯一检查面）。

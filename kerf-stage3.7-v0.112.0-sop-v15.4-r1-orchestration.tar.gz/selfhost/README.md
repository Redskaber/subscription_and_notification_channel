# selfhost/ — the self-hosted bootstrap front end (`.ktf`, the sole production skin)

The front end of the bootstrap chain, written in the frozen kerf subset
itself and driven through the production pipeline: **the target skin
(`.ktf`) is the one and only production chain** — the seven files below
are the r100 switch-window step-3 twins (five) plus the W-HM-TWIN
segment-three twins (two, r127/r128), and the `.krf` S-expr
originals they were twins of were removed at r104 (E5 batch 3; see the
history note at the bottom). Design record: `docs/stage0.md` §9.46-§9.48
(the RS/EX/MX ruling families), §9.83-§9.84 (the CP two passes), §9.87
(the full composed chain), §9.98 (the two-skin corpus closeout), §9.99
(the E5 batch-3 teardown).

## The seven pieces

| File | Layer | Lines | Role |
|---|---|---|---|
| `v1/lexer.ktf` | 1.5 lexical (RS-1) | 671 | the byte-surface host channel — every lexical decision over the raw byte table (trivia / the Unicode whitespace table / the reject set / atom classification / the i64 threshold guard / the f64 grammar automaton / the Symbol floor / escape validation; the K20 permanent host layer = the f64 value face + string decode) |
| `v1/reader.ktf` | 1.5 structure | 141 | the structure layer — token records in, Stx tree out (the iterative `rd_loop`, the REC-A option-3 lineage) |
| `v1/macro.ktf` | 1.7 macro face | 686 | the MX-2 pure-function library — syntax-rules with zero driver defines (assembled ahead of the expander) |
| `v1/expander.ktf` | 1.6 expansion | 1346 | the MX-2 assembly carrier — flat pre-order form stream in, ModuleItem tree out (one self-recursive expander + synthetic node modes) |
| `v1/compiler.ktf` | 2.3 CP two passes | 1501 | the fully self-hosted compile segment — the gate-B dual-caliber carrier (pass 1 lexical-domain analysis; pass 2 instruction emission) |
| `v1/infer.ktf` | 3.12 HM inference (TWIN-1) | 3641 | the segment-three inference face — the `infer_module` mirror: the iterative Algorithm W machine (explicit task stack), the union-find links with the undo log, let-polymorphism generalization, the SCC partition of the call graph, the extern boundary, the 512 depth budget (r127: parity converged bit-for-bit, sweep 5/5) |
| `v1/typecheck.ktf` | 3.12 check face (TWIN-1) | 1234 | the segment-three conservative checker — the `check_module` mirror: the pass-1 module table (check-shaped define shapes + the assigned first-seen list — the INF-9 mirror) and the pass-2 rule walk R1-R8 + the LA-7 captured-assignment boundary, multi-error collection, the diagnostics stream with the r109 F2 subject sets (r128: parity converged bit-for-bit, sweep 6/6 — the pass-1 table face rides every sweep row, the mirror guard made direct) |

Line counts: `wc -l` — the five r100 twins at r106 (v0.69.0); the
segment-three twins at their delivery rounds (infer.ktf r127 · v0.88.0,
typecheck.ktf r128 · v0.89.0).

## Bootstrap status (one sentence)

The compile segment is fully self-hosted — gate B holds both calibers
(the twin's bytecode byte-identical to the oracle pipeline's, and the
three-phase fixpoint `C_t(C_t(S')) == C_t(S')`: the twin compiles
itself, the product executes, the rerun reproduces the same bytes); the
lexer segment additionally carries its own-source fixpoint (the twin
lexing its own source, the VM-bracket face); reader/macro/expander ride
composed-chain-level parity (the junction feeds — the twins' products
feed the next layer, never an oracle intermediate); the VM/runtime stay
the permanent Rust base (the constitutional exclusion).

## Hosting conventions

- **lexer.ktf** (§9.46.4 RS-1, the LX-1 payload generalization): the
  host encodes the source text as one integer per byte —
  `define(source_bytes, quote((104, 101, ...)))` — and every lexical
  decision rides plain integer arithmetic; the twin binds `tokens` /
  `lex_error` for the structure layer. f64 values and string payloads
  stay host-side (K20: no variable-precision arithmetic, no string
  construction in the subset); empty payloads ride `nil`.
- **reader.ktf** (§9.46.4 RS-1): the host injects the token table —
  `define(tokens, quote((record, ...)))`; positions ride as decimal
  byte-offset strings, carried opaquely (no int->string in the subset).
- **expander.ktf** (§9.47.4 EX-1, the MX-2 assembly): the host injects
  a flat pre-order form stream — `define(forms, quote((record, ...)))`;
  `"list"` records carry their child count, so depth stays inside the
  reader's 256 cap. The assembled program = `macro.ktf` prepended to
  `expander.ktf` (the expander's define-syntax arm and macro dispatch
  call into the library).
- **compiler.ktf** (§9.83 CP-1): the host injects the EXPANDED item
  tree as a flat pre-order record stream —
  `define(items, quote((record, ...)))`.
- **infer.ktf / typecheck.ktf** (w-hm-twin-window.md TWIN-2, the
  segment-three payload): the same `items` channel and the same CP-1
  record grammar — the inference twin binds the tdef table + the
  diagnostics, the checker twin binds the pass-1 table face + the
  diagnostics (code/severity/span/template-payload/subjects); the
  extern records ride the stream with their entries inline (the r124
  junction-3 face). The walk state rides the assigned globals (the
  W-machine discipline — the monomorphic-recursion constraint makes a
  type-changing argument an occurs check).
- **Junction feeds** (§9.87 JX-1, the composed chain): the junction
  products feed forward — J1 the `.ktf` reader's forms, J2 the `.ktf`
  expander's rebuilt items, J3 the compile — never an oracle
  intermediate (the honest fixpoint direction).
- The source tail binds the verdict — `define(result, ("ok" ...))` or
  `("err" kind payload ...)` — which the host rebuilds and renders
  through the same `Display` (parity transparent by construction).

## Consumers (who reads the five)

| Consumer | Face |
|---|---|
| `crates/kerf-driver/src/target_corpus.rs` | the seven `*_TARGET_SOURCE` constants (`include_str!` ×7, compile-time embed) + `assembled_expander_target_source` (the MX-2 assembly) + `read_target_source_for_bootstrap` (the production bridge) + `ktf_compile_rich(_vm)` + `gate_b_bytecode` |
| `crates/kerf-driver/src/steady_typecheck_chain.rs` | `SteadyTypecheckChain` (the inference twin's steady chain) + `SteadyCheckChain` (the checker twin's) — compile once through the production bridge, per-check injection through the `items` slot |
| `crates/kerf-driver/src/{infer_parity,typecheck_parity}.rs` | the segment-three parity faces: the oracle verdict renderers + the twin decoders + the CP-1 payload builder (`items_stream_literal`, one builder every segment-three consumer) |
| `crates/kerf-driver/src/composed_target_chain.rs` | `composed_target_chain_parity(_vm/_probes)` — the §9.87 formula through the production bridge: the three junction feeds, the tamper three-arm, the VM bracket |
| `crates/kerf-driver/src/fixpoint.rs` | `fixpoint_selfhost_compiler_target` / `fixpoint_products_target` — the target-skin fixpoint |
| `crates/kerf-driver/src/lexer_parity.rs` | `reader_parity_full_target_with(_feed_vm)` — the lexer own-source fixpoint (junction 1) |
| `tests/v1/stage1/plan/composed_target_chain_tests.rs` (13) | positive anchors end to end, the selfhost fixpoint full chain, the tamper probes junction by junction, the VM bracket, the i64::MIN data boundary |
| `tests/v1/stage1/plan/target_fixpoint_tests.rs` (8) | the three-phase fixpoint + the gate-B bytecode-identity corpus sweep |
| `tests/v1/stage1/plan/fixpoint_tests.rs` (9) | the 2.5 fixpoint-window family on the target face (the rebuild face, the fixpoint driver, the negative faces) |
| `tests/v1/stage1/plan/determinism_guard_tests.rs` (7) | the assembled reader/expander sources through two independent traversals (the gate-B prerequisite) |
| `tests/v1/stage1/plan/{infer_twin_sweep_tests,typecheck_twin_sweep_tests}.rs` (5 + 6) | the segment-three sweeps: every fed corpus row's twin verdict vs the oracle, bit-for-bit (the inference axis + the check axis with the pass-1 table face) |
| `tests/v1/stage1/plan/selfhost_format_guard_tests.rs` (3) | the format invariants (below, seven files) |
| `examples/audit/stage0_gate_audit_r1.rs` | the live target-face audit sections (the bridge fail-closed family, the target fixpoint, gate-B transitivity); the `.krf`-era cases ride the r104 historical blocks (104 retired) |

(The corpus sweep — `target_corpus_sweep_tests.rs` — rides the
transcoder + `validate_target` over the acceptance corpus, both skins;
it does not consume these five files directly.)

## Sensitive anchors (read before touching)

Three tamper anchors are pinned as contiguous substrings by
`composed_target_chain_tests.rs` (a tamper probe that misses its anchor
fails its own `assert_ne!`):

- `lexer.ktf`: `} else if b == 11 {` (the whitespace-table byte arm —
  the tamper-lexer probe, junction 1);
- the assembled expander (`macro.ktf` + `expander.ktf`):
  `ex_depth >= 512` (the depth guard — tamper-expander, junction 2);
- `compiler.ktf`:
  `cp_emit("load-global", cp_intern_global(name), 0, cp_span_of(t))`
  (the CP7 globals tamper, junction 3), plus the hosting tail
  `define(result, cp_run(items))` (stripped by the structural probes).

Comment and whitespace changes are invisible to parity (not tokens);
**any token-level change requires a full parity rerun** of the
consumer family above.

## Format conventions (machine-checked)

`tests/v1/stage1/plan/selfhost_format_guard_tests.rs` pins three
invariants over all seven files:

1. **line width ≤ 100 columns** (SOP §10.5; the same bound rustfmt
   enforces on the Rust face);
2. **the non-ASCII whitelist = {`—`, `§`}** (the em-dash is the
   repo-wide parenthetical convention; `§` anchors ride verbatim);
3. **no ASCII parenthetical dashes** (` - ` / `  -  `) — prose dashes
   are em-dashes (the `.ktf` comment marker is `//`).

(The `krf_reformat.py` local pre-flight tool was retired at r106 — its
targets, the `.krf` originals, had already left the tree at r104; the
Rust guard above is the one checked face.)

## Honest boundaries (registered)

- **MX-1**: the subset has no string construction — mangled names ride
  as structured records `("mangled" s e base counter gen)`, decoded
  host-side (decision-face parity; rendering stays host-side); the
  Rust `fresh_name` trigger-avoidance loop is not mirrored
  (plan-1.7.md §5).
- **float payloads**: inf/NaN have no literal shape — every float
  rides as Debug text (host-side parse is exact).
- **macro-layer routing**: sources carrying define-syntax route to the
  macro layer (§9.47.4 EX-3); the expander's `"macro-layer"` error arm
  is unreachable but fail-closed.
- **the VM stays Rust** (the constitutional exclusion): this directory
  is the bootstrap FRONT END; a VM rewrite is not on any roadmap
  (SOP §2.2 principles 41/53).

## E5 history note

The `.krf` S-expr originals of these five files were **removed at
r104** (E5 batch 3 — the switch-window step-5 teardown, one shot: the
originals deleted, the driver constants switched to the `.ktf` twins,
the affected audit cases historized, the tests reorganized onto the
target faces). The S-expr seed-chain READER survives as verification
infrastructure (the BS-A constitution): `kerf-reader`'s `read_program`
remains the seed-chain oracle — the S-expr corpus face and the parity
harnesses still validate through it — but it is verification surface,
not the production chain. The production chain reads `.ktf` only.

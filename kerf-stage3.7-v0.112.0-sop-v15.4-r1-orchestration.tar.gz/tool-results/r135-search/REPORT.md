# r135 Knowledge Search Archive — W-JIT-METHOD-T1 Window + T-a Chain Planning

Task ID: 135-a-search · Agent: general-purpose (knowledge search subagent)
Scope: 7 web searches archived as JSON under `/home/z/kerf/tool-results/r135-search/`, plus 2 synonym-query retries (q2b, q4b) — see "Execution Disclosure".
Consumers: `w-jit-method-t1-window.md` v1.0 + T-a production-bit switch chain planning.

Context recap: kerf is a Rust-hosted S-expr compiler (Cargo workspace, 12 crates), Stage 3.7. Front-end pipeline (read/expand/typecheck/compile) has .ktf twins at bit-level parity, but production bits remain Rust (T-a switch pending). Next window W-JIT-METHOD-T1 = method JIT with V8 Sparkplug 1:1 non-optimizing form ruled as reference form (K153); it is the performance precondition of the T-a chain. VM holds a zero-external-dependency discipline (cranelift/LLVM both rejected). Current eval engine carries EVAL_DEPTH_LIMIT 2048 fixed depth cap (prior incident: fixpoint self-source exceeded the depth budget); user requires an "arbitrary recursion depth" general solution in planning.

---

## Query Results (top relevant hits per query)

### q1 — V8 Sparkplug baseline JIT design (`q1-sparkplug-baseline-jit.json`)

1. **vitalyivanov.com — "Interpreted vs compiled: how one line reaches the CPU"**
   https://vitalyivanov.com — Sparkplug compiles bytecode straight to machine code with **no intermediate representation at all — just a single linear walk over the bytecode**; the tier exists to remove interpreter dispatch overhead, not to optimize.
2. **ursb.me — QuickJS source deep-dive (一行JS 的一生)**
   https://ursb.me — Modern JS engines layer JITs: V8 = Ignition→Sparkplug→Maglev→TurboFan (4 tiers); JSC = LLInt→Baseline→DFG→FTL. Each tier raises peak speed but also raises code volume — tiering is a cost/benefit ladder, and the baseline tier is the cheapest rung.
3. **completefrontend.com — The JavaScript Field Guide**
   https://completefrontend.com — Sparkplug's defining property = **compiling bytecode directly** (bytecode-to-machine-code 1:1 mapping, no IR, no type feedback); SpiderMonkey and JavaScriptCore each have an analogous Baseline tier — the "baseline JIT" is an industry-standard tier shape, not a V8 idiosyncrasy.
4. **book.kedbyte.com — How a Compiler Actually Works**
   https://book.kedbyte.com — V8 pipeline as of 2026: Ignition (bytecode interpreter) then Sparkplug (baseline compiler, added 2021) positioned between interpreter and optimizing tiers; baseline fills the latency gap before optimizing JIT warmup completes.
5. helpbox.in (weak) — generic restatement: Sparkplug = non-optimizing baseline compiler turning bytecode into machine code quickly.

**Anchor strength: STRONG.** Multiple independent sources converge on the same design facts (no IR, bytecode-linear-walk, non-optimizing, dispatch-overhead elimination, industry-standard tier shape).

### q2 (+ retry q2b) — interpreter acceleration without codegen dependency (`q2-rust-zero-dep-jit.json`, `q2b-rust-zero-dep-jit-retry.json`)

Original query returned 4 results, all off-target (wasm threading proposal, tokio-on-wasm, Lunatic runtime, wasm marketing) — **treated as a de facto miss; synonym retry executed** (query: "interpreter optimization superinstructions direct threading dispatch cost without JIT engine design"). Retry results:

1. **EPFL — Advanced Compiler Construction (Michel Schinz), lecture notes**
   https://www.epfl.ch — Canonical formulation: "instruction dispatch is expensive in a VM; one way to reduce its cost is simply to **dispatch less** — group several instructions" (= superinstructions). The whole zero-codegen acceleration family reduces to dispatch-count and dispatch-cost reduction.
2. **cuddly-octo-palm-tree.com — "Cheap interpreter, part 6: faster stack machines"**
   https://cuddly-octo-palm-tree.com — Systematic comparison of interpreter implementation approaches (switch vs computed-goto/threading vs fused ops), explicitly seeking the best **complexity-vs-overhead balance** — directly applicable to a Rust zero-dependency VM deciding how far past plain `match` dispatch to go.
3. **Hacker News — "The Structure and Performance of Efficient Interpreters" [pdf] discussion**
   https://news.ycombinator.com — Around the Ertl/Gregg-style performance work: threaded-code interpreters restructure dispatch so "there's no dispatch" in the naive sense; later Lua and Lisp VM results reconfirm — dispatch structure (not raw instruction count) dominates interpreter performance.
4. **prg.comp.isct.ac.jp — "Two-level Just-in-Time Compilation with One Interpreter" (Izawa et al.)**
   https://prg.comp.isct.ac.jp — Realizes two-level JIT tiering **on top of a single interpreter** without writing several interpreters/compilers from scratch — evidence that tier boundaries can be added incrementally above one core loop.

**Anchor strength: STRONG after retry (original query = weak/miss, disclosed).** Note: wasm3 specifically did not surface in either pass; the superinstruction/context-threading family is however covered by EPFL notes + efficient-interpreters literature.

### q3 — self-hosting production switch order (`q3-selfhost-production-switch.json`)

1. **rustc-dev-guide.rust-lang.org — "What Bootstrapping does"**
   https://rustc-dev-guide.rust-lang.org — The authority on stage discipline: Stage 1 = compiler built by an earlier compiler from current sources; Stage 2 = "the truly current compiler"; **Stage 3 = the same-result test** (stage2 compiling the sources must reproduce stage2 — the fixpoint check). Artifacts must be uplifted in a fixed order; the doc encodes exactly when each artifact becomes trustworthy.
2. **languagelineage.org — "What is Compiler Bootstrapping?"**
   https://www.languagelineage.org — Typical self-hosting build = three stages; Stage 0 (seed) → recompile same source with stage-N compiler → fixpoint; frames bootstrapping as a verification protocol, not merely a build mechanism.
3. **tmewett.com — "Bootstrapping and self-hosting"**
   https://tmewett.com — GCC-style three-stage chain: minimal C compiler built by host → GCC built by that → GCC rebuilt by itself; the practical pattern of **seed-compiler → full-compiler → self-rebuild** with the third stage existing to verify the second.
4. **github.com/rust-lang/compiler-team #619 — "Redesign bootstrap stages"**
   https://github.com — 2023 redesign of how rustc bootstrapping stages are structured (build/std/rustc artifact matrix) — evidence that even mature self-hosted compilers keep refining stage ordering; stage semantics are load-bearing and worth formalizing early.
5. **news.ycombinator.com — "I never understood why self-hosting is considered good"**
   https://news.ycombinator.com — Counterpoint thread: the build involves a **fixed set of steps (stage1, stage2, stage3) and the chain never grows**; no pre-existing binaries required after the seed — a good statement of the invariant that makes self-hosting auditable.

**Anchor strength: STRONG.** (Gap disclosed: no hit specifically on Go 1.5's C→Go transition plan in this pass; Go 1.5's "last C deleted, compiler self-hosted, bootstrap via C-built Go 1.4" is corroborated only indirectly by the general stage literature above.)

### q4 (+ retry q4b) — arbitrary recursion depth (`q4-arbitrary-recursion-depth.json`, `q4b-arbitrary-recursion-retry.json`)

Original query returned flashcards/edu-platform noise (Quizlet, Ed, cram) and one off-topic arxiv paper — **de facto miss; synonym retry executed** (query: "trampoline tail call optimization avoid stack overflow deep recursion interpreter heap allocated activation records"). Retry results:

1. **stackoverflow.com — "What are some good ways of implementing tail call elimination?"**
   https://stackoverflow.com/questions/6003037 — Classic implementer thread (Scheme interpreter in C/C++): proper tail calls via **trampoline, explicit loop-and-rewrite of the interpreter core, and CPS/Cheney-on-the-M.T.A** style heap-allocated continuation frames — the three canonical implementation strategies in one place.
2. **dev.to (Sean Chen) — "The Story of Tail Call Optimizations in Rust"**
   https://dev.to — Rust-specific: the language lacks guaranteed TCO, so the general technique is a **trampoline** — return a "bounced" tail-recursive value and let an outer loop drive iteration; directly maps to a Rust-hosted VM.
3. **blog.scottlogic.com — "Recursion, Thunks and Trampolines with Java and Scala"**
   https://blog.scottlogic.com — Thunk/trampoline pattern **transforms deep recursion into safe heap-based iteration** — frames grow on the heap, so depth is bounded by memory, not stack size.
4. **rabinarayanpatra.com — "Tail-Call Optimization Explained"**
   https://www.rabinarayanpatra.com — The trampoline works because each step returns a lambda **stored on the heap** instead of making a recursive call **stored on the stack** — crisp statement of the heap-frames vs stack-frames trade.
5. **johnazariah.github.io — "Bouncing around with Recursion"**
   https://johnazariah.github.io — Trampolines give a **constant-height stack while evaluating arbitrarily deep tail-called chains** — the guarantee that a fixed EVAL_DEPTH_LIMIT can never provide.
6. inventwithpython.com — Chapter 8, TCO as an interpreter/compiler feature to avoid stack overflow (pedagogical, weak-moderate).

**Anchor strength: STRONG after retry (original query = miss, disclosed).**

### q5 — parser depth / iterative parsing (`q5-parser-depth-iterative.json`)

1. **users.rust-lang.org — "On guarding against stack overflows while using recursion"**
   https://users.rust-lang.org — Real Rust practice: during parsing, **check the nesting depth of the resulting AST and return an error beyond a threshold** — i.e., the industry default for recursive-descent readers/parsers is a guarded depth cap, not unbounded depth (kerf's current reader posture is the industry norm, but this thread also covers why the guard must live at the right layer).
2. **langdev.stackexchange.com — recursive-descent tag**
   https://langdev.stackexchange.com — Practitioner Q&A on recursive-descent as top-down parsing via mutual recursion between nonterminal functions — the structural reason deep nesting maps to host-stack depth.
3. **github.com — "Excessive Recursion in modelFromJSON Causes Stack Overflow (Parser Depth Handling Bug)"**
   https://github.com — Field report of a real parser-depth bug: recursion over attacker/user-supplied nesting overflows the host stack — evidence that unbounded input nesting is a robustness (not just performance) issue at the reader/parser layer.
4. studyplan.dev (weak) — generic stack-overflow-in-recursion explainer.

**Anchor strength: MODERATE.** No hit that directly demonstrates a fully iterative explicit-stack parser in this pass; the dominant industry pattern surfaced is "guarded depth cap at parse time". The explicit-stack conversion technique for recursive descent is well known but not strongly anchored here — flag as a gap; the general explicit-stack machinery is however covered by q4b's results (same technique, different layer).

### q6 — package manager self-hosting (`q6-package-manager-selfhost.json`)

1. **langdev.stackexchange.com — "Why do many language implementations not provide an official package manager?"**
   https://langdev.stackexchange.com — In the bootstrapping context, **quite a few languages are fully self-hosted, and becoming self-hosting is often treated as a significant milestone** — but the package manager is frequently *not* part of the self-hosted core (kept in the host language for ecosystem/ergonomics reasons). Directly relevant to kerf's W-PKG-SELFHOST window ordering.
2. **ochagavia.nl — "The birth of a package manager"**
   https://ochagavia.nl — Design walkthrough of building a package manager from scratch (dependency resolution from the user's perspective: name + constraints → plan) — useful shape reference for a kerf-native package tool.
3. **discuss.ocaml.org — opam packaging questions**
   https://discuss.ocaml.org — opam is **fully OCaml-agnostic** as a tool (can distribute non-OCaml tools, depends on conf- style bridges) — an existence proof that a language's package manager need not be written in (nor restricted to) that language.
4. users.rust-lang.org — "is cargo really a package manager?" (weak-moderate) — definitional discussion; cargo ships as part of the Rust toolchain rather than as a self-hosted artifact in the strict compiler sense.
5. nesbitt.io (weak) — package-management landscape directory only.

**Anchor strength: MODERATE.** No direct hit on "cargo/opam rewritten in own language"; the strongest signal is the langdev discussion that package-manager self-hosting is *decoupled* from compiler self-hosting in industry practice.

### q7 — bootstrap fixpoint / three-stage chain verification (`q7-bootstrap-fixpoint-purity.json`)

1. **rustc-dev-guide.rust-lang.org — "What Bootstrapping does"**
   https://rustc-dev-guide.rust-lang.org/building/bootstrapping/what-bootstrapping-does.html — Stage 0 uses the downloaded (seed) compiler to create stage0 artifacts later **uplifted to be the stage1 compiler** — the concrete artifact-flow that a production-bit switch must reproduce for kerf (Rust-built kerf → .ktf-built kerf → self-rebuilt kerf).
2. **kaikai-lang.org — Appendix A: Three-stage bootstrap**
   https://kaikai-lang.org — A clean published walk-through: A.2 Stage 0 = compiler in C; A.3 Stage 1 = compiler in kaikai-minimal; A.4 Stage 2 = full kaikai, self-hosted; **A.5 = the fixed point** — a small-language existence proof of exactly the chain kerf's T-a is planning, including the fixpoint section as a first-class document.
3. **github.com/oriansj/stage0**
   https://github.com/oriansj/stage0 — Minimal-dependency bootstrap chain built from **hand-written hex programs** upward to a C compiler — the maximal-purity end of the spectrum (auditable seed, no binary trust), showing how far chain verification can be pushed.
4. **reddit.com/r/ProgrammingLanguages — "I wrote my first self-hosted compiler"**
   https://www.reddit.com — Practitioner formulation: compile sources with bootstrap compiler → stage0; compile sources with stage0 → stage1; keep recompiling until **output stops changing (fixpoint)** — the termination criterion stated plainly.
5. **lobste.rs — "The Full-Source Bootstrap: Building from source all the way"**
   https://lobste.rs — All tools needed to build the system live in the source tree and are compiled once with the host compiler during the bootstrap phase — the "live-in-tree" discipline that makes the chain reproducible from source alone.
6. en.wikipedia.org — Bootstrapping (compilers) (weak-moderate) — definitional background.

**Anchor strength: STRONG.** Multiple independent sources (rustc-dev-guide, kaikai appendix, stage0, practitioner threads) converge on three-stage + fixpoint-check as the standard verification shape.

---

## Insights for the Three kerf Planning Questions

### ① Method JIT zero-dependency form selection (W-JIT-METHOD-T1)

1. **Sparkplug's essential property survives the loss of machine codegen.** All q1 sources agree Sparkplug = *non-optimizing, no-IR, single linear walk over bytecode, 1:1 bytecode-to-code mapping*. The value it delivers is (a) removal of dispatch overhead per bytecode and (b) reduced tier-up latency. Neither (a) nor (b) *requires* native code generation — a "Sparkplug-shaped" tier in kerf can be defined as **an execution form that removes per-instruction dispatch**, not as an x86 emitter.
2. **Zero-codegen acceleration is a well-mapped family: dispatch less, dispatch cheaper.** EPFL notes (q2b #1) reduce the whole field to superinstruction fusion ("dispatch less"); the efficient-interpreters literature (q2b #3) shows threaded dispatch restructures the loop so per-instruction dispatch cost collapses; the "Cheap interpreter" series (q2b #2) provides the complexity-vs-payoff ladder (switch → computed goto/threading → fusion). For kerf's zero-dependency VM this is the honest menu: **closure-chain / threaded-code / superinstruction fusion are the Rust-native equivalents of the Sparkplug tier**, with no external crate.
3. **Rust constraint shapes the choice.** Rust offers no guaranteed TCO and computed-goto is unstable/unavailable in stable Rust — so the "Sparkplug form" in kerf most plausibly lands as (i) pre-fused superinstructions in the existing bytecode stream (r134's W-VM-SUPERINSTR work is literally tier-0.5 in this framing), and/or (ii) a **closure-chain / trampoline-driven method-execution path** where each method compiles to a chain of Rust closures executing without re-entering the central dispatch loop. q2b #4 (two-level JIT over one interpreter) supports doing this as an incremental tier above the existing loop rather than a parallel engine.
4. **Tiering order matches kerf's plan.** q1's four-tier ladder (Ignition→Sparkplug→Maglev→TurboFan) confirms the industry pattern of shipping the interpreter + baseline first and optimizing tiers later; a 1:1 non-optimizing method JIT as tier-1 (K153 ruling) is the standard cheap rung, and the "1:1" property (no IR, no type feedback) is exactly what keeps it within a zero-dependency Rust implementation.
5. **Watch item:** none of the q1/q2 sources claim a baseline JIT is *necessary* before an interpreter is production-quality — Sparkplug exists to close a latency window under an *optimizing* tier. If kerf's roadmap has no optimizing tier, the honest framing of W-JIT-METHOD-T1 is "dispatch-elimination tier" and its win should be measured against the r134 superinstruction baseline (the 20% third-lever data in the ledger).

### ② Self-hosted production-bit switch order (T-a)

1. **Industry order = seed → full → self-rebuild-fixpoint, with the fixpoint as a verification gate, not a build step** (q3 #1 rustc Stage 2/3; q7 #2 kaikai A.5; q7 #4). For T-a: (step 1) Rust-hosted kerf compiles the .ktf sources (parity twins already proven at bit level — this is the "seed" role), (step 2) the resulting .ktf-built kerf becomes the candidate production compiler, (step 3) **the candidate recompiles its own sources and the output must be bit-identical (fixpoint check)** before any production-bit switch. kerf's existing .ktf parity discipline is precisely the machinery this check needs.
2. **The chain must be fixed-length and artifact-explicit.** HN (q3 #5): "the build involves a fixed set of steps and the chain never grows"; rustc-dev-guide (q3 #1, q7 #1) models artifacts with explicit uplift rules (stage0 artifacts uplifted to be the stage1 compiler). Planning implication: T-a should be specified as a **fixed three-step pipeline with named artifacts** (A: Rust-built; B: A-built; C: B-built; require B≡C), never as an open-ended "recompile until stable" loop — this also protects against the fixpoint-source depth-budget class of incident.
3. **Switch timing in industry: after parity, before package-manager self-hosting.** q6 #1 shows compiler self-hosting is the celebrated milestone, while the package manager is routinely *not* part of the self-hosted core (opam is even language-agnostic, q6 #3). This supports the current roadmap ordering — T-a production-bit switch (front-end segments already ELEVATED at parity) ahead of W-PKG-SELFHOST — and warns against coupling the two switches.
4. **Mature projects keep refining stage semantics — formalize early.** rustc's 2023 bootstrap-stage redesign (q3 #4) shows stage definitions are load-bearing and get reworked at great cost; T-a planning should pin down stage/artifact names and verification gates in the window document (w-jit-method-t1-window.md + the T-a chain doc) before any switch, exactly as the v15.3 next-entry check already requires.
5. **Verification beyond fixpoint: reproducibility from source alone.** The Full-Source Bootstrap pattern (q7 #5) and stage0's auditable seed (q7 #3) suggest T-a's acceptance test should include "rebuild the chain from a clean tree + the seed artifact only, and confirm the same bits" — a natural extension of kerf's §19 packaging discipline to the bootstrap chain. (Gap: Go 1.5's actual C→Go cutover did not surface directly in these passes; the rustc three-stage model is the strongest proxy anchor.)

### ③ Arbitrary recursion depth general solution (reader/parser/eval/compiler)

1. **The industry default at the reader/parser layer is a guarded depth cap — kerf's current posture is normal, not deficient.** users.rust-lang.org (q5 #1) documents the standard practice of checking AST nesting depth at parse time and erroring beyond a threshold; the modelFromJSON bug report (q5 #3) shows the failure mode being *unguarded* nesting, not the existence of a cap. So the "arbitrary depth" requirement should be scoped: **unbounded depth is a property the *eval* engine must have; the reader/parser may legitimately keep a (much higher, configurable) guard** — or adopt the explicit-stack conversion below to remove host-stack dependence entirely.
2. **Three canonical mechanisms, all heap-based: trampoline, explicit stack, heap-allocated frames.** The classic SO thread (q4b #1) lays out all three for interpreter cores (trampoline; loop-and-rewrite core; CPS/Cheney-on-the-M.T.A heap frames). Constant-height-stack guarantee via trampoline (q4b #5), heap-vs-stack frame trade (q4b #4), and the Java/Scala thunk-trampoline transform of deep recursion into heap-based iteration (q4b #3) all confirm: **the unifying move is moving activation records from the host stack to the heap**, after which depth is bounded by memory policy (GC), not a fixed integer.
3. **Rust reality: no guaranteed TCO ⇒ trampoline/explicit loop is the portable answer.** dev.to Rust TCO story (q4b #2): since rustc does not guarantee tail-call elimination, a Rust-hosted VM cannot rely on host recursion for deep chains — the eval loop must own an **explicit frame stack (Vec of heap frames) or a trampoline loop**, which conveniently is also the structure a method-JIT closure chain (question ①) naturally provides. The two requirements (arbitrary depth + method JIT) share one architectural change — a kerf-owned activation stack — and should be planned as one mechanism, not two.
4. **Layer-by-layer division of labor for kerf:** (a) **reader**: keep a configurable nesting guard or convert to explicit-stack iterative read (same technique as parser); (b) **parser/expander**: explicit-stack conversion of recursive descent (the technique is standard, though this pass's direct anchors are thin — flagged below; q4b's explicit-stack results carry the mechanism); (c) **eval/compiler**: heap-allocated frames on a VM-owned stack + tail-call elimination at the bytecode level (self-tail jumps, cross-tail trampoline), replacing EVAL_DEPTH_LIMIT 2048 with a memory-budget policy; (d) the fixpoint self-build (T-a) then inherits unbounded depth automatically, closing the class of incident where kerf's own source exceeds the depth cap.
5. **Verification shape:** the acceptance test for the general solution should include (i) deep non-tail recursion bounded only by memory, (ii) deep tail recursion at constant stack height, and (iii) the fixpoint self-source build completing under the new regime — mirroring how q7's fixpoint checks double as stress tests of the whole pipeline.

---

## Execution Disclosure

- All 7 primary queries executed successfully on first CLI invocation; **no 429s encountered**.
- **q2 retry**: original query ("interpreter acceleration techniques Rust without codegen dependency context threading superinstructions wasm3") returned 4 results, all off-target (wasm threading proposal / tokio-wasm / Lunatic / wasm marketing). Treated as de facto miss; synonym retry ("interpreter optimization superinstructions direct threading dispatch cost without JIT engine design") returned strong results (EPFL notes, Cheap-interpreter series, efficient-interpreters literature, two-level-JIT paper). Archived as `q2b-rust-zero-dep-jit-retry.json`; original retained as `q2-rust-zero-dep-jit.json`. wasm3 specifically did not surface in either pass (disclosed).
- **q4 retry**: original query ("interpreter arbitrary recursion depth heap allocated frames explicit stack trampoline tail call elimination") returned flashcards/edu noise and one off-topic arxiv paper. Treated as de facto miss; synonym retry ("trampoline tail call optimization avoid stack overflow deep recursion interpreter heap allocated activation records") returned strong results. Archived as `q4b-arbitrary-recursion-retry.json`; original retained.
- **Anchor strength summary**: q1 STRONG · q2 STRONG-after-retry · q3 STRONG (Go 1.5-specific source absent — gap) · q4 STRONG-after-retry · q5 MODERATE (no direct iterative-parser exemplar; mechanism covered via q4b) · q6 MODERATE (no direct "PM rewritten in own language" case; strongest signal = PM self-hosting decoupled from compiler self-hosting) · q7 STRONG.

## Archive Inventory

| File | Query | Status |
|---|---|---|
| q1-sparkplug-baseline-jit.json | V8 Sparkplug baseline JIT design bytecode without optimization tiering | first pass, usable |
| q2-rust-zero-dep-jit.json | interpreter acceleration Rust without codegen (context threading / superinstructions / wasm3) | first pass, off-target |
| q2b-rust-zero-dep-jit-retry.json | interpreter optimization superinstructions direct threading dispatch cost without JIT | retry, strong |
| q3-selfhost-production-switch.json | compiler self-hosting production switch Go 1.5 rustc bootstrap stages | first pass, strong |
| q4-arbitrary-recursion-depth.json | interpreter arbitrary recursion depth heap frames explicit stack trampoline TCO | first pass, off-target |
| q4b-arbitrary-recursion-retry.json | trampoline TCO avoid stack overflow deep recursion heap allocated activation records | retry, strong |
| q5-parser-depth-iterative.json | recursive descent parser stack overflow explicit stack iterative parsing | first pass, moderate |
| q6-package-manager-selfhost.json | package manager self-hosting bootstrap cargo opam implemented in own language | first pass, moderate |
| q7-bootstrap-fixpoint-purity.json | self-hosting compiler fixpoint stage0 stage1 three stage bootstrap chain verification | first pass, strong |

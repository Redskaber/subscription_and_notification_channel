# kerf v0.112.0 — W-SEXP-RETIRE 刀 2：S-expr 读链退役（r151）

第一百五十一轮（r151 · Task 151）· SOP v15.3 §21.12-28 自举完备优先 · W-SEXP-RETIRE 刀 2（S-expr 读链退役——单皮肤终态）· L3（读链本体 + 孪生 + harness + 转码器 + 全消费面 ~250 文件；三续传会话接力：151-a 裁定层 + 151-b 拆除主体〔中断会话落树〕+ 151-c 消费面〔本会话〕）

## 交付清单

1. **裁定层 BR-1..17**（151-a）：消费面全量侦察（281 处/51 文件）+ 拆除/保留/切换三面账目 + 十六裁定定案（audit 四类处置 / reader_seed 整体退役 / StxToken helpers 退役 / error.rs 四变体退役 / ReaderFace 枚举退役 / CLI --skin 退役 / diagnostic face 参数收口 / 转码器退役 + 迁移臂随刀退役 / bench 目标面拼写 / cbackend helper 转面 / 孪生退役 8→7 / BR-15 清理项 / fixpoint 零直接消费确认）。
2. **拆除主体 ~4,700 行**（151-b，中断会话落树）：kerf-reader S-expr 本体三件（lexer.rs 918 + parser.rs 401 + token.rs 116）+ lib.rs 单皮肤重写（NESTING_LIMIT 搬家 crate 根）+ error.rs 四变体退役（共享 12 变体保留）+ lexer.ktf/reader.ktf 两孪生退役（selfhost 九件→七件）+ bootstrap 四件退役（bootstrap_chain/composed_target_chain/lexer_parity/skin_transcoder）+ reader_parity→vm_harness 改名（工具库化）+ target_corpus RS-1 内嵌 PrefixDatum 微解析器（fail-closed）+ pipeline/diagnostic/cli/repl/read_segment 五面收口 + common/mod.rs StxToken 退役。
3. **消费面 141 错误位点 ~46 文件**（151-c，本会话）：tests 树 40 文件（三子代理 32 + 特殊六件自做：rec_depth 逗号列表孪生/1-开括号 if 形、selfhost 守卫 8→7 全清单 + target-parser 68 行重排、determinism 组装主体换 lexer 孪生、target_corpus_sweep 三 seed 腿退役 + else 保留字行为钉、span_seed 形位钉、driver_seed CLI 退休守卫镜像）+ audit 59 处（AF 族整体 RETIRED + AB/AD 收编 + A-D 节转面 + include_str 两行删）+ bench 三件 + in-crate 45 失败清偿（172/172）。
4. **生产缺陷三件当轮清偿**：transcode_quoted_define 命名守卫（显示面比较——r151 重写误引合成 span 入等式，12 处链测试红）；REPL 源累积 callee 丢失（call 锚 `(` 形——set!/write-line 双皮肤拼写下 callee 恢复）；audit 仲裁四案（C02 EOF span 402 / J03 oracle 臂 + TD-028 登记 / AA10 布尔条件 / AP04 尾逗号参数表）。
5. **TD-028 登记（TWIN-HYG-1）**：自举孪生展开器 plain-ident 查询缺代纪律——引入非碰撞模板标识符按文本解析到使用位帧项（J03 面：oracle 拒 / 孪生受）；修复需 letloop/doloop/fnbind 三推送位统一 (name, generation) 帧表示迁移 = 独立刀窗；audit J03 钉 oracle 臂承载（孪生臂落刀回迁）。
6. **audit 减法共变**：480→460 live（20 案退役披露：AF 族 + A03/B03/B09/C03 四元组〔ruling C12〕+ AH9 + AJ07-AJ10 + AL03/AL08 + AY09）+ 124 retired-historical；总账 584 维持；守卫 TEST-3/3b 共变（documented 表 8 节降 + 头行 460/460 + 披露行 RETIRED 起始措辞）。
7. **版本金链锁步**：v0.111.0 → **v0.112.0**（Cargo.toml workspace + ds08 钉扎 snapshot_seed_tests）。

**测试面**：tests 树全绿（tests 71 错→0 + in-crate 172/172）+ **audit 460/460 live + 124 retired-historical 实跑 exit 0** + fixpoint 维持义务（CCF 6→4 共变随 BR-14b 落账）。**转化台账改账**：九件 14,932 → **七件 14,497 行**（lexer.ktf 671 + reader.ktf 141 两孪生 812 行退役；target-parser 68 行重排 +377——纯空白重排零语义变更）。下一刀：**W-SEXP-RETIRE 刀 3**（词面清零守卫化——.krf 词面残余扫描 + 台账层收口）。

# kerf v0.111.0 — W-SEXP-RETIRE 刀 1：全语料单皮肤迁移（r150）

第一百五十轮（r150 · Task 150）· SOP v15.3 §21.12-28 自举完备优先 · W-SEXP-RETIRE 窗开窗 + 刀 1（语料单皮肤迁移）· L3（全语料验收基础面切换——一切语料消费面 .krf→.ktf；中断轮续完：实施面由中断会话落树 ~85%，恢复会话续完 audit 面内联清偿 + 守卫共变 + 版本锁步 + 文档族 + GATE 1）

## 交付清单

1. **窗口开档**：`docs/develop/v3/w-sexp-retire-window.md` v1.0→v1.1——入口对账四前置全 ✓（read 段生产位 r145 / TD-027 r143 / R5 双臂判据 / C4 r149）+ 窗内裁定 SR-1..SR-5 + S-expr 表面四层清单（语料/读链/词面/台账）+ 三刀排期（刀 1 语料迁移 r150 ✓ / 刀 2 S-expr 读链退役 / 刀 3 词面清零守卫化）。
2. **语料单皮肤迁移（112 案处置）**：`tests/v1/stage1/corpus/` 全量 `.krf`→`.ktf` 落盘 **109 案**（机械族 89 经转码器 / 手作孪生族 11〔parse-error 6 + 负字面量 2 + ruling-D 2 + bnd-007 生成 1〕/ 阶段分歧族 9 期望改钉目标面 parse-error）+ **3 案退役**（neg-021 单元分歧 ruling-C12 / pos-031 关键字词汇 `else` 保留字 / neg-036 形状分歧臂 fn 包裹——目标皮肤面无主语案，分歧钉扎由 sweep 专项测试内联承载至刀 2）；.krf 原件 112 文件全数离树；分布地板维持 pos 45 / neg 54 / bnd 10 = 109 ≥ 地板 20/20/10/50。
3. **逐案双皮肤等价预检（SR-3 迁移期一次性义务）**：112 案种子契约复证 + 109 案目标契约预检（validate_target 全过）+ 值/警告机械族三闸（α-等价 + 单一语义字节码 + 单一值面 vs .krf 原件）——证明落档 `tool-results/r150-migration-report.txt`（迁移报告 = 窗口工件在案）。
4. **parse_directive 双注释前缀扩展**（SR-1）：`crates/kerf-driver/src/parity.rs`——`;; expect:`（种子皮肤）与 `// expect:`（目标皮肤）**单源期望语义**（皮肤只选字形、不选契约）。
5. **消费面切换 14 测试文件 + 3 子代理 + 漏网 2 件**：subset_corpus（109 corpus_case! + validate_target）/ target_corpus_sweep 全量重写（单皮肤 sweep + 溯源表 + 三分歧钉扎内联双面）/ hm_twin_face（管线脊柱 16/23/70）/ determinism_guard / test_infra_guard TEST-2（quoted_ktf_literals 扫描器）/ infer_twin_sweep + typecheck_twin_sweep（裸机裁定 75/16/18——判定轴加载器无关）/ steady_expander + lexical_capture + c_backend_e2e + stage_exit（C 回放 52/52 执行一致 + i64::MIN 文本边界内联 S-expr 常量）/ composed_target_chain + bootstrap_chain（账目 8/32/69/2/1 → 16/23/11/57/2 = 109——目标读组成链）/ superinstr_window；**诚实披露**：neg-057 J2 错误臂渲染形缺口（双编译器同消息拒绝、仅比较形漂移——刀 2 清理项登记）+ neg-062 extern 双胎缺口维持（r123 两法官契约）。
6. **迁移机械臂归档（SR-4）**：`examples/retire/sexp_corpus_migration.rs` ~380 行 + Cargo.toml `[[example]]`（R4 归档——一次性迁移驱动器；孪生表迁移期单源 = 机械臂，迁移后单源 = .ktf 语料文件本体）。
7. **audit BF 族 10 案（470→480 · 56→57 节）**：BF01-03 单皮肤目录事实 + 皮肤中性指令契约（双前缀裁定）/ BF04 分布地板 / BF05-07 三退役案分歧钉扎（C12 nil / else 保留 / 臂 fn 包裹）/ BF08 阶段分歧 parse-error 钉扎 / BF09-10 手作孪生边界与机械值锚。
8. **audit 语料消费面内联清偿（恢复会话续完——中断轮缺口）**：V03 全语料 sweep 切换目标面（`.ktf` 过滤 + `run_parity_source_with(ReaderFace::Target)` + 地板 79→109）+ AF1/AF2/AF3/AF7/AF8 + AK08 + AL01/AL08 九案种子源内联化（`.krf` 语料原件已离树——案前提 = 源文本非文件本体，determinism-guard 先例；整族刀 2 随 S-expr 读链退役收编）。
9. **守卫共变**：test_infra_guard TEST-3 四处共变（BF 节登记 + 总数 470→480 + 头行字面量 480/480 + 总账 574→584）。
10. **版本金链锁步**：v0.110.0 → **v0.111.0**（Cargo.toml workspace + ds08 钉扎 tests/v0/stage0/plan/snapshot_seed_tests.rs:1180）。

**测试面**：1701 → **1693:0:4**（runner 745〔−3 退役案 −5 sweep 重构 +消费面再钉〕+ lib 857 + api 91——十三分区全绿 + audit 480/480 实跑）。**转化台账**：零新转化面（语料迁移 = 验收载体换皮肤非段孪生转化——台账维持九件 14,932 行；刀 2 读链退役后改账）。下一刀：**W-SEXP-RETIRE 刀 2**（Rust S-expr lexer/parser 退役 oracle→移除 + lexer/reader.ktf 孪生退役 + parity harness 收编 + 转码器退役——fixpoint 经目标读链维持）。

1. **工作流实录语料（C4 面首个生产消费）**：`examples/workflow/selfcheck.ktf`（62 行自描述测试套件——8 标记全 PASS + 汇总行；语言面 = fn/if-else 值表达式/算术比较/`==` 数值等值/`eq` 字符串等值/pair 构造与 first/rest 读/递归/`read_line` 输入带/`write_line` 输出）+ `examples/workflow/bench.ktf`（47 行基准核——fib(30)=832040 约 1.3M 调用 / build+walk(10000) 分配形 / sum_to(20000)=200010000 深非尾递归堆帧）。开发工作流完整实录：编辑 .ktf → `kerf run`（四段孪生链生产位编译 + VM 执行）→ 测试/基准标记——**语言自我推进面首个生产级消费**。
2. **测试族七件**（`workflow_record_tests`——语料驱动非内联夹具，交付物即被测对象）：正向 2（selfcheck 全 8 标记 PASS + 汇总行闭合 / bench 全相位对值 + 确定性二跑逐行一致）；负向 3（错误期望表面化 FAIL 标记〔自测惯用语判别力——不能 FAIL 的套件不是测试套件〕/ 类型破坏程序双位同批先拒且永不抵 VM / 分歧输入带翻转 t8 至 FAIL 且余 7 标记维持）；回退带 1（全 oracle 位——四段全钉 Rust——输出与字节码双双位一致）；跨段消费 1（CLI `kerf run` 端到端 exit 0 + 全标记 stdout + stdin tape 管道契约）。
3. **audit BE 族 10 案**（460→470 · 55→56 节）：BE01-05 正向族（生产位全标记/基准相位/CLI e2e）+ BE06-10 负向与一致族（判别力臂/类型门/带翻转/双位一致/确定性）。
4. **守卫共变**：`test_infra_guard` TEST-3 BE 族入账 + 总数 460→470 + 头行字面量机检对齐（564→574 总账）。
5. **测量三跑落档**（K140 纪律——宿主墙钟包全进程：链构造 + 四段孪生编译 + VM 执行）：`tool-results/r149-workflow-run{1,2,3}.txt`——selfcheck 163/165/170ms / bench 953/954/954ms（v0.110.0 二进制实测）。
6. **C1-C4 验收对账 + Rust 面清点表 + 关窗宣告**：w-t-a-switch-window v1.5 **CLOSED**（出口条件 4/4 全 ✓）——C1 ✓（r139 组成链等价 + 四段 sweep）/ C2 ✓（四段生产位 + K159 不动点 B≡C + 工作流实录）/ C3 ✓（r137 终态）/ C4 ✓（本轮首个生产消费 + Rust 面清点表：宪制排除项〔VM 基座/构建引导/链外后端〕+ oracle 逐项）。
7. **W-SEXP-RETIRE 交棒就绪**：read 段生产位 ✓（r145）+ TD-027 ✓（r143）——拆除权双臂全满足；开窗序位 = T-a 关闭后首位（bootstrap-completion-plan §3 序 4）。

**测试面**：1694 → **1701:0:4**（runner +7 族——750 挂载 fns）。**转化台账**：零新转化面（workflow 语料 = .ktf 用户程序非孪生；台账维持九件 14,932 行）。下一入口：**W-SEXP-RETIRE 开窗**（S-expr 脚手架拆除——词法语法语义全目标语言单皮肤 + S-expr 面全树清零）。

# kerf v0.109.0 — T-a step ④ 第四段（末段）：compile 段生产位切换（r148）

第一百四十八轮（r148 · Task 148）· SOP v15.3 §21.12-28 自举完备优先 · T-a 切换窗 step ④ 第四段刀轮 · L3（生产管线核心域——compile 段 = 一切 .ktf 生产编译入口；沙箱迁移恢复轮：Pack A 自恢复 + cargo 1.99.0 重装 + 基线逐位复现）

## 交付清单

1. **生产编译默认翻转**：`ParsedProgram::compile_bytecode`（check/c_source/run VM 臂/run_parity 四消费面单一入口）twin 臂 = `SteadyCompilerChain::compile_production`（fresh VM + items 注入 + verdict 重建 + verify 地板）；Rust 编译器退役 oracle；S-expr 面结构性 Rust；注入面程序抵达 twin 臂 = 大声 wiring 缺陷。
2. **co_limit 预算镜像参数化**（ex_limit/tp_limit 先例——本段与 check 段不同形：Rust 侧有 KERF_COMPILE_DEPTH_LIMIT 覆写面）：compiler.ktf `cp_depth > co_limit` + 装配前缀 `define(co_limit, N);`（assembled_compiler_target_source{,_with_limit} + ccf_compiler_source + ktf_compile_rich 前缀 + fixpoint 双装配位 + 结构性源五处）；深度记录 `("err" "depth" D L s e)` 自描述双字段；Rust `DepthExceeded{depth, limit}` 载荷扩限值字段（Display 从载荷——覆写下诚实）；链按 co_limit 键控逐线程缓存。
3. **K163 第五实例清偿（编译半面）**：双重建面（make_span/rebuild_span）FileId(0) → 错误面 `CompileError::with_span`（全变体穷举 FIX-16）+ 产品面全部 proto dbg span 双 retarget 会话 file（真代际原样保留——运行时 span 渲染对档）。
4. **K163 第六实例当轮清偿（60k 平坦引号默认栈实证）**：items 流投递链四递归面迭代化（emit_litval_literal 编码器 + emit_litval 文本前缀 + dump_ktf_litval verdict 文本 + dump_oracle_lit oracle 文本——rebuild_lit/from_literal/pair_cells 先例族）+ `inject_items_stream` 共享 helper（迭代析构 × 全 12 注入位——r146 forms 流清偿的 items 流补全）。诚实边界登记：AST 字面量 Box-drop 胶水 ~150k 元素生产主线程实测上界（双臂共享 oracle 域先存——W-REC-DEPTH 堆化后续）。
5. **孪生三潜在缺陷当轮清偿（新输入域即新审计域）**：①cp_ewalk 错误臂 bool 契约（裸 set 返 nil → cfwalk `if term` 崩溃——烘焙 1024 期从未触达错误路径；修复 = 错误臂 do(...,false) + 顶层 post-error 短路 else false）②extern 重复名全局索引（孪生块内 i vs oracle 跨块表索引——CLI parity 测试暴露；cp_extern_n 计数器）③§6e 字符警察盲面经重建 verify 地板两法官显式化（rebuild_bytecode_unverified + 生产臂自跑 verify → 程序级 CompileError——与 oracle 同族同消息，fail-closed）。
6. **种子面四段全钉**：Session::with_segments 四参（parse_target_with_injected + read_target_source_for_bootstrap + rust_compile_ccf——A 轮编译直调结构性钉位）；cli 第四键 KERF_COMPILE_SEGMENT。
7. **测量先行三跑**（tool-results/r148-compile-segment-run{1,2,3}）：链构造一次（compiler.ktf 种子面）+ 每编译 twin vs Rust——curated ≈1.2× / match ≈1.3× / compiler-twin-CCF ≈1.7×；spine（读+展+编，查钉 Rust）1.3-1.5×——**四段最优切片带**。
8. **测试族十二件**（compile_segment_switch_tests：curated 位级 sweep + CCF 固定点 + 预算镜像同键 + 自描述限值 + 回退带三态 + 全脊柱消费〔run/check/emit-c 值与产物一致〕+ CLI 双面 + 种子钉源扫描 + wiring 缺陷 + S-expr 面 + K163 双钉 + 60k 栈平回归）+ audit BD 族 10 案（450→460 · 54→55 节）+ 守卫五处共变。

**测试面**：1679 → 1691:0:4（runner +12 族）。**转化台账**：compiler.ktf 1,804→1,850（+46——co_limit/bool 契约/全局索引）累计 14,932 行。下一入口：T-a step ⑤ 工作流宣告（C1/C2 验收 + K140 带登记 + 实录落档）。

# kerf v0.108.0 — T-a step ④ 第三段：check 段生产位切换（r147）

第一百四十七轮（r147 · Task 147）· SOP v15.3 §21.12-28 自举完备优先 · T-a 切换窗 step ④ 第三段刀轮 · L3（生产管线核心域——check 段 = 一切 .ktf 生产检查入口 + 双检查孪生链〔保守检查器 + HM 推断引擎〕+ 诊断结构化重建面——先例无的新面 + 全树默认翻转共变）。

## 本轮交付

- **check 段生产位切换（step ④ 四段之三——w-t-a-switch-window §3 r147 行 · TA-7 形制沿 TA-5/TA-6）**：`.ktf` 生产检查默认翻转至双检查孪生链（`CheckSegment::Twin`——check_segment.rs 新建 ~430 行：CheckSegment 枚举 + `KERF_CHECK_SEGMENT` 三态 fail-closed + 双链 thread-local 缓存〔无键控——检查段无预算覆写面〕+ `production_check` 单一入口）；`ParsedProgram::typecheck` 按位分臂——twin 臂先跑保守检查器（typecheck.ktf）再跑推断引擎（infer.ktf），oracle 臂沿袭 `check_module` + `infer_module` 收集序。Rust 检查器对退役 oracle 面（parity 比较臂 + 种子链自检 + 回退带）。
- **诊断结构化重建面（本段独有新面——read/expand 段重建拒绝，本段重建发现）**：twin verdict 的 `("cdiag" code sev s e payload subjects)` / `("tdiag" ...)` 记录解码为 `TypeDiagnostic`——code 经 `TypeCode::from_registry_str` 注册表查表（kerf-typecheck 单源新增逆映射 + 回环测试）；message 经 oracle 自有模板表渲染（R8 单源字典 pub(crate) 化共享——parity sweep 逐行交叉核验的同一表）；subjects 经 Symbol intern（r109 F2 皮肤面）；span = 会话 file 重靶 + ROOT generation（expand 段错误轴 make_span 先例——诊断轴 span 为源代际，宏展开真代际的诚实边界登记窗口档）。
- **K163 第四实例（P1 生产缺陷当轮清偿——新输入域即新审计域）**：twin 重建树 span 的 file_id 恒 FileId(0)（parity harness 惯例域）——r145/r146 切换 sweep 恰在零 id 域验证故树面从未重靶；**本轮非零 file id 会话首入输入域即暴露**（诊断 file 归属错档）。§20 同类路径全量清偿：read 段 `retarget_forms`（StxDatum::List 递归 walk）+ expand 段 `retarget_items`/`retarget_expr`（ModuleItem/CoreExpr/Binding/HandlerClause 全变体穷尽 match——FIX-16 编译期表随源长）；BC05/BC10 + 测试族非零 id 案例回归钉扎。
- **P0 性能回归当轮发现当轮修复（A/B 基线对照实证）**：`drive_dual_engines`/`drive_full_face`（差分 harness 宿主）在 r147 默认位下对 46KB 级 assembled 链工件跑解释态检查（infer twin HM ≈ 49s/件）——corpus sweep 61 分钟（基线 5 分钟，10× 回归）。**修复 = harness 自检检查步钉 Rust**（与种子面同构：assembled 程序是链工件非用户程序，其检查结论仅喂 harness「必须干净」断言——twin 位零验证增值而成本灾难；read/expand 步保持生产位——r145/r146 先例的免费输入域覆盖）。修复后全树超长测试全面回落：corpus sweep 308s / hm_twin_face 54.6→3.3s / hm_twin_chain 317-369→13-19s / lexer twin curated 331→35s / parser twin rejection >600→105s。
- **双链解耦三段全钉（§21.12-28②）**：`parse_target_with_injected`（链构造自身入口——检查孪生链构造经此，twin 位检查在此 = 循环）+ `read_target_source_for_bootstrap`（fixpoint 纯度腿）+ `rust_compile_ccf`（A 轮种子身份）——`Session::with_segments(Rust, Rust, Rust)` 三参扩展；防御性重排：injected 程序抵达 twin 臂 = 大声 wiring 缺陷（绝不静默 oracle 侧步）。
- **回退带（§14.6.4 规则 5 测量先行）**：`KERF_CHECK_SEGMENT` = `twin`（默认）| `rust`（回退）| 其他 = 硬错误（fail-closed）；CLI session_from_env 三键全消费。
- **预算镜像审查（tp_limit/ex_limit 先例对照——零改动裁定）**：推断深度预算双侧烘焙 512（Rust 常量 + infer.ktf 烘焙值，无任何环境面）——回退带同键义务构造性成立；且 E0011 生产管线结构性不可达（展开帽 512 先拦——520 深左脊探针实证双位同拒于展开层），预算镜像义务空真成立。
- **测量先行三跑落档（tool-results/r147-check-segment-run{1,2,3}.txt——examples/bench/check_segment_profile.rs 新建）**：双链构造 ~22ms 一次/进程（check 5ms + infer 17ms）；每检查对照（twin vs Rust 中位数）——curated-small ≈ 1.4-1.5× / match-composite ≈ 1.4× / check-twin-CCF ≈ 3.8-3.9× / **infer-twin-CCF ≈ 23×**（49.5-49.9s vs 2.1s——HM 推断解释态的最重负载；生产位检查的合法成本形态，非缺陷）；全 spine 切片（read+expand+check 三段切换位）——small ≈ 1.5× / match ≈ 1.4× / macro-twin-20KB ≈ 4.0×。K140 段级切片带追加（与 read 240-990× / expand 58-230× 同序收窄——check 段比值带显著更窄：oracle 检查自身毫秒级、分母大）。
- **测试族十一件 + audit BC 族 10 案（440→450 · 53→54 节）**：check_segment_switch_tests 新建（curated 双位一致 / selfhost+CCF 固定点 / 发现族渲染位级一致含非零 id / 推断层双位一致 + E0011 结构性不可达披露 / 警告通道不阻断 / 空程序面 / 回退带三态 / 跨段消费〔字节码位级 + run 值一致 + 拒绝批一致〕/ CLI 端到端 / 种子钉源扫描 + 幂等注入防御 / S-expr 面不动）；BC01-BC10（披露/双位一致/推断层/警告/span 重靶/种子钉/选择器/定点/空面/树重靶回归）。

## 自举矩阵实态

- G4 step ④：read ✓（r145）+ expand ✓（r146）+ **check ✓（本轮）** / compile 段 = 下一刀（SteadyCompilerChain 已在位——r144 TA-4；形制沿 TA-7）。
- C2 后半：read + expand + check 三段 ✓；compile 段 + step ⑤ 宣告（C1/C2 验收 + K140 带登记 + 工作流实录）排期内。
- S-expr 转化台账：零新转化面（检查孪生 r127/r131 在账；本轮位切换非新转化，行数零共变）。

# kerf v0.107.0 — T-a step ④ 第二段：expand 段生产位切换（r146）

第一百四十六轮（r146 · Task 146——中断轮续完：实施面由中断会话落树 ~90%，验证面/文档族/金链锁步由恢复会话续完，含 K163 第三实例生产缺陷当轮清偿与三处夹具勘误）· SOP v15.3 §21.12-28 自举完备优先 · T-a 切换窗 step ④ 第二段刀轮 · L3（生产管线核心域——expand 段 = 一切 .ktf 生产展开入口 + junction-2 双拒绝面 + expander.ktf 孪生手术 + 全树默认翻转共变）。

## 本轮交付

- **expand 段生产位切换（step ④ 四段之二——w-t-a-switch-window §3 r146 行）**：`.ktf` 生产展开默认翻转至稳态展开孪生链（`ExpandSegment::Twin`——expand_segment.rs 新建 315 行：ExpandSegment 枚举 + `KERF_EXPAND_SEGMENT` 三态 fail-closed + 预算键控链缓存 + span 重靶 + `production_expand` 单一入口）；**junction-2 纪律**：孪生裁决覆盖展开与加载两拒绝面（`ParityError::Expand | Module`——生产位不再跑 Rust loader；twin 即加载面）。Rust 展开器退役 oracle 面（parity 比较臂 + 种子链自展 + 回退带）。
- **预算镜像（tp_limit 先例）**：expander.ktf 孪生源 512 烘焙 → 参数化 `ex_limit` 全局（`ex_depth >= ex_limit` + depth 载荷携 limit〔自描述拒绝——decode 位置无关预算无关〕+ reconstruct_expand_error 从载荷读限）+ 装配前缀 `define(ex_limit, N);` 携进程有效 `KERF_EXPANSION_LIMIT`——预算覆写双位同键拒绝（回退带 parity 义务）；链按 expansion 预算键控逐线程缓存。
- **双链解耦双段落位（§21.12-28②）**：三种子面钉 Rust——`parse_target_with_injected`（链构造自身入口——生产位在此 = 循环）+ `read_target_source_for_bootstrap`（fixpoint 纯度腿 oracle 臂——r145 读段钉位扩双段）+ `rust_compile_ccf`（A 轮种子身份）——`Session::with_segments(Rust, Rust)`；比较面坍缩防护 = 源扫描守卫机检（read 段 r145 同形）。
- **回退带（§14.6.4 规则 5 测量先行）**：`KERF_EXPAND_SEGMENT` = `twin`（默认）| `rust`（回退）| 其他 = 硬错误（fail-closed）；CLI 进程入口单点消费；缺陷大声失败（driver_error——绝不静默回落）。
- **测量先行三跑落档（tool-results/r146-expand-segment-run{1,2,3}.txt——examples/bench/expand_segment_profile.rs 新建）**：链构造 ~15-16ms 一次/进程；每展开对照（twin vs Rust 中位数）——curated-small ≈ 227-230× / match-composite ≈ 218-224× / **expander-twin-CCF-60KB ≈ 57.6-58.7×**（283-292ms vs 4.8-5.1ms——深负载比值低于读段 570×：oracle 自身展开 60KB ~5ms 远慢于读 1.9ms，分母变大）；全 spine（读+展+载，双段均切换位）——small ≈ 484-516× / match ≈ 444-502× / macro-twin-20KB ≈ 250-259×。K140 段级切片带诚实登记（与 read 段带及全链 ~339× 同序——纯解释 VM 预期形态；收窄后置 W-3.8 链外可选项；回退带在场）。预算检查：30 深嵌套在预算 8 下双位同键拒绝（ex_limit 镜像验证）。
- **K163 第三实例（生产缺陷当轮清偿——新输入域即新审计域）**：`rebuild_lit` 右脊递归（expander_parity.rs——展开段解码面）：determinism 守卫的 assembled-expander 主题前缀表 = ~2 万记录右脊，生产位 twin 展开解码逐记录递归 → **默认栈溢出实证**（1GB 栈复跑通过定位为深度型）；清偿 = 右脊迭代行走（`Value::from_literal` r145 先例形制：脊柱步 = 记录 cdr 载荷〔下一记录——真列表〕而非堆链〔降入记录内部〕；car 递归 = 读帽所界；点尾 = 末元素解码；非记录裸原子 = `value_elems` 大声失败）——determinism 守卫 = 回归钉扎（默认栈双遍历一致）。**K163 同族预防位**：`forms_stream_literal` 右脊 Box-drop 胶水（与 r145 读段宿主表同族）——`dispose_literal_iteratively` 升 `pub(crate)` 共享 × 全注入位（expand / expand_dual / expand_production / abc expand_via）迭代析构 + BB10 默认栈回归钉扎（CCF 形式 60KB 全展开）。
- **测试族十件（expand_segment_switch_tests.rs 新建 523 行）**：curated 全族双位 items 位级一致 + selfhost 固定点默认栈展开（九源 + 装配展开器）+ 拒绝渲染位级等同（同键 + 同渲染文本〔非零 FileId span 重靶面〕——.ktf 皮肤四案：unbound / top-level / non-exhaustive match / malformed macro spec datum）+ junction-2 模块面同键（loader 拒绝覆盖）+ 预算覆写双位一致 + 回退带三态（默认 twin / 显式 rust / 非法值 fail-closed ×6 拒）+ 跨段消费（生产位展开喂全 spine → 字节码 == Rust 位字节码——深主题 = CCF 形式 expander 孪生）+ CLI check 端到端 + 种子钉源扫描守卫 + Sexpr 种子面不受扰；read_segment.rs 单元 2 件（env 解析 + span 重靶）。
- **audit BB 族 10 案（430→440 · 52→53 节）**：BB01 披露位 / BB02 curated items 位级 / BB03 拒绝同键 / BB04 junction-2 模块面 / BB05 选择器 fail-closed / BB06 match 复合双位 / BB07 种子钉（CCF 族双位一致）/ BB08 预算镜像（紧预算同键拒）/ BB09 span 重靶（非零 FileId 渲染对档）/ BB10 栈平回归（CCF 形式 60KB 默认栈全展开）。
- **中断轮勘误（恢复会话 146-a——三处夹具设计缺陷，非生产缺陷）**：①跨段消费深主题 = CCF 形式（裸装配体非自含——`forms` 槽引用 + `ex_is_name_member` 宏库依赖 → 双位同键拒绝 = 固定点族一致性面非正例）；②拒绝族 .ktf 皮肤四案定稿（中断稿 `let = 1;` 与三元组模式 = 读层拒绝〔.ktf 语法层形状强制〕、`f( )` = 合法零参调用〔双位 Ok〕——读净载体的展开层形状拒绝只剩 macro spec datum 通道）；③profile 深负载同改 CCF 形式。
- **文档族**：w-t-a-switch-window v1.2（TA-6 形制单源 + K163 第三实例）+ bootstrap-completion-plan v1.11（§4.3 r146 ✓ + §8 复核）+ roadmap v2.75 + stage0 v10.00（§9.132）+ tech-debt r146 检视（K163 第三实例 + 预防位 + 零新 TD + 8 原语第一百零八轮验证）+ 转化台账行数共变（expander 2,227→2,230——ex_limit 参数化 +3；累计 14,883→14,886 实测口径）+ 本件。
- **测试面 1652→1664:0:4（runner 717→727〔+10 族〕+ lib 848→850〔+2 单元〕；全树 Target 面测试双段默认翻转即生产位全语料 sweep——分块跑全绿〔4GB 主机约束诚实披露：深栈线程与稳态链构造碰撞 → 顺序分块 + 2 线程纪律〕）；六命令 clean 冷跑全绿（build 0e0w + clippy -D warnings 零 + fmt 零 diff + doc 唯一 cargo#6313）；audit 440/440 live + 104 retired · 53 节；R8 扫描清零（新增代码面零 CJK）；golden K159 门维持全过（344.98s）；v0.107.0 金链锁步（Cargo.toml + ds08 钉扎——bump 后全量重跑纪律 r99 教训）。

## 下一入口

T-a step ④ 次段：check 段生产位切换（SteadyCheckChain/SteadyTypecheckChain 为生产位 + Rust 检查器退役 oracle + 全语料 parity 门 + 段级回退带——形制沿 TA-6；compile 段后置；step ⑤ 工作流宣告殿后）。自举矩阵：C1 ✓ / C3 ✓ / C2 前半 ✓（K159 门）+ **C2 后半 read 段 ✓ + expand 段 ✓（本轮）** / check+compile 段 ✗（排期内）/ C4 = step ⑤。

# kerf v0.106.0 — T-a step ④ 首段：read 段生产位切换（r145）

第一百四十五轮（r145 · Task 145）· SOP v15.3 §21.12-28 自举完备优先 · T-a 切换窗 step ④ 首段刀轮 · L3（生产管线核心域——parse_with Target 臂 = 一切 .ktf 编译入口 + 全树 Target 面测试默认翻转共变）。

## 本轮交付

- **read 段生产位切换（step ④ 四段之首——w-t-a-switch-window §3 r145+ 行）**：`.ktf` 生产读默认翻转至稳态孪生链（`ReadSegment::Twin`——target-lexer.ktf + K20 永久宿主桥 + target-parser.ktf，VM 臂〔MJ-5 生产引擎裁定〕，链按 nesting 帽键控缓存逐线程一次构造）；Rust 目标读器退役为 oracle 面（parity 比较臂 + 种子链自读 + 回退带）。`ParsedProgram.read_segment` 披露位（可观测非静默旁路）。
- **双链解耦在驱动内的落位（§21.12-28②）**：生产面（`parse_with` Target 臂默认孪生读）vs 种子面钉 Rust——`read_target_source_for_bootstrap`（fixpoint 纯度腿「孪生前端 == Rust 生产桥」oracle 臂——防自比较坍缩〔检测力零〕）+ `rust_compile_ccf`（A 轮 = Rust 编译器作为种子四段全 Rust——A≡B 观察行 read 段差分保全）；源扫描守卫（read_segment_switch_tests::the_seed_faces_stay_pinned_to_the_rust_reader——TEST-2/TEST-3 机检源不变式先例）。
- **回退带（§14.6.4 规则 5 测量先行）**：`KERF_READ_SEGMENT` = `twin`（默认）| `rust`（回退）| 其他 = 硬错误（fail-closed——DepthLimits 先例；静默忽略 = 谎）；CLI 进程入口单点消费（session_from_env）。链构造缺陷 = 大声失败诊断（driver_error——绝不静默回落 Rust 读，§2.3-4）。
- **测量先行三跑落档（tool-results/r145-read-segment-run{1,2,3}.txt——examples/bench/read_segment_profile.rs）**：链构造 ~30ms 一次/进程；每读对照（twin vs Rust 中位数）——curated-small 2.2ms vs 0.002ms ≈ **970×** / match-composite 2.8ms vs 0.003ms ≈ **990×** / expander-twin-60KB 1.09s vs 1.9ms ≈ **570×**；全 spine（读+展+载）——small ≈ 450× / match ≈ 460× / macro-twin-20KB ≈ 240×。K140 段级切片带诚实登记（与全链 ~339× 带同序——纯解释 VM 上的预期形态；收窄后置 W-3.8 链外可选项）。
- **K163 第二实例（新输入域即新审计域——r144 新锚的即轮兑现）**：生产位在默认栈上暴露 `pair_cells`/`Value::from_literal`/Box-drop 胶水三处同族递归缺陷（~60KB 源 = ~6 万单元对链 = 6 万帧 → 栈溢出）——验证面以 768MB 深栈线程掩蔽 10+ 轮的潜伏缺陷。§20 同类路径全量清偿：`pair_cells` 显式栈迭代 + `from_literal` 右脊迭代（car 递归仅嵌套深度 = 读帽所界）+ `dispose_literal_iteratively`（生产读两表的主显式析构）。BA10 钉扎回归（expander 孪生 60KB 源默认栈读通）。
- **种子面结构自证**：`parse_target_with_injected` = 种子面（内联 Rust 读——链构造自身骑此入口；生产位读在此 = 循环，结构性排除）。
- **测试族十件（read_segment_switch_tests.rs）**：curated 全族双位一致（forms 位级）+ selfhost 固定点默认栈读（九源 + 装配展开器——r145 栈平族回归）+ 拒绝渲染位级等同（同键 + 同渲染文本〔非零 FileId 会话 = span 重映射面〕）+ 层分裂（lexer 层拒绝永不达 parser 孪生）+ 嵌套帽覆写双位一致（512 帽 200 深纳 / 256 帽 400 深同键拒）+ 回退带三态（默认 twin / 显式 rust / 非法值 fail-closed）+ 跨段消费（生产位读喂全 spine → 字节码 == Rust 位字节码〔C1 公式生产位口径〕）+ CLI check 端到端（清洁过 / 拒绝渲染 == Rust 位渲染）+ 种子钉源扫描守卫 + Sexpr 种子面不受扰。
- **audit BA 族 10 案（420→430 live · 51→52 节）**：BA01 披露位 / BA02 curated 正例 forms 位级 / BA03 parser 层拒绝同键 / BA04 层分裂 / BA05 选择器 fail-closed / BA06 match 复合双位一致 / BA07 种子钉（CCF 族双位一致）/ BA08 帽覆写 / BA09 span 重靶（非零 FileId 渲染对档）/ BA10 栈平回归（60KB 默认栈）。
- **文档族**：w-t-a-switch-window v1.1（step ④ read ✓ + 测量带 + K163 二实例）+ bootstrap-completion-plan v1.10（§4.3 step ④ read ✓ + §8 r145 复核）+ roadmap v2.74 + stage0 v9.99（§9.131）+ tech-debt r145 检视（K163 三清偿 + 零新 TD）+ 本件；转化台账零新转化面（读孪生早于 r136/r138 在账——位切换非新转化）。
- **测试面 1640→1642:0:4（runner 707→717〔+10 族〕+ lib +2〔read_segment 单元〕；全树 Target 面测试默认翻转即生产位全语料 sweep——runner 分块跑全绿〔552+71+25+10+21+10+6+18+gap〕）；六命令 clean 冷跑全绿（build 0e0w + clippy -D warnings 零 + fmt 零 diff + doc 唯一 cargo#6313）；R8 扫描清零（新增三文件 + 全部 diff 增量零 CJK）；v0.106.0 金链锁步（Cargo.toml + ds08 钉扎——bump 后全量重跑纪律 r99 教训）。

## 下一入口

T-a step ④ 次段：expand 段生产位切换（SteadyExpanderChain 为生产位 + Rust 展开器退役 oracle + 全语料 parity 门 + 段级回退带——w-t-a-switch-window §3 排期；check/compile 两段后置；step ⑤ 工作流宣告殿后）。自举矩阵：C1 ✓ / C3 ✓ / C2 前半 ✓（K159 门）+ **C2 后半 read 段 ✓（本轮）** / C4 = step ⑤。

# kerf v0.105.0 — T-a 首刀：A/B/C 工件管线与 K159 不动点门首证（r144）

第一百四十四轮（r144 · Task 144）· SOP v15.3 §21.12-28 自举完备优先 · T-a 切换窗 step ②+③ 交付轮 · L3（自举管线核心域——bootstrap/ 全家族 + selfhost 孪生消费面 + 新装配形制）。

## 本轮交付

- **CCF 链可编译形制（TA-1——本窗核心裁定）**：链自身程序的可编译形 = extern 槽声明 + 孪生源原样（`extern "C" { fn source_bytes() -> int; }` + target-lexer.ktf——六件：ccf-lexer/parser〔tp_forms+tp_limit 前缀〕/expander〔MX-2 装配体〕/infer/check/compiler）。语义链：展开器 extern_names 预播种 → 检查器 R1 externals → HM 契约箭头类型化裸引用（槽作函数实参由参数吸收——孪生自身用法形）→ 编译器 load-global → 产品惰性契约记录（零代码）→ 注入通道运行时绑定。皮肤映射 Rule K（`source_bytes` → `source-bytes` 规范身份）；C 符号地板连字符→下划线推导合法。否决形制三：裸源（展开层 unbound）/ 前缀 define（运行时覆写槽）/ 宿主注入面（链不可自处理）。
- **A/B/C 三轮 + K159 不动点门首证（TA-2）**：A = Rust 普通生产管线编译六 CCF；B = 链骑 A 工件（VM 臂 + 注入通道 + 树同一性门 + 查双轴微分 + SteadyCompilerChain 编段）编译链自身；C = 同形骑 B 工件再编译。**B ≡ C 位级六工件全过**（Bytecode PartialEq 全描述符表）+ A ≡ B parity 观察行同真——K159「不动点是验证门非构建步骤；链条定长工件显式」首证。golden 集成测试 ~325s（release——十二次全链自编译上 VM）。
- **SteadyCompilerChain 编译段稳态形（TA-4）**：编译孪生经 `items` 注入通道消费（稳态链族末位补齐）——与装配烘焙路线（ktf_compile_rich）同孪生双投递面，AZ06 钉扎双路产品位级等价。
- **四项前置缺陷清偿（TA-3——CCF 新输入域首次暴露，语料四盲区齐触）**：①infer.ktf `ti_join` 以 `eq` 内建（pair = Rc 指针身份）比较复合类型 → 复合分支 tif 恒 dyn——清偿 = `ti_type_eq(mode,a,b)` 单分派器结构相等；②`ti_env_truncate` 保留端反转（头推表保留最新、丢弃最旧参数）→ let 后外层绑定回退 dyn——清偿 = `ti_drop` 保留最旧；③Tarjan 边表 `ti_rev` 降序 → SCC 发射序反 → 密集图 var 索引交换——清偿 = 升序；④`items_stream_literal` generation 字符串 vs CP-1 文本 grammar INT → 编译孪生透传产品 dbg 记录被重建拒——清偿 = 统一 INT。**K163 新锚：新输入域即新审计域**（sweep 全绿只对已见输入形状有效——自举每入新输入域，审计集先扩展到该域形状空间）。
- **测试族六件**：golden K159 门（B≡C + A≡B + 六工件计数与契约记录）+ 负例四（裸源展开层拒绝〔extern 声明承重〕/ 拒绝源 fail-closed / 门检测力〔变异产物被拒 + FAIL 行命名工件〕/ 未声明槽同键拒绝）+ 跨段消费（B 工件作链段实跑——C 轮消费面的单段钉扎 + parity 锚）。
- **audit AZ 族 10 案（410→420 live · 50→51 节）**：AZ01 装配面与槽名表 / AZ02 A 轮六工件契约记录 / AZ03 声明承重 / AZ04 C 符号地板 / AZ05 声明 vs 未声明 / AZ06 编译段双路等价 / AZ07 generation INT 编码 / AZ08 查双轴微分（lexer CCF 全尺度）/ AZ09 门行形制 / AZ10 契约记录值路径惰性 + 产品 = oracle 编译。
- **文档族**：w-t-a-switch-window.md v1.0 新建（T-a 窗档单源——TA-1..TA-4 裁定 + 刀级排期 + 出口条件 + K163）+ bootstrap-completion-plan v1.9（§4.3 step ②③ ✓ + §8 r144 复核）+ roadmap v2.73 + stage0 v9.98（§9.130）+ tech-debt r144 检视（四清偿 + 零新 TD）+ 转化台账行数共变（infer 3,690→3,774 + r143 陈旧清偿 expander 1,671→2,227——累计 14,243→14,883）+ 本件。
- **测试面 1634→1640:0:4（+6）**；六命令 clean 冷跑全绿（build 0e0w + clippy -D warnings 零 + fmt 零 diff + doc 唯一 cargo#6313）；R8 扫描清零（新增代码面零 CJK）；v0.105.0 金链锁步（Cargo.toml + ds08 钉扎——bump 后全量重跑纪律 r99 教训）。

## 下一入口

T-a step ④ 分段生产位切换（read → expand → check → compile 逐段：孪生生产位 + Rust 段退役 oracle + 全语料 parity 门 + 段级回退带——w-t-a-switch-window §3 排期；step ⑤ 工作流宣告后置）。自举矩阵：C1 ✓ / C3 ✓ / C2 前半 ✓（K159 门）/ C2 后半 = step ④ / C4 = step ⑤。

# kerf v0.104.0 — TD-027 清偿：双子展开器 match 臂与 T-a 开窗对账（r143）

第一百四十三轮（r143 · Task 143）· SOP v15.3 §21.12-28 自举完备优先 · TD-027 前置门清偿 + T-a 切换窗开窗对账轮 · L3（大阶段切换点轮——展开孪生核心域 + C1 组成链共变面 + 语料/守卫/审计全链）。

## 本轮交付

- **TD-027 全链清偿（tech-debt r139 登记 → r143 关闭）**：expander.ktf 新增 match 臂——oracle expand_match 逐决策镜像（mchk 臂形态 walk → 穷尽性检查 → scrutinee 单次求值入 `match(scrut` 载体 → marm 右折叠）；compile_pattern 六模式族（`=`/`eq?`/`nil?`/`_`/裸绑定/pair?+car/cdr 二元组；一元透传；三元+ = unsupported-pattern fail-closed）；孪生 span/gen 逐位镜像（载体 Let/Binding、test apply、arm Let 的 span 与 generation 全对账——rebuild gen_span 逐位）。
- **错误协议共变（FIX-16 同 commit 扩表纪律）**：expander_parity.rs 新增 "nonexhaustive"/"unsupported-pattern" 两错误 kind 重建 + static_form "match"——孪生报告的 match 拒绝族经 oracle Display 重建，错误轴 parity by construction。
- **组成链 J0.9 边界行退役 + audit AV7 共变**：match 载荷程序走全公式（J0 读双引擎 → J1 展开双引擎 parity → J1.5 check → J2 compile）——r139 登记的披露边界行退役，AV7 断言从披露边界翻转为全公式（r123 边界退役先例）。
- **语料族 21 案（91→112）**：pos-038..048 十一正（模式族全覆盖：bare/`_`/float/string/bool 字面量同类型、nil、pair 带兜底尾、嵌套 pair、shadow、函数内折叠、scrutinee 单次求值）+ neg-063..072 十负（nonexhaustive×2/unsupported×2/malformed×2/unbound×2/**错误顺序钉扎×2**——穷尽性先于 pattern 编译、scrutinee 展开先于 pattern 编译）。
- **转码器 match 臂（skin_transcoder.rs）**：emit_pattern（nil→`()`、符号逆皮肤拼写、list→括号逗号形）+ match_arm_is_shaped guard——.krf→.ktf 双皮肤契约（malformed 臂走 call 面 = stage 对齐机制先例）。
- **五守卫共变**：HM 轴分类钉扎（expansion 19→29 + infer_clean 58→69 + check_clean 54→65 + fed 64→75）/ infer sweep / check sweep / target sweep（91→112 + stage-divergent 表 +4）/ composed ledger（expand 22→32 / compile 58→69）。
- **audit AY 族 10 案（400→410 live · 49→50 节）**：AY01 值面 / AY02-03 穷尽性+模式族拒绝 / AY04 scrutinee 单次求值（write-line 效应计数）/ AY05 shadow / AY06 嵌套 pair / AY07 孪生 parity（稳态链 vs oracle 双轴）/ AY08 组成链全公式（J0.9 退役验证）/ AY09 转码面 / AY10 错误顺序双钉扎。
- **LLC 链内退役/维持重审裁定：LLC 维持在位**（r142 改判登记的延后重审兑现——LLC 是编译期静态融合与被证伪的运行时 tier 分派不同机制类；r135 +3% 墙时实测未被动摇；退役成本〔opcode 27 全链回退〕远超 3% 墙时差；再重审时点 = W-3.8 codegen 窗）。
- **T-a 开窗对账：前置全凑齐**（G1 ✓ + G2 ✓ + G3 裁决完成 + TD-027 ✓）——step ① 种子链固化落档（宪制排除项清点 + 种子工件清点）；step ② A/B/C 工件管线 = r144 首刀；K140 带重审结论 = ~10× 维持为 step ⑤ 验收带，达成路径诚实化（稳态摊销 × A/B/C 实测 ×〔可选〕W-3.8），不预设达标时点。
- **文档族**：bootstrap-completion-plan v1.8（G4 行 + §4.3 开窗对账 + §8 r143 复核 + LLC 裁定）+ tech-debt r143 检视（TD-027 关闭 + LLC 重审裁定）+ roadmap v2.72 + stage0 v9.97（§9.129）+ 本件。

## 验收

- 六命令（bump 后全量重跑——r99 教训）：build 0e0w / check 0/0 / fmt 零 diff / clippy --all-targets -D warnings 零 / test --release **1634:0:4**（+21 语料族） / doc 唯一 cargo#6313；audit **410/410 live + 104 retired · 50 节**（AY 族 10 案 + AV7 共变）。
- 8 原语不变性第一百零五轮验证（match 臂 = 冻结子集 18 内建纯消费，零子集面扩展）。
- S-expr 转化记录：零新转化面（match 臂 = 展开器能力扩展非 S-expr 转化——台账维持九件）。
- 自举矩阵实态：G1 ✓ + G2 ✓ + G3 裁决完成 + **G4 前置全凑齐（TD-027 ✓）** → **T-a 开窗合法成立**；C1 ✓ / C3 ✓ / C2 ✗（step ② A/B/C 工件管线 = r144 首刀）/ C4 ✗（随 C2）。

---

# kerf v0.103.0 — W-JIT-METHOD-T1 tier-1 刀 2：B 轴实测裁决与窗口出口（r142）

第一百四十二轮（r142 · Task 142）· SOP v15.3 §21.12-28 自举完备优先 · W-JIT-METHOD-T1 窗内刀 2（G3 性能前置——窗口出口轮）· L3 常规轮（VM 执行核心域测量裁决 + 测试面 + 审计面 + 生产默认翻转全链）。

## 本轮交付

- **刀 2 双裁定 MJ-5/MJ-6（w-jit-method-t1-window.md v1.2 §8——K129 实测裁决纪律）**：**MJ-5 生产默认 = 纯解释**——三跑 B 轴对照实测 closure chain 净负 ~9%（fib-25 tier-on 73.140/71.935/71.801ms vs tier-off 66.137/65.952/66.706ms——ratio 1.106/1.091/1.076）→ MJ-1 诚实注记实测兑现（`Rc<dyn Fn>` 间接调用 + entry 索引 + Rc 维护 > 消除的 match 分派；**零 codegen 约束下 27 臂 match 解释器即最优分派形态**——K152/K157 实证）→ `Vm::new` 默认翻转为 `METHOD_TIER_DISABLED`（u32::MAX）+ `note_invoke` early-out 零成本关闭态（禁用态计数恒 0 = 钉扎语义）+ `METHOD_HOT_THRESHOLD`（64）转为 opt-in 推荐阈值；机制保留双位 = opt-in 验证面 + W-3.8 链外 codegen 窗基座资产（census 计数器 + MethodChain 纯函数构建器 + chain_listing 确定性面）。**MJ-6 窗口出口裁定 = 带缺口登记关闭**——三触发器复画像（生产位 tier-off 口径）：①B2 66.1ms = 2.79× C-O0 带（阈 1.8×）未清；②分派份额 64.2%（阈 40%）未清（census 与 r135 逐位维持：1,942,283 指令 / LLC 485,569）；③T-a 链路 ~339×（阈 25×）未清——消除杠杆（真 codegen）在链外（W-3.8 可选位——链内结构性天花板诚实登记）。
- **LLC 杠杆归属改判**：r135「LLC -20% 指令数价值在 tier-1 内兑现」论题被实测结构性证伪（兑现载体不存在）→ LLC 墙时面确认净负资产（r135 +3% 维持）；链内退役/维持延后 T-a 切换窗开窗轮重审（opcode 全链回退成本 vs 墙时 ~3% 的权衡在切换窗组合面内裁定）。
- **测量面升级**：vm_dispatch_profile 双臂对照——每负载 tier-on（默认）/tier-off（u32::MAX）双计时 + ratio 行 + tier_compiled_any 健全性探针；dispatch-share summary 以生产位口径承载；三跑落档 tool-results/r142-dispatch-profile-run{1,2,3}.txt。
- **生产语义钉扎（blade-2 测试族六件——正 2/负 4）**：正 = 生产默认纯解释（Vm::new 三零：零计数/零链/零构建 + 与显式禁用臂值/输出/账逐位）+ LLC 协作单节点双压（融合对在链内 = 单节点——listing 钉扎 + census 引擎不变性）；负 = 禁用零计数冻结语义 + LLC 错误载荷跨引擎位级 + opt-in 63/64 边界 + 帧边界预算 parity（BudgetExceeded 同位同账）。
- **audit AX 族 10 案**（390→400 live · 48→49 节）：AX01 生产默认 / AX02 opt-in 穿越 / AX03 LLC 协作 parity / AX04 链内 LLC 节点形态 / AX05 census 引擎不变性 / **AX06 r135 画像数字机制化**（1,942,283 + 485,569 逐位钉扎——工具产物与 audit 的机制化对照锚）/ AX07 禁用常量 = 默认一致性 / AX08 帧边界混合引擎 / AX09 LLC 错误载荷 / AX10 深递归堆帧；TEST-3 守卫共变（504 总 = 400 live + 104 retired）。
- **共变面全清**：AW01/AW07（audit 默认断言 → 显式 opt-in 构造化）+ wmj_method_tier_dual_path（默认臂改写 + opt-in 臂新增 + census 引擎不变性对照臂改用计数不达阈构造）+ TEST-3（400/400）。
- **文档族**：w-jit-method-t1-window v1.2（Status CLOSED + §8 双裁定）+ bootstrap-completion-plan v1.7（G3 改写 = 性能面实测裁决完成 + §8 r142 复核实态 + T-a 前置对账更新）+ roadmap v2.71 + stage0 v9.96（§9.128 三小节）+ tech-debt r142 检视（零新 TD + LLC 改判登记）+ 本件。

## 验收

- 六命令（cargo clean 冷跑，OBS 口径）：build 0e0w / check 0/0 / fmt 零 diff / clippy --all-targets -D warnings 零 / test --release **1613:0:4**（+6 blade-2 族） / doc 唯一 cargo#6313；audit **400/400 live + 104 retired · 49 节**（AX 族 10 案）。
- 8 原语不变性第一百零四轮验证：零新原语/零新内建/零语法增改/零操作码面变更（生产默认翻转 = 运行期策略面非机制面；VM 永久 Rust 基座宪制排除项维持）。
- S-expr 转化记录：零新转化面（刀 2 = Rust 侧测量与策略面——零 .ktf 孪生变更；台账维持九件 14,243 行）。
- 自举矩阵实态：G1 ✓ + G2 ✓ + **G3 裁决完成（W-JIT-METHOD-T1 CLOSED @ r142——带缺口登记）** + G4 切换窗前置凑齐（**T-a 开窗合法成立**）+ G5/G6 后置 + G7/G8 在册；C1 ✓ / C3 ✓ / C2 ✗（T-a 未开——下一入口 = T-a 切换窗开窗轮〔前置门 TD-027 + LLC 退役/维持重审〕）/ C4 ✗。

---

# kerf v0.102.0 — W-JIT-METHOD-T1 tier-1 刀 1：方法编译基础设施（r141）

第一百四十一轮（r141 · Task 141）· SOP v15.3 §21.12-28 自举完备优先 · W-JIT-METHOD-T1 窗内刀 1（G3 性能前置——tier-1 两刀之一）· L3 常规轮（VM 执行核心域 + 测试面 + 审计面全链）。

## 本轮交付

- **tier-1 刀级四裁定 MJ-1..MJ-4（w-jit-method-t1-window.md v1.1 §7——K158 菜单的操作化）**：MJ-1 执行形 = closure chain（链接闭包链——每节点恰一条指令的语义，1:1 镜像解释器臂：节点体调用与臂相同的 arm_* 辅助函数同序同载荷——**语义等价是构造性的非统计性的**〔r134 F1 先例形制〕；诚实注记 = Rc 直链在安全 Rust 前向引用下须内部可变性，其每步成本超过它要替代的索引——后继链接走 pc 索引表，刀 2 B 轴实测裁决）；MJ-2 census = per-function 闭包调用计数（invoke 闭包臂每调用 +1 非每指令 +1；METHOD_HOT_THRESHOLD = 64 两端论证〔fib-25 242,785 ≫ 64 摊销 / 一次性程序 1 ≪ 64 冷函数永不编译——F5 机制化〕；触达当次调用走编译链；失败永久回退无重试）；MJ-3 编译边界 = 整函数粒度 + 帧边界引擎选择（绝不混链；mid-method 重入经 pc 索引表；pc 纪律 = 驱动器单源 fetch 等价推进）；MJ-4 确定性 = 同 Bytecode 恒同链（canonical listing 可序列化比对）+ 双路同值（值/输出/错误/预算账逐位）。
- **实施全链（kerf-vm + 跨 crate 测试/审计）**：`crates/kerf-vm/src/methodjit.rs` 新模块（MethodChain 纯函数构建 + 悬挂跳转/空体/未知函数 fail-closed 纵深防御 + canonical listing + MethodJit census 状态机〔Cold/Hot/Failed〕）；vm.rs 臂提取重构（15 个 arm_* pub(crate) 单源镜像面 + 4 个 shim——两引擎共用同函数；解释器臂成为 arm_* 调用者）；run_dispatch loop-top 引擎选择（一次 Option 探测/迭代——刀 2 B 轴实测）+ run_compiled_frame 驱动器（const 泛型 OBSERVE 单化——观察三元组由驱动器上报，census 测量面零扰动）；invoke 闭包臂 note_invoke 计数钩子；Vm 构造器/策略面（with_method_tier_threshold + set_method_tier_threshold + method_tier() 观察面）。
- **构造性 parity 实证（刀 1 验收三腿全绿）**：双路同值（同程序阈值 u32::MAX 纯解释 vs 阈值 1 全编译 vs 默认 64 自然穿越——值/输出/allocations 逐位一致）；回退触发实测（构建器三拒绝面直调 + 健康运行零 Failed 记录——Verified 面上结构性不可达 = 纵深防御分层本身）；确定性（两次构建 listing 逐位相等 + 形变移动 listing）。
- **测试面（GATE 6 正负 1:3）**：method_jit_window_tests 新族 8 件（正 2/负 6：双路同值与账目 [MUV 141-b 集成验证用例] + 链确定性 | 构建器 fail-closed + 错误路径位级一致 [TypeMismatch/DivByZero 双族] + 预算边界 parity [BudgetExceeded 同位同账] + census 流零扰动 [观察三元组逐位] + 深递归堆帧纪律 [sum 2000] + entry 下界与 halt 边）；audit **AW 族 10 案**（380→390 live · 47→48 节：AW01-AW10 对应族面 + 默认 64 阈值边界〔63 次不编译/64 次编译〕）；TEST-3 守卫共变（494 总 = 390 live + 104 retired + 头行字面量）。
- **基线迁移**：test --release **1599:0:4 → 1607:0:4**（+8 新族——tier 机制默认激活下全树绿 = 构造性 parity 的全树实证〔fixpoint/gate B/parity/census 锚/gc/rec-depth 10^5 全部在 tier 开启态运行通过〕）；audit 390/390 · 48 节；六命令 clean 冷跑全绿（build 0e0w 18s / check 0/0 / fmt 零 diff / clippy -D warnings 零 / doc 唯一 cargo#6313）；R8 编码面扫描清零（新代码面全英文）。
- **零编译面变更**：操作码面 27 维持、零新原语、零 .ktf 孪生变更（tier = 运行期机制非编译期）——S-expr 转化台账维持九件 14,243 行（零新转化面）；快照黄金族零再生成（指令流不变）。
- **B 轴对照与守卫族再生成 = 刀 2 排期**（w-jit-method-t1-window.md §3 切轮表 + §7 交付范围声明——MUV 边界不降级）：tier-0.5 LLC 协作精化 + B 轴对照 tier-0.5 收尾基线三跑 + 三触发器复画像 + 守卫族再生成。

## 验收

- 六命令（cargo clean 冷跑，OBS 口径）：build 0e0w / check 0/0 / fmt 零 diff / clippy --all-targets -D warnings 零 / test --release **1607:0:4**（+8） / doc 唯一 cargo#6313；audit **390/390 live + 104 retired · 48 节**（AW 族 10 案——实施窗增节形制沿 r124-r139 先例）。
- 8 原语不变性第一百零三轮验证：零新原语/零新内建/零语法增改/零操作码面变更（tier = VM 执行层机制；VM 永久 Rust 基座宪制排除项维持——本刀为基座内优化非重写）。
- S-expr 转化记录：零新转化面（tier = Rust 侧执行层——零 .ktf 孪生变更；台账维持九件 14,243 行）。
- 自举矩阵实态：G1 ✓ + G2 ✓ + **G3 在窗（tier-1 刀 1 ✓——下一刀 = 刀 2 tier 分派集成/守卫/audit/B 轴）** + G4-G6 后置 + G7/G8 在册；C1 ✓ / C3 ✓ / C2 ✗（T-a 未开——前置 G1 ✓ + G2 ✓ + G3 在窗）/ C4 ✗。
- 下一入口：**W-JIT-METHOD-T1 tier-1 刀 2**（tier 分派集成 + LLC 协作精化 + 守卫族再生成 + audit AX + B 轴对照三跑 + 三触发器复画像——窗口出口条件 §4）∥ TD-027（T-a 前置门在册）。

---
# kerf v0.101.0 — 自举完备总规划 v1.5：语言基础时点裁定 + S-expr 拆除窗入序 + 转化台账（r140）

第一百四十轮（r140 · Task 140）· SOP v15.3 §21.12-28 自举完备优先 · 规划刷新轮（bootstrap-completion-plan.md v1.4→v1.5——G1 ✓ / G2 ✓ 闭合后的窗口序列重整 + 用户 15 条指令族承载）· 单轮规划域（零代码变更——六命令基线维持验证）。

## 本轮交付

- **两新窗入序（§3 序 4/序 7 + §4.4/§4.5 细粒度 MUV）**：**W-SEXP-RETIRE**（G7——S-expr 脚手架拆除窗：语料单皮肤迁移 → S-expr 读链退役 → 面清零扫描守卫化三刀；前置 = T-a step ④ read 段生产位 + TD-027；R5 拆除判据双臂满足——target 读链全语料覆盖 + 类型注解语法/胖关键字额外能力；先于 W-EVAL-RETIRE 的技术理由 = 最大表面迁移需双引擎 parity 安全网在场）+ **W-LANG-FOUNDATION**（G8——语言基础完备窗：类型注解消费面 → struct 脱糖 → enum 脱糖 + 穷尽性 → 模式匹配扩展 + 行多态评估窗四刀；前置 = 自举完备验收 C1-C4 + 单皮肤终态——§21.12-28① 从属位法定解除对象；工作流 = 自托管[编辑 .ktf → kerf 编译 → 测试经 VM]——C4 面首个生产消费）。
- **G7/G8 缺口行补全（§2 现状地图）**：S-expr 表面存续（双皮肤态——用户指令⑥「完全自举后完全使用目标语言词法语法语义」未兑现 = 自举终态组成缺口）+ 语言基础面未完备（struct/enum/注解消费 = Stage 2+ 登记态——stage0 §9.14.2 R4 实况对账）入账；G2 行刷新为已闭合（r136/r137——C3 终态）。
- **enum/struct 时点裁定（§9——用户审查问题正面回答）**：**时机未到（非遗忘）**——设计登记在位（stage0 §9.14.2 类型系统成员 + §7.4 内部语法 ADT 设计）+ 语法桥生产在位（target parser parse_type_drop:1602——注解全族解析后 drop）+ 实现窗法定 C2 后；三层结构性理由（冻结子集 = 自举目标面 / 串行自举硬规则 / 生产位切换后语言经自身推进——K140-K142 先例族投影）；与 8 原语不变性零冲突（struct/enum = 派生表面语法糖非原语面）；「当前这样好」的边界 = C1-C4 前是（纪律正确）、作为终态否（G8 入账 + 窗入序 = 不可无限推迟）。
- **S-expr→目标语言完全转化统一记录新建**（docs/develop/v3/s-expr-conversion-record.md v1.0——用户指令⑫落位）：九件 14,243 行逐件台账（lexer 671/reader 141/macro 686/expander 1,671/compiler 1,804/infer 3,690/typecheck 1,234/target-lexer 1,065/target-parser 3,281）+ 刀级谱系（r100 首波五件 → r121-r124 段族 → r126-r131 HM 刀族 → r133-r135 融合共变 → r136/r138 目标孪生 → r139 C1 闭合）+ 未转化面清点（G7 拆除对象）+ 三处单源登记义务 + 审计口径（wc -l 与台账累计行互证）。
- **roadmap §6 当前位置行 r140 刷新**（r120 滞留 19 轮的文档同步缺口清偿——§8.4.5 文档与代码冲突以代码为准 + 提交修正文档）：G1/G2/G3/G4 实态 + 窗口序列单源指针（bootstrap-completion-plan v1.5 §3 序 1-7）。
- **冻结问题重审对账（用户指令③——tech-debt r140 检视节承载）**：r135 W-PKG-SELFHOST 反冻结改写维持；subset-spec「Frozen」= 实现面诚实快照非政策性冻结（语义翻转经 MUV 合法行使三次先例）；§3.2 内核冻结 = 设计宪法锚与数据类型表面化正交——零「因冻结导致设计问题」残留项。
- **过度特化审查（指令⑨）**：本轮交付全为规划域通解（窗序/缺口入账/台账/裁定）；两新窗均为机制窗（拆除窗 = 脚手架生命周期通用拆除；语言基础窗 = 类型系统成员通设面）非位点特化；当前阶段未解决问题清单 = W-JIT-METHOD-T1 tier-1 两刀（排期内）+ TD-027（T-a 前置门）+ TD-026（riding）——零未登记问题，推进合法。

## 验收

- 六命令（cargo clean 冷跑，OBS 口径）：build 0e0w / check 0/0 / fmt 零 diff / clippy --all-targets -D warnings 零 / test --release **1599:0:4 基线维持**（r139 基线逐位——1599 passed + 4 ignored 重负载披露维持） / doc 零新增警告（cargo#6313 既有唯一）；audit **380/380 live + 104 retired · 47 节维持**（规划域零增测/零增节双合规——r126 先例）。
- 8 原语不变性第一百零二轮验证：零代码变更（规划域轮）——零新原语/零新内建/零语法增改/零操作码面变更。
- S-expr 转化记录：零新转化面（孪生维持九件 14,243 行——台账单源化本轮落位）；记录位 = 转化台账 + bootstrap-plan 窗口行 + stage0 §9.126（三处单源）。
- 下一入口：**W-JIT-METHOD-T1 tier-1 刀 1**（方法编译基础设施——TJ-4 去分派形态，构建于 G2 堆激活栈基座 TJ-3）∥ **TD-027**（双子展开器 match 臂——T-a 前置门）∥ T-a 切换窗前置对账（G1 ✓ + G2 ✓ + G3 在窗）。

# kerf v0.100.0 — W-TGT-READ-TWIN 刀 3：稳态目标读链 + C1 链路闭合（r139）

第一百三十九轮（r139 · Task 139）· SOP v15.3 §21.12-28 自举完备优先 · 自举完备总规划 §4.2 刀 3 行（bootstrap-completion-plan.md v1.4——G1 目标皮肤读链孪生窗的收口刀：**C1 链路级闭合 = G1 终态**）· 单刀整轮。

## 本轮交付

- **SteadyTargetReaderChain（G1 终态链形——steady_expander_chain 形制沿袭至目标读链）**：两孪生各编译一次——lexer 程序 = target-lexer.ktf 原文（引用 `source-bytes` 注入槽，RS-1 值面）；parser 程序 = tp-forms 表 + tp-limit 256 常量 + target-parser.ktf（引用 `tp-tokens` 注入槽）。每读四引擎（lexer vm+eval → 桥 → parser vm+eval——各轴独立桥接，桥 bug 偏袒一引擎需与另一引擎恒同漂移方可存活 sweep）。通道契约构建期断言（两 bytecode 的 globals 各含槽名）。
- **K20 永久宿主层桥（链结位实例化——crates/kerf-driver/src/bootstrap/steady_target_reader_chain.rs）**：lexer 孪生记录（span 面）→ parser 孪生输入记录（载荷面）：ident → skin_symbol 规范字节（oracle 自身单源）；float → strip_us + f64 解析 + Debug 格式化（非有限映射 oracle 自身 FloatOutOfRange——层分裂：lexer 层拒绝永不达 parser）；str → decode_target_string 转义解码；int/bool 载荷直通；eof 二字段记录先于 span 提取分裂。桥正确性机器检查 = 稳态/逐源/oracle 三路由同键（稳态桥由孪生 lexer 派生 vs 逐源由 oracle lexer 派生——两路由一致即桥证）。
- **组成链 composed_target_read_chain（C1 断链闭合——crates/kerf-driver/src/bootstrap/composed_target_read_chain.rs）**：J0 token / J0.5 tree / J1 expand（稳态链重建 forms 值面经 SteadyExpanderChain——r103 i64::MIN 文本边界不适用；1.6 树同一性门 items == oracle_items）/ J1.5 check（SteadyCheckChain——查段入组成链）/ J2 compile（ktf_compile_rich 终端字节码等同）= **pipeline_ktf(S) == pipeline_rust(S)** 五联差分；总路由（§9.87.4 沿袭）：匹配拒绝（错误轴一致）为该层 PASS 行（vacuous 下游），读层拒绝两轴同键。
- **fixpoint 纯度腿（K159 前置）**：fixpoint Phase-2 assembled 自应用程序（items 前缀 + compiler.ktf）读段经 twin_front_end_read（目标读孪生 + 展开孪生 → rebuild items）== 生产桥 items 断言（CP-1 约定沿袭——树真值源差分）。
- **读段自应用（最深固定点）**：selfhost 九源 + 孪生自身 3,281 行经稳态链（parser 孪生读自身源——engines agree + forms 重建）。
- **外部记录空参 nil 编码清偿（CP-1 词汇契约第三成员——r122/r124 extern 渲染族齐账）**：emit_item Extern 臂补 Fn 臂同款规则（空参列表载为 `nil` 非 `()`——S-expr 读者空应用拒绝；零消费者自 W-3.2 掩蔽至本轮组成链 sweep 暴露：extern-no-abi curated 案）。
- **诚实边界行（match 脱糖）**：双子展开器冻结子集域（subset-spec §1.2 八表达式形式——无 match 臂）vs oracle 超集（expand.rs expand_match）；语料 91 无 match 程序按设计；match 载荷 curated 五例 J0.9 结构分类披露（r103 先例形制）；TD-027 登记 follow-up（双子展开器 match 臂）。
- **测试与守卫族**：steady_target_reader_tests.rs 七测试（curated 91 案全公式 + selfhost 九源 + 组装展开器程序[最强实面] + 磁盘源 + 跨路由等价 + 层分裂 + 孪生前端 == 生产桥 + fixpoint 纯度腿）；test_infra_guard AV 族 10 案（370→380 live · 47 节）+ TEST-3 守卫共变（380/380 + 头行字面量 + 族注释）；eval_inventory_guard 台账 C 桶 +2（13→15——总 40→42）与窗口记录 §1 共变。
- **会话调试实录（stage0 §9.125.3 六类）**：桥 eof 二字段越界 / 「J0.5 匹配」误当「接受」（错误轴一致 ≠ 接受——层分裂读值） / 外部记录空参 () 不可读 / 1e999 词法歧义（int+ident 分裂非 float 文法）/ selfhost 孪生为链件（组装 + 前缀 define 形态才自包含）/ audit span 钉扎校准。

## 验收

- 六命令（cargo clean 冷跑）：build 0e0w / check 0/0 / fmt 零 diff / clippy --all-targets -D warnings 零 / **test --release 1599:0:0** / doc 唯一 cargo#6313；audit run **380/380 live + 104 retired · 47 节**（40 live + 7 retired）。
- 刀 3 三验收腿：**自源读取 parity**（九源 + 孪生自身——engines agree + forms 重建）✓ / **组成链等价**（91 curated + 九源 + 组装展开器程序全公式——C1 断链闭合）✓ / **fixpoint 经目标读链复现**（b_self_exec == b_self 维持 + 孪生读段新腿 == 生产桥）✓。
- S-expr 转化记录：**本轮零新转化面**（.ktf 孪生集合维持九件 14,243 行——本刀为链形/桥/组成层 Rust 侧工程，孪生皮肤件不变）；记录位 = 本文件 + bootstrap-plan §4.2 刀 3 行 + stage0 §9.125（三处单源）。
- 下一入口：**W-JIT-METHOD-T1 tier-1 刀 1**（方法编译基础设施——TJ-3 基座就位）∥ **TD-027 双子展开器 match 臂**（W-TGT-READ-TWIN 后续清偿）∥ T-a 切换窗前置对账（G1 ✓ + G2 ✓ + G3 在窗）。

# kerf v0.99.0 — W-TGT-READ-TWIN 刀 2：target Pratt parser 孪生（r138）

第一百三十八轮（r138 · Task 138）· SOP v15.3 §21.12-28 自举完备优先 · 自举完备总规划 §4.2 刀 2 行（bootstrap-completion-plan.md v1.3——G1 目标皮肤读链孪生窗的第二刀）· 单刀整轮（137-b 排期裁定的执行轮：孪生体量单刀完整交付）。

## 本轮交付

- **target-parser.ktf 第九自举孪生（G1 刀 2 主体）**：`crates/kerf-reader/src/target/parser.rs`（1,676 行）的 .ktf 全量镜像 = `selfhost/v1/target-parser.ktf`（3,281 行）——帧机形制（step/give/replace/push 显式栈机器——冻结子集无循环原语，迭代经自递归）逐决策镜像：14 级优先级瀑布（or/and/cmp/bit 族/加减/乘除模/一元/后缀）+ do/let 反向折叠 + quote datum 载体 + 模式族（字面量/绑定/mut 糖/对模式/nil 模式）+ 类型注解 drop（路径/泛型参数/圆括类型表/联合/函数返回/impl·effect 前缀）+ 胖关键字（fn/module/extern/macro/use 双形/handle/match/perform）+ fail-closed UnsupportedTargetForm 全表 + 24 关键字拒绝面。
- **TP-1 注入通道（parser 层 RS-1 形制沿袭）**：宿主以单源 Rust target lexer（`lex_target`——皮肤映射 K20 已在该层施加）注入三全局——token 记录表（`tp_tokens`：ident 携带皮肤映射后规范名字节表/float Debug 文本/str 解码文本）+ 嵌套限（`tp_limit`）+ oracle 自身 UnsupportedTargetForm 消息文本表（`tp_forms` 21 键——孪生侧消息漂移结构性不可能：消息值反查静态表 = oracle 单源）。孪生做全部 parse 决策；harness 解码 `tp_verdict`（vm/eval 双引擎各自）。
- **harness 与测试族**：`crates/kerf-driver/src/bootstrap/target_parser_parity.rs`（745 行——三注入前缀构造 + decode_tp_tree 递归[ident/int/float/dfloat 宿主取负/bool/string/list/use-str K20 宿主 skin_symbol/use-path] + rebuild_tp_error 五类错误重建 + drive_dual_engines 三向对比）+ `tests/v1/stage1/plan/target_parser_twin_tests.rs`（六测试：curated 91 案 / selfhost 九源自应用固定点[含孪生自身 3,281 行——最深自应用面] / 磁盘源 / 拒绝面 ≥35 同键 / anchor 错误键六例 / 跨阶段声明头）。
- **r138 会话调试实录清账（三簇缺陷修复——worklog Task-138-a-inprogress 序列化条目的三簇全部清零）**：簇 A params 重写回归（fn 头 name 前置序[tp_rappend 误用→prepend] + 空源 ("ok") 零记录 verdict 契约 + 类型圆括表缺 give 臂[元素经 machine-drop 误弹帧] + use-path 字符串记录端 = 分号端[oracle span_from 自身面] + extern 形参类型源序[累加器逆序]）+ 簇 B if/match/handle 帧族（if want-then 步进臂缺位[等待相位无子帧自旋] + give 相位名失配["want-then" vs "wait-then"——DONE 臂误吞 then 为 else 而 cond 槽置 Nil] + handle (eff params) 尾槽可变参数帧散布纪律[pair(acc, tail) 追加元素非包裹列表——tp_8/tp_9 直读槽位 8/9] + resume 右括号消费[oracle expect(CloseParen) 先于逗号] + handle 臂逗号折叠共享化[tp_handle_arm_fold] + match (pattern . real_acc) 取 rest 非 tp_2[单臂形 car-of-nil] + pattern-paren 五字段帧[四字段帧 tp_5 越界] + pattern-paren 逗号续元缺推帧[自旋] + 元组模式三元素拒绝计数 >=2[oracle elements.len()==2 于逗点位]）+ 簇 C 拒绝面 decode 批（or-or/and-and 层 0/1 操作符集缺位 + tp_n_eq 单元素字节表 datum 需尾逗号[(61,) 列表 vs (61) 分组——int 裸值] + require 形消息文本表过度转义修正 + tk_e 对二字段 eof 记录的回退[oracle "end of input" 面] + 词法层拒绝 parity 分层[K20 单源——oracle lexer 拒绝 = 双引擎同键构造性成立]）+ **块帧单次进入纪律**（guarded push 与 step fresh 双 tp_enter = 每块 +1 深度泄漏——expander.ktf 6,444 位 257>256 实证；块进入权归 step 单点）+ harness 崩溃位点渲染（K182 分类于失败点——harness_run_failure 附 span；lexer_parity 同类路径共变）。
- **audit AU 族 10 案**（360→370 live · 46 节——39 live + 7 retired）：AU01 fn 头名前置序 / AU02 空源零记录 verdict / AU03 类型圆括表逗号环 + 尾逗号拒绝 / AU04 use-path 半冒号端字符串记录 / AU05 extern 类型源序 / AU06 短路操作符层 0/1 / AU07 单元素字节表 datum / AU08 do/let 折叠序 + 赋值语句 / AU09 handle 臂尾槽散布 + resume 右括号 / AU10 嵌套守卫单次进入（200 语句默认帽内）+ eof 二字段记录。守卫 TEST-3 共变（360→370 live + 474 总 + 头行字面量 + 族注释）。

## 验收

- 六命令（cargo clean 冷跑）：build 0e0w / check 0/0 / fmt 零 diff / clippy --all-targets -D warnings 零 / test --release 全绿 / doc 零新增警告。
- audit **370/370 live + 104 retired · 46 节**；curated twin 91/91（正 50 + 负 41——含三簇边界全清）+ selfhost 九源固定点（lexer/reader/expander/macro/infer/typecheck/compiler/target-lexer/target-parser——含孪生自身源最深自应用）全绿。
- 8 原语不变性第一百零一轮验证：零新原语/零新内建/零语法增改/零操作码面变更（纯前端孪生面）。S-expr 完全转化记录义务：本轮新增转化面 ×1（target-parser.ktf = Rust target parser 的 kerf 语言完整转化——转化面累计九件 14,243 行 .ktf）；记录位 = 本文件 + bootstrap-completion-plan §4.2 刀 2 行 + stage0 §9.124。
- 下一入口：W-TGT-READ-TWIN 刀 3（读段自应用 + 稳态读链 SteadyTargetReaderChain + 组成链扩展 = C1 断链闭合）∥ W-JIT-METHOD-T1 tier-1 刀 1（TJ-3 基座就位）。

# kerf v0.98.0 — W-REC-DEPTH 刀 2：K162 可配置护栏 + r74/r85 括号退役（r137）

第一百三十七轮（r137 · Task 137）· SOP v15.3 §21.12-28 自举完备优先 · 自举完备总规划 §4.1 刀 2 行（bootstrap-completion-plan.md v1.2——C3 递归深度通解的收尾刀）· 单刀整轮（137-b parser 孪生独立排期 r138——§4 MUV 边界：孪生体量 ~3,500-4,000 行 .ktf 单刀完整交付，避免降级交付违例）。

## 本轮交付

- **四层帽 K162 范围化全链（C3 收尾）**：原则 58 四层帽谱系（reader NESTING_LIMIT 256 / expander EXPANSION_LIMIT 512 / compiler COMPILE_DEPTH_LIMIT 1024 / pkg RESOLUTION_DEPTH_LIMIT 512）全部参数化——每层新增 `*_with_limit` 显式入口（read_program_with_limit / read_target_program_with_limit / parse_program_with_limit / expand_program_with_limit / expand_program_with_injected_and_limit / compile_with_limit / compile_program_with_limit / resolve_with_limit）+ 既有公共 API 逐位不变（默认常量委托——黄金行为零漂移）+ ExpandCtx 手写 Default（= new 保守默认——derive 的全零结构将使 limit=0 拒绝一切 enter，语义破坏修复于当轮）+ 编译器错误载荷随配置 cap 共变（DepthExceeded depth = limit+1）。
- **driver DepthLimits 面（env 单源消费）**：`DepthLimits { reader_nesting, expansion, compile_depth }`（Default = 三 crate 常量钉扎）+ `from_env()`（KERF_READER_NESTING_LIMIT / KERF_EXPANSION_LIMIT / KERF_COMPILE_DEPTH_LIMIT 三键——缺省回落默认；非法值[非正整数/非 Unicode]硬错误 fail-closed——「静默忽略的护栏覆盖是谎言」）+ `Session::with_limits`（limits 挂 Session——进程级配置归属位；库面零隐式 env 读取，测试确定性免疫环境变量）+ `ParsedProgram.limits` 字段（程序自带护栏——check/run 无需 session）+ CLI 三命令位（check/emit-c/run 族）session_from_env 接线（错误退出码 2）+ kp 工具 KERF_PKG_RESOLVE_DEPTH_LIMIT 独立单源。REPL 维持默认帽（交互源天然浅——设计边界如实登记）。
- **r74/r85 VM-only 括号全链退役（C3 第三验收腿）**：eval 堆激活栈化（刀 1）使「evaluator envelope is finite」前提失效——fixpoint 两处 step-3（fixpoint_selfhost_compiler_target / fixpoint_products_target 的 C_t(C_t(S'))）从 ktf_compile_rich_vm 切换 ktf_compile_rich 双引擎面（vm_text == eval_text 断言新增——自应用数据逐元素递归预算内实测通过）；composed_target_chain junction-1 VM-bracket 面（composed_target_chain_parity_vm）+ reader_parity_full_target_feed_vm + drive_full_target_vm + drive_full_face 的 dual 分支 + ktf_compile_rich_vm + vm_harness_failure_target + decode_verdict_vm 全链删除（零 dead code 留守）；语料 sweep 的 harness-limit 分类从「切 VM 括号重验」改为硬失败回归守卫（「刀 1 后任何 corpus case 触达 harness-limit 分类 = 回归」）；bnd-006 255 深嵌套族双引擎直接 matched + engines_agree 严格断言（原宽松「matched or classified」断言收紧）；audit AE8 改双引擎 + LA-7 探针测试改双引擎（vm/eval 一致断言强化）。
- **测试面 +13（1573→1586）**：rec_depth_window_tests 新族（正 6：reader/target/expander/compiler/pkg with_limit 深源 + session 提帽集成[600 深 if 链经 raised session 读取展开 + 默认 session 拒绝]；负 7：默认帽黄金维持[257 拒绝载荷钉扎] + 零帽 fail-closed + expander 紧帽边界 + compiler 紧帽载荷 + DepthLimits 常量钉扎 + Session 默认 = 常量 + env 清洁解析）+ composed_target_chain_tests 三面改造（sweep panic 化 + budget_bracketed 退役 + the_deep_nesting_family_rides_the_dual_face 更名严格化）+ target_fixpoint_tests LA-7 双引擎化。
- **audit AT 族 10 案（350→360 live · 44→45 节）**：AT01-AT10（四层 with_limit 深源审计 + 默认黄金 + target 孪生面 + expander 紧帽 + compiler 默认拒载荷 + pkg 深链紧帽/提帽双臂 + DepthLimits 常量 + env 清洁 + 退化帽 fail-closed + **AT10 fixpoint 无括号全跑**[C_t(S') + C_t(C_t(S')) + 执行产物 fixpoint_holds + selfapplied_consts > self_consts 烘焙输入断言]）。
- **r136 遗漏缺陷当轮清偿（§20 同类路径审查）**：ds08 工作区版本黄金钉扎停留在 0.96.0（r136 金链锁步 v0.97.0 时遗漏该钉扎位——GATE 1 跑在锁步前的顺序窗口）；同类排查 = WORKSPACE_VERSION 字面量钉扎全树仅 ds08 一处（其余为 env!("CARGO_PKG_VERSION") 动态对比自适应）；本轮随 v0.98.0 锁步修正 + 遗漏机制如实登记。

## 验收

- 六命令（OBS 口径 --jobs 2 / --test-threads 1 / RUST_MIN_STACK=268435456）：build 0e0w / check 0/0 / fmt 零 diff / clippy --all-targets -D warnings 零 / test --release **1586:0:4**（基线 1573 + 新族 13——恰中声明阈值）/ doc 零新增警告（cargo#6313 既有唯一——output filename collision 先例）。
- audit **360/360 live + 104 retired · 45 节**；gate B 全语料逐位 + fixpoint 自复现维持 + fixpoint 无括号（双引擎全相位）。
- **C3 递归深度通解终态宣告**：深非尾递归仅受内存约束（10^5 默认栈——刀 1）✓ + 深尾递归恒定栈高（10^5——刀 1）✓ + fixpoint 无括号自建（双引擎——本轮）✓ + 读/析层护栏范围化（四层 with_limit + env——本轮）✓；四层帽谱系文档对账（原则 58：默认保留 + 可配置护栏——bootstrap-completion-plan §4.1 刀 2 行刷新）。
- 8 原语不变性第一百轮验证：零新原语/零新内建/零语法增改；零操作码面变更（护栏参数化 + 括号退役轮——纯 API/测试/harness 面）；S-expr 转化记录义务：零新 S-expr→目标语言转化面（API 参数化轮）。
- 下一入口：**W-TGT-READ-TWIN 刀 2（target Pratt parser 孪生——r138 单刀整轮，G1 推进 2/3）∥ W-JIT-METHOD-T1 tier-1（TJ-3 基座已就位）**。

# kerf v0.97.0 — W-REC-DEPTH 刀 1 ∥ W-TGT-READ-TWIN 刀 1：自举阶梯双首刀（r136）

第一百三十六轮（r136 · Task 136）· SOP v15.3 §21.12-28 自举完备优先 · 自举完备总规划 §3 序 1/2 的双首刀轮（bootstrap-completion-plan.md v1.0 排期——W-REC-DEPTH 共享基座刀 1 ∥ W-TGT-READ-TWIN 刀 1 并行排期零交集）· 第十九次回退恢复轮（本地 Pack B 双包恢复——按用户指令不访问 GitHub）。

## 本轮交付

- **W-REC-DEPTH 刀 1——eval 引擎堆激活栈化（G2 通解基座 · K160 执行化）**：kerf-runtime eval.rs 全量重写为显式激活栈机器（Kont 延续帧族：Arg/Callee/If/Store/Bind/LetOut/EffectArg/Install/Uninstall/Frame——每一闭包应用一帧，双守卫对[entry/site]镜像旧 Rust 递归的 temp 根保护纪律）+ SExpr 共享树表示（Rc-per-node 镜像 CoreExpr——闭包体创建时一次性转换，替代旧深拷贝同代价；延续帧持节点句柄零深拷贝）+ EVAL_DEPTH_LIMIT 2048 固定帽解除为内存预算治理（每闭包入口一次 reserve——与 VM push_frame 逐位同账；DEFAULT_BUDGET 8Mi 统一两引擎深度界）+ 错误路径 Rust-unwind 镜像（逐帧恢复/env 截断/handler 弹出/temp 截断——`?`-walk 泄漏语义逐位镜像不改进）+ RuntimeError::EvalDepthExceeded 退役注记（变体保留为历史诊断面——错误注册表渲染测试钉扎；零构造路径）。**验收对**：10^5 非尾递归默认线程栈（8 MiB）实测通过（旧原生递归 2048 即需 64 MiB 深栈线程——恒定宿主栈高证明）+ 10^5 尾形同过 + 双引擎 10^5 深度 parity + 预算 fail-closed + 深帧错误 unwind 状态一致 + 深度下 GC 根完备（紧预算丢弃步 collect-then-retry 存活）+ 深度下 handler/闭包捕获正确 + 深度下 span 存活 + 双跑确定性（值与 cycle 数逐位）。
- **W-TGT-READ-TWIN 刀 1——target-skin lexer 孪生（G1 断链首刀 · 第八 selfhost 孪生）**：selfhost/v1/target-lexer.ktf（1,065 行——crates/kerf-reader/src/target/lexer.rs 的逐决策镜像：4 字节 trivia/嵌套块注释/24 关键字节表/true-false/ASCII 标识域/0x-0o-0b-十进制四族数文法[点强制 float + 指数消费规则 + `1._5`/`1.5e` 边界]/7 转义 + \u{1..6hex} 字符串[代理对与超平面拒绝]/maximal munch 三级操作符/非 ASCII unexpected-char；整数值在孪生内计算——负域累加器 + per-radix（位数,字典序）阈值守卫使检查算术永不陷阱，i64/u64 双界分类逐位；float/str 值 K20 永久宿主侧——孪生只判文法）+ target_lexer_parity.rs 三向 parity harness（twin-vm == twin-eval == oracle；49 案例族：19 正向 + 30 拒绝；ident 皮肤映射经 oracle 自有 skin_symbol 单源派生）+ kerf-reader target 面开放（TgtToken/TgtKind/lex_target/skin_symbol 公开——S-expr lex 公开先例镜像）。**自源案例**：孪生读取自身 .ktf 文本三向一致（读段自应用种子——G1 闭合面）；selfhost 七件全 corpus 三向 sweep（infer.ktf 17,268 token 逐位）。
- **audit 两新节（330→350 live · 42→44 节）**：AR 族 10 案（W-REC-DEPTH 审计面——验收对全腿 + 双引擎深度 parity + 预算唯一界 R8 消息 + unwind 状态机 + 深度 GC 根完备 + 深度 handler/捕获/span + 双跑确定性 + 分配记账）+ AS 族 10 案（孪生审计面——全案例三向 sweep + 词面 dump 锚 + 孪生内整数值锚 + float K20 边界 + 拒绝锚 + 自源 + selfhost corpus + 皮肤映射轴 + trivia-only + 最大源 token 计数消费）。
- **测试面 +12（1561→1573）**：eval.rs 内族 5 新（深非尾/深尾形/预算 fail-closed/深度 GC/深帧错误 unwind——深度帽测试与 R8 深度消息腿退役重写为预算腿）+ limits_ladder 重写（eval 档退役为预算治理档——终止论证强化覆盖双引擎）+ runtime_seed 深度 parity 重写（双引擎 10^5 双形——默认栈即证明）+ 孪生测试族 7（curated/selfhost 内存/disk 拒绝族/锚渲染/token 计数/自源 fn 头）+ test_infra 审计清点 350 锁步 + selfhost 格式守卫第八件登记。
- **第十九次回退恢复轮**：/home/z/kerf 整树再次丢失 → 本地 download/ 双包恢复（Pack B 984 entries sha256 416a43973ce15de4... 编排态工作树原件——按用户指令「无需访问 GitHub 直接使用本地最新环境」）+ git 基线重建（recovery baseline 016696f）+ Rust 1.99.0 工具链重装 + GATE 1 七命令零漂移复验（1561:0:4 + audit 330/330·42 节逐位）后开工。

## 验收

- 六命令（OBS 口径 --jobs 2 / --test-threads 1 / RUST_MIN_STACK=268435456 + ulimit -s 131072，cargo clean 冷跑）：build 0e0w（17.62s 全量）/ check 0/0 / fmt 零 diff / clippy --all-targets -D warnings 零 / test --release **1573:0:4** / doc 零新增警告（cargo#6313 既有唯一）。
- audit **350/350 live + 104 retired · 44 节**；gate B 全语料逐位 + fixpoint 自复现维持（1561 存量全绿即证）。
- 8 原语不变性第九十九轮验证：零新原语/零新内建/零语法增改；零操作码面变更（刀 1 纯执行链与前端孪生面）；S-expr 转化记录义务：本轮新增 S-expr→目标语言转化面 ×1（target-lexer.ktf = Rust target lexer 的 kerf 语言完整转化——登记于本文件与 bootstrap-completion-plan §4.2）。
- 下一入口：W-REC-DEPTH 刀 2（四层帽显式栈化/可配置护栏 K162）∥ W-TGT-READ-TWIN 刀 2（target Pratt parser 孪生）∥ W-JIT-METHOD-T1 tier-1（构建于刀 1 基座之上——TJ-3）。

# kerf v0.96.0 — W-JIT-METHOD-T1 开窗：自举完备总规划 + tier-0.5 收尾首刀（r135）

第一百三十五轮（r135 · Task 135）· SOP v15.3 §21.12-28 自举完备优先 · W-JIT-METHOD-T1 方法 JIT 窗开窗轮（上游裁定 = r134 三触发器全命中 + w3.7-jit-window.md §4.3-2；自 r134 闭合态续作）· 用户常设指令①「完整完全自举优先」+「任意递归深度纳入规划」双指令承载轮。

## 本轮交付

- **自举完备总规划**（bootstrap-completion-plan.md v1.0 新建——用户首要指令的规划单源）：完成标准操作化 C1-C4（§21.12-28③「完全脱离宿主语言」的工程判据：C1 kerf 源的 kerf 编译链 / C2 生产位切换 K159 不动点管线 / C3 递归深度通解 / C4 语言自我推进面）+ 现状缺口地图 G1-G6（G1 目标皮肤读链孪生不存在 = C1 结构性断链 / G2 任意递归深度未通解 / G3 T-a 性能带 / G4 生产位 / G5 PM 自举 / G6 eval 退役）+ 五窗序列粗粒度排序（§21.12-28① 逐窗可审计理由）+ 前置窗细粒度 MUV（W-JIT-METHOD-T1 五刀 / W-TGT-READ-TWIN 三刀）+ T-a 切换窗五步（K159 操作化）+ 测量计划（稳态摊销口径 + K140 带诚实预期）+ 每轮复核义务（指令⑨载体）。
- **窗内第一议题裁定 TJ-1..TJ-5**（w-jit-method-t1-window.md v1.0 新建）：TJ-1 首刀 = tier-0.5 收尾（LLC 复制对融合——第三杠杆 20% 在册数据消费；K154 阶梯序 + r133/r134 形制先例 + MUV 边界单轮完整）；TJ-2 余量对（含调用/控制流成分）归 tier-1 方法级吸收（K157 重定义：方法级编译自然吸收块内全部相邻对——逐对融合是低阶子集）；TJ-3 共享基座耦合（tier-1 构建于 W-REC-DEPTH 堆激活栈之上——K160 归一 + 重复施工警戒 + r134 fixpoint 爆深度实证）；TJ-4 tier-1 = 去分派方法执行层（K153+K157——零 codegen、确定性构造、验收对照 tier-0.5 收尾基线）；TJ-5 T-a 组合面诚实预期（本窗出口 = 三触发器清账；T-a <10× 需组合面——本窗不承诺）。
- **登记窗两件新增**（tech-debt-register r135 检视）：W-REC-DEPTH（任意递归深度通解——用户显式指令 + G2 + TJ-3 依赖；排期 r136+ 前置刀）+ W-TGT-READ-TWIN（目标皮肤读链孪生——G1 结构缺口；与 JIT 窗 r136+ 阶段并行排期零交集）。
- **W-PKG-SELFHOST 触发器反冻结改写**（用户「禁止冻结」指令 × r115 设计的冲突裁定）：前置二「功能冻结」→「manifest 子集实证稳定」（micro-TOML 六形 + semver 边界最近 N≥5 轮零变更 + pkg 语料回归全绿——可机检判据替代政策性冻结；§12 判据可审计优于口号）。
- **知识层 K157-K162 六新锚**（stage0.md §9.121 + tool-results/r135-search/ 七件 + REPORT.md）：K157 Sparkplug 重定义（价值在分派消除非原生 codegen）/ K158 零 codegen 加速家族（closure chain + threaded code 菜单）/ K159 生产位切换 = 种子→全量→自重建不动点（不动点 = 验证门非构建步骤）/ K160 任意递归深度 = 激活记录堆化归一（与 closure chain 共享 VM 自有激活栈——单一机制规划）/ K161 PM 自举与编译器自举解耦（opam 先例）/ K162 读析层深度护栏业界常态（范围化裁定）。
- **tier-0.5 收尾首刀 LLC 融合全链**（w-jit-method-t1-window.md §3 MUV 135-b）：opcode 26→27（`load-local-const {a: local slot, b: const index}`——pops 0/pushes 2，Dup pushes=2 先例；ordinal 26 尾插 census 键稳定扩展；「about 35」裕量 8）+ VM 双压臂 + verify Pass 1 双边界（槽位/常量池）+ depth DAG pushes=2 + .krf 往返（kebab `load-local-const`）+ C 后端复合发射（k_local_load + 常量压栈）+ compile.rs args 环视特判（arg[i] Var 解析局部 ∧ arg[i+1] Literal → 单指令双压——结构安全论证：args 列内部位永非分支头，消除位免 fusable 分类器；intern 序保持——Var 零 intern）+ compiler.ktf 孪生同步（gate B 逐位 + fixpoint 自复现）。
- **守卫再生成 + 新族 + audit**：jit_window census 锚再推导（(load-local,push-const) 对消失 + load-local-const 计数入锚）+ 快照黄金族再生成（含 (局部, 常量) 相邻实参形态程序）+ method_jit_window_tests 新族（正 2/负 6 = 1:3——融合/非融合同值双臂[集成验证用例] + 跳转目标落位融合指令 + verify 双边界 + .krf 往返 + C 混合发射 + 孪生篡改 gate B drift + census 前提）+ audit AQ 族 10 案（320→330 live · 42 节）。
- **B 轴复画像三跑（诚实账）**：fib-25 指令数 2,427,852 → **1,942,283（-20.0% 精确兑现——485,569 复制对逐位消除）**；中位 **63.601/63.816/63.466ms = +3% 回退**（r134 预估 ~12ms 节余未兑现——消除的是最廉价指令，剩余混合均值成本上浮 25.35→32.75ns + 布局效应 ~3.4%；K129 纪律执行不投机微调）+ parity OK 全负载；**裁定 = tier-0.5 融合层墙时收益已尽，负担全部移交 tier-1**（方法级编译吸收全部逐指令分派——LLC 的 -20% 指令数在 tier-1 内兑现）——三触发器维持命中，tier-1 必要性强化实证（w-jit-method-t1-window.md §3.1 单源）。
- **孪生潜伏缺陷顺带清偿（§20 同类路径审查）**：cp_emit 栈下溢载荷 span 三元组错位析取（cp_2/cp_3 取得 end/gen 替代 s/e——该路径在良构产物上从未触发，N6 表效篡改探针首达即暴露）——修正为 first/cp_2 对齐 Rust rebuild 的 make_span 契约；错误轴载荷修复非行为面变更（gate B/fixpoint 零影响——错误轴产物不含良构产物比对面）。

## 验收

- 六命令（OBS 口径 --jobs 2 / --test-threads 1 / RUST_MIN_STACK=268435456 + ulimit -s 131072）：build 0e0w / check 0/0 / fmt 零 diff / clippy -D warnings 零 / test --release 全绿（基线 1554 + 新族与再生成差量）/ doc 零新增警告（cargo#6313 既有先例唯一）。
- audit 330/330 live + 104 retired · 42 节；gate B 全语料逐位 + fixpoint 自复现维持。
- 8 原语不变性第九十八轮验证：零新原语/零新内建/零语法增改；操作码面 26→27（VM 内部编码扩展——SI-2/FA-2 先例族）；S-expr 转化记录义务：零新 S-expr→目标语言转化面（编译器发射面优化轮）。
- 下一入口：W-REC-DEPTH 共享基座刀 1（r136+）∥ W-TGT-READ-TWIN 刀 1（并行排位零交集）——自举阶梯单源 = bootstrap-completion-plan.md §3 序。

//! The external-name face: names bound outside any module `define`.
//!
//! Single-source discipline (stage-1-plan §4): this crate never
//! copies the `STAGE0_GLOBALS` list. Callers construct
//! [`Externals`] from the authoritative sources —
//! `kerf_expander::STAGE0_GLOBALS` (the expansion-time resolution
//! table) plus `kerf_vm::Builtin::ALL` (name + arity triples) — at the
//! three consumption sites (root integration tests, the audit
//! example, the 1.1 driver wiring).
//!
//! Identity discipline (§9.68 CHK-6): entries ride the single
//! symbol pool (§9.52) — construction interns the caller's text
//! once, resolution compares pool identities. The construction
//! face keeps `&str` inputs (callers hold authoritative text); the
//! resolution face takes `&Symbol` (every caller inside the crate
//! already holds the pool entry of the referenced `Var`).

use kerf_span::Symbol;

/// Name-to-optional-arity table for externally bound names.
///
/// Resolution is three-valued, mirroring what the caller knows:
/// `Some(Some(n))` — the name is external and takes `n` arguments
/// (a builtin with a fixed arity);
/// `Some(None)` — the name is external with unknown arity;
/// `None` — the name is not external at all.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct Externals {
    entries: Vec<(Symbol, Option<u32>)>,
}

/// Intern one external name. External names come from the
/// authoritative sources (`STAGE0_GLOBALS` / `Builtin::ALL`), all of
/// which pass the symbol floor — a floor-rejected name could never
/// match any `Var` (those are validated `Symbol`s by construction),
/// so failing fast on the caller contract is the honest direction
/// (report-over-silence; the `builtin_symbol` seeding face uses the
/// same discipline — §9.67 NB-5).
fn external_symbol(text: &str) -> Symbol {
    Symbol::new(text).expect("external names come from authoritative sources")
}

impl Externals {
    /// The empty table — nothing is external.
    pub const fn empty() -> Self {
        Self {
            entries: Vec::new(),
        }
    }

    /// Names only — every entry resolves as external with unknown
    /// arity (the R2c conservative skip case).
    pub fn from_names<'a>(names: impl IntoIterator<Item = &'a str>) -> Self {
        Self {
            entries: names
                .into_iter()
                .map(|n| (external_symbol(n), None))
                .collect(),
        }
    }

    /// Names with optional arities — `(name, Some(arity))` from
    /// `Builtin::ALL` triples, or `(name, None)` when only existence
    /// is known. Later entries win (last-binding-wins, mirroring the
    /// global-store overwrite order the checker mirrors elsewhere).
    pub fn from_named_arities<'a>(
        entries: impl IntoIterator<Item = (&'a str, Option<u32>)>,
    ) -> Self {
        Self {
            entries: entries
                .into_iter()
                .map(|(n, a)| (external_symbol(n), a))
                .collect(),
        }
    }

    /// Three-valued resolution (see the type docs). The lookup is
    /// an identity comparison against pool entries — no text, no
    /// re-interning (the §9.52 single-pool invariant on this face).
    pub fn resolve(&self, name: &Symbol) -> Option<Option<u32>> {
        // Reverse scan: the nearest binding wins (the same
        // last-wins order as a global store overwrite).
        self.entries
            .iter()
            .rev()
            .find(|(n, _)| n == name)
            .map(|(_, a)| *a)
    }

    /// Insert one entry (W-3.2): program extern declarations are a
    /// third authoritative source after `STAGE0_GLOBALS` and
    /// `Builtin::ALL` — the driver's construction extends the table
    /// with them so call-site arity checking covers extern calls
    /// through the same three-valued face.
    pub fn insert(&mut self, name: &Symbol, arity: Option<u32>) {
        // Last-binding-wins, mirroring `from_named_arities`.
        self.entries.retain(|(n, _)| n != name);
        self.entries.push((name.clone(), arity));
    }

    /// The number of registered entries (deduplicated by resolution
    /// order — the audit face uses this to assert the full builtin
    /// surface made it in).
    pub fn len(&self) -> usize {
        self.entries.len()
    }

    /// Whether the table is empty.
    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }
}

#[cfg(test)]
mod tests {
    //! Externals-face tests (FP2): three-state resolution, constructor
    //! shapes, last-binding-wins order, and the single-pool identity
    //! discipline (§9.68 CHK-6).

    use super::*;

    /// Test-side interning helper (validated constructors only).
    fn sym(text: &str) -> Symbol {
        Symbol::new(text).expect("test fixture name passes the floor")
    }

    #[test]
    fn empty_resolves_nothing() {
        let e = Externals::empty();
        assert!(e.is_empty());
        assert_eq!(e.resolve(&sym("car")), None);
    }

    #[test]
    fn from_names_resolves_existence_without_arity() {
        let e = Externals::from_names(["car", "cdr"]);
        assert_eq!(e.resolve(&sym("car")), Some(None));
        assert_eq!(e.resolve(&sym("cdr")), Some(None));
        assert_eq!(e.resolve(&sym("cons")), None);
        assert_eq!(e.len(), 2);
    }

    #[test]
    fn from_named_arities_resolves_known_arities() {
        let e =
            Externals::from_named_arities([("+", Some(2)), ("car", Some(1)), ("mystery", None)]);
        assert_eq!(e.resolve(&sym("+")), Some(Some(2)));
        assert_eq!(e.resolve(&sym("car")), Some(Some(1)));
        assert_eq!(e.resolve(&sym("mystery")), Some(None));
        assert_eq!(e.resolve(&sym("nope")), None);
    }

    #[test]
    fn later_entries_win_on_duplicate_names() {
        let e = Externals::from_named_arities([("f", Some(1)), ("f", Some(2))]);
        assert_eq!(e.resolve(&sym("f")), Some(Some(2)));
    }

    #[test]
    fn default_is_empty_like_empty() {
        let d = Externals::default();
        assert!(d.is_empty());
        assert_eq!(d, Externals::empty());
    }

    #[test]
    fn externals_ride_the_single_pool() {
        // §9.68 CHK-6 guard: constructed entries are live pool
        // members — an independently interned Symbol of the same
        // text resolves through identity, not text comparison (the
        // §9.52 single-pool invariant pinned on the externals face).
        let e = Externals::from_named_arities([("+", Some(2)), ("car", Some(1))]);
        let plus_again = Symbol::new("+").expect("text interns");
        assert_eq!(e.resolve(&plus_again), Some(Some(2)));
        // A differently built entry of the same text (format! path)
        // is the same identity — intern-once, not text-match.
        let car_again = Symbol::new(&format!("c{}", "ar")).expect("text interns");
        assert_eq!(e.resolve(&car_again), Some(Some(1)));
        // A miss never pollutes the table or the pool path.
        assert_eq!(e.resolve(&sym("nope")), None);
        assert_eq!(e.len(), 2);
    }
}

//! The E0xxx diagnostic registry — Stage 1 activation (stage-1-plan §4).
//!
//! The variant-level code scheme was registered in Stage 0 (driver
//! `diagnostic.rs` header note: "the E0xxx scheme is the Stage 1+
//! diagnostics agenda, registered"); this module is its activation for
//! the type-checking domain. The driver's stage-level
//! `DiagnosticCode` remains the pipeline-face scheme — the two are
//! joined at the 1.1 driver wiring, not here.
//!
//! Message shape follows the Rust compiler conventions (SOP §10.5 /
//! R8): lowercase start, no trailing period, payloads in backticks —
//! and stays same-source same-translation with the RuntimeError family
//! (the single-source dictionary): the R2 wording mirrors
//! `RuntimeError::ArityMismatch`, R4/R7 mirror the `call callee`
//! type-mismatch family, R6 mirrors `UnhandledEffect`.

use kerf_span::{Span, Symbol};

/// One conservative-static diagnostic code (stage-1-plan §3 table).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum TypeCode {
    /// R1 — a variable reference that resolves nowhere (E0001).
    UnboundVariable,
    /// R2 — application arity mismatch on a statically known callee (E0002).
    ArityMismatch,
    /// R3 — an `if` condition that is a non-boolean literal (E0003).
    NonBooleanCondition,
    /// R4 — an application whose callee is a literal (E0004).
    NonCallableCallee,
    /// R5 — handler arity mismatch on a routed top-level perform (E0005).
    HandlerArityMismatch,
    /// R6 — a top-level perform with no enclosing handler (E0006).
    TopLevelUnhandledPerform,
    /// R7 — a routed handler that is a literal value (E0007).
    NonCallableHandler,
    /// R8 — a surprising assignment target (E0008, warning severity).
    AssignmentTargetSurprise,
    /// A definite unification failure in the HM inference engine
    /// (E0009, Stage 1.3 — stage0.md §9.44.4).
    TypeMismatch,
    /// The occurs check rejected a cyclic (infinite) type (E0010,
    /// Stage 1.3).
    RecursiveType,
    /// The inference depth budget was exhausted for one define
    /// (E0011, Stage 1.3 — **warning** severity: a checker-limit
    /// disclosure, never a program error; deep-but-legal programs
    /// must keep running).
    InferenceBudgetExceeded,
    /// R-LA7 — an assignment targets a variable the enclosing Fn
    /// scope binds (E0012, Stage 2.1 LA-7): captures are immutable in
    /// the first-cut subset, so the store is a definite error (the
    /// compiler rejects the same construct on its side — the
    /// boundary has two faces, one code).
    AssignToCaptured,
}

impl TypeCode {
    /// The stable registry string (`"E0001"`..=`"E0012"`).
    pub fn as_str(&self) -> &'static str {
        match self {
            TypeCode::UnboundVariable => "E0001",
            TypeCode::ArityMismatch => "E0002",
            TypeCode::NonBooleanCondition => "E0003",
            TypeCode::NonCallableCallee => "E0004",
            TypeCode::HandlerArityMismatch => "E0005",
            TypeCode::TopLevelUnhandledPerform => "E0006",
            TypeCode::NonCallableHandler => "E0007",
            TypeCode::AssignmentTargetSurprise => "E0008",
            TypeCode::TypeMismatch => "E0009",
            TypeCode::RecursiveType => "E0010",
            TypeCode::InferenceBudgetExceeded => "E0011",
            TypeCode::AssignToCaptured => "E0012",
        }
    }

    /// The registry-string lookup (the inverse of [`Self::as_str`]):
    /// the step-④ check-segment production position's rebuild face —
    /// the twin verdict carries the code as its registry string, and
    /// the rebuild maps it back onto this enum (the single source of
    /// the registry — an unknown string is `None`, never a guess).
    pub fn from_registry_str(raw: &str) -> Option<Self> {
        Some(match raw {
            "E0001" => TypeCode::UnboundVariable,
            "E0002" => TypeCode::ArityMismatch,
            "E0003" => TypeCode::NonBooleanCondition,
            "E0004" => TypeCode::NonCallableCallee,
            "E0005" => TypeCode::HandlerArityMismatch,
            "E0006" => TypeCode::TopLevelUnhandledPerform,
            "E0007" => TypeCode::NonCallableHandler,
            "E0008" => TypeCode::AssignmentTargetSurprise,
            "E0009" => TypeCode::TypeMismatch,
            "E0010" => TypeCode::RecursiveType,
            "E0011" => TypeCode::InferenceBudgetExceeded,
            "E0012" => TypeCode::AssignToCaptured,
            _ => return None,
        })
    }
}

/// How severe a checker diagnostic is — the checker-side subset of the
/// §8.7 contract (the driver's four-level face is joined at the 1.1
/// wiring). R1-R7 are definite errors; R8 is the first `Warning`
/// producer in the workspace (legal semantics, likely bug —
/// report-over-silence at the non-blocking level).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Severity {
    /// A definite error — the program cannot behave as written.
    Error,
    /// A surprising-but-legal construct — surfaced, never blocking.
    Warning,
}

impl std::fmt::Display for Severity {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let s = match self {
            Severity::Error => "error",
            Severity::Warning => "warning",
        };
        f.write_str(s)
    }
}

/// One checker finding: code + severity + byte-precise span + message.
///
/// The message is pre-rendered at construction (R8 shape asserted in
/// tests) so the 1.1 driver wiring consumes a ready string with zero
/// rendering drift.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct TypeDiagnostic {
    /// The registry code (E0001-E0012 — E0012 = AssignToCaptured,
    /// the Stage 2.1 LA-7 addition).
    pub code: TypeCode,
    /// Error (R1-R7) or warning (R8).
    pub severity: Severity,
    /// The byte-precise position of the offending node.
    pub span: Span,
    /// The rendered message (R8 conventions, single-source dictionary).
    pub message: String,
    /// The interned identifiers the message names (r109 F2 — the
    /// skin-awareness subject set): the driver re-spells exactly
    /// these subjects through the skin dictionary on the target
    /// face (a pure presentation pass — the message itself stays
    /// the single-source canonical rendering; SKIN-DIAG-2). Empty
    /// for messages that name no user identifier (type words and
    /// budget numbers render identically on both faces).
    pub subjects: Vec<Symbol>,
}

impl TypeDiagnostic {
    /// Construct with a pre-rendered message that names no user
    /// identifier.
    pub fn new(code: TypeCode, severity: Severity, span: Span, message: String) -> Self {
        Self {
            code,
            severity,
            span,
            message,
            subjects: Vec::new(),
        }
    }

    /// Construct with a pre-rendered message that names `subjects`
    /// (the message must render each exactly as `` `{subject}` `` —
    /// the backticked canonical spelling — so the driver's
    /// subject-token re-spelling finds it).
    pub fn with_subjects(
        code: TypeCode,
        severity: Severity,
        span: Span,
        message: String,
        subjects: Vec<Symbol>,
    ) -> Self {
        Self {
            code,
            severity,
            span,
            message,
            subjects,
        }
    }
}

#[cfg(test)]
mod tests {
    //! Registry-face tests (FP1): stable code strings, severity
    //! rendering, diagnostic shape, and the R8 message-form invariants.

    use super::*;
    use kerf_span::{ByteOffset, ExpansionId, FileId};

    fn sp(a: u32, b: u32) -> Span {
        Span::new(FileId(0), ByteOffset(a), ByteOffset(b), ExpansionId::ROOT)
            .expect("test span is ordered")
    }

    #[test]
    fn registry_strings_are_stable_e0001_through_e0012() {
        // r106 FIX-10: the pinned registry includes E0012
        // (AssignToCaptured, the Stage 2.1 LA-7 addition) — the test
        // name and body had lagged at E0011.
        assert_eq!(TypeCode::UnboundVariable.as_str(), "E0001");
        assert_eq!(TypeCode::ArityMismatch.as_str(), "E0002");
        assert_eq!(TypeCode::NonBooleanCondition.as_str(), "E0003");
        assert_eq!(TypeCode::NonCallableCallee.as_str(), "E0004");
        assert_eq!(TypeCode::HandlerArityMismatch.as_str(), "E0005");
        assert_eq!(TypeCode::TopLevelUnhandledPerform.as_str(), "E0006");
        assert_eq!(TypeCode::NonCallableHandler.as_str(), "E0007");
        assert_eq!(TypeCode::AssignmentTargetSurprise.as_str(), "E0008");
        assert_eq!(TypeCode::TypeMismatch.as_str(), "E0009");
        assert_eq!(TypeCode::RecursiveType.as_str(), "E0010");
        assert_eq!(TypeCode::InferenceBudgetExceeded.as_str(), "E0011");
        assert_eq!(TypeCode::AssignToCaptured.as_str(), "E0012");
    }

    #[test]
    fn registry_codes_are_pairwise_distinct() {
        let all = [
            TypeCode::UnboundVariable,
            TypeCode::ArityMismatch,
            TypeCode::NonBooleanCondition,
            TypeCode::NonCallableCallee,
            TypeCode::HandlerArityMismatch,
            TypeCode::TopLevelUnhandledPerform,
            TypeCode::NonCallableHandler,
            TypeCode::AssignmentTargetSurprise,
            TypeCode::TypeMismatch,
            TypeCode::RecursiveType,
            TypeCode::InferenceBudgetExceeded,
        ];
        for (i, a) in all.iter().enumerate() {
            for b in &all[i + 1..] {
                assert_ne!(a.as_str(), b.as_str(), "distinct codes required");
            }
        }
    }

    #[test]
    fn registry_lookup_round_trips_and_rejects_unknown() {
        // The step-④ check-segment rebuild face: every registry
        // string maps back onto its enum member, and anything else
        // is a loud None (never a guess).
        let all = [
            TypeCode::UnboundVariable,
            TypeCode::ArityMismatch,
            TypeCode::NonBooleanCondition,
            TypeCode::NonCallableCallee,
            TypeCode::HandlerArityMismatch,
            TypeCode::TopLevelUnhandledPerform,
            TypeCode::NonCallableHandler,
            TypeCode::AssignmentTargetSurprise,
            TypeCode::TypeMismatch,
            TypeCode::RecursiveType,
            TypeCode::InferenceBudgetExceeded,
            TypeCode::AssignToCaptured,
        ];
        for code in all {
            let text = code.as_str();
            assert_eq!(
                TypeCode::from_registry_str(text),
                Some(code),
                "`{text}` must round-trip"
            );
        }
        for bad in ["", "E0000", "E0013", "e0009", "E0009 ", "X1234"] {
            assert_eq!(
                TypeCode::from_registry_str(bad),
                None,
                "`{bad}` must not parse as a registry code"
            );
        }
    }

    #[test]
    fn severity_renders_lowercase_single_word() {
        assert_eq!(Severity::Error.to_string(), "error");
        assert_eq!(Severity::Warning.to_string(), "warning");
    }

    #[test]
    fn diagnostic_carries_all_four_fields() {
        let d = TypeDiagnostic::new(
            TypeCode::UnboundVariable,
            Severity::Error,
            sp(3, 7),
            "unbound variable `g`".to_owned(),
        );
        assert_eq!(d.code, TypeCode::UnboundVariable);
        assert_eq!(d.severity, Severity::Error);
        assert_eq!(d.span, sp(3, 7));
        assert_eq!(d.message, "unbound variable `g`");
    }
}

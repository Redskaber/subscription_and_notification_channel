//! CoreExpr: the frozen semantic-primitive expression ADT (Layer 4).
//!
//! Primitive enumeration is frozen (docs/develop/v0/stage-0/
//! 0.1-design-adjudications.md, TD-005): Fn / Apply / If / Var / Literal /
//! Assign / Let / Perform / Handle. Every variant carries a mandatory
//! `span` (TD-004; docs/stage0.md §8.6 — never `Option`, never a dummy).
//! The `do` surface form desugars into `Let` chains at expansion time
//! (plan sub-stage 0.4); `Let` bindings are sequential (let* semantics —
//! shadowing an earlier binding in the same form is legal by design).

use std::collections::HashSet;
use std::fmt;
use std::rc::Rc;

use crate::error::CoreError;
use kerf_span::Span;
use kerf_span::Symbol;

/// One `let` binding site: `name` bound to `value`, covering `span`.
///
/// The binding carries its own span (the name/binding position) in
/// addition to the value's span — diagnostics such as "unbound identifier"
/// must point at the binding site, not only at the value expression.
#[derive(Debug, Clone, PartialEq)]
pub struct Binding {
    pub span: Span,
    pub name: Symbol,
    pub value: CoreExpr,
}

impl Binding {
    /// Checked constructor from source-shaped text (0.4 expander
    /// contract): validates the name via [`Symbol::new`].
    pub fn new(span: Span, name: &str, value: CoreExpr) -> Result<Self, CoreError> {
        Ok(Self {
            span,
            name: Symbol::new(name)?,
            value,
        })
    }
}

/// One `handle` clause: `handler` installed for `effect`, at `span`.
///
/// Continuation semantics (single-shot / multi-shot, resumption types)
/// are a VM design item (plan sub-stage 0.6); this type freezes only the
/// data shape.
#[derive(Debug, Clone, PartialEq)]
pub struct HandlerClause {
    pub span: Span,
    pub effect: Symbol,
    pub handler: Box<CoreExpr>,
}

impl HandlerClause {
    /// Checked constructor from source-shaped text (0.4 expander
    /// contract): validates the effect name via [`Symbol::new`].
    pub fn new(span: Span, effect: &str, handler: CoreExpr) -> Result<Self, CoreError> {
        Ok(Self {
            span,
            effect: Symbol::new(effect)?,
            handler: Box::new(handler),
        })
    }
}

/// Literal values carried by [`CoreExpr::Literal`].
///
/// `Pair` supports quoted S-expression data (a quoted list reduces to
/// nested pairs ending in `Nil`), which the 0.3 reader will produce for
/// `(quote ...)` forms. `Unit`-style void is spelled `Nil` here, matching
/// the frozen §3.2 `literal_value` definition.
#[derive(Debug, Clone, PartialEq)]
pub enum LiteralValue {
    Int(i64),
    Float(f64),
    Bool(bool),
    /// §9.72 SYN-1: shared payload — the expander clones the reader's
    /// `Rc<str>` (pointer, not bytes); the compiler's constant pool and
    /// every runtime materialization clone the same allocation
    /// (K143/K146 — rustc `Symbol` chain / Lua string table).
    String(Rc<str>),
    Nil,
    Pair(Box<LiteralValue>, Box<LiteralValue>),
}

impl LiteralValue {
    /// Stable diagnostic name (lowercase, one word).
    pub fn kind_name(&self) -> &'static str {
        match self {
            LiteralValue::Int(_) => "int",
            LiteralValue::Float(_) => "float",
            LiteralValue::Bool(_) => "bool",
            LiteralValue::String(_) => "string",
            LiteralValue::Nil => "nil",
            LiteralValue::Pair(..) => "pair",
        }
    }

    /// Number of heap cells materializing this literal allocates
    /// (§9.69.3 EXC-1: the single source for the cell count both
    /// engines budget against — only `Pair` nodes allocate; scalars,
    /// strings, and `Nil` are inline `Value` data).
    pub fn pair_cells(&self) -> usize {
        // Iterative walk (the r145 production-position exposure): a
        // long proper list is LINEAR in cells — the byte-table
        // injection of a ~60 KB source is a ~60k-cell chain, and the
        // naive recursion overflows a default-size stack. The
        // verification harnesses ran this same walk inside
        // demand-allocated 768 MB stacks, masking the latent defect;
        // the production read position runs on any thread's stack,
        // so the walk itself must be stack-flat (§20 — the same-path
        // family fix: pair_cells / from_literal / the Box-drop glue).
        let mut cells = 0;
        let mut stack = vec![self];
        while let Some(node) = stack.pop() {
            if let LiteralValue::Pair(a, b) = node {
                cells += 1;
                stack.push(a);
                stack.push(b);
            }
        }
        cells
    }
}

impl fmt::Display for LiteralValue {
    /// Readable literal form: `42`, `2.5`, `true`, `"abc"`, `nil`,
    /// `(1 . 2)` (dotted-pair notation, nested naturally).
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            LiteralValue::Int(v) => write!(f, "{v}"),
            LiteralValue::Float(v) => write!(f, "{v:?}"),
            LiteralValue::Bool(v) => write!(f, "{v}"),
            LiteralValue::String(v) => write!(f, "{v:?}"),
            LiteralValue::Nil => f.write_str("nil"),
            LiteralValue::Pair(car, cdr) => write!(f, "({car} . {cdr})"),
        }
    }
}

/// The core expression ADT: the compiler-private internal syntax
/// (docs/stage0.md §7.4 — surface syntax and internal syntax are strictly
/// separated; safety comes from the type system, not from naming
/// conventions).
///
/// Variants are open to pattern-match and construct inside Rust, but the
/// *canonical* construction path for name-bearing nodes is the validated
/// `&str`-based constructors ([`CoreExpr::fn_`], [`CoreExpr::var`],
/// [`CoreExpr::assign`], [`CoreExpr::perform`], [`CoreExpr::handle`]) —
/// the contract the 0.4 expander will call with token text. Structural
/// validity (a real span, a valid `Symbol`) is guaranteed by the types
/// themselves; semantic floor checks (duplicate parameters, duplicate
/// handler clauses) live in those constructors and will be re-asserted at
/// expansion time.
#[derive(Debug, Clone, PartialEq)]
pub enum CoreExpr {
    /// Function abstraction. `(Fn{params, body}, env) → closure`.
    Fn {
        span: Span,
        params: Vec<Symbol>,
        body: Box<CoreExpr>,
    },
    /// Application. `(Apply{func, args}, env) → apply(eval(func), eval(args))`.
    Apply {
        span: Span,
        func: Box<CoreExpr>,
        args: Vec<CoreExpr>,
    },
    /// Conditional branch with short-circuit semantics.
    If {
        span: Span,
        cond: Box<CoreExpr>,
        then_branch: Box<CoreExpr>,
        else_branch: Box<CoreExpr>,
    },
    /// Variable reference.
    Var { span: Span, name: Symbol },
    /// Constant value.
    Literal { span: Span, value: LiteralValue },
    /// Assignment (the side-effect primitive; §6.12.6 maps the historical
    /// `set!` here; the Stage 2 ANF target re-spells it `Perform(State)`).
    Assign {
        span: Span,
        name: Symbol,
        value: Box<CoreExpr>,
    },
    /// Sequential binding form (let* semantics; `do` desugars to this).
    Let {
        span: Span,
        bindings: Vec<Binding>,
        body: Box<CoreExpr>,
    },
    /// Effect performance. `(Perform{effect, args}, env, k) → operation`.
    Perform {
        span: Span,
        effect: Symbol,
        args: Vec<CoreExpr>,
    },
    /// Effect handling: evaluate `body` with `handlers` installed.
    Handle {
        span: Span,
        body: Box<CoreExpr>,
        handlers: Vec<HandlerClause>,
    },
}

impl CoreExpr {
    /// The span of this node (every variant carries one — TD-004).
    pub fn span(&self) -> Span {
        match self {
            CoreExpr::Fn { span, .. }
            | CoreExpr::Apply { span, .. }
            | CoreExpr::If { span, .. }
            | CoreExpr::Var { span, .. }
            | CoreExpr::Literal { span, .. }
            | CoreExpr::Assign { span, .. }
            | CoreExpr::Let { span, .. }
            | CoreExpr::Perform { span, .. }
            | CoreExpr::Handle { span, .. } => *span,
        }
    }

    /// Stable diagnostic name (one lowercase word; used by diagnostics
    /// and by the 0.8 renderer).
    pub fn kind_name(&self) -> &'static str {
        match self {
            CoreExpr::Fn { .. } => "fn",
            CoreExpr::Apply { .. } => "apply",
            CoreExpr::If { .. } => "if",
            CoreExpr::Var { .. } => "var",
            CoreExpr::Literal { .. } => "literal",
            CoreExpr::Assign { .. } => "assign",
            CoreExpr::Let { .. } => "let",
            CoreExpr::Perform { .. } => "perform",
            CoreExpr::Handle { .. } => "handle",
        }
    }

    /// Pre-order span traversal over the whole expression tree, including
    /// binding sites and handler-clause sites.
    ///
    /// This is the sub-stage 0.4 expander consumption contract (and the
    /// "no dummy span" audit primitive): the callback receives this
    /// node's span first, then spans of children depth-first left-to-right.
    pub fn visit_spans(&self, f: &mut impl FnMut(Span)) {
        match self {
            CoreExpr::Fn { span, body, .. } => {
                f(*span);
                body.visit_spans(f);
            }
            CoreExpr::Apply { span, func, args } => {
                f(*span);
                func.visit_spans(f);
                for arg in args {
                    arg.visit_spans(f);
                }
            }
            CoreExpr::If {
                span,
                cond,
                then_branch,
                else_branch,
            } => {
                f(*span);
                cond.visit_spans(f);
                then_branch.visit_spans(f);
                else_branch.visit_spans(f);
            }
            CoreExpr::Var { span, .. } => f(*span),
            CoreExpr::Literal { span, .. } => f(*span),
            CoreExpr::Assign { span, value, .. } => {
                f(*span);
                value.visit_spans(f);
            }
            CoreExpr::Let {
                span,
                bindings,
                body,
            } => {
                f(*span);
                for binding in bindings {
                    f(binding.span);
                    binding.value.visit_spans(f);
                }
                body.visit_spans(f);
            }
            CoreExpr::Perform { span, args, .. } => {
                f(*span);
                for arg in args {
                    arg.visit_spans(f);
                }
            }
            CoreExpr::Handle {
                span,
                body,
                handlers,
            } => {
                f(*span);
                body.visit_spans(f);
                for clause in handlers {
                    f(clause.span);
                    clause.handler.visit_spans(f);
                }
            }
        }
    }

    /// Checked `fn` constructor from source-shaped parameter text.
    ///
    /// Validation order is fixed for determinism: every parameter is
    /// symbol-validated first (left to right), then a duplicate scan runs
    /// (left to right, first duplicate wins).
    pub fn fn_(span: Span, params: &[&str], body: CoreExpr) -> Result<Self, CoreError> {
        let symbols: Vec<Symbol> = params
            .iter()
            .map(|raw| Symbol::new(raw))
            .collect::<Result<_, _>>()?;
        // §9.65 EXP-4 + §9.72 SYN-2: the duplicate scan keys on the
        // interned identity (same left-to-right order as `params` —
        // the first duplicate wins, unchanged); the error payload
        // reuses the pool entry instead of copying the text back out.
        let mut seen: HashSet<Symbol> = HashSet::with_capacity(params.len());
        for sym in &symbols {
            if !seen.insert(sym.clone()) {
                return Err(CoreError::DuplicateParam { name: sym.clone() });
            }
        }
        Ok(CoreExpr::Fn {
            span,
            params: symbols,
            body: Box::new(body),
        })
    }

    /// Checked `var` constructor from source-shaped name text.
    pub fn var(span: Span, name: &str) -> Result<Self, CoreError> {
        Ok(CoreExpr::Var {
            span,
            name: Symbol::new(name)?,
        })
    }

    /// Checked `assign` constructor from source-shaped name text.
    pub fn assign(span: Span, name: &str, value: CoreExpr) -> Result<Self, CoreError> {
        Ok(CoreExpr::Assign {
            span,
            name: Symbol::new(name)?,
            value: Box::new(value),
        })
    }

    /// Checked `perform` constructor from source-shaped effect text.
    pub fn perform(span: Span, effect: &str, args: Vec<CoreExpr>) -> Result<Self, CoreError> {
        Ok(CoreExpr::Perform {
            span,
            effect: Symbol::new(effect)?,
            args,
        })
    }

    /// Checked `handle` constructor over pre-built clauses.
    ///
    /// Clauses are validated at their own construction
    /// ([`HandlerClause::new`]); this constructor adds the semantic floor
    /// check that no effect is handled twice (deterministic: left to
    /// right, first duplicate wins).
    pub fn handle(
        span: Span,
        body: CoreExpr,
        handlers: Vec<HandlerClause>,
    ) -> Result<Self, CoreError> {
        let mut seen: HashSet<Symbol> = HashSet::with_capacity(handlers.len());
        for clause in &handlers {
            // §9.65 EXP-5 + §9.72 SYN-2: identity-keyed duplicate scan —
            // the entry the clause already carries, never a de-interned
            // text copy.
            if !seen.insert(clause.effect.clone()) {
                return Err(CoreError::DuplicateHandler {
                    effect: clause.effect.clone(),
                });
            }
        }
        Ok(CoreExpr::Handle {
            span,
            body: Box::new(body),
            handlers,
        })
    }
}

impl fmt::Display for CoreExpr {
    /// Minimal one-word rendering (the stable diagnostic name).
    ///
    /// Canonical S-expression rendering of whole programs is deferred to
    /// the diagnostics renderer (0.8) and the snapshot suite (0.11).
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.kind_name())
    }
}

#[cfg(test)]
mod tests {
    //! Unit tests for the CoreExpr / LiteralValue feature points (sub-stage
    //! test doc FP2-FP4; docs/tests/v0/stage0/plan/core.md).

    use super::*;
    use kerf_span::{ByteOffset, ExpansionId, FileId};

    fn span(start: u32, end: u32) -> Span {
        Span::new(
            FileId(0),
            ByteOffset(start),
            ByteOffset(end),
            ExpansionId::ROOT,
        )
        .expect("test fixture span must be well-formed")
    }

    fn sample_literal() -> CoreExpr {
        CoreExpr::Literal {
            span: span(30, 32),
            value: LiteralValue::Int(42),
        }
    }

    // ---------- positive ----------

    #[test]
    fn kind_name_covers_all_nine_variants() {
        let body = sample_literal();
        let cases: Vec<(CoreExpr, &'static str)> = vec![
            (CoreExpr::fn_(span(0, 1), &["x"], body).unwrap(), "fn"),
            (
                CoreExpr::Apply {
                    span: span(0, 1),
                    func: Box::new(sample_literal()),
                    args: vec![],
                },
                "apply",
            ),
            (
                CoreExpr::If {
                    span: span(0, 1),
                    cond: Box::new(sample_literal()),
                    then_branch: Box::new(sample_literal()),
                    else_branch: Box::new(sample_literal()),
                },
                "if",
            ),
            (CoreExpr::var(span(0, 1), "x").unwrap(), "var"),
            (sample_literal(), "literal"),
            (
                CoreExpr::assign(span(0, 1), "x", sample_literal()).unwrap(),
                "assign",
            ),
            (
                CoreExpr::Let {
                    span: span(0, 1),
                    bindings: vec![],
                    body: Box::new(sample_literal()),
                },
                "let",
            ),
            (
                CoreExpr::perform(span(0, 1), "read", vec![]).unwrap(),
                "perform",
            ),
            (
                CoreExpr::handle(span(0, 1), sample_literal(), vec![]).unwrap(),
                "handle",
            ),
        ];
        for (expr, expected) in &cases {
            assert_eq!(expr.kind_name(), *expected);
            assert_eq!(expr.to_string(), *expected);
        }
        assert_eq!(cases.len(), 9, "all nine primitives must be covered");

        let literal_kinds = [
            (LiteralValue::Int(1), "int"),
            (LiteralValue::Float(1.0), "float"),
            (LiteralValue::Bool(true), "bool"),
            (LiteralValue::String("s".into()), "string"),
            (LiteralValue::Nil, "nil"),
            (
                LiteralValue::Pair(Box::new(LiteralValue::Nil), Box::new(LiteralValue::Nil)),
                "pair",
            ),
        ];
        for (value, expected) in &literal_kinds {
            assert_eq!(value.kind_name(), *expected);
        }
    }

    #[test]
    fn literal_value_display_forms() {
        assert_eq!(LiteralValue::Int(42).to_string(), "42");
        assert_eq!(LiteralValue::Int(-7).to_string(), "-7");
        assert_eq!(LiteralValue::Float(2.5).to_string(), "2.5");
        // Debug-style float formatting keeps the float-ness visible.
        assert_eq!(LiteralValue::Float(3.0).to_string(), "3.0");
        assert_eq!(LiteralValue::Bool(true).to_string(), "true");
        assert_eq!(LiteralValue::Bool(false).to_string(), "false");
        assert_eq!(LiteralValue::String("abc".into()).to_string(), "\"abc\"");
        assert_eq!(LiteralValue::Nil.to_string(), "nil");
        let pair = LiteralValue::Pair(
            Box::new(LiteralValue::Int(1)),
            Box::new(LiteralValue::Int(2)),
        );
        assert_eq!(pair.to_string(), "(1 . 2)");
        let nested = LiteralValue::Pair(Box::new(pair), Box::new(LiteralValue::Int(3)));
        assert_eq!(nested.to_string(), "((1 . 2) . 3)");
    }

    #[test]
    fn span_accessor_returns_constructor_span() {
        let s = span(10, 20);
        let expr = CoreExpr::var(s, "x").unwrap();
        assert_eq!(expr.span(), s);

        let apply = CoreExpr::Apply {
            span: s,
            func: Box::new(CoreExpr::var(s, "f").unwrap()),
            args: vec![sample_literal()],
        };
        assert_eq!(apply.span(), s);
        assert_eq!(apply.span().to_string(), "file#0:10..20");
    }

    #[test]
    fn visit_spans_reports_exact_preorder() {
        // let (100..200) {
        //   x = literal(30..32)   [reused fixture]
        // } in apply(150..200) { var f(150..180), literal(180..200) }
        let program = CoreExpr::Let {
            span: span(100, 200),
            bindings: vec![Binding::new(span(100, 150), "x", sample_literal()).unwrap()],
            body: Box::new(CoreExpr::Apply {
                span: span(150, 200),
                func: Box::new(CoreExpr::var(span(150, 180), "f").unwrap()),
                args: vec![CoreExpr::Literal {
                    span: span(180, 200),
                    value: LiteralValue::Int(7),
                }],
            }),
        };
        let mut collected = Vec::new();
        program.visit_spans(&mut |s| collected.push(s));
        let starts: Vec<u32> = collected.iter().map(|s| s.start.0).collect();
        // Pre-order: let, binding site, binding value, apply, func var, arg.
        assert_eq!(starts, vec![100, 100, 30, 150, 150, 180]);
        assert_eq!(collected.len(), 6);

        // handle(0..50) { body(10..20) } with clauses at 20..30 / 30..50.
        let handled = CoreExpr::handle(
            span(0, 50),
            CoreExpr::var(span(10, 20), "x").unwrap(),
            vec![
                HandlerClause::new(
                    span(20, 30),
                    "read",
                    CoreExpr::var(span(21, 22), "h").unwrap(),
                )
                .unwrap(),
                HandlerClause::new(
                    span(30, 50),
                    "write",
                    CoreExpr::var(span(31, 32), "g").unwrap(),
                )
                .unwrap(),
            ],
        )
        .unwrap();
        let mut spans = Vec::new();
        handled.visit_spans(&mut |s| spans.push(s.start.0));
        // handle, body, clause1 site, clause1 handler, clause2 site,
        // clause2 handler.
        assert_eq!(spans, vec![0, 10, 20, 21, 30, 31]);
    }

    // ---------- negative ----------

    #[test]
    fn fn_constructor_rejects_adjacent_duplicate_params() {
        let err = CoreExpr::fn_(span(0, 1), &["x", "x"], sample_literal())
            .expect_err("adjacent duplicate params must be rejected");
        assert_eq!(
            err,
            CoreError::DuplicateParam {
                name: Symbol::new("x").expect("fixture symbol must be valid")
            }
        );
    }

    #[test]
    fn fn_constructor_rejects_non_adjacent_duplicate_params() {
        let err = CoreExpr::fn_(span(0, 1), &["x", "y", "x"], sample_literal())
            .expect_err("non-adjacent duplicate params must be rejected");
        assert_eq!(
            err,
            CoreError::DuplicateParam {
                name: Symbol::new("x").expect("fixture symbol must be valid")
            }
        );
    }

    #[test]
    fn duplicate_payloads_round_trip_through_the_single_pool() {
        // §9.65 EXP-4/EXP-5: duplicate-detection payloads are the
        // interned identities of the offending names — the expected
        // values are rebuilt through the single pool, so equality is
        // index equality (the parity-decoder contract, pinned at the
        // constructor level).
        let err = CoreExpr::fn_(span(0, 1), &["p", "q", "p"], sample_literal())
            .expect_err("duplicate param must be rejected");
        assert_eq!(
            err,
            CoreError::DuplicateParam {
                name: Symbol::new("p").expect("fixture symbol must be valid")
            }
        );
        let clauses = vec![
            HandlerClause::new(span(20, 30), "read", sample_literal()).unwrap(),
            HandlerClause::new(span(30, 40), "write", sample_literal()).unwrap(),
            HandlerClause::new(span(40, 50), "read", sample_literal()).unwrap(),
        ];
        let err = CoreExpr::handle(span(0, 1), sample_literal(), clauses)
            .expect_err("duplicate effect must be rejected");
        assert_eq!(
            err,
            CoreError::DuplicateHandler {
                effect: Symbol::new("read").expect("fixture symbol must be valid")
            }
        );
    }

    #[test]
    fn fn_constructor_rejects_invalid_param_symbol() {
        let err = CoreExpr::fn_(span(0, 1), &["x", "a b"], sample_literal())
            .expect_err("invalid param text must be rejected");
        assert!(matches!(err, CoreError::InvalidSymbol(_)));
    }

    fn two_read_clauses() -> Vec<HandlerClause> {
        vec![
            HandlerClause::new(span(20, 30), "read", sample_literal()).unwrap(),
            HandlerClause::new(span(30, 40), "read", sample_literal()).unwrap(),
        ]
    }

    #[test]
    fn handle_constructor_rejects_adjacent_duplicate_effects() {
        let err = CoreExpr::handle(span(0, 1), sample_literal(), two_read_clauses())
            .expect_err("adjacent duplicate effect clauses must be rejected");
        assert_eq!(
            err,
            CoreError::DuplicateHandler {
                effect: Symbol::new("read").expect("fixture symbol must be valid")
            }
        );
    }

    #[test]
    fn handle_constructor_rejects_non_adjacent_duplicate_effects() {
        let mut clauses = two_read_clauses();
        clauses.insert(
            1,
            HandlerClause::new(span(40, 50), "write", sample_literal()).unwrap(),
        );
        let err = CoreExpr::handle(span(0, 1), sample_literal(), clauses)
            .expect_err("non-adjacent duplicate effect clauses must be rejected");
        assert_eq!(
            err,
            CoreError::DuplicateHandler {
                effect: Symbol::new("read").expect("fixture symbol must be valid")
            }
        );
    }

    #[test]
    fn handler_clause_rejects_invalid_effect_symbol() {
        let err = HandlerClause::new(span(0, 1), "bad name", sample_literal())
            .expect_err("invalid effect text must be rejected");
        assert!(matches!(err, CoreError::InvalidSymbol(_)));
    }

    #[test]
    fn var_constructor_rejects_invalid_name() {
        let err = CoreExpr::var(span(0, 1), "a\tb").expect_err("invalid var text must be rejected");
        assert_eq!(
            err,
            CoreError::InvalidSymbol(kerf_span::SymbolError::InvalidSymbol {
                text: "a\tb".to_owned()
            })
        );
    }
}

#[test]
fn pair_cells_counts_the_materialization_footprint_exactly() {
    // §9.69.3 EXC-1: `pair_cells` is the single source both engines
    // budget against — only Pair nodes allocate heap cells; the
    // inline variants (including String, which lives inside the
    // Value enum) count zero.
    assert_eq!(LiteralValue::Int(7).pair_cells(), 0);
    assert_eq!(LiteralValue::Float(0.5).pair_cells(), 0);
    assert_eq!(LiteralValue::Bool(true).pair_cells(), 0);
    assert_eq!(LiteralValue::String("s".into()).pair_cells(), 0);
    assert_eq!(LiteralValue::Nil.pair_cells(), 0);
    // (1 . 2) — one cell.
    let one = LiteralValue::Pair(
        Box::new(LiteralValue::Int(1)),
        Box::new(LiteralValue::Int(2)),
    );
    assert_eq!(one.pair_cells(), 1);
    // (1 . (2 . 3)) — the quoted-list spine: two cells.
    let two = LiteralValue::Pair(Box::new(LiteralValue::Int(1)), Box::new(one.clone()));
    assert_eq!(two.pair_cells(), 2);
    // ((1 . 2) . (3 . 4)) — branching nesting: car 1 + cdr-side
    // 1 + the root itself = three cells.
    let three = LiteralValue::Pair(
        Box::new(one.clone()),
        Box::new(LiteralValue::Pair(
            Box::new(LiteralValue::Int(3)),
            Box::new(LiteralValue::Int(4)),
        )),
    );
    assert_eq!(three.pair_cells(), 3);
}

//! CoreExpr -> Bytecode translation (sub-stage 0.5, docs/stage0.md §19.3).
//!
//! Direct-style compilation with jump backpatching, a deduplicated
//! constant pool, an interned global table, and the per-instruction
//! debug_info table (spans are copied from CoreExpr nodes — the only
//! synthesized span is the cold-start anchor used for the `halt` of an
//! empty program). Compile-time bookkeeping (depth tracking, patch
//! assertions, placeholder drain) is the first defense layer and fails
//! closed with structured errors; `Bytecode::verify` is the second.
//!
//! Tail-position contract (§19.3 trap 1): a tail `If` compiles its
//! branches straight into the proto terminator (`ret` in closures /
//! `halt` in the entry) with no merge jump — Stage 1+ TCO only
//! rewrites the branch tail, never the VM. `Handle` bodies are
//! compiled non-tail: handlers must be popped before returning (tail
//! pass-through under handlers is registered Stage 2
//! effect-elimination theory, not implemented here).

use std::collections::HashMap;

use kerf_core::{CoreExpr, LiteralValue, ModuleItem};
use kerf_span::{ByteOffset, ExpansionId, FileId, Span, Symbol};

use crate::bytecode::{Bytecode, CaptureSource, ExternEntry, FuncProto, Instr};
use crate::error::CompileError;
use crate::opcode::Opcode;
use crate::{COMPILE_DEPTH_LIMIT, JUMP_PLACEHOLDER};

/// Slot-identity predicate for the constant pool — the single source
/// of dedup semantics (Lua `addk` discipline: a candidate index is
/// only a hint, the pool entry is the truth). NaN folds to one slot
/// (Eq reflexivity), +0.0/-0.0 stay distinct (bit-pattern comparison
/// keeps pool layout consistent — dedup is an optimization, not a
/// semantic merge, but pool layout is part of bytecode identity).
fn same_const_slot(a: &LiteralValue, b: &LiteralValue) -> bool {
    match (a, b) {
        (LiteralValue::Int(x), LiteralValue::Int(y)) => x == y,
        (LiteralValue::Float(x), LiteralValue::Float(y)) => {
            let xb = if x.is_nan() {
                f64::NAN.to_bits()
            } else {
                x.to_bits()
            };
            let yb = if y.is_nan() {
                f64::NAN.to_bits()
            } else {
                y.to_bits()
            };
            xb == yb
        }
        (LiteralValue::Bool(x), LiteralValue::Bool(y)) => x == y,
        (LiteralValue::String(x), LiteralValue::String(y)) => x == y,
        (LiteralValue::Nil, LiteralValue::Nil) => true,
        (LiteralValue::Pair(xc, xd), LiteralValue::Pair(yc, yd)) => {
            same_const_slot(xc, yc) && same_const_slot(xd, yd)
        }
        _ => false,
    }
}

/// Deterministic FNV-1a over the canonical constant walk — a fixed
/// seed and a wrapping multiply keep the hash stable across runs and
/// platforms, so pool indices (first-use insertion order) stay
/// deterministic; the fixpoint gate B rests on it (rustc `Unhasher`
/// discipline: only pre-hashed, hash-like-quality keys enter the
/// map; the hash never defines slot identity, `same_const_slot`
/// does — a collision just widens a bucket).
fn const_hash(value: &LiteralValue) -> u64 {
    const FNV_OFFSET: u64 = 0xcbf29ce484222325;
    const FNV_PRIME: u64 = 0x100000001b3;
    fn mix(state: &mut u64, bytes: &[u8]) {
        for &b in bytes {
            *state ^= u64::from(b);
            *state = state.wrapping_mul(FNV_PRIME);
        }
    }
    let mut h = FNV_OFFSET;
    match value {
        LiteralValue::Int(v) => {
            mix(&mut h, &[0x01]);
            mix(&mut h, &v.to_le_bytes());
        }
        LiteralValue::Float(v) => {
            mix(&mut h, &[0x02]);
            let bits = if v.is_nan() {
                f64::NAN.to_bits()
            } else {
                v.to_bits()
            };
            mix(&mut h, &bits.to_le_bytes());
        }
        LiteralValue::Bool(v) => {
            mix(&mut h, &[0x03]);
            mix(&mut h, &[*v as u8]);
        }
        LiteralValue::String(s) => {
            // length-prefixed: no cross-variant or concatenation ambiguity
            mix(&mut h, &[0x04]);
            mix(&mut h, &(s.len() as u64).to_le_bytes());
            mix(&mut h, s.as_bytes());
        }
        LiteralValue::Nil => {
            mix(&mut h, &[0x05]);
        }
        LiteralValue::Pair(car, cdr) => {
            mix(&mut h, &[0x06]);
            h ^= const_hash(car);
            h = h.wrapping_mul(FNV_PRIME);
            h ^= const_hash(cdr);
            h = h.wrapping_mul(FNV_PRIME);
        }
    }
    h
}

/// Per-proto compilation state (the §19.3 `CodeBuf`).
struct ProtoState {
    name: Option<Symbol>,
    params: u32,
    n_locals: u32,
    code: Vec<Instr>,
    debug_info: Vec<Span>,
    /// Linear data-stack depth bookkeeping.
    depth: i32,
    /// Lexical local bindings (stack discipline: mark/truncate).
    locals: Vec<(Symbol, u32)>,
    /// Dead local slots returned by `locals_truncate`, handed back
    /// LIFO by `alloc_local` — deterministic reuse, so `n_locals`
    /// tracks the peak simultaneous bindings, not the cumulative
    /// count (Lua `freereg` discipline: the slot window shrinks at
    /// scope exit; compile products are back-edge-free, so a reused
    /// slot's earlier readers always execute before its re-binder).
    free_slots: Vec<u32>,
    /// The flat-capture analysis table (Stage 2.1 LA-1/LA-4): entry
    /// `i` is `(name, source)` where `source` says where the
    /// *defining* frame holds the value (its local slot, or its own
    /// capture index for the transitive case). First-use order —
    /// the deterministic walk the products' `captures` tables land
    /// in (pool-identity name keys, never text).
    captures: Vec<(Symbol, CaptureSource)>,
    /// The proto whose body encloses this one's `closure`
    /// instruction (`None` for the entry proto — top-level free
    /// names are globals, so the entry never captures).
    parent: Option<usize>,
}

struct Compiler {
    protos: Vec<ProtoState>,
    cur: usize,
    /// Caller protos saved at each `begin_closure` (LIFO) — `cur`
    /// restores through this stack, NOT by decrementing: sibling and
    /// nested closures must both return to their exact caller
    /// (0.5 defect fixed in the 0.6 round: `cur -= 1` corrupted every
    /// program with more than one closure past the first).
    cur_stack: Vec<usize>,
    consts: Vec<LiteralValue>,
    /// Pre-hashed dedup index: FNV-1a hash -> pool indices sharing
    /// it (collision buckets resolved by `same_const_slot`).
    const_map: HashMap<u64, Vec<u32>>,
    globals: Vec<Symbol>,
    global_map: HashMap<Symbol, u32>,
    /// The extern contract table (W-3.2): collected from
    /// `ModuleItem::Extern` declarations in item order — the product
    /// face the VM (diagnostics) and the C backend (prototypes,
    /// wrappers, seeding) consume.
    externs: Vec<ExternEntry>,
    /// Current compile-recursion depth (guarded by the configured
    /// `limit` — [`COMPILE_DEPTH_LIMIT`] on the default entries,
    /// caller-raised on the `with_limit` face of the W-REC-DEPTH
    /// blade 2).
    depth: usize,
    /// The configured compile-recursion cap (K162).
    limit: usize,
    /// Span of the last emit (the `halt` of a non-empty program uses
    /// it; an empty program falls back to the cold-start anchor).
    last_span: Span,
    /// The F1 direct-arithmetic poison set (W-VM-SUPERINSTR §2a
    /// FA-1): the arithmetic builtin names this program could
    /// rebind — a module `define`, an extern contract entry, or any
    /// `assign` anywhere. A poisoned name falls back to the fused
    /// `call-global` path at every call site; an unpoisoned name at
    /// a two-argument global call site emits the direct arithmetic
    /// opcode. Populated once per program by
    /// [`scan_arith_poison`] (the twin mirrors it as the
    /// `cp_arith_poison` name list over the raw record stream).
    arith_poison: Vec<Symbol>,
}

impl Compiler {
    /// Cold-start anchor: a real (zero-length) span at origin. The
    /// only synthesized span in the crate, used solely when an empty
    /// program must still emit its terminal `halt` (single-generation
    /// ROOT — no cross-generation join can occur).
    fn anchor() -> Span {
        Span::new(FileId(0), ByteOffset(0), ByteOffset(0), ExpansionId::ROOT)
            .expect("cold-start anchor span is well-formed by construction")
    }

    fn new() -> Self {
        Compiler {
            protos: vec![ProtoState {
                name: None,
                params: 0,
                n_locals: 0,
                code: Vec::new(),
                debug_info: Vec::new(),
                depth: 0,
                locals: Vec::new(),
                free_slots: Vec::new(),
                captures: Vec::new(),
                parent: None,
            }],
            cur: 0,
            cur_stack: Vec::new(),
            consts: Vec::new(),
            const_map: HashMap::new(),
            globals: Vec::new(),
            global_map: HashMap::new(),
            externs: Vec::new(),
            depth: 0,
            limit: COMPILE_DEPTH_LIMIT,
            last_span: Self::anchor(),
            arith_poison: Vec::new(),
        }
    }

    /// A cold-start compiler with an explicit recursion cap (the K162
    /// configurable-guardrail face of the W-REC-DEPTH blade 2).
    fn with_limit(limit: usize) -> Self {
        Compiler {
            limit,
            ..Compiler::new()
        }
    }

    // ---- emission ----

    /// Emit one instruction with automatic debug_info recording and
    /// depth bookkeeping (the single emit path — §19.3 "every emit
    /// automatically writes debug_info_table"). Fails closed on
    /// bookkeeping underflow (a compile bug, never silently emitted).
    fn emit(&mut self, op: Opcode, a: u32, b: u32, span: Span) -> Result<usize, CompileError> {
        let p = &mut self.protos[self.cur];
        let pops = op.pops(a, b) as i32;
        let pc = p.code.len();
        if p.depth < pops {
            return Err(CompileError::StackUnderflow { pc, span });
        }
        p.depth = p.depth - pops + op.pushes() as i32;
        p.code.push(Instr { op, a, b });
        p.debug_info.push(span);
        self.last_span = span;
        Ok(pc)
    }

    /// Emit a jump with a placeholder target; returns the pc. The
    /// depth *after* the jump rides in the instruction's unused `b`
    /// slot for the patch assertion — the instruction stream carries
    /// its own patch bookkeeping (Lua patchlist discipline adapted:
    /// `a` holds the placeholder sentinel while pending, `b` holds
    /// the source depth; both are restored to the zero-operand
    /// output contract by `patch`).
    fn emit_jump(&mut self, op: Opcode, span: Span) -> Result<usize, CompileError> {
        let pc = self.emit(op, JUMP_PLACEHOLDER, 0, span)?;
        let p = &mut self.protos[self.cur];
        p.code[pc].b = p.depth as u32;
        Ok(pc)
    }

    /// Patch the placeholder at `at` to `target`, asserting the
    /// current (reset) depth matches the depth recorded in the jump's
    /// `b` slot at emission, then clearing `b` back to zero (the
    /// "unused slot is always 0" output contract holds for finished
    /// products).
    fn patch(&mut self, at: usize, target: u32) -> Result<(), CompileError> {
        let p = &mut self.protos[self.cur];
        let instr = p
            .code
            .get_mut(at)
            .expect("patch target pc must be in the current proto");
        if instr.a != JUMP_PLACEHOLDER {
            panic!("patch of a non-placeholder pc is a compiler bug");
        }
        let expected = instr.b as i32;
        instr.a = target;
        instr.b = 0;
        let actual = p.depth;
        if actual != expected {
            let span = p.debug_info[at];
            return Err(CompileError::StackImbalance {
                pc: at,
                expected: expected as u32,
                actual: actual as u32,
                span,
            });
        }
        Ok(())
    }

    /// Explicit depth reset (the else-entry of an If: linear flow just
    /// left the then-branch, but the jump target enters at the
    /// post-condition depth).
    fn set_depth(&mut self, depth: i32) {
        self.protos[self.cur].depth = depth;
    }

    fn cur_depth(&self) -> i32 {
        self.protos[self.cur].depth
    }

    fn here(&self) -> u32 {
        self.protos[self.cur].code.len() as u32
    }

    /// The tail-position terminator: `ret` inside a closure (value
    /// delivered across frames), `halt` in the entry proto (value left
    /// on the stack for the VM to pop).
    fn emit_tail_terminator(&mut self, span: Span) -> Result<(), CompileError> {
        if self.cur == 0 {
            self.emit(Opcode::Halt, 0, 0, span)?;
        } else {
            self.emit(Opcode::Ret, 0, 0, span)?;
        }
        Ok(())
    }

    // ---- pools and locals ----

    // Determinism invariant (stage0.md §9.55): pool and global slots
    // are assigned by first-use insertion order (`idx = Vec::len()` at
    // insert) and the Vec is the emission source; the hash map is a
    // dedup index only (pre-hashed keys; buckets resolved by the
    // `same_const_slot` predicate against the pool entries) and its
    // iteration order must never reach the output — the fixpoint
    // gate B (bytecode identity) rests on this.

    fn intern_const(&mut self, value: &LiteralValue) -> u32 {
        let hash = const_hash(value);
        if let Some(bucket) = self.const_map.get(&hash) {
            for &idx in bucket {
                if same_const_slot(&self.consts[idx as usize], value) {
                    return idx;
                }
            }
        }
        let idx = self.consts.len() as u32;
        self.consts.push(value.clone());
        self.const_map.entry(hash).or_default().push(idx);
        idx
    }

    fn intern_global(&mut self, name: &Symbol) -> u32 {
        if let Some(&idx) = self.global_map.get(name) {
            return idx;
        }
        let idx = self.globals.len() as u32;
        self.globals.push(name.clone());
        self.global_map.insert(name.clone(), idx);
        idx
    }

    fn alloc_local(&mut self) -> u32 {
        let p = &mut self.protos[self.cur];
        if let Some(slot) = p.free_slots.pop() {
            slot
        } else {
            let slot = p.n_locals;
            p.n_locals += 1;
            slot
        }
    }

    fn push_local(&mut self, name: Symbol, slot: u32) {
        self.protos[self.cur].locals.push((name, slot));
    }

    fn lookup_local(&self, name: &Symbol) -> Option<u32> {
        // innermost binding wins (stack discipline -> shadowing)
        self.protos[self.cur]
            .locals
            .iter()
            .rev()
            .find(|(n, _)| n == name)
            .map(|(_, slot)| *slot)
    }

    // ---- the Stage 2.1 capture analysis (LA-1 / LA-4) ----

    /// Resolve `name` as a capture of the current proto, ensuring
    /// every intermediate proto on the chain holds it. Returns the
    /// capture index, or `None` when no enclosing proto holds the
    /// name (the global fallback — unchanged dormant-era behavior
    /// for names nothing binds lexically).
    fn capture_in_cur(&mut self, name: &Symbol) -> Option<u32> {
        let cur = self.cur;
        if let Some(k) = self.protos[cur]
            .captures
            .iter()
            .position(|(n, _)| n == name)
        {
            return Some(k as u32);
        }
        let parent = self.protos[cur].parent?;
        let source = self.held_by(parent, name)?;
        let k = self.protos[cur].captures.len() as u32;
        self.protos[cur].captures.push((name.clone(), source));
        Some(k)
    }

    /// Where `holder` holds `name`, as read by a proto whose definer
    /// is `holder`: its live local slot, or its own capture index —
    /// capturing it transitively when only an outer proto holds it
    /// (LA-4, the flat-closure pass-through: the Steensgaard free-
    /// variable walk internalized; K45 minimal-capture-set ruling).
    ///
    /// Soundness: `holder.locals` at the call moment is exactly the
    /// binding set live at the fn-expression site (mark/truncate
    /// discipline), and the `closure` instruction is emitted at that
    /// same site — so every recorded slot is occupied when the VM
    /// copies the captured values.
    fn held_by(&mut self, holder: usize, name: &Symbol) -> Option<CaptureSource> {
        if let Some(slot) = self.protos[holder]
            .locals
            .iter()
            .rev()
            .find(|(n, _)| n == name)
            .map(|(_, slot)| *slot)
        {
            return Some(CaptureSource::Local(slot));
        }
        if let Some(k) = self.protos[holder]
            .captures
            .iter()
            .position(|(n, _)| n == name)
        {
            return Some(CaptureSource::Captured(k as u32));
        }
        let outer = self.protos[holder].parent?;
        let source = self.held_by(outer, name)?;
        let k = self.protos[holder].captures.len() as u32;
        self.protos[holder].captures.push((name.clone(), source));
        Some(CaptureSource::Captured(k))
    }

    /// Whether `name` would resolve through the enclosing chain (a
    /// read-only probe — the assign boundary checks it without
    /// materializing capture entries).
    fn resolves_outer(&self, name: &Symbol) -> bool {
        let mut holder = match self.protos[self.cur].parent {
            Some(p) => p,
            None => return false,
        };
        loop {
            let p = &self.protos[holder];
            if p.locals.iter().any(|(n, _)| n == name) || p.captures.iter().any(|(n, _)| n == name)
            {
                return true;
            }
            match p.parent {
                Some(up) => holder = up,
                None => return false,
            }
        }
    }

    fn locals_mark(&self) -> usize {
        self.protos[self.cur].locals.len()
    }

    fn locals_truncate(&mut self, mark: usize) {
        let p = &mut self.protos[self.cur];
        let dead = p.locals.split_off(mark);
        for (_, slot) in dead {
            p.free_slots.push(slot);
        }
    }

    // ---- protos ----

    fn begin_closure(&mut self, name: Option<Symbol>, params: &[Symbol]) -> u32 {
        let idx = self.protos.len() as u32;
        let parent = self.cur;
        self.cur_stack.push(self.cur);
        self.protos.push(ProtoState {
            name,
            params: params.len() as u32,
            n_locals: params.len() as u32,
            code: Vec::new(),
            debug_info: Vec::new(),
            depth: 0,
            locals: params.iter().cloned().zip(0u32..).collect(),
            free_slots: Vec::new(),
            // Stage 2.1 LA-1: the closure body sees the enclosing
            // scope through this link — free names resolve up the
            // chain instead of falling straight to the global table
            // (the dormant-capture design flipped by the semantic
            // MUV; the scope *stack* discipline below is unchanged).
            captures: Vec::new(),
            parent: Some(parent),
        });
        self.cur = idx as usize;
        idx
    }

    fn end_closure(&mut self) {
        // Restore the exact caller proto (the saved stack), never a
        // decrement — sibling closures jump indices non-sequentially
        // relative to their caller.
        self.cur = self
            .cur_stack
            .pop()
            .expect("begin/end closure pairs are balanced");
    }

    // ---- recursion depth ----

    fn enter_depth(&mut self, span: Span) -> Result<(), CompileError> {
        self.depth += 1;
        if self.depth > self.limit {
            self.depth -= 1;
            return Err(CompileError::DepthExceeded {
                depth: self.limit + 1,
                limit: self.limit,
                span,
            });
        }
        Ok(())
    }

    // ---- translation ----

    /// Compile one expression. Returns `true` when the expression has
    /// already emitted its own tail terminator (a tail `If`): the
    /// caller must not emit another one, and the proto-level depth has
    /// already been consumed.
    fn expr(&mut self, e: &CoreExpr, tail: bool) -> Result<bool, CompileError> {
        self.enter_depth(e.span())?;
        let result = self.expr_inner(e, tail);
        self.depth -= 1;
        result
    }

    fn expr_inner(&mut self, e: &CoreExpr, tail: bool) -> Result<bool, CompileError> {
        match e {
            CoreExpr::Literal { span, value } => {
                let k = self.intern_const(value);
                self.emit(Opcode::PushConst, k, 0, *span)?;
                Ok(false)
            }
            CoreExpr::Var { span, name } => {
                if let Some(slot) = self.lookup_local(name) {
                    self.emit(Opcode::LoadLocal, slot, 0, *span)?;
                } else if let Some(k) = self.capture_in_cur(name) {
                    // Stage 2.1 LA-1/LA-3: a free name an enclosing
                    // proto holds becomes a capture read.
                    self.emit(Opcode::LoadCaptured, k, 0, *span)?;
                } else {
                    let g = self.intern_global(name);
                    self.emit(Opcode::LoadGlobal, g, 0, *span)?;
                }
                Ok(false)
            }
            CoreExpr::Fn { span, params, body } => {
                self.compile_fn(None, *span, params, body)?;
                Ok(false)
            }
            CoreExpr::Apply { span, func, args } => {
                // eval-order contract (§19.3/§19.5): args left to
                // right, then the callee; `call n` finds the callee on
                // top via peek(n).
                let mut ai = 0;
                while ai < args.len() {
                    // W-JIT-METHOD-T1 TJ-1 (the fused copy pair): a
                    // local-resolving `Var` argument immediately
                    // followed by a `Literal` argument — the portrait's
                    // third lever (the K151 classic copy pair, 20% of
                    // fib-25 dispatches) — emits one fused
                    // `load-local-const` instead of the load-local +
                    // push-const pair. Structural safety: the fused
                    // instruction replaces the pair's FIRST slot, and
                    // jump targets only ever land on expression-start
                    // boundaries (if/loop arms) — an args-list interior
                    // position (the second slot) is never a target, so
                    // no fusable-classifier walk is needed at the
                    // emission site. Intern order is preserved: the
                    // `Var` interns nothing, so pooling the literal at
                    // the fused emission point is the same first-use
                    // point the unfused push-const would have had. Both
                    // source arms are pure data movement with no error
                    // face; the fused span is the Var's span.
                    if let CoreExpr::Var { name, span: vspan } = &args[ai] {
                        if let Some(slot) = self.lookup_local(name) {
                            if ai + 1 < args.len() {
                                if let CoreExpr::Literal { value, .. } = &args[ai + 1] {
                                    let k = self.intern_const(value);
                                    self.emit(Opcode::LoadLocalConst, slot, k, *vspan)?;
                                    ai += 2;
                                    continue;
                                }
                            }
                        }
                    }
                    self.expr(&args[ai], false)?;
                    ai += 1;
                }
                // W-VM-SUPERINSTR SI-1 (emission-site fusion): a
                // callee that is a plain global reference compiles to
                // one fused `call-global` instead of the
                // load-global + call pair — the dispatch portrait's
                // universal first pair (24-29% of every measured
                // load, w3.7-jit-window.md §2b F4). The fusion
                // condition mirrors the `Var` resolution exactly
                // (local slot, then capture, else global): the two
                // lookups are idempotent for a global name, and a
                // captured callee that installs a descriptor here
                // resolves to the same index when the fallback
                // re-walks it below (first-use order preserved). The
                // fused instruction carries the Apply span — the
                // same span the plain `call` would have carried.
                if let CoreExpr::Var { name, .. } = &**func {
                    if self.lookup_local(name).is_none() && self.capture_in_cur(name).is_none() {
                        // W-VM-SUPERINSTR F1 (FA-2, the direct
                        // arithmetic blade): an unpoisoned arithmetic
                        // builtin called with exactly two arguments
                        // emits the direct Add/Sub/Mul/Div opcode —
                        // the builtin dispatch and the opcode arm
                        // share the single `arith` source (FA-3's
                        // constructive equivalence), and the argc==2
                        // conjunct statically excludes the arity
                        // error face (any other argc falls through to
                        // the fused call and preserves
                        // ArityMismatch). The name is never interned
                        // on this path (FA-4: a direct-only reference
                        // leaves the globals table without the
                        // slot — first-use order of the remaining
                        // names is untouched).
                        if let Some(op) = direct_arith_opcode(name) {
                            if args.len() == 2 && !self.arith_poison.contains(name) {
                                self.emit(op, 0, 0, *span)?;
                                return Ok(false);
                            }
                        }
                        let g = self.intern_global(name);
                        self.emit(Opcode::CallGlobal, g, args.len() as u32, *span)?;
                        return Ok(false);
                    }
                }
                self.expr(func, false)?;
                self.emit(Opcode::Call, args.len() as u32, 0, *span)?;
                Ok(false)
            }
            CoreExpr::If {
                cond,
                then_branch,
                else_branch,
                ..
            } if tail => {
                self.expr(cond, false)?;
                let jf = self.emit_jump(Opcode::JumpIfFalse, cond.span())?;
                // else-entry depth = the depth after the conditional
                // pop (the jump-source depth)
                let post_cond = self.cur_depth();
                self.expr(then_branch, false)?;
                self.emit_tail_terminator(then_branch.span())?;
                self.set_depth(post_cond);
                self.patch(jf, self.here())?;
                self.expr(else_branch, false)?;
                self.emit_tail_terminator(else_branch.span())?;
                Ok(true)
            }
            CoreExpr::If {
                span,
                cond,
                then_branch,
                else_branch,
            } => {
                self.expr(cond, false)?;
                let jf = self.emit_jump(Opcode::JumpIfFalse, cond.span())?;
                // else-entry depth = the depth after the conditional
                // pop (the jump-source depth)
                let post_cond = self.cur_depth();
                self.expr(then_branch, false)?;
                let j_end = self.emit_jump(Opcode::Jump, *span)?;
                self.set_depth(post_cond);
                self.patch(jf, self.here())?;
                self.expr(else_branch, false)?;
                self.patch(j_end, self.here())?;
                Ok(false)
            }
            CoreExpr::Assign { span, name, value } => {
                self.expr(value, false)?;
                self.emit(Opcode::Dup, 0, 0, *span)?;
                if let Some(slot) = self.lookup_local(name) {
                    self.emit(Opcode::StoreLocal, slot, 0, *span)?;
                } else if self.resolves_outer(name) {
                    // Stage 2.1 LA-7: the first-cut subset keeps
                    // captures immutable — assigning through a
                    // captured binding is a definite rejection, not
                    // a silent global store (report-over-silence).
                    return Err(CompileError::AssignToCaptured {
                        name: name.clone(),
                        span: *span,
                    });
                } else {
                    let g = self.intern_global(name);
                    self.emit(Opcode::StoreGlobal, g, 0, *span)?;
                }
                Ok(false)
            }
            CoreExpr::Let { bindings, body, .. } => {
                // let* semantics: binding i's value sees slots of
                // bindings 0..i-1 only (the slot is allocated after
                // the value is compiled).
                let mark = self.locals_mark();
                for binding in bindings {
                    self.expr(&binding.value, false)?;
                    let slot = self.alloc_local();
                    self.emit(Opcode::StoreLocal, slot, 0, binding.span)?;
                    self.push_local(binding.name.clone(), slot);
                }
                let terminated = self.expr(body, tail)?;
                self.locals_truncate(mark);
                Ok(terminated)
            }
            CoreExpr::Perform { span, effect, args } => {
                for arg in args {
                    self.expr(arg, false)?;
                }
                let g = self.intern_global(effect);
                self.emit(Opcode::Perform, g, args.len() as u32, *span)?;
                Ok(false)
            }
            CoreExpr::Handle {
                span,
                body,
                handlers,
            } => {
                // handler values are evaluated at installation (any
                // CoreExpr; callability is a 0.6 VM check), then the
                // body runs non-tail (handlers pop before return —
                // plan-0.5.md decision 8).
                for clause in handlers {
                    self.expr(&clause.handler, false)?;
                    let g = self.intern_global(&clause.effect);
                    self.emit(Opcode::PushHandler, g, 0, clause.span)?;
                }
                self.expr(body, false)?;
                self.emit(Opcode::PopHandler, handlers.len() as u32, 0, *span)?;
                Ok(false)
            }
        }
    }

    fn compile_fn(
        &mut self,
        name: Option<&Symbol>,
        span: Span,
        params: &[Symbol],
        body: &CoreExpr,
    ) -> Result<(), CompileError> {
        let idx = self.begin_closure(name.cloned(), params);
        let terminated = self.expr(body, true)?;
        if !terminated {
            self.emit(Opcode::Ret, 0, 0, body.span())?;
        }
        self.end_closure();
        self.emit(Opcode::Closure, idx, 0, span)?;
        Ok(())
    }

    fn item(&mut self, item: &ModuleItem) -> Result<(), CompileError> {
        self.enter_depth(item.span())?;
        let result = self.item_inner(item);
        self.depth -= 1;
        result
    }

    fn item_inner(&mut self, item: &ModuleItem) -> Result<(), CompileError> {
        match item {
            ModuleItem::Define { span, name, value } => {
                if let CoreExpr::Fn {
                    span: fn_span,
                    params,
                    body,
                } = value
                {
                    self.compile_fn(Some(name), *fn_span, params, body)?;
                } else {
                    self.expr(value, false)?;
                }
                let g = self.intern_global(name);
                self.emit(Opcode::StoreGlobal, g, 0, *span)?;
                Ok(())
            }
            ModuleItem::Require { .. } => {
                // Zero code: linking is deferred to VM load time
                // (§19.3 trap 3 — Stage 0 single-module compilation).
                Ok(())
            }
            ModuleItem::DefineSyntax { .. } => {
                // Zero code: the transformer lives in the expansion
                // environment; the declaration record is compile-time
                // bookkeeping only (sub-stage 0.9 — the `Require`
                // zero-code precedent applied to the macro phase).
                Ok(())
            }
            ModuleItem::Extern { items, .. } => {
                // Zero code + the contract record (W-3.2): the entry
                // table rides the product so the non-C engines can
                // name the contract (`ExternCallRequiresBackend`)
                // and the C backend can emit prototypes, wrappers
                // and global seeding. The C-domain floor itself is
                // judged once, at `finish`, over the WHOLE table
                // (the r123 re-attribution — see `finish`).
                for entry in items {
                    self.externs.push(ExternEntry {
                        name: entry.name.clone(),
                        params: entry.params.clone(),
                        ret: entry.ret,
                    });
                }
                Ok(())
            }
            ModuleItem::Module { items, .. } => {
                // Recursive flat compilation; proper scope homes arrive
                // with the 0.9 module system (flat-table precedent).
                for sub in items {
                    self.item(sub)?;
                }
                Ok(())
            }
        }
    }

    fn finish(self) -> Result<Bytecode, CompileError> {
        for p in &self.protos {
            // The pending-jump bookkeeping rides in the stream itself:
            // the first placeholder-sentinel jump in code order is the
            // deterministic defense witness (code order, not emission
            // order).
            if let Some(at) = p.code.iter().position(|i| {
                matches!(i.op, Opcode::Jump | Opcode::JumpIfFalse) && i.a == JUMP_PLACEHOLDER
            }) {
                return Err(CompileError::UnpatchedJump {
                    at,
                    span: p.debug_info[at],
                });
            }
        }
        // The extern contract table's C-domain floor (the r123
        // re-attribution, W-CSYM-EXPR ruling b): the expander no
        // longer early-polices derived-symbol legality or
        // dash/underscore collisions (the frozen subset cannot
        // express them — the .ktf twin boundary retired with the
        // re-attribution); `compile` is the police for the products
        // it builds, so compile output ALWAYS passes verify — the
        // plan-0.5 ruling-4 contract holds unconditionally.
        crate::bytecode::extern_table_floor(&self.externs)?;
        Ok(Bytecode {
            funcs: self
                .protos
                .into_iter()
                .map(|p| FuncProto {
                    name: p.name,
                    params: p.params,
                    n_locals: p.n_locals,
                    // Stage 2.1 LA-1/LA-4: the analysis table lands
                    // as the product's descriptor table — first-use
                    // order, pool-identity keys, sources read from
                    // the defining frame (the LA-2 zero-production
                    // intermediate state flipped by this MUV).
                    captures: p.captures.into_iter().map(|(_, src)| src).collect(),
                    code: p.code,
                    debug_info: p.debug_info,
                })
                .collect(),
            consts: self.consts,
            globals: self.globals,
            externs: self.externs,
        })
    }
}

/// Compile a single expression: the entry proto leaves the value on
/// the stack and `halt`s (depth-1 halt form).
pub fn compile(expr: &CoreExpr) -> Result<Bytecode, CompileError> {
    compile_with_limit(expr, COMPILE_DEPTH_LIMIT)
}

/// [`compile`] with an explicit recursion cap (the K162
/// configurable-guardrail face of the W-REC-DEPTH blade 2: the
/// default cap stays `1024` — [`COMPILE_DEPTH_LIMIT`] — while deep
/// synthesized trees may ride a raised limit).
pub fn compile_with_limit(expr: &CoreExpr, limit: usize) -> Result<Bytecode, CompileError> {
    let mut c = Compiler::with_limit(limit);
    let terminated = c.expr(expr, true)?;
    if !terminated {
        c.emit(Opcode::Halt, 0, 0, expr.span())?;
    }
    c.finish()
}

/// Compile a program (declaration sequence): every `define` nets zero
/// on the stack; the entry proto ends with a depth-0 `halt`.
pub fn compile_program(items: &[ModuleItem]) -> Result<Bytecode, CompileError> {
    compile_program_with_limit(items, COMPILE_DEPTH_LIMIT)
}

/// [`compile_program`] with an explicit recursion cap (the K162
/// configurable-guardrail face of the W-REC-DEPTH blade 2).
pub fn compile_program_with_limit(
    items: &[ModuleItem],
    limit: usize,
) -> Result<Bytecode, CompileError> {
    let mut c = Compiler::with_limit(limit);
    scan_arith_poison(items, &mut c.arith_poison);
    for item in items {
        c.item(item)?;
    }
    let halt_span = c.last_span;
    c.emit(Opcode::Halt, 0, 0, halt_span)?;
    c.finish()
}

/// The four arithmetic builtin names (FA-1): the F1 direct-emission
/// candidates, in the registry's own order (`Builtin::ALL` rows
/// 0-3 — Add/Sub/Mul/Div).
const DIRECT_ARITH_NAMES: [&str; 4] = ["+", "-", "*", "/"];

/// The F1 opcode for an arithmetic builtin name, when the name is
/// one of the four (FA-2's name membership conjunct; the poison and
/// argc conjuncts live at the call site).
fn direct_arith_opcode(name: &Symbol) -> Option<Opcode> {
    match name.as_str() {
        "+" => Some(Opcode::Add),
        "-" => Some(Opcode::Sub),
        "*" => Some(Opcode::Mul),
        "/" => Some(Opcode::Div),
        _ => None,
    }
}

/// Mark `name` poisoned when it is one of the four (FA-1). A single
/// pass appends at most one entry per name; the scan never
/// deduplicates because `Vec::contains` answers the membership
/// question directly and the set is bounded by four.
fn mark_arith_poison(name: &Symbol, poison: &mut Vec<Symbol>) {
    if DIRECT_ARITH_NAMES.contains(&name.as_str()) && !poison.contains(name) {
        poison.push(name.clone());
    }
}

/// The program-wide F1 guard scan (FA-1): walk the whole expanded
/// item tree and poison every arithmetic name a binding face could
/// rebind. Three poison sources — a module `define` (its
/// `store-global` overwrites the seeded builtin slot), an extern
/// entry name (the direct arm would bypass the backend boundary
/// error), and any `assign` (a runtime `store-global` to the slot,
/// at any nesting depth — program-wide, not per-function, because
/// call order between a rebinding function and a calling function
/// is arbitrary). NOT poisoned: let/bind locals, fn params, and
/// captured names (the call site's own local/capture resolution
/// already falls back to the unfused path), perform/handle effect
/// names (read-only slot reads), and `require` (the module graph
/// resolves only in-tree modules, whose items this scan already
/// visits through the `Module` arm — FA-1's completeness note).
fn scan_arith_poison(items: &[ModuleItem], poison: &mut Vec<Symbol>) {
    for item in items {
        match item {
            ModuleItem::Define { name, value, .. } => {
                mark_arith_poison(name, poison);
                scan_arith_poison_expr(value, poison);
            }
            ModuleItem::Extern { items, .. } => {
                for entry in items {
                    mark_arith_poison(&entry.name, poison);
                }
            }
            ModuleItem::Module { items, .. } => scan_arith_poison(items, poison),
            ModuleItem::Require { .. } | ModuleItem::DefineSyntax { .. } => {}
        }
    }
}

/// The expression half of the F1 guard scan: every `assign` target
/// anywhere in the tree poisons its name (locals included — a
/// local `assign` to an arithmetic name is conservatively treated
/// as a potential global store; the rare program that assigns a
/// local `+` simply loses the optimization, never correctness).
fn scan_arith_poison_expr(expr: &CoreExpr, poison: &mut Vec<Symbol>) {
    match expr {
        CoreExpr::Assign { name, value, .. } => {
            mark_arith_poison(name, poison);
            scan_arith_poison_expr(value, poison);
        }
        CoreExpr::Apply { func, args, .. } => {
            scan_arith_poison_expr(func, poison);
            for arg in args {
                scan_arith_poison_expr(arg, poison);
            }
        }
        CoreExpr::Fn { body, .. } => scan_arith_poison_expr(body, poison),
        CoreExpr::Handle { body, handlers, .. } => {
            scan_arith_poison_expr(body, poison);
            for clause in handlers {
                scan_arith_poison_expr(&clause.handler, poison);
            }
        }
        CoreExpr::If {
            cond,
            then_branch,
            else_branch,
            ..
        } => {
            scan_arith_poison_expr(cond, poison);
            scan_arith_poison_expr(then_branch, poison);
            scan_arith_poison_expr(else_branch, poison);
        }
        CoreExpr::Let { bindings, body, .. } => {
            for binding in bindings {
                scan_arith_poison_expr(&binding.value, poison);
            }
            scan_arith_poison_expr(body, poison);
        }
        CoreExpr::Perform { args, .. } => {
            for arg in args {
                scan_arith_poison_expr(arg, poison);
            }
        }
        CoreExpr::Var { .. } | CoreExpr::Literal { .. } => {}
    }
}

#[cfg(test)]
mod tests {
    //! Translation tests (FP2/FP3): per-primitive instruction shapes,
    //! the tail-If contract, pool dedup, and the compile-time defense
    //! paths (depth cap, unpatched placeholder, patch assertion).

    use super::*;
    use crate::bytecode::Bytecode;
    use kerf_core::HandlerClause;
    use kerf_core::{ExternAbi, ExternItem, ExternType};
    use kerf_span::{ByteOffset as B, ExpansionId, FileId as F};

    fn s(start: u32, end: u32) -> Span {
        Span::new(F(0), B(start), B(end), ExpansionId::ROOT).expect("fixture span")
    }

    fn lit(v: i64) -> CoreExpr {
        CoreExpr::Literal {
            span: s(0, 2),
            value: LiteralValue::Int(v),
        }
    }

    fn var(name: &str) -> CoreExpr {
        CoreExpr::var(s(0, 1), name).unwrap()
    }

    fn ops(bc: &Bytecode, func: usize) -> Vec<Opcode> {
        bc.funcs[func].code.iter().map(|i| i.op).collect()
    }

    #[test]
    fn literal_var_forms_and_const_pool_dedup() {
        // (f 1 1 2): value forms plus pool dedup in one program.
        let program = CoreExpr::Apply {
            span: s(0, 8),
            func: Box::new(var("f")),
            args: vec![lit(1), lit(1), lit(2)],
        };
        let bc = compile(&program).unwrap();
        assert_eq!(
            bc.consts.len(),
            2,
            "duplicate int literals share one pool slot"
        );
        assert_eq!(bc.consts[0], LiteralValue::Int(1));
        assert_eq!(bc.consts[1], LiteralValue::Int(2));
        // NaN folding: distinct NaN payloads collapse to one slot.
        let nan_a = CoreExpr::Literal {
            span: s(0, 3),
            value: LiteralValue::Float(f64::NAN),
        };
        let nan_b = CoreExpr::Literal {
            span: s(0, 3),
            value: LiteralValue::Float(f64::NAN.copysign(-1.0)),
        };
        let both = CoreExpr::Apply {
            span: s(0, 6),
            func: Box::new(var("g")),
            args: vec![nan_a, nan_b],
        };
        let bc2 = compile(&both).unwrap();
        assert_eq!(
            bc2.consts.len(),
            1,
            "all NaNs fold into a single canonical slot"
        );
        // var: global form when no local is in scope; call arity.
        assert_eq!(
            ops(&bc, 0),
            vec![
                Opcode::PushConst,
                Opcode::PushConst,
                Opcode::PushConst,
                Opcode::CallGlobal,
                Opcode::Halt,
            ]
        );
        // W-VM-SUPERINSTR: the fused instruction carries the global
        // slot in a and the argc in b (SI-2 — the Perform convention).
        assert_eq!(bc.funcs[0].code[3].a, 0, "first global intern gets slot 0");
        assert_eq!(bc.funcs[0].code[3].b, 3, "the fused b slot counts the args");
        assert!(bc.verify().is_ok());
    }

    #[test]
    fn fn_closure_apply_and_eval_order() {
        // (fn (x) (f x 7)): closure proto, then apply with args before
        // the callee (eval-order contract).
        let body = CoreExpr::Apply {
            span: s(4, 12),
            func: Box::new(var("f")),
            args: vec![var("x"), lit(7)],
        };
        let f = CoreExpr::fn_(s(0, 12), &["x"], body).unwrap();
        let bc = compile(&f).unwrap();
        assert_eq!(bc.funcs.len(), 2, "entry + one closure proto");
        assert_eq!(bc.funcs[1].params, 1);
        assert_eq!(bc.funcs[1].n_locals, 1, "params occupy local slots");
        // entry: closure + halt; closure: load-local-const x 7 (the
        // fused copy pair, W-JIT-METHOD-T1 TJ-1), call-global f 2,
        // ret (the fused call form, W-VM-SUPERINSTR).
        assert_eq!(ops(&bc, 0), vec![Opcode::Closure, Opcode::Halt]);
        assert_eq!(
            ops(&bc, 1),
            vec![Opcode::LoadLocalConst, Opcode::CallGlobal, Opcode::Ret,]
        );
        assert_eq!(bc.funcs[1].code[0].a, 0, "param x lives in slot 0");
        assert_eq!(bc.funcs[1].code[1].b, 2, "the fused argc rides b");
        assert!(bc.verify().is_ok(), "compile output always passes verify");
    }

    #[test]
    fn if_forms_tail_and_non_tail() {
        // Non-tail if (as an argument): jump-if-false + merge jump.
        let call = CoreExpr::Apply {
            span: s(0, 10),
            func: Box::new(var("g")),
            args: vec![CoreExpr::If {
                span: s(1, 9),
                cond: Box::new(var("c")),
                then_branch: Box::new(lit(1)),
                else_branch: Box::new(lit(2)),
            }],
        };
        let bc = compile(&call).unwrap();
        assert_eq!(
            ops(&bc, 0),
            vec![
                Opcode::LoadGlobal, // c
                Opcode::JumpIfFalse,
                Opcode::PushConst,  // 1
                Opcode::Jump,       // merge
                Opcode::PushConst,  // 2
                Opcode::CallGlobal, // g (fused, W-VM-SUPERINSTR)
                Opcode::Halt,
            ]
        );
        let jf_target = bc.funcs[0].code[1].a as usize;
        let j_target = bc.funcs[0].code[3].a as usize;
        assert_eq!(
            jf_target, 4,
            "else entry is the instruction after the merge jump"
        );
        assert_eq!(j_target, 5, "merge point is right after else");
        // Tail if (fn body): branches end in ret, no merge jump.
        let f = CoreExpr::fn_(
            s(0, 12),
            &["x"],
            CoreExpr::If {
                span: s(8, 12),
                cond: Box::new(var("x")),
                then_branch: Box::new(lit(1)),
                else_branch: Box::new(lit(2)),
            },
        )
        .unwrap();
        let bc2 = compile(&f).unwrap();
        assert_eq!(
            ops(&bc2, 1),
            vec![
                Opcode::LoadLocal,
                Opcode::JumpIfFalse,
                Opcode::PushConst,
                Opcode::Ret, // tail terminator, then-branch
                Opcode::PushConst,
                Opcode::Ret, // explicit fn-body ret (else falls through)
            ],
            "tail if has no merge jump — branches go straight to ret"
        );
        assert_eq!(
            bc2.funcs[1].code[1].a as usize, 4,
            "else entry after then's ret"
        );
        assert!(bc2.verify().is_ok());
    }

    #[test]
    fn let_assign_perform_handle_forms() {
        // (let ((x 1) (y 2)) (set! x (perform read))) — let chain,
        // assign dup+store, perform with argc 0.
        let perform = CoreExpr::perform(s(9, 21), "read", vec![]).unwrap();
        let assign = CoreExpr::assign(s(9, 21), "x", perform).unwrap();
        let letform = CoreExpr::Let {
            span: s(0, 22),
            bindings: vec![
                kerf_core::Binding::new(s(6, 7), "x", lit(1)).unwrap(),
                kerf_core::Binding::new(s(7, 8), "y", lit(2)).unwrap(),
            ],
            body: Box::new(assign),
        };
        let bc = compile(&letform).unwrap();
        assert_eq!(
            ops(&bc, 0),
            vec![
                Opcode::PushConst,  // 1
                Opcode::StoreLocal, // x -> slot 0
                Opcode::PushConst,  // 2
                Opcode::StoreLocal, // y -> slot 1
                Opcode::Perform,    // read, argc 0
                Opcode::Dup,
                Opcode::StoreLocal, // assign x
                Opcode::Halt,
            ]
        );
        assert_eq!(bc.funcs[0].n_locals, 2);
        assert_eq!(bc.funcs[0].code[1].a, 0);
        assert_eq!(bc.funcs[0].code[3].a, 1);
        assert_eq!(bc.funcs[0].code[6].a, 0, "assign resolves innermost x");
        assert_eq!(
            bc.funcs[0].code[4].a, 0,
            "effect name interns in the global table"
        );
        assert_eq!(bc.globals[0].as_str(), "read");
        assert!(bc.verify().is_ok());
        // handle: two clauses -> push-handler x2, body, pop-handler 2.
        let handled = CoreExpr::handle(
            s(0, 10),
            var("body-val"),
            vec![
                kerf_core::HandlerClause::new(s(2, 4), "read", var("h1")).unwrap(),
                kerf_core::HandlerClause::new(s(4, 6), "write", var("h2")).unwrap(),
            ],
        )
        .unwrap();
        let bc2 = compile(&handled).unwrap();
        assert_eq!(
            ops(&bc2, 0),
            vec![
                Opcode::LoadGlobal, // h1
                Opcode::PushHandler,
                Opcode::LoadGlobal, // h2
                Opcode::PushHandler,
                Opcode::LoadGlobal, // body
                Opcode::PopHandler,
                Opcode::Halt,
            ]
        );
        assert_eq!(bc2.funcs[0].code[5].a, 2, "pop-handler counts both clauses");
        // Intern order follows evaluation order: handler values first,
        // then the effect name of each clause.
        assert_eq!(bc2.globals[0].as_str(), "h1");
        assert_eq!(bc2.globals[1].as_str(), "read");
        assert_eq!(bc2.globals[2].as_str(), "h2");
        assert_eq!(bc2.globals[3].as_str(), "write");
        assert!(bc2.verify().is_ok());
    }

    #[test]
    fn depth_cap_rejects_synthesized_deep_tree_and_boundary_passes() {
        fn deep_apply(n: usize) -> CoreExpr {
            let mut e = lit(42);
            for _ in 0..n {
                e = CoreExpr::Apply {
                    span: s(0, 1),
                    func: Box::new(var("f")),
                    args: vec![e],
                };
            }
            e
        }
        // n nested applies -> recursion depth n + 1 (applies + inner
        // literal): n = 1023 peaks exactly at the limit and passes.
        let ok = compile(&deep_apply(COMPILE_DEPTH_LIMIT - 1)).unwrap();
        assert!(ok.verify().is_ok());
        // n = 1024 peaks one over the cap: structured rejection.
        let err = compile(&deep_apply(COMPILE_DEPTH_LIMIT)).unwrap_err();
        assert!(matches!(
            err,
            CompileError::DepthExceeded { depth: 1025, .. }
        ));
    }

    #[test]
    fn codebuf_unpatched_jump_defense_fires_at_finish() {
        // Internal defense: a placeholder that never got patched must
        // surface as a structured error at finish, not as a bad
        // product (the placeholder sentinel would fail verify as an
        // out-of-range target — this defense fires first, at the
        // producer).
        let mut c = Compiler::new();
        c.expr(&lit(1), false).unwrap();
        let jf = c.emit_jump(Opcode::JumpIfFalse, s(0, 1)).unwrap();
        // the pending bookkeeping rides in the stream: sentinel `a`,
        // source depth in `b`
        assert_eq!(c.protos[0].code[jf].a, JUMP_PLACEHOLDER);
        assert_eq!(c.protos[0].code[jf].b, 0, "depth after the pop");
        c.emit(Opcode::Halt, 0, 0, s(0, 1)).unwrap();
        let err = c.finish().unwrap_err();
        assert!(matches!(err, CompileError::UnpatchedJump { at, .. } if at == jf));
    }

    #[test]
    fn codebuf_patch_depth_assertion_defense() {
        // Internal defense: patching with a mismatched current depth
        // (the else-entry reset was skipped) is a bookkeeping bug and
        // must fail closed instead of emitting a skewed target.
        let mut c = Compiler::new();
        c.expr(&var("c"), false).unwrap();
        let jf = c.emit_jump(Opcode::JumpIfFalse, s(0, 1)).unwrap();
        // then-branch leaves one extra value on the linear depth;
        // forget the reset and patch directly.
        c.expr(&lit(1), false).unwrap();
        let err = c.patch(jf, c.here()).unwrap_err();
        assert!(matches!(
            err,
            CompileError::StackImbalance { pc, expected: 0, actual: 1, .. } if pc == jf
        ));
    }

    #[test]
    fn const_pool_pred_carries_slot_identity_end_to_end() {
        // EMI-1 guard: the pre-hashed index is only a hint; slot
        // identity is the predicate's. Signed zeros stay distinct
        // slots, strings and pair structures dedup by content, and
        // the pool keeps first-use order.
        let zpos = CoreExpr::Literal {
            span: s(0, 3),
            value: LiteralValue::Float(0.0),
        };
        let zneg = CoreExpr::Literal {
            span: s(0, 3),
            value: LiteralValue::Float(-0.0),
        };
        let bc = compile(&CoreExpr::Apply {
            span: s(0, 6),
            func: Box::new(var("f")),
            args: vec![zpos.clone(), zneg, zpos],
        })
        .unwrap();
        assert_eq!(bc.consts.len(), 2, "+0.0 and -0.0 are distinct slots");
        assert_eq!(bc.consts[0], LiteralValue::Float(0.0));
        assert_eq!(bc.consts[1], LiteralValue::Float(-0.0));

        let strlit = |text: &str| CoreExpr::Literal {
            span: s(0, 4),
            value: LiteralValue::String(text.into()),
        };
        let pair = |car: i64, cdr: i64| CoreExpr::Literal {
            span: s(0, 8),
            value: LiteralValue::Pair(
                Box::new(LiteralValue::Int(car)),
                Box::new(LiteralValue::Int(cdr)),
            ),
        };
        let bc2 = compile(&CoreExpr::Apply {
            span: s(0, 10),
            func: Box::new(var("g")),
            args: vec![
                strlit("abc"),
                strlit("abc"),
                strlit("abd"),
                pair(1, 2),
                pair(1, 2),
            ],
        })
        .unwrap();
        assert_eq!(
            bc2.consts.len(),
            3,
            "strings and pairs dedup by content: abc, abd, (1 . 2)"
        );
        assert_eq!(bc2.consts[0], LiteralValue::String("abc".into()));
        assert_eq!(bc2.consts[1], LiteralValue::String("abd".into()));
        assert_eq!(
            bc2.consts[2],
            LiteralValue::Pair(
                Box::new(LiteralValue::Int(1)),
                Box::new(LiteralValue::Int(2))
            )
        );
        assert!(bc2.verify().is_ok());

        // §9.72 SYN-1 guard: interning a literal into the pool clones the
        // shared payload (pointer, not bytes) — the pool entry and the
        // source expression alias one allocation. Re-interning the same
        // literal returns the same slot, so the whole program keeps one
        // `Rc<str>` per distinct string constant.
        let original = LiteralValue::String("shared".into());
        let rc_of = |v: &LiteralValue| match v {
            LiteralValue::String(s) => std::rc::Rc::clone(s),
            _ => panic!("expected a string literal"),
        };
        let bc3 = compile(&CoreExpr::Apply {
            span: s(0, 10),
            func: Box::new(var("h")),
            args: vec![
                CoreExpr::Literal {
                    span: s(0, 4),
                    value: original.clone(),
                },
                CoreExpr::Literal {
                    span: s(0, 4),
                    value: original.clone(),
                },
            ],
        })
        .unwrap();
        assert_eq!(bc3.consts.len(), 1, "identical strings share one slot");
        assert!(
            std::rc::Rc::ptr_eq(&rc_of(&bc3.consts[0]), &rc_of(&original)),
            "the pool entry must alias the literal's allocation"
        );
    }

    #[test]
    fn let_slots_reuse_across_sibling_scopes() {
        // EMI-3 guard: a slot freed at scope exit is handed to the
        // next binding (Lua freereg discipline) — n_locals tracks the
        // peak simultaneous bindings, not the cumulative count.
        let branch = |name: &str| CoreExpr::Let {
            span: s(0, 10),
            bindings: vec![kerf_core::Binding::new(s(1, 2), name, lit(7)).unwrap()],
            body: Box::new(var(name)),
        };
        // (if c (let ((a 7)) a) (let ((b 7)) b)): the then-scope's
        // slot frees at the branch boundary, the else-scope reuses it.
        let sibling = CoreExpr::If {
            span: s(0, 20),
            cond: Box::new(var("c")),
            then_branch: Box::new(branch("a")),
            else_branch: Box::new(branch("b")),
        };
        let bc = compile(&sibling).unwrap();
        assert_eq!(bc.funcs[0].n_locals, 1, "sibling scopes share one slot");
        let stores: Vec<(Opcode, u32)> = bc.funcs[0]
            .code
            .iter()
            .filter(|i| matches!(i.op, Opcode::StoreLocal | Opcode::LoadLocal))
            .map(|i| (i.op, i.a))
            .collect();
        assert_eq!(
            stores,
            vec![
                (Opcode::StoreLocal, 0),
                (Opcode::LoadLocal, 0),
                (Opcode::StoreLocal, 0),
                (Opcode::LoadLocal, 0),
            ],
            "both branches store and read THE SAME recycled slot 0"
        );
        assert!(bc.verify().is_ok());

        // shadowing: an inner same-name binding is allocated a FRESH
        // slot while the outer binding is still live.
        let shadow = CoreExpr::Let {
            span: s(0, 12),
            bindings: vec![kerf_core::Binding::new(s(1, 2), "x", lit(1)).unwrap()],
            body: Box::new(CoreExpr::Let {
                span: s(4, 12),
                bindings: vec![kerf_core::Binding::new(s(5, 6), "x", lit(2)).unwrap()],
                body: Box::new(var("x")),
            }),
        };
        let bc2 = compile(&shadow).unwrap();
        assert_eq!(bc2.funcs[0].n_locals, 2, "simultaneously live bindings");
        assert_eq!(bc2.funcs[0].code[1].a, 0, "outer x binds slot 0");
        assert_eq!(bc2.funcs[0].code[3].a, 1, "inner x binds slot 1");
        assert_eq!(
            bc2.funcs[0].code[4].a, 1,
            "the body resolves the innermost x"
        );
        assert!(bc2.verify().is_ok());
    }

    #[test]
    fn patched_jumps_restore_the_zero_operand_contract() {
        // EMI-2 guard: the source depth rides in `b` only while a
        // jump is pending; a finished product has b == 0 for every
        // jump (the "unused slot is always 0" output contract).
        let program = CoreExpr::If {
            span: s(0, 20),
            cond: Box::new(var("c")),
            then_branch: Box::new(lit(1)),
            else_branch: Box::new(CoreExpr::If {
                span: s(8, 20),
                cond: Box::new(var("d")),
                then_branch: Box::new(lit(2)),
                else_branch: Box::new(lit(3)),
            }),
        };
        let bc = compile(&program).unwrap();
        let jumps: Vec<&Instr> = bc.funcs[0]
            .code
            .iter()
            .filter(|i| matches!(i.op, Opcode::Jump | Opcode::JumpIfFalse))
            .collect();
        assert!(jumps.len() >= 3, "outer + inner if jumps");
        for j in jumps {
            assert_ne!(j.a, JUMP_PLACEHOLDER, "every jump is patched");
            assert_eq!(j.b, 0, "the depth bookkeeping is cleared at patch");
            assert!(j.a < bc.funcs[0].code.len() as u32);
        }
        assert!(bc.verify().is_ok());
    }

    // ---- 0.6-round regression pair (0.5 defect: `end_closure`
    // decremented `cur` instead of restoring the saved caller —
    // every program with a second, sibling, or nested closure past
    // the first emitted into the wrong proto) ----

    #[test]
    fn sibling_closures_compile_into_their_caller_not_each_other() {
        // Two top-level defines each holding a closure: the second
        // closure's `closure` opcode must land in the ENTRY proto
        // (previously it landed inside the first closure's proto).
        let f = ModuleItem::Define {
            span: s(0, 4),
            name: Symbol::new("f").unwrap(),
            value: CoreExpr::fn_(s(0, 4), &["x"], lit(1)).unwrap(),
        };
        let g = ModuleItem::Define {
            span: s(5, 9),
            name: Symbol::new("g").unwrap(),
            value: CoreExpr::fn_(s(5, 9), &["y"], lit(2)).unwrap(),
        };
        let bc = compile_program(&[f, g]).expect("sibling closures compile");
        bc.verify().expect("sibling closures verify");
        assert_eq!(bc.funcs.len(), 3);
        // The entry references both closure protos.
        let entry_ops: Vec<u32> = bc.funcs[0]
            .code
            .iter()
            .filter(|i| i.op == Opcode::Closure)
            .map(|i| i.a)
            .collect();
        assert_eq!(entry_ops, vec![1, 2]);
        // Each closure proto holds exactly its own body (one const +
        // one ret) — no spillover from the sibling.
        for fi in [1usize, 2] {
            assert_eq!(bc.funcs[fi].code.len(), 2, "proto {fi} must stay closed");
            assert_eq!(bc.funcs[fi].code[1].op, Opcode::Ret);
        }
    }

    #[test]
    fn capture_analysis_emits_load_captured_for_free_names() {
        // (let ((n 5)) (fn (x) (+ x n))): the closure proto captures
        // `n` as the defining frame's Local(0) (first-use index 0)
        // and reads it through load-captured — the LA-1/LA-3 flip.
        let inner = CoreExpr::fn_(
            s(14, 30),
            &["x"],
            CoreExpr::Apply {
                span: s(16, 28),
                func: Box::new(var("+")),
                args: vec![var("x"), var("n")],
            },
        )
        .unwrap();
        let letform = CoreExpr::Let {
            span: s(0, 30),
            bindings: vec![kerf_core::Binding::new(s(6, 7), "n", lit(5)).unwrap()],
            body: Box::new(inner),
        };
        let bc = compile(&letform).unwrap();
        assert_eq!(bc.funcs.len(), 2, "entry + the closure proto");
        let closure = &bc.funcs[1];
        assert_eq!(
            closure.captures,
            vec![CaptureSource::Local(0)],
            "n captures as the defining frame's local 0"
        );
        assert!(
            closure
                .code
                .iter()
                .any(|i| i.op == Opcode::LoadCaptured && i.a == 0)
        );
        assert!(bc.verify().is_ok(), "compile output always passes verify");
        // The global table never interns `n` (the capture resolved it).
        assert!(!bc.globals.iter().any(|g| g.as_str() == "n"));
    }

    #[test]
    fn capture_transitive_chain_builds_pass_through_descriptors() {
        // (fn (a) (fn (b) (fn (c) (+ a c)))): the innermost proto
        // reads `a`, which only the OUTERMOST frame holds — the
        // middle proto must capture `a` purely as a pass-through
        // (its own body never reads it), so the innermost
        // `Captured(0)` source has supply — the LA-4 discipline.
        let inner = CoreExpr::fn_(
            s(10, 34),
            &["c"],
            CoreExpr::Apply {
                span: s(12, 32),
                func: Box::new(var("+")),
                args: vec![var("a"), var("c")],
            },
        )
        .unwrap();
        let middle = CoreExpr::fn_(s(9, 35), &["b"], inner).unwrap();
        let outer = CoreExpr::fn_(s(0, 35), &["a"], middle).unwrap();
        let bc = compile(&outer).unwrap();
        assert_eq!(bc.funcs.len(), 4, "entry + outer + middle + inner protos");
        // outer: no captures (its body has no free names).
        assert!(bc.funcs[1].captures.is_empty());
        // middle: captures `a` from outer's frame — pass-through.
        assert_eq!(bc.funcs[2].captures, vec![CaptureSource::Local(0)]);
        // inner: captures `a` from the MIDDLE closure's capture area.
        assert_eq!(bc.funcs[3].captures, vec![CaptureSource::Captured(0)]);
        assert!(
            bc.funcs[3]
                .code
                .iter()
                .any(|i| i.op == Opcode::LoadCaptured && i.a == 0)
        );
        assert!(bc.verify().is_ok());
    }

    #[test]
    fn capture_shadowing_prefers_the_innermost_binding() {
        // (let ((x 1)) (fn (x) x)): the param shadows the outer `x` —
        // the body reads its OWN local (load-local), never captures.
        let inner = CoreExpr::fn_(s(14, 24), &["x"], var("x")).unwrap();
        let letform = CoreExpr::Let {
            span: s(0, 24),
            bindings: vec![kerf_core::Binding::new(s(6, 7), "x", lit(1)).unwrap()],
            body: Box::new(inner),
        };
        let bc = compile(&letform).unwrap();
        let closure = &bc.funcs[1];
        assert!(closure.captures.is_empty(), "the shadowing param wins");
        assert!(
            closure
                .code
                .iter()
                .any(|i| i.op == Opcode::LoadLocal && i.a == 0)
        );
        assert!(bc.verify().is_ok());
    }

    #[test]
    fn assign_to_captured_is_rejected_with_the_boundary_error() {
        // (let ((n 5)) (fn (x) (set! n 1))): the store targets the
        // captured `n` — the LA-7 immutable-capture subset rejects it
        // at compile time (the checker reports E0012 first on the
        // source path; this is the direct-construction face).
        let assign = CoreExpr::assign(s(14, 24), "n", lit(1)).unwrap();
        let inner = CoreExpr::fn_(s(10, 24), &["x"], assign).unwrap();
        let letform = CoreExpr::Let {
            span: s(0, 24),
            bindings: vec![kerf_core::Binding::new(s(6, 7), "n", lit(5)).unwrap()],
            body: Box::new(inner),
        };
        match compile(&letform) {
            Err(CompileError::AssignToCaptured { name, .. }) => {
                assert_eq!(name.as_str(), "n");
            }
            other => panic!("expected the assign-to-captured boundary, got {other:?}"),
        }
    }

    #[test]
    fn nested_closures_restore_the_exact_caller_proto() {
        // A closure compiled from inside another closure's HANDLE
        // clause: after the inner fn finishes, emission continues in
        // the proto that was current BEFORE the handle (previously
        // the corrupted `cur` sent the rest of the program into the
        // outer handler's proto, leaving the entry unterminated).
        let inner_fn = CoreExpr::fn_(s(20, 40), &["v"], lit(7)).unwrap();
        let handle = CoreExpr::handle(
            s(10, 45),
            lit(3),
            vec![HandlerClause::new(s(30, 40), "e", inner_fn).unwrap()],
        )
        .unwrap();
        let item = ModuleItem::Define {
            span: s(0, 45),
            name: Symbol::new("r").unwrap(),
            value: handle,
        };
        let bc = compile_program(&[item]).expect("nested closure compiles");
        bc.verify()
            .expect("nested closure product verifies (the 0.5 defect failed here)");
        assert_eq!(bc.funcs.len(), 2);
        // Entry: closure, push-handler, body const, pop-handler,
        // store-global, halt — the inner closure's opcode is IN the
        // entry, and the handler proto stays two instructions.
        let ops: Vec<Opcode> = bc.funcs[0].code.iter().map(|i| i.op).collect();
        assert_eq!(
            ops,
            vec![
                Opcode::Closure,
                Opcode::PushHandler,
                Opcode::PushConst,
                Opcode::PopHandler,
                Opcode::StoreGlobal,
                Opcode::Halt,
            ]
        );
        assert_eq!(bc.funcs[1].code.len(), 2);
    }

    #[test]
    fn global_table_reaches_every_define_and_referenced_builtin() {
        // Contract guard (stage0.md §9.60.5): `bc.globals` is the
        // *global name table* — every name the bytecode can reach,
        // interned at first use (LoadGlobal references, set!
        // targets, effect names, and defines; see `intern_global`
        // and its five call sites). Two rosters, two contracts:
        // this table is the VM's observation face (the vs01-vs10
        // golden face reports builtins like `+=#<builtin:+>`), the
        // AST define walk is the Eval/parity face. This guard pins
        // the relationship: every define lands in the table, and a
        // reference pulls its name in even without a define.
        let items = vec![
            ModuleItem::Define {
                span: s(0, 4),
                name: Symbol::new("alpha").unwrap(),
                value: lit(1),
            },
            ModuleItem::Require {
                span: s(5, 9),
                module: Symbol::new("dep").unwrap(),
            },
            ModuleItem::DefineSyntax {
                span: s(10, 14),
                name: Symbol::new("m").unwrap(),
            },
            ModuleItem::Define {
                span: s(15, 19),
                name: Symbol::new("beta").unwrap(),
                value: lit(2),
            },
        ];
        let bc = compile_program(&items).expect("mixed module compiles");
        let table: Vec<&str> = bc.globals.iter().map(|g| g.as_str()).collect();
        // Every define is reachable in the table (alpha before beta:
        // first-use order follows program order here).
        assert!(
            table.contains(&"alpha"),
            "define alpha must be in the table"
        );
        assert!(table.contains(&"beta"), "define beta must be in the table");
        // A program of pure defines (no builtin references, no
        // effects) interns exactly the define sequence — nothing
        // more, nothing less.
        assert_eq!(table, vec!["alpha", "beta"]);
        // A builtin *reference* pulls the builtin name into the
        // table even though no define binds it — the observation
        // face the vs goldens pin (`+=#<builtin:+> r=3`).
        // r134 regeneration (W-VM-SUPERINSTR FA-4): the vs01 shape
        // `(define r (+ 1 2))` now direct-emits `add` — a
        // direct-only arithmetic reference NEVER interns (the
        // table carries no slot for a name no instruction
        // references). The observation face survives through the
        // non-direct paths, pinned by both conjuncts below.
        // Explicit case 1 (FA-4, the direct-only reference):
        // (define r (+ 1 2)) interns exactly `r`.
        let items = vec![ModuleItem::Define {
            span: s(0, 18),
            name: Symbol::new("r").unwrap(),
            value: CoreExpr::Apply {
                span: s(0, 18),
                func: Box::new(CoreExpr::var(s(0, 1), "+").unwrap()),
                args: vec![lit(1), lit(2)],
            },
        }];
        let bc = compile_program(&items).expect("vs01-shaped program compiles");
        let table: Vec<&str> = bc.globals.iter().map(|g| g.as_str()).collect();
        assert_eq!(
            table,
            vec!["r"],
            "FA-4: a direct-only arithmetic reference never interns"
        );
        // Explicit case 2 (the load-global reference still interns):
        // (define op +) references `+` as a VALUE — the plain var
        // walk interns it (first use), and the observation face
        // keeps its `+=#<builtin:+>` row.
        let plus = CoreExpr::var(s(0, 1), "+").unwrap();
        let items = vec![
            ModuleItem::Define {
                span: s(0, 13),
                name: Symbol::new("op").unwrap(),
                value: plus,
            },
            ModuleItem::Define {
                span: s(14, 32),
                name: Symbol::new("r").unwrap(),
                value: lit(3),
            },
        ];
        let bc = compile_program(&items).expect("the value-reference program compiles");
        let table: Vec<&str> = bc.globals.iter().map(|g| g.as_str()).collect();
        assert_eq!(
            table,
            vec!["+", "op", "r"],
            "a load-global builtin reference still interns (the vs face)"
        );
    }

    #[test]
    fn extern_table_floor_rejects_c_domain_defects_at_compile() {
        // The r123 re-attribution (W-CSYM-EXPR ruling b): the
        // derived-C-symbol faces are product constraints — `compile`
        // is the police for the products it builds (`verify` judges
        // hand-built ones; both share `extern_table_floor`).
        fn extern_item(name: &str) -> ExternItem {
            ExternItem {
                span: s(0, 20),
                name: Symbol::new(name).expect("symbol"),
                params: vec![],
                ret: ExternType::Int,
            }
        }
        // Invalid derived C symbol (set! keeps its `!`).
        let block = ModuleItem::extern_block(s(0, 20), ExternAbi::C, vec![extern_item("set!")])
            .expect("the checked constructor passes (the symbol floor only)");
        match compile_program(&[block]) {
            Err(CompileError::ExternSymbolInvalid { index, name }) => {
                assert_eq!(index, 0);
                assert_eq!(name, Symbol::new("set!").expect("symbol"));
            }
            other => panic!("the invalid C symbol rejects at compile, got {other:?}"),
        }
        // Dash/underscore derived collision across spellings.
        let block = ModuleItem::extern_block(
            s(0, 40),
            ExternAbi::C,
            vec![extern_item("my-add"), extern_item("my_add")],
        )
        .expect("the checked constructor passes");
        match compile_program(&[block]) {
            Err(CompileError::ExternSymbolCollision { index, name, other }) => {
                assert_eq!(index, 1);
                assert_eq!(name, Symbol::new("my_add").expect("symbol"));
                assert_eq!(other, Symbol::new("my-add").expect("symbol"));
            }
            other => panic!("the derived collision rejects at compile, got {other:?}"),
        }
        // Duplicate canonical names across TWO blocks — the
        // full-table judge (the expander's within-block face never
        // sees this shape).
        let b1 = ModuleItem::extern_block(s(0, 20), ExternAbi::C, vec![extern_item("add")])
            .expect("block one");
        let b2 = ModuleItem::extern_block(s(20, 40), ExternAbi::C, vec![extern_item("add")])
            .expect("block two");
        match compile_program(&[b1, b2]) {
            Err(CompileError::ExternNameDuplicate { index, name }) => {
                assert_eq!(index, 1);
                assert_eq!(name, Symbol::new("add").expect("symbol"));
            }
            other => panic!("the cross-block duplicate rejects at compile, got {other:?}"),
        }
        // A legal contract compiles and verifies — the plan-0.5
        // ruling-4 contract holds unconditionally since the
        // re-attribution (compile polices its own products).
        let block = ModuleItem::extern_block(s(0, 20), ExternAbi::C, vec![extern_item("my-add")])
            .expect("legal");
        let bc = compile_program(&[block]).expect("the legal contract compiles");
        bc.verify().expect("compile output always passes verify");
    }
}

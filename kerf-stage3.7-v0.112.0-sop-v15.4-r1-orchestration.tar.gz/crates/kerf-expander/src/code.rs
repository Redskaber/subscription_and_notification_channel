//! CodeValue: the structured macro-phase code value (sub-stage 0.9).
//!
//! Stage 0 projection of the design's structured code value
//! (docs/stage0.md §6.1/§6.3 — the typed multi-stage `CodeValue` face):
//! the Stage 0 carrier is the [`SyntaxObject`] itself, so a `CodeValue`
//! is a *disciplined view* over one syntax node — the datum plus its
//! hygiene metadata (span, scopes, phase) — with the transformer-facing
//! operations the macro system needs:
//! - [`CodeValue::substitute`] — the pattern-variable splice face
//!   (syntax-rules template instantiation is its single-pass production
//!   consumer in `transformer.rs`);
//! - [`CodeValue::alpha_rename`] — the rename-on-capture remedy face
//!   (docs/stage0.md §9.38(b) second algorithm, kept public; the
//!   production hygiene mechanism of this stage is scope coloring);
//! - [`CodeValue::symbols`] — the symbol census (the Stage 0 stand-in
//!   for the design's `free_variables`: no type layer and no binder
//!   model exists yet, so "free" cannot be decided — the honest name
//!   and semantics are recorded here, the semantic upgrade is the
//!   Stage 2+ evolution slot);
//! - [`CodeValue::to_source`] — the S-expression display (macro
//!   diagnostics observability face).
//!
//! All operations are total (no fallible face): they walk datum
//! structure only and never invent spans or scopes (every product node
//! copies its origin node's metadata verbatim — the TD-002/§19.2 span
//! discipline).

use kerf_span::{Span, Symbol};
use kerf_syntax::{Phase, ScopeSet, StxDatum, SyntaxObject};

/// One structured code value: a syntax node viewed as a first-class
/// macro-phase value.
#[derive(Debug, Clone, PartialEq)]
pub struct CodeValue {
    syntax: SyntaxObject,
}

impl CodeValue {
    /// Wrap one syntax node (the "quote" construction face — the node
    /// keeps its own span, scopes and phase; nothing is synthesized).
    pub fn from_syntax(syntax: &SyntaxObject) -> Self {
        CodeValue {
            syntax: syntax.clone(),
        }
    }

    /// The expansion input face: hand the wrapped node back to the
    /// expansion loop.
    pub fn to_syntax(&self) -> &SyntaxObject {
        &self.syntax
    }

    /// The wrapped node's span (metadata accessor).
    pub fn span(&self) -> Span {
        self.syntax.span
    }

    /// The wrapped node's scope set (metadata accessor — the hygiene
    /// coloring of this code).
    pub fn scopes(&self) -> &ScopeSet {
        &self.syntax.scopes
    }

    /// The wrapped node's phase (metadata accessor).
    pub fn phase(&self) -> Phase {
        self.syntax.phase
    }

    /// Splice `replacement` over every symbol named `var` (the
    /// pattern-variable face). Syntactic, not binder-aware: a
    /// syntax-rules template substitutes *every* occurrence regardless
    /// of nesting — binder discipline is the expansion environment's
    /// job (scope coloring), not this layer's.
    pub fn substitute(&self, var: &str, replacement: &CodeValue) -> CodeValue {
        CodeValue {
            syntax: substitute_node(&self.syntax, var, &replacement.syntax),
        }
    }

    /// Rename every symbol named `from` to `to` (the rename-on-capture
    /// remedy face, docs/stage0.md §9.38(b)). Like
    /// [`Self::substitute`] this is syntactic; the production hygiene
    /// mechanism of this stage is scope coloring, and this operation is
    /// the public remedy tool (diagnostics, tests, Stage 1 faces).
    ///
    /// # Panics (the documented floor — r106 FIX-5)
    ///
    /// `to` must be valid symbol text under the [`Symbol`] floor
    /// (non-empty; no ASCII or C1 control characters): the rename
    /// constructs the target symbol eagerly and refuses to invent a
    /// placeholder for illegal text. rustc's `Symbol::intern` and
    /// oxc's `Atom::new` are infallible for arbitrary input — kerf's
    /// stricter floor is imposed here on a public signature, so the
    /// infallible-shaped API is pinned by the negative seed test
    /// (`tests/v0/stage0/plan/macro_seed_tests.rs`) while a
    /// `Result`-returning successor stays a registered Stage 3
    /// breaking-window item (the callers today are tests and the
    /// diagnostics face, all of which pass legal text by construction).
    pub fn alpha_rename(&self, from: &str, to: &str) -> CodeValue {
        CodeValue {
            syntax: rename_node(&self.syntax, from, to),
        }
    }

    /// The symbol census: every distinct symbol text in the tree,
    /// sorted and deduplicated (the Stage 0 stand-in for the design's
    /// `free_variables` — see the module header).
    pub fn symbols(&self) -> Vec<String> {
        let mut found = Vec::new();
        collect_symbols(&self.syntax, &mut found);
        found.sort();
        found.dedup();
        found
    }

    /// The S-expression source display of the wrapped datum (the
    /// diagnostics observability face — `StxDatum: Display` reused).
    pub fn to_source(&self) -> String {
        self.syntax.datum.to_string()
    }
}

// ---------- internal walkers (iterative over lists, recursive over the
// fixed datum depth — reader-bounded at 256 levels) ----------

fn substitute_node(node: &SyntaxObject, var: &str, replacement: &SyntaxObject) -> SyntaxObject {
    match &node.datum {
        StxDatum::Symbol(sym) if sym.as_str() == var => replacement.clone(),
        StxDatum::List(items) => SyntaxObject {
            datum: StxDatum::List(
                items
                    .iter()
                    .map(|item| substitute_node(item, var, replacement))
                    .collect(),
            ),
            span: node.span,
            scopes: node.scopes.clone(),
            phase: node.phase,
        },
        _ => node.clone(),
    }
}

fn rename_node(node: &SyntaxObject, from: &str, to: &str) -> SyntaxObject {
    match &node.datum {
        StxDatum::Symbol(sym) if sym.as_str() == from => SyntaxObject {
            datum: StxDatum::Symbol(Symbol::new(to).expect("rename target must be a valid symbol")),
            span: node.span,
            scopes: node.scopes.clone(),
            phase: node.phase,
        },
        StxDatum::List(items) => SyntaxObject {
            datum: StxDatum::List(
                items
                    .iter()
                    .map(|item| rename_node(item, from, to))
                    .collect(),
            ),
            span: node.span,
            scopes: node.scopes.clone(),
            phase: node.phase,
        },
        _ => node.clone(),
    }
}

fn collect_symbols(node: &SyntaxObject, found: &mut Vec<String>) {
    match &node.datum {
        StxDatum::Symbol(sym) => found.push(sym.as_str().to_owned()),
        StxDatum::List(items) => {
            for item in items {
                collect_symbols(item, found);
            }
        }
        _ => {}
    }
}

#[cfg(test)]
mod tests {
    //! Unit tests for the CodeValue structured code value (sub-stage
    //! test doc FP1; docs/tests/v0/stage0/plan/macro.md).

    use super::*;
    use kerf_span::{ByteOffset, ExpansionId, FileId};
    use kerf_syntax::ScopeSet;

    fn sp(start: u32, end: u32) -> Span {
        Span::new(
            FileId(0),
            ByteOffset(start),
            ByteOffset(end),
            ExpansionId::ROOT,
        )
        .expect("test fixture span must be well-formed")
    }

    fn sym(start: u32, end: u32, text: &str) -> SyntaxObject {
        SyntaxObject::symbol(sp(start, end), ScopeSet::new(), Phase::Runtime, text)
            .expect("test fixture symbol must be valid")
    }

    fn int(start: u32, end: u32, value: i64) -> SyntaxObject {
        SyntaxObject::int(sp(start, end), ScopeSet::new(), Phase::Runtime, value)
    }

    fn lst(start: u32, end: u32, items: Vec<SyntaxObject>) -> SyntaxObject {
        SyntaxObject::list(sp(start, end), ScopeSet::new(), Phase::Runtime, items)
    }

    // ---------- positive ----------

    #[test]
    fn from_syntax_round_trips_the_wrapped_node() {
        let node = int(3, 5, 42);
        let code = CodeValue::from_syntax(&node);
        assert_eq!(code.to_syntax(), &node);
        assert_eq!(code.span(), node.span);
        assert_eq!(code.scopes(), &node.scopes);
        assert_eq!(code.phase(), Phase::Runtime);
    }

    #[test]
    fn to_source_renders_nested_s_expressions() {
        // (add x 1)
        let node = lst(0, 9, vec![sym(1, 4, "add"), sym(5, 6, "x"), int(7, 8, 1)]);
        let code = CodeValue::from_syntax(&node);
        assert_eq!(code.to_source(), "(add x 1)");
    }

    #[test]
    fn symbols_census_deduplicates_and_sorts() {
        // (cons b a (car a))
        let node = lst(
            0,
            16,
            vec![
                sym(1, 5, "cons"),
                sym(6, 7, "b"),
                sym(8, 9, "a"),
                lst(10, 16, vec![sym(11, 14, "car"), sym(15, 16, "a")]),
            ],
        );
        let code = CodeValue::from_syntax(&node);
        assert_eq!(code.symbols(), vec!["a", "b", "car", "cons"]);
    }

    #[test]
    fn substitute_splices_nested_occurrences_only_where_named() {
        // template (fn (x) (f x y)) with var x := (g 1)
        let template = lst(
            0,
            16,
            vec![
                sym(1, 3, "fn"),
                lst(4, 7, vec![sym(5, 6, "x")]),
                lst(
                    8,
                    16,
                    vec![sym(9, 10, "f"), sym(11, 12, "x"), sym(13, 14, "y")],
                ),
            ],
        );
        let replacement = lst(20, 26, vec![sym(21, 22, "g"), int(23, 24, 1)]);
        let out = CodeValue::from_syntax(&template)
            .substitute("x", &CodeValue::from_syntax(&replacement))
            .to_syntax()
            .clone();
        // The parameter list x is spliced too (syntactic substitution —
        // the documented contract), y untouched, the replacement node
        // keeps its own span.
        let expected = lst(
            0,
            16,
            vec![
                sym(1, 3, "fn"),
                lst(4, 7, vec![replacement.clone()]),
                lst(8, 16, vec![sym(9, 10, "f"), replacement, sym(13, 14, "y")]),
            ],
        );
        assert_eq!(out, expected);
    }

    #[test]
    fn alpha_rename_rewrites_only_the_named_symbol() {
        // (let ((tmp 1)) (f tmp other)) rename tmp -> tmp%1
        let node = lst(
            0,
            26,
            vec![
                sym(1, 4, "let"),
                lst(
                    5,
                    13,
                    vec![lst(6, 12, vec![sym(7, 10, "tmp"), int(11, 12, 1)])],
                ),
                lst(
                    14,
                    26,
                    vec![sym(15, 16, "f"), sym(17, 20, "tmp"), sym(21, 26, "other")],
                ),
            ],
        );
        let out = CodeValue::from_syntax(&node)
            .alpha_rename("tmp", "tmp__macro_1")
            .to_source();
        assert_eq!(out, "(let ((tmp__macro_1 1)) (f tmp__macro_1 other))");
    }
}

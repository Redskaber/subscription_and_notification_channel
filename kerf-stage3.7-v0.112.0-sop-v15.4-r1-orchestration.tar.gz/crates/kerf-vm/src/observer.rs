//! The dispatch observation face (the W-3.7 measurement seam).
//!
//! [`VmObserver`] is the dependency-inversion twin of [`Collector`]
//! (roots.rs): Layer 6 owns the hook point (the fetch site — every
//! executed instruction reports exactly once, before its match arm
//! runs), the harness owns the observation algorithm. The r119
//! lifetime portrait observed the GC path through the collector
//! injection; this face extends the same measurement-only pattern to
//! the dispatch path, where no injection point existed (stage-3-plan
//! §2.3 W-3.7 MUV 3.7-a: "dispatch hotspot statistics — the existing
//! B-axis extension"). The observer is a `run_observed` parameter,
//! never stored in the VM — the struct layout is byte-identical with
//! and without the seam, and `run`'s `run_dispatch::<false>`
//! instantiation compiles the observation arm out entirely (the A/B
//! control measurements in w3.7-jit-window.md §2a pin the
//! production-loop cost at zero within measurement noise).
//!
//! Discipline boundary (the w3.7-jit-window.md §2a adjudication):
//! this seam is MEASUREMENT INFRASTRUCTURE, not mechanism
//! pre-implementation — it observes the real interpreter loop (census
//! exactness by construction: no harness-side twin to drift), adds
//! zero opcodes, zero fusion, and zero dispatch reordering.
//!
//! The face a tier-1 design consumes (window record §4): per-opcode
//! dynamic census, dynamic adjacent-pair histograms (the
//! superinstruction candidate data — an observation-adjacent pair is
//! a dynamic back-to-back execution, the fusion precondition), and
//! per-function instruction counts (the method-JIT hot-function
//! input). A fused-opcode or tiered-JIT implementation window, if
//! opened by the W-3.7 adjudication, reuses this seam as its
//! profiling substrate rather than inventing a second one.

use kerf_compiler::Opcode;

/// One dispatch observer: called exactly once per executed
/// instruction, before the opcode's match arm runs.
pub trait VmObserver {
    /// Observe one executed instruction: its opcode and its
    /// `(func, pc)` location. The pc is the instruction's own index
    /// (the pre-increment fetch position), so two consecutive
    /// observations with the same `func` and `pc2 == pc1 + 1` are a
    /// dynamic back-to-back execution — the superinstruction fusion
    /// precondition (window record §2b).
    fn observe(&mut self, op: Opcode, func: usize, pc: usize);
}

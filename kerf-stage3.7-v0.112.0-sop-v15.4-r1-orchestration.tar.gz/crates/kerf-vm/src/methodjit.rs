//! The tier-1 method-JIT infrastructure (W-JIT-METHOD-T1 blade 1,
//! window record `docs/develop/v3/w-jit-method-t1-window.md` §7 —
//! the MJ-1..MJ-4 rulings).
//!
//! Form (MJ-1, the K158 menu ruling): a hot function's whole code
//! compiles into a [`MethodChain`] — one [`ChainNode`] per
//! instruction, each node's step being the 1:1 mirror of the
//! interpreter's match arm. The mirror is CONSTRUCTIVE, not
//! statistical: the node bodies call the very same `arm_*` helpers
//! the interpreter arms call (single source — §2.3), in the same
//! order with the same payloads, so engine equivalence is a
//! construction, not an argument (the r134 F1 precedent form).
//!
//! Census (MJ-2): a per-function closure-invocation counter, one
//! `u32` add per call (not per instruction), counted in `invoke`'s
//! closure arm after the arity check. Crossing
//! [`METHOD_HOT_THRESHOLD`] builds the chain for that function on
//! the spot; the crossing invocation itself runs compiled (the
//! build completes before its frame is pushed — deterministic: the
//! same program always crosses at the same invocation). A build
//! failure is permanent fallback (one attempt, no retry loop —
//! anti-thrash and determinism). Static single-phase only (the
//! K150 ruling carries: no runtime feedback, no adaptation).
//!
//! Boundary (MJ-3): whole-function granularity — a function is all
//! chain or all interpreted, never a mixed chain. Engine mixing
//! happens only at frame boundaries (a call pushing a frame, a ret
//! popping one) where the main loop re-selects the engine for the
//! new top frame; mid-method resume enters the chain through the
//! pc-indexed node map, so `frame.pc` is bitwise identical to the
//! interpreter's at every point control can leave the chain.
//!
//! Determinism (MJ-4): the build is a pure function of the
//! bytecode — the same bytecode always yields the same chain (the
//! canonical `listing()` is comparable across builds), and the
//! tier-up point is a deterministic function of the program. The
//! honest Rust note, registered in MJ-1 and measured by blade 2's
//! B-axis: successor linking goes through the pc map (one Vec index
//! per step) — true Rc-linked closures would need interior
//! mutability for forward jump targets, whose per-step cost exceeds
//! the index it would replace.

use std::rc::Rc;

use kerf_compiler::{Bytecode, Instr, Opcode};

use crate::error::RuntimeError;
use crate::value::Value;
use crate::vm::Vm;

/// The default hot-invocation census threshold (MJ-2): fib(25)
/// invokes `fib` 242,785 times (>> 64 — the compile cost amortizes
/// over >= 99.97% of the invocations) while one-shot programs count
/// 1 (<< 64 — cold functions never compile: the F5 hot-function
/// concentration finding mechanized).
///
/// Blade 2 (r142) ruling — this is the OPT-IN threshold, no longer
/// the shipped default: the three-run B-axis contrast measured the
/// closure chain at ~1.09x the pure interpreter's wall time on
/// fib-25 (tool-results/r142-dispatch-profile-run{1,2,3}.txt — the
/// MJ-1 honest note realized: the `Rc<dyn Fn>` indirect call and
/// the entry-index hop price above the match jump table they
/// replace, so under the zero-codegen constraint the 27-arm match
/// interpreter IS the optimal dispatch form). The production
/// default is therefore [`METHOD_TIER_DISABLED`] (pure
/// interpretation — the fastest measured form); the tier machinery
/// stays as the opt-in verification face (`with_method_tier_threshold`)
/// and as the reusable census/chain-builder base for the W-3.8
/// out-of-chain codegen window (K152/K157: beating the interpreter
/// requires register-machine codegen, which lives outside the
/// bootstrap chain by constitution).
pub const METHOD_HOT_THRESHOLD: u32 = 64;

/// The shipped production default (blade 2, r142): the census
/// threshold pinned past every saturating count, so no function
/// ever crosses and every dispatch goes through the interpreter's
/// match — the tier machinery structurally idle, and `note_invoke`
/// short-circuits before the counting add (the disabled face costs
/// nothing per call).
pub const METHOD_TIER_DISABLED: u32 = u32::MAX;

/// What one chain step returns to its driver.
#[derive(Debug)]
pub(crate) enum Control {
    /// Continue with the node at this pc (the fetch-equivalent
    /// advance already happened in the driver).
    Next(u32),
    /// A call pushed a new frame onto the frame stack; the main
    /// loop re-selects the engine for the new top frame.
    CalleePushed,
    /// `ret` popped this frame (the value is already on the caller's
    /// stack).
    FrameReturned,
    /// `halt` stopped the machine with this value.
    Halted(Value),
}

/// One compiled step's signature (the 1:1 arm-mirror face — a
/// boxed closure over the shared helpers).
pub(crate) type StepFn = Box<dyn Fn(&mut Vm) -> Result<Control, RuntimeError>>;

/// One compiled step: the 1:1 mirror of one interpreter arm. The
/// `pc`/`func`/`op` fields exist for the driver's fetch-equivalent
/// advance and observation triples (identical to the interpreter's
/// fetch position — the pre-increment index).
pub(crate) struct ChainNode {
    pub(crate) pc: u32,
    pub(crate) func: u32,
    pub(crate) op: Opcode,
    pub(crate) step: StepFn,
}

/// One row of the canonical chain listing (MJ-4's determinism face:
/// the same bytecode must produce the same listing across builds).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ListingRow {
    pub pc: u32,
    pub op: Opcode,
    /// Successor pcs in driver order: sequential `[pc + 1]`, jump
    /// `[target]`, branch `[pc + 1, target]`, boundary `[]`.
    pub next: Vec<u32>,
}

/// The compiled form of one function: a node per pc, plus the
/// canonical listing (both built in the same walk — one source).
pub struct MethodChain {
    pub(crate) nodes: Vec<ChainNode>,
    listing: Vec<ListingRow>,
}

/// The fail-closed build defenses (MJ-3). Structurally unreachable
/// on verified products — `Bytecode::verify` rejects all three
/// shapes first; the builder re-checks independently as defense in
/// depth, so hand-built fragments cannot smuggle a broken chain.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum MethodJitError {
    UnknownFunc { func: usize },
    EmptyBody { func: usize },
    DanglingJump { func: usize, pc: usize, target: u32 },
}

impl MethodChain {
    /// Build the chain for `func` from `bc` (a pure function of the
    /// bytecode — MJ-4). Every instruction gets a node; the driver
    /// resumes mid-method through `entry(pc)`.
    pub fn build(bc: &Bytecode, func: usize) -> Result<MethodChain, MethodJitError> {
        let proto = bc
            .funcs
            .get(func)
            .ok_or(MethodJitError::UnknownFunc { func })?;
        let code = &proto.code;
        if code.is_empty() {
            return Err(MethodJitError::EmptyBody { func });
        }
        // The dangling-jump defense (verify's JumpTargetOutOfRange,
        // mirrored here independently).
        for (pc, instr) in code.iter().enumerate() {
            if matches!(instr.op, Opcode::Jump | Opcode::JumpIfFalse)
                && instr.a as usize >= code.len()
            {
                return Err(MethodJitError::DanglingJump {
                    func,
                    pc,
                    target: instr.a,
                });
            }
        }
        let func32 = func as u32;
        let mut nodes: Vec<ChainNode> = Vec::with_capacity(code.len());
        let mut listing: Vec<ListingRow> = Vec::with_capacity(code.len());
        for (pc, instr) in code.iter().enumerate() {
            let pc32 = pc as u32;
            let node = ChainNode {
                pc: pc32,
                func: func32,
                op: instr.op,
                step: build_step(func, pc, *instr),
            };
            nodes.push(node);
            listing.push(ListingRow {
                pc: pc32,
                op: instr.op,
                next: successors_of(instr, pc),
            });
        }
        Ok(MethodChain { nodes, listing })
    }

    /// The node at `pc` (the driver's resume face; the chain covers
    /// every pc by construction).
    pub(crate) fn entry(&self, pc: usize) -> &ChainNode {
        &self.nodes[pc]
    }

    /// The canonical listing (the MJ-4 determinism face).
    pub fn listing(&self) -> &[ListingRow] {
        &self.listing
    }
}

/// The successor pcs of one instruction, in driver order (the
/// listing's single source).
fn successors_of(instr: &Instr, pc: usize) -> Vec<u32> {
    match instr.op {
        Opcode::Jump => vec![instr.a],
        Opcode::JumpIfFalse => vec![pc as u32 + 1, instr.a],
        // Boundary steps: a call may push a frame (the main loop
        // re-selects), ret pops one, halt ends the run — none of
        // them has a static in-method successor.
        Opcode::Call | Opcode::CallGlobal | Opcode::Ret | Opcode::Halt | Opcode::Perform => {
            Vec::new()
        }
        _ => vec![pc as u32 + 1],
    }
}

/// Build one node's step closure — the 1:1 mirror of the
/// interpreter arm (MJ-1). The trivial arms (Pop/Dup/Swap/LoadLocal/
/// LoadCaptured/StoreLocal/StoreGlobal/Jump) mirror through the same
/// helpers and shims the arms use, as identical expressions; every
/// other arm is a single-source `arm_*` call.
fn build_step(func: usize, pc: usize, instr: Instr) -> StepFn {
    let op = instr.op;
    let a = instr.a;
    let pc32 = pc as u32;
    let seq = pc32 + 1;
    match op {
        Opcode::PushConst => Box::new(move |vm: &mut Vm| {
            vm.arm_push_const(instr, func, pc)?;
            Ok(Control::Next(seq))
        }),
        Opcode::Pop => Box::new(move |vm: &mut Vm| {
            vm.pop(op, func, pc)?;
            Ok(Control::Next(seq))
        }),
        Opcode::Dup => Box::new(move |vm: &mut Vm| {
            let top = vm.peek(0, op, func, pc)?.clone();
            vm.push(top)?;
            Ok(Control::Next(seq))
        }),
        Opcode::Swap => Box::new(move |vm: &mut Vm| {
            let x = vm.pop(op, func, pc)?;
            let y = vm.pop(op, func, pc)?;
            vm.push(x)?;
            vm.push(y)?;
            Ok(Control::Next(seq))
        }),
        Opcode::Call => Box::new(move |vm: &mut Vm| {
            // MJ-1: a builtin callee runs inline (no frame change —
            // continue the chain); a closure callee pushes a frame —
            // hand the loop back for engine re-selection. The probe
            // is the frame-vector length around the shared invoke.
            let before = vm.frames_len();
            vm.exec_call(a, func, pc)?;
            if vm.frames_len() > before {
                Ok(Control::CalleePushed)
            } else {
                Ok(Control::Next(seq))
            }
        }),
        Opcode::CallGlobal => Box::new(move |vm: &mut Vm| {
            let before = vm.frames_len();
            vm.arm_call_global(instr, func, pc)?;
            if vm.frames_len() > before {
                Ok(Control::CalleePushed)
            } else {
                Ok(Control::Next(seq))
            }
        }),
        Opcode::Ret => Box::new(move |vm: &mut Vm| {
            vm.arm_ret(func, pc)?;
            Ok(Control::FrameReturned)
        }),
        Opcode::Closure => Box::new(move |vm: &mut Vm| {
            vm.arm_closure(instr, func, pc)?;
            Ok(Control::Next(seq))
        }),
        Opcode::Jump => Box::new(move |vm: &mut Vm| {
            vm.top_frame_mut().pc = a as usize;
            Ok(Control::Next(a))
        }),
        Opcode::JumpIfFalse => Box::new(move |vm: &mut Vm| {
            vm.arm_jump_if_false(instr, func, pc)?;
            // The arm wrote the taken branch into frame.pc; the chain
            // follows whatever the interpreter would fetch next.
            let next = vm.top_frame().pc as u32;
            Ok(Control::Next(next))
        }),
        Opcode::MakePair => Box::new(move |vm: &mut Vm| {
            vm.arm_make_pair(instr, func, pc)?;
            Ok(Control::Next(seq))
        }),
        Opcode::Car => Box::new(move |vm: &mut Vm| {
            vm.arm_car(func, pc)?;
            Ok(Control::Next(seq))
        }),
        Opcode::Cdr => Box::new(move |vm: &mut Vm| {
            vm.arm_cdr(func, pc)?;
            Ok(Control::Next(seq))
        }),
        Opcode::LoadLocal => Box::new(move |vm: &mut Vm| {
            let v = vm.top_frame().locals[a as usize].clone();
            vm.push(v)?;
            Ok(Control::Next(seq))
        }),
        Opcode::LoadCaptured => Box::new(move |vm: &mut Vm| {
            let v = vm.top_frame().captured[a as usize].clone();
            vm.push(v)?;
            Ok(Control::Next(seq))
        }),
        Opcode::StoreLocal => Box::new(move |vm: &mut Vm| {
            let value = vm.pop(op, func, pc)?;
            vm.top_frame_mut().locals[a as usize] = value;
            Ok(Control::Next(seq))
        }),
        Opcode::LoadGlobal => Box::new(move |vm: &mut Vm| {
            vm.arm_load_global(instr, func, pc)?;
            Ok(Control::Next(seq))
        }),
        Opcode::StoreGlobal => Box::new(move |vm: &mut Vm| {
            let value = vm.pop(op, func, pc)?;
            vm.store_global_slot(a as usize, value);
            Ok(Control::Next(seq))
        }),
        Opcode::LoadLocalConst => Box::new(move |vm: &mut Vm| {
            vm.arm_load_local_const(instr, func, pc)?;
            Ok(Control::Next(seq))
        }),
        Opcode::Add | Opcode::Sub | Opcode::Mul | Opcode::Div => Box::new(move |vm: &mut Vm| {
            vm.arm_arith(instr, func, pc)?;
            Ok(Control::Next(seq))
        }),
        Opcode::PushHandler => Box::new(move |vm: &mut Vm| {
            vm.arm_push_handler(instr, func, pc)?;
            Ok(Control::Next(seq))
        }),
        Opcode::PopHandler => Box::new(move |vm: &mut Vm| {
            vm.arm_pop_handler(instr, func, pc)?;
            Ok(Control::Next(seq))
        }),
        Opcode::Perform => Box::new(move |vm: &mut Vm| {
            let before = vm.frames_len();
            vm.exec_perform(instr, func, pc)?;
            if vm.frames_len() > before {
                Ok(Control::CalleePushed)
            } else {
                Ok(Control::Next(seq))
            }
        }),
        Opcode::Halt => Box::new(move |vm: &mut Vm| {
            let v = vm.arm_halt(func, pc)?;
            Ok(Control::Halted(v))
        }),
    }
}

/// The tier state of one function.
enum Status {
    Cold,
    Hot(Rc<MethodChain>),
    /// One attempt made, the build refused — permanent fallback to
    /// the interpreter (MJ-2: no retry loop).
    Failed,
}

/// The per-VM tier-1 state (MJ-2): census counters plus per-function
/// compile status. Counting continues after tier-up (a saturating
/// add — the guard observation face); the status check short-circuits
/// the build attempt.
pub struct MethodJit {
    threshold: u32,
    counts: Vec<u32>,
    status: Vec<Status>,
}

impl MethodJit {
    pub(crate) fn new(n_funcs: usize, threshold: u32) -> MethodJit {
        MethodJit {
            threshold,
            counts: vec![0; n_funcs],
            status: (0..n_funcs).map(|_| Status::Cold).collect(),
        }
    }

    /// Count one closure invocation; on the threshold crossing, build
    /// the chain (the crossing invocation runs compiled — MJ-2).
    /// The disabled face ([`METHOD_TIER_DISABLED`]) short-circuits
    /// before the counting add — the production default pays nothing
    /// per call, and its census counts stay at zero (a pinned
    /// semantic: the blade-2 guard family asserts it).
    pub(crate) fn note_invoke(&mut self, bc: &Bytecode, func: usize) {
        if self.threshold == METHOD_TIER_DISABLED {
            return;
        }
        self.counts[func] = self.counts[func].saturating_add(1);
        if self.counts[func] == self.threshold && matches!(self.status[func], Status::Cold) {
            let built = MethodChain::build(bc, func);
            self.status[func] = match built {
                Ok(chain) => Status::Hot(Rc::new(chain)),
                Err(_) => Status::Failed,
            };
        }
    }

    /// The engine-selection probe (run_dispatch's loop top): the
    /// compiled chain if this function is hot, else None.
    pub(crate) fn chain_for(&self, func: usize) -> Option<Rc<MethodChain>> {
        match &self.status[func] {
            Status::Hot(chain) => Some(Rc::clone(chain)),
            _ => None,
        }
    }

    /// Override the census threshold (the policy face — callers set
    /// it before the run; counts already taken stand).
    pub(crate) fn set_threshold(&mut self, threshold: u32) {
        self.threshold = threshold;
    }

    // ---------- guard observation faces (MJ-4) ----------

    /// The census count so far (saturating).
    pub fn invocations(&self, func: usize) -> u32 {
        self.counts[func]
    }

    /// Whether this function has a compiled chain.
    pub fn is_compiled(&self, func: usize) -> bool {
        matches!(self.status[func], Status::Hot(_))
    }

    /// Whether the one build attempt refused (permanent fallback).
    pub fn build_failed(&self, func: usize) -> bool {
        matches!(self.status[func], Status::Failed)
    }

    /// The canonical listing of the compiled chain, if hot.
    pub fn chain_listing(&self, func: usize) -> Option<&[ListingRow]> {
        match &self.status[func] {
            Status::Hot(chain) => Some(chain.listing()),
            _ => None,
        }
    }
}

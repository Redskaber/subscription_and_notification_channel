//! kerf-reader — the surface-syntax reader (Layer 2).
//!
//! Charter (docs/stage0.md §278 capability signature `read : string →
//! Result<SyntaxObject, ReadError>` and §8.1 typed-token-stream
//! contract): a UTF-8-aware lexer plus a recursive-descent parser
//! turning source text into syntax-object trees. The read surface is
//! the target skin only — the single-skin terminal state of the
//! W-SEXP-RETIRE blade 2 (r151): the S-expression scaffold's reader
//! (the `lexer.rs` / `parser.rs` / `token.rs` modules and the
//! `read_program` entry) was removed together with the rest of the
//! scaffold once the target reader chain held the production
//! position (r145) and the corpus had migrated to `.ktf` (r150).
//! Stage 0's S-expression skin was scaffolding by charter
//! (docs/stage0.md §7.3.5/§7.3.6, SOP §2.5 — removed from the
//! bootstrap chain at Stage 2b, never a permanent internal IR).
//!
//! Public surface:
//! - [`read_target_program`] — the §278 read contract for the v9
//!   target skin (stage0.md §9.94): the Level 0 parity subset mapped
//!   through the skin dictionary onto the same syntax-object trees.
//!
//! Naming (SOP §21.12): the token types carry the `Tgt` prefix
//! (`TgtToken`, `TgtKind`); the error surface is `ReadError` per the
//! capability table.

mod error;
mod target;

// Explicit re-export list (SOP §10.1 rule 4 — glob re-exports are forbidden).
pub use error::ReadError;
pub use target::{
    TgtKind, TgtToken, lex_target, read_target_program, read_target_program_with_limit, skin_symbol,
};

/// The list-nesting cap of 256 levels (sub-stage 0.3 acceptance; the
/// K162 conservative default — the W-REC-DEPTH blade 2 keeps the cap
/// configurable through the `with_limit` entries). Single-skin note
/// (r151): the constant was born in the retired S-expression parser
/// and now anchors the target reader's default cap — one shared
/// depth budget, one source.
pub const NESTING_LIMIT: usize = 256;

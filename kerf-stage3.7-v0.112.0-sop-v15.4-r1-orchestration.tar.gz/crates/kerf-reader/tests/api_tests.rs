//! kerf-reader crate-level integration tests: verify the public API
//! surface re-exported from `lib.rs` (SOP §9.1 rule 5 — crate-internal
//! `tests/` validates only this crate's public API; cross-crate
//! assertions live in the workspace root `tests/` tree).
//!
//! r151 single-skin retarget (the W-SEXP-RETIRE blade 2): the
//! S-expression reader left the tree with the scaffold, so the public
//! surface this file pins is the target reader — `lex_target`,
//! `read_target_program`, `read_target_program_with_limit` and the
//! target-skin `ReadError` variants. The seed reader's
//! EmptyApplication rejection has no target twin: `()` reads as nil
//! (ruling C12 — pinned below as the unit-skin contract).

use kerf_reader::{
    NESTING_LIMIT, ReadError, TgtKind, lex_target, read_target_program,
    read_target_program_with_limit,
};
use kerf_span::{ByteOffset, FileId};

fn file() -> FileId {
    FileId(0)
}

#[test]
fn public_api_exports_documented_surface() {
    // Compile-level surface check: every documented name is reachable
    // from the crate root (SOP §10.1 rule 4 explicit re-export list).
    let tokens = lex_target(file(), "x()").expect("lex via public path");
    assert_eq!(tokens.len(), 4);
    assert!(
        matches!(tokens[0].kind, TgtKind::Ident(_)),
        "the head lexes as an identifier"
    );
    assert_eq!(tokens[1].kind, TgtKind::OpenParen);
    assert_eq!(tokens[2].kind, TgtKind::CloseParen);
    assert_eq!(tokens[3].kind, TgtKind::Eof);

    let forms = read_target_program(file(), "add(x, 1);").expect("read via public path");
    assert_eq!(forms.len(), 1);
    assert_eq!(forms[0].datum.to_string(), "(add x 1)");
    assert_eq!(NESTING_LIMIT, 256, "Stage 0 nesting cap is 256");
    let _err: ReadError = ReadError::StrayTargetDelim {
        at: ByteOffset(0),
        closing: ')',
    };
}

#[test]
fn public_reader_builds_nested_program() {
    // A representative nested program: every node comes back with an
    // exact span and the reader stamps (Runtime phase, empty scopes).
    // The mapped tree is the canonical `(define (f x) (add x 1))` —
    // the skin dictionary applies at parse time, so the target
    // spelling and the retired seed spelling produce one tree.
    let forms = read_target_program(file(), "fn f(x) { add(x, 1) }").expect("program reads");
    assert_eq!(forms.len(), 1);
    let root = &forms[0];
    assert_eq!(root.datum.to_string(), "(define (f x) (add x 1))");
    assert_eq!((root.span.start.0, root.span.end.0), (0, 21));
    let mut count = 0usize;
    root.visit_spans(&mut |_s| count += 1);
    assert_eq!(
        count, 9,
        "root + define + f-form + f + x + add-form + add + x + 1"
    );
}

#[test]
fn public_path_reads_the_unit_as_nil() {
    // Ruling C12 (the r151 single-skin retarget): `()` is the unit
    // skin of nil on the target face — the seed reader's
    // EmptyApplication rejection retired with the seed reader, and
    // the unit statement reads to the nil atom.
    let forms = read_target_program(file(), "();").expect("the unit statement reads");
    assert_eq!(forms.len(), 1);
    assert_eq!(forms[0].datum.to_string(), "nil");
}

#[test]
fn public_path_rejects_stray_close() {
    let err = read_target_program(file(), ")").expect_err("stray close rejected via public path");
    assert_eq!(
        err,
        ReadError::StrayTargetDelim {
            at: ByteOffset(0),
            closing: ')',
        }
    );
    assert_eq!(err.to_string(), "unexpected closing delimiter `)`");
}

#[test]
fn public_path_rejects_unclosed_delim() {
    // The `{` of a fn body opens at byte 7 and never closes.
    let err = read_target_program(file(), "fn f() { 1").expect_err("unclosed brace rejected");
    assert_eq!(
        err,
        ReadError::UnclosedTargetDelim {
            opened_at: ByteOffset(7),
            opening: "{",
        }
    );
    assert_eq!(err.to_string(), "unclosed delimiter: `{` is never closed");
}

#[test]
fn public_path_rejects_malformed_number() {
    // The radix-garbage twin of the seed multi-dot face: `0x1g`
    // scans as one token and rejects with the whole-token payload.
    let err = read_target_program(file(), "f(0x1g);").expect_err("malformed number rejected");
    assert!(matches!(
        &err,
        ReadError::MalformedNumber { text, span }
            if text == "0x1g" && span.start.0 == 2 && span.end.0 == 6
    ));
}

#[test]
fn public_path_rejects_hash_tokens() {
    // The seed `#true` bool face retired with the seed reader: `#`
    // is not in the target single-char token table at all, so the
    // whole hash family is UnexpectedCharacter at the `#` byte.
    let err = read_target_program(file(), "#true").expect_err("hash token rejected");
    assert!(matches!(
        &err,
        ReadError::UnexpectedCharacter { character, at } if *character == '#' && at.0 == 0
    ));
}

#[test]
fn public_path_rejects_both_overflow_faces() {
    // v0.40.0 (stage0.md §9.71): the silent int→float demotion and
    // the silent ±inf read both fail closed on the public path.
    let err =
        read_target_program(file(), "f(9223372036854775808);").expect_err("i64 overflow rejected");
    match err {
        ReadError::IntOutOfRange { ref text, ref span } => {
            assert_eq!(text, "9223372036854775808");
            assert_eq!((span.start.0, span.end.0), (2, 21));
        }
        other => panic!("expected IntOutOfRange, got {other:?}"),
    }
    assert!(err.token_span().is_some());
    // The v9 float grammar mandates the dot (`1e999` is not a float
    // on the target skin), so the overflow face rides `1.0e999`.
    let err = read_target_program(file(), "f(1.0e999);").expect_err("f64 overflow rejected");
    match err {
        ReadError::FloatOutOfRange { ref text, .. } => assert_eq!(text, &"1.0e999"),
        other => panic!("expected FloatOutOfRange, got {other:?}"),
    }
    assert_eq!(
        err.to_string(),
        "float literal `1.0e999` out of range for `f64`"
    );
}

#[test]
fn public_path_rejects_unterminated_string() {
    let err = read_target_program(file(), "\"oops").expect_err("unterminated string rejected");
    assert_eq!(
        err,
        ReadError::UnterminatedString {
            started_at: ByteOffset(0)
        }
    );
}

#[test]
fn public_path_rejects_nesting_over_limit() {
    let mut src = String::new();
    for _ in 0..(NESTING_LIMIT + 1) {
        src.push('(');
    }
    src.push('x');
    for _ in 0..(NESTING_LIMIT + 1) {
        src.push(')');
    }
    src.push(';');
    let err = read_target_program(file(), &src).expect_err("over-cap nesting rejected");
    assert_eq!(
        err,
        ReadError::NestingDepthExceeded {
            depth: NESTING_LIMIT + 1,
            limit: NESTING_LIMIT,
        }
    );
}

#[test]
fn public_with_limit_face_raises_and_enforces_the_cap() {
    // The K162 conservative default is caller-raisable through the
    // `with_limit` entry (the W-REC-DEPTH blade 2): 300-deep group
    // nesting reads under a raised cap and rejects at the default.
    let mut deep = String::new();
    for _ in 0..300 {
        deep.push('(');
    }
    deep.push('1');
    for _ in 0..300 {
        deep.push(')');
    }
    deep.push(';');
    let forms =
        read_target_program_with_limit(file(), &deep, 1024).expect("reads under a raised cap");
    assert_eq!(forms.len(), 1);
    let err = read_target_program_with_limit(file(), &deep, NESTING_LIMIT)
        .expect_err("the default cap rejects the deep source");
    assert_eq!(
        err,
        ReadError::NestingDepthExceeded {
            depth: NESTING_LIMIT + 1,
            limit: NESTING_LIMIT,
        }
    );
}

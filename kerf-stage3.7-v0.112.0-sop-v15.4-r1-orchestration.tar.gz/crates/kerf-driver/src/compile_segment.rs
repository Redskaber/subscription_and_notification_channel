//! The T-a switch-window step-④ COMPILE segment production position
//! (w-t-a-switch-window.md §3 r148+ row — the TA-5/TA-6/TA-7 form
//! carried to the compile segment, the window's LAST segment): the
//! `.ktf` production compilation switches from the Rust compiler to
//! the steady twin chain (the compiler twin `compiler.ktf` compiled
//! once per process — per distinct depth budget — running on the
//! VM, the production engine), and the Rust compiler retires to the
//! oracle face (the parity harnesses' comparison arm, the seed
//! chain's own compilation, and the rollback band).
//!
//! The dual-chain decoupling (SOP §21.12-28②) instantiated for the
//! compile segment:
//!
//! * the PRODUCTION face — [`crate::pipeline::ParsedProgram::
//!   compile_bytecode`] (ridden by `check`/`c_source`/`run`'s VM
//!   arm/`run_parity`) on a target-face parse — rides
//!   [`CompileSegment::Twin`] (the default after the switch);
//! * the SEED/ORACLE faces — the injection-channel front end
//!   (`parse_target_with_injected` — the twin chain's OWN
//!   construction entry: a twin-position compile here would be
//!   circular, the chain cannot compile its own construction
//!   through itself), the A pass of the A/B/C pipeline
//!   (`rust_compile_ccf` — the Rust compiler as the A-round seed
//!   identity), and the differential harnesses' self-check compile
//!   step (`drive_dual_engines`/`drive_full_face` — structurally
//!   Rust, the direct `compile_program` call: the assembled programs
//!   are CHAIN ARTIFACTS whose products only feed the harnesses'
//!   "must run" assertions, so the switched twin position buys no
//!   verification value there — the r147 harness-pin ruling carried
//!   to the compile step, where the pin is structural and needs no
//!   env face) — PIN the Rust compiler explicitly: their
//!   comparisons stay differential.
//!
//! The rebuilt-faces retarget (the segment's own new face — the
//! K163 fifth instance, the compile half of the r147 fourth
//! instance's family): BOTH rebuild faces in the parity module
//! derive spans with `FileId(0)` (the parity harnesses' convention
//! — every harness interns at zero), but the production position
//! compiles items read from files interned at any id:
//!
//! * the ERROR face — a rebuilt rejection's span is retargeted
//!   through [`kerf_compiler::CompileError::with_span`] (exhaustive
//!   over every spanned variant, the FIX-16 discipline);
//! * the PRODUCT face — every rebuilt proto's debug-info span names
//!   the session's file, so runtime errors (whose spans resolve
//!   through the debug-info table) render against the right source;
//!   the GENERATIONS ride untouched (the twin already rebuilds the
//!   true macro generations — only the file identity was the
//!   harness convention's).
//!
//! Budget mirroring (the `tp_limit`/`ex_limit` precedent): the
//! twin's work budget rides the assembly prefix
//! (`define(co_limit, N);`) — the chain must carry the process's
//! effective `KERF_COMPILE_DEPTH_LIMIT` (the `DepthLimits::
//! compile_depth` the parse spine already threads), so an
//! over-depth tree rejects with the same key on both positions (the
//! rollback band's parity obligation); each distinct budget gets its
//! own once-compiled chain. The rejection itself is self-describing
//! on both arms: the payload carries the first-exceeding depth AND
//! the limit in force (the r148 `DepthExceeded` extension — the
//! `ExpansionDepthExceeded` precedent).
//!
//! The rollback band (SOP §14.6.4 rule 5 — measurement first): the
//! `KERF_COMPILE_SEGMENT` environment variable selects the position
//! for the CLI process entry — `twin` (the default) or `rust` (the
//! rollback); any other value is a hard error (fail-closed, the
//! `KERF_READ_SEGMENT`/`KERF_EXPAND_SEGMENT`/`KERF_CHECK_SEGMENT`
//! precedents). The library face stays deterministic — nothing here
//! reads the environment implicitly.

use std::collections::HashMap;
use std::rc::Rc;

use kerf_compiler::{Bytecode, CompileError};
use kerf_core::ModuleItem;
use kerf_span::FileId;

use crate::bootstrap::steady_compiler_chain::SteadyCompilerChain;

/// Which implementation compiles the checked items in the production
/// pipeline (the step-④ compile segment position).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CompileSegment {
    /// The steady twin chain on the VM (the production engine) —
    /// the switched position: `compiler.ktf` behind the `items`
    /// slot declaration and the `co_limit` budget define, compiled
    /// once per process (per distinct depth budget) through the
    /// seed face; every compile a fresh VM run with the expanded
    /// item stream bound through the injection channel.
    Twin,
    /// The Rust compiler — the rollback band (and the retired
    /// oracle: the parity harnesses' comparison arm and the seed
    /// chain's own compilation).
    Rust,
}

impl Default for CompileSegment {
    /// The switched production default (the T-a step-④ ruling:
    /// `Session::new` and every unset position ride the twins).
    fn default() -> Self {
        CompileSegment::Twin
    }
}

impl CompileSegment {
    /// Parse one `KERF_COMPILE_SEGMENT` value (the process entry's
    /// fail-closed face): `twin` and `rust` are the only legal
    /// spellings.
    pub fn parse_value(raw: &str) -> Result<Self, String> {
        match raw.trim() {
            "twin" => Ok(CompileSegment::Twin),
            "rust" => Ok(CompileSegment::Rust),
            other => Err(format!(
                "invalid value for KERF_COMPILE_SEGMENT: `{other}` (expected `twin` or `rust`)"
            )),
        }
    }

    /// Read the environment override: unset keeps the switched
    /// default (`Twin`); a set value must parse (the caller reports
    /// and exits — never a silent ignore).
    pub fn from_env() -> Result<Self, String> {
        match std::env::var("KERF_COMPILE_SEGMENT") {
            Ok(raw) => Self::parse_value(&raw),
            Err(std::env::VarError::NotPresent) => Ok(CompileSegment::Twin),
            Err(std::env::VarError::NotUnicode(raw)) => Err(format!(
                "invalid value for KERF_COMPILE_SEGMENT: `{}` (expected `twin` or `rust`)",
                raw.to_string_lossy()
            )),
        }
    }
}

/// The production compile's failure face — the two families the
/// production position must never confuse (the
/// `ProductionReadError`/`ProductionExpandError` precedents).
#[derive(Debug)]
pub enum ProductionCompileError {
    /// The program's own rejection (the rebuilt [`CompileError`] —
    /// the same error family the oracle produces, spans retargeted
    /// to the session's file, so the diagnostics render identically
    /// on both positions).
    Program(CompileError),
    /// A harness defect — the twin chain or a decode broke. A
    /// compiler defect: rendered loudly, never a silent Rust
    /// fallback (SOP §2.3-4 — errors over silence).
    Defect(String),
}

// The per-thread twin-chain cache, keyed by the depth budget the
// chain was constructed under: the twin's `co_limit` global must
// mirror the process's effective `KERF_COMPILE_DEPTH_LIMIT` (an
// over-depth tree rejects with the same key on both positions —
// the rollback band's parity obligation), so each distinct budget
// gets its own once-compiled chain (the `ex_limit` keyed-cache
// precedent). The default budget covers the ordinary corpus; the
// cache keeps the override honest without recompiling per compile.
//
// Thread-local by necessity (the `ReadSegment`/`ExpandSegment`/
// `CheckSegment` precedents): the chain's products carry `Rc`
// payloads — not `Send`/`Sync`; the cache value is plain `Rc`
// (never shared across threads). Construction failures are NOT
// cached: a broken chain is a tree defect the test suite would
// catch — retrying keeps the failure observable per call instead of
// freezing it.
thread_local! {
    static PRODUCTION_CHAINS: std::cell::RefCell<HashMap<usize, Rc<SteadyCompilerChain>>> =
        std::cell::RefCell::new(HashMap::new());
}

/// The cached (or first-constructed) production chain for one depth
/// budget.
fn production_chain(limit: usize) -> Result<Rc<SteadyCompilerChain>, String> {
    PRODUCTION_CHAINS.with(|cache| {
        let mut cache = cache.borrow_mut();
        match cache.get(&limit) {
            Some(chain) => Ok(Rc::clone(chain)),
            None => {
                let chain = Rc::new(SteadyCompilerChain::new_with_limit(limit)?);
                cache.insert(limit, Rc::clone(&chain));
                Ok(chain)
            }
        }
    })
}

/// Retarget a rebuilt rejection's spans to the session's file id.
///
/// The twin rebuild face derives spans with `FileId(0)` (the parity
/// harnesses' convention — every harness interns at zero), but the
/// production position compiles items read from files interned at
/// any id; a span that names the wrong file renders against the
/// wrong source. The walk rides [`CompileError::with_span`], which
/// is exhaustive over every spanned variant on purpose: a new
/// variant fails at compile time, so the retarget can never
/// silently miss a face (the FIX-16 discipline — the
/// `retarget_expand_error` precedent).
fn retarget_compile_error(err: CompileError, file: FileId) -> CompileError {
    match err.span() {
        Some(span) => {
            let mut span = span;
            span.file_id = file;
            err.with_span(span)
        }
        None => err,
    }
}

/// Retarget the rebuilt product's debug-info spans to the session's
/// file id (the K163 fifth-instance clearance, the product half):
/// every proto's debug spans name the session's file, so the
/// runtime error path (spans resolved through the debug-info table)
/// renders against the right source. The generations ride untouched
/// — the twin already rebuilds the true macro generations, only the
/// file identity was the harness convention's (the
/// `retarget_items` precedent).
fn retarget_bytecode(bc: &mut Bytecode, file: FileId) {
    for proto in &mut bc.funcs {
        for span in &mut proto.debug_info {
            span.file_id = file;
        }
    }
}

/// The production compilation: one expanded item stream through the
/// compiler twin chain on the VM (the switched position's single
/// entry — `ParsedProgram`'s compile faces ride it; the rebuilt
/// artifact passes the VM's own verify floor inside the rebuild, and
/// every span the rebuild derived names the session's file after the
/// retarget). A harness defect (chain construction, the VM run, a
/// decode) renders loudly as `Err` — the caller surfaces it as a
/// driver error, never a silent Rust fallback (SOP §2.3-4).
pub fn production_compile(
    items: &[ModuleItem],
    limit: usize,
    file: FileId,
) -> Result<Bytecode, ProductionCompileError> {
    let chain = production_chain(limit).map_err(ProductionCompileError::Defect)?;
    match chain.compile_production(items) {
        Err(defect) => Err(ProductionCompileError::Defect(defect)),
        Ok(Err(err)) => Err(ProductionCompileError::Program(retarget_compile_error(
            err, file,
        ))),
        Ok(Ok(mut bc)) => {
            // The product face rides the same retarget as the error
            // face (the K163 fifth-instance clearance — see
            // `retarget_bytecode`).
            retarget_bytecode(&mut bc, file);
            Ok(bc)
        }
    }
}

// The rebuilt-record unit face: the env policy and the two retarget
// walks. The pipeline-level integration faces live in the root test
// tree (`compile_segment_switch_tests.rs` — the corpus sweep, the
// rollback band, the budget mirror, and the cross-stage
// consumption).
#[cfg(test)]
mod tests {
    use super::*;
    use kerf_span::Span;

    #[test]
    fn env_values_parse_fail_closed() {
        assert_eq!(
            CompileSegment::parse_value("twin"),
            Ok(CompileSegment::Twin)
        );
        assert_eq!(
            CompileSegment::parse_value("rust"),
            Ok(CompileSegment::Rust)
        );
        // Surrounding whitespace is tolerated (the read/expand/check
        // segment precedents: a trailing newline from a shell
        // `FOO=bar\n` export must not become a hard failure).
        assert_eq!(
            CompileSegment::parse_value(" rust "),
            Ok(CompileSegment::Rust)
        );
        for bad in ["", "twins", "TWIN", "c", "0", "oracle"] {
            assert!(
                CompileSegment::parse_value(bad).is_err(),
                "`{bad}` must not parse as a compile segment"
            );
        }
    }

    #[test]
    fn error_retarget_takes_the_session_file_on_every_spanned_variant() {
        // The with_span walk is exhaustive (FIX-16); the retarget
        // pairs whatever span the variant carries with the session's
        // file — a representative sweep over the family's three
        // shapes: the budget face, an analysis face, and a
        // position-less product face (which must ride untouched).
        let file = FileId(9);
        let span = || {
            Span::new(
                FileId(0),
                kerf_span::ByteOffset(3),
                kerf_span::ByteOffset(4),
                kerf_span::ExpansionId::ROOT,
            )
            .expect("a well-formed fixture span")
        };
        let depth = CompileError::DepthExceeded {
            depth: 1025,
            limit: 1024,
            span: span(),
        };
        let retargeted = retarget_compile_error(depth, file);
        assert_eq!(
            retargeted
                .span()
                .expect("the depth face carries a span")
                .file_id,
            file,
            "the rebuilt depth rejection must name the session's file"
        );

        let unpatched = CompileError::UnpatchedJump {
            at: 4,
            span: span(),
        };
        let retargeted = retarget_compile_error(unpatched, file);
        assert_eq!(
            retargeted
                .span()
                .expect("the unpatched face carries a span")
                .file_id,
            file
        );

        // The position-less product family rides untouched (the
        // missing span is the defect itself — no fabrication).
        let shape = CompileError::EmptyFuncTable;
        let retargeted = retarget_compile_error(shape, file);
        assert!(retargeted.span().is_none());
        assert!(matches!(retargeted, CompileError::EmptyFuncTable));
    }

    #[test]
    fn product_retarget_names_the_session_file_with_generations_untouched() {
        // The rebuilt product's debug spans carry the true macro
        // generations from the twin's records; only the file
        // identity was the harness convention's. The retarget swaps
        // the file and leaves everything else bit-for-bit.
        let file = FileId(7);
        let mk_span = |generation: u32| {
            Span::new(
                FileId(0),
                kerf_span::ByteOffset(1),
                kerf_span::ByteOffset(9),
                kerf_span::ExpansionId(generation),
            )
            .expect("a well-formed fixture span")
        };
        let mut bc = Bytecode::default();
        let mut proto = kerf_compiler::FuncProto::new(None, 0, 0);
        proto.debug_info.push(mk_span(0));
        proto.debug_info.push(mk_span(3));
        bc.funcs.push(proto);

        retarget_bytecode(&mut bc, file);
        for span in &bc.funcs[0].debug_info {
            assert_eq!(
                span.file_id, file,
                "every rebuilt dbg span must name the session's file"
            );
        }
        assert_eq!(
            bc.funcs[0].debug_info[1].expansion_id,
            kerf_span::ExpansionId(3),
            "the true generations ride untouched"
        );
    }
}

//! The T-a switch-window step-④ CHECK segment production position
//! (w-t-a-switch-window.md §3 r147+ row — the TA-5/TA-6 form carried
//! to the checking segment): the `.ktf` production checking switches
//! from the Rust checker pair (`check_module` + `infer_module`) to
//! the steady twin chains (the two checker twins — `typecheck.ktf`
//! and `infer.ktf` — each compiled once per process, running on the
//! VM, the production engine), and the Rust checkers retire to the
//! oracle face (the parity harnesses' comparison arm and the
//! rollback band).
//!
//! The dual-chain decoupling (SOP §21.12-28②) instantiated for the
//! checking segment:
//!
//! * the PRODUCTION face — [`crate::pipeline::ParsedProgram::
//!   typecheck`] on a target-face parse — rides [`CheckSegment::Twin`]
//!   (the default after the switch): BOTH checker twins run (the
//!   conservative checker first, the HM inference engine second —
//!   the oracle spine's own collection order), their verdicts
//!   decoded straight into rebuilt [`TypeDiagnostic`] records;
//! * the SEED/ORACLE faces — the injection-channel front end
//!   (`parse_target_with_injected` — the twin chains' OWN
//!   construction entry: a twin-position check here would be
//!   circular, the chain cannot check its own construction through
//!   itself) and the A pass of the A/B/C pipeline (`rust_compile_ccf`)
//!   — PIN the Rust checkers explicitly: their comparisons stay
//!   differential.
//!
//! The verdict rebuild (the segment's own new face — the read and
//! expand segments rebuilt rejections, this segment rebuilds
//! FINDINGS): the twin's `("cdiag" code severity s e payload
//! subjects)` / `("tdiag" code severity s e payload)` records decode
//! into `TypeDiagnostic` — the code through the registry lookup, the
//! message through the oracle's own template tables (the R8
//! single-source dictionaries the parity sweeps already
//! cross-check), the span as `Span::new(file, s, e, ROOT)` — the
//! file retargeted to the session's id (the read-segment precedent)
//! and the generation ROOT (the expand-segment error-axis precedent:
//! rejection/diagnostic spans are source-generation spans; the
//! oracle position's macro-expanded findings DO carry non-ROOT
//! generations, an honest boundary — neither the parity contract
//! (five fields: code/severity/offsets/message/subjects) nor any
//! current rendering face consumes the generation; the W-3.9
//! diagnostics window owns the twin-side generation emission if that
//! window ever needs the macro context chain).
//!
//! Budgets (the `tp_limit`/`ex_limit` precedent, examined): the
//! inference depth budget is a baked `512` on BOTH sides (the Rust
//! constant and the twin's baked `512` — no environment face
//! anywhere), so the rollback band's same-key obligation holds by
//! construction; the checker twins' VM instruction budget is the
//! engine default (the A/B/C pipeline's `check_via` runs the same
//! twins under the same budget on the 60 KB CCF forms — the deep
//! fixed point is already in evidence).
//!
//! The rollback band (SOP §14.6.4 rule 5 — measurement first): the
//! `KERF_CHECK_SEGMENT` environment variable selects the position
//! for the CLI process entry — `twin` (the default) or `rust` (the
//! rollback); any other value is a hard error (fail-closed, the
//! `KERF_READ_SEGMENT`/`KERF_EXPAND_SEGMENT` precedents). The
//! library face stays deterministic — nothing here reads the
//! environment implicitly.

use std::rc::Rc;

use kerf_core::ModuleItem;
use kerf_span::{ByteOffset, ExpansionId, FileId, Span, Symbol};
use kerf_typecheck::{Severity, TypeCode, TypeDiagnostic};

use crate::bootstrap::steady_typecheck_chain::{SteadyCheckChain, SteadyTypecheckChain};
use crate::bootstrap::vm_harness::{as_str, need_fields, value_elems};

/// Which implementation checks the expanded items in the production
/// pipeline (the step-④ check segment position).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CheckSegment {
    /// The steady twin chains on the VM (the production engine) —
    /// the switched position: BOTH checker twins (`typecheck.ktf` +
    /// `infer.ktf`), each compiled once per process through the
    /// seed face, every check a fresh VM run with the expanded item
    /// stream bound through the injection channel.
    Twin,
    /// The Rust checker pair — the rollback band (and the retired
    /// oracle: the parity harnesses' comparison arm and the seed
    /// chain's own checking).
    Rust,
}

impl Default for CheckSegment {
    /// The switched production default (the T-a step-④ ruling:
    /// `Session::new` and every unset position ride the twins).
    fn default() -> Self {
        CheckSegment::Twin
    }
}

impl CheckSegment {
    /// Parse one `KERF_CHECK_SEGMENT` value (the process entry's
    /// fail-closed face): `twin` and `rust` are the only legal
    /// spellings.
    pub fn parse_value(raw: &str) -> Result<Self, String> {
        match raw.trim() {
            "twin" => Ok(CheckSegment::Twin),
            "rust" => Ok(CheckSegment::Rust),
            other => Err(format!(
                "invalid value for KERF_CHECK_SEGMENT: `{other}` (expected `twin` or `rust`)"
            )),
        }
    }

    /// Read the environment override: unset keeps the switched
    /// default (`Twin`); a set value must parse (the caller reports
    /// and exits — never a silent ignore).
    pub fn from_env() -> Result<Self, String> {
        match std::env::var("KERF_CHECK_SEGMENT") {
            Ok(raw) => Self::parse_value(&raw),
            Err(std::env::VarError::NotPresent) => Ok(CheckSegment::Twin),
            Err(std::env::VarError::NotUnicode(raw)) => Err(format!(
                "invalid value for KERF_CHECK_SEGMENT: `{}` (expected `twin` or `rust`)",
                raw.to_string_lossy()
            )),
        }
    }
}

// The per-thread twin-chain caches — one chain each, no keying (the
// read/expand segments key their caches by the nesting cap / work
// budget because those ride environment overrides; the checking
// segment has NO budget override — the inference depth budget is a
// baked 512 on both sides, so there is exactly one chain shape per
// process). Thread-local by necessity (the `ReadSegment`/`
// ExpandSegment` precedents: the chain products carry `Rc` payloads
// — not `Send`/`Sync`); the cache value is plain `Rc` (never shared
// across threads).
//
// Construction failures are NOT cached: a broken chain is a tree
// defect the test suite would catch — retrying keeps the failure
// observable per call instead of freezing it.
thread_local! {
    static PRODUCTION_CHECK_CHAIN: std::cell::RefCell<Option<Rc<SteadyCheckChain>>> =
        const { std::cell::RefCell::new(None) };
    static PRODUCTION_INFER_CHAIN: std::cell::RefCell<Option<Rc<SteadyTypecheckChain>>> =
        const { std::cell::RefCell::new(None) };
}

fn production_check_chain() -> Result<Rc<SteadyCheckChain>, String> {
    PRODUCTION_CHECK_CHAIN.with(|cache| {
        let mut cache = cache.borrow_mut();
        if let Some(chain) = cache.as_ref() {
            return Ok(Rc::clone(chain));
        }
        let chain = Rc::new(SteadyCheckChain::new()?);
        *cache = Some(Rc::clone(&chain));
        Ok(chain)
    })
}

fn production_infer_chain() -> Result<Rc<SteadyTypecheckChain>, String> {
    PRODUCTION_INFER_CHAIN.with(|cache| {
        let mut cache = cache.borrow_mut();
        if let Some(chain) = cache.as_ref() {
            return Ok(Rc::clone(chain));
        }
        let chain = Rc::new(SteadyTypecheckChain::new()?);
        *cache = Some(Rc::clone(&chain));
        Ok(chain)
    })
}

/// Rebuild one finding's span: the offsets from the verdict record,
/// the file retargeted to the session's id (the twin rebuild faces
/// derive spans with `FileId(0)` — the parity harnesses' convention
/// — but the production position checks items read from files
/// interned at any id), the generation ROOT (the expand-segment
/// error-axis `make_span` precedent: diagnostic spans are
/// source-generation spans; the honest boundary sits in this
/// module's header).
fn rebuild_span(s: &kerf_vm::Value, e: &kerf_vm::Value, file: FileId) -> Result<Span, String> {
    let s = as_str(s)?;
    let e = as_str(e)?;
    let start: u32 = s
        .parse()
        .map_err(|_| format!("a cdiag span start is not a decimal offset: `{s}`"))?;
    let end: u32 = e
        .parse()
        .map_err(|_| format!("a cdiag span end is not a decimal offset: `{e}`"))?;
    Span::new(file, ByteOffset(start), ByteOffset(end), ExpansionId::ROOT)
        .map_err(|err| format!("a rebuilt finding span rejected: {err:?}"))
}

/// Rebuild the severity from the verdict's own spelling (the parity
/// text's two words — anything else is a harness defect, never a
/// guess).
fn rebuild_severity(raw: &str) -> Result<Severity, String> {
    match raw {
        "error" => Ok(Severity::Error),
        "warning" => Ok(Severity::Warning),
        other => Err(format!(
            "a verdict severity is neither error nor warning: `{other}`"
        )),
    }
}

/// Rebuild one `("cdiag" code severity s e payload subjects)` record
/// (the conservative checker twin's finding) into a
/// [`TypeDiagnostic`]: the code through the registry lookup, the
/// message through the oracle's own template table (the R8
/// single-source dictionary — the same table the parity sweeps
/// cross-check against the oracle's baked messages on every row),
/// the subjects as interned symbols (the r109 F2 face).
fn rebuild_cdiag(
    record: &kerf_vm::Value,
    heap: &kerf_vm::Heap,
    file: FileId,
) -> Result<TypeDiagnostic, String> {
    let elems = value_elems(record, heap)?;
    need_fields(&elems, 7, "the checker twin's cdiag record")?;
    if as_str(elems[0])? != "cdiag" {
        return Err(format!(
            "a non-cdiag record in the checker twin's diags section: {}",
            as_str(elems[0])?
        ));
    }
    let code = TypeCode::from_registry_str(as_str(elems[1])?).ok_or_else(|| {
        format!(
            "the checker twin's code is not in the registry: {}",
            as_str(elems[1]).unwrap_or("<unreadable>")
        )
    })?;
    let severity = rebuild_severity(as_str(elems[2])?)?;
    let span = rebuild_span(elems[3], elems[4], file)?;
    let message = crate::bootstrap::typecheck_parity::render_cdiag_template(elems[5], heap)?;
    let subject_elems = value_elems(elems[6], heap)?;
    let mut subjects = Vec::with_capacity(subject_elems.len());
    for subject in subject_elems {
        subjects.push(
            Symbol::new(as_str(subject)?)
                .map_err(|err| format!("a cdiag subject is not a valid identifier: {err:?}"))?,
        );
    }
    Ok(TypeDiagnostic {
        code,
        severity,
        span,
        message,
        subjects,
    })
}

/// Rebuild one `("tdiag" code severity s e payload)` record (the
/// inference twin's finding) — the same rebuild as the cdiag face
/// minus the subject set (the inference layer's messages name no
/// user identifier the driver re-spells; the parity record carries
/// no subjects field).
fn rebuild_tdiag(
    record: &kerf_vm::Value,
    heap: &kerf_vm::Heap,
    file: FileId,
) -> Result<TypeDiagnostic, String> {
    let elems = value_elems(record, heap)?;
    need_fields(&elems, 6, "the inference twin's tdiag record")?;
    if as_str(elems[0])? != "tdiag" {
        return Err(format!(
            "a non-tdiag record in the inference twin's diags section: {}",
            as_str(elems[0])?
        ));
    }
    let code = TypeCode::from_registry_str(as_str(elems[1])?).ok_or_else(|| {
        format!(
            "the inference twin's code is not in the registry: {}",
            as_str(elems[1]).unwrap_or("<unreadable>")
        )
    })?;
    let severity = rebuild_severity(as_str(elems[2])?)?;
    let span = rebuild_span(elems[3], elems[4], file)?;
    let message = crate::bootstrap::infer_parity::render_tdiag_template(elems[5], heap)?;
    Ok(TypeDiagnostic {
        code,
        severity,
        span,
        message,
        subjects: Vec::new(),
    })
}

/// Walk one verdict's `("diags" record...)` section into the rebuilt
/// findings (the section tag checked, the records rebuilt in the
/// twin's report order — the parity sweeps pin that order against
/// the oracle's collection order).
fn rebuild_diag_section(
    section: &kerf_vm::Value,
    heap: &kerf_vm::Heap,
    file: FileId,
    rebuild_one: fn(&kerf_vm::Value, &kerf_vm::Heap, FileId) -> Result<TypeDiagnostic, String>,
) -> Result<Vec<TypeDiagnostic>, String> {
    let elems = value_elems(section, heap)?;
    need_fields(&elems, 2, "the verdict's diags section")?;
    if as_str(elems[0])? != "diags" {
        return Err(format!(
            "the verdict's diags section tag drifted: {}",
            as_str(elems[0])?
        ));
    }
    let records = value_elems(elems[1], heap)?;
    let mut out = Vec::with_capacity(records.len());
    for record in records {
        out.push(rebuild_one(record, heap, file)?);
    }
    Ok(out)
}

/// The verdict's top-level shape check: `("ok" table diags)` — the
/// `ok` tag means the module driver completed (the twins never
/// reject a checked program: findings are DATA, carried in the
/// diags section; a non-`ok` tag is a harness defect).
fn verdict_ok(value: &kerf_vm::Value, heap: &kerf_vm::Heap) -> Result<(), String> {
    let elems = value_elems(value, heap)?;
    need_fields(&elems, 3, "the twin's verdict record")?;
    if as_str(elems[0])? != "ok" {
        return Err(format!(
            "the twin's verdict tag is `{}` — the module driver must complete",
            as_str(elems[0])?
        ));
    }
    Ok(())
}

/// The checker twin's whole verdict rebuilt (the production entry —
/// called by `SteadyCheckChain::check_production`): the top-level
/// `("ok" table diags)` shape checked, the diags section walked into
/// rebuilt findings in report order. The table section (the pass-1
/// define axes) is the parity sweep's own comparison business — the
/// production position consumes the findings channel only.
pub(crate) fn rebuild_check_verdict(
    value: &kerf_vm::Value,
    heap: &kerf_vm::Heap,
    file: FileId,
) -> Result<Vec<TypeDiagnostic>, String> {
    verdict_ok(value, heap)?;
    let elems = value_elems(value, heap)?;
    rebuild_diag_section(elems[2], heap, file, rebuild_cdiag)
}

/// The inference twin's whole verdict rebuilt (the production entry
/// — called by `SteadyTypecheckChain::infer_production`): the
/// top-level `("ok" types diags)` shape checked, the diags section
/// walked into rebuilt findings. The types section (the typed
/// program axis) is the parity face's comparison business — the
/// production position consumes the diagnostics channel only (the
/// oracle spine's own `infer_module` wiring).
pub(crate) fn rebuild_infer_verdict(
    value: &kerf_vm::Value,
    heap: &kerf_vm::Heap,
    file: FileId,
) -> Result<Vec<TypeDiagnostic>, String> {
    verdict_ok(value, heap)?;
    let elems = value_elems(value, heap)?;
    rebuild_diag_section(elems[2], heap, file, rebuild_tdiag)
}

/// The production checking: one expanded item stream through BOTH
/// checker twin chains on the VM (the switched position's single
/// entry — `ParsedProgram::typecheck`'s twin arm rides it; the
/// conservative checker's findings first, the inference engine's
/// second, the oracle spine's own collection order). A harness
/// defect (chain construction, the VM run, a decode) renders loudly
/// as `Err` — the caller surfaces it as a driver error, never a
/// silent Rust fallback (SOP §2.3-4).
pub fn production_check(items: &[ModuleItem], file: FileId) -> Result<Vec<TypeDiagnostic>, String> {
    let check_chain = production_check_chain()?;
    let infer_chain = production_infer_chain()?;
    let check_diags = check_chain.check_production(items, file)?;
    let infer_diags = infer_chain.infer_production(items, file)?;
    let mut all = check_diags;
    all.extend(infer_diags);
    Ok(all)
}

// The rebuilt-record unit face: the span/severity rebuilders and
// the env policy. The pipeline-level integration faces live in the
// root test tree (`check_segment_switch_tests.rs` — the corpus
// sweep, the rollback band, and the cross-stage consumption).
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn env_values_parse_fail_closed() {
        assert_eq!(CheckSegment::parse_value("twin"), Ok(CheckSegment::Twin));
        assert_eq!(CheckSegment::parse_value("rust"), Ok(CheckSegment::Rust));
        // Surrounding whitespace is tolerated (the read/expand
        // segment precedents: a trailing newline from a shell
        // `FOO=bar\n` export must not become a hard failure).
        assert_eq!(CheckSegment::parse_value(" rust "), Ok(CheckSegment::Rust));
        for bad in ["", "twins", "TWIN", "c", "0", "oracle"] {
            assert!(
                CheckSegment::parse_value(bad).is_err(),
                "`{bad}` must not parse as a check segment"
            );
        }
    }

    #[test]
    fn spans_rebuild_with_the_session_file_and_root_generation() {
        // The record fields carry decimal offset strings (the parity
        // family convention); the rebuild pairs them with the
        // session's file id and the ROOT generation (the error-axis
        // precedent — see the module header's honest boundary).
        let s = kerf_vm::Value::Str(std::rc::Rc::from("12"));
        let e = kerf_vm::Value::Str(std::rc::Rc::from("34"));
        let span = rebuild_span(&s, &e, FileId(7)).expect("a well-formed span record");
        assert_eq!(span.file_id, FileId(7));
        assert_eq!(span.start, ByteOffset(12));
        assert_eq!(span.end, ByteOffset(34));
        assert_eq!(span.expansion_id, ExpansionId::ROOT);

        // A non-decimal offset is a loud defect, never a guess.
        let bad = kerf_vm::Value::Str(std::rc::Rc::from("12.5"));
        assert!(rebuild_span(&bad, &e, FileId(7)).is_err());
        let neg = kerf_vm::Value::Str(std::rc::Rc::from("-1"));
        assert!(rebuild_span(&neg, &e, FileId(7)).is_err());
    }

    #[test]
    fn severity_rebuild_takes_only_the_two_spellings() {
        assert_eq!(rebuild_severity("error").unwrap(), Severity::Error);
        assert_eq!(rebuild_severity("warning").unwrap(), Severity::Warning);
        for bad in ["Error", "err", "warn", "", "note"] {
            assert!(
                rebuild_severity(bad).is_err(),
                "`{bad}` must not parse as a severity"
            );
        }
    }
}

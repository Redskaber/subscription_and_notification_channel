//! The T-a switch-window step-④ READ segment production position
//! (w-t-a-switch-window.md §3 r145+ row — bootstrap-completion-plan
//! §4.3 step ④): the `.ktf` production read switches from the Rust
//! target reader to the steady twin chain (the two read twins
//! compiled once per process, running on the VM — the production
//! engine), and the Rust reader retires to the oracle face (the
//! parity harnesses' comparison arm, the seed chain's own read, and
//! the rollback band).
//!
//! The dual-chain decoupling (SOP §21.12-28②) instantiated inside
//! the driver:
//!
//! * the PRODUCTION face — [`crate::pipeline::parse_with`] on
//!   `ReaderFace::Target` — rides [`ReadSegment::Twin`] (the
//!   default after the switch);
//! * the SEED/ORACLE faces — the bootstrap bridge
//!   (`read_target_source_for_bootstrap`) and the A pass of the
//!   A/B/C pipeline (`rust_compile_ccf`) — PIN the Rust read
//!   explicitly: their comparisons stay differential (the fixpoint
//!   purity leg's "twin front end == Rust production bridge"
//!   assertion must never collapse into a self-comparison, and the
//!   A ≡ B observation row keeps its read-segment coverage).
//!
//! The rollback band (SOP §14.6.4 rule 5 — measurement first): the
//! `KERF_READ_SEGMENT` environment variable selects the position
//! for the CLI process entry — `twin` (the default) or `rust` (the
//! rollback); any other value is a hard error (fail-closed, the
//! `DepthLimits` precedent: a silently ignored position override
//! would be a lie). The library face stays deterministic — nothing
//! here reads the environment implicitly.

use std::collections::HashMap;
use std::rc::Rc;

use kerf_reader::ReadError;
use kerf_span::FileId;
use kerf_syntax::SyntaxObject;

use crate::bootstrap::steady_target_reader_chain::SteadyTargetReaderChain;

/// Which implementation reads `.ktf` source in the production
/// pipeline (the step-④ read segment position).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ReadSegment {
    /// The steady twin chain on the VM (the production engine) —
    /// the switched position: `target-lexer.ktf` + the K20 host
    /// bridge + `target-parser.ktf`, the twins compiled once per
    /// process (per distinct nesting cap) through the seed face.
    Twin,
    /// The Rust target reader — the rollback band (and the retired
    /// oracle: the parity harnesses' comparison arm and the seed
    /// chain's own read).
    Rust,
}

impl Default for ReadSegment {
    /// The switched production default (the T-a step-④ ruling:
    /// `Session::new` and every unset position ride the twins).
    fn default() -> Self {
        ReadSegment::Twin
    }
}

impl ReadSegment {
    /// Parse one `KERF_READ_SEGMENT` value (the process entry's
    /// fail-closed face): `twin` and `rust` are the only legal
    /// spellings.
    pub fn parse_value(raw: &str) -> Result<Self, String> {
        match raw.trim() {
            "twin" => Ok(ReadSegment::Twin),
            "rust" => Ok(ReadSegment::Rust),
            other => Err(format!(
                "invalid value for KERF_READ_SEGMENT: `{other}` (expected `twin` or `rust`)"
            )),
        }
    }

    /// Read the environment override: unset keeps the switched
    /// default (`Twin`); a set value must parse (the caller reports
    /// and exits — never a silent ignore).
    pub fn from_env() -> Result<Self, String> {
        match std::env::var("KERF_READ_SEGMENT") {
            Ok(raw) => Self::parse_value(&raw),
            Err(std::env::VarError::NotPresent) => Ok(ReadSegment::Twin),
            Err(std::env::VarError::NotUnicode(raw)) => Err(format!(
                "invalid value for KERF_READ_SEGMENT: `{}` (expected `twin` or `rust`)",
                raw.to_string_lossy()
            )),
        }
    }
}

/// The production read's failure face — the two families the
/// production position must never confuse.
#[derive(Debug)]
pub enum ProductionReadError {
    /// The program's own rejection (the rebuilt [`ReadError`] — the
    /// same error the oracle read produces, so the diagnostics
    /// render identically on both positions).
    Program(ReadError),
    /// A harness defect — the twin chain or a decode broke. A
    /// compiler defect: rendered loudly, never a silent Rust
    /// fallback (SOP §2.3-4 — errors over silence).
    Defect(String),
}

// The per-thread twin-chain cache, keyed by the reader nesting
// cap the chain was constructed under: the twin parser's
// `tp_limit` constant must mirror the process's effective
// `KERF_READER_NESTING_LIMIT` (an over-limit source rejects with
// the same key on both positions — the rollback band's parity
// obligation), so each distinct cap gets its own once-compiled
// chain. The default cap covers everything but the deep-synthesis
// corpus; the cache keeps the override honest without recompiling
// per read.
//
// Thread-local by necessity: the chain's products (`Bytecode`, the
// twin items) carry `Rc` payloads — not `Send`/`Sync`, so a global
// static cannot hold them; the cache value is plain `Rc` (never
// shared across threads). The cost shape is the status quo's
// (every steady-chain test today constructs its own chain; the
// cache only amortizes within one thread — the CLI's single main
// thread constructs exactly once).
thread_local! {
    static PRODUCTION_CHAINS: std::cell::RefCell<HashMap<usize, Rc<SteadyTargetReaderChain>>> =
        std::cell::RefCell::new(HashMap::new());
}

/// The cached (or first-constructed) production chain for one
/// nesting cap. Construction failures are NOT cached: a broken
/// chain is a tree defect the test suite would catch — retrying
/// keeps the failure observable per call instead of freezing it.
fn production_chain(nesting: usize) -> Result<Rc<SteadyTargetReaderChain>, String> {
    PRODUCTION_CHAINS.with(|cache| {
        let mut cache = cache.borrow_mut();
        match cache.get(&nesting) {
            Some(chain) => Ok(Rc::clone(chain)),
            None => {
                let chain = Rc::new(SteadyTargetReaderChain::new_with_limit(nesting)?);
                cache.insert(nesting, Rc::clone(&chain));
                Ok(chain)
            }
        }
    })
}

/// Retarget a rebuilt rejection's spans to the session's file id.
///
/// The twin rebuild faces derive spans with `FileId(0)` (the parity
/// harnesses' convention — every harness interns at zero), but the
/// production position reads files interned at any id; a span that
/// names the wrong file renders against the wrong source. The six
/// span-carrying variants are retargeted; the offset-only variants
/// carry no file identity and pair with the caller's id.
fn retarget_read_error(err: ReadError, file: FileId) -> ReadError {
    let retarget = |mut span: kerf_span::Span| {
        span.file_id = file;
        span
    };
    match err {
        ReadError::MalformedNumber { text, span } => ReadError::MalformedNumber {
            text,
            span: retarget(span),
        },
        ReadError::IntOutOfRange { text, span } => ReadError::IntOutOfRange {
            text,
            span: retarget(span),
        },
        ReadError::FloatOutOfRange { text, span } => ReadError::FloatOutOfRange {
            text,
            span: retarget(span),
        },
        ReadError::UnexpectedTargetToken { text, span } => ReadError::UnexpectedTargetToken {
            text,
            span: retarget(span),
        },
        ReadError::UnsupportedTargetForm { form, span } => ReadError::UnsupportedTargetForm {
            form,
            span: retarget(span),
        },
        other => other,
    }
}

/// Retarget the rebuilt FORMS tree's spans to the session's file id
/// (the r147 K163 fourth-instance clearance: the twin rebuild faces
/// derive spans with `FileId(0)` — the parity harnesses' convention,
/// every harness interns at zero — and the r145 switch's sweeps
/// validated in exactly that domain, so the TREE face never
/// retargeted; the first non-zero-id session exposed every
/// downstream span consumer naming the wrong file). The walk is
/// exhaustive over every span-carrying shape on purpose: a new
/// variant fails this match at compile time (the FIX-16 discipline).
fn retarget_forms(forms: &mut [SyntaxObject], file: FileId) {
    for form in forms.iter_mut() {
        form.span.file_id = file;
        if let kerf_syntax::StxDatum::List(children) = &mut form.datum {
            retarget_forms(children, file);
        }
    }
}

/// The production read: one `.ktf` source through the twin chain on
/// the VM (the switched position's single entry — the parse spine's
/// `ReaderFace::Target` arm and the REPL probe both ride it).
pub fn production_read(
    source: &str,
    nesting: usize,
    file: FileId,
) -> Result<Vec<SyntaxObject>, ProductionReadError> {
    let chain = production_chain(nesting).map_err(ProductionReadError::Defect)?;
    match chain.read_production(source) {
        Err(defect) => Err(ProductionReadError::Defect(defect)),
        Ok(Err(err)) => Err(ProductionReadError::Program(retarget_read_error(err, file))),
        Ok(Ok(mut forms)) => {
            // The tree face rides the same retarget as the error
            // face (the K163 fourth-instance clearance — see
            // `retarget_forms`): every rebuilt span names the
            // session's file, so the expansion, the checking, and
            // every runtime span consumer downstream render against
            // the right source.
            retarget_forms(&mut forms, file);
            Ok(forms)
        }
    }
}

#[cfg(test)]
mod tests {
    //! The read-segment policy's unit face: env parsing (the
    //! fail-closed three-state) and the span retarget walk. The
    //! pipeline-level integration faces live in the root test tree
    //! (`read_segment_switch_tests.rs` — the corpus sweep, the
    //! rollback band, and the cross-stage consumption).

    use super::*;

    #[test]
    fn env_values_parse_fail_closed() {
        assert_eq!(ReadSegment::parse_value("twin"), Ok(ReadSegment::Twin));
        assert_eq!(ReadSegment::parse_value("rust"), Ok(ReadSegment::Rust));
        // Surrounding whitespace is tolerated (the DepthLimits
        // precedent does not, but a trailing newline from a shell
        // `FOO=bar\n` export must not become a hard failure).
        assert_eq!(ReadSegment::parse_value(" rust "), Ok(ReadSegment::Rust));
        for bad in ["", "twins", "TWIN", "c", "0", "oracle"] {
            assert!(
                ReadSegment::parse_value(bad).is_err(),
                "`{bad}` must not parse as a read segment"
            );
        }
    }

    #[test]
    fn span_retarget_touches_every_span_carrying_variant() {
        let file = FileId(7);
        let span = |s: u32| {
            kerf_span::Span::new(
                FileId(0),
                kerf_span::ByteOffset(s),
                kerf_span::ByteOffset(s + 1),
                kerf_span::ExpansionId::ROOT,
            )
            .unwrap()
        };
        let cases: Vec<ReadError> = vec![
            ReadError::MalformedNumber {
                text: "1.2.3".into(),
                span: span(2),
            },
            ReadError::IntOutOfRange {
                text: "99999999999999999999".into(),
                span: span(3),
            },
            ReadError::FloatOutOfRange {
                text: "1e999".into(),
                span: span(4),
            },
            ReadError::UnexpectedTargetToken {
                text: "}".into(),
                span: span(5),
            },
            ReadError::UnsupportedTargetForm {
                form: "impl",
                span: span(6),
            },
        ];
        for err in cases {
            let retargeted = retarget_read_error(err, file);
            assert_eq!(retargeted.token_span().map(|s| s.file_id), Some(file));
        }
        // The offset-only family passes through untouched (no span
        // to retarget — the diagnostic pairs it with the caller's
        // file id; the r151 single-skin retarget moves the guard
        // onto the target-skin twin).
        let passthrough = ReadError::StrayTargetDelim {
            at: kerf_span::ByteOffset(9),
            closing: '}',
        };
        assert!(matches!(
            retarget_read_error(passthrough, file),
            ReadError::StrayTargetDelim { .. }
        ));
    }
}

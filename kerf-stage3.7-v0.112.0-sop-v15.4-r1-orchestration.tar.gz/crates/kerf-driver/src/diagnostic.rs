//! The structured diagnostic (docs/stage0.md §8.7) — Stage 0 slice.
//!
//! «Errors are data, not exceptions» (§12.2): every pipeline stage
//! failure becomes a [`Diagnostic`] value; the driver collects them
//! across files and renders them in one pass instead of unwinding at
//! the first error.
//!
//! Stage 0 slice decisions (plan-0.8.md, disclosed):
//! - `primary_span` is `Option<Span>`: the reader's four payload-only
//!   variants and the compiler's three product-shape variants have no
//!   position *by design* — a fabricated span would be a DUMMY span
//!   (the 0.1 ruling family: no DUMMY spans, ever).
//! - [`DiagnosticCode`] is stage-level, not variant-level — with one
//!   Stage 1.1 exception: [`DiagnosticCode::Typecheck`] carries the
//!   checker's E0xxx registry code so the rendered tag is the stable
//!   registry string (`error[E0002]`), exactly where stage-1-plan §4
//!   said the two schemes join (at the wiring, not in the checker).
//! - `children`/`suggestions` are deliberately absent: no producer
//!   exists in Stage 0, and an always-empty field is a stub (R1);
//!   the extension belongs to the Stage 1+ diagnostics agenda
//!   (registered, beyond the 0.10 interface-freeze scope).
//! - [`Severity`] carries all four §8.7 levels; `Error` and `Warning`
//!   have producers since Stage 1.1 (the checker's R8 is the first
//!   Warning producer; Note/Help stay producerless contract slots).

use kerf_compiler::CompileError;
use kerf_span::{ByteOffset, FileId, Span};
use kerf_vm::Builtin;
use kerf_vm::RuntimeError;
use kerf_vm::{
    arity_mismatch_text, assign_to_captured_text, eof_text, extern_call_requires_backend_text,
    type_mismatch_text, unbound_global_text, unhandled_effect_text,
};

use crate::target_skin::{target_context, target_name};

/// The user-facing runtime message: the engine Display re-composed
/// with target-skin name spellings mapped through the skin
/// dictionary (§9.96 skin/skeleton separation — the canonical names
/// the engines report are the Stx-internal vocabulary, and the
/// target skin spells several of them differently:
/// `first`/`rest`/`write_line`/`==`; the message shapes themselves
/// are single-sourced in `kerf-vm`'s `*_text` helpers). The r151
/// single-skin retarget: the former S-expr verbatim arm left the
/// tree with the W-SEXP-RETIRE blade 2 — the target rendering is
/// the only rendering.
pub(crate) fn runtime_message_on_target(err: &RuntimeError) -> String {
    match err {
        RuntimeError::ArityMismatch {
            func,
            expected,
            actual,
            ..
        } => {
            let callee = match func {
                Some(name) => target_name(name.as_str()),
                None => "#<anonymous>".to_string(),
            };
            arity_mismatch_text(&callee, *expected, *actual)
        }
        RuntimeError::TypeMismatch {
            context,
            demanded,
            got,
            ..
        } => type_mismatch_text(&target_context(context), demanded, got),
        RuntimeError::UnboundGlobal { name, .. } => {
            unbound_global_text(&target_name(name.as_str()))
        }
        RuntimeError::UnhandledEffect { effect, .. } => {
            unhandled_effect_text(&target_name(effect.as_str()))
        }
        RuntimeError::ExternCallRequiresBackend { name, .. } => {
            extern_call_requires_backend_text(&target_name(name.as_str()))
        }
        RuntimeError::AssignToCaptured { name, .. } => {
            assign_to_captured_text(&target_name(name.as_str()))
        }
        RuntimeError::Eof { .. } => eof_text(&target_name(Builtin::ReadLine.name())),
        _ => err.to_string(),
    }
}

/// Re-spell a compile-time stage message's identifier subjects for
/// the target face (r109 F2 — the compile-time twin of
/// [`runtime_message_on_target`]): the owning stage already rendered
/// the canonical message through its single-source shape, and the
/// subjects are the interned identifiers the message names: each
/// subject's exact backticked canonical spelling is replaced by its
/// skin-dictionary spelling (an exact-token replace — backtick
/// delimiters make substring false positives impossible). A pure
/// presentation pass: no stage payload changes (SKIN-DIAG-2; the
/// r151 single-skin state — the target spelling is the only face).
pub(crate) fn skin_map_stage_message(message: &str, subjects: &[&kerf_span::Symbol]) -> String {
    let mut out = message.to_string();
    for subject in subjects {
        let canonical = format!("`{}`", subject.as_str());
        let spelled = format!("`{}`", target_name(subject.as_str()));
        if canonical != spelled {
            out = out.replace(&canonical, &spelled);
        }
    }
    out
}

/// How severe a diagnostic is (§8.7 contract shape).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Severity {
    Error,
    Warning,
    Note,
    Help,
}

impl std::fmt::Display for Severity {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let s = match self {
            Severity::Error => "error",
            Severity::Warning => "warning",
            Severity::Note => "note",
            Severity::Help => "help",
        };
        f.write_str(s)
    }
}

/// Which pipeline stage produced the diagnostic.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DiagnosticCode {
    Read,
    Expand,
    Compile,
    Runtime,
    Driver,
    /// The conservative static checker (Stage 1.1 wiring). Carries
    /// the E0xxx registry code; the rendering tag is the registry
    /// string itself (`E0001`..=`E0008`) — rustc-style
    /// `error[E0002]:` — while `Diagnostic::code` stays stage-level
    /// for every other producer.
    Typecheck(kerf_typecheck::TypeCode),
}

impl DiagnosticCode {
    /// The stable rendering tag (`kerf-read` etc.; `E0001`.. for the
    /// checker).
    pub fn tag(self) -> &'static str {
        match self {
            DiagnosticCode::Read => "kerf-read",
            DiagnosticCode::Expand => "kerf-expand",
            DiagnosticCode::Compile => "kerf-compile",
            DiagnosticCode::Runtime => "kerf-runtime",
            DiagnosticCode::Driver => "kerf-driver",
            DiagnosticCode::Typecheck(code) => code.as_str(),
        }
    }
}

impl std::fmt::Display for DiagnosticCode {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(self.tag())
    }
}

/// One structured diagnostic: severity, stage code, message, file and
/// (when the producing error carried one) the primary span.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Diagnostic {
    pub severity: Severity,
    pub code: DiagnosticCode,
    pub message: String,
    pub file: FileId,
    pub primary_span: Option<Span>,
}

impl Diagnostic {
    /// Build a diagnostic from a reader error. The literal family
    /// (`MalformedNumber` / `IntOutOfRange` / `FloatOutOfRange`) carries its whole-token span — the
    /// diagnostic points at the literal's real extent (v0.40.0,
    /// stage0.md §9.71 — rustc underlines the full literal); every
    /// other positioned error becomes an empty span at its byte
    /// offset (empty spans are legal and carry the real offset —
    /// `Span::new` invariant), and a payload-only error keeps `None`.
    pub fn from_read(err: &kerf_reader::ReadError, file: FileId) -> Self {
        let primary_span = err.token_span().or_else(|| {
            err.offset().and_then(|ByteOffset(at)| {
                Span::new(
                    file,
                    ByteOffset(at),
                    ByteOffset(at),
                    kerf_span::ExpansionId::ROOT,
                )
                .ok()
            })
        });
        Diagnostic {
            severity: Severity::Error,
            code: DiagnosticCode::Read,
            message: err.to_string(),
            file,
            primary_span,
        }
    }

    /// Build a diagnostic from an expander error (every variant
    /// carries a span; the span names its own file). The message's
    /// identifier subjects re-spell through the skin dictionary
    /// (r109 F2).
    pub fn from_expand(err: &kerf_expander::ExpandError) -> Self {
        Diagnostic {
            severity: Severity::Error,
            code: DiagnosticCode::Expand,
            message: skin_map_stage_message(&err.to_string(), &err.subject_symbols()),
            file: err.span().file_id,
            primary_span: Some(err.span()),
        }
    }

    /// Build a diagnostic from a module-loading error (sub-stage
    /// 0.9: the declaration-graph validation face — cycles, missing
    /// and duplicate declarations; rendered under the expand tag
    /// because loading is part of the expansion stage).
    pub fn from_module(err: &kerf_expander::ModuleError) -> Self {
        Diagnostic {
            severity: Severity::Error,
            code: DiagnosticCode::Expand,
            message: skin_map_stage_message(&err.to_string(), &err.subject_symbols()),
            file: err.span().file_id,
            primary_span: Some(err.span()),
        }
    }

    /// Build a diagnostic from a compiler error. Spanned variants
    /// carry their own file; the three product-shape variants are
    /// position-less by design and take the caller's `file` (the
    /// file being compiled — never a fabricated `FileId(0)`).
    pub fn from_compile(err: &CompileError, file: FileId) -> Self {
        let primary_span = err.span();
        let file = primary_span.map(|s| s.file_id).unwrap_or(file);
        Diagnostic {
            severity: Severity::Error,
            code: DiagnosticCode::Compile,
            message: skin_map_stage_message(&err.to_string(), &err.subject_symbols()),
            file,
            primary_span,
        }
    }

    /// Build a diagnostic from a C-emitter refusal (Stage 2.6, the
    /// `emit-c` face). The emitter carries no source positions —
    /// its guards are product-shape level — so the diagnostic rides
    /// the stage code with the message alone.
    pub fn from_emit(err: &kerf_cbackend::EmitError, file: FileId) -> Self {
        Diagnostic {
            severity: Severity::Error,
            code: DiagnosticCode::Compile,
            message: err.to_string(),
            file,
            primary_span: None,
        }
    }

    /// Build a diagnostic from a runtime error (every variant carries
    /// a span resolved through the debug-info table — §12.1 VM row).
    /// The message renders through the skin-aware pass
    /// (`runtime_message_on_target`): the engine Display re-composed
    /// with the canonical name spellings mapped through the skin
    /// dictionary.
    pub fn from_runtime(err: &RuntimeError) -> Self {
        let span = err.span();
        Diagnostic {
            severity: Severity::Error,
            code: DiagnosticCode::Runtime,
            message: runtime_message_on_target(err),
            file: span.file_id,
            primary_span: Some(span),
        }
    }

    /// Build a diagnostic from a checker finding (Stage 1.1 wiring).
    /// The checker severity maps onto the same-named driver levels
    /// (its two-level subset of the §8.7 contract); the message is
    /// passed through verbatim — the checker pre-renders R8-shaped
    /// messages and the driver never rewrites stage messages (the
    /// single-source dictionary).
    pub fn from_typecheck(td: &kerf_typecheck::TypeDiagnostic) -> Self {
        let severity = match td.severity {
            kerf_typecheck::Severity::Error => Severity::Error,
            kerf_typecheck::Severity::Warning => Severity::Warning,
        };
        let subjects: Vec<&kerf_span::Symbol> = td.subjects.iter().collect();
        Diagnostic {
            severity,
            code: DiagnosticCode::Typecheck(td.code),
            message: skin_map_stage_message(&td.message, &subjects),
            file: td.span.file_id,
            primary_span: Some(td.span),
        }
    }

    /// A driver-level error (bad arguments, unknown files): position
    /// is whatever the caller can honestly provide.
    pub fn driver_error(
        message: impl Into<String>,
        file: FileId,
        primary_span: Option<Span>,
    ) -> Self {
        Diagnostic {
            severity: Severity::Error,
            code: DiagnosticCode::Driver,
            message: message.into(),
            file,
            primary_span,
        }
    }
}

#[cfg(test)]
mod tests {
    //! Diagnostic conversion tests (FP3): the 41-variant exhaustive
    //! mapping — position presence and stage attribution per variant,
    //! plus severity/code display and R8 message passthrough.

    use super::*;
    use kerf_reader::ReadError;
    use kerf_span::SymbolError;
    use kerf_span::{ByteOffset, ExpansionId, Symbol};

    fn file() -> FileId {
        FileId(0)
    }

    fn span(start: u32, end: u32) -> Span {
        Span::new(
            file(),
            ByteOffset(start),
            ByteOffset(end),
            ExpansionId::ROOT,
        )
        .expect("test span")
    }

    #[test]
    fn severity_display_is_lowercase_single_word() {
        assert_eq!(Severity::Error.to_string(), "error");
        assert_eq!(Severity::Warning.to_string(), "warning");
        assert_eq!(Severity::Note.to_string(), "note");
        assert_eq!(Severity::Help.to_string(), "help");
    }

    #[test]
    fn code_tags_are_stable() {
        assert_eq!(DiagnosticCode::Read.tag(), "kerf-read");
        assert_eq!(DiagnosticCode::Expand.to_string(), "kerf-expand");
        assert_eq!(DiagnosticCode::Compile.to_string(), "kerf-compile");
        assert_eq!(DiagnosticCode::Runtime.to_string(), "kerf-runtime");
        assert_eq!(DiagnosticCode::Driver.to_string(), "kerf-driver");
        assert_eq!(
            DiagnosticCode::Typecheck(kerf_typecheck::TypeCode::ArityMismatch).tag(),
            "E0002",
            "the checker tag is the registry string"
        );
    }

    #[test]
    fn from_typecheck_maps_code_severity_span_and_message() {
        let td = kerf_typecheck::TypeDiagnostic::new(
            kerf_typecheck::TypeCode::ArityMismatch,
            kerf_typecheck::Severity::Error,
            span(4, 9),
            "this function takes 1 argument but 2 were supplied".to_owned(),
        );
        let d = Diagnostic::from_typecheck(&td);
        assert_eq!(
            d.code,
            DiagnosticCode::Typecheck(kerf_typecheck::TypeCode::ArityMismatch)
        );
        assert_eq!(d.severity, Severity::Error);
        assert_eq!(d.primary_span, Some(span(4, 9)));
        assert_eq!(d.file, file());
        assert_eq!(
            d.message, "this function takes 1 argument but 2 were supplied",
            "the message passes through verbatim (single-source dictionary)"
        );
    }

    #[test]
    fn from_typecheck_maps_warning_level() {
        let td = kerf_typecheck::TypeDiagnostic::new(
            kerf_typecheck::TypeCode::AssignmentTargetSurprise,
            kerf_typecheck::Severity::Warning,
            span(0, 4),
            "assignment rebinds builtin `car`".to_owned(),
        );
        let d = Diagnostic::from_typecheck(&td);
        assert_eq!(d.severity, Severity::Warning, "R8 lands on Warning");
        assert_eq!(d.code.tag(), "E0008");
    }

    #[test]
    fn from_typecheck_error_renders_registry_tag() {
        // The joined rendering face: `error[E0001]:` — the registry
        // code in the bracket, not a stage tag.
        let td = kerf_typecheck::TypeDiagnostic::new(
            kerf_typecheck::TypeCode::UnboundVariable,
            kerf_typecheck::Severity::Error,
            span(1, 2),
            "unbound variable `g`".to_owned(),
        );
        let d = Diagnostic::from_typecheck(&td);
        let head = format!("{}[{}]: {}", d.severity, d.code.tag(), d.message);
        assert_eq!(head, "error[E0001]: unbound variable `g`");
    }

    #[test]
    fn read_error_position_becomes_empty_span_at_offset() {
        // The r151 single-skin retarget: the retired S-expr
        // `UnclosedList` face moves this guard onto the target-skin
        // twin (same offset discipline).
        let err = ReadError::UnclosedTargetDelim {
            opened_at: ByteOffset(9),
            opening: "(",
        };
        let d = Diagnostic::from_read(&err, file());
        assert_eq!(d.code, DiagnosticCode::Read);
        assert_eq!(
            d.primary_span,
            Some(span(9, 9)),
            "a byte offset renders as an empty span at that offset"
        );
        assert_eq!(d.file, file());
    }

    #[test]
    fn read_error_without_position_keeps_none() {
        for err in [
            ReadError::InvalidSymbol(SymbolError::InvalidSymbol {
                text: "a\u{0}b".to_owned(),
            }),
            ReadError::NestingDepthExceeded {
                depth: 257,
                limit: 256,
            },
        ] {
            let d = Diagnostic::from_read(&err, file());
            assert!(
                d.primary_span.is_none(),
                "{err:?} must not fabricate a span"
            );
        }
    }

    #[test]
    fn literal_family_renders_its_whole_token_span() {
        // v0.40.0 (stage0.md §9.71): the complete-atom rejections
        // carry the literal's real byte extent — the diagnostic points
        // at the token, not at a fabricated byte and not at nothing.
        let cases: Vec<(ReadError, (u32, u32))> = vec![
            (
                ReadError::MalformedNumber {
                    text: "1.2.3".to_owned(),
                    span: span(11, 16),
                },
                (11, 16),
            ),
            (
                ReadError::IntOutOfRange {
                    text: "9223372036854775808".to_owned(),
                    span: span(4, 23),
                },
                (4, 23),
            ),
            (
                ReadError::FloatOutOfRange {
                    text: "1e999".to_owned(),
                    span: span(4, 9),
                },
                (4, 9),
            ),
        ];
        for (i, (err, (s, e))) in cases.iter().enumerate() {
            let d = Diagnostic::from_read(err, file());
            let got = d
                .primary_span
                .unwrap_or_else(|| panic!("case {i} must carry the token span"));
            assert_eq!((got.start.0, got.end.0), (*s, *e), "case {i} extent");
            assert_eq!(got.file_id, file(), "case {i} file");
        }
    }

    #[test]
    fn every_read_variant_maps_with_correct_position_presence() {
        // All twelve reader variants: five single-offset, five
        // token-span (the literal family plus the target position and
        // scope faces), two payload-only (the r151 single-skin
        // retarget: the four retired S-expr variants swap for their
        // target-skin twins, keeping the walk exhaustive).
        let cases: Vec<(ReadError, bool)> = vec![
            (
                ReadError::UnclosedTargetDelim {
                    opened_at: ByteOffset(0),
                    opening: "{",
                },
                true,
            ),
            (
                ReadError::StrayTargetDelim {
                    at: ByteOffset(1),
                    closing: '}',
                },
                true,
            ),
            (
                ReadError::UnterminatedString {
                    started_at: ByteOffset(2),
                },
                true,
            ),
            (
                ReadError::InvalidEscape {
                    escape: 'z',
                    at: ByteOffset(3),
                },
                true,
            ),
            (
                ReadError::MalformedNumber {
                    text: "9q".into(),
                    span: span(9, 11),
                },
                true,
            ),
            (
                ReadError::IntOutOfRange {
                    text: "99999999999999999999".into(),
                    span: span(4, 24),
                },
                true,
            ),
            (
                ReadError::FloatOutOfRange {
                    text: "1e999".into(),
                    span: span(4, 9),
                },
                true,
            ),
            (
                ReadError::InvalidSymbol(SymbolError::InvalidSymbol {
                    text: "\u{1}x".into(),
                }),
                false,
            ),
            (
                ReadError::NestingDepthExceeded {
                    depth: 300,
                    limit: 256,
                },
                false,
            ),
            (
                ReadError::UnexpectedCharacter {
                    character: '{',
                    at: ByteOffset(5),
                },
                true,
            ),
            // The r151-b2 restructure's missing pair: the target
            // position and scope faces ride the token-span family
            // (`token_span` fabricates their primary spans) — the
            // twelve-variant walk is complete now.
            (
                ReadError::UnexpectedTargetToken {
                    text: "end of input".into(),
                    span: span(10, 10),
                },
                true,
            ),
            (
                ReadError::UnsupportedTargetForm {
                    form: "type declarations",
                    span: span(0, 6),
                },
                true,
            ),
        ];
        for (i, (err, positioned)) in cases.iter().enumerate() {
            let d = Diagnostic::from_read(err, file());
            assert_eq!(d.code, DiagnosticCode::Read, "case {i}");
            assert_eq!(d.severity, Severity::Error, "case {i}");
            assert_eq!(d.primary_span.is_some(), *positioned, "case {i}");
            assert!(!d.message.is_empty(), "case {i} message passthrough");
        }
    }

    #[test]
    fn expand_error_carries_its_span_and_file() {
        // §9.65 EXP-1: interned identity payload (the diagnostic
        // consumes only the span; the payload type co-varies with the
        // expander error family).
        let err = kerf_expander::ExpandError::UnboundIdentifier {
            name: Symbol::new("nope").expect("fixture symbol must be valid"),
            span: span(4, 8),
        };
        let d = Diagnostic::from_expand(&err);
        assert_eq!(d.code, DiagnosticCode::Expand);
        assert_eq!(d.primary_span, Some(span(4, 8)));
        assert_eq!(d.file, file());
    }

    #[test]
    fn compile_error_spanned_and_spanless_families() {
        let spanned = CompileError::StackUnderflow {
            pc: 3,
            span: span(1, 5),
        };
        let d = Diagnostic::from_compile(&spanned, FileId(0));
        assert_eq!(d.code, DiagnosticCode::Compile);
        assert_eq!(d.primary_span, Some(span(1, 5)));

        let spanless = CompileError::EmptyFuncTable;
        let d2 = Diagnostic::from_compile(&spanless, FileId(3));
        assert!(d2.primary_span.is_none());
        assert_eq!(
            d2.file,
            FileId(3),
            "spanless variants take the caller's file, not a fabricated id"
        );
        assert!(!d2.message.is_empty());
    }

    #[test]
    fn runtime_error_carries_its_span() {
        let err = RuntimeError::DivByZero { span: span(6, 10) };
        let d = Diagnostic::from_runtime(&err);
        assert_eq!(d.code, DiagnosticCode::Runtime);
        assert_eq!(d.primary_span, Some(span(6, 10)));
        assert_eq!(d.file, file());
    }

    #[test]
    fn driver_error_is_position_optional() {
        let d = Diagnostic::driver_error("no such file: `gone.krf`", FileId(0), None);
        assert_eq!(d.code, DiagnosticCode::Driver);
        assert_eq!(d.severity, Severity::Error);
        assert!(d.primary_span.is_none());
        assert_eq!(d.message, "no such file: `gone.krf`");
    }

    #[test]
    fn messages_pass_through_verbatim_r8_shapes() {
        // Stage messages are the stage error's Display output,
        // unchanged — the single-source dictionary (R8) means the
        // driver never rewrites them (the r151 single-skin retarget:
        // the retired S-expr face's verbatim arm left the tree; the
        // target-skin twin keeps the pass-through guard).
        let err = ReadError::UnclosedTargetDelim {
            opened_at: ByteOffset(7),
            opening: "{",
        };
        let d = Diagnostic::from_read(&err, file());
        assert_eq!(d.message, err.to_string());
        let rt = RuntimeError::DivByZero { span: span(0, 1) };
        let d2 = Diagnostic::from_runtime(&rt);
        assert_eq!(d2.message, rt.to_string());
    }

    #[test]
    fn target_context_maps_builtin_names_and_passes_engine_vocabulary() {
        // The five divergent context faces map through the skin
        // dictionary; engine-opcode vocabulary is face-neutral and
        // passes through verbatim (the opcode names are identical
        // on both faces by construction).
        assert_eq!(super::target_context("car operand"), "first operand");
        assert_eq!(super::target_context("cdr operand"), "rest operand");
        assert_eq!(
            super::target_context("write-line operand"),
            "write_line operand"
        );
        assert_eq!(super::target_context("`=` operand"), "`==` operand");
        assert_eq!(super::target_context("`<` operand"), "`<` operand");
        assert_eq!(super::target_context("not operand"), "not operand");
        assert_eq!(
            super::target_context("jump-if-false condition"),
            "jump-if-false condition"
        );
        assert_eq!(super::target_context("add operand"), "add operand");
        assert_eq!(super::target_context("call callee"), "call callee");
    }

    #[test]
    fn runtime_messages_render_target_spellings_on_the_target_face() {
        // Each symbol-bearing variant re-composes through the
        // single-sourced `*_text` helpers with skin-mapped names;
        // the canonical face renders verbatim (the mapping is a
        // pure presentation pass — the engine payloads stay
        // canonical for parity).
        let kebab = || Symbol::new("my-undef-fn").expect("the probe name interns");
        for (err, _canonical, target) in [
            (
                RuntimeError::UnboundGlobal {
                    name: kebab(),
                    span: span(0, 1),
                },
                "unbound global `my-undef-fn`",
                "unbound global `my_undef_fn`",
            ),
            (
                RuntimeError::UnhandledEffect {
                    effect: kebab(),
                    span: span(0, 1),
                },
                "unhandled effect `my-undef-fn`",
                "unhandled effect `my_undef_fn`",
            ),
            (
                RuntimeError::AssignToCaptured {
                    name: kebab(),
                    span: span(0, 1),
                },
                "cannot assign to captured variable `my-undef-fn` (captures are immutable in the current subset)",
                "cannot assign to captured variable `my_undef_fn` (captures are immutable in the current subset)",
            ),
            (
                RuntimeError::Eof { span: span(0, 1) },
                "read-line: end of input",
                "read_line: end of input",
            ),
        ] {
            assert_eq!(runtime_message_on_target(&err), target);
        }
    }

    #[test]
    fn target_face_runtime_diagnostics_are_skin_aware_end_to_end() {
        // The full pipeline on real .ktf sources: read → expand →
        // typecheck → compile → run, asserting the user-facing
        // message names what the target-skin user actually wrote.
        // The type-mismatch and arity probes route their operands
        // through HM-released dynamic parameters / checker-opaque
        // callee parameters (the Stage 1.1/1.8 wiring faces) so the
        // failure lands on the RUNTIME face under test — the static
        // checker catches the literal shapes first (E0002/E0009).
        // Each case round-trips the spelling through the real
        // target reader by construction: the source itself is
        // target syntax.
        use crate::pipeline::{Engine, run_source_with};
        use crate::session::Session;

        let cases: &[(&str, &str)] = &[
            (
                "fn f(x) { write_line(x) } define(r, f(42));",
                "type mismatch: write_line operand must be a string, got `int`",
            ),
            (
                "fn f(x) { first(x) } define(r, f(5));",
                "type mismatch: first operand must be a pair, got `int`",
            ),
            (
                "fn apply2(g) { g(1, 2) } define(r, apply2(first));",
                "arity mismatch: `first` expects `1` argument, got `2`",
            ),
            (
                "fn f(x) { (1 == x) } define(r, f(\"x\"));",
                "type mismatch: `==` operand must be a number of the same kind, got `string`",
            ),
            ("define(r, read_line());", "read_line: end of input"),
        ];
        for (src, expected) in cases {
            let mut session = Session::new();
            let err = run_source_with(&mut session, "probe.ktf", src, Engine::Vm, &[])
                .expect_err("every probe fails at run time");
            assert_eq!(err[0].message, *expected, "source: {src}");
        }
        // The face-neutral families render identically (no name
        // payloads to map).
        let mut session = Session::new();
        let err = run_source_with(
            &mut session,
            "probe.ktf",
            "define(r, (1 / 0));",
            Engine::Vm,
            &[],
        )
        .expect_err("division by zero fails at run time");
        assert_eq!(err[0].message, "division by zero");
    }

    #[test]
    fn stage_messages_render_target_spellings_on_the_target_face() {
        // r109 F2 — the compile-time twin of the runtime face: each
        // identifier-bearing stage error re-spells its subject
        // through the skin dictionary. The r151 single-skin retarget:
        // the target rendering is the only rendering (the canonical-
        // verbatim arm left with the S-expression reader) — every
        // stage message names the target spelling of what the
        // target-skin user actually wrote.
        use kerf_span::Symbol;

        let kebab = || Symbol::new("my-undef-fn").expect("probe name interns");
        let expand = kerf_expander::ExpandError::UnboundIdentifier {
            name: kebab(),
            span: span(0, 1),
        };
        assert_eq!(
            Diagnostic::from_expand(&expand).message,
            "unbound identifier `my_undef_fn`: not in any lexical scope and not a Stage 0 global"
        );

        // The typecheck face: the subject rides the diagnostic.
        let td = kerf_typecheck::TypeDiagnostic::with_subjects(
            kerf_typecheck::TypeCode::UnboundVariable,
            kerf_typecheck::Severity::Error,
            span(0, 1),
            "unbound variable `my-undef-fn`".to_string(),
            vec![kebab()],
        );
        assert_eq!(
            Diagnostic::from_typecheck(&td).message,
            "unbound variable `my_undef_fn`"
        );

        // The subject set is exact-token: a subject whose target
        // spelling equals its canonical spelling (no separators, no
        // table entry) leaves the message untouched.
        let plain = kerf_typecheck::TypeDiagnostic::with_subjects(
            kerf_typecheck::TypeCode::UnboundVariable,
            kerf_typecheck::Severity::Error,
            span(0, 1),
            "unbound variable `x`".to_string(),
            vec![Symbol::new("x").expect("probe")],
        );
        assert_eq!(
            Diagnostic::from_typecheck(&plain).message,
            "unbound variable `x`"
        );

        // The compiler face: AssignToCaptured carries the subject.
        let ce = CompileError::AssignToCaptured {
            name: kebab(),
            span: span(0, 1),
        };
        assert_eq!(
            Diagnostic::from_compile(&ce, FileId(0)).message,
            "cannot assign to captured variable `my_undef_fn` (captures are immutable in the current subset)"
        );
    }

    #[test]
    fn target_face_compile_time_diagnostics_are_skin_aware_end_to_end() {
        // The full static pipeline on real .ktf sources: read →
        // expand → (typecheck →) compile, asserting the user-facing
        // message names what the target-skin user actually wrote
        // (r109 F2 — the compile-time twin of the r108 runtime e2e).
        use crate::pipeline::check_source_with;
        use crate::session::Session;

        let cases: &[(&str, &str)] = &[
            (
                "fn dup(x_y, x_y) { x_y }\nfn main() { dup(1); }",
                "core construction failed: duplicate parameter `x_y` in fn form",
            ),
            (
                "fn my_fn(x) { x }\nfn main() { my_fn(1, 2); }",
                "arity mismatch: `my_fn` expects `1` argument, got `2`",
            ),
            (
                "fn main() { my_undef(); }",
                "unbound identifier `my_undef`: not in any lexical scope and not a Stage 0 global",
            ),
            (
                "use \"nope_mod\";\nfn main() { 1 }",
                "required module `nope_mod` is not declared",
            ),
            (
                "module my_a { use my_b; define(x, 1); }\nmodule my_b { use my_a; define(y, 2); }\nfn main() { 1 }",
                "module cycle detected: `my_a` -> `my_b` -> `my_a`",
            ),
        ];
        for (src, expected) in cases {
            let mut session = Session::new();
            let err = check_source_with(&mut session, "probe.ktf", src)
                .expect_err("every probe fails at a compile-time stage");
            assert!(
                err.iter().any(|d| d.message == *expected),
                "source: {src}\nexpected: {expected}\ngot: {:?}",
                err.iter().map(|d| d.message.clone()).collect::<Vec<_>>()
            );
        }

        // The assign-captured face (E0012) through a real closure.
        let mut session = Session::new();
        let err = check_source_with(
            &mut session,
            "probe.ktf",
            "fn main() { let cap_v = 1; let f = move || { set(cap_v, 2); }; f(); }",
        )
        .expect_err("the captured assign rejects");
        assert!(
            err.iter()
                .any(|d| d.message == "cannot assign to captured variable `cap_v`")
        );
    }

    #[test]
    fn read_error_span_respects_file_argument() {
        // The span is built on the *driver's* file id (the reader
        // error payload is offset-only; file identity comes from
        // which file was being read).
        let err = ReadError::UnclosedTargetDelim {
            opened_at: ByteOffset(2),
            opening: "(",
        };
        let d = Diagnostic::from_read(&err, FileId(5));
        assert_eq!(d.file, FileId(5));
        assert_eq!(
            d.primary_span.map(|s| s.file_id),
            Some(FileId(5)),
            "the fabricated span must live in the file being read"
        );
    }
}

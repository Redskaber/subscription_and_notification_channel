//! The W-TGT-READ-TWIN blade-3 steady-state TARGET read chain
//! (bootstrap-completion-plan §4.2 blade 3 — the G1 closure's chain
//! form): the TARGET read twins — `target-lexer.ktf` AND
//! `target-parser.ktf` — each compiled ONCE, fed per source through
//! the injection channel, the LEXER twin's own token records bridged
//! into the PARSER twin's input slot by the host (the K20 permanent
//! host layer — the same single-source derivations the blade-1/2
//! parity harnesses ride).
//!
//! The delta against the per-source route (the blade-1/2 parity
//! harnesses): there every case re-parses, re-checks and re-compiles
//! the whole assembled twin program (the token table, the nesting
//! limit and the form table ride the program TEXT as quoted defines).
//! Here each twin program is FIXED — the form table and the limit
//! are constants of the parser program's own text, compiled once —
//! and each read binds only the per-source payload:
//!
//! * the LEXER run binds `source-bytes` (the RS-1 encoding, the same
//!   contract name the S-expr `SteadyReaderChain` rides — one
//!   channel, per-blade payload);
//! * the PARSER run binds `tp-tokens` (the bridged token records —
//!   the value face of the per-source route's `tp_token_prefix`
//!   grammar, record for record, field for field).
//!
//! The bridge (the K20 permanent host layer, instantiated on the
//! chain's junction): the lexer twin's records carry SPANS (its
//! ident records carry no payload, its float records no value, its
//! str records no decoded text — the twins made the GRAMMAR
//! decisions); the host derives the parser twin's input payloads
//! from the source slices — `skin_symbol` for the ident canonical
//! text (the oracle's own mapping), the `_`-stripped f64 parse plus
//! Debug formatting for the float value, `decode_target_string` for
//! the str body. A bridge derivation that rejects (a non-finite
//! float lexeme) renders through the ORACLE's own `FloatOutOfRange`
//! — the same key the oracle lexer produced, so the layer split
//! holds on both routes by construction.
//!
//! Cross-route equivalence (the steady chain's machine check, the
//! `steady_expander_chain` lineage): the steady route and the
//! per-source route decode through the SAME decoder closures
//! (`decode_twin_verdict`, `decode_tp_verdict`) — the delivery face
//! is the only delta, so a clobber or a bridge drift collapses the
//! sweep loudly.
//!
//! The tree rebuild face (`rebuild_tp_forms`) carries the read
//! forward: the composition chain's junction feed and the fixpoint
//! purity leg's read — the cross-stage consumers, never part of the
//! comparison itself.

use kerf_compiler::{Bytecode, compile_program};
use kerf_core::LiteralValue;
use kerf_reader::{ReadError, skin_symbol};
use kerf_runtime::Evaluator;
use kerf_syntax::SyntaxObject;
use kerf_vm::{BufferIo, Vm};

use crate::bootstrap::target_corpus::{
    TARGET_LEXER_TARGET_SOURCE, TARGET_PARSER_TARGET_SOURCE, transcode_quoted_define,
};
use crate::bootstrap::target_lexer_parity::{
    decode_target_string, decode_twin_verdict, rebuild_target_error, slice_src, strip_us,
};
use crate::bootstrap::target_parser_parity::{
    decode_tp_verdict, rebuild_tp_forms, tp_forms_prefix, tp_limit_prefix, tp_verdict_read_error,
};
use crate::bootstrap::vm_harness::{as_i64, as_str, error_parity_key, value_elems};
use crate::bootstrap::vm_harness::{byte_table_literal, classify_engine_failure};
use crate::session::Session;

/// The lexer twin's injected slot — the RS-1 contract name (the same
/// identity the S-expr `SteadyReaderChain` rides; the twins spell it
/// `source_bytes` on the target skin, the E5 skin map canonicalizes
/// the token to this one identity).
pub const STEADY_TARGET_SOURCE_NAME: &str = "source-bytes";

/// The parser twin's injected slot — the TP-1 token-record contract
/// name (the twins spell it `tp_tokens`; the skin map canonicalizes
/// to `tp-tokens`).
pub const STEADY_TP_TOKENS_NAME: &str = "tp-tokens";

/// The host names the fixed twin programs parse under (diagnostics
/// attribution only — the twins verify clean, so they never surface).
const STEADY_TARGET_LEXER_HOST: &str = "steady-target-lexer.ktf";
const STEADY_TARGET_PARSER_HOST: &str = "steady-target-parser.ktf";

/// One steady read's outcome: the two axes' dumps (the per-source
/// route's grammar — byte-comparable across routes) plus the
/// rebuilt forms (the cross-stage feed, present only on a full ok).
#[derive(Debug, Clone)]
pub struct SteadyTargetRead {
    /// The token-axis dump (`ERR {key}` on a lexer-layer rejection).
    pub token_dump: String,
    /// The tree-axis dump (`ERR {key}` on either layer's rejection —
    /// a lexer-layer rejection never reaches the parser, and the
    /// oracle's own read rejects with the same key).
    pub tree_dump: String,
    /// The rebuilt forms — `Some` only when both layers accepted.
    pub forms: Option<Vec<SyntaxObject>>,
}

/// The steady-state TARGET read chain: the two compiled fixed
/// programs plus the parsed items (the evaluator arm's input — the
/// dual-engine discipline consumes the same programs through both
/// engines).
pub struct SteadyTargetReaderChain {
    lexer_bc: Bytecode,
    lexer_items: Vec<kerf_core::ModuleItem>,
    parser_bc: Bytecode,
    parser_items: Vec<kerf_core::ModuleItem>,
}

/// The lexer layer's per-engine outcome: the token-axis dump plus
/// the bridged token table (the same rejection key on both faces —
/// the table carries `Err(key)` exactly when the dump does).
struct LexerOutcome {
    dump: Result<String, String>,
    table: Result<LiteralValue, String>,
}

impl SteadyTargetReaderChain {
    /// Compile the two fixed twin programs ONCE at the conservative
    /// default nesting cap ([`kerf_reader::NESTING_LIMIT`] — the
    /// verification harnesses' face).
    pub fn new() -> Result<Self, String> {
        Self::new_with_limit(kerf_reader::NESTING_LIMIT)
    }

    /// Compile the two fixed twin programs ONCE under an explicit
    /// reader nesting cap (the step-④ production face: the twin
    /// parser's `tp_limit` constant must mirror the process's
    /// `KERF_READER_NESTING_LIMIT` override, so an over-limit source
    /// rejects with the SAME key on both positions — the rollback
    /// band's parity obligation).
    ///
    /// The lexer program is `target-lexer.ktf` verbatim — its
    /// `source_bytes` reference is the injected slot. The parser
    /// program embeds the FIXED constants ahead of the twin source:
    /// the form table (the `tp_forms` define — the same single
    /// source the per-source route assembles) and the nesting limit
    /// (the `tp_limit` define) — so only the token table ever
    /// arrives per read. Zero new primitives, zero new builtins,
    /// zero frozen-surface change.
    pub fn new_with_limit(nesting: usize) -> Result<Self, String> {
        // ---- the lexer program ----
        let lexer_injected = [kerf_span::Symbol::new(STEADY_TARGET_SOURCE_NAME)
            .expect("the injected name is a valid identifier")];
        let mut session = Session::new();
        let lexer_program = crate::pipeline::parse_target_with_injected(
            &mut session,
            STEADY_TARGET_LEXER_HOST,
            TARGET_LEXER_TARGET_SOURCE,
            &lexer_injected,
        )
        .map_err(|diags| {
            format!("harness defect: the fixed target-lexer program failed to parse: {diags:?}")
        })?;
        if lexer_program
            .typecheck()
            .iter()
            .any(|d| d.severity == crate::diagnostic::Severity::Error)
        {
            return Err(
                "harness defect: the fixed target-lexer program failed the checker".to_string(),
            );
        }
        let lexer_bc = compile_program(&lexer_program.items).map_err(|err| {
            format!("harness defect: the fixed target-lexer program failed to compile: {err}")
        })?;
        if !lexer_bc
            .globals
            .iter()
            .any(|g| g.as_str() == STEADY_TARGET_SOURCE_NAME)
        {
            return Err(format!(
                "harness defect: the target-lexer twin does not reference `{STEADY_TARGET_SOURCE_NAME}` — the injection channel has no slot"
            ));
        }
        // ---- the parser program ----
        // The form table rides as a quoted define TRANSCODED to the
        // target skin (the per-source route's own assembly — the
        // same single source, never a re-typed copy); the limit is
        // already target-skin text.
        let parser_assembled = format!(
            "{}{}{}",
            transcode_quoted_define(&tp_forms_prefix()),
            tp_limit_prefix(nesting),
            TARGET_PARSER_TARGET_SOURCE
        );
        let parser_injected = [kerf_span::Symbol::new(STEADY_TP_TOKENS_NAME)
            .expect("the injected name is a valid identifier")];
        let mut session = Session::new();
        let parser_program = crate::pipeline::parse_target_with_injected(
            &mut session,
            STEADY_TARGET_PARSER_HOST,
            &parser_assembled,
            &parser_injected,
        )
        .map_err(|diags| {
            format!("harness defect: the fixed target-parser program failed to parse: {diags:?}")
        })?;
        if parser_program
            .typecheck()
            .iter()
            .any(|d| d.severity == crate::diagnostic::Severity::Error)
        {
            return Err(
                "harness defect: the fixed target-parser program failed the checker".to_string(),
            );
        }
        let parser_bc = compile_program(&parser_program.items).map_err(|err| {
            format!("harness defect: the fixed target-parser program failed to compile: {err}")
        })?;
        if !parser_bc
            .globals
            .iter()
            .any(|g| g.as_str() == STEADY_TP_TOKENS_NAME)
        {
            return Err(format!(
                "harness defect: the target-parser twin does not reference `{STEADY_TP_TOKENS_NAME}` — the injection channel has no slot"
            ));
        }
        Ok(Self {
            lexer_bc,
            lexer_items: lexer_program.items,
            parser_bc,
            parser_items: parser_program.items,
        })
    }

    /// The compiled fixed products (the once-compiled bytecodes —
    /// the observation face; the per-read cost is the injection +
    /// run, never a recompile).
    pub fn bytecodes(&self) -> (&Bytecode, &Bytecode) {
        (&self.lexer_bc, &self.parser_bc)
    }

    /// One read through the chain on the PRODUCTION engine alone
    /// (the step-④ read segment's production position; the
    /// dual-engine agreement of [`Self::read_dual`] is the
    /// verification face and stays there — production never pays
    /// for a second opinion).
    ///
    /// The outcome splits the two failure families the production
    /// position must never confuse:
    ///
    /// * outer `Err` — a harness defect (the chain or a decode
    ///   broke; a compiler defect, rendered loudly — never a silent
    ///   Rust fallback, §2.3-4);
    /// * inner `Err` — the program's own rejection, as the rebuilt
    ///   [`ReadError`] (the same error the oracle read produces, so
    ///   the diagnostics render identically on both positions).
    pub fn read_production(
        &self,
        source: &str,
    ) -> Result<Result<Vec<SyntaxObject>, ReadError>, String> {
        // ---- stage 1+2: the lexer twin on the VM, bridged ----
        let table = {
            let mut vm = Vm::with_io(self.lexer_bc.clone(), Box::new(BufferIo::default()))
                .map_err(|err| {
                    format!("harness defect: the vm rejected the target-lexer program: {err}")
                })?;
            // The byte table is owned here and disposed iteratively
            // (a long chain's default Box-drop glue is one stack
            // frame per cell — the same linear-depth family as
            // `pair_cells`/`from_literal`, §20).
            let source_table = byte_table_literal(source);
            let injected = vm
                .inject_global(STEADY_TARGET_SOURCE_NAME, &source_table)
                .map_err(|err| format!("harness defect: the source-bytes channel: {err}"));
            dispose_literal_iteratively(source_table);
            injected?;
            vm.run().map_err(|err| {
                classify_engine_failure("vm", "production target lexer chain", &err)
            })?;
            let value = vm
                .global("result")
                .ok_or_else(|| "harness defect: no `result` global on the vm engine".to_string())?;
            bridge_token_table_production(source, value, vm.heap())
        };
        let table = match table {
            // A harness defect (outer family) — a compiler defect.
            Err(defect) => return Err(defect),
            Ok(Ok(table)) => table,
            // The lexer layer's own rejection (or a bridge
            // derivation rejection) — the program's error, never
            // the parser layer's business (the layer split).
            Ok(Err(err)) => return Ok(Err(err)),
        };
        // ---- stage 3: the parser twin on the VM ----
        let mut vm =
            Vm::with_io(self.parser_bc.clone(), Box::new(BufferIo::default())).map_err(|err| {
                format!("harness defect: the vm rejected the target-parser program: {err}")
            })?;
        let injected = vm
            .inject_global(STEADY_TP_TOKENS_NAME, &table)
            .map_err(|err| format!("harness defect: the tp-tokens channel: {err}"));
        dispose_literal_iteratively(table);
        injected?;
        vm.run()
            .map_err(|err| classify_engine_failure("vm", "production target parser chain", &err))?;
        let value = vm
            .global("result")
            .ok_or_else(|| "harness defect: no `result` global on the vm engine".to_string())?;
        if let Some(err) = tp_verdict_read_error(value, vm.heap(), source)? {
            return Ok(Err(err));
        }
        let forms = rebuild_tp_forms(value, vm.heap(), source)?
            .ok_or_else(|| "harness defect: a tree-ok verdict rebuilt to no forms".to_string())?;
        Ok(Ok(forms))
    }

    /// One read through the steady chain on BOTH engines (the
    /// dual-engine discipline: the same programs, the same
    /// injections, both engines' outcomes decoded and bridged
    /// independently — a bridge bug that favored one engine's
    /// output would have to drift against the other's identically
    /// to survive the sweep). The two outcomes return for the
    /// caller's agreement assertion (the cross-route equivalence
    /// face asserts them equal).
    ///
    /// Rejections render ON the outcome (`ERR {key}` on the axes,
    /// `forms: None`) — the layer split face; `Err` carries only
    /// harness defects and engine disagreements.
    pub fn read_dual(&self, source: &str) -> Result<(SteadyTargetRead, SteadyTargetRead), String> {
        // ---- stage 1+2: the lexer twin, both engines, bridged ----
        let vm_outcome = {
            let mut vm = Vm::with_io(self.lexer_bc.clone(), Box::new(BufferIo::default()))
                .map_err(|err| {
                    format!("harness defect: the vm rejected the target-lexer program: {err}")
                })?;
            vm.inject_global(STEADY_TARGET_SOURCE_NAME, &byte_table_literal(source))
                .map_err(|err| format!("harness defect: the source-bytes channel: {err}"))?;
            vm.run()
                .map_err(|err| classify_engine_failure("vm", "steady target lexer chain", &err))?;
            let value = vm
                .global("result")
                .ok_or_else(|| "harness defect: no `result` global on the vm engine".to_string())?;
            let dump = decode_twin_verdict(value, vm.heap(), source)?;
            let table = bridge_token_table(source, value, vm.heap());
            LexerOutcome { dump, table }
        };
        let eval_outcome = {
            let mut evaluator = Evaluator::with_io(Box::new(BufferIo::default()));
            evaluator
                .inject_global(STEADY_TARGET_SOURCE_NAME, &byte_table_literal(source))
                .map_err(|err| format!("harness defect: the source-bytes channel: {err}"))?;
            evaluator.eval_program(&self.lexer_items).map_err(|err| {
                classify_engine_failure("eval", "steady target lexer chain", &err)
            })?;
            let value = evaluator.global("result").ok_or_else(|| {
                "harness defect: no `result` global on the eval engine".to_string()
            })?;
            let dump = decode_twin_verdict(value, evaluator.heap(), source)?;
            let table = bridge_token_table(source, value, evaluator.heap());
            LexerOutcome { dump, table }
        };
        // The engines' agreement at the lexer layer — the dumps are
        // the byte-comparable face; the bridged tables agree with
        // their own dumps by construction (the same verdict value).
        if vm_outcome.dump != eval_outcome.dump {
            return Err(format!(
                "steady target read: engines disagree at the lexer layer: vm `{:?}` vs eval `{:?}`",
                vm_outcome.dump, eval_outcome.dump
            ));
        }
        // The layer split — the lexer's own rejection (the twin's
        // grammar face or a bridge derivation, both engines' rejection
        // with the same key by construction): both axes render the
        // key, the parser layer never runs, and the oracle's own read
        // rejects the same way (the parity face asserts it).
        if let Err(key) = &vm_outcome.dump {
            return match &vm_outcome.table {
                Err(table_key) if table_key == key => {
                    let rejection = format!("ERR {key}");
                    Ok((
                        SteadyTargetRead {
                            token_dump: rejection.clone(),
                            tree_dump: rejection.clone(),
                            forms: None,
                        },
                        SteadyTargetRead {
                            token_dump: rejection.clone(),
                            tree_dump: rejection,
                            forms: None,
                        },
                    ))
                }
                Err(defect) => Err(format!(
                    "harness defect: the bridge diverged from the lexer verdict: `{defect}` vs `{key}`"
                )),
                Ok(_) => Err("harness defect: the bridge accepted a rejected verdict".to_string()),
            };
        }
        // ---- stage 3: the parser twin, both engines, per bridged
        // table (the tables agree with their dumps — the vm and eval
        // tables are the same records by the agreement above) ----
        let vm_table = vm_outcome
            .table
            .clone()
            .map_err(|defect| format!("harness defect: the bridge: {defect}"))?;
        let vm_read = self.run_parser_once(&vm_table, "vm", source)?;
        let eval_table = eval_outcome
            .table
            .map_err(|defect| format!("harness defect: the bridge: {defect}"))?;
        let eval_read = self.run_parser_once(&eval_table, "eval", source)?;
        if vm_read.0 != eval_read.0 {
            return Err(format!(
                "steady target read: engines disagree at the parser layer: vm `{:?}` vs eval `{:?}`",
                vm_read.0, eval_read.0
            ));
        }
        // ---- the outcomes ----
        let axis = |dump: &Result<String, String>| match dump {
            Ok(text) => text.clone(),
            Err(key) => format!("ERR {key}"),
        };
        let token_axis = axis(&vm_outcome.dump);
        let tree_axis = axis(&vm_read.0);
        // The forms rebuild rides the VM axis's tree verdict (the
        // cross-stage feed; the eval axis's agreement is asserted
        // above through the dumps).
        let forms = match &vm_read.0 {
            Ok(_) => {
                let rebuilt = rebuild_tp_forms(&vm_read.1, &vm_read.2, source)?;
                Some(rebuilt.ok_or_else(|| {
                    // A tree-ok verdict cannot rebuild to None — the
                    // rebuild walks the same records the dump decoded.
                    "harness defect: a tree-ok verdict rebuilt to no forms".to_string()
                })?)
            }
            Err(_) => None,
        };
        Ok((
            SteadyTargetRead {
                token_dump: token_axis,
                tree_dump: tree_axis,
                forms,
            },
            SteadyTargetRead {
                token_dump: axis(&eval_outcome.dump),
                tree_dump: axis(&eval_read.0),
                forms: None,
            },
        ))
    }

    /// The parser twin's single-engine run on one bridged table:
    /// `Ok((tree dump, verdict value, heap snapshot))` — the value
    /// and a heap clone ride back for the forms rebuild (the VM
    /// engine's heap is alive only inside; the clone carries the
    /// verdict's records forward — the value face is
    /// `kerf_vm::Value`, whose Pair chains live in the heap).
    fn run_parser_once(
        &self,
        table: &LiteralValue,
        engine: &str,
        source: &str,
    ) -> Result<(Result<String, String>, kerf_vm::Value, kerf_vm::Heap), String> {
        let run = |bc: &Bytecode, items: &[kerf_core::ModuleItem]| -> Result<(Result<String, String>, kerf_vm::Value, kerf_vm::Heap), String> {
            let mut vm = Vm::with_io(bc.clone(), Box::new(BufferIo::default()))
                .map_err(|err| format!("harness defect: the vm rejected the target-parser program: {err}"))?;
            vm.inject_global(STEADY_TP_TOKENS_NAME, table)
                .map_err(|err| format!("harness defect: the tp-tokens channel: {err}"))?;
            vm.run().map_err(|err| {
                classify_engine_failure("vm", "steady target parser chain", &err)
            })?;
            let value = vm
                .global("result")
                .cloned()
                .ok_or_else(|| "harness defect: no `result` global on the vm engine".to_string())?;
            let heap = vm.heap().clone();
            let dump = decode_tp_verdict(&value, &heap, source)?;
            let _ = items; // the parser program's items ride the eval arm; the vm arm consumes the bytecode
            Ok((dump, value, heap))
        };
        match engine {
            "vm" => run(&self.parser_bc, &[]),
            "eval" => {
                let mut evaluator = Evaluator::with_io(Box::new(BufferIo::default()));
                evaluator
                    .inject_global(STEADY_TP_TOKENS_NAME, table)
                    .map_err(|err| format!("harness defect: the tp-tokens channel: {err}"))?;
                evaluator.eval_program(&self.parser_items).map_err(|err| {
                    classify_engine_failure("eval", "steady target parser chain", &err)
                })?;
                let value = evaluator.global("result").cloned().ok_or_else(|| {
                    "harness defect: no `result` global on the eval engine".to_string()
                })?;
                let heap = evaluator.heap().clone();
                let dump = decode_tp_verdict(&value, &heap, source)?;
                Ok((dump, value, heap))
            }
            other => Err(format!(
                "harness defect: unknown engine `{other}` (the dual-engine discipline is vm+eval)"
            )),
        }
    }
}

// ---------------------------------------------------------------------------
// The bridge — the K20 permanent host layer on the chain's junction.
// The lexer twin's token records (spans; the grammar decisions are
// the twin's) become the parser twin's input records (payloads; the
// host derivations are the oracle's own single sources).
// ---------------------------------------------------------------------------

/// Build one proper-list record value `(tag s e payload...)` from
/// the field slice (the value face of the per-source route's text
/// grammar — field for field).
fn record(kind: &str, fields: &[LiteralValue]) -> LiteralValue {
    let mut list = LiteralValue::Nil;
    for f in fields.iter().rev() {
        list = LiteralValue::Pair(Box::new(f.clone()), Box::new(list));
    }
    LiteralValue::Pair(Box::new(LiteralValue::String(kind.into())), Box::new(list))
}

/// The bytes of a text as a proper list of ints (the ident record's
/// payload face).
fn bytes_list(text: &str) -> LiteralValue {
    let mut list = LiteralValue::Nil;
    for b in text.as_bytes().iter().rev() {
        list = LiteralValue::Pair(Box::new(LiteralValue::Int(i64::from(*b))), Box::new(list));
    }
    list
}

/// Rebuild a span for a bridge rejection (the FloatOutOfRange face).
fn span_of(s: i64, e: i64) -> Result<kerf_span::Span, String> {
    kerf_span::Span::new(
        kerf_span::FileId(0),
        kerf_span::ByteOffset(s as u32),
        kerf_span::ByteOffset(e as u32),
        kerf_span::ExpansionId::ROOT,
    )
    .map_err(|err| format!("harness defect: bridged span rejected: {err}"))
}

/// One lexer twin token record → one parser twin input record (the
/// K20 host derivations per kind), with the rejection split the
/// production face needs: `Ok(Ok(record))` accepts, `Ok(Err(err))`
/// is a PROGRAM rejection (the oracle's own `ReadError` — a
/// non-finite float lexeme; the diagnostics render identically on
/// both positions), `Err` is a harness defect.
fn bridge_token_for(
    source: &str,
    rec: &[&kerf_vm::Value],
) -> Result<Result<LiteralValue, ReadError>, String> {
    let kind = as_str(rec[0]).map_err(|e| format!("bridge token kind: {e}"))?;
    // The eof record is TWO-field — ("eof" end) — every other record
    // is (tag s e ...): span extraction comes after the eof split.
    if kind == "eof" {
        let e = as_i64(rec[1]).map_err(|e| format!("bridge eof span end: {e}"))?;
        return Ok(Ok(record("eof", &[LiteralValue::Int(e)])));
    }
    let s = as_i64(rec[1]).map_err(|e| format!("bridge token span start: {e}"))?;
    let e = as_i64(rec[2]).map_err(|e| format!("bridge token span end: {e}"))?;
    match kind {
        "ident" => {
            // The K20 ident face: the oracle's own skin mapping —
            // the canonical text bytes are the parser twin's payload.
            let raw = slice_src(source, s, e, "bridge ident")?;
            let sym = skin_symbol(raw).map_err(|err| {
                format!("harness defect: the bridged ident is unmappable ({err:?})")
            })?;
            Ok(Ok(record(
                "ident",
                &[
                    LiteralValue::Int(s),
                    LiteralValue::Int(e),
                    bytes_list(sym.as_str()),
                ],
            )))
        }
        "float" => {
            // The K20 float face: the `_`-stripped lexeme parse plus
            // Debug formatting — the oracle's own value and text.
            let raw = slice_src(source, s, e, "bridge float")?;
            match strip_us(raw).parse::<f64>() {
                Ok(v) if v.is_infinite() => {
                    let text = raw.to_owned();
                    let span = span_of(s, e)?;
                    Ok(Err(ReadError::FloatOutOfRange { text, span }))
                }
                Ok(v) => Ok(Ok(record(
                    "float",
                    &[
                        LiteralValue::Int(s),
                        LiteralValue::Int(e),
                        LiteralValue::String(format!("{v:?}").into()),
                    ],
                ))),
                Err(_) => Err(format!(
                    "harness defect: the twin float grammar accepted an unparseable lexeme `{raw}`"
                )),
            }
        }
        "str" => {
            // The K20 string face: the escape decode of the body —
            // the oracle's own decoded value.
            let raw = slice_src(source, s + 1, e - 1, "bridge str")?;
            let decoded = decode_target_string(raw);
            Ok(Ok(record(
                "str",
                &[
                    LiteralValue::Int(s),
                    LiteralValue::Int(e),
                    LiteralValue::String(decoded.into()),
                ],
            )))
        }
        "int" => {
            let v = as_i64(rec.get(3).ok_or("bridge int record lacks its value")?)
                .map_err(|e| format!("bridge int payload: {e}"))?;
            Ok(Ok(record(
                "int",
                &[
                    LiteralValue::Int(s),
                    LiteralValue::Int(e),
                    LiteralValue::Int(v),
                ],
            )))
        }
        "bool" => match rec.get(3) {
            Some(kerf_vm::Value::Bool(b)) => Ok(Ok(record(
                "bool",
                &[
                    LiteralValue::Int(s),
                    LiteralValue::Int(e),
                    LiteralValue::Bool(*b),
                ],
            ))),
            Some(other) => Err(format!("harness defect: bridge bool payload is {other:?}")),
            None => Err("harness defect: bridge bool record lacks its payload".to_string()),
        },
        "eof" => unreachable!("the eof record is handled ahead of the span extraction"),
        // The 24 word faces and every operator tag: span-only — the
        // parser twin's input grammar is the per-source route's own.
        "kw-fn" | "kw-let" | "kw-mut" | "kw-if" | "kw-else" | "kw-match" | "kw-perform"
        | "kw-handle" | "kw-module" | "kw-use" | "kw-extern" | "kw-macro" | "kw-pub"
        | "kw-struct" | "kw-enum" | "kw-type" | "kw-effect" | "kw-capability" | "kw-move"
        | "kw-as" | "kw-impl" | "kw-resume" | "kw-halt" | "kw-pass" | "ellipsis" | "arrow"
        | "fat-arrow" | "colon-colon" | "dot-dot" | "eq-eq" | "not-eq" | "and-and" | "or-or"
        | "le" | "ge" | "shl" | "shr" | "open-brace" | "close-brace" | "open-paren"
        | "close-paren" | "open-bracket" | "close-bracket" | "semi" | "comma" | "colon" | "dot"
        | "bang" | "assign" | "plus" | "minus" | "star" | "slash" | "percent" | "lt" | "gt"
        | "amp" | "pipe" | "caret" => Ok(Ok(record(
            kind,
            &[LiteralValue::Int(s), LiteralValue::Int(e)],
        ))),
        other => Err(format!(
            "harness defect: unknown bridge token kind `{other}`"
        )),
    }
}

/// Dispose a host-side literal table without the recursive Box-drop
/// glue: a long pair chain's default drop is one stack frame per
/// cell — the same linear-depth family as `pair_cells`/
/// `from_literal` (§20's same-path sweep, the r145
/// production-position exposure) — so the production read walks it
/// explicitly and lets each leaf drop inline.
///
/// Shared across the injection family (the r146 same-path sweep:
/// every host-side literal handed to `inject_global` — the read
/// segment's tables AND the expand segment's forms streams —
/// disposes through this one walker).
pub(crate) fn dispose_literal_iteratively(mut lit: LiteralValue) {
    let mut pending: Vec<LiteralValue> = Vec::new();
    loop {
        match lit {
            LiteralValue::Pair(car, cdr) => {
                pending.push(*car);
                lit = *cdr;
            }
            leaf => {
                drop(leaf);
                match pending.pop() {
                    Some(next) => lit = next,
                    None => return,
                }
            }
        }
    }
}

/// The whole-record walk: the lexer twin's ok verdict → the parser
/// twin's token table (the value face of `tp_token_prefix`'s
/// grammar). On the twin's own rejection — or a bridge derivation
/// rejection — the outcome is the rebuilt `ReadError` (the same
/// error the oracle read produces); harness defects stay on the
/// outer `Err`. This is the PRODUCTION core (the step-④ read
/// position's bridge); the verification face below key-ifies it.
pub(crate) fn bridge_token_table_production(
    source: &str,
    verdict: &kerf_vm::Value,
    heap: &kerf_vm::Heap,
) -> Result<Result<LiteralValue, ReadError>, String> {
    let elems = value_elems(verdict, heap).map_err(|e| format!("bridge verdict chain: {e}"))?;
    let tag = as_str(elems.first().ok_or("bridge verdict is empty")?)
        .map_err(|e| format!("bridge verdict tag: {e}"))?;
    match tag {
        "ok" => {
            let mut bridged: Vec<LiteralValue> = Vec::with_capacity(elems.len() - 1);
            for rec in &elems[1..] {
                let fields = value_elems(rec, heap).map_err(|e| format!("bridge record: {e}"))?;
                match bridge_token_for(source, &fields)? {
                    Ok(record) => bridged.push(record),
                    Err(err) => return Ok(Err(err)),
                }
            }
            let mut table = LiteralValue::Nil;
            for b in bridged.iter().rev() {
                table = LiteralValue::Pair(Box::new(b.clone()), Box::new(table));
            }
            Ok(Ok(table))
        }
        "err" => {
            // The twin's own rejection — the rebuilt ReadError (the
            // same single source the per-source route rides).
            let kind = as_str(elems.get(1).ok_or("bridge err lacks its kind")?)
                .map_err(|e| format!("bridge error kind: {e}"))?;
            let payload: Vec<&kerf_vm::Value> = elems[2..].to_vec();
            Ok(Err(rebuild_target_error(kind, &payload, source)?))
        }
        other => Err(format!(
            "harness defect: unknown bridge verdict tag `{other}`"
        )),
    }
}

/// The verification face of the production bridge (the parity
/// harnesses' contract preserved bit-for-bit): the program rejection
/// renders as the rebuilt ReadError's KEY — the layer split (the
/// lexer IS the single source shared by the oracle and the twin's
/// injection).
pub(crate) fn bridge_token_table(
    source: &str,
    verdict: &kerf_vm::Value,
    heap: &kerf_vm::Heap,
) -> Result<LiteralValue, String> {
    match bridge_token_table_production(source, verdict, heap)? {
        Ok(table) => Ok(table),
        Err(err) => Err(error_parity_key(&err)),
    }
}

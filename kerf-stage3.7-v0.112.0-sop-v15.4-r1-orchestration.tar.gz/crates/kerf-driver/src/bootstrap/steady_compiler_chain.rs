//! The step-④ compile-segment steady-state chain (w-t-a-switch-window
//! §2 TA-4 — the r144 steady form; the r148 production face): the
//! compiler twin — `selfhost/v1/compiler.ktf` plus the `items` slot
//! declaration and the `co_limit` work-budget define — compiled ONCE
//! per process (per distinct depth budget) through the seed face,
//! every production compile a fresh VM run with the expanded item
//! stream bound through the injection channel. The
//! `SteadyExpanderChain`/`SteadyCheckChain` shapes carried to the
//! compile segment: parse once, check once, compile once.
//!
//! Channel contract (the build-time half, the reader-chain
//! precedent): the fixed program must REFERENCE `items` (checked at
//! construction so the chain fails at build, not at first compile)
//! and must not DEFINE it (a program-side define would clobber the
//! bound slot at run time — the twins hold that discipline; the
//! sweep is the machine check).
//!
//! Budget mirroring (the `ex_limit`/`tp_limit` precedent, r148): the
//! twin's `co_limit` global rides the assembly prefix
//! (`define(co_limit, N);` — [`crate::bootstrap::target_corpus::
//! assembled_compiler_target_source_with_limit`]), so the chain
//! constructed under one budget rejects over-depth trees with the
//! same key the Rust oracle's `compile_program_with_limit` would —
//! the rollback band's parity obligation. Each distinct budget gets
//! its own once-compiled chain (the cache lives in the production
//! sibling, `crate::compile_segment`).
//!
//! The dual-engine agreement face for the compiler twin stays where
//! it has lived since the r122/r124 parity family: the assembled
//! baked-prefix route ([`crate::bootstrap::target_corpus::
//! ktf_compile_rich`] — both engines, verdict texts compared). This
//! chain is the PRODUCTION face: the VM arm only (the production
//! engine), the artifact rebuilt through the parity module's own
//! single-source rebuild faces.
//!
//! The spans the rebuild faces derive carry `FileId(0)` (the parity
//! harnesses' convention — the K163 fifth-instance finding): the
//! RETARGET to the session's file is the production segment
//! module's own policy step (`crate::compile_segment`), kept out
//! of this mechanical chain on purpose.

use kerf_compiler::{Bytecode, CompileError, compile_program};
use kerf_core::ModuleItem;
use kerf_vm::{BufferIo, Vm};

use crate::bootstrap::compiler_parity::{dump_ktf_section, rebuild_compile_error};
use crate::bootstrap::steady_typecheck_chain::STEADY_ITEMS_NAME;
use crate::bootstrap::vm_harness::{KtfVerdict, decode_tagged};

/// The host name the chain's own construction interns the twin
/// source under (the steady-chain naming form).
const STEADY_COMPILER_HOST_NAME: &str = "steady-compiler-chain.ktf";

/// The compiler twin's steady-state chain: the twin program compiled
/// once, every production compile a fresh VM run over the injected
/// item stream.
pub struct SteadyCompilerChain {
    bc: Bytecode,
}

impl SteadyCompilerChain {
    /// Compile the fixed compiler twin ONCE at one explicit
    /// compile-depth budget: `compiler.ktf` behind the `items` slot
    /// declaration and the `define(co_limit, N);` prefix, parsed
    /// through the production bridge (the target-skin reader) with
    /// `items` declared as an injected global (the extern-names
    /// precedent — the free reference expands, the payload still
    /// arrives only through the run-time slot bind), checked (the
    /// seed face — the Rust checkers by construction), compiled (the
    /// seed face — the Rust compiler by construction, never the
    /// switched arm: a twin-position compile here would be circular).
    /// No per-compile prefix ever enters this text.
    pub fn new_with_limit(limit: usize) -> Result<Self, String> {
        let assembled =
            crate::bootstrap::target_corpus::assembled_compiler_target_source_with_limit(limit);
        let injected = [kerf_span::Symbol::new(STEADY_ITEMS_NAME)
            .expect("the injected name is a valid identifier")];
        let mut session = crate::session::Session::new();
        let program = crate::pipeline::parse_target_with_injected(
            &mut session,
            STEADY_COMPILER_HOST_NAME,
            &assembled,
            &injected,
        )
        .map_err(|diags| {
            format!("harness defect: the fixed compiler twin failed to parse: {diags:?}")
        })?;
        let findings = program.typecheck();
        if findings
            .iter()
            .any(|d| d.severity == crate::diagnostic::Severity::Error)
        {
            return Err(format!(
                "harness defect: the fixed compiler twin failed the checker: {findings:?}"
            ));
        }
        let bc = compile_program(&program.items).map_err(|err| {
            format!("harness defect: the fixed compiler twin failed to compile: {err}")
        })?;
        // The channel contract's build-time face: the program must
        // reference the injected name — the compiler's collected
        // global table is the single source (the same check
        // `Vm::inject_global` enforces per bind, hoisted here so a
        // twin regression fails at construction, not at first
        // compile).
        if !bc.globals.iter().any(|g| g.as_str() == STEADY_ITEMS_NAME) {
            return Err(format!(
                "harness defect: the compiler twin does not reference `{STEADY_ITEMS_NAME}` — the injection channel has no slot"
            ));
        }
        Ok(Self { bc })
    }

    /// One PRODUCTION compile (the step-④ compile-segment switch, the
    /// `read_production`/`expand_production`/`check_production`
    /// precedent): the same fresh-VM run and the same injection, the
    /// verdict decoded — the tree arm rebuilds the ARTIFACT through
    /// the parity module's own single-source face (the two-judges
    /// contract's second judge included: the rebuilt product passes
    /// the VM's own verify floor inside `rebuild_bytecode`), the
    /// error arm hands the REBUILT rejection back (the program's own
    /// `CompileError`, exactly the oracle's error family — the
    /// production segment module retargets its spans to the session
    /// file). Never the comparison text: the sweeps own the text
    /// face, the production position consumes the artifact.
    pub fn compile_production(
        &self,
        items: &[ModuleItem],
    ) -> Result<Result<Bytecode, CompileError>, String> {
        let mut vm = Vm::with_io(self.bc.clone(), Box::new(BufferIo::default()))
            .map_err(|err| format!("harness defect: the vm rejected the compiler twin: {err}"))?;
        crate::bootstrap::steady_typecheck_chain::inject_items_stream(&mut vm, items)
            .map_err(|err| format!("harness defect: the injection channel: {err}"))?;
        vm.run()
            .map_err(|err| format!("harness defect: the compiler twin run failed: {err:?}"))?;
        let value = vm
            .global("result")
            .cloned()
            .ok_or_else(|| "harness defect: no `result` global on the vm engine".to_string())?;
        let verdict: KtfVerdict<CompileError> =
            decode_tagged(&value, vm.heap(), dump_ktf_section, rebuild_compile_error)?;
        match verdict {
            KtfVerdict::Tree(_) => {
                let bc = crate::bootstrap::compiler_parity::rebuild_bytecode_unverified(
                    &value,
                    vm.heap(),
                )
                .map_err(|err| format!("harness defect: the artifact rebuild: {err}"))?;
                // The two-judges floor, made explicit (the r148
                // production face): the twin's product must pass the
                // VM's own verify — a rejection here is the PROGRAM's
                // compile error (the SAME `CompileError` family the
                // oracle's compile-time police raises: the twin's
                // disclosed blind faces — §6e, zero character ops in
                // the frozen subset — ride this floor), never a
                // silent pass and never a disguised harness defect.
                match bc.verify() {
                    Ok(()) => Ok(Ok(bc)),
                    Err(err) => Ok(Err(err)),
                }
            }
            KtfVerdict::Error(err) => Ok(Err(err)),
        }
    }
}

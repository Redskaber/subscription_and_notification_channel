//! The W-HM-TWIN segment-three steady-state bootstrap chain
//! (w-hm-twin-window.md §3 TWIN-3, the 127-a driver): the HM
//! inference twin — `selfhost/v1/infer.ktf`, nothing else — compiled
//! ONCE through the production bridge, every inference binding the
//! expanded item stream into the `items` global slot through the
//! injection channel's VM arm before the run. The segment-one
//! (`SteadyReaderChain`) and segment-two (`SteadyExpanderChain`)
//! shapes carried to segment three: parse once, check once, compile
//! once; per inference a fresh VM, the payload bind, the run, the
//! decoded verdict text.
//!
//! Channel contract (the build-time half, the reader-chain
//! precedent): the fixed program must REFERENCE `items` (the
//! compiler's collected global table is the single source — checked
//! at construction so the chain fails at build, not at first
//! inference) and must not DEFINE it (a program-side define would
//! clobber the bound slot at run time — the twins hold that
//! discipline; the sweep is the machine check).
//!
//! The 127-c extension ships the dual-engine faces (the RS-4
//! discipline — the same once-compiled program, the same injection,
//! the two engines' outcomes both decoded) on both chains, and the
//! parity machine's other two faces (the `oracle_analysis_dump`
//! types segment and the dump/rebuild arms) plus the cross-route
//! equivalence (the steady route ≡ the per-source text route) live
//! in the parity siblings (`infer_parity` / `compiler_parity`).

use kerf_compiler::{Bytecode, compile_program};
use kerf_core::ModuleItem;
use kerf_runtime::Evaluator;
use kerf_vm::{BufferIo, Vm};

use crate::bootstrap::infer_parity::{decode_infer_result, items_stream_literal};
use crate::session::Session;

/// The injected global's canonical name — the CP-1 contract name
/// `items` (the same identity the text route's prefix defines and
/// the twin's hosting tail references).
pub const STEADY_ITEMS_NAME: &str = "items";

/// Bind one items stream through the injection channel, then drop
/// the host-side literal ITERATIVELY (the K163 family — the r148
/// sixth instance: a flat list's right spine makes the default
/// Box-drop glue one stack frame per cell, and the items streams
/// carry user quote data of arbitrary spine depth; the r146 sweep
/// covered the forms-stream sites, this helper completes the
/// items-stream side — every items injection site rides it, so the
/// discipline cannot be forgotten at a new site).
pub(crate) fn inject_items_stream(
    vm: &mut Vm,
    items: &[ModuleItem],
) -> Result<(), kerf_vm::RuntimeError> {
    let lit = items_stream_literal(items);
    let injected = vm.inject_global(STEADY_ITEMS_NAME, &lit);
    crate::bootstrap::steady_target_reader_chain::dispose_literal_iteratively(lit);
    injected
}

/// The host name the fixed twin program parses under (diagnostics
/// attribution only — the twin verifies clean, so it never surfaces).
const STEADY_HOST_NAME: &str = "steady-typecheck-chain.ktf";

/// The host name the fixed checker twin parses under (the same
/// attribution-only face).
const STEADY_CHECK_HOST_NAME: &str = "steady-check-chain.ktf";

/// The steady-state HM inference twin chain: the compiled fixed
/// program plus the parsed items (the eval engine's face — the
/// RS-4 dual run evaluates the program items directly, never a
/// recompile).
pub struct SteadyTypecheckChain {
    bc: Bytecode,
    items: Vec<ModuleItem>,
}

impl SteadyTypecheckChain {
    /// Compile the fixed twin program ONCE: `infer.ktf`, parsed
    /// through the production bridge (the target-skin reader) with
    /// `items` declared as an injected global (the extern-names
    /// precedent — the free reference expands, the payload still
    /// arrives only through the run-time slot bind), checked,
    /// compiled. No per-inference prefix ever enters this text.
    pub fn new() -> Result<Self, String> {
        let assembled = crate::bootstrap::target_corpus::INFER_TARGET_SOURCE.to_string();
        let injected = [kerf_span::Symbol::new(STEADY_ITEMS_NAME)
            .expect("the injected name is a valid identifier")];
        let mut session = Session::new();
        let program = crate::pipeline::parse_target_with_injected(
            &mut session,
            STEADY_HOST_NAME,
            &assembled,
            &injected,
        )
        .map_err(|diags| {
            format!("harness defect: the fixed twin program failed to parse: {diags:?}")
        })?;
        let findings = program.typecheck();
        if findings
            .iter()
            .any(|d| d.severity == crate::diagnostic::Severity::Error)
        {
            return Err(format!(
                "harness defect: the fixed twin program failed the checker: {findings:?}"
            ));
        }
        let bc = compile_program(&program.items).map_err(|err| {
            format!("harness defect: the fixed twin program failed to compile: {err}")
        })?;
        if !bc.globals.iter().any(|g| g.as_str() == STEADY_ITEMS_NAME) {
            return Err(format!(
                "harness defect: the twin program does not reference `{STEADY_ITEMS_NAME}` — the injection channel has no slot"
            ));
        }
        Ok(Self {
            bc,
            items: program.items,
        })
    }

    /// One inference through the steady chain: a fresh VM per run
    /// (the globals start clean), the expanded item stream bound
    /// through the injection channel's value face, the run, the
    /// decoded verdict text (the comparison face of the sweep).
    pub fn infer(&self, items: &[ModuleItem]) -> Result<String, String> {
        let mut vm = Vm::with_io(self.bc.clone(), Box::new(BufferIo::default()))
            .map_err(|err| format!("harness defect: the vm rejected the twin program: {err}"))?;
        inject_items_stream(&mut vm, items)
            .map_err(|err| format!("harness defect: the injection channel: {err}"))?;
        vm.run()
            .map_err(|err| format!("harness defect: the twin run failed: {err:?}"))?;
        let value = vm
            .global("result")
            .ok_or_else(|| "harness defect: no `result` global on the vm engine".to_string())?;
        decode_infer_result(value, vm.heap())
    }

    /// One PRODUCTION inference (the step-④ check-segment switch —
    /// the inference layer of the checking segment): the same
    /// fresh-VM run and injection, the verdict decoded straight into
    /// the rebuilt findings (the structured tdiag records, never the
    /// comparison text — the typed-program axis stays the parity
    /// face's own comparison business; the production position
    /// consumes the diagnostics channel only, the oracle spine's
    /// own `infer_module` wiring contract).
    pub fn infer_production(
        &self,
        items: &[ModuleItem],
        file: kerf_span::FileId,
    ) -> Result<Vec<kerf_typecheck::TypeDiagnostic>, String> {
        let mut vm = Vm::with_io(self.bc.clone(), Box::new(BufferIo::default()))
            .map_err(|err| format!("harness defect: the vm rejected the twin program: {err}"))?;
        inject_items_stream(&mut vm, items)
            .map_err(|err| format!("harness defect: the injection channel: {err}"))?;
        vm.run()
            .map_err(|err| format!("harness defect: the twin run failed: {err:?}"))?;
        let value = vm
            .global("result")
            .cloned()
            .ok_or_else(|| "harness defect: no `result` global on the vm engine".to_string())?;
        let heap = vm.heap().clone();
        crate::check_segment::rebuild_infer_verdict(&value, &heap, file)
    }

    /// One inference on BOTH engines (the RS-4 dual-engine
    /// discipline: the same once-compiled program, the same
    /// injection, the two engines' verdict texts both decoded — the
    /// caller asserts their agreement, the segment-one
    /// `read_dual` precedent carried to segment three).
    pub fn infer_dual(&self, items: &[ModuleItem]) -> Result<(String, String), String> {
        let vm_text = self.infer(items)?;
        let mut evaluator = Evaluator::with_io(Box::new(BufferIo::default()));
        evaluator
            .inject_global(STEADY_ITEMS_NAME, &items_stream_literal(items))
            .map_err(|err| format!("harness defect: the injection channel: {err}"))?;
        evaluator.eval_program(&self.items).map_err(|err| {
            format!("harness defect: the eval engine rejected the twin program: {err:?}")
        })?;
        let value = evaluator
            .global("result")
            .ok_or_else(|| "harness defect: no `result` global on the eval engine".to_string())?;
        let eval_text = decode_infer_result(value, evaluator.heap())
            .map_err(|err| format!("harness defect: the eval engine's verdict decode: {err}"))?;
        Ok((vm_text, eval_text))
    }

    /// The debug arm (the r127 bisect probe): on a run failure the
    /// machine globals are appended to the error text — never a
    /// shipped face, exercised by the one-off probe example only.
    pub fn infer_debug(&self, items: &[ModuleItem]) -> Result<String, String> {
        let mut vm = Vm::with_budget(self.bc.clone(), 400_000)
            .map_err(|err| format!("harness defect: the vm rejected the twin program: {err}"))?;
        inject_items_stream(&mut vm, items)
            .map_err(|err| format!("harness defect: the injection channel: {err}"))?;
        const INFER_SRC: &str = crate::bootstrap::target_corpus::INFER_TARGET_SOURCE;
        eprintln!("[debug] vm.run() starting");
        let t0 = std::time::Instant::now();
        let run = vm.run();
        eprintln!("[debug] vm.run() finished in {:?}", t0.elapsed());
        if run.is_err() {
            let state = |n: &str| {
                vm.global(n)
                    .map(|v| format!("{v:?}"))
                    .unwrap_or_else(|| "absent".to_string())
            };
            let msg = format!("{run:?}");
            // The error span resolved against the twin source text.
            let span_ctx = match &run {
                Err(kerf_vm::RuntimeError::TypeMismatch { span, .. })
                | Err(kerf_vm::RuntimeError::BudgetExceeded { span, .. }) => {
                    let s = (span.start.0 as usize).min(INFER_SRC.len());
                    let e = ((span.end.0 as usize).max(s + 1)).min(INFER_SRC.len());
                    let line = INFER_SRC[..s].matches('\n').count() + 1;
                    let lo = s.saturating_sub(70);
                    format!(
                        "span@line {line}: {:?}",
                        &INFER_SRC[lo.min(INFER_SRC.len())..e]
                    )
                }
                other => format!("{other:?}"),
            };
            // A shallow decoded tree dump of the given global (depth-capped).
            fn dump_tree(v: Option<&kerf_vm::Value>, heap: &kerf_vm::Heap, depth: usize) -> String {
                let Some(v) = v else { return "absent".into() };
                match v {
                    kerf_vm::Value::Nil => "nil".into(),
                    kerf_vm::Value::Int(i) => i.to_string(),
                    kerf_vm::Value::Str(s) => format!("{s:?}"),
                    kerf_vm::Value::Pair(_) => {
                        if depth == 0 {
                            return "…".into();
                        }
                        let mut parts = Vec::new();
                        let mut cur = v.clone();
                        loop {
                            match cur {
                                kerf_vm::Value::Nil => break,
                                kerf_vm::Value::Pair(r) => match heap.get(r) {
                                    Some(kerf_vm::HeapObj::Pair(car, cdr)) => {
                                        parts.push(dump_tree(Some(car), heap, depth - 1));
                                        cur = cdr.clone();
                                    }
                                    _ => {
                                        parts.push("dangling".into());
                                        break;
                                    }
                                },
                                other => {
                                    parts.push(format!("improper:{other:?}"));
                                    break;
                                }
                            }
                        }
                        format!("({})", parts.join(" "))
                    }
                    other => format!("{other:?}"),
                }
            }
            let globals = format!(
                "define_index={} | tasks={:?} | defines={} | flat={} | pre={} | slots={} | schemas={} | scc_of={} | env={} | results_out={}",
                state("ti-define-index"),
                vm.global("ti-tasks")
                    .map(|v| dump_tree(Some(v), vm.heap(), 3))
                    .unwrap_or_default(),
                dump_tree(vm.global("ti-defines"), vm.heap(), 4),
                dump_tree(vm.global("ti-flat"), vm.heap(), 6),
                dump_tree(vm.global("ti-pre"), vm.heap(), 3),
                dump_tree(vm.global("ti-slots"), vm.heap(), 3),
                dump_tree(vm.global("ti-schemas"), vm.heap(), 4),
                dump_tree(vm.global("ti-scc-of"), vm.heap(), 3),
                dump_tree(vm.global("ti-env"), vm.heap(), 4),
                dump_tree(vm.global("ti-results-out"), vm.heap(), 4),
            );
            return Err(format!("{msg} | {span_ctx} | {globals}"));
        }
        let value = vm
            .global("result")
            .ok_or_else(|| "harness defect: no `result` global on the vm engine".to_string())?;
        eprintln!("[debug] decode starting");
        match decode_infer_result(value, vm.heap()) {
            Ok(text) => Ok(text),
            Err(e) => {
                fn dump_tree(
                    v: Option<&kerf_vm::Value>,
                    heap: &kerf_vm::Heap,
                    depth: usize,
                ) -> String {
                    let Some(v) = v else { return "absent".into() };
                    match v {
                        kerf_vm::Value::Nil => "nil".into(),
                        kerf_vm::Value::Int(i) => i.to_string(),
                        kerf_vm::Value::Str(s) => format!("{s:?}"),
                        kerf_vm::Value::Pair(_) => {
                            if depth == 0 {
                                return "…".into();
                            }
                            let mut parts = Vec::new();
                            let mut cur = v.clone();
                            loop {
                                match cur {
                                    kerf_vm::Value::Nil => break,
                                    kerf_vm::Value::Pair(r) => match heap.get(r) {
                                        Some(kerf_vm::HeapObj::Pair(car, cdr)) => {
                                            parts.push(dump_tree(Some(car), heap, depth - 1));
                                            cur = cdr.clone();
                                        }
                                        _ => {
                                            parts.push("dangling".into());
                                            break;
                                        }
                                    },
                                    other => {
                                        parts.push(format!("improper:{other:?}"));
                                        break;
                                    }
                                }
                            }
                            format!("({})", parts.join(" "))
                        }
                        other => format!("{other:?}"),
                    }
                }
                Err(format!(
                    "{e} | raw result: {}",
                    dump_tree(vm.global("result"), vm.heap(), 8)
                ))
            }
        }
    }

    /// The debug variant arm (the r127 bisect probe): compile a
    /// MODIFIED twin source through the same production bridge and
    /// run it — never a shipped face.
    pub fn infer_debug_src(&self, items: &[ModuleItem], src: &str) -> Result<String, String> {
        let injected = [kerf_span::Symbol::new(STEADY_ITEMS_NAME)
            .expect("the injected name is a valid identifier")];
        let mut session = Session::new();
        let program = crate::pipeline::parse_target_with_injected(
            &mut session,
            "steady-typecheck-chain-debug.ktf",
            src,
            &injected,
        )
        .map_err(|diags| format!("variant failed to parse: {diags:?}"))?;
        let findings = program.typecheck();
        if findings
            .iter()
            .any(|d| d.severity == crate::diagnostic::Severity::Error)
        {
            return Err(format!("variant failed the checker: {findings:?}"));
        }
        let bc = compile_program(&program.items)
            .map_err(|err| format!("variant failed to compile: {err}"))?;
        let mut vm = Vm::with_budget(bc, 400_000)
            .map_err(|err| format!("vm rejected the variant: {err}"))?;
        inject_items_stream(&mut vm, items).map_err(|err| format!("injection channel: {err}"))?;
        if let Err(e) = vm.run() {
            return Err(format!("variant run failed: {e:?}"));
        }
        let value = vm
            .global("result")
            .ok_or_else(|| "no result global".to_string())?;
        match decode_infer_result(value, vm.heap()) {
            Ok(text) => Ok(text),
            Err(e) => {
                fn dump_tree(
                    v: Option<&kerf_vm::Value>,
                    heap: &kerf_vm::Heap,
                    depth: usize,
                ) -> String {
                    let Some(v) = v else { return "absent".into() };
                    match v {
                        kerf_vm::Value::Nil => "nil".into(),
                        kerf_vm::Value::Int(i) => i.to_string(),
                        kerf_vm::Value::Str(s) => format!("{s:?}"),
                        kerf_vm::Value::Pair(_) => {
                            if depth == 0 {
                                return "…".into();
                            }
                            let mut parts = Vec::new();
                            let mut cur = v.clone();
                            loop {
                                match cur {
                                    kerf_vm::Value::Nil => break,
                                    kerf_vm::Value::Pair(r) => match heap.get(r) {
                                        Some(kerf_vm::HeapObj::Pair(car, cdr)) => {
                                            parts.push(dump_tree(Some(car), heap, depth - 1));
                                            cur = cdr.clone();
                                        }
                                        _ => {
                                            parts.push("dangling".into());
                                            break;
                                        }
                                    },
                                    other => {
                                        parts.push(format!("improper:{other:?}"));
                                        break;
                                    }
                                }
                            }
                            format!("({})", parts.join(" "))
                        }
                        other => format!("{other:?}"),
                    }
                }
                Err(format!(
                    "{e} | raw: {} | schemas: {} | pre: {} | scc_of: {} | cur_scc: {:?} | slots: {}",
                    dump_tree(vm.global("result"), vm.heap(), 10),
                    dump_tree(vm.global("ti-schemas"), vm.heap(), 5),
                    dump_tree(vm.global("ti-pre"), vm.heap(), 4),
                    dump_tree(vm.global("ti-scc-of"), vm.heap(), 3),
                    vm.global("ti-cur-scc").map(|v| format!("{v:?}")),
                    dump_tree(vm.global("ti-slots"), vm.heap(), 4)
                ))
            }
        }
    }

    /// The compiled fixed product (the once-compiled bytecode — the
    /// observation face for tests; the per-inference cost is the
    /// injection + run, never a recompile).
    pub fn bytecode(&self) -> &Bytecode {
        &self.bc
    }
}

/// The W-HM-TWIN segment-three check-face steady chain
/// (w-hm-twin-window.md §3, the 127-b driver): the conservative
/// checker twin — `selfhost/v1/typecheck.ktf`, nothing else —
/// compiled ONCE through the production bridge, every check binding
/// the expanded item stream into the `items` global slot through the
/// injection channel's VM arm before the run (the same channel, the
/// same contract, the same `items` name as the inference chain —
/// TWIN-2's one-channel-many-segments discipline). The parsed items
/// ride alongside for the eval engine's face (the RS-4 dual run).
pub struct SteadyCheckChain {
    bc: Bytecode,
    items: Vec<ModuleItem>,
}

impl SteadyCheckChain {
    /// Compile the fixed checker twin ONCE: `typecheck.ktf`, parsed
    /// through the production bridge with `items` declared as an
    /// injected global (the free reference expands, the payload
    /// arrives only through the run-time slot bind), checked (the
    /// self-application face: the checker twin must itself survive
    /// the oracle checker error-free), compiled. No per-check prefix
    /// ever enters this text.
    pub fn new() -> Result<Self, String> {
        let assembled = crate::bootstrap::target_corpus::TYPECHECK_TARGET_SOURCE.to_string();
        let injected = [kerf_span::Symbol::new(STEADY_ITEMS_NAME)
            .expect("the injected name is a valid identifier")];
        let mut session = Session::new();
        let program = crate::pipeline::parse_target_with_injected(
            &mut session,
            STEADY_CHECK_HOST_NAME,
            &assembled,
            &injected,
        )
        .map_err(|diags| {
            format!("harness defect: the fixed checker twin failed to parse: {diags:?}")
        })?;
        let findings = program.typecheck();
        if findings
            .iter()
            .any(|d| d.severity == crate::diagnostic::Severity::Error)
        {
            return Err(format!(
                "harness defect: the fixed checker twin failed the checker: {findings:?}"
            ));
        }
        let bc = compile_program(&program.items).map_err(|err| {
            format!("harness defect: the fixed checker twin failed to compile: {err}")
        })?;
        if !bc.globals.iter().any(|g| g.as_str() == STEADY_ITEMS_NAME) {
            return Err(format!(
                "harness defect: the checker twin does not reference `{STEADY_ITEMS_NAME}` — the injection channel has no slot"
            ));
        }
        Ok(Self {
            bc,
            items: program.items,
        })
    }

    /// One check through the steady chain: a fresh VM per run (the
    /// globals start clean), the expanded item stream bound through
    /// the injection channel's value face, the run, the decoded
    /// verdict text (the comparison face of the sweep).
    pub fn check(&self, items: &[ModuleItem]) -> Result<String, String> {
        let mut vm = Vm::with_io(self.bc.clone(), Box::new(BufferIo::default()))
            .map_err(|err| format!("harness defect: the vm rejected the checker twin: {err}"))?;
        inject_items_stream(&mut vm, items)
            .map_err(|err| format!("harness defect: the injection channel: {err}"))?;
        vm.run()
            .map_err(|err| format!("harness defect: the checker twin run failed: {err:?}"))?;
        let value = vm
            .global("result")
            .ok_or_else(|| "harness defect: no `result` global on the vm engine".to_string())?;
        crate::bootstrap::typecheck_parity::decode_check_result(value, vm.heap())
    }

    /// One PRODUCTION check (the step-④ check-segment switch, the
    /// `read_production`/`expand_production` precedent): the same
    /// fresh-VM run and the same injection, but the verdict decoded
    /// straight into the REBUILT findings (the structured records,
    /// never the comparison text) — the conservative checker's
    /// findings are data, and the production position consumes them
    /// as `TypeDiagnostic`s with the spans retargeted to the
    /// session's file (the rebuild lives in `check_segment`, this
    /// module's production sibling — the record grammar's single
    /// source stays the parity face).
    pub fn check_production(
        &self,
        items: &[ModuleItem],
        file: kerf_span::FileId,
    ) -> Result<Vec<kerf_typecheck::TypeDiagnostic>, String> {
        let mut vm = Vm::with_io(self.bc.clone(), Box::new(BufferIo::default()))
            .map_err(|err| format!("harness defect: the vm rejected the checker twin: {err}"))?;
        inject_items_stream(&mut vm, items)
            .map_err(|err| format!("harness defect: the injection channel: {err}"))?;
        vm.run()
            .map_err(|err| format!("harness defect: the checker twin run failed: {err:?}"))?;
        let value = vm
            .global("result")
            .cloned()
            .ok_or_else(|| "harness defect: no `result` global on the vm engine".to_string())?;
        let heap = vm.heap().clone();
        crate::check_segment::rebuild_check_verdict(&value, &heap, file)
    }

    /// One check on BOTH engines (the RS-4 dual-engine discipline —
    /// the same once-compiled program, the same injection, the two
    /// engines' verdict texts both decoded).
    pub fn check_dual(&self, items: &[ModuleItem]) -> Result<(String, String), String> {
        let vm_text = self.check(items)?;
        let mut evaluator = Evaluator::with_io(Box::new(BufferIo::default()));
        evaluator
            .inject_global(STEADY_ITEMS_NAME, &items_stream_literal(items))
            .map_err(|err| format!("harness defect: the injection channel: {err}"))?;
        evaluator.eval_program(&self.items).map_err(|err| {
            format!("harness defect: the eval engine rejected the checker twin: {err:?}")
        })?;
        let value = evaluator
            .global("result")
            .ok_or_else(|| "harness defect: no `result` global on the eval engine".to_string())?;
        let eval_text =
            crate::bootstrap::typecheck_parity::decode_check_result(value, evaluator.heap())
                .map_err(|err| {
                    format!("harness defect: the eval engine's verdict decode: {err}")
                })?;
        Ok((vm_text, eval_text))
    }

    /// The compiled fixed product (the once-compiled bytecode — the
    /// observation face for tests).
    pub fn bytecode(&self) -> &Bytecode {
        &self.bc
    }
}

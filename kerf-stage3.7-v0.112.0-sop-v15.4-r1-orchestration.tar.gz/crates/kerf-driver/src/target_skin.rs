//! The target-skin spelling and emission contract — the Rust-side
//! face of the reader's E5 skin map (stage0.md §9.46): how one
//! canonical (S-expr vocabulary) name, context or datum renders on
//! the target skin.
//!
//! Split out of `target_corpus.rs` at r122 (the user instruction-①
//! bootstrap-file unification): the skin map is a PRODUCTION contract
//! — the production bridge (`skin_transcoder.rs`) and the production
//! diagnostics (`diagnostic.rs`) consume it — so it stays at the
//! crate root beside its consumers while the selfhost twin surface
//! (the `selfhost/v1/*.ktf` embeddings, the injection prefixes, the
//! parity harnesses) moved under `bootstrap/` (SOP §8.4.6 two-level
//! semantics). `bootstrap/target_corpus.rs` remains a consumer of
//! this module — the twin prefix assembly rides the same single
//! spelling truth, so the two faces can never drift.

use kerf_syntax::StxDatum;
use kerf_vm::Builtin;

/// The inverse of the reader's E5 skin map (the naming guard's
/// spelling pass): the target spelling of one S-expr face name.
///
/// Inverse rule P: a trailing `?` becomes the `is_` marker before
/// the final segment (`nil?` → `is_nil`, `lx-digit?` →
/// `lx_is_digit`). Inverse rule K: `-` becomes `_`. The batch-1+2
/// table entries invert entry-wise. The caller round-trip checks
/// the result through the real reader — names the target
/// vocabulary cannot spell (an interior `_`, the bare operator
/// spellings, the shadowed modern names) fail there, never here.
pub(crate) fn target_skin_spelling(text: &str) -> String {
    let spelled = match text {
        "read-line" => "read_line".to_string(),
        "write-line" => "write_line".to_string(),
        "car" => "first".to_string(),
        "cdr" => "rest".to_string(),
        "cons" => "pair".to_string(),
        "eq?" => "eq".to_string(),
        "set!" => "set".to_string(),
        _ => match text.strip_suffix('?') {
            Some(stem) => match stem.rfind('-') {
                Some(i) => format!("{}_is_{}", &stem[..i], &stem[i + 1..]),
                None => format!("is_{stem}"),
            },
            None => text.to_string(),
        },
    };
    spelled.replace('-', "_")
}

/// The target-skin spelling of one canonical (S-expr vocabulary)
/// name: the skin map for word names, plus the one divergent
/// operator spelling (`=` → `==`; every other operator renders with
/// identical glyphs on both faces). Names the skin map cannot
/// spell pass through verbatim (the reader's own constraint —
/// target-unspellable names surface exactly as the canonical
/// pool text).
pub(crate) fn target_name(canonical: &str) -> String {
    if canonical == "=" {
        "==".to_string()
    } else {
        target_skin_spelling(canonical)
    }
}

/// The target-skin rendering of one runtime type-mismatch context:
/// tokens that name a registry builtin map through
/// [`target_name`]; engine-opcode vocabulary (`jump-if-false`,
/// `add`, the call callee) is face-neutral and passes through
/// verbatim. Backticked operator tokens keep their backticks.
pub(crate) fn target_context(context: &str) -> String {
    context
        .split(' ')
        .map(|token| {
            let (bare, backticked) = match token.strip_prefix('`') {
                Some(rest) => (rest.strip_suffix('`').unwrap_or(rest), true),
                None => (token, false),
            };
            if Builtin::from_name(bare).is_none() {
                return token.to_string();
            }
            let spelled = target_name(bare);
            if backticked {
                format!("`{spelled}`")
            } else {
                spelled
            }
        })
        .collect::<Vec<_>>()
        .join(" ")
}

/// Emit one Stx datum as target-skin datum text (the quote carrier
/// grammar): lists ride the tuple skin — one element needs the
/// Rust tuple convention's trailing comma, two or more join with
/// commas. Shared with the step-5 program transcoder
/// (`skin_transcoder.rs`) — the single datum-emission truth.
///
/// The string arm is [`emit_escaped_string`] below — extracted as
/// the single escaping truth both emission faces share (r106 FIX-9:
/// skin_transcoder's `emit_string` delegates here; the old duplicated
/// loop was a copy-drift channel the "shared" doc comment denied).
pub(crate) fn emit_target_datum(datum: &StxDatum, out: &mut String) {
    match datum {
        // The symbol arm rides `target_name` (the r114 W-3.3 review:
        // the canonical `=` spells `==` on the datum face — the one
        // divergent operator glyph — so a datum naming it must emit
        // the operator spelling; every other name renders with
        // identical glyphs, and the read-back guard holds the rest).
        StxDatum::Symbol(symbol) => out.push_str(&target_name(symbol.as_str())),
        StxDatum::Int(v) => out.push_str(&v.to_string()),
        StxDatum::Float(v) => out.push_str(&format!("{v:?}")),
        StxDatum::Bool(v) => out.push_str(if *v { "true" } else { "false" }),
        StxDatum::String(value) => emit_escaped_string(value, out),
        StxDatum::List(items) => {
            if items.is_empty() {
                // The S-expr face rejects `(quote ())` (subset-spec
                // §2.5) — an empty list datum cannot reach the
                // transcoding face from the prefix builders.
                panic!("harness defect: the empty list datum rides as `nil`");
            }
            out.push('(');
            for (i, item) in items.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                emit_target_datum(&item.datum, out);
            }
            if items.len() == 1 {
                // `(d)` groups; `(d,)` is the one-element list.
                out.push(',');
            }
            out.push(')');
        }
    }
}

/// The string-literal arm of [`emit_target_datum`] — the escaping
/// set the datum carrier accepts (`\"` `\\` `\n` `\t` `\r`),
/// shared verbatim by the transcoder's string emission so the two
/// faces can never drift (r106 FIX-9: this extraction closed the
/// copy-drift channel the old duplicated loop left open despite the
/// "shared" doc claim).
pub(crate) fn emit_escaped_string(value: &str, out: &mut String) {
    out.push('"');
    for c in value.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\t' => out.push_str("\\t"),
            '\r' => out.push_str("\\r"),
            _ => out.push(c),
        }
    }
    out.push('"');
}

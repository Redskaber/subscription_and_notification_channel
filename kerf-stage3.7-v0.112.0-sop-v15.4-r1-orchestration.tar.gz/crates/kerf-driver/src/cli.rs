//! The CLI surface — `kerf run|check|repl` (stage-0-plan row 0.8).
//!
//! Hand-rolled argument parsing (zero external dependencies — the
//! §18 review keeps crates.io out of the driver; clap is a Stage 1+
//! agenda item at most). All user-facing text is R8 English,
//! lowercase, no trailing periods. Exit codes: `0` success, `1`
//! program or environment error, `2` usage error.
//!
//! The executable core ([`run_cli`]) is dependency-injected (file
//! reader, REPL input, pre-read stdin, output sinks) so the CLI
//! behavior is unit-testable without process spawns.

use std::io::Write;

use crate::diagnostic::Diagnostic;
use crate::pipeline::{self, DepthLimits, Engine};
use crate::render::render_diagnostics;
use crate::repl::{Repl, ReplEvent};
use crate::session::Session;

/// A parsed command line.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Command {
    /// Compile and execute a file.
    Run {
        file: String,
        engine: Engine,
        parity: bool,
    },
    /// Compile and verify without executing.
    Check { file: String },
    /// Transpile to C (the Stage 2.6 chain-external backend; the C
    /// text goes to stdout — `kerf emit-c f.ktf > f.c && cc f.c`).
    EmitC { file: String },
    /// Interactive session.
    Repl { engine: Engine },
    /// `--help` / no arguments (prints usage).
    Help,
    /// `--version`.
    Version,
}

/// Parse raw arguments (without the program name). `Err` carries the
/// usage-error message (exit code 2 territory).
pub fn parse_args(args: &[String]) -> Result<Command, String> {
    let mut it = args.iter();
    let Some(first) = it.next() else {
        return Ok(Command::Help);
    };
    match first.as_str() {
        "--help" | "-h" | "help" => {
            if it.next().is_some() {
                Err("--help takes no arguments".to_owned())
            } else {
                Ok(Command::Help)
            }
        }
        "--version" | "-V" => {
            // §9.62 SURF-3: the same trailing-argument strictness as
            // `--help` (before, `kerf --version foo` silently ignored
            // `foo` — asymmetric with `--help`, which errored).
            if it.next().is_some() {
                Err("--version takes no arguments".to_owned())
            } else {
                Ok(Command::Version)
            }
        }
        "run" => {
            let mut file: Option<String> = None;
            let mut engine = Engine::Vm;
            let mut parity = false;
            let rest: Vec<&String> = it.collect();
            let mut i = 0;
            while i < rest.len() {
                let arg = rest[i];
                if arg == "--parity" {
                    parity = true;
                    i += 1;
                } else if arg == "--engine" {
                    let Some(value) = rest.get(i + 1) else {
                        return Err("--engine requires a value (`vm` or `eval`)".to_owned());
                    };
                    engine = match value.as_str() {
                        "vm" => Engine::Vm,
                        "eval" => Engine::Eval,
                        other => {
                            return Err(format!(
                                "unknown engine `{other}` (expected `vm` or `eval`)"
                            ));
                        }
                    };
                    i += 2;
                } else if arg == "--skin" {
                    // The r151 single-skin retirement: the target skin
                    // is the only skin (W-SEXP-RETIRE blade 2) — the
                    // flag errors loudly rather than silently
                    // accepting a no-op (SOP §2.3-4).
                    return Err(
                        "--skin was retired at v0.112.0: the target skin is the only skin"
                            .to_owned(),
                    );
                } else if arg.starts_with("--") {
                    return Err(format!("unknown option `{arg}`"));
                } else if file.is_none() {
                    file = Some(arg.clone());
                    i += 1;
                } else {
                    return Err(format!("unexpected argument `{arg}`"));
                }
            }
            match file {
                Some(file) => Ok(Command::Run {
                    file,
                    engine,
                    parity,
                }),
                None => Err("run requires a file: `kerf run <file>`".to_owned()),
            }
        }
        "check" => {
            let mut file: Option<String> = None;
            let rest: Vec<&String> = it.collect();
            let mut i = 0;
            while i < rest.len() {
                let arg = rest[i];
                if arg == "--skin" {
                    // The r151 single-skin retirement (see the run arm).
                    return Err(
                        "--skin was retired at v0.112.0: the target skin is the only skin"
                            .to_owned(),
                    );
                } else if arg.starts_with("--") {
                    return Err(format!("unknown option `{arg}`"));
                } else if file.is_none() {
                    file = Some(arg.clone());
                    i += 1;
                } else {
                    return Err(format!("unexpected argument `{arg}`"));
                }
            }
            match file {
                Some(file) => Ok(Command::Check { file }),
                None => Err("check requires exactly one file: `kerf check <file>`".to_owned()),
            }
        }
        "emit-c" => {
            let mut file: Option<String> = None;
            let rest: Vec<&String> = it.collect();
            let mut i = 0;
            while i < rest.len() {
                let arg = rest[i];
                if arg == "--skin" {
                    // The r151 single-skin retirement (see the run arm).
                    return Err(
                        "--skin was retired at v0.112.0: the target skin is the only skin"
                            .to_owned(),
                    );
                } else if arg.starts_with("--") {
                    return Err(format!("unknown option `{arg}`"));
                } else if file.is_none() {
                    file = Some(arg.clone());
                    i += 1;
                } else {
                    return Err(format!("unexpected argument `{arg}`"));
                }
            }
            match file {
                Some(file) => Ok(Command::EmitC { file }),
                None => Err("emit-c requires exactly one file: `kerf emit-c <file>`".to_owned()),
            }
        }
        "repl" => {
            // §9.62 SURF-5: the REPL accepts the same --engine choice
            // as `run` (the library always had the capability —
            // `Repl::with_options`; the CLI just never exposed it,
            // leaving the eval engine unreachable from the binary).
            let mut engine = Engine::Vm;
            let rest: Vec<&String> = it.collect();
            let mut i = 0;
            while i < rest.len() {
                let arg = rest[i];
                if arg == "--engine" {
                    let Some(value) = rest.get(i + 1) else {
                        return Err("--engine requires a value (`vm` or `eval`)".to_owned());
                    };
                    engine = match value.as_str() {
                        "vm" => Engine::Vm,
                        "eval" => Engine::Eval,
                        other => {
                            return Err(format!(
                                "unknown engine `{other}` (expected `vm` or `eval`)"
                            ));
                        }
                    };
                    i += 2;
                } else if arg == "--skin" {
                    // The r151 single-skin retirement: the target skin
                    // is the only skin (W-SEXP-RETIRE blade 2) — the
                    // flag errors loudly rather than silently
                    // accepting a no-op (SOP §2.3-4).
                    return Err(
                        "--skin was retired at v0.112.0: the target skin is the only skin"
                            .to_owned(),
                    );
                } else {
                    return Err(format!("unexpected argument `{arg}`"));
                }
            }
            Ok(Command::Repl { engine })
        }
        other => Err(format!(
            "unknown command `{other}` (expected `run`, `check`, `emit-c` or `repl`)"
        )),
    }
}

/// The usage text (`--help` and usage errors).
pub fn usage() -> String {
    "kerf — the kerf compiler driver (sexpr | target skins)

usage:
  kerf run <file> [--engine vm|eval] [--parity]
                                                 compile and execute a file
  kerf check <file>                             compile and verify, no execution
  kerf emit-c <file>                            transpile to C (chain-external backend)
  kerf repl [--engine vm|eval]
                                                 interactive session (ctrl-d exits)
  kerf --help | --version

options:
  --engine <name>   execution engine: `vm` (default) or `eval`
  --parity          run both engines and assert structural agreement

the source skin is the target skin only (the single-skin terminal
state of the W-SEXP-RETIRE window, r151 — the S-expression seed
skin was scaffolding and left the tree with its reader)

the emit-c product is one self-contained C file (runtime shim
embedded); it never enters the compiler's own build — the backend
is chain-external by constitution. compile it with the host cc:
  kerf emit-c prog.ktf > prog.c && cc prog.c -o prog

stdin piped into `run` feeds the program's `read-line` calls"
        .to_owned()
}

/// The driver version (single source: the workspace manifest).
pub fn version() -> &'static str {
    env!("CARGO_PKG_VERSION")
}

/// Execute a parsed command. All I/O is injected; returns the process
/// exit code.
#[allow(clippy::too_many_arguments)]
pub fn run_cli(
    args: &[String],
    read_file: &dyn Fn(&str) -> std::io::Result<String>,
    repl_input: &mut dyn FnMut() -> Option<String>,
    input_lines: Vec<String>,
    out: &mut dyn Write,
    err: &mut dyn Write,
) -> i32 {
    let command = match parse_args(args) {
        Ok(command) => command,
        Err(message) => {
            let _ = writeln!(err, "error: {message}");
            let _ = writeln!(err);
            let _ = write!(err, "{}", usage());
            return 2;
        }
    };
    match command {
        Command::Help => {
            let _ = write!(out, "{}", usage());
            0
        }
        Command::Version => {
            let _ = writeln!(out, "kerf {}", version());
            0
        }
        Command::Check { file } => match read_file(&file) {
            Err(io_err) => {
                let _ = writeln!(err, "error: cannot read `{file}`: {io_err}");
                1
            }
            Ok(source) => {
                let mut session = match session_from_env(err) {
                    Some(session) => session,
                    None => return 2,
                };
                match pipeline::check_source_with(&mut session, &file, &source) {
                    Ok(check) => {
                        // Warnings never block: they render to the error
                        // sink (the diagnostics channel) before the ok
                        // line, and the exit code stays 0.
                        if !check.warnings.is_empty() {
                            report(err, &session, &check.warnings);
                        }
                        let _ = writeln!(
                            out,
                            "ok: {} functions, {} instructions, {} constants, {} globals",
                            check.func_count,
                            check.instr_count,
                            check.const_count,
                            check.global_count
                        );
                        0
                    }
                    Err(diags) => {
                        report(err, &session, &diags);
                        1
                    }
                }
            }
        },
        Command::EmitC { file } => match read_file(&file) {
            Err(io_err) => {
                let _ = writeln!(err, "error: cannot read `{file}`: {io_err}");
                1
            }
            Ok(source) => {
                let mut session = match session_from_env(err) {
                    Some(session) => session,
                    None => return 2,
                };
                match pipeline::emit_c_source_with(&mut session, &file, &source) {
                    Ok(outcome) => {
                        if !outcome.warnings.is_empty() {
                            report(err, &session, &outcome.warnings);
                        }
                        let _ = write!(out, "{}", outcome.c_source);
                        0
                    }
                    Err(diags) => {
                        report(err, &session, &diags);
                        1
                    }
                }
            }
        },
        Command::Repl { engine } => {
            let _ = writeln!(out, "{}", Repl::greeting());
            let _ = writeln!(out, "skin: target (.ktf forms)");
            let mut repl = Repl::with_options(engine, Vec::new());
            loop {
                let Some(line) = repl_input() else {
                    return 0;
                };
                match repl.submit(&line) {
                    ReplEvent::Ignored | ReplEvent::NeedMoreInput => {}
                    ReplEvent::Evaluated {
                        value,
                        new_outputs,
                        new_warnings,
                    } => {
                        for warning in &new_warnings {
                            let _ = write!(err, "{warning}");
                        }
                        for output in &new_outputs {
                            let _ = writeln!(out, "{output}");
                        }
                        if let Some(value) = value {
                            let _ = writeln!(out, "{value}");
                        }
                    }
                    ReplEvent::Error { rendered } => {
                        let _ = write!(err, "{rendered}");
                    }
                }
            }
        }
        Command::Run {
            file,
            engine,
            parity,
        } => match read_file(&file) {
            Err(io_err) => {
                let _ = writeln!(err, "error: cannot read `{file}`: {io_err}");
                1
            }
            Ok(source) => {
                let mut session = match session_from_env(err) {
                    Some(session) => session,
                    None => return 2,
                };
                if parity {
                    // The local binding is `parity_out` — the module
                    // function `report` must stay callable inside the
                    // arms.
                    match pipeline::run_parity_source_with(
                        &mut session,
                        &file,
                        &source,
                        &input_lines,
                    ) {
                        Ok(parity_out) if parity_out.agrees() => {
                            if !parity_out.warnings.is_empty() {
                                report(err, &session, &parity_out.warnings);
                            }
                            let _ = writeln!(
                                out,
                                "parity: PASS (vm and eval agree on `{}`)",
                                parity_out.vm_repr
                            );
                            0
                        }
                        Ok(parity_out) => {
                            if !parity_out.warnings.is_empty() {
                                report(err, &session, &parity_out.warnings);
                            }
                            let _ = writeln!(err, "parity: FAIL");
                            let _ = writeln!(err, "  vm   = {}", parity_out.vm_repr);
                            let _ = writeln!(err, "  eval = {}", parity_out.eval_repr);
                            if !parity_out.outputs_agree {
                                let _ = writeln!(err, "  output sequences differ");
                            }
                            if !parity_out.globals_agree {
                                let _ = writeln!(err, "  global tables differ");
                            }
                            1
                        }
                        Err(diags) => {
                            report(err, &session, &diags);
                            1
                        }
                    }
                } else {
                    match pipeline::run_source_with(
                        &mut session,
                        &file,
                        &source,
                        engine,
                        &input_lines,
                    ) {
                        Ok(outcome) => {
                            if !outcome.warnings.is_empty() {
                                report(err, &session, &outcome.warnings);
                            }
                            for output in &outcome.outputs {
                                let _ = writeln!(out, "{output}");
                            }
                            if outcome.value != kerf_vm::Value::Nil {
                                let _ = writeln!(out, "{}", outcome.value_display());
                            }
                            0
                        }
                        Err(diags) => {
                            report(err, &session, &diags);
                            1
                        }
                    }
                }
            }
        },
    }
}

/// Build the CLI session from the environment's depth-guardrail
/// overrides and the four segment positions (the process-entry env
/// consumers: the K162 depth face, W-REC-DEPTH blade 2, and the
/// step-④ rollback band selectors `KERF_READ_SEGMENT` /
/// `KERF_EXPAND_SEGMENT` / `KERF_CHECK_SEGMENT` /
/// `KERF_COMPILE_SEGMENT` — the T-a switch window): an invalid
/// override aborts the command (fail-closed) with the parse error on
/// the error sink.
fn session_from_env(err: &mut dyn Write) -> Option<Session> {
    let limits = match DepthLimits::from_env() {
        Ok(limits) => limits,
        Err(message) => {
            let _ = writeln!(err, "error: {message}");
            return None;
        }
    };
    let read_segment = match crate::read_segment::ReadSegment::from_env() {
        Ok(segment) => segment,
        Err(message) => {
            let _ = writeln!(err, "error: {message}");
            return None;
        }
    };
    let expand_segment = match crate::expand_segment::ExpandSegment::from_env() {
        Ok(segment) => segment,
        Err(message) => {
            let _ = writeln!(err, "error: {message}");
            return None;
        }
    };
    let check_segment = match crate::check_segment::CheckSegment::from_env() {
        Ok(segment) => segment,
        Err(message) => {
            let _ = writeln!(err, "error: {message}");
            return None;
        }
    };
    let compile_segment = match crate::compile_segment::CompileSegment::from_env() {
        Ok(segment) => segment,
        Err(message) => {
            let _ = writeln!(err, "error: {message}");
            return None;
        }
    };
    let mut session = Session::with_limits(limits);
    session.set_read_segment(read_segment);
    session.set_expand_segment(expand_segment);
    session.set_check_segment(check_segment);
    session.set_compile_segment(compile_segment);
    Some(session)
}

/// Render a diagnostic batch to the error sink.
fn report(err: &mut dyn Write, session: &Session, diags: &[Diagnostic]) {
    let _ = write!(err, "{}", render_diagnostics(session, diags));
}

#[cfg(test)]
mod tests {
    //! CLI tests (FP4): argument parsing (every command + error
    //! family), exit codes, output shapes, injected I/O.

    use super::*;

    fn no_files(_: &str) -> std::io::Result<String> {
        Err(std::io::Error::new(std::io::ErrorKind::NotFound, "no file"))
    }

    fn file_with(content: &'static str) -> impl Fn(&str) -> std::io::Result<String> {
        move |_| Ok(content.to_owned())
    }

    fn no_input() -> impl FnMut() -> Option<String> {
        || None
    }

    fn run(args: &[&str]) -> i32 {
        let args: Vec<String> = args.iter().map(|s| (*s).to_owned()).collect();
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        run_cli(
            &args,
            &no_files,
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        )
    }

    #[test]
    fn no_args_is_help_with_zero_exit() {
        let args: Vec<String> = vec![];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &no_files,
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0);
        let text = String::from_utf8(out).expect("utf8");
        assert!(text.contains("usage:"));
        assert!(text.contains("kerf run <file>"));
    }

    #[test]
    fn version_flag_prints_workspace_version() {
        let args = vec!["--version".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &no_files,
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0);
        assert_eq!(
            String::from_utf8(out).expect("utf8"),
            format!("kerf {}\n", version())
        );
    }

    #[test]
    fn parse_run_defaults_to_vm_engine() {
        let cmd = parse_args(&["run".to_owned(), "f.krf".to_owned()]).expect("parse");
        assert_eq!(
            cmd,
            Command::Run {
                file: "f.krf".to_owned(),
                engine: Engine::Vm,
                parity: false,
            }
        );
    }

    #[test]
    fn parse_run_accepts_engine_and_parity() {
        let cmd = parse_args(&[
            "run".to_owned(),
            "f.krf".to_owned(),
            "--engine".to_owned(),
            "eval".to_owned(),
            "--parity".to_owned(),
        ])
        .expect("parse");
        assert_eq!(
            cmd,
            Command::Run {
                file: "f.krf".to_owned(),
                engine: Engine::Eval,
                parity: true,
            }
        );
    }

    #[test]
    fn parse_run_rejects_the_retired_skin_flag() {
        // The r151 single-skin retirement: `--skin` left with the
        // S-expression scaffold — it errors loudly on every file
        // command, never a silent no-op (SOP §2.3-4).
        assert!(
            parse_args(&[
                "run".to_owned(),
                "f.ktf".to_owned(),
                "--skin".to_owned(),
                "target".to_owned(),
            ])
            .is_err()
        );
        assert!(
            parse_args(&[
                "run".to_owned(),
                "f.ktf".to_owned(),
                "--skin".to_owned(),
                "sexpr".to_owned(),
            ])
            .is_err()
        );
        assert!(parse_args(&["run".to_owned(), "f.ktf".to_owned(), "--skin".to_owned()]).is_err());
    }

    #[test]
    fn parse_check_requires_exactly_one_file() {
        assert!(parse_args(&["check".to_owned()]).is_err());
        assert!(parse_args(&["check".to_owned(), "a".to_owned(), "b".to_owned()]).is_err());
        assert_eq!(
            parse_args(&["check".to_owned(), "a.krf".to_owned()]).expect("parse"),
            Command::Check {
                file: "a.krf".to_owned(),
            }
        );
        // The r151 single-skin retirement: `--skin` errors on check
        // the same way.
        assert!(
            parse_args(&[
                "check".to_owned(),
                "--skin".to_owned(),
                "target".to_owned(),
                "a.krf".to_owned(),
            ])
            .is_err()
        );
    }

    #[test]
    fn parse_emit_c_requires_exactly_one_file() {
        assert!(parse_args(&["emit-c".to_owned()]).is_err());
        assert!(parse_args(&["emit-c".to_owned(), "a".to_owned(), "b".to_owned()]).is_err());
        assert!(parse_args(&["emit-c".to_owned(), "--opt".to_owned()]).is_err());
        assert_eq!(
            parse_args(&["emit-c".to_owned(), "a.krf".to_owned()]).expect("parse"),
            Command::EmitC {
                file: "a.krf".to_owned(),
            }
        );
        // The r151 single-skin retirement: `--skin` errors on
        // emit-c the same way.
        assert!(
            parse_args(&[
                "emit-c".to_owned(),
                "a.ktf".to_owned(),
                "--skin".to_owned(),
                "sexpr".to_owned(),
            ])
            .is_err()
        );
    }

    #[test]
    fn emit_c_prints_c_source_with_generated_header() {
        // The r151 single-skin retarget: the fixture rides the target
        // skin (the pos-001 corpus spelling).
        let args = vec!["emit-c".to_owned(), "prog.ktf".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &file_with("define(result, (40 + 2));"),
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0);
        let text = String::from_utf8(out).expect("utf8");
        assert!(
            text.contains("generated by kerf emit-c"),
            "the product header must lead the C text"
        );
        assert!(text.contains("int main(void)"));
        assert!(text.contains("chain-external"));
    }

    #[test]
    fn emit_c_bad_program_renders_diagnostics_exit_one() {
        // The r151 single-skin retarget: the S-expr fixture had been
        // passing through a READ error (the group form rejects before
        // expansion ever runs); the target spelling restores the
        // intended expand-error face (an unbound call head).
        let args = vec!["emit-c".to_owned(), "bad.ktf".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &file_with("define(r, undefined_call(1));"),
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 1);
        assert!(out.is_empty(), "no C text on a rejected product");
        let text = String::from_utf8(errbuf).expect("utf8");
        assert!(text.contains("error"), "diagnostics render: {text}");
    }

    #[test]
    fn unknown_command_is_usage_error() {
        let err = parse_args(&["frobnicate".to_owned()]).expect_err("unknown");
        assert!(err.contains("unknown command `frobnicate`"));
        assert_eq!(run(&["frobnicate"]), 2);
    }

    #[test]
    fn unknown_option_is_usage_error() {
        let err = parse_args(&["run".to_owned(), "f.krf".to_owned(), "--wat".to_owned()])
            .expect_err("unknown option");
        assert!(err.contains("unknown option `--wat`"));
        assert_eq!(run(&["run", "f.krf", "--wat"]), 2);
    }

    #[test]
    fn missing_engine_value_is_usage_error() {
        let err = parse_args(&["run".to_owned(), "f.krf".to_owned(), "--engine".to_owned()])
            .expect_err("engine value");
        assert!(err.contains("--engine requires a value"));
        assert_eq!(run(&["run", "f.krf", "--engine"]), 2);
    }

    #[test]
    fn bad_engine_name_is_usage_error() {
        let err = parse_args(&[
            "run".to_owned(),
            "f.krf".to_owned(),
            "--engine".to_owned(),
            "native".to_owned(),
        ])
        .expect_err("bad engine");
        assert!(err.contains("unknown engine `native`"));
        assert_eq!(run(&["run", "f.krf", "--engine", "native"]), 2);
    }

    #[test]
    fn run_without_file_is_usage_error() {
        assert_eq!(run(&["run"]), 2);
    }

    #[test]
    fn unreadable_file_is_environment_error_exit_one() {
        let args = vec!["run".to_owned(), "gone.krf".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &no_files,
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 1);
        let text = String::from_utf8(errbuf).expect("utf8");
        assert!(text.contains("cannot read `gone.krf`"));
    }

    #[test]
    fn run_prints_outputs_and_non_nil_value() {
        let args = vec!["run".to_owned(), "prog.ktf".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &file_with("define(r, write_line(\"hello\"));"),
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0);
        let text = String::from_utf8(out).expect("utf8");
        assert_eq!(text, "hello\n", "nil halt values stay silent");
    }

    #[test]
    fn run_bad_program_renders_diagnostics_exit_one() {
        // The r151 single-skin retarget: the unclosed-form carrier is
        // the neg-001 corpus twin (`define(result, (1 + 2;`) — the
        // reader rejects the unclosed group at the `;` (byte 21 →
        // column 22, re-pinned from the S-expr unclosed-list anchor).
        let args = vec!["run".to_owned(), "bad.ktf".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &file_with("define(result, (1 + 2;"),
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 1);
        let text = String::from_utf8(errbuf).expect("utf8");
        assert!(text.contains("error[kerf-read]:"));
        assert!(text.contains("--> bad.ktf:1:22"), "{text}");
    }

    #[test]
    fn check_prints_counts_exit_zero() {
        let args = vec!["check".to_owned(), "ok.ktf".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &file_with("define(r, (1 + 2));"),
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0);
        let text = String::from_utf8(out).expect("utf8");
        assert!(text.starts_with("ok: "), "{text}");
        assert!(text.contains("functions"));
    }

    #[test]
    fn parity_flag_reports_pass() {
        let args = vec!["run".to_owned(), "p.ktf".to_owned(), "--parity".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &file_with("define(r, (20 + 22));"),
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0);
        let text = String::from_utf8(out).expect("utf8");
        assert!(text.contains("parity: PASS"), "{text}");
    }

    #[test]
    fn repl_loop_evaluates_and_exits_on_eof() {
        let args = vec!["repl".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let lines = vec![
            Some("define(x, 1);".to_owned()),
            Some("(x + 41);".to_owned()),
            None,
        ];
        let mut it = lines.into_iter();
        let mut next = move || it.next().flatten();
        let code = run_cli(
            &args,
            &no_files,
            &mut next,
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0);
        let text = String::from_utf8(out).expect("utf8");
        assert!(text.contains("kerf repl"));
        assert!(text.ends_with("42\n"), "value printed: {text}");
    }

    #[test]
    fn repl_error_goes_to_err_stream_and_survives() {
        let args = vec!["repl".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let lines = vec![
            Some("nope_undefined();".to_owned()),
            Some("(1 + 2);".to_owned()),
            None,
        ];
        let mut it = lines.into_iter();
        let mut next = move || it.next().flatten();
        let code = run_cli(
            &args,
            &no_files,
            &mut next,
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0);
        let err_text = String::from_utf8(errbuf).expect("utf8");
        assert!(err_text.contains("kerf-expand"), "{err_text}");
        let out_text = String::from_utf8(out).expect("utf8");
        assert!(out_text.ends_with("3\n"), "session survived: {out_text}");
    }

    #[test]
    fn help_flag_is_zero_exit() {
        assert_eq!(run(&["--help"]), 0);
    }

    // ---- §9.62: user-surface rulings SURF-3 / SURF-5 ----

    #[test]
    fn version_flag_with_trailing_argument_is_usage_error() {
        // SURF-3: `--version` is as strict as `--help` — trailing
        // arguments no longer get silently ignored.
        let err =
            parse_args(&["--version".to_owned(), "wat".to_owned()]).expect_err("trailing arg");
        assert!(err.contains("--version takes no arguments"));
        assert_eq!(run(&["--version", "wat"]), 2);
        assert_eq!(run(&["-V"]), 0, "the bare flag still works");
    }

    #[test]
    fn parse_repl_defaults_to_vm_engine() {
        let cmd = parse_args(&["repl".to_owned()]).expect("parse");
        assert_eq!(cmd, Command::Repl { engine: Engine::Vm });
    }

    #[test]
    fn parse_repl_accepts_engine_choice() {
        let cmd = parse_args(&["repl".to_owned(), "--engine".to_owned(), "eval".to_owned()])
            .expect("parse");
        assert_eq!(
            cmd,
            Command::Repl {
                engine: Engine::Eval,
            }
        );
        let bad = parse_args(&[
            "repl".to_owned(),
            "--engine".to_owned(),
            "native".to_owned(),
        ])
        .expect_err("bad engine");
        assert!(bad.contains("unknown engine `native`"));
        assert_eq!(run(&["repl", "--engine", "native"]), 2);
        let stray = parse_args(&["repl".to_owned(), "f.krf".to_owned()]).expect_err("stray arg");
        assert!(stray.contains("unexpected argument `f.krf`"));
    }

    #[test]
    fn repl_engine_flag_runs_the_eval_engine_end_to_end() {
        // SURF-5 integration: the whole CLI chain — parse, the
        // `--engine eval` flag, the REPL loop, the eval engine —
        // reaches the value. Before, the eval engine was unreachable
        // from the binary (library-only via `Repl::with_options`).
        let args = vec!["repl".to_owned(), "--engine".to_owned(), "eval".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let lines = vec![
            Some("define(x, 41);".to_owned()),
            Some("(x + 1);".to_owned()),
            None,
        ];
        let mut it = lines.into_iter();
        let mut next = move || it.next().flatten();
        let code = run_cli(
            &args,
            &no_files,
            &mut next,
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0);
        let text = String::from_utf8(out).expect("utf8");
        assert!(text.contains("kerf repl"), "greeting: {text}");
        assert!(text.ends_with("42\n"), "eval engine value: {text}");
    }

    // ---- Stage 1.1: warning paths (test doc driver-wiring.md FP5) ----

    #[test]
    fn check_with_warnings_prints_them_and_exits_zero() {
        // The r151 single-skin retarget: the warning carrier is the
        // expression-position assign (`set(first, 1)` — the neg-015
        // corpus shape, `set` maps to `set!`, `first` to `car`); the
        // rendered subject re-spells through the skin map, so the
        // warning names the target spelling `first` (what the user
        // actually wrote), never the canonical `car`.
        let args = vec!["check".to_owned(), "warn.ktf".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &file_with("define(r, set(first, 1));"),
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0, "warnings never change the exit code");
        let err_text = String::from_utf8(errbuf).expect("utf8");
        assert!(
            err_text.contains("warning[E0008]: assignment rebinds builtin `first`"),
            "{err_text}"
        );
        let out_text = String::from_utf8(out).expect("utf8");
        assert!(
            out_text.starts_with("ok: "),
            "the ok line still prints: {out_text}"
        );
    }

    #[test]
    fn run_with_warnings_prints_outputs_and_value() {
        let args = vec!["run".to_owned(), "warn.ktf".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &file_with("define(r, set(first, 41));\ndefine(r2, write_line(\"done\"));"),
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0);
        let err_text = String::from_utf8(errbuf).expect("utf8");
        assert!(err_text.contains("warning[E0008]"), "{err_text}");
        assert!(
            !err_text.contains("aborting due to"),
            "a single warning has no summary line: {err_text}"
        );
        let out_text = String::from_utf8(out).expect("utf8");
        assert_eq!(
            out_text, "done\n",
            "the program ran to its output despite the warning"
        );
    }

    #[test]
    fn run_with_definite_error_renders_registry_code_and_exits_one() {
        // The neg-030 corpus twin (`fn f(x) { x }` + the E0002 call).
        let args = vec!["run".to_owned(), "arity.ktf".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &file_with("fn f(x) { x }\ndefine(r, f(1, 2));"),
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 1);
        let err_text = String::from_utf8(errbuf).expect("utf8");
        assert!(
            err_text.contains("error[E0002]:"),
            "the registry tag renders: {err_text}"
        );
        assert!(err_text.contains("--> arity.ktf:2:"), "{err_text}");
        assert!(out.is_empty(), "a definite error produces no output");
    }

    #[test]
    fn parity_with_warnings_still_passes() {
        let args = vec!["run".to_owned(), "w.ktf".to_owned(), "--parity".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &file_with("define(r, set(first, 7));"),
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0);
        let err_text = String::from_utf8(errbuf).expect("utf8");
        assert!(err_text.contains("warning[E0008]"), "{err_text}");
        let out_text = String::from_utf8(out).expect("utf8");
        assert!(out_text.contains("parity: PASS"), "{out_text}");
    }

    #[test]
    fn repl_warning_prints_once_then_stays_silent() {
        let args = vec!["repl".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let lines = vec![
            Some("set(first, 1);".to_owned()),
            Some("(1 + 2);".to_owned()),
            None,
        ];
        let mut it = lines.into_iter();
        let mut next = move || it.next().flatten();
        let code = run_cli(
            &args,
            &no_files,
            &mut next,
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0);
        let err_text = String::from_utf8(errbuf).expect("utf8");
        assert_eq!(
            err_text.matches("warning[E0008]").count(),
            1,
            "the warning renders exactly once: {err_text}"
        );
        let out_text = String::from_utf8(out).expect("utf8");
        assert!(
            out_text.ends_with("3\n"),
            "the value still prints: {out_text}"
        );
    }

    // ---------- r106 FIX-3: the .ktf production-skin reachability ----------

    /// A minimal target-skin program (the .ktf twin of the S-expr
    /// fib-and-run shape): extension-derived routing must execute it.
    /// `write_line` is the target-skin spelling of the `write-line`
    /// builtin (the E5 batch-1 two-entry table).
    const KTF_PROG: &str = concat!(
        "fn add(a, b) { a + b }\n",
        "define(result, add(1, 2));\n",
        "define(out, write_line(\"done\"));\n",
    );

    #[test]
    fn run_executes_ktf_by_extension_default() {
        let args = vec!["run".to_owned(), "prog.ktf".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &file_with(KTF_PROG),
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0, "err: {}", String::from_utf8_lossy(&errbuf));
        assert!(
            String::from_utf8(out).expect("utf8").contains("done"),
            "the target-skin program ran through the extension-derived face"
        );
    }

    #[test]
    fn run_ktf_without_side_effects_exits_zero() {
        // The value-define-only shape: no output, Nil halt value, exit 0
        // (the run contract — value defines are not printed).
        let args = vec!["run".to_owned(), "prog.ktf".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &file_with("fn add(a, b) { a + b }\ndefine(result, add(1, 2));\n"),
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0, "err: {}", String::from_utf8_lossy(&errbuf));
        assert_eq!(String::from_utf8(out).expect("utf8"), "");
    }

    #[test]
    fn run_skin_flag_retirement_is_a_loud_usage_error() {
        // The r151 single-skin retirement record: this test's subject
        // was the two-skin override (`--skin sexpr` forced the
        // S-expression reader over target-skin text and failed
        // closed). The override machinery left with the S-expression
        // reader (W-SEXP-RETIRE blade 2): every spelling of the flag
        // now rejects loudly at the argument layer — never a silent
        // no-op (SOP §2.3-4). The parse-level family lives above
        // (`parse_run_rejects_the_retired_skin_flag` and its
        // check/emit-c/repl mirrors); this is the run_cli face: exit
        // 2, message on the error sink.
        let err = parse_args(&[
            "run".to_owned(),
            "prog.ktf".to_owned(),
            "--skin".to_owned(),
            "sexpr".to_owned(),
        ])
        .expect_err("the retired flag must error");
        assert_eq!(
            err,
            "--skin was retired at v0.112.0: the target skin is the only skin"
        );
        let args = vec![
            "run".to_owned(),
            "prog.ktf".to_owned(),
            "--skin".to_owned(),
            "target".to_owned(),
        ];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &file_with(KTF_PROG),
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 2, "a usage error, not a program error");
        assert!(out.is_empty(), "no output before the usage error");
        let err_text = String::from_utf8(errbuf).expect("utf8");
        assert!(
            err_text.contains("--skin was retired at v0.112.0: the target skin is the only skin"),
            "the loud message renders: {err_text}"
        );
    }

    #[test]
    fn run_sexpr_text_fails_closed_on_the_single_skin() {
        // The r151 single-skin retirement record: this test's subject
        // was the face override (`run prog.krf --skin target` forced
        // an S-expr-extension file onto the target reader and failed
        // closed). The override left with the S-expression reader —
        // the flag rejects loudly (the usage-error face above) — but
        // the test's fail-closed half survives on the single skin: a
        // `.krf`-named file rides the one target reader, and
        // S-expression text is genuinely not target-skin text
        // (`(define result 3)` reads as a group around the bare
        // symbol `define`, which the reader rejects) — fail-closed,
        // never a silent wrong-language parse.
        let args = vec!["run".to_owned(), "prog.krf".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &file_with("(define result 3)"),
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 1, "S-expr text must fail closed on the single skin");
        let err_text = String::from_utf8(errbuf).expect("utf8");
        assert!(
            err_text.contains("kerf-read"),
            "the read error renders: {err_text}"
        );
    }

    #[test]
    fn check_accepts_ktf_by_extension() {
        let args = vec!["check".to_owned(), "prog.ktf".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &file_with(KTF_PROG),
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0, "err: {}", String::from_utf8_lossy(&errbuf));
        let text = String::from_utf8(out).expect("utf8");
        assert!(text.starts_with("ok:"), "the check ok-line prints: {text}");
    }

    #[test]
    fn emit_c_transpiles_ktf_by_extension() {
        let args = vec!["emit-c".to_owned(), "prog.ktf".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let code = run_cli(
            &args,
            &file_with(KTF_PROG),
            &mut no_input(),
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0, "err: {}", String::from_utf8_lossy(&errbuf));
        let text = String::from_utf8(out).expect("utf8");
        assert!(
            text.contains("generated by kerf emit-c"),
            "the C product header is present"
        );
    }

    #[test]
    fn repl_target_skin_evaluates_and_wraps() {
        // The target-skin REPL: an expression submission wraps as the
        // call-like value define; the value prints. The r151
        // single-skin retarget: the target skin is the only skin, so
        // the banner names it unconditionally and the retired
        // `--skin` flag rejects loudly on the repl arm too (the
        // parse-level mirror of the run arm's family above).
        assert!(
            parse_args(&["repl".to_owned(), "--skin".to_owned(), "target".to_owned()]).is_err(),
            "the retired flag must error on the repl arm"
        );
        let args = vec!["repl".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let lines = vec![Some("1 + 2;".to_owned()), None];
        let mut it = lines.into_iter();
        let mut next = move || it.next().flatten();
        let code = run_cli(
            &args,
            &no_files,
            &mut next,
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0, "err: {}", String::from_utf8_lossy(&errbuf));
        let text = String::from_utf8(out).expect("utf8");
        assert!(text.contains("skin: target"), "the banner names the skin");
        assert!(text.ends_with("3\n"), "the value prints: {text}");
    }

    #[test]
    fn repl_target_skin_open_brace_requests_more_input() {
        // The multi-line brace form: an unclosed `{` asks for more
        // input line after line until the closing brace lands — the
        // r151 single-skin retarget (the flagless invocation; the
        // retired `--skin` flag rejects loudly, its mirror above).
        let args = vec!["repl".to_owned()];
        let mut out = Vec::new();
        let mut errbuf = Vec::new();
        let lines = vec![
            Some("fn f() {".to_owned()),
            Some("1".to_owned()),
            Some("}".to_owned()),
            None,
        ];
        let mut it = lines.into_iter();
        let mut next = move || it.next().flatten();
        let code = run_cli(
            &args,
            &no_files,
            &mut next,
            Vec::new(),
            &mut out,
            &mut errbuf,
        );
        assert_eq!(code, 0, "err: {}", String::from_utf8_lossy(&errbuf));
        let err_text = String::from_utf8(errbuf).expect("utf8");
        assert!(
            err_text.is_empty(),
            "the multi-line brace form must not error: {err_text}"
        );
    }
}

//! Semver triples and caret constraints (PKG-3).
//!
//! The caret rule follows the Cargo convention: for `major >= 1` the
//! major version is the compatibility boundary; for `major == 0` the
//! minor version is the boundary (pre-1.0 stability rides the minor).

use crate::error::PkgError;
use std::fmt;

/// An exact `X.Y.Z` version.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub struct Version {
    /// Major component.
    pub major: u64,
    /// Minor component.
    pub minor: u64,
    /// Patch component.
    pub patch: u64,
}

impl Version {
    /// Parse an exact `X.Y.Z` triple (all three components required).
    pub fn parse(text: &str) -> Result<Self, PkgError> {
        let parts = text.split('.').collect::<Vec<_>>();
        if parts.len() != 3 {
            return Err(PkgError::BadVersion {
                text: text.to_string(),
                message: "expected the X.Y.Z form".to_string(),
            });
        }
        let mut nums = [0u64; 3];
        for (slot, part) in nums.iter_mut().zip(parts.iter()) {
            *slot = part.parse().map_err(|_| PkgError::BadVersion {
                text: text.to_string(),
                message: format!("component \"{part}\" is not a number"),
            })?;
        }
        Ok(Version {
            major: nums[0],
            minor: nums[1],
            patch: nums[2],
        })
    }
}

impl fmt::Display for Version {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}.{}.{}", self.major, self.minor, self.patch)
    }
}

/// A caret requirement: `>= X.Y[.Z]` with the caret upper bound.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Constraint {
    /// Major component of the requirement.
    pub major: u64,
    /// Minor component of the requirement.
    pub minor: u64,
    /// Patch component of the requirement (`None` = any patch).
    pub patch: Option<u64>,
}

impl Constraint {
    /// Parse an `X.Y` or `X.Y.Z` requirement.
    pub fn parse(text: &str) -> Result<Self, PkgError> {
        let parts = text.split('.').collect::<Vec<_>>();
        if parts.len() != 2 && parts.len() != 3 {
            return Err(PkgError::BadVersion {
                text: text.to_string(),
                message: "expected the X.Y or X.Y.Z form".to_string(),
            });
        }
        let major = parts[0].parse().map_err(|_| PkgError::BadVersion {
            text: text.to_string(),
            message: format!("component \"{}\" is not a number", parts[0]),
        })?;
        let minor = parts[1].parse().map_err(|_| PkgError::BadVersion {
            text: text.to_string(),
            message: format!("component \"{}\" is not a number", parts[1]),
        })?;
        let patch = if parts.len() == 3 {
            Some(parts[2].parse().map_err(|_| PkgError::BadVersion {
                text: text.to_string(),
                message: format!("component \"{}\" is not a number", parts[2]),
            })?)
        } else {
            None
        };
        Ok(Constraint {
            major,
            minor,
            patch,
        })
    }

    /// Does `version` satisfy this caret requirement?
    ///
    /// - `major >= 1`: `version.major == major` and
    ///   `version >= (major, minor, patch-or-0)`
    /// - `major == 0`: `version.major == 0 && version.minor == minor`
    ///   and `version.patch >= patch-or-0`
    pub fn caret_satisfies(&self, version: Version) -> bool {
        if version.major != self.major {
            return false;
        }
        let (bound_minor, bound_patch) = (self.minor, self.patch.unwrap_or(0));
        if self.major == 0 {
            version.minor == bound_minor && version.patch >= bound_patch
        } else {
            (version.minor, version.patch) >= (bound_minor, bound_patch)
        }
    }
}

impl fmt::Display for Constraint {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.patch {
            Some(p) => write!(f, "{}.{}.{}", self.major, self.minor, p),
            None => write!(f, "{}.{}", self.major, self.minor),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn version_parses_the_full_triple() {
        let v = Version::parse("1.2.3").expect("the triple parses");
        assert_eq!(
            v,
            Version {
                major: 1,
                minor: 2,
                patch: 3
            }
        );
        assert_eq!(v.to_string(), "1.2.3");
    }

    #[test]
    fn version_rejects_short_and_non_numeric_forms() {
        assert!(
            Version::parse("1.2").is_err(),
            "two components are not exact"
        );
        assert!(
            Version::parse("1.2.3.4").is_err(),
            "four components are invalid"
        );
        assert!(
            Version::parse("1.x.3").is_err(),
            "non-numeric components fail"
        );
        assert!(Version::parse("").is_err(), "the empty literal fails");
    }

    #[test]
    fn constraint_parses_two_and_three_components() {
        let two = Constraint::parse("0.2").expect("the two-component form parses");
        assert_eq!(
            two,
            Constraint {
                major: 0,
                minor: 2,
                patch: None
            }
        );
        let three = Constraint::parse("1.2.3").expect("the three-component form parses");
        assert_eq!(three.patch, Some(3));
    }

    #[test]
    fn constraint_rejects_other_shapes() {
        assert!(Constraint::parse("1").is_err());
        assert!(Constraint::parse("latest").is_err());
    }

    #[test]
    fn caret_one_x_bounds_on_the_major() {
        let c = Constraint::parse("1.2").unwrap();
        assert!(c.caret_satisfies(Version::parse("1.2.0").unwrap()));
        assert!(c.caret_satisfies(Version::parse("1.9.3").unwrap()));
        assert!(
            !c.caret_satisfies(Version::parse("2.0.0").unwrap()),
            "major boundary"
        );
        assert!(
            !c.caret_satisfies(Version::parse("1.1.9").unwrap()),
            "lower bound"
        );
    }

    #[test]
    fn caret_zero_x_bounds_on_the_minor() {
        let c = Constraint::parse("0.2").unwrap();
        assert!(c.caret_satisfies(Version::parse("0.2.0").unwrap()));
        assert!(c.caret_satisfies(Version::parse("0.2.99").unwrap()));
        assert!(
            !c.caret_satisfies(Version::parse("0.3.0").unwrap()),
            "minor boundary"
        );
        assert!(!c.caret_satisfies(Version::parse("1.2.0").unwrap()));
    }

    #[test]
    fn caret_patch_component_sets_the_floor() {
        let c = Constraint::parse("0.1.5").unwrap();
        assert!(
            !c.caret_satisfies(Version::parse("0.1.4").unwrap()),
            "below the floor"
        );
        assert!(c.caret_satisfies(Version::parse("0.1.5").unwrap()));
        let one = Constraint::parse("1.2.3").unwrap();
        assert!(!one.caret_satisfies(Version::parse("1.2.2").unwrap()));
        assert!(one.caret_satisfies(Version::parse("1.2.3").unwrap()));
    }
}

//! The package-tool error family.
//!
//! Standalone by design (§11 interface isolation): these errors never
//! enter the compiler's E0xxx diagnostic registry — the package manager
//! is a build-bootstrap tool with its own face. Messages follow the Rust
//! convention: lowercase start, no trailing period.

use std::fmt;
use std::path::PathBuf;

/// An error raised by manifest parsing, lockfile handling, or resolution.
#[derive(Debug, Clone)]
pub enum PkgError {
    /// A manifest or lockfile failed the TOML-micro grammar.
    Syntax {
        /// The file the error was found in (as given).
        file: String,
        /// One-based line of the offending form.
        line: u32,
        /// One-based column of the offending form.
        col: u32,
        /// What went wrong (lowercase, no trailing period).
        message: String,
    },
    /// The manifest projection rejected a well-formed document
    /// (missing required fields, unknown keys, bad names — fail-closed).
    ManifestInvalid {
        /// The file the error was found in (as given).
        file: String,
        /// One-based line anchor for the rejected form, when known.
        line: Option<u32>,
        /// What went wrong (lowercase, no trailing period).
        message: String,
    },
    /// A version or constraint literal is not a valid semver shape.
    BadVersion {
        /// The literal that failed to parse.
        text: String,
        /// Why it failed (lowercase, no trailing period).
        message: String,
    },
    /// A dependency directory does not exist under the layout convention.
    DepDirNotFound {
        /// The dependency name that failed to resolve.
        name: String,
        /// The expected directory (missing).
        dir: PathBuf,
    },
    /// A manifest is missing where one is required.
    ManifestNotFound {
        /// The expected manifest path (missing).
        path: PathBuf,
    },
    /// The dependency graph closed a cycle; `cycle` names it in order.
    CycleDetected {
        /// The cycle names in visit order, first name repeated at the end.
        cycle: Vec<String>,
    },
    /// A resolved version violates at least one imposed constraint.
    VersionConflict {
        /// The package whose version is contested.
        name: String,
        /// The single resolved version.
        version: String,
        /// Every `(dependent, constraint)` pair imposed on the package.
        constraints: Vec<(String, String)>,
    },
    /// The dependency chain exceeded the resolution depth budget
    /// (the LIM ladder discipline — an error, never a stack overflow).
    DepthLimitExceeded {
        /// The depth budget that was exceeded.
        limit: u32,
        /// The package at the bottom of the chain.
        package: String,
    },
    /// Filesystem access failed while reading a manifest or writing a lockfile.
    Io {
        /// The operation attempted (lowercase, e.g. "read manifest").
        op: String,
        /// The underlying error text.
        source: String,
    },
}

impl fmt::Display for PkgError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            PkgError::Syntax {
                file,
                line,
                col,
                message,
            } => write!(f, "{file}:{line}:{col}: {message}"),
            PkgError::ManifestInvalid {
                file,
                line,
                message,
            } => match line {
                Some(line) => write!(f, "{file}:{line}: {message}"),
                None => write!(f, "{file}: {message}"),
            },
            PkgError::BadVersion { text, message } => {
                write!(f, "invalid version \"{text}\": {message}")
            }
            PkgError::DepDirNotFound { name, dir } => {
                write!(
                    f,
                    "dependency directory for \"{name}\" not found: {}",
                    dir.display()
                )
            }
            PkgError::ManifestNotFound { path } => {
                write!(f, "manifest not found: {}", path.display())
            }
            PkgError::CycleDetected { cycle } => {
                write!(f, "dependency cycle detected: {}", cycle.join(" -> "))
            }
            PkgError::VersionConflict {
                name,
                version,
                constraints,
            } => {
                write!(
                    f,
                    "version conflict for \"{name}\": resolved {version}, but "
                )?;
                let list = constraints
                    .iter()
                    .map(|(dep, c)| format!("\"{dep}\" requires {c}"))
                    .collect::<Vec<_>>()
                    .join(", ");
                write!(f, "{list}")
            }
            PkgError::DepthLimitExceeded { limit, package } => {
                write!(
                    f,
                    "dependency chain under \"{package}\" exceeds the depth limit {limit}"
                )
            }
            PkgError::Io { op, source } => write!(f, "{op}: {source}"),
        }
    }
}

impl std::error::Error for PkgError {}

//! The TOML-micro subset parser (PKG-1).
//!
//! The accepted grammar is a strict subset of TOML:
//!
//! - `#` comments (whole-line and trailing),
//! - blank lines,
//! - `key = "quoted string"` and `key = integer`,
//! - `[section]` headers,
//! - `[[array-section]]` headers (successive same-name headers accumulate
//!   separate table instances).
//!
//! Everything else — floats, booleans, dates, inline tables, arrays,
//! dotted keys, quoted keys — is rejected fail-closed with a line/column
//! position (SOP §2.3: report, never silently accept).

use std::fmt;

/// A value in the micro subset.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Value {
    /// A double-quoted string literal (escapes: `\\` and `\"`).
    Str(String),
    /// An integer literal (optional leading `-`).
    Int(i64),
}

impl fmt::Display for Value {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Value::Str(s) => write!(f, "\"{}\"", s.replace('\\', "\\\\").replace('"', "\\\"")),
            Value::Int(i) => write!(f, "{i}"),
        }
    }
}

/// A `key = value` pair with its source position.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Entry {
    /// The bare key (`[A-Za-z0-9_-]+`).
    pub key: String,
    /// The parsed value.
    pub value: Value,
    /// One-based line of the entry.
    pub line: u32,
    /// One-based column of the key start.
    pub col: u32,
}

/// A document item: a `[section]` table or one `[[array]]` table instance
/// (global entries live in [`Document::globals`]).
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Item {
    /// A `[name]` table with its entries.
    Table {
        /// The section name.
        name: String,
        /// The entries inside the section.
        entries: Vec<Entry>,
    },
    /// One instance of a `[[name]]` array table (in file order).
    ArrayTable {
        /// The section name.
        name: String,
        /// The entries inside this instance.
        entries: Vec<Entry>,
    },
}

/// A parsed micro-TOML document, items in file order.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct Document {
    /// Global entries in file order.
    pub globals: Vec<Entry>,
    /// Sections and array-table instances in file order.
    pub items: Vec<Item>,
}

/// A parse failure with its position.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct MicroTomlError {
    /// One-based line of the offending form.
    pub line: u32,
    /// One-based column of the offending form.
    pub col: u32,
    /// What went wrong (lowercase, no trailing period).
    pub message: String,
}

impl fmt::Display for MicroTomlError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}:{}: {}", self.line, self.col, self.message)
    }
}

impl std::error::Error for MicroTomlError {}

/// Parse `text` as a micro-TOML document.
///
/// Duplicate keys within the same table context (global scope or one
/// section instance) are rejected — the later definition never shadows.
pub fn parse(text: &str) -> Result<Document, MicroTomlError> {
    let mut doc = Document::default();
    let mut seen_globals: Vec<String> = Vec::new();
    // (section name, instance index, seen keys) — one stack frame per
    // open section; array tables open a fresh instance each header.
    let mut open: Option<(String, Vec<Entry>, Vec<String>)> = None;

    for (idx, raw_line) in text.lines().enumerate() {
        let line_no = (idx + 1) as u32;
        let trimmed = raw_line.trim_start();
        let indent = (raw_line.len() - trimmed.len()) as u32 + 1;

        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        // Section headers close any open table first.
        if trimmed.starts_with("[[") {
            let name = parse_array_header(trimmed, line_no, indent)?;
            flush(&mut doc, &mut open);
            open = Some((format!("[]{}", name), Vec::new(), Vec::new()));
            continue;
        }
        if trimmed.starts_with('[') {
            let name = parse_section_header(trimmed, line_no, indent)?;
            flush(&mut doc, &mut open);
            open = Some((name, Vec::new(), Vec::new()));
            continue;
        }

        // Otherwise the line must be a key = value entry.
        let entry = parse_entry(trimmed, line_no, indent)?;

        match &mut open {
            None => {
                if seen_globals.contains(&entry.key) {
                    return Err(MicroTomlError {
                        line: line_no,
                        col: indent,
                        message: format!("duplicate key \"{}\"", entry.key),
                    });
                }
                seen_globals.push(entry.key.clone());
                doc.globals.push(entry);
            }
            Some((_, entries, seen)) => {
                if seen.contains(&entry.key) {
                    return Err(MicroTomlError {
                        line: line_no,
                        col: indent,
                        message: format!("duplicate key \"{}\"", entry.key),
                    });
                }
                seen.push(entry.key.clone());
                entries.push(entry);
            }
        }
    }
    flush(&mut doc, &mut open);
    Ok(doc)
}

/// Move the open table (if any) into the document items.
fn flush(doc: &mut Document, open: &mut Option<(String, Vec<Entry>, Vec<String>)>) {
    if let Some((name, entries, _)) = open.take() {
        if let Some(array_name) = name.strip_prefix("[]") {
            doc.items.push(Item::ArrayTable {
                name: array_name.to_string(),
                entries,
            });
        } else {
            doc.items.push(Item::Table { name, entries });
        }
    }
}

/// Parse a `[name]` header line (already trimmed, starts with `[`).
fn parse_section_header(line: &str, line_no: u32, col: u32) -> Result<String, MicroTomlError> {
    let rest = &line[1..];
    let close = rest.find(']').ok_or_else(|| MicroTomlError {
        line: line_no,
        col,
        message: "section header is missing \"]\"".to_string(),
    })?;
    let name = &rest[..close];
    let tail = rest[close + 1..].trim();
    if !tail.is_empty() && !tail.starts_with('#') {
        return Err(MicroTomlError {
            line: line_no,
            col,
            message: "trailing content after section header".to_string(),
        });
    }
    validate_header_name(name, line_no, col)?;
    Ok(name.to_string())
}

/// Parse a `[[name]]` header line (already trimmed, starts with `[[`).
fn parse_array_header(line: &str, line_no: u32, col: u32) -> Result<String, MicroTomlError> {
    let rest = &line[2..];
    let close = rest.find("]]").ok_or_else(|| MicroTomlError {
        line: line_no,
        col,
        message: "array header is missing \"]]\"".to_string(),
    })?;
    let name = &rest[..close];
    let tail = rest[close + 2..].trim();
    if !tail.is_empty() && !tail.starts_with('#') {
        return Err(MicroTomlError {
            line: line_no,
            col,
            message: "trailing content after array header".to_string(),
        });
    }
    validate_header_name(name, line_no, col)?;
    Ok(name.to_string())
}

/// Header names share the bare-key shape.
fn validate_header_name(name: &str, line_no: u32, col: u32) -> Result<(), MicroTomlError> {
    if name.is_empty() {
        return Err(MicroTomlError {
            line: line_no,
            col,
            message: "empty section name".to_string(),
        });
    }
    if !name
        .chars()
        .all(|c| c.is_ascii_alphanumeric() || c == '-' || c == '_')
    {
        return Err(MicroTomlError {
            line: line_no,
            col,
            message: format!("section name \"{name}\" is not a bare key"),
        });
    }
    Ok(())
}

/// Parse one `key = value` line (already trimmed).
fn parse_entry(line: &str, line_no: u32, col: u32) -> Result<Entry, MicroTomlError> {
    let eq = line.find('=').ok_or_else(|| MicroTomlError {
        line: line_no,
        col,
        message: "expected `key = value`".to_string(),
    })?;
    let key = line[..eq].trim();
    if key.is_empty() {
        return Err(MicroTomlError {
            line: line_no,
            col,
            message: "empty key".to_string(),
        });
    }
    if !key
        .chars()
        .all(|c| c.is_ascii_alphanumeric() || c == '-' || c == '_')
    {
        return Err(MicroTomlError {
            line: line_no,
            col,
            message: format!("key \"{key}\" is not a bare key"),
        });
    }

    let value_part = line[eq + 1..].trim_start();
    let value_col = col + (line.len() - value_part.len()) as u32;
    let (value, rest) = parse_value(value_part, line_no, value_col)?;
    let rest_trimmed = rest.trim();
    if !rest_trimmed.is_empty() && !rest_trimmed.starts_with('#') {
        return Err(MicroTomlError {
            line: line_no,
            col: value_col,
            message: format!("trailing content after value: \"{rest_trimmed}\""),
        });
    }

    Ok(Entry {
        key: key.to_string(),
        value,
        line: line_no,
        col,
    })
}

/// Parse a value at the start of `s`; returns the value and the rest.
fn parse_value(s: &str, line_no: u32, col: u32) -> Result<(Value, &str), MicroTomlError> {
    if let Some(rest) = s.strip_prefix('"') {
        // Scan for the closing quote, honoring \\ and \" escapes.
        let mut out = String::new();
        let mut chars = rest.char_indices();
        loop {
            match chars.next() {
                None => {
                    return Err(MicroTomlError {
                        line: line_no,
                        col,
                        message: "unclosed string literal".to_string(),
                    });
                }
                Some((i, '\\')) => match chars.next() {
                    Some((_, c @ ('"' | '\\'))) => out.push(c),
                    _ => {
                        return Err(MicroTomlError {
                            line: line_no,
                            col: col + i as u32,
                            message: "invalid escape in string literal".to_string(),
                        });
                    }
                },
                Some((i, '"')) => {
                    return Ok((Value::Str(out), &rest[i + 1..]));
                }
                Some((_, c)) => out.push(c),
            }
        }
    }

    // Integer literal: optional '-', digits, then end or comment.
    let int_end = s.find([' ', '\t', '#']).unwrap_or(s.len());
    let token = &s[..int_end];
    if token == "-" || token.is_empty() {
        return Err(MicroTomlError {
            line: line_no,
            col,
            message: "expected a string or integer value".to_string(),
        });
    }
    let digits = token.strip_prefix('-').unwrap_or(token);
    if !digits.chars().all(|c| c.is_ascii_digit()) || digits.is_empty() {
        return Err(MicroTomlError {
            line: line_no,
            col,
            message: format!(
                "value \"{token}\" is not in the micro subset (strings and integers only)"
            ),
        });
    }
    let n: i64 = token.parse().map_err(|_| MicroTomlError {
        line: line_no,
        col,
        message: format!("integer \"{token}\" out of range"),
    })?;
    Ok((Value::Int(n), &s[int_end..]))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn valid_document_projects_all_shapes() {
        let doc = parse(
            "# leading comment\n\
             package = \"app\"\n\
             count = 3\n\
             delta = -7 # trailing comment\n\
             \n\
             [depends]\n\
             core-bits = \"0.2\"\n\
             \n\
             [[packages]]\n\
             name = \"a\"\n\
             \n\
             [[packages]]\n\
             name = \"b\"\n",
        )
        .expect("the valid document parses");
        assert_eq!(doc.globals.len(), 3);
        assert_eq!(doc.globals[0].value, Value::Str("app".to_string()));
        assert_eq!(doc.globals[1].value, Value::Int(3));
        assert_eq!(doc.globals[2].value, Value::Int(-7));
        assert_eq!(doc.items.len(), 3);
        match &doc.items[0] {
            Item::Table { name, entries } => {
                assert_eq!(name, "depends");
                assert_eq!(entries.len(), 1);
            }
            other => panic!("expected a table, got {other:?}"),
        }
        let arrays = doc
            .items
            .iter()
            .filter(|i| matches!(i, Item::ArrayTable { .. }))
            .count();
        assert_eq!(arrays, 2, "two [[packages]] instances accumulate");
    }

    #[test]
    fn string_escapes_round_trip() {
        let doc = parse("k = \"a\\\"b\\\\c\"").expect("escapes parse");
        assert_eq!(doc.globals[0].value, Value::Str("a\"b\\c".to_string()));
    }

    #[test]
    fn unclosed_string_rejected_with_position() {
        let err = parse("k = \"oops").expect_err("the unclosed string must fail");
        assert_eq!(err.line, 1);
        assert!(err.message.contains("unclosed string literal"));
    }

    #[test]
    fn invalid_escape_rejected() {
        let err = parse("k = \"a\\x\"").expect_err("the invalid escape must fail");
        assert!(err.message.contains("invalid escape"));
    }

    #[test]
    fn duplicate_global_key_rejected() {
        let err = parse("a = 1\na = 2").expect_err("the duplicate key must fail");
        assert_eq!(err.line, 2);
        assert!(err.message.contains("duplicate key \"a\""));
    }

    #[test]
    fn duplicate_section_key_rejected() {
        let err = parse("[s]\na = 1\na = 2").expect_err("the duplicate must fail");
        assert_eq!(err.line, 3);
    }

    #[test]
    fn same_key_across_sections_allowed() {
        parse("[s1]\na = 1\n[s2]\na = 2").expect("distinct sections may share a key");
    }

    #[test]
    fn bool_value_rejected_as_out_of_subset() {
        let err = parse("k = true").expect_err("the bool literal must fail");
        assert!(err.message.contains("not in the micro subset"));
    }

    #[test]
    fn float_value_rejected_as_out_of_subset() {
        let err = parse("k = 1.5").expect_err("the float literal must fail");
        assert!(err.message.contains("not in the micro subset"));
    }

    #[test]
    fn malformed_section_header_rejected() {
        let err = parse("[unclosed").expect_err("the unclosed header must fail");
        assert!(err.message.contains("missing \"]\""));
    }

    #[test]
    fn empty_section_name_rejected() {
        let err = parse("[]").expect_err("the empty name must fail");
        assert!(err.message.contains("empty section name"));
    }

    #[test]
    fn trailing_garbage_after_value_rejected() {
        let err = parse("k = 1 junk").expect_err("content after the value must fail");
        assert!(err.message.contains("trailing content after value"));
    }

    #[test]
    fn missing_equals_rejected() {
        let err = parse("just-a-word").expect_err("the bare word must fail");
        assert!(err.message.contains("expected `key = value`"));
    }

    #[test]
    fn empty_key_rejected() {
        let err = parse(" = 1").expect_err("the empty key must fail");
        assert!(err.message.contains("empty key"));
    }
}

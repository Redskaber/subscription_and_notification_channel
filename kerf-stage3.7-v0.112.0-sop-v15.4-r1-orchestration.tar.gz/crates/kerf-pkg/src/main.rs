//! `kp` — the kerf package tool (W-3.10 driver face).
//!
//! Hand-rolled argument parsing (SOP §18 — no external deps). The one
//! v0 command:
//!
//! ```text
//! kp resolve <dir>    resolve the package graph at <dir>,
//!                     print the topological order, write <dir>/kerf.lock
//! ```

use kerf_pkg::{Lockfile, RESOLUTION_DEPTH_LIMIT, resolve_with_limit};
use std::path::Path;
use std::process::ExitCode;

fn main() -> ExitCode {
    let args: Vec<String> = std::env::args().skip(1).collect();
    match args.as_slice() {
        [cmd, dir] if cmd == "resolve" => run_resolve(Path::new(dir)),
        [flag] if flag == "--help" || flag == "-h" || flag == "help" => {
            print_usage();
            ExitCode::SUCCESS
        }
        _ => {
            print_usage();
            ExitCode::FAILURE
        }
    }
}

/// The depth-guardrail override of the resolver (the K162 face of
/// the W-REC-DEPTH blade 2, the `kp` twin of the compiler CLI's
/// `DepthLimits::from_env`): unset keeps the conservative default;
/// a set value must be a positive integer or the run aborts
/// (fail-closed).
fn resolve_depth_from_env() -> Result<u32, String> {
    match std::env::var("KERF_PKG_RESOLVE_DEPTH_LIMIT") {
        Ok(raw) => match raw.parse::<u32>() {
            Ok(n) if n > 0 => Ok(n),
            _ => Err(format!(
                "invalid value for KERF_PKG_RESOLVE_DEPTH_LIMIT: `{raw}` (expected a positive integer)"
            )),
        },
        Err(std::env::VarError::NotPresent) => Ok(RESOLUTION_DEPTH_LIMIT),
        Err(std::env::VarError::NotUnicode(raw)) => Err(format!(
            "invalid value for KERF_PKG_RESOLVE_DEPTH_LIMIT: `{}` (expected a positive integer)",
            raw.to_string_lossy()
        )),
    }
}

fn run_resolve(dir: &Path) -> ExitCode {
    let depth_limit = match resolve_depth_from_env() {
        Ok(limit) => limit,
        Err(message) => {
            eprintln!("kp: {message}");
            return ExitCode::FAILURE;
        }
    };
    match resolve_with_limit(dir, depth_limit) {
        Ok(resolution) => {
            for pkg in &resolution.order {
                println!("{} {} ({})", pkg.name, pkg.version, pkg.source);
            }
            match write_lockfile(dir, &resolution.lockfile) {
                Ok(()) => {
                    println!(
                        "wrote {} ({} package{})",
                        dir.join("kerf.lock").display(),
                        resolution.lockfile.packages.len(),
                        if resolution.lockfile.packages.len() == 1 {
                            ""
                        } else {
                            "s"
                        }
                    );
                    ExitCode::SUCCESS
                }
                Err(err) => {
                    eprintln!("kp: {err}");
                    ExitCode::FAILURE
                }
            }
        }
        Err(err) => {
            eprintln!("kp: {err}");
            ExitCode::FAILURE
        }
    }
}

/// Write the lockfile next to the root manifest (deterministic text).
fn write_lockfile(dir: &Path, lockfile: &Lockfile) -> Result<(), kerf_pkg::PkgError> {
    let path = dir.join("kerf.lock");
    std::fs::write(&path, lockfile.to_text()).map_err(|e| kerf_pkg::PkgError::Io {
        op: "write lockfile".to_string(),
        source: e.to_string(),
    })
}

fn print_usage() {
    println!("usage: kp resolve <dir>");
    println!("  resolve the package graph at <dir> and write <dir>/kerf.lock");
}

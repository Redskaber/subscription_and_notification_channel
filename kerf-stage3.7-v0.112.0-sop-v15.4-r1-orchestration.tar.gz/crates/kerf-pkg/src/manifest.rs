//! The `kerf.toml` manifest projection (PKG-1).
//!
//! Schema (fail-closed — every unknown key or section is an error):
//!
//! ```text
//! # kerf package manifest
//! package = "math-utils"
//! version = "0.1.0"
//!
//! [depends]
//! core-bits = "0.2"        # caret requirement
//! strings = "0.1.5"
//! ```

use crate::error::PkgError;
use crate::micro_toml::{self, Document, Item, Value};
use crate::semver::{Constraint, Version};
use std::collections::BTreeMap;

/// A parsed package manifest.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Manifest {
    /// The package name (kebab-case).
    pub package: String,
    /// The exact package version.
    pub version: Version,
    /// Dependencies: name -> caret requirement (sorted by name).
    pub depends: BTreeMap<String, Constraint>,
}

impl Manifest {
    /// Parse and project a manifest document.
    pub fn from_document(file: &str, doc: &Document) -> Result<Self, PkgError> {
        let mut package: Option<(String, u32)> = None;
        let mut version: Option<(String, u32)> = None;
        let mut depends: BTreeMap<String, Constraint> = BTreeMap::new();

        for entry in &doc.globals {
            match entry.key.as_str() {
                "package" => {
                    let Value::Str(name) = &entry.value else {
                        return Err(PkgError::ManifestInvalid {
                            file: file.to_string(),
                            line: Some(entry.line),
                            message: "\"package\" must be a string".to_string(),
                        });
                    };
                    validate_package_name(file, entry.line, name)?;
                    package = Some((name.clone(), entry.line));
                }
                "version" => {
                    let Value::Str(text) = &entry.value else {
                        return Err(PkgError::ManifestInvalid {
                            file: file.to_string(),
                            line: Some(entry.line),
                            message: "\"version\" must be a string".to_string(),
                        });
                    };
                    version = Some((text.clone(), entry.line));
                }
                key => {
                    return Err(PkgError::ManifestInvalid {
                        file: file.to_string(),
                        line: Some(entry.line),
                        message: format!("unknown manifest key \"{key}\""),
                    });
                }
            }
        }

        let (package_name, package_line) = package.ok_or_else(|| PkgError::ManifestInvalid {
            file: file.to_string(),
            line: None,
            message: "missing required key \"package\"".to_string(),
        })?;
        let (version_text, version_line) = version.ok_or_else(|| PkgError::ManifestInvalid {
            file: file.to_string(),
            line: None,
            message: "missing required key \"version\"".to_string(),
        })?;
        let version = Version::parse(&version_text).map_err(|e| PkgError::ManifestInvalid {
            file: file.to_string(),
            line: Some(version_line),
            message: e.to_string(),
        })?;

        for item in &doc.items {
            match item {
                Item::Table { name, entries } if name == "depends" => {
                    for entry in entries {
                        let Value::Str(constraint_text) = &entry.value else {
                            return Err(PkgError::ManifestInvalid {
                                file: file.to_string(),
                                line: Some(entry.line),
                                message: format!(
                                    "dependency \"{}\" must carry a string constraint",
                                    entry.key
                                ),
                            });
                        };
                        validate_package_name(file, entry.line, &entry.key)?;
                        let constraint = Constraint::parse(constraint_text).map_err(|e| {
                            PkgError::ManifestInvalid {
                                file: file.to_string(),
                                line: Some(entry.line),
                                message: format!("dependency \"{}\": {e}", entry.key),
                            }
                        })?;
                        depends.insert(entry.key.clone(), constraint);
                    }
                }
                Item::Table { name, .. } => {
                    return Err(PkgError::ManifestInvalid {
                        file: file.to_string(),
                        line: None,
                        message: format!("unknown manifest section \"{name}\""),
                    });
                }
                Item::ArrayTable { name, .. } => {
                    return Err(PkgError::ManifestInvalid {
                        file: file.to_string(),
                        line: None,
                        message: format!("unknown manifest section \"[[{name}]]\""),
                    });
                }
            }
        }

        let _ = package_line;
        Ok(Manifest {
            package: package_name,
            version,
            depends,
        })
    }

    /// Parse manifest text directly.
    pub fn parse(file: &str, text: &str) -> Result<Self, PkgError> {
        let doc = micro_toml::parse(text).map_err(|e| PkgError::Syntax {
            file: file.to_string(),
            line: e.line,
            col: e.col,
            message: e.message,
        })?;
        Self::from_document(file, &doc)
    }
}

/// Package names share the module-name discipline (kebab-case, lowercase
/// ASCII letters, digits, and `-`, starting with a letter — K102-K106).
fn validate_package_name(file: &str, line: u32, name: &str) -> Result<(), PkgError> {
    let valid = !name.is_empty()
        && name.starts_with(|c: char| c.is_ascii_lowercase())
        && name
            .chars()
            .all(|c| c.is_ascii_lowercase() || c.is_ascii_digit() || c == '-');
    if valid {
        Ok(())
    } else {
        Err(PkgError::ManifestInvalid {
            file: file.to_string(),
            line: Some(line),
            message: format!(
                "package name \"{name}\" must be kebab-case (lowercase letters, digits, `-`)"
            ),
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn valid_manifest_projects_every_field() {
        let m = Manifest::parse(
            "kerf.toml",
            "package = \"math-utils\"\nversion = \"0.1.0\"\n\n[depends]\ncore-bits = \"0.2\"\nstrings = \"0.1.5\"\n",
        )
        .expect("the valid manifest parses");
        assert_eq!(m.package, "math-utils");
        assert_eq!(
            m.version,
            Version {
                major: 0,
                minor: 1,
                patch: 0
            }
        );
        assert_eq!(m.depends.len(), 2);
        assert_eq!(m.depends["strings"].to_string(), "0.1.5");
    }

    #[test]
    fn manifest_without_depends_is_valid() {
        let m = Manifest::parse("kerf.toml", "package = \"p\"\nversion = \"0.1.0\"\n")
            .expect("depends is optional");
        assert!(m.depends.is_empty());
    }

    #[test]
    fn missing_version_rejected() {
        let err = Manifest::parse("kerf.toml", "package = \"p\"\n")
            .expect_err("the missing version must fail");
        assert!(err.to_string().contains("missing required key \"version\""));
    }

    #[test]
    fn non_string_package_rejected() {
        let err = Manifest::parse("kerf.toml", "package = 3\nversion = \"0.1.0\"\n")
            .expect_err("the integer package name must fail");
        assert!(err.to_string().contains("\"package\" must be a string"));
    }

    #[test]
    fn uppercase_package_name_rejected() {
        let err = Manifest::parse("kerf.toml", "package = \"MyPkg\"\nversion = \"0.1.0\"\n")
            .expect_err("the non-kebab name must fail");
        assert!(err.to_string().contains("kebab-case"));
    }

    #[test]
    fn bad_dependency_name_rejected() {
        let err = Manifest::parse(
            "kerf.toml",
            "package = \"p\"\nversion = \"0.1.0\"\n\n[depends]\nBad = \"0.1\"\n",
        )
        .expect_err("the uppercase dependency name must fail");
        assert!(err.to_string().contains("kebab-case"));
    }

    #[test]
    fn unknown_section_rejected() {
        let err = Manifest::parse(
            "kerf.toml",
            "package = \"p\"\nversion = \"0.1.0\"\n\n[features]\nx = \"y\"\n",
        )
        .expect_err("the unknown section must fail");
        assert!(
            err.to_string()
                .contains("unknown manifest section \"features\"")
        );
    }

    #[test]
    fn array_section_rejected() {
        let err = Manifest::parse(
            "kerf.toml",
            "package = \"p\"\nversion = \"0.1.0\"\n\n[[bins]]\nname = \"x\"\n",
        )
        .expect_err("the array section must fail");
        assert!(
            err.to_string()
                .contains("unknown manifest section \"[[bins]]\"")
        );
    }

    #[test]
    fn non_string_constraint_rejected() {
        let err = Manifest::parse(
            "kerf.toml",
            "package = \"p\"\nversion = \"0.1.0\"\n\n[depends]\na = 2\n",
        )
        .expect_err("the integer constraint must fail");
        assert!(err.to_string().contains("must carry a string constraint"));
    }
}

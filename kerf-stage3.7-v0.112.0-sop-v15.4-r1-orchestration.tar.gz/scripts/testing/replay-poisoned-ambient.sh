#!/usr/bin/env bash
# scripts/testing/replay-poisoned-ambient.sh — the v0.73.0 incident replay.
#
# The toolchain-pairing incident class (stage0.md §9.92 hygiene addendum):
# an ambient dev-shell can carry contaminant variables that pair the
# emitted binary's dynamic loader with a foreign libc. The c_backend e2e
# boundaries (tests/v1/stage1/plan/c_backend_e2e_tests.rs) scrub exactly
# the link-side and load-side contaminant sets; this replay runs the whole
# c_backend suite under a poisoned AMBIENT environment — the environment
# shape of the original incident — and must stay green.
#
# Scope note: the ambient poison covers the link-side variables only
# (LIBRARY_PATH/CPATH/C_INCLUDE_PATH/CPLUS_INCLUDE_PATH). A garbage libc
# on ambient LD_LIBRARY_PATH would kill the test runner's own load, so
# the load-side protection is pinned in-suite instead: the scrub
# registration face plus the poison-lethality negative control.
#
# Usage: bash scripts/testing/replay-poisoned-ambient.sh [runner filter args]
set -euo pipefail

root="$(cd "$(dirname "$0")/../.." && pwd)"
poison="$root/target/cbackend-e2e/ambient-poison"
mkdir -p "$poison"
printf 'poisoned header\n' > "$poison/stdio.h"
printf 'poisoned libc\n'  > "$poison/libc.so.6"

cd "$root"
build_log="$(mktemp)"
trap 'rm -f "$build_log"' EXIT
cargo test --release -p kerf --test runner --no-run > "$build_log" 2>&1
runner="$(grep -oE 'target/release/deps/runner-[0-9a-f]+' "$build_log" | head -1)"
if [ -z "$runner" ] || [ ! -x "$root/$runner" ]; then
    echo "replay: cannot locate the runner binary" >&2
    exit 1
fi

echo "replay: running $runner under the poisoned ambient (link-side set)"
env \
  LIBRARY_PATH="$poison" \
  CPATH="$poison" \
  C_INCLUDE_PATH="$poison" \
  CPLUS_INCLUDE_PATH="$poison" \
  "$root/$runner" c_backend "$@"

# scripts/ — 环境/构建/部署脚本（SOP §3.4）

按 `<domain>/` 子目录组织；自定义安装/配置脚本归档于此并同步 docs/scripts/。

## testing/

- `replay-poisoned-ambient.sh` — v0.73.0 工具链配对事件重放（r110）：在被污染 ambient 环境变量下运行 c_backend e2e 套件，断言双边界 scrub 防护在位（18:0:2 全绿为通过口径）。文档：`docs/scripts/replay-poisoned-ambient.md`。

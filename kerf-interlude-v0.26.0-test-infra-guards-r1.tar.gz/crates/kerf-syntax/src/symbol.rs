//! Surface-syntax identifier symbol: validated, opaque, cheap to compare.
//!
//! Since v0.23.0 the payload is an interned index (stage0.md §9.52):
//! [`StxSymbol::new`] validates the floor, then interns the text in a
//! process-global interner owned by this layer. Equality, hashing, and
//! cloning are index operations; `as_str` and `Display` resolve the text
//! through the same interner. Interned text lives for the process
//! lifetime by design (the classic interner tradeoff, §9.52.3).

use std::collections::HashMap;
use std::fmt;
use std::num::NonZeroU32;
use std::sync::{Mutex, OnceLock};

use crate::error::SyntaxError;

/// The interning table: text-to-index and index-to-text.
///
/// Strings are leaked on first intern so `as_str` can hand out text
/// without holding the lock beyond the lookup itself (the matklad-style
/// simple interner — stage0.md §9.52.2 K54 anchor).
struct Interner {
    map: HashMap<&'static str, NonZeroU32>,
    strings: Vec<&'static str>,
}

static INTERNER: OnceLock<Mutex<Interner>> = OnceLock::new();

/// Intern `text` (already validated by [`StxSymbol::new`]).
fn intern(text: &str) -> StxSymbol {
    let mut table = INTERNER
        .get_or_init(|| {
            Mutex::new(Interner {
                map: HashMap::new(),
                strings: Vec::new(),
            })
        })
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner());
    if let Some(&index) = table.map.get(text) {
        return StxSymbol { index };
    }
    let leaked: &'static str = Box::leak(text.to_owned().into_boxed_str());
    let index = u32::try_from(table.strings.len() + 1)
        .ok()
        .and_then(NonZeroU32::new)
        .expect("symbol index space of 2^32 - 1 exhausted");
    table.strings.push(leaked);
    table.map.insert(leaked, index);
    StxSymbol { index }
}

/// An identifier atom inside a [`StxDatum`](crate::expr::StxDatum).
///
/// The payload is private on purpose (docs/stage0.md §7.4.2 principle 1 —
/// type safety over naming safety): the only construction path is the
/// checked [`StxSymbol::new`], so a symbol found inside a datum is always
/// structurally valid.
///
/// The floor is identical to `kerf_core::Symbol`'s (non-empty, no
/// whitespace, no control characters — a conservative floor, not a
/// grammar; the full identifier grammar lands with the 0.3 reader).
/// This is a pipeline-phase twin, not a duplicate type: the surface
/// identifier and the core symbol live at different pipeline layers
/// (skeleton vs core AST) and never share a definition — the 0.4
/// expander crosses the boundary as source text through the core
/// validated `&str` constructors, so "anything the reader accepts must
/// pass both floors" holds by identical validation, not by a shared type
/// (SOP §21.12-5 single-definition rule scopes to cross-stage *shared*
/// types; the DAG keeps L1 and L4 independent — docs/graph/stage-0/
/// dataflow.md). Since v0.23.0 the twin discipline extends to the
/// interning pools: each layer owns its own global interner and the
/// layers never share indices (stage0.md §9.52.4).
///
/// Ordering note (v0.23.0): [`Ord`] is derived from the intern index
/// (first-intern order), not lexicographic text order; the tree is
/// audited to have no ordering consumer (stage0.md §9.52.4).
#[derive(Clone, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct StxSymbol {
    index: NonZeroU32,
}

impl StxSymbol {
    /// Checked constructor.
    ///
    /// Rejects empty text and any character that is whitespace or a
    /// control character, then interns the text. Returns
    /// [`SyntaxError::InvalidSymbol`] on rejection; rejected text is
    /// never interned.
    pub fn new(text: &str) -> Result<Self, SyntaxError> {
        if text.is_empty() {
            return Err(SyntaxError::InvalidSymbol {
                text: text.to_owned(),
            });
        }
        if text.chars().any(|c| c.is_whitespace() || c.is_control()) {
            return Err(SyntaxError::InvalidSymbol {
                text: text.to_owned(),
            });
        }
        Ok(intern(text))
    }

    /// The identifier text (guaranteed valid by construction).
    pub fn as_str(&self) -> &str {
        let table = INTERNER
            .get()
            .expect("interner exists once any symbol was constructed")
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner());
        table.strings[self.index.get() as usize - 1]
    }
}

impl fmt::Display for StxSymbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.as_str())
    }
}

impl fmt::Debug for StxSymbol {
    // Hand-written to keep the exact pre-interning derived shape
    // `StxSymbol { text: "x" }`: goldens stay byte-identical across the
    // representation change and the output stays index-independent.
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("StxSymbol")
            .field("text", &self.as_str())
            .finish()
    }
}

#[cfg(test)]
mod tests {
    //! Unit tests for the StxSymbol feature point; ratio mirrors the
    //! sub-stage test doc (docs/tests/v0/stage0/plan/syntax.md, FP1).
    //! CJK fixture note (SOP §10.5 registered whitelist): the
    //! `valid_symbols_accept_unicode_cjk` case uses CJK *as the tested
    //! object* (identifier floor acceptance), which is the sanctioned
    //! fixture category.

    use super::*;

    // ---------- positive ----------

    #[test]
    fn valid_symbols_roundtrip() {
        for text in [
            "x",
            "snake_case_x1",
            "+",
            "x!",
            "?value",
            "a1b2",
            "nil?",
            "set!",
        ] {
            let symbol = StxSymbol::new(text).expect("floor-valid name must construct");
            assert_eq!(symbol.as_str(), text);
            assert_eq!(symbol.to_string(), text);
        }
        let a = StxSymbol::new("alpha").unwrap();
        let b = StxSymbol::new("alpha").unwrap();
        assert_eq!(a, b);
        assert_ne!(a, StxSymbol::new("beta").unwrap());
    }

    #[test]
    fn valid_symbols_accept_unicode_cjk() {
        // The floor must not constrain the future reader grammar: CJK
        // identifiers stay legal until the 0.3 grammar rules on them.
        let symbol = StxSymbol::new("计数器").expect("CJK identifier passes the floor");
        assert_eq!(symbol.as_str(), "计数器");
    }

    #[test]
    fn same_text_interns_to_one_identity() {
        // Two constructions through distinct string paths must land on
        // one interned identity (the mirror of the core-layer probe —
        // twin discipline covers the interning face too).
        let a = StxSymbol::new("identity-probe").unwrap();
        let b = StxSymbol::new(&format!("identity-{}", "probe")).unwrap();
        assert_eq!(a, b);
        assert_ne!(a, StxSymbol::new("identity-prob").unwrap());
    }

    #[test]
    fn as_str_roundtrips_across_many_interns() {
        let keep = StxSymbol::new("keep-me").unwrap();
        for i in 0..64 {
            StxSymbol::new(&format!("crowd-{i}")).unwrap();
        }
        assert_eq!(keep.as_str(), "keep-me");
        assert_eq!(StxSymbol::new("keep-me").unwrap().as_str(), "keep-me");
    }

    #[test]
    fn debug_shape_is_text_based_and_stable() {
        let symbol = StxSymbol::new("probe").unwrap();
        assert_eq!(format!("{symbol:?}"), r#"StxSymbol { text: "probe" }"#);
    }

    #[test]
    fn option_symbol_keeps_niche_layout() {
        assert_eq!(
            std::mem::size_of::<Option<StxSymbol>>(),
            std::mem::size_of::<StxSymbol>()
        );
    }

    // ---------- negative ----------

    #[test]
    fn new_rejects_empty() {
        let err = StxSymbol::new("").expect_err("empty symbol must be rejected");
        assert_eq!(
            err,
            SyntaxError::InvalidSymbol {
                text: String::new()
            }
        );
    }

    #[test]
    fn new_rejects_space_only() {
        assert!(matches!(
            StxSymbol::new(" "),
            Err(SyntaxError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn new_rejects_interior_space() {
        assert!(matches!(
            StxSymbol::new("a b"),
            Err(SyntaxError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn new_rejects_interior_tab() {
        assert!(matches!(
            StxSymbol::new("a\tb"),
            Err(SyntaxError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn new_rejects_leading_space() {
        assert!(matches!(
            StxSymbol::new(" x"),
            Err(SyntaxError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn new_rejects_trailing_space() {
        assert!(matches!(
            StxSymbol::new("x "),
            Err(SyntaxError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn new_rejects_nul_control() {
        assert!(matches!(
            StxSymbol::new("a\u{0}b"),
            Err(SyntaxError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn new_rejects_unicode_whitespace() {
        // Unicode whitespace (NBSP) is whitespace for the floor too —
        // `char::is_whitespace` is Unicode-aware.
        assert!(matches!(
            StxSymbol::new("a\u{a0}b"),
            Err(SyntaxError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn rejected_text_leaves_valid_construction_unchanged() {
        // A rejection must not intern the text nor disturb the pool.
        assert!(StxSymbol::new("bad text").is_err());
        let after = StxSymbol::new("after-reject").unwrap();
        assert_eq!(after.as_str(), "after-reject");
    }
}

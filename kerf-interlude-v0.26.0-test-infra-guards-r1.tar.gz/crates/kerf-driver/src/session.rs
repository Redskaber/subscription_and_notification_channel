//! Session and file interning (charter item, stage-0-plan row 0.8).
//!
//! The session owns every source text the driver ever touches and the
//! name <-> [`FileId`] mapping. Ids are handed out sequentially from
//! zero (deterministic — SOP §2.3-3); re-interning a known name keeps
//! the id and replaces the source (upsert semantics — the REPL
//! re-reads one growing file per submission, and diagnostics must
//! always render against the *current* text).
//!
//! The session is the single source of truth for diagnostic rendering
//! (SOP §2.3-2): renderers ask the session for file names, source
//! texts, and line indexes, never the callers. Each file's
//! [`LineIndex`] is built once at intern (and rebuilt on REPL upsert)
//! — §9.56 DIAG-4: the rustc source-map shape (line starts cached per
//! file), not a fresh O(source) rebuild per rendered diagnostic.

use kerf_compiler::{FileId, Span};

use crate::line_index::LineIndex;

/// One interned file: a display name, its current source text, and
/// the render-time line index derived from that text.
#[derive(Debug)]
struct FileEntry {
    name: String,
    source: String,
    index: LineIndex,
}

/// The driver session: file interning plus source storage.
#[derive(Debug, Default)]
pub struct Session {
    entries: Vec<FileEntry>,
}

impl Session {
    /// An empty session (no files interned).
    pub fn new() -> Self {
        Session {
            entries: Vec::new(),
        }
    }

    /// Intern a file: first sight allocates the next sequential
    /// [`FileId`]; a known name keeps its id and has its source
    /// replaced (upsert — REPL re-reads are idempotent).
    pub fn intern(&mut self, name: impl Into<String>, source: impl Into<String>) -> FileId {
        let name = name.into();
        let source = source.into();
        match self.entries.iter().position(|e| e.name == name) {
            Some(idx) => {
                let entry = &mut self.entries[idx];
                entry.index = LineIndex::new(&source);
                entry.source = source;
                FileId(idx as u32)
            }
            None => {
                let index = LineIndex::new(&source);
                self.entries.push(FileEntry {
                    name,
                    source,
                    index,
                });
                FileId((self.entries.len() - 1) as u32)
            }
        }
    }

    /// The display name of an interned file, or `None` for an id this
    /// session never handed out (fail-closed: no silent fallback name).
    pub fn file_name(&self, id: FileId) -> Option<&str> {
        self.entries.get(id.0 as usize).map(|e| e.name.as_str())
    }

    /// The current source text of an interned file, or `None` for an
    /// unknown id.
    pub fn source(&self, id: FileId) -> Option<&str> {
        self.entries.get(id.0 as usize).map(|e| e.source.as_str())
    }

    /// The cached line index of an interned file (built at intern,
    /// rebuilt on upsert), or `None` for an unknown id. §9.56 DIAG-4.
    pub fn line_index(&self, id: FileId) -> Option<&LineIndex> {
        self.entries.get(id.0 as usize).map(|e| &e.index)
    }

    /// The number of interned files (ids `0..len` are all valid).
    pub fn len(&self) -> usize {
        self.entries.len()
    }

    /// Whether no file has been interned yet.
    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    /// Whether `span`'s file belongs to this session (used by the
    /// diagnostic constructor to keep the span and the `file` field
    /// from disagreeing).
    pub fn knows(&self, span: &Span) -> bool {
        (span.file_id.0 as usize) < self.entries.len()
    }
}

#[cfg(test)]
mod tests {
    //! Session interning tests (FP1): sequential ids, upsert identity,
    //! lookup round-trips, fail-closed unknown ids.

    use super::*;

    #[test]
    fn first_intern_allocates_sequential_ids() {
        let mut s = Session::new();
        assert!(s.is_empty());
        let a = s.intern("a.krf", "(define x 1)");
        let b = s.intern("b.krf", "(define y 2)");
        assert_eq!(a, FileId(0));
        assert_eq!(b, FileId(1));
        assert_eq!(s.len(), 2);
    }

    #[test]
    fn reintern_keeps_id_and_replaces_source() {
        let mut s = Session::new();
        let id = s.intern("repl", "(define x 1)");
        let again = s.intern("repl", "(define x 1)\n(define y 2)");
        assert_eq!(id, again, "upsert must keep the id");
        assert_eq!(s.len(), 1, "upsert must not allocate a new entry");
        assert_eq!(s.source(id), Some("(define x 1)\n(define y 2)"));
    }

    #[test]
    fn name_and_source_round_trip() {
        let mut s = Session::new();
        let id = s.intern("main.krf", "(+ 1 2)");
        assert_eq!(s.file_name(id), Some("main.krf"));
        assert_eq!(s.source(id), Some("(+ 1 2)"));
    }

    #[test]
    fn unknown_ids_fail_closed() {
        let s = Session::new();
        assert_eq!(s.file_name(FileId(0)), None);
        assert_eq!(s.source(FileId(0)), None);
        assert_eq!(s.file_name(FileId(999)), None);
    }

    #[test]
    fn reintern_after_growth_still_targets_the_right_entry() {
        let mut s = Session::new();
        let a = s.intern("a.krf", "1");
        let _b = s.intern("b.krf", "2");
        let c = s.intern("c.krf", "3");
        let a2 = s.intern("a.krf", "one");
        assert_eq!(a, a2);
        assert_eq!(s.source(c), Some("3"));
        assert_eq!(s.source(a2), Some("one"));
        assert_eq!(s.len(), 3);
    }

    #[test]
    fn line_index_cache_matches_fresh_build_and_rebuilds_on_upsert() {
        // §9.56 DIAG-4: the cached index is byte-for-byte the fresh
        // derivation, and a REPL upsert rebuilds it against the new
        // text (stale indexes would mis-render positions).
        let mut s = Session::new();
        let id = s.intern("main.krf", "(define x 1)\n(+ x 2)");
        let cached = s.line_index(id).expect("index interned");
        let fresh = LineIndex::new("(define x 1)\n(+ x 2)");
        assert_eq!(*cached, fresh);
        assert_eq!(cached.line_count(), 2);

        let _ = s.intern("main.krf", "one\ntwo\nthree");
        let rebuilt = s.line_index(id).expect("index after upsert");
        assert_eq!(rebuilt.line_count(), 3, "upsert rebuilds the index");
        assert_eq!(rebuilt.line_bounds(2), Some((8, 13)));

        assert_eq!(s.line_index(FileId(9)), None, "unknown ids fail closed");
    }
}

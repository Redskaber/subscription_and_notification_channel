//! Identifier symbol: validated, opaque, cheap to compare.
//!
//! Since v0.23.0 the payload is an interned index (stage0.md §9.52):
//! [`Symbol::new`] validates the floor, then interns the text in a
//! process-global interner (the rustc-style `Symbol = interned u32`
//! shape — stage0.md §9.44.3 K6 anchor). Equality, hashing, and cloning
//! are index operations; `as_str` and `Display` resolve the text through
//! the same interner. Interned text lives for the process lifetime by
//! design — a compiler-side identity pool that is never freed (the
//! classic interner tradeoff, recorded in stage0.md §9.52.3).

use std::collections::HashMap;
use std::fmt;
use std::num::NonZeroU32;
use std::sync::{Mutex, OnceLock};

use crate::error::CoreError;

/// The interning table: text-to-index and index-to-text.
///
/// Strings are leaked on first intern, so the map keys are genuine
/// `&'static str` and `as_str` can hand out text without holding the
/// lock beyond the lookup itself (the matklad-style simple interner —
/// stage0.md §9.52.2 K54 anchor). One mutex serializes intern and
/// resolve; kerf compiles single-threaded per process, so contention
/// is not a design face (measured in-band on the B-series baselines).
struct Interner {
    map: HashMap<&'static str, NonZeroU32>,
    strings: Vec<&'static str>,
}

static INTERNER: OnceLock<Mutex<Interner>> = OnceLock::new();

/// Intern `text` (already validated by [`Symbol::new`]).
fn intern(text: &str) -> Symbol {
    let mut table = INTERNER
        .get_or_init(|| {
            Mutex::new(Interner {
                map: HashMap::new(),
                strings: Vec::new(),
            })
        })
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner());
    if let Some(&index) = table.map.get(text) {
        return Symbol { index };
    }
    let leaked: &'static str = Box::leak(text.to_owned().into_boxed_str());
    let index = u32::try_from(table.strings.len() + 1)
        .ok()
        .and_then(NonZeroU32::new)
        .expect("symbol index space of 2^32 - 1 exhausted");
    table.strings.push(leaked);
    table.map.insert(leaked, index);
    Symbol { index }
}

/// An identifier name inside a `CoreExpr` node (parameter, variable,
/// effect, module item, ...).
///
/// The payload is private on purpose (docs/stage0.md §7.4.2 principle 1 —
/// type safety over naming safety): the only construction path is the
/// checked [`Symbol::new`], so a `Symbol` found inside a node is always
/// structurally valid.
///
/// Validation is a conservative floor, not a grammar: non-empty, no
/// whitespace, no control characters. The full identifier grammar lands
/// with the reader (plan sub-stage 0.3); anything the reader accepts must
/// pass this floor, and the floor deliberately keeps non-ASCII (e.g. CJK)
/// names legal so the future grammar is not constrained.
///
/// Ordering note (v0.23.0): [`Ord`] is derived from the intern index
/// (first-intern order), not lexicographic text order. The whole tree is
/// audited to have no ordering consumer — every `sort` site sorts
/// `String`/`&str` values and no `BTreeMap<Symbol, _>` exists
/// (stage0.md §9.52.4 ripple audit) — and the impl is kept only because
/// the frozen public API surface already promised it. New code must not
/// rely on lexicographic semantics.
#[derive(Clone, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct Symbol {
    index: NonZeroU32,
}

impl Symbol {
    /// Checked constructor.
    ///
    /// Rejects empty text and any character that is whitespace or a
    /// control character, then interns the text. Returns
    /// [`CoreError::InvalidSymbol`] on rejection; rejected text is
    /// never interned.
    pub fn new(text: &str) -> Result<Self, CoreError> {
        if text.is_empty() {
            return Err(CoreError::InvalidSymbol {
                text: text.to_owned(),
            });
        }
        if text.chars().any(|c| c.is_whitespace() || c.is_control()) {
            return Err(CoreError::InvalidSymbol {
                text: text.to_owned(),
            });
        }
        Ok(intern(text))
    }

    /// The identifier text (guaranteed valid by construction).
    pub fn as_str(&self) -> &str {
        let table = INTERNER
            .get()
            .expect("interner exists once any symbol was constructed")
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner());
        table.strings[self.index.get() as usize - 1]
    }
}

impl fmt::Display for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.as_str())
    }
}

impl fmt::Debug for Symbol {
    // Hand-written to keep the exact pre-interning derived shape
    // `Symbol { text: "x" }`: goldens and diagnostics stay
    // byte-identical across the representation change, and the output
    // stays index-independent (stable regardless of intern order).
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Symbol")
            .field("text", &self.as_str())
            .finish()
    }
}

#[cfg(test)]
mod tests {
    //! Unit tests for the Symbol feature point; ratio mirrors the sub-stage
    //! test doc (docs/tests/v0/stage0/plan/core.md, FP1).
    //! CJK fixture note (SOP §10.5 registered whitelist): the
    //! `valid_symbols_accept_unicode_cjk` case uses CJK *as the tested
    //! object* (identifier floor acceptance), which is the sanctioned
    //! fixture category.

    use super::*;

    // ---------- positive ----------

    #[test]
    fn valid_symbols_roundtrip() {
        for text in ["x", "snake_case_x1", "+", "x!", "?value", "a1b2"] {
            let symbol = Symbol::new(text).expect("floor-valid name must construct");
            assert_eq!(symbol.as_str(), text);
            assert_eq!(symbol.to_string(), text);
        }
    }

    #[test]
    fn valid_symbols_accept_unicode_cjk() {
        // The floor must not constrain the future reader grammar: CJK
        // identifiers stay legal until the 0.3 grammar rules on them.
        let symbol = Symbol::new("计数器").expect("CJK identifier passes the floor");
        assert_eq!(symbol.as_str(), "计数器");
    }

    #[test]
    fn symbol_equality_and_hash_follow_text() {
        use std::collections::hash_map::DefaultHasher;
        use std::hash::{Hash, Hasher};

        let a = Symbol::new("alpha").unwrap();
        let b = Symbol::new("alpha").unwrap();
        let c = Symbol::new("beta").unwrap();
        assert_eq!(a, b);
        assert_ne!(a, c);

        let hash = |s: &Symbol| {
            let mut hasher = DefaultHasher::new();
            s.hash(&mut hasher);
            hasher.finish()
        };

        assert_eq!(hash(&a), hash(&b));
    }

    #[test]
    fn same_text_interns_to_one_identity() {
        // Two constructions through distinct string paths must land on
        // one interned identity: equality and hash are index-backed.
        use std::collections::hash_map::DefaultHasher;
        use std::hash::{Hash, Hasher};

        let a = Symbol::new("identity-probe").unwrap();
        let b = Symbol::new(&format!("identity-{}", "probe")).unwrap();
        assert_eq!(a, b);

        let hash = |s: &Symbol| {
            let mut hasher = DefaultHasher::new();
            s.hash(&mut hasher);
            hasher.finish()
        };
        assert_eq!(hash(&a), hash(&b));
        assert_ne!(a, Symbol::new("identity-prob").unwrap());
    }

    #[test]
    fn as_str_roundtrips_across_many_interns() {
        // A crowd of later interning must not disturb earlier or
        // re-resolved identities.
        let keep = Symbol::new("keep-me").unwrap();
        for i in 0..64 {
            Symbol::new(&format!("crowd-{i}")).unwrap();
        }
        assert_eq!(keep.as_str(), "keep-me");
        assert_eq!(Symbol::new("keep-me").unwrap().as_str(), "keep-me");
    }

    #[test]
    fn debug_shape_is_text_based_and_stable() {
        // Debug output must stay text-based (index-independent) so
        // goldens are stable regardless of intern order, and must keep
        // the pre-interning derived shape byte-for-byte.
        let symbol = Symbol::new("probe").unwrap();
        assert_eq!(format!("{symbol:?}"), r#"Symbol { text: "probe" }"#);
    }

    #[test]
    fn option_symbol_keeps_niche_layout() {
        // The NonZeroU32 payload keeps `Option<Symbol>` the same size
        // as `Symbol` (compiler closure names and vm frame names store
        // `Option<Symbol>` — stage0.md §9.52.4).
        assert_eq!(
            std::mem::size_of::<Option<Symbol>>(),
            std::mem::size_of::<Symbol>()
        );
    }

    // ---------- negative ----------

    #[test]
    fn new_rejects_empty() {
        let err = Symbol::new("").expect_err("empty symbol must be rejected");
        assert_eq!(
            err,
            CoreError::InvalidSymbol {
                text: String::new()
            }
        );
    }

    #[test]
    fn new_rejects_space_only() {
        assert!(matches!(
            Symbol::new(" "),
            Err(CoreError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn new_rejects_interior_space() {
        assert!(matches!(
            Symbol::new("a b"),
            Err(CoreError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn new_rejects_interior_tab() {
        assert!(matches!(
            Symbol::new("a\tb"),
            Err(CoreError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn new_rejects_interior_newline() {
        assert!(matches!(
            Symbol::new("a\nb"),
            Err(CoreError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn new_rejects_interior_carriage_return() {
        assert!(matches!(
            Symbol::new("a\rb"),
            Err(CoreError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn new_rejects_unicode_em_space() {
        // `char::is_whitespace` is Unicode-aware: U+2003 counts.
        assert!(matches!(
            Symbol::new("a\u{2003}b"),
            Err(CoreError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn new_rejects_leading_space() {
        assert!(matches!(
            Symbol::new(" x"),
            Err(CoreError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn new_rejects_nul_control_char() {
        assert!(matches!(
            Symbol::new("a\u{0}b"),
            Err(CoreError::InvalidSymbol { .. })
        ));
    }

    #[test]
    fn rejected_text_leaves_valid_construction_unchanged() {
        // A rejection must not intern the text nor disturb the pool:
        // subsequent valid construction still succeeds and round-trips.
        assert!(Symbol::new("bad text").is_err());
        let after = Symbol::new("after-reject").unwrap();
        assert_eq!(after.as_str(), "after-reject");
    }

    #[test]
    fn invalid_symbol_error_shape() {
        // R8 message conventions: lowercase start, no trailing period,
        // non-empty, backticks around the payload.
        let err = Symbol::new("a b").expect_err("invalid symbol must error");
        let rendered = err.to_string();
        assert!(!rendered.is_empty());
        assert_eq!(rendered.chars().next().unwrap(), 'i');
        assert!(!rendered.ends_with('.'));
        assert!(rendered.contains("`a b`"));
    }
}

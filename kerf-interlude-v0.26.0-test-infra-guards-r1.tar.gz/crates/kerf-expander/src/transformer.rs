//! The syntax-rules transformer (sub-stage 0.9 — docs/stage0.md §8.10
//! basic macro system).
//!
//! Surface: `(define-syntax name (syntax-rules (literal...) (pattern
//! template)...))`. Matching is fixed-arity (no ellipsis `...` — the
//! Stage 0 boundary: a pattern position carrying `...` is rejected at
//! registration, fail-closed); literals match by symbol text; `_`
//! matches any single datum; other symbols are pattern variables bound
//! to the matched subtrees.
//!
//! Hygiene (docs/stage0.md §19.2 core invariant 2, §9.38(b) scope
//! coloring): the template is stored **def-scope colored** — at
//! registration the whole spec subtree receives one fresh def-site
//! scope (applied by the caller before [`SyntaxRules::parse`]) on top
//! of the definition context's scopes. At instantiation:
//! - a **pattern variable** splices the use-site argument node
//!   *verbatim* — its spans, scopes and phase keep the use-site
//!   identity (generation 0 for source code);
//! - every other template node is an **introduced** node: same byte
//!   range and file, but `expansion_id = use-generation + 1`
//!   (docs/stage0.md §8.6 / the dea12b tracing contract) and the
//!   def-colored scope set (def context ∪ def scope).
//!
//! Two complementary mechanisms carry the hygiene guarantee
//! (§9.38(b) lists both):
//! 1. **Scope coloring + the binder-scopes subset judgment** (ctx.rs)
//!    decides *expansion-time* binding: an introduced binding carries
//!    the def scope the spliced arguments lack and vice versa, so no
//!    capture is possible in either direction at resolution time.
//! 2. **Rename-on-capture** (this module) carries the decision into
//!    the *name-based* back half of the pipeline: the CoreExpr/
//!    bytecode/VM faces resolve `Var` by name, so an introduced
//!    binding whose name collides with a symbol carried by the
//!    spliced arguments (or with the flat global / core-form name
//!    faces) is renamed to a fresh `name__macro_N` together with its
//!    introduced references — the use-site argument keeps its name
//!    and therefore its meaning.

use std::collections::{HashMap, HashSet};

use kerf_syntax::{ExpansionId, Span, StxDatum, StxSymbol, SyntaxObject};

use crate::STAGE0_GLOBALS;
use crate::error::ExpandError;

/// One syntax-rules transformer.
#[derive(Debug, Clone)]
pub struct SyntaxRules {
    name: String,
    rules: Vec<Rule>,
    span: Span,
}

/// One `(pattern template)` clause.
#[derive(Debug, Clone)]
struct Rule {
    pattern: Pattern,
    template: SyntaxObject,
}

/// The compiled pattern tree.
#[derive(Debug, Clone, PartialEq)]
enum Pattern {
    /// `_` — matches any single datum, binds nothing.
    Wildcard,
    /// A symbol that must appear verbatim (the literals list plus the
    /// reserved `nil`).
    Literal(String),
    /// A pattern variable: binds the matched subtree.
    Var(String),
    /// An atom that must match structurally.
    Atom(AtomDatum),
    /// A fixed-arity list pattern.
    List(Vec<Pattern>),
}

/// The atom shapes a pattern can demand (the symbol-free subset of
/// [`StxDatum`]).
#[derive(Debug, Clone, PartialEq)]
enum AtomDatum {
    Int(i64),
    Float(f64),
    Bool(bool),
    Str(String),
}

impl SyntaxRules {
    /// The macro name this transformer is bound to.
    pub fn name(&self) -> &str {
        &self.name
    }

    /// The `define-syntax` declaration span (diagnostics).
    pub fn span(&self) -> Span {
        self.span
    }

    /// The number of `(pattern template)` clauses.
    pub fn rule_count(&self) -> usize {
        self.rules.len()
    }

    /// Parse a def-scope-colored `(syntax-rules ...)` spec. `name` is
    /// the macro name (already validated as a legal symbol by the
    /// caller); `form_span` is the enclosing `define-syntax` span.
    pub fn parse(name: &str, spec: &SyntaxObject, form_span: Span) -> Result<Self, ExpandError> {
        let items = match &spec.datum {
            StxDatum::List(items) if items.len() >= 2 => items,
            _ => return Err(malformed(form_span)),
        };
        // (syntax-rules (literals...) clause...)
        match symbol_text(&items[0]) {
            Some("syntax-rules") => {}
            _ => return Err(malformed(form_span)),
        }
        require_runtime_shape(&items[1], form_span)?;
        // The literals list: `nil` (the Stage 0 empty-list spelling —
        // the reader rejects a literal `()` in source, plan-0.3
        // decision 3) or a non-empty list of symbols. `_`, `...` and
        // the reserved `nil` cannot serve as match literals.
        let mut literals: Vec<String> = Vec::new();
        match &items[1].datum {
            StxDatum::Symbol(sym) if sym.as_str() == "nil" => {}
            StxDatum::List(literal_items) if !literal_items.is_empty() => {
                for lit in literal_items {
                    match symbol_text(lit) {
                        Some(text) if text != "_" && text != "..." && text != "nil" => {
                            literals.push(text.to_owned());
                        }
                        _ => return Err(malformed(form_span)),
                    }
                }
            }
            _ => return Err(malformed(form_span)),
        }

        let mut rules = Vec::with_capacity(items.len().saturating_sub(2));
        let mut seen_vars: Vec<String> = Vec::new();
        for clause in &items[2..] {
            require_runtime_shape(clause, form_span)?;
            let clause_items = match &clause.datum {
                StxDatum::List(parts) if parts.len() == 2 => parts,
                _ => return Err(malformed(form_span)),
            };
            // The pattern must be a list (it matches the whole use
            // form, head included).
            require_runtime_shape(&clause_items[0], form_span)?;
            if !matches!(clause_items[0].datum, StxDatum::List(_)) {
                return Err(malformed(form_span));
            }
            seen_vars.clear();
            let pattern = compile_pattern(&clause_items[0], &literals, &mut seen_vars, form_span)?;
            require_runtime_shape(&clause_items[1], form_span)?;
            rules.push(Rule {
                pattern,
                template: clause_items[1].clone(),
            });
        }

        Ok(SyntaxRules {
            name: name.to_owned(),
            rules,
            span: form_span,
        })
    }

    /// Match the whole macro use form and instantiate the winning
    /// rule's template. `form_items` is the complete use form
    /// `(name arg...)`; `use_gen` is the use form's expansion
    /// generation (introduced nodes carry `use_gen + 1`).
    pub fn instantiate(
        &self,
        form_items: &[SyntaxObject],
        use_gen: ExpansionId,
    ) -> Result<SyntaxObject, ExpandError> {
        for rule in &self.rules {
            let mut bindings: HashMap<String, SyntaxObject> = HashMap::new();
            if match_list(&rule.pattern, form_items, &mut bindings) {
                // Rename-on-capture trigger set (§9.38(b) algorithm
                // steps 1-2): every symbol the spliced arguments
                // carry, plus the name-based faces the back half of
                // the pipeline resolves by name and therefore cannot
                // let an introduced binder shadow.
                // Determinism note (stage0.md §9.55.4): iterating
                // `bindings.values()` feeds a set union — the trigger
                // set's *contents* are order-independent, and every
                // downstream consumer is membership-only (fresh_name,
                // binder_collisions). The mangled suffix sequence is
                // driven by template traversal order (a tree walk),
                // never by this iteration order.
                let mut trigger: HashSet<String> = HashSet::new();
                for arg in bindings.values() {
                    collect_symbols(arg, &mut trigger);
                }
                trigger.extend(STAGE0_GLOBALS.iter().map(|s| (*s).to_owned()));
                trigger.extend(
                    crate::expand::RESERVED_MACRO_NAMES
                        .iter()
                        .map(|s| (*s).to_owned()),
                );
                let mut renames: Vec<(String, String)> = Vec::new();
                let mut counter: usize = 0;
                return instantiate_node(
                    &rule.template,
                    &bindings,
                    use_gen,
                    &trigger,
                    &mut renames,
                    &mut counter,
                );
            }
        }
        Err(ExpandError::MacroPatternMismatch {
            name: self.name.clone(),
            // The use site, not the declaration: the mismatch is an
            // error about the *call* (the rustc convention — point at
            // what the user wrote wrong).
            span: form_items[0].span,
        })
    }
}

// ---------- pattern compilation ----------

fn compile_pattern(
    node: &SyntaxObject,
    literals: &[String],
    seen: &mut Vec<String>,
    form_span: Span,
) -> Result<Pattern, ExpandError> {
    match &node.datum {
        StxDatum::Symbol(sym) => {
            let text = sym.as_str();
            if text == "_" {
                Ok(Pattern::Wildcard)
            } else if text == "..." {
                // The Stage 0 boundary: ellipsis patterns are not
                // modeled (docs/stage0.md §8.10 — no complex macro
                // composition); fail closed at registration.
                Err(malformed(form_span))
            } else if text == "nil" || literals.iter().any(|lit| lit == text) {
                Ok(Pattern::Literal(text.to_owned()))
            } else {
                if seen.iter().any(|v| v == text) {
                    // Duplicate pattern variables would bind one name
                    // twice — rejected at registration.
                    return Err(malformed(form_span));
                }
                seen.push(text.to_owned());
                Ok(Pattern::Var(text.to_owned()))
            }
        }
        StxDatum::Int(v) => Ok(Pattern::Atom(AtomDatum::Int(*v))),
        StxDatum::Float(v) => Ok(Pattern::Atom(AtomDatum::Float(*v))),
        StxDatum::Bool(v) => Ok(Pattern::Atom(AtomDatum::Bool(*v))),
        StxDatum::String(v) => Ok(Pattern::Atom(AtomDatum::Str(v.clone()))),
        StxDatum::List(items) => {
            let mut subs = Vec::with_capacity(items.len());
            for item in items {
                subs.push(compile_pattern(item, literals, seen, form_span)?);
            }
            Ok(Pattern::List(subs))
        }
    }
}

// ---------- matching ----------

fn match_list(
    pattern: &Pattern,
    items: &[SyntaxObject],
    bindings: &mut HashMap<String, SyntaxObject>,
) -> bool {
    match pattern {
        Pattern::List(subs) => {
            if subs.len() != items.len() {
                return false;
            }
            subs.iter()
                .zip(items.iter())
                .all(|(sub, item)| match_datum(sub, item, bindings))
        }
        _ => false,
    }
}

fn match_datum(
    pattern: &Pattern,
    node: &SyntaxObject,
    bindings: &mut HashMap<String, SyntaxObject>,
) -> bool {
    match pattern {
        Pattern::Wildcard => true,
        Pattern::Literal(text) => symbol_text(node) == Some(text.as_str()),
        Pattern::Var(name) => {
            bindings.insert(name.clone(), node.clone());
            true
        }
        Pattern::Atom(atom) => match (&node.datum, atom) {
            (StxDatum::Int(a), AtomDatum::Int(b)) => a == b,
            (StxDatum::Float(a), AtomDatum::Float(b)) => a == b,
            (StxDatum::Bool(a), AtomDatum::Bool(b)) => a == b,
            (StxDatum::String(a), AtomDatum::Str(b)) => a == b,
            _ => false,
        },
        Pattern::List(subs) => match &node.datum {
            StxDatum::List(items) => {
                if subs.len() != items.len() {
                    return false;
                }
                subs.iter()
                    .zip(items.iter())
                    .all(|(sub, item)| match_datum(sub, item, bindings))
            }
            _ => false,
        },
    }
}

// ---------- instantiation ----------

/// A fresh rename target that collides with nothing in `trigger`
/// (§9.38(b) step 2: `x` → `x__macro_1`).
fn fresh_name(base: &str, trigger: &HashSet<String>, counter: &mut usize) -> String {
    loop {
        let candidate = format!("{base}__macro_{counter}");
        *counter += 1;
        if !trigger.contains(&candidate) {
            return candidate;
        }
    }
}

/// The active rename for `text`, if any (innermost binding wins —
/// the stack is searched from the top).
fn active_rename<'a>(renames: &'a [(String, String)], text: &str) -> Option<&'a str> {
    renames
        .iter()
        .rev()
        .find(|(from, _)| from == text)
        .map(|(_, to)| to.as_str())
}

/// The binder names an introduced binding form declares: `fn`
/// parameter lists and `let` binding specs (the only user binder
/// forms; `do` binds the internal discard only, declarations cannot
/// appear in expression templates).
fn binder_names(items: &[SyntaxObject]) -> Option<Vec<&str>> {
    let head = symbol_text(&items[0])?;
    match head {
        "fn" => {
            if items.len() != 3 {
                return None;
            }
            symbol_texts(&items[1])
        }
        "let" => {
            if items.len() != 3 {
                return None;
            }
            match &items[1].datum {
                StxDatum::List(spec) if spec.is_empty() => Some(Vec::new()),
                // Multi-binding spec: ((name value)...).
                StxDatum::List(spec) if matches!(spec[0].datum, StxDatum::List(_)) => {
                    let mut names = Vec::with_capacity(spec.len());
                    for pair in spec {
                        if let StxDatum::List(pair_items) = &pair.datum {
                            if let Some(name) = symbol_text(&pair_items[0]) {
                                names.push(name);
                                continue;
                            }
                        }
                        return None;
                    }
                    Some(names)
                }
                // Single-binding spec: (name value).
                StxDatum::List(spec) if spec.len() == 2 => {
                    symbol_text(&spec[0]).map(|name| vec![name])
                }
                _ => None,
            }
        }
        _ => None,
    }
}

fn symbol_texts(node: &SyntaxObject) -> Option<Vec<&str>> {
    match &node.datum {
        StxDatum::List(items) => {
            let mut texts = Vec::with_capacity(items.len());
            for item in items {
                texts.push(symbol_text(item)?);
            }
            Some(texts)
        }
        _ => None,
    }
}

fn collect_symbols(node: &SyntaxObject, found: &mut HashSet<String>) {
    match &node.datum {
        StxDatum::Symbol(sym) => {
            found.insert(sym.as_str().to_owned());
        }
        StxDatum::List(items) => {
            for item in items {
                collect_symbols(item, found);
            }
        }
        _ => {}
    }
}

#[allow(clippy::too_many_arguments)]
fn instantiate_node(
    node: &SyntaxObject,
    bindings: &HashMap<String, SyntaxObject>,
    use_gen: ExpansionId,
    trigger: &HashSet<String>,
    renames: &mut Vec<(String, String)>,
    counter: &mut usize,
) -> Result<SyntaxObject, ExpandError> {
    // A pattern variable splices the use-site argument verbatim —
    // spans, scopes, phase *and name* all keep their use-site identity
    // (the rename walk never touches spliced nodes).
    if let StxDatum::Symbol(sym) = &node.datum {
        if let Some(arg) = bindings.get(sym.as_str()) {
            return Ok(arg.clone());
        }
    }
    let next_gen = use_gen.0.checked_add(1).ok_or(
        // Generation exhaustion is the expansion-depth family: the
        // work budget bounds real programs far below this; only
        // hand-built pathological generations reach it.
        ExpandError::ExpansionDepthExceeded {
            limit: crate::ctx::EXPANSION_LIMIT,
            span: node.span,
        },
    )?;
    let span = Span::new(
        node.span.file_id,
        node.span.start,
        node.span.end,
        ExpansionId(next_gen),
    )
    .expect("template byte range is a valid span (copied verbatim)");
    match &node.datum {
        StxDatum::List(items) => {
            // Rename-on-capture (§9.38(b)): an introduced binding form
            // whose binder collides with the trigger set renames the
            // binder and its introduced references for the whole
            // subtree — the name-based back half then cannot conflate
            // the introduced binding with the use-site name.
            let pushed = if !items.is_empty() {
                binder_collisions(items, trigger)
                    .into_iter()
                    .map(|name| {
                        let to = fresh_name(name, trigger, counter);
                        renames.push((name.to_owned(), to));
                    })
                    .count()
            } else {
                0
            };
            let mapped = items
                .iter()
                .map(|item| instantiate_node(item, bindings, use_gen, trigger, renames, counter))
                .collect::<Result<Vec<_>, _>>()?;
            for _ in 0..pushed {
                renames.pop();
            }
            Ok(SyntaxObject {
                datum: StxDatum::List(mapped),
                span,
                scopes: node.scopes.clone(),
                phase: node.phase,
            })
        }
        StxDatum::Symbol(sym) => {
            // An introduced reference: renamed if an enclosing
            // introduced binder renamed this name (§9.38(b) step 3).
            let datum = match active_rename(renames, sym.as_str()) {
                Some(to) => StxDatum::Symbol(
                    StxSymbol::new(to).expect("rename target must be a valid symbol"),
                ),
                None => node.datum.clone(),
            };
            Ok(SyntaxObject {
                datum,
                span,
                scopes: node.scopes.clone(),
                phase: node.phase,
            })
        }
        _ => Ok(SyntaxObject {
            datum: node.datum.clone(),
            span,
            scopes: node.scopes.clone(),
            phase: node.phase,
        }),
    }
}

/// The binder names of an introduced binding form that collide with
/// the trigger set (deduplicated, declaration order).
fn binder_collisions<'a>(items: &'a [SyntaxObject], trigger: &HashSet<String>) -> Vec<&'a str> {
    let Some(names) = binder_names(items) else {
        return Vec::new();
    };
    let mut collisions: Vec<&'a str> = Vec::new();
    for name in names {
        if trigger.contains(name) && !collisions.contains(&name) {
            collisions.push(name);
        }
    }
    collisions
}

// ---------- shared helpers ----------

fn symbol_text(node: &SyntaxObject) -> Option<&str> {
    match &node.datum {
        StxDatum::Symbol(sym) => Some(sym.as_str()),
        _ => None,
    }
}

/// The registration-time phase guard: every node of a `syntax-rules`
/// spec must be runtime-phase syntax (the reader's single-phase
/// reality; the phase-closure invariant is enforced on the
/// *instantiated product* by the expansion loop).
fn require_runtime_shape(node: &SyntaxObject, form_span: Span) -> Result<(), ExpandError> {
    if node.phase != kerf_syntax::Phase::Runtime {
        return Err(ExpandError::PhaseViolation {
            phase: node.phase,
            span: form_span,
        });
    }
    Ok(())
}

fn malformed(form_span: Span) -> ExpandError {
    ExpandError::MalformedForm {
        form: "define-syntax",
        span: form_span,
    }
}

#[cfg(test)]
mod tests {
    //! Unit tests for the syntax-rules transformer (sub-stage test doc
    //! FP2; docs/tests/v0/stage0/plan/macro.md).

    use super::*;
    use kerf_span::{ByteOffset, FileId};
    use kerf_syntax::{Phase, ScopeSet};

    fn sp(start: u32, end: u32) -> Span {
        Span::new(
            FileId(0),
            ByteOffset(start),
            ByteOffset(end),
            ExpansionId::ROOT,
        )
        .expect("test fixture span must be well-formed")
    }

    fn sym(start: u32, end: u32, text: &str) -> SyntaxObject {
        SyntaxObject::symbol(sp(start, end), ScopeSet::new(), Phase::Runtime, text)
            .expect("test fixture symbol must be valid")
    }

    fn int(start: u32, end: u32, value: i64) -> SyntaxObject {
        SyntaxObject::int(sp(start, end), ScopeSet::new(), Phase::Runtime, value)
    }

    fn lst(start: u32, end: u32, items: Vec<SyntaxObject>) -> SyntaxObject {
        SyntaxObject::list(sp(start, end), ScopeSet::new(), Phase::Runtime, items)
    }

    /// (define-syntax m (syntax-rules () clause)) shaped fixtures.
    fn rules_of(clause: SyntaxObject) -> SyntaxRules {
        // `nil` is the Stage 0 empty-literals spelling.
        let spec = lst(
            0,
            40,
            vec![sym(1, 12, "syntax-rules"), sym(13, 16, "nil"), clause],
        );
        SyntaxRules::parse("m", &spec, sp(0, 40)).expect("fixture transformer must parse")
    }

    // ---------- positive: parsing ----------

    #[test]
    fn parse_accepts_the_canonical_my_if_shape() {
        // (syntax-rules () ((_ c t e) (if c t e)))
        let clause = lst(
            16,
            39,
            vec![
                lst(
                    17,
                    26,
                    vec![
                        sym(18, 19, "_"),
                        sym(20, 21, "c"),
                        sym(22, 23, "t"),
                        sym(24, 25, "e"),
                    ],
                ),
                lst(
                    27,
                    38,
                    vec![
                        sym(28, 30, "if"),
                        sym(31, 32, "c"),
                        sym(33, 34, "t"),
                        sym(35, 36, "e"),
                    ],
                ),
            ],
        );
        let rules = rules_of(clause);
        assert_eq!(rules.name(), "m");
        assert_eq!(rules.rule_count(), 1);
        assert_eq!(rules.span(), sp(0, 40));
    }

    #[test]
    fn parse_records_literals() {
        // (syntax-rules (else) ((_ x else y) (if x y 0))) — the
        // non-empty literals list.
        let spec = lst(
            0,
            50,
            vec![
                sym(1, 12, "syntax-rules"),
                lst(13, 19, vec![sym(14, 18, "else")]),
                lst(
                    20,
                    49,
                    vec![
                        lst(
                            21,
                            33,
                            vec![
                                sym(22, 23, "_"),
                                sym(24, 25, "x"),
                                sym(26, 30, "else"),
                                sym(31, 32, "y"),
                            ],
                        ),
                        lst(
                            34,
                            48,
                            vec![
                                sym(35, 37, "if"),
                                sym(38, 39, "x"),
                                sym(40, 41, "y"),
                                int(42, 43, 0),
                            ],
                        ),
                    ],
                ),
            ],
        );
        assert!(SyntaxRules::parse("m", &spec, sp(0, 50)).is_ok());
    }

    // ---------- positive: matching + instantiation ----------

    #[test]
    fn instantiate_splices_arguments_verbatim() {
        // ((_ c t e) (if c t e)) applied to (m 1 2 3)
        let clause = lst(
            16,
            39,
            vec![
                lst(
                    17,
                    26,
                    vec![
                        sym(18, 19, "_"),
                        sym(20, 21, "c"),
                        sym(22, 23, "t"),
                        sym(24, 25, "e"),
                    ],
                ),
                lst(
                    27,
                    38,
                    vec![
                        sym(28, 30, "if"),
                        sym(31, 32, "c"),
                        sym(33, 34, "t"),
                        sym(35, 36, "e"),
                    ],
                ),
            ],
        );
        let rules = rules_of(clause);
        let arg_two = int(100, 101, 2);
        let use_form = vec![
            sym(50, 51, "m"),
            int(60, 61, 1),
            arg_two.clone(),
            int(70, 71, 3),
        ];
        let out = rules
            .instantiate(&use_form, ExpansionId::ROOT)
            .expect("the canonical shape must match");
        // Spliced arguments keep their own spans (use-site identity).
        let out_items = match &out.datum {
            StxDatum::List(items) => items.clone(),
            other => panic!("expected a list product, got {other:?}"),
        };
        assert_eq!(out_items[1].span, sp(60, 61));
        assert_eq!(out_items[2].span, arg_two.span);
        assert_eq!(out_items[3].span, sp(70, 71));
    }

    #[test]
    fn introduced_nodes_carry_the_next_generation() {
        let clause = lst(
            16,
            39,
            vec![
                lst(17, 21, vec![sym(18, 19, "_")]),
                lst(
                    27,
                    38,
                    vec![
                        sym(28, 30, "if"),
                        int(31, 32, 1),
                        int(33, 34, 2),
                        int(35, 36, 3),
                    ],
                ),
            ],
        );
        let rules = rules_of(clause);
        let use_form = vec![sym(50, 51, "m")];
        let out = rules
            .instantiate(&use_form, ExpansionId::ROOT)
            .expect("wildcard head must match");
        // Every introduced node: generation 0 + 1 = 1 (dea12b).
        assert_eq!(out.span.expansion_id, ExpansionId(1));
        if let StxDatum::List(items) = &out.datum {
            for item in items {
                assert_eq!(item.span.expansion_id, ExpansionId(1));
            }
        } else {
            panic!("expected a list product");
        }
    }

    #[test]
    fn introduced_nodes_carry_the_next_generation_from_a_macro_product() {
        // A use form that itself came from a macro (generation 3):
        // introduced nodes carry generation 4.
        let clause = lst(
            16,
            30,
            vec![
                lst(17, 21, vec![sym(18, 19, "_")]),
                lst(24, 29, vec![sym(25, 26, "f"), int(27, 28, 9)]),
            ],
        );
        let rules = rules_of(clause);
        let use_form = vec![sym(50, 51, "m")];
        let out = rules
            .instantiate(&use_form, ExpansionId(3))
            .expect("wildcard head must match");
        assert_eq!(out.span.expansion_id, ExpansionId(4));
    }

    #[test]
    fn atom_and_nested_list_patterns_match_structurally() {
        // ((_ (a b) 42) (f a b)) — nested list + atom demand.
        let clause = lst(
            16,
            45,
            vec![
                lst(
                    17,
                    29,
                    vec![
                        sym(18, 19, "_"),
                        lst(20, 26, vec![sym(21, 22, "a"), sym(23, 24, "b")]),
                        int(25, 27, 42),
                    ],
                ),
                lst(
                    30,
                    44,
                    vec![sym(31, 32, "f"), sym(33, 34, "a"), sym(35, 36, "b")],
                ),
            ],
        );
        let rules = rules_of(clause);
        let use_form = vec![
            sym(50, 51, "m"),
            lst(60, 66, vec![int(61, 63, 7), int(64, 65, 8)]),
            int(70, 72, 42),
        ];
        assert!(rules.instantiate(&use_form, ExpansionId::ROOT).is_ok());
    }

    #[test]
    fn first_matching_rule_wins() {
        // Two rules: ((_ 1) one) then ((_ x) (f x)).
        let clause_a = lst(
            16,
            26,
            vec![
                lst(17, 23, vec![sym(18, 19, "_"), int(20, 21, 1)]),
                lst(24, 25, vec![int(24, 25, 10)]),
            ],
        );
        let clause_b = lst(
            26,
            40,
            vec![
                lst(27, 33, vec![sym(28, 29, "_"), sym(30, 31, "x")]),
                lst(34, 39, vec![sym(35, 36, "f"), sym(37, 38, "x")]),
            ],
        );
        let spec = lst(
            0,
            40,
            vec![
                sym(1, 12, "syntax-rules"),
                sym(13, 16, "nil"),
                clause_a,
                clause_b,
            ],
        );
        let rules = SyntaxRules::parse("m", &spec, sp(0, 40)).unwrap();
        // (m 1) hits rule 1; (m 5) falls through to rule 2.
        assert!(
            rules
                .instantiate(&[sym(50, 51, "m"), int(52, 53, 1)], ExpansionId::ROOT)
                .is_ok()
        );
        assert!(
            rules
                .instantiate(&[sym(50, 51, "m"), int(52, 53, 5)], ExpansionId::ROOT)
                .is_ok()
        );
    }

    // ---------- negative: registration ----------

    #[test]
    fn parse_rejects_duplicate_pattern_variables() {
        // ((_ x x) (f x)) — x bound twice.
        let clause = lst(
            16,
            30,
            vec![
                lst(
                    17,
                    24,
                    vec![sym(18, 19, "_"), sym(20, 21, "x"), sym(22, 23, "x")],
                ),
                lst(25, 29, vec![sym(26, 27, "f"), sym(28, 29, "x")]),
            ],
        );
        let spec = lst(
            0,
            40,
            vec![sym(1, 12, "syntax-rules"), sym(13, 16, "nil"), clause],
        );
        let err = SyntaxRules::parse("m", &spec, sp(0, 40))
            .expect_err("duplicate pattern variables must be rejected");
        assert!(matches!(err, ExpandError::MalformedForm { form, .. } if form == "define-syntax"));
    }

    #[test]
    fn parse_rejects_ellipsis_patterns() {
        // ((_ x ...) (f x)) — the Stage 0 ellipsis boundary.
        let clause = lst(
            16,
            32,
            vec![
                lst(
                    17,
                    26,
                    vec![sym(18, 19, "_"), sym(20, 21, "x"), sym(22, 25, "...")],
                ),
                lst(27, 31, vec![sym(28, 29, "f"), sym(30, 31, "x")]),
            ],
        );
        let spec = lst(
            0,
            40,
            vec![sym(1, 12, "syntax-rules"), sym(13, 16, "nil"), clause],
        );
        let err = SyntaxRules::parse("m", &spec, sp(0, 40))
            .expect_err("ellipsis patterns must be rejected at registration");
        assert!(matches!(err, ExpandError::MalformedForm { form, .. } if form == "define-syntax"));
    }

    #[test]
    fn parse_rejects_non_syntax_rules_heads_and_bad_shapes() {
        // Wrong head.
        let spec = lst(0, 20, vec![sym(1, 5, "noise"), lst(6, 8, vec![])]);
        assert!(SyntaxRules::parse("m", &spec, sp(0, 20)).is_err());
        // Clause with three parts.
        let clause = lst(
            16,
            30,
            vec![lst(17, 20, vec![]), int(21, 22, 1), int(23, 24, 2)],
        );
        let spec = lst(
            0,
            40,
            vec![sym(1, 12, "syntax-rules"), sym(13, 16, "nil"), clause],
        );
        assert!(SyntaxRules::parse("m", &spec, sp(0, 40)).is_err());
        // Non-list pattern.
        let clause = lst(16, 26, vec![sym(17, 19, "no"), int(20, 22, 5)]);
        let spec = lst(
            0,
            40,
            vec![sym(1, 12, "syntax-rules"), sym(13, 16, "nil"), clause],
        );
        assert!(SyntaxRules::parse("m", &spec, sp(0, 40)).is_err());
    }

    // ---------- negative: matching ----------

    #[test]
    fn no_matching_rule_is_a_pattern_mismatch() {
        let clause = lst(
            16,
            26,
            vec![
                lst(17, 23, vec![sym(18, 19, "_"), int(20, 21, 1)]),
                int(24, 25, 10),
            ],
        );
        let rules = rules_of(clause);
        let err = rules
            .instantiate(&[sym(50, 51, "m"), int(52, 53, 2)], ExpansionId::ROOT)
            .expect_err("an atom mismatch must fail every rule");
        assert_eq!(
            err,
            ExpandError::MacroPatternMismatch {
                name: "m".to_owned(),
                // The use head's span, not the declaration's.
                span: sp(50, 51)
            }
        );
    }

    #[test]
    fn literal_mismatch_and_arity_mismatch_fail() {
        // (syntax-rules (else) ((_ else) 1))
        let clause = lst(
            20,
            34,
            vec![
                lst(21, 29, vec![sym(22, 23, "_"), sym(24, 28, "else")]),
                int(30, 31, 1),
            ],
        );
        let spec = lst(
            0,
            40,
            vec![
                sym(1, 12, "syntax-rules"),
                lst(13, 19, vec![sym(14, 18, "else")]),
                clause,
            ],
        );
        let rules = SyntaxRules::parse("m", &spec, sp(0, 40)).unwrap();
        // Literal mismatch: (m other).
        assert!(matches!(
            rules.instantiate(&[sym(50, 51, "m"), sym(52, 57, "other")], ExpansionId::ROOT),
            Err(ExpandError::MacroPatternMismatch { .. })
        ));
        // Arity mismatch: (m).
        assert!(matches!(
            rules.instantiate(&[sym(50, 51, "m")], ExpansionId::ROOT),
            Err(ExpandError::MacroPatternMismatch { .. })
        ));
    }
}

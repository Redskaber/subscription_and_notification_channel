//! The external-name face: names bound outside any module `define`.
//!
//! Single-source discipline (stage-1-plan §4): this crate never
//! copies the `STAGE0_GLOBALS` list. Callers construct
//! [`Externals`] from the authoritative sources —
//! `kerf_expander::STAGE0_GLOBALS` (the expansion-time resolution
//! table) plus `kerf_vm::Builtin::ALL` (name + arity triples) — at the
//! three consumption sites (root integration tests, the audit
//! example, the 1.1 driver wiring).

/// Name-to-optional-arity table for externally bound names.
///
/// Resolution is three-valued, mirroring what the caller knows:
/// `Some(Some(n))` — the name is external and takes `n` arguments
/// (a builtin with a fixed arity);
/// `Some(None)` — the name is external with unknown arity;
/// `None` — the name is not external at all.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct Externals {
    entries: Vec<(String, Option<u32>)>,
}

impl Externals {
    /// The empty table — nothing is external.
    pub const fn empty() -> Self {
        Self {
            entries: Vec::new(),
        }
    }

    /// Names only — every entry resolves as external with unknown
    /// arity (the R2c conservative skip case).
    pub fn from_names<'a>(names: impl IntoIterator<Item = &'a str>) -> Self {
        Self {
            entries: names.into_iter().map(|n| (n.to_owned(), None)).collect(),
        }
    }

    /// Names with optional arities — `(name, Some(arity))` from
    /// `Builtin::ALL` triples, or `(name, None)` when only existence
    /// is known. Later entries win (last-binding-wins, mirroring the
    /// global-store overwrite order the checker mirrors elsewhere).
    pub fn from_named_arities<'a>(
        entries: impl IntoIterator<Item = (&'a str, Option<u32>)>,
    ) -> Self {
        Self {
            entries: entries
                .into_iter()
                .map(|(n, a)| (n.to_owned(), a))
                .collect(),
        }
    }

    /// Three-valued resolution (see the type docs).
    pub fn resolve(&self, name: &str) -> Option<Option<u32>> {
        // Reverse scan: the nearest binding wins (the same
        // last-wins order as a global store overwrite).
        self.entries
            .iter()
            .rev()
            .find(|(n, _)| n == name)
            .map(|(_, a)| *a)
    }

    /// The number of registered entries (deduplicated by resolution
    /// order — the audit face uses this to assert the full builtin
    /// surface made it in).
    pub fn len(&self) -> usize {
        self.entries.len()
    }

    /// Whether the table is empty.
    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }
}

#[cfg(test)]
mod tests {
    //! Externals-face tests (FP2): three-state resolution, constructor
    //! shapes, last-binding-wins order.

    use super::*;

    #[test]
    fn empty_resolves_nothing() {
        let e = Externals::empty();
        assert!(e.is_empty());
        assert_eq!(e.resolve("car"), None);
    }

    #[test]
    fn from_names_resolves_existence_without_arity() {
        let e = Externals::from_names(["car", "cdr"]);
        assert_eq!(e.resolve("car"), Some(None));
        assert_eq!(e.resolve("cdr"), Some(None));
        assert_eq!(e.resolve("cons"), None);
        assert_eq!(e.len(), 2);
    }

    #[test]
    fn from_named_arities_resolves_known_arities() {
        let e =
            Externals::from_named_arities([("+", Some(2)), ("car", Some(1)), ("mystery", None)]);
        assert_eq!(e.resolve("+"), Some(Some(2)));
        assert_eq!(e.resolve("car"), Some(Some(1)));
        assert_eq!(e.resolve("mystery"), Some(None));
        assert_eq!(e.resolve("nope"), None);
    }

    #[test]
    fn later_entries_win_on_duplicate_names() {
        let e = Externals::from_named_arities([("f", Some(1)), ("f", Some(2))]);
        assert_eq!(e.resolve("f"), Some(Some(2)));
    }

    #[test]
    fn default_is_empty_like_empty() {
        let d = Externals::default();
        assert!(d.is_empty());
        assert_eq!(d, Externals::empty());
    }
}

//! kerf-compiler — bytecode generation (Layer 5).
//!
//! Charter (docs/stage0.md §19.3): CoreExpr -> Bytecode with jump
//! backpatching, a deduplicated constant pool, an interned global
//! symbol table, and a debug_info_table mapping every pc back to a
//! source span (docs/stage0.md §12.1 consumption table). The 24-op
//! set covers the §8.12 groups plus the Perform/Handle carriers; the
//! 0.6 VM executes it and resolves runtime errors through
//! [`Bytecode::span_of`].
//!
//! Defense in depth (plan-0.5.md ruling 4): compile-time bookkeeping
//! (depth caps, patch assertions, placeholder drain) fails closed
//! with structured errors, and [`Bytecode::verify`] re-checks the
//! product (operand bounds, debug-info parallelism, DAG stack-depth
//! propagation) — the VM load-time hook.
//!
//! Status: structural scaffold created at Stage 0.0 (Task 2-c),
//! implemented at sub-stage 0.5 (TD-003 resolution step 1 of 4).

mod bytecode;
mod compile;
mod error;
mod opcode;
mod verify;

// Explicit re-export list (SOP §10.1 rule 4 — glob re-exports are forbidden).
pub use bytecode::{Bytecode, FuncProto, Instr};
pub use compile::{compile, compile_program};
pub use error::CompileError;
pub use opcode::Opcode;

// Face extension for the Layer 8 consumer (plan-0.8 decision, same
// consumer-face completeness passthrough as LiteralValue/Span/Symbol):
// the driver names `ModuleItem` (the expand_program output type it
// stores in ParsedProgram) but the §18.5 DAG declares no L4 -> L8
// edge — the type flows through this crate exactly as the others.
pub use kerf_core::ModuleItem;

// Face extension for the Layer 6 consumer (plan-0.6 decision, mirroring
// the plan-0.5 ruling 14 precedent "consumer-face completeness passthrough"):
// the VM consumes the core primitive types (constants, spans, symbols) but
// the §18.5 DAG declares no L4 -> L6 edge, so they pass through this crate
// exactly as `Span` passes through kerf-core for this crate. Zero new DAG
// edges; kerf-span stays a dev-dependency here only.
pub use kerf_core::{
    Binding, ByteOffset, CoreExpr, ExpansionId, FileId, HandlerClause, LiteralValue, Span, Symbol,
};
// 1.6 nameability completion (the 1.5-b kerf-reader precedent, third
// instance): CoreExpr/Binding/HandlerClause ride ModuleItem's public
// shape — the expander-parity harness names them; zero new DAG edges.

/// Compile-recursion depth cap: 2× the expander budget (512) — the
/// same 2× headroom ratio the expander keeps over the reader cap
/// (256). Expander output is structurally bounded below this; only
/// synthesized trees can exceed it, and they fail closed with
/// [`CompileError::DepthExceeded`] (never a stack overflow — §19.2
/// invariant 1 mirrored on the compiler side).
pub const COMPILE_DEPTH_LIMIT: usize = 1024;

/// Jump placeholder sentinel emitted by `emit_jump`: never a valid pc
/// (it equals u32::MAX); `finish` drains unpatched placeholders and
/// `verify` rejects any survivor as an out-of-range target.
pub const JUMP_PLACEHOLDER: u32 = u32::MAX;

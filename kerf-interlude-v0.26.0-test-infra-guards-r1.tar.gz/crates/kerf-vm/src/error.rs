//! Runtime errors (docs/stage0.md §19.5): every variant carries the
//! source [`Span`] resolved through the debug_info table at raise
//! time, following the §12.1 consumption row (the VM reports runtime
//! failures back at the source level).
//!
//! Class coverage (SOP §7.1.1): [`RuntimeError::ArityMismatch`] lights
//! class 5 and [`RuntimeError::TypeMismatch`] lights class 6 — the
//! 0.6 round took the seven-class matrix from 4/7 to 6/7; the 0.9
//! module-loading layer lit the seventh class (all seven lit since).

use std::fmt;

use kerf_compiler::{Opcode, Span, Symbol};

use crate::value::Value;

/// A runtime failure with a resolved source location.
#[derive(Debug, Clone, PartialEq)]
pub enum RuntimeError {
    /// A call passed the wrong argument count — to a closure (proto
    /// params) or to a builtin (registry arity). SOP §7.1.1 class 5.
    ArityMismatch {
        /// Rendered callee description (`fib`, `#<anonymous>`, `+`).
        func: String,
        expected: u32,
        actual: u32,
        span: Span,
    },
    /// A value of the wrong kind reached an operation that demands a
    /// specific one (truthy conditions demand `bool`, arithmetic
    /// demands same-kind numbers, `car`/`cdr` demand pairs, calls
    /// demand callables). SOP §7.1.1 class 6.
    TypeMismatch {
        /// What the operation demanded, e.g. `jump-if-false condition`.
        context: &'static str,
        /// What the operand's kind actually was.
        got: &'static str,
        span: Span,
    },
    /// A `load-global` read a never-stored non-builtin slot (the
    /// dynamic-order face verify cannot decide statically: use before
    /// the defining `store-global` executed).
    UnboundGlobal { name: Symbol, span: Span },
    /// A `perform` found no installed handler for the effect.
    UnhandledEffect { effect: Symbol, span: Span },
    /// Integer division by a zero divisor.
    DivByZero { span: Span },
    /// A checked integer operation overflowed `i64` (fail-closed, not
    /// wrapping — §2.3 deterministic boundaries).
    ArithmeticOverflow { op: Opcode, span: Span },
    /// The allocation budget ran out (the §19.4 safety point failing
    /// closed; the 0.7 collector turns this point into
    /// collect-then-retry).
    BudgetExceeded { budget: u32, span: Span },
    /// `read-line` hit the end of input.
    Eof { span: Span },
    /// A `ret` executed in the entry frame, which has no caller to
    /// return to (verify accepts it as a terminator; only the run
    /// time knows the frame stack is empty).
    RetFromEntry { pc: usize, span: Span },
    /// A stack access popped below the bottom — the §19.5 trap 2
    /// mandate (explicit depth checks on every stack access). Reachable
    /// in verified bytecode through the handler-stack face
    /// (`pop-handler n` with fewer than `n` installed).
    StackUnderflow { op: Opcode, pc: usize, span: Span },
    /// The meta-circular evaluator's recursion depth cap ran out (the
    /// 0.7 evaluator recurses in Rust while VM frames live on the
    /// heap — only the evaluator path can raise this; the VM is
    /// bounded by `BudgetExceeded` instead).
    EvalDepthExceeded { limit: u32, span: Span },
}

impl RuntimeError {
    /// The resolved source location (§12.1 consumption row face — the
    /// 0.8 driver renders diagnostics through this).
    pub fn span(&self) -> Span {
        match self {
            RuntimeError::ArityMismatch { span, .. }
            | RuntimeError::TypeMismatch { span, .. }
            | RuntimeError::UnboundGlobal { span, .. }
            | RuntimeError::UnhandledEffect { span, .. }
            | RuntimeError::DivByZero { span }
            | RuntimeError::ArithmeticOverflow { span, .. }
            | RuntimeError::BudgetExceeded { span, .. }
            | RuntimeError::Eof { span }
            | RuntimeError::RetFromEntry { span, .. }
            | RuntimeError::StackUnderflow { span, .. }
            | RuntimeError::EvalDepthExceeded { span, .. } => *span,
        }
    }

    /// The offending value kind, when the variant carries one.
    pub fn got_kind(&self) -> Option<&'static str> {
        match self {
            RuntimeError::TypeMismatch { got, .. } => Some(got),
            _ => None,
        }
    }
}

impl fmt::Display for RuntimeError {
    /// R8 family: lowercase start, no trailing period, backticked
    /// payloads. §9.56 DIAG-1: no position fragments — spans live in
    /// the payload and the driver renders them as the location line.
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            RuntimeError::ArityMismatch {
                func,
                expected,
                actual,
                ..
            } => write!(
                f,
                "arity mismatch: `{func}` expects `{expected}` arguments, got `{actual}`"
            ),
            RuntimeError::TypeMismatch { context, got, .. } => {
                write!(
                    f,
                    "type mismatch: {context} must be a matching kind, got `{got}`"
                )
            }
            RuntimeError::UnboundGlobal { name, .. } => {
                write!(f, "unbound global `{name}`")
            }
            RuntimeError::UnhandledEffect { effect, .. } => {
                write!(f, "unhandled effect `{effect}`")
            }
            RuntimeError::DivByZero { .. } => f.write_str("division by zero"),
            RuntimeError::ArithmeticOverflow { op, .. } => {
                write!(f, "{} overflow", op.kind_name())
            }
            RuntimeError::BudgetExceeded { budget, .. } => {
                write!(f, "allocation budget of `{budget}` exhausted")
            }
            RuntimeError::Eof { .. } => f.write_str("read-line: end of input"),
            RuntimeError::RetFromEntry { pc, .. } => {
                write!(f, "ret from entry frame at pc `{pc}`")
            }
            RuntimeError::StackUnderflow { op, pc, .. } => {
                write!(f, "stack underflow at `{}` pc `{pc}`", op.kind_name())
            }
            RuntimeError::EvalDepthExceeded { limit, .. } => {
                write!(f, "eval depth of `{limit}` exceeded")
            }
        }
    }
}

impl std::error::Error for RuntimeError {}

// Re-exported for the `TypeMismatch` constructors below (call sites
// stay terse inside the interpreter).
pub(crate) fn type_mismatch(context: &'static str, got: &Value, span: Span) -> RuntimeError {
    RuntimeError::TypeMismatch {
        context,
        got: got.kind_name(),
        span,
    }
}

#[cfg(test)]
mod tests {
    //! RuntimeError face tests (FP1): every variant renders in the R8
    //! family and keeps its resolved span.

    use super::*;
    use kerf_compiler::{ByteOffset, ExpansionId, FileId};

    fn fix_span() -> Span {
        Span::new(FileId(0), ByteOffset(4), ByteOffset(8), ExpansionId::ROOT)
            .expect("test fixture span must be well-formed")
    }

    fn every_variant() -> Vec<RuntimeError> {
        let span = fix_span();
        vec![
            RuntimeError::ArityMismatch {
                func: "fib".into(),
                expected: 1,
                actual: 2,
                span,
            },
            RuntimeError::TypeMismatch {
                context: "jump-if-false condition",
                got: "int",
                span,
            },
            RuntimeError::UnboundGlobal {
                name: Symbol::new("x").expect("fixture symbol"),
                span,
            },
            RuntimeError::UnhandledEffect {
                effect: Symbol::new("log").expect("fixture symbol"),
                span,
            },
            RuntimeError::DivByZero { span },
            RuntimeError::ArithmeticOverflow {
                op: Opcode::Add,
                span,
            },
            RuntimeError::BudgetExceeded { budget: 4, span },
            RuntimeError::Eof { span },
            RuntimeError::RetFromEntry { pc: 3, span },
            RuntimeError::StackUnderflow {
                op: Opcode::PopHandler,
                pc: 7,
                span,
            },
            RuntimeError::EvalDepthExceeded { limit: 2048, span },
        ]
    }

    #[test]
    fn arity_mismatch_display_carries_both_counts() {
        // §9.56 DIAG-1: position-free — the span lives in the payload.
        let err = RuntimeError::ArityMismatch {
            func: "fib".into(),
            expected: 1,
            actual: 2,
            span: fix_span(),
        };
        assert_eq!(
            err.to_string(),
            "arity mismatch: `fib` expects `1` arguments, got `2`"
        );
    }

    #[test]
    fn type_mismatch_display_names_context_and_got() {
        let err = RuntimeError::TypeMismatch {
            context: "car operand",
            got: "int",
            span: fix_span(),
        };
        let msg = err.to_string();
        assert!(msg.contains("type mismatch: car operand"));
        assert!(msg.contains("got `int`"));
        assert_eq!(err.got_kind(), Some("int"));
    }

    #[test]
    fn unbound_global_and_unhandled_effect_name_their_payloads() {
        let unbound = RuntimeError::UnboundGlobal {
            name: Symbol::new("x").expect("fixture symbol"),
            span: fix_span(),
        };
        assert!(unbound.to_string().contains("unbound global `x`"));
        let unhandled = RuntimeError::UnhandledEffect {
            effect: Symbol::new("log").expect("fixture symbol"),
            span: fix_span(),
        };
        assert!(unhandled.to_string().contains("unhandled effect `log`"));
    }

    #[test]
    fn div_zero_and_overflow_use_short_forms() {
        assert!(
            RuntimeError::DivByZero { span: fix_span() }
                .to_string()
                .starts_with("division by zero")
        );
        let over = RuntimeError::ArithmeticOverflow {
            op: Opcode::Mul,
            span: fix_span(),
        };
        assert!(over.to_string().starts_with("mul overflow"));
    }

    #[test]
    fn budget_and_eof_display_their_limits() {
        let budget = RuntimeError::BudgetExceeded {
            budget: 4,
            span: fix_span(),
        };
        assert!(
            budget
                .to_string()
                .contains("allocation budget of `4` exhausted")
        );
        assert!(
            RuntimeError::Eof { span: fix_span() }
                .to_string()
                .starts_with("read-line: end of input")
        );
    }

    #[test]
    fn ret_from_entry_and_stack_underflow_carry_pcs() {
        let ret = RuntimeError::RetFromEntry {
            pc: 3,
            span: fix_span(),
        };
        assert!(ret.to_string().contains("ret from entry frame at pc `3`"));
        let under = RuntimeError::StackUnderflow {
            op: Opcode::PopHandler,
            pc: 7,
            span: fix_span(),
        };
        assert!(
            under
                .to_string()
                .contains("stack underflow at `pop-handler` pc `7`")
        );
    }

    #[test]
    fn eval_depth_display_names_its_limit() {
        let err = RuntimeError::EvalDepthExceeded {
            limit: 2048,
            span: fix_span(),
        };
        assert!(err.to_string().contains("eval depth of `2048` exceeded"));
        assert_eq!(err.span(), fix_span());
    }

    #[test]
    fn every_variant_starts_lowercase_without_trailing_period() {
        for err in every_variant() {
            let msg = err.to_string();
            let first = msg.chars().next().expect("non-empty message");
            assert!(
                first.is_lowercase(),
                "R8: message must start lowercase: {msg}"
            );
            assert!(!msg.ends_with('.'), "R8: no trailing period: {msg}");
            assert!(!msg.contains("#"), "§9.56 DIAG-1: no span fragment: {msg}");
        }
    }

    #[test]
    fn every_variant_preserves_its_resolved_span() {
        for err in every_variant() {
            assert_eq!(err.span(), fix_span(), "span survives construction: {err}");
        }
    }
}

//! Errors produced by the reader (lexical and syntactic phases).

use std::error::Error;
use std::fmt;

use kerf_span::ByteOffset;

/// Everything that can go wrong while turning source text into a
/// syntax-object tree (docs/stage0.md §278 capability signature:
/// `read : string → Result<SyntaxObject, ReadError>`; the §8.1
/// `LexError` of the tokenize contract maps onto the lexical variants
/// of this single error surface — one consumer, one error type).
///
/// All payloads carry byte-precise locations (docs/stage0.md §12.1 —
/// byte-offset representation; line/column are derived at diagnostic
/// render time, never stored — TD-001).
///
/// Message shape follows the Rust compiler conventions (SOP §10.5 / R8):
/// lowercase start, no trailing period, payloads in backticks. The
/// `InvalidSymbol` rendering is byte-identical to
/// `kerf_syntax::SyntaxError::InvalidSymbol` and
/// `kerf_core::CoreError::InvalidSymbol` (single-source dictionary).
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ReadError {
    /// A `(` was never closed before end of input. When several lists
    /// are open at end of input, the innermost one (the list being
    /// parsed when input ran out — the latest-opened `(`) is reported:
    /// a deterministic boundary (SOP §2.3-3) and the location closest
    /// to where the input ended.
    UnclosedList { opened_at: ByteOffset },
    /// A `)` appeared with no matching open delimiter.
    UnexpectedClose { at: ByteOffset },
    /// A string literal was never terminated before end of input (raw
    /// newlines inside strings are legal — Scheme tradition).
    UnterminatedString { started_at: ByteOffset },
    /// A string escape was not one of `\"` `\\` `\n` `\t` `\r`.
    InvalidEscape { escape: char, at: ByteOffset },
    /// An atom starting with `#` was not `#t` or `#f` (fail-closed —
    /// the Stage 0 skin defines exactly two hash literals).
    InvalidBool { text: String },
    /// A number-shaped atom (leading digit, or `+`/`-`/`.` followed by
    /// a digit) that parses as neither `i64` nor `f64`. No Racket-style
    /// symbol fallback: a typo like `1.2.3` must be an error, not a
    /// silent identifier (SOP §2.3-4 — errors over silence).
    MalformedNumber { text: String },
    /// An atom failed the [`crate::StxSymbol`](crate::symbol::StxSymbol)
    /// floor (control characters — whitespace cannot occur inside a
    /// lexed atom because whitespace terminates atoms).
    InvalidSymbol { text: String },
    /// `()` — the empty application (SOP §7.1.1 error class 3). The
    /// Stage 0 skin has no reading for an empty form: it can never
    /// carry an operator, so the reader rejects it fail-closed instead
    /// of passing it downstream.
    EmptyApplication { at: ByteOffset },
    /// List nesting exceeded the Stage 0 cap of 256 levels
    /// (docs/develop/v0/stage-0/stage-0-plan.md, sub-stage 0.3).
    NestingDepthExceeded { depth: usize, limit: usize },
    /// A character that has no meaning in the Stage 0 skin: the
    /// bracket characters `[` `]` `{` `}` and the reader-macro
    /// characters `` ` `` `'` `,` (no reader macros exist in Stage 0 —
    /// quote is spelled `(quote x)`).
    UnexpectedCharacter { character: char, at: ByteOffset },
}

impl fmt::Display for ReadError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            // §9.56 DIAG-1: position fragments stay out of Display —
            // the message is general and stands on its own (rustc
            // convention); offsets live in the payload and the driver
            // renders them as the `--> file:line:col` location line.
            ReadError::UnclosedList { .. } => {
                f.write_str("unclosed delimiter: `(` is never closed")
            }
            ReadError::UnexpectedClose { .. } => f.write_str("unexpected closing delimiter `)`"),
            ReadError::UnterminatedString { .. } => f.write_str("unterminated string literal"),
            ReadError::InvalidEscape { escape, .. } => {
                write!(f, "invalid string escape `{escape}`")
            }
            ReadError::InvalidBool { text } => {
                write!(f, "invalid boolean literal `{text}`: expected `#t` or `#f`")
            }
            ReadError::MalformedNumber { text } => {
                write!(f, "malformed number literal `{text}`")
            }
            ReadError::InvalidSymbol { text } => {
                write!(
                    f,
                    "invalid symbol `{text}`: must be non-empty with no whitespace or control characters"
                )
            }
            ReadError::EmptyApplication { .. } => {
                f.write_str("empty application: `()` has no operator")
            }
            ReadError::NestingDepthExceeded { depth, limit } => {
                write!(f, "nesting depth {depth} exceeds the limit of {limit}")
            }
            ReadError::UnexpectedCharacter { character, .. } => {
                write!(f, "unexpected character `{character}`")
            }
        }
    }
}

impl Error for ReadError {}

impl ReadError {
    /// The byte-precise location of the offending token, when the
    /// variant carries one. Four variants (`InvalidBool`,
    /// `MalformedNumber`, `InvalidSymbol`, `NestingDepthExceeded`)
    /// report through their text/depth payload only — a whole-token
    /// defect has no single byte to point at, and a fabricated
    /// position would be a DUMMY span (stage-0-plan row 0.1 ruling
    /// family). The driver's diagnostic layer (plan sub-stage 0.8)
    /// renders `Some` offsets as spans and `None` without a location
    /// line.
    pub fn offset(&self) -> Option<ByteOffset> {
        match self {
            ReadError::UnclosedList { opened_at } => Some(*opened_at),
            ReadError::UnexpectedClose { at }
            | ReadError::InvalidEscape { at, .. }
            | ReadError::EmptyApplication { at }
            | ReadError::UnexpectedCharacter { at, .. } => Some(*at),
            ReadError::UnterminatedString { started_at } => Some(*started_at),
            ReadError::InvalidBool { .. }
            | ReadError::MalformedNumber { .. }
            | ReadError::InvalidSymbol { .. }
            | ReadError::NestingDepthExceeded { .. } => None,
        }
    }
}

#[cfg(test)]
mod tests {
    //! Unit tests for the ReadError rendering surface (sub-stage test
    //! doc FP3; R8 message-shape assertions).

    use super::*;

    fn every_variant() -> Vec<ReadError> {
        vec![
            ReadError::UnclosedList {
                opened_at: ByteOffset(3),
            },
            ReadError::UnexpectedClose { at: ByteOffset(7) },
            ReadError::UnterminatedString {
                started_at: ByteOffset(0),
            },
            ReadError::InvalidEscape {
                escape: 'x',
                at: ByteOffset(4),
            },
            ReadError::InvalidBool {
                text: "#q".to_owned(),
            },
            ReadError::MalformedNumber {
                text: "1.2.3".to_owned(),
            },
            ReadError::InvalidSymbol {
                text: "a\u{0}b".to_owned(),
            },
            ReadError::EmptyApplication { at: ByteOffset(0) },
            ReadError::NestingDepthExceeded {
                depth: 257,
                limit: 256,
            },
            ReadError::UnexpectedCharacter {
                character: '[',
                at: ByteOffset(2),
            },
        ]
    }

    // ---------- negative (error surface) ----------

    #[test]
    fn display_family_follows_rust_message_conventions() {
        // R8 family check over every variant: lowercase start, no
        // trailing period.
        for err in every_variant() {
            let rendered = err.to_string();
            let first = rendered.chars().next().expect("non-empty message");
            assert!(
                first.is_lowercase(),
                "message must start lowercase: {rendered}"
            );
            assert!(!rendered.ends_with('.'), "no trailing period: {rendered}");
        }
    }

    #[test]
    fn display_unclosed_is_position_free() {
        // §9.56 DIAG-1: the message stands on its own — the byte offset
        // lives in the payload (`offset()`), never in the Display.
        let err = ReadError::UnclosedList {
            opened_at: ByteOffset(12),
        };
        let rendered = err.to_string();
        assert_eq!(rendered, "unclosed delimiter: `(` is never closed");
        assert!(!rendered.contains("12"));
        assert_eq!(err.offset(), Some(ByteOffset(12)), "payload keeps it");
    }

    #[test]
    fn display_invalid_symbol_is_byte_identical_across_layers() {
        // Single-source dictionary (SOP §10.5 / R8): the same source
        // concept renders the same English text in every layer.
        let reader = ReadError::InvalidSymbol {
            text: "a b".to_owned(),
        }
        .to_string();
        let syntax = kerf_syntax::SyntaxError::InvalidSymbol {
            text: "a b".to_owned(),
        }
        .to_string();
        assert_eq!(reader, syntax);
    }

    #[test]
    fn display_invalid_bool_mentions_expected_literals() {
        let err = ReadError::InvalidBool {
            text: "#true".to_owned(),
        };
        let rendered = err.to_string();
        assert!(rendered.contains("`#true`"));
        assert!(rendered.contains("`#t`"));
        assert!(rendered.contains("`#f`"));
    }

    #[test]
    fn error_variants_distinguishable_by_equality() {
        let variants = every_variant();
        for (i, a) in variants.iter().enumerate() {
            for (j, b) in variants.iter().enumerate() {
                if i != j {
                    assert_ne!(a, b, "variants {i} and {j} must be distinct");
                }
            }
        }
        // Same variant with same payload compares equal.
        assert_eq!(variants[0], variants[0].clone());
    }

    /// 0.8 consumer-face extension: the six positioned variants expose
    /// their byte offset, the four payload-only variants expose none
    /// (a fabricated position would be a DUMMY span).
    #[test]
    fn offset_extraction_matches_variant_kind() {
        let positioned = [
            ReadError::UnclosedList {
                opened_at: ByteOffset(3),
            },
            ReadError::UnexpectedClose { at: ByteOffset(7) },
            ReadError::UnterminatedString {
                started_at: ByteOffset(0),
            },
            ReadError::InvalidEscape {
                escape: 'x',
                at: ByteOffset(4),
            },
            ReadError::EmptyApplication { at: ByteOffset(0) },
            ReadError::UnexpectedCharacter {
                character: '[',
                at: ByteOffset(9),
            },
        ];
        for (i, err) in positioned.iter().enumerate() {
            assert!(err.offset().is_some(), "variant {i} must carry an offset");
        }
        let payload_only = [
            ReadError::InvalidBool {
                text: "#q".to_owned(),
            },
            ReadError::MalformedNumber {
                text: "1.2.3".to_owned(),
            },
            ReadError::InvalidSymbol {
                text: "a\u{0}b".to_owned(),
            },
            ReadError::NestingDepthExceeded {
                depth: 257,
                limit: 256,
            },
        ];
        for (i, err) in payload_only.iter().enumerate() {
            assert!(
                err.offset().is_none(),
                "variant {i} must not fake an offset"
            );
        }
    }

    /// The extracted offset is the exact payload byte, not a copy of a
    /// neighboring variant's position.
    #[test]
    fn offset_extraction_returns_payload_byte() {
        assert_eq!(
            ReadError::UnclosedList {
                opened_at: ByteOffset(42)
            }
            .offset(),
            Some(ByteOffset(42))
        );
        assert_eq!(
            ReadError::UnexpectedClose { at: ByteOffset(7) }.offset(),
            Some(ByteOffset(7))
        );
    }

    /// UnterminatedString reports the opening quote position (the
    /// deterministic anchor for a defect with no end).
    #[test]
    fn offset_extraction_string_reports_start() {
        assert_eq!(
            ReadError::UnterminatedString {
                started_at: ByteOffset(11)
            }
            .offset(),
            Some(ByteOffset(11))
        );
    }
}

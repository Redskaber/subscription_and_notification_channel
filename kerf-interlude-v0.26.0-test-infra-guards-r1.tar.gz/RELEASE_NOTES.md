# kerf release notes

## v0.26.0 — interlude: test-infrastructure self-audit (inventory guards + audit label normalization)

The §9.57 review turned the audit lens on the test infrastructure
itself — the meta-domain the review genealogy had never surveyed
(r51 Symbol → r52 memory → r54 determinism → r55 diagnostics; the
verifier was the last unsurveyed component). Frontier anchors: the
rustc-dev-guide testing chapters (tidy enforces test-placement
discipline tree-wide; compiletest tracks stray output files;
distcheck verifies the tarball), rust-analyzer expect-test, and
cargo-mutants (K75-K77; three weak queries disclosed, one upgraded
to a primary-source direct read).

**What changed.** Three inventory invariants are now machine-guarded
(`tests/v1/stage1/plan/test_infra_guard_tests.rs`, the K75 tidy
family — mechanical, tree-wide, fail-closed):

- **TEST-1 — runner mounting guard.** Cargo discovers only top-level
  `tests/*.rs`; every deeper file runs only through a `#[path]` mount
  in `tests/runner.rs`. An unmounted file was a silent dead file —
  now both directions are asserted (every `.rs` under `tests/` is
  mounted; every mount target exists).
- **TEST-2 — corpus table/directory parity.** The per-case
  `corpus_case!` table and the 79-file corpus directory must carry
  exactly the same set (the old design tolerated a lagging table —
  the sweep covered validation but isolation degraded silently).
- **TEST-3 — audit case registration.** The gate-audit's headline
  "200/200" was a hardcoded literal over a three-form labeling
  convention (H07 shared H06's comment; sections U/V used single
  digits). The convention is now uniform — every case opens with a
  `// XNN:` comment (A-C comments added, H07 labeled, U/V widened;
  comment-only, zero behavior change) — and a guard asserts the
  per-section composition (A10 + B10 + C5 + D5 + 16×10 = 200) plus
  the headline literal. A detection-power arm feeds the counter a
  synthetic fixture with near-miss shapes (the r54 detector
  precedent).

**Tests.** +4 (three guards + one detection arm), zero pipeline
regression. Full suite **1174:0:0**, gate audit **200/200**, fmt
zero diff, clippy `-D warnings` clean. Registered windows (zero
signal, not opened): golden blessing tooling, mutation testing,
doc-count sync, distcheck automation. Stage 2 entry remains
explicitly prohibited (r54/r55, reaffirmed r56); test-tree-only
changes — no primitive, channel, VM, or grammar surface touched.

## v0.25.0 — interlude: diagnostics position single-sourcing (message/location separation + session line-index cache)

The §9.56 review surveyed the diagnostics domain end to end: the
structured `Diagnostic` type, the TD-001 line/column derivation, the
rustc-flavored renderer, the per-stage collection policy, and the
parity harnesses' error-axis comparison. The rustc-dev-guide
diagnostics chapter is the canonical anchor: a diagnostic message
"should be general and able to stand on its own" — position lives in
the `--> file:line:col` location line exclusively (K71).

**What changed.** Two findings were implemented in code:

- **DIAG-1 — position fragments leave the stage Display messages.**
  All four error families embedded positions in their `Display`
  (reader `at byte N` ×6, expander `at {span}` ×9, compiler
  `({span})` ×10, vm `({span})` ×11 — 36 sites), which double-reported
  against the renderer's location line and leaked the internal
  `file#0:15..16` byte form into user-facing output. Messages are now
  position-free; offsets and spans stay in the structured payloads
  (`offset()` / `span()`), and the location line is the single
  position render. Compiler `pc`/`slot`/`index` operands stay (they
  are semantic payloads, not source positions).
- **DIAG-4 — the session owns the line index.** `render_position`
  and `render_one` rebuilt `LineIndex::new(source)` per diagnostic
  (twice each across the width and render passes — O(source) per
  diagnostic). `Session::intern` now builds the index once per file
  (rebuilt on REPL upsert; rustc source-map / rust-analyzer line-index
  shape, K72), and the renderer fetches it through the fail-closed
  `Session::line_index`.

**A consequential fix discovered during implementation.** The parity
harnesses compare the oracle error against the rebuilt `.krf`-side
error through the shared `Display`; with positions gone from the
messages, two different payloads could render to the same text — the
drift detector would go blind. The error-axis parity key is now
`Display` + a harness-rendered position suffix (`@ byte N` /
`@ {span}`), the same shape the tree-axis dumps always carried
(`(define 0 36 x ...)`); tamper detection is proven restored by the
drift-detector and span-trap tests.

**Tests.** 29 assertion sites updated (the failing suite enumerated
them — zero guesswork), six render goldens re-baselined as a
documented intentional change (ds01/ds02/ds04/ds05/ds10 + e2e; the
ds03-via-1.1-wiring precedent), one new session-cache test. Full
suite **1170:0:0** (+1 net), gate audit **200/200**, fmt zero diff,
clippy `-D warnings` clean. Registered windows (zero signal, not
opened): per-variant error codes, within-file multi-error recovery,
suggestion engine. Stage 2 entry remains explicitly prohibited
(r54/r55); release-only render-golden and message changes, no
primitive, channel, VM, or grammar surface touched.

## v0.24.0 — interlude: compile-output determinism guard (the fixpoint gate-B prerequisite locked in tests)

The §9.55 audit classified all 61 non-comment HashMap/HashSet sites
across the ten pipeline crates: every map is keyed-lookup-only,
membership-only, or insertion-order-indexed (the `Vec` +
`HashMap`-as-index shape — a hand-rolled IndexMap, K69); no site lets
hash iteration order leak into compiler output. The numeric edge
semantics face (checked i64 arithmetic, NaN-canonicalized constant
pool keys, bit-identical NaN equality) was re-verified as already
hardened.

**What changed.** The property was implicit; now it is locked: a new
root-tree guard family double-traverses the real fixpoint subjects
(the assembled reader behind its own token table, the macro library
assembled ahead of the expander behind a forms-stream prefix — the
gate-B recipe) and the full 79-case corpus through two independent
reader -> expander -> loader -> compiler instances, asserting
structural equality of the expanded items and the bytecode. Three
detector-detects tests prove the comparison catches pool/table/code
divergence, and one semantics test documents the first-use ordering
discipline of the global table (source order, never hash order).
Four invariant comments now pin the discipline at the sites it rests
on (`intern_const`/`intern_global`, the trigger-set union, the GC
root scan, the sweep loop). Zero behavior change; tests +7.

**Why now.** Stage 2's exit criterion (2) — two self-compilations
byte-identical — rests entirely on this property, and the user's
standing review directive ("review the whole pipeline, implement the
fixes, do not converge") flagged the determinism domain as the
remaining unreviewed face after the §9.46-§9.53 lineage closed. The
round also registers the user's explicit "no stage 2 entry" ruling
(stage-2-plan.md §0 r54 note): the confirmation gate flips from
"awaiting" to "explicitly prohibited" until lifted.

## v0.23.0 — interlude: symbol interning (the user-flagged representation gap closed in code)

The identifier payload swaps from owned `String` to an interned
`NonZeroU32` index (stage0.md §9.52) — the user's four-times-flagged
review item, now implemented rather than registered. Both phase-twin
types (`kerf_core::Symbol`, `kerf_syntax::StxSymbol`) keep their public
APIs byte-identical; only the private payload changes, and each layer
owns its own global interner (leaked `&'static str` map — the
matklad-style simple interner, K54; the rustc `Symbol = interned
identity` shape, K6/K54b).

**Why now.** The three previously registered triggers (LSP window,
B-series hotspots, selfhost self-compile load) stayed zero-signal, and
that assessment stands. The window opened on the user directive itself
(rounds 42/47/50/51) plus a blueprint-implementation gap: the design
blueprint's `Identifier(Symbol) // interned string` assumed interning
all along. Stage 2 benefits directly — capture descriptors (LA-2) can
key on symbol identity instead of text comparison.

**What it buys.** Equality/hashing become index operations, cloning
becomes a bitwise copy (every `CoreExpr`/`StxDatum` clone gets
cheaper), and `Option<Symbol>` keeps a 4-byte niche layout in the
compiler and vm frames.

**What it costs (informed tradeoffs, §9.52.3).** Interned text lives
for the process (leak-by-design — the classic interner tradeoff,
CLR/Python pool pitfalls surveyed as the con-side anchors);
`as_str`/`Display` take one uncontended mutex; `Ord` now means
first-intern order, not lexicographic (whole-tree ripple audit: zero
ordering consumers — every `sort` site sorts `String`/`&str`, no
`BTreeMap<Symbol, _>` exists); language-level strings (`Value::Str`)
are NOT interned — identifier identity and string data stay two
worlds. The `Copy` trait is deliberately not derived (a whole-tree
`clone_on_copy` churn for no semantic gain; revisited with LA-2).

**Guardrails.** `Debug` is hand-written to reproduce the old derived
`Symbol { text: "x" }` shape byte-for-byte, so goldens and diagnostics
are index-independent. Tests grow by 17 (10 unit + 7 cross-crate
integration: symbol-heavy programs on both engines, shadowing, parity
contract drift detection, unbound-name diagnostic fidelity): 1162:0:0,
audit 200/200, fmt clean, clippy `-D warnings` clean. B-series all
in-band: B1 at 7.7µs (a new low — the interning dividend), B3 +11%
(evaluator display-path lock cost, recorded as measured).

Zero language-surface change: 8-primitive invariance round 25, subset
frozen faces untouched, selfhost parity byte-identical. Stage 2 entry
still pending user confirmation (SOP §14.6.3 rule 5).

## v0.22.0 — Stage 1 close: the exit round (deep-review family + seven-piece finals + nine-signal audit, GO recommended)

Stage 1 ends (stage-1-plan row 1.9; docs/stage0.md §9.50 — the
fifth and last review segment closed the lineage with zero
findings). The exit claims are re-runnable, not narrated.

**The review lineage completes.** §9.50 gives the checker domain
(R1-R8) its per-rule survey — the only pipeline domain left — and
it is the lineage's single zero-finding segment: the conservative
discipline (definite-errors-only + the assign over-approximation
guard), the double mirror (compiler resolution order + expander
sequencing), the severity split (E0008/E0011 warnings), and the
dynamic-soundness boundary (R5-R7 at top level only) all hold. The
frozen layers (span/syntax/core) close with a git-audited zero
drift since Stage 0.

**The audit grows to 200 with section V — one case per §21.5
signal.** Semantic stability (builtin families, both engines),
bootstrap verification (gate B on a composite source), coverage
(the corpus replay), the performance baseline (the live budget
face: frames share the allocation budget; zero budget fails
closed), documentation sync (render goldens), handling degrees
(the frozen cardinalities: 18 builtins, 24 opcodes), debt zero
(the assembled expander + a clean recursive program both produce
zero findings), outer-loop auditability (the section set itself),
cross-stage verification (the full pipeline dataflow), and the
recovery close. A new root test family (`stage_exit_tests.rs`,
ten cases) carries the same anchors as permanent cargo tests.

**The deep-review family lands as finals.**
`deep-review-round1.9.md`: D1-D8 all pass, the §14.8 deviation
list adjudicates eight items (every B3/B4 already written back
per-round, the B1s enter Stage 2 planning, the constitutional item
is zero-deviation), C1-C6 closes with zero cleanup actions
(fourteen consecutive clean rounds), and the committee votes
5.5/5.5. The seven-piece set completes: architecture scores +
extension costs, the four gap lists (all empty for Stage 1
obligations), hidden-problem growth ratings (no mandatory fixes),
the refactoring verdicts (five rounds, every rejected alternative
recorded), the 1.9 performance re-run (B1 at 9.4µs — the whole
stage stayed within ±2% of its entry point), and
final-assessment.md with all nine §21.5 signals checked plus the
§14.7 C1-C6 cross-stage chapters.

**GO is recommended for the Stage 1 → Stage 2 transition.** Per
SOP §14.6.3 rule 5 the final gate is user confirmation. The Stage
2 entry plan: the §21 planning round first (backend strategy +
capability maturity re-check), then the lexical-addressing +
capture-activation first knife, with the 1.8 institutional lesson
(island capabilities wire to the driver face in their own delivery
round) as a standing acceptance clause.

- Tests: 1145 passed / 0 failed / 0 ignored (Stage 1 total: 767 → 1145)
- Audit: 200/200 (A-V twenty-one sections; V = the nine-signal exit evidence)
- td register: zero open items, fourteen consecutive rounds
- 8-primitive invariant: twenty-third verification round
- B1-B5 at exit: 9.4µs / 97.45ms / 9.4ms / 0.372ms / 97.0ms (in band)

## v0.21.0 — Stage 1.8: gate-prep (full-set gate re-run + HM wiring + calibration + seven-piece skeletons)

The Stage 1 endgame-prep round (stage-1-plan row 1.8; docs/stage0.md
§9.49 — GATE-1..GATE-4).

**The HM layer joins the driver pipeline (GATE-2, the plan-1.3
"1.8 agenda").** `pipeline.typecheck()` now runs both static layers
in one batch — the conservative rules (R1-R8) and the inference
engine (E0009-E0011) — with the soft-typing severity contract kept:
definite errors block, the E0011 budget warning never does.

**Wiring it immediately exposed a 1.3-layer false positive.** The
assembled `.krf` expander (a legal 1.4k-line program, parity-
verified on both engines) was rejected with E0009: argument-shape
unification was reporting heterogeneous tag dispatch (one parameter
fed different tuple shapes at different call sites — legal dynamic
code) as a definite error. The hardening is *release-and-demand*:
a failing argument-shape constraint is rolled back and released,
never reported; the single body-sensitive binding source (an if
condition forcing a parameter metavariable to bool) keeps its
definite-error reporting through a per-define demand table —
`(define f (fn (x) (if x 1 2)))) (f 1)` still blocks, the tag
dispatchers run. FP3 hardening anchors both halves; the audit U1c
case pins the assembled expander to zero error-level findings.

**Gate re-run (GATE-1).** The audit set re-runs the whole Stage 1
family (A-T) and grows to 190: the new U section carries the HM
wiring end-to-end, the §7.3.2 fix-boundary family of the 1.7
probe rounds (the four-head record grammar, three-generation macro
chains beyond the corpus, the mangled-field tamper detector, the
assembly-order neutrality, the Macro sentinel at zero), and the
cross-sub-stage sweep (1.0-1.7 full chain on both engines).

**Calibration (GATE-3) + seven-piece skeletons (GATE-4).** The
calibration pool backfills the 1.4-1.7 verification rows and the
Stage 1 summary (tests 846→1135, twelve consecutive rounds of zero
runtime-semantic defects, TD register at zero); the institutional
lesson — *an island capability must reach the driver face in its
own delivery round* — is written into the 1.9 exit-review clauses.
The §14.6.6 seven-piece deep-verification set lands as skeletons
with pre-filled evidence and per-document 1.9 obligation tables.

**Corpus expectation co-variance (all probe-verified).** Five
negative cases re-freeze their directives for the two-layer batch
(neg-031/037 gain E0009; neg-041/044/047 move from runtime-error to
type-error E0009 — the checker now catches them first); ds02 keeps
its runtime render face through an HM-released dynamic parameter
and gains a checker-face golden (ds02b).

- Tests: 1135 passed / 0 failed / 0 ignored (baseline 1128 + net 7)
- Audit: 190/190 (A-T full re-run + U10 — the §7.3 gate-prep form)
- td register: zero open items, twelve consecutive rounds
- 8-primitive invariant: twenty-second verification round

## v0.20.0 — Stage 1.7: the .krf macro layer, third segment (macro parity + fixpoint gate B)

The third self-hosted front-end segment lands: the macro layer of the
expander, rewritten in the frozen kerf subset itself and checked
against the Rust expander oracle byte-for-byte (stage-1-plan row 1.7;
docs/stage0.md §9.48 — the BS-C 1.7 segmentation: MX-1..MX-6).

**The assembled program (MX-2).** `selfhost/v1/macro.krf` is a pure
function library — registration validation, fixed-arity matching, the
six-step instantiation order, rename-on-capture — assembled ahead of
`expander.krf` into one program by the host (the module-vs-crate
mirror: transformer.rs is a module of kerf-expander, macro.krf is a
library of the expander program).

**Rename encoding (MX-1).** The frozen subset has no string
construction, so a renamed introduced identifier rides as a structured
`("mangled" s e base counter gen)` record; the host decodes
`format!("{base}__macro_{counter}")` for the byte comparison — parity
observes the decision face, the deterministic rendering stays
host-side (the 1.5 float-as-Debug-text precedent).

**Generation threading.** Every input record carries a trailing
generation int (source records ride 0; macro products carry
use_gen + 1 — pos-032 exercises the two-generation chain). The dump
TEXT grammar is unchanged; the host rebuilder consumes the generation.

**The Macro layer collapses (MX-3).** The 1.6 three-layer split
collapses: define-syntax sources run the assembled program on both
engines; the Macro enum value survives as a zero-routing sentinel.

**Fixpoint gate B (MX-6).** Two axes cash in subset-spec §4's
reserved criterion: (a) bytecode equality — `compile(rebuild(krf
items)) == compile(oracle items)` over the macro corpus and the
assembled source applied to itself; (b) the self-application
fixpoint — the assembled program expands its own source, three-way
agreement (vm / eval / oracle).

**Corpus 72 → 79.** pos-031 (literal table), pos-032 (two
generations), pos-033 (hygiene binder collision — rename-on-capture's
first corpus exercise), neg-050/051/052/053 (pattern mismatch,
duplicate pattern variables, the ellipsis boundary, module-scoped
macro visibility).

**Numbers.** 1128:0:0 (net +30), audit 180/180 (new T section, ten
cases), B1-B5 performance within band, zero open technical debt
(twelfth consecutive round).

---

# Release Notes

## v0.19.0 — Stage 1.6: the .krf expander, second segment (expansion layer)

The second self-hosted front-end piece: the expander's *expansion
layer*, rewritten in the frozen kerf subset itself and running on
both engines, checked against the Rust expander oracle
byte-for-byte (stage-1-plan row 1.6; docs/stage0.md §9.47 — the
BS-C 1.6 segmentation: EX-1..EX-5).

- **`selfhost/v1/expander.krf`**: the full expansion layer in ~640
  lines of frozen-subset kerf — all four declaration heads (both
  define shapes with letrec pre-binding, require's string domain,
  module frame isolation, define-syntax as the fail-closed
  macro-layer marker), all eight expression forms, the `do`→flat
  `Let` desugar with the discard binding, `quote`→Pair right-fold,
  let\* progressive binding, and the module loader (the LIFO
  worklist declare pass + three-color DFS with the gray-cycle path
  slice). The §9.47.3 seven span traps are mirrored one by one:
  the quote whole-form span, the fn-sugar name-atom span, the
  binding value-node span, the `do` identity, the set! name-atom
  error span, the handler whole-clause span, and the require
  symbol-name MalformedForm.
- **One self-recursive expander** (the REC-A lineage, third
  instance): the frozen subset bans define-level mutual recursion
  (neg-046), so the expression expander is ONE function; the
  variable-arity walks (argument lists, let pairs, do steps,
  handler clauses, fn assembly) ride five synthetic node modes
  (`mapx`/`letloop`/`doloop`/`clausemap`/`fnbind`) dispatched by
  tag at the same recursion point. Synthetic modes bypass the depth
  counter, so .krf depth tracks the Rust node depth exactly (the
  512 budget stays unreachable from pure source — the reader's 256
  cap has the 2× margin).
- **Flat pre-order forms stream** (EX-1): the host reads (single
  source) and injects `(define forms (quote (...)))` — one flat
  record list where a `("list" s e n)` record's n children follow
  it. The flat shape keeps 255-deep trees inside the reader's
  nesting cap (a nested encoding would need depth+3).
- **Three-layer split** (EX-3): sources the reader rejects are
  decided by the reader layer (six corpus files); sources declaring
  a macro (`define-syntax`) ride the Macro layer — pos-024 and
  bnd-010, decided by the oracle with the .krf layer not exercised
  (`SyntaxRules` is the 1.7 window); everything else runs the .krf
  expander on both engines.
- **Corpus extension 68→72** (§9.47.4, the extension-duty table):
  pos-029 (string require + the three comparison builtins + an
  uncalled read-line), pos-030 (nested module declaration), neg-048
  (the string-name module cycle — `ModuleCycle` becomes
  corpus-reachable), neg-049 (`ModuleNotFound`). Expectations
  frozen through the probe round (all four correct on first
  validation).
- **Two-faced bootstrap fixed point**: the structural face (the
  expander's own source minus the hosting tail, expanded to the
  same 49-item tree on both engines and the oracle) and the error
  face (the bare source — oracle and both engines agree on the
  unbound `forms` at the exact same span: the hex0-layer hosting
  dependency made visible by self-application).
- **Nameability completions** (the 1.5-b kerf-reader precedent,
  third and fourth instances): kerf-compiler re-exports
  `CoreExpr`/`Binding`/`HandlerClause` (they ride ModuleItem's
  public shape); kerf-expander re-exports `CoreError` (it rides
  ExpandError::Core's public shape). Zero new Cargo edges.
- Six commands all green: **1098:0:0** (1069 baseline + 29: seven
  harness inline, eighteen integration, four corpus cases) · gate
  audit **170/170** (the new S section mounts the expander-parity
  meta-audit) · B1-B5 performance baselines unchanged.

## v0.18.0 — Stage 1.5: the .krf reader, first segment (structure layer)

The first self-hosted front-end piece: the S-expr reader's
*structure layer*, rewritten in the frozen kerf subset itself and
running on both engines, checked against the Rust reader oracle
byte-for-byte (stage-1-plan row 1.5; docs/stage0.md §9.46 — the
K18 hex0-layer lineage: the host lexer stays the single source of
token truth while the .krf layer takes over structure).

- **`selfhost/v1/reader.krf`**: an iterative explicit-stack parser
  (one token per self-recursive step; frame = depth/open-start/
  items-reversed) written with only the frozen 18 builtins + 8
  special forms. The four parser-side rejections (unclosed innermost
  `(`, stray close, empty application before outer unclosed,
  nesting 257 at limit 256) are produced as *structured values* —
  the host rebuilds the `ReadError` and renders through the oracle's
  own `Display`, so message parity holds by construction.
- **Source-injected token table** (RS-1): the host lexes (single
  source) and prepends `(define tokens (quote (...)))` ahead of the
  reader source — the only typed data channel the frozen subset
  offers (strings are opaque; the read-line input-tape route is
  ruled out and re-registered as a second-segment obligation).
  Spans ride as decimal strings; floats ride as Debug text
  (inf/NaN have no .krf literal shape).
- **The parity harness** (`kerf-driver::reader_parity`): dual-axis
  normalization (tree dumps) + error reconstruction + dual-engine
  runs (handles stay alive for heap walks), with a layer split —
  lexer-side rejections are decided by the single-source lexer
  (the six-variant family is the second-segment window).
- **Coverage**: 1069:0:0 (net +23), audit 160/160 (new Section R),
  the 68-case Stage 1.4 corpus replayed in full as reader inputs,
  the 255/256/257 nesting boundary, two drift-detector self-checks,
  and the bootstrap fixed point (the .krf reader reads its own
  source's token stream).
- Docs: stage0.md §9.46 (v9.12 — K18-K21 anchors, the subset
  expressibility audit, the B3 scope correction), plan-1.5.md,
  reader-parity.md.

## v0.17.0 — Stage 1.4: the kerf subset freeze (.krf self-hosting target surface)

Stage 1.5-1.7 will rewrite the compiler front end *in the kerf
subset itself*; this release freezes what that subset is, pins it
with an acceptance corpus, and lands the parity contract the rewrite
will be judged by (stage-1-plan row 1.4; docs/stage0.md §9.45).

- **The subset spec** (`docs/develop/v1/stage-1/subset-spec.md`): an
  honest freeze of the implemented surface — 4 declaration heads, 8
  expression special forms, 18 builtins, 6 literals, 9 core
  constructors, 4 module items — every row anchored to its code
  source, with the exclusion faces registered explicitly (macro
  trigger surface stays a 1.7 item; quote rejects symbols; I/O is
  the §8.8 minimal set with `write-line` string-only).
- **The acceptance corpus (68 cases)**:
  `tests/v1/stage1/corpus/*.krf` — directory-form data files with
  in-file `;; expect:` directives (the GCC-torture `dg-*` pattern):
  26 positive, 32 negative, 10 boundary. Every expectation was
  verified against the real pipeline before freezing (probe round:
  68/68, zero guessed expectations).
- **Empirically adjudicated semantics, now pinned by the corpus**:
  closures do **not** capture outer bindings (both engines reject
  with `unbound global` — the checker's E0001 is the correct
  definite-error catch); forward references are rejected at
  expansion (defines-so-far; the R1 "all defines" view is the
  direct-construction face); `()` is a *reader*-stage rejection;
  `write-line` takes strings only.
- **The parity contract** (`kerf-driver::parity`): the BS-C Stage
  1.4 slice — `CorpusCase`/`Expectation`/`Observed`/
  `EquivalenceReport` + `validate`/`validate_all`, the closed
  directive grammar, and the dual-engine equivalence discipline
  (value/outputs/globals three-face agreement; runtime rejections
  must fail on *both* engines). `ParityReport` grows
  `globals_repr` (additive); the 1.5 dual-reader window extends the
  same report shape — nothing pre-built.
- **Audit Section Q (10 cases)**: the detector-detects meta-audit —
  wrong expectations must drift with both sides named, stage
  attribution both ways, exact code-set comparison, the no-define
  value convention, the batch face, and the closed grammar.
- **Numbers**: 1046:0:0 (from 953, net +93), audit 150/150 (new
  Section Q), zero new dependencies, zero new crates, B1-B5
  performance baselines unchanged (the contract is off the hot
  path).

## v0.16.0 — Stage 1.3: the Hindley-Milner inference base

The checker grows a real type layer: an iterative Algorithm W with
union-find metavariables, an undo log, SCC-partitioned define
processing, an effect-row collection face, and the Layer 2 typed
annotation IR — all inside `kerf-typecheck` (zero new crates, zero
new dependencies, zero pipeline changes).

- **Iterative everywhere (the A6 lineage)**: explicit task-stack
  tree walk, worklist unification, iterative occurs check and deep
  resolve — zero deep Rust recursion, bootstrap-friendly for the
  later `.krf` rewrite on the flat-stack VM. The 512 depth budget
  per define emits one `E0011` *warning* (never an error — deep but
  legal programs must keep running) and excludes the define whole.
- **The undo log is a soundness device**: bindings made while
  inferring an `if` branch are rolled back at the branch boundary —
  a leaked binding would flag dynamically-legal programs. Condition
  bindings persist (evaluation order); `Fn` bodies are the
  parametric contract itself.
- **SCC partitioning**: defines are grouped by the syntactic call
  graph (iterative Tarjan, dependencies first). Mutual recursion
  unifies through pre-bound metavariables within an SCC; cross-SCC
  references instantiate generalized schemas — same-module
  polymorphic reuse (`(id 1)` + `(id #t)`) is decoupled per use.
- **The conservative discipline holds**: `Dyn` is the one-way
  unknown top (if-branches join, never unify); assigned names never
  generalize (value-restriction analog); the 18 builtins are typed
  ad hoc at application sites (no type classes for a closed set);
  effect rows collect `Perform`/`Handle` with definite subtraction
  and over-approximate handler merges (row polymorphism stays the
  Stage 2+ TY-C window).
- **New diagnostics**: `E0009` type mismatch, `E0010` recursive
  type (occurs check), `E0011` inference budget exceeded (warning).
- **The Layer 2 typed IR**: `TypedExpr` mirrors `CoreExpr` with a
  type and effect row on every node; `TypedDefine` carries the
  generalized schema. The IS snapshot family freezes the
  deterministic dump byte-for-byte.
- **Numbers**: 953:0:0 (from 890, net +63), audit 140/140 (new
  section P), B1-B5 baselines unchanged (the inference layer is not
  in the compile path).

## v0.15.0 — Stage 1.2: property-based testing lands (DEA-13 closure)

The fourth testing layer joins the pyramid: snapshot / golden /
bootstrap-parity / **property**. `proptest` enters as a root-layer
dev-dependency only (never in the language pipeline or the bootstrap
chain), and the first three invariant families of the §9.34.5
checklist go live as seven properties.

- **The seven properties** (tests/v1/stage1/plan/pbt_seed_tests.rs,
  mounted through tests/runner.rs): dual-engine parity on arbitrary
  well-formed programs (FP1), the runtime unhandled-effect trap on
  both engines (FP2), handle-perform reduction fused with a concrete
  arithmetic oracle (FP3), the static E0006 propertified across the
  whole effect-name space (FP4 — the 1.1 finite samples generalized),
  the reader fixed point of display (FP5 — the caliber disclosure:
  `StxDatum::Display` is the diagnostics face, not a serialization
  face), VM dispatch determinism across fresh instances (FP6), and
  integer addition against the host checked-add oracle (FP7).
- **Typed generators** (the well-formed domain): a three-channel
  expression generator (Int / Bool / Any — depth-capped, ±2^40
  oracle band), safe symbol pools (zero keyword / zero builtin
  collisions, self-tested), and a float domain restricted to the
  exact Debug-parse roundtrip band.
- **First-run honesty**: the initial PBT round failed 4 properties —
  all generator-domain or assertion-face issues (the reader rejects
  `()` and `(fn () …)` — the frozen EmptyApplication grammar fact;
  declaration-only programs halt at nil, so FP3/FP7 assert on the
  define slot instead of the program value), zero dual-engine
  divergences: the property layer found no new defects in the
  shipped implementation, which is exactly what DEA-13 closure
  should look like on a green baseline.
- **Numbers**: 890 tests green (881 baseline zero-regression + net
  9: 7 properties + 2 domain self-tests; 64 cases × 7 properties =
  448 generated programs); the audit set stays at 130/130 (PBT and
  the exhaustive-sample audit are complementary domains — the ruling
  is recorded in plan-1.2.md §4); one new dev-dependency (proptest
  1.11.0 — the ^1.9 constraint resolves to the latest 1.x), zero
  production-dependency changes; baseline co-changes: the ds08
  version golden moves to 0.15.0, Cargo.lock gains the dev-side
  tree.

## v0.14.0 — Stage 1.1: driver wiring (typecheck stage in the pipeline + diagnostic-render join + the first Warning producer wired)

The checker joins the pipeline: `read -> expand -> typecheck ->
{compile, eval}` on every face (run / check / parity / REPL).

- **Abort semantics (ruling at implementation)**: Error-level
  findings (R1-R7) abort *before execution* — a definite error means
  the program cannot behave as written, so neither engine runs it;
  Warning-level findings (R8) never block: they ride on the outcome
  (`RunOutcome` / `CheckOutcome` / `ParityReport` gained a
  `warnings` channel), the CLI prints them to the diagnostics sink,
  and exit codes stay untouched.
- **The render join** (stage-1-plan §4 fulfilled): the driver's
  stage-level `DiagnosticCode` gained a data-carrying
  `Typecheck(TypeCode)` variant whose tag *is* the E0xxx registry
  string — diagnostics render rustc-style `error[E0002]:` /
  `warning[E0008]:` with the byte-precise `--> file:line:column`
  locations. Multi-diagnostic batches gained a
  `warning: N warnings emitted` summary line (before the abort line,
  rustc order); warning-free batches render byte-identically to the
  Stage 0 form (the ds10 golden freeze holds), and warnings-only
  batches no longer claim an abort they never made.
- **REPL warning replay**: the session-replay semantics extend to
  warnings — the whole program re-runs per submission, and the
  rendered warnings delta-print under the same prefix rule as
  outputs (shown once, silent on replay, new findings are news).
  Warning submissions enter the accumulated program (legal); only
  errors roll back.
- **Externals, third consumption site**: the driver builds the
  checker's table from the two authoritative sources only
  (`STAGE0_GLOBALS` names + `Builtin::ALL` arity triples — the
  single-source discipline; same construction as the root tests and
  the audit).
- **Baseline co-changes, five disclosed sites**: known-callee arity
  mismatches now surface statically (E0002) before the runtime face
  — the runtime coverage moves to checker-opaque param-mediated
  shapes (`((fn (g) (g 1 2)) car)`); the ds03 snapshot golden updates
  to the static form; ds08 tracks the version bump (0.14.0). A
  design-level validation surfaced on the way: an earlier
  `(set! car 1)` in the REPL correctly poisons `car` for R2 (the
  assign guard spans submissions) — conservative discipline working
  as specified.
- **Numbers**: 881 tests green (846 baseline zero-regression + 35
  net: 17 positive / 18 negative — the non-blocking / abort / render
  / replay guard families in dual balance); audit set 120 -> 130
  (section N: source-reachable E0xxx end-to-end, abort-before-
  execution, warning channels on every face); seven error classes
  stay 7/7; zero new external dependencies (one internal edge,
  L4.5 -> L8).

## v0.13.0 — Stage 1.0: kerf-typecheck seed (E0xxx registry + conservative static R1-R8 + multi-error collection)

Stage 1 opens (the stage-exit GO from 0.12.0 confirmed). The first
sub-stage delivers the external-Rust type-checker path (the §21.6
circular-dependency mitigation): a conservative static checker over
expanded programs, the E0xxx diagnostic registry, and the ruling-21
multi-error collection architecture.

- **The conservative discipline** (docs/develop/v1/stage-1-plan.md §3,
  the authoritative definition): every rule R1-R8 reports only
  *definite* errors, each with a recorded soundness argument. The two
  mirrors keep resolution honest — the compiler's locals-then-globals
  order (`lookup_local` -> `intern_global`) and the expander's
  define-so-far + letrec pre-bind discipline. Position-aware
  visibility: top-level immediate positions see defines-so-far; Fn
  bodies see every define (call time is post-load).
- **R1** unbound reference — the structural-layer re-assertion behind
  the expander's first line of defense (serves directly-constructed
  programs). **R2** known-arity mismatch (IIFE / define-to-Fn /
  builtin arity, under the assign guard and lexical-shadow skip).
  **R3** non-boolean literal condition. **R4** non-callable callee
  (literal directly, or a no-reassign literal define). **R5** handler
  arity mismatch on routed top-level performs. **R6** top-level
  unhandled perform (module load has no dynamic context — the lexical
  handle is the only possible router). **R7** non-callable literal
  handler. **R8** assignment-target surprise — the first Warning
  producer (implicit global creation / builtin rebinding; legal
  semantics, surfaced per report-over-silence).
- **The effect-family soundness key**: performs inside Fn bodies are
  never lexically routed (dynamic handlers may exist at call time) —
  R5-R7 apply to top-level immediate performs only; the walk mirrors
  the Handle compilation order (handler values evaluate before their
  own clauses install).
- **The E0xxx registry** (TypeCode E0001-E0008 + two-level Severity +
  TypeDiagnostic with byte-precise spans) activates the variant-level
  code scheme registered in Stage 0; messages stay single-source with
  the RuntimeError family (R2 mirrors ArityMismatch wording).
- **The Externals face** keeps the builtin table single-source:
  callers construct it from `STAGE0_GLOBALS` + `Builtin::ALL` (the
  root tests, the audit example, and the 1.1 driver wiring are the
  three consumption sites).
- **Layer disclosure**: R2-R7 statically catch what is runtime-only
  today (ArityMismatch / TypeMismatch / UnhandledEffect move to
  compile time) — the checker is a validator, never an executor
  (stage0.md §9.24 TY-A).
- **Housekeeping**: TD-006 cleared (stage0.md header version tag
  synced v8.8 -> v9.9, four-place consistency, user-instruction
  window) — the tech-debt register is at zero open items. PBT
  dependency review concluded DEFER-WITH-TRIGGER (proptest enters at
  1.2 with its first real consumers). Zero new external dependencies
  (two internal edges: kerf-span + kerf-core).
- Tests: 767 -> **846** (net +79: 51 inline + 7 api + 21 root
  integration over the real read->expand->typecheck pipeline); audit
  set 110 -> **120** (section M); seven error classes 7/7 maintained.

## v0.12.0 — Stage 0.11 final round: snapshot suite + performance baseline + stage-exit review

Stage 0 closes. The final L3 round delivers the last two §22.3
milestone items (L6 ≥50 snapshot tests, L8 performance baseline),
runs the full deep-review family, and checks every stage-exit
signal — the stage-exit review concludes GO (pending user
confirmation per §14.6.3 rule 5).

- **The snapshot suite** (`tests/v0/stage0/plan/snapshot_seed_tests.rs`,
  57 cases ≥ 50): one fixed input frozen into one exact output string
  per case, across every pipeline layer — reader skeletons (RS01-10),
  expander trees covering each of the nine primitives in its direct
  form (ES01-10), per-instruction bytecode listings (CS01-10, the
  `op a b` machine form), VM/eval terminal state including the
  compile-ordered globals table and opaque display forms
  (VS01-10 + VE01-02), driver rendering goldens for six negative
  paths plus the check/parity/version/output faces (DS01-10), and
  REPL transcripts with rollback and continuation (TS01-04 + VD01).
  Goldens were recorded from the verified 0.10-r3 baseline via a
  temporary probe, eye-checked line by line, and frozen inline;
  they change only with an explicit behavior change logged in the
  worklog.
- **The performance baseline** (`examples/bench/stage0_baseline.rs`
  re-runnable via `cargo run --release --example stage0_baseline` +
  `docs/develop/v0/stage-0/performance-baseline.md`): B1 compile-fib
  9.3µs median, B2 vm-run-fib(25) 96.7ms (≈2.4µs/call), B3
  eval-run-fib(20) 9.4ms, B4 gc-pressure churn 0.36ms with 1 cycle
  and 1023 swept cells per iteration on the collect-then-retry path,
  B5 driver end-to-end 97.6ms. Regression bar: median worsening
  >25%, or any change in the B4 behavior counters. std-only tooling
  (zero new dependencies).
- **The deep-review family** (§14.5/§14.6/§14.8/§14.9):
  `deep-review-round0.11.md` (D1-D8, committee vote 5.5/5.5, the
  §14.8 deviation ledger B1×2 / B2×3 / B3×3) plus the seven
  inter-stage documents — dataflow coverage (enum exhaustiveness
  with zero unwraps and 33 justified expects), architecture review
  (nine stages all green), design-impl-test three-way coverage
  (zero gaps), hidden-problems assessment (zero P0/P1, zero
  mandatory-fix items), refactoring optimality (7/7 + 8/8),
  performance baseline, and `final-assessment.md` (§22.3 twelve
  items all checked, §21.5 nine switch signals all checked, C1-C6
  cross-stage audit — GO).
- **Code grooming (§14.9)**: two historical-tense file-header notes
  corrected in place (the seven-class coverage note in kerf-vm, the
  diagnostics extension ownership note in kerf-driver); zero TODO /
  FIXME / unimplemented / todo markers, zero glob re-exports.
- **Numbers**: 710 → 767 tests (+57 snapshots; 50:7 positive:negative
  — reverse deviation declared, the determinism-contract layer is
  structurally positive, error-detection semantics stay with the
  existing 7/7 classes), audit set 110/110 re-run green, six
  commands green, R8 encoding face clean on all new files.

## v0.11.1 — Stage 0.10-r2 Capability-model reservation generalization

The capability reservation becomes a SPACE, not a point (user
explicit instruction — adjudication 20). What the reservation
reserves is no longer the concrete io model: it reserves the ability
to register and extend abstract capability models themselves.

- **The capability space** (`kerf-core/src/reserved/capability/`):
  the family contract (`CapabilityModelFamily` — identity card +
  closed error face, no operation signatures: the no-prediction
  discipline), the token calculus (`TokenCalculus` — the sealed-token
  discipline and its registry vocabulary term), the registration &
  extension mechanism (`CapabilityModelRegistry` — register / lookup
  / governing_model / governed_authorities, fail-closed on
  InvalidDescriptor / DuplicateModel / AuthorityConflict, rejected
  registrations mutate nothing), and the io sub-model re-hung as the
  first concrete model (`IoModel` — Error pinned verbatim to the
  frozen IOError; identity card "io" / ["io.read", "io.write"] /
  "CapabilityIO"). Space relations are constraint combinations, not
  inheritance (stage0.md §9.10.2); the registry's unique-subordination
  rejection is axioms A3/A4 made machine-checked (§9.13.2).
- **Freeze continuity (adjudication 17 discipline)**: the 0.10-r1
  module path `reserved::capability_io` survives as a re-export of
  `capability::io` — TypeId identity proven in tests; all four r1
  consumer faces (api tests, root integration tests, the audit set,
  the docs) compile with zero changes.
- **Extension proven at four positions**: a locally-defined model
  (the canonical clock resource — the object-capability lineage's
  fs/net/clock set, knowledge-search verified) registers into the
  same closed world as io from inside the crate, the api position,
  the workspace root, and the audit example — zero framework changes
  each time (the open-closed principle at the organizational layer).
- **Numbers**: 672 → 710 tests (+38: unit 27 / api 6 / root 5;
  25:13 positive:negative — reverse deviation declared, the
  fail-closed family contributes 11 negative cases), audit set
  100 → 110 (section L), six commands green, R8 encoding face clean.

## v0.11.0 — Stage 0.10 Reserved-interface freeze

The Stage 0 interface-reservation milestone: the four reserved
contract families of docs/stage0.md §22.3 are frozen — "interface
defined, implementation may be empty". The milestone checklist's four
interface items (Effect Handlers / multistage programming /
capability-model I/O / compilation cache) are all checked.

- **One freeze anchor, four families (adjudication 17)**: everything
  lives in `kerf-core/src/reserved/` — the L4 semantic-authority
  crate, reachable by every downstream crate and the workspace root.
  The face is *fully self-contained*: zero inbound edges beyond
  `std` (the language value is an associated type, not the VM value —
  L4 never depends on L6; the cache payload is opaque bytes, never a
  typed compiler product). "Depend on abstract constraints, not
  concrete implementations" (SOP §21.12-10(2)) lands in its strongest
  cold-start form, with the six-domain affiliation declared as module
  documentation (the kerf-space marker family stays a Stage 1+
  registration; re-anchoring onto it is additive).
- **Compilable translation of the blueprint sketches (adjudication
  18)**: the §9.1.1-§9.1.4 pseudo-code shapes become real Rust —
  companion traits (`EffectOp`, `CodeCarrier`) carry the
  `Self::Effect::Result` / `Self::Code::Inner` paths verbatim in
  meaning; `impl Expr` becomes an explicit generic; the §9.3.1 vs
  §9.1.1 vocabulary drift resolves in favor of the §9.1.1 block with
  mapping notes (the kernel-level `HandlerClause` stays the primitive
  arm; the reserved `Handler` associated type is the system face).
  Two naming disclosures: the reserved `MultiStage::quote` is the
  staged-code constructor (Stage 2), distinct from the 0.9 datum
  literal; the reserved `Code` is not the expander's `CodeValue`.
- **`effects` (P3)**: `EffectSystem` with `Effect: EffectOp` /
  `Handler` / `Continuation` / `Value` associated types and the
  `perform` / `handle` signatures frozen. Primitive semantics stay in
  the kernel (`CoreExpr::Perform` / `Handle`); Stage 2 owns the
  language-level system.
- **`multistage` (P3)**: `MultiStage` with `quote` / `splice` / `run`
  over a `CodeCarrier` — the Stage 2 staged-programming face.
- **`capability_io` (P3)**: sealed zero-sized tokens
  (`ReadCapability` / `WriteCapability`, hand-written bare-name
  `Debug`), the closed `IoErrorKind` set (Eof / Denied / Interrupted
  / Other), an R8-shaped `IOError`, and the `CapabilityIO` trait.
  Token construction is closed outside the defining crate — no
  public constructor exists at Stage 0 (minting/delegation is the
  Stage 1 additive window; default-deny is the Stage 0 discipline).
- **`cache` (P2 — signatures + executable behavior spec)**:
  `CacheKey` (a 256-bit content digest; the algorithm is a Stage 1
  implementation detail), `CachedResult` (opaque payload bytes —
  adjudication 19: the known follow-on needs of cross-session
  persistence and distributed caches are serialization-shaped, so the
  frozen face never pins a product type), `CompilationCache` with the
  three blueprint methods, and
  `check_compilation_cache_contract` — the behavior spec made
  runnable. Six contracts (store-then-get hit + value equality /
  never-stored miss / post-invalidate miss / no-op invalidate /
  latest-wins / cross-key isolation) assert against any
  implementation; Stage 1 caches reuse the kit directly as their
  contract tests. The kit's detection power is itself tested: five
  deliberately broken implementations (never-hit / no-invalidate /
  no-overwrite / wrong-key / payload-corrupt) are all caught.
- **Signature-stability snapshots**: canonical conforming
  implementors ("witnesses") live at four consumption layers (inline
  tests / crate api tests / workspace-root integration / the audit
  example) — any drift in the frozen shape breaks a witness
  compilation, which the six-command acceptance turns into a hard
  gate.
- **Counts**: 672:0:0 workspace tests (624 baseline zero-regression,
  net +48 — the roadmap agenda met verbatim; round 32:16 = 1:0.5
  reverse-skew declared: a reservation round's acceptance face is
  type existence and signature snapshots, structurally positive;
  negative-testable faces are exhausted — kit detection ×5, IOError
  four-kind paths, R8 shapes at two layers, token discipline). Audit
  set 90 → **100** (section K — reserved-face contracts; §7.1.1
  seven classes stay 7/7). Zero implementation-side runtime-semantics
  defects (all round fixes were compile-level or shape-level).

## v0.10.0 — Stage 0.9 Macro system seed

The Stage 0 macro milestone: the basic hygienic macro system
(`define-syntax` + `syntax-rules`), the structured `CodeValue`, the
module loading layer, and the `quote` datum literal. The SOP §7.1.1
error-class matrix reaches **7/7** — the module-cycle class lights up
end-to-end, at both the sub-stage and the gate threshold.

- **Hygienic macros, two complementary mechanisms (adjudication 14)**:
  scope coloring with the *binder-scopes subset* judgment (the 0.4
  membership rule generalized to Racket's "Binding as Sets of
  Scopes" — non-macro code is structurally unchanged, 551-test
  baseline zero-regression) decides expansion-time binding;
  *rename-on-capture* (the §9.38(b) second algorithm) carries the
  decision into the name-based back half (CoreExpr/bytecode/VM
  resolve `Var` by name — an introduced binder colliding with a
  spliced argument name is renamed to `name__macro_N` together with
  its introduced references). Observable proof: without hygiene the
  capture test yields 200, with it 101.
- **`define-syntax` / `syntax-rules`** (§8.10): fixed-arity patterns
  (the ellipsis `...` is a registered Stage 0 boundary — rejected at
  registration, fail-closed), literals matching by symbol text,
  `_` wildcards, pattern variables splicing use-site arguments
  *verbatim* (span/scopes/phase/name all keep their use-site
  identity), introduced nodes carrying generation+1 (the dea12b
  tracing contract — macros expanding into macros increment per hop).
  Macros are lexically scoped like defines (a nested module's macros
  vanish with their frame); a head naming nothing reports the unified
  unbound-identifier judgment (adjudication 16 — the Racket rule).
- **Module loading layer (§8.9 Stage 0 slice)**: `load_program`
  collects declared (nested) modules into the flat namespace,
  walks every `require` edge, and rejects cycles with a three-color
  DFS reporting the full path (`module cycle detected: a -> b -> a`)
  — **§7.1.1 class 7 lit, completing 7/7 at both thresholds** —
  plus not-found and duplicate declarations. The deliverable is graph
  validation + the dependency-first instantiation order (`LoadPlan`);
  visibility merging is the Stage 1 module system. The driver's
  `parse` runs it fail-fast; module diagnostics render with
  line:column locations.
- **`CodeValue`** (§6.3.3 Stage 0 projection): the structured
  macro-phase code value — `from_syntax`/`to_syntax`/`substitute`
  (the pattern-variable splice face)/`alpha_rename` (the
  rename-on-capture remedy face, public)/`symbols` (the honest
  Stage 0 census — the semantic `free_variables` is the Stage 2+
  slot)/`to_source` (the diagnostics observability face).
- **`quote`** (plan-0.7 decision 13 redeemed): atoms and proper
  lists fold into `LiteralValue::Pair` chains terminated by `Nil`
  (the 0.1 consumption face — `ConstKey::Pair` gets its first
  production consumer); symbols fail closed (`QuoteUnsupportedDatum`
  — no Stage 0 value carrier; the Stage 1 evolution slot).
- **`ModuleItem::DefineSyntax`**: the fourth declaration variant —
  a faithful declaration record with zero code (the `Require`
  precedent applied to the macro phase; compiler and evaluator both
  skip it).
- Adjudications 14/15/16 and 13 decisions recorded in plan-0.9.md §4
  (dual-mechanism hygiene; the `nil` empty-literals spelling — the
  reader rejects `()`, so `nil` is the language's empty-list
  spelling everywhere; the unified unbound judgment). Tests: net +73
  (34:39 — deviation declared: the four-stage macro E2E is the plan
  row's acceptance body), cumulative 624 green, audit set 80 → 90
  (section J), all seven error classes lit.

## v0.9.0 — Stage 0.8 Driver seed

The compiler entry point (Layer 8): pipeline orchestration over both
execution engines, the diagnostics rendering closure (TD-001 paid),
session/file interning, and the `kerf` CLI/REPL. Every crate of the
0.0 charter is now implemented — 9/9 (TD-003 cleared to zero).

- **Pipeline orchestration**: `kerf_driver::run_source` drives
  `read -> expand -> {compile -> VM, eval}`; `Engine::Vm` / `Engine::Eval`
  select the engine; `ParsedProgram` is the stable fork point (the
  same expanded program feeds both, exactly as the 0.7 cross-check
  established). `check_source` compiles + verifies without executing.
- **Parity as data**: `run_parity` runs both engines over the same
  input and compares three faces — final value repr, output
  sequence, and the define-name global table (`parity_repr` with
  both heaps alive — a divergence is *reported*, never a panic; the
  `--parity` CLI flag surfaces it as `parity: PASS/FAIL`).
- **Diagnostics rendering closure (TD-001)**: `LineIndex` derives
  1-based line + **character** column from byte offsets at render
  time (never stored — single source of truth); the renderer emits
  rustc-flavored `error[kerf-read]: msg`, ` --> file:line:col`,
  source excerpts with caret underlines (span-length, line-clamped),
  multi-diagnostic separation and a summary line. `Diagnostic` is
  the §8.7 slice: `Severity`/`DiagnosticCode`/`primary_span:
  Option<Span>` — position-less errors render without a fabricated
  location (no DUMMY spans, ever).
- **Session/file interning**: `Session` maps names to sequential
  `FileId`s with upsert semantics (the REPL re-reads one growing
  file); diagnostics render against the session's sources — the
  single source of truth.
- **REPL (session-replay semantics)**: both engines are per-program
  by design, so the REPL accumulates source and re-runs the whole
  program per submission; expressions wrap as `(define $repl:N expr)`
  (the r110 "top-level expression channel = define calling form");
  failed submissions roll back (the session survives any error); the
  input tape replays deterministically (a `read-line` past the tape
  ends with `Eof` — interactive stdin is the `run` mode's pipe).
- **CLI**: `kerf run <file> [--engine vm|eval] [--parity]`,
  `kerf check <file>`, `kerf repl`, `--help`, `--version`; exit codes
  0/1/2 (success / program-or-environment / usage); piped stdin feeds
  a run's `read-line` calls; hand-rolled parsing, zero dependencies.
- **Consumer-face extensions** (all additive): `ReadError::offset()`,
  `CompileError::span()`, `kerf_compiler::ModuleItem` re-export
  (ExpandError::span() existed since 0.4 — its doc comment named this
  sub-stage). New DAG edges L1->L8 and L7->L8 (ruling 11, plan-0.8).
- **Audit set**: 70 -> 80 (Section I: the five source-reachable
  error classes rendered end-to-end through the driver, multi-file
  multi-diagnostic collection, REPL rollback, check rejection,
  parity divergence-as-data, CJK character columns, position-less
  rendering). Error classes 6/7 held (module circular dependency
  stays DEFERRED to 0.9).
- **Fixed in-round**: TapeIo write recording (the VmIo face is the
  engine's single output recording point — a no-op face silently ate
  all REPL output) and stdin pre-read scoping (only `run` consumes
  piped stdin; the REPL reads its own submissions).

## v0.8.0 — Stage 0.7 Runtime seed

The runtime layer (Layer 7): the docs/stage0.md §19.4 mark-sweep
collector and the `eval` meta-circular evaluator — the dual-execution-
path cross-check goes live (the same expanded program runs through
`compile → VM` AND through `eval`; ≥15 programs agree structurally,
and the STAGE0_GLOBALS tables are officially asserted three ways).

- **GC (§19.4)**: mark bits and a free list live on the kerf-vm `Heap`
  (the heap-method skeleton verbatim — `test_and_set_mark`,
  `clear_marks`, `free`, slot iteration); the three-phase orchestration
  (explicit-work-stack mark — a 10^5-deep chain marks without host
  recursion; linear sweep; symmetric reset) lives in
  `kerf_runtime::gc` (Layer 7). `Roots` carries the four §19.4 root
  classes plus the handler-table extension (installed handler values
  are frame-adjacent state — missing them dangles handlers).
- **collect-then-retry** (the point error.rs announced at 0.6): the
  budget safety point now checks the LIVE footprint (frames + live
  cells); on exhaustion an injected collector runs one cycle and the
  charge retries. Without a collector the 0.6 fail-closed behavior
  stands; `Vm::with_collector` / `with_budget_and_collector` inject;
  `Vm::register_foreign_ref` protects host-held values (§19.4 root
  class four); `Vm::snapshot_roots` snapshots every class.
- **eval (the meta-circular evaluator)**: the nine semantic primitives
  interpreted directly over CoreExpr, mirroring the compiler/VM
  decision-for-decision — name resolution (tail-first scan,
  `lookup_local` verbatim; shadowing = new slots), evaluation order
  (§19.3: args left-to-right, then the callee), assign's Dup
  semantics, Require as a no-op, Module flattening, Handle's
  install-run-pop, Perform's nearest-handler rule. Closures are the
  "basic closure" P0 scope (free names resolve globally; the captured
  env is a dormant value snapshot — the 0.6 duality; lexical capture
  is a Stage 1 activation on BOTH engines). `EVAL_DEPTH_LIMIT`
  guards the Rust stack (the evaluator recurses in host frames while
  the VM stacks heap frames — a registered asymmetric boundary).
- **Builtin single source**: the 18 STAGE0_GLOBALS operation semantics
  extracted into shared kerf-vm functions (`arith`, `compare`, `car`,
  `cdr`, `cons`, `not`, `read_line`, `write_line`) — the VM and the
  evaluator call the SAME bodies (zero drift by construction, stronger
  than parity tests). The name/arity tables are asserted three ways
  (expander ↔ registry ↔ evaluator seeding).
- **parity**: `parity_repr` renders values structurally (pairs as
  dotted notation recursing both arms; closures and builtins as
  opaque forms — addresses never participate); `assert_parity`
  compares engines. Error parity is exact too: the same failing
  source produces the same variant AND the same rendered message on
  both engines.
- **Fixed (found this round)**: the evaluator's `invoke` swapped-out
  environment locals were outside the GC roots — a recursive call's
  in-flight caller values could dangle after a cycle; now
  root-protected through the evaluator's temp stack (§19.4
  explicit-roots class of a Rust evaluator), with program isolation
  (no lexical residue across `eval_program` calls) as the
  same-family backfill.
- `RuntimeError` grows to 11 variants (`EvalDepthExceeded`); the
  seven-class matrix holds at 6/7 (module cycles remain 0.9's). The
  audit set grows 60 → 70 (Section H: evaluator negatives + the GC
  retention guard + the parity-detector self-check). 427 tests green
  (71 new, 19:52 positive:negative — deviation disclosed in
  plan-0.7.md §3: the GC family counts entirely as defense-negative
  and the parity battery IS the acceptance criterion).

## v0.7.0 — Stage 0.6 VM seed

The bytecode virtual machine (Layer 6, a PERMANENT Rust base — rewriting
it in kerf is constitutionally excluded): the docs/stage0.md §19.5
switch-dispatch iterative main loop with heap-allocated call frames
(the TD-023 anchor — kerf-level recursion consumes the frame vector,
never the Rust stack). Source → value runs end to end for the first
time: fib(25) = 75025 executes on the full chain (reader → expander →
compiler → verify → VM).

- `Vm::new(bytecode)` runs the load-time verify hook (plan-0.5 ruling
  4, second line of defense) and seeds every STAGE0_GLOBALS name as a
  builtin value (18-name registry, `Builtin::ALL`); plain globals stay
  unbound until their `store-global` runs (`UnboundGlobal` on early
  loads — the dynamic-order face verify cannot decide statically).
- 24-op full execution: per-frame operand stacks, `pc` monotonicity
  with the closed jump/call/ret exception set, and the evaluation-order
  contract consumed exactly as the 0.5 compiler emits it (args
  left-to-right, callee on top — plan-0.6 ruling 5 reconciles the
  §19.5 skeleton drawing against the compiler's actual emission).
- `RuntimeError` (10 variants, every one carrying the source `Span`
  resolved through the debug_info table — the §12.1 consumption row):
  arity mismatches on both call faces and type mismatches across four
  contexts light SOP §7.1.1 classes 4 and 5 (6/7 lit); plus
  `UnhandledEffect`, `DivByZero`, `ArithmeticOverflow` (checked i64 —
  no wrapping), `BudgetExceeded`, `Eof`, `RetFromEntry`, and
  `StackUnderflow` (handler-stack face — §19.5 trap 2: explicit depth
  checks on every stack access, defense in depth over verify).
- Effects at 0.6 (plan-0.6 ruling 6): `perform` finds the nearest
  installed handler and invokes it as a function — the handler's
  return value IS the perform's value; real continuations stay
  reserved in the frozen ext1 frame slot (Stage 1+).
- The §19.4 allocation budget is the Stage 0 safety point: frames +
  heap cells share one `u32` budget (`DEFAULT_BUDGET` = 8 MiB), which
  bounds every non-terminating program (kerf has no loop primitive —
  all unbounded growth routes through calls and allocations). The 0.7
  collector hooks `gc_cycle` at the same point.
- Pluggable I/O (`VmIo`): `read-line` / `write-line` builtins over a
  deterministic `BufferIo` default (strict-string writes; the 0.8
  driver wires real streams).
- Fixed in passing (found by this round's nested-handle tests, §20.6
  full-class sweep): the 0.5 compiler's `end_closure` restored `cur`
  by decrementing — every program with a second, sibling, or nested
  closure past the first emitted into the wrong proto. Now restored
  through a saved-caller stack (`cur_stack`), with a two-case
  regression pair pinning sibling and nested closure shapes.

Verification (cold build, SOP §3.2): 0 error / 0 warning; fmt zero
diff; clippy `-D warnings` clean; **356 passed / 0 failed** (300
baseline + 56 new: 54 VM tests at 12:42 plus the 2-case compiler
regression pair; round ratio 14:42 = 1:3, cumulative 89:267 = 1:3);
`cargo run --release --example stage0_gate_audit_r1` — **AUDIT PASS
60/60** (A10 + B10 + C5 + D5 + E10 + F10 + G10).

## v0.6.0 — Stage 0.5 compiler seed

The bytecode compiler (Layer 5): CoreExpr -> Bytecode, implementing
the direct-style translation of docs/stage0.md §19.3 with jump
backpatching, a deduplicated constant pool, an interned global symbol
table, and the per-instruction debug_info table (§19.3 invariant 3 —
no bare instructions; §12.1: the VM resolves runtime errors back to
source through `Bytecode::span_of`).

- `compile_program(items) -> Bytecode` and `compile(expr) -> Bytecode`
  — the two public entries (program form ends in a depth-0 `halt`,
  single-expression form in a depth-1 `halt`).
- 24-op set: the §8.12 groups (stack / function / control flow / data
  construction / variable access / arithmetic / termination) plus
  `push-handler` / `pop-handler` / `perform` — the frozen
  Perform/Handle primitives (TD-005) carried directly. Every operand
  slot's meaning is declared on the opcode (`Opcode::operand_help` —
  "operands fully resolved").
- Eval-order contract (§19.5): args left to right, callee on top;
  `call n` pops n + 1 and pushes the result. Tail-position `if`
  compiles branches straight into the proto terminator with no merge
  jump (§19.3 trap 1) — Stage 1+ TCO only rewrites the compiler, never
  the VM. `handle` bodies compile non-tail (handlers pop before
  return; tail pass-through is registered Stage 2 effect-elimination
  theory).
- Defense in depth (plan-0.5.md ruling 4): compile-time bookkeeping
  (depth tracking, patch assertions, placeholder drain — all
  structured `CompileError`s) plus a public `Bytecode::verify`:
  operand bounds, debug-info parallelism, terminal shape, `halt`
  entry-only, and a DAG basic-block stack-depth propagation that
  catches underflow and imbalance in hand-built or corrupted
  products. The 0.6 VM is expected to call verify before loading.
- `CompileError` — 13 variants, R8 message shapes, `std::error::Error`
  (no source chain: inputs are pre-validated by the front end).
  `COMPILE_DEPTH_LIMIT = 1024` mirrors the expander budget with 2x
  headroom (reader 256 < expander 512 < compiler 1024).
- Constant pool dedup by canonical key: all NaNs fold to one slot
  (Eq reflexivity); +0.0/-0.0 stay distinct (bit-pattern keys — dedup
  is an optimization, not a semantic merge).
- Span discipline: every debug_info entry is copied from a CoreExpr
  node; the only synthesized span is the cold-start anchor for the
  `halt` of an empty program (single-generation ROOT — the TD-002
  no-cross-generation-join guarantee extends to the compiler side).
- kerf-core now re-exports the span coordinate types
  (`FileId`/`ByteOffset`/`ExpansionId`) for downstream span
  construction — no new DAG edge (plan-0.5.md §4 decision 14).
- Workspace: 300 tests green (48 new, positive:negative 12:36 = 1:3);
  §7.3.1 audit set 40 -> 50 (Section F: compile depth cap + verify
  rejection family over hand-built products). TD-003 resolves one
  more scaffold (compiler implemented; vm/runtime/driver remain).

## v0.5.0 — Stage 0.4 expander seed

The macro expander (Layer 3): syntax objects -> the frozen CoreExpr
kernel, implementing the expansion-loop skeleton of docs/stage0.md
§19.2. The 0.4 slice is the core-form skeleton — transformer
execution and the def-site / use-site hygiene union are the 0.9 macro
system (§8.10).

- `expand_program(forms) -> Vec<ModuleItem>` and
  `expand(ctx, stx) -> CoreExpr` — the two public entries. The module
  top level accepts declarations only (`define` / `require` /
  `module`); bare top-level expressions fail closed (the top-level
  expression channel is the `define` calling form — r102 corpus
  anchor; the driver owns the main composition at 0.8).
- All nine expression forms: `fn` / `if` / `let` (single, multi and
  empty binding specs, let* progressive visibility) / `do` (Begin ->
  Let chain desugaring with `_` discards, §6.12.6) / `set!` (target
  must resolve — Scheme semantics) / `perform` / `handle` /
  application / atoms, with `nil` as the reserved literal keyword and
  `(define (f x) body)` sugar mapping near-identically to
  `Define{f, Fn{...}}` (§7.3.5). Defines pre-bind their name
  (letrec-shaped top-level rule — recursive functions resolve).
- Hygiene skeleton (§19.2 invariant 2): every binding construct
  allocates a fresh scope, colors its subtree on descent
  (`with_scope_added` in production use — the 0.2 contract), and
  resolution is scope-set keyed: a name bound at a scope the
  identifier does not carry stays unbound. Nested modules are
  scope-isolated (§8.9 direction).
- Phase closure (§8.9 rule 1, 0.4 slice): every touched node must be
  runtime-phase — macro-phase syntax fails closed with
  `PhaseViolation`.
- `EXPANSION_LIMIT = 512`: the expansion work budget — a structured
  `ExpansionDepthExceeded` error, never a stack overflow (§19.2
  invariant 1); independent of the reader's 256 source-tree cap, it
  bounds synthesized and (at 0.9) macro-produced trees.
- `ExpandError` — seven variants, each carrying the byte-precise
  span; `std::error::Error::source` chains into `CoreError` (the
  core constructor floor is re-asserted at expansion time).
- `STAGE0_GLOBALS` — the 18-name Stage 0 global function table
  (arithmetic/comparison, pair/predicates, minimal I/O — §8.8
  traditional globals); kerf-runtime asserts parity when seeding the
  global environment at 0.7.
- SOP §7.1.1 error classes 2 (unbound identifier) and 7 (expansion
  depth exceeded) are now lit — 4/7 cumulative. The §7.3.1 audit set
  grows monotonically 30 -> 40 (new section E: ten expander
  negatives). Workspace: 252 tests green (48 new, 12:36 = 1:3).
- TD-002 adjudicated and resolved: the 0.4 expander copies source
  spans only (zero span construction — desugared nodes reuse the
  source spans of the same generation), so cross-generation joins
  structurally cannot occur; `JoinExpansionMismatch` stays a designed
  rejection, and the 0.9 macro system registers span-set
  representation (def-site ∪ use-site) as its design agenda
  (plan-0.4.md §4 ruling 3).

## v0.4.0 — Stage 0.3 reader seed

The surface-syntax reader (Layer 2): the first source-level pipeline
entry, implementing the typed-token-stream contract of docs/stage0.md
§8.1 and the `read : string → Result<SyntaxObject, ReadError>`
capability signature (§278), pluralized to whole programs.

- `StxToken`/`StxTokenKind` — the §8.1 TokenKind S-expression subset
  (Delimiter / Identifier / IntLiteral / FloatLiteral / BoolLiteral /
  StringLiteral / Eof); modern-skin kinds arrive additively at Stage 2.
  The tokenize guarantees all hold: lossless coverage (inter-token gaps
  are exactly whitespace and `;` comments — test-anchored), precise
  byte spans (multi-byte UTF-8 exact), structured lexical errors.
- `lex(file_id, source)` and `read_program(file_id, source)` — the two
  public entries; a token slice without Eof is tolerated (end of slice
  behaves as end of input).
- Numbers follow Rust `i64`/`f64` parse semantics (`.5`, `1.`, `1e5`
  are floats); number-shaped atoms that parse as neither are rejected
  fail-closed (`MalformedNumber`) — no Racket-style symbol fallback.
  Booleans are exactly `#t`/`#f` (`#true` fails closed). Strings take
  escapes `\" \\ \n \t \r` with raw newlines legal. `;` line
  comments; the BOM is skipped like whitespace.
- `()` is rejected at read time as `EmptyApplication` (SOP §7.1.1
  error class 3, lit at the reader as defense in depth — the quoted
  empty list is covered by the `nil` literal; honest boundary in
  plan-0.3.md §4.3). Bracket and reader-macro characters
  (`[ ] { } ' \` ,`) fail closed — no reader macros in Stage 0; quote
  is spelled `(quote x)`.
- The list-nesting cap is a public constant (`NESTING_LIMIT = 256`),
  boundary-tested both ways (256 legal, 257 rejected); the cap also
  bounds the descent's native recursion depth. Unclosed lists report
  the innermost open `(` — deterministic and closest to where input
  ran out.
- `ReadError` — ten variants, all byte-precise, R8 message shapes; the
  `InvalidSymbol` rendering is byte-identical across the reader,
  syntax and core layers (single-source dictionary, cross-crate
  asserted).
- SOP §7.3.1 audit set revision 1: `examples/audit/
  stage0_gate_audit_r1.rs` — 30 cases (10 single-statement + 10
  multi-statement + 5 complex + 5 error-recovery), re-runnable via
  `cargo run --release --example stage0_gate_audit_r1`; error-class
  coverage 2/7 (syntax error + empty application lit; 5 structurally
  deferred to 0.4/0.6/0.9). Grows monotonically until 7/7 at the 0.11
  stage gate.
- The `TokenLike` test stand-in is retired exactly as its charter
  promised: seed tests now reduce spans over real reader tokens.
- 60 new tests (15 positive + 45 negative = 1:3; 43 unit + 8 crate
  API + 9 cross-crate); workspace total 204, cold-build green under
  the six-command gate. TD-003 shrinks to 5 scaffold crates.

## v0.3.0 — Stage 0.2 SyntaxObject seed

The surface-syntax data layer (Layer 1), implementing the syntax-object
four-tuple of docs/stage0.md §3.3.

- `SyntaxObject` = datum + span + scopes + phase. The span is a
  mandatory field (never `Option`, never a dummy — the TD-004 structural
  discipline extended to the syntax layer); list members are full syntax
  objects, not bare datums ("extended S-expression", §7.3.6 — per-node
  wrappers are what per-identifier hygiene needs, §19.2 invariant 2).
- `StxDatum` — the skeleton atoms (Symbol/Int/Float/Bool/String) plus
  proper lists; `()` is legal datum; improper (dotted) lists are a 0.3
  reader grammar decision (quoted pair data already lives in
  `kerf_core::LiteralValue::Pair`).
- `StxSymbol` — validated, opaque identifier (floor byte-identical to
  `kerf_core::Symbol`'s: non-empty, no whitespace, no control
  characters). A pipeline-phase twin, not a duplicate: the 0.4 expander
  crosses the boundary as source text through the core validated `&str`
  constructors, so "anything the reader accepts passes both floors"
  holds by identical validation (plan-0.2.md design record 2).
- `Phase` — the frozen two-level model (Runtime = 0, MacroExpansion =
  1, §8.9) with a checked `from_u8` decoder; phase closure is an
  expander (0.4) invariant, the data layer stores per-node phases
  without cross-validation.
- `ScopeId`/`ScopeSet` — the hygiene substrate: sorted, deduplicated
  storage (deterministic iteration — no HashMap randomness), functional
  `union` and the `is_subset_of` lexical-resolution query (§9.38
  scope-coloring sketch); scope freshness is a 0.4 expander-context
  discipline.
- Consumption contracts pre-anchored by integration tests:
  `visit_spans` pre-order traversal and the deep functional
  `with_scope_added` scope flip (principle 23 — the receiver is never
  mutated) for the 0.4 expander; the token→stx assembly pattern
  (token spans reduce to the list span, token text flows through the
  checked symbol constructor) for the 0.3 reader.
- 48 new tests (12 positive + 36 negative = 1:3; three layers: 32
  unit + 8 crate API + 8 cross-crate); workspace total 144, all green
  under the six-command gate (cold build). TD-003 shrinks to 6
  scaffold crates. CJK identifiers remain legal at the floor
  (registered test-fixture whitelist).

## v0.2.0 — Stage 0.1 core expression seed

The frozen semantic-primitive kernel (Layer 4), plus the two design
adjudications that unblocked it (docs/develop/v0/stage-0/
0.1-design-adjudications.md).

- TD-005 ratified: `CoreExpr` carries the nine semantic primitives
  (Fn/Apply/If/Var/Literal/Assign/Let/Perform/Handle) per SOP §21.12-11;
  the historical §3.2 frozen set maps onto it via the §6.12.6
  semantic-equivalence table (shared semantic core, closed both ways).
  Declaration layer `ModuleItem` = Define/Require/Module; `do` sugar
  desugars to `Let` at 0.4.
- TD-004 ratified: every node carries a real `Span` (never `Option`,
  never a dummy); dependency edge kerf-span → kerf-core added to the
  workspace DAG (docs/graph/stage-0/dataflow.md synced).
- `Symbol`: opaque checked identifier (non-empty, no whitespace, no
  control chars — conservative floor; full grammar lands with the 0.3
  reader). Validated `&str` constructors (`fn_`/`var`/`assign`/`perform`/
  `handle`, `Binding::new`, `HandlerClause::new`, `ModuleItem::define`/
  `require`/`module`) pre-anchor the 0.4 expander contract; duplicate
  params / duplicate handler effects are rejected deterministically.
- `CoreExpr::visit_spans` / `ModuleItem::visit_spans`: pre-order span
  traversal — the expander consumption contract and the no-dummy-span
  audit primitive.
- Tests: 48 new cases (unit 32 + crate API 8 + cross-crate integration
  8, positive:negative = 12:36 = 1:3); workspace total 96, all green.
- Verification: SOP §3.2 six commands all green on a cold build (see
  docs/develop/v0/stage-0/plan-0.1.md).

## v0.1.0 — Stage 0.0 cold-start bootstrap

First engineering artifact of the kerf compiler, reconstructed from the
upstream document repository (sop.md v15.0-verified + stage0.md design
blueprint, content state v9.8).

- Cargo workspace, edition 2024: root aggregation package + 9 `kerf-*`
  member crates wired exactly along the SOP §18.5 dependency DAG.
- Seed MUV `kerf-span` (Layer 0): `FileId` / `ByteOffset` / `ExpansionId` /
  `Span` with checked invariants (stage0.md §8.6 four-field model, §12.1
  byte-offset representation). Line/column rendering deferred to the
  diagnostics framework (TD-001).
- Test architecture per SOP §8.4.6/§9.1: root `tests/runner.rs` single
  entry + three-layer suite (unit / crate API / cross-crate integration).
- Stage 0 roadmap fixed: sub-stages 0.0-0.11 (minimal semantic kernel →
  infrastructure depth → macro engine → interface-reservation freeze →
  stage gate).
- Verification: SOP §3.2 six commands all green (see
  `docs/develop/v0/stage-0/plan-0.0.md`).

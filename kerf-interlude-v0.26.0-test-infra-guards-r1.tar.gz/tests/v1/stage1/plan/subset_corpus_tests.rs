//! Stage 1.4 acceptance-corpus tests — the `.krf` corpus through the
//! real pipeline (stage-1-plan row 1.4; docs/stage0.md §9.45.5).
//!
//! Two faces over one corpus directory (`tests/v1/stage1/corpus/`):
//! - one `#[test]` per case (the macro table below — isolation and
//!   precise failure naming);
//! - one dynamic sweep over the directory (completeness: no `.krf`
//!   file escapes validation).
//!
//! The table and the directory are held in exact parity by the
//! `test_infra_guard_tests::corpus_case_table_matches_directory_exactly`
//! guard (v0.26.0, stage0.md §9.57): a new corpus file must gain its
//! table entry in the same change — the isolation face may not lag.
//!
//! Every expectation is embedded in its file's `;; expect:` directive
//! line (the GCC torture `dg-*` pattern) and was verified against the
//! real pipeline at authoring time — the corpus is frozen data, the
//! harness is `kerf_driver::parity` (the Stage 1.4 contract surface).
//!
//! Distribution (subset-spec.md): positive >= 20, negative >= 20,
//! boundary >= 10, total >= 50 — asserted by the meta tests below.

use kerf::driver::{CorpusCase, validate};

/// The corpus directory (absolute — the working directory of a test
/// run is the package root, but the sweep stays explicit).
const CORPUS_DIR: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/tests/v1/stage1/corpus");

/// Declare one isolated per-case test: embed the file at compile
/// time (relative to this file), parse its directive, validate
/// through the real pipeline, assert the match.
macro_rules! corpus_case {
    ($fn_name:ident, $file:literal) => {
        #[test]
        fn $fn_name() {
            let source = include_str!(concat!("../corpus/", $file));
            let case = CorpusCase::from_source($file, source).expect("directive parses");
            let report = validate(&case);
            assert!(
                report.matched,
                "corpus case `{}` drifted: {} (observed {:?})",
                $file,
                report.drift.as_deref().unwrap_or("no drift note"),
                report.observed
            );
        }
    };
}

corpus_case!(corpus_bnd_001_i64_max, "bnd-001-i64-max.krf");
corpus_case!(corpus_bnd_002_i64_min, "bnd-002-i64-min.krf");
corpus_case!(
    corpus_bnd_003_sub_min_overflow,
    "bnd-003-sub-min-overflow.krf"
);
corpus_case!(corpus_bnd_004_float_frac, "bnd-004-float-frac.krf");
corpus_case!(corpus_bnd_005_float_whole, "bnd-005-float-whole.krf");
corpus_case!(corpus_bnd_006_nesting_255_ok, "bnd-006-nesting-255-ok.krf");
corpus_case!(
    corpus_bnd_007_nesting_257_fails,
    "bnd-007-nesting-257-fails.krf"
);
corpus_case!(corpus_bnd_008_fib_25, "bnd-008-fib-25.krf");
corpus_case!(corpus_bnd_009_iota_chain_50, "bnd-009-iota-chain-50.krf");
corpus_case!(
    corpus_bnd_010_expansion_limit,
    "bnd-010-expansion-limit.krf"
);
corpus_case!(corpus_neg_001_unclosed_paren, "neg-001-unclosed-paren.krf");
corpus_case!(corpus_neg_002_stray_close, "neg-002-stray-close.krf");
corpus_case!(
    corpus_neg_003_unterminated_string,
    "neg-003-unterminated-string.krf"
);
corpus_case!(corpus_neg_004_bad_hash_token, "neg-004-bad-hash-token.krf");
corpus_case!(
    corpus_neg_010_top_level_expression,
    "neg-010-top-level-expression.krf"
);
corpus_case!(corpus_neg_011_malformed_fn, "neg-011-malformed-fn.krf");
corpus_case!(corpus_neg_012_malformed_let, "neg-012-malformed-let.krf");
corpus_case!(
    corpus_neg_013_unbound_reference,
    "neg-013-unbound-reference.krf"
);
corpus_case!(corpus_neg_014_quote_symbol, "neg-014-quote-symbol.krf");
corpus_case!(corpus_neg_015_set_unbound, "neg-015-set-unbound.krf");
corpus_case!(
    corpus_neg_016_malformed_handle,
    "neg-016-malformed-handle.krf"
);
corpus_case!(
    corpus_neg_017_malformed_define,
    "neg-017-malformed-define.krf"
);
corpus_case!(corpus_neg_018_module_cycle, "neg-018-module-cycle.krf");
corpus_case!(corpus_neg_019_module_missing, "neg-019-module-missing.krf");
corpus_case!(
    corpus_neg_020_module_duplicate,
    "neg-020-module-duplicate.krf"
);
corpus_case!(
    corpus_neg_021_empty_application,
    "neg-021-empty-application.krf"
);
corpus_case!(corpus_neg_030_arity_known, "neg-030-arity-known.krf");
corpus_case!(corpus_neg_031_nonbool_cond, "neg-031-nonbool-cond.krf");
corpus_case!(corpus_neg_032_call_literal, "neg-032-call-literal.krf");
corpus_case!(
    corpus_neg_033_call_numeric_global,
    "neg-033-call-numeric-global.krf"
);
corpus_case!(corpus_neg_034_handler_arity, "neg-034-handler-arity.krf");
corpus_case!(
    corpus_neg_035_unhandled_effect,
    "neg-035-unhandled-effect.krf"
);
corpus_case!(
    corpus_neg_036_literal_handler,
    "neg-036-literal-handler.krf"
);
corpus_case!(
    corpus_neg_037_multi_error_collection,
    "neg-037-multi-error-collection.krf"
);
corpus_case!(corpus_neg_040_div_zero, "neg-040-div-zero.krf");
corpus_case!(corpus_neg_041_car_nonpair, "neg-041-car-nonpair.krf");
corpus_case!(corpus_neg_042_add_overflow, "neg-042-add-overflow.krf");
corpus_case!(
    corpus_neg_043_arity_through_param,
    "neg-043-arity-through-param.krf"
);
corpus_case!(corpus_neg_044_add_bool, "neg-044-add-bool.krf");
corpus_case!(
    corpus_neg_045_closure_no_capture,
    "neg-045-closure-no-capture.krf"
);
corpus_case!(
    corpus_neg_046_forward_reference,
    "neg-046-forward-reference.krf"
);
corpus_case!(corpus_neg_047_write_line_int, "neg-047-write-line-int.krf");
corpus_case!(
    corpus_neg_048_module_cycle_string,
    "neg-048-module-cycle-string.krf"
);
corpus_case!(
    corpus_neg_049_require_missing,
    "neg-049-require-missing.krf"
);
corpus_case!(
    corpus_neg_050_pattern_mismatch,
    "neg-050-pattern-mismatch.krf"
);
corpus_case!(
    corpus_neg_051_duplicate_pattern_vars,
    "neg-051-duplicate-pattern-vars.krf"
);
corpus_case!(
    corpus_neg_052_ellipsis_rejected,
    "neg-052-ellipsis-rejected.krf"
);
corpus_case!(
    corpus_neg_053_module_macro_outside,
    "neg-053-module-macro-outside.krf"
);
corpus_case!(corpus_pos_001_arith_add, "pos-001-arith-add.krf");
corpus_case!(corpus_pos_002_arith_mixed, "pos-002-arith-mixed.krf");
corpus_case!(corpus_pos_003_int_div, "pos-003-int-div.krf");
corpus_case!(corpus_pos_004_float_add, "pos-004-float-add.krf");
corpus_case!(corpus_pos_005_compare_true, "pos-005-compare-true.krf");
corpus_case!(
    corpus_pos_006_bool_false_branch,
    "pos-006-bool-false-branch.krf"
);
corpus_case!(
    corpus_pos_007_fn_sugar_square,
    "pos-007-fn-sugar-square.krf"
);
corpus_case!(corpus_pos_009_recursion_fib, "pos-009-recursion-fib.krf");
corpus_case!(corpus_pos_010_let_bindings, "pos-010-let-bindings.krf");
corpus_case!(corpus_pos_011_let_shadow, "pos-011-let-shadow.krf");
corpus_case!(corpus_pos_012_do_sequencing, "pos-012-do-sequencing.krf");
corpus_case!(corpus_pos_013_string_literal, "pos-013-string-literal.krf");
corpus_case!(corpus_pos_014_quote_list, "pos-014-quote-list.krf");
corpus_case!(
    corpus_pos_015_quote_nested_lists,
    "pos-015-quote-nested-lists.krf"
);
corpus_case!(corpus_pos_016_cons_chain, "pos-016-cons-chain.krf");
corpus_case!(corpus_pos_017_car_cdr, "pos-017-car-cdr.krf");
corpus_case!(corpus_pos_018_predicates, "pos-018-predicates.krf");
corpus_case!(corpus_pos_019_not_truthy, "pos-019-not-truthy.krf");
corpus_case!(
    corpus_pos_020_higher_order_map,
    "pos-020-higher-order-map.krf"
);
corpus_case!(corpus_pos_021_effect_handle, "pos-021-effect-handle.krf");
corpus_case!(
    corpus_pos_022_effect_pass_through,
    "pos-022-effect-pass-through.krf"
);
corpus_case!(corpus_pos_023_write_line, "pos-023-write-line.krf");
corpus_case!(corpus_pos_024_macro_my_if, "pos-024-macro-my-if.krf");
corpus_case!(corpus_pos_025_module_flat, "pos-025-module-flat.krf");
corpus_case!(corpus_pos_027_nil_literal, "pos-027-nil-literal.krf");
corpus_case!(
    corpus_pos_028_warn_rebind_builtin,
    "pos-028-warn-rebind-builtin.krf"
);
corpus_case!(corpus_pos_029_require_string, "pos-029-require-string.krf");
corpus_case!(corpus_pos_030_module_nested, "pos-030-module-nested.krf");
corpus_case!(corpus_pos_031_literal_macro, "pos-031-literal-macro.krf");
corpus_case!(
    corpus_pos_032_macro_two_generations,
    "pos-032-macro-two-generations.krf"
);
corpus_case!(
    corpus_pos_033_hygiene_binder_collision,
    "pos-033-hygiene-binder-collision.krf"
);

// ---------- the dynamic sweep + corpus meta (completeness/floor) ----------

/// Every `.krf` file in the corpus directory validates through the
/// contract — the completeness face (sorted, deterministic order).
#[test]
fn corpus_directory_every_file_validates() {
    let mut paths: Vec<_> = std::fs::read_dir(CORPUS_DIR)
        .expect("corpus directory exists")
        .filter_map(|e| e.ok())
        .map(|e| e.path())
        .filter(|p| p.extension().is_some_and(|x| x == "krf"))
        .collect();
    paths.sort();
    assert!(
        paths.len() >= 50,
        "corpus floor: {} files, want >= 50",
        paths.len()
    );
    for path in paths {
        let name = path.file_stem().unwrap().to_str().unwrap().to_owned();
        let source = std::fs::read_to_string(&path).expect("corpus file reads");
        let case = CorpusCase::from_source(
            Box::leak(name.clone().into_boxed_str()),
            Box::leak(source.into_boxed_str()),
        )
        .unwrap_or_else(|e| panic!("directive of `{name}`: {e}"));
        let report = validate(&case);
        assert!(
            report.matched,
            "corpus case `{name}` drifted: {} (observed {:?})",
            report.drift.as_deref().unwrap_or("no drift note"),
            report.observed
        );
    }
}

/// The frozen distribution floors (subset-spec.md §Corpus): positive
/// >= 20, negative >= 20, boundary >= 10, total >= 50.
#[test]
fn corpus_distribution_meets_floors() {
    let names: Vec<String> = std::fs::read_dir(CORPUS_DIR)
        .expect("corpus directory exists")
        .filter_map(|e| e.ok())
        .filter_map(|e| e.file_name().into_string().ok())
        .filter(|n| n.ends_with(".krf"))
        .collect();
    let count = |prefix: &str| names.iter().filter(|n| n.starts_with(prefix)).count();
    let pos = count("pos-");
    let neg = count("neg-");
    let bnd = count("bnd-");
    let total = names.len();
    assert!(pos >= 20, "positive floor: {pos} < 20");
    assert!(neg >= 20, "negative floor: {neg} < 20");
    assert!(bnd >= 10, "boundary floor: {bnd} < 10");
    assert!(total >= 50, "total floor: {total} < 50");
}

/// Case names are unique and carry their category prefix (the naming
/// discipline the distribution test counts on).
#[test]
fn corpus_names_are_prefixed_and_unique() {
    let mut names: Vec<String> = std::fs::read_dir(CORPUS_DIR)
        .expect("corpus directory exists")
        .filter_map(|e| e.ok())
        .filter_map(|e| e.file_name().into_string().ok())
        .filter(|n| n.ends_with(".krf"))
        .collect();
    names.sort();
    let total = names.len();
    names.dedup();
    assert_eq!(names.len(), total, "corpus file names are unique");
    for name in &names {
        assert!(
            name.starts_with("pos-") || name.starts_with("neg-") || name.starts_with("bnd-"),
            "case `{name}` lacks a category prefix"
        );
    }
}

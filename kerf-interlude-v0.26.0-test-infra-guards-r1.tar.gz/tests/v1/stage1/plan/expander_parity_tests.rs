//! Stage 1.7 macro parity tests  -  the assembled `.krf` front end
//! (macro library + expansion layer) against the Rust expander
//! oracle (stage-1-plan row 1.7; docs/stage0.md §9.48.4 MX-1..MX-6;
//! the test doc docs/tests/v1/stage1/macro-parity.md).
//!
//! Families (the test doc FP1-FP8 + MP1-MP11):
//! - FP1/FP2: stream encoding + the two-layer split (reader /
//!   expander  -  the 1.6 Macro split collapsed, MX-3) over the
//!   whole corpus (macro files included, the sentinel at zero);
//! - FP3/FP5: the tree axis at hand-computed anchor spans  -  the
//!   §9.47.3 seven span traps one by one;
//! - FP4: the error axis at exact payloads;
//! - FP6: the binding discipline (let* order, define pre-binding,
//!   module frame isolation, no cross-define recursion);
//! - FP7: the corpus replay (79 files, layer distribution);
//! - FP8: the drift detector's self-checks and the harness-defect
//!   face;
//! - plus MP1-MP11: the macro faces (matching, the six-step
//!   instantiation order, mangled rename decoding, registration
//!   validation, frame isolation, the depth mirror, the sentinel,
//!   gate B axes (a)/(b)) and the deep boundary paths under
//!   `deep_stack`.

use kerf::driver::{
    EXPANDER_SOURCE, ExpanderParityLayer, MACRO_SOURCE, assembled_expander_source, expander_parity,
    expander_parity_with, gate_b_bytecode,
};

/// The corpus directory (absolute  -  the working directory of a test
/// run is the package root, but the sweep stays explicit).
const CORPUS_DIR: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/tests/v1/stage1/corpus");

/// Deep trees (bnd-006's 255-deep if chain) recurse through the
/// .krf expander and the harness's Rust tree walkers; the default
/// 8 MiB test-thread stack is not enough in debug builds. Virtual
/// stack pages are demand-allocated, so the large hint costs
/// nothing.
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly");
}

// ---------- FP5: the seven span traps, at anchor spans ----------

#[test]
fn span_trap_1_quote_literal_takes_the_whole_form_span() {
    // The literal's span is the whole `(quote datum)` form  -  not
    // the datum's own span.
    let report = expander_parity("trap1", "(define x (quote (1 2)))");
    assert!(report.matched, "{}", report.failure_line());
    assert!(report.engines_agree);
    assert_eq!(
        report.oracle,
        "(define 0 24 x (lit 10 23 (pair (int 1) (pair (int 2) nil))))"
    );
}

#[test]
fn span_trap_2_fn_sugar_fn_span_is_the_name_atom() {
    let report = expander_parity("trap2", "(define (f x) x)");
    assert!(report.matched, "{}", report.failure_line());
    assert_eq!(report.oracle, "(define 0 16 f (fn 9 10 (x) (var 14 15 x)))");
}

#[test]
fn span_trap_3_binding_span_is_the_value_node() {
    let report = expander_parity("trap3", "(define x (let ((a 1)) a))");
    assert!(report.matched, "{}", report.failure_line());
    assert_eq!(
        report.oracle,
        "(define 0 26 x (let 10 25 ((19 20 a (lit 19 20 (int 1)))) (var 23 24 a)))"
    );
}

#[test]
fn span_trap_4_do_identity_is_unwrapped() {
    // (do e) is the identity: no Let wrapper, no frame.
    let one = expander_parity("trap4a", "(define x (do 5))");
    assert!(one.matched, "{}", one.failure_line());
    assert_eq!(one.oracle, "(define 0 17 x (lit 14 15 (int 5)))");
    // (do e1 e2) is one flat Let with the discard binding whose
    // span is the STEP node.
    let two = expander_parity("trap4b", "(define x (do 5 6))");
    assert!(two.matched, "{}", two.failure_line());
    assert_eq!(
        two.oracle,
        "(define 0 19 x (let 10 18 ((14 15 _ (lit 14 15 (int 5)))) (lit 16 17 (int 6))))"
    );
}

#[test]
fn span_trap_5_set_unbound_reports_the_name_atom_span() {
    let report = expander_parity("trap5", "(define x (set! y 1))");
    assert!(report.matched, "{}", report.failure_line());
    // §9.56 DIAG-1: parity key = Display + `@ {span}` suffix.
    assert_eq!(
        report.oracle,
        "unbound identifier `y`: not in any lexical scope and \
         not a Stage 0 global @ file#0:16..17"
    );
}

#[test]
fn span_trap_6_handler_clause_span_is_the_whole_clause_list() {
    let report = expander_parity("trap6", "(define x (handle 1 (e (fn (v) v))))");
    assert!(report.matched, "{}", report.failure_line());
    assert_eq!(
        report.oracle,
        "(define 0 36 x (handle 10 35 (lit 18 19 (int 1)) \
         ((20 34 e (fn 23 33 (v) (var 31 32 v))))))"
    );
}

#[test]
fn span_trap_7_require_symbol_name_is_malformed_not_module_error() {
    let report = expander_parity("trap7", "(require b)");
    assert!(report.matched, "{}", report.failure_line());
    assert_eq!(report.oracle, "malformed `require` form @ file#0:0..11");
    // The string form produces a Require item (the loader's face).
    let ok = expander_parity(
        "trap7b",
        "(module m (define x 1))\n(require \"m\")\n(define result 2)",
    );
    assert!(ok.matched, "{}", ok.failure_line());
    assert!(
        ok.oracle
            .starts_with("(module 0 23 m (define 10 22 x (lit 20 21 (int 1))))")
    );
}

// ---------- FP6: the binding discipline ----------

#[test]
fn let_star_order_later_values_see_earlier_names() {
    let ok = expander_parity("letstar-ok", "(define x (let ((a 1) (b (+ a 1))) b))");
    assert!(ok.matched, "{}", ok.failure_line());
    // The reverse never holds: a's value cannot see b.
    let bad = expander_parity("letstar-bad", "(define x (let ((a b) (b 1)) a))");
    assert!(bad.matched, "{}", bad.failure_line());
    assert_eq!(
        bad.oracle,
        "unbound identifier `b`: not in any lexical scope and \
         not a Stage 0 global @ file#0:19..20"
    );
}

#[test]
fn define_prebinds_its_own_name_but_not_later_defines() {
    // letrec-shaped: the function's body resolves its own name.
    let rec = expander_parity(
        "prebind-ok",
        "(define (f n) (if (< n 2) n (f (- n 1))))\n(define x (f 3))",
    );
    assert!(rec.matched, "{}", rec.failure_line());
    // Cross-define forward references are rejected (no mutual
    // recursion between top-level defines).
    let fwd = expander_parity("prebind-fwd", "(define a (f 1))\n(define (f x) x)");
    assert!(fwd.matched, "{}", fwd.failure_line());
    assert!(
        fwd.oracle
            .starts_with("unbound identifier `f`: not in any lexical scope")
    );
    assert!(fwd.oracle.contains("@ file#0:11..12"));
}

#[test]
fn module_frames_are_isolated() {
    let report = expander_parity("module-iso", "(define x 1)\n(module m (define y x))");
    assert!(report.matched, "{}", report.failure_line());
    assert!(
        report
            .oracle
            .starts_with("unbound identifier `x`: not in any lexical scope")
    );
    assert!(report.oracle.contains("@ file#0:33..34"));
}

// ---------- FP2/FP7: the corpus replay, three-layer split ----------

#[test]
fn corpus_directory_every_file_validates_expander_parity() {
    deep_stack(corpus_sweep_body);
}

fn corpus_sweep_body() {
    let entries = std::fs::read_dir(CORPUS_DIR).expect("the Stage 1.4 corpus directory is in tree");
    let mut files: Vec<_> = entries
        .filter_map(|e| e.ok())
        .map(|e| e.path())
        .filter(|p| p.extension().is_some_and(|x| x == "krf"))
        .collect();
    files.sort();
    assert!(
        files.len() >= 79,
        "the corpus floor is >= 79 (found {})",
        files.len()
    );
    let mut reader_layer = 0usize;
    let mut macro_layer = 0usize;
    let mut expander_layer = 0usize;
    for path in &files {
        let source = std::fs::read_to_string(path).expect("corpus file reads");
        let name = path.file_name().and_then(|n| n.to_str()).unwrap_or("?");
        let report = expander_parity(name, &source);
        assert!(
            report.matched,
            "corpus case {name}: {}",
            report.failure_line()
        );
        assert!(report.engines_agree, "corpus case {name}: engines disagree");
        match report.layer {
            ExpanderParityLayer::Reader => reader_layer += 1,
            ExpanderParityLayer::Macro => macro_layer += 1,
            ExpanderParityLayer::Expander => expander_layer += 1,
        }
    }
    // The collapsed split (MX-3): six reader-side rejections,
    // everything else  -  the macro corpus files included  -  on the
    // assembled .krf expansion layer; the Macro layer is a sentinel
    // at zero (any routing regression fails this count).
    assert_eq!(reader_layer, 6, "reader-layer count");
    assert_eq!(macro_layer, 0, "macro-layer sentinel (must stay zero)");
    assert_eq!(expander_layer, 73, "expander-layer count");
    assert_eq!(reader_layer + macro_layer + expander_layer, files.len());
}

#[test]
fn corpus_boundary_files_ride_the_deep_paths() {
    deep_stack(corpus_boundary_body);
}

fn corpus_boundary_body() {
    // bnd-006 (255-deep ok  -  the heaviest forms stream the harness
    // walks, on both engines) and bnd-007 (257-deep  -  the reader
    // layer decides).
    let bnd6 =
        std::fs::read_to_string(format!("{CORPUS_DIR}/bnd-006-nesting-255-ok.krf")).expect("file");
    let r6 = expander_parity("bnd-006", &bnd6);
    assert_eq!(r6.layer, ExpanderParityLayer::Expander);
    assert!(r6.matched, "{}", r6.failure_line());
    assert!(r6.engines_agree);
    let bnd7 = std::fs::read_to_string(format!("{CORPUS_DIR}/bnd-007-nesting-257-fails.krf"))
        .expect("file");
    let r7 = expander_parity("bnd-007", &bnd7);
    assert_eq!(r7.layer, ExpanderParityLayer::Reader);
    assert!(r7.matched, "{}", r7.failure_line());
}

#[test]
fn the_macro_corpus_files_run_the_assembled_expander() {
    // MX-3: the 1.6 Macro-layer routing collapsed - the macro
    // corpus files (the two originals plus the seven 1.7
    // extensions) run the assembled .krf program on both engines
    // with the oracle agreeing byte-for-byte.
    for file in [
        "pos-024-macro-my-if.krf",
        "bnd-010-expansion-limit.krf",
        "pos-031-literal-macro.krf",
        "pos-032-macro-two-generations.krf",
        "pos-033-hygiene-binder-collision.krf",
        "neg-050-pattern-mismatch.krf",
        "neg-051-duplicate-pattern-vars.krf",
        "neg-052-ellipsis-rejected.krf",
        "neg-053-module-macro-outside.krf",
    ] {
        let source = std::fs::read_to_string(format!("{CORPUS_DIR}/{file}")).expect("file");
        let report = expander_parity(file, &source);
        assert_eq!(report.layer, ExpanderParityLayer::Expander, "{file}");
        assert!(report.matched, "{file}: {}", report.failure_line());
        assert!(report.engines_agree, "{file}: engines disagree");
        assert!(
            report.krf.is_some(),
            "{file}: the .krf layer must be exercised"
        );
    }
}

// ---------- the loader faces (the 1.6 corpus extension) ----------

#[test]
fn loader_faces_parity_at_exact_payloads() {
    // The new neg-048/049 corpus files: the string-name cycle and
    // the missing module (ModuleCycle / ModuleNotFound  -  reachable
    // only through string requires; trap 7's sibling faces).
    let cyc = std::fs::read_to_string(format!("{CORPUS_DIR}/neg-048-module-cycle-string.krf"))
        .expect("file");
    let rc = expander_parity("neg-048", &cyc);
    assert!(rc.matched, "{}", rc.failure_line());
    // §9.56 DIAG-1: parity key = Display + `@ {span}` suffix.
    assert_eq!(
        rc.oracle,
        "module cycle detected: a -> b -> a @ file#0:59..72"
    );
    let miss =
        std::fs::read_to_string(format!("{CORPUS_DIR}/neg-049-require-missing.krf")).expect("file");
    let rm = expander_parity("neg-049", &miss);
    assert!(rm.matched, "{}", rm.failure_line());
    assert!(
        rm.oracle
            .starts_with("required module `nope` is not declared")
    );
    assert!(rm.oracle.contains("@ file#0:"));
    // The duplicate face (the original corpus anchor).
    let dup = std::fs::read_to_string(format!("{CORPUS_DIR}/neg-020-module-duplicate.krf"))
        .expect("file");
    let rd = expander_parity("neg-020", &dup);
    assert!(rd.matched, "{}", rd.failure_line());
    assert!(rd.oracle.starts_with("duplicate module declaration `m`"));
}

// ---------- FP8: the drift detector's self-checks ----------

#[test]
fn drift_detector_catches_a_tampered_expander_source() {
    // A tampered depth guard (trips at 2 nesting levels instead of
    // 512) must fail the tree comparison  -  a detector that cannot
    // fail proves nothing.
    let tampered = EXPANDER_SOURCE.replace("(>= ex-depth 512)", "(>= ex-depth 2)");
    assert_ne!(tampered, EXPANDER_SOURCE, "tamper must change the source");
    let assembled = format!("{MACRO_SOURCE}\n{tampered}");
    let report = expander_parity_with("tamper-depth", "(define x (do 1 (do 2 3)))", &assembled);
    assert!(!report.matched, "the tampered expander must be caught");
    assert!(report.drift.is_some());
}

#[test]
fn drift_detector_catches_a_tampered_span_selection() {
    // A tampered set! branch that reports the FORM span for unbound
    // names (instead of the name atom span  -  trap 5) must fail the
    // error-axis comparison.
    let needle = "(cons (ex-s nt) (cons (ex-e nt) nil))";
    let replacement = "(cons (ex-s t) (cons (ex-e t) nil))";
    assert!(
        EXPANDER_SOURCE.contains(needle),
        "the trap-5 anchor must exist in the source"
    );
    let tampered = EXPANDER_SOURCE.replacen(needle, replacement, 1);
    let assembled = format!("{MACRO_SOURCE}\n{tampered}");
    let report = expander_parity_with("tamper-span", "(define x (set! y 1))", &assembled);
    assert!(!report.matched, "the tampered span must be caught");
}

#[test]
fn report_failure_line_names_the_case_on_both_verdicts() {
    let pass = expander_parity("line-pass", "(define x 1)");
    assert_eq!(pass.failure_line(), "expander parity PASS [line-pass]");
    let tampered = EXPANDER_SOURCE.replace("(>= ex-depth 512)", "(>= ex-depth 2)");
    let assembled = format!("{MACRO_SOURCE}\n{tampered}");
    let fail = expander_parity_with("line-fail", "(define x (do 1 (do 2 3)))", &assembled);
    assert!(
        fail.failure_line()
            .starts_with("expander parity FAIL [line-fail]:")
    );
}

// ---------- the bootstrap fixed point ----------

#[test]
fn the_assembled_expander_expands_its_own_source_forms() {
    // The third self-hosting fixed point (the 1.5 reader / 1.6
    // expander precedents, third instance): the assembled program
    // (macro library + expansion layer, MX-2) consumes the
    // oracle-read forms of its own assembled source.
    // Structural face: the assembled source minus the hosting tail.
    let assembled = assembled_expander_source();
    let self_forms = assembled.replace("\n(define result (ex-run forms))", "");
    assert_ne!(&self_forms, &assembled);
    let report = expander_parity_with("selfhost-structural", &self_forms, &assembled);
    assert_eq!(report.layer, ExpanderParityLayer::Expander);
    assert!(report.engines_agree, "{:?}", report.drift);
    assert!(report.matched, "{}", report.failure_line());
    assert!(report.oracle.starts_with("(define"));
    assert!(report.oracle.contains("ex-expand"));
    // Error face: the bare assembled source - the oracle and both
    // engines agree on the unbound `forms` (the hosting dependency
    // made visible by self-application; span probe-verified).
    let bare = expander_parity("selfhost-bare", &assembled);
    assert!(bare.matched, "{}", bare.failure_line());
    assert!(
        bare.oracle.starts_with("unbound identifier `forms`"),
        "the bare source must fail on `forms`: {}",
        bare.oracle
    );
}

// ---------- MP1-MP11: the 1.7 macro faces ----------

#[test]
fn mp2_the_literal_table_matches_by_symbol_text() {
    let report = expander_parity(
        "mp-lit",
        "(define-syntax k (syntax-rules (then) ((_ then v) v))) (define r (k then 5))",
    );
    assert!(report.matched, "{}", report.failure_line());
    assert!(report.oracle.contains("(lit"), "{}", report.oracle);
}

#[test]
fn mp3_the_hygiene_rename_decodes_to_the_concatenated_name() {
    let report = expander_parity(
        "mp-hygiene",
        "(define-syntax w (syntax-rules nil ((_ e) (let ((x 100)) (+ x e))))) \
         (define (f x) (w x)) (define result (f 1))",
    );
    assert!(report.matched, "{}", report.failure_line());
    // The introduced binder renamed (x -> x__macro_0), the reference
    // followed, the use-site x spliced untouched (MX-1 decode face).
    assert!(
        report.oracle.contains("x__macro_0"),
        "the mangled name must decode: {}",
        report.oracle
    );
}

#[test]
fn mp5_registration_rejections_render_byte_exact() {
    for (src, needle) in [
        (
            "(define-syntax d (syntax-rules nil ((_ a a) a)))",
            "malformed `define-syntax` form",
        ),
        (
            "(define-syntax e (syntax-rules nil ((_ a ...) a)))",
            "malformed `define-syntax` form",
        ),
        (
            "(define-syntax if (syntax-rules nil ((_ x) x)))",
            "malformed `define-syntax` form",
        ),
        (
            "(define-syntax m (syntax-rules nil ((_ x) x))) (define r (m 1 2))",
            "macro `m` matched no clause",
        ),
    ] {
        let report = expander_parity("mp-reg", src);
        assert!(report.matched, "{}", report.failure_line());
        assert!(report.oracle.contains(needle), "{}", report.oracle);
    }
}

#[test]
fn mp6_module_scoped_macros_vanish_outside() {
    let report = expander_parity(
        "mp-module",
        "(module m (define-syntax i (syntax-rules nil ((_) 1)))) (define result (i))",
    );
    assert!(report.matched, "{}", report.failure_line());
    assert!(
        report.oracle.contains("unbound identifier `i`"),
        "{}",
        report.oracle
    );
}

#[test]
fn mp7_the_depth_budget_mirrors_the_oracle() {
    let report = expander_parity(
        "mp-depth",
        "(define-syntax loop (syntax-rules nil ((_) (loop)))) (define result (loop))",
    );
    assert!(report.matched, "{}", report.failure_line());
    assert_eq!(
        report.oracle,
        "expansion depth exceeded the limit of 512 @ file#0:43..49"
    );
}

#[test]
fn mp8_the_macro_sentinel_stays_at_zero_routing() {
    // MX-3: a define-syntax source runs the assembled program; the
    // Macro layer enum value is a sentinel with zero routing.
    let report = expander_parity(
        "mp-sentinel",
        "(define-syntax m (syntax-rules nil ((_ x) x))) (define r (m 1))",
    );
    assert_eq!(report.layer, ExpanderParityLayer::Expander);
    assert!(report.matched, "{}", report.failure_line());
    assert!(report.krf.is_some());
}

#[test]
fn mp9_gate_b_axis_a_holds_bytecode_equality() {
    for file in [
        "pos-024-macro-my-if.krf",
        "pos-031-literal-macro.krf",
        "pos-032-macro-two-generations.krf",
        "pos-033-hygiene-binder-collision.krf",
    ] {
        let source = std::fs::read_to_string(format!("{CORPUS_DIR}/{file}")).expect("file");
        gate_b_bytecode(file, &source)
            .unwrap_or_else(|err| panic!("gate B axis (a) [{file}]: {err}"));
    }
    gate_b_bytecode("plain", "(define result (+ 1 2))")
        .expect("the non-macro source compiles equal too");
}

#[test]
fn mp10_gate_b_axis_b_the_self_application_fixpoint() {
    // The assembled program applied to its own forms: the item
    // trees agree three ways AND compile to the same bytecode
    // (MX-6 axis (b) - the third-segment self-application).
    let assembled = assembled_expander_source();
    let self_forms = assembled.replace("\n(define result (ex-run forms))", "");
    let report = expander_parity_with("selfhost", &self_forms, &assembled);
    assert!(report.matched, "{}", report.failure_line());
    gate_b_bytecode("selfhost", &self_forms).expect("the self-application bytecode equality");
}

#[test]
fn mp11_tampering_the_rename_counter_is_caught() {
    // A tampered counter start (7 instead of 0) must drift the
    // mangled decode against the oracle (x__macro_7 vs x__macro_0).
    let needle = "(set! ex-mcount 0)";
    assert!(MACRO_SOURCE.contains(needle), "the counter anchor exists");
    let tampered = MACRO_SOURCE.replacen(needle, "(set! ex-mcount 7)", 1);
    let assembled = format!("{tampered}\n{EXPANDER_SOURCE}");
    let report = expander_parity_with(
        "tamper-counter",
        "(define-syntax w (syntax-rules nil ((_ e) (let ((x 100)) (+ x e))))) \
         (define (f x) (w x)) (define result (f 1))",
        &assembled,
    );
    assert!(!report.matched, "the tampered counter must be caught");
}

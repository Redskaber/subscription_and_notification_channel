//! Stage-interlude integration tests for the interned symbol payload
//! (v0.23.0, docs/stage0.md §9.52) — the cross-crate face of the
//! representation change: identifier-heavy programs must compile, run,
//! and diagnose identically through the whole
//! reader → expander → (compiler → vm | evaluator) chain.
//!
//! Layering note (SOP §8.4.6 rule 7): these are cross-crate assertions
//! about the *pipeline behavior* over interned identities, so they live
//! in the root tree; the representation invariants themselves are unit
//! tests inside the two owning crates.

use kerf::driver::{CorpusCase, Engine, Session, run_parity_source, run_source, validate};

/// A symbol-heavy program: repeated use of the same names, shadowing
/// chains, wide frames (the compile-time reverse-scan face), and a
/// closure — the interned-identity stress shape across every pipeline
/// stage that consumes symbols.
const SYMBOL_HEAVY: &str = "\
(define (twice x) (* 2 x))
(define (compute alpha beta)
  (let ((alpha (twice alpha)))
    (let ((beta (+ alpha beta)))
      (+ alpha beta))))
(define (wide a b c d e f g h)
  (+ a (+ b (+ c (+ d (+ e (+ f (+ g h))))))))
(define (add-two operand) (+ operand 2))
(define result (+ (compute 4 1) (+ (wide 1 2 3 4 5 6 7 8) (add-two 5))))";

// ---------- positive ----------

#[test]
fn symbol_heavy_program_runs_on_vm_engine() {
    let mut s = Session::new();
    let out =
        run_source(&mut s, "symbol-heavy.krf", SYMBOL_HEAVY, Engine::Vm, &[]).expect("vm run");
    // compute 4 1 = 17, wide 1..8 = 36, add-two 5 = 7 → 60.
    assert_eq!(
        out.global("result").expect("result stored").to_string(),
        "60"
    );
}

#[test]
fn symbol_heavy_program_runs_on_eval_engine() {
    let mut s = Session::new();
    let out =
        run_source(&mut s, "symbol-heavy.krf", SYMBOL_HEAVY, Engine::Eval, &[]).expect("eval run");
    assert_eq!(
        out.global("result").expect("result stored").to_string(),
        "60"
    );
}

#[test]
fn shadowed_names_resolve_to_the_innermost_binding() {
    // Same text, distinct bindings: interned identity must not collapse
    // the *binding* structure — the innermost let wins at each step.
    let source = "\
(define (shadow x) (+ x 1))
(define r (let ((x 10)) (let ((x (shadow x))) x)))";
    let mut s = Session::new();
    let out = run_source(&mut s, "shadow.krf", source, Engine::Vm, &[]).expect("vm run");
    assert_eq!(out.global("r").expect("r stored").to_string(), "11");
}

// ---------- cross-stage consumption ----------

#[test]
fn symbol_heavy_program_agrees_across_both_engines() {
    // The parity face: the same interned-symbol program through
    // compiler → vm on one side and the evaluator on the other.
    let mut s = Session::new();
    let report =
        run_parity_source(&mut s, "symbol-heavy.krf", SYMBOL_HEAVY, &[]).expect("parity run");
    assert!(report.agrees(), "drift: {report:?}");
    assert!(report.globals_agree, "result must be `60` on both engines");
}

#[test]
fn parity_contract_flags_wrong_expectation_for_symbol_heavy_program() {
    // The detector-detects duality: a wrong expectation over the
    // symbol-heavy program must be flagged as drift, not swallowed.
    let case = CorpusCase::from_source(
        "symbol-heavy-wrong",
        ";; expect: value 61\n(define (twice x) (* 2 x))\n(define result (twice 30))",
    )
    .expect("directive parses");
    let report = validate(&case);
    assert!(!report.matched, "wrong expectation must be flagged");
}

// ---------- negative ----------

#[test]
fn unbound_identifier_diagnostic_keeps_exact_name_text() {
    // Interning must not garble diagnostics: the rejected program's
    // error message carries the exact identifier text.
    let mut s = Session::new();
    let diags = run_source(
        &mut s,
        "unbound.krf",
        "(define result (+ 1 very-unbound-name-xyz))",
        Engine::Vm,
        &[],
    )
    .expect_err("unbound identifier must be rejected");
    assert!(
        diags
            .iter()
            .any(|d| d.message.contains("very-unbound-name-xyz")),
        "diagnostic must carry the exact name: {diags:?}"
    );
}

#[test]
fn unbound_name_inside_lambda_body_is_rejected() {
    // The deferred-shape face: a free name inside a lambda body is
    // resolved during expansion and rejected with the exact text.
    let mut s = Session::new();
    let diags = run_source(
        &mut s,
        "unbound-lambda.krf",
        "(define (make b) (fn (u) (+ u missing-capture-name)))\n\
         (define result ((make 1) 2))",
        Engine::Vm,
        &[],
    )
    .expect_err("unbound lambda-body name must be rejected");
    assert!(
        diags
            .iter()
            .any(|d| d.message.contains("missing-capture-name")),
        "diagnostic must carry the exact name: {diags:?}"
    );
}

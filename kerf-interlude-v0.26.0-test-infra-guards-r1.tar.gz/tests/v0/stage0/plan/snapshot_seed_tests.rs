//! Stage 0.11 snapshot suite — the §22.3 milestone L6 determinism
//! layer (docs/tests/v0/stage0/plan/snapshot.md).
//!
//! A snapshot case freezes one fixed input into one exact output
//! string across a pipeline layer (stage0.md §13.2 layer 1:
//! deterministic output). The goldens below were recorded from the
//! verified 0.10-r3 baseline (710:0:0 + audit 110/110) via a
//! temporary probe and eye-checked line by line; they change only
//! with an explicit behavior change logged in the worklog.
//!
//! The dump helpers are deterministic test-side walkers (structure
//! only — spans/scopes/phase are the span/syntax test families'
//! job, not the snapshot object).

use kerf::compiler::{Bytecode, compile_program};
use kerf::core::{CoreExpr, LiteralValue, ModuleItem};
use kerf::driver::{self, Engine, Repl, ReplEvent, Session, run_source};
use kerf::expander::expand_program;
use kerf::reader::read_program;
use kerf::span::FileId;
use kerf::syntax::{StxDatum, SyntaxObject};
use kerf::vm::Value;

const FILE: FileId = FileId(0);

// ---------- deterministic dump walkers ----------

fn dump_stx(node: &SyntaxObject) -> String {
    match &node.datum {
        StxDatum::Symbol(s) => s.as_str().to_owned(),
        StxDatum::Int(v) => format!("int:{v}"),
        StxDatum::Float(v) => format!("float:{v}"),
        StxDatum::Bool(v) => format!("bool:{v}"),
        StxDatum::String(s) => format!("str:{s:?}"),
        StxDatum::List(items) => {
            let inner: Vec<String> = items.iter().map(dump_stx).collect();
            format!("({})", inner.join(" "))
        }
    }
}

fn dump_literal(v: &LiteralValue) -> String {
    match v {
        LiteralValue::Int(n) => format!("{n}"),
        LiteralValue::Float(n) => format!("{n}"),
        LiteralValue::Bool(b) => format!("{b}"),
        LiteralValue::String(s) => format!("{s:?}"),
        LiteralValue::Nil => "nil".to_owned(),
        LiteralValue::Pair(a, b) => format!("({} . {})", dump_literal(a), dump_literal(b)),
    }
}

fn dump_core(e: &CoreExpr) -> String {
    match e {
        CoreExpr::Fn { params, body, .. } => format!(
            "(fn ({}) {})",
            params
                .iter()
                .map(|p| p.as_str())
                .collect::<Vec<_>>()
                .join(" "),
            dump_core(body)
        ),
        CoreExpr::Apply { func, args, .. } => {
            let mut parts = vec![dump_core(func)];
            parts.extend(args.iter().map(dump_core));
            format!("(apply {})", parts.join(" "))
        }
        CoreExpr::If {
            cond,
            then_branch,
            else_branch,
            ..
        } => format!(
            "(if {} {} {})",
            dump_core(cond),
            dump_core(then_branch),
            dump_core(else_branch)
        ),
        CoreExpr::Var { name, .. } => name.as_str().to_owned(),
        CoreExpr::Literal { value, .. } => dump_literal(value),
        CoreExpr::Assign { name, value, .. } => {
            format!("(set! {} {})", name.as_str(), dump_core(value))
        }
        CoreExpr::Let { bindings, body, .. } => {
            let bs: Vec<String> = bindings
                .iter()
                .map(|b| format!("({} {})", b.name.as_str(), dump_core(&b.value)))
                .collect();
            format!("(let ({}) {})", bs.join(" "), dump_core(body))
        }
        CoreExpr::Perform { effect, args, .. } => {
            let mut parts = vec![effect.as_str().to_owned()];
            parts.extend(args.iter().map(dump_core));
            format!("(perform {})", parts.join(" "))
        }
        CoreExpr::Handle { body, handlers, .. } => {
            let hs: Vec<String> = handlers
                .iter()
                .map(|h| format!("({} {})", h.effect.as_str(), dump_core(&h.handler)))
                .collect();
            format!("(handle {} {})", dump_core(body), hs.join(" "))
        }
    }
}

fn dump_item(item: &ModuleItem) -> String {
    match item {
        ModuleItem::Define { name, value, .. } => {
            format!("(define {} {})", name.as_str(), dump_core(value))
        }
        ModuleItem::Require { module, .. } => format!("(require {})", module.as_str()),
        ModuleItem::Module { name, items, .. } => {
            let inner: Vec<String> = items.iter().map(dump_item).collect();
            format!("(module {} {})", name.as_str(), inner.join(" "))
        }
        ModuleItem::DefineSyntax { name, .. } => {
            format!("(define-syntax {})", name.as_str())
        }
    }
}

fn dump_bytecode(bc: &Bytecode) -> String {
    let mut out = Vec::new();
    for (i, f) in bc.funcs.iter().enumerate() {
        let name = f.name.as_ref().map(|s| s.as_str()).unwrap_or("<entry>");
        out.push(format!(
            "func {i} {name} params {} locals {}",
            f.params, f.n_locals
        ));
        for instr in &f.code {
            out.push(format!("  {instr}"));
        }
    }
    out.join("\n")
}

// ---------- pipeline drivers ----------

fn read_stx(src: &str) -> Vec<String> {
    let forms = read_program(FILE, src).expect("snapshot source must read");
    forms.iter().map(dump_stx).collect()
}

fn expand_items(src: &str) -> Vec<String> {
    let forms = read_program(FILE, src).expect("snapshot source must read");
    let items = expand_program(&forms).expect("snapshot source must expand");
    items.iter().map(dump_item).collect()
}

fn compile_dump(src: &str) -> String {
    let forms = read_program(FILE, src).expect("snapshot source must read");
    let items = expand_program(&forms).expect("snapshot source must expand");
    let bc = compile_program(&items).expect("snapshot source must compile");
    bc.verify().expect("snapshot product must verify");
    dump_bytecode(&bc)
}

fn run_vm(src: &str) -> (String, String, String) {
    let mut session = Session::new();
    let outcome = run_source(&mut session, "p.krf", src, Engine::Vm, &[]).expect("vm run");
    let globals = outcome
        .globals
        .iter()
        .map(|(n, v)| format!("{n}={v}"))
        .collect::<Vec<_>>()
        .join(" ");
    (
        outcome.value_display(),
        globals,
        outcome.outputs.join(" | "),
    )
}

// ---------- §A reader layer (FP1) ----------

#[test]
fn rs01_int_atom_skeleton() {
    assert_eq!(read_stx("42"), ["int:42"]);
}

#[test]
fn rs02_float_atom_skeleton() {
    assert_eq!(read_stx("-3.5"), ["float:-3.5"]);
}

#[test]
fn rs03_bool_atom_skeleton() {
    assert_eq!(read_stx("#t"), ["bool:true"]);
}

#[test]
fn rs04_string_atom_skeleton() {
    assert_eq!(read_stx("\"hello world\""), ["str:\"hello world\""]);
}

#[test]
fn rs05_symbol_atom_skeleton() {
    assert_eq!(read_stx("sym->name"), ["sym->name"]);
}

#[test]
fn rs06_flat_list_skeleton() {
    assert_eq!(read_stx("(+ 1 2)"), ["(+ int:1 int:2)"]);
}

#[test]
fn rs07_nested_list_skeleton() {
    assert_eq!(read_stx("(a (b (c 1)) 2)"), ["(a (b (c int:1)) int:2)"]);
}

#[test]
fn rs08_comment_and_whitespace_are_lossless() {
    // A leading `;` comment plus blank line: the skeleton is exactly
    // the one form that survives.
    assert_eq!(
        read_stx("; leading comment\n\n(+ 1 2)"),
        ["(+ int:1 int:2)"]
    );
}

#[test]
fn rs09_full_nine_primitive_fib_source_skeleton() {
    assert_eq!(
        read_stx("(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2)))))"),
        ["(define (fib n) (if (< n int:2) n (+ (fib (- n int:1)) (fib (- n int:2)))))"]
    );
}

#[test]
fn rs10_quote_dot_is_an_ordinary_symbol() {
    // Stage 0 grammar fact: `.` inside a list reads as an ordinary
    // symbol atom (dotted pairs are not modeled in StxDatum).
    assert_eq!(
        read_stx("(quote (1 2 . 3))"),
        ["(quote (int:1 int:2 . int:3))"]
    );
}

// ---------- §B expander layer (FP2) ----------

#[test]
fn es01_literal_define_expands_to_int() {
    assert_eq!(expand_items("(define a 42)"), ["(define a 42)"]);
}

#[test]
fn es02_fn_form_expands_to_fn_node() {
    assert_eq!(
        expand_items("(define f (fn (x) (+ x 1)))"),
        ["(define f (fn (x) (apply + x 1)))"]
    );
}

#[test]
fn es03_application_expands_with_explicit_apply_head() {
    assert_eq!(
        expand_items("(define s (+ 1 2 3))"),
        ["(define s (apply + 1 2 3))"]
    );
}

#[test]
fn es04_if_expands_to_three_way_node() {
    assert_eq!(
        expand_items("(define b (if #t 1 2))"),
        ["(define b (if true 1 2))"]
    );
}

#[test]
fn es05_var_reference_expands_to_bare_name() {
    // A let-bound body reference: the Var node renders as the name.
    assert_eq!(
        expand_items("(define l (let ((q 1)) q))"),
        ["(define l (let ((q 1)) q))"]
    );
}

#[test]
fn es06_let_expands_to_binding_chain() {
    assert_eq!(
        expand_items("(define l (let ((a 1) (b 2)) (+ a b)))"),
        ["(define l (let ((a 1) (b 2)) (apply + a b)))"]
    );
}

#[test]
fn es07_do_desugars_to_let_with_discard_names() {
    assert_eq!(
        expand_items("(define d (do (+ 1 2) 7))"),
        ["(define d (let ((_ (apply + 1 2))) 7))"]
    );
}

#[test]
fn es08_assign_keeps_set_head() {
    assert_eq!(
        expand_items("(define g0 1) (define g1 (set! g0 5))"),
        ["(define g0 1)", "(define g1 (set! g0 5))"]
    );
}

#[test]
fn es09_perform_expands_with_effect_name() {
    assert_eq!(
        expand_items("(define p (perform e 1 2))"),
        ["(define p (perform e 1 2))"]
    );
}

#[test]
fn es10_handle_expands_with_handler_clauses() {
    assert_eq!(
        expand_items("(define h (handle (perform e) (e (fn (v) v))))"),
        ["(define h (handle (perform e) (e (fn (v) v))))"]
    );
}

// ---------- §C compiler layer (FP3) ----------

#[test]
fn cs01_literal_define_loads_const_and_stores_global() {
    assert_eq!(
        compile_dump("(define a 7)"),
        "func 0 <entry> params 0 locals 0\n  push-const 0 0\n  store-global 0 0\n  halt 0 0"
    );
}

#[test]
fn cs02_binary_application_is_two_consts_global_call() {
    assert_eq!(
        compile_dump("(define s (+ 2 3))"),
        "func 0 <entry> params 0 locals 0\n  push-const 0 0\n  push-const 1 0\n  load-global 0 0\n  call 2 0\n  store-global 1 0\n  halt 0 0"
    );
}

#[test]
fn cs03_if_compiles_to_jump_shape() {
    assert_eq!(
        compile_dump("(define b (if (< 1 2) 10 20))"),
        "func 0 <entry> params 0 locals 0\n  push-const 0 0\n  push-const 1 0\n  load-global 0 0\n  call 2 0\n  jump-if-false 7 0\n  push-const 2 0\n  jump 8 0\n  push-const 3 0\n  store-global 1 0\n  halt 0 0"
    );
}

#[test]
fn cs04_let_compiles_to_store_local_chain() {
    assert_eq!(
        compile_dump("(define l (let ((a 1) (b 2)) (+ a b)))"),
        "func 0 <entry> params 0 locals 2\n  push-const 0 0\n  store-local 0 0\n  push-const 1 0\n  store-local 1 0\n  load-local 0 0\n  load-local 1 0\n  load-global 0 0\n  call 2 0\n  store-global 1 0\n  halt 0 0"
    );
}

#[test]
fn cs05_define_function_produces_closure_proto() {
    assert_eq!(
        compile_dump("(define (f x) (+ x 1))"),
        "func 0 <entry> params 0 locals 0\n  closure 1 0\n  store-global 1 0\n  halt 0 0\nfunc 1 f params 1 locals 1\n  load-local 0 0\n  push-const 0 0\n  load-global 0 0\n  call 2 0\n  ret 0 0"
    );
}

#[test]
fn cs06_anonymous_closure_immediate_call() {
    assert_eq!(
        compile_dump("(define s2 ((fn (x) (* x x)) 6))"),
        "func 0 <entry> params 0 locals 0\n  push-const 0 0\n  closure 1 0\n  call 1 0\n  store-global 1 0\n  halt 0 0\nfunc 1 <entry> params 1 locals 1\n  load-local 0 0\n  load-local 0 0\n  load-global 0 0\n  call 2 0\n  ret 0 0"
    );
}

#[test]
fn cs07_cons_is_an_ordinary_global_call() {
    assert_eq!(
        compile_dump("(define p (cons 1 2))"),
        "func 0 <entry> params 0 locals 0\n  push-const 0 0\n  push-const 1 0\n  load-global 0 0\n  call 2 0\n  store-global 1 0\n  halt 0 0"
    );
}

#[test]
fn cs08_nested_call_is_inner_first() {
    assert_eq!(
        compile_dump("(define c (car (cons 1 2)))"),
        "func 0 <entry> params 0 locals 0\n  push-const 0 0\n  push-const 1 0\n  load-global 0 0\n  call 2 0\n  load-global 1 0\n  call 1 0\n  store-global 2 0\n  halt 0 0"
    );
}

#[test]
fn cs09_fib_closure_is_the_21_instruction_contract() {
    assert_eq!(
        compile_dump("(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2)))))"),
        "func 0 <entry> params 0 locals 0\n  closure 1 0\n  store-global 2 0\n  halt 0 0\nfunc 1 fib params 1 locals 1\n  load-local 0 0\n  push-const 0 0\n  load-global 0 0\n  call 2 0\n  jump-if-false 7 0\n  load-local 0 0\n  ret 0 0\n  load-local 0 0\n  push-const 1 0\n  load-global 1 0\n  call 2 0\n  load-global 2 0\n  call 1 0\n  load-local 0 0\n  push-const 0 0\n  load-global 1 0\n  call 2 0\n  load-global 2 0\n  call 1 0\n  load-global 3 0\n  call 2 0\n  ret 0 0"
    );
}

#[test]
fn cs10_entry_consumes_the_defined_closure() {
    assert_eq!(
        compile_dump(
            "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define r (fib 6))"
        ),
        "func 0 <entry> params 0 locals 0\n  closure 1 0\n  store-global 2 0\n  push-const 2 0\n  load-global 2 0\n  call 1 0\n  store-global 4 0\n  halt 0 0\nfunc 1 fib params 1 locals 1\n  load-local 0 0\n  push-const 0 0\n  load-global 0 0\n  call 2 0\n  jump-if-false 7 0\n  load-local 0 0\n  ret 0 0\n  load-local 0 0\n  push-const 1 0\n  load-global 1 0\n  call 2 0\n  load-global 2 0\n  call 1 0\n  load-local 0 0\n  push-const 0 0\n  load-global 1 0\n  call 2 0\n  load-global 2 0\n  call 1 0\n  load-global 3 0\n  call 2 0\n  ret 0 0"
    );
}

// ---------- §D vm / eval layer (FP4) ----------

#[test]
fn vs01_arithmetic_define_runs_to_value() {
    let (val, globals, outs) = run_vm("(define r (+ 1 2))");
    assert_eq!(val, "nil");
    assert_eq!(globals, "+=#<builtin:+> r=3");
    assert_eq!(outs, "");
}

#[test]
fn vs02_recursive_fact_runs_to_720() {
    let (val, globals, outs) =
        run_vm("(define (fact n) (if (< n 2) 1 (* n (fact (- n 1))))) (define r (fact 6))");
    assert_eq!(val, "nil");
    assert_eq!(
        globals,
        "<=#<builtin:<> -=#<builtin:-> fact=#<closure> *=#<builtin:*> r=720"
    );
    assert_eq!(outs, "");
}

#[test]
fn vs03_cons_produces_opaque_pair_global() {
    let (val, globals, outs) = run_vm("(define p (cons 1 2))");
    assert_eq!(val, "nil");
    assert_eq!(globals, "cons=#<builtin:cons> p=#<pair>");
    assert_eq!(outs, "");
}

#[test]
fn vs04_car_of_cons_selects_left_string() {
    let (val, globals, outs) = run_vm("(define c (car (cons \"left\" 2)))");
    assert_eq!(val, "nil");
    assert_eq!(
        globals,
        "cons=#<builtin:cons> car=#<builtin:car> c=\"left\""
    );
    assert_eq!(outs, "");
}

#[test]
fn vs05_set_mutates_global_in_place() {
    let (val, globals, outs) = run_vm("(define a 1) (define a2 (set! a 5)) (define r2 a)");
    assert_eq!(val, "nil");
    assert_eq!(globals, "a=5 a2=5 r2=5");
    assert_eq!(outs, "");
}

#[test]
fn vs06_let_bindings_sum_to_three() {
    let (val, globals, outs) = run_vm("(define l (let ((a 1) (b 2)) (+ a b)))");
    assert_eq!(val, "nil");
    assert_eq!(globals, "+=#<builtin:+> l=3");
    assert_eq!(outs, "");
}

#[test]
fn vs07_nil_predicate_branches_to_string() {
    let (val, globals, outs) = run_vm("(define s (if (nil? nil) \"is-nil\" \"not-nil\"))");
    assert_eq!(val, "nil");
    assert_eq!(globals, "nil?=#<builtin:nil?> s=\"is-nil\"");
    assert_eq!(outs, "");
}

#[test]
fn vs08_write_line_emits_the_output_line() {
    let (val, globals, outs) = run_vm("(define w (write-line \"out-line\"))");
    assert_eq!(val, "nil");
    assert_eq!(globals, "write-line=#<builtin:write-line> w=nil");
    assert_eq!(outs, "out-line");
}

#[test]
fn vs09_eq_on_two_pairs_is_false_identity_semantics() {
    // Two cons allocations are distinct heap objects: eq? is identity,
    // not structural equality.
    let (val, globals, outs) = run_vm("(define e (eq? (cons 1 2) (cons 1 2)))");
    assert_eq!(val, "nil");
    assert_eq!(globals, "cons=#<builtin:cons> eq?=#<builtin:eq?> e=false");
    assert_eq!(outs, "");
}

#[test]
fn vs10_pair_predicate_is_true_on_pair() {
    let (val, globals, outs) = run_vm("(define p2 (pair? (cons 1 2)))");
    assert_eq!(val, "nil");
    assert_eq!(
        globals,
        "cons=#<builtin:cons> pair?=#<builtin:pair?> p2=true"
    );
    assert_eq!(outs, "");
}

#[test]
fn ve01_eval_engine_fib_ten_agrees() {
    let mut session = Session::new();
    let src = "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define r (fib 10))";
    let outcome = run_source(&mut session, "p.krf", src, Engine::Eval, &[]).expect("eval run");
    assert_eq!(
        outcome.global("r").map(|v| v.to_string()),
        Some("55".to_owned())
    );
}

#[test]
fn ve02_eval_engine_car_selects_left() {
    let mut session = Session::new();
    let src = "(define c (car (cons \"left\" 2)))";
    let outcome = run_source(&mut session, "p.krf", src, Engine::Eval, &[]).expect("eval run");
    assert_eq!(
        outcome.global("c").map(|v| v.to_string()),
        Some("\"left\"".to_owned())
    );
}

// ---------- §E driver layer (FP5) ----------

fn render_of(src: &str) -> String {
    let mut session = Session::new();
    let diags = run_source(&mut session, "p.krf", src, Engine::Vm, &[]).expect_err("must fail");
    driver::render_diagnostics(&session, &diags)
}

#[test]
fn ds01_unclosed_delimiter_render_golden() {
    assert_eq!(
        render_of("(+ 1 2"),
        "error[kerf-read]: unclosed delimiter: `(` is never closed\n --> p.krf:1:1\n  |\n1 | (+ 1 2\n  | ^\n"
    );
}

#[test]
fn ds02_type_mismatch_render_golden() {
    // The Stage 1.8 HM wiring hoists the literal `(car 5)` face to
    // the checker (E0009, probe-verified); this golden keeps the
    // runtime face by feeding `car` through an HM-released dynamic
    // parameter (a forall-a schema the caller satisfies — the shape
    // constraint is released, §9.49 GATE-2).
    assert_eq!(
        render_of("(define f (fn (x) (car x)))\n(define r (f 5))"),
        "error[kerf-runtime]: type mismatch: car operand must be a matching kind, got `int`\n --> p.krf:1:19\n  |\n1 | (define f (fn (x) (car x)))\n  |                   ^^^^^^^\n"
    );
}

#[test]
fn ds02b_hm_checker_mismatch_render_golden() {
    // The checker face the HM wiring adds: the literal car-of-int
    // is now a compile-time E0009 (probe-verified at Stage 1.8).
    assert_eq!(
        render_of("(define r (car 5))"),
        "error[E0009]: type mismatch: expected `pair`, found `int`\n --> p.krf:1:11\n  |\n1 | (define r (car 5))\n  |           ^^^^^^^\n"
    );
}

#[test]
fn ds03_arity_mismatch_render_golden() {
    // Golden updated with the Stage 1.1 wiring (behavior change: a
    // known-callee arity mismatch is now caught statically before
    // execution — E0002 registry tag, no runtime file# suffix; the
    // runtime face stays covered by the driver module tests through
    // a checker-opaque param-mediated call).
    assert_eq!(
        render_of("(define r (+ 1 2 3))"),
        "error[E0002]: arity mismatch: `+` expects `2` arguments, got `3`\n --> p.krf:1:11\n  |\n1 | (define r (+ 1 2 3))\n  |           ^^^^^^^^^\n"
    );
}

#[test]
fn ds04_unbound_identifier_render_golden() {
    assert_eq!(
        render_of("(define r (undefined-fn 1))"),
        "error[kerf-expand]: unbound identifier `undefined-fn`: not in any lexical scope and not a Stage 0 global\n --> p.krf:1:12\n  |\n1 | (define r (undefined-fn 1))\n  |            ^^^^^^^^^^^^\n"
    );
}

#[test]
fn ds05_empty_application_render_golden() {
    assert_eq!(
        render_of("(define r ())"),
        "error[kerf-read]: empty application: `()` has no operator\n --> p.krf:1:11\n  |\n1 | (define r ())\n  |           ^\n"
    );
}

#[test]
fn ds06_check_face_counts_the_product() {
    let mut session = Session::new();
    let src = "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define r (fib 6))";
    let check = driver::check_source(&mut session, "p.krf", src).expect("check");
    assert_eq!(
        format!(
            "funcs={} instrs={} globals={}",
            check.func_count, check.instr_count, check.global_count
        ),
        "funcs=2 instrs=29 globals=5"
    );
}

#[test]
fn ds07_parity_three_faces_agree() {
    let mut session = Session::new();
    let src = "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define r (fib 6))";
    let report = driver::run_parity_source(&mut session, "p.krf", src, &[]).expect("parity");
    assert_eq!(
        format!(
            "values={} outputs={} globals={}",
            report.values_agree, report.outputs_agree, report.globals_agree
        ),
        "values=true outputs=true globals=true"
    );
}

#[test]
fn ds08_workspace_version_string() {
    // Golden updated with the v0.26.0 interlude release (behavior
    // change: workspace version bump — the test-infrastructure
    // self-audit round, stage0.md §9.57; prior goldens: 0.25.0
    // recorded at the diagnostics-domain round, 0.24.0 recorded at
    // the determinism guard round, 0.23.0 recorded at the symbol
    // interning round, 0.22.0 recorded at the 1.9
    // stage-close, 0.21.0 recorded at 1.8, 0.20.0 recorded at 1.7,
    // 0.18.0 recorded at 1.5, 0.17.0 recorded at 1.4, 0.16.0
    // recorded at 1.3, 0.15.0 recorded at 1.2, 0.14.0 recorded at
    // 1.1, 0.13.0 recorded at 1.0, 0.12.0 recorded at the 0.11
    // stage-close).
    assert_eq!(kerf::WORKSPACE_VERSION, "0.26.0");
}

#[test]
fn ds09_output_lines_keep_submission_order() {
    let mut session = Session::new();
    let src = "(define r (write-line \"a\")) (define r2 (write-line \"b\"))";
    let outcome = run_source(&mut session, "p.krf", src, Engine::Vm, &[]).expect("run");
    assert_eq!(outcome.outputs.join(" | "), "a | b");
    assert_eq!(outcome.value_display(), "nil");
}

#[test]
fn ds10_two_diagnostics_render_with_summary_line() {
    // Two broken files in one session: errors are data — collected
    // across runs, rendered together, closed by the summary line.
    let mut session = Session::new();
    let mut all = Vec::new();
    for (name, src) in [("one.krf", "(+ 1"), ("two.krf", "(define r (nope))")] {
        if let Err(diags) = run_source(&mut session, name, src, Engine::Vm, &[]) {
            all.extend(diags);
        }
    }
    let rendered = driver::render_diagnostics(&session, &all);
    assert_eq!(
        rendered,
        "error[kerf-read]: unclosed delimiter: `(` is never closed\n --> one.krf:1:1\n  |\n1 | (+ 1\n  | ^\n\nerror[kerf-expand]: unbound identifier `nope`: not in any lexical scope and not a Stage 0 global\n --> two.krf:1:12\n  |\n1 | (define r (nope))\n  |            ^^^^\nerror: aborting due to 2 previous errors\n"
    );
}

// ---------- §F repl transcripts (FP6) ----------

#[test]
fn ts01_session_transcript_values_and_outputs() {
    let mut repl = Repl::new();
    let mut transcript = Vec::new();
    for line in ["(define x 41)", "(+ x 1)", "(write-line \"hi\")"] {
        match repl.submit(line) {
            ReplEvent::Evaluated {
                value,
                new_outputs,
                new_warnings,
            } => {
                assert!(new_warnings.is_empty(), "ts02 warning-free corpus");
                transcript.push(format!(
                    "value={:?} outputs={:?}",
                    value.unwrap_or_default(),
                    new_outputs
                ))
            }
            other => panic!("unexpected event: {other:?}"),
        }
    }
    assert_eq!(
        transcript,
        [
            "value=\"\" outputs=[]".to_owned(),
            "value=\"42\" outputs=[]".to_owned(),
            "value=\"nil\" outputs=[\"hi\"]".to_owned(),
        ]
    );
}

#[test]
fn ts02_error_submission_rolls_back_and_session_survives() {
    let mut repl = Repl::new();
    match repl.submit("(define y 5)") {
        ReplEvent::Evaluated { .. } => {}
        other => panic!("define: {other:?}"),
    }
    match repl.submit("(+ y undefined-var)") {
        ReplEvent::Error { rendered } => {
            assert_eq!(rendered.lines().count(), 5);
        }
        other => panic!("error expected: {other:?}"),
    }
    match repl.submit("y") {
        ReplEvent::Evaluated { value, .. } => assert_eq!(value.as_deref(), Some("5")),
        other => panic!("y: {other:?}"),
    }
}

#[test]
fn ts03_unclosed_submission_asks_for_more() {
    let mut repl = Repl::new();
    assert!(matches!(repl.submit("(+ 1"), ReplEvent::NeedMoreInput));
}

#[test]
fn ts04_continuation_line_completes_the_program() {
    let mut repl = Repl::new();
    assert!(matches!(repl.submit("(+ 1"), ReplEvent::NeedMoreInput));
    match repl.submit("2)") {
        ReplEvent::Evaluated { value, .. } => assert_eq!(value.as_deref(), Some("3")),
        other => panic!("continuation: {other:?}"),
    }
}

#[test]
fn vd01_value_display_eight_forms() {
    let forms = [
        Value::Int(-7).to_string(),
        Value::Float(2.5).to_string(),
        Value::Bool(true).to_string(),
        Value::Str("s".into()).to_string(),
        Value::Nil.to_string(),
        Value::Pair(3).to_string(),
        Value::Closure(9).to_string(),
        kerf::vm::Builtin::from_name("+")
            .map(|b| Value::Builtin(b).to_string())
            .unwrap_or_default(),
    ];
    assert_eq!(
        forms,
        [
            "-7",
            "2.5",
            "true",
            "\"s\"",
            "nil",
            "#<pair>",
            "#<closure>",
            "#<builtin:+>",
        ]
    );
}

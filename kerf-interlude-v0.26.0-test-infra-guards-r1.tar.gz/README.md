# kerf

A minimal-bootstrap systems programming language compiler — Rust workspace,
edition 2024.

> **One-liner** (activation protocol): Rust kerf compiler, Cargo Workspace
> edition 2024 (`kerf_*` crates), frozen minimal-primitive kernel (primitive
> invariance: no new primitives, no channels, no VM rewrite, no syntax),
> Stage 0-1 self-built VM (**the VM is a permanent Rust base — a
> "fully self-hosted" VM rewrite is constitutionally excluded**), LLVM /
> native-code backends never enter the bootstrap chain.

## Status

**Stage 1 CLOSED · interlude v0.26.0 (test-infrastructure self-audit — three inventory guards machine-locked: runner mounting, corpus table/directory parity, audit case registration with uniform `// XNN:` labels; 1174:0:0 + audit 200/200) — all nine sub-stages delivered (typecheck base, driver wiring, PBT, HM inference, subset freeze, .krf reader/expander/macro segments + fixpoint gate B, gate-prep, exit round: deep-review D1-D8 + seven-piece finals + nine-signal audit 200 + GO recommended). Stage 2 entry explicitly prohibited by the user (r54, reaffirmed r55/r56) until lifted — entry plan stands: lexical addressing + capture activation first knife (symbol identity foundation in place, stage0.md §9.52; determinism prerequisite locked, §9.55; diagnostics position single-sourced, §9.56; test-infrastructure invariants guarded, §9.57).**

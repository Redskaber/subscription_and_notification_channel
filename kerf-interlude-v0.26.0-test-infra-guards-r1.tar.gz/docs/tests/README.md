# 测试文档索引（docs/tests/）

> 依据：docs/sop.md §9.2——每个测试代码文件必须有对应测试文档（双向印证）。

| 测试代码 | 测试文档 | 层级 |
|---------|---------|------|
| crates/kerf-span/src/span.rs（内联 tests） | v0/stage0/plan/span.md | 单元 |
| crates/kerf-span/tests/api_tests.rs | v0/stage0/plan/span.md | crate API |
| tests/v0/stage0/plan/span_seed_tests.rs（经 tests/runner.rs 挂载） | v0/stage0/plan/span.md | 跨 crate 集成 |
| tests/v0/stage0/plan/snapshot_seed_tests.rs（经 tests/runner.rs 挂载——0.11 快照层） | v0/stage0/plan/snapshot.md | 跨 crate 快照冻结 |
| tests/v1/stage1/plan/pbt_seed_tests.rs（经 tests/runner.rs 挂载——1.2 属性层 PBT） | v1/stage1/pbt.md | 跨 crate 属性 |
| tests/v1/stage1/plan/hm_inference_seed_tests.rs（经 tests/runner.rs 挂载——1.3 HM 推断基座：FP1-FP8 + IS 快照族） | v1/stage1/hm-inference.md | 跨 crate 集成 + 快照冻结 |
| tests/v1/stage1/plan/reader_parity_tests.rs（经 tests/runner.rs 挂载——1.5 Reader parity：FP1-FP8 + 语料 68 重放 + 自举不动点） | v1/stage1/reader-parity.md | 跨 crate 集成（双轴双引擎） |
| tests/v1/stage1/plan/expander_parity_tests.rs（经 tests/runner.rs 挂载——1.6 Expander parity：FP1-FP8 + 七 span 陷阱 + 绑定纪律 + loader 面 + 语料 72 重放 + 双面自举不动点） | v1/stage1/expander-parity.md | 跨 crate 集成（双轴双引擎三层分流） |
- [v1/stage1/macro-parity.md](v1/stage1/macro-parity.md) — Stage 1.7 macro parity + fixpoint gate B (MP1-MP11)
| tests/v1/stage1/plan/subset_corpus_tests.rs（经 tests/runner.rs 挂载——1.4 验收语料：逐条 68 + 动态全目录扫 + 分布底线） | v1/stage1/plan-1.4.md §3 + subset-spec.md §3 | 跨 crate 集成（语料契约） |
| tests/v1/stage1/plan/parity_contract_tests.rs（经 tests/runner.rs 挂载——1.4 parity 契约面：正负 + 跨阶段消费） | v1/stage1/plan-1.4.md §3 + stage0.md §9.45.6 | 跨 crate 集成（BS-C 1.4 切片） |
| （审查文档）pipeline-test-coverage.md（0.11 深验件——四轴完整性审查） | 自身即文档（数据流覆盖） | 审查 |
| audit U 节（1.8 门审全集复跑增量——HM 接线 E2E 三断言 + 1.7 修复边界族 + 跨子阶段集成） | examples/audit/stage0_gate_audit_r1.rs（190） | 审计 |
| FP3 硬化（1.8 HM release-and-demand——释放族 ×3 / bool 需求保持 / 已知释放登记） | tests/v1/stage1/plan/hm_inference_seed_tests.rs | 测试 |
| audit V 节（1.9 出阶段证据——九信号逐项锚 + 恢复收口） | examples/audit/stage0_gate_audit_r1.rs（200） | 审计 |
| 出阶段测试族（1.9——§21.5 信号常驻 cargo 锚：正 6/负 3/跨阶段 4） | tests/v1/stage1/plan/stage_exit_tests.rs | 跨 crate 集成（出阶段契约） |
| Symbol 驻留集成族（阶段间 29-c——v0.23.0 表示置换管道行为锚：正 5/负 4/跨阶段 2） | tests/v1/stage1/plan/symbol_intern_tests.rs + 两 crate symbol.rs 内联（+10） | 跨 crate 集成（stage0.md §9.52.4 单源承载） |
| 诊断域位置单源化族（阶段间 33-c——v0.25.0：消息-位置分离 36 Display 站点 + Session 行索引缓存 + parity 键连锁修正；29 期望更新 + 1 新增缓存测试 + 金色再基线六处） | 四错误族 error.rs Display + kerf-driver session.rs/render.rs + reader_parity/expander_parity parity 键 + snapshot/driver/audit 期望面 | 跨 crate 集成（stage0.md §9.56 单源承载） |
| 确定性守护集成族（阶段间 32-d——v0.24.0 fixpoint 门 B 前置锁定：装配主体双跑 + 79 语料双跑 + 改名面 + 检测器三臂 + 首用序语义，正 4/负 3/跨阶段 1） | tests/v1/stage1/plan/determinism_guard_tests.rs + 四处不变量注释（compile/transformer/eval/gc） | 跨 crate 集成（stage0.md §9.55 单源承载） |
| 测试基础设施自审计族（阶段间 34-d——v0.26.0 三清单守卫：runner 装配双向完备 + 语料表-目录 parity + audit 案例注册[统一 `// XNN:` 规约] + 计数器检测力臂，正 3/负 1/元域 3） | tests/v1/stage1/plan/test_infra_guard_tests.rs + audit 标签规约化（A-C 补注/H07 补标/U-V 双位化——纯注释零行为变更） | 跨 crate 集成（stage0.md §9.57 单源承载——元域：测试树对自身的清单不变量） |

全局矩阵：[matrix.md](matrix.md)（阶段门审查输入）。

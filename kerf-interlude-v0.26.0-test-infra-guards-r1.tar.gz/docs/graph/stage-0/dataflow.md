# Stage 0 数据流与依赖图（graph/stage-0/）

> 依据：docs/sop.md §15（项目图管理）+ §18.5（内部依赖图）+ §9.5.1（流水线路径覆盖矩阵）。
> 图形与文档同源：结构变更须同步更新本图（§8.4.6 规则 5）。

## 1. Cargo Workspace 依赖 DAG（SOP §18.5——当前实现态）

```mermaid
flowchart TD
    subgraph Implemented["已实现（Stage 0.0-0.8 全九层）"]
        L0["kerf-span<br/>Span/位置（48 测试绿）"]
        L1["kerf-syntax<br/>SyntaxObject 四元组（40 crate 测试 + 8 集成）"]
        L2["kerf-reader<br/>lexer/parser → stx 树（51 crate 测试 + 9 集成）"]
        L3["kerf-expander<br/>展开→CoreExpr + do→Let + **宏系统**（0.9：define-syntax/syntax-rules 变换器 + 子集判据 + rename-on-capture + CodeValue + 模块加载层 + quote——85 crate 测试 + 27 集成）"]
        L4["kerf-core<br/>CoreExpr/ModuleItem（40 crate 测试 + 8 集成）"]
        L5["kerf-compiler<br/>CoreExpr→Bytecode + debug_info + verify（42 crate 测试 + 8 集成——0.6 回归对 +2）"]
        L6["kerf-vm<br/>迭代主循环 VM + 堆帧栈 + RuntimeError(Span)（46 crate 测试 + 8 集成）"]
    end
        L7["kerf-runtime<br/>标记-清除 GC + eval 元循环 + parity（42 crate 测试 + 20 集成）"]
        L45["kerf-typecheck<br/>保守静态 R1-R8 + E0xxx 注册面 + 多错误收集（51 内联 + 7 api + 21 集成——1.0 落位 L4.5：kerf-core 后 compiler 前）"]
        L8["kerf-driver<br/>管线编排双引擎 + **typecheck 前置接线（1.1）** + 诊断渲染 + CLI/REPL + Warning 通道（118 内联 + 22+10 集成）"]
    end
    ROOT["kerf（根聚合 crate + 根 tests/）"]

    L0 --> L1
    L1 --> L2
    L1 --> L3
    L4 --> L3
    L4 --> L5
    L5 --> L6
    L6 --> L7
    L7 -->|§18.5 新边（0.7 裁定十四）：CoreExpr/ModuleItem eval 输入| L4
    L7 -->|Span/Symbol 类型面（0.5 决策 14 先例）| L5
    L2 --> L8
    L3 --> L8
    L5 --> L8
    L6 --> L8
    L1 -->|§18.5 新边（0.8 裁定十一）：REPL 表单分类直查 SyntaxObject| L8
    L7 -->|§18.5 新边（0.8 裁定十一）：Engine::Eval 函数调用面| L8
    L45 -->|§18.5 新边（1.1）：typecheck 级入管线 read→expand→typecheck→{compile,eval}——Externals 第三消费位（STAGE0_GLOBALS + Builtin::ALL 单源）| L8
    L0 -->|TD-004 已裁定（0.1）| L4
    ROOT -.->|聚合 re-export| L0 & L1 & L2 & L3 & L4 & L5 & L6 & L7 & L8
```

> 注：实线 = §18.5 既有边；kerf-span→kerf-core 边于 Stage 0.1 裁定落地（TD-004 清偿，docs/develop/v0/stage-0/0.1-design-adjudications.md 裁定二）；kerf-runtime→kerf-core / →kerf-compiler 边于 0.7 裁定十四落地；**kerf-syntax→kerf-driver / kerf-runtime→kerf-driver 边于 0.8 裁定十一落地（plan-0.8.md §4——L1→L8 REPL 表单分类直查先例 + L7→L8 eval 引擎函数调用面）**；虚线 = 根聚合关系。0.5 起 kerf-core 再导出 Span 坐标类型（FileId/ByteOffset/ExpansionId——compiler 冷启动锚构造的消费面完整性传递，plan-0.5.md §4 决策 14 实施修订）；0.6 起 kerf-compiler 再导出 LiteralValue/Span/Symbol（VM 生产消费面完整性传递——零新 DAG 边，plan-0.6.md §4 决策 1/沿 0.5 决策 14 先例）；0.8 起 kerf-compiler 再导出 ModuleItem（driver 消费面完整性传递——零新 DAG 边，plan-0.8.md §4 决策 5），kerf-core 仅 dev-dependencies 于 kerf-vm（CoreExpr 夹具构造）。**1.0 起 kerf-typecheck 落位 L4.5（kerf-core/kerf-span 两条内部边——外部 Rust 检查器路径 §21.6；节点登记回补于 1.1 轮 §20.3 同族顺修）。1.1 起 L4.5→L8 消费边落地（driver 第三 Externals 消费位 + check/run/run_parity 前置检查阶段——Error 中止/Warning 附着 Outcome；plan-1.1.md §4）。**0.10 起 kerf-core 增 `reserved` 冻结面模块族（EffectSystem/MultiStage/CapabilityIO/CompilationCache——§22.3 四接口项；裁定十七：除 std 外零入边零出边于 DAG——预留面不参与生产数据流，消费仅经根聚合与测试位；六域从属以文档声明位承载——kerf-space re-anchoring = Stage 1+ 加法路径）。0.10-r2 起能力域泛化为 `capability/` 模块族（family 族契约 + token 令牌纪律 + registry 注册拓展机制 + io 首子模型——裁定二十：预留注册与拓展抽象模型的能力本身；旧 capability_io 路径 re-export 存续[冻结连续性]；DAG 零变更——预留面维持零入边零出边）**；**1.2 起 dev 侧增 proptest 1.11.0（根包 [dev-dependencies] 唯一一条——§18.5 dev 侧豁免位：永不入语言管线/自举链/成员 crate 生产依赖；生产 DAG 零变更——plan-1.2.md §4 版本解析披露）。**

## 2. 目标编译流水线（Stage 0 完成态——测试路径覆盖对象）

```mermaid
flowchart LR
    Source["源码"] --> R["Reader<br/>(0.3)"]
    R --> SO["SyntaxObject<br/>含 Span (0.2)"]
    SO --> E["Expander<br/>(0.4)"]
    E --> CE["CoreExpr<br/>9 语义原语 (0.1)"]
    CE --> C["Compiler<br/>(0.5)"]
    C --> BC["Bytecode<br/>含 debug_info"]
    BC --> VM["VM (0.6)"]
    VM --> V["Value"]
    V -.->|双路径互查| EVAL["eval (0.7)"]
    CE -.-> EVAL
```

## 3. Span 消费流（stage0.md §12.1 消费表——Stage 0.0 已交付首行）

| 阶段 | Span 携带位置 | 消费方式 | 状态 |
|------|-------------|---------|------|
| Reader | 每个 Token | 词法错误定位、无损覆盖校验（join 归约模式已由集成测试验证） | 0.3 |
| Expander | SyntaxObject + expansion_id | 多阶段错误关联、卫生性追踪 | 0.4 |
| Compiler | 字节码指令 → debug_info_table | 运行时错误反查源码 | 0.5 |
| VM | debug_info_table（按 pc 查询——contains_offset 已就绪） | 堆栈追踪、调试断点 | 0.6 |
| 增量编译 | 文件 × 字节区间 | 细粒度失效传播 | Stage 1+ |

> **1.5 增注（selfhost 面）**：`selfhost/v1/reader.krf` = 跨 crate 全局工件（§8.4.6 新根目录——自举面登记，切换窗步②首切口物理锚位）。DAG 零变更：.krf Reader 是**被编译对象**而非编译器成员——消费路径 = kerf-driver reader_parity harness（表格注入 → 既有 L2 Rust reader 读取装配源 → L3-L8 全链 → 双引擎执行）→ 生产 DAG 经既有十边承载零新边零新节点；kerf-reader 公共面补 `FileId`/`ByteOffset` re-export（既有签名类型可名化——零新边）。

#
# License: See LICENSE.md file
# GitHub: https://github.com/Baekalfen/PyBoy
#

from array import array
from ctypes import c_void_p
from random import getrandbits

import pyboy
from pyboy.utils import PyBoyException, INTR_VBLANK, INTR_LCDC, FRAME_CYCLES
from pyboy.api.constants import ROWS, COLS, TILES

logger = pyboy.logging.get_logger(__name__)

VIDEO_RAM = 8 * 1024  # 8KB
OBJECT_ATTRIBUTE_MEMORY = 0xA0

# The target mode and timing phase are independent parts of the LCD state.
STAT_TRANSITION_NONE = 0
STAT_TRANSITION_ADVANCE_LY = 1
STAT_TRANSITION_START_MODE2 = 2
STAT_TRANSITION_VBLANK_PRETRIGGERED = 3


def rgb_to_bgr(color):
    a = 0xFF
    r = (color >> 16) & 0xFF
    g = (color >> 8) & 0xFF
    b = color & 0xFF
    return (a << 24) | (b << 16) | (g << 8) | r


class LCD:
    def __init__(self, cgb, cgb_mode, color_palette, cgb_color_palette, randomize=False):
        self.VRAM0 = array("B", [0] * VIDEO_RAM)
        self.OAM = array("B", [0] * OBJECT_ATTRIBUTE_MEMORY)
        self.disable_renderer = False

        if randomize:
            for i in range(VIDEO_RAM):
                self.VRAM0[i] = getrandbits(8)
            for i in range(OBJECT_ATTRIBUTE_MEMORY):
                self.OAM[i] = getrandbits(8)

        self._LCDC = LCDCRegister(0)
        self._STAT = STATRegister()  # Bit 7 is always set.

        self.speed_shift = 0
        self.clock = 0
        self.clock_target = FRAME_CYCLES
        self.frame_done = False
        self.first_frame = False
        self.reset = False
        self.stat_mode_override = False
        self.lyc_changed_while_disabled = False
        self._cycles_to_interrupt = 0
        self._cycles_to_frame = (FRAME_CYCLES - self.clock) << self.speed_shift
        self.next_stat_mode = 2
        self.stat_transition = STAT_TRANSITION_NONE
        self.LY = 0x00
        self.mode3_adjustment = 0
        self._STAT.set_mode(0)

        self.SCY = 0x00
        self.SCX = 0x00
        self.LYC = 0x00
        # self.DMA = 0x00
        self.WY = 0x00
        self.WX = 0x00
        self.object_priority_mode = 0xFF  # TODO: Not implemented

        self.cgb = cgb
        self._downgraded_to_dmg = False
        self._scanlineparameters = [[0, 0, 0, 0, 0] for _ in range(ROWS)]
        self.last_cycles = 0
        self._cycles_to_interrupt = 0
        self._cycles_to_frame = (FRAME_CYCLES - self.clock) << self.speed_shift

        if self.cgb:
            logger.debug("Starting CGB renderer")
            # Setting for both modes, even though CGB is ignoring them. BGP[0] used in scanline_blank.
            bg_pal, obj0_pal, obj1_pal = cgb_color_palette
            self.BGP = PaletteRegister(0xFC, bg_pal)
            self.OBP0 = PaletteRegister(0xFF, obj0_pal)
            self.OBP1 = PaletteRegister(0xFF, obj1_pal)
        else:
            logger.debug("Starting DMG renderer")
            self.BGP = PaletteRegister(0xFC, color_palette)
            self.OBP0 = PaletteRegister(0xFF, color_palette)
            self.OBP1 = PaletteRegister(0xFF, color_palette)
        self.renderer = Renderer(self, self.cgb)

        # CGB specific
        if self.cgb:
            self.VRAM1 = array("B", [0] * VIDEO_RAM)

            self.vbk = VBKregister()
            self.bcps = PaletteIndexRegister()  # Only stored here for access in mb
            self.bcpd = PaletteColorRegister(self.bcps)
            self.ocps = PaletteIndexRegister()  # Only stored here for access in mb
            self.ocpd = PaletteColorRegister(self.ocps)

    def switch_cgb(self, is_dmg_rom):
        # Bootrom requests CGB hardware to switch to DMG rendering. This is only
        # done once, and only downgraded from CGB to DMG at the end of CGB bootrom.
        if self.cgb and is_dmg_rom:
            logger.debug("Migrating from CGB renderer to DMG renderer")
            self.cgb = False
            self.renderer.cgb = False
            self._downgraded_to_dmg = True
        else:
            logger.debug("Ignoring key0 change")

    def set_lcdc(self, value):
        _lcd_enable = self._LCDC.lcd_enable
        _window_enable = self._LCDC.window_enable
        self._LCDC.set(value)

        # On CGB, clearing the window enable bit resets the window Y condition.
        if self.cgb and _window_enable and not self._LCDC.window_enable:
            self.renderer.wy_activated_frame = False

        if _lcd_enable and (not self._LCDC.lcd_enable):
            # https://www.reddit.com/r/Gameboy/comments/a1c8h0/what_happens_when_a_gameboy_screen_is_disabled/
            # 1. LY (current rendering line) resets to zero. A few games rely on this behavior, namely Mr. Do! When LY
            # is reset to zero, no LYC check is done, so no STAT interrupt happens either.
            # 2. The LCD clock is reset to zero as far as I can tell.
            # 3. I believe the LCD enters Mode 0.
            self.clock = 0
            self.clock_target = 0
            self._cycles_to_frame = 0
            self._STAT.set_mode(0)
            if self.LY < 144:
                logger.debug("LCD disabled outside of VBLANK!")
            self.LY = 0
        elif (not _lcd_enable) and self._LCDC.lcd_enable:  # When switching from disabled to enabled
            # Registers are actually supposed to be frozen when LCD is disabled. This is mimicked by reseting them again
            self.clock_target = 0  # This will trigger an immediate update in tick()

            # The Cycle Accurate Game Boy Docs:
            # the LCD won't show any image during the first frame it is turned on. The first drawn frame is the second one.
            self.first_frame = True  # used to postpose rendering of first frame

            # Will schedule a full reset on next call to LCD.tick. This will happen immediately, as CPU.tick returns
            # because of CPU.bail and MB.tick proceeds to call LCD.tick.
            self.reset = True
            if self.lyc_changed_while_disabled:
                if not self.cgb:
                    self.stat_mode_override = True
                self.lyc_changed_while_disabled = False
            if self._STAT.value & 0x40:
                return self._STAT.update_LYC(self.LYC, self.LY)

        return 0

    def _is_cgb_hardware(self):
        return self.cgb or self._downgraded_to_dmg

    def _is_startup_mode2_delay(self):
        return self.first_frame and self.stat_transition == STAT_TRANSITION_START_MODE2

    def _should_pretrigger_vblank_stat(self):
        return (
            self._is_cgb_hardware()
            and self._LCDC.lcd_enable
            and self.LY == 143
            and self._STAT._mode == 0
            and self.next_stat_mode == 1
            and self._STAT.value & 0x20
            and not self._STAT._irq_line
        )

    def _mode3_sprite_penalty(self, ly):
        if not self._LCDC.sprite_enable:
            return 0

        spriteheight = 16 if self._LCDC.sprite_height else 8
        spritecount = 0
        group_count = 0
        penalty = 0
        seen_x0 = 0
        seen_x1 = 0
        seen_x2 = 0
        for index in range(0, OBJECT_ATTRIBUTE_MEMORY, 4):
            y = self.OAM[index] - 16
            if y <= ly < y + spriteheight:
                x = self.OAM[index + 1]
                if x < 168:
                    penalty += 6
                    # Keep X-group bookkeeping local; the renderer's sprite list is live state.
                    x_mask = 1
                    if x < 64:
                        x_mask <<= x
                        duplicate = (seen_x0 & x_mask) != 0
                        seen_x0 |= x_mask
                    elif x < 128:
                        x_mask <<= x - 64
                        duplicate = (seen_x1 & x_mask) != 0
                        seen_x1 |= x_mask
                    else:
                        x_mask <<= x - 128
                        duplicate = (seen_x2 & x_mask) != 0
                        seen_x2 |= x_mask

                    if not duplicate:
                        group_count += 1
                        alignment = 5 - ((x + self.SCX - 8) & 7)
                        if alignment > 0:
                            penalty += alignment

                spritecount += 1
                if spritecount == 10:
                    break

        if spritecount and not group_count:
            # A line with only off-screen objects skips one machine cycle of mode-3 startup.
            return -4
        if not spritecount:
            return 0

        # The first seven dots of object fetching overlap the fixed mode-3 startup.
        penalty = max(0, penalty - 7)
        if self._is_cgb_hardware():
            penalty = (penalty + 3) // 4 * 4
        return penalty

    def _mode3_timing_adjustment(self, ly):
        penalty = self._mode3_sprite_penalty(ly)
        if not self.first_frame and not self._is_cgb_hardware():
            penalty += ((self.SCX & 7) + 3) // 4 * 4
        return penalty

    def cycles_to_mode0(self):
        mode = self._STAT._mode & 0b11
        remainder = self.clock_target - self.clock

        if mode == 0:
            return 0
        elif mode == 3:
            return remainder

        mode2 = 80
        cgb_hardware = self._is_cgb_hardware()
        sprite_line = 0 if mode == 1 else self.LY
        mode3_adjustment = self._mode3_timing_adjustment(sprite_line)
        normal_mode3 = 170 + mode3_adjustment if cgb_hardware else 172 + mode3_adjustment

        if mode == 2:
            mode3 = 172 + mode3_adjustment if self.first_frame else normal_mode3
            return remainder + mode3
        elif mode == 1:
            remaining_ly = 153 - self.LY
            return remainder + 456 * remaining_ly + mode2 + normal_mode3
        # else:
        #     logger.critical("Unsupported STAT mode: %d", mode)
        #     return 0

    def tick(self, _cycles):
        cycles = _cycles - self.last_cycles
        if cycles == 0:
            return False
        self.last_cycles = _cycles

        interrupt_flag = 0
        self.clock += cycles >> self.speed_shift
        vblank_stat_pretriggered = False

        if self._should_pretrigger_vblank_stat() and self.clock >= self.clock_target - 4:
            # CGB hardware keeps this timing after switching to DMG compatibility mode.
            self.stat_transition = STAT_TRANSITION_VBLANK_PRETRIGGERED
            interrupt_flag |= INTR_LCDC

        if self.clock >= self.clock_target:
            if self._LCDC.lcd_enable and self.reset:
                self.reset = False
                self.frame_done = True

                self.LY = 0
                self.clock = 0
                # LCD startup begins in mode 0 and skips the initial mode 2.
                self.clock_target = 76
                self.next_stat_mode = 3
                self.stat_transition = STAT_TRANSITION_NONE
                interrupt_flag |= self._STAT.set_mode(0)
                self.renderer.wy_activated_frame = self.WY == self.LY
                interrupt_flag |= self._STAT.update_LYC(self.LYC, self.LY)

            elif self._LCDC.lcd_enable and self.LY == 153:
                if self.first_frame and self.clock_target < FRAME_CYCLES:
                    # The startup line is eight cycles short; keep the frame period unchanged.
                    self.clock_target = FRAME_CYCLES
                else:
                    self.frame_done = True
                    self.LY = 0
                    self.clock %= FRAME_CYCLES
                    self.first_frame = False
                    self.clock_target = self.clock_target % FRAME_CYCLES + 80
                    self.next_stat_mode = 3
                    self.stat_transition = STAT_TRANSITION_NONE
                    interrupt_flag |= self._STAT.set_mode(2)
                    self.renderer.wy_activated_frame = self.WY == self.LY
                    interrupt_flag |= self._STAT.update_LYC(self.LYC, self.LY)

            elif self._LCDC.lcd_enable and self.stat_transition == STAT_TRANSITION_ADVANCE_LY:
                self.LY += 1
                if self.first_frame:
                    # Clear coincidence now, then compare again when mode 2 starts.
                    self._STAT.value &= 0xFB
                    interrupt_flag |= self._STAT._update_irq_line()
                else:
                    interrupt_flag |= self._STAT.update_LYC(self.LYC, self.LY)
                self.clock_target += 4
                self.stat_transition = STAT_TRANSITION_START_MODE2

            elif self._LCDC.lcd_enable and self.stat_transition == STAT_TRANSITION_START_MODE2:
                interrupt_flag |= self._STAT.set_mode(2)
                if self.first_frame:
                    interrupt_flag |= self._STAT.update_LYC(self.LYC, self.LY)
                self.clock_target += 80
                self.next_stat_mode = 3
                self.stat_transition = STAT_TRANSITION_NONE
                self.renderer.wy_activated_frame = self.renderer.wy_activated_frame | (self.WY == self.LY)

            elif self._LCDC.lcd_enable:
                # Change to next mode
                if self.stat_transition == STAT_TRANSITION_VBLANK_PRETRIGGERED:
                    self.stat_transition = STAT_TRANSITION_NONE
                    vblank_stat_pretriggered = True
                interrupt_flag |= self._STAT.set_mode(self.next_stat_mode)

                # Pan Docs:
                # The following are typical when the display is enabled:
                #   Mode 2  2_____2_____2_____2_____2_____2___________________2____
                #   Mode 3  _33____33____33____33____33____33__________________3___
                #   Mode 0  ___000___000___000___000___000___000________________000
                #   Mode 1  ____________________________________11111111111111_____

                # LCD state machine
                if self._STAT._mode == 2:  # Searching OAM
                    self.LY += 1
                    self.clock_target += 80
                    self.next_stat_mode = 3
                    self.stat_transition = STAT_TRANSITION_NONE
                    interrupt_flag |= self._STAT.update_LYC(self.LYC, self.LY)
                    # If this condition is not met in mode 2, at some point in this
                    # frame, the window will not show.
                    # FIXME: Strange Cython work-around. I thought I had fixed this.
                    self.renderer.wy_activated_frame = self.renderer.wy_activated_frame | (self.WY == self.LY)
                elif self._STAT._mode == 3:
                    self.mode3_adjustment = self._mode3_timing_adjustment(self.LY)
                    if self.first_frame:
                        self.clock_target += 172 + self.mode3_adjustment
                    elif self._is_cgb_hardware():
                        self.clock_target += 170 + self.mode3_adjustment
                    else:
                        self.clock_target += 172 + self.mode3_adjustment
                    self.next_stat_mode = 0
                    self.stat_transition = STAT_TRANSITION_NONE
                elif self._STAT._mode == 0:  # HBLANK
                    if self.first_frame:
                        self.clock_target += 200 - self.mode3_adjustment
                        if self.LY < 143:
                            self.next_stat_mode = 2
                            self.stat_transition = STAT_TRANSITION_ADVANCE_LY
                        else:
                            self.next_stat_mode = 1
                            self.stat_transition = STAT_TRANSITION_NONE
                    elif self._is_cgb_hardware():
                        self.clock_target += 206 - self.mode3_adjustment
                        self.next_stat_mode = 2 if self.LY < 143 else 1
                        self.stat_transition = STAT_TRANSITION_NONE
                    elif self.LY < 143:
                        self.clock_target += 200 - self.mode3_adjustment
                        self.next_stat_mode = 2
                        self.stat_transition = STAT_TRANSITION_ADVANCE_LY
                    else:
                        self.clock_target += 204 - self.mode3_adjustment
                        self.next_stat_mode = 1
                        self.stat_transition = STAT_TRANSITION_NONE

                    # Recorded for API
                    bx, by = self.getviewport()
                    wx, wy = self.getwindowpos()
                    self._scanlineparameters[self.LY][0] = bx
                    self._scanlineparameters[self.LY][1] = by
                    self._scanlineparameters[self.LY][2] = wx + 7
                    self._scanlineparameters[self.LY][3] = wy
                    self._scanlineparameters[self.LY][4] = self._LCDC.tiledata_select

                    if self.cgb:
                        self.renderer.cgb_scanline(self.LY)
                    else:
                        self.renderer.scanline(self.LY)
                    self.renderer.scanline_sprites(
                        self.LY, self.renderer._screenbuffer, self.renderer._screenbuffer_attributes, False
                    )
                elif self._STAT._mode == 1:  # VBLANK
                    self.clock_target += 456
                    self.next_stat_mode = 1
                    self.stat_transition = STAT_TRANSITION_NONE

                    self.LY += 1
                    interrupt_flag |= self._STAT.update_LYC(self.LYC, self.LY)

                    if self.LY == 144:
                        if self._STAT.value & 0x20 and not self._STAT._irq_line and not vblank_stat_pretriggered:
                            interrupt_flag |= INTR_LCDC
                        interrupt_flag |= INTR_VBLANK
                        self.renderer.wy_activated_frame = False
                        if self.first_frame:
                            # Pan Docs: https://gbdev.io/pandocs/LCDC.html#lcdc7--lcd-enable
                            # When re-enabling the LCD, the PPU will immediately start drawing again, but the screen
                            # will stay blank during the first frame.
                            self.renderer.blank_screen()
            else:
                # See also `self.set_lcdc`
                self.frame_done = True
                self.clock %= FRAME_CYCLES
                self.clock_target = FRAME_CYCLES

                # Renderer
                self.renderer.blank_screen()

        # NOTE: speed_shift because they are using in externally in mb
        cycles_to_interrupt = self.clock_target - self.clock
        if self._should_pretrigger_vblank_stat():
            cycles_to_interrupt -= 4
        self._cycles_to_interrupt = cycles_to_interrupt << self.speed_shift
        # TODO: STAT Cycles to interrupts
        self._cycles_to_frame = (FRAME_CYCLES - self.clock) << self.speed_shift
        return interrupt_flag

    def save_state(self, f):
        for n in range(VIDEO_RAM):
            f.write(self.VRAM0[n])

        for n in range(OBJECT_ATTRIBUTE_MEMORY):
            f.write(self.OAM[n])

        f.write(self._LCDC.value)  # TODO: Mode to class
        f.write(self.BGP.value)
        f.write(self.OBP0.value)
        f.write(self.OBP1.value)

        self._STAT.save_state(f)
        f.write(self.LY)
        f.write(self.LYC)

        f.write(self.SCY)
        f.write(self.SCX)
        f.write(self.WY)
        f.write(self.WX)
        f.write(self.object_priority_mode)

        for y in range(ROWS):
            f.write(self._scanlineparameters[y][0])
            f.write(self._scanlineparameters[y][1])
            # We store (WX + 7). We added 7 earlier to make it easier to serialize
            f.write(self._scanlineparameters[y][2])
            f.write(self._scanlineparameters[y][3])
            f.write(self._scanlineparameters[y][4])

        f.write(self.cgb)
        f.write(self._downgraded_to_dmg)
        f.write(self.speed_shift)
        f.write(self.frame_done)
        f.write(self.first_frame)
        f.write(self.reset)
        f.write_64bit(self.last_cycles)
        f.write_64bit(self.clock)
        f.write_64bit(self.clock_target)
        f.write(self.next_stat_mode)
        f.write(self.stat_transition)

        if self.cgb:
            for n in range(VIDEO_RAM):
                f.write(self.VRAM1[n])
            f.write(self.vbk.active_bank)
            self.bcps.save_state(f)
            self.bcpd.save_state(f)
            self.ocps.save_state(f)
            self.ocpd.save_state(f)

    def load_state(self, f, state_version):
        for n in range(VIDEO_RAM):
            self.VRAM0[n] = f.read()

        for n in range(OBJECT_ATTRIBUTE_MEMORY):
            self.OAM[n] = f.read()

        self.set_lcdc(f.read())  # TODO: Mode to class
        self.BGP.set(f.read())
        self.OBP0.set(f.read())
        self.OBP1.set(f.read())

        if state_version >= 5:
            self._STAT.load_state(f, state_version)
            self.LY = f.read()
            self.LYC = f.read()

        self.SCY = f.read()
        self.SCX = f.read()
        self.WY = f.read()
        self.WX = f.read()
        if state_version >= 16:
            # See motherboard before version 16
            self.object_priority_mode = f.read()

        if state_version >= 11:
            for y in range(ROWS):
                self._scanlineparameters[y][0] = f.read()
                self._scanlineparameters[y][1] = f.read()
                # Restore (WX - 7) as described above
                self._scanlineparameters[y][2] = f.read()
                self._scanlineparameters[y][3] = f.read()
                if state_version > 3:
                    self._scanlineparameters[y][4] = f.read()

        if state_version >= 8:
            _cgb = f.read()
            if state_version >= 17:
                self._downgraded_to_dmg = f.read()
                if self._downgraded_to_dmg:
                    logger.debug("Load-state from downgraded CGB renderer to DMG renderer")
                    self.renderer.cgb = False

            if self._downgraded_to_dmg and _cgb:
                raise PyBoyException("LCD was supposed to be downgraded!")
            elif not self._downgraded_to_dmg:
                if self.cgb and not _cgb:
                    raise PyBoyException("Loading state which *is not* CGB-mode, but PyBoy *is* in CGB mode!")
                if not self.cgb and _cgb:
                    raise PyBoyException("Loading state which *is* CGB-mode, but PyBoy *is not* in CGB mode!")

            self.cgb = _cgb
            self.speed_shift = f.read()
            if state_version >= 13:
                self.frame_done = f.read()
                self.first_frame = f.read()
                self.reset = f.read()

            if state_version >= 12:
                self.last_cycles = f.read_64bit()
            self.clock = f.read_64bit()
            self.clock_target = f.read_64bit()
            # NOTE: speed_shift because they are using in externally in mb
            self._cycles_to_interrupt = (self.clock_target - self.clock) << self.speed_shift
            self._cycles_to_frame = (FRAME_CYCLES - self.clock) << self.speed_shift
            self.next_stat_mode = f.read()
            self.stat_transition = f.read()
            if self._STAT._mode == 3:
                self.mode3_adjustment = self._mode3_timing_adjustment(self.LY)
            if (
                self._should_pretrigger_vblank_stat()
                and self.clock <= self.clock_target
                and self.clock_target - self.clock >= 4
            ):
                self._cycles_to_interrupt -= 4 << self.speed_shift

            if self.cgb:
                for n in range(VIDEO_RAM):
                    self.VRAM1[n] = f.read()
                self.vbk.active_bank = f.read()
                self.bcps.load_state(f, state_version)
                self.bcpd.load_state(f, state_version)
                self.ocps.load_state(f, state_version)
                self.ocpd.load_state(f, state_version)

    def getwindowpos(self):
        return (self.WX - 7, self.WY)

    def getviewport(self):
        return (self.SCX, self.SCY)


class PaletteRegister:
    def __init__(self, value, palette):
        self.value = 0
        self.lookup = [0] * 4

        self.set_palette_colors(palette)
        self.set(value)

    def set(self, value):
        # Pokemon Blue continuously sets this without changing the value
        if self.value == value:
            return False

        self.value = value
        self._update_lookup()
        return True

    def set_palette_colors(self, palette):
        self.palette_mem_rgb = [(rgb_to_bgr(c)) for c in palette]
        self._update_lookup()

    def _update_lookup(self):
        for x in range(4):
            self.lookup[x] = self.palette_mem_rgb[(self.value >> x * 2) & 0b11]

    def get(self):
        return self.value

    def getcolor(self, i):
        return self.lookup[i]


class STATRegister:
    def __init__(self):
        self.value = 0b1000_0000
        self._mode = 0
        self._irq_line = False

    def set(self, value):
        value &= 0b0111_1000  # Bit 7 is always set, and bit 0-2 are read-only
        self.value &= 0b1000_0111  # Preserve read-only bits and clear the rest
        self.value |= value  # Combine the two
        return self._update_irq_line()

    def update_LYC(self, LYC, LY):
        # WARNING: Only call when LCD is enabled!
        if LYC == LY:
            self.value |= 0b100  # Sets the LYC flag
        else:
            # Clear LYC flag
            self.value &= 0b1111_1011
        return self._update_irq_line()

    def set_mode(self, mode):
        if self._mode == mode:
            # Mode already set
            return 0

        self._mode = mode
        self.value &= 0b11111100  # Clearing 2 LSB
        self.value |= mode  # Apply mode to LSB
        return self._update_irq_line()

    def _update_irq_line(self):
        mode_irq = self._mode != 3 and self.value & (1 << (self._mode + 3))
        lyc_irq = self.value & 0x44 == 0x44
        irq_line = mode_irq or lyc_irq
        interrupt = INTR_LCDC if irq_line and not self._irq_line else 0
        self._irq_line = irq_line
        return interrupt

    def save_state(self, f):
        f.write(self.value)

    def load_state(self, f, state_version):
        value = f.read()
        self.value = value
        self._mode = value & 0b11
        self._irq_line = False
        self._update_irq_line()


class LCDCRegister:
    def __init__(self, value):
        self.set(value)

    def set(self, value):
        self.value = value

        # No need to convert to bool. Any non-zero value is true.
        # fmt: off
        self.lcd_enable           = value & (1 << 7)
        self.windowmap_select     = value & (1 << 6)
        self.window_enable        = value & (1 << 5)
        self.tiledata_select      = value & (1 << 4)
        self.backgroundmap_select = value & (1 << 3)
        self.sprite_height        = value & (1 << 2)
        self.sprite_enable        = value & (1 << 1)
        self.background_enable    = value & (1 << 0)
        self.cgb_master_priority  = self.background_enable # Different meaning on CGB
        # fmt: on

        # All VRAM addresses are offset by 0x8000
        # Following addresses are 0x9800 and 0x9C00
        self.backgroundmap_offset = 0x1800 if self.backgroundmap_select == 0 else 0x1C00
        self.windowmap_offset = 0x1800 if self.windowmap_select == 0 else 0x1C00


COL0_FLAG = 0b01
BG_PRIORITY_FLAG = 0b10


class Renderer:
    def __init__(self, lcd, cgb):
        self.lcd = lcd
        self.cgb = cgb
        self.color_format = "RGBA"

        self.buffer_dims = (ROWS, COLS)

        # Init buffers as white
        self._screenbuffer_raw = array("B", [0x00] * (ROWS * COLS * 4))
        self._screenbuffer_attributes_raw = array("B", [0x00] * (ROWS * COLS))
        self._tilecache_raw = array("B", [0x00] * (TILES * 8 * 8 * 2))
        self._spritecache_raw = array("B", [0x00] * (TILES * 8 * 8 * 2))
        self.sprites_to_render = array("i", [0] * 10)

        # Allocate both cache 0 and 1. Even on DMG, where tilecache[0] is only used.
        self._tilecache_state = array("B", [0] * TILES * 2)
        self._spritecache_state = array("B", [0] * TILES * 2)
        self.clear_cache()

        self._screenbuffer = memoryview(self._screenbuffer_raw).cast("I", shape=(ROWS, COLS))
        self._screenbuffer_attributes = memoryview(self._screenbuffer_attributes_raw).cast("B", shape=(ROWS, COLS))
        self._tilecache = memoryview(self._tilecache_raw).cast("B", shape=(2, TILES * 8, 8))
        self._tilecache_64 = memoryview(self._tilecache_raw).cast(
            "Q",
            shape=(
                2,
                TILES * 8,
            ),
        )

        # The look-up table only stored 4 bits from each byte, packed into a single byte
        self.colorcode_table = array("I", [0x00000000] * (0x100))  # Should be "L"!?
        """Convert 2 bytes into color code at a given offset.

        The colors are 2 bit and are found like this:

        Color of the first pixel is 0b10
        | Color of the second pixel is 0b01
        v v
        1 0 0 1 0 0 0 1 <- byte1
        0 1 1 1 1 1 0 0 <- byte2
        """
        for byte in range(0x100):
            byte1 = byte & 0xF
            byte2 = (byte >> 4) & 0xF
            v = 0
            for offset in range(4):
                t = (((byte2 >> (offset)) & 0b1) << 1) | ((byte1 >> (offset)) & 0b1)
                assert t < 4
                v |= t << (8 * (3 - offset))  # Store them in little-endian
            self.colorcode_table[byte] = v

        # OBP0 and OBP1 palette
        self._spritecache = memoryview(self._spritecache_raw).cast("B", shape=(2, TILES * 8, 8))
        self._spritecache_64 = memoryview(self._spritecache_raw).cast("Q", shape=(2, TILES * 8))

        self._screenbuffer_ptr = c_void_p(self._screenbuffer_raw.buffer_info()[0])

        self.ly_window = 0

        # WY has a strange behavior described at:
        # https://gbdev.io/pandocs/Scrolling.html#window
        self.wy_activated_frame = False

    def scanline(self, y):
        if self.lcd.disable_renderer:
            return

        bx, by = self.lcd.getviewport()
        wx, wy = self.lcd.getwindowpos()

        x = 0
        if self.lcd._LCDC.window_enable and self.wy_activated_frame and wx < COLS:
            # Window has it's own internal line counter. It's only incremented whenever the window is drawing something on the screen.
            self.ly_window += 1

            # Before window
            if wx > x:
                x += self.scanline_background(y, x, bx, by, wx, self.lcd)

            # Window hit
            self.scanline_window(y, x, wx, wy, COLS - x, self.lcd)
        elif self.lcd._LCDC.background_enable:
            # No window
            self.scanline_background(y, x, bx, by, COLS, self.lcd)
        else:
            self.scanline_blank(y, x, COLS, self.lcd)

        if y == 143:
            # Reset at the end of a frame. We set it to -1, so it will be 0 after the first increment
            self.ly_window = -1

    def _get_tile(self, y, x, offset, lcd):
        tile_addr = offset + y // 8 * 32 % 0x400 + x // 8 % 32
        tile = lcd.VRAM0[tile_addr]

        # If using signed tile indices, modify index
        if not lcd._LCDC.tiledata_select:
            # (x ^ 0x80 - 128) to convert to signed, then
            # add 256 for offset (reduces to + 128)
            tile = (tile ^ 0x80) + 128

        yy = 8 * tile + y % 8
        return tile, yy, tile_addr

    def _pixel(self, cache_index, pixel, x, y, xx, yy, bg_priority_apply):
        col0 = (self._tilecache[cache_index, yy, xx] == 0) & 1
        self._screenbuffer[y, x] = pixel
        # COL0_FLAG is 1
        self._screenbuffer_attributes[y, x] = bg_priority_apply | col0

    def scanline_window(self, y, _x, wx, wy, cols, lcd):
        for x in range(_x, _x + cols):
            xx = (x - wx) % 8
            if xx == 0 or x == _x:
                wt, yy, _ = self._get_tile(self.ly_window, x - wx, lcd._LCDC.windowmap_offset, lcd)
                self.update_tilecache(0, lcd, wt, 0)

            pixel = lcd.BGP.getcolor(self._tilecache[0, yy, xx])
            self._pixel(0, pixel, x, y, xx, yy, 0)
        return cols

    def scanline_background(self, y, _x, bx, by, cols, lcd):
        for x in range(_x, _x + cols):
            # bx mask used for the half tile at the left side when scrolling
            b_xx = (x + (bx & 0b111)) % 8
            if b_xx == 0 or x == 0:
                bt, b_yy, _ = self._get_tile(y + by, x + bx, lcd._LCDC.backgroundmap_offset, lcd)
                self.update_tilecache(0, lcd, bt, 0)

            xx = b_xx
            yy = b_yy

            pixel = lcd.BGP.getcolor(self._tilecache[0, yy, xx])
            self._pixel(0, pixel, x, y, xx, yy, 0)
        return cols

    def scanline_blank(self, y, _x, cols, lcd):
        # If background is disabled, it becomes white
        for x in range(_x, _x + cols):
            self._screenbuffer[y, x] = lcd.BGP.getcolor(0)
            self._screenbuffer_attributes[y, x] = 0
        return cols

    def sort_sprites(self, sprite_count):
        # Use insertion sort, as it has O(n) on already sorted arrays. This
        # functions is likely called multiple times with unchanged data.
        # Sort descending because of the sprite priority.

        for i in range(1, sprite_count):
            key = self.sprites_to_render[i]  # The current element to be inserted into the sorted portion
            j = i - 1  # Index of the last element in the sorted portion of the array

            # Move elements of the sorted portion greater than the key to the right
            while j >= 0 and key > self.sprites_to_render[j]:
                self.sprites_to_render[j + 1] = self.sprites_to_render[j]
                j -= 1

            # Insert the key into its correct position in the sorted portion
            self.sprites_to_render[j + 1] = key

    def scanline_sprites(self, ly, buffer, buffer_attributes, ignore_priority):
        if not self.lcd._LCDC.sprite_enable or self.lcd.disable_renderer:
            return

        # Find the first 10 sprites in OAM that appears on this scanline.
        # The lowest X-coordinate has priority, when overlapping
        spriteheight = 16 if self.lcd._LCDC.sprite_height else 8
        sprite_count = 0
        for n in range(0x00, OBJECT_ATTRIBUTE_MEMORY, 4):
            y = self.lcd.OAM[n] - 16  # Documentation states the y coordinate needs to be subtracted by 16
            x = self.lcd.OAM[n + 1] - 8  # Documentation states the x coordinate needs to be subtracted by 8

            if y <= ly < y + spriteheight:
                # x is used for sorting for priority
                if self.cgb:
                    self.sprites_to_render[sprite_count] = n
                else:
                    self.sprites_to_render[sprite_count] = x << 16 | n
                sprite_count += 1

            if sprite_count == 10:
                break

        # Pan docs:
        # When these 10 sprites overlap, the highest priority one will appear above all others, etc. (Thus, no
        # Z-fighting.) In CGB mode, the first sprite in OAM ($FE00-$FE03) has the highest priority, and so on. In
        # Non-CGB mode, the smaller the X coordinate, the higher the priority. The tie breaker (same X coordinates) is
        # the same priority as in CGB mode.
        self.sort_sprites(sprite_count)

        for _n in self.sprites_to_render[:sprite_count]:
            if self.cgb:
                n = _n
            else:
                n = _n & 0xFF
            # n = self.sprites_to_render_n[_n]
            y = self.lcd.OAM[n] - 16  # Documentation states the y coordinate needs to be subtracted by 16
            x = self.lcd.OAM[n + 1] - 8  # Documentation states the x coordinate needs to be subtracted by 8
            tileindex = self.lcd.OAM[n + 2]
            if spriteheight == 16:
                tileindex &= 0b11111110
            attributes = self.lcd.OAM[n + 3]
            xflip = attributes & 0b00100000
            yflip = attributes & 0b01000000
            spritepriority = (attributes & 0b10000000) and not ignore_priority
            sprite_cache_no = 0
            if self.cgb:
                palette = attributes & 0b111
                if attributes & 0b1000:
                    sprite_cache_no = 1
            else:
                # Fake palette index
                palette = 0
                if attributes & 0b10000:
                    sprite_cache_no = 1

            self.update_spritecache(sprite_cache_no, self.lcd, tileindex, sprite_cache_no if self.cgb else 0)
            if self.lcd._LCDC.sprite_height:
                self.update_spritecache(sprite_cache_no, self.lcd, tileindex + 1, sprite_cache_no if self.cgb else 0)

            dy = ly - y
            yy = spriteheight - dy - 1 if yflip else dy

            for dx in range(8):
                xx = 7 - dx if xflip else dx
                color_code = self._spritecache[sprite_cache_no, 8 * tileindex + yy, xx]
                if 0 <= x < COLS and not color_code == 0:  # If pixel is not transparent
                    if self.cgb:
                        pixel = self.lcd.ocpd.getcolor(palette, color_code)
                        bgmappriority = buffer_attributes[ly, x] & BG_PRIORITY_FLAG

                        if (
                            self.lcd._LCDC.cgb_master_priority
                        ):  # If 0, sprites are always on top, if 1 follow priorities
                            if bgmappriority:  # If 0, use spritepriority, if 1 take priority
                                if buffer_attributes[ly, x] & COL0_FLAG:
                                    buffer[ly, x] = pixel
                            elif (
                                spritepriority
                            ):  # If 1, sprite is behind bg/window. Color 0 of window/bg is transparent
                                if buffer_attributes[ly, x] & COL0_FLAG:
                                    buffer[ly, x] = pixel
                            else:
                                buffer[ly, x] = pixel
                        else:
                            buffer[ly, x] = pixel
                    else:
                        # TODO: Unify with CGB
                        if attributes & 0b10000:
                            pixel = self.lcd.OBP1.getcolor(color_code)
                        else:
                            pixel = self.lcd.OBP0.getcolor(color_code)

                        if spritepriority:  # If 1, sprite is behind bg/window. Color 0 of window/bg is transparent
                            if buffer_attributes[ly, x] & COL0_FLAG:  # if BG pixel is transparent
                                buffer[ly, x] = pixel
                        else:
                            buffer[ly, x] = pixel
                x += 1
            x -= 8

    def clear_cache(self):
        self.clear_tilecache(0)
        if self.cgb:
            self.clear_tilecache(1)
        self.clear_spritecache(0)
        self.clear_spritecache(1)

    def invalidate_tile(self, tile, vbank):
        # TODO: Is this right?
        if vbank and self.cgb:
            self._tilecache_state[tile] = 0
            self._tilecache_state[tile + TILES] = 0
            self._spritecache_state[tile] = 0
            self._spritecache_state[tile + TILES] = 0
        else:
            self._tilecache_state[tile] = 0
            if self.cgb:
                self._tilecache_state[tile + TILES] = 0
            self._spritecache_state[tile] = 0
            self._spritecache_state[tile + TILES] = 0

    def clear_tilecache(self, cache_no):
        for i in range(TILES):
            self._tilecache_state[i + (TILES if cache_no else 0)] = 0

    def clear_spritecache(self, cache_no):
        for i in range(TILES):
            self._spritecache_state[i + (TILES if cache_no else 0)] = 0

    def update_tilecache(self, cache_no, lcd, t, bank):
        if self._tilecache_state[t + (TILES if cache_no else 0)]:
            return
        # for t in self.tiles_changed0:
        for k in range(0, 16, 2):  # 2 bytes for each line
            if self.cgb and bank:
                byte1 = lcd.VRAM1[t * 16 + k]
                byte2 = lcd.VRAM1[t * 16 + k + 1]
            else:
                byte1 = lcd.VRAM0[t * 16 + k]
                byte2 = lcd.VRAM0[t * 16 + k + 1]
            y = (t * 16 + k) // 2

            self._tilecache_64[cache_no, y] = self.colorcode(byte1, byte2)

        self._tilecache_state[t + (TILES if cache_no else 0)] = 1

    def update_spritecache(self, cache_no, lcd, t, bank):
        if self._spritecache_state[t + (TILES if cache_no else 0)]:
            return
        # for t in self.tiles_changed0:
        for k in range(0, 16, 2):  # 2 bytes for each line
            if self.cgb and bank:
                byte1 = lcd.VRAM1[t * 16 + k]
                byte2 = lcd.VRAM1[t * 16 + k + 1]
            else:
                byte1 = lcd.VRAM0[t * 16 + k]
                byte2 = lcd.VRAM0[t * 16 + k + 1]
            y = (t * 16 + k) // 2

            self._spritecache_64[cache_no, y] = self.colorcode(byte1, byte2)

        self._spritecache_state[t + (TILES if cache_no else 0)] = 1

    def colorcode(self, byte1, byte2):
        colorcode_low = self.colorcode_table[(byte1 & 0xF) | ((byte2 & 0xF) << 4)]
        colorcode_high = self.colorcode_table[((byte1 >> 4) & 0xF) | (byte2 & 0xF0)]
        return (colorcode_low << 32) | colorcode_high

    def blank_screen(self):
        # If the screen is off, fill it with a color.
        for y in range(ROWS):
            for x in range(COLS):
                self._screenbuffer[y, x] = self.lcd.BGP.getcolor(0)
                self._screenbuffer_attributes[y, x] = 0

    def save_state(self, f):
        for y in range(ROWS):
            for x in range(COLS):
                f.write_32bit(self._screenbuffer[y, x])
                f.write(self._screenbuffer_attributes[y, x])
        f.write(self.wy_activated_frame)

    def load_state(self, f, state_version):
        if 2 <= state_version < 11:
            # Dummy reads to align scanline parameters. See LCD instead
            for y in range(ROWS):
                f.read()
                f.read()
                f.read()
                f.read()
                if state_version > 3:
                    f.read()

        if state_version >= 6:
            for y in range(ROWS):
                for x in range(COLS):
                    self._screenbuffer[y, x] = f.read_32bit()
                    if state_version >= 10:
                        self._screenbuffer_attributes[y, x] = f.read()

        if state_version >= 18:
            self.wy_activated_frame = f.read()

        self.clear_cache()

    ####################################
    #
    #  ██████   ██████   ██████
    # ██       ██        ██   ██
    # ██       ██   ███  ██████
    # ██       ██    ██  ██   ██
    #  ██████   ██████   ██████
    #

    def _cgb_get_background_map_attributes(self, lcd, i):
        tile_num = lcd.VRAM1[i]
        palette = tile_num & 0b111
        vbank = (tile_num >> 3) & 1
        horiflip = (tile_num >> 5) & 1
        vertflip = (tile_num >> 6) & 1
        bg_priority = (tile_num >> 7) & 1

        return palette, vbank, horiflip, vertflip, bg_priority

    def _cgb_get_tile(self, y, x, offset, lcd):
        tile, yy, tile_addr = self._get_tile(y, x, offset, lcd)

        palette, vbank, horiflip, vertflip, bg_priority = self._cgb_get_background_map_attributes(lcd, tile_addr)

        bg_priority_apply = 0
        if bg_priority:
            # We hide extra rendering information in the lower 8 bits (A) of the 32-bit RGBA format
            bg_priority_apply = BG_PRIORITY_FLAG

        if vertflip:
            yy = 8 * tile + (7 - (y) % 8)

        return tile, yy, palette, horiflip, bg_priority_apply, vbank

    def cgb_scanline_window(self, y, _x, wx, wy, cols, lcd):
        bg_priority_apply = 0
        for x in range(_x, _x + cols):
            xx = (x - wx) % 8
            if xx == 0 or x == _x:
                wt, yy, w_palette, w_horiflip, bg_priority_apply, vbank = self._cgb_get_tile(
                    self.ly_window, x - wx, lcd._LCDC.windowmap_offset, lcd
                )
                self.update_tilecache(vbank, lcd, wt, vbank)

            if w_horiflip:
                xx = 7 - xx

            pixel = lcd.bcpd.getcolor(w_palette, self._tilecache[vbank, yy, xx])
            self._pixel(vbank, pixel, x, y, xx, yy, bg_priority_apply)
        return cols

    def cgb_scanline_background(self, y, _x, bx, by, cols, lcd):
        for x in range(_x, _x + cols):
            # bx mask used for the half tile at the left side when scrolling
            xx = (x + (bx & 0b111)) % 8
            if xx == 0 or x == 0:
                bt, yy, b_palette, b_horiflip, bg_priority_apply, vbank = self._cgb_get_tile(
                    y + by, x + bx, lcd._LCDC.backgroundmap_offset, lcd
                )
                self.update_tilecache(vbank, lcd, bt, vbank)

            if b_horiflip:
                xx = 7 - xx

            pixel = lcd.bcpd.getcolor(b_palette, self._tilecache[vbank, yy, xx])
            self._pixel(vbank, pixel, x, y, xx, yy, bg_priority_apply)
        return cols

    def cgb_scanline(self, y):
        if self.lcd.disable_renderer:
            return

        bx, by = self.lcd.getviewport()
        wx, wy = self.lcd.getwindowpos()

        x = 0
        if self.lcd._LCDC.window_enable and self.wy_activated_frame and wx < COLS:
            # Window has it's own internal line counter. It's only incremented whenever the window is drawing something on the screen.
            self.ly_window += 1

            # Before window
            if wx > x:
                x += self.cgb_scanline_background(y, x, bx, by, wx, self.lcd)

            # Window hit
            self.cgb_scanline_window(y, x, wx, wy, COLS - x, self.lcd)
        else:  # background_enable doesn't exist for CGB. It works as master priority instead
            # No window
            self.cgb_scanline_background(y, x, bx, by, COLS, self.lcd)

        if y == 143:
            # Reset at the end of a frame. We set it to -1, so it will be 0 after the first increment
            self.ly_window = -1


class VBKregister:
    def __init__(self, value=0):
        self.active_bank = value

    def set(self, value):
        # when writing to VBK, bit 0 indicates which bank to switch to
        bank = value & 1
        self.active_bank = bank

    def get(self):
        # reading from this register returns current VRAM bank in bit 0, other bits = 1
        return self.active_bank | 0xFE


class PaletteIndexRegister:
    def __init__(self, val=0):
        self.value = val
        self.auto_inc = 0
        self.index = 0
        self.hl = 0

    def set(self, val):
        if self.value == val:
            return
        self.value = val
        self.hl = val & 0b1
        self.index = (val >> 1) & 0b11111
        self.auto_inc = (val >> 7) & 0b1

    def get(self):
        return self.value

    def getindex(self):
        return self.index

    def shouldincrement(self):
        if self.auto_inc:
            # ensure autoinc also set for new val
            new_val = 0x80 | (self.value + 1)
            self.set(new_val)

    def save_state(self, f):
        f.write(self.value)
        f.write(self.auto_inc)
        f.write(self.index)
        f.write(self.hl)

    def load_state(self, f, state_version):
        self.value = f.read()
        self.auto_inc = f.read()
        self.index = f.read()
        self.hl = f.read()


CGB_NUM_PALETTES = 8


class PaletteColorRegister:
    def __init__(self, i_reg):
        # 8 palettes of 4 colors each 2 bytes
        self.palette_mem = array("I", [0xFFFF] * CGB_NUM_PALETTES * 4)
        self.palette_mem_rgb = array("L", [0] * CGB_NUM_PALETTES * 4)
        self.index_reg = i_reg

        # Init with some colors -- TODO: What are real defaults?
        for n in range(0, len(self.palette_mem), 4):
            c = [0x1CE7, 0x1E19, 0x7E31, 0x217B]
            for m in range(4):
                self.palette_mem[n + m] = c[m]
                self.palette_mem_rgb[n + m] = self.cgb_to_rgb(c[m], m)

    def cgb_to_rgb(self, cgb_color, index):
        alpha = 0xFF
        red = (cgb_color & 0x1F) << 3
        green = ((cgb_color >> 5) & 0x1F) << 3
        blue = ((cgb_color >> 10) & 0x1F) << 3
        # NOTE: Actually BGR, not RGB
        rgb_color = (alpha << 24) | (blue << 16) | (green << 8) | red
        return rgb_color

    def set(self, val):
        i_val = self.palette_mem[self.index_reg.getindex()]
        if self.index_reg.hl:
            self.palette_mem[self.index_reg.getindex()] = (i_val & 0x00FF) | (val << 8)
        else:
            self.palette_mem[self.index_reg.getindex()] = (i_val & 0xFF00) | val

        cgb_color = self.palette_mem[self.index_reg.getindex()] & 0x7FFF
        self.palette_mem_rgb[self.index_reg.getindex()] = self.cgb_to_rgb(cgb_color, self.index_reg.getindex())

        # check for autoincrement after write
        self.index_reg.shouldincrement()

    def get(self):
        if self.index_reg.hl:
            return (self.palette_mem[self.index_reg.getindex()] & 0xFF00) >> 8
        else:
            return self.palette_mem[self.index_reg.getindex()] & 0x00FF

    def getcolor(self, paletteindex, colorindex):
        # Each palette = 8 bytes or 4 colors of 2 bytes
        return self.palette_mem_rgb[paletteindex * 4 + colorindex]

    def save_state(self, f):
        for n in range(CGB_NUM_PALETTES * 4):
            f.write_16bit(self.palette_mem[n])

    def load_state(self, f, state_version):
        for n in range(CGB_NUM_PALETTES * 4):
            self.palette_mem[n] = f.read_16bit()
            self.palette_mem_rgb[n] = self.cgb_to_rgb(self.palette_mem[n], n % 4)

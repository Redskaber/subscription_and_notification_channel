# W-LINEAR-TYPES 线性/仿射类型窗——能力模型资源安全基础（登记 → 实施）

> **Status**: **v1.1 CLOSED @ r218**（刀 3 收口轮——corpus-qual 28 案四判决臂 + audit Section BM 10 案〔522→532 普查共变〕+ Q6 递延裁决落档〔QL-27——接口面冻结义务清偿〕+ 出口判据六条全过〔§7〕→ 窗口 CLOSED；
> 刀 1 DELIVERED @ r216 + 刀 2 DELIVERED @ r217 + 刀 3 DELIVERED @ r218——三刀序完整交付，金链 v0.153.0 + 台账 v1.29）；
> 开窗位历史：**v1.0 OPEN @ r215**（开窗行权轮——触发器① 行权：α 收口 @ r212 + 用户常设排期信号〔首要完整完全自举 →
> 基础核心能力先行〕；preceding 档 = w-linear-types-presurvey.md v1.0 @ r214——预备位完成使命，触发器定义单源
> w-decision-gap-windows.md §4 登记位冻结，实施细节单源 = 本档）
> **流程权威**: docs/sop.md v15.7（§3.3 演进提案形制——r181 先例：提案 = 窗口档本体；§2.2 原则 38/44-58 登记态纪律；
> §5.3 八项内循环；§7.3 门审构成；§9.5 覆盖率口径；§3.2.1 长套件分块纪律）
> **形制先例**: w-row-poly-window.md v1.0（r181 八节形制——效应族链首段开窗档；本窗 = Phase β 链首窗同构位）
> **知识单源**: tool-results/r213-search/（7 检 48 锚——r214 预备轮已消化入 presurvey §3；本档直接消费）
> **设计单源**: stage0.md §6.10.2/6.10.3（线性 = ✅ 实现 Stage 1 决策 + linear_cap 消耗旧的/产生新登记记）+
> §9.15（Fatal 边界裁定族）+ language-capability-matrix.md §4 行 5（登记位 @ r172）

## 1. 一行定位

线性/仿射类型 = **类型层限定（qualifier）而非值构造**：在既有 HM + 行多态 + 效应行基座上，为能力模型的资源安全面
提供编译期 use-count 检查——「消耗旧的、产生新的」（stage0 §6.10.3 原文）的静态纪律。零值层原语、零新内建、
零通道、零 VM 触点、零关键字表变更（预期）——L3 授权层（原则 34）资源面基础的链式前置。

## 2. 成熟度口径（现状 + 前沿对照）

- **现状基座**（全部 ✓ 在位）：HM 单态推断（infer.ktf 5,532 行生产位）+ 行多态 P1（W-ROW-POLY CLOSED @ r185）
  + 效应行推断消费（W-EFFECT-MECHANISM 刀 2 @ r188——箭头携行四元槽）+ 类型注解双向检查（E0013 @ r165）+
  struct/enum 名义层 + 穷尽性（GZ-4）。
- **前沿对照**（r213-search 48 锚单源）：GHC LinearTypes 自 9.0 合并**仍部分采用**（ghc-proposals 0111 /
  arxiv 1710.09756——`l →` 多重性约束形）；**Rust Polonius 2026-08 nightly alpha** = 检查层独立分析 + 值表示
  零变更在生产规模成立的最新实证；ATS viewtype（proof/linear 分层）；Koka per-VC（handler/value-center）；
  Qualified types（Jones 1994）= HM+qualified 谓词限定的标准融合路径；use-count 算法族（Wadler 0/1/ω 基数）。
- **判定**：触发器②（≥1 主流函数语言生产采用 HM+qualified/linear 融合）**未达维持**——GHC 部分采用不构成门槛
  证据；观察义务续行（成熟度轴与行权解耦——行权路径 = 触发器①）。

## 3. 时机触发器（四件——① 行权 @ r215）

| 触发器 | 登记定义（w-decision-gap-windows §4） | 状态 @ r215 |
|---|---|---|
| ①需求 | L3 能力模型排期 / 用户显式排期 | **达成行权**（α 收口 @ r212〔W-SELFHOST-ORCH CLOSED〕+ 用户常设指令排期信号 = presurvey §1 落档 @ r214；completion-plan §3 Phase β 入口声明 = 链首窗） |
| ②成熟度 | HM+qualified/linear 融合 ≥1 主流函数语言生产采用 | 未达维持（§2 判定——观察义务续行） |
| ③替代路径 | FFI 句柄生命周期安全显性化且 Fatal 边界不能承载 | 未触发（W-HEAP-EXTERN 联动位维持——TD-026 承载注记） |
| ④成本 | 资源误用运行期错误实测频率 > use-count 检查实现成本 | 未观测（calibration-data 轴维持；本环境运行面如实登记） |

**行权路径 = 触发器①**（roadmap / completion-plan §3 / presurvey 三处一致——零信号不开窗纪律下这是唯一达成面）。

## 4. 开窗前置门（四件——全过 @ r215）

| 前置门 | 状态 | 证据锚 |
|---|---|---|
| ①§3.3 演进提案 | **本档本体**（r181 形制：触发器落档 + 表示裁定 + 刀序 + 出口判据） | §3/§5/§6/§7 |
| ②知识搜索先行 | **就绪直接消费**（r213-search 7 检 48 锚 @ r213——GHC/Polonius/Koka/ATS/qualified/use-count 六族覆盖；开刀如有窄面缺口增量补检） | presurvey §3 摘要 + tool-results/r213-search/213-summary.md |
| ③8 原语不变性核对 | **第 165 轮设计面 ✓**（qualifier = 类型层限定非新值构造——零值层原语/零新内建/零通道/零 VM/零操作码；语法面零关键字表变更预期；刀 1 实施轮复验） | §5 Q1/Q4 裁决 + r212 第 164 轮承继 |
| ④孪生可表达性评估 | **设计面 ✓ + 运行面刀 1 实测义务**（infer.ktf 镜像 = tag-headed pair 复合 + ti_unify 新臂 + walk 机族 qual 臂——r182 行刀 1 同族机族先例；检查段镜像 = 既有帧机族上的计数走查；18 内建可表达面内） | §5 Q2 裁决 + r182 M 映射先例 |

## 5. 表示与算法裁定（ARCH-A @ r215——判据先于先例）

**GZ-Q1..Q6 裁决表**（presurvey §4 六问逐裁决——刀级实施单源）：

| # | 问题 | 裁决 | 判据（锚） |
|---|---|---|---|
| Q1 | 限定表示（.ktf 生产位载体） | **`("qual" ...)` pair 嵌套复合**（行类型 `("row" ...)` 同构形——tag-headed pair，共用 Type spine 与 var 空间）；注解面经既有注解机消费；**刀 1 金档 = 数据构造形**（ModuleItem 直构喂 steady 链——r182 行刀 1 先例：皮肤无法产生 "row" 头同因），刀 2 最小注解表面扩展 | GHC 多重性 = **约束形非值形**（presurvey §3 首锚）；linear_cap = 类型层限定（§6.10.3 登记原文）；r174 oracle 冻结裁定——新特性验证 = 金档 + fixpoint + audit 三面，**零 oracle 共同实现** |
| Q2 | 检查器形制 | **use-count 基数（Wadler 0/1/ω）**为检查段消费面：计数走查骑既有帧机族（零新机族骨架），限定消费裁决（≥2 消耗 = E 码拒绝 / 0 消耗 = 警告级登记面诚实裁定）+ Dyn 逃逸降级保守族（r182 GZ-1 同族）；ATS 义务面 / Koka VC 记否决态（证明级机制超当前阶段；value-center 形 = 效应族资源窗〔L3 链〕后续位） | 登记设计「不可复制——消耗旧的、产生新的」= 基数语义；**Polonius 生产规模实证 = 检查层独立分析 + 值表示零变更**；use-count 算法族（r213-search q6） |
| Q3 | 效应行正交对账 | **正交构造性维持**：限定轴 = Type spine 位（值来源面），效应行轴 = 箭头携行四元槽（P2 形状冻结 @ r185 `("row" ((eff opT)...) tail)`）——不同槽位不同轴；检查段相位序裁定 = **① infer（HM+行+效应行——零变更）→ ② qualify（use-count 走查 + 限定满足性）→ 合并诊断报告**；刀 2 义务 = 正交回归族（限定值 × 效应函数组合案例） | 构造性正交（槽位分立）+ §6.10.2「类型安全优先」整合原则；效应行 P2 冻结先例不触碰 |
| Q4 | 表面皮肤 | **注解面最小扩展先行，零关键字表变更预期**：刀 1 = 纯类型层（数据构造金档——零皮肤变更）；刀 2 = 解析守卫 + 注解语法最小形（r185 `[l: T \| r]` 行注解先例同构）+ 负向金档钉扎；表面糖（消费侧 with 语法族）后置 γ 相位 K-D 脱糖纪律 | 矩阵 §4「注解面扩展」候选位；K-D 脱糖纪律（§2.2 原则族）；刀 2 语法面 = 20-surface-conventions R1-R6 管辖 |
| Q5 | Fatal 边界对账 | **双线防御维持**：编译期预防（本窗 use-count = 静态可表达误用面：≥2 消耗/0 消耗线性值/别名逃逸）为第一线；运行期 Fatal 兜底（既有——资源误用运行期错误）维持不拆除（§9.15 统一而分治裁定 + stage0 Layer 4 check_capability/transfer 设计位）；触发器④观察轴（运行期实测频率）入 calibration-data 续行——本窗不开除 Fatal 面义务 | §9.15 六裁定；defense-in-depth（stage0 §6.10.3 能力层登记）；触发器④未观测如实登记 |
| Q6 | std 资源词汇 | **递延刀 3 内裁决**（presurvey 原裁定维持）：接口预留 = with_cap 族候选（能力传递「消耗旧的、产生新的」），载体 = selfhost/std/ 库位 + W-EFFECT-INSTANCES 六实例模式先例（with_state @ r192/with_read @ r193 同构）；L3 授权层链（W-LINEAR-TYPES → L3 → 效应族资源面〔State/Async〕）接口面冻结义务在刀 3 开刀时落档 | presurvey §4 Q6 + §6.10.3 linear_cap 登记原文 + 六实例窗口档形制先例 |

**8 原语不变性第 165 轮（设计面构造性核对）**：qualifier = Type 层新复合形态（`("qual" ...)` pair 嵌套——与
`("row" ...)` 同族），共用 var 空间与既有机族——零值层原语 / 零新内建 / 零通道 / 零 VM 触点 / 零操作码 /
零语法增改（刀 1 皮肤零变更；刀 2 注解面 = 既有语法位扩展非新关键字）。

## 6. 刀级 MUV 排期（最小先行 + 逐刀金档/fixpoint 门——三刀序）

1. **刀 1（infer.ktf 类型层限定内核）**：qualified-type 融合骨架（Jones 1994 HM+qualified——谓词限定骑 HM spine）
   + `("qual" ...)` 表示 + ti_unify qual 臂 + 四 walk 机族 qual 臂 + 泛化/实例化限定穿透 + Display qual 臂
   ——**零值层变更**。验收门 = 金档新语料正负 ≥1:3（负向 ≥3 类）+ parity 回归全绿 + fixpoint B≡C 位级 +
   **§3.2 六命令真实电池**（工具链在位——本环境实测义务恢复，无指纹豁免）。
   **✅ DELIVERED @ r216**（infer.ktf 5,538→5,721；映射表 §9 QL-1..QL-11 全条目 ✓；金档 32 案 8:24=1:3 数据构造形
   + 既有 parity sweep 回归全绿〔sweep 69 案 + fixpoint 双族 17/17 B≡C 位级 + segment 四开关 + audit 522/522
   live EXIT 0〕+ §3.2 六命令真电池〔fmt 零 diff / build 0e0w / check 0e0w / clippy -D 零 / T0 fresh 32/32 /
   T1 63/64 + T2 73/76 台账银行化——三怪物窗算术停车 TD-038 族诚实登记〕；oracle 零文件机检维持）
2. **刀 2（检查段 use-count 消费面 + 注解表面）**：typecheck.ktf 检查段 use-count 计数走查（0/1/ω 基数裁决族 +
   E 诊断码新位 + 限定消费裁决）+ target-parser 注解守卫 + infer 注解桥 qual 面 + 正交回归族（Q3 义务）+
   穿透 case（r182 TD-030 同族边界全量审查——§20.3）。
   **✅ DELIVERED @ r217**（typecheck.ktf 1,310→1,942 R9 面 + target-parser.ktf 4,747→4,885 `[lin] T` 皮肤〔含
   row-spec 深度泄漏同族捕获修复〕；映射表 §10 QL-12..QL-22 全条目 ✓；金档 qual_skin 56 案 14:42=1:3
   + E-code 注册表扩展披露〔code.rs 解码表——语义体零文件机检维持〕+ Q3 正交族（perform 载参 + handle 消费）
   + TD-030 族穿透审查结论〔载体递归泛型——emit_spec_value/Annotate 臂零载体变更，纯审计义务清偿〕
   + QL-10③ if-join 复审结论〔保守动态地板维持——行同族先例；分支区计数由 R9 面 min/max 合并承载〕
   + TD-032 ccf-parser 金档再生〔蓄意行动〕+ §3.2 六命令真电池〔T0 fresh 32/32 / T1 64+libs 106:0 /
   T2 边缘 11 族直跑全绿 + audit 522/522 live EXIT 0——三怪物窗算术停车 TD-038 族维持〕）。
3. **刀 3（语料 + audit + std 词汇 + 出口收口）**：corpus-qual 语料族 + audit Section 扩展（522 基线共变）+
   Q6 裁决 + with_cap 族 std 词汇（若裁决采纳）+ 出口判据六条收口（§7）。
   **✅ DELIVERED @ r218**（corpus-qual 28 案四判决臂〔value 10 + warn-linear 5 + type-error 8 + read-error 5〕
   经真实皮肤入产链 + sweep 挂载〔r189 efx 接线先例，T1 900 注册〕+ audit Section BM 10 案〔522→532 普查共变
   + guard TEST-3 同轮钉扎〕；**Q6 裁决 = 递延采纳**〔QL-27——零消费者信号 + 纪律已完整交付 + 纪律表达需注解钉扎 +
   载体位冻结；接口面冻结义务以 QL-27 为单源落档〕；出口六条全过〔§7 ✓ 行〕；§3.2 六命令真电池〔fmt 零 diff /
   build 0e0w / check 0e0w / clippy -D 零 / T0 fresh 32/32 / T1 65 绿 + digest 族 TD-038 停车〔parity 腿 501.46s
   直跑绿〕/ libs 839:0 / doc 0:0 / audit 532/532 live EXIT 0 / T2 边缘族直跑全绿——steady 7/7 @386.30s +
   parser_twin 6/6 @419.47s + segments 9/11/9/10 + fixpoint 9/9 + target_fixpoint 8/8 + abc 5+1；
   k159/forms-level/self-carrier 三停维持〕）——窗口 CLOSED。

每刀内循环走 §5.3 八项 + 集成 ≥3（正 ≥1/负 ≥3/跨阶段消费 ≥1）+ 7 类错误 ≥6 类负向覆盖（GATE 6）；
门审 ≥30 case 按 §7.3.1 构成扩展。

## 7. 出口判据（窗口 CLOSED 六条——全过 @ r218）

1. **金档全钉死 ✓**：正负 ≥1:3 + 7 类错误 ≥6 类负向覆盖 + 每子阶段集成 ≥3 构成达标（GATE 5/6）——
   窗口累计 116 案：刀 1 金档 32〔8:24=1:3 数据构造形〕+ 刀 2 金档 56〔14:42=1:3 皮肤/检查面〕+
   刀 3 语料 28〔10:18 四判决臂——value 真跑值钉 + warn-linear 线性族自有警告层 + type-error E0014/E0009/E0013 +
   read-error 皮肤五守卫〕；集成 ≥3 每刀满足（跨阶段消费：QL-21 效应正交 + QL-23 跨函数转移 + corpus sweep 全链
   parse→check→compile→VM）。
2. **真电池 ✓**：§3.2 六命令全绿实测（fmt 零 diff / build 0e0w @28.97s / check 0e0w / clippy -D warnings 零 /
   **T0 fresh 32/32**〔v0.153.0 bump 同轮共变〕/ T1 65 绿 + digest 族窗算术停车〔TD-038——parity 腿 501.46s 直跑绿〕/
   libs 839:0 / doc 0:0 / **audit 532/532 live EXIT 0**〔BM 十案入普查〕/ T2 边缘族直跑全绿〔k159/forms-level/
   self-carrier 三停 per-case 证据维持〕）——无指纹豁免（源码变更轮）。
3. **parity + fixpoint ✓**：全 parity sweep 回归绿（T1 65 族含 sweep/parity/row/hm 面）+ fixpoint B≡C 位级
   （fixpoint 9/9 @1.04s + target_fixpoint 8/8 @45.98s 双族直跑绿）+ **oracle 零文件机检**（`git diff
   crates/kerf-typecheck/` = 0 文件——刀 3 零源码触点，r174 冻结构造性维持）。
4. **8 原语第 165-167 轮构造性维持 ✓**（实施面逐刀复验：刀 3 变更面 = Cargo 版本对 + audit 例 + tests +
   tiers——零值层原语/零新内建/零通道/零 VM 触点/零操作码/零关键字表）。
5. **账实共变 ✓**：矩阵 §4 线性行 登记→✓（计数 94→95、✓64→65，v1.39）+ 台账 v1.29（selfhost 零变更诚实
   改账：wc 26,448 逐位不变）+ tech-debt r218 检视（TD-038 第 4 观测）+ calibration-data 触发器④观察轴维持登记。
6. **桥增殖基线 = 0 维持 ✓**：刀 3 零新桥（语料/审计/治理骑既有机制——sweep 接线 r189 先例 + audit 例既有驱动形 +
   guard 既有钉扎位；r174 终局裁定承继——窗口全程零桥增殖）。

## 8. 零载荷边界与链定位 + 环境实况

- **链定位**：completion-plan §3 Phase β 链首窗（β = W-LINEAR-TYPES → W-UNION-INTERSECT → W-COMPTIME——
  基础核心先行序；γ 糖域 / δ 生态位后置）。正交登记窗族触发器纪律维持（零信号不开窗——非冻结）。
- **零载荷**：S-expr 面零涉及（单皮肤 .ktf 终态 @ r154）；VM 基座 / cargo 构建引导 / 种子装载器（宪制排除三项）
  零触碰；效应族六实例已交付面零扰动（正交轴——Q3 回归族守护）。
- **环境实况（r215 材料性升级——预备档 §6 诚实边界翻新）**：
  - **工具链重建 @ r215**：Rust 1.99.0 全五件（rustc/cargo/rustfmt 1.10.0-stable/clippy 0.1.99/rust-std）经
    官方 dist 分段并行下载（沙箱 egress 限流 ~11KB/s 单连接的合规旁路——16 slots 聚合 ~110-176KB/s）+
    逐文件官方 .sha256 核验一致，落装 `/home/z/rust-battery`（与 worklog 末代电池环境精确一致）。
  - **真电池基线 @ r215（树零源码变更下实测）**：fmt 零 diff / build --release 0e0w（26.4s）/ check --all-targets
    0e0w / clippy -D warnings 零告警 / **T0 fresh 32/32** / libs 839:0 / doc 0:0 / **audit 522/522 live
    EXIT 0** / T2 台账银行化 32/75 族绿（分块前台耐力账——docs commit 换 HEAD 会归档，证据入 worklog）。
  - **重族约束如实登记**：abc k159 级单测在本沙箱 CPU 配额下超 runner slice 预算算术（per_case 安全倍增
    514s + 头位 90s > 单工具窗 600s 上限）→ 重族以直跑证据模式 + 台账 parking 处置；打包门（§19.3 fresh
    全量）对源码变更轮 = 逐窗耐力义务，docs-only 轮维持 §3.2.1 指纹豁免（r211 电池 #5 T2 75/75 of-record）。
  - **刀 1-3 验证义务在环境内可执行**（工具链 + 电池基线在位）——预备档「§3.2 六命令不可本机复跑」边界
    **就此解除**，后续源码轮不再有指纹豁免通道（除 docs-only 轮）。

## 9. 刀 1 实施映射表（r216-a 落档——W 机 qual 融合臂 + 四 walk 机族 + spec 机 + Display 面）

> 形制 = w-row-poly-window §8.1 先例（a-MUV 裁定落档 → b-MUV 对账单源）；编号空间 QL-1..QL-11（本窗自有，不与 RW/M# 空间混编）。

| # | 对象（位点） | 映射内容（b-MUV 对账单源） |
|---|---|---|
| QL-1 | 类型表示（新构造子） | `("qual" (a ...) T)`——谓词原子裸串列表 + body（ordinary type record 骑共享 var 空间）；**零原子壳不可达**（spec 降级它——空壳对其所拼写的同一性必失败）；原子 l = 裸串（pinned lin/un）；与 tdef 第四域 effects 裸名列表形态正交（tagged 复合 vs 裸列表） |
| QL-2 | spec 机（ti_resolve_spec "spec" 模式头分派加 `"qual"` 臂 + "qual"/"qual-atoms"/"qual-atom" 三模式） | `(qual a... S)` spec：末元素 = body（递归经 "spec"），其余元素 = 谓词原子；**≥1 原子必需**（单元素/空 → 整体降 dyn——GZ-1 保守族）；原子验证 pinned 词表 {lin, un}（未知原子/非串元素 → 降 dyn）；重复原子 → 整体降 dyn（ti_qual_dup——ti_row_dup 同族）；body 降 dyn → 整体降 dyn（失败传播——row 同族）；**零新错误路径** |
| QL-3 | W 机（ti_unify_step 复合分派加 `"qual"` 臂） | b 侧前置 `not(is_pair(b))` 守卫（r127 car-on-string 同族纪律）→ mis；`"qual"×"qual"` → ti_unify_qual（QL-4）；`"qual"×其他复合`（struct/enum/pair/fn/row）→ mis（精确谓词正交——限定类型永不对未限定 spine 合一）；dyn 前置吸收 / var 前置绑定维持不动 |
| QL-4 | ti_unify_qual 融合臂（+ ti_qual_preds_eq 助手） | 精确谓词表相等（同长同序——**kernel 携带不解释**：entailment = 刀 2 checker 面）→ 相等分解为 body 对（Jones 1994 融合：C⇒τ ~ C⇒τ' iff τ ~ τ'）；不等 → mis 骑原始记录（行 rule-5 同族）；**零新诊断码**（E0009/E0013 族 expected/found 双面可判别——body 分解后体级精确诊断自动成立〔neg-call-body-mismatch 案钉 int vs str〕） |
| QL-5 | 四 walk 机族 qual 臂（ti_varocc_walk / ti_subst_walk / ti_occurs_walk / ti_resolve_walk——RW-5 同族位点） | 原子裸串永不 var；body 唯一 var 承载槽：varocc 收集 body vars（首见序）；subst 原子骑不变 + body 替换（穿透面）；occurs body 递归（循环限定守卫）；resolve 原子骑不变 + body 深解析（tdef schema 输出面） |
| QL-6 | 泛化/实例化（ti_generalize / ti_instantiate） | **零新增函数**——QL-5 机族扩展即达（varocc 下钻自动捕获 body vars 入 schema vars；subst 下钻自动 fresh 实例化——HM let-多态对限定 body 全量生效；跨 define 实例化金档钉 schema (2)→t5 新鲜位） |
| QL-7 | Display 面（宿主解码基建 twin_type_display 加 "qual" 臂——**验证面扩展非 oracle 语义**，RW-7 同族） | `(qual a1 a2 ... T)`——原子 spec 序内联 + body 经共享类型面递归；tdef schema 串与 mis 诊断载荷双面消费本臂；宿主渲染模板零改动 |
| QL-8 | oracle 零改动精确口径（r174 冻结裁定 row-blade 消费者族） | `git diff crates/kerf-typecheck/` **零文件**（oracle 语义本体冻结机检）；`crates/kerf-driver/` 解码器 = 验证基建允许扩展（QL-7 臂 + 金档测试挂载）；`tests/` = 金档新文件；既有主库 parity sweep 零扰动（qual 语料不入主库——oracle Dyn ≠ twin qual，parity 断言豁免面 RW-8 先例延伸） |
| QL-9 | 金档落位（数据构造形——RW-9 皮肤勘定承继） | 皮肤无法产生 `"qual"` 头（`(` 一律 tuple / path(args) 一律 app 同因）→ **刀 1 金档 = 数据构造形**（32 案 8:24=1:3：正 8〔identity-lin / two-atoms〔un 词表钉〕/ body-pair / nested-qual / body-row-open〔schema vars (2) t2 穿透钉〕/ cross-define〔泛化+实例化双穿透 t5 钉〕/ degrade-unknown-atom / degrade-dup-atom〕vs 负 24〔E0013 ret 面 13：谓词 lin-vs-un / 集合长度 / 序反 / body int-str / body bool-int / 嵌套 body / 嵌套谓词 / qual×int 双向 / qual×pair / qual×fn / qual×row 双向；名义正交 2：struct/enum；E0009 调用位 9：字面量×2 / 谓词错 / body 错〔体级精确诊断钉〕/ row·pair·fn·enum-name 参数×4 / row×qual 反向〕）；`corpus-qual/` 源码语料目录 = 刀 3 交付物（audit 扩展同刀） |
| QL-10 | 边界勘定 | ① 降级族 = 保守边界正例（unknown-atom / dup-atom / 单元素 → dyn 吸收通过——钉死防静默漂移）；② `("qual")/` `(qual body)` 单元素面 → 整体降 dyn（零原子壳不可达——表示单一形态）；③ if-join 面：两结构等价但异 cell 的限定类型经 ti_type_eq `one` 模式 `_ => false` → 动态地板（行先例未入 ti_type_eq 臂的同族保守——刀 2 消费面重审）；④ 嵌套限定结构保持（(qual un (qual lin T)) 不展平——pair 复合可扩展性留后续窗） |
| QL-11 | tamper 针清查 | 新增代码零 E00/tdef 针形态（banned-token 零交集——r180 §14 同型机检口径）；限定诊断复用 mis 模板（零新诊断码 = 零新模板面）；§10.5 编码面：注释全 ASCII（首版数学符号 ⇒/τ 经 selfhost_format_guard 立捕当轮清偿——白名单 {em-dash, §} 纪律维持） |

- **§9 对账回填（r216-b/c）**：QL-1 ✓（零原子壳不可达）/ QL-2 ✓（三模式 + 保守降级族全落地）/ QL-3 ✓（r127 守卫同族）/ QL-4 ✓（精确谓词 + 体级精确诊断自动成立）/ QL-5 ✓（四机族 + body 唯一 var 槽）/ QL-6 ✓（零新增函数——跨 define 实例化钉 schema vars 捕获）/ QL-7 ✓（显示形 `(qual lin int)`）/ QL-8 ✓（kerf-typecheck 零文件机检）/ QL-9 ✓（数据构造金档 32 案 + 皮肤层勘定承继）/ QL-10 ✓（四边界全钉）/ QL-11 ✓（零新诊断码 + ASCII 清偿）；偏差零——全部实勘当轮披露当轮采纳。

## 10. 刀 2 实施映射表（r217 落档——检查段 use-count 消费面 + `[lin] T` 注解皮肤 + E 码注册表扩展披露）

> 形制 = §9 先例（a-MUV 裁定落档 → b-MUV 对账单源）；编号空间 QL-12..QL-22（§9 QL-1..11 的同窗续编，不与 RW/M# 混编）。

| # | 对象（位点） | 映射内容（b-MUV 对账单源） |
|---|---|---|
| QL-12 | 限定注解皮肤（target-parser row-spec "label" 相位分叉） | `[lin] T` / `[lin, un] T`——row 括号同体、首 ident 无冒号即分叉 qual-spec 机（原子逗号分隔 + 闭括号后 body type-drop 子机）；Q4「最小形·零关键字表变更」裁决兑现（tp_b_qual 字节表 define 非关键字）；**负向守卫**：无 body / 空格原子（[lin un]）/ 尾逗号 / 非 ident 原子 / row 缺冒号分叉位 = read-error 全钉（n25-n32） |
| QL-13 | tp_leave_g 守卫表（§20.6 同族捕获） | row-spec 臂自 r184 缺失——每 row 注解泄漏一层深度（256 帽下第 257 括号误触 nesting）当轮清偿 + qual-spec 分叉同槽双臂；**300 注解回归钉**（row_skin sk28——修复前必红的面） |
| QL-14 | E-code 注册表扩展（kerf-typecheck/src/code.rs） | **披露边界裁定**：r174 冻结范围 = oracle 语义体（check.rs/infer.rs/types.rs——零文件机检维持）；code.rs = twin 判决解码表（from_registry_str fail-closed）= QL-7「验证基建可扩展」族一 crate 之隔的同边界——oracle 永不发射新码（零语义变更）；LinearUseCountExceeded E0014 + LinearValueNeverConsumed E0015 + registry 单测共变（must-NOT-parse 列表骑行下一空位 E0016） |
| QL-15 | 检查段 lin 站点收集（tc_collect "dann" 臂 + tc_linn） | 刀 1 零码记录获唯一消费者：pinned {lin,un} 词表 + 无重复镜像 QL-2 降级族（未知原子/重复原子 → 无纪律——检查器与 resolver 同裁决）；param/let 双 kind（ret 零码维持——调用侧消费面非本面，披露）；行 ("l" kind s e as ae idx)——spec 跨度 = 报告锚（E0013 族同约定） |
| QL-16 | 活动行机族（tc_lina） | ("a" name lo hi flag boundary s e)——**区间基数 [lo, hi]**：公共路径双端同宽；**if 分支区 = 逐路径 min/max 合并**（Wadler 每路径恰一次——单支丢弃 lo=0→E0015、单支翻倍 hi=2→E0014、双发独立〔n15 钉〕、嵌套分支区复合〔n05/n42 钉〕）；escape 保守族 = 捕获（row.boundary < first(marks)）/ 赋值目标 / let 遮蔽——**永不诬告**方向裁决（us09 音义钉：捕获 + 直引两处句法引用零误报） |
| QL-17 | 帧出口裁决（tc_lina_frame_exit） | fn boundary 与 let mark 同键纪律（共活不碰撞证明：let 行仅在 bind push 后存在、其后每个 fn 见更长的 locals）；E0014 ("c14" name count=hi) error / E0015 ("c15" name) warning；**双发独立**（tc_lina_report 双 if 非链——n15 立捕后当轮修）；注册序 = 参数序钉（n07/n12/n14/n37） |
| QL-18 | R9 走查接线（tc_walk 五臂） | var 臂计数/捕获测试；fn 臂入注册 + 出口裁决；assign 臂 escape；letbinds push 注册（let-dann 锚 = bind 值节点跨度实勘）+ 终端出口；if 臂 → "linbranch" 模式机（.ktf 自递归族纪律——跨函数互调非法的机族单函数承载）；零行守卫（无活动行 = 旧双走查字节同形——parity 面） |
| QL-19 | 消息模板 + 解码（kerf-driver 验证基建） | render_cdiag_template c14/c15 臂（R8 单源字典族——小写开头/无句号/反引号载荷）；cdiag 解码经 from_registry_str fail-closed（QL-14 依赖位） |
| QL-20 | 字面量入界边界（kernel 精确谓词纪律的首面后果） | unify(i64, ("qual" lin i64)) = 故意 mis（QL-3）→ 纯字面量永不入限定参数（n24 钉）；**纪律净正例 = 定义未调用族**（检查器走查与推断体推断覆盖每个 define——纪律静态全行使，运行值维持普通）；降级族（未知/重复原子 → dyn → dyn 吸收字面量）可真调用运行（us12/us13 钉） |
| QL-21 | Q3 正交回归族 | perform 载参计数（us14——限定值经 effect 路由消费 + 箭头效应行槽正交）+ perform 双发（n08——effect 面穿透计数）；效应行 P2 形状冻结面零扰动（audit 522/522 + ef-族 sweep 回归绿） |
| QL-22 | TD-030 族穿透审查结论（§20.3 全量） | **载体递归泛型实证**：emit_spec_value（pair 链递归渲染）+ items_stream_prefix Annotate 臂（全 payload）对 qual spec 值树零载体变更——原子裸串 ≥1 + body 必在 → 空表 nil 歧义边界不可达（TD-030 的 Nil↔String("nil") 面对 qual 形态构造性豁免）；QL-10③ if-join 复审：**保守动态地板维持**（行同族先例——ti_type_eq 臂增设 = infer 语义变更，非检查器消费面；分支区基数由 R9 min/max 合并承载）+ TD-032 ccf-parser 金档再生（蓄意行动——regen 面唯 parser 档变 = 源作用域自证） |

- **§10 对账回填（r217-b/c/d）**：QL-12 ✓（皮肤 + 五守卫全钉）/ QL-13 ✓（双臂 + 300 钉）/ QL-14 ✓（披露边界 + 单测共变）/ QL-15 ✓（双 kind + 词表镜像）/ QL-16 ✓（区间基数 + min/max + escape 族 + 音义钉）/ QL-17 ✓（同键证明 + 双发独立）/ QL-18 ✓（五臂 + 模式机 + 零行守卫）/ QL-19 ✓（双模板）/ QL-20 ✓（字面量边界 + 定义未调用族 + 降级可跑族）/ QL-21 ✓（perform 双向 + audit 回归）/ QL-22 ✓（载体泛型实证 + if-join 维持 + 金档再生）；偏差零——全部实勘当轮披露当轮采纳。

## 11. 刀 3 实施映射表（r218 落档——corpus-qual 语料族 + audit Section BM + Q6 递延裁决 + 出口收口）

> 形制 = §9/§10 先例（a-MUV 裁定落档 → b-MUV 对账单源）；编号空间 QL-23..QL-31（同窗续编，不与 RW/M# 混编）。

| # | 对象（位点） | 映射内容（b-MUV 对账单源） |
|---|---|---|
| QL-23 | corpus-qual 语料族（tests/v1/stage1/corpus-qual/ 28 案） | 皮肤面真源语料——`[lin] T` 注解经真实 target-parser 皮肤入产链（非刀 1 数据构造形；QL-12 皮肤的首批真源消费者）；`// expect:` 行 = 判决单源四臂：value 10（单耗净洁/let 转移/跨函数转移/ret 注解转移/分支双路各耗一次/双原子逗号/[un] 无纪律双耗/Q3 效应正交消费/未知原子降级真跑/重复原子降级真跑）+ warn-linear 5（**线性族自有判决层**——E0015 警告级零消耗面不阻断运行〔行/效族无此臂〕：dropped param/dropped let/分支单侧 drop/闭包携带 drop/参数序双警声明序）+ type-error 8（E0014 双耗/三耗/跨函数双耗/嵌套分支区/let 分支双耗/使用位发散/ret 注解发散/字面量入界边界〔QL-20 纪律面钉〕）+ read-error 5（皮肤五守卫：body-less qual/空格原子/非 ident 原子/未闭括号/尾逗号）；oracle 零消费（r174 豁免面——corpus 纪律承自行族 r185/效族 r189） |
| QL-24 | sweep 挂载（plan/qual_corpus_sweep_tests.rs） | r189 efx 接线先例（产链四段真驱动 parse_target → typecheck → Engine::Vm run + `define(result, ...)` 值钉惯例）；deep-stack 512MB（r139 先例）；人口断言 ≥28 全态 + 四臂下限（≥10 value/≥5 warn/≥8 type/≥5 read）防静默漂移；T1 900 注册（tiers.tsv——**python 手术纪律**〔r216 tab 教训内化：本轮 Edit 工具 tab 扩张事故复发 → git 还原 + python 重插修复，全列 tab 完整性机检 0 坏行〕） |
| QL-25 | audit Section BM（10 案） | 生产孪生段驱动（Sections BG/BH 同驱动形——Session 默认段 + r174 冻结豁免面）：BM1 严格洁净普查双面（findings 空 + 值钉）/ BM2 E0014 count 载荷（`consumed \`2\` times`——Wadler 基数经皮肤）/ BM3 E0015 警告级不阻断（Q2 裁决 audit 面）/ BM4 双发独立 + 声明序钉 / BM5-BM6 双降级族真跑 / BM7 Q3 效应正交消费（限定轴 vs 效应行槽——P2 冻结面零扰动）/ BM8 分支区 per-path max 合并 / BM9 read 层皮肤守卫 / BM10 [un] 无纪律双耗零发现；**普查共变**：headline 522→532（A9..BM 全节） |
| QL-26 | 普查与版本同轮共变（r216 教训内化） | test_infra_guard TEST-3（documented map + BM 10 行 + total 532 + headline 字面钉 532/532 + 编年散文 BM 条目）+ tiers.tsv audit 行注释（532 live）+ Cargo.toml v0.153.0 + ds08（assert 0.153.0 + r216/r217/r218 编年注释块）——版本 bump 与 ds08 钉扎**同轮同 commit**清偿（r216 曾留 latent 面由 r217 单笔修复——本表登记该教训的纪律化） |
| QL-27 | **Q6 裁决（刀 3 内裁决——本表 = 接口面冻结义务的单源落档位）** | **递延采纳（DEFER）**：with_cap 族 std 词汇维持接口预留，随 L3 授权层窗（真信号开窗时）落档。判据四条：①**零消费者信号**——with_cap 的消费者 = L3 能力模型资源面（State/Async 效应族资源位），L3 窗未开，零信号不开窗纪律（§2.2 原则 38）对 std 词汇同等适用；②**纪律已完整交付**——`[lin] T` 注解面 + use-count 检查器 = 「消耗旧的、产生新的」（§6.10.3）完整静态表达位，任何 with_cap 组合子在其上组合，无缺件阻塞 L3；③**纪律表达需注解钉扎**——std 实例包先例（with_read r193 等） = 无注解 define（let-多态推断），而 use-count 收集位 = 注解站点（QL-15）——无注解 with_cap 零纪律检查（违背本窗目的），带纪律形需逐具体类型 `[lin] T` 钉扎（类型参数化注解皮肤 = γ 相位表面糖后置位，Q4 同族）；④**载体位冻结**——selfhost/std/ 库位 + W-EFFECT-INSTANCES 六实例形制先例（with_state r192/with_read r193 同构），纯 .ktf 载体零原语/零内建/零关键字成本——预留零成本。**接口面冻结**：名序 with_cap 族 + 载体位 selfhost/std/ + 组合基座（注解面 + 检查器面，本窗已交付冻结） |
| QL-28 | 出口判据六条收口（§7 ✓ 行） | 逐条证据锚回填——金档 116 案累计（32+56+28）/ 六命令真电池（含 audit 532/532 EXIT 0）/ parity+fixpoint 回归绿 + oracle 零文件 / 8 原语第 165-167 轮 / 账实共变族（矩阵 v1.39 + 台账 v1.29 + tech-debt + calibration）/ 桥增殖 = 0（窗口全程零桥） |
| QL-29 | TD-038 窗算术维持（第 4 观测） | digest parity 腿 501.46s 直跑绿（r216 483s → r217 468s → r218 501s——树增长轨迹如实）+ 一切 window-fit 全绿：fixpoint 9/9 @1.04s + steady 7/7 @386.30s + parser_twin 6/6 @419.47s + segments 9/11/9/10 + target_fixpoint 8/8 @45.98s + abc 5 pass + 1 ignore（regen 蓄意通道）+ macro-carrier ok；**三停维持**：forms-level（digest 族内 ~1017s 估）/ k159（abc 族内）/ self-carrier（orchestrator-fixpoint 族内）——per-case 直跑证据模式 + 台账 parking 处置（r216/r217 先例承继） |
| QL-30 | 8 原语第 167 轮（实施面构造性） | 树 diff 实勘：`crates/kerf-typecheck/` 零文件（oracle 机检）+ `selfhost/` 零文件 + 变更面 = Cargo 版本对 + audit 例 + tests 四件 + tiers——零值层原语/零新内建/零通道/零 VM 触点/零操作码/零关键字表（刀 3 = 纯测试/审计/治理面——构造性维持的最强形） |
| QL-31 | 账实共变族 | ledger v1.29（s-expr-conversion-record——**selfhost 零变更诚实改账**：wc v1/ 13 件 26,067 + std/ 7 件 381 = 26,448 逐位不变 + 刀 3 语料/审计面入账〔tests/examples 位——非自举产链位〕+ Q6 递延 = std 零变更）+ 矩阵 v1.39（§4 线性行 登记→✓，计数 94→95、✓64→65）+ completion-plan v1.63（Phase β 链首窗 CLOSED）+ roadmap v3.27 + tech-debt r218 检视 + calibration-data 触发器④观察轴维持 + RELEASE_NOTES r218 + 金链 v0.153.0 |

- **§11 对账回填（r218-a/b/c/d）**：QL-23 ✓（28 案四臂 + expect 单源）/ QL-24 ✓（efx 接线 + 人口断言 + T1 注册）/ QL-25 ✓（BM 十案 + 普查 532）/ QL-26 ✓（guard/tiers/版本/ds08 同轮）/ QL-27 ✓（Q6 递延 + 接口冻结落档）/ QL-28 ✓（§7 六条 ✓）/ QL-29 ✓（parity 腿直跑绿 + 三停维持）/ QL-30 ✓（零源码触点构造性）/ QL-31 ✓（共变族全落）；偏差零——全部实勘当轮披露当轮采纳。

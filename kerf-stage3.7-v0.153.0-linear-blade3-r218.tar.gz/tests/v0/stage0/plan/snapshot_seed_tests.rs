//! Stage 0.11 snapshot suite — the §22.3 milestone L6 determinism
//! layer (docs/tests/v0/stage0/plan/snapshot.md).
//!
//! A snapshot case freezes one fixed input into one exact output
//! string across a pipeline layer (stage0.md §13.2 layer 1:
//! deterministic output). The goldens below were recorded from the
//! verified 0.10-r3 baseline (710:0:0 + audit 110/110) via a
//! temporary probe and eye-checked line by line; they change only
//! with an explicit behavior change logged in the worklog. The r151
//! single-skin retarget (W-SEXP-RETIRE blade 2): every fixture below
//! rides the target skin — the goldens whose mapped trees are
//! identical to the S-expr originals keep their bytes verbatim, and
//! the sources whose target grammar reshapes the tree (arithmetic
//! chains, block folds, call forms, render spans) carry re-recorded
//! goldens.
//!
//! The dump helpers are deterministic test-side walkers (structure
//! only — spans/scopes/phase are the span/syntax test families'
//! job, not the snapshot object).

use kerf::compiler::{Bytecode, compile_program};
use kerf::core::{CoreExpr, LiteralValue, ModuleItem};
use kerf::driver::{self, Engine, Repl, ReplEvent, Session, run_source};
use kerf::expander::expand_program;
use kerf::reader::read_target_program;
use kerf::span::FileId;
use kerf::syntax::{StxDatum, SyntaxObject};
use kerf::vm::Value;

const FILE: FileId = FileId(0);

// ---------- deterministic dump walkers ----------

fn dump_stx(node: &SyntaxObject) -> String {
    match &node.datum {
        StxDatum::Symbol(s) => s.as_str().to_owned(),
        StxDatum::Int(v) => format!("int:{v}"),
        StxDatum::Float(v) => format!("float:{v}"),
        StxDatum::Bool(v) => format!("bool:{v}"),
        StxDatum::String(s) => format!("str:{s:?}"),
        StxDatum::List(items) => {
            let inner: Vec<String> = items.iter().map(dump_stx).collect();
            format!("({})", inner.join(" "))
        }
    }
}

fn dump_literal(v: &LiteralValue) -> String {
    match v {
        LiteralValue::Int(n) => format!("{n}"),
        LiteralValue::Float(n) => format!("{n}"),
        LiteralValue::Bool(b) => format!("{b}"),
        LiteralValue::String(s) => format!("{s:?}"),
        LiteralValue::Nil => "nil".to_owned(),
        LiteralValue::Pair(a, b) => format!("({} . {})", dump_literal(a), dump_literal(b)),
    }
}

fn dump_core(e: &CoreExpr) -> String {
    match e {
        CoreExpr::Fn { params, body, .. } => format!(
            "(fn ({}) {})",
            params
                .iter()
                .map(|p| p.as_str())
                .collect::<Vec<_>>()
                .join(" "),
            dump_core(body)
        ),
        CoreExpr::Apply { func, args, .. } => {
            let mut parts = vec![dump_core(func)];
            parts.extend(args.iter().map(dump_core));
            format!("(apply {})", parts.join(" "))
        }
        CoreExpr::If {
            cond,
            then_branch,
            else_branch,
            ..
        } => format!(
            "(if {} {} {})",
            dump_core(cond),
            dump_core(then_branch),
            dump_core(else_branch)
        ),
        CoreExpr::Var { name, .. } => name.as_str().to_owned(),
        CoreExpr::Literal { value, .. } => dump_literal(value),
        CoreExpr::Assign { name, value, .. } => {
            format!("(set! {} {})", name.as_str(), dump_core(value))
        }
        CoreExpr::Let { bindings, body, .. } => {
            let bs: Vec<String> = bindings
                .iter()
                .map(|b| format!("({} {})", b.name.as_str(), dump_core(&b.value)))
                .collect();
            format!("(let ({}) {})", bs.join(" "), dump_core(body))
        }
        CoreExpr::Perform { effect, args, .. } => {
            let mut parts = vec![effect.as_str().to_owned()];
            parts.extend(args.iter().map(dump_core));
            format!("(perform {})", parts.join(" "))
        }
        CoreExpr::Handle { body, handlers, .. } => {
            let hs: Vec<String> = handlers
                .iter()
                .map(|h| format!("({} {})", h.effect.as_str(), dump_core(&h.handler)))
                .collect();
            format!("(handle {} {})", dump_core(body), hs.join(" "))
        }
    }
}

fn dump_item(item: &ModuleItem) -> String {
    match item {
        ModuleItem::Define { name, value, .. } => {
            format!("(define {} {})", name.as_str(), dump_core(value))
        }
        ModuleItem::Require { module, .. } => format!("(require {})", module.as_str()),
        ModuleItem::Module { name, items, .. } => {
            let inner: Vec<String> = items.iter().map(dump_item).collect();
            format!("(module {} {})", name.as_str(), inner.join(" "))
        }
        ModuleItem::DefineSyntax { name, .. } => {
            format!("(define-syntax {})", name.as_str())
        }
        ModuleItem::Annotate { .. } => {
            // The blade 1 dann site record: the snapshot face renders
            // the module skeleton (defines and their code) — the
            // zero-code annotation records are the checker's own
            // input, not the code face.
            String::new()
        }
        ModuleItem::Struct { .. } => {
            // The blade 2 struct record: the same zero-code class —
            // the runtime face is the generated defines (real items
            // this skeleton renders); the type-layer record is the
            // checker's own input.
            String::new()
        }
        ModuleItem::Enum { .. } => {
            // The blade 3 enum record: the struct record's own —
            // the runtime face is the generated constructor defines.
            String::new()
        }
        ModuleItem::Extern { items, .. } => {
            let inner: Vec<String> = items
                .iter()
                .map(|e| {
                    format!(
                        "({} [{}] {})",
                        e.name.as_str(),
                        e.params
                            .iter()
                            .map(|t| t.kind_tag())
                            .collect::<Vec<_>>()
                            .join(","),
                        e.ret.kind_tag()
                    )
                })
                .collect();
            format!("(extern {})", inner.join(" "))
        }
    }
}

fn dump_bytecode(bc: &Bytecode) -> String {
    let mut out = Vec::new();
    for (i, f) in bc.funcs.iter().enumerate() {
        let name = f.name.as_ref().map(|s| s.as_str()).unwrap_or("<entry>");
        out.push(format!(
            "func {i} {name} params {} locals {}",
            f.params, f.n_locals
        ));
        for instr in &f.code {
            out.push(format!("  {instr}"));
        }
    }
    out.join("\n")
}

// ---------- pipeline drivers ----------

fn read_stx(src: &str) -> Vec<String> {
    let forms = read_target_program(FILE, src).expect("snapshot source must read");
    forms.iter().map(dump_stx).collect()
}

fn expand_items(src: &str) -> Vec<String> {
    let forms = read_target_program(FILE, src).expect("snapshot source must read");
    let items = expand_program(&forms).expect("snapshot source must expand");
    items.iter().map(dump_item).collect()
}

fn compile_dump(src: &str) -> String {
    let forms = read_target_program(FILE, src).expect("snapshot source must read");
    let items = expand_program(&forms).expect("snapshot source must expand");
    let bc = compile_program(&items).expect("snapshot source must compile");
    bc.verify().expect("snapshot product must verify");
    dump_bytecode(&bc)
}

fn run_vm(src: &str) -> (String, String, String) {
    let mut session = Session::new();
    let outcome = run_source(&mut session, "p.ktf", src, Engine::Vm, &[]).expect("vm run");
    let globals = outcome
        .globals
        .iter()
        .map(|(n, v)| format!("{n}={v}"))
        .collect::<Vec<_>>()
        .join(" ");
    (
        outcome.value_display(),
        globals,
        outcome.outputs.join(" | "),
    )
}

// ---------- §A reader layer (FP1) ----------

#[test]
fn rs01_int_atom_skeleton() {
    assert_eq!(read_stx("42;"), ["int:42"]);
}

#[test]
fn rs02_float_atom_skeleton() {
    // The r151 target-skin note: a leading `-` is the unary-minus
    // operator (`-3.5` reads as `(- 0 3.5)` — the r103 spellability
    // boundary), so the float-atom skeleton rides the positive
    // literal.
    assert_eq!(read_stx("3.5;"), ["float:3.5"]);
}

#[test]
fn rs03_bool_atom_skeleton() {
    assert_eq!(read_stx("true;"), ["bool:true"]);
}

#[test]
fn rs04_string_atom_skeleton() {
    assert_eq!(read_stx("\"hello world\";"), ["str:\"hello world\""]);
}

#[test]
fn rs05_symbol_atom_skeleton() {
    // The target spelling `sym_name` maps through the skin
    // dictionary (Rule K: an interior `_` between alphanumerics is
    // the S-expr face's `-`) onto the canonical identity `sym-name`.
    assert_eq!(read_stx("sym_name;"), ["sym-name"]);
}

#[test]
fn rs06_flat_list_skeleton() {
    assert_eq!(read_stx("(1 + 2);"), ["(+ int:1 int:2)"]);
}

#[test]
fn rs07_nested_list_skeleton() {
    assert_eq!(read_stx("a(b(c(1)), 2);"), ["(a (b (c int:1)) int:2)"]);
}

#[test]
fn rs08_comment_and_whitespace_are_lossless() {
    // A leading `//` comment plus blank line: the skeleton is exactly
    // the one form that survives (the target skin's comment face is
    // the C-style line comment).
    assert_eq!(
        read_stx("// leading comment\n\n(1 + 2);"),
        ["(+ int:1 int:2)"]
    );
}

#[test]
fn rs09_full_nine_primitive_fib_source_skeleton() {
    assert_eq!(
        read_stx("fn fib(n) { if ((n < 2)) { n } else { (fib((n - 1)) + fib((n - 2))) } }"),
        ["(define (fib n) (if (< n int:2) n (+ (fib (- n int:1)) (fib (- n int:2)))))"]
    );
}

#[test]
fn rs10_quote_comma_datum_is_a_list_skeleton() {
    // The r151 target-skin note: the S-expr `.` fact (a dot inside a
    // list reads as an ordinary symbol — dotted pairs are not
    // modeled in StxDatum) retired with the S-expr reader; on the
    // target skin `.` is field-access skin material and the datum
    // face rejects it fail-closed. The datum-face skeleton twin: the
    // comma-separated tuple `quote((d1, d2, ...))` is the LIST datum
    // the S-expr face's `(quote (d1 d2 ...))` read (the pos-014
    // corpus spelling).
    assert_eq!(
        read_stx("quote((1, 2, 3));"),
        ["(quote (int:1 int:2 int:3))"]
    );
}

// ---------- §B expander layer (FP2) ----------

#[test]
fn es01_literal_define_expands_to_int() {
    assert_eq!(expand_items("define(a, 42);"), ["(define a 42)"]);
}

#[test]
fn es02_fn_form_expands_to_fn_node() {
    assert_eq!(
        expand_items("define(f, ||(x) { (x + 1) });"),
        ["(define f (fn (x) (apply + x 1)))"]
    );
}

#[test]
fn es03_application_expands_with_explicit_apply_head() {
    // The r151 target-skin note: an arithmetic chain folds into
    // left-nested BINARY applications (the three-argument `(+ 1 2 3)`
    // call is unspellable on the target skin — operator glyphs are
    // skin material), so the apply-head golden shows the chain's
    // nesting honestly.
    assert_eq!(
        expand_items("define(s, 1 + 2 + 3);"),
        ["(define s (apply + (apply + 1 2) 3))"]
    );
}

#[test]
fn es04_if_expands_to_three_way_node() {
    assert_eq!(
        expand_items("define(b, if (true) { 1 } else { 2 });"),
        ["(define b (if true 1 2))"]
    );
}

#[test]
fn es05_var_reference_expands_to_bare_name() {
    // A let-bound body reference: the Var node renders as the name.
    assert_eq!(
        expand_items("define(l, { let q = 1; q });"),
        ["(define l (let ((q 1)) q))"]
    );
}

#[test]
fn es06_let_expands_to_binding_chain() {
    assert_eq!(
        expand_items("define(l, { let a = 1, b = 2; (a + b) });"),
        ["(define l (let ((a 1) (b 2)) (apply + a b)))"]
    );
}

#[test]
fn es07_do_desugars_to_let_with_discard_names() {
    assert_eq!(
        expand_items("define(d, { (1 + 2); 7 });"),
        ["(define d (let ((_ (apply + 1 2))) 7))"]
    );
}

#[test]
fn es08_assign_keeps_set_head() {
    assert_eq!(
        expand_items("define(g0, 1); define(g1, set(g0, 5));"),
        ["(define g0 1)", "(define g1 (set! g0 5))"]
    );
}

#[test]
fn es09_perform_expands_with_effect_name() {
    assert_eq!(
        expand_items("define(p, perform e(1, 2));"),
        ["(define p (perform e 1 2))"]
    );
}

#[test]
fn es10_handle_expands_with_handler_clauses() {
    assert_eq!(
        expand_items("define(h, handle (perform e()) { e(v) => { v }, });"),
        ["(define h (handle (perform e) (e (fn (v) v))))"]
    );
}

// ---------- §C compiler layer (FP3) ----------

#[test]
fn cs01_literal_define_loads_const_and_stores_global() {
    assert_eq!(
        compile_dump("define(a, 7);"),
        "func 0 <entry> params 0 locals 0\n  push-const 0 0\n  store-global 0 0\n  halt 0 0"
    );
}

#[test]
fn cs02_binary_application_is_two_consts_global_call() {
    // r134 (FA-2): the arithmetic site direct-emits `add` — the
    // name never interns (FA-4), so `s` is the only global.
    assert_eq!(
        compile_dump("define(s, (2 + 3));"),
        "func 0 <entry> params 0 locals 0\n  push-const 0 0\n  push-const 1 0\n  add 0 0\n  store-global 0 0\n  halt 0 0"
    );
}

#[test]
fn cs03_if_compiles_to_jump_shape() {
    assert_eq!(
        compile_dump("define(b, if (1 < 2) { 10 } else { 20 });"),
        "func 0 <entry> params 0 locals 0\n  push-const 0 0\n  push-const 1 0\n  call-global 0 2\n  jump-if-false 6 0\n  push-const 2 0\n  jump 7 0\n  push-const 3 0\n  store-global 1 0\n  halt 0 0"
    );
}

#[test]
fn cs04_let_compiles_to_store_local_chain() {
    // r134 (FA-2): the `+` site direct-emits; `l` is the only global.
    assert_eq!(
        compile_dump("define(l, { let a = 1, b = 2; (a + b) });"),
        "func 0 <entry> params 0 locals 2\n  push-const 0 0\n  store-local 0 0\n  push-const 1 0\n  store-local 1 0\n  load-local 0 0\n  load-local 1 0\n  add 0 0\n  store-global 0 0\n  halt 0 0"
    );
}

#[test]
fn cs05_define_function_produces_closure_proto() {
    // r134 (FA-2/FA-4): the body `+` direct-emits; `f` is the only
    // global (slot 0). r135 (TJ-1): the (x, 1) argument pair fuses
    // to one load-local-const.
    assert_eq!(
        compile_dump("fn f(x) { (x + 1) }"),
        "func 0 <entry> params 0 locals 0\n  closure 1 0\n  store-global 0 0\n  halt 0 0\nfunc 1 f params 1 locals 1\n  load-local-const 0 0\n  add 0 0\n  ret 0 0"
    );
}

#[test]
fn cs06_anonymous_closure_immediate_call() {
    // r134 (FA-2/FA-4): the Fn callee keeps the plain call (the
    // fusion condition is Var-only); the body `*` direct-emits and
    // `s2` is the only global.
    assert_eq!(
        compile_dump("define(s2, (||(x) { x * x })(6));"),
        "func 0 <entry> params 0 locals 0\n  push-const 0 0\n  closure 1 0\n  call 1 0\n  store-global 0 0\n  halt 0 0\nfunc 1 <entry> params 1 locals 1\n  load-local 0 0\n  load-local 0 0\n  mul 0 0\n  ret 0 0"
    );
}

#[test]
fn cs07_cons_is_an_ordinary_global_call() {
    assert_eq!(
        compile_dump("define(p, pair(1, 2));"),
        "func 0 <entry> params 0 locals 0\n  push-const 0 0\n  push-const 1 0\n  call-global 0 2\n  store-global 1 0\n  halt 0 0"
    );
}

#[test]
fn cs08_nested_call_is_inner_first() {
    assert_eq!(
        compile_dump("define(c, first(pair(1, 2)));"),
        "func 0 <entry> params 0 locals 0\n  push-const 0 0\n  push-const 1 0\n  call-global 0 2\n  call-global 1 1\n  store-global 2 0\n  halt 0 0"
    );
}

#[test]
fn cs09_fib_closure_is_the_16_instruction_contract() {
    // r134 (FA-2/FA-4): globals = [<, fib] (the `-`/`+` sites
    // direct-emit and never intern). r135 (TJ-1): the three
    // (local, const) argument pairs — the `(< n 2)` comparison
    // args and both `(- n k)` subtraction operands — fuse to one
    // load-local-const each (19 -> 16 instructions; the jump
    // target shifts 6 -> 5 with the eliminated slots).
    assert_eq!(
        compile_dump("fn fib(n) { if ((n < 2)) { n } else { (fib((n - 1)) + fib((n - 2))) } }"),
        "func 0 <entry> params 0 locals 0\n  closure 1 0\n  store-global 1 0\n  halt 0 0\nfunc 1 fib params 1 locals 1\n  load-local-const 0 0\n  call-global 0 2\n  jump-if-false 5 0\n  load-local 0 0\n  ret 0 0\n  load-local-const 0 1\n  sub 0 0\n  call-global 1 1\n  load-local-const 0 0\n  sub 0 0\n  call-global 1 1\n  add 0 0\n  ret 0 0"
    );
}

#[test]
fn cs10_entry_consumes_the_defined_closure() {
    // r134 (FA-4): globals = [<, fib, r] — three slots, the direct
    // arithmetic names never enter the table. r135 (TJ-1): the
    // fib body's three (local, const) pairs fuse (see cs09).
    assert_eq!(
        compile_dump(
            "fn fib(n) { if ((n < 2)) { n } else { (fib((n - 1)) + fib((n - 2))) } } define(r, fib(6));"
        ),
        "func 0 <entry> params 0 locals 0\n  closure 1 0\n  store-global 1 0\n  push-const 2 0\n  call-global 1 1\n  store-global 2 0\n  halt 0 0\nfunc 1 fib params 1 locals 1\n  load-local-const 0 0\n  call-global 0 2\n  jump-if-false 5 0\n  load-local 0 0\n  ret 0 0\n  load-local-const 0 1\n  sub 0 0\n  call-global 1 1\n  load-local-const 0 0\n  sub 0 0\n  call-global 1 1\n  add 0 0\n  ret 0 0"
    );
}

// ---------- §D vm / eval layer (FP4) ----------

#[test]
fn vs01_arithmetic_define_runs_to_value() {
    // r134 (FA-4): the direct-only `+` reference never interns —
    // the observation face carries `r` alone (the `+=#<builtin:+>`
    // row rides the load-global face, pinned in compile.rs tests).
    let (val, globals, outs) = run_vm("define(r, 1 + 2);");
    assert_eq!(val, "nil");
    assert_eq!(globals, "r=3");
    assert_eq!(outs, "");
}

#[test]
fn vs02_recursive_fact_runs_to_720() {
    // r134 (FA-4): `-` and `*` direct-emit — the observation face
    // carries `<`, fact, and r.
    let (val, globals, outs) = run_vm(
        "fn fact(n) { if ((n < 2)) { 1 } else { (n * fact((n - 1))) } } define(r, fact(6));",
    );
    assert_eq!(val, "nil");
    assert_eq!(globals, "<=#<builtin:<> fact=#<closure> r=720");
    assert_eq!(outs, "");
}

#[test]
fn vs03_cons_produces_opaque_pair_global() {
    let (val, globals, outs) = run_vm("define(p, pair(1, 2));");
    assert_eq!(val, "nil");
    assert_eq!(globals, "cons=#<builtin:cons> p=#<pair>");
    assert_eq!(outs, "");
}

#[test]
fn vs04_car_of_cons_selects_left_string() {
    let (val, globals, outs) = run_vm("define(c, first(pair(\"left\", 2)));");
    assert_eq!(val, "nil");
    assert_eq!(
        globals,
        "cons=#<builtin:cons> car=#<builtin:car> c=\"left\""
    );
    assert_eq!(outs, "");
}

#[test]
fn vs05_set_mutates_global_in_place() {
    let (val, globals, outs) = run_vm("define(a, 1); define(a2, set(a, 5)); define(r2, a);");
    assert_eq!(val, "nil");
    assert_eq!(globals, "a=5 a2=5 r2=5");
    assert_eq!(outs, "");
}

#[test]
fn vs06_let_bindings_sum_to_three() {
    // r134 (FA-4): the `+` reference is direct-only — no slot.
    let (val, globals, outs) = run_vm("define(l, { let a = 1, b = 2; (a + b) });");
    assert_eq!(val, "nil");
    assert_eq!(globals, "l=3");
    assert_eq!(outs, "");
}

#[test]
fn vs07_nil_predicate_branches_to_string() {
    let (val, globals, outs) =
        run_vm("define(s, if (is_nil(nil)) { \"is-nil\" } else { \"not-nil\" });");
    assert_eq!(val, "nil");
    assert_eq!(globals, "nil?=#<builtin:nil?> s=\"is-nil\"");
    assert_eq!(outs, "");
}

#[test]
fn vs08_write_line_emits_the_output_line() {
    let (val, globals, outs) = run_vm("define(w, write_line(\"out-line\"));");
    assert_eq!(val, "nil");
    assert_eq!(globals, "write-line=#<builtin:write-line> w=nil");
    assert_eq!(outs, "out-line");
}

#[test]
fn vs09_eq_on_two_pairs_is_false_identity_semantics() {
    // Two cons allocations are distinct heap objects: eq? is identity,
    // not structural equality.
    let (val, globals, outs) = run_vm("define(e, eq(pair(1, 2), pair(1, 2)));");
    assert_eq!(val, "nil");
    assert_eq!(globals, "cons=#<builtin:cons> eq?=#<builtin:eq?> e=false");
    assert_eq!(outs, "");
}

#[test]
fn vs10_pair_predicate_is_true_on_pair() {
    let (val, globals, outs) = run_vm("define(p2, is_pair(pair(1, 2)));");
    assert_eq!(val, "nil");
    assert_eq!(
        globals,
        "cons=#<builtin:cons> pair?=#<builtin:pair?> p2=true"
    );
    assert_eq!(outs, "");
}

#[test]
fn ve01_eval_engine_fib_ten_agrees() {
    let mut session = Session::new();
    let src = "fn fib(n) { if ((n < 2)) { n } else { (fib((n - 1)) + fib((n - 2))) } } define(r, fib(10));";
    let outcome = run_source(&mut session, "p.ktf", src, Engine::Eval, &[]).expect("eval run");
    assert_eq!(
        outcome.global("r").map(|v| v.to_string()),
        Some("55".to_owned())
    );
}

#[test]
fn ve02_eval_engine_car_selects_left() {
    let mut session = Session::new();
    let src = "define(c, first(pair(\"left\", 2)));";
    let outcome = run_source(&mut session, "p.ktf", src, Engine::Eval, &[]).expect("eval run");
    assert_eq!(
        outcome.global("c").map(|v| v.to_string()),
        Some("\"left\"".to_owned())
    );
}

// ---------- §E driver layer (FP5) ----------

fn render_of(src: &str) -> String {
    let mut session = Session::new();
    let diags = run_source(&mut session, "p.ktf", src, Engine::Vm, &[]).expect_err("must fail");
    driver::render_diagnostics(&session, &diags)
}

#[test]
fn ds01_unclosed_delimiter_render_golden() {
    // The r151 target-skin twin: the unclosed-BLOCK face renders the
    // same family message (an unclosed group paren renders as the
    // end-of-input token face instead — the two render shapes both
    // pin the fail-closed boundary).
    assert_eq!(
        render_of("fn f(x) { x"),
        "error[kerf-read]: unclosed delimiter: `{` is never closed\n --> p.ktf:1:9\n  |\n1 | fn f(x) { x\n  |         ^\n"
    );
}

#[test]
fn ds02_type_mismatch_render_golden() {
    // The Stage 1.8 HM wiring hoists the literal `(car 5)` face to
    // the checker (E0009, probe-verified); this golden keeps the
    // runtime face by feeding `first` through an HM-released dynamic
    // parameter (a forall-a schema the caller satisfies — the shape
    // constraint is released, §9.49 GATE-2). The r151 target-skin
    // golden: the runtime message names the target spelling
    // (`first`), and the call form's span starts at the open paren
    // (extended by the closure body's block fold to the close brace).
    assert_eq!(
        render_of("define(f, ||(x) { first(x) });\ndefine(r, f(5));"),
        "error[kerf-runtime]: type mismatch: first operand must be a pair, got `int`\n --> p.ktf:1:24\n  |\n1 | define(f, ||(x) { first(x) });\n  |                        ^^^^^\n"
    );
}

#[test]
fn ds02b_hm_checker_mismatch_render_golden() {
    // The checker face the HM wiring adds: the literal car-of-int
    // is now a compile-time E0009 (probe-verified at Stage 1.8). The
    // r151 target-skin golden: the caret spans the call form's own
    // extent (`(5)` — the call form's span starts at the open paren).
    assert_eq!(
        render_of("define(r, first(5));"),
        "error[E0009]: type mismatch: expected `pair`, found `int`\n --> p.ktf:1:16\n  |\n1 | define(r, first(5));\n  |                ^^^\n"
    );
}

#[test]
fn ds03_arity_mismatch_render_golden() {
    // Golden updated with the Stage 1.1 wiring (behavior change: a
    // known-callee arity mismatch is now caught statically before
    // execution — E0002 registry tag, no runtime file# suffix; the
    // runtime face stays covered by the driver module tests through
    // a checker-opaque param-mediated call). The r151 target-skin
    // twin: the three-argument `+` call is unspellable (operator
    // glyphs are skin material), so the static face rides the
    // nameable `first` (`car`, fixed arity 1) with two arguments.
    assert_eq!(
        render_of("define(r, first(1, 2));"),
        "error[E0002]: arity mismatch: `first` expects `1` argument, got `2`\n --> p.ktf:1:16\n  |\n1 | define(r, first(1, 2));\n  |                ^^^^^^\n"
    );
}

#[test]
fn ds04_unbound_identifier_render_golden() {
    assert_eq!(
        render_of("define(r, undefined_fn(1));"),
        "error[kerf-expand]: unbound identifier `undefined_fn`: not in any lexical scope and not a Stage 0 global\n --> p.ktf:1:11\n  |\n1 | define(r, undefined_fn(1));\n  |           ^^^^^^^^^^^^\n"
    );
}

#[test]
fn ds05_stray_close_delimiter_render_golden() {
    // The r151 single-skin retarget: the S-expr empty-application
    // face (`()` has no operator) retired with the S-expr reader —
    // on the target skin `()` is the UNIT skin (ruling C12: `()` is
    // `nil`). The read-layer render twin in this slot: the stray
    // closing delimiter (neg-002's family).
    assert_eq!(
        render_of(")"),
        "error[kerf-read]: unexpected closing delimiter `)`\n --> p.ktf:1:1\n  |\n1 | )\n  | ^\n"
    );
}

#[test]
fn ds06_check_face_counts_the_product() {
    let mut session = Session::new();
    let src = "fn fib(n) { if ((n < 2)) { n } else { (fib((n - 1)) + fib((n - 2))) } } define(r, fib(6));";
    let check = driver::check_source(&mut session, "p.ktf", src).expect("check");
    // r134 (FA-2/FA-4): globals shrink 5 -> 3 (the `-`/`+` names
    // never intern). r135 (TJ-1): instrs 22 -> 19 (the three
    // (local, const) argument pairs fuse to load-local-const).
    assert_eq!(
        format!(
            "funcs={} instrs={} globals={}",
            check.func_count, check.instr_count, check.global_count
        ),
        "funcs=2 instrs=19 globals=3"
    );
}

#[test]
fn ds07_parity_three_faces_agree() {
    let mut session = Session::new();
    let src = "fn fib(n) { if ((n < 2)) { n } else { (fib((n - 1)) + fib((n - 2))) } } define(r, fib(6));";
    let report = driver::run_parity_source(&mut session, "p.ktf", src, &[]).expect("parity");
    assert_eq!(
        format!(
            "values={} outputs={} globals={}",
            report.values_agree, report.outputs_agree, report.globals_agree
        ),
        "values=true outputs=true globals=true"
    );
}

#[test]
fn ds08_workspace_version_string() {
    // Golden updated with the v0.63.0 Stage 2.7 window-opening
    // release (behavior change: workspace version bump — the
    // syntax-replacement window opens per the #15 gate ruling:
    // the EBNF v9 final draft (§9.26) plus the skin dictionary
    // mapping base are in place, the Stage 2a closeout quality
    // signals hold (the r92 three-criteria verification), and the
    // user's advance-per-plan instruction completes the double
    // premise; the B2 three-option ruling lands as option 1 —
    // if/perform/handle take expression positions at the primary
    // face (the kernel's expressiveness, the Koka/OCaml 5/Rust
    // precedents, the skin dictionary's completeness); the step-1
    // seed ships: kerf-reader's target module, the v9 Level 0
    // parity subset mapped through the skin dictionary onto the
    // same syntax-object trees, the §9.25.4 parity contract
    // asserted as the semantic projection (instruction streams,
    // constants, globals — the debug_info spans excluded by the
    // layering ruling) plus behavior; the seed-scope boundary
    // (struct/enum/type/effect/capability/match/generics/where/
    // cast/range/field/index/halt/pass) rejects fail-closed with
    // the registered variant; audit AB 284/284, tests 1448:0:0).
    //
    // Prior golden: v0.62.0 recorded at the Stage 2.6 close-out
    // release (behavior change: workspace version bump — the
    // 2.6 window closes with the Stage 2a exit criteria
    // verified in full: (1) the whole compiler in kerf (the
    // five selfhost pieces ride the complete .ktf chain —
    // standing evidence re-run this round), (2) the fixpoint
    // C(C(S)) == C(S) re-confirmed with B8 in band, (3) the
    // non-VM backend works (the C transpilation backend —
    // corpus C replay 41/41 re-run, audit AA 274/274
    // maintained); the seven-piece skeleton takes its 2.6
    // write-back rows and the nine signals hold at 8/9 for
    // Stage 2a (the ninth — cross-stage deep verification — is
    // the 2.8 closer's); one formatting drift left by r91 in
    // test_infra_guard_tests.rs is repaid this round; tests
    // 1405:0:0 maintained, audit 274/274 maintained.
    //
    // Prior golden: v0.61.0 recorded at the Stage 2.6
    // first-cut release
    // (behavior change: workspace version bump — the 2.6
    // window opens with three adjudications landed: the build
    // orchestration stays on its Rust bootstrap footing (the
    // mission's ~20% Rust share, a Stage 3+ criterion — the
    // budget shape B7 x files + B8 x stages shows the VM exec
    // phase dominating at >98%, so a `.ktf` orchestrator gains
    // nothing semantically), the non-VM backend route is
    // adjudicated as C transpilation (zero external binary
    // dependency — text emission with the host cc, maximal
    // portability, the C-ABI face shared with criterion (4), out
    // of the bootstrap chain by constitution; QBE moves to a
    // Stage 3+ registration), and the FFI ownership model is
    // pre-adjudicated as four rules (eager materialization at
    // the boundary, caller ownership with return transfer,
    // explicit handle roots across calls, C-ABI alignment) —
    // unblocking criterion (4); the Stage 2 seven-piece skeleton
    // lands with the nine signals at 8/9 for Stage 2a; tests
    // 1369:0:0 maintained, audit 264/264 maintained.
    //
    // Prior golden: v0.59.0 recorded at the Stage 2.5
    // close-out release
    // (behavior change: workspace version bump — the
    // fixpoint window closes with its exit criteria verified in
    // full: §21.3 (1) [the whole compiler written in kerf — all
    // five selfhost pieces ride the complete .ktf chain, the
    // composed chain and fixpoint tests as the standing evidence]
    // and §21.3 (2) [C(C(S)) == C(S), re-proven by the fixpoint
    // test and pinned by the new B8 cost axis — the whole
    // three-phase proof measured, failing closed on every run;
    // the 2.6 build-orchestration evaluation consumes the number
    // as its bootstrap-verification budget floor]; tests
    // 1369:0:0 maintained, audit 264/264 maintained.
    //
    // Prior golden: v0.58.0 recorded at the Stage 2.5
    // first-knife release
    // (behavior change: workspace version bump — the
    // self-application fixed point: the compiler compiled by
    // itself, EXECUTED in the VM, reproduces its own compilation
    // byte-for-byte (C(C(S)) == C(S), SOP §21.3 exit criterion
    // (2)); the trailing-generation addendum threads the expansion
    // generation through the CP-1 record format (the 1.7 record
    // lineage — the flat stream records carry it trailing, the
    // assembler re-positions it last, the debug products land it
    // in the real spans while the dump text stays
    // generation-free); the rebuild face turns the `.ktf`
    // compiler's heap product into a real Bytecode (the opcode
    // kebab reverse table, verify-gated); the elevated gate B
    // sweeps the whole corpus structurally; tests 1369:0:0,
    // audit 264/264.
    //
    // Prior golden: v0.57.0 recorded at the Stage 2.4
    // closure-evaluation release
    // (behavior change: workspace version bump — the
    // closure round adjudicates the three 2.4 exit criteria: the
    // gate-B `.ktf`-side swap moves to 2.5 with its prerequisite
    // already witnessed (the dump-faithfulness nine probes), the
    // composed-chain cost axis lands as B7 (median 21.9ms over the
    // FIB anchor, fail-closed on `matched` — the self-hosting
    // multiplier 3081x vs B1's Rust pipeline is the Stage 2a
    // cost story's baseline number), and the drift-convergence
    // ledger (8/19/58) baselines into the calibration register;
    // 2.4 closes with the composed chain as its verification
    // face — 1358:0:0 maintained, audit 256/256 maintained.
    //
    // Prior golden: v0.56.0 recorded at the Stage 2.4 first-knife
    // release
    // (behavior change: workspace version bump — the full
    // composed chain: the 2.4 formula verifies as ONE chain with
    // the `.ktf` front end's OWN products feeding forward at every
    // junction (the junction re-encoder rebuilds the `.ktf`
    // reader's forms into the expansion layer's prefix, the `.ktf`
    // expander's items into the compiler's prefix — never the
    // oracle's intermediates); the routing is total — the drift
    // ledger pins every corpus file into exactly one row (8
    // reader-layer / 19 expander-layer / 58 compiler-layer, counts
    // test-pinned); the seventh self-application — lexer.ktf's own
    // source through the COMPLETE `.ktf` chain; all five selfhost
    // pieces through the chain; tamper probes at all three
    // junctions fail locally; the empty-product rows ride
    // `(quote nil)` stream prefixes; the gate-B promotion witness
    // proves the analysis-dump grammar a faithful image of the
    // Bytecode semantics (nine field probes — the 2.5
    // precondition); audit section Z growing to sixteen cases
    // (256/256) — 1358:0:0.
    //
    // Prior golden: v0.55.0 recorded at the Stage 1.5
    // second-segment release
    // (behavior change: workspace version bump — the
    // lexical layer of the reader lands in the frozen subset: the
    // byte-table injection generalizes the RS-1 channel with zero
    // freeze-surface change, `lexer.ktf` makes every lexical
    // decision (trivia, the Unicode whitespace table, the reject
    // set, atom classification, the i64 threshold guard, the f64
    // grammar automaton, the Symbol floor, escape validity), the
    // unchanged structure layer consumes its `tokens` binding, and
    // the harness checks the FULL .ktf chain on three axes (tokens
    // / tree / error) on both engines with the K20 float-value face
    // on the permanent host layer; the corpus sweep rides all 85
    // files through the chain; both own-source fixed points close
    // (the VM bracket face for the past-envelope cases, the
    // K165/K166 discipline); audit section R grows to twenty cases
    // (246/246) — 1343:0:0.
    //
    // Prior golden: v0.54.0 recorded at the Stage 2.3 close-out
    // release
    // (behavior change: workspace version bump — the 2.3 close-out
    // evaluation delivers the composed chain: the `.ktf` expander
    // feeding the `.ktf` compiler as ONE verification,
    // `compile(expand_oracle(S)) == compile_krf(expand_krf(S))`,
    // with the tree identity asserted in-chain through
    // `ModuleItem: PartialEq` (the 1.6 criterion) and the products
    // compared against the oracle full pipeline through the same
    // dump grammar; the CP9 five-test family (positive anchors, the
    // selfhost fixed points through the full chain — the sixth
    // self-application, compiler.ktf expanded by the `.ktf`
    // expander and compiled by the `.ktf` compiler — the LA-7
    // error axis, the 58-file compiler-layer corpus sweep, and the
    // front-end tamper probe); audit section Z mounting the six
    // composed-chain cases (236/236); the audit deep-stack guard
    // over the new toolchain's main-thread frames (the §9.84.1
    // lineage applied to the audit example itself) — 1321:0:0.
    //
    // Prior golden chain (kept verbatim below; see git history for
    // the full chain): 0.53.0 recorded at the Stage 2.3 second-Pass
    // release (the instruction emission rewritten in the frozen
    // subset: the single emit path with the opcode stack-effect
    // table, the jump backpatching discipline (the placeholder in
    // `a`, the source depth in `b`, both restored by patch — the
    // Lua patchlist lineage, K198), the explicit else-entry depth
    // reset, the tail-position terminator contract, the dense
    // per-instruction debug_info table (K201) and the finish-time
    // placeholder drain (K199) — compiler.ktf grows to 1221 lines
    // and the parity products now carry every proto's full
    // instruction stream and span table (K196/K203 the
    // translation-validation shape extended to the emitted code);
    // the emission defenses (stack-underflow / stack-imbalance /
    // unpatched-jump) rebuild through the oracle's own Display as
    // readable drift, bad-patch and bad-node classify as harness
    // defects; the fifth self-application (compiler.ktf compiles
    // its own tree — code sections byte-identical, both engines);
    // the thirteen-test CP8 emission family; audit section Y
    // mounting the ten emission cases (230/230); the stack-guard
    // recovery over the new sandbox's 8 MiB test-thread default
    // (the r74 BST-1 lineage applied to the runtime and audit
    // faces) — 1316:0:0.
    //
    // Prior golden chain (kept verbatim below; see git history for
    // the full chain): 0.52.0 recorded at the Stage 2.3
    // fixpoint-window opening release (the first Pass: the
    // lexical-domain analysis in compiler.ktf against the Rust
    // oracle on the analysis products, the fourth self-application,
    // audit X, 1303:0:0); 0.51.0 recorded at the Stage 2.2 close-out
    // release
    // (the first-cut
    // close-out verification round: gate B both axes re-run over the
    // full pipeline with the capture descriptors inside the Bytecode
    // equality (a capture-dense composite anchor), the subset-spec
    // capture chapter fully rewritten as the seven-clause semantic
    // face, the quantified ★1' resolution (the B6 closure-creation
    // axis debuts: 47.8ns at frame width 4 vs 47.7ns at width 100 —
    // flat, O(captured) not O(n_locals) — with 222.2ns at 25
    // captures, ~7.3ns each, linear; plus the deterministic guards:
    // a fifty-slot frame with one capture yields a one-slot env, and
    // an explicit §19.4 cycle sweeps exactly the seven uncaptured
    // pairs), B1-B5 reconciled all in band with B4's counters
    // bit-identical for the fifth consecutive run, audit section W
    // mounting the ten capture-family end-to-end cases (210/210),
    // and the three-MUV chain closing sub-stage 2.1 — 1286:0:0.
    //
    // Prior golden chain (kept verbatim below; see git history for
    // the full chain): 0.50.0 recorded at the Stage 2.1 semantic-flip
    // round (LA-1/LA-3/LA-4/LA-5 activate lexical capture on both
    // engines — the dormant full-frame clone retires; 1283:0:0);
    // 0.49.0 recorded at the Stage 2 entry round
    // (the user lift of the stage-2 implementation-entry restriction
    // takes effect on a ten-item all-green base, and the first
    // lexical-addressing MUV lands the flat-capture descriptor as a
    // zero-production intermediate state); 0.48.0 recorded at the
    // selfhost formatting
    // round (the three self-hosted .ktf sources and their two Rust
    // consumption faces get the user-named cleanup — every
    // parenthetical dash unifies to the em-dash (the ASCII
    // parenthetical dash is eradicated repo-wide), the 100-column
    // hard bound clears the six outliers (the 684- and 1697-column
    // define monsters re-emitted as 25 and 81 lines, four more
    // surgically split), selfhost/README.md lands as the entry
    // document, and the convention becomes machine-checked (a root
    // guard: width, the non-ASCII whitelist, the dash style —
    // 1261:0:0); whitespace-only by construction (comments are not
    // tokens; B4's swept-1023 counter stays bit-identical) —
    // stage0.md §9.79; prior goldens: 0.47.0 recorded at the
    // diagnostic message content-quality round, 0.46.0 recorded at
    // the typecheck inference-algorithm round, 0.45.0 recorded at
    // the oracle-encoding round,
    // 0.44.0 recorded at the bootstrap-bridge round, 0.43.0
    // recorded at the parity-machine round, 0.42.0 recorded at the
    // evaluator builtin-dispatch round, 0.41.0 recorded at the
    // syntax-tree/core-IR representation round, goldens: 0.39.0
    // recorded at the compiler lowering round, goldens: 0.38.0
    // recorded at the VM execution-core round, 0.37.0 recorded at
    // the checker work-state round, 0.36.0 recorded at the name
    // backend round, 0.35.0 recorded at the expander
    // lexical/transformer identity round, 0.34.0 recorded at the
    // expander error payload round, 0.33.0 recorded at the
    // module-system round, 0.32.0 recorded at the resource-limits
    // round, 0.31.0 recorded at the user-surface round, 0.30.0
    // recorded at the performance-engineering round, 0.29.0
    // recorded at the driver-orchestration round, 0.28.0 recorded
    // at the no-forwarding round, 0.27.0 recorded at the crate
    // boundary review round, 0.26.0 recorded at the
    // test-infrastructure self-audit round, 0.25.0 recorded at the
    // diagnostics-domain round, 0.24.0 recorded at the determinism
    // guard round, 0.23.0 recorded at the symbol interning round,
    // 0.22.0 recorded at the 1.9 stage-close, 0.21.0 recorded at
    // 1.8, 0.20.0 recorded at 1.7, 0.18.0 recorded at 1.5, 0.17.0
    // recorded at 1.4, 0.16.0 recorded at 1.3, 0.15.0 recorded at
    // 1.2, 0.14.0 recorded at 1.1, 0.13.0 recorded at 1.0, 0.12.0
    // recorded at the 0.11 stage-close; 0.64.0 recorded at the
    // switch-window step-2 round; 0.65.0 recorded at the
    // switch-window step-5 round — the two-skin corpus closeout; 0.67.0
    // recorded at the switch-window step-4 round — the target
    // fixpoint through the production bridge; 0.68.0 recorded at
    // the E5 batch-3 removal round — the .ktf composition chain
    // retire closeout; 0.68.0 re-asserted at the sandbox-10
    // recovery round with lockstep repaired — the chore-side bump
    // had left this expectation one version behind; 0.69.0 recorded
    // at the stage-2 final L3 closeout round — the ninth signal,
    // the FFI assessment-window ruling, and the Stage 2 GO gate; 0.70.0
    // recorded at the r106 full-pipeline audit round - the web-side
    // independent re-verification caught the expectation one version
    // behind for the second consecutive release (the r105 ds08 lesson
    // reiterated: run the six commands after every version-touching
    // edit, including pre-commit bumps); 0.71.0 recorded at the r107
    // Stage 3+ planning round — the stage-3-plan.md v1.0 window
    // system (10 windows + gate record), K113-K119 knowledge anchors,
    // and the pure-planning discipline (zero production-code change;
    // the only code face is a typecheck header-comment precision fix);
    // 0.72.0 recorded at the r108 inter-stage audit round — the
    // bootstrap-completeness special review (the W-3.12 frontend
    // self-hosting advancement window added to stage-3-plan v1.1),
    // the skin-aware runtime diagnostics (SKIN-DIAG ruling family),
    // and the K120-K123 frontend-bootstrap anchors; 0.73.0 recorded
    // at the r109 interlude audit round — the reader module split
    // (target.rs 2,757-line monolith -> the target/ submodule tree
    // mirroring the S-expression twin's token/lexer/parser layout),
    // the compile-time skin-aware diagnostics (subject sets across
    // expander/typecheck/compiler/module), the user-facing
    // unsupported-form message (plan vocabulary retired), and the
    // module-name dictionary consistency fix (use-form surfaces map
    // through the skin dictionary; the require call carrier rejects
    // fail-closed on the target skin); 0.74.0 recorded at the r110
    // environment-regression fix round — the toolchain-pairing
    // hygiene on the c_backend e2e process boundaries (the v0.73.0
    // Nix dev-shell incident: ambient contaminant variables paired
    // the emitted binary's dynamic loader with a store glibc and
    // every cc-built case died at load with exit 127 — the link and
    // load boundaries now scrub the contaminant sets, a loader
    // abort reports as the environment-pairing defect it is, the
    // stdin feed never masks a dead child behind a broken-pipe
    // panic, and the ambient incident replay joins scripts/testing).
    // 0.79.0 recorded at the r116 W-3.10 package-manager window — the
    // kerf-pkg crate (manifest/lockfile resolution, the build-bootstrap
    // layer) and the kp CLI joined the tree; the audit AI family took
    // the live set to 250.
    // 0.80.0 recorded at the r117 W-3.11 convergence-audit window —
    // the first-wave milestone audit (D1-D8 adapted deep review,
    // calibration T2.19, the registered-state re-check) plus the
    // E5-narrative residue cleanup in the parity family (the ktf_
    // identifier scheme and the four module heads).
    // 0.81.0 recorded at the r119 W-3.4 generational-GC evaluation
    // window — the lifetime portrait (gc_lifetime_profile example,
    // findings F1-F5), the D-CLASS-1 equivalence-class pinning with
    // the D-CLASS-2 pre-derivation registered, the keep-single-
    // generation adjudication, and the gc_window guard family (8).
    // 0.82.0 recorded at the r120 directive-absorption round — the
    // SOP v15.3 bootstrap-completion-first discipline (sop.md
    // §21.12 item 28: scheduling-priority adjudication, the dual-
    // chain decoupling, the completion standard, and the T-b purity
    // trigger activation) plus the stage0 §9.113 knowledge layer
    // (anchors K140-K142) and the window re-ordering that elevates
    // the W-3.12 segment-one implementation window.
    // 0.83.0 recorded at the r121 W-3.12 segment-one implementation
    // window — the injection channel productionized (the engines'
    // `inject_global` pair with the expander's injected-names
    // acceptance and the checker's externals extension), the
    // steady-state bootstrap chain (`bootstrap_chain.rs` — the
    // once-compiled twin program fed per source through the
    // channel), the corpus sweep through the steady route, and the
    // segment-one elevation re-adjudication under the dual-chain
    // decoupling criteria (audit family AJ, 250 -> 260 live).
    // 0.84.0 recorded at the r122 W-3.12 segment-two implementation
    // window — the bootstrap-file directory unification (the
    // `bootstrap/` module family plus the `target_skin.rs` split,
    // bit-identical 1491:0:3), the steady expander chain
    // (`steady_expander_chain.rs` — the forms record stream through
    // the one injection channel), the expander twin refresh (the
    // W-3.2 extern police's expressible faces: shape / ABI /
    // type vocabulary / canonical collisions / top-level-only plus
    // the extern item records and the dump/rebuild/error-rebuild
    // arms), the exposed-and-fixed items-prefix extern encoding
    // (the comma-split latent defect), and the segment-two
    // adjudication — machinery complete, elevation deferred to the
    // C-symbol expressivity decision (audit family AK, 260 -> 270
    // live).
    // 0.85.0 recorded at the r123 W-CSYM-EXPR capability
    // adjudication window — the three-way ruling (path b: the
    // C-domain predicate re-attribution — the extern floor is a
    // product constraint, not expander semantics), the
    // `extern_table_floor` single-source dual judge (compile's
    // whole-table police plus verify's hand-built product judge,
    // the derived-collision face NEW coverage at verify), the
    // `CompileError` extern family's three-way split with
    // name-bearing payloads, the corpus contract's `compile-error`
    // expectation kind (neg-062 reclassified), the steady sweep's
    // zero-disclosed-row retirement, and the segment-two
    // re-adjudication — ELEVATED, the bootstrap ladder's second
    // segment closed (audit family AL, 270 -> 280 live).
    // r124 (v0.86.0): the segment-three adjudication round — the
    // three-topic split ruling (build orchestration constitutional
    // exclusion + HM twin confirmation with the W-HM-TWIN window
    // registered) plus the junction-3 clearance (the emit fix +
    // `cp_extern_walk` + the externs parity section, the composed
    // ledger 3 -> 1, audit family AM 280 -> 290 live).
    // r126 (v0.87.0): the W-HM-TWIN window-opening round — the
    // bootstrap-ladder evolution planning landed as the user's
    // standing instruction 1 (the ladder panorama with the
    // segment-three carrier named `typecheck.ktf` + `infer.ktf`,
    // the knowledge layer K146-K149 with "Typing Haskell in
    // Haskell" as the canonical own-language typechecker
    // precedent, the twin-shape rulings TWIN-1..TWIN-5 reusing the
    // INJ-1 channel and the steady-chain form, and the 127-a..e
    // MUV schedule) — a pure planning round: zero production-code
    // change, only this version pin and the Cargo lockstep.
    // r127 (v0.88.0): the W-HM-TWIN 127-a delivery round — the
    // infer.ktf twin converged to the Rust oracle bit-for-bit on
    // the inference axis (the sweep family 5/5: the full corpus,
    // the HM negative family, the E0011 budget row, the
    // deterministic/injection row, the empty stream; the suite
    // 1511:0 = the 1506 baseline + the five new cases). The
    // thirteen-defect clearance includes the oracle-side P0
    // (Ctx::resolve's Arrow rebuild carried a spurious
    // params.reverse() — every multi-param arrow rebuilt through
    // links had its params silently crossed; the parity face
    // exposed what no golden had pinned). Segment three stays NOT
    // ELEVATED — 127-b/c/d/e remain.
    // r128 (v0.89.0): the W-HM-TWIN 127-b delivery round — the
    // typecheck.ktf twin converged to the Rust oracle bit-for-bit
    // on the check axis (the sweep family 6/6: the full corpus
    // with the pass-1 table face riding every row — the direct
    // INF-9 mirror guard — the rule-family probes R2-R8/LA7, the
    // R1 direct-construction probes, the 600-deep programmatic
    // row, the deterministic/injection row, the empty stream; the
    // suite 1520:0 = the 1511 baseline + the six sweep cases + the
    // three table_axes crate cases). The pass-1 parity face
    // (`table_axes` + the assigned-order list) renders the oracle
    // table deterministically for the twin's mirror guard; the
    // walk state rides the assigned globals (the W-machine
    // discipline — the monomorphic-recursion constraint made the
    // type-changing-argument shape an occurs check). Segment three
    // stays NOT ELEVATED — 127-c/d/e remain.
    // r129 (v0.90.0): the W-HM-TWIN 127-c delivery round — the
    // segment-three steady chains completed their remaining faces:
    // the RS-4 dual-engine drives on both chains (the once-compiled
    // program, the same injection, both engines' verdicts decoded),
    // the per-source text route for both twins (the RS-1 test
    // channel: the item stream as a program-text prefix, one
    // program, recompiled per case), the cross-route equivalence
    // (steady == per-source == oracle, one decoder), the parity
    // machine's three faces (the oracle_analysis_dump types tail,
    // the shared dump renderer's types arm, the structural rebuild
    // into real TypedExpr trees / schemas / effect rows /
    // TypeDiagnostic records with the fail-closed tamper face), and
    // the composed analysis (the compiler twin's dump plus the
    // inference twin's types section == the oracle's full-pipeline
    // dump). The suite 1526:0 = the 1520 baseline + the six new
    // chain-face cases. The eval-face ledger grows by three
    // classified consumers (the bucket pin C12/39). Segment three
    // stays NOT ELEVATED — 127-d/e remain.
    // r130 (v0.91.0): the W-HM-TWIN 127-d delivery round — the test
    // face: the paired positive/negative probes on both judgment
    // faces (one probe set, both oracles — the 127-a/b rounds' probes
    // were face-specific, this round pins the pairing), the corpus
    // HM-axis reclassification pinned exactly (reader 8 /
    // expansion 19 / inference-diagnostics 6 by name / clean 58;
    // check-diagnostics 10 by name / clean 54 — the sweeps rode lower
    // bounds, this pin turns any corpus change that shifts either
    // axis into a visible break), and the budget row's E0011 face
    // through the per-source route (the 127-a budget row rode the
    // steady route alone). The suite 1530:0 = the 1526 baseline +
    // the four new face cases; the audit grows the AN family of ten
    // (300/300 live, 39 sections); the eval-face ledger grows by one
    // classified consumer (the bucket pin C13/40). Segment three
    // stays NOT ELEVATED — 127-e remains.
    // r131 (v0.92.0): the W-HM-TWIN 127-e delivery round — the
    // window closes: the segment-three elevation re-adjudication
    // passes all three criteria (SOP v15.3 §21.12-28(2) — the
    // 4,924-line pure-kerf twin fully carries the checker's whole
    // semantics with both sweep axes bit-exact; the steady chains
    // run through the segment with the cross-route equivalence and
    // the exact corpus reclassification pins; the parity gates stay
    // green at audit 300/300 and the six commands 1530:0:4), so the
    // HM judgment face is ELEVATED and the BS-A frontend ladder
    // converges — read (r121) + expand (r123) + HM (r131) elevated,
    // the compiler twin in place, build orchestration
    // constitutionally excluded. The W-BOOT-FRONTEND ledger closes
    // in full; the T-a production-slot switch stays a separate
    // follow-up window (the W-3.7 JIT/superinstruction window is the
    // next entry). This round is a pure documentation round — the
    // version pin below is the only behavioral delta.
    // r132 (v0.93.0): the W-3.7 JIT/superinstruction evaluation
    // round — the window closes with the implementation window
    // OPENED. The dispatch portrait (the new vm_dispatch_profile
    // example riding the W-3.7 observer seam) measures the
    // interpreter overhead share at 72.5% (the B9c cross-check),
    // the uniform per-instruction cost, the 79.3-100.0% fusable
    // coverage, and load-global+call as the universal top pair;
    // F1 pins the arithmetic opcodes dynamically cold. EXC-10 fires
    // in strengthened form: W-VM-SUPERINSTR opens as the
    // implementation window (static single-phase fusion + the F1
    // orthogonal slice, both r133+), W-JIT-METHOD-T1 registers, and
    // cranelift is rejected inside the base. K150-K156 join the
    // knowledge layer; jit_window_tests (2 positive / 6 negative)
    // pins the census exactness and the seam's inertness; the suite
    // grows 1530 -> 1538:0:4, the audit holds at 300/300, and B4
    // stays bit-exact (the twenty-third consecutive run).
    // r133 (v0.94.0): the W-VM-SUPERINSTR first blade — the fused
    // call-global lands end to end. The opcode set grows 25 -> 26
    // (SI-2, the "about 35" capability budget holds): a global
    // callee compiles to one call-global at the emission site
    // (SI-1), the operand layout follows the Perform convention (a
    // = global index, b = argc), and the stack contract keeps only
    // the args on the stack (SI-3: pops argc, pushes 1 — the callee
    // rides the slot, never the stack). The verify/depth/C-emitter
    // faces ride the single-source tables; the .ktf twin's acall
    // arm mirrors the fusion (gate B bit-exact, the fixpoint holds
    // — self-compilation reproduces itself through the fused
    // emission); the guard families regenerate against the fused
    // form (census anchor 12 -> 10 instructions, the pair pins, the
    // snapshot seeds, the golden counts) and a new
    // superinstr_window_tests family (2 positive / 6 negative)
    // pins the fused/unfused agreement, the corpus-wide fusion
    // completeness, the verify boundary, the error-family
    // migrations, and the twin fusion-arm tamper. The audit grows
    // an AO section (300 -> 310 live, 40 sections). The B-axis
    // re-measurement: fib-25 2,427,852 instructions (the -25.9%
    // the portrait predicted, bit-for-bit), median ~71.0ms against
    // the 82.0ms seam reference (0.87x — the first blade alone does
    // not reach the 0.7x band; the r134 F1 blade plus the
    // second-pair candidates close it, the honest mid-window
    // ledger). B4 stays bit-exact (the twenty-fourth consecutive
    // run).
    // r134 (v0.95.0): the W-VM-SUPERINSTR second blade — the F1
    // direct-arithmetic arm lands end to end and the window
    // closes. An unpoisoned two-argument arithmetic site
    // direct-emits its Add/Sub/Mul/Div opcode (FA-2 — the four arms
    // were in the tree since Stage 0; the blade adds the emission
    // path, not the opcodes): the builtin dispatch and the opcode
    // arm share the single `arith` source (FA-3's constructive
    // equivalence), the program-wide poison scan (FA-1 — a module
    // define, an extern entry, or any assign on the name forces the
    // fused-call fallback) rides the twin's assemble pass (FA-5 —
    // the linear stream walk would blow the eval depth budget on
    // the fixpoint's own source), and a direct-only reference never
    // interns (FA-4 — the globals table carries no slot for a name
    // no instruction reads). The guard families regenerate again
    // (the F1 cold-era alarm reversed into the direct-emission
    // liveness pin, the census anchor carries the direct mul arm,
    // the snapshot seeds and golden counts re-pin the new
    // instruction streams) and a new F1 family inside
    // superinstr_window_tests (2 positive / 6 negative) pins the
    // direct-vs-poisoned agreement, the local-shadow granularity,
    // the poison tri-source, the fallback family, and the twin F1
    // arm's gate-B load. The audit grows an AP section (310 -> 320
    // live, 41 sections). The B-axis re-measurement: fib-25 stays
    // r134 close: 2,427,852 instructions, median 61.544/61.815/
    // 61.963ms = 0.75x against the 82.0ms seam reference (two
    // blades -25.0%; the honest 4.1ms ledger gap carried the
    // third-lever handoff). r135 (TJ-1): the copy-pair blade
    // consumes the third lever inside W-JIT-METHOD-T1 — the
    // re-profiled numbers land in tool-results/r135-*. B4 stays
    // bit-exact (the twenty-sixth consecutive run).
    // r186 (v0.135.0): the recovery-and-open round — the r185 P1
    // deferred long families fully cleared fresh (66/66 green:
    // steady_route 7/7 + fixpoint 17 + abc_pipeline 6/6 + doc),
    // and the effect-family chain's middle segment opens
    // (W-EFFECT-MECHANISM — one-shot resumption semantics +
    // effect-row inference consumption, w-effect-mechanism-window
    // v1.0).
    // r187 (v0.136.0): the W-EFFECT-MECHANISM blade 1 — the
    // value-layer/VM one-shot deepening delivered (the continuation
    // as the class-2 family's new member, the ext2 one-shot mark,
    // the k-form arity convention, the `return` clause routing, the
    // +1 pop-handler sentinel; the degenerate form bit-stable and
    // the 6:18 golden pinned).
    // r188 (v0.137.0): the W-EFFECT-MECHANISM blade 2 — the
    // effect-row inference consumption delivered (the arrow-carried
    // row as the fn type's fourth slot, the covering-clause perform
    // typing with the degenerate param unification and the k-form
    // resume recovery, the handle's typed-row coverage and the
    // halt/body ret unification, the row extension with the
    // Koka-coherence op type, the schema-vars generalization face;
    // the frozen oracle untouched — the r174 third blade, the
    // twin-beyond-oracle lanes carry the three effect-typing corpus
    // rows and the 25-case golden pins the faces).
    // r189 (v0.138.0): the W-EFFECT-MECHANISM blade 3 — the corpus,
    // audit, and close-out face (the corpus-effect/ family of 28
    // cases with the four-verdict sweep riding the rw-type wiring,
    // the audit's Section BH of 10 at 480/480 live, the r185-r188
    // guard-map blind spot repaired in the same path, and the
    // segment-3 six-instance interface freeze; the window CLOSED
    // with the six exit criteria checked — zero production files
    // touched this blade, the frozen oracle untouched by
    // construction).
    // r194 (v0.139.0): the W-EFFECT-INSTANCES blade 3 + window
    // CLOSED — the Async strategy face and the effect-family chain
    // fully closed (selfhost/std/async.ktf's with_async synchronous
    // pass-through degenerate handler on the §5.4 honest boundary;
    // the re-entrant routing ruling pinned by probes then deleted;
    // the ef-async-* family of 8 at the 40-case 10:30 corpus, the
    // five-family sweep with the six-library prefix, the mechanism
    // sweep's exclusion filter extended with ef-async-; the audit's
    // Section BK of 10 at 512/512 live; the gold-chain bump on the
    // chain-closing milestone, the r189 window-CLOSED precedent —
    // blades 1-2 had stayed flat as vocabulary-pack rounds).
    // r196 (v0.140.0): the W-SELFHOST-MODERN-2 blade 1 — the
    // effect-family chain surface consumption lands in the pkg-logic
    // twins (semver.ktf + micro-toml.ktf rewritten onto the Error
    // vocabulary — the internal walkers take the one-shot raise path
    // with the original records as payloads, the public parse faces
    // keep their frozen ok/err contracts through the attempt wrapper
    // — and micro-toml's open frame rides row literals and closed
    // row patterns, the runtime value the identical cons chain; the
    // five pkg parity families switched to the single-vm drive, the
    // eval axis retired for them per the window §9 M16 ruling with
    // the probe forensics; the std error-lib prefix rides every
    // assembly embedding the two twins; the parity sweeps green
    // byte-for-byte against the untouched oracle).
    // r197 (v0.141.0): the W-SELFHOST-MODERN-2 blade 2 — the
    // composed-program trio (manifest.ktf + lockfile.ktf +
    // resolve.ktf) consumes the Error vocabulary: the 33 err-threading
    // sites all take the one-shot raise path with the original
    // records as payloads, the ("ok" ...) threading cascades dissolve
    // into direct lets (the resolver's phase-crossing self-recursion
    // binds the returned ctx directly — the P11-proven form), the
    // three public faces keep their frozen contracts through the
    // attempt wrapper, and lockfile's field slots ride the row
    // vocabulary (the bare row literal out of lk_field, the closed
    // row pattern in the walk — RW-13's value right fold); the C5
    // State-generation evaluation for resolve closed no-consumption
    // (the explicit ctx threading is the natural form); the probe
    // forensics P11-P13 pinned four language-face facts on the way
    // (the number-only `==`, the match arm trailing comma, the E0009
    // nested literal head, the flat cons-chain payloads); zero
    // harness changes — the blade-1 assembly already covers the five
    // pkg families; the parity sweeps green byte-for-byte against
    // the untouched oracle.)
    // r198 (v0.142.0): the W-SELFHOST-MODERN-2 blade 3 — the
    // judgment/lexer pair consumes the Error vocabulary: the whole
    // lexical rejection family (the three error constructors with
    // their 28 call sites unchanged — the construction IS the
    // short-circuit — plus the trivia scanner's unclosed-delim arm)
    // takes the one-shot raise with the CONTRACT error record as the
    // payload, the two check sites in tl_start dissolve, the
    // top-level verdict rides the attempt wrapper; the success
    // frames drop their dead discriminant heads and destructure
    // through nested pair patterns (the Rust-reader boundary: the
    // chain built-ins parse through the frozen reader, which
    // predates the row vocabulary — the blade's honest boundary
    // M49); the typecheck twin's boundary-2 survey holds (the walk
    // never short-circuits — zero Error-vocabulary sites, the
    // accumulation architecture keeps its shape) with the extern
    // table's entries and the let stack's frames riding bare value
    // chains; and the first-ever handle-carrying chain source
    // surfaced two latent twinsurface defects, both closed in-round:
    // the compiler twin's handle emit pre-interned the return
    // clause's effect name ahead of the clause walk (every clause
    // effect's global slot shifted — the B-vs-C gate caught it the
    // moment ccf-lexer carried a handle; the fix aligns the twin
    // with the oracle's in-loop form), and the infer differential
    // collided with the r188 typed-perform pin (the twin's LIVE
    // effect typing vs the frozen oracle's dyn — the registered
    // divergence now rides structural anchors, TD-032 closes it at
    // blade 6); the std error-lib prefix rides every lexer assembly
    // (the twin dump, the abc CCFs, the steady read chain, the
    // determinism guard), the twin dump and parity comparison
    // retired the eval axis for the lexer family, and the steady
    // read chain's lexer layer went vm-only with the single-source
    // bridged token table feeding both parser engines; the parity
    // sweeps green byte-for-byte against the untouched oracle.)
    // r200 (v0.143.0): the W-SELFHOST-MODERN-2 blade 4 (the harvest
    // recovery round): the compile/macro pair takes the Error
    // vocabulary — the whole compile-rejection family (the extern
    // duplicate, the emit underflow, the patch imbalance and
    // bad-patch, the depth guard, the assign-to-captured, the
    // bad-node fallthrough, the unpatched-jump drain) rides the
    // one-shot raise with the CONTRACT error record as the payload,
    // the first-error cell and the seven post-error guards retire,
    // the estate and proto records drop their dead discriminant
    // heads (the product render rebuilds the proto head — the
    // external record shape stays frozen), and cp_run rides the
    // attempt wrapper with the result define byte-frozen (the
    // fixpoint's structural anchor survives); the macro twin's
    // adjudication: zero consumption (the shadow-pair contract face
    // belongs to blade 5's co-modernization, the live-tag census
    // finds zero label-key navigation); the harness co-variation
    // carries the std error-lib prefix into every compiler assembly
    // (the rich drive, the steady production chain, the fixpoint's
    // three forms, the abc ccf-compiler, the test's inline
    // structural), retires the rich drive's eval axis with the
    // twin's Error-vocabulary consumption (the M16/M46 policy line),
    // and retires six files from the eval-inventory ledger (C 13→9,
    // E 17→15, the pin 39→33); the superinstr and audit tamper
    // anchors re-anchor at the walker's post-dedent column (the
    // in-round catch: the audit's AO10 copy needed the same
    // co-variation the T1 face took); TD-032's registered-divergence
    // set extends to ccf-compiler; the K159 fixpoint gate rides a
    // double-fork daemon past the sandbox's descendant reaping (the
    // single case now beyond the tool-call window — the escape form
    // registered).)
    // r201 (v0.144.0): the W-SELFHOST-MODERN-2 blade 5 (the largest
    // twin + the shadow pair in one surgery): the expander's whole
    // expansion-rejection family rides `perform raise` through the
    // ex_fail helper — the single construction site changes its
    // body, the 113 call sites stay text-for-text (the inverse of
    // blade 3's lexer form); the 44 dead-nil arms and the one
    // continuation dissolve, the 39 post-error walk guards take an
    // iterative leaf-first dissolve (the ex_expand entry guard alone
    // spans ~1,950 lines with 27 inner guards), the six
    // between-helpers split their two shapes, the error cell retires,
    // and ex_run rides unwrap(attempt(thunk), identity) with the
    // seeds machine-checked pure outside the thunk and the result
    // define byte-frozen; the macro twin's ex_fail takes the
    // identical raise body (the shadow pair co-modernized — the
    // MX-2 assembly order stays order-insensitive), its one dead-nil
    // and one guard dissolve, the ex_err cell retires in both files;
    // the C1 evaluation closes zero-consumption (the Rust-reader
    // boundary, the live-tag census finding zero dead heads, the
    // internal forms already bare pairs); the harness co-variation
    // carries the std error-lib prefix into both expander assemblies
    // (the corpus single point and the abc ccf-expander source —
    // the third handle-carrying chain source, its infer differential
    // joining the TD-032 registered set), retires the steady chain's
    // eval axis (the ledger C 9→8, pin 33→32) with the composed
    // chain's expand layer and the audit's AK06 site; the gates all
    // fresh — the four segment switches 39/39, fixpoint B≡C
    // bit-level, T0/T1, and T2 70/70 with the abc family at 625s on
    // the double-fork daemon (the r200 escape form's first reprise);
    // the honest performance account discloses the abc +11% as the
    // prefix's real compile-leg load, not a regression.)
    // r203 (v0.145.0): the W-SELFHOST-MODERN-2 blade 6 + close: the
    // parser twin's whole parse-rejection family rides `perform
    // raise` through the three tp_err_* helpers (nine construction
    // sites, the 50 call sites unchanged), the 100 post-error guards
    // dissolve, the entry rides unwrap(attempt(thunk), identity)
    // with the result define byte-frozen, and the give protocol's
    // dead "done" head retires (21 constructions drop the
    // never-dispatched discriminant; tp_finish reads first); infer
    // stays at 5,532 — three closure rulings (the boundary-②
    // accumulation census, the C1 three-grounds closure, the C4
    // API-face adjudication); TD-032 closes as the
    // differential-semantics upgrade — the r198/r200/r201 matches!
    // exemption revokes, the carrying sources' expectations pin as
    // byte-exact goldens (the four fixtures, regenerated only
    // through the deliberately-ignored regen test), the structural
    // anchors stay applied against the oracle, and AZ08 rides the
    // central classifier; the C4 pins ei08/ei09 land the Error
    // instance's owed annotation faces; the harness co-variation
    // carries the std prefix into the three parser assemblies (the
    // abc ccf-parser the fourth handle-carrying chain source),
    // retires the steady read chain's parser-layer eval axis (the
    // ledger C 8→7, pin 32→31); the window's exit criteria all pass
    // — W-SELFHOST-MODERN-2 closes with this round, the 12/12 twin
    // consumption terminal.)
    // r206 (W-SELFHOST-ORCH blade 1): the import surface — the
    // composition layer's own language face (the `import` keyword,
    // the composer, the unit registry) joins the gold chain.
    // r207 (W-SELFHOST-ORCH blade 2): the serialization face — the
    // render-line library global (the registry's 19th row, the io.rs
    // "later library concern" line arriving as the library face OVER
    // the §8.8 channel) + the std/render.ktf seventh pack + the four
    // twin registries' covariant rows (the ex_globals shadow pair,
    // tc_builtin_arity, ti_is_builtin — the ccf-expander golden
    // regenerated) + the render_vocab census golden (the emitted
    // lines double-pinned against the host display, digit-by-digit)
    // + the audit's Section BL of 10 at 522 live + the C backend's
    // KB_RENDERLINE mirror arm; the skin channel rides Rule K (the
    // explicit table gains no row).
    // r216/r217/r218 (W-LINEAR-TYPES blades 1-3): the qualified-type
    // kernel + the use-count checker face (the Wadler per-path range
    // cardinality, E0014/E0015 through the disclosed decode-registry
    // extension) + the [lin] T annotation skin + the corpus-qual
    // sweep — the Phase β chain-first window; the audit's Section BM
    // of 10 at 532 live; zero value-layer primitives, zero builtins,
    // zero channels, zero VM, zero opcodes, zero keyword-table rows
    // (the 165th-167th constructive rounds); the window CLOSED at
    // r218 with the six exit criteria.
    assert_eq!(kerf::WORKSPACE_VERSION, "0.153.0");
    // r151 (v0.112.0): the W-SEXP-RETIRE blade 2 — the S-expression
    // reader left the tree (kerf-reader is the target reader alone;
    // the S-expr lexer/parser twins, the S-expr steady read chain, the
    // composed S-expr chains and the skin transcoder retired with
    // it; every parse is the target skin now — the single-skin
    // state this suite's fixtures ride).
    // r154 (v0.113.0): the W-SEXP-RETIRE blade 3 — the lexical
    // surface closed (the legacy corpus extension token retired from
    // every code surface, the zero guard TEST-5 holds it) and the
    // twin expander's frames carry (name, generation) entries
    // (TD-028 closed — the J03 hygiene judgment rides the production
    // arm again).
    // r156 (v0.114.0): the W-PKG-SELFHOST blade 1 — the micro-TOML
    // twin joins selfhost (the ninth twin, the first of the pkg
    // self-hosting family); the parity harness rides the RS-1 byte
    // table and the RS-5 first_diff sharing (the lexer harness's
    // private helper converged), kerf-pkg widens its selective
    // re-export by the parser itself.
    // r157 (v0.115.0): the W-PKG-SELFHOST blade 2 — the semver twin
    // and the composed manifest twin join (the tenth and eleventh
    // twins; the first three-twin composition rides the
    // macro+expander assembly precedent); TD-030 registers the
    // inline nested-cons collapse (the manifest twin's let-bound
    // construction avoids the defective inline form).
    // r158 (v0.116.0): the W-PKG-SELFHOST blade 3, part one — the
    // lockfile twin joins (the model and deterministic serializer,
    // the roundtrip + render faces over the composed mt/semver
    // assembly); TD-030 closes as a misdiagnosis (the registered
    // "collapse" was the correct cons tail-splice semantics
    // misread — the assessment record rides
    // tool-results/r158/td030-assessment.md).
    // r159 (v0.117.0): the W-PKG-SELFHOST blade 3, part two — the
    // resolver twin joins (the five-piece composed program, the
    // family's first) and the kp shell wires the
    // KERF_PKG_SELFHOST three-state band (twin production seat;
    // the e2e dual arms + the red-green fallback verification).
    // r160 (v0.118.0): the W-PKG-SELFHOST blade 4 — the corpus
    // regression completes the window's named cases on both seats
    // (the corpus face caught the conflict twin reporting only the
    // tail of the imposed list on a mid-list violation — fixed to
    // the oracle's whole-list ruling and pinned as the
    // conflict-mid-list parity case); the Rust logic arm retires
    // into the build-guidance rollback band and the window CLOSES
    // (G5 closed — the bootstrap matrix turns to G6).
    // r162 (v0.119.0): the W-EVAL-RETIRE blade 1 — the user surface
    // retires from the eval face (the `--engine`/`--parity` flags
    // reject loudly, the --skin precedent form; the REPL rides the
    // VM engine unconditionally) and the guard re-pins B1/40 — the
    // window CLOSES (G6 closed — the bootstrap matrix turns to G8
    // and the bootstrap-completion acceptance).
    // r163 (v0.120.0): the bootstrap-completion acceptance — the
    // C1-C4 criteria re-verified live on the accepting baseline
    // (the K159 fixpoint gate 8/8 on release, the segment switch
    // families, the corpus sweep 112/112, the audit 460 live) and
    // the deep review GOes: the matrix G1-G7 all closed, W-LANG-
    // FOUNDATION (G8) is the first post-acceptance agenda.
    // r165 (v0.121.0): the W-LANG-FOUNDATION blade 1 — the type
    // annotation consumption face whole: the read chain builds the
    // spec records (b1+b2), the expander emits the dann sites on
    // both arms (b3), the HM engine consumes them (b4 — the
    // resolve table, the param anchoring, the ret/let E0013, the
    // annotation-demanded E0009 exception), and the corpus carries
    // the sixteen annotation rows (b5) — annotations are checked,
    // not decorative.
    // r166 (v0.122.0): the W-LANG-FOUNDATION blade 2 — the struct
    // surface and its desugaring whole: the read chain parses the
    // struct declaration face (b1), the expander lowers it into
    // constructor/accessor defines with generated danns plus the
    // zero-code dstruct item (b2), the HM engine carries the
    // Struct(name, fields) nominal type with transparent unfolding
    // (b3 — the cycle-checked resolve stack, the five unify arms,
    // the scalar guard clearing the r127-born first(b) crash face),
    // and the corpus carries the thirteen struct rows (b4) — a
    // struct is a derived surface over the cons right-fold, never
    // a new primitive.
    // r167 (v0.123.0): the W-TEST-FLOW delivery — the tiered test
    // engine: the family tier table (T0 smoke / T1 round / T2 full)
    // with the chunked-foreground batch runner (per-family ledger,
    // fit-aware packing, intra-family sharding for families above
    // the tool-call window), the three tier guards pinning the slow
    // self-application faces at T2, and the chunked+resumable full
    // gate crossing five tool-call windows without a single session
    // kill — tiering changes when tests run, never what must pass.
    // r168 (v0.124.0): the W-LANG-FOUNDATION blade 3 — the enum
    // surface: the tag-only variant pattern boundary (a bare symbol
    // naming a zero-payload variant discriminates the tag, it is
    // never an irrefutable binding), the GZ-4 expand-time
    // exhaustiveness with the coverage-set walk, the Type::Enum
    // nominal-closed carrier with the tag bare face (car of the
    // cons chain is the declared index), and the sixteen-row corpus
    // family at 1:3 — an enum is a derived surface over
    // cons(tag, right-fold), never a new primitive.
    // r170 (v0.125.0): the W-LANG-FOUNDATION blade 4 — the struct
    // pattern family closure: the dual-lookup disambiguation (the
    // enum table first, the struct table second, a miss keeps the
    // six pattern families), the zero-shift field positions
    // car(cdr^k s) (the variant's +1 tag shift's absence IS the
    // struct/enum representation split), the zero-field face as
    // (nil? s), the three-way irrefutable walk (a bare zero-field
    // struct name passes the name walk yet compiles a failable
    // nil? test), the read-side relocation (an n-ary tuple pattern
    // READS — the head-NAME ruling replaced the shape ruling), and
    // the sixteen-row corpus family at 1:3 with the GZ-5 row-
    // polymorphism evaluation archive — a struct pattern is a
    // derived surface over the existing pair algebra, never a new
    // primitive.
    // r175 (v0.126.0): the W-SELFHOST-MODERN blade 1 — the
    // selfhost twins begin consuming the G8 surface themselves
    // (rustc's MSRV-of-itself / Go 1.5 toolchain modernization
    // family): semver.ktf and micro-toml.ktf rewritten onto struct
    // declarations (Version/Constraint/Span/Pos — the constructor
    // IS the cons right fold), match dispatch (pair patterns with
    // literal heads, int-literal byte arms, the `_` domain-
    // totality fallback), and scalar annotations (list-typed
    // parameters stay bare — the honest degradation), with the
    // representation byte-identical by construction (the mapping
    // table w-selfhost-modern-window §9, M1-M12); the parity
    // families and the composed manifest/lockfile/resolve drives
    // pass unchanged — the refactor's correctness is the sweep
    // itself, the oracle frozen at v0.125.0's language face.
    // r176 (v0.127.0): the W-SELFHOST-MODERN blade 2 — the
    // composed-program family follows: manifest.ktf, lockfile.ktf
    // and resolve.ktf rewritten onto the same surface with the
    // blade-2 extension (the mapping table §10, M13-M20): struct
    // declarations with STRUCT-TYPED fields (Slot/Dep — the
    // first twin consumer of the nested struct-table resolve
    // face), the family-wide Span/Pos/Version/Constraint
    // vocabulary shared across the five-piece composition, the
    // key-matcher int-literal constant tables, the record-tag
    // literal-head dispatch with wildcard tails, the syntax
    // pass-through cons identity, and the phase/color/status
    // discriminants on match arms with the top-level nil pattern;
    // the kp shell's twin arm, fallback band and both-arms corpus
    // pass unchanged — representation-identical, the oracle
    // untouched.
    // r177 (v0.128.0): the W-SELFHOST-MODERN blade 3 — the
    // judgment face and the lexical face: typecheck.ktf and
    // target-lexer.ktf rewritten onto the same surface (the
    // mapping table §11, M21-M30): the scalar tag tables on the
    // tag string (child counts, builtin arities, litval
    // conversion, shapes), the walk-mode machines with the
    // closing wildcard arm, the record assembly and collection
    // dispatch, the R1-R8 walk's tag arms with the do/set
    // mutation sequences untouched, the callee-analysis pair
    // patterns (the is_pair guard internalized in the pattern
    // test chain), the operator maximal-munch table on
    // int-literal arms with nested second/third-byte matches, and
    // the i64/str/bool annotation family (the monomorphic-
    // recursion uniformity the check face's own header
    // documents); the hm twin face, the target-lexer parity with
    // its selfhost fixed points (the twin lexing its own
    // rewritten source — the self-application closure), and the
    // wiring seeds pass unchanged — representation-identical,
    // the oracle untouched.
    // r178 (v0.129.0): the W-SELFHOST-MODERN blade 4 — the
    // compile face and the macro face: compiler.ktf and
    // macro.ktf rewritten onto the same surface (the mapping
    // table §12, M31-M40): the two-pass dispatch on match arms
    // (the child-count and assemble tag tables, the opcode
    // stack-effect tables, the emitter walker's synthetic-mode
    // and real-tree tag tables — the fixpoint carrier reading
    // itself through the new surface), the drain scan's jump
    // dispatch, the macro-face pattern compiler and matcher mode
    // machines with the matcher's pattern family, the
    // instantiation mode, the binder head names, and the scalar
    // annotation family (index/count/slot i64, name/opcode str,
    // the walker's tail flag bool — mixed-return faces stay
    // honestly bare); the shadowed helper copies that
    // expander.ktf re-defines stay untouched (the
    // identical-bodies discipline — blade 5 co-modernizes);
    // compile_segment_switch 11/11 (the selfhost fixed points on
    // the default stack included), the three-phase fixpoint
    // 17/17 (B≡C bit-identical), expand_segment_switch 9/9 and
    // the steady expander chain 9/9 pass — representation-
    // identical, the oracle untouched (the fourth freeze
    // exercise).
    // r182 (v0.132.0): the W-ROW-POLY blade 1 — the row type's
    // type-layer kernel lands in the selfhosted infer twin (the
    // r174 frozen-oracle ruling's FIRST consumer: the twin grows
    // rows, the Rust oracle never does): the ("row" fields tail)
    // representation (zero-field shell kept), the row spec's
    // resolve modes ("row"/"row-fields"/"row-field" — the tail
    // nil-closes/_-opens/anything-else-degrades table, duplicate
    // labels degrading whole), the scoped-labels unification
    // machine (the whole-list label extraction with the
    // rest(hit) dotted-pair remainder, the open-tail extension
    // binding rho := (l fresh | rho'), both lacks directions at
    // the remainder level, the tail-variable binding with the
    // empty-fields pass-through), the four walk machines' row arms
    // + row-fields modes (fields first, tail after), the Display
    // face's row arm in the harness decoder; the golden corpus
    // (24 pinned cases, 6:18 = 1:3), the per-source payload
    // completion (dann/struct/enum riding their full payloads —
    // the position-only form was the compiler twin's zero-code
    // view), and the frozen-oracle exemption face pinned.
    // r180 (v0.131.0): the W-SELFHOST-MODERN blade 6 — the
    // closing pair: infer.ktf (4,471→4,512) and target-parser.ktf
    // (4,402→4,424) rewritten onto the same surface (the mapping
    // table w-selfhost-modern-window §14, M49-M65): the W machine's
    // unify step on match arms (the string-domain arms plus the
    // `_` arm carrying the var guards and the record-tag nested
    // match — the not(is_pair(b)) crash-face guard folded into the
    // pair/fn arms, the GZ-2/GZ-3/GZ-4 comments verbatim), the
    // resolve/occurs/annotation walk machines (one/params modes),
    // the spec resolver's eight-mode table, the task machine's
    // enter/dispatch heads, the name tables (builtin membership,
    // the ad-hoc dispatch), the tarjan roots/loop dispatcher; the
    // parser's frame machine (33 states plus the give cascade's 29
    // arms and the machine-drop `_`), the guarded phase machines
    // (the is_nil(phase) fresh-state family — the guard stays, the
    // phase arms match inside the else), the phase/step families,
    // the token/datum tables (kind_name, datum_word, is_word,
    // datum_op, is_datum_op, cmp_kind), the tp_bin_ops int-literal
    // level table, the datum step's kind dispatch with the
    // is_word/is_datum_op predicate cascade in the `_` arm, the
    // leave guard's sixteen arms; the annotation families (~76
    // infer sites, ~29 parser sites — the first-pass mislabels the
    // checker caught: tp_ha/tp_ma nil placeholders and the
    // ti_member/ti_row_push mixed name/position domains, honestly
    // bare); the full parity sweep + fixpoint 17/17 (B≡C
    // bit-identical) + T2 63/63 with audit 460/460 live —
    // representation-identical, the oracle untouched (the fifth
    // freeze exercise, git diff crates/ zero).
    // r179 (v0.130.0): the W-SELFHOST-MODERN blade 5 — the
    // largest piece: expander.ktf (4,740→4,850) rewritten onto
    // the same surface (the mapping table §13, M41-M48): the
    // expander's synthetic-mode machine on match arms (nine
    // modes, the `_` arm carrying the depth guard and the real
    // tree verbatim), the expression-head dispatch (ten special
    // forms, the macro/application fallback), the declaration
    // heads (eight forms), the loader's require/module edge
    // dispatch, the extern type-tag table, and the annotation
    // family (~41 sites: spans str, gens/indices i64, predicates
    // bool — the dual-shape name faces honestly bare); the
    // shadow family co-modernized in both copies (22 shared
    // names, ex_gen's dispatch on match arms, the identical-
    // bodies discipline machine-checked); the T2 audit face
    // surfaced two r178 needle misses (the audit's own AO10/
    // AP09 tamper anchors still pinned the pre-match source
    // forms — covariantly updated here, the tests-tree
    // precedent); T2 63/63 with the audit 460/460 live —
    // representation-identical, the oracle untouched (the
    // fifth freeze exercise).
}

#[test]
fn ds09_output_lines_keep_submission_order() {
    let mut session = Session::new();
    let src = "define(r, write_line(\"a\")); define(r2, write_line(\"b\"));";
    let outcome = run_source(&mut session, "p.ktf", src, Engine::Vm, &[]).expect("run");
    assert_eq!(outcome.outputs.join(" | "), "a | b");
    assert_eq!(outcome.value_display(), "nil");
}

#[test]
fn ds10_two_diagnostics_render_with_summary_line() {
    // Two broken files in one session: errors are data — collected
    // across runs, rendered together, closed by the summary line.
    // The r151 target-skin twin: an unclosed BLOCK (the read face)
    // and an unbound identifier (the expand face).
    let mut session = Session::new();
    let mut all = Vec::new();
    for (name, src) in [("one.ktf", "fn f(x) { 1"), ("two.ktf", "define(r, nope);")] {
        if let Err(diags) = run_source(&mut session, name, src, Engine::Vm, &[]) {
            all.extend(diags);
        }
    }
    let rendered = driver::render_diagnostics(&session, &all);
    assert_eq!(
        rendered,
        "error[kerf-read]: unclosed delimiter: `{` is never closed\n --> one.ktf:1:9\n  |\n1 | fn f(x) { 1\n  |         ^\n\nerror[kerf-expand]: unbound identifier `nope`: not in any lexical scope and not a Stage 0 global\n --> two.ktf:1:11\n  |\n1 | define(r, nope);\n  |           ^^^^\nerror: aborting due to 2 previous errors\n"
    );
}

#[test]
fn ds11_literal_errors_render_whole_token_spans() {
    // v0.40.0 (stage0.md §9.71): the literal family carries its
    // whole-token span — the render points at the literal's full
    // extent (rustc underlines the literal in its own out-of-range
    // diagnostics; kerf mirrors). Before, these rendered with no
    // location line at all. The r151 target-skin twins: `1.2.3` is
    // field-access skin material on the target skin (the malformed-
    // number face rides the radix prefix `0xzz`), and the bare
    // `1e999` exponent attaches only to dot-mandatory floats (the
    // overflow face rides `1.0e999`).
    assert_eq!(
        render_of("define(r, 0xzz);"),
        "error[kerf-read]: malformed number literal `0xzz`\n --> p.ktf:1:11\n  |\n1 | define(r, 0xzz);\n  |           ^^^^\n"
    );
    assert_eq!(
        render_of("define(r, 9223372036854775808);"),
        "error[kerf-read]: integer literal `9223372036854775808` out of range for `i64`\n --> p.ktf:1:11\n  |\n1 | define(r, 9223372036854775808);\n  |           ^^^^^^^^^^^^^^^^^^^\n"
    );
    assert_eq!(
        render_of("define(r, 1.0e999);"),
        "error[kerf-read]: float literal `1.0e999` out of range for `f64`\n --> p.ktf:1:11\n  |\n1 | define(r, 1.0e999);\n  |           ^^^^^^^\n"
    );
}

// ---------- §F repl transcripts (FP6) ----------

#[test]
fn ts01_session_transcript_values_and_outputs() {
    let mut repl = Repl::new();
    let mut transcript = Vec::new();
    // The r151 target-skin retarget: the statement grammar ends
    // expressions with `;`, so every submitted line carries its own
    // terminator (the wrap name `_replN` avoids interior
    // underscores — the skin dictionary's Rule K domain).
    for line in ["define(x, 41);", "x + 1;", "write_line(\"hi\");"] {
        match repl.submit(line) {
            ReplEvent::Evaluated {
                value,
                new_outputs,
                new_warnings,
            } => {
                assert!(new_warnings.is_empty(), "ts02 warning-free corpus");
                transcript.push(format!(
                    "value={:?} outputs={:?}",
                    value.unwrap_or_default(),
                    new_outputs
                ))
            }
            other => panic!("unexpected event: {other:?}"),
        }
    }
    assert_eq!(
        transcript,
        [
            "value=\"\" outputs=[]".to_owned(),
            "value=\"42\" outputs=[]".to_owned(),
            "value=\"nil\" outputs=[\"hi\"]".to_owned(),
        ]
    );
}

#[test]
fn ts02_error_submission_rolls_back_and_session_survives() {
    let mut repl = Repl::new();
    match repl.submit("define(y, 5);") {
        ReplEvent::Evaluated { .. } => {}
        other => panic!("define: {other:?}"),
    }
    match repl.submit("y + undefined_var;") {
        ReplEvent::Error { rendered } => {
            assert_eq!(rendered.lines().count(), 5);
        }
        other => panic!("error expected: {other:?}"),
    }
    match repl.submit("y;") {
        ReplEvent::Evaluated { value, .. } => assert_eq!(value.as_deref(), Some("5")),
        other => panic!("y: {other:?}"),
    }
}

#[test]
fn ts03_unclosed_submission_asks_for_more() {
    let mut repl = Repl::new();
    assert!(matches!(repl.submit("(1 +"), ReplEvent::NeedMoreInput));
}

#[test]
fn ts04_continuation_line_completes_the_program() {
    let mut repl = Repl::new();
    assert!(matches!(repl.submit("(1 +"), ReplEvent::NeedMoreInput));
    match repl.submit("2);") {
        ReplEvent::Evaluated { value, .. } => assert_eq!(value.as_deref(), Some("3")),
        other => panic!("continuation: {other:?}"),
    }
}

#[test]
fn vd01_value_display_eight_forms() {
    let forms = [
        Value::Int(-7).to_string(),
        Value::Float(2.5).to_string(),
        Value::Bool(true).to_string(),
        Value::Str("s".into()).to_string(),
        Value::Nil.to_string(),
        Value::Pair(3).to_string(),
        Value::Closure(9).to_string(),
        kerf::vm::Builtin::from_name("+")
            .map(|b| Value::Builtin(b).to_string())
            .unwrap_or_default(),
    ];
    assert_eq!(
        forms,
        [
            "-7",
            "2.5",
            "true",
            "\"s\"",
            "nil",
            "#<pair>",
            "#<closure>",
            "#<builtin:+>",
        ]
    );
}

//! The W-LINEAR-TYPES blade-1 golden corpus (w-linear-types-window.md
//! §6 blade 1, GZ-Q1 — the r174 frozen-oracle ruling's row-blade
//! consumer family: the golden pins the TWIN's own verdicts; the Rust
//! oracle never implements quals, so no parity face ever sees these
//! cases).
//!
//! The data-constructed form (the RW-9 skin-layer finding, verbatim):
//! the target skin's spec grammar cannot spell a `"qual"` head today
//! (the same `(`-opens-tuple / `path(args)`-opens-app closure), so
//! every case here builds its `ModuleItem`s directly (a Define
//! carrying one `Fn` plus the `Annotate` dann sites, the paired_drive
//! items-injection precedent) and feeds the steady twin chain. The
//! blade-2 annotation-skin cases are their own deliverable.
//!
//! Case families (the blade-1 acceptance gate, 8 positive : 24
//! negative = 1:3 exact, negative >= 3 classes): the identity family
//! (the "lin"/"un" pinned vocabulary, the multi-atom order), the
//! composite-body family (pair / nested-qual / open-row bodies — the
//! display recursion and the schema-var penetration), the
//! cross-define instantiation (the generalization face — the schema's
//! var list carries the body's vars THROUGH the qual arm), and the
//! GZ-1 conservative-degrade boundary (the unknown atom, the
//! duplicate atom — a degraded qual absorbs as dyn, the program
//! stays legal); against thirteen E0013 ret-face rows (the pred-set
//! mismatches, the body mismatches, the nested conflicts, the
//! composite orthogonalities both directions), two nominal
//! orthogonality rows (struct/enum), and nine E0009 call-site rows.

use kerf::core::{CoreExpr, LiteralValue, ModuleItem};
use kerf::driver::SteadyTypecheckChain;
use kerf::span::{ByteOffset, ExpansionId, FileId, Span};

fn sp(a: u32, b: u32) -> Span {
    Span::new(FileId(0), ByteOffset(a), ByteOffset(b), ExpansionId::ROOT)
        .expect("test span is ordered")
}

fn sym(text: &str) -> kerf::span::Symbol {
    kerf::span::Symbol::new(text).expect("test symbol is valid")
}

fn s(text: &str) -> LiteralValue {
    LiteralValue::String(std::rc::Rc::from(text))
}

fn l(items: Vec<LiteralValue>) -> LiteralValue {
    let mut out = LiteralValue::Nil;
    for item in items.into_iter().rev() {
        out = LiteralValue::Pair(Box::new(item), Box::new(out));
    }
    out
}

/// One closed single-field row `(row (x T) tail)` — the qual body's
/// own row vocabulary (the corpus-row helpers' shape, scoped here).
fn rowx(ty: &str, tail: &str) -> LiteralValue {
    l(vec![s("row"), l(vec![s("x"), s(ty)]), s(tail)])
}

/// One qual spec `(qual a... body)` — the atoms inline, the body last.
fn quals(atoms: &[&str], body: LiteralValue) -> LiteralValue {
    let mut v = vec![s("qual")];
    for a in atoms {
        v.push(s(a));
    }
    v.push(body);
    l(v)
}

/// One annotated identity function `fn f(r) { r }`: the Define
/// carrying the Fn, one Param dann site, one Ret dann site (the
/// anchor IS the Fn's span — the paired-drive convention).
fn id_fn(param_spec: LiteralValue, ret_spec: LiteralValue) -> Vec<ModuleItem> {
    let fspan = sp(10, 40);
    vec![
        ModuleItem::Define {
            span: sp(0, 41),
            name: sym("f"),
            value: CoreExpr::Fn {
                span: fspan,
                params: vec![sym("r")],
                body: Box::new(CoreExpr::Var {
                    span: sp(35, 36),
                    name: sym("r"),
                }),
            },
        },
        ModuleItem::Annotate {
            span: sp(11, 20),
            anchor: fspan,
            kind: kerf::core::AnnotationKind::Param,
            index: 0,
            spec: param_spec,
        },
        ModuleItem::Annotate {
            span: sp(28, 39),
            anchor: fspan,
            kind: kerf::core::AnnotationKind::Ret,
            index: 0,
            spec: ret_spec,
        },
    ]
}

/// The golden case drive: the steady twin chain, the decoded
/// verdict, byte-exact against the pinned expectation.
fn drive(items: &[ModuleItem]) -> String {
    let chain = SteadyTypecheckChain::new().expect("the fixed twin program builds");
    chain.infer(items).expect("the twin inference runs")
}

/// The positive family — eight drives, every one pinning the twin's
/// full decoded verdict (zero diags; the tdef schema shows the qual
/// display, the open row body's variable rides the schema var list
/// through the qual arm, the cross-define case instantiates the
/// qualified schema fresh, and the GZ-1 degrade boundary absorbs).
#[test]
fn qual_golden_positive_family() {
    let cases: Vec<(&str, Vec<ModuleItem>, &str)> = vec![
        (
            "pos-qual-identity-lin",
            id_fn(quals(&["lin"], s("int")), quals(&["lin"], s("int"))),
            "(ok (types (tdef f (schema () (fn ((qual lin int)) (qual lin int))) (effs) (tfn 10 40 (r) (tvar 35 36 r (qual lin int)) (fn ((qual lin int)) (qual lin int))))) (diags))",
        ),
        (
            "pos-qual-two-atoms",
            id_fn(
                quals(&["lin", "un"], s("str")),
                quals(&["lin", "un"], s("str")),
            ),
            "(ok (types (tdef f (schema () (fn ((qual lin un str)) (qual lin un str))) (effs) (tfn 10 40 (r) (tvar 35 36 r (qual lin un str)) (fn ((qual lin un str)) (qual lin un str))))) (diags))",
        ),
        (
            "pos-qual-body-pair",
            id_fn(
                quals(&["lin"], l(vec![s("tuple"), s("int"), s("bool")])),
                quals(&["lin"], l(vec![s("tuple"), s("int"), s("bool")])),
            ),
            "(ok (types (tdef f (schema () (fn ((qual lin (pair int bool))) (qual lin (pair int bool)))) (effs) (tfn 10 40 (r) (tvar 35 36 r (qual lin (pair int bool))) (fn ((qual lin (pair int bool))) (qual lin (pair int bool)))))) (diags))",
        ),
        (
            "pos-qual-nested-qual",
            id_fn(
                quals(&["un"], quals(&["lin"], s("int"))),
                quals(&["un"], quals(&["lin"], s("int"))),
            ),
            "(ok (types (tdef f (schema () (fn ((qual un (qual lin int))) (qual un (qual lin int)))) (effs) (tfn 10 40 (r) (tvar 35 36 r (qual un (qual lin int))) (fn ((qual un (qual lin int))) (qual un (qual lin int)))))) (diags))",
        ),
        (
            "pos-qual-body-row-open",
            id_fn(
                quals(&["lin"], rowx("int", "_")),
                quals(&["lin"], rowx("int", "_")),
            ),
            "(ok (types (tdef f (schema (2) (fn ((qual lin (row x int | t2))) (qual lin (row x int | t2)))) (effs) (tfn 10 40 (r) (tvar 35 36 r (qual lin (row x int | t2))) (fn ((qual lin (row x int | t2))) (qual lin (row x int | t2)))))) (diags))",
        ),
        (
            // f = fn(r: (qual lin (row (x int) _))) { r };
            // g = fn(a) { f(a) } — g's schema instantiates f's
            // qualified schema fresh (the penetration face).
            "pos-cross-define-penetration",
            {
                let fspan = sp(10, 40);
                let mut items = vec![
                    ModuleItem::Define {
                        span: sp(0, 41),
                        name: sym("f"),
                        value: CoreExpr::Fn {
                            span: fspan,
                            params: vec![sym("r")],
                            body: Box::new(CoreExpr::Var {
                                span: sp(35, 36),
                                name: sym("r"),
                            }),
                        },
                    },
                    ModuleItem::Annotate {
                        span: sp(11, 20),
                        anchor: fspan,
                        kind: kerf::core::AnnotationKind::Param,
                        index: 0,
                        spec: quals(&["lin"], rowx("int", "_")),
                    },
                ];
                items.push(ModuleItem::Define {
                    span: sp(50, 91),
                    name: sym("g"),
                    value: CoreExpr::Fn {
                        span: sp(60, 90),
                        params: vec![sym("a")],
                        body: Box::new(CoreExpr::Apply {
                            span: sp(70, 80),
                            func: Box::new(CoreExpr::Var {
                                span: sp(70, 71),
                                name: sym("f"),
                            }),
                            args: vec![CoreExpr::Var {
                                span: sp(72, 73),
                                name: sym("a"),
                            }],
                        }),
                    },
                });
                items
            },
            "(ok (types (tdef f (schema (2) (fn ((qual lin (row x int | t2))) (qual lin (row x int | t2)))) (effs) (tfn 10 40 (r) (tvar 35 36 r (qual lin (row x int | t2))) (fn ((qual lin (row x int | t2))) (qual lin (row x int | t2))))) (tdef g (schema (5) (fn ((qual lin (row x int | t5))) (qual lin (row x int | t5)))) (effs) (tfn 60 90 (a) (tapply 70 80 (tvar 70 71 f (fn ((qual lin (row x int | t5))) (qual lin (row x int | t5)))) ((tvar 72 73 a (qual lin (row x int | t5)))) (qual lin (row x int | t5)) (effs)) (fn ((qual lin (row x int | t5))) (qual lin (row x int | t5)))))) (diags))",
        ),
        (
            // (qual linx int) — the unknown atom degrades the whole
            // spec to dyn (the pinned vocabulary boundary); the dyn
            // absorbs, the ret annotation rules, the program stays
            // legal (the GZ-1 conservative boundary).
            "pos-degrade-unknown-atom",
            id_fn(quals(&["linx"], s("int")), s("int")),
            "(ok (types (tdef f (schema () (fn (int) int)) (effs) (tfn 10 40 (r) (tvar 35 36 r int) (fn (int) int)))) (diags))",
        ),
        (
            // (qual lin lin int) — the duplicate atom degrades the
            // whole spec to dyn (the ti_qual_dup half).
            "pos-degrade-dup-atom",
            id_fn(quals(&["lin", "lin"], s("int")), s("int")),
            "(ok (types (tdef f (schema () (fn (int) int)) (effs) (tfn 10 40 (r) (tvar 35 36 r int) (fn (int) int)))) (diags))",
        ),
    ];
    for (name, items, expected) in cases {
        assert_eq!(drive(&items), expected, "{name}: the pinned verdict");
    }
}

/// The E0013 ret-face negative family — thirteen rows (the pred-set
/// mismatches, the body ground mismatches, the nested conflicts, the
/// composite orthogonalities both directions).
#[test]
fn qual_golden_negative_e0013_family() {
    let cases: Vec<(&str, LiteralValue, LiteralValue, &str)> = vec![
        (
            "neg-ann-pred-lin-vs-un",
            quals(&["lin"], s("int")),
            quals(&["un"], s("int")),
            "(ok (types (tdef f (schema () (fn ((qual lin int)) (qual lin int))) (effs) (tfn 10 40 (r) (tvar 35 36 r (qual lin int)) (fn ((qual lin int)) (qual lin int))))) (diags (tdiag E0013 error 28 39 annotation divergence: expected `(qual un int)`, found `(qual lin int)`)))",
        ),
        (
            "neg-ann-pred-set-length",
            quals(&["lin"], s("int")),
            quals(&["lin", "un"], s("int")),
            "(ok (types (tdef f (schema () (fn ((qual lin int)) (qual lin int))) (effs) (tfn 10 40 (r) (tvar 35 36 r (qual lin int)) (fn ((qual lin int)) (qual lin int))))) (diags (tdiag E0013 error 28 39 annotation divergence: expected `(qual lin un int)`, found `(qual lin int)`)))",
        ),
        (
            "neg-ann-pred-order",
            quals(&["lin", "un"], s("int")),
            quals(&["un", "lin"], s("int")),
            "(ok (types (tdef f (schema () (fn ((qual lin un int)) (qual lin un int))) (effs) (tfn 10 40 (r) (tvar 35 36 r (qual lin un int)) (fn ((qual lin un int)) (qual lin un int))))) (diags (tdiag E0013 error 28 39 annotation divergence: expected `(qual un lin int)`, found `(qual lin un int)`)))",
        ),
        (
            "neg-ann-body-int-str",
            quals(&["lin"], s("int")),
            quals(&["lin"], s("str")),
            "(ok (types (tdef f (schema () (fn ((qual lin int)) (qual lin int))) (effs) (tfn 10 40 (r) (tvar 35 36 r (qual lin int)) (fn ((qual lin int)) (qual lin int))))) (diags (tdiag E0013 error 28 39 annotation divergence: expected `(qual lin str)`, found `(qual lin int)`)))",
        ),
        (
            "neg-ann-body-bool-int",
            quals(&["un"], s("bool")),
            quals(&["un"], s("int")),
            "(ok (types (tdef f (schema () (fn ((qual un bool)) (qual un bool))) (effs) (tfn 10 40 (r) (tvar 35 36 r (qual un bool)) (fn ((qual un bool)) (qual un bool))))) (diags (tdiag E0013 error 28 39 annotation divergence: expected `(qual un int)`, found `(qual un bool)`)))",
        ),
        (
            "neg-ann-nested-body",
            quals(&["un"], quals(&["lin"], s("int"))),
            quals(&["un"], quals(&["lin"], s("str"))),
            "(ok (types (tdef f (schema () (fn ((qual un (qual lin int))) (qual un (qual lin int)))) (effs) (tfn 10 40 (r) (tvar 35 36 r (qual un (qual lin int))) (fn ((qual un (qual lin int))) (qual un (qual lin int)))))) (diags (tdiag E0013 error 28 39 annotation divergence: expected `(qual un (qual lin str))`, found `(qual un (qual lin int))`)))",
        ),
        (
            "neg-ann-nested-pred",
            quals(&["un"], quals(&["lin"], s("int"))),
            quals(&["un"], quals(&["un"], s("int"))),
            "(ok (types (tdef f (schema () (fn ((qual un (qual lin int))) (qual un (qual lin int)))) (effs) (tfn 10 40 (r) (tvar 35 36 r (qual un (qual lin int))) (fn ((qual un (qual lin int))) (qual un (qual lin int)))))) (diags (tdiag E0013 error 28 39 annotation divergence: expected `(qual un (qual un int))`, found `(qual un (qual lin int))`)))",
        ),
        (
            "neg-ann-qual-vs-int",
            quals(&["lin"], s("int")),
            s("int"),
            "(ok (types (tdef f (schema () (fn ((qual lin int)) (qual lin int))) (effs) (tfn 10 40 (r) (tvar 35 36 r (qual lin int)) (fn ((qual lin int)) (qual lin int))))) (diags (tdiag E0013 error 28 39 annotation divergence: expected `int`, found `(qual lin int)`)))",
        ),
        (
            "neg-ann-int-vs-qual",
            s("int"),
            quals(&["lin"], s("int")),
            "(ok (types (tdef f (schema () (fn (int) int)) (effs) (tfn 10 40 (r) (tvar 35 36 r int) (fn (int) int)))) (diags (tdiag E0013 error 28 39 annotation divergence: expected `(qual lin int)`, found `int`)))",
        ),
        (
            "neg-ann-qual-vs-pair",
            quals(&["lin"], s("int")),
            l(vec![s("tuple"), s("int"), s("bool")]),
            "(ok (types (tdef f (schema () (fn ((qual lin int)) (qual lin int))) (effs) (tfn 10 40 (r) (tvar 35 36 r (qual lin int)) (fn ((qual lin int)) (qual lin int))))) (diags (tdiag E0013 error 28 39 annotation divergence: expected `(pair int bool)`, found `(qual lin int)`)))",
        ),
        (
            "neg-ann-qual-vs-fn",
            quals(&["lin"], s("int")),
            l(vec![s("arrow"), s("int"), s("int")]),
            "(ok (types (tdef f (schema () (fn ((qual lin int)) (qual lin int))) (effs) (tfn 10 40 (r) (tvar 35 36 r (qual lin int)) (fn ((qual lin int)) (qual lin int))))) (diags (tdiag E0013 error 28 39 annotation divergence: expected `(fn (int) int)`, found `(qual lin int)`)))",
        ),
        (
            "neg-ann-qual-vs-row",
            quals(&["lin"], s("int")),
            rowx("int", "nil"),
            "(ok (types (tdef f (schema () (fn ((qual lin int)) (qual lin int))) (effs) (tfn 10 40 (r) (tvar 35 36 r (qual lin int)) (fn ((qual lin int)) (qual lin int))))) (diags (tdiag E0013 error 28 39 annotation divergence: expected `(row x int)`, found `(qual lin int)`)))",
        ),
        (
            "neg-ann-row-vs-qual",
            rowx("int", "nil"),
            quals(&["lin"], s("int")),
            "(ok (types (tdef f (schema () (fn ((row x int)) (row x int))) (effs) (tfn 10 40 (r) (tvar 35 36 r (row x int)) (fn ((row x int)) (row x int))))) (diags (tdiag E0013 error 28 39 annotation divergence: expected `(qual lin int)`, found `(row x int)`)))",
        ),
    ];
    for (name, p, r, expected) in cases {
        assert_eq!(drive(&id_fn(p, r)), expected, "{name}: the pinned verdict");
    }
}

/// The struct/enum orthogonality rows — the nominal closure never
/// unfolds against a qual (the ORIGINAL records ride).
#[test]
fn qual_golden_negative_orthogonality_family() {
    let fspan = sp(30, 60);
    let base = |decl: ModuleItem, ret: LiteralValue| {
        vec![
            decl,
            ModuleItem::Define {
                span: sp(21, 61),
                name: sym("f"),
                value: CoreExpr::Fn {
                    span: fspan,
                    params: vec![sym("r")],
                    body: Box::new(CoreExpr::Var {
                        span: sp(55, 56),
                        name: sym("r"),
                    }),
                },
            },
            ModuleItem::Annotate {
                span: sp(31, 40),
                anchor: fspan,
                kind: kerf::core::AnnotationKind::Param,
                index: 0,
                spec: quals(&["lin"], s("int")),
            },
            ModuleItem::Annotate {
                span: sp(48, 59),
                anchor: fspan,
                kind: kerf::core::AnnotationKind::Ret,
                index: 0,
                spec: ret,
            },
        ]
    };
    let cases: Vec<(&str, Vec<ModuleItem>, &str)> = vec![
        (
            "neg-ann-qual-vs-struct",
            base(
                ModuleItem::Struct {
                    span: sp(0, 20),
                    name: sym("S"),
                    fields: vec![(sym("a"), s("int"))],
                },
                s("S"),
            ),
            "(ok (types (tdef f (schema () (fn ((qual lin int)) (qual lin int))) (effs) (tfn 30 60 (r) (tvar 55 56 r (qual lin int)) (fn ((qual lin int)) (qual lin int))))) (diags (tdiag E0013 error 48 59 annotation divergence: expected `S`, found `(qual lin int)`)))",
        ),
        (
            "neg-ann-qual-vs-enum",
            base(
                ModuleItem::Enum {
                    span: sp(0, 20),
                    name: sym("E"),
                    variants: vec![(sym("A"), vec![])],
                },
                s("E"),
            ),
            "(ok (types (tdef f (schema () (fn ((qual lin int)) (qual lin int))) (effs) (tfn 30 60 (r) (tvar 55 56 r (qual lin int)) (fn ((qual lin int)) (qual lin int))))) (diags (tdiag E0013 error 48 59 annotation divergence: expected `E`, found `(qual lin int)`)))",
        ),
    ];
    for (name, items, expected) in cases {
        assert_eq!(drive(&items), expected, "{name}: the pinned verdict");
    }
}

/// The E0009 call-site family — the application-face unifications
/// (the qual x scalar argument, the pred mismatches, the composite
/// orthogonalities, both directions).
#[test]
fn qual_golden_negative_e0009_call_site_family() {
    let fspan = sp(10, 40);
    // f = fn(r: (qual ...)) { r }; g = fn(<g-params>) { f(<g-arg>) }
    let mut cases: Vec<(&str, Vec<ModuleItem>, &str)> = vec![];

    // The literal-argument rows: g = fn() { f(<lit>) }.
    for (name, f_spec, lit, expected) in [
        (
            "neg-call-qual-vs-int-lit-arg",
            quals(&["lin"], s("int")),
            LiteralValue::Int(1),
            "(ok (types (tdef f (schema () (fn ((qual lin int)) (qual lin int))) (effs) (tfn 10 40 (r) (tvar 35 36 r (qual lin int)) (fn ((qual lin int)) (qual lin int)))) (tdef g (schema () (fn () (qual lin int))) (effs) (tfn 60 90 () (tapply 70 80 (tvar 70 71 f (fn ((qual lin int)) (qual lin int))) ((tlit 75 76 (int 1) int)) (qual lin int) (effs)) (fn () (qual lin int))))) (diags (tdiag E0009 error 75 76 type mismatch: expected `(qual lin int)`, found `int`)))",
        ),
        (
            "neg-call-qual-vs-str-lit-arg",
            quals(&["lin"], s("str")),
            s("x"),
            "(ok (types (tdef f (schema () (fn ((qual lin str)) (qual lin str))) (effs) (tfn 10 40 (r) (tvar 35 36 r (qual lin str)) (fn ((qual lin str)) (qual lin str)))) (tdef g (schema () (fn () (qual lin str))) (effs) (tfn 60 90 () (tapply 70 80 (tvar 70 71 f (fn ((qual lin str)) (qual lin str))) ((tlit 75 76 (string \"x\") str)) (qual lin str) (effs)) (fn () (qual lin str))))) (diags (tdiag E0009 error 75 76 type mismatch: expected `(qual lin str)`, found `str`)))",
        ),
    ] {
        let items = vec![
            ModuleItem::Define {
                span: sp(0, 41),
                name: sym("f"),
                value: CoreExpr::Fn {
                    span: fspan,
                    params: vec![sym("r")],
                    body: Box::new(CoreExpr::Var {
                        span: sp(35, 36),
                        name: sym("r"),
                    }),
                },
            },
            ModuleItem::Annotate {
                span: sp(11, 20),
                anchor: fspan,
                kind: kerf::core::AnnotationKind::Param,
                index: 0,
                spec: f_spec,
            },
            ModuleItem::Define {
                span: sp(50, 91),
                name: sym("g"),
                value: CoreExpr::Fn {
                    span: sp(60, 90),
                    params: vec![],
                    body: Box::new(CoreExpr::Apply {
                        span: sp(70, 80),
                        func: Box::new(CoreExpr::Var {
                            span: sp(70, 71),
                            name: sym("f"),
                        }),
                        args: vec![CoreExpr::Literal {
                            span: sp(75, 76),
                            value: lit,
                        }],
                    }),
                },
            },
        ];
        cases.push((name, items, expected));
    }

    // The annotated-argument rows: f keeps its (qual lin int)
    // param; g's param rides the varying spec.
    for (name, g_spec, expected) in [
        (
            "neg-call-pred-mismatch-arg",
            quals(&["un"], s("int")),
            "(ok (types (tdef f (schema () (fn ((qual lin int)) (qual lin int))) (effs) (tfn 10 40 (r) (tvar 35 36 r (qual lin int)) (fn ((qual lin int)) (qual lin int)))) (tdef g (schema () (fn ((qual un int)) (qual lin int))) (effs) (tfn 60 90 (a) (tapply 70 80 (tvar 70 71 f (fn ((qual lin int)) (qual lin int))) ((tvar 75 76 a (qual un int))) (qual lin int) (effs)) (fn ((qual un int)) (qual lin int))))) (diags (tdiag E0009 error 75 76 type mismatch: expected `(qual lin int)`, found `(qual un int)`)))",
        ),
        (
            "neg-call-body-mismatch-arg",
            quals(&["lin"], s("str")),
            "(ok (types (tdef f (schema () (fn ((qual lin int)) (qual lin int))) (effs) (tfn 10 40 (r) (tvar 35 36 r (qual lin int)) (fn ((qual lin int)) (qual lin int)))) (tdef g (schema () (fn ((qual lin str)) (qual lin int))) (effs) (tfn 60 90 (a) (tapply 70 80 (tvar 70 71 f (fn ((qual lin int)) (qual lin int))) ((tvar 75 76 a (qual lin str))) (qual lin int) (effs)) (fn ((qual lin str)) (qual lin int))))) (diags (tdiag E0009 error 75 76 type mismatch: expected `int`, found `str`)))",
        ),
        (
            "neg-call-qual-vs-row-arg",
            rowx("int", "nil"),
            "(ok (types (tdef f (schema () (fn ((qual lin int)) (qual lin int))) (effs) (tfn 10 40 (r) (tvar 35 36 r (qual lin int)) (fn ((qual lin int)) (qual lin int)))) (tdef g (schema () (fn ((row x int)) (qual lin int))) (effs) (tfn 60 90 (a) (tapply 70 80 (tvar 70 71 f (fn ((qual lin int)) (qual lin int))) ((tvar 75 76 a (row x int))) (qual lin int) (effs)) (fn ((row x int)) (qual lin int))))) (diags (tdiag E0009 error 75 76 type mismatch: expected `(qual lin int)`, found `(row x int)`)))",
        ),
        (
            "neg-call-qual-vs-pair-arg",
            l(vec![s("tuple"), s("int"), s("bool")]),
            "(ok (types (tdef f (schema () (fn ((qual lin int)) (qual lin int))) (effs) (tfn 10 40 (r) (tvar 35 36 r (qual lin int)) (fn ((qual lin int)) (qual lin int)))) (tdef g (schema () (fn ((pair int bool)) (qual lin int))) (effs) (tfn 60 90 (a) (tapply 70 80 (tvar 70 71 f (fn ((qual lin int)) (qual lin int))) ((tvar 75 76 a (pair int bool))) (qual lin int) (effs)) (fn ((pair int bool)) (qual lin int))))) (diags (tdiag E0009 error 75 76 type mismatch: expected `(qual lin int)`, found `(pair int bool)`)))",
        ),
        (
            "neg-call-qual-vs-fn-arg",
            l(vec![s("arrow"), s("int"), s("int")]),
            "(ok (types (tdef f (schema () (fn ((qual lin int)) (qual lin int))) (effs) (tfn 10 40 (r) (tvar 35 36 r (qual lin int)) (fn ((qual lin int)) (qual lin int)))) (tdef g (schema () (fn ((fn (int) int)) (qual lin int))) (effs) (tfn 60 90 (a) (tapply 70 80 (tvar 70 71 f (fn ((qual lin int)) (qual lin int))) ((tvar 75 76 a (fn (int) int))) (qual lin int) (effs)) (fn ((fn (int) int)) (qual lin int))))) (diags (tdiag E0009 error 75 76 type mismatch: expected `(qual lin int)`, found `(fn (int) int)`)))",
        ),
        (
            "neg-call-qual-vs-enum-name-arg",
            s("E"),
            "(ok (types (tdef f (schema () (fn ((qual lin int)) (qual lin int))) (effs) (tfn 10 40 (r) (tvar 35 36 r (qual lin int)) (fn ((qual lin int)) (qual lin int)))) (tdef g (schema () (fn (E) (qual lin int))) (effs) (tfn 60 90 (a) (tapply 70 80 (tvar 70 71 f (fn ((qual lin int)) (qual lin int))) ((tvar 75 76 a E)) (qual lin int) (effs)) (fn (E) (qual lin int))))) (diags (tdiag E0009 error 75 76 type mismatch: expected `(qual lin int)`, found `E`)))",
        ),
    ] {
        let gspan = sp(60, 90);
        let mut items = vec![
            ModuleItem::Define {
                span: sp(0, 41),
                name: sym("f"),
                value: CoreExpr::Fn {
                    span: fspan,
                    params: vec![sym("r")],
                    body: Box::new(CoreExpr::Var {
                        span: sp(35, 36),
                        name: sym("r"),
                    }),
                },
            },
            ModuleItem::Annotate {
                span: sp(11, 20),
                anchor: fspan,
                kind: kerf::core::AnnotationKind::Param,
                index: 0,
                spec: quals(&["lin"], s("int")),
            },
        ];
        if name.contains("enum-name") {
            items.insert(
                0,
                ModuleItem::Enum {
                    span: sp(100, 120),
                    name: sym("E"),
                    variants: vec![(sym("A"), vec![])],
                },
            );
        }
        items.push(ModuleItem::Define {
            span: sp(50, 91),
            name: sym("g"),
            value: CoreExpr::Fn {
                span: gspan,
                params: vec![sym("a")],
                body: Box::new(CoreExpr::Apply {
                    span: sp(70, 80),
                    func: Box::new(CoreExpr::Var {
                        span: sp(70, 71),
                        name: sym("f"),
                    }),
                    args: vec![CoreExpr::Var {
                        span: sp(75, 76),
                        name: sym("a"),
                    }],
                }),
            },
        });
        items.push(ModuleItem::Annotate {
            span: sp(61, 70),
            anchor: gspan,
            kind: kerf::core::AnnotationKind::Param,
            index: 0,
            spec: g_spec,
        });
        cases.push((name, items, expected));
    }

    // The reverse direction: f wants the row, g's argument is the
    // qual — expected rides the row face.
    {
        let gspan = sp(60, 90);
        let items = vec![
            ModuleItem::Define {
                span: sp(0, 41),
                name: sym("f"),
                value: CoreExpr::Fn {
                    span: fspan,
                    params: vec![sym("r")],
                    body: Box::new(CoreExpr::Var {
                        span: sp(35, 36),
                        name: sym("r"),
                    }),
                },
            },
            ModuleItem::Annotate {
                span: sp(11, 20),
                anchor: fspan,
                kind: kerf::core::AnnotationKind::Param,
                index: 0,
                spec: rowx("int", "nil"),
            },
            ModuleItem::Define {
                span: sp(50, 91),
                name: sym("g"),
                value: CoreExpr::Fn {
                    span: gspan,
                    params: vec![sym("a")],
                    body: Box::new(CoreExpr::Apply {
                        span: sp(70, 80),
                        func: Box::new(CoreExpr::Var {
                            span: sp(70, 71),
                            name: sym("f"),
                        }),
                        args: vec![CoreExpr::Var {
                            span: sp(75, 76),
                            name: sym("a"),
                        }],
                    }),
                },
            },
            ModuleItem::Annotate {
                span: sp(61, 70),
                anchor: gspan,
                kind: kerf::core::AnnotationKind::Param,
                index: 0,
                spec: quals(&["lin"], s("int")),
            },
        ];
        cases.push(("neg-call-row-vs-qual-arg", items, "(ok (types (tdef f (schema () (fn ((row x int)) (row x int))) (effs) (tfn 10 40 (r) (tvar 35 36 r (row x int)) (fn ((row x int)) (row x int)))) (tdef g (schema () (fn ((qual lin int)) (row x int))) (effs) (tfn 60 90 (a) (tapply 70 80 (tvar 70 71 f (fn ((row x int)) (row x int))) ((tvar 75 76 a (qual lin int))) (row x int) (effs)) (fn ((qual lin int)) (row x int))))) (diags (tdiag E0009 error 75 76 type mismatch: expected `(row x int)`, found `(qual lin int)`)))"));
    }

    for (name, items, expected) in cases {
        assert_eq!(drive(&items), expected, "{name}: the pinned verdict");
    }
}

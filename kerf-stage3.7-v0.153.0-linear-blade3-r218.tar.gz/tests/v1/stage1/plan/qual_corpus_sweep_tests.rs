//! The W-LINEAR-TYPES blade-3 corpus face (w-linear-types-window.md
//! §6 blade 3 — the `corpus-qual/` family's own sweep): every case
//! through the PRODUCTION twin segments with the `// expect:` line
//! owning the verdict, exactly as the r189 corpus-effect precedent
//! (the efx sweep wiring — the r185 corpus-row discipline carried
//! to the linear family).
//!
//! The sweep's layer split is the linear family's own honest face —
//! four verdict arms naming WHICH layer owns the judgment:
//!
//!   * `value N` — the full chain runs with ZERO findings and the
//!     result global pins N (the strict clean: the consumption-clean
//!     transfers, the [un] no-discipline doubles, the Q3 orthogonal
//!     consume, and the two degrade families that run real calls);
//!   * `warn-linear N` — the check face reports NO Error and one
//!     E0015 warning (the zero-consume face is warning-grade by the
//!     Q2 ruling), and the run still pins N — the warning never
//!     blocks (this arm is the linear family's own verdict layer,
//!     absent from the row and effect families);
//!   * `type-error` — the parse succeeds and the check face reports
//!     an Error finding (E0014 the use-count rejection with the
//!     count payload; E0009/E0013 the operand and annotation
//!     divergence faces through the skin);
//!   * `read-error` — the twin read segment rejects (the qual-spec
//!     skin guards: the body-less form, the spaced atoms, the
//!     non-ident atom, the unclosed bracket, the trailing comma).
//!
//! The population: 10 positive value rows against 18 negative rows
//! (5 read + 8 type + 5 warn) — the same 28-case caliber as the
//! corpus-row and corpus-effect precedents, with the warn arm
//! carrying the E0015 rows the golden corpus established (the
//! authoring-time catches: a dropped [lin] param inside a
//! defined-but-uncalled fn still reports — the checker's walk
//! covers every define; and the literal-call boundary stays an
//! Error even though the degrade families run — both pinned by
//! their expect lines).

use kerf::driver::{Engine, Session, parse_target};
use kerf::vm::{BufferIo, Value};

/// The r139 deep-stack precedent: the twin segments compile the
/// selfhost-scale programs, so the driver needs the large stack.
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(512 * 1024 * 1024)
        .spawn(body)
        .expect("deep-stack thread")
        .join()
        .expect("deep-stack join")
}

/// One production-chain parse: the twin read and expansion verdicts.
fn parse(source: &str) -> Result<kerf::driver::ParsedProgram, Vec<kerf::driver::Diagnostic>> {
    let mut session = Session::new();
    parse_target(&mut session, "qual-case.ktf", source)
}

/// One production-chain run: parse, check, compile, VM execute — the
/// `define(result, ...)` convention pins the program's value.
fn run(source: &str) -> Result<String, Vec<kerf::driver::Diagnostic>> {
    let program = parse(source)?;
    let outcome = program.run(Engine::Vm, Box::new(BufferIo::default()))?;
    let entry = outcome
        .globals
        .iter()
        .find(|(name, _)| name.as_str() == "result")
        .map(|(_, v)| v.clone())
        .unwrap_or(Value::Nil);
    Ok(format!("{entry}"))
}

// ---------- the corpus-qual sweep (the efx wiring, linear family) ----------

/// The `corpus-qual/` source family: every case through the
/// PRODUCTION twin segments with the `// expect:` line owning the
/// verdict. The oracle never sees these sources (the r174 exemption
/// face — the sweep is the twin's own, the corpus discipline carried
/// from the row and effect families to the linear family).
#[test]
fn ql_corpus_sweep_holds_the_linear_family() {
    deep_stack(|| {
        let dir = concat!(env!("CARGO_MANIFEST_DIR"), "/tests/v1/stage1/corpus-qual");
        let entries = std::fs::read_dir(dir).expect("the corpus-qual directory is in tree");
        // The linear family's files only: every ql-* case rides this
        // sweep (no library prefix, no instance-family split — the
        // corpus-row/corpus-effect single-family precedents).
        let mut files: Vec<_> = entries
            .filter_map(|e| e.ok())
            .map(|e| e.path())
            .filter(|p| {
                p.extension().is_some_and(|x| x == "ktf")
                    && p.file_name()
                        .and_then(|n| n.to_str())
                        .is_some_and(|n| n.starts_with("ql-"))
            })
            .collect();
        files.sort();
        assert!(
            files.len() >= 28,
            "the qual corpus expects the blade-3 population (10 positive + 18 negative), got {}",
            files.len()
        );
        let mut values = 0usize;
        let mut warn_rows = 0usize;
        let mut type_rejections = 0usize;
        let mut read_rejections = 0usize;
        for path in &files {
            let source = std::fs::read_to_string(path).expect("corpus file reads");
            let case = path.file_name().unwrap().to_string_lossy().to_string();
            let expect = source
                .lines()
                .find_map(|l| l.strip_prefix("// expect: "))
                .unwrap_or_else(|| panic!("{case} carries an expect line"));
            if let Some(v) = expect.strip_prefix("value ") {
                // The strict clean: zero findings of EITHER severity,
                // then the run pins the value.
                let program = parse(&source)
                    .unwrap_or_else(|d| panic!("{case} parses (the value face): {d:?}"));
                let findings = program.typecheck();
                assert!(
                    findings.is_empty(),
                    "{case} the value face carries zero findings: {findings:?}"
                );
                let got =
                    run(&source).unwrap_or_else(|d| panic!("{case} runs (the value face): {d:?}"));
                assert_eq!(
                    got.trim(),
                    v,
                    "{case} the result global pins the expected value"
                );
                values += 1;
            } else if let Some(v) = expect.strip_prefix("warn-linear ") {
                // No Error finding, one E0015 warning names the drop,
                // and the warning never blocks the run.
                let program = parse(&source).unwrap_or_else(|d| {
                    panic!("{case} parses (the warn face owns the verdict): {d:?}")
                });
                let findings = program.typecheck();
                assert!(
                    !findings
                        .iter()
                        .any(|d| d.severity == kerf::driver::Severity::Error),
                    "{case} carries no Error finding (the warn face owns the verdict): {findings:?}"
                );
                assert!(
                    findings
                        .iter()
                        .any(|d| d.message.contains("is never consumed")),
                    "{case} reports the E0015 zero-consume warning: {findings:?}"
                );
                let got = run(&source)
                    .unwrap_or_else(|d| panic!("{case} runs (the warning never blocks): {d:?}"));
                assert_eq!(
                    got.trim(),
                    v,
                    "{case} the result global pins the expected value through the warning"
                );
                warn_rows += 1;
            } else if expect.contains("type-error") {
                // The read layer does not own the verdict: the case
                // parses, and the check face reports an Error finding.
                let program = parse(&source).unwrap_or_else(|d| {
                    panic!("{case} parses (the type face owns the verdict): {d:?}")
                });
                let findings = program.typecheck();
                assert!(
                    findings
                        .iter()
                        .any(|d| d.severity == kerf::driver::Severity::Error),
                    "{case} rejects at the type layer"
                );
                type_rejections += 1;
            } else {
                assert!(
                    expect.contains("read-error"),
                    "{case} carries a known expectation, got {expect}"
                );
                parse(&source).expect_err(&format!("{case} rejects at the read layer"));
                read_rejections += 1;
            }
        }
        assert!(
            values >= 10 && warn_rows >= 5 && type_rejections >= 8 && read_rejections >= 5,
            "the sweep expects the 28-case population (>=10 values, >=5 warn, \
             >=8 type, >=5 read), got {values} values + {warn_rows} warn \
             + {type_rejections} type + {read_rejections} read"
        );
    });
}

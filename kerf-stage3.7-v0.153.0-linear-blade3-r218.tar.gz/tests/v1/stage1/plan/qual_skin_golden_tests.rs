//! The W-LINEAR-TYPES blade-2 golden corpus (w-linear-types-window.md
//! §6 blade 2, the Q2/Q3/Q4 rulings): the qualifier ANNOTATION SKIN
//! (`[lin] T` — the row precedent's own bracket, the first ident
//! without a colon) and the checker twin's use-count consumption
//! face (E0014 multi-consume / E0015 zero-consume) — all driven
//! through the PRODUCTION twin chain (the twin read + twin
//! expansion + BOTH checker twins; the Rust oracle never implements
//! the qual skin or the use-count rule — the r174 frozen boundary's
//! row-blade consumer family, so no parity face ever sees these
//! cases).
//!
//! The kernel's exact-predicate discipline (QL-4: the kernel
//! carries predicate sets without interpreting them) has a
//! first-face consequence this corpus pins honestly: a plain
//! literal (type i64) can never enter a `[lin] i64` parameter —
//! unify(i64, ("qual" lin i64)) is a deliberate mis. The
//! discipline-clean positives therefore ride DEFINED-BUT-UNCALLED
//! linear functions (the checker's use-count walk and the infer's
//! body inference both run over every define — the discipline is
//! exercised statically, the runtime value stays plain); the
//! DEGRADE family (the unknown atom, the duplicate — QL-2's
//! resolver rulings) resolves to dyn, dyn absorbs the literal, and
//! those programs run with real calls.
//!
//! Case families (14 positive : 42 negative = 1:3 exact, the
//! negative side spanning at least three classes): the
//! consumption-clean family (the param/let/ret
//! transfers, the branch-zone per-path merge, the two-atom comma
//! form, the [un] no-discipline pins both directions, the escape
//! faces — capture / assignment / shadowing refuse to judge, the
//! soundness pin: a capture plus a direct reference must NOT
//! false-accuse), the effect-orthogonal family (Q3: a linear value
//! consumed through a perform argument inside a handler); against
//! eight E0014 rows (the count payloads 2 and 3, the cross-fn
//! double, the branch then-doubling, the nested-branch
//! composition, the let-scope row, the param-order report, the
//! perform-arg double), six E0015 rows (the dropped param/let, the
//! branch one-side drops, the closure-carried site, the param
//! order), the both-fire rows (one path drops while another
//! doubles; one param drops while another doubles), eight
//! E0013/E0009 divergence rows through the skin (the use-site, the
//! ret, the let predicate mismatch, the row-x-qual annotation, the
//! plain callee, the ret composite, the ret literal, the
//! literal-call boundary), eight read-guard rows (the body-less
//! qual, the spaced atoms, the row missing-colon fork guard, the
//! non-ident atom, the unclosed form, the trailing comma, the eof
//! cuts, the let-position guard), the multi-error interplay rows
//! (the unbound-plus-zero and arity-plus-multi collections, the
//! captured-assignment boundary staying E0012-only, the composite
//! body divergence), the report-order rows (three findings in one
//! program; the mixed-severity define order), and the composite
//! family (the nested-qual ret, the atom-order unification, the
//! bool-demand condition, the branch-zone let transfer).

use kerf::driver::{Engine, Session, parse_target};
use kerf::vm::{BufferIo, Value};

/// The r139 deep-stack precedent: the twin segments compile the
/// selfhost-scale programs, so the driver needs the large stack.
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(512 * 1024 * 1024)
        .spawn(body)
        .expect("deep-stack thread")
        .join()
        .expect("deep-stack join");
}

fn parse(source: &str) -> Result<kerf::driver::ParsedProgram, Vec<kerf::driver::Diagnostic>> {
    let mut session = Session::new();
    parse_target(&mut session, "qual-skin-case.ktf", source)
}

/// The full findings probe (BOTH severities — E0015 warnings ride
/// here; the E0014 errors abort the run).
fn diags(source: &str) -> Vec<String> {
    let program = parse(source).expect("the case parses");
    program
        .typecheck()
        .iter()
        .map(|d| d.message.clone())
        .collect::<Vec<_>>()
}

fn run(source: &str) -> Result<String, Vec<kerf::driver::Diagnostic>> {
    let program = parse(source)?;
    let outcome = program.run(Engine::Vm, Box::new(BufferIo::default()))?;
    let entry = outcome
        .globals
        .iter()
        .find(|(name, _)| name.as_str() == "result")
        .map(|(_, v)| v.clone())
        .unwrap_or(Value::Nil);
    Ok(format!("{entry}"))
}

/// The clean pin: zero findings AND the run reaches the value.
fn clean(src: &str, value: &str) {
    let d = diags(src);
    assert!(d.is_empty(), "the clean case carries no findings: {d:?}");
    let v = run(src).expect("the clean case runs");
    assert_eq!(v, value);
}

/// The findings pin: the exact message list, in order.
fn findings(src: &str, want: &[&str]) {
    let d = diags(src);
    let joined = d.join("; ");
    for w in want {
        assert!(joined.contains(w), "the case must report `{w}`: got {d:?}");
    }
}

/// The read-guard pin: the parse rejects.
fn rejects(src: &str) {
    assert!(parse(src).is_err(), "the case must reject: {src}");
}

// ---------- the positive family (14) ----------

#[test]
fn us01_param_single_consume_is_clean() {
    deep_stack(|| {
        clean(
            "fn f(x: [lin] i64) { car(pair(x, nil)) }\ndefine(result, 42);",
            "42",
        );
    });
}

#[test]
fn us02_cross_fn_lin_to_lin_transfer() {
    deep_stack(|| {
        clean(
            "fn g(y: [lin] i64) { car(pair(y, nil)) }\nfn f(x: [lin] i64) { g(x) }\ndefine(result, 42);",
            "42",
        );
    });
}

#[test]
fn us03_let_transfer_counts_both_rows() {
    deep_stack(|| {
        clean(
            "fn f(x: [lin] i64) { let y: [lin] i64 = x; car(pair(y, nil)) }\ndefine(result, 42);",
            "42",
        );
    });
}

#[test]
fn us04_ret_annotated_transfer_unifies_green() {
    deep_stack(|| {
        clean(
            "fn f(x: [lin] i64) -> [lin] i64 { x }\ndefine(result, 42);",
            "42",
        );
    });
}

#[test]
fn us05_branch_both_sides_consume_once() {
    deep_stack(|| {
        clean(
            "fn f(c: bool, x: [lin] i64) { if c { car(pair(x, nil)) } else { car(pair(x, nil)) } }\ndefine(result, 42);",
            "42",
        );
    });
}

#[test]
fn us06_two_atom_comma_form_is_linear() {
    deep_stack(|| {
        clean(
            "fn f(x: [lin, un] i64) { car(pair(x, nil)) }\ndefine(result, 42);",
            "42",
        );
    });
}

#[test]
fn us07_un_dropped_never_warns() {
    deep_stack(|| {
        clean("fn f(x: [un] i64) { 42 }\ndefine(result, 42);", "42");
    });
}

#[test]
fn us08_un_doubled_never_errors() {
    deep_stack(|| {
        clean(
            "fn f(x: [un] i64) { pair(pair(x, nil), pair(x, nil)) }\ndefine(result, 42);",
            "42",
        );
    });
}

#[test]
fn us09_capture_and_direct_reference_escape_soundly() {
    deep_stack(|| {
        // Two syntactic references, one captured by the closure:
        // the capture leaves the static face, the row escapes, and
        // the count face refuses to judge — no false E0014 (the
        // soundness pin of the conservative degradation family).
        clean(
            "fn f(x: [lin] i64) { let g = ||() { car(pair(x, nil)) }; pair(x, nil) }\ndefine(result, 42);",
            "42",
        );
    });
}

#[test]
fn us10_assignment_target_escapes() {
    deep_stack(|| {
        clean(
            "fn f(x: [lin] i64) { set(x, x); car(x) }\ndefine(result, 42);",
            "42",
        );
    });
}

#[test]
fn us11_let_shadow_escapes_the_outer_row() {
    deep_stack(|| {
        clean(
            "fn f(x: [lin] i64) { let x = 8; x }\ndefine(result, 42);",
            "42",
        );
    });
}

#[test]
fn us12_unpinned_atom_degrades_and_runs() {
    deep_stack(|| {
        // The unknown atom degrades the whole spec to dyn (QL-2),
        // dyn absorbs the literal call — and the checker mirrors
        // the degrade: no discipline, no judgment.
        clean("fn f(x: [bad] i64) { 42 }\ndefine(result, f(7));", "42");
    });
}

#[test]
fn us13_duplicate_atom_degrades_and_runs() {
    deep_stack(|| {
        clean(
            "fn f(x: [lin, lin] i64) { 42 }\ndefine(result, f(7));",
            "42",
        );
    });
}

#[test]
fn us14_effect_axis_stays_orthogonal() {
    deep_stack(|| {
        // Q3: the perform argument counts as the one consumption
        // and the handler machinery rides untouched — the effect
        // row on the arrow and the qualifier on the value are
        // different slots (the P2 shape freeze's own pin).
        clean(
            "fn f(x: [lin] i64) { handle (perform give(x)) { give(v) => { car(pair(v, nil)) }, } }\ndefine(result, 42);",
            "42",
        );
    });
}

// ---------- the E0014 family (8) ----------

#[test]
fn n01_double_consume_reports_count_two() {
    deep_stack(|| {
        let src = "fn f(x: [lin] i64) { pair(pair(x, nil), pair(x, nil)) }\ndefine(result, 42);";
        findings(src, &["linear value `x` consumed `2` times"]);
        assert!(run(src).is_err(), "E0014 is error severity");
    });
}

#[test]
fn n02_triple_consume_reports_count_three() {
    deep_stack(|| {
        findings(
            "fn f(x: [lin] i64) { pair(pair(x, nil), pair(pair(x, nil), pair(x, nil))) }\ndefine(result, 42);",
            &["linear value `x` consumed `3` times"],
        );
    });
}

#[test]
fn n03_cross_fn_double_fires_on_the_caller() {
    deep_stack(|| {
        let src = "fn g(y: [lin] i64) { car(pair(y, nil)) }\nfn f(x: [lin] i64) { pair(g(x), g(x)) }\ndefine(result, 42);";
        let d = diags(src);
        assert_eq!(d.len(), 1, "only the caller's row reports: {d:?}");
        findings(src, &["linear value `x` consumed `2` times"]);
    });
}

#[test]
fn n04_branch_then_doubling_caps_the_hi_end() {
    deep_stack(|| {
        findings(
            "fn f(c: bool, x: [lin] i64) { if c { pair(pair(x, nil), pair(x, nil)) } else { car(pair(x, nil)) } }\ndefine(result, 42);",
            &["linear value `x` consumed `2` times"],
        );
    });
}

#[test]
fn n05_nested_branch_zone_composes() {
    deep_stack(|| {
        findings(
            "fn f(c: bool, d: bool, x: [lin] i64) { if c { if d { pair(x, nil) } else { pair(x, nil) } } else { pair(pair(x, nil), pair(x, nil)) } }\ndefine(result, 42);",
            &["linear value `x` consumed `2` times"],
        );
    });
}

#[test]
fn n06_let_scope_row_counts_and_reports() {
    deep_stack(|| {
        let src = "fn f(x: [lin] i64) { let y: [lin] i64 = x; pair(pair(y, nil), pair(y, nil)) }\ndefine(result, 42);";
        let d = diags(src);
        assert_eq!(d.len(), 1, "the transfer consumes x once; y doubles: {d:?}");
        findings(src, &["linear value `y` consumed `2` times"]);
    });
}

#[test]
fn n07_two_params_report_in_param_order() {
    deep_stack(|| {
        let src = "fn f(a: [lin] i64, b: [lin] i64) { pair(pair(a, nil), pair(a, nil)) }\ndefine(result, 42);";
        // a doubles; b drops — both fire, a first.
        findings(
            src,
            &[
                "linear value `a` consumed `2` times",
                "linear value `b` is never consumed",
            ],
        );
        let d = diags(src);
        assert_eq!(d.len(), 2, "both param rows report in order: {d:?}");
    });
}

#[test]
fn n08_perform_arg_double_fires_through_the_effect_face() {
    deep_stack(|| {
        findings(
            "fn f(x: [lin] i64) { pair(x, nil); handle (perform give(x)) { give(v) => { v }, } }\ndefine(result, 42);",
            &["linear value `x` consumed `2` times"],
        );
    });
}

// ---------- the E0015 family (6) ----------

#[test]
fn n09_dropped_param_warns_and_runs() {
    deep_stack(|| {
        let src = "fn f(x: [lin] i64) { 42 }\ndefine(result, 42);";
        findings(src, &["linear value `x` is never consumed"]);
        let v = run(src).expect("the warning never blocks");
        assert_eq!(v, "42");
    });
}

#[test]
fn n10_dropped_let_row_warns() {
    deep_stack(|| {
        let src = "fn f(x: [lin] i64) { let y: [lin] i64 = x; 42 }\ndefine(result, 42);";
        let d = diags(src);
        assert_eq!(d.len(), 1, "x transfers once; y drops: {d:?}");
        findings(src, &["linear value `y` is never consumed"]);
    });
}

#[test]
fn n11_branch_else_dropping_floors_the_lo_end() {
    deep_stack(|| {
        let src = "fn f(c: bool, x: [lin] i64) { if c { car(pair(x, nil)) } else { 42 } }\ndefine(result, 42);";
        findings(src, &["linear value `x` is never consumed"]);
        let v = run(src).expect("the warning never blocks");
        assert_eq!(v, "42");
    });
}

#[test]
fn n12_branch_then_dropping_floors_the_lo_end() {
    deep_stack(|| {
        findings(
            "fn f(c: bool, x: [lin] i64) { if c { 42 } else { car(pair(x, nil)) } }\ndefine(result, 42);",
            &["linear value `x` is never consumed"],
        );
    });
}

#[test]
fn n13_closure_carried_site_drops() {
    deep_stack(|| {
        // The fn-ann carrier (the annotated closure param) rides
        // the same machinery — the closure's own exit reports.
        findings(
            "fn f() { let g = ||(x: [lin] i64) { 42 }; 8 }\ndefine(result, 42);",
            &["linear value `x` is never consumed"],
        );
    });
}

#[test]
fn n14_two_dropped_params_report_in_order() {
    deep_stack(|| {
        let src = "fn f(a: [lin] i64, b: [lin] i64) { 42 }\ndefine(result, 42);";
        findings(
            src,
            &[
                "linear value `a` is never consumed",
                "linear value `b` is never consumed",
            ],
        );
        let d = diags(src);
        assert_eq!(d.len(), 2, "both drops report in param order: {d:?}");
    });
}

// ---------- the both-fire family (2) ----------

#[test]
fn n15_one_path_drops_while_another_doubles() {
    deep_stack(|| {
        let src = "fn f(c: bool, x: [lin] i64) { if c { pair(pair(x, nil), pair(x, nil)) } else { 42 } }\ndefine(result, 42);";
        findings(
            src,
            &[
                "linear value `x` consumed `2` times",
                "linear value `x` is never consumed",
            ],
        );
        assert!(run(src).is_err(), "the E0014 half still aborts");
    });
}

#[test]
fn n16_cross_family_report_order_pins() {
    deep_stack(|| {
        let src = "fn g(x: [lin] i64) { 42 }\nfn f(a: [lin] i64, b: [lin] i64) { pair(pair(b, nil), pair(b, nil)) }\ndefine(result, 42);";
        // g's x drops (warning); f's a drops (warning), b doubles
        // (error) — the define order then the param order.
        findings(
            src,
            &[
                "linear value `x` is never consumed",
                "linear value `a` is never consumed",
                "linear value `b` consumed `2` times",
            ],
        );
    });
}

// ---------- the E0013/E0009 divergence family (8) ----------

#[test]
fn n17_use_site_divergence_surfaces_as_e0009() {
    deep_stack(|| {
        // The + builtin demands i64; the linear param carries its
        // qualifier — the use site surfaces the divergence.
        findings(
            "fn f(x: [lin] i64) { x + 1 }\ndefine(result, 42);",
            &["type mismatch"],
        );
    });
}

#[test]
fn n18_ret_annotation_diverges() {
    deep_stack(|| {
        findings(
            "fn f(x: [lin] i64) -> i64 { x }\ndefine(result, 42);",
            &["annotation"],
        );
    });
}

#[test]
fn n19_let_predicate_mismatch_diverges() {
    deep_stack(|| {
        findings(
            "fn f(x: [lin] i64) { let y: [un] i64 = x; car(pair(y, nil)) }\ndefine(result, 42);",
            &["annotation"],
        );
    });
}

#[test]
fn n20_let_row_annotation_meets_qual_value() {
    deep_stack(|| {
        findings(
            "fn f(x: [lin] i64) { let y: [x: i64] = x; car(y) }\ndefine(result, 42);",
            &["annotation"],
        );
    });
}

#[test]
fn n21_plain_callee_rejects_the_linear_argument() {
    deep_stack(|| {
        findings(
            "fn g(y: i64) { y }\nfn f(x: [lin] i64) { g(x) }\ndefine(result, 42);",
            &["type mismatch"],
        );
    });
}

#[test]
fn n22_ret_qual_vs_composite_body_diverges() {
    deep_stack(|| {
        findings(
            "fn f(x: [lin] i64) -> [lin] i64 { pair(x, nil) }\ndefine(result, 42);",
            &["annotation"],
        );
    });
}

#[test]
fn n23_ret_qual_vs_literal_body_diverges() {
    deep_stack(|| {
        findings(
            "fn f(x: [lin] i64) -> [lin] i64 { 7 }\ndefine(result, 42);",
            &["annotation"],
        );
    });
}

#[test]
fn n24_literal_call_boundary_is_a_mis() {
    deep_stack(|| {
        // The literal-entry boundary: i64 never enters a
        // qualified parameter (the kernel's exact-predicate
        // discipline — the entailment face is the deferred blade).
        findings(
            "fn f(x: [lin] i64) { car(pair(x, nil)) }\ndefine(result, f(7));",
            &["type mismatch"],
        );
    });
}

// ---------- the read-guard family (8) ----------

#[test]
fn n25_qual_without_body_rejects() {
    deep_stack(|| {
        rejects("fn f(x: [lin]) { 42 }\ndefine(result, 42);");
    });
}

#[test]
fn n26_spaced_atoms_reject() {
    deep_stack(|| {
        rejects("fn f(x: [lin un] i64) { 42 }\ndefine(result, 42);");
    });
}

#[test]
fn n27_row_missing_colon_fork_still_rejects() {
    deep_stack(|| {
        // The fork must not swallow the malformed row: [x i64]
        // enters the qual fork and dies on the non-separator.
        rejects("fn f(r: [x i64]) { 42 }\ndefine(result, 42);");
    });
}

#[test]
fn n28_non_ident_atom_rejects() {
    deep_stack(|| {
        rejects("fn f(x: [1] i64) { 42 }\ndefine(result, 42);");
    });
}

#[test]
fn n29_unclosed_qual_rejects() {
    deep_stack(|| {
        rejects("fn f(x: [lin i64) { 42 }\ndefine(result, 42);");
    });
}

#[test]
fn n30_trailing_comma_rejects() {
    deep_stack(|| {
        rejects("fn f(x: [lin,] i64) { 42 }\ndefine(result, 42);");
    });
}

#[test]
fn n31_qual_at_eof_rejects() {
    deep_stack(|| {
        rejects("fn f(x: [lin]");
    });
}

#[test]
fn n32_let_qual_without_body_rejects() {
    deep_stack(|| {
        rejects("fn f() { let y: [lin] = 1; y }\ndefine(result, 42);");
    });
}

// ---------- the multi-error interplay family (4) ----------

#[test]
fn n33_warning_and_warning_collect_together() {
    deep_stack(|| {
        // The source path's expander owns the unbound face (the
        // R1 domain is macro synthesis and programmatic consumers
        // — the sweep's own disclosure); the reachable two-warning
        // collection rides the E0008 + E0015 pair.
        let src = "fn f(x: [lin] i64) { set(first, 5); 42 }\ndefine(result, 42);";
        findings(
            src,
            &[
                "assignment rebinds builtin `first`",
                "linear value `x` is never consumed",
            ],
        );
        let v = run(src).expect("both findings are warnings — the run stays legal");
        assert_eq!(v, "42");
    });
}

#[test]
fn n34_arity_and_multi_consume_collect_together() {
    deep_stack(|| {
        let src = "fn g(y: [lin] i64) { car(pair(y, nil)) }\nfn f(x: [lin] i64) { g(x, x) }\ndefine(result, 42);";
        findings(
            src,
            &["arity mismatch", "linear value `x` consumed `2` times"],
        );
    });
}

#[test]
fn n35_captured_assignment_stays_e0012_only() {
    deep_stack(|| {
        // The assign-to-captured boundary is the checker's own
        // E0012; the use-count row escapes (the capture) and adds
        // nothing — the R-family rules ride untouched.
        let src = "fn f(x: [lin] i64) { ||(step) { set(x, step) } }\ndefine(result, 42);";
        let d = diags(src);
        assert_eq!(d.len(), 1, "the captured assignment only: {d:?}");
        findings(src, &["cannot assign to captured variable `x`"]);
    });
}

#[test]
fn n36_row_bodied_qual_diverges_at_the_use_site() {
    deep_stack(|| {
        findings(
            "fn f(x: [lin] [x: i64]) { x + 1 }\ndefine(result, 42);",
            &["type mismatch"],
        );
    });
}

// ---------- the report-order family (2) ----------

#[test]
fn n37_three_findings_in_one_program() {
    deep_stack(|| {
        // Three cross-severity findings in param order: a doubles
        // (error), b and c drop (warnings) — one walk, one stream.
        let src = "fn f(a: [lin] i64, b: [lin] i64, c: [lin] i64) { pair(pair(a, nil), pair(a, nil)) }\ndefine(result, 42);";
        let d = diags(src);
        assert_eq!(d.len(), 3, "the three rows report in param order: {d:?}");
        findings(
            src,
            &[
                "linear value `a` consumed `2` times",
                "linear value `b` is never consumed",
                "linear value `c` is never consumed",
            ],
        );
    });
}

#[test]
fn n38_mixed_severities_report_in_define_order() {
    deep_stack(|| {
        let src = "fn g(x: [lin] i64) { 42 }\nfn f(y: [lin] i64) { pair(pair(y, nil), pair(y, nil)) }\ndefine(result, 42);";
        findings(
            src,
            &[
                "linear value `x` is never consumed",
                "linear value `y` consumed `2` times",
            ],
        );
        assert!(run(src).is_err(), "the error half aborts the run");
    });
}

// ---------- the composite family (4) ----------

#[test]
fn n39_nested_qual_ret_mismatch_diverges() {
    deep_stack(|| {
        findings(
            "fn f(x: [lin] [un] i64) -> [lin] [lin] i64 { x }\ndefine(result, 42);",
            &["annotation"],
        );
    });
}

#[test]
fn n40_atom_order_matters_in_unification() {
    deep_stack(|| {
        findings(
            "fn f(x: [lin, un] i64) -> [un, lin] i64 { x }\ndefine(result, 42);",
            &["annotation"],
        );
    });
}

#[test]
fn n41_qual_condition_hits_the_bool_demand() {
    deep_stack(|| {
        findings(
            "fn f(x: [lin] i64) { if x { 1 } else { 2 } }\ndefine(result, 42);",
            &["type mismatch"],
        );
    });
}

#[test]
fn n42_transfer_via_annotated_let_then_double() {
    deep_stack(|| {
        // x transfers once into y (clean); y doubles inside a
        // branch zone — the let row rides the zone merge.
        findings(
            "fn f(c: bool, x: [lin] i64) { let y: [lin] i64 = x; if c { pair(pair(y, nil), pair(y, nil)) } else { car(pair(y, nil)) } }\ndefine(result, 42);",
            &["linear value `y` consumed `2` times"],
        );
    });
}

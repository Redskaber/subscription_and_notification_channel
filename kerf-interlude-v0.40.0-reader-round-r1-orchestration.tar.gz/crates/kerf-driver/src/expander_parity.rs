//! Stage 1.7 macro parity  -  the third self-hosted front-end
//! segment (docs/stage0.md §9.48.4, plan-1.7.md). The macro layer
//! layer of the expander, rewritten in the frozen kerf subset
//! itself (`selfhost/v1/macro.krf` assembled ahead of `expander.krf`
//! expander oracle byte-for-byte on both axes:
//!
//! * **Tree axis**  -  the oracle `ModuleItem` tree (expansion plus
//!   the loader's validation pass, exactly the `pipeline::parse`
//!   composition) and the `.krf` expander's `("ok" items...)`
//!   result normalize to the same dump: item records, expression
//!   records, literal-value records (Pair chains right-nested,
//!   floats as Debug text).
//! * **Error axis**  -  the `.krf` expander reports a *structured*
//!   rejection (`("err" kind payload...)`); the harness rebuilds
//!   the `ExpandError` / `ModuleError` and renders it through the
//!   oracle's own `Display`, so byte parity holds by construction
//!   and the non-trivial part under test is the kind / payload /
//!   span selection (the seven span traps plus the 1.7
//!
//! `macro-mismatch` arm).
//!
//! The forms stream is source-injected (EX-1, 1.7 addendum: every
//! record carries a trailing generation int - source records ride
//! generation 0, macro products carry use_gen + 1): the host runs the
//! Rust reader  -  the single source of tree truth  -  and prepends a
//! *flat pre-order* record stream as `(define forms (quote (...)))`
//! ahead of the expander source. A `("list" s e n)` record's n
//! children follow it in the stream; the flat shape keeps the
//! assembled source inside the reader's 256 nesting cap even for
//! 255-deep trees (a nested encoding would need depth+3). Spans
//! ride as decimal strings; floats ride as Debug-text strings (the
//! 1.5 conventions, unchanged).
//!
//! Two layers decide a case (MX-3 - the 1.6 three-layer split
//! collapses; define-syntax sources run the assembled program too):
//! sources the *reader* rejects take the
//! [`ExpanderParityLayer::Reader`] path (the 1.5 parity owns that
//! face); everything else runs the assembled `.krf` expander on
//! **both engines** (the `run_parity` lineage).
//! [`ExpanderParityLayer::Macro`] survives as a sentinel: the
//! corpus sweep asserts zero routing. Rename encoding (MX-1):
//! renamed identifiers ride as structured mangled records; the
//! host decodes `format!("{base}__macro_{counter}")`. Fixpoint
//! gate B (MX-6): axis (a) bytecode equality via the host
//! rebuilder, axis (b) the assembled-source self-application
//! fixpoint.
//!
//! Payload conventions (the `.krf` expander never inspects
//! payloads  -  it passes records through; the host re-reads them):
//! spans and floats as above; ints/bools/strings as typed literals.

use kerf_core::{Binding, CoreError, CoreExpr, HandlerClause, LiteralValue, ModuleItem};
use kerf_expander::{ExpandError, ModuleError, expand_program, load_program};
use kerf_reader::read_program;
use kerf_runtime::Evaluator;
use kerf_span::{ByteOffset, ExpansionId, FileId, Span, Symbol};
use kerf_syntax::{StxDatum, SyntaxObject};
use kerf_vm::{BufferIo, Heap, Value, Vm};

use crate::diagnostic::Severity;
use crate::pipeline;
use crate::reader_parity::{as_str, encode_string_literal, parse_span, value_elems};
use crate::session::Session;

/// The self-hosted macro-layer library (MX-2: assembled ahead of
/// the expansion layer - single source, never a copy).
pub const MACRO_SOURCE: &str = include_str!("../../../selfhost/v1/macro.krf");

/// The self-hosted expansion-layer expander, embedded from the
/// workspace's bootstrap face (single source  -  tests and any future
/// CLI face consume this constant, never a copy).
pub const EXPANDER_SOURCE: &str = include_str!("../../../selfhost/v1/expander.krf");

/// The assembled expander program (MX-2): the macro library body
/// first, the expansion layer second, one program.
pub fn assembled_expander_source() -> String {
    format!("{MACRO_SOURCE}\n{EXPANDER_SOURCE}")
}

/// Which layer produced a case's verdict.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ExpanderParityLayer {
    /// The Rust reader rejected the source. The `.krf` expansion
    /// layer is not exercised: the 1.5 reader parity owns that
    /// face.
    Reader,
    /// The source declares a macro (`define-syntax`): the Rust
    /// oracle decides. `SyntaxRules` (parse / instantiate /
    /// generation spans / rename-on-capture) is the 1.7 window  -
    /// §9.47.4 EX-3.
    Macro,
    /// The `.krf` expander ran on both engines and was compared
    /// against the Rust oracle (item trees, or the structured
    /// rejections).
    Expander,
}

/// One rebuilt rejection: an expansion error or a loader error
/// (the loader runs right after expansion in the production
/// pipeline  -  `pipeline::parse`  -  so both surfaces are in parity
/// scope for the 1.6 segment).
#[derive(Debug, Clone, PartialEq)]
pub enum ParityError {
    Expand(ExpandError),
    Module(ModuleError),
}

impl std::fmt::Display for ParityError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            ParityError::Expand(err) => err.fmt(f),
            ParityError::Module(err) => err.fmt(f),
        }
    }
}

/// The `.krf` expander's decoded verdict for one engine run.
#[derive(Debug, Clone, PartialEq)]
pub enum KrfVerdict {
    /// `("ok" item...)`  -  the normalized item-tree dump.
    Tree(String),
    /// `("err" kind payload...)`  -  the rebuilt rejection.
    Error(ParityError),
}

impl KrfVerdict {
    /// The rendered comparison text (item dump, or the parity-key
    /// form of the rebuilt error). §9.56 DIAG-1: the stage Display is
    /// position-free, so the harness appends the span payload
    /// itself — the comparison key must distinguish payloads (the
    /// drift detector depends on it), exactly like the tree-axis
    /// item dumps carry their `s e` offsets.
    fn text(&self) -> String {
        match self {
            KrfVerdict::Tree(dump) => dump.clone(),
            KrfVerdict::Error(err) => error_parity_key(err),
        }
    }
}

/// The error-axis parity key: stage Display + harness-rendered span
/// payload (§9.56 DIAG-1 compensation — spans ride in the payload,
/// the key surfaces them).
fn error_parity_key(err: &ParityError) -> String {
    let span = match err {
        ParityError::Expand(e) => e.span(),
        ParityError::Module(e) => e.span(),
    };
    format!("{err} @ {span}")
}

/// The oracle's normalized outcome for one read-able source.
#[derive(Debug, Clone, PartialEq)]
enum OracleOutcome {
    Tree(String),
    Error(String),
}

/// The outcome of one expander-parity case.
#[derive(Debug, Clone)]
pub struct ExpanderParityReport {
    /// The case name (caller-supplied, for corpus attribution).
    pub case: String,
    /// Which layer decided the case.
    pub layer: ExpanderParityLayer,
    /// The oracle's normalized item-tree dump, or its rendered
    /// rejection.
    pub oracle: String,
    /// The `.krf` layer's matching form (`None` on the reader and
    /// macro layers, or a harness defect).
    pub krf: Option<String>,
    /// Both engines agreed on the `result` global's verdict.
    pub engines_agree: bool,
    /// Oracle and `.krf` layer agree (tree axis or error axis).
    pub matched: bool,
    /// The mismatch description when `!matched` (both sides shown).
    pub drift: Option<String>,
}

impl ExpanderParityReport {
    /// The one-line failure form (the parity.rs `failure_line`
    /// lineage  -  corpus manifests print this on drift).
    pub fn failure_line(&self) -> String {
        match &self.drift {
            Some(d) => format!("expander parity FAIL [{}]: {}", self.case, d),
            None => format!("expander parity PASS [{}]", self.case),
        }
    }
}

// ---------- EX-1: the source-injected forms stream ----------

/// Emit one tree node into the flat pre-order stream: atoms close
/// themselves; a list emits `("list" s e n)` and its n children
/// follow as the next records.
fn emit_stream_node(node: &SyntaxObject, out: &mut String) {
    let (s, e) = (node.span.start.0.to_string(), node.span.end.0.to_string());
    match &node.datum {
        StxDatum::Symbol(sym) => {
            out.push_str(&format!(
                "(\"ident\" \"{s}\" \"{e}\" {} 0)",
                encode_string_literal(sym.as_str())
            ));
        }
        StxDatum::Int(v) => {
            out.push_str(&format!("(\"int\" \"{s}\" \"{e}\" {v} 0)"));
        }
        StxDatum::Float(v) => {
            // Debug text rides as a string (the 1.5 convention).
            out.push_str(&format!(
                "(\"float\" \"{s}\" \"{e}\" {} 0)",
                encode_string_literal(&format!("{v:?}"))
            ));
        }
        StxDatum::Bool(v) => {
            let lit = if *v { "#t" } else { "#f" };
            out.push_str(&format!("(\"bool\" \"{s}\" \"{e}\" {lit} 0)"));
        }
        StxDatum::String(v) => {
            out.push_str(&format!(
                "(\"string\" \"{s}\" \"{e}\" {} 0)",
                encode_string_literal(v)
            ));
        }
        StxDatum::List(items) => {
            out.push_str(&format!("(\"list\" \"{s}\" \"{e}\" {} 0)", items.len()));
            for item in items {
                out.push(' ');
                emit_stream_node(item, out);
            }
        }
    }
}

/// Build the `(define forms (quote (...)))` prefix for one
/// already-read form list (the caller split the reader layer).
pub fn forms_stream_prefix(forms: &[SyntaxObject]) -> String {
    let mut out = String::from("(define forms (quote (");
    for (i, form) in forms.iter().enumerate() {
        if i > 0 {
            out.push(' ');
        }
        emit_stream_node(form, &mut out);
    }
    out.push_str(")))");
    out
}

// ---------- EX-4: the two normalizers (tree axis) ----------

/// The oracle's normalized dump: items as `(kind start end
/// payload...)`  -  the same record grammar the `.krf` expander
/// emits.
pub fn oracle_dump_items(items: &[ModuleItem]) -> String {
    let mut out = String::new();
    for (i, item) in items.iter().enumerate() {
        if i > 0 {
            out.push(' ');
        }
        dump_oracle_item(item, &mut out);
    }
    out
}

fn dump_oracle_item(item: &ModuleItem, out: &mut String) {
    match item {
        ModuleItem::Define { span, name, value } => {
            out.push_str(&format!(
                "(define {} {} {} ",
                span.start.0,
                span.end.0,
                name.as_str()
            ));
            dump_oracle_expr(value, out);
            out.push(')');
        }
        ModuleItem::Require { span, module } => {
            out.push_str(&format!(
                "(require {} {} {})",
                span.start.0,
                span.end.0,
                module.as_str()
            ));
        }
        ModuleItem::Module { span, name, items } => {
            out.push_str(&format!(
                "(module {} {} {}",
                span.start.0,
                span.end.0,
                name.as_str()
            ));
            for inner in items {
                out.push(' ');
                dump_oracle_item(inner, out);
            }
            out.push(')');
        }
        ModuleItem::DefineSyntax { span, name } => {
            out.push_str(&format!(
                "(defsyn {} {} {})",
                span.start.0,
                span.end.0,
                name.as_str()
            ));
        }
    }
}

fn dump_oracle_expr(expr: &CoreExpr, out: &mut String) {
    let span = expr_span(expr);
    match expr {
        CoreExpr::Fn { params, body, .. } => {
            out.push_str(&format!("(fn {} {} (", span.start.0, span.end.0));
            for (i, p) in params.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                out.push_str(p.as_str());
            }
            out.push_str(") ");
            dump_oracle_expr(body, out);
            out.push(')');
        }
        CoreExpr::Apply { func, args, .. } => {
            out.push_str(&format!("(apply {} {} ", span.start.0, span.end.0));
            dump_oracle_expr(func, out);
            for arg in args {
                out.push(' ');
                dump_oracle_expr(arg, out);
            }
            out.push(')');
        }
        CoreExpr::If {
            cond,
            then_branch,
            else_branch,
            ..
        } => {
            out.push_str(&format!("(if {} {} ", span.start.0, span.end.0));
            dump_oracle_expr(cond, out);
            out.push(' ');
            dump_oracle_expr(then_branch, out);
            out.push(' ');
            dump_oracle_expr(else_branch, out);
            out.push(')');
        }
        CoreExpr::Var { name, .. } => {
            out.push_str(&format!(
                "(var {} {} {})",
                span.start.0,
                span.end.0,
                name.as_str()
            ));
        }
        CoreExpr::Literal { value, .. } => {
            out.push_str(&format!("(lit {} {} ", span.start.0, span.end.0));
            dump_oracle_lit(value, out);
            out.push(')');
        }
        CoreExpr::Assign { name, value, .. } => {
            out.push_str(&format!(
                "(assign {} {} {} ",
                span.start.0,
                span.end.0,
                name.as_str()
            ));
            dump_oracle_expr(value, out);
            out.push(')');
        }
        CoreExpr::Let { bindings, body, .. } => {
            out.push_str(&format!("(let {} {} (", span.start.0, span.end.0));
            for (i, b) in bindings.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                dump_oracle_binding(b, out);
            }
            out.push_str(") ");
            dump_oracle_expr(body, out);
            out.push(')');
        }
        CoreExpr::Perform { effect, args, .. } => {
            out.push_str(&format!(
                "(perform {} {} {}",
                span.start.0,
                span.end.0,
                effect.as_str()
            ));
            for arg in args {
                out.push(' ');
                dump_oracle_expr(arg, out);
            }
            out.push(')');
        }
        CoreExpr::Handle { body, handlers, .. } => {
            out.push_str(&format!("(handle {} {} ", span.start.0, span.end.0));
            dump_oracle_expr(body, out);
            out.push_str(" (");
            for (i, h) in handlers.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                dump_oracle_clause(h, out);
            }
            out.push_str("))");
        }
    }
}

/// Every CoreExpr variant carries a `span` field (the constructor
/// contract); this reads it without consuming the enum.
fn expr_span(expr: &CoreExpr) -> Span {
    match expr {
        CoreExpr::Fn { span, .. }
        | CoreExpr::Apply { span, .. }
        | CoreExpr::If { span, .. }
        | CoreExpr::Var { span, .. }
        | CoreExpr::Literal { span, .. }
        | CoreExpr::Assign { span, .. }
        | CoreExpr::Let { span, .. }
        | CoreExpr::Perform { span, .. }
        | CoreExpr::Handle { span, .. } => *span,
    }
}

fn dump_oracle_binding(b: &Binding, out: &mut String) {
    out.push_str(&format!("({} {} ", b.span.start.0, b.span.end.0));
    out.push_str(b.name.as_str());
    out.push(' ');
    dump_oracle_expr(&b.value, out);
    out.push(')');
}

fn dump_oracle_clause(h: &HandlerClause, out: &mut String) {
    out.push_str(&format!("({} {} ", h.span.start.0, h.span.end.0));
    out.push_str(h.effect.as_str());
    out.push(' ');
    dump_oracle_expr(&h.handler, out);
    out.push(')');
}

fn dump_oracle_lit(value: &LiteralValue, out: &mut String) {
    match value {
        LiteralValue::Int(v) => out.push_str(&format!("(int {v})")),
        LiteralValue::Float(v) => out.push_str(&format!("(float {v:?})")),
        LiteralValue::Bool(v) => out.push_str(&format!("(bool {v})")),
        LiteralValue::String(v) => out.push_str(&format!("(string {v:?})")),
        LiteralValue::Nil => out.push_str("nil"),
        LiteralValue::Pair(a, b) => {
            out.push_str("(pair ");
            dump_oracle_lit(a, out);
            out.push(' ');
            dump_oracle_lit(b, out);
            out.push(')');
        }
    }
}

// The `.krf` expander's normalized item dump (the same grammar as
// [`oracle_dump_items`]; span strings re-parse to offsets, float
// text rides verbatim).

/// A dump-record name field: either a plain string (a source
/// identifier) or a structured mangled record
/// `("mangled" s e base counter gen)` (a renamed introduced
/// identifier - MX-1). Decoded here to the concatenated form the
/// oracle carries, so the byte comparison covers the rename
/// decision face (which symbol renamed, which counter) while the
/// deterministic rendering stays host-side.
fn krf_name(v: &Value, heap: &Heap) -> Result<String, String> {
    if let Value::Str(s) = v {
        return Ok(s.as_str().to_owned());
    }
    let elems = value_elems(v, heap)?;
    if elems.len() >= 5 && as_str(elems[0])? == "mangled" {
        let base = as_str(elems[3])?;
        let counter = match elems[4] {
            Value::Int(n) => n,
            other => return Err(format!("mangled counter is not an int: {other:?}")),
        };
        return Ok(format!("{base}__macro_{counter}"));
    }
    Err(format!(
        "expected a name (string or mangled record), found {v:?}"
    ))
}

fn dump_krf_item(value: &Value, heap: &Heap, out: &mut String) -> Result<(), String> {
    let elems = value_elems(value, heap)?;
    if elems.len() < 4 {
        return Err(format!(
            "item record has {} fields, need at least kind/start/end/payload",
            elems.len()
        ));
    }
    let kind = as_str(elems[0])?.to_string();
    let s = parse_span(elems[1])?;
    let e = parse_span(elems[2])?;
    match kind.as_str() {
        "define" => {
            let name = krf_name(elems[3], heap)?;
            out.push_str(&format!("(define {s} {e} {name} "));
            dump_krf_expr(elems[4], heap, out)?;
            out.push(')');
        }
        "require" => {
            let module = krf_name(elems[3], heap)?;
            out.push_str(&format!("(require {s} {e} {module})"));
        }
        "module" => {
            let name = krf_name(elems[3], heap)?;
            out.push_str(&format!("(module {s} {e} {name}"));
            for child in &elems[4..] {
                out.push(' ');
                dump_krf_item(child, heap, out)?;
            }
            out.push(')');
        }
        "defsyn" => {
            let name = krf_name(elems[3], heap)?;
            out.push_str(&format!("(defsyn {s} {e} {name})"));
        }
        other => return Err(format!("unknown item kind `{other}`")),
    }
    Ok(())
}

fn dump_krf_expr(value: &Value, heap: &Heap, out: &mut String) -> Result<(), String> {
    let elems = value_elems(value, heap)?;
    if elems.len() < 4 {
        return Err(format!(
            "expr record has {} fields, need at least kind/start/end/payload",
            elems.len()
        ));
    }
    let kind = as_str(elems[0])?.to_string();
    let s = parse_span(elems[1])?;
    let e = parse_span(elems[2])?;
    match kind.as_str() {
        "fn" => {
            let params = value_elems(elems[3], heap)?;
            out.push_str(&format!("(fn {s} {e} ("));
            for (i, p) in params.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                out.push_str(&krf_name(p, heap)?);
            }
            out.push_str(") ");
            dump_krf_expr(elems[4], heap, out)?;
            out.push(')');
        }
        "apply" => {
            out.push_str(&format!("(apply {s} {e} "));
            dump_krf_expr(elems[3], heap, out)?;
            for arg in &elems[4..elems.len() - 1] {
                out.push(' ');
                dump_krf_expr(arg, heap, out)?;
            }
            out.push(')');
        }
        "if" => {
            out.push_str(&format!("(if {s} {e} "));
            dump_krf_expr(elems[3], heap, out)?;
            out.push(' ');
            dump_krf_expr(elems[4], heap, out)?;
            out.push(' ');
            dump_krf_expr(elems[5], heap, out)?;
            out.push(')');
        }
        "var" => {
            let name = krf_name(elems[3], heap)?;
            out.push_str(&format!("(var {s} {e} {name})"));
        }
        "lit" => {
            out.push_str(&format!("(lit {s} {e} "));
            dump_krf_litval(elems[3], heap, out)?;
            out.push(')');
        }
        "assign" => {
            let name = krf_name(elems[3], heap)?;
            out.push_str(&format!("(assign {s} {e} {name} "));
            dump_krf_expr(elems[4], heap, out)?;
            out.push(')');
        }
        "let" => {
            let bindings = value_elems(elems[3], heap)?;
            out.push_str(&format!("(let {s} {e} ("));
            for (i, b) in bindings.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                let be = value_elems(b, heap)?;
                if be.len() != 5 {
                    return Err(format!(
                        "binding record has {} fields, need bs/be/name/expr/gen",
                        be.len()
                    ));
                }
                out.push_str(&format!(
                    "({} {} {} ",
                    parse_span(be[0])?,
                    parse_span(be[1])?,
                    krf_name(be[2], heap)?
                ));
                dump_krf_expr(be[3], heap, out)?;
                out.push(')');
            }
            out.push_str(") ");
            dump_krf_expr(elems[4], heap, out)?;
            out.push(')');
        }
        "perform" => {
            let effect = krf_name(elems[3], heap)?;
            out.push_str(&format!("(perform {s} {e} {effect}"));
            for arg in &elems[4..elems.len() - 1] {
                out.push(' ');
                dump_krf_expr(arg, heap, out)?;
            }
            out.push(')');
        }
        "handle" => {
            out.push_str(&format!("(handle {s} {e} "));
            dump_krf_expr(elems[3], heap, out)?;
            out.push_str(" (");
            let clauses = value_elems(elems[4], heap)?;
            for (i, c) in clauses.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                let ce = value_elems(c, heap)?;
                if ce.len() != 5 {
                    return Err(format!(
                        "clause record has {} fields, need cs/ce/effect/handler/gen",
                        ce.len()
                    ));
                }
                out.push_str(&format!(
                    "({} {} {} ",
                    parse_span(ce[0])?,
                    parse_span(ce[1])?,
                    krf_name(ce[2], heap)?
                ));
                dump_krf_expr(ce[3], heap, out)?;
                out.push(')');
            }
            out.push_str("))");
        }
        other => return Err(format!("unknown expr kind `{other}`")),
    }
    Ok(())
}

fn dump_krf_litval(value: &Value, heap: &Heap, out: &mut String) -> Result<(), String> {
    // The nil literal is a bare nil value (no record wrapper).
    if matches!(value, Value::Nil) {
        out.push_str("nil");
        return Ok(());
    }
    let elems = value_elems(value, heap)?;
    if elems.len() < 2 {
        return Err(format!(
            "litval record has {} fields, need kind/payload",
            elems.len()
        ));
    }
    let kind = as_str(elems[0])?;
    match kind {
        "int" => {
            let v = match elems[1] {
                Value::Int(n) => *n,
                other => return Err(format!("expected an int payload, found {other:?}")),
            };
            out.push_str(&format!("(int {v})"));
        }
        "float" => {
            // Debug text rides verbatim (the stream encoded it).
            let text = as_str(elems[1])?;
            out.push_str(&format!("(float {text})"));
        }
        "bool" => {
            let v = match elems[1] {
                Value::Bool(b) => *b,
                other => return Err(format!("expected a bool payload, found {other:?}")),
            };
            out.push_str(&format!("(bool {v})"));
        }
        "string" => {
            let text = as_str(elems[1])?;
            out.push_str(&format!("(string {text:?})"));
        }
        "pair" => {
            out.push_str("(pair ");
            dump_krf_litval(elems[1], heap, out)?;
            out.push(' ');
            dump_krf_litval(elems[2], heap, out)?;
            out.push(')');
        }
        other => return Err(format!("unknown litval kind `{other}`")),
    }
    Ok(())
}

// ---------- EX-4: the structured-error rebuild (error axis) ----------

/// Rebuild a span from two decimal-string offsets (the parity file
/// is always `file#0`; generation is ROOT  -  1.6 output spans are
/// all generation-0 source spans).
fn make_span(s: &Value, e: &Value) -> Result<Span, String> {
    let start = parse_span(s)?;
    let end = parse_span(e)?;
    Span::new(
        FileId(0),
        ByteOffset(start),
        ByteOffset(end),
        ExpansionId::ROOT,
    )
    .map_err(|err| format!("reconstructed span rejected: {err:?}"))
}

/// Map a malformed-form name onto its static str (the enum field is
/// `&'static str`).
fn static_form(name: &str) -> Result<&'static str, String> {
    Ok(match name {
        "fn" => "fn",
        "if" => "if",
        "let" => "let",
        "do" => "do",
        "set!" => "set!",
        "perform" => "perform",
        "handle" => "handle",
        "quote" => "quote",
        "define" => "define",
        "require" => "require",
        "module" => "module",
        "define-syntax" => "define-syntax",
        other => return Err(format!("unknown malformed form `{other}`")),
    })
}

/// Rebuild the rejection from a `("err" kind payload...)` value.
/// The caller renders it through the oracle's own `Display`, so
/// message-text parity holds by construction; what this checks is
/// that the `.krf` expander chose the right kind and payload.
pub fn reconstruct_expand_error(value: &Value, heap: &Heap) -> Result<ParityError, String> {
    let elems = value_elems(value, heap)?;
    if elems.len() < 3 || as_str(elems[0])? != "err" {
        return Err("expected an (\"err\" kind payload...) value".to_string());
    }
    let kind = as_str(elems[1])?;
    let err = match kind {
        "unbound" => ParityError::Expand(ExpandError::UnboundIdentifier {
            // §9.65 EXP-1: the payload is the interned identity —
            // reconstruct it through the single pool, never a
            // de-interned text copy (the MOD-1 decoder precedent).
            name: Symbol::new(as_str(elems[2])?).map_err(|e| e.to_string())?,
            span: make_span(elems[3], elems[4])?,
        }),
        "macro-mismatch" => ParityError::Expand(ExpandError::MacroPatternMismatch {
            // §9.65 EXP-2: same single-pool reconstruction.
            name: Symbol::new(as_str(elems[2])?).map_err(|e| e.to_string())?,
            span: make_span(elems[3], elems[4])?,
        }),
        "malformed" => ParityError::Expand(ExpandError::MalformedForm {
            form: static_form(as_str(elems[2])?)?,
            span: make_span(elems[3], elems[4])?,
        }),
        "top" => ParityError::Expand(ExpandError::TopLevelExpression {
            span: make_span(elems[2], elems[3])?,
        }),
        "quote-datum" => ParityError::Expand(ExpandError::QuoteUnsupportedDatum {
            span: make_span(elems[2], elems[3])?,
        }),
        "depth" => ParityError::Expand(ExpandError::ExpansionDepthExceeded {
            limit: 512,
            span: make_span(elems[2], elems[3])?,
        }),
        "empty" => ParityError::Expand(ExpandError::EmptyForm {
            span: make_span(elems[2], elems[3])?,
        }),
        "dup-param" => ParityError::Expand(ExpandError::Core {
            source: CoreError::DuplicateParam {
                // §9.65 EXP-4: the payload is the interned identity —
                // rebuilt through the single pool.
                name: Symbol::new(as_str(elems[2])?).map_err(|e| e.to_string())?,
            },
            span: make_span(elems[3], elems[4])?,
        }),
        "dup-handler" => ParityError::Expand(ExpandError::Core {
            source: CoreError::DuplicateHandler {
                // §9.65 EXP-5: same single-pool reconstruction.
                effect: Symbol::new(as_str(elems[2])?).map_err(|e| e.to_string())?,
            },
            span: make_span(elems[3], elems[4])?,
        }),
        "mod-dup" => ParityError::Module(ModuleError::ModuleDuplicate {
            // §9.64 MOD-1: the payload is the interned identity —
            // reconstruct it through the single pool, never a
            // de-interned text copy.
            name: Symbol::new(as_str(elems[2])?).map_err(|e| e.to_string())?,
            span: make_span(elems[3], elems[4])?,
        }),
        "mod-missing" => ParityError::Module(ModuleError::ModuleNotFound {
            name: Symbol::new(as_str(elems[2])?).map_err(|e| e.to_string())?,
            span: make_span(elems[3], elems[4])?,
        }),
        "mod-cycle" => {
            let path_elems = value_elems(elems[2], heap)?;
            let mut path = Vec::with_capacity(path_elems.len());
            for p in path_elems {
                path.push(Symbol::new(as_str(p)?).map_err(|e| e.to_string())?);
            }
            ParityError::Module(ModuleError::ModuleCycle {
                path,
                span: make_span(elems[3], elems[4])?,
            })
        }
        other => return Err(format!("unknown error kind `{other}`")),
    };
    Ok(err)
}

/// Decode one engine's `result` global into a verdict (while that
/// engine  -  and its heap  -  is still alive).
fn decode_verdict(value: &Value, heap: &Heap) -> Result<KrfVerdict, String> {
    let elems = value_elems(value, heap)?;
    let tag = elems
        .first()
        .and_then(|v| match v {
            Value::Str(s) => Some(s.as_str()),
            _ => None,
        })
        .ok_or_else(|| "the result value is not a tagged list".to_string())?;
    match tag {
        "ok" => {
            let mut out = String::new();
            for (i, item) in elems[1..].iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                dump_krf_item(item, heap, &mut out)?;
            }
            Ok(KrfVerdict::Tree(out))
        }
        "err" => Ok(KrfVerdict::Error(reconstruct_expand_error(value, heap)?)),
        other => Err(format!("unknown verdict tag `{other}`")),
    }
}

// ---------- EX-5: the dual-engine run ----------

/// Run the assembled expander program on both engines and return
/// the two decoded verdicts. Handles stay alive until both sides
/// decode (heap-backed values)  -  the `run_parity` lineage. `Err`
/// is a harness-side defect class (the expander program itself
/// failed a pipeline stage, or produced an undecodable result)  -
/// reported as drift, never a panic.
fn run_dual(assembled: &str) -> Result<(KrfVerdict, KrfVerdict), String> {
    let mut session = Session::new();
    let program = pipeline::parse(&mut session, "expander-parity-host.krf", assembled)
        .map_err(|diags| format!("the assembled expander program failed to parse: {diags:?}"))?;
    let findings = program.typecheck();
    if findings.iter().any(|d| d.severity == Severity::Error) {
        return Err(format!(
            "the assembled expander program failed the checker: {findings:?}"
        ));
    }
    let bc = kerf_compiler::compile_program(&program.items)
        .map_err(|err| format!("the assembled expander program failed to compile: {err}"))?;
    let mut vm = Vm::with_io(bc, Box::new(BufferIo::default()))
        .map_err(|err| format!("the vm rejected the expander program: {err}"))?;
    vm.run()
        .map_err(|err| format!("the .krf expander crashed on the vm engine: {err}"))?;
    let vm_verdict = decode_verdict(
        vm.global("result")
            .ok_or_else(|| "no `result` global on the vm engine".to_string())?,
        vm.heap(),
    )?;

    let mut evaluator = Evaluator::with_io(Box::new(BufferIo::default()));
    evaluator
        .eval_program(&program.items)
        .map_err(|err| format!("the .krf expander crashed on the eval engine: {err}"))?;
    let eval_verdict = decode_verdict(
        evaluator
            .global("result")
            .ok_or_else(|| "no `result` global on the eval engine".to_string())?,
        evaluator.heap(),
    )?;
    Ok((vm_verdict, eval_verdict))
}

// ---------- MX-6 gate B: the host rebuilder + the two axes ----------

/// Rebuild a generation-carrying span from a record's span fields
/// and trailing generation int (the 1.7 record addendum; the dump
/// TEXT stays generation-free).
fn gen_span(s: &Value, e: &Value, g: &Value) -> Result<Span, String> {
    let start = parse_span(s)?;
    let end = parse_span(e)?;
    let generation = match g {
        Value::Int(n) => *n,
        other => return Err(format!("generation field is not an int: {other:?}")),
    };
    Span::new(
        FileId(0),
        ByteOffset(start),
        ByteOffset(end),
        ExpansionId(u32::try_from(generation).map_err(|_| "negative generation")?),
    )
    .map_err(|err| format!("rebuilt span rejected: {err:?}"))
}

/// The last field of a record (the generation).
fn last_field<'a>(elems: &[&'a Value]) -> Result<&'a Value, String> {
    elems
        .last()
        .copied()
        .ok_or_else(|| "empty record".to_string())
}

/// Rebuild the item tree from the `.krf` expander's result value
/// (the dump-grammar records carry the trailing generation the
/// rebuild threads into the spans; name fields decode through
/// [`krf_name`]). This is the gate-B axis (a) face: the rebuilt
/// `ModuleItem`s compile through the real `compile_program` and
/// compare by `Bytecode: PartialEq` against the oracle's own.
fn rebuild_items(value: &Value, heap: &Heap) -> Result<Vec<ModuleItem>, String> {
    let elems = value_elems(value, heap)?;
    if elems.first().and_then(|v| as_str(v).ok()) != Some("ok") {
        return Err("cannot rebuild items from a rejection".to_string());
    }
    let mut items = Vec::with_capacity(elems.len() - 1);
    for item in &elems[1..] {
        items.push(rebuild_item(item, heap)?);
    }
    Ok(items)
}

fn rebuild_item(v: &Value, heap: &Heap) -> Result<ModuleItem, String> {
    let elems = value_elems(v, heap)?;
    if elems.len() < 4 {
        return Err(format!("item record has {} fields", elems.len()));
    }
    // Declaration records carry NO generation field (source-level
    // only - an expression template cannot produce one): the
    // rebuilt span rides the ROOT generation.
    let span = make_span(elems[1], elems[2])?;
    match as_str(elems[0])? {
        "define" => {
            let name = krf_name(elems[3], heap)?;
            let value = rebuild_expr(elems[4], heap)?;
            ModuleItem::define(span, &name, value).map_err(|e| format!("{e:?}"))
        }
        "require" => {
            let module = krf_name(elems[3], heap)?;
            ModuleItem::require(span, &module).map_err(|e| format!("{e:?}"))
        }
        "module" => {
            let name = krf_name(elems[3], heap)?;
            let mut items = Vec::with_capacity(elems.len() - 4);
            for child in &elems[4..] {
                items.push(rebuild_item(child, heap)?);
            }
            ModuleItem::module(span, &name, items).map_err(|e| format!("{e:?}"))
        }
        "defsyn" => {
            let name = krf_name(elems[3], heap)?;
            ModuleItem::define_syntax(span, &name).map_err(|e| format!("{e:?}"))
        }
        other => Err(format!("unknown item kind `{other}`")),
    }
}

fn rebuild_expr(v: &Value, heap: &Heap) -> Result<CoreExpr, String> {
    let elems = value_elems(v, heap)?;
    if elems.len() < 5 {
        return Err(format!("expr record has {} fields", elems.len()));
    }
    let span = gen_span(elems[1], elems[2], last_field(&elems)?)?;
    match as_str(elems[0])? {
        "fn" => {
            let params = value_elems(elems[3], heap)?;
            let mut names = Vec::with_capacity(params.len());
            for p in params {
                names.push(krf_name(p, heap)?);
            }
            let refs: Vec<&str> = names.iter().map(String::as_str).collect();
            let body = rebuild_expr(elems[4], heap)?;
            CoreExpr::fn_(span, &refs, body).map_err(|e| format!("{e:?}"))
        }
        "apply" => {
            let func = rebuild_expr(elems[3], heap)?;
            let mut args = Vec::with_capacity(elems.len() - 5);
            for a in &elems[4..elems.len() - 1] {
                args.push(rebuild_expr(a, heap)?);
            }
            Ok(CoreExpr::Apply {
                span,
                func: Box::new(func),
                args,
            })
        }
        "if" => {
            let cond = rebuild_expr(elems[3], heap)?;
            let then_branch = rebuild_expr(elems[4], heap)?;
            let else_branch = rebuild_expr(elems[5], heap)?;
            Ok(CoreExpr::If {
                span,
                cond: Box::new(cond),
                then_branch: Box::new(then_branch),
                else_branch: Box::new(else_branch),
            })
        }
        "var" => {
            let name = krf_name(elems[3], heap)?;
            CoreExpr::var(span, &name).map_err(|e| format!("{e:?}"))
        }
        "lit" => {
            let value = rebuild_lit(elems[3], heap)?;
            Ok(CoreExpr::Literal { span, value })
        }
        "assign" => {
            let name = krf_name(elems[3], heap)?;
            let value = rebuild_expr(elems[4], heap)?;
            CoreExpr::assign(span, &name, value).map_err(|e| format!("{e:?}"))
        }
        "let" => {
            let binding_elems = value_elems(elems[3], heap)?;
            let mut bindings = Vec::with_capacity(binding_elems.len());
            for b in binding_elems {
                let be = value_elems(b, heap)?;
                if be.len() != 5 {
                    return Err(format!("binding record has {} fields", be.len()));
                }
                let bspan = gen_span(be[0], be[1], be[4])?;
                let name = krf_name(be[2], heap)?;
                let value = rebuild_expr(be[3], heap)?;
                bindings.push(Binding::new(bspan, &name, value).map_err(|e| format!("{e:?}"))?);
            }
            let body = rebuild_expr(elems[4], heap)?;
            Ok(CoreExpr::Let {
                span,
                bindings,
                body: Box::new(body),
            })
        }
        "perform" => {
            let effect = krf_name(elems[3], heap)?;
            let mut args = Vec::with_capacity(elems.len() - 5);
            for a in &elems[4..elems.len() - 1] {
                args.push(rebuild_expr(a, heap)?);
            }
            CoreExpr::perform(span, &effect, args).map_err(|e| format!("{e:?}"))
        }
        "handle" => {
            let body = rebuild_expr(elems[3], heap)?;
            let clause_elems = value_elems(elems[4], heap)?;
            let mut handlers = Vec::with_capacity(clause_elems.len());
            for c in clause_elems {
                let ce = value_elems(c, heap)?;
                if ce.len() != 5 {
                    return Err(format!("clause record has {} fields", ce.len()));
                }
                let cspan = gen_span(ce[0], ce[1], ce[4])?;
                let effect = krf_name(ce[2], heap)?;
                let handler = rebuild_expr(ce[3], heap)?;
                handlers.push(
                    HandlerClause::new(cspan, &effect, handler).map_err(|e| format!("{e:?}"))?,
                );
            }
            CoreExpr::handle(span, body, handlers).map_err(|e| format!("{e:?}"))
        }
        other => Err(format!("unknown expr kind `{other}`")),
    }
}

fn rebuild_lit(v: &Value, heap: &Heap) -> Result<LiteralValue, String> {
    if matches!(v, Value::Nil) {
        return Ok(LiteralValue::Nil);
    }
    let elems = value_elems(v, heap)?;
    if elems.len() < 2 {
        return Err(format!("litval record has {} fields", elems.len()));
    }
    match as_str(elems[0])? {
        "int" => match elems[1] {
            Value::Int(n) => Ok(LiteralValue::Int(*n)),
            other => Err(format!("int payload: {other:?}")),
        },
        "float" => {
            let text = as_str(elems[1])?;
            let v: f64 = text.parse().map_err(|_| format!("float text `{text}`"))?;
            Ok(LiteralValue::Float(v))
        }
        "bool" => match elems[1] {
            Value::Bool(b) => Ok(LiteralValue::Bool(*b)),
            other => Err(format!("bool payload: {other:?}")),
        },
        "string" => Ok(LiteralValue::String(as_str(elems[1])?.to_owned())),
        "pair" => Ok(LiteralValue::Pair(
            Box::new(rebuild_lit(elems[1], heap)?),
            Box::new(rebuild_lit(elems[2], heap)?),
        )),
        other => Err(format!("unknown litval kind `{other}`")),
    }
}

/// Run the assembled expander on both engines, decode the two
/// verdicts, and (on the tree axis) rebuild the item tree from the
/// vm engine's result value. `Err` is a harness defect class.
fn run_dual_rich(
    assembled: &str,
) -> Result<(Option<Vec<ModuleItem>>, KrfVerdict, KrfVerdict), String> {
    let mut session = Session::new();
    let program = pipeline::parse(&mut session, "expander-parity-host.krf", assembled)
        .map_err(|diags| format!("the assembled expander program failed to parse: {diags:?}"))?;
    let findings = program.typecheck();
    if findings.iter().any(|d| d.severity == Severity::Error) {
        return Err(format!(
            "the assembled expander program failed the checker: {findings:?}"
        ));
    }
    let bc = kerf_compiler::compile_program(&program.items)
        .map_err(|err| format!("the assembled expander program failed to compile: {err}"))?;
    let mut vm = Vm::with_io(bc, Box::new(BufferIo::default()))
        .map_err(|err| format!("the vm rejected the expander program: {err}"))?;
    vm.run()
        .map_err(|err| format!("the .krf expander crashed on the vm engine: {err}"))?;
    let result = vm
        .global("result")
        .ok_or_else(|| "no `result` global on the vm engine".to_string())?
        .clone();
    let vm_verdict = decode_verdict(&result, vm.heap())?;
    let rebuilt = match &vm_verdict {
        KrfVerdict::Tree(_) => Some(rebuild_items(&result, vm.heap())?),
        KrfVerdict::Error(_) => None,
    };

    let mut evaluator = Evaluator::with_io(Box::new(BufferIo::default()));
    evaluator
        .eval_program(&program.items)
        .map_err(|err| format!("the .krf expander crashed on the eval engine: {err}"))?;
    let eval_verdict = decode_verdict(
        evaluator
            .global("result")
            .ok_or_else(|| "no `result` global on the eval engine".to_string())?,
        evaluator.heap(),
    )?;
    Ok((rebuilt, vm_verdict, eval_verdict))
}

/// Fixpoint gate B, axis (a)  -  bytecode equality: the oracle's own
/// items and the `.krf` expander's rebuilt items compile to the
/// same `Bytecode` (the `PartialEq` comparison covers the
/// per-instruction debug spans, generation included  -  subset-spec
/// §4's fixpoint-chain criterion, cashed in at 1.7).
pub fn gate_b_bytecode(case: &str, source: &str) -> Result<(), String> {
    let forms = read_program(FileId(0), source)
        .map_err(|err| format!("gate B [{case}]: the reader rejected the source: {err}"))?;
    let oracle_items = expand_program(&forms)
        .map_err(|err| format!("gate B [{case}]: the oracle rejected the source: {err}"))?;
    load_program(&oracle_items)
        .map_err(|err| format!("gate B [{case}]: the oracle loader rejected: {err}"))?;
    let bc_oracle = kerf_compiler::compile_program(&oracle_items)
        .map_err(|err| format!("gate B [{case}]: oracle compile failed: {err}"))?;
    let prefix = forms_stream_prefix(&forms);
    let assembled = format!("{prefix}\n{}", assembled_expander_source());
    let (rebuilt, vm_verdict, eval_verdict) =
        run_dual_rich(&assembled).map_err(|err| format!("gate B [{case}]: {err}"))?;
    if vm_verdict != eval_verdict {
        return Err(format!(
            "gate B [{case}]: engines disagree: vm `{}` vs eval `{}`",
            vm_verdict.text(),
            eval_verdict.text()
        ));
    }
    let items = rebuilt.ok_or_else(|| {
        format!(
            "gate B [{case}]: the .krf expander rejected: {}",
            vm_verdict.text()
        )
    })?;
    let bc_krf = kerf_compiler::compile_program(&items)
        .map_err(|err| format!("gate B [{case}]: krf rebuild compile failed: {err}"))?;
    if bc_oracle == bc_krf {
        Ok(())
    } else {
        Err(format!(
            "gate B [{case}]: bytecode drift (oracle {} bytes / krf {} bytes)",
            bc_oracle.funcs.len(),
            bc_krf.funcs.len()
        ))
    }
}

// ---------- the oracle verdict ----------

/// The oracle's normalized outcome: expand, then load (exactly the
/// `pipeline::parse` composition  -  both surfaces are in scope).
fn oracle_outcome(forms: &[SyntaxObject]) -> OracleOutcome {
    match expand_program(forms) {
        Err(err) => OracleOutcome::Error(error_parity_key(&ParityError::Expand(err))),
        Ok(items) => match load_program(&items) {
            Err(err) => OracleOutcome::Error(error_parity_key(&ParityError::Module(err))),
            Ok(_) => OracleOutcome::Tree(oracle_dump_items(&items)),
        },
    }
}

// ---------- the case driver ----------

/// Run one expander-parity case: three-layer split, oracle verdict,
/// dual-engine `.krf` run, and the two-axis comparison.
pub fn expander_parity(case: &str, source: &str) -> ExpanderParityReport {
    expander_parity_with(case, source, &assembled_expander_source())
}

/// The parameterized face (tests may pass a tampered expander
/// source to prove the drift detector actually detects).
pub fn expander_parity_with(
    case: &str,
    source: &str,
    expander_source: &str,
) -> ExpanderParityReport {
    // Layer 1  -  the reader (single source) rejected the input.
    let forms = match read_program(FileId(0), source) {
        Err(err) => {
            return ExpanderParityReport {
                case: case.to_string(),
                layer: ExpanderParityLayer::Reader,
                oracle: err.to_string(),
                krf: None,
                engines_agree: true,
                matched: true,
                drift: None,
            };
        }
        Ok(forms) => forms,
    };
    // The assembled .krf expansion layer on both engines (MX-3: the
    // macro sources run it too - the 1.6 Macro split collapsed).
    let layer = ExpanderParityLayer::Expander;
    let outcome = oracle_outcome(&forms);
    let oracle_text = match &outcome {
        OracleOutcome::Tree(dump) => dump.clone(),
        OracleOutcome::Error(text) => text.clone(),
    };
    let prefix = forms_stream_prefix(&forms);
    let assembled = format!("{prefix}\n{expander_source}");
    let (vm_verdict, eval_verdict) = match run_dual(&assembled) {
        Ok(v) => v,
        Err(harness) => {
            return ExpanderParityReport {
                case: case.to_string(),
                layer,
                oracle: oracle_text,
                krf: None,
                engines_agree: false,
                matched: false,
                drift: Some(format!("harness defect: {harness}")),
            };
        }
    };
    let engines_agree = vm_verdict == eval_verdict;
    let krf_text = vm_verdict.text();
    let matched = engines_agree
        && match (&outcome, &vm_verdict) {
            (OracleOutcome::Tree(_), KrfVerdict::Tree(_)) => krf_text == oracle_text,
            (OracleOutcome::Error(_), KrfVerdict::Error(_)) => krf_text == oracle_text,
            _ => false, // shape mismatch: tree vs error
        };
    let drift = if matched {
        None
    } else {
        Some(format!(
            "oracle `{oracle_text}` vs krf `{krf_text}`{}",
            if engines_agree {
                String::new()
            } else {
                format!(
                    "; engines disagree: vm `{}` vs eval `{}`",
                    vm_verdict.text(),
                    eval_verdict.text()
                )
            }
        ))
    };
    ExpanderParityReport {
        case: case.to_string(),
        layer,
        oracle: oracle_text,
        krf: Some(krf_text),
        engines_agree,
        matched,
        drift,
    }
}

#[cfg(test)]
mod tests {
    //! Expander-parity harness tests (the plan-1.6 test doc FP1,
    //! FP2, FP8 faces that live naturally next to the harness).

    use super::*;

    fn parity(source: &str) -> ExpanderParityReport {
        expander_parity("unit", source)
    }

    #[test]
    fn forms_stream_encodes_a_small_program() {
        let forms = read_program(FileId(0), "(f 1)").expect("the source reads");
        let prefix = forms_stream_prefix(&forms);
        assert_eq!(
            prefix,
            "(define forms (quote ((\"list\" \"0\" \"5\" 2 0) (\"ident\" \"1\" \"2\" \"f\" 0) \
             (\"int\" \"3\" \"4\" 1 0))))"
        );
    }

    #[test]
    fn reader_layer_split_routes_the_read_rejections() {
        for src in ["(a", ")", "(f ())", "\"unterminated", "(((x"] {
            let report = parity(src);
            assert_eq!(report.layer, ExpanderParityLayer::Reader, "case {src:?}");
            assert!(report.matched, "case {src:?}");
            assert!(report.krf.is_none());
        }
    }

    #[test]
    fn macro_sources_run_the_assembled_expander() {
        // MX-3: the 1.6 Macro split collapsed - a define-syntax
        // source runs the assembled program with the oracle
        // agreeing (the Macro enum value is the zero-routing
        // sentinel).
        let src = "(define-syntax m (syntax-rules nil ((_ x) x))) (define r (m 1))";
        let report = parity(src);
        assert_eq!(report.layer, ExpanderParityLayer::Expander);
        assert!(report.matched, "{}", report.failure_line());
        assert!(report.krf.is_some());
    }

    #[test]
    fn tree_axis_parity_holds_at_the_exact_anchor_spans() {
        let report = parity("(define x 1)");
        assert_eq!(report.layer, ExpanderParityLayer::Expander);
        assert!(report.engines_agree, "{:?}", report.drift);
        assert!(report.matched, "{}", report.failure_line());
        assert_eq!(report.oracle, "(define 0 12 x (lit 10 11 (int 1)))");
        assert_eq!(report.krf.as_deref(), Some(report.oracle.as_str()));
    }

    #[test]
    fn error_axis_parity_holds_at_the_exact_payloads() {
        // A bare top-level atom is a top-level expression at its
        // own span. §9.56 DIAG-1: the parity key = position-free
        // Display + harness-rendered `@ {span}` suffix.
        let top = parity("x");
        assert!(top.matched, "{}", top.failure_line());
        assert_eq!(
            top.oracle,
            "top-level expression is not allowed: only `define`, \
             `require` and `module` declarations are valid at module top level @ file#0:0..1"
        );
        // A symbol module name is MalformedForm (the trap-7 rule).
        let req = parity("(require b)");
        assert!(req.matched, "{}", req.failure_line());
        assert_eq!(req.oracle, "malformed `require` form @ file#0:0..11");
        // An unbound reference reports the symbol atom's span.
        let unbound = parity("(define x y)");
        assert!(unbound.matched, "{}", unbound.failure_line());
        assert_eq!(
            unbound.oracle,
            "unbound identifier `y`: not in any lexical scope \
             and not a Stage 0 global @ file#0:10..11"
        );
    }

    #[test]
    fn drift_detector_actually_detects() {
        // A tampered expander (the depth guard trips at 2 nesting
        // levels instead of 512) must fail the comparison  -  a
        // detector that cannot fail proves nothing.
        let tampered = EXPANDER_SOURCE.replace("(>= ex-depth 512)", "(>= ex-depth 2)");
        assert_ne!(tampered, EXPANDER_SOURCE, "tamper must change the source");
        let report = expander_parity_with("tamper", "(define x (do 1 (do 2 3)))", &tampered);
        assert!(!report.matched, "the tampered expander must be caught");
        assert!(report.drift.is_some());
    }

    #[test]
    fn harness_defects_surface_as_drift_not_panics() {
        // A tampered expander that publishes an unknown verdict tag
        // is a harness defect class: drift, never a panic.
        let tampered = EXPANDER_SOURCE.replace("(cons \"ok\" items)", "(cons \"okay\" items)");
        assert_ne!(tampered, EXPANDER_SOURCE);
        let report = expander_parity_with("defect", "(define x 1)", &tampered);
        assert!(!report.matched);
        assert!(report.drift.as_deref().unwrap().contains("harness defect"));
    }
}

#[cfg(test)]
mod macro_parity_tests {
    //! The 1.7 macro-face harness tests (the plan-1.7 test doc
    //! MP1-MP11 faces that live naturally next to the harness).

    use super::*;

    fn parity(source: &str) -> ExpanderParityReport {
        expander_parity("unit", source)
    }

    #[test]
    fn mp1_the_assembly_contract_holds_one_program() {
        // MP1: the assembled program is macro.krf's body ahead of
        // expander.krf's body, one parse; the driver define rides
        // only in the expansion layer's tail.
        let assembled = assembled_expander_source();
        assert!(assembled.starts_with(MACRO_SOURCE.trim_start()));
        assert!(assembled.contains(EXPANDER_SOURCE.trim_start()));
        assert_eq!(
            MACRO_SOURCE.matches("(define result").count(),
            0,
            "the macro library carries no driver define"
        );
        assert_eq!(
            EXPANDER_SOURCE.matches("(define result").count(),
            1,
            "exactly one driver define"
        );
    }

    #[test]
    fn mp1b_the_bare_assembly_exposes_the_hosting_dependency() {
        // The bare assembled source carries the (ex-run forms)
        // driver but no forms definition - the parse rejects on
        // the unbound `forms` (the hex0-layer hosting dependency,
        // the 1.6 bare-source error face, third segment).
        let mut session = Session::new();
        let outcome = pipeline::parse(&mut session, "assembly.krf", &assembled_expander_source());
        let diags = outcome.expect_err("the bare assembly must reject");
        assert!(
            diags
                .iter()
                .any(|d| d.message.contains("unbound identifier `forms`")),
            "{diags:?}"
        );
    }

    #[test]
    fn mp2b_the_literals_table_validates_its_three_shapes() {
        // The empty-table spelling, a good non-empty table, and the
        // `_`/`...`/`nil` prohibitions.
        for (src, ok) in [
            ("(define-syntax m (syntax-rules nil ((_ x) x)))", true),
            ("(define-syntax m (syntax-rules (a b) ((_ x) x)))", true),
            ("(define-syntax m (syntax-rules (_) ((_ x) x)))", false),
            ("(define-syntax m (syntax-rules (... a) ((_ x) x)))", false),
            ("(define-syntax m (syntax-rules (nil) ((_ x) x)))", false),
            ("(define-syntax m (syntax-rules (1) ((_ x) x)))", false),
        ] {
            let report = parity(src);
            assert!(report.matched, "{src}: {}", report.failure_line());
            if ok {
                assert!(report.oracle.contains("defsyn"), "{src}: {report:?}");
            } else {
                assert!(
                    report.oracle.contains("malformed `define-syntax` form"),
                    "{src}: {}",
                    report.oracle
                );
            }
        }
    }

    #[test]
    fn mp2c_first_matching_rule_wins_in_declaration_order() {
        let report = parity(
            "(define-syntax pick (syntax-rules nil ((_ x) 1) ((_ x) 2))) (define r (pick 9))",
        );
        assert!(report.matched, "{}", report.failure_line());
        assert!(report.oracle.contains("(int 1)"), "{}", report.oracle);
    }

    #[test]
    fn mp2d_atom_patterns_match_structurally() {
        let report = parity(
            "(define-syntax m (syntax-rules nil ((\"s\" 3 #t 2.5) 1) ((_ x) 0))) (define r (m 2.5))",
        );
        assert!(report.matched, "{}", report.failure_line());
        assert!(report.oracle.contains("(int 0)"), "{}", report.oracle);
    }

    #[test]
    fn mp3b_the_spliced_argument_keeps_its_use_site_identity() {
        // Splice early-return: the rename walk never touches the
        // spliced node (its span stays the use-site span).
        let report =
            parity("(define-syntax m (syntax-rules nil ((_ x) (+ x 1)))) (define r (m 41))");
        assert!(report.matched, "{}", report.failure_line());
        assert!(
            report.oracle.contains("(lit 66 68 (int 41))"),
            "the spliced literal keeps its use-site span: {}",
            report.oracle
        );
    }

    #[test]
    fn mp4_the_mangled_decode_covers_the_counter_allocation() {
        // Two distinct colliding binders allocate consecutive
        // counters from a single instantiation-wide pool.
        let report = parity(
            "(define-syntax w (syntax-rules nil ((_ a b) (let ((x 1) (y 2)) (+ x (+ y (+ a b))))))) \
             (define (f x y) (w x y)) (define result (f 3 4))",
        );
        assert!(report.matched, "{}", report.failure_line());
        assert!(
            report.oracle.contains("x__macro_0") && report.oracle.contains("y__macro_1"),
            "both colliding binders rename with consecutive counters: {}",
            report.oracle
        );
    }

    #[test]
    fn mp5b_reserved_names_reject_at_registration() {
        for name in [
            "fn", "if", "let", "do", "set!", "perform", "handle", "quote",
        ] {
            let report = parity(&format!(
                "(define-syntax {name} (syntax-rules nil ((_ x) x)))"
            ));
            assert!(report.matched);
            assert!(
                report.oracle.contains("malformed `define-syntax` form"),
                "{name}: {}",
                report.oracle
            );
        }
    }

    #[test]
    fn mp6b_use_before_definition_fails() {
        let report = parity("(define r (m 1)) (define-syntax m (syntax-rules nil ((_ x) x)))");
        assert!(report.matched, "{}", report.failure_line());
        assert!(
            report.oracle.contains("unbound identifier `m`"),
            "{}",
            report.oracle
        );
    }

    #[test]
    fn mp8b_the_macro_registry_survives_a_plain_run_untouched() {
        // Non-macro sources never touch the registry; the sentinel
        // count stays zero across a mixed corpus slice.
        for src in ["(define x 1)", "(define (f x) x)"] {
            let report = parity(src);
            assert_eq!(report.layer, ExpanderParityLayer::Expander);
            assert!(report.matched, "{}", report.failure_line());
        }
    }

    #[test]
    fn mp9b_gate_b_axis_a_holds_on_a_plain_module_source() {
        gate_b_bytecode(
            "plain-module",
            "(module m (define x 1)) (require \"m\") (define result 2)",
        )
        .expect("module-source bytecode equality");
    }

    #[test]
    fn mp10b_gate_b_axis_b_keeps_the_bare_source_error_face() {
        // The bare assembled source (hosting tail included) fails
        // on the unbound `forms` - the hex0-layer hosting dependency
        // made visible by self-application.
        let bare = expander_parity("selfhost-bare", &assembled_expander_source());
        assert!(bare.matched, "{}", bare.failure_line());
        assert!(
            bare.oracle.starts_with("unbound identifier `forms`"),
            "§9.56 DIAG-1: position-free oracle message: {}",
            bare.oracle
        );
    }

    #[test]
    fn mp11b_tampering_the_assembly_order_is_caught() {
        // A reversed assembly (expander before macro) must fail the
        // parse or the run - the harness never assembles that way,
        // but the reversed source demonstrates the contract's teeth.
        let reversed = format!("{EXPANDER_SOURCE}\n{MACRO_SOURCE}");
        let mut session = Session::new();
        let outcome = pipeline::parse(&mut session, "reversed.krf", &reversed);
        assert!(
            outcome.is_err(),
            "the reversed assembly must not parse cleanly"
        );
    }

    #[test]
    fn mp11c_tampering_a_rename_decision_is_caught_by_the_tree_axis() {
        // A tampered binder-detection (only `fn` binder forms, no
        // `let`) must drift the hygiene rename on the collision case.
        let needle = "(eq? hx \"let\")";
        assert!(MACRO_SOURCE.contains(needle), "the binder anchor exists");
        let tampered = MACRO_SOURCE.replacen(needle, "(if (eq? hx \"fn\")", 1);
        let assembled = format!("{tampered}\n{EXPANDER_SOURCE}");
        let report = expander_parity_with(
            "tamper-binder",
            "(define-syntax w (syntax-rules nil ((_ e) (let ((x 100)) (+ x e))))) \\
             (define (f x) (w x)) (define result (f 1))",
            &assembled,
        );
        assert!(!report.matched, "the tampered binder scan must be caught");
    }
}

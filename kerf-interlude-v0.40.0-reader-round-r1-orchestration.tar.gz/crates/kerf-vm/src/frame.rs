//! Call frames (docs/stage0.md §8.12 / §19.5 invariant 1).
//!
//! The frame FORMAT IS FROZEN: every calling frame carries three
//! extension slots — ext1 continuation, ext2 exception table, ext3
//! debug frame. Stage 0 keeps ext1/ext2 as reserved singletons and
//! fills ext3 with the proto's diagnostic name; the slots are part of
//! the §15 pre-stage contract, so they exist now and grow later
//! without a layout break.

use kerf_span::Symbol;

use crate::value::Value;

/// ext1 — reserved for continuations (Stage 1+ effect resumption).
/// Stage 0 value: locked format, always [`ContinuationSlot::Reserved`].
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ContinuationSlot {
    Reserved,
}

/// ext2 — reserved for the exception table. Stage 0 value: locked
/// format, always [`ExceptionTableSlot::Reserved`].
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ExceptionTableSlot {
    Reserved,
}

/// ext3 — the debug frame. Filled from 0.6 on: the callee proto's
/// diagnostic name (stack-trace rendering is the 0.8 driver's face).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DebugFrameSlot {
    pub func_name: Option<Symbol>,
}

/// The frozen three-slot extension block (§8.12 frame shape).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FrameExt {
    /// ext1: continuation.
    pub continuation: ContinuationSlot,
    /// ext2: exception table.
    pub exception_table: ExceptionTableSlot,
    /// ext3: debug frame.
    pub debug: DebugFrameSlot,
}

impl FrameExt {
    /// The Stage 0 shape (ext1/ext2 reserved, ext3 named).
    pub fn new(func_name: Option<Symbol>) -> Self {
        FrameExt {
            continuation: ContinuationSlot::Reserved,
            exception_table: ExceptionTableSlot::Reserved,
            debug: DebugFrameSlot { func_name },
        }
    }
}

/// One activation record. Frames live in the VM's frame vector —
/// kerf-level recursion grows that vector, never the Rust stack (the
/// TD-023 anchor: iterative main loop + heap frame stack). Each frame
/// owns its operand stack and locals; `pc` is the index into the
/// owning proto's code of the NEXT instruction to fetch.
#[derive(Debug, Clone, PartialEq)]
pub struct Frame {
    /// Proto index into `Bytecode::funcs`.
    pub func: usize,
    /// Next fetch position (§19.5 invariant 2: only jump / call /
    /// ret / error paths move it against the +1 rule).
    pub pc: usize,
    /// Parameter slots first (0..params), then let slots; slots never
    /// stored yet read as `nil` (deterministic baseline — verified
    /// source never reads before its store).
    pub locals: Vec<Value>,
    /// This frame's operand stack.
    pub stack: Vec<Value>,
    /// The frozen extension block.
    pub ext: FrameExt,
}

impl Frame {
    /// Build a frame for `func` whose proto declares `n_locals` slots,
    /// entering with `args` (arity already checked by the caller).
    pub fn new(func: usize, func_name: Option<Symbol>, n_locals: u32, args: Vec<Value>) -> Self {
        let mut locals = vec![Value::Nil; n_locals as usize];
        if args.len() > locals.len() {
            // Arity was checked before entry; args beyond n_locals
            // would be a caller-contract violation (params <= n_locals
            // holds for every proto the compiler builds).
            locals.resize(args.len(), Value::Nil);
        }
        for (slot, arg) in locals.iter_mut().zip(args) {
            *slot = arg;
        }
        Frame {
            func,
            pc: 0,
            locals,
            stack: Vec::new(),
            ext: FrameExt::new(func_name),
        }
    }
}

#[cfg(test)]
mod tests {
    //! Frame layout tests (FP2/FP4): construction, nil padding, and
    //! the frozen extension-slot shape.

    use super::*;

    fn sym(text: &str) -> Symbol {
        Symbol::new(text).expect("fixture symbol")
    }

    #[test]
    fn frame_binds_args_then_pads_and_locks_ext_slots() {
        let frame = Frame::new(1, Some(sym("fib")), 3, vec![Value::Int(7)]);
        assert_eq!(frame.func, 1);
        assert_eq!(frame.pc, 0);
        // args in param slots, never-stored slots read as nil.
        assert_eq!(frame.locals, vec![Value::Int(7), Value::Nil, Value::Nil]);
        assert!(frame.stack.is_empty());
        // The three extension slots exist with their Stage 0 values.
        assert_eq!(frame.ext.continuation, ContinuationSlot::Reserved);
        assert_eq!(frame.ext.exception_table, ExceptionTableSlot::Reserved);
        assert_eq!(frame.ext.debug.func_name, Some(sym("fib")));
    }

    #[test]
    fn frame_without_padding_keeps_args_only() {
        // n_locals == arg count: no nil slots at all.
        let frame = Frame::new(0, None, 2, vec![Value::Bool(true), Value::Nil]);
        assert_eq!(frame.locals, vec![Value::Bool(true), Value::Nil]);
    }

    #[test]
    fn anonymous_frame_has_no_debug_name() {
        let frame = Frame::new(0, None, 0, vec![]);
        assert!(frame.locals.is_empty());
        assert_eq!(frame.ext.debug.func_name, None);
    }
}

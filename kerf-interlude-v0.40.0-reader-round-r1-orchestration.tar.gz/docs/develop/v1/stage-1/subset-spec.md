# kerf 子集规格——.krf 自举目标面（subset-spec.md）

> **Status**: Frozen（Stage 1.4 冻结轮落档——2026-09-29 · v0.17.0）
> 依据：stage-1-plan.md §2 行 1.4 + docs/stage0.md §9.45.4（冻结面五表）+ §9.25.4（BS-C）
> 性质：**当前实现面的诚实登记**（代码事实单源直读）——零新原语、零新语法、零能力扩张（8 原语不变性第十八轮验证维持）。规格与实现冲突以代码为准 + 提交修正本文档（sop §8.4.5）。
> 消费者：Stage 1.5-1.7 前端三段 .krf 重写（Reader → Expander → 基础宏）+ 验收语料（tests/v1/stage1/corpus/）+ parity 契约面（kerf-driver/src/parity.rs）。

## 0. 一行定位

kerf 子集 = Stage 0-1 已实现语言面的冻结快照：`.krf` 文件承载 S-expr 皮肤（bootstrap-parser 脚手架——切换窗未开），语义锚定链 = 表面形式 → `CoreExpr` → 字节码 → eval 同构（双引擎 parity 即语义安全网）。

## 1. 冻结面

### 1.1 声明头（4）——模块顶层唯一合法形式

| 形式 | 文法 | 语义锚 |
|------|------|--------|
| `define` | `(define name value)` / `(define (f params...) body)` | `ModuleItem::Define`——值位立即求值；函数糖 = `Define{f, Fn{params, body}}` 近恒等映射（§7.3.5）；**letrec 预绑定**：自身名先绑（递归合法） |
| `require` | `(require name)` | `ModuleItem::Require`——声明图校验（0.9 装载层）；**零代码**（链接推迟装载期——单模块运行） |
| `module` | `(module name items...)` | `ModuleItem::Module`——嵌套声明；运行时**平坦求值**（名字入同一全局表——可见性合并 = 后续模块系统面） |
| `define-syntax` | `(define-syntax name spec)` | `ModuleItem::DefineSyntax`——声明位（transformer 注册于展开环境）；宏触发面 = 1.7 自举议程 |

其余头（含全部表达式特殊形式）在模块顶层 = `TopLevelExpression` 拒绝（展开期）。

### 1.2 表达式特殊形式（8）

| 形式 | 文法 | 语义锚（CoreExpr → 双引擎） |
|------|------|------------------------------|
| `fn` | `(fn (params...) body)`——单 body | `Fn`——闭包；**不捕获外层绑定**（见 §2.1） |
| `if` | `(if cond then else)`——三元严格 | `If`——短路；cond 必须 Bool（R3/E0003；非 Bool 字面量确定错误，运行时 truthy 仅 Bool） |
| `let` | `(let ((name val)...) body)`——或 `(let (name val) body)` | `Let`——**let\* 顺序语义**（前一绑定可见于后一绑定） |
| `do` | `(do expr...)` | 脱糖为 `Let` 链（顺序求值，值 = 末位） |
| `set!` | `(set! name val)` | `Assign`——目标必须已解析（展开期 Unbound 拒绝）；重绑内建 = E0008 Warning |
| `perform` | `(perform effect args...)` | `Perform`——效应执行；顶层即时位无 Handle 覆盖 = E0006 确定错误 |
| `handle` | `(handle body (effect handler)...)` | `Handle`——最近词法路由（Fn 边界截断）；handler 元数失配 = E0005/E0007 |
| `quote` | `(quote datum)` | `Literal`——数据面：Int/Float/Bool/String/nil/嵌套表（→ 嵌套 Pair）；**Symbol 不可 quote**（nil 除外） |

### 1.3 内建（18）——STAGE0_GLOBALS 单源（expander/lib.rs = vm/builtin.rs ALL 注册表互证）

| 域 | 名字（元数） | 语义备注 |
|----|--------------|----------|
| 算术比较（9） | `+`(2) `-`(2) `*(2)` `/`(2) `<`(2) `<=`(2) `>`(2) `>=`(2) `=`(2) | 数值域封闭；溢出 fail-closed（`ArithmeticOverflow`）；`/` 整除；`=` 数值等 |
| pair 与谓词（7） | `car`(1) `cdr`(1) `cons`(2) `pair?`(1) `nil?`(1) `eq?`(2) `not`(1) | `car/cdr` 非 pair = `type_mismatch` |
| 最小 I/O（2） | `read-line`(0) `write-line`(1) | **write-line 仅 Str 域**（int 实参 = `type_mismatch`——§8.8 最小集域约束） |

### 1.4 字面量（6）与原子

`Int`(i64，十进制) / `Float`(f64，十进制小数) / `Bool`(`#t`/`#f`) / `String`(`"..."` 转义已解码) / `Nil`（`nil` 字面量位） / `Pair`（quote 表脱糖产物）。符号 = 标识符（绑定位或引用位）。

### 1.5 核心构造子（9）与模块项（4）

`CoreExpr`：`Fn / Apply / If / Var / Literal / Assign / Let / Perform / Handle`——核心面即冻结面全集。`ModuleItem`：`Define / DefineSyntax / Require / Module`。

### 1.6 量化帽（实证值）

| 帽 | 值 | 依据 |
|----|-----|------|
| Reader 嵌套 | 256 层 | `NESTING_LIMIT`（257 层 = Reader 期拒绝） |
| 宏展开 | 512 | `EXPANSION_LIMIT`（自递归宏触顶 = 展开期拒绝） |
| HM 推断 | 512/define | `INFERENCE_DEPTH_LIMIT`（E0011 Warning——1.8 接线前面） |
| 整数域 | i64 全域 checked | 溢出 = 运行时 `ArithmeticOverflow`（双引擎一致） |

## 2. 冻结语义细则（实证裁定——语料锚定）

### 2.1 闭包不捕获

内层 `fn` 引用外层 Fn 参数/let 绑定 = **确定错误**：展开器词法域允许（卫生作用域集），运行时双引擎一致拒绝（eval dormant capture 不参与解析；VM 编译 `Var` 为当前 proto 局部或 `LoadGlobal`）。检查器 R1（E0001）在源路径精确检出（neg-045 锚）。捕获语义 = Stage 2 词法寻址窗（§9.44.5 触发器既有）。

### 2.2 顺序绑定（define-so-far）

顶层 define 按序展开绑定：**前向引用**（引用后置 define）= 展开期 `UnboundIdentifier` 拒绝（neg-046 锚）；自身名 letrec 预绑定（递归合法——pos-009 锚）；互递归源路径不可达（展开期拒绝）。stage-1-plan §3 R1 行「Fn 体内看全部 Defines」= 检查器对**直接构造面**的视角（宏合成/程序化 API），源路径以展开器为准。

### 2.3 顶层即时位效应

`define` 值位的 `perform`（模块装载期立即执行）无词法 Handle 覆盖 = E0006 确定错误（neg-035 锚）；有覆盖按最近词法路由（pos-021/022 锚）。

### 2.4 程序终值与值约定

define-only 模块程序终值恒 `nil`（双引擎同构）；**语料值约定 = 末位顶层 define 的停机值**（REPL `$repl:N` 同通道——parity 契约面 globals_repr 末位读取）。纯 module 体（零顶层 define）= 语料面明确漂移。

### 2.5 空表与空应用

`()` 在 **Reader 期**拒绝（`empty application`——§7.1.1 class 3；neg-021 锚）——非展开期。

## 3. 验收语料（68 条——tests/v1/stage1/corpus/）

### 3.1 指令文法（首行，封闭）

```
;; expect: value <repr>            — 双引擎停机，末位 define = <repr>
;; expect: parse-error             — Reader 拒绝（kerf-read）
;; expect: expand-error            — 展开器/装载器拒绝（kerf-expand）
;; expect: type-error <code>+      — 检查器错误级码集（序不敏感精确集）
;; expect: runtime-error           — 检查器过 + 双引擎一致运行时拒绝
;; expect: warning <code>+ value <repr> — 仅警告级码集 + 停机值
```

`<repr>` = `parity_repr` 结构形态：整数十进制 / 浮点 `Debug` 形（`3.0` 非丢零）/ `true`/`false` / `"带引号串"` / `nil` / `(a . b)` 右嵌 pair / `#<closure>` / `#<builtin:name>`。

### 3.2 分布（§9.45.5 底线 + 实态）

| 类 | 数 | 覆盖 |
|----|-----|------|
| pos-（26） | ≥20 ✓ | 算术/比较/布尔/函数糖/闭包工厂/递归 fib/let 链/遮蔽/do/set!/字符串/quote 两形/cons 链/car-cdr/谓词族/not/高阶 map/perform-handle 两形/write-line/宏 my-if/module 平坦求值/nil 字面量/E0008 警告位 |
| neg-（32） | ≥20 ✓ | Reader 4（未闭合/游离闭/未终结串/坏 # 记号）+ 展开/装载 14（顶层表达式/malformed 四形/未绑定/quote 符号/set 未绑/模块环/缺模块/重复模块/空应用/**前向引用**/**闭包不捕获**/write-line int 域）+ 检查器 8（E0002-E0008 七码全档 + 多错误收集 E0002+E0003）+ 运行时 6（除零/car 非 pair/加法溢出/参数位元数失配/加 bool/write-line int） |
| bnd-（10） | ≥10 ✓ | i64 max/min 存活 + min-1 溢出拒 + 浮点两形态（0.1/3.0）+ 嵌套帽双侧（255 过/257 拒）+ fib 25 深递归 + iota 50 长链 + 宏展开帽 512 |

**每条期望经真实管线实证**（探针轮 68/68 固化——零猜测期望纪律；修正实录见 plan-1.4.md §4）。

### 3.3 扩展义务（§9.45.7）

每子阶段交付语料增量：1.5 双 Reader parity 语料（~~可带输入带~~ **1.5 实施裁定[2026-09-29]**：输入带路线不采——冻结子集字符串不透明使任何行协议不可拆解，源注入表格契约为唯一类型化数据通道[§9.46.4 RS-1]；本义务重登记为词法层第二段评估位）；1.6 展开器 parity；1.7 宏面 + fixpoint 门；1.8 HM 接线后 E0009-E0011 语料位解锁。

**1.5 交付态注记**：双 Reader parity 已以「既有 68 语料全扫重放 + RS 族内联域」达成（非新增语料文件——语料从程序合法性判定面升格为 Reader 输入面；分布与口径见 docs/tests/v1/stage1/reader-parity.md）。

**1.6 交付态注记（2026-09-29）**：1.6 展开器 parity 以「语料扩展 4 案 + 既有 68 全扫重放」达成——语料 **68 → 72**（pos-029 字符串 require + 比较内建三连 + 未调用 read-line / pos-030 嵌套 module 声明 / neg-048 字符串名 module 环 / neg-049 require 缺失模块——后两案使 ModuleCycle/ModuleNotFound 自语料可达[符号名 require 死于 MalformedForm 的 §9.47.3 ★7 勘察实证]）；三层分流 = Reader 6 / Macro 2（pos-024 + bnd-010 经 oracle 定案——SyntaxRules = 1.7 窗） / Expander 64；分布与口径见 docs/tests/v1/stage1/expander-parity.md。

**1.7 交付态注记（2026-09-29）**：1.7 宏面 parity 以「语料扩展 7 案 + 既有 72 全扫重放」达成——语料 **72 → 79**（pos-031 literal 非空表 / pos-032 两代宏链[use_gen+1 首次语料行使] / pos-033 卫生 binder 碰撞[rename-on-capture 首次语料行使——MX-1 mangled 记录 parity 面] / neg-050 模式不匹配[MacroPatternMismatch 语料可达化] / neg-051 重复模式变量 / neg-052 ellipsis 拒绝 / neg-053 module 域宏外用）；三层分流**收缩**为 Reader 6 / **Macro 0（哨兵零路由——1.6 的 oracle 定案位拆除，宏案直入装配程序双引擎真跑）** / Expander 73；fixpoint 门 B 落位（(a) 字节码全等 + (b) 装配源自应用）；分布与口径见 docs/tests/v1/stage1/macro-parity.md。
**1.8 交付态注记（HM 接线语料共变）**：driver 面接入 HM 层后（stage-1-plan 1.8 / §9.49.5 GATE-2），五案负向期望双层化——neg-031（非布尔条件）与 neg-037（多错误收集）增补 E0009；neg-041（car 非二元组）/ neg-044（数值异参）/ neg-047（write-line 整数）由 runtime-error 迁至 type-error E0009（检查器先拒——soft typing 的确定错误语义前移，1.1 "both layers report" 先例；期望全部探针实测重冻结）。正负分布不变（79 案构成零变化，仅期望语义更新）。

## 4. parity 契约面（BS-C 的 1.4 切片）

`kerf-driver::parity`：`CorpusCase::from_source`（首行指令解析）→ `validate`（parse → checker → 双引擎）→ `EquivalenceReport{observed, matched, drift}`；`validate_all` 批次面。判定分层（BS-C 沿袭）：同语法链 = 值等价（`parity_repr` 全等 + outputs + globals 三面 agree）；字节码全等限 fixpoint 链（1.7+ 门 B）；跨语法 = CoreExpr 全等 + 运行结果等价（1.5+ 切换窗）。**不做清单**（§9.45.6）：不预建 Reader 抽象、不做字节码全等、不做性能基准。

## 5. 冻结纪律

- 后续子阶段任何表面变更（1.5-1.7 切口）= 本规格同步 + 语料增量 + 契约面回归（1046:0:0 基线）。
- 8 原语不变性维持（零新原语零通道零 VM 零语法）；VM 永久 Rust 基座（宪制排除项）；切换窗未开（S-expr 皮肤 = 脚手架维持——原则 41 生命周期）。

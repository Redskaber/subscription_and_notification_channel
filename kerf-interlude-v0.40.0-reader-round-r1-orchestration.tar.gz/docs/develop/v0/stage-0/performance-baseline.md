# Stage 0 性能基线（performance-baseline.md）

> 依据：docs/sop.md §14.6.4（性能测试标准——每个大阶段末尾必须建立性能基线）+ docs/stage0.md §22.3 里程碑第 8 项「性能基准已建立基线数据」
> 产出轮次：Stage 0.11 末轮（2026-09-28 首录）；**2026-09-29 方法学 v2 重录（r60 §9.61——有意方法学变更 = 文档化再基线非冻结打破）**
> 可重跑入口：`cargo run --release --example stage0_baseline`（examples/bench/stage0_baseline.rs——§14.6.4 规则 2 单入口；零新依赖：std::time + std::hint::black_box + 既有 crate API）
> 统计口径 v2：mean / median / min / stdev 四统计量（中位数为主判据——抗环境噪声；stdev+min = 离群可见面）；每轴预热段 max(3, iters/10) 不入样；优化器栅栏 std::hint::black_box（K90 best-effort 纪律）；B1 子轴拆分 B1a/B1b/B1c（阶段归因面）；每次代码变更后重跑对比（规则 3 回归检测）

## 1. 记录环境

| 项 | 首录 2026-09-28 | 方法学 v2 重录 2026-09-29 |
|----|----|----|
| rustc | 1.98.1 (48a229cea 2026-09-01) | 同 |
| profile | release（debug_assertions=false） | 同 |
| CPU | Intel(R) Xeon(R) Processor × 2 vCPU | 同 |
| 工作区版本 | v0.11.1（0.10-r3 基线 + 0.11 快照套件） | v0.30.0（r60 §9.61 方法学 v2 随本版本落地）；r70 重跑 = v0.40.0（§9.71 reader 轮——B 表 §2 刷新） |

## 2. 基线数据（2026-09-30 r70 §9.71 reader 轮重跑——当前有效基线）

> r70 重跑触发面 = §14.6.4 规则 5（kerf-reader src 触碰）。**域主账：B1a read-fib median 1.4µs → 1.1µs（−21.4%）**——§9.71 RDR-1 字节分派扫描 + 零拷贝原子切片的实施收益（每原子中间 String 分配退役 + ASCII 快径免解码）；B1 复合 7.7µs → 7.3µs（−5.2%，承载读轴收益）；B1b/B1c 逐位带内（未触碰面零扰动实证）；B2/B3/B5 带内（B3 +2.6% 环境噪声带内）；B4 确定性计数逐位一致。

| 项 | 工作负载 | 迭代 | mean | median | min | stdev | 判读 |
|----|---------|------|------|--------|-----|-------|------|
| B1 compile-fib | fib 源码 → read + expand + compile + verify 全编译链 | 1000 | 7.5µs | 7.3µs | 6.8µs | 1.1µs | 编译面基线（r70 §9.71——读轴收益承载 −5.2%） |
| B1a read-fib | read 子轴 | 1000 | 1.1µs | 1.1µs | 1.1µs | 0.3µs | **阶段归因子轴——r70 §9.71 RDR-1 域主账 −21.4%（1.4µs → 1.1µs；字节分派 + 零拷贝原子）** |
| B1b expand-fib | expand 子轴 | 1000 | 3.6µs | 3.5µs | 3.5µs | 0.6µs | 同上；r70 带内逐位一致（未触碰面） |
| B1c compile+verify-fib | compile+verify 子轴 | 1000 | 1.5µs | 1.5µs | 1.4µs | 0.3µs | 同上；r70 带内逐位一致（§9.70 B1c 逐位一致维持） |
| B2 vm-run-fib25 | fib(25)=75025（入口消费闭包——0.6 锚负载） | 100 | 75.915ms | 75.597ms | 75.314ms | 1.401ms | VM 执行面基线（r70 带内 +0.2%——§9.69 −13.0% 改善保持） |
| B3 eval-run-fib20 | fib(20)=6765（元循环求值器——双路径对照面） | 30 | 6.973ms | 6.956ms | 6.910ms | 0.055ms | eval 路径基线（r70 +2.6% 环境噪声带内——§9.67 −34.3% 改善保持） |
| B4 gc-pressure-churn | 2000 顶层丢弃 pair 分配（预算 1024——collect-then-retry 实路径） | 50 | 0.298ms | 0.297ms | 0.291ms | 0.009ms | GC 面基线：gc-cycles/iter 1，swept/iter 1023——**确定性计数与首录逐位一致（r70 维持——零 GC 语义漂移）；逐 run 精确值已由守卫测试 b4_churn_counters_exact_per_run 锚定** |
| B5 driver-e2e-fib25 | run_source VM fib(25)（session + 管线 + halt 快照全链） | 50 | 75.419ms | 75.356ms | 75.053ms | 0.333ms | 端到端基线（B2 + 驱动层开销；r70 带内 +0.2%——§9.69 −12.6% 改善保持） |

**子轴物理注记**：B1a+B1b+B1c ≈ 6.1µs < B1 复合 7.3µs——子轴循环单阶段更热（缓存局部性）周知测量物理；两口径并行报告不互推（复合值承担与首录/v0.23.0 实测的可比性，子轴值承担阶段归因）。

**历史首录（2026-09-28 方法学 v1——保留作历史层：无栅栏/无预热/mean+median 双统计量）**：

| 项 | 迭代 | mean | median |
|----|------|------|--------|
| B1 compile-fib | 1000 | 9.7µs | 9.3µs |
| B2 vm-run-fib25 | 100 | 96.8ms | 96.7ms |
| B3 eval-run-fib20 | 30 | 9.4ms | 9.4ms |
| B4 gc-pressure-churn | 50 | 0.37ms | 0.36ms（gc 1 cycle/iter，swept 1023/iter） |
| B5 driver-e2e-fib25 | 50 | 98.4ms | 97.6ms |

**回归判定口径（规则 3）**：median 恶化 > 25%（环境噪声带）= 性能回归 → 定位变更轮次并评估；B4 的 gc-cycles/swept 为行为指标——数值变化即语义变化（分配率或存活集变更），必须解释（守卫测试 perf_observability_guard_tests 锚定逐 run 精确值）。

## 3. 热点识别（规则 4——O(n²) 或更差算法的优化候选登记）

| 热点 | 复杂度现状 | 证据 | 处置 |
|------|-----------|------|------|
| VM 解释循环 fib(25) ~87ms（v2 重录） | fib 调用树指数级（242,785 calls ≈ 1.16µs/call） | B2/B5 | 负载本性（naive fib 无记忆化）——非实现缺陷；吞吐对 Stage 0 树遍历 VM 属预期量级 |
| eval 元循环 fib(20) 10.3ms（v2 重录） | 同上 + 每步 ClosureData 分配 | B3 | 对照面设计目的（parity 双路径互查）——性能非其验收轴 |
| 字节码编译 ~7.7µs/fib 全链（v2 重录；子轴 read 1.4 / expand 3.5 / compile+verify 1.5） | 线性于 AST | B1 + B1a/b/c | 无热点；子轴归因面已备（§9.61 PERF-3） |
| 标记-清除全停顿 | O(live+slots) | B4 | Stage 2+ 演进窗登记（分代/并发 GC——stage0.md §9.43 K7 对照表已登记） |

**结论**：Stage 0 无功能性性能缺陷（语义正确性优先——原则 19）；B4 全停顿 GC 为已知登记态演进窗，非本阶段债。

## 4. 变更同步义务（规则 5——r60 强化版）

- **触发面（r60 扩充）**：本表由每次触碰**生产面**的轮次重跑刷新——即 `crates/*/src` 任何变更（含表示层——§9.44.3 第 1 行族：表示置换类变更直接影响 B1 链，T35 先例即属此类）或基准 harness 本体（examples/bench/）变更；worklog 记录对比。
- **r60 失察修复记录（§9.61 PERF-4）**：T30-T37 十轮无 B 系列重跑记录（v0.24.0-v0.29.0——其中 T33/T35 触碰生产面）；本次重录验证失察期**零回归**（B1 7.7µs 与 v0.23.0 实测一致 / B4 确定性计数与首录逐位一致）；起每轮九项复查增设第 ⑩ 项「B 系列重跑义务核对」，守卫测试 perf_observability_guard_tests 锚定 B4 确定性计数防再犯。
- `docs/tests/pipeline-test-coverage.md` 性能基线表引用本文件（不重复承载——单一事实源 §8.4.5）。
- 基线数值只在环境变更（rustc/CPU）、有意优化或有意方法学变更时整体重录（再基线须文档化记录——本次 v2 重录即先例），禁止静默漂移。

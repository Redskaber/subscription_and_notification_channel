# kerf release notes

## v0.40.0 — interlude: the reader round (the scan goes byte-dispatched and zero-copy; both literal-overflow faces fail closed; the literal errors point at the token)

The §9.71 review opens the reader domain (RDR ruling family, 10
faces: 3 implemented, 7 maintained) — the kerf-reader crate's scan,
classification, and error surfaces last specifically reviewed at
§9.44 (v0.15.0, twenty-four versions ago); every later touch was a
cross-cutting fix (the §9.58 error passthrough, the §9.52 single
pool), never a domain round.

- **RDR-1 — the byte-dispatched, zero-copy scan.** Every scan loop
  (trivia, comments, atoms, string runs) dispatches on bytes: the
  ASCII fast path advances by single bytes and never decodes, and
  only non-ASCII bytes pay a UTF-8 decode (the V8 range-scan
  discipline, K142; rustc holds one `Chars` and clones per peek —
  kerf's old per-peek re-slice was the worst of the three shapes,
  K137). Atoms classify from a zero-copy slice of the source (the
  run is contiguous and both ends are char boundaries by
  construction) — the per-atom intermediate `String` allocation
  retires (rustc tokens are lengths over the source; the consumer
  slices once, K137). String literals bulk-copy plain ASCII runs
  between the specials. The whole token stream (kinds + byte spans)
  is pinned byte-identical on a mixed-width fixture (BOM, CJK
  atoms, the vertical-tab separator that `u8::is_ascii_whitespace`
  would miss, non-ASCII inside comments, escapes, adjacency).
- **RDR-2 — both literal-overflow faces fail closed.** An
  integer-shaped atom that overflows `i64` is no longer silently
  demoted to a float (the strict Int/Float typing contradicted at
  the lexical floor), and a float-shaped atom that overflows `f64`
  is no longer silently read as ±inf — two new variants,
  `IntOutOfRange` and `FloatOutOfRange` (K138: rustc denies both
  faces by default with the same split; K139: the Go spec requires
  an error when an integer constant cannot be represented precisely
  or a float overflows, while precision-limited underflow rounds to
  the nearest representable value — so `1e-999` stays legal as
  `0.0`). The escape is spelling the value as a float (`1e20`,
  `99999999999999999999.0`).
- **RDR-3 — the literal errors point at the token.** The literal
  family (`InvalidBool`, `MalformedNumber`, and the two new
  overflow variants) carries its whole-token span; the driver's
  diagnostic renders the real extent (a caret run under the
  literal, exactly the rustc shape) instead of rendering no
  location line at all — `1.2.3` in a large file used to have to be
  found by hand. `offset()` keeps its honesty rule (no fabricated
  single byte); the new `token_span()` surfaces the real extent.
- Maintained: the eager token vector (incremental parsing stays a
  registered Stage-2 LSP window), the 256/512/1024 three-tier
  nesting caps, the BOM-anywhere leniency, the dotted-pair `.`
  identifier surface, the position-free Display (§9.56 DIAG-1), the
  parser's deterministic error precedence, and the single-source
  dictionary delegation for `InvalidSymbol`.
- Frontier anchors K137-K142 (rustc_lexer cursor/lib — the
  byte-note `eat_while`, length-tokens, memchr comments; the rustc
  1.98.1 empirical probe on `1e999`/`99999999999999999999`/`1e-999`
  — deny, deny, accept; the Go spec constant-expression rules;
  CPython `parsenumber_raw` with its in-source "XXX Huge floats
  may silently fail"; Lua `read_numeral`; the V8 scanner range
  scan). Corpus +2 negative (neg-054 i64 overflow, neg-055 float
  overflow — 79 → 81 cases). Guards: the rich-fixture byte pin, the
  overflow faces at both signs, the inclusive boundaries
  (i64::MAX/MIN, f64::MAX), underflow-to-zero, the spelled-float
  escape, the driver render goldens (ds11), the diagnostic
  whole-token spans. Six commands green; B1a read-fib re-measured
  on the byte-dispatched scan.

## v0.39.0 — interlude: the compiler lowering round (the constant pool goes pre-hashed with a predicate truth; the jump patch bookkeeping rides in the instruction stream; let slots recycle)

The §9.70 review opens the compiler lowering and instruction
emission domain (EMI ruling family, 10 faces: 3 implemented, 6
maintained, 1 window registration) — the kerf-compiler crate's
algorithm faces (instruction selection, jump backpatching, constant
pool interning, slot allocation) last specifically reviewed at
§9.49 (v0.20.0, nineteen rounds ago).

- **EMI-1 — pre-hashed constant interning with a predicate truth.**
  Every literal occurrence used to deep-clone its `ConstKey` mirror
  (strings cloned, pairs recursively boxed) just to probe the dedup
  map — and the mirror type carried a second, manually-synced copy
  of the pool semantics (NaN folds, ±0.0 stay distinct). The pool
  now keys by a deterministic FNV-1a hash computed over the literal
  itself (fixed seed, wrapping multiply — rustc `Unhasher`
  discipline) with collision buckets resolved by the
  `same_const_slot` predicate against the pool entries (Lua `addk`:
  the index is only a hint, the pool entry is the truth). Zero
  allocation on the probe path; the mirror type retires; pool
  output is bit-identical (first-use insertion order preserved).
- **EMI-2 — jump patch bookkeeping rides in the instruction
  stream.** Pending jumps used to be tracked in two parallel
  structures (`jump_sources: HashMap<usize, i32>` +
  `unpatched: Vec<usize>`), patched through an O(pending) position
  scan. The source depth now rides in the jump's unused `b` operand
  at emission, membership is the `a == JUMP_PLACEHOLDER` sentinel
  (O(1)), `patch` writes the target and clears `b` back to zero
  (the "unused slot is always 0" output contract holds for finished
  products), and `finish` scans for placeholder jumps in code order
  (Lua patchlist discipline — the code is the bookkeeping; the list
  machinery itself is not adopted: kerf patches single jumps with
  depth assertions, principle over mechanism).
- **EMI-3 — let slots recycle through a LIFO free-list.** Slots
  were allocated monotonically and never reused, so `n_locals`
  grew with the cumulative binding count while the VM allocates
  `vec![Value::Nil; n_locals]` per call. `locals_truncate` now
  returns dead slots to a per-proto free-list and `alloc_local`
  hands them back LIFO (deterministic; Lua `freereg` window
  discipline) — `n_locals` is the peak simultaneous count. Valid
  because compile products are back-edge-free: a reused slot's
  earlier readers always execute before its re-binder. Shadowing
  keeps distinct slots (simultaneously live bindings).
- **Maintained** — the Vec reverse-scan local lookup (rustc Rib
  discipline, §9.68 CHK-8 precedent), the one-pass backpatch shape
  (CPython's symbolic-label indirection buys multi-pass
  optimization kerf does not have), the args-then-callee evaluation
  order (§19.3/§19.5 frozen contract), the exact-dedup contract
  (NaN single slot, ±0.0 distinct — Lua's tolerant "wastes an
  entry" philosophy declined), the verify DAG depth propagation,
  and the single `emit` path with automatic debug_info.
- **Registered W-EMI-COMPILE-AXIS** (compile-time measurement
  window; trigger: the self-host corpus compile becomes a measured
  concern at Stage 2, currently no dedicated B axis).
- Frontier anchors K132-K136 (Lua 5.4 lcode.c addk/patchlist/
  freereg + lparser.c + lobject.h, CPython 3.12 compile.c label
  indirection + deterministic slot order, rustc unhash.rs + span
  symbol.rs intern_inner, V8 baseline constant-pool consumption).
- Guards +4 (predicate truth end-to-end: ±0/NaN/string/pair slot
  identity; sibling-scope slot reuse + shadowing freshness; patched
  jumps restore the zero-operand contract; full-pipeline VM
  integration with recycled slots); 1205:0:0 + audit 200/200.

# kerf release notes

## v0.38.0 — interlude: the VM execution-core round (materialization goes single-source and batch; the call window becomes one move)

The §9.69 review opens the first algorithm-level domain of the
execution core (EXC ruling family, 10 faces: 3 implemented, 6
maintained, 1 window registration). Distinct from §9.53 (the storage
domain: heap/GC/budget/roots) and the §9.44.3 census row 7 (the
dispatch form), this round audits the execution algorithm faces:
the call protocol's argument traffic, the operand-stack discipline,
and the constant-materialization budget protocol.

- **EXC-1 — `LiteralValue::pair_cells` single-sourced (kerf-core).**
  The literal cell-count helper existed as twins (`vm.rs
  materialize` and `eval.rs`'s `Literal` arm each carried a private
  recursive walker); the count now lives once on `LiteralValue`
  itself and both engines budget against the same method (§20.3
  same-path discipline).
- **EXC-2 — one `reserve_exact(n)` batch per materialization.** The
  per-cell reserve loop performed `n` identical budget checks (live
  usage only moves when `heap.alloc` runs in the walk that
  follows); both engines now charge the whole batch in one check
  under the same condition — the accept/reject boundary, the
  collect-then-retry point, and the success-path allocation totals
  are bit-identical (pinned from both sides by guards).
- **EXC-3 — `take_args` becomes one stack-window move.** The
  pop-loop + reverse (2×argc value moves per call) is now a single
  `split_off` of the argument window — the args leave the caller's
  stack in call order, one move each (the Lua OP_CALL
  register-window discipline expressed within safe-Rust per-frame
  stacks, K127).
- Maintained: the 24-arm match dispatch (threaded code needs
  label-as-value — not available in safe Rust; K129/K130), the
  whole-frame closure snapshot (Stage 2 capture window), the
  handler-stack reverse scan, the register-machine window (K131),
  the per-frame operand stacks (K126 — the single contiguous
  valuestack would fight the borrow checker; Pulley chose a register
  file for the same reason), and the fetch double-index form.
- Registered **W-VM-SUPERINSTR** (superinstruction/macro-op fusion
  window — Pulley's in-tree macro-op rationale K128 and BEAM's
  loader; trigger: a B-axis profile showing dispatch-bound hot
  spots; zero signal today).
- Frontier anchors **K126-K131** (CPython ceval/bytecodes call
  protocol + operand-stack-as-frame-region, Lua 5.4 lvm/ldo register
  windows, Wasmtime Pulley's safe-Rust register ISA guidelines, BEAM
  beam_emu dispatch commentary — the alignment experiment that
  *slowed* the emulator ~5%, OCaml interp.c computed-goto dispatch,
  and the register-vs-stack systematic comparisons). Weak-query
  disclosure round 15; the VEE'05 showdown full text was not
  fetchable this round (dead fetches registered honestly).
- Guards +4: `pair_cells` exact footprint counts (kerf-core), the
  batch boundary pinned from both sides (kerf-vm), the window-order
  call round-trip (kerf-vm), and the cross-engine budget-boundary
  parity (root `vm_seed_tests` — both engines accept budget 2 and
  reject budget 1 on the same three-cell quoted list).
- Baseline: **1201:0:0** (+4) + audit 200/200 + B-series all
  in-band (rule-5 rerun; vm/runtime/core sources touched).

## v0.37.0 — interlude: the checker work-state round (the typecheck tables join the single identity base)

The §9.68 review opens the NB-9 registered domain — the checker's
working state (CHK ruling family, 9 faces: 6 implemented, 2
maintained, 1 window registration). With this round the
single-identity base covers the whole pipeline: syntax tree,
CoreExpr, module loader, error family, expander tables, the run-time
name tables, and now the static checker's tables — the §9.52 chain
closes end to end.

**The check.rs module table (CHK-1/CHK-2).** `Table.defines
Vec<(String, DefineShape)>` and `Table.assigned HashSet<String>` were
text-keyed: every define paid one `to_owned()` heap allocation at
collection, every Var resolution a byte-string comparison on the
reverse scan — while the pool entry sat in hand (`ModuleItem::Define.
name` is already a `Symbol`). The table now clones the 4-byte entry:
collection allocates nothing, the reverse scan compares indices, the
assign guard set hashes on the entry (the position-aware visibility
slice `defines[..defined_so_far]` is untouched — walk order is the
definition identity, mirroring how rustc keys its checker contexts by
`LocalDefId`, not by name — K121).

**The infer.rs mirror (CHK-3/CHK-4/CHK-5).** The HM engine's
`DefineTable` had drifted from its check.rs mirror: `assigned` was a
`Vec<String>` with a manual scan-then-push dedup (check.rs already
used a `HashSet`). Both tables now share the exact `HashSet<Symbol>`
form (the §9.44 assigned-guard generalization obligation cleared),
the local environment entries (`LocalEntry.name`) clone the param/
binding entries the tree already holds, and the SCC call-graph
over-approximation (`collect_var_names`) collects pool identities —
the edge construction compares indices instead of byte strings
(`r == name`, the GHC `Unique` fast-comparison discipline — K122).

**The externals boundary (CHK-6).** `Externals` keeps its `&str`
construction face (callers hold authoritative text —
`STAGE0_GLOBALS`/`Builtin::ALL` at the three consumption sites) but
interns at construction and resolves by identity:
`resolve(&Symbol)`. A floor-rejected externals name fails fast (it
could never match a Var — those are validated Symbols; the
`builtin_symbol` seeding face uses the same discipline — NB-5). The
rustc resolver's `Rib` bindings are keyed the same way
(`FxIndexMap<Ident, R>` — interned identity, insert-ordered — K123);
OCaml's classic HM environment is `Ident`-keyed, never string-keyed
(K124).

**Maintained (CHK-7/CHK-8).** The 18-arm ad-hoc builtin dispatch
(`builtin_type`) keeps its str-literal match arms — a static
dispatch face (a runtime pool index cannot literal-match; K125
supports keeping literal dispatch at static faces). The
Vec-plus-reverse-scan shapes stay (defines table, local environment,
externals table): insert order carries the position-aware visibility
and last-wins shadowing semantics — a hash map would break the
visibility slice and add iteration-order hazards (§9.55); at module
scale the linear scans are noise (the B axes do not cross typecheck
— zero signal).

**Registered window (CHK-9).** W-CHK-DEFINE-HASH covers the
escalation of the define/environment reverse scans to hash indexes —
trigger: a B axis attributes cost to define-resolution scans. Zero
signal today.

Workspace: 1197:0:0 (+3 pool-identity guards), audit 200/200, B
series all in-band (B3 keeps the §9.67 −34.3% eval improvement at
6.78ms; B4 deterministic counters bit-identical), zero new
dependencies, TD open items 0.

## v0.36.0 — interlude: the name backend round (the run-time name tables join the single identity base)

The §9.67 review opens the TRF-13 registered domain — the name-based
back half (NB ruling family, 9 faces: 6 implemented, 2 maintained,
1 domain registration). With this round the single-identity base
covers the whole pipeline: syntax tree, CoreExpr, module loader,
error family, expander tables, and now the run-time name tables.

**The evaluator's name tables (NB-1/NB-2/NB-3/NB-4).** The
evaluator's globals (`HashMap<String, Value>`), binding-site
environment (`Vec<(String, usize)>`), handler stack
(`Vec<(String, Value)>`), and closure names (`Option<String>`) were
text-keyed: every define/assign stored a fresh `String`, every Var
fallback and every resolve step paid a full-text hash or byte
comparison — while the pool entry (`Symbol`) sat in hand at every
call site (`CoreExpr::Var.name`, `params: &[Symbol]`,
`clause.effect`). All four tables now key on the interned entry: a
4-byte clone per store, a 4-byte comparison per scan step, zero
allocation per binding (params and lets clone the entry they
already hold).

**The arity payload (NB-5).** `ArityMismatch.func` was the error
family's last text identity payload (a fresh `String` per error,
`#<anonymous>` invented per anonymous-closure error). It is now
`Option<Symbol>` — `None` renders `#<anonymous>`, mirroring the
`UnboundGlobal`/`UnhandledEffect` payload faces. The 18 builtin
names intern once per process through a `OnceLock` table derived
from `Builtin::ALL` (the single text source — the derived table
cannot drift, guard-pinned; the `rustc_span::sym` pre-interning
discipline).

**Identity observation faces (NB-7).** `Evaluator::global_sym`,
`Vm::global_names`, `Vm::global_sym`, and `RunOutcome::global_sym`
join the existing text faces. The driver's VM branch snapshots the
bytecode's own global name table (it is already `Vec<Symbol>` — no
de-intern of the roster); the eval branch reads the Define names as
pool entries; the parity face resolves each Define by interned
identity (the repr column stays text — the rendering protocol
face). The §9.60.5 dual contract is unchanged (which names appear
in a snapshot follows the same three clauses).

**Maintained (NB-6/NB-8).** The VM's global hot path resolves at
compile time — `instr.a` is the pool index of the bytecode's global
table, so `LdGlobal`/`StGlobal` never look up a name at run time
(CPython pays runtime dict lookups per LOAD_GLOBAL and amortizes
them with adaptive specialization — K116; the compile-time form is
the stronger shape, now documented). A new registration window
W-NAME-INLINE-CACHE covers the more aggressive forms (inline
caches, slot NaN-boxing) — zero signal. The text observation faces
(`global(&str)` on all three types) stay linear scans so a miss
query never pollutes the interning pool.

**Registered next domain (NB-9).** The typechecker's working state
— `CheckerState.defines: Vec<(String, DefineShape)>` and
`assigned: HashSet<String>` — is the identity base's last
text-keyed remainder (the §9.50 checker review predates the §9.52
single-pool unification); registered as the next candidate domain.

**Guards (+3) and baselines.** 1191:0:0 → **1194:0:0** (+3: the
derived builtin-symbol table matches the registry and the pool; the
evaluator's name tables round-trip through the single pool with
miss-non-pollution; the halt snapshots carry pool identities on
both engines). audit 200/200; doc warnings 1 (the registered
cargo#6313 collision, unchanged); B-series rerun per §14.6.4 rule
5: **B3 eval-run-fib20 10.345ms → 6.796ms (−34.3%) — the round's
main account** (the meta-circular evaluator's name face went
zero-text), B1/B1a/B1b/B1c bit-identical after the first-run
cross-session variance converged (7.7µs / 1.4µs / 3.6µs / 1.5µs),
B2/B5 in-band, B4 deterministic counts bit-identical (gc-cycles 1,
swept 1023). Frontier anchors K116-K120 (CPython ceval/bytecodes
LOAD_GLOBAL specialization, Lua lstring.c interning discipline,
Lua _ENV globals + the prestrings experiment, V8 InternalizedString
canonicalization, Chez symbol uniqueness). 8 primitives invariant
verified for the 40th round (run-time name tables are keying and
allocation shape — syntax, expansion, and the VM instruction stream
untouched; dual-engine equivalence pinned by the 79-corpus parity
replay and the 200-case audit); zero new dependencies; weak-query
disclosure round 13 (q1/q5/q6 garbage, q2 weak — six primary
sources read in full instead; the m6 C0VM PDF fetch 404'd and was
not archived, the constant-pool knowledge rides the q7 snippet).

## v0.35.0 — interlude: the expander lexical/transformer identity round (the frame tables and the pattern machine join the single identity base)

The §9.66 review opens the EXP-13 registered domain — the expander's
own working state (TRF ruling family, 13 faces: 8 implemented, 4
maintained, 1 domain registration).

**Frame tables (TRF-1/TRF-2/TRF-3).** `Frame.names` and
`Frame.macros` were text-keyed (`HashSet<String>` /
`HashMap<String, usize>`) with a fresh `String` allocation on every
bind; `resolve`/`resolve_macro` de-interned the tree's `Symbol` to
run text lookups. Both tables now key on the pool entry — the
caller hands over the `Symbol` the syntax tree already carries
(rustc's resolver tables are keyed the same way: `Ident { name:
Symbol }`, `macro_use_prelude: FxIndexMap<Symbol, _>` — K111/K112),
and the `STAGE0_GLOBALS` fallback runs over a pre-interned
`OnceLock<HashSet<Symbol>>` seeded once (the `rustc_span::sym`
pre-interning discipline — K113).

**The pattern machine (TRF-4/TRF-5/TRF-7).** `Pattern::Literal` and
`Pattern::Var` carry pool entries (index comparison per match
position instead of byte comparison); the bindings map inserts a
4-byte pool-entry clone where it used to heap-clone a `String` per
pattern variable per attempt; the rename stack is
`Vec<(Symbol, Symbol)>` and `fresh_name` interns its genuinely-new
target once.

**The trigger set (TRF-6).** Every macro instantiation used to
re-seed the rename-on-capture trigger set from scratch:
`STAGE0_GLOBALS.iter().map(to_owned)` (18 strings) +
`RESERVED_MACRO_NAMES` (15 strings) + one `to_owned` per distinct
symbol in every spliced argument — ~45+ `String` allocations per
macro use, on the hottest expander path. The set now holds pool
entries; the static tables are pre-interned once and copied entry by
entry. Zero text allocation per instantiation (B1b in-band at
3.6µs vs 3.7µs recorded).

**Call-site discipline (TRF-8).** `expand_symbol`/`expand_set` feed
the pool entry straight into `resolve`; `expand_fn_binding` binds
params by entry; `define`/`define-syntax` bind entries. The one
text crossing left is the core checked-constructor boundary
(`var`/`fn_`/`assign`/`Binding::new` take `&str` — the §9.58
established design, K110 intern-once-at-boundary; the pool-hit
re-intern is a hash lookup, zero allocation). Maintained:
constructor signatures stay (TRF-9 — the 67-site ripple is not
justified by two hash lookups); literal text-matching semantics
stay (TRF-10 — under the single-pool invariant text equality and
pool equality coincide, the R6RS free-identifier=? unbound-tier
equivalence, K114); `Pattern::Atom::Str` stays a value payload
(TRF-11); `fresh_name` keeps its one `format!` (TRF-12, the MX-1
mangled-record precedent).

**A survey dividend: the doc-warning backlog cleared (22 → 1).**
The round's baseline verification exposed that previous rounds'
`tail -2` verification masked 22 pre-existing `cargo doc` warnings
(intra-doc links to private items across five crates, bare
`funcs[0]` parsed as reference links, cross-crate `Bytecode::*`
links). All sixteen fixable warnings are cleared this round (doc
comments only, zero semantic change); the one remaining warning is
the cargo output-filename collision (cargo#6313 — bin `kerf` and
lib `kerf` share a doc path; not fixable in-tree without renaming a
public target — registered maintained).

**Registered next domain (TRF-13).** The name-based back half —
`CoreExpr::Var` → bytecode globals table → VM/eval
`HashMap<String, Value>` — is the reason the rename-on-capture
bridge exists; it is registered as the next candidate domain (the
VM stays the permanent Rust base; key-type evolution is a semantic
face needing its own frontier review).

**Guards (+3) and baselines.** 1188:0:0 → **1191:0:0** (+3: the
frame tables round-trip through the single pool; literal matching
judges by the pool entry; static name tables are pre-interned pool
entries). audit 200/200; B-series rerun all in-band (B4
deterministic counts bit-identical: gc-cycles 1, swept 1023);
frontier anchors K111-K115 (rustc_span Ident/Symbol, rustc_resolve
macro_use_prelude, rustc_span::sym pre-interning, R6RS 12.8
free-identifier=? two-tier semantics, Dybvig 1992 syntax-case
literal matching — snippet-level). 8 primitives invariant verified
for the 39th round (identity keying is a table/keying change:
syntax surface, expansion behavior, and the VM untouched); zero new
dependencies; weak-query disclosure round 12 (q1/q2/q5/q7 garbage
— four primary sources read in full instead).

## v0.34.0 — interlude: the expander error payload round (the error family joins the single identity base)

The §9.65 review opens the expander error payload domain — the
MOD-11 maintained item promoted to a full EXP ruling family (13
faces: 6 implemented, 6 maintained, 1 domain registration).

**Identity payloads (EXP-1/2/4/5).** Four identity-bearing error
payloads were text copies made at construction sites where the
interned identity was already in hand: `UnboundIdentifier.name` and
`MacroPatternMismatch.name` (the syntax tree's `Symbol`, bridged to
`&str` and copied back out as `String`), `CoreError::DuplicateParam`
(the constructor had just built the `Vec<Symbol>` and re-copied the
text on the error path), and `CoreError::DuplicateHandler` (the
clause's effect was already a `Symbol`, de-interned only to be
re-owned). All four now carry `Symbol` — a 4-byte clone, never a
text copy. `Display` renders byte-identically through the `as_str`
bridge; the hand-written `Symbol` Debug keeps the derived shape
(`Symbol { text: "x" }`), and no golden pins an `ExpandError` Debug
rendering. Equality strengthens from text equality to pool-entry
equality — the exact contract the .krf parity decoder relies on.

**The transformer source chain (EXP-3).** `SyntaxRules::parse` took
`&str`, owned it as `String`, and cloned the `String` into every
mismatch error: two allocations per declaration plus one per error,
and a phantom failure path (the name was already validated by the
checked constructor, so an in-parse `Symbol::new` could never fail —
yet the signature demanded the error be handled). The parse now
takes the `Symbol` itself: the declaration identity flows from the
syntax tree, the mismatch error clones the pool entry, and the
phantom failure surface is gone.

**The parity decoders (EXP-6).** Four error-reconstruction sites
(unbound, macro-mismatch, dup-param, dup-handler) rebuild their
payloads through the single pool (`Symbol::new`), matching the
v0.33.0 MOD-1 decoder precedent — the .krf oracle protocol (a
`Value::Str` payload) is unchanged on the selfhost side.

**Maintained faces.** `MalformedForm` keeps `&'static str` (a closed
static set — the K107 three-tier discipline: identity = Symbol,
non-identity text = String, static descriptors = `&'static str`);
numeric and enum payloads keep their shapes; `InvalidSymbol` keeps
its `String` text by design (the rejected text cannot be interned by
definition — a fail-closed payload has no identity to carry);
span-only variants carry no identity at all. `krf_name` stays
String-typed for the dump/rebuild text-protocol faces.

**Registration (EXP-13).** The expander's lexical tables
(`Frame.macros`, `bind`/`bind_macro` `&str` keys) and the transformer
internals (literals, bindings, renames) are registered as the next
candidate domain — resolution is a hot path, a different
performance/identity trade than the cold error path (the K110
mitigation argument does not transfer).

Anchors: K107 (rustc_resolve diagnostics — the payload three-tier
discipline), K108 (rustc DiagArgValue `Cow<'static, str>` bridge),
K109 (Racket `raise-syntax-error` — the name is a symbol extracted
from the syntax object; the dedicated `exn:fail:syntax:unbound`
subfamily), K110 (rustc_span `Symbol` — Copy u32 newtype; the
DroplessArena permanence trade-off registered head-on: the defect
face is memory that never frees, the mitigation is that names are
already interned by the front end and errors are cold paths).

Tests: 1185 → 1188:0:0 (+3 guards — the pool round-trip family:
expander error payloads, transformer registered identity, core
duplicate payloads), audit 200/200. Eight-primitive invariance
re-verified (38th round — the error family is a diagnostics face,
not a semantic one: expansion behavior is unchanged).

## v0.33.0 — interlude: the module-system round (the loader joins the single identity base, and the collection order tells the truth)

The §9.64 review opens the module-system domain — the last
pipeline-surface code domain that had never had a dedicated section
(the declaration layer, the loading layer, and every consumer face:
compiler flat walk, evaluator flattening, checker skip arms, driver
assembly, REPL accumulated replay, corpus).

**Identity (MOD-1).** The loading layer keyed every module — the
declaration map, the declaration order, the DFS colors, the cycle
path, the error payloads, the load plan — on `String` copies of
interned `Symbol`s: a de-interned text bridge, one allocation per
lookup per edge per visit, the last text-identity face left on the
pipeline after the §9.58 single-pool unification. The layer now keys
on `Symbol` throughout: `ModuleError` payloads carry the interned
identity, `LoadPlan::order()` returns `&[Symbol]`, and the parity
fixture decoders reconstruct through the single pool. `Display`
rendering is byte-identical — every pinned golden (corpus parity,
audit J, module unit tests) survives unchanged.

**The collection order (MOD-2).** Two doc comments claimed
"first-seen declaration order"; the 0.9 collection walk was a LIFO
stack that recorded cross-level nested modules in reverse encounter
order (a1 under a, then b1 under b, recorded b1 first). The walk is
now an iterative pre-order iterator stack — a module is recorded the
moment it is encountered in source reading order, children before
later siblings, no recursion (hand-built trees can nest arbitrarily
deep; the loader never recurses on untrusted shapes). A guard test
pins the cross-level case (a, a1, b, b1). The edge walk keeps its
deterministic LIFO shape — the cycle path and triggering span it
selects are corpus- and parity-pinned, and no doc claim was attached
to it.

**Duplicate defines, recorded (MOD-3).** Duplicate *module*
declarations are rejected fail-closed (ModuleDuplicate); duplicate
*define* names are not rejected anywhere — flat compilation and
evaluation both store the last definition into the same global slot,
engines symmetric, parity observing every define. That is the Stage 0
flat-namespace semantics, now written down where it lives (the
loading-layer header). The module-body duplicate semantics
(single-assignment constants — the Racket two-face model, K104:
module-body identifiers without set! are constants, re-declaration
not generally allowed, REPL re-declaration may fail on constant
redefinition) is registered as the Stage 1 module-system window
(W-MOD-DUP-DEFINE); implementing it ahead of its stage would be
premature — the registered-theory discipline holds.

Six commands all green; 1185:0:0 (the +1 is the MOD-2 order guard);
audit 200/200; review anchors K102-K106 (Rust Reference module tree;
Racket module syntax name/path split; Racket module-body constants;
Chez libraries/top-level-program two-face; rustc E0428 duplicate
wording) — ten consecutive rounds of weak-query disclosure, all
carried by primary-source direct reads.


# kerf release notes

## v0.32.0 — interlude: the resource-limits round (the ladder gets a single source, and the termination argument becomes a chain)

The §9.63 review opens the resource-limits and budget-governance
domain — survey-segment gap identification, fifth case: the limits
family was scattered across five crates, each site locally documented
and locally boundary-tested, but never governed as a ladder. The
layering (256 → 512 → 512 → 1024 → 2048, plus the 8Mi allocation
budget) existed only as pairwise comments; nothing asserted the
ratios; three load-bearing facts for termination lived in three
separate comments.

**The ladder, single-sourced (LIM-1).** A new root-tree guard test
pins all six constants at their exact values and asserts the
relational invariants. The expander-over-reader and
compiler-over-expander headroom ratios are spelled as const blocks —
drift now breaks the build, not just a test run. The two 512s
(expansion and inference) are cross-asserted so they cannot drift
apart silently.

**The termination argument, as a chain (LIM-3).** The Stage 0 subset
has no loop primitive (§9.45); the VM does no tail-call reuse (every
closure call pushes a frame); every frame and heap cell is a budget
charge against the LIVE footprint. Therefore every non-terminating
program grows the live usage monotonically and ends in a structured
`BudgetExceeded` — never a hang. The guard test
`vm_budget_catches_non_terminating_programs` is that argument made
executable: read → expand → compile → run under budget 64 → the
structured error, end to end.

**Exact boundaries (LIM-7).** A probe pinned the single-call
program's peak live usage at exactly three units (entry frame + the
define's closure cell + the call frame): budget 3 admits it, budget
2 rejects it at the call frame. The first draft guessed two — the
closure cell was missed — the probe caught it, and the miss is on
record. The budget is exact, not approximate.

**Maintained against the frontier (K98-K101).** rustc's
recursion_limit (default 128, crate-attribute-tunable) and GCC's
-ftemplate-depth (default 900, flag-tunable) are both depth-only —
as is kerf; a macro's sibling fan-out (a breadth bomb) remains
unbounded by any depth cap, and the industry takes the same stance
under the same threat model (developer-owned source, not untrusted
input). The escape hatch is registered: W-EXP-WORK, with wasmtime's
fuel/epoch dichotomy (K100 — deterministic-but-instrumented vs
cheap-but-cooperative) as the reference when an untrusted-input
scenario (LSP) ever arrives. kerf's allocation-granularity charging
is a third form: deterministic, zero instrumentation cost, and
sufficient only because the language has no loops — the
construction that makes the argument work. Racket's expand pass
recurses without a published numeric cap (K101); kerf's explicit 512
is the more defensive shape. Two more windows: W-LIMIT-TUNABLE
(attribute/flag tunability when real programs legitimately exceed a
limit) and W-REPL-ACC-GROWTH (session accumulation).

Six commands green: fmt clean, build/check/clippy 0/0, test
1180 → 1184:0:0 (+4 guard family), audit 200/200. Eight-primitive
invariance round thirty-six: zero new primitives, zero channels,
zero VM changes, zero syntax, zero EBNF — crates/*/src untouched
this round (a pure root-tree test + documentation increment; the
six constants and every charging site are exactly as they were).

# kerf release notes

## v0.31.0 — interlude: the user-surface round (REPL incompleteness family + declaration-heads single source + CLI strictness and engine flag)

The §9.62 review opens the user-interaction surface domain: the CLI
(`cli.rs`), the REPL (`repl.rs`), and the diagnostic renderer
(`render.rs`) — 1743 lines of real code that every prior segment had
only ever side-audited as a "consumer" of the pipeline, diagnostics,
or orchestration domains. The survey lineage (§9.43-§9.61) had twelve
pipeline-stage segments plus measurement methodology; the layer where
the user actually meets the compiler had none.

**The incompleteness family, unified (SURF-1).** The reader
distinguishes two ways input can end mid-structure: an unclosed list
(`UnclosedList`) and an unterminated string (`UnterminatedString`).
The REPL mapped only the first to its continuation event; an
unterminated string was rejected on the spot — so a multi-line string,
a shape file mode has always accepted (raw newlines inside string
literals, Scheme tradition), was unreachable from the REPL. Both
incompleteness variants now produce NeedMoreInput; the malformed
family (bad escapes, stray closes, bad numbers, over-deep nesting)
still errors immediately. Multi-line strings now build across
submissions exactly like multi-line lists.

**The declaration-heads single source (SURF-2).** The REPL classifies
submissions by head: declarations pass through, expressions wrap into
`$repl:N` defines. That classification lived in a second hand-kept
list in the driver while the expander's dispatch table held the truth
— a silent-drift risk the moment Stage 2 grows a new top-level form.
The expander now exports `TOP_LEVEL_DECLARATION_HEADS` as the single
source, enforced by a gate-then-dispatch structure: a const member
with no dispatch arm falls to a fail-closed arm and fails the
const-vs-arm sync test; an arm without a const member is unreachable
dead code. The driver consumes the const; the hand-kept twin retires.
A behavioral guard on the driver side pins the other direction: every
declaration head, when wrapped into a define, is rejected by the
pipeline — the invariant that makes pass-through classification
necessary.

**CLI strictness and the engine flag (SURF-3/SURF-5).** `--version`
gains the same trailing-argument strictness as `--help` (before,
`kerf --version foo` silently ignored `foo`). `kerf repl` gains
`--engine vm|eval` — the run command always had the choice, the
library always had the capability (`Repl::with_options`), but the
eval engine was unreachable from the binary. The greeting stops
saying "one form per line" — the REPL has always accepted multi-line
forms; the banner now says what the machine does.

**Maintained against the frontier (K92-K97).** miette renders its
fancy layer (unicode-width carets, ANSI color, terminal sizing) as a
feature-gated option — kerf's char-count, colorless, deterministic
core is the pre-fancy position, with width, color, and a JSON
emitter registered as windows (W-RENDER-WIDTH/COLOR/JSON; rustc's
dual human+JSON emitter is the anchor for the third). MIT Scheme's
error REPLs nest — a level-2 REPL over a waiting level-1, with a
restart menu; kerf's transactional rollback is the determinism-first
alternative (a nested REPL's session state is not expressible as
source text, which the tape-replay semantics require). clap's
`exit_code` contract — usage errors exit 2 — is exactly kerf's
0/1/2. The gcc/rustc source-line-plus-caret default shape is exactly
kerf's. Maintained, with the reasoning on record.

Six commands green: fmt clean, build/check/clippy 0/0, test
1180:0:0 (+9: the expander sync guard, four REPL tests, four CLI
tests), audit 200/200. Eight-primitive invariance re-verified
(round thirty-five): zero new primitives, zero channels, zero VM
changes, zero syntax additions, zero EBNF — the surface round is
wrapping and flags only.

## v0.30.0 — interlude: the performance-engineering round (benchmark methodology v2 + the §14.6.4 rule-5 relapse repair)

The §9.61 review opens the performance-engineering domain: the one
cross-cut the §9.44-§9.60 survey lineage had never visited. Every
pipeline stage, the bootstrap segments, memory, determinism,
diagnostics, test infrastructure, crate boundaries, forwarding, and
the driver orchestration had each had a dedicated segment — but the
measurement methodology itself (the empirical face that every
§9.44.3 quantified switch trigger ultimately appeals to) had never
been audited.

**Methodology v2, implemented.** Three frontier adjudications land as
code: (1) optimizer fences — every measured region now takes its
source input through `std::hint::black_box` (K90: a best-effort
discipline, not a guarantee — the limitation is documented in the
harness header so nobody mistakes the fence for a hard one);
(2) warmup — each axis runs `max(3, iters/10)` unrecorded iterations
before its measured loop, so cold caches and first-touch faults land
outside the sample set; (3) four-statistic reporting —
mean/median/min/stdev, with median keeping the primary-criterion seat
and stdev+min exposing outlier contamination that mean/median alone
would hide.

**The sub-axis split (PERF-3).** B1 keeps its composite shape (whole-
chain comparability with every recorded reading since 2026-09-28) and
gains three sub-axes: B1a read 1.4µs, B1b expand 3.5µs, B1c
compile+verify 1.5µs — the stage-attribution face the §9.44.5 trigger
table always demanded but the composite number could never provide.
The sub-axis physics (B1a+B1b+B1c < B1 composite — hotter per-stage
caches) is documented in the baseline file; the two readings are
reported side by side and never derived from each other.

**The rule-5 relapse, repaired in the open.** §14.6.4 rule 5 requires
a B-series re-run on every production-face round. The last recorded
re-run was v0.23.0 (T29): ten rounds lapsed with no reading — and two
of them (T33 diagnostics positions, T35 Symbol single-pool) touched
the compile chain. This round re-runs the full series and the verdict
is clean: B1 7.7µs matches the v0.23.0 reading exactly, B4's
deterministic counters (1 cycle/iter, 1023 swept/iter) match the
2026-09-28 first recording bit-for-bit — the lapse hid no regression,
and the relapse is repaired structurally: the trigger formulation is
widened to cover representation-layer changes, a per-round recheck
item is added, and a new guard test pins the churn program's exact
per-run counters (any GC-semantics drift now trips a test, not a
ten-round silence).

**Docs-reality repair.** benchmarks/README.md claimed "crate
micro-benchmarks go in each crate's benches/" — zero crates have a
benches/ directory. The unimplemented promise is retired into a
registered window (W-PERF-CRATE-BENCH) with an honest trigger: open
only when sub-axis attribution shows an in-crate hotspot the B-series
cannot characterize. Zero-signal, window stays closed.

**Tooling adjudication.** criterion-class statistics tooling would be
the project's first external dependency in a zero-dependency codebase;
the informed ruling stays std-only — `black_box` is std, the fence/
warmup/reporting needs are met without a single new dependency, and
W-PERF-CRITERION registers the escape hatch (trigger: the ±25% band
provably fails, twice, on real regression judgments).

8-primitive invariance: thirty-fourth verification (zero new
primitives, zero channels, zero VM changes, zero syntax, zero EBNF —
the harness change is measurement methodology only; every workload
source string is byte-identical with the pre-change harness, and the
full suite plus audit pass unchanged). Tests 1169 -> 1171 (+2: the
B4 deterministic-counter pin and the methodology-presence source
guard). Audit 200/200.

## v0.29.0 — interlude: the driver-orchestration round (error-propagation ruling + globals roster single-sourcing)

The §9.60 review opens the eighteenth segment of the pipeline survey
lineage: seventeen prior segments (§9.43-§9.59) had covered every
pipeline stage's data structures, the three bootstrap segments, the
backend rows, the checker, interning, memory, determinism,
diagnostics, test infrastructure, and the two-step crate-boundary
cleanup — but the orchestrator itself (pipeline.rs, the glue that runs
all phases in order and the host of the typecheck() ×4 action anchor)
and the error-propagation policy (why each layer returns what it
returns) had never had a dedicated review.

**The asymmetry, ruled in writing.** The survey found the four-layer
error shape asymmetric on purpose, not by drift: reader, expander,
compiler, and runtime return single-error `Result` (fail-fast — each
consumes the previous stage's complete product, and runtime effects
are not rollbackable), while typecheck returns collected batches
(one run surfaces every finding — the diagnostic value of a pure
analysis). Even the check/run divergence is principled: `check`
keeps compiling after a checker error to append more findings (a pure
function, no side effects), `run` aborts before either engine starts
(effects must not begin). This ruling (ERR-PROP) previously lived in
three scattered comments; §9.60.3 is now its single source.

**The frontier verdict, primary-source quadruple-read.** K84
(rustc-dev-guide, the driver chapter): rustc_driver "acts as the glue
for running the various phases of the compiler in the correct order" —
kerf's hardcoded sequence is the same shape minus the `Callbacks`
phase-hook face, justified by scale (three in-house consumer faces,
no third-party driver need; a new W-ORCH-CALLBACK window registers
the trigger). K85 (the lexing-and-parsing chapter): rustc's
`ParseSess`-bound lexer/parser vs kerf's stateless pure-function
reader — both valid at their respective scales, kerf's choice kept
deliberately for parity-face determinism. K86 (oxc.rs "Dealing with
Errors", read in full): the recovery spectrum is three-valued —
fully recoverable (Biome; the linter/formatter need), partially
recoverable (most JS parsers; deterministic-grammar recovery), and
the panicking parser. **kerf's reader sits lawfully on the panicking
seat**: S-expression prefix notation has no unambiguous recovery
point, the parity semantics of a recovered partial AST is undefined,
and the 79-corpus error axis asserts byte-exact single-error output.
K87 (the diagnostic-structs chapter): rustc's `#[derive(Diagnostic)]`
attribute machinery is a 10^3-diagnostic-scale tool; kerf's
hand-written six-converter face at 10^1 scale is the right size.

**The ruling, ★ORCH-1 — two contracts, not two sources.** The survey
first read `run()`'s roster extraction as a single-source-of-truth
gap (VM branch reads `bc.globals`, the Eval branch and the
`run_parity` loop walk `self.items`) and unified all three on the AST
— **and the golden face rejected that reading loudly**: vs01-vs10
failed (`globals` must read `+=#<builtin:+> r=3`), because
`bc.globals` is not a Define-sequence projection at all. The full
re-audit of `intern_global`'s five call sites (LoadGlobal references,
set! targets, Perform and PushHandler effect names, defines) shows
the truth: `bc.globals` is the *global name table*, interning every
name the bytecode can reach — including builtin references. The
correct ruling is that the three rosters are three different
contracts, each already right: the VM branch reports the full global
table (the vs golden face), the Eval branch walks the defines (the
ve point-query face), and parity compares both engines over the
define roster. `run()` keeps its original shape with the contract now
written down ("by contract, not by drift"), and the new guard in the
compiler's tree pins the real invariant: a pure-define program
interns exactly the define sequence, and a vs01-shaped program pulls
the referenced builtin `+` into the table — `["+", "r"]`. The
rejected-first-reading loop is recorded verbatim in §9.60.5 (the
zero-guessing discipline's live lesson: audit every registration
path before ruling a projection).

**Numbers.** Full suite **1169:0:0** (1168 + 1 guard); audit
**200/200**; fmt clean; clippy `-D warnings` clean; 8-primitive
invariance verified for the thirty-third round (a driver-layer
roster-sourcing change touches no payload, no semantics). Stage 2
entry remains explicitly prohibited by the user (r54, reaffirmed
r55-r59).

## v0.28.0 — interlude: the no-forwarding round (cross-crate re-exports retired, SOP §18.5 v15.2)

The §9.59 review is the direct sequel to the Symbol single-pool
unification: v0.27.0 paid off "one type, two definitions"; this round
pays off "one type, many reachability paths". The user's r58
instruction made the rule explicit: *each crate exports only what it
defines — no forwarding, no re-exporting other crates' content; if
another crate needs it, it imports from the defining crate* — naming
kerf-core as still carrying the problem.

**The inventory, verified.** Thirteen cross-crate `pub use` lines
across seven crates: kerf-core re-exported six kerf-span names,
kerf-syntax four, kerf-compiler ten (one whole block "for the Layer 6
consumer"), kerf-reader two, kerf-runtime four, kerf-driver three,
kerf-expander one. The archaeology matters: these were not convenience
re-exports. The Cargo comments say it themselves — "types flow through
the kerf-compiler re-exports (SOP §18.5 — no direct production edge
L4 -> L6)". The old edge-minimization policy made forwarding
*structurally necessary*: refusing direct DAG edges forced types to
travel through middlemen.

**The frontier verdict, primary-source triple-read.** K81: `rustc_ast`
depends on `rustc_span` **directly** and its lib.rs re-exports only its
own modules (`pub use self::ast::*`) — zero passthrough; the whole
rustc compiler imports Span/Symbol from rustc_span itself. K82:
`oxc_ast` is the same shape — direct `oxc_span` workspace dependency,
own-module exports only. K83, the honest counter-example:
`rustc_middle` is the famous historical facade, but current master's
`hir/mod.rs` consumes rustc_hir as a **private** `use rustc_hir::*` —
the public forwarding face has been cleaned up. The direction of
travel at the frontier is away from public passthrough.

**What changed.**

- **All thirteen forwarding lines retired.** Every pipeline crate now
  exports only what it defines. The old charter comments ("consumers
  must not depend on kerf-span directly") are inverted and rewritten:
  consumers now MUST — that is the rule.
- **~40 import sites re-surgically connected** across the pipeline
  crates, the six in-crate api test files, and the root tree: mixed
  imports split (`kerf_compiler::{Opcode}` stays, `Span`/`Symbol` move
  to `kerf_span::`, `LiteralValue`/`ModuleItem` move to `kerf_core::`).
- **Five Cargo dependency faces updated** — the honest DAG emerges:
  kerf-span is now a direct production dependency of every consumer
  (compiler/expander promoted from dev-deps, vm/runtime/driver new),
  and kerf-vm takes kerf-core as a production dependency.
- **SOP §18.5 amended via the §3.3 evolution path (v15.1 → v15.2) —
  the first SOP self-amendment of the interlude series.** Five policy
  clauses: pipeline crates forward nothing; a type's unique
  reachability path is its defining crate; the root aggregation crate
  is exempted on a two-tier basis (crate-level aliases are its
  designed aggregation content, type-level forwarding stays banned);
  edge count is not a complexity metric (a forwarding chain is an edge
  in disguise); lesson source recorded.
- **TEST-4 machine-guards the zero** (three tests in
  `test_infra_guard_tests.rs`): crates/ scanned tree-wide for
  `pub use kerf_*` (= 0), the root facade checked two-tier (aliases
  yes, `::`-paths no), and a detection-power arm with seven
  must-flag / five must-spare fixtures. Development true-positive,
  disclosed: the arm's first run caught its own fixture error — the
  alias shape was listed as must-spare; the detector was right, the
  fixture was wrong (the TEST-2 precedent, third instance).

**Numbers.** 28 Rust files + 5 Cargo.tomls + SOP + dataflow graph;
tests 1165 → **1168:0:0** (+3 guards, zero pipeline-expectation
changes — semantic zero-movement proven by untouched goldens), audit
**200/200**, fmt zero diff (one long-line self-fix), clippy
`-D warnings` zero. Stage 2 entry remains explicitly prohibited (r58,
sixth reiteration). Also this round: one T35 leftover repaired — the
stage-2-plan Status line's r57 addition had silently failed to save
(a raw replace without an assertion; the lesson is recorded, all
edits are assert-backed now).

## v0.27.0 — interlude: crate-boundary review + Symbol single-pool unification

The §9.58 review opened the crate-boundary meta-domain — after the
diagnostics and test-infrastructure rounds audited the pipeline's
*products*, this round audited the *factory*: are the ten crate
charters clean, and does any cross-crate duplication hide behind
layer independence? The user's r57 instruction named the exact
suspicion: "kerf-core/ and kerf-syntax/ contain large amounts of
similar or identical content — why does this exist, it should not."

**The finding, verified.** `kerf-core/src/symbol.rs` (334 lines) and
`kerf-syntax/src/symbol.rs` (288 lines) are structural twins: after
normalizing the type names, a diff leaves **243 changed lines — every
one of them in doc comments**. The same `Interner`, the same
process-global `OnceLock<Mutex<Interner>>`, the same `intern()`, the
same identifier floor, the same hand-written Debug shape. The v0.23.0
interning round (§9.52.4) had ratified this as the deliberate "twin
discipline" — each layer owns its pool, the expander crosses the
boundary as source text. Three more twins rode along: the
`InvalidSymbol` error variant with byte-identical Display text in
*three* crates (reader, syntax, core — the "single-source dictionary"
maintained by triple copy), and ~14 twin unit-test cases.

**The frontier verdict, triple-confirmed.** K78 (direct read of
`rustc_span/src/symbol.rs`, 88KB): rustc's `Symbol` and its interner
live **in the span crate** — the lexer, AST, HIR and MIR all consume
one Symbol type and one pool; `rustc_ast` has no twin. K79 (oxc
`ARCHITECTURE.md` + `oxc_span` source): the foundation layer shares
Span/Syntax/Diagnostics across all components, and `oxc_span` cites
rustc_span as its model. K80 (rust-analyzer workspace): `crates/span`
is the foundation crate, and even hygiene (`SyntaxContext`) lives
there. Three frontier compilers, one shape: identity types sink to
the foundation layer; layers stay independent by *crate layering*,
never by duplicating types.

**What changed.** The §9.52.4 ruling is amended by informed
adjudication (three counter-arguments recorded and rebutted; the
v0.23.0 ruling's premises archived, not erased):

- **One Symbol, one pool, in kerf-span** (`crates/kerf-span/src/
  symbol.rs`, 403 lines): `Symbol` + `SymbolError` + the interner +
  the consolidated 20-case unit-test family. Both twin files are
  retired (622 lines deleted). `kerf-syntax` and `kerf-core`
  re-export `kerf_span::Symbol` — every downstream import path
  (`kerf_core::Symbol`, `kerf_compiler::Symbol`) is unchanged, zero
  new DAG edges (§18.5).
- **`StxSymbol` retires.** The §21.12 naming family is amended:
  Symbol is a cross-stage ID type (like Span/FileId/ScopeId), not a
  syntax-object type — the no-prefix family, in the foundation crate.
- **One canonical error rendering.** `SyntaxError`, `CoreError` and
  `ReadError` `InvalidSymbol` variants now *wrap* `SymbolError` with
  `From` impls and delegate their Display — the triple text copy is
  gone, and the reader's lexer now propagates the real error payload
  instead of discarding it.
- **The text bridge becomes a pool hit.** The expander's
  `sym.as_str()` lowering path is unchanged in shape, but the second
  intern now hits the same table — one pool, one identity per text,
  half the memory, and the Stage 2 lexical-addressing input (§9.52.5
  "symbol identity foundation") strengthens from a text protocol to
  index isomorphism.
- **Two new integration assertions** (`symbol_intern_tests.rs`): the
  same text constructed through the syntax face and the core face is
  the *very same* Symbol (equality, size, hash), and all three error
  faces render one byte-identical message — the single-source
  dictionary is now machine-checked, not asserted.

**Numbers.** Code face: 24 files, +369/−453 — the deleted duplication
outweighs the new foundation. Tests: 1174 → **1165:0:0** (the twin
suites merge into one family — a legitimate net reduction with zero
semantic-coverage loss), audit **200/200**, fmt zero diff, clippy
`-D warnings` zero. Registration windows: W-BOUND-SCOPE (scope/
hygiene context placement — rust-analyzer K80 precedent; opens with
Stage 2 lexical addressing) and W-BOUND-NAMING (the two same-named
`code.rs` files — expander CodeValue vs typecheck TypeCode; P3
observation). Stage 2 entry remains explicitly prohibited (r57,
fifth reiteration).

Also this round: the GitHub file repository
(`Redskaber/subscription_and_notification_channel`) became reachable
for the first time in eighteen rounds — v0.26.0 was imported and
aligned from commit `ba6e243`, and the sandbox environment reset
(toolchain reinstalled at 1.98.1, web dashboard re-synced from the
stale v0.1.0 state, worklog mirror drift repaired).

## v0.26.0 — interlude: test-infrastructure self-audit (inventory guards + audit label normalization)

The §9.57 review turned the audit lens on the test infrastructure
itself — the meta-domain the review genealogy had never surveyed
(r51 Symbol → r52 memory → r54 determinism → r55 diagnostics; the
verifier was the last unsurveyed component). Frontier anchors: the
rustc-dev-guide testing chapters (tidy enforces test-placement
discipline tree-wide; compiletest tracks stray output files;
distcheck verifies the tarball), rust-analyzer expect-test, and
cargo-mutants (K75-K77; three weak queries disclosed, one upgraded
to a primary-source direct read).

**What changed.** Three inventory invariants are now machine-guarded
(`tests/v1/stage1/plan/test_infra_guard_tests.rs`, the K75 tidy
family — mechanical, tree-wide, fail-closed):

- **TEST-1 — runner mounting guard.** Cargo discovers only top-level
  `tests/*.rs`; every deeper file runs only through a `#[path]` mount
  in `tests/runner.rs`. An unmounted file was a silent dead file —
  now both directions are asserted (every `.rs` under `tests/` is
  mounted; every mount target exists).
- **TEST-2 — corpus table/directory parity.** The per-case
  `corpus_case!` table and the 79-file corpus directory must carry
  exactly the same set (the old design tolerated a lagging table —
  the sweep covered validation but isolation degraded silently).
- **TEST-3 — audit case registration.** The gate-audit's headline
  "200/200" was a hardcoded literal over a three-form labeling
  convention (H07 shared H06's comment; sections U/V used single
  digits). The convention is now uniform — every case opens with a
  `// XNN:` comment (A-C comments added, H07 labeled, U/V widened;
  comment-only, zero behavior change) — and a guard asserts the
  per-section composition (A10 + B10 + C5 + D5 + 16×10 = 200) plus
  the headline literal. A detection-power arm feeds the counter a
  synthetic fixture with near-miss shapes (the r54 detector
  precedent).

**Tests.** +4 (three guards + one detection arm), zero pipeline
regression. Full suite **1174:0:0**, gate audit **200/200**, fmt
zero diff, clippy `-D warnings` clean. Registered windows (zero
signal, not opened): golden blessing tooling, mutation testing,
doc-count sync, distcheck automation. Stage 2 entry remains
explicitly prohibited (r54/r55, reaffirmed r56); test-tree-only
changes — no primitive, channel, VM, or grammar surface touched.

## v0.25.0 — interlude: diagnostics position single-sourcing (message/location separation + session line-index cache)

The §9.56 review surveyed the diagnostics domain end to end: the
structured `Diagnostic` type, the TD-001 line/column derivation, the
rustc-flavored renderer, the per-stage collection policy, and the
parity harnesses' error-axis comparison. The rustc-dev-guide
diagnostics chapter is the canonical anchor: a diagnostic message
"should be general and able to stand on its own" — position lives in
the `--> file:line:col` location line exclusively (K71).

**What changed.** Two findings were implemented in code:

- **DIAG-1 — position fragments leave the stage Display messages.**
  All four error families embedded positions in their `Display`
  (reader `at byte N` ×6, expander `at {span}` ×9, compiler
  `({span})` ×10, vm `({span})` ×11 — 36 sites), which double-reported
  against the renderer's location line and leaked the internal
  `file#0:15..16` byte form into user-facing output. Messages are now
  position-free; offsets and spans stay in the structured payloads
  (`offset()` / `span()`), and the location line is the single
  position render. Compiler `pc`/`slot`/`index` operands stay (they
  are semantic payloads, not source positions).
- **DIAG-4 — the session owns the line index.** `render_position`
  and `render_one` rebuilt `LineIndex::new(source)` per diagnostic
  (twice each across the width and render passes — O(source) per
  diagnostic). `Session::intern` now builds the index once per file
  (rebuilt on REPL upsert; rustc source-map / rust-analyzer line-index
  shape, K72), and the renderer fetches it through the fail-closed
  `Session::line_index`.

**A consequential fix discovered during implementation.** The parity
harnesses compare the oracle error against the rebuilt `.krf`-side
error through the shared `Display`; with positions gone from the
messages, two different payloads could render to the same text — the
drift detector would go blind. The error-axis parity key is now
`Display` + a harness-rendered position suffix (`@ byte N` /
`@ {span}`), the same shape the tree-axis dumps always carried
(`(define 0 36 x ...)`); tamper detection is proven restored by the
drift-detector and span-trap tests.

**Tests.** 29 assertion sites updated (the failing suite enumerated
them — zero guesswork), six render goldens re-baselined as a
documented intentional change (ds01/ds02/ds04/ds05/ds10 + e2e; the
ds03-via-1.1-wiring precedent), one new session-cache test. Full
suite **1170:0:0** (+1 net), gate audit **200/200**, fmt zero diff,
clippy `-D warnings` clean. Registered windows (zero signal, not
opened): per-variant error codes, within-file multi-error recovery,
suggestion engine. Stage 2 entry remains explicitly prohibited
(r54/r55); release-only render-golden and message changes, no
primitive, channel, VM, or grammar surface touched.

## v0.24.0 — interlude: compile-output determinism guard (the fixpoint gate-B prerequisite locked in tests)

The §9.55 audit classified all 61 non-comment HashMap/HashSet sites
across the ten pipeline crates: every map is keyed-lookup-only,
membership-only, or insertion-order-indexed (the `Vec` +
`HashMap`-as-index shape — a hand-rolled IndexMap, K69); no site lets
hash iteration order leak into compiler output. The numeric edge
semantics face (checked i64 arithmetic, NaN-canonicalized constant
pool keys, bit-identical NaN equality) was re-verified as already
hardened.

**What changed.** The property was implicit; now it is locked: a new
root-tree guard family double-traverses the real fixpoint subjects
(the assembled reader behind its own token table, the macro library
assembled ahead of the expander behind a forms-stream prefix — the
gate-B recipe) and the full 79-case corpus through two independent
reader -> expander -> loader -> compiler instances, asserting
structural equality of the expanded items and the bytecode. Three
detector-detects tests prove the comparison catches pool/table/code
divergence, and one semantics test documents the first-use ordering
discipline of the global table (source order, never hash order).
Four invariant comments now pin the discipline at the sites it rests
on (`intern_const`/`intern_global`, the trigger-set union, the GC
root scan, the sweep loop). Zero behavior change; tests +7.

**Why now.** Stage 2's exit criterion (2) — two self-compilations
byte-identical — rests entirely on this property, and the user's
standing review directive ("review the whole pipeline, implement the
fixes, do not converge") flagged the determinism domain as the
remaining unreviewed face after the §9.46-§9.53 lineage closed. The
round also registers the user's explicit "no stage 2 entry" ruling
(stage-2-plan.md §0 r54 note): the confirmation gate flips from
"awaiting" to "explicitly prohibited" until lifted.

## v0.23.0 — interlude: symbol interning (the user-flagged representation gap closed in code)

The identifier payload swaps from owned `String` to an interned
`NonZeroU32` index (stage0.md §9.52) — the user's four-times-flagged
review item, now implemented rather than registered. Both phase-twin
types (`kerf_core::Symbol`, `kerf_syntax::StxSymbol`) keep their public
APIs byte-identical; only the private payload changes, and each layer
owns its own global interner (leaked `&'static str` map — the
matklad-style simple interner, K54; the rustc `Symbol = interned
identity` shape, K6/K54b).

**Why now.** The three previously registered triggers (LSP window,
B-series hotspots, selfhost self-compile load) stayed zero-signal, and
that assessment stands. The window opened on the user directive itself
(rounds 42/47/50/51) plus a blueprint-implementation gap: the design
blueprint's `Identifier(Symbol) // interned string` assumed interning
all along. Stage 2 benefits directly — capture descriptors (LA-2) can
key on symbol identity instead of text comparison.

**What it buys.** Equality/hashing become index operations, cloning
becomes a bitwise copy (every `CoreExpr`/`StxDatum` clone gets
cheaper), and `Option<Symbol>` keeps a 4-byte niche layout in the
compiler and vm frames.

**What it costs (informed tradeoffs, §9.52.3).** Interned text lives
for the process (leak-by-design — the classic interner tradeoff,
CLR/Python pool pitfalls surveyed as the con-side anchors);
`as_str`/`Display` take one uncontended mutex; `Ord` now means
first-intern order, not lexicographic (whole-tree ripple audit: zero
ordering consumers — every `sort` site sorts `String`/`&str`, no
`BTreeMap<Symbol, _>` exists); language-level strings (`Value::Str`)
are NOT interned — identifier identity and string data stay two
worlds. The `Copy` trait is deliberately not derived (a whole-tree
`clone_on_copy` churn for no semantic gain; revisited with LA-2).

**Guardrails.** `Debug` is hand-written to reproduce the old derived
`Symbol { text: "x" }` shape byte-for-byte, so goldens and diagnostics
are index-independent. Tests grow by 17 (10 unit + 7 cross-crate
integration: symbol-heavy programs on both engines, shadowing, parity
contract drift detection, unbound-name diagnostic fidelity): 1162:0:0,
audit 200/200, fmt clean, clippy `-D warnings` clean. B-series all
in-band: B1 at 7.7µs (a new low — the interning dividend), B3 +11%
(evaluator display-path lock cost, recorded as measured).

Zero language-surface change: 8-primitive invariance round 25, subset
frozen faces untouched, selfhost parity byte-identical. Stage 2 entry
still pending user confirmation (SOP §14.6.3 rule 5).

## v0.22.0 — Stage 1 close: the exit round (deep-review family + seven-piece finals + nine-signal audit, GO recommended)

Stage 1 ends (stage-1-plan row 1.9; docs/stage0.md §9.50 — the
fifth and last review segment closed the lineage with zero
findings). The exit claims are re-runnable, not narrated.

**The review lineage completes.** §9.50 gives the checker domain
(R1-R8) its per-rule survey — the only pipeline domain left — and
it is the lineage's single zero-finding segment: the conservative
discipline (definite-errors-only + the assign over-approximation
guard), the double mirror (compiler resolution order + expander
sequencing), the severity split (E0008/E0011 warnings), and the
dynamic-soundness boundary (R5-R7 at top level only) all hold. The
frozen layers (span/syntax/core) close with a git-audited zero
drift since Stage 0.

**The audit grows to 200 with section V — one case per §21.5
signal.** Semantic stability (builtin families, both engines),
bootstrap verification (gate B on a composite source), coverage
(the corpus replay), the performance baseline (the live budget
face: frames share the allocation budget; zero budget fails
closed), documentation sync (render goldens), handling degrees
(the frozen cardinalities: 18 builtins, 24 opcodes), debt zero
(the assembled expander + a clean recursive program both produce
zero findings), outer-loop auditability (the section set itself),
cross-stage verification (the full pipeline dataflow), and the
recovery close. A new root test family (`stage_exit_tests.rs`,
ten cases) carries the same anchors as permanent cargo tests.

**The deep-review family lands as finals.**
`deep-review-round1.9.md`: D1-D8 all pass, the §14.8 deviation
list adjudicates eight items (every B3/B4 already written back
per-round, the B1s enter Stage 2 planning, the constitutional item
is zero-deviation), C1-C6 closes with zero cleanup actions
(fourteen consecutive clean rounds), and the committee votes
5.5/5.5. The seven-piece set completes: architecture scores +
extension costs, the four gap lists (all empty for Stage 1
obligations), hidden-problem growth ratings (no mandatory fixes),
the refactoring verdicts (five rounds, every rejected alternative
recorded), the 1.9 performance re-run (B1 at 9.4µs — the whole
stage stayed within ±2% of its entry point), and
final-assessment.md with all nine §21.5 signals checked plus the
§14.7 C1-C6 cross-stage chapters.

**GO is recommended for the Stage 1 → Stage 2 transition.** Per
SOP §14.6.3 rule 5 the final gate is user confirmation. The Stage
2 entry plan: the §21 planning round first (backend strategy +
capability maturity re-check), then the lexical-addressing +
capture-activation first knife, with the 1.8 institutional lesson
(island capabilities wire to the driver face in their own delivery
round) as a standing acceptance clause.

- Tests: 1145 passed / 0 failed / 0 ignored (Stage 1 total: 767 → 1145)
- Audit: 200/200 (A-V twenty-one sections; V = the nine-signal exit evidence)
- td register: zero open items, fourteen consecutive rounds
- 8-primitive invariant: twenty-third verification round
- B1-B5 at exit: 9.4µs / 97.45ms / 9.4ms / 0.372ms / 97.0ms (in band)

## v0.21.0 — Stage 1.8: gate-prep (full-set gate re-run + HM wiring + calibration + seven-piece skeletons)

The Stage 1 endgame-prep round (stage-1-plan row 1.8; docs/stage0.md
§9.49 — GATE-1..GATE-4).

**The HM layer joins the driver pipeline (GATE-2, the plan-1.3
"1.8 agenda").** `pipeline.typecheck()` now runs both static layers
in one batch — the conservative rules (R1-R8) and the inference
engine (E0009-E0011) — with the soft-typing severity contract kept:
definite errors block, the E0011 budget warning never does.

**Wiring it immediately exposed a 1.3-layer false positive.** The
assembled `.krf` expander (a legal 1.4k-line program, parity-
verified on both engines) was rejected with E0009: argument-shape
unification was reporting heterogeneous tag dispatch (one parameter
fed different tuple shapes at different call sites — legal dynamic
code) as a definite error. The hardening is *release-and-demand*:
a failing argument-shape constraint is rolled back and released,
never reported; the single body-sensitive binding source (an if
condition forcing a parameter metavariable to bool) keeps its
definite-error reporting through a per-define demand table —
`(define f (fn (x) (if x 1 2)))) (f 1)` still blocks, the tag
dispatchers run. FP3 hardening anchors both halves; the audit U1c
case pins the assembled expander to zero error-level findings.

**Gate re-run (GATE-1).** The audit set re-runs the whole Stage 1
family (A-T) and grows to 190: the new U section carries the HM
wiring end-to-end, the §7.3.2 fix-boundary family of the 1.7
probe rounds (the four-head record grammar, three-generation macro
chains beyond the corpus, the mangled-field tamper detector, the
assembly-order neutrality, the Macro sentinel at zero), and the
cross-sub-stage sweep (1.0-1.7 full chain on both engines).

**Calibration (GATE-3) + seven-piece skeletons (GATE-4).** The
calibration pool backfills the 1.4-1.7 verification rows and the
Stage 1 summary (tests 846→1135, twelve consecutive rounds of zero
runtime-semantic defects, TD register at zero); the institutional
lesson — *an island capability must reach the driver face in its
own delivery round* — is written into the 1.9 exit-review clauses.
The §14.6.6 seven-piece deep-verification set lands as skeletons
with pre-filled evidence and per-document 1.9 obligation tables.

**Corpus expectation co-variance (all probe-verified).** Five
negative cases re-freeze their directives for the two-layer batch
(neg-031/037 gain E0009; neg-041/044/047 move from runtime-error to
type-error E0009 — the checker now catches them first); ds02 keeps
its runtime render face through an HM-released dynamic parameter
and gains a checker-face golden (ds02b).

- Tests: 1135 passed / 0 failed / 0 ignored (baseline 1128 + net 7)
- Audit: 190/190 (A-T full re-run + U10 — the §7.3 gate-prep form)
- td register: zero open items, twelve consecutive rounds
- 8-primitive invariant: twenty-second verification round

## v0.20.0 — Stage 1.7: the .krf macro layer, third segment (macro parity + fixpoint gate B)

The third self-hosted front-end segment lands: the macro layer of the
expander, rewritten in the frozen kerf subset itself and checked
against the Rust expander oracle byte-for-byte (stage-1-plan row 1.7;
docs/stage0.md §9.48 — the BS-C 1.7 segmentation: MX-1..MX-6).

**The assembled program (MX-2).** `selfhost/v1/macro.krf` is a pure
function library — registration validation, fixed-arity matching, the
six-step instantiation order, rename-on-capture — assembled ahead of
`expander.krf` into one program by the host (the module-vs-crate
mirror: transformer.rs is a module of kerf-expander, macro.krf is a
library of the expander program).

**Rename encoding (MX-1).** The frozen subset has no string
construction, so a renamed introduced identifier rides as a structured
`("mangled" s e base counter gen)` record; the host decodes
`format!("{base}__macro_{counter}")` for the byte comparison — parity
observes the decision face, the deterministic rendering stays
host-side (the 1.5 float-as-Debug-text precedent).

**Generation threading.** Every input record carries a trailing
generation int (source records ride 0; macro products carry
use_gen + 1 — pos-032 exercises the two-generation chain). The dump
TEXT grammar is unchanged; the host rebuilder consumes the generation.

**The Macro layer collapses (MX-3).** The 1.6 three-layer split
collapses: define-syntax sources run the assembled program on both
engines; the Macro enum value survives as a zero-routing sentinel.

**Fixpoint gate B (MX-6).** Two axes cash in subset-spec §4's
reserved criterion: (a) bytecode equality — `compile(rebuild(krf
items)) == compile(oracle items)` over the macro corpus and the
assembled source applied to itself; (b) the self-application
fixpoint — the assembled program expands its own source, three-way
agreement (vm / eval / oracle).

**Corpus 72 → 79.** pos-031 (literal table), pos-032 (two
generations), pos-033 (hygiene binder collision — rename-on-capture's
first corpus exercise), neg-050/051/052/053 (pattern mismatch,
duplicate pattern variables, the ellipsis boundary, module-scoped
macro visibility).

**Numbers.** 1128:0:0 (net +30), audit 180/180 (new T section, ten
cases), B1-B5 performance within band, zero open technical debt
(twelfth consecutive round).

---

# Release Notes

## v0.19.0 — Stage 1.6: the .krf expander, second segment (expansion layer)

The second self-hosted front-end piece: the expander's *expansion
layer*, rewritten in the frozen kerf subset itself and running on
both engines, checked against the Rust expander oracle
byte-for-byte (stage-1-plan row 1.6; docs/stage0.md §9.47 — the
BS-C 1.6 segmentation: EX-1..EX-5).

- **`selfhost/v1/expander.krf`**: the full expansion layer in ~640
  lines of frozen-subset kerf — all four declaration heads (both
  define shapes with letrec pre-binding, require's string domain,
  module frame isolation, define-syntax as the fail-closed
  macro-layer marker), all eight expression forms, the `do`→flat
  `Let` desugar with the discard binding, `quote`→Pair right-fold,
  let\* progressive binding, and the module loader (the LIFO
  worklist declare pass + three-color DFS with the gray-cycle path
  slice). The §9.47.3 seven span traps are mirrored one by one:
  the quote whole-form span, the fn-sugar name-atom span, the
  binding value-node span, the `do` identity, the set! name-atom
  error span, the handler whole-clause span, and the require
  symbol-name MalformedForm.
- **One self-recursive expander** (the REC-A lineage, third
  instance): the frozen subset bans define-level mutual recursion
  (neg-046), so the expression expander is ONE function; the
  variable-arity walks (argument lists, let pairs, do steps,
  handler clauses, fn assembly) ride five synthetic node modes
  (`mapx`/`letloop`/`doloop`/`clausemap`/`fnbind`) dispatched by
  tag at the same recursion point. Synthetic modes bypass the depth
  counter, so .krf depth tracks the Rust node depth exactly (the
  512 budget stays unreachable from pure source — the reader's 256
  cap has the 2× margin).
- **Flat pre-order forms stream** (EX-1): the host reads (single
  source) and injects `(define forms (quote (...)))` — one flat
  record list where a `("list" s e n)` record's n children follow
  it. The flat shape keeps 255-deep trees inside the reader's
  nesting cap (a nested encoding would need depth+3).
- **Three-layer split** (EX-3): sources the reader rejects are
  decided by the reader layer (six corpus files); sources declaring
  a macro (`define-syntax`) ride the Macro layer — pos-024 and
  bnd-010, decided by the oracle with the .krf layer not exercised
  (`SyntaxRules` is the 1.7 window); everything else runs the .krf
  expander on both engines.
- **Corpus extension 68→72** (§9.47.4, the extension-duty table):
  pos-029 (string require + the three comparison builtins + an
  uncalled read-line), pos-030 (nested module declaration), neg-048
  (the string-name module cycle — `ModuleCycle` becomes
  corpus-reachable), neg-049 (`ModuleNotFound`). Expectations
  frozen through the probe round (all four correct on first
  validation).
- **Two-faced bootstrap fixed point**: the structural face (the
  expander's own source minus the hosting tail, expanded to the
  same 49-item tree on both engines and the oracle) and the error
  face (the bare source — oracle and both engines agree on the
  unbound `forms` at the exact same span: the hex0-layer hosting
  dependency made visible by self-application).
- **Nameability completions** (the 1.5-b kerf-reader precedent,
  third and fourth instances): kerf-compiler re-exports
  `CoreExpr`/`Binding`/`HandlerClause` (they ride ModuleItem's
  public shape); kerf-expander re-exports `CoreError` (it rides
  ExpandError::Core's public shape). Zero new Cargo edges.
- Six commands all green: **1098:0:0** (1069 baseline + 29: seven
  harness inline, eighteen integration, four corpus cases) · gate
  audit **170/170** (the new S section mounts the expander-parity
  meta-audit) · B1-B5 performance baselines unchanged.

## v0.18.0 — Stage 1.5: the .krf reader, first segment (structure layer)

The first self-hosted front-end piece: the S-expr reader's
*structure layer*, rewritten in the frozen kerf subset itself and
running on both engines, checked against the Rust reader oracle
byte-for-byte (stage-1-plan row 1.5; docs/stage0.md §9.46 — the
K18 hex0-layer lineage: the host lexer stays the single source of
token truth while the .krf layer takes over structure).

- **`selfhost/v1/reader.krf`**: an iterative explicit-stack parser
  (one token per self-recursive step; frame = depth/open-start/
  items-reversed) written with only the frozen 18 builtins + 8
  special forms. The four parser-side rejections (unclosed innermost
  `(`, stray close, empty application before outer unclosed,
  nesting 257 at limit 256) are produced as *structured values* —
  the host rebuilds the `ReadError` and renders through the oracle's
  own `Display`, so message parity holds by construction.
- **Source-injected token table** (RS-1): the host lexes (single
  source) and prepends `(define tokens (quote (...)))` ahead of the
  reader source — the only typed data channel the frozen subset
  offers (strings are opaque; the read-line input-tape route is
  ruled out and re-registered as a second-segment obligation).
  Spans ride as decimal strings; floats ride as Debug text
  (inf/NaN have no .krf literal shape).
- **The parity harness** (`kerf-driver::reader_parity`): dual-axis
  normalization (tree dumps) + error reconstruction + dual-engine
  runs (handles stay alive for heap walks), with a layer split —
  lexer-side rejections are decided by the single-source lexer
  (the six-variant family is the second-segment window).
- **Coverage**: 1069:0:0 (net +23), audit 160/160 (new Section R),
  the 68-case Stage 1.4 corpus replayed in full as reader inputs,
  the 255/256/257 nesting boundary, two drift-detector self-checks,
  and the bootstrap fixed point (the .krf reader reads its own
  source's token stream).
- Docs: stage0.md §9.46 (v9.12 — K18-K21 anchors, the subset
  expressibility audit, the B3 scope correction), plan-1.5.md,
  reader-parity.md.

## v0.17.0 — Stage 1.4: the kerf subset freeze (.krf self-hosting target surface)

Stage 1.5-1.7 will rewrite the compiler front end *in the kerf
subset itself*; this release freezes what that subset is, pins it
with an acceptance corpus, and lands the parity contract the rewrite
will be judged by (stage-1-plan row 1.4; docs/stage0.md §9.45).

- **The subset spec** (`docs/develop/v1/stage-1/subset-spec.md`): an
  honest freeze of the implemented surface — 4 declaration heads, 8
  expression special forms, 18 builtins, 6 literals, 9 core
  constructors, 4 module items — every row anchored to its code
  source, with the exclusion faces registered explicitly (macro
  trigger surface stays a 1.7 item; quote rejects symbols; I/O is
  the §8.8 minimal set with `write-line` string-only).
- **The acceptance corpus (68 cases)**:
  `tests/v1/stage1/corpus/*.krf` — directory-form data files with
  in-file `;; expect:` directives (the GCC-torture `dg-*` pattern):
  26 positive, 32 negative, 10 boundary. Every expectation was
  verified against the real pipeline before freezing (probe round:
  68/68, zero guessed expectations).
- **Empirically adjudicated semantics, now pinned by the corpus**:
  closures do **not** capture outer bindings (both engines reject
  with `unbound global` — the checker's E0001 is the correct
  definite-error catch); forward references are rejected at
  expansion (defines-so-far; the R1 "all defines" view is the
  direct-construction face); `()` is a *reader*-stage rejection;
  `write-line` takes strings only.
- **The parity contract** (`kerf-driver::parity`): the BS-C Stage
  1.4 slice — `CorpusCase`/`Expectation`/`Observed`/
  `EquivalenceReport` + `validate`/`validate_all`, the closed
  directive grammar, and the dual-engine equivalence discipline
  (value/outputs/globals three-face agreement; runtime rejections
  must fail on *both* engines). `ParityReport` grows
  `globals_repr` (additive); the 1.5 dual-reader window extends the
  same report shape — nothing pre-built.
- **Audit Section Q (10 cases)**: the detector-detects meta-audit —
  wrong expectations must drift with both sides named, stage
  attribution both ways, exact code-set comparison, the no-define
  value convention, the batch face, and the closed grammar.
- **Numbers**: 1046:0:0 (from 953, net +93), audit 150/150 (new
  Section Q), zero new dependencies, zero new crates, B1-B5
  performance baselines unchanged (the contract is off the hot
  path).

## v0.16.0 — Stage 1.3: the Hindley-Milner inference base

The checker grows a real type layer: an iterative Algorithm W with
union-find metavariables, an undo log, SCC-partitioned define
processing, an effect-row collection face, and the Layer 2 typed
annotation IR — all inside `kerf-typecheck` (zero new crates, zero
new dependencies, zero pipeline changes).

- **Iterative everywhere (the A6 lineage)**: explicit task-stack
  tree walk, worklist unification, iterative occurs check and deep
  resolve — zero deep Rust recursion, bootstrap-friendly for the
  later `.krf` rewrite on the flat-stack VM. The 512 depth budget
  per define emits one `E0011` *warning* (never an error — deep but
  legal programs must keep running) and excludes the define whole.
- **The undo log is a soundness device**: bindings made while
  inferring an `if` branch are rolled back at the branch boundary —
  a leaked binding would flag dynamically-legal programs. Condition
  bindings persist (evaluation order); `Fn` bodies are the
  parametric contract itself.
- **SCC partitioning**: defines are grouped by the syntactic call
  graph (iterative Tarjan, dependencies first). Mutual recursion
  unifies through pre-bound metavariables within an SCC; cross-SCC
  references instantiate generalized schemas — same-module
  polymorphic reuse (`(id 1)` + `(id #t)`) is decoupled per use.
- **The conservative discipline holds**: `Dyn` is the one-way
  unknown top (if-branches join, never unify); assigned names never
  generalize (value-restriction analog); the 18 builtins are typed
  ad hoc at application sites (no type classes for a closed set);
  effect rows collect `Perform`/`Handle` with definite subtraction
  and over-approximate handler merges (row polymorphism stays the
  Stage 2+ TY-C window).
- **New diagnostics**: `E0009` type mismatch, `E0010` recursive
  type (occurs check), `E0011` inference budget exceeded (warning).
- **The Layer 2 typed IR**: `TypedExpr` mirrors `CoreExpr` with a
  type and effect row on every node; `TypedDefine` carries the
  generalized schema. The IS snapshot family freezes the
  deterministic dump byte-for-byte.
- **Numbers**: 953:0:0 (from 890, net +63), audit 140/140 (new
  section P), B1-B5 baselines unchanged (the inference layer is not
  in the compile path).

## v0.15.0 — Stage 1.2: property-based testing lands (DEA-13 closure)

The fourth testing layer joins the pyramid: snapshot / golden /
bootstrap-parity / **property**. `proptest` enters as a root-layer
dev-dependency only (never in the language pipeline or the bootstrap
chain), and the first three invariant families of the §9.34.5
checklist go live as seven properties.

- **The seven properties** (tests/v1/stage1/plan/pbt_seed_tests.rs,
  mounted through tests/runner.rs): dual-engine parity on arbitrary
  well-formed programs (FP1), the runtime unhandled-effect trap on
  both engines (FP2), handle-perform reduction fused with a concrete
  arithmetic oracle (FP3), the static E0006 propertified across the
  whole effect-name space (FP4 — the 1.1 finite samples generalized),
  the reader fixed point of display (FP5 — the caliber disclosure:
  `StxDatum::Display` is the diagnostics face, not a serialization
  face), VM dispatch determinism across fresh instances (FP6), and
  integer addition against the host checked-add oracle (FP7).
- **Typed generators** (the well-formed domain): a three-channel
  expression generator (Int / Bool / Any — depth-capped, ±2^40
  oracle band), safe symbol pools (zero keyword / zero builtin
  collisions, self-tested), and a float domain restricted to the
  exact Debug-parse roundtrip band.
- **First-run honesty**: the initial PBT round failed 4 properties —
  all generator-domain or assertion-face issues (the reader rejects
  `()` and `(fn () …)` — the frozen EmptyApplication grammar fact;
  declaration-only programs halt at nil, so FP3/FP7 assert on the
  define slot instead of the program value), zero dual-engine
  divergences: the property layer found no new defects in the
  shipped implementation, which is exactly what DEA-13 closure
  should look like on a green baseline.
- **Numbers**: 890 tests green (881 baseline zero-regression + net
  9: 7 properties + 2 domain self-tests; 64 cases × 7 properties =
  448 generated programs); the audit set stays at 130/130 (PBT and
  the exhaustive-sample audit are complementary domains — the ruling
  is recorded in plan-1.2.md §4); one new dev-dependency (proptest
  1.11.0 — the ^1.9 constraint resolves to the latest 1.x), zero
  production-dependency changes; baseline co-changes: the ds08
  version golden moves to 0.15.0, Cargo.lock gains the dev-side
  tree.

## v0.14.0 — Stage 1.1: driver wiring (typecheck stage in the pipeline + diagnostic-render join + the first Warning producer wired)

The checker joins the pipeline: `read -> expand -> typecheck ->
{compile, eval}` on every face (run / check / parity / REPL).

- **Abort semantics (ruling at implementation)**: Error-level
  findings (R1-R7) abort *before execution* — a definite error means
  the program cannot behave as written, so neither engine runs it;
  Warning-level findings (R8) never block: they ride on the outcome
  (`RunOutcome` / `CheckOutcome` / `ParityReport` gained a
  `warnings` channel), the CLI prints them to the diagnostics sink,
  and exit codes stay untouched.
- **The render join** (stage-1-plan §4 fulfilled): the driver's
  stage-level `DiagnosticCode` gained a data-carrying
  `Typecheck(TypeCode)` variant whose tag *is* the E0xxx registry
  string — diagnostics render rustc-style `error[E0002]:` /
  `warning[E0008]:` with the byte-precise `--> file:line:column`
  locations. Multi-diagnostic batches gained a
  `warning: N warnings emitted` summary line (before the abort line,
  rustc order); warning-free batches render byte-identically to the
  Stage 0 form (the ds10 golden freeze holds), and warnings-only
  batches no longer claim an abort they never made.
- **REPL warning replay**: the session-replay semantics extend to
  warnings — the whole program re-runs per submission, and the
  rendered warnings delta-print under the same prefix rule as
  outputs (shown once, silent on replay, new findings are news).
  Warning submissions enter the accumulated program (legal); only
  errors roll back.
- **Externals, third consumption site**: the driver builds the
  checker's table from the two authoritative sources only
  (`STAGE0_GLOBALS` names + `Builtin::ALL` arity triples — the
  single-source discipline; same construction as the root tests and
  the audit).
- **Baseline co-changes, five disclosed sites**: known-callee arity
  mismatches now surface statically (E0002) before the runtime face
  — the runtime coverage moves to checker-opaque param-mediated
  shapes (`((fn (g) (g 1 2)) car)`); the ds03 snapshot golden updates
  to the static form; ds08 tracks the version bump (0.14.0). A
  design-level validation surfaced on the way: an earlier
  `(set! car 1)` in the REPL correctly poisons `car` for R2 (the
  assign guard spans submissions) — conservative discipline working
  as specified.
- **Numbers**: 881 tests green (846 baseline zero-regression + 35
  net: 17 positive / 18 negative — the non-blocking / abort / render
  / replay guard families in dual balance); audit set 120 -> 130
  (section N: source-reachable E0xxx end-to-end, abort-before-
  execution, warning channels on every face); seven error classes
  stay 7/7; zero new external dependencies (one internal edge,
  L4.5 -> L8).

## v0.13.0 — Stage 1.0: kerf-typecheck seed (E0xxx registry + conservative static R1-R8 + multi-error collection)

Stage 1 opens (the stage-exit GO from 0.12.0 confirmed). The first
sub-stage delivers the external-Rust type-checker path (the §21.6
circular-dependency mitigation): a conservative static checker over
expanded programs, the E0xxx diagnostic registry, and the ruling-21
multi-error collection architecture.

- **The conservative discipline** (docs/develop/v1/stage-1-plan.md §3,
  the authoritative definition): every rule R1-R8 reports only
  *definite* errors, each with a recorded soundness argument. The two
  mirrors keep resolution honest — the compiler's locals-then-globals
  order (`lookup_local` -> `intern_global`) and the expander's
  define-so-far + letrec pre-bind discipline. Position-aware
  visibility: top-level immediate positions see defines-so-far; Fn
  bodies see every define (call time is post-load).
- **R1** unbound reference — the structural-layer re-assertion behind
  the expander's first line of defense (serves directly-constructed
  programs). **R2** known-arity mismatch (IIFE / define-to-Fn /
  builtin arity, under the assign guard and lexical-shadow skip).
  **R3** non-boolean literal condition. **R4** non-callable callee
  (literal directly, or a no-reassign literal define). **R5** handler
  arity mismatch on routed top-level performs. **R6** top-level
  unhandled perform (module load has no dynamic context — the lexical
  handle is the only possible router). **R7** non-callable literal
  handler. **R8** assignment-target surprise — the first Warning
  producer (implicit global creation / builtin rebinding; legal
  semantics, surfaced per report-over-silence).
- **The effect-family soundness key**: performs inside Fn bodies are
  never lexically routed (dynamic handlers may exist at call time) —
  R5-R7 apply to top-level immediate performs only; the walk mirrors
  the Handle compilation order (handler values evaluate before their
  own clauses install).
- **The E0xxx registry** (TypeCode E0001-E0008 + two-level Severity +
  TypeDiagnostic with byte-precise spans) activates the variant-level
  code scheme registered in Stage 0; messages stay single-source with
  the RuntimeError family (R2 mirrors ArityMismatch wording).
- **The Externals face** keeps the builtin table single-source:
  callers construct it from `STAGE0_GLOBALS` + `Builtin::ALL` (the
  root tests, the audit example, and the 1.1 driver wiring are the
  three consumption sites).
- **Layer disclosure**: R2-R7 statically catch what is runtime-only
  today (ArityMismatch / TypeMismatch / UnhandledEffect move to
  compile time) — the checker is a validator, never an executor
  (stage0.md §9.24 TY-A).
- **Housekeeping**: TD-006 cleared (stage0.md header version tag
  synced v8.8 -> v9.9, four-place consistency, user-instruction
  window) — the tech-debt register is at zero open items. PBT
  dependency review concluded DEFER-WITH-TRIGGER (proptest enters at
  1.2 with its first real consumers). Zero new external dependencies
  (two internal edges: kerf-span + kerf-core).
- Tests: 767 -> **846** (net +79: 51 inline + 7 api + 21 root
  integration over the real read->expand->typecheck pipeline); audit
  set 110 -> **120** (section M); seven error classes 7/7 maintained.

## v0.12.0 — Stage 0.11 final round: snapshot suite + performance baseline + stage-exit review

Stage 0 closes. The final L3 round delivers the last two §22.3
milestone items (L6 ≥50 snapshot tests, L8 performance baseline),
runs the full deep-review family, and checks every stage-exit
signal — the stage-exit review concludes GO (pending user
confirmation per §14.6.3 rule 5).

- **The snapshot suite** (`tests/v0/stage0/plan/snapshot_seed_tests.rs`,
  57 cases ≥ 50): one fixed input frozen into one exact output string
  per case, across every pipeline layer — reader skeletons (RS01-10),
  expander trees covering each of the nine primitives in its direct
  form (ES01-10), per-instruction bytecode listings (CS01-10, the
  `op a b` machine form), VM/eval terminal state including the
  compile-ordered globals table and opaque display forms
  (VS01-10 + VE01-02), driver rendering goldens for six negative
  paths plus the check/parity/version/output faces (DS01-10), and
  REPL transcripts with rollback and continuation (TS01-04 + VD01).
  Goldens were recorded from the verified 0.10-r3 baseline via a
  temporary probe, eye-checked line by line, and frozen inline;
  they change only with an explicit behavior change logged in the
  worklog.
- **The performance baseline** (`examples/bench/stage0_baseline.rs`
  re-runnable via `cargo run --release --example stage0_baseline` +
  `docs/develop/v0/stage-0/performance-baseline.md`): B1 compile-fib
  9.3µs median, B2 vm-run-fib(25) 96.7ms (≈2.4µs/call), B3
  eval-run-fib(20) 9.4ms, B4 gc-pressure churn 0.36ms with 1 cycle
  and 1023 swept cells per iteration on the collect-then-retry path,
  B5 driver end-to-end 97.6ms. Regression bar: median worsening
  >25%, or any change in the B4 behavior counters. std-only tooling
  (zero new dependencies).
- **The deep-review family** (§14.5/§14.6/§14.8/§14.9):
  `deep-review-round0.11.md` (D1-D8, committee vote 5.5/5.5, the
  §14.8 deviation ledger B1×2 / B2×3 / B3×3) plus the seven
  inter-stage documents — dataflow coverage (enum exhaustiveness
  with zero unwraps and 33 justified expects), architecture review
  (nine stages all green), design-impl-test three-way coverage
  (zero gaps), hidden-problems assessment (zero P0/P1, zero
  mandatory-fix items), refactoring optimality (7/7 + 8/8),
  performance baseline, and `final-assessment.md` (§22.3 twelve
  items all checked, §21.5 nine switch signals all checked, C1-C6
  cross-stage audit — GO).
- **Code grooming (§14.9)**: two historical-tense file-header notes
  corrected in place (the seven-class coverage note in kerf-vm, the
  diagnostics extension ownership note in kerf-driver); zero TODO /
  FIXME / unimplemented / todo markers, zero glob re-exports.
- **Numbers**: 710 → 767 tests (+57 snapshots; 50:7 positive:negative
  — reverse deviation declared, the determinism-contract layer is
  structurally positive, error-detection semantics stay with the
  existing 7/7 classes), audit set 110/110 re-run green, six
  commands green, R8 encoding face clean on all new files.

## v0.11.1 — Stage 0.10-r2 Capability-model reservation generalization

The capability reservation becomes a SPACE, not a point (user
explicit instruction — adjudication 20). What the reservation
reserves is no longer the concrete io model: it reserves the ability
to register and extend abstract capability models themselves.

- **The capability space** (`kerf-core/src/reserved/capability/`):
  the family contract (`CapabilityModelFamily` — identity card +
  closed error face, no operation signatures: the no-prediction
  discipline), the token calculus (`TokenCalculus` — the sealed-token
  discipline and its registry vocabulary term), the registration &
  extension mechanism (`CapabilityModelRegistry` — register / lookup
  / governing_model / governed_authorities, fail-closed on
  InvalidDescriptor / DuplicateModel / AuthorityConflict, rejected
  registrations mutate nothing), and the io sub-model re-hung as the
  first concrete model (`IoModel` — Error pinned verbatim to the
  frozen IOError; identity card "io" / ["io.read", "io.write"] /
  "CapabilityIO"). Space relations are constraint combinations, not
  inheritance (stage0.md §9.10.2); the registry's unique-subordination
  rejection is axioms A3/A4 made machine-checked (§9.13.2).
- **Freeze continuity (adjudication 17 discipline)**: the 0.10-r1
  module path `reserved::capability_io` survives as a re-export of
  `capability::io` — TypeId identity proven in tests; all four r1
  consumer faces (api tests, root integration tests, the audit set,
  the docs) compile with zero changes.
- **Extension proven at four positions**: a locally-defined model
  (the canonical clock resource — the object-capability lineage's
  fs/net/clock set, knowledge-search verified) registers into the
  same closed world as io from inside the crate, the api position,
  the workspace root, and the audit example — zero framework changes
  each time (the open-closed principle at the organizational layer).
- **Numbers**: 672 → 710 tests (+38: unit 27 / api 6 / root 5;
  25:13 positive:negative — reverse deviation declared, the
  fail-closed family contributes 11 negative cases), audit set
  100 → 110 (section L), six commands green, R8 encoding face clean.

## v0.11.0 — Stage 0.10 Reserved-interface freeze

The Stage 0 interface-reservation milestone: the four reserved
contract families of docs/stage0.md §22.3 are frozen — "interface
defined, implementation may be empty". The milestone checklist's four
interface items (Effect Handlers / multistage programming /
capability-model I/O / compilation cache) are all checked.

- **One freeze anchor, four families (adjudication 17)**: everything
  lives in `kerf-core/src/reserved/` — the L4 semantic-authority
  crate, reachable by every downstream crate and the workspace root.
  The face is *fully self-contained*: zero inbound edges beyond
  `std` (the language value is an associated type, not the VM value —
  L4 never depends on L6; the cache payload is opaque bytes, never a
  typed compiler product). "Depend on abstract constraints, not
  concrete implementations" (SOP §21.12-10(2)) lands in its strongest
  cold-start form, with the six-domain affiliation declared as module
  documentation (the kerf-space marker family stays a Stage 1+
  registration; re-anchoring onto it is additive).
- **Compilable translation of the blueprint sketches (adjudication
  18)**: the §9.1.1-§9.1.4 pseudo-code shapes become real Rust —
  companion traits (`EffectOp`, `CodeCarrier`) carry the
  `Self::Effect::Result` / `Self::Code::Inner` paths verbatim in
  meaning; `impl Expr` becomes an explicit generic; the §9.3.1 vs
  §9.1.1 vocabulary drift resolves in favor of the §9.1.1 block with
  mapping notes (the kernel-level `HandlerClause` stays the primitive
  arm; the reserved `Handler` associated type is the system face).
  Two naming disclosures: the reserved `MultiStage::quote` is the
  staged-code constructor (Stage 2), distinct from the 0.9 datum
  literal; the reserved `Code` is not the expander's `CodeValue`.
- **`effects` (P3)**: `EffectSystem` with `Effect: EffectOp` /
  `Handler` / `Continuation` / `Value` associated types and the
  `perform` / `handle` signatures frozen. Primitive semantics stay in
  the kernel (`CoreExpr::Perform` / `Handle`); Stage 2 owns the
  language-level system.
- **`multistage` (P3)**: `MultiStage` with `quote` / `splice` / `run`
  over a `CodeCarrier` — the Stage 2 staged-programming face.
- **`capability_io` (P3)**: sealed zero-sized tokens
  (`ReadCapability` / `WriteCapability`, hand-written bare-name
  `Debug`), the closed `IoErrorKind` set (Eof / Denied / Interrupted
  / Other), an R8-shaped `IOError`, and the `CapabilityIO` trait.
  Token construction is closed outside the defining crate — no
  public constructor exists at Stage 0 (minting/delegation is the
  Stage 1 additive window; default-deny is the Stage 0 discipline).
- **`cache` (P2 — signatures + executable behavior spec)**:
  `CacheKey` (a 256-bit content digest; the algorithm is a Stage 1
  implementation detail), `CachedResult` (opaque payload bytes —
  adjudication 19: the known follow-on needs of cross-session
  persistence and distributed caches are serialization-shaped, so the
  frozen face never pins a product type), `CompilationCache` with the
  three blueprint methods, and
  `check_compilation_cache_contract` — the behavior spec made
  runnable. Six contracts (store-then-get hit + value equality /
  never-stored miss / post-invalidate miss / no-op invalidate /
  latest-wins / cross-key isolation) assert against any
  implementation; Stage 1 caches reuse the kit directly as their
  contract tests. The kit's detection power is itself tested: five
  deliberately broken implementations (never-hit / no-invalidate /
  no-overwrite / wrong-key / payload-corrupt) are all caught.
- **Signature-stability snapshots**: canonical conforming
  implementors ("witnesses") live at four consumption layers (inline
  tests / crate api tests / workspace-root integration / the audit
  example) — any drift in the frozen shape breaks a witness
  compilation, which the six-command acceptance turns into a hard
  gate.
- **Counts**: 672:0:0 workspace tests (624 baseline zero-regression,
  net +48 — the roadmap agenda met verbatim; round 32:16 = 1:0.5
  reverse-skew declared: a reservation round's acceptance face is
  type existence and signature snapshots, structurally positive;
  negative-testable faces are exhausted — kit detection ×5, IOError
  four-kind paths, R8 shapes at two layers, token discipline). Audit
  set 90 → **100** (section K — reserved-face contracts; §7.1.1
  seven classes stay 7/7). Zero implementation-side runtime-semantics
  defects (all round fixes were compile-level or shape-level).

## v0.10.0 — Stage 0.9 Macro system seed

The Stage 0 macro milestone: the basic hygienic macro system
(`define-syntax` + `syntax-rules`), the structured `CodeValue`, the
module loading layer, and the `quote` datum literal. The SOP §7.1.1
error-class matrix reaches **7/7** — the module-cycle class lights up
end-to-end, at both the sub-stage and the gate threshold.

- **Hygienic macros, two complementary mechanisms (adjudication 14)**:
  scope coloring with the *binder-scopes subset* judgment (the 0.4
  membership rule generalized to Racket's "Binding as Sets of
  Scopes" — non-macro code is structurally unchanged, 551-test
  baseline zero-regression) decides expansion-time binding;
  *rename-on-capture* (the §9.38(b) second algorithm) carries the
  decision into the name-based back half (CoreExpr/bytecode/VM
  resolve `Var` by name — an introduced binder colliding with a
  spliced argument name is renamed to `name__macro_N` together with
  its introduced references). Observable proof: without hygiene the
  capture test yields 200, with it 101.
- **`define-syntax` / `syntax-rules`** (§8.10): fixed-arity patterns
  (the ellipsis `...` is a registered Stage 0 boundary — rejected at
  registration, fail-closed), literals matching by symbol text,
  `_` wildcards, pattern variables splicing use-site arguments
  *verbatim* (span/scopes/phase/name all keep their use-site
  identity), introduced nodes carrying generation+1 (the dea12b
  tracing contract — macros expanding into macros increment per hop).
  Macros are lexically scoped like defines (a nested module's macros
  vanish with their frame); a head naming nothing reports the unified
  unbound-identifier judgment (adjudication 16 — the Racket rule).
- **Module loading layer (§8.9 Stage 0 slice)**: `load_program`
  collects declared (nested) modules into the flat namespace,
  walks every `require` edge, and rejects cycles with a three-color
  DFS reporting the full path (`module cycle detected: a -> b -> a`)
  — **§7.1.1 class 7 lit, completing 7/7 at both thresholds** —
  plus not-found and duplicate declarations. The deliverable is graph
  validation + the dependency-first instantiation order (`LoadPlan`);
  visibility merging is the Stage 1 module system. The driver's
  `parse` runs it fail-fast; module diagnostics render with
  line:column locations.
- **`CodeValue`** (§6.3.3 Stage 0 projection): the structured
  macro-phase code value — `from_syntax`/`to_syntax`/`substitute`
  (the pattern-variable splice face)/`alpha_rename` (the
  rename-on-capture remedy face, public)/`symbols` (the honest
  Stage 0 census — the semantic `free_variables` is the Stage 2+
  slot)/`to_source` (the diagnostics observability face).
- **`quote`** (plan-0.7 decision 13 redeemed): atoms and proper
  lists fold into `LiteralValue::Pair` chains terminated by `Nil`
  (the 0.1 consumption face — `ConstKey::Pair` gets its first
  production consumer); symbols fail closed (`QuoteUnsupportedDatum`
  — no Stage 0 value carrier; the Stage 1 evolution slot).
- **`ModuleItem::DefineSyntax`**: the fourth declaration variant —
  a faithful declaration record with zero code (the `Require`
  precedent applied to the macro phase; compiler and evaluator both
  skip it).
- Adjudications 14/15/16 and 13 decisions recorded in plan-0.9.md §4
  (dual-mechanism hygiene; the `nil` empty-literals spelling — the
  reader rejects `()`, so `nil` is the language's empty-list
  spelling everywhere; the unified unbound judgment). Tests: net +73
  (34:39 — deviation declared: the four-stage macro E2E is the plan
  row's acceptance body), cumulative 624 green, audit set 80 → 90
  (section J), all seven error classes lit.

## v0.9.0 — Stage 0.8 Driver seed

The compiler entry point (Layer 8): pipeline orchestration over both
execution engines, the diagnostics rendering closure (TD-001 paid),
session/file interning, and the `kerf` CLI/REPL. Every crate of the
0.0 charter is now implemented — 9/9 (TD-003 cleared to zero).

- **Pipeline orchestration**: `kerf_driver::run_source` drives
  `read -> expand -> {compile -> VM, eval}`; `Engine::Vm` / `Engine::Eval`
  select the engine; `ParsedProgram` is the stable fork point (the
  same expanded program feeds both, exactly as the 0.7 cross-check
  established). `check_source` compiles + verifies without executing.
- **Parity as data**: `run_parity` runs both engines over the same
  input and compares three faces — final value repr, output
  sequence, and the define-name global table (`parity_repr` with
  both heaps alive — a divergence is *reported*, never a panic; the
  `--parity` CLI flag surfaces it as `parity: PASS/FAIL`).
- **Diagnostics rendering closure (TD-001)**: `LineIndex` derives
  1-based line + **character** column from byte offsets at render
  time (never stored — single source of truth); the renderer emits
  rustc-flavored `error[kerf-read]: msg`, ` --> file:line:col`,
  source excerpts with caret underlines (span-length, line-clamped),
  multi-diagnostic separation and a summary line. `Diagnostic` is
  the §8.7 slice: `Severity`/`DiagnosticCode`/`primary_span:
  Option<Span>` — position-less errors render without a fabricated
  location (no DUMMY spans, ever).
- **Session/file interning**: `Session` maps names to sequential
  `FileId`s with upsert semantics (the REPL re-reads one growing
  file); diagnostics render against the session's sources — the
  single source of truth.
- **REPL (session-replay semantics)**: both engines are per-program
  by design, so the REPL accumulates source and re-runs the whole
  program per submission; expressions wrap as `(define $repl:N expr)`
  (the r110 "top-level expression channel = define calling form");
  failed submissions roll back (the session survives any error); the
  input tape replays deterministically (a `read-line` past the tape
  ends with `Eof` — interactive stdin is the `run` mode's pipe).
- **CLI**: `kerf run <file> [--engine vm|eval] [--parity]`,
  `kerf check <file>`, `kerf repl`, `--help`, `--version`; exit codes
  0/1/2 (success / program-or-environment / usage); piped stdin feeds
  a run's `read-line` calls; hand-rolled parsing, zero dependencies.
- **Consumer-face extensions** (all additive): `ReadError::offset()`,
  `CompileError::span()`, `kerf_compiler::ModuleItem` re-export
  (ExpandError::span() existed since 0.4 — its doc comment named this
  sub-stage). New DAG edges L1->L8 and L7->L8 (ruling 11, plan-0.8).
- **Audit set**: 70 -> 80 (Section I: the five source-reachable
  error classes rendered end-to-end through the driver, multi-file
  multi-diagnostic collection, REPL rollback, check rejection,
  parity divergence-as-data, CJK character columns, position-less
  rendering). Error classes 6/7 held (module circular dependency
  stays DEFERRED to 0.9).
- **Fixed in-round**: TapeIo write recording (the VmIo face is the
  engine's single output recording point — a no-op face silently ate
  all REPL output) and stdin pre-read scoping (only `run` consumes
  piped stdin; the REPL reads its own submissions).

## v0.8.0 — Stage 0.7 Runtime seed

The runtime layer (Layer 7): the docs/stage0.md §19.4 mark-sweep
collector and the `eval` meta-circular evaluator — the dual-execution-
path cross-check goes live (the same expanded program runs through
`compile → VM` AND through `eval`; ≥15 programs agree structurally,
and the STAGE0_GLOBALS tables are officially asserted three ways).

- **GC (§19.4)**: mark bits and a free list live on the kerf-vm `Heap`
  (the heap-method skeleton verbatim — `test_and_set_mark`,
  `clear_marks`, `free`, slot iteration); the three-phase orchestration
  (explicit-work-stack mark — a 10^5-deep chain marks without host
  recursion; linear sweep; symmetric reset) lives in
  `kerf_runtime::gc` (Layer 7). `Roots` carries the four §19.4 root
  classes plus the handler-table extension (installed handler values
  are frame-adjacent state — missing them dangles handlers).
- **collect-then-retry** (the point error.rs announced at 0.6): the
  budget safety point now checks the LIVE footprint (frames + live
  cells); on exhaustion an injected collector runs one cycle and the
  charge retries. Without a collector the 0.6 fail-closed behavior
  stands; `Vm::with_collector` / `with_budget_and_collector` inject;
  `Vm::register_foreign_ref` protects host-held values (§19.4 root
  class four); `Vm::snapshot_roots` snapshots every class.
- **eval (the meta-circular evaluator)**: the nine semantic primitives
  interpreted directly over CoreExpr, mirroring the compiler/VM
  decision-for-decision — name resolution (tail-first scan,
  `lookup_local` verbatim; shadowing = new slots), evaluation order
  (§19.3: args left-to-right, then the callee), assign's Dup
  semantics, Require as a no-op, Module flattening, Handle's
  install-run-pop, Perform's nearest-handler rule. Closures are the
  "basic closure" P0 scope (free names resolve globally; the captured
  env is a dormant value snapshot — the 0.6 duality; lexical capture
  is a Stage 1 activation on BOTH engines). `EVAL_DEPTH_LIMIT`
  guards the Rust stack (the evaluator recurses in host frames while
  the VM stacks heap frames — a registered asymmetric boundary).
- **Builtin single source**: the 18 STAGE0_GLOBALS operation semantics
  extracted into shared kerf-vm functions (`arith`, `compare`, `car`,
  `cdr`, `cons`, `not`, `read_line`, `write_line`) — the VM and the
  evaluator call the SAME bodies (zero drift by construction, stronger
  than parity tests). The name/arity tables are asserted three ways
  (expander ↔ registry ↔ evaluator seeding).
- **parity**: `parity_repr` renders values structurally (pairs as
  dotted notation recursing both arms; closures and builtins as
  opaque forms — addresses never participate); `assert_parity`
  compares engines. Error parity is exact too: the same failing
  source produces the same variant AND the same rendered message on
  both engines.
- **Fixed (found this round)**: the evaluator's `invoke` swapped-out
  environment locals were outside the GC roots — a recursive call's
  in-flight caller values could dangle after a cycle; now
  root-protected through the evaluator's temp stack (§19.4
  explicit-roots class of a Rust evaluator), with program isolation
  (no lexical residue across `eval_program` calls) as the
  same-family backfill.
- `RuntimeError` grows to 11 variants (`EvalDepthExceeded`); the
  seven-class matrix holds at 6/7 (module cycles remain 0.9's). The
  audit set grows 60 → 70 (Section H: evaluator negatives + the GC
  retention guard + the parity-detector self-check). 427 tests green
  (71 new, 19:52 positive:negative — deviation disclosed in
  plan-0.7.md §3: the GC family counts entirely as defense-negative
  and the parity battery IS the acceptance criterion).

## v0.7.0 — Stage 0.6 VM seed

The bytecode virtual machine (Layer 6, a PERMANENT Rust base — rewriting
it in kerf is constitutionally excluded): the docs/stage0.md §19.5
switch-dispatch iterative main loop with heap-allocated call frames
(the TD-023 anchor — kerf-level recursion consumes the frame vector,
never the Rust stack). Source → value runs end to end for the first
time: fib(25) = 75025 executes on the full chain (reader → expander →
compiler → verify → VM).

- `Vm::new(bytecode)` runs the load-time verify hook (plan-0.5 ruling
  4, second line of defense) and seeds every STAGE0_GLOBALS name as a
  builtin value (18-name registry, `Builtin::ALL`); plain globals stay
  unbound until their `store-global` runs (`UnboundGlobal` on early
  loads — the dynamic-order face verify cannot decide statically).
- 24-op full execution: per-frame operand stacks, `pc` monotonicity
  with the closed jump/call/ret exception set, and the evaluation-order
  contract consumed exactly as the 0.5 compiler emits it (args
  left-to-right, callee on top — plan-0.6 ruling 5 reconciles the
  §19.5 skeleton drawing against the compiler's actual emission).
- `RuntimeError` (10 variants, every one carrying the source `Span`
  resolved through the debug_info table — the §12.1 consumption row):
  arity mismatches on both call faces and type mismatches across four
  contexts light SOP §7.1.1 classes 4 and 5 (6/7 lit); plus
  `UnhandledEffect`, `DivByZero`, `ArithmeticOverflow` (checked i64 —
  no wrapping), `BudgetExceeded`, `Eof`, `RetFromEntry`, and
  `StackUnderflow` (handler-stack face — §19.5 trap 2: explicit depth
  checks on every stack access, defense in depth over verify).
- Effects at 0.6 (plan-0.6 ruling 6): `perform` finds the nearest
  installed handler and invokes it as a function — the handler's
  return value IS the perform's value; real continuations stay
  reserved in the frozen ext1 frame slot (Stage 1+).
- The §19.4 allocation budget is the Stage 0 safety point: frames +
  heap cells share one `u32` budget (`DEFAULT_BUDGET` = 8 MiB), which
  bounds every non-terminating program (kerf has no loop primitive —
  all unbounded growth routes through calls and allocations). The 0.7
  collector hooks `gc_cycle` at the same point.
- Pluggable I/O (`VmIo`): `read-line` / `write-line` builtins over a
  deterministic `BufferIo` default (strict-string writes; the 0.8
  driver wires real streams).
- Fixed in passing (found by this round's nested-handle tests, §20.6
  full-class sweep): the 0.5 compiler's `end_closure` restored `cur`
  by decrementing — every program with a second, sibling, or nested
  closure past the first emitted into the wrong proto. Now restored
  through a saved-caller stack (`cur_stack`), with a two-case
  regression pair pinning sibling and nested closure shapes.

Verification (cold build, SOP §3.2): 0 error / 0 warning; fmt zero
diff; clippy `-D warnings` clean; **356 passed / 0 failed** (300
baseline + 56 new: 54 VM tests at 12:42 plus the 2-case compiler
regression pair; round ratio 14:42 = 1:3, cumulative 89:267 = 1:3);
`cargo run --release --example stage0_gate_audit_r1` — **AUDIT PASS
60/60** (A10 + B10 + C5 + D5 + E10 + F10 + G10).

## v0.6.0 — Stage 0.5 compiler seed

The bytecode compiler (Layer 5): CoreExpr -> Bytecode, implementing
the direct-style translation of docs/stage0.md §19.3 with jump
backpatching, a deduplicated constant pool, an interned global symbol
table, and the per-instruction debug_info table (§19.3 invariant 3 —
no bare instructions; §12.1: the VM resolves runtime errors back to
source through `Bytecode::span_of`).

- `compile_program(items) -> Bytecode` and `compile(expr) -> Bytecode`
  — the two public entries (program form ends in a depth-0 `halt`,
  single-expression form in a depth-1 `halt`).
- 24-op set: the §8.12 groups (stack / function / control flow / data
  construction / variable access / arithmetic / termination) plus
  `push-handler` / `pop-handler` / `perform` — the frozen
  Perform/Handle primitives (TD-005) carried directly. Every operand
  slot's meaning is declared on the opcode (`Opcode::operand_help` —
  "operands fully resolved").
- Eval-order contract (§19.5): args left to right, callee on top;
  `call n` pops n + 1 and pushes the result. Tail-position `if`
  compiles branches straight into the proto terminator with no merge
  jump (§19.3 trap 1) — Stage 1+ TCO only rewrites the compiler, never
  the VM. `handle` bodies compile non-tail (handlers pop before
  return; tail pass-through is registered Stage 2 effect-elimination
  theory).
- Defense in depth (plan-0.5.md ruling 4): compile-time bookkeeping
  (depth tracking, patch assertions, placeholder drain — all
  structured `CompileError`s) plus a public `Bytecode::verify`:
  operand bounds, debug-info parallelism, terminal shape, `halt`
  entry-only, and a DAG basic-block stack-depth propagation that
  catches underflow and imbalance in hand-built or corrupted
  products. The 0.6 VM is expected to call verify before loading.
- `CompileError` — 13 variants, R8 message shapes, `std::error::Error`
  (no source chain: inputs are pre-validated by the front end).
  `COMPILE_DEPTH_LIMIT = 1024` mirrors the expander budget with 2x
  headroom (reader 256 < expander 512 < compiler 1024).
- Constant pool dedup by canonical key: all NaNs fold to one slot
  (Eq reflexivity); +0.0/-0.0 stay distinct (bit-pattern keys — dedup
  is an optimization, not a semantic merge).
- Span discipline: every debug_info entry is copied from a CoreExpr
  node; the only synthesized span is the cold-start anchor for the
  `halt` of an empty program (single-generation ROOT — the TD-002
  no-cross-generation-join guarantee extends to the compiler side).
- kerf-core now re-exports the span coordinate types
  (`FileId`/`ByteOffset`/`ExpansionId`) for downstream span
  construction — no new DAG edge (plan-0.5.md §4 decision 14).
- Workspace: 300 tests green (48 new, positive:negative 12:36 = 1:3);
  §7.3.1 audit set 40 -> 50 (Section F: compile depth cap + verify
  rejection family over hand-built products). TD-003 resolves one
  more scaffold (compiler implemented; vm/runtime/driver remain).

## v0.5.0 — Stage 0.4 expander seed

The macro expander (Layer 3): syntax objects -> the frozen CoreExpr
kernel, implementing the expansion-loop skeleton of docs/stage0.md
§19.2. The 0.4 slice is the core-form skeleton — transformer
execution and the def-site / use-site hygiene union are the 0.9 macro
system (§8.10).

- `expand_program(forms) -> Vec<ModuleItem>` and
  `expand(ctx, stx) -> CoreExpr` — the two public entries. The module
  top level accepts declarations only (`define` / `require` /
  `module`); bare top-level expressions fail closed (the top-level
  expression channel is the `define` calling form — r102 corpus
  anchor; the driver owns the main composition at 0.8).
- All nine expression forms: `fn` / `if` / `let` (single, multi and
  empty binding specs, let* progressive visibility) / `do` (Begin ->
  Let chain desugaring with `_` discards, §6.12.6) / `set!` (target
  must resolve — Scheme semantics) / `perform` / `handle` /
  application / atoms, with `nil` as the reserved literal keyword and
  `(define (f x) body)` sugar mapping near-identically to
  `Define{f, Fn{...}}` (§7.3.5). Defines pre-bind their name
  (letrec-shaped top-level rule — recursive functions resolve).
- Hygiene skeleton (§19.2 invariant 2): every binding construct
  allocates a fresh scope, colors its subtree on descent
  (`with_scope_added` in production use — the 0.2 contract), and
  resolution is scope-set keyed: a name bound at a scope the
  identifier does not carry stays unbound. Nested modules are
  scope-isolated (§8.9 direction).
- Phase closure (§8.9 rule 1, 0.4 slice): every touched node must be
  runtime-phase — macro-phase syntax fails closed with
  `PhaseViolation`.
- `EXPANSION_LIMIT = 512`: the expansion work budget — a structured
  `ExpansionDepthExceeded` error, never a stack overflow (§19.2
  invariant 1); independent of the reader's 256 source-tree cap, it
  bounds synthesized and (at 0.9) macro-produced trees.
- `ExpandError` — seven variants, each carrying the byte-precise
  span; `std::error::Error::source` chains into `CoreError` (the
  core constructor floor is re-asserted at expansion time).
- `STAGE0_GLOBALS` — the 18-name Stage 0 global function table
  (arithmetic/comparison, pair/predicates, minimal I/O — §8.8
  traditional globals); kerf-runtime asserts parity when seeding the
  global environment at 0.7.
- SOP §7.1.1 error classes 2 (unbound identifier) and 7 (expansion
  depth exceeded) are now lit — 4/7 cumulative. The §7.3.1 audit set
  grows monotonically 30 -> 40 (new section E: ten expander
  negatives). Workspace: 252 tests green (48 new, 12:36 = 1:3).
- TD-002 adjudicated and resolved: the 0.4 expander copies source
  spans only (zero span construction — desugared nodes reuse the
  source spans of the same generation), so cross-generation joins
  structurally cannot occur; `JoinExpansionMismatch` stays a designed
  rejection, and the 0.9 macro system registers span-set
  representation (def-site ∪ use-site) as its design agenda
  (plan-0.4.md §4 ruling 3).

## v0.4.0 — Stage 0.3 reader seed

The surface-syntax reader (Layer 2): the first source-level pipeline
entry, implementing the typed-token-stream contract of docs/stage0.md
§8.1 and the `read : string → Result<SyntaxObject, ReadError>`
capability signature (§278), pluralized to whole programs.

- `StxToken`/`StxTokenKind` — the §8.1 TokenKind S-expression subset
  (Delimiter / Identifier / IntLiteral / FloatLiteral / BoolLiteral /
  StringLiteral / Eof); modern-skin kinds arrive additively at Stage 2.
  The tokenize guarantees all hold: lossless coverage (inter-token gaps
  are exactly whitespace and `;` comments — test-anchored), precise
  byte spans (multi-byte UTF-8 exact), structured lexical errors.
- `lex(file_id, source)` and `read_program(file_id, source)` — the two
  public entries; a token slice without Eof is tolerated (end of slice
  behaves as end of input).
- Numbers follow Rust `i64`/`f64` parse semantics (`.5`, `1.`, `1e5`
  are floats); number-shaped atoms that parse as neither are rejected
  fail-closed (`MalformedNumber`) — no Racket-style symbol fallback.
  Booleans are exactly `#t`/`#f` (`#true` fails closed). Strings take
  escapes `\" \\ \n \t \r` with raw newlines legal. `;` line
  comments; the BOM is skipped like whitespace.
- `()` is rejected at read time as `EmptyApplication` (SOP §7.1.1
  error class 3, lit at the reader as defense in depth — the quoted
  empty list is covered by the `nil` literal; honest boundary in
  plan-0.3.md §4.3). Bracket and reader-macro characters
  (`[ ] { } ' \` ,`) fail closed — no reader macros in Stage 0; quote
  is spelled `(quote x)`.
- The list-nesting cap is a public constant (`NESTING_LIMIT = 256`),
  boundary-tested both ways (256 legal, 257 rejected); the cap also
  bounds the descent's native recursion depth. Unclosed lists report
  the innermost open `(` — deterministic and closest to where input
  ran out.
- `ReadError` — ten variants, all byte-precise, R8 message shapes; the
  `InvalidSymbol` rendering is byte-identical across the reader,
  syntax and core layers (single-source dictionary, cross-crate
  asserted).
- SOP §7.3.1 audit set revision 1: `examples/audit/
  stage0_gate_audit_r1.rs` — 30 cases (10 single-statement + 10
  multi-statement + 5 complex + 5 error-recovery), re-runnable via
  `cargo run --release --example stage0_gate_audit_r1`; error-class
  coverage 2/7 (syntax error + empty application lit; 5 structurally
  deferred to 0.4/0.6/0.9). Grows monotonically until 7/7 at the 0.11
  stage gate.
- The `TokenLike` test stand-in is retired exactly as its charter
  promised: seed tests now reduce spans over real reader tokens.
- 60 new tests (15 positive + 45 negative = 1:3; 43 unit + 8 crate
  API + 9 cross-crate); workspace total 204, cold-build green under
  the six-command gate. TD-003 shrinks to 5 scaffold crates.

## v0.3.0 — Stage 0.2 SyntaxObject seed

The surface-syntax data layer (Layer 1), implementing the syntax-object
four-tuple of docs/stage0.md §3.3.

- `SyntaxObject` = datum + span + scopes + phase. The span is a
  mandatory field (never `Option`, never a dummy — the TD-004 structural
  discipline extended to the syntax layer); list members are full syntax
  objects, not bare datums ("extended S-expression", §7.3.6 — per-node
  wrappers are what per-identifier hygiene needs, §19.2 invariant 2).
- `StxDatum` — the skeleton atoms (Symbol/Int/Float/Bool/String) plus
  proper lists; `()` is legal datum; improper (dotted) lists are a 0.3
  reader grammar decision (quoted pair data already lives in
  `kerf_core::LiteralValue::Pair`).
- `StxSymbol` — validated, opaque identifier (floor byte-identical to
  `kerf_core::Symbol`'s: non-empty, no whitespace, no control
  characters). A pipeline-phase twin, not a duplicate: the 0.4 expander
  crosses the boundary as source text through the core validated `&str`
  constructors, so "anything the reader accepts passes both floors"
  holds by identical validation (plan-0.2.md design record 2).
- `Phase` — the frozen two-level model (Runtime = 0, MacroExpansion =
  1, §8.9) with a checked `from_u8` decoder; phase closure is an
  expander (0.4) invariant, the data layer stores per-node phases
  without cross-validation.
- `ScopeId`/`ScopeSet` — the hygiene substrate: sorted, deduplicated
  storage (deterministic iteration — no HashMap randomness), functional
  `union` and the `is_subset_of` lexical-resolution query (§9.38
  scope-coloring sketch); scope freshness is a 0.4 expander-context
  discipline.
- Consumption contracts pre-anchored by integration tests:
  `visit_spans` pre-order traversal and the deep functional
  `with_scope_added` scope flip (principle 23 — the receiver is never
  mutated) for the 0.4 expander; the token→stx assembly pattern
  (token spans reduce to the list span, token text flows through the
  checked symbol constructor) for the 0.3 reader.
- 48 new tests (12 positive + 36 negative = 1:3; three layers: 32
  unit + 8 crate API + 8 cross-crate); workspace total 144, all green
  under the six-command gate (cold build). TD-003 shrinks to 6
  scaffold crates. CJK identifiers remain legal at the floor
  (registered test-fixture whitelist).

## v0.2.0 — Stage 0.1 core expression seed

The frozen semantic-primitive kernel (Layer 4), plus the two design
adjudications that unblocked it (docs/develop/v0/stage-0/
0.1-design-adjudications.md).

- TD-005 ratified: `CoreExpr` carries the nine semantic primitives
  (Fn/Apply/If/Var/Literal/Assign/Let/Perform/Handle) per SOP §21.12-11;
  the historical §3.2 frozen set maps onto it via the §6.12.6
  semantic-equivalence table (shared semantic core, closed both ways).
  Declaration layer `ModuleItem` = Define/Require/Module; `do` sugar
  desugars to `Let` at 0.4.
- TD-004 ratified: every node carries a real `Span` (never `Option`,
  never a dummy); dependency edge kerf-span → kerf-core added to the
  workspace DAG (docs/graph/stage-0/dataflow.md synced).
- `Symbol`: opaque checked identifier (non-empty, no whitespace, no
  control chars — conservative floor; full grammar lands with the 0.3
  reader). Validated `&str` constructors (`fn_`/`var`/`assign`/`perform`/
  `handle`, `Binding::new`, `HandlerClause::new`, `ModuleItem::define`/
  `require`/`module`) pre-anchor the 0.4 expander contract; duplicate
  params / duplicate handler effects are rejected deterministically.
- `CoreExpr::visit_spans` / `ModuleItem::visit_spans`: pre-order span
  traversal — the expander consumption contract and the no-dummy-span
  audit primitive.
- Tests: 48 new cases (unit 32 + crate API 8 + cross-crate integration
  8, positive:negative = 12:36 = 1:3); workspace total 96, all green.
- Verification: SOP §3.2 six commands all green on a cold build (see
  docs/develop/v0/stage-0/plan-0.1.md).

## v0.1.0 — Stage 0.0 cold-start bootstrap

First engineering artifact of the kerf compiler, reconstructed from the
upstream document repository (sop.md v15.0-verified + stage0.md design
blueprint, content state v9.8).

- Cargo workspace, edition 2024: root aggregation package + 9 `kerf-*`
  member crates wired exactly along the SOP §18.5 dependency DAG.
- Seed MUV `kerf-span` (Layer 0): `FileId` / `ByteOffset` / `ExpansionId` /
  `Span` with checked invariants (stage0.md §8.6 four-field model, §12.1
  byte-offset representation). Line/column rendering deferred to the
  diagnostics framework (TD-001).
- Test architecture per SOP §8.4.6/§9.1: root `tests/runner.rs` single
  entry + three-layer suite (unit / crate API / cross-crate integration).
- Stage 0 roadmap fixed: sub-stages 0.0-0.11 (minimal semantic kernel →
  infrastructure depth → macro engine → interface-reservation freeze →
  stage gate).
- Verification: SOP §3.2 six commands all green (see
  `docs/develop/v0/stage-0/plan-0.0.md`).

//! Stage 0 performance baseline (SOP §14.6.4) — the re-runnable
//! benchmark entry for the stage-end gate.
//!
//! Measures the two §22.3 baseline axes (compile time + run time)
//! with std-only tooling (zero new dependencies — SOP §18): wall
//! clock via `std::time::Instant`, statistics as mean/median/min/
//! stdev over N iterations (median stays the primary criterion —
//! environment-noise resistant; §9.61 PERF-2).
//!
//! Methodology v2 (§9.61, K88-K91 frontier adjudications):
//! - Optimizer fences: every measured region takes its source input
//!   through `std::hint::black_box` (K90 — best-effort fence, a
//!   discipline rather than a guarantee; the doc comment records the
//!   limitation so nobody mistakes the fence for a hard one).
//! - Warmup: each axis runs `max(3, iters/10)` unrecorded iterations
//!   before the measured loop, so cold caches and first-touch page
//!   faults land outside the sample set (§9.61 PERF-2).
//! - Reporting: mean / median / min / stdev — the stdev and min
//!   expose outlier contamination that mean/median alone would hide.
//! - Sub-axis split: B1 keeps its composite shape (whole-chain
//!   comparability with the recorded baseline) and gains three
//!   sub-axes B1a/B1b/B1c (read / expand / compile+verify) so a
//!   regression can be attributed to a stage — the §9.44.5 trigger
//!   table demands stage-level attribution, which the composite
//!   number alone could never provide (§9.61 PERF-3).
//! - Deterministic counters: B4 keeps the gc-cycles/swept counters —
//!   the deterministic observability face (K91 pattern: values that
//!   change are a semantic change, not a performance change).
//!
//! The output lines are the paste source for
//! `docs/develop/v0/stage-0/performance-baseline.md`; re-run after
//! any change and compare against the recorded baseline (regression
//! detection, §14.6.4 rule 3).
//!
//! Run: `cargo run --release --example stage0_baseline`.

use std::cell::Cell;
use std::hint::black_box;
use std::rc::Rc;
use std::time::Instant;

use kerf::compiler::compile_program;
use kerf::expander::expand_program;
use kerf::reader::read_program;
use kerf::runtime::collect as production_collect;
use kerf::span::FileId;
use kerf::vm::{Collector, Heap, Roots, Vm};

const FIB: &str = "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2)))))";

/// Four-statistic reporting set (§9.61 PERF-2). Sample standard
/// deviation (the `n-1` form) — the outlier-visibility companion to
/// the median-primary judgment.
struct Stats {
    mean: f64,
    median: f64,
    min: f64,
    stdev: f64,
}

fn stats(samples: &[f64]) -> Stats {
    let mut s = samples.to_vec();
    s.sort_by(|a, b| a.partial_cmp(b).expect("finite samples"));
    let n = s.len() as f64;
    let mean = s.iter().sum::<f64>() / n;
    let median = s[s.len() / 2];
    let min = s[0];
    let var = if s.len() > 1 {
        s.iter().map(|x| (x - mean) * (x - mean)).sum::<f64>() / (n - 1.0)
    } else {
        0.0
    };
    Stats {
        mean,
        median,
        min,
        stdev: var.sqrt(),
    }
}

/// One line of the paste block for microsecond axes (B1 family):
/// mean / median / min / stdev, one decimal, µs unit.
fn line_stats_us(label: &str, iters: usize, st: &Stats) {
    println!(
        "{label}: {iters} iters, mean {:.1}µs, median {:.1}µs, min {:.1}µs, stdev {:.1}µs",
        st.mean, st.median, st.min, st.stdev
    );
}

/// One line of the paste block for millisecond axes (B2-B5):
/// mean / median / min / stdev, three decimals, ms unit.
fn line_stats_ms(label: &str, iters: usize, st: &Stats) {
    println!(
        "{label}: {iters} iters, mean {:.3}ms, median {:.3}ms, min {:.3}ms, stdev {:.3}ms",
        st.mean, st.median, st.min, st.stdev
    );
}

/// Warmup count for an axis: `max(3, iters/10)` (§9.61 PERF-2 —
/// unrecorded iterations land cold caches and first-touch faults
/// outside the sample set).
fn warmup_iters(iters: usize) -> usize {
    (iters / 10).max(3)
}

/// Counting collector: shares sweep counters out through interior
/// mutability so the bench can read them while the VM owns the box.
/// The sweep itself is the production mark-sweep (`kerf-runtime`).
#[derive(Clone, Default)]
struct SharedCounters {
    cycles: Rc<Cell<u32>>,
    swept: Rc<Cell<u32>>,
}

struct CountingCollector {
    shared: SharedCounters,
}

impl Collector for CountingCollector {
    fn collect(&mut self, heap: &mut Heap, roots: &Roots) -> u32 {
        let gc = production_collect(heap, roots);
        self.shared.cycles.set(self.shared.cycles.get() + 1);
        self.shared.swept.set(self.shared.swept.get() + gc.swept);
        gc.swept
    }
}

fn main() {
    let file = FileId(0);

    println!("kerf stage-0 performance baseline (methodology v2)");
    println!(
        "env: release profile (debug_assertions={}), parallelism {:?}",
        cfg!(debug_assertions),
        std::thread::available_parallelism()
    );

    // B1 compile throughput: source -> read + expand + compile + verify.
    // Composite axis kept for baseline comparability; the three sub-axes
    // B1a/B1b/B1c below attribute a regression to a stage (PERF-3).
    const B1_ITERS: usize = 1_000;
    for _ in 0..warmup_iters(B1_ITERS) {
        let forms = read_program(file, black_box(FIB)).expect("read");
        let items = expand_program(&forms).expect("expand");
        let bc = compile_program(&items).expect("compile");
        bc.verify().expect("verify");
    }
    let mut b1 = Vec::with_capacity(B1_ITERS);
    for _ in 0..B1_ITERS {
        let t = Instant::now();
        let forms = read_program(file, black_box(FIB)).expect("read");
        let items = expand_program(&forms).expect("expand");
        let bc = compile_program(&items).expect("compile");
        bc.verify().expect("verify");
        b1.push(t.elapsed().as_secs_f64() * 1e6);
    }
    line_stats_us(
        "B1 compile-fib (read+expand+compile+verify)",
        B1_ITERS,
        &stats(&b1),
    );

    // B1a read sub-axis.
    let mut b1a = Vec::with_capacity(B1_ITERS);
    for _ in 0..B1_ITERS {
        let t = Instant::now();
        let forms = read_program(file, black_box(FIB)).expect("read");
        let n = forms.len();
        b1a.push(t.elapsed().as_secs_f64() * 1e6);
        black_box(n);
    }
    line_stats_us("B1a read-fib", B1_ITERS, &stats(&b1a));

    // B1b expand sub-axis (reads the product of a fenced read).
    let mut b1b = Vec::with_capacity(B1_ITERS);
    for _ in 0..B1_ITERS {
        let forms = read_program(file, black_box(FIB)).expect("read");
        let t = Instant::now();
        let items = expand_program(&forms).expect("expand");
        let n = items.len();
        b1b.push(t.elapsed().as_secs_f64() * 1e6);
        black_box(n);
    }
    line_stats_us("B1b expand-fib", B1_ITERS, &stats(&b1b));

    // B1c compile+verify sub-axis (reads the product of a fenced expand).
    let mut b1c = Vec::with_capacity(B1_ITERS);
    for _ in 0..B1_ITERS {
        let forms = read_program(file, black_box(FIB)).expect("read");
        let items = expand_program(&forms).expect("expand");
        let t = Instant::now();
        let bc = compile_program(&items).expect("compile");
        bc.verify().expect("verify");
        b1c.push(t.elapsed().as_secs_f64() * 1e6);
    }
    line_stats_us("B1c compile+verify-fib", B1_ITERS, &stats(&b1c));

    // B2 VM run: fib(25) = 75025 — the 0.6 anchor workload, entry
    // consumes the defined closure (read back from the global).
    const B2_ITERS: usize = 100;
    const B2_SRC: &str =
        "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define r (fib 25))";
    let bc2 = {
        let forms = read_program(file, black_box(B2_SRC)).expect("read");
        let items = expand_program(&forms).expect("expand");
        compile_program(&items).expect("compile")
    };
    for _ in 0..warmup_iters(B2_ITERS) {
        let mut vm = Vm::new(bc2.clone()).expect("vm");
        vm.run().expect("fib(25)");
    }
    let mut b2 = Vec::with_capacity(B2_ITERS);
    for _ in 0..B2_ITERS {
        let mut vm = Vm::new(bc2.clone()).expect("vm");
        let t = Instant::now();
        vm.run().expect("fib(25)");
        let elapsed = t.elapsed().as_secs_f64() * 1e3;
        assert_eq!(
            vm.global("r").map(|v| v.to_string()),
            Some("75025".to_owned())
        );
        b2.push(elapsed);
    }
    line_stats_ms("B2 vm-run-fib25", B2_ITERS, &stats(&b2));

    // B3 eval run: fib(20) = 6765 on the meta-circular evaluator.
    const B3_ITERS: usize = 30;
    const B3_SRC: &str =
        "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define r (fib 20))";
    for _ in 0..warmup_iters(B3_ITERS) {
        let mut session = kerf::driver::Session::new();
        kerf::driver::run_source(
            &mut session,
            "bench.krf",
            black_box(B3_SRC),
            kerf::driver::Engine::Eval,
            &[],
        )
        .expect("eval fib(20)");
    }
    let mut b3 = Vec::with_capacity(B3_ITERS);
    for _ in 0..B3_ITERS {
        let mut session = kerf::driver::Session::new();
        let t = Instant::now();
        let outcome = kerf::driver::run_source(
            &mut session,
            "bench.krf",
            black_box(B3_SRC),
            kerf::driver::Engine::Eval,
            &[],
        )
        .expect("eval fib(20)");
        let elapsed = t.elapsed().as_secs_f64() * 1e3;
        assert_eq!(
            outcome.global("r").map(|v| v.to_string()),
            Some("6765".to_owned())
        );
        b3.push(elapsed);
    }
    line_stats_ms("B3 eval-run-fib20", B3_ITERS, &stats(&b3));

    // B4 GC pressure: 2000 top-level defines each allocating one
    // pair that is dead right after `car` consumes it — the sweep
    // path is exercised under a tight 1024-cell budget (frames stay
    // flat; only heap garbage accumulates).
    const B4_ITERS: usize = 50;
    const B4_PAIRS: usize = 2_000;
    let mut churn_src = String::with_capacity(B4_PAIRS * 32);
    for i in 0..B4_PAIRS {
        churn_src.push_str(&format!("(define d{i} (car (cons {i} nil))) "));
    }
    let churn_bc = {
        let forms = read_program(file, black_box(&churn_src)).expect("read");
        let items = expand_program(&forms).expect("expand");
        compile_program(&items).expect("compile")
    };
    let shared = SharedCounters::default();
    for _ in 0..warmup_iters(B4_ITERS) {
        let collector = Box::new(CountingCollector {
            shared: shared.clone(),
        });
        let mut vm = Vm::with_budget_and_collector(churn_bc.clone(), 1024, collector).expect("vm");
        vm.run().expect("churn program halts");
    }
    let cycles_before = shared.cycles.get();
    let swept_before = shared.swept.get();
    let mut b4 = Vec::with_capacity(B4_ITERS);
    for _ in 0..B4_ITERS {
        let collector = Box::new(CountingCollector {
            shared: shared.clone(),
        });
        let mut vm = Vm::with_budget_and_collector(churn_bc.clone(), 1024, collector)
            .expect("tight-budget vm");
        let t = Instant::now();
        vm.run().expect("churn program halts");
        let elapsed = t.elapsed().as_secs_f64() * 1e3;
        b4.push(elapsed);
    }
    let st = stats(&b4);
    println!(
        "B4 gc-pressure-churn ({} pairs, budget 1024): {} iters, mean {:.3}ms, median {:.3}ms, min {:.3}ms, stdev {:.3}ms, gc-cycles/iter {}, swept/iter {}",
        B4_PAIRS,
        B4_ITERS,
        st.mean,
        st.median,
        st.min,
        st.stdev,
        (shared.cycles.get() - cycles_before) / B4_ITERS as u32,
        (shared.swept.get() - swept_before) / B4_ITERS as u32,
    );

    // B5 driver end-to-end: run_source VM fib(25) — session + pipeline
    // + halt-snapshot included.
    const B5_ITERS: usize = 50;
    const B5_SRC: &str =
        "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define r (fib 25))";
    for _ in 0..warmup_iters(B5_ITERS) {
        let mut session = kerf::driver::Session::new();
        kerf::driver::run_source(
            &mut session,
            "bench.krf",
            black_box(B5_SRC),
            kerf::driver::Engine::Vm,
            &[],
        )
        .expect("e2e fib(25)");
    }
    let mut b5 = Vec::with_capacity(B5_ITERS);
    for _ in 0..B5_ITERS {
        let mut session = kerf::driver::Session::new();
        let t = Instant::now();
        let outcome = kerf::driver::run_source(
            &mut session,
            "bench.krf",
            black_box(B5_SRC),
            kerf::driver::Engine::Vm,
            &[],
        )
        .expect("e2e fib(25)");
        let elapsed = t.elapsed().as_secs_f64() * 1e3;
        assert_eq!(
            outcome.global("r").map(|v| v.to_string()),
            Some("75025".to_owned())
        );
        b5.push(elapsed);
    }
    line_stats_ms("B5 driver-e2e-fib25 (vm)", B5_ITERS, &stats(&b5));
}

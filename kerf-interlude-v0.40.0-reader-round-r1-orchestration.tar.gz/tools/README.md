# tools/ — 自研工具归档（SOP §3.4）

按 `<domain>/` 子目录组织；新工具须同步 docs/tools/<domain>/ 文档。
当前为空（Stage 0.0 冷启动——首个自研工具落位时建立子目录）。

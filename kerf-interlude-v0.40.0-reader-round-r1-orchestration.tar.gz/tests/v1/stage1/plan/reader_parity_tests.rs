//! Stage 1.5 reader-parity integration tests — the first self-hosted
//! front-end segment through the real driver faces (stage-1-plan row
//! 1.5; docs/stage0.md §9.46.4 RS-1..RS-4).
//!
//! Three layers, per the corpus discipline:
//! - **Positive**: tree parity at byte-exact spans on both engines,
//!   the multi-form/atom-kind family, the corpus sweep (all 68 Stage
//!   1.4 corpus files as reader inputs), and the bootstrap fixed
//!   point (the .krf reader reads its own source's token stream).
//! - **Negative**: the four parser-side rejections at their exact
//!   payloads, the lexer-layer split, the 255/257 nesting boundary,
//!   and the drift detector's self-check (a tampered reader must be
//!   caught).
//! - **Cross-stage consumption**: the Stage 1.4 corpus deliverable is
//!   consumed as the reader-parity input face, and the parity
//!   contract's layer attribution rides the same driver module.

use kerf::driver::{ParityLayer, READER_SOURCE, reader_parity, reader_parity_with};

const CORPUS_DIR: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/tests/v1/stage1/corpus");

/// Run a body on a thread with a deep explicit stack. The evaluator
/// is a tree-walker: its *native* recursion grows with the kerf call
/// depth, and the deep corpus tables (bnd-006/007 ride ~1.3k tokens
/// = ~1.3k nested .krf reader calls) need more than the default
/// test-thread stack in debug builds. Virtual stack pages are
/// demand-allocated, so the large hint costs nothing.
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly");
}

fn deep_source(depth: usize) -> String {
    let mut src = String::new();
    for _ in 0..depth {
        src.push('(');
    }
    src.push('x');
    for _ in 0..depth {
        src.push(')');
    }
    src
}

// ---------- positive: tree parity at byte-exact spans ----------

#[test]
fn nested_tree_parity_matches_the_oracle_spans() {
    // The parser.rs unit anchor: root 0..11, inner list 3..8.
    let report = reader_parity("nested", "(f (g 1) 2)");
    assert!(report.matched, "{}", report.failure_line());
    assert!(report.engines_agree);
    assert_eq!(report.layer, ParityLayer::Parser);
    assert_eq!(
        report.oracle,
        "(list 0 11 (ident 1 2 f) (list 3 8 (ident 4 5 g) (int 6 7 1)) (int 9 10 2))"
    );
    assert_eq!(report.krf.as_deref(), Some(report.oracle.as_str()));
}

#[test]
fn multi_form_program_with_every_atom_kind_parity() {
    let src = "; leading comment\n(a) 1 x 2.5 #t \"s\\n\" \"raw\\nnewline\"\n";
    let report = reader_parity("atoms", src);
    assert!(report.matched, "{}", report.failure_line());
    assert!(report.engines_agree);
    // Two forms: the list, then five top-level atoms.
    assert_eq!(report.oracle.matches("(list").count(), 1);
    assert!(report.oracle.contains("(float "));
    assert!(report.oracle.contains("(bool 30 32 true)"));
    assert!(report.oracle.contains("(string "));
}

#[test]
fn empty_source_and_comment_only_source_parity() {
    for src in ["", " ; nothing here\n\t\n"] {
        let report = reader_parity("empty", src);
        assert!(report.matched, "{}", report.failure_line());
        assert_eq!(report.oracle, "");
        assert_eq!(report.krf.as_deref(), Some(""));
    }
}

#[test]
fn whitespace_inside_lists_and_string_escapes_parity() {
    let src = "( write-line  \"a\\tb\" )";
    let report = reader_parity("ws", src);
    assert!(report.matched, "{}", report.failure_line());
    assert!(report.oracle.contains("\"a\\tb\""));
}

#[test]
fn float_extremes_parity_through_debug_text() {
    // Every float rides as Debug text (inf/NaN have no .krf literal
    // shape). v0.40.0 (§9.71): the overflow faces fail closed — the
    // inf payload path no longer exists via literal overflow, and
    // the legal extremes carry the Debug-text convention: f64::MAX,
    // a negative fraction, and the underflow-to-zero rounding.
    let report = reader_parity("floats", "(f 1.7976931348623157e308 -0.5 1e-999)");
    assert!(report.matched, "{}", report.failure_line());
    assert!(report.oracle.contains("1.7976931348623157e308"));
    assert!(report.oracle.contains("-0.5"));
    assert!(report.oracle.contains("0.0"));
}

#[test]
fn literal_overflow_faces_reject_on_the_lexer_layer() {
    // v0.40.0 (§9.71): both overflow faces are lexer-side rejections
    // (ParityLayer::Lexer — the .krf structure layer is not exercised
    // for sources the single-source lexer itself refuses).
    for (case, src, want) in [
        (
            "i64-overflow",
            "(f 9223372036854775808)",
            "integer literal `9223372036854775808` out of range for `i64`",
        ),
        (
            "f64-overflow",
            "(f 1e999)",
            "float literal `1e999` out of range for `f64`",
        ),
    ] {
        let report = reader_parity(case, src);
        assert!(report.matched, "{}", report.failure_line());
        assert!(
            report.oracle.contains(want),
            "case {case}: oracle `{}` must contain `{want}`",
            report.oracle
        );
    }
}

#[test]
fn i64_boundaries_parity() {
    let report = reader_parity("ints", "(f -9223372036854775808 9223372036854775807 007)");
    assert!(report.matched, "{}", report.failure_line());
    assert!(report.oracle.contains("-9223372036854775808"));
    assert!(report.oracle.contains("9223372036854775807"));
    // `007` re-lexes as 7 on the oracle side (i64 parse semantics).
    assert!(report.oracle.contains("(int 44 47 7)"));
}

// ---------- negative: rejections at exact payloads ----------

#[test]
fn parser_side_rejections_match_byte_for_byte() {
    // §9.56 DIAG-1: the parity key = position-free Display +
    // harness-rendered `@ byte` suffix (offsets surface in the key).
    for (src, want) in [
        ("(f", "unclosed delimiter: `(` is never closed @ byte 0"),
        ("(a (b", "unclosed delimiter: `(` is never closed @ byte 3"),
        ("(((x", "unclosed delimiter: `(` is never closed @ byte 2"),
        (
            "(a 1) (b (c) x",
            "unclosed delimiter: `(` is never closed @ byte 6",
        ),
        (
            "(a) (b) (c",
            "unclosed delimiter: `(` is never closed @ byte 8",
        ),
        (")", "unexpected closing delimiter `)` @ byte 0"),
        ("(a 1) )", "unexpected closing delimiter `)` @ byte 6"),
        ("()", "empty application: `()` has no operator @ byte 0"),
        ("(f ())", "empty application: `()` has no operator @ byte 3"),
        (
            "(a (b ()))",
            "empty application: `()` has no operator @ byte 6",
        ),
        (
            "(f () 1)",
            "empty application: `()` has no operator @ byte 3",
        ),
        ("(()", "empty application: `()` has no operator @ byte 1"),
    ] {
        let report = reader_parity("neg", src);
        assert_eq!(report.layer, ParityLayer::Parser, "case {src:?}");
        assert!(report.matched, "case {src:?}: {}", report.failure_line());
        assert!(report.engines_agree, "case {src:?}");
        assert!(
            report.oracle.starts_with(want),
            "case {src:?}: oracle `{}` want `{want}`",
            report.oracle
        );
        assert_eq!(report.krf.as_deref(), Some(report.oracle.as_str()));
    }
}

#[test]
fn lexer_layer_split_short_circuits_the_six_variants() {
    for src in [
        "\"unterminated",
        "(a \"\\q\")",
        "#x",
        "1.2.3",
        "[",
        "(a `b)",
    ] {
        let report = reader_parity("lex", src);
        assert_eq!(report.layer, ParityLayer::Lexer, "case {src:?}");
        assert!(report.matched, "case {src:?}");
        assert!(report.krf.is_none(), "case {src:?}");
    }
}

#[test]
fn nesting_boundary_255_ok_and_257_rejected_at_exact_payload() {
    deep_stack(nesting_boundary_body);
}

fn nesting_boundary_body() {
    // 255-deep is legal: the .krf reader walks 512 tokens on both
    // engines and produces the full tree.
    let ok = reader_parity("bnd-255", &deep_source(255));
    assert!(ok.matched, "{}", ok.failure_line());
    assert!(ok.engines_agree);
    // 257-deep rejects at the oracle's exact payload (depth 257,
    // limit 256) — the .krf depth counter is checked on entry.
    let over = reader_parity("bnd-257", &deep_source(257));
    assert!(over.matched, "{}", over.failure_line());
    assert_eq!(over.oracle, "nesting depth 257 exceeds the limit of 256");
    // 256-deep is the inclusive boundary (legal).
    let edge = reader_parity("bnd-256", &deep_source(256));
    assert!(edge.matched, "{}", edge.failure_line());
}

#[test]
fn drift_detector_catches_a_tampered_reader() {
    // The unclosed payload tampered to the OUTERMOST open list — the
    // detector must flag the drift (a detector that cannot fail
    // proves nothing).
    let tampered = READER_SOURCE.replace(
        "(cons \"unclosed\" (cons (rd-fr-open (car stack)) nil))",
        "(cons \"unclosed\" (cons (rd-fr-open (rd-rev stack nil)) nil))",
    );
    assert_ne!(tampered, READER_SOURCE);
    let report = reader_parity_with("tamper", "(a (b", &tampered);
    assert!(!report.matched, "the tampered reader must be caught");
    assert!(report.drift.is_some());
}

#[test]
fn drift_detector_catches_a_wrong_nesting_limit() {
    deep_stack(wrong_limit_body);
}

fn wrong_limit_body() {
    // The limit tampered to 255: the 256-deep boundary case must now
    // drift (the .krf reader rejects where the oracle accepts).
    let tampered = READER_SOURCE.replace("(if (> (+ d 1) 256)", "(if (> (+ d 1) 255)");
    assert_ne!(tampered, READER_SOURCE);
    let report = reader_parity_with("tamper-limit", &deep_source(256), &tampered);
    assert!(!report.matched, "the wrong limit must be caught");
    // And the 255-deep case still agrees under the tampered limit.
    let still = reader_parity_with("tamper-limit-255", &deep_source(255), &tampered);
    assert!(still.matched, "{}", still.failure_line());
}

// ---------- cross-stage consumption: the Stage 1.4 corpus ----------

#[test]
fn corpus_directory_every_file_validates_reader_parity() {
    deep_stack(corpus_sweep_body);
}

fn corpus_sweep_body() {
    let entries = std::fs::read_dir(CORPUS_DIR).expect("the Stage 1.4 corpus directory is in tree");
    let mut files: Vec<_> = entries
        .filter_map(|e| e.ok())
        .map(|e| e.path())
        .filter(|p| p.extension().is_some_and(|x| x == "krf"))
        .collect();
    files.sort();
    assert!(
        files.len() >= 50,
        "the corpus floor is >= 50 (found {})",
        files.len()
    );
    let mut parser_layer = 0usize;
    let mut lexer_layer = 0usize;
    for path in &files {
        let source = std::fs::read_to_string(path).expect("corpus file reads");
        let name = path.file_name().and_then(|n| n.to_str()).unwrap_or("?");
        let report = reader_parity(name, &source);
        assert!(
            report.matched,
            "corpus case {name}: {}",
            report.failure_line()
        );
        assert!(
            report.engines_agree,
            "corpus case {name}: engine divergence"
        );
        match report.layer {
            ParityLayer::Parser => parser_layer += 1,
            ParityLayer::Lexer => lexer_layer += 1,
        }
    }
    // Both layers are exercised by the corpus (the neg- family
    // covers lexer-side rejections; pos/bnd cover the parser side).
    assert!(parser_layer >= 60, "parser-layer cases: {parser_layer}");
    // The corpus's lexer-side rejections (unterminated string,
    // invalid escape) are the minority family.
    assert!(lexer_layer >= 2, "lexer-layer cases: {lexer_layer}");
}

#[test]
fn corpus_boundary_files_ride_the_deep_paths() {
    deep_stack(corpus_boundary_body);
}

fn corpus_boundary_body() {
    // bnd-006 (255-deep ok) and bnd-007 (257-deep rejected) — the
    // heaviest token tables the harness walks, on both engines.
    for (file, want_layer) in [
        ("bnd-006-nesting-255-ok.krf", ParityLayer::Parser),
        ("bnd-007-nesting-257-fails.krf", ParityLayer::Parser),
    ] {
        let source = std::fs::read_to_string(format!("{CORPUS_DIR}/{file}")).expect("file");
        let report = reader_parity(file, &source);
        assert_eq!(report.layer, want_layer);
        assert!(report.matched, "{}", report.failure_line());
        assert!(report.engines_agree);
    }
}

// ---------- the bootstrap fixed point ----------

#[test]
fn the_krf_reader_reads_its_own_source_token_stream() {
    // The .krf reader's own source, lexed by the Rust oracle and
    // re-read by the .krf structure layer — the bootstrap fixed
    // point as a corpus case (the oracle stays the Rust reader per
    // the 1.4 contract; this checks the loop closes on itself).
    let report = reader_parity("selfhost-fixed-point", READER_SOURCE);
    assert!(report.matched, "{}", report.failure_line());
    assert!(report.engines_agree);
    assert!(report.oracle.contains("(ident "));
    assert!(report.oracle.starts_with("(list "));
}

// ---------- report face ----------

#[test]
fn report_failure_line_names_the_case_on_both_verdicts() {
    let pass = reader_parity("pass-case", "(a)");
    assert_eq!(pass.failure_line(), "reader parity PASS [pass-case]");
    let tampered = READER_SOURCE.replace(
        "(cons \"empty-app\" (cons (rd-fr-open (car stack)) nil))",
        "(cons \"empty-app\" (cons \"0\" nil))",
    );
    let fail = reader_parity_with("fail-case", "(f ())", &tampered);
    assert!(!fail.matched);
    assert!(
        fail.failure_line()
            .starts_with("reader parity FAIL [fail-case]")
    );
    assert!(fail.failure_line().contains(" vs krf "));
}

#[test]
fn harness_defects_surface_as_drift_not_panics() {
    // A reader source that binds garbage: the harness must report a
    // drift (never panic) — errors are data (§12.2 lineage).
    let broken = "(define result 42)";
    let report = reader_parity_with("broken", "(a)", broken);
    assert!(!report.matched);
    assert!(report.drift.as_deref().unwrap().contains("harness defect"));
}

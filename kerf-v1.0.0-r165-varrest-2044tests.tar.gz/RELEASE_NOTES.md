# 发布说明

## r165 —— TD-038 变参 rest 参数窗：`fn f(a: T, ...rest: T)` 现代 rest 参数形全链 + append 泊回实裁 + 语料质量审计（2012 → 2044 净 +32 机制窗）

> 2026-11-26 · Task ID 236-a..236-f · 设计单源 [variadic-rest-design.md](docs/develop/v0/stage-3/variadic-rest-design.md) v1.0（D1-D11 + D7' 实施期实裁 + §9 诚实边界九条）

**语言面（用户可见）**：`fn f(a: T, b: T, ...rest: T) { ... }`——JS/TS/Rust 模式位同形的现代 rest 参数（闭包面同权 `||(base: T, ...more: T)`）；rest 绑定 = 帧建立期右折叠 nil 终止 pair 链（0 超参 ⇒ nil）；min-arity fail-closed（实参 < 定参数 → E0004 "expected at least N"；定参面消息逐字节维持）；check 静态 ≥N + 超参 unconstrained（运行时真值为准——`TcParams::Variadic(Any)` 同语义）。

**实施链（机制窗）**：`...` 词法 = r129 第九皮肤映射既有 ident 载荷（零 lexer 变更零新 Token 变体）→ Stx 签名沿标记符（`(define (f a ... rest) body)`——无标记 = 定参，全语料向后兼容）→ CoreExpr::Fn/IrNode::Fn 加性字段 `rest: Option<Symbol>`（原则 27）→ BcProto `rest_slot`（wire 协议零 bump）→ 双 Reader 锁步（Rust parse_typed_params rest 臂 + 种子 reader.ktf rest_param_tail 镜像——错误面字节级 parity）→ expander parse_params/parse_rest_param（终端律 + A3 重复律 + 程序化 Stx 防御）→ 种子/生产编译器 rest 槽位 → VM 三 arity 位（run_closure 入口 / Call / TailCall）+ 双池路径行为同一性（td028 四参数契约延拓）→ eval.rs 树走同律 → HM/check 双面锁步。

**D7' 实施期实裁（append 泊回）**：原设计 D7 全量迁移撞双实锤——①注入/注册互斥（import 注入 fn append 与 Rust 注册撞名 E0004 实测）；②种子链热消费（reader.ktf ×6 + expander.ktf ×5 拼接消费——r164 member/assoc 12.5x 同族）。循 r164 先例处置：kerf 实现已证（测试门内联 kl_va_append 全语义 + 错误面逐字节）+ 泊回 + **TD-041 触发式重登记**（native-AOT + TD-040 语料拼接迁移双触发）。

**TD-040 新登记（同窗附带腿——236-a-audit）**：自举语料四维工具化实测——77 函数深度>3（11.4%，95% 集中 reader/expander 机械翻译三代件，`} else { if` 堆叠链为直接成因）+ 9 件超 80 行 + 短名族 + 职责混合；新写件面健康（61 函数仅 3 例轻度）。触发式批窗（r166 候选首位）。

**验收**：ktf_variadic_rest_tests 32 case（8 正 + 24 负 1:3，6 错误类 E0001/E0004/E0005/E0006/E0019/E0022 + r162/r164 边界回归）+ GATE 1 六命令全绿 2044:0:0 净 +32 + 审计复跑 125:0 + CLI 零回归（fib(25)=75025 / sum_rest 0/15 / 闭包 rest）+ bench fib 75.791ms（基线 76.506ms——-0.9% 噪声带，定参路径零开销实证）+ 增长锚重校准 216/507/247 + 8 原语不变性第四十七轮。委员会投票 5.5/5.5 GO（验收即兑付）。

## r164 —— list 域自建迁移窗：五内建 kerf 语料自建 + forms 级注入 + 性能边界裁定（1979 → 2012 净 +33 自举深化窗）

> M1 指令开窗第六十九例（用户指令①「在种子端应该是极小的（只有不能实现的部分内容），其余应当全部通过自己自建实现」——种子端极小性审计的 list 域行权；设计单源 list-self-built-design.md v1.1{D1-D12 + §9 性能边界裁定}）

**窗口定位**：**自举深化窗**（BS-A 最大化前端自举方向行权——r109 preamble 先例族{map/filter/foldl/foldr/for_each}的 list 域扩展）；**非皮肤窗非机制窗**（实现源迁移——零新原语零通道零新操作码，8 原语不变性第四十六轮）。

**交付要点**：
1. **迁移集（D1——v1.1 修订后）**：五定参内建 length/reverse/nth/drop/last-pair 从 Rust 种子注册面（builtins.rs BuiltinFn）迁入自建 kerf 语料 `bootstrap/list.ktf`（第 11 件）——纯 pair-spine 尾递归实现{TD-022 帧预算同律——O(n) 帧不叠栈}；`list`{N1 变参构造} + `append`{变参 arity——TD-038 登记面缺位}维持 Rust；**member/assoc 性能边界泊回**{v1.1 裁定——check-HM 查询段深度敏感热消费 37s 撞 10⁹ TCO 守卫实测；kerf 实现已证[E2E + 错误面逐字节]——TD-039 native-AOT 回收触发式重迁}。
2. **forms 级注入（D3/D4——preamble 先例同构）**：`import kerf_list` ⇒ list.ktf 模块形式并入编译单元（read 后 expand 前——Span 独立 file_id）；`import kerf_prelude` ⇒ **级联注入**（preamble + list 双模块——nth/drop 重导出域定义单源）；RESERVED_ALLOW 预 declare 例外（kerf-list 同 kerf-prelude——注入形态承接 declare）；双路判定{seed = Rust oracle imports_list_seed / 生产 = build.ktf 泛化族 lbld_is_imports_kerf_list}。
3. **限定名 flat 化 + 重命名注入扩展（D3 增补）**：`list::nth` 限定 Var → 注入 define 的 flat nth（rewrite_alias_expr Var 臂扩展——短名/全名/别名归一产物三形态覆盖）；`use kerf_list::{nth as pick}` 选择形重命名 → Stx 注入 `(define pick nth)`（r135 D14 同构扩展）。
4. **错误面逐字节复刻（D5）**：type_name 谓词族 12 分支 helper{粒度边界申报：Closure/Builtin 皆 "procedure" + 谓词全阴兜底 "unit"} + int_to_string 自建{kl_ 私有名族——expander/test 撞名审计后避让}；**arity 面 fn 形消息变更申报**{E0004 "procedure argument count mismatch"——设计申报的合法变更}；静态域诊断退役 → 泛型统一面{E0005 type mismatch——fail-closed 方向维持}。
5. **注册面收缩与守卫对账（D8）**：STDLIB_MODULES 导出面行恢复{E0014/E0024 查询面完整性} + SELF_BUILT_LIST_NAMES 清单{注册跳过——导出面/注册面分离} + 四守卫对账{105/93/16/58 族计数 + SELF_BUILT 跳过条件}。
6. **ktf_list_selfbuilt_tests 33 case 门（D6）**：8 正 + 24 负 1:3 + 边界复合{五面 E2E + 级联/限定名/重命名/万元素帧预算/Rust 锚共存 + 错误面字节锚 ×13 + arity fn 形 ×5 + 静态统一面 + member/assoc 维持半 + E0022 + r163 边界回归}。
7. **法修订涟漪十二处全数定性（§9.3）**：stdlib arity 矩阵 / member_any 双向 / diag_msg / tc_sigs / seed_parity / read_line 计数与语料锚 / hm_production occurs 6→14{注入体保守假阳性——r80 接受族} / hm_inference td030 / multi_parity import 面切换 / namespace d50 按名查找 / fixpoint B₀' 注入对齐 / builtins 四守卫。
8. **GATE 1 六命令全绿**：build 零告警 + check 0:0 + fmt 0 diff + clippy -D warnings 0{r163 既有文件新 lint 漂移当场清偿——同族第四例} + test **2012:0:0 净 +33** + 审计复跑 125:0；CLI 零回归{fib 75025⇒144 / closures ⇒42 / check 2/9/5/38} + bench fib **76.506ms**{基线 74.814ms——+2.3% 链级，迁移面生产占比实测确证}。

**遗留债务**：TD-038{变参函数面缺位——append 迁移阻断，触发式} + TD-039{member/assoc 自建重迁——native-AOT 性能回收触发式} + TD-034 维持{cache 富面休眠}——俱触发式零开放缺陷。

## r163 —— 索引访问窗：`coll[idx]` postfix 中缀面第十七皮肤映射 + N1 vector-ref 扩容（1948 → 1979 净 +31 索引面语言窗）

> M1 指令开窗第六十八例（用户四链指令——①「……基础内置函数、数据类型、数据结构……应该通过目标语言自身设计实现」——数据结构消费三角第三角开窗；设计单源 index-access-design.md v1.0{D1-D10}；会话压缩恢复轮 234-d 续作收口——上会话代码+测试已落，本会话 GATE 1 实测全绿 + 治理/打包/web 收口）

**窗口定位**：「one face, one name」轨迹第十步（索引访问面——r158 顶层 let / r159 运算符面 / r160 数据结构面 / r161 绑定性质面 / r162 相等域面连续五窗后第六窗）；数据结构消费三角闭合{构造角 r160 `(a, b)` + 解构角 r121 模式位 + **索引角 r163**}；r138 D6 位置纪律 superseded。

**交付要点**：
1. **皮肤映射第十七（D1）**：`coll[idx]` postfix 位索引面 → as-if-written `(vector-ref coll idx)`——Reader 直接合成与调用形产物同构的 Stx（皮肤换、骨架不变——原则 31：零脱糖零新原语零 CoreExpr/IR/操作码，expander/compiler/HM/VM 全链零触及，8 原语不变性第四十五轮）；恰一索引表达式（空 `v[]` / 多参 `v[1, 2]` fail-closed E0001）；嵌套链式 `v[i][j]` = postfix 尾循环自然组合；D7 Span 契约（合成 vector-ref 头符号 = `[` Token 本位——r160 D10 先例）。
2. **N1 扩容（D2/D3——编译层放行）**：`vector-ref` 入 N1_CORE_NAMES 数据模型词汇组第 42 名——脱糖目标免 import 纪律（r138 D4「字面量强制 import = 坏的语言设计」律的索引面兑付）；VM 全局注册既有 ⇒ 零 VM 触碰；诚实申报：连字符 `vector-ref` 直书维持 r159 中缀词法拦截（N1 扩容只服务脱糖产物 Stx 符号——与 r162 `=` 休眠态同构）；N2 `vector_ref(v, 1)` import 调用形维持合法（双面并存——与 r162 后 `==`/`eq(...)` 关系同构）。
3. **fail-closed 三面沿用（D4——VM 零改动）**：非 Vector 首参 E0004 / 非 int 索引专用诊断 / 越界专用诊断——r138 三 fail-closed 面自然继承。
4. **不可变维持（D5）**：`v[i] = x` 索引赋值域外维持——Reader assign LHS 只接受标识符绑定域（r138 D1 不可变性的执法面）；可变索引赋值未来开窗须先修订 r138 D1（登记维持）。
5. **诚实边界三条（D6）**：pair-list 索引维持 `nth(lst, i)` 调用形{import kerf_list}——对 Pair 值运行时 E0004 fail-closed（不静默分派）；Str 字符索引域外（字节/字符/码点位 = 独立设计题——未来窗域外登记）；空索引/多参 Reader 层专用诊断。
6. **测试门 32 case**：ktf_index_access_tests（8 正 + 24 负 1:3）——核心 E2E{`v[1]` ⇒ 20 + 表达式索引 + 嵌套链式 + 字面量直索引} + as-is-written Stx 同构门 + r138 N2 兼容 + r162 跨阶段组合 + r161 const 组合 + 双 Reader 正典渲染 parity ×4 形 + r162 边界回归 ×3 + 7 类错误 ≥6 类覆盖。
7. **法修订涟漪五处**：corpus neg11（Reader 域外 → VM E0004 域检查——pair-list 索引走 VM fail-closed）+ vector neg15 退役（postfix 域外锚随合法化）+ krf_tests `1[2]` 域外行退役 + **builtins 计数断言双修订**{N1 41→42 + shrink 面 22→21——vector-ref 从 kerf_vector 模块 underlying 面移入 N1 面；恢复轮发现当场清偿} + fmt 遗留折行清偿。
8. **增长签名锚**：reader.ktf payload 215 protos / 504 consts / 246 globals **零增量维持**（一进一出巧合：退役的域外消息字符串槽位恰被新入的 "vector-ref" 字符串填补——payload consts 净零）。

**验证**：GATE 1 六命令全绿{build 零告警 + check 0:0 + fmt 0 diff + clippy -D warnings 0 + **test --release --workspace 1979:0:0 净 +31**[RUST_MIN_STACK=33554432——净账目 = 32 新增 − 1 退役]} + 审计复跑{architecture_audit 6:0 + seed_ktf_parity 119:0} + CLI 零回归探针{fib 75025/⇒144 + const 6 + r162 true/false} + 新面 E2E 八探针{正向四 + 负向四{越界 E0004 专用诊断 exit 1 / 空索引 E0001 / 多参 E0001 / assign 位 E0001} + 域外双边界{Str got str / Pair got pair}}；治理八件{02 v7.31 + 20 v1.42 + matrix 1979 + 本节 + t3plus v1.83 + 登记册 v0.4.21 + 设计单源 §5 勘误{设计期预估 1980/净+32 失准修正为实测 1979/净+31} + 锚注释 r163 校准行} + README；8 原语不变性第四十五轮（零新原语零通道零新操作码——词汇面扩容非原语面）。

---
## r162 —— TD-037 相等域窗：`==` 扩域至 eq 语义 + eq 值律结构化分层 + r138 eq? 律修订（1916 → 1948 净 +32 相等域面语言窗）

> M1 指令开窗第六十七例（用户四链指令——①「……eq（等运算符问题，**应当使用现代设计理念**）……」——TD-037 触发条件①三选一行权[A：`==` 扩域至 eq 语义]；设计单源 equality-domain-design.md v1.0{D1-D10}）

**窗口定位**：「one face, one name」轨迹第九步（相等域面——r158 顶层 let / r159 运算符面 / r160 数据结构面 / r161 绑定性质面 / r162 相等域面连续五窗）；TD-037 清偿关闭（r161 / 231-b-audit 附带发现的跨值域相等中缀面缺口——P3 触发式三选一裁定本窗行权）。

**交付要点**：
1. **皮肤映射域重指向（D1）**：`a == b` → `(eq a b)`；`a != b` → `(not (eq a b))`——双 Reader 单点换目标（Rust parse_comparison `Tk::Eq` 臂 + 种子 reader.ktf cmp_make/`!=` 臂）；`=` 内核基座休眠态申报（裸 `=` 词法为 Assign——现代面不可直书；退役 = 未来移除轮窗）+ ordering 族（`< > <= >=`）维持 num/str 全序域（TD-011 r24 律零触碰——同路径审计 `true < false` ⇒ E0004/E0005 维持）。
2. **eq 值律结构化分层（D3/D4——本窗核心语义）**：新增 `kerf_vm::structural_eq` 用户面单源——immediate 域值相等 + **Pair/Vector 递归结构相等**（spine 迭代走尾——长表无深栈）+ **procedural 值同一性维持**（Closure/Builtin/Continuation/External——eq? 律保留）+ **混合域静默 false**（`1 == "1"` ⇒ false——Python/JS 先例；r161 基线下 E0004/E0005 双诊断面退役）；消费面五处切换{eq 内建 / assert-eq / member / assoc / VM `Op::Eq`——一相等律用户面全域}; `Value::eq_value` 保留为值层基底（4 处历史测试直引零扰动）；**无环不变量**：不可变构造（无槽位突变原语）⟹ Pair/Vector DAG 无环 ⟹ structural_eq 全域终止。
3. **r138 eq? 律修订（D5——登记法变更）**：Pair/Vector per-instance identity → 值相等。理由四联：①用户「现代设计理念」指令 ②混血不连贯（`eq("a","a")` 结构真 vs `eq((1,2),(1,2))` 同一性假——不可辩护）③不可变性使结构相等健全（Python 元组/Rust derive 先例）④种子 `is_const_eq` 手工绕路证据（compiler.ktf:417 注释自证——语言自身需要结构相等却要求用户手工实现）；r138 neg23 锚翻转（`eq(vector(), vector())` ⇒ true）。
4. **check/HM 面（D6）**：eq sig 既有（`(Any, Any) → Bool`）——零注册链增量；`==` 位静态域诊断退役（`true == true` 从 E0005 → check 通过——与运行时真值一致）；ordering 族静态诊断维持。
5. **测试门 32 case**：ktf_equality_domain_tests（8 正 + 24 负 1:3）——核心 E2E{`true == true` ⇒ true[TD-037 开窗句] + `(1, 2) == (1, 2)` ⇒ true + 嵌套 + vector + `!=` 面 + const 跨阶段[r161 边界四联 + 正向腿]} + 混合域静默 false ×3 + as-is-written 调用形结构锚{`1 == 2` → `(eq 1 2)`} + 双 Reader 正典渲染 parity + check 面翻转锚 + 7 类错误 ≥6 类覆盖。
6. **法修订涟漪九处全数定性（零真回归）**：hm superset R3 行 / ktf_vector neg23 / negative_semantics d2 / negative_vm comparison + symbol_misuse / stdlib comparison_chain + eq_boundaries / test_runner form render / typecheck r3——俱为 D3/D5 律翻转的既有期望落定。
7. **增长签名锚**：reader.ktf payload 215 protos / 504 consts / 246 globals（`=` 符号末二引用退役 → global_refs −1）。

**验证**：GATE 1 六命令全绿{build 零告警 + check 0:0 + fmt 0 diff + clippy -D warnings 0 + **test --release --workspace 1948:0:0 净 +32**[RUST_MIN_STACK=33554432]} + CLI 零回归七探针{fib 144 / closures 42 / higher_order (1 4 9 16 25) / vector 9 / match fib-13 / gc_stress(const) 5 / check 2/9/5/38——与 r161 基线逐字节一致} + 新面 E2E 探针族；治理八件{02 v7.30 + 20 v1.41 + matrix 1948 + 本节 + t3plus v1.82 + TD-037 清偿关闭[登记册 v0.4.20] + r138/r159 设计单源增补 + 设计单源 equality-domain-design.md v1.0} + README；8 原语不变性第四十四轮（零新原语零通道零新操作码——值层语义精化非原语增量）。

---

## r161 —— 常量声明窗：`const name [: T] = e;` 第十六皮肤映射 + 项位 assign 拒收只读闭环 + 绑定性质轴收口（1884 → 1916 净 +32 绑定性质面语言窗）

> M1 指令开窗第六十六例（用户四链指令——①「……缺少常量的定义和描述从语法到具体语义和实现……应该通过目标语言自身设计实现」——231-b-audit 十项审计裁定：常量 = 唯一四面俱缺完全缺失面[P1 实锤：关键字域无 const / EBNF 无产生式 / 实现无受理 / 文档无承诺——mut 修饰词为 no-op 剥离，绑定性质轴未编码]；②实现窗推进 ③推荐序推进 ④打包 + web 同步）。

**窗口定位**：「one face, one name」轨迹第八步（绑定性质面——r158 顶层 let / r159 运算符面 / r160 数据结构面 / r161 绑定性质面连续四窗）；one face, one name 的语义轴收口：可变（let + assign 面）与只读（const 面）双轴俱备。

**交付要点**：
1. **产生式与皮肤（D1）**：`toplevel_const ::= "const" identifier [ ":" type ] "=" expr ";"` → Stx `(define name e')`——第十六皮肤映射，as-if-written toplevel_let 孪生（r158 先例——皮肤换、骨架不变，原则 31；零脱糖零新原语零 CoreExpr/IR/操作码；expander/compiler/HM/VM 全链零触及——8 原语不变性第四十三轮）。const = 目标面本地关键字第 14 名（E0020 共享保留域 28 名零扰动——halt/pass/macro 先例，原则 27）。
2. **最小只读语义闭环（D3——本窗核心语义）**：Reader 单遍顺序 const 集——项位 assign 语句 `NAME = e;` 若 NAME ∈ const 集 → E0001 拒收（消息 "cannot assign to a const binding (const bindings are read-only; rebind with let for mutation)" + Span = 名 Token 本位[r130 先例]）；重绑移除（let/fn/macro/module 名——最新绑定胜出——移除使内核 E0004 平表不变量浮现于更深错误位）；模块体保存/清空/恢复（模块局部 const 不外泄——p-b 探针实证）。种子侧承载 = CONST_NAMES 模块级可变全局 + assign 面 SetGlobal 自举通道（P1 探针实证——种子纯函数式风格的首次 assign 面使用）。
3. **三专用诊断 + 块位域外（D1/D4）**：const mut 矛盾拒收（Span = mut Token）/ 单绑定封顶（toplevel_let 同族）/ 块位 domain-out（mut 块位臂同构——fn 体与 if 臂俱验）。
4. **D4 诚实边界（实证锚定）**：函数体/块内 assign const 名 = 域外维持（p-c 探针 ⇒ 2——运行时 SetGlobal 生效；完整不可变性 = Stage 2+ 类型系统保证[D35⑥ 重申]）；32 case 电池含边界正向锚。
5. **种子源 IR 标签重命名**：`('const tag value)` → `('constant tag value)` 8 处（compiler.ktf——新关键字与 quote(const) 冲突消解；桥 const_from_value 结构性忽略外标签——零桥代码变更；'constant' 全词 r102 命名纪律）。
6. **双 Reader 锁步（D2）**：Rust parse_const_decl + parse_stmt_into 门 + 模块保存恢复 + 重绑移除五点 ↔ 种子 TKEYWORDS + CONST_NAMES + const_has/remove/add + parse_const_decl 镜像 + parse_stmt_into 门 + 模块保存恢复 + 重绑移除——四新诊断错误面消息+Span 字节级 parity（32 case 电池 ×6 parity 断言 + 全语料既有 parity 门全绿）。
7. **测试门（D7）**：ktf_const_decl_tests 32 case = 8 正 + 24 负 1:3（E2E 值/跨 fn/类型剥离/模块位/同构 Stx/双 Reader parity ×4 形/无泄漏+块位边界/跨阶段 check ×8 正；项位 assign 拒收 run/check/Span/parity/模块位 ×5 + const mut ×2 + 单绑定 + 块位域外 ×2 + 结构族 ×5 + E0004 平表族 ×4 + 7 类错误覆盖 ×5 负）；增长签名锚重校准 215/504/247（+4 protos +10 consts +5 globals——reader.ktf payload 指纹）。
8. **语料迁移（D7）**：gc_stress 双件 `let keep` → `const keep`（真常量语义位——输出 parity 逐字节 ⇒ 5）+ examples README r161 注记。
9. **治理八件**：02 v7.29（toplevel_const 产生式）+ 20 v1.40（§14 第十六映射行）+ matrix 1916 + RELEASE r161 节 + t3plus v1.81 + TD-037 登记（跨值域相等中缀面缺口 P3 触发式——231-b 审计附带发现 `true == true` ⇒ E0004 实锤）+ 12-roadmap.md:570 顺修（「效应行收集 analyzer 既有」↔ EffectRow 实现零命中张力修正）+ 设计单源 v1.1 收口增补 + README 四处。

**GATE 1 实录**：六命令 clean 起步全绿{build 零告警 + check 0:0 + fmt --all 0 diff + clippy --workspace --all-targets -D warnings 0 + test --release --workspace **1916:0:0 净 +32**[RUST_MIN_STACK=33554432]} + 审计×6 EXIT 0 + CLI 零回归{fib ⇒ 144 / closures ⇒ 42 / higher_order ⇒ (1 4 9 16 25) / vector ⇒ 9 / match ⇒ fib-13 / gc_stress(const) ⇒ 5 / check fib 2/9/5/38} + 新面 E2E{const LIMIT = 5; LIMIT + 1 ⇒ 6 + 项位 assign 拒收 rc=1——r160 基线下 const ⇒ E0001 词法拒绝}；内循环 2 轮（实施 + 期望修正——print 末值 nil / 合成 define Span 关键字本位 r158 先例合法差异 / 同因第三处）。

**遗留债务**：无新增（TD-034 维持 P3 触发式——cache 富面休眠，唯一开放项；TD-037 新登记 P3 触发式——跨值域相等中缀面缺口{三选一裁定待用户：== 扩域 / eq 中缀化 / 诚实边界维持}）。

---

## r160 —— TD-036 元组表达式形窗：`(a, b)` pair 构造现代面 + 构造⟺解构对称缺口闭合 + 语料 pair 构造位现代化（1852 → 1884 净 +32 数据结构表面窗）

> M1 指令开窗第六十五例（用户四链指令——①「审查并整理当前项目详细状态和情况……语法核心目标语言表示，现代前沿的目标语言语法对 S 表达式的替换等（**如当前目标语言中的逻辑处理，比较处理，等等运算符设计实现，基础内置函数、内置基本类型、数据类型、数据结构、非内置基本类型、非内置基本数据结构等……S 表达式旧时代的内容……应该通过目标语言自身设计实现**）②继续推进目标语言设计的实现窗[遇缺陷直接推进] ③按 sop.md 流程结合 lang-design 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 ④打包 + web 同步）。TD-036 触发条件①兑现（用户指令直接开窗——数据结构面现代化——r159 / 229-c 登记）。

**窗口定位**：r159 运算符面审计（§20.3 15 行）+ TD-036 登记的数据结构面对称缺口——match 模式位 `(p, q)` pair 解构形自 r121 起即为现代面，而表达式位构造形缺位（r159 基线实测 `(1, 2)` ⇒ E0001 fail-closed），用户被迫回落 `cons(a, b)` Lisp 时代调用形（match.ktf `describe(cons(1, 9))` 语料实录——解构用现代形、构造用旧形的同函数两面割裂）。本窗补齐 `primary → "(" expr "," expr ")"` 元组表达式产生式（第十五皮肤映射，as-if-written `cons(a, b)`——皮肤换、骨架不变），TD-036 清偿关闭。设计单源：`docs/develop/v0/stage-3/tuple-expression-design.md` v1.0（D1-D10 + §1 机制确认 + §3 域外表）。

**交付要点**：
1. **机制确认（§1——零下游变更实锤）**：cons 注册链完整既有{N1_CORE_NAMES + register_globals + BUILTIN_SIGS `(Any, Any) → Pair` + check.ktf TC_SIGS + anf native PoC}——as-if-written 脱糖路径全链既有消费；HM 已知 cons 产 Pair 型{`1 + cons(2, 3)` ⇒ E0005 实证}；语句位 LParen 分派既有{parse_stmt_or_expr 兜底臂}；
2. **D1-D10 十裁定**：二元 pair 构造产生式{primary 位——r138 vector 同族位纪律} + as-if-written 合成{Reader 直接产 `(cons e₁ e₂)`——r158 define 合成先例} + 二元封顶 D2{模式位 r121 裁定镜像——3+ 元 fail-closed 专用诊断「at most two elements in a tuple expression」} + 分组/Unit 维持 D3 + 尾逗号 fail-closed D4{r138 同律} + cons 调用形维持 D5{内核聚合基座名 + list 链惯用形——能力补齐非退役} + HM/check 零变更 D6{零注册链增量} + 双 Reader 错误面字节级 parity D7 + 语料迁移 D8{离散 pair 构造位迁移 + list 链惯用形维持} + Span 契约 D10{合成 cons 符号 = `(` Token 本位——r158 合成 define 先例}；
3. **Reader 双侧（230-c1/c2）**：种子 reader.rs parse_primary LParen 逗号臂{parse_expr 后 Comma 检查分流：尾逗号 fail-closed → 第二元素 → 3 元封顶检查 → 合成 `(cons e₁ e₂)`} + 镜像 reader.ktf parse_tuple_tail 函数{`(` 臂 p_kind "," 分流——nd_lst(cons(nd_sym("cons", s, e), ...)) 同构}；错误面消息+Span 字节级 parity（3 元封顶 / 尾逗号 / 自然失败面 EOF 族）；
4. **新测试电池（230-c3）**：ktf_tuple_expr_tests 32 case[8 正 + 24 负 1:3]——核心 E2E{`(1, 2)` ⇒ (1 . 2) + head/tail + 字符串对} + 构造⟺解构对称{`match (1, 2) { (a, b) => a + b }` ⇒ 3 + 嵌套 `((1, 2), 3)` ⇒ 6 + 守卫} + **as-if-written 字节码全等门**{`(1, 2)` ↔ `cons(1, 2)` disassembly Span 剥离后逐字节全等——r133 全等门先例 + 嵌套形} + 全位置形{let 值/实参/if 值臂/match 检查位/嵌套元组/语句位/closure 体/handle protected——r143 五位置形先例} + 双 Reader 正典渲染 parity{含 Span 字节} + check 跨阶段消费{HM cons 签名零诊断} + 分组/Unit 零回归 + 语料迁移复锚{describe 三臂 + gc churn} + 负例 7 类 ≥6 覆盖{E0001×8 + E0004×2 + E0022×3 + E0005×3[recovery-mode] + E0006 + E0014 + 模式位回归锚 + Span 契约×2 + 双 Reader 错误面 parity×3——E0002 无自然面如实申报}；
5. **增长签名锚重校准**：reader.ktf payload 210→211 protos / 491→494 consts / 241→242 globals{单函数增量指纹 +1/+3/+1——r158 parse_toplevel_let 同型}——payload_full_shape_anchor 同轮更新；
6. **语料现代化（230-c4——用户面 only）**：match.ktf `describe(cons(1, 9))` → `describe((1, 9))`{构造⟺解构对称的语料闭环} + gc_stress.ktf / gc_stress_nontail.ktf 离散 pair 构造位 15 处{`cons(1, 2);` → `(1, 2);`——GC 压力形态不变}；**list 链惯用形维持**{effect_stress `cons(n, mk(n-1))` / higher_order cons 链 / vector `cons(n, ())`——链式构造 = list 惯用法非 pair 构造}；examples/README v0.2.2 三行注记；输出 parity 逐字节实证{match ⇒ fib-13 / gc_stress ⇒ 5 / gc_stress_nontail ⇒ 5}；
7. **治理回写（230-d）**：02-syntax-model v7.28{§8.13.1a tuple_expr 产生式——primary_expr ::= ... | tuple_expr} + 20-surface-conventions v1.39{§14 皮肤字典第十五映射行} + 18-terminology 复核{构造⟺解构对称词条核对——无术语表增量} + matrix r160 行{净 +32 = 1852 → 1884} + RELEASE r160 节{本节} + t3plus v1.80{14 行零变化——数据结构表面非 T3+ 行} + **TD-036 清偿关闭**{tech-debt-register 清偿记录} + tuple-expression-design v1.0 Closed{GATE 1 实录回填}；
8. **GATE 1（230-d）**：六命令 clean 起步全绿{build 零告警 + check 0:0 + fmt --all 0 diff + clippy --workspace --all-targets -D warnings 0 + test --release --workspace **1884:0:0**[RUST_MIN_STACK=33554432——净 +32]} + 审计×6 真实 EXIT 0 ×6 + CLI 零回归探针{fib ⇒ 144 / closures ⇒ 42 / higher_order ⇒ (1 4 9 16 25) / vector ⇒ 9} + 新面 E2E{`(1, 2)` ⇒ (1 . 2)——r159 基线下 E0001}。

**8 原语不变性第四十二轮**（零新原语零通道零 IR/操作码零 expander/compiler/HM/VM 机制变更——Reader 合成既有核心形，原则 31 皮肤换骨架不变）；14 行触发族判定零变化（t3plus v1.80——数据结构表面非 T3+ 行）；**TD-036 清偿关闭**（余留 TD-034 唯一开放项）；1884 基线自 r160 起；内循环轮次 2（实施 + 测试期望修正循环）；委员会投票随收口笔（230-e）；web 同步 + §19 打包随收口腿（230-e）。

## r159 —— 运算符面完备性清偿窗：`%` 中缀主名注册链闭合 + `mod` 别名维持 + 运算符面全量对账审计 + 语料现代化（1820 → 1852 净 +32 运算符注册面窗；前置恢复腿 r158 权威包单源恢复）

> M1 指令开窗第六十四例（用户四链指令——①「审查并整理当前项目详细状态……语法核心目标语言表示，现代前沿的目标语言语法对 S 表达式的替换等（**如当前目标语言中的逻辑处理，比较处理，等等运算符设计实现，基础内置函数、数据类型、数据结构、基本类型、基本数据结构等——这在目标语言中不应该使用和出现吧？他就是 S 表达式旧时代的内容**），EBNF 语法审查，闭包函数 EBNF 语法审查重选筛选」②继续推进目标语言设计的实现窗[遇缺陷直接推进] ③按 sop.md 推荐序推进 ④打包 + web 同步）。前置恢复腿（229-a）：z.ai web 保存机制第七次回退恢复——kerf-v1.0.0-r158-toplevellet-1820tests.tar.gz 单源解包替换（保 .git；sha256 709d574d 与 228-e 记录逐位一致）+ Rust 1.98.1 工具链第七次重装 + GATE 1 恢复验收全绿（六命令 + test --workspace 1820:0:0 + 审计×6 EXIT 0 + CLI 探针零回归）+ commit 0980b96。

**窗口定位**：用户指令①运算符面审查经 §20.3 同类路径全量审计发现 **`%` 断链 P1**——EBNF Level 0 定稿的项级中缀 `n % 2`（02 §8.13 term 级 `"*" | "/" | "%"`）在 Reader 双侧俱已解析为 `(% n 2)`，但注册链（N1 核心面 / 内建全局 / 双侧 HM 签名表 / QBE ANF 原语映射）只注册了 `mod` 调用形——现代主面 E0022 断链（CLI 实证 `7 % 2` ⇒ rc=1 unbound），用户被迫使用 S-expr 旧时代 `mod(n, 2)` 调用形（higher_order.ktf 语料实录）。本窗闭合注册链并以 `mod` 别名维持旧面。设计单源：`docs/develop/v0/stage-3/operator-surface-parity-design.md` v1.0（§1 审计表 15 行 + D1-D8 + §3 域外表）。

**交付要点**：
1. **同类路径全量审计（§20.3 / §20.6）**：reader.rs 解析链消费的全部运算符 Token → Stx 符号 → 注册链三列对账 15 行——逻辑（`&&`/`||`/`!` → and/or/not 核心形）✅、比较（`==`/`!=`/`<`/`>`/`<=`/`>=`）✅、算术（`+`/`-`/`*`/`/`）✅ 俱现代中缀形注册链完整；**`%` 唯一断链（本窗修复）**；位运算 `| ^ & << >>` / `..` / `as` / `.` / `[e]` / `|>` 俱 EBNF Level 0 ○ 登记态（词法未收——fail-closed 实证 `1 | 2` ⇒ E0001）；
2. **`%` 注册链五点（D2）**：register_globals defs 行（`("%", arith_builtin("%", Fold::Mod, 2))`）+ N1_CORE_NAMES（40→41——E0022 可见面单源 verify_unbound_refs 直连）+ BUILTIN_SIGS（62→63——Rust HM 签名表）+ families 测试锚 + check.ktf TC_SIGS 行（bootstrap HM 镜像——r140 TC-SIGS oracle parity 族同轮锁定）；**native PoC 面（D3）**：anf.rs `"%" => APrim::Mod`（CLI 实证 `8 % 3` ⇒ exit 2 同 `mod(8, 3)`——值 = exit code 约定实证）；
3. **主名/别名裁定（D1）**：`%` = EBNF Level 0 定稿主名；`mod` = S-expr 旧时代调用形**别名维持**——种子域 .ktf 七件 + 测试语料零扰动（自举链字节码 parity 锚保护）+ 「`+`/`-`/`*`/`/` 俱符号名内建而 `mod` 为唯一词名算术内建」的历史不一致由本窗收敛为别名；不退役 `mod`（退役 = 种子语料强迁 = bootstrap 字节码扰动 + 60+ 处测试锚翻转——收益不成比例，登记态维持）；
4. **语料现代化（D4——用户面 only）**：higher_order.ktf `mod(n, 2) == 0` → `n % 2 == 0`；vector.ktf `do(cons(n, ()), churn(n - 1))` → `cons(n, ()); churn(n - 1)` 块语句序列（D42 同构——尾项 = 尾值；输出 parity 逐字节实证 `(1 4 9 16 25)` / `9` 保持）；**种子七件不动**；
5. **计数锚全域更新（D5——8 处）**：N1 40→41（e5close 审计 P08 + builtins 测试）/ flat 62→63（n1_core_and_module_flats_closed + ktf_read_line_sig_tests::p07）/ 授权面 114→115（×2 测试）/ 零授权面 102→103 / BUILTIN_SIGS 63 注记 ×3 / tc_sigs 注记；
6. **新测试电池（D6）**：ktf_percent_operator_tests 32 case[8 正 + 24 负 1:3]——E2E 绑定闭合 + 优先级/结合律（左结合实证 `10 % 3 % 2` ⇒ 1）+ 有符号操作数语义族（截断余数 `-7 % 3` ⇒ -1）+ 别名值等价 + 双 Reader 正典渲染/错误面字节级 parity + 同核心形 `(% 7 2)` 机器锚 + check 跨阶段消费 + 语料迁移复锚（is_even + D42 do→块同构双形等值）+ 负例 7 类错误覆盖（E0001×7 形态 / E0004×7 域错含 float/bool/string/零除/arity / E0022×4 / E0005×3 / E0006 / E0014 / Read parity 面）；
7. **治理回写（D8）**：02-syntax-model v7.27{term 级 `%` 实施状态注记——EBNF 定稿与注册链对账} + 20-surface-conventions v1.38{§14 皮肤字典运算符行——`%` 主名 + `mod` 别名} + matrix r159 行{净 +32 = 1820 → 1852} + RELEASE r159 节{本节} + t3plus v1.79{14 行零变化——运算符注册面非 T3+ 行} + TD-036 登记{元组表达式形 pair 构造现代面——P3 触发式} + operator-surface-parity-design v1.0 Closed + 18-terminology 复核{mod ↔ % 别名——「一个概念两个面」沿 r102 命名谱系，无术语表增量}；
8. **GATE 1（229-verify）**：六命令 clean 起步全绿{build 19.50s 零告警 + check 0:0 + fmt --all 0 diff + clippy --workspace --all-targets -D warnings 0 + test --release --workspace **1852:0:0**[RUST_MIN_STACK=33554432——24 test binary 族]} + 审计×6 真实 EXIT 0 ×6 + CLI 零回归探针{fib.ktf ⇒ 144 / closures.ktf ⇒ 42 / higher_order.ktf ⇒ `(1 4 9 16 25)` / vector.ktf ⇒ 9 迁移后逐字节保持} + 新面 E2E{`7 % 2` ⇒ 1 rc=0——r158 基线下 E0022 rc=1} + native PoC{`8 % 3` ⇒ exit 2} + 双 HM 面正负探针{check `n % 2` 诊断零 + `"a" % 2` E0005 浮出}。

**8 原语不变性第四十一轮**（零新原语零通道零 IR/操作码零 expander/compiler/HM/VM 机制变更——`%` 为内建函数注册，r138 vector 五内建族同型先例：N1 面扩容 ≠ 原语增量；原则 31 皮肤换骨架不变——本窗连皮肤都未换，补的是消费者注册链）；14 行触发族判定零变化（t3plus v1.79——运算符注册面非 T3+ 行）；TD-034 维持 + **TD-036 新登记**（元组表达式形 pair 构造现代面——P3 触发式）；1820 基线一轮后运算符面增量窗；内循环轮次 2（实施 + 计数锚修复循环）；委员会投票随收口笔（229-close——注册面窗 r138/r144 同族先例「验收即兑付」）；web 同步 + §19 打包随收口腿（229-d）。

## r158 —— 顶层 let 现代化窗：S-expr 旧时代 `define(NAME, e)` 项位调用形退役 + toplevel_let 产生式就位 + 闭包 EBNF 复审维持（1788 → 1820 净 +32 语言表面窗）

> M1 指令开窗第六十三例（用户四链指令——①「审查并整理当前项目详细状态和情况……语法核心目标语言表示，现代前沿的目标语言语法对 S 表达式的替换等（**如 define 这在目标语言中不应该使用和出现吧？他就是 S 表达式旧时代的内容**，并同时检查当前项目中是否还存在类似或 S 表达式旧时代相关习惯或内容），EBNF 语法审查，闭包函数 EBNF 语法审查重选筛选（语法形式是否太过繁杂？当然也需要语义清晰）」②继续推进目标语言设计的实现窗 ③按 sop.md 推荐序推进 ④打包 + web 同步）。

**窗口定位**：r156-r157 已清偿代码面/README/web/设计文档后，用户指令①明示 `define` 调用形 = S-expr 旧时代内容不应出现在目标语言——**目标表面语法本体**的最后一件旧时代残留（「one face, one name」轨迹第五步：目标面 `define(NAME, e);` 项位调用形退役）。闭包 EBNF 复审（用户指令①「重选筛选」）同窗承载——四候选对照后维持现行形。设计单源：`docs/develop/v0/stage-3/toplevel-let-design.md` v1.0（D1-D10 裁定 + §1 残留全域盘点 512 处 + §2 K-1 闭包复审维持裁定）。

**交付要点**：
1. **方案单源（228-b）**：toplevel-let-design.md v1.0——残留全域盘点{bootstrap 七件 136 + examples 四件 9 + tests 42 文件 362 + web 预设 ~7 = 512 处} + D1-D10 十裁定{顶层 let 产生式 / define 项位退役拒收 / 双 Reader 锁步 / R4 工具纪律 / 原则 31 皮肤换骨架不变 / 闭包复审 K-1 / 32 case 电池 / 治理八件 / web 五件 / §19 打包} + 不变量五条 + 域外表；
2. **Reader 双侧（228-c）**：种子 reader.rs parse_item 增两臂——`Tk::KwLet → parse_toplevel_let`{`let name [: T] = e;` → `(define name e')`——mut/类型标注解析后剥离[fn_decl 先例]；单绑定封顶[逗号 fail-closed 专用诊断]；项位 = 顶层 + module 项位} + `Tk::Ident("define") + (LParen|Unit) 前瞻 → 退役诊断`{「the define call form is retired: use a top-level let binding (let name = value;) instead」——Span = define Token 本位[r130 先例]；Unit 前瞻 = `define()` 零参形[parse_typed_params 双关先例——define_misuse 失败驱动发现]}；镜像 reader.ktf 锁步{parse_toplevel_let 共享 parse_let_binder + 同诊断字节级 parity}；**零 expander/compiler/HM/VM 触碰**{8 原语不变性第四十轮——被退役调用形经统一 list 结构合成的同一核心形 (define name value)，皮肤换、骨架不变}；
3. **语料迁移（228-c，R4 两遍工具）**：`scripts/r158-toplevel-let/`{apply.py 括号配对 + 项位判别[括号栈反向分类 module/fn/block + 表达式位括号深度 + 宿主串解码-变换-再编码 + 反引号支持] + semipass.py 分号补齐[旧调用形可选分号产物——括号深度 + 花括号配对 + 转义感知] + README}——bootstrap 七件 136 处 + examples 四件 9 处 + tests 42 文件 ~380 处 + web 预设 7 处 + 函数糖形手工迁移两例{`define(make(), e)` → `fn make() { e }`——use_decl/member_rename 正例}；
4. **新测试电池（228-c）**：ktf_toplevel_let_tests 32 case[8 正 + 24 负 1:3]——run 面 E2E{closures 迁移复锚 ⇒ 42} + 双 Reader 正典渲染/错误面字节级 parity + 同 Stx 断言{(define name value) 三元核心形机器锚} + check 跨阶段 + 项位拒收 ×3 路径{run/check/reader+Span} + module 项位 + 单绑定封顶 + 7 类错误覆盖{E0001/E0002/E0005{恢复模式双诊断}/E0006/E0014{限定名导出面}/块位域外/Read 退役面} + 顶层 do-拼接合法锚{表达式位域外维持——块位/函数体位 expander 拒收域}；
5. **存量锚重校准 20 测试族**：parity_err_core_forms 3 case 移除{项位族 Reader 前置} + let_misuse 1 case 移除{顶层 let 合法化} + namespace 族 8 锚翻转{takeover 豁免→拒收双断言 + 保留字 5 锚分号 + d48/s1 语境} + negative_expander define_misuse 5 case 重面化{Read 退役面} + expander_error_rendering_shape E0002 锚改造 + seed_ktf 2 锚翻转{截断/单参形→退役诊断} + multi_error 位置重校准{[19,57]→[16,51]——现代绑定前缀字节移位} + payload 形状锚重校准{209/488/240 → 210/491/241——镜像新函数} + tc_sigs 原始字符串手工补全{apply/semipass 原始串边界局限——两件 define 补迁 + 两处半插入损坏回退} + 58 处 `;}` 误插入回退{semipass 花括号配对缺陷——闭包体 `{ x ;}` 形}；
6. **闭包 EBNF 复审维持裁定 K-1（用户指令②「重选筛选」）**：四候选对照{现行 `|| (params) -> eff { body }` vs Rust 单竖线 `|x|`[位或 `|` 词法冲突——bitor_expr 既有] vs JS 箭头 `(x) =>`[match 臂 `=>` Token 冲突 + 裸参位三重歧义] vs Swift in 形 `{ x in }`[裸块/struct_lit 位形冲突]}——现行形四判据胜出：零关键字{`||` 纯词法前缀 E0020 零占用} + fn_decl 同构{params→effects→block 一族两形} + r157 E-3 逐位一致实证 + 32 case 门成熟；**结论：形式不繁杂——四可选层各承独立语义，无可削减层，语义清晰度由 fn_decl 同构保证——零变更，登记复审结论即兑付**；
7. **治理回写（228-d）**：02-syntax-model v7.26{§8.13.1a toplevel_let 产生式 + §8.12 D2 映射表 define 行分裂} + 20-surface-conventions v1.37{§14 皮肤字典顶层值绑定行翻转} + matrix r158 行{净 +32 = 1788 → 1820} + RELEASE r158 节{本节} + t3plus v1.78{14 行零变化} + 18-terminology 复核{define 核心形 = 内部/S-expr 面本名维持} + toplevel-let-design v1.1 Closed；
8. **GATE 1（228-verify）**：六命令全绿{build 零告警 + check 0:0 + fmt 零 diff + clippy -D warnings 0 + test --workspace **1820:0:0**[RUST_MIN_STACK=33554432]} + CLI 零回归探针{closures.ktf ⇒ 42 / fib.ktf ⇒ 144 逐字节保持}。

**8 原语不变性第四十轮**（expander/compiler/HM/VM 零触碰——皮肤换骨架不变，原则 31）；14 行触发族判定零变化（t3plus v1.78——本轮开用户指令窗非 T3+ 行）；TD-034 维持（P3 触发式——cache 富面休眠——唯一开放项）；1788 基线五轮后首个语言表面增量窗（r154-r157 零增量维持后 +32）；内循环轮次 2（实施 + 修复循环）；委员会投票随收口笔（228-close）；web 五件同步 + §19 打包随收口腿（228-e）。

## r157 —— 设计文档 S-expr 时代残留清偿窗 + EBNF Level 0 审查：lang-design 24 件现行面收口 + fn_decl 漂移修正 + 闭包 `||` 终选确认（1788 → 1788 零增量纯文档轮）

> M1 指令开窗第六十二例（用户四链指令——①「深度审查项目中是否存在遗留旧时代的编码方式和内容（全面转向现代前沿理论表示，**包括目标语言中的设计和内容是否存在和转化**）……当前目标语言中遗留的 S 表达式相关结构或表现等，语法核心目标语言表示，现代前沿的目标语言语法对 S 表达式的替换等，**EBNF 语法审查，闭包函数 EBNF 语法审查重选筛选**」）。上一会话实施中途上下文耗尽（227-a..227-b3 已落未提交），本会话 PHASE 1 实况核实后收口续作（227-verify/d/e/close 收口笔）。

**窗口定位**：r156 已清偿代码面 + README + web 后，用户指令①明示「目标语言中的设计和内容」= **lang-design/ 设计文档 24 件的现行面**收口（「one face, one name」轨迹第四步：代码面 → README → web → 设计文档）；同窗承载用户指令①的「EBNF 语法审查 + 闭包函数 EBNF 语法审查重选筛选」。设计单源：`docs/develop/v0/stage-3/design-docs-modernization-plan.md` v1.0（D1-D8 裁定 + §2 残留全量盘点 175 处三判据分流 J1/J2/J3 + §3 EBNF Level 0 审查三发现 + §3.4 46 行审计表）。

**交付要点**：
1. **方案单源（227-a）**：design-docs-modernization-plan.md v1.0——残留全量盘点{24 件正文扫描 175 处命中——排除版本头历史行} + 分流三判据{J1 历史记述 KEEP / J2 Stx 内核形 KEEP+桥 / J3 用户面退役形 UPDATE} + KEEP 面清单八条{版本头/D 表族/皮肤字典 §14/Level 1-4/EBNF v9 本体/06 规则形状/14 Racket 对照/01 数学推导}；
2. **U1 现行文件名 .krf→.ktf（227-b1）**：×10 项 16 引用点——现行命令/验证/机制表述中的文件引用{04 bench 命令行 + 05 测试锚 ×3 + 06 验证矩阵 ×5 + 09 自举 Reader 行 + 20 preamble 定位/§6.5 引导语料清单/闭合守卫 + 22 R-N6 核验行 + 03 生产侧状态双行}——历史窗记述中的 .krf 俱按时点实况 KEEP（D3 现行实体界）；
3. **U2 lambda 时名清偿 + Stx 记号桥（227-b2）**：06-operational L1 规则 `(lambda (x₁…xₙ) e)` → `(fn (x₁…xₙ) e)`{r43 后内核关键字面——assign/do 已现代唯 lambda 漏面} + §2 规则族头部 Stx 记号桥{六映射现代形对照：`(fn (x) e)` ↔ `fn (x) { e }` / `|| (x) { e }`；`(assign x v)` ↔ `x = v;`；`(let ((x v)) b)` ↔ `let x = v; b`——01 §2 + 20 §14 双锚} + R1 gloss 顺修{防 L1 修复后同规则块自相矛盾}；规则展示位退役关键字 lambda 归零（余 7 处俱历史/时名/数学记法 KEEP 逐处判定在案）；
4. **U3 用户面声明形记号桥（227-b1）**：×6——节头/表头最小侵入{20 §5.2 import/require 双面 + 22 R-N2 表头 + 22 §5.2 红线区 + 21 §4.1 授权三态表} + 行级双面记法 ×2{09 print 行 `require io, write;`（内核形 `(require io write)`） + 01 §6 require 形式文法用户面形句}——零行级改写原则（D5 最小侵入）；
5. **EBNF Level 0 审查（227-b3）**：**46 行全产生式审计表**{≥30 目标超额——逐产生式 EBNF 位置 × reader.rs 实施锚[函数:行] × 实施状态[✅34 / ◐5 / ○7] × 漂移裁定四列对账 + 十四级优先级表抽查 4 级}：**E-1 fn_decl 返回签名漂移修正**{02:544 `"->" effect_union` 必选 → `[ "->" effect_union ]` 可选——parse_fn_decl :1523 可选臂 + 语料双形实证 fib.ktf 带/closures.ktf 不带——R4 文档随代码} + E-2 move 前缀宽松面注记{02:631-632——任意 unary 位受理且剥离} + 宽松面注记 ×2{perform 括号可省 #29 + item 内核超集 #46——语料正典不破坏 EBNF 所述形态} + **E-3 closure_expr 逐位一致实证 + `||` 终选确认**{EBNF ↔ parse_closure_body ↔ closures.ktf/higher_order.ktf 三方零偏差；备选①fn 表达式形拒绝[声明族关键字位冲突] + 备选②Rust 风 `|x|` 拒绝[`|` 保留 Token——match or 模式/effect_union 既有消费位——例 3/18 二义性预防词法根基]——EBNF v9 定稿维持零修正义务} + char_literal 无 Token 登记态注记 + match 基座臂体愿景行增补位正源注记 + U4 已删锚历史注记{02:241 'x 简写随 .krf 面退役 r153/r154 E6——现代面符号字面量 = quote(sym) 调用形}；
6. **死链修复 + KEEP 面零漂移**：02 五处 `../../develop/` → `../develop/`{227-b1 偏差 2 同律——docs/lang-design/ 一层上溯即 docs/develop/}——499 相对链接机器校验零死链{唯一命中 06:336 `[A,B](R)` 为量子对易子数学记法非链接}；KEEP 面区域级零触碰{20 §14 皮肤字典@300+ / 22 D 表族@246+ / 02 §8.5-§8.12@360-499 / §8.13.2a@1098 / §8.14@1109} + 版本头 prepend 保形 10 件机器校验 ALL OK；
7. **GATE 1（227-verify 收口复验）**：六命令 clean 起步全绿{build 20.21s 零告警 + check 0:0 + fmt 零 diff + clippy -D warnings 0 + test --workspace **1788:0:0 逐位保持**[RUST_MIN_STACK=33554432——24 test binary 族]} + 审计×6 真实 EXIT 0 ×6{41+50+53+46+43+47 case} + CLI 零回归八探针{fib 75025/⇒144 + check ok + .krf 拒收 exit 2 三短语逐词命中 + tokens + test PASS + bench 76.361ms 带内 + multiarm ⇒ 217 + nested_resume ⇒ 540}。

**8 原语不变性第三十九轮**（纯文档轮零代码变更零机制变更零新原语零通道——零 .rs 触碰）；14 行触发族判定零变化（本轮开用户指令窗非 T3+ 行——t3plus v1.77 消费注记）；TD-034 维持（P3 触发式——cache 富面休眠——唯一开放项）；1788 基线第四轮（r154-r157）；内循环轮次 2（227-a..b3 首会话 + 本会话收口笔）；委员会投票随收口笔（227-close——纯文档轮 r104/r155/r156 同族先例）；下一演进 = 触发式零信号维持或自然信号（按用户指令序或 t3plus 推荐序）。

## r156 —— 旧时代残留清偿窗（TD-035 Batch 2 行权）：Tier-3 残响退役 + S-expr 时代术语现代化 + README 完全重构（1788 → 1788 零增量纯重命名+文本轮）

> M1 指令开窗第六十一例（用户四链指令——①「深度审查项目中是否存在遗留旧时代的编码方式和内容（全面转向现代前沿理论表示……S 表达式相关结构或表现等）+ 完全重构 readme 文件和 web」= TD-035 触发条件①{用户指令直接开窗}）。

**窗口定位**：r155 Batch 1 生产面清偿后，「target」限定词与 S-expr 时代词汇的残响面（测试局部名 Tier 3 + 注释指称失真 + 消息文本时代措辞）按 TD-035 触发式登记待清——本轮用户指令直接开窗行权全量清偿，并携用户明示扩展面（README 完全重构 + 演进叙事对账）。设计单源：`docs/develop/v0/stage-3/legacy-residue-clearance-plan.md` v1.0（D1-D8 裁定 + §2 S-expr 演进叙事对账单源 + 残留全量盘点表）。

**交付要点**：
1. **方案单源（226-a）**：legacy-residue-clearance-plan.md v1.0——残留全量盘点表{八类：.krf = 0 / S-expr 标识符 = 0 / Tier-3 局部名 ~127 点 / 生产私有 fn 逃逸名 3 / 注释字样 108 / 消息文本 2 / README 1 / web 五件} + §2 S-expr 演进叙事对账单源{四层钉死：皮肤层唯一后继 + IR 层冻结内核非残留 + 工程层五批六轮轨迹 + 余响层本窗对象——「换脸保核」认知框架} + D1-D8 裁定；
2. **Tier-3 局部名退役（226-b）**：113 点/13 文件——`target_value`→`run_value` ×80{10 测试文件} + `assert_target_reader_stx/err_parity`→`assert_reader_stx/err_parity` ×20{switch_corpus_parity_tests} + `target_err_form`→`read_error_form` ×3{bootstrap/reader.rs 生产私有 fn——Batch 1 逃逸名} + `neg_target_*`→`neg_*` ×5{ktf_vector_value_tests} + `hm_target`→`hm_check` ×2{hm_inference_tests} + `seed_front_target`→`seed_front_reader` ×2{bootstrap_compiler_tests——冲突实锤：既有 fn seed_front 备选名} + `sexpr_source_in_target_entry_rejected`→`retired_sexpr_entry_rejected` ×1{历史可溯值新名保形——体注 r153 收敛语义保持} + `ktf_corpus_fixpoint_target_syntax_self_compiles`→`ktf_corpus_fixpoint_self_compiles` ×1{单点裁定}；域外残留如实申报{parity_target/target_outcome/READER_TARGET 常量族/neg_match_pattern_vector_target——俱不在 D2 字典}；
3. **注释时代术语现代化（226-c）**：「seed target Reader」→「seed Reader」 ×11 + 「target-Reader bridge」→「reader bridge」 ×~24 + main.rs/reader.rs/driver.rs/bootstrap 族模块头注现行机制指称修正 ~8 处{「target-syntax face」→「.ktf face (kerf syntax)」等} + bootstrap 错误标签两处{「(seed pipeline·target syntax)」→「(seed pipeline)」}——历史转换注记（E6 close-out 头注族）全保持{§8.6 只追加纪律}；
4. **消息文本现代化（226-d）**：两处——.krf 拒收诊断「...is not a .ktf target-syntax file...」→「...is not a .ktf kerf source file; the S-expression surface is retired (r153)...」 + usage 行「.ktf target syntax (single face...)」→「.ktf kerf syntax (single face...)」；锚宽松验证过：cli_entry_convergence_tests 断言面 contains("retired")&&contains(".ktf") 双词俱含——零断言改动实测复跑；
5. **README 完全重构（226-e）**：S-expr 旧展示（fib.krf + define-syntax）全换现代 kerf 语法展示{真实语料库取材} + 新增演进叙事段{S-expr→现代语法「换脸保核」+ one face, one name 轨迹} + 质量状态表 + 文档索引——历史信息零删除{压缩至治理文档既有承载：matrix 增量行族 + RELEASE r-* 节}；
6. **GATE 1（226-f）**：六命令 clean 起步全绿{build 零告警 + check 0:0 + fmt 零 diff + clippy -D warnings 0 + test --workspace **1788:0:0 逐位保持**[RUST_MIN_STACK=33554432]} + 审计×6 真实 EXIT 0 ×6{41+50+53+46+43+47 case} + CLI 零回归八探针{fib 75025/⇒144 + check ok + .krf 拒收 exit 2 新消息三短语逐词命中 + tokens + test PASS + bench 75.826ms 带内 + multiarm ⇒ 217 + nested_resume ⇒ 540} + 残留 grep 双归零。

**8 原语不变性第三十八轮**（纯重命名+文本轮零机制变更零新原语零通道）；14 行触发族判定零变化（本轮开 TD-035 窗非 T3+ 行）；**TD-035 清偿关闭**（Batch 1 = r155 生产面 + Batch 2 = r156 残响面——TD-register 清偿记录 + naming-standardization-plan Closed + legacy-residue-clearance-plan Closed 承载）；TD-034 维持（P3 触发式——cache 富面休眠）；1788 基线第三轮（r154-r156）；内循环轮次 1；委员会投票随收口笔（纯重命名+文本轮——r155 先例「验收即兑付」口径候选，最终由主代理收口笔定）；下一演进 = 触发式零信号维持或自然信号（按用户指令序或 t3plus 推荐序）。

## r155 —— 命名标准化窗 Batch 1（生产面「target」限定词退役）：one face, one name 轨迹完成步（1788 → 1788 零增量纯重命名轮）

> M1 指令开窗第六十例（用户四链指令——①审查全项目命名精确标准化[用户明示「kerf_driver/src/bootstrap/target_reader.rs 直接命名为 reader.rs 难道不好？」对称收敛方向] + ②继续推进目标语言设计的实现窗[自然信号开窗] + ③按 sop.md 流程推荐序推进 + ④同步完整打包 tar.gz + 同步完整更新 web page）。

**窗口定位**：r154 E6 收口批全闭后（S-expr 完全拆除窗终局——「one face, one name」裁定已对 `TargetReadError` 执行），「target」限定词在全部生产命名中失去辨义对象（双语法共存期的区分职能随 S-expr 面退役而消失）——本窗将该裁定推广至文件名/模块名/类型名/API 名全域。设计单源：`docs/develop/v0/stage-3/naming-standardization-plan.md` v1.0（D1-D8 裁定 + 不变量五条 + Tier 3 触发式登记）。

**交付要点**：
1. **文件重命名 ×2（git mv 保史）**：`kerf-reader/src/target.rs` → `reader.rs`（唯一 Reader 实现——crate/模块名精确自洽）+ `kerf-driver/src/bootstrap/target_reader.rs` → `reader.rs`（用户明示——与 `reader.ktf` 恢复 bootstrap 目录 X.ktf/X.rs 对称，其余八对俱对称唯本件破缺）；
2. **kerf-reader API 面**：`read_target_source` → `read_source`（S-expr 旧名 r154 退役——名位承接）+ `read_source_for_bootstrap` + `lex_for_parity` + `symbol_name`（原 target_symbol_name）+ `Parser`（原 TargetParser）+ `pub mod reader`；
3. **driver API 面**：`compile_source` / `compile_front` / `compile_front_seed` / `check_source_recover` / `run_source` / `run_source_seed` / `dump_tokens` / `dump_stx`（九族 `*_source_target`/`*_target` 限定词退役）+ CLI `is_ktf_path`（原 is_target_syntax——名从「语法时代辨义」转「文件形态辨义」）+ `run_test_case`（原 test_runner::run_target）；
4. **bootstrap 桥 + reader.ktf 锁步**：`TargetReaderState` → `ReaderState` + `load_reader`/`with_reader` + `lex_for_bootstrap`；reader.ktf `fn lex_target`/`fn parse_target` → `fn lex`/`fn parse`（Rust intern `"lex-target"`/`"parse-target"` → `"lex"`/`"parse"` 四处同步——fixpoint 门族自洽验证通过）；
5. **活性探针族**：`production_prelude_is_ktf_reader` / `seed_prelude_is_seed_reader` / `expander|compiler_bootstrap_is_ktf_corpus` / `PRELUDE_*_READS`；
6. **全域机械替换 ~1315 点**（80 文件——序敏感 sed：长名先短名后 + 词边界精确）；fmt 两处换行重排顺修（标识符变短行折叠）；
7. **保留面 D8**：`TargetTriple`/`supported_targets`/`collect_import_targets`（非语法时代语义——codegen/import 目标语义）+ 测试局部名 Tier 3（约 60 处 `hm_target`/`target_err`/`neg_target_*` 等——纯装饰性，触发式 Batch 2）+ 消息文本（断言锚——零文本变更不变量；`.krf` 退役诊断/编译器消息逐字节保持）；
8. **GATE 1**：六命令 clean 起步全绿（build 零告警 + check 0:0 + fmt 零 diff + clippy -D warnings 0 + test --workspace **1788:0:0 逐位保持**[RUST_MIN_STACK=33554432]）+ 审计×6 真实 EXIT 0 ×6 + CLI 零回归（run fib.ktf ⇒ 46368/75025 + check ok + .krf 拒收 exit 2 + tokens + test PASS + bench 76.583ms 带内[基线 77.308ms 同量级] + multiarm ⇒ 217 + nested_resume ⇒ 540）。

**8 原语不变性第三十七轮**（纯重命名零机制变更零新原语零通道）；14 行触发族判定零变化；TD-035 新登（Tier 3 命名批 2 + 消息文本现代化——P3 触发式）；1788 基线第二轮（r154-r155）；下一演进 = 触发式零信号维持或自然信号（Batch 2 触发式或用户指令序）。

## r154 —— S-expr 完全拆除窗 E6 收口批（终局清理）：S 表达式完全拆除窗全闭（2049 → 1788 净 -261 拆除轮合法收缩）

> M1 指令开窗第五十九例（用户四链指令——⓪r153 包恢复 + ①②③ 三链推进）。恢复轮 224-r：z.ai web 保存机制第七次回退恢复（r153 包单源解包替换——diff 归零实证 + 单笔 cf7f5c6 承载 r135-r153 增量）。

**批次定位**：r153 Batch D 全闭后按 s-expr-removal-plan §4 推荐序进入 E6 收口批——七件 .krf 平行件删除 + Rust S-expr Reader 拆除 + KRF_SOURCES→KTF_SOURCES 翻转 + compile_front_seed 退役 + target_reader.ktf → reader.ktf 单一收敛 + 文档终局回写。

**交付八件**：
1. **终局文件操作**：reader.ktf（S-expr Reader B3）退役删除 + target_reader.ktf 更名 reader.ktf（§11 单一 Reader 终局整合指令兑现——自举目录唯一 Reader 文件）+ 8 件 .krf 删除（七种子平行件 oracle + target_reader_lex.krf 提取件）——仓库 .krf = 0 实证（退出条件 1）；
2. **Rust S-expr 经典面拆除**：kerf-reader lexer.rs/parser.rs/token.rs 删除——target.rs 唯一 Reader 实现；ReadError 归一 THE face（TargetReadError 别名退役）；
3. **S-expr API 族 13 退役**：driver.rs compile_front/compile_front_cached/compile_front_seed/check_source(_recover)/compile_source(_seed)/run_source(_seed/_rendered)/dump_tokens/dump_stx/test_source + validator.rs（SyntaxTransitionValidator——职责完结）+ bootstrap/mod.rs S-expr 读桥全拆 + KTF_SOURCES 扩全 10 件（reader.ktf 承载 `->` 功能性豁免）+ E6 域内删除守卫新立；
4. **§20.3 同类路径审查新发现面清偿**：DERIVED_SOURCES（七糖内联 S-expr 宏定义文本——经典 Reader 最后活生产消费者，经 lexp-init-derived 注入 VM 自举 expander，未入拆除窗 §3 审计枚举{内联 Rust 字符串非 .krf 文件}）→ 程序化 Stx 构建转化（s/lit/lst 构建器 + 词法分类保真实证{bare true/false/nil = Bool/Nil 字面量——git 历史查证} + derived_definition_forms 单源导出）；
5. **加性 API**：run_source_seed_target（E6 oracle 职责目标面等价物——双路交叉检查承接）；cache 管线富面休眠（#[allow(dead_code)] + TD 登记——触发式 cache.ktf 键协议扩展）；
6. **测试面全域转换**：8 组件族删除（negative_reader/bootstrap_reader/switch_step5 + 5×krf_parity + reader_tests + target_reader_tests——职责完结）+ ~50 族内联语料目标语法化（stage0/1/2/3 全域——子代理 19 波次 224-b2..d6——承载裁定六条落注）+ 审计×6 转换（俱 EXIT 0）+ e6-conversion-guide.md 转换单源（stage-3/ 归档）；
7. **GATE 1**：六命令 clean 起步全绿（build 20.07s 零告警 + check 0:0 + fmt 零 diff + clippy -D warnings 0 + test 1788:0:0）+ 审计×6 真实 EXIT 0 ×6 + CLI 零回归（fib 75025/⇒144 + check ok + .krf 拒收 fail-closed + tokens + test PASS + multiarm 217 + nested_resume 540 + bench 77.308ms 带内）；
8. **E6 退出条件五项全兑现**：输入归零（仓库 .krf = 0 + CLI 拒收既存）+ Rust S-expr Reader 死代码归零 + parity 证据链全绿（fixpoint + 两路 + 删除守卫）+ 文档终局回写（plan v1.5 + 替换面图 §8.3 终态 + 07/12/20）+ 门审/投票。

**8 原语不变性第三十六轮**（纯拆除轮零机制变更零新原语零通道）；14 行触发族判定零变化；**S-expr 完全拆除窗全闭 ✅**（Batch A r149 + B r150 + C r151-r152 + D r153 + E6 r154——五批六轮全录）；1788 基线自 r154 起；下一演进 = 触发式零信号维持或自然信号。

## r153 —— S-expr 完全拆除窗 Batch D 用户面拆除（CLI 入口收敛 .ktf 单面 + reader.ktf 生产路径退役 + 语料 .krf 面清理 + 双入口测试族重构）：S-expr 用户面终局退役（2044 → 2049 净 +5）

> M1 指令开窗第五十八例（用户三链指令：①继续推进目标语言设计的实现窗[遇缺陷/未完成窗口按推荐顺序直接推进进入对应窗口具体实施] ②按 sop.md 流程结合 lang-design 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 ③同步完整打包 tar.gz + 同步完整更新 web page）。上一会话实施中途上下文耗尽（36 文件在场未提交）——本会话 PHASE 1 实况核实后按 s-expr-removal-plan §4 推荐序续作收口（§8.6 冲突检测：在场工作与 worklog「下一演进 = Batch D」一致——合法续作态）。

**批次定位**：r152 Batch C 全闭（Reader fixpoint 里程碑收口）后，按 s-expr-removal-plan.md §4 推荐序进入 Batch D——拆除对象 2（用户 S-expr 面）/3（reader.ktf 生产路径）/5（语料 .krf 面）的「用户面拆除」批；r125 双入口窗的共存期自此正式终。

**Batch D 实施**（223-a..223-c）：
- **CLI 入口收敛 .ktf 单面**（对象 2「扩展名分派规则翻转」）：main.rs is_target_syntax 分派语义翻转——精确 `.ktf` = 唯一生产入口，其余一切（.krf 真实文件/不存在路径/无扩展名/未知扩展名/大写 .KTF）经 reject_retired_syntax fail-closed 拒收（exit 2 + 结构化退役诊断：命名 r153/Batch D 基准 + 指引改写为 .ktf）；拒收发生于分派层先于文件读取（不可读/不存在的 .krf 路径亦报退役而非读取错误——负例族行为锚）；run/bench/anf/native/check/tokens/stx/test 全子命令收敛 target 单面；S-expr driver API（run_source/compile_source 等）自生产面退役（余消费者 = parity oracle 测试族——E6 收口批删除）；usage 文本单面声明；
- **reader.ktf 生产路径退役**（对象 3）：bootstrap/mod.rs + driver.rs 退役注记（oracle-of-record duty 单一化——compile_front 读段服务于 parity oracle 测试族直至 E6 删除；E6 后 target_reader.ktf 收敛为唯一 reader.ktf——s-expr-removal-plan v1.3 §11 终局整合指令维持）；
- **语料 .krf 面清理**（对象 5）：usage 15 对的 .krf 面全量删除（fib/closures/macros/higher_order/gc_stress/gc_stress_nontail/io/effect_stress/effect_handle_expr/effect_multiarm/effect_nested_resume/ffi/ffi_alias/match/vector——仓库余 .krf = 8 件：七件种子平行件 oracle + target_reader_lex.krf 抽取件，俱 E6 删除对象）+ examples/README v0.2.0 单面化（.krf 演示表退役——跨语法行为等价证据归档 RELEASE r127-r152；行内等价纪律由 cli_entry_convergence_tests 承载）；
- **双入口测试族重构**（门 D 载体）：cli_dual_entry_tests（530 行 22 case——r125 双入口窗遗产）删除 → **cli_entry_convergence_tests 新立（655 行 27 case——8 正 + 19 负）**：①跨语法行为等价（目标面 fib 经 run_source_target/check_source_target_recover/test_runner::run_target 全生产链 ↔ S-expr 库面 oracle——principle 31 皮肤/骨架同构）②CLI 边界收敛（编译二进制子进程实测：.ktf 受理 + .krf 五形全族 exit 2 + 退役诊断文本锚）③驱动 API 正交（文件名 = Span 标签非分派输入——收敛仅居于 CLI 分派层）④fail-closed 负例族（S-expr 源入目标入口/词法/文法/use 域外/展开诊断/HM 类型/运行时类型/恢复模式多错收集）+ 缓存裁定锚（目标面入口 cache-free 维持）；
- **十四测试族内联语料归档改写**：switch_corpus_parity/ktf_handle_multiarm/ktf_macros_corpus/ktf_nested_resume/ktf_read_line_sig/ktf_stress_corpus/ktf_tc_sigs_parity/hm_production_switch/hm_perf_evolution/effect_tests/hm_inference_tests/bootstrap_compiler_tests/qbe_backend_tests/capability_tests/typecheck_tests——已删除 .krf 语料的使用改读 .ktf 对应件或内联归档（「the retired X.krf corpus archived inline — r153 / 223-c」注记纪律）。

**门 D 三判据全绿**：CLI 单面零回归（fib ⇒75025/144 + check ok + effect_multiarm ⇒217 + nested_resume ⇒540 + closures ⇒42 + test 6/6 + tokens + match ⇒fib-13 + vector ⇒9 + higher_order ⇒(1 4 9 16 25) + bench 75.107ms 带内 + anf）+ .krf 拒收 fail-closed（EXIT 2 实测五路径）+ 语料 .ktf 单面全绿（1712 既有测试全量零回归）。

**GATE 1 全绿实测**：cargo clean → build --release 零告警 + check --all-targets 0:0 + fmt 零 diff + clippy --all-targets -D warnings 0 + test --release --workspace **2049:0:0 净 +5**（RUST_MIN_STACK=33554432——299 单元 + 1750 集成；净变动 = cli_entry_convergence 27 新立 − cli_dual_entry 22 删除）+ 审计×6 真实 EXIT 0（stage0/stage1/stage2_r1/stage2_r2/e5close/m3）+ CLI 单面十二路径 + bench 75.107ms 带内（r149-r152 带内 71.7-76.6；OBS-C <65ms 不满足维持——零信号）。内循环修正 3 处（clippy doc 列表缩进 12 + needless_borrow 1 + effect_stress 内联归档闭括号转写笔误 1——git show HEAD 对账定位）。

**治理对账**：matrix r153 增量行 + 总量行 2049 + RELEASE 本节 + README 两处（质量状态 + 打包交付）+ t3plus-trigger-audit v1.73（r153 消费注记——14 行触发族判定零变化）+ s-expr-removal-plan v1.4（§4 Batch D 行 ✅ + §12 对账节）+ 替换面图 §8.3 Batch D 进程注记 + examples/README v0.2.0 + rec 114 + 根层 l + 03 层 l + worklog 三链。20 §14 皮肤字典无增量（Batch D = 入口层翻转非转换批——零新转换纪律，跳过有据）。

**8 原语不变性第三十五轮**：纯入口层/语料形态切换——零机制变更、零新原语、零通道。

**下一演进**：E6 收口批——终局清理（七件 .krf 平行件 + target_reader_lex.krf 删除 + Rust S-expr Reader 经典面拆除 + KRF_SOURCES → KTF_SOURCES 翻转 + compile_front_seed 退役 + 文档终局回写 + target_reader.ktf → reader.ktf 单一收敛——s-expr-removal-plan §6 退出条件五项终验——门 E6：全 .krf 输入归零实证 + fixpoint 门族 + 两路门 + 删除守卫）。

---

## r152 —— S-expr 完全拆除窗 Batch C 语法段收口（target_reader.krf → target_reader.ktf 语法段）：Reader fixpoint 里程碑收口（2012 → 2044 净 +32）

> M1 指令开窗第五十七例（用户四链指令：①审查 kerf-driver/bootstrap/reader.ktf、target_reader* 文件相关，移除重复项或整合为单一 reader.ktf，同理在 rust 端同步整合管理 + ②继续推进目标语言设计的实现窗[遇缺陷或未完成窗口按推荐顺序直接推进进入对应窗口具体实施] + ③按 sop.md 流程结合 lang-design 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 + ④同步完整打包 tar.gz + 同步完整更新 web page）。

**批次定位**：r151 Batch C 词法腿后，按 s-expr-removal-plan.md §4 推荐序进入 Batch C 语法段（675-2979 行约 156 define——module/import/require/extern/use/export/macro/fn/params/types/kcell/block/let/stmt/if/perform/handle/match/patterns/precedence/postfix/primary/closures 全语法段）+ 桥语法入口切换 + fixpoint 门收口。**Reader fixpoint 里程碑收口**：生产 .ktf 读桥自身的词法器与解析器俱以目标语言表述（桥装载 .ktf 件时由 Rust target Reader 读入运行于 VM——读桥描述自身）。用户指令①整合裁定：**Rust 端整合腿本轮兑现**（桥 r151 双状态临时形收敛为单状态——双入口单程序单状态）；**单一 reader.ktf 端态 = E6 终局整合指令**（登记 s-expr-removal-plan v1.3 §11——reader.ktf{S-expr 自举 Reader}Batch D 退役后，target_reader.ktf 更名收敛为唯一 reader.ktf；Rust 端同步收敛 kerf-reader 面）。

**Batch C 语法段实施**（222-a..222-c）：
- **target_reader.ktf 语法段全量转写**（675-2979 行约 156 define → 4230 行全件——皮肤字典机械映射：cond→if-else 右递归 + 深嵌套 let 穿线{多绑定→逗号并列单语句 D61 + 嵌套单绑定→顺序语句} + 'sym→quote(sym) + 裸 nil→() + n 元 and/or 右嵌套 + eq/= 分工 + (= a b)→== + (- 1)→-1{r151 第三锚复用} + do/多表达式体→语句序列{D42 块穿线同构} + 闭包表达式 (fn (op v) body)→||(op: T, v: T){body}{closures 语料对先例} + assign 语句位 + kebab↔snake；六块子代理并行转写 c1-c6——156 define 全转 0 UNMAPPED）；
- **转换纪律第四新锚——值位 let 表达式 define → 工厂函数 + define 调用双侧镜像**：kcell（r133 闭包胞）的 (define kcell (let ((cell nil)) (fn ...))) 在目标面不可表达（无 let 表达式），oracle 同轮规范化为 kcell-make 工厂形 + (define kcell (kcell-make))——closures.krf make-counter 捕获惯用先例，语义同一（工厂装载期执行一次，胞创建一次）；
- **转换纪律第四新锚第二面——if 臂值位 assign → do 包裹语句化双侧镜像**：.krf 侧 (assign cell v) → (do (assign cell v) nil)，目标面 { cell = v; } 语句块穿线产出 (do assign unit) 形——双侧同形 → 字节码全等；
- **桥语法入口切换**：read_target_source_for_bootstrap 装载 target_reader.krf → target_reader.ktf（compile_front_seed_target 路径——Reader fixpoint 里程碑收口）；
- **桥双状态收敛**：TARGET_READER_LEX 临时态退役（r151 词法腿的过渡形）——lex-target 与 parse-target 双入口共享单一 thread_local 状态（用户指令① Rust 端整合腿）+ driver.rs 陈旧文档注记修正五处；
- **门 C 语法段测试族**：seed_ktf_parity_tests 96 → 128 case（Batch C 语法段增 8 正 + 24 负 1:3）——**门 X 全文件字节码 parity**（target_reader.krf 全件 oracle{含 kcell 规范化} ↔ target_reader.ktf 全件{4230 行}：指令序/常量池[解析]/proto 形状[名字解析]/全局引用面[解析]全等；r151 词法腿抽取基测试重定基为全文件形——抽取件 target_reader_lex.krf 被超越，维持 E6 删除）+ 载荷形状锚（双侧 209 protos/488 consts/240 globals）+ **门 Z fixpoint**（fixpoint_self_parse_stx_parity：生产读桥解析 target_reader.ktf 自身源文 ↔ Rust 种子解析同文——正典 Stx 渲染逐项字节级全等，自宿主 Reader 读自身）+ 语法入口面（双入口单程序）+ kcell 工厂面 + 语法命名回环（28 采样名）+ 语法内建消费面（append/is-pair/length）+ 解析桥双跑确定性 + 解析正典渲染快照锚 + 负向 24 族（语法段全声明族 fail-closed——module 2/import 2/require 1/extern 2/export 1/use 2/if 1/perform 2/handle 2/match 3/let 1/macro 2/闭包 1/resume 域外 1{r133 D5}/参数前导逗号 1——各断言具名诊断族）；
- **门 Y 既有 target_reader_krf_tests 32 case 零变更全绿**：语法 16 族断言面自动升级为 .ktf 路径 ↔ Rust 种子（行为零漂移证据）+ 1712 既有测试全量经新解析器零回归。

**GATE 1 全绿实测**：cargo clean（522 files/88.9MiB）→ build 23.01s 零告警 + check 0:0 + fmt 零 diff + clippy --release --workspace -D warnings 0 + test --release --workspace **2044:0:0 净 +32**（RUST_MIN_STACK=33554432）+ 审计×6 真实 EXIT 0（280 case）+ CLI 双语法面零回归十二路径（fib ⇒75025/144 双面 + check ok 2/9/5/38 双面 + effect_multiarm ⇒217 双面 + nested_resume ⇒540 双面 + closures ⇒42 + test 2/2 双面 + tokens .ktf 桥生产面）+ bench 75.799/76.045/75.203ms 带内（r149-r151 带内 71.7-76.6；OBS-C <65ms 不满足维持——零信号）。内循环修正 2 轮（①parse-typed-params 的 eq 误映射 == 单点——门 X 指令级定位 proto 129 LoadGlobal 123≠129，子代理误用数值 == 于 eq 位点 → 修为 !(eq(...)) 调用形；②解析快照锚预期值实测校准）。

**治理对账**：matrix r152 增量行 + 总量行 2044 + RELEASE 本节 + README 三处 + t3plus-trigger-audit v1.72（r152 消费注记——14 行触发族判定零变化）+ s-expr-removal-plan v1.3（§4 排期 Batch C 语法段 ✅ 全闭 + §10 语法段实施对账节 + §11 单一 reader.ktf 终局整合指令{用户 r152 指令①登记}）+ 20 §14 皮肤字典语法段行 + 替换面图 §8.3 拆除进程注记 + rec 113 + 根层 l + worklog 三链。8 原语不变性第三十四轮（纯皮肤/载荷形态切换——零机制变更零新原语零通道）。

**下一演进**：Batch D——用户面拆除（CLI .krf 入口收敛 + compile_front/read_source S-expr 生产路径退役 + reader.ktf 退役 + 语料 .krf 面清理 + 双入口测试族重构——门 D：CLI 单面零回归 + .krf 拒收 fail-closed 负例族 + 语料 .ktf 单面全绿）。

---

## r151 —— S-expr 完全拆除窗 Batch C 词法腿（target_reader.krf → target_reader.ktf 词法段）：Reader fixpoint 里程碑第一腿（1980 → 2012 净 +32）

> M1 指令开窗第五十六例（用户三链指令：①继续推进目标语言设计实现窗[遇缺陷或未完成窗口按推荐顺序直接推进进入对应窗口具体实施] + ②按 sop.md 流程结合 lang-design 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 + ③同步完整打包 tar.gz + 同步完整更新 web page）。

**批次定位**：r150 Batch B（check.ktf HM 判定面）后，按 s-expr-removal-plan.md §4 推荐序进入 Batch C——target_reader.krf（2979 行，生产 .ktf 读入桥，r107 词法批 + r108 语法批）→ target_reader.ktf 目标语言化。**Reader fixpoint 里程碑**：生产 .ktf 读桥自身的词法器以目标语言表述（桥装载 .ktf 件时由 Rust target Reader 读入——Reader 读 Reader 的第一腿）。r151-r152 两轮分批：**本轮 = 词法段（1-643 行）**；r152 = 语法段（675-2979 行）+ 桥语法入口切换 + fixpoint 门收口。

**Batch C 词法腿实施**（221-a..221-c）：
- **target_reader.ktf 词法段全量转写**（1-643 行——皮肤字典机械映射：cond 20 处→if-else 右递归链 + 多绑定 let 16 处→逗号并列单语句 + define 62 处→fn + 'sym 21 处→quote(sym) + 裸 nil 40 处→() 值位{build.ktf:95-107 先例} + and/or/not→&&/||/! + **高阶函数值传递**{lex_scan_with(scan_number, ...)——compiler.ktf:1430 map(proto_finish) 先例} + 字符串转义集 7 形同构{Rust target Reader 转义臂 n t r 0 \\ " ' 逐字核对} + kebab↔snake 符号引入边界）；
- **转换纪律第三新锚——负整数字面量位双侧同形化**：S-expr 面 -1 读期字面量化（PushConst(Int(-1))）vs 目标面 -1 解析期一元负（(- 1) 全局调用——parse_unary Minus 臂），形态分歧根因 = 目标面无负数字面量语法 → **三侧同形化**（target_reader.krf 全件 list-pos 的 -1 → (- 1) 一元负调用形 + 提取件同步 + .ktf 侧 -1）——r150 TAG 规范化先例镜像（双侧同形 → 字节码全等）；
- **n 元 and 右嵌套纪律复用**：平铺三元/四元/六元 and 共 7 位点 → A && (B && (C && D)) 右嵌套（S-expr and 宏右递归展开 (_ a b ...) => (if a (and b ...) false) 同构——expander derived.rs 语义单源核对）；
- **多绑定 let 逗号并列纪律复用**：lex_scan_with 三绑定 + lex_string 双绑定 → let a = e1, b = e2, c = e3; 单语句（平铺多绑定 ↔ 逗号并列；嵌套单绑定 ↔ 顺序语句——Batch A 纪律精确化）；
- **eq/= 映射分工纪律**：(eq a b) 通用相等 → eq(a, b) 函数调用形；(= a b) 数值比较 → == 运算符（首跑 16 败根因清偿——== 对字符串报 requires a number{TD-016 口径}）；
- **target_reader_lex.krf 新立**（1-643 行提取 + 一处规范化位点声明——门 C 词法腿 parity oracle；E6 收口批删除）；
- **target_reader.rs 桥双状态改造**：TARGET_READER_LEX thread_local 新状态（include_str! target_reader.ktf + compile_front_seed_target 装载）+ load_reader_program 共享装载脊柱（face 参数分派两种子装载——expand/compile 维持种子 Rust P1 硬约定）+ lex_target_for_bootstrap 切换至新状态 + read_target_source_for_bootstrap 维持 .krf 全件（r152 语法段批收敛——双状态隔离零既有行为变更）；
- **门 C 词法腿测试族**：seed_ktf_parity_tests 64 → 96 case（Batch C 词法腿增 8 正 + 24 负 1:3）——载荷字节码 parity（提取 oracle ↔ 转写件：指令序/常量池[解析]/proto 形状[名字解析]/全局引用面[解析]全等）+ 入口面（global_refs 承载 lex-target）+ 内建消费面（十内建双侧同在）+ 字符集常数面（DIGITS/ALPHA/HEX-DIGITS/OCT/BIN/TKEYWORDS/CAP10/16/8/2 十表）+ 命名映射回环（入口 + 11 内部名 + 恒等面）+ 生产活性（dump_tokens_target CLI 桥真实语料）+ 双跑确定性（radix 值文本 int:255 + 注释跳过）+ Token 快照锚（首五尾三硬编码）+ 负向 24 族（词法 12：未闭合串/非法转义/未闭合块注释/i64 溢出界/双点浮点/e 后点/非法字符 # @ ` ~/EOF 反斜杠/多字节转义/路径尾随 ::/:: 后数字；文法 5：孤立 }/未闭合 [/fn 体缺 }/相邻表达式无分隔/孤立 else/let 缺 =；深度帽 2：块族 300 层嵌套 if 经 Rust 种子直击 + S-expr datum 帽双侧 parity；关键字操作数位 1；多字节错误 Span 1）；
- **门 Y 既有 target_reader_krf_tests 32 case 零变更全绿**：词法 16 族断言面自动升级为 .ktf 路径 ↔ Rust 种子（行为零漂移证据）+ 语法 16 族维持 .krf 路径（r152 前保持）。

**GATE 1 全绿实测**：cargo clean → build 22.64s 零告警 + check 0:0 + fmt 零 diff（一处顺修）+ clippy --release --workspace -D warnings 0（一处 doc_lazy_continuation 顺修）+ test --release --workspace **2012:0:0 净 +32**（RUST_MIN_STACK=33554432）+ 审计族全绿（architecture 6 + gate_review 8 + e5 1 + m3 17 + switch 60——含于 2012 全量）+ CLI 双语法面零回归（fib ⇒75025/144 双面 + check ok 2/9/5/38 + effect_multiarm ⇒217 双面 + nested_resume ⇒540 双面 + closures ⇒42 + test 2/2 + tokens .ktf 桥生产面实证）+ bench 71.909/72.358/72.338ms 带内（r150 锚 71.735 同带；OBS-C <65ms 不满足维持——零信号）。内循环修正 3 轮（①eq 映射错误根因 + ②三纪律增量锚 + ③测试程序字面括号笔误与快照锚校准）。

**治理对账**：matrix r151 增量行 + 总量行 2012 + RELEASE 本节 + README 三处 + t3plus-trigger-audit v1.71（r151 消费注记——14 行触发族判定零变化）+ s-expr-removal-plan v1.2（§4 排期 Batch C 词法腿 ✅ + §9 词法腿实施对账节）+ 替换面图 §8.3 拆除进程注记（Batch C 词法腿行）+ rec 112 + 根层 l + worklog 三链。8 原语不变性第三十三轮（纯皮肤/载荷形态切换——零机制变更零新原语零通道）。

**下一演进**：Batch C 语法段——target_reader.ktf 扩展 675-2979 行 + 桥语法入口切换 + .krf 全件退役 oracle + fixpoint 门（target Reader 读自身 .ktf 源——Reader fixpoint 里程碑收口）。

---

## r150 —— S-expr 完全拆除窗 Batch B（check.krf → check.ktf）：HM 生产判定面目标语言化（1948 → 1980 净 +32）

> M1 指令开窗第五十五例（用户三链指令：①继续推进目标语言设计实现窗[遇缺陷/未完成窗按推荐顺序直接推进进入对应窗口具体实施] + ②按 sop.md 流程结合 lang-design 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 + ③同步完整打包 tar.gz + 同步完整更新 web page）。

**批次定位**：r149 Batch A（构建系统五面 .ktf 化）后，按 s-expr-removal-plan.md §4 推荐序进入 Batch B——check.krf（1285 行 HM 引擎，r80 起生产判定面）→ check.ktf 目标语言化。本轮两项**转换纪律新锚**：①**r116 第二规范化双侧逐字镜像**——七个关键字符号（'fn/'if/'let/'module/'require/'perform/'handle，13 位点）在目标面不可直写（quote(fn) 解析失败 = switch_corpus_parity_tests r116 负锚——保留字不可入表达式位），双侧同形化为 FN-TAG..HANDLE-TAG string-to-symbol 常量（同文件 LT-TRUE/LT-FALSE/LT-NIL 形先例），双侧字节码全等（r116 正锚先例镜像）；②**'nil→quote(()) 字面量化位**——S-expr 面的 'nil 在读期被字面量化为 Nil 字面量（编译为 PushNil），目标面的 nil 是普通标识符（quote(nil) 产出 SymLit 符号常量 PushConst——语义分歧 + 常量池/全局表索引漂移双根因），正确映射 = quote(())（expander.ktf:1295 先例）。

**Batch B 实施**（220-a..220-c）：
- **check.ktf 全量转写**（1285 行 HM 生产判定面——皮肤字典机械映射：cond 69 处→if-else 右递归链 + 'sym→quote(sym) + 'nil→quote(()) + n 元 or→显式右嵌套 + mod 保留调用形 + do/assign 语句序列化{D42——语句序=求值序} + 多绑定 let 单语句承载 + kebab↔snake 符号引入边界；桥入口符号 lchk-check-program 查询零变更）；
- **check.rs 桥切换**：include_str!/CHECK_FILENAME → check.ktf + 装载行 compile_front_seed → compile_front_seed_target（Rust target Reader 读入；expand/compile 维持种子 Rust——P1 硬约定）；探针名 production_check_is_krf 历史名保留（Batch A 同律——门 Y 零变更纪律）；
- **平行件策略**：check.krf（规范化 oracle）保留为门 B 基线腿（KRF_SOURCES 守卫维持——原则 41 窗口期 oracle，E6 收口批删除）；
- **门 B 测试族**：seed_ktf_parity_tests 32 → 64 case（Batch B 增 8 正 + 24 负 1:3）——载荷字节码 parity（规范化 oracle ↔ 转写件：指令序/常量池[解析]/proto 形状[名字解析]/全局引用面[解析]全等；debug_spans 跨文本按设计豁免）+ 关键字 TAG 双侧规范化锚 + 入口与全局消费面 + 命名映射回环（入口标识符 + 11 内部名 + 七 TAG 名 + 恒等面）+ 跨阶段双面 E2E（同一类型错误程序双用户面同诊断计数同消息族——生产判定面双侧同走 check.ktf）+ 生产接线活性（production_check_is_krf 实证）+ 干净语料面 + r126 多错误收集形 + 负向 24 族（occurs/unify/arity 五形/规则五族/uncallable/if 条件/sigf 位置四族——具体实参直击{tvar 走 A4 保守域}/module 体/失败 define 后续引用/项内多违反/关键字 quote 负锚）；
- **门 Y 既有 hm 三族零变更全绿**：hm_production_switch 9（七语料锚 18/6/3/6/0/0/0 钉定维持）+ hm_krf_path 31 + ktf_tc_sigs_parity 32（TC-SIGS 62 行锚维持——r144 口径）。

**GATE 1 全绿实测**：cargo clean → build 22.69s 零告警 + check 0:0 + fmt 零 diff（一处 import 长行顺修）+ clippy --release --workspace -D warnings 0 + test --release --workspace **1980:0:0 净 +32**（RUST_MIN_STACK=33554432）+ 审计×6 真实 EXIT 0（280 case）+ CLI 双语法面零回归（fib ⇒144 双面 + check fib 2/9/5/38 双面全等 + effect_stress ⇒120 + higher_order ⇒(1 4 9 16 25) + closures ⇒42 + macros ⇒42 + test 2/2 + ffi_alias ⇒9 + vector ⇒9）+ bench 71.735ms（r149 锚 76.612 对照 -6.3% 环境侧有利漂移——fib 路径零接触 check 载荷；OBS-C <65ms 不满足维持——零信号）。

**治理对账**：matrix r150 增量行 + 总量行 1980 + RELEASE 本节 + README 三处 + t3plus-trigger-audit v1.70（r150 消费注记——14 行触发族判定零变化）+ s-expr-removal-plan v1.1（§4 排期 Batch B ✅ + §7 Batch B 实施对账节）+ 20-surface-conventions §14（'nil↔quote(()) 字面量化位 + TAG 规范化注记）+ 12-roadmap §2.19（Batch B 锚）+ 替换面图 §8.3 拆除进程注记（Batch B 行）+ rec 111 + 根层 l + worklog 三链。8 原语不变性第三十二轮（纯皮肤/载荷形态切换——零机制变更零新原语零通道）。

**下一演进**：Batch C——target_reader.krf → target_reader.ktf（2979 行，r151-r152 两轮分批：词法段 + 语法段——**Reader fixpoint 里程碑**：生产 .ktf 读入桥自身目标语言化）。

---

## r149 —— S-expr 完全拆除窗 Batch A（开窗 + 构建系统五面 .ktf 化）：种子链目标语言化首批（1916 → 1948 净 +32）

> M1 指令开窗第五十四例（用户四链指令：①S-expr 完全拆除时机授权「在演进中是存在将 S 表达式完全拆除只使用最终目标语言表述的，如果演进节点和任务推进合适时机可完全拆除 S 表达式」+ ②继续推进目标语言设计实现窗[遇缺陷直接推进] + ③推荐序推进 + ④打包 web 同步）。

**窗口定位**：r148 终局审计裁定「S-expr→目标语言替换进程已抵达设计终态——剩余 = 触发式域外行 + 按设计保留面（替换面图 §8.3 三行）」后，用户指令①对 §8.3 前两行（种子链七件 .krf + 用户 S-expr 面）作出完全拆除时机授权——时机六因子判定全过（用户信号在位 / 竞争任务零{登记册实施项全清零} / 切换窗方法论成熟{r106-r120 转换纪律} / 可行性审计六面全绿 / 1916 基线稳定 / 宪制授权完备{BS-A「VM 永久 Rust 基座」条款零触碰}）→ **S-expr 完全拆除窗开窗**（多轮窗：Batch A ✅ r149 / B check.krf r150 / C target_reader.krf r151-r152{Reader fixpoint} / D 用户面拆除 r153 / E6 终局清理 r154）——设计单源 s-expr-removal-plan.md v1.0（开窗判据 + 可行性审计 + 分批计划 + 门 X/Y/Z 体系 + 退出条件）。

**可行性审计六面全绿**（r149 / 219-a——替换面图 §8.4 六族信号法的种子域延拓）：七件 .krf 种子代码面实测——零下划线符号（命名映射 `_`→`-` 无歧义往返）+ 零代码级准引用 + 零真实效应用法（perform/handle 命中全为解析器关键字字符串与注释）+ 零代码级 bang 名 + 核心形式皮肤字典全覆盖（cond→if-else 右递归 + n 元 or→显式右嵌套 + 'sym→quote(sym) + mod 调用形 + define(NAME,e) 调用形）+ 装载路径就绪（compile_front_seed_target 自 r110-r116 生产验证）——**纯皮肤机械转换，零语言面前置缺口零语义变更义务**。

**Batch A 实施**（219-b/219-b2）：
- **五件 .krf→.ktf 转写**：build.ktf（148 行）/ cli.ktf（75）/ test.ktf（157）/ test_runner.ktf（163）/ cache.ktf（135）——皮肤字典机械映射逐件落地，桥入口符号查询零变更（命名映射 `_`→`-` 保证 .ktf 标识符 intern 出与 .krf 相同的种子符号）；
- **五桥种子路径切换**：bootstrap/{build,cli,test,test_runner,cache}.rs 装载行 compile_front_seed → compile_front_seed_target（Rust target Reader 读入；expand/compile 维持种子 Rust——P1 硬约定：引导装载恒种子路径）；
- **平行件策略**：五件 .krf 原件保留为门 X 基线腿（KRF_SOURCES 守卫维持七件——原则 41 窗口期 oracle，E6 收口批删除）；
- **门 X 新测试族**：seed_ktf_parity_tests 32 case（8 正 + 24 负 1:3）——载荷字节码 parity ×5（跨文本解析口径：Symbol 句柄经属主表名解析 + 编译器哨兵容错；指令序/常量池[解析]/proto 形状[名字解析]/全局引用面[解析]全等；debug_spans 跨文本按设计豁免）+ 入口与全局消费面 + 命名映射回环 + 跨阶段双面 E2E（prelude 导入程序双用户面同值 (2 3 4)——传递消费 build.ktf[prelude 注入决策] + cache.ktf[缓存咨询] + target_reader.krf[生产读桥]）+ 负向 24 族（词法 3 + 文法 8 + 位置 2 + 域外 2 + 声明 2 + 能力 E0006 + 未绑定 E0022 ×2 + HM ×2 + 运行期 + 深度帽）；
- **门 Y 既有桥级 parity 全族零变更全绿**：build_krf_parity 14 + cache/cli/test/test_runner 四族 65 case——生产决策经桥端到端零行为漂移。

**同窗缺陷清偿：目标 Reader 深度帽**（§20.3 同类路径全量审查发现——用户指令②「遇缺陷直接推进」臂命中）：target.rs 缺失 principle-58 MAX_NESTING_DEPTH=256 守卫（S-expr 面 parser.rs 有帽、目标面无帽——深嵌套 .ktf 输入栈溢出崩溃而非 fail-closed 拒收的不对称）→ TARGET_MAX_NESTING_DEPTH=256 新守卫落地（parse_expr / parse_block / consume_type / parse_pattern_or 四递归族根；同帽同消息族「nesting depth exceeds the limit 256」；生产读路径经 VM 自举 Reader{迭代蹦床 + 堆帧 + VM 帧数帽 TD-023——自有防线}不入新帽保护面）——负例 #24 双面 parity 锚定（同一深嵌套源双 Reader 同族拒收）。

**GATE 1 全绿实测**：cargo clean → build 23.05s 零告警 + check --workspace --all-targets --release 0:0 + fmt 零 diff（一处长行顺修）+ clippy --all-targets -D warnings 0 + test --release --workspace **1948:0:0 净 +32**（RUST_MIN_STACK=16777216）+ 审计×6 真实 EXIT 0（280 case）+ CLI 双语法面零回归（fib ⇒75025/144 双面 + ffi_alias ⇒9 双面 + nested ⇒540 + multiarm ⇒217 + handle_expr ⇒327 + closures ⇒42 + vector ⇒9 + stress ⇒120 + check fib 2/9/5/38 + check ffi_alias 1/2/0/5 + test 2/2）+ bench 76.612ms 带内（OBS-C <65ms 不满足维持——零信号）。

**治理对账**：matrix r149 增量行 + 总量行 1948 + RELEASE 本节 + README 三处 + t3plus-trigger-audit v1.69（r149 消费注记——14 行触发族判定零变化）+ 07-bootstrap-strategy v7.3（构建系统段 .ktf 化注记）+ 12-roadmap v6.31（§2.19 拆除时点对账——Batch A 锚）+ 20-surface-conventions v1.32（§14 种子域行）+ 替换面图 §8.3 注记（前两行转入拆除进程中）+ rec 110 + 根层 l + worklog 三链。8 原语不变性第三十一轮（纯皮肤/载荷形态切换——零机制变更零新原语零通道）。

**遗留债务**：无新增（同窗缺陷当轮清偿——目标 Reader 深度帽；.krf 平行件 = 窗口期 oracle 策略性保留非债务{E6 收口批按原则 41 判据删除}）。

**内循环轮次**：1（负例三处假设修正 + 深度帽发现-清偿-回归全链单轮收敛）。

**委员会投票**：r149 Batch A 收口投票 5.5/5.5 = 100% GO（验收即兑付——M1 指令开窗第五十四例）。

**下一演进**：Batch B（check.krf → check.ktf——HM 引擎 1285 行，r150；体量先例 r114 compiler.ktf 1404 行单轮）。

---

## r148 —— 终局审计对账窗（恢复 + 指令②终局审计 + 替换面图 v2.0-r148 R4 全量回写）：S-expr→目标语言替换进程终局裁定（1916 基线第一轮维持——零增量纯文档轮）

**日期**：2026-11-16　**类型**：恢复轮 + R4 审计链文档债清偿轮 No.3 + 终局审计对账窗（零 kerf 代码变更零测试面变动——**1916 基线第一轮维持**{r148——r105/r145/r146 零增量同型第四连}）　**驱动**：用户五链指令（⓪使用上传的 kerf-v1.0.0-r147-externalias-1916tests.tar.gz 替换回退态[第十一次 z.ai web 回退恢复——磁盘态 git HEAD r134 + 329 残改 vs 包态 r147 全链] + ①审查当前项目演进进度和位置，检查完全将 S 表达式 替换为 目标语言 序言剩余的任务区域和范围 + ②继续推进 目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施 + ③按照 docs/sop.md 流程结合 lang-design 与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 + ④同步完整打包项目 tar.gz 并同步完整更新 web page）——**M1 指令开窗第五十三例**（推荐序裁定：恢复后六族语料信号实测全零 + T3+ 14 行零信号 + 登记册触发式实施项全清零 + 门控任务七项全闭 + #15 需 next23.md{未上传} → 逐行走查全部登记域外表 → **零用户指令臂开放行**{r147 已清偿末行} → 唯一可推进缺陷 = **替换面图 v1.0-r71 滞留 76 轮的 R4 文档债**——§20.3 同类路径全量审查至收敛的自然延拓{r145 第一例 / r146 第二例 / r148 第三例}）

### 交付链（218-a..218-f）

- **218-a 恢复窗**：r147 包单源解包替换{sha256 b9409a55…706 成员——保 .git + target；diff -rq 差异归零实证} + 恢复 commit 9bd1f6e{单笔承载 r135-r147 全量增量 223 文件} + Rust 1.98.1 工具链第七次环境重装{scripts/rust/setup.sh——§3.1 自助} + GATE 1 恢复验收全绿{cargo clean → build 25.21s 零告警 + check 0:0 + fmt 零 diff + clippy -D warnings 0 + **test 1916:0:0 逐位复现**[RUST_MIN_STACK=16777216]} + 审计×6 真实 EXIT 0 ×6{280 case} + CLI 双语法面零回归{fib ⇒75025/144 双面 + ffi_alias ⇒9 双面 + nested ⇒540 + multiarm ⇒217 + handle_expr ⇒327 + closures ⇒42 + vector ⇒9 + stress ⇒120 + check fib 2/9/5/38 + check ffi_alias 1/2/0/5{全局引用 0 = D3 实证} + test 2/2} + bench 76.292ms 带内{<65ms 触发线不满足维持——OBS-C 零信号}；**谱系裁定**：磁盘残态 = 孤儿分支（r141 包恢复后自标 r142 终局审计——web 回退致与主谱系分叉），包态 = 主谱系真值
- **218-b 审计腿**：指令② S-expr→目标语言替换剩余范围全量走查{宪制保留面{BS-A 七件 .krf 种子链 + 用户 S-expr 面} / 已完成面{切换窗 r106-r120 全闭 + parity 五连 + 门控七项全闭} / 触发式维持面{九族设计单源 §7 域外行} / Stage 2+ 门控面 / 恒态} + 六族信号实测全零{net 0 / @ 0 / syntax-parse 0 / vector .krf #( 0 / CStruct-CFunction 0 / extern 语料在位为窗交付物本体} + #15 需 next23.md 维持 + r147 声称双翻转实证在位{ffi v1.1 + handle-expr v1.1 §7 末行} → **终局裁定：零用户指令臂开放行**；唯一可推进缺陷 = 替换面图 R4 债
- **218-c 实施**：bootstrap-replacement-surface-map.md v1.0-r71 → **v2.0-r148**{头部升格「识别基线」→「终局审计基线」+ 谱系诚实注记{v2.0 曾于孤儿分支 r142 交付一次随 web 回退丢失——r148 依代码实况重建} + §2 r148 实况注记{reader.ktf 桥读 + check.krf 判定面 + TD-032 五切口} + §3.1 四行翻转 ✅{preamble r109 / reader r110 / compiler r114 / expander r116 + r120 原件 git rm} + 种子链七件新行{BS-A 按设计保留} + §3.3 HM/driver 双行翻转 ✅{r74/r80 / r74-r90} + §3.4 WasmBackend 行注记{TD-031 四阶段全落} + §3.5 终态注记{五步全落 + r121-r147 廿七窗} + §4 用法二/三终态升级 + §5 七缺口全闭翻转 + §6/§7 终局版 + **§8 终局审计节新立**{8.1 演进位置 r148 快照 + 8.2 已完成区域十一行 + 8.3 按设计保留区域三行 + 8.4 剩余任务区域全量枚举{A 语言面触发行九族 + B 优化/架构触发行 + C 治理触发行——零信号} + 8.5 R4 回写对账八处 + 8.6 终局结论：替换进程已抵达设计终态——剩余范围不含任何零信号可推进的实施任务}
- **218-d GATE 1**：六命令全绿{build 0 告警 + check 0:0 + fmt 零 diff + clippy -D warnings 0 + **test 1916:0:0 逐位维持**} + 审计×6 真实 EXIT 0 ×6 + 纯文档轮零代码变更
- **218-e 治理对账**：RELEASE r148 节{本件} + README 三处 + matrix r148 零增量行 + t3plus v1.68 + guide v1.33{行权态三十二→三十三} + rec 109 + l r148 条 + worklog 三链{根层 r134-r147 丢失段补链注记}
- **218-f 收口**：§6.4 commit + git archive 单源打包 → r148 包三验 + download 入位 + web 五件 + Agent Browser E2E + 投票

### 关键裁定

1. **终局审计裁定（指令②答复）**：S-expr → 目标语言替换进程**已抵达设计终态**——切换窗 r106-r120 全闭 + 域外清偿 r121-r147 廿七窗 + 门控七项全闭 + 皮肤字典 14 映射族 + 双面语料 parity 全绿；「完全替换」剩余范围 = 触发式域外行（零信号）+ 按设计保留面（BS-A 种子链七件 + 用户 S-expr 面 + A 类基座）——**不含任何零信号可推进的实施任务**（23 §2.3 红线 3 维持）
2. **谱系裁定（恢复轮诚实登记）**：磁盘残态为孤儿分支（r141 包恢复后自标 r142——其 v2.0 地图交付随 web 回退丢失）；r147 包 = 主谱系唯一真值（用户指令⓪指定）；r148 重建 v2.0 地图非首次交付（谱系注记在图头部）
3. **R4 文档债第三例（§20.3 收敛延拓）**：替换面图 v1.0-r71 滞留 76 轮{r143-r147 五窗均未触碰——主谱系从未回写}——八处滞留当轮全翻转；r145 第一例 / r146 第二例 / r148 第三例同类路径收敛中
4. **8 原语不变性第三十轮验证**：零新原语零通道零操作码零语法——纯文档审计轮{恢复 + 终局对账}
5. **下一演进登记**：触发式零信号维持或自然信号——按用户指令序或自然信号{§8.4 三族全零信号；#15 需 next23.md}

---

## r147 —— extern 符号空间别名窗（声明位别名臂：双名分离 + 替换语义 + 反遮蔽扩展）：ffi §7 末行「extern 别名/重导出」清偿关闭（1884 → 1916 净 +32）

**日期**：2026-11-16　**类型**：实施窗（extern 符号空间别名机制——ffi-language-surface §7 末行 + handle-expr-position §7 末行双登记行清偿；**1916 基线自 r147 起**）　**驱动**：用户四链指令（〇审查当前项目演进进度和位置，检查完全将 S 表达式替换为目标语言序列剩余的任务区域和范围 + ①继续推进 目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施 ②按照 docs/sop.md 流程结合 docs/lang-design/ 下的项目演进流程（整体任务视角）与 docs/develop/v0/tech-debt-register.md、docs/develop/v0/stage-3/t3plus-trigger-audit.md 等（局部任务视角），按照推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）——**M1 指令开窗第五十二例**（推荐序裁定：r146 收口后六族语料信号实测全零 + T3+ 14 行零信号 + 登记册触发式实施项维持全清零 + #15 需 next23.md{未上传} → 逐行走查全部登记域外表{11 份设计单源 §7 + 切换窗 §4 + 登记册} → **唯一含「用户指令」触发臂的开放行 = ffi §7 末行「extern 别名/重导出（use 选择形接驳）」**{r143 收口 P5/P6 探针已实证 E0019/E0022 符号空间机制缺口——r147 五探针复核逐位吻合}）

### 交付链（217-a..217-f）

- **217-a 走查 + 张力探针**：r146 态核验零回退{git 6db4e2b + 1884:0:0 逐位复验——第十三轮会话首检} + rustc PATH 第七次环境自助{~/.cargo/bin 注入——1.98.1 与基线一致} + 用户指令〇审计腿{S-expr→目标语言替换剩余范围全量走查：宪制保留面{BS-A 七件 .krf 种子链 + 用户 S-expr 面} / 触发式维持面{vector 7 行 + handle 5 行 + ffi 7 行} / Stage 2+ 门控面{类型/效应/能力声明族 + is-procedure + pub(scope) 族} / 恒态{单层裁定族}——切换窗 r106-r120 全闭 + parity 五连 r125-r143 + 门控七项全闭实证} + 五探针{P1 双面 ⇒9 基线 / P2 E0001 声明位 as 形 / P3 E0026 模块体位 / P4 E0019 虚拟模块 / P5 E0026 六元素形——r143 P5/P6 逐位吻合}
- **217-b 设计单源**：extern-alias-design.md v1.0{D1-D10 十裁定 + §7 域外表八行——双名分离 D3[IR extern_face (Symbol, Rc<str>) 对既有分离维度启用——IR/编译器/VM 零机制变更] + 替换语义 D4[r130 import-as 声明位家族线——r134 D8 反向锚同构；r135 prelude 双绑形判别注记] + 自别名拒收 D5 + 反遮蔽扩展 D6 + 能力门不感知别名 D7[r135 D13 行权线] + HM/check A4 维持 D8 + use 选择形接驳维持域外 D9[扁平空间无模块面——宪制] + 新语料对 D10[零锚翻转]}
- **217-c 实施**：种子 target.rs parse_extern_decl KwAs 前置臂{r130 asp 先例措辞} + 镜像 target_reader.krf extern-alias-name 新函数 + alias-rec 双 Token 穿线{(as-t al-t) 对——extern-kind/kind-sep/arrow/semi 六函数链签名扩展} + 驱动面 collect_extern_face 六元素臂{4/6 元素形 + items[2] as 字面符号 + items[3] ALIAS + kinds/ret 位移} + ExternEntryDecl.local 字段{恒等缺省——原则 27} + D5 自别名 + D6 反遮蔽扩展{local 入 define/import/N1/既有 extern 可见名} + externs_for_compile 分离映射{(intern(local), Rc(name))} + verify_unbound_refs defined.insert(local){替换语义} + **bootstrap 编译桥 CC_EXTERN 协议扩展**{compiler.rs 桥改传 (local flat) 对 + compiler.ktf rv_loop extern_lookup 新函数{is_contains → 对查找 + EXTERN_TAG 载荷 = flat} + compile_call SymLit 载 second{Rust 侧 IrVar::Extern(flat) 镜像——原则 31}} + ktf_extern_alias_tests 32 case{8 正 + 24 负 1:3} + 语料对 ffi_alias.{ktf,krf} ⇒ 9 双面{语料族 15 对 + effect.ktf 孤件} + runner.rs 挂载
- **217-d GATE 1**：六命令 clean 起步全绿{cargo clean → build 21.12s 零告警 + check --workspace --all-targets 0:0 + fmt 顺修一处后零 diff + clippy --workspace --all-targets -D warnings 0 + **test --release --workspace 1916:0:0 净 +32**} + 审计×6 真实 EXIT 0{280 case} + CLI 双语法面零回归{fib ⇒144 双面 + nested 540 + multiarm 217 + handle_expr 327 + closures 42 + vector 9 + ffi 9 + **ffi_alias ⇒9 双面[新]** + stress 120 + check fib 2/9/5/38 双面 + check ffi_alias 1/2/0/5{全局引用 0 = D3 分辨面实证} + test 2/2} + bench 带内{fib 111ms 全进程{~71ms 计算段——带内}}
- **217-e 治理对账**：ffi-language-surface-design v1.1 §7 末行翻转 + handle-expr-position-design v1.1 §7 末行翻转{**R4 审计链纪律——r145/r146 教训：行翻转与收口同窗}** + 02 v7.24{extern_decl [as ident] 可选段 + 版本头} + 20 v1.31{§14 第十三映射域扩展注记} + examples README{语料 15 对 + ffi_alias 双行} + matrix 1916 + RELEASE r147 节{本件} + README 三处 + t3plus v1.67 + rec 108 + worklog 三链
- **217-f 收口**：§6.4 commit + git archive 单源打包 + 包三验 + web 五件 + Agent Browser E2E + 投票

### 关键裁定

1. **双名分离（D3）**：underlying = 扁平 FFI 空间名{注册 E0012 / 契约 E0026 / 能力 E0006 / 运行表四面恒按 underlying 匹配——零变更}；local = 源级绑定名；穿线 = externs_for_compile 对 `(intern(local), Rc(name))`——**IR extern_face (Symbol, Rc<str>) 既有分离维度启用：IR/编译器/VM 零机制变更**（原则 9）
2. **替换语义（D4）**：local 替换 underlying 入源级可见面——underlying 直写 = E0022{r134 member-rename D8 反向锚同构}；r135 prelude 增量别名双绑形判别 = 模块面 vs 声明位家族线
3. **bootstrap 桥协议扩展（同窗实施发现）**：r137 恒等映射下的隐性协议假设{桥只传扁平名列表}被别名打破——E0004 运行期未绑定实证定位 → CC_EXTERN 改传 (local flat) 对 + rv_loop extern_lookup + SymLit 载 flat{Rust 侧镜像——原则 31}；无别名路径 (local == flat) 逐位不变{原则 27}
4. **use 选择形接驳维持域外（D9）**：扁平 FFI 空间无模块面{ffi-ownership-model §4 卫生不可穿透——宪制}；虚拟模块面 = Stage 2+ 命名空间演进触发；模块体重导出 = D2 位置纪律维持
5. **8 原语不变性第二十九轮验证**：零新原语零通道零新操作码零 CoreExpr/IR 变体——纯 Reader/驱动面/桥协议窗口
6. **下一演进登记**：触发式零信号维持或自然信号——按用户指令序或自然信号{§7 域外表全行为触发式或 Stage 2+}

## r146 —— R4 审计链文档债清偿窗第二例（扩展核对轮）：r132/r133 收口声称四件补债 + 收敛判定（1884 基线第三轮维持——零增量轮）

**日期**：2026-11-14　**类型**：R4 审计链文档债清偿轮 No.2（零 kerf 代码变更零测试面变动——**1884 基线第三轮维持{r144-r146}**；r145 同型先例第二连）　**驱动**：用户三链指令（①继续推进 目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施 ②按照 docs/sop.md 流程结合 docs/lang-design/ 下的项目演进流程（整体任务视角）与 docs/develop/v0/tech-debt-register.md、docs/develop/v0/stage-3/t3plus-trigger-audit.md 等（局部任务视角），按照推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）——**M1 指令开窗第五十一例**（推荐序裁定：r145 收口态登记册触发式实施项全清零 + T3+ 14 行零信号{六族例行监测复测零命中} + 门控任务七项全闭 → 用户指令①「遇缺陷直接推进」臂 → **§20.3 同类路径全量审查至收敛的自然延拓：审计链交叉核对自 r134-r144 范围扩展至 r125-r136 声明范围**{r145 发现第三例后的继续审查} → 四件声称未执行实证：r132 收口声称「根层 l r132 条目 + rec 94 + docs/worklog.md 全录 202-a..f」三项未落盘{l 全文件零命中 + rec 目录 93_r131→94_r133 跳号 + 202-a..e 止} + r133 收口声称「根层 l」未落盘{无行首条目}——**R4 审计链文档债第四例**）

### 交付链（216-a..216-e）

- **216-a 走查 + 审计链扩展核对 + 收敛判定**：r145 残余收尾{重生成包三验收尾——1884:0:0 复跑 + e5close EXIT 0 + handle_expr ⇒327 双面 + 215-e 全录} + 六族例行监测复测零信号{net/extern/@ 零命中——upload/ 无 next22.md} + **审计链交叉核对扩展（r125-r136 + r137-r144 补集）**：switch-window-plan §4 四行{r125 CLI 双入口/r130 import as/r131 use/r132 handle 多臂——全部物理翻转在位 ✓} + hm-inference-design v0.3.0{r126 ✓} + r75-implementation-audit v1.1 §5.3 清偿注记{r126 ✓} + replacement-map §5 缺口5 TD-002 行{r138 ✓} + 22-namespace §7 `::` 终态注记{r131 ✓} + SOP v13.22{r139 ✓} + 04-bytecode-vm v5.6 操作码 47 全链{r136 ✓} + 06 [HANDLE-INSTALL] 注记{r136 ✓} + RELEASE r125-r139 节 15 件 ✓ + matrix r125-r133 增量行 9 件 ✓ + 02/20 版本链 ✓ + rec 序号 1-106 连续零缺口{101 同号已知} + l 行首条目 r90-r145 逐轮清点 → **唯一缺陷簇 = r132/r133 双轮四件**；203-c/203-f 误报排除{复合形态 Task ID: 203-b2/203-c 与 203-e/203-f 在位}
- **216-b R4 第四例清偿**：①docs/worklog.md **202-f 条目补债回填**{滞留十三轮 r133-r145——内容自根层 worklog 复合条目回填：r132 包三验 650 成员/19.24s + 1526 复跑 + e5close EXIT 0 + 多臂实证 202 + web 完整更新 + E2E + 投票 100% GO} ②rec **94_r132_handle多臂halt-pass窗.md 补债件**{94 号同号两件并存{94_r132 补债件 + 94_r133 原件}——101 同号先例同构} ③l 路由 **r132 条目补债**{乱序追加 r144 先例} ④l 路由 **r133 条目补债**——四件全落位
- **216-c GATE 1**：六命令 clean 全绿实测{build --release 零告警 + check --workspace --all-targets --release 0:0 + fmt --all --check 零 diff{直接复验 exit 0} + clippy --workspace --all-targets --release -D warnings 0 + **test --release --workspace 1884:0:0 零增量第三轮维持{r144-r146}**} + 审计×6 真实 EXIT 0 ×6{280 case} + CLI 双语法面零回归{八值路径全双面：fib ⇒144 + closures ⇒42 + vector ⇒9 + ffi ⇒9 + effect_stress ⇒120 + handle_expr ⇒327 + nested ⇒540 + multiarm ⇒217 + check ok{2/9/5/38} + test 2/2} + bench OBS-C{fib 10 轮 76.759/75.965/75.984ms——带内{>65ms 触发线不满足维持——零信号}}
- **216-d 治理对账**：RELEASE r146 节{本件} + README 质量状态行 r146 前插 + 包行 r146/r145 + matrix r146 零增量行{总量 1884 维持} + t3plus-trigger-audit v1.66{r146 消费注记——14 行触发族判定零变化} + t3plus-manual-trigger-guide v1.31{M1 第五十一例行权实录——行权态三十→三十一} + rec 107 + 根层 l 路由 r146 新条 + worklog 三链
- **216-e 收口**：§6.4 commit + git archive 单源打包 + 包三验 + web 五件 + Agent Browser E2E + 投票

### 关键裁定

1. **R4 审计链文档债第四例定性（216-a）**：r132/r133 双轮收口声称的四件治理物未落盘{202-f 条目 + rec r132 件 + l r132 条目 + l r133 条目}——同类第三例{r145：handle-multi-arm §7 行}后的继续扫描命中；根因同族{收口对账清单未含全部声称物的物理核验}；§20.3 收敛路径 = 逐声称件 × 逐物理文件交叉核对至零新缺陷
2. **收敛判定（r90-r145 范围）**：l 行首条目 r90-r145 逐轮清点{唯 r132/r133 两洞——本轮补齐} + rec 序号 1-106 连续{唯 94 轮覆盖洞——本轮补齐} + 版本链/RELEASE/matrix 全实证——**审计链类缺陷在 r90-r145 范围收敛**；pre-r90 范围由 r56/78-b + r72/142-a 历史审计承载{l 文件自 r90 起建}
3. **零增量维持轮定性（r105/r145 同型第三连）**：走查零信号 + 扩展核对缺陷全为纯文档域 → 开窗 = R4 清偿窗非实施窗；GATE 1 六命令仍全量实测{零代码 ≠ 零验证}；GATE 6 对零代码变更轮免{零新子阶段}
4. **8 原语不变性第二十八轮验证**：零新原语零通道零新操作码零 CoreExpr/IR 变体零代码变更——纯文档域轮
5. **下一演进登记**：触发式零信号维持或自然信号——按用户指令序或自然信号{审计链类缺陷已收敛——后续轮按例行监测 + 自然信号驱动}

---

## r145 —— R4 审计链文档债清偿窗：handle-multi-arm §7 表达式位行翻转补债 + 零信号维持诚实登记（1884 基线维持——零增量轮）

**日期**：2026-11-14　**类型**：R4 审计链文档债清偿轮（零 kerf 代码变更零测试面变动——**1884 基线维持{第二轮 r144-r145}**；r105 零增量维持轮同型先例）　**驱动**：用户三链指令（①继续推进 目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施 ②按照 docs/sop.md 流程结合 docs/lang-design/ 下的项目演进流程（整体任务视角）与 docs/develop/v0/tech-debt-register.md、docs/develop/v0/stage-3/t3plus-trigger-audit.md 等（局部任务视角），按照推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）——**M1 指令开窗第五十例**（推荐序裁定：r144 收口态登记册触发式实施项全清零{tc-sigs §7 余二行均 Stage 2+} + T3+ 14 行零信号{本轮六族例行监测复测：match 用户面 = r122 交付物本体非新信号 + net/extern/@ 零命中 + next22.md 未上传} + 门控任务七项全闭 → 用户指令①「遇缺陷直接推进」逐行走查全部登记域外表 → 三类不可行排除{Stage 2+ 域外 / 成熟度不在位 / 纯语料信号零张力} + vector 家族张力探针 P1-P5 全绿{运行时执法完备——A4 Dynamic 静态边界为既有登记} → **唯一实测缺陷 = R4 审计链文档债**：handle-multi-arm-design.md §7「目标面 handle 表达式位」行未翻转——r143 收口四件声称清偿关闭{worklog Stage Summary + matrix.md L152 + README L69/L75 + t3plus-manual-trigger-guide v1.28}但 213-e 对账九件未含本文件{Version 头 v1.1 r136 态滞留两轮}）

### 交付链（215-a..215-e）

- **215-a 走查 + 审计链交叉核对 + 例行监测**：r144 态核验{第十三轮会话首检零回退——git c737673 干净 + **1884:0:0 基线逐位复验** + 双包 r143/r144 在位 + web r144 态} + 六族例行监测复测零信号{next22.md 未上传维持——#15 讨论链维持不可行} + 全部登记域外表逐行走查{tc-sigs §7 余二行[值位 Callable / is-procedure——均 Stage 2+ 值模型] + member-rename §7 余三行[pub(scope) ×2 Stage 2+ + 多段路径恒态] + use-decl §7[io 门控改名感知 / prelude 改名注入 / 签名表派生——触发式] + vector §7 六行[语料信号族] + handle-multi-arm §7 余五行 + handle-expr-pos §7 六行 + nested-resume D5-D7 + read-line-sig §7 四行 + TD-003/005 残留/008/015[零信号]} → 三类不可行排除成立 + vector 家族张力探针 P1-P5{P1 vector-length 非向量 E0004 + P2 越界 E0004 + P3 索引类型 E0004 + P4 append 非向量 E0004 + P5 head 向量 E0004——运行时执法全 fail-closed，静态 Any 参数 = vector-value-design D5 A4 Dynamic 既有登记边界，零张力} + **审计链同类路径全量交叉核对（§20.3）**：r134-r144 全部声称翻转件逐一实证{use-decl §7 r134 ×2 ✓ + member-rename §7 r140/r144 ✓ + tc-sigs §7 r141/r142/r144 ✓ + 02 v7.23 ✓ + 20 v1.30 ✓ + trigger-audit v1.64 ✓ + guide v1.29 ✓ + rec 100-105 ✓ + matrix 1884 ✓ + README 三处 ✓ + RELEASE r143/r144 节 ✓ + examples/README 13:13 ✓ + 09-stdlib r144 注记 ✓ + 根 l 路由 r137-r144 ✓ + 根 worklog r144 镜像 ✓}——**唯 handle-multi-arm §7 表达式位行缺失**
- **215-b R4 主清偿**：handle-multi-arm-design.md §7「目标面 handle 表达式位」行翻转{strikethrough + ✅ r143 清偿注记[双侧 Reader primary 位分派 + 五位置形 + 32 case 门 + 语料对 ⇒327 双面 + 1852 基线] + 滞留两轮发现路径注记} + Version 头 v1.1→v1.2{r145 补债注记} + Date 行增补——变更面 = 纯文档三处
- **215-c GATE 1**：六命令 clean 全绿{build --release 零告警 + check --workspace --all-targets --release 0:0 + fmt --all --check 零 diff + clippy --workspace --all-targets --release -D warnings 0 + **test --release --workspace 1884:0:0 零增量维持{第二轮}**} + 审计×6 真实 EXIT 0 ×6{stage0/stage1/stage2_r1/stage2_r2/m3/e5close——280 case 全 APPROVED} + CLI 双语法面零回归{十路径：fib ⇒144 双面 + closures ⇒42 双面 + nested ⇒540 双面 + multiarm ⇒217 双面 + vector ⇒9 双面 + ffi ⇒9 双面 + effect_stress ⇒120 双面 + handle_expr ⇒327 双面 + check ok{2 原型/9 常量/5 全局引用/38 指令}双面 + test pass 2/total 2} + bench OBS-C{fib 10 轮 76.290/76.018/75.461ms——带内[>65ms 触发线不满足维持——OBS-C 零信号]}
- **215-d 治理对账**：RELEASE r145 节{本件} + README 质量状态行 r145 前插 + 包行 r145/r144 双包 + matrix r145 零增量行{总量 1884 维持} + t3plus-trigger-audit v1.65{r145 消费注记——14 行触发族判定零变化} + t3plus-manual-trigger-guide v1.30{M1 第五十例行权实录——行权态二十九→三十} + rec 106 + 根层 l 路由 r145 新条 + worklog 三链
- **215-e 收口**：§6.4 commit + git archive 单源打包 + 包三验 + web 五件 + Agent Browser E2E + 投票

### 关键裁定

1. **R4 审计链文档债第三例裁定（215-a/215-b）**：r144 两例{l 路由六条 + rec 100-102}后第三例{§7 行翻转声称未执行}——同类路径全量审查（§20.3）为唯一可靠检出面：逐声称件 × 逐物理文件交叉核对；四件声称物（worklog/matrix/README/guide）与单件实物（design doc §7 表）的分离 = 根因（收口对账清单未含上游设计单源文件）
2. **零增量维持轮定性（r105 同型先例）**：走查零信号 + 探针零张力 + 缺陷为纯文档域 → 开窗 = R4 清偿窗非实施窗；GATE 6 测试构成义务对零代码变更轮免{零新子阶段——r117/r115/r113 零增量先例一致}；GATE 1 六命令仍全量实测{零代码 ≠ 零验证}
3. **vector 家族零张力登记（张力探针 P1-P5）**：五内建运行时执法全 fail-closed{非向量/越界/索引类型/append 非向量/head 向量}；静态 Any 参数 = vector-value-design D5 A4 Dynamic 既有登记诚实边界{Vector HM 类型构造行维持触发式——TC-SIGS 扩表同族需求信号未至}；双侧表行 parity 五行同构{oracle BUILTIN_SIGS ↔ krf TC-SIGS}
4. **8 原语不变性第二十七轮验证**：零新原语零通道零新操作码零 CoreExpr/IR 变体零代码变更——纯文档域轮（历次最轻量轮族）
5. **下一演进登记**：触发式零信号维持或自然信号——按用户指令序或自然信号{tc-sigs §7 余二行均 Stage 2+ 值模型域外；#15 需 next22.md 未上传维持}

---

## r144 —— read-line 签名条目窗：静态-动态元数 parity 补全 + R4 审计链文档债清偿（1884 新基线）

**日期**：2026-11-14　**类型**：登记域外行清偿实施窗 + 同窗 R4 文档债四件当场清偿（净 +32——**1884 基线自 r144 起**）　**驱动**：用户三链指令（①继续推进 目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施 ②按照 docs/sop.md 流程结合 docs/lang-design/ 下的项目演进流程（整体任务视角）与 docs/develop/v0/tech-debt-register.md、docs/develop/v0/stage-3/t3plus-trigger-audit.md 等（局部任务视角），按照推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）——**M1 指令开窗第四十九例**（推荐序裁定：r143 收口态登记册触发式实施项全清零 + T3+ 14 行零信号{本轮六族例行监测复测：match 用户面 = r122 交付物本体非新信号 + net/extern/@ 零命中 + next22.md 未上传} + 门控任务七项全闭 → 用户指令①「遇缺陷直接推进」逐行走查全部登记域外表 → 三类不可行排除{Stage 2+ 域外 / 成熟度不在位 / 纯语料信号零张力} → **唯一可行行 = tc-sigs-parity-design §7「read-line 签名条目」行**——且走查实测发现该行触发前提「运行时执法缺位先行」**事实性过时**：运行时元数执法自 FS-4 起即在位{代码 fail-closed + 09-stdlib §3 r8 注记 + 20 §4 B3 契约三源确证——r140-r143 四轮走查以过时前提排除本行 = 审计链 R4 文档债本轮修正}；张力探针实证静态-动态行为缺口：`(read-line 1)` check 面静默通过 vs 运行时 E0004 fail-closed）

### 交付链（214-a..214-f）

- **214-a 走查 + 探针实测**：r143 态核验{第十二轮会话首检零回退——git 61a82c3 干净 + 双包在位} + 六族例行监测复测零信号 + 全部登记域外表走查（tc-sigs §7 余三行 + member-rename §7 余四行 + vector/ffi/use-decl/handle-multi-arm/handle-expr-pos §7 + nested-resume D5-D7 + match §7）→ 三类不可行排除 → 唯一行 read-line + **R4 文档-代码冲突四件实证**{builtins.rs 表尾注释「runtime does not check arity」vs 代码 1563 行 fail-closed 执法在位 + negative_vm_tests 模块注释同款冲突[同文件 338 行测试实证相反] + 09-stdlib/20 B3 单源确证} + 张力探针：`(read-line 1)` 静态 ok vs 运行时 E0004；`(read-int 1)` 对照 E0005 正典形；改名 `(rl 1)` 静默（r135 D12 miss-skip 现状）
- **214-b 设计单源**：read-line-sig-design.md v1.0{D1-D8 + §7 域外四行——D1 窗口定性[登记行清偿非缺陷修复 + R4 四件同窗] + D2 双侧签名行设计[read-int/read-num 家族形锁步] + D3 结果 Unknown 裁定[命中 Str ∪ EOF Nil——8 kind 冻结无 union，r142 member D3 先例] + D4 邻位维持[运行时逐字节不动 + E0006 门先行 + 值位 A4 + 限定名 krf 通用路径] + D5 派生链影响[miss-skip 零在世 miss——防御性路径保留裁定] + D6 计数 parity + D7 锚翻转预算 + D8 测试矩阵 32 case{8正+24负 1:3}}
- **214-c 实施**：builtins.rs BUILTIN_SIGS read-line 行{fixed(&[], Unknown)——r144 注释} + 表尾注释/r42 注记改写 + builtin_name_exists 特例移除{扁平名 62 单源} + builtin_sigs/builtin_sigs_with_renames 文档注释前提清偿 + check.krf TC-SIGS read-line 行 + tc-infer-app/tc-sig-resolve 注释前提清偿 + negative_vm_tests 模块注释 R4 修正 + neg_r135_hm_read_family_a4_carryover 前提翻转{断言维持——零参合法} + ktf_tc_sigs_parity 头注 61→62 + **ktf_read_line_sig_tests 32 case 新门**{8 正[零参双面 clean + Unknown 流消费 + if 条件 + 改名派生 clean + 值位 A4 + 表级 parity{扁平 62 + sig 形} + 派生闭合{io/read-line 限定 + 改名键 + 防御 miss-skip}] + 24 负[扁平/ktf/多参元数 E0005 + oracle 面同拒 + 改名链收紧 N5/N6 + E0006 门先行 ×2 + 运行时 E0004 维持 + 限定名双裁定 + EOF 子进程探针 + 反查双名 + 层正交 E0005/E0004 + 邻位维持 ×3 + prelude 组合 + 深嵌套消费 + 双层合意 + 无别名面 + 嵌套实参位 + 多错误收集 + 跨面计数 parity + 语料锚零翻转七件]}——纯静态签名面（表行插入 + 注释修正——零机制变更）
- **214-d GATE 1**：六命令 clean 全绿{build 零告警 + check --workspace --all-targets 0:0 + fmt 零 diff{cargo fmt 顺修} + clippy -D warnings 0{unused import + dead code + needless borrow 三顺修} + **test --release --workspace 1884:0:0 净 +32——1884 基线自 r144 起**} + 审计×6 EXIT 0 ×6{280 case} + CLI 双语法面零回归{十路径：fib ⇒144 双面 + closures ⇒42 双面 + nested ⇒540 + multiarm ⇒217 + vector ⇒9 双面 + ffi ⇒9 双面 + effect_stress ⇒120 双面 + handle_expr ⇒327 双面 + check ok{2/9/5/38} + test 2/2} + bench OBS-C{fib VM 计算 74.5ms 带内[启动基线 38.6ms 剥离——>65ms 触发线不满足维持——零信号}
- **214-e 治理对账**：tc-sigs-parity-design v1.3{§7 read-line 行翻转清偿关闭} + member-rename-design v1.4{§7 io read 族行翻转清偿关闭——read-int/read-num r140 + read-line r144 全族覆盖} + 09-stdlib §3 io 行 r144 注记 + RELEASE r144 节 + README 三处 + matrix r144 行/总量 1884 + t3plus v1.64 + guide v1.29{M1 第四十九例——行权态二十九次} + rec 105 + worklog 三链
- **214-f 收口**：r144 包三验 + web 五件 + Agent Browser E2E + 投票

### 关键裁定

1. **触发前提事实性过时裁定（D1——审计链 R4 文档债）**：read-line 运行时元数执法自 FS-4 起即在位（r141 b1730b5 统一消息形重锚）——r140-r143 四轮走查以 builtins.rs 过时表尾注释为据排除本行 = 审计读注释未读代码的 R4 文档债；本轮三源确证（代码 + 09-stdlib + 20 B3 契约）后行权清偿
2. **结果位 Unknown 裁定（D3）**：read-line 命中 Str ∪ EOF Nil——8 kind 冻结下无 union 构造（Typed Racket 形不可表达），read-int/read-num 家族先例（同构并集域 Int∪Nil）+ r80 零误报契约（fresh 零约束流）三依据裁定 Unknown
3. **层正交维持（D4/原则 42）**：静态 E0005「expected 0..0, got N (static check)」与运行时 E0004「read-line requires 0 arguments, got N」双层各自正典形非镜像义务；运行时面逐字节不动
4. **miss-skip 存废裁定（D5）**：read-line 入表后底层名全表覆盖（62 扁平名）——r135 D12 派生 miss-skip 成为零在世实例防御性路径；裁定保留（确定性边界——未来表扩张容错臂价值高于删除收益）
5. **8 原语不变性第二十六轮验证**：零新原语零通道零新操作码零 CoreExpr/IR 变体零 VM 分派变更——纯静态签名面（表行插入 + 注释修正）

---

## r143 —— handle 表达式位窗：双侧 Reader primary 位分派（1852 新基线）

**日期**：2026-11-14　**类型**：登记域外行清偿实施窗（净 +32——**1852 基线自 r143 起**）　**驱动**：用户三链指令（①继续推进 目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施 ②按照 docs/sop.md 流程结合 docs/lang-design/ 下的项目演进流程（整体任务视角）与 docs/develop/v0/tech-debt-register.md、docs/develop/v0/stage-3/t3plus-trigger-audit.md 等（局部任务视角），按照推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）——**M1 指令开窗第四十八例**（推荐序裁定：r142 收口态登记册触发式实施项全清零 + T3+ 14 行零信号 + 门控任务七项全闭 + #15 需 next22.md 未上传 → 用户指令①「遇未完成窗口直接推进」逐行走查全部登记域外表{八设计单源 §7 + tc-sigs §7 + 登记册 + 触发表} → 三类不可行排除{Stage 2+ 域外 / 成熟度不在位[extern 别名符号空间机制缺口——P5/P6 探针 E0019/E0022 实证] / 纯语料信号且零张力} → **唯一可行项 = handle-multi-arm-design §7 末行「目标面 handle 表达式位」**{张力探针五连实证：P1 define 值位 ⇒100 / P3 实参位 ⇒101 / P7 if 条件位 ⇒11 [S-expr 面三位形全合法] vs P2 let 值位 E0001 / P8 嵌套位 E0001 [目标面全域 fail-closed]}；成熟度全在位{r132 多臂 + r133 嵌套 resume 双底座 + r110 表达式位 if / r121 match 值形先例通道}）

### 交付链（213-a..213-f）

- **213-a 走查 + 探针实测**：八设计单源 §7 域外表 + tc-sigs §7 余三行 + 登记册 + 触发表 14 行全量走查 → 张力探针五连实证（S-expr 面三位形全合法 vs 目标面 E0001 fail-closed）+ extern 别名成熟度探针（P5/P6——符号空间机制缺口实证不可行）；**CLI 双入口双面表达力 parity 缺口第五连候选成立**{r125 require / r130 import as / r131 use 选择树 / r132 handle 多臂——四连先例}
- **213-b 设计单源**：handle-expr-position-design.md v1.0{D1-D8 + §7 域外六行——D1 同形裁定{语句位与表达式位共享一形——r110/r121 先例第三例} + D2 脱糖同构零机制变更{8 原语不变性第二十五轮} + D3 双侧最小变更{≈12 行} + D4 r133 穿线无损延拓 + D5 语义边界维持{块形 protected 域外 + resume 表达式位域外 + halt/pass 语句位域外} + D6 双登记{02 v7.23 + 20 v1.30} + D7 测试矩阵 32 case + D8 零锚翻转{rg 全库实证}}
- **213-c 实施**：种子 target.rs parse_primary KwHandle 前置臂 + 镜像 target_reader.krf parse-primary cond 臂 + ktf_handle_expr_position_tests 32 case{8 正 + 24 负 1:3——五位置形 E2E{let 值位/实参位/if 条件位/嵌套 protected/group} + 跨面值 parity 327 + 语句位零回归复锚 217/540 + 双 Reader 正典渲染 parity + 位域维持电池 + 跨阶段语义族} + 语料对 effect_handle_expr.{ktf,krf} ⇒327 双面{语料族 13:13} + 02 v7.23 EBNF 注记 + 20 v1.30 皮肤字典注记
- **213-d GATE 1**：六命令 clean 起步全绿{build 零告警 + check 0:0 + fmt 零 diff{一处顺修} + clippy -D warnings 0{unused import 顺修} + **test 1852:0:0 净 +32**} + 审计×6 EXIT 0{280 case} + CLI 双语法面零回归{八路径：fib 144 双面 + closures 42 + nested 540 + multiarm 217 + vector 9 + ffi 9 + stress 120 + handle_expr 327 新语料双面 + check 计数锚 + test 2/2} + bench fib 72.844ms 带内{>65ms 触发线不满足维持——OBS-C 零信号}
- **213-e 治理**：对账九件{README 三处 + RELEASE r143 节 + matrix r143 行 + examples/README 13:13 + t3plus v1.63 + guide v1.28 + rec 104 + 02/20 双登记 + worklog 三链}
- **213-f 收口**：r143 包三验{独立解包净构建 + 包内 1852 复跑 + e5close EXIT 0 + fib 144 双面 + handle_expr 327 双面} + web 五件 + Agent Browser E2E + §6.3 投票

### 关键裁定

1. **同形裁定（D1）**：表达式位 handle 与语句形共享一形——parse_primary 前置分派（r110 if / r121 match 同构第三例）；语句位零回归（parse_stmt_or_expr 先行分派维持）
2. **零机制变更（D2）**：脱糖产物与语句位逐字节同构——expander/compiler/HM/VM 零触及；8 原语不变性第二十五轮{零新原语零通道零新操作码零 CoreExpr/IR 变体——纯 Reader 位域扩展}
3. **r133 穿线无损延拓（D4）**：handler_k save/restore 在表达式位同样生效——嵌套 protected 内 resume 维持域外 fail-closed
4. **零锚翻转（D8）**：rg 全库实证「expected an expression, got KwHandle」零锚定——纯加性位域扩展，既有负例全维持

---

## r142 —— member/assoc 静态面双缺陷窗：'sigf 'any 规则位兜底误位清偿 + member Bool 谓词化建模宽化（1820 新基线）

**日期**：2026-11-12　**类型**：登记域外行清偿实施窗 + 同窗双缺陷当场清偿（净 +32——**1820 基线自 r142 起**）　**驱动**：用户三链指令（①继续推进 目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施 ②按照 docs/sop.md 流程结合 docs/lang-design/ 下的项目演进流程（整体任务视角）与 docs/develop/v0/tech-debt-register.md、docs/develop/v0/stage-3/t3plus-trigger-audit.md 等（局部任务视角），按照推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）——**M1 指令开窗第四十七例**（推荐序裁定：r141 收口态登记册触发式实施项全清零 + T3+ 14 行零信号 + 门控任务七项全闭 + #15 需 next22.md 未上传 → 用户指令①「遇缺陷直接推进」逐行走查期间**张力探针实测发现双缺陷**[212-a] → tc-sigs §7「member/assoc 结果类型 Bool 建模复审」登记行独立评估面行权 + 同窗双缺陷当场清偿{§20.3 同类路径全量审查}）

### 交付链（212-a..212-f）

- **212-a 走查 + 张力实测**：六族信号 grep 零{match 语料 = r122 交付物本体 / net-extern-@ 0 / vector = r138 交付物本体} + next22.md 未上传 + 全部登记域外表走查 → tc-sigs §7 member/assoc 复审行（独立评估面）张力探针 → **双缺陷实测成立**：`(member 2 (list 1 2 3))` 兜底误报 + `(head (member 2 lst))` E0005 假阳性{运行时 ⇒ 2 正确} + `(if (member 2 lst))` 运行时严格 bool if 纪律 E0004 发现{正典谓词形态 = is-pair 包裹}。
- **212-b 设计单源**：member-any-bool-model-design.md v1.0{D1-D8 + §7 域外四行——D1 双缺陷定性[P1×2] + D2 'any 短路臂单点插入[镜像 oracle Any=>true/var=>None 双臂] + D3 member Bool→Unknown 双侧宽化[对齐 assoc 既有行 + r80 零误报契约 + B2 净化先例] + D4 三层宽度影响论证 + D5 邻位维持 + D6/D7 计数 parity 与锚翻转预算[实测修正版] + D8 测试矩阵 32 case}。
- **212-c 实施**：check.krf tc-rule-one **'any 短路臂**{cond 顶部单臂双收——具体类型 + tvar 两路径一并收口} + TC-SIGS member 行 **'bool → 'unknown** + builtins.rs BUILTIN_SIGS member 行 **TcType::Bool → TcType::Unknown**{双侧锁步}——纯静态面三处最小变更{零机制变更}。
- **212-c 测试**：ktf_member_any_model_tests 新门 32 case{8 正 + 24 负 1:3——**精确计数断言形态**[补 r140 contains-any 掩盖缺口]：'any 位具体类型全族 clean + 值消费张力翻转锚[head (member 2 lst) ⇒ 2 双面] + is-pair 正典谓词 + tvar 无污染 + fresh 泛化多消费位 + 跨阶段 .ktf 全链 E2E + 参数位真检出维持十六负例 + arity/邻位/if 条件/E0022/运行时双族负例}。
- **212-d GATE 1**：六命令 clean 全绿{build 9.38s 零告警 + check 0/0 + fmt 0 diff + clippy -D warnings 0 + **test --release --workspace 1820:0:0 净 +32**} + 审计×6 真实 EXIT 0 ×6{280 case} + CLI 双语法面零回归{fib ⇒144 双面 + closures ⇒42 双面 + nested ⇒540 + multiarm ⇒217 + vector ⇒9 + effect_stress ⇒120 + ffi ⇒9 + check ok + test pass 2/2} + bench fib 72.595ms 带内{OBS-C <65ms 不满足维持}。
- **212-e 治理对账**：tc-sigs-parity-design v1.2{§7 member/assoc 复审行翻转清偿关闭} + t3plus audit v1.62 + guide v1.27{M1 第四十七例——行权态二十七次 + 速查卡行权态行 R4 顺修} + RELEASE r142 节 + README 三处 + **rec 100/101/102/103 四件补债**{R4 文档债——r139/r140/r141 三轮 worklog 声称的 rec 100-102 实况未落盘[包内实证]——当轮发现当轮修正} + worklog 三链。
- **212-f 收口**：r142 包三验 + web 五件 + Agent Browser E2E + 投票。

### 关键裁定

- **缺陷①定性（P1——r140 移植偏差）**：'sigf 逐参路径 tc-rule-one 无 'any 臂——具体类型实参全落 else 兜底误报{`(member 2 …)` 第一参任何具体类型} + tvar 实参 unify 伪 tcon('any)；**污染跨用位传播**{stash-built 修复前对照实证：r140 三语料重锚 11 项中 5 项实为污染伪产物——expander 第 6 项 `string-append requires str, got ?`{`?` = 伪 kind 渲染} + compiler 第 2 项 `type mismatch: ? and str` + reader 全 3 项}——比本地误报刻画更严重；r140 门覆盖缺口根因{P02 无 member 'any 正例 + N05 contains-any 断言形态掩盖}。
- **缺陷②定性（P1——E0005 假阳性族 TD-030 先例）**：member Bool 谓词化建模值消费假阳性{`(head (member 2 lst))` 静态误报 vs 运行时 ⇒ 2}——D3 宽化四依据{r80 零误报契约首要优先级 + assoc 既有行对齐 + B2 净化先例方向 + 8 kind 冻结下唯一零误报复现}；**谓词位静态零变化**{fresh unify bool 合法} + **运行时严格 bool if 纪律维持**{E0004 truthy 显式拒绝——Bool 建模的静态-运行时错位一并消除} + 正典谓词形态 = is-pair 包裹{tc-sigs §7 行文原意}。
- **语料锚翻转三处（r140 伪真检出误判修正）**：expander.ktf 6→5 / compiler.ktf 2→1 / reader.ktf 3→0{5 个 'any 污染伪诊断消除——5 个 num-into-int + 1 个 tail-nil 真检出全维持；krf ⊆ oracle 方向合法宽松化}；check.krf 2 / build.krf 0 / cli.krf 0 / fib.krf 0 全维持。
- **8 原语不变性第二十四轮验证**：零新原语零通道零操作码零语法——纯静态签名面（'any 短路臂 + 结果位宽化——数据行/规则臂级最小变更）。

## r141 —— 消息文本统一窗：krf/hm 静态检查九族诊断消息收敛 oracle op+got 形 + tc-type-str 渲染器（1788 新基线）

**日期**：2026-11-12　**类型**：登记域外行清偿实施窗（净 +32——**1788 基线自 r141 起**）　**驱动**：用户四链指令（①以 r140 tar.gz 替换回退态[第十次 z.ai web 回退恢复——rustc 丢失级环境自助 + 1756:0:0 逐位复验] ②继续推进目标语言设计的实现窗[遇缺陷/未完成窗口则按推荐顺序直接推进进入对应窗口开始具体实施] ③按 docs/sop.md 流程结合 lang-design 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 ④同步完整打包项目 tar.gz 并同步完整更新 web page）——**M1 指令开窗第四十六例**（推荐序裁定：r140 收口态登记册触发式实施项全清零 + T3+ 14 行零信号 + 门控任务七项全闭 + #15 需 next22.md 未上传 → 用户指令②「遇未完成窗口直接推进」逐行走查全部登记域外表 → **唯一行** = tc-sigs-parity-design §7「krf/hm 消息文本统一」行{触发判据明文含「语料/用户信号」+ 成熟度全在位——D5 刻画 + 双侧构造点实读 + r139 消息面标准轮同族先例}；其余各行全部不可行{TD-026 ②③④ interop/token 语料信号 / pub(scope)·is-procedure·值位 Callable·prelude pub(scope) = Stage 2+ / TD-005 架构位未在位 / TD-003/015 IrGraph 信号 / TD-008 DEFER / TD-024 Stage 3+ 评估 / read-line 运行时执法缺位先行 / extern 别名 = 设计成熟度未在位 / Vector HM 类型构造 = oracle 侧无构造子[方向守卫前置阻塞] / 语料信号族全部零命中 / 恒态无触发两行})

### 交付链（211-a..211-f）

- **211-a 恢复轮**：第十次 z.ai web 回退确认{磁盘 r134 态 + 根 worklog r133 + web r134} → rustc 丢失级恢复{scripts/rust/setup.sh——rustc 1.98.1} → r140 包单源替换 → 六命令 clean 起步全绿{build 21.60s + **test 1756:0:0 逐位复现**} + 审计×6 EXIT 0 + CLI 双语法面零回归 + bench 带内。
- **211-b 设计单源**：diag-msg-unify-design.md v1.0{D1-D8 + §7 域外四行}——D1 方向裁定{krf → oracle 形三依据：§12 信息保全 + oracle 零变更零 Rust 风险 + fallback 一致性收口} + D2 tc-type-str 渲染器{镜像 Ty::render 全变体 + Unicode α/→/≥ 实证} + D3 op 名穿线七函数{不采全局暂存} + D4 九族统一映射表{逐字节镜像含族间空格沿袭} + D5 arity want 五位点{≥{mn}/{mn}..{mx}/{k}} + D6 计数 parity 维持论证{守护面 = 诊断数非文本} + D7 锚翻转预算{短针存活五族 + 翻转 44 处} + D8 测试矩阵{32 case 8 正 + 24 负 1:3}。
- **211-c 实施**：check.krf 渲染器十件{tc-digit-str cond 链 + tc-int-str 递归除余 + tc-str-cat 二元折叠[运行时 string-append 严格二元 E0004] + tc-type-str/tc-types-str/tcon-kind-str + arity-want-str} + op 名穿线七函数{tc-infer-builtin-fixed/tc-check-pos-rules/tc-check-rule/tc-rule-all/tc-rule-one/tc-rule-pair-list 各 +1 参——入口协议零变更 + TC-RENAME 派生链 underlying 归因自动保持} + 九族 22 位点统一{requires 7 kind + num a number 措辞 + head/tail + if 条件 + uncallable + arity 五位点 want/n 计数 + unify 冲突双侧渲染 + occurs α{i} and {t}[自应用位复用返回 fresh 构造箭头型]} + 兜底族⑨防御位维持——纯 .krf 面零桥变更零 Rust 机制变更。**同窗缺陷当场清偿 ×3**：① tc-types-str 3 参 string-append{真 bug——静态 2..2 + 运行时 E0004 双报——自举报料锚 2→5 检出} → tc-str-cat 折叠顺修；② nth 索引 (mod n 10) num 型入 int 位{r140 真检出同族} → cond 链 tc-digit-str 替代；③ r102 命名守卫新注释 `->` → 全角箭头顺修——自举报文回归 r80 锚 2 逐位维持。
- **211-c 测试**：ktf_diag_msg_parity_tests 新门 32 case{8 正 + 24 负 1:3——九族全文本锚 + 双面 parity 五族 + arity 三 want 形 + Unicode α/→/≥ 全链 + r135 改名派生归因锚[underlying 名] + 多违反收集计数 2 + 跨阶段 vector 消费} + 锚翻转 45 处锁步{typecheck 15 + member_rename 4 + tc_sigs_parity 18 + 审计 5[m3/r2 msg 形 + e5close + r2 E03 探针 contains 位——非 msg 形 grep 漏网当轮补获]} + stdlib 运行时锚 4 处免翻转{VM 消息面未变更}。
- **211-d GATE 1**：六命令 clean 起步全绿{clean + build --release 20.36s 零告警 + check 0/0 + fmt 0 diff + clippy -D warnings 0 + **test --release --workspace 1788:0:0 净 +32**} + 审计×6 EXIT 0 ×6{280 case} + CLI 双语法面零回归{fib ⇒144 双面 + nested 540 + multiarm 217 + closures 42 + vector ⇒9 + ffi ⇒9 + effect_stress ⇒120 + check ok 2/9/5/38 + test 2/2} + bench 带内{fib 71.99ms——<65ms 触发线不满足维持} + 九族探针逐字节实录{`nth requires int, got str(static check)` … `cannot construct an infinite type: α25 and (α25 → α26)(static check)`}。
- **211-e 治理对账**：tc-sigs-parity-design v1.1{§7 消息文本统一行翻转清偿关闭} + t3plus audit v1.61 + guide v1.26{M1 第四十六例——行权态二十六次} + RELEASE r141 节 + matrix r141 行/总量 1788 + README 三处 + rec 102 + 根层 l + worklog 三链。
- **211-f 收口**：r141 包三验 + web 五件 + Agent Browser E2E + 投票。

### 关键裁定

- **D1 方向裁定**：统一方向 = krf 面收敛到 oracle 的 op+got 形（不采 oracle 降级族形）——三依据：§12 最优>最小{op+got 三元组信息保全 vs 族形一元} + r139 消息层形态标准{Rust 编译器惯例恒携带操作位 + 期望 + 实际} + oracle 零变更 = 零 Rust 面风险{全部变更收敛 check.krf 单文件——r140「纯 .krf 面」同型最优风险面}；同程序形态经 fallback 路由产出两种文本的用户面不一致消除。
- **D6 计数 parity 守护面不动**：r80 契约守护面 = 诊断数非消息文本{tc-sigs D5 明文}——本窗零计数变更{同位点同记录次数下文本替换}→ 方向守卫 krf ⊆ oracle 维持无需重证；check.krf 自举报文 r80 锚 2 逐位维持 = 守护面不动的直接实证。
- **D2 Unicode 全链**：α{U+03B1}/→{U+2192}/≥{U+2265} 经 bootstrap Reader/VM/桥/CLI 字节保持{探针 `(string-append "α" "≥3" "→")` ⇒ α≥3→}；变元号跨面差异{α{i} 面内独立}登记永久域外{计数 parity 为守护面}。
- **8 原语不变性第二十三轮验证**：零新原语零通道零操作码零语法——纯消息文本面（krf 面诊断表达力收敛）。

## r140 —— TC-SIGS Oracle 对齐窗：check.krf 签名表 24→61 逐行同构扩表 + sig 语言定点扩展（1756 新基线）

**日期**：2026-11-11　**类型**：登记域外行清偿实施窗（净 +32——**1756 基线自 r140 起**）　**驱动**：用户三链指令（①继续推进目标语言设计的实现窗[遇缺陷/未完成窗口则按推荐顺序直接推进进入对应窗口开始具体实施] ②按 docs/sop.md 流程结合 lang-design 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）——**M1 指令开窗第四十五例**（推荐序裁定：r139 收口态登记册触发式实施项全清零 + T3+ 14 行零信号 + 门控任务七项全闭 + #15 需 next22.md 未上传 → 用户指令①「遇未完成窗口直接推进」逐行走查全部登记域外表 → **唯一行** = member-rename-design §7「TC-SIGS 子集不对称」行{触发判据明文含「用户信号」+ 成熟度全在位——oracle 61 行 + 派生链 TC-RENAME/tc-sig-of + r126/r135 同族先例}；其余各行全部不可行{TD-026 ②③④ interop/token 语料信号 / pub(scope) Stage 2+ / TD-005 残留架构位未在位 / TD-003/015 IrGraph 信号 / TD-008 DEFER / TD-024 Stage 3+ 评估}）

### 交付链（210-a..210-f）

- **210-a 设计单源**：tc-sigs-parity-design.md v1.0{D1-D8 + §7 域外表}——37 行逐行同构映射表（变长 5 + 定形齐次 23+既有修正 1 + 'sigf 定形异参 5） + D2 'sigf 形 + D3 结果映射{Unknown→fresh 镜像 oracle——非 Dynamic} + D4 新 kind 逐位裁定{'int tvar→Num 域宽化[方向守卫防御位] + 'list/'pair tvar 零约束 + 'sym} + D5 消息族沿袭 + D6 方向守卫维持论证 + D7 锚翻转预算 + D8 测试矩阵。
- **210-b 实施**：check.krf TC-SIGS **24→61 行**（37 新行 + string-append 既有行修正{(sig 0 999999 'str 'str)→(sig 2 2 'str 'str)——运行时恒 2 参[args.len()!=2→E0004] + oracle fixed(&[Str,Str],Str)——krf 面静态放行 1/3 参调用的原登记分歧清偿}） + tc-infer-builtin 'sig/'sigf 双形分派 + tc-infer-builtin-fixed/tc-check-pos-rules/tc-sig-result 三新函数 + tc-rule-one 新 kind 四臂 + tvar 域特化臂{Int→Num 统一} + tc-rule-msg 新 kind 四消息——纯 .krf 面零桥变更零 Rust 变更。
- **210-c 测试**：ktf_tc_sigs_parity_tests 32 case{8 正 + 24 负 = 1:3}——全形族双面 E2E 值锚 + 新成员双面 check 零诊断 + 'sigf tvar 位 + Int 参 Num 域宽化锚[方向守卫防御位] + 结果类型映射 + string-append 2 参修正锚 + 派生链双面{kerf-list 改名执法正负 + io 改名 str 执法} + 跨阶段语料回归 + 位置独立违反{'sigf 逐位} + 元数族 + 多违反收集 + 运行期/静态一致性。**同窗锚翻转**：hm_production_switch 七语料锚三件{expander.ktf 0→6 + compiler.ktf 1→2 + reader.ktf 0→3}——逐条裁定 = 真检出{num 入 int 索引位族[nth/drop 位收 mod/length 结果——oracle 同报"krf 6⊆oracle 80/2⊆27/3⊆31 方向守卫全维持"] + unify 冲突位}；**同窗缺陷清偿**：r102 命名守卫命中新注释 `->` ×5 → 全角箭头顺修。
- **210-d GATE 1**：六命令 clean 起步全绿{clean + build --release 21.59s + check 0/0 + fmt 0 diff + clippy --all-targets -D warnings 0 + **test --release --workspace 1756:0:0 净 +32**} + 审计×6 EXIT 0 ×6{280 case 全 APPROVED} + CLI 双语法面零回归{fib 75025/⇒144 双面 + nested 540 + multiarm 217 + closures 42 + higher_order + vector ⇒9 + check ok 2/9/5/38 + test pass 1/total 1 + ffi ⇒9 + effect_stress ⇒120} + bench 带内{gc_stress 109ms}。
- **210-e 治理对账**：member-rename-design §7 TC-SIGS 行翻转[清偿关闭] + io read 族行重锚{read-int/read-num 已覆盖——read-line 维持缺位} + t3plus audit v1.60 + guide v1.25{M1 第四十五例} + RELEASE r140 节 + matrix r140 行/总量 1756 + README 三处 + rec 101 + worklog 三链。
- **210-f 收口**：r140 包三验 + web 五件 + Agent Browser E2E + 投票。

### 关键裁定

- **D4 Int 参 Num 域宽化**：'int 参对 tvar 统一至 (tcon 'num) 而非 'int——镜像 oracle `Num|Int => Some(Ty::Num)`；若 krf 直统一 'int 则 (define (f x) (nth '(1) x)) 后 (f 1.5) 形 krf 报 oracle 不报 → krf ⊄ oracle 方向破坏——本裁定为方向守卫防御位（p04 正锚 + D6 论证）。
- **D3 Unknown→fresh**：变长/定形 'unknown 结果 → (tc-fresh) 而非 (tcon 'dynamic)——镜像 oracle `Unknown => self.fresh()`；未解变元经泛化 ∀α 与 oracle 同构（Dynamic 会丢失后续约束参与）。
- **member/assoc 结果 Bool 建模沿袭**：运行时命中返回子列表/条目 Pair、未中 Bool——oracle 行为 Bool 谓词化建模；严格 bool if 纪律下谓词用法需 is-pair 包裹（设计 §7 域外登记——oracle 行语义复审属独立评估面）。
- **8 原语不变性第二十二轮验证**：零新原语零通道零操作码零语法——纯静态签名面扩展（krf 面执法面向 oracle 收敛）。

## r139 —— 英语编码统一窗：单一编码语言首选-英语立法 + 错误提示/开发面/CLI 面全量英文化（1724 基线零增量维持）

**日期**：2026-11-11　**类型**：代码域语言标准化重构窗（r112 注释语言标准轮同型第 2 例——零测试函数增量，**1724 基线第 r139 轮**）　**驱动**：用户四链指令（①检查当前项目中的编码语言，使用单一英语编码，将错误提示标准化，并将「单一编码语言首选-英语」添加到 docs/sop.md 中 ②继续推进目标语言设计的实现窗[遇缺陷/未完成窗口则按推荐顺序直接推进进入对应窗口开始具体实施] ③按 docs/sop.md 流程结合 lang-design 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 ④同步完整打包项目 tar.gz 并同步完整更新 web page）——**M1 指令开窗第四十四例**（推荐序裁定：r138 后登记册触发式实施项维持全清零 + T3+ 14 行零信号 + 门控任务七项全闭 → 用户指令① = 唯一合法需求信号——错误提示 = 目标语言诊断面[20-surface-conventions E00xx 族] = 语言设计面正当窗口；r112 注释标准窗先例同型）

### 交付链（209-a..209-f）

- **209-a 审计 + 立法**：代码域 CJK 全量盘点{4109 distinct 字面量 / 5922 出现——crates 1112 行 59 文件 + tests 3512 行 + 审计脚本 908 行 + bootstrap 语料 + src/main.rs CLI 面 + setup 脚本} + 单源翻译字典四轮迭代{kerf_dict + ext + r3 + r4 四件——whole-literal 覆盖关键消息 + 短语最长匹配分割 + 343 单字兜底——同一中文原文恒得同一英文译文[parity 双侧字节级一致前提]} + **SOP v13.21→v13.22**：§10.5「注释语言标准」升格「单一编码语言标准——首选英语」{四层覆盖：注释层[r112 沿袭] + 错误提示层[r139 新增——r112 双豁免位错误消息豁免撤销] + 开发面消息层[r139 新增] + CLI 输出面[r139 新增]；豁免位收窄：设计文档 + Unicode 能力测试夹具登记制白名单 + worklog/归档历史工件；消息层形态标准 = Rust 编译器惯例} + §10.2 清单末项 + §16.1 变更日志行。
- **209-b/c 双侧转换 + 锁步**：**~5.9K 字面量全量英文化**{148 文件——Rust 种子侧 + bootstrap .krf/.ktf 镜像侧同步 + tests/ 期望锚锁步 + 审计脚本期望面锁步}；转换机制 = 字典驱动纯函数{E00xx 消息族/VM messages.rs 单源/check.krf tc-fail 族/expander xperr 族/compiler.ktf cerr 族/test.krf 汇总行——双侧逐位一致}；**同窗修复四族**{① 空格边界三缺陷[strip 吞尾随空格 76 件 + 折叠吞对齐空格 + 
 转义后幻影空格] ② 反引号引号奇偶定位修复[「X」→`X` 空格规则] ③ Unicode 测试数据损伤三件回滚[中/世界/日本語/éλ 夹具 + 字.repeat(66) 截断夹具] ④ r138 滞留审计锚两件[stage1 A09 quote-向量已合法化重锚 OkDual + e5close P03 N1 计数 38→40]}。
- **209-d GATE 1**：六命令 clean 全绿{clean + build --release 21.58s 零告警 + check 0/0 + fmt 0 diff + clippy --all-targets -D warnings 0 + **test --release --workspace 1724:0:0 逐位维持**} + **审计×6 EXIT 0 ×6**{280 case 全 APPROVED——审计期望面锁步 + 双语锚[所有权/演进矩阵]} + CLI 双语法面零回归{fib 75025/⇒144 双面 + nested 540 + multiarm 217 + closures 42 + higher_order (1 4 9 16 25) + vector 双面同输出 + check ok 2/9/5/38 双面 + test "PASS    1 / pass 1 / total 1 (fail 0)" + ffi ⇒ 9} + bench 带内{effect_stress 170ms + gc_stress 106ms}。
- **209-e 治理对账**：SOP v13.22 + 本 RELEASE r139 节 + matrix r139 零增量行 + t3plus v1.59{M1 第四十四例行权注记} + README{质量状态行 + 测试计数行 1687→1724 + 包行} + 转换工具归档 scripts/r139-english-surface/{字典 + 应用器四件——R4 归档纪律} + worklog 三链 + rec 100。
- **209-f 收口**：r139 包三验 + web 五件{status 前插 + hero 1724 徽章 + footer v7.96 + download README r139 节 + stats 双源对账} + Agent Browser E2E。

### 关键裁定

- **豁免位收窄裁定**：r112「字符串字面量豁免」收窄为「Unicode 能力测试夹具白名单」——以 CJK 文本为被测对象本身的字符串数据豁免（io.ktf 演示语料 + Reader CJK 往返 + 字符串全序码点 + test runner Unicode 截断边界）；其余字符串一律英文。
- **双语侧单源字典纪律**：错误消息转换的唯一合法机制 = 单源字典（同一中文原文恒得同一英文译文）——Rust 种子侧与 bootstrap 镜像侧字节级一致是 parity 测试的守护前提；手工逐侧翻译 = 违例。
- **语义不变纪律**：消息文本变更但行为面不变——测试计数逐位维持 1724:0:0；同窗发现的 Unicode 测试数据损伤（中→in 类）即刻回滚修复。
- **8 原语不变性第二十一轮验证**：零新原语零通道零操作码零语法——纯消息面重构轮。

## r138 —— TD-002 向量值类型窗：双面集合字面量 + 双侧脱糖 + 值模型 + 五内建（1724 新基线）

**日期**：2026-11-10　**类型**：TD-002 全清偿实施窗（值模型 + 净 +37——**1724 基线自 r138 起**）　**驱动**：用户三链指令（①以 r137 tarball 替换回退态 + 继续推进 目标语言设计的实现窗[遇缺陷/未完成窗口则按推荐顺序直接推进进入对应窗口开始具体实施] ②按 docs/sop.md 流程结合 lang-design 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）——**M1 指令开窗第四十三例**（推荐序裁定：登记册触发式实施项维持全清零{TD-026 行②③④语料门控——CFunction「语言面无函数指针落地通路」P3 冻结形状 + CStruct 无宿主消费者 + 在册可注册表扩容自身语料门控} + 六族语料信号实测全零 → 速查卡第 5 位臂序走查 → **TD-002 = 唯一可行实施项**：门控任务 #5 = target-language-gated-tasks 七项中**唯一未完成项**（用户指令「未完成窗口直接推进」直接命中——r122 match #6 同族先例） + t3plus 审计行 14 自荐路径「推荐经门控任务 #5 路径——目标语法自然携带集合字面量」 + 判据②「目标语法轮开窗联动」——指令点名续行目标语言设计实现轮链 = 轮联动臂命中 + 成熟度全在位{S-expr 词法 StxDatum::Vector 既有 + target LBracket 域外诊断位 + expander 拒绝位双侧定位 + 值模型扩展先例族 Symbol r5/Foreign TD-010/Match r122/HandleGroup r136}）

### 交付链（208-a..208-f）

- **208-a 恢复笔（第十次环境回退）**：PATH 丢失级{rustc 工具链实体在位——export PATH 即恢复 + .bashrc/.profile 持久化} + r137 tarball 校验{diff -rq 归零——树与 tarball 逐位一致} + git HEAD c8c763a 干净态 + GATE 1 基线复验 1687:0:0 逐位 + CLI 双语法面零回归{fib 75025/⇒144 双面 + ffi ⇒ 9 双面}。
- **208-b 设计单源**：vector-value-design.md v1.0{D1-D10 + §7 域外表七行}——D1 不可变设计{构造期无环 + 可变族域外} + D2 全脱糖{表达式位/quote 位递归——零 CoreExpr/IR/操作码[原则 9 冻结维持]} + D3 值模型与 GC{元素槽位制 + children 臂} + D4 五内建族{kerf-vector 模块 + BUILTIN_SIGS oracle 五条} + D5 HM A4 Dynamic{TC-SIGS 不扩表——krf ⊆ oracle 契约维持} + D6 位置纪律{primary 受理 + postfix 索引域外维持} + D7 诊断分配{运行期族复用——码表零净增} + D8 渲染括号形可回读 + D9 空载不变式{1687 基线逐位不变} + D10 测试矩阵{36 case 9:27 = 1:3}。
- **208-c 实施全链**：**值模型**{kerf-runtime：HeapObj::Vector(Vec<GcRef>) + alloc_vector + get_vector + children 臂 + ValueSlot::Vector 标记 + Debug/PartialEq；kerf-vm：Value::Vector + type_name "vector" + eq_value 引用相等 + render_vector 括号形 + box/unbox/collect_roots/trace_refs 四桥 + slot_terminal/render_slot 臂} + **五内建**{builtins.rs：vector/vector-length/vector-ref/vector-append/is-vector + err_vector_op 消息单源{messages.rs + lib.rs 再导出} + BUILTIN_SIGS 五条 + STDLIB_MODULES vector 五行{local = flat——("list","list","list") 先例} + 模块组 "kerf-vector" + 计数锚四族{47→52 行/57→62 扁平/104→114 全授权/92→102 零授权}} + **双侧脱糖**{种子：expander.rs 表达式位翻转{StxDatum::Vector → Apply{Var("vector"), elements}} + core_forms.rs quote 位翻转{quote_vector_apply/elem 递归} + datum_to_value Vector 臂转内部防御；自举：expander.ktf 表达式位翻转{vec 节点 → apply 节点} + quote 位翻转{quote_vector_apply/elem/elems 三函数} + datum_to_value 防御臂} + **目标面 Reader**{种子 target.rs parse_primary LBracket 臂{逗号分隔 + 尾逗号 fail-closed + Eof 断点——call-args 先例} + 镜像 target_reader.krf parse-primary `[` 臂 + vec-items/vec-items-tail + nd-vec + 桥 "vec" 臂} + **N1 可见面与导入面**{N1_CORE_NAMES + vector/is-vector{38→40 名} + RESERVED_ALLOW + kerf-vector{E0019 白名单}} + **测试**{ktf_vector_value_tests 36 case + runner 挂载 + 8 处测试文件 Vector 渲染占位翻转} + **语料对**{vector.{ktf,krf} ⇒ 9 双面同输出}。
- **208-d GATE 1**：六命令 clean 起步全绿{build 20.65s 零告警 + check 0/0 + fmt 顺修归零 + clippy --all-targets -D warnings 0 + **test 1724:0:0 净 +37**} + 审计模块过滤器全绿 + CLI 双语法面零回归{fib 75025/⇒144 双面 + ffi ⇒ 9 双面 + closures 42 + check ok + multiarm 217 维持} + 新能力生产面实证{vector.{ktf,krf} 双面 ⇒ 9 同输出 + check ok 2 原型/24 常量/10 全局引用/107 指令} + bench 111-112ms 带内{OBS-C 不满足维持}。
- **208-e 治理对账**：TD-002 全清偿{登记册 v0.4.17——索引行终态 + 头部版本链} + t3plus v1.58{行 14 翻转 + 头部消费注记 + `#(` 监测项语义勘正} + gated-tasks v1.1{#5 翻转——七项全闭终态} + replacement-map §5 缺口 5 清偿 + RELEASE r138 节 + matrix r138 增量行/总量行 1724 + 02 v7.22{§8.13.1a vector_lit 产生式} + 20 v1.29{§14 第十四映射族} + README 包行 + worklog 三链。
- **208-f 收口**：r138 包三验{git archive 单源} + download README r138 节 + web 五件 + Agent Browser E2E + §6.3 投票。

### 语义要点

- **D2 全脱糖（本窗最重裁定）**：`[a b c]` → `(vector a b c)`——as-if-written 纪律{Var 携字面量位点 scopes——词法捕获语义与手写一致（neg_vector_shadowing 实证）}；quote 位递归字面量脱糖{运行期构造 = quote pair emit_literal_pair 同律}；**零 CoreExpr/IR/操作码**——原则 9 九原语冻结维持{match r122 同律}；8 原语不变性第二十轮：**历次最轻量值模型窗**{比 r137 更轻——分辨/编译/VM 主链零变更，变更面 = Reader 皮肤 + expander 脱糖 + 值模型 + 内建}。
- **D3 元素槽位制**：HeapObj::Vector(Vec<GcRef>)——每元素经 box_value 装箱{list 内建同律}——GC children 臂 = Pair 两元素枚举的直接推广；D1 不可变性 ⇒ 构造期无环{渲染防御性 seen-map 保留}；eq? 引用相等{Pair 同律}。
- **D4 导入门控律**：vector 构造器 + is-vector 入 N1 可见面{字面量可用性强制——脱糖目标必须免 import}；vector-length/ref/append import 门控{list 域 length/append 同律}；TC-SIGS 不扩表{生产 check.krf 路径 vector 调用 A4 Dynamic——运行期 one_arg/two_args/域执法兜底 fail-closed；krf ⊆ oracle 契约维持——r137 extern D7 同律}。
- **皮肤映射语义勘正**：向量正典形 = **方括号**（`[a b c]`）非 `#(...)`——`#(` 为 t3plus 监测项的历史笔误{r71 项设当时未读种子 parser.rs parse_list_like OpenBracket→is_vector 交付态}——r138 语言面定稿勘正重锚。
- **既有程序零回归（原则 27）**：零 vector 字面量程序——展开面零变化 + 值模型加性 + 内建注册加性{+5 名零冲突}——1687 基线逐位不变。

**1687 → 1724（净 +37）**——ktf_vector_value_tests 新文件 36 case（9 正 + 27 负 = 1:3）+ 锚翻转三组净 +1；**1724 基线自 r138 起**；13 行触发族其余判定零变化{TD-002 行 14 清偿——14 行中第 14 行终态}；**TD-002 全清偿——目标语言门控任务七项全闭**{#1-#4 切换窗 r106-r120 + #5 r138 + #6 match r122-r124 + #7 文档族}；8 原语不变性第二十轮{零新原语零通道零新操作码零 CoreExpr/IR 变体——历次最轻量值模型窗}；下一演进 = 触发式零信号维持或自然信号——按用户指令序或自然信号。

## r137 —— TD-026 行① FFI extern 声明族语言面窗：extern 声明 + 扁平符号空间调用面 + 编译臂发射（1687 新基线）

**日期**：2026-11-09　**类型**：TD-026 行① 部分清偿实施窗（语言面 + 净 +32——**1687 基线自 r137 起**）　**驱动**：用户三链指令（①以 r136 tarball 替换回退态 + 继续推进 目标语言设计的实现窗[遇缺陷/未完成窗口则按推荐顺序直接推进进入对应窗口开始具体实施] ②按 docs/sop.md 流程结合 lang-design 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）——**M1 指令开窗第四十二例**（推荐序裁定：第九次 z.ai web 回退恢复[rustc 丢失级] + r136 基线 1655 逐位复验后——r136 后登记册触发式实施项全清零 + 六族语料信号实测全零[表达式位 handle/块体 halt-pass/裸臂/resume 多参/extern/@] → 推荐序落到 T3+ 14 行手动臂中与「目标语言设计实现窗」需求语义唯一匹配项 = TD-026 行①{登记册「语言面语法/extern 声明形式 = Stage 3 锚」明文行 + 手动触发臂「开启 TD-026 窗——实施 FFI 语言面形式」 + r74/r99 先例锚指令即需求信号本体}；成熟度匹配 = VM 面机制基座 r30 全在位 + P1 冻结形状在位 + ffi-ownership-model v0.1.0 行为规格冻结）

**交付链（207-a..207-f）**：
- **恢复 + 治理修复（207-a/207-a2）**：第九次 z.ai web 环境回退{rustc 丢失级} + r136 tarball 单源解包替换{rsync --delete + diff -rq 归零} + git 恢复笔 d8cab0b{49 文件 r135-superseded→r136 增量} + Rust 1.98.1 第九次重装 + GATE 1 基线复验 1655:0:0 逐位 + 审计×6 + CLI 双语法面零回归 + r136 语义三探针{组分派 15 + 同胞非保护 207 + 组消费 145}；治理修复三件{根层 worklog 206 条目断链承接 + TC-SIGS 子集不对称重登记{oracle 56 vs krf 23——krf ⊆ oracle 契约方向合法} + 触发指南 v1.22 R4 顺修{切换窗 r120 全闭 + next18-21 已吸收——v1.21 滞留 34 轮}}；恢复轮实测：核心名改名{use kerf_pair::{head as h}}双面实证通过——r135 首实施态 E0022 边界已随 N1 派生段清偿，旧登记不复活{R4 代码为准}。
- **设计单源（207-b）**：ffi-language-surface-design.md v1.0{D1-D10 十裁定 + §7 域外表七行}——kind 三词表 D1{int/str/ptr = ExternKind 消费子集语言面同构} + 驱动面收集与剥离 D2{import 先例同构——expander 零变更} + 五重声明校验 D3{形状/可注册性 E0012 编译期/契约 E0026/查重/能力 E0006} + 分辨层 extern 类 D4{IrVar::Extern——词法帧后 global 兑底前 + Symbol 名字匹配卫生不可穿透} + 发射臂 D5{Apply 头识别 + 值位 fail-closed} + 运行表构造 D6{声明 ∩ 在册可注册 ∩ 能力授予 → run_program_with_externs} + E0022 并入 D7{防御性} + Keyword 28 名 D8 + E0026 诊断族 D9 + 32 case 门 D10。
- **实施（207-c——双侧全链）**：Keyword::Extern{第 28 名——E0020 共享域扩展 + ALL 28 计数锚} + 种子 parse_extern_decl{target.rs——Unit 零参 kind 表双关 = parse_typed_params 先例} + 镜像 parse-extern-decl 族{target_reader.krf 六函数——TKEYWORDS extern 入表} + 驱动面{collect_extern_face + verify_extern_positions_stx{.ktf 块内 = 读者层 E0001 + .krf = Stx 层 E0026 双层纪律} + verify_extern_capabilities + strip 扩展 + E0022 面并入 + run_front 表构造} + 在册可注册表 AVAILABLE_EXTERNS{driver/ffi.rs——write-stdio 唯一条目：CPointer(Char) → CInt(Usize) + requires_write} + 分辨层{ir.rs IrVar::Extern(Rc<str>) + LowerCtxt.extern_face + resolve_var 延拓 + lower_module_with_externs 加性入口 + 捕获分析跳过} + 编译臂{compile.rs Apply 头识别 + compile_module_with_externs 加性入口 + 值位/赋值位 E0026 拒绝 + compiler.ktf EXTERN_TAG[string-to-symbol 铸——r116 第二规范化先例] + rv_loop extern 咨询 + compile_var 值位 cerr + compile_ffi_args——PushConst SymLit + 实参 A1 序 + Op::CallExternal #43 冻结四方同步维持} + 桥双参协议{bootstrap compiler.rs call_entry 第二参数——r135 lchk-check-program 先例} + expander Keyword::Extern 结构拒绝臂{表达式位背栈} + FrontOutput.extern_decls{缓存快照自动携带}。
- **语料 + 测试**：ffi.{ktf,krf} 语料对{require io, write + extern 声明 + 调用 ⇒ 9 双面——真实宿主 I/O 往返 + Φ 窗口协议} + ktf_extern_decl_tests 32 case{8 正 + 24 负 1:3——正向八族：E2E 双面 + check 跨阶段零诊断{global_ref_count=0——extern 名不入全局池} + 双 Reader 正典 parity 三形 + 嵌套 fn + 混合程序 + 操作数位 + S-expr 正典形 + 零参形状门；负向二十四族：形状六 + 位置三 + 可注册性双 + 契约双 + 能力双 + 查重三 + 值位双 + 运行期 E0011 双 + 读者层双{消息+Span 字节级镜像}}。
- **GATE 1（207-d）**：六命令 clean 起步全绿{build 20.26s 零告警 + check 0/0 + fmt 0 diff + clippy --all-targets -D warnings 0{三处顺修后归零} + **test 1687:0:0 净 +32**} + 审计×6 EXIT 0 ×6 + CLI 双语法面零回归{fib 144 双面 + nested 540 + multiarm 217 双面 + closures 42 + higher_order + check + test 2/2} + **新能力 CLI 生产面实证**{ffi.ktf/ffi.krf ⇒ 9 双面 + check ok 0 全局引用 + r136 语义维持 207} + bench 129-131ms 带内{OBS-C 不满足维持}。
- **治理对账（207-e）**：TD-026 行① 部分清偿{登记册 v0.4.16——行②③④维持注册面显式拒绝触发式} + t3plus v1.57 + 本 RELEASE 节 + matrix r137 增量行/总量行 1687 + 02 v7.21{§8.13.1a extern_decl 产生式} + 20 v1.28{皮肤字典第十三映射族} + README 三处 + rec 98 + worklog 三链。
- **收口（207-f）**：r137 包三验{git archive 单源} + download README r137 节 + web 五件 + Agent Browser E2E + §6.3 投票。

**语义要点**：
- **扁平符号空间（ffi-ownership-model §4）**：extern 名以 Symbol 名字匹配解析（词法帧后 global 兑底前）——宏卫生不可穿透 + 顶层 define/import/N1 撞名编译期拒绝 + 值位 fail-closed（E0026「仅调用位」——无 extern 函数值）。
- **能力门（r65/118-a「permission belongs to the capability domain」）**：write-stdio 经 io write 能力令牌门{E0006——FFI 写通道与 io 语言通道同享授权令牌}——首个 FFI 通道能力执法实例。
- **冻结机制消费（8 原语不变性第十九轮）**：零新原语零通道零新操作码——#43 CallExternal r30 冻结四方同步维持{enum ↔ count 47 ↔ 04 §1 ↔ compiler.ktf OP-*}；CoreExpr/ModuleItem 零新变体{D2 剥离决策——kerf-core 零代码}；比 r136 更轻{无内核形态增量}。
- **既有程序零回归（原则 27）**：零 extern 声明 → 空表 + 零分辨面变化 + 零发射变化——1655 基线逐位不变{净 +32 全部来自新门族}。

**1655 → 1687（净 +32）**——ktf_extern_decl_tests 新文件 32 case（8 正 + 24 负 = 1:3）；**1687 基线自 r137 起**；14 行触发族判定零变化{TD-026 行① = 触发式行权清偿非新信号}；**TD-026 行① 部分清偿——登记册触发式实施项维持全清零**{行②③④触发式：CStruct/CFunction interop 语料 + token 消费语料——设计单源 §7 域外表}；下一演进 = 触发式零信号维持或自然信号——按用户指令序或自然信号。

---

## r136 —— TD-033 组安装语义窗：多臂 handle 组安装 + VM 组消费机制 + handle-group 核心形式（1655 新基线）

**日期**：2026-11-09　**类型**：TD-033 组安装语义实施窗（VM 机制变更 + 净 +32——**1655 基线自 r136 起**）　**驱动**：用户三链指令（①继续推进 目标语言设计的实现窗[遇缺陷/未完成窗口则按推荐顺序直接推进进入对应窗口开始具体实施] ②按 docs/sop.md 流程结合 lang-design 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）——**M1 指令开窗第四十一例**（推荐序首位三源一致：#15 需 next18.md 未上传 + TD-032/TD-031/HM 全清偿 + r134/r135 域外登记全清零 → TD-033 = 唯一剩余可开实施窗项{触发判据「臂体 perform 兄弟标签语料消费信号或用户指令」之用户指令臂命中——r74 先例锚}）

**交付链（206-a..206-e）**：
- **设计单源（206-a）**：handle-multi-arm-design.md v1.1 §8 D11-D19 九裁定{语义切换 D11 + S-expr handle-group 核心形式 D12 + CoreExpr/节点协议 D13 + VM 多 entry 组消费 D14 + 编译发射 D15 + HM/check D16 + 诊断面 D17 + 锚翻转/语料 D18 + 四方同步申报 D19} + §2 映射表翻转 + §7 TD-033 行清偿；开窗判据链六项全过；环境恢复实录{第八次 z.ai web 回退——PATH 丢失级{工具链在位非安装丢失} + 1623 基线逐位复验}.
- **实施（206-b——双侧全链）**：CoreExpr::HandleGroup/HandleArm{kerf-core 十 walk 位 + 图 IR + code_value 双 walk + ANF 拒绝臂} + VM 机制{HandlerFrame.entries 多 tag 匹配 + **组消费**[命中帧整体替换——兄弟 entry 随帧消亡] + 快照整组惰性化 + GC 根集经帧捕获槽拼接} + **新操作码 INSTALL_HANDLER_GROUP #46**{交错臂操作数变长布局——四方同步：enum[尾部保号] ↔ 测试 47 ↔ 04 §1 ↔ compiler.krf OP-* + 桥 46 臂} + compiler 双侧{compile.rs emit_handle_group + compiler.ktf compile_handle_group 族——T→H₁..H_N→B→tk 序确定性} + hm.rs/typecheck.rs 泛化{A4 纪律维持} + expander 双侧{expand_handle_group + expander.ktf hg_walk——≥2 臂强制 + D17 消息族 + 组内重复标签 fail-closed} + Keyword::HandleGroup{27 名——E0020 共享域扩展} + target.rs/target_reader.krf 折叠翻转{≥2 臂 → handle-group 生成；单臂字节级零回归} + 三桥 + check.krf unsupported 跳过 + driver 七 walk 位 + eval.rs 参考路径.
- **GATE 1（206-c）**：六命令 clean 起步全绿{build 20.18s 零告警 + check 0/0 + fmt 0 diff + clippy -D warnings 0{两处顺修} + **test 1655:0:0 净 +32**} + 审计×6 EXIT 0 + CLI 双语法面零回归{fib 144 双面 + nested 540 + multiarm 217 双面 + closures 42 + higher_order (1 4 9 16 25) + check 2/9/5/38 + test 2/2} + **组安装新语义 CLI 三实证**{组分派 ⇒ 15 双面 + 同胞非保护 ⇒ 207} + bench ~165ms 带内{OBS-C 维持不满足——sandbox 负载态}.
- **治理对账（206-d）**：TD-033 清偿{登记册 v0.4.15} + t3plus v1.56 + 本 RELEASE 节 + matrix r136 增量行 + 04 v5.6{操作码 47 + 效应组 3 + ext1 entries 泛化} + 02 v7.20{§8.13.1a 翻转 + Keyword 27} + 06 [HANDLE-INSTALL] 实施注记 + 20 v1.27{第十二映射族行翻转} + README 两处 + rec 97 + worklog 三链.
- **收口（206-e）**：r136 包三验{git archive 单源} + download README r136 节 + web 五件 + Agent Browser E2E + §6.3 投票.

**语义要点**：
- **组安装（D11/D14）**：多臂 [≥2] `handle e { A(p,k) => b₁, B(p,k) => b₂ }` → 全臂一帧——任一命中分派 + **整组消费**{兄弟 entry 随帧消亡：兄弟臂对臂体/恢复后计算皆不再保护——Koka 式 [HANDLE-INSTALL] 读法}；嵌套语义仍可经显式嵌套手写{D11}；单臂 = 1-entry 退化零行为变更{D1}.
- **值分叉实证（D18）**：同胞非保护 ⇒ 207{r132 嵌套语义为 205} + 组消费后逃逸 ⇒ 145{r132 嵌套语义为 135}——两读法在动态案例上可观测分叉，测试锚钉住 r136 语义.
- **8 原语不变性（D19）**：零新原语零通道；VM 指令 +1{INSTALL_HANDLER_GROUP #46——TD-033 登记范围明示的机制变更，诚实申报}；架构审计 10 名表{HandleGroup = Handle 原语组安装载体非新语义原语}.

**1623 → 1655（净 +32）**——ktf_handle_multiarm_tests 32 → 64（16 正 + 48 负 = 1:3）；**1655 基线自 r136 起**；14 行触发族判定零变化{TD-033 = 触发式行权清偿非新信号}；**TD-033 清偿关闭**——登记册触发式实施项全清零；下一演进 = 触发式零信号维持或自然信号（handle-multi-arm §7 余项均语料信号门控）——按用户指令序或自然信号.

---

## r135 —— 域外三项清偿窗：HM 签名派生 + 门控面改名感知（E0006 反查）+ prelude 模块实例面（1623 新基线）

**日期**：2026-11-08　**类型**：域外三项族清偿实施窗（设计先行 + 净 +32——**1623 基线自 r135 起**）　**驱动**：用户三链指令（①继续推进 目标语言设计的实现窗[遇缺陷/未完成窗则按推荐顺序直接推进进入对应窗口开始具体实施] ②按 docs/sop.md 流程结合 lang-design 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）——**M1 指令开窗第四十例**（推荐序首位 = r134 收口笔触发式余项成熟度匹配排序——member-rename-design.md §7 前三行同族域外项{HM 签名派生 + 门控面改名感知 + prelude 模块实例面}；TD-033 组安装语义居后维持{VM 机制变更风险高}；设计单源 member-rename-design.md v1.2 §8 D11-D16）

**交付链（205-a..205-e）**：
- **环境恢复（205-a）**：第七次 z.ai web 环境回退{cargo 工具链丢失 + 329 文件纯模式位噪声[100644→100755 零内容差——r133 同型] + 根层 worklog 204 条目断链[kerf 内部三链为权威源]}→ Rust 1.98.1 第七次重装 + 模式位 normalize + GATE 1 恢复复验 1591:0:0 逐位 + 审计×6 + CLI 零回归 + r134 能力三探针。
- **HM 签名派生（D12——双侧）**：Rust oracle `builtin_sigs_with_renames`{r39 限定名派生同构——renamed → underlying sig 追加循环 + underlying miss 跳过[read-line 无签名沿袭]} + type_check_diags fallback 臂数据流补线 + krf 面 check.krf 入口协议扩展{`lchk-check-program nodes renames` 双参 + 全局 TC-RENAME + `tc-sig-resolve` 链式解析} + 桥面 heap_renames VM 关联表——**值位恒 Dynamic A4 纪律维持**；krf ⊆ oracle 契约维持{双侧同派生}。
- **门控面改名感知（D13——E0006 反查）**：D8 io 行撤销 + verify_io_capabilities renames 感知{verify_refs Var 臂：roster miss → renamed 反查 underlying → 按 underlying 检查 declared} + 双名诊断{「pr（io 成员 print）需要 write 能力——改名绑定不改变能力要求」}——**renamed 绑定与 underlying 同享授权令牌**；**N1 域派生段（实施补裁定 ①'）**：io/core/pair/char 的 flat 循环零迭代{underlying 恒 N1 被滤除}→ 补专用派生段{member_renames 非 prelude 行 + underlying ∈ N1 → flat push renamed + rename_binds push}。
- **prelude 模块实例面（D14——Stx 层注入）**：D8 prelude 行撤销 + front_from_forms 管线 1.62 注入{`(define renamed local)`——preamble 段后用户 forms 前 + member_rename_spans 平行数组[选择列表元素位——用户 use 声明归因]}——**增量别名语义（D14-③）**：underlying 可用性三源全不动{define 面[自有 HOF] / N1 面[cons/is_* 重导出] / flat 面[nth/drop 重导出]}——`map as m` 后 map 依然可用{与七模块替换语义形成域对比}；**flat 增量双名（实施补裁定 ③'）** + **rename_binds 零 push（实施补裁定 ④'）**{运行时绑定单路径 = Stx 注入 define——run_front 双注入撞 E0004 重复定义}；prelude HM = 泛化闭包自然类型{无需签名派生}。
- **当轮缺陷当场清偿（§20.3 同类路径全量审查）**：实施探针暴露三缺口全数同窗清偿{N1 域派生段缺失[E0022] / flat 单名 E0022 误报[nth 引用] / 双注入 E0004}——三探针-定位-清偿循环；clippy 一处顺修 + fmt 归零。
- **测试门**：`ktf_member_rename_tests` 32 → 64（净 +32：8 正 + 24 负 = 1:3——D8 双拒绝锚退役迁移{→ E0006 双名新锚 + 增量别名正例} + 新增 28 case{HM 派生域检查十族[含 krf ⊆ oracle parity + 值位 Dynamic 维持 + takeover 零误报 + 双面诊断一致] + io 反查五族[read/newline 未授权 + 能力维度精确性 + 首违规阻断 + 限定名混合] + prelude 六族[保留字 E0020 + 注入 define 撞 E0004 + 未定义成员 E0024 + 非符号操作数 + nth 别名与 local 并存]}）。
- **GATE 1**：六命令 clean 起步全绿（build 18.74s 零告警 / check 0/0 / fmt 0 diff / clippy --all-targets -D warnings 0 / test **1623:0:0**）+ 审计×6 EXIT 0 ×6 + CLI 双语法面零回归{fib 144 双面 + check 2/9/5/38 + nested 540 + higher_order (1 4 9 16 25) + test 2/2} + **新能力 CLI 生产面五实证**{sa ⇒ R135 hm-ok + sa(1,2) E0005 + pr 授权输出 R135 io-rename-ok + m ⇒ (1 4 9) + p 未授权 E0006 双名} + bench ~106ms 带内（OBS-C <65ms 触发线不满足维持——sandbox 负载态）。
- **治理**：t3plus v1.55 + member-rename-design v1.2{§7 前三行翻转 + §8 D11-D16 + 实施补裁定回写} + matrix r135 行/总量 1623 + README 两处 + rec 96 + 根层 l + worklog 三链{含根层 worklog 204 断链承接}；02/20/22 零变更（域外语义清偿非语法增量——皮肤字典维持 v1.26）。

**语义要点**：域外三项族清偿 = r134 收口笔触发式余项的成熟度匹配兑现——HM 派生（apply 位签名 = underlying 签名的派生条目——r39 限定名派生的成员改名同构）+ E0006 反查（改名不产生新能力面——renamed 同享 underlying 授权令牌）+ prelude 增量别名（Stx 层注入 + 三源可用性不动）。member-rename §7 触发式域外登记**前三行清零**{余项均恒态/Stage 2+ 族}；8 原语不变性第十七轮验证{零新原语零通道零 VM 指令——全部前端域}。

---

## r134 —— use 域外二项清偿窗：成员重命名（`use m::{a as x}` 三元组双侧受理）+ module 头部选择形（1591 新基线）

**日期**：2026-11-08　**类型**：use 域外二项清偿实施窗（设计先行 + 净 +33——**1591 基线自 r134 起**）　**驱动**：用户三链指令（①继续推进 目标语言设计的实现窗[遇缺陷/未完成窗则按推荐顺序直接推进进入对应窗口开始具体实施] ②按 docs/sop.md 流程结合 lang-design 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）——**M1 指令开窗第三十九例**（推荐序首位 = r133 收口笔明文首项——use 窗遗留触发式域外二项{成员重命名 + 选择形 module 头部}；设计载体 use-declaration-design.md v1.0 D3/D6 触发判据在位 = 本窗即其登记触发载体；设计单源 member-rename-design.md v1.0 D1-D10）

**交付链（204-a..204-e）**：
- **设计单源 + 归一化方案裁定**：`docs/develop/v0/stage-3/member-rename-design.md` v1.0——D1-D10 十裁定（三元组消费链单点 / 目标面 D3 翻转 / 替换式注入 / 运行时注入方案 B / 头部扫描双侧 / ImportFace 加性 / 同域查重 / io-prelude 域外 / Span 契约 / 锚翻转三组）。**ARCH-A 方案对比**：alias 重写方案不适用于平铺名（限定名跳 E0022 而改名绑定不跳——重写产物与反向锚冲突）→ **方案 B 运行时注入**（run_front 注册后附加注入 globals[renamed] = underlying Builtin Rc 共享——与限定名注册同构；E0022 反向锚精确 + CoreExpr 零触碰 + HM A4 零误报）。
- **实施（六件代码）**：种子 `kerf-reader/target.rs`（parse_use_decl 成员后 as 受理臂 + 「期望成员重命名标识符」专用消息族 + 首槽 as 维持既有面）+ 镜像 `bootstrap/target_reader.krf`（use-member-alias/use-member-alias-sep 新函数 + sel-member-build as 字面符号）+ **driver 消费链**（collect_import_items 三元组解析 + 形状执法三消息族{E0002 码族} + ImportFace 加性字段 member_renames/rename_binds + 派生段替换注入{injected_names/flat_underlying} + verify_import_face D8 io/prelude 域外前置 + D7 同域查重 + FrontOutput.member_rename_binds + run_front 附加注入）+ expander 双侧（core_forms.rs 头部扫描选择列表受理 + expander.ktf module_names_walk/sel_members_all_syms）——S-expr Reader 零变更 + CoreExpr 零触碰{原则 27 加性}。
- **替换语义（D3）**：`use kerf_string::{append as sa};` ⇒ `sa` 平铺可用{underlying 分派体} + 原 `string-append` E0022{反向锚精确性实证} + local `append` E0022{D65 过滤不变} + `string/append` 限定形不受影响{模块级关系维持}。
- **HM A4 Dynamic**：renamed ∉ 签名表 → check.krf tc-infer-var / hm.rs infer_expr 双侧保守 Dynamic——check 面零扩展零误报（触发式：签名表派生窗口）。
- **测试门**：`ktf_member_rename_tests` 32 case（8 正 + 24 负 = 1:3——改名 E2E/跨语法值 parity/限定不变/混合成员/module 头部双面 E2E/正典渲染 parity/HM A4 check 零诊断 + 形状执法 11 族 + E0017 同域 2 + E0024/E0022 反向锚 + io/prelude 域外 + E0002 头部 3 + E0019 双 + parity 5）+ ktf_use_decl_tests 锚翻转三组（D3 双形锚退役 + 首槽 as 消息锚翻转 + D6 双侧拒锚退役迁移 + 新增 13a/13b/13c 三负例维持 8:25 ≥ 1:3）。
- **GATE 1**：六命令 clean 起步全绿（build 19.18s 零告警 / check 0/0 / fmt 0 diff / clippy --all-targets -D warnings 0 / test **1591:0:0**）+ 审计×6 EXIT 0 ×6 + CLI 双语法面零回归{fib 75025/144 双面 + check 2/9/5/38 + multiarm 202 双面 + nested 540 双面 + closures 42 + test 3/3} + 新能力 CLI 生产面三实证{rename 双面 ⇒ R134 cli-ok + module 头部选择形 ⇒ m hdr-ok} + bench 105-109c 带内（OBS-C <65ms 触发线不满足维持）。
- **治理**：t3plus v1.54 + use-declaration-design v1.1{D3/D6 翻转} + 02 v7.19 + 20 v1.26 + README 三处 + rec 95 + 根层 l + worklog 三链。

**语义要点**：成员重命名 = S-expr 面选择形扩展窗（r131 D3/D6 登记触发载体兑现）——替换式注入 + 运行时分派体共享（零 CoreExpr 重写）；module 头部选择形 = expander 头部扫描双侧受理（r131 D6 域外边界退役）；use 窗遗留触发式域外登记**清零**（余项均触发式：HM 签名派生 / 门控面改名感知 / 模块实例面）。

---

## r133 —— 嵌套块内 resume 窗：r128 域外登记清偿（嵌套块 κ 穿线）双侧 Reader + 同窗 VM 续体边界截断清偿（1558 新基线）

**日期**：2026-11-07　**类型**：嵌套 resume 实施窗（恢复轮前置 + 设计先行 + 净 +32——**1558 基线自 r133 起**）　**驱动**：用户三链指令（①继续推进 目标语言设计的实现窗[遇缺陷/未完成窗口则按推荐顺序直接推进进入对应窗口开始具体实施] ②按 docs/sop.md 流程结合 lang-design 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）——**M1 指令开窗第三十八例**（恢复轮前置：第六次 z.ai web 保存机制回退——kerf 树回退 r113，r132 tarball 单源恢复 + 1526:0:0 逐位复验后行权；推荐序首位 = 成熟度匹配排序——r131 三部曲检验{S-expr 语义全既有 + driver 零变更 + EBNF 在位}——设计单源 nested-resume-design.md v1.0 D1-D10）

**交付链（203-a..203-f）**：
- **恢复轮（203-a/203-b）**：z.ai web 保存机制第六次回退（git HEAD r113 + 477 文件纯模式位噪声）→ r132 tarball 单源解包替换{保 .git + diff -rq 归零} + git 恢复笔 93b3680 + Rust 1.98.1 第六次重装 + GATE 1 复验 1526:0:0 逐位 + 审计×6 + CLI 零回归。
- **设计单源**：`docs/develop/v0/stage-3/nested-resume-design.md` v1.0——D1-D10 十裁定（开放域 if 臂/闭包体/嵌套 handle 臂体语句位/尾位 + κ 注入域 innermost 臂 + 遮蔽 shadow-aware + 闭包捕获开放 + 受护式 κ=nil 收窄 + 表达式位域外 + 跨臂显式续体收窄 + halt/pass 直位形维持 + 死代码延拓 + 32 case 门）。
- **实施（双侧 Reader 嵌套穿线）**：种子 `kerf-reader/target.rs`（`handler_k` 字段 save/restore——parse_handle 入口 take/每臂 install/闭 `}` restore + parse_block_inner 态穿线）+ 镜像 `bootstrap/target_reader.krf`（`kcell` 闭包胞{let 可变捕获惯用法} + block-loop 读胞 + parse-handler-body 入口装胞 + parse-handle save/restore）；零脱糖零新原语{原则 31；8 原语不变性第十五轮验证}。
- **同窗 VM P1 清偿（深帧非尾 resume 陈旧帧残留）**：闭包捕获探针暴露既有潜伏缺陷——续体恢复仅弹一帧，臂体帧残留帧链 → 恢复 RET 级联以蹦床 ret_pc 重入臂体 → STORE_LOCAL 吞句柄值污染闭包槽（「不可调用的值：int」——字节码+错误面完全定位；三变量隔离 isoA/isoB/isoC/isoD 定界：handle 特异 + κ 捕获特异 + 非尾位调用特异）；双侧清偿 = `ContinuationValue.boundary`{perform 时 handler 帧索引} + Call/TailCall 双续体臂边界截断循环——r128 臂内语句/尾位 resume 语义不变（单帧弹出已达边界）。
- **测试门**：`ktf_nested_resume_tests` 32 case（8 正 + 24 负 = 1:3——含嵌套等价字节码全等门{共享符号表} + 双 Reader 正典渲染/错误面字节级 parity + isoB VM 清偿回归锚 + check 跨阶段消费）+ 语料族平行对 `effect_nested_resume.{ktf,krf}`（12:12——双面 ⇒ 540）+ 同窗测试锚翻转 ×3{ktf_stress_corpus 三负锚转正——r131 先例同构}。
- **GATE 1**：六命令 clean 起步全绿（build 17.85s 零告警 / check 0/0 / fmt 0 diff / clippy --all-targets -D warnings 0 / test **1558:0:0**）+ 审计×6 EXIT 0 ×6 + CLI 八路径零回归{含嵌套 resume 540 双面} + bench 70.031ms 带内（OBS-C <65ms 触发线不满足维持）。
- **治理**：t3plus v1.53 + switch-window-plan §4 match 行 R4 顺修{r121-r124 已实施态回写} + 02 v7.18 + 20 v1.25 + README 三处 + rec 94 + 根层 l + worklog 三链。

**语义要点**：嵌套块 resume = 纯皮肤域扩展（S-expr 词法作用域镜像——κ 注入既有零新语义）；受护式/表达式位/跨臂显式续体 = 诚实边界登记（触发式后续信号）；VM 边界截断 = 续体恢复的帧链卫生（r132 fvo 族同窗清偿先例延续——帧记账纪律）。

---

## r132 —— handle 多臂 / halt / pass 窗：皮肤字典第十二映射族（多臂嵌套脱糖 + 终止流糖 + 穿透重构）双侧 Reader + fvo 同窗缺陷清偿（1526 新基线）

**日期**：2026-11-06　**类型**：handle 多臂实施窗（设计先行 + 净 +32——**1526 基线自 r132 起**）　**驱动**：用户三链指令（①继续推进 目标语言设计的实现窗[遇缺陷/未完成窗口则按推荐顺序直接推进进入对应窗口开始具体实施] ②按 docs/sop.md 流程结合 lang-design 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）——**M1 指令开窗第三十七例**（推荐序首位 = r131 收口笔唯一设计先行态余项{切换窗后续域外登记末项 handle 多臂/halt/pass——需 resume ∈ {0,1} 合围扩展设计}——设计单源 handle-multi-arm-design.md v1.0 D1-D10）

**交付链（202-a..202-f）**：
- **环境恢复 + 基线复验**：r131 态 1494:0:0 逐字复现（git HEAD 0e31c34 clean）。
- **设计单源**：`docs/develop/v0/stage-3/handle-multi-arm-design.md` v1.0——D1-D10 十裁定（单臂零回归 / 多臂嵌套脱糖先写臂外层 / sibling 分歧诚实登记{TD-033} / pass 重构 / halt 尾值糖 / 重复标签 fail-closed / 位形词目标面本地 / 臂形两元纪律 / 保序声明 / Span 契约）。
- **实施（第十二映射族双侧 Reader）**：种子 `kerf-reader/target.rs`（Tk::KwHalt/KwPass + parse_handle 多臂循环 + parse_handler_body 四形 + parse_halt_form/parse_pass_form）+ 镜像 `bootstrap/target_reader.krf`（TKEYWORDS 增词 + handle-arm-loop/handle-arm/handle-fold + parse-halt-form/parse-pass-form）；`handle e { A(p,k) => b₁, B(p,k) => b₂, }` → 嵌套单臂 handle 脱糖；`halt`/`halt(v)` → 尾值（nil/expr）；`pass` → `(perform (cons (quote T) p))`——expander/compiler/VM 全链零变更（原则 31；8 原语不变性第十四轮验证）。
- **同窗 P1 缺陷清偿（fvo 条件入栈/无条件弹出错配）**：多臂 E2E 暴露既有潜伏缺陷族——compiler.ktf fvo handle/fn 臂 pop(2)/pop(len) 无条件 vs fvo_bound_add 条件入栈，嵌套同名绑定 handle 崩 `tail(nil)` fail-closed（纯 .krf 手写形同崩——既有性实证）；Rust expr.rs Fn/Handle 臂同型（Vec::pop 空栈静默 no-op——静默变体）；双侧清偿 = Let 臂 r45/D42 shadow-aware 纪律延拓（fvo_bound_add/fvo_params 返入栈数 + pop 按实推数）；同类路径全量审查收口（§20.3——Fn/Handle/Let 三臂）。
- **测试门**：`ktf_handle_multiarm_tests` 32 case（8 正 + 24 负 = 1:3——含嵌套等价字节码全等门{共享符号表} + 双 Reader 正典渲染/错误面字节级 parity + fvo 清偿回归锚 + pass 无外层 handler 语义负例）+ 语料族平行对 `effect_multiarm.{ktf,krf}`（11:11 维持，双面 ⇒ 202）。
- **GATE 1**：六命令 clean 起步全绿（build 20.76s 零告警 / check 0/0 / fmt 0 diff / clippy --all-targets -D warnings 0 / test **1526:0:0**）+ 审计×6 EXIT 0 ×6 + CLI 双面零回归 + bench 75.398ms 带内（OBS-C <65ms 触发线不满足维持）。
- **治理**：t3plus v1.52 + TD-033 登记 + switch-window-plan §4 handle 行清偿（**切换窗后续域外登记清零**）+ 02 v7.17 + 20 v1.24 + 22 §880 注记 + README 三处 + rec 94 + worklog 三链。

**语义要点**：多臂 = 嵌套惯用法（先写臂外层——tag 分派按帧扫描 / 浅处理 D2 发射臂一次消费 / 其余臂维持保护受保护表达式剩余计算）；halt = 不 resume 尾值（T-NO-RESUME——resume ∈ {0,1} 合围 {0} 形）；pass = 本臂效应重发射（H 帧 ext1 已清 → 扫描越本 handle → 外层传播——T-EFFECT-PROPAGATION；外层 resume 自 pass 点续起——re-raise 标准语义）；重复标签 fail-closed（嵌套脱糖下静默遮蔽拒绝——§2.3 报错>静默）。

---

## r131 —— use 声明 / `::` 导入树窗：皮肤字典第十一映射（选择树）双侧 Reader + 镜像实施缺陷二件同窗清偿 + 同窗测试锚翻转 ×3（1494 新基线）

**日期**：2026-11-05　**类型**：use 声明实施窗（设计先行 + 净 +32——**1494 基线自 r131 起**）　**驱动**：用户三链指令（①继续推进 目标语言设计的实现窗[遇缺陷/未完成窗口则按推荐顺序直接推进进入对应窗口开始具体实施] ②按 docs/sop.md 流程结合 lang-design 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）——**M1 指令开窗第三十六例**（推荐序首位 = 成熟度匹配排序{三源均「触发式零信号维持或自然信号——按用户指令序或自然信号」+ 切换窗后续余二项中 use 声明设计完备度最高：S-expr 面选择形 r50/D65 既有 + driver collect_import_items 消费形在位 + EBNF v9 use_decl/use_path/use_tree 定稿产生式在位}——设计单源 use-declaration-design.md v1.0 D1-D10 先行落档）

- **201-a 环境恢复 + 基线复验 + 开窗判据**：cargo 工具链第四次环境回退重装（rustc/cargo/rustfmt/clippy 1.98.x——§3.1 自助纪律 r126/r129/r130 同型）+ r130 基线完整性复验（**1462:0:0 逐位**）+ 设计探针六件先行{S-expr 选择形 E2E r131 sel-ok + 别名+选择复合形 E2E + E0019 路径形面 + 块内 import 期望表达式面 + S-expr 面 use 普通标识符 (define use 42) ⇒ 84 + 词法 `::` 双形{后随 id_start → 合并 Path token；后随 `{` → 独立 PathSep/"::" 分隔}}——判据先于先例 §2.1.1-11}
- **201-b 设计单源落档**：use-declaration-design.md v1.0（问题陈述{目标面表达力 parity 缺口——选择形 `(import kerf-string (append))` 前此不可表达} + 语法定稿域 + D1-D10 十裁定 + 诊断面 + 测试矩阵 + 诚实边界表）；D1 `::` 路径树与单层模块名映射裁定{名位受理 Ident|Path + 多段路径 E0019 编译期拒绝——22 §7 单层执法面} / D2 选择形映射{r50/D65 纯皮肤——语义继承表代码为准：underlying 名平铺注入 + E0022 未选 + 限定访问不变 + E0024 + union} / D3 成员重命名域外 / D4 pub 维持 / D5 全族受理{bare/别名/选择/复合/多路径——拼写冗余合法性} / D6 位置纪律{选择形 module 头部 = 双侧一致 E0002 既有语义边界——探针实证} / D7 尾逗号双轨 / D8 use 目标面本地关键字{S-expr 面零扰动} / D9 Stx 元素序 = 消费者序 / D10 Span 契约{花括号区}
- **201-c 实施——第十一映射双侧 Reader**：种子 target.rs parse_use_decl（parse_item KwUse 臂翻转 + module 体 parse_item 自然继承；名位 as 专用诊断「use as 别名须跟在模块名后（缺模块名）」；花括号成员循环{Ident 受理 + KwAs 首槽/成员后双位 D3 专用诊断 + 空集「期望成员名」}；as 对先于选择列表的 D9 元素序；选择列表 Span = 花括号区 D10）+ 镜像 target_reader.krf parse-use-decl 函数族十一函数（parse-use-decl/use-name/use-sel-opt/use-sel-brace/use-member/use-member-sep/use-sel-close/sel-member-nodes/sel-member-build/use-alias-opt/use-close-opt/use-close——逆序 cons 暂存 + reverse 收口构造；错误面经桥 tk_debug_of_kind 单源渲染）；`use kerf_string::{append};` → `(import kerf-string (append))` **r50/D65 选择形的纯皮肤映射**——**driver collect_import_items/face_selects/face_selects_underlying/verify_import_face E0024 臂全链零变更**（零脱糖零新原语——原则 31）
- **201-c 同窗镜像实施缺陷清偿二件（§20.6 诚实登记）**：①use-sel-close 余流传递缺位——`(use-alias-opt toks ...)` 误传 toks{仍停在 `}`} 代 `(third r)`{`}` 之后余流}——探针插桩七轮定位{rderr 作多语句 do 体非尾语句其值被丢弃的 debug 方法论首误也如实登记}当场清偿；②sel-member-nodes 成员序反转——staged 逆序暂存 macc 未翻回直接 head-first 构造{多成员选择形 [append to-upper] 镜像产 [to-upper append]}——双 Reader 正典渲染 parity 门当场拦截当场清偿{sel-member-build + 前置 reverse}
- **201-c ktf_use_decl_tests 32 case 门**（tests/v0/stage3/plan/ + runner.rs 挂载）：正向八族{选择形平铺注入 E2E{⇒ r131 use-ok——underlying 名 string_append 非限定可用} + 跨语法值 parity{.krf ↔ .ktf ab} + 双 Reader 文法 parity 六形{bare/选择/多成员/复合/多路径/花括号尾逗号——正典渲染字节级含嵌套选择列表与花括号区 Span + 正典三符号断言 kerf-string/append/to-upper} + bare/别名形 E2E + 复合形 E2E{⇒ abc——选择+别名双可用} + 多路径/限定访问不变/连字符成员三锚{⇒ 2/3/AB} + module 头部别名形 E2E{⇒ m head-ok} + check 跨阶段消费零诊断带工件}；负向二十四族{名位 as 双形 + 名位非名三形{Semi/Int/PathSep} + 缺别名右操作数三形 + 空花括号 + 缺右花括号双形 + 关键字成员名 + 成员重命名域外双形{D3 专用诊断} + 顶层尾逗号 + 缺分号 + 双重别名 + pub 域外 + 块内位 E0001 + module 头部选择形 E0002 双侧一致 + 多段路径 E0019 双形 + 未注册 E0019 + E0024 + E0022 未选成员{选择性语义负锚} + E0017}——**8:24 = 1:3**（§9.4.3）
- **201-c 同窗测试锚翻转 ×3**（合法化锚点迁移——r130 m3 同型）：ktf_corpus_tests neg_use_decl_domain_out → neg_use_decl_multisegment_path_e0019{use 域外断言 → E0019 单层执法面} + target_reader_krf_tests syntax_parity_domain_out use 行退役{r121 match 行退役同型} + target_reader_tests domain_out_diagnostics use 行退役
- **201-d GATE 1 验收——六命令 clean 起步全绿**：cargo clean 725 files/196.8MiB → build --release **20.72s 零告警** → check --workspace --all-targets 0:0 → fmt --all --check 0 diff{一处顺修} → clippy --workspace --release --all-targets -D warnings 0 errors{doc list item 四处顺修——doc 注释行首 `+ ` 列表标记误判} → **test --release --workspace 1494:0:0**（净 +32；RUST_MIN_STACK=16777216）+ 审计×6 280 case 真实 EXIT 0 ×6 + CLI 双语法面零回归{.krf 八路径 + .ktf 双入口 + use 生产面双面实证 r131 ok / r131 krf} + bench OBS-C ~106ms{<65ms 触发线不满足维持——与 r130 71.189ms 同结论；进程级口径环境差异诚实注记} + §7.2 防崩 Q1-Q6 全过
- **201-e 治理对账九件**：t3plus v1.51（14 行触发族判定零变化——use 窗 = 声明面皮肤映射轮 T3+ 表零行命中）+ RELEASE r131 节 + matrix r131 增量行/总量行 + switch-window-plan §4 use 行清偿 + 下一批推荐更新{切换窗后续余一项 handle 多臂 + use 窗遗留触发式域外二项} + README 三处 + 02 v7.16（§8.13.1a use_decl 产生式族 + 域外注记翻转 + D9/D6 注记）+ 20 v1.23（§14 第十一映射行）+ 22 §7 `::` 导入树目标面映射终态注记 + rec 93 + 根层 l r131 条目 + worklog 三链
- **201-f 交付闭环**：r131 包三验（git archive 单源 → 独立解包净构建 + 包内 test 复跑 + e5close 审计）+ use 生产面双面实证 + web 更新（kerf-data + footer v7.89 + hero）+ web E2E（Agent Browser——桌面/移动 + 五探针 + footer 结构 + Playground 生产路径）+ §6.3 投票收口

**窗口意义**：CLI 双入口双面表达力 parity 缺口再清偿一项（r125 require / r130 import as / **r131 use 选择树** 同型三连）；S-expr 面选择形（r50/D65）的目标面首表达——目标语言蓝图侧消费面导入形（EBNF v9 use_decl）双侧 Reader 全族开放；`::` 在 kerf 的两个消费位（限定引用 + 选择树引导）终态入档；切换窗后续域外登记余一项（handle 多臂/halt/pass——需合围扩展设计）。**1494 基线自 r131 起**。

## r130 —— import as 别名窗：皮肤字典第十映射（别名对）双侧 Reader + 名位 Span 潜伏错位同窗清偿（1462 新基线）

**日期**：2026-11-04　**类型**：import as 别名实施窗（净 +32——**1462 基线自 r130 起**）　**驱动**：用户三链指令（①继续推进 目标语言设计的实现窗[遇缺陷/未完成窗口则按推荐顺序直接推进进入对应窗口开始具体实施] ②按 docs/sop.md 流程结合 lang-design 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）——**M1 指令开窗第三十五例**（推荐序首位 = 成熟度匹配排序{r129 收口笔/t3plus v1.49/switch-window-plan 三源均「触发式零信号维持或自然信号——按用户指令序或自然信号」+ §4 三登记项中 import as 设计完备度最高：S-expr 面 r40 M2 三形态既有 + driver collect_import_items 消费形在位 + EBNF 域外注记在位}）

- **200-a 环境恢复 + 开窗判据**：cargo 工具链环境回退重装（rustc 1.98.1/cargo 1.98.1/rustfmt 1.9.0/clippy 0.1.98——§3.1 自助纪律 r126/r129 同型）+ r129 基线完整性复验（**1430:0:0 逐位**）+ 七项判据表全过（需求信号 r74 先例锚 + 推荐序首位{成熟度匹配——设计完备项先行，原则 26} + 技术就绪{双侧 Reader 先例链 r125/r128/r129 + 消费形既有} + 缺口核实{双侧 Reader 双位 fail-closed 实读 + 02 行 728 域外注记 + switch-window-plan §4 行} + 8 原语不变性{零新原语零通道——Stx 即既有 import list} + §6.2 零开放 P0/P1 + 治理边界{皮肤映射窗型非切换窗}）
- **200-b 实施——别名对双侧 Reader**：种子 target.rs parse_import_decl 别名臂（`import_item = (ident | path) ["as" (ident | path)]`——ImportItem 结构体承载{clippy type_complexity 以结构体重构清偿非 allow 抑制}；名位 `as` = 别名缺模块名专用诊断「import as 别名须跟在模块名后（缺模块名）」；缺右操作数 = 「期望别名标识符，实际 {:?}」族{消息家族与「期望导入名」平行}）+ 镜像 target_reader.krf 四函数（import-alias-name/import-alias-sep/import-close/import-item-nodes——`as` Token → 字面符号 "as"{keyword Tokens 无 payload——nd-sym 字面量}；ident payload 经桥侧 target_symbol_name{kerf_list → kerf-list}）；`import a as b, c;` → `(import a as b c)` **符号逐一同构 S-expr 三形态导入**[r40 M2 / 22 §8 R-N5]——**driver collect_import_items/rewrite_alias_refs 消费形零变更**（零脱糖零新原语——原则 31）；`alias::member` ↔ `alias/member` 限定引用（`::`→`/` 既有分隔符映射 + r40 既有编译期归一）
- **200-b 同窗潜伏缺陷清偿**：名位 as 诊断 Span 种子/镜像错位——种子 bump 后 cur_span{后随 token 位} vs 镜像 p-start{as 本位}——无测试覆盖的潜伏缺陷本窗实读发现，双侧统一为 as 本位（1:8 列实证）
- **200-b 同窗测试锚翻转**：switch_corpus_parity_tests m3 锚「import a as b; 域外」→「import a as; 缺别名」（合法化锚点迁移——模块级 parity 网完备性维持）
- **200-b ktf_import_alias_tests 32 case**（tests/v0/stage3/plan/ + runner.rs 挂载）：正向八族（别名限定引用 E2E ab + 跨语法值 parity{.krf ↔ .ktf 双面} + **双 Reader 文法 parity**{单别名/混合/下划线三形——正典渲染字节级含 as 符号与 Span} + 混合声明 E2E + 下划线命名映射一致性 + module 头部别名 + define 调用形 + check 跨阶段消费零诊断带工件）；负向二十四族（名位 as 双形 + 缺右操作数四形 + 关键字别名 + 双重别名 + 缺逗号 + 未闭合 + 块内/表达式位 + 尾逗号 + 关键字模块名 + export/require 无别名形 + E0019 未知模块/路径形{注册名单连字符形单源诚实边界} + E0017 别名重复{含 .krf 面跨语法错误 parity——m2_alias_duplicate_e0017 锚同族} + E0014 未知成员/未导入命名空间 + E0022 裸别名 + E0004 string-append 契约）——**正负比 8:24 = 1:3**（§9.4.3）；错误面 parity 16 形{消息 + Span 字节级}
- **200-c GATE 1**：六命令 clean 起步全绿——cargo clean 725 files/195.9MiB → build --release **19.95s 零告警** / check --workspace --all-targets 0 errors 0 warnings / fmt 0 diff{一处顺修} / clippy --workspace --release --all-targets -D warnings 0{type_complexity 结构体重构 + doc_lazy_continuation 一处顺修} / **test --release --workspace 1462:0:0**（净 +32）+ 审计×6 280 case EXIT 0 ×6 + CLI 双语法面零回归（.krf 面：fib ⇒144 + closures ⇒42 + match ⇒fib-13 + macros ⇒42 + check ok + effect_stress ⇒120 + gc_stress test 2/2；.ktf 面：fib ⇒144 + macros ⇒42 + check ok{38 指令} + effect_stress ⇒120 + test 1/1）+ **别名生产面双面实证**（.ktf `import kerf_string as str; str::append("r130"," ok")` ⇒ r130 ok + .krf `(import kerf-string as str) (str/append "r130" " krf")` ⇒ r130 krf——CLI 双入口双面表达力 parity 缺口清偿{r125 require 同型}）+ OBS-C bench 71.189ms（r55→r130 带内——<65ms 触发线不满足维持）+ §7.2 Q1-Q6 全过（Q1 基线 1430 全量零回归 / Q2 零新 P0/P1{名位 Span 错位 = 本窗当场清偿} / Q3 缓存纪律{include_str! 嵌入重构建} / Q4 诊断面七类全覆盖{审计×6} / Q5 bench 带内 / Q6 文档对账 = 200-d）
- **200-d 治理对账九件**：t3plus v1.50（r130 消费注记——14 行判定零变化）+ RELEASE r130 节（本件）+ matrix r130 增量行 + 总量行 1462 对账{单元 298 + 集成 1164} + switch-window-plan §4 域外登记行清偿 + 下一批推荐行更新（r130 后——触发式零信号维持或自然信号{切换窗后续余下两项均设计先行态：use 声明/`::` 导入树{22 §7 目标面语义设计} + handle 多臂/halt/pass{合围扩展设计}}）+ README 三处（质量状态行 r130/1462 + cargo test 行 + 打包交付行）+ 02 v7.14→v7.15（§8.13.1a import_item 别名位产生式 + 域外注记翻转 + 名位 Span 修复注记）+ 20 v1.21→v1.22（§14 皮肤字典第十映射行 + N1 模块行陈旧域外注记翻转）+ rec 92（03 层第 92 件）+ 根层 l r130 条目{**含 r129 R4 回填**——199-d 声称「根层 l r129 条目」实况缺失，当轮补齐} + worklog 三链镜像
- **200-e 收口**：r130 包三验（git archive 单源 → 独立解包净构建 + 1462 复跑 + e5close 审计 EXIT 0 + 别名生产面实证）+ download README r130 节 + web 更新（kerf-data + footer + hero——r130 前置链保留）+ Agent Browser E2E + §6.3 投票

**验收快照**：`kerf-v1.0.0-r130-importasalias-1462tests.tar.gz`（r130 包件——三验全绿）；**.ktf 别名面能力**：`import kerf_string as str; str::append("a","b")` ⇒ "ab"；**E2E 别名错误面五形态**：名位 as 专用诊断 / 缺右操作数四形 / 双重别名 / 缺逗号 / 未闭合——消息+Span 双侧字节级。

**窗口意义**：CLI 双入口架构（r125）下 .ktf 程序自此可使用模块别名——双面表达力 parity 缺口清偿（r125 require/r128 handler 块体/r130 import as = 声明面三缺口全闭）；皮肤字典第十映射 = import 声明家族完备化（module/import/export/require + as 别名）；切换窗后续登记项余二（use 声明/`::` 导入树 + handle 多臂/halt/pass——均设计先行态）。

## r129 —— 宏面语料窗：皮肤字典第九映射（宏定义面）双侧 Reader + macros.ktf + check 恢复模式宏注册 P1 缺陷清偿（1430 新基线）

**日期**：2026-11-03　**类型**：.ktf 宏面语料就位实施窗（净 +37——**1430 基线自 r129 起**）　**驱动**：用户三链指令（①继续推进 目标语言设计的实现窗[遇缺陷/未完成窗口则按推荐顺序直接推进进入对应窗口开始具体实施] ②按 docs/sop.md 流程结合 lang-design 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）——**M1 指令开窗第三十四例**（r128 收口笔推荐序首位兑现——宏面语料三源一致指名{r128 收口笔 + switch-window-plan v1.10 下一批推荐 + t3plus v1.48}）

- **199-a 开窗判据回填 + ARCH-A 设计裁定**：七项判据表——需求信号（r74 先例锚）✓ 推荐序首位三源一致 ✓ 技术就绪（双侧 Reader 先例 + macro_sys 结构契约确认零变更可复用）✓ 语料面缺位核实（.krf 10 件 vs .ktf 9 件唯 macros 缺位）✓ 8 原语不变性（零新原语零通道——Stx 即既有 define-syntax 结构）✓ §6.2 零开放 P0/P1 ✓ 治理边界（语料族窗型非切换窗）✓。**第九映射设计裁定六件**：语法形（`macro NAME [ "(" [字面量集] ")" ] "{" { 模式 => 模板 [","] } "}"`——臂 = 模式 => 模板，尾臂逗号可省[match 臂先例]；`=>` = 既有 FatArrow）/ `...` 词法 = Tk::Ident("...")（三连点前瞻先于 `..`——S-expr 面 is_ellipsis 符号同构）/ `macro` = **目标面本地关键字**（Tk::KwMacro——不入共享 Keyword/E0020 域；match/require 入共享域区别 = S-expr 面有消费，macro 的 S-expr 面宏定义恒 define-syntax——S-expr 面零扰动 = 原则 27 加性最优实例）/ 模板省略号吸收 = **无条件**（ARCH-A 中途精化：template_depth 旗标废弃——非模板位 `f(a ...)` 两面同产 Stx `(f a ...)` → 展开期未绑定错误与 S-expr 面同形——比读错分叉更优 parity）/ 零脱糖零新原语（Stx = 同一 `(define-syntax NAME (syntax-rules (lit) (pattern template)...)`——expand_define_syntax/SyntaxRules::parse/register_transformer 全链零变更——原则 31）/ 语料命名（macros.ktf 宏名 = my_or/swap——`!` 不入目标面标识符域，语料面自由命名，跨语法行为等价门守）
- **199-b 实施——第九映射双侧 Reader**：种子 target.rs（KwMacro + 三连点前瞻 + parse_macro_decl/parse_macro_pattern{Option 宏名注入——resume-k 先例}/parse_macro_template + parse_postfix args 无条件吸收 + 空字面量集 `()` Unit 特判——词法前瞻歧义按句法位决断先例族）+ 镜像 target_reader.krf（TKEYWORDS + 三连点 → ident "..." + parse-macro-decl 族[Unit 特判 + 尾逗号容忍对齐种子 + 无逗号 expect ) 收口错误面同形] + call-args-tail 吸收[后随 )/,/eof 才吸收——中间位 fail-closed]）
- **199-b 实施——macros.ktf 语料就位**：双宏（my_or 变参递归省略号三臂 + swap 块模板卫生）——**跨语法行为等价与 macros.krf 逐位一致**（`(2 1)` + `42`——原则 31）；.ktf 语料族 **9→10 件与 .krf 语料族 10:10 全对齐**
- **199-b 实施——check 恢复模式宏注册 P1 缺陷清偿（本窗 E2E 发现——用户指令①「中途遇缺陷直接推进」行权）**：check 面对含用户宏程序全体 E0022 误报（`.krf`/`.ktf` 两面共通；r17 TD-013 恢复模式引入起潜伏——测试缺口 = check + 用户宏组合零覆盖）——根因 = expand_program_recover 桥逐 form 调 lexp-expand-program 而该入口**每次调用重置 TRANSFORMERS = DERIVED_ENTRIES** → 用户 define-syntax 注册在下个 form 前丢失（桥注释「persists across calls」与 .krf 实况矛盾；种子 recover ctx 持久无此缺陷 = parity 缺口）——清偿 = **expander.ktf 入口加性拆分**（`lexp-expand-program-reset` 全重置 + `lexp-expand-program-continue` 不重置——既有整列表入口 = 复合零变更——原则 41 加性）+ 桥 reset-once/continue-per-form + BootstrapExpanderState 增 reset/continue 符号字段（Symbol 表私有索引——build_state 时 intern）；清偿后双面 check 全绿（.ktf 43 指令 / .krf 41 指令）
- **199-b 实施——ktf_macros_corpus_tests 37 case**（tests/v0/stage3/plan/ + runner.rs 挂载）：正向八族（语料 run E2E 值锚 42 + 跨语法值 parity 双对[.krf ↔ .ktf 含 swap 形 (2 1)] + **双 Reader 文法 parity**[全语料 + 字面量集三形{显式空集/非空集/尾逗号容忍} + 空模式嵌套子模式字面量元素——正典渲染字节级] + 三臂递归语义[零参 false/短路 true/多参 42] + 卫生 tmp 不捕获[引入标识符改名跨用户绑定 77] + 宏名注入嵌套拆构[4 元素子模式 → c=3] + 字面量集语义[字面量精确匹配 vs 模式变量回退] + check 跨阶段消费零诊断带工件）；负向二十九族（位置双族：块内/表达式位 + 结构十四族：缺名/关键字名/缺臂箭头/非括号模式/运算符元素/未闭合双形/嵌套未闭合/字面量集数字双逗号/缺模板/关键字模板/块语句缺分号/臂间缺分隔 + 省略号三族：中间位 fail-closed/维度不匹配/非模板位未绑定**两面同形** + 展开期四族：无匹配/未定义宏/零参带参/模板未绑定引用 + 错误面 parity 八形[消息+Span 字节级] + 词法族 + 模块表达式位 + 尾逗号双逗号二族）——**正负比 8:29 = 1:3.6**（§9.4.3）；语料 = include_str! 测试工件（语料完整性门）
- **199-c GATE 1**：六命令 clean 起步全绿——cargo clean 730 files/197.9MiB → build --release **20.32s 零告警** / check --workspace --all-targets 0:0 / fmt 顺修一处后零 diff / clippy -D warnings 顺修一处（err().expect → expect_err）后零告警 / **test --release --workspace 1430:0:0**（净 +37）+ 审计×6 280 case EXIT 0 ×6 + CLI 双语法面零回归（.krf 面：fib ⇒75025 + closures ⇒(4 2) + match ⇒fib-13 + **macros ⇒(2 1)/42** + check ok + effect_stress ⇒120 + test PASS 2/2；.ktf 面：fib ⇒75025 + **macros ⇒(2 1)/42** + check ok{43 指令} + effect_stress ⇒120 + test PASS 2/2）+ OBS-C bench 三轮 71.539/71.449/72.925ms（r55→r129 带内——<65ms 触发线不满足维持）
- **199-d 治理**：对账九件——t3plus v1.49（r129 消费注记 + 14 行判定零变化 + .ktf 语料族 10:10 全对齐）+ RELEASE r129 节（本件）+ matrix r129 增量行 + 总量行 1430 对账 + switch-window-plan 下一批推荐行更新（r129 后——触发式零信号维持或自然信号）+ README 两处（质量状态行 r129/1430 + 打包交付行最新包名）+ examples/README .ktf 语料族表 R4 对齐（10 件全量）+ rec 91 + 根层 l r129 行 + worklog 三链镜像 + 02 v7.14 / 20 v1.21（文法登记——实施笔同轮）
- **199-e 收口**：r129 包三验（git archive 单源 → 独立解包净构建 + 1430 复跑 + e5close 审计 EXIT 0 + 宏面语料生产面实证）+ download README r129 节 + web 更新 + Agent Browser E2E（双视口零溢出 + 第九映射探针 + stats 双源对账 1430/r129 包名）+ §6.3 投票

---

## r128 —— 语料族深度化窗（stress 变体批）：examples/usage/*.ktf stress 三件 + handler 块体 resume 文法清偿（1393 新基线）

**日期**：2026-11-03　**类型**：.ktf 语料族深度化实施窗（净 +32——**1393 基线自 r128 起**）　**驱动**：用户三链指令（①继续推进 目标语言设计的实现窗[遇缺陷/未完成窗口则按推荐顺序直接推进进入对应窗口开始具体实施] ②按 docs/sop.md 流程结合 lang-design 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）——**M1 指令开窗第三十三例**（r127 收口笔推荐序首位兑现——stress 变体批三源一致指名{r127 收口笔 + switch-window-plan v1.10 + t3plus v1.47}）

- **198-a 开窗判据回填 + ARCH-A/PM-A 双确认**：七项判据表——需求信号（r74 先例锚：用户显式指令点名 = 需求信号命中）✓ 推荐序自然落位（stress 变体居首位——r127 诚实边界已登记「effect_stress GC 压力变体 = 后续自然信号」；宏面语料列次位成为下轮首位）✓ 技术就绪（皮肤字典八映射全在位 + stress 语料 .krf 原件实测 76-133ms 可入测试）✓ 语料面缺位核实（examples/usage/ 零 .ktf stress 件）✓ 8 原语不变性（语料 + 文法清偿纯消费零新原语零通道——resume 扩展 = 既有核心形式 `(resume k v)` 的目标面语句形映射）✓ §6.2 债务前置（TD 登记册零开放 P0/P1）✓ 治理边界（本窗 ≠ 切换窗本体；**本窗发现真实文法缺口**——目标面 handler 块体无法表达 S 表达式面 `(do A (resume k v))` 序列形，按用户指令①「中途穿着缺陷…直接推进实施」行权文法清偿）✓——**GO**
- **198-b 实施——handler 块体 resume 文法清偿（双侧 Reader）**：S 表达式面 handler 体 `(do (mk 50000) (resume k (+ (tail p) (head p))))` 的「分配后恢复」序列在目标面不可表达（直位 `=> resume(v)` 无语句序列承载——effect_stress 翻译直接受阻）。清偿 = 处理器臂块体顶层语句/尾位 resume 调用形 `resume(expr)` → `(resume k expr)`——**k 由臂绑定注入（用户永不书写）**；语句位（后随 ;）与尾位（后随 }）同形；一次性 resume 语句后的语句 = 死代码（与 S 表达式 `(do (resume k v) dead)` 同构——值锚实证 120）；**嵌套块（if 臂/闭包体）内 resume = 登记域外 fail-closed 诚实边界**（S 表达式面词法作用域内合法——目标面收窄，触发式后续信号）；普通块无处理器作用域 → 既有「期望表达式」错误路径逐字节不变。双侧落地：种子 `parse_handler_block`/`parse_resume_call`（target.rs——parse_block_inner 参数化 + parse_handler_body 直位/块体统一）+ 镜像 `parse-handler-block`/`parse-resume-call`（target_reader.krf——block-loop 增 k-node 参数第四形{普通块恒 nil——零回归}）。产生式 = 02 §8.13.1a v7.13 + 皮肤字典 = 20 §14 v1.20（D2 handle 映射体域扩展）
- **198-b 实施——stress 语料三件就位**：examples/usage/*.ktf —— **effect_stress.ktf**（效应 GC 压力：mk(50000) 挂起续延跨多轮标记清扫存活 + `{ mk(50000); resume(tail(p) + head(p)) }` handler 块体 resume 语句形——**r128 文法清偿载体**⇒ 120）/ **gc_stress.ktf**（10^6 量级临时对象分配堆稳定——`define(keep, list(1, 2, 3, 4, 5));` 运行时构造{目标面无引号列表字面量 r127 诚实边界} + spin(30000) 尾形 TCO ⇒ 5 存活数据跨 GC 完整）/ **gc_stress_nontail.ktf**（TD-023 基准重定型目标面——`grow(n - 1) + 1` 非尾位深帧根集枚举负载 ⇒ 5）——**跨语法行为等价与 .krf 对应件逐位一致**（120/5/5——原则 31）；三件 check 面零诊断带真实指令工件（65/94/72 指令）
- **198-b 实施——ktf_stress_corpus_tests 32 case**（tests/v0/stage3/plan/ + runner.rs 挂载）：正向八族（三语料 run E2E 值锚 + 跨语法值 parity 三对[.krf run_source ↔ .ktf run_source_target] + **双 Reader 文法 parity**[种子↔镜像正典渲染字节级——三语料全件 + 四聚焦形{尾位/语句位死代码/let 穿线/纯 resume 块}] + **双 Reader 错误面 parity**[五负形消息+Span 字节级] + check 面跨阶段消费三件零诊断 + 语句位 resume 一次性跳离语义值锚）；负向二十四族（新形纪律十族：普通 fn 块/顶层/嵌套 if 臂/嵌套闭包/无括号/未闭合/双实参/直位语句序列/保护表达式位/空实参 + 既有族十四族：词法/文法/类型必填/E0006 能力/E0022 短路/E0022 N2 注入面/E0025 穷尽/HM E0005 三形/运行期 E0004 三形/恢复位置序/r126 ∀α 吸收目标面消费）——**正负比 8:24 = 1:3**（§9.4.3）；语料 = include_str! 测试工件（语料完整性门）
- **198-c GATE 1**：六命令 clean 起步全绿——cargo clean 725 files/193.7MiB → build --release **20.43s 零告警** / check --workspace --all-targets 0 errors 0 warnings / fmt --all --check 0 diff（一处顺修后归零） / clippy --workspace --release --all-targets -D warnings 0 errors（一处顺修后归零——unnecessary_unwrap → match 形） / **test --release --workspace 1393:0:0**（净 +32；RUST_MIN_STACK=16777216）+ 审计×6 280 case EXIT 0 ×6 + CLI 双语法面零回归（.krf 八路径：fib ⇒75025/⇒144 + check ok：2 原型/9 常量/5 全局引用/38 指令 + match ⇒fib-13 + closures ⇒42 + effect_stress ⇒120 + higher_order ⇒(1 4 9 16 25) + macros ⇒42 + test PASS 5/5；.ktf 新三路径：effect_stress ⇒120 + gc_stress ⇒5 + gc_stress_nontail ⇒5 + 语料族 fib ⇒144/match ⇒fib-13 维持）+ OBS-C bench 三轮 108-111ms（<65ms 触发线不满足维持零信号——sandbox 负载态绝对值波动，触发线对比为协议事实）
- **198-d 治理**：对账九件——t3plus v1.48（r128 消费注记 + 14 行判定零变化 + .ktf 语料族 6→9 件族邻域增量）+ RELEASE r128 节（本件）+ matrix r128 增量行 + 总量行 1393 对账 + switch-window-plan 下一批推荐行更新（r128 后——宏面语料候选首位）+ README 两处（质量状态行 r128/1393 + 打包交付行最新包 r128-stresscorpus-1393tests）+ examples/README .ktf 语料族表（R4 对齐——r127 六件 + r128 三件全量登记）+ rec 90（docs/worklog/03_stage-3_入场序列/）+ 根层 l r128 行 + worklog 三链镜像 + 02 v7.13 / 20 v1.20（文法登记——实施笔同轮）
- **198-e 收口**：r128 包三验（git archive 单源 → 独立解包净构建 + 1393 复跑 + e5close 审计 EXIT 0 + 生产面语料实证）+ download README r128 节 + web 五处（kerf-data/hero/footer/stats/download）+ Agent Browser E2E（双视口零溢出 + 语料族消费探针 + stats 双源对账 1393/r128 包名）+ §6.3 投票

**演进位置**：**语料族深度化窗（stress 变体批）全闭 ✅**——.ktf 语料族 6→9 件（与 .krf 语料族 9 件对齐——唯 macros.ktf 宏面语料缺位）；handler 块体 resume 文法缺口清偿（双侧 Reader + 产生式 + 皮肤字典三面同轮）；**1393 基线自 r128 起**；14 行触发族判定零变化（T3+ #5 族邻域语料面信号增量——供切换窗消费）；下一演进 = 宏面语料（macros.ktf——需宏定义目标面形设计{第九映射候选}，触发式）或触发式零信号维持——按用户指令序或自然信号。

---

## r127 —— .ktf 用户面语料族就位窗：examples/usage/*.ktf 六件（M2 语料消费形态兑现 · 1361 新基线）

**日期**：2026-11-03　**类型**：.ktf 用户面语料族就位实施窗（净 +32——**1361 基线自 r127 起**）　**驱动**：用户三链指令（①继续推进 目标语言设计的实现窗[遇缺陷/未完成窗口则按推荐顺序直接推进进入对应窗口开始具体实施] ②按 docs/sop.md 流程结合 lang-design 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）——**M1 指令开窗第三十二例**（r126 收口笔推荐序首位兑现——M2 语料消费形态三源一致指名）

- **197-a 开窗判据回填 + ARCH-A/PM-A 双确认**：七项判据表——需求信号（r74 先例锚：用户显式指令点名 = 需求信号命中）✓ 推荐序自然落位（第 1 位 #15 需 next18.md 未上传 + 第 2/3/4 位全闭[TD-032 ✅ r90 / TD-031 ✅ r99 / HM ✅ r80]——r126 收口笔 + t3plus v1.46 + switch-window-plan v1.10 三源一致指名 M2 语料消费形态）✓ 技术就绪（r125 CLI 双入口 22 case 全绿——.ktf 生产路径 run/check/test 三入口在位）✓ 语料消费面缺位核实（examples/usage/*.ktf 零件——M2 候选登记态实况）✓ 8 原语不变性（皮肤字典八映射纯消费——零新原语零通道零语法增量零 Reader 机制变更）✓ §6.2 债务前置（TD 登记册零开放 P0/P1）✓ 治理边界（本窗 ≠ 切换窗——六步前置清单门控维持未开；语料面信号建立供未来切换窗消费）✓——**GO**
- **197-b 语料族六件就位**：examples/usage/*.ktf —— **fib**（fn 声明 + 类型签名剥取 + 递归 + require/print 第八映射面）/ **closures**（`||` 闭包表达式[lambda→closure D2 方向] + `let n = 0;` 绑定 + `n = n + 1;` assign 可变捕获 + `define(NAME, e);` 顶层值定义调用形）/ **higher_order**（高阶函数 + `||` 闭包实参 + `list` 内建调用面 + `is_` 现代命名[目标面字符集 A-Za-z0-9_]）/ **match**（第七映射全形态：字面量臂 + 守卫臂 + 序对拆构 + 嵌套 or-in-pair-left + 臂级 or 标记 + 单次求值 scrutinee）/ **io**（`import kerf_string;` 模块生产面 + `require io, write;` 能力声明 + `string_append` 词分隔映射[`-`↔`_` Reader 符号引入边界单点]）/ **effect**（`perform gift(0, 20);` 效应值[标签 + 载荷序对] + `handle e { Name(p, k) => body }` 单臂 + `resume(v)` 续体恢复——effect_stress 演示形）——**跨语法行为等价与 .krf 对应件逐位一致**（⇒144/42/(1 4 9 16 25)/fib-13/42/120）；诚实边界登记：目标面无引号列表字面量（Level 0 实施面列表 = cons/list 应用）；effect_stress GC 压力变体 = 后续自然信号
- **ktf_corpus_tests 32 case**（tests/v0/stage3/plan/——runner.rs 挂载）：**正向八族**（六语料 run E2E 值锚 + check 面跨阶段消费六件零诊断与真实指令工件 + test 入口 match.ktf 5/5 三入口消费）+ **负向二十四族**（未闭合字符串/大括号/fn 参数缺类型注解/require 缺分号/match 臂缺逗号/or 混序对拆构/块内 require 位置纪律/S 表达式源目标入口拒收/dump 坏源/use 声明域外/索引域外/print 无 require E0006 能力门控/未绑定 E0022 短路/导入面 E0022/string-append/E0025 非穷尽收集/HM E0005 三形[字面量/参数错/define 全局链]/运行期 E0004 四形[非函数调用/head 非序对/参数类型错/字符串操作数]/恢复多错误位置序 E0002+E0005/r126 失败 define ∀α 吸收目标面消费恰一诊断零污染）——**正负比 8:24 = 1:3**（§9.4.3）；**语料 = include_str! 测试工件**（语料完整性门：任何语料编辑破坏生产链路即测试断裂）
- **GATE 1 六命令 clean 起步全绿**：cargo clean 725 files/193.1MiB → build --release **20.12s 零告警** / check --workspace --all-targets 0 errors 0 warnings / fmt --all --check 0 diff / clippy --workspace --release --all-targets -D warnings 0 / **test --release --workspace 1361:0:0**（净 +32；RUST_MIN_STACK=16777216）+ 审计×6 280 case EXIT 0 ×6 + CLI 双语法面零回归（.krf 八路径[fib ⇒75025/⇒144 + match ⇒fib-13 + check ok + closures ⇒42 + effect_stress ⇒120 + higher_order ⇒(1 4 9 16 25) + macros ⇒42 + test PASS 2/2] + .ktf 语料族七路径[六 run 值锚 + test 5/5 + check ok]）+ OBS-C bench 三轮 70.455/70.854/72.213ms 带内（r55→r127——<65ms 触发线不满足维持零信号）
- **演进位置**：**.ktf 用户面语料族就位窗全闭 ✅**（M2 语料消费形态候选兑现——T3+ #5 族邻域语料面信号建立：match.krf 十面命中维持 + match.ktf 六面命中族邻域增量——供切换窗消费）；**1361 基线自 r127 起**；14 行触发族判定零变化；下一演进 = 切换窗语料面信号积累或触发式零信号维持——按用户指令序或自然信号
- 对账链：matrix r127 行 + 本节 + [rec 89（03 层）](docs/worklog/03_stage-3_入场序列/89_r127_KTF语料族.md) + t3plus v1.47 + switch-window-plan 下一批推荐行 + 根层 l + README 两处 + download README + worklog 三链；**R4 顺修**：r126 包字节漂移三方修正（内链三件[worklog/docs 镜像/rec 88] 5,446,261 → **5,446,347 实测**{= git archive 5ac0a47 逐位实证——86 字节差 = 字节回填后重打包}；web 两处 5,445,854 → 5,446,347；commit 消息不可变——修正注记补录）



## r126 —— HM 深化窗：check.krf 项内恢复架构（r75 §5.3 双轴诚实边界全吸收 · 1329 新基线）

**日期**：2026-11-03　**类型**：HM 深化实施窗（净 +7——**1329 基线自 r126 起**）　**驱动**：用户三链指令（①z.ai web 保存机制回退——上传包 kerf-v1.0.0-r125-clidual-1322tests.tar.gz 全量替换恢复 ②继续推进 目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施 + 按照 docs/sop.md 流程结合 docs/lang-design/ 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按照推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）——196-a..196-e（M1 指令开窗第三十一例——r125 收口笔推荐序首位兑现{HM 深化 = CLI 双入口窗全闭后推荐序首位，三源一致：r125 收口笔 + t3plus v1.45 + switch-window-plan v1.10 下一批推荐——均列首位}）

- **196-a 前置环境恢复**：z.ai web 保存机制回退致工作区回落 r113（1214 基线）——上传 r125 包替换{保留 .git + target；逐字节 diff 零差异} + 工具链重装{cargo 丢失——scripts/rust/setup.sh → rustc 1.98.1/cargo 1.98.1/rustfmt 1.9.0/clippy 0.1.98} + GATE 1 复验全绿{六命令 clean 起步 build 19.77s + **1322:0:0 逐位** + 审计×6 EXIT 0 + CLI fib ⇒144/match ⇒fib-13/check ok/.ktf 入口 ok} + git 恢复轮提交；r114-r125 交付链内容全找回{切换窗后续 + EBNF 定稿 + match M-1..M-4 全闭 + CLI 双入口全闭}。
- **196-b HM 深化实施**——check.krf 软错误通道改「记录+恢复」架构（生产判定面 HM 深化——镜像 Rust oracle 的 diag()+Dynamic 恢复机制面；**r75 审计 §5.3 注册的「归未来生产切换窗的两阶段架构重构义务」全清偿**——r80 生产切换未做的架构重构本轮兑现）：**tc-failv 重定义**{记录后返 (tcon 'dynamic) 恢复型——原返诊断值中止项；四调用点自动获恢复：tc-infer-builtin 元数 + head/tail 非 pair + app-general 元数/不可调用} + **tc-record 新通道**{记录 + 返 true——逐参续行 sites helper} + **tc-rule-one/tc-rule-all/tc-rule-pair-list 重构**{具体违例 tc-record 内录续扫——原返 false 由调用者 tc-fail 中止；tvar 走 tc-unify 内录；**逐参数全量收集 = 约束级全 drain 可观测行为**} + **tc-infer-builtin 规则失败后仍返签名结果型**{oracle parity：diag + sig ret——`(+ (not 5) (+ 1 "s"))` 三诊断全收集} + **tc-infer-app-general**{参数合一失败恢复 Dynamic + occurs 记录恢复 fresh} + **tc-if-cond-ok/tc-infer-if**{具体非 bool 条件记录续行 + **条件违例不再中止分支推断**{then/else 双查——`(if true (+ 1 "a") (+ 2 "b"))` 双诊断} + 双变元合一失败格 join 恢复} + **tc-infer-assign**{合一失败仍返 Dynamic} + **tc-check-define**{合一失败仍绑定——未解先绑变量 → ∀α 泛化 = oracle Poly 可观测；**失败 define 后续引用获自身诊断**：`(define (f x) (+ x "s"))` + `(f 1 2)` 双诊断} + **kerr/unsupported 硬中止维持**{r75 口径——内部缺陷/子集越界无恢复语义}；括号平衡三处顺修{S 表达式解析器逐形式验证 106 顶层形式}。
- **双轴边界吸收实证**：轴① 项内多错——`(+ (not 5) (+ 1 "s"))` krf 1→**3 = oracle 3**；轴② 失败 define 吸收——`(define (f x) (+ x "s"))` + `(f 1 2)` krf 1→**2 = oracle 2**；③ occurs 时机差 + ④ 变元头不传播 = **保守边界维持登记态**（krf ⊆ oracle 宽松化方向不破坏）。
- **语料锚重锚**（锚漂移程序合规处置——matrix 注记程序明文「drift = check.krf inference semantics changed (must re-pin + record in the worklog)」）：check.krf 锚 1→**2**{项内恢复显邻位 `(head TC-DIAGS)` pair 规则违例——原被 r80 期项级首错中止抑制}；**方向守卫 krf 2 ⊆ oracle 23 探针实证**（oracle 对该语料报 23 条约束级诊断——出口区双面均有检出；宽松化契约完好）；其余六锚零漂移{expander 0/compiler 1/reader 0/build 0/cli 0/fib 0}。
- **r126 门族 +7**（1322→1329）：hm_krf_path 六件{正向双族：全参数收集 3=3{`(+ "a" "b" "c")`} + 深嵌套 4=4{`(+ (+ (not 5) "x") "y")`——恢复型参与外层规则检查}；负向守卫四族：if 条件无级联 1=1 + 失败 define ∀α 干净引用无级联 1=1 + 干净后续项零污染 1=1 + 单错 wire 形态保持{'diag 单形态——原则 27 加性协议}} + hm_production_switch 跨阶段一件{**.ktf 目标链项内恢复 3=3**——`not(5) + (1 + "s")` 目标语料双面 parity + 方向断言{core 语法不变性——r120 锚重锚同族}}——正负比 2:5 族内 + 全套件 1:3+ 维持。**测试面翻转三处**：boundary_intra_item_single_diag → boundary_intra_item_multi_diag_parity{3=3 + Diags 形态} + boundary_failed_define_call_absorption → _parity{2=2} + typecheck multi_error_continues_after_error{r80 重锚 2→1 回归 2 = oracle parity——含 if 分支双查 2}。
- **GATE 1 六命令 clean 起步全绿**：cargo clean 535 files/120.5MiB → build --release **19.29s 零告警** / check --workspace --all-targets 0 errors 0 warnings / fmt --all --check 0 diff（顺修后归零）/ clippy --workspace --release --all-targets -D warnings 0 errors / **test --release --workspace 1329:0:0**（净 +7；RUST_MIN_STACK=16777216）+ 审计×6 280 case 真实 EXIT 0 ×6 + CLI 六路径零回归（fib ⇒144 + match ⇒fib-13 + check ok：5 原型/16 常量/10 全局引用/91 指令 + closures ⇒42 + effect_stress ⇒120 + test PASS 2/2）+ OBS-C bench fib 三轮 71.194/71.269/70.812ms（r55→r126 带内——<65ms 触发线不满足维持）+ §7.2 防崩 Q1-Q6 全过。
- **演进位置**：**HM 深化窗全闭 ✅**（r75 §5.3 双轴残留诚实边界全吸收——项内恢复架构落地：krf 面多错误收集粒度达 oracle parity；③④ 保守边界维持登记态）；**1329 基线自 r126 起**；14 行触发族判定零变化（本窗 = 类型检查器深化轮零 T3+ 消费信号）；下一演进 = .ktf 用户面语料族就位（M2 形态——触发表 #5 族邻域候选）或触发式家族零信号维持——按用户指令序或自然信号。
- 对账链：matrix r126 行 + 本节 + rec 88（03 层） + t3plus v1.46 + hm-inference-design v0.3.0{r126 双轴吸收注记} + r75 审计 §5.3 清偿注记 + 12-roadmap §2.5.1 类型检查器行 r126 注记 + 根层 l r126 条目 + README 两处 + worklog 三链镜像。

## r125 —— CLI 双入口形态（双 Reader 并存期入口分派 · require 声明皮肤第八映射 · 1322 新基线）

**日期**：2026-11-03　**类型**：CLI 双入口实施窗（净 +22——**1322 基线自 r125 起**）　**驱动**：用户三链指令（①继续推进 目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施 ②按照 docs/sop.md 流程结合 docs/lang-design/ 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按照推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）——195-a..195-d（M1 指令开窗第三十例——r124 收口笔推荐序首位兑现{CLI 双入口形态 = match 实施窗全闭后推荐序首位，三源一致：r124 收口笔 + switch-window-plan v1.9 §4 域外登记行「CLI 双入口（P3 设计候选）｜切换窗后续」 + t3plus v1.44}；match 实施窗已全闭 r124{M-1..M-4 全批}——指令①「遇缺陷/未完成窗口」核对零命中，按指令②推荐序首位行权）

- **195-a CLI 双入口实施**（switch-window-plan v1.9 §4 域外登记行「CLI 双入口（P3 设计候选）——双 Reader 并存期入口形态」字面清偿）：**driver 层 `_target` 变体函数族四件**（kerf-driver/driver.rs——`run_source_target`{compile_front_target + run_front 共享执行尾段；cache-free 口径与 compile_front_target 同基{B11/P4 kind-tag 无语法维度——.ktf 用户面缓存化 = 后续触发式登记}} + `check_source_target_recover`{读段换 target Reader 桥，尾段与 S-expr 面共享——`check_recover_from_forms` 单源提取：prelude 注入 → Stx 层守卫族 → 恢复展开 → 部分产物管线 → HM 类型检查 → 诊断合并/排序一次实现两皮肤消费} + `dump_tokens_target`{lex_target_for_bootstrap → ParityToken kind:payload 渲染} + `dump_stx_target`{read_target_source_for_bootstrap → Stx 渲染循环共享——皮肤/骨架同构：双皮肤在同一 Stx 收敛}）+ **test_runner 桥 `run_target`**（bootstrap/test_runner.rs——front 获取换 compile_front_target；用例切分/编排尾段 `run_report_from_front` 单源提取：ModuleItem 层切分语法中立{fn 声明 = prelude Define、顶层表达式 = 用例——双皮肤同构}）+ **compile_front_target 可见性 pub(crate) + lib.rs 导出面扩展八项** + **main.rs 双入口分派接线**（`is_target_syntax`{精确 `.ktf` 扩展名命中——大小写敏感 Rust extension 惯例；其余一切{.krf/无扩展名/未知扩展}维持 S-expr 既有路径逐字不变——原则 27 加性演化：新入口加性、默认面零回归} + 12 子命令全接线{run/check/test/tokens/stx/core/ir/bc/code/bench/anf/native——compile 族消费既有 compile_source_target} + 帮助文本双入口行）+ **require 声明皮肤第八映射**（本窗 E2E 发现的真实缺口：目标语法无 require 声明形态——.ktf 程序无法声明 IO 能力{print → E0006 或 require → E0001}；双侧补齐：种子 target.rs `parse_require_decl`{顶层声明家族——import/export/require 同族裸名形 `require io, write;` → `(require io write)` list 逐符号同构 S-expr；非名字 fail-closed + 强制分号 + 块内/表达式位维持既有拒绝{E0018 位置纪律 Stx 层双皮肤共享}} + 镜像 target_reader.krf `parse-require-decl`/`require-name`/`require-sep` 三函数同构 + 皮肤字典第八映射登记{20 §14 v1.19}）+ **cli_dual_entry_tests 22 case 新门族**（①正向五族：跨语法行为等价{fib 目标语料 run_source_target ⇒ 144 与 S-expr 面同值——原则 31 CLI 边界实证} + check ok 与 dump 面{零诊断 + 指令数 >0 + cache_hit false + tokens/stx 渲染含 fn/int 目标面} + test 面用例 PASS{fn prelude + `==` 断言用例} + 非扩展名/未知扩展名默认面维持 + **require 声明跨语法工件 parity{print 门控通过 + check 工件计数与 S-expr 面全等——2 原型/9 常量/5 全局引用/38 指令}** ②负向十七族：S-expr 源经目标入口拒绝 + 词法失败{未闭合字符串} + 语法失败{未闭合大括号} + 编译期 E0022 短路面 + HM E0005 目标面 + 运行时类型错误 + 恢复多错误收集{E0002 quote 坏形 + E0005 位置序——TD-013/r75 TC-DIAGS 共享尾段} + .krf 零回归锚{fib.krf 真实语料 ⇒ 144} + 大写 .KTF 不命中 + driver API 正交性{无文件名分派泄漏——§11 接口隔离} + use 域外 fail-closed + dump 面坏语料报错{词法/语法分层} + bench 复跑确定性 + require 坏形三族{非名字/缺分号/块内} + E0006 未声明 print + 双侧 Reader require 解析 parity{Stx 正典渲染字节级一致} + S-expr 恢复面共享尾段零回归——正负比 5:17 ≥ 1:3 合规）。
- **GATE 1 六命令 clean 起步全绿**：cargo clean → build --release **18.76s 零告警** / check --workspace --all-targets 0 errors 0 warnings / fmt --all --check 0 diff（顺修后归零）/ clippy --workspace --release --all-targets -D warnings 0 errors（result_large_err allow 顺修后归零）/ **test --release --workspace 1322:0:0**（净 +22 = cli_dual_entry_tests 22 case；RUST_MIN_STACK=16777216）+ 审计×6 280 case 真实 EXIT 0 ×6 + **CLI 双路径验收**：.krf 八路径零回归（fib ⇒75025/⇒144 + check ok：2 原型/9 常量/5 全局引用/38 指令[缓存未中；会话命中 0/0] + effect_stress ⇒120 + higher_order ⇒(1 4 9 16 25) + closures ⇒(4 2)/⇒42 + macros ⇒(2 1)/⇒42 + test PASS 2/2 + match ⇒ fib-13 维持）+ .ktf 新路径 E2E 十子命令（run fib.ktf ⇒75025/⇒144{与 .krf 同输出} + check ok 逐字节一致{2 原型/9 常量/5 全局引用/38 指令——跨语法工件 parity 的 CLI 面实证} + test PASS 1/1 + tokens/stx/core/bc/anf{纯计算} + bench 74.692ms + require 负例三族{非名字/缺分号/块内}）+ 例行监测（match 用户面 1 语料维持{match.krf} / @/vector #(//use 语言面 0 / `->` .ktf 语料零{KTF_SOURCES 守卫带内}）+ OBS-C bench fib 三轮 71.480/71.128/70.888ms（r55→r125 带内——<65ms 触发线不满足维持）。
- **演进位置**：**CLI 双入口窗全闭 ✅**（switch-window-plan §4 域外登记行「CLI 双入口（P3 设计候选）」清偿——双 Reader 并存期入口形态落地：.krf 默认面零回归 + .ktf 加性入口全子命令覆盖 + require 声明皮肤第八映射双侧 + 22 case 门族）；**1322 基线自 r125 起**；14 行触发族判定零变化（本窗 = 入口形态轮零 T3+ 消费信号）；.ktf 用户面语料消费信号（examples/usage/*.ktf 就位）= M2 语料消费形态候选——t3plus #5 族邻域登记态；下一演进 = HM 深化（.ktf 语料锚已就位）或 .ktf 用户面语料族就位（M2 形态——触发表邻域）或触发式家族零信号维持——按用户指令序或自然信号。
- 对账链：matrix r125 行 + 本节 + rec 87（03 层） + t3plus v1.45 + switch-window-plan v1.10 + 20 v1.19（皮肤字典第八映射） + 根层 l r125 条目 + README 两处 + worklog 三链镜像。

## r124 —— match 实施批 M-4：.krf 镜像同步（双 Reader 分歧窗闭窗 · match 实施窗全闭 · 1300 新基线）

**日期**：2026-11-03　**类型**：match 实施窗第四批（净 +15——**1300 基线自 r124 起**）　**驱动**：用户三链指令（①继续推进 目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施 ②按照 docs/sop.md 流程结合 docs/lang-design/ 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）——194-a..194-d（M1 指令开窗第二十九例——r123 收口笔推荐序首位兑现{match 实施批 M-4 = match-design.md v1.3 §6 批路径 M-3 后推荐序首位，三源一致}）

- **194-a match 实施批 M-4 实施**（match-design.md v1.3 §6 批表 M-4 行字面兑现——.krf 镜像同步，步② 语法批合并承载；依赖 M-1 ✅ + 步② ✅ 双满足）：**镜像侧 match 语法臂七函数族**（bootstrap/target_reader.krf ~215 行——种子 r121 parse_match 家族逐函数同构移植：parse-match[scrutinee 完整 expr + 臂循环——尾逗号可省/臂间逗号强制/零臂 fail-closed] + match-arms-loop[逆序臂累积 + 未闭合同构错误形态] + match-arm/match-arm-guard/match-arm-arrow[「先 atom 后判分隔符」三分支算法镜像——pattern 后逗号 = or/序对混用专项诊断 + 守卫 if 可选 + 臂节点 (pattern [guard] body)] + parse-pattern-or/pattern-or-loop[or 标记表——单原子裸返 + or 符号跨度 = 首 Token 锚] + parse-pattern-atom[字面量五族 + unit nil 皮肤 + ident 绑定 + `_` 桥 target_symbol_name 恒等 + path 域外 fail-closed{22 §27} + 括号三分支{二元拆构/分组 or 链/分组恒等} + 深度帽 8{>8 fail-closed}] + pattern-group-or-loop[括内 or 链——逗号混用 fail-closed + 闭括号跨度合并]）+ **语句位分派翻转**（parse-stmt-or-expr 的 match domain-out 退役 → parse-match——M-1 位改判的镜像侧兑现）+ **表达式位臂**（parse-primary 增 match 分派——r110 表达式位 if 先例同构）+ **分歧窗锚点翻转**（match_m1_reader_tests 分歧窗锚——镜像侧从域外诊断断言翻转为字节级同渲染断言；**双 Reader 分歧窗 M-1..M-3 正式闭窗**）+ **match_m4_krf_mirror_tests 15 case 新门族**（①语法 parity 正向两族{r121 全语料 + 位置形六面——Stx 正典渲染含 Span 字节级镜像} ②负向十一族{消息 + Span 字节级镜像：零臂/三元/裸 or 混逗号/括内 or 混逗号/右元 or/限定名/缺 =>/未闭合/非模式 Token/缺臂分隔/深度帽 9×2} ③词法 parity 维持{词法层零触碰实证} ④跨阶段消费{镜像 Reader → 自举 Expander → 自举 Compiler → VM 全链 E2E ⇒ 161 + 复执行确定性}——正负比 3:12 ≥ 1:3 合规）+ **治理文档**（match-design.md v1.4：§3.0 分歧窗登记完成化 + §6 批表 M-4 ✅ + 头部三行；target_reader_krf_tests domain-out 注记更新）。**开发实录（诚实登记）**：①镜像 .krf 括号平衡两处（match-arms-loop cond 子句少一闭括——define 被吞入函数体触发 E0002「define 必须位于函数体头部」当轮定位；parse-pattern-atom 终行多一闭括——python 栈模拟审计定形；r122「嵌套 match 括号平衡三轮」同族）②E2E 语料 pair 类型注记修正（`(p: (i64, i64))` 非目标面类型域——改 cons(a, b) 运行时构造形[m2 先例对齐]）③fmt 六处顺修后归零。
- **GATE 1 六命令 clean 起步全绿**：cargo clean（747 files/201.0MiB）→ build --release **19.41s 零告警** / check --workspace --all-targets 0 errors 0 warnings / fmt --all --check 0 diff（顺修后归零）/ clippy --workspace --release --all-targets -D warnings 0 errors / **test --release --workspace 1300:0:0**（净 +15 = match_m4_krf_mirror_tests 15 case；RUST_MIN_STACK=16777216）+ 审计×6 280 case 真实 EXIT 0 ×6（m3「窗 M 出口条件达成」/e5close「E5 出口三条件全绿——S4 收口 GO」结论行复核）+ CLI 八路径零回归（fib ⇒75025/⇒144 + check ok：2 原型/9 常量/5 全局引用/38 指令[缓存未中；会话命中 0/0] + effect_stress ⇒120 + higher_order ⇒(1 4 9 16 25) + closures ⇒(4 2)/⇒42 + macros ⇒(2 1)/⇒42 + test PASS 2/2 + match ⇒ fib-13 维持）+ 例行监测（match 用户面 10 = match.krf 消费语料维持{M-4 = 镜像语法批零用户语料增量} / match .ktf 语料命中全为标识符与注释非语言面{match_bindings + match_* 函数族 + KEYWORDS 列表} / net/extern/@/vector #( 语言面 0 / syntax-parse = TD-005 注记本体[r72 起 49 轮一致] / `->` .ktf 语料零[KTF_SOURCES 守卫带内]）+ OBS-C bench fib 三轮 70.982/71.384/70.478ms（r55→r124 带内——<65ms 触发线不满足维持）。
- **演进位置**：**match 实施窗全闭 ✅**（match-design.md v1.4 §6 批路径：M-1 ✅ r121 → M-2 ✅ r122 → M-3 ✅ r123 → **M-4 ✅ r124**——语法/语义/诊断三义务面全兑现 + 双 Reader 分歧窗闭窗）；**1300 基线自 r124 起**；14 行触发族判定零变化（match 行维持 r122 翻转态——消费语料 match.krf 十面命中维持）；后续 match 相关演进均触发式登记态（类型驱动穷尽[原则 26 Stage 2+ 候选]/结构化模式[类型声明族独立窗]/向量字面量模式[TD-002 三判据联动]——零信号不开窗）；下一演进 = CLI 双入口形态（P3 候选）或 HM 深化或触发式家族零信号维持——按用户指令序或自然信号。
- 对账链：matrix r124 行 + 本节 + [rec 86（03 层）](docs/worklog/03_stage-3_入场序列/86_r124_match实施批M4.md) + t3plus v1.44 + match-design.md v1.4 + 根层 l r124 条目 + README 两处 + worklog 三链镜像。

## r123 —— match 实施批 M-3：穷尽性诊断（E0025 保守规则双面落地 · §4.1 五条实施裁定 · 1285 新基线）

**日期**：2026-11-03　**类型**：match 实施窗第三批（净 +16——**1285 基线自 r123 起**）　**驱动**：用户三链指令（①继续推进 目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施 ②按照 docs/sop.md 流程结合 docs/lang-design/ 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）——193-a..193-d（M1 指令开窗第二十八例——r122 收口笔推荐序首位兑现{match 实施批 M-3 = match-design.md v1.2 §6 批路径 M-2 后推荐序首位}）

- **193-a match 实施批 M-3 实施**（match-design.md v1.2 §4 保守规则三条 + **v1.3 §4.1 五条实施裁定入档**——诊断面双面同源实施）：**种子侧 match_desugar.rs E0025 穷尽性门**（check_exhaustive + pattern_is_total + scan_top_bools + or_marker_items 四函数——穷尽 ⇔ 无守卫全匹配臂{通配/裸绑定/or 含全匹配备选——折叠面 test=None 类轻量重推导} ∨ bool 闭域 {true,false} 双覆盖{顶层收集 + or 展平——`(or true false)` 单臂 = 双覆盖}；否则 E0025 fail-closed{消息携建议补 `_ =>` 终臂或 true/false 闭域双臂 + int/float/str/() 开放域不判定 + match-design §4 引用——Span 指向 match 形式}）+ **自举侧 expander.ktf match_exhaustive 族镜像**（match_pat_total/match_alts_total/match_pat_has_bool/match_alts_have_bool/match_arms_total/match_arms_have_bool/match_exhaustive 七函数 + expand_match 门插入——TRUE_TAG/FALSE_TAG 标签比较 + 折叠成功后触发{结构诊断优先序双侧镜像}）+ **五条 M-3 裁定入档**（match-design v1.3 §4.1：①无守卫严化——带守卫通配/绑定/字面量臂零贡献{守卫可否决——计入将违反「兜底理论不可达」声明；闭域枚举同规} ②顶层收集 + or 展平——嵌套序对位字面量不计{is-pair 恒非全匹配} ③模式结构豁免 + 诚实边界——bool 豁免不依赖审查值类型{展开期无类型 + eq : any→any→bool——HM 不拦}；运行时兜底**残余可达类 = 豁免面 × 非 bool 审查值**{原则 42 双层实例——「理论不可能」精确化} ④门后置折叠——结构诊断保持 surfacing 优先序{M-2 负例族消息序契约零扰动} ⑤纯诊断批——脱糖产物与 M-2 字节级全同{均匀链 + 兜底节点保持——零死码消除}）+ **诊断码 E0025 指配**（E0001-E0024 后次号——与 E0002 族同通道渲染{展开期错误 → Stage::Expand + kerf-span 源映射}，零新通道——原则 42 编译期诊断正交维持）+ **M-2 四测试协同收窄**（①match_m2_pattern_family_parity + ②nested_pair_parity + ③dual_path 双语料[模式全族/嵌套序对]——补 `_ => 9`/`_ => 0` 通配终臂 + 手写等价形同步{均匀链兜底节点保持——parity 三向全等} ④non_exhaustive_runtime_fallback——语料改残余可达类{`(match 5 (true 1) (false 0))` + str 审查值形}——M-2 期自注释「M-3 降低可达性」预言兑现{直接非穷尽形 = 编译期拒绝}）+ **match_m3_exhaustiveness_tests 16 case 新门族**（①正向五族{通配终臂 dual-path + 运行时双路径 / 绑定臂全匹配 / bool 闭域豁免——真假双值 × 双路径 / or 展平闭域 `(or true false)` 单臂 / or 含通配备选 `(or _ 0)`} ②负向十族{字面量单双臂 / 开放域四族[int 多臂/float/str/nil+int] / 带守卫三形[守卫通配/守卫绑定{M-2 迁移负例}/守卫排除通配全匹配性] / 半闭域两形 / 闭域带守卫 / nil 单臂非闭域+嵌套位字面量不计 / 序对臂恒非全匹配 + or 字面量非全匹配两形} ③消息面双路径字节镜像{assert_e0025 六语料族——种子↔自举逐字节等价} ④结构诊断优先序{七组先例消息先于 E0025——双侧} ⑤兜底残余类{豁免面 × 非 bool 审查值双路径 Stage::Run + 直接非穷尽形 Stage::Expand 编译期接管} ⑥check 通道 E2E{负例 Err Stage::Expand + E0025 文本 + 正例闭域程序零诊断——E0005 正交共存} ⑦目标面门{read_target_source → 种子/自举双侧同消息} ⑧闭域 parity 三向{目标面/S-expr 面/手写等价形含兜底节点——纯诊断批锚}）。
- **GATE 1 六命令 clean 起步全绿**：cargo clean（730 files/194.6MiB）→ build --release **17.95s 零告警** / check --workspace --all-targets 0 errors 0 warnings / fmt --all --check 0 diff（顺修两处后归零——or_marker_items 重构 + match guard 形）/ clippy --workspace --release --all-targets -D warnings 0 errors（顺修 collapsible_match 一处后归零）/ **test --release --workspace 1285:0:0**（净 +16 = match_m3_exhaustiveness_tests 16 case；RUST_MIN_STACK=16777216）+ 审计×6 280 case 真实 EXIT 0 ×6（m3「窗 M 出口条件达成」/e5close「E5 出口三条件全绿——S4 收口 GO」结论行复核）+ CLI 八路径零回归（fib ⇒75025/⇒144 + check ok：2 原型/9 常量/5 全局引用/38 指令[缓存未中；会话命中 0/0] + effect_stress ⇒120 + higher_order ⇒(1 4 9 16 25) + closures ⇒(4 2)/⇒42 + macros ⇒(2 1)/⇒42 + test PASS 2/2 + match ⇒ fib-13）+ 例行监测（match 用户面 5 = match.krf 消费语料维持{M-3 纯诊断批零语料增量} / net 语言面 0[命中 1 = E0006 诊断文本带内] / extern/@/vector #( 语言面 0 / syntax-parse = TD-005 注记本体[r72 起 48 轮一致] / `->` .ktf 语料零[KTF_SOURCES 守卫带内]）+ OBS-C bench fib 三轮 70.479/70.906/70.602ms（r55→r123 带内——<65ms 触发线不满足维持）。
- **演进位置**：**match 实施窗推进至 M-3 ✅**（match-design.md v1.3 §6 批路径：M-1 ✅ r121 → M-2 ✅ r122 → **M-3 ✅ r123** → M-4 .krf 镜像同步）；**1285 基线自 r123 起**；14 行触发族判定零变化（match 行维持 r122 翻转态——消费语料维持）；**E0025 = 首个穷尽性族编译期诊断码**（match-design §4 诊断义务三件兑现——语法域 M-1 + 语义 M-2 + 诊断 M-3 全落）；双 Reader 分歧窗 M-1..M-3 维持（M-4 闭窗）；下一演进 = match 实施批 M-4（.krf 镜像同步——双 Reader 分歧窗闭窗 + 锚点测试翻转）或 CLI 双入口形态（P3 候选）或 HM 深化——按用户指令序或自然信号。
- 对账链：matrix r123 行 + 本节 + [rec 85（03 层）](docs/worklog/03_stage-3_入场序列/85_r123_match实施批M3.md) + t3plus v1.43 + match-design.md v1.3 + 根层 l r123 条目 + README 两处 + worklog 三链镜像。

## r122 —— match 实施批 M-2：皮肤字典第七映射（脱糖双侧落地 · compiler.ktf 潜伏清偿 · 1269 新基线）

**日期**：2026-11-02　**类型**：match 实施窗第二批（净 +18——**1269 基线自 r122 起**）　**驱动**：用户三链指令（①继续推进 目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施 ②按照 docs/sop.md 流程结合 docs/lang-design/ 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）——192-a..192-d（M1 指令开窗第二十七例——r121 收口笔推荐序首位兑现{match 实施批 M-2 = M-1 落地后推荐序首位}；[match-design.md v1.1 §6] M-2 批路径字面兑现）

- **192-a match 实施批 M-2 实施**（match-design.md v1.1 §3 语义表全量 + **v1.2 §3.4 正典产物形状裁定入档**——脱糖单源双面实施）：**种子侧 match_desugar.rs 新模块**（kerf-expander——`(match scrut (pattern [guard] body)...)` → `(let ((m scrut)) chain)` 纯皮肤链{let/if/and/or + eq/is-pair/is-nil/head/tail/error 全既有内建应用——**零新原语零通道**，8 原语不变性构造性成立}；正典形状：temp = match-scrut$hyg$N 全局单调[ExpandCtxt::fresh_uniq 新计数器——单次求值契约 §3.3 + 最大基数并列消除] + 臂右折叠均匀 if 链[终态臂 (if true ...)——脱糖层零死码消除{报错>静默}；消除归优化器域] + 路径直取[(head m)/(tail m) 链——零中间临时名] + 守卫 `(and T (let binds G))` 形[短路保序 + 体位重绑定——臂绑定零泄入 rest{§3.3 臂隔离}] + 兑底 `(error "匹配失败：无臂匹配")`{§4 防御层}）+ **Keyword::Match 入面**（kerf-syntax/symbol.rs 第 26 关键字——ALL/as_str/from_name + roundtrip 锚 25→26；E0020 绑定禁令面双侧自动扩展[is_reserved_word 单源]；`match` 已在 22 定稿词面——实现面追平「词面零新增」）+ **自举侧 expander.ktf 镜像**（expand_match 族 + match_analyze/match_analyze_pair/match_analyze_or/ match_chain 递归族 + KEYWORDS 增 match + MATCH_TMP_NEXT 重置——节点六头协议构造性同构）+ **模式绑定位 E0020 第三层**（脱糖层保留字检查携精确 span——Stx/CoreExpr 两层不识模式形状）+ **or 绑定映射恒等裁定**（名+路径全同——严于设计字面名集规则：动态类型无位置统一通道，join point 域外；§7 问题 1 裁定兑现）+ **重复绑定 fail-closed**（Rust 同形）+ **compiler.ktf 潜伏缺陷清偿**（compile_inner_proto 写回硬编码参数数覆盖 proto_bump_nlocals 回填——handle H/B 体原型 nlocals 归零，handle 体含 let 即「局部槽越界」；compile_fn 的 r50-β 修复[max(参数数,bump)] 在 inner 路径漏修——r116 D61 三潜伏同族；M-2 脱糖产物首次触发[handle × let]，用户指令①「中途穿着缺陷直接推进」行权——极小复现探针四轮窄化定位[手写等价形同样失败 = 非脱糖缺陷]）+ **match_m2_desugar_tests 18 case 新门族**（①跨语法字节码 parity 六族——目标面/ S 表达式面/ 手写 cond-let 等价形三向字节码全等[M-2 验收门——r106 SyntaxTransitionValidator 纪律]：基础/守卫绑定/模式全族/or 标记/嵌套序对/审查值表达式 ②种子↔自举双路径 parity[E1-β 纪律扩展] ③运行时语义种子路径[字面量/绑定/守卫可见/首臂胜出/序对/嵌套/or 同位/nil 皮肤/str/bool/float/Int-Float 类型严格/语句位/表达式位] ④生产路径 E2E[自举展开器+自举编译器真实运行] ⑤§4 兜底运行时错误双路径 ⑥负例族[零臂/臂形/三元/单元素/向量/保留字绑定/重复绑定/or 名集/or 形态/or 路径] ⑦负例消息面双路径镜像[六族逐字节等价] ⑧HM check 集成[E0005 正交] ⑨守卫效应序锚[§7 问题 2：处理器 resume false 否决首臂——结构测试失败短路实证] ⑩M-1 边界翻转[全局引用面零 match + 运行值] ⑪嵌套 match 卫生锚[外臂绑定内层可见 + 臂隔离双锚]）+ **M-1 边界锚翻转**（match_frontend_pass_through_boundary——伪应用面退役[全局引用零 match + 双路径脱糖一致]）+ **用户面消费语料 examples/usage/match.krf**（分类/守卫/序对拆构/or/单次求值五面——生产路径 E2E ⇒ fib-13）。**开发实录（诚实登记）**：①四轮行为探测先行（生产路径 handle × match 槽位缺陷——极小复现窄化四变体族至 handle × let 极小形[手写等价形同败 = 既有潜伏非脱糖缺陷]；双路径展开探针实证指令序一致[Symbol ID 差 = 探针双表假象]）②S-expr 臂形笔误三轮（「n if guard」目标面混写——中间形臂 = (pattern guard body) 无 if 关键字；嵌套 match 括号平衡经栈模拟定形——match 臂为 match 形式直接元素无臂列表包裹层）③守卫 bool 型纪律发现（处理器 resume nil → E0004「if 条件需要 bool」——显式 bool 纪律同族[非脱糖缺陷]，锚改 resume false + match-design v1.2 §3.4 裁定 2 入档）④nil 字面量词面（S-expr 面表达式位 nil 非 `()`——空列表 = E0002）。
- **GATE 1 六命令 clean 起步全绿**：cargo clean（745 files/201.1MiB）→ build --release **18.68s 零告警** / check --workspace --all-targets 0 errors 0 warnings / fmt --all --check 0 diff / clippy --workspace --release --all-targets -D warnings 0 errors / **test --release --workspace 1269:0:0**（净 +18 = match_m2_desugar_tests 18 case；RUST_MIN_STACK=16777216）+ 审计×6 280 case 真实 EXIT 0 ×6（m3「窗 M 出口条件达成」/e5close「E5 出口三条件全绿——S4 收口 GO」结论行复核）+ CLI 八路径零回归（fib ⇒75025/⇒144 + check ok：2 原型/9 常量/5 全局引用/38 指令[缓存未中；会话命中 0/0] + effect_stress ⇒120 + higher_order ⇒(1 4 9 16 25) + closures ⇒(4 2)/⇒42 + macros ⇒(2 1)/⇒42 + test PASS 2/2 + **match ⇒ fib-13 新路径**）+ 例行监测（**match 用户面命中 10 = match.krf 消费语料本体——t3plus #5 行信号翻转**{M-2 语义落地} / net/extern/@/vector #( 语言面 0 / syntax-parse = TD-005 注记本体[r72 起 47 轮一致] / `->` .ktf 四件全零[KTF_SOURCES 守卫带内]）。
- **演进位置**：**match 实施窗推进至 M-2 ✅**（match-design.md v1.2 §6 批路径：M-1 ✅ r121 → **M-2 ✅ r122** → M-3 穷尽性诊断 → M-4 .krf 镜像同步；**t3plus #5 行 match 语言面消费信号翻转**——examples/usage/match.krf 就位）；**1269 基线自 r122 起**；双 Reader 分歧窗 M-1..M-3 维持（.krf 镜像侧维持域外诊断——M-4 闭窗）；14 行触发族判定：#5 行翻转、其余 13 行零变化；下一演进 = match 实施批 M-3（穷尽性诊断——§4 保守规则三条 + E0xxx 通道）或 CLI 双入口形态（P3 候选）或 HM 深化——按用户指令序或自然信号。
- 对账链：matrix r122 行 + 本节 + [rec 84（03 层）](docs/worklog/03_stage-3_入场序列/84_r122_match实施批M2.md) + t3plus v1.42 + match-design.md v1.2 + 20 v1.18 + 22 v2.15 + 根层 l r122 条目 + README 两处 + worklog 三链镜像。

## r121 —— match 实施批 M-1：Reader 臂（模式文法全量 · 域外诊断退役 · 中间形裁定三条 · 1251 新基线）

**日期**：2026-11-02　**类型**：match 实施窗首批（净 +10——**1251 基线自 r121 起**）　**驱动**：用户三链指令（①继续推进 目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施 ②按照 docs/sop.md 流程结合 docs/lang-design/ 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）——191-a..191-d（M1 指令开窗第二十六例——r120 收口笔推荐序首位兑现{match 实施批 M-1 = 切换窗全闭后推荐序首位}；[match-design.md v1.0 §6] M-1 批路径字面兑现）

- **191-a match 实施批 M-1 实施**（match-design.md v1.1 §6 批表——Reader 臂：**target.rs match_expr 解析（模式文法 §2 全量）+ 域外诊断退役（match 位改判）**）：**parse_match + parse_pattern_or + parse_pattern_atom 三函数族**（kerf-reader/src/target.rs +~215 行——语句位与表达式位同形{parse_stmt_or_expr 分派 + parse_primary 表达式位——r110 表达式位 if 先例同构}；scrutinee = 完整 expr；臂形 `(pattern body)` / `(pattern guard body)` 长度分立——M-2 脱糖消费契约无歧义）+ **模式文法全量**（字面量五族{int/float/str/bool/`()`=nil 皮肤}/绑定 ident/`_` 通配/序对二元拆构/分组恒等/or 闭界链 + 守卫 `if expr` + 尾臂逗号可省）+ **中间形裁定三条入档**（match-design.md v1.1 §3.0：①or 标记形 `(or p q ...)`——`|` 为保留运算符 Token 无绑定碰撞 + 序对恒二元 vs or ≥3 元长度域不交；②括号内至多二元——`(p)` 分组恒等 / `(p, q)` 二元拆构{两侧元素须 pattern_atom——裸 or 链 fail-closed 带括号提示} / `(p, q, r)` 三元 fail-closed「至多二元」/ 括号包裹嵌套按 EBNF 字面合法{右不嵌套 = rest 位 pattern_atom 字面解读——深度帽限界}；③深度帽 8——嵌套 >8 fail-closed{§1 防御性栈保护字面——与 parse-list 256 同锚收紧至模式域}）+ **域外诊断退役**（「match 语句（模式匹配设计文档——T3+ #5）」域外诊断退役——位改判开域；限定名模式 `a::b` = 新 fail-closed 域外诊断{22 §27 对账——模式位无路径形态}）+ **02 §8.13.1a 增补行**（match 产生式族九条入 Level 0 定稿域增补位——设计单源 match-design.md v1.0 §2 → 语言面规范锚 → Reader 解析域开放，定稿域边界纪律三步链字面兑现；Date/Version 头 v7.11）+ **match-design.md v1.1**（§3.0 中间形裁定 + §6 批表 M-1 行 ✅ r121 + M-4 依赖行更新{步② ✅ 既成}）+ **新测试文件 match_m1_reader_tests.rs**（10 case 五面：①中间形结构三函数{基础臂/守卫臂/模式全族+命名映射}②位置形{语句位 do 穿线/块尾/表达式位 let 右值/顶层/scrutinee 表达式}③逗号纪律{尾逗号两形/缺臂分隔 fail-closed}④fail-closed 负例族{零臂/三元/裸 or 混逗号/括内 or 混逗号/右元 or/限定名/缺 =>/未闭合/非模式 Token} + 深度帽边界{8 合法/9 拒绝 ×2}⑤**跨语法 Stx parity match 语料族七对**{目标 match 面 ↔ S-expr 中间形文本——数据面正典渲染字节级全等；Span 跨文本出比较域[r106 纪律]} + **两枚边界锚**{.krf 镜像分歧窗锚——种子侧开域 vs 镜像侧维持域外诊断[M-4 闭窗时翻转] + 前端伪应用边界锚——双路径一致通过至编译，失败点 = 运行时未绑定全局 match[M-2 落地脱糖后消除]}）+ **两处既有断言退役**（target_reader_tests domain_out_diagnostics + target_reader_krf_tests syntax_parity_domain_out 各一行 match 域外断言——位改判语义随诊断退役；注释注记 M-4 分歧窗锚点在档）。**开发实录（诚实登记）**：①多轮行为探测先行（probe 四轮：中间形结构/边界行为/双路径一致性/诊断质量——「match 语句」域外断言两处既有测试面命中当轮退役）②arm 级裸 or+逗号诊断改进（generic「期望 =>」→ 专项「or 模式与序对拆构不可混用（请括号包裹）」）③展开器语义守卫裁定**不采纳**——M-1 纯 Reader 臂纪律{红线 4 零窗口合并}：中间形经展开/编译为伪应用{双路径一致}通过，失败点 = 运行时未绑定诊断——诚实边界登记于 match-design.md v1.1 §3.0{M-2 落地脱糖后消除}。
- **GATE 1 六命令 clean 起步全绿**：cargo clean（752 files/200.4MiB）→ build --release **18.02s 零告警** / check --workspace --all-targets 0 errors 0 warnings / fmt --all --check 0 diff / clippy --workspace --release --all-targets -D warnings 0 errors / **test --release --workspace 1251:0:0**（净 +10 = match_m1_reader_tests 10 case；RUST_MIN_STACK=16777216）+ 审计×6 280 case 真实 EXIT 0 ×6（m3「窗 M 出口条件达成」/e5close「E5 出口三条件全绿——S4 收口 GO」结论行复核）+ CLI 七路径零回归（fib ⇒75025/⇒144 + check ok：2 原型/9 常量/5 全局引用/38 指令[缓存未中；会话命中 0/0] + effect_stress ⇒120 + higher_order ⇒(1 4 9 16 25) + closures ⇒(4 2)/⇒42 + macros ⇒(2 1)/⇒42 + test PASS 2/2）+ 例行监测全项带内（match 用户面 examples 语料 0{M-1 = Reader 侧开域，消费面信号待 M-2} / match .ktf 语料命中 6 全为英文注释非语言面 / net 命中全为错误消息文本与 Rust 预留族名非语言面 / extern 语言面 0 / @ 0 / vector #( 0 / syntax-parse = TD-005 注记本体[r72 起 46 轮一致] / `->` .ktf 语料四件全零[KTF_SOURCES 守卫带内]）。
- **演进位置**：**match 实施窗开启——M-1（Reader 臂）落地**（match-design.md v1.1 §6 批路径：M-1 ✅ r121 → M-2 皮肤字典第七映射{cond/let 脱糖——SyntaxTransitionValidator 扩展} → M-3 穷尽性诊断 → M-4 .krf 镜像同步{分歧窗闭窗}；切换窗 r120 窗全闭后推荐序首位兑现）；**双 Reader 分歧窗 M-1..M-3 登记**（.krf 镜像侧维持域外诊断——M-4 语法批同步闭窗，锚点测试在档随 M-4 翻转）；**1251 基线自 r121 起**；14 行触发族判定零变化（match 语言面消费信号 examples 语料零命中维持——M-2 落地语义后语料可消费）；下一演进 = match 实施批 M-2（皮肤字典第七映射——cond/let 脱糖）或 CLI 双入口形态（P3 候选）或 HM 深化——按用户指令序或自然信号。
- 对账链：matrix r121 行 + 本节 + [rec 83（03 层）](docs/worklog/03_stage-3_入场序列/83_r121_match实施批M1.md) + t3plus v1.41 + match-design.md v1.1 + 02 v7.11 + 根层 l r121 条目 + README 两处 + worklog 三链镜像。

## r120 —— E5 收口清理批：切换窗终收口（四件 .krf 原件删除 · 原则 41 脚手架拆除 · 测试网与审计集语料域切换 · 1241 新基线）

**日期**：2026-11-01　**类型**：切换窗终收口轮（净 -3 合法收缩——删 4 验证完成退役测试 + 增 1 目标面命名守卫——**1241 基线自 r120 起**）　**驱动**：用户三链指令（①继续推进 目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施 ②按照 docs/sop.md 流程结合 docs/lang-design/ 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）——190-a..190-d（M1 指令开窗第二十五例——r119 收口笔推荐序首位兑现{E5 收口清理批 = 五步全落后自然下一步}）

- **190-a E5 收口清理批实施**（switch-window-plan v1.8 §5 推荐序首位 + 原则 41 拆除判据已满足{≥98% parity 三路门全量覆盖 r109-r119 + 三阶段 fixpoint r118 + 验证等价 r119 全绿 + 回退能力经平行件策略走完生命周期}——**拆除面 = 生产链 + 语料面，种子链 S-expr Reader 保留 = BS-A 混合自举宪制裁定**）：**四件 .krf 原件删除**（crates/kerf-driver/src/bootstrap/{preamble,reader,compiler,expander}.krf——git rm；生产链零影响实证：三桥自 r110/r114/r116 起已从 .ktf 加载 + prelude 注入自 r109 走目标 Reader 桥）+ **测试面六文件语料域切换**：① bootstrap_compiler_tests——gate_b_fixpoint + gate_b_b1_programs_execute **两测试退役删除**（i1 §5 门 B 语义完备迁移至 .ktf fixpoint 门族{步④ 三门 + 步⑤ 三阶段门}——头部迁移映射注记）+ parity_preamble_injection_order 删 .krf 语料腿保留模块头腿 ② switch_corpus_parity_tests——**三路门四件改造为两路门**（`_three_way`→`_dual_path`——基线腿随 .krf 原件退役，等价历史验证归档 RELEASE r109-r119；.ktf 种子目标 Reader ↔ 生产桥两路 parity 长期有效{双实现等价的持续守卫}）+ ktf_expander_generation_parity_regression 删除（对照物 .krf 种子态消失——r116 翻译缺陷回归门完成历史使命）③ switch_step5_validation_tests——fixpoint_gate_dual_caliber_unified **重组为 fixpoint_gate_target_syntax_three_stage**（口径一 .krf 链随语料退役——口径二 .ktf 三阶段 + BS-C 传递性 B₁'=B₂'=B₃' 承载持续验证）+ switch_compile_speed_regression_within_2x 删除（11 §6.3 判据④ 完成历史使命——实测值 0.990/1.005/1.119 归档 switch-window-plan v1.8 §5 + 本 RELEASE r119 节；对照物消失）④ namespace_tests d50 锚语料切换 preamble.krf→preamble.ktf（compile_source_target 链——`_`→`-` 符号映射经 target_symbol_name 单点[02 §8.13 r109 条目]语义面断言恒定）⑤ hm_production_switch_tests——七语料锚三 .krf 锚切换 .ktf（target_front/oracle_diag_count_target/krf_diag_count_target 三新 helper——core 语法不变性 = HM 判定面同体）+ boundary_three_corpus_krf_subset_direction 三语料切换 .ktf（宽松化方向守卫目标面延续）⑥ bootstrap/mod.rs——KRF_SOURCES 守卫表 10→7 件（删四 + **target_reader.krf 补入 R1 顺修**[r107 期遗漏诚实登记——其 `->` 为目标词法器效果签名 Token 载荷功能面，R4 检查文档化豁免 + R2 `?` 尾缀仍查]）+ **KTF_SOURCES 四件新守卫**（ktf_naming_modern_closed——`fn NAME` 名提取 + R2 `?` 尾缀零 + R4 `->` 全文件零容忍[目标面 match 臂 = `=>`、转换 = `a_to_b`——stray `->` 恒为陈旧面回归]——现代命名纪律目标语法面新锚）。
- **审计集语料域切换（GATE 5 载体——280 case 计数不变）**：stage2_gate_audit_r1（E01 B₁ 活性 + P03 门 B 轻量终验——语料 .krf→.ktf + 链 compile_source→compile_source_target）+ stage2_gate_audit_r2（P03 + P06 生产自宿主活性——同形态切换）+ stage1 审计头部 R4 顺修（历史描述「reader.krf + expander.krf on the VM」→ .ktf 现状）——**i1-design §5 门 B 语义在目标语法域延续**（B₁'/B₂' fixpoint + B₁ 活性 = .ktf 语料经 compile_source_target——与步④ 门同判据异载体：审计集可重跑口径[§7.3.1 规则 3]随架构演进语料域切换）。
- **R4 现状对齐扫描（.rs/.ktf 注释——描述当前状态的更新，历史记录保留）**：三桥源常量 doc（mod.rs/compiler.rs/expander.rs「retained as parity oracle」→「deleted by E5 close-out cleanup batch r120」）+ 四 .ktf 头部「deletion = step ⑤ wrap-up cleanup batch」时态完成化 + driver.rs 十处现状注释（Expander/Compiler 运行面 + prelude 常量 + bootstrap loading 消费面）+ lib.rs 头部 + 三桥「损坏」错误消息文本（reader/expander/compiler .krf→.ktf——保留组件 build/cache/check/cli/test/test_runner 的 .krf 消息不动）。
- **GATE 1 六命令 clean 起步全绿**：cargo clean（3770 files/1.1GiB）→ build --release **18.49s 零告警** / check --workspace --all-targets 0 errors 0 warnings / fmt --all --check 0 diff（R4 顺修一处：r2 审计 import 行宽 fmt 归零）/ clippy --workspace --release **--all-targets** -D warnings 0 errors（比 r119 口径更严——all-targets 覆盖暴露既有 doc lazy continuation 一处[switch_corpus_parity_tests 闭包单元门 doc 行首 `+`——当轮顺修改写]）/ **test --release --workspace 1241:0:0**（净 -3 = 删 4{gate_b_fixpoint + gate_b_b1 + 速度线 + 跨面生成 parity} + 增 1{ktf_naming_modern_closed}——RUST_MIN_STACK=16777216）+ 审计×6 280 case 真实 EXIT 0 ×6（含语料切换后的 r1/r2——**切换后首跑全绿即语义等价实证**）+ CLI 七路径零回归（fib ⇒144 + check ok：2 原型/9 常量/5 全局引用/38 指令 + effect_stress ⇒120 + higher_order ⇒(1 4 9 16 25) + closures ⇒42 + macros ⇒42 + test PASS 2/2）+ 例行监测全项带内（match 用户面 0 / extern 语言面 0 / @ 0 / vector #( 0 / syntax-parse = TD-005 注记本体 / `->` .ktf 语料四件零——net 命中 20 全为 Rust 注释技术用语非语言面{r114 起口径}）。
- **演进位置**：**切换窗终收口——五步①-⑤ + E5 收口清理批全部完成（窗全闭）**：07 §3.2.1 五步流程全链 + 原则 41 脚手架拆除时点兑现（S-expr 语法脚手架 = 步⑤ E5 收口一次性拆除——拆除边界 = 生产链 + 语料面{bootstrap 四件 .krf 原件 + gate B .krf 语料依赖}，种子链 S-expr Reader 保留 = BS-A 混合自举宪制裁定{VM 永久 Rust 基座 + 最大化前端自举}——保留组件七件 .krf{check/build/cli/test/test_runner/cache/target_reader} + 用户 S-expr 面{examples 语料 + read_source 种子链}不受影响）；**1241 基线自 r120 起**；14 行触发族判定零变化（E5 收口清理轮零 T3+ 消费信号）；下一演进 = match 实施批 M-1（match-design.md v1.0——#5 义务的窗内实施臂）或双 Reader 并存期 CLI 入口形态（P3 设计候选）或 HM 深化（.ktf 语料锚已就位）——按用户指令序或自然信号。
- 对账链：matrix r120 行 + 本节 + [rec 82（03 层）](docs/worklog/03_stage-3_入场序列/82_r120_E5收口清理批.md) + t3plus v1.40 + switch-window-plan v1.9 + 根层 l r120 条目 + README 两处 + worklog 三链镜像。

## r119 —— 切换窗步⑤ 验证等价收口轮：SyntaxTransitionValidator 结构化 + 门 B 双口径合并 + 三阶段传递性 + 诊断面 parity + 速度验收线实测（五步流程全落 · 1244 新基线）

**日期**：2026-11-01　**类型**：切换窗续窗收口轮（净 +7——**1244 基线自 r119 起**）　**驱动**：用户三链指令（①继续推进 目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施 ②按照 docs/sop.md 流程结合 docs/lang-design/ 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）——189-a..189-d（M1 指令开窗第二十四例——r118 收口笔推荐序首位兑现{步⑤ = 步④ 全落后自然下一步}）

- **189-a 步⑤ 实施**（07 §3.2.1 五步流程步⑤「⑤验证目标语法的编译器编译自身输出等价」——11 §6.3 三层验证 + 三阶段构建验收判据全兑现）：**SyntaxTransitionValidator 结构化**（kerf-driver/src/validator.rs 新增——02 §8.12「parity 纪律的结构化完备形态」**设计登记态→实施态**：三成员{old_reader = read_source / new_reader = read_target_source / pipeline = strip imports → 种子展开 → 种子编译[E1-β/I1 前端同构——Reader 为唯一比较变量]} + `validate_equivalence`（双解析 → **同 SymbolTable 穿线**——构造性 intern 序一致 → 语义载荷直接可比 → 分层口径比较）+ `SemanticDrift` 四元组诊断{name/old_span/new_span/description/suggestion——fail 路径结构化而非裸 panic} + `validate_test_suite` 批量报告{total/passed/failures + all_passed 套件门} + `disassemble_by_name` 跨链按名 helper{i1 §7.3 魔法符号口径单源化}；lib.rs 显式再导出——**未来 E5 收口清理批的删除守卫设施**[原则 41 拆除判据消费面]）+ **层 1 单元级收口**（皮肤字典全表 SemanticProof——**D2 六映射**[define→fn/let→let/if→if/perform→perform/handle→handle/lambda→closure] + **20 §14 扩充八条机器锚**[::路径分隔/nil→()/while!宏标记/命名映射 -↔_/module 生产面/多绑定 let/quote 调用形/define 调用形]——14 锚全过 validate_test_suite；**try! 条目登记态豁免**{S-expr 面 try* 无内建糖零消费面——机器锚不适用诚实标注}）+ **层 2 程序级收口**（三代表性程序对[fib/高阶闭包/效应往返]payload 全等 + 生产链行为锚[fib 12⇒144 / make_adder(30)(12)⇒42 / handle gift⇒120]——「同字节码 ⇒ 同行为」构造性推论 + 实证锚）+ **层 3 自举级收口**（**门 B 双口径合并** fixpoint_gate_dual_caliber_unified——11 §6.3「开窗时与既有门 B 合并为『fixpoint 门二/三阶段双口径』」字面兑现：口径一 .krf 链轻量复验[compiler.krf B₁/B₂ bytecode_equal + SHA-256——编译段轮换承重{完整三态口径 = bootstrap_compiler_tests gate B 引用}] + 口径二 .ktf 三阶段[B₁' 四件 → install 三态 → B₂' 四件全等——步④ 核心门同轮复验] + **BS-C 传递性扩展**[install B₂' 三态 → B₃' 再编——**三点 B₁'==B₂'==B₃' 全等**{不动点稳定性归纳步}——原则 53 第 4 句「A 编译 B、B 编译 C、B==C 字节级」完整链形]）+ **诊断面 parity 收口**（11 §6.3「错误消息等价断言——B3 负 307 case 先例形态」**跨语法口径**：cond 非列表子句/空子句[E0002 宏展开错——同一展开器逻辑镜像] + E0022 未绑定引用[N1-N3 解析链——目标面 `undefined_macro` 经 r109 命名映射与 S-expr 面 `undefined-macro` **同 intern**——消息**逐字节等价**三族实证；Span 跨文本天然不同按 BS-C 分层裁定出比较域）+ **编译速度回退验收线实测**（11 §6.3 陷阱 3「可接受编译速度下降 <2x」——三语料对 min-of-2 预热后：**reader 701ms/694ms ratio 0.990 / compiler 2.353s/2.365s ratio 1.005 / expander 8.386s/9.386s ratio 1.119——全部 ≪ 2.0**{展开/编译段 VM 自举耗时占绝对大头，读段复杂度差被管线稀释——蓝图 10x Reader 复杂度预期未转化为管线级回退}；preamble 对最小代表性弱诚实豁免）+ **诚实边界登记**（`m!()` 空参宏调用 = 词法 Unit 歧义域[目标词法器 `()` 合并 Unit 先于 MacroBang 后缀分支——perform Op() 有 Unit 特判而宏面无——零参宏调用无合法语义故 fail-closed 读错可接受；诊断 parity 对经非空参数形态到达共享展开器错误]）——**净 +7 测试**（switch_step5_validation_tests.rs 新门族：皮肤字典两函数 14 锚 + validator 负例锚 + 双口径门 + 诊断 parity + 层 2 + 速度线）。
- **开发实录**：诊断 parity 初版三对 `(while)`↔`while!()` 等零参形态实测证伪——目标面 code=1（Reader 错误「期望 (」——`()` 词法合并 Unit 先于宏后缀分支）vs S-expr 面 code=2（展开错误）；定位经 dump_tokens/dump_stx 双工具实测（发现 dump_stx 走 S-expr 自举链——.ktf 文件被 S-expr Reader 误读为「while! 符号 + 空列表」→ E0002）——修正为非空参数形态对（cond!(5)/cond!(())/undefined_macro(42)）三族逐字节等价；层 2 效应程序目标面初版误用前缀形态 `(+ 100 (ask))`（目标面须中缀 `100 + ask()`）——parse 实测定位后修正。
- **GATE 1 六命令 clean 起步全绿**：build --release **19.09s 零告警** / check 0 errors 0 warnings / fmt --check 0 diff / clippy --workspace --release -D warnings 0 errors / **test --release --workspace 1244:0:0**（24 target[单元 298 + 集成 946]；RUST_MIN_STACK=16777216 沿袭）+ 审计×6 280 case 真实 EXIT 0 ×6（m3「窗 M 出口条件达成」/e5close「E5 出口三条件全绿——S4 收口 GO」结论行复核）+ CLI 七路径零回归（fib ⇒144 + check ok：2 原型/9 常量/5 全局引用/38 指令 + effect_stress ⇒120 + higher_order ⇒(1 4 9 16 25) + closures ⇒42 + macros ⇒42 + test PASS 2/2）+ 例行监测全项带内（match 用户面 0 / @ 0 / vector #( 0 / `->` .ktf 零 / syntax-parse = TD-005 注记本体——net/extern 命中均为注释/FFI 文档面非语言面）。
- **11 §6.3 迁移验收判据达成对账（步⑤ 收口——「候选」转正）**：①四步替换顺序（D2）✅ r106-r118 按批；②三层验证 ✅（层 1 = 皮肤字典 14 锚 + 既有族 / 层 2 = 三程序对 + 行为锚 / 层 3 = 双口径门 + 传递性）；③三阶段 fixpoint ✅（r118 核心硬门 + r119 B₃' 传递归纳步）；④编译速度回退 <2x ✅（实测 0.990/1.005/1.119）；⑤错误消息等价断言 ✅（三族逐字节等价）。
- **演进位置**：**切换窗五步①-⑤ 全部完成——验证等价收口落地**（07 §3.2.1 五步流程全链走完：①新 Reader 本体 r106 → ②字节码化 r107-r108 → ③编译器源码目标语法重写 r109-r116 → ④目标语法自身编译 r118 → ⑤验证等价 r119）；**1244 基线自 r119 起**；14 行触发族判定零变化（切换窗续窗轮零 T3+ 消费信号）；下一演进 = **E5 收口清理批（.krf 原件删除——切换窗终收口）为自然下一步**（原则 41 拆除判据已满足：≥98% parity 三路门全量覆盖 + 三阶段 fixpoint + 验证等价全绿）或 match 实施批 M-1 或双 Reader 并存期 CLI 入口形态（P3 设计候选）——按用户指令序或自然信号。
- 对账链：matrix r119 行 + 本节 + [rec 81（03 层）](docs/worklog/03_stage-3_入场序列/81_r119_切换窗步⑤验证等价收口轮.md) + t3plus v1.39 + switch-window-plan v1.8 + 根层 l r119 条目 + README 两处 + worklog 三链镜像。

## r118 —— 切换窗步④ 实施轮：目标语法自身编译 + fixpoint 门族三件（compile_source_target 生产入口 · 1237 新基线）

**日期**：2026-10-31　**类型**：切换窗续窗实施轮（净 +3——**1237 基线自 r118 起**）　**驱动**：用户三链指令（①继续推进 目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施 ②按照 docs/sop.md 流程结合 docs/lang-design/ 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按照推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）——188-a..188-d（M1 指令开窗第二十三例——r117 收口笔推荐序首位兑现）

- **188-a 步④ 实施**（07 §3.2.1 五步流程步④「④用编译器编译目标语法的自身」——fixpoint 前置）：**compile_source_target 生产目标语法编译入口**（driver.rs 新增 compile_front_target + compile_source_target + lib.rs 导出——读段 = .krf 目标 Reader 桥[r109 起生产组件] + 展开段 = expander.ktf 自举[E1-β] + 编译段 = compiler.ktf 自举[I1]；**cache-free 构造性纪律**[§7.4 隔离——cached B₂ 会返回 B₁ 条目 = 假阳性防线 + B11/P4 维度分离]；**driver 入口族四形态收齐**：compile_front[.krf 生产]/compile_front_seed[.krf 种子]/compile_front_seed_target[.ktf 种子]/compile_front_target[.ktf 生产]）+ **步④ fixpoint 门族三件**：①**核心硬门**（B₁' = 生产目标链编译四件 .ktf 语料「自身」→ install B₁' 产物为三态新自举状态「产物编译自身」→ B₂' = 同链重编——**全结构 bytecode_equal + SHA-256 四件全等**[同链口径——构造性同 intern 序；诚实边界：.ktf 编译链读段 = target_reader.krf 桥[种子管线装载硬 P1]，轮换 Reader 态参与 gate-B 对称 install 但不喂 .ktf 读取——展开/编译两段轮换为 fixpoint 承重段]）②**跨链按名 oracle**（B₀' 种子目标路径 ↔ B₁' 生产目标链——四件反汇编按名全等[i1 §7.3「按名是唯一稳定跨链口径」]）③**可执行性门**（install B₁' 三态后 run_source ⇔ run_source_seed 值全等——B₁' 链实际作为自举实现运行）——**三门首跑全绿**。
- **parity 净 +3**（switch_corpus_parity_tests 44→47）：步④ fixpoint 门族 = **步⑤ 验证等价的机器判据基础已在位**（B₁'/B₂' fixpoint 硬门 + 跨链按名 + 可执行性三证）。
- **GATE 1 六命令 clean 起步全绿**：build --release **21.59s 零告警** / check 0/0 / fmt --check 0 diff / clippy --workspace --release -D warnings 0 errors / **test 1237:0:0**（RUST_MIN_STACK=33554432 沿袭）+ 审计×6 280 case EXIT 0 ×6 + CLI 七路径零回归（fib⇒144 + check ok：2 原型/9 常量/5 全局引用/38 指令 + effect_stress⇒120 + higher_order⇒(1 4 9 16 25) + closures⇒42 + macros⇒42 + test PASS 2/2）。
- **R4 顺修一处**：测试文件头部未用 import 清理（compile_source/compile_source_seed 全限定路径使用——lint 告警当轮清零）。
- **演进位置**：**切换窗步④ 落地**（目标语法自身编译——fixpoint 前置兑现）；**1237 基线自 r118 起**；14 行触发族判定零变化（切换窗续窗轮零 T3+ 消费信号）；下一演进 = **步⑤（验证等价——fixpoint 同构收口）为步④ 全落后的自然下一步**（门 B 设施复用 + SyntaxTransitionValidator 结构化 + 三阶段 fixpoint 传递性扩展[BS-C]）或 match 实施批 M-1 或 E5 收口清理批（.krf 原件删除）——按用户指令序或自然信号。
- 对账链：matrix r118 行 + 本节 + [rec 80（03 层）](docs/worklog/03_stage-3_入场序列/80_r118_切换窗步④实施轮.md) + t3plus v1.38 + switch-window-plan v1.7 + 根层 l r118 条目 + README 两处 + worklog 三链镜像。

## r117 —— 第二十九轮递归处理与脚手架拆除对账吸收轮（next21.md 两段全量吸收；原则 58；纯文档域零代码变更零语法增量）

**日期**：2026-10-30　**类型**：设计讨论吸收轮（1234 逐位维持——**1234 基线第二轮[r116-r117]**）　**驱动**：用户五链段式指令（①next21.md 吸收融入 stage0.md 直至收敛 → ②lang-design 收编 + 系统性全面审查直至全部收敛 → ③反哺 stage0.md 二次整理 → ④反哺 sop.md → ⑤完整打包 tar.gz + 同步完整更新 web page 与 t3plus-trigger-audit.md）——#15 讨论主线第十九次用户行权 + M1 指令开窗第二十二例（沿 r111/r113/r115 先例形态；切换窗步④ 断点无损顺延居推荐序首位）

- **187-a 吸收**：stage0.md v8.7→v8.8（8607→8709 行）——§9.30 S 表达式递归处理与脚手架拆除对账六小节[REC-A..REC-C 三裁定]：**同形树递归处理四层实况谱系**（Reader 递归下降 + MAX_NESTING_DEPTH=256 深度帽[FS-1 实测锚——2MiB 测试线程栈 ~600 层溢出 → >8× 裕量 + 结构化错误 fail-closed + 下游 expander/compile/eval 同形树递归同帽覆盖] / HM 推断迭代式零深递归 + 512 生成预算[A6 语义不变] / VM 迭代主循环堆分配帧栈[TD-023——Rust 栈深恒定 + 帧数帽 + 尾递归 O(1) 帧] / eval 树走器互递归由 Reader 帽前置覆盖）+ **理论统一归位叙事层**（递归 = 效应流分支/嵌套 / 深度 = 流形嵌套层级 / 溢出 = 流分析边界条件 = 解释框架层叙事[K-F 零机制变更]——「perform 不创建栈帧」三断言 = 效应处理器实现策略面非效应语义必然[OCaml 5 堆分配续延先例 E.30-165]）+ **漂移检测八项实况修正**（时态漂移——切换窗步③ 4/4 已落 E1-β 非未来规划 / 四方案对账——方案 1/3 已落地实证 / 方案选型差异 R4 代码为准 / IR 层级口径——VM 路径四层 + Stx = 宏展开必需承载非冗余 / 行数估算口径 / 管线相位分离省略修正 / 双 Reader → 三路形态精确化 / 验证等价性 → 三路门+fixpoint+豁免体系）+ **脚手架生命周期五段 ↔ 切换窗五步映射**（S-expr 拆除时点 = 步⑤ E5 收口[原则 41]；拆除边界 = 生产链 + 语料面 + 种子链保留 = 混合自举宪制裁定[BS-A]）+ **8 原语不变性第十三轮验证**（零新原语零通道零 VM 零语法——历次最轻量轮族并列）+ 原创贡献零新增（累计维持 25 项）+ 原则 58 + 附录 A 十二条 / E.30 四文献[E.30-164..167——r117-q1~q4 检索证 tool-results/r117-search/] / F.24。
- **187-b 收编 + 系统性审查**：lang-design 九件修订（17 v7.19[原则 58 镜像 + 附二十四对照] / 18 v7.23 §5y[术语十二条] / 19 v7.15 §30[E.30 四文献] / 04 v5.5 §3.1[递归处理实况注记——四层谱系表] / 07 v7.1 §3.2.2[脚手架生命周期映射与拆除边界] / 06 v6.12 §16[递归流形统一叙事注记] / 13 v6.24 §3.22[递归深度处理能力面] / 12 v6.30 §2.19[脚手架拆除时点对账注记] / 00 v6.24）+ 十六件零增量维持（02 号件零触碰 = **v9 定稿域零扰动实证——本轮零语法面与第十源语料轮的差异登记**：递归处理 = 防御机制非语法面故无 §8.13.2a 类增量登记位需求）+ ~25 维度交叉审计零遗留 + 锚点核验九处全存在 + 反向引用九件全通。
- **187-c/d 双反哺**：§9.30.6 双侧同步核验段（九件版本链零漂移 + EBNF 整合链对账[v9 定稿既有 + 本轮零语法增量确认]）+ sop v13.20→v13.21（原则 58 + §21.12 第 27 条「同形树递归处理纪律」+ §8.4.5 八锚查询行 + 计数五十七→五十八全域同步）。
- **187-e 交付闭环**：GATE 1 六命令全绿（build 零告警 / check 0/0 / fmt 0 diff / clippy --workspace --release -D warnings 0 / **test 1234:0:0 逐位维持**[RUST_MIN_STACK=33554432 沿袭——环境 OBS r115 登记沿袭]）+ 审计×6 280 case EXIT 0 ×6 + CLI 七路径零回归（fib⇒144 + check ok 2/9/5/38 + effect_stress⇒120 + higher_order⇒(1 4 9 16 25) + closures⇒42 + macros⇒42 + test PASS 2/2）+ r117 包三验 + web 五件 + E2E。
- **零代码变更证明**：git status 仅 11 docs 件 + 1 tool-results 未跟踪目录（r115 同构形态——纯文档吸收轮）。
- **演进位置**：递归处理线程统一登记（FS-1/A6/TD-023 既有交付 → 四层谱系原则化[原则 58]）+ 脚手架线程语法面实例化对账（原则 41——生命周期五段 ↔ 切换窗五步映射）+ 切换窗理论重述收编；**14 行触发族判定零变化**（纯文档吸收轮零消费信号）；下一演进 = **步④（目标语法自身编译——fixpoint 前置）为步③全落后的自然下一步**或 match 实施批 M-1 或步⑤ 验证等价——按用户指令序或自然信号。
- 对账链：matrix r117 行 + 本节 + [rec 79（03 层）](docs/worklog/03_stage-3_入场序列/79_r117_递归处理与脚手架拆除对账吸收轮.md) + t3plus v1.37 + 根层 l r117 条目 + README 两处 + download README r117 节 + worklog 三链镜像。

## r116 —— 切换窗步③ 第四批实施轮（expander.ktf C 类语料全量改写 + bootstrap Expander 状态自 .ktf 构建；步③ 全四件落；1234 基线起）

**日期**：2026-10-29　**类型**：切换窗续窗实施轮（净 +10——**1234 基线自 r116 起**）　**驱动**：用户三链指令（①继续推进目标语言设计实现窗[遇缺陷/未完成窗按推荐顺序直接推进——切换窗步③ 第四批 expander.ktf，r115 收口笔推荐序首位] ②按 docs/sop.md 流程结合 docs/lang-design/ 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）

- **186-a 步③ 第四批交付**（07 §3.2.1 步③「用新 Reader 重新解析编译器源码（已切换为目标语法版本）」——C 类语料分件渐进第 4 件 = 末件）：**expander.ktf 全量改写**（2234 行 S-expr 原件 → 3175 行目标语法生产件——**bootstrap Expander 状态自此自 .ktf 构建**）+ 基础设施三件：
  - **语料机制普查前置**（r115 收口笔预判「宏定义目标面映射设计先行」的实证回答）：define-syntax/syntax-rules 8 处命中全为字符串字面量/注释/函数名 syntax-rules-parse——**语料实现宏系统但零消费宏定义形**（零 quasiquote / 零 lambda 关键字 / 零 named-let / 零派生关键字调用）——计划 v1.5 预判的宏定义皮肤字典缺口**不成立**，零设计负担零新条目
  - **本批独有新机制 = 匿名闭包表达式 ×19**（compiler.krf/reader.krf 语料均零闭包）：`(fn (c) body)` ↔ `||(c: T) { body }`——D2 lambda→closure 既有支持（parse_closure_body 括号类型化参数表 + 块体——参数类型为皮肤面解析后剥离）；**闭包实参同构单元门 ×2** 钉住该纪律
  - **三项 oracle 规范化**（沿 r112 bang 剥离先例——双侧逐字镜像）：①registry-put! bang 剥离（1 名 4 处——目标面标识符字符集 [A-Za-z0-9_] 无 `!`）②关键字名输出标签七枚（'let/'fn/'if/'module/'require/'perform/'handle 10 处）→ string-to-symbol 铸 TAG 常量（LET-TAG..HANDLE-TAG——目标面保留字不可入表达式位；沿同文件 NIL-TAG/TRUE-TAG/FALSE-TAG 先例）③-1 负整数字面量（1 处）→ (- 1) 求反形（目标面无负整数字面量——`-` 恒 Minus 运算符）
  - **两处真实翻译缺陷检出并当场清偿**（用户指令「中途穿着缺陷…直接推进」行权——三路门 + gate B 双重机器验证网内清偿）：**is_scopes_subset 谓词反转**（(is-bool (member ...)) 误译为 is_pair(member ...)——member 命中返 Pair 未中返 false，两谓词互补反转→uni 快路径判定反转→嵌套宏产物 expansion_id 全漂移→**gate B fixpoint B₁/B₂ 字节不一致当场拦截**——is-uni-matches 链路依赖该谓词，翻译器谓词保真纪律锚定）+ **match_sequence/is_scopes_eq 两处 eq 误译为 ==**（(eq k 0)/(eq (length a) (length b)) 为值等谓词调用非数值运算符——三路字节码门 const 池对账定位：Sym(eq) vs Sym(=) 两操作数位）
  - **加载切换 + 活性探针**：expander.rs EXPANDER_SRC → expander.ktf + load_expander → compile_front_seed_target（r110 reader/r114 compiler 模式——种子目标 Reader 读段 / 展开 / 编译维持种子硬 P1 约定）+ EXPANDER_KTF_LOADS 活性探针 + lib.rs 导出 expander_bootstrap_is_target_corpus
- **parity 门 10 case**（switch_corpus_parity_tests 扩展——净 +10 = **1234:0:0**）：三路字节码全等核心门（expander.krf 规范化基线 ↔ .ktf 种子目标 Reader ↔ .ktf 生产桥——全载荷含 19 闭包实参 + TAG 常量全局加载 + quote(()) nil 字面量位 + mod 函数调用形）+ 生产活性（lexp-expand-program 入口经 .ktf 状态解析 + define-syntax 展开产物）+ 行为 parity（宏密集源生产 ↔ 种子端到端 VM 值全等——define-syntax/ellipsis/卫生 α 更名全载荷）+ **跨面生成 parity 回归门**（.ktf 装载态 ↔ .krf 种子态——含 expansion_id；E1-β 登记豁免[宏产物 expansion_id 不入 parity 判据]不覆盖此对：双侧同为 corpus 逻辑，任何生成漂移 = 翻译缺陷——is_scopes_subset 反转的回归锚）+ 宏深路径（macros.krf ⇒42——syntax-rules 解析/子句匹配/省略号拼接/引入标识符 α 更名/卫生基名回退全在 expander.ktf 字节码内执行）+ 派生糖深路径（when/unless/and/or/let*/cond/while 全族 ⇒45——DERIVED_SOURCES 注入 + 惰性糖注册 + 'derived 变换器步 + 验证器负例契约）+ 闭包实参同构单元门 ×2（(fn (c) body) ↔ ||(c: T) { body } 字节码全等——含嵌套调用体形）+ 关键字 TAG 规范化锚（负例：quote(let) 解析错误[KwLet 保留字不可入表达式位——缺口证据] + 正例：规范化 TAG 形双侧字节码全等）+ 种子↔自举全管线 oracle（compile_source[bootstrap expander.ktf + compiler.ktf] ↔ compile_source_seed[Rust] 字节码全等——E1-β + I1 纪律链式端到端）
- **GATE 1 六命令 clean 起步全绿**：build --release **19.33s 零告警** / check 0 errors 0 warnings / fmt --check 0 diff / clippy --workspace --release -D warnings 0 errors / **test --release --workspace 1234:0:0**（24 target；RUST_MIN_STACK=33554432 沿袭）+ 审计×6 280 case 真实 EXIT 0 ×6（m3「窗 M 出口条件达成」/ e5close「E5 出口三条件全绿——S4 收口 GO」结论行复核）+ CLI 七路径零回归（fib ⇒144 + check ok：2 原型/9 常量/5 全局引用/38 指令 + effect_stress ⇒120 + higher_order ⇒(1 4 9 16 25) + closures ⇒42 + **macros ⇒42[宏语料经生产 expander.ktf——新增强化路径]** + test PASS 2/2）+ 例行监测六族 grep 全零 + OBS-C fib ~106ms 带内（<65ms 触发线不满足维持）
- **对账八件**：matrix r116 增量行 + RELEASE r116 节 + t3plus v1.36 + switch-window-plan v1.6 + rec 78（03 层第 78 件）+ 根层 l r116 条目 + kerf README 两处 + download README（r116 节 + r115 退役注记）+ worklog 三链镜像（186-a..d 全录）
- **演进位置**：切换窗步③ **4/4 件全落——步③完成**（preamble ✅ r109 + reader ✅ r110 + compiler ✅ r114 + expander ✅ r116）；C 类语料按原件行计 4073/3550[115%——expander.ktf 3175 行因注释全量携带与 if 链展开]；**bootstrap Reader + Expander + Compiler 三状态均自 .ktf 构建**（自举链语料目标语法化第 4 件——E1-β 生产路径全量自 .ktf 语料运行实证）；**1234 基线自 r116 起**；14 行触发族判定零变化（切换窗续窗轮零 T3+ 消费信号——match 语言面消费信号维持零命中）；下一演进 = **步④（目标语法自身编译——fixpoint 前置）为步③全落后的自然下一步**或 match 实施批 M-1（Reader 臂）或步⑤ 验证等价（fixpoint 同构）——按用户指令序或自然信号

## r115 —— 第二十八轮统一流分析与描述论吸收轮（借用检查投影化工程统一面·描述论立场层·哥德尔同构；1224 逐位维持）

**日期**：2026-10-28　**类型**：设计讨论吸收轮（零测试函数增量——**1224 基线第二轮[r114-r115]**）　**驱动**：用户双链六段式指令（next20.md 吸收 + lang-design 系统性审查 + 双反哺 + 对账打包 web + t3plus；并行链——next.md-next20.md EBNF 整合[r104 v9 定稿既有 + 第十源语料增量登记]）——#15 讨论主线第十八次用户行权 + M1 指令开窗第二十例

- **185-a 吸收（stage0.md v8.6→v8.7——8305→8605 行净 +300）**：§9.29 统一流分析与描述论本体论八小节[UFA-A..UFA-F 六裁定]——统一流分析 = 借用检查投影化工程统一面{Lifetime(T)=π_time(EffectFlow(T)) 观测投影家族第三实例 + UnifiedFlowAnalysisPass 四相位 + 三干涉型 + 四超越优势分级[语料「Rust 不支持部分借用」修正——Rust 实支持字段级 disjoint borrow]} + EBNF 第十源语料 Level 1-4 登记态{统一流分析语法族七件 + ~32 关键字候选全脱糖 + 记法修正五处 + 操作语义六规则族 + 重写面 vs 标注面分治} + 描述论立场层{五描述修正表 + 机制层豁免表述纪律 + OSR 哲学锚 E.29-163} + 哥德尔不完备同构{第一定理↔间隙性 + 第二定理↔自举信任根[BS-E 三机制理论背书] + 三重不完备统一叙事层} + **8 原语不变性第十二轮验证**{零新原语零通道零 VM——历次第二轻量轮族} + 原创贡献 #23/#24/#25{累计 25 项} + 环数维持 12{本体层流本体论 + 立场层描述论双基座} + 漂移检测十项实况修正 + 原则 57 + 附录 A 二十二条/E.29 四文献[Polonius E.29-160 + Koka Perceus E.29-161 + 哥德尔-图灵-Rice 家族 E.29-162 + OSR E.29-163——r115-q1~q4 检索存档 tool-results/r115-search/]/F.23
- **185-b 收编 + 系统性审查**：lang-design **十件修订**（17 v7.18[原则 57 + 附二十三 + R4 顺修一处{头部导语「四十六条」9 轮陈旧残留}] / 18 v7.22 §5x 术语二十二条 / 19 v7.14 §29 E.29 四文献 / 02 v7.10 §8.13.2a 第十源语料登记 / 06 v6.11 §15 / 13 v6.23 §3.21 / 05 v6.13 §15 / 12 v6.29 §2.18 / 24 v2.12 §24 / 00 v6.23）；十五件零增量维持（02 §8.13 v9 定稿位维持不动 = **定稿域零扰动实证**）；~25 维度交叉审计全收敛 0 未处理问题遗留
- **185-c/d 双反哺**：§9.29.8 双侧同步核验段（十件版本链零漂移 + 回流零项）+ sop v13.19→v13.20（原则 57 入 §2.2 表 + §21.12 第 26 条 + §8.4.5 九锚查询行 + 计数五十六→五十七全域同步 + 变更日志）
- **185-e 交付闭环**：GATE 1 六命令全绿（build 7.91s 零告警/check 0/fmt 0/clippy -D warnings 0/**test 1224:0:0 逐位维持**[RUST_MIN_STACK=32MB——环境 OBS 注记：默认 8MB 栈深下 deep_nesting_within_budget_clean 溢出非代码缺陷零代码变更+大栈全绿双证]）+ 审计×6 EXIT 0 + CLI 五路径零回归（fib⇒144 + check ok 2/9/5/38 + effect_stress⇒120 + higher_order⇒(1 4 9 16 25) + closures⇒42）+ r115 包三验 + web 五件 + E2E
- **对账八件**：matrix r115 增量行 + RELEASE r115 节 + t3plus v1.35（r115 消费注记——14 行触发族判定零变化）+ rec 77（03 层第 77 件）+ 根层 l r115 条目 + README 两处 + download README（r115 节 + r114 退役注记）+ worklog 三链镜像（185-a..185-e 全录）
- **演进位置**：分析线程工程统一面开面（r95 MU-A → 借用检查投影实例化）+ 观测投影家族三实例完备（π_shape/π_state/π_time）+ 哲学层立场声明；**1224 基线第二轮[r114-r115]**；14 行触发族判定零变化（纯文档吸收轮零消费信号——T3+ 触发面零行权维持）；下一演进 = 切换窗步③ 第四批 expander.ktf（宏定义目标面映射设计先行）或 match 实施批 M-1 或步④ fixpoint 前置——按用户指令序或自然信号

## r114 —— 切换窗步③ 第三批实施轮（compiler.ktf C 类语料全量改写 + bootstrap Compiler 状态自 .ktf 构建；1224 基线起）

**日期**：2026-10-27　**类型**：切换窗续窗实施轮（净 +10——**1224 基线自 r114 起**）　**驱动**：用户三链指令（①r113 tarball 单源恢复[z.ai web 保存机制回退——r103 恢复轮同构] ②继续推进目标语言设计实现窗[切换窗步③ 第三批 compiler.ktf——r112 序列化断点 182-h 无损顺接推荐序首位] ③按推荐先后任务顺序继续推进 + 完整打包 tar.gz + 同步完整更新 web page）

- **r113 tarball 单源恢复**：upload/kerf-v1.0.0-r113-flowtheory-1214tests.tar.gz（578 文件）替换 kerf/ 内容 + .git 保留[r102 备份——r103 恢复轮同构处置] + Rust 1.98.1 工具链重装[scripts/rust/setup.sh §3.1 口径]；恢复态与 worklog 183-a..e 终态一致
- **184-a/b 步③ 第三批交付**（07 §3.2.1 步③「用新 Reader 重新解析编译器源码（已切换为目标语法版本）」——C 类语料[替换面图 §3.1：reader 472 + expander 2065 + compiler 1301 + preamble 66]分件渐进第 3 件）：**compiler.ktf 全量改写**（1301 行 S-expr 原件 → 1404 行目标语法生产件——**bootstrap Compiler 状态自此自 .ktf 构建**）+ 基础设施三件：
  - **语料机制普查前置兑现**（182-h 结论实证）：零新语法零新皮肤字典条目——多绑定 let / n 元 and-or 右嵌套 / 表达式位 if / quote 调用形 / define 调用形均已就位（r109-r110 批次成果复用）；r112 oracle 规范化两处（bang 后缀变更名族 9 名剥离 + n 元 minus 1 处二元化）逐字镜像
  - **语句序列化翻译范式**（本批新增纪律）：flat `(do A B ... Z)` ↔ `A; B; ... Z`（末项无分号 = 块尾值）——D42 同构[平坦 do 与块穿线嵌套 do 脱糖恒等]；**D42 语句同构单元门含负例锚**（全语句形恰好多 Pop + PushNil 两条指令——反向锚钉住尾值纪律）
  - **多绑定 let 单语句承载纪律**（D61 暂存法链——r110 裁定 2 重申）：三处拆分回归（eref-node / fvo-node / compile-expr 的 tag+fields 多绑定 let 被写成顺序 let）被三路字节码全等门当场检出**当场清偿**——多绑定 let 必须单语句 `let a = e1, b = e2;` 承载（顺序 let 的指令序与 D61 暂存法链结构不同）
  - **加载切换 + 活性探针**：compiler.rs COMPILER_SRC → compiler.ktf + load_compiler → compile_front_seed_target（r110 reader 模式——种子目标 Reader 读段 / 展开 / 编译维持种子硬 P1 约定）+ COMPILER_KTF_LOADS 活性探针 + lib.rs 导出 compiler_bootstrap_is_target_corpus
- **parity 门 10 case**（switch_corpus_parity_tests 扩展——净 +10 = **1224:0:0**）：三路字节码全等核心门（compiler.krf 基线 ↔ .ktf 种子目标 Reader ↔ .ktf 生产桥）+ 生产活性（lexc_compile_program 入口经 .ktf 状态解析）+ 行为 parity（生产 ↔ 种子端到端 VM 值全等）+ 双展开器 parity（.ktf 语料经种子展开器 ↔ 自举展开器）+ CLI 语料回归（fib ⇒144）+ 效应深路径（effect_stress ⇒120——compile-handle 三原型编排 / ensure-trampoline 惰性单例 / compile-inner-proto 全部在 compiler.ktf 字节码内执行）+ 高阶深路径（higher_order ⇒(1 4 9 16 25)——闭包转换/fvo 自由变量分析/捕获槽位/原型窗口切换）+ 闭包深路径（closures ⇒42——多级捕获链/rv-loop 帧栈走查）+ D42 语句同构单元门（含负例锚）+ 种子↔自举编译器 oracle（compile_source ↔ compile_source_seed 字节码全等）
- **GATE 1 六命令 clean 起步全绿**：build --release **17.70s 零告警** / check 0 errors 0 warnings / fmt --check 0 diff / clippy --workspace --release -D warnings 0 errors / **test --release --workspace 1224:0:0**（24 target；RUST_MIN_STACK=16777216 沿袭）+ 审计×6 280 case 真实 EXIT 0 ×6（m3「窗 M 出口条件达成」/ e5close「E5 出口三条件全绿——S4 收口 GO」结论行复核）+ CLI 六路径零回归（fib ⇒144 + check ok：2 原型/9 常量/5 全局引用/38 指令 + effect_stress ⇒120 + higher_order ⇒(1 4 9 16 25) + closures ⇒42 + test PASS 2/2）+ OBS-C 71.036ms 带内（<65ms 触发线不满足维持）
- **对账八件**：matrix r114 增量行 + RELEASE r114 节 + t3plus v1.34 + switch-window-plan v1.5 + rec 76（03 层第 76 件）+ 根层 l r114 条目 + kerf README 两处 + download README（r114 节 + r113 退役注记）+ worklog 三链镜像（184-a..d 全录）
- **演进位置**：切换窗步③ **3/4 件**（preamble ✅ r109 + reader ✅ r110 + compiler ✅ r114；expander.ktf 待——宏定义目标面另需映射设计）；C 类语料按原件行计 1839/3550[52%]；**bootstrap Reader + Compiler 状态均自 .ktf 构建**（自举链语料目标语法化第 3 件）；**1224 基线自 r114 起**；14 行触发族判定零变化（切换窗续窗轮零 T3+ 消费信号——match 语言面消费信号维持零命中）；下一演进 = 步③ 第四批 expander.ktf（宏定义目标面映射设计先行）或 match 实施批 M-1（Reader 臂）或步④ fixpoint 前置——按用户指令序或自然信号

## r113 —— 第二十七轮流特性理论吸收轮（流特性理论与流本体论·理论载体第十二环；1214 逐位维持）

**日期**：2026-10-27　**类型**：设计讨论吸收轮（零测试函数增量——**1214 基线第四轮[r110-r113]**）　**驱动**：用户五链指令（next19.md 吸收 + lang-design 系统性审查 + 双反哺 + 对账打包 web + t3plus）

- **183-a 吸收（stage0.md v8.5→v8.6——8082→8305 行净 +223）**：§9.28 流特性理论与流本体论九小节（FLW-A..FLW-G 七裁定）：**流本体论第十二环**（效应流 = 六线程族全部谓词的共同主语/本体对象——五层特性[波动性/粒子性/中间态/间隙性/时间性] = 完备观测谱；六线程族维持不推翻 + 本体层开面；「九支柱」降格叙事层口径；四视角全景登记态{本体/机制/分析/观测}）+ **三核心洞察形式化**（固定 vs 确定 = Fix/Det 投影算子观测维度阶精确化{Handle = 固定操作非确定操作——resume∈{0,1} 合围兼容 + 退相干式表述增益} / N 维可能性 = 正交分解原则理论层重述{8 原语轴 = 维度分解基} / 随机种子 = 自由度 = CAP-C 对偶面完备化{第三不确定性形态——计数恒等式实质 + 叙事不等式}）+ 五层↔8 原语映射（19 行映射表 + 原语/语义/观测三层标注）+ **8 原语不变性第十一轮验证**（零新原语零通道零 VM 零语法——历次最轻量轮族）+ 弦理论八行逐行裁定（**T 对偶驳回**——尺度对偶非观测机制，替换为退相干/投影测量 E.28-155 锚 / 全息原理 = Tier 2 信息论骨架共享 E.28-158 锚 / 弦理论不采纳为第八数学基础层）+ 时间性四命题 = 操作语义物理层重述（小步语义每步坍缩 + Const 快照 + eager 求值持续观测 + Randomness 种子演进——K-F 零机制变更）+ 原创贡献 #20/#21/#22 三项新登记（累计 22 项）+ 漂移检测八项实况修正 + 原则 56 + 附录 A 二十条 + E.28 四文献（r113-q1~q4 检索证）+ F.22 对照
- **183-b 收编 + 系统性审查**：lang-design **十件修订**（17 v7.17[原则 56 镜像 + 附二十二] / 18 v7.21 §5w[术语二十条] / 19 v7.13 §28[E.28 四文献] / 06 v6.10 §14[时间性与坍缩语义注记] / 13 v6.22 §3.20[自由度-约束对偶能力面] / 21 v2.3 §11.5[随机种子=自由度对偶注记] / 24 v2.11 §23[流本体论空间注记——零新子空间] / 05 v6.12 §14[种子演进运行时面] / 12 v6.28 §2.17[Stage 3+ 门控注记] / 00 v6.22[修订注记]）+ 十五件零增量维持（02 v7.9 维持 = v9 定稿域零扰动实证）+ ~25 维度交叉审计全收敛（0 未处理问题遗留）
- **183-c 反哺 stage0 + 二次整理**：§9.28.9 双侧同步核验段（十件版本链逐件对账零漂移 + 锚点核验十处 + 反向引用九件全通 + 审查回流零项 + 四链闭合复检）
- **183-d 反哺 sop.md**：v13.18→v13.19（原则 56「流特性理论登记纪律」入 §2.2 表 + §21.12 第 25 条 + §8.4.5 九锚查询行 + 目录/标题/来源注五十五→五十六计数全域同步 + 变更日志行）
- **183-e 交付闭环**：§3.2 六命令 clean 起步全绿（build --release **18.18s 零告警** / check 0/0 / fmt 0 diff / clippy --workspace --release -D warnings 0 errors / **test --release --workspace 1214:0:0 逐位维持**[24 target = 单元 298 + 集成 916；RUST_MIN_STACK=16777216 沿袭]）+ 审计×6 280 case 真实 EXIT 0 ×6（stage0/stage1/stage2_r1/stage2_r2/m3「窗 M 出口条件达成」/e5close「E5 出口三条件全绿——S4 收口 GO」）+ CLI 六路径逐字一致（fib ⇒144 + check ok：2 原型/9 常量/5 全局引用/38 指令 + effect_stress ⇒120 + higher_order ⇒(1 4 9 16 25) + closures ⇒42 + test PASS 2/2）+ r113 包三验（独立解包净构建零告警 + 1214:0:0 复跑 + e5close EXIT 0）+ web 五件 E2E + 对账八件
- **演进位置**：理论载体线程（r84-r111 十一环）的**第十二环开面**（流本体论——本体层基座叙事）；观测理论三阶化（r96 类型观测 → r111 信息观测双子 → 本轮固定vs确定维度阶）；不确定性三形态全景（r89 非对易 → r91 波粒二象性 → 本轮自由度-约束对偶）；语法线程零增量轮（v9 定稿域免疫——连登记态语法族亦无）；compiler.ktf 本体断点（r112 序列化）无损顺延——下一演进 = compiler.ktf 本体或 match 实施批 M-1 按用户指令序或自然信号

## r112 —— 注释语言标准轮（代码域全量注释英文化 + SOP §10.5 立法；1214 逐位维持）

**日期**：2026-10-26　**类型**：注释标准化重构轮（零测试函数增量——**1214 基线第三轮[r110-r112]**）　**驱动**：用户四链指令（①审查项目内所有注释中文转标准化英文 + 注释语言选择原则入 sop.md ②继续推进目标语言设计实现窗[切换窗步③ 第三批 compiler.ktf——前置件交付 + 本体序列化 r113] ③按推荐先后任务顺序继续推进 ④完整打包 tar.gz + web page 同步更新）

- **182-a 立法**：sop.md v13.17→v13.18——**§10.5 注释语言标准**（语言选择原则：代码注释一律标准化英文——Rust `//`/`///`/`//!` + kerf 语料 `;`/`//` + TOML/Shell `#`；中文双豁免位 = 设计文档[文档非注释] + 字符串字面量[非注释且受 parity 字节级守护]；技术锚保留义务[§X.Y/TD-xxx/rNNN/裁定号/诊断码/标识符原样保留]；形态标准[`//!` 职责+入口 / `///` why 优先 / 禁 fenced code block]；存量治理[r112 首轮全量清偿 + 零语义变更纪律]；新增违反后果[P2]）+ §10.2 清单末项 + 变更日志 v13.18 行
- **182-b..f 转换五波 23 批**（子 Agent 并行——波间 cargo check 三波全绿）：**代码域中文注释全量清零 ~12.7K 行**（139 个 .rs 文件 ~11.2K[crates 核心 3444 + bootstrap 桥/reserved/expander/compiler 余 2612 + reader/syntax/runtime/space/span/backend 余 + tests 2561 + stage2/3 tests + audit 3418] + 13 bootstrap 语料件 ~1.6K[expander.krf 421/compiler.krf 250/target_reader.krf 269/check.krf/reader.krf/reader.ktf/preamble 双件/cache/test_runner/test/build/cli] + 8 示例语料 + 根 Cargo.toml + 3 setup 脚本 + 1 存档脚本）；**零语义变更三重自证**（只动注释行——代码前缀逐字节保持 / 字符串字面量零触碰——错误消息与 CLI 输出 parity 守护面 / 注释剥离比较器——HEAD vs 工作树代码 token 流全等）；残留中文 4,085 行全为字符串字面量（§10.5 双豁免位——rg 逐行分类实证）；超时四批（b1/d5/e1/e5）后台完成实证 + worklog 合并承载诚实登记；clippy doc_lazy_continuation 31 处顺修（译文行首 `+` markdown 列表伪命中——移行尾）+ fmt 归零
- **182-g GATE 1**：§3.2 六命令 clean 起步全绿（build --release **17.97s 零告警** / check 0/0 / fmt 0 diff / clippy --all-targets -D warnings 0 / **test --release --workspace 1214:0:0 逐位维持**——24 target 单元 298 + 集成 916）+ 审计×6 280 case EXIT 0 ×6 + CLI 六路径逐字一致（fib 75025/⇒144 + check ok：2 原型/9 常量/5 全局引用/38 指令 + higher_order ⇒(1 4 9 16 25) + closures ⇒42 + effect_stress ⇒120 + test PASS 2/2）+ 实施笔① 60c1a6b（164 文件 +18389/-12727）
- **182-h 实现窗前置件 + 序列化**：切换窗续窗行权（M1 指令开窗第十八例——r109/r110 同指令形态延续）；**compiler.krf oracle 规范化前置件**（141 行语义保持双改——①bang 后缀变更名族 9 名剥离[emit!/proto-set-at!/cc-locals-push! 等——目标面标识符字符集 [A-Za-z0-9_] 无 `!`，r109 命名映射仅覆盖 `-`↔`_`；r102 现代命名窗同方向] ②n 元 minus 扁平调用 1 处 → 左结合二元嵌套[代数恒等]；**1214:0:0 复跑语义保持实证**）+ R4 顺修一处（规范化注释 `->` 触发命名守卫→「arrow sigil」）；**compiler.ktf 本体移交 r113**（子 Agent 完成规范化后停滞——断点序列化 worklog 182-h：停止原因[子 Agent 停滞 + 主线程上下文预算]/继续条件[r103 恢复轮同构断点续接]/推荐任务顺序[本体重写→加载切换→parity 门→治理链四件]/演进位置[C 类语料维持 532/3550]）
- **182-i 交付闭环**：对账八件（matrix r112 行 + RELEASE r112 节 + t3plus v1.32 + rec 74 + 根层 l + README 两处 + download README + worklog 三链）+ r112 包三验（git archive 单源 + 独立解包净构建 + 1214 复跑 + e5close EXIT 0 + fib⇒75025/144）+ web 五件 + E2E
- **演进位置**：注释规范面（代码工程界面统一——跨语言协作成本三面[检索/审阅/新人上手]清偿）；切换窗步③ 第三批 = 前置件 ✅ + 本体待（r113 断点续接居推荐序首位）；**14 行触发族判定零变化**（注释轮 + 前置件轮零消费信号——T3+ 触发面零行权维持）

## r111 —— 第二十六轮信息效应化吸收轮（信息效应化与统一观测框架·理论六线程族终态；1214 逐位维持）

**日期**：2026-10-25　**类型**：设计讨论吸收轮（零测试函数增量——**1214 基线第二轮[r110-r111]**）　**驱动**：用户五段式指令（①next18.md 吸收 + ②lang-design 收编与系统性审查 + ③反哺 stage0 + ④反哺 sop + ⑤完整打包 tar.gz + web page + t3plus 同步更新）——**#15 讨论主线第十六次用户行权**（设计讨论吸收轮——纯文档域零代码变更；M1 指令开窗第十三例——沿 r102/r104 先例形态）

- **181-a 吸收（stage0.md v8.4→v8.5——7887→8080 行净 +193）**：§9.27 信息效应化与统一观测框架九小节（INFO-A..INFO-G 七裁定）——信息 = 效应流的状态投影（**第八支柱 + 观测双子闭合**：类型形状观测 + 信息状态观测互补）+ 统一五机制/分治五策略登记态（**原则 42 信息面推广零修订原文**——统一而分治从 Error 推广到五类信息 + 渐进观测分级 = 原则 43 观测面投影——LSP 四级协议同构）+ 信息效应语法族**第九源语料 Level 1-4 登记**（三分域归位 + ~20 关键字候选全脱糖——**Level 0 定稿域零扰动**[原则 54] + 二义性预防新增例 23-25）+ **InfoEffectSpace 归位**（EffectSpace Level 2 登记态子空间第七例 + 空间单源第九轮 + 「信息」双层口径——语言级效应/编译器诊断分立）+ 编译器信息流管线架构叙事层登记（**F13 正交裁定维持**——编译期诊断恒值通道 + ErrorPolicy 三策略既有形态命名完备化）+ 一致性八项验证全过 + **8 原语不变性第十轮验证**（零新增原语零通道增量）+ **理论载体第十一环**（六线程族：效应七环 + 能力 + 生命周期 + 分析 + 类型 + 信息）+ 原创贡献 18/19 两项新登记 + LSP/IDE 投影工具链层单向派生（severity 四级同构）+ 漂移检测六项实况修正（最重 = 编译期诊断归属冲突——F13 维持「大 Handle 包裹」降格叙事层）；**原则 54 R4 顺修**（r104 漏更 §23.1 补齐——计数五十三→五十五）+ 原则 55 + 附录 A 二十条 + E.27 四文献（149 rustc diagnostic structs / 150 LSP 3.18 Diagnostics / 151 错误恢复策略谱系 / 152 效应处理器前沿共识——r111-q1~q4 检索证存档 tool-results/r111-search/）+ F.21 第二十六轮对照
- **181-b 收编 + 系统性审查**：lang-design **十四件修订**（02 v7.9 §8.14 信息效应语法族登记 + 17 v7.16 原则 55 + 18 v7.20 §5v + 19 v7.12 §27 + 24 v2.10 §22 InfoEffectSpace 归位 + 05 v6.11 + 06 v6.9 + 13 v6.21 + 15 v6.5 + 12 v6.27 + 20 v1.17 + 21 v2.2 + 23 v1.9 + 00 v6.21——net +250 行）+ **~25 维度审查矩阵全收敛**（next18.md 全问题对账——0 未处理问题遗留）+ 零断链实证（新增节锚点 14 处全存在 + lang-design 12 件反向引用 §9.27 全通 + F13 违例表述残留零）+ 17 §1.1 计数 R4 顺修（r89 起四十六→四十七漂移）
- **181-c 反哺 stage0 + 二次整理**：§9.27.9 双侧同步核验段（十四件版本链逐件对账零漂移 + 回流两项处置[21 §11.3→§11.4 节号修正 + 17 §1.1 计数漂移顺修]）+ 四链闭合复检（理论链 42→55 推广零修订 / 语法链 v9 定稿→第九源登记 / 空间链六→七例 / 线程链十环→十一环）
- **181-d 反哺 sop.md**：v13.16→v13.17（原则 55 + §21.12 第 24 条 + §8.4.5 十三锚查询行 + 计数五十四→五十五全域同步 + 变更日志行）——零载荷纪律维持
- **181-e 交付闭环**：§3.2 六命令全绿（clean 起步 build 19.21s 零告警 / check 0 / fmt 0 diff / clippy -D warnings 零告警）+ **test 1214:0:0 逐位维持**（纯文档轮零代码变更——24 target 单元 298 + 集成 916）+ 审计×6 280 case EXIT 0 + CLI 三路径零回归（fib 75025/⇒144 + check ok：2 原型/9 常量/5 全局引用/38 指令 + effect⇒120）+ r111 包三验 + web 五件 + E2E + t3plus v1.31
- **演进位置**：错误处理线程（原则 42 r81 开面）的**信息面推广收束** + 信息系统线程（r88 三层架构）的用户侧语法 + 观测理论延伸 + 理论载体**第十一环·六线程族终态**（三视角三口号：机制一切皆效应 / 分析一切皆投影 / 观测一切皆信息）+ 语法线程第九源语料登记（v9 定稿域免疫）+ 空间线程第七登记态子空间；**14 行触发族判定零变化**（纯文档吸收轮零消费信号——T3+ 触发面零行权维持；切换窗续窗节奏维持续待步③ 第三批 compiler.ktf 或 match 实施批 M-1——按用户指令序或自然信号）

## r110 —— 切换窗步③ 第二批实施轮（reader.ktf C 类语料全量改写 + 双语法扩展 + P1 潜伏缺陷清偿——1214 基线起）

**日期**：2026-10-24　**类型**：切换窗续窗实施轮（净 +10——**1214 基线自 r110 起**）　**驱动**：用户指令「继续推进 目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施 + 按 docs/sop.md 流程结合 docs/lang-design/ 与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 + 同步完整打包项目 tar.gz 并同步完整更新 web page」——**切换窗续窗行权 = M1 指令开窗第十七例**（r109 同指令形态延续——switch-window-plan v1.3 §5 + r109 收口笔双源明文「下一演进 = 步③ 第二批 reader.ktf」居推荐序首位）

- **切换窗步③ 第二批交付**（07 §3.2.1 步③「用新 Reader 重新解析编译器源码（已切换为目标语法版本）」——C 类语料[替换面图 §3.1：reader 472 + expander 2065 + compiler 1147 + preamble 66]分件渐进第 2 件）：**reader.ktf 全量改写**（472 行 S-expr 原件 → ~560 行目标语法生产件——自举 Reader 本体语料；**bootstrap Reader 状态自此自 .ktf 构建**）+ 基础设施三件：
  - **14 条映射总表全载荷**（180-a 裁定 1）：fn 函数形 + T 占位（45 函数）/ cond×13 → if-else 链（九糖右递归展开同形）/ let 单绑定×7 语句化 / **多绑定×6 → `let a = e1, b = e2;`**（新语法）/ **and 3 元×2 + 4 元×1 + or 3 元×1 → 显式右嵌套**（derived.rs 右递归同构——左结合 `a && b && c` 产出 `(and (and a b) c)` ≠ S-expr 面禁用）/ 符号字面量 ~45 处 → **`quote(sym)` 调用形** / 顶层值定义×4 → **`define(NAME, e);` 调用形** / 命名 `-`↔`_` 全量 / `=`→`==` / nil→()×~20 / 顶层 import 兑现（r109 预铺顶层臂）
  - **多绑定 let_stmt 语法扩展**（180-a 裁定 2——Level 0 产消面缺口：语料消费 6 处 vs let_stmt 单绑定；**顺序 let 破坏字节码 parity 实证**：D61 暂存法链[core_forms.rs——多绑定展开 Let[t,e,Let[t,...Let[x,Var(t)...]]] vs 顺序 Let[x,e,Let[y,e,...]] 结构不同 → 指令序不同]；双侧实施：target.rs parse_let_stmt binder 循环[元组收集——单绑定行为/形态/Span 逐字节保持；多绑定绑定组 Span = 首名起..末值止] + target_reader.krf parse-let-binder/let-binder-rest 镜像[fifth 辅助新增；尾位 TCO]；02 §8.13.1a 产生式增补[原则 44]）
  - **表达式位 if 语法扩展**（180-a 裁定 2b——primary 位 if 前置检查：语句位 parse_stmt_or_expr 先行分派不受影响；Rust `let x = if c { a } else { b }` 同位形；list-items 唯一表达式位 if `cons(if (open_k == 13) { quote(vec) } else { quote(list) }, ...)` 直映通道；双侧实施 + 02 §8.13.1a 增补）
  - **加载切换 + 活性探针**（180-a 裁定 4：driver.rs **compile_front_seed_target** 新入口[read_target_source 种子目标 Reader 读 + 种子展开/编译——r109 裁定 2 r6 对称沿袭 + compiler.ktf/expander.ktf 后续批次共享] + mod.rs READER_SRC → include_str!("reader.ktf") + READER_FILENAME → "reader.ktf" + load_bootstrap 切换 + READER_KTF_LOADS 活性探针 + reader_bootstrap_is_target_corpus pub re-export；**原件 reader.krf 保留**[gate B fixpoint 测试 include_str + KRF_SOURCES 命名守卫 10 .krf 域继续消费零改动——删除 = 步⑤收口清理批]）
- **P1 级潜伏缺陷检出并当场清偿（双侧六处同修）**：目标面**缺省 else / 空块尾 / perform 0 元 payload** 三处产出 nil **符号**（→ else 臂执行时「未绑定的全局变量」错误——探针实测 VM ERR）vs S-expr 面 nil 源文本 = NilLiteral / 2 参 if 展开器补 Literal(Nil)——**r106 期先天缺陷**（历轮测试零缺省 else 执行路径故未暴露）；清偿 = Rust parse_if else-less + parse_block 空尾 + perform 0 元 payload → `Stx::literal(Nil)`；.krf 镜像 block-thread rest0 + parse-if else-less + payload-chain 0 元 → `nd-nil`；清偿后探针 f(false) ⇒ Nil（语义对齐实证）
- **R1 口径修正（诚实登记）**：r109 裁定 5「quote×2」计数 = `(quote ` grep 命中 2 处均在注释行——实际载荷 ~45 符号字面量 + 4 值定义 + 6 多绑定 let + 4 n 元 and/or（第二批范围显著大于 r109 计数——180-a 语料机制普查承载清偿）
- **parity 门 = 10 case 增量**（switch_corpus_parity_tests——**三路字节码全等核心门**：reader.krf S-expr 基线 ↔ reader.ktf 种子目标 Reader ↔ reader.ktf .krf 桥生产路径[同一表符号域归一——多绑定暂存法链/cond→if 链/and-or 右嵌套/quote 调用形/值定义调用形全载荷] + 皮肤映射形态域四锚[render_stx_shape span 剥离助手——多绑定 let 双/三绑定 + quote 调用形 + define 调用形 + 表达式位 if] + 多绑定 let 双侧 Stx span 级 parity[类型注解/mut 面] + 错误路径三负例[缺绑定名/缺 =/缺 ;] + **nil 语义缺陷清偿回归锚**[缺省 else/空块形态映射 + f(false) ⇒ Nil 行为锚] + 活性探针 + 行为锚[reader 特性密集源——行注释/嵌套块注释/quote 简写/字符串/嵌套列表 ⇒ (tag sym ab 42)] + 双展开器 parity[E1-β 延伸——多绑定暂存法链双展开器同构] + fib.krf CLI 回归锚[⇒ 144]）；测试修正实录三则（strip_toplevel_imports_for_compile 镜像助手[driver 1.68 步——测试助手旁路 front_from_forms] + fib 锚 75025→144[程序值口径] + mut 借用）
- **治理链**：switch-window-plan v1.4（步③ 第二批 ✅ + 后续批次序[compiler.ktf 第三批 → expander.ktf 末批]）+ t3plus v1.30 + 02-syntax-model v7.8（§8.13.1a 增补二产生式：多绑定 let_stmt + 表达式位 if）+ 20-surface-conventions v1.16（§14 皮肤字典新三条：多绑定 let 双面映射 / 符号字面量调用形 / 顶层值定义调用形）+ stage0 §9.26.9 皮肤字典锚同步
- **验收**：§3.2 六命令全绿 + **test 1214:0:0**（净 +10 = 单元 298 维持 + 集成 906→916）+ 审计×6 280 case EXIT 0 + CLI 五路径零回归（fib 75025/⇒144 + check ok + effect ⇒120 + closures (4 2)/⇒42 + test PASS 2/2 + higher_order (1 4 9 16 25)）+ **既有 1204 全量零回归**（bootstrap_reader_tests 28 case 全过 = reader.ktf 字节码行为等价性最大回归网）+ r110 包三验
- **演进位置**：切换窗五步流程步③ 第二批 ✅（preamble 首批 r109 + reader 第二批 r110——compiler.ktf[1 cond]/expander.ktf[宏定义目标面]分批续进；步④⑤ 待）；**1204 基线终（r109 单轮）→ 1214 基线起**

## r109 —— 切换窗步③ 首批实施轮（C 类语料目标语法改写启动 + 新 Reader 首次生产化——1204 基线起）

**日期**：2026-10-23　**类型**：切换窗续窗实施轮（净 +13——**1204 基线自 r109 起**）　**驱动**：用户指令「继续推进 目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施 + 按 docs/sop.md 流程结合 docs/lang-design/ 与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 + 同步完整打包项目 tar.gz 并同步完整更新 web page」——**切换窗续窗行权 = M1 指令开窗第十六例**（r108 同指令形态延续——switch-window-plan v1.2 §5 + r108 收口笔双源明文「下一演进 = 切换窗步③」居推荐序首位）

- **切换窗步③ 首批交付**（07 §3.2.1 步③「用新 Reader 重新解析编译器源码（已切换为目标语法版本）」——C 类语料[替换面图 §3.1：reader 472 + expander 2065 + compiler 1147 + preamble 66 = 3550 行]分件渐进首件）：**preamble.ktf**（66 行序章语料 → ~87 行目标语法生产件——.ktf = kerf target form 扩展名[切换窗期语料语法区分]）+ 基础设施三件：
  - **皮肤字典命名映射新条目**（S-expr `-` 词分隔 ↔ 目标面 `_` 词分隔——步③ 语料改写暴露的缺口：目标面 `id_continue` 无 `-`[`is-nil` 词法为减法链不可表示]而 v9 皮肤字典十映射无命名条目[r106-r108 测试语料零连字符名故未暴露]；实现 = kerf-reader/target.rs `target_symbol_name` pub 单点[`_`→`-`；bare `_` 恒等；Token payload 维持词面原文——词法层零语义] + `sym_at` 收口接入[全部符号引入单点] + 桥 'sym→Stx 转换同源——双侧符号 parity；S-expr 生产名域零 `_`[grep 实证] → 映射无歧义）
  - **模块 import/export 头部语法域**（N1 模块生产面——v9 蓝图侧 use_decl 仅消费面，模块生产面 (import)/(export) 头部未入 Level 0[文法缺口——原则 44 产生式义务补齐：02 §8.13.1a 增补]）：种子 target.rs parse_item 双臂 + parse_import_decl/parse_export_decl（Ident|Path 名表 + 名位/名后双位 `as` 域外 fail-closed）+ .krf target_reader.krf 镜像六函数（p-expect ';' 收口同构保错误消息口径）；expander 头部扫描序兼容（import → export → 体形式——core_forms.rs 587/618 实证）
  - **生产/种子双路注入切换**（driver.rs resolve_prelude_imports——PREAMBLE_SRC → preamble.ktf：生产路径 = **.krf 目标 Reader 桥** `read_target_source_for_bootstrap`[**新 Reader 首次成为生产组件**——07 §3.2.1 步③字面语义；fixpoint 推进：语言常驻 Reader 生产化]；种子路径 = `kerf_reader::read_target_source`[r6 对称：Rust 种子读固定库工件]；零环实证——9 件 bootstrap 语料 import 全 kerf-list/kerf-string 零 kerf-prelude 消费；活性探针双件 production/seed_prelude_is_target_reader[`production_*_is_bootstrap` 探针族同构]）
- **parity 门 = 13 case 新测试族**（switch_corpus_parity_tests——三路字节码全等核心门：S-expr 原件基线 ↔ .ktf 种子路径 ↔ .ktf 生产桥路径[同一表符号域归一——指令序/常量池/原型形/全局引用面；debug_spans 跨文本不可比显式排除——r106 SyntaxTransitionValidator 纪律] + 命名映射单点八锚 + 双侧 Reader Stx 正典渲染 parity + 命名端到端字节码/行为 + 模块 forms parity + 错误路径五负例[消息+Span 双侧全等] + 模块结构锚[模块名/import 头/export 20 名/五 define] + 行为等价[五 HOF 全消费 ⇒ (54 . -1)——render_value 渲染口径] + 双展开器 parity[E1-β 纪律向新语料延伸] + 重定义诊断双路渲染全等[E0004——.ktf 模块 define 全局面注册与原件一致的结构性证明] + higher_order.krf 真实语料回归锚 + 活性探针双件）
- **文件策略**（179-a 裁定 3：平行件）：preamble.ktf（生产件）+ preamble.krf（S-expr 原件保留为 parity oracle——bootstrap_compiler_tests 三处 + namespace_tests D50 + stage2 审计×2 继续消费原件零改动）；原件删除 = 步⑤/收口清理批（07 §3.2.1「重写 + 删除」纪律）
- **治理链**：switch-window-plan v1.3（步③ 首批 ✅ + 后续批次序[reader.ktf 第二批 → compiler.ktf 第三批 → expander.ktf 末批] + `import as` 域外登记）+ t3plus v1.29 + 02-syntax-model v7.7（§8.13.1a Level 0 增补位）+ 20-surface-conventions v1.15（§14 皮肤字典新二条 + .ktf 扩展名）
- **验收**：§3.2 六命令全绿 + **test 1204:0:0**（净 +13 = 单元 298 维持 + 集成 893→906）+ 审计×6 280 case EXIT 0 + CLI 五路径零回归（fib 75025/⇒144 + check ok + effect ⇒120 + higher_order (1 4 9 16 25)[经 .ktf 生产注入] + closures ⇒42）+ r109 包三验
- **演进位置**：切换窗五步流程步③ 首批 ✅（reader.ktf/compiler.ktf/expander.ktf 分批续进）；**1191 基线终（r108 单轮）→ 1204 基线起**

## r108 —— 切换窗步② 语法批实施轮（目标语法 Reader .krf 化语法层全落——1191 基线起）

**日期**：2026-10-22　**类型**：切换窗续窗实施轮（净 +15——**1191 基线自 r108 起**）　**驱动**：用户指令「继续推进目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施 + 按 docs/sop.md 流程结合 docs/lang-design/ 与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 + 同步完整打包项目 tar.gz 并同步完整更新 web page」——**切换窗续窗行权 = M1 指令开窗第十五例**（r107 同指令形态延续——switch-window-plan v1.1 §5 + r107 收口笔双源明文「下一批推荐 = 步② 语法批」）

- **切换窗步② 语法批交付**（五步流程步②「新 Reader 字节码化」第二批——渐进披露分批）：**bootstrap/target_reader.krf 语法层增量 ~995 行**（种子语法器全量 .krf 移植——语法入口 `parse-target`：顶层族[parse-program/parse-item/parse-module-decl/parse-fn-decl/parse-typed-params] + 类型消费族[consume-type/consume-type-atom/consume-effect-union/effect-args 等——宽松递归下降解析后剥离] + 块穿线族[parse-block/block-thread/thread-loop——逆序单一算法：let 包裹余部 + 非 let 语句 → do 序列[r45 D42 脱糖同构]] + 语句族[let/assign 桥/if-else 链/perform payload cons 链/handle 单臂/resume 体] + 表达式十四级优先级子集[or→and→comparison 不链式→additive→term→unary→postfix→primary→closure]——后缀 Token 列表穿线[peek/bump O(1)，词法器 char 游标同构风格]）+ **桥扩展**（`parse-target` 入口 + `read_target_source_for_bootstrap`：源 → `Vec<Stx>`——符号引入调用方 table[种子 sym_at 同构——符号引入为宿主职责] + 节点树走查 + 错误双形态[4 字段固定消息 / 6 字段 Token 内嵌——桥渲染 Tk Debug 词面，f64 Debug 与 Str 转义不可 VM 内可靠重实现 = 宿主渲染边界]）+ **kerf-reader 契约单源三函数**（parse_int_payload_text/parse_float_payload_text + tk_debug_of_kind[61 kind 全表 Debug 词面——parity_kind 逆映射]）
- **语法 parity 门 = 14 case 新测试族 + 1 单元测试**（target_reader_krf_tests——.krf 路径 ↔ Rust 种子 oracle **Stx 树正典渲染[符号名 + 字面量值 + Span 字节]字节级全等**）：全程序 ×9（r106 步① 语料族复用）/ 优先级链 ×8 / let 穿线 ×7 / perform payload（0/1/2/3/4 参 cons 链——r108 修复面）/ **参数序正典锚**（渲染 (int V) 序提取——双侧独立防共错）/ handle 形态 ×3 / 闭包 ×3 / 类型注解 ×9（含生命周期泛型修复锚）/ module ×2 / 宏调用 ×2 / if 与字面量 ×7 / 期望错误 13 例（消息含 Tk Debug 词面[Int(5)/Eof/Arrow 等]字节级全等）/ 域外诊断 15 例（字节级全等）/ 活性探针 + tk_debug_round_trip 单元测试（Tk 全变体往返验证——Display→parse→Debug 无损锚）
- **种子修复二件（P2——用户指令「中途穿着缺陷…直接推进」行权，r107 三件先例延续）**：kerf-reader/target.rs ① **perform 3+ 元 cons 链参数序扰码**（mk_cons(second) 后置致 3+ 元产出 [cons a₂ (cons a₁ a₃)] 扰码形——移至循环前[尾二点对先行]；2 元退化单层行为不变、0/1 元零影响、语料零 3+ 元消费形）② **consume_type 泛型参列表双重消费**（`<'a, T>` 位 eat(lifetime) 后再 bump——逗号被吞致 expect(>) 断裂于 Ident("T")；修正为单消费 bump）
- **开发实录九则当场闭环**：括号失衡五处（深嵌套 if/let 链手工计数漂移——结构级校验器定位）+ postfix-loop "!" 臂缺闭括号（形式跨界 E0002）+ E0020 cond 保留字绑定（N4 关键字非值）+ E0022 quoted 并行绑定域（拆嵌套 let）+ call-args 漏传 acc 参 + 'nil quote 产生 nil 值非符号（节点标签改 'unit）+ string-append 三参调用 ×2（内置仅二参）+ cons/do 符号 span 起点化（种子全 span）
- **治理链**：switch-window-plan v1.2（步② 语法批 ✅）+ t3plus v1.28（r108 续窗行权注记）
- **验收**：§3.2 六命令全绿 + **test 1191:0:0**（净 +15 = 单元 298[+1] + 集成 893[+14]）+ 审计×6 280 case EXIT 0 + CLI 五路径零回归（fib 75025/⇒144 + check ok + effect ⇒120 + higher_order + closures）+ r108 包三验
- **演进位置**：切换窗五步流程步② 语法批 ✅（词法批 r107 + 语法批 r108——步② 双批全落；步③④⑤按计划分批）；**1176 基线终（r107 单轮）→ 1191 基线起**

## r107 —— 切换窗步② 词法批实施轮（目标语法 Reader .krf 化首落——1176 基线起）

**日期**：2026-10-22　**类型**：切换窗续窗实施轮（净 +18——**1176 基线自 r107 起**）　**驱动**：用户指令「开始推进 目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施 + 按推荐先后任务顺序继续推进 + 同步完整打包项目 tar.gz 并同步完整更新 web page」——**切换窗续窗行权 = M1 指令开窗第十四例**（r106 同指令形态延续——switch-window-plan v1.1）

- **切换窗步② 词法批交付**（五步流程步②「新 Reader 字节码化」首批——渐进披露分批）：**bootstrap/target_reader.krf 新文件 ~590 行**（目标语法词法层全量 .krf 移植——入口 `lex-target`：进制[0x/0o/0b 大小写前缀 + 无数字段]/数字分隔符 `_`/浮点[含带符号指数]/转义全量[nt r 0 \\ " ']/嵌套块注释/`::` 路径压平 `a::b`→`a/b`[22 §27]/全运算符两字符表[13 组]/unit `()` 前瞻/生命周期 `'x`/整数溢出守卫[T-R 精确界——i64 界免 i128 宽域]/浮点可解析性前置[float-text-bad——f64 不可解析形 = 双 `.` ∨ 双 e/E ∨ `.` 后置于 e 的精确语法刻画]）+ **bootstrap/target_reader.rs 桥 ~290 行**（种子管线编译 + thread_local 惰性加载 + VM 调用 + ParityToken 值桥 + 数字同源 parse[宿主类型边界——reader 桥同源契约]）
- **词法 parity 门 = 18 case 新测试族**（target_reader_krf_tests——.krf 路径 ↔ Rust 种子 oracle **kind/Span/payload 字节级全等**）：全程序词法 ×9（r106 步① 语料族复用）/ 进制与分隔符 / 溢出边界（i64max 精确界 + 十六/二进制界）/ 浮点形态（含 r107 修复面）/ 浮点非法形（错误消息 + Span + 优先级全等）/ 转义与错误（含 EOF 反斜杠口径镜像 + 多字节非法转义字节 Span）/ 注释族（嵌套 + 未闭合）/ 关键字全表 + 路径压平 / 运算符全表 / 生命周期 / 非法字符 / Unicode Span 精确性 / 空源 / payload 值锚 / 活性探针 / 种子投影健全性
- **种子修复三件（R1/P1 实录——用户指令「中途穿着缺陷…直接推进」行权）**：kerf-reader/target.rs ① **Span 字节偏移精确化**（R1 桩清偿——`byte_of` 表替换「char 索引即 Span 偏移」ASCII 域简化；「Token Span 精确」不变式自此覆盖全 Unicode 源）② **带符号指数缺陷**（P1——原 j 前瞻校验后未推进 i：`1e+5` 产出断裂 Token「1e」→ f64 解析必败）③ **指数 `_` 分隔符对齐**（原推入 float_text 致 `1e5_0` 必败——与尾数同规跳过）+ ParityToken/lex_target_for_parity 公共 parity API（60 kind 词面稳定映射）
- **match 设计文档首件**（#5 义务激活兑现——t3plus v1.26「窗内首日义务候选」）：match-design.md v1.0——EBNF 产生式（Level 0 定稿域内追加）/ 脱糖路径第七映射（皮肤字典 D2 增补——match 臂 → cond/let 链；零新原语 = 8 原语不变性第十轮验证锚）/ 穷尽性保守规则（通配臂存在性 + bool 闭域枚举豁免 + 开放域诚实边界）/ M-1..M-4 实施路径（Reader 臂 → 第七映射 → 诊断 → .krf 同步）
- **治理链**：switch-window-plan v1.1（步② 词法批 ✅）+ bootstrap-replacement-surface-map §3.5 实况化（「未来面——尚不存在」→ 实施面两行：Rust 种子[B 类形态 1] + .krf 载荷[C 类预备]）+ t3plus v1.27（r107 行权注记）
- **验收**：§3.2 六命令全绿 + **test 1176:0:0**（净 +18）+ 审计×6 280 case EXIT 0 + CLI 五路径零回归（fib 75025/⇒144 + check ok + effect ⇒120 + higher_order + closures）+ r107 包三验
- **演进位置**：切换窗五步流程步② 词法批 ✅（语法批/步③④⑤按计划分批）；match 设计文档 v1.0 落档（实施批 M-1..M-4 待窗内续批）；**1158 基线终（r106 单轮）→ 1176 基线起**

## r106 —— TD-005 窗 + 切换窗双窗实施轮（R7RS 宏语义 + 目标语法 Reader 首落——1158 基线起）

**日期**：2026-10-21　**类型**：双窗实施轮（净 +15——**1158 基线自 r106 起**）　**驱动**：用户四链指令（①TD-005 窗 + ②目标语言实现窗 + ③推荐序兜底 + ④打包 web）——**TD-005 = M1 指令开窗第十三例；切换窗 = 治理闸门②首次满足（用户信号命中——r104 收口笔「等 next18.md 或切换窗用户信号」后者兑现）**

- **TD-005 窗交付**（syntax-parse 级宏组合——R7RS 4.3 语义面全量·单层域）：**复合省略号 R7RS 收集语义切换**（r101 登记窗内义务兑现——克隆-提交 → 正典；语料零消费形 = 加性变更零破坏；双面：macro_sys.rs match_sequence 重构[固定尾支持 + collected 累积] + expander.krf match-compound/instantiate-items 镜像 + parity 锚更新正典形态）+ **尾省略号 + 固定尾部 `(a ... b)`** + **模板转义 `(... template)`**（字面省略号产出通道）+ letrec 诚实边界裁定（维持内置——常量按迭代生成在声明式模板语义外，R7RS 同界）+ 嵌套深度 2+ fail-closed 诚实边界登记
- **切换窗步①交付**（新 Reader Rust 种子段——B 类自举替换候选）：kerf-reader/src/target.rs ~1400 行——词法层 EBNF v9 全量（进制/转义/嵌套注释/`::`/全部运算符）+ Level 0 内核映射域语法器（fn 声明[类型/效应签名剥离]/闭包/let·assign·if 穿线/十四级优先级子集/perform·handle 单臂/module/宏调用 `!`）+ 皮肤字典映射（D2 六映射 + `::`→`/` + `()`→nil）+ 登记域外 fail-closed 诊断
- **跨语法字节码 parity = SyntaxTransitionValidator 首个真实实例**：同一 SymbolTable 下目标语法源与 S-expr 源编译产物——指令序/常量池/原型形/全局引用面全等（原则 31 皮肤/骨架同构的机器验证；debug_spans 跨文本不可比[按设计]——比较域显式排除）+ 行为等价 VM 值全等
- **治理链**：switch-window-plan.md v1.0（e5-plan 同构——六步清单步 3 计划承载）+ surface-syntax-switch-assessment v1.3-r106（信号命中 + 节点状态改判「切换窗已开」）+ t3plus v1.26（#4 TD-005 部分行权 + #5 match 设计文档义务激活）+ TD-005 登记部分清偿
- **验收**：§3.2 六命令全绿 + **test 1158:0:0**（净 +15）+ 审计×6 280 case EXIT 0 + CLI 三路径零回归 + r106 包三验
- **演进位置**：切换窗五步流程步① ✅（步②③④⑤按计划分批）；TD-005 残留（嵌套深度 2+ + 结构化 DSL 守卫面）维持触发式；**1143 基线终（r103-r105）→ 1158 基线起**

## r105 —— 例行监测与 web 完整性清偿轮（推荐序前列零信号维持态诚实登记 + web R4 顺修三处）

**日期**：2026-10-21　**类型**：例行监测轮（零 kerf 代码变更——1143 基线第三轮）　**驱动**：用户双指令（①按照 docs/sop.md 流程结合 docs/lang-design/ 下的项目演进流程 与 docs/develop/v0/tech-debt-register.md、docs/develop/v0/stage-3/t3plus-trigger-audit.md 按照推荐先后任务顺序继续推进 ②同步完整打包项目 tar.gz 并同步完整更新 web page）——**非行权形态**（r78/r100 监测轮同构；红线 3 零信号不开窗合规）

- **推荐序裁定**：第 1 位 #15 需 next18.md（upload/ 实测未上传）→ 第 2 位 TD-032 ✅ r90 + 第 3 位 TD-031 ✅ r99 + 第 4 位 HM ✅ r80 全清偿 → 第 5 位 T3+ 14 行各需特定消费信号零命中——推荐序前列零信号维持态诚实登记，本轮不开任何窗
- **例行监测实测**：六族 grep 全零（match 用户面 0[宽口径命中全为 match-* 连字引擎私有 helper 族——.rs 桥文件 Rust match 语法甄别] + net/extern/@ 0 + vector #( 0 + syntax-parse 1 = TD-005 注记本体 + 嵌套省略号严格形 0[宽口径 27 全为注释形/xperr 错误消息字符串形/单层省略号宏——非嵌套] + 命名旧形族 -> 与 ? 尾缀全零）+ OBS-C 70.889/71.066/71.438ms 带内第 49 轮（<65ms 不满足——零消费方维持）+ CLI 三路径逐字一致（fib 75025/⇒144 + check ok：2 原型/9 常量/5 全局引用/38 指令[缓存未中；会话命中 0/0] + effect_stress ⇒120）+ TD 开放 P0/P1 = 0
- **§3.2 六命令全绿**：build --release 0.01s（缓存命中——零代码变更实证）/ check 0/0 / fmt --check 0 diff / clippy --workspace --all-targets --release -- -D warnings 零告警 / **test --release --workspace 1143:0:0 逐位维持**（24 suite——单元 297 + 集成 846；RUST_MIN_STACK=16777216 沿袭 r29）
- **审计×6 280 case 真实 EXIT 0**：stage0（41 case §7.3.1 配比满足 + 七类全覆盖）+ stage1 + stage2_r1 + stage2_r2（S1-S9）+ e5close（E5 出口三条件全绿——S4 收口 GO）+ m3（窗 M 出口条件达成）——含审计集正确名称复核（stage3_gate_audit_e5close/m3——管道尾命令误捕 EXIT 假阳性甄别实录）
- **web 完整性 R4 顺修三处**：hero.tsx（徽章「Stage 1 · 自举验证进行中（批次 A/B/C/D 已交付）」r25 期陈旧态 + 描述段 + 测试提示「r8 口径」→ v1.0.0·Stage 3 全收口 + T3+ 待触发态 / 十件 .krf 自举面 / EBNF v9 定稿就位 / 1143+280 口径）+ site-header.tsx（版本徽章 v0.1.0·Stage 0 → v1.0.0·Stage 3+[T3+ 触发式]）+ site-footer.tsx 底行（r89 → r105）——r104 轮 kerf-data/footer 主链更新未覆盖 hero/header 次链的存量漂移当轮清偿；web lint 0 + 渲染验证三锚（r105 状态行/hero 徽章/header 徽章）
- **对账链**：matrix r105 增量行 + 总量行 r105 注记（1143 基线第三轮[r103-r105]）+ t3plus-trigger-audit v1.25 + rec 67（03 层）+ 根层 l r105 条目 + kerf README 两处 + web 五件（footer v7.74 + kerf-data 五处 + download README + stats 双源自动对账）+ r105 包三验 + worklog 三链镜像
- **演进位置**：14 行触发族判定零变化——待触发态维持；下一演进 = next18.md 或切换窗用户信号或自然信号触发；**1143 基线第三轮（r103-r105）**

## r104 —— EBNF 整合定稿轮（第二十五轮指令·EBNF 定稿子窗）

**日期**：2026-10-20　**类型**：纯文档定稿轮（零代码变更——1143 基线第二轮）　**驱动**：用户五链指令（EBNF 整合 + lang-design 系统性审查 + 双反哺 + 对账打包）——**EBNF 定稿子窗开窗**（M1 指令开窗第十二例——纯文档域；#15 讨论主线第十五次用户行权；切换窗本体维持未开窗：定稿 ≠ Reader 实施）

- **EBNF v9 整合定稿**：stage0.md v8.3→v8.4 §9.26 十小节（V-A..V-H 八裁定）——九源语料地图（§9.16.4 骨架 + v1-v8 八份）+ 六整合原则 + 十二整合裁定 C1-C12 + 完整文法（词法层 Rust 最小集补全 + Level 0 定稿域 + Level 1-4 扩展语法族登记）+ **运算符优先级结合律十四级表（定稿义务兑现——原 #15 窗内义务）** + 关键字分级终态（15 全域 + 4 语境 + 3 位形 = 22 定稿词面；张力族 ~47 候选全脱糖优先）+ 二义性 22 例完备消歧（新增例 18-22）+ 宏层脱糖路径表 + 数学底层与内核映射（8 原语不变性第九轮验证——零新增原语零通道增量）+ 皮肤字典映射基础
- **lang-design 七件收编**：02 v7.6 §8.13（**grammar L2 规范层权威定稿位**——EBNF 块零漂移双源）+ 22 v2.14 §27 + 20 v1.14 §14 + 17 v7.15（原则 54）+ 18 v7.19 §5u + 19 v7.11 §26（E.26 四文献 145-148）+ 00 v6.20
- **系统性审查**：next.md-next17.md 全问题交叉审计——声称锚点十五件 grep 核验零断链 + 专项维度全覆盖 + 唯一缺口（EBNF 未定稿）本轮清偿——零 P0/P1
- **双反哺**：00 文档地图 v8.4 + surface-syntax-switch-assessment v1.2-r104（六步清单第 1 步设计面达成）+ sop v13.16（原则 54 + §21.12 第 23 条 + §8.4.5 查询行 + 五十四计数 + 变更日志）
- **验收**：§3.2 六命令全绿 + **1143:0:0 逐位维持** + 审计×6 280 case EXIT 0 + CLI 三路径零回归 + r104 包三验 + web E2E
- **演进位置**：语法线程定稿收束（八份骨架累积义务兑现——「定稿义务仍在 #15 切换窗内」注记自本轮改写为「定稿已就位于 02 §8.13」）；T3+ 14 行触发族判定零变化（等 next18.md 或切换窗用户信号）

## r103（v1.0.0-r103）——状态恢复轮：z.ai web 保存机制回退恢复（r102 权威态单源重建 + 1143 基线逐位恢复 + web r90-r102 补链）

**驱动源**：用户指令——「当前由于 z.ai web 端的保存机制，导致项目推进内容有所回退，使用上传的 kerf-v1.0.0-r102-naming-modern-1143tests.tar.gz 替换掉当前项目内容」+ 五链验收态核验（next.md-next17.md 已于 r90-r102 全量吸收：stage0 v8.3 / lang-design 25 件收敛 / sop v13.15——恢复即兑付）+「同步完整打包项目 tar.gz 并同步完整更新 web page 与 kerf/docs/develop/v0/stage-3/t3plus-trigger-audit.md」。

**① 恢复主体（173-a）**：环境整体回退实况（仓库 git HEAD r89[5b13ae8] + 工作树 r89/r102 混合态 114 处差异 + web 五件 r89 态 + download 仅 r89 包 + 外根 worklog 末条 r89）→ r102 tarball 单源解包替换（保 .git——544 tar 成员全量落位 + 差异归零核验 diff -rq 0 处 + 模式位 755×3[tools/qbe/bin/qbe + scripts/qbe/setup.sh + scripts/rust/setup.sh] + 双源 worklog md5 一致[535459c9——9014 行]）+ git 恢复笔 a00a028（r90-r102 全量 370 文件变更单笔承载——r90 任务① 同构先例）+ Rust 1.98.1 工具链重装（环境重置所致 §3.1 工具缺失处置——scripts/rust/setup.sh 官方 rustup 路径）。

**② 验收（173-b）**：§3.2 六命令 clean 起步全绿（build --release 17.08s 零告警 → check 0/0 → fmt --check 0 diff → clippy --workspace --all-targets --release -D warnings 零告警 → **test --release --workspace 1143:0:0 逐位恢复**——24 target[单元 297 + 集成 846；RUST_MIN_STACK=16777216 沿袭 r29]）+ 审计×6 280 case EXIT 0（stage0/stage1/stage2_r1/stage2_r2/e5close/m3——§7.3.1 规则 3 可重跑实证）+ CLI 三路径逐字一致（run fib 75025/⇒144 + check ok：2 原型/9 常量/5 全局引用/38 指令（缓存未中；会话命中 0/0）+ effect_stress ⇒120）。

**③ web + download（173-c）**：web 五件 r90-r102 补链重建（kerf-data 五处：status r103 前置 + points[0] r103/points[1] r102 详情块 + HERO 14 行[r103-r90 每轮一行] + PACKAGE stats 1143 行 + rec 树 102 条目[03 层 64 rec 编号至 65] + footer v7.72[JSX 文本位裸符号防护——ASCII 箭头全角化沿袭 r99-r102 先例] + download README r103 节置顶 + stats API 双源自动对账[testCount 1143 ← matrix.md 解析 + packageName ← download 目录]）+ r89 包退役清除（仅保留最新交付包策略沿袭）+ lint 0。

**④ 对账（173-d）**：RELEASE r103 节（本节）+ rec 65（03 层）+ matrix r103 增量行（1143 维持——零测试函数增量）+ t3plus v1.23（r103 恢复轮注记——非行权形态登记）+ 根层 l r103 条目 + README 两处（最新包行 + 质量状态节头）+ worklog 三链镜像（docs/worklog.md 173 全录 + kerf/worklog.md 双源 md5 + 外根浓缩条目）。

**⑤ 演进位置**：T3+ 触发族 14 行零信号维持（等 next18.md 或切换窗用户信号——恢复轮零行权）；TD-031/032 全清偿关闭维持；TD-005 窗内义务两项维持（复合省略号语义切换评审 + letrec 诚实边界）；**1143 基线维持**（恢复轮零代码变更——r102 起基线逐位对账）。

**⑥ r103 包**：kerf-v1.0.0-r103-recovery-1143tests.tar.gz（git archive HEAD 单源 + 模式位纪律——包内自举三验全绿：独立解包净构建零告警 + 包内 test 1143:0:0 复跑 + e5close EXIT 0 + fib ⇒144）。

## r102（v1.0.0-r102）——S 表达式命名现代化清偿 + 文件层级复审二轮：残余 7 名专项窗 + 闭合守卫（M1 指令开窗第十一例）

**驱动源**：用户三段式指令——「① 整理项目文件层级结构和组织形式（可以重命名或通过目录整理，如：kerf-backend/ 下就不要将所有文件都平铺……请审查项目是否存在类似问题并修复）② **注意当前项目对 S 表达式的命名变化（禁止使用 ->、? 等不清晰的命名形式，使用现代方式命名，如当前：lbld-imports-prelude? 这就是错误的）**③ 按 docs/sop.md 流程结合 docs/lang-design/ 推进演进 + 同步完整打包 tar.gz 并同步完整更新 web page」。

**① 文件层级审查二轮（172-a）**：r101 171-a 三域目录化（backend wasm/+native/、driver bootstrap/）后全树复审——唯一残余 = 根层 `tool-results/r101-search/`（其余 12 轮检索存档均居 docs/tool-results/——物理组织与归档治理约定不一致）→ `git mv` 归位 `docs/tool-results/r101-search/`（13 存档目录物理一致——根空间治理物理印证原则的复审兑现）+ 活跃引用同步三处（22-namespace v2.13 版本头 + §26 证据行 + RELEASE r101 节——`../tool-results/` 相对路径形态对齐 r83 先例）；全树其余判定 = 维持（docs/stage0.md = 上游蓝图存档既定约定 + docs/backend|vm|graph 组件 README 单件目录约定 + scripts/tests/examples/tools 域化在位）。

**② S 表达式命名现代化清偿（172-b——M1 指令开窗第十一例：用户点名「禁止使用 ->、? 等不清晰的命名形式」= 20 §6.5 机会主义迁移条款的专项窗升格——r74 先例「用户指令即需求信号本体」）**：自举语料面残余 7 名全清偿——`lbld-imports-prelude?`→`lbld-is-imports-prelude`（build.krf 入口定义 + 递归调用 + 头注释 + build.rs `ENTRY_NAME` + 桥文档注释——双侧同步 3+3 处；R2 `is-` 前缀现代谓词形态）+ `num->str`/`int->str`→`int-to-string`（**同概念统一单名裁定**：expander.krf 与 test.krf 两份同算法数字渲染函数（递归除余 + 数字表）收敛为一现代名——R1+R4 合成：`num` 为 number 缩写违 R1 全词、语义域 Int、20 §9 原登记 `num-to-str` 当轮修正）+ `chars->str`→`chars-to-string` + `datum->value`→`datum-to-value` + `list->pairs`→`list-to-pairs` + `params->bound`→`params-to-bound`——**33 处替换逐计数验证**（krf 语料 30 + Rust 桥 3；替换后全仓 grep 旧形零命中）；入口改名端到端一致性由 `production_build_is_bootstrap` 活性探针 + build_krf_parity 14 case 全绿实证（krf↔Rust 名面漂移即入口查找失败——fail-closed）；净 +1 单元 = kerf-driver `bootstrap/mod.rs` 新增**闭合守卫** `bootstrap_naming_modern_closed`（10 .krf 全量：`(define` 名面 `?` 尾缀零断言 + 全文 `->` 零容忍[含注释面]——20 §8 R1-R4 现代命名法的机器锚；合法 `?` 白名单 = check.krf Rust `?` 运算符注释 + reader.krf 标识符字符集字符串表[E0021 旧名诊断的词法前提]——`?`/`->` 词法域维持不收紧裁定沿袭 e5-plan §4.2）。

**③ T3+ 例行监测（172-c）**：六族 grep 全零（match 用户面 0 / net-extern-@ 0 / syntax-parse 1 = TD-005 注记本体 / vector `#(` 0 / 嵌套省略号严格形 0 / **命名旧形族本起新增第六族 0**——`->` 全零 + `?` 尾缀定义零）+ OBS-C bench 三轮 71.296/71.506/71.227ms（r55-r101 噪声带内 47 轮——<65ms 不满足，零消费方需求信号维持）+ CLI 三路径零回归（run fib⇒75025/⇒144 + check ok{2 原型/9 常量/5 全局引用/38 指令——缓存未中} + effect_stress⇒120）——**T3+ 触发族 14 行判定零变化：待触发态维持**（本轮开的是用户指令命名窗——外源窗非 T3+ 行，红线 1/3 合规）。

**④ 文档同步**：20-surface-conventions **v1.13**（§6.5 机会主义迁移条款终结注记——历批次顺带收编 + r102 残余 7 名专项窗 + 闭合守卫；§9 第 2 条终名裁定登记[原 `num-to-str` 修正为 `int-to-string`——R1+R4 合成依据]；Status 行增「引导语料私有名清偿 ✅ r102」）+ 07-bootstrap-strategy **v7.0**（§3.2 双注册注记 r102 更新[机会主义迁移终结 + 入口名 lbld-is-imports-prelude] + **R4 顺修一处**：B3 交付注记 `str-int-valid?`→`string-is-int`——D63 注册面改名后滞留）+ 22-namespace v2.13 / RELEASE r101 节（tool-results/r101-search 归位路径同步——`../tool-results/` 形态）。

**⑤ 终验与对账**：§3.2 六命令 clean 起步全绿（build 零告警 / check 0/0 / fmt 0 diff / clippy --all-targets 零告警 / **test 1143:0:0**[24 target——RUST_MIN_STACK=16777216 沿袭 r29]）+ 审计×6 全 EXIT 0 + CLI 三路径零回归 + r102 包三验全绿（净构建 + 1143 复跑 + e5close EXIT 0 + fib⇒144）+ web 五件 + stats 双源自动对账（1143/r102 包）+ E2E 双视口零溢出 + Playground ⇒144；对账八件 = matrix r102 行 + 总量行 + 本节 + rec 64 + 层 l r102 条目 + t3plus v1.22 + 指南 v1.21 + README 计数同步（1142→1143）。**1143 基线自 r102 起**。

## r101（v1.0.0-r101）——衍生关键字宏化 + require 重筛 + 文件层级域目录化：七糖 S 表达式拓展宏实施（M1 指令开窗第十例）+ append 先在缺陷清偿（A 类基座）+ 22 §26 知识搜索四查询重筛（零翻转）+ 根空间治理物理印证

**驱动源**：用户三段式指令——「① 整理项目文件层级结构和组织形式（可以重命名或通过目录整理，如：kerf-backend/ 下就不要将所有文件都平铺（wasm 就是自己治理的内容，从某些方面上根空间的治理理念在项目的物理逻辑上是相互印证对照的，请审查项目是否存在类似问题并修复））② 按照 docs/sop.md 流程结合 docs/lang-design/ 下文档集合内容推进项目演进流程，按照推荐先后任务顺序继续推进（match 用户面消费，net/extern/@ 族，OBS-C（fib <65ms——性能消费面），CLI 生产链健康，check.krf, 等现有 krf 自举内容审查和深化健壮），S表达式拓展宏补充完备实施衍生关键字，能力模型适配和关键字（require 结合设计与知识搜索进行审核与重新筛选及语法形式和表达能力），版本？（思考 S 表达式作为脚手架需要考虑版本吗？这不是在目标语言阶段应该考虑的事情吗？）③ 同步完整打包项目 tar.gz 并同步完整更新 web page」。

**① 文件层级域目录化（171-a）**：kerf-backend `wasm/`（wasm/mod.rs 契约层 + abi.rs + compose.rs + emit.rs——TD-031 M0-M3 自治理域四件）+ `native/`（qbe.rs + aot.rs——本地码域）+ kerf-driver `bootstrap/` 域统一（9 桥 .rs 与 10 载荷 .krf 同目录——「桥↔载荷成对物理相邻」）；git mv 历史保全；全仓引用同步（外部消费方走 lib.rs 再导出**零变更**——仅内部 crate:: 路径与 include_str 相对路径机械迁移 + 测试/示例/审计器 15 文件路径更新 + .krf 头注释桥路径更新[注释词法剥离——零字节码影响]）；活文档面 R4 对齐三件（tech-debt TD-031 行 / 07-bootstrap 桥路径 / wasm-model §5 架构节）；**根空间治理理念物理印证**（24-space-decomposition：后端根 = 共享契约 codegen + 共享 lowering anf；两自治理目标域分居 wasm/ 与 native/；driver 根 = driver 核心，bootstrap 域 = TD-032 链 + 自举桥族）——「自治理域不散置于 crate 根」的全树审计结论：backend 与 driver 两处修复，其余 crate 单文件域无平铺问题维持。

**② 衍生关键字宏化（171-c——M1 指令开窗第十例：「S 表达式拓展宏补充完备实施衍生关键字」= 需求信号本体[r74 先例]）**：七糖（when/unless/and/or/let\*/cond/while）自硬编码变换器迁移为**真实 syntax-rules 宏**——种子侧 `kerf-expander/src/derived.rs` 新模块（DERIVED_SOURCES 单一 S 表达式源[七定义逐头] + 形式校验器保留负例消息契约 + `TransformerKind::Derived{validate, rules}` 新通道 + builtin_transformer 重写 + sugar.rs 收窄至 letrec 一件）；krf 生产侧 `expander.krf`（lexp-init-derived 注入入口 + DERIVED-ENTRIES 注册基[每次展开复位] + 'derived 变换器臂[校验先行] + validate-derived 族——七 desugar-\* 函数族退役）；桥侧 `bootstrap/expander.rs` inject_derived_macros（**同一 DERIVED_SOURCES 字符串集**经 stx_to_node 桥接注入——模板 Span 与卫生行为两侧同源 = E1-β parity 与 B₀/B₁ 反汇编文本 parity 的**单一源锚**[file_id 0 对齐用户主文件约定]）；**letrec 维持内置**（诚实边界：nil 实参按绑定数重复填充 `((fn (f...) ...) nil nil ...)` 在深度-1 省略号模板面不可表达——R7RS syntax-rules 同族限制，TD-005 族设计窗事项）；**R7RS 复合省略号序列收集语义审查裁定回退**（实施后发现与 Stage 0 编纂行为冲突——parity_macro_compound_ellipsis 两例锁定克隆-提交语义——非加性变更不作静默切换，登记 TD-005 族窗内义务）；**append 先在缺陷清偿**（A 类基座非重复可进行：`append` 内建在前参全空 + 末参 nil 时恒返回 `Pair(box(nil))` 伪序对[遍历即「tail 应用于非序对堆槽」崩溃] + 末参原子产出单件列表非 improper 尾——宏模板空序列子列表拼接 `(a ...)`[a = ∅] 的必经路径，衍生 let\* 空 rest 拼接首暴露——修复 = elems 空时末参**原样**返回[正典语义]）；CoreExpr 级零漂移验收（E1-β parity + 门 B fixpoint + 1142:0:0 全绿 + CLI 实测 let\*⇒3/cond⇒2/when⇒2）。

**③ require 与能力关键字族重筛（171-d——M1 形态：「require 结合设计与知识搜索」）**：22-namespace §26 新增（v2.13）——四查询实证（docs/tool-results/r101-search/：q1 WASI 组件模型声明式授权[WIT「描述组件 imports/exports」+ wasmCloud typed WIT 契约] / q2 Clojure require-use-import-refer 四族分工 / q3 OCaml 5-Koka-Eff-Unison 效应动词族[resume/continue 二支系] / q4 ocap 不可伪造令牌模型）；**四件全维持**（require/perform/handle/resume——r43 D25 裁定经 2026 证据面复核零翻转）；require 撞名 P3 维持但**三重区分度注记增强**（Clojure require 居 ns 宏键位形态 vs kerf 独立顶层声明 + 参数形态完全不同 + kerf import 分立承载模块加载语义）；resume **家族支系澄清**（kerf 属 Koka/Eff/Unison 支系——OCaml continue 为平行支系非竞争名）；语法形式与表达能力复核（S-expr `(require 主体 能力...)` 与 WIT 声明位架构同构 + 幂等集合/fail-closed/Stage 2 扩展面提示——声明面完整表达边界维持）；能力模型适配对账（IoGrant 令牌铸造 = q4 unforgeable token 同构）；与 CAP-D 宏层糖路径的机器支撑强化注记。

**④ krf 自举内容审查（171-e）**：10 .krf 载荷 + 10 桥——零桩零静默零裸 unwrap（唯一「暂不支持」= quote 向量 TD-002 既登记边界）；本轮健壮性深化 = append 崩溃级缺陷清偿 + 宏化双路径架构 + 全量套件绿。

**⑤ T3+ 例行监测 + 用户九项枚举逐项裁定 + 版本问询（171-b）**：六族 grep 五零（match 用户面 0 / net 0 / extern 0 / @ 0 / vector `#(` 0——syntax-parse 1 = TD-005 注记本体）+ OBS-C bench 三轮 70.842/71.113/70.614ms（r55→r101 带内一致 46 轮——<65ms 不满足，零消费方维持）+ CLI 三路径零回归（fib⇒75025/144 + check ok[2 原型/9 常量/5 全局引用/38 指令] + effect⇒120）+ #15 next18.md 未上传维持；**版本问询裁定**：S-expr 脚手架阶段**不需要**版本化 ✓（触发族 #2 = Stage 3+ 包管理窗维持——23 §5.2 + 22 §7 接口语义位已锁 = 接口预留已在位；用户原则「当前阶段是否需要 + 适配 + 接口预留」= 原则 12/17 既有元分析规则的合规实例——问询即对照非开窗信号[r70/r100 assessment 同形态]）。

**验证**：§3.2 六命令 clean 起步全绿（build 零告警 + check 0/0 + fmt 0 diff + clippy 零告警 + test **1142:0:0**[24 target——RUST_MIN_STACK=16777216 沿袭 r29]）+ 审计×6 全 EXIT 0 + CLI 三路径零回归 + 断链扫描零；**净 +1 测试**（kerf-expander derived_sources_parse_cleanly——七糖定义源可解析性结构烟测）；**1142 基线自 r101 起**。对账：matrix r101 行 + 03-macro-system v6.5（能力边界更新——衍生关键字宏化 + letrec/复合省略号双诚实边界）+ 22-namespace v2.13（§26 重筛节）+ t3plus v1.21 + 指南 v1.20（行权态十六次——r101 宏化窗第十例）+ rec 63 + 层 l r101 条目 + README 测试计数同步（1141→1142）。

## r100（v1.0.0-r100）——结构整理轮 + 切换窗就绪度复审：v1.1-r100 问询对照锚第二例（零信号不开窗维持——TD-031/032 全清偿后首个维持轮）

- **用户驱动源**：四段式指令「① 整理项目文件层级结构和组织形式（可以重命名或通过目录整理）② 结合项目当前设计情况审理距离开启将表达式转换为目标语言当前进度以及可能存在的缺陷或内容是否处理完整 ③ 按照 docs/sop.md 流程结合 docs/lang-design/ 下文档集合内容推进项目演进流程，按照推荐先后任务顺序继续推进 ④ 同步完整打包项目 tar.gz 并同步完整更新 web page」——170-a..170-e/170-c2 六 MUV + 收口。
- **结构整理三动作（170-a）**：①`docs/tools/rust/setup.md` 字节级重复件删除（与 `docs/scripts/rust/setup.md` md5 同 `a9264013`——r46 deep-review-round1 已登记缺陷当轮清偿；§3.4 归位 = 脚本文档归 `docs/scripts/`）②`scripts/s1_migrate_names.py` → `scripts/archive/` 归档（r42/63-b 一次性迁移工具使命完成——§3.4 目录约定收敛：scripts/ 根只承载常驻环境脚本；archive/README.md 归档登记表立约「只进不出」）③README.md 目录节九处实况对齐（10→11 crates / lang-design 24→25 篇 / stage0 v7.0→v8.3 / sop v13.0→v13.15 / 测试 919→1141 / 自举四件→自举面十件 .krf / kerf-space 与 WASM M0-M3 入架构行 / 最新包 r64→r99 / download 外置注记 + worklog.md 条目）+ sop §3.4 表示例路径 R4 顺修（示例改指实存文件 + 强制规则 1 检查面补 `docs/scripts/`）——**断链扫描活文档面零命中**（余下命中均为不可变档案 worklog 树/历史审查件/归档登记表自身）。
- **切换窗就绪度复审（170-b）**：`surface-syntax-switch-assessment.md` **v1.0-r70→v1.1-r100**——§2.1 增量两行证据（自举面扩张至十件 .krf——BS-A Phase 1 超越实证 + WASM M0-M3 parity 五段实例——切换窗验证底座强化）+ §3 监测矩阵 r70/r100 双列复测（**match 语言面 0 命中**——自举命中全为连字符私有 helper 族 + cli.krf 注释三处「main.rs 原 Rust match」移植注记，r56/r70 口径逐字一致；net/extern/@/vector `#(` 全 0；OBS-C 70.950/71.003/70.527ms——r55→r100 带内一致 45 轮，触发线 <65ms 不满足）+ **新增 §3.1 D2 弹药库完备性审理**（收编零遗漏 + 验证协议六项弹药清单 + 缺陷分级 **P0/P1/P2 零** + P3 三项开窗义务[双 Reader CLI 双入口设计候选 / 映射表 E5 重叠审定义务 / 目标语法 EBNF 窗内定稿义务]——**处理完整 ✅**）+ §5.2 六步前置清单逐项 r100 状态注记 + §6 结论表增「D2 内容处理完整吗？完整 ✅」行——**节点判定维持「技术就绪 + 治理待触发」零信号不开窗**（问询对照锚机制第二例——r70 同形态先例）。
- **推荐序裁定（任务③）**：第 1 位 #15 需 next18.md（upload/ 实测未上传）+ T3+ 14 行零信号 + TD-031/032 全清偿——本窗用户四段式指令本体即工作内容（r74 先例：用户显式指令 = 合法需求信号）；零信号维持态诚实登记（等 next18.md 或切换窗用户信号）。
- **验证**：§3.2 六命令 clean 起步全绿（build --release 零告警 + check 0/0 + fmt --check 0 diff + clippy 零告警 + test **1141:0:0 逐位维持**——结构整理轮零代码变更）+ 审计×6 280 case EXIT 0 + CLI 三路径零回归（fib⇒144 / check ok / effect⇒120）+ 断链复扫零命中。
- **r100 包**：`kerf-v1.0.0-r100-reorg-readiness-1141tests.tar.gz`（包内自举三验全绿：独立解包净构建 + 1141 复跑 + e5close 审计 + CLI fib 144）。
- 对账链：matrix r100 行 + [rec 62（03 层）](docs/worklog/03_stage-3_入场序列/62_r100_结构整理与切换窗就绪复审.md) + assessment v1.1-r100 + t3plus v1.20 + 指南 v1.19 + 层 l r100 条目。

## r99（v1.0.0-r99）——TD-031 M3 组件组合层实施：imports/exports 缝合 + 组件级类型校验 + L-β 效应/能力组件实例协议裁定（用户 M1 指令开窗第九例——TD-031 全清偿关闭）

- **用户驱动源**：双链指令「① 按照 docs/sop.md 流程结合 docs/lang-design/ 下文档集合内容推进项目演进流程，按照推荐先后任务顺序继续推进 ② 同步完整打包项目 tar.gz 并同步完整更新 web page」——**M1 指令开窗第九例**（指南 §4 速查卡【第 3 位】TD-031 M3；行权链 r74/r79/r80/r86/r87/r90/r92/r97/r99）。
- **推荐序裁定 + M3 判据回填**：第 1 位 #15 需 next18.md 未上传（next17.md 已 r98 全量消费）→ 第 2 位 TD-032 ✅ r90 / 第 4 位 HM ✅ r80 清偿 → **第 3 位 TD-031 M3 落位**；判据两腿 = M2 ✅ r97 + **组件组合消费方**（用户指令 = 需求信号本体[r74 先例锚——指南 §4 响应契约「指令即触发」] + M2 双工件族组合基底[emit_core_module + emit_abi_module 两类发射工件并立——M2 L-A′ 裁定明文登记的后续信号路径] + node 宿主组合实例化验证实体[本窗交付]）。
- **净增量三件**：①`crates/kerf-backend/src/wasm_compose.rs`（组合层——**imports/exports 缝合**：`compose_component(ir, model, data, abi)` → M2 边界模块 + M3 链接核心模块 + `InstantiationPlan` 有序实例化计划[双步：`kerf_abi` 无导入 → `kerf_core` 注入 wiring 图{memory + realloc 双缝合}] + **组件级类型校验** `validate_composition` 五校验全 fail-closed[memory64 地址域一致性 / realloc 供给一致性 / **边界类型分配协议**——`boundary_class` 递归扫描 String/List 族要求 realloc——M0 契约层 InterfaceType 首次真实消费 / Func 导出背书 / main 入口背书] + **L-β 效应/能力组件实例协议裁定**）+ ②`wasm_emit.rs` 增量（`CoreImportFace` 导入面 + `emit_core_module_linked`——Import 节 id 0x02 插 Type/Function 间 + realloc 签名类型池条目[wasm32 独立/memory64 与四形参同构复用] + **函数索引空间基偏移**[导入函数占前位——Export main 与 Call 同步偏移]——plain 形态零变更）+ ③`tests/v0/stage3/plan/wasm_compose_tests.rs`（node 宿主组合 E2E + 缝合真实性负探针——runner 树挂载）。
- **L-β 裁定（效应/能力组件实例协议）**：perform/handle 不跨组件边界——效应承载于组件实例协议（宿主按组件实例实例化处理器——M0 §3「效应/能力|边界外」表的 M3 落位）；**结构化守护** = `boundary_class` 穷举全部 `InterfaceType` 变体（当前全部效应无关——类型系统不设效应承载面，结构事实；新增变体必须补分类臂否则**编译期断裂**——fail-closed 的编译期形态）；组合面接收 ANF 恒为效应无关（`AOp = Prim|Call`、`ACtrl = Ret|Br|Jmp` 无效应变体——效应程序走 VM 路径 INC7）；组件实例协议完整设计 = 后续 B1 扩界/效应后端信号窗义务。
- **node 宿主组合 E2E**：按计划实例化 canonical 双模块系统——validate ×2 → 实例化 `kerf_abi` → 其导出面（memory + realloc）作 import object 注入 `kerf_core` 实例化 → `main()` 与 kerf VM `run_source` 逐语料对账（**缝合的运行时类型检查背书**——名/类型/页数不匹配即实例化失败）：fib 12→144 / fib 20→6765 / 算术 / 值菱形 / 嵌套菱形 / 尾位 if / 互递归 / div-mod 负数 / i64 全宽边界（2^32 / i64::MAX）；**缝合真实性负探针 ×2**（无 import object → LinkError[导入依赖真实非装饰]；错误 memory 接线[42] → 实例化失败[类型检查真实]）；自定义 realloc 名接线 parity（名从 ABI 选项 → face → 计划 → 宿主接线**单源透传**）；memory-only 形态（realloc = None 单缝合 + 基偏移零）。
- **M3 诚实边界**：核心模块对导入面的**语义消费**（str 载荷经 memory + realloc 的语言面 lowering）= B1 扩界窗信号（与 M2 L-A′ 同族——`string_literal_rejected_before_emit` 负例继续守护）；M3 交付组合协议面（缝合 + 类型校验 + 实例协议裁定），组合系统经宿主链实例化验证（导入面结构性接线——实例化期类型检查即消费验证）。
- **验证**：§3.2 六命令全绿（build --release 零告警 + check 0/0 + fmt --check 0 diff + clippy 零告警 + test **1141:0:0**[单元 295 + 集成 846——净 +27：单元 18 + 集成 9]）+ 审计×6 280 case EXIT 0 + CLI 三路径零回归（fib⇒144 / check ok / effect⇒120）。
- **TD-031 终态**：M0 契约层 ✅ r74 + M1 核心模块生成 ✅ r92 + M2 canonical ABI 适配 ✅ r97 + **M3 组件组合 ✅ r99——四阶段全落全清偿关闭**（后续演进 = B1 扩界窗/组件实例协议窗——触发式，红线 3）。
- **r99 包**：`kerf-v1.0.0-r99-component-compose-1141tests.tar.gz`（包内自举三验全绿：独立解包净构建 + 1141 复跑 + e5close 审计 + CLI fib 144）。
- 对账链：matrix r99 行 + [rec 61（03 层）](docs/worklog/03_stage-3_入场序列/61_r99_TD-031M3组件组合实施.md) + wasm-backend-component-model v1.3 §5.3 + 登记册 v0.4.13 + t3plus v1.19 + 指南 v1.18 + 层 l r99 条目。

## r98（v1.0.0-r98）——#15 讨论主线第十四次用户行权：渐进式混合自举与语法迁移验证全量吸收（纯文档轮——工程进程线程开面）

- **用户驱动源**：五链指令「① next17.md 吸收进 stage0.md 直至完全收敛 ② 融入 lang-design 对应文件 + 系统性全面审查[十六维] ③ 反哺 stage0.md 二次整理 ④ 反哺 sop.md 适当位置 ⑤ 打包 + web」——**r97 收口笔明确等待的 next17.md 信号落位**（第十四次 #15 目标语言设计讨论主线用户行权——行权链 r74/r79/r80/r81/r83/r84/r88/r89/r91/r93/r94/r95/r96/r98）。
- **语料与形态**：next17.md（1046 行两文档）——D1「前端自举 vs 完全自举」（两路径部件级定义 + 6+4/6+6 优缺点 + 六维度决策矩阵 + 渐进式混合自举三阶段 + 决策树 + 八语言先例表）+ D2「S-expr→目标语法转换阶段指导」（替换四步 + 同结果测试框架 Rust 设计 + 语法映射表六映射 + 三层验证 + 四陷阱）——**工程演进/进程面语料（第一个工程面吸收轮——理论载体十环维持，五线程族完备态不推翻）**。
- **BS-A 自举路径第三形态落位**：kerf = **最大化前端自举**（前端三段[read r6/expand r15/compile r23] + HM 判定面[r80] + 构建编排五切口[TD-032 全收口]全自举——超出 D1 前端自举清单；VM = 永久 Rust 基座[12 §2.5.1/INC7/r69 A 类]——「完全自举」VM 重写 = 宪制排除项）；D1 缺点 4「理论纯度不足」分层消解（VM = 效应语义物理基座非验证对象——90%/100% 缺口消解为非缺口）。
- **BS-B 三阶段对账**：Phase 1 ✅ 已达成并超越（含构建编排——D1 Phase 3 域提前达成）/ Phase 2 既有规划一致（QBE AOT PoC + TD-024——**本地码后端永不入自举链**）/ Phase 3 宪制排除（替代机制承接）——**D1 推荐策略 = kerf 既有路线的独立复核确认**（六维度八裁定 + 决策树三问全一致）。
- **BS-C 语法迁移验证（Stage 2b 切换窗前置设计登记）**：**D2 时态前提修正**（「已到达转换阶段」按 r70 判定式修正为「技术就绪[fixpoint + E5 v1.0.0 + 架构保证] + 治理待触发[match 消费信号 0 命中——红线 3]」——全部指导内容 = 开窗弹药库非本轮实施义务）+ SyntaxTransitionValidator = 既有 parity 纪律（B3 28 函数/E5 九腿/TD-032/HM 四段链）的结构化完备 + 映射表 = 皮肤字典单源（20/02 双锚）+ **三阶段构建 = 门 B fixpoint 传递性扩展**（A→B→C 链 B==C 字节级）+ 语义安全网分层（字节级限同语法链/跨语法 CoreExpr 全等）。
- **BS-D/BS-E/BS-F**：四陷阱全闭环零新增风险类（语义漂移三重防护/诊断 parity 先例/量化背书既有/可插拔蓝图）；八语言先例对账（Java = 最近大型同构 + Chez nanopass = 性能反例锚）+ **供应链安全承接 = 缩短信任链三机制**（可审计种子/parity oracle 链/fixpoint 确定性——全源自举 = 远期理论对照）；一致性八项零冲突 + **8 原语零触及**（历次最彻底纯工程轮——零语法零原语零 EBNF零新理论环）。
- **原则 53**「混合自举与迁移验证登记纪律」：第三形态/后端不入自举链/同结果硬纪律/两路径声明/零信号不开窗/三阶段 fixpoint 六项——五违反示例（VM 重写入计划/无信号开窗/parity 降格/未达 fixpoint 拆脚手架/未验证切生产）。
- **E.25 四文献**（四项 web-search 实检索证 r98-q1~q4 存档 tool-results/r98-search/）：Thompson 1984 *Reflections on Trusting Trust*（供应链安全奠基）/ Guix-Mes 全源自举（357 字节 hex0 链）/ Keep 2012 nanopass（Chez 自举高性能先例——性能反例锚）/ Yang et al. PLDI 2011 Csmith（等价性测试学术先例——parity 方法论对账）。
- **lang-design 八件修订**：**07 v6.9 §4（自举策略进程面承载本体——六小节）** + 02 v7.5 §8.12（语法迁移验证与映射表登记——**含 R4 顺修：v7.4 Version 头行 r96 漏更本轮补齐**）+ 11 v6.5 §6（parity 结构化完备与切换窗验证协议）+ 12 v6.26 §2.15（三阶段策略对账注记）+ 17 v7.14（原则 53 + 附十九——五面姊妹链外第一工程面条）+ 18 v7.18 §5t（术语二十条）+ 19 v7.10 §25（E.25 四文献 141-144）+ 00 v6.19——其余十七件零增量维持。
- **sop v13.15 反哺**：原则 53 入 §2.2 表 + §21.12 第 22 条 + §8.4.5 渐进式混合自举/语法迁移验证定位查询行 + 目录/标题/来源注五十二→五十三计数同步 + 变更日志 v13.15 行。
- **验证**：§3.2 六命令 clean 起步全绿（build --release 零告警 + check 0/0 + fmt --check 0 diff + clippy 零告警 + test **1114:0:0 逐位维持**[纯文档轮零增量——1114 基线第二轮 r97-r98]）+ 审计×6 全 EXIT 0 + CLI 三路径零回归（fib⇒144 / check ok / effect_stress⇒120）。
- **r98 包**：`kerf-v1.0.0-r98-hybrid-bootstrap-1114tests.tar.gz`（包内自举三验全绿：独立解包净构建 + 1114 复跑 + e5close 审计 + CLI fib 144）。
- 对账链：matrix r98 行 + [rec 60（03 层）](docs/worklog/03_stage-3_入场序列/60_r98_渐进式混合自举与语法迁移吸收轮.md) + t3plus v1.18 r98 消费注记 + 指南 v1.17 第十四例行权实录 + 层 l r98 条目 + sop v13.15 变更日志行。

## r97（v1.0.0-r97）——TD-031 M2 canonical ABI 适配层实施（用户 M1 指令开窗第八例）

- **用户驱动源**：双链指令「① 按照 docs/sop.md 流程结合 docs/lang-design/ 下文档集合推进项目演进流程 与 docs/develop/v0/tech-debt-register.md，docs/develop/v0/stage-3/t3plus-trigger-audit.md 按照推荐先后任务顺序继续推进 ② 同步完整打包项目 tar.gz 并同步完整更新 web page」——**M1 指令开窗第八例**（指南 §4 速查卡【第 3 位】TD-031 M2；行权链 r74/r79/r80/r86/r87/r90/r92/r97）。
- **推荐序裁定 + M2 判据实测回填**：第 1 位 #15 需 next17.md 未上传（next16.md 已 r96 全量消费）→ 第 2 位 TD-032 ✅ r90 / 第 4 位 HM ✅ r80 清偿 → **第 3 位 TD-031 M2 落位**；判据两腿 = M1 ✅ r92 + **边界类型消费 case ≥10 实测成立**（语料库 18 个 .krf：10 语料消费 str[check 50/compiler 50/expander 214/reader 91 行级命中]、9 语料消费 pair/list[expander 86/check 44/compiler 33]——行级命中 400+ ≫ 10；bootstrap 自举链全量依赖边界类型）。
- **净增量两件**：①`crates/kerf-backend/src/wasm_abi.rs`（canonical ABI 协议层——**CanonicalAbiOptions 三字段全消费**：`string_encoding` → UTF-8/UTF-16 **验证性**串编解码[非法 UTF-8 序列/奇数字节长度/孤立高/低代理/交错代理对均 AbiError fail-closed] + `memory64` → `AddressWidth` 地址域 + `realloc` → bump 协议锚[对齐表 log2→字节 + align_up + 默认名 + 页几何]）+ ②`wasm_emit.rs` 增量 + `tests/v0/stage3/plan/wasm_abi_tests.rs`（`emit_abi_module(data, abi)` 七节发射：Type/Function/Memory[flags 0x04 = memory64]/Global[堆指针——地址 0 保留 null 哨兵]/Export[memory + realloc 名锚]/Code/Data[active 段 offset 0 = str 跨界载荷面]；**realloc bump 函数**[(old_ptr, old_size, align, new_size) → new_ptr 四参协议——对齐 1<<align 向上取整 + block/loop 旧数据逐字节保留 + 堆单调前进 + i32/i64 双地址域单源操作码选择]；契约语义诚实兑现[realloc = None 省略四节/空 data 省略 Data 节/data > u32 fail-closed]）。
- **node 宿主 E2E**：**str 跨界 parity**（Rust 编码 → data 段 → node 经 `exports.memory.buffer` 读回 → hex 逐字节对账 → 解码回原串——UTF-8[ASCII/BMP/增补平面] / UTF-16[代理对族]双形）+ **realloc 协议**（首次分配 = 堆基址 / 扩容单调前进且 8 对齐 / 旧 5 字节逐字节保留 / 第三分配不重叠 / 零大小旧块仍前进）+ memory 导出面与页数几何（2 页/4 页跨页锚）+ 自定义 realloc 名导出。
- **三裁定**：**L-A′ M2 范围** = 协议层做实（语言面 str 字面量 lowering[ANF B1 扩界]不在 M2 范围——独立演进信号与 TD-024 Float 域同族；`string_literal_rejected_before_emit` 负例继续守护）；**L-B′ 零依赖沿袭**（std::str::from_utf8 + char::decode_utf16——§18 纪律）；**L-C′ memory64 字节级验证策略**（节走查断言 flags 0x04 + Global i64 + Type 四参全 i64 + Data offset i64.const——node 实例化支持版本依赖，诚实注记不宣称未验证能力）。
- **bump 诚实边界**：不做 `memory.grow`（初始余量耗尽即越界 trap——fail-closed）；旧块不回收（bump 单调——free 协议由宿主 GC 域承接）。
- **验证**：§3.2 六命令全绿（build --release 零告警 + check 0/0 + fmt --check 0 diff + clippy 零告警 + test **1114:0:0**[单元 277 + 集成 837——净 +23：单元 12 + 集成 11]）+ 审计×6 280 case EXIT 0 + CLI 三路径零回归（fib⇒144 / check ok / effect⇒120）。
- **TD-031 终态**：M0 契约层 ✅ r74 + M1 核心模块生成 ✅ r92 + **M2 canonical ABI 适配 ✅ r97**——M3 组件组合触发式维持（判据 = M2 交付 + 组件组合消费方[多组件系统需求]）。
- **r97 包**：`kerf-v1.0.0-r97-canonical-abi-1114tests.tar.gz`（包内自举三验全绿：独立解包净构建 + 1114 复跑 + e5close 审计 + CLI fib 144）。
- 对账链：matrix r97 行 + [rec 59（03 层）](docs/worklog/03_stage-3_入场序列/59_r97_TD-031M2canonicalABI适配层实施.md) + wasm-backend-component-model v1.2 §5.2 + 登记册 v0.4.12 + t3plus v1.17 + 指南 v1.16 + 层 l r97 条目。

## r96（v1.0.0-r96）——#15 讨论主线第十三次用户行权：效应容器类型系统与类型观测理论全量吸收（纯文档轮——五线程族完备）

- **用户驱动源**：五链指令「① next16.md 吸收进 stage0.md 直至完全收敛 ② 融入 lang-design 对应文件 + 系统性全面审查[十六维] ③ 反哺 stage0.md 二次整理 ④ 反哺 sop.md 适当位置 ⑤ 打包 + web」——第十三次 #15 目标语言设计讨论主线用户行权（行权链 r74/r79/r80/r81/r83/r84/r88/r89/r91/r93/r94/r95/r96）。
- **语料与对账**：next16.md（2800 行四文档全量新语料）——Doc1 类型系统完整设计（四大模型横切定位 + CoreType + 推断算法 + EBNF v1 + 实施路线 + vs Rust/Haskell/TS/Koka）/ Doc2 类型模型效应化自然演进（推导链五步 + 静/动双重本质 + 观测语义 + 「哥白尼革命」）/ Doc3 最终收敛版（EBNF v2 统一语法 + 流形约束求解算法 + 八项一致性验证 + 理论体系最终版 16 原创贡献）/ Doc4 可行性与四模型协同最终审查（六维评估 86% + 五接口精确契约 + 协同操作语义 + 风险分层缓解）。
- **漂移检测五项 + 实况修正**：①时态漂移 R4 沿袭（「现在可以开始 Stage 0」vs kerf Stage 3 T3+ 待触发态）②实施路线对账（hm.rs HM 已生产 r80 + 效应行收集既有——观测理论 = Stage 2+ 设计约束）③**接口 5 二义审理**（Doc1 类型↔类型自反 vs Doc4 类型↔能力 LinearType——裁定：模型间接口计数取五接口 + 自反不占数）④8 原语双层口径沿袭 ⑤完成度数字 K-H 档案口径。
- **TY-A 效应容器类型系统**：横切静态验证层——「验证者非执行者」+ CoreType 十一构造子（Function.returns=EffectUnion——Return 容器承接）+ Linearity 四级谱系（q3 锚：Rust=affine 泛化——linear 位由能力消耗承载）+ TypeInferencer 八臂（Perform 返回 Never+效应行追加 / Handle 差集消除——与效应行合一同构）。
- **TY-B 类型观测理论**：推导链五步（概率∩能力→叠加→函数=流区域→返回=切片观测→静/动统一）+ TypeNature 三形 + 观测维度代数（Static 四维=四模型各一 / Dynamic 四维=四前沿）+ q1 锚（Siek&Taha 渐进类型相邻先例弱锚——「何时检查」vs「类型是什么」分辨）+ 「哥白尼革命」叙事层定位 K-H 沿袭。
- **TY-C 流形约束求解**：argmin 数学形式 + q4 锚（HM[X] 约束域扩展叙事**非新数学**——生成/求解分离结构对应）+ ManifoldTypeInferencer 五步六约束类 + InferenceStrategy 四形（**安全域恒 Static fail-closed**——r94 裁定四策略推广）+ 流形求解器 = Stage 2+ pass 候选（MU-B 单源纪律适用）。
- **TY-D EBNF v8 第七份骨架**：unified_type 四形（static/dynamic{superpose/refine/evolving}/progressive/hybrid）+ manifold_constraints 四形 + trait 四成员 + **历次最大关键字张力轮 ~12+ 两域分层门控 + 宏层脱糖备选** + 二义性预防第 15-17 例 + 零环境通道纯注记层。
- **TY-E 四模型协同最终化**：**五接口零漂移确认**（与 r94 21 号件 §11.2 逐项同构——本轮=契约化深化）+ **接口计数纪律**（自反不占数 + 类型↔生命周期经效应中介传递——6 边取 5 直连）+ 职责矩阵十二行（+2 类型行）+ 协同七步骤零新机制 + CompilerPipeline 七阶段 MU-E 同构 + 渐进式理论应用 = 接口预留完整性同构。
- **TY-F 一致性验证与第十环**：八验证 = 既有理论实例化（⑤波粒↔静/动投影为表述增益）+ **8 原语不变性第八轮验证零新原语** + TypeSystemSpace 归位类型域（空间单源第八轮）+ **理论载体第十环成立——五线程族完备**（效应七环+能力+生命周期+分析+类型）+ 原创贡献 16/17 两项新登记 + 三口号叙事层（一切皆效应/分析投影/观测——机制/分析/观测三视角互补）+ q2 锚（Koka 行多态成熟路径确认）。
- **原则 52**「类型观测化登记纪律」：五违反示例（观测理论提前实现化 / 叙事层越位 / superposition 量子语法越窗 / 类型系统运行时原语 / 接口越限）。
- **E.24 四文献**（四项 web-search 实检索证 r96-q1~q4 存档 tool-results/r96-search/）：Siek&Taha 2006 渐进类型（引 257+）/ Koka 行多态效应行 Leijen 2014（引 256+）/ Rust affine 社区认辨多源 / HM[X] Sulzmann 约束式推断。
- **lang-design 九件修订**：**13 v6.20 §3.18（效应容器类型系统能力面）** + **21 v2.1 §11.2（五接口契约化深化注记——多模型组织协调维度承载本体）** + 24 v2.9 §21（TypeSystemSpace 归位）+ 17 v7.13（原则 52 + 附十八——五条姊妹链）+ 18 v7.17 §5s + 19 v7.9 §24 + 02 v7.4 §8.11（EBNF v8）+ 12 v6.25 §2.14 + 00 v6.18。
- **sop v13.14 反哺**：原则 52 入 §2.2 表 + §21.12 第 21 条「类型观测化登记纪律」+ §8.4.5 类型观测/效应容器类型系统定位查询行 + 目录/标题/来源注五十一→五十二计数修正。
- **验证**：§3.2 六命令 clean 起步全绿（build --release 零告警 + check 0/0 + fmt --check 0 diff + clippy 零告警 + test **1091:0:0 逐位维持**[826 runner + 265 单元——纯文档轮零增量；基线连续五轮 r92-r96]）+ 审计×6 280 case EXIT 0 + CLI 三路径零回归。
- **理论载体第十环 + 五线程族完备**：容器三部曲 → 流形 → 逆向对偶 → 波粒二象性 → 能力内禀几何 → 生命周期效应化 → 分析统一场论 → **类型观测化**（四模型线程 + 分析收束线程全齐——「四大模型通过观测统一」）。
- **r96 包**：`kerf-v1.0.0-r96-type-observation-1091tests.tar.gz`（包内自举三验全绿：独立解包净构建 + 1091 复跑 + e5close 审计 + CLI fib 144）。
- 对账链：matrix r96 行 + [rec 58（03 层）](docs/worklog/03_stage-3_入场序列/58_r96_类型观测吸收轮.md) + stage0 v8.2 + 17 v7.13 原则 52 + sop v13.14 + 层 l r96 条目 + t3plus v1.16 + 指南 v1.15。
- 十六维审查：P0/P1 = 零；P2 三项（关键字张力历次最大[两域门控+脱糖备选] / 接口 5 二义[计数裁定消解] / superposition 概率语法[Stage 3+ 档案]）。

## r95（v1.0.0-r95）——#15 讨论主线第十二次用户行权：流形统一分析与统一场论全量吸收（纯文档轮——历次最轻量）

- **用户驱动源**：五链指令「① next15.md 吸收进 stage0.md 直至完全收敛 ② 融入 lang-design 对应文件 + 系统性全面审查[十六维矩阵] ③ 反哺 stage0.md 二次整理 ④ 反哺 sop.md 适当位置 + 打包 + web」
- **语料与对账**：next15.md（1995 行四文档——Documents 1-3[行 1-1571] 已于 r94/v8.0 吸收零遗漏；本轮唯一新增量 = **Document 4「流形统一分析」行 1573-1995 +424 行**——同文件名追加段按语料实质判定[r89 先例沿袭]：六大优势深度展开 + 隐藏优势四项 + 挑战诚实分析四项 + 统一流形分析中心架构图 + 总结）
- **漂移检测三项 + 实况修正**：①时态漂移（「你的编译器统一流形分析」现在时 vs kerf Stage 0 实况 → Stage 3+ 愿景层档案）②零丢失精确化（表示层真[共享底层零转换] / 分析层投影必有损[切片即丢弃维度]）③先例对账（Kildall 1973 框架级统一为先例弱锚——流形级统一无工业先例，kerf 特有理论叙事）
- **MU-A 流形统一分析理论**：分析的统一场论——所有分析（类型/借用/能力/优化/并发/调试/生命周期）= **同一效应流形上的投影/切片**；十优势对账（六大显性 + 四隐藏——六项为既有登记架构级重述 + 四项[优化推理/调试视图/形式化验证/AI-ML 接口]须分级处理）；统一场论 = **解释框架层第九环** + 「架构革命」叙事层定位
- **MU-B Pass 数据结构单源纪律**：Pass = 流形变换函数——组合 = 函数复合 + 正确性独立验证 + 顺序灵活；**三级单源体系**（IR 单源[CoreExpr] + 分析单源[流形对象] + Pass 变换纪律——任何分析 Pass 不得引入自有中间表示）；与 r91 K-F 五 Pass 分立全景同构确认——Stage 2+ 优化窗设计约束即刻生效
- **MU-C 八项映射表 K-A 分级复验**：连通分量→并行化[Tier 1 图算法精确同构] + H₀/H₁/欧拉/联络[Tier 2 离散化对应或叙事级] + 曲率/外微分/Stokes[Tier 3 叙事维持]——**零越级升格**；H₀/H₁ 同调语言 = 图算法数学上溯表述（表述增益：不变量视角 + 代数拓扑工具链接入）
- **MU-D 挑战四项与缓解**：实现复杂度→K-F 渐进分层重述 / 性能开销→LC-F 缓解族叠加（近似 + 分级两新策略——性能域不违 fail-closed）/ 学习曲线→原则 43 同构（语言用户零数学门槛——数学背景限核心团队）/ 工具链兼容→后端宪法零冲突 + **ANF-SSA 实况修正第三例**（流形→ANF-SSA 桥接归 kerf 自有管线 + 目标面可选件不入自举链）——**零新增风险类**
- **MU-E 统一流形分析中心愿景档案**：Stage 3+ 愿景层（前端→中心[流形构建 + 分析引擎 + 六分析 + 流形变换]→后端）；**六分析 = 既有理论投影重述零新分析类**（类型投影↔EffectRow / 干涉↔借用 / 拓扑↔三连接 / 生命周期↔LC-B / 曲率↔干涉交换子 / 同调↔H₁ 循环）；Stage 0 雏形对账（效应行 + E0006 = 分析①②雏形——已交付）
- **MU-F 一致性验证与第九环**：**8 原语不变性第七轮验证——历次最轻量吸收轮（零语法零原语零 EBNF——EBNF v7 六份骨架存量维持）** + 空间归位（EffectSpace 分析面视图——ManifoldAnalysisSpace 平行空间违例登记）+ AI/ML Level 5 远见（MLGO 工业锚 + GNN-on-manifold 特有愿景无先例）+ **理论载体第九环成立**（…→生命周期效应化→分析统一场论——分析架构面收束）+ 原创贡献 15 新登记
- **原则 51**「流形统一分析登记纪律」：五违反示例（流形分析中心提前实现化 / 分析 Pass 引入自有中间表示 / 微分几何工具未经 K-A 分级直称精确同构 / 「架构革命」作实现宣称 / GNN-on-manifold 列入近期路线图）
- **E.23 四文献**（四项 web-search 实检索证 r95-q1~q4 存档 tool-results/r95-search/）：Kildall 1973 统一分析框架先例（E.23-133——框架级 vs 流形级分辨）/ 并发拓扑分析前沿（E.23-134——persistent homology Myers 2019 引 150+ + 奇点理论 arXiv 2025）/ MLGO 工业 ML-编译器（E.23-135——ML 入管线可行 + GNN-on-manifold 无先例确认）/ CompCert 形式化基准（E.23-136——逐 pass 验证 vs 单一理论全分析愿景分辨）
- **lang-design 九件修订**：**15 v6.4 §5.4（统一流形分析中心愿景与分析单源——架构分层承载本体）** + 13 v6.19 §3.17（流形统一分析能力面）+ 24 v2.8 §20（EffectSpace 分析面视图）+ 17 v7.12（原则 51 + 附十七——四条理论登记纪律姊妹链闭合[效应×能力×生命周期×分析]）+ 18 v7.16 §5r（术语二十一条）+ 19 v7.8 §23（E.23 四文献）+ 08 v6.7 §5.5（流形→ANF-SSA 桥接注记）+ 12 v6.24 §2.13（Stage 3+ 愿景注记）+ 00 v6.17；十六件零增量维持
- **sop v13.13 反哺**：原则 51 入 §2.2 表 + §21.12 第 20 条「流形统一分析登记纪律」+ §8.4.5 流形统一分析/统一场论定位查询行 + 目录/标题/来源注五十→五十一计数同步 + **R4 顺修一处**（来源注「第 50 条」条目 r94 漏更——本轮发现当轮补齐）+ 变更日志 v13.13 行
- **验证**：§3.2 六命令 clean 起步全绿（build --release 零告警 + check 0/0 + fmt --check 0 diff + clippy 零告警 + test **1091:0:0 逐位维持**[826 runner + 265 单元——纯文档轮零增量；基线连续四轮 r92-r95]）+ 审计×6 280 case EXIT 0 + CLI 三路径零回归（fib 144 / check ok / effect_stress 120）
- **理论载体第九环成立**：三部曲 → 流形 → 逆向对偶 → 波粒二象性 → 能力内禀几何 → 生命周期效应化 → **分析统一场论**——分析架构面收束（流形从效应理论载体升格为分析架构统一原理——原创贡献 15）
- **r95 包**：`kerf-v1.0.0-r95-manifold-unification-1091tests.tar.gz`（包内自举三验全绿：独立解包净构建 + 1091 复跑 + e5close 审计 + CLI fib 144）
- 对账链：matrix r95 行 + [rec 57（03 层）](docs/worklog/03_stage-3_入场序列/57_r95_流形统一分析吸收轮.md) + stage0 v8.1 + 17 v7.12 原则 51 + sop v13.13 + t3plus v1.15 + 指南 v1.14
- 十六维审查：P0/P1 = 零；P2 三项（「架构革命」时态张力[愿景层档案裁定] / AI-ML 前沿宣称强度[Level 5 远见 + 检索证差异化锚] / 同调 O(n³) 工程可行性[近似拓扑 Stage 3 研究项 + 分级可选裁定]——均有裁定）

---

## r94（v1.0.0-r94）——#15 讨论主线第十一次用户行权：生命周期效应化与四模型协同全量吸收（纯文档轮）

- **用户驱动源**：五链指令「① next15.md 吸收进 stage0.md 直至完全收敛 ② 融入 lang-design 对应文件 + 系统性全面审查[十六维矩阵] ③ 反哺 stage0.md 二次整理 ④ 反哺 sop.md 适当位置 ⑤ 同步完整打包 tar.gz + 同步完整更新 web page」——**#15 目标语言设计讨论主线第十一次用户行权**（行权链第十一例：r74/r79/r80/r81/r83/r84/r88/r89/r91/r93/r94——生命周期线程开面轮·理论载体第八环）
- **语料与对账**：next15.md（1571 行三文档：①生命周期效应化统一 ②最终收敛版[EBNF + Pass 算法 + 七项一致性验证] ③编译器完整可行性分析与四模型协同审查）——漂移检测四项实况修正：Stage 0 时态漂移（语料「现在可以开始 Stage 0」vs kerf 实况已交付——上游时态档案口径 R4）/ QBE-LLVM 表面冲突（目标面可选件 vs 自举链成员资格分立——项目一行「LLVM 永不入自举链」零冲突维持）/ 8 原语双层口径（理论基座 8 + 结构臂 2 = 现行 9——r67 对账沿袭）/ 自评数字档案口径（K-H 先例）
- **LC-A 生命周期效应化理论**：生命周期 = **资源的时间效应**——ResourceLifecycle 四操作（acquire/use/release/transfer）全 Perform 使用模式（**8 原语不变性第六轮验证——零新原语**）+ with_resource 作用域 = Handle 语义（Return/Error 双臂 RAII 释放）+ 借用 = 效应组合（immutable 可复制非线性/mutable 线性 use-once）+ 冲突检测 = 效应干涉分析（三处置策略 handler 外置）——Rust 对比八维度（机制归属/概念/学习曲线/复杂度/错误信息/开销/表达能力/扩展性）
- **LC-B 编译期验证与 Pass 算法**：Koka 效应消除迁移——三 Stage 管线（效应分析→干涉分析[借用检查]→效应消除[优化]）+ LifecycleAnalysisPass 五 Phase 完整算法（收集→构建 EffectFlow→验证规则三[Acquire 前置/悬垂引用/线性流]→借用干涉→消除优化）+ **消除三形**（FullElimination 简单作用域零开销/PartialElimination 静态借用/Optimized 动态可约化）——Stage 2+ 优化窗 pass 候选（零信号不开窗）
- **LC-C EBNF v7 第六份骨架**：resource_decl（四操作产生式）+ borrow_decl（三操作）+ with_resource_stmt + lifetime_annotation（七约束：acquire_before/release_after/exclusive/shared/no_overlap/must_overlap/linear_flow）+ lifetime_analysis（四查询）——`body=block` 非标准记法归档修正（W3C 纪律）+ ~7 关键字宏层脱糖备选（with→with_resource 函数糖/@lifetime→LifecycleConstraint 效应糖/analyze→工具链指令）+ **零环境通道增量**（纯糖层）
- **LC-D 一致性七项验证与第八环**：七验证全过（8 原语第六轮/空间归位[ResourceLifecycleEffect+BorrowEffect → EffectSpace Level 2 登记态子空间——同 K-E/§18 先例第六例]/资源能力族/流形三连接覆盖/资源侧二象性/正逆对偶资源域实例/耦合资源域投影）+ 理论体系最终版对账（数学基础七层/核心六支柱/统一关系四行）+ **原创贡献 13/14 两项新登记**（生命周期=效应[资源管理统一]/借用=干涉分析[生命周期检查统一]）+「一切皆效应」降格理论叙事层（K-H 时点档案口径）
- **LC-E 四模型协同关系**：六协同关系（效应↔类型/效应↔能力/效应↔生命周期/能力↔生命周期/类型↔能力/类型↔生命周期——各五行：接口/职责/协同方式/边界）+ 职责矩阵十行（✅核心/⚠️参与/❌不参与）+ **接口契约五形**（每形三元组[数据流方向/传输内容/时机]——EffectRow 注解/Perform requires Capability/LifecycleEffect 模式/ResourceCap 门控/linear 标注——**唯一接触面纪律多模型推广**：r93 双模型 → 四模型五接触面）+ 双口径注记裁定（「四模型」= 协作面视角；生命周期非平级模型——效应的应用）
- **LC-F 可行性与风险登记**：四维度评估（理论 99%/工程 85%/性能[与 §6.13.3 双轨口径一致]/生态——总体 88% 档案口径）+ 风险六项 + **效应分析管线单点性**详细分析（五下游依赖——缓解三策略：分层实现/多级缓存/保守-乐观双模式）+ **安全底线裁定：乐观仅限性能优化域，安全域[能力门控/E0006]恒保守 fail-closed** + 实施路线图时态对账（上游时态档案 vs kerf 实况 R4）
- **E.22 四文献**（四项 web-search 实检索证 r94-q1~q4 存档 tool-results/r94-search/）：RFC 2094 NLL/Polonius（E.22-129——Rust 借用检查器工程复杂度锚）+ **Tofte-Talpin 区域效应系统**（E.22-130——「生命周期=效应」的 1997 学术同构先例[本轮最大发现——早于语料 30 年的同一洞察]）+ Koka 效应处理器编译（E.22-131——消除迁移技术源锚）+ RAII 多源（E.22-132——with_resource RAII 语义对照面）
- **lang-design 十一件修订**：13 v6.18 §3.16（生命周期效应化能力面——8 原语第六轮验证）+ **21 v2.0 §11（资源能力族与四模型协同——多模型组织协调维度承载本体）**+ 24 v2.7 §19（EffectSpace Level 2 登记态子空间第六例 + 六登记态子空间全景）+ 02 v7.3 §8.10（EBNF v7 + 二义性预防第 13-14 例）+ 05 v6.10 §12（with_resource Handle 四臂语义运行时面）+ **09 v6.15 §7（生命周期线程开面——ResourceLifecycle/Borrow/LifecycleConstraint std 候选[三线程族完备：r91 效应线程 + r93 能力线程 + r94 生命周期线程]）**+ 17 v7.11（原则 50 + 附十六）+ 18 v7.15 §5q（术语二十条）+ 22 v2.12 §25（关键字张力脱糖备选）+ 19 v7.7 §22（E.22 四文献）+ 00 v6.16；其余十四件零增量维持
- **sop v13.12 反哺**：原则 50 入 §2.2 表 + §21.12 第 19 条「生命周期效应化登记纪律」+ §8.4.5 生命周期效应化/四模型协同定位查询行 + 目录/标题/来源注四十九→五十计数修正 + 变更日志 v13.12 行
- **验证**：§3.2 六命令 clean 起步全绿（build --release 零告警 + check 0/0 + fmt --check 0 diff + clippy 零告警 + test **1091:0:0 逐位维持**[826 runner + 265 单元——纯文档轮零增量]）+ 审计×6 280 case EXIT 0 + CLI 三路径零回归
- **理论载体第八环成立**：三部曲 → 流形 → 逆向对偶 → 波粒二象性 → 能力内禀几何 → **生命周期效应化**——资源时间维补全（生命周期线程开面）；切换窗六步前置清单维持未开窗（#15 讨论先行持续）
- **r94 包**：`kerf-v1.0.0-r94-lifecycle-effect-1091tests.tar.gz`（包内自举三验全绿：独立解包净构建 + 1091 复跑 + e5close 审计 + CLI fib 144）
- 对账链：matrix r94 行 + [rec 56（03 层）](docs/worklog/03_stage-3_入场序列/56_r94_生命周期效应化吸收轮.md) + stage0 v8.0 + 17 v7.11 原则 50 + sop v13.12 + t3plus v1.14 + 指南 v1.13 + download README r94 节

---

## r93（v1.0.0-r93）——#15 讨论主线第十次用户行权：能力模型内禀几何全量吸收（纯文档轮）

- **用户驱动源**：五链指令「① next14.md 吸收进 stage0.md 直至完全收敛 ② 融入 lang-design 对应文件 + 系统性全面审查[十六维矩阵] ③ 反哺 stage0.md 二次整理 ④ 反哺 sop.md 适当位置 ⑤ 同步完整打包 tar.gz + 同步完整更新 web page」——**#15 目标语言设计讨论主线第十次用户行权**（行权链第十例：r74/r79/r80/r81/r83/r84/r88/r89/r91/r93——能力模型深潜轮·理论载体第七环）
- **吸收主体**：stage0.md v7.8→**v7.9**（§9.21 八小节）——**CAP-A 三支柱统一体与空间归位**（线性类型[编译期安全——Rust 仿射/Austral 纯线性] × OCap[运行时安全——三公理；与 r92 Wasm M1 实装对账] × 能力效应融合[Unison abilities]——kerf 定位 = 最小自举统一体；CapabilitySpace Level 2 平行提议 → 理论坐标系保留 + 实施面核心七域单源；七维度 = 九动词投影双视角）
- **CAP-B 八维度正交分解**：效应/能力双模型各八维（定义/性质/能力/职责/控制/协同/变化/边界）精确数学定义——**HOW vs WHETHER 正交判据**（Effect.R2 投影选择 vs Capability.R2 门卫验证分立）+ 协同接口**唯一接触面** `Perform(e) requires Capability(e)`——**kerf E0006 既有实证理论完备化**（r25 io 门控起生产——理论完备化实现/实现锚定理论双向确认）
- **CAP-C 内禀关系**：**计算广义相对论 = 解释框架层**（效应 = 概率空间上的流/能力 = 度规——`dE² = C_μν dE^μ dE^ν` + 三层内禀方程[能力约束效应/效应改变能力/自洽耦合演化] + **14 操作完备集**{基础三[控制/限制/携带] + 高级十一[放大/变化/塌缩/聚合/分形/层级/嵌套/循环/衍生/干涉/湮灭]} + 能力侧波粒对偶 CapabilityNature 三态）——度规/联络/曲率依原则 48 K-A ②离散化对应物登记（描述转换非机制新增）
- **CAP-D EBNF v6 第五份骨架**：capability_decl 四成员（state/operation/metric/derivation）+ 使用/效应操作/耦合演化语法族 + **15+ 关键字张力 → 宏层糖脱糖备选**（E0020 名空间经济判据——不入语言首批形态）+ 环境五元组 ⟨e,ρ,σ,κ,C⟩（运行期 C 通道/编译期退化四元组——通道分立）+ 四规则族含 COUPLED-EVOLUTION 收敛 `‖Cₙ₊₁-Cₙ‖ < ε`
- **CAP-E 可行性与四层次协同**：线性类型三方案（Stage 0-1 C → Stage 2+ B → Stage 3+ 评估 A——脚手架哲学同构）+ 度规开销三策略（编译期解析 70% 零开销/缓存 20% O(1)/消除优化 10%——平均 <5%）+ Lotka-Volterra 收敛三机制（强制收敛+fallback/阻尼 λ/安全锥 δ——收敛性证明 = 数学难题登记[E.21-127 Tahara 锚]）+ **四层次协同谱系**（门控[编译期零开销——**kerf Stage 0 已交付 ✅**]/调制/演化/耦合[Stage 3+ 前沿]——层次 2-4 触发式远窗）
- **8 原语不变性第五轮验证**：全部 14 能力操作 = Perform/Handle 使用模式——**零新原语**；**原则 49**「能力-效应正交与内禀关系登记纪律」（五违反示例）
- **E.21 四文献**（四项 web-search 实检索证 r93-q1~q4 存档 tool-results/r93-search/）：Austral 线性（E.21-125 Borretti 2022）+ Unison abilities（E.21-126 官方文档）+ Tahara LV 收敛（E.21-127 PMC cited-by-92）+ OCap 多源（E.21-128 Wikipedia/tersesystems/ACIG——tersesystems 为语料直接引用源）
- **lang-design 十一件修订**：21 v1.9 §10（能力架构承载本体）+ 13 v6.17 §3.15（协同接口效应侧）+ 24 v2.6 §18（CapabilitySpace 归位）+ 05 v6.9 §11（运行时通道）+ **09 v6.14 §6（能力线程首次开面——io 能力族四层次对账）**+ 19 v7.6 §21 + 17 v7.10（原则 49）+ 18 v7.14 §5p（术语二十条）+ 22 v2.11 §24（关键字张力脱糖备选）+ 02 v7.2 §8.9（EBNF v6 + 二义性预防第 11-12 例）+ 00 v6.15；其余十四件零增量维持
- **sop v13.11 反哺**：原则 49 入 §2.2 表 + §21.12 第 18 条 + §8.4.5 能力模型三支柱/内禀关系定位查询行 + 目录/标题/来源注四十八→四十九计数 + 变更日志 v13.11 行
- **验证**：§3.2 六命令 clean 起步全绿（cargo clean 725 files → build --release **16.78s 零告警** → check 0/0 → fmt --check 0 diff → clippy --workspace --all-targets 零告警 → test **1091:0:0 逐位维持**[826 runner + 265 单元]）+ 审计×6 280 case EXIT 0（stage0/stage1/stage2-r1/stage2-r2/e5close/m3 全 PASS）+ CLI 三路径零回归（run fib 144 / check ok / run effect 120）
- **理论载体第七环成立**：三部曲 → 流形 → 逆向对偶 → 波粒二象性 → **能力内禀几何（计算 GR）**——效应线程与能力线程在第七环交汇；切换窗六步前置清单维持未开窗（#15 讨论先行持续）
- **r93 包**：`kerf-v1.0.0-r93-capability-intrinsic-1091tests.tar.gz`（**413 条目 / 3,934,419 字节 / 模式位 755×3**——包内自举三验全绿：独立解包净构建 16.06s + 1091 复跑 workspace 全量 + e5close 审计 E5 出口三条件全绿 + CLI fib 144）
- 对账链：matrix r93 行 + [rec 55（03 层）](docs/worklog/03_stage-3_入场序列/55_r93_能力模型内禀几何吸收轮.md) + stage0 v7.9 + 17 v7.10 原则 49 + sop v13.11 + download README r93 节

---

## r92（v1.0.0-r92）——TD-031 M1 核心模块生成实施轮：WASM 发射器 + trait 首实作## r92（v1.0.0-r92）——TD-031 M1 核心模块生成实施轮：WASM 发射器 + trait 首实作 + node 宿主 E2E parity（#16 WasmBackend 续窗·M1 指令开窗第七例——**TD-031 M1 清偿**）

- **用户驱动源**：双链指令「① 按照 docs/sop.md 流程结合 docs/lang-design/ 下的项目演进流程 与 docs/develop/v0/tech-debt-register.md，docs/develop/v0/stage-3/t3plus-trigger-audit.md 按照推荐先后任务顺序继续推进 ② 同步完整打包项目 tar.gz 并同步完整更新 web page」——任务① = **M1 指令开窗第七例**（[t3plus-manual-trigger-guide §4 速查卡【第 3 位】](docs/develop/v0/stage-3/t3plus-manual-trigger-guide.md) TD-031 M1——「按照推荐先后任务顺序继续推进」指定方向行权：第 1 位 #15 需 next14.md 未上传[upload/ 实测无新语料] → 推荐序自然落到第 3 位 TD-031[第 2 位 TD-032 ✅ r90 清偿 + 第 4 位 HM ✅ r80 清偿]；行权链第七例：r74 四窗 / r79 / r80 / r86 / r87 / r90 / **r92**）
- **开窗判据回填表**（[wasm-backend-component-model §5](docs/develop/v0/stage-3/wasm-backend-component-model.md) v1.1）：①组件消费方出现 = **用户 M1 指令 = 需求信号本体**（r74 先例锚）+ **node 宿主实体化消费验证**（WebAssembly.validate + 实例化 + `main()` 调用——宿主运行时/嵌入方角色实体）；②QBE 后端边界扩展经验回填 = **B1 共享拒绝面负例回填**（`lower_program` 同一拒绝面——Float/Str/闭包值位/assign 四负例即经验回填）；③**WASM GC 类型裁定（L-A）= M1 核心模块 = 线性类型域（i64 值域 + locals + 栈机指令），GC 堆类型维持边界外**（M0「堆内表示属核心模块内部」+ 组件边界「序对/GC 堆对象/效应续延不经边界投影」同口径——红线 3 零信号不引入）
- **§18 依赖审查裁定（L-B）**：**自写字节码发射器**（零 cargo 依赖——纯 Rust LEB128/节区/指令发射；无 wasm-tools/wasmparser）；**node = 宿主侧测试期验证工具**（`KERF_NODE` 查找链 → PATH 探测 → 缺失显式失败 §3.1——同 qbe/cc 先例：外部宿主工具非构建依赖）
- **实施净增量两件**：①`crates/kerf-backend/src/wasm_emit.rs`（**自写字节码发射器**——[LEB128 无符号/有符号编码 + 节区框架] + `emit_core_module`：magic/版本头 + Type 节[签名去重保序] + Function 节 + Export 节[main = 函数索引 0，QBE PoC 同口径] + Code 节[逐函数 locals + 指令] + **`kerf_meta` 清单自定义节**[CoreModuleFunc 名/形参数/块数——回读对账锚]；**确定性**：同 ANF → 同字节——全结构定序，无哈希迭代序入产物] + **CFG→结构化控制递归区域分解**（`emit_region`——值菱形[Br + 双 Jmp 臂 + 单 phi merge] → `if (result i64)` 双臂留值 + `local.set` phi dst；尾位 if[Br + 双 Ret 臂] → `if (void)` 双臂 return + **函数级 `unreachable` 垫底**[双臂 return 后 `end` 复位可达态——验证器合法形态，控制事实上永不落穿语义零变更]；**结构不变式逐项 fail-closed**：Br.then≠下一块 / Jmp 在 Return 区域 / Ret 非区域末块 / 值臂尾形 Br / merge 越界 / phi 缺来源 / 重名 / 空名）+ **原语映射**（Add/Sub/Mul → i64.add/sub/mul；Div/Mod → i64.div_s/rem_s[VM 截断除/余符号对齐]；六比较族 → i64.eq/lt_s/gt_s/le_s/ge_s + extend_i32_u；not → i64.eqz；Call → call funcidx[名字表索引解析 fail-closed]；**真值性**：条件 = `i64.eqz + i32.eqz` 双取反[非 wrap 降宽——全宽非零即真]；ATemp 编号即 local 索引[anf.rs LowerCtxt 编号不变式]）+ **`WasmCoreBackend` = WasmBackend trait 首个做实实现**（`compile_component → { bytes: emit_core_module, model: component_model_from_anf }`——原则 27：trait 签名零变化；`bytes` 语义自 r74 契约注释「M1 字节码生成的载荷」兑现）+ `parse_core_module_manifest` 清单回读（节区走查 + `kerf_meta` 解码——**发射↔契约层双向 parity**：`parse(emit(ir)) == component_model_from_anf(ir).core_funcs` + 单源断裂守护）+ 单元测试 8）+ ②`tests/v0/stage3/plan/wasm_backend_tests.rs`（集成 28：**node 宿主 E2E parity** 15 语料族[fib 12→144 / fib 20→6765 深递归 / 算术 / 嵌套菱形 / 尾位 if / 尾位嵌套 / let 链 / not / 六比较族全扫 / div-mod 负数 / 互递归前向引用 / 多形参 / 空程序→0 / i64::MAX 字面量 / **i64 全宽真值边界 2^32·2^33·-2^32·0·-1**] + 清单回读对账双形 + 确定性跨编译链 + trait 信封端到端 + **三侧条件宽度边界**[VM 显式 bool E0004 / ANF 宽口 / WASM 非零即真——合法程序条件值恒 ∈ {0,1} 三侧一致] + B1 共享边界负例四形 + 回读 fail-closed 三形——runner 树挂载）
- **验证器两缺陷修复实录**（实施期 node E2E 检出即修——GATE 1 实跑价值实证）：①Br 臂漏发块内语句（cond 计算绑定丢弃——`(if (< 1 2) 10 20)` WASM 侧误取 else 臂实测检出）；②尾位 if 双臂 return 后函数级 `end` 的 i64 要求落空（node INVALID WASM 检出 → `unreachable` 垫底解）
- **验证**：§3.2 六命令全绿（build --release 零告警 + check 0/0 + fmt --check 0 diff + clippy --workspace --all-targets --release -D warnings 0 + **test --release --workspace 1091:0:0**[798 + 28 runner + 257 + 8 单元——净 +36]）+ 六审计集 280 case EXIT 0 ×6 + CLI 三路径（run fib 75025/⇒144 + check 含缓存观测文本 + test——零回归）
- **TD-031 终态**：M0 契约层 ✅ r74 + **M1 核心模块生成 ✅ r92**——M2 canonical ABI 适配[触发判据 = M1 交付 + 边界类型消费 case ≥10——str/list 跨界语料信号] + M3 组件组合[触发判据 = M2 交付 + 多组件系统需求]触发式维持（登记册 v0.4.11 + wasm-model v1.1 + t3plus v1.13 + 指南 v1.12 + 08 v6.6 + 13 v6.16 六件对账）
- **T3+ 触发族 14 行判定零变化**（本轮开外源窗 #16 续窗首例非 T3+ 行；#15 切换窗维持未开窗——next14.md 未上传 + 信号零命中）
- **r92 包**：kerf-v1.0.0-r92-wasmm1-1091tests.tar.gz（包内自举三验全绿：净构建 + 1091 复跑 + e5close + fib 75025/⇒144）
- 对账链：matrix r92 行 + 本节 + rec 54（03 层）+ t3plus v1.13 r92 注记 + 指南 v1.12 + 层 l 双更新 + 外根第三链镜像 + web r92 节点

## r91（v1.0.0-r91）——第十九轮数学工具箱与波粒二象性吸收轮：工具箱分级 + 波粒第六环 + EBNF v5 + 理论-实现映射（#15 讨论主线第九次行权·新语料全量形态）

- **用户驱动源**：五链指令「① next13.md 文件中的相关讨论的设计和理念与原则、演进进程等内容吸收并融入到 docs/stage0.md 中直至完全收敛 ② 融入 docs/lang-design/ 对应文件 + 系统性全面审查（性质/边界/能力/职责/数学性质/前沿概念/正交分解/二义性/文献完整性/数学逻辑支撑/引用可靠性等）③ 反哺 stage0.md 二次整理 ④ 反哺 sop.md 适当位置 ⑤ 同步完整打包 tar.gz + 完整更新 web page」——**#15 目标语言设计讨论主线第九次用户行权**（[t3plus-manual-trigger-guide §4 速查卡【第 1 位】](docs/develop/v0/stage-3/t3plus-manual-trigger-guide.md)——next13.md 1856 行四段上传即行权条件达成；行权链第九例：r74/r79/r80/r81/r83/r84/r88/r89/**r91**）
- **语料主线**：数学流形工具箱全量复用主张（「真实数学同构/实例化数学」+ 映射表十六对 + ManifoldAnalysisPass 五决策）+ 高维维度谱系（0/1/2/3/N/∞ 维 + EffectField）+ **波粒二象性**（用户理论 v6：粒子性/波动性/EffectNature 三态 + Perform=坍缩/Handle=弥散）+ 量子场论映射九对与路径积分计算版 + 效应纠缠与贝尔不等式计算版 + **理论-实现分层映射收敛**（五层理论 vs 四阶段实现 + 8 原语不变性验证表）+ **EBNF v5 分层语料**（Level 0-4 含拓扑/量子语法族）+ QuantumEffectSpace + 九步推演链方法论审查（「不是空中楼阁」终判）
- **吸收主体**：stage0.md v7.7→**v7.8**（§9.20 八小节——对账修正表八行[R4 口径] + **K-A 数学工具箱三级分级裁定**[①组合拓扑工具在离散 EffectGraph 上精确同构可用——E.20-124 持久同调锚；②微分几何工具 = 离散化对应物登记——E.20-123 Hirani DEC 锚；③量子结构 = 隐喻维持——「实例化数学」降格三级形态] + 维度谱系六阶[2 维 fork/join = 正逆对偶平面展开——R4 降格「∞ 维 = 高基数连续近似」] + **波粒二象性 = 解释框架层第六环**[K-C——Perform=坍缩/Handle=弥散为描述转换非机制新增；8 原语闭合**第四轮验证**；EffectUncertainty 两形态] + 路径积分[枚举语义——与 r89 交换子差分语义互补]与效应纠缠[K-B **贝尔不等式诊断性裁定**——经典关联必然 ≤ 经典上限，`QuantumAdvantage::Present` 不可达分支 = 守卫代码形态非能力宣称] + **理论-实现分层映射 K-F 采纳**[五层理论 vs 四阶段实现 = 理论登记默认层级视图；**五 Pass 分立全景首次成型**——A 基础优化/B 流形/C 拓扑/D 量子 + r89 干涉坍缩] + **EBNF v5 = grammar L2 第四份骨架语料**[Level 0-4 分层 + 二义性预防第 8-10 例 + K-D Level 3-4 脱糖备选优先级提高] + **QuantumEffectSpace 归位 K-E**[空间单源纪律——归位 EffectSpace Level 3 量子登记态子空间非平级新增] + 九步推演链与方法论七种[K-G 构建叙事档案——构建/验收判据分立] + 审查裁定 K-A..K-H 八项）+ **原则 48**「数学工具箱分级与隐喻登记纪律」+ 附录 A 二十条 + **E.20 文献两条**[Hirani DEC + Edelsbrunner & Zomorodian 持久同调——**两项 web-search 实检索证 r91-q1~q2 存档 docs/tool-results/r91-search/**] + F.14 第十九轮对照表 + §23.1 计数四十八
- **收编**：lang-design **十二件**修订 + 十三件零增量维持（25/25）——02 v7.1 §8.8[EBNF v5 分层版] / 05 v6.8 §10[量子分析 Pass D + EffectPathIntegral] / 06 v6.8 §12[波粒二象性语义注记] / 13 v6.15 §3.14[拓扑/量子能力行 + 8 原语第四轮验证] / 24 v2.5 §17[量子登记态子空间归位 + 维度谱系] / 19 v7.5 §20[E.20 两条 127-128] / 18 v7.13 §5o[术语二十条] / 22 v2.10 §23[数学工具箱/波粒/场论/纠缠术语族消歧 + K-A 分级裁定锚] / 17 v7.9[原则 48 + 附十四] / 20 v1.12 §13[EBNF v5 脱糖优先] / **09 v6.13 §5[Randomness 效应 std 族候选 + EffectField 层 5 远见方向注记——效应线程首次开面]** / 00 v6.14
- **反哺**：sop.md v13.9→**v13.10**（§2.2 原则表新增 48 行 + §21.12 新增第 17 条「数学工具箱分级与隐喻登记纪律」[K-A 三级分级 + 贝尔诊断性 + 波粒第六环 + EBNF v5 脱糖优先 + 空间归位单源 + 理论-实现分层映射 + 推演方法论档案七项] + §8.4.5 新增「数学工具箱/波粒二象性定位」查询行 + 目录/标题/来源注四十七→四十八计数修正 + stage0 v7.8 锚 + 变更日志 v13.10 行）
- **验证**：§3.2 六命令全绿（build --release 零告警 + check 0/0 + fmt --check 0 diff + clippy --workspace --all-targets --release -D warnings 0 + **test --release --workspace 1055:0:0 逐位维持**[798 runner + 257 单元——纯文档轮零代码变更]）+ 六审计集 280 case EXIT 0 ×6 + CLI 六路径
- **#15 状态**：讨论先行持续——理论载体**六环**齐备（容器→概率域→生命周期三部曲 + 流形 + 逆向对偶 + 波粒二象性）+ EBNF **四份**骨架（v1/v3/v4/v5）+ 类型规则全集（14+9+9+5 条）——设计完备性持续兑付**不构成开窗信号**；切换窗六步前置清单维持未开窗；**T3+ 14 行触发族判定零变化**
- **r91 包**：kerf-v1.0.0-r91-mathtoolbox-waveduality-1055tests.tar.gz（包内自举三验全绿：净构建 + 1055 复跑 + e5close + fib 75025/⇒144）
- 对账链：matrix r91 行 + 本节 + rec 53（03 层）+ t3plus v1.12 r91 注记 + 指南 v1.11 + 层 l 双更新 + 外根第三链镜像 + web r91 节点

## r90（v1.0.0-r90）——TD-032 第五切口（末切口）实施轮：缓存咨询策略生产切换 + r89 状态恢复轮（#17 构建系统续窗·M1 指令开窗第六例——**TD-032 清偿关闭**）

- **用户驱动源**：三链指令「① z.ai web 保存机制回滚后使用上传的 kerf-v1.0.0-r89-reverseeffect-1036tests.tar.gz 替换当前项目内容 ② 按照 docs/sop.md 流程结合 docs/lang-design/ 下的项目演进流程 与 docs/develop/v0/tech-debt-register.md，docs/develop/v0/stage-3/t3plus-trigger-audit.md 按照推荐先后任务顺序继续推进 ③ 同步完整打包项目 tar.gz 并同步完整更新web page」——任务② = **M1 指令开窗第六例**（[t3plus-manual-trigger-guide §4 速查卡【第 2 位】](docs/develop/v0/stage-3/t3plus-manual-trigger-guide.md) TD-032 续窗——「按照推荐先后任务顺序继续推进」指定方向行权：第 1 位 #15 需 next13.md 未上传 → 自然落到第 2 位 TD-032；开窗依据双合规 = 登记册 v0.4.9「按用户指令续窗或触发判据」用户指令路径 + r74/r79/r86/r87 先例锚；行权链第六例：r74 四窗 / r79 / r80 / r86 / r87 / **r90**）
- **任务① r89 状态恢复（160-a）**：环境整体回滚实况（git HEAD r75 + download 尾包 r75 + 外根 worklog 末条 r75）→ tarball 全量解包恢复（398 条目对账一致 + 恢复提交 aec9c2e；**r76-r88 十三轮实绩随包恢复**；根 tool-results 原始检索档 r34-r50 = 44 件在 git 历史 0d20895 保全；**docs/tool-results 精选证据面零损失**[r65/r66/r83/r84/r88/r89-search 共 24 件全在包内]）+ 工具链重装（scripts/rust/setup.sh——rustc 1.98.1 同版零漂移）+ **1036:0:0 逐位复现**（782 runner + 254 单元）+ 文档实锚 15 项全核对（sop v13.9 / stage0 v7.7 / t3plus v1.10 / 指南 v1.9 / lang-design 十一件）+ **worklog 159 条目回补**（收口 append 随会话耗尽丢失——依包内存证[rec 51 + RELEASE r89 节]重构，append-only 显式标注）
- **任务② TD-032 第五切口（160-b）——缓存咨询策略面生产切换**：净增量四件 = ①`crates/kerf-driver/src/bootstrap/cache.krf`（入口 `lcache-consult`——缓存咨询策略语义移植[driver.rs compile_front_cached 原三段式]：**键策略 .krf 单源**{source-hash = (lhash source) 内容寻址 + cfg-fp 输入串 = "{SEED}|{filename}|{kind-tag}"[string-append 二元嵌套 = Rust format! 逐字符同构]——文件名入指纹理由[产物内嵌 SourceMap] + kind 入指纹 = B11/P4 种类分桶在 .krf 面表达} + **bypass 快路径**{!enabled 早退——零哈希/零查询调用，镜像 Rust 早退臂} + **咨询三形决策**{(llookup src-hash cfg-fp) → ('hit|'miss src-hash cfg-fp) 三元列表}；CACHE-SEED 常量 .krf 单源侧——parity corpus 锁双源一致）+ ②`crates/kerf-driver/src/bootstrap_cache.rs`（切口桥第五实例：六参直传 + **lhash64 Foreign 回调**[hash.rs content_hash64 = A 类冻结宿主服务经桥暴露——「VM 原语缺位」裁定解：宿主服务永不入 VM 指令集，SHA-256 截断 u64 ↔ VM Int i64 位型透传] + **lcache-lookup Foreign 回调**[cache.rs lookup_front = A 类冻结宿主服务 + 命中快照单槽暂存 handoff——FrontOutput pub(crate) 形态不经 VM 值域/pub 面] + CachePlan 三形决策面{Bypass/Hit(CacheKey)/Miss(CacheKey)——pub CacheKey 冻结契约类型全可观测} + take_hit crate 内取回 + production_cache_is_bootstrap 活性探针 + 桥单元 3[状态活性 + 生产活性 + hit 快照 handoff 单槽]）+ ③driver.rs compile_front_cached 生产切换（cache_bridge_internal fail-closed 映射 E0002 + Stage::Compile——bootstrap_build 同构纪律；cache_key + 原三段式退役 parity oracle）+ ④`tests/v0/stage3/plan/cache_krf_parity_tests.rs`（parity corpus 16 case[键构造 parity 五：生产语料族/文件名区分/B11 分桶/决定性复询/分隔符边界文件名 + 咨询策略六：bypass 零副作用/新鲜未中/错误路径不缓存/停用直编译/命中快照可重复/启用×预热全形态矩阵 + 生产守护五：活性探针/check E2E 真实语料/run 缓存透明/统计计数矩阵 3×3/报告字段全等价]——runner 树挂载）
- **切换守护**：**切换前后 CLI 六路径输出逐字节一致**（run fib 75025 + ⇒144 / run higher_order ⇒(1 4 9 16 25) / run closures (4 2)⇒42 / check fib ok：2 原型/9 常量/5 全局引用/38 指令（缓存未中；会话命中 0/0）[缓存观测文本逐字节] / test fib 双 PASS + 通过 2/共 2 + 退出码 0 / fail_demo FAIL+detail+退出码 1——diff 零差异）；测试计数 = 1036 + 16 runner + 3 桥单元 = **1055:0:0**
- **TD-032 终态**：五切口全落清偿关闭——首切口 build.krf（模块解析面）✅ r74 + 第二切口 cli.krf（CLI 编排面）✅ r79 + 第三切口 test.krf（测试入口面）✅ r86 + 第四切口 test_runner.krf（测试运行器面）✅ r87 + **第五切口 cache.krf（缓存咨询策略面）✅ r90**——07 §3.3 Stage 2→3 信号「构建系统可用新语言重写」第五生产实证 + **构建系统 .krf 化余下面清零全收口**（缓存存储本体 = A 类永久基座永不替换——替换面图 §3.4；增量编译需求信号路径留档 = Stage 2 查询式增量深化[per-module 粒度/依赖图]的自然信号判据维持登记——本切口 = Stage 1 咨询策略面）
- **T3+ 触发族 14 行判定零变化**（本轮开外源窗 TD-032 续窗非 T3+ 行；#15 切换窗维持未开窗）
- **验收**：§3.2 六命令全绿（build 0 告警 / check 0/0 / fmt 0 / clippy --workspace --all-targets --release -D warnings 0 / **test 1055:0:0 逐位**[798 runner + 257 单元]）+ 六审计集 280 case EXIT 0 ×6 + CLI 六路径逐字节一致
- **r90 包**：kerf-v1.0.0-r90-td032cacheclose-1055tests.tar.gz（包内自举三验全绿：净构建 + 1055 复跑 + e5close + fib 75025/⇒144）
- 对账链：matrix r90 行 + 本节 + rec 52（03 层）+ t3plus r90 注记 + 指南 v1.10 #17 终态 + TD 登记册 v0.4.10 + 07 v6.8 + 层 l 双更新 + 外根第三链镜像 + web r90 节点

## r89（v1.0.0-r89）——第十八轮逆向效应流与计算干涉吸收轮：对偶五环 + 原则 47 + EBNF v4 + 量子隐喻裁定（#15 讨论主线第八次行权·新语料追加段形态）

- **用户驱动源**：五链指令「next12.md 吸收进 stage0.md 直至收敛 → 融入 lang-design 对应文件 + 系统性全面审查[性质/边界/能力/职责/数学性质/前沿概念/正交分解/二义性/文献完整性/数学逻辑支撑/引用可靠性等] → 反哺 stage0.md 二次整理 → 反哺 sop.md 适当位置 + 打包 + web」——#15 目标语言设计讨论主线第八次用户行权（M1 形态：next12.md 追加段 2845-6512 行 +3668 历次最大单轮追加——同文件名追加按语料实质判定合法新语料；TD 指南【第 1 位】行权第七例延续）
- **吸收主体（159-a）**：stage0.md v7.6→v7.7（§9.19 八小节：①追加段对账[八段结构 + 实况修正八行——「可以开始 Stage 0 实施」= 理论完备性表述非流程指令；登记态零代码维持] ②**逆向效应流对偶理论 v5**[用户理论第五环：正逆对偶表 Perform↔Consume/Handle↔Offer/Resume↔Rewind + 汇流/收拢/收敛三逆连接 + 对偶范畴 正向范畴^op ≅ 逆向范畴 + 双幺半群 + 分配律开放问题] ③逆向不可替代性判据[知识不对称理论——全局解不可分解为局部解组合时必须逆向；四领域：共识/收敛/事务/资源回收] ④8 原语闭合验证与正逆组合语义[Consume = Perform(Receive)/Offer = Handle 服务模式/Rewind = Resume 多播——三轮验证零新增原语 + 四组合规则 + 正逆五类型规则含 T-SHUTDOWN 正逆配对湮灭 + 双向 Continuation 运行时登记] ⑤**计算干涉理论**[三干涉模式构造性/破坏性/纠缠 + 交换子 [A,B]_R 形式化 + 非对易性实例 A=+1/B=×2 → −1 ≠ 0 + 计算不确定性原理 + 量子隐喻性裁定 + 干涉感知四类型规则] ⑥伪随机坍缩机制[Randomness 效应 + PCG32 检索锚 + 竞争 Offer 调度 + CollapseScheduler 轮盘赌] ⑦EBNF v4 第三份骨架语料[逆向/干涉/概率三语法族 + 二义性预防第 4-7 例 + 关键字张力双判据 + 宏层脱糖零关键字备选] ⑧空间归属扩展与统一五层框架[逆向/干涉/坍缩三子空间 + 五层总图 + 异步并发七优势 + InterferenceAnalysisPass]）+ 原则 47 + 附录 A 二十条/E.19 两条/F.13
- **收编（159-b）**：lang-design 十一件修订——02 v7.0 §8.7（EBNF v4 正逆干涉版——语法面主体）/ 05 v6.7 §9（双向 Continuation + EffectScheduler + CollapseScheduler + Randomness——运行时面）/ 06 v6.7 §11（正逆五规则 + 干涉四规则——语义面）/ 13 v6.14 §3.13（逆向/干涉/坍缩能力行 + InterferenceAnalysisPass + 异步并发七优势——能力面）/ 24 v2.4 §16（三子空间 + 统一五层框架——空间论主体）/ 19 v7.4 §19（E.19 两条——O'Neill PCG + Selinger 量子 PL 综述，web-search 实检索证 r89-q1~q2 存档 tool-results/r89-search/）/ 18 v7.12 §5n（术语二十条）/ 22 v2.9 §22（六组术语消歧 + 量子隐喻裁定 + 收拢/坍缩同形异义）/ 17 v7.8（原则 47 + 附十三）/ 20 v1.11（关键字张力与脱糖备选增记）/ 00 v6.13（修订注记 + **R4 顺修：上游内联版本注 r88 漏更新 v7.5→v7.7**）；其余十四件零增量维持
- **反哺（159-c/159-d）**：sop.md v13.8→v13.9（原则 47 入 §2.2 表[四十六→四十七] + §21.12 第 16 条「逆向效应与计算干涉登记纪律」+ §8.4.5 逆向效应流/计算干涉定位查询行 + 目录/标题/来源注计数同步 + 变更日志 v13.9 行）；stage0 双侧同步注记修正（§9.19.8 收编清单——十一件实际落位节号核对）+ **R4 顺修四处**（stage0 流形消歧节号漂移 §20→§21 ×3[r88 残留] + 00 上游内联版本注——本轮勘察发现当轮修正）
- **对账**：t3plus-trigger-audit v1.10（§4 前注 r89 行——#15 第八次行权消费注记）+ t3plus-manual-trigger-guide v1.9（#15 第八次行权注记——追加段形态登记；下一行权推荐 = 第 1 位维持：next13.md 待上传）+ 本节；#15 状态 = 讨论先行持续（理论载体五环齐备）——切换窗六步前置清单维持未开窗
- **验收**：§3.2 六命令全绿 + **test 1036:0:0 逐位维持**（纯文档轮零代码变更）+ 审计×6 280 case EXIT 0 + CLI 五路径逐字一致
- **r89 包**：kerf-v1.0.0-r89-reverseeffect-1036tests.tar.gz（包内自举三验全绿：净构建 + 1036 复跑 + e5close + fib 75025/⇒144）
- 对账链：本节 + t3plus r89 注记 + 指南 v1.9 #15 第八次行权 + rec 51（03 层）+ 层 l 双更新 + web 五件（stats 自动对账 1036/r89 包）

## r88（v1.0.0-r88）——第十七轮效应流形理论与形式化完备吸收轮：流形四环 + 原则 46 + EBNF v3 + 坐标系/地图裁定（#15 讨论主线第七次行权·新语料全量形态）

- **用户驱动源**：五链指令「next12.md 吸收进 stage0.md 直至收敛 → 融入 lang-design 对应文件 + 系统性全面审查[概念漂移/数学性质/前沿概念/正交分解/单模型内部与多模型间组织协调/二义性/文献完整性等] → 反哺 stage0.md 二次整理 → 反哺 sop.md 适当位置 + 打包 + web」——#15 目标语言设计讨论主线第七次用户行权（M1 形态：next12.md 2855 行六轮上传即行权条件达成——历次最大语料 121KB；TD 指南【第 1 位】行权第六例）
- **吸收主体（158-a）**：stage0.md v7.5→v7.6（§9.18 八小节：①十二维度矩阵对账[漂移检测 + 实况修正——语料自评 72%→86%→92% vs kerf 实况 R4] ②设计宪法五定义[概念漂移防护新形态——分散定义的宪法式集中权威化] ③**效应流形理论 v4**[用户理论三部曲推广环：三连接公理串联/嵌套/循环 + 切片/升降维对偶 + 范畴论定位 Monad ⊂ Free ⊂ EffectManifold + 「流形」隐喻性裁定——数学实质 = 带连接的效应范畴/图] ④完整操作语义[14 推理规则全集 + 小步语义 ⟨e,ρ,σ,κ⟩ + 效应行合一算法 + 8 原语映射与 Return final:Var(0) 裁定——零新增原语] ⑤EBNF v3 效应容器模型[15 关键字演进：impl 并入 type + linear 降为类型标注 + connect/lift/project/pass 流形语法 + 二义性预防三例] ⑥空间理论深化[坐标系/地图裁定——用户陈述权威化 + 低熵控制三机制 = A1-A7 信息论再表述零新公理 + 七维度/七步坐标 + SpaceRegistry 协议 + SpaceValidationPass 编译期强制] ⑦信息系统三层架构[EffectTrace 桥接层 + 流形诊断五类] ⑧审查裁定汇总 I-A..I-H' 九项）+ 原则 46 + 附录 A 二十三条/E.18 两条/F.12
- **收编（158-b）**：lang-design 十一件修订——02 v6.9 §8.6（EBNF v3 + 流形语法 + 二义性三例——语法面主体）/ 05 v6.6 §8（EffectGraph + 流形分析 Pass + EffectTrace——运行时面）/ 06 v6.6 §10（14 规则 + 小步语义 + 合一算法——语义面）/ 13 v6.13 §3.12（流形能力面 + SpaceRegistry + SpaceValidationPass）/ 24 v2.3 §15（坐标系/地图 + 低熵控制 + 七维度/七步——空间论主体）/ 19 v7.3 §18（E.18 文献两条——Mac Lane 范畴论工具箱 + Ramsey&Pfeffer 概率最近邻，web-search 实检索证 r88-q1~q2 存档 tool-results/r88-search/）/ 18 v7.11 §5m（术语二十三条）/ 22 v2.8 §21（流形术语族消歧六条 + 隐喻裁定 + 设计宪法锚）/ 17 v7.7（原则 46 + 附十二 + **R4 顺修两处：原则 45 重复条目 + 附十一重复块清除——r84 残留**）/ 20 v1.10（15 关键字演进增记）/ 00 v6.12；其余十四件零增量维持
- **反哺（158-c/158-d）**：sop.md v13.7→v13.8（原则 46 入 §2.2 表[四十五→四十六] + §21.12 第 15 条「效应流形理论登记纪律」+ §8.4.5 效应流形/空间理论定位查询行 + 目录/标题/来源注计数同步 + 变更日志 v13.8 行）；stage0 双侧同步注记（§9.18.8 收编清单——十一件版本对齐核验）
- **对账**：t3plus-trigger-audit v1.9（§4 前注 r88 行——#15 第七次行权消费注记）+ t3plus-manual-trigger-guide v1.8（#15 行权注记——next12.md 上传即条件兑现）+ 本节；#15 状态 = 讨论先行持续（理论载体四环齐备）——切换窗六步前置清单维持未开窗
- **验收**：§3.2 六命令全绿 + **test 1036:0:0 逐位维持**（纯文档轮零代码变更）+ 审计×6 280 case EXIT 0 + CLI 五路径逐字一致
- **r88 包**：kerf-v1.0.0-r88-effectmanifold-1036tests.tar.gz（包内自举三验全绿：净构建 + 1036 复跑 + e5close + fib 75025/⇒144）
- 对账链：本节 + t3plus r88 注记 + 指南 v1.8 #15 第七次行权 + web 五件（stats 自动对账 1036/r88 包）

## r87（v1.0.0-r87）——TD-032 第四切口实施轮：测试运行器编排生产切换（#17 构建系统续窗·M1 指令开窗第五例）

- **用户驱动源**：两链指令「① 按照 docs/sop.md 流程结合 docs/lang-design/ 下的项目演进流程 与 docs/develop/v0/tech-debt-register.md，按照推荐的先后任务顺序开始继续任务 ② 同步完整打包项目 tar.gz 并同步完整更新web page」——**M1 指令开窗第五例**（[t3plus-manual-trigger-guide §4 速查卡【第 2 位】](docs/develop/v0/stage-3/t3plus-manual-trigger-guide.md) TD-032 续窗——「按推荐先后顺序继续任务」指定方向行权：第 1 位 #15 需 next12.md 未上传 → 自然落到第 2 位 TD-032；行权链第五例：r74 四窗/r79 TD-032 第二切口/r80 HM 默认期/r86 TD-032 第三切口/r87 TD-032 第四切口）
- **TD-032 第四切口（157-b）——测试运行器面生产切换**：净增量四件 = ①`crates/kerf-driver/src/bootstrap/test_runner.krf`（入口 `ltest-run`——用例切分 + 逐用例执行编排 + 结果聚合语义移植：`is-prelude-kind` 切分判定单源[define/module/require/assign 前置 vs 表达式用例] + `truncate-name` 截断单源[char 域 ≤64 字符——string-length/string-substring 与 Rust chars().count()/take(64) 同构] + `run-loop` 主循环[两 if 臂均尾位——TCO 帧复用长源无栈溢出] + `rev-list` 逆序还原 + 前置 id 逆序头插 O(1)；结果四元列表 `(index name pass detail)` 与第三切口 `ltest-report` 契约同型——切口链式消费；`(import kerf-list kerf-string)` 与五桥同款）+ ②`crates/kerf-driver/src/bootstrap_test_runner.rs`（切口桥第四实例：项元数据投影[kind_tag + 完整渲染名] + **Foreign 回调 `lrun-case`**[前置 id 列表 + 用例 id 参数直传——词法绑定规避全局可见面；切片重建 + `handle_escape`/`TestFailure` 效应边界短路/恢复 + `run_case` 嵌套 VM 独立堆/全局用例隔离] + `report_from_value` 协议防御解构 + 现场统计 + `production_test_runner_is_bootstrap` 活性探针 + Front/Internal 双通道[前段真实诊断透传 vs 引导缺陷 fail-closed]）+ ③根 `src/main.rs` cmd_test 生产切换（`test_source` 退役为 parity oracle；`driver.rs` 三件 pub(crate) 暴露[resolve_symbol/TestFailure/run_case——桥消费面]）+ ④`tests/v0/stage3/plan/test_runner_krf_parity_tests.rs`（parity corpus 13 case[零用例协议/单通过/单失败 detail 逐字/混合恢复编排/前置逐用例重放隔离/切分全 kind 含用例先于前置/名称截断边界 64-65+Unicode char 域/运行时错误 detail/效应短路首错即停/前段错误通道分立/真实语料端到端 fib+fail_demo 形态/全形态矩阵扫描 0-5 项 × 前置用例全组合 63 源形态/生产活性探针] + 桥内嵌单元 3[状态活性 + 生产活性 + 前段错误通道]——runner 树挂载）
- **切换守护**：**切换前后 CLI `kerf test` 输出逐字节一致**（fib.krf：`75025/PASS    1 (print (fib 25))/PASS    2 (fib 12)/通过 2 / 共 2（失败 0）` + 退出码 0；fail_demo.krf：`FAIL    1 (= 1 2)/      └ 断言返回 #f（期望非 #f 值）——求值结果 false/PASS    2 (f 5)/通过 1 / 共 2（失败 1）` + 退出码 1——cat -A 逐字节对账）；端到端 parity 级联第三切口（`.krf runner + ltest-report` vs `Rust oracle + report_seed` 全链字节级一致）；测试计数 = 1020 + 13 runner + 3 桥单元 = **1036:0:0**
- **验收**：§3.2 六命令全绿（build 0 告警/check 0/0/fmt 0 diff/clippy --workspace --all-targets -D warnings 0/**test 1036:0:0 逐位**[782 runner + 254 单元]）+ 六审计集 280 case EXIT 0 ×6（E5 出口三条件全绿 S4 收口 GO 维持）+ CLI 五路径（四路径逐字一致 + test 路径切换前后逐字节一致）
- **TD-032 状态推进**：首切口 build.krf（模块解析面）✅ r74 + 第二切口 cli.krf（CLI 编排面）✅ r79 + 第三切口 test.krf（测试入口面）✅ r86 + **第四切口 test_runner.krf（测试运行器面）✅ r87**——余下一切口 = 缓存段（cache.rs——字节级哈希面，VM 原语缺位；触发判据 = 增量编译需求信号——登记册 v0.4.9；07 §3.3 Stage 2→3 信号第四生产实证）
- **T3+ 触发族 14 行判定零变化**（本轮开外源窗 TD-032 续窗非 T3+ 行；#15 切换窗维持未开窗）
- **r87 包**：kerf-v1.0.0-r87-td032testrunner-1036tests.tar.gz（包内自举三验全绿：净构建 + 1036 复跑 + e5close EXIT 0）
- 对账链：matrix r87 行 + 本节 + rec 49（03 层）+ t3plus r87 注记 + 指南 v1.7 #17 第四切口 + TD 登记册 v0.4.9 + 07 v6.7 + 层 l 双更新 + 外根第三链镜像 + web r87 节点

## r86（v1.0.0-r86）——TD-032 第三切口实施轮：测试入口执行链生产切换 + ripwire 工具收录（#17 构建系统续窗·M1 指令开窗第四例）

- **用户驱动源**：三链指令「① 查询并判断工具 https://github.com/redhat-et/ripwire 是否有助于当前项目的推进，如果有助于则结合 sop.md 中的工具流程收录到开发流程中 ② 按照 docs/sop.md 流程结合 docs/lang-design/ 下的项目演进流程 与 docs/develop/v0/tech-debt-register.md，按照推荐的先后任务顺序开始继续任务 ③ 同步完整打包项目 tar.gz 并同步完整更新web page」——**M1 指令开窗第四例**（[t3plus-manual-trigger-guide §4 速查卡【第 2 位】](docs/develop/v0/stage-3/t3plus-manual-trigger-guide.md) TD-032 续窗——「按推荐先后顺序继续任务」指定方向行权：第 1 位 #15 需 next12.md 未上传 → 自然落到第 2 位 TD-032；行权链第四例：r74 四窗/r79 TD-032 第二切口/r80 HM 默认期/r86 TD-032 第三切口）
- **任务① ripwire 调研裁定与收录（156-a）**：**裁定 = 有助于**——三重实证（① v0.6.0 linux/x64 实机安装[官方一键脚本 api.github.com 限流 403 → release tar.gz 直链——setup.sh 内置该路径] ② kerf 仓库实测 `ripwire .`：358 文件/6090 符号/5562 边/1.1s 冷解析 + `--for="cmd_test report rendering test entry"` 精确命中本轮切口全符号面[cmd_test/TestReport/test_source/dispatch_seed + hops 调用边 + r79 rec 文档锚] ③ 诚实边界契合[输出披露 `unindexed="krf:15,lock:1"`——.krf 面归原则 44 symbol.rs 双源单源不受影响]）；**收录形态** = agent 辅助开发流程工具（§3.1 流程归档：`scripts/ripwire/setup.sh` + `docs/tools/ripwire/setup.md` + sop v13.7 §3.1 工具表行）——**非构建依赖**（§18.4 表不收录；永不进入 Cargo 依赖/语言管线/自举链——与 ripgrep 同类宿主侧工具）
- **任务② TD-032 第三切口（156-b）——测试入口执行链生产切换**：净增量四件 = ①`crates/kerf-driver/src/bootstrap/test.krf`（入口 `ltest-report`——cmd_test 面分派后执行链语义移植：int->str 递归除余 + pad3 右对齐 `{:>3}` 同构 + 逐用例行[PASS/FAIL 前缀 + 序号 + 名 + 可选 detail 行] + 汇总行[中文字面量逐字节镜像] + all_passed 退出码决策；passed/failed 现场统计——.krf 为决策单源；`(import kerf-list kerf-string)` 与四桥同款）+ ②`crates/kerf-driver/src/bootstrap_test.rs`（切口桥第三实例——用例四元列表构造 + 单参直传 + 二元列表解构 + `report_seed` 退役 oracle + `production_test_is_bootstrap` 活性探针）+ ③根 `src/main.rs` cmd_test 生产切换（渲染循环退役为 parity oracle；fail-closed 码 1 引导缺陷面）+ ④`tests/v0/stage3/plan/test_krf_parity_tests.rs`（parity corpus 13 case[零用例协议/单通过/单失败双态/混合多用例/序号边界 1-1000/Unicode/全失败/长名空格名/计数一致性/生产活性探针/真实语料端到端/全形态矩阵扫描 0-5 用例 × 通过失败全组合]——runner 树挂载）
- **切换守护**：**切换前后 CLI `kerf test` 输出逐字节一致**（fib.krf：`75025/PASS    1 (print (fib 25))/PASS    2 (fib 12)/通过 2 / 共 2（失败 0）` + fail_demo.krf：FAIL + `      └ ` detail 行 + PASS + 退出码 1——cat -A 逐字节对账）；测试计数 = 1005 + 13 runner + 2 桥单元 = **1020:0:0**
- **验收**：§3.2 六命令全绿（build 0 告警/check 0/0/fmt 0[桥初写 fmt 顺修 + doc 注释折行两处顺修]/clippy --workspace --all-targets -D warnings 0/**test 1020:0:0 逐位**）+ 六审计集 280 case EXIT 0 ×6 + CLI 五路径（四路径逐字一致 + 新 test 路径基线对账）
- **TD-032 状态推进**：首切口 build.krf（模块解析面）✅ r74 + 第二切口 cli.krf（CLI 编排面）✅ r79 + **第三切口 test.krf（测试入口面）✅ r86**——余下两切口 = 测试运行器 / 缓存段（登记册 v0.4.8；07 §3.3 Stage 2→3 信号第三生产实证）
- **T3+ 触发族 14 行判定零变化**（本轮开外源窗 TD-032 续窗非 T3+ 行；#15 切换窗维持未开窗）
- **r86 包**：kerf-v1.0.0-r86-td032testentry-1020tests.tar.gz（包内自举三验全绿：净构建 + 1020 复跑 + e5close EXIT 0）
- 对账链：matrix r86 行 + 本节 + rec 48（03 层）+ t3plus r86 注记 + 指南 v1.6 #17 第三切口 + TD 登记册 v0.4.8 + 07 v6.6 + sop v13.7 工具表 + 层 l 双更新 + 外根第三链镜像 + web r86 节点

## r84（v1.0.0-r84）——第十六轮效应本体论与目标语言极简设计吸收轮：三部曲 + 原则 45 + 容器式签名

- **用户驱动源**：五链指令「next11.md 吸收进 stage0.md 直至收敛 → 融入 lang-design 对应文件 + 系统性全面审查 → 反哺 → 打包 + web」——**第六次用户行权**（#15 目标语言设计讨论主线 M1+M3 复合；**新语料全量吸收形态**：next11.md 2821 行九段，上传于 r83 收口后）
- **吸收主体**：stage0.md v7.5（§9.17 八小节：十二问题对账[8 已覆盖+2 增量+2 新覆盖——F13 同构交叉印证] + 17 关键字极简体系[十二项传统关键字效应替代 + 宏层熟悉语法] + 标注语法演进[四方案→用户否决方案 A→容器式 `Return(T) | E` 终态草案——二元分离残留教训] + **效应本体论三部曲**[容器→概率域→生命周期：四维结构 + resume ∈ {0,1} 完整语义 + 量子类比理解辅助] + 终态定位[同一系统两种描述——机制 100% 兼容零实现成本] + 二义性三策略 + SpaceContract 接口面）+ 原则 45「效应理论登记纪律」+ 附录 A 十七条/E.17 文献六条[六项 web-search 实检索证]/F.11
- **收编**：lang-design 十一件修订（02 v6.8 / 05 v6.5 / 06 v6.5 / 13 v6.12 / 24 v2.2 / 19 v7.2 / 18 v7.10 / 22 v2.7 / 17 v7.6 / 20 v1.9 / 00 v6.11）+ 十四件零增量（25/25）+ **R4 顺修两处**（sop 孤立 44 号行清除 + 22 Date v2.6 条目补登）
- **反哺**：sop.md v13.6（原则表 45 + §21.12 第 14 条 + §8.4.5 查询行 + 计数四十五 + 变更日志）
- **验收**：§3.2 六命令全绿 + **test 1005:0:0 逐位维持**（纯文档轮）+ 审计×6 280 case EXIT 0 + CLI 四路径经判定面逐字一致 + 交叉引用自检（§9.17 锚 38 处 + 十一件版本实锚）
- **#15 门控**：切换窗六步前置清单维持未开窗（理论载体就位不构成开窗信号——定稿义务含容器式签名与二义性审理）；T3+ 触发族 14 行判定零变化
- **r84 包**：kerf-v1.0.0-r84-effectontology-1005tests.tar.gz（包内自举三验全绿：净构建 + 1005 复跑 + e5close EXIT 0）
- 对账链：matrix r84 行 + 本节 + rec 47（03 层）+ t3plus r84 注记 + 指南 v1.5 + 层 l 双更新 + 外根第三链镜像 + web r84 节点

## r83（v1.0.0-r83）——第十五轮语法定义形式增量维度吸收轮：EBNF 体系组织模型 + 原则 44 + grammar 规范层落位（#15 主线第五次用户行权——维度增量形态）

- **用户驱动源**：五链指令在 r81 十八维系统性审查基础上**新增审查维度**——「目标语言的语法定义形式和语法文件描述与语言语法设计和前沿探索与深度广度描述及知识搜索与系统化体系组织模型（间）设计(EBNF,...)」——非 next 系列新语料（next10.md 本体已于 r81/v7.3 全量吸收），同一语料的**新透镜再审查**（审查收敛的维度增量形态）。**第五次用户行权实例**（[t3plus-manual-trigger-guide §4 速查卡【第 1 位】](docs/develop/v0/stage-3/t3plus-manual-trigger-guide.md) #15 目标语言设计讨论主线——行权链第五例：r74/r79/r80/r81/r83）
- **审查发现（G1-G3 缺漏三证据）**：①next10.md 996 行全文 EBNF/BNF/文法零命中（仅第 311 行目录项「表面语法定义（关键字/运算符）」——语法以成员清单登记，「有什么」≠「如何定义」）②stage0 §9.14.2 清单式继承（上游语料缺漏显性化——非遗漏）③lang-design 25 文件零文法锚 + 关键字双源（20 §8 文档源 vs symbol.rs 代码源）无 grammar 单源。**缺漏定性**：不阻塞 Stage 0 / 阻塞 #15 切换窗设计完备性（六步前置清单第 1 步「完整语法规范」无形式载体）/ 工具面漂移债（Rust reference 非形式化前车之鉴）
- **补全设计主体**：stage0.md v7.3→**v7.4**——§9.16 语法定义形式与语法文件体系七小节（五体系对照三裁定[**G-A** W3C EBNF 记法——XML 1.0 §6 先例 30 年工业实证；**G-B** 定义/解析分离——CFG 级定义 + Stage 0 手写递归下降维持 + PEG 实现参考登记态；**G-C** 生成器永不入自举链——LLVM 同构纪律] + Stage 0 语法 EBNF 形式化[声明层/核心层/派生层/原子层四层产生式——R4 与 symbol.rs 25 关键字逐名对账] + Stage 2+ 目标语法 EBNF 骨架[fn/struct/enum/match/try-catch——try/catch 库层文法分区 + 优先级表独立义务] + grammar 四层组织模型[L1 记法/L2 规范/L3 实现/L4 工具——文档单源 + 单向派生] + 前沿对照六锚[Ford PEG/W3C/Wheeler 批评/tree-sitter/ANTLR4/Rust 教训 + Rhombus/Scheme R7RS 广度]) + **原则 44「语法定义形式化单源纪律」** + 附录 A 六条/E.16 六条文献[六项 web-search 实检索证]/F.10 第十五轮对照
- **lang-design 收编六件 + 十九件零增量维持（25/25 全覆盖）**：02 v6.7 §8.4（**grammar L2 规范层落位**——文档侧语法唯一权威呈现）/ 17 v7.5（原则 44 + 计数四十四 + 附十）/ 19 v7.1（§16 文献六条 111-116）/ 18 v7.9（§5k 术语六条）/ 20 v1.8（§12 EBNF 登记义务增记——产生式权威单源 02 §8.4）/ 00 v6.10（修订注记）；其余十九件零增量（语法形式化主题不触及——01 九原语冻结面不动）
- **sop.md v13.4→v13.5**：原则表 44 + §21.12 第 13 条「语法形式化登记纪律」（形式定义义务即刻生效 + W3C 记法裁定 + grammar 文档单源 + 定义/实现分离 + 单向派生 + #15 形式载体就位零载荷）+ §8.4.5 查询行 + 计数修正 + **来源注 v7.0/四十一残留 R4 顺修**（v13.4 漏更新当轮顺修→v7.4/四十四）
- **验证全项过**：§3.2 六命令全绿（build 零告警/check 0/0/fmt 0/clippy 0/**test 1005:0:0 逐位维持**——纯文档轮零代码变更）+ 六审计集 280 case EXIT 0 ×6 + CLI 四路径经 check.krf 判定面逐字一致 + 交叉引用自检全过（§9.16 锚 22 处 + 五件目标节 + 原则 44 三面落位）
- **T3+ 触发族 14 行判定零变化**（#15 讨论先行已发生 + 维度增量——切换窗维持未开窗；Stage 2+ EBNF 骨架 = 六步前置清单第 1 步预置形式载体，定稿义务在窗内）
- **r83 包**：kerf-v1.0.0-r83-ebnfformal-1005tests.tar.gz（包内自举三验全绿：净构建 + 1005 复跑 + e5close EXIT 0）
- 对账链：matrix r83 行 + 本节 + rec 46（03 层）+ t3plus v1.6 + 指南 v1.4 + 层 l 双更新 + 外根第三链镜像 + 打包 v1.0.0-r83（153-f）+ web r83 节点（153-web）

## r81（v1.0.0-r81）——第十四轮目标语言设计与错误统一效应模型吸收轮：next10.md 全量吸收 + lang-design 十六件收编 + sop v13.4 反哺（#15 目标语言设计讨论主线第四次用户行权）

- **用户驱动源**：「上传的 next10.md 文件中的相关讨论的设计和理念与原则、演进进程等等相关内容吸收并融入到 docs/stage0.md 中，直至完全收敛 → 重新审查并收并融入 docs/lang-design/ 对应文件 + 系统性全面审查（结合知识搜索、探索及思考发散与 sop.md 原则——问题/缺陷/性质/边界/能力/职责/数学性质/前沿概念/设计原则/架构选择/完整性/语法合理性/信息系统 vs 效应/二义性/正交分解/单模型内部/多模型协调/文献完整性/引用可靠性等维度）→ 反哺 stage0.md 二次整理 → 反哺 sop.md 适当位置 → 同步完整打包 tar.gz + 完整更新 web page」——**第四次用户行权实例**（[t3plus-manual-trigger-guide §4 速查卡【第 1 位】](docs/develop/v0/stage-3/t3plus-manual-trigger-guide.md) 目标语言设计讨论主线 #15——M1+M3 复合形态：设计讨论发生即信号 + 提案载体；行权链第四例：r74 四窗/r79 TD-032/r80 HM 默认期/r81 目标语言设计）
- **吸收主体（151-b/c）——stage0.md v7.2 → v7.3**：§9.14 目标语言设计蓝图（六维身份定位[表面/内核/控制流/资源/性能/拓展 + 既有收敛锚列] + 成员构成三组[语法全糖化清单 + 类型系统实况对账——HM 已生产 r80，行多态/交叉/开放记录/线性句法 = Stage 2+ 登记态 + 效应六内置] + 模块=子空间映射[A2/A5/A3 公理收敛] + 边界职责六层表[语言面 vs 实现面正交裁定] + 权衡七决策与放弃五特性 + 渐进披露四层[原则 43] + 生态扩展六维修正[F1：五维补 ForeignSpace 对齐 24 拓展域六域] + 最终形态七面 + 审查 F1-F5）+ §9.15 错误统一效应模型「统一而分治」（五套传统机制碎片化批判[三违背] + 流统一视角 + 统一五面/分治策略[参数化非特殊化] + Perform 同构展开形 + try/catch 标准库宏定位 + 替代表七项[Result 值级/效应级对偶——J4 同构] + 用户自定义错误语义 + 审查六裁定[**①信息系统 vs 效应系统正交**——编译期诊断 = 元信息系统 r75-r80 实况/运行时错误 = Error 效应；**②异常/错误二义消歧**；**③one-shot continuation 纪律补全**——文献锚；④Fatal/编译器 panic 边界；⑤五判据收敛；⑥实况对账] + §9.15.7 双侧同步注记）+ 原则 42/43 + 附录 A 十五条/B 四行/E.15 十条（六项 web-search 实检索证：Leijen 2014/Hillerström/OCaml 5 §24/Leroy 2024/Soundly Handling Linearity/Affect 2025/Kobayashi 2025/Becker 2019/Castagna 2024/Unison abilities）/F.9 第十四轮吸收对照
- **收编主体（151-d）——lang-design 十六件修订 + 全 25 文件系统性审查**：核心八件（17 v7.4 原则 42/43 + 附九对照 / 18 v7.8 §5j 术语十五条 / 19 v7.0 §15 文献十条 / 02 v6.6 §8.3 表面语法面 / 05 v6.4 §6 运行时面 / 06 v6.4 §8 归约视角 + one-shot / 12 v6.23 §2.12 #15 门控注记 / 24 v2.1 §13 效应域 Error 子空间 + 生态六维对齐）+ 次级八件（13 v6.11 §3.10 / 21 v1.8 §9 L2 层注记 / 22 v2.6 §19 模块映射与 Error 命名 / 14 v6.3 §4.9 替代设计对照 / 20 v1.7 §12 目标表面登记 / 04 v5.4 ext2 异常表槽方向注记 / 23 v1.8 **F13 终态声明** / 00 v6.9 十六件清单）+ 九件零增量维持（01/03/07/08/09/10/11/15/16——计数零漂移 + 悬空引用零 + 一致性确认）；**审查发现即修三处**：轮次编号冲突 R4 顺修（r66 同步轮「第十四轮」误标 ×2 处改名）+ F13 未裁项清偿（error 两通道分立正式声明）+ ext2 槽方向锚定（Error 效应 handler 表非栈展开）
- **反哺主体（151-e/f）**：stage0 §9.15.7 双侧同步与反哺注记（三段闭环终态 + 反哺三项回流）+ **sop.md v13.3 → v13.4 六处**（§2.2 原则表第 42/43 行[含违反示例] + §21.12 第 12 条「错误机制设计登记纪律」[禁止硬编码错误机制即刻生效 + F13 两通道分立终态 + one-shot 纪律 + 目标语言登记态零载荷] + §8.4.5 错误处理/目标语言设计查询行 + 目录/标题/来源注四十一→四十三 + §16.1 变更日志 v13.4 行）
- **验证主体（151-g）**：§3.2 六命令 clean 起步全绿（cargo clean → build --release **17.18s 零告警** → check 0/0 → fmt 0 diff[两处 r80 遗留顺修后] → clippy --workspace --all-targets -D warnings 0[一处孤立文档注释顺修后] → test --release --workspace **1005:0:0 逐位维持**——1005 基线零回归）+ 六审计集 **280 case EXIT 0 ×6**（stage0 41 + stage1 50 + stage2_r1 53 + stage2_r2 46 + stage3_m3 43 + stage3_e5close 47——E5 出口三条件全绿维持）+ CLI 四路径经 check.krf 判定面逐字一致 + 交叉引用自检全过（新增 20+ 引用全解析）
- **测试计数**：1005 → **1005（零测试函数增量——纯文档吸收轮零代码变更；1005 基线维持）**
- **#15 门控关系**：目标语言设计讨论已发生（讨论先行 ✅——第四次用户行权 M1+M3 复合）；表面语法切换窗仍按六步前置清单门控（未开窗）；T3+ 触发族 14 行判定零变化
- 对账链：matrix r81 行 + 本节 + rec 45（03 层）+ t3plus v1.5 + 指南 v1.3 + 层 l 双更新 + 外根第三链镜像 + 打包 v1.0.0-r81（151-z）+ web r81 节点（151-web）

## r80（v1.0.0-r80）——HM 默认期生产切换实施轮：kerf check 判定面切换 check.krf（#18 外源触发窗清偿 + oracle/fallback 双面 + 修正③④⑤ + 1005 测试）

- **用户驱动源**：「按照 docs/sop.md 流程结合 docs/lang-design/ 下的项目演进流程 与 docs/develop/v0/tech-debt-register.md，按照推荐的先后任务顺序开始继续 docs/develop/v0/stage-3/t3plus-trigger-audit.md, HM 默认期生产切换——PoC 已验证路径（check.krf parity 全过），自举深化」+「同步完整打包项目 tar.gz 并同步完整更新web page」——**M1 指令开窗形态**（用户按 [t3plus-manual-trigger-guide §4 速查卡【第 4 位】](docs/develop/v0/stage-3/t3plus-manual-trigger-guide.md) 行权——**第三次用户行权实例**[r74 四窗/r79 TD-032 之后]；12 §2.5.1 K3 终态「默认期切换窗口归 23 §2.2 Stage 3 承载」的窗口经行权开启——红线 1/3 双合规；开窗判据回填见 worklog 150-a 载荷）
- **实施主体（150-b）——HM 默认期生产切换**：**判定面四件** = ①`bootstrap_check.rs` 生产入口（`ProductionOutcome` 枚举[Krf 诊断载荷/Fallback 信号] + `production_check`[Unsupported 升格 fallback 路由 + KRF_PRODUCTION_RUNS 活性计数 + 单一形态收敛] + `production_check_is_krf` 活性探针——镜像 cli.krf 形态）+ ②`driver.rs` 双入口切换（`type_check_diags` 三路由[Krf → E0005 诊断重建/Span file_id 反查；Fallback → Rust oracle 窄面回退——perform/handle 效应语料；Err → DriverError fail-closed]——check_source + check_source_recover 双入口接入；**INC3「静态分析面不在自举链」裁定经用户指令推翻，HM 段迁入自举链——自举深化**）+ ③`check.krf` 修正③④⑤ + LT-* 盲区修复（**修正③** if 分支 occurs 时机[单变元分支改格 join——higher_order.krf 非尾递归误报清除]；**修正④** 变元头箭头传播[不传播返回 fresh——参数化调用误报清除]；**修正⑤** 自应用挽救[tc-var-occurs-in-args 形态精确探测——ω 形即时检出]；LT-TRUE/LT-FALSE/LT-NIL string-to-symbol 铸造['true/'nil quote 字面量化坑——PoC 25 case 盲区，三语料 probe 首跑暴露]；**自举语料误报 33 → 2 收敛**——保留 2 条 = 双面一致真检出[tail 具体非 pair 误用]）+ ④测试面语义重锚五文件（hm_krf_path/typecheck/hm_perf/namespace + hm_production_switch 新建 8 case——oracle 直调 helper 守护检出能力 + krf 面边界专项断言的双面分立）
- **验证主体（150-a/150-c/150-d）**：§3.2 六命令 clean 起步全绿（cargo clean → build --release **16.98s 零告警** → check 0/0 → fmt 0 diff[1 处当轮归零] → clippy 0[result_large_err 1 处 allow 注记] → test --release --workspace **1005:0:0 逐位**[756 runner + 249 单元]）+ 六审计集 **280 case 全 APPROVED**（审计集语义重锚——r2/m3/e5close 三集新增 OracleStaticErr 参照面变体[run_oracle_static 直调] + 消息锚重定 + D01 恢复探针双面分立[E0002 krf 面 + E0005 oracle 参照面]）+ **CLI 四路径经 check.krf 判定面逐字一致**（fib ⇒144 + higher_order (1 4 9 16 25) + closures ⇒42 + check ok：2 原型/9 常量/5 全局引用/38 指令——生产 E2E 即切换守护本体）+ 退出码五路径实测（run 0 / NeedsFile 2 / 文件不可读 1 / bogus 2 / 无参 2 / eval 退役 2）+ bench 三轮稳态 **71.453/73.315/70.780ms 带内**（OBS-C <65ms 不满足——零消费方维持）+ 语料六族 grep 零信号 + **三语料锚重定 319/145/193 → 0/1/0**（旧锚 r53-r79 十四轮正式退役——R4 诊断面变更实况对账）+ TD 开放 P0/P1 = 0
- **测试计数**：997 → **1005（净 +8** = hm_production_switch_tests 8[活性探针 + 七语料锚 + occurs 契约豁免守卫 + 三语料宽松化方向守卫 + fallback 双通道 + 生产负例检出 + 多错误收集]——**1005 基线自 r80 起**）
- **#18 外源触发窗清偿关闭**：r74 PoC 验证[check.krf + parity 16] → r75 多错误深化[项级恢复 + 25 case] → **r80 生产切换**全链闭环（12-roadmap v6.22 §2.5.1 终态注记 + 指南 v1.2 #18 清偿）；**T3+ 触发族 14 行判定零变化**（本轮开的是外源窗 #18 清偿——非 T3+ 行，待触发态维持）
- 对账链：matrix r80 行 + 总量行 1005 注记 + 本节 + rec 44（03 层）+ t3plus v1.4 r80 注记 + TD 登记册 v0.4.7 + 指南 v1.2 #18 清偿 + 12-roadmap v6.22 + 层 l 双更新 + 外根第三链镜像 + 打包 v1.0.0-r80（150-z）+ web r80 节点（150-web）

## r79（v1.0.0-r79）——TD-032 续窗实施轮：CLI 编排第二切口生产切换（cli.krf 分派判定 + parity 23 case + 997 测试）

- **用户驱动源**：「按照 docs/sop.md 流程结合 docs/lang-design/ 下的项目演进流程 与 docs/develop/v0/tech-debt-register.md，按照推荐的先后任务顺序开始继续 docs/develop/v0/stage-3/t3plus-trigger-audit.md, TD-032 构建系统续窗——首切口已生产切换（build.krf），四切口独立可续、低风险增量」+「同步完整打包项目 tar.gz 并同步完整更新web page」——**M1 指令开窗形态**（用户按 [t3plus-manual-trigger-guide §4 速查卡【第 2 位】](docs/develop/v0/stage-3/t3plus-manual-trigger-guide.md) 行权——r74-window-opening §1 先例锚 + 红线 1[非时间驱动] / 红线 3[用户指令即信号本体] 双合规；开窗判据回填表见 worklog 149-a 载荷）
- **实施主体（149-b）——TD-032 第二切口（CLI 编排面）生产切换**：净增量四件 = ①`bootstrap/cli.krf`（入口 `lcli-dispatch`——main.rs 原 match 分派逐臂语义移植：十二元组真值[run/check/test/tokens/stx/core/ir/bc/code/bench/anf/native] + eval 退役 + 三元组缺文件 NeedsFile + 未知兜底 Unknown；零 import 纯数据变换[仅 eq 内置 + cond/if/quote 特殊形]——R9 空授权）+ ②`bootstrap_cli.rs`（切口桥第二实例——两参直传无 Stx 序列化 + Symbol 标签→CliAction 重建 + `dispatch_seed` 退役 oracle + thread_local 惰性加载）+ ③根 `src/main.rs` 生产切换（分派判定经 .krf VM 运行——fail-closed 码 1 引导缺陷面 + bench N 可选参数宿主侧独立解析）+ ④`cli_krf_parity_tests.rs` 23 case（parity corpus：十二元组真值 12 + 三元组缺文件 3 + eval 双态 2 + dump 缺文件/未知/空命令边界 4 + 全矩阵扫描[15 命令 × 2 在位性 = 30 组合 + 大小写敏感锚 Run/RUN/ru] + 生产活性探针——runner 树挂载 §8.4.6）
- **验证主体（149-a/149-c）**：§3.2 六命令 clean 起步全绿（cargo clean → build --release **15.78s 零告警** → check 0/0 → fmt 0 diff[新桥初写 29 行 diff 当轮归零] → clippy --workspace --all-targets -D warnings 0 → test --release --workspace **997:0:0 逐位**[748 runner + 249 单元]）+ 六审计集 **280 case EXIT 0 ×6 真实复跑**（stage0 41 + stage1 50 + stage2_r1 53 + stage2_r2 46[宽窄双口径 45+1] + stage3_m3 43 + stage3_e5close 47）+ **CLI 四路径经 cli.krf 生产分派链逐字一致**（fib 75025/⇒144 + higher_order (1 4 9 16 25) + closures ⇒42 + check ok：2 原型/9 常量/5 全局引用/38 指令——生产 E2E 即第二切口切换守护 + 退出码五路径[run 0 / check 缺文件 2 / bogus 2 / 无参 2 / eval 退役 2]）+ bench 三轮稳态 **71.200/70.757/71.322ms 带内**（OBS-C <65ms 不满足——零消费方维持）+ 语料六族 grep 零信号 + 三语料诊断锚 **319/145/193 第十四轮独立复验** + TD 开放 P0/P1 = 0
- **测试计数**：973 → **997（净 +24** = cli_krf_parity_tests 23[runner] + bootstrap_cli 活性探针 1[单元]——**997 基线自 r79 起**）
- **TD-032 状态推进**：首切口 build.krf（模块解析面）✅ r74 + **第二切口 cli.krf（CLI 编排面）✅ r79**——余下三切口 = 测试入口 / 测试运行器 / 缓存段（维持 T3+ 触发式 + 用户指令续窗口径——登记册 v0.4.6-r79）；**T3+ 触发族 14 行判定零变化**（本轮开的是外源窗 TD-032 续窗——非 T3+ 行，待触发态维持）
- 对账链：matrix r79 行 + 总量行 997 注记 + 本节 + rec 43（03 层）+ t3plus v1.3 r79 注记 + TD 登记册 v0.4.6 + 指南 v1.1 #17 状态更新 + 层 l 双更新 + 外根第三链镜像 + 打包 v1.0.0-r79（149-z）+ web r79 节点（149-web）

## r78（v1.0.0-r78）——触发族全表监测轮 + 手动触发指南交付（14 行例行监测 + 用户括号义务兑现 + 第七次零信号复现）

- **用户驱动源**：「按照 docs/sop.md 流程结合 docs/lang-design/ 下的项目演进流程 与 docs/develop/v0/tech-debt-register.md，按照推荐的先后任务顺序开始继续 docs/develop/v0/stage-3/t3plus-trigger-audit.md 触发族全表（如果没有执行，你最后必须给我一个所有触发任务的列表和如何触发以及推荐顺序（你不说如何触发，我怎么手动触发？））」+「同步完整打包项目 tar.gz 并同步完整更新web page」——用户点名监测载体 + **括号义务显式交付令**（触发任务全列表 × 如何触发 × 推荐顺序三件）
- **监测主体（148-a）**：§3.2 六命令 clean 起步全绿（cargo clean 670 files/200.7MiB → build --release 16.20s 零告警 → check 0/0 → fmt 0 diff → clippy --workspace --all-targets -D warnings 0 → test --release --workspace **973:0:0 逐位**[725 runner + 248 单元]）+ 六审计集 **280 case EXIT 0 ×6**（stage0 41 + stage1 50 + stage2_r1 53 + stage2_r2 46[宽窄双口径 45+1 判别沿用] + stage3_m3 43 + stage3_e5close 47）+ CLI 四路径逐字一致（fib 75025/⇒144 + higher_order (1 4 9 16 25) + closures ⇒42 + check ok：2 原型/9 常量/5 全局引用/38 指令）+ bench 五轮 **72.846/75.717/71.110/71.310/71.135ms**（稳带 71.1-71.3ms——OBS-C 触发线 <65ms 不满足，零消费方维持）+ 语料六族 grep 零信号（match 用户面 `(match\s` 0——宽口径 35 全为 match-* 连字引擎私有函数族与注释[expander.krf 29 + compiler.krf 6] + net/extern/@ 0 + syntax-parse 1 = TD-005 注记本体 + **vector `#(` 0——r71 首测起八轮连续零命中** + 嵌套省略号严格形 0[宽命中全为注释形]）+ 三语料诊断锚 **319/145/193 第十三轮独立复验**（stderr 合流口径）+ TD 开放 P0/P1 = 0
- **净增量（148-b）——[t3plus-manual-trigger-guide.md](docs/develop/v0/stage-3/t3plus-manual-trigger-guide.md) v1.0**：用户括号义务「你不说如何触发，我怎么手动触发」的兑现载体——①**全部触发任务总列表**（23 项 = 14 触发族行 + 4 外源窗[目标语言切换/TD-031 M1-M3/TD-032 四切口/HM 默认期] + 7 门控任务[新 Reader ~3000 行/编译器源码切换 3550 行/fixpoint 复验/语料迁移/文档刷新等]——去重 21 唯一项，每项持自然触发判据 + 手动触发指令 + 触发后首步）；②**三种手动触发形态**（M1 指令开窗「开启 X 窗——实施 Y」/ M2 语料消费提交 / M3 提案载体——r74 用户显式指令开窗先例的操作化普适，红线 1/3 合规）；③**推荐先后顺序五级**（第 1 位目标语言设计讨论主线[解锁 9 项——用户 r74 已预告]→ 第 2 位 TD-032 构建系统续窗[首切口已生产切换]→ 第 3 位 TD-031 WasmBackend M1-M3[契约层已做实]→ 第 4 位 HM 默认期生产切换[PoC 已验证]→ 第 5 位 T3+ 其余按需对号）；④**触发指令速查卡**（复制即用——每条指令的响应契约：PHASE 1 路由 → 开窗判据回填 → ARCH-A+PM-A 双确认 → GATE 1-5 → 投票收口）
- **零信号维持裁定**：触发族全表 14 行判定零变化——**待触发态维持**（红线 1[禁止时间驱动] + 红线 3[零判据不得开窗]——r56 → r68 → r72 → r73 → r76 → r77 后第七次全表监测同构复现）；TD-031/032 维持 P3 触发式；节点维持「技术就绪 + 治理待触发」——**手动触发能力已操作化交付**（下一演进 = 信号触发或用户按指南手动行权）
- **r78 实测证据基线**：见监测主体（零代码轮零回归——973 基线自 r75 起连续四轮[r75 净+6 → r76 恢复维持 → r77 监测维持 → r78 监测+指南维持]）
- 对账链：matrix r78 行 + 总量行 r76/r77/r78 维持注记 + 本节 + rec 42（03 层）+ t3plus v1.2 r78 例行监测注记 + 手动触发指南 v1.0 + 层 l 双更新 + 外根第三链浓缩条目 + 打包 v1.0.0-r78（148-z）+ web r78 节点（148-web）

## r77（v1.0.0-r77）——触发族全表监测轮（t3plus 14 行例行监测 + 零信号维持 + 第十二轮锚复验）

- **用户驱动源**：「按照 docs/sop.md 流程结合 docs/lang-design/ 下的项目演进流程 与 docs/develop/v0/tech-debt-register.md，按照推荐的先后任务顺序开始继续 docs/develop/v0/stage-3/t3plus-trigger-audit.md 触发族全表」+「同步完整打包项目 tar.gz 并同步完整更新web page」——用户点名监测载体（触发族全表 = [t3plus-trigger-audit §2](docs/develop/v0/stage-3/t3plus-trigger-audit.md) 14 行——零信号下推荐任务顺序的合法形态 = 例行监测 + 状态对账 + 交付三件套，r60/r61/r68 监测轮先例同构）
- **监测主体（147-a/147-b）**：§3.2 六命令 clean 起步全绿（cargo clean 670 files/200.7MiB → build --release 16.38s 零告警 → check 0/0 → fmt 0 diff → clippy --workspace --all-targets -D warnings 0 → test --release --workspace **973:0:0 逐位**[725 runner + 248 单元]）+ 六审计集 **280 case EXIT 0 ×6**（stage0 41 + stage1 50 + stage2_r1 53 + stage2_r2 46[45 `^[` case 行 + P05 行前缀 `kerf[PASS]` 已知形态对账——write_stdout 真 I/O 无换行产物] + stage3_m3 43 + stage3_e5close 47）+ CLI 四路径逐字一致（fib 75025/⇒144 + higher_order (1 4 9 16 25) + closures (4 2)/⇒42 + check ok：2 原型/9 常量/5 全局引用/38 指令）+ bench 三轮稳态 **70.748/71.310/70.653ms 带内**（OBS-C 触发线 <65ms 不满足——零消费方维持）+ 语料六族 grep 零信号（match 用户面 `(match\s` 0——宽口径 35 全为 match-* 连字引擎私有函数族与注释[expander.krf 29 + compiler.krf 6，r72 锚逐字一致] + net/extern/@ 0 + syntax-parse 1 = expander.krf TD-005 注记本体 + **vector `#(` 0——r71 首测起七轮连续零命中** + 嵌套省略号严格形 0[宽命中 3 全为注释/平行单层文档形]）+ 三语料诊断锚 **319/145/193 第十二轮独立复验**（stderr 合流口径——r76 R4 纪律沿用）+ upload 零新增（12 文件）+ TD 开放 P0/P1 = 0
- **零信号维持裁定**：触发族全表 14 行判定零变化——**待触发态维持**（红线 1[禁止时间驱动] + 红线 3[零判据不得开窗]——r56 首版 → r68 → r72 → r73 → r76 后第六次全表监测同构复现）；TD-031（WasmBackend M1-M3 三判据）/TD-032（构建系统余下面四切口）维持 P3 触发式；节点维持「技术就绪 + 治理待触发」（r70-r76 七轮裁定链 + 本轮例行复核——下一演进 = 信号触发或用户显式指令[目标语言设计讨论预告在册]）
- **r77 实测证据基线**：见监测主体（零代码轮零回归——973 基线自 r75 起连续三轮[r75 净+6 → r76 恢复维持 → r77 监测维持]）
- 对账链：matrix r77 行 + 总量行 r76/r77 维持注记 + 本节 + rec 41（03 层）+ t3plus r77 例行监测注记 + 层 l 双更新 + 外根第三链浓缩条目 + 打包 v1.0.0-r77（147-z）+ web r77 节点（147-web）

## r76（v1.0.0-r76）——恢复轮（环境回落事件 + 上传包全量恢复 + 旧包清理 + web 补链）

- **用户驱动源**：「清理掉所有的旧包（z.ai 在web 端保留的数据和超过自动丢失会导致最新部分内容丢失）+ 使用上传版本包（kerf-v1.0.0-r75-implaudit-hmmultierr-973tests.tar.gz）替换掉当前回落至旧版本内容的项目内容 + 按照 docs/sop.md 流程结合 docs/lang-design/ 下的项目演进流程 与 docs/develop/v0/tech-debt-register.md，继续推进任务 + 同步完整打包项目 tar.gz 并同步完整更新web page」
- **恢复主体（146-a）**：r53 回落态全量替换为 r75 终态（git 单笔 209e0b7，357 tracked files，工作树 clean）——§3.2 六命令 clean 起步全绿（build 16.83s 零告警 + check + fmt 0 diff + clippy 0 + **973:0:0 逐位零漂移**）+ 六审计集 EXIT 0 ×6（e5close：E5 出口三条件全绿——v1.0.0 发布就绪）+ CLI 四路径逐字一致（fib 75025/⇒144 + higher_order (1 4 9 16 25) + closures ⇒42 + check ok：2 原型/9 常量/5 全局引用/38 指令）+ bench 三轮稳态 70.810-71.055ms 带内 + 三语料诊断锚 319/145/193 第十一轮独立复验（α377 在位）
- **旧包清理（146-b）**：download/ 52 旧 tar.gz 清零（85MB）——仅保留最新交付包策略（z.ai web 端数据保留超限自动丢失风险对齐）；upload/ 恢复权威源保留
- **工具链重装实录（§3.1）**：环境为重置后新沙箱（与回落事件同源）——cargo 不在位；项目自带 scripts/rust/setup.sh 安装 → rustc 1.98.1（与 r52 基线环境记录完全一致）
- **信号纪律**：本轮用户指令未点名新实施窗——TD-031/032 与 t3plus 14 行持触发判据零信号维持；节点维持「技术就绪 + 治理待触发」（r70-r75 六轮裁定链）；合法推进形态 = 恢复 + 承接 145-web + 监测复验 + 交付三件套（r68/r73 先例同构）
- **r76 实测证据基线**：§3.2 六命令全绿（test **973:0:0**）+ 六审计集 280 case ×6 + CLI 四路径 + bench 带内 + 三语料锚第十一轮一致 + TD 零新登记（开放 P0/P1 = 0 维持）
- 对账链：matrix r76 行 + 本节 + rec 40（03 层）+ 12-roadmap v6.21（恢复轮注记）+ 层 l 双更新 + 外根浓缩条目

## r75（v1.0.0-r75）——审查推进轮（两点名面实现状态与完整性审查 + HM 多错误收集 PoC 深化）

- **用户驱动源**：「按照 docs/sop.md 流程结合 docs/lang-design/ 下的项目演进流程 与 docs/develop/v0/tech-debt-register.md，继续推进任务（**HM/typecheck .krf 路径验证， 构建系统重写（driver .krf 化）**）**审查实现状态并完整性**」+「同步完整打包项目 tar.gz 并同步完整更新 web page」——r74 四窗交付的两点名面复验与续推
- **审查轮主体（145-b/c/d + r75-implementation-audit.md v1.0）**：①全仓基线复验——§3.2 六命令 clean 起步全绿（build 16.53s 零告警/check 0/0/fmt 0/clippy 0/**967:0:0 逐位复现**）+ 六审计集 280 case EXIT 0 ×6 + CLI 四路径 + bench 稳态带内 + 三语料锚 319/145/193 第十轮一致 + 六族 grep 零信号；②HM .krf 路径逐件审查全绿（check.krf 757 行语义臂齐备 + 入口复位纪律 + wire 协议单源 + parity 19 复跑 + **生产面不动核验**——hm_check_program 唯二生产入口 + krf 路径零生产消费）；③构建系统首切口逐件审查全绿（build.krf 语义移植完整 + **生产切换双消费点实测生效** + 种子豁免条款在档 + parity 14 复跑 + TD-032 登记一致）；④**TD-032 余下面就绪图**——四切口（缓存段[技术+信号双阻塞]/CLI 编排[待工具链指令]/测试运行器/测试入口[各自续窗]）全持信号纪律：泛指指令不开面级窗（红线 3）
- **推进件（145-e——HM 多错误收集 PoC 深化·项级恢复）**：Rust 面约束级 drain 语义锚（CLI probe ×9）→ check.krf TC-DIAGS 累积 + tc-check-items 项级恢复（诊断中止继续后续项）+ 入口三形（单错误形态保持——原则 27 加性；('diags ((msg s e) ...)) 源序新形）+ 桥 KrfDiagItem/Diags 变体 + **hm_krf_path 19 → 25 case**（计数 parity 4[项间双错/三错/module 体/顶层 do splice] + 诚实边界守卫 2[嵌套应用项内多错 Rust 3 vs 本机 1；失败 define 后续调用吸收 Rust 2 vs 本机 1]——双轴残留边界归未来生产切换窗两阶段架构义务）；**967 → 973:0:0 净 +6 零回归**
- **开发实录（R4）**：顶层 do 为 module 级 splice（r49 D59）——单 do 形双错预判失效实为项间独立错误（计数 parity 达成，预判失效转化为 parity case）——**项粒度预判必须以 expander 项位分类实况为准**（r73「语料以仓库示例实读为锚」教训的架构面补充：语料形态锚 + 项位分类语义锚双锚）；check.krf 自身语料 E0005 21→22（git stash 对照净 +1——旗标期策略豁免类一致性注记）
- **r75 实测证据基线**：§3.2 六命令全绿（test **973:0:0**）+ 六审计集 280 case ×6 + CLI 四路径 + bench 三轮稳态 71.007/70.948/70.880ms 带内（首轮 73.461ms 冷启动噪声实录）+ 三语料锚第十轮一致 + 六族 grep 零信号 + TD 零新登记（多错误深化为 PoC 范围非债务项；开放 P0/P1 = 0 维持）
- 对账链：matrix r75 行 + 本节 + rec 39（03 层）+ r75-implementation-audit.md + 12-roadmap v6.20（§2.5.1 类型检查器行 r75 后记）+ 层 l 双更新 + 外根浓缩条目

## r74（v1.0.0-r74）——用户显式指令四窗推进轮（HM/typecheck .krf 路径验证 PoC + WasmBackend 组件模型契约层 + 构建系统首切口生产切换 + 目标语言门控任务清单）

- **用户驱动源**：「按照 docs/sop.md 流程结合 docs/lang-design/ 下的项目演进流程 与 docs/develop/v0/tech-debt-register.md，继续推进任务（**HM/typecheck .krf 路径验证， WasmBackend 组件模型， 构建系统重写（driver .krf 化）， 先完成非S表达式转化目标语言后才能实现的任务，最后会给机会深入深度和广度的探讨目标语言的相关设计**）」+「同步完整打包项目 tar.gz 并同步完整更新 web page」——r73 状态报告 §E 决策点 2（显式指定方向）行权形态
- **开窗判据回填（144-a——r74-window-opening.md v1.0）**：四窗开启依据 = 用户显式指令（红线 1/3 合规——非时间驱动非自主开窗）；三实施窗形态刻意收敛为**验证/契约/切口**三形态（PoC + 契约做实 + 第一切口）；表面语法切换窗**不开**（入口信号 = 用户预告的目标语言设计讨论——target-language-gated-tasks §1 登记）
- **HM/typecheck .krf 路径验证 PoC（144-b）**：`bootstrap/check.krf` 迷你 HM 推断机（类型格 tvar/tcon/tpair/tfun + 合一[occurs/数值格/Dynamic 吸收] + 格 join + 值限制泛化 + 递归预置 + 内置签名子集表——Rust hm.rs 子集语义逐臂镜像）在 VM 上运行；`bootstrap_check.rs` 桥（与 bootstrap_compiler.rs 同构——item_to_node wire 协议单源复用）；**parity 19 case 全绿**（accept/reject 16[正 4：fib 递归/let 多态/闭包工厂/字符串全序；负 12：算术串参/if 非 bool/元数/不可调用/let 冲突/assign 冲突/not 非 bool/head 非 pair/混合比较/module 内错/eq 上界/实参注入] + perform/handle 诚实边界 2 + Span 1）——B 类形态 2 替换候选（HM 中窗）可替换性实证；**非生产切换**（INC8/K3：判定面维持 hm_check_program）
- **WasmBackend 组件模型契约层（144-c）**：`kerf-backend/wasm.rs`——InterfaceType（primitive 族 + record/variant/tuple/list/option/result/func + render + 深界）+ ComponentImport/Export + CanonicalAbiOptions（utf8/utf16 + memory64 + realloc 锚）+ CoreModuleFunc + WasmComponentModel（版本 + 清单 + 边界 + ABI + 源指纹链）+ ComponentModelBuilder（fail-closed 五校验）+ component_model_from_anf（M0 派生件）；**8 契约测试**；`WasmComponent` 自字节信封演化为「bytes + model」双字段（原则 27 加性演化——Default 兼容 + trait 签名零变化）；零外部依赖（§18）；M1-M3 触发式维持——**TD-031 登记**（wasm-backend-component-model.md v1.0——kerf 值域↔接口类型映射表 + 分阶段路线）
- **构建系统首切口生产切换（144-d）**：`bootstrap/build.krf`（lbld-imports-prelude? 入口——Stx 六头字段协议消费，imports_prelude 全语义移植）+ `bootstrap_build.rs` 桥 + **生产切换**（resolve_prelude_imports 判定经 VM——07 §3.3 Stage 2→3 信号「构建系统可用新语言重写」**首个生产实证**）；**种子管线豁免条款**（种子路径判定用 imports_prelude_seed Rust oracle——阻断 build.krf 加载自引用[实测 RefCell 重入当轮根治]）；parity 12 case + 生产 E2E 双向 2 + 桥单元 1；Rust 版退役为 parity oracle；余下面（缓存段/CLI 编排/测试运行器）登记 **TD-032**
- **目标语言门控任务清单（144-e）**：target-language-gated-tasks.md v1.0——七项门控任务（新 Reader/编译器语料切换/fixpoint 复验/语料库迁移/TD-002 向量/match 用户面/文档刷新）+ 前置可推进项总账（五项——两项判据面已前置 + 本轮两项能力旁证 + 治理链）
- **文档同步六件（144-f）**：07 v6.5（§3.2 构建段首切口 + 静态分析验证路径注记）/ 08 v6.5（WasmBackend 组件模型注册）/ 12 v6.19（§2.5.1 类型检查器行 r74 PoC 注记）/ TD 登记册 v0.4.5（TD-031 + TD-032 双登记）/ t3plus-trigger-audit r74 开窗消费注记（**14 行 T3+ 判定零变化**——用户指令开外源窗非 T3+ 行）/ bootstrap-replacement-surface-map §5（缺口 4/6/7 ✅ r74 兑现——结论 r74 增量）
- **r74 实测证据基线**：§3.2 六命令 clean 起步全绿（cargo clean 621 files → build --release 17.26s 零告警 → check 0/0 → fmt 0 diff → clippy -D warnings 0 → test --release --workspace **967:0:0 净增 44**——集成 710 + 单元 257）+ 六审计集 280 case EXIT 0 ×6 真实复跑 + CLI 四路径全过 + **bench 70.798ms 带内**（生产切换开销可忽略）+ 三语料诊断锚 319/145/193 逐字一致（第九轮独立复验）
- 开发实录四则：①check.krf 值位 false 不被 is-abort 捕获（tc-fail 布尔通道/tc-failv 诊断值通道分离——诊断值与布尔不可同形）②drop 两边界（参数序 (drop lst k) + 零字段 (module) 守卫——kerf drop 越界报错 vs Rust skip 静默钳制的语义差）③handle 标签必须符号（语料实读对照锚定——r73「PoC 语料以仓库示例实读为锚」教训延续）④种子管线自引用（build.krf 加载中两入 = RefCell 重入 + 无限递归——种子豁免条款根治，P1 硬约定的同构扩展）
- 对账链：matrix r74 行 + 本节 + rec 38（03 层）+ r74-window-opening.md + wasm-backend-component-model.md + target-language-gated-tasks.md + 层 l 双更新 + 外根浓缩条目

## r73（v1.0.0-r73）——缺口复核与状态报告轮（用户条件分支交付 + 零信号维持 + 节点论证第四轮复核）

- **用户驱动源**：「按照 docs/sop.md 流程结合 docs/lang-design/ 下的项目演进流程 与 docs/develop/v0/tech-debt-register.md，**自举将S表达式到目标语言的过程中还缺少什么任务就继续推进任务**（如果当前需要我指令才进行推进则需要给出当前项目状态和编译器阶段与任务推进情况和演进节点等相关信息，**如果项目演进流程节点到达切换S表达式到目标语言节点则可以直接说明并给出具体项目情况，以论证当前能力和节点**）」+「同步完整打包项目 tar.gz 并同步完整更新web page」
- **缺口清单七项复核（143-a——bootstrap-replacement-surface-map §5 常设对账表）**：③替换面识别（r71 ✅ 兑现）+ ⑤TD-002 向量裁定（r71 ✅）两项已完成；余五项（①目标语法消费信号 ②新 Reader 本体 ④HM .krf 路径验证 ⑥WasmBackend 占位 ⑦构建系统重写）全部持显式触发判据且**零信号维持**——**路径上无任何可在零信号下推进的实施任务**（23 §2.3 红线 3——禁止无信号开窗）
- **节点答复（指令条件分支）**：**节点未到开窗位——技术就绪 + 治理待触发**（139-a r70 裁定 + 141-a r71 复核 + 142-a r72 重审三轮裁定链 + 本轮 r73 第四轮例行复核）：能力三项全过（Stage 2a fixpoint r69 实证 + E5 → v1.0.0 现代表面收敛 + 原则 31 皮肤/骨架分离架构保证——五步流程机制全在位）；治理闸门零信号（14 行触发族 + 外源三窗全零命中）；开窗六步前置清单步 6（B 类替换面识别）r71 前置完成——评审收敛为信号确认 + L3 分派
- **状态报告交付（rec 37 五节载荷 + 终态响应承载）**：A 项目状态快照（v1.0.0 + 包链 r52→r73 二十二轮 + 923:0:0 + TD P0/P1=0 + 演进治理文档族四件套）/ B 编译器阶段全景（Stage 0-3 全收口 + T3+ 待触发态 + 后端策略 + 自举混合期构成）/ C 二十一轮任务推进全链（三件优化窗 + 九段吸收链 + 空间/真值/治理四件套 + 监测轮）/ D 演进节点表（待触发 14 行 + 外源三窗 + 切换节点判定）/ E 用户三决策点
- **例行监测全项过**：§3.2 六命令 clean 起步全绿（cargo clean 670 files/193.9MiB → build --release 16.15s 零告警 → check 0/0 → fmt 0 diff → clippy --workspace --all-targets -D warnings 0 → test --release --workspace **923:0:0 逐位**——纯监测报告轮零代码变更零回归）+ 六审计集 **280 case EXIT 0 ×6 真实复跑**（stage0 41 + stage1 50 + stage2_r1 53 + stage2_r2 46 + stage3_m3 43 + stage3_e5close 47——E5 出口三条件全绿「v1.0.0 发布就绪」）+ CLI 四路径（fib 75025/⇒144 + higher_order (1 4 9 16 25) + closures ⇒42 + check ok）+ bench 三轮 **70.957/71.014/71.543ms 带内**（OBS-C <65ms 不满足）+ 语料六族 grep 零信号维持（match 用户面 0[自举语料 35 命中全为 match-* 连字引擎私有函数族——expander.krf 29 + compiler.krf 6] / net-extern-@ 0 / syntax-parse 1 = TD-005 注记本体 / **vector `#(` 0——r71/r72/r73 三轮连续零命中**）+ 三语料诊断锚 **319/145/193 逐字一致**（r53 锚八轮独立复验）
- 对账链：matrix r73 行 + 本节 + rec 37（03 层）+ 层 l 双更新（03 树导航覆盖 r38-r73 + 表行 37 / 根 l 未压实区间 + by-topic）+ 外根浓缩条目 + 打包 v1.0.0-r73（143-z）+ web r73 节点（143-web）

## r72（v1.0.0-r72）——t3plus 触发态审计文档五问重审轮（完整性/边界覆盖/定位/选项合理性/符合要求 + 四项实况漂移当轮清偿）

- **用户驱动源**：「结合当前项目 docs/lang-design/ 和 docs/sop.md 进行对 t3plus-trigger-audit.md 的重审（内容不限于是否完整 / 能否覆盖完整能力边界和职责边界 / 具备清晰定位 / 选择的项是否合理 / 是否符合要求等）」+「按照 docs/sop.md 流程结合 docs/lang-design/ 下的项目演进流程 与 docs/develop/v0/tech-debt-register.md，自举将S表达式到目标语言的过程中还缺少什么任务就继续推进任务（……如果项目演进流程节点到达切换S表达式到目标语言节点则可以直接说明并给出具体项目情况，以论证当前能力和节点）」+「同步完整打包项目 tar.gz 并同步完整更新web page」
- **重审五问结论（142-a——t3plus-trigger-audit.md v1.0 → v1.1，新增 §8 重审记录）**：①完整性——v1.0 时点合格、r71 TD-002 向量入族后计数陈旧（13→14 未回填，P2）；②能力/职责边界覆盖——职责边界三处显式一致合格、能力边界有一处缺口（「全族」未对账外源触发窗 HM/Wasm/构建系统，P3）；③定位清晰性——合格（单源权威 + 证据层 + 监测锚三层角色一致）；④选项合理性——合格（14 行逐行溯源单源锚 + 四列结构 + TD-008 样板形态统一）；⑤符合要求——三项缺口（监测矩阵 vector 落表缺 P2 + 版本档案停滞 P3 + 计数陈旧——均为 r71 增补的声明-实况漂移：实践已执行、文档本体未兑现）
- **四项实况漂移当轮全清（§8.2 修正清单）**：①触发族计数 13→14（TD-002 向量回填 §1 范围公式 + §2 表第 14 行[T3+ 三判据 + `#(` 0 命中] + §5 结论）；②§4 监测矩阵表格本体落实 r71 声明的 vector 字面量族（首行信号源 + 六族口径——声明-实况漂移修正）；③版本档案 v1.1 恢复（r70/r71 两轮增补注记未过版本行补偿登记）；④§5 结论补外源触发窗姊妹对账引用（bootstrap-replacement-surface-map §5 分工声明）——**修正后五问全过，重审不改变任何触发判定**
- **节点答复（指令条件分支）**：139-a/141-a 裁定维持——**节点未到开窗位（技术就绪 + 治理待触发）**，触发族经 r72 重审复核后为 **14 行全族零信号**（match 用户面 0——自举语料 35 命中全为 `match-*` 连字引擎私有函数族与注释；net/extern/@ 0；syntax-parse 1 = TD-005 注记本体；vector `#(` 0；OBS-C bench 三轮 70.841/70.751/70.821ms <65ms 不满足）——红线 3 维持待触发态；本轮可推进面 = 审计文档完整性维护（重审修正即缺口推进——治理债 P2×2 + P3×2 当轮清偿，TD 零新事件维持开放 P0/P1 = 0）
- **r72 实测证据基线**：§3.2 六命令 clean 起步全绿（build 15.76s 零告警/check 0/0/fmt 0/clippy 0）+ **923:0:0 逐位零回归**（重审轮零代码变更）+ 六审计集 280 case EXIT 0 ×6 真实复跑 + CLI 四路径全过（fib 75025/⇒144 + higher_order (1 4 9 16 25) + closures ⇒42 + check ok：2 原型/9 常量/5 全局引用/38 指令）+ 三语料 check 诊断 A/B 锚 319/145/193 逐字一致（r53/r56 锚独立复验成立）
- 对账链：matrix r72 行 + 本节 + rec 36（03 层）+ t3plus-trigger-audit v1.1（§8 重审记录 + 四项修正）+ 层 l 双更新 + 外根浓缩条目

## r71（v1.0.0-r71）——自举替换面识别轮（S 表达式 → 目标语言路径缺口推进——B 类前瞻义务识别兑现 + TD-002 dangling 再裁定）

- **用户驱动源**：「按照 docs/sop.md 流程结合 docs/lang-design/ 下的项目演进流程 与 docs/develop/v0/tech-debt-register.md，**自举将S表达式到目标语言的过程中还缺少什么任务就继续推进任务**（如果当前需要我指令才进行推进则需要给出当前项目状态和编译器阶段与任务推进情况和演进节点等相关信息，**如果项目演进流程节点到达切换S表达式到目标语言节点则可以直接说明并给出具体项目情况，以论证当前能力和节点**）」+「同步完整打包项目 tar.gz 并同步完整更新web page」
- **节点答复（先于执行的直接论证）**：r70/139-a 裁定维持——**节点未到开窗位（技术就绪 + 治理待触发零信号）**；按指令「还缺少什么任务就继续推进」识别路径缺口并推进**唯一可不违红线 3 前置兑现的缺口**（B 类替换面识别）+ R1 dangling 检测成果（TD-002 向量）
- **替换面识别图（141-a——bootstrap-replacement-surface-map.md v1.0 新件）**：B 类前瞻义务（136-a §5.3 前瞻纪律第 1 条 + 139-a §5.2 开窗六步清单步 6）的**识别兑现载体**——逐段五问（生产角色/自举状态/三分法对号/替换窗口/前瞻义务）× 全链：**§3.1 C 类语料 4 行**（read/expand/compile/preamble .krf 3550 行——目标语法改写对象）+ **§3.2 B 类形态 1 oracle 三段**（kerf-reader/kerf-expander/kerf-compiler compile.rs——种子引导 + parity oracle 存档，替换已完成非候选）+ **§3.3 B 类形态 2 替换候选三行**（HM/typecheck 1846 行[中窗——HM 默认期触发式，INC3 可选替换] + IrGraph 1379 行[远窗——TD-003/015 三判据] + driver 组合根 3069 行[最远窗——07 §3.3 Stage 2→3 信号]——**B 类优化推迟义务的正对象 + 窗口远近**）+ **§3.4 A 类永久基座八行**（VM/eval 存档/runtime/builtins/宿主桥三件 2275 行[数字类型边界宿主职责]/诊断/宿主服务/后端+骨架）+ **§3.5 新 Reader 未来面**（~3000 行蓝图 + 07 §3.2.1 五步流程路径 + match 信号触发）；**§4 三用法**（优化开窗前置对号 / 目标语法轮开窗评审直接引用——**步 6 识别前置完成，评审收敛为信号确认 + L3 分派** / 缺口常设对账）
- **缺口清单七行（§5——「还缺少什么」的常设对账表）**：①目标语法消费信号（治理闸门——r71 例行监测零命中）②新 Reader 本体 ~3000 行（待信号）③~~B 类替换面识别~~**✅ 本轮兑现**④HM/typecheck .krf 重写路径验证（HM 默认期窗口触发式）⑤TD-002 向量 dangling**✅ 本轮再裁定**⑥WasmBackend 组件模型（T3+ 占位）⑦构建系统重写（Stage 2→3 信号未触发）——**结论：路径上无任何可在零信号下推进的实施任务（红线 3）；本轮可推进面 = 识别 + 裁定 + 监测全部兑现**
- **TD-002 向量部分 dangling 再裁定（R1 检测成果——r56 审计 13 行未覆盖）**：索引行声明「向量开放→Stage 2」但 Stage 2 已 r37 收口未交付（`LiteralValue` 无 Vector 变体 + expander.rs `StxDatum::Vector(_) => Err` 显式报错实证——状态列「已解决（符号 r5）」部分标记掩盖向量开放）→ **T3+ 触发式三判据**（语料 vector 字面量消费[当前 `#(` 0 命中] / 目标语法轮联动[目标语法自然携带集合字面量] / FFI 编组消费[与 TD-026 判据 2 同源]）——TD 登记册 v0.4.4 + 监测矩阵增补 vector 字面量族例行项
- **例行监测（t3plus-trigger-audit §4——r71 注记）**：语料五族零信号维持（match 用户面 0[自举语料命中全为 match-* 连字引擎私有函数族] + net/extern/@ 0 + syntax-parse 1 = TD-005 注记本体 + **vector `#(` 0 命中新增项**）+ bench 三轮 71.580/70.790/71.708ms 带 r70 内一致（OBS-C <65ms 不满足）+ CLI 四路径全过
- §3.2 全绿：**923:0:0 零回归**（识别轮零代码变更——build 15.64s 零告警/check 0/0/fmt 0/clippy 0/test 逐位）+ **六审计集 280 case EXIT 0 ×6 真实复跑** + CLI 四路径 + bench 带内
- 对账链：matrix r71 行 + 本节 + rec 35（03 层）+ t3plus-trigger-audit r71 注记 + bootstrap-replacement-surface-map 新件 + TD 登记册 v0.4.4 + 层 l 双更新 + 外根浓缩条目

## r70（v1.0.0-r70）——表面语法切换节点判定轮（S 表达式 → 目标语言——技术就绪 + 治理待触发裁定）

- **用户驱动源**：「按照 docs/sop.md 流程结合 docs/lang-design/ 下的项目演进流程 与 docs/develop/v0/tech-debt-register.md，继续推进任务（如果当前需要我指令才进行推进则需要给出当前项目状态和编译器阶段与任务推进情况和演进节点等相关信息，**如果项目演进流程节点到达切换S表达式到目标语言节点则可以直接说明并给出具体项目情况，以论证当前能力和节点**）」+「同步完整打包项目 tar.gz 并同步完整更新web page」
- **节点判定（139-a——surface-syntax-switch-assessment.md v1.0 新件）**：「切换 S 表达式到目标语言」= Stage 2b 语法替换节点——**裁定 = 技术就绪（能力闸门三项全过）+ 治理待触发（信号闸门零命中），切换不发生于本轮**。能力论证：①Stage 2a 完全自举达成（fixpoint 两次编译自身字节一致 r69 实证 + 前端三段 3550 行 .krf 生产自举 + VM 唯一路径 INC7）②现代表面收敛（E5 窗 r42-r51 全闭 → v1.0.0：fn/assign/do 现代关键字 + 旧名 27 件退役 + 「1970 表面」清算完毕）③架构保证在位（原则 31 皮肤/骨架分离——任何表面语法编译产物为相同 CoreExpr + 02 §8 可插拔 Reader 蓝图 + reserved/codegen.rs 路径恒有效先例）。治理核对：23 §2.2「目标语法轮」T3+ 触发式（r56 操作化）——match 表面消费信号 0 命中 + net/extern/@ 0 命中 + OBS-C <65ms 不满足（bench 三轮 70.929/70.942/71.214ms）→ 红线 3「禁止无信号开窗」维持待触发态。路径对照（07 §3.2.1）：kerf 实况 = 渐进式皮肤现代化（E5 九腿分段）而非蓝图一次性替换——两条合法路径收敛点相同，E5 已兑现 Stage 2b 的可渐进部分；开窗六步前置清单落档（信号命中 → 证据回填 → 双确认 → L3 全流程 → 五步流程执行 → B 类替换面识别[联动 r69 三分法]）
- **t3plus-trigger-audit §4 增补**：r70 专题证据层注记（「目标语法轮」行深挖判定载体——136-a 先例同构，23 §2.2 单源权威不变）
- **层 l r69 压实缺口清偿（R4 实录第六实例后续）**：137-a 声明「层 l 覆盖 r38-r69 + 33 表行正序追加」与实况不符（未压实区间止 r68 / 03 树导航覆盖列止 r68 / by-topic 无 r69 行）——本轮一并补齐 r69 + r70 双条目（声明-实况漂移当轮修复口径）
- §3.2 全绿：**923:0:0 零回归**（判定轮零代码变更——build 15.83s 零告警/check 0/0/fmt 0/clippy 0/test 逐位）+ CLI 四路径 + bench 三轮带内（OBS-C 维持零信号）
- 对账链：matrix r70 行 + 本节 + rec 34（03 层）+ t3plus-trigger-audit r70 注记 + surface-syntax-switch-assessment 新件 + 层 l 双条目（r69 清偿 + r70）+ 外根浓缩条目

## r69（v1.0.0-r69）——空间导入导出整理与自举审查（kerf_space 转发链单径化 + lib.rs/mod.rs 清洁化 + 性能优化重复性三分法裁定）

- **用户驱动源**：「整理当前项目中对 kerf_space 的导入和导出（当前在项目中对于空间管理存在一些问题，并整理所有的 lib.rs 和 mod.rs 保持清洁和明确）（同时审理项目其他类似情况是否存在，如果存在则次修正）」+「审查当前项目完整自举进度、自举与拓展接口预留及自举后是否具备完整设计实现能力，同时审查当前对底层的可编程能力，思考判断当前做的性能优化与通过自举后的目标语言实现是否是重复性优化工作，如果不是则可以进行，如果是则推迟到自举后进行（除了不可容忍的性能差距之外）」+ 打包 + web
- **空间导入导出整理（134-a 勘察 + 135-a 修正——六文件 +53/-41 声明级零语义变更）**：**D-1 转发链单径化**（kerf-driver 根 lib.rs `pub use kerf_space::CoreSpace` 直连残留删除——8 marker 统一经 reserved 转发链[组合根转发面设计意图对齐——`reserved::CoreSpace` 死转发面根除]）+ **D-2 impl 段短名化**（18 行全限定 impl → 顶部 use + 短名——与 9 crate「空间从属声明段」形态全同构）+ **D-3 space_proofs.rs 双风格统一**（4 处全限定 → 短名 + `#[cfg(test)] use` 门控）+ **D-4/D-6 测试探针统一**（reserved_ext_tests.rs 三风格 → 短名 + kerf_space 直连可见性锚；reserved/codegen.rs mod tests 内 use）+ **同构两件**（kerf-compiler lib.rs mod/use 交替 → 模块群+导出群；reserved/mod.rs pub(crate) use 后置分组）；**保留不修**（勘察判据）：gate_review_r1.rs 全限定 = 外部可达性锚定故意形态；main.rs kerf-space 依赖 = 24 §7.5 S5 骨架直连组织面（R2 真实设计判定）
- **自举审查（136-a——bootstrap-progress-review.md v1.0 新件）**：五维度结论（①前端三段 100% 生产自举[3550 行 .krf] + Stage 2a 定义满足[fixpoint]；②接口预留完备[20 契约 + 双侧体系 + 路径恒有效实证]；③核心语义全覆盖[九原语+module+require+perform/handle——HM .krf 路径依赖默认期窗口如实登记]；④FFI/门控/pin/AOT 四面做实[net/process/extern 触发式零信号]；⑤**性能优化对象三分法**）——**核心裁定**：A 类 VM/runtime/GC 基座 = 非重复可进行（VM 永久基座 + 自举链恒走 VM——12 §2.5.1 + INC7）；B 类种子编译器段 Rust 逻辑 = 重复性风险**推迟至自举后**（例外：不可容忍性能差距 + 消费方显式诉求）；C 类自举 .krf 语料本体 = 非重复可进行；历史件对号：r54/r55（A 类正当）/ r53（B 类已发生无回退义务——HM <0.3% 收益边际 + 方法论可迁移）；判据联动 t3plus-trigger-audit §4 增补 + 24 §7.5 r69 注记
- §3.2 全绿：**923:0:0 零回归**（组织修正轮零语义变更逐位复跑）+ 审计 ×6 EXIT 0（280 case）+ CLI 四路径 + bench 三轮 71.331/72.009/71.226ms 带内（OBS-C 维持零信号）
- 对账链：matrix r69 行 + 本节 + rec 33（03 层）+ 24 v2.0 r69 注记 + t3plus-trigger-audit r69 联动 + bootstrap-progress-review 新件 + 双 l 镜像 + 外根浓缩条目

## r68（v1.0.0-r68）——信号监测轮与状态报告（T3+ 零信号维持 + 用户条件分支交付 + 外根镜像缺口清偿）

- **用户驱动源**：「按照 docs/sop.md 流程结合 docs/lang-design/ 下的项目演进流程 与 docs/develop/v0/tech-debt-register.md，继续推进任务（如果当前需要我指令才进行推进则需要给出当前项目状态和编译器阶段与任务推进情况和演进节点等相关信息）+ 同步完整打包 tar.gz + 同步完整更新 web page」——T3+ 待触发态零信号 → 条件分支触发，状态报告交付（rec 32 §状态报告：项目状态快照 / 编译器阶段全景表 / r52 以来十六轮任务推进 / 待触发 13 行演进节点表 / 用户三决策点）
- **信号监测全项过（131-a）**：§3.2 六命令全绿 **923:0:0**（纯监测报告轮零回归）+ 六审计集 280 case EXIT 0 ×6（真实复跑）+ CLI 四路径 + bench fib 三轮 70.842/70.869/71.612ms 带内（OBS-C <65ms 触发线不满足）+ 语料五族 grep 0/0/0/0/1 预期（match 宽口径 11 命中 = match-\* 连字函数名假阳性判别实录）+ 三语料 check 诊断锚 319/145/193 逐字一致 + upload 零新增 + TD 开放 P0/P1 = 0
- **零信号维持裁定**：信号监测矩阵 13 行触发族零开窗信号——待触发态维持（红线 1 禁止时间驱动 + 红线 3 零判据不开窗；r56 审计结论 1 同构）
- **外根镜像缺口清偿（132-a）**：项目根 my-project/worklog.md 止于 r65——r66/r67 浓缩条目缺位（130-a「双源」声明仅覆盖 kerf 内部双源，外根 web 侧第三链未枚举）→ 本轮回补 r66/r67/r68 三条 + 裁定外根链入每轮收口镜像纪律
- 对账链：matrix r68 行 + 本节 + rec 32（含状态报告全文）+ 双 l（03 层覆盖 r38-r68 + 32 表行 / 根 l 未压实区间 r68 终态前置）

## r67（v1.0.0-r67）——原语集真值对账与过去形态条例化（lang-design 十件修订 + R12 Let 归约规则补写）

- **用户驱动源**：「当前项目确定的原语是 fn, apply, var, if, literal, assign, let, perform, handle 那么其他的就应该修正或者注明为过去形态条例，无需占据大量内容，可能导致内容歧义或干扰等」——R4 代码为准（expr.rs 现行九变体逐项互锚）
- **lang-design 十件修订**：01 v6.5（§2 规范块换现行九原语 + ModuleItem 声明层块 + 过去形态条例五条）/ 06 v6.3（§1.1 语义域 + §2 规则集对账注 + **R12 Let 归约规则补写**[r45 原语落地后缺位跨 22 轮] + R6/R7/R9 过去形态标）/ 21 v1.7（L1 清单 + §5.2 四要素卡对账 + Let 卡补列）/ 09 v6.12 / 22 v2.5（N4 名面 25 关键字 + §13.3 两轴表 + 派生表现行脱糖目标 + 门 A 终态）/ 20 v1.6（关键字面时态——r43 已执行 + Keyword 22→25）/ 11 v6.4 / 03 v6.4 / 04 v5.3 / 00 v6.8（十件分布 + 正文计数 23→25 顺修）
- **违例清单 15 组全清**（126-a V1-V12 修复 + V13 历史记录天然合规不动 + 计数仍真项不动）+ grep 六组残留模式零残留实证
- **stage0.md v7.2**：空间层级同步核验（§9.13 与 24 v2.0 零漂移——本轮未触及空间层级内容；归档说明文件计数 24→25 顺修）
- **sop v13.3**：§21.12 第 11 条原语集真值对账纪律（真值单一锚/两分法处置/缺位补齐义务/计数漂移防护）
- §3.2 全绿：**923:0:0**（文档轮零回归逐位复跑）+ 审计 ×6 EXIT 0 + CLI 四路径 + bench 71.053ms 带内

## r66（v1.0.0-r66）——核心空间统一规划与双侧统一体系（kerf-space crate + 七核心域 + 命名/结构裁定）

- **双侧统一体系**（lang-design 24 v2.0）：推翻 v1.0「闭集不设 marker」——核心空间显式化（`CoreSpace` + 七核心域[语言/前端/编译/后端/执行/横切/组织——15 §5.3 五轴宏观归并]）+ A1-A7 公理（+A6 开闭性[统一编码、分流治理] + A7 全树统一[物理不判据化]）+ J8 双侧对称判据；做实面归属修复（拓展 L4 种子——A4 L1 互斥恢复）；CodegenBackend/WasmBackend 零挂靠收编
- **kerf-space 骨架 crate**（零依赖 Layer -1——q2 Rust core::marker 同型）：marker 家族物理家迁移（root_space.rs → kerf-space/src/lib.rs）+ 44 核心主类型三层 impl + 20 契约 supertrait 换源 + 双侧证明测试（923:0:0 净+3）
- **改名三连**（N1-N3 命名裁定——设计阶段不考虑兼容）：`ExtensibleRoot`→`RootSpace`（名实修复）/ `ExtensibleSpace`→`ExtensionSpace`（名词族统一）/ `SyntaxDomain`→`MetaprogrammingDomain`（语义自明）；实施裁定：type alias 非从属载体（E0117 机制边界）
- **stage0.md v7.1 §9.13**：lang-design 空间层级内容全量同步（用户独立指令——双侧统一体系五子节镜像 + r65 欠账清偿）
- §3.2 全绿：923:0:0 + 审计 ×6 EXIT 0 + CLI 四路径 + bench 71.020ms 带内

## r65（v1.0.0-r65）——空间层级正交分解（五级从属链 + 20 trait 逐级重挂 + 24 号设计文件）

- **用户驱动源**：「当前对根空间和拓展空间，编译器内部核心空间，的划分和父空间与子空间之间的正交分解性质和抽象与具体之间并没符合设计的需求和要求，编译器本身就是一个空间的根……CapabilityIO 是 Capability 空间下的子项，却跨越空间层级关系这是禁止的……先定性再能力、边界、载定位置从属的先后审理」——**r62 扁平挂靠（全部预留契约直挂根）被判定为跨级违例**。
- **24-space-decomposition.md 新文件（v1.0）**：层级公理 A1-A5（根唯一/层级唯系/唯一从属/正交分解/依赖方向）+ 数学定性四基础（树/正交划分/特化链/开闭集合编码——核心空间=闭集[存在性成员资格]、拓展空间=开集[约束满足成员资格]）+ 六域从属表（能力/效应/语法/优化[零成员空域裁定]/工具链/外域——外域独立：FFI 令牌归能力域、边界机制归外域，协作非从属）+ 类型论编码（五级链 `trait 族: 域: ExtensibleSpace: ExtensibleRoot`）+ J5-J7 空间层正交判据 + 知识搜索四查询实证（Java ClassLoader 三级层级/SoC 正交分解/Rust core-std 分层/Racket namespace 相层级——tool-results/r65-search/）。
- **代码面 20 trait 逐级重挂**：五域 marker（CapabilityDomain/EffectDomain/SyntaxDomain/ToolchainDomain/ForeignDomain）+ ExtensibleSpace 拓展空间 marker；用户点名违例 `CapabilityIO: ExtensibleRoot` → `CapabilityIO: CapabilityDomain`（同类修复 20 处）；Probe 实现体全链四层显式 impl（预留层 17 + 做实面 7[IoFamily/StdCapabilityIO/InMemoryCompilationCache/ValueEffectFamily/ValueEffect/InternalEffectSystem/HeapFfiBoundary] + 集成 tests 10）——「声明即归属」层级版：每一级从属都是显式裁定痕迹，Rust 编译器强制 supertrait 逐层满足（层级由纪律升格为机制）。
- **测试净 +1：920:0:0**（five_level_hierarchy_chain_smoke 五级从属链烟囱测试 + require_domain 域归属证明函数族 20 证明 + 既有根归属证明升级四层链传递闭包）；签名冻结对账（J6）：20 trait supertrait 行变更、签名零变更（原则 27）。
- **审计锚更新**：stage2_gate_audit_r2 S5 锚 lang-design 24→25 文件（文档集扩容连带——r2 复跑 APPROVED）；六审计集 280 case EXIT 0 ×6；CLI 四路径 + bench A/B 零回归（r64 基线同环境 99.7-101.2ms vs r65 98-99ms——跨环境漂移 OBS-C 已登记现象非代码回归）。
- **文档回写**：13 §3.8 v6.9（五大子空间→六大域 + 分形层级代码面落位）+ 21 v1.5 §2.6 增注（J5-J7 挂接）+ 17 原则 40 v7.2 精确化（逐级声明）+ 00 v6.6（25 文件表 + r65 注记）+ matrix 920 总量行 + r65 增量行。

## r64（v1.0.0-r64）——lang-design 全文件集完整梳理与五类缺陷清偿（24 文件四维审计 + 零编译器代码增量）

- **24 文件完整梳理（四维 python 审计 + 内容级复核）**：标题结构 + 跨引用 **1886+ 条五模式全解析**（[NN §X.Y] / [NN-名称 §X.Y](链接) / [17 原则 N] / [sop|stage0 §X] / 链接目标）+ 计数（原则 1-41 列表连续 ✓ / 四十一条 4 处 ✓ / 18 §5a-5h 八节 ✓ / 19 §6-§13 引证编号连续 ✓）+ 版本头全景；内容级 = 24 文件 heading outline 全 dump + 00/17 全文精读 + 13 §3.9 / 11 §5 / 12 §2.11 三节 r63 新增面完备性验证 + r63 关键词锚 7 文件复验——初扫 P1=0，39 P2 全为「父标题直接跟子标题」既有文体假阳性。
- **五类缺陷 28 处清偿（17 文件 +21−32 行纯文档零语义）**：①引用 4 处——`[20 §9.4]` 悬空根因 = 20 的 §9 自 v1.0 为编号列表非子节（列表项缩记误作节号；18 §6 W1003 行自 r42 起真误目标——重锚 [22 §10 D6] W 族值域权威 + 21 D3/22 §7/20 表行同步精确化）②分隔线 3 处（13 §3.8→§3.9 三连[### 同级无分隔线惯例] + 12/22 各一双）③**Date 行滞后 9 文件**（00/01/09/10/18/20/21/22/23——22 最重 v1.5 vs v2.4 十一版；16 git 实证内容自创建未变合法排除）→ r64 增记补正 + 日期降序重排④**Date 行括号失衡 11 文件**（栈追踪定位：行尾缺闭合 8 追加 / 01·06·22 提前闭合各删 1 / 18 ×2 补全 / 12 嵌套失锁链 ×2）→ **24/24 平衡**⑤23 版本链 v1.3 断号 git 溯源（r41 更新时被 v1.4 吸并——跳号成因回补声明）。
- **§3.2 六命令全绿 + 零信号维持**：build 0 告警 / check 0 / fmt 0 / clippy 0 / **test --release --workspace 919:0:0**（逐位维持）+ 六审计集 280 case EXIT 0 ×6（examples/audit 六二进制独立复跑）+ CLI 四路径（fib stdout 75025 + ⇒144 + higher_order ⇒(1 4 9 16 25) + closures ⇒42 + check ok）+ bench fib 70.940ms（噪声带 70.3-71.6 内）+ 语料五族 0/0/1 预期/0/0 + upload 零新增（吸收链收敛终态实证）+ TD 开放 P0/P1 = 0——T3+ 待触发态维持（红线 3）。
- **打包 v1.0.0-r64**：kerf-v1.0.0-r64-langdesign-fullaudit-919tests.tar.gz（沿 git 模式位字节级打包 + 包内自举三验）。
## r63（v1.0.0-r63）——第十三轮双向调试与脚手架哲学吸收（next9.md 五段全链——吸收链首收敛，零编译器代码增量）
- **next9.md 五段全量吸收 → stage0.md v7.0**：§9.11 双向调试策略五节（模式识别器双重用途——五级调试视图[用户源码/胖关键字/原语/ANF-SSA/目标码] + 四技术对比[GHC -ddump-simpl/Racket macro-debugger/LLVM opt-bisect] + 四组件统一[模式识别器/等价替换/Span/IR——零额外基础设施]）+ §9.12 脚手架哲学完整闭环五节（三阶段性能演进[借用→并行→拆除] + 三种脚手架完整对称[语法/信任/优化——信任脚手架新登记] + 逐个替换四步 + 拆除判据 ≥98%/额外能力 + 可回滚）+ **原则 41 脚手架哲学统一纪律** + 附录 A 十二条/B 三行/E.14 四条/F.8——十六主题关键词矩阵 16/16 全锚。
- **lang-design 六件回写 + sop v13.0**：17 v7.1（原则 41 + 附八）+ 12 v6.16（§2.11 三种脚手架生命周期权威）+ 11 v6.3（§5 双向调试策略权威——跳间中断半执行态补完 108-a）+ 13 v6.8（§3.9 工程能力定位——矩阵挂接而非新行）+ 18 v7.6（§5h 术语十二条）+ 19 v6.8（§13 引证 93-96）+ 00 注记 + 悬空引用 §2.13→§2.11 ×2 修复；sop.md v13.0（原则 41 + §21.12 第 9 条[**新借用登记纪律即刻生效**——脚手架或长期依赖二选一禁止模糊态] + §8.4.5 脚手架查询行 + 计数四十→四十一）。
- **代码零 delta 裁定（连续第四）**：四锚实证（模式识别器/调试视图数据结构/优化管线全零实现[Stage 2+/3+ 设计登记态] + 调试契约 DebugInfoGenerator/DebugTraceable P2 冻结在位 + 根空间 supertrait 状态维持）→ 零触发信号零代码变更（红线 3）——**919:0:0 维持** + 六审计集 280 case EXIT 0 ×6 + CLI 四路径 + bench fib 71.083ms 带内 + 语料五族 grep 精确口径全 0/预期命中 + 零信号维持裁定。
- **七轮吸收链首收敛**：r57-r63 next5/6/7/8/9 五文件九段全量吸收（文档栈五层闭环——蓝图存档→拆分权威→流程反哺→代码对齐→打包/web）至此零剩余；T3+ 待触发态维持（Stage 2 优化窗裁定材料四批登记——sop §21.12 第 6/7/8/9 条）。
- **打包 v1.0.0-r63（双轮一包）**：kerf-v1.0.0-r63-rootspace-scaffold-919tests.tar.gz（320 条目——r62 根空间 + r63 脚手架双轮交付；沿 git 模式位字节级打包 + 包内自举三验）。
## r62（v1.0.0-r62）——第十二轮根空间架构吸收与统一组织实施（next8.md 两段全链 + 预留接口根空间化 919 净+1）
- **next8.md 两段全量吸收 → stage0.md v6.9**：§9.10 根空间统一组织五节（概念性占位 marker + 约束特化[集合交集/约束合取——`trait A: B` = 约束加强 A ⊆ B 非实现继承] + 约束组合代数[格论——交/并/偏序] + 三层预留体系[点+通道+骨架] + 预留接口依赖方向裁定[DIP 的预留层投影]）+ **原则 40 根空间统一组织** + 附录 A 十二条/B 三行/E.13 四条/F.7——十二主题关键词矩阵 12/12 全锚。
- **lang-design 七件回写 + sop v12.9**：17 v7.0（原则 40）+ 13 v6.7（§3.8 根空间权威节 + 依赖方向裁定）+ 21 v1.4（§2.6 L0-L3 = 约束维度子空间实例）+ 18 v7.5（§5g 术语十二条）+ 19 v6.7（§12 Birkhoff/Cook/Pierce/Reynolds 89-92）+ 14 §4.8（类继承形态否决登记）+ 00；sop.md v12.9（原则 40 + §21.12 第 8 条[**预留接口依赖方向判据即刻生效**] + §8.4.5 根空间查询行 + 计数三十九→四十）。
- **预留接口审计与根空间实施（用户显式指令开窗）**：106-a 审计三结论（签名级具体依赖维持原则 27 冻结[Stage 2 演化窗] + **碎片化成立**[13+ 契约 trait 平行无根] + 既有缓解面清点）；107-a 矫正全量落地——**reserved/root_space.rs `ExtensibleRoot` marker trait**（零语义载荷）+ **20 契约 trait supertrait 化**（`trait X: ExtensibleRoot`）+ 38 归属声明 + 归属机器证明测试 + 三波编译错误清零；918:0:0 → **919:0:0（净 +1）** + 六审计集 280 ×6 + CLI 四路径 + bench 71.061ms 带内。
- **打包 v1.0.0-r62（跳间中断由 r63 轮补齐为双轮一包）**：r62 打包/web/收口在跳间中断中缺失——由 r63 轮 111-z/111-web/112-a 合并承载（kerf-v1.0.0-r63 双轮一包）。
## r61（v1.0.0-r61）——T3+ 监测复测轮 + web 移动端溢出清偿（例行监测全项过——零编译器代码增量，零信号维持）

- **例行监测复测全项过**（t3plus-trigger-audit §4 监测矩阵例行两项随每轮附载）：语料五族 grep **0 命中**（net/@包管理/extern/match 用户面 0 + syntax-parse 1 = expander.krf:40 TD-005 注记本体预期命中——触发族维持待触发态）+ bench fib 三轮 **71.102/70.840/70.427ms**（r55-r60 噪声带 70.3-71.6 内一致——OBS-C 观察项维持，零消费方诉求）+ CLI 四路径（fib 75025/⇒144 + higher_order ⇒(1 4 9 16 25) + closures ⇒42 + check ok[2 原型/9 常量/5 全局引用/38 指令]）+ 三语料 check 诊断锚 **319/145/193 逐字一致**（expander/compiler/reader——r53/r56 锚维持）。
- **§3.2 六命令全绿**：build 0 告警 + check 0 + fmt 0 + clippy --all-targets 0 + **918:0:0**（runner 686 集成 + 10 crate 单元 232 复合对账）+ 六审计集 **280 case EXIT 0 ×6**（41+50+53+46+43+47——精确名逐集独立复跑含汇总计数行对账）。
- **零信号维持裁定（ARCH-A）**：13 行触发族全部待触发态维持 → 无开窗（23 §2.3 红线 3 合规）→ R5 无升级 → **连续第五零代码轮**（r57-r59 吸收链 + r60/r61 监测轮）。
- **web 移动端 390px 溢出清偿（r47 起 13 轮基线豁免的已知特性本轮主动清偿）**：scrollWidth **477→390 = 视口**——根因两处（download-section LI 匿名 flex item min-width:auto 不可收缩 87px + footer 状态/叙述 P min-content 416px）→ 修复 = LI 文本显式 span 化 + min-w-0 + break-words + footer 三 P `[overflow-wrap:anywhere]`；**CSS 规范实例落档：break-word 不影响 min-content 内在尺寸（首版修完实测仍 416），anywhere 参与内在尺寸计算（416→390）**；桌面 1920×1080 零回归（1920/1920）+ 非 scroll 容器贡献者扫描 NONE + lint 0。
- **R4 开发实录（PATH 丢失静默失败——r56 三连跳实录变体）**：首轮 bench `--quiet 2>/dev/null` 空输出 = cargo PATH 丢失且错误被 stderr 抑制掩盖为「空成功」——**验收命令禁止丢弃 stderr；空输出 ≠ 成功（退出码 + 期望值锚双面核验后才可采信）**。
- **打包 v1.0.0-r61**：kerf-v1.0.0-r61-t3mon-webfix-918tests.tar.gz（沿 git 模式位字节级打包 + 包内自举三验）。

## r60（v1.0.0-r60）——T3+ 监测复测轮 + README v2.1 对齐（例行监测全项过——零代码零测试增量，零信号维持）

- **例行监测复测全项过**（t3plus-trigger-audit §4 监测矩阵例行两项随每轮附载）：语料五族 grep **0 命中**（net/@包管理/extern/match 用户面/syntax-parse——触发族 1/2/3/5/11 行维持待触发态）+ bench fib **70.463ms**（r55-r59 噪声带 70.3-71.6 内一致——OBS-C 观察项维持，离 65ms 需求信号尚有距离且零消费方诉求）+ CLI 四路径（fib 75025/⇒144 + higher_order ⇒(1 4 9 16 25) + closures ⇒42 + check ok[2 原型/9 常量/5 全局引用/38 指令]）+ 三语料 check 诊断锚 **319/145/193 逐字一致**（expander/compiler/reader——r53/r56 锚维持）。
- **§3.2 六命令 clean 起步全绿**：build 15.92s 零告警 + check 0 + fmt 0 + clippy --all-targets 0 + **918:0:0**（runner 686 集成 + 10 crate 单元 232 复合对账——`--workspace` 为六命令唯一可信形态）+ 六审计集 **280 case EXIT 0 ×6**（stage0 41 + stage1 50 + stage2_r1 53 + stage2_r2 46 + stage3_m3 43 + stage3_e5close 47——精确名逐集独立复跑直接退出码复核）。
- **零信号维持裁定（ARCH-A）**：13 行触发族全部待触发态维持——语料零命中 + bench 带内 + 诊断锚一致 + 无消费方诉求载体 → 无开窗条件（23 §2.3 红线 3 合规——禁止无信号开窗）→ R5 无升级 → 零代码变更裁定成立（**连续第四零代码轮**：r57/r58/r59 吸收链 + r60 监测轮）。
- **README v2.1 对齐（R4 清偿——r55 停更 4 轮滞后）**：5 处对齐——①头部三行（三十五→**三十九条**设计原则 + stage0 v6.8 收束注 + sop v12.5→**v12.8** 三轮判据级反哺特征 + 阶段状态补 r56 触发态审计判据操作化 + r57-r59 三轮吸收收束）②质量状态节（r55→r60 监测复测轮）③基准行（r55 基线 v1.3 补 r60 复测带内一致 70.4-71.4ms + 三语料诊断锚维持注）④路线节（已收口链补吸收链收束 + T3+ 行补 r56 判据操作化零信号维持 + Stage 2 优化窗裁定材料两批已登记[sop §21.12 第 6/7 条——零信号不开窗]）⑤打包行（r55→r60 包名）——全锚点实盘对账零臆造。
- **R4 开发实录（管线退出码第三实例）**：审计集计数经 `cmd | rg -o` 转手聚合时 stage0 汇总行丢失（其格式「total 41 / PASS 41（含 XFAIL-WARN 0）/ FAIL 0」含中文括注不匹配预设正则）→ 逐集独立复跑精确对账 280——**跨命令聚合统计必须逐源独立验证，不可信任转手管线首匹配**（r58 85-b「转手捕获陷阱」/r59 90-web「验收作用域限定」实录的再实例）。
- **打包 v1.0.0-r60**：kerf-v1.0.0-r60-t3monitor-918tests.tar.gz（沿 git 模式位字节级打包——r59 R4 教训执行 + 包内自举三验）。



## r59（v1.0.0-r59）——第十一轮性能潜力裁定与双轨策略吸收（next7.md 第三段全链——文档栈五层闭环，零代码 delta 轮）

- **next7.md 第十一轮第三段全量吸收**（收束轮——R4 实证：next7 前两段与 next6 逐字一致，第三段为唯一增量 ~131 行）：stage0.md v6.7→**v6.8**——§6.13.3 性能潜力裁定与双轨策略（**偏见纠正**：性能潜力[理论上限——极小原语严格更高：信息更多+粒度更细+空间更大] vs 开发成熟度[当前表现——胖关键字占优：50 年 vs ~30 年研究投入]两个正交概念——差距本质 = 研究投入差距非设计本质差距，概念区分即刻生效为判据；**双轨策略**：轨道 A 胖关键字优化复用「消除当前差距」+ 轨道 B 原语独有优化「超越胖关键字上限」——新的性能主要战场；**六项验证状态**：GHC 流融合初步验证 / Koka 效应内联验证中 / MetaOCaml 理论验证 / 自动并行化研究阶段 / Racket 生态验证 / MLton 全程序优化完整验证；**三阶段性能预期**：短期 ~1/1.2 C / 中期特定场景 1/1.0 甚至超越 / 长期全程序优化上限 > 任何胖关键字语言——理论上限：保留完整语义信息的编译器的极限；**风险→解法→预期三链路闭合**：§9.9.6[v6.6 登记] → §6.13.1[v6.7 解法] → §6.13.3[v6.8 预期]；哲学定位：不是重新发明轮子，而是站在轮子之上建造新的交通工具）+ 原则 38 判据级澄清增注 + §11.3/§9.9.6 两处增注 + 附录 A 术语四条 / B 三行 / E.12 文献 86-88 / F.6 对照——关键词矩阵 53 锚 574 命中零缺漏。
- **lang-design 五件回写 + 全集系统审查**：17 v6.9（原则 38 判据级澄清 + 附六 next7 对照——收束轮无新原则）/ 13 v6.6（**§3.7.5 性能潜力裁定与双轨策略权威节**）/ 08 v6.4（§5.4 三阶段性能预期——双预期矩阵）/ 19 v6.6（§11 文献 86-88：GHC Stream Fusion / Koka 效应内联 / MLton 全程序优化）/ 18 v7.4（§5f 术语四条）+ 00 上游注记 + **1039 相对链接全检零断链** + 五维审查（计数零漂移/编号 83-88 连续零重复/标题零重复/缺漏零缺口）。
- **sop.md v12.8 反哺**：§2.2 原则 38 判据级澄清（含违反示例扩展）+ §21.12 第 7 条（**三阶段性能预期登记与性能讨论判据纪律**：性能讨论先过概念区分 + 预期为优化窗验收锚候选 + 验证状态 = 原则 26 优化域投影）+ 来源注增记 + 2 处预存断链顺带清偿（§8.4.4 示例行 + §21.9 对账注记——git diff 空集实证非本轮引入）。
- **代码面对齐核查（零 delta 裁定——连续第三零 delta 吸收轮）**：v6.8 增量全为判据级/预期级/引证级内容——五锚核验（anf.rs AnnotatedANF + IndexIR r48 前置基座 / reserved **67 冻结签名三连精确一致**[r57/r58/r59] / 10 crate 单向流 / effect_stress E2E ⇒ 120 维持）——零触发信号 → 零代码变更（红线 3 合规）。
- **918:0:0 零回归维持**（零代码轮）+ §3.2 六命令 clean 起步全绿（build 16.23s）+ 六审计集 280 case EXIT 0 ×6（精确名）+ CLI 全路径 + bench fib 71.077ms 带内。
- **打包 v1.0.0-r59**：kerf-v1.0.0-r59-perfpot-dualtrack-918tests.tar.gz + 包内自举三验（净构建 + 918 逐位复跑 + 审计 ×6 + CLI + bench 带一致 + v6.8 内容在包锚命中）。



## r58（v1.0.0-r58）——第十轮优化桥接与 IR 正交精简吸收（next6.md 全链——文档栈五层闭环，零代码 delta 轮）

- **next6.md 第十轮全量吸收**（两段问答，647 行）：stage0.md v6.6→**v6.7**——§6.13.1 模式识别与等价替换（极小原语桥接到胖关键字优化体系的双向通道：四步管线[模式匹配→等价标记→优化复用→额外优化] + 循环模式四特征规格[Y 组合子自引用/Branch 入口/参数更新链/纯循环] + 异常模式三特征规格[单 handler/不 resume/恒等 final] + 双向优化能力对照[复用六项 LICM/向量化/循环展开/零成本异常/跳转线程化/函数内联 vs 独有六项跨控制流融合/用户级控制流优化/部分求值/自动并行化/自定义控制流优化/细粒度指令调度] + 六阶段优化管线 + 识别器判定特征 Rust 规格 + **A + B > 胖关键字**）+ §6.13.2 IR 层级正交精简（四维正交框架[结构/语义/形式/目标] + 6→4 合并对照 + Pass 而非 Layer[识别即替换单一 pass] + 正交合并三原则 + 转换开销 5→3 次[40% 减]——**修正案登记非推翻**：与六层规划的差集论据在 Stage 2 优化窗按验证表 + 实测裁定）+ **原则 38 模式识别桥接 / 39 维度正交与 Pass 化** + §11.4.3 转换开销与速度正贡献 + 附录 A/B/E.11/F.5——关键词矩阵 77 锚零缺漏。
- **lang-design 七件回写 + 全集系统审查**：17 v6.8（原则 38/39 + 附五对照）/ 13 v6.5（**§3.7 优化桥接权威节**——模式判据表 + 打洞能力对账第四行[优化复用通道] + 实况三锚）/ 15 v6.2（§5.2 四层修正案注记）/ 08 v6.3（§5 优化管线与模式识别桥接）/ 19 v6.5（§10 文献 83-85：LLVM Loop Optimization / LLVM Exception Handling / Appel 教材）/ 18 v7.3（§5e 术语九条）/ 14 v6.2（§4.7 四层 IR 修正案登记——**判据与方案分层吸收**：三原则即刻生效为判据，四层方案触发式评估）+ **1040 相对链接全检零断链**。
- **sop.md v12.7 反哺**：§2.2 原则 38/39（含违反示例三则）+ §21.12 第 6 条（**Stage 2 优化窗裁定材料登记** + 判据与方案分层吸收纪律）+ §21.2 转换开销正贡献 + 五处计数同步（三十七→三十九）。
- **代码面对齐核查（零 delta 裁定）**：模式识别前置基座两半面实锚（anf.rs AnnotatedANF 原子化[批次 G/B1 PoC 边界] + IndexIR r48 解析闭包）+ 四层修正案实况三锚（typecheck E0005 在 CoreExpr / IndexIR Closed 半面 / SSA 未实现零重构成本）+ reserved/ **67 冻结签名精确对账** + 10 crate 单向层级 + effect_stress E2E ⇒ 120 维持——零触发信号 → 零代码变更（红线 3 合规）。
- **918:0:0 零回归维持**（零代码轮）+ §3.2 六命令 clean 起步全绿（build 16.22s）+ 六审计集 280 case EXIT 0 ×6（精确名复验）+ CLI 全路径。
- **打包 v1.0.0-r58**：kerf-v1.0.0-r58-optbridge-irorth-918tests.tar.gz（313 条目 / 2.76 MiB）+ 包内自举三验（净构建 15.46s + 918 逐位复跑 + 审计 ×6 + CLI + bench fib 71.190ms 与 repo 带一致 + qbe 在包 + v6.7 内容在包锚命中）。


## r57（v1.0.0-r57）——第九轮机制预留吸收（next5.md 全链——文档栈五层闭环，零代码 delta 轮）

- **next5.md 第九轮全量吸收**（6 问 5 答段，1208 行）：stage0.md v6.5→**v6.6**——§9.9 机制预留（接口预测悖论的解法：三层未知防御[语义完备性/机制通用性/组合无限性] + 三种打洞能力[自定义效应/宏展开/能力系统] + OCP 哲学根基 + 真正风险三则[第 9 原语/性能天花板/认知天花板] + 与既有预留体系正交互补）+ §9.5.4 代价分级判据（重构级 vs 增量级——「数据结构不可变，实现可替换」）+ §11.4 编译速度标杆与四档预期（TCC ~1μs/行 / Jai ~10μs/行声明值 / Zig 增量 10-50ms + Stage 0-3+ 四档 + 双路径策略）+ §18.2.1 Stage 2a/2b 两阶段语义（S 表达式形态完全自举 → 语法替换重写非转化 + 分裂问题正面解法 + E5 渐进皮肤现代化实况对照）+ §7.3.6 S 表达式架构位置精确化（语法级 IR + Racket SyntaxObject 四元组 + 选择 A 脚手架 vs B 永久中间层六维度裁定）+ **原则 36 机制预留 / 37 抽象-具体分离（开闭）** + 附录 B 六行 / E.10 / F.4——关键词矩阵 41/41 全命中。
- **lang-design 八件回写 + 全集系统审查**：17 v6.7（原则 36/37 + 计数漂移修正）/ 13 v6.4（§3.6 机制预留权威节 + 三种打洞能力实盘对账表）/ 02 v6.5 / 07 v6.4 / 08 v6.2 / 19 v6.4 / 18 v7.2 / 14 v6.1 + **历史断链 18→0 清偿**（`../../` 深度错误五文件）+ 五维系统审查（缺漏/理念/演进/能力/文献）。
- **sop.md v12.6 反哺**：§2.2 原则 36/37 + §21.12 第 5 条（接口预留 × 机制预留正交互补 + 代价分级判据）+ §21.2 编译速度四档 + 计数漂移修正 ×4。
- **代码面对齐核查（零 delta 裁定）**：三打洞机制实盘验证（Perform 值域效应全量化 + effect_stress E2E ⇒ 120 + macro_sys.rs + capability.rs fail-closed）+ reserved/ 67 冻结签名 + 10 crate 单向层级——零触发信号 → 零代码变更（红线 3 合规）。
- **918:0:0 零回归维持**（零代码轮）+ §3.2 六命令 clean 起步全绿（build 15.74s）+ 六审计集 280 case EXIT 0 ×6 + CLI 全路径。
- **打包 v1.0.0-r57**：kerf-v1.0.0-r57-next5mechreserve-918tests.tar.gz（312 条目 / 2.72 MiB）+ 包内自举三验（净构建 16.02s + 918 逐位复跑 + 审计 ×6 + CLI + bench fib 70.744ms 与 repo 70.841ms 带一致 + qbe 在包）。

## r56（v1.0.0-r56）——T3+ 触发态审计 + 判据操作化（治理回路维护轮）

- **零开窗声明（23 §2.3 红线 3 的执行载体）**：T3+ 触发族全量 13 行逐行证据审计——**零开窗信号**（语料 grep 五族零消费：net / extern / match 用户面 / @ 版本语法 / syntax-parse + OBS-C 性能消费面需求信号缺 + net 四依据 ① 缺）→ r56 = 触发态审计 + 判据操作化（非实施窗——预防式不引入）。
- **dangling 目标再裁定 ×5**：TD-003/005/015/024/026 的「目标时机」列指向已关闭窗口（Stage 3 收口 r52 / Stage 2 批次 H-I 收口）——全部再裁定为 **T3+ 触发式三判据**（TD-008 r24 样板式可监测形态）；TD-024 承接件清偿状态修正（FFI 面 r30 + 闭包/GC 协同 r24-r25 已做实）；TD-028 索引行清偿终态补齐（R4——r54/r55 实况对齐）。
- **触发族证据矩阵（13 行）**：实测复核 fib bench 三轮 70.851/71.197/70.624ms（r55 记录 71.4ms 噪声带内——**r55 状态可复现**）+ gc 尾形 36.230ms + CLI 四路径全过 + 三语料 check 诊断集 **319/145/193 行与 r53 锚逐字一致**（零漂移）+ check 时延 3.600/1.164s（r54/r55 VM 链优化自然收益 ~8-12%）。
- **信号监测矩阵**（七信号源 × 监测方法 × 时机 × 责任锚）：语料 grep + bench 例行随每轮 §3.2/PHASE 1 附载零边际成本；其余触发怀疑才测——任何信号命中 → 23 §2.2 入口信号回填 → 开窗评审。
- **918:0:0 零回归维持**（零代码轮——r27/r36/r52 先例链）+ 六审计集 280 case EXIT 0 ×6 + CLI 全路径 + 投票 5.5/5.5 = 100% GO。
- 文档：t3plus-trigger-audit.md（新建）+ TD 登记册 v0.4.3-r56 + 23-evolution-governance v1.8（§5.2 触发列四行操作化）+ v0.5-roadmap v1.0.0-r56（Status 枚举 R4 修正）+ matrix r56 增量行 + calibration-data r56 数据点。

## r55（v1.0.0-r55）——T3+ 优化窗第三件：TD-028 帧槽池（清偿关闭）

- **帧槽池（P1 + P3 清槽分工）**：execute 层内 LIFO 池——深递归/尾调用热循环的帧槽分配免堆化（fib(25) 剖面 248,105 次帧分配 / ≈50 万次堆分配 → 池命中近零）。护栏两道：`strong_count == 1`（捕获/continuation 快照共享 → 整 Vec 弃置走 drop 原路径）+ 清堆引用槽（GC 悬空安全必要条件）；P3 分工——release 仅清 `has_heap` 槽、acquire 仅清 Let 槽（全参数覆写场景双侧零清槽）。
- **A/B 实测（同机同时段交替对照）**：fib 76.4→**71.4ms（1.067x 稳定）**；effect_stress 1.05-1.08x；gc 尾形 1.005-1.012x；gc 非尾形双峰带持平（89-105ms——基线同带，GC 相位稳态差异诚实落档）。
- **TD-028 清偿关闭**：r36 漂移（+9.9%）经 r54 分派优化 + r55 帧槽池——**相对 r24 原始基线 84.2ms 净超越 1.18x**；OBS-C 观察项登记（args 中转 + Frame 构造 = fib 剩余大头——T3+ 触发式，性能消费面需求信号时开窗）。
- **增量归因实录**：P2 参数直写判据移除（callee 栈位约束证伪——args 中转时序必需）；剖面→实测对账（上界模型 28-35ms vs 真实收益 5ms——glibc tcache + 池管理开销，判据诚实不粉饰）。
- **918:0:0**（净 +14 vm_frame_pool_tests——一优化一锚）+ 语义零漂移五手段全绿（三语料 A/B 逐字节 diff 空集 + 六审计集 280 ×6 + CLI 全路径 + bench 值锚 + 门 B fixpoint）+ 投票 5.5/5.5 = 100% GO。
- 文档：td028-frame-pool-optimization.md v1.1 + deep-review-td028-framepool.md + performance-baseline.md v1.3（§2.8）+ TD-028 详情节清偿注记。


- **开窗**（23 §2.2 T3+ 行——六信号核对：基线 v1.1 阶段分布判据锚[自举 VM 链 99.77%] + final-assessment「TD 优化窗口 profile 先行」+ TD-028 登记在位 + profile 实测定锚[逐指令成本拆解——clone/span 拷贝/双边界检查/守卫双查] + 语义零漂移五手段可机械实证 + 净负载红线合规）
- **O1 span 惰性求值**（cur_pc 不可变绑定 + cur_span!() 宏——错误路径/帧构造点按需取，消除逐指令 16B 无条件拷贝）+ **O2 指令引用化**（.get 单次边界检查 + Op 按引用分发——消除逐指令 clone 与守卫/索引双查）+ **O3 proto 跨迭代缓存**（帧未变时复用 proto 引用——九处帧变更点显式置位失效）——vm.rs execute 层内，零接口面变更
- **A/B 双二进制实测**：**fib 91.238→76.354ms（1.195x，≈3.15M 调用/s）** / gc_stress 尾形 42.017→36.641ms（1.143x）/ check expander 中值 3812→3669ms（1.039x——波动带内诚实口径）/ 深帧非尾形与效应中性
- **语义零漂移五手段全绿**：904:0:0（889 基线 + 15 新增 vm_dispatch_perf_tests——一优化一锚）+ 三语料 check 诊断集 A/B 逐字节 diff 空集 + 六审计集 280 case EXIT 0 ×6 + CLI 全路径 + bench 值锚
- **§3.2 六命令 clean 起步全绿**：build 15s 零告警 / check 0 / fmt 0 diff / clippy --all-targets --workspace -D warnings 0 / test 904:0:0
- **同窗治理件（76-a）**：sop.md **v12.5** 路由覆盖全量审查升级——死块补线 ×2（§18/§20 入路由）+ L1/L2 分层口径三方统一 + 校准回路重建（calibration-data v0.2.0——断档 45 轮修复 + Stage 1/2/3 统计行回填）+ 悬空引用修复 + stage-3 final-assessment.md 补建
- **深审 + 投票**：deep-review-td028-dispatch.md（D1/D2/D3/D5/D6/D8 六维度——P0/P1 = 0；五角色 5.5/5.5 = 100% GO）



## v1.0.0-r54（2026-09-21）——T3+ 优化窗第二件：TD-028 VM 主分派性能演进 + SOP v12.5 治理升级（76-a/76-b/76-z/76-web）

## v1.0.0-r53（2026-09-21）——T3+ 优化窗首件：HM 求解器 O1+O4 性能演进 + 基线归因修正（75-a/75-b/75-z/75-web）

- **开窗**（23 §2.2 T3+ 行——六信号核对：性能基线冻结 + final-assessment「TD 优化窗口 profile 先行」+ TD-028 锚 + 优化候选判据 + 语义零漂移可证明性 + 净负载红线——非时间驱动，红线 3 合规）
- **O1 路径压缩写回**（resolve 两遍法：短链零开销/深链 union-find 摊还）+ **O4 copy_fresh 结构共享**（Rc::ptr_eq 短路——spine 复制最小化）：HM 段实测 **8.5→6.95ms（1.22x，expander 语料）/ 2.5→2.15ms（1.16x，compiler 语料）**
- **负收益实录**（判据驱动移除——增量归因方法论资产）：O2 occurs 结构指针剪枝 / O3 free_vars seen HashSet / O5 env_free HashSet——SipHash 开销 > 剪枝收益（真实语料结构共享度低 + free 集小）；OBS-A（env_free 全量增量化）判据关闭（增量收益上限 <0.05% check 总时长）
- **基线归因修正 v1.1（R4——重大口径发现）**：v1.0 把 check 全链耗时误记为「HM 类型检查」（3734ms 实测构成 = 自举 VM 链 99.77%[read 1287.6ms 34.7% / expand 495.3ms 13.4% / compile 1909.8ms 51.5%] + HM 段 0.23%[8.5ms]）——check 性能演进正解 = TD-028 VM 主分派优化（阶段分布首次实测落档为后继判据锚）
- **语义零漂移五手段全绿**：889:0:0（877 基线 + 12 新增守护[hm_perf_evolution_tests]）+ 三语料 check 诊断集逐字节一致（含 E0005 α377 编号锚——fresh 分配顺序不变实证）+ 六审计集 280 case EXIT 0 ×6 + CLI 全路径 + bench 91.038ms 基线噪声带内
- **§3.2 六命令 clean 起步全绿**：build 14.22s 零告警 / check 0 / fmt 0 diff / clippy -D warnings 0 / test 889:0:0
- **深审 + 投票**：deep-review-t3-optimization.md（D1/D2/D3/D5/D6/D8 六维度——P0/P1 = 0；五角色 5.5/5.5 = 100% GO）


## v1.0.0-r52（2026-09-21）——Stage 3 收口窗：性能基线五维度冻结 + D1-D8 深审 + final-assessment（74-a/74-b/74-z/74-web）

### 交付一：性能基线（performance-baseline.md v1.0——§21.5 九信号信号④兑付）
- **五维度 13 程序实测冻结**（release 口径 + bench 20 轮均值/check 3 取样中值）：①执行速度 6 程序——fib 25 = 91.534ms（≈2.65M 调用/s）+ effect_stress 85.807ms（效应恢复无异常放大）+ gc 尾形 41.593ms/非尾形 90.851ms + higher_order/closures/macros/io 亚毫秒；②编译速度 4 语料——自举四件全链 < 1ms（compiler 0.270ms ≈ 16.3M 指令/s 发射吞吐）；③HM 类型检查 3 语料——fib 27ms / compiler 1230ms / expander 3734ms（check 路径重量级维度诚实落档——run 路径零开销维持，原则 18）；④GC 压力 2 形态（≈7.2M 分配/s 尾形）；⑤自举一致性——门 B fixpoint SHA 一致
- **载体 = CLI 既有 `bench`/`check` 子命令（零本体变更）**——纯测量落档，877 基线零回归结构性保证；重跑规程入档（§5——重大性能演进须对照追加版本行）
- **TD-028 漂移对照复核**：fib r24=84.2 → r36=92.5 → r52=91.534ms（-1.1% vs r36——漂移收敛于噪声带上沿 +8.7% vs r24，**维持登记不升级**）
- **Stage 3+ 优化候选注记**：HM occurs check union-find 压缩 + 泛化 memo（基线文档 §2.3——判据先于先例）

### 交付二：Stage 3 大阶段末深审（deep-review-stage3-close.md——D1-D8 + 投票 + final-assessment）
- **D1 架构**：10 crates 接口隔离抽查维持（compiler→reader = 0；vm→compiler = 数据类型 only 正当）+ E5 三结构臂层内演进零跨层新增
- **D2 技术债**：30 项 P0/P1 = 0（解决/清偿 20 + 断档 4 + DEFER 1 + 开放 5 全有 T3+ 触发窗口——23 §2.2 触发表单源）
- **D3 测试**：877:0:0 + 六审计集 280 case（r52 复验 EXIT 0 ×6）
- **D4 就绪度**：T3+ 触发式族输入面全 ✅ 或显式触发式（net 四依据 / 各推迟项 / TD 优化窗口 profile 先行）
- **D5 设计**：E5 九腿全绿 + 35 条核心原则全数在位 + 正交判据 J1-J4 实测锚维持
- **D6 性能**：r52 基线 + 算法复杂度零新增（de Bruijn O(n)/ModuleItem O(1)/let 直映 O(1)）
- **D7 文档**：lang-design 24 文件 + 新两件（performance-baseline + deep-review-stage3-close）——冷启动路径零隐性
- **D8 流程**：R6/R7 收敛达成（连续两轮零新 P0/P1——r51 e5close + r52 深审）
- **五角色投票：5.5/5.5 = 100% GO** + **final-assessment：Stage 3 收口 GO——进入 Stage 3+ 触发式演进（T3+ 族——23 §2.2 触发表单源驱动，禁止无信号开窗）**

### 测试与验证
- **§3.2 六命令 clean 起步全绿**：build --release 14.26s 零告警 → check 0 → fmt 0 diff（一处 rustfmt 边界修正）→ clippy -D warnings 0 → **test --release --workspace 877:0:0**（集成 645 + 单元 232——与 r51 逐位一致零回归）
- **六审计集 280 case EXIT 0 ×6** + CLI 全路径（fib 144 / native QBE PoC fib 12 → 144 / E0021 负例）

---

## v1.0.0-r51（2026-09-21）——E5 窗收口 S4：出口三条件终验全绿 + 门审 47 case（73-a/73-b/73-z/73-web）

### 交付一：第六审计集 stage3_gate_audit_e5close（47 case APPROVED——examples/audit/ 第 6 件）
- **A12 单语句负向**：E5 窗诊断码全覆盖——E0021 关键字三对（lambda/set!/begin 携现代名指引）+ 旧内置三族代表（car 访问器/int? 谓词/string->symbol 转换/assert-eq? 断言）+ E0022 face 核对（N3/N2/N1 逐层明细）+ E0020 保留字绑定 + E0019 未知导入 + E0005 元数静态面 + 空形式
- **B10 多语句负向**：位置纪律前移组（define/module 表达式位——E0002/E0023[r49-α]）+ 平行语义 E0022（`(let ((x 1) (y x))` 值位不可见）+ 未选成员不可见 + face-aware 导入建议（`(import kerf-prelude) 后可用`——B10）+ E0024 选择性导入（r50-α D65）+ 宏产物旧关键字（B06/C03）+ HM 多错误收集
- **C5/D5**：复杂负向（module 内未绑定/深位 module 表达式/深宏产物/HM 闭包链类型/module 后未知导入）+ 恢复（合并报告 + E0021 后 VM 健康 fib 144 + E0022 后多绑定 let 3 + E0024 双路径一致 + Span 排序单调）
- **E6 上轮修复边界（≥5）**：r50-β 三件（cc-locals-push! 帧位边界——多绑定 let 上闭包捕获四变量 ⇒ 14 / TD-030 check+prelude 零误报 / let* 平行语义正例 ⇒ 2）+ r50-α D65（选择性导入限定名维持模块级关系 ⇒ 2）+ r49-α do-splice（def-twice 宏产顶层 define ⇒ 14）+ r48 de Bruijn（三层深捕获链 ⇒ 6）
- **P9 正向/E2E/证据锚**：九原语全用点（fn/apply/if/var/literal/assign/let/perform/handle 单程序 ⇒ 41——CoreExpr 9 变体结构锚）+ 单源计数锚（N1_CORE_NAMES 38 + PRELUDE_EXPORT_NAMES 20 + REMOVED_BUILTIN_NAMES 27 对 + 旧名零残留 N1）+ 旧名负例组七形 E0021 总验 + fib 610 双路径 + N1 永驻裸用 + prelude HOF + 选择性导入组合 + 效应恢复链 + do-splice/assign
- **机械校验**：七类全覆盖 + 配比 12/10/5/5/6/9（超 §7.3.1 强制下限 10/10/5/5/5）+ 负向 27 ≥ 22 + 总 47 ≥ 30——EXIT 0（APPROVED）

### 交付二：E5 出口三条件终验全绿（e5-plan §5 对账表三行落档）
- **①迁移后 parity 链全绿**：A01-C05 双路径同 Err（run_negative 种子链核对贯穿）+ E/P 桶 OkDual（生产/种子同值 eq_value）——九腿结构重构零语义漂移的执行级终验
- **②旧名/关键字移除负例组**：A01-A07 + P09 七形 E0021 携现代名指引总验 + B06/C03 宏产物旧形 + P03 计数锚（27 对冻结口径维持）
- **③非正交点 ≤1**（21 §5.5）：P02 九原语全用点结构锚 + E05 do-splice 宏产 define（ModuleItem 声明层行为锚）+ B01/B02/B08 位置纪律编译期不可表示——SetBang 受控维持 1 为终态

### 交付三：S4 收口外循环投票（e5-plan §7——§6.3 口径）
- 5/5 = 100% GO（ARCH-A 2 / DEV-A 1.5 / QA-A 1 / ALG-C 1 / SKL-A 1 不计权）——E5 窗收口 GO + v1.0.0 发布裁定

### 测试与验证
- **877:0:0 零回归**（纯审计集新增零本体变更——S4 收口轮零代码变更 = 九腿实施质量的直接证明；集成 645 + 单元 232）
- **§3.2 六命令 clean 起步全绿**：clean 352.9MiB → build --release 14.03s 零告警 → check 0 → fmt 0 diff → clippy --all-targets -- -D warnings 0 → test --release --workspace 877:0:0
- **六审计集 280 case EXIT 0 ×6**（stage0 41 + stage1 50 + stage2_r1 53 + stage2_r2 46 + stage3_m3 43 + e5close 47）
- **CLI 全路径**：fib 6765 + map (1 16 64) + append + 选择性导入 + 多绑定 let + do-splice/assign + handle 效应恢复 + check+prelude + E0021/E0022/E0024 负例 + examples/fib + io 门控分项（read-line/io/print）

### 打包与同步
- tar.gz：`kerf-v1.0.0-r51-s4close-e5exit-877tests.tar.gz`（73-z——包内自举三验全绿）
- web 面：kerf-data r51/v1.0.0 节点 + footer v7.23 + stats 877 自动（73-web）
- 文档：e5-plan v2.0（§5 三行全绿 + §7 投票）/ 23 v1.7（§2.2 E5 行终态）/ 12 v6.14（§2.10 移除轮行终态）/ v0.5-roadmap v1.0.0-r51 / matrix v0.1.2-r51（六审计集 280）

---

## v0.18.0-r50β（2026-09-21）——let 直映臂：核心形式直映 + TD-030 清偿（D61——22 §17.3/§17.6）（72-b/72-z/72-web——用户指令「按照 sop.md 继续推进任务」+「同步完整打包项目 tar.gz 并同步完整更新 web page」）

### 交付零一：let 退出糖表——核心形式直映（九糖 → 八糖）
- **三形态直映**（`expand_let`——core_forms.rs）：单绑定 `(let ((x e)) b...)` → `CoreExpr::Let`（fresh scope 注入绑定器与体[TD-004 同口径]，**值位不注入**——平行语义）；多绑定 `(let ((x e1) (y e2)) b...)` → **多绑定暂存法** `Let[t₀, e₁′, Let[t₁, e₂′, Let[x, Var(t₀), Let[y, Var(t₁), b′]]]]`（恒定名族 `let$st{i}` + stash/bind 双层 fresh 时序防劫持 + 值位零注入——全部值先求值后绑定，e₂ 不可见 x）；空绑定 `(let () b...)` → do 链（零闭包分配）
- **收益**：①let-polymorphism 原语化（HM 泛化锚点直载 Let 节点——D6 ② Apply[Fn] 形状模式识别退役；SML 正典「应用位不泛化」）②每 let 绑定消除闭包分配（`[PushClosure; e; Call 1]` → `[e; StoreLocal; b]`——性能载荷）③D34「一个语义一个名」完全兑现（let↔Let 名实一致）
- **corpus 三面镜像**：expander.krf `expand-let`/`expand-let-multi`/`let-rebind-fold`/`let-stash-fold` 逐层镜像（fresh 分配时序两侧同步）+ SUGAR-HEADS 去名 + compiler.krf `'let` 臂激活

### 交付零二：TD-030 清偿（check+prelude E0005 假阳性）
- **机制**：`infer_let` 逐绑定 `solve_now()` 提前求解把对称挂起约束变单向绑定（α₂ := (α₃ . α₄)）→ 后续 define 合一在不对称状态触发 occurs 误报——D6 ② 形状识别退役（infer_let 删除）后 discard 路径零提前求解
- **验收五件**：`(import kerf-prelude) 42` check ok ｜ for-each let-discard 零误报 ｜ prelude 全模块集成（五 HOF + 序对三件 + 表域两件）｜ 双导入组合 ｜ 真 occurs 负例维持检出（不弱化）
- **覆盖缺口闭合**：check_source 测试语料零 prelude 的历史缺口 → td030_check_prelude_combo_clean 常驻组

### 交付零三：corpus compiler.krf 三潜伏修复（D61「零变更」预判修正——R4）
- **binding cons 形**：`(list name lscopes)` → `(cons name lscopes)`（cdr 位 nil 壳致 is-scope-subset 逐元素比较恒假）
- **cc-locals-push! 帧位**：head 帧 → **尾帧**（种子真值 `scopes.last_mut()`；原 head 写入使 let 绑定落 main 帧[槽号错帧计算与形参碰撞] + 不对称 pop 刈尾帧形参绑定——E0022 best-rank/pats 双实证）
- **nlocals 保 bump 终值**：fn `max(参数数, bump)` + main 保 third（原硬编码参数数/0 覆写 let bind 槽回填——VM 帧分配不足）
- 三潜伏根源：r45 起 do 链恒 discard 使 bind 分支死代码从未暴露——let 直映激活 bind 模式即爆

### 测试与验证
- **净 +3**：let_direct_mapping_parallel_semantics（平行语义机器验证组——E0022）+ let_direct_mapping_hm_generalization（HM 泛化面）+ td030_check_prelude_combo_clean（TD-030 集成组）
- **§3.2 六命令 clean 起步全绿**：build --release 14.31s 零告警 → check 0 → fmt 0 → clippy 0 → **test 877:0:0**（874 基线零回归）+ 五审计集 EXIT 0 ×5（A09 期望消息随 D6 ② 退役重锚——检出语义等价）+ CLI 全路径（多绑定 3 / 闭包捕获暂存链 30 / let* 30 / assign 槽 5 / 空绑定 42 / 平行负例 E0022 / check+prelude ok）
- **行为 parity 门**（e5-plan §3.2 S3 门分类学——形态变更臂）：字节码序列合法变更（{PushClosure; Call}→{StoreLocal}），全套件行为零回归 + 双路径 parity 维持 + B₁/B₂ fixpoint 双自编译字节一致
- **E5 出口三条件全绿**：①parity 链（α 字节码全等 + β 行为 parity）②负例组（S1/S2 + E0003/E0018/E0023 + 平行 E0022）③非正交点 ≤1（r49 达标维持）→ S4 收口（门审 ≥30 case 终验 → v1.0.0）

### 打包与同步
- tar.gz：`kerf-stage3-v0.18.0-r50b-letdirectmapping-877tests.tar.gz`（72-z——包内自举三验全绿）
- web 面：kerf-data r50-β 节点 + footer v7.22 + stats 877 自动（72-web）
- 文档：22 v2.4 §17.6 / 01 v6.4（糖表 let 行退役 + §8.3 Let 行直映状态）/ TD 登记册 v0.4.2（TD-030 清偿）/ e5-plan v1.9 / roadmap v0.14.0-r50β / matrix v0.1.1 / RELEASE v0.18.0

## v0.17.0-r50（2026-09-21）——谓词命名清偿 + 成员级选择性导入（D63-D66——22 §18）（71-a/71-b/71-z/71-web——用户指令八子项再审理[含子项 6「? 命名形式」+ 子项 7「- 层级 + 导入粒度」新增焦点] +「按照 sop.md 继续推进任务」+「同步完整打包项目 tar.gz 并同步完整更新 web page」）

### 交付零一：D63 `?`/`->` 命名全量清偿（R2/R4 域内一致性）
- **注册面四件**：`char-whitespace?`→`char-is-whitespace` / `char-alphabetic?`→`char-is-alphabetic` / `str-int-valid?`→`string-is-int` / `str->pos-chars`→`string-to-pos-chars`（N1_CORE_NAMES + char 模块 underlying + 消息面 + 测试全迁——限定名 `char/is-whitespace` 本地名零变更）
- **corpus 24 helper**：`名?`→`is-名`（err?→is-err / digit?→is-digit / is-keyword?→is-keyword / registry-hit?→is-registry-hit 等——156 refs 词法边界替换 + B₁/B₂ fixpoint 重锚合法）
- **用户自由面不变**：`?`/`->` 恒为合法标识符字符（e5-plan §4.3 维持——清偿面 = 官方注册面 + 官方语料示范面）

### 交付零二：D65 成员级选择性导入（`(import <模块> (成员...))`）
- **三形态**：`(import kerf-string)` 全量 ｜ `(import kerf-string (append length))` 选择 ｜ `(import kerf-string as str (append))` 别名+选择
- **语义分层**：选择子集作用于**扁平注入面**（E0022 可见面 / E0013 冲突面 / W face 按成员 underlying 过滤）；**限定名访问维持模块级导入关系**（`string/length` 于选择后仍可达——Kotlin/Java 特定导入同构[q4/q7 实证]：选择 = 扁平命名空间卫生非模块关系裁剪）
- **E0024 新码位**：成员不在模块导出面 → 编译期拒绝（fail-closed + actionable：成员名 + 模块名 + 全量导入查看指引）
- **prelude 诚实语义**：E0024 校验 + W/E0013 面过滤；E0022 define 面维持（模块语料恒在编译单元——文档化非访问控制）
- **D64 文档不变式**：`-` = word-join 永不承载层级语义 + 扁平/限定双轨显式化（flat = 运行时分派身份 / qualified = 词法可见形态）+ 多层级词法预留（`/` 已在 R-N4 字符集——Stage 3+ 用户模块窗口）

### 测试与验证
- **净 +6**：d66 选择性导入组 5 case（可见/拒绝/限定可达/E0024/并集）+ D63 现代名 1 case
- **§3.2 六命令 clean 起步全绿**：build --release 13.55s 零告警 → check 0 → fmt 0 → clippy 0 → **test 874:0:0**（868 基线零回归）+ 五审计集 EXIT 0 ×5 + CLI 全路径（选择性导入 E2E + alias+selection + fib + io + check + native fib(10)=55）

### 打包与同步
- tar.gz：`kerf-stage3-v0.17.0-r50-predclear-selectiveimport-874tests.tar.gz`（71-z——包内自举三验全绿）
- web 面：kerf-data r50 节点 + footer v7.20 + stats 874 自动（71-web）
- 文档：22 v2.3 §18 / 18 v7.1（E0024）/ matrix v0.1.0-r50 / TD 登记册（TD-030 维持——r50-β 修复窗）/ e5-plan v1.8 / roadmap v0.13.0-r50

## v0.16.0-r49（2026-09-21）——ModuleItem 声明层臂：CoreExpr 12→9 + module 级 do-splice + 位置纪律前移（M-D 上移 + M-L 层迁 + Require 归位——D59-D62）（70-a/70-b/70-z/70-web——用户指令「按照 sop.md 继续推进任务」+「同步完整打包项目 tar.gz 并同步完整更新 web page」）

### 交付零：声明层实化（D59——两级文法：声明与表达式分离）
- **`ModuleItem` 声明层（kerf-core）**：`CoreExpr` 消除 `Define`/`Module`/`Require` 三变体（12→9 语义原语——表达式 ADT 不再携带声明/组织职责）；新类型四 kind：`Define{name, value}`（M-D 上移）/ `Require{caps}`（声明变体归位——01 §6 两层不合流裁定的层归宿）/ `Module{name, imports, exports, items}`（M-L 层级迁移）/ `Expr(Rc<CoreExpr>)`（Python ast.Expr 包装同构）。程序 = `Vec<ModuleItem>`（SML dec-exp + Python stmt-expr + Racket module-begin 三家族 2026 两级文法共识——q1-q4 实证 tool-results/r49-search/）
- **module 级 do-splice（D59 核心机制）**：程序/module 体项位上的 `do`（宏 trampoline 后）递归展开为项序列（Racket module 级 begin splicing 同构）——**宏产顶层 define 的合法通道**（def-twice 正例驱动）；**字节码全等证明**：do 链 `[item; Pop]*` 结构 ≡ 项序结构（空 do → [PushNil]；do 内 define → `[e; Dup; DefineGlobal; Pop]` 两 Pop 分隔位逐位对齐）
- **位置纪律前移（类型不可表示优于运行检查——01 §8.1 原则 1 推广）**：表达式位 define → E0003（消息逐字保持——ir.rs lowering 深度检查退役）；require → E0018（消息逐字——driver `verify_require_positions_stx` Stx 游走承载源码级[码位 18 与 Stage::Compile 契约保持] + 展开器兜底）；module → **E0023 新码位**（此前无检查[inline 静默编译]收紧为显式拒绝）
- **发射域零变更**：IrExpr 保留 Define/Module/Require 发射节点（kerf-compiler 私有发射 IR——D56 scope 纪律）；`lower_module` 项级入口 → 字节码全等由结构保证（Define `[value; Dup; DefineGlobal]` / Module inline / Require PushNil 原臂原样）
- **正交收益（D60）**：非正交点 **2→1**（Define 消除——E5 出口条件③ ≤1 达标，SetBang 受控维持为终态）；anf.rs 三拒绝臂 + driver require_pos_diag 树走随不可表示退役（死代码清除）
- **桥与语料镜像（D57 三面镜像）**：wire 协议文本不变（'define/'module/'require 扁平节点本就是项级形态）——`item_from_value`/`item_to_node` 项桥 + **compiler.krf 零变更**（fixpoint 自举编译器字节码零漂移）+ expander.krf 分类器镜像（classify-seq + classify 专用变换器步[裸产物形——transformer-step 尾部全展的项位豁免]）
- **D61 let 直映臂规格（r49-β 分臂）**：多绑定暂存法 + gensym + hm Let 臂直推[let-polymorphism 原语化——q3 理论根据]；parity 门 = 行为 parity（非字节码全等——闭包调用→内联槽为脱糖形态变更）
- **D62 排期**：r49-β（let 直映——r50 窗内）→ S4 收口（E5 出口三条件终验 + 门审 ≥30 case → v1.0.0）

### 测试与验证
- **净 +9**：kerf-expander 5（位置负例三件[消息逐字] + 项位分类 + do-splice）+ architecture_audit 1（module_item_kind_keyword_face 项面审计）+ namespace d59 组 3（E0023 两形态 + define 前移 + splice 端到端）
- **§3.2 六命令 clean 起步全绿**：build --release workspace 13.70s 零告警 → check 0 → fmt 0 diff → clippy --all-targets -- -D warnings 0 → **test 868:0:0**（859 基线零回归——集成 633→634 + 单元 226→231）+ 五审计集 EXIT 0 ×5 + CLI 全路径（fib 46368 + map prelude (1 4 9) + do-splice `(do (define x 7) x)` → 7 + native fib(10)）
- **门 A/B parity**：bootstrap parity 组全绿（compiler.krf 零变更——字节码零漂移）；expander.krf 语料变更 → B₁/B₂ SHA 重锚合法（门 B 口径）
- **TD-030 登记**：check+prelude 组合 HM occurs 误报（E0005 假阳性——**前置既有缺陷**[r48 stash 基线对照逐字一致失败实证]；发现载体 = 本轮 CLI 冒烟 check 面扩展；修复窗 = r49-β hm Let 臂重做同窗）

### 打包与同步
- tar.gz：`kerf-stage3-v0.16.0-r49-moduleitem-declaration-868tests.tar.gz`（r49-z——包内自举三验全绿）
- web 面：kerf-data r49 节点 + footer v7.19 + stats 868 自动（70-web）
- 文档：22 v2.2 §17（D59-D62 裁定 + 实施对账）/ 01 v6.4（§8.3 三行 + 冻结契约表述）/ 21 v1.3（形态卡 + 非正交计数）/ 18 v7.0（E0023 落位 + 阶段注记）/ matrix v0.1.0-r49 / TD 登记 v0.4.1-r49（TD-030）/ e5-plan v1.7 / roadmap v0.12.0-r49

## v0.15.0-r48（2026-09-20）——de Bruijn IR 臂：IndexIR 解析闭包层（M-I 索引化——D56-D58）（69-a/69-b/69-z/69-web——用户指令「按照 sop.md 继续推进任务」+「同步完整打包项目 tar.gz 并同步完整更新 web page」）

### 交付零：IndexIR 实化（M-I——仅 IR 层；E3 分层裁定 ② 兑现）
- **`kerf-compiler/src/ir.rs` 新模块**：`CoreExpr`（命名制——E3 ① 展开层命名制永久保持）→ **`IrExpr`（解析闭包）** → 字节码（**发射零解析**）三段管线。12 变体同词根镜像（D34 层内延伸）：`IrVar::Local(u32)/Captured(u32)/Global(Symbol)`（槽级词法寻址——de Bruijn level 线性化：alpha-free 编码等价 + VM 帧槽原生对齐零转换损失[A1 实况形式化收编]）+ `IrProto{params[arity 语义承载 + BcProto 元数据], captures[IrCapture 显式环境], free_vars, body}`（M-I 形态卡 `Lambda→Fn(params: usize)`/`VarRef→Var(de Bruijn)` 兑现）+ `IrExpr::Let{slot, bind}`（槽位/判型 lowering 定型）
- **解析单通道**：`Binding`/`ScopeFrame`/`match_bindings`/`resolve_var` 自 compile.rs 迁入 ir.rs——TD-004/r13 的 `(name, scopes ⊆)` 子集匹配语义零变更（compiler.krf L303-366 语义镜像维持）；Let discard/bind 判型 + Define 位置纪律（原型深度词法化——消息逐字保持）归解析域
- **compile.rs 发射域重写**：`compile_module` = `lower_module` + `emit_module`（对外签名零变更——driver 消费面不动）；`emit_ir`/`emit_fn`/`emit_inner_proto`/`emit_handle` 纯发射（原型分配/常量池/跳转回填/trampoline）+ **发射序 = 解析序**（常量池 intern 序/原型序/全局首现序/Handle tag 后置 intern 逐位保持——字节码全等 parity 的结构性根据）
- **D57 镜像纪律精确化**：种子/自举镜像义务 = 三面（共享数据协议[CoreExpr tag/桥] + 解析语义[ScopeSet 子集匹配] + 字节码产物[门 A/B parity]）；编译器内部管线组织不在镜像义务——compiler.krf 零变更合法（fixpoint SHA 零漂移）
- **D58 排期重锚**：E5 出口三条件对账（de Bruijn 不在出口条件内——23 §2.2）；**r49 = Define 上移 + Module 迁移 + let 直映臂**（非正交点 2→1 唯一阻塞臂）→ **r50 = S4 收口**（门审 ≥30 case + 出口终验 → v1.0.0）
- **E3 ② 条件兑现注记**：IndexIR = 15 §5.2 IR 六层规划 ANF+Closed 层 Closed 半面先行实化——优化器 alpha-free 基座就位（SSA/优化 pass 迁移路径：IndexIR → AnnotatedANF → SSA）

### 测试与验证
- **IndexIR 断言组 5 case**（kerf-compiler 单元 16→21）：ir_let_slot_assignment_reuse_and_discard（bind/discard 判型 + 槽分配 + 兄弟槽复用 + 嵌套递增）/ ir_nested_fn_capture_resolution（捕获源 Local 槽定型 + Captured 链 + Global 回退）/ ir_shadowing_max_cardinality_subset_match（TD-004 max-card 语义零变更迁移实证 + 反例全局回退）/ ir_define_position_error_preserved（E0003 消息逐字保持 + Handle 体同拒）/ ir_handle_captures_resolved_for_both_protos（H/B 双原型捕获定型 + 嵌套 fn 帧捕获链）
- **§3.2 六命令 clean 起步全绿**：build --release workspace **15.32s** 零告警 + check 0 + fmt 0 diff + clippy --all-targets -- -D warnings 0 + **test 859:0:0**（854 基线零回归 + 净 +5；633 集成 + 226 单元）+ 五审计集 EXIT 0 ×5 + CLI 全路径（fib 24 → 46368；map + (import kerf-prelude) → (1 4 9)；append + (import kerf-list) → (1 2)；io 门控 read → 77；check ok；let 糖 → 7）
- **门 A/B parity（最严口径）**：全套件零断言修改逐位维持（const_pool_dedup 黄金快照 + bootstrap parity 组全绿）+ B₁/B₂ fixpoint SHA 零漂移（语料零变更 + compiler.krf 零变更）——发射序 = 解析序的执行级证明

### 对账
- 22 v2.1（§16 D56-D58 + 实施对账 + 开发实录三则）/ 01 §8.3（VarRef 行 r48 IR 层索引化 ✅ + Define/Module 行 r49 重锚）/ 21 §5.3（Fn/Var 形态行 M-I ✅ r48 + Define/Module 行 r49）/ 15 §5.2（ANF+Closed 行 Closed 半面 ✅ r48）/ e5-plan v1.6（de Bruijn 臂 ✅ + 排期重锚）/ matrix v0.1.0-r48 / 本文件 / v0.5-roadmap v0.11.0-r48

## v0.14.0-r47（2026-09-19）——可见性收紧腿：N1 扁平面收缩 + TD-029 清偿（D55——68-a/68-b/68-z/68-web——用户指令「按照 sop.md 继续推进任务」+「同步完整打包项目 tar.gz 并同步完整更新 web page」）

### 交付零：可见性收紧腿实施（68-b——22 §15.4 D55 + TD-029 六件合同全实施）
- **①E0022 面核对升级**：基准从全局面升级为**可见面** = N1 核心面 38 名（`N1_CORE_NAMES` 单源——运算符 10 + 恒等/逻辑/中止/断言 4 + 序对/list 构造 4 + 谓词全集 10 + 门控 I/O 6 + Reader 引导私有 4）∪ import 扁平运行时载荷（`flat_underlying`——含 prelude 再导出边际 7 名）∪ 程序 define 面；消息**逐层明细**（「已查：N3 局部绑定 ✗ · N2 import 注入面：未导入——(import kerf-prelude) 后可用 ✗ · N1 核心面 ✗」）+ `suggest_import_for` 导入建议单源（prelude 高频集优先 + underlying 反查）
- **②语料 import 迁移**：compiler/expander.krf 头部 `(import kerf-list kerf-string)`（序章 map/append 引用合法性声明）+ preamble.krf 头部补 kerf-list（nth/drop 再导出源声明）+ 全测试语料（stdlib/namespace/prelude/typecheck/hm/bootstrap/negative/pipeline）+ examples io.krf——**面核对 fail-closed 下 854:0:0 实证**（执行级验证强于 grep 审计）
- **③④face-aware 双改**：W1003/W1002 数据源 = 可见扁平面（N1 ∪ import 载荷）∩ 注册面——**不可见面名自由定义零误报**（限定名宏查模块 ∈ 导入集/别名集）；E0004 接管检查由 E0022 define 面承接（用户接管[define map …] 后引用合法——S1 接管豁免逻辑的推广）
- **⑤prelude 载荷化（D50 ②步）**：`PRELUDE_EXPORT_NAMES` 20 名单源（与 preamble.krf export 列表逐名一致——d50 契约测试锁同步）+ 扁平可见边际 7 名（5 HOF + nth/drop——N1 冗余名去重）+ **E0013 underlying 同一性重基**（D55-b：本地名词法碰撞重基为扁平运行时载荷碰撞——stdlib 域结构性零冲突 + 通道保留 Stage 3+ 用户模块窗口）
- **新增实施裁定 D55-a/b/c**：双集分立（injected_names 本地名/flat_underlying 扁平集——string/symbol/char 模块分立实证）/ E0013 underlying 同一性 / N1 核心面 38 名单源（22 §15.4 落档）

### 测试与验证
- **d55 可见性对账组 8 case**（D54 ④合同 ≥8 满足）：免 import 拒绝 / import 后可见 / 限定名需导入 / io 门重合 / prelude 高频集 / N1 零声明可见 / 别名限定导入 / W1003+W1002 face-aware 零误报
- **n1_core_and_module_flats_closed 闭合锚**（单元）：N1 38 名计数 + prelude 20 名 + 模块边际非重叠机器断言
- **§3.2 六命令 clean 起步全绿**：build --release 零告警 + check 0 + fmt 0 diff + clippy --all-targets -- -D warnings 0 + **test 854:0:0**（633 集成 + 221 单元——845 基线 + 9 净增）+ 五审计集 EXIT 0 ×5 + CLI 全路径 + **E0022 端到端**（`(require io write)(print (map …))` 免 import → 编译期拒绝 span 1:27 携「(import kerf-prelude) 后可用」；`+ (import kerf-prelude)` → (1 4 9)）
- **门 A/B parity**：全套件零行为回归 + bootstrap fixpoint 组全绿（语料 import 迁移后 B₁/B₂ 自一致重建）

### 对账
- 22 v2.0（§15.4 D55 实施对账）/ 18 v6.9（E0022 面核对 + E0013 重基 + W1003 face-aware 注记）/ 20 §5.4 D50 ②载荷步兑现注记 / TD-029 清偿（v0.4.0-r47）/ e5-plan v1.5（可见性收紧腿 ✅）/ matrix v0.1.0-r47 / 本文件 / v0.5-roadmap v0.10.0-r47

## v0.13.0-r46（2026-09-18）——可见性与导入导出机制深审：顶层 import + E0022 + 保留域双形 + prelude 再导出元数据（D46-D54）（67-a/67-b/67-z/67-web——用户指令「能力模型和导入导出机制和可见性与权限管理等方面再审理和内部设计与规划」+「按 sop.md 继续推进」+「同步完整打包 tar.gz 并同步完整更新 web page」）

### 交付零：可见性与导入导出深审（67-a——22 §15 D46-D54 + 六查询实证）
- **缺陷面实测矩阵六项**（probe 实证——R4 以代码为准）：缺 A N1 扁平面未收缩（import 可见性载荷 = 0——47 扁平名 + 47 限定名无条件注册；22 §2.1「v0.6 后收缩」未兑现）/ 缺 B 顶层 import 违例 E0002（与 require E0018 位置纪律不对称无据）/ 缺 C 保留域单形执法（kerf/ 斜杠形漏网 + §7 文本与实现双向不一致）/ 缺 D R-N1 第 4 步编译期失败面缺位（check ok + run E0004 惊喜）/ 缺 E prelude 再导出面缺位（20 §5.4 未落）/ **缺 F compiler.krf 平行 let 值域违例（潜伏——E0022 实证当场捕获）**
- **D46 N1 收缩腿排期重锚**：退出锚从 D7 含混「Stage 3 移除轮后」精确化为 **E5 窗口专腿 r47 可见性收紧腿**（与 Module M-L 同波次合并单一 breaking wave——波次经济学；Swift SE-0444/InternalImportsByDefault 2026-01 工业同向 + Monte 入口点授权导入实证）+ TD-029 登记 + D54 验收合同（六件：面核对/语料迁移/W1003+接管 face-aware/prelude 载荷化/再导出感知 E0013/对账测试组）
- **D47 顶层 import 合法化**：import 合法位 = 程序顶层任意直接元素（与 require E0018 对称）+ module 头部区（既有）；表达式子树/体中段维持 E0002（消息重述双侧——Rust + expander.krf）；机制 = driver Stx 层剥离（面收集后 expand 前——import 零运行语义）
- **D48 保留域双形执法**：kerf-（连字符标识形）+ kerf/（斜杠形——模块名与限定名同词法域）双形 E0015；实现补斜杠形拦截 + §7 文本双侧对齐
- **D49 E0022 编译期未绑定引用（R-N1 第 4 步载体——基线版）**：基准 = **编译产物 global_refs**（编译器已完成局部消解——卫生局部名零误报；r46 实施实录教训：CoreExpr Var 树遍历误判卫生局部名）∩ 已定义集（register_globals 按授权分项 + define-only 面[assign 名不构成定义]）；hyg 基名口径（与运行期回退解析同逻辑）；限定名/门控名不参与（E0014/E0006 语义域先行）；**HM A4 动态逃生舱语义收敛**（未绑定 front 先拒——零 HM 误报承诺保持且加强）；运行期 E0004 保留为防御纵深；span 归因 find_var_span 树序 DFS（A1 求值序契约编译期镜像）
- **D50 prelude 再导出面落位（分两步）**：r46 元数据步（头部 `(import kerf-core kerf-pair)` + export 20 名 = 自有五件 + 序对三件 + 表域两件 + 谓词全集十件——判据：序对构造是同像性氧气管 / length/append 次级频率 / 「prelude ≠ 全 stdlib 藏身所」；collect_import_face 对 prelude 自身 import 结构性跳过——模块内部可见面 ≠ 导入者注入面）→ r47 载荷步（注入面派生单源 + 再导出感知 E0013）
- **D51/D52 能力模型细化**（21 §4.6/§4.7）：能力生命周期动词表（九动词 × 三态矩阵——撤销/衰减分态裁定：声明态程序原子性 + 令牌态线性消费 = 一次性撤销特例 + 衰减器 Stage 3 net 窗口重评）+ 调用通道定位表（六通道 × 授权/可见性/检查/诊断/判据五维——用户「使用能力 vs 使用内置/库」指令的直接交付物）
- **D53 四形式最优性复审**：require/import/export/module 维持（D25 复用——零新负判据）+ 头部区纪律精化 + 选择性导入接口位锁定（Racket only-in 谱系实证；三逃生阀在位时第四阀 = 语法税——Stage 3+ 用户模块窗口评估）

### 交付一：实施（67-b——845:0:0）
- **kerf-driver**：`verify_unbound_refs`（front 4.5 步——compile 后 global_refs 基准）+ `find_var_span`（树序 DFS——fn 位优先归因）+ `collect_define_names`（define-only 收集器）+ `strip_toplevel_imports`（1.68 步）+ collect_import_face/collect_import_targets/imports_prelude 三扩展（顶层 import 形态 + prelude 模块结构性跳过）+ E0015 双形判定 + E0022 码位
- **expander 双侧**：core_forms.rs E0002 消息重述 + expander.krf 同步（「import/export 只能出现在程序顶层直接元素位或 module 头部区」）
- **preamble.krf**：头部 `(import kerf-core kerf-pair)` + export 面 20 名（元数据态——r47 载荷化）
- **compiler.krf 缺 F 修复**：cc-locals-push! 平行 let 第四绑定值引用同组前位绑定（`(slot (length locals))`——平行语义下未绑定全局引用；bind 模式死代码掩盖、let 直映落地即爆）→ 嵌套 let 重写（let* 语义显式化）
- **测试**：835 → **845:0:0**（净 +10：namespace_tests d47×5/d48×1/d49×3/d50×1）+ **15 处语义保持型迁移**（E0004 运行期未绑定 → E0022 编译期前移——negative_semantics/vm_tests/compiler_tests/negative_vm/qbe/hm A4/test_runner 错误载体迁移；runner 恢复语义意图保持[错误载体改运行期错误形态]）
- **§3.2 六命令全绿** + 五审计集 EXIT 0 ×5 + CLI 全路径（fib 144/macros 42/check ok + 顶层 import 三形态端到端 + E0021 维持 + E0022 新端到端）
- **开发实录三则（R1）**：①**global_refs 基准的必要性**（Var 树遍历把卫生局部名 `locals$hyg$N` 误判全局——编译器编译期局部消解产物；以编译器实际消解结果为准是未绑定检查的正确口径）②**平行 let 值域违例的潜伏性**（bind 模式死代码掩盖未绑定——E0022 在死码路径仍有编译期可见性[global_refs 无死码概念] = 检查设计超越执行路径的正面价值）③**assign 名自满足陷阱**（collect_takeover 含 Assign 名会自满足已定义集——define-only 收集器后 assign 目标核对语义正确）
- 对账：22 v1.9（§15 D46-D54 + §7 双形修正）/ 21 v1.2（§4.6 动词表 + §4.7 通道表 + §7 锚三行）/ 20 §5.4 D50 注记 / 18 v6.8（E0022 行）/ e5-plan v1.4（r46 记录 + r47 收缩腿）/ TD-029 / matrix r46 行（845 = 625 + 220）/ RELEASE v0.13.0-r46 / v0.5-roadmap

- **里程碑：可见性启用件交付（E0022 + 顶层 import——R-N1 第 4 步与主程序 N2 入口兑现；compiler.krf r45 潜伏缺陷实证捕获）；下一步 r47 可见性收紧腿（N1 扁平面收缩——D46/D54 合同：面核对 + 语料 import 迁移 + face-aware 双改 + prelude 载荷化；与 Module M-L 同波次）→ de Bruijn IR → S4 收口（非正交点 ≤1 + 门审 ≥30 case）**

---

## v0.12.0-r45（2026-09-17）——E5 S3 结构臂首臂：Do 消除 + Let 引入（M-D+M-A——D41-D45）（66-a/66-b/66-z/66-web——用户指令「按 sop.md 继续推进任务」+「同步完整打包 tar.gz 并同步完整更新 web page」）

### 交付零：结构臂首臂设计核对（66-a——22 §14 D41-D45）
- **D41 Let 入 Core 层**（E1 DEFER-TO-STAGE3 的 Stage 3 重评 GO）：①`Op::StoreLocal` 既有——零 VM 指令变更 ②discard/bind 双模式编译规则（discard：`[value; Pop; body]`；bind：`[value; StoreLocal(槽); body]` + 原型 n_locals 编译期回填）③五面同词根天然成立（let ∈ Keyword 25 名）④M-A 不可归约判据精确化：Let 职责 = 编译期显式局部绑定锚点——Fn+Apply 组合语义等价但结构匿名（每绑定一闭包 + 无法锚定 ANF 优化）——A-normal form 正典共识 ⑤IrNode::Let 图 IR 映照（IrNode::Do 删除——无生产者死代码）
- **D42 Do 消除 + do→Let 链脱糖**：`(do e1...en)` → `Let[do, e1, ... en]`（恒定名 "do"——E0020 保留字名用户 Var 不可引用 + 嵌套屏蔽无害 + 空集作用域名称基语义）；**字节码 parity 最严口径硬证明**——discard 模式与原 Do 逐项序列**逐指令全等**（黄金快照 const_pool_dedup_in_program 维持 + 新锚 let_bind_mode_emits_store_local）；D30 先例域内形态分离（脱糖归约非名面漂移——D34 精确化正确适用）
- **D43 修正版 let 系糖裁定**：let/letrec 维持 App[Fn] 组合推导（**平行语义零风险**——嵌套直映破坏 let 平行性[值序可见性]；letrec 字节码零漂移[Fn+Assign 编译路径不变]）+ hm D4 识别重写为链形态（Fn 体 = Let 链前导 Assign 群——预置/合一/泛化零变更）+ **let 直映归 r46 臂**（多绑定暂存法——fresh 临时变量保平行语义 + gensym 基础设施先行；名实暂分离登记 D30 受控域）
- **D44 名面**：kind_name 12 名表 -do +let；s3mr 9 原语级集合 do→let 换位（let ∈ Keyword 注册面）；桥 tag 'do 退役 / 'let 入（4 字段[名/作用域/值/体]——与 assign 对称）
- **D45 分臂排期**：r45 Do→Let ✅ / r46 Define 上移 + Module 迁移 + let 直映 / r47 de Bruijn / S4 收口——**非正交点 3→2→1**（21 §5.5 口径演进）

### 交付一：Do→Let 臂全链实施（66-b——835:0:0）
- **kerf-core**：CoreExpr::Let 引入（name/scopes/value/body/span——TD-004 绑定器作用域同口径）+ Do 变体删除（kind_name/render/free_var_occurrences 全迁移）；IrNode::Let + IrNode::Do 删除 + code_value 遍历迁移
- **kerf-compiler**：compile Let 臂（discard/bind 双模式 + 尾位穿线 + 局部槽 push/pop + n_locals 回填）；hm Let 臂（HM let 规则——RHS→solve→泛化→装订→恢复 + 体 define C7 泛化维持）+ D4 letrec 链识别重写；typecheck Let 臂（词法装订 save/restore）
- **kerf-vm**：eval Let 臂（discard/bind 同判据 + 子环境词法绑定）+ **VM 帧分配 n_locals 扩展五点**（main ×2 + Call + TailCall + InstallHandler B thunk/H 变形——`alloc_local_cells`/`nil_local_cells` 辅助：参数前 k 槽 + Let 槽 nil 初始化）
- **kerf-backend**：anf Let 链 lower（值/尾上下文双臂——qbe PoC 域）
- **kerf-expander**：expand_begin → make_do_let_chain（恒定名构造 + 空序列 nil 字面量 + 单元素直返）+ wrap_body Let 链化
- **kerf-driver**：capability ×4 + driver ×6 遍历臂迁移 + 宏产物探针语料修正（多元素 do——单元素链直返无节点可判）
- **自举桥**：bootstrap_compiler/expander 4 字段对称协议（'let tag）+ expander.krf（make-do-let-chain + 契约注释 + wrap-body）+ compiler.krf（let 臂双模式 + fvo let 臂 + `expr-references?`/`cc-locals-push!`/`proto-bump-nlocals!` 辅助族）
- **测试**：834 → **835:0:0**（净 +1：let_bind_mode_emits_store_local bind 模式指令序列锚）；黄金快照维持（const_pool_dedup——do 形式字节码 parity 机器验证）+ s3mr 12 名表更新 + 糖锚渲染期望迁移（(let (do) 1 2) 形态）+ GC 压力测试形态迁移（4000 项 do 平铺 → 顶层平铺序列——语义等价[同 alloc+Pop 压力]零深递归；深嵌套栈深限制 = r44 hm 既有基线特性注记）
- **§3.2 六命令 clean 起步全绿**：clean 747 files/254.4MiB → build --release 14.45s 零告警 → check 0 → fmt 0 diff → clippy --all-targets -D warnings 0（while-let 同型 + 多余 cast 两处修正）→ **test 835:0:0**；五审计集 EXIT 0 ×5（233 维持）；CLI 全路径（fib 75025/144 + macros 42 + check ok + **let bind 25 新端到端** + do 3 + letrec true + while 10 + E0021 REAL_EXIT 1）
- **开发实录三则（R1）**：①桥字段序对称（初版 3 字段不对称——'literal x 位「期望 int 实际 nil」当场定位）②空 do 链 'literal x 位遗漏修正 ③GC 压力形态迁移（do 平铺 → Let 链 4000 层嵌套触发编译递归深度基线——**语义等价平铺重写**非阉割）
- 对账：22 v1.8（§14 D41-D45 + 14.6 实施对账）/ 01 v6.4（§8.3 Do/Let 行 r45 状态）/ e5-plan v1.3（S3 结构首臂记录 + §4 排期表）/ matrix r45 行 / RELEASE v0.12.0-r45

- **里程碑：E5 S3 结构臂首臂交付（Do 消除——「1970 序形式」结构清算；非正交点 3→2）；下一步 E5 S3 结构续臂 r46（Define 上移 + Module 迁移 + let 直映——非正交点 2→1）→ r47 de Bruijn → S4 收口（≤1 + 门审 ≥30 case）**

---

## v0.11.0-r44（2026-09-17）——E5 S3 M-R 名面臂：内部关键字全栈一致性深审（D34-D40）+ 五面同词根 + 自举桥 tag 域重构（65-a/65-b/65-z/65-web——用户指令「内部关键字和候选衍生关键字的完全重新筛选 + 原语本身也是关键字/暴露面与编译器内部一致性[不然内部设计一套开发一套算什么？] + 关键字正交性 + 自举桥同类问题也需重构[正确 > 妥协]」+「按 sop.md 继续推进」+「同步完整打包 tar.gz 与 web page」）

### 交付零：内部关键字全栈一致性深审（65-a——22 §13 D34-D40 + 四查询实证）
- **四套名面现状矩阵**（22 §13.1）：表面关键字 / 自举桥 quote 符号与 tag / Rust ADT 变体名 / kind_name 诊断名——**四语义 8 处不一致 + Keyword 枚举内自身不一致 3 处**（fn↔'lambda↔Lambda↔"lambda" / assign↔'set[第三形——非 set! 非 assign]↔SetBang↔"set!" / do↔'begin↔Begin↔"begin" + var/lit/app 两形并存）；r43「三域零变更」被裁定为**把债务当资产引用的过度引申**（域隔离是防误伤流程 ≠ 名面漂移合法）
- **一致性总则（D34——判据新增）**：「一个语义一个名」：原语级关键字的表面名 = 桥 quote/tag = ADT 变体词根 = kind_name = 渲染面，五面同词根；派生关键字经宏/糖展开到原语（无独立 ADT 节点）；无表面关键字的语义（apply/var/literal）用内部统一名三面同名。**原则 31 精确化**：分离的是语法形态（皮肤可替换），不是名词根（名面一致）——名面漂移不是分离原则的推论而是其违反（正向：Python AST 同词根[ast.If↔if]；反向：Racket `#%plain-lambda` 双轨家族病活体实证）
- **M-R 重命名族逐名裁定（D35——修正 01 §8.3 原候选）**：五件 GO（`Lambda→Fn`/`SetBang→Assign`/`Begin→Do`/`App→Apply`/`VarRef→Var`——M-R 与 M-E 解耦：D5 否决的是效应化实现，纯重命名零语义载荷独立合法）；**两件 NO-GO**（`If→Branch`：表面 if 是 D22 跨家族通用语，重命名制造新分离——一致性 > 行为导向微优化；`Literal→Const`：literal 精确覆盖 quote 产物，const 偏编译期常量概念，不可变性由类型系统保证[原则 23/30]名无需编码）——判据先于先例的操作实例（01 §8.3 是 next3 轮裁定，新判据推翻其中两行）
- **S3 分臂裁定（D39）**：r44 = M-R 名面臂 + 三域一致化（~270 Rust 处 + 桥语料 ~30 处 + 测试期望）；结构臂（Define 脱糖/Do→Let 链/Module 迁移/de Bruijn IR）归 r45+ 分臂承载（每臂独立 commit + 字节码 parity 断言先行）；**六域候选空间完备性收敛证明（D40）**：Fn/Assign/Do/Apply/Var/Literal 六域 × 4-5 候选全展开，每域收敛唯一解 + 否决记录保留（Branch/Const 两否决入档）
- **关键字正交性对账（§13.3——用户指令「每个关键字的定位/职责/边界/能力」）**：9 原语级关键字 × 五要素表 + 3 内部名 + 13 派生/声明/数据位——25 表面名每名职责唯一无重叠（M-R 零语义载荷不改正交结构）；知识搜索四查询实证（tool-results/r44-search/：Python AST 节点同词根 / 自举双实现同步 / Racket #%plain-lambda 双轨 / PEP8-C# 命名一致性）

### 交付一：M-R 名面臂实施（65-b——§3.2 六命令 + 834:0:0）
- **变体五件重命名**（expr.rs 枚举定义 + OCaml 规范块同词根化[规范↔代码互锚] + 15 crate 文件 + 7 测试文件 ~244 处 + 注释面全清扫——crates/tests/examples 旧名 grep 零残留）；**Keyword 枚举对齐**（D36：`Keyword::Fn/Assign/Do` 变体名 = as_str 字面 + `Keyword::ALL` 25 名单源[预内部化与 roundtrip 共享]）；**kind_name 12 名表**（D37：fn/apply/if/var/literal/assign/define/do/module/require/perform/handle——诊断面与桥 tag 同名穿透）
- **自举桥 tag 域重构（D38——用户指令点名载荷）**：六处改名 `'lambda→'fn`/`'set→'assign`/`'begin→'do`/`'app→'apply`/`'lit→'literal`（全词统一——两形并存清偿）/`'var` 维持；expander.krf（产出点）+ compiler.krf（双 pass 匹配点）+ bootstrap_compiler.rs（tag 表）+ bootstrap_expander.rs（消费臂）四文件双侧对称迁移；tag 改名 parity 影响分析：tag 是数据协议标记非 bytecode 组成——门 A CoreExpr parity 恒成立 + 门 B fixpoint 随语料变更重建（SHA 重锚合法）
- **新增机器断言 ×2**：`s3mr_kind_name_keyword_face_penetration`（五面穿透——9 原语级 kind_name ∈ Keyword 注册面 + 3 内部名 ∉ 关键字面[内部名独立域不侵蚀 E0020 全域排他]）+ `keyword_all_roundtrip_and_distinct`（25 名全量 roundtrip + 字面互异 + 计数锚）；architecture_audit 12 名表同步 + r43 遗留 unused import 清偿（clippy -D warnings 0）
- §3.2 六命令 clean 起步全绿（build 14.26s 零告警 / check 0 / fmt 0 / clippy --all-targets -D warnings 0 / **test 834:0:0**[615 集成 + 219 单元——净 +2]）+ 五审计集 EXIT 0 ×5（233）+ CLI 四路径（fib 144 / macros 42 / check ok / E0021 端到端 REAL_EXIT 1 携「现代形式「fn」」）
- 对账：22 v1.7（§13 D34-D40 + 13.4 实施实录）/ 01 v6.3（§2 OCaml 块同词根化 + §8.3 修正版 + §8.5 五面锚）/ 17 v6.6（原则 31 精确化）/ 20 v1.5 注记（S3-M-R 行 ✅）/ e5-plan v1.2（S3 分臂记录）/ matrix v0.1.0-r44 / RELEASE v0.11.0-r44 / v0.5-roadmap v0.8.0-r44

- **里程碑：E5 S3 M-R 名面臂交付——「1970 表面」清算第三腿（S1 库面 r42 + S2 表面 r43 + S3 内部名面 r44 三腿闭合，五面同词根终态）；下一步 E5 S3 结构臂 r45+（Define 脱糖/Do→Let 链/Module 迁移/de Bruijn IR——字节码 parity 最严口径）→ S4 收口（非正交点 3→≤1 + 门审 ≥30 case）**

---

## v0.10.0-r43（2026-09-16）——E5 S2 关键字腿：关键字完全重筛深审（D19-D33）+ 三件切换 fn/assign/do + E0021 扩展（64-a/64-b/64-c/64-e/64-z/64-web——用户指令「内部关键字与候选衍生关键字的完全重新筛选——语义清晰/无二义/标准符合 + 2026 前沿 + 内循环迭代收敛」+「按 sop.md 继续推进」+「同步完整打包 tar.gz 与 web page」）

### 交付零：关键字完全重筛深审轮（64-a/64-b/64-c——22 §12 D19-D33 + 八查询实证）
- **全 24 文档七维度第三轮扫描**（r40 D1-D9 + r41 D10-D18 后第三轮——含新增**关键字语义面**维度）：六维既有收敛维持 + 关键字语义面首轮深审——25 名全量三判定（J-1 语义清晰 / J-2 无二义[含**名空间经济**新判据——E0020 严格保留字启用后首次完整适用] / J-3 2026 跨家族标准符合）
- **两处 P2 候选修正**（判据驱动非先例驱动）：①`set!→assign`（**否决原候选 set**——名空间经济：set 是集合构造 2026 生态标配名[Clojure/Python/Kotlin]——E0020 全域排他将永久禁标准库 set 注册 + assign 精确对应 assignment）②`begin→do`（**否决原候选 seq**——Clojure seq 序列生态核心名占用 + do 与 Scheme begin 完全同义[Clojure 现代化先例] + 动词化[原则 29]）；`lambda→fn` 维持原候选强化（Rust/Janet/Gleam 三家族 2026 共识 + 形态同构 + 2 字符 + 低频标识符占用近零）；其余 22 名维持裁定（D22-D27 全表——每名 ≥2 实证源）；4 项 P3/登记项如实入册（let\* 平行/顺序频率倒挂[语义冻结无通道] / require Clojure 撞名 / when Kotlin 异形 / else 数据位结构登记）
- **衍生关键字 S3 形态名一致性对账**（D30——原则 31）：fn↔Fn 对齐（S3 重命名族）/ assign↔SetBang 分离合法（S3 裁定不迁——D5 受控维持）/ do↔Begin→Let 分离合法（脱糖链解耦）；**否决记录表八行保留**（fun/func/mut/match/macro/continue 备选否决判据入册——原则 35「否决与采纳同等一等」）；`/` 分隔符与 (op args...) 操作位统一零交互复审（D32/D33——r40+r41+r43 三轮收敛证明）
- 知识搜索八查询实证（tool-results/r43-search/：fn 四形态对比 / Clojure do-begin 同义 / `!` 标记 SE / 保留字占用 / OCaml5-Koka-Eff perform-resume / Janet-Gleam 现代 Lisp / **Clojure seq 生态占用** / **Clojure set 构造占用**——D20/D21 否决的决定性证据）

### 交付一：S2 关键字腿实施（64-e——§3.2 六命令 + 832:0:0）
- **三件切换**：`lambda→fn`/`set!→assign`/`begin→do`（Keyword::as_str + from_name 双向单源——变体名 Lambda/SetBang/Begin 不变[原则 31 表面/内部分离]；expander WORD\* 词表经 keyword_symbol 派生自动跟随；E0020 禁绑面 25 名计数不变——三名出三名入）
- **E0021 扩展至关键字旧名**（22 §12 D29）：`REMOVED_KEYWORD_NAMES` 3 对表 + driver VarRef 臂分源检查（消息分源——内置旧名维持 S1 文案[27 负例组断言锚] + 关键字旧形新文案「关键字已切换——现代形式」）；**接管豁免同口径**（用户 `(define lambda 5)` 后 lambda 为合法用户变量——退役的是 N4 关键字面非 N0 符号宇宙层）；CLI 端到端 REAL_EXIT 1 ×3 形态
- **渲染面跟随表面**（r42 `#<builtin:head>` 先例）：CoreExpr::render 三 format 串（fn/assign/do——kind_name 内部 ADT 名维持[S3 腿才改]）+ 魔法符号 `<lambda>`→`<fn>`（匿名 fn 原型渲染）+ core_forms/anf/vm 用户可见消息面六处 + driver E0020/W1002 消息（「fn 参数」）
- **三域分离实录**（R1 开发实录——本轮最重要实施发现）：`begin`/`lambda` 在语料中存在**三个命名域**——①表面关键字域（源码形式头——切换 ✓）②**自举桥 tag 域**（bootstrap\_compiler/bootstrap\_expander + compiler.krf `(eq tag "lambda"/"set"/"begin")`——CoreExpr 值序列化标签，`"set"` 无 `!` 即其独立证据——**零变更**[tag 与 .krf 侧解析精确匹配是自举链生命线]）③**core 节点 quote 符号域**（expander.krf `(list 'lambda ...)`——展开产物 tag——零变更）；误伤两次均当场发现修复（全局词边界替换的 IDCH 排除集把 `begin/` 中文斜杠语境排除 + cfg(test) 文件中位结构陷阱——**教训入 worklog**）
- **全语料迁移 800+ 处**：引导 .krf ×4（compiler 120 + expander 92 + reader 3 + preamble 0）+ tests 578 + examples + audits——词法边界替换（IDCH 负向先行防 `set!x` 类标识符误伤）；语料终态 grep 实证（残留 = tag 域 + E0021 负例测试数据 + 内部名注释——全部合法）
- **s2 负例组 4 case**（namespace_tests：E0021 三旧形四形态[操作位/值位/携新形指引] + 接管豁免[define lambda 合法值 5] + E0020 新名禁绑四形态 + 门 A 行为 parity[fn/assign/do 运行值断言——表面/内部分离原则 31 的行为面验证]）
- §3.2 六命令 clean 起步全绿（build 14.00s 零告警 / check 0 / fmt 0 diff / clippy -D warnings 0 / **test 832:0:0**[828 基线 + s2 组 4 净增]）+ 五审计集 EXIT 0 ×5 + CLI 四路径 + E0021/W1003 端到端 + 双 Reader 同核行为面
- 对账：22 v1.6（§12 D19-D33 + 三判定表 + 否决记录表 + 收敛证明）/ 01 v6.2 注记（§7.2 表面候选确认）/ 02 v6.4（Keyword 25 名文字）/ 20 v1.5 注记（S2 行 ✅）/ 18 v6.7 扩展（E0021 关键字旧名行）/ e5-plan v1.1（S2 载荷修正 + §4.2 否决记录）/ matrix v0.1.0-r43 / pipeline r43 / 23（E5 S2 行 ✅）/ v0.5-roadmap

- **里程碑：E5 S2 关键字腿交付——1970 表面清算第二腿（N4 关键字面现代形唯一）；下一步 E5 S3 ADT 腿（Define 脱糖/Begin→Let 链/Module 层级迁移/重命名族/de Bruijn IR 层——字节码 parity 最严口径）→ S4 收口（非正交点 3→≤1）**

---

## v0.9.0-r42（2026-09-15）——E5 窗开启 + 移除轮 S1 表面腿：旧名 27 件退役 + E0021 + W1003（63-a/63-b/63-z/63-web——用户指令「按 sop.md 继续推进任务」+「同步完整打包 tar.gz 与同步完整更新 web page」）

### 交付零：E5 开窗设计轮（63-a——入口信号四核对 + parity 链保护方案）
- **E5 窗合法开启**（23 §2.2 红线 3「禁止无信号开窗」合规）：①窗 M 后 v0.6 稳定期（M3 闭环 837:0:0 + 弃用期跨版本核对[W1001 落地 v0.7 → v0.8 一稳定版全绿 → v0.9 移除]）②12 §2.5.1 全行终态（磁盘实况逐行核对）③外循环投票 5/5 = 100% GO（e5-plan §6 记录）④自举 parity 链保护方案评审通过
- **设计载体**：docs/develop/v0/stage-3/e5-removal-round-plan.md v1.0——三腿分步（S1 表面腿[本轮 ✅] / S2 关键字腿[lambda→fn 等 N4 面] / S3 ADT 腿[Define 脱糖/Begin→Let/de Bruijn] + S4 收口）；parity 断言矩阵复用 i1 门 A/B/C 三门（零新造——原则 6）；`?`/`->` 词法域收紧裁定 = 维持不收紧（否决记录在位——重评条件 = 包生态名冲突实证）

### 交付一：移除轮 S1 表面腿（63-b——§3.2 六命令 + 828:0:0）
- **旧名 27 件退役**：`BUILTIN_ALIASES` 双注册机制下线（20 §7 移除轮行兑现）——主注册 27 对旧名→现代名迁移（`REMOVED_BUILTIN_NAMES` 退役表单源：旧名→现代名指引映射）；注册面 84→57 扁平（+47 限定 = 104 全授权 / 92 零授权）；BUILTIN_SIGS 旧条目删除（83→56 维持）；STDLIB_MODULES 底层 4 名现代化
- **E0021 已移除旧名错误**：driver `verify_qualified_refs` VarRef 臂扩展（与 E0014 同 traversal——遮蔽/接管豁免同口径：N3 局部绑定胜出 + 用户接管合法[退役的是内置注册面非符号宇宙层]）；诊断携现代名指引（比裸 E0004 未绑定 actionable——迁移期 DX 最优）；CLI 端到端 REAL_EXIT 1
- **W1001 退役 + W1003 落地**：弃用族下线（23 §3.4 生命周期四阶段完整走完：引入 v0.5 → 默认 v0.6 → 弃用 v0.7 → 移除 v0.9）；W1003 宏名遮蔽警告（22 §11 D11 排期承诺清偿——Stx 层 `collect_macro_names` 唯一数据源 + `builtin_name_exists`[57 扁平 + 47 限定] + 宏胜出行为不变）
- **全语料现代名终态**：引导 .krf ×4（compiler 249 + expander 511 + reader 200 + preamble 17 处替换）+ 21 测试文件 ~350 处 + examples——词法边界替换（grep 零旧名实证）；**迁移实录：compiler.krf `tail` 参数名与现代内置名碰撞 → `tail-pos` 重命名**（词法遮蔽合法但迁移期文本碰撞——如实登记）
- 负例组 27 名全覆盖（stdlib_tests removed_* 17 case：E0021 三断言 + 参数遮蔽/用户接管合法豁免 + 闭合守卫双向对账）+ namespace_tests s1 组 4 case（W1003 正例/零误报/限定名遮蔽 + E0021 恢复健康/位置面）；hm.rs 结构重解释臂 head/tail 现代化 + anf.rs eq；M3 门审 P07 计数锚更新（43:0 APPROVED 维持）
- §3.2 六命令 clean 起步全绿（build 15.20s 零告警/check 0/fmt 0/clippy 超集 0/**828:0:0**[837 - 9——移除轮测试面合法收缩：28 parity case 收敛为 17 退役负例 + 2 W1001 case 演进为 4 W1003/E0021 case]）+ 五审计集 EXIT 0 ×5（233）+ CLI 四路径 + E0021/W1003 端到端
- 对账八面 + 文档回写：20 v1.5 / 22 v1.5 / 23 v1.5 / 18 v6.7（E0021 + W1003 码位落位）/ 12 / 09 v6.11 / **TD-027 清偿关闭（三腿全兑现：批次 L r38 + M r39-40 + 移除 S1 r42）** / matrix v0.1.0-r42 / pipeline r42 / v0.5-roadmap v0.6.0

- **里程碑：E5 窗开启（四信号全过）+ S1 表面腿交付——1970 表面清算首腿（库表面现代名唯一注册面）；下一步 E5 S2 关键字腿（lambda→fn/set!→set/begin→seq——01 §7.2 候选 + 全语料 + 负例组）→ S3 ADT 腿 → S4 收口（非正交点 3→≤1）**

## v0.8.0-r41（2026-09-15）——批次 M 收口 M3 + 语言形式深审轮：E0020 保留字绑定禁令 + M3 门审 APPROVED（62-a/62-b/62-z/62-web——用户指令「内部语法设计/通解特解/词法语法语义无二义性/层级组织/(a b c) 通解性/多模型组织 + 2026 前沿 + 内循环迭代收敛」+「按 sop.md 继续推进」+「同步打包 tar.gz + web page」）

- **深审 D10（P1 文档-代码冲突当场修复）**：22 §2.1 N4 不变量「不是值、不可引用、不可遮蔽」实测被违反（`(define if 5)` 合法 + 值位可读 + 操作位恒关键字 = 用户绑定**静默失效**——Lisp 家族双轨陷阱）→ **E0020 严格保留字绑定禁令**（25 关键字全域禁作绑定名：define/set!/lambda 参数/let 系/define-syntax 宏名/module 名/import as 别名/handle 双绑定器；Stx 源码面 + CoreExpr 展开产物面双层防御；syntax-rules 模板数据域跳过[零误报]；quote 位 `'if` 数据符号豁免[同像性维持]；值位引用恒未绑定 fail-closed）——12 case 锚定 + 837:0:0 净 +12 零回归
- **深审 D11-D18 七项裁定**（22 §11——六查询实证 + Rhombus v1.0 2026-06 发布深读）：D11 W1003 宏遮蔽警告排期移除轮 / D12 `/` vs `::` 维持（三重依据：模块不嵌套 + 域成员语义读法 + 除法二义性已分立——`.`/`::` 符号期权保留）/ D13 `(a b c)` 前缀 = 当前工程最优解（UFCS 更强形态 + Rhombus enforestation 代价 ×10 对照 + 终态多语法窗维持——「kerf 不被家族限制」三件兑现）/ D14 负数字面量显式无二义 / D15 N4 三件套全编译期执行 / D16 functor 不引入（OCaml 蔓延痛点反向印证）/ D17 维持括号（缩进敏感批判）/ D18 **词法语法语义二义性面全清**（六组潜在歧义源逐一显式裁定）
- **M3 收口门审 APPROVED**：stage3_gate_audit_m3 **43 case**（A11/B9/C6/D5/E5/P7——七类全覆盖 + M1/M2/D10 三修复边界 ≥5 + E2E 全导入路径三通道[限定直引/非限定注入 D7 过渡期语义如实审计/别名归一] + io 授权第四通道 + 计数锚）——**窗 M 出口条件达成**（R-N1~N8 全 case + B1-B3 契约 + 组合闭包 + E2E——23 §2.2）
- §3.2 六命令 clean 起步全绿（build 14.41s 零告警/check 0/fmt 0/clippy 超集 0/837:0:0）+ **五审计集 EXIT 0 ×5**（190+43=233）+ CLI 四路径（fib 144/macros 42/effect_stress 120/check ok+E0005 REAL_EXIT 1）+ E0020 CLI 端到端 REAL_EXIT 1
- 对账八面 + 文档回写：22 v1.4（§11 D10-D18 + §2.1 N4 三件套执行注记）/ 18 v6.6（E0020 码位落位）/ 02 v6.3（§8 Rhombus v1.0 对表注记）/ 14 r41 前沿更新（Rhombus v1.0 三重启示）/ matrix v0.1.0-r41 / pipeline v0.6.0-r41 / 12 v6.13 / 23 v1.4 / 09 v6.10 / v0.5-roadmap v0.5.0
- **里程碑：批次 M 全链闭环（M1 r39 + M2 r40 + 深审 D10 r41 + M3 门审 APPROVED）——窗 M 出口条件达成；下一步移除轮（与 E5 同窗，23 §2.2 触发表驱动）**

## v0.7.0-r40（2026-09-15）——批次 M 次件 M2：import 注入面/别名 + 组合闭包 + B1/B2 契约 + W 弃用族（61-a/61-b/61-z/61-web——用户指令「深审缺陷面 + 知识搜索补充修正」+「按 sop.md 继续推进」+「同步打包 tar.gz + web page」，806 → 825 + E0013/E0016/E0017/E0018/E0019 + W1001/W1002 落位）

### 交付零：设计深审（61-a——六维度缺陷面扫描 + 四查询实证）
- 深审裁定 D1-D9（22 §10）：D1 `as` contextual keyword（N4 零改动）/ D2 E0019 未知导入（Clojure require 同型）/ D3 E0018 require 位置纪律 / **D4 P1 缺口当场修复**（`IoRequirements::from_core` 递归入 Module body 把模块内 require 计入程序级授权 = 环境继承反面形态——恰是 WASI「无环境权威」批判的对象；修正为顶层口径：授权获得唯一路径 = 入口顶层声明）/ D5 B1-B3 限定名独享新契约 / D6 W 独立值域 1000+ / D7 过渡期注入可观测语义知悉项 / D8 W1002 编译期交集检测 + preamble 结构豁免 / D9 零配置面维持
- 知识搜索四查询实证（tool-results/r40-search/）：q1 langdev 导入语义类型学 / q2 滚动弃用与警告失效（HN + Kevin Cox）/ q3 WASI 无环境权威 + ocap 组合 / q4 Clojure refer 冲突逃逸阀

### 交付一：M2 本体（61-b——§3.2 六命令 + 825:0:0）
- import 注入面/别名（R-N5 三形态）：`collect_import_face` Stx 层收集（非限定/`as` 别名[前瞻解析]/混合）+ `rewrite_alias_refs` 编译期归一（`str/append` → `string/append`——HM/编译/运行全链一致）+ registry stdlib 预 declare（七模块 visit 叶子）+ expander 双镜像（core_forms.rs + expander.krf as 对跳过）
- 组合闭包（21 §4.4）：`verify_capability_closure` 需求 ⊆ 授权（E0006 **增强形态**先于基础形态——携模块归属与上移指引）+ `module_requirements` 需求元数据 + **D4 修复**（from_core 顶层口径）+ E0018 位置纪律
- B1/B2 契约：`string/index-of`/`list/member`/`list/assoc` 限定名**独立分派体** miss→nil（旧名/扁平名 parity 不动——20 §4「新名新契约、旧名旧契约并存」迁移不变量）；B3 纯测试锚（底层 FS-4 已对齐——20 §4 行 R4 修正）
- W 警告族：W1001 弃用（27 旧名每名去重 + 现代名指引 + preamble 结构性豁免）+ W1002 遮蔽（R-N2 第二行）+ `RunOutcome/CheckReport/CompileOutput` 三产物面 warnings + CLI stderr 非阻断渲染
- 五码落位：E0013 import 冲突（+ as 逃生阀）/ E0016 模块内重复 define / E0017 别名重复 / E0018 require 位置 / E0019 未知导入——stage 统一 Compile（front 管线验证族）
- §3.2 六命令 clean 起步全绿（clean 2821 files/650.8MiB → build 14.08s 零告警 → check 0/0 → fmt 0 → clippy -D warnings 0 → test 825:0:0：集成 607 + 单元 218）+ 四审计集 EXIT 0 ×4（190 维持——4 case E0019 语义演进同步 + stage_e_code 族扩展）+ CLI 四路径 + import/别名/组合闭包/W 端到端实证
- 存量语义演进修正（D4 行为锚反转）：architecture_audit require 上移（21 §4.4 语义）+ negative_expander/prelude E0019 断言 + capability 单测反转——三处 + 审计集四处全部按新契约更新（破坏面零残留）

### 交付二：对账八面
- matrix v0.1.0-r40 + 本节 + pipeline r40（Tier 2 头 588→607）+ 七文档回写（22 v1.3[§10 D1-D9 + §8 M2 状态] + 18 v6.5[七码全落位 + W 段] + 20 v1.5[B1-B3 + M2 注记] + 21[§4.4 落地 + D4 修复登记] + 12 v6.12 + v0.5-roadmap v0.4.0 + 23/09 注记）+ TD 登记册零新事件

### 交付三：r40 tar.gz 包内自举 + web E2E + rec 树（61-z/61-web）
- r40 tar.gz（§19.3 正序）+ 包内自举（全新解包构建 + 825:0:0 复跑 + 包内四审计集 + CLI 一致 + qbe 在包）+ web 五件面同步 + E2E 双端

### 里程碑
- **批次 M M2 ✅**（import 面 + 组合闭包 + W 族 + 五码——825:0:0 净 +19）——M3 = 全表对账收口 + 门审（§7.3 ≥30 case）→ 移除轮（与 E5 同窗，23 §2.2 驱动）

## v0.6.0-r39（2026-09-15）——批次 M 首件 M1：命名空间层限定名可见面（60-a/60-z/60-web——用户指令「按 sop.md 继续推进 + 同步完整打包 tar.gz 并同步完整更新 web page」，788 → 806 + E0014/E0015 落位）

### 交付一：M1 本体——N2 限定名可见面（22 §8 七行落地）

- **七模块 47 限定名注册**：`builtins.rs STDLIB_MODULES` 单源静态表（20 §5.2 模块树转译：core 14/pair 3/list 9/string 11/symbol 2/io 6/char 2）——`ns/本地名` 注册为与底层共享同一 `Rc<BuiltinFn>` 分派体（同 r38 别名层 parity 形态）；**R-N4 词法零改动**（`/` 已在双路径 ID 域——`str/append` 单 token 天然流过全管线，独立 `/` 除法维持）
- **io 族 fail-closed 分项注册**（22 §5.1 矩阵唯一对齐点「门控全集 ≡ 导出全集」）：未授权分项限定名不注册；R9 `gated_name` 归一化——`io/*` 限定名与门控名同表数据源，未授权引用 → E0006 携「io/print」限定形态（红线 1 双门分立可观测形态）
- **E0014 限定名不导出**（R-N3 不回落——22 §3.3）：`driver verify_qualified_refs` 编译期验证（仅查 stdlib 七面 export + 接管豁免；**Lambda 参数遮蔽**——R-N1 N3 局部胜出[开发实录：初版漏遮蔽集，测试实测发现当场修复]；诊断「不导出」而非「未绑定」——打错模块名精确指向模块面）
- **E0015 保留域违例**（22 §7）：用户模块名 `kerf-` 前缀 → 编译期拒绝（许可名单八名：preamble + 七模块标识形）
- **限定名签名派生**：`builtin_sigs` 按模块表派生（`ns/name` 与底层同签名——check/hm 对限定名同判；read-line 底层不列口径维持）

### 交付二：§3.2 六命令 + 审计 + CLI + 对账

- **788 → 806（净 +18）零回归**（集成 +17：namespace_tests 新文件[tests/v0/stage3/plan/ 首件]；单元 +1：模块表闭合守卫[47 行数/分面计数/131-119 计数锚/派生签名]）
- 四审计集 EXIT 0 ×4 维持（190）+ CLI 四路径（fib 144/macros 42/effect_stress 120/E0005 REAL_EXIT 1）+ **限定名端到端实证**（七模块正路 + E0014/E0015/E0006 限定形态负路 + 除法/符号值锚）
- 对账：matrix v0.1.0-r39 + pipeline r39（Tier 2 头 571→588）+ 六文档回写（18 v6.4[E0014/E0015 落位回填——「先查本表占位」纪律兑现]/20 v1.4/22 v1.2[§8 M1 落地状态]/12 v6.11/23 v1.2[窗 M M1 进行中]/09 v6.8）+ v0.5-roadmap 批次 M M1 行 + TD 登记册零新事件

### 交付三：r39 tar.gz 包内自举 + web E2E + rec 树（60-z/60-web）

- r39 tar.gz（§19.3 正序）+ 包内自举（全新解包构建 + 806:0:0 复跑 + 包内四审计集 + CLI 一致 + qbe 在包）
- web 面：kerf-data r39 节点 + footer v7.9 + download README r39 节 + E2E 双端 + lint 0 + git 双仓 clean
- rec 树：02_r39 新建（03 层）+ l 更新

### 里程碑：批次 M M1 ✅（限定名可见面核心）——M2 = import 注入面/别名 + B1-B3 契约 + W 弃用族 + 冲突三类 + 组合闭包（22 §8 驱动）

---

## v0.5.0-r38（2026-09-15）——批次 L 别名层：库表面现代化首件 / Stage 3 入场序列（59-a/59-z/59-web——用户指令「按 sop.md 继续推进 + 同步完整打包 tar.gz 并同步完整更新 web page」，758 → 788 + 27 parity 全绿）

### 交付一：批次 L 本体——27 现代扁平名双注册（20 §6.4 四件实施清单全落地）

- **① 注册面 57→84**：`builtins.rs` 新增 `BUILTIN_ALIASES` 静态表（27 现代名 → 旧名——20 §8 映射表实施单源）+ `register_globals` 双注册段；**别名与旧名共享同一 `Rc<BuiltinFn>` 分派体**：同行为同诊断天然 parity（20 §9.3——负例错误消息含旧名属设计口径：双名渲染逐字一致即 parity）；词法/语法零变更（27 别名全为既有词法形态的扁平符号——02 §8.1 B1-1 v0.5 面澄清）
- **② `BUILTIN_SIGS` 双名同步（56→83）**：27 别名条目逐字复制旧名签名（同分派 → 同静态检查面——check/hm 消费方对新名同判）
- **③ 门控表零变更实测**：I/O 六门控名（READ_GATED/WRITE_GATED）零新名——守卫锚（六名 ⊆ 注册 + 别名零交集）
- **④ parity 测试组 27 case + 漂移守卫三方扩展**：stdlib_tests 别名组（正例双名同值 + 负例**阶段/诊断码/消息体三面比对**——开发实录：rendered 源码回显与 Span 列号随名字长度自然平移，非诊断内容差异，比对面收敛为诊断内容三面）+ 闭合守卫（静态名单 ↔ `BUILTIN_ALIASES` 双向对账：零缺零溢）+ builtins.rs 单元守卫 ×2（`builtin_aliases_closed_and_parity_typed`：27 表长/84 计数锚/双注册/双签名逐项相等/零重复零链式；`builtin_gating_names_subset_of_registered`：门控腿）
- 27 别名清单：head/tail/nth/drop/is-nil/is-pair/is-int/is-bool/is-procedure/is-string/is-symbol/is-float/is-number/is-list/eq/string-append/string-length/string-substring/string-index-of/string-contains/string-starts-with/string-ends-with/string-to-upper/string-to-lower/string-to-symbol/symbol-to-string/assert-eq

### 交付二：§3.2 六命令全绿 + 审计 + CLI + 对账

- **758 → 788（净 +30）零回归**（集成 +28：stdlib_tests 27 parity + 闭合守卫 1；单元 +2：builtins 守卫 ×2——22 套件逐二进制实测）
- 四审计集 EXIT 0 ×4 维持（stage0 41 + stage1 50 + stage2_r1 53 + stage2_r2 46 = 190）
- CLI 四路径维持（fib ⇒ 144 / macros ⇒ 42 / effect_stress ⇒ 120 / check 负例 E0005 REAL_EXIT 1）+ **别名端到端实证**（`head/tail/string-contains/eq/nth` 经 run 路径全过 + E0006 门控 fail-closed 维持——未声明 `(require io write)` 时 `print` 仍编译期拒绝）
- 对账面：matrix v0.1.0-r38（r38 增量行 + 总量行 788 = 217 单元 + 571 集成）/ pipeline r38（Tier 2 头 543→571）/ TD-027 进展注记（批次 L 腿 ✅——剩余批次 M + 移除轮）/ **六文档回写**：20 v1.3（§6.4 兑现 + §7 行 ✅ + §10 锚点 ✅）+ 12 v6.10（§2.10 批次 L 行 ✅）+ 23 v1.1（§2.2 窗 L 出口条件 ✅）+ 09 v6.7（§2 r38 双注册注记 + §4 状态）+ 02 v6.2（§8.1 B1-1 v0.5 面澄清）+ 07 v6.3（引导语料双注册注记）+ v0.5-roadmap v0.3.0（批次 L 行 ✅——Stage 3 入场序列首件）

### 交付三：r38 tar.gz 包内自举 + web E2E + rec 树（59-z/59-web）

- r38 tar.gz（§19.3 commit-then-package 正序）+ 包内自举验证（全新解包构建 + 788:0:0 复跑 + 包内四审计集 EXIT 0 ×4 + CLI 一致）
- web 面：kerf-data r38 节点 + footer v7.8 + download README r38 节 + E2E 双端 + lint 0 + git 双仓 clean
- rec 树：22_r38 新建（Stage 3 入场序列层）+ l 两层更新

### 里程碑：批次 L ✅（窗 L 出口条件三全过）——下一步批次 M（v0.6 命名空间层，22 §8 实施对账表驱动）

---

## v0.4.0-r37（2026-09-15）——批次 K 终件：K3 收尾交付 + r36 收尾中断清偿（58-c/58-a/58-z/58-web——用户指令「按 sop.md 继续推进 + 同步完整打包 tar.gz 并同步完整更新 web page」，758 维持全绿 + **批次 K 全闭环 → Stage 2 全收口**）

### 交付零：r36 收尾中断清偿（58-c——PHASE 4 纪律诚实登记）

- 上会话在 r36 收尾段中断（tar.gz 已打包 01:46 + kerf-data r36 节点已写，但 rec 树 commit/57-z/57-web worklog 双源条目/footer v7.6/download README r36 节/PACKAGE_CONTENTS 未落）→ 本会话以磁盘实况为准（R4）逐件补齐：footer v7.6（五处 r36 同步）+ download README r36 节 + PACKAGE_CONTENTS 四处 r36 口径 + worklog 双源 57-z/57-web 条目补账 + kerf 仓 rec 树 commit（9dc8d28）+ E2E 双端（r36 关键词全命中 + 移动端 375 零横溢 + footer 贴底 + stats/download API + lint 0）

### 交付一：§3.2 六命令 clean 起步全绿（零代码收尾轮——K3 验收合同第一门）

- cargo clean（680 files/238.5MiB）→ **build --release 13.15s 零告警** → check --workspace 0 errors 0 warnings → fmt --check 0 diff → clippy --all-targets --workspace -- -D warnings 超集 0 → **test --release --workspace 758:0:0 零断言修改**（22 套件——集成 543/26.67s + 单元 215）
- **四审计集 EXIT 0 ×4**（stage0 41 + stage1 50 + stage2_r1 53 + stage2_r2 46 = 190 case 全 APPROVED）
- CLI 四路径：run fib ⇒ 75025 ⇒ 144 exit 0 / run macros ⇒ (2 1) ⇒ 42 exit 0 / check ok「2 原型/9 常量/5 全局引用/38 指令」exit 0 / check 负例 **E0005「+ 需要数值，实际 str（静态检查）」定位 1:4 REAL_EXIT 1**（HM 旗标期判定面维持）

### 交付二：对账六面 + 12 §2.5.1 终态注记 + v0.5-roadmap Stage 2 行收口

- 对账六面：matrix v0.1.0-r37（r37 增量行零增量维持）/ pipeline v0.4.0-r37 / RELEASE_NOTES 本节 / plan K3 执行注记 + Status 行（**批次 K 全闭环 + Stage 2 全收口**）/ **v0.5-roadmap v0.1.0 → v0.2.0**（Stage 2 行收口——批次 G→H→I→J→K 全链终态 + 批间插入 r19/r32-r34 + Stage 3 GO 注记 + 批次 L/M 入场序列；12 §2.10 预锚「K3 交付时直引」兑现）/ TD 登记册零事件（TD-028 维持 P3——28 项开放 P0/P1 = 0）
- **12 §2.5.1（附加）类型检查器行 K3 终态注记**：r31「默认期评估移交批次 K 终门审」→ K3 闭环（K1 P07 九信号核对 + K2 深审 GO + K3 收尾）——**默认期评估结论**：HM 旗标期维持（判定面 = hm_check_program；R1-R8 退为回归基线断言双面检出纪律保留）；默认期切换窗口（hm-inference-design §2.3）归 23 §2.2 治理触发表 Stage 3 承载——**触发式非时间驱动**（时间治理四红线之一）

### 交付三：r37 tar.gz 包内自举 + web E2E + rec 树（58-z/58-web）

- r37 tar.gz（§19.3 commit-then-package 正序：git commit 先行 → §19.4 十二路径）+ 包内自举验证（全新解包构建 + 758:0:0 复跑 + 包内四审计集 EXIT 0 ×4 + CLI 一致 + qbe 在包）
- web 面：kerf-data r37 节点（Status 行「批次 K 全闭环 → Stage 2 全收口」+ points 两条）+ footer v7.7 + download README r37 节 + E2E 双端（r37 关键词全命中 + 移动端 375 零横溢 + 控制台零错误 + stats/download API + lint 0）+ git 双仓 clean
- rec 树：21_r37 新建（1:8 压缩）+ l 两层更新 + 未压实区间刷新至 r37 终态

### 里程碑：Stage 2 全收口（v0.4.0 终态）

- **批次 K 全闭环**：K1 终门审 APPROVED（stage2_gate_audit_r2 46 case + §21.3 四条件终验 + §21.5 九信号 + 投票 100% GO）→ K2 大阶段末深审环（§14.6.3 三轮深挖 + deep-review-round2 大阶段末版 + §14.6 六件套 + 投票 100% GO + **final-assessment Stage 3 切换 GO 裁定**）→ K3 收尾（§3.2 全绿 + 包内自举 + E2E）
- **Stage 2 终态口径**：758 测试（单元 215 + 集成 543）+ 四审计集 190 case + TD 登记册 28 项（开放 P0/P1 = 0）+ lang-design 24 篇（设计栈四层 20/21/22/23）+ sop v12.4 + stage0 v6.5 + 原则 35 条
- **下一步 Stage 3 入场序列**：批次 L（表面现代化——20-表面规范 §7 三批次迁移）→ 批次 M（命名空间——22 §8 实施对账表）→ 移除轮（与 E5 同窗）——23 §2.2 触发表驱动（触发式非时间驱动）

---

## v0.4.0-r36（2026-09-15）——批次 K 次件：K2 大阶段末深审环 + §14.8 设计回写 + §14.9 系统性代码整理（57-a/57-s1/57-s2/57-z/57-web——用户指令「按 sop.md 继续推进 + 同步完整打包 tar.gz 并同步完整更新 web page」，758 维持全绿 + Stage 3 切换 GO 裁定）

### 交付一：K2 大阶段末深审环——§14.5/§14.6/§14.8/§14.9 全协议面（会话 Task 57-a——plan §5c 49-b 批次 K 次件）

- **§14.6.3 三轮深挖**：第 1 轮事实采集（57-s1 子代理十三项代码扫描[C1-C6 + §11 接口隔离 + §14.6.1.1 数据流覆盖] + 57-s2 子代理八设计文档三方对照[§14.6.1.3 + §14.8 偏差候选] + §3.2 基线六命令 clean 起步实测：cargo clean 589 files/166.5MiB → build --release 14.48s 零告警 → check --workspace 0 errors 0 warnings → fmt --check 0 diff → clippy --all-targets --workspace -D warnings 超集 0 → test --release --workspace **758:0:0 零断言修改** + 四审计集 EXIT 0 ×4[41+50+53+46] + CLI 四路径[fib ⇒ 75025 ⇒ 144 exit 0 / macros ⇒ (2 1) ⇒ 42 exit 0 / check ok「2 原型/9 常量/5 全局引用/38 指令」/ check 负例 E0005「+ 需要数值，实际 str」REAL_EXIT 1] + 性能三重采样）→ 第 2 轮发现即修（19 处注释级修复 + 四件设计回写——见交付二/三）→ 第 3 轮收敛（**零新 P0/P1——R6/R7 收敛判据达成**）
- **§14.5 D1-D8 全量三段式深审（大阶段末版——非 r26 批次裁剪版）**：`docs/develop/v0/stage-2/deep-review-round2.md`——八维度各「现状/风险/建议」三段式 + §6.3 五角色投票（ARCH-A 2/DEV-A 1.5/QA-A 1/ALG-C 1/SKL-A 1 不加权）**加权 5.5/5.5 = 100% GO** + §14.8 偏差清单 + §14.9 C1-C6 六维表。结论：P0 = 0 / P1 = 0 / P2 = 0（7 项当场修复）/ P3 = 12（11 修复 + 1 容忍观察）
- **§14.6 六件套深验证文档（全落位——批次 K K2 验收合同「四项审查各 ≥1 产出文档 + P0/P1 = 0 维持」达成）**：`architecture-review.md`（八管道阶段全绿 + §11 七项机械验证零违规 + 数据流五段校验）/ `design-impl-test-coverage.md`（**「枚举-实现-测试」四方互锚零缺项**：46 操作码 opcode_count_matches_spec 逐一断言 / 57 stdlib 逐名核对 / CoreExpr 12 变体三面穷尽 / E0001-E0012 全测试锚 / prelude 五件；B1 净缺口 0 / B3 零新项）/ `hidden-problems-assessment.md`（**强制修复项[复杂度增长 ≥2×] = 0** + Stage 3 就绪度清单 12/12 ✅）/ `refactoring-optimality-review.md`（Stage 2 七项重构 7/7 最优判据零「治症不治根」hack）/ `performance-baseline.md`（新建大阶段末基线：clean 构建 14.48s/二进制 1.92 MiB/fib 92.5ms/gc_tail 42.6ms/gc_nontail 噪声域/全量测试 54.5s + 复测协议）/ `final-assessment.md`（**Stage 3 切换 GO 裁定**——附条件无）+ `pipeline-test-coverage.md` v0.4.0-r36（§4 完整性审查小节 r36 全量重测：catch-all 86 处/24 文件六分类判定全合规[「_ 臂理由」24 + 显式错误臂 ~30 + unreachable 窄化 4 + 空臂注释 5 + None 契约 ~20 + 数值塔语义 ~7]；生产区 expect 23 处全不变式消息化零裸 unwrap；enum 穷尽性四抽查[Op 46 变体 VM 主分派穷尽无 `_`——新变体编译器强制双面更新]；§6 性能基线表更新）
- **TD-028 新登记（P3）**：VM 主分派与 GC 根扫描性能漂移——fib(25) 84.2→92.5ms（+9.9%）/ gc_stress 尾形 38.57→42.6ms（+9.5%）双基准同向漂移三重采样；归因候选三面（r25 效应两操作码 + r30 FFI 三操作码入主分派 match 46 臂分支布局 / GC 六来源入口 / ForeignBox 追踪器入口）待 Stage 3 优化窗口 profile 定锚（判据先于先例——原则 35）；正确性零影响（§14.5.3 D6 条款「非正确性影响的性能记录为 Stage N+2 优化项」）

### 交付二：§14.8 设计回写四件（实现 → 设计单向——代码超前文档的滞后清零）

- **03-macro-system.md v6.2 → v6.3**：深度上限 500 → **10_000** 全口径对齐（TD-007 r18 全解除——Stx Rc 化 + retag 迭代式重建 + 均匀标记 O(1) 共享；§2.2 契约块 + §4 不变式 1 + §5 测试锚行 + 头部版本行；expander.rs:77 / expander.krf:478 / tco_tests「超限 10000」断言三实锚）+ 推迟项清「迭代式工作表展开（TD-007）」（已 resolved）
- **05-runtime.md v6.2 → v6.3**：根集**五来源 → 六来源**（第 6 源 = 活跃 continuation 帧链——r25/M5；vm.rs:1368 实锚 + effect_tests gc_continuation_boxed；§2/§3.2/§4 三节六处——修复 06 §1.2 指针落空）+ 类型化分配**八入口 → 九入口**（alloc_foreign r30 FFI ForeignBox 装箱第 9 入口——heap.rs:202 实锚）+ 推迟项口径对齐（TD-008 DEFER Stage 3+ / net/process Stage 3 触发式）
- **02-syntax-model.md v6.0 → v6.1**：Keyword **22 → 25 变体**（r25 增 perform/handle/resume 效应三关键字——symbol.rs:24-54 实锚）+ 叶级**45 → 48 种** + **§8.1 两语法同核验证改判**（B1-1：原定 Stage 2 前置未执行——重规划至表面现代化批次 L/M[20 §5 模块树 + 12 §2.10] 承载，目标语法引入随 v0.5/v0.6 窗口，同核验证作为该批次验收件）
- **13-capability-matrix.md v6.2 → v6.3**：**§3.1.1 Effect Handlers 节态由 r8 口径升 r25/r28 终态**（语言面 P0：M1-M5 全量[原语集 9→11 + ext1 具体化 Option<Rc<HandlerFrame>> + continuation 四要素 + E0007-E0009 + GC 第六来源] + 静态收敛面[typecheck/hm 双面检出超集]；行多态/效应行 Stage 3——修复主链 01/04/06/12 已回写而本节残留的「节态滞后」）+ 12-roadmap 宏系统行「深度 500」同步（跟随 03 v6.3 单源）

### 交付三：§14.9 系统性代码整理（19 处注释级修复——零行为变更，758:0:0 复验实证）

- **P2 注释时效 7 项全修**（设计口径已改判未同步的「代码注释滞后」）：runtime/lib.rs TD-008 DEFER Stage 3+ / core/ir.rs TD-003 优化窗口 / expander core_forms.rs:444 + bootstrap expander.krf:1373 net-process Stage 3 触发式（**用户面错误消息双侧同步**——capability_tests:201 断言锚「未知能力主体」前缀不受影响，parity 保持） / reserved/multistage.rs 多阶段 DEFER Stage 3（头部 + trait 注释 + 三方法注释）/ expander/lib.rs:32 深度 128→10_000 / driver/effects.rs:24-25 ext1 已激活（r25 M5 HandlerFrame）+ resumption 语义分域（内部层一次性逃逸 vs 语言级 continuation 四要素）/ effects.rs:19 K2 深审复核结论注记
- **P3 12 项修复 11**：catch-all 无臂注释 5 处补齐（backend/anf.rs:195 prim_arity 默认二元 / compiler/hm.rs:688 扫描窗口终止 / compiler/typecheck.rs:420 防御回退 / expander/macro_sys.rs:191 构造性默认 / vm/vm.rs:1591 NaN partial_cmp 保底）+ 注释枚举不全 2 处（vm.rs:1392 + Symbol / runtime/heap.rs:349 + Symbol）+ 文件头时效 4 处（vm/lib.rs 值模型清单补 Symbol/continuation/Foreign/External / compiler/lib.rs 操作码 39→46 / driver/lib.rs eval 退役 VM 唯一生产路径 / expander/lib.rs TD-004 r13 已解决时态）+ 1 容忍观察（backend qbe.rs gen_il 业界惯用缩写）
- **需复核 3 项处置落位**：capability.rs:65 net 窗口终判注记（plan §5d 触发式口径） / effects.rs:19「Stage 2 复核」= 本轮 K2 承办完成 / expr.rs:92-94 ADT 评估清单冻结维持注记（K1+K2 双复核）
- **修复后复验**：build 12.18s / fmt 0 diff / clippy 超集 0 / **test 758:0:0 零断言修改**——零行为变更实证（§14.9 完成标准 7 项全过：TODO/FIXME/HACK/XXX = 0 / glob re-export = 0 / fmt 0 / clippy 0 / test 全绿 / 无死代码 / 整理报告落位 worklog）

### 交付四：对账四面 + 收尾（57-z/57-web 随同执行）

- 对账四面：matrix.md **v0.1.0-r36**（r36 增量行 + **总量行同步债修正**：门审计集「三件 144」→「四件 190」[r35 遗留的总量行未同步——本轮同步债清理先例延续]）/ pipeline-test-coverage.md **v0.4.0-r36**（§4 r36 全量重测 + §6 性能基线）+ performance-baseline 新建 / RELEASE_NOTES r36 节（本节）/ plan.md K2 执行注记（下一步 K3 收尾交付——K2 GO 已满足输入条件）
- TD 登记册：TD-028 新增（28 项总量：**P0/P1 = 0 维持**——解决 17 + 断档 4 + DEFER 1 + 开放 6）
- r36 tar.gz（§19.3 commit-then-package 正序 + §19.4 十二路径）包内自举 + web 同步（kerf-data r36 节点 + download README r36 节 + footer）+ rec 树 20_r36/l + git 双仓库

## v0.4.0-r35（2026-09-15）——批次 K 首件：K1 终门审 + lang-design→stage0/sop 附录级全面同步（56-a/56-b/56-z/56-web——用户三指令驱动，758 维持全绿 + 第四审计集 46 case APPROVED）

### 交付一：lang-design → stage0.md 附录级全面同步 + sop.md 反哺（会话 Task 56-a——用户指令「将更新的 docs/lang-design/ 下所有内容同步到 docs/stage0.md 中，并反哺 docs/sop.md」）

- **同步缺口实测（磁盘对账）**：①附录 A 术语表缺 r32-r34 三轮 33 条（18 §5a 七条 + §5b 十三条 + §5c 十三条）②附录 E 参考文献缺 14 条（19 §7 r33 八查询 + §8 r34 四查询）③§23.1 标题计数漂移（「三十二条」vs 正文 35 条——内容自 v6.4 已同步，标题停在 v6.1 时代）——判定为「拆分面→存档面的附录级同步债」（r32-r34 各轮只做了 §9.x 存档侧镜像 + 原则增量，附录面无 owner）
- **stage0.md v6.4 → v6.5**：附录 A 增补 33 条设计栈术语（is- 前缀谓词/方向词转换/命名空间限定名/别名层/能力-命名空间对齐/表面债/表面现代化动态演进 + 三义定锚/能力四要素/L0-L3/J1-J4/授权三态/六类迁移/新原语两判据/N0-N4/R-N1/R-N2/import 不传播授权/kerf 保留域/原则 34 + 三轴坐标系/双轴归属/授权组合闭包/编译期权威三判据/诊断终止域/横切泛函域/演进六窗/时间治理四红线/变更通道矩阵/受控债务四步/生命周期四阶段/十二审计轴/判据先于先例）+ 附录 E 新增 E.9 节（66-79 十四条知识搜索引用）+ §23.1 标题计数修正 + 三处指针注记（§7 三义消歧 / §9.3.2 LSP×命名空间三交互点 / §21.5 时机治理单源）+ 版本历史 v6.5 条目
- **sop.md v12.3 → v12.4（反哺）**：§8.4.3 语言设计文档目录树由「00-13 + …（13+ 扩展设计文档）」修正为 24 文件全列（设计栈四件 20/21/22/23 显式列出——r32-r34 三轮交付后的目录树漂移）+ §8.4.5 文档优先查询表增 4 行设计栈落点（库表面命名→20 / 能力归属与授权→21 / 命名空间与模块机制→22 / 演进时机与窗口触发→23）+ §16.1 版本历史 v12.4 + **存档纪律吸收**（附录级内容[术语表/参考文献/原则计数]属「同步债」——自本轮起纳入 §8.5 审查检查项）

### 交付二：K1 终门审——stage2_gate_audit_r2 46 case APPROVED（会话 Task 56-b——plan §5c 批次 K 首件）

- **新审计集第 4 件 `examples/audit/stage2_gate_audit_r2.rs`**（Cargo.toml [[example]] 登记 + §7.3.1 可重运行口径）：**46 case 全 PASS EXIT 0 APPROVED**——与 r1（53 case）零源语料重叠，主轴 = **静态判定面**（r29 HM 旗标期切换后 check_source 生产判定面 E0005——r1 零覆盖的半区：A 桶 10 单语句静态 + B 桶 10 多语句/集成静态含 r28 效应臂收敛三 case + E0006 门控函数体位变体 + 空列表 define 值位变体 + 多错误非短路收集）
- **批次 J 修复边界（§7.3.2 三修复面 7 case）**：r28 效应 typecheck 收敛双 case（perform 效果值双面检出[tc+hm 超集纪律] + handle 双体多错误收集）+ r29 HM 旗标双缺口修复双 case（TD-011 字符串全序零误报/混串检出对偶 + car/cdr Nil 漏检归零）+ E0005 定位面（文件名 + 行:列 + Span）+ r30 FFI 双 case（编译面收窄[非字面量实参 CompileError] + VM 三码族[E0010 双重释放/E0011 非令牌释放/E0012 未登记符号 fail-closed]）
- **§21.3 四条件终验（P 桶）**：条件 1 = P06 生产链自编译 compiler.krf + 活性终验（sq(7)=49 与种子一致）；条件 2 = P03 门 B fixpoint（B₁/B₂ bytecode_equal + SHA-256 两件）；条件 3 = P04 QBE 本地码 fib(12) exit 144 端到端；条件 4 = **P05 FFI 真端到端**（write_stdout 经冻结 FfiCall → lowering → 操作码 → 窗口规程 → 宿主真实 I/O → Int(4)——r30 VM 面做实后，较 r1 的「模型冻结断言」升级为运行时实证）
- **§21.5 九信号全核对（P07）**：S1 语义稳定（金路径进程内实测）/ S2 自举验证（P03 证据引用）/ S3 测试覆盖（matrix 758:0:0 v0.1.0-r34 锚）/ S4 性能基线（CLI bench 锚）/ S5 文档同步（lang-design 24 文件实测 + stage0 v6.5）/ S6 能力处理程度（12 §2.5.1 终态注记锚）/ S7 技术债 P0/P1 清零（登记册机械扫描开放项 = 0）/ S8 外循环投票（协议承载——本审计集为证据输入）/ S9 阶段间深验证（K2 承载——如实登记）
- **§6.3 五角色投票**：ARCH-A 2 票 GO + DEV-A 1.5 票 GO + QA-A 1 票 GO + ALG-C 1 票 GO + SKL-A 1 票 GO（不参与加权）——**加权 5.5/5.5 = 100% ≥ 95% GO**（K1 验收合同达成；批次 K 输入条件进入 K2）

### 交付三：GATE 1 §3.2 六命令 clean 起步实测全绿

- cargo clean（589 files 166.5MiB）/ build --release 13.11s 零告警 / check --workspace 0 errors 0 warnings / fmt --check 0 diff / clippy --all-targets --workspace 超集 0 / **test --release --workspace 758:0:0（22 套件零断言修改——代码增量 = 审计器单件，零生产代码变更）** + **四审计集 EXIT 0 ×4**（stage0 41 + stage1 50 + stage2_r1 53 + stage2_r2 46）+ CLI 四路径（run fib ⇒ 75025 ⇒ 144 / run macros ⇒ (2 1) ⇒ 42 / check ok「2 原型/9 常量/5 全局引用/38 指令」/ check 负例 E0005「+ 需要数值，实际 str」REAL_EXIT 1）

## v0.4.0-r34（2026-09-14）——批间插入轮第三弹：设计缺陷深度审计收敛轮（55-a/55-z/55-web——用户审查指令驱动，设计栈治理层补齐 + 原则 35，758 维持全绿）

### 交付一：演进治理与设计收敛（会话 Task 55-a——「定位/权限/能力边界/职责边界/层级处理和管理模型/演进阶段和时机——网状发散、内循环直至收敛」）

- **驱动源**：用户对 r33 产物的第三轮质量反馈（「检索当前 docs/lang-design/ 下存在哪些语言设计上的缺陷面，定位是否具体和清晰，权限是否具体和清晰，能力的边界与具体是否具体和清晰，职责的边界与具体是否完善和清晰，层级处理和管理模型是否具体和清晰，演进阶段和时机是否具体和清晰等等——沿着思路向下继续思考确保思维深度，并网状发散性思维确保思维广度」「这是一个内循环迭代的过程，直至你确保所有可能性的收敛」+「kerf 不是 lisp 系列也不是 c/rust 系列——kerf 并不会限制你什么，限制的是差的设计、规划、理念等内容」）+ 知识搜索四查询实证（tool-results/r34-search/：WASI 无环境权威与组件组合 / Rust proc-macro 编译期任意执行安全缺口与 2026 沙箱化收敛 / Swift resilience 库演进治理 / ocap 组合布线）
- **新设计文件 `docs/lang-design/23-evolution-governance.md` v1.0（治理层——设计栈第四层：20 名字与行为 / 21 能力与职责 / 22 命名机制 / 23 演进治理）**：**十二审计轴系**（用户六轴 + 发散六轴：组合语义/覆盖完备性/一致性/诊断对账/判据先于先例/元编程工具链交互）+ **第一轮 14 项发现全表**（F1-F14 全落位）+ **演进六窗触发表**（K/L/M/E5/T3+——每窗入口信号全满足才开窗 + 出口条件 + 时间治理四红线：禁止时间驱动切换/处理程度倒挂/无信号开窗/窗口合并）+ **变更通道矩阵**（每类变更对象唯一通道 + 前置判据）+ **准入判据总表**（新原语/新域/新模块/新内置/新效应/新授权/新码位/新值型八类 checklist）+ **受控债务四步仲裁**（登记→等价证明→清偿窗口→深审复核——D5 set! 先例流程化）+ **生命周期四阶段**（引入→默认→弃用→移除——引入与移除永不同窗同面）+ **非锚定设计哲学**（判据先于先例的操作化）+ **第二轮复审收敛证明**（0 新 P0/P1 + 残余 7 项全持接口契约）
- **21-能力架构升 v1.1**：§2.5 **三轴坐标系**（语义 L0-L3 × 命名 N0-N4 × 相位 P0/P1——「L3′」记号退役 + L×N 交互矩阵交格 owner 单源表 + `=` 双轴归属）+ §3.1 **十一域覆盖闭合**（补算术运算符域[N1 永驻]/诊断终止域[error/assert-eq——终止 ≠ 可拦截裁定]/横切泛函域[prelude 五件]三卡——57 注册名 + prelude 五件每名有家）+ §4.4 **授权组合规则**（require 传递闭包：模块需求 = 元数据非授权获得，入口程序声明并集 + 编译期核对——WASI「无环境权威」同构）+ §4.5 **编译期权威边界**（Phase 1 零授权面 + 编译期权威三判据[确定性/零外部 I/O 或编译期令牌/展开可终止]——Rust proc-macro 反面教材 + 2026 沙箱化方向双实证）
- **22-命名空间设计升 v1.1**：§4.2 相位授权面注记（Phase 1 零授权接线）+ §5.1 权限矩阵增两行（模块授权需求声明[组合闭包] + Phase 1 宏命名宇宙）+ §8 实施对账增两行
- **原则 35「判据先于先例」三方同步**：先例是佐证不是权威；向后锚定（停 1970）与向前锚定（抄某家族）等价失败形态；引证纪律 = 先判据后先例 + 跨家族取样（≥3 范式家族）+ 否决记录保留（17 v6.5 / sop §2.2 v12.3 + 版本历史 / stage0 §23.1 v6.4 + §9.8 镜像）
- **同步轮 9 文件**：00 v6.5（文档地图 23→24 + 计数漂移修正 F7）/ 09 v6.6（十一域口径）/ 10 v6.4（LSP×命名空间三交互点注记 F10——补全/重命名/格式化）/ 12 v6.8（时机治理单源化注记）/ 18 v6.4（§5c +13 术语 + **§6 批次 M 码位预登记 E0013-E0019**[F9]）/ 19 v6.3（§8 +6 引用）/ 20 v1.2（四层设计栈 + §11 +5 维）/ 13 维持（无增量）/ sop v12.3 / stage0 v6.4
- **GATE 1 §3.2 六命令 clean 起步实测全绿**：cargo clean（600 files 175.4MiB）/ build --release 13.63s 零告警 / check 0/0 / fmt 0 diff / clippy 超集 0 / **test 758:0:0（22 套件零断言修改）** + 三审计集 EXIT 0 ×3 + CLI 四路径（run fib ⇒ 144 / run macros ⇒ 42 / check ok「2 原型/9 常量/5 全局引用/38 指令」/ check 负例 E0005「+ 需要数值，实际 str」EXIT 1）——**零代码变更轮**（设计文档 + tool-results 面唯一增量）

### 交付二：55-z 收尾（对账四面 + r34 tar.gz 包内自举 + web E2E + git 双仓库 + rec 树 18_r34/l + worklog 双源）

- r34 tar.gz（§19.3 commit-then-package 正序）+ 包内自举验证（全新解包构建 + 758 复跑 + CLI 一致 + 包内三审计集）+ web 面（kerf-data r34 节点 + download README r34 节 + E2E）——详录见 root worklog 55-z/55-web 条目

---

## v0.4.0-r33（2026-09-13）——批间插入轮第二弹：能力架构深度设计轮（54-a/54-z/54-web——用户审查指令驱动，lang-design 三层设计栈补齐 + 原则 34，758 维持全绿）

### 交付一：能力架构与命名空间深度设计双文件（会话 Task 54-a——「能力定位/边界/职责/正交 + 命名空间层级/权限控制 + 原语级 ≠ 重命名」）

- **驱动源**：用户对 r32 产物的质量反馈（「整体是否需要清晰的能力定位，能力边界，能力职责，能力正交，是否完整设计规划的命名空间，层级关系，权限控制……对原语级别的内容不是简单的重命名（之前存在相关讨论并已经在计划中推进重构设计）……不止是内置和命名方面」+「kerf 不是 lisp 系列也不是 c/rust 系列——限制的是差的设计、规划、理念」）+ 知识搜索八查询实证（tool-results/r33-search/：ocap 模型 / Pony-Austral 能力安全语言 / 效应组合性 / 模块≠命名空间 / 可见性谱系 / Clojure 命名空间组织 / 库核心-Stdlib 分层 / 最小 kernel 传统）
- **新设计文件 `docs/lang-design/21-capability-architecture.md` v1.0（能力架构——三层设计栈的「能力与职责层」）**：「能力」三义定锚（工程能力/语言能力/授权——r32 前三义混用即缺位证据）+ **语言能力四层 L0-L3 四要素卡**（值域/控制/效应/授权——每层定位/边界/职责/正交）+ **正交判据 J1-J4 各配既有实测锚**（r24 装箱值零控制层改动 = J1 / r25 原语集 9→11 零断言修改 = J2 / r8 门控授权零语义载荷 = J3 / D10 效应-授权正交 = J4——「正交是已验证的测试属性非口号」）+ 八库能力域四要素 + 域正交单向依赖三规则（D1 单向 / D2 零双向 / **D3 副作用汇聚**——「门控表 = I/O 域全集」的架构根据）+ **授权三态**（纯度态静态纪律 / 声明态程序头审查 / 令牌态逐值持有——粒度递进收紧）+ fail-closed 三红线（缺省拒绝 / 授权零语义载荷 / **import 不传播授权**）+ 对齐不变量 A 精确化（修正 20 §5.3「同一语义」过强表述——「边界对齐 + 机制分工两门」）+ **原语四要素卡 11 张 + 六类迁移分类学 M-R/D/I/L/E/A**（重命名/脱糖/索引化/层级迁移/效应化/新增——「重命名只是最浅一类」，E1-E5 既有裁定载荷的结构重构归档）+ 新原语准入两判据（不可归约性 + 单层归属）+ 2026 前沿对照（Pony 变量级 cap 不引入裁定——原则 26 成熟度匹配）
- **新设计文件 `docs/lang-design/22-namespace-design.md` v1.0（命名机制——三层设计栈的「命名机制层」）**：**五层命名层级 N0-N4**（符号宇宙/全局注册/模块/局部绑定/保留字——存在性与可见性分离）+ 解析优先序 R-N1（非限定：N3 内向外 → N2 注入 → N1 全局；限定：仅查 export 面**不回落**）+ 遮蔽许可表 R-N2（六行三分界——合法/警告/错误）+ 限定名词法域 R-N4 + 导入/别名规则 R-N5（别名 = N3 局部绑定）+ prelude 规则化 R-N6（无特权模块）+ 运算符族 N1 永驻 R-N7 + 符号宇宙豁免 R-N8 + **模块×授权权限矩阵**（11 行完整对账——v0.6 批次 M 实施单源表）+ 授权传播三红线命名面 + 冲突三类裁定 + `kerf/` 保留域 + 版本化接口位锁定 + 宏卫生/相位交互（E3 裁定机制面）+ 批次 M 实施对账表 12 行——**v0.6 命名空间层实施输入由此齐备**（此前 20 §5 仅方向概要，属「可推迟决策未配接口契约」违例）
- **20-表面规范升 v1.1**：§1.2 失实叙述修正（「内部已现代」→「方向已冻结、实施有窗口」——原语级迁移是 Stage 3 结构重构非已完成改名）+ §5 分工接线（本文件持方向概要与模块树，22 持机制规范——批次 M 输入以 22 为准）+ §5.3 对齐精确化 + §11 完整性核查 13→18 维（+5：能力四要素/原语分类学/命名机制/授权架构/术语消歧）
- **原则 34「能力正交与授权分层」三方同步**：17-principles v6.4 / sop.md §2.2 v12.2（+ 版本历史 v12.2 行）/ stage0.md §23.1 v6.3（+ stage0 §9.7 存档侧镜像）——正交判据思维吸收进 sop（「正交不是口号是已验证的测试属性——每条正交声明必须配实测锚」：层归属/正交声明/授权变更三类决策先过 J 判据）
- **lang-design 同步轮**：00 v6.4（文档地图 21→23 文件）/ 09 v6.5（§4 扩展指针）/ 12 v6.7（§2.10 批次 M 机制设计输入注记）/ 18 v6.3（§5b 增 14 术语 + §5a 对齐术语精确化）/ 19 v6.2（§7 增 8 条引用——知识搜索参考文献 66-73）/ 13 v6.2（「能力」三义消歧指针）
- **项目级清扫**（用户指令末条「全部更新后对项目系统性扫描」）：01 §8 无同类失实表述（复核通过）/ 代码注释零混用（复核通过）/ builtins.rs 头注 + 21/22 指针（唯一代码面变更——注释级零语义）

### 交付二：54-z 收尾（r33）

- §3.2 六命令全绿（758:0:0 维持——零断言修改；唯一代码变更 = builtins.rs 注释指针）+ 三审计集 EXIT 0 ×3（stage0 41 + stage1 50 + stage2 53）+ CLI 四路径（run fib ⇒ 75025 ⇒ 144 / run macros ⇒ (2 1) ⇒ 42 / check ok / check 负例 E0005「+ 需要数值，实际 str」EXIT 1）+ r33 tar.gz 包内自举验证 + web 同步 + rec 树 17_r33/l 两层 + git 双仓库

### 质量口径

- §3.2 全绿（本轮实跑）：build --release 5.35s 零告警 / check 0 errors 0 warnings / fmt --check 0 diff / clippy --all-targets --workspace 0 / **test --release --workspace 758:0:0**（22 套件全 ok——单元 215 + 集成 543）
- 三审计集 EXIT 0 ×3（144 case）+ CLI 四路径；TD 登记册零新增（TD-027 实施面不受影响——批次 L/M 输入经本轮升级）

### 下一步（批次 K 终批，plan §5c——零接触维持）

K1 终门审（stage2_gate_audit_r2 ≥30 新 case + 批次 J 修复边界 §7.3.2 + §21.3 四条件终验 + §21.5 九信号全核对 + §6.3 投票）→ K2 大阶段末深审环（§14.5 D1-D8 全量 + §14.8 B1-B4 + §14.9 + §14.6 阶段间四项 + final-assessment + Stage 3 切换 GO/NO-GO）→ K3 收尾（12 §2.5.1 终态回写 + v0.5-roadmap（批次 L 经 12 §2.10 预锚 + **本轮 22 §8 实施对账表升级**）+ tar.gz + web）。

---

## v0.4.0-r32（2026-09-12）——批间插入轮：表面现代化设计轮（53-a/53-z——用户审查指令驱动，lang-design 2026 现代化 + 原则 33 + TD-027，758 维持全绿）

### 交付一：库表面现代化设计规范（会话 Task 53-a——「实现端不要停留在 Lisp 家族 1970 年代表达」）

- **审查实测**（全项目扫描）：57 注册内置名中 18 件 `?` 谓词 + 3 件 `->` 转换 + `car`/`cdr` 历史访问器 + 扁平 `str-` 前缀 ×15 + 行为模式遗留（-1 哨兵 / 真值多态 / 元数缺口）；引导语料自铸 41 个 `?` 名 + 9 个 `->` 名；**此前无现代化 owner / 无映射表 / 无 TD 登记**（「未认领半区」——内部 ADT 已由原则 29-31 治理，库表面悬空）
- **新设计文件 `docs/lang-design/20-surface-conventions.md` v1.0**：R1-R6 六规则（全词 / `is-` 谓词前缀 / 动词关系裸形 / `to`/`from` 方向词 / 库面零 `!` 新铸 / 运算符族冻结）+ B1-B5 行为契约（`index-of` miss→nil / `member` 真值多态单一化 / `read-line` 严格元数 / 恒等元与 `eq` 语义**显式裁定保留**）+ 命名空间层（`/` 限定名 + `kerf/<模块>` 模块树七件 + **能力-命名空间对齐**：`kerf/io` ↔ `(require io …)`）+ **57 项完整映射表**（27 新别名 / 24 不变 / 4 引导私有跳过）+ 零破坏三批次迁移（v0.5 批次 L 别名层——别名层零语义变更不变量 / v0.6 批次 M 命名空间层 / Stage 3 移除轮——与 E5 关键字切换同窗）；§6 与既有裁定协调（核心冻结不受影响 / E5 适用域划分 / HM-BUILTIN_SIGS-门控三方同步契约）
- **原则 33「表面现代化动态演进」三方同步**：17-principles v6.3 / sop.md §2.2 v12.1 / stage0.md §23.1 v6.2（+ stage0 §9.6 存档侧镜像）——标点后缀约定 = 前类型系统时代补偿机制；动态演进思维模式吸收进 sop（每个引入新表面的设计时点先对照当期前沿）
- **lang-design 同步轮**：00 v6.3（文档地图 21 文件）/ 09 v6.4（§4 命名规范层指针 + 新语料现代名纪律）/ 12 v6.6（§2.10 迁移登记 + v0.5-roadmap 预锚）/ 18 v6.2（§5a 七术语）/ 02 注记（Reader 原语四件现代化方向）
- **TD-027 登记（P2）**：库表面命名现代化——设计 owner = 20-表面规范 / 实施 owner = TD-027（批次 L）；顺带实测对账修复：builtins.rs 头注 3→4 Reader 原语 + hm-inference-design 49→56 项
- **知识搜索前沿对照实证**（§2）：Swift API 设计指南（clarity at point of use / is 前缀 / 避免缩写）/ Rust `is_`/`to_`/`from_`/`into_` 方向语义学 / Kotlin `isX` / Clojure 命名空间标准库（Lisp 家族内部的现代答案）/ 2026 新语言代际（Mojo 开源 2026-08）——「Lisp 家族 `?` 后缀 vs 2026 跨范式 `is` 前缀共识」的跨语言判定

### 交付二：53-z 收尾（r32）

- §3.2 六命令 clean 起步全绿（758:0:0 维持——单元 215 + 集成 543，零断言修改；唯一代码变更 = builtins.rs 注释）+ 三审计集 EXIT 0 ×3（stage0 41 + stage1 50 + stage2 53）+ CLI 四路径（run fib ⇒ 144 / run macros ⇒ 42 / check ok / check 负例 E0005 检出 EXIT 1）+ r32 tar.gz 包内自举验证 + web 同步 + rec 树 16_r32/l 两层 + git 双仓库

### 质量口径

- §3.2 全绿（本轮实跑）：cargo clean（633 files 208.7MiB）/ build --release 零告警 / check 0 errors 0 warnings / fmt --check 0 diff / clippy --all-targets --workspace -D warnings 0 / **test --release --workspace 758:0:0**（单元 215 + 集成 543）
- 三审计集 EXIT 0 ×3（144 case）+ CLI 四路径；TD 登记册：TD-027 新增（P2——设计已冻结，实施批次 L）

### 下一步（批次 K 终批，plan §5c）

K1 终门审（stage2_gate_audit_r2 ≥30 新 case + 批次 J 修复边界 §7.3.2 + §21.3 四条件终验 + §21.5 九信号全核对 + §6.3 投票）→ K2 大阶段末深审环（§14.5 D1-D8 全量 + §14.8 B1-B4 + §14.9 + §14.6 阶段间四项 + final-assessment + Stage 3 切换 GO/NO-GO）→ K3 收尾（12 §2.5.1 终态回写 + v0.5-roadmap（含 12 §2.10 表面现代化批次 L 预锚）+ tar.gz + web）。

---

## v0.4.0-r31（2026-09-12）——批次 J 收口：J4 批次 J 收尾（48-e——§3.2 复验 + 12 §2.5.1 终态复核 + 对账 + r31 包，758 维持全绿）

### 交付一：48-e J4 批次 J 收尾（会话 Task 52-a——plan §5b 末 MUV，零代码收尾轮）

- **§3.2 六命令 clean 起步全量复验全绿**：cargo clean（350 files 156.2MiB）/ build --release **13.81s 零告警** / check 0 errors 0 warnings / fmt --check 0 diff / clippy --all-targets --workspace（超集口径）0 警告 / **test --release --workspace 758:0:0 维持**（单元 215 + 集成 543——零断言修改零语义变更）+ 三审计集 EXIT 0 ×3（stage0 41 + stage1 50 + stage2 53 = 144 case）+ CLI 四路径（run fib ⇒ 144 / run macros ⇒ (2 1) ⇒ 42 / check fib ok / check 负例 E0005「类型不一致：num 与 str」定位 1:24 EXIT 1——HM 判定面维持）
- **12-roadmap §2.5.1 行注记终态复核 ✅（plan §5b 排程注 4 兑现——v6.5）**：十一行批次 J 终态对账——三处更新（①Effect Handlers 行 48-b 静态收敛面 ✅ 兑现注记（r28/49-a：Perform 效应值 + Handle 两体入 R1-R8/HM 双检出域子表达式遍历，6 违例 case 双面检出 + 零误报对照——深审 D3/D8 覆盖缺口闭环）②字节码 VM+GC 行 FFI 所有权 GC 边界注记（r30/51-a——Heap Φ 计数簿 supp(Φ) 根集第五来源计数化 + ForeignBox 装箱/线性令牌不参与 GC 可达性；§21.3 条件 4 兑现）③类型检查器行批次 J 兑现位终态（默认期（R1-R8 内化）评估移交批次 K 终门审承载——§21.5 九信号全核对））；其余八行 r27 §5d 处置表已终态无需复改
- **rec 树补账（r30 会话遗留缺口——REC-A 纪律）**：14_r30 补建（r30 FFI VM 面做实 1:8 压缩条目）+ 15_r31 新建 + l 两层更新（树导航行 02 扩展至 r31 + 未压实区间刷新至 r31 终态 + flat 51-z 补录）
- **对账四面**：matrix r31 行（758 零增量维持，v0.1.0-r31）/ pipeline-test-coverage v0.4.0-r31（Tier 2 头 543 零增量维持）/ plan §5b J 执行注记 r31 + Status 行（批次 J 全收口）/ RELEASE_NOTES 本节；TD 登记册零事件

### 交付二：52-z 收尾（r31）

- r31 tar.gz（§19.3 commit-then-package 正序）+ 包内自举验证（全新解包构建 + 758 复跑 + CLI 一致 + 包内三审计集）+ web 同步（kerf-data r31 三节点 + footer v7.1 + download README r31 节）+ root worklog 索引 + git 双仓库

### 质量口径

- cargo test --release --workspace：**758:0:0 维持**（批次 J 终态基线——门审计集三件 144 case 另计全过）
- cargo clippy --all-targets --workspace：0 警告（超集口径）；cargo fmt --check：0 diff
- 环境口径：RUST_MIN_STACK=16777216（r29 既有环境级修复维持——深嵌套 case 线程栈）

---

## v0.4.0-r30（2026-09-12）——批次 J 执行：J3 FFI VM 面做实（窗口规程 Φ 簿 + 线性令牌 + E0010-E0012 + 13 边界 case，758 全绿）

### 交付一：48-d J3 FFI VM 面做实（会话 Task 51-a——plan §5b 第三 MUV，§21.3 条件 4 兑现）

- **操作码三指令 43→46**（CALL_EXTERNAL symbol, n_args / ALLOC_EXTERNAL size / FREE_EXTERNAL——04-bytecode-vm §1 第十组 + compiler.krf OP-* 常量表 + bootstrap_compiler.rs 桥三臂，三方冻结同步；**语言面形式 Stage 3，编译臂不发射**——IR/VM 面做实即验收条件 4 兑现，plan §5b 批次 J 排程注 3 如实注记）
- **窗口规程（ffi-ownership-model §2.1 步 2-4，边界包装层执行）**：装载边界（char* 实参装箱堆槽 pin `Φ[v]+=1` + 令牌实参校验 Invalid→E0010）→ 宿主调用（VM 挂起——§6 case 6 时序：外部 malloc 零 kerf 分配计数）→ **unpin 配平先于返回包装**（不依赖实参堆对象）；char* marshalling = Str 值装箱堆槽（GC 追踪形态）+ 数据指针借用出界（窗口借用——F-PIN 存活保证）
- **Heap Φ 计数簿**（kerf-runtime——`register_foreign_ref` 的计数化泛化）：`pin_object`（P1 可重复累计）/ `unpin_object`（U1 归零摘根；U2 下溢 Err——E8 口径）/ `pin_count`/`pinned_refs`（可观测性）；supp(Φ) 并入 mark 起点（F-PIN 引理——根集第五来源计数化，完备性不变式维持）；持久根与窗口计数根并存
- **线性令牌状态机（§5）**：`Value::External(Rc<ExternalToken>)`（CPointer/Opaque + Cell 状态——**消费全局生效**：一处 FreeExternal 后所有共享绑定同步失效）；装箱 `HeapObj::Foreign` 载荷（追踪器 no-op——不参与 GC 可达性，§7）；NULL 哨兵（Valid 空令牌——free = 合法 no-op，case 13）；外部域纪律 = Rust 宿主堆 Box<[u8]>（真 C ABI = QBE AOT 路径）
- **E0010-E0012 诊断族落位**（18 §6 码位登记 r18 预留兑现——E9 FfiTokenInvalid/E10 FfiOwnershipViolation/E11 FfiSymbolResolution）：messages.rs 单源三构造器（TD-018 纪律）+ VM 携码经 driver from_vm 映射；E0012 = 符号解析 fail-closed（QBE AOT 链接期解析在 VM 路径的调用期对应物）；空表默认入口（run_program）E0012
- **§21.3 条件 4 冻结形状消费面**：FfiBoundary 真实实现（driver ffi.rs HeapFfiBoundary——P1/P2/U1 经 Φ 簿；冻结签名 U2 经 expect E8 口径承载）+ compile_ffi_call_program（FfiCall → 操作码序——字面量实参子集 + AllocExternal size=0 编译期拒绝 + FreeExternal 运行时令牌依赖拒绝——诚实收窄）+ default_extern_table（write_stdout char* 注册——ExternalType 形状消费：CInt(Usize)/CPointer(Char)；CStruct/CFunction 子集外注册拒绝）+ run_program_with_externs（extern 注册执行入口）
- **正例端到端**：冻结 FfiCall → lowering → 操作码 → 窗口规程 → kerf_runtime 真实 I/O（CInt 返回 = 写入字节数）
- **ffi_vm_tests 37 case**：13 边界 case 全判定落地（覆盖映射表——case 1 F-PIN/case 2 绑定变更/case 3 CFunction 拒绝/case 4 双面拒绝/case 5 E0010/case 6 外部零分配/case 7 Opaque/case 8 浅 pin 等价/case 9 三容忍观测（错误路径泄漏 + panic unwind + 槽回收）/case 10 单线程注记/case 11 共享失效/case 12 非令牌/case 13 NULL no-op）+ 正负比 7:22（功能点粒度 ≥1:3，§9.4.3）+ Φ/P-U 机制组 6 件 + E0010/E0011/E0012 码断言
- TD-026 登记（P3）：FFI 语言面形式 + 编组消费子集收窄（CStruct 递归编组/CFunction 回调/FreeExternal lowering——显式拒绝非静默；Stage 3 锚）

### 交付二：51-z 收尾（r30）

- §3.2 六命令全绿 + 对账六面（06 §3 E0-E11 + 05 §3.1 Φ 簿/Foreign 令牌注记/根集五来源 supp(Φ) + 13 §3.3.4 实现锚（§21.3 条件 4 ✅）+ 04 §1 十组 46 + 18 §6 落位 + TD 登记册 TD-026 + plan §5b J 执行注记 r30）+ r30 tar.gz + 包内自举验证 + web 同步 + E2E

### 质量口径

- cargo test --release --workspace：**758:0:0**（713 零回归 + 净 45 = ffi_vm_tests 37 集成 + driver ffi 单元 8；门审计集三件 144 case 另计全过）
- cargo clippy --all-targets --workspace：**0 警告**（超集口径）
- cargo fmt --check：0 diff

---

## v0.4.0-r29（2026-09-11）——批次 J 执行：J2 HM 旗标期切换（`kerf check` 判定面 = HM 推断 + 契约重定义 + 双缺口修复，713 全绿）

### 交付一：48-c J2 HM 旗标期切换（会话 Task 50-a——plan §5b 第二 MUV，D8 阶段 2）

- **判定面切换**：driver.rs `check_source` / `check_source_recover` 两入口判定面 = `hm_check_program`（hm.rs 约束三段式——生成/求解/收集；D8 演进轨道阶段 2；**run 路径不触静态面，爆炸半径有界维持**）；R1-R8（typecheck.rs `check_program`）**退为回归基线断言**（测试面超集门参照侧——hm_inference_tests / effect_tests 双面检出纪律保留）；typecheck.rs / hm.rs / builtins.rs / driver.rs 四处头注旗标期角色注记同步（R4 文档随代码）
- **契约重定义显式登记（P0-2 兑现——hm-inference-design §2.3 旗标期节 + §3.7 阶段 2 实锚，文档 v0.1.0 → v0.2.0）**：保守性断言更新为「零类型不一致误报」口径（类型不一致即报——含运行期可存活的类型不一致）；**occurs/自应用误报面文档化为政策接受行为**（无限类型静态报错——运行期行为不承诺双向锚）；双向锚 `static_error_is_runtime_error` 范围重锚（超集门内维持 / occurs 面豁免——typecheck_tests 头注 + 函数 doc 同步）
- **断言重锚（5 处子串——语义/检出/定位不变，渲染措辞随判定面）**：`(int . int)` / `(int . nil)` / `(α0 → α0)`（HM 结构化类型渲染——R1-R8 域名 pair/procedure 的精确化）+ 元数区间格式（「过程参数数量不匹配：期望 1..1 实际 2」——内置元数 5 case）
- **切换实测双缺口当场修复（超集门/零误报门经生产入口实测纪律的兑现——PoC 离线语料未覆盖生产入口负例矩阵全貌）**：① hm.rs Ordering 臂未同步 TD-011 r24 字符串全序（`(< "a" "b")` 曾误报「字符串仅支持 =」——PoC r18 遗留旧口径，typecheck.rs 已在前）→ all_str → 合法返回 Bool；② hm.rs car/cdr 臂 `Ty::Nil` 误入保守跳过（`(car nil)` 曾漏检——注释声称「R5 口径之外的动态边界」为错误归因：Nil 是静态确定类型，运行期必然 E5）→ Nil 归入诊断臂（与 R1-R8 R5 负例矩阵对齐）
- **新增旗标期判定面测试组 3 件（typecheck_tests 25 → 28）**：增值面生产证据（`(f "s")` 约束传播检出「类型不一致」——R1-R8 静默面，判定面切换直接证据）+ occurs 豁免政策锚（`(cons x (f x))` 无限类型报出但不断言双向锚——契约政策行为）+ 双面修复锚（TD-011 零误报 ×2 + car nil 检出 + 双向锚维持）
- **12-roadmap §2.5.1 类型检查器行「迁移评估」结论 ✅（v6.4）**：HM 旗标期切换落地 + **自举内迁裁定 = 留 Rust**（INC8 三段口径——读+展开+编译 100% kerf 即「kerf ~80%」；类型检查器属静态分析面不在自举关键路径（INC3 实证 front_from_core 无 check），归 07 §3.4 Rust 保留面；默认期（R1-R8 语义内化）= Stage 2 末评估）
- 生产实证：`kerf check` 负例（`(define (f x) (+ x 1)) (f "s")`）→ `error[E0005]: 类型不一致：num 与 str` 精确定位 1:24（R1-R8 时代此程序静默——HM 增值面 CLI 可见）

### 交付二：50-z 收尾（r29）

- §3.2 六命令全绿（build 零告警 / check 0/0 / fmt 0 diff / clippy --all-targets --workspace 超集 0 / test **713:0:0**（710 零回归 + 净 3）/ 三审计集 EXIT 0 ×3 + CLI 四路径（fib ⇒ 144 / macros ⇒ 42 / check ok / check 负例 E0005 HM 面））
- 对账六面：matrix r29 行（710 → 713 + 汇总链 + 表体两行实测修正 24→28）/ pipeline-test-coverage v0.4.0-r29（Tier 2 头 503→506）/ plan §5b J 执行注记 r29 / RELEASE_NOTES r29 / 12-roadmap v6.4 / hm-inference-design v0.2.0；TD 登记册零事件（双缺口为当场修复非登记债）
- 环境注记：沙箱重置后测试线程默认栈不足（深嵌套 case 爆栈——基线 stash 复跑同型归因环境而非代码）→ RUST_MIN_STACK=16777216 环境级修复（同 r21 工具链重装同型环境恢复操作，worklog 登记）
- r29 tar.gz（§19.3 commit-then-package 正序）+ 包内自举验证 + web 同步 + E2E

### 质量口径

- cargo test --workspace：**713:0:0**（单元 207 + 集成 506；净 +3 集成；门审计集三件 144 case 另计全过）
- cargo clippy --all-targets --workspace：**0 警告**（超集口径）
- cargo fmt --check：0 diff
- 三审计集：stage0/stage1/stage2_gate_audit_r1 全 **EXIT 0**（复验）

---

## v0.4.0-r28（2026-09-11）——批次 J 执行启动：J1 效应 typecheck 收敛（Perform/Handle 子表达式遍历 + 静态负例组双面检出，710 全绿）

### 交付一：48-b J1 效应 typecheck 收敛（会话 Task 49-a——plan §5b 首 MUV）

- **typecheck.rs 效应臂收敛**（补深审 D3/D8「Unknown 放宽面」覆盖缺口——r25 设计性放宽的收敛位）：Perform 臂——效应值表达式入 R1-R8 检查域（子表达式遍历）；Handle 臂——handler 体与被保护计算体均入检出域 + payload/resume 绑定器以 Unknown 装订（遮蔽纪律与 Lambda 臂 save/restore 同型镜像）；**结果类型维持 Unknown**（Perform 值 = resume 注入的任意值 / Handle 值 = 体汇合动态结果——行多态属 Stage 3 类型层，effect-language-design 静态面不收紧裁定维持）
- **hm.rs 效应臂同口径收敛**（HM PoC 域内违例检出）：Perform 效应值进推断（约束集检查）；Handle 两体进推断 + 绑定器 Binding::Mono(Dynamic) 装订（infer_let save/restore 同型）；**结果类型维持 Dynamic**（effect-language-design 风险表「与 HM 推断的效应行交互 = P3/Stage 3」——不收紧、不误报）
- **静态负例组 4 测试（6 违例 case，双面检出——超集纪律：tc 面报 → hm 面亦报）**：Perform 效应值违例（R2 算术混串 + R1 if 非真值）+ handler 体违例（R5 car/cdr 非 pair）+ handle 体违例（R1）+ 双体多错误收集（handler 体 R2 + handle 体 R1 → Span 序合并）；**零误报对照**：r25 六正例 + 绑定器动态用点（payload Unknown/Dynamic 算术与点对）+ effect_stress.krf M5 语料——双面 0 诊断（保守契约维持）
- 生产入口实证：`kerf check` 对 `(handle log ((p k) (car 42)) 1)` → `error[E0005]: car 需要 pair，实际 int` 精确定位 handler 子句体 1:25；合法效应程序 → `ok`
- 改动面：≤3 文件（typecheck.rs + hm.rs + effect_tests.rs——深审 D1 预估口径内）；编译面零改动（bootstrap_compiler_tests 效应 parity 维持 32/32 零回归）

### 交付二：49-z 收尾（r28）

- §3.2 六命令 clean 起步全绿（build 13.32s 零告警 / check 0/0 / fmt 0 diff（一处排版当场 apply）/ clippy --all-targets --workspace 超集 0 / test **710:0:0**（706 零回归 + 净 4）/ 三审计集 EXIT 0 + CLI 四路径（fib ⇒ 144 / macros ⇒ 42 / effect_stress ⇒ 120 / io ⇒ 42）+ check ok）
- 对账六面：matrix r28 行（706 → 710 + 汇总链）/ pipeline-test-coverage v0.4.0-r28（**R4 修正：Tier 2 头 463→503——r26 补账声称「499」未落面，本轮回写实测值**+ effect_tests 行 17→21）/ plan Status r28 + §5b 执行注记 / RELEASE_NOTES r28 / TD 登记册零事件 / worklog 双层 + rec 树 12_r28
- 深审 D3/D8 闭合注记（deep-review-round1.md——「批次 J 引入效应 typecheck 时补静态负例组（≥3）」建议兑现）
- r28 tar.gz（§19.3 commit-then-package 正序）+ 包内自举验证 + web 同步 + E2E

### 质量口径

- cargo test --release --workspace：**710:0:0**（单元 207 + 集成 503 逐二进制实测；净 +4 集成；门审计集三件 144 case 另计全过）
- cargo clippy --all-targets --workspace -- -D warnings：**0 警告**（超集口径）
- cargo fmt --check：0 diff
- 三审计集：stage0/stage1/stage2_gate_audit_r1 全 **EXIT 0**（复验）

---

## v0.4.0-r27（2026-09-11）——批次 J 规划轮：Stage 2 收官批细化 + 余下面处置（§5b/§5c/§5d，零代码轮 706 全绿）

### 交付一：批次 J 细化（48-a——plan §5b/§5c/§5d 三节）

- **§5b 批次 J 四 MUV（Stage 2 收官主体批）**：48-b J1 效应 typecheck 收敛（typecheck.rs/hm.rs Perform/Handle 臂**子表达式遍历**——补深审 D3/D8「Unknown 放宽面」覆盖缺口：效应体内 R1-R8 违例当前不诊断（typecheck.rs L353-357 实锚——`{ .. }` 早退不递归）；结果类型维持 Unknown——行多态 Stage 3 边界如实；负例组 ≥3）+ 48-c J2 HM 旗标期切换（**D8 阶段 2 GO 裁定落定**——深审 D4「早期决策点 / 防 PoC 长期化」兑现；切换面 = check_source L563 + check_source_recover L626 两入口（run 路径不触静态面——爆炸半径有界）；契约重定义显式登记（P0-2 兑现：保守性断言更新 + occurs/自应用误报面文档化 + 双向锚重锚）；类型检查器行「迁移评估」结论随轮登记）+ 48-d J3 FFI VM 面做实（write_stdout char* 按 ffi-ownership-model §8 窗口规程（Str 堆槽 pin + 借用出界 + 返回后 unpin）+ AllocExternal/FreeExternal 开放 + E9/E10/E11 落位 E0010-E0012 + 13 边界 case 对齐 + 回写四处——§21.3 条件 4 完整版兑现）+ 48-e J4 收尾
- **§5c 批次 K 概排（Stage 2 终批，49-x）**：49-a 终门审（stage2_gate_audit_r2 ≥30 新 case + 批次 J 三修复边界 + §21.3 四条件终验 + **§21.5 九信号全核对**）+ 49-b 大阶段末深审环（§14.5 D1-D8 全量 + §14.8/§14.9 + §14.6 阶段间深验证四项 + final-assessment Stage 2 版 + **Stage 3 切换 GO/NO-GO**）+ 49-z 收尾（12 §2.5.1 终态回写 + v0.5-roadmap Stage 2 行）
- **§5d Stage 2 余下面处置表（12-roadmap §2.5.1 十一行逐行落位——规划轮内闭环）**：已兑并行五（Token/CodeValue 增量/元循环/闭包/VM+GC PoC）+ Effect（r25 + 48-b 补静态面）+ **多阶段与缓存增量两行 DEFER Stage 3**（§21.3 不含 + 成熟度研究前沿/收益边际——矩阵自述「可依据当时成熟度重新评估」结构启用）+ **net/process 触发式**（net 窗口核对四依据：效应依赖 ✅ + 零消费 + 沙箱网络受限 + D11 手术面收敛——「预留长期不做实是允许的」条款）+ 宏完整化改判 Stage 3（在用宏面零缺口）+ 类型检查器行 48-c 兑现位
- **TD 登记册排期改判三行**（等级/状态不动）：TD-003/TD-015 → Stage 3 优化窗口 + TD-005 → Stage 3 宏增强窗口（R6/R7 收敛纪律；批次 J 实施发现消费面则回判）

### 交付二：48-z 收尾

- §3.2 六命令 clean 起步全绿（build 14.41s 零告警 / check 0/0 / fmt 0 / clippy --all-targets --workspace 超集 0 / test **706:0:0** / 三审计集 EXIT 0 + CLI 四路径 + check ok）
- 对账六面：matrix r27 行（零计数增量）/ pipeline 零增量（无代码变化——r26 口径维持）/ plan Status r27 / RELEASE_NOTES r27 / TD 登记册 r27 事件（三行改判）/ worklog 双层 + rec 树 11_r27
- 12-roadmap v6.3（九行处置注记回写）+ r27 tar.gz（§19.3 commit-then-package 正序）+ 包内自举验证 + web 同步 + E2E

### 质量口径

- cargo test --release --workspace：**706:0:0**（零代码规划轮——r26 基线零回归；门审计集三件 144 case 另计全过）
- cargo clippy --all-targets --workspace -- -D warnings：**0 警告**（超集口径）
- cargo fmt --check：0 diff
- 三审计集：stage0/stage1/stage2_gate_audit_r1 全 **EXIT 0**（复验）

---

## v0.4.0-r26（2026-09-11）——批次 I 收口：I3 门审查 + 收尾交付（门审计集 53 case APPROVED + 深审五角色全票 GO，706 全绿）

### 交付一：I3 门审查（42-g / 47-a——plan §5a 合同逐项兑现）

- **门审计集第 3 件 stage2_gate_audit_r1（53 case，examples/audit/——§7.3.1 规则 3 可重运行口径）**：A12 单语句负向（基础类型系统——含效应类型面）+ B12 多语句负向（糖九件/module/require/宏/**能力门控 E0006 编译期静态拒绝**（read-line 未授权 → Compile 阶段「能力权限不足」——比 Run 未绑定更强的 fail-closed 形态，实测如实升级断言））+ C10 复杂负向（⑥循环依赖 + ⑦宏深度 + E0007 逃逸深链 + E0008 逃逸续恢 + E0009 元数 + GC 压力 × 类型错 + module 体 inline 运行错）+ D6 错误恢复（含 E0007/E0008 后效应金路径恢复——VM 效应状态无泄漏实证）+ **E7 上轮修复边界（§7.3.2）**：门 B fixpoint 活性（B₁ install 后编译执行 = 种子）/ 缓存 CompilerKind 分桶（生产命中 + 种子不查不存条目数不变）/ E0008 首次恢复位置追踪 / TD-014 专门归因（无失真兜底回退）/ TD-011 全序正负双面 / TD-018 消息单源（if 直用 = cond 脱糖同文）/ recover 多错误收集（46-z 死代码清偿边界）+ **P6 正向含 §21.3 四条件锚定探针**（fib 144 双路径 / prelude 管道 50 / 门 B 轻量终验 B₁/B₂ bytecode_equal + SHA-256 / QBE native fib exit 144 / FFI 模型冻结文档锚 / TCO × 效应 10 万深 ⇒ 100）；run_negative 显式 E 码字段扩展（E0007/E0008/E0009 结构化族）+ 双路径同 Err 机械校验；实测 **53/53 PASS EXIT 0 —— APPROVED 零新发现**（七类覆盖 1/4/2/3/12/1/2 + §7.3.1 配比全过 + §7.3.2 边界 7 ≥ 5）
- **§14.5 深审报告（docs/develop/v0/stage-2/deep-review-round1.md——Stage 2 首篇）**：D1-D8 八维度三段式（§0 如实定位：批次 I 末门审深审，非大阶段末——Stage 2 终批另做 §14.6）+ §14.8 B1-B4 偏差清单（闭环 8 行对照记录 + B1 残留 3 行如实：HM 生产切换（D8 旗标期）/ FFI 实现（模型冻结）/ net 门控行（裁定维持——Stage 2 末窗口）——均纳后续批次计划）+ §6.3 五角色投票 **5.5/5.5 = 100% ≥ 95% GO** + 行动计划 W1-W5
- **§14.9 C1-C6 代码整理（发现即修 4 处）**：clippy --all-targets --workspace 超集口径抓出审计器 2 处 result_large_err（闭包 Result 大 Err 链 → for 循环收集重写）+ hm.rs 2 处 `_ => {}` catch-all 无注释（§14.6.1.1「无注释视为违规」→ 补「_ 臂理由」：free_vars 封闭类型臂 + 内置签名 fall-through 臂）；C2 glob re-export 0 / C3 TODO 0；全链复跑 fmt 0 diff + clippy 0 + **706:0:0 零回归**

### 交付二：42-h 收尾（47-z）

- §3.2 六命令 clean 起步全绿：build --release --workspace 13.56s 零告警 / check 0 errors 0 warnings / fmt 0 diff / clippy --all-targets --workspace 超集口径 0 / test --release --workspace **706:0:0** / 三审计集 EXIT 0（stage0 + stage1 + stage2 新）+ CLI 四路径冒烟（fib ⇒ 144 / macros ⇒ 42 / effect_stress ⇒ 120 / prelude foldl ⇒ 21 + check ok）
- 对账六面：matrix.md r26 增量行（零 cargo 计数 + 审计集 144 case 三件注记）/ pipeline-test-coverage v0.4.0-r26（**滞后两轮补账**——r24 +14 / r25 +22 表体行 + catch-all 小节 r26 实测）/ plan.md Status r26 / RELEASE_NOTES r26 / TD 登记册零事件 / worklog 双层 + rec 树 10_r26
- r26 tar.gz（§19.3 commit-then-package 正序）+ 包内自举验证 + web 同步 + E2E

### 质量口径

- cargo test --release --workspace：**706:0:0**（单元 207 + 集成 499——r25 基线零回归；门审计集三件合计 144 case 另计）
- cargo clippy --all-targets --workspace -- -D warnings：**0 警告**（超集口径）
- cargo fmt --check：0 diff
- 门审计：stage2_gate_audit_r1 53/53 PASS **EXIT 0（APPROVED）** + 深审五角色 100% GO

## v0.4.0-r25（2026-09-11）——批次 I 执行：I 后段双主题（Effect M1-M5 语言级效应全落地 + 能力管线泛化 M2，706 全绿）

### 交付一：Effect M1-M5（42-f 主体——effect-language-design v1.1 全裁定兑现）

- **原语集 9→11**：`perform`/`handle` 两核心形式入 CoreExpr（`resume` 非原语——展开期脱糖为 `(κ v)` App，D4）；Keyword +3；fresh scope 深注入 handle 子句（绑定器 + handler 体——TD-004 口径）；核心形式冻结证明 12 实例（architecture_audit）；自举 expander.krf 三展开臂 + 桥两向（parity 全链）
- **VM ext1 具体化（D6）**：`FrameExt.ext1 = Option<Rc<HandlerFrame>>`（分派键 tag/handler 原型/捕获单元/数据栈水位——原则 27 预留槽位兑现）；`INSTALL_HANDLER{handler, body, tag, trampoline}`（41）+ `PERFORM`（42）两指令（43 项三方冻结——opcode/测试/04 文档）；**三原型帧编排**（T trampoline 惰性单例 code=[Ret] / H handler 原型 params=[payload, resume] / B body thunk 体= lambda 体语义尾位穿线）——编译器零 CLOSURE/CALL 发射（帧编排原子化）
- **continuation 四要素**：捕获帧链（**含 handler 帧本身**——快照 ext1 清除保 D2 浅处理）+ 数据栈快照（VM flat 栈整栈还原——设计三要素之外的实现必要补充）+ 恢复点 + 线性唯一性（consumed Cell 跨帧共享——E0008 含首恢位置追踪）；resume 控制转移语义（Call/TailCall 的 Continuation 臂——当前 H 执行帧拆除）
- **诊断族 E0007-E0009（D9/M4）**：messages.rs 单源（TD-018 纪律）——E0007 逃逸（tag 名经符号值文本直渲染）/ E0008 二次恢复（首恢位置）/ E0009 元数（非 continuation 值面归 E0004 通用族——v1.1 执行注记口径）；driver `from_vm` 码映射（None→E0004）
- **GC 六来源（M5）**：`Value::Continuation` 根集递归（帧链 locals/captures + 数据栈快照——visited 防嵌套环）+ `GcCell` has_heap 判据扩展 + ForeignBox 装箱/解箱（往返恒等——TD-010 协议复用 + 专用追踪器）
- **M3 双路径新口径**：resume 一致性 T1 承载面 = 种子/生产双编译链（42-d eval 退役终态）——双路径 8 case；eval 域（树走）经 `EvalError.effect` 逃逸通道承载 dispatch（D7）+ resume 哨兵域限（显式报错——`call_closure` 拒绝 Eval 闭包同型先例）
- **native 显式拒绝（B1 同型）**：anf/qbe 路径 perform/handle 报 PoC 边界错（效应语义由 VM 承载——Stage 3 后端演进评估项）
- **回写 W1/W3/W4/W5**：01-core-forms §7.3（原语集 9→11 状态翻转 + §8.3 映射行）/ 18-terminology §6（诊断码位登记表 E0001-E0012 全族总账）/ 06-operational-semantics（R10/R11 归约规则 + continuation 值域 + 根集六来源）/ 04-bytecode-vm（43 项九组 + ext1 具体化 + INSTALL_HANDLER/PERFORM 语义）+ effect-language-design v1.1（九条执行注记——数据栈快照/三原型/快照含 handler 帧/E0009 口径/M3 新口径等）
- **测试**：effect_tests 17（设计锚正 6 + M3 双路径 8 + eval 域 3 + 负例 7 + GC 存活 2）+ bootstrap_compiler_tests 门 A 效应组 3（parity 基础/trampoline 共享/行为面）——**706:0:0 零回归 + 净 22**；效应 GC 压力语料 `examples/usage/effect_stress.krf`（万级分配下挂起链存活 ⇒ 120）

### 交付二：能力管线泛化 M2（capability-model-design §7 M2 别名兼容路径）

- **`IoFamily` 形状标记**：`IoGrant` = `Grant<io 族>` 的 trait 形态承载（`CapabilityModelFamily` 关联类型别名兼容语义——冻结路径零删改，原则 27）；归位证明测试（族形状 + Token 关联类型等式 + 授权面回读）
- **门控表 net 增行评估**：依赖条件①效应系统成熟（12 §2.4.5）已就位（本批 Effect M1-M5）+ ②手术面三点加法（D11）；评估结论**维持不增行**——net 语音面属 Stage 2 末窗口（I3 门审后；零破坏纪律：既有门控表/授权管线/require 语法零改动）；`net_gate_rows_unchanged_in_42f` 机器锚
- **D12 同轮协调**：driver 组合根双接触面（Effect ext1 激活 + M2 族形状归位）经 worklog 交叉引用锚定（capability-model-design v1.1）

### 交付三：对账与收尾（46-z）

- 文档同步：matrix v0.1.0-r25（684→706；effect_tests 17 行 + bootstrap 29→32 + 集成 header 499）+ plan.md Status（42-f 交付——I 后段闭环）+ 18 §6 码位登记 + 04/06/01 lang-design 回写 + 两设计文档 v1.1 + compiler.krf 头部契约（节点协议 + OP 表 0..=42）+ examples/README（effect_stress 行）+ TD 登记册（TD-024 效应边界注记）
- **§3.2 六命令全绿**（clean 起步终验）+ r25 tar.gz（§19.4）包内自举验证 + web 同步（kerf-data r25）+ git 入账 + rec 树压实

## v0.4.0-r24（2026-09-11）——批次 I 执行：I2 stdlib/GC/TD 批（五债清偿 + 谓词/foldr 补齐 + TD-023 根扫描对症，684 全绿）

### 交付一：TD 五项清偿（42-e 主体）

- **TD-010 闭包/内置装箱 resolved**：`HeapObj::Foreign(Rc<ForeignBox>)`——类型擦除 Rc 载体（解箱往返恒等 → eq? 按引用）+ **追踪器协议**（`ForeignTracer = fn(&Rc<dyn Any>, &mut Vec<GcRef>)` 由装箱方注入——标记阶段枚举闭包捕获图，kerf-runtime 不依赖 kerf-vm 类型，§11 接口隔离）；原「标记字符串占位」路径删除；渲染 `#<procedure>`/`#<builtin:名>`；**函数列表模式就位**（`(list f g)` + `map` 应用——stdlib 库化前提）
- **TD-011 字符串全序 resolved**：全字符串链按 **Unicode 码点序**参与全部比较族（`Rc<str>` 比较 = UTF-8 字节序 = 码点序——编码保序性）；混合链保持 `{op} 需要数值`（TD-016 口径）；静态面 R3：`Ordering ≡ NumOrAllStr`（全字符串链放行——运行时/静态一致）；HM 超集门语料同步
- **TD-014 嵌套 define 归因 resolved**：专门消息「嵌套 define 重复绑定（同名内部变量只允许出现一次）」+ Span = 第二次出现处 define 形式自身（原「lambda 参数重名」提升兜底——归因失真 + Span 指向体首合成节点）；seed `expand_body` + 自举 `expand-body`/`dup-define-scan` 双侧镜像（判定序一致）；parity_err +2 case（消息 + Span 逐字）
- **TD-018 消息单源 resolved**：`kerf-vm/src/messages.rs` 单源构造器（if 条件 / not / car·cdr / set! 未绑定五族——VM 操作码 + eval 参考臂 + driver 内置三消费面同源）；**`Value::truthy` 复活为单一实现**（原无调用方死助手 → `Result<bool, RuntimeError>` 化——VM `JumpIfFalse` 与 eval if 臂同文；scope_set_tests 对拍回归断言消息文本相等）；前缀统一「if 条件需要 bool」（与静态面 R1 一致）；未绑定族裁定保留（阶段信息差异）
- **TD-023 根扫描对症 resolved**：**基准重定型先行**（新增 `gc_stress_nontail.krf` 非尾形锚定——改前 144.06ms/轮 + 2×→3.2~3.7× 超线性实测成立）；**对症双件**：① `GcCell` 堆根性摘要（`Rc<RefCell<Value>>` → `Rc<GcCell>`——`has_heap` 标志由写路径维护（sound 不变式：每写必置），根集枚举对非堆单元 O(1) 跳过）② 根扫描缓冲跨周期复用（root Vec + visited HashSet——take/归还零 API 变更，无分配化路径 B）；**对拍实测（stash 重建 r23 二进制同会话）**：非尾形 **144.06→105.15ms（-27.1%）**；尾形 gc_stress 39.68→38.57ms（-2.8%）+ fib(25) 86.97→84.22ms（-3.1%）——双噪声带（验收 ≤5% ✓）；残留超线性如实归因 = 帧栈内存 churn + 每周期固定成本（精确 MS 栈根扫描的结构性成本）；写路径 soundness 回归锚 `gc_cell_flag_flips_on_pair_write`
- **TD-008 分代 GC/堆压缩裁定 DEFER（Stage 3+ 条件触发）**：实测依据三面——①收益面不存在（Stage 2 无长驻程序：CLI 单趟/测试/自举管线，分配有界；尾形 38.57ms/非尾形 105.15ms/分配主导 23.76ms 全过验收门）②分代对栈根扫描无通用免除 + 压缩破坏 GcRef=槽位索引契约（转发表 = P1 级全量改写）③复杂度预算（§12——42-f Effect/M2 + 42-g 门审查优先）；重评估触发条件入册

### 交付二：stdlib 缺口补齐（清单清零——09-stdlib v6.3）

- **类型谓词 5 件**：`string?`/`symbol?`/`float?`/`number?`（数值塔域 Int∪Float）/`list?`（真表判定 = nil 或 cdr 链终止于 nil——**Floyd 龟兔环安全**，环 → false）；BUILTIN_SIGS 同步（TcParam::Any → Bool）——Value 变体判别完备面（57 项清单）
- **prelude `foldr`**：foldl 对偶（从表尾累积 `(f 首元素 递归果)` 形态——与 Racket 同序）；prelude_tests +3（用户面/对偶语义可观测（foldr 2 vs foldl -6）/双路径）
- **缺口盘点口径（三面）**：①文档合同面 52/52 对齐（数量+逐项）②值模型谓词完备面（5 缺 → 补齐）③prelude 库化对称面（foldr 缺 → 补齐）——**I2 stdlib 缺口清单清零**

### 交付三：对账与收尾（45-z）

- 文档同步：09-stdlib v6.3（52→57 项 + 比较行重写 + prelude foldr）+ TD 登记册（五 resolved + 一裁定 + 索引/详情/Status）+ performance-baseline §4.1（r24 复测四口径对拍表）+ §9.1 复测记录 + §10 热点行 resolved + matrix v0.1.0-r24（670→684；表体 gc 9/stdlib 24/scope_set 10/prelude 10）+ pipeline 性能小节 + plan.md Status（42-e 交付）+ 本 RELEASE_NOTES
- **§3.2 六命令全绿**（clean 起步终验）+ r24 tar.gz（§19.4）包内自举验证 + web 同步（kerf-data r24）+ git 入账 + rec 树压实

## v0.4.0-r23（2026-09-11）——批次 I 执行：I1 收口（生产切换 + 门 B fixpoint 两次编译自身字节一致 + eval 退役终态，670 全绿）

### 交付一：CompilerKind 生产切换（42-d 主体，S3 段——P1/P2）

- **`CompilerKind::{Bootstrap,Seed}` 分派**（driver.rs——镜像 `ExpanderKind` 先例）：分派位 `front_from_core` 第 4 步——生产（`compile_front`）= 自举 Compiler（compiler.krf 在 VM 上运行），种子（`compile_front_seed`）= Rust Compiler（bootstrap 加载引导 + parity oracle）；**bootstrap init 恒种子路径**（P1 硬约定——无递归）；`check_source_recover` 恢复路径同生产口径
- **守护测试 `production_compiler_is_bootstrap`**（P2——独立线程活性探针双信号：生产编译后 is_loaded 翻转 + 种子路径不加载自举 Compiler（引导恒种子的实测面））
- 三自举模块新增 **`install_state`/`reset_state` 钩子**（门 B fixpoint 的 B₂ 轮「以 B₁ 为新 bootstrap 程序」语义——状态构造提取为共享 `build_state` 单一实现）

### 交付二：门 B fixpoint——两次编译自身字节一致（§21.3 条件 2 终验）

- **`gate_b_fixpoint_two_self_compiles_byte_identical`**：B₁ = 生产链（自举读+展+编）编译自举三件 + preamble；B₂ = 以 B₁ 产物为新自举状态（三件 install）再编译同源；**硬门判据全过**：B₁[i]/B₂[i] 四程序 `bytecode_equal` 全结构一致（含 debug_spans）+ **SHA-256 摘要一致**（`BcProgram` Debug 结构序确定序列化——`sha256_hex` 自研 hash.rs 零新依赖）；隔离纪律 §7.4（关缓存 + fresh 状态——缓存命中假阳性防线）
- **加强判据（非硬门）实测两裁定（GATE 1 诚实入档）**：① B₀（种子链）vs B₁（自举链）**按名反汇编全等**（四程序——结构 + 名 + span 位置；E1 边界 expansion_id 不参与）；② 宏自由件（compiler.krf）**跨链全结构 bytecode_equal 实测不成立**——两链符号表各自 intern 序不保证一致（差异仅 Symbol 数值——i1-design §7.3「名字是唯一稳定口径」预判的实证；全结构判据在同链 B₁/B₂ 下成立）
- **`gate_b_b1_programs_execute_as_bootstrap_chain`**（行为面）：B₁ 字节码作为自举 Compiler 实际运转——install 后编译的程序 VM 执行 = 种子链结果（「产物编译自身」不止字节一致，可执行性同证）

### 交付三：eval 退役终态裁定（P5/INC7）+ 缓存键分桶（B11/P4）

- **eval_source 从生产路径退役**：CLI `eval` 子命令移除（退役提示 + 指向 run）；driver pub API 移除（`eval_source`/`resolve_eval_hygiene_fallbacks`/`collect_global_refs` 删除）；kerf-vm eval.rs **存档为 Rust 参考实现**（scope_set_tests 语义 oracle 消费面保留——12 §2.5 行 299 终态回写）
- **T1 双路径互查新口径**：`run_source`（生产链）vs **`run_source_seed`**（种子链公共参考入口——新增 pub API）+ `compile_source_seed`（fixpoint B₀ 基准）；T1 测试面全量迁移（stage0/1 十文件 + common + 双审计集——eval 侧断言迁移为种子链对拍/编译 parity 断言，§9.4.3 断言迁移非删除）
- **TD-017/TD-009 联动注销**（INC7 清单）：TD-017 resolved（256 深度上限域随 eval 退役注销——深尾递归生产路径经 TCO 无上限，`deep_tail_recursion_production_path_tco` 重写口径）；TD-009 resolved（eval GC 根集域随路径注销——生产 run 路径根集完整）
- **缓存键 CompilerKind 分桶**（B11）：`cache_key(source, filename, kind)`——维度入 config_fingerprint 构成层（CacheKey 冻结字段结构不动）；种子路径不经缓存（不查不存——`pipeline_seed_path_cache_isolated` 集成实测）+ 键区分 + 跨桶隔离双测试

### 交付四：对账与收尾（44-z）

- 文档同步六面：plan.md Status（I1 收口交付 r23）+ i1-design v1.3（S3 执行注记——跨链符号值实测裁定 + 门 B 首跑全过 + 缓存分桶实测）+ matrix v0.1.0-r23（665→670；单元 202→205 + 集成 463→465；表体 driver 单元 58→67 实测修正（r12 时代陈旧数）+ bootstrap_compiler_tests 27→29）+ pipeline v0.4.0-r23 + TD 登记（TD-017/TD-009 resolved）+ 12-roadmap §2.5 行 299 终态回写 + 本 RELEASE_NOTES
- **§3.2 六命令全绿**（clean 起步终验）：build --release 12.84s 零告警 / check 0 errors 0 warnings / fmt 零 diff / clippy --all-targets -D warnings 0 / **test --release --workspace 670:0:0**（665 基线零回归 + 净 5：单元 +3（守护 + 缓存 ×2）+ 集成 +2（fixpoint ×2）；23.9s）；CLI 冒烟（VM fib 75025/144 + macros `(2 1)`⇒42 + io 门控端到端 + check ok 38 指令 + native fib exit 144（print-free PoC 边界先例口径）+ E0006 负例 fail-closed + **eval 退役提示 exit 2**）+ 双审计集 EXIT 0
- r23 tar.gz 打包（§19.4 命令）+ 包内自举验证 + web 同步（kerf-data r23）+ git 入账

## v0.4.0-r22（2026-09-11）——批次 I 执行：I1 中段糖/module/require 面全迁移（门 A 扩展组全臂 parity，665 全绿）

### 交付一：compiler.krf module/require 两臂迁移（42-c 主体，S2 段）

- **module 臂**（`compile-module-body` + `compile-module-seq`）：镜像 compile.rs:416 逐语义——体 inline 编译**逐项恒非尾位**（区别于 begin 末项继承尾位：module 项不构成尾位——TCO 不参与）+ 中间值 Pop 携项自身 Span + 空体 PushNil 携 module 自身 Span + 首原型名覆写 `'<main>'` **值等价无操作**（Rust `pm.name = Symbol(u32::MAX-1)` 与 proto 0 创建/回写值恒等——设计 v1.2 注记）
- **require 臂**：PushNil（r8 能力声明零字节码语义——顶层「每形式一值」栈不变式维持；权限验证在 driver 前端 R9/E0006 完成——编译段零感知与种子同口径）
- 42-b 显式边界错误两处移除——**边界不对称消除**（生产切换点 CompilerKind 属 42-d）；fvo 面 42-b 已预置（module → 体遍历 / require → 空——与 kerf-core expr.rs:358/365 一致），本轮零改动通过

### 交付二：门 A 扩展组 parity 套件（42-c 验收面，19 → 27 测试函数 / 净 +8）

- **parity 扩展组 46 case**（≥12 超额）：module/require 正例组（多项体 Pop + 导入/导出面 + 尾位非继承 + 确定性双跑）/ 糖九件（let 家族 8 + cond/when/unless 9 + and/or/while 10——**全管线 parity**：expander 脱糖 → 双编译路径 bytecode_equal）/ 宏语料 3（swap!（let+set! 混合）+ my-or（递归省略号）+ def-twice（begin 多模式））/ **prelude 注入序**（preamble.krf 全文真实语料——生产前端 import kerf-prelude 实际注入的编译对象 + 用户 module import 面同编）/ **examples/usage 全六件双路径 bytecode_equal**（fib/closures/higher_order/macros/gc_stress/io——require/宏/GC 压力/高阶函数全谱系）
- 边界断言改写：42-b 的 `parity_err_module_require_boundary`（module/require 自举报边界错误）改写为 `parity_module_require_arms` 正例 parity + 确定性断言（生产切换守护属 42-d）
- **行为面 +2 组**：糖九件语义（let*/letrec 互递归/while 计数/and/or/when/unless——自举编译段产物 VM 执行 = 生产管线结果）+ module 臂行为面（inline 编译产物执行 = 生产管线含 registry 前端面；闭包+糖+module 混合语料）
- **语料实测勘误两处（GATE 1 诚实记录）**：① 条件位严格 bool（`(and 1 2 3)` 触 E0004「条件位置需要 bool」——kerf truthy 语义显式定义，行为语料改 `(and true true 3)`；parity 不受影响——编译段不类型检查）；② 同层 let 重名绑定是展开器错误（lambda 形参重名拒绝——语料改跨层嵌套遮蔽）

### 交付三：对账与收尾（43-z）

- 文档同步六面：plan.md Status（42-c 交付 r22 + 42-d 执行待续）+ 切口设计 v1.2（S2 执行注记 + module 名覆写值等价注记）+ matrix v0.1.0-r22（657→665；单元 202 + 集成 463）+ pipeline v0.4.0-r22（Tier 2 表体 bootstrap_compiler_tests 行补齐——r21 头部有表体漏的 R4 同型修正）+ v0.5-roadmap 批次 I 行 + 本 RELEASE_NOTES
- **§3.2 六命令全绿**（clean 起步终验）：build --release 12.87s 零告警 / check 0 errors 0 warnings / fmt 零 diff / clippy --all-targets -D warnings 0 / **test --release --workspace 665:0:0**（657 基线零回归 + 8；36.6s）；CLI 冒烟六路径（VM fib 75025/144 + macros `(2 1)`⇒42 + io 门控端到端 + check ok 38 指令 + native fib exit 144 + E0006 负例 fail-closed）+ 双审计集 EXIT 0（stage0 41 + stage1 50 APPROVED）
- r22 tar.gz 打包（§19.4 命令）+ 包内自举验证 + web 同步（kerf-data r22 + footer）+ agent-browser E2E + git 入账

## v0.4.0-r21（2026-09-11）——批次 I 执行：I1 前段基础核心形式 kerf 化（三件套第三实例，门 A parity 657 全绿）

### 交付一：compiler.krf——八臂编译段 kerf 实现（42-b 主体，S1 段）

- `crates/kerf-driver/src/bootstrap/compiler.krf`（~790 行）：**compile.rs 798 行的逐语义镜像**——三件套第三实例（r6 Reader / r14/r15 Expander 之后）。八臂全量：Literal（标记化分派 + Bool/Nil 直发不进池 + 引号点对递归先 car 后 cdr 对齐 MAKE_PAIR）/ VarRef（三源解析）/ If（跳转回填 j_false→then→j_end→patch 序）/ Begin（末项继承尾位 + Pop 挂项自身 Span）/ Set!（值→DUP→存储三路径）/ Define（入口原型守卫 + D1 消息逐字）/ App（被调先、参数从左到右 + 尾位 TailCall）/ Lambda（自由变量出现 → 捕获解析 → 新原型 → 新帧 → 体编译 tail=true → RET → 回写 → 弹帧 → CLOSURE 发射）
- **作用域解析机逐语义镜像**（B3 最难段）：`match-bindings`（同名 + `binder.scopes ⊆ ref_scopes` 子集匹配 + max-cardinality 严格大于替换——并列先注册优先）+ `resolve-var`（帧栈自顶向下；帧 0 仅局部；其余局部先于捕获；首个含子集匹配帧胜出；无候选 → 全局）+ 自由变量遍历（绑定屏蔽 + letrec* 序 + **shadow-pop 计数口径逐位镜像**——形参「新名才入栈 + 弹出恒为形参数」的 Rust 既有行为原样保留）
- **确定性纪律**（§7/B8）：入口全量复位（CC-* 14 项状态——镜像 CompileCtxt::new 每调用新上下文）+ 常量池/全局索引关联列表首插序（禁哈希序天然满足）+ 符号一律 str 携带桥回 intern + `const-eq?` 结构相等（eq? 对序对是引用相等——逐字段递归；Float 按 f64 == 镜像 Rust HashMap Hash+Eq 去重行为：±0.0 合一、NaN 永不去重）
- module/require 两臂显式边界错误（42-c 迁移面——§2.3-4 显式失败不静默）

### 交付二：bootstrap_compiler.rs 桥 + 门 A parity 套件（42-b 验收面）

- `crates/kerf-driver/src/bootstrap_compiler.rs`（~640 行）：CoreExpr → core 节点（四头字段协议 tag/s/e/exp——expander 输出同形态）→ `lexc-compile-program` VM 调用 → `('prog ...)` → BcProgram 类型重建（原型名形三态 `'main/'anon/'name`——魔法符号 Symbol(u32::MAX-1/2) 桥侧重建；操作码码表 0..=40 = opcode.rs 声明序；span 三元组桥侧注入 file_id）。**42-b 边界：parity 影子路径**（生产仍走种子 compile_module——CompilerKind 切换属 42-d）
- **INC4 实现期修订**（登记于切口设计文档注记）：字面量值消歧标记形态（`('int v)('float v)('str s)('sym 名)('pair l r)`——Str/Symbol/Float 在 VM 值面无谓词区分，桥侧定型传递）；span 携带 (s e exp) 三元组（bytecode_equal 判据含 expansion_id——INC4 原文「span对」修正）
- `tests/v0/stage2/plan/bootstrap_compiler_tests.rs`（19 测试 / 门 A 基础组 ≥8 超额）：**parity 13**（bytecode_equal 全结构含 debug_spans——字面量/常量池去重/引号点对/全局 define/if 回填/begin 尾位/嵌套捕获三链+遮蔽/set! 三路径/尾位穿线含相互尾递归/深嵌套 100 层/确定性双跑/空程序）+ **负例 2**（define 位置 D1 消息+Span 逐字；module/require 42-c 边界不对称断言）+ **行为面 4**（fib 144 / closures 计数器 (4 2) / higher_order map 平方 / 10 万层深尾递归——自举编译段产物 VM 执行 = 生产管线结果，examples/usage 基础件核心语义）
- **语言陷阱实测发现**（krf 侧修复三处）：`'true/'false/'nil` 在 kerf 中是 bool/nil **字面量**而非符号——标签分派必须经 `symbol->string` 字符串比较（expander.krf tname 同款纪律）；编译期两轮括号失衡（逐行平衡检查修复）

### 交付三：R4 发现项修复——操作码三方冻结漂移补齐

- **opcode_count_matches_spec 修正（40→41）**：TailCall（r18/40-c TD-022 TCO 引入）此前漏列于守护测试枚举——enum 实有 41 变体 vs 测试断言 40（数组恰好 40 项而断言同值——测试自洽但与 enum 漂移）。按 sop 附录 A R4（代码为准 + 本次修正文档）：opcode.rs 测试枚举补齐 + `04-bytecode-vm.md` 三处同步（§1 冻结计数 + 函数操作表行 3→4 + §3 执行循环组计数）
- 该发现证明门 A parity 语料经双实现实跑的对账价值（§2.3-11 先实测禁臆测——三方冻结契约的漏网只有全量对账才可见）

### 交付四：对账与收尾（42-z'）

- 文档同步五面：plan.md Status（42-b 交付 r21）+ 切口设计 Status/INC4 注记 + matrix v0.1.0-r21（638→657 净 +19 集成；单元 202 + 集成 455）+ pipeline-test-coverage v0.4.0-r21（Tier 2 行 + 657 基线）+ 本 RELEASE_NOTES
- **§3.2 六命令全绿**（clean 起步终验）：build --release / check 0/0 / fmt 零 diff / clippy --all-targets -D warnings 0 / **test --release --workspace 657:0:0**（638 基线零回归 + 19）；CLI 冒烟 + 双审计集 EXIT 0
- r21 tar.gz 打包（§19.4 命令）+ 包内自举验证 + web 同步（kerf-data r21 + footer）+ agent-browser E2E + git 入账

## v0.4.0-r20（2026-09-11）——批次 I 执行启动：I1 切口评估与迁移设计（638 零回归）

### 交付一：I1 切口评估与迁移设计（42-a——批次 I 首 MUV）

- `stage-2/i1-incision-migration-design.md`（10 节 + 附录）：**现状基线 12 实锚 B1-B12**（compile_module 单一入口 :229 / 十臂全景 / 作用域解析机 / bytecode_equal :145 现成 §21.3 判据 / 三件套先例×2 / analyzing 不在生产编译路径（front_from_core 实证）/ eval 参考路径独立 / SCOPE-NEXT 入口复位 :1471 / TCO 尾位穿线 / $hyg$N 回退 / 缓存键缺口 / 全结构比较无灰区）+ **本体盘点表**（S0-S6 段×文件×行数×依赖×裁定——compile.rs 798 迁移主体 / 字节码域 534 留 Rust / 组合根留 Rust / typecheck+hm 1709 绑 42-f / eval.rs 391 排退役）
- **切口裁定 INC1-INC8**：切口位置 = compile_module 单点（三件套第三实例——compiler.krf + bootstrap_compiler.rs 桥 + 种子 oracle）；值树契约复用 expander.krf 输出格式（输入零新设计）；字节码域留 Rust（VM 宿主契约）；组合根留 Rust（编排非编译逻辑）；**analyzing 段不迁**（I1 范围内——自举命题不依赖 typecheck，迁移评估绑 42-f/HM 同轮）；**eval 退役裁定排 42-d**（12 §2.5 行 299 口径）；**~80% 口径精确化**（读+展开+编译三段 100% kerf = §21.3 条件 1 机器口径）
- **段序 S1-S3（DAG 无环）**：S1=42-b 基础八臂（含作用域机+闭包捕获+回填——最难段 B3 风险前置）→ S2=42-c module/require 面+糖全管线 parity → S3=42-d 生产切换+自举终局
- **parity 三门 A/B/C**：门 A 段 parity（`bytecode_equal` 全结构含 debug_spans——基础组 ≥8 + 扩展组 ≥12）；门 B 自举一致性（§21.3 条件 2 机器判据——自举链 B₁/B₂ 隔离运行四程序逐一 bytecode_equal + 加强判据 B₀/B₁ 种子-自举全链终验）；门 C 回归门（全套件+双审计+T1 收口+CLI 冒烟）
- **切换点 P1-P5**：CompilerKind 镜像 ExpanderKind / 守护 production_compiler_is_bootstrap / 无 parity 不切换 + 单点回退 / **缓存键分桶（B11——种子与自举产物不得混享缓存）** / eval 退役终态口径
- **确定性纪律**（fixpoint 先决）：入口复位（SCOPE-NEXT :1471 实证延伸）+ 插入序即索引 + 符号 str 携带桥回 intern + 门 B 隔离运行

### 交付二：对账与收尾（42-z）

- plan.md Status 行（批次 I 执行启动 r20 交付 + 42-b 执行待续）+ §5a 42-b/c/d 行引用本设计为验收合同；matrix v0.1.0-r20（零测试增量注记 + 638 复跑）/ pipeline v0.3.0-r20 / 登记册 v0.3.0-r20（设计轮零债务面 + eval 退役排 42-d 注记）/ v0.5-roadmap r20 行
- **§3.2 六命令全绿**（clean 起步终验）：build --release 12.94s 零告警 / check 0/0 / fmt 零 diff / clippy -D 0 / **test --release --workspace 638:0:0**（单元 202 + 集成 436——零回归精确复现 r19 基线）；CLI 冒烟四路径：VM run fib ⇒ 144（print fib(25)=75025 + 终值 fib(12)）/ native fib（print-free 变体——TD-024 PoC 边界内）exit 144 / check ok（2 原型/9 常量/38 指令）/ require 门控端到端（print 输出 + nil）+ **E0002 负例**（未知能力项「print」fail-closed 拒绝——R9 防线实证）
- r20 tar.gz 打包（§19.4 r17 版命令）+ 包内自举验证 + web 同步（kerf-data r20 三节点 + footer）+ git 入账

## v0.4.0-r19（2026-09-11）——批间插入轮：能力模型泛化设计 + 模型层骨架冻结 + 批次 I 细化（638 全绿）

### 交付一：能力模型定位审思与泛化设计（41-a——用户指令轮）

- `stage-2/capability-model-design.md`（10 节）：**七面对照**（设计/契约接口/职责/能力覆盖/边界/命名/扩展面——真实 vs 当前逐面代码实锚 B1-B8）+ 术语裁定（「能力模型」双义消歧：语言能力 vs 权限安全模型）+ **族分类学 10 族候选**（io ✅ / ffi ✅设计冻结 / net / process / file / time / random / eval-stage / compilation-service）+ **令牌演算 6 操作**（mint ✅ + delegate 隐式 + attenuate/revoke/compose/amplify 预留位）+ 分层架构（模型层/族层/管线层/消费层四层归位）
- **裁定 D1：当前定位过窄成立**——能力安全模型被 IO 第一实例在命名（IoGrant/IoRequirements/IOError）、类型（Capability 枚举 2 变体）、职责（capability.rs 五职责全 IO 具体化）三面遮蔽；模型层无冻结位（13 §3.3 预留原则违例面——net/process 引入将触「五点手术」）
- **化学反应矩阵 C1-C6**（全部「正交可组合不合并」——§11 + D10 边界条件）：能力×效应（perform 需令牌 + handler=权限作用域 + 「不可撤销效应」统一窗口）/ 能力×多阶段（代码值携带能力集合——quote 零改动 + run 验证 D6）/ 能力×缓存（CacheKey 加能力面 D7）/ 能力×FFI（CPointer 归位第二实例 D8）/ 能力×HM（令牌类型禁泛化 D9——与值限制同型）/ 能力×工具链（编译即服务=能力合同 D10b）
- 裁定表 D1-D12 + 迁移路径 M1-M6（零破坏——冻结契约全程不动）+ 测试锚点正 6 负 6 + 风险 4 项 + 回写义务 6（M6 本轮全兑现）

### 交付二：模型层骨架 P3 冻结（M1 落地——reserved/ 第八子模块）

- `reserved/capability_model.rs`：`CapabilityModelFamily`（族形状——`type Token` + `family_name()`）+ `TokenCalculus`（演算位——`attenuate(&Token) -> Token` / `revoke(&mut Token)`，**无默认体**——P3 位不可被实现体污染）；模型层公开面零 Io 前缀（防层次再耦合）；生产面子模块零依赖（J3 维持——归属证明在测试面）
- **Probe 四测试**：骨架冻结（Probe net 族）/ **io 族两令牌归属证明**（`io_family_tokens_satisfy_model_shape`——IO ⊂ 能力模型的机器验证，用户判断的代码面证明）/ ffi 令牌归属证明（ExternalType::CPointer 载体）/ 演算位签名证明（函数指针形态）
- 兼容实证：capability.rs 12 测试 + reserved_ext_tests 12 集成零改动通过（原则 27）；mod.rs 速览表八子模块 + re-export；capability_io.rs / capability.rs 头部层次定位注记
- 文档回写：13 §3.1 标题术语消歧（v7.0——「4 个能力模型」→「4 个语言能力」）+ 13 §3.1.3 v7.0 三层形态注 + 12 §2.4.5 r19 注（手术面 D11 五点→三点）

### 交付三：批次 I 细化 + 收尾（41-b/41-c）

- `stage-2/plan.md` §5a：**42-x 八 MUV 六字段分解**——42-a I1 切口评估与迁移设计 / 42-b 基础核心形式 kerf 化 / 42-c 糖+module/require 面 / 42-d 两次编译自身字节一致（§21.3 条件 2 SHA-256 终验 + eval 退役终态）/ 42-e I2 stdlib+TD 批（TD-008/023/009/010/011/014/018）/ 42-f **I 后段 Effect M1-M5 + 能力管线泛化 M2 同轮**（driver 组合根双接触面协调）/ 42-g I3 门审查 + §14 阶段末环 / 42-h r20 收尾
- §3.2 六命令全绿（clean 起步终验）：build --release 12.49s 零告警 / check 0/0 / fmt 零 diff / clippy -D 0 / **test --release --workspace 638:0:0**（634 + 4——单元 202 + 集成 436）；CLI 冒烟：VM fib ⇒ 144 / native fib exit 144 / check ok / 能力门控 require 路径
- **对账六面**：RELEASE_NOTES（本条）/ matrix v0.1.0-r19（638 总量 + r19 增量行 + r18 集成计数勘误 438→436——内部矛盾 198+438=636≠634 修正）/ 登记册 v0.3.0-r19（零债务面）/ pipeline v0.3.0-r19（Tier 1 202 + driver 64/64 + Tier 2 436）/ v0.5-roadmap r19 行 / plan.md §5a
- r19 tar.gz 打包（§19.4 r17 版命令——tools/ + scripts/ 入包）+ 包内自举验证 + web 同步（kerf-data r19 三节点 + footer）+ git 入账

## v0.4.0-r18（2026-09-11）——批次 H：语义演进评估轮 + 三债清偿 + HM PoC（TCO 尾调用优化 + TD-007 完整口径 + Effect 语言级设计 + HM 推断 PoC，634 全绿）

### 交付一：H1 8 原语迁移五项语义层评估 + §6.3 全票投票（40-b）

- `stage-2/primitive-migration-evaluation.md`（6 节）：五项评估 × 三段式（收益/成本/风险）+ §13.4 J1-J6 判据 30 检查点 + 五角色逐项投票 20 票全记录（5.5/5.5 × 5 全票——E1 DEFER-TO-STAGE3 / E2 GO-DESIGN / E3 分层 / E4 SPEC-ANCHOR / E5 REJECT-STANDALAND）+ 代码实况锚 3 项（A1 词法寻址已实现 / A2 块式 ANF 实化 / A3 parity 链在飞）
- **总裁定：Stage 2 内原语集零变更**（核心冻结原则 9 维持）——8 原语形态整体迁移 = Stage 3 切换期候选（§13.2 登记）；§21.3 验收面与 12-roadmap 承诺面口径调和显式化

### 交付二：H2 三债清偿 + 一裁定（TCO 落地——40-c）

- **TD-022 resolved（TCO 兑现）**：VM `Op::TailCall` 帧复用（拆帧承返回地址——帧数净零）+ 编译器尾位穿线（`compile_expr(ctx, e, tail)`——Lambda 体 / If 两臂 / Begin 末项传递；顶层恒 false 主原型 Halt 终止）+ 内建尾调用隐式 RET + 指令预算护栏 `MAX_INSTRUCTIONS=10^9`（TCO 后帧数不增的无限尾循环兜底——结构化报错非挂死）+ `run_program_with_budget` 测试注入入口；实证：127,780B 源（5,000 define——>10^5 字符边界）自举管线完整通过 + 自举 expander 10_000 深度链端到端（TD-007/022 耦合解除）
- **TD-007 resolved（完整 10_000 口径）**：Stx Rc 共享化（`List/Vector → Rc<Vec<Stx>>` clone O(1)）+ retag 迭代式重建（显式工作表后序——栈深恒定）+ **均匀标记** `uniform_tag`（retag 输出子树均匀作用域证书 + `add_scope_to_all` 注入清除保健全性——链 N 步总工作量 O(N)）+ 扁平 Drop（唯一持有脊柱工作表拆除）；上限 500→10_000（种子 + 自举 expander.krf 同步）；10_000 链 0.02s + 边界 10_001 报错
- **TD-017 裁定维持 256**：eval 参考路径 I1 退役在即——大栈线程化不成立；T1 域注记（VM 尾递归超 256 深度域在双路径互查域外）
- **TD-023 P2→P3 降级重定型**：TCO 副作用实测 gc_stress 61-62ms × 5 轮稳定（r16 回归值 207-235ms → **-70%**；Stage 0 基线 160.4ms → -62%）——原基准不再复现回归（P2 证据基础失效）；残留非尾形根扫描模式待新基准（绑定 I2）
- **语义变更注记**：尾递归恒定帧（旧 105_001 尾递归报帧上限反转为通过项——tco_tests 正例；帧上限负例改非尾形态；尾调用帧不出现在追踪链——GCC/clang -O2 同行为）

### 交付三：H3 Effect 语言级设计（E2 GO-DESIGN 兑现——40-d）

- `stage-2/effect-language-design.md`（8 节）：设计裁定 12 项（D1 perform/handle 二形式 / D2 浅处理 / D3 continuation 线性唯一（Fresh→Resumed 动态防线 + E0008）/ D4 resume 非独立原语 / D5 set!→Perform(State) = 等价证明非实现 / D6 ext1 具体化 / D7 eval 逃逸映射 + T1 域收窄 / D8 TCO 正交 / D9 E0007-E0009 诊断族 + FFI 族 E0010-E0012 码位预留 / D10 能力-效应正交 / D11 多次恢复不实现 / D12 实现窗口 = 批次 I 后段）+ R10/R11 归约规则 6 条 + E4 三要素兑现表 + 迁移路径 M1-M5 + 风险 5 项全附缓解；实现窗口裁定 D12（设计做实 Stage 2 / 实现批次 I 后段——roadmap 口径回写）

### 交付四：H4 HM 推断 PoC（38-d 设计 GO 有条件兑现——40-e）

- `kerf-compiler/src/hm.rs`（~850 行）：**约束三段式**（生成 → worklist 求解 → zonk）——数值格扩展合一（Int/Float/Num 互匹）+ occurs check + 元数结构 + 失败逐条收集（多错误）；D2 值限制 / D3 set! join / D4 递归预置（define + letrec 双形状——sugar.rs 实况核对）/ D6 双点泛化（顶层序 + let 形状 App-of-Lambda 识别）/ D7 诊断（E0005 族 + 形式级桶隔离 + 512 生成期预算）；BUILTIN_SIGS 解释层重解释（cons/car/cdr 结构化 Pair(τ,τ) + NumOrAllStr/Ordering 变元锚点约束）
- **双门全过**：超集门 29 程序（R1-R8 检出 → HM 亦检出——双检查器并行对照）+ 零误报门（examples 六件套 + 动态边界 15 case 零诊断）；**四类缺口检出证明**（用户 lambda 实参错 / car 元素类型 / 分支分歧 / 递归元数域错——R1-R8 静默放过面）；occurs ≥3 + 值限制 ≥2 + 多错误 Span 序；**验收口径（R4）**：fib : (num → num) 非 Dynamic（设计预期 Int→Int 修正——n 全用点数值域约束，格合一最小解 = Num）
- 实现勘误实录：generalize 自污染（exclude + 泛化点前 solve_now）/ Ordering 变元锚点约束缺失两轮修复

### 交付五：40-g 接口预留层标准化拆分（用户指令插入 MUV）

- `reserved/mod.rs` 344 → **66 行纯声明**（模块声明 + re-export）：四能力族独立文件——`effect_handlers.rs`（79 行）/ `multistage.rs`（69 行）/ `capability_io.rs`（79 行）/ `compilation_cache.rs`（120 行），对齐 13 §3.1.1-§3.1.4 分节结构（§13.4 J1-J6 全过）；契约与实现的模块分离形态注记（P2 消费面 crate::capability/crate::cache）；**原则 27 兼容实证**：reserved_ext_tests 零改动通过（re-export 路径恒有效）；Probe 冻结测试随迁拆分（合并测试 → 4 子模块独立 Probe，净 +2）

### 交付六：质量口径与收尾

- **§3.2 六命令实跑全绿**（clean 起步：build --release 12.78s 零告警 / check 0/0 / fmt 0 diff / clippy -D 0 / **test --release --workspace 634:0:0**（34s——集成 438 = 409 + TCO 12 + HM 15 + Probe 拆分 2；单元 196——逐二进制实测：span 11 + syntax 11 + core 10 + reader 23 + expander 32 + compiler 15 + runtime 9 + vm 18 + driver 60 + backend 9））；CLI 冒烟：VM run fib ⇒ 144 / native fib exit 144 / check ok / 恢复模式 E0002 合并报告
- TD-025 resolved（40-f 收尾轮补修）：krf 六头字段协议（`(tag s e exp scopes uni . fields)`——uni = ('uni . scopes) 均匀证书：make-node 默认 nil / retag 置位 / inject 清除 / 桥 stx_to_node 同步）+ retag-scope 快路径（种子 uniform_tag 镜像）——门审计 C02 包装链 **>540s → 7.37s（73×+）**；双审计集 EXIT 0（stage0 41 + stage1 51）；实现勘误实录：六头协议初版桥侧编辑未生效（fmt 重排致静默未匹配——最小形式全崩定位）+ 弱内容等快路径被 parity 套件捕获否决（def⊆use 顶层角共享过早——展开代次不提升分歧）→ 真标记协议
- r18 tar.gz 打包（§19.4 r17 版命令——tools/ + scripts/ 入包）+ 包内自举验证（634:0:0 + CLI 冒烟）+ web 三层同步 + agent-browser E2E + git 入账 + worklog 树压实（38-g 补记 + 40-a~40-g 全条目）

## v0.4.0-r17（2026-09-11）——批次 G：后端 / FFI / 类型三主线（QBE 后端 PoC fib 本地码端到端 + FFI 所有权模型 + HM 设计轮 + TD-013 恢复实现，605 全绿）

### 交付一：G1 QBE 后端 PoC（首个非 VM 后端——§21.3 条件 3 兑现）

- **QBE 1.3 工具链落位**（§3.1 链：scripts/ → tools/ → docs/tools/ → 安装 → 记录）：`tools/qbe/bin/qbe`（670,544 B，amd64_sysv 六目标）+ 源码归档（可重建）+ `scripts/qbe/setup.sh` + `docs/tools/qbe/setup.md`（含三段冒烟实录 + 语法勘误两条：函数签名必带返回类型 / 比较指令宽度后缀 csltl）
- **kerf-backend 新 crate**（第 10 成员——后端层独立，§11）：`codegen.rs`（**契约迁移**：CodegenBackend/AnnotatedANF 自 kerf-driver/reserved 迁入正式家——签名零变化（原则 27），AnnotatedANF 从指纹占位**实化**为函数定义集 IR，fingerprint 字段保留；reserved/codegen 改薄 re-export，旧路径继续可用——迁移兼容锁存测试实证）+ `anf.rs`（块式 ANF IR + CoreExpr lowering：phi 值合并 / 跳转回填（§19.3 不变式 2 同型）/ 形式级两遍扫描 / arity 静态校验）+ `qbe.rs`（IL 生成 + QbeBackend 首个做实实现——QBE 内建 pass 声明 ssa/gvn/gcm/rega）+ `aot.rs`（外部进程编排：qbe → 汇编 → cc → 可执行 → 运行；查找链 KERF_QBE → 安装布局 → 编译期锚；纯函数注入式 env——并行测试零竞态）
- **CLI 13 子命令**（11 → +2）：`kerf anf <file>`（IR 摘要 dump）/ `kerf native <file>`（AOT 编译 + 运行——产物三路径打印 + exit code 口径）
- **端到端实测**：`(fib 12)` ⇒ **本地码 exit 144**（= VM 路径 ⇒ 144 双路径一致）；IL 结构断言（csltl/call $fib/sub/add/jnz/export main 全命中）；值上下文 if 经 phi 合并（`(- (if (< 1 2) 10 20) 5)` ⇒ 5）；嵌套 if 组合（classify ± / 111/144）——**PoC 边界 B1 登记（TD-024）**：整数域原语十二项 + 递归调用；闭包/Float/Str/Pair/set!/module/print·IO/函数值一等均显式边界外错误（非静默降级）
- **测试 +40 集成**（qbe_backend_tests：端到端 6 + 结构 4 + 一致性采样 6 + 负例 10 + 契约 2）+ **+9 单元**（backend crate）——585 中间基线全绿

### 交付二：G3 FFI 所有权模型定义（§21.3 阻塞项解除——子代理 ARCH-A/ALG-A 交付）

- `stage-2/ffi-ownership-model.md`（216 行）：三原语责任矩阵 3/3（CallExternal 借用窗口 + CInt/CPointer/Opaque 归属三分法 / AllocExternal 线性所有权 / FreeExternal 消费释放）+ **pin/unpin 形式化**（Φ 计数簿扩展 σ=(H,R,Φ) + P1/P2/U1/U2 归约 + 引理 F-PIN + mark_all 起点快照并入——主循环零改动）+ **线性令牌语义**（可重复借用传递 + 一次性消费全局生效；失效 E9 诊断而非 UB）+ ExternalPointer 状态机（非法迁移 7 条 E9-E11）+ 边界 case 13 个全判定 + 决策记录 19 条（新裁定 12 项显式标注）+ 实现路线（G1 PoC 整数路径不触及 pin；批次 I write_stdout 借用路径做实）+ Stage 3 锚点 6 项
- 回写义务 4 处登记（06 §3 E9-E11 / 05 §3.1 Foreign / 13 §3.3.4 行为规格引用 / TD-010）——落地轮执行

### 交付三：G2 HM 推断设计轮（子代理 ALG-A/ARCH-A 交付——GO 有条件）

- `stage-2/hm-inference-design.md`（303 行）：R1-R8 逐条行号锚盘点（8 规则 + 8 架构事实）+ 11 项核心裁定（**约束三段式算法**（否决 W/J——TD-013 多错误协同 + TD-022 栈安全）/ 值限制 OCaml 式 / set! join / letrec fresh 预置双形状特判 / occurs check / TcType→HM 十一构造子映射 / 双点泛化 / 诊断集成 / 三阶段演进轨道）+ 16 参照对照 6 行 + 冲突 7 项（P0×3：letrec nil 预绑定 / 保守契约重定义 / 数值塔格合一偏差）+ 风险 P0×3/P1×3/P2×3/P3×1 全附缓解
- **裁定**：GO（有条件）——PoC 排批次 H 新增 MUV（H4），默认期早于 I1 自举迁移（推断器本体 kerf 化前置）

### 交付四：TD-013 多错误收集与恢复展开实现（P2 清偿——r7 设计验收 5 条全过）

- **种子路径**（kerf-expander `recover.rs`）：DiagCollector（push / is_full(128) / mark_truncated / into_sorted——(file_id,start,end) 稳定排序）+ expand_program_recover（形式级恢复：错形式收集跳过继续；满即显式截断 + 提前终止——38-e 勘误：break 路径须显式置位）
- **自举桥路径**（bootstrap_expander `expand_program_recover`）：逐形式单元素列表调用（expander.krf 协议零改动——调用粒度桥侧切换）；双路径同构测试（诊断数/产物数/错误消息族一致——parity 纪律）
- **driver 消费面**：`check_source_recover`（front_from_core 抽段重构——R9 fail-closed + 簿记 + 字节码共享段单一实现）——E0002（展开）+ E0005（类型）**全量合并报告** + 位置序 + 截断尾注；**CLI `kerf check` 切换恢复模式**（单错误短路保留库 API check_source——run/eval 执行路径不变，r7 设计 §5）
- **实测**：`(define x 1) () (define y 2) y` → 1×E0002 + **y 完整进编译产物**（指令数 = 无错对照一致——r7 验收 1 兑现）+ 混合诊断 E0002/E0005 同报位置序 + >128 截断提示 + read/E0006 短路边界维持 + **16 集成测试全过**

### 交付五：质量口径与收尾

- **§3.2 六命令实跑全绿**（clean 起步：build --release 11.52s 零告警 / check 0/0 / fmt 0 diff / clippy -D 0 / **test --release --workspace 605:0:0**（28s））；双审计集 EXIT 0；CLI 冒烟：VM run fib ⇒ 144 / **native fib exit 144** / test 2/2
- 测试增量对账（553 → **605**，净 +52）：集成 +40（qbe 24 + 恢复 16）+ 单元 +12（backend 9 新 crate + expander +4 recover - reserved codegen 2 迁移 + 兼容锚 1）
- 文档同步：matrix r17 对账 + 登记册（TD-013 **resolved** + TD-024 新增 B1 边界）+ pipeline-test-coverage Stage 2 节 + v0.5-roadmap 批次 G 行 + stage-2/plan Status 更新 + lang-design 13 §3.3.7 迁移注记 + 10-toolchain CLI 13 子命令
- r17 tar.gz（§19.4 整目录含 tools/qbe + 包内自举验证 605:0:0 + CLI 一致）+ web 同步 + E2E + git commit

### 下一步（批次 H：语义演进评估轮）

H1 8 原语迁移五项评估（§13.2 + 委员会投票）∥ H2 TCO 决策 + TD-007 Rc 化（10_000 口径）+ TD-017/TD-022 裁定 ∥ H3 Effect 语言级设计 ∥ **H4 HM 推断 PoC（38-d 裁定新增——三阶段轨道第一段）**；I 批次（编译器本体 kerf ~80% 迁移 + 两次一致 + stdlib 完整化 + TD-008/023）。

---

## v0.3.0-r16（2026-09-11）——批次 F：Stage 1 深审收尾环（§14 阶段末全协议 + §14.6 阶段间验证 GO + TD-023 登记 + lang-design v6.2）

### 交付一：§14.5 D1-D8 深度审查（deep-review-round1.md + 委员会投票 GO-WITH-CONDITIONS）

- **P0/P1 = 0**；P2×2（TD-023 gc_stress 回归新登记 + 登记册目标时机过期家族）；P3×9；**无系统性 B3「实现违反设计」**——全部偏差为「实现前进、文档滞后」方向
- 偏差清单 17 项（子代理 36-a-facts 独立扫描 20 篇 lang-design + 主代理亲验五项抽查全中）+ 无偏差确认 12 组（40 操作码/52 内置/parity 36/28/预留 14 项等核心契约面全对上）
- §6.3 批次 F 批准补票（stage-2/plan「规划批准中」悬空项）：五角色加权 5.5/5.5 = 100%
- §3.2 基线 clean 全量复验：build 9.86s 零告警 / check 0/0 / fmt 0 diff / clippy 0 / **553:0:0**（25s）+ CLI 冒烟

### 交付二：§14.8 设计回写（lang-design v6.1→v6.2 十篇 + 登记册 v0.3.0-r16）

- **TD-002 符号值家族三篇**：05（HeapObj 七变体/八入口/三通道函数/TD-023 注记）、06（值域十变体 + 语义字段限定）、01（literal_value + Symbol）
- **批次 E 滞后四面**：09（TD-021 r15 解决注记）、11（553 口径）、07（471 行 + 全模式面限定）、03（ExpandCtxt 四字段）
- **12-roadmap 两行矩阵改写**：元循环求值器（保持 Rust 参考，eval 自举滑入 Stage 2）/ 宏系统（E1-β 收口 ✅，调试工具 Stage 2+）；10-toolchain 补 CLI 11 子命令清单（B4 收口）
- **登记册全量对账**：索引补全 23 行（TD-015+ 此前无索引行的结构性缺口修复）+ TD-012 resolved（批次 B 六文件实证）+ TD-013/009/010/014/017/018 改判 Stage 2（附门放行裁定）+ TD-019/020 断档登记（禁复用）+ **TD-023 新增（P2——绑定批次 I2）**

### 交付三：§14.6 阶段间深度验证（六篇 + 自举 vs 种子前段实测）

- **architecture-review**（32✅/3⚠️/0❌——Stage 0 ⚠️×4 收敛 2）/**design-impl-test-coverage**（B1 全登记零未登记缺口 + 三者不一致零项）/**hidden-problems-assessment**（复杂度 ≥2× 强制修复触发 0 项）/**refactoring-optimality-review**（7 重构 7 优 0 hack）/**performance-baseline**/**final-assessment**（GO + 门审 checklist 增补：登记册核对 + 对账面六面清单）
- **自举 vs 种子前段开销实测**（§21.5 信号 4 补录）：**比值 69×（fib）/157×（宏）/116×/388×（300-defines）** + 冷启动 16.1ms + fib bench 89.4~89.6ms（**自举切换零性能代价 +0.8% 噪声带**）——**stage-2 DAG 的 H2→I1 次序被实测验证**（TCO 是编译器本体迁移的实质前置）
- **gc_stress 回归**（+29~46% 超线性，超 §14.6.4 10% 阈值）：TD-023 登记（per-cycle HashSet 分配 + Value 宽度候选根因）→ 批次 I2（TD-008 分代同轮）；正确性无影响不阻塞
- pipeline-test-coverage.md 全量重写（294→553 口径 + Stage 1 套件 11 行 + parity 印证节 + catch-all 42→1 通配实测）

### 交付四：§14.9 C1-C6 代码整理（零语义变化）

- 三处注释级修正（driver.rs 切换守护方向反写 / kerf-runtime「四类根」→五来源 / 堆语义注释过时）——**553 零断言修改逐一等价复跑实证**（探针临时部署/移除各一次全绿）
- C1-C6 全维检查：TODO/FIXME 0、glob 0、//! 66/66、§11 五项合规、真通配 catch-all 1 处（带臂级注释）

### 交付五：质量口径与收尾

- **§3.2 六命令实跑全绿**（clean 420 files → build 9.86s → check 0/0 → fmt 0 diff → clippy -D 0 → test **553:0:0**）；双审计集 EXIT 0（41 + 50）；探针移除后全量复验 553:0:0
- 文档同步：v0.5-roadmap Stage 1 行 ✅ + matrix r16 对账（表体两行尾差修复）+ stage-1/plan 批次 F 注记 + stage-2/plan TD 绑定行（G2←TD-013 / I2←TD-023 / H2←TD-017）
- r16 tar.gz（§19.4 整目录 + 包内自举验证 553:0:0 + CLI 一致）+ web 同步 + E2E + git commit（r13-r16 积欠统一入账 per §6.4）

### 下一步（Stage 2 主体——批次 G 起）

G3 FFI 所有权模型定义（§21.3 阻塞项先行）→ G1 QBE 后端 PoC（QBE 二进制按 §3.1 链位安装）∥ G2 HM 推断设计轮（+ TD-013 多错误恢复绑定）；H2（TCO + TD-007 + TD-022 + TD-017——**I1 实质前置，性能基线实测锚定**）；I2（TD-008 分代 + TD-023 根扫描对症）。

---

## v0.3.0-r15（2026-09-11）——批次 E 收口：E1-β 宏系统 + 生产切换 + TD-021 prelude + Stage 1 门审查 APPROVED（553 全绿）

### 交付一：E1-β 宏收口——expander.krf 完整宏系统（syntax-rules 卫生宏，VM 上运行）

- **宏机制**（expander.krf +~470 行）：define-syntax 注册（变换器注册表 = 名字单表——用户宏 'rules / 糖惰性注册 'builtin，HashMap 替换语义镜像：用户宏可覆盖糖名）+ syntax-rules 解析（字面量集合/子句 (模式 模板)/五类解析错误逐字镜像）+ **模式匹配**（通配 `_`/字面量（同名 sym）/省略号（零/多段/复合单层）/字面量 datum 值相等/嵌套列表/向量 `[...]`——trial 语义经函数式绑定传递）+ **模板实例化**（模式变量替换保留用户 Span/作用域、(var ...) 省略号拼接跳格、悬垂省略号按普通符号走实例化——报错优于静默）+ **卫生 α 重命名**（`name$hyg$N`——num->str 递归构造；同标识符同实例化恒同映射；保留集（宏自引用）+ 核心关键字豁免）+ **深度计数 500**（链长语义——expand-form 入口快照/出口回滚，兄弟不累计；超限结构化报错非栈溢出）+ retag def∪use 并集 + 卫生基名回退（rsplit $hyg$ + 后缀纯数字保守校验）
- **Span 并集代次守卫镜像**（实测驱动的发现——parity 失败暴露）：节点形状升 v2 = `(tag s e exp scopes ...)`（exp = Span.expansion_id，桥侧发射/读回）；**instantiate 的 Span 并集须镜像 Span::merge 保守策略——代次不同 → 丢弃该跨距**（糖产物内宏调用：use-site 代次 ≥1 vs 模板 0 → 产物 Span 落模板范围）；retag 代次 +1（bumped_expansion）；全部构造器（糖/提升/宏）逐位镜像代次来源
- **核心节点携带代次**（生产切换的相位可观测性保持）：core 节点 `(tag s e exp ...)` → 桥重建 `Span{expansion_id}`——「宏引入引用未绑定错误应携带 expansion N 标记」（E3 诊断特性）经切换后保持
- **实测驱动修复**（§2.3-11——全部经 parity 双实现实跑发现）：foldl/for-each 序章补定义（chars->str→foldl 此前为死代码——卫生基名回退首次激活）+ 宏产物品类 6 处（let 括号/字面量 tag 铸造/letrec 先用后绑/...的 r14 既有 + E1-β 新发现：set/require/define-syntax 代次字段漏挂×3、模块注册簿错误无 Span 无渲染×2）

### 交付二：生产切换（E1-β——读 + 展开两段全自举）

- **compile_front 展开段** → `bootstrap_expander::expand_program`（VM 上 expander.krf）——**「语言能表达自身前端」的完整生产命题**；Rust 种子保留双角色：自举引导（reader.krf/expander.krf/preamble.krf 的编译经 compile_front_seed）+ parity oracle（测试对照）
- **切换守护**：driver 单元 `production_expander_is_bootstrap`——独立线程（thread_local 零残留）编译前活性探针 `is_loaded()` = false → 编译后 = true（实测判别非推断）+ 宏产物展开代次标记 ≥1 双信号
- **553:0:0**（528 基线零回归——全套件经自举 Reader + 自举 Expander 生产管线执行）

### 交付三：TD-021 高阶函数用户面注入（P3 清偿——模块/import 承载）

- **kerf-prelude 模块**（`bootstrap/preamble.krf`）：map/filter/foldl/for-each（reader.krf 序章同源）；用户程序 `(module 名 (import kerf-prelude) ...)` 声明导入
- **注入机制**（P1/P3/P5 三否决全规避）：read 后、expand 前 forms 级合并（独立 file_id——Span 指向 preamble.krf，无源码拼接诊断污染）；单一编译单元（无跨程序全局合并）；零 VM 再入；**多模块按序 declare + 主模块 visit**（§8.9 单模块生命周期扩展——import 边传递依赖）；同名 define 显式报「重复定义」（不静默遮蔽）；无 import 声明保持未绑定（opt-in 语义）
- **prelude_tests 7 case**：用户面可见/组合管道（filter→map→foldl = 50）/for-each 副作用/双路径一致/opt-in 负例/名字捕获显式失败/未知导入

### 交付四：Stage 1 门审查（§7.3 + §21.3 四条验收——APPROVED）

- **审计集** `examples/audit/stage1_gate_audit_r1.rs`（50 case，可重运行）：§7.3.1 配比满足（A 单语句 12 / B 多语句 12 / C 复杂 10 / D 恢复 6 / E 边界 6 / P 正向 4）+ §7.1.1 **七类全覆盖**（语法/未绑定/空应用/参数个数/类型不匹配/循环依赖（双模块源码 → DFS 灰标记结构化 Err）/宏深度（自指宏经生产路径））+ §7.3.2 边界 6（本批次修复面：Span 代次守卫糖内宏/require·set 代次/prelude/模块内宏注册）——全部 case 经**生产管线**（自举读+展开）
- **审计发现项 2（已修复）**：模块注册簿错误（未声明模块/循环依赖）无 Span 定位 + 无诊断渲染——修复：挂 module 形式 Span + render_diagnostic（P2 诊断质量）
- **§21.3 四条件锚定**：① 子集表达前端——生产管线自举（VM Reader + VM Expander 含宏）② VM 上正确运行——自举 Expander 承载全部生产展开 ③ 标准库最小集——prelude 管道（列表 hofs 用户面）+ stdlib（列表/字符串/I/O）④ 增量编译——P04 缓存确定性 + 第二次 check 命中观测 + 静态检查 0 错
- **结论**：APPROVED（50/50 PASS + 配比满足 + 七类全覆盖 + 零新 P0/P1）——Stage 1 全批次（A/B/C/D/吸收/E）交付闭环，进入 Stage 2 准备

### 交付五：质量口径

- **§3.2 六命令实跑全绿**（clean 起步：498 files/123.6MiB → build 9.39s 零告警 → check 0/0 → fmt 零 diff → clippy -D warnings 0 → test **553:0:0**（单元 184 + 集成 369））；双审计集 EXIT 0（stage0 41 + stage1 50）；CLI 冒烟 fib 75025 + ⇒ 144 + kerf test 2/2 + 宏+prelude 自检 ⇒ 10
- 文档同步：tech-debt-register TD-021 → 已解决（r15）+ matrix 553 对账 + stage-1/plan.md 批次 E 行收口 + bootstrap-expander.md E1-β 增补 + prelude.md + stage1 门审计测试计划

### 下一步（Stage 2 准备——§21 阶段规划先行）

Stage 2 启动条件核对（§7.3.3 收敛裁定 + §21.5 切换信号）→ 阶段规划（§21 + §13.1 设计对齐 + §17 排版图）→ 后端策略裁定（LLVM 可选后端引入评估——永不入自举链边界重申）+ TD-007 残留（10_000 完整口径）与 TD-022（Reader 帧消耗 O(n)）的 TCO 决策点。

---

# RELEASE_NOTES

## v0.1.0 —— Stage 0 语义验证（2026-09-09）

### 交付

- **12（10+2）能力模型全量落地**（P0/P1）：
  类型化 Token Reader / 图 IR（共享节点）/ 结构化 CodeValue /
  元循环求值器 / 基础闭包（共享单元格捕获）/ Span 全管线 /
  结构化诊断 / 最小 I/O / 相位分离 / 卫生宏（syntax-rules）/
  标记-清除 GC / 字节码 VM（39 操作码）
- **四项接口预留冻结**（P2/P3）：Effect Handlers / 多阶段编程 /
  能力模型 I/O / 编译缓存
- **9 crates Cargo Workspace**（零外部依赖）+ CLI（10 子命令）
- **200 项测试全绿**；§3.2 验收全绿（build/check/test/fmt/clippy）
- **文档**：lang-design 20 篇（stage0.md v5.0 拆分）+ develop/tests/graph 树

### 语义验证亮点

- fib(25) = 75025（VM 与 eval 双路径一致）
- 卫生宏：宏内外同名不串扰（一致性 α 重命名 + 自引用保留 + 关键字保留）
- letrec 互递归 / 闭包可变捕获（独立计数器）/ 深递归 10^4（迭代式帧栈）
- GC：3×10^5 临时分配堆有界；环回收；2×10^5 深链标记不爆栈

### 已知边界

TD-002~TD-011（P2/P3，显式推迟）——见
docs/develop/v0/tech-debt-register.md。无 P0/P1 遗留。

### 基准

- fib(25)（含编译）：84.7 ms/轮（release）
- GC 压力：0.72 s / 3×10^5 分配

### 下一步

Stage 1（自举验证）：目标语言子集重写编译器前端 + 类型检查器。

---

## v0.1.0-r2 —— lang-design v5.1 收敛 + 双路径语义分裂修复（2026-09-10）

### lang-design v5.1（设计文档收敛审查）

- **06-操作语义从 21 行空壳重写**（~200 行）：9 原语小步归约规则组 R1–R9
  （含 βv/δ 辅助规则）+ 错误吸收语义 E0–E8 + GC 不可观测性引理 L-GC +
  编译正确性定理 T1（L1–L4 三引理证明纲要 + 适用边界）——补齐
  stage0.md §13.4 的源文档理论欠账
- **03-宏系统 / 05-运行时契约回填**（从冻结实现）：
  Transformer/TransformerKind/ExpandCtxt/ModuleRegistry/syntax-rules 文法；
  Heap/GcRef/Slot/RootSet/I-O 通道契约
- 01–05/09–11 统一增补「处理程度（P0–P4）/所属 Stage/推迟项」标注 +
  「测试锚点」节（设计驱动测试锚定）；02 职责矛盾调和（词法层 vs
  Reader 模块）；04 操作码漂移注记 + CodeBuf/CaptureSource 契约；
  断链修正（19-参考文献 §3.5/§3.6）×3；术语计数 42；全库 0 断链

### 双路径语义分裂修复（依据 06 定理 T1 审查发现，CLI 实证三组反例）

- **新增第 40 号冻结契约 `DefineGlobal`**：define 与 set! 的全局存储
  语义分裂修复——`StoreGlobal` 收紧为 S1/E3（未绑定报错）；
  `DefineGlobal` 承载 D1/E6（同层重复定义报错）
- **Define 返回值统一**（T1 反例）：编译模式改为 `value; DUP;
  DefineGlobal`，与 eval 路径一致（此前 VM 返回 nil）
- **lambda 形参表重名展开期拒绝**（A3 卫式，两路径共同上游）
- 修正 2 处依赖旧错误语义的测试断言（去除兼容思维）
- **204 项测试全绿**（200 基线 + 4 组新语义双路径对账）；
  §3.2 验收全绿（build/check/test/fmt/clippy 零警告）

### 交付包

kerf-stage0-v0.1.0-stage0.1-12-caps-langdesign-v5.1-semantics-r2.tar.gz
（312 KB / 165 文件；包内解压自举验证 204 测试全绿）

---

## v0.1.0-r3 —— deep-review R1 修复 + 负测扩张 + 门审计集（2026-09-10）

### 深度审查修复（P1×4 清零）

- **App 求值顺序统一「函数先」**（偏差 #13，T1 反例面）：compile.rs/vm.rs 双侧对齐
  06 §1.3/§2 A1 契约；双路径错误排序负例回归（app_evaluates_fn_then_args /
  app_evaluation_order_fn_first_dual_path）
- **操作码冻结守护测试重写**（偏差 #7）：40 项显式枚举（八组：栈 7/变量访问 7/控制流 2/
  函数 3/算术比较 12/数据 3/谓词 5/终止 1）——enum ↔ 测试 ↔ 文档三方冻结
- **模块循环依赖检测**：phase.rs DFS 灰标记 → 结构化 Err「模块循环依赖：…」
  （菱形依赖合法；§7.1.1 类 6 补齐）
- **§7.3.1 门审计集就位**：examples/audit/stage0_gate_audit_r1.rs——41 case
  （负向 32 + 恢复 6 + 正向 3），§7.1.1 七类全覆盖；r1 的 gate PASS 判定缺陷闭环
- **驱动修复**：VM 堆栈追踪（run_program 最内 16 帧 note）；eval 路径卫生回退接线
  （与 VM 路径镜像，T1）；driver 公共 API dump_tokens/dump_stx（CLI 经 driver 转发，
  §14.7.2 B4 合规）

### 负向测试扩张（§9.4.3 1:3 门限达标）

- 四个表格驱动负测文件：negative_reader（60 case）/negative_expander（98）/
  negative_vm（231）/negative_semantics（100+）≈ **490 case**（r1 基线 37）

### T17-a 对抗深挖修复批（r3 末轮——§14.6.3 独立深挖发现）

- **D1** 函数体内 begin 包裹 define 全局泄漏（VM）vs 词法（eval）——T1 反例：
  编译期结构化拒绝（E0003，两路径共享 compile_source 双侧一致）
- **D2** `eq?` 字符串指针比较 → 内容比较（VM 常量池去重路径与 eval 分裂）
- **D3** eval 深递归栈溢出 abort → MAX_EVAL_DEPTH=256 结构化上限（实测标定）
- **D4** `i64::MIN /± -1` Rust panic → checked_div/rem 结构化错误
- **D5/D9** `(+)` 越界 panic → 单位元 0；`(*)` → 1；`(- x)` → 取负
- **D6** 宏调宏未绑定 → 展开器基名回退（卫生穿透落地）
- **D7** eval 错误逐层「求值失败：」前缀累积 + Span 丢失 → 保真透传
- FS-1 Reader 嵌套守卫失效（600 层即溢出）→ MAX_NESTING_DEPTH=256
- 全局正负比 1:0.24 → **≈1:3.2**（负 515 vs 正 ~160，case 口径）；
  E1–E6 + E0001/E0002/E0004 直接断言矩阵；E7/E8/E0003 不可触发性文档化存档
- **297 项测试全绿**（298 函数，0 失败 / 1 忽略-文档化）；§3.2 验收全绿（release）

### 工程整理

- examples/ 重组：usage/（6 个 .krf）+ audit/（审计集）+ README 索引（§9.6.2）
- lang-design v5.2：deep-review §6 偏差清单 26 项全量回写（操作码全枚举/HeapObj 六变体/
  根集五来源/GC 数值冻结/内置 24 项清单/reserved.rs 签名回填/7 层→9 crate 映射表等）
- 工程文档对账：matrix / pipeline-test-coverage（§9.5.1 三层 + §14.6.1.1 完整性）/
  negative-tests.md 新建 / TD-012~014 登记

### 基准

- fib(25)（含编译）：84.4 ms/轮（release，复现声称 84.7）
- GC 压力：3×10^5 分配单轮 ~0.17 s（更正 0.72s 陈旧口径；gc_tests 10^6 为验收权威口径）

### 下一步

Gate R2 门审查复审（审计集就位后按 §7.3 重跑）→ §6.3 外循环投票 → Stage 1 规划输入。

## v0.1.0-r4（2026-09-10）——Stage 1 批次 A：切换期重构 + 第一批工作项

**SOP 流程**：Stage 1 启动（§21 规划 → §17 排版图 → §18 依赖审查 → §13.1 设计对齐 → §4 MUV 批次 A）。

### 交付（3 MUV + 1 重排）

- **TD-015 已解决**：`compile_source` 按消费方分流——run/eval 生产路径改走
  `compile_front` 前段（不构造图 IR）；完整入口保留给 `ir`/`code`/`bc`/`check`
  dump 与检查子命令；分流守护测试（快路径与完整编译字节码逐指令一致）。
- **TD-012 已解决**：expander.rs 1372 → 517 行（-62%）——三职责分置
  （core_forms.rs 511 / sugar.rs 426，crate 私有模块，公共 API 零变化）；
  测试整体保留主控走公共入口（拆分等价性天然回归）。
- **TD-007 部分解决**：宏展开 trampoline 工作表（宏产物头部仍是宏调用时
  迭代继续，展开控制流栈深与链长解耦）；深度上限 128 → **500**（实测
  标定：2MiB 测试线程 1_000 通过/2_000 溢出，2× 裕度——TD-017 同型
  实测法；探针 example 双环境数据记录于 TD 登记）；完整 10_000 口径
  依赖 Stx Rc 化（批次 B 前端重写）。
- **TD-004 重排批次 B**：完整实现 = 绑定 scope 注入 + CoreExpr::VarRef
  scope 桥 + 双路径解析体系切换（≥800 LOC 跨 5 crate）——超出单 MUV
  容量，与 TD-002/标准库同批（依据 §1.2.1 只升不降 + §12 最优>最小）。

### 质量口径

- §3.2 全绿：build --release 0 警告 / check --all-targets 0/0 /
  fmt 零 diff / clippy -D warnings 零警告 / test --release **304:0:1**
- 审计集 41/41 复跑 EXIT 0；新增集成套件 expansion_worklist_tests（4 例）
- SOP 文件更名：`stage-committee-process.md` → `sop.md`（引用同步 3 处）
- worklog Task 18-21 全记录；lang-design 03-macro-system TD-007 注记回写

## v0.1.0-r5（2026-09-10）——Stage 1 批次 B：TD-002 符号值 + 标准库最小集

**SOP 流程**：批次 B 按 plan.md §5 序列推进；MUV 22-a（TD-002）与
MUV 22-c（标准库最小集）各走完整内循环（22-b TD-004 按重排裁定留批次 E 收口批次整体推进）。

### 交付（2 MUV）

- **TD-002 符号部分已解决**：`(quote sym)` / `'sym` → 符号值——全链落地：
  - `LiteralValue::Symbol(Rc<str>)`（kerf-core；存剥离卫生后缀的基名，
    Racket 语义近似——与 resolve_hygiene_fallbacks 同一 $hyg$ 剥离口径）
  - `Value::Symbol`（kerf-vm）+ eq? 按名相等 + type_name "symbol"
    + render（裸名）/ 序对渲染（slot_terminal/render_slot）
  - `BcConst::SymLit`（kerf-compiler 常量池；与全局名索引 `Symbol`
    变体语义严格区分——§11 接口隔离）
  - `HeapObj::Symbol` / `ValueSlot::Symbol` / `Heap::alloc_symbol`
    （kerf-runtime；符号入序对 + car/cdr 往返）
  - 双路径同步：VM `const_to_value` 与 eval `eval_literal`；
    宏模板内 quote 符号卫生后缀 datum 层剥离（实测验证）
- **向量 datum 仍显式报错**（TD-002 向量部分开放，后续阶段）

### 质量口径

- §3.2 全绿：build --release 0 警告 / fmt 零 diff / clippy -D warnings
  零警告 / test --release **324:0:1**（304 基线 + 20：TD-002 5 +
  stdlib 15）/ 审计集 41/41 复跑 EXIT 0
- 负向锚点迁移：符号 datum 报错负例 → 符号值语义负例（negative_vm
  symbol_value_misuse 6 case 实跑校准：算术/条件/序对/比较位置）；
  全局正负比 1:3.1 维持（stdlib 负例 172 case 三维矩阵）

### 追加交付（MUV 22-c：标准库最小集）

- **24 项新内置函数**（48 项总量；07 §3.3 阶段门条件 3：列表/字符串/I/O
  各 ≥8——driver `register_globals` 注册，语言核心零内置原则不变）：
  - 列表操作（8）：`length`/`append`/`reverse`/`list-ref`/`list-tail`/
    `member`/`assoc`/`last-pair`——堆序对链遍历，nil 终结契约；
    `member`/`assoc` 按 `eq?` 查找
  - 字符串处理（10）：`str-length`/`str-substring`/`str-index-of`/
    `str-contains?`/`str-prefix?`/`str-suffix?`/`str-upcase`/
    `str-downcase`/`string->symbol`/`symbol->string`——字符索引
    Unicode 安全（`str-length "héllo"` = 5）；符号互转联动 TD-002
  - 基本 I/O（6）：`newline`/`write-string`（通道层 `write_stdout` 新增）/
    `read-int`/`read-num`（行解析，失败结构化报错）`/`error`/`assert-eq?`
- **高阶函数（map/filter/foldl/for-each）显式推迟 B3**：用 kerf 源码
  preamble 实现是 B3「Reader kerf 重写」的自举验证命题本体（§12
  最优>最小：Rust 抢实现移除 B3 验证内容；源码拼接方案的 Span 污染
  为真实 P1 缺陷，worklog 22-c 记录裁定依据）
- **修复伴随缺陷 2 项**（std 函数实跑发现）：`list`/`reverse` 空参
  曾返回 `(nil)` 包装形态（堆 nil 槽包成序对）——改 nil 值形态与 `'()`
  一致；`list-tail` k=0 曾对非 list 输入静默返回（Racket contract
  严格语义：每步形态校验）
- 测试：stdlib_tests 15 函数（正例 59 断言 + 负例 172 case——元数/
  类型/边界三维矩阵 + 类型全扫描）；全局正负比 1:3.1 维持

### 文档回写（合并）

- 09-stdlib v5.3（48 项清单 + 高阶函数 B3 推迟注记）/ capability-
  boundaries（48 内置）/ matrix 324 对账（stdlib 15 函数 172 负 case）/
  status r5 / tests/v0/stage1/plan.md + plan/stdlib.md 新建

## v0.1.0-r6（2026-09-10）——Stage 1 批次 B 收官：B3 自举 Reader（Reader kerf 重写）

**SOP 流程**：批次 B 收官按 plan.md §5 序列（Task 23 尾注）；MUV 24-a
（VM 宿主调用 API）→ 24-b（reader.krf + 桥 + 生产读路径切换）→ 24-c
（parity 套件）→ 24-d（交付闭环）各走完整内循环。

### 交付（B3：Reader 以 kerf 源码重写，在 Stage 0 VM 上运行）

- **reader.krf**（`kerf-driver/src/bootstrap/reader.krf`，~430 行 kerf 源码）：
  完整词法 + 语法逻辑——`lex-src` / `parse-tokz` 两入口（与种子
  `lex_source`/`parse_tokens` 接口形状对齐，§11）；尾调用链形态的错误
  传播（err 标签值返回，不依赖异常）；高阶函数序章（map/filter/foldl/
  for-each 以 kerf 源码实现——r5 裁定「自举验证命题本体」的交付面）
- **VM 宿主调用 API**（24-a）：`kerf_vm::call_closure`——函数入口帧语义
  （底帧 RET = 程序化返回值）；跨程序闭包显式拒绝（P3 否决的运行时面）；
  错误追踪与 run_program 同构
- **自举桥**（`kerf-driver/src/bootstrap.rs`）：种子管线编译 reader.krf
  （thread_local 惰性加载，无递归）+ 值树 ↔ Token/Stx 转换 + 数字文本
  同源 parse（i64/f64 转换是宿主类型边界）+ 持久堆（GC 根集含全局）
- **生产读路径切换**：`compile_front`（run/eval/compile_source 全管线）
  与 `dump_tokens`/`dump_stx` 经自举 Reader；种子（kerf-reader）保留为
  引导实现 + parity oracle（`compile_front_seed`）
- **+4 自举 Reader 原语**（52 项总量）：`str->pos-chars`（(字节偏移 .
  单字符) 列表）/ `char-whitespace?` / `char-alphabetic?`（Unicode 属性）/
  `str-int-valid?`（i64 域——扫描序内溢出前置校验，维持首错位置 parity）
- **错误次序契约**：数字溢出在 VM 词法扫描序内前置报错（与种子一致）；
  数字文本最终转换桥侧同源 parse（消息与 Span 逐字节一致）

### parity 验收（bootstrap_reader_tests：28 函数，正 87 / 负 307 case）

- **Stx 树等价**：datum + Span 递归比对（符号按名——两实现 intern 次序
  不保证一致）；语料 = 种子 reader 测试全集 + 奇异边界（省略号族/
  多行字符串/科学计数法/前导零/Unicode 标识符/NFC 组合归一）
- **错误 parity**：消息 + Span 逐字节（28 负例语料 + 系统化矩阵 266：
  未闭合深度 1..30 / 括号错配矩阵 / 非法转义 32 字符（含多字节——
  种子 eo+1 字节口径逐字节复刻）/ 贪婪数字 10×5 矩阵 / 溢出扫描
  19..26 位 × 3 符号 / 非法字符 8×3 上下文 / 双错误次序 / 注释嵌套）
- **双错误次序**：溢出 + 后置词法错误（首错 = 溢出）与前置错误反向——
  两实现首错位置逐字节一致
- **高阶函数直测**：map/filter/foldl/for-each 经自举桥（builtin 作 f——
  跨程序安全的函数值）
- **防误收断言**：全部负例先断言种子确实报错（`assert_negative_parity`）

### 质量口径

- §3.2 全绿：build --release 0 警告 / fmt 零 diff / clippy -D warnings
  零警告 / test --release **356:0:1**（324 基线 + 32：VM call_closure 4 +
  parity 28）/ 审计集 41/41 复跑 EXIT 0
- **356 全套件（含全部既有负向消息断言）经自举 Reader 执行**——整体
  行为等价的实证（孤立正确 → 集成正确的 §7 防崩验证）
- 全局正负比 **≈1:3.2**（负 1000 case / 正 ≈311；§9.4.3 门限维持）

### 技术债登记

- TD-021（P3）：高阶函数用户面注入缺载体（P1/P3/P5 否决——批次 E 模块系统）
- TD-022（P3）：自举 Reader 帧消耗 O(源字符数)（无 TCO 边界——Stage 2 决策点）

### 文档同步

07-bootstrap v5.3（§3.2 B3 交付注记）/ 09-stdlib v5.4（4 原语 + hof
注记）/ 02-syntax-model（B3 双实现注记）/ stage-1 plan §5（B3 ✅）/
matrix r6 对账 / tests/v0/stage1/plan.md（parity 套件行）/ status r6 /
data-flow（自举 Reader 读路径）

## v0.1.0-r7（2026-09-10）——Stage 1 批次 C：类型检查器 + 编译缓存 + TD-016/013

**SOP 流程**：批次 C 按 plan.md §5 序列（Task 24-d 尾注——批次 B
收官后承接）；MUV 25-a（类型检查器本体）→ 25-b（编译缓存）→ 25-c
（TD-016 收紧 + check CLI）→ 25-d（TD-013 设计批）→ 25-e（交付闭环）。
L3 全量内循环（跨 kerf-compiler/kerf-driver/kerf-syntax/CLI/web 五面）。

### 交付一：保守静态类型检查器（25-a——§21.6 循环依赖缓解落地）

- **kerf-compiler/src/typecheck.rs**：`check_program(core, builtin_sigs, table)`
  → `Vec<Diagnostic>`（E0005）。**保守性契约**：只报告静态确定的错误——
  每条规则触发时对应程序运行期必然以同类错误失败；动态信息不足一律
  Unknown 跳过（误报 = P1 缺陷的工程口径）
- **R1-R8 规则集**：if 条件非 bool / 算术非数值 / 比较族（TD-016
  全操作数口径 + TD-011 字符串边界）/ not / car-cdr 非序对 / 不可调用
  值 / 元数（字面量 lambda + 内置签名）/ 字符串符号族
- **内置签名表注入**（§2.3-10 唯一可信源）：builtins.rs 的
  BUILTIN_SIGS（49 项）与 register_globals 同文件维护——签名表 ⊆
  注册表双向防漂移锚（`builtin_sigs_subset_of_registered` /
  `builtin_sigs_cover_operator_families`）
- **多错误收集**：全量诊断按 Span 次序（TD-013 设计的首个实证消费面）
- **深度预算** MAX_CHECK_DEPTH=512（Reader 256 上限 2×；debug 帧实测
  ~1 KiB，2000 深度实测溢出 2 MiB 栈——程序化构造单测存档）
- **消费面**：`kerf check` 子命令（编译 + 静态报告 + 缓存观测，发现
  问题 exit 1）+ `check_source` 库 API + web /api/check

### 交付二：编译缓存（25-b——13 §3.1.4 三方法规格做实，§21.3 条件 4）

- **InMemoryCompilationCache**（kerf-driver/src/cache.rs）：冻结 trait
  `get_cached`/`store`/`invalidate` 行为规格 1/2/3 逐条测试锁定 +
  管线富入口（`lookup_front`/`store_front`——完整前端输出含符号表/
  源映射/模块簿记；快照语义克隆）
- **SHA-256 内容寻址**（hash.rs 零外部依赖自实现，FIPS 180-4；NIST
  标准向量锚定）：`CacheKey{source_hash 截断 u64, config_fingerprint
  = 阶段种子 + 文件名}`（位置信息入指纹——SourceMap 产物等价性要求）
- **管线接线**：run/eval/compile/check 经 `compile_front_cached`
  （同源二次命中——eval 共享 run 条目；错误路径不缓存；`cache_stats`
  观测 + `set_cache_enabled` 基准对照开关）
- **确定性证明**：`cached_program_equals_fresh_compile`——命中产物 ==
  新编译产物（BcProgram PartialEq 逐字段）

### 交付三：TD-016 收紧（25-c——链式比较全操作数前置校验，双侧）

- 运行时面：`cmp_builtin` 前置全参数数值校验（全字符串+排序族 →
  TD-011 消息；其余首个非数值 → `{op} 需要数值`；**既有两参消息
  逐条兼容**——负例矩阵全绿回归）
- 静态面：R3 规则同口径（Ordering / NumOrAllStr）
- 语义收敛：`(< 3 1 "a")` 静默 false → 结构化错误（FS-5 边界闭环）；
  `(= 1 2 "s")` 同理；`(< "a" "b" 1)` 混串消息统一为「需要数值」
- 09-stdlib §2 v5.5 重写 + negative_vm_tests 语义边界注记更新

### 交付四：TD-013 设计批（25-d——多错误收集设计冻结）

- docs/develop/v0/stage-1/multi-error-recovery-design.md：恢复粒度 =
  形式级（表达式级不恢复——半展开状态重建成本）；恢复机制 = 编译期
  控制流（非 effect——§11 接口隔离裁定）；收集上限 128 + 截断提示；
  输出按 Span 次序；实现绑定批次 E（验收标准 5 项）
- 登记册 TD-013 → 设计完成；TD-016 → 已解决（r7）

### 质量口径

- §3.2 全绿：build --release 0 警告 / fmt 零 diff / clippy -D warnings
  零警告 / test --release **408:0:1**（356 基线 + 52：typecheck 24 +
  cache 13 + stdlib TD-016 2 + compiler 单元 3 + builtins 签名 2 +
  cache 单元 6 + hash 单元 2）/ 审计集 41/41 复跑 EXIT 0
- 全局正负比 **≈1:3.2 维持**（负 1077 / 正 ≈340 case；r7 typecheck
  负例 68 全部携带静态确定性反向锚——静态报错程序实跑必报 Run 错）
- **零误报保守性机械验证**：examples/ 6 程序 + 既有 408 全套件零
  新诊断（缓存行为等价 + 检查器保守性双证明）

### 下一步（批次 D，plan §5）

Effect 内部最小实现（编译器错误恢复用）+ 能力 I/O 基础传递
（13 §3.1.3 规格）。

## v0.2.0-r8（2026-09-10）——Stage 1 批次 D：能力 I/O 基础传递 + 内部效应做实 + 用例运行器

### 交付一：Effect Handlers 编译器内部做实（12-roadmap §2.4.3 第二级）

- `kerf-driver/src/effects.rs`（新，414 行）：**类型化一次性逃逸层**
  `handle_escape<R,T>` / `perform_escape<T>`——载荷从任意嵌套深度
  上展开至最近同类型边界，零签名污染（「任意流程节点能力」的机械
  实现）；线程局部深度计数 + `catch_unwind`/`resume_unwind` std-only
  载荷逃逸 + 私有载荷类型判别的 panic hook 过滤（效应控制流零噪声、
  真实 panic 照常穿透——12 单元测试锁定）
- **冻结契约层** `InternalEffectSystem`：reserved.rs `EffectSystem`
  P3 形状的真实现（与 Probe 测试构成「可编译/可承载」契约双证）；
  语言面保持 P3（D1 裁定——语言级 perform/handle 语义留 Stage 2）
- VM 帧 `ext1` 槽位不激活（Stage 2 语言级效应时启用）

### 交付二：能力模型 I/O 基础传递（13 §3.1.3 四条款做实）

- **声明形式 `(require io read|write)`**：`CoreExpr::Require`（零运行时
  语义——求值恒 nil 双路径一致 / 编译产 PushNil / IR 降级 nil 节点）；
  幂等集合语义；核心冻结边界精确化（「语义原语集冻结 + 声明变体可
  追加」——01-core-forms §6）
- **R9 保守静态权限验证**：门控内置名（read-line/read-int/read-num/
  print/newline/write-string）任意位置引用未声明 → **E0006 编译期
  错误**（front 管线 run/eval/check/compile 全路径单一验证点；用户
  接管豁免 + 卫生回退基名判定——零误报纪律）
- **令牌授权面**：`mint_read_token`/`mint_write_token`（pub(crate)
  构造面控制）+ `IoGrant` 按声明铸造 + `StdCapabilityIO`（冻结 trait
  的 stdio 实现）+ `register_globals` 能力参数化（未声明即不注册——
  fail-closed）
- **FS-4 修复**：read-line 元数校验补齐（能力参数化重写时顺带——
  negative_vm_tests 存档断言激活）

### 交付三：用例运行器 `kerf test`（测试面即语言面）

- `test_source` API + CLI `kerf test` 子命令：前置形式（define/set!/
  module/require）逐用例重放 + 顶层表达式 = 用例（值非 #f = PASS）；
  **短路 + 恢复**（效应系统消费面——case 内任意深度失败即停、边界
  捕获后下一 case 续跑）+ 状态隔离（每 case 全新环境与堆）
- 设计文档：[11-testing §4](docs/lang-design/11-testing.md)

### 交付四：文档回写 v5.4（lang-design 七文件 + sop.md v11.1）

- lang-design：00（v5.4 修订记录 + next.md 吸收审计结论）/ 01（§6
  require 声明形式设计）/ 02（Token 叶级 45）/ 09（v5.6 能力门控）/
  11（§4 用例运行器）/ 12（v5.4 演进矩阵状态）/ 13（v5.4 双做实注记）
- sop.md v11.1：§21.9 矩阵现状对账（四项 ✅ + 类型检查器提前引入
  偏差登记）+ §16.1 变更日志 + §21.7.1 P4 行注记
- 测试计划：capability.md / test-runner.md（新）+ matrix.md r8 全量
  对账（含 r7 陈旧计数修正）

### 质量口径

- §3.2 全绿：build --release 0 警告 / fmt 零 diff / clippy -D warnings
  零警告 / test --release **476:0:0**（408 基线 + 68：capability 24 +
  test_runner 18 + driver 单元 25（effects 12 + capability 13）+
  negative_vm +1（FS-4 激活））/ 审计集 41/41 复跑 EXIT 0
- 全局正负比 **≈1:3.15 维持**（负 ≈1118 / 正 ≈355 case；E0006 能力
  权限码逐条断言——第七族结构码就位）
- 确定性纪律：read-line EOF 语义经子进程探针（Stdio::null()——不依赖
  运行器 stdin 形态）

### 下一步（批次 E，plan §5）

Expander kerf 重写 + TD-004 scope-set 解析收口 + TD-021 hof 用户面
注入（模块机制）→ Stage 1 门审查（§7.3 + §21.3 四条验收）。

## v0.2.0-r9（2026-09-10）——next2.md 吸收轮 + 测试入口架构重构 + lang-design v5.5

### 交付一：next2.md 五轮讨论增量吸收（lang-design v5.5）

- 与 next.md 轮（零缺口）不同，本轮识别**实质缺口**（Perform/Handle/de Bruijn/四层正交/六 IR/MLton/Koka/comptime 于既有文档集零命中）并全量吸收至九文件：01 §7（核心原语 9 vs 8 vs 7 数量真相 + 命名精确性表 + 效应原语化 Stage 2 演进对照裁定——核心冻结不动摇）/ 14 §4（2026 前沿五维成熟度矩阵 + comptime 生产就绪档登记 + 批判审查史 + 可行性评分对照）/ 15 §5（四层正交 crate 对照——r8 实现与 next2 最终版架构同构实证 + IR 六层演进表 + MLton 闭包/Koka 效应消除锚点）/ 12 §2.4.1（S 表达式量化背书 300 vs 3000 行 + 皮肤骨架论）/ 17（六原则对照映射）/ 18 §3（八条术语）/ 19（六行参考）/ 13（comptime 注记）/ 00（v5.5 修订记录）

### 交付二：测试入口架构重构（sop.md §8.4.6 v11.2——Cargo.toml 干净精要）

- **`tests/runner.rs` 单一总入口**：cargo 自动发现（零 [[test]] 配置），`#[path]` mod 树挂载 v0/stage-N 全部 18 个测试文件——阶段/plan/gate 目录语义不变，仅入口收敛；**Cargo.toml 125 行 → 50 行**（[[test]] 18 块清零，仅保留 [[example]] 嵌套声明）
- 共享辅助单实例化：`tests/common/` 由每文件 `mod common` 重复加载（clippy duplicate_mod）改为 runner 单实例 + `use crate::common`（10 个测试文件迁移；3 个未使用者清理）
- sop.md v11.2：§8.4.6「测试入口架构意图」+ 强制规则 8（禁止 [[test]] 逐文件声明）+ §9.1 树更新 + §16.1 变更日志；testing-guide.md r9（运行命令与编写规范更新）
- **测试总数 476 与逐模块计数完全不变**（组织收敛零语义变化）；选择性运行 `cargo test --test runner <module>::`（模块路径即过滤器）

### 质量口径

- §3.2 全绿：build 0 警告 / fmt 零 diff / clippy -D 0 / test **476:0:0**（runner 单二进制 301 + 单元 175）/ 审计集 41/41 EXIT 0
- 集成测试单二进制运行时间 6.95s（18 二进制顺序执行 → 1 二进制并行——加速且零重复编译）

## v0.3.0-r10（2026-09-10）——next3.md 七轮吸收 + 内部语法三原则落地 + 架构合规审计

### 交付一：next3.md 七轮讨论吸收（stage0.md v6.0 + lang-design v6.0 双层收敛）

- **upload/stage0.md v5.0 → v6.0**（原语批判演进版，3706 → 4216 行）：新增 §6.9-§6.12（9/8/7 数量真相与不可消除性证明 / 2026 理论前沿全景与整合决策矩阵 / 四层正交架构与 8 原语重设计 / 最终修正（显式 continuation 类型 / 真解耦四层 / 六 IR / MLton 闭包三策略 / Koka 四阶段效应消除）+ 可行性审查（五目标 A+/A/A/A+/B+）+ §6.12.6 本项目收敛裁定）；§7.3 表面语法决策（S 表达式 = 工程捷径，300 vs 3000 行，皮肤/骨架分离，分阶段语法策略）；§7.4 内部语法设计（告别 `#%` 派生关键词——类型安全 ADT 三原则 + 2026 内部 AST 完整 Rust 定义 + 旧→新迁移映射）；设计原则第 29-31 条；附录 A +17 术语 / E +8 引用 / F 设计讨论演进记录（七轮档案）
- **lang-design v5.5 → v6.0**（九文件回写 + 12 维度系统审查）：01 §8 内部语法设计（三原则 + 当前实现三项合规核验 + 十二行迁移映射 + §8.5 测试锚点）/ 02 §8 表面语法决策 / 15 §5.3 表面-内部分离 = 四层正交第五轴 / 14 §4.4-§4.5 ADT 对照与演进链 / 17 原则 29-31 + 附表四处编号误引修正 / 18 §4 六术语 / 19 §5 三引用（de Bruijn 1972 / Flanagan 1993 / Plotkin & Pretnar 2009）/ 12 §2.5.1 评估清单补齐（悬空引用修复）/ 00 v6.0 修订记录
- **审查修复六类缺陷**：版本号漂移 ×3（01/18/19 头部停在 v5.0/v5.4）、12 悬空登记、13 Version 字段污染、17 附表误引 ×4、**打包自包含性**（上游蓝图存档 docs/stage0.md 243,952 B + lang-design 三处外链改内）
- **收敛裁定**（stage0 §6.12.6 / 01 §8.2-§8.3 / sop v11.3 三处一致）：Stage 0-1 冻结 9 原语（+Require）不变；8 原语形态 + 四层/六 IR/MLton 闭包/Koka 效应消除 = Stage 2「目标语言完整化」评估清单；三原则即刻生效为架构验证基准

### 交付二：sop.md v11.3（原则 29-31 接入流程权威）

- §2.2 三十一条（29 命名行为导向 / 30 类型安全优于命名安全 / 31 表面-内部语法严格分离——各含违反示例）+ 协同关系块第五组
- §8.4.5 文档清单 + §9.1 docs 树登记蓝图存档；§8.4.6 补设计侧锚点接线（lang-design 测试锚点节 ↔ tests/ 树双向锚定）；§16.1 v11.3 变更日志；反臃肿四问全过

### 交付三：架构合规审计落地（代码 + 测试）

- **tests/v0/stage0/plan/architecture_audit_tests.rs（+4）**：十变体穷尽 match 冻结证明（编译期机器证明——新增/删除变体即编译失败）+ 逐变体 Span 独立携带 + kind_name 全映射互异 / Reader 产出 Stx 类型级隔离 / Expander 唯一 Stx→CoreExpr 桥（翻译发生证明）/ 同源双编译 render_core 全等（表面语法可替换性确定性基线）
- **kerf-core expr.rs 迁移映射文档块**（冻结边界 + 三原则合规 + Stage 2 演进目标——§8.4.5 文档随代码）
- **九 crate 五正交轴定位文档**（15 §5.3 落地：span=元数据基座 / syntax=表面语法层 / reader=轴 1 唯一桥接点 / core=骨架 / expander=翻译执行面 / compiler=轴 2 桥接 / vm=轴 3/4 运行时消费 / runtime=通道层 / driver=组合根）

### 质量口径

- §3.2 全绿：clean + build --release ✓ / check 0 error 0 warning / fmt 零 diff / clippy -D 0 / test --release --workspace **480:0:0**（+4 架构审计；单元 175 + 集成 305）
- 矩阵 r10 口径（逐模块计数与 r9 完全一致 + 新增套件）

### 下一步（批次 E，plan §5）

Expander kerf 重写 + TD-004 scope-set 收口 + TD-021 hof 用户面注入 → Stage 1 门审查（§7.3 + §21.3 四条验收）。

---

## v0.3.0-r14（2026-09-11）——批次 E / E1-α：自举 Expander（核心形式 + 九糖，VM 上运行，parity 19 测试）

### 交付一：expander.krf——Expander 以 kerf 源码重写（07 §3.2「Expander（新语言子集）」α 阶段）

- **自举程序**：`bootstrap/expander.krf`（~910 行 kerf 源码，种子管线编译为 **208 原型 / 4685 指令**——迄今最大 kerf 程序）：9 核心形式（lambda/if/set!/define/begin/module/quote/require）+ 九糖（let/letrec/let*/cond/and/or/when/unless/while）+ 内部 define 提升（含切分期名校验/值校验/错误短路序镜像）+ **TD-004 fresh-scope 深注入与作用域集携带**（r13 语义的 kerf 侧镜像）+ trampoline 糖链循环 + retag use-site 替换语义 + quote datum 转换（$hyg$ 剥离经字符表模式匹配——算术索引不经 int 参数内置）
- **值桥**：`bootstrap_expander.rs`——Stx → VM datum 节点（tag s e scopes，作用域集 int 列表）→ VM core 节点 → CoreExpr（作用域集排序去重重建；符号经用户表 intern）；共享 bootstrap.rs 走查辅助（§2.3-10 单一定义）；种子管线加载（compile_front_seed——Rust Reader/Expander 编译 expander.krf，无递归）
- **parity 验收**（tests/v0/stage1/plan/bootstrap_expander_tests.rs，19 测试）：结构（原语形态 + Span(start,end) + **作用域集 + param_scopes** 递归一致）+ 错误（消息 + Span 逐字一致——含提升路径短消息口径）+ 行为面（自举展开产物经 compile + VM 执行与种子全管线一致——**「语言能表达自身前端」的自举验证命题在 Expander 子集上成立**）；509 基线零回归 = **528:0:0**
- **E1-α 边界**（显式报错不静默，§2.3 原则 4）：define-syntax → 边界错误（宏属 E1-β）；糖产物 Span 展开代次不参与 parity 判据（r6 Reader 同口径）；影子路径——生产展开仍走 Rust 种子（切换随 E1-β 宏收口）
- **接口最小放宽**：`IoGrant::none()` pub 化（宿主/测试侧构造无能力全局环境的合法入口；令牌铸造面保持 crate 私有）

### 交付二：质量口径

- **§3.2 六命令实跑全绿**（clean 起步）；审计集 §7.3.1 EXIT 0；CLI 冒烟 fib=75025 + test 2/2 + **expander.krf 自检 ok（208 原型/4685 指令）**
- 文档同步：matrix 528 对账（正例 8 套件 + 负例 6 套件 + 边界 1 + 行为面 3）+ stage-1/plan.md 批次 E 行 + docs/tests/v0/stage1/plan/bootstrap-expander.md 测试计划

### 下一步（批次 E 续）

E1-β 宏收口（syntax-rules + HygieneCtx α 重命名 + 展开深度计数 + 宏产物 Span 代次 + **生产路径切换** + 基础宏定义）+ TD-021 hof 用户面注入（随模块系统）→ Stage 1 门审查（§7.3 + §21.3 四条验收）。

---

## v0.3.0-r13（2026-09-11）——批次 E 启动：TD-004 作用域集解析收口（Racket 式 (name, scopes ⊆) 双路径 + 509 全绿）

### 交付一：TD-004 作用域集解析（P2 清偿——E1 Expander kerf 重写的前置语义基座）

- **展开器**：`ExpandCtxt` 作用域分配器（fresh_scope 单调递增）+ 绑定形式（lambda）fresh scope 深注入——绑定器与全体体形式（`Stx::add_scope_to_all`，新 kerf-syntax 公共 API）；注入先于体展开 ⇒ 宏产物作用域 ⊇ use-site ⊇ {fresh}，自由标识符穿透保持；α 重命名（$hyg$N）保留为第二道卫生保险
- **核心层**：`CoreExpr::VarRef/SetBang` 携带引用作用域集（`scopes`）+ `Lambda.param_scopes` 携带绑定作用域集（与 params 平行）；`free_var_occurrences`（名 + 首现作用域集）——闭包捕获分析与名称版共用单一定义（名称版 = 其投影）
- **编译器**：`ScopeFrame` 绑定项化（名 + 作用域集）+ `resolve_var(name, scopes)` 帧序 + 帧内 max-cardinality 子集匹配；捕获描述符携带命中绑定的绑定作用域集（内层原型经同一子集匹配命中捕获槽）
- **eval 双路径**：`Env` 绑定项化 + `lookup/set` 同一子集匹配口径（T1 一致）；`ClosureValue::Eval` 携带 param_scopes，`apply_value` 经 `define_scoped` 绑定；**空作用域集绑定 ⊆ 任意引用集** ⇒ driver 根环境全局/内置天然兜底，`$hyg$` 基名回退（双侧）降级为回退路径
- **语义判别点**（与旧名称基差异）：名称匹配但作用域不匹配 ≠ 解析命中——按 Racket 语义判为未绑定（VM → 全局兜底后「未绑定的全局变量」；eval → 「未绑定变量」）

### 交付二：质量口径

- **509:0:0**（500 基线零回归 + 9 锚点新增；单元 183 + 集成 326）；§3.2 六命令全绿（clean 起步实测）；审计集 §7.3.1 配比满足 EXIT 0；CLI 冒烟 fib 75025 + test 2/2
- 锚点 = tests/v0/stage1/plan/scope_set_tests.rs（正例 5 双路径：shadowing/嵌套 shadowing/闭包捕获/set! 词法命中/子集对照；负例 4：作用域不匹配未绑定 VM/eval/set! + 宏引入不捕获）+ docs/tests/v0/stage1/plan/scope-set.md 测试计划
- 文档同步：tech-debt-register TD-004 → 已解决（r13）+ matrix 509 对账 + 03-macro-system 实现状态注记 + stage-1/plan.md 批次 E 行更新

### 下一步（批次 E 续）

Expander kerf 重写（E1——scope-set 语义基座就绪后重写，Rust 实现保留为 parity oracle）+ TD-021 hof 用户面注入（随模块系统设计）→ Stage 1 门审查（§7.3 + §21.3 四条验收）。

---

## v0.3.0-r12（2026-09-11）——接口预留完整性扩展轮（next4 第八轮：docs 三层 + 预留层代码冻结 + 500 全绿）

### 交付一：next4.md 第八轮三层吸收（stage0 v6.1 + lang-design v6.1 + sop v11.4）

- **stage0.md v6.0 → v6.1**（4216 → 4757 行）：新增 §9.3-§9.5 接口预留完整性审查（覆盖度评估六类 ~70% → 10 个新识别关键接口：LSP/IDE 查询/调试信息/FFI 边界/增量编译查询/编译器即服务/多目标后端/包管理/AI 辅助 + 效应扩展/能力委托增补 → 完整预留矩阵 14 项 → P0-P3 优先级 + ~3 周成本核算 + 全景图）；§9.2 边界调和（LSP/FFI 重分类——「完全推迟 = 未承诺采用」语义精确化）；§7.1 矩阵 4→14 项；§21.9 预留成本核算；原则 32「预留留白」；附录 E.8 + F 第八轮登记
- **lang-design v6.1**（八文件）：13 主体（§1.1.1 矩阵 4→14 + §3.2 调和 + §3.3-§3.5 完整审查 + 测试锚点注记）；12 §2.9 成本核算 + Phase 4 更新；10 LSP 重分类注记；08 CodegenBackend 预留注记；15 预留层注记 + 查询双预留互链；17 原则 32 + 附三；18 §5 术语 13 条；19 §6 引用 3 条；00 v6.1 修订记录；kerf/docs/stage0.md 存档再生成 v6.1
- **sop v11.3 → v11.4**：§2.2 三十二条（第 32 条预留留白 + 违反示例）；新增 §21.12 接口预留时机（能力引入时机 vs 数据结构冻结时机叠加规则 + §13.1/§6.2 双接线 + 成本口径）；§21.11 风险表「接口预留过多/不足」行对账（四项 → 14 项矩阵清单）；§8.4.5 查询表 + 接口预留行；§16.1 v11.4 行
- **审计**：关键词矩阵 74/74（stage0）+ 29/29（lang-design 全集）全命中；LSP/FFI 陈旧行 0；全 20 文件锚点 GitHub 算法校验零坏链；三面原则编号链一致（29-31 → 32）

### 交付二：预留层代码冻结（reserved/ 模块 4→14 项，P0 位置跨 crate 断言）

- **重构 reserved.rs → reserved/ 模块目录**（§8.4.6 落位 + 既有四接口零迁移）：`mod.rs`（既有 4 项 + 文档 v6.1）+ `toolchain.rs`（P0 三项：LanguageService/IncrementalAst + DebugInfoGenerator/DebugTraceable + QuerySystem/Query；P1：CompilerService/Serializable；P2：PackageManager/ExternalModule/AiAssistant）+ `ffi.rs`（P1：ExternalType/FfiCall/FfiBoundary——GC pin/unpin 隔离协议 + 自举合规注记）+ `codegen.rs`（P1：CodegenBackend/WasmBackend——目标中立类型级证明）
- **P0 数据结构位置对账**（集成断言 12 项）：每节点 Span ✓（CoreExpr::span()）/ 绑定作用域 ✓（NodeMetadata.scopes）/ 稳定 ID ✓（ir::NodeId）/ 函数边界 ✓（BcProgram::protos）/ 调试帧槽 ✓（VM ext3）/ 内容寻址口径统一 ✓（QueryDescriptor ↔ CacheKey）
- **测试 +20（480 → 500）**：Probe 冻结 8（单元：toolchain 3 + ffi 3 + codegen 2——「测试实现体编译通过 = 契约冻结」先例沿用）+ 跨 crate 位置断言与形状行为 12（集成 tests/v0/stage1/plan/reserved_ext_tests.rs，经 runner.rs 总入口挂载）

### 交付三：质量口径

- cargo clean + build --release / check / fmt --check / clippy --all-targets -D warnings 全绿；**test --release --workspace 500:0:0**（单元 183 + 集成 317）；审计集 §7.3.1 配比满足 EXIT 0；CLI 冒烟 fib 75025 + kerf test 3/3
- 语义核心冻结零变动（CoreExpr/9 原语/操作语义）；既有四预留契约签名零迁移（reserved_signatures_are_frozen 先例测试保持）
- 下一步（批次 E，plan §5）：Expander kerf 重写 + TD-004 scope-set 收口 + TD-021 hof 用户面注入 → Stage 1 门审查（§7.3 + §21.3 四条）
---

## v0.3.0-r11（2026-09-10）——吸收完整性复核轮 + 核心原语三面同步（docs / web / 打包）

### 交付一：next*.md 三源吸收完整性复核（审计轮，零实质缺口确认）

- **三源关键词矩阵 + 章节结构映射审计**：next.md（4 文档：超越 Lisp 范式替代方案 / 五大能力历史与创新原则 / 2026 深度设计 / Stage 0 完整能力模型）→ stage0.md Part II §4 + Part III（拆分至 lang-design 14/13/16）；next2.md（六轮：8vs9 真相 / 前沿全景 / 四层正交 / 最终修正 / 可行性 / 表面语法）→ stage0 §6.9-§6.12 + lang-design v5.5；next3.md（= next2 六轮 + 第七轮内部语法重构）→ stage0 v6.0 §7.3/§7.4 + lang-design v6.0——**全部特征概念在吸收面命中**（三原则 / CoreExpr ADT / 迁移映射 / 派生关键词批判 / 9-8-7 真相 / 四层正交 / 六 IR / MLton 闭包 / Koka 效应消除 / de Bruijn / continuation 类型安全 / comptime / S 表达式决策 / 皮肤骨架分离 / 联合交叉类型 / 行多态 / Janet/Céu 归入 PEG/同步语言概念族）
- **存档对账**：kerf/docs/stage0.md（上游蓝图存档）与 upload/stage0.md 同为 v6.0（+496B 归档说明头，预期设计）；sop v11.3 三十一条（29-31）+ §16.1 变更日志 + §8.4.6 测试入口架构意图全部在位

### 交付二：核心原语相关变动三面同步（用户指令专项——P2 文档债修复）

- **kerf README.md**（§8.4.5 文档随代码——r6-r10 陈旧对账）：版本 v5.4/v11.1 → v6.0/v11.3；状态行批次 D → r9/r10 吸收审计轮；架构行补 能力参数化 / 内部效应 / kerf test；特性清单补 **核心原语演进登记**（9 冻结 + 8 原语 Stage 2 语义等价映射 + 三原则）+ 自举 Reader（r6）+ 能力门控 I/O（r8）+ 内部效应（r8）四条；质量状态 r7/476 → r10/480（runner.rs 单一总入口口径）
- **develop plan.md**：批次表新增「吸收/审计轮」行（r9 测试入口重构 ✅ + r10 next3 双层吸收 + 架构合规审计 4 测试 480:0:0 ✅ + 语义核心冻结零变动 + 三面同步验收）
- **stage-0 status.md**：测试总数 356（r6 陈旧）→ 480 全绿（r5-r10 增量分项）；§5 新增架构合规审计测试与核心原语演进登记两条
- **web（kerf 官网）**：能力区新增「核心原语 · 语义核心」主内容区块——9 冻结原语网格（名称/元数/语义，与 lang-design 01 §2 最终定义逐项对齐）+ 核心原语演进登记卡（§6.12.6 收敛裁定 / 9-8-7 数量真相 / 9→8 迁移映射表 8 行 / 内部语法三原则 / 四层正交 + 第五正交轴 / 架构合规审计 4 测试）；路线图 Stage 2 补核心原语演进迁移要点；此前 v6.0/v11.3/r10 版本口径与 footer 包清单已同步（r10 轮交付，本轮复核确认）

### 质量口径

- §3.2 全绿（本轮实跑）：clean + build --release 9.37s ✓ / check 0/0 / fmt 零 diff / clippy --all-targets -D 0 / test --release --workspace **480:0:0**（单元 175 + 集成 305——--workspace 口径，根 package 单跑为 305 属预期组织形态）
- 审计集 41 case EXIT 0（§7.1.1 七类全覆盖）；CLI 冒烟：fib 75025 + ⇒ 144 + kerf test 2/2 通过

### 下一步（批次 E，plan §5）

Expander kerf 重写 + TD-004 scope-set 收口 + TD-021 hof 用户面注入 → Stage 1 门审查（§7.3 + §21.3 四条验收）。

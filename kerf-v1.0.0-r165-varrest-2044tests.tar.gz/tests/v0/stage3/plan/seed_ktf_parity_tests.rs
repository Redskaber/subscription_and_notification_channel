//! Seed-payload target-syntax parity tests — r149 / 219-b2 (the S-expr
//! complete removal window Batch A — the build-system five-face payload
//! conversion gate; s-expr-removal-plan.md §5 gate X + §7).
//!
//! E6 close-out (r154 / 224-b3): the gate-X .krf-oracle parity legs
//! retired (duty complete — principle 41 demolition after validation;
//! the surviving duty = fixpoint gates + two-path faces + payload
//! integrity anchors, all .ktf-only). The bytecode-parity legs that
//! compared each .krf original (through the deleted S-expr seed Reader)
//! against its .ktf rewrite are gone together with the deleted oracle
//! files; the .ktf payloads' own integrity faces below carry forward.
//!
//! **Verification faces** (post-E6):
//! (1) **entry + global consumption face** (the .ktf payloads'
//! resolved proto names carry the bridge entry symbols — the naming-map
//! roundtrip root — and the resolved global_refs carry the payloads'
//! builtin consumption faces);
//! (2) **naming-map roundtrip** (symbol_name single-point
//! discipline — the entry identifiers + sampled internal names +
//! the identity faces);
//! (3) **cross-stage consumption E2E** (the target user face —
//! run_source — on a prelude-importing program: transitively
//! consults build.ktf [prelude injection decision] + cache.ktf [cached
//! compilation] + reader.ktf [production read bridge — the bridge's
//! own program, renamed from reader.ktf at the E6 close-out]);
//! (4) **fixpoint + payload integrity anchors** (the Reader self-parse
//! fixpoint, the reader.ktf growth-signature shape anchor, the
//! entry/charset/kcell/builtin consumption faces, the token/Stx
//! snapshot anchors);
//! (5) **fail-closed negatives** (payload-shaped rejections across the
//! error classes: lexical / grammar / position / domain-out /
//! declaration-arity / declaration-collision / capability / unbound /
//! HM / runtime / depth-guard).
//!
//! Basis: principle 31 (skin/skeleton isomorphism — the gate X judgment,
//! archived at E6) / principle 41 (parallel-piece strategy — the .krf
//! oracle originals demolished after the window's full validation)
//! / s-expr-removal-plan §3 (feasibility audit) + §5 (gate design) +
//! §6 (exit conditions) / 07 §3.2.1 (seed-loading hard
//! P1 convention — the seed target path is the bootstrap loading route)
//! / 20 §14 (skin dictionary) / §9.4.3 (8 : 24 = 1:3).

use kerf_compiler::{compile_module, BcConst, BcProgram};
use kerf_driver::bootstrap::check::production_check_is_krf;
use kerf_driver::bootstrap::reader::read_source_for_bootstrap;
use kerf_driver::{check_source_recover, run_source};
use kerf_expander::{expand_program as expand_program_seed, ExpandCtxt};
use kerf_reader::{read_source, symbol_name};
use kerf_span::SourceMap;
use kerf_syntax::{Stx, StxDatum, StxLiteral, SymbolTable};

// ---------------------------------------------------------------------------
// Payload artifacts (include_str! makes every payload a tested artifact —
// the payload-integrity gate; the .krf oracle originals were deleted at
// the E6 close-out [224-a] — repository .krf count = 0, principle 41
// demolition after validation)
// ---------------------------------------------------------------------------

const BUILD_KTF: &str = include_str!("../../../../crates/kerf-driver/src/bootstrap/build.ktf");
const CLI_KTF: &str = include_str!("../../../../crates/kerf-driver/src/bootstrap/cli.ktf");
const TEST_KTF: &str = include_str!("../../../../crates/kerf-driver/src/bootstrap/test.ktf");
const RUNNER_KTF: &str =
    include_str!("../../../../crates/kerf-driver/src/bootstrap/test_runner.ktf");
const CACHE_KTF: &str = include_str!("../../../../crates/kerf-driver/src/bootstrap/cache.ktf");

// r150 / 220-c — Batch B payload (the HM production judgment face; the
// bilateral keyword-tag normalization — the seven TAG constants — now
// rides the .ktf side alone; the .krf oracle leg retired at E6).
const CHECK_KTF: &str = include_str!("../../../../crates/kerf-driver/src/bootstrap/check.ktf");

// ---------------------------------------------------------------------------
// Compile-path helpers (the seed pipeline reconstructed at test level —
// read [target face] → seed expansion → seed compilation; the established
// switch_corpus_parity_tests caliber)
// ---------------------------------------------------------------------------

fn read_ktf(src: &str, name: &str) -> (Vec<Stx>, SymbolTable) {
    let mut sm = SourceMap::new();
    let fid = sm.add_file(name, src);
    let mut table = SymbolTable::new();
    let forms = read_source(src, fid, &mut table)
        .unwrap_or_else(|e| panic!("[{}] ktf read failed: {}", name, e.message));
    (forms, table)
}

fn compile_forms(forms: &[Stx], table: SymbolTable, what: &str) -> (BcProgram, SymbolTable) {
    let mut ectx = ExpandCtxt::new(table);
    let core = expand_program_seed(forms, &mut ectx)
        .unwrap_or_else(|e| panic!("[{}] seed expansion failed: {}", what, e.message));
    let program = compile_module(&core)
        .unwrap_or_else(|e| panic!("[{}] seed compile failed: {}", what, e.message));
    (program, ectx.table)
}

/// Strip top-level imports (driver-pipeline 1.68-step isomorphism — import
/// has zero runtime semantics; the test helper bypasses front_from_forms,
/// so it must mirror this explicitly — the switch_corpus_parity_tests
/// caliber, shared verbatim).
fn strip_toplevel_imports_for_compile(forms: &[Stx], t: &SymbolTable) -> Vec<Stx> {
    forms
        .iter()
        .filter(|f| {
            !matches!(
                &f.datum,
                StxDatum::List(l)
                    if l.first()
                        .and_then(|x| x.datum.as_symbol())
                        .map(|s| t.name(s) == "import")
                        .unwrap_or(false)
            )
        })
        .cloned()
        .collect()
}

/// Payload compile: target-face source → bytecode + owning table
/// (top-level imports stripped before expansion — the driver 1.68 step
/// mirror).
fn payload_ktf(src: &str, name: &str) -> (BcProgram, SymbolTable) {
    let (forms, table) = read_ktf(src, name);
    let stripped = strip_toplevel_imports_for_compile(&forms, &table);
    compile_forms(&stripped, table, name)
}

// ---------------------------------------------------------------------------
// Resolved-name comparison caliber (Symbol handles are table-local — every
// Symbol-bearing field resolved through its owning table; the surviving
// legacy of the retired gate-X cross-text comparator, consumed by the
// entry/global consumption faces)
// ---------------------------------------------------------------------------

/// Normalized constant (Symbol → resolved global name, keeping the
/// Global/SymLit variant distinction — §11 interface isolation).
#[derive(Debug, PartialEq)]
enum CNorm {
    Int(i64),
    Float(f64),
    Str(String),
    Bool(bool),
    Nil,
    Global(String),
    SymLit(String),
}

fn norm_const(c: &BcConst, t: &SymbolTable) -> CNorm {
    match c {
        BcConst::Int(v) => CNorm::Int(*v),
        BcConst::Float(f) => CNorm::Float(*f),
        BcConst::Str(s) => CNorm::Str(s.to_string()),
        BcConst::Bool(b) => CNorm::Bool(*b),
        BcConst::Nil => CNorm::Nil,
        BcConst::Symbol(s) => CNorm::Global(safe_name(*s, t)),
        BcConst::SymLit(s) => CNorm::SymLit(s.to_string()),
    }
}

fn resolved_names(syms: &[kerf_syntax::Symbol], t: &SymbolTable) -> Vec<String> {
    syms.iter().map(|s| safe_name(*s, t)).collect()
}

/// Sentinel-tolerant name resolution (the compiler uses out-of-table
/// sentinel Symbols for rendering-replaced slots — e.g. the main proto's
/// name [compile.rs `Symbol(u32::MAX - 1)`]; both sides carry the same
/// sentinel at the same slot, rendered uniformly here).
fn safe_name(s: kerf_syntax::Symbol, t: &SymbolTable) -> String {
    if (s.0 as usize) < t.len() {
        t.name(s).to_string()
    } else {
        format!("<uninterned:{}>", s.0)
    }
}

// ---------------------------------------------------------------------------
// (2) Entry + global consumption face (the .ktf payloads' resolved proto
// names carry the bridge entry symbols; the global face carries the
// payloads' builtin consumption faces)
// ---------------------------------------------------------------------------

/// Entry + global consumption face: the five .ktf payloads' **constant
/// pools (resolved)** carry the bridge entry symbols as `Global`
/// constants (every top-level define lands a STORE_GLOBAL — the name the
/// bridge interns + looks up; proto names are first-parameter metadata
/// [compile.rs `proto.params.first()` — resolution surface = arity], not
/// fn names, so the const pool is the entry-resolution evidence), and
/// the resolved global_refs carry the payloads' builtin consumption
/// faces.
#[test]
fn payload_entry_and_global_face_five_faces() {
    let sources: [(&str, &str); 5] = [
        ("build.ktf", BUILD_KTF),
        ("cli.ktf", CLI_KTF),
        ("test.ktf", TEST_KTF),
        ("test_runner.ktf", RUNNER_KTF),
        ("cache.ktf", CACHE_KTF),
    ];
    let entries: [(&str, &str); 5] = [
        ("build.ktf", "lbld-is-imports-prelude"),
        ("cli.ktf", "lcli-dispatch"),
        ("test.ktf", "ltest-report"),
        ("test_runner.ktf", "ltest-run"),
        ("cache.ktf", "lcache-consult"),
    ];
    let globals_want: [(&str, &str, &[&str]); 5] = [
        (
            "build.ktf",
            "head",
            &["tail", "length", "drop", "eq", "is-nil"],
        ),
        ("cli.ktf", "eq", &[]),
        (
            "test.ktf",
            "nth",
            &["string-append", "string-length", "is-nil"],
        ),
        (
            "test_runner.ktf",
            "nth",
            &[
                "string-length",
                "string-substring",
                "string-append",
                "cons",
                "is-nil",
            ],
        ),
        ("cache.ktf", "string-append", &["list"]),
    ];
    for (idx, (name, src)) in sources.iter().enumerate() {
        let (program, table) = payload_ktf(src, name);
        // Entry resolution: the bridge entry symbol lands in the resolved
        // constant pool as a Global constant (the top-level define's
        // STORE_GLOBAL operand — the name the bridge interns + the loaded
        // globals carry).
        let consts: Vec<CNorm> = program
            .consts
            .iter()
            .map(|c| norm_const(c, &table))
            .collect();
        let entry = entries
            .iter()
            .find(|(n, _)| n == name)
            .map(|(_, e)| e)
            .expect("entry table row");
        assert!(
            consts
                .iter()
                .any(|c| matches!(c, CNorm::Global(g) if g == entry)),
            "[{}] entry constant {} missing from the resolved pool {:?}",
            name,
            entry,
            consts
        );
        // Global consumption face: the primary/secondary builtins of the
        // case row resolve in the global reference face.
        let globals = resolved_names(&program.global_refs, &table);
        let (_, primary, secondary) = globals_want[idx];
        assert!(
            globals.iter().any(|g| g == primary),
            "[{}] primary builtin {} missing from global face {:?}",
            name,
            primary,
            globals
        );
        for want in secondary {
            assert!(
                globals.iter().any(|g| g == want),
                "[{}] secondary builtin {} missing from global face {:?}",
                name,
                want,
                globals
            );
        }
    }
}

// ---------------------------------------------------------------------------
// (2) Naming-map roundtrip (symbol_name single-point discipline)
// ---------------------------------------------------------------------------

#[test]
fn payload_naming_map_roundtrip_discipline() {
    // The five bridge entry identifiers (target `_` face) land on the seed
    // symbols (S-expr `-` face) the bridges intern + look up.
    for (ident, symbol) in [
        ("lbld_is_imports_prelude", "lbld-is-imports-prelude"),
        ("lcli_dispatch", "lcli-dispatch"),
        ("ltest_report", "ltest-report"),
        ("ltest_run", "ltest-run"),
        ("lcache_consult", "lcache-consult"),
    ] {
        assert_eq!(
            symbol_name(ident),
            symbol,
            "entry identifier {} must map to the seed symbol {}",
            ident,
            symbol
        );
    }
    // Sampled internal names (the conversion's naming discipline — every
    // kebab name of the five payloads roundtrips through the `_` face).
    for (ident, symbol) in [
        ("import_clause_has_prelude", "import-clause-has-prelude"),
        ("form_imports_prelude", "form-imports-prelude"),
        ("module_imports_prelude", "module-imports-prelude"),
        ("truncate_name", "truncate-name"),
        ("run_case_step", "run-case-step"),
        ("rev_list", "rev-list"),
        ("cfg_input", "cfg-input"),
        ("int_to_string", "int-to-string"),
        ("digit_table", "digit-table"),
        ("CACHE_SEED", "CACHE-SEED"),
        ("PRELUDE_MODULE", "PRELUDE-MODULE"),
        ("kerf_prelude", "kerf-prelude"),
    ] {
        assert_eq!(symbol_name(ident), symbol);
    }
    // Identity faces: bare `_` placeholder + underscore-free names.
    assert_eq!(symbol_name("_"), "_");
    assert_eq!(symbol_name("eq"), "eq");
    assert_eq!(symbol_name("lhash"), "lhash");
}

// ---------------------------------------------------------------------------
// (3) Cross-stage consumption E2E (the target user face through the
// production chain — the .ktf payloads serve production transitively)
// ---------------------------------------------------------------------------

/// A prelude-importing program through the target user face
/// (run_source): transitively consults build.ktf [the
/// prelude-injection decision] + cache.ktf [cached compilation] +
/// reader.ktf [the production read bridge — the bridge's own program].
/// The rendered value = the payloads serving the production face
/// (principle 31; the S-expr twin leg retired with the deleted S-expr
/// driver face at the E6 close-out).
#[test]
fn payload_cross_stage_dual_face_e2e() {
    let ktf_src = "import kerf_prelude;\nmap(|| (x: i64) { x + 1 }, list(1, 2, 3))";
    let out_ktf = run_source(ktf_src, "cross.ktf")
        .unwrap_or_else(|e| panic!("ktf face execution failed: {}", e));
    let rendered_ktf = kerf_vm::render_value(&out_ktf.value, &out_ktf.heap);
    assert_eq!(rendered_ktf, "(2 3 4)");
}

// ---------------------------------------------------------------------------
// (5) Fail-closed negatives (payload-shaped — 24 across the error classes)
// ---------------------------------------------------------------------------

fn read_err_msg(src: &str, what: &str) -> String {
    let mut sm = SourceMap::new();
    let fid = sm.add_file("neg.ktf", src);
    let mut table = SymbolTable::new();
    match read_source(src, fid, &mut table) {
        Err(e) => e.message,
        Ok(_) => panic!("[{}] expected a read error, parsed successfully", what),
    }
}

/// Negative 1 (lexical): unterminated string literal.
#[test]
fn neg_lex_unterminated_string_fail() {
    let msg = read_err_msg("define(X, \"unterminated);", "unterminated string");
    assert!(
        msg.to_lowercase().contains("unterminated") || msg.to_lowercase().contains("string"),
        "diagnostic must name the string family (actual: {})",
        msg
    );
}

/// Negative 2 (lexical): unterminated block comment.
#[test]
fn neg_lex_unterminated_block_comment_fail() {
    let msg = read_err_msg("#| fn f(x: T) { 1 }", "unterminated block comment");
    assert!(
        !msg.is_empty(),
        "block comment without a terminator must read-error (actual message: {})",
        msg
    );
}

/// Negative 3 (lexical): invalid string escape.
#[test]
fn neg_lex_bad_escape_fail() {
    let msg = read_err_msg("let X = \"a\\qb\";", "invalid escape");
    assert!(
        !msg.is_empty(),
        "invalid escape must read-error (actual message: {})",
        msg
    );
}

/// Negative 4 (grammar): unbalanced brace (missing `}`).
#[test]
fn neg_grammar_unbalanced_brace_fail() {
    let msg = read_err_msg("fn f(x: T) { f(x)", "missing brace");
    assert!(
        msg.contains("}") || msg.to_lowercase().contains("brace"),
        "diagnostic must name the missing brace (actual: {})",
        msg
    );
}

/// Negative 5 (grammar — r158 / 228-c reface): the truncated call form
/// is fronted to the Read-stage retirement diagnostic (the define(X,
/// list(1, 2); shape never reaches paren matching — the rejection arm
/// fires at the define token; the diagnostic names the modern
/// replacement form).
#[test]
fn neg_grammar_missing_paren_fail() {
    let msg = read_err_msg("define(X, list(1, 2);", "missing paren");
    assert!(
        msg.contains("the define call form is retired"),
        "the retirement diagnostic fronts the truncated shape (actual: {})",
        msg
    );
}

/// Negative 6 (grammar): fn parameter without the mandatory type annotation.
#[test]
fn neg_grammar_fn_param_missing_type_fail() {
    let err = run_source("fn f(x) { f(x) }", "neg.ktf")
        .expect_err("target face parameter type annotations grammatically required");
    assert!(
        err.to_string().contains("expected :"),
        "diagnostic must name the missing `:` (actual: {})",
        err
    );
}

/// Negative 7 (grammar): expression statement inside a block without the
/// `;` separator (top-level items are separator-tolerant — the block
/// statement discipline is the enforced face).
#[test]
fn neg_grammar_stmt_missing_semi_fail() {
    let err = run_source("fn f(x: T) { g(1) g(2) }\nf(1)", "neg.ktf")
        .expect_err("block expression statements must end with `;`");
    assert!(
        err.to_string().contains(";") || err.to_string().contains("}"),
        "diagnostic must name the terminator family (actual: {})",
        err
    );
}

/// Negative 8 (grammar): stray `else` without an `if`.
#[test]
fn neg_grammar_stray_else_fail() {
    assert!(
        run_source("else { 1 }", "neg.ktf").is_err(),
        "stray else must read-error"
    );
}

/// Negative 9 (grammar): fn declaration without a name.
#[test]
fn neg_grammar_fn_missing_name_fail() {
    let err = run_source("fn (x: T) { 1 }", "neg.ktf").expect_err("fn requires a name identifier");
    assert!(
        err.to_string().contains("name"),
        "diagnostic must name the function-name family (actual: {})",
        err
    );
}

/// Negative 10 (grammar): call arguments missing the comma separator.
#[test]
fn neg_grammar_call_missing_comma_fail() {
    assert!(
        run_source("let X = list(1 2);", "neg.ktf").is_err(),
        "call arguments without a comma must read-error"
    );
}

/// Negative 11 (grammar): import with a trailing comma.
#[test]
fn neg_grammar_import_trailing_comma_fail() {
    assert!(
        run_source("import kerf_list,;\n1", "neg.ktf").is_err(),
        "import trailing comma must read-error"
    );
}

/// Negative 12 (domain-out): a bare `mut` statement (mutability semantics
/// out of the kernel domain — the `let mut`/param-position modifier is
/// parsed-then-stripped skin, the statement-position form is domain-out).
#[test]
fn neg_domain_mut_binding_fail() {
    let err = run_source("fn f(x: T) { mut y = 1; y }\nf(1)", "neg.ktf")
        .expect_err("bare mut statement is domain-out (fail-closed)");
    assert!(
        err.to_string().contains("mut"),
        "diagnostic must name the mut domain-out family (actual: {})",
        err
    );
}

/// Negative 13 (domain-out): vector literal trailing comma.
#[test]
fn neg_domain_vector_trailing_comma_fail() {
    let err = run_source("let v = [1, 2,];\nv", "neg.ktf")
        .expect_err("vector literal trailing comma is rejected fail-closed");
    assert!(
        err.to_string().contains("trailing comma"),
        "diagnostic must name the trailing comma (actual: {})",
        err
    );
}

/// Negative 14 (position): import inside a fn body (import is a
/// top-level/module-header form — in-statement position is out of domain).
#[test]
fn neg_position_import_inside_fn_fail() {
    assert!(
        run_source("fn f(x: T) { import kerf_list; 1 }", "neg.ktf").is_err(),
        "import inside a fn body must read-error (statement position out of domain)"
    );
}

/// Negative 15 (position): require inside a fn body.
#[test]
fn neg_position_require_inside_fn_fail() {
    assert!(
        run_source("fn f(x: T) { require io; 1 }", "neg.ktf").is_err(),
        "require inside a fn body must read-error (statement position out of domain)"
    );
}

/// Negative 16 (declaration arity — r158 / 228-c reface): the one-
/// argument call form is fronted to the Read-stage retirement
/// diagnostic (the whole item-position family retires together —
/// toplevel-let-design.md D2).
#[test]
fn neg_decl_define_bad_arity_fail() {
    let err = run_source("define(X);\n1", "neg.ktf")
        .expect_err("the one-argument call form must be rejected at read time");
    assert!(
        err.diagnostic
            .message
            .contains("the define call form is retired"),
        "the retirement diagnostic names the define family (actual: {})",
        err.diagnostic.message
    );
}

/// Negative 17 (declaration collision): duplicate top-level define.
#[test]
fn neg_decl_duplicate_define_fail() {
    let err = run_source("let x = 1;\nlet x = 2;\nx", "neg.ktf")
        .expect_err("colliding top-level define is a structured compile-time diagnostic");
    assert!(
        err.to_string().to_lowercase().contains("duplicate"),
        "diagnostic must name the duplicate family (actual: {})",
        err
    );
}

/// Negative 18 (capability): I/O call without a require declaration.
#[test]
fn neg_capability_print_without_require_fail() {
    let err = run_source("fn f(n: T) { print(n); }\nf(1)", "neg.ktf")
        .expect_err("undeclared I/O call = compile-time E0006 capability gating");
    assert!(
        err.to_string().contains("E0006"),
        "diagnostic must be E0006 capability permission (actual: {})",
        err
    );
}

/// Negative 19 (unbound): reference to an undefined global.
#[test]
fn neg_unbound_reference_fail() {
    let err = check_source_recover(
        "fn f(n: T) { if (n == 0) { 0 } else { gxx(n - 1) } }\nf(3)",
        "neg.ktf",
    )
    .expect_err("unbound reference = compile-time E0022 whole-program short-circuit");
    assert!(
        err.to_string().contains("gxx") || err.to_string().contains("unbound"),
        "diagnostic must name the unbound family (actual: {})",
        err
    );
}

/// Negative 20 (unbound — mapped face): kerf-string consumption without an
/// import (the mapped symbol `string-append` in the diagnostic).
#[test]
fn neg_unbound_mapped_face_without_import_fail() {
    let err = check_source_recover("let keep = string_append(\"a\", \"b\");\nkeep", "neg.ktf")
        .expect_err("string_append without import = E0022 (N2 injection face)");
    assert!(
        err.to_string().contains("string-append"),
        "diagnostic must name the mapped symbol string-append (actual: {})",
        err
    );
}

/// Negative 21 (HM): arithmetic type mismatch (int + string).
#[test]
fn neg_hm_type_mismatch_fail() {
    let err = run_source("let x = 1 + \"a\";\nx", "neg.ktf")
        .expect_err("int + string is an HM type mismatch (BUILTIN_SIGS face)");
    assert!(
        !err.to_string().is_empty(),
        "HM diagnostic must be rendered (actual: {})",
        err
    );
}

/// Negative 22 (HM): builtin arity mismatch (mod with one argument).
#[test]
fn neg_hm_builtin_arity_fail() {
    assert!(
        run_source("let x = mod(1);\nx", "neg.ktf").is_err(),
        "mod(1) arity mismatch must fail (HM signature face)"
    );
}

/// Negative 23 (runtime): head of a non-pair value.
#[test]
fn neg_runtime_head_of_non_pair_fail() {
    let err = run_source("let x = head(1);\nx", "neg.ktf")
        .expect_err("head of an int is a runtime type error");
    assert!(
        !err.to_string().is_empty(),
        "runtime diagnostic must be rendered (actual: {})",
        err
    );
}

/// Negative 24 (depth guard): nesting beyond the 256 depth cap on the
/// **seed Reader** (the Rust recursive-descent recursion guard —
/// the r149 / 219-b2 in-window defect settlement; the production read
/// path runs the self-hosted target Reader on the VM — iterative
/// trampoline + heap frames + the VM frame cap [TD-023], its own
/// defense — so this guard's protected face is the seed path
/// [compile_front_seed payload loading + oracle]; the S-expr
/// datum-cap twin leg retired with the deleted classic Reader at the
/// E6 close-out).
#[test]
fn neg_depth_nesting_over_cap_fail() {
    let deep = format!("let x = {}1{};\nx", "(".repeat(400), ")".repeat(400));
    // Seed target Reader (the guarded face)
    let mut sm = SourceMap::new();
    let fid = sm.add_file("neg.ktf", &deep);
    let mut table = SymbolTable::new();
    let err = read_source(&deep, fid, &mut table)
        .expect_err("nesting beyond the 256 depth cap must read-error fail-closed");
    assert!(
        err.message.contains("nesting depth exceeds the limit"),
        "diagnostic must name the depth-cap family (actual: {})",
        err.message
    );
}

// ===========================================================================
// r150 / 220-c — Batch B gate faces (check.ktf — the HM production judgment
// face; s-expr-removal-plan §4 Batch B + §5 gate B — post-E6: entry/global
// face + naming roundtrip + cross-stage E2E + production wiring liveness +
// the check-shaped negative family through the target user face; the
// .krf-oracle bytecode-parity legs + the bilateral keyword-tag anchor
// retired at the E6 close-out [224-b3])
// ===========================================================================

/// Entry + global consumption face: check.ktf's resolved constant pool
/// carries the bridge entry symbol `lchk-check-program` (the STORE_GLOBAL
/// operand the bridge interns + looks up) and the resolved global_refs
/// carry the HM engine's builtin consumption face.
#[test]
fn check_entry_and_global_face() {
    let (program, table) = payload_ktf(CHECK_KTF, "check.ktf");
    let consts: Vec<CNorm> = program
        .consts
        .iter()
        .map(|c| norm_const(c, &table))
        .collect();
    let entry_hit = consts.iter().any(|c| match c {
        CNorm::Global(n) => n == "lchk-check-program",
        _ => false,
    });
    assert!(
        entry_hit,
        "check.ktf const pool must carry the bridge entry symbol lchk-check-program"
    );
    let globals: Vec<String> = resolved_names(&program.global_refs, &table);
    for want in ["head", "tail", "cons", "eq", "length", "list", "append"] {
        assert!(
            globals.iter().any(|g| g == want),
            "check.ktf global face must consume the builtin {} (actual: {:?})",
            want,
            globals
        );
    }
}

/// Naming-map roundtrip (Batch B discipline): the bridge entry identifier
/// and sampled internal kebab names and the seven TAG names roundtrip
/// through the `_` face; identity faces unchanged.
#[test]
fn check_naming_map_roundtrip_discipline() {
    // The bridge entry (target `_` face → the seed symbol the bridge
    // interns + looks up).
    assert_eq!(symbol_name("lchk_check_program"), "lchk-check-program");
    // Sampled internal names across the payload's sections.
    for (ident, symbol) in [
        ("tc_infer_app_general", "tc-infer-app-general"),
        ("tc_unify_params", "tc-unify-params"),
        ("tc_rule_pair_list", "tc-rule-pair-list"),
        ("is_num_atom", "is-num-atom"),
        ("arity_want_str", "arity-want-str"),
        ("tcon_kind_str", "tcon-kind-str"),
        ("env_free_vars_except", "env-free-vars-except"),
        ("tc_var_names_many", "tc-var-names-many"),
        ("tc_diag_triples", "tc-diag-triples"),
        ("TC_SIGS", "TC-SIGS"),
        ("TC_RENAME", "TC-RENAME"),
    ] {
        assert_eq!(
            symbol_name(ident),
            symbol,
            "internal identifier {} must map to the seed symbol {}",
            ident,
            symbol
        );
    }
    // The seven keyword TAG names (the bilateral normalization face).
    for (ident, symbol) in [
        ("FN_TAG", "FN-TAG"),
        ("IF_TAG", "IF-TAG"),
        ("LET_TAG", "LET-TAG"),
        ("MODULE_TAG", "MODULE-TAG"),
        ("REQUIRE_TAG", "REQUIRE-TAG"),
        ("PERFORM_TAG", "PERFORM-TAG"),
        ("HANDLE_TAG", "HANDLE-TAG"),
    ] {
        assert_eq!(symbol_name(ident), symbol);
    }
    // Identity faces.
    assert_eq!(symbol_name("eq"), "eq");
    assert_eq!(symbol_name("assoc"), "assoc");
    assert_eq!(symbol_name("_"), "_");
}

/// Production wiring liveness: after a check judgment the
/// production HM path is the loaded self-hosted payload (the bridge now
/// loads check.ktf through compile_front_seed — the r150/220-b
/// switch's empirical anchor, mirroring the cli.krf
/// production_cli_is_bootstrap liveness shape; the target user face is
/// the sole face since the E6 S-expr demolition).
#[test]
fn check_ktf_production_wiring_liveness() {
    let report = check_source_recover("fn f(x: i64) -> i64 { x + 1 }\nf(2)", "live.ktf")
        .expect("clean program must check");
    assert!(report.diagnostics.is_empty());
    assert!(
        production_check_is_krf(),
        "the production judgment face must be the self-hosted payload path"
    );
}

/// Cross-stage E2E (target face, post-E6): a type-error program through
/// the target user face → the diagnostic count + message families of the
/// production HM judgment (the verdict flows through check.ktf — the
/// self-hosted engine implements the judgment once; the S-expr twin leg
/// retired with the deleted S-expr driver face).
#[test]
fn check_cross_stage_dual_face_e2e() {
    let ktf_src = "fn f(x: T) { x + \"a\" }\nf(1)";
    let rt = check_source_recover(ktf_src, "cross.ktf")
        .expect("recovery-mode check returns a report for type errors");
    assert!(
        !rt.diagnostics.is_empty(),
        "the target face must report the + str violation"
    );
    let joined_t = rt.rendered.join("\n");
    for want in ["requires", "a number"] {
        assert!(
            joined_t.contains(want),
            "the target face must carry the op+got family {} (ktf: {})",
            want,
            joined_t
        );
    }
}

/// A clean .ktf corpus program checks clean through the production path
/// (the positive judgment face — proto/const/global/instruction counts
/// reported).
#[test]
fn check_ktf_corpus_face_clean() {
    let src = "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(4)";
    let report =
        check_source_recover(src, "fib.ktf").expect("clean target-face program must check");
    assert!(
        report.diagnostics.is_empty(),
        "clean corpus must carry zero diagnostics (actual: {:?})",
        report.rendered
    );
    assert!(report.proto_count >= 1);
    assert!(report.instruction_count > 0);
}

/// The r126 multi-error collection shape through the target user face:
/// two items with independent violations → two diagnostics in source
/// order (the item-level recovery anchor, dual-face).
#[test]
fn check_ktf_multi_error_collection_shape() {
    let src = "fn a(x: T) { x + \"s\" }\nfn b(y: T) { not(y) }\na(1)\nb(2)";
    let report =
        check_source_recover(src, "multi.ktf").expect("recovery-mode check returns a report");
    assert!(
        report.diagnostics.len() >= 2,
        "independent item violations must collect (actual: {:?})",
        report.rendered
    );
    // Source order: the + violation (item a) precedes the not violation
    // (item b's rule fires at the call site — both orders carry the
    // two-family evidence).
    let joined = report.rendered.join("\n");
    assert!(
        joined.contains("requires"),
        "op+got family present: {}",
        joined
    );
}

// ---------------------------------------------------------------------------
// Batch B negatives (24 — the check-shaped fail-closed family through the
// target user face: the HM judgment rejections across the signature-rule
// / arity / occurs / positional / protocol classes; every diagnostic
// must carry the "(static check)" honest-boundary marker)
// ---------------------------------------------------------------------------

/// Helper: recovery-mode target-face check → rendered diagnostic text
/// (non-empty required).
fn check_neg(src: &str, what: &str) -> String {
    match check_source_recover(src, "neg.ktf") {
        Ok(report) => {
            assert!(
                !report.diagnostics.is_empty(),
                "[{}] expected a static diagnostic, got clean (report: {} protos)",
                what,
                report.proto_count
            );
            report.rendered.join("\n")
        }
        Err(e) => {
            // Driver-level errors (read/R9 short-circuits) also count as
            // rejections — rendered text carries the family evidence.
            e.rendered
        }
    }
}

/// Negative 1 (occurs): the self-application shape — unifying α with an
/// arrow containing α trips occurs.
#[test]
fn neg_hm_occurs_self_application() {
    let m = check_neg("fn bad(f: T) { f(f) }\nbad(1)", "self-application occurs");
    assert!(
        m.contains("infinite type"),
        "occurs family must name the infinite type (actual: {})",
        m
    );
}

/// Negative 2 (occurs): the let-cycle shape.
#[test]
fn neg_hm_occurs_let_cycle() {
    let m = check_neg(
        "fn go(x: T) { let y = cons(x, y); y }\ngo(1)",
        "let occurs cycle",
    );
    assert!(
        !m.is_empty(),
        "the let occurs shape must report (actual: {})",
        m
    );
}

/// Negative 3 (unify): the tvar-constraint flow — not's bool rule pins
/// the parameter, then an int call-site argument trips the unify
/// mismatch family.
#[test]
fn neg_hm_type_mismatch_unify() {
    let m = check_neg("fn f(x: T) { not(x) }\nf(1)", "type mismatch unify");
    assert!(
        m.contains("type mismatch"),
        "mismatch family present (actual: {})",
        m
    );
    assert!(m.contains("static check"), "honest marker (actual: {})", m);
}

/// Negative 4 (arity under-min): mod needs ≥2 args (the call-form
/// builtin — the infix operators are structurally binary on the target
/// face, so the under-min family rides the call form).
#[test]
fn neg_hm_builtin_arity_under_min_div() {
    let m = check_neg("fn f(x: T) { mod(x) }\nf(1)", "mod under-min arity");
    assert!(m.contains("argument count"), "arity family (actual: {})", m);
    assert!(m.contains("static check"), "honest marker (actual: {})", m);
}

/// Negative 5 (arity over-max): `not` is fixed 1-arg.
#[test]
fn neg_hm_builtin_arity_over_max_not() {
    let m = check_neg(
        "fn f(a: T, b: T) { not(a, b) }\nf(true, false)",
        "not over-max arity",
    );
    assert!(m.contains("argument count"), "arity family (actual: {})", m);
    assert!(m.contains("static check"), "honest marker (actual: {})", m);
}

/// Negative 6 (fixed arity): read-line is fixed 0-arg (the r144 anchor;
/// the read capability is declared so the R9 gate passes and the HM
/// arity face fires).
#[test]
fn neg_hm_builtin_arity_fixed_read_line() {
    let m = check_neg(
        "require io, read;\nfn f(x: T) { read_line(x) }\nf(1)",
        "read-line fixed arity",
    );
    assert!(
        m.contains("argument count"),
        "read-line fixed 0-arity (actual: {})",
        m
    );
}

/// Negative 7 (fixed arity): newline is fixed 0-arg (the write capability
/// declared so the R9 gate passes and the HM arity face fires).
#[test]
fn neg_hm_builtin_arity_fixed_newline() {
    let m = check_neg(
        "require io, write;\nfn f(x: T) { newline(x) }\nf(1)",
        "newline fixed arity",
    );
    assert!(
        m.contains("argument count"),
        "newline fixed 0-arity (actual: {})",
        m
    );
}

/// Negative 8 (num rule): + with a str argument.
#[test]
fn neg_hm_builtin_rule_num_plus_str() {
    let m = check_neg("fn f(x: T) { x + \"a\" }\nf(1)", "plus num rule");
    assert!(
        m.contains("+ requires a number"),
        "num rule op+got (actual: {})",
        m
    );
}

/// Negative 9 (bool rule): not with a concrete int argument (the
/// concrete-violation arm records the op+got message; the tvar arm is
/// the unify family — negative 3).
#[test]
fn neg_hm_builtin_rule_bool_not_int() {
    let m = check_neg("fn f() { not(1) }\nf()", "not bool rule");
    assert!(
        m.contains("not requires bool"),
        "bool rule op+got (actual: {})",
        m
    );
}

/// Negative 10 (str rule): string_length with an int argument (the
/// target-face identifier — the S-expr `string-length` maps through the
/// `_` skin entry).
#[test]
fn neg_hm_builtin_rule_str_length_int() {
    let m = check_neg(
        "import kerf_string;\nfn f() { string_length(1) }\nf()",
        "string-length str rule",
    );
    assert!(
        m.contains("string-length requires str"),
        "str rule op+got (actual: {})",
        m
    );
}

/// Negative 11 (sym rule): symbol_to_string with an int argument.
#[test]
fn neg_hm_builtin_rule_sym_symbol_to_string_int() {
    let m = check_neg(
        "import kerf_string;\nfn f() { symbol_to_string(1) }\nf()",
        "symbol-to-string sym rule",
    );
    assert!(
        m.contains("symbol-to-string requires symbol"),
        "sym rule op+got (actual: {})",
        m
    );
}

/// Negative 12 (head special): head on a concrete non-pair (the pair-rule
/// passes tvars — the A4 conservative family — so the concrete arm owns
/// the diagnostic).
#[test]
fn neg_hm_head_requires_pair_int() {
    let m = check_neg("fn f() { head(1) }\nf()", "head pair special");
    assert!(
        m.contains("head requires pair"),
        "head special (actual: {})",
        m
    );
}

/// Negative 13 (tail special): tail on a concrete non-pair.
#[test]
fn neg_hm_tail_requires_pair_int() {
    let m = check_neg("fn f() { tail(1) }\nf()", "tail pair special");
    assert!(
        m.contains("tail requires pair"),
        "tail special (actual: {})",
        m
    );
}

/// Negative 14 (uncallable): applying a concrete int value (a non-
/// syntactic-value define binds mono through the cons special's concrete
/// tpair — the var-head conservative family stays out; the concrete head
/// owns the uncallable diagnostic).
#[test]
fn neg_hm_uncallable_int_head() {
    let m = check_neg("let g = head(cons(1, 2));\ng(1)", "uncallable int");
    assert!(
        m.contains("uncallable value"),
        "uncallable family (actual: {})",
        m
    );
}

/// Negative 15 (if condition): a concrete non-bool condition (the tvar
/// arm unifies to bool — the concrete arm records the op+got family).
#[test]
fn neg_hm_if_cond_requires_bool() {
    let m = check_neg("fn f() { if (1) { 2 } else { 3 } }\nf()", "if cond bool");
    assert!(
        m.contains("if condition requires bool"),
        "if condition family (actual: {})",
        m
    );
}

/// Negative 16 (sigf pos-1): nth's first position requires a list — a
/// concrete int argument (the tvar arm imposes no constraint per the
/// r140 domain specialization; the prelude import declares the N1 face
/// so the HM positional rule fires).
#[test]
fn neg_hm_sigf_nth_pos1_non_list() {
    // r164/235-c: nth's static positional rows retired with the self-built
    // migration — the (T,T) unification of (int, int) is clean; the runtime
    // face enforces the non-list input (the exact retired-Rust message).
    let e16 = kerf_driver::run_source(
        "import kerf_prelude;\nfn f() { nth(1, 0) }\nf()",
        "neg16rt.ktf",
    )
    .expect_err("neg16 run must fail");
    assert!(
        e16.rendered.contains("nth index 0 out of list range"),
        "runtime positional rule (actual: {})",
        e16.rendered
    );
}

/// Negative 17 (sigf pos-2): nth's second position requires an int — a
/// concrete str argument (the tvar arm constrains to the Num domain and
/// reports at the call site through the unify family; the concrete arm
/// owns the positional op+got message).
#[test]
fn neg_hm_sigf_nth_pos2_non_int() {
    // r164/235-c: the static face generalizes to the num/str unification
    // conflict (fail-closed maintained); the runtime face carries the exact
    // retired-Rust message.
    let m = check_neg(
        "import kerf_prelude;\nfn f() { nth(list(1, 2), \"a\") }\nf()",
        "nth pos-2 int rule",
    );
    assert!(
        m.contains("type mismatch"),
        "static unification face (actual: {})",
        m
    );
    let e17 = kerf_driver::run_source(
        "import kerf_prelude;\nfn f() { nth(list(1, 2), \"a\") }\nf()",
        "neg17rt.ktf",
    )
    .expect_err("neg17 run must fail");
    assert!(
        e17.rendered.contains("nth index requires int, got str"),
        "runtime positional rule (actual: {})",
        e17.rendered
    );
}

/// Negative 18 (sigf pos-2): member's second position requires a list —
/// a concrete int argument (the tvar arm imposes no constraint per the
/// r140 domain specialization; the kerf-list import declares the N1
/// face).
#[test]
fn neg_hm_sigf_member_pos2_non_list() {
    let m = check_neg(
        "import kerf_list;\nfn f() { member(1, 2) }\nf()",
        "member pos-2 list rule",
    );
    assert!(
        m.contains("member requires list"),
        "sigf positional rule (actual: {})",
        m
    );
}

/// Negative 19 (sigf pos-2): string_substring's second position requires
/// an int — a concrete str argument (the kerf-string import declares the
/// N1 face).
#[test]
fn neg_hm_sigf_string_substring_pos2_non_int() {
    let m = check_neg(
        "import kerf_string;\nfn f() { string_substring(\"ab\", \"x\", 1) }\nf()",
        "string-substring pos-2 int rule",
    );
    assert!(
        m.contains("string-substring requires int"),
        "sigf positional rule (actual: {})",
        m
    );
}

/// Negative 20 (r140 divergence fix): string_append is fixed 2-arg — a
/// 3-arg call fails statically (the kerf-string import declares the N1
/// face).
#[test]
fn neg_hm_string_append_arity_divergence() {
    let m = check_neg(
        "import kerf_string;\nfn f(a: T, b: T, c: T) { string_append(a, b, c) }\nf(\"x\", \"y\", \"z\")",
        "string-append fixed 2-arg",
    );
    assert!(
        m.contains("argument count"),
        "string-append fixed arity (actual: {})",
        m
    );
}

/// Negative 21 (module body): a type error inside a module item is
/// checked (module body items recurse).
#[test]
fn neg_hm_module_item_type_error() {
    let m = check_neg(
        "module m { fn g(x: T) { x + \"s\" } }\n1",
        "module body type error",
    );
    assert!(
        m.contains("requires"),
        "module-body judgment (actual: {})",
        m
    );
}

/// Negative 22 (r126 axis ②): a failed define still binds — a later call
/// site gets its own diagnostic (the failed-define absorption anchor).
#[test]
fn neg_hm_failed_define_later_reference() {
    let m = check_neg(
        "fn bad(f: T) { f(f) }\nbad(1)\nbad(2)",
        "failed define later references",
    );
    // The occurs diagnostic on the define + the later call-site diagnostic
    // both land (count ≥ 2 — the axis-② anchor: later references are NOT
    // silently absorbed).
    assert!(
        m.matches("error").count() >= 1 && (m.contains("infinite type") || m.contains("requires")),
        "failed-define absorption anchor (actual: {})",
        m
    );
}

/// Negative 23 (r126 axis ①): within-item multiple violations collect
/// (per-argument rule continuation — ≥2 diagnostics from one item).
#[test]
fn neg_hm_within_item_multi_violation() {
    let m = check_neg(
        "fn f(a: T, b: T) { a + b }\nf(\"x\", true)",
        "within-item multi violation",
    );
    assert!(
        m.contains("type mismatch") || m.contains("requires"),
        "within-item collection (actual: {})",
        m
    );
    assert!(m.contains("static check"), "honest marker (actual: {})", m);
}

/// Negative 24 (keyword normalization negative anchor — the Batch B
/// record): quote(fn) on the target face is a parse error (KwFn is
/// reserved — the motivating gap for the bilateral TAG normalization;
/// mirrors switch_corpus_parity_tests' r116 anchor).
#[test]
fn neg_hm_quote_keyword_tag_parse_error() {
    let mut t0 = SymbolTable::new();
    let r = read_source("fn bad() { quote(fn) }", 0, &mut t0);
    assert!(
        r.is_err(),
        "quote(fn) must be a parse error (KwFn reserved word cannot enter an expression position)"
    );
}

// ---------------------------------------------------------------------------
// r151 / 221-c — Batch C lexer-leg gate faces (reader.ktf — the production
// .ktf read bridge's own lexer expressed in the target language: the
// Reader fixpoint milestone first leg; s-expr-removal-plan §4 Batch C
// [r151-r152 two-round split] + §5 gate C lexer leg).
// r152 / 222-c — Batch C parser-leg re-base: the payload covers the whole
// program (lexer + parser segments).
// E6 close-out (r154 / 224-b3): the .krf full-oracle parity leg retired
// (duty complete — principle 41 demolition after validation); the artifact
// was renamed reader.ktf → reader.ktf (224-a — the bootstrap
// directory's sole Reader file); the surviving faces below are all
// .ktf-only payload-integrity anchors.
// ---------------------------------------------------------------------------

/// The read bridge's own program — the full target-syntax Reader
/// (lexer + parser segments; renamed from reader.ktf at the E6
/// close-out [224-a] — content unchanged, the shape anchor's r152 numbers
/// carry over verbatim).
const TARGET_READER_KTF: &str =
    include_str!("../../../../crates/kerf-driver/src/bootstrap/reader.ktf");

/// Entry face: the .ktf payload's resolved global-reference face carries
/// the bridge entry (lex-target — the top-level fn define form lands in
/// the global table; the bridge queries `table.intern("lex")`
/// and must resolve to the compiled closure).
#[test]
fn payload_lex_entry_proto_face() {
    let (pb, tb) = payload_ktf(TARGET_READER_KTF, "reader.ktf");
    let face = resolved_names(&pb.global_refs, &tb);
    assert!(
        face.iter().any(|n| n == "lex"),
        "entry global lex-target missing (global face: {:?})",
        face
    );
}

/// Builtin consumption face: the payload's global reference face carries
/// the resolved builtin consumption list (head/tail/cons/eq/member/reverse/
/// string-append/string-contains/string-to-pos-chars/char-is-whitespace —
/// the kerf-list + kerf-string mapped consumption; .ktf-only post-E6).
#[test]
fn payload_lex_builtin_consumption_face() {
    let (pb, tb) = payload_ktf(TARGET_READER_KTF, "reader.ktf");
    let fb = resolved_names(&pb.global_refs, &tb);
    // The charset-table and CAP constants are payload-local globals (define
    // forms) — pinned by name in the charset face below; here we assert the
    // builtin consumption core (the mapped module surface).
    for required in [
        "head",
        "tail",
        "cons",
        "eq",
        "member",
        "reverse",
        "string-append",
        "string-contains",
        "string-to-pos-chars",
        "char-is-whitespace",
    ] {
        assert!(
            fb.contains(&required.to_string()),
            "reader.ktf global face missing builtin {} (face: {:?})",
            required,
            fb
        );
    }
}

/// Charset constants face (lexer-segment specific): the payload's global
/// reference face carries the seven charset/bound tables and the four CAP
/// overflow guards (the digit / keyword / radix tables are the lexer's
/// data spine; .ktf-only post-E6).
#[test]
fn payload_lex_charset_constants_face() {
    let (pb, tb) = payload_ktf(TARGET_READER_KTF, "reader.ktf");
    let fb = resolved_names(&pb.global_refs, &tb);
    for table_name in [
        "DIGITS",
        "ALPHA",
        "HEX-DIGITS",
        "OCT-DIGITS",
        "BIN-DIGITS",
        "TKEYWORDS",
        "CAP10",
        "CAP16",
        "CAP8",
        "CAP2",
    ] {
        assert!(
            fb.contains(&table_name.to_string()),
            "reader.ktf global face missing table {} (face: {:?})",
            table_name,
            fb
        );
    }
}

/// Naming-map roundtrip (lexer leg): the entry identifier + sampled
/// internal fn names land in the global-reference face with their
/// kebab-cased seed symbols — `lex` interns as `lex-target` (the
/// naming-map `_`→`-` single-point boundary at symbol introduction).
#[test]
fn payload_naming_map_roundtrip_lex() {
    let (pb, tb) = payload_ktf(TARGET_READER_KTF, "reader.ktf");
    let face = resolved_names(&pb.global_refs, &tb);
    for sample in [
        "lex",
        "lex-loop",
        "lex-op",
        "scan-number",
        "scan-word",
        "tscan-string",
        "tskip-block",
        "num-scan",
        "emit1",
        "emit2",
        "rderr",
        "tok-end",
    ] {
        assert!(
            face.iter().any(|n| n == sample),
            "sampled global {} missing (global face: {:?})",
            sample,
            face
        );
    }
    // Identity face: the mapping is a pure `-`/`_` swap.
    assert_eq!(symbol_name("lex"), "lex");
    assert_eq!(symbol_name("cur_char"), "cur-char");
}

/// Production liveness: the CLI dump-tokens face goes through the bridge
/// lexer entry, which since r151 loads reader.ktf (the seed target
/// Reader reads the .ktf payload — the Reader fixpoint milestone first
/// leg). A real corpus fragment must lex through the production path.
#[test]
fn lexc_bridge_production_liveness() {
    let out = kerf_driver::dump_tokens("fn add(a: T, b: T) { a + b }", "live.ktf")
        .expect("production lexer path must lex a real corpus fragment");
    assert!(
        out.contains("fn") && out.contains("add") && out.contains("+"),
        "token surface must carry the corpus tokens (actual: {})",
        out
    );
}

/// Determinism: the same source lexed twice through the .ktf bridge entry
/// yields byte-identical surfaces (the thread-local state reuse path). The
/// radix payloads render as value texts (the bridge's same-source parse —
/// int:255 / int:5, not the radix-marked spelling).
#[test]
fn lexc_bridge_determinism_dual_run() {
    let src = "let x = 0xFF + 0b101; // comment\n/* nested /* block */ */ x";
    let a = kerf_driver::dump_tokens(src, "det.ktf").unwrap();
    let b = kerf_driver::dump_tokens(src, "det.ktf").unwrap();
    assert_eq!(a, b, "dual-run surfaces must be byte-identical");
    assert!(
        a.contains("int:255") && a.contains("int:5"),
        "radix value payload surface must survive the bridge (actual: {})",
        a
    );
    assert!(
        !a.contains("comment"),
        "comments must be skipped by the lexer (actual: {})",
        a
    );
}

/// Token-stream snapshot anchor: a fixed corpus fragment's canonical token
/// surface (kind[:payload] + Span columns — the dump-tokens caliber) is
/// pinned — the .ktf Reader lexer's production output is a stable surface.
#[test]
fn lexc_token_stream_snapshot_anchor() {
    let out = kerf_driver::dump_tokens("fn f(x: T) { 1 + 2 }", "snap.ktf").unwrap();
    let lines: Vec<&str> = out.lines().filter(|l| !l.trim().is_empty()).collect();
    // fn(0..2) ident:f(3..4) ((4..5) ident:x(5..6) :(6..7) ident:T(8..9) ...
    // a compact-but-real anchor: the first five and the last three tokens.
    let first: Vec<&str> = lines[..5].to_vec();
    assert_eq!(
        first,
        vec![
            "   0..2    fn",
            "   3..4    ident:f",
            "   4..5    (",
            "   5..6    ident:x",
            "   6..7    :"
        ],
        "first-five token surface (actual: {:?})",
        first
    );
    let tail: Vec<&str> = lines[lines.len() - 3..].to_vec();
    assert_eq!(
        tail,
        vec!["  17..18   int:2", "  19..20   }", "  20..20   eof"],
        "last-three token surface (actual: {:?})",
        tail
    );
}

// ---------------------------------------------------------------------------
// r152 / 222-c — Batch C parser-leg gate faces (the grammar segment: the
// Reader fixpoint milestone closure — the bridge's parser entry now loads
// the .ktf rewrite; s-expr-removal-plan §4 Batch C parser leg + §5 gate C
// + gate Z fixpoint; the user r152 directive's Rust-side consolidation
// leg is pinned by the single-state dual-entry faces below)
// ---------------------------------------------------------------------------

/// Grammar entry face: the parser entry (parse-target) resolves in the
/// .ktf payload's global face — since r152 both bridge entries
/// (lex-target / parse-target) live in ONE loaded program (the r151
/// dual-state interim collapsed).
#[test]
fn payload_grammar_entry_proto_face() {
    let (pb, tb) = payload_ktf(TARGET_READER_KTF, "reader.ktf");
    let face = resolved_names(&pb.global_refs, &tb);
    for entry in ["lex", "parse"] {
        assert!(
            face.iter().any(|n| n == entry),
            "entry global {} missing (global face: {:?})",
            entry,
            face
        );
    }
}

/// kcell factory face (the conversion-discipline fourth anchor — the
/// r152/222-a normalization): the kcell-make factory + the kcell define
/// call form + the kset/kget accessors land in the payload's global
/// face (the factory shape the target face expresses; the
/// closures.ktf make-counter precedent; .ktf-only post-E6).
#[test]
fn payload_kcell_factory_face() {
    let (pb, tb) = payload_ktf(TARGET_READER_KTF, "reader.ktf");
    let fb = resolved_names(&pb.global_refs, &tb);
    for name in ["kcell-make", "kcell", "kset", "kget"] {
        assert!(
            fb.contains(&name.to_string()),
            "reader.ktf global face missing {} (face: {:?})",
            name,
            fb
        );
    }
}

/// Naming-map roundtrip (parser leg): sampled grammar-segment fn names
/// land in the global face with their kebab-cased seed symbols —
/// `parse_target` interns as `parse-target` (the naming-map boundary at
/// symbol introduction, grammar-segment samples).
#[test]
fn payload_grammar_naming_roundtrip() {
    let (pb, tb) = payload_ktf(TARGET_READER_KTF, "reader.ktf");
    let face = resolved_names(&pb.global_refs, &tb);
    for sample in [
        "parse",
        "program-loop",
        "parse-item",
        "parse-module-decl",
        "parse-import-decl",
        "parse-extern-decl",
        "parse-use-decl",
        "parse-macro-decl",
        "parse-fn-decl",
        "parse-typed-params",
        "consume-type",
        "parse-block",
        "block-loop",
        "block-thread",
        "parse-let-stmt",
        "parse-if",
        "parse-perform",
        "parse-handle",
        "handle-arm",
        "handle-fold",
        "parse-resume-call",
        "parse-match",
        "parse-pattern-or",
        "parse-expr",
        "parse-unary",
        "parse-postfix",
        "parse-primary",
        "parse-closure-body",
    ] {
        assert!(
            face.iter().any(|n| n == sample),
            "sampled grammar global {} missing (global face: {:?})",
            sample,
            face
        );
    }
}

/// Builtin consumption face (parser leg): the grammar segment's newly
/// consumed builtins — `append` (thread-loop let threading), `is-pair`
/// (parse-target error-shape discrimination), `length` (handle-arm
/// binder arity guard) — in the payload's global face (.ktf-only
/// post-E6).
#[test]
fn payload_grammar_builtin_consumption_face() {
    let (pb, tb) = payload_ktf(TARGET_READER_KTF, "reader.ktf");
    let fb = resolved_names(&pb.global_refs, &tb);
    for required in ["append", "is-pair", "length"] {
        assert!(
            fb.contains(&required.to_string()),
            "reader.ktf global face missing builtin {} (face: {:?})",
            required,
            fb
        );
    }
}

/// Full-payload shape anchor: the payload's proto / const / global
/// counts (209 / 488 / 240 — the r152 full-file conversion shape,
/// re-based .ktf-only at the E6 close-out [224-b3] when the .krf oracle
/// leg retired; the artifact was renamed reader.ktf → reader.ktf
/// with content unchanged, so the numbers carry over verbatim — any
/// accidental payload growth fails here, the growth-signature anchor).
#[test]
fn payload_full_shape_anchor() {
    // r158 / 228-c recalibration: the mirror's parse_toplevel_let +
    // parse_item arms (the define retirement + the toplevel let) add
    // one proto / three consts / one global ref
    // r160 / 230-c recalibration: the mirror's parse_tuple_tail (the
    // TD-036 tuple expression window — the fifteenth skin mapping) adds
    // one proto / three consts / one global ref (the same single-function
    // growth signature as the r158 parse_toplevel_let arm)
    // r161 / 231-c recalibration: the const-declaration window (the
    // sixteenth skin mapping) adds four protos (const_has /
    // const_remove / const_add / parse_const_decl) / ten consts (the
    // helper-family literals + the "const" kind strings) / five global
    // refs (CONST_NAMES + the helper-family name references) — the
    // multi-function growth signature of the sequential const set
    // r162 / 233-c recalibration: the equality-domain window (TD-037)
    // re-points the == / != skins from the `=` symbol to the `eq`
    // terminal name — zero protos (no new functions), zero consts (the
    // "eq" op string was already interned; the "=" string stays via the
    // lexer char comparisons), and ONE global ref DROPS (the `=` symbol
    // loses its last two references — cmp_make's == and != sites — so
    // its deduplicated entry retires from the payload's reference table)
    // r163 / 234-c recalibration: the index-access window (the
    // seventeenth skin mapping) opens the postfix `[` arm inside the
    // existing postfix_loop — ZERO protos (inlined into the existing
    // function), ZERO consts (the retiring domain-out message string
    // "index(collection type out of domain)" vacates a slot exactly
    // filled by the incoming "vector-ref" nd_sym literal — one in, one
    // out), ZERO global refs (nd_sym/nd_lst/p_expect/parse_expr are all
    // pre-existing payload references)
    // r165 / 236-b recalibration: the variadic-rest window adds the
    // `rest_param_tail` helper fn to the seed reader mirror (+1 proto);
    // +3 consts (the rest-marker `...` string literal, the "expected `:`"
    // reuse ride plus the rest-specific error message strings) and +1
    // global ref (the helper's fresh tail-call target symbol joins the
    // payload's deduplicated reference table).
    let (pb, _) = payload_ktf(TARGET_READER_KTF, "reader.ktf");
    assert_eq!(pb.protos.len(), 216, "proto count anchor (r165)");
    assert_eq!(pb.consts.len(), 507, "const count anchor (r165)");
    assert_eq!(pb.global_refs.len(), 247, "global-ref count anchor (r165)");
}

/// Stx-tree canonical rendering (the target_reader_krf_tests caliber,
/// shared verbatim — symbol names + literal values + Span bytes).
fn render_stx(s: &Stx, t: &SymbolTable) -> String {
    let mut out = String::new();
    render_stx_into(s, t, &mut out);
    out
}

fn render_stx_into(s: &Stx, t: &SymbolTable, out: &mut String) {
    match &s.datum {
        StxDatum::Symbol(sym) => {
            out.push_str(&format!(
                "(sym {} {}..{})",
                t.name(*sym),
                s.span.start,
                s.span.end
            ));
        }
        StxDatum::Literal(l) => match l {
            StxLiteral::Int(v) => {
                out.push_str(&format!("(int {} {}..{})", v, s.span.start, s.span.end));
            }
            StxLiteral::Float(f) => {
                out.push_str(&format!("(float {:?} {}..{})", f, s.span.start, s.span.end));
            }
            StxLiteral::Str(r) => {
                out.push_str(&format!("(str {:?} {}..{})", r, s.span.start, s.span.end));
            }
            StxLiteral::Bool(b) => {
                out.push_str(&format!("(bool {} {}..{})", b, s.span.start, s.span.end));
            }
            StxLiteral::Nil => {
                out.push_str(&format!("(nil {}..{})", s.span.start, s.span.end));
            }
        },
        StxDatum::List(items) => {
            out.push_str(&format!("(lst {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
        StxDatum::Vector(_) => out.push_str("(vector)"),
    }
}

/// Gate Z fixpoint (the Reader fixpoint milestone closure): the
/// production read bridge — reader.ktf compiled and running on
/// the VM — parses reader.ktf's OWN source; the canonical Stx
/// rendering is byte-identical to the seed Rust target Reader's parse of
/// the same text (the self-hosting Reader reads itself, the strongest
/// fixpoint form available at this stage).
#[test]
fn fixpoint_self_parse_stx_parity() {
    let mut t1 = SymbolTable::new();
    let seed = read_source(TARGET_READER_KTF, 0, &mut t1)
        .unwrap_or_else(|e| panic!("seed parse of reader.ktf failed: {}", e.message));
    let mut t2 = SymbolTable::new();
    let bridge = read_source_for_bootstrap(TARGET_READER_KTF, 0, &mut t2)
        .unwrap_or_else(|e| panic!("bridge self-parse failed: {}", e.message));
    assert_eq!(
        seed.len(),
        bridge.len(),
        "self-parse top-level item count mismatch (seed {} vs bridge {})",
        seed.len(),
        bridge.len()
    );
    for (i, (a, b)) in seed.iter().zip(bridge.iter()).enumerate() {
        assert_eq!(
            render_stx(a, &t1),
            render_stx(b, &t2),
            "self-parse top-level item #{} canonical render mismatch (the fixpoint gate)",
            i
        );
    }
}

/// Parser-bridge determinism: the same source parsed twice through the
/// production bridge (the single thread-local state's reuse path) yields
/// byte-identical canonical renderings.
#[test]
fn parser_bridge_determinism_dual_run() {
    let src = "fn add(a: T, b: T) { a + b }\nmodule m { fn f(x: T) { x * 2 } }\nadd(2, 3)";
    let mut t1 = SymbolTable::new();
    let a = read_source_for_bootstrap(src, 0, &mut t1).unwrap();
    let mut t2 = SymbolTable::new();
    let b = read_source_for_bootstrap(src, 0, &mut t2).unwrap();
    let ra: Vec<String> = a.iter().map(|s| render_stx(s, &t1)).collect();
    let rb: Vec<String> = b.iter().map(|s| render_stx(s, &t2)).collect();
    assert_eq!(
        ra, rb,
        "dual-run canonical renderings must be byte-identical"
    );
}

/// Parser Stx snapshot anchor: a fixed fragment's canonical rendering is
/// pinned (the parser's production output is a stable surface — the
/// mirror of the lexer-leg token snapshot anchor).
#[test]
fn parser_stx_snapshot_anchor() {
    let src = "fn f(x: T) { x + 1 }";
    let mut t = SymbolTable::new();
    let forms = read_source_for_bootstrap(src, 0, &mut t).unwrap();
    assert_eq!(
        forms.len(),
        1,
        "one top-level item (actual: {})",
        forms.len()
    );
    assert_eq!(
        render_stx(&forms[0], &t),
        "(lst 0..18 [(sym define 0..2) (lst 3..4 [(sym f 3..4) (sym x 5..6)]) (lst 13..18 [(sym + 15..16) (sym x 13..14) (int 1 17..18)])])",
        "parser canonical-render snapshot (actual differs)"
    );
}

// ---------------------------------------------------------------------------
// Batch C lexer-leg negatives (23 — the target-face lexical / grammar /
// depth fail-closed family through the production .ktf read path; several
// double as boundary anchors of the overflow guards and the r149 target
// Reader depth cap)
// ---------------------------------------------------------------------------

/// Negative 1: unterminated string.
#[test]
fn neg_lexc_unterminated_string() {
    let err = run_source("define(s, \"abc);\ns", "neg.ktf")
        .expect_err("unterminated string is a lexical fail-closed");
    assert!(
        err.to_string().contains("unclosed string"),
        "diagnostic must name unclosed string (actual: {})",
        err
    );
}

/// Negative 2: illegal escape character.
#[test]
fn neg_lexc_illegal_escape_char() {
    let err = run_source("let s = \"a\\qb\";\ns", "neg.ktf")
        .expect_err("illegal escape is a lexical fail-closed");
    assert!(
        err.to_string().contains("illegal escape"),
        "diagnostic must name the illegal escape (actual: {})",
        err
    );
}

/// Negative 3: unterminated block comment.
#[test]
fn neg_lexc_unterminated_block_comment() {
    let err = run_source("/* outer /* inner never closes\n1", "neg.ktf")
        .expect_err("unterminated block comment is a lexical fail-closed");
    assert!(
        err.to_string().contains("unclosed block comment"),
        "diagnostic must name the unclosed block comment (actual: {})",
        err
    );
}

/// Negative 4: integer literal overflow (i64 max + 1 — the T/R exact-bound
/// guard's hard boundary).
#[test]
fn neg_lexc_integer_overflow_i64_bound() {
    let err = run_source("let x = 9223372036854775808;\nx", "neg.ktf")
        .expect_err("i64max+1 must overflow at the lexer's exact-bound guard");
    assert!(
        err.to_string().contains("integer literal overflow"),
        "diagnostic must name the overflow (actual: {})",
        err
    );
}

/// Negative 5: float with double '.' (the float-text-bad syntactic
/// signature).
#[test]
fn neg_lexc_float_double_dot() {
    let err = run_source("let x = 1.2.3;\nx", "neg.ktf")
        .expect_err("double-dot float is invalid (float_text_bad face)");
    assert!(
        err.to_string().contains("invalid float literal"),
        "diagnostic must name the invalid float (actual: {})",
        err
    );
}

/// Negative 6: float with '.' after the exponent.
#[test]
fn neg_lexc_float_dot_after_exponent() {
    let err = run_source("let x = 1e2.3;\nx", "neg.ktf")
        .expect_err("'.' after e is invalid (float_text_bad face)");
    assert!(
        err.to_string().contains("invalid float literal")
            || err.to_string().contains("illegal character"),
        "diagnostic must name the float family (actual: {})",
        err
    );
}

/// Negative 7: illegal character '#'.
#[test]
fn neg_lexc_illegal_char_hash() {
    assert!(
        run_source("let x = #;\nx", "neg.ktf").is_err(),
        "'#' is outside the target charset — illegal character"
    );
}

/// Negative 8: illegal character '@'.
#[test]
fn neg_lexc_illegal_char_at() {
    let err =
        run_source("let x = @;\nx", "neg.ktf").expect_err("'@' is outside the target charset");
    assert!(
        err.to_string().contains("illegal character"),
        "diagnostic must name the illegal character (actual: {})",
        err
    );
}

/// Negative 9: illegal character '`'.
#[test]
fn neg_lexc_illegal_char_backtick() {
    assert!(
        run_source("let x = `;\nx", "neg.ktf").is_err(),
        "'`' is outside the target charset (no quasiquote on the target face)"
    );
}

/// Negative 10: illegal character '~'.
#[test]
fn neg_lexc_illegal_char_tilde() {
    assert!(
        run_source("let x = ~;\nx", "neg.ktf").is_err(),
        "'~' is outside the target charset"
    );
}

/// Negative 11: backslash at EOF inside a string (the bs-off+2 virtual
/// escape calibration).
#[test]
fn neg_lexc_escape_eof_backslash() {
    let err = run_source("define(s, \"abc\\", "neg.ktf")
        .expect_err("backslash at EOF is a lexical fail-closed");
    assert!(
        err.to_string().contains("illegal escape"),
        "diagnostic must name the escape family (actual: {})",
        err
    );
}

/// Negative 12: multibyte illegal escape (the Span byte-calibration on
/// non-ASCII content).
#[test]
fn neg_lexc_illegal_escape_multibyte() {
    let err = run_source("let s = \"héllo\\q9\";\ns", "neg.ktf")
        .expect_err("illegal escape after multibyte content");
    assert!(
        err.to_string().contains("illegal escape"),
        "diagnostic must name the escape family (actual: {})",
        err
    );
}

/// Negative 13: trailing `::` at the end of an operand (the flattening
/// look-ahead fails — the colons surface as stray operator tokens and the
/// parser rejects the form).
#[test]
fn neg_lexc_path_trailing_double_colon() {
    assert!(
        run_source("let x = a::;\nx", "neg.ktf").is_err(),
        "trailing :: must fail (path flattening look-ahead rejects)"
    );
}

/// Negative 14: `::` followed by a digit (not id-start — the flattening
/// look-ahead fails).
#[test]
fn neg_lexc_double_colon_then_digit() {
    assert!(
        run_source("let x = a::1;\nx", "neg.ktf").is_err(),
        "a::1 must fail (:: requires an id-start continuation)"
    );
}

/// Negative 15: stray closing brace.
#[test]
fn neg_lexc_stray_rbrace() {
    assert!(
        run_source("fn f() { 1 }\n}\n1", "neg.ktf").is_err(),
        "stray closing brace at top level must fail"
    );
}

/// Negative 16: unclosed paren in an expression.
#[test]
fn neg_lexc_unclosed_paren_expr() {
    assert!(
        run_source("define(x, (1 + 2);\nx", "neg.ktf").is_err(),
        "unclosed paren must fail (lexical EOF inside a form)"
    );
}

/// Negative 17: fn body missing its closing brace.
#[test]
fn neg_lexc_fn_body_missing_brace() {
    assert!(
        run_source("fn f() { 1\n", "neg.ktf").is_err(),
        "fn body without a closing brace must fail"
    );
}

/// Negative 18: adjacent expression statements without a separator (`1 2`
// — expression statements must end with `;` or `}`).
#[test]
fn neg_lexc_adjacent_exprs_no_separator() {
    let err = run_source("fn f() { 1 2 }", "neg.ktf")
        .expect_err("adjacent expression statements must fail");
    assert!(
        err.to_string().contains("expected"),
        "diagnostic must name the expected-family (actual: {})",
        err
    );
}

/// Negative 19: stray else without a matching if.
#[test]
fn neg_lexc_stray_else() {
    assert!(
        run_source("fn f() { else { 1 } }", "neg.ktf").is_err(),
        "stray else must fail (else without a matching if)"
    );
}

/// Negative 20: let without '='.
#[test]
fn neg_lexc_let_missing_eq() {
    assert!(
        run_source("fn f() { let x 1; x }", "neg.ktf").is_err(),
        "let without '=' must fail"
    );
}

/// Negative 21: nesting depth over the cap — the block family (r149
/// TARGET_MAX_NESTING_DEPTH = 256, principle-58 depth guard: nested if
/// blocks through the Rust seed Reader's parse_block recursion).
#[test]
fn neg_lexc_depth_nested_blocks_over_cap() {
    let src = format!(
        "fn f() {{ {}1{}}}",
        "if (true) { ".repeat(300),
        "} ".repeat(300)
    );
    // Seed target Reader (the guarded face — the production read path's
    // parser guard; the VM-bridge path carries its own TD-023 frame cap)
    let mut sm = SourceMap::new();
    let fid = sm.add_file("neg.ktf", &src);
    let mut table = SymbolTable::new();
    let err = read_source(&src, fid, &mut table)
        .expect_err("300-deep if-block nesting must trip the 256 depth cap");
    assert!(
        err.message.contains("nesting depth exceeds the limit"),
        "diagnostic must name the depth-cap family (actual: {})",
        err.message
    );
}

/// Negative 23: keyword token in operand position (KwFn is reserved — an
/// expression operand cannot be a keyword token).
#[test]
fn neg_lexc_keyword_in_operand_position() {
    assert!(
        run_source("fn f(x: T) { 1 + fn }", "neg.ktf").is_err(),
        "keyword token as an operand must fail (reserved word in expression position)"
    );
}

/// Negative 24: multibyte string content then a lexical error — the error
/// Span carries byte offsets (the parity_unicode_span_precision caliber,
/// through the .ktf bridge).
#[test]
fn neg_lexc_multibyte_string_error_span() {
    let err = run_source("define(s, \"日本語テキスト);\ns", "neg.ktf")
        .expect_err("unterminated multibyte string must fail closed");
    assert!(
        err.to_string().contains("unclosed string"),
        "diagnostic must name unclosed string (actual: {})",
        err
    );
}

// ---------------------------------------------------------------------------
// r152 / 222-c — Batch C parser-leg negatives (24 — the grammar-segment
// fail-closed family through the production .ktf read path: every
// declaration family + statement/expression form of the newly converted
// parser segment, each asserting the specific diagnostic message family;
// these run through run_source → compile_front →
// read_source_for_bootstrap → reader.ktf on the VM — the
// Reader fixpoint closure's own rejection surface)
// ---------------------------------------------------------------------------

/// Negative g1: module declaration without a name identifier.
#[test]
fn neg_grm_module_name_not_ident() {
    let err = run_source("module { fn f() { 1 } }", "neg.ktf")
        .expect_err("module without a name must fail closed");
    assert!(
        err.to_string()
            .contains("expected a module name identifier"),
        "diagnostic must name the module name family (actual: {})",
        err
    );
}

/// Negative g2: module body never closed (EOF inside items loop).
#[test]
fn neg_grm_module_unclosed_eof() {
    let err = run_source("module m { fn f() { 1 }", "neg.ktf")
        .expect_err("unclosed module body must fail at EOF");
    assert!(
        err.to_string().contains("expected }"),
        "diagnostic must name the closing-brace family (actual: {})",
        err
    );
}

/// Negative g3: import declaration without a module name.
#[test]
fn neg_grm_import_name_not_ident() {
    let err = run_source("import { a };", "neg.ktf")
        .expect_err("import without a module name must fail closed");
    assert!(
        err.to_string().contains("expected an import name"),
        "diagnostic must name the import name family (actual: {})",
        err
    );
}

/// Negative g4: import member alias without a following identifier.
#[test]
fn neg_grm_import_alias_missing_name() {
    let err = run_source("import m::{a as};", "neg.ktf")
        .expect_err("alias without a name must fail closed");
    assert!(
        err.to_string().contains("expected"),
        "diagnostic must name an expectation family (actual: {})",
        err
    );
}

/// Negative g5: require declaration without a capability name.
#[test]
fn neg_grm_require_missing_name() {
    let err = run_source("require;", "neg.ktf")
        .expect_err("require without a capability name must fail closed");
    assert!(
        err.to_string().contains("expected a capability name"),
        "diagnostic must name the capability family (actual: {})",
        err
    );
}

/// Negative g6: extern declaration missing the -> arrow.
#[test]
fn neg_grm_extern_missing_arrow() {
    let err = run_source("extern f();", "neg.ktf")
        .expect_err("extern without a result type must fail closed");
    assert!(
        err.to_string().contains("expected ->"),
        "diagnostic must name the arrow family (actual: {})",
        err
    );
}

/// Negative g7: extern symbol name not an identifier.
#[test]
fn neg_grm_extern_name_not_ident() {
    let err = run_source("extern 1(i64) -> i64;", "neg.ktf")
        .expect_err("extern name must be an identifier");
    assert!(
        err.to_string().contains("expected an external symbol name"),
        "diagnostic must name the extern symbol family (actual: {})",
        err
    );
}

/// Negative g8: export declaration without a name.
#[test]
fn neg_grm_export_missing_name() {
    let err = run_source("export;", "neg.ktf").expect_err("export without a name must fail closed");
    assert!(
        err.to_string().contains("expected an export name"),
        "diagnostic must name the export family (actual: {})",
        err
    );
}

/// Negative g9: use selection braces never closed.
#[test]
fn neg_grm_use_selection_unclosed() {
    let err =
        run_source("use m::{a;", "neg.ktf").expect_err("unclosed use selection must fail closed");
    assert!(
        err.to_string().contains("expected }"),
        "diagnostic must name the closing-brace family (actual: {})",
        err
    );
}

/// Negative g10: use member rename target not an identifier.
#[test]
fn neg_grm_use_member_alias_not_ident() {
    let err = run_source("use m::{a as 1};", "neg.ktf")
        .expect_err("rename to a non-identifier must fail closed");
    assert!(
        err.to_string()
            .contains("expected a member rename identifier"),
        "diagnostic must name the rename family (actual: {})",
        err
    );
}

/// Negative g11: if statement without a block operand.
#[test]
fn neg_grm_if_missing_block() {
    let err =
        run_source("if x 1", "neg.ktf").expect_err("if without a block must fail at read time");
    assert!(
        err.to_string().contains("expected {"),
        "diagnostic must name the block family (actual: {})",
        err
    );
}

/// Negative g12: perform statement missing its semicolon.
#[test]
fn neg_grm_perform_missing_semi() {
    let err = run_source("fn g() { perform Op(1) }", "neg.ktf")
        .expect_err("perform without a semicolon must fail closed");
    assert!(
        err.to_string().contains("expected ;"),
        "diagnostic must name the semicolon family (actual: {})",
        err
    );
}

/// Negative g13: perform effect name not an identifier.
#[test]
fn neg_grm_perform_op_not_ident() {
    let err = run_source("fn g() { perform 1(2); }", "neg.ktf")
        .expect_err("perform with a non-identifier op must fail closed");
    assert!(
        err.to_string().contains("expected an effect name"),
        "diagnostic must name the effect-name family (actual: {})",
        err
    );
}

/// Negative g14: handle with zero arms (fail-closed D8).
#[test]
fn neg_grm_handle_zero_arms() {
    let err = run_source("fn g() { handle E(x) { } }", "neg.ktf")
        .expect_err("handle with zero arms must fail closed");
    assert!(
        err.to_string().contains("handle needs at least one arm"),
        "diagnostic must name the zero-arm family (actual: {})",
        err
    );
}

/// Negative g15: handle arms missing the comma separator (the arm binder
/// arity guard fires — two arms glued parse as one 3-element binder).
#[test]
fn neg_grm_handle_arm_missing_separator() {
    let err = run_source(
        "fn g() { handle E(x) { E(p) => resume(p) E(q) => resume(q) } }",
        "neg.ktf",
    )
    .expect_err("arms without a separator must fail the binder arity guard");
    assert!(
        err.to_string()
            .contains("handle arm binding must be two-element"),
        "diagnostic must name the binder arity family (actual: {})",
        err
    );
}

/// Negative g16: match with zero arms (fail-closed).
#[test]
fn neg_grm_match_zero_arms() {
    let err = run_source("fn g() { match x { } }", "neg.ktf")
        .expect_err("match with zero arms must fail closed");
    assert!(
        err.to_string()
            .contains("match expression needs at least one arm"),
        "diagnostic must name the zero-arm family (actual: {})",
        err
    );
}

/// Negative g17: match arm missing the => arrow.
#[test]
fn neg_grm_match_arm_missing_arrow() {
    let err = run_source("fn g() { match x { _ } }", "neg.ktf")
        .expect_err("arm without => must fail closed");
    assert!(
        err.to_string().contains("expected =>"),
        "diagnostic must name the arrow family (actual: {})",
        err
    );
}

/// Negative g18: pattern-or with a trailing pipe (no following pattern).
#[test]
fn neg_grm_match_pattern_trailing_pipe() {
    let err = run_source("fn g() { match x { _ | } }", "neg.ktf")
        .expect_err("trailing pipe must fail closed");
    assert!(
        err.to_string().contains("expected a pattern"),
        "diagnostic must name the pattern family (actual: {})",
        err
    );
}

/// Negative g19: let statement with a missing value expression.
#[test]
fn neg_grm_let_missing_value() {
    let err = run_source("fn g() { let x = ; x }", "neg.ktf")
        .expect_err("let without a value must fail closed");
    assert!(
        err.to_string().contains("expected an expression"),
        "diagnostic must name the expression family (actual: {})",
        err
    );
}

/// Negative g20: macro declaration without a name identifier.
#[test]
fn neg_grm_macro_missing_name() {
    let err =
        run_source("macro { }", "neg.ktf").expect_err("macro without a name must fail closed");
    assert!(
        err.to_string().contains("expected a macro name identifier"),
        "diagnostic must name the macro-name family (actual: {})",
        err
    );
}

/// Negative g21: macro body with zero clauses.
#[test]
fn neg_grm_macro_zero_clauses() {
    let err = run_source("macro m() { }", "neg.ktf")
        .expect_err("macro with zero clauses must fail closed");
    assert!(
        err.to_string()
            .contains("macro body needs at least one clause"),
        "diagnostic must name the zero-clause family (actual: {})",
        err
    );
}

/// Negative g22: closure body without a block.
#[test]
fn neg_grm_closure_missing_block() {
    let err = run_source("let f = || 1;", "neg.ktf")
        .expect_err("closure without a block must fail closed");
    assert!(
        err.to_string().contains("expected {"),
        "diagnostic must name the block family (actual: {})",
        err
    );
}

/// Negative g23: resume call outside a handler arm body (the kcell
/// domain discipline — r133 nested-resume D5: resume stays out-of-domain
/// outside handler arm bodies).
#[test]
fn neg_grm_resume_outside_handler() {
    let err = run_source("fn g() { resume(1); }", "neg.ktf")
        .expect_err("resume outside a handler arm must fail closed");
    assert!(
        err.to_string().contains("expected an expression"),
        "diagnostic must name the expression family (actual: {})",
        err
    );
}

/// Negative g24: parameter list with a leading comma (no parameter name).
#[test]
fn neg_grm_params_leading_comma() {
    let err =
        run_source("fn f(,) { 1 }", "neg.ktf").expect_err("parameter list must start with a name");
    assert!(
        err.to_string().contains("expected a parameter name"),
        "diagnostic must name the parameter family (actual: {})",
        err
    );
}

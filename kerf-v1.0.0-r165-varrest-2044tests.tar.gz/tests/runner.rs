//! The **single main entry** for cross-crate integration tests (sop.md
//! §8.4.6 test entry architecture intent v11.2 — Cargo.toml clean-and-minimal
//! principle).
//!
//! cargo auto-discovers this file as the sole test target among top-level
//! `.rs` files under `tests/`, with **zero `[[test]]` configuration**; all
//! v0/stage-N test files are mounted via the `#[path]` mod tree — the
//! stage/plan/gate directory semantics are unchanged (physical location is
//! semantics); only the entry is consolidated.
//!
//! Standard action to add a test file: append one `#[path]` mod declaration
//! under the corresponding stage group + create the new file (reverting to
//! per-file `[[test]]` declarations is forbidden — sop.md §8.4.6 mandatory
//! rule 8).
//!
//! Selective runs: `cargo test --test runner <module>::<case>` (the module
//! path is the filter, e.g. `cargo test --test runner capability_tests::`).
//! Relative `#[path]` inside test files (e.g. `mod common`) resolves against
//! the file's own directory — the mounting scheme does not change its
//! resolution base.

// ---------------------------------------------------------------------------
// Shared test helpers (single-instance sharing — each test module consumes
// via `use crate::common`, replacing the former per-file `mod common`
// duplicated-loading form)
// ---------------------------------------------------------------------------

#[path = "common/mod.rs"]
mod common;

// ---------------------------------------------------------------------------
// Stage 0 (semantic verification): plan suite
// ---------------------------------------------------------------------------

#[path = "v0/stage0/plan/expander_tests.rs"]
mod expander_tests;

#[path = "v0/stage0/plan/compiler_tests.rs"]
mod compiler_tests;

#[path = "v0/stage0/plan/vm_tests.rs"]
mod vm_tests;

#[path = "v0/stage0/plan/gc_tests.rs"]
mod gc_tests;

#[path = "v0/stage0/plan/pipeline_tests.rs"]
mod pipeline_tests;

// Architecture compliance audit (v6.0 — principles 29-31 shape audit:
// private ADT freeze / Span independence / surface-internal separation;
// 01 §8.5 + 02 §8.1 anchor landing)

#[path = "v0/stage0/plan/architecture_audit_tests.rs"]
mod architecture_audit_tests;

// Four negative-test files (§9.4.3 positive:negative ratio ≥1:3 main carrier)

#[path = "v0/stage0/plan/negative_expander_tests.rs"]
mod negative_expander_tests;

#[path = "v0/stage0/plan/negative_vm_tests.rs"]
mod negative_vm_tests;

#[path = "v0/stage0/plan/negative_semantics_tests.rs"]
mod negative_semantics_tests;

// ---------------------------------------------------------------------------
// Stage 0: gate review audit (§7.3)
// ---------------------------------------------------------------------------

#[path = "v0/stage0/gate/gate_review_r1.rs"]
mod gate_review_r1;

// ---------------------------------------------------------------------------
// Stage 1 (self-hosting verification): plan suite (batches A → D)
// ---------------------------------------------------------------------------

// Batch A (r4: TD-007 trampoline worklist conversion)

#[path = "v0/stage1/plan/expansion_worklist_tests.rs"]
mod expansion_worklist_tests;

// Batch B (r5/r6: minimal standard library + B3 self-hosting Reader)

#[path = "v0/stage1/plan/stdlib_tests.rs"]
mod stdlib_tests;

// Batch C (r7: type checker + compilation cache)

#[path = "v0/stage1/plan/typecheck_tests.rs"]
mod typecheck_tests;

#[path = "v0/stage1/plan/cache_tests.rs"]
mod cache_tests;

// Batch D (r8: capability I/O basic passing + internal effects/test runner)

#[path = "v0/stage1/plan/capability_tests.rs"]
mod capability_tests;

#[path = "v0/stage1/plan/test_runner_tests.rs"]
mod test_runner_tests;

// r12 batch (worklog Task 31-d): interface reserved extension layer
// (v6.1 completeness review — next4 round 8; P0 location assertions +
// 14 reserved APIs cross-crate reachability)

#[path = "v0/stage1/plan/reserved_ext_tests.rs"]
mod reserved_ext_tests;

// Batch E (r13: TD-004 scope set resolution close-out — Racket-style
// (name, scopes ⊆) matching dual-path semantic anchor + scope-mismatch
// negative cases)

#[path = "v0/stage1/plan/scope_set_tests.rs"]
mod scope_set_tests;

// Batch E (r14: E1-α self-hosting Expander — core forms + nine-sugar
// shadow path + parity)

#[path = "v0/stage1/plan/bootstrap_expander_tests.rs"]
mod bootstrap_expander_tests;

// Batch E (r15: E1-β macro close-out + production switch + TD-021 prelude
// module injection)

#[path = "v0/stage1/plan/prelude_tests.rs"]
mod prelude_tests;

// ---------------------------------------------------------------------------
// Stage 2 (full language): plan suite (from batch G)
// ---------------------------------------------------------------------------

// Batch G (r17: QBE backend PoC — AnnotatedANF reification + IL generation
// + AOT end-to-end + PoC boundary negative cases; carried by 38-b/38-c)

#[path = "v0/stage2/plan/qbe_backend_tests.rs"]
mod qbe_backend_tests;

// Batch H (r18: TD-022 TCO tail-call optimization — frame reuse + tail
// position propagation + instruction budget guardrail + TD-007/TD-022
// decoupling self-hosting end-to-end; carried by 40-c)

#[path = "v0/stage2/plan/tco_tests.rs"]
mod tco_tests;

// Batch H (r18: H4 HM inference PoC — three-stage constraints + value
// restriction + recursion preset + superset/zero-false-positive dual gate +
// four-class gap detection proof; carried by 40-e — 38-d design landing)

#[path = "v0/stage2/plan/hm_inference_tests.rs"]
mod hm_inference_tests;

// Batch G (r17: TD-013 multi-error collection and recovery expansion —
// seed/bridge dual path + driver check_source_recover consumption surface;
// carried by 38-e)

#[path = "v0/stage2/plan/multi_error_recovery_tests.rs"]
mod multi_error_recovery_tests;

// Batch I (r21: I1 front-end self-hosting Compiler parity — eight arms +
// scope machinery + capture + backfill + constant pool + TCO tail
// position; bytecode_equal full-structure criterion; carried by 42-b —
// i1-incision-migration-design §5 gate A foundation group)

#[path = "v0/stage2/plan/bootstrap_compiler_tests.rs"]
mod bootstrap_compiler_tests;

// Batch I back end (r25: 42-f Effect M1-M5 — language-level effect surface
// + GC six sources + dual-path consistency; effect-language-design §5 test
// anchors 6 positive 7 negative + M3 ≥8)

#[path = "v0/stage2/plan/effect_tests.rs"]
mod effect_tests;

// Batch J (r30: 48-d J3 FFI VM surface made real — the bytecode execution
// surface of ffi-ownership-model §2/§3/§5/§6: window protocol (Φ pin count
// book) + linear token state machine + E0010-E0012 diagnostic family +
// 13 boundary cases; language-surface form in Stage 3 — direct opcode
// construction driver + frozen FfiCall lowering surface)

// ---------------------------------------------------------------------------
// Stage 3 entry sequence (batch M namespace layer M1 — r39): plan suite
// ---------------------------------------------------------------------------

#[path = "v0/stage3/plan/namespace_tests.rs"]
mod namespace_tests;

// ---------------------------------------------------------------------------
// T3+ optimization window r53 (75-b): HM solver performance evolution guard
// (O1 path compression + O4 structural sharing — the fifth of the five
// zero-semantic-drift measures: new performance-evolution test surface)
// ---------------------------------------------------------------------------

#[path = "v0/stage3/plan/hm_perf_evolution_tests.rs"]
mod hm_perf_evolution_tests;

// ---------------------------------------------------------------------------
// T3+ optimization window r54 (76-b): VM main dispatch performance
// evolution guard (O1 span laziness + O2 instruction referencing +
// O3 proto cache — TD-028 optimization window item two)
// ---------------------------------------------------------------------------

#[path = "v0/stage3/plan/vm_dispatch_perf_tests.rs"]
mod vm_dispatch_perf_tests;

// ---------------------------------------------------------------------------
// T3+ optimization window r55 (77-b): VM frame slot pool guard (P1 pooling
// + P3 slot-clearing division of labor — TD-028 optimization window item
// three)
// ---------------------------------------------------------------------------

#[path = "v0/stage3/plan/vm_frame_pool_tests.rs"]
mod vm_frame_pool_tests;

// ---------------------------------------------------------------------------
// r74 / 144-b: HM/typecheck .krf path validation PoC (user r74 instruction
// window ① — r74-window-opening §2: krf mini inference surface vs Rust
// production decision surface accept/reject parity + honest boundary
// protocol surface)
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// r107 / 177-c: switch window step ② lexer parity gate (.krf path
// bootstrap/reader.krf ↔ Rust seed oracle kind/Span/payload
// byte-level identity — first independent acceptance of the five-step
// process step ② new Reader bytecode-ization)
// ---------------------------------------------------------------------------

#[path = "v0/stage3/plan/target_reader_krf_tests.rs"]
mod target_reader_krf_tests;

// ---------------------------------------------------------------------------
// Switch window step ③ corpus rewrite parity gate (r109 / 179-c — first
// batch: preamble.ktf): skin dictionary name mapping (`-` ↔ `_`) both-side
// Reader consistency + module import/export header grammar domain +
// three-way bytecode identity (S-expr original baseline ↔ .ktf seed path
// ↔ .ktf production bridge path) + behavioral equivalence + dual-expander
// parity + injected liveness probe)
// ---------------------------------------------------------------------------

#[path = "v0/stage3/plan/switch_corpus_parity_tests.rs"]
mod switch_corpus_parity_tests;

// ---------------------------------------------------------------------------
// Switch window step ⑤ validation-equivalence gate (r119 / 189-a — the
// fixpoint-isomorphism closing batch): skin-dictionary full-table
// SemanticProof through the structured SyntaxTransitionValidator (02
// §8.12 registration made real) + layer-2 program-level dual-compile
// parity + the fixpoint gate dual-caliber unification (.krf gate-B
// caliber + .ktf three-stage fixpoint + BS-C transitivity B₁'→B₂'→B₃')
// + diagnostic-face parity + the compile-speed regression <2x
// acceptance line (11 §6.3 trap-3 criterion)
// ---------------------------------------------------------------------------

#[path = "v0/stage3/plan/hm_krf_path_tests.rs"]
mod hm_krf_path_tests;

// ---------------------------------------------------------------------------
// match implementation batch M-1 (r121 / 191-a — the Reader arm: pattern
// grammar per match-design.md v1.0 §2 / 02 §8.13.1a r121 addition; the
// intermediate arm-structure direct-mapping form + cross-syntax Stx parity
// match-corpus family + fail-closed pattern-domain negatives + the staging
// boundary anchors: .krf mirror divergence window [M-4 closes] and the
// front-end pseudo-application pass-through [M-2 dissolves])
// ---------------------------------------------------------------------------

#[path = "v0/stage3/plan/match_m1_reader_tests.rs"]
mod match_m1_reader_tests;

// ---------------------------------------------------------------------------
// match implementation batch M-2 (r122 / 192-a — the D2 skin-dictionary
// seventh mapping: the match-arm → cond/let desugar, match-design.md v1.1
// §3 semantic table in full; the canonical product rulings of v1.2 §3.4 —
// the `eq` predicate refinement / path-based extraction / the guard
// (and T (let binds G)) shape with body re-binding / the uniform
// (if true ...) chain / the or binding-map identity. Gates: cross-syntax
// bytecode parity (the M-2 acceptance gate — target face + S-expr face ↔
// hand-written cond/let equivalent), dual-path seed ↔ self-hosted expander
// parity, runtime semantics (seed + production paths, the §4 defensive
// fallback), fail-closed negatives with mirrored message faces, the HM-check
// integration, the guard effect-order anchor, and the M-1 pass-through
// boundary dissolution flip)
// ---------------------------------------------------------------------------

#[path = "v0/stage3/plan/match_m2_desugar_tests.rs"]
mod match_m2_desugar_tests;

// ---------------------------------------------------------------------------
// r123 / 193-a: match implementation batch M-3 — the §4 exhaustiveness
// gate (conservative sound rules on both expander faces: positive families
// [wildcard/binding/or-total arms + the bool closed-domain exemption with
// or-flattening], E0025 fail-closed negatives with byte-identical mirrored
// message faces, structural-diagnostic precedence, the principle-42 runtime
// double layer's residual reachable class, the check-channel E2E, and the
// diagnostic-only product anchor via three-face bytecode parity)
// ---------------------------------------------------------------------------

#[path = "v0/stage3/plan/match_m3_exhaustiveness_tests.rs"]
mod match_m3_exhaustiveness_tests;

// ---------------------------------------------------------------------------
// r124 / 194-a: match implementation batch M-4 — the .krf mirror grammar
// batch (the dual-Reader divergence window M-1..M-3 closed: grammar parity
// positives with byte-level canonical Stx renderings incl. Spans, the full
// r121 fail-closed negative corpus with message+Span mirrored equality, the
// maintained lexical parity face, and the cross-stage consumption — a
// mirror-read match program through the production chain to the VM)
// ---------------------------------------------------------------------------

#[path = "v0/stage3/plan/match_m4_krf_mirror_tests.rs"]
mod match_m4_krf_mirror_tests;

// ---------------------------------------------------------------------------
// r125 / 195-a: CLI dual-entry (two-Reader coexistence period) tests —
// the switch-window-plan §4 domain-registered "CLI dual entry (P3 design
// candidate)" row discharged: cross-syntax behavioral equivalence at the
// CLI boundary (run/check/test/dump target faces), default-face zero
// regression, driver-API orthogonality, fail-closed negatives.
// ---------------------------------------------------------------------------

#[path = "v0/stage3/plan/cli_entry_convergence_tests.rs"]
mod cli_entry_convergence_tests;

// ---------------------------------------------------------------------------
// r127 / 197-b: .ktf usage-corpus family tests (M2 consumption form) —
// the user-facing .ktf corpus placed at examples/usage/*.ktf (six files)
// consumed through the three production entries (run/check/test) with
// corpus-shaped fail-closed negatives across the error classes (§9.4.3
// ratio 1:3 carrier).
// ---------------------------------------------------------------------------

#[path = "v0/stage3/plan/ktf_corpus_tests.rs"]
mod ktf_corpus_tests;

// ---------------------------------------------------------------------------

#[path = "v0/stage3/plan/ktf_stress_corpus_tests.rs"]
mod ktf_stress_corpus_tests;

// ---------------------------------------------------------------------------

#[path = "v0/stage3/plan/seed_ktf_parity_tests.rs"]
mod seed_ktf_parity_tests;

// ---------------------------------------------------------------------------

#[path = "v0/stage3/plan/ktf_macros_corpus_tests.rs"]
mod ktf_macros_corpus_tests;

// ---------------------------------------------------------------------------

#[path = "v0/stage3/plan/ktf_import_alias_tests.rs"]
mod ktf_import_alias_tests;

// r131 / 201-c: use-declaration family (the eleventh skin-dictionary
// mapping — the `::` import tree; user M1 instruction window opening case
// 36: selective `use mod::{m}` ↔ the r50/D65 S-expr selective import +
// bare/alias/combined/multi-path family; dual-Reader canonical parity +
// D3 member-rename domain-out + E0019/E0024/E0022/E0017 semantic battery)

#[path = "v0/stage3/plan/ktf_use_decl_tests.rs"]
mod ktf_use_decl_tests;

// r137 / 207-c: FFI extern declaration family (the thirteenth
// skin-mapping family — the TD-026 language-surface window: the extern
// declaration + call surface over the frozen #43 CallExternal mechanism;
// run-face E2E dual-face + five-fold declaration discipline battery +
// position/flat-space/value-position fail-closed + runtime window-protocol
// propagation E0011 + dual-Reader canonical parity)
#[path = "v0/stage3/plan/ktf_extern_decl_tests.rs"]
mod ktf_extern_decl_tests;

// r147 / 217-c — the extern symbol-space alias window's 32-case gate
// (8 positive + 24 negative = 1:3; extern-alias-design.md D1-D10: the
// declaration-site alias arm — two-name split E2E dual face + replacement
// semantics D4 reverse anchor + self-alias D5 + anti-shadowing D6 +
// capability/contract/availability by the underlying D3/D7 + dual-Reader
// canonical parity + error-face parity ×3)
#[path = "v0/stage3/plan/ktf_extern_alias_tests.rs"]
mod ktf_extern_alias_tests;

// r138 / 208-c — TD-002: the vector value-type window's 32-case gate
// (8 positive + 24 negative = 1:3; vector-value-design.md D10)
#[path = "v0/stage3/plan/ktf_vector_value_tests.rs"]
mod ktf_vector_value_tests;

#[path = "v0/stage3/plan/ktf_tc_sigs_parity_tests.rs"]
mod ktf_tc_sigs_parity_tests;

// ---------------------------------------------------------------------------
// r158 / 228-c: top-level let modernization family (the S-expr-era
// define(NAME, e) call form retired at item position; the toplevel_let
// production — toplevel-let-design.md v1.0)
// (8 positive + 24 negative = 1:3)
#[path = "v0/stage3/plan/ktf_toplevel_let_tests.rs"]
mod ktf_toplevel_let_tests;

// ---------------------------------------------------------------------------
// r141 / 211-c: diagnostic-message parity family (the registered
// message-unification row cleared — the krf face's nine static-check
// message families converge to the oracle's op+got form; design single
// source = diag-msg-unify-design.md v1.0: full-text anchors on every
// family + dual-face parity + the three arity want forms + Unicode
// α/→/≥ rendering + the r135 renamed-derivation attribution + the
// multi-violation collection channel)
// ---------------------------------------------------------------------------
#[path = "v0/stage3/plan/ktf_diag_msg_parity_tests.rs"]
mod ktf_diag_msg_parity_tests;

// r142 / 212-c — member/assoc static-face dual-defect gate (32 case,
// 8:24 — member-any-bool-model-design.md D8).
#[path = "v0/stage3/plan/ktf_member_any_model_tests.rs"]
mod ktf_member_any_model_tests;

// r132 / 202-c: handle multi-arm / halt / pass family (the twelfth
// skin-mapping family — the multi-arm desugar to nested single-arm
// handles + the halt tail-value sugar + the pass re-perform propagation;
// dual-Reader canonical parity + nesting-equivalence bytecode gate +
// D6/D8 fail-closed battery + the pass-unhandled semantic negative +
// the same-window fvo settlement regression anchor)
#[path = "v0/stage3/plan/ktf_handle_multiarm_tests.rs"]
mod ktf_handle_multiarm_tests;

// r143 / 213-c — handle expression-position gate (32 case, 8:24 —
// handle-expr-position-design.md D7: the primary-position dispatch's
// five positional forms E2E + cross-face value parity with the
// statement-position zero-regression re-anchors + dual-Reader canonical
// parity + cross-stage check consumption; the fail-closed battery =
// expression-position structure discipline + the positional-domain
// maintenance battery + the cross-stage semantic family)
#[path = "v0/stage3/plan/ktf_handle_expr_position_tests.rs"]
mod ktf_handle_expr_position_tests;

// r144 / 214-c — read-line signature-entry gate (32 case, 8:24 —
// read-line-sig-design.md D8: the registered row's stale premise
// ("runtime arity unchecked") is retired — the FS-4 enforcement was
// already in place, so the entry lands on both faces in the
// read-int/read-num family form; the static face gains the E0005
// rejection (layer-orthogonal to the untouched E0004 runtime bottom),
// the r135 rename chain and the oracle qualified derivation tighten,
// and the zero-false-positive battery guards the Unknown result flow)
#[path = "v0/stage3/plan/ktf_read_line_sig_tests.rs"]
mod ktf_read_line_sig_tests;

// ---------------------------------------------------------------------------
// r133 / 203-c: nested-block resume family (the r128 registered honest
// boundary cleared — resume at nested-block statement/tail positions
// inside a handler arm body: if arms / closures / nested-handle arms;
// dual-Reader canonical parity + nesting-equivalence bytecode gate +
// positional/scope/form fail-closed battery + the isoB VM settlement
// regression anchor — the handler-boundary teardown on resume)
// ---------------------------------------------------------------------------
#[path = "v0/stage3/plan/ktf_nested_resume_tests.rs"]
mod ktf_nested_resume_tests;

// ---------------------------------------------------------------------------
// r134 / 204-b: member-rename family (the use-window legacy domain-out
// pair cleared — `use m::{a as x}` rename triple on both faces + the
// module-header selection acceptance; design single source =
// member-rename-design.md v1.0: replacement-semantics E2E + the E0022
// reverse anchor + the D7 same-domain dedup + the D8 gated/re-export
// domain-out + the D5 header-scan flip + the HM A4 cross-stage anchor)
// ---------------------------------------------------------------------------
#[path = "v0/stage3/plan/ktf_member_rename_tests.rs"]
mod ktf_member_rename_tests;

// ---------------------------------------------------------------------------
// r80 / 150-c: HM default-period production switch guard (user M1
// instruction window opening exercise — guide §4 quick-reference card
// [position 4] third user exercise: production decision surface switch to
// check.krf path — liveness probe + seven corpus anchors + occurs contract
// exemption guard + fallback narrow surface + production detection
// capability)
// ---------------------------------------------------------------------------

#[path = "v0/stage3/plan/hm_production_switch_tests.rs"]
mod hm_production_switch_tests;

// ---------------------------------------------------------------------------
// r74 / 144-d: build system segment first incision (user r74 instruction
// window ③ — 07 §3.3 Stage 2→3 signal first production evidence: prelude
// injection decision .krf-ization — dual-surface parity [seed oracle vs
// production surface] + production E2E bidirectional guard)
// ---------------------------------------------------------------------------

// r90 / 160-b: build system segment fifth incision (TD-032 cache segment
// final incision — user M1 instruction window opening case 6: cache
// consultation policy .krf-ization — key construction oracle parity +
// consultation three-form decision full shapes + production E2E/statistics
// matrix + liveness probe)

// r92 / 162-a: TD-031 M1 core module generation (user M1 instruction
// window opening case 7: WASM emitter — CFG→structured control + node host
// E2E parity + manifest read-back reconciliation + determinism + B1 shared
// boundary negative case + read-back fail-closed)

#[path = "v0/stage3/plan/wasm_backend_tests.rs"]
mod wasm_backend_tests;

// r97 / 167-a: TD-031 M2 canonical ABI adapter layer (user M1 instruction
// window opening case 8: CanonicalAbiOptions three-field full consumption
// — UTF-8/UTF-16 validating string encode/decode + memory64 address
// domain + realloc bump protocol; node host str cross-boundary parity +
// four-param allocation protocol E2E + memory64 byte-level assertions +
// determinism/omitted-surface structural positive case)

#[path = "v0/stage3/plan/wasm_abi_tests.rs"]
mod wasm_abi_tests;

// r99 / 169-a: TD-031 M3 component composition layer (user M1 instruction
// window opening case 9: imports/exports stitching + component-level type
// validation + L-β effect/capability component instance protocol ruling;
// node host composition E2E parity (canonical dual-module system
// instantiated as planned) + stitching authenticity negative probe
// (LinkError reverse anchor) + custom realloc name wiring + memory-only
// shape + determinism)

#[path = "v0/stage3/plan/wasm_compose_tests.rs"]
mod wasm_compose_tests;

// ---------------------------------------------------------------------------
// r159 / 229-c: percent-operator family (the operator-surface parity
// window: the term-level infix `%` primary face closes the
// EBNF-vs-registration gap — `mod` stays as the legacy call-form alias;
// design single source = operator-surface-parity-design.md v1.0: E2E
// binding + precedence/associativity + signed-operand semantics + the
// alias value equivalence + dual-Reader canonical/error parity + the
// same-core-form machine anchor + check cross-stage consumption + the
// corpus migration anchors (is_even + the D42 do→block isomorphism) +
// 7 error-class negatives at 1:3)
// ---------------------------------------------------------------------------
#[path = "v0/stage3/plan/ktf_percent_operator_tests.rs"]
mod ktf_percent_operator_tests;

// r160 / 230-c — TD-036 (tuple-expression-design.md v1.0): the tuple
// expression family — the binary pair construction's modern face (the
// fifteenth skin mapping: `(a, b)` → as-if-written `cons(a, b)` — skin
// swap, skeleton identical; the construction/destruction symmetry with
// the match pattern's `(p, q)` face; 8 positives [core E2E + symmetry +
// as-if-written bytecode equivalence + the full position domain + the
// dual-Reader canonical parity + the check cross-stage consumption +
// the grouping/unit regression + the corpus migration value parity] +
// 24 negatives [E0001 arity/shape/EOF family + E0004 domains + E0022
// unbound ×3 + E0005 static Pair≠Num family ×3 + E0006 capability +
// E0014 qualified path + the pattern-face regression anchor + the Span
// contracts ×2 + the dual-Reader error parity ×3] at 1:3)
// ---------------------------------------------------------------------------
#[path = "v0/stage3/plan/ktf_tuple_expr_tests.rs"]
mod ktf_tuple_expr_tests;

#[path = "v0/stage2/plan/ffi_vm_tests.rs"]
mod ffi_vm_tests;
#[path = "v0/stage3/plan/ktf_const_decl_tests.rs"]
mod ktf_const_decl_tests;
#[path = "v0/stage3/plan/ktf_equality_domain_tests.rs"]
mod ktf_equality_domain_tests;
#[path = "v0/stage3/plan/ktf_index_access_tests.rs"]
mod ktf_index_access_tests;

// r164 / 235: list-domain self-built migration gate (list-self-built-design
// .md D6 — 8 positives + 24 negatives 1:3; the five migrated faces' E2E +
// cascade/qualified/rename faces + the exact retired-Rust error-message
// byte anchors + the fn-form arity declared change + the static generic
// unification face + the member/assoc Rust-maintained half).
#[path = "v0/stage3/plan/ktf_list_selfbuilt_tests.rs"]
mod ktf_list_selfbuilt_tests;

// r165 / 236: variadic rest-parameter family gate (variadic-rest-design.md
// D8 — 8 positives + 24 negatives 1:3; the rest binding's pair-chain E2E +
// the closure rest face + the inline kerf append proof artifact (the parked
// migration's TD-041 carrier) + the Reader structural family + the VM
// min-arity "expected at least N" face at all three call sites + the check
// static ">=N" face + the append error-face byte anchors + the r162/r164
// boundary regressions — 6 error code classes covered).
#[path = "v0/stage3/plan/ktf_variadic_rest_tests.rs"]
mod ktf_variadic_rest_tests;

# kerf

**极小内核 · 自举 · 现代语法** 的系统级编程语言（v1.0.0 / r158）

> **一行**：Rust 实现的 kerf 编译器——九个正交核心原语 + Stage 0-1 自建 VM + 渐进式混合自举；11 个 kerf-* crate，零外部 cargo 依赖，LLVM 永不入自举链。
>
> **设计蓝图**：[docs/lang-design/](docs/lang-design/)（25 篇编号文档 00-24：五十八条设计原则 + 能力架构三轴坐标系 + 演进治理触发表 + 根空间统一组织）
> **流程管控**：[docs/sop.md](docs/sop.md)（路由全覆盖 + 校准回路闭环 + 判据级登记体系）
> **演进档案**：[RELEASE_NOTES.md](RELEASE_NOTES.md)（r1-r165 全量轮次记录）· [docs/tests/matrix.md](docs/tests/matrix.md)（测试基线对账）· [docs/develop/v0/](docs/develop/v0/)（阶段开发档案）

## 30 秒了解（现代 kerf 语法，`.ktf` 单面）

```text
// fib.ktf —— 递归基准（fib(25) = 75025，VM ≈ 3.4M 调用/s）
require io, write;

fn fib(n: i64) -> i64 {
    if (n < 2) { n } else { fib(n - 1) + fib(n - 2) }
}

print(fib(25));
```

```text
// 词法闭包 + 可变捕获（共享单元格）
fn make_counter() {
    let n = 0;
    || { n = n + 1; n }
}

define(a, make_counter());
a(); a(); a();          // 计数到 3
print(a());             // ⇒ 4

// 效应系统：perform / handle / resume——一次消费线性续体
fn ask() { perform gift(0, 20); }

fn guarded() {
    handle (100 + ask()) { gift(p, k) => resume(tail(p) + head(p)) }
}
guarded()               // ⇒ 120

// 卫生宏（macro 皮肤 → syntax-rules 核心，零新原语）
macro my_or {
    () => false,
    (a) => a,
    (a, rest ...) => if a { true } else { my_or(rest ...) },
}

// 向量值类型（不可变 + 五内建）
import kerf_vector;
vector_append([1, 2], [3, 4])       // ⇒ [1 2 3 4]

// 命名空间（import / 别名 / 限定名）
import kerf_string as s;
s::append("拼接", "字符串")
```

```bash
cargo build --release
./target/release/kerf run examples/usage/fib.ktf        # 75025 / ⇒ 144
./target/release/kerf check examples/usage/fib.ktf      # HM 类型检查（多错误收集）
./target/release/kerf bench examples/usage/fib.ktf      # 性能基准（~77ms 量级）
```

## 语言面貌

- **现代语法皮肤**（`.ktf` 单一文件面）：`fn f(x: i64) -> i64 { … }` 函数声明（类型/效应签名解析后剥皮肤——内核零类型消费）、`|| (p: T) { body }` 闭包、`let x = 1, y = 2;` 多绑定、`if (c) { a } else { b }`、中缀运算符十四级优先级（含 `%`）、`[a, b, c]` 向量字面量、`(a, b)` 元组表达式（pair 构造现代面——构造⟺解构对称）、`import kerf_string as s;` 命名空间、`macro m { (pat) => tpl }` 宏皮肤。
- **九个正交核心原语**（内核冻结）：`Fn / Apply / If / Var / Literal / Assign / Let / Perform / Handle` + `ModuleItem` 声明层——一切糖（do/define/cond/while/module/require/match/向量/元组）皆脱糖至该基座，8 原语不变性第四十二轮零漂移。
- **效应系统**：`perform` / `handle` / `resume`——一次消费线性续体（payload 序对 tag 分派 + GC 第六根来源）。
- **syntax-rules 卫生宏**：省略号 `...` + 引入标识符重命名（宏名去 `!` 化——标识符域现代化）。
- **HM 类型检查**（`kerf check`）：O1 路径压缩 + O4 结构共享 + 多错误收集 + 递归预置。
- **能力门控 I/O**（fail-closed）：`require io, read|write;` 声明 → 编译期验证 → 不可伪造令牌。
- **命名空间层**：七模块限定名 + import/别名/选择性导入 + E0013-E0024 诊断族。
- **向量值类型**：不可变 + 五内建（`vector_length` / `vector_ref` / `vector_append` / `is_vector` / 方括号打印形）。

## 架构（11 crates，零外部依赖）

```text
.ktf 源码 → kerf-reader（Token/Stx——reader.rs 唯一 Reader 实现）
 → kerf-expander（CoreExpr 九原语 + 卫生宏 + 命名空间可见面）
 → kerf-core（图 IR + CodeValue）→ kerf-compiler（HM 推断 + 字节码 + IndexIR[de Bruijn]）
 → kerf-vm（switch-dispatch + 帧槽池 + 效应/续体/FFI）→ kerf-runtime（标记-清除 GC）
编排: kerf-driver（管线 + 相位分离 + 能力门控 + 编译缓存 + kerf test 运行器）
可选: kerf-backend（QBE AOT + WASM 组件模型 M0-M3——均不入自举链）
基础: kerf-span / kerf-syntax / kerf-space（根空间骨架 Layer -1）
```

- **Span 全管线传播**：词法 → 语法 → IR → 字节码 → 运行时错误反查（调用点追踪链）。
- **IndexIR**（de Bruijn 层级寻址）：解析闭包单通道 + 字节码发射零解析。
- **VM 性能**：span 惰性 + 指令引用化 + proto 缓存 + 帧槽池——fib 相对 r24 基线净超越 1.18x。
- **标记-清除 GC**：GcCell 堆根性摘要 + 六来源根集 + 冷却退避 + 分配驱动。
- **编译缓存**：内存内容寻址（SHA-256 键）+ `cache.ktf` 咨询决策桥。

## 自举（渐进式混合自举）

十个 `.ktf` 自举件在 Stage 0 VM 上运行生产链：`reader.ktf / expander.ktf / compiler.ktf / preamble.ktf / cli.ktf / test.ktf / test_runner.ktf / cache.ktf / build.ktf / check.ktf`——

- **Reader fixpoint**（r151-r152 里程碑）：生产 `.ktf` 读桥自身的词法器与解析器以 kerf 源码表述（`reader.ktf`），经种子 Reader 读入运行于 VM——自宿主 Reader 读自身。
- **门族守护**：fixpoint 门 + 两路门 + 删除守卫（`bootstrap/mod.rs` KTF_SOURCES 十件单源）。
- **宪制边界**：VM 永久 Rust 基座（「完全自举」VM 重写 = 宪制排除项）；本地码后端（QBE/WASM）永不入自举链。

## 质量状态（§3.2 六命令全绿）

| 指标 | 值 |
|---|---|
| 测试基线 | **2044 passed / 0 failed / 0 ignored**（`cargo test --workspace --release`——r165 变参 rest 参数窗净 +32{`fn f(a: T, ...rest: T)` 现代 rest 参数形全链——机制窗{CoreExpr::Fn 加性字段 + BcProto rest_slot + VM min-arity 门 + HM/check 面} + append 泊回实裁{TD-041 触发式}——TD-038 清偿}；r164 list 域自建迁移窗净 +33{五定参内建 kerf 语料自建 + member/assoc 泊回}；r163 索引访问/r162 相等域/r161 常量声明/r160 数据结构面连续多窗） |
| 编译 | `cargo check --workspace --all-targets` 0 error / 0 warning；`cargo clippy -D warnings` 零告警 |
| 门审计 | 六审计集（stage0/stage1/stage2×2/stage3×2）真实 EXIT 0 ×6——41+50+53+46+43+47 case 七类错误全覆盖 |
| CLI | `run` fib ⇒ 75025/144 · `check` ok · `.krf` 拒收 fail-closed exit 2 · `test` PASS · `bench` ~77ms 带内 |
| 内核不变性 | 8 原语不变性第四十五轮（零新原语零通道零新操作码——词汇面扩容非原语面） |
| 演进治理 | T3+ 触发族 14 行零信号维持（零信号不开窗）；技术债开放项 = TD-034（cache 富面休眠·触发式） |

## 演进叙事：从 S-expr 到现代语法（「换脸保核」）

kerf 起步于 S-expr 表面（`.krf`），经 **S-expr 完全拆除窗**（r149-r154 五批六轮：A 构建系统 → B check 面 → C Reader fixpoint → D 用户面 → E6 收口）抵达 **现代语法单面** 终态：仓库 `.krf` = 0、CLI 单面 `.ktf`、`reader.rs` 唯一 Reader 实现、S-expr API 族全域退役。转换以**皮肤字典**（1:1 皮肤映射）+ **转换纪律四新锚** + **承载裁定族**固化「面变核不变」——1788 测试与六审计集为等价性的持续证据链；内部 Stx/CoreExpr datum（pair/list IR）为冻结内核表示，非遗留。命名标准化窗（r155 生产面 + r156 残响面）完成「**one face, one name**」轨迹；顶层 let 现代化窗（r158）退役目标面最后一件 S-expr 旧时代残留——`define(NAME, e);` 项位调用形（现代形 `let NAME = e;`，同一核心形皮肤换）；运算符面完备性窗（r159）闭合 `%` 断链；元组表达式形窗（r160）闭合 pair 构造/解构对称缺口（TD-036——`(a, b)` as-if-written `cons(a, b)`）。详见 [s-expr-removal-plan](docs/develop/v0/stage-3/s-expr-removal-plan.md)（Closed v1.5）与 [legacy-residue-clearance-plan](docs/develop/v0/stage-3/legacy-residue-clearance-plan.md)。；**现代皮肤映射窗**（r158 顶层 let → r159 运算符 `%` → r160 元组表达式 `(a, b)` → r161 常量声明 `const` → r162 相等域 `==`→`eq` → r163 索引访问 `coll[idx]`——「one face, one name」轨迹第十步：索引访问面{`coll[idx]` → as-if-written `(vector-ref coll idx)`——数据结构消费三角第三角闭合{构造 r160 + 解构 r121 + 索引 r163}；N1 vector-ref 扩容——脱糖目标免 import 纪律}）；**自举深化窗**（r164 list 域自建迁移——五定参内建 kerf 语料自建{bootstrap/list.ktf 第 11 件 + forms 级注入 + member/assoc 性能边界泊回——「种子端应该是极小的，只有不能实现的部分，其余自建」的 BS-A 最大化前端自举行权；preamble 先例族{map/filter/foldl/for_each r109}的 list 域扩展}）；**机制窗族**（r165 变参 rest 参数——`fn f(a: T, ...rest: T)` 现代 rest 形全链{JS/TS/Rust 模式位同形 + 闭包面同权 + min-arity fail-closed + 帧建立右折叠 pair 链}——TD-038 清偿 + append 泊回实裁{TD-041 触发式} + 语料质量审计{TD-040 触发式批窗}））

## 快速开始

```bash
git clone <repo> && cd kerf
cargo build --release                          # 零外部依赖，一次构建
./target/release/kerf run examples/usage/fib.ktf
./target/release/kerf check examples/usage/closures.ktf
./target/release/kerf test examples/usage/higher_order.ktf
```

语料族：`examples/usage/*.ktf` 十六件（fib / closures / effect 族 / macros / vector / match / ffi / io / gc / higher_order）。

## 文档索引

| 域 | 入口 |
|---|---|
| 语言设计 | [docs/lang-design/00-overview.md](docs/lang-design/00-overview.md)（25 篇：语法模型 / 宏系统 / VM / 运行时 / 操作语义 / 自举策略 / 后端演进 / 术语表…） |
| 流程 SOP | [docs/sop.md](docs/sop.md) |
| 发布档案 | [RELEASE_NOTES.md](RELEASE_NOTES.md)（r1-r158） |
| 测试对账 | [docs/tests/matrix.md](docs/tests/matrix.md) |
| 阶段档案 | [docs/develop/v0/](docs/develop/v0/)（stage-0..3 + tech-debt-register + calibration-data） |
| 里程碑设计 | [docs/develop/v0/stage-3/](docs/develop/v0/stage-3/)（近窗设计单源族：命名标准化 / 残留清偿 / handle 多臂 / 向量值 / FFI 面 / WASM 组件模型…） |
| 上游存档 | [docs/stage0.md](docs/stage0.md)（外部讨论吸收链） |

---

*遵循：§8.4.5（文档以实况为准——r156 旧时代残留清偿窗交付件）/ §12（最优>最小——README 完全重构非补丁）/ 原则 44（语法定义形式化单源——示例语料取自真实审计语料库）。*

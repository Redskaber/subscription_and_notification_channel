# 综合技术债登记册

> **Author**: kerf-dev-agent（ARCH-A 角色）
> **Date**: 2026-09-11（r27/48-a 批次 J 规划轮：TD-003/TD-005/TD-015 目标时机改判 Stage 3（零消费缺口 + R6/R7 收敛纪律——依据 stage-2/plan §5d 处置表；等级/状态不动）；r17：TD-013 resolved（双路径恢复 + 合并报告 + CLI 切换）+ TD-024 新增（本地码 PoC 边界 B1）；r16：批次 F 深审全量对账——索引表补全（r3 后新增 TD-015+ 此前无索引行）+ TD-012 标记 resolved / TD-013 与 TD-009/010/014/017/018 目标时机改判 Stage 2（附 Stage 1 门放行裁定）/ TD-019/020 断档登记 / TD-023 新增（P2）；r3：TD-001/006 断档记录 + TD-005/008/011 详情补齐 + TD-012/013/014 新增 + TD-009 注记更新）
> **Version**: v0.4.23-r165（**r165 / 236-a..236-f TD-038 变参 rest 参数窗清偿（M1 指令开窗第七十例{用户四链指令「①单函数层级 ≤3、单一职责、适度长度、变量名清晰 ②继续推进目标语言设计实现窗[遇缺陷直接推进] ③按推荐序推进 ④打包同步」——TD-038 触发条件①②双满足{变参面需求信号 + 语言面设计窗}——推荐序首位唯一实际候选}）**：`fn f(a: T, ...rest: T)` 现代 rest 参数形全链交付{JS/TS/Rust 模式位同形——D1 裁定}——`...` 词法 = r129 第九皮肤映射既有 ident 载荷{零 lexer 变更零新 Token 变体}；Stx 签名沿 `...` 标记符{`(define (f a ... rest) body)`——D2-a 无标记 = 定参全语料向后兼容} + CoreExpr::Fn/IrNode::Fn 加性字段 `rest: Option<Symbol>`{原则 27} + BcProto `rest_slot: Option<u32>`{wire 协议零 bump} + 双 Reader 锁步{parse_typed_params rest 臂 + 种子 reader.ktf rest_param_tail 镜像——错误面字节级 parity} + expander parse_params/parse_rest_param 消费{终端律 + A3 重复律 + 展开期防御} + 种子/生产编译器 rest 槽位分配 + VM 三 arity 位 min-arity 门{run_closure 入口/Call/TailCall——"expected at least N" 新形 + 定参面逐字节维持} + 帧建立右折叠 nil 终止 pair 链{双池路径行为同一性——td028 四参数契约延拓} + eval.rs 树走同律 + HM/check 双面{rest = 普通类型变量 D6 零 Ty 增量 + 静态 ≥N + 超参 unconstrained} + 闭包面同权{`||(a: T, ...more: T)`}；**D7' 实施期实裁**{append 全量迁移泊回——注入/注册互斥 + 种子链热消费双阻断实测；kerf 实现已证{测试门内联 kl_va_append 全语义 + 错误面逐字节}}；ktf_variadic_rest_tests 32 case 门{8 正 + 24 负 1:3——rest 链 E2E + 混合实参数 + 闭包面 + append 五形 + Reader 结构族 ×6 + VM min-arity ×3 + 静态族 + 错误面字节锚 + r162/r164 边界回归——6 错误类覆盖}；增长锚重校准{216/507/247——+1 protos{rest_param_tail} +3 consts +1 globals}；GATE 1 六命令 2044:0:0 净 +32 + 审计 125:0 + CLI 零回归{fib 75025 + sum_rest 0/15 + 闭包 1} + bench fib 75.791ms{基线 76.506ms——-0.9% 噪声带 ✓ 定参路径零开销实证}；**TD-038 清偿关闭 + TD-040/TD-041 新登记**{语料代码质量批窗 + append 自建重迁——俱触发式}；设计单源 variadic-rest-design.md v1.0{D1-D11 + §9 诚实边界九条}；8 原语不变性第四十七轮{机制窗——零值域原语零通道零新操作码}；余留开放项 = TD-034 + TD-039 + TD-040 + TD-041 俱触发式**）；v0.4.22-r164（**r164 / 235-a..235-e list 域自建迁移窗（M1 指令开窗第六十九例{用户指令「种子端应该是极小的（只有不能实现的部分内容），其余应当全部通过自己自建实现」的 list 域行权}）**：五定参内建 length/reverse/nth/drop/last-pair 从 Rust 种子注册面迁入自建 kerf 语料 bootstrap/list.ktf{forms 级注入——preamble.ktf 先例族；级联注入{import kerf_prelude ⇒ preamble + list 双模块——nth/drop 重导出域单源} + 限定名 flat 化{list::nth → 注入 define 的 flat nth——rewrite_alias_expr Var 臂扩展} + 选择形重命名注入扩展{use kerf_list::{nth as pick}——r135 D14 同构} + RESERVED_ALLOW 预 declare 例外 + W1002 注入模块豁免} + **v1.1 性能边界裁定**{member/assoc 泊回 Rust——check-HM 查询段深度敏感热消费 37s 撞 10⁹ TCO 守卫实测；kerf 实现已证[E2E + 错误面逐字节]——TD-039 触发式重迁{native-AOT 回收就绪}} + 错误面逐字节复刻{type_name 谓词族 12 分支 + int_to_string 自建{kl_ 私有名族——撞名审计 expander/test 后避让} + arity 面 fn 形消息变更申报} + 静态域诊断退役→泛型统一面{E0005 type mismatch——fail-closed 方向维持} + 注册面四守卫对账{105/93/16/58 族计数} + ktf_list_selfbuilt_tests 33 case 门{8 正 + 24 负 1:3 + 边界复合} + 法修订涟漪十二处全数定性 + GATE 1 六命令 2012:0:0 净 +33 + 审计 125:0 + bench fib 76.506ms{+2.3% 链级}；**TD-038/TD-039 新登记**{变参面缺位 + member/assoc 重迁——俱触发式}；设计单源 list-self-built-design.md v1.1；余留开放项 = TD-034 + TD-038 + TD-039 俱触发式**）；v0.4.21-r163（**r163 / 234-a..234-f 索引访问窗（登记外行——M1 指令开窗第六十八例{用户审计清单「数据结构」项——数据结构消费三角第三角}）**：`coll[idx]` postfix 位索引中缀面开面——第十七皮肤映射 as-if-written `(vector-ref coll idx)`{Reader 直接合成与调用形产物同构的 Stx——皮肤换、骨架不变，原则 31：零脱糖零新原语零 CoreExpr/IR/操作码，expander/compiler/HM/VM 全链零触及，8 原语不变性第四十五轮} + **r138 D6 位置纪律 superseded**{双括号面俱在域——primary 位 `[a, b, c]` 字面量 r138 + postfix 位 `v[i]` 索引 r163} + **N1 vector-ref 扩容第 42 名**{D2/D3 脱糖目标免 import 纪律——r138 D4 律的索引面兑付；VM 全局注册既有零 VM 触碰；连字符直书维持 r159 中缀词法拦截——与 r162 `=` 休眠态同构} + fail-closed 三面沿用{非 Vector E0004 / 非 int 索引专用诊断 / 越界专用诊断} + **不可变维持 D5**{`v[i] = x` assign 位域外——r138 D1 执法面；可变索引赋值未来开窗须先修订 r138 D1{登记维持}} + **诚实边界 D6 三条**{pair-list 索引维持 nth 调用形{import kerf_list——对 Pair 值运行时 E0004 fail-closed 不静默分派} + Str 字符索引域外{字节/字符/码点位 = 独立设计题——未来窗域外登记} + 空索引/多参 Reader 专用诊断} + ktf_index_access_tests 32 case 门{8 正 + 24 负 1:3} + 法修订涟漪五处{corpus neg11 + vector neg15 退役 + krf_tests `1[2]` 行退役 + builtins 计数断言双修订{N1 41→42 + shrink 22→21} + fmt 清偿} + 增长签名锚 215/504/246 零增量维持；净 +31 测试 1948 → **1979——1979 基线自 r163 起**；设计单源 index-access-design.md v1.0；余留 TD-034 维持{P3 触发式——cache 富面休眠，唯一开放项}}）；v0.4.20-r162（**r162 / 233-a..233-f TD-037 相等域窗清偿关闭**：用户指令①「eq（等运算符问题，应当使用现代设计理念）」三选一行权[A：`==` 扩域至 eq 语义]——`==`/`!=` 皮肤域重指向至 `(eq a b)`/`(not (eq a b))`{双 Reader 单点换目标——原则 31 皮肤换骨架不变} + **eq 值律结构化分层**{structural_eq 用户面单源——Pair/Vector 递归结构相等[spine 迭代] + procedural 同一性维持 + 混合域静默 false[Python/JS 先例——r161 基线下 E0004/E0005 双诊断面退役]；消费面五处{eq 内建/assert-eq/member/assoc/Op::Eq}} + **r138 eq? 律修订**{Pair/Vector per-instance identity → 值相等——混血不连贯修正 + 种子 is_const_eq 手工绕路证据 + neg23 锚翻转} + `=` 内核基座休眠态申报{裸 `=` 词法为 Assign——现代面不可直书；退役 = 未来移除轮} + ordering 族维持 num/str 域 + ktf_equality_domain_tests 32 case 门{8 正 + 24 负 1:3} + 法修订涟漪九处全数定性{零真回归}；净 +32 测试 1916 → **1948——1948 基线自 r162 起**；设计单源 equality-domain-design.md v1.0}）；v0.4.19-r161（**r161 / 231-b..231-c 常量声明窗：TD-037 新登记**{跨值域相等中缀面缺口——`==` num/str 域 vs `eq` Any 域——231-b-audit 附带发现 `true == true` ⇒ E0004 实锤；P3 触发式——三选一裁定待用户[== 扩域 / eq 中缀化 / 诚实边界维持]}）；v0.4.18-r160（**r160 / 230-a..230-e TD-036 元组表达式形窗清偿关闭**：`(a, b)` 二元 pair 构造现代面——第十五皮肤映射 as-if-written `cons(a, b)`{Reader 直接合成与调用形产物同构的 Stx——皮肤换、骨架不变，原则 31：零脱糖零新原语零 CoreExpr/IR/操作码，expander/compiler/HM/VM 全链零触及，8 原语不变性第四十二轮} + 构造⟺解构对称缺口闭合{模式位 `(p, q)` r121 解构形的表达式位对偶——TD-036 登记本体清偿} + 二元封顶 D2{模式位 r121 裁定镜像——3+ 元 fail-closed 专用诊断} + 尾逗号 fail-closed D4{r138 vector 同律} + cons 调用形维持 D5{内核聚合基座名 + list 链惯用形——能力补齐非退役} + HM/check 零变更 D6{BUILTIN_SIGS (Any, Any)→Pair 既有消费——零注册链增量} + Span 契约 D10{合成 cons 符号 = `(` Token 本位——r158 合成 define 先例}；双侧 Reader 已实施[种子 parse_primary LParen 逗号臂 + 镜像 parse_tuple_tail——错误面消息+Span 字节级 parity] + ktf_tuple_expr_tests 32 case 门{8 正 + 24 负 1:3——含 as-if-written 字节码全等门 + 构造⟺解构对称 E2E + 全位置形 + 模式位回归锚} + 语料迁移三件{match.ktf describe(cons(1,9))→describe((1,9)) + gc_stress 双件离散 pair 构造位 15 处——输出 parity 逐字节} + 增长签名锚重校准{reader.ktf payload 211 protos/494 consts/242 globals} + 净 +32 测试 1852 → **1884——1884 基线自 r160 起**；设计单源 tuple-expression-design.md v1.0 Closed{GATE 1 实录回填}；开窗 = M1 指令开窗第六十五例{TD-036 触发条件①用户指令直接开窗——数据结构面现代化}）；v0.4.17-r138（**r138 / 208-c TD-002 向量值类型清偿关闭**：`Value::Vector` + `HeapObj::Vector` 元素槽位制 + GC children 臂 + 双面集合字面量 + 双侧脱糖（D2 全脱糖零 CoreExpr/操作码——原则 9 冻结） + 五内建族 + kerf-vector 模块面 + N1 可见面扩容（vector/is-vector） + 36 case 门{9正+27负} + 语料对双面 ⇒ 9；净 +37 测试 1687 → **1724——1724 基线自 r138 起**；目标语言门控任务 #5 清偿——七项全闭；8 原语不变性第二十轮{零新原语零通道零新操作码零 CoreExpr/IR 变体——历次最轻量值模型窗}；设计单源 vector-value-design.md v1.0；开窗 = M1 指令开窗第四十三例{门控任务 #5 路径——r122 match 同族先例}）；v0.4.16-r137（**r137 / 207-c TD-026 行① 部分清偿——FFI extern 声明族语言面全链**：`extern name(kinds) -> kind;` ↔ `(extern name (kinds) kind)` 双侧 Reader{第十三皮肤映射} + Keyword::Extern{第 28 名——E0020 共享域} + 驱动面五重校验{形状/可注册性 E0012 编译期/契约 E0026/查重/能力 E0006} + 分辨层 IrVar::Extern{扁平符号空间——卫生不可穿透} + 编译臂双侧发射{Op::CallExternal #43 冻结四方同步} + 值位 fail-closed + 运行表构造{声明 ∩ 在册可注册 ∩ 能力授予——write-stdio 唯一在册条目} + 32 case 门{8 正 + 24 负 1:3} + 语料对 ⇒ 9 双面；净 +32 测试 1655 → 1687——设计单源 ffi-language-surface-design.md v1.0；行②③④维持注册面显式拒绝{触发式}；开窗 = M1 指令开窗第四十二例{r74/r99 先例锚}）；v0.4.15-r136（**r136 / 206-b TD-033 组安装语义清偿关闭**：多臂 [≥2] 目标面 handle 语义自嵌套脱糖切换为组安装{Koka 式 [HANDLE-INSTALL] 读法——全臂一帧 + 任一命中整组消费 + 兄弟臂体互不保护}；VM HandlerFrame entries 多 tag 匹配 + 组消费机制 + 新操作码 INSTALL_HANDLER_GROUP #46{四方同步}；S-expr 面 handle-group 核心形式{Keyword 27 名}；嵌套语义仍可经显式嵌套手写；单臂零回归；净 +32 测试 1623 → 1655——设计单源 handle-multi-arm-design.md v1.1 §8 D11-D19）；v0.4.14-r132（**r132 / 202-b TD-033 登记——handle 多臂窗 D3 裁定载体**：多臂嵌套脱糖的 sibling 分歧（先写臂保护后写臂体、非对称）vs 组安装语义（Koka 式臂体互不保护、对称——[HANDLE-INSTALL] 读法）= 设计裁定登记非缺陷{机制层零变更}；触发判据 = 臂体 perform 兄弟标签语料消费信号或用户指令；同轮 fvo P1 缺陷清偿非 TD{当场双侧清偿——Let 臂 r45/D42 纪律延拓}）；v0.4.13-r99（**r99 / 169-a TD-031 M3 组件组合层交付——TD-031 全清偿关闭**：`crates/kerf-backend/src/wasm_compose.rs` 组合层[**imports/exports 缝合**——`compose_component(ir, model, data, abi)` → M2 边界模块 + M3 链接核心模块 + `InstantiationPlan` 有序实例化计划{双步 + wiring 图{memory + realloc 双缝合}} + **组件级类型校验** `validate_composition` 五校验全 fail-closed{地址域一致性/realloc 供给一致性/边界类型分配协议[String/List 族要求 realloc——boundary_class 递归扫描——M0 契约层 ComponentImport×InterfaceType 首次真实消费]/Func 导出背书/main 入口背书} + **L-β 效应/能力组件实例协议裁定**：perform/handle 不跨组件边界——效应承载于组件实例协议{宿主按实例实例化处理器——M0 §3「效应/能力|边界外」的 M3 落位}；结构化守护 = boundary_class 穷举全部 InterfaceType 变体{新增变体必须补分类臂否则编译期断裂——fail-closed 编译期形态}；组合面 ANF 恒效应无关{AOp=Prim|Call 无效应变体——效应程序走 VM 路径 INC7}] + `wasm_emit.rs` 增量[`CoreImportFace` 导入面 + `emit_core_module_linked(ir, face)`——Import 节 id 0x02 插 Type/Function 间 + Type 池增 realloc 签名条目{wasm32 = (i32×4)→i32 独立；memory64 = (i64×4)→i64 与四形参同构复用} + **函数索引空间基偏移**{导入函数占前位——Export main 与 Call 同步偏移}] + `wasm_compose_tests.rs` 集成 9[**node 宿主组合 E2E parity**——按计划实例化 canonical 双模块系统{validate ×2 → 实例化 kerf_abi → 其导出面作 import object 注入 kerf_core → main() 与 kerf VM run_source 逐语料对账——缝合的运行时类型检查背书}：fib 12/20 + 算术/菱形/尾位 if/互递归/div-mod 负数/i64 全宽边界 + **缝合真实性负探针** ×2{无 import object → LinkError + 错误 memory 接线 → 实例化失败} + 自定义 realloc 名接线 + memory-only 形态 + 确定性]——**净 +27 测试 1141:0:0**{单元 18 + 集成 9}；**开窗依据 = 用户 r99 M3 指令开窗第九例**[「按照 docs/sop.md 流程结合 docs/lang-design/ 下文档集合内容推进项目演进流程，按照推荐先后任务顺序继续推进」行权链 r74/r79/r80/r86/r87/r90/r92/r97/r99——第 1 位 #15 需 next18.md 未上传 → 推荐序自然落到第 3 位 TD-031 M3；**M3 判据回填**：M2 ✅ r97 + 组件组合消费方 = 用户指令 = 需求信号本体{r74 先例锚——指南 §4 响应契约「指令即触发」} + M2 双工件族组合基底{emit_core_module + emit_abi_module 并立——M2 L-A′ 裁定明文登记的后续信号路径} + node 组合实例化验证实体{本窗交付——r92 M1 同构}]；**TD-031 终态 = M0 ✅ r74 + M1 ✅ r92 + M2 ✅ r97 + M3 ✅ r99——全清偿关闭**（后续演进 = B1 扩界窗/组件实例协议窗[触发式，红线 3]）；**M3 诚实边界**：核心模块对导入面的语义消费（str 载荷 lowering）= B1 扩界窗信号——与 M2 L-A′ 同族，string_literal_rejected_before_emit 负例继续守护）；v0.4.12-r97（**r97 / 167-a TD-031 M2 canonical ABI 适配层交付**：`crates/kerf-backend/src/wasm_abi.rs` 协议层[**CanonicalAbiOptions 三字段全消费**——string_encoding → UTF-8/UTF-16 验证性串编解码{非法序列/孤立代理/奇数长度 fail-closed} + memory64 → AddressWidth 地址域 + realloc → bump 协议锚{对齐表 + 默认名}] + `wasm_emit.rs` 增量 `emit_abi_module`[Type/Function/Memory{flags 0x04 = memory64}/Global{堆指针}/Export{memory + realloc}/Code/Data 七节——realloc = None 诚实省略四节 + data > u32 fail-closed] + realloc bump 函数[(old_ptr, old_size, align, new_size) → new_ptr 四参协议——对齐 log2 + 旧数据逐字节保留 + 堆单调前进 + i32/i64 双地址域单源] + `wasm_abi_tests.rs` 集成 11[**node 宿主 str 跨界 parity**{Rust 编码 → data 段 → node 读回逐字节对账 → 解码 round-trip——UTF-8/UTF-16 双形} + realloc 协议 E2E{单调/对齐/保留/零大小边界} + memory64 字节级断言{L-C′——node 版本依赖诚实注记} + 确定性/省略面结构正例] + 单元 12——**净 +23 测试 1114:0:0**；**开窗依据 = 用户 r97 M2 指令开窗第八例**[「按照推荐先后任务顺序继续推进」行权链 r74/r79/r80/r86/r87/r90/r92/r97——第 1 位 #15 需 next17.md 未上传 → 推荐序自然落到第 3 位 TD-031 M2；**M2 判据实测回填**：M1 ✅ r92 + 边界类型消费 case ≥10 实测成立[语料库 18 .krf：10 语料消费 str + 9 消费 pair-list，行级命中 400+ ≫ 10——bootstrap 自举链全量依赖边界类型]]；**三裁定**：L-A′ M2 范围 = 协议层做实[语言面 str 字面量 lowering（ANF B1 扩界）不在 M2 范围——独立演进信号与 TD-024 Float 域同族] + L-B′ 零依赖沿袭[std::str::from_utf8 + char::decode_utf16] + L-C′ memory64 字节级验证策略；余下 = M3 组件组合[触发判据 = M2 交付 + 多组件系统需求]——触发式维持）；v0.4.11-r92（**r92 / 162-a TD-031 M1 核心模块生成交付**：WasmBackend 字节码生成第一阶段做实——`crates/kerf-backend/src/wasm_emit.rs` 自写字节码发射器[§18 L-B 裁定：零 cargo 依赖；node 仅宿主侧测试期验证工具——KERF_NODE 查找链同 qbe/cc 先例] + CFG→结构化控制递归区域分解[值菱形→`if (result i64)`+phi→local.set；尾位 if→`if (void)`+`unreachable` 垫底——anf.rs 前向良嵌套不变式逐项 fail-closed] + `WasmCoreBackend` = WasmBackend trait 首实作[bytes 承载真实 core module——原则 27 加性演化内载荷实化] + `kerf_meta` 清单自定义节回读对账[parse(emit(ir)) == model.core_funcs 双向 parity] + node 宿主 E2E parity 28 语料族[fib 144/6765 + i64 全宽真值边界 2^32——eqz 双取反非 wrap] + 净 +36 测试 **1091:0:0**；**开窗依据 = 用户 r92 M1 指令开窗第七例**[「按照推荐先后任务顺序继续推进」行权链 r74/r79/r80/r86/r87/r90/r92——第 1 位 #15 需 next14.md 未上传 → 自然落到第 3 位 TD-031（第 2 位 TD-032 ✅ r90 清偿 + 第 4 位 HM ✅ r80 清偿）]；**M1 三判据回填**：①组件消费方 = 用户指令需求信号本体[r74 先例锚] + node 宿主实体化消费验证 ②QBE 边界经验回填 = B1 共享拒绝面负例 ③**L-A WASM GC 类型裁定 = 线性类型域 i64 先行，GC 堆类型边界外维持**；余下 = M2 canonical ABI 适配[触发判据 = M1 交付 + 边界类型消费 case ≥10——str/list 跨界语料信号] + M3 组件组合[触发判据 = M2 交付 + 多组件系统需求]——触发式维持）；v0.4.10-r90（**r90 / 160-b：TD-032 第五切口（末切口）交付——缓存咨询策略面生产切换，TD-032 全清偿关闭**：`bootstrap/cache.krf` 入口 `lcache-consult`[缓存咨询策略语义移植——键构造 + bypass/hit/miss 三形决策：①键策略 .krf 单源{source-hash = lhash source 内容寻址 + cfg-fp 输入串 = "{SEED}|{filename}|{kind-tag}" 组合[string-append 二元嵌套 = Rust format! 逐字符同构]——文件名入指纹理由[产物内嵌 SourceMap] + kind 入指纹 = B11/P4 种类分桶在 .krf 面表达} + ②bypass 快路径{!enabled 早退——零哈希/零查询调用，镜像 Rust 早退臂} + ③咨询{(llookup src-hash cfg-fp) → hit/miss 分形}] + `bootstrap_cache.rs` 桥[切口桥第五实例：六参直传{enabled/source/filename/kind-tag + 两 Foreign 回调参数直传——r87 词法绑定同款} + **lhash64 回调**{hash.rs content_hash64 = A 类冻结宿主服务经 Foreign 桥暴露——「VM 原语缺位」裁定解：宿主服务永不入 VM 指令集，SHA-256 截断 u64 ↔ VM Int i64 位型透传} + **lcache-lookup 回调**{cache.rs lookup_front = A 类冻结宿主服务 + 命中快照单槽暂存 handoff——FrontOutput pub(crate) 形态不经 VM 值域/pub 面} + CachePlan 三形决策面{Bypass/Hit(CacheKey)/Miss(CacheKey)——pub CacheKey 冻结契约类型全可观测} + take_hit crate 内取回 + production_cache_is_bootstrap 活性探针] + driver.rs compile_front_cached 生产切换{cache_bridge_internal fail-closed 映射 E0002 + Stage::Compile——bootstrap_build 同构纪律} + cache_krf_parity_tests 16 case[键构造 parity 五：生产语料族/文件名区分/B11 分桶/决定性复询/分隔符边界文件名 + 咨询策略六：bypass 零副作用/新鲜未中/错误路径不缓存/停用直编译/命中快照可重复/启用×预热全形态矩阵 + 生产守护五：活性探针/check E2E 真实语料/run 缓存透明/统计计数矩阵 3×3/报告字段全等价] + 桥单元 3[状态活性 + 生产活性 + hit 快照 handoff 单槽]——净 +19 测试 **1055:0:0**；切换前后 CLI 六路径输出**逐字节一致**[run×3 + check + test 双态 + 退出码 0/1——含缓存观测文本「（缓存未中；会话命中 0/0）」逐字节]；**TD-032 五切口全落清偿关闭**（首切口 build r74 + cli r79 + test r86 + test_runner r87 + **缓存段 r90**——07 §3.3 Stage 2→3 信号「构建系统可用新语言重写」第五生产实证 + 构建系统 .krf 化余下面清零）；开窗依据 = 用户 r90 指令[M1 指令开窗第六例——「按照推荐先后任务顺序继续推进」指定方向行权 + 登记册 v0.4.9「按用户指令续窗或触发判据」用户指令路径 + r74/r79/r86/r87 先例锚；增量编译需求信号路径留档 = Stage 2 查询式增量深化[per-module 粒度/依赖图]的自然信号判据维持登记——本切口 = Stage 1 咨询策略面，非 Stage 2 增量基础设施本体]）；v0.4.9-r87（**r87/157-b：TD-032 第四切口交付**——测试运行器面生产切换：`bootstrap/test_runner.krf` 入口 `ltest-run`[cmd_test 用例切分 + 逐用例执行编排 + 结果聚合——语义移植：is-prelude-kind 切分判定单源（define/module/require/assign 前置） + truncate-name 截断单源（char 域 ≤64 字符——与 Rust chars().take(64) 同构） + run-loop 主循环（两 if 臂均尾位 TCO——长源无栈溢出） + rev-list 逆序还原 + 前置 id 逆序头插 O(1)] + `bootstrap_test_runner.rs` 桥[切口桥第四实例：项元数据投影（kind_tag + 完整渲染名） + Foreign 回调 lrun-case（前置 id 列表 + 用例 id 参数直传——词法绑定；切片重建 + handle_escape/TestFailure 效应边界短路/恢复 + run_case 嵌套 VM 独立堆/全局用例隔离） + report_from_value 协议防御解构 + 现场统计 + production_test_runner_is_bootstrap 活性探针 + Front/Internal 双通道] + 根 main.rs cmd_test 生产切换（test_source 退役 parity oracle）+ driver.rs pub(crate) 三件暴露[resolve_symbol/TestFailure/run_case——桥消费面] + test_runner_krf_parity_tests 13 case[零用例协议/单双态/混合恢复/前置重放隔离/切分全 kind/名称截断边界 64-65+Unicode/运行时错误/效应短路/前段错误通道/真实语料端到端/全形态矩阵扫描 63 源形态/活性探针]——净 +16 测试 **1036:0:0**；切换前后 CLI `kerf test` 输出逐字节一致[fib.krf 双 PASS + 退出码 0 + fail_demo FAIL+detail+退出码 1]；开窗依据 = 用户 r87 指令[M1 指令开窗第五例——「按推荐先后顺序继续任务」指定方向行权 + 指南 §4 速查卡【第 2 位】+ r74/r79/r86 先例锚]；余下一切口 = 缓存段）；v0.4.8-r86（**r86/156-b：TD-032 第三切口交付**——测试入口面生产切换：`bootstrap/test.krf` 入口 `ltest-report`[cmd_test 面分派后执行链——报告渲染 + 退出码决策语义移植：int->str 递归除余 + pad3 右对齐 {:>3} 同构 + 逐用例行 + 可选 detail 行 + 汇总行 + all_passed 退出码] + `bootstrap_test.rs` 桥[用例四元列表构造 + 单参直传 + 二元列表解构 + report_seed 退役 oracle + production_test_is_bootstrap 活性探针] + 根 main.rs cmd_test 生产切换 + test_krf_parity_tests 13 case[零用例协议/单双态/序号边界 1-1000/Unicode/全失败/全形态矩阵扫描/真实语料端到端/活性探针]——净 +15 测试 **1020:0:0**；切换前后 CLI `kerf test` 输出逐字节一致[fib.krf 双 PASS + fail_demo FAIL+detail+退出码 1]；开窗依据 = 用户 r86 指令[M1 指令开窗——「按推荐先后顺序继续任务」指定方向行权 + 指南 §4 速查卡【第 2 位】+ r74/r79 先例锚]；余下两切口 = 测试运行器/缓存段）；v0.4.7-r80（**r80/150-b：HM 默认期生产切换——12 §2.5.1 K3 终态窗口行权清偿**：用户 M1 指令开窗[指南 §4 速查卡【第 4 位】第三次行权]——`kerf check` 判定面切换 check.krf 路径 + Rust hm_check_program 退役 oracle/fallback + 四类诚实边界语义重锚[krf ⊆ oracle] + 1005:0:0 + 三语料锚重定[319/145/193 → 0/1/0]——外源触发窗 #18 清偿关闭[12-roadmap v6.22 §2.5.1 终态注记]）；v0.4.6-r79（**r79/149-b：TD-032 第二切口交付**——CLI 编排面生产切换：`bootstrap/cli.krf` 入口 `lcli-dispatch`[main.rs 原 match 分派逐臂语义移植——十二元组真值 + eval 退役 + 三元组缺文件 + 未知兜底] + `bootstrap_cli.rs` 桥[两参直传 + Symbol 标签重建 + dispatch_seed 退役 oracle] + 根 main.rs 生产切换 + cli_krf_parity_tests 23 case[全矩阵扫描 30 组合 + 生产活性探针]——净 +24 测试 997:0:0；开窗依据 = 用户 r79 显式指令[M1 指令开窗——t3plus-manual-trigger-guide §4 速查卡【第 2 位】行权 + r74-window-opening §1 先例锚]；余下三切口 = 测试入口/测试运行器/缓存段）；v0.4.5-r74（**r74/144-c·144-d：TD-031 + TD-032 双登记**——TD-031 WasmBackend 字节码生成[组件模型契约层已 r74 做实：kerf-backend/wasm.rs 接口类型/组件边界/canonical ABI + AnnotatedANF 派生件；M1-M3 触发式三判据——设计载体 stage-3/wasm-backend-component-model.md §5] + TD-032 构建系统 .krf 化余下面[首切口已 r74 生产切换：build.krf prelude 注入判定；余下 = 缓存段/CLI 编排/测试运行器/测试入口——07 §3.2 v6.5 注记]；开窗依据 = 用户 r74 显式指令[r74-window-opening §1 回填表]）；v0.4.4-r71（**r71/141-a：TD-002 向量部分 dangling 再裁定**——PHASE 1 路由 R1 检测发现：索引行「向量开放→Stage 2」但 Stage 2 已 r37 收口未交付（`LiteralValue` 无 Vector 变体 + expander.rs `StxDatum::Vector(_) => Err` 显式报错实证），r56 审计 13 行未覆盖（状态列「已解决（符号 r5）」部分标记掩盖向量开放）→ 再裁定为 T3+ 触发式三判据（与目标语法轮/FFI 编组联动——详情节 r71 注记）；同轮净增量 = [bootstrap-replacement-surface-map.md](./stage-3/bootstrap-replacement-surface-map.md) v1.0（B 类前瞻义务识别兑现件））；v0.4.3-r56（**r56/78-b：T3+ 触发态审计 + dangling 目标再裁定**——TD-003/005/015/024/026 五项目标时机自「已关闭窗口」再裁定为 T3+ 触发式三判据（TD-008 样板式可监测化）+ TD-024 承接件清偿状态修正 + TD-028 索引行清偿终态补齐（r54-r55 实况对齐）+ OBS-C 监测锚注记；承载 = [t3plus-trigger-audit.md](./stage-3/t3plus-trigger-audit.md)）；v0.4.2-r50β（**r50-β/72-b：TD-030 清偿**——check+prelude 组合 E0005 假阳性消除：D6 ② let 形状识别退役[infer_let 删除——逐绑定 solve_now 提前求解机制退役]；覆盖缺口闭合[td030_check_prelude_combo_clean 五验：原形态/for-each/prelude 全模块/双导入/真 occurs 维持检出——22 §17.6]）；v0.4.1-r49（**r49/70-b：TD-030 登记**——check+prelude 组合的 HM occurs 误报[前置既有缺陷，r48 基线 stash 对照逐字一致失败实证]；发现载体 = r49 CLI 冒烟 check 面；修复窗 = r49-β let 直映臂 hm Let 臂重做[22 §17 D61 同区域]）；v0.4.0-r47（**r47/68-b：TD-029 清偿**——N1 扁平面收缩六件合同全实施[E0022 面核对 + 语料 import 迁移 + W1003/W1002 face-aware + E0004 接管 face-aware + prelude 载荷化 + E0013 underlying 同一性重基]；D54 出口条件四项全过[语料 import 完备由 854:0:0 面核对 fail-closed 实证 + face-aware 零误报双证 + d55 对账组 8 case ≥8 + 非正交点计数归 S4 同窗复核]——详见详情节清偿记录）；v0.3.0-r46：TD-029 新增；r30：TD-026）
> **Status**: Active（**r24 批次 I 执行 42-e：TD 五项 resolved（TD-010 Foreign 装箱 + TD-011 字符串全序 + TD-014 嵌套 define 归因 + TD-018 消息单源统一 + TD-023 根扫描对症——GcCell 摘要 + 缓冲复用，非尾形基准 -27%）+ TD-008 裁定 DEFER（实测依据三面——见详情）**；r23 批次 I 执行 42-d：TD-017 + TD-009 联动 resolved（INC7 清单兑现——eval 参考路径退役，两域随路径注销）；r21/r22 批次 I 执行 42-b/42-c：无新增/无 resolved（段迁移零债务面——module 名覆写值等价注记入 i1-design v1.2）；r20 批次 I 执行启动：无新增/无 resolved——设计轮（42-a I1 切口设计）零债务面；eval 退役裁定已设计锁定排 42-d（INC7）——兑现于 r23；r19 批间插入轮：无新增/无 resolved——设计轮 + 骨架冻结零债务面；口径注记：矩阵 r18 版集成计数 438 勘误为 436（198+438=636≠634 内部矛盾——实测 436 与 r17 增量链 409+27 吻合））
> **规则**: sop.md §6.2.1——新增已解决项/调整剩余项优先级（每子阶段必检）

## 索引

| TD ID | 标题 | 等级 | 状态 | 目标阶段 |
|-------|------|------|------|---------|
| TD-001 | （编号断档——不可考） | — | 断档存档 | — |
| TD-002 | quote 符号/向量值类型缺失 | P3 | **已清偿关闭（符号 r5；向量 ✅ r138 / 208-c——M1 指令开窗第四十三例）**：向量值类型全链交付——双面集合字面量{S-expr `[a b c]` 既有 datum + target `[a, b, c]` 第十四皮肤映射（逗号省略）} + 双侧脱糖{表达式位 D2-a `[a b c]` → `(vector a b c)` + quote 位 D2-b 递归字面量脱糖——零 CoreExpr/IR/操作码变更（原则 9 冻结维持——match r122 同律）} + 值模型{`Value::Vector` + `HeapObj::Vector(Vec<GcRef>)` 元素槽位制 + GC children 臂 + 渲染 `[1 2 3]` 括号形可回读} + 五内建族{vector/vector-length/vector-ref/vector-append/is-vector——kerf-vector 限定模块 + N1 可见面{vector 构造器 + is-vector 谓词——字面量可用性强制}} + 36 case 门{9 正 + 27 负 1:3——含 GC 存活实证/跨语法字节码 parity/遮蔽捕获律} + 语料对 vector.{ktf,krf} ⇒ 9 双面同输出；净 +37 测试 1687 → 1724——设计单源 [vector-value-design.md](./stage-3/vector-value-design.md) v1.0{D1-D10 + §7 域外表七行}；目标语言门控任务 #5 清偿（[门控清单](./stage-3/target-language-gated-tasks.md) 七项全闭） | ~~Stage 1~~ 符号 r5 + 向量 r138 ✅ 全清偿关闭 |
| TD-003 | 图 IR 复合节点 CSE 共享 | P3 | 开放 | ~~Stage 2~~ → ~~Stage 3 优化窗口（v6.3/r27 改判）~~ → T3+ 触发式三判据（r56/78-b 再裁定——[审计 §3.1](./stage-3/t3plus-trigger-audit.md)） |
| TD-004 | 作用域集解析（Racket 式）替换名称基解析 | P2 | **已解决（r13——编译器/eval 双路径 (name, scopes ⊆) + max-cardinality；锚点 9 测试）** | Stage 1 |
| TD-005 | syntax-parse 级宏组合 | P3 | **部分清偿（r106 / 176-b——TD-005 窗开窗[M1 指令开窗第十三例]**：R7RS 收集语义[复合省略号克隆-提交 → 正典——r101 窗内义务兑现] + 尾省略号固定尾部 `(a ... b)`[R7RS 4.3.2] + 模板转义 `(... template)`[R7RS 4.3.3] 双面交付[macro_sys.rs 种子 + expander.krf 镜像] + letrec 诚实边界裁定[维持内置——常量按迭代生成在声明式模板语义外，R7RS 同界]；净 +3 测试 1146:0:0。**残留维持触发式**：嵌套省略号深度 2+[fail-closed 登记边界——深度追踪架构位] + 结构化 DSL 守卫/属性面[syntax-parse 类扩展]——[审计 §3.2](./stage-3/t3plus-trigger-audit.md) v1.26） | ~~Stage 2~~ → T3+ 触发式三判据（r56/78-b 再裁定——r106 用户指令行权第十三例） |
| TD-006 | （编号断档——不可考） | — | 断档存档 | — |
| TD-007 | 迭代式展开工作表（深度上限解除：128→500→**10_000**） | P2 | **已解决（r18 / 40-c——完整口径）**：Stx Rc 共享化（List/Vector → `Rc<Vec<Stx>>` clone O(1)）+ retag 迭代式重建（显式工作表后序——栈深恒定）+ 均匀标记 O(1) 共享（链 N 步总工作量 O(N)，旧 O(N²)）+ 扁平 Drop（唯一持有脊柱工作表拆除）；上限 500→10_000（种子 + 自举 expander.krf 同步）；10_000 链测试 0.02s 通过 + 10_001 边界报错 | ~~Stage 2 批次 H2~~ 已交付 |
| TD-008 | 分代 GC / 堆压缩 | P3 | **裁定 DEFER（r24 / 42-e——实测依据三面）** | Stage 3+（条件触发重评估） |
| TD-009 | eval 路径 GC 根集枚举 | P3 | **resolved（r23 / 42-d）**：eval 路径自 driver 生产面退役（P5/INC7 联动注销）——GC 根集域随路径注销（生产 run 路径根集完整：栈+帧+全局；kerf-vm eval.rs 存档参考面非 GC 消费） | ~~Stage 2（eval 重写同轮评估）~~ 已交付 |
| TD-010 | 闭包/内置函数装箱（pair 元素） | P3 | **resolved（r24 / 42-e）**：HeapObj::Foreign(Rc<ForeignBox>)——类型擦除 Rc 载体 + 装箱方注入追踪器（标记阶段枚举闭包捕获图）；解箱往返 Rc 恒等（eq? 按引用）；渲染 #<procedure>/#<builtin:名> | ~~Stage 2~~ 已交付 |
| TD-011 | 字符串全序比较 | P3 | **resolved（r24 / 42-e）**：全字符串链按 Unicode 码点序参与全部比较族（Rc<str> 比较 = UTF-8 字节序 = 码点序——编码保序性）；混合链保持 `{op} 需要数值`（TD-016 口径）；静态面 R3 同步（Ordering ≡ NumOrAllStr） | ~~Stage 2~~ 已交付 |
| TD-012 | expander.rs 单文件拆分候选 | P3 | **已解决（批次 B 前端重写落地六文件）** | ~~Stage 1（切换期）~~ |
| TD-013 | 多错误收集 / Expander 恢复展开（单错误短路） | — | **resolved（r17 / 38-e）**：种子+自举桥双路径形式级恢复 + DiagCollector（128 上限/截断/位置序）+ check_source_recover 合并报告（E0002+E0005）+ CLI check 切换恢复模式；16 集成测试全过 | ~~Stage 2 批次 G2~~ 已交付 |
| TD-014 | 展开期错误消息归因失真（嵌套 define） | P3 | **resolved（r24 / 42-e）**：专门消息「嵌套 define 重复绑定」+ Span 指向第二次出现处（seed expand_body + 自举 expand-body-hoist 镜像 + parity 2 case 逐字一致） | ~~Stage 2~~ 已交付 |
| TD-015 | IrGraph 无条件计算旁路丢弃 | P3 | 开放 | ~~Stage 2（切换期重构）~~ → ~~Stage 3 优化窗口（v6.3/r27 改判）~~ → T3+ 触发式三判据（r56/78-b 再裁定——与 TD-003 同窗联动，[审计 §3.3](./stage-3/t3plus-trigger-audit.md)） |
| TD-016 | 链式比较短路语义静态收紧 | P3 | **已解决（r7）** | ~~Stage 1~~ |
| TD-017 | eval 参考路径深度上限不对称 | P3 | **resolved（r23 / 42-d）**：eval 参考路径自 driver 生产面退役（P5/INC7——CLI eval 子命令移除 + eval_source 删除）——**256 深度上限域随路径注销**；生产 VM 路径经 TCO 帧复用无深度上限（105_000 层尾递归正确终止——`deep_tail_recursion_production_path_tco` 重写口径实测）；kerf-vm eval.rs 存档为 Rust 参考实现（scope_set_tests 语义 oracle 消费面保留） | ~~Stage 2（I1 eval 重写时随迁评估）~~ 已交付（INC7 联动注销） |
| TD-018 | 双路径错误消息文本分裂 | P3 | **resolved（r24 / 42-e）**：kerf-vm messages.rs 单源构造器（if 条件/not/car/cdr/set! 五族）；Value::truthy 复活为单一实现（VM JumpIfFalse + eval if 臂同源）；未绑定族裁定为保留的阶段信息差异（VM 携全局兜底完成度） | ~~Stage 2~~ 已交付 |
| TD-019 | （编号断档——不可考，r16 登记） | — | 断档存档 | — |
| TD-020 | （编号断档——不可考，r16 登记） | — | 断档存档 | — |
| TD-021 | 高阶函数用户面注入缺载体 | P3 | **已解决（r15——kerf-prelude 模块/import 承载）** | ~~Stage 1 批次 E~~ |
| TD-022 | 自举 Reader/Expander 帧消耗 O(源字符数) | P3 | **已解决（r18 / 40-c——TCO 兑现）**：VM 尾调用优化（Op::TailCall 帧复用 + 编译器尾位穿线（Lambda 体/If 两臂/Begin 末项）+ 内建尾调用隐式 RET + 指令预算护栏 10^9 兜底无限尾循环）；实证：127,780B 源（>10^5 字符边界）自举管线完整通过 + 自举 expander 10_000 深度链端到端（TD-007/TD-022 耦合解除） | ~~Stage 2 批次 H2~~ 已交付 |
| TD-023 | gc_stress 深递归 GC 根扫描回归（超线性） | P3（r18 降级） | **resolved（r24 / 42-e）**：基准重定型（gc_stress_nontail 非尾形锚定——改前 144.06ms/轮 + 2×→3.2-3.7× 超线性实测成立）+ 对症双件（GcCell 堆根性摘要——非堆单元 O(1) 跳过；根扫描缓冲跨周期复用——无分配化路径 B）→ **非尾形 -27.1%（144.06→105.15ms）**；尾形 gc_stress -2.8% / fib -3.1%（±5% 噪声带 ✓）；残留超线性（2×→3.4×）如实归因 = 帧栈内存 churn + 每周期固定成本（精确 MS 栈根扫描的结构性成本，非分配模式缺陷） | ~~Stage 2 批次 I2~~ 已交付 |
| TD-024 | 本地码后端 PoC 边界（整数域十二原语 + 直接调用；闭包/Float/Str/Pair/set!/module/IO/函数值一等边界外；**r25 扩界注记**：perform/handle 效应形式同口径显式拒绝——效应语义由 VM 路径承载（anf LowerError B1 类），native 效应化属 Stage 3 后端演进评估项） | P3 | **登记（r17 / 38-b·38-c）**：显式错误非静默降级（B1 类）；FFI 面（print/write_stdout）按 ffi-ownership-model 批次 I 做实；闭包/GC 协同批次 H/I | ~~Stage 2 批次 H-I（GC-后端协同轮）~~（承接件已清偿：FFI 面 r30 + 闭包/GC 协同 r24-r25）→ T3+ 触发式三判据（r56/78-b 再裁定——[审计 §3.4](./stage-3/t3plus-trigger-audit.md)） |
| TD-025 | 自举侧 retag 无均匀标记快路径（包装宏链 O(N²) VM 工作） | P3 | **resolved（r18 / 40-f）**：krf 六头字段协议落地——`(tag s e exp scopes uni . fields)`（`uni = ('uni . scopes)` 均匀证书，make-node 默认 nil + retag 重建置位 + inject-scope 注入清除 + 桥 stx_to_node 同步）；retag-scope 快路径（uni 命中 → 整棵子树 O(1) 共享——种子 uniform_tag 镜像）；实测门审计 C02 包装链 **>540s → 7.37s（73×+）**；双审计集 EXIT 0（stage0 41 + stage1 51，20s/28s） | ~~Stage 3~~ 已交付 |
| TD-026 | FFI 语言面形式 + 编组消费子集收窄（FFI 三操作码 VM 面 r30 已做实；**语言面语法/extern 声明形式 ✅ r137 行① 部分清偿**（编译臂发射——双侧 Reader + 驱动面五重校验 + 分辨层 IrVar::Extern + Op::CallExternal 发射 + 能力门 + 运行表构造）；CStruct 逐字段递归编组/CFunction 回调通路/`FfiCall::FreeExternal` 非令牌实参 lowering 均未消费——注册面显式拒绝或编译期拒绝（诚实收窄注记维持）） | P3 | **部分清偿（r137 / 207-c——M1 指令开窗第四十二例）**：行① extern 声明族语言面全链交付（双侧 Reader + 32 case 门 + 语料对 ffi.{ktf,krf} ⇒ 9 双面——设计单源 ffi-language-surface-design.md v1.0 §7 域外表）；行②③④ 维持注册面显式拒绝（触发式：interop/token 语料信号） | ~~Stage 3（语言面形式批次）~~ → ~~T3+ 触发式三判据（r56/78-b 再裁定）~~ 行① r137 用户指令行权清偿；余②③④触发式维持（[审计 §3.5](./stage-3/t3plus-trigger-audit.md)） |
| TD-028 | VM 主分派与 GC 根扫描性能漂移 | P3 | **已清偿关闭（r54-r55 / 76-b·77-b）**：分派优化 O1+O2+O3（fib 1.195x）+ 帧槽池 P1+P3（1.067x）——相对 r24 原始基线 84.2ms 净超越 1.18x；OBS-C 观察项接续（T3+ 触发式——fib <65ms 需求信号，预防式不引入） | ~~Stage 3（性能窗口）~~ ✅ r55 清偿关闭 |
| TD-029 | N1 扁平面收缩——可见性收紧腿（import 可见性载荷化：47 模块扁平名出 N1 全局无条件面 → import opt-in；启用件已 r46 交付[顶层 import + E0022 基线 + 双形执法 + prelude 元数据]） | P2 | **已清偿（r47 / 68-b）**：六件合同全实施 + D54 出口四项全过（854:0:0 面核对 fail-closed 实证 + d55 组 8 case + face-aware 零误报双证）——清偿记录见详情节 | ~~Stage 3（E5 窗口 r47）~~ ✅ r47 |
| TD-030 | check+prelude 组合 HM occurs 误报（E0005 假阳性——递归 define 体 let-discard 值约束流入递归合一链） | P1（check 面功能缺陷——run 路径零影响） | **已清偿（r50-β / 72-b）**：D6 ② let 形状识别退役（infer_let 删除——逐绑定 solve_now 提前求解机制退役）→ E0005 假阳性消除；覆盖缺口闭合（td030_check_prelude_combo_clean：①原形态 ②for-each ③prelude 全模块 ④双导入 ⑤真 occurs 维持检出）——清偿记录见详情节 | ~~r49-β let 直映臂~~ ✅ r50-β（D61 实施） |
| TD-031 | WasmBackend 字节码生成（M1 核心模块生成 / M2 canonical ABI 适配 / M3 组件组合——**组件模型契约层已 r74 做实**：`kerf-backend/src/wasm/mod.rs` 接口类型 + 组件边界 + canonical ABI 选项 + AnnotatedANF → 组件模型派生 + 构建器 fail-closed 校验；`WasmComponent` 双字段信封演化[原则 27 加性]；零外部依赖[§18 纪律]；**M1 核心模块生成已 r92 做实**：`kerf-backend/src/wasm/emit.rs` 自写字节码发射器[LEB128 + Type/Function/Export/Code 节 + `kerf_meta` 清单自定义节] + CFG→结构化控制递归区域分解[值菱形→`if (result i64)`；尾位 if→`if (void)`+`unreachable` 垫底] + `WasmCoreBackend` = WasmBackend trait 首实作[bytes 载荷实化] + 清单回读对账 + node 宿主 E2E parity 28 语料族 + 净 +36 测试 1091:0:0——开窗依据 = 用户 r92 M1 指令[第七例] + 三判据回填[L-A GC 类型裁定 = 线性域 i64 先行]） | P3 | **已清偿关闭（r74 / 144-c；M1 ✅ r92 / 162-a；M2 ✅ r97 / 167-a；M3 ✅ r99 / 169-a）**：M0 契约层 ✅（8 契约测试 + 指纹链锚）；**M1 核心模块生成 ✅ r92**（用户 M1 指令开窗第七例——判据回填见 v0.4.11）；**M2 canonical ABI 适配 ✅ r97**（用户 M2 指令开窗第八例——判据实测回填见 v0.4.12）；**M3 组件组合 ✅ r99**（用户 M3 指令开窗第九例——判据回填：M2 ✅ + 组件组合消费方 = 用户指令 = 需求信号本体[r74 先例锚] + M2 双工件族组合基底 + node 组合实例化验证——wasm_compose.rs 组合层[InstantiationPlan 缝合 + 组件级类型校验五校验 + L-β 效应/能力组件实例协议裁定] + emit_core_module_linked 链接发射[Import 节 + 函数索引基偏移] + node 组合 E2E parity + 缝合负探针 ×2 + 净 +27 测试 1141:0:0）——**TD-031 四阶段全落全清偿关闭**（后续演进 = B1 扩界窗/组件实例协议窗[触发式，红线 3]——[wasm-backend-component-model §5](./stage-3/wasm-backend-component-model.md) v1.3） | ~~T3+ 触发式（M3 入口信号）~~ ✅ r99 全清偿关闭（M1 指令开窗第九例） |
| TD-032 | 构建系统 .krf 化余下面（**首切口已 r74 生产切换**：`bootstrap/build.krf` prelude 注入判定；**第二切口已 r79 生产切换**：`bootstrap/cli.krf` CLI 编排分派判定；**第三切口已 r86 生产切换**：`bootstrap/test.krf` 测试入口执行链——`ltest-report` 报告渲染 + 退出码决策 + parity 13 case——1020:0:0 + CLI 逐字节一致；**第四切口已 r87 生产切换**：`bootstrap/test_runner.krf` 测试运行器编排——`ltest-run` 用例切分 + 逐用例执行编排 + 结果聚合[切分判定/截断/序号 .krf 单源 + Foreign 回调嵌套 VM 用例隔离 + 效应边界短路/恢复] + parity 13 case + 活性探针——1036:0:0 + CLI 逐字节一致；**第五切口（末切口）已 r90 生产切换**：`bootstrap/cache.krf` 缓存咨询策略——`lcache-consult` 键构造 + bypass/hit/miss 三形决策[键策略 .krf 单源 + lhash64/lcache-lookup 两 Foreign 回调{A 类冻结宿主服务经桥暴露——「VM 原语缺位」裁定解} + 命中快照单槽 handoff] + parity 16 case + 桥单元 3 + 活性探针——1055:0:0 + CLI 六路径逐字节一致；07 §3.3 Stage 2→3 信号第五生产实证 + **余下面清零——构建系统 .krf 化全收口**） | P3 | **已清偿关闭（r90 / 160-b）**：五切口全落（build r74 + cli r79 + test r86 + test_runner r87 + **缓存段 r90**）；增量编译需求信号路径留档 = Stage 2 查询式增量深化[per-module 粒度/依赖图]的自然信号判据——本切口 = Stage 1 咨询策略面（cache.rs 存储本体 = A 类永久基座永不替换——替换面图 §3.4） | ~~T3+ 触发式 + 用户指令续窗~~ ✅ r90 清偿关闭（M1 指令开窗第六例） |
| TD-033 | 组安装语义（Koka 式 handle 臂体互不保护）——多臂嵌套脱糖的 sibling 分歧登记：嵌套语义下先写臂的 handler 体不受后写臂保护、后写臂的 handler 体受先写臂保护（非对称——嵌套结构自然结果）；组安装语义（[06 §10](../../../lang-design/06-operational-semantics.md) [HANDLE-INSTALL] 的 Koka 式读法——臂体互不保护、对称）需 HandlerFrame 多 tag 匹配 + 组消费机制变更（VM/expander/compiler 两侧） | P3 | **已清偿关闭（r136 / 206-b——M1 指令开窗第四十一例）**：组安装全链实施——CoreExpr::HandleGroup + S-expr 面 `handle-group` 核心形式{Keyword 27 名——E0020 共享保留域扩展} + VM `HandlerFrame.entries` 多 tag 匹配 + **组消费**{命中帧整体替换——兄弟臂对臂体/恢复后计算皆不再保护} + 新操作码 `INSTALL_HANDLER_GROUP` #46{四方同步：opcode.rs enum ↔ `opcode_count_matches_spec` 47 ↔ [04 §1](../../../lang-design/04-bytecode-vm.md) ↔ compiler.krf OP-* 表 + 桥 46 臂} + 双侧编译链{compile.rs emit_handle_group + compiler.ktf compile_handle_group——组等价字节码全等门} + HM/check 双侧{A4 纪律维持 + 'handle-group unsupported 跳过——krf ⊆ oracle} + ktf_handle_multiarm_tests 32 → 64 case 门{16 正 + 48 负 1:3——含同胞非保护/组消费语义锚 + S-expr 语法族 24 负}；嵌套语义仍可经显式嵌套手写{D11}；单臂零回归{D1 锚}；语料对重写 ⇒ 217 双面；净 +32 测试 **1623 → 1655**；设计单源 [handle-multi-arm-design.md v1.1 §8 D11-D19](./stage-3/handle-multi-arm-design.md) | ~~T3+ 触发式（触发判据：臂体 perform 兄弟标签语料消费信号或用户指令）~~ ✅ r136 用户指令行权清偿关闭 |

## 详情

### TD-001 / TD-006 编号断档记录（r3 登记）

**编号断档：早期开发轮次消化，具体去向不可考——登记于 r3。** 考证过程（2026-09-10）：
(1) 全库 git 历史（4 commits）与 worklog 全文检索「TD-001」「TD-006」零命中——两个编号
**从未被登记过任何内容**；(2) 登记册于 worklog Task 6（工程文档树）创建时即自 TD-002
起编（TD-005/TD-008/TD-011 同批仅索引行），推断为创建时的**编号跳号笔误**而非
「已解决项消失」——不存在应留而未留的解决痕迹。**处置**：两个编号永久保留为断档占位
（禁止复用），以满足 §6.2 规则 2「大阶段末全审须闭环『已解决项确实消失』」的审计要求；
后续新增债一律从 TD-015 起编。

### TD-002 quote 符号/向量值类型缺失（r5 符号部分解决）
- **描述**：`LiteralValue` 无 Symbol/Vector 变体——`(quote sym)` 显式报错
- **根因**：Stage 0 值模型最小化（§3.2 literal_value 定义如此）
- **修复方案**：Stage 1 增加 `Value::Symbol`；quote 符号 datum → 符号值
- **r5 执行注记**（2026-09-10，批次 B Task 22-a）：**符号部分已解决**——
  全链落地：`LiteralValue::Symbol(Rc<str>)`（存剥离卫生后缀的基名，
  Racket 语义近似——与 resolve_hygiene_fallbacks 同一剥离口径）/
  `Value::Symbol` + eq? 按名相等 + `BcConst::SymLit`（与全局名索引
  `Symbol` 变体严格区分，§11 接口隔离）/ `HeapObj::Symbol`（符号入序对）
  / `ValueSlot::Symbol`（car/cdr 往返）；双路径（VM const_to_value +
  eval eval_literal）同步覆盖；宏模板内 quote 符号的卫生后缀在 datum
  层剥离（实测验证）。**向量部分仍开放**（显式报错——~~后续阶段~~）；
  正负测试 +5 函数（expander 2 / vm 3）+ 负例 6 case（符号值语义误用
  ——算术/条件/序对/比较位置），实跑校准消息。
- **影响范围**：expander::datum_to_value / vm::value / runtime::heap /
  compiler::bytecode（r5 实际触点比登记时扩大——含堆装箱三处）
- **代码锚**：kerf-core（literal_value 定义）；负测锚点：negative_expander_tests::quote_misuse（向量 case 保留）
- **优先级依据**：符号值影响宏编程体验（P3——不影响语义验证闭环）

> **r71 目标时机再裁定（141-a——dangling 清偿）**：~~Stage 2~~（窗未开即收口 r37——dangling，r56 审计未覆盖：状态列「已解决（符号 r5）」部分标记掩盖向量开放）→ **T3+ 触发式三判据**：①**语料消费信号**：.krf 语料出现 vector 字面量/quote 向量消费需求（当前语料 `#(` 零消费——`StxDatum::Vector` 词法面在位、展开面显式报错如实收窄）；②**目标语法轮联动信号**：目标语法轮开窗（match 表面消费信号命中——[23 §2.2](../../../lang-design/23-evolution-governance.md)）时集合字面量表面随窗评估（Rust/Go 风格目标语法自然携带 `[1 2 3]` 形态——[12 §2.4.1](../../../lang-design/12-roadmap.md) 蓝图位）；③**FFI 编组消费信号**：vector 作为 CStruct 编组目标形态需求（与 [TD-026 判据 2](#td-026-ffi-语言面形式--编组消费子集收窄) 同源联动）。本轮零信号命中——维持待触发（红线 3）。承载 = [bootstrap-replacement-surface-map §5 缺口 5](./stage-3/bootstrap-replacement-surface-map.md)。

### TD-003 图 IR 复合节点 CSE 共享
- **描述**：字面量/变量节点按结构键共享；复合节点不做激进 CSE
- **根因**：§21.11 风险表既定缓解（图 IR 过于复杂 → 树承载 + Stage 2 迁移）
- **修复方案**：Stage 2 哈希cons 复合节点 + SSA 化
- **workaround**：字面量共享已满足「公共子表达式」演示与验收

> **r56 目标时机再裁定（78-b——T3+ 触发态审计）**：~~Stage 3 优化窗口~~（Stage 3 已收口 r52 未消费——dangling）→ **T3+ 触发式三判据**（[t3plus-trigger-audit §3.1](../stage-3/t3plus-trigger-audit.md)：①IR 第二生产消费方出现[当前 anf.rs 独立承载] ②`kerf ir` 剖面复合节点重复占比 >30% ③编译期 P95 >100ms 且 IR 面热点[当前自举四件 <1ms + VM 链 99.77%]）。本轮零信号命中——维持待触发（红线 3）。

### TD-004 作用域集解析
- **状态（r13，批次 E 首个 MUV）**：**已解决**——展开器绑定形式 fresh scope 深注入（`Stx::add_scope_to_all`）+ `CoreExpr::VarRef/SetBang` 携带引用作用域集 + `Lambda.param_scopes` 携带绑定作用域集 + 编译器 `resolve_var` 与 eval `Env::lookup/set` 双路径切换为 `(name, scopes ⊆)` 子集匹配 + max-cardinality；空作用域集全局绑定 ⊆ 任意引用集——全局/内置天然兑底，`$hyg$` 基名回退（driver 双侧）降级为回退路径；α 重命名保留为第二道卫生保险（作用域注入不变式下两层同解）。锚点 = tests/v0/stage1/plan/scope_set_tests.rs（9 测试：双路径正例 5 + 作用域不匹配负例 3 + 宏引入不捕获 1）；500 基线零回归（r13 实测 509:0:0）。
- **描述**：标识符解析为名称基（编译期 slot 查找 + 运行期全局名）；
  Racket 式 scope-set 子集匹配未实现（ScopeSet 已在数据结构中全程携带）
- **根因**：名称基 + 一致性卫生重命名已满足 P1 卫生保证；
  scope-set 解析是 Stage 1 语言级宏的前置
- **修复方案**：编译器 resolve 按 (name, scopes ⊆) 匹配绑定（✅ r13 落地）
- **卫生回退**：$hyg$ 后缀剥离（driver::resolve_hygiene_fallbacks +
  **driver::resolve_eval_hygiene_fallbacks**——r3 已接线 eval 路径，双路径镜像）为
  名称基解析的显式近似
- **测试锚点**：negative_semantics_tests::t1_regression_hygiene_fallback_dual_path（3 case）

### TD-005 syntax-parse 级宏组合（r3 补详情）
- **描述**：syntax-rules 为骨架子集——**单层省略号边界**；点对模式尾部、尾省略号 + 固定尾部、
  展开转义 `(… template)`、嵌套省略号（多维笛卡尔展开）未实现（03 §2.3 v5.2 Stage 0 裁定注记）
- **根因**：宏组合表达力非 Stage 0 语义验证闭环的必要项（deep-review R1 偏差 #1 的
  「实现合理（Stage 0 骨架）」裁定）
- **修复方案**：Stage 2 syntax-parse 类结构化宏 DSL + 文法全量实现
- **代码锚**：kerf-expander/src/macro_sys.rs:4（显式推迟注记）
- **workaround**：单层省略号 + Rust 内置变换器（§3.2 糖推导全表）覆盖 Stage 0 全部需求
- **测试锚点**：negative_expander_tests::syntax_rules_misuse / macro_expansion_failures

> **r56 目标时机再裁定（78-b——T3+ 触发态审计）**：~~Stage 3 宏增强窗口~~（dangling——窗未开即收口）→ **T3+ 触发式三判据**（[t3plus-trigger-audit §3.2](../stage-3/t3plus-trigger-audit.md)：①单层省略号不可表达缺口信号[语料零嵌套省略号需求形] ②syntax-parse DSL 提案[与 23 §5.2 编译期令牌行同锚] ③自举宏臂剖面热点[当前 expand 13.4% 非主导]）。零信号维持待触发。

### TD-007 迭代式展开（r4 部分解决注记）
- **描述**：展开深度上限 128（rustc 默认对齐）；文档示例 10_000 需迭代式
- **修复方案**：展开工作表化（显式队列替代递归下降）
- **测试锚点**：negative_expander_tests 宏深度超限负例（超限报错而非栈溢出）
- **r4 执行注记**（Stage 1 批次 A3，2026-09-10）：trampoline 工作表已落地
  （expand_form 顶层循环——宏产物头部仍是宏调用时迭代继续，展开控制流
  栈深与链长解耦）；上限 128→500（实测标定：2MiB 测试线程 1_000 通过/
  2_000 溢出，500 = 2× 裕度——TD-017 同型实测法）。**残留**：完整 10_000
  口径受 Stx 值语义深树的 clone/drop 递归约束（数据结构层）——批次 B
  前端重写时 Rc 化解除；探针实测记录：8MiB 主线程 4_000 通过/5_000 溢出

### TD-007 迭代式展开（r4 部分解决注记；r18 resolved）

- **r18 收口注记（批次 H / Task 40-c）**：完整 10_000 口径交付——
  ① `StxDatum::List/Vector` → `Rc<Vec<Stx>>`（clone O(1) 浅共享）；
  ② `retag_scopes` 迭代式重建（显式工作表后序 Visit/Assemble——
  Rust 栈深恒定，旧递归版 10_000 层链溢出）；③ **均匀标记**（`Stx
  .uniform_tag: Option<ScopeSet>`——retag 输出子树均匀作用域标记 +
  `add_scope_to_all` 注入时清除保健全性；链 N 步总工作量 O(N)，旧
  每步全树重建 O(N²)）；④ 扁平 Drop（`impl Drop for Stx`——唯一
  持有脊柱工作表拆除，共享子树计数递减天然无递归）；⑤ 上限
  500→10_000（种子 expander.rs + 自举 expander.krf `MAX-EXP-DEPTH`
  同步——parity 消息一致）；⑥ 均匀标记不参与 PartialEq（手写实现
  忽略性能字段）。正例 10_000 链 0.02s（2MiB 测试线程——恒定栈深）
  + 边界 10_001 报错含头含尾。
- 耦合解除实证：自举 expander 路径 10_000 深度链此前先撞 VM 帧上限
  （expander.krf trampoline 尾调用链耗帧）——TCO（TD-022 同轮）后
  端到端到达深度上限结构化报错（tco_tests 锚定）。

- **描述**：展开深度上限 128（rustc 默认对齐）；文档示例 10_000 需迭代式
- **修复方案**：展开工作表化（显式队列替代递归下降）
- **测试锚点**：negative_expander_tests 宏深度超限负例（超限报错而非栈溢出）
- **r4 执行注记**（Stage 1 批次 A3，2026-09-10）：trampoline 工作表已落地
  （expand_form 顶层循环——宏产物头部仍是宏调用时迭代继续，展开控制流
  栈深与链长解耦）；上限 128→500（实测标定：2MiB 测试线程 1_000 通过/
  2_000 溢出，500 = 2× 裕度——TD-017 同型实测法）。**残留**：完整 10_000
  口径受 Stx 值语义深树的 clone/drop 递归约束（数据结构层）——批次 B
  前端重写时 Rc 化解除；探针实测记录：8MiB 主线程 4_000 通过/5_000 溢出

### TD-008 分代 GC / 堆压缩（r3 补详情）
- **描述**：slot-Vec + 空闲表（free 表）方案**不移动对象、不压缩**——长运行程序的堆碎片
  治理缺位（05 §4 v5.2 对齐：清除阶段全量重建空闲表，句柄稳定但空间不回收整理）
- **根因**：Stage 0 程序短生命周期 + mark-sweep 最小复杂度裁定（避免分代/增量/并发的复杂度）
- **修复方案**：Stage 2 分代 GC / 堆压缩（05 §4 陷阱 3 的既定推迟路径）
- **代码锚**：kerf-runtime/src/lib.rs:19（推迟注记）
- **workaround**：Stage 0 测试与示例程序分配量有界（gc_tests 10^6 / gc_stress 3×10^5 均堆有界）
- **r24 裁定（42-e / 批次 I2，DEFER→Stage 3+ 条件触发）**：
  ① **收益面不存在**：Stage 2 无长驻程序（负载 = CLI 单趟 + 测试 + 自举管线
  ——分配有界、生命周期短；登记时的 workaround 依然成立）；r24 会话实测：尾形
  gc_stress 38.57ms（-2.8% 噪声带）、非尾形 105.15ms（TD-023 对症后 -27%）、
  分配主导负载 23.76ms——mark-sweep + 空闲表满足全部验收门；
  ② **分代对症有限 + 压缩破坏不变式**：分代对栈根（帧局部）扫描无通用免除
  （年轻代回收仍全量枚举栈根——非尾形深递归实测主导成本是帧根扫描 + 帧内存
  churn，分代只减堆标记量，本负载堆恒 ~阈值规模）；堆压缩破坏 GcRef = 槽位
  索引的结构性契约（「只分配不压缩」§19.4 陷阱 3 + 全库消费面）→ 需转发表
  间接层 = 值模型全量改写（P1 级工程）；
  ③ **复杂度预算**（§12）：批次 I 剩余 MUV（42-f Effect M1-M5 + 能力 M2 /
  42-g 门审查）优先于本阶段无收益的堆治理改造。
  **重评估触发条件**：Stage 3 长驻/服务型负载出现；或堆规模实测 >10^6 槽 /
  碎片率可观测劣化；或栈根采样成为 >30% 热点。

### TD-009 eval 路径 GC 根集（r3 注记更新）
- **描述**：元循环求值器关闭 GC 触发（根集枚举需遍历 Rc 环境链）
- **修复方案**：Stage 1 根集遍历或（按 §21.9 演进矩阵）eval 被编译器替换
- **代码锚**：driver.rs（eval 路径 `heap.set_gc_enabled(false)`）+ eval.rs:8
- **r3 关联注记**：eval 路径的**卫生回退解析已接线**（driver::resolve_eval_hygiene_fallbacks，
  Task 16 修复双路径全局引用分裂，TD-004 的 eval 侧镜像）——但该路径 **GC 仍禁用**：
  卫生回退是符号解析层修复，与根集枚举（Rc 环境链/闭包可达图遍历）**无耦合**，属两个
  独立边界；GC 触发仍仅由 VM 路径承担（安全点轮询 + 五来源根集），L-GC 不可观测性不受影响

### TD-010 闭包装箱
- **描述**：序对元素为闭包/内置时以标记字符串占位（不可达路径）
- **修复方案**：Stage 1 HeapObj::Foreign(Rc<dyn Any>)
- **代码锚**：heap.rs（BoxedInput 显式限制）/ vm.rs:626（占位注记）；05 §3.1 v5.2（HeapObj 六变体对齐——早期文档误写 Boxed 变体的更正出处）
- **r24 收口注记（42-e / 批次 I2）**：`HeapObj::Foreign(Rc<ForeignBox>)`
  落地——ForeignBox{any: Rc<dyn Any>, tracer: fn}（追踪协议由装箱方注入，
  kerf-runtime 不依赖 kerf-vm 类型——§11 接口隔离）；box_value 闭包/内置
  → Foreign 装箱（Rc 共享 → 解箱往返恒等，eq? 按引用）；**标记阶段
  children 经 tracer 枚举闭包捕获图的 Pair 子引用**（漏追踪 = 仅经 Foreign
  可达的捕获 Pair 误回收——use-after-free 级缺陷面）；渲染 #<procedure>/
  #<builtin:名>（与直接函数值同形）。测试：往返恒等/函数列表模式
  （(list f g) + map 应用）/ GC 存活 2（追踪器实际行使 + 捕获链多级传递）
  / 渲染含点对形态。原「占位字符串」路径删除（vm.rs box_value）。

### TD-011 字符串全序比较（r3 补详情）
- **描述**：比较操作符（`<` `<=` `>` `>=`）仅支持数值塔——字符串操作数报
  「字符串仅支持 = 比较」（`= `可判等字符串；`eq?` 即时值按值/堆值按引用）
- **根因**：字符串全序语义（Unicode 码点序 vs 本地化序）裁定推迟——Stage 0 避免隐式语义承诺
- **修复方案**：Stage 2 实现字符串序比较（数值塔之外的比较路径分流）
- **代码锚**：kerf-driver/src/builtins.rs:330（报错消息注记）
- **测试锚点**：negative_vm_tests::comparison_string_ordering_rejected（4 case 断言报错形态）
- **r24 收口注记（42-e / 批次 I2）**：码点序裁定落地——**全字符串链参与
  全部比较族**（`Rc<str>` 比较 = UTF-8 字节序，编码保序性 ⇒ 与 Unicode
  码点序全序一致；09-stdlib v6.3 语义裁定）；混合链（串入数值）保持
  `{op} 需要数值`（TD-016 首个非数值归因口径）；静态面 R3：Ordering 与
  NumOrAllStr 同语义放行全字符串链（运行时/静态口径一致）。负例改写：
  comparison_string_ordering_rejected → comparison_string_chain_mixed_rejected
  （语义边界迁移——正例锚 stdlib_tests 12 case + HM 超集门语料换混串链）。

### TD-012 expander.rs 单文件拆分候选（r3 新增；r16 标记已解决）

- **r16 收口注记（批次 F 深审 D2 全审发现）**：拆分已随**批次 B 前端重写**
  实际落地——kerf-expander 现六文件（expander.rs 632 / core_forms.rs 604 /
  macro_sys.rs 715 / sugar.rs / phase.rs / lib.rs），原「单文件 1350 行」不复
  存在；登记册状态列此前未同步（深审发现项）。
- **描述**：kerf-expander 2276 LOC 占 crates 22.2%，其中 expander.rs 单文件 1350 行
  （deep-review R1 D1 风险项②）——职责仍单一（9 核心形式 + 糖推导 + 相位驱动）但认知负担
  已达拆分阈值
- **等级**：P3（非性能、非语义——纯可维护性）
- **目标时机**：Stage 1 切换期（前端重写时顺带拆分：核心形式/糖推导/相位驱动三模块）；
  拆分前禁止向该文件继续新增职责（防 1500+ 失控）
- **关联**：worklog Task 14-a（D1 架构审查）；TD-007（迭代式展开重写时自然触碰）

### TD-013 多错误收集 / Expander 恢复展开（r3 新增；r7 设计完成；r16 改判；**r17 resolved / 38-e**）

- **r17 交付注记（批次 G / Task 38-e）**：双路径实现全落地——种子
  `kerf-expander/src/recover.rs`（DiagCollector：push / is_full(128) /
  mark_truncated / into_sorted 位置序 + expand_program_recover 形式级
  恢复）+ 自举桥 `bootstrap_expander::expand_program_recover`（逐形式
  单元素列表调用——expander.krf 协议零改动）+ driver
  `check_source_recover`（front_from_core 抽段共享——E0002/E0005
  全量合并 + 截断尾注）+ CLI `kerf check` 切换恢复模式（单错误短路
  保留库 API check_source；run/eval 执行路径不变——r7 设计 §5）。
  **r7 验收 5 条全过**：恢复跳过（产物含后续 define，指令数 = 无错
  对照一致）/ 上限 128 + 截断提示 / 位置序 / 既有零破坏 / 16 case。
  实测勘误 2 项如实记录：截断标记 break 路径须显式置位（mark_truncated）；
  并行测试 env 竞态（find_qbe 纯函数注入式重构）。

- **r16 改判注记（批次 F 深审 D2 发现）**：原「实现绑定批次 E」未纳入
  E1-α（自举 Expander 核心形式）/E1-β（宏收口 + 生产切换）范围——批次 E
  已收口（r15 门审 APPROVED）而展开段仍单错误短路。**Stage 1 门放行裁定**：
  诊断吞吐量面（P2）非语义正确性阻塞，按「P2 开放不阻塞 Stage 2 启动」放行
  （34-d 投票记录口径）。改判 **Stage 2 批次 G2**（HM 推断设计轮同批——
  错误恢复与推断升级同为前端诊断主线）；设计文档 multi-error-recovery-
  design.md 继续有效，`kerf check` 首个消费面（r7）已在。
- **描述**：stage0.md §8.7 / 02 §5 承诺「单次运行报告多个错误 + Expander 错误恢复后继续
  展开后续形式（IDE 增量反馈）」——实现为**单错误短路**（首个错误终止管线，后续形式不再
  展开/求值）。deep-review R1 存档确认，negative_semantics_tests::error_recovery_* 锚定
  当前事实行为（4 case）
- **等级**：P2（设计承诺与实现存在可观测差距——诊断吞吐量面）
- **r7 设计批交付注记**（批次 C Task 25-d，2026-09-10）：设计已冻结于
  [multi-error-recovery-design.md](./v0/stage-1/multi-error-recovery-design.md)——
  恢复粒度=形式级（表达式级不恢复：半展开状态重建成本不成比例）；恢复机制=
  编译期控制流（**非** effect——§11 接口隔离，效应联动裁定已归档）；收集上限
  128 + 截断提示；输出次序按 Span（与 check_program 一致）。**首个消费面已实证**：
  `kerf check`（r7）静态检查多错误全量收集（typecheck_tests::multi_error_collection_span_order
  锚定三错误全量 + Span 次序）。实现绑定批次 E（Expander kerf 重写同批——避免双恢复机制）
- **目标时机**：Stage 1 批次 E（验收标准 5 项见设计文档 §6）
- **代码锚**：driver.rs（管线短路返回）；negative_semantics_tests.rs:433（存档注记）；
  kerf-compiler/src/typecheck.rs（多错误收集的实证消费面）

### TD-014 展开期错误消息归因失真（r3 新增）
- **描述**：嵌套 define 重复（`(define (f) (define x 1) (define x 2))` 类形态）在**展开期**
  被体内部提升机制拒绝，但消息为「lambda 参数重名」——**归因失真**（语义上等价 E6 的
  提前防御，消息误导排查方向）。同批存档：eval 路径错误诊断保真度弱于 VM（错误包装
  前缀「求值失败：」+ Span 指向差异——双路径消息分裂面，见 negative_semantics_tests 头注）
- **等级**：P3（消息质量——不影响 Err 事实与双路径一致性）
- **目标时机**：Stage 1（消息质量专项：展开期错误归因到「嵌套 define 重复」；eval 错误
  包装对齐 VM 诊断形状）
- **代码锚**：expander.rs（parse_params 重名检查——两路径共同上游）；06 §5.3 v5.2（错误路径
  互查口径补注）
- **r24 收口注记（42-e / 批次 I2）**：专门消息「嵌套 define 重复绑定（同名内部
  变量只允许出现一次）」+ Span = 第二次出现处的 define 形式自身（原路径经
  提升构造的 lambda 形参重名兜底——消息误导 + Span 指向体首合成节点）。
  双侧镜像：seed `expand_body` seen 向量 + 自举 `expand-body` 的
  `dup-define-scan`（判定序一致：头部切分 → late-define → 重名 → 提升）；
  bootstrap_expander_tests parity_err +2 case（消息 + Span 逐字一致）。

### TD-015：IrGraph 无条件计算旁路丢弃（P3）

- **等级**：P3（不影响正确性，恒定开销）
- **状态**：开放
- **目标阶段**：Stage 1 切换期（与 TD-012 expander 拆分同批）
- **描述**：`compile_source` 在 run/eval 生产路径无条件计算 `IrGraph` 后
  旁路丢弃（仅 `kerf ir` 子命令与 CodeValue 检查消费）。发现于 §14.6.2
  重构最优性审查（O-1）。
- **偿还计划**：按消费方拆分编译入口（`compile_source_lowered` /
  `compile_source_fast`），或延迟到 IrGraph 消费点。

> **r56 目标时机再裁定（78-b——T3+ 触发态审计）**：~~Stage 3 优化窗口~~（dangling）→ **T3+ 触发式三判据**（[t3plus-trigger-audit §3.3](../stage-3/t3plus-trigger-audit.md)：①IrGraph 生产消费点出现[与 TD-003 判据 ① 同源——同窗联动] ②IrGraph 构造占全链 >10%[当前微量——分布锚不显峰] ③`kerf ir` 子命令高频使用信号）。零信号维持待触发。

### TD-016：链式比较短路语义待静态收紧（P3）

- **等级**：P3（语义已显式裁定，行为稳定）
- **状态**：**已解决（r7，批次 C Task 25-c）**
- **目标阶段**：Stage 1（类型检查器联动）
- **描述**：比较链在首对判定终止时后续操作数不做类型检查
  （FS-5，09-stdlib §2 显式裁定段）。Stage 1 类型检查引入后统一为
  全操作数静态检查。
- **r7 偿还注记**：双侧落地——① 运行时面：`cmp_builtin` 前置全参数
  数值校验（全字符串+排序族 → TD-011 消息；其余首个非数值 →
  `{op} 需要数值`；既有两参消息逐条兼容，负例矩阵回归锚全绿）；
  ② 静态面：类型检查器 R3 规则（typecheck.rs Ordering/NumOrAllStr）
  同口径。语义文档 09-stdlib §2 v5.5 重写（FS-5 边界收敛）；负例
  +9 case（stdlib_tests comparison_chain_* 两函数）+ 静态面
  typecheck_tests R3 四函数。
- **偿还计划**：已交付（双侧 + 文档 + 测试）

### TD-017：eval 参考路径深度上限不对称（P3）

- **等级**：P3（已结构化+文档化，语义边界非缺陷）
- **状态**：开放
- **目标阶段**：Stage 1（判定是否大栈线程化）
- **描述**：eval 参考路径 `MAX_EVAL_DEPTH=256`（2 MiB 线程栈实测标定）
  vs VM 生产路径 `MAX_FRAMES=100_000`（D3 修复引入——修复前 eval 深递归
  为 Rust 栈溢出 abort）。T1 定理在深度 ≤ 256 的常规程序域成立。
- **偿还计划**：eval_source 在大栈专用线程（32 MiB）执行 + 上限对齐
  MAX_FRAMES；或维持参考路径边界声明。

### TD-018：双路径错误消息文本分裂（P3）

- **等级**：P3（Err 事实与阶段一致，仅文本不同）
- **状态**：开放
- **目标阶段**：Stage 1（消息质量批——与 TD-014 同批）
- **描述**：未绑定变量/if 非布尔等错误 VM 与 eval 文本不同（D8——
  T17-a 深挖发现）。E 码/阶段/Span 三要素一致，文本常量分散于
  vm.rs/eval.rs。
- **偿还计划**：共享消息常量模块（kerf-span 或 kerf-vm 公共层）。
- **r24 收口注记（42-e / 批次 I2）**：`kerf-vm/src/messages.rs` 单源构造器
  （偿还计划既定位置——kerf-vm 公共层）：if 条件/not/car·cdr/set? 五族
  消息构造器三消费面（VM 操作码 + eval 参考臂 + driver 内置）同源引用；
  **`Value::truthy` 复活为单一实现**（原无调用方死助手 → Result 化 + 双
  if 消费——VM JumpIfFalse 与 eval if 臂同文，scope_set_tests 对拍回归
  锚 td018_if_cond_message_unified_dual_path 断言消息文本相等）。归因
  口径：前缀统一「if 条件需要 bool」（与静态面 R1 一致——糖均脱为 if）。
  **未绑定族裁定保留差异**：VM「未绑定的全局变量（…）」携带全局兜底
  解析完成度（阶段信息），eval「未绑定变量」为参考面口径——非分裂。

### TD-021：高阶函数用户面注入缺载体（P3）

- **等级**：P3（hofs 已以 kerf 源码交付并直测——仅用户程序不可见）
- **状态**：**已解决（r15——模块/import 承载：kerf-prelude 模块
  （bootstrap/preamble.krf）经 forms 级合并注入单一编译单元；用户程序
  `(module 名 (import kerf-prelude) ...)` 声明后 map/filter/foldl/
  for-each 以普通全局函数可调用；同名 define 显式报「重复定义」；
  无 import 声明保持未绑定（opt-in）；测试 prelude_tests 7 case）**
- **目标阶段**：Stage 1 批次 E（已随 E1-β 交付）
- **描述**：map/filter/foldl/for-each 已实现于 reader.krf 序章（r6/B3，
  经 bootstrap 桥直测——「用 kerf 源码 preamble 实现」的自举验证命题
  本体已交付），但用户程序引用报未绑定变量。三方案已否决（r5 裁定）：
  P1 源码拼接（Span 诊断污染 = P1 缺陷）、P3 跨程序全局合并
  （SymbolTable id 不可比 + 原型索引程序局部——call_closure 运行时
  显式拒绝）、P5 builtin 调闭包（VM 递归 re-entry 越界 §11）。
- **偿还计划**：模块/import 机制承载 preamble（批次 E Expander 重写
  时设计）——正确 > 妥协：不做看起来像但不是的半吊子注入。
- **实现**（r15）：P1/P3/P5 全规避——preamble.krf 以独立 file_id 读入
  （Span 指向自身文件，无源码拼接污染）；forms 前置合并进同一编译
  单元（无跨程序合并）；零 VM 再入。注册表多模块按序 declare + 主
  模块 visit（import 边传递依赖——§8.9 单模块生命周期扩展）。

### TD-022：自举 Reader 帧消耗 O(源字符数)（P3）

- **等级**：P3（语言无 TCO 的既定边界；测试语料全部远低于上限）
- **状态**：开放
- **目标阶段**：Stage 2（TCO 决策点——12-roadmap §2.5）
- **描述**：reader.krf 的词法/语法主循环按 Token/字符递归（尾调用链
  形态），无 TCO 下每步消耗一 VM 帧（MAX_FRAMES=10^5）：约 10^5 字符
  以上源文件将以「调用帧超过上限」终止（非读语义错误）。种子 Reader
  无此限制（Rust 循环）。Stage 1 验收语料（≤ 数 KB）不受影响。
- **偿还计划**：Stage 2 TCO 裁定时一并评估（帧复用或迭代式驱动）；
  若 TCO 继续推迟，评估分块驱动协议（宿主侧步进）。

### TD-019 / TD-020 编号断档记录（r16 登记）

**编号断档：TD-018 与 TD-021 之间的两个编号从未被登记任何内容**（r16 批次
F 深审 D2 全审时全库 grep「TD-019」「TD-020」零命中——含 worklog/matrix/
lang-design 全部对账面）。推断与 TD-001/006 同型：跳号笔误而非已解决项消失
（TD-015~018 登记于深审修复内循环，TD-021 首现于 r12——两编号在其间跳过）。
**处置**：沿用 TD-001/006 先例——永久保留为断档占位（禁复用），后续新增债
从 TD-024 起编。

### TD-024 本地码后端 PoC 边界（P3，r17 新增——38-b/38-c B1 类登记）

- **描述**：QBE 后端 PoC（G1）支持面 = 整数域原语十二项（+ - * / mod =
  < > <= >= not eq?）+ 顶层 define 函数直接调用（静态 arity 校验）+ If
  （值/尾上下文——phi 合并）+ Begin；**边界外**（显式错误非静默降级）：
  lambda 值位置（闭包捕获）/ Float/Str/Symbol/Pair/Bool/Nil 字面量 /
  set! / module / print·IO 内置 / 未定义调用 / 自由变量 / 函数值一等传递
- **等级**：P3（PoC 范围裁定的显式声明——§21.3 条件 3 以 fib 端到端
  满足；边界扩张属既定路线非缺陷）
- **承接路线**：FFI 面（print/write_stdout）按 stage-2/ffi-ownership-
  model.md 批次 I 做实（38-a 交付）；闭包/GC-后端协同（根扫描本地码
  化 + pin 根集）批次 H/I；Float 域 QBE d 类型扩展随后
- **代码锚**：kerf-backend/src/anf.rs（lower 边界错误族）；tests/v0/
  stage2/plan/qbe_backend_tests.rs（负例 10 项锚定）

> **r56 状态修正 + 目标时机再裁定（78-b——T3+ 触发态审计）**：~~Stage 2 批次 H-I~~ 承接内容**已全部清偿**（FFI 面 print/write_stdout 批次 I r30 做实 + 闭包/GC-后端协同[GcCell 堆根性摘要 + ForeignBox 装箱追踪] r24-r25 做实）——残余 = PoC 边界扩张（Float 域 / 闭包值位 / native 效应化——B1 类显式拒绝在案非静默降级）。→ **T3+ 触发式三判据**（[t3plus-trigger-audit §3.4](../stage-3/t3plus-trigger-audit.md)：①native vs VM 剖面 >2x 差距且消费方需求[当前 PoC 满足 §21.3 条件 3 零扩张压力] ②效应语料要求本地码执行[B1 既定裁定域] ③Float 域 QBE d 类型消费）。零信号维持待触发。

### TD-023 gc_stress 深递归 GC 根扫描回归（P2，r16 新增——批次 F 深审 D6 实测发现）

- **等级**：P2（性能回归超 §14.6.4 的 10% 阈值；不影响语义正确性——存活
  数据跨 GC 验证全过、L-GC 不可观测性不受影响）
- **状态**：开放
- **目标阶段**：**Stage 2 批次 I2**（与 TD-008 分代 GC / 堆压缩评估同轮——
  分代/压缩是对症路径）
- **描述**：gc_stress（3×10^5 分配 + 30k 深递归）单轮 207~235ms，较 Stage 0
  基线 160.4ms 回归 **+29%~46%**（超回归阈值）；且**超线性缩放**——spin
  15000 → 59.5ms、spin 30000 → ~215ms（2× 分配 → 3.6× 耗时）。冷却退避
  四参数（256/64/25%/1024）未变——Stage 1 新增变量为候选根因：① 根集遍历
  per-cycle `HashSet<usize>` 去重分配（vm.rs `collect_value_roots`——每
  GC 周期重建）；② `Value` 枚举宽度两轮增长（r5 Symbol + 闭包共享捕获）的
  栈/帧内存布局与缓存效应。
- **证据**：深审 D6 实测三组（207/214/235ms）+ 减半缩放实验；完整口径见
  [stage-1/performance-baseline.md](./stage-1/performance-baseline.md)（36-d 落位）
- **偿还计划**：批次 I2 评估三路径——分代 GC（年轻代扫描集缩小 = 对症）/
  根遍历 visited 结构无分配化（arena/bitset 复用）/ Value 瘦身（大变体
  Box 化）。在此之前每次合入按 §14.6.4 协议复测 gc_stress 5 轮（超 10%
  阈值保持追踪）。
- **r24 收口注记（42-e / 批次 I2）**：**基准重定型先行**——新增
  `examples/usage/gc_stress_nontail.krf`（非尾形深递归：`(+
  (grow (- n 1)) 1)` 参数位 → 峰值 3×10^4 存活帧 + 10 cons/层）；
  改前实测 144.06ms/轮（尾形 39.68ms 的 3.6×）+ 缩放 15k/30k/60k =
  45.07/144.06/528.33ms（**2×→3.2~3.7× 超线性实测成立**——原登记的
  残留模式锚定）。**对症双件落地**（偿还计划路径 B 直译 + 对症变体）：
  ① `GcCell` 堆根性摘要（`Rc<RefCell<Value>>` → `Rc<GcCell>`——
  has_heap 标志由写路径维护（set! 写 Pair/Closure 翻转，sound 不变式），
  根集枚举对非堆单元 O(1) 跳过——深帧根扫描实测主导成本的对症面；
  write-路径 soundness 回归锚 gc_cell_flag_flips_on_pair_write）；
  ② 根扫描缓冲跨周期复用（root Vec + visited HashSet 由 execute 持有
  ——take/归还零 API 变更，无分配化路径 B）。**改后对拍（stash 重建
  r23 二进制同会话）**：非尾形 144.06→105.15ms（**-27.1%**）；尾形
  gc_stress 39.68→38.57ms（-2.8%）+ fib(25) 86.97→84.22ms（-3.1%）
  ——均在 ±5% 噪声带（验收 ≤5% ✓）。**残留如实归因**：超线性（2×→
  3.4×）由帧栈内存 churn（每帧 2 Vec 分配）+ 每周期固定成本构成——
  精确 mark-sweep 栈根扫描的结构性成本（非登记的分配模式缺陷——已治愈）；
  分代/压缩对该残留对症有限（TD-008 裁定 DEFER 的②依据）。

### TD-026 FFI 语言面形式 + 编组消费子集收窄（P3，r30 新增——48-d 做实边界登记）

- **登记背景（r30 / 48-d）**：FFI VM 面（§21.3 条件 4）已做实——操作码
  三指令（43→46）+ `FfiBoundary` 真实实现（Heap Φ 计数簿——P/U 归约
  规则）+ extern 符号表（E0012 fail-closed）+ 线性令牌状态机（E0010/
  E0011）+ 13 边界 case（ffi_vm_tests 37 case + driver ffi 单元 8）；
  **残留两域显式登记**：
  1. **语言面形式**（extern 声明语法/FFI 调用表达形式——「批次 G1/I
     定」既定 Stage 3，plan §5b 批次 J 排程注 3）：编译臂不发射三操作
     码——Stage 2 消费面 = 操作码直接构造（测试/审计）+
     `compile_ffi_call_program`（冻结 FfiCall 的字面量实参 lowering）；
  2. **编组消费子集**（ffi-ownership-model §2.1 三分法的 Stage 2 实现
     子集）：CInt/CPointer(char* 窗口借用 + 令牌传递)/Opaque 已消费；
     **CStruct 逐字段递归编组未消费**（注册面拒绝）+ **CFunction 回调
     通路不存在**（§6 case 3——形状非回调注册面）+ `FfiCall::
     FreeExternal` 非令牌实参 lowering 拒绝（实参需运行时令牌值）。
- **等级 P3 依据**：零实现债务（接口预留成本 = 类型维护——13 §2.5.1
  解读要点原文口径）；收窄面均显式拒绝非静默（报错 > 静默，§2.3-4）。
- **目标阶段**：Stage 3（语言面形式批次——ffi-ownership-model §8
  「语言面形式批次 G1/I 定」同口径锚）。

> **r56 目标时机再裁定（78-b——T3+ 触发态审计）**：~~Stage 3（语言面形式批次）~~（dangling——收口未消费）→ **T3+ 触发式三判据**（[t3plus-trigger-audit §3.5](../stage-3/t3plus-trigger-audit.md)：①.krf 语料 extern 声明/FFI 调用形式需求[当前语料 extern = 0——本轮 grep 实证] ②CStruct/CFunction interop 语料需求 ③互操作生态必要性信号[与 net 四依据 ④ 同源]）。零信号维持待触发。
>
> **r137 / 207-c 行① 部分清偿（M1 指令开窗第四十二例）**：判据③生态必要性的用户指令臂命中（r74/r99 先例锚「指令即需求信号本体」——推荐序裁定：r136 后登记册触发式实施项全清零 + 六族语料信号实测全零 → T3+ 14 行手动臂中与「目标语言设计实现窗」需求语义唯一匹配项）。交付 = extern 声明族语言面全链：`extern name(kinds) -> kind;` ↔ `(extern name (kinds) kind)` 双侧 Reader（第十三皮肤映射——seed parse_extern_decl + mirror parse-extern-decl 族）+ Keyword::Extern（第 28 名——E0020 共享域扩展）+ 驱动面 collect_extern_face 五重校验（形状/可注册性 E0012 编译期/契约 E0026/查重/能力 E0006——write-stdout 与 io 语言通道同享授权令牌）+ 剥离（expander 零变更——kerf-core/kerf-expander 两 crate 零代码）+ 分辨层 IrVar::Extern（扁平符号空间：词法帧后 global 兑底前，Symbol 名字匹配卫生不可穿透）+ 编译臂发射（双侧：compile.rs Apply 头识别 + compiler.ktf EXTERN_TAG/compile_ffi_args——PushConst SymLit + 实参 + Op::CallExternal #43 冻结操作码四方同步）+ 值位 fail-closed（E0026）+ 运行入口表构造（声明 ∩ 在册可注册 ∩ 能力授予 → run_program_with_externs——空表 = 历史行为逐位不变）+ 在册可注册表 AVAILABLE_EXTERNS（write-stdout 唯一条目）+ ktf_extern_decl_tests 32 case（8 正 + 24 负 1:3）+ 语料对 ffi.{ktf,krf}（⇒ 9 双面——真实宿主 I/O 往返）；净 +32 测试 1655 → 1687。**余②③④维持注册面显式拒绝**（CStruct/CFunction interop 语料信号 + token 消费语料信号——设计单源 ffi-language-surface-design.md §7 域外表）。

### TD-027 库表面命名现代化（P2，r32 新增——53-a 审查轮登记）

- **登记背景（r32 / 53-a）**：用户审查指令驱动——「实现端不要停留在 Lisp
  家族 1970 年代表达」；全项目扫描实测：57 注册内置名中 18 件 `?` 谓词 +
  3 件 `->` 转换 + `car`/`cdr`/`last-pair` 历史访问器 + 扁平 `str-` 前缀
  ×15 + 行为模式遗留（`str-index-of` -1 哨兵 / `member`/`assoc` 真值多态 /
  `read-line` 元数缺口）；引导语料自铸 41 个 `?` 名 + 9 个 `->` 名；
  21 测试文件 240 处 + examples 180 处存量引用。**此前无 owner/无映射表/
  无 TD 登记**（r32 审查确认——「未认领半区」）。
- **设计 owner 已落位（本登记的实施侧对应物）**：
  `docs/lang-design/20-surface-conventions.md` v1.0（R1-R6 六规则 + B1-B5
  行为契约 + 命名空间层 + 57 项映射表 + 零破坏三批次迁移）；原则 33
  （17-principles v6.3 / sop §2.2 v12.1 / stage0.md §23.1 v6.2 三方同步）；
  12-roadmap §2.10 批次登记（v0.5 批次 L / v0.6 批次 M / Stage 3 移除轮）。
- **等级 P2 依据**：设计规范已冻结（无设计债）；实施为三批次渐进（无
  「现在不做会恶化」的阻塞面——但表面债随库生长线性累积，故非 P3：
  Stage 2 库化生长放量前应兑现别名层）。
- **目标阶段**：批次 L（v0.5 别名层——27 现代名双注册 + BUILTIN_SIGS/
  门控三方同步 + parity 组）；批次 M（v0.6 命名空间层）；移除轮
  （Stage 3——与 E5 关键字切换同窗）。
- **r42 清偿注记（移除轮 S1 表面腿交付 ✅——TD-027 三腿全清偿，登记关闭）**：
  ① 旧名 27 件退役（`BUILTIN_ALIASES` 表转身为 `REMOVED_BUILTIN_NAMES`
  [旧名→现代名指引映射——E0021 诊断单源]；注册面 84→57 扁平 + 47 限定
  = 104；零授权面 92）；② E0021 已移除旧名错误（编译期拒绝携现代名
  指引——20 §7「旧名引用 = E00xx 错误」兑现；与 E0014 同 traversal，
  遮蔽/接管豁免同口径）；③ W1001 弃用族下线（生命周期四阶段完整走完：
  引入 v0.5 → 默认 v0.6 → 弃用 v0.7 → 移除 v0.9——23 §3.4）+ W1003
  宏名遮蔽警告落地（22 §11 D11 排期承诺清偿）；④ 全语料现代名终态
  （引导 .krf ×4 + 21 测试文件 + examples——grep 零旧名实证；迁移
  实录：compiler.krf `tail` 参数名撞现代内置名 → `tail-pos` 重命名
  [词法遮蔽合法但迁移期碰撞——如实登记]）；⑤ 负例组 27 名全覆盖 +
  闭合守卫双向对账（stdlib_tests removed_* 组 17 case + namespace_tests
  s1 组 4 case）；828:0:0（837 - 9：28 parity case 收敛为 17 移除
  case + 2 W1001 case 演进为 4 W1003/E0021 case——移除轮的测试面
  合法收缩）。**B1/B2 契约（r40 M2）与限定名面（r39 M1）不受影响**
  ——底层共享分派体形态在移除后依然单源。
- **剩余关联面（非本 TD 范围——显式登记防误读）**：关键字切换
  （`lambda→fn` 等 N4 面）= E5 S2 腿（01 §7.2/§8.3 owner）；ADT 结构
  重构 = E5 S3 腿（21 §5.3 owner）；`?`/`->` 词法域收紧 = 裁定维持
  不收紧（e5-plan §4.2 否决记录——重评条件 = 包生态名冲突实证）。
- **r38 进展注记（批次 L 交付 ✅）**：① 注册面 57→84（`BUILTIN_ALIASES`
  27 现代扁平名双注册——同名共享 `Rc<BuiltinFn>` 分派体：同行为同诊断
  天然 parity）；② `BUILTIN_SIGS` 双名同步（56→83——守卫锚逐项相等）；
  ③ 门控表零变更实测（READ_GATED/WRITE_GATED 六名 ⊆ 注册 + 别名零
  交集——守卫锚）；④ parity 组 27 case + 闭合守卫 1（stdlib_tests——
  正例双名同值 + 负例阶段/诊断码/消息体三面比对）+ 三方漂移守卫 ×2
  （builtins.rs 单元）。**剩余**：批次 M（v0.6——22 §8 实施对账表）+
  移除轮（Stage 3 同窗 E5）——TD 维持开放直至移除轮终态（27 旧名
  删除时本条 resolved）。
- **顺带修复（r32 本轮已做）**：builtins.rs 文件头注记「3 个 Reader 原语」
  → 4（实测漂移——`str-int-valid?` 第 4 件）；hm-inference-design.md A8
  「BUILTIN_SIGS 49 项」→ 56（实测漂移）。

### TD-029 N1 扁平面收缩——可见性收紧腿（P2，r46 新增——67-a/67-b 深审 D46 登记；**r47 / 68-b 清偿**）

- **登记背景（r46 / 67-a）**：22 §15 缺 A 实测——47 模块扁平名 + 47 限定名无条件注册（import 可见性载荷 = 0：`(append …)` 免 import 可用）；22 §2.1 N1 行「v0.6 后收缩为：运算符族 + 门控 + 旧名兼容」未兑现。D7 过渡期锚（r40「Stage 3 移除轮后」）退出动作从未排期——本轮重锚为 **E5 窗口内专腿 r47**（与 Module M-L 同波次合并单一 breaking wave——波次经济学[两次波 = 双倍语料迁移成本]）。
- **收缩机制（D46 六件合同）**：①E0022 基线版（r46 已落——全局面口径）升级为**可见面核对**（global_refs ∩ 可见面 + 消息携带逐层明细）②语料 import 迁移（测试/示例补 import 声明——prelude 再导出 20 名为高频集[D50 载荷步]）③W1003 数据源 face-aware（注册面 ∩ 可见面——零误报纪律）④E0004 内置接管检查 face-aware（接管合法性 = 名 ∈ 当前编译单元可见面——不可见面名自由定义）⑤prelude 注入面派生载荷化 + 再导出感知 E0013 ⑥五面文档同步。
- **启用件（r46 已交付——本 TD 的前置）**：顶层 import 合法化（D47——主程序 N2 注入面入口）+ E0022（D49——未绑定编译期先行）+ 保留域双形（D48）+ prelude 元数据（D50 ①步）。
- **出口条件（D54 验收合同）**：四件 krf + 全测试语料 import 完备（grep 审计零免 import 扁平名——负例测试数据除外）+ face-aware 双改零误报 + 可见性对账测试组 ≥8 case + 非正交点计数复核（S4 同窗）。
- **依据**：Swift SE-0444 MemberImportVisibility + InternalImportsByDefault（2026-01 工业同向）；Monte 入口点授权导入（q1）；22 §15 D46 判据集。
- **清偿记录（r47 / 68-b）**：六件合同逐件实施——①E0022 面核对（基准 = `N1_CORE_NAMES` 38 名 ∪ `flat_underlying` ∪ define 面；消息逐层明细 + `suggest_import_for` 建议单源）②语料 import 迁移（compiler/expander 头部 `(import kerf-list kerf-string)` + preamble 头部补 kerf-list + 测试/示例全量——面核对 fail-closed 下 854:0:0 实证[强于 grep 审计的执行级验证]）③W1003/W1002 face-aware 双改（visible_flat 数据源 + 限定名宏查导入集——零误报）④E0004 接管 face-aware（define 面 ∪ defined 集——接管合法 + 未导入未接管名编译期拒）⑤prelude 载荷化（`PRELUDE_EXPORT_NAMES` 20 名单源 + 扁平边际 7 名 + E0013 underlying 同一性重基[D55-b]）⑥八件文档同步（22 v2.0 §15.4 / 18 v6.9 / TD 本件 / e5-plan v1.5 / 20 §5.4 注记 / matrix r47 / RELEASE v0.14.0-r47 / roadmap v0.10.0-r47）。D54 出口四项：语料完备 ✅（854:0:0）/ face-aware 零误报 ✅（d55 ⑧ case + s1_w1003 既有锚）/ 对账组 ≥8 ✅（d55 ①-⑧）/ 非正交点计数 → S4 收口同窗（排期维持非本轮缺陷）。新增实施裁定 D55-a/b/c（双集分立/underlying 同一性/N1 38 名单源——22 §15.4 落档）。

### TD-028 VM 主分派与 GC 根扫描性能漂移（P3，r36 新增——57-a/K2 深审 D6 登记）

> **r56 审计复核注记（78-b——T3+ 触发态审计，2026-09-22）**：OBS-C 触发态实测——fib bench 三轮 70.851/71.197/70.624ms（r55 记录 71.4ms 噪声带内一致——r55 状态可复现）；零性能消费面需求信号——**维持待触发**（监测锚 = [t3plus-trigger-audit §4](../stage-3/t3plus-trigger-audit.md) 信号监测矩阵：bench 例行复核 + worklog 提案载体监控）。索引行清偿终态同步补齐（本轮 R4——r54/r55 实况对齐）。

> **r55 清偿注记（77-b——帧槽池窗关闭，2026-09-22）**：P1 帧槽池 + P3 清槽分工落地（vm.rs execute 层内——零接口变更；`strong_count==1` 捕获护栏 + `has_heap` 清槽分工 + CELL_POOL_CAP=256）。A/B 同机对照：**fib 76.4→71.4ms（1.067x 稳定）** / effect_stress 1.05-1.08x / gc 非尾形双峰带持平（诚实落档——基线同带）。**漂移本体修复完成：相对 r24 原始基线 84.2ms 净超越 1.18x**（r36 漂移 +9.9% → r54 分派优化 92.5→76.4 → r55 帧槽池 76.4→71.4）+「或新分布数据」条款满足（OBS-B 剖面兑现 + 剩余大头迁移）——**本 TD 关闭清偿**。承载 = [td028-frame-pool-optimization.md](stage-3/td028-frame-pool-optimization.md) + [deep-review-td028-framepool.md](stage-3/deep-review-td028-framepool.md)（投票 5.5/5.5 GO）。**OBS-C 新登记**（非债务观察项）：fib 剩余 71.4ms 大头 = args Vec 中转（callee 栈位约束证伪直写）+ Frame 构造/帧栈 push——T3+ 触发式（性能消费面 fib <65ms 明确需求信号时开窗；预防式不引入）。

> **r54 增量注记（76-b——分派优化窗首批清偿）**：VM 主分派三优化点落地（O1 span 惰性求值 / O2 指令引用化[单次边界检查 + 消除逐指令 clone] / O3 proto 跨迭代缓存[九处帧变更点显式失效]——vm.rs execute 层内，零接口面变更）。A/B 双二进制实测：**fib 91.238→76.354ms（1.195x）/ gc 尾形 1.143x / check 1.039x（波动带内）**；语义零漂移五手段全绿（904:0:0 + 三语料 A/B 逐字节 diff 空集 + 六审计集 280 + CLI 全路径 + bench 值锚）。承载 = [td028-dispatch-optimization.md](stage-3/td028-dispatch-optimization.md) + [deep-review-td028-dispatch.md](stage-3/deep-review-td028-dispatch.md)（投票 5.5/5.5 GO）。**维持登记**（GC 根扫描快路径与查表化候选未耗尽）——续窗判据收紧：fib < 65ms 或新分布数据（OBS-B：alloc_local_cells 逐调用 Rc 分配——深递归剩余大头候选，触发时先做分配剖面定锚）。
> **r53 增量注记（75-b——check 阶段分布判据锚）**：T3+ 优化窗阶段插桩实测 expander.krf check 全链构成 = read 1287.6ms（34.7%）/ expand 495.3ms（13.4%）/ 自举编译 1909.8ms（51.5%）/ HM 17.4ms（0.5%）——**自举 VM 链三段全为主分派优化受益面**（performance-baseline.md §2.6 v1.1 归因修正承载）；本 TD 的优化窗口判据自此持精确分布数据（非粗粒度全链值）。


- **登记背景（r36 / 57-a）**：K2 大阶段末深审性能基线三重采样实测：fib(25)
  bench 84.2ms（r24 基线）→ **92.3-92.8ms（中位 ~92.5ms，+9.9%）**；
  gc_stress（尾形）38.57ms → **42.2-42.9ms（+9.5%）**；gc_stress_nontail
  91.9-116.9ms（方差带 ±13% 与 r24 105.15ms 重叠——噪声域）。漂移方向
  双基准一致（非纯噪声）。
- **归因候选（三面，未做针对性 profile——Stage 3 优化窗口入场时实测定锚）**：
  ①r25 效应两操作码（INSTALL_HANDLER/PERFORM）+ r30 FFI 三操作码入 VM
  主分派 match——46 臂分支布局变化；②GC 六来源（r25 continuation 帧链
  入根扫描入口——零活跃 continuation 时为空遍历但仍过入口检查）；
  ③ForeignBox 装箱追踪器入口（TD-010 r24——同型）。
- **等级 P3 依据**：正确性零影响（758:0:0 全绿 + 四审计集 190 case）；
  §14.5.3 D6 条款「性能瓶颈除非影响功能正确性，否则记录为 Stage N+2
  优化项」；漂移量级 ~10% 非用户可感知面（CLI bench 口径）。
- **优化候选（Stage 3 优化窗口与 TD-003/TD-015 同窗评估）**：主分派
  查表化/computed goto 候选 + GC 根扫描入口快路径（零 continuation/
  零 Foreign 时跳过）——优化前须先 profile 实测定锚（判据先于先例——
  原则 35）。
- **目标阶段**：Stage 3 优化窗口（触发式——性能消费面出现时）。


### TD-030 check+prelude 组合 HM occurs 误报（P1，r49 / 70-b 登记——前置既有缺陷）

- **发现载体（r49 / 70-b）**：r49-α 声明层臂交付的 CLI 冒烟 check 面扩展
  至 prelude 组合——`(import kerf-prelude) 42` → E0005「无法构造无限类型：
  α47 与 (α46 . α47)（静态检查）」（`kerf check` 全确定性复现）。
- **前置既有性证明（R1 实证）**：git stash 基线对照——r48 HEAD 二进制
  同源逐字一致失败（`(import kerf-prelude) 42` 与最小复现
  `(define (fe f lst) (if (is-nil lst) nil (let ((ignored (f (head lst)))) (fe f (tail lst))))) 42`
  双双同报 E0005）；r49-α 变更零行为漂移（非本轮回归——868:0:0 零回归
  口径下行为逐位一致）。
- **根因初诊（未修复——登记性分析）**：HM 推断的递归 define D4 预置链
  （`infer_item` Define 臂）× let-discard 值约束（Let 臂 discard 模式的
  值类型变元流入求解器）交互——discard 值 `(f (head lst))` 的约束链与
  递归合一（`constraint(alpha, ty)`）在 `solve_now` 前后序上产生 occurs
  假阳性（α_fe 出现于自身参数序对类型 `(α3 . α4)`）。prelude 的
  for-each（let-discard 形态）为首个触发语料。
- **影响面**：`kerf check` / `check_source` 对 prelude 导入程序不可用
  （E0005 假阳性）；run/eval/compile 路径零影响（HM 仅 check 面）；
  测试套件零覆盖该组合（check_source 语料零 prelude——覆盖缺口即本 TD
  发现晚的直接原因）。
- **修复窗（r49-β let 直映臂——D61）**：let 直映的 hm Let 臂重做（D6
  识别迁移 + Let 节点直推）与本 TD 根因同区域——同窗修复 + 新增
  check+prelude 组合测试组（本 TD 的覆盖缺口闭合）。修复验收：
  `(import kerf-prelude) 42` check ok + for-each 形态 check 零误报 +
  prelude 全模块 check 集成组。
- **清偿记录（r50-β / 72-b——2026-09-12）**：D61 let 直映臂交付同窗
  清偿。**机制实证**：`infer_let`（D6 ② Apply[Fn] 同参形状识别）的
  逐绑定 `solve_now()` 提前求解把对称挂起约束变成单向绑定
  （α₂ := (α₃ . α₄)），后续 define 合一在不对称状态下触发 occurs
  误报——r50-β 形状识别整体退役（糖产物不再产出此形态；用户手写
  组合走通用应用[SML 正典：应用位不泛化]），discard 路径零提前求解。
  **验收三件全过**：①`(import kerf-prelude) 42` check ok（CLI 实测
  EXIT 0）②for-each let-discard 形态零误报（最小复现 + prelude 全
  模块导入双验）③prelude 全模块 check 集成组
  （hm_inference_tests td030_check_prelude_combo_clean——五 HOF +
  序对三件 + 表域两件全用点 + 双导入组合 + 真 occurs 负例维持检出
  [修复不弱化 occurs 面]）。**注记**：Let bind 臂的 `solve_now`
  （泛化点前求解）维持——泛化须看到已解类型；退役的是 infer_let 的
  多绑定不对称提前求解（两臂分立：泛化义务 vs 假阳性机制）。
  口径：877:0:0（874 基线零回归 + 净 +3——TD 验收组含于净增）。


### TD-033 组安装语义（Koka 式 handle 臂体互不保护）——多臂嵌套脱糖 sibling 分歧登记（P3，r132 新增——202-b D3 裁定载体）

**登记态**：r132 handle 多臂/halt/pass 窗的实施裁定 = 多臂脱糖为嵌套单臂 handle（先写臂外层——设计单源 [handle-multi-arm-design.md](./stage-3/handle-multi-arm-design.md) v1.0 D2/D3）。嵌套语义的 sibling 面：先写臂的 handler 体不受后写臂保护；后写臂的 handler 体受先写臂保护（非对称——嵌套结构自然结果）。**组安装语义**（Koka shallow handler 族语义——任意臂发射即整组消费、臂体互不保护、对称）= 登记态增强窗，需 HandlerFrame 多 tag 匹配 + 组消费机制变更（VM InstallHandler 载荷 + expander 双侧 + compiler 双侧 + CoreExpr::Handle 多子句形）——机制变更量级与嵌套脱糖的零机制形成对照，故按触发式登记（非阉割版推进：两语义均在文档钉死，分歧案例显式裁定）。

**触发判据**：①臂体 perform 兄弟标签的真实语料消费信号（嵌套语义的非对称性造成实际语义困惑的用例）；②用户指令直接开窗。

**对账**：本行 + 索引行 + [handle-multi-arm-design.md §7 域外表](./stage-3/handle-multi-arm-design.md) + switch-window-plan §4 注记 + t3plus v1.52。

### TD-034 cache 管线富面休眠——目标路径缓存扩展触发式（P3，r154 / 224-a 新增——E6 收口批连带登记）

**登记面**：InMemoryCompilationCache 的管线富面（CacheEntry::Front /
store_front / bootstrap cache 桥 take_hit）随唯一生产消费者
compile_front_cached 的删除（S-expr API 族退役——E6 收口批）转入
休眠（#[allow(dead_code)] + 使命名注记）。**基础维持面**：冻结 trait
CompilationCache（工件级 get/store/invalidate）+ InMemoryCompilationCache
骨架 + cache_stats 统计面 + cache.ktf 决策桥本体俱维持（Stage 1 批次 C
能力面 + cache_tests 消费 + 未来扩展基座）。

**触发条件**（cache.ktf 键协议扩展——run_source 契约注记既有
登记{r155 命名标准化更名——原 run_source_target}）：目标语法路径的编译缓存启用需求（信号 = 目标面重复编译的实测
性能压力或用户指令）——需 cache.ktf 键协议扩展{B11/P4 维度无语法轴}
+ compile_front 接入 consult 链{r155 更名——原 compile_front_target}。

**裁定依据**：原则 41（休眠非删除——拆除判据未满足于「目标路径
消费者」侧）；R2（依赖受限登记——非阉割版{管线富面自 r154 起无生产
消费者，语义完好性由 cache_tests + bootstrap cache 内联测试守卫}）。


### TD-035 命名标准化窗 Batch 2（测试局部名 Tier 3 + 消息文本现代化）——P3 触发式（r155 / 225-a 新增——naming-standardization-plan.md D8 登记）

**登记面**：r155 Batch 1 清偿生产面「target」限定词全域退役后，两类残留面按触发式登记：
①测试局部名 Tier 3（约 60 处——`hm_target`/`target_err`/`neg_target_*`/`target_value`/`assert_target_reader_*`/`seed_front_target` 等测试助手与用例名）：纯装饰性、无 API 耦合、含历史可溯值（如 `sexpr_source_in_target_entry_rejected` 记录 r153 收敛语义）；②消息文本中的时代术语（`.krf` 退役诊断「target-syntax file」表述等）：文本 = 测试断言锚（cli_entry_convergence_tests 诊断文本锚族），改动须携测试锚同步批。

**触发条件**：①用户指令直接开窗（命名标准化续窗 Batch 2）；②消息文本现代化专门窗信号（用户对诊断措辞的意见或下一轮触审发现措辞与实际语义偏离）。**对账**：naming-standardization-plan.md §4 Batch 2 行 + t3plus v1.75 r155 消费注记。

**清偿记录（r156 / 226-b..d——2026-11-21）**：触发条件①兑现（用户指令直接开窗——M1 指令开窗第六十一例：「深度审查项目中是否存在遗留旧时代的编码方式和内容（全面转向现代前沿理论表示……S 表达式相关结构或表现等）+ 完全重构 readme 文件和 web」；方案单源 legacy-residue-clearance-plan.md v1.0{226-a}）。**清偿面三件**：①Tier-3 局部名退役 113 点/13 文件{`target_value`→`run_value` ×80 + `assert_target_reader_stx/err_parity`→`assert_reader_stx/err_parity` ×20 + `target_err_form`→`read_error_form` ×3[bootstrap/reader.rs 生产私有 fn——Batch 1 逃逸名] + `neg_target_*`→`neg_*` ×5 + `hm_target`→`hm_check` ×2 + `seed_front_target`→`seed_front_reader` ×2[冲突实锤——bootstrap_compiler_tests 既有 fn seed_front，备选名申报] + `sexpr_source_in_target_entry_rejected`→`retired_sexpr_entry_rejected` ×1[历史可溯值新名保形——体注 r153 收敛语义保持] + `ktf_corpus_fixpoint_target_syntax_self_compiles`→`ktf_corpus_fixpoint_self_compiles` ×1}；②消息文本现代化两处{.krf 拒收诊断「...is not a .ktf target-syntax file...」→「...is not a .ktf kerf source file; the S-expression surface is retired (r153)...」 + usage 行「.ktf target syntax」→「.ktf kerf syntax」——锚宽松验证过：cli_entry_convergence_tests 断言面 contains("retired")&&contains(".ktf") 双词俱含，零断言改动实测复跑}；③注释时代术语现代化同窗承载{「seed target Reader」→「seed Reader」 ×11 + 「target-Reader bridge」→「reader bridge」 ×~24 + 模块头注现行机制指称修正 ~8 处 + bootstrap 错误标签两处——历史转换注记[E6 close-out 头注族]全保持}。**验收数字**：GATE 1 六命令 clean 起步全绿 **1788:0:0 逐位保持**（RUST_MIN_STACK=33554432——纯重命名+文本轮零测试函数增减零行为变更）+ 审计×6 真实 EXIT 0 ×6{41+50+53+46+43+47 case} + CLI 零回归八探针{bench 75.826ms 带内 + .krf 拒收 exit 2 新消息三短语逐词命中} + 残留 grep 双归零（`target_value|assert_target_reader|neg_target_|hm_target|seed_front_target|target_err_form` 全 .rs 全域 = 0 命中）。**单源对账**：naming-standardization-plan.md Status → **Closed**（Batch 1 = r155 生产面全量；Batch 2 = r156 残响面清偿——TD-035 行权承载 legacy-residue-clearance-plan.md v1.0）+ legacy-residue-clearance-plan.md v1.0 Status → **Closed**（226-a..g 全链）+ t3plus v1.76 r156 消费注记 + matrix.md r156 增量行 + RELEASE_NOTES r156 节。**注记**：登记面「约 60 处」为 r155 期估计口径——r156 轮全量盘点实测清偿 113 点（盘点候选 ~127 点中域外残留如实申报未动：`parity_target`/`target_outcome`/`READER_TARGET·EXPANDER_TARGET·COMPILER_TARGET·PREAMBLE_TARGET` 常量族/`neg_match_pattern_vector_target`——俱不在 D2 字典与 §4.3 验收 pattern 族）；README 完全重构（226-e）与 web 完整更新（226-g 承载）为用户明示扩展面（超出 TD-035 登记域——legacy-residue-clearance-plan D5/D6 裁定）。**TD-035 清偿关闭**；余留 TD-034 维持（P3 触发式——cache 富面休眠）。

### TD-036 用户面数据结构现代化信号——元组表达式形（pair 构造现代面）——P3 触发式（r159 / 229-c 新增——operator-surface-parity-design.md §3 登记）

**登记面**：match 模式位 `(a, b)` pair 解构形与表达式位构造形的**对称缺口**——模式位可解构 pair 而表达式位无构造形（仅 `cons(a, b)` Lisp 时代调用形可用）；现代主数据结构面 = vector（r138 五内建 + `[a, b, c]` 字面量）俱交付，pair 构造的现代皮肤缺位。EBNF Level 0 无 tuple_expr 产生式——实施需 EBNF 增补 + K 候选复审（r158 闭包 EBNF 复审 K-1 同型流程）+ 语义裁定（二元 = cons 同构 / 三元以上 = 右嵌套 or 拒收——`(a, b, c)` 与 list 语义边界）。

**触发条件**：①用户指令直接开窗（数据结构面现代化——「基本数据结构……S 表达式旧时代内容」指令族的后续行权）；②语料信号（用户程序 pair 构造需求的实测压力——当前 usage 语料 cons 调用形 ~10 处均为种子桥惯用形，零用户压力信号）。

**裁定依据**：原则 38（愿景语料登记态——零信号不开窗）+ 原则 41（pair = 内核聚合基座非脚手架——构造面缺位是能力登记非债务本体）+ R2（能力边界登记）。**余留开放项**：TD-034（cache 富面休眠）+ TD-036（本行——触发式）。

**清偿记录（r160 / 230-a..230-e——2026-11-25）**：触发条件①兑现（用户指令直接开窗——M1 指令开窗第六十五例：「审查……数据类型、数据结构……S 表达式旧时代的内容……应该通过目标语言自身设计实现」的数据结构面专项行权）。**清偿面**：`primary → "(" expr "," expr ")"` 元组表达式产生式（第十五皮肤映射）——as-if-written `cons(a, b)`：Reader 直接合成与调用形产物同构的 Stx `(cons e₁ e₂)`（皮肤换、骨架不变——原则 31：零脱糖零新原语零 CoreExpr/IR/操作码，expander/compiler/HM/VM 全链零触及，8 原语不变性第四十二轮）；构造⟺解构对称缺口闭合{模式位 `(p, q)` r121 解构形的表达式位对偶——`match (1, 2) { (a, b) => a + b }` ⇒ 3 对称 E2E}；二元封顶（D2 对称纪律——模式位 r121 裁定镜像，3+ 元 fail-closed 专用诊断）；尾逗号 fail-closed（r138 vector 同律）；cons 调用形维持（D5——内核聚合基座名 + list 链惯用形，能力补齐非退役）；HM/check 零变更（BUILTIN_SIGS `(Any, Any) → Pair` 既有消费——零注册链增量）；双侧 Reader 已实施[种子 parse_primary LParen 逗号臂 + 镜像 parse_tuple_tail——错误面消息+Span 字节级 parity] + ktf_tuple_expr_tests 32 case 门[8 正 + 24 负 1:3——含 as-if-written 字节码全等门 + 全位置形 + 模式位回归锚] + 语料迁移三件[match.ktf describe(cons(1,9))→describe((1,9)) + gc_stress 双件离散 pair 构造位 15 处——输出 parity 逐字节] + 增长签名锚重校准[reader.ktf payload 211/494/242] + **1884:0:0 净 +32**。**单源对账**：tuple-expression-design.md v1.0 Status → **Closed**（GATE 1 实录回填） + 02 v7.28 tuple_expr 产生式 + 20 §14 皮肤字典 v1.39 第十五映射行 + matrix r160 行 + RELEASE r160 节 + t3plus v1.80 消费注记。**TD-036 清偿关闭**；余留 TD-034 维持（P3 触发式——cache 富面休眠，唯一开放项）。

### TD-037 跨值域相等中缀面缺口（`==` num/str 域 vs `eq` Any 域）——**已解决（r162 / 233 相等域窗清偿关闭）**

**登记面**：`==`/`!=` 现代中缀形已实现（reader.rs parse_comparison → `(= a b)` / `(not (= a b))`），但 `=` 的值域 = num_or_all_str（builtins.rs `num_or_all_str` 域检查——`true == true` ⇒ E0004 "= requires a number" 实锤）；跨值域结构相等原语 `eq` 仅有调用形（`(Any, Any) → Bool`——运行时 eq_value 结构相等；match 脱糖消费 r121；N1 现代终名——r42 移除轮裁定）。跨值域相等**无现代中缀面**——表达力缺口非正确性缺陷。

**触发条件**：①用户指令裁定（三选一：`==` 扩域至 eq 语义 / `eq` 中缀化新皮肤 / 诚实边界维持{值域分离本身是一致设计——数值/字符串域现代面 + 跨域显式调用形}）；②语料信号（用户程序跨值域相等需求的实测压力——当前 usage 语料零信号）。

**裁定依据**：原则 38（愿景语料登记态——零信号不开窗）+ R2（能力边界登记）+ 一个概念两个面（r102 命名谱系：`=` 符号名族 vs `eq` 跨域终名——两名的域分离本身合法）。

**清偿记录（r162 / 233-f）**：触发条件①行权——用户指令「eq（等运算符问题，应当使用现代设计理念）」= A 选项（`==` 扩域至 eq 语义）；交付 = 皮肤域重指向{`==`/`!=` → `(eq a b)`/`(not (eq a b))`——双 Reader 单点换目标} + eq 值律结构化分层{structural_eq 用户面单源——Pair/Vector 递归结构相等 + procedural 同一性维持 + 混合域静默 false} + r138 eq? 律修订{Pair/Vector identity → 值相等} + `=` 内核基座休眠态申报 + ordering 族维持 + ktf_equality_domain_tests 32 case 门 + 法修订涟漪九处全数定性；详见登记册版本行 v0.4.20 与 RELEASE r162 节 + 设计单源 equality-domain-design.md v1.0 D1-D10；8 原语不变性第四十四轮；余留开放项 = 仅 TD-034{P3 触发式——cache 富面休眠}。



### TD-038 变参函数面语言缺位（append 自建迁移阻断）——✅ 已清偿关闭（r165 / 236——variadic-rest-design.md v1.0；登记 r164 / 235-c）

**登记面**：kerf-list 域 `append` 的 Rust 迁移阻断——变参 arity（0/1/n 参数变元——Rust `args` 切片天然面）超出 kerf fn 定参面（调用 arity 不匹配 → E0004）。当前变参族仅 `list`/`append`/`append` 类内建（N1 构造 + 拼接）。

**清偿记录（r165 / 236-a..236-f）**：触发条件①②双满足行权——用户指令「单函数层级 ≤3……变量名称应该清晰简要明确」+ TD-038 登记本体 = 推荐序首位唯一实际候选{TD-034 零信号休眠 / TD-039 阻断于 native-AOT / TD-040 本轮新登记}；交付 = `fn f(a: T, ...rest: T)` 现代 rest 参数形全链{语法 D1 + Stx/内核 D2 + 双 Reader/expander/compiler 锁步 D3 + VM 帧行为 D4/D5 + HM/check D6}——`...` 词法零变更（r129 ident 载荷先例）、CoreExpr::Fn 加性字段（原则 27）、wire 协议零 bump（定参面逐字节向后兼容）、min-arity fail-closed（报错>静默 §2.3-4）；**D7' 实施期实裁**：append 全量迁移泊回{注入/注册互斥 E0004 实测 + 种子链热消费 r164 member/assoc 同族——kerf 实现已证[测试门内联 kl_va_append 全语义 + 错误面逐字节]——TD-041 触发式重迁}；**TD-038 登记本体「变参函数面语言缺位」已闭环**{语言面全链交付 + 探针实证}；32 case 门 + 2044:0:0 净 +32 + bench -0.9% 噪声带；详见登记册版本行 v0.4.23 与 RELEASE r165 节 + 设计单源 variadic-rest-design.md v1.0 D1-D11。

### TD-040 自举语料代码质量（深度>3 / 超长函数 / 短名 / 职责混合）——P3 触发式批窗（r165 / 236-a-audit 新增——variadic-rest-design.md §0 附带腿）

**登记面**：236-a-audit 工具化实测（python 词法清洗 + fn 体块层级计数 + 跨度/命名全量盘点——脚本留档 /home/z/audit_tmp/audit_ktf.py）：全语料 13,162 行 / 677 函数——**深度>3 违例 77 函数（11.4%）**{reader 36 / expander 33 / check 3 / compiler 2 / build 2 / list 1——95% 集中机械翻译三代件；`} else { if` 堆叠链 = 直接成因——compiler.ktf 同代件 `else if` 平链风格最深仅 4 实证可等价重写消解} + **超 80 行函数 9 件**{compile_expr 170 / lex_op 169 / expand_core_form 150 / parse_primary 127 / postfix_loop 106 / parse_item 99 / parse_pattern_atom 99 / block_loop 86 / tc_rule_one 82} + 命名短名族{形参 ≤2 字符 23.7% / let 局部 50.7%——r/r2/r3/r4 泛用结果名族 105 处 + 双字母缩写族} + 职责混合（>80 行 9 件全数多职责）。Top-5 热点：lex_op 深度36/169行、expand_core_form 深度18/150行、parse_pattern_atom 深度16、parse_item 深度15、parse_primary 深度15/127行。**新写件面健康**{list/build/cache/cli/test/test_runner 61 函数仅 3 例轻度越线}。**触发条件**：①批窗开窗信号（用户指令「单函数层级 ≤3、单一职责、适度长度、变量名清晰」的存量面行权——r165 窗只交付了新代码纪律 + 登记）；②与 TD-041 语料拼接迁移同窗协同（append 迁移携带 reader/expander 拼接面改写）。**处置三轨**：堆叠 else → `else if` 平链等价重写（消解 ~70/77 例）+ >80 行函数分拆（9 件）+ 三代件短名清洗；**零行为变更约束**{输出字节码全等门 + 错误面 parity 维持}。**对账**：variadic-rest-design.md §0 + worklog 236-a-audit。

### TD-041 append 自建重迁——种子链热消费 + 注入/注册互斥双阻断触发式（r165 / 236-d 新增——variadic-rest-design.md §6 D7'）

**登记面**：kerf-list 域 `append` 的 kerf 自建实现**已证**（r165 测试门内联 kl_va_append——全语义{0 实参⇒nil / 1 实参 as-is / n 实参拼接 fresh 链 + shared 末参} + 错误面「append # N requires list, got TYPE」逐字节 + 结构纪律{kl_va 族尾递归 TD-022 + ≤2 深度 + 单一职责}——「语料实现已证」与 r164 member/assoc 同口径）——泊回双阻断实测：①**注入/注册互斥**{import kerf_list 注入的 fn append 与 Rust 注册 append 撞名 E0004「duplicate variable definition」——五自建名 r164 先例的根因正是注册退役；append 注册在位服务种子链/N1 则注入必断}；②**种子链热消费**{reader.ktf ×6 + expander.ktf ×5 的 Stx 装配/宏产物拼接消费 append——r164 member/assoc 12.5x PoC 同族性能边界}。**触发条件**：①native-AOT QBE 性能回收（TD-039 同族）；②TD-040 语料拼接迁移{reader/expander 批窗改写拼接面 = 注入面就位的前置}。**对账**：variadic-rest-design.md §6 D7' + §9.2 + RELEASE r165 节 + t3plus v1.85。

### TD-039 member/assoc 自建重迁——native-AOT 性能回收触发式（r164 / 235-e 新增——list-self-built-design.md §9.1）

**登记面**：kerf-list 域 `member`/`assoc` 的 kerf 自建实现**已证**（r164 窗内 E2E + 错误面逐字节复刻交付后泊回）——阻断面 = 过渡期 VM 解释性能边界（check-HM 查询段深度敏感热消费：全迁移态 expander 语料 check 37s 撞 10⁹ TCO 守卫实测；泊回后 24.1s 收口）。**触发条件**：native AOT QBE 后端（CLI `native` PoC 既有）的性能回收就绪（AOT 编译 kerf 递归为机器码后重实测——守卫内即重迁）。**对账**：list-self-built-design.md v1.1 §9.1 + RELEASE r164 节 + t3plus v1.84。

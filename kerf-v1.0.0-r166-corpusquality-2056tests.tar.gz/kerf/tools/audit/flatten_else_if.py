#!/usr/bin/env python3
"""flatten_else_if.py — TD-040 Track 1: stacked-else -> flat `else if` chains.

Equivalence law (zero-behavior by construction, corpus-quality-batch-design D2):
    else { if (C) { A } else { B } }   ==   else if (C) { A } else { B }
when the else block contains EXACTLY ONE statement (an if-expression) and
nothing else (whitespace/comments aside).

Method: brace-matched lexical scan (strings/comments stripped for matching,
original text preserved), single-statement check, wrapper-brace removal,
fixpoint iteration (each pass flattens one nesting level per chain).

Usage: python3 tools/audit/flatten_else_if.py <file.ktf> [--check]
  --check: report how many rewrites WOULD apply, change nothing.
"""

import re
import sys


def strip_for_match(src: str):
    """Return a same-length string where string-literal and comment chars are
    neutralized, so brace matching ignores them while indexes stay aligned."""
    out = list(src)
    i = 0
    n = len(src)
    in_str = False
    while i < n:
        ch = src[i]
        if in_str:
            if ch == "\\":
                out[i] = " "
                if i + 1 < n:
                    out[i + 1] = " "
                i += 2
                continue
            if ch == '"':
                in_str = False
                out[i] = " "
            else:
                out[i] = " "
            i += 1
            continue
        if ch == '"':
            in_str = True
            out[i] = " "
            i += 1
            continue
        if ch == ";" and i + 1 < n and src[i + 1] == ";":
            j = src.find("\n", i)
            j = n if j == -1 else j
            for k in range(i, j):
                out[k] = " "
            i = j
            continue
        if ch == "/" and i + 1 < n and src[i + 1] == "/":
            j = src.find("\n", i)
            j = n if j == -1 else j
            for k in range(i, j):
                out[k] = " "
            i = j
            continue
        i += 1
    return "".join(out)


WORD = re.compile(r"[A-Za-z0-9_!?]")


def skip_ws(match_src: str, i: int) -> int:
    n = len(match_src)
    while i < n and match_src[i] in " \t\r\n":
        i += 1
    return i


def match_brace(match_src: str, i: int) -> int:
    """i points at '{'; return index of matching '}'."""
    depth = 0
    n = len(match_src)
    while i < n:
        if match_src[i] == "{":
            depth += 1
        elif match_src[i] == "}":
            depth -= 1
            if depth == 0:
                return i
        i += 1
    return -1


def find_if_span(match_src: str, i: int) -> int:
    """i points at 'if' keyword start; return end index (exclusive) of the
    complete if-expression including any else / else if tails."""
    n = len(match_src)
    # keyword
    if match_src[i : i + 2] != "if":
        return -1
    j = i + 2
    if j < n and WORD.match(match_src[j]):
        return -1  # identifier like iff
    # condition parens
    j = skip_ws(match_src, j)
    if j >= n or match_src[j] != "(":
        return -1
    # match parens
    depth = 0
    while j < n:
        if match_src[j] == "(":
            depth += 1
        elif match_src[j] == ")":
            depth -= 1
            if depth == 0:
                break
        j += 1
    if j >= n:
        return -1
    j += 1
    # then block
    j = skip_ws(match_src, j)
    if j >= n or match_src[j] != "{":
        return -1
    j = match_brace(match_src, j)
    if j == -1:
        return -1
    j += 1
    # tail loop: else / else if
    while True:
        k = skip_ws(match_src, j)
        save = k
        if match_src[k : k + 4] == "else":
            k2 = k + 4
            if k2 < n and WORD.match(match_src[k2]):
                j = save
                break
            k2 = skip_ws(match_src, k2)
            if k2 < n and match_src[k2 : k2 + 2] == "if" and not (
                k2 + 2 < n and WORD.match(match_src[k2 + 2])
            ):
                # else if — recurse for its span via same routine
                sub = find_if_span(match_src, k2)
                if sub == -1:
                    j = save
                    break
                j = sub
                continue
            if k2 < n and match_src[k2] == "{":
                e = match_brace(match_src, k2)
                if e == -1:
                    j = save
                    break
                j = e + 1
                continue
            j = save
            break
        else:
            j = save
            break
    return j


def one_pass(src: str):
    """Return (new_src, applied_count)."""
    ms = strip_for_match(src)
    n = len(src)
    out = []
    i = 0
    applied = 0
    while i < n:
        ch = ms[i]
        if ch == "e" and src[i : i + 4] == "else":
            # word boundary before
            if i > 0 and WORD.match(ms[i - 1] or " "):
                out.append(src[i])
                i += 1
                continue
            j = i + 4
            if j < n and WORD.match(ms[j] or " "):
                out.append(src[i])
                i += 1
                continue
            # skip ws
            k = skip_ws(ms, j)
            if k < n and ms[k] == "{":
                # find first significant token inside
                p = skip_ws(ms, k + 1)
                if p < n and ms[p : p + 2] == "if" and not (
                    p + 2 < n and WORD.match(ms[p + 2] or " ")
                ):
                    ifend = find_if_span(ms, p)
                    if ifend != -1:
                        # after if: only ws until wrapper close?
                        q = skip_ws(ms, ifend)
                        if q < n and ms[q] == "}":
                            # single-if else block confirmed -> flatten
                            applied += 1
                            # emit: else SP if-statement (from p..ifend)
                            out.append("else ")
                            out.append(src[p:ifend])
                            i = q + 1
                            continue
        out.append(src[i])
        i += 1
    return "".join(out), applied


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    path = sys.argv[1]
    check_only = "--check" in sys.argv
    with open(path, encoding="utf-8") as f:
        src = f.read()
    total = 0
    cur = src
    while True:
        new, applied = one_pass(cur)
        if applied == 0:
            break
        total += applied
        cur = new
        if check_only:
            # in check mode count further passes without materializing
            continue
    print(f"{path}: flatten sites = {total}")
    if not check_only and total > 0:
        with open(path, "w", encoding="utf-8") as f:
            f.write(cur)


if __name__ == "__main__":
    main()

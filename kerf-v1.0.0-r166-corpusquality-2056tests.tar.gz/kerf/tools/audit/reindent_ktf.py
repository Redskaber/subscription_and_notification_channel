#!/usr/bin/env python3
"""reindent_ktf.py — brace-depth re-indentation for flattened .ktf seed files.

Normalization pass for TD-040 Track 1: after else-if flattening the chain arms
keep their historical staircase indentation; this pass re-indents every line
by its actual brace depth (leading-whitespace-only changes — string literals
and comments content preserved verbatim, so behavior is unchanged by
construction; kerf is whitespace-insensitive outside strings).

Usage: python3 tools/audit/reindent_ktf.py <file.ktf> [--check]
"""

import sys

INDENT = "    "  # 4 spaces


def stripped(line: str) -> str:
    """Same-length neutralized copy (strings/comments blanked) for counting."""
    out = list(line)
    i = 0
    n = len(line)
    in_str = False
    while i < n:
        ch = line[i]
        if in_str:
            if ch == "\\":
                if i + 1 < n:
                    out[i + 1] = " "
                out[i] = " "
                i += 2
                continue
            if ch == '"':
                in_str = False
            out[i] = " "
            i += 1
            continue
        if ch == '"':
            in_str = True
            out[i] = " "
            i += 1
            continue
        if ch == ";" and i + 1 < n and line[i + 1] == ";":
            j = line.find("\n", i)
            j = n if j == -1 else j
            for k in range(i, j):
                out[k] = " "
            break
        if ch == "/" and i + 1 < n and line[i + 1] == "/":
            j = line.find("\n", i)
            j = n if j == -1 else j
            for k in range(i, j):
                out[k] = " "
            break
        i += 1
    return "".join(out)


def reindent(src: str):
    lines = src.split("\n")
    out = []
    depth = 0
    changed = 0
    for raw in lines:
        sig = raw.lstrip()
        if sig == "":
            out.append("")
            continue
        s = stripped(sig)
        leading_closes = 0
        while leading_closes < len(s) and s[leading_closes] == "}":
            leading_closes += 1
        level = depth - leading_closes
        if level < 0:
            level = 0
        new = INDENT * level + sig
        if new != raw:
            changed += 1
        out.append(new)
        depth += s.count("{") - s.count("}")
        if depth < 0:
            depth = 0
    return "\n".join(out), changed


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    path = sys.argv[1]
    check_only = "--check" in sys.argv
    with open(path, encoding="utf-8") as f:
        src = f.read()
    new, changed = reindent(src)
    if check_only:
        print(f"{path}: would reindent {changed} lines")
        return
    with open(path, "w", encoding="utf-8") as f:
        f.write(new)
    print(f"{path}: reindented {changed} lines")


if __name__ == "__main__":
    main()

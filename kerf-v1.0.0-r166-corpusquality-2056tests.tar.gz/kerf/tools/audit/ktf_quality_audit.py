#!/usr/bin/env python3
"""ktf_quality_audit.py — bootstrap corpus code-quality audit (TD-040 carrier).

Methodology (r165 / 236-a-audit recreation, archived in-repo per R4):
- lexical scan of `fn NAME(...) {` declarations in .ktf seed files
- fn body block-depth counting (max brace nesting inside the body)
- fn span (line count) + short-name inventory (params / let-locals <= 2 chars)
- flags: depth > 3, span > 80 lines, short-name ratio

Usage: python3 tools/audit/ktf_quality_audit.py [root]
Prints a per-file / per-function violation table + summary counts.
Exit code 0 always (audit tool, not a gate runner).
"""

import os
import re
import sys

ROOT = sys.argv[1] if len(sys.argv) > 1 else "crates/kerf-driver/src/bootstrap"
DEPTH_LIMIT = 3
SPAN_LIMIT = 80

FN_RE = re.compile(r"^\s*fn\s+([A-Za-z0-9_!?]+)\s*\(")


def strip_line(line: str) -> str:
    """Remove string literals and line comments so braces in text do not count."""
    out = []
    i = 0
    n = len(line)
    in_str = False
    while i < n:
        ch = line[i]
        if in_str:
            if ch == "\\":
                i += 2
                continue
            if ch == '"':
                in_str = False
            i += 1
            continue
        if ch == '"':
            in_str = True
            i += 1
            continue
        if ch == ";" and i + 1 < n and line[i + 1] == ";":
            break  # line comment (`;;`) — but `;` alone is a statement separator
        if ch == "/" and i + 1 < n and line[i + 1] == "/":
            break
        out.append(ch)
        i += 1
    return "".join(out)


def audit_file(path: str):
    with open(path, encoding="utf-8") as f:
        lines = f.readlines()

    results = []
    cur = None  # {name, start, depth_now, max_depth, span_end}
    stack_depth = 0

    def close(idx: int):
        nonlocal cur
        if cur is not None:
            cur["span"] = idx - cur["start"] + 1
            results.append(cur)
            cur = None

    for i, raw in enumerate(lines):
        line = strip_line(raw)
        m = FN_RE.match(raw)
        if m and cur is None:
            cur = {
                "name": m.group(1),
                "start": i + 1,
                "max_depth": 0,
            }
            # count braces on the signature line itself after the opening brace
            open_b = line.find("{")
            stack_depth = line.count("{") - line.count("}") if open_b != -1 else 0
            cur["max_depth"] = max(cur["max_depth"], stack_depth)
            continue
        if cur is not None:
            opens = line.count("{")
            closes = line.count("}")
            # entering the fn body: the fn's own brace counts as depth 1
            stack_depth += opens - closes
            cur["max_depth"] = max(cur["max_depth"], stack_depth)
            if stack_depth <= 0:
                close(i)
    if cur is not None:
        close(len(lines))

    # short-name inventory (params + let locals)
    short_params = 0
    total_params = 0
    short_lets = 0
    total_lets = 0
    for raw in lines:
        pm = re.match(r"^\s*fn\s+[A-Za-z0-9_!?]+\s*\(([^)]*)\)", raw)
        if pm:
            for p in pm.group(1).split(","):
                p = p.strip().split(":")[0].strip()
                if p:
                    total_params += 1
                    if len(p) <= 2:
                        short_params += 1
        lm = re.match(r"^\s*let\s+([A-Za-z0-9_!?]+)\s*=", raw)
        if lm:
            total_lets += 1
            if len(lm.group(1)) <= 2:
                short_lets += 1

    return results, (short_params, total_params, short_lets, total_lets)


def main():
    files = []
    for base, _, names in os.walk(ROOT):
        for n in sorted(names):
            if n.endswith(".ktf"):
                files.append(os.path.join(base, n))

    grand = {
        "fns": 0,
        "depth_violations": [],
        "span_violations": [],
        "lines": 0,
        "sp": 0,
        "tp": 0,
        "sl": 0,
        "tl": 0,
    }

    for path in sorted(files):
        results, (sp, tp, sl, tl) = audit_file(path)
        with open(path, encoding="utf-8") as f:
            nlines = sum(1 for _ in f)
        grand["lines"] += nlines
        grand["sp"] += sp
        grand["tp"] += tp
        grand["sl"] += sl
        grand["tl"] += tl
        grand["fns"] += len(results)
        fpath = path.replace(ROOT + "/", "")
        for r in results:
            if r["max_depth"] > DEPTH_LIMIT:
                grand["depth_violations"].append(
                    (fpath, r["name"], r["max_depth"], r["span"], r["start"])
                )
            if r["span"] > SPAN_LIMIT:
                grand["span_violations"].append(
                    (fpath, r["name"], r["max_depth"], r["span"], r["start"])
                )

    print(f"corpus: {grand['lines']} lines / {grand['fns']} functions / {len(files)} files")
    print(
        f"short params: {grand['sp']}/{grand['tp']}"
        f" ({100 * grand['sp'] / max(1, grand['tp']):.1f}%)"
        f" | short lets: {grand['sl']}/{grand['tl']}"
        f" ({100 * grand['sl'] / max(1, grand['tl']):.1f}%)"
    )
    print()
    print(f"== depth>{DEPTH_LIMIT} violations: {len(grand['depth_violations'])} ==")
    for f, n, d, s, ln in sorted(grand["depth_violations"], key=lambda x: -x[2]):
        print(f"  {f}:{ln}  {n}  depth={d}  span={s}")
    print()
    print(f"== span>{SPAN_LIMIT} violations: {len(grand['span_violations'])} ==")
    for f, n, d, s, ln in sorted(grand["span_violations"], key=lambda x: -x[3]):
        print(f"  {f}:{ln}  {n}  depth={d}  span={s}")


if __name__ == "__main__":
    main()

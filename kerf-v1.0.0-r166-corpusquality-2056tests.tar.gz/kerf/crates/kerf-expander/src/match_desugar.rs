//! match implementation batch M-2 — the D2 skin-dictionary seventh mapping:
//! the match-arm → cond/let desugar (match-design.md v1.1 §3, r122 / 192-a).
//! match implementation batch M-3 — the §4 exhaustiveness gate (r123 /
//! 193-a): conservative sound rules, diagnostic-only (the desugar product
//! stays byte-identical to M-2 — the uniform chain keeps the fallback).
//!
//! **Architectural positioning** (principle 31 — skin/skeleton isomorphism):
//! `match` never enters `CoreExpr`. The expansion-time desugar lowers the M-1
//! intermediate form `(match scrut (pattern [guard] body) ...)` into a pure
//! chain of **existing** core forms — `let` / `if` / the `and`/`or` sugars /
//! applications of existing builtins (`eq`, `is-pair`, `is-nil`, `head`,
//! `tail`, `error`). Zero new primitives, zero new channels, zero VM changes
//! (the 8-primitive invariance holds by construction: the compiled product
//! is always If/Let/Apply over the existing instruction set).
//!
//! **Canonical product shape** (r122 / 192-a rulings, registered in
//! match-design.md v1.2 §3.4 — the single source for both the seed Rust
//! desugar and the expander.ktf mirror):
//!
//! ```text
//! (match scrut arm1 ... armK)
//!   → (let ((m scrut))
//!        chain)
//! m      = "match-scrut$hyg$N" — one temp per desugar site, globally
//!          monotonic N (single-evaluation contract §3.3; the global counter
//!          is stricter than the per-site macro α-channel: sibling/nested
//!          desugars never mint the same name, eliminating max-cardinality
//!          ties in scope resolution)
//! chain  = fold right-to-left, rest0 = (error "match failed: no arm matched") (§4
//!          defensive runtime fallback)
//! arm    = (if test_full product rest):
//!            test_full:  T=none,G=none → literal true (uniform chain — no
//!                        desugar-layer dead-code elimination: dead arms stay
//!                        expanded and diagnosed, report-don't-stay-silent; elimination is
//!                        the Stage 2+ optimizer's domain)
//!                        T=none,G=g    → (let binds g) | g  (binds empty)
//!                        T=t,  G=none → t
//!                        T=t,  G=g    → (and t X) — short-circuit keeps the
//!                        guard out of reach until the structural test passes
//!            product:    (let binds body) | body  (binds re-extracted —
//!                        pure head/tail chains on the temp; arm bindings
//!                        never leak into `rest`, §3.3 arm-scope isolation)
//! pattern analysis at path p (path = head/tail chain over m):
//!   literal L  → (eq p L)      — `eq` = type-strict polymorphic equality
//!                                 (refines the design's schematic `=`: `=`
//!                                 is the numeric-chain comparison and would
//!                                 error on Bool/Nil scrutinees and
//!                                 cross-match Int/Float; `eq` is the exact
//!                                 single-source predicate for the pattern
//!                                 literal family)
//!   nil ()     → (is-nil p)    — the dedicated row of the §3.2 table
//!   _          → no test
//!   binding n  → no test, binds n:=p (E0020 pre-check: keyword names are
//!                 not bindable in pattern position)
//!   (p1 p2)    → (and (is-pair p) sub-tests...) — pair destructuring,
//!                 left-to-right binding order
//!   (or a1 a2 ...) → binding-map identity across alternatives (name AND
//!                 path — stricter than the design-letter name-set rule:
//!                 dynamic typing has no position-unification channel, and
//!                 per-alternative binding extraction would need match-tag
//!                 join points beyond the Level 0 desugar); any no-test
//!                 alternative makes the whole or always-true
//! ```

use std::rc::Rc;

use kerf_core::CoreExpr;
use kerf_span::Span;
use kerf_syntax::{Keyword, ScopeSet, Stx, StxDatum, StxLiteral, Symbol, SymbolTable};

use crate::expander::{expand_form, ExpandCtxt, ExpandError};

/// All symbols the desugar product consumes: the §3.2 predicate column
/// (`eq` ruling + `is-pair`/`is-nil`/`head`/`tail`), the §4 fallback carrier
/// (`error`), and the core-form/sugar heads (`let`/`if`/`and`/`or` —
/// resolved through the context table so the constructed Stx carries the
/// same Symbol ids the regular expansion dispatches on).
struct Syms {
    eq: Symbol,
    is_pair: Symbol,
    is_nil: Symbol,
    head: Symbol,
    tail: Symbol,
    error: Symbol,
    kw_let: Symbol,
    kw_if: Symbol,
    kw_and: Symbol,
    kw_or: Symbol,
}

impl Syms {
    fn resolve(table: &mut SymbolTable) -> Self {
        Syms {
            eq: table.intern("eq"),
            is_pair: table.intern("is-pair"),
            is_nil: table.intern("is-nil"),
            head: table.intern("head"),
            tail: table.intern("tail"),
            error: table.intern("error"),
            kw_let: table.keyword_symbol(Keyword::Let),
            kw_if: table.keyword_symbol(Keyword::If),
            kw_and: table.keyword_symbol(Keyword::And),
            kw_or: table.keyword_symbol(Keyword::Or),
        }
    }

    fn sym(&self, s: Symbol, span: Span) -> Stx {
        Stx::symbol(s, span, ScopeSet::new())
    }
}

/// One pattern binding: name (display string + Symbol) + its extraction path
/// (the canonical key for or-map identity, the path expression for the let
/// bindings, the source span for diagnostics).
struct Bind {
    name: Symbol,
    name_str: String,
    key: String,
    path: Stx,
    span: Span,
}

/// A scrutinee sub-path: the canonical key (`""` = the temp itself, `"h"` =
/// head, `"t"` = tail, composed left-to-right) + the extraction expression.
struct Path {
    key: String,
    expr: Stx,
}

/// The analysis product of one pattern: the structural test (if any) and the
/// ordered binding list.
struct Analysis {
    test: Option<Stx>,
    binds: Vec<Bind>,
}

/// The M-2 entry: `(match scrut arm...)` → the cond/let desugar product →
/// regular expansion (the product is an ordinary Stx program fragment — the
/// let/if/and/or machinery and scope injection treat it exactly like
/// user-written forms; only the temp name is machine-reserved).
pub(crate) fn expand_match(
    stx: &Stx,
    items: &[Stx],
    ctx: &mut ExpandCtxt,
) -> Result<Rc<CoreExpr>, ExpandError> {
    // ---- 1. Shape validation (the M-1 arm contract, §3.0) ----
    if items.len() < 3 {
        return Err(ExpandError::new(
            "match form: (match scrutinee arm...) -- at least one arm(zero arms fail-closed)",
            stx.span,
        ));
    }
    let scrut = items[1].clone();
    let arms = &items[2..];
    let syms = Syms::resolve(&mut ctx.table);

    // ---- 2. The scrutinee temp (single-evaluation contract, §3.3) ----
    let temp_n = ctx.fresh_uniq();
    let temp_name = format!("match-scrut$hyg${}", temp_n);
    let temp_sym = ctx.table.intern(&temp_name);
    let root = Path {
        key: String::new(),
        expr: syms.sym(temp_sym, stx.span),
    };

    // ---- 3. Fold the arms right-to-left (uniform chain, §3.4 rulings) ----
    let mut rest = fallback_call(&syms, stx.span);
    for arm in arms.iter().rev() {
        let fields = arm.datum.as_list().ok_or_else(|| {
            ExpandError::new(
                "match arm form: (pattern [guard] body) -- two- or three-element list",
                arm.span,
            )
        })?;
        if fields.len() != 2 && fields.len() != 3 {
            return Err(ExpandError::new(
                "match arm form: (pattern [guard] body) -- two- or three-element list(guard centered)",
                arm.span,
            ));
        }
        let (pattern, guard, body) = match fields.len() {
            2 => (&fields[0], None, &fields[1]),
            _ => (&fields[0], Some(&fields[1]), &fields[2]),
        };
        let analysis = analyze_pattern(pattern, &root, &syms, &mut ctx.table)?;
        // Arm-level duplicate-binding check (diagnostic precision: the second
        // occurrence's span; multi-binding let would silently shadow without
        // this).
        check_duplicates(&analysis.binds)?;
        // Guard visibility: the guard evaluates inside the binding scope
        // (§3.2 guard row); the arm bindings never leak into `rest`.
        let test_full = match (&analysis.test, guard) {
            (None, None) => true_stx(arm.span),
            (None, Some(g)) => with_binds(g.clone(), &analysis.binds, arm.span, &syms),
            (Some(t), None) => t.clone(),
            (Some(t), Some(g)) => and_form(
                vec![
                    t.clone(),
                    with_binds(g.clone(), &analysis.binds, arm.span, &syms),
                ],
                arm.span,
                &syms,
            ),
        };
        let product = with_binds(body.clone(), &analysis.binds, arm.span, &syms);
        rest = if_form(test_full, product, rest, arm.span, &syms);
    }

    // ---- 4. The scrutinee wrapper ----
    let temp_bind = vec![Bind {
        name: temp_sym,
        name_str: temp_name,
        key: String::new(),
        path: scrut,
        span: stx.span,
    }];
    let product = let_form(&temp_bind, rest, stx.span, &syms);

    // ---- 5. The M-3 exhaustiveness gate (§4 conservative rules) ----
    // Fires AFTER the fold: structural diagnostics (arm shapes / pattern
    // domain / or identity / duplicates / E0020) keep their surfacing order
    // — the negative-family message-order contract. Diagnostic-only: the
    // product above is untouched (byte-identical to the M-2 canonical
    // shape — no dead-code elimination at the desugar layer).
    check_exhaustive(arms, &ctx.table, stx.span)?;

    expand_form(&product, ctx)
}

/// The M-3 gate: an unguarded total arm (wildcard / bare binding / an or
/// with a total alternative — exactly the fold's test=None class) OR the
/// bool closed-domain exemption ({true, false} both among the top-level
/// literals of unguarded arms, or-alternatives flattened). Everything else
/// → E0025 (int/float/str are open domains — never judged exhaustive; nil's
/// complement (non-nil) has no literal form, so it closes nothing either).
fn check_exhaustive(
    arms: &[Stx],
    table: &SymbolTable,
    match_span: Span,
) -> Result<(), ExpandError> {
    let mut has_true = false;
    let mut has_false = false;
    for arm in arms {
        // Shapes are fold-validated (the gate runs only on fold success):
        // every arm is a 2/3-element list; a 3-element arm is guarded.
        let fields = arm
            .datum
            .as_list()
            .expect("arm shapes validated by the fold");
        if fields.len() == 3 {
            // A guarded arm contributes nothing: the guard is an arm-level
            // secondary filter that can reject — counting it would
            // contradict the §4 fallback-unreachability claim (r123 ruling:
            // guarded wildcard/binding/literal arms are not total).
            continue;
        }
        let pattern = &fields[0];
        if pattern_is_total(pattern, table) {
            return Ok(());
        }
        scan_top_bools(pattern, table, &mut has_true, &mut has_false);
    }
    if has_true && has_false {
        // The closed-domain exemption — pattern-structural (the scrutinee
        // type is unknown at expansion time; `eq` is any→any→bool so HM
        // does not gate the type side either: a non-bool scrutinee stays
        // the §4 runtime fallback's residual reachable class — the
        // principle-42 double layer).
        return Ok(());
    }
    Err(ExpandError::new(
        "non-exhaustive match: missing wildcard arm (E0025 -- consider adding a `_ =>` final arm or true/false closed-domain dual arms; int/float/str/() are open domains where exhaustiveness is not decided, match-design §4 conservative rule)",
        match_span,
    ))
}

/// Pattern-position totality (the fold's test=None class, re-derived
/// lightweight): wildcard / bare binding / an or-marker with any total
/// alternative. Pair destructuring and every literal family carry
/// structural tests — never total.
fn pattern_is_total(pattern: &Stx, table: &SymbolTable) -> bool {
    match &pattern.datum {
        StxDatum::Symbol(_) => true,
        StxDatum::List(items) => {
            if or_marker_items(items, table) {
                return items[1..].iter().any(|alt| pattern_is_total(alt, table));
            }
            false
        }
        _ => false,
    }
}

/// Top-level bool-literal scan (or-alternatives flattened — `(or true
/// false)` in one arm covers both). Literals at nested pair positions do
/// not count: the pair pattern carries `is-pair`, so it is structurally
/// never total regardless of the nested literals.
fn scan_top_bools(pattern: &Stx, table: &SymbolTable, has_true: &mut bool, has_false: &mut bool) {
    match &pattern.datum {
        StxDatum::Literal(StxLiteral::Bool(true)) => *has_true = true,
        StxDatum::Literal(StxLiteral::Bool(false)) => *has_false = true,
        StxDatum::List(items) if or_marker_items(items, table) => {
            for alt in &items[1..] {
                scan_top_bools(alt, table, has_true, has_false);
            }
        }
        _ => {}
    }
}

/// The or-marker shape shared by the totality and bool scans: ≥3 elements
/// whose head symbol is the reserved `or` (2-element lists are always pair
/// destructuring — the head "or" in that slot flows into the E0020
/// reserved-binding rejection, mirroring the fold's `match_is_or_head`).
fn or_marker_items(items: &[Stx], table: &SymbolTable) -> bool {
    items.len() >= 3
        && items[0]
            .datum
            .as_symbol()
            .is_some_and(|head_sym| table.name(head_sym) == "or")
}

/// Pattern analysis at `path` (the §3.2 semantic table + the §3.4 canonical
/// rulings). Returns the structural test (if any) and the ordered bindings.
fn analyze_pattern(
    pattern: &Stx,
    path: &Path,
    syms: &Syms,
    table: &mut SymbolTable,
) -> Result<Analysis, ExpandError> {
    match &pattern.datum {
        // ---- literal family (int/float/str/bool): (eq path L) — the `eq`
        // ruling (type-strict polymorphic; see the module doc) ----
        StxDatum::Literal(
            StxLiteral::Int(_) | StxLiteral::Float(_) | StxLiteral::Str(_) | StxLiteral::Bool(_),
        ) => Ok(Analysis {
            test: Some(app(
                syms.eq,
                vec![path.expr.clone(), pattern.clone()],
                pattern.span,
            )),
            binds: Vec::new(),
        }),
        // ---- nil pattern `()` (the skin literal maps to the dedicated
        // is-nil row of the §3.2 table) ----
        StxDatum::Literal(StxLiteral::Nil) => Ok(Analysis {
            test: Some(app(syms.is_nil, vec![path.expr.clone()], pattern.span)),
            binds: Vec::new(),
        }),
        // ---- binding / wildcard ----
        StxDatum::Symbol(sym) => {
            let name = table.name(*sym).to_string();
            if name == "_" {
                // Wildcard: no test, no binding (the lexical ident whose
                // pattern-position semantics were re-judged in M-1).
                return Ok(Analysis {
                    test: None,
                    binds: Vec::new(),
                });
            }
            // E0020 pre-check: pattern position is a binding position —
            // keyword names are not bindable (22 §2.1; the driver's
            // Stx/CoreExpr two layers do not know pattern shapes, so this
            // arm carries the pattern-binding face with a precise span).
            if Keyword::from_name(&name).is_some() {
                return Err(ExpandError::new(
                    format!(
                        "reserved word is not bindable: `{}` is N4 keyword -- keyword is not value, not referenceable, not shadowable(22 §2.1); pattern binding position belongs to binding face(match arm pattern, E0020)",
                        name
                    ),
                    pattern.span,
                ));
            }
            Ok(Analysis {
                test: None,
                binds: vec![Bind {
                    name: *sym,
                    name_str: name,
                    key: path.key.clone(),
                    path: path.expr.clone(),
                    span: pattern.span,
                }],
            })
        }
        // ---- vector: out of domain (TD-002 trigger family — the §1
        // out-of-domain declaration, fail-closed here) ----
        StxDatum::Vector(_) => Err(ExpandError::new(
            "vector not can appear in pattern position(TD-002 trigger-gated out of domain -- match-design §1 out of domain maintained)",
            pattern.span,
        )),
        // ---- list forms: empty / or-marker / pair destructuring ----
        StxDatum::List(items) => {
            if items.is_empty() {
                // `()` written as an empty list in the S-expr face — the
                // same nil-pattern row (the M-1 corpus contract renders the
                // nil skin as an empty list datum).
                return Ok(Analysis {
                    test: Some(app(syms.is_nil, vec![path.expr.clone()], pattern.span)),
                    binds: Vec::new(),
                });
            }
            if items.len() == 1 {
                return Err(ExpandError::new(
                    "pattern list form: binary destructuring (p q) / empty pattern () / or tag (or p q ...) -- single-element grouping is not an intermediate form(target face by Reader resolution)",
                    pattern.span,
                ));
            }
            // or-marker: ≥3 elements with the reserved head `or`.
            if items.len() >= 3 {
                if let Some(head_sym) = items[0].datum.as_symbol() {
                    if table.name(head_sym) == "or" {
                        return analyze_or(&items[1..], path, syms, table, pattern.span);
                    }
                }
            }
            if items.len() > 2 {
                return Err(ExpandError::new(
                    "at most two elements inside pattern parentheses ((p, q) -- right not nested prevents infinite types, match-design §3.0 ruling 2)",
                    pattern.span,
                ));
            }
            // Binary pair destructuring: (p q) → sub-analysis at head/tail.
            let head_path = Path {
                key: format!("{}h", path.key),
                expr: app(syms.head, vec![path.expr.clone()], pattern.span),
            };
            let tail_path = Path {
                key: format!("{}t", path.key),
                expr: app(syms.tail, vec![path.expr.clone()], pattern.span),
            };
            let left = analyze_pattern(&items[0], &head_path, syms, table)?;
            let right = analyze_pattern(&items[1], &tail_path, syms, table)?;
            let mut operands = vec![app(syms.is_pair, vec![path.expr.clone()], pattern.span)];
            if let Some(t) = left.test.clone() {
                operands.push(t);
            }
            if let Some(t) = right.test.clone() {
                operands.push(t);
            }
            let mut binds = left.binds;
            binds.extend(right.binds);
            Ok(Analysis {
                test: Some(and_form(operands, pattern.span, syms)),
                binds,
            })
        }
    }
}

/// or-marker analysis: `(or a1 a2 ...)` at `path` (the §3.2 closed-bound or
/// row + the r122 binding-map identity ruling — name AND path must be
/// identical across alternatives; any always-true alternative makes the
/// whole or always-true).
fn analyze_or(
    alternatives: &[Stx],
    path: &Path,
    syms: &Syms,
    table: &mut SymbolTable,
    or_span: Span,
) -> Result<Analysis, ExpandError> {
    let mut results = Vec::with_capacity(alternatives.len());
    for alt in alternatives {
        results.push(analyze_pattern(alt, path, syms, table)?);
    }
    // Binding-map identity: the ordered (name, path-key) pairs must be
    // identical across alternatives — the first mismatch carries the
    // diagnostic (match-design §7 open question 1: point at the differing
    // alternative — diagnostic precision).
    let reference: Vec<(&str, &str)> = results[0]
        .binds
        .iter()
        .map(|b| (b.name_str.as_str(), b.key.as_str()))
        .collect();
    for (i, r) in results.iter().enumerate().skip(1) {
        let current: Vec<(&str, &str)> = r
            .binds
            .iter()
            .map(|b| (b.name_str.as_str(), b.key.as_str()))
            .collect();
        if current != reference {
            return Err(ExpandError::new(
                "or pattern binding set mismatch: each alternative pattern's bindings (names and destructuring positions) must be identical (match-design §3.2 + r122 path identity ruling)",
                alternatives[i].span,
            ));
        }
    }
    let first_binds = std::mem::take(&mut results[0].binds);
    // Any no-test alternative ⇒ the or is always-true.
    if results.iter().any(|r| r.test.is_none()) {
        return Ok(Analysis {
            test: None,
            binds: first_binds,
        });
    }
    let tests: Vec<Stx> = results
        .into_iter()
        .map(|mut r| r.test.take().expect("no-test case handled above"))
        .collect();
    Ok(Analysis {
        test: Some(or_form(tests, or_span, syms)),
        binds: first_binds,
    })
}

/// Duplicate-binding check at arm level (one pattern may not bind the same
/// name twice — Rust-shaped fail-closed; multi-binding let would silently
/// shadow without this).
fn check_duplicates(binds: &[Bind]) -> Result<(), ExpandError> {
    for (i, b) in binds.iter().enumerate() {
        if binds[..i].iter().any(|p| p.name == b.name) {
            return Err(ExpandError::new(
                format!(
                    "duplicate pattern binding: `{}` (cannot rebind within the same pattern)",
                    b.name_str
                ),
                b.span,
            ));
        }
    }
    Ok(())
}

// ---------------------------------------------------------------------------
// Construction helpers (the product spine — spans from the arm/form being
// folded, empty scope sets: keyword dispatch is by name and global builtin
// references resolve through the empty-set global face; the let machinery
// injects the binding scopes during regular expansion)
// ---------------------------------------------------------------------------

fn with_binds(body: Stx, binds: &[Bind], span: Span, syms: &Syms) -> Stx {
    if binds.is_empty() {
        return body;
    }
    let_form(binds, body, span, syms)
}

fn let_form(binds: &[Bind], body: Stx, span: Span, syms: &Syms) -> Stx {
    // (let ((n1 p1) (n2 p2)) body)
    let mut binding_forms = Vec::with_capacity(binds.len());
    for b in binds {
        binding_forms.push(Stx::list(
            vec![syms.sym(b.name, b.span), b.path.clone()],
            b.span,
            ScopeSet::new(),
        ));
    }
    let group = Stx::list(binding_forms, span, ScopeSet::new());
    Stx::list(
        vec![syms.sym(syms.kw_let, span), group, body],
        span,
        ScopeSet::new(),
    )
}

fn if_form(cond: Stx, then: Stx, els: Stx, span: Span, syms: &Syms) -> Stx {
    Stx::list(
        vec![syms.sym(syms.kw_if, span), cond, then, els],
        span,
        ScopeSet::new(),
    )
}

fn and_form(operands: Vec<Stx>, span: Span, syms: &Syms) -> Stx {
    if operands.len() == 1 {
        return operands.into_iter().next().expect("len checked");
    }
    let mut items = Vec::with_capacity(operands.len() + 1);
    items.push(syms.sym(syms.kw_and, span));
    items.extend(operands);
    Stx::list(items, span, ScopeSet::new())
}

fn or_form(operands: Vec<Stx>, span: Span, syms: &Syms) -> Stx {
    if operands.len() == 1 {
        return operands.into_iter().next().expect("len checked");
    }
    let mut items = Vec::with_capacity(operands.len() + 1);
    items.push(syms.sym(syms.kw_or, span));
    items.extend(operands);
    Stx::list(items, span, ScopeSet::new())
}

fn app(head: Symbol, args: Vec<Stx>, span: Span) -> Stx {
    let mut items = Vec::with_capacity(args.len() + 1);
    items.push(Stx::symbol(head, span, ScopeSet::new()));
    items.extend(args);
    Stx::list(items, span, ScopeSet::new())
}

fn fallback_call(syms: &Syms, span: Span) -> Stx {
    // (error "match failed: no arm matched") — the §4 defensive runtime fallback (the
    // `error` builtin is the designed carrier; M-3's exhaustiveness
    // diagnostics reduce its reachability).
    app(
        syms.error,
        vec![Stx::literal(
            StxLiteral::Str(std::rc::Rc::from("match failed: no arm matched")),
            span,
            ScopeSet::new(),
        )],
        span,
    )
}

fn true_stx(span: Span) -> Stx {
    Stx::literal(StxLiteral::Bool(true), span, ScopeSet::new())
}

//! syntax-rules macro definitions for derived keywords (r101 / 171-c — derived keywords fully
//! implemented via supplementary S-expression extension macros).
//!
//! **Architectural positioning**: seven of the eight sugars (when/unless/and/or/let\*/cond/while)
//! migrate from built-in Rust transformers (the hardcoded derivation arms in `sugar.rs`) to
//! **real syntax-rules macros** — the definitions are carried as S-expression source (the single
//! source being the programmatic Stx constructions in this file — the E6 replacement of the retired inline S-expr text sources), consumed by [`SyntaxRules::parse`]
//! and registered as [`TransformerKind::Derived`] (form validators + macro expansion).
//! `letrec` stays a built-in transformer: its nil arguments, repeated once per binding
//! (`((fn (f...) ...) nil nil ...)`), are **inexpressible** on the depth-1 ellipsis surface —
//! the same boundary family as TD-005 (nested ellipsis / syntax-parse), honestly registered.
//!
//! **Shape-fidelity contract** (macro templates bit-for-bit aligned with the original derivation
//! arms in `sugar.rs` — zero drift at the CoreExpr level): the E1-β parity suite (seed vs
//! self-hosting expander) plus the full 1141-test suite serve as the acceptance net; the `loop`
//! introduced identifier of `while` goes through macro-hygiene α renaming (the same `$hyg$N`
//! mechanism as the original `fresh_symbol` — a constant identical mapping within a single
//! instantiation).
//!
//! **Error-message contract** (zero drift on the negative-case assertion surface): the form
//! validators (`validator_for` in this file) keep every negative-case message of the original
//! hardcoded arms — the "macro 'X' expansion failed:" prefix is uniformly wrapped by the
//! expansion driver (`try_macro_step`), flowing the same way as the original Builtin path.
//!
//! **krf-side reconciliation** (production path): the desugar-\* function family in
//! `expander.krf` stays untouched — the shape contract (bit-for-bit identical at the CoreExpr
//! level) makes it the parity mirror of this macro path (verified bidirectionally by the E1-β
//! suite); migrating the production path to macros is future evolution (trigger-based: a
//! same-source migration once the krf engine gains compound-ellipsis completion — registered
//! in the capability-boundary note of 03-macro-system).

use std::rc::Rc;

use kerf_span::Span;
use kerf_syntax::{Phase, ScopeSet, Stx, StxDatum, StxLiteral, SymbolTable};

use crate::macro_sys::SyntaxRules;

/// Signature of derived-keyword form validators (carrier of the negative-case message contract).
pub(crate) type ValidateFn = fn(&[Stx]) -> Result<(), String>;

/// Derived-keyword macro definition sources (single S-expression source — key = sugar head name).
///
/// Template discipline: every introduced symbol is a keyword (`if`/`do`/`fn`/`assign`/`let`/
/// `letrec`/`nil`/`true`/`false`/ recursive sugar names) — keywords are exempt from α renaming
/// (`is_core_keyword`); the only non-keyword introduction is `loop` of `while`
/// (the hygiene subject of α renaming — same mechanism and same name surface as the original
/// implementation).
/// Programmatic Stx construction helpers (the E6 close-out replacement of
/// the inline S-expr text sources — r154 / 224-a, s-expr-removal-plan §6
/// exit condition 2: the classic S-expr Reader's last production consumer
/// was these `read_program` parses; the macro-definition data now lives as
/// Rust-constructed syntax objects, datum-identical to the text-parsed
/// originals: bare `true`/`false`/`nil` were classified by the classic
/// lexer as Bool/Nil **literals** (lexer.rs:351-358 — verified against the
/// pre-deletion git history), every other word is a plain symbol; the
/// empty ScopeSet + dummy Span match the Reader-produced originals on the
/// fields the macro machinery consumes).
fn s(name: &str, table: &mut SymbolTable) -> Stx {
    Stx {
        datum: StxDatum::Symbol(table.intern(name)),
        span: Span::dummy(),
        scopes: ScopeSet::new(),
        phase: Phase::Runtime,
        uniform_tag: None,
    }
}

/// Literal syntax object (true/false/nil in the templates — the classic
/// lexer's literal classification, preserved datum-identically).
fn lit(l: StxLiteral) -> Stx {
    Stx {
        datum: StxDatum::Literal(l),
        span: Span::dummy(),
        scopes: ScopeSet::new(),
        phase: Phase::Runtime,
        uniform_tag: None,
    }
}

/// List syntax object.
fn lst(items: Vec<Stx>) -> Stx {
    Stx {
        datum: StxDatum::List(Rc::new(items)),
        span: Span::dummy(),
        scopes: ScopeSet::new(),
        phase: Phase::Runtime,
        uniform_tag: None,
    }
}

/// `(syntax-rules (lit...) (pattern template)...)` form.
fn syntax_rules_form(literals: &[&str], clauses: Vec<(Stx, Stx)>, t: &mut SymbolTable) -> Stx {
    let mut items = vec![s("syntax-rules", t)];
    items.push(lst(literals.iter().map(|n| s(n, t)).collect()));
    for (pat, tpl) in clauses {
        items.push(lst(vec![pat, tpl]));
    }
    lst(items)
}

/// `(define-syntax NAME (syntax-rules ...))` wrapper — the bridge injection
/// shape (init_derived_one expects the 3-element define-syntax node).
fn define_syntax_form(name: &str, rules: Stx, t: &mut SymbolTable) -> Stx {
    lst(vec![s("define-syntax", t), s(name, t), rules])
}

/// The seven sugars' syntax-rules definitions (the single source — datum
/// trees mirroring the retired S-expr text sources clause for clause).
///
/// Template discipline (unchanged): every introduced symbol is a keyword
/// (`if`/`do`/`fn`/`assign`/`let`/`letrec`/`nil`/`true`/`false`/ recursive
/// sugar names) — keywords are exempt from α renaming (`is_core_keyword`);
/// the only non-keyword introduction is `loop` of `while` (the hygiene
/// subject of α renaming — same mechanism and same name surface as the
/// original implementation).
fn derived_rules_form(head_name: &str, t: &mut SymbolTable) -> Option<Stx> {
    let rules = match head_name {
        // ((_ test body ...) (if test (do body ...) nil))
        "when" => syntax_rules_form(
            &[],
            vec![(
                lst(vec![s("_", t), s("test", t), s("body", t), s("...", t)]),
                lst(vec![
                    s("if", t),
                    s("test", t),
                    lst(vec![s("do", t), s("body", t), s("...", t)]),
                    lit(StxLiteral::Nil),
                ]),
            )],
            t,
        ),
        // ((_ test body ...) (if test nil (do body ...)))
        "unless" => syntax_rules_form(
            &[],
            vec![(
                lst(vec![s("_", t), s("test", t), s("body", t), s("...", t)]),
                lst(vec![
                    s("if", t),
                    s("test", t),
                    lit(StxLiteral::Nil),
                    lst(vec![s("do", t), s("body", t), s("...", t)]),
                ]),
            )],
            t,
        ),
        // ((_) true) ((_ a) a) ((_ a b ...) (if a (and b ...) false))
        "and" => syntax_rules_form(
            &[],
            vec![
                (lst(vec![s("_", t)]), lit(StxLiteral::Bool(true))),
                (lst(vec![s("_", t), s("a", t)]), s("a", t)),
                (
                    lst(vec![s("_", t), s("a", t), s("b", t), s("...", t)]),
                    lst(vec![
                        s("if", t),
                        s("a", t),
                        lst(vec![s("and", t), s("b", t), s("...", t)]),
                        lit(StxLiteral::Bool(false)),
                    ]),
                ),
            ],
            t,
        ),
        // ((_) false) ((_ a) a) ((_ a b ...) (if a true (or b ...)))
        "or" => syntax_rules_form(
            &[],
            vec![
                (lst(vec![s("_", t)]), lit(StxLiteral::Bool(false))),
                (lst(vec![s("_", t), s("a", t)]), s("a", t)),
                (
                    lst(vec![s("_", t), s("a", t), s("b", t), s("...", t)]),
                    lst(vec![
                        s("if", t),
                        s("a", t),
                        lit(StxLiteral::Bool(true)),
                        lst(vec![s("or", t), s("b", t), s("...", t)]),
                    ]),
                ),
            ],
            t,
        ),
        // ((_ () body ...) (do body ...))
        // ((_ (first rest ...) body ...) (let (first) (let* (rest ...) body ...)))
        "let*" => syntax_rules_form(
            &[],
            vec![
                (
                    lst(vec![s("_", t), lst(vec![]), s("body", t), s("...", t)]),
                    lst(vec![s("do", t), s("body", t), s("...", t)]),
                ),
                (
                    lst(vec![
                        s("_", t),
                        lst(vec![s("first", t), s("rest", t), s("...", t)]),
                        s("body", t),
                        s("...", t),
                    ]),
                    lst(vec![
                        s("let", t),
                        lst(vec![s("first", t)]),
                        lst(vec![
                            s("let*", t),
                            lst(vec![s("rest", t), s("...", t)]),
                            s("body", t),
                            s("...", t),
                        ]),
                    ]),
                ),
            ],
            t,
        ),
        // Clauses in order: the else family (including the single-element
        // bare else — shape-faithful to the original implementation's
        // "(else) → else symbol") → three single-clause shapes → three
        // recursive shapes. else is a literal.
        "cond" => syntax_rules_form(
            &["else"],
            vec![
                // ((_ (else)) else)
                (lst(vec![s("_", t), lst(vec![s("else", t)])]), s("else", t)),
                // ((_ (else body) rest ...) body)
                (
                    lst(vec![
                        s("_", t),
                        lst(vec![s("else", t), s("body", t)]),
                        s("rest", t),
                        s("...", t),
                    ]),
                    s("body", t),
                ),
                // ((_ (else b1 b2 ...) rest ...) (do b1 b2 ...))
                (
                    lst(vec![
                        s("_", t),
                        lst(vec![s("else", t), s("b1", t), s("b2", t), s("...", t)]),
                        s("rest", t),
                        s("...", t),
                    ]),
                    lst(vec![s("do", t), s("b1", t), s("b2", t), s("...", t)]),
                ),
                // ((_ (test)) (if test test nil))
                (
                    lst(vec![s("_", t), lst(vec![s("test", t)])]),
                    lst(vec![
                        s("if", t),
                        s("test", t),
                        s("test", t),
                        lit(StxLiteral::Nil),
                    ]),
                ),
                // ((_ (test body)) (if test body nil))
                (
                    lst(vec![s("_", t), lst(vec![s("test", t), s("body", t)])]),
                    lst(vec![
                        s("if", t),
                        s("test", t),
                        s("body", t),
                        lit(StxLiteral::Nil),
                    ]),
                ),
                // ((_ (test b1 b2 ...)) (if test (do b1 b2 ...) nil))
                (
                    lst(vec![
                        s("_", t),
                        lst(vec![s("test", t), s("b1", t), s("b2", t), s("...", t)]),
                    ]),
                    lst(vec![
                        s("if", t),
                        s("test", t),
                        lst(vec![s("do", t), s("b1", t), s("b2", t), s("...", t)]),
                        lit(StxLiteral::Nil),
                    ]),
                ),
                // ((_ (test) rest ...) (if test test (cond rest ...)))
                (
                    lst(vec![
                        s("_", t),
                        lst(vec![s("test", t)]),
                        s("rest", t),
                        s("...", t),
                    ]),
                    lst(vec![
                        s("if", t),
                        s("test", t),
                        s("test", t),
                        lst(vec![s("cond", t), s("rest", t), s("...", t)]),
                    ]),
                ),
                // ((_ (test body) rest ...) (if test body (cond rest ...)))
                (
                    lst(vec![
                        s("_", t),
                        lst(vec![s("test", t), s("body", t)]),
                        s("rest", t),
                        s("...", t),
                    ]),
                    lst(vec![
                        s("if", t),
                        s("test", t),
                        s("body", t),
                        lst(vec![s("cond", t), s("rest", t), s("...", t)]),
                    ]),
                ),
                // ((_ (test b1 b2 ...) rest ...) (if test (do b1 b2 ...) (cond rest ...)))
                (
                    lst(vec![
                        s("_", t),
                        lst(vec![s("test", t), s("b1", t), s("b2", t), s("...", t)]),
                        s("rest", t),
                        s("...", t),
                    ]),
                    lst(vec![
                        s("if", t),
                        s("test", t),
                        lst(vec![s("do", t), s("b1", t), s("b2", t), s("...", t)]),
                        lst(vec![s("cond", t), s("rest", t), s("...", t)]),
                    ]),
                ),
            ],
            t,
        ),
        // ((_ test body ...)
        //  (letrec ((loop (fn () (if test (do body ... (loop)) nil)))) (loop)))
        // loop = an introduced identifier → macro-hygiene α renaming (same base name maps
        // identically within one instantiation — the three occurrences [binding / self-call /
        // outer call] agree; same `$hyg$N` name surface as the original fresh_symbol). letrec
        // stays a built-in transformer (the nil-fill boundary).
        "while" => syntax_rules_form(
            &[],
            vec![(
                lst(vec![s("_", t), s("test", t), s("body", t), s("...", t)]),
                lst(vec![
                    s("letrec", t),
                    lst(vec![lst(vec![
                        s("loop", t),
                        lst(vec![
                            s("fn", t),
                            lst(vec![]),
                            lst(vec![
                                s("if", t),
                                s("test", t),
                                lst(vec![
                                    s("do", t),
                                    s("body", t),
                                    s("...", t),
                                    lst(vec![s("loop", t)]),
                                ]),
                                lit(StxLiteral::Nil),
                            ]),
                        ]),
                    ])]),
                    lst(vec![s("loop", t)]),
                ]),
            )],
            t,
        ),
        _ => return None,
    };
    Some(define_syntax_form(head_name, rules, t))
}

/// The seven sugars' `(define-syntax ...)` forms (the bridge injection
/// single source — the E6 replacement of the text-source export; the
/// bootstrap expander bridge consumes these datum trees directly, no
/// Reader parse involved).
pub fn derived_definition_forms(table: &mut SymbolTable) -> Vec<(String, Stx)> {
    const HEADS: &[&str] = &["when", "unless", "and", "or", "let*", "cond", "while"];
    HEADS
        .iter()
        .map(|h| {
            let form = derived_rules_form(h, table)
                .unwrap_or_else(|| panic!("derived head `{h}` must construct"));
            ((*h).to_string(), form)
        })
        .collect()
}

/// Constructs the macro rules for the given sugar head (lazily once per
/// expansion context — cached via the transformer table after
/// registration). Unregistered heads (including `letrec`, which stays
/// built-in) return `None`.
pub(crate) fn parse_derived_rules(head_name: &str, table: &mut SymbolTable) -> Option<SyntaxRules> {
    // E6 close-out: the rules are programmatic Stx constructions (the
    // datum-identical replacement of the retired text sources — the
    // classic Reader parse is gone); take the third element of
    // (define-syntax NAME RULES).
    let form = derived_rules_form(head_name, table)?;
    let items = form.datum.as_list()?;
    if items.len() != 3 {
        return None;
    }
    let rules_form = items.get(2)?;
    SyntaxRules::parse(rules_form).ok()
}

/// Form validators (error-message contract retained — verbatim identical to the original
/// negative-case surface in sugar.rs).
///
/// Validation first, macro expansion after (the `TransformerKind::Derived` application order):
/// a validator error is a transformer error (wrapped by the driver with the "macro 'X' expansion
/// failed:" prefix — same flow as the original Builtin errors); once validation passes the macro
/// pattern must match (the pattern set is completely aligned with the validator shape surface —
/// see each head's comments).
pub(crate) fn validator_for(head_name: &str) -> Option<ValidateFn> {
    match head_name {
        // Pattern set covers all shapes (any argument arity is legal) — no negative-case surface
        "and" | "or" => None,
        "when" => Some(validate_when),
        "unless" => Some(validate_unless),
        "while" => Some(validate_while),
        "let*" => Some(validate_let_star),
        "cond" => Some(validate_cond),
        _ => None,
    }
}

/// `(when)`/`(unless)`/`(while)` zero-argument negative cases (original messages kept verbatim).
fn validate_when(args: &[Stx]) -> Result<(), String> {
    if args.is_empty() {
        return Err("when form: (when condition body...)".to_string());
    }
    Ok(())
}

fn validate_unless(args: &[Stx]) -> Result<(), String> {
    if args.is_empty() {
        return Err("unless form: (unless condition body...)".to_string());
    }
    Ok(())
}

fn validate_while(args: &[Stx]) -> Result<(), String> {
    if args.is_empty() {
        return Err("while form: (while condition body...)".to_string());
    }
    Ok(())
}

/// `(let*)` arity negative case + `(let* 1 1)` non-list binding-group negative case (original
/// messages kept verbatim). Shape validation of binding pairs is **delegated through template
/// derivation** to the inner `let` core form (`(let ((first)) ...)` — isomorphic to the
/// degradation chain of the original implementation: `(let* ((x)) 1)` reports the inner let
/// binding error).
fn validate_let_star(args: &[Stx]) -> Result<(), String> {
    if args.len() < 2 {
        return Err("let* form: (let* ((name value)...) body...)".to_string());
    }
    if args[0].datum.as_list().is_none() {
        return Err("let* binding group must be a list".to_string());
    }
    Ok(())
}

/// `(cond)` zero-clause + `(cond 1)`/`(cond ())` clause-not-a-non-empty-list negative cases
/// (original messages kept verbatim). The empty-list test position of `(cond (()))` is delegated
/// downstream through template derivation (empty-list expression error — same flow as the
/// original implementation).
fn validate_cond(args: &[Stx]) -> Result<(), String> {
    if args.is_empty() {
        return Err("cond requires at least one clause".to_string());
    }
    for clause in args {
        let non_empty_list = clause
            .datum
            .as_list()
            .map(|l| !l.is_empty())
            .unwrap_or(false);
        if !non_empty_list {
            return Err("cond clause must be a non-empty list".to_string());
        }
    }
    Ok(())
}

// ---------------------------------------------------------------------------
// Space-affiliation declaration section (r66 / 123-a — lang-design 24 v2.0 unified two-sided
// system; this module = an internal part of the kerf-expander domain (no independent main
// types — affiliation follows the crate declaration section))
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    /// Constructibility + parseability of the seven sugars' programmatic
    /// rule forms + non-empty clauses (structural smoke test — per head;
    /// the E6 form of the retired text-source parse test).
    #[test]
    fn derived_sources_parse_cleanly() {
        let mut table = SymbolTable::new();
        crate::macro_sys::BuiltinTransformers::init_markers(&mut table);
        crate::expander::init_keywords(&mut table);
        for (name, _form) in derived_definition_forms(&mut table) {
            let rules = parse_derived_rules(&name, &mut table)
                .unwrap_or_else(|| panic!("{} definition should can parse", name));
            assert!(rules.clause_len() >= 1, "{} clause should non-empty", name);
        }
    }
}

//! Expansion of the 9 core forms (stage0.md §19.2 core-form dispatch; split from expander.rs
//! per TD-012).
//!
//! Responsibility boundary (sop.md §11 interface isolation):
//! - **this module**: purely structural dispatch after keyword lookup and implementation of
//!   the 9 core forms (fn/if/assign/define/do/module/quote/define-syntax + import/export
//!   position validation) + the function-body define hoisting path + **the r49
//!   declaration-layer item producers** (`expand_define_item`/`expand_require_item`/
//!   `expand_module_item` — consumed by the driver's `classify_item_form` item
//!   classification);
//! - `expander` (driver): entry dispatch (macro → sugar → core form → function application)
//!   and shared types (`ExpandCtxt`/`ExpandError`) + item classification;
//! - `sugar`: built-in syntactic sugar transformers (§3.2 derivation table);
//! - `macro_sys`/`phase`: transformer machinery and phase driving (unchanged).
//!
//! Core-form expansion never expands the form itself, only recursively expands child nodes
//! (§19.2 skeleton rule 1).
//!
//! **r49 / E5 S3 declaration-layer arm (22 §17 D59)**: define/require/module in expression
//! position are structurally rejected at this module's dispatch points (E0003/E0018/E0023
//! messages — `CoreExpr` cannot represent declarations; position discipline moves from a
//! compile-time check to expansion-time type unrepresentability).

use std::rc::Rc;

use kerf_core::{Capability, CoreExpr, LiteralValue, ModuleItem};
use kerf_span::Span;
use kerf_syntax::{Keyword, ScopeSet, Stx, StxDatum, SymbolTable};

use crate::expander::{
    expand_form, expand_program, is_head_keyword, keyword_stx, make_setbang, nil_stx, ExpandCtxt,
    ExpandError,
};
use crate::macro_sys::{SyntaxRules, Transformer, TransformerKind};

/// r165 / 236-c (variadic-rest-design.md D2-a/D3-b): the parsed parameter
/// list — fixed params plus the optional rest binding. A named alias keeps
/// `parse_params` / `parse_rest_param` under the clippy type-complexity bar.
type ParsedParams = (
    Vec<(kerf_syntax::Symbol, ScopeSet)>,
    Option<(kerf_syntax::Symbol, ScopeSet)>,
);

/// Core-form dispatch (keyword → corresponding expander; purely structural dispatch, no macro
/// semantics).
pub(crate) fn expand_core_form(
    kw: Keyword,
    stx: &Stx,
    items: &[Stx],
    ctx: &mut ExpandCtxt,
) -> Result<Rc<CoreExpr>, ExpandError> {
    match kw {
        Keyword::Fn => expand_lambda(stx, items, ctx),
        Keyword::If => expand_if(stx, items, ctx),
        // r50-β / D61 (direct let mapping): `let` leaves the sugar table and goes straight to
        // the core form — single binding maps directly to `CoreExpr::Let` (multi-binding
        // staging preserves parallel semantics, empty binding becomes a do chain;
        // 22 §17.3 D61 spec); the Apply[Fn] sugar view is retired
        Keyword::Let => expand_let(stx, items, ctx),
        Keyword::Assign => expand_setbang(stx, items, ctx),
        // r49 declaration-layer arm: define in expression position is structurally rejected
        // (E0003 spec — message kept verbatim from the original ir.rs lowering; legal
        // positions = the item classifier and the function-body-head hoisting path, so this
        // arm is unreachable for legal programs)
        Keyword::Define => Err(ExpandError::new(
            "define is only allowed at the top level or at the head of a function body (a define wrapped in a do/expression position is illegal -- place nested defines at the body head)",
            stx.span,
        )),
        Keyword::Do => expand_begin(stx, items, ctx, true),
        // r49 declaration-layer arm: module in expression position is structurally rejected
        // (E0023 new diagnostic code — previously unchecked [compiled silently inline];
        // symmetric with the import/export E0002 message shape: module is a compilation-unit
        // organization form, not an expression)
        Keyword::Module => Err(ExpandError::new(
            "module may only appear at the program top level or module body direct element position (current position is an expression --module is a compilation-unit organizational form, not an expression; 22 §17 D59)",
            stx.span,
        )),
        Keyword::Require => Err(ExpandError::new(
            "require position violation: require legal position = program top level or module body direct element (current position is inside an expression subtree -- require is a declaration, not an expression; deep audit D3 ruling",
            stx.span,
        )),
        Keyword::Quote => expand_quote(stx, items, ctx),
        Keyword::Perform => expand_perform(stx, items, ctx),
        Keyword::Handle => expand_handle(stx, items, ctx),
        // r136 / 206-b (TD-033 — handle-multi-arm-design §8 D12): the
        // S-expr-face group-install core form head
        Keyword::HandleGroup => expand_handle_group(stx, items, ctx),
        // D4 (effect-language-design): resume is not a standalone primitive — desugared at
        // expansion time into a `(κ v)` Apply (the call shape of a continuation value,
        // reusing the application machinery)
        Keyword::Resume => expand_resume(stx, items, ctx),
        // r122 / 192-a — match implementation batch M-2: the D2 skin-dictionary
        // seventh mapping. A pure skin (principle 31): the desugar lowers the M-1
        // intermediate form into a cond/let chain of existing core forms + builtin
        // applications, then re-enters the regular expansion (match-design.md v1.1
        // §3 — the §3 semantic table in full; zero new primitives).
        Keyword::Match => crate::match_desugar::expand_match(stx, items, ctx),
        Keyword::Import | Keyword::Export => Err(ExpandError::new(
            "import/export may only appear as a direct program top-level element or in module header zone (current position is an expression/mid-body --import is an organizational declaration, not an expression; 22 §15 D47)",
            stx.span,
        )),
        // r137 / 207-c (TD-026 language-surface window,
        // ffi-language-surface-design §3/D2): extern in the expression
        // domain is structurally rejected — the expander-level backstop
        // (the top-level legal position is implemented by the driver's
        // pre-expansion stripping; anything that survives to here is an
        // expression-position or macro-produced occurrence — fail-closed
        // with the position-violation family, the require/import
        // precedent's dual-layer discipline).
        Keyword::Extern => Err(ExpandError::new(
            "extern declaration position violation: only program top level direct element position legal(current position is expression/mid-body --extern is FFI declaration non-expression; ffi-language-surface-design §3 D2)",
            stx.span,
        )),
        Keyword::LetRec
        | Keyword::LetStar
        | Keyword::Cond
        | Keyword::And
        | Keyword::Or
        | Keyword::When
        | Keyword::Unless
        | Keyword::While => {
            // Handled by the builtin_transformer channel (this branch is unreachable —
            // defensive explicit failure)
            Err(ExpandError::new(
                "syntactic sugar forms should go through the builtin transformer (internal invariant broken)",
                stx.span,
            ))
        }
        Keyword::Else => Err(ExpandError::new(
            "else may only appear in cond the clause's test position",
            stx.span,
        )),
        Keyword::DefineSyntax => expand_define_syntax(stx, items, ctx),
        Keyword::SyntaxRules => Err(ExpandError::new(
            "syntax-rules may only appear in define-syntax internal",
            stx.span,
        )),
    }
}

// ---- Core-form implementations ----

fn expand_lambda(
    stx: &Stx,
    items: &[Stx],
    ctx: &mut ExpandCtxt,
) -> Result<Rc<CoreExpr>, ExpandError> {
    if items.len() < 3 {
        return Err(ExpandError::new(
            "fn form: (fn (argument...) body...)",
            stx.span,
        ));
    }
    // TD-004/r13 (Racket add-scope): binding forms allocate a fresh scope and deep-inject it
    // into the binders and all body forms — references inside the body therefore carry the
    // binding scope, letting the compiler/eval resolve them by (name, scopes ⊆) subset
    // matching (max-cardinality resolves shadowing). Injection precedes body expansion:
    // macro-product scopes ⊇ use-site ⊇ {fresh}, preserving free-identifier pass-through
    // (03 §2.4); α renaming ($hyg$N) remains the second line of hygiene defense.
    let fresh = ctx.fresh_scope();
    let mut param_stx = items[1].clone();
    param_stx.add_scope_to_all(fresh);
    let mut body_forms: Vec<Stx> = items[2..].to_vec();
    for b in &mut body_forms {
        b.add_scope_to_all(fresh);
    }
    let params_and_rest = parse_params(&param_stx, &ctx.table)?;
    let (names, param_scopes): (Vec<_>, Vec<_>) = params_and_rest.0.into_iter().unzip();
    let rest = params_and_rest.1;
    let body = expand_body(&body_forms, ctx)?;
    Ok(Rc::new(CoreExpr::Fn {
        params: names,
        param_scopes,
        rest,
        body,
        span: stx.span,
    }))
}

/// r165 / 236-c (variadic-rest-design.md D2-a/D3-b): the parsed parameter
/// list — fixed params plus the optional rest binding. The Reader emits the
/// rest parameter into the signature list as the marker symbol `...`
/// followed by the binding name (`(f a b ... rest)`); this is the single
/// point where the marker is consumed. No marker = fixed arity (the
/// pre-r165 corpus is untouched).
fn parse_params(
    param_stx: &Stx,
    names: &kerf_syntax::SymbolTable,
) -> Result<ParsedParams, ExpandError> {
    let list = param_stx
        .datum
        .as_list()
        .ok_or_else(|| ExpandError::new("fn arguments must be a symbol list", param_stx.span))?;
    let mut params = Vec::with_capacity(list.len());
    let rest: Option<(kerf_syntax::Symbol, ScopeSet)> = None;
    for p in list {
        match p.datum.as_symbol() {
            Some(s) => {
                // r165 / 236-c: the rest-parameter marker — the binding name
                // is the NEXT element and the marker must be terminal. The
                // loop RETURNS at the marker (a second marker is unreachable
                // here — the terminal law rejects it inside parse_rest_param).
                if names.name(s) == "..." {
                    return parse_rest_param(list, p, &params, names);
                }
                // A3 hygiene rule ([06-operational-semantics §2]): same-named parameters
                // may appear only once per level. The expansion-time check is the common
                // upstream of both execution paths (eval/VM) — single-point defense.
                if params
                    .iter()
                    .any(|(n, _): &(kerf_syntax::Symbol, ScopeSet)| *n == s)
                {
                    return Err(ExpandError::new(
                        "fn duplicate argument names (a formal parameter name may only appear once)",
                        p.span,
                    ));
                }
                // The binding scope set = the injected binder symbol's scopes (TD-004).
                params.push((s, p.scopes.clone()));
            }
            None => {
                return Err(ExpandError::new(
                    "fn argument must be a symbol (destructuring parameters not supported)",
                    p.span,
                ))
            }
        }
    }
    Ok((params, rest))
}

/// The rest parameter tail: the marker `...` at index `i` must be followed
/// by exactly one binding symbol and nothing else (D1-b terminal law —
/// the Reader already enforces it; this is the expansion-time defense for
/// programmatically-constructed Stx).
fn parse_rest_param(
    list: &[Stx],
    marker: &Stx,
    fixed: &[(kerf_syntax::Symbol, ScopeSet)],
    names: &kerf_syntax::SymbolTable,
) -> Result<ParsedParams, ExpandError> {
    let i = list
        .iter()
        .position(|p| std::ptr::eq(p, marker))
        .expect("marker comes from the list");
    let name_stx = list.get(i + 1).ok_or_else(|| {
        ExpandError::new(
            "fn rest parameter marker `...` must be followed by a binding name",
            marker.span,
        )
    })?;
    if list.len() != i + 2 {
        return Err(ExpandError::new(
            "the rest parameter must be the last parameter",
            marker.span,
        ));
    }
    let name = name_stx.datum.as_symbol().ok_or_else(|| {
        ExpandError::new("fn rest parameter name must be a symbol", name_stx.span)
    })?;
    // The marker itself is not a binding name — `(f ... ...)` (only
    // reachable via programmatically-constructed Stx; the Reader rejects
    // it at the source face).
    if names.name(name) == "..." {
        return Err(ExpandError::new(
            "fn rest parameter marker `...` must be followed by a binding name",
            name_stx.span,
        ));
    }
    // The A3 duplicate law covers the rest binding too (fixed ∪ rest).
    if fixed.iter().any(|(n, _)| *n == name) {
        return Err(ExpandError::new(
            "fn duplicate argument names (a formal parameter name may only appear once)",
            name_stx.span,
        ));
    }
    Ok((fixed.to_vec(), Some((name, name_stx.scopes.clone()))))
}

/// Function-body expansion: internal define hoisting (§19.2 pitfall 3).
/// `(define x e)... expr...` → `((lambda (x...) (begin (set! x e)... expr...)) nil...)`
fn expand_body(forms: &[Stx], ctx: &mut ExpandCtxt) -> Result<Rc<CoreExpr>, ExpandError> {
    // Split off the leading defines
    let mut defines: Vec<(kerf_syntax::Symbol, &Stx)> = Vec::new();
    let mut rest_idx = forms.len();
    for (i, f) in forms.iter().enumerate() {
        if is_head_keyword(f, ctx, Keyword::Define) {
            defines.push((define_name(f, ctx)?, f));
        } else {
            rest_idx = i;
            break;
        }
    }
    // define must sit at the head (any non-head define is an error, explicit failure — also
    // covering sequences with no leading defines)
    for f in &forms[rest_idx..] {
        if is_head_keyword(f, ctx, Keyword::Define) {
            return Err(ExpandError::new(
                "define must be at the head of a function body (subsequent define illegal)",
                f.span,
            ));
        }
    }
    // TD-014 (r24): early attribution for duplicate nested defines — the original path was
    // backstopped by duplicate lambda parameters constructed during hoisting (parse_params
    // reports "duplicate lambda parameter" — distorted attribution with the Span pointing
    // at the synthesized body-head node); here it is reported with a dedicated message and
    // the error Span = the define form itself at the second occurrence (semantically
    // equivalent to E6 early defense).
    let mut seen: Vec<kerf_syntax::Symbol> = Vec::with_capacity(defines.len());
    for (name, def) in &defines {
        if seen.contains(name) {
            return Err(ExpandError::new(
                "nested define duplicate binding (an inner variable name may only appear once)",
                def.span,
            ));
        }
        seen.push(*name);
    }
    if defines.is_empty() {
        // No defines: expression sequence
        let exprs: Result<Vec<Rc<CoreExpr>>, _> =
            forms.iter().map(|f| expand_form(f, ctx)).collect();
        let exprs = exprs?;
        return Ok(wrap_body(exprs, forms));
    }
    // Build the hoisted form
    let span = forms.first().map(|f| f.span).unwrap_or_default();
    let names: Vec<kerf_syntax::Symbol> = defines.iter().map(|(n, _)| *n).collect();
    let mut body_forms: Vec<Stx> = Vec::new();
    for (name, def) in &defines {
        // (set! name value)
        let value = define_value_stx(def, ctx)?;
        body_forms.push(make_setbang(*name, value, def.span));
    }
    body_forms.extend(forms[rest_idx..].iter().cloned());
    // ((lambda (names...) body...) nil...) — body forms laid out flat as the lambda tail
    let mut lambda_items: Vec<Stx> = vec![
        keyword_stx(ctx, Keyword::Fn),
        Stx::list(
            names
                .iter()
                .map(|n| Stx::symbol(*n, span, ScopeSet::new()))
                .collect(),
            span,
            ScopeSet::new(),
        ),
    ];
    lambda_items.extend(body_forms);
    let lambda_form = Stx::list(lambda_items, span, ScopeSet::new());
    // app = (lambda nil nil ...) — nil arguments laid out flat
    let mut app_items: Vec<Stx> = vec![lambda_form];
    for _ in names {
        app_items.push(nil_stx(span));
    }
    let app_form = Stx::list(app_items, span, ScopeSet::new());
    expand_form(&app_form, ctx)
}

fn wrap_body(exprs: Vec<Rc<CoreExpr>>, forms: &[Stx]) -> Rc<CoreExpr> {
    let span = forms.first().map(|f| f.span).unwrap_or_default();
    if exprs.len() == 1 {
        return exprs.into_iter().next().expect("single element");
    }
    make_do_let_chain(exprs, span)
}

/// Builds the do-desugaring Let chain (r45/E5 S3 structural arm D42 — 22 §14):
/// `(do e1 e2 ... en)` → `Let[do, e1, Let[do, e2, ... en]]`.
///
/// The constant name `"do"` (= the Symbol of `Keyword::Do`): a reserved name that user Vars
/// cannot reference (E0020 strict reserved word) — anti-hijacking is guaranteed by name
/// unreachability rather than a fresh scope; same-name shadowing across nested do chains is
/// harmless (the name is never referenced by a body). The empty-set binding scope =
/// name-base semantics (consistent with the hand-constructed CoreExpr tolerance path).
///
/// The compiler's discard mode (the body never references the binding name, always true)
/// emits `[value; Pop; body]` — **instruction-for-instruction identical** to the original
/// `Do` per-item compilation sequence (the strictest scope of e5-plan §3.2 S3 bytecode
/// parity).
fn make_do_let_chain(exprs: Vec<Rc<CoreExpr>>, span: Span) -> Rc<CoreExpr> {
    let mut it = exprs.into_iter().rev();
    let Some(mut acc) = it.next() else {
        // Empty do: nil literal (the PushNil-equivalent shape of the original empty Do)
        return Rc::new(CoreExpr::Literal {
            value: LiteralValue::Nil,
            span,
        });
    };
    // Constant name: the Do keyword Symbol (single source via the thread_local handle —
    // same intern-table entry as the surface keyword, zero new name surface)
    for e in it {
        acc = Rc::new(CoreExpr::Let {
            name: crate::expander::kw_symbol(&crate::expander::WORD_BEGIN),
            scopes: ScopeSet::new(),
            value: e,
            body: acc,
            span,
        });
    }
    acc
}

/// `(let ((name value)...) body...)` direct core-form mapping (r50-β / D61 — 22 §17.3).
///
/// Three shapes:
/// - **single binding** `(let ((x e)) b...)` → `CoreExpr::Let` (fresh scope injected into
///   binder and body — same discipline as `expand_lambda` TD-004; **the value position is
///   not injected** [outside the binding scope — parallel semantics: e cannot see x]);
/// - **multi-binding** `(let ((x e1) (y e2)) b...)` → **multi-binding staging**:
///   `Let[t0, e1', Let[t1, e2', Let[x, Var(t0), Let[y, Var(t1), b']]]]`
///   (all values evaluated before any binding — e₂ cannot see x; parallel semantics doubly
///   guaranteed by name isolation of the staging names + zero injection at value positions;
///   the D61 shape);
/// - **empty binding** `(let () b...)` → do chain (`make_do_let_chain`).
///
/// **Staging-name hygiene** (the constant `let$st{i}` name family + fresh scopes):
/// - binder `Let[t_i].scopes = {fresh_i}` (`fresh_i` = the new ScopeId allocated by this
///   expansion); reference `Var(t_i).scopes = {fresh_i}` (exact subset match);
/// - **anti-hijacking is guaranteed by the timing of fresh scopes**: the scope sets of
///   user-source symbols are already fixed before expansion (historical ScopeIds) and
///   physically cannot carry `fresh_i` (globally monotonically increasing) → user
///   references never mis-resolve onto staging bindings (more fundamental than the do
///   constant-name E0020 reserved-word scheme — scope unreachability; same-level
///   multi-bindings are mutually exclusive via the position indices `let$st0/1/...`,
///   same-named staging of nested lets is distinguished by scope set).
/// - `E0022` unbound-reference check: staging names are `Let` binding names (on the local
///   binding-collection register) — no false positives.
///
/// **Behavioral parity gate** (e5-plan §3.2 S3 gate taxonomy — shape-change arm):
/// Apply[Fn] closure call → inlined Let slot is a desugaring shape change, so the bytecode
/// sequence necessarily differs (`[PushClosure; e; Call 1]` → `[e; StoreLocal; b]`) — the
/// acceptance gate = behavioral parity + re-anchoring the golden bytecode snapshot (a
/// corpus shape change is legal in itself).
fn expand_let(stx: &Stx, items: &[Stx], ctx: &mut ExpandCtxt) -> Result<Rc<CoreExpr>, ExpandError> {
    if items.len() < 3 {
        // (let binding-group body...) needs at least three elements (including the let head
        // itself)
        return Err(ExpandError::new(
            "let form: (let ((name value)...) body...)",
            stx.span,
        ));
    }
    let binding_group = items[1]
        .datum
        .as_list()
        .ok_or_else(|| ExpandError::new("let binding group must be a list", items[1].span))?;
    // Parse binding pairs ((name value) two-element lists + symbol names — message surface
    // kept verbatim from the original desugar_let)
    let mut pairs: Vec<(&Stx, &Stx)> = Vec::with_capacity(binding_group.len());
    for b in binding_group {
        let pair = b.datum.as_list().filter(|p| p.len() == 2).ok_or_else(|| {
            ExpandError::new("let binding must be (name value) two-element list", b.span)
        })?;
        let name = pair[0]
            .datum
            .as_symbol()
            .ok_or_else(|| ExpandError::new("let binding name must be a symbol", pair[0].span))?;
        let _ = name; // symbolhood check (scope sets are carried by the Stx structure)
        pairs.push((&pair[0], &pair[1]));
    }
    let body_forms = &items[2..];
    let span = stx.span;

    // ---- Empty binding: (let () b...) → do chain (behaviorally equivalent to the original
    // zero-argument closure application) ----
    if pairs.is_empty() {
        let body: Result<Vec<Rc<CoreExpr>>, _> =
            body_forms.iter().map(|f| expand_form(f, ctx)).collect();
        return Ok(make_do_let_chain(body?, span));
    }

    // ---- Single binding: direct mapping to CoreExpr::Let (fresh scope injected into binder
    // + body) ----
    if pairs.len() == 1 {
        let (name_stx, value_stx) = pairs[0];
        let fresh = ctx.fresh_scope();
        let mut name_inj = (*name_stx).clone();
        name_inj.add_scope_to_all(fresh);
        let mut body_inj: Vec<Stx> = body_forms.to_vec();
        for b in &mut body_inj {
            b.add_scope_to_all(fresh);
        }
        let name = name_inj
            .datum
            .as_symbol()
            .expect("binding name verified to be a symbol above");
        let value = expand_form(value_stx, ctx)?;
        let body = expand_body(&body_inj, ctx)?;
        return Ok(Rc::new(CoreExpr::Let {
            name,
            scopes: name_inj.scopes.clone(),
            value,
            body,
            span,
        }));
    }

    // ---- Multi-binding: staging (the D61 shape) ----
    // Step 1: expand all values first (zero injection — value positions sit outside every
    // binding scope; the structural guarantee of parallel semantics: symbol references in
    // e_i physically cannot resolve to any binding of this level)
    let values: Result<Vec<Rc<CoreExpr>>, _> =
        pairs.iter().map(|(_, v)| expand_form(v, ctx)).collect();
    let values = values?;

    // Step 2: fresh allocation for the rebinding layer + body injection (a fresh scope per
    // binding name — references inside the body carry each fresh to match its binding;
    // value positions are already expanded and untouched by the injection)
    let bind_fresh: Vec<_> = (0..pairs.len()).map(|_| ctx.fresh_scope()).collect();
    let mut body_inj: Vec<Stx> = body_forms.to_vec();
    for b in &mut body_inj {
        for s in &bind_fresh {
            b.add_scope_to_all(*s);
        }
    }
    let body_core = expand_body(&body_inj, ctx)?;

    // Step 3: fresh scopes for the staging layer (the t_i binding scopes — the exact match
    // key where reference and binding share the set; the timing guarantee means user source
    // cannot carry them → anti-hijacking)
    let stash_fresh: Vec<_> = (0..pairs.len()).map(|_| ctx.fresh_scope()).collect();
    let stash_names: Vec<_> = (0..pairs.len())
        .map(|i| ctx.table.intern(&format!("let$st{}", i)))
        .collect();

    // Step 4: assemble the rebinding layer from the inside out: Let[x_i, Var(t_i), ...]
    let mut acc = body_core;
    for i in (0..pairs.len()).rev() {
        let (name_stx, _) = pairs[i];
        // Inject bind_fresh[i] into the binding-name symbol (same discipline as single
        // binding)
        let mut name_inj = (*name_stx).clone();
        name_inj.add_scope_to_all(bind_fresh[i]);
        let name = name_inj
            .datum
            .as_symbol()
            .expect("binding name verified to be a symbol above");
        // Staging reference: Var(t_i).scopes = {stash_fresh[i]} (the exact match key)
        let var_ref = Rc::new(CoreExpr::Var {
            name: stash_names[i],
            scopes: ScopeSet::from_iter_scopes([stash_fresh[i]]),
            span,
        });
        acc = Rc::new(CoreExpr::Let {
            name,
            scopes: name_inj.scopes.clone(),
            value: var_ref,
            body: acc,
            span,
        });
    }

    // Step 5: assemble the staging layer from the inside out: Let[t_i, e_i', ...]
    for i in (0..pairs.len()).rev() {
        acc = Rc::new(CoreExpr::Let {
            name: stash_names[i],
            scopes: ScopeSet::from_iter_scopes([stash_fresh[i]]),
            value: Rc::clone(&values[i]),
            body: acc,
            span,
        });
    }
    Ok(acc)
}

fn expand_if(stx: &Stx, items: &[Stx], ctx: &mut ExpandCtxt) -> Result<Rc<CoreExpr>, ExpandError> {
    if items.len() != 3 && items.len() != 4 {
        return Err(ExpandError::new(
            "if form: (if condition true branch [false branch])",
            stx.span,
        ));
    }
    let cond = expand_form(&items[1], ctx)?;
    let then_branch = expand_form(&items[2], ctx)?;
    let else_branch = if items.len() == 4 {
        expand_form(&items[3], ctx)?
    } else {
        Rc::new(CoreExpr::Literal {
            value: LiteralValue::Nil,
            span: stx.span,
        })
    };
    Ok(Rc::new(CoreExpr::If {
        cond,
        then_branch,
        else_branch,
        span: stx.span,
    }))
}

fn expand_setbang(
    stx: &Stx,
    items: &[Stx],
    ctx: &mut ExpandCtxt,
) -> Result<Rc<CoreExpr>, ExpandError> {
    if items.len() != 3 {
        return Err(ExpandError::new(
            "assign form: (assign name value)",
            stx.span,
        ));
    }
    let name = items[1]
        .datum
        .as_symbol()
        .ok_or_else(|| ExpandError::new("assign target must be a symbol", items[1].span))?;
    let value = expand_form(&items[2], ctx)?;
    Ok(Rc::new(CoreExpr::Assign {
        name,
        scopes: items[1].scopes.clone(),
        value,
        span: stx.span,
    }))
}

/// `(define name value)` item-position expansion (r49 D59 — `expand_define_item`: invoked
/// by the item classifier after the macro trampoline; function sugar expands the lambda form
/// directly instead of building a define wrapper and re-entering — error messages kept
/// verbatim from the original `expand_define`).
pub(crate) fn expand_define_item(
    stx: &Stx,
    items: &[Stx],
    ctx: &mut ExpandCtxt,
) -> Result<ModuleItem, ExpandError> {
    if items.len() < 3 {
        return Err(ExpandError::new(
            "define form: (define name value) or (define (name argument...) body...)",
            stx.span,
        ));
    }
    // Function sugar: (define (f x y) body...) → value = (fn (x y) body...) — body forms laid
    // out flat
    if let Some(flist) = items[1].datum.as_list() {
        if let Some(fname) = flist.first().and_then(|f| f.datum.as_symbol()) {
            let mut lambda_items: Vec<Stx> = vec![
                keyword_stx(ctx, Keyword::Fn),
                Stx::list(flist[1..].to_vec(), stx.span, ScopeSet::new()),
            ];
            lambda_items.extend(items[2..].iter().cloned());
            let lambda_form = Stx::list(lambda_items, stx.span, ScopeSet::new());
            let value = expand_form(&lambda_form, ctx)?;
            return Ok(ModuleItem::Define {
                name: fname,
                value,
                span: stx.span,
            });
        }
        return Err(ExpandError::new(
            "define function sugar first element must be a symbol",
            items[1].span,
        ));
    }
    let name = items[1]
        .datum
        .as_symbol()
        .ok_or_else(|| ExpandError::new("define target must be a symbol", items[1].span))?;
    if items.len() != 3 {
        return Err(ExpandError::new(
            "define value form must be a single expression (for function sugar use (define (name argument...) body...))",
            stx.span,
        ));
    }
    let value = expand_form(&items[2], ctx)?;
    Ok(ModuleItem::Define {
        name,
        value,
        span: stx.span,
    })
}

fn expand_begin(
    stx: &Stx,
    items: &[Stx],
    ctx: &mut ExpandCtxt,
    _toplevel: bool,
) -> Result<Rc<CoreExpr>, ExpandError> {
    // r45/D42: the do core form → Let-chain desugaring (CoreExpr::Do eliminated — the
    // surface keyword do remains, expansion product = Let chain [constant name "do"];
    // empty do → nil)
    if items.len() < 2 {
        return Ok(Rc::new(CoreExpr::Literal {
            value: LiteralValue::Nil,
            span: stx.span,
        }));
    }
    let body: Result<Vec<Rc<CoreExpr>>, _> =
        items[1..].iter().map(|f| expand_form(f, ctx)).collect();
    Ok(make_do_let_chain(body?, stx.span))
}

/// `(module name [(import ...)] [(export ...)] body...)` item-position expansion (r49 D59 —
/// `expand_module_item`: body forms classified recursively by item position [do-splice +
/// declaration-head dispatch], same rules as the program top level; header-region parsing
/// kept verbatim from the original `expand_module`).
pub(crate) fn expand_module_item(
    stx: &Stx,
    items: &[Stx],
    ctx: &mut ExpandCtxt,
) -> Result<ModuleItem, ExpandError> {
    if items.len() < 2 {
        return Err(ExpandError::new(
            "module form: (module name [(import ...)] [(export ...)] body...)",
            stx.span,
        ));
    }
    let name = items[1]
        .datum
        .as_symbol()
        .ok_or_else(|| ExpandError::new("module name must be a symbol", items[1].span))?;
    let mut imports = Vec::new();
    let mut exports = Vec::new();
    let mut body_start = 2;
    // Optional (import ...) and (export ...) header region (parsing kept verbatim from the
    // original expand_module — as-alias pair skipping + item symbol validation)
    while body_start < items.len() {
        if let Some(head) = items[body_start]
            .datum
            .as_list()
            .and_then(|l| l.first())
            .and_then(|h| h.datum.as_symbol())
        {
            let kw = Keyword::from_name(ctx.table.name(head));
            match kw {
                Some(Keyword::Import) => {
                    let list = items[body_start]
                        .datum
                        .as_list()
                        .expect("checked to be a list above");
                    // M2 (r40) R-N5 as-alias pair skipping: the as/str of
                    // `(import kerf-string as str)` do not enter imports (alias info is
                    // carried by the driver's Stx-layer collect_import_face — option C: zero
                    // new fields on the frozen CoreExpr surface; as is a contextual marker,
                    // not an N4 keyword).
                    // r134 / member-rename-design.md v1.0 §3 D5: a list item at the
                    // second-or-later position = the member selection list
                    // (`(import kerf-string (append))` — r50/D65, previously
                    // E0002-rejected in headers, both faces shared this scan);
                    // the module name was already pushed at the preceding
                    // position, so the list is skipped whole (the module-level
                    // import relation is maintained — selection = flat namespace
                    // hygiene, not module-relation pruning). Shape pre-check:
                    // every member must be a symbol (the rename triple's
                    // local/as/renamed are all symbols — natural pass; nested
                    // lists / non-symbol members keep the E0002 face). The
                    // triple-shape completeness is enforced by the driver's
                    // collect_import_items (the shared single point — D1).
                    // A list at the first position (missing module name)
                    // likewise falls to the E0002 face (a list is not a symbol).
                    let mut i = 1;
                    while i < list.len() {
                        match list[i].datum.as_symbol() {
                            Some(sym) => {
                                if ctx.table.name(sym) == "as" {
                                    if i + 1 >= list.len() {
                                        return Err(ExpandError::new(
                                            "import as alias missing right-hand operand",
                                            list[i].span,
                                        ));
                                    }
                                    i += 2;
                                    continue;
                                }
                                imports.push(sym);
                            }
                            None => {
                                if i > 1 {
                                    // The selection-list shape pre-check: all
                                    // members must be symbols (as-triples pass
                                    // naturally — the marker and both operands
                                    // are symbols)
                                    if let Some(sel) = list[i].datum.as_list() {
                                        for m in sel {
                                            if m.datum.as_symbol().is_none() {
                                                return Err(ExpandError::new(
                                                    "import item must be a symbol",
                                                    m.span,
                                                ));
                                            }
                                        }
                                        i += 1;
                                        continue;
                                    }
                                }
                                return Err(ExpandError::new(
                                    "import item must be a symbol",
                                    list[i].span,
                                ));
                            }
                        }
                        i += 1;
                    }
                    body_start += 1;
                    continue;
                }
                Some(Keyword::Export) => {
                    let list = items[body_start]
                        .datum
                        .as_list()
                        .expect("checked to be a list above");
                    for s in &list[1..] {
                        match s.datum.as_symbol() {
                            Some(sym) => exports.push(sym),
                            None => {
                                return Err(ExpandError::new(
                                    "export item must be a symbol",
                                    s.span,
                                ))
                            }
                        }
                    }
                    body_start += 1;
                    continue;
                }
                // Reason for the _ arm: the head is not import/export (a body form such as
                // define, or a non-keyword symbol head) — the optional header region ends
                // and the rest is the module body
                _ => break,
            }
        }
        break;
    }
    // Recursive item classification of the body (r49 D59 — same rules as the program top
    // level: do-splice + declaration-head dispatch)
    let body_items = expand_program(&items[body_start..], ctx)?;
    Ok(ModuleItem::Module {
        name,
        imports,
        exports,
        items: body_items,
        span: stx.span,
    })
}

/// `(require io read|write ...)` item-position expansion (r8 capability declaration — the
/// program-side declaration surface of 13 §3.1.3 basic passing; moved to the declaration
/// layer by r49 D59).
///
/// Shape contract: `(require <subject> <capability>...)`; the only subject today is `io`
/// (Stage 2 extends to net/process — a data-driven extension surface); capability items are
/// `read`/`write`. The declaration has idempotent set semantics (duplicate items deduped);
/// it produces `ModuleItem::Require` (zero runtime semantics, consumed by the driver's R9
/// permission validation and token minting).
pub(crate) fn expand_require_item(
    stx: &Stx,
    items: &[Stx],
    ctx: &mut ExpandCtxt,
) -> Result<ModuleItem, ExpandError> {
    if items.len() < 3 {
        return Err(ExpandError::new(
            "require form: (require io read|write) -- subject and capability items cannot be omitted",
            stx.span,
        ));
    }
    let subject = items[1].datum.as_symbol().ok_or_else(|| {
        ExpandError::new(
            "require subject must be a symbol(currently only io)",
            items[1].span,
        )
    })?;
    let subject_name = ctx.table.name(subject).to_string();
    if subject_name != "io" {
        return Err(ExpandError::new(
            format!(
                "unknown capability subject `{}`(currently only io; net/process belongs to Stage 3 trigger-gated introduction)",
                subject_name
            ),
            items[1].span,
        ));
    }
    let mut caps: Vec<Capability> = Vec::new();
    for item in &items[2..] {
        let cap_sym = item.datum.as_symbol().ok_or_else(|| {
            ExpandError::new(
                "require capability item must be a symbol(read/write)",
                item.span,
            )
        })?;
        let cap_name = ctx.table.name(cap_sym).to_string();
        let cap = match cap_name.as_str() {
            "read" => Capability::IoRead,
            "write" => Capability::IoWrite,
            other => {
                return Err(ExpandError::new(
                    format!(
                        "unknown capability item `{}`(currently only read/write)",
                        other
                    ),
                    item.span,
                ))
            }
        };
        if !caps.contains(&cap) {
            caps.push(cap);
        }
    }
    Ok(ModuleItem::Require {
        caps,
        span: stx.span,
    })
}

fn expand_quote(
    stx: &Stx,
    items: &[Stx],
    ctx: &mut ExpandCtxt,
) -> Result<Rc<CoreExpr>, ExpandError> {
    if items.len() != 2 {
        return Err(ExpandError::new("quote form: (quote data)", stx.span));
    }
    // r138 / 208-c — TD-002 (vector-value-design.md D2-b): quote vectors
    // take the recursive literal desugar — `(quote #(e1 ...))` →
    // `(vector 'e1 ...)`: elements are the existing quote products
    // (atoms / pair-lists → datum_to_value literals; nested vectors →
    // recursive desugar). Runtime construction is symmetric with the
    // quoted-pair emit_literal_pair law (quote structures are built at
    // runtime — the existing semantics, not a new introduction).
    if let StxDatum::Vector(children) = &items[1].datum {
        return quote_vector_apply(&items[1], children, ctx);
    }
    let value = datum_to_value(&items[1], &ctx.table)?;
    Ok(Rc::new(CoreExpr::Literal {
        value,
        span: stx.span,
    }))
}

/// Quote-vector desugar body (D2-b): builds the `(vector elem...)`
/// application — each element via `quote_vector_elem` (literal product or
/// nested recursive desugar).
fn quote_vector_apply(
    stx: &Stx,
    children: &Rc<Vec<Stx>>,
    ctx: &mut ExpandCtxt,
) -> Result<Rc<CoreExpr>, ExpandError> {
    let fn_expr = Rc::new(CoreExpr::Var {
        name: ctx.table.intern("vector"),
        scopes: stx.scopes.clone(),
        span: stx.span,
    });
    let mut args = Vec::with_capacity(children.len());
    for c in children.iter() {
        args.push(quote_vector_elem(c, ctx)?);
    }
    Ok(Rc::new(CoreExpr::Apply {
        fn_expr,
        args,
        span: stx.span,
    }))
}

/// One quoted vector element (D2-b): nested vectors recurse into the
/// desugar; every other datum takes the existing `datum_to_value` quote
/// product (atoms / pair-lists — zero new literal surface).
fn quote_vector_elem(stx: &Stx, ctx: &mut ExpandCtxt) -> Result<Rc<CoreExpr>, ExpandError> {
    match &stx.datum {
        StxDatum::Vector(children) => quote_vector_apply(stx, children, ctx),
        _ => {
            let value = datum_to_value(stx, &ctx.table)?;
            Ok(Rc::new(CoreExpr::Literal {
                value,
                span: stx.span,
            }))
        }
    }
}

/// datum → literal value (quote semantics; symbol datum → symbol value (base name with the
/// hygiene suffix stripped) — TD-002; r138/208-c: vector datums are routed to the D2-b
/// desugar BEFORE this function — the Vector arm below is the unreachable internal
/// defense (fail-closed if the routing regresses).
fn datum_to_value(stx: &Stx, table: &SymbolTable) -> Result<LiteralValue, ExpandError> {
    match &stx.datum {
        StxDatum::Literal(l) => Ok(crate::expander::literal_from_stx(l)),
        StxDatum::List(items) => {
            // List → right-folded pairs
            let mut acc = LiteralValue::Nil;
            for item in items.iter().rev() {
                acc = LiteralValue::Pair(Rc::new(datum_to_value(item, table)?), Rc::new(acc));
            }
            Ok(acc)
        }
        StxDatum::Symbol(sym) => {
            // The symbol value's name = the user-visible name: hygiene renaming (the
            // $hyg$N suffix) is an implementation detail; stripping it yields an explicit
            // approximation of Racket semantics (until scope-set resolution lands, same
            // stripping rule as driver::resolve_hygiene_fallbacks).
            let name = sym.as_str(table);
            let base = strip_hygiene_suffix(name);
            Ok(LiteralValue::Symbol(Rc::from(base)))
        }
        StxDatum::Vector(_) => Err(ExpandError::new(
            "internal defense: quote vector via D2-b desugar path first(r138/208-c -- this arm is unreachable; reaching it is an expander routing defect)",
            stx.span,
        )),
    }
}

/// Hygiene-suffix stripping (`name$hyg$N` → `name`; returned as-is when there is no suffix).
/// Same rule as the driver's global resolution fallback (the explicit name-base approximation
/// of TD-004).
fn strip_hygiene_suffix(name: &str) -> &str {
    match name.rsplit_once("$hyg$") {
        Some((base, _)) => base,
        None => name,
    }
}

fn expand_define_syntax(
    stx: &Stx,
    items: &[Stx],
    ctx: &mut ExpandCtxt,
) -> Result<Rc<CoreExpr>, ExpandError> {
    if items.len() != 3 {
        return Err(ExpandError::new(
            "define-syntax form: (define-syntax name (syntax-rules ...))",
            stx.span,
        ));
    }
    let name = items[1]
        .datum
        .as_symbol()
        .ok_or_else(|| ExpandError::new("define-syntax name must be a symbol", items[1].span))?;
    let rules_stx = &items[2];
    // The head must be syntax-rules
    let head_ok = rules_stx
        .datum
        .as_list()
        .and_then(|l| l.first())
        .and_then(|h| h.datum.as_symbol())
        .map(|s| ctx.table.is_keyword(s, Keyword::SyntaxRules))
        .unwrap_or(false);
    if !head_ok {
        return Err(ExpandError::new(
            "define-syntax second argument must be (syntax-rules ...) form",
            rules_stx.span,
        ));
    }
    let rules = SyntaxRules::parse(rules_stx).map_err(|e| {
        ExpandError::new(format!("syntax-rules parse failed: {}", e), rules_stx.span)
    })?;
    ctx.register_transformer(
        name,
        Transformer {
            kind: TransformerKind::Rules(rules),
            def_scopes: stx.scopes.clone(),
        },
    );
    // Phase 1 form: a runtime no-op (nil literal)
    Ok(Rc::new(CoreExpr::Literal {
        value: LiteralValue::Nil,
        span: stx.span,
    }))
}

fn define_name(def: &Stx, _ctx: &ExpandCtxt) -> Result<kerf_syntax::Symbol, ExpandError> {
    let items = def
        .datum
        .as_list()
        .ok_or_else(|| ExpandError::new("define must be a list", def.span))?;
    if items.len() < 2 {
        return Err(ExpandError::new("define form incomplete", def.span));
    }
    // Function sugar: (define (f x) ...)
    if let Some(flist) = items[1].datum.as_list() {
        return flist
            .first()
            .and_then(|f| f.datum.as_symbol())
            .ok_or_else(|| {
                ExpandError::new(
                    "define function sugar first element must be a symbol",
                    items[1].span,
                )
            });
    }
    items[1]
        .datum
        .as_symbol()
        .ok_or_else(|| ExpandError::new("define target must be a symbol", items[1].span))
}

fn define_value_stx(def: &Stx, ctx: &ExpandCtxt) -> Result<Stx, ExpandError> {
    // Returns the "value" part of the define; function sugar is normalized to
    // (define name (lambda ...))
    let items = def
        .datum
        .as_list()
        .ok_or_else(|| ExpandError::new("define must be a list", def.span))?;
    if items.len() < 2 {
        return Err(ExpandError::new("define form incomplete", def.span));
    }
    // Function sugar: (define (f x) body...) → builds (define f (lambda (x) body...))
    if let Some(flist) = items[1].datum.as_list() {
        if flist.first().and_then(|f| f.datum.as_symbol()).is_none() {
            return Err(ExpandError::new(
                "define function sugar first element must be a symbol",
                items[1].span,
            ));
        }
        let mut lambda_items: Vec<Stx> = vec![
            keyword_stx(ctx, Keyword::Fn),
            Stx::list(flist[1..].to_vec(), items[1].span, ScopeSet::new()),
        ];
        lambda_items.extend(items[2..].iter().cloned());
        let lambda_form = Stx::list(lambda_items, items[1].span, ScopeSet::new());
        // Returns the equivalent define's value (the lambda syntactic form — uniformly
        // re-expanded by the hoisting path)
        return Ok(lambda_form);
    }
    if items.len() == 3 {
        Ok(items[2].clone())
    } else {
        Err(ExpandError::new(
            "define value form must be a single expression",
            def.span,
        ))
    }
}

/// `(perform ⟨effect-value⟩)` (r25/42-f — effect-language-design §2.1 R10).
///
/// The effect value is evaluated first (Apply order — the evaluation-order contract
/// 06 §1.3 A1 unchanged); the result must be a `(tag . payload)` pair (tag = the Symbol
/// dispatch key — validated at runtime, not at expansion time). The control transfer is not
/// a value reduction: the value after resume is injected by the resumption point.
fn expand_perform(
    stx: &Stx,
    items: &[Stx],
    ctx: &mut ExpandCtxt,
) -> Result<Rc<CoreExpr>, ExpandError> {
    if items.len() != 2 {
        return Err(ExpandError::new(
            "perform form: (perform effect value) -- effect value must evaluates to (tag . payload) dotted pair",
            stx.span,
        ));
    }
    let effect = crate::expander::expand_form(&items[1], ctx)?;
    Ok(Rc::new(CoreExpr::Perform {
        effect,
        span: stx.span,
    }))
}

/// `(handle ⟨tag⟩ ((⟨payload-var⟩ ⟨resume-var⟩) ⟨result-expr⟩) ⟨body⟩)`
/// (R11 — shallow handling with a single clause, D2/D3). Both binders get a deep fresh-scope
/// injection (TD-004 discipline, same shape as Fn: inject the binder symbols and the handler
/// body; the body is not injected — the scope of p/r covers only the handling clause). The
/// body is always a single expression (single-shape by design syntax).
fn expand_handle(
    stx: &Stx,
    items: &[Stx],
    ctx: &mut ExpandCtxt,
) -> Result<Rc<CoreExpr>, ExpandError> {
    if items.len() != 4 {
        return Err(ExpandError::new(
            "handle form: (handle label ((payload variable resume variable) result expression) body)",
            stx.span,
        ));
    }
    // Effect-family tag (the single match dispatch key — a symbol)
    let tag_sym = items[1]
        .datum
        .as_symbol()
        .ok_or_else(|| ExpandError::new("handle effect tag must be a symbol", items[1].span))?;
    // The tag carrier = an Rc<str> shaped like a symbol literal (same as
    // LiteralValue::Symbol — no symbol table needed on the compile/VM side)
    let tag: std::rc::Rc<str> = std::rc::Rc::from(ctx.table.name(tag_sym));
    // Handling clause: ((p r) result) — deep fresh-scope injection (binders + handler body)
    let fresh = ctx.fresh_scope();
    let mut clause = items[2].clone();
    clause.add_scope_to_all(fresh);
    let clause_list = clause
        .datum
        .as_list()
        .ok_or_else(|| {
            ExpandError::new(
                "handle handler clause must be ((payload variable resume variable) result expression) form",
                items[2].span,
            )
        })?
        .to_vec();
    if clause_list.len() != 2 {
        return Err(ExpandError::new(
            "handle handler clause must be ((payload variable resume variable) result expression) form",
            items[2].span,
        ));
    }
    let binders = clause_list[0]
        .datum
        .as_list()
        .ok_or_else(|| {
            ExpandError::new(
                "handle handler clause variable table must be (payload variable resume variable) two-symbol list",
                clause_list[0].span,
            )
        })?
        .to_vec();
    if binders.len() != 2 {
        return Err(ExpandError::new(
            "handle handler clause variable table must be (payload variable resume variable) two-symbol list",
            clause_list[0].span,
        ));
    }
    let payload_var = binders[0].datum.as_symbol().ok_or_else(|| {
        ExpandError::new("handle payload variable must be a symbol", binders[0].span)
    })?;
    let resume_var = binders[1].datum.as_symbol().ok_or_else(|| {
        ExpandError::new("handle resume variable must be a symbol", binders[1].span)
    })?;
    if payload_var == resume_var {
        return Err(ExpandError::new(
            "handle payload variable and resume variable share a name (they must differ)",
            binders[1].span,
        ));
    }
    let payload_scopes = binders[0].scopes.clone();
    let resume_scopes = binders[1].scopes.clone();
    // Handler body (the fresh scope was injected along with the clause)
    let handler_body = crate::expander::expand_form(&clause_list[1], ctx)?;
    // The protected computation (the clause fresh scope is not injected — p/r are not in the
    // body's scope)
    let body = crate::expander::expand_form(&items[3], ctx)?;
    Ok(Rc::new(CoreExpr::Handle {
        tag,
        payload_var,
        payload_scopes,
        resume_var,
        resume_scopes,
        handler_body,
        body,
        span: stx.span,
    }))
}

/// `(handle-group (tag ((payload-var resume-var)) result-expr)+ body)` —
/// r136 / 206-b (TD-033 — handle-multi-arm-design.md §8 D12): the group-install
/// core form. Variadic (the match precedent): the LAST operand is the protected
/// body, everything before it is an arm clause `(tag (p k) result)`. >= 2 arms
/// enforced (the single-arm redirect keeps the surface economy — `handle`
/// already covers it); duplicate tags within the group fail closed (D6's same
/// discipline — under group install a duplicate arm would silently shadow).
/// Each arm gets its OWN deep fresh-scope injection (binders + the arm's
/// handler body — sibling scopes; the protected body is not injected).
fn expand_handle_group(
    stx: &Stx,
    items: &[Stx],
    ctx: &mut ExpandCtxt,
) -> Result<Rc<CoreExpr>, ExpandError> {
    if items.len() < 4 {
        return Err(ExpandError::new(
            "handle-group form: (handle-group (label (payload variable resume variable) result expression)+ body) -- at least two arms; for a single arm use handle form",
            stx.span,
        ));
    }
    let n_arms = items.len() - 2;
    let mut arms: Vec<kerf_core::HandleArm> = Vec::with_capacity(n_arms);
    let mut seen_tags: Vec<std::rc::Rc<str>> = Vec::with_capacity(n_arms);
    for clause_stx in &items[1..items.len() - 1] {
        let clause_list = clause_stx
            .datum
            .as_list()
            .ok_or_else(|| {
                ExpandError::new(
                    "handle-group arm clause must be (label (payload variable resume variable) result expression) form",
                    clause_stx.span,
                )
            })?
            .to_vec();
        if clause_list.len() != 3 {
            return Err(ExpandError::new(
                "handle-group arm clause must be (label (payload variable resume variable) result expression) form",
                clause_stx.span,
            ));
        }
        // Effect-family tag (the arm's dispatch key — a symbol; parsed from
        // the un-injected operand, same discipline as the single-arm form's
        // separate tag operand)
        let tag_sym = clause_list[0].datum.as_symbol().ok_or_else(|| {
            ExpandError::new(
                "handle-group effect tag must be a symbol",
                clause_list[0].span,
            )
        })?;
        let tag: std::rc::Rc<str> = std::rc::Rc::from(ctx.table.name(tag_sym));
        if seen_tags.contains(&tag) {
            return Err(ExpandError::new(
                format!(
                    "handle-group arm effect name duplicate: `{}`(the same handle-group at most one arm per effect -- under group installation a duplicate arm silently shadows, fail-closed rejected)",
                    tag
                ),
                clause_list[0].span,
            ));
        }
        seen_tags.push(tag.clone());
        // The arm's binders + result: deep fresh-scope injection (per-arm
        // independence — binders + the arm's handler result; sibling scopes)
        let fresh = ctx.fresh_scope();
        let mut binders_stx = clause_list[1].clone();
        binders_stx.add_scope_to_all(fresh);
        let mut result_stx = clause_list[2].clone();
        result_stx.add_scope_to_all(fresh);
        let binder_list = binders_stx
            .datum
            .as_list()
            .ok_or_else(|| {
                ExpandError::new(
                    "handle-group arm variable table must be a (payload-var resume-var) two-symbol list",
                    clause_list[1].span,
                )
            })?
            .to_vec();
        if binder_list.len() != 2 {
            return Err(ExpandError::new(
                "handle-group arm variable table must be a (payload-var resume-var) two-symbol list",
                clause_list[1].span,
            ));
        }
        let payload_var = binder_list[0].datum.as_symbol().ok_or_else(|| {
            ExpandError::new(
                "handle-group payload variable must be a symbol",
                binder_list[0].span,
            )
        })?;
        let resume_var = binder_list[1].datum.as_symbol().ok_or_else(|| {
            ExpandError::new(
                "handle-group resume variable must be a symbol",
                binder_list[1].span,
            )
        })?;
        if payload_var == resume_var {
            return Err(ExpandError::new(
                "handle-group payload variable and resume variable share a name (they must differ)",
                binder_list[1].span,
            ));
        }
        let payload_scopes = binder_list[0].scopes.clone();
        let resume_scopes = binder_list[1].scopes.clone();
        // The arm's handler body (expanded from the injected result)
        let handler_body = crate::expander::expand_form(&result_stx, ctx)?;
        arms.push(kerf_core::HandleArm {
            tag,
            payload_var,
            payload_scopes,
            resume_var,
            resume_scopes,
            handler_body,
        });
    }
    // The protected computation (no arm fresh scope is injected — the arms'
    // binders are not in the body's scope)
    let body = crate::expander::expand_form(&items[items.len() - 1], ctx)?;
    Ok(Rc::new(CoreExpr::HandleGroup {
        arms,
        body,
        span: stx.span,
    }))
}

/// `(resume κ v)` → `(κ v)` Apply (D4: the call shape of a continuation value — desugaring
/// that reuses the application machinery; zero ad-hoc paths in compile/runtime).
fn expand_resume(
    stx: &Stx,
    items: &[Stx],
    ctx: &mut ExpandCtxt,
) -> Result<Rc<CoreExpr>, ExpandError> {
    if items.len() != 3 {
        return Err(ExpandError::new(
            "resume form: (resume continuation value) -- continuation resume takes exactly one argument",
            stx.span,
        ));
    }
    let fn_expr = crate::expander::expand_form(&items[1], ctx)?;
    let arg = crate::expander::expand_form(&items[2], ctx)?;
    Ok(Rc::new(CoreExpr::Apply {
        fn_expr,
        args: vec![arg],
        span: stx.span,
    }))
}

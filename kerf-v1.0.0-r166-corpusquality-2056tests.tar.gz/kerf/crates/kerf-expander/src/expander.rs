//! Expander driver (the landed implementation of the expansion-loop skeleton of stage0.md
//! §19.2; module layout after the TD-012 split).
//!
//! `Stx` → `CoreExpr`: entry dispatch (macro → sugar → core form → function application).
//!
//! **Module layout** (TD-012, split of 2026-09-10):
//! - this file (driver): shared types (`ExpandCtxt`/`ExpandError`) + entry dispatch +
//!   macro-call expansion + shared construction helpers (keyword handles / literals /
//!   set! construction);
//! - `core_forms`: expansion of the 9 core forms + the function-body define hoisting path;
//! - `sugar`: built-in syntactic sugar transformers (§3.2 derivation table — the
//!   `TransformerKind::Builtin` carrier);
//! - `macro_sys`: transformer machinery (syntax-rules / hygiene context);
//! - `phase`: phase driving (module declare/visit/instantiate bookkeeping).
//!
//! **Expansion-loop skeleton** (§19.2):
//! 1. Core forms: never expand themselves, only recursively expand child nodes
//!    (`core_forms`);
//! 2. Macro calls: run the Phase 1 transformer, then recursively expand the product (until a
//!    core form);
//! 3. Identifiers: keep symbol references (slot resolution is performed by the compiler per
//!    §19.3).
//!
//! **Three core invariants** (§19.2):
//! 1. Expansion termination: exceeding the expansion-depth limit raises an error instead of
//!    overflowing the stack;
//! 2. Hygiene preservation: macro-introduced identifiers are α-renamed and never cross-talk
//!    with user identifiers;
//! 3. Phase closure: a Phase 1 transformer only produces Phase 0 syntax objects.

use std::borrow::Cow;
use std::collections::HashMap;
use std::rc::Rc;

use kerf_core::{CoreExpr, LiteralValue, ModuleItem};
use kerf_syntax::{Keyword, ScopeId, ScopeSet, Stx, StxDatum, StxLiteral, Symbol, SymbolTable};

use crate::core_forms::expand_core_form;
use crate::macro_sys::{BuiltinTransformers, Transformer, TransformerKind};

/// Expander error (minimal shared shape `{ message, span }`).
#[derive(Debug, Clone, PartialEq)]
pub struct ExpandError {
    pub message: String,
    pub span: kerf_span::Span,
}

impl ExpandError {
    pub(crate) fn new(message: impl Into<String>, span: kerf_span::Span) -> Self {
        ExpandError {
            message: message.into(),
            span,
        }
    }
}

/// Macro-expansion depth limit (§19.2 invariant 1: over the limit raises an error instead of
/// overflowing the stack).
///
/// **TD-007 partial lifting** (Stage 1 batch A3): macro-expansion chains were made iterative
/// via the trampoline worklist (the top-level loop of [`expand_form`] — no recursion when the
/// head of a macro product is still a macro call, the loop just continues), decoupling the
/// stack depth of expansion control flow from the chain length. The limit was raised from 128
/// (calibrated against rustc's recursion alignment) to **500**.
///
/// **Calibration basis** (TD-017 same-shape field measurement, probed on example):
/// - 2MiB test thread: 1_000 levels pass / 2_000 levels overflow;
/// - 8MiB main thread (CLI production): 4_000 levels pass / 5_000 levels overflow;
/// - the residual stack constraint comes from clone/drop recursion over the deep
///   value-semantics Stx tree (a data-structure-level constraint, not expansion control
///   flow);
/// - 500 = a 2× margin over the measured passing value 1_000 in the strictest delivery
///   environment (2MiB test thread) (the TD-017 precedent 690→256 is the same shape at
///   2.7×) — invariant 1 (error over the limit, not a stack overflow) must hold under
///   environment fluctuation, so the limit must sit inside the measured boundary.
///
/// The full documented value of 10_000 depends on making Stx `Rc`-based (Stage 1 front-end
/// rewrite batch B scope) — the residual boundary is registered in the TD-007 note.
/// Expansion depth limit (TD-007 full scope, batch H2): after both liftings — the trampoline
/// worklist (r4) + Stx Rc sharing (H2 — clone O(1), old trees spared deep drops via
/// sharing) — a 10_000-level chain measures constant stack depth (positive-case anchor
/// deep_macro_chain_expands_iteratively). Depth-counting semantics unchanged: the total
/// number of macro expansions on the current expansion path.
pub const MAX_EXPANSION_DEPTH: u32 = 10_000;

/// Expansion context (§10.1 rule 2: `Ctxt` suffix).
pub struct ExpandCtxt {
    /// Shared symbol table (the single source of truth).
    pub table: SymbolTable,
    /// Transformer registry (the Phase 1 world).
    transformers: HashMap<Symbol, Transformer>,
    /// Current macro-expansion depth.
    depth: u32,
    /// Scope allocator (TD-004/r13: the sole issuer of fresh scopes for binding forms —
    /// globally monotonically increasing, guaranteeing ScopeIds are never reused within one
    /// expansion).
    next_scope: ScopeId,
    /// Desugar-temp uniquifier (r122 / 192-a — match M-2): globally monotonic per
    /// expansion context. Stricter than the per-site macro α-channel counter:
    /// sibling/nested match desugars never mint the same temp name, eliminating
    /// max-cardinality ties in (name, scopes ⊆) resolution — the "match-scrut$hyg$N"
    /// single-evaluation temp carries the contract (match-design.md v1.2 §3.4).
    next_uniq: u32,
}

impl ExpandCtxt {
    /// Constructor (including marker-symbol initialization).
    pub fn new(mut table: SymbolTable) -> Self {
        BuiltinTransformers::init_markers(&mut table);
        init_keywords(&mut table);
        ExpandCtxt {
            table,
            transformers: HashMap::new(),
            depth: 0,
            next_scope: 1,
            next_uniq: 1,
        }
    }

    /// Allocates the next desugar-temp uniquifier value (r122 / 192-a — see the
    /// field doc; monotonic, never reused within one expansion context).
    pub(crate) fn fresh_uniq(&mut self) -> u32 {
        let n = self.next_uniq;
        self.next_uniq += 1;
        n
    }

    /// Allocates a fresh scope (TD-004: for binding-form injection; 0 is reserved for the
    /// "no scope" semantics — the empty set = the global/builtin fallback, never allocated).
    pub fn fresh_scope(&mut self) -> ScopeId {
        let s = self.next_scope;
        self.next_scope += 1;
        s
    }

    /// Registers a transformer (the Phase 1 effect of define-syntax).
    pub fn register_transformer(&mut self, name: Symbol, transformer: Transformer) {
        self.transformers.insert(name, transformer);
    }

    /// Looks up a transformer (Stage 0: by name; scope-set resolution: see TD-004).
    pub fn lookup_transformer(&self, name: Symbol) -> Option<&Transformer> {
        self.transformers.get(&name)
    }

    /// Decides and registers built-in syntactic sugar transformers (lazily: constructed on
    /// lookup).
    ///
    /// r101 / 171-c (derived-keyword macro-ization): the seven sugars (when/unless/and/or/
    /// let\*/ cond/while) migrate from hardcoded derivation arms to **`TransformerKind::Derived`**
    /// (form validators + syntax-rules macro definitions — single S-expression source
    /// `derived.rs`); `letrec` stays `Builtin` (nil arguments repeated once per binding are
    /// inexpressible on the depth-1 ellipsis surface — the same boundary family as TD-005,
    /// honestly registered). After lazy registration it is cached via the transformer table
    /// (parsed once per expansion context on first lookup).
    fn builtin_transformer(&mut self, head: Symbol) -> Option<Transformer> {
        let name = self.table.name(head).to_string();
        // letrec: stays built-in (the nil-fill boundary — see the sugar.rs module note)
        if name == "letrec" {
            return Some(Transformer {
                kind: TransformerKind::Builtin(crate::sugar::desugar_letrec),
                def_scopes: ScopeSet::new(),
            });
        }
        // The seven sugars: macro-ized (validators + S-expression macro definitions)
        let rules = crate::derived::parse_derived_rules(&name, &mut self.table)?;
        let validate = crate::derived::validator_for(&name);
        Some(Transformer {
            kind: TransformerKind::Derived { validate, rules },
            def_scopes: ScopeSet::new(),
        })
    }
}

/// Expands a program (sequence of top-level forms → sequence of `ModuleItem`s).
///
/// r49 / E5 S3 declaration-layer arm (22 §17 D59): top level = module-body semantics — item
/// classification (after the macro trampoline): define/require/module heads → declaration
/// items; `do` → **module-level splice** (recursive item classification — the legal channel
/// for macro-produced top-level defines, isomorphic to Racket's module-level begin splicing;
/// bytecode parity: a do chain's `[item; Pop]*` structure ≡ the item-order structure); the
/// rest → expression items (define-syntax is legal — it registers a transformer at expansion
/// time, with nil as the expression item).
pub fn expand_program(forms: &[Stx], ctx: &mut ExpandCtxt) -> Result<Vec<ModuleItem>, ExpandError> {
    let mut items = Vec::new();
    for form in forms {
        classify_item_form(form, ctx, &mut items)?;
    }
    Ok(items)
}

/// Item classification (r49 D59: macro trampoline → declaration-head dispatch / do-splice /
/// expression items).
///
/// Depth semantics are the same shape as `expand_form` (entry snapshot + exit rollback —
/// macro-step counts do not accumulate across siblings); expression items reuse all existing
/// expansion paths via `expand_form` (a second trampoline entry is zero steps — already
/// expanded).
fn classify_item_form(
    form: &Stx,
    ctx: &mut ExpandCtxt,
    out: &mut Vec<ModuleItem>,
) -> Result<(), ExpandError> {
    let entry_depth = ctx.depth;
    let mut current: Cow<'_, Stx> = Cow::Borrowed(form);
    while let Some(expanded) = try_macro_step(&current, ctx)? {
        current = Cow::Owned(expanded);
    }
    let result = (|| {
        if let StxDatum::List(items) = &current.datum {
            if let Some(head) = items.first().and_then(|h| h.datum.as_symbol()) {
                match Keyword::from_name(ctx.table.name(head)) {
                    Some(Keyword::Define) => {
                        let item = crate::core_forms::expand_define_item(&current, items, ctx)?;
                        out.push(item);
                        return Ok(());
                    }
                    Some(Keyword::Require) => {
                        let item = crate::core_forms::expand_require_item(&current, items, ctx)?;
                        out.push(item);
                        return Ok(());
                    }
                    Some(Keyword::Module) => {
                        let item = crate::core_forms::expand_module_item(&current, items, ctx)?;
                        out.push(item);
                        return Ok(());
                    }
                    Some(Keyword::Do) => {
                        // module-level splice: do items classified recursively (empty do → a
                        // single nil expression item — same shape as an empty do at the
                        // expansion layer, bytecode [PushNil])
                        if items.len() < 2 {
                            out.push(ModuleItem::Expr(Rc::new(CoreExpr::Literal {
                                value: LiteralValue::Nil,
                                span: current.span,
                            })));
                            return Ok(());
                        }
                        for inner in &items[1..] {
                            classify_item_form(inner, ctx, out)?;
                        }
                        return Ok(());
                    }
                    _ => {}
                }
            }
        }
        // Expression item (the define-syntax registration side effect happens in expansion
        // order — item order preserved)
        let expr = expand_form(&current, ctx)?;
        out.push(ModuleItem::Expr(expr));
        Ok(())
    })();
    ctx.depth = entry_depth;
    result
}

/// Item classification for the recovery path (r49 D59: top-level forms are all-or-nothing —
/// when classification fails internally the form's partial products are dropped [recovery
/// granularity = top-level form, consumed by recover.rs]).
pub(crate) fn classify_program_form_recover(
    form: &Stx,
    ctx: &mut ExpandCtxt,
) -> Result<Vec<ModuleItem>, ExpandError> {
    let mut items = Vec::new();
    classify_item_form(form, ctx, &mut items)?;
    Ok(items)
}

/// Expands a single form (entry function, §10.1 rule 1).
///
/// **Macro-expansion trampoline** (TD-007 worklist-ization): when the list head hits a
/// transformer (user macro / built-in sugar) and the expansion product's **head is still a
/// macro call**, the top-level loop continues without recursion — macro-chain length is
/// decoupled from stack depth (a 10_000-level chain at constant stack depth); when the
/// product's head is not a macro head, regular expansion takes over (core forms /
/// applications — child recursion, depth protected by the reader nesting cap).
/// `ctx.depth` keeps the semantics "total macro expansions on the current expansion path"
/// (no accumulation across siblings: entry snapshot, rollback on successful exit).
pub fn expand_form(stx: &Stx, ctx: &mut ExpandCtxt) -> Result<Rc<CoreExpr>, ExpandError> {
    let entry_depth = ctx.depth;
    let mut current: Cow<'_, Stx> = Cow::Borrowed(stx);
    while let Some(expanded) = try_macro_step(&current, ctx)? {
        current = Cow::Owned(expanded);
    }
    let result = match &current.datum {
        StxDatum::Literal(l) => Ok(Rc::new(CoreExpr::Literal {
            value: literal_from_stx(l),
            span: current.span,
        })),
        StxDatum::Symbol(name) => Ok(Rc::new(CoreExpr::Var {
            name: *name,
            scopes: current.scopes.clone(),
            span: current.span,
        })),
        StxDatum::List(items) => expand_list(&current, items, ctx),
        // r138 / 208-c — TD-002 (vector-value-design.md D2-a):
        // expression-position vector literal desugar — `#(a b c)` →
        // `(vector a b c)`. The as-if-written discipline (match-design M-2
        // same-shape precedent): the Var carries the literal site's scopes,
        // so a user shadowing of `vector` applies exactly as if the user
        // had written the application themselves; zero CoreExpr variants
        // (principle 9 freeze maintained — the match r122 desugar law).
        StxDatum::Vector(items) => {
            let fn_expr = Rc::new(CoreExpr::Var {
                name: ctx.table.intern("vector"),
                scopes: current.scopes.clone(),
                span: current.span,
            });
            let mut args = Vec::with_capacity(items.len());
            for it in items.iter() {
                args.push(expand_form(it, ctx)?);
            }
            Ok(Rc::new(CoreExpr::Apply {
                fn_expr,
                args,
                span: current.span,
            }))
        }
    };
    // Path-depth rollback: trampoline chain counts do not accumulate across siblings
    // (semantically equivalent to the old recursive version)
    ctx.depth = entry_depth;
    result
}

/// One step of the macro-expansion worklist (TD-007): if `stx` is a macro call (the list head
/// hits the transformer registry — including hygienic base-name fallback; or hits the
/// built-in sugar trigger set), run the transformer and return the product; otherwise return
/// `None` (regular expansion takes over).
///
/// Priority matches the old `expand_list`: user macros (including already-registered sugars)
/// → lazy registration of unregistered sugar names → core forms/applications handed back to
/// regular expansion. Depth counting accumulates here (chain length).
fn try_macro_step(stx: &Stx, ctx: &mut ExpandCtxt) -> Result<Option<Stx>, ExpandError> {
    let items = match &stx.datum {
        StxDatum::List(items) if !items.is_empty() => items,
        _ => return Ok(None),
    };
    let head = match items[0].datum.as_symbol() {
        Some(s) => s,
        None => return Ok(None),
    };
    // ---- 1. User macros (transformers registered by define-syntax; may shadow built-in
    // syntactic sugar names) ----
    // Hygienic fallback (D6 fix): transformer references introduced by macro templates are
    // α-renamed (`name$hyg$N`) — when the exact symbol misses the transformer table, fall
    // back to a **base-name** lookup (the Stage 0 approximation of 03 §2.4 hygiene guarantee
    // (2) "free-identifier pass-through", same rule as the driver's global hygiene fallback;
    // before the fix, both macro-calling-macro paths were unbound).
    let resolved = if ctx.lookup_transformer(head).is_some() {
        Some(head)
    } else {
        hygienic_base_symbol(head, &mut ctx.table)
            .filter(|base| ctx.lookup_transformer(*base).is_some())
    };
    let transformer_sym = match resolved {
        Some(sym) => sym,
        // ---- 2. Built-in syntactic sugar transformers (lazy registration) ----
        None => {
            if !is_sugar_symbol(head, &ctx.table) {
                return Ok(None);
            }
            let t = match ctx.builtin_transformer(head) {
                Some(t) => t,
                None => return Ok(None),
            };
            ctx.register_transformer(head, t);
            head
        }
    };
    // ---- Depth counting (chain-length semantics; over the limit raises an error, not a
    // stack overflow — §19.2 invariant 1) ----
    ctx.depth += 1;
    if ctx.depth > MAX_EXPANSION_DEPTH {
        ctx.depth -= 1;
        return Err(ExpandError::new(
            format!(
                "macro expansion depth exceeds the limit {}(suspected infinite recursive expansion)",
                MAX_EXPANSION_DEPTH
            ),
            stx.span,
        ));
    }
    let transformer = ctx
        .transformers
        .get(&transformer_sym)
        .cloned()
        .expect("caller already verified the transformer exists");
    let args: &[Stx] = &items[1..];
    let use_scopes = stx.scopes.clone();
    let expanded = transformer
        .apply_named(transformer_sym, args, &mut ctx.table, &use_scopes)
        .map_err(|e| {
            ExpandError::new(
                format!(
                    "macro `{}` expand failed: {}",
                    ctx.table.name(transformer_sym),
                    e
                ),
                stx.span,
            )
        })?;
    Ok(Some(expanded))
}

/// Literal Stx → CoreExpr literal (reused by the quote datum path).
pub(crate) fn literal_from_stx(l: &StxLiteral) -> LiteralValue {
    match l {
        StxLiteral::Int(v) => LiteralValue::Int(*v),
        StxLiteral::Float(v) => LiteralValue::Float(*v),
        StxLiteral::Str(s) => LiteralValue::Str(s.clone()),
        StxLiteral::Bool(b) => LiteralValue::Bool(*b),
        StxLiteral::Nil => LiteralValue::Nil,
    }
}

fn expand_list(
    stx: &Stx,
    items: &[Stx],
    ctx: &mut ExpandCtxt,
) -> Result<Rc<CoreExpr>, ExpandError> {
    if items.is_empty() {
        return Err(ExpandError::new(
            "empty list cannot be evaluated as an expression",
            stx.span,
        ));
    }
    // Macro and sugar heads were already handled by expand_form's trampoline (TD-007) —
    // a list reaching this point must be a core form or a function application.
    // ---- 3. Core forms (keyword table lookup, purely structural dispatch) ----
    if let Some(sym) = items[0].datum.as_symbol() {
        let name = ctx.table.name(sym);
        if let Some(kw) = Keyword::from_name(name) {
            return expand_core_form(kw, stx, items, ctx);
        }
    }
    // ---- 4. Function application ----
    let fn_expr = expand_form(&items[0], ctx)?;
    let mut args = Vec::with_capacity(items.len() - 1);
    for a in &items[1..] {
        args.push(expand_form(a, ctx)?);
    }
    Ok(Rc::new(CoreExpr::Apply {
        fn_expr,
        args,
        span: stx.span,
    }))
}

/// Hygienic base-name resolution: `name$hyg$N` → base-name Symbol (the suffix must be purely
/// digits; same conservative rule as the driver's `resolve_hygiene_fallbacks`).
fn hygienic_base_symbol(sym: Symbol, table: &mut kerf_syntax::SymbolTable) -> Option<Symbol> {
    let name = table.name(sym).to_string();
    let (base, suffix) = name.rsplit_once("$hyg$")?;
    if suffix.is_empty() || !suffix.chars().all(|c| c.is_ascii_digit()) {
        return None;
    }
    Some(table.intern(base))
}

// ---- Keyword handles (thread_local caches of intern results — shared by sugar/core_forms) ----

thread_local! {
    pub(crate) static WORD_LAMBDA: std::cell::RefCell<Symbol> = const { std::cell::RefCell::new(Symbol(u32::MAX)) };
    pub(crate) static WORD_SETBANG: std::cell::RefCell<Symbol> = const { std::cell::RefCell::new(Symbol(u32::MAX)) };
    pub(crate) static WORD_IF: std::cell::RefCell<Symbol> = const { std::cell::RefCell::new(Symbol(u32::MAX)) };
    pub(crate) static WORD_BEGIN: std::cell::RefCell<Symbol> = const { std::cell::RefCell::new(Symbol(u32::MAX)) };
    pub(crate) static WORD_LET: std::cell::RefCell<Symbol> = const { std::cell::RefCell::new(Symbol(u32::MAX)) };
    pub(crate) static WORD_LETREC: std::cell::RefCell<Symbol> = const { std::cell::RefCell::new(Symbol(u32::MAX)) };
    pub(crate) static WORD_ELSE: std::cell::RefCell<Symbol> = const { std::cell::RefCell::new(Symbol(u32::MAX)) };
    pub(crate) static WORD_LETSTAR: std::cell::RefCell<Symbol> = const { std::cell::RefCell::new(Symbol(u32::MAX)) };
}

/// Initializes the core-form keyword handles (called automatically by `ExpandCtxt::new`).
pub(crate) fn init_keywords(table: &mut SymbolTable) {
    let words: Vec<(
        Keyword,
        &'static std::thread::LocalKey<std::cell::RefCell<Symbol>>,
    )> = vec![
        (Keyword::Fn, &WORD_LAMBDA),
        (Keyword::Assign, &WORD_SETBANG),
        (Keyword::If, &WORD_IF),
        (Keyword::Do, &WORD_BEGIN),
        (Keyword::Let, &WORD_LET),
        (Keyword::LetRec, &WORD_LETREC),
        (Keyword::Else, &WORD_ELSE),
        (Keyword::LetStar, &WORD_LETSTAR),
    ];
    for (kw, slot) in words {
        let sym = table.keyword_symbol(kw);
        slot.with(|w| *w.borrow_mut() = sym);
    }
}

pub(crate) fn kw_symbol(
    word: &'static std::thread::LocalKey<std::cell::RefCell<Symbol>>,
) -> Symbol {
    word.with(|w| *w.borrow())
}

// ---- Construction helpers (the Stx construction foundation shared by core_forms/sugar) ----

pub(crate) fn nil_stx(span: kerf_span::Span) -> Stx {
    Stx::literal(StxLiteral::Nil, span, ScopeSet::new())
}

// r101 / 171-c note: true_stx/false_stx retired together with desugar_and/desugar_or
// (macro-ization of the seven sugars — boolean base cases are carried by macro-template
// literals).

pub(crate) fn keyword_stx(ctx: &ExpandCtxt, kw: Keyword) -> Stx {
    let sym = ctx.table.keyword_symbol(kw);
    Stx::symbol(sym, kerf_span::Span::dummy(), ScopeSet::new())
}

pub(crate) fn make_setbang(name: Symbol, value: Stx, span: kerf_span::Span) -> Stx {
    // (set! name value) three-element list (the internal-define hoisting path)
    Stx::list(
        vec![
            Stx::symbol(kw_symbol(&WORD_SETBANG), span, ScopeSet::new()),
            Stx::symbol(name, span, ScopeSet::new()),
            value,
        ],
        span,
        ScopeSet::new(),
    )
}

pub(crate) fn is_head_keyword(stx: &Stx, ctx: &ExpandCtxt, kw: Keyword) -> bool {
    stx.datum
        .as_list()
        .and_then(|l| l.first())
        .and_then(|h| h.datum.as_symbol())
        .map(|s| ctx.table.is_keyword(s, kw))
        .unwrap_or(false)
}

/// Syntactic-sugar symbol predicate (the trigger set of the built-in transformer channel —
/// same name set as builtin_transformer).
fn is_sugar_symbol(sym: Symbol, table: &SymbolTable) -> bool {
    // r50-β / D61: "let" leaves the sugar table (nine sugars → eight sugars — direct mapping
    // to the core form)
    matches!(
        table.name(sym),
        "letrec" | "let*" | "cond" | "and" | "or" | "when" | "unless" | "while"
    )
}

#[cfg(test)]
mod tests {
    // E6 close-out (r154 / 224-d6): converted to the target-syntax face
    // (`read_source` — the sole Reader since r154 / 224-a). The asserted
    // CoreExpr renders stay byte-identical (the renderer is skin-neutral — only
    // the INPUT programs converted). Deletions and recalibrations are recorded
    // in the r154 worklog:
    // - deleted (unconvertible): `expand_letrec_derives` (the letrec binding-group
    //   shape has no call-argument surface on the target grammar) and
    //   `inner_define_hoisted` (the Reader's block threading do-wraps every
    //   in-body define — the function-body head-define hoisting window is
    //   unreachable; the position rejection below is the reachable face);
    // - recalibrated: `quote_list_becomes_pairs` → the vector datum family
    //   (r127 honest boundary — the quoted pair-list datum has no target-surface
    //   literal), `inner_define_after_expr_is_error` → the E0003 do-wrap message,
    //   `errors_carry_span` → the quote-arity family (the if arity is
    //   grammar-enforced at Read), and the `'sym` quote-shorthand leg
    //   (the apostrophe lexes as the lifetime token).
    use super::*;
    use kerf_reader::read_source;

    fn ctx() -> ExpandCtxt {
        ExpandCtxt::new(SymbolTable::new())
    }

    fn expand_src(src: &str, c: &mut ExpandCtxt) -> Result<Vec<ModuleItem>, ExpandError> {
        let forms = read_source(src, 0, &mut c.table).expect("read failed");
        expand_program(&forms, c)
    }

    /// Item rendering (r49 D59 — item-level render; expression items are unwrapped for
    /// rendering, keeping the existing assertion surface).
    fn render(items: &[ModuleItem], c: &ExpandCtxt) -> Vec<String> {
        items
            .iter()
            .map(|i| i.render(&|s| c.table.name(s).to_string()))
            .collect()
    }

    /// Symbol constructor for the macro-produced-shape tests below (declaration
    /// keywords are Reader Tokens — their expression-position occurrences are
    /// fronted to Read on the target face, so the expander backstops are
    /// exercised through constructed Stx).
    fn sym_stx(c: &mut ExpandCtxt, name: &str) -> Stx {
        Stx::symbol(
            c.table.intern(name),
            kerf_span::Span::dummy(),
            ScopeSet::new(),
        )
    }

    /// Dummy-span list constructor (same idiom as the depth-limit tests).
    fn list_stx(items: Vec<Stx>) -> Stx {
        Stx::list(items, kerf_span::Span::dummy(), ScopeSet::new())
    }

    #[test]
    fn expand_lambda_and_app() {
        let mut c = ctx();
        let out = expand_src("(|| (x: i64) { x + 1 })(41)", &mut c).unwrap();
        assert_eq!(render(&out, &c), vec!["((fn (x) (+ x 1)) 41)"]);
    }

    #[test]
    fn expand_if_with_implicit_else() {
        let mut c = ctx();
        let out = expand_src("if (true) { 1 }", &mut c).unwrap();
        assert_eq!(render(&out, &c)[0], "(if true 1 nil)");
    }

    #[test]
    fn expand_define_function_sugar() {
        let mut c = ctx();
        let out = expand_src("fn f(x: i64) { x * x }", &mut c).unwrap();
        assert_eq!(render(&out, &c)[0], "(define f (fn (x) (* x x)))");
    }

    #[test]
    fn expand_let_derives_to_lambda_app() {
        // r50-β / D61 direct-mapping anchor: multi-binding staging chain (render =
        // (let (name) value body)). E6 face: `let` is a block-position statement —
        // the comma form `let x = 1, y = 2;` lowers to the same multi-binding let
        // Stx carried inside the closure block; the bare let form (the closure
        // body) is the assertion surface (the IIFE carrier would wrap the render).
        let mut c = ctx();
        let forms =
            read_source("(|| { let x = 1, y = 2; x + y })", 0, &mut c.table).expect("read failed");
        // (fn () (let ((x 1) (y 2)) (+ x y))) — the third element is the body form
        let let_form = forms[0].datum.as_list().expect("closure form")[2].clone();
        let out = expand_form(&let_form, &mut c).unwrap();
        assert_eq!(
            out.render(&|s| c.table.name(s).to_string()),
            "(let (let$st0) 1 (let (let$st1) 2 (let (x) let$st0 (let (y) let$st1 (+ x y)))))"
        );
    }

    // ---- r49 / E5 S3 declaration-layer arm (22 §17 D59): item classification + position
    // discipline moved forward ----

    #[test]
    fn expand_define_position_rejected_at_expression() {
        // E0003-spec message kept verbatim (formerly in ir.rs, lowering moved forward into
        // the expander — CoreExpr cannot represent the structured rejection of define in
        // expression position). E6 face: the call-form define + the Reader's block
        // threading reproduce the do-wrapped shape the message describes.
        let mut c = ctx();
        let err = expand_src("fn f(x: i64) { define(y, 2); x }", &mut c).unwrap_err();
        assert_eq!(
            err.message,
            "define is only allowed at the top level or at the head of a function body (a define wrapped in a do/expression position is illegal -- place nested defines at the body head)"
        );
        // Wrapping in if expression position is likewise rejected
        let mut c2 = ctx();
        let err2 = expand_src(
            "fn f(x: i64) { if (true) { define(y, 2); } else { x } }",
            &mut c2,
        )
        .unwrap_err();
        assert!(err2
            .message
            .contains("define is only allowed at the top level or at the head of a function body"));
    }

    #[test]
    fn expand_module_position_rejected_at_expression() {
        // E0023 new diagnostic code (previously unchecked — compiled silently inline;
        // symmetric with the import/export E0002 message shape). E6 face: `module` is
        // a declaration Token — source-level occurrences in expression position are
        // fronted to the Reader (fail-closed at Read); the expander's E0023 backstop
        // stays reachable for macro-produced shapes and is exercised through
        // constructed Stx here (the message is asserted verbatim).
        let mut c = ctx();
        let module_form = list_stx(vec![
            sym_stx(&mut c, "module"),
            sym_stx(&mut c, "m"),
            Stx::literal(
                StxLiteral::Int(1),
                kerf_span::Span::dummy(),
                ScopeSet::new(),
            ),
        ]);
        let fn_form = list_stx(vec![
            sym_stx(&mut c, "fn"),
            list_stx(vec![sym_stx(&mut c, "x")]),
            module_form,
        ]);
        let err = expand_form(&fn_form, &mut c).unwrap_err();
        assert_eq!(
            err.message,
            "module may only appear at the program top level or module body direct element position (current position is an expression --module is a compilation-unit organizational form, not an expression; 22 §17 D59)"
        );
    }

    #[test]
    fn expand_require_position_rejected_at_expression() {
        // E0018-spec message kept verbatim (formerly a driver tree walk — the expander is
        // the structured backstop; source-level violations are carried by the Reader's
        // fail-closed keyword rejection on the target face [diagnostic-code-18
        // contract] — `require` is a declaration Token). The backstop stays reachable
        // for macro-produced shapes and is exercised through constructed Stx (the
        // original (fn (x) (require io read) x) shape, multi-body form).
        let mut c = ctx();
        let fn_form = list_stx(vec![
            sym_stx(&mut c, "fn"),
            list_stx(vec![sym_stx(&mut c, "x")]),
            list_stx(vec![
                sym_stx(&mut c, "require"),
                sym_stx(&mut c, "io"),
                sym_stx(&mut c, "read"),
            ]),
            sym_stx(&mut c, "x"),
        ]);
        let err = expand_form(&fn_form, &mut c).unwrap_err();
        assert!(err.message.contains("require position violation"));
        assert!(err
            .message
            .contains("require legal position = program top level or module body direct element"));
    }

    #[test]
    fn expand_program_classifies_declarations() {
        // Item classification: define/require/module → declaration items; expressions → Expr
        // items
        let mut c = ctx();
        let out = expand_src(
            "require io, read;\nlet x = 1;\nmodule m { export y; let y = 2; y }\n42",
            &mut c,
        )
        .unwrap();
        assert_eq!(out.len(), 4, "four item: require/define/module/expr");
        assert!(matches!(out[0], ModuleItem::Require { .. }));
        assert!(matches!(out[1], ModuleItem::Define { .. }));
        assert!(matches!(out[2], ModuleItem::Module { .. }));
        assert!(
            matches!(&out[3], ModuleItem::Expr(e) if matches!(e.as_ref(), CoreExpr::Literal { .. }))
        );
    }

    #[test]
    fn expand_reader_private_names_modern() {
        // r50 / D63: the Reader bootstraps the four private modern names (is-/-to- shapes —
        // in-domain consistency of R2/R4; the `?`/`->` user freedom surface unchanged
        // [e5-plan §4.3 maintained]). E6 face: the snake_case surface spelling interns
        // to the same kebab core names (the symbol_name skin mapping).
        let mut c = ctx();
        let out = expand_src(
            "let ws = char_is_whitespace; let p = char_is_alphabetic; let v = string_is_int; let s = string_to_pos_chars;",
            &mut c,
        )
        .unwrap();
        assert_eq!(
            out.len(),
            4,
            "the four modern names via Var references should be legal"
        );
    }

    #[test]
    fn expand_program_splices_toplevel_do() {
        // module-level do-splice (the D59 core mechanism — the legal channel for
        // macro-produced top-level defines; isomorphic to Racket's module-level begin
        // splicing):
        // do(define(a, 1), a) → two items [Define a, Expr a]
        let mut c = ctx();
        let out = expand_src("do(define(a, 1), a)", &mut c).unwrap();
        assert_eq!(out.len(), 2, "do two items splice");
        assert!(matches!(out[0], ModuleItem::Define { .. }));
        assert!(matches!(&out[1], ModuleItem::Expr(_)));
        // empty do → a single nil expression item ([PushNil] bytecode shape preserved)
        let mut c2 = ctx();
        let out2 = expand_src("do()", &mut c2).unwrap();
        assert_eq!(out2.len(), 1);
        assert!(
            matches!(&out2[0], ModuleItem::Expr(e) if matches!(e.as_ref(), CoreExpr::Literal { value: LiteralValue::Nil, .. }))
        );
        // nested do splices recursively
        let mut c3 = ctx();
        let out3 = expand_src("do(do(1, 2), do(3, 4))", &mut c3).unwrap();
        assert_eq!(out3.len(), 4, "nested do flattening four items");
    }

    #[test]
    fn expand_cond_chain() {
        // E6 face: the else-if chain lowers to the same nested-if Stx the cond macro
        // used to derive — the derivation target is asserted unchanged.
        let mut c = ctx();
        let out = expand_src(
            "if (false) { 1 } else { if (true) { 2 } else { 3 } }",
            &mut c,
        )
        .unwrap();
        let r = render(&out, &c)[0].clone();
        assert!(
            r.starts_with("(if false 1 (if true 2 3))"),
            "cond inference:{}",
            r
        );
    }

    #[test]
    fn expand_and_or() {
        // E6 face: the call forms and(a, b, c)/or(a, b) reach the same n-ary sugar
        // Stx (`&&`/`||` are binary left-assoc — `a && b && c` folds as
        // (and (and a b) c), a different derivation tree; the n-ary surface needs
        // the call form).
        let mut c = ctx();
        let out = expand_src("and(a, b, c)", &mut c).unwrap();
        assert_eq!(render(&out, &c)[0], "(if a (if b c false) false)");
        let out2 = expand_src("or(a, b)", &mut c).unwrap();
        assert_eq!(render(&out2, &c)[0], "(if a true b)");
    }

    #[test]
    fn expand_while_uses_fresh_loop() {
        // E6 face: while has no statement surface — the sugar entry is the call form
        // while(cond, assign(...)) (the assign call form is the expression-position
        // spelling of the set! statement).
        let mut c = ctx();
        let out = expand_src("while(i < 10, assign(i, i + 1))", &mut c).unwrap();
        let r = render(&out, &c)[0].clone();
        assert!(
            r.contains("loop$hyg$"),
            "while loop must be uniquified: {}",
            r
        );
    }

    #[test]
    fn quote_list_becomes_pairs() {
        // E6 face (r127 honest boundary): the quoted pair-list datum has no
        // target-surface literal — the reachable datum-sequence family is the
        // vector literal quote([1, 2, 3]) (the D2-b recursive desugar → the
        // vector application).
        let mut c = ctx();
        let out = expand_src("quote([1, 2, 3])", &mut c).unwrap();
        assert_eq!(render(&out, &c)[0], "(vector 1 2 3)");
    }

    #[test]
    fn quote_symbol_becomes_symbol_literal() {
        // TD-002 lifting: symbol datum → symbol literal (hygiene suffix stripped).
        // (The 'sym quote-shorthand leg has no target surface — the apostrophe
        // lexes as the lifetime token; deleted at E6, recorded in the r154
        // worklog.)
        let mut c = ctx();
        let out = expand_src("quote(sym)", &mut c).unwrap();
        assert_eq!(render(&out, &c)[0], "sym");
    }

    #[test]
    fn inner_define_after_expr_is_error() {
        // E6 face: the Reader's block threading do-wraps every in-body define —
        // the reachable rejection is the E0003 do-wrap message (calibrated by
        // running at r154; the former "define must be at the head of a function
        // body" family fired on the multi-body-form shape the target Reader no
        // longer produces).
        let mut c = ctx();
        let err = expand_src("fn f(x: i64) { x + 1; define(y, 2); }", &mut c).unwrap_err();
        assert!(err
            .message
            .contains("define is only allowed at the top level or at the head of a function body"));
    }

    #[test]
    fn expansion_depth_limit() {
        let mut c = ctx();
        // Self-referential macro: infinite expansion (self references in the template are not
        // renamed, per the preserve set)
        let src = "macro loop2 { () => loop2() }\nloop2()";
        let forms = read_source(src, 0, &mut c.table).unwrap();
        let result = expand_program(&forms, &mut c);
        let err = result.unwrap_err();
        assert!(
            err.message.contains("expansion depth"),
            "actual error: {}",
            err.message
        );
    }

    #[test]
    fn deep_macro_chain_expands_iteratively() {
        // TD-007 full-scope positive case (H2): a 10_000-level pass-through macro chain = the
        // documented example scope. After the r4 trampoline lifted control-flow recursion, the
        // residual stack constraint was clone/drop on the deep value-semantics Stx tree
        // (measured: 8MiB main thread passes 4_000 / overflows 5_000) — after the H2 Rc
        // sharing (List/Vector → Rc<Vec<Stx>>, clone O(1) + old trees shared, spared deep
        // drops) this test passes on the 2MiB test thread (constant stack depth).
        // The chain is constructed, not nested in source (the reader nesting cap of 256 does
        // not apply to Stx construction).
        let src = "macro m { (x) => x }";
        let mut c = ctx();
        let forms = read_source(src, 0, &mut c.table).unwrap();
        expand_program(&forms, &mut c).unwrap(); // registers the pass-through macro m
        let m_sym = c.table.intern("m");
        let span = kerf_span::Span::dummy();
        let mut cur = Stx::literal(StxLiteral::Int(42), span, ScopeSet::new());
        for _ in 0..10_000 {
            cur = Stx::list(
                vec![Stx::symbol(m_sym, span, ScopeSet::new()), cur],
                span,
                ScopeSet::new(),
            );
        }
        let out = expand_form(&cur, &mut c).unwrap();
        match out.as_ref() {
            CoreExpr::Literal {
                value: LiteralValue::Int(42),
                ..
            } => {}
            other => panic!(
                "the passed-through 10_000-level chain should reduce to the literal 42, got {:?}",
                other
            ),
        }
    }

    #[test]
    fn macro_chain_beyond_limit_reports_error() {
        // TD-007 negative case (H2 scope): a 10_001-level chain exceeds the limit → a
        // structured error (not a stack overflow). Limit semantics = the total macro
        // expansions on the expansion path (a 10_000-level chain passes exactly, 10_001
        // levels error — boundary verified inclusive on both ends).
        let src = "macro m { (x) => x }";
        let mut c = ctx();
        let forms = read_source(src, 0, &mut c.table).unwrap();
        expand_program(&forms, &mut c).unwrap();
        let m_sym = c.table.intern("m");
        let span = kerf_span::Span::dummy();
        let mut cur = Stx::literal(StxLiteral::Int(1), span, ScopeSet::new());
        for _ in 0..10_001 {
            cur = Stx::list(
                vec![Stx::symbol(m_sym, span, ScopeSet::new()), cur],
                span,
                ScopeSet::new(),
            );
        }
        let err = expand_form(&cur, &mut c).unwrap_err();
        assert!(
            err.message.contains("exceeds the limit 10000"),
            "actual error: {}",
            err.message
        );
    }

    #[test]
    fn user_macro_with_hygiene() {
        // E6 face: the macro name drops the `!` (the target skin writes macro
        // invocations as plain calls — `!` is the MacroBang suffix token); the
        // template's assign statements reproduce the same (assign …) Stx.
        let mut c = ctx();
        let src = "macro swap { (a, b) => { tmp = quote([1]); a = b; } }\nswap(x, y)";
        let out = expand_src(src, &mut c).unwrap();
        let r = render(&out, &c).join(" ");
        // The introduced identifier tmp must be renamed (hygiene guarantee)
        assert!(
            r.contains("tmp$hyg$"),
            "introduced identifier renamed: {}",
            r
        );
    }

    #[test]
    fn module_form_expands() {
        let mut c = ctx();
        let out = expand_src("module m { import a; export f; let f = 1; f }", &mut c).unwrap();
        let r = render(&out, &c)[0].clone();
        assert!(
            r.starts_with("(module m (import a) (export f)"),
            "module: {}",
            r
        );
    }

    #[test]
    fn errors_carry_span() {
        // E6 face: the if-arity shape is grammar-enforced at Read — the
        // span-carriage property is asserted on the expander-reachable
        // quote-arity family (the call form lowers to the same quote Stx).
        let mut c = ctx();
        let err = expand_src("quote()", &mut c).unwrap_err();
        assert!(!err.span.is_empty() || err.span.start == 0);
    }
}

//! # kerf-expander
//!
//! **Positioning on the five orthogonal axes (lang-design 15 §5.3, v6.0)**: the execution
//! surface of the Axis-1 bridge — the sole translator from `Stx → CoreExpr` (macro expansion +
//! sugar derivation; translation happens rather than pass-through, anchored by audit
//! tests).
//!
//! Expander skeleton + hygienic macro system + phase separation (stage0.md §8.9 / §8.10 /
//! §12.3 / §19.2).
//!
//! Pipeline position (sop.md §2.4.4): `Stx` (produced by kerf-reader) → **this crate** →
//! `CoreExpr` (kerf-core).
//!
//! **Module layout** (TD-012 split, 2026-09-10: core forms / sugar derivation / phase driving
//! as three separate responsibilities; the master expander keeps entry dispatch and shared
//! construction helpers; r101 / 171-c added `derived`)
//! - `expander`: entry dispatch + shared types (`ExpandCtxt`/`ExpandError`) +
//!   macro-call expansion + construction foundation;
//! - `core_forms`: expansion of the 9 core forms + the function-body define hoisting path
//!   (crate-private);
//! - `sugar`: built-in syntactic sugar transformers (§3.2 derivation table, crate-private —
//!   after r101 / 171-c it hosts the `letrec` transformer + the form-validator surface);
//! - `derived`: derived-keyword syntax-rules macro definitions (r101 / 171-c — macro-ization of
//!   seven sugars: single S-expression source + form validators, crate-private);
//! - `macro_sys`: transformer machinery (syntax-rules / hygiene context — including compound
//!   ellipsis sequence collection and depth-1 completion of compound template ellipsis iteration);
//! - `phase`: phase driving (module declare/visit/instantiate bookkeeping).
//!
//! **Capability list**:
//! - Expansion of the 9 core forms (lambda/if/set!/define/begin/module/varref/literal/app);
//! - Built-in syntactic sugar transformers (let/letrec/let*/cond/and/or/when/unless/while —
//!   §3.2 derivation table);
//! - User hygienic macros via `define-syntax` + `syntax-rules` (patterns/templates/ellipsis);
//! - Phase separation (Phase 0/1 physical isolation + declare/instantiate/visit module lifecycle).
//!
//! **Hygiene model** (Stage 0, P1 level):
//! - Syntax objects carry a `ScopeSet` throughout (binding forms add a mark, §19.2);
//! - Introduced identifiers (non-pattern variables in macro templates) are **α-renamed** to
//!   unique symbols — the hygiene guarantee that "the same name inside and outside a macro never
//!   cross-talks" (complete, a P1 requirement);
//! - Racket-style scope-set resolution (resolved in TD-004 r13 — (name, scopes ⊆)
//!   max-cardinality, two paths anchored by 9 tests).
//!
//! **Core invariants** (§19.2):
//! 1. Expansion termination: exceeding the expansion-generation limit raises an error instead of
//!    overflowing the stack (limit 10_000 — delivered in TD-007 r18: iterative worklist + Stx Rc
//!    sharing, two paths);
//! 2. Hygiene preservation: macro-introduced identifiers never collide with user identifiers;
//! 3. Phase closure: a Phase 1 transformer only produces Phase 0 syntax objects.

mod core_forms;
mod derived;
pub mod expander;
pub mod macro_sys;
mod match_desugar;
pub mod phase;
pub mod recover;
mod sugar;

// Explicit re-exports (§10.1 rule 4: glob re-exports are forbidden).
// Convention: this crate exposes all public types and entry points of the expansion domain;
// core_forms/sugar are internal implementation modules (§11 interface isolation — the outside
// only sees the expander entry) and are not exported.
pub use derived::derived_definition_forms;
pub use expander::{expand_form, expand_program, ExpandCtxt, ExpandError};
pub use macro_sys::{SyntaxRules, Transformer, TransformerKind};
pub use phase::{ModuleEntry, ModuleRegistry, PhaseLevel};
pub use recover::{expand_program_recover, DiagCollector, RecoveredExpansion, MAX_DIAGNOSTICS};

// ---------------------------------------------------------------------------
// Space-affiliation declaration section (r66 / 123-a — lang-design 24 v2.0 unified two-sided
// system; 24 §7.2 core-side incorporation table: this crate's main types get three-layer explicit
// impls [root + core space + domain] — core front-end domain (source entry — macro expansion /
// phase management, the second bridge); core-side version of "declaration as affiliation",
// sole affiliation criterion = marker impl [24 §3 A7])
// ---------------------------------------------------------------------------
use kerf_space::{CoreFrontendDomain, CoreSpace, RootSpace};

impl RootSpace for ExpandCtxt {}
impl CoreSpace for ExpandCtxt {}
impl CoreFrontendDomain for ExpandCtxt {}
impl RootSpace for ExpandError {}
impl CoreSpace for ExpandError {}
impl CoreFrontendDomain for ExpandError {}
impl RootSpace for Transformer {}
impl CoreSpace for Transformer {}
impl CoreFrontendDomain for Transformer {}
impl RootSpace for SyntaxRules {}
impl CoreSpace for SyntaxRules {}
impl CoreFrontendDomain for SyntaxRules {}
impl RootSpace for ModuleRegistry {}
impl CoreSpace for ModuleRegistry {}
impl CoreFrontendDomain for ModuleRegistry {}
impl RootSpace for PhaseLevel {}
impl CoreSpace for PhaseLevel {}
impl CoreFrontendDomain for PhaseLevel {}

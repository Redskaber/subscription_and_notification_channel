//! Basic macro system: hygienic macros + SyntaxObject (stage0.md §8.10, §19.2).
//!
//! The Stage 0 macro system is a "skeleton" — macro definition, macro expansion, and
//! hygiene guarantees are supported; complex macro composition (e.g. `syntax-parse`) is
//! explicitly deferred (technical debt TD-005).
//!
//! **Transformers**: first-class citizens of the Phase 1 world.
//! - `Builtin`: built-in transformers implemented in Rust (let/letrec/cond/... syntactic
//!   sugars, §3.2 derivation table);
//! - `SyntaxRules`: user-defined pattern/template transformers (match → substitute →
//!   rename).
//!
//! **Hygiene** (a P1-level guarantee, §19.2 invariant 2):
//! - Identifiers in templates that are **not pattern variables** (introduced identifiers)
//!   are α-renamed to unique symbols at expansion time (`name$hyg$N`) — the same name never
//!   cross-talks inside vs outside the macro;
//! - pattern-variable substitution keeps the user code's identifiers (user symbols
//!   reference user bindings);
//! - expansion products carry the union "macro-definition-site scopes ∪ use-site scopes"
//!   (the key to §19.2 hygiene).

use kerf_syntax::{Keyword, ScopeSet, Stx, StxDatum, Symbol, SymbolTable};

/// Transformer: syntax → syntax (the Phase 1 world).
#[derive(Debug, Clone)]
pub enum TransformerKind {
    /// User syntax-rules transformer.
    Rules(SyntaxRules),
    /// Built-in transformer implemented in Rust (syntactic-sugar derivation, §3.2 derivation
    /// table).
    Builtin(fn(&[Stx], &mut HygieneCtx) -> Result<Stx, String>),
    /// **Derived-keyword macro-ization transformer** (r101 / 171-c — derived keywords
    /// implemented via S-expression extension macros): a form validator (keeping the existing
    /// error-message contract — the negative-case assertion surface) + a syntax-rules macro
    /// definition (single S-expression source — the expansion body).
    ///
    /// Application order: validate first (fail-closed error surface) → macro-expand after
    /// (shape surface).
    Derived {
        /// Form validator (None = no negative-case surface — any argument shape is legal).
        validate: Option<crate::derived::ValidateFn>,
        /// Macro definition (the syntax-rules clause set).
        rules: SyntaxRules,
    },
}

/// Transformer wrapper (carries the macro-definition-site scopes — a union ingredient of
/// hygienic expansion).
#[derive(Debug, Clone)]
pub struct Transformer {
    /// Transformer kind.
    pub kind: TransformerKind,
    /// Scope set at the macro definition site.
    pub def_scopes: ScopeSet,
}

impl Transformer {
    /// Applies the transformer (syntax → syntax; preserves no symbol — the old interface,
    /// see apply_named).
    pub fn apply(
        &self,
        args: &[Stx],
        table: &mut SymbolTable,
        use_site_scopes: &ScopeSet,
    ) -> Result<Stx, String> {
        self.apply_named(Symbol(u32::MAX), args, table, use_site_scopes)
    }

    /// Applies the transformer (syntax → syntax; `self_name` is the macro's own symbol —
    /// references to that symbol in the template are **not renamed** (a correctness
    /// requirement of self-referential recursive macros, Stage 0 ruling).
    pub fn apply_named(
        &self,
        self_name: Symbol,
        args: &[Stx],
        table: &mut SymbolTable,
        use_site_scopes: &ScopeSet,
    ) -> Result<Stx, String> {
        let mut hygiene = HygieneCtx::new(table);
        hygiene.preserve(self_name);
        let output = match &self.kind {
            TransformerKind::Rules(rules) => rules.apply(args, &mut hygiene)?,
            TransformerKind::Builtin(f) => f(args, &mut hygiene)?,
            TransformerKind::Derived { validate, rules } => {
                // r101 / 171-c: derived-keyword macro-ization — validate first (the
                // error-message contract is retained: verbatim identical to the original
                // built-in transformer's negative-case surface — the negative-case assertion
                // anchor), then expand (the single-S-expression-source macro definition).
                if let Some(v) = validate {
                    v(args)?;
                }
                rules.apply(args, &mut hygiene)?
            }
        };
        // Hygiene key (§19.2): the expansion product carries the union "macro-definition-site
        // scopes ∪ use-site scopes"
        let out_scopes = self.def_scopes.union(use_site_scopes);
        Ok(retag_scopes(&output, &out_scopes))
    }
}

/// Hygiene context: uniqueness renaming of introduced identifiers.
///
/// **Consistency invariant**: within one template instantiation, every occurrence of the
/// same introduced identifier must be renamed to the **same** symbol (guaranteed by the
/// `renames` map — otherwise bindings and references come apart).
pub struct HygieneCtx<'t> {
    table: &'t mut SymbolTable,
    counter: u32,
    /// Preserve set: these symbols are **not renamed** (macro self-references etc.).
    preserve: Vec<Symbol>,
    /// Introduced symbol → renamed symbol (consistent within this instantiation).
    renames: std::collections::HashMap<Symbol, Symbol>,
}

impl<'t> HygieneCtx<'t> {
    /// Constructor (counting starts fresh at each macro call site).
    pub fn new(table: &'t mut SymbolTable) -> Self {
        HygieneCtx {
            table,
            counter: 0,
            preserve: Vec::new(),
            renames: std::collections::HashMap::new(),
        }
    }

    /// Begins a template instantiation (the rename map is reset — each expansion numbers
    /// independently).
    pub fn begin_instantiation(&mut self) {
        self.renames.clear();
    }

    /// Registers a preserve-set symbol (excluded from α renaming).
    pub fn preserve(&mut self, sym: Symbol) {
        if sym.0 != u32::MAX {
            self.preserve.push(sym);
        }
    }

    /// Introduced identifier → uniquified symbol (α renaming `name$hyg$N`; **multiple
    /// occurrences of the same identifier map to the same symbol** — the consistency
    /// invariant).
    pub fn fresh_symbol(&mut self, base: Symbol) -> Symbol {
        if let Some(&s) = self.renames.get(&base) {
            return s;
        }
        self.counter += 1;
        let name = self.table.name(base);
        let sym = self.table.intern(&format!("{}$hyg${}", name, self.counter));
        self.renames.insert(base, sym);
        sym
    }

    /// Current rename count (test and debug observation).
    pub fn renames(&self) -> u32 {
        self.counter
    }

    /// Symbol table access (for built-in transformers constructing introduced symbols).
    pub fn table(&mut self) -> &mut SymbolTable {
        self.table
    }

    /// Read-only name lookup (for read-only paths such as keyword checks).
    pub fn peek_name(&self, sym: Symbol) -> &str {
        self.table.name(sym)
    }

    /// Whether the symbol is in the preserve set.
    fn is_preserved(&self, sym: Symbol) -> bool {
        self.preserve.contains(&sym)
    }
}

/// Recursively retags scopes (keeps datum/span/phase, only updating the scopes field).
///
/// **Iterative + uniform-tag sharing (the TD-007/H2 double lifting)**:
/// 1. **Iterative**: explicit-worklist postorder rebuild (`Visit` descends / `Assemble`
///    assembles), so Rust stack depth stays constant — the old recursive version
///    overflowed on 10_000-level chains;
/// 2. **Uniform-tag fast path**: when the input node has `uniform_tag == Some(target)`
///    (the whole subtree's scopes are uniform = target — set when rebuilt by this function,
///    cleared when `add_scope_to_all` injects), return directly via shallow sharing (Rc
///    count +1). The products of each trampoline-chain step (the previous step's retag
///    output) hit with the same geometry: total work O(N) for a chain of length N (the old
///    version rebuilt the whole tree each step, O(N²)).
fn retag_scopes(stx: &Stx, scopes: &ScopeSet) -> Stx {
    // Fast path: uniform hit — the whole subtree's scopes already = target, share shallowly.
    if stx.uniform_tag.as_ref() == Some(scopes) {
        return stx.clone();
    }
    // Worklist: postorder rebuild (children built first, parents assembled); constant stack
    // depth.
    enum Task<'a> {
        Visit(&'a Stx),
        Assemble { input: &'a Stx, child_count: usize },
    }
    let mut tasks: Vec<Task<'_>> = vec![Task::Visit(stx)];
    let mut out: Vec<Stx> = Vec::new();
    while let Some(task) = tasks.pop() {
        match task {
            Task::Visit(node) => {
                // A child's uniform hit can be shared wholesale (the subtree is spared a
                // rebuild)
                if node.uniform_tag.as_ref() == Some(scopes) {
                    out.push(node.clone());
                    continue;
                }
                match &node.datum {
                    StxDatum::Symbol(s) => out.push(retag_leaf(StxDatum::Symbol(*s), node, scopes)),
                    StxDatum::Literal(l) => {
                        out.push(retag_leaf(StxDatum::Literal(l.clone()), node, scopes))
                    }
                    StxDatum::List(items) | StxDatum::Vector(items) => {
                        let n = items.len();
                        tasks.push(Task::Assemble {
                            input: node,
                            child_count: n,
                        });
                        for item in items.iter().rev() {
                            tasks.push(Task::Visit(item));
                        }
                    }
                }
            }
            Task::Assemble { input, child_count } => {
                // The child items sit in order at the top of out (guaranteed by LIFO
                // processing order)
                let start = out.len() - child_count;
                let items: Vec<Stx> = out.drain(start..).collect();
                let datum = match &input.datum {
                    StxDatum::List(_) => StxDatum::List(std::rc::Rc::new(items)),
                    // Constructive default: only the List/Vector container variants can
                    // reach this rebuild path (Assemble upstream has already narrowed) —
                    // keep the original container kind unchanged
                    _ => StxDatum::Vector(std::rc::Rc::new(items)),
                };
                out.push(retag_leaf(datum, input, scopes));
            }
        }
    }
    out.pop().expect("root rebuild artifact invariant")
}

/// Leaf/assemble-node rebuild: datum given, scopes → target, span bumped one expansion
/// generation, phase kept; **uniform_tag set to Some(target)** (subtree uniformity is
/// guaranteed by construction: the leaf itself / the assembled children are all
/// target-tagged nodes or shared uniform subtrees).
fn retag_leaf(datum: StxDatum, input: &Stx, scopes: &ScopeSet) -> Stx {
    Stx {
        datum,
        span: input.span.bumped_expansion(),
        scopes: scopes.clone(),
        phase: input.phase,
        uniform_tag: Some(scopes.clone()),
    }
}

/// User hygienic macros: `(syntax-rules (literal...) (pattern template)...)`.
///
/// Pattern syntax:
/// - `_`: wildcard (matches anything, binds nothing);
/// - `...`: ellipsis (zero or more repetitions of the preceding pattern at the list tail);
/// - symbols: pattern variables (bind the matched fragment), except symbols in the literal
///   set (matched literally);
/// - literal datums (numbers/strings/booleans): matched by equality;
/// - lists/vectors: structural matching.
///
/// Template syntax:
/// - pattern variables: substituted with the bound value;
/// - `(x ...)`: the ellipsis splices the bound sequence;
/// - all other identifiers: **introduced identifiers** → α renaming (hygiene);
/// - datums: copied verbatim.
#[derive(Debug, Clone)]
pub struct SyntaxRules {
    /// Literal set (matched by symbol, not treated as pattern variables).
    literals: Vec<Symbol>,
    /// Sequence of (pattern, template) clauses (tried in order).
    clauses: Vec<(Stx, Stx)>,
    /// Snapshot of the scopes at the definition site.
    def_scopes: ScopeSet,
}

impl SyntaxRules {
    /// Constructs from a `(syntax-rules (lit...) (pat tpl)...)` syntax object.
    /// Returns (SyntaxRules, the first failure among the error list).
    pub fn parse(form: &Stx) -> Result<SyntaxRules, String> {
        let items = form
            .datum
            .as_list()
            .ok_or_else(|| "syntax-rules must be a list".to_string())?;
        if items.len() < 2 {
            return Err(
                "syntax-rules missing arguments (need at least a literal set and one clause)"
                    .to_string(),
            );
        }
        // The head must be the syntax-rules keyword (the caller guarantees it; defensive
        // check here)
        if !matches!(items[0].datum, StxDatum::Symbol(_)) {
            return Err("syntax-rules first element must be a symbol".to_string());
        }
        // Literal set
        let lits = match &items[1].datum {
            StxDatum::List(lits) => {
                let mut out = Vec::new();
                for l in lits.iter() {
                    match l.datum.as_symbol() {
                        Some(s) => out.push(s),
                        None => return Err("syntax-rules literal must be a symbol".to_string()),
                    }
                }
                out
            }
            _ => return Err("syntax-rules second element must be a literal list".to_string()),
        };
        // Clauses
        let mut clauses = Vec::new();
        for clause in &items[2..] {
            let pair = clause
                .datum
                .as_list()
                .filter(|c| c.len() == 2)
                .ok_or_else(|| {
                    "syntax-rules clause must be (pattern template) two-element list".to_string()
                })?;
            clauses.push((pair[0].clone(), pair[1].clone()));
        }
        if clauses.is_empty() {
            return Err("syntax-rules needs at least one clause".to_string());
        }
        Ok(SyntaxRules {
            literals: lits,
            clauses,
            def_scopes: form.scopes.clone(),
        })
    }

    /// Applies: match clause by clause → expand the template on a hit.
    /// The `args` parameter holds every argument of the macro-call form except the macro
    /// name.
    pub fn apply(&self, args: &[Stx], hygiene: &mut HygieneCtx) -> Result<Stx, String> {
        for (pattern, template) in &self.clauses {
            let mut bindings = Vec::new();
            // The pattern (macro-name . rest) aligns with the call (args...):
            // the pattern's first element matches the macro-name placeholder (by
            // convention `_` or a symbol)
            if let Some(matched) = self.match_clause(pattern, args, &mut bindings) {
                if matched {
                    return self.instantiate(template, &bindings, hygiene);
                }
            }
        }
        Err("macro call matches no clause pattern".to_string())
    }

    /// Definition-site scope set (a hygiene union ingredient; consumed by
    /// Transformer::apply).
    pub fn definition_scopes(&self) -> &ScopeSet {
        &self.def_scopes
    }

    /// Clause count (test surface — a structural smoke-test anchor).
    #[cfg(test)]
    pub(crate) fn clause_len(&self) -> usize {
        self.clauses.len()
    }

    /// Clause matching: the pattern (including the macro-name head) against the argument
    /// sequence.
    fn match_clause(
        &self,
        pattern: &Stx,
        args: &[Stx],
        bindings: &mut Vec<(Symbol, BoundValue)>,
    ) -> Option<bool> {
        // Flatten the pattern into a "sequence pattern": the list pattern (p0 p1 ... rest...)
        // aligns element-wise with args
        let pats = pattern.datum.as_list()?;
        // The first element is the macro name (or `_`): skip it
        let arg_pats = &pats[1.min(pats.len())..];
        match match_sequence(arg_pats, args, &self.literals, bindings) {
            true => Some(true),
            false => None,
        }
    }

    /// Template instantiation: pattern-variable substitution + ellipsis splicing + α
    /// renaming of introduced identifiers.
    fn instantiate(
        &self,
        template: &Stx,
        bindings: &[(Symbol, BoundValue)],
        hygiene: &mut HygieneCtx,
    ) -> Result<Stx, String> {
        hygiene.begin_instantiation();
        Ok(instantiate_template(template, bindings, hygiene, None))
    }
}

/// Value shapes of match bindings.
#[derive(Debug, Clone)]
enum BoundValue {
    /// A single matched fragment.
    Single(Stx),
    /// A sequence expanded from an ellipsis (zero or more).
    Sequence(Vec<Stx>),
}

/// Sequence matching: a pattern sequence (with ellipsis — at any non-first position, a
/// fixed tail `(a ... b)` is legal) against the argument sequence.
fn match_sequence(
    pats: &[Stx],
    args: &[Stx],
    literals: &[Symbol],
    bindings: &mut Vec<(Symbol, BoundValue)>,
) -> bool {
    // Locate the first ellipsis (position k ≥ 1 — k == 0 is a syntax error treated as a
    // no-match, existing behavior)
    let ell_pos = pats
        .iter()
        .position(|p| p.datum.as_symbol().map(is_ellipsis).unwrap_or(false));
    let Some(k) = ell_pos else {
        // No ellipsis: equal length + item-by-item (existing semantics)
        if args.len() != pats.len() {
            return false;
        }
        for (p, a) in pats.iter().zip(args.iter()) {
            if !match_datum(p, a, literals, bindings) {
                return false;
            }
        }
        return true;
    };
    if k == 0 {
        return false; // an ellipsis is legal only in sequence position (existing behavior)
    }
    let fixed_prefix = &pats[..k - 1];
    let ep = &pats[k - 1];
    let fixed_suffix = &pats[k + 1..];
    if args.len() < fixed_prefix.len() + fixed_suffix.len() {
        return false;
    }
    // Fixed prefix segment
    for (p, a) in fixed_prefix.iter().zip(args.iter()) {
        if !match_datum(p, a, literals, bindings) {
            return false;
        }
    }
    // Fixed suffix segment (aligned to the argument tail — R7RS 4.3.2 `(a ... b)` tail
    // ellipsis + fixed tail)
    if !fixed_suffix.is_empty() {
        let tail_args = &args[args.len() - fixed_suffix.len()..];
        for (p, a) in fixed_suffix.iter().zip(tail_args.iter()) {
            if !match_datum(p, a, literals, bindings) {
                return false;
            }
        }
    }
    // Ellipsis segment: the middle between prefix and suffix
    let rest = &args[fixed_prefix.len()..args.len() - fixed_suffix.len()];
    // The ellipsis pattern variable binds a sequence
    if let Some(var) = ep.datum.as_symbol() {
        let seq: Vec<Stx> = rest.to_vec();
        bindings.retain(|(n, _)| *n != var);
        bindings.push((var, BoundValue::Sequence(seq)));
        return true;
    }
    // Compound ellipsis patterns (e.g. `(a b)` matched structurally, element by element) —
    // **R7RS collection semantics** (TD-005 in-window obligation honored — the
    // r101-registered clone-commit → R7RS canonical switch: the corpus has zero
    // compound-ellipsis consumer shapes = an additive change with zero breakage; the
    // krf-side match-compound mirror + parity anchor updated in sync to the canonical
    // shape). Nested ellipses (a compound pattern containing `...` inside) = an honest
    // boundary — fail-closed no-match (depth tracking = a later batch)
    let mut vars: Vec<Symbol> = Vec::new();
    collect_pattern_vars(ep, literals, &mut vars);
    let mut collected: Vec<(Symbol, Vec<Stx>)> =
        vars.into_iter().map(|v| (v, Vec::new())).collect();
    for r in rest {
        let mut inner = bindings.clone();
        if !match_datum(ep, r, literals, &mut inner) {
            return false;
        }
        for (v, acc) in collected.iter_mut() {
            match inner.iter().find(|(n, _)| n == v) {
                Some((_, BoundValue::Single(val))) => acc.push(val.clone()),
                // Nested ellipses out of scope: a sequence binding inside a compound pattern →
                // fail-closed
                Some((_, BoundValue::Sequence(_))) => return false,
                None => {
                    // Variable unbound (e.g. it appears only in a literal branch) — per R7RS
                    // the variable is dropped from the collection set (the template cannot
                    // reference it — later instantiation reports an unbound error)
                }
            }
        }
    }
    for (v, acc) in collected {
        bindings.retain(|(n, _)| *n != v);
        bindings.push((v, BoundValue::Sequence(acc)));
    }
    true
}

/// Collects the pattern-variable names in a pattern (excluding ellipsis/wildcard/literals;
/// deduplicated, order preserved).
fn collect_pattern_vars(pat: &Stx, literals: &[Symbol], out: &mut Vec<Symbol>) {
    match &pat.datum {
        StxDatum::Symbol(s) => {
            if !is_ellipsis(*s) && !is_wildcard(*s) && !literals.contains(s) && !out.contains(s) {
                out.push(*s);
            }
        }
        StxDatum::List(items) | StxDatum::Vector(items) => {
            for it in items.iter() {
                collect_pattern_vars(it, literals, out);
            }
        }
        StxDatum::Literal(_) => {}
    }
}

/// Single-element matching: pattern datum against argument datum.
fn match_datum(
    pat: &Stx,
    arg: &Stx,
    literals: &[Symbol],
    bindings: &mut Vec<(Symbol, BoundValue)>,
) -> bool {
    match &pat.datum {
        StxDatum::Symbol(s) => {
            if is_ellipsis(*s) {
                return false; // an ellipsis is legal only in sequence position
            }
            if is_wildcard(*s) {
                return true; // `_` wildcard
            }
            if literals.contains(s) {
                // Literal: matches only when the symbols are equal
                matches!(&arg.datum, StxDatum::Symbol(a) if a == s)
            } else {
                // Pattern variable: bind
                bindings.retain(|(n, _)| *n != *s);
                bindings.push((*s, BoundValue::Single(arg.clone())));
                true
            }
        }
        StxDatum::Literal(l) => matches!(&arg.datum, StxDatum::Literal(a) if a == l),
        StxDatum::List(pats) => {
            if let Some(inner) = arg.datum.as_list() {
                let mut fresh = bindings.clone();
                if match_sequence(pats, inner, literals, &mut fresh) {
                    *bindings = fresh;
                    return true;
                }
            }
            false
        }
        StxDatum::Vector(pats) => {
            if let StxDatum::Vector(inner) = &arg.datum {
                let mut fresh = bindings.clone();
                if match_sequence(pats, inner, literals, &mut fresh) {
                    *bindings = fresh;
                    return true;
                }
            }
            false
        }
    }
}

/// Template instantiation: `depth` = the current nesting depth of ellipsis splicing
/// (None = top level).
fn instantiate_template(
    template: &Stx,
    bindings: &[(Symbol, BoundValue)],
    hygiene: &mut HygieneCtx,
    seq_index: Option<usize>,
) -> Stx {
    match &template.datum {
        StxDatum::Symbol(s) => {
            // Pattern-variable substitution (keeps the user symbol and Span — references
            // user bindings)
            if let Some((_, BoundValue::Single(v))) = bindings.iter().find(|(n, _)| n == s) {
                return v.clone();
            }
            if let Some((_, BoundValue::Sequence(seq))) = bindings.iter().find(|(n, _)| n == s) {
                // Sequence variable in a non-ellipsis position: take the element at the
                // current index (splicing context)
                if let Some(idx) = seq_index {
                    if let Some(v) = seq.get(idx) {
                        return v.clone();
                    }
                }
                // Out of bounds or no index: keep as a symbol (the expander will treat it
                // as unbound)
                return template.clone();
            }
            // Introduced identifier: α renaming (the core of hygiene).
            // Exceptions: the preserve set (macro self-references) and core-form keywords
            // (syntax dispatch words, not references).
            if hygiene.is_preserved(*s) || is_core_keyword(*s, hygiene) {
                return template.clone();
            }
            let fresh = hygiene.fresh_symbol(*s);
            Stx {
                datum: StxDatum::Symbol(fresh),
                span: template.span,
                scopes: template.scopes.clone(),
                phase: template.phase,
                uniform_tag: None,
            }
        }
        StxDatum::Literal(l) => Stx {
            datum: StxDatum::Literal(l.clone()),
            span: template.span,
            scopes: template.scopes.clone(),
            phase: template.phase,
            uniform_tag: None,
        },
        StxDatum::List(items) | StxDatum::Vector(items) => {
            let mut out: Vec<Stx> = Vec::new();
            let is_vector = matches!(template.datum, StxDatum::Vector(_));
            // Expansion escape `(… template)` (R7RS 4.3.3 — delivered within the TD-005
            // window): a two-element list whose first element is an ellipsis → instantiate
            // the second element in escaped mode (inner ellipses kept literally — the only
            // channel for a template to write a literal `...`)
            if items.len() == 2 && items[0].datum.as_symbol().map(is_ellipsis).unwrap_or(false) {
                return instantiate_escaped(&items[1], bindings, hygiene);
            }
            let mut i = 0;
            while i < items.len() {
                let item = &items[i];
                // Detect `(var ...)` ellipsis splicing
                let next_is_ellipsis = items
                    .get(i + 1)
                    .and_then(|n| n.datum.as_symbol())
                    .map(is_ellipsis)
                    .unwrap_or(false);
                if next_is_ellipsis {
                    if let Some(var) = item.datum.as_symbol() {
                        if let Some((_, BoundValue::Sequence(seq))) =
                            bindings.iter().find(|(n, _)| *n == var)
                        {
                            for v in seq {
                                out.push(v.clone());
                            }
                            i += 2;
                            continue;
                        }
                    }
                    // Compound sub-template iteration `(sub ...)` (the template side of
                    // R7RS collection semantics — delivered within the TD-005 window): the
                    // sub-template contains sequence-bound variables → instantiate index by
                    // index over the first variable's sequence length (locally rebind
                    // v → Single(seq[i]); out-of-range drops the binding and flows into the
                    // downstream unbound error — length mismatch is fail-closed via
                    // downstream diagnostics). Single-level scope: a nested `(v ...)` inside
                    // the sub-template is out of scope.
                    if matches!(item.datum, StxDatum::List(_) | StxDatum::Vector(_)) {
                        let seq_vars = sequence_vars_in(item, bindings);
                        if let Some(first) = seq_vars.first() {
                            let seq_len = bindings
                                .iter()
                                .find(|(n, _)| n == first)
                                .and_then(|(_, v)| match v {
                                    BoundValue::Sequence(vs) => Some(vs.len()),
                                    BoundValue::Single(_) => None,
                                })
                                .unwrap_or(0);
                            for idx in 0..seq_len {
                                let mut local: Vec<(Symbol, BoundValue)> = bindings
                                    .iter()
                                    .filter(|(n, _)| !seq_vars.contains(n))
                                    .cloned()
                                    .collect();
                                for v in &seq_vars {
                                    if let Some((_, BoundValue::Sequence(vs))) =
                                        bindings.iter().find(|(n, _)| n == v)
                                    {
                                        if let Some(elem) = vs.get(idx) {
                                            local.push((*v, BoundValue::Single(elem.clone())));
                                        }
                                    }
                                }
                                out.push(instantiate_template(item, &local, hygiene, None));
                            }
                            i += 2;
                            continue;
                        }
                    }
                    // An ellipsis without a sequence binding: erroring beats silence — kept
                    // as-is here, and the expander uniformly reports "unbound" for unknown
                    // symbols
                }
                out.push(instantiate_template(item, bindings, hygiene, seq_index));
                i += 1;
            }
            let span = out
                .first()
                .map(|f| {
                    let mut sp = f.span;
                    for x in &out {
                        sp = sp.merge(x.span);
                    }
                    sp
                })
                .unwrap_or(template.span);
            let datum = if is_vector {
                StxDatum::Vector(std::rc::Rc::new(out))
            } else {
                StxDatum::List(std::rc::Rc::new(out))
            };
            Stx {
                datum,
                span,
                scopes: template.scopes.clone(),
                phase: template.phase,
                uniform_tag: None,
            }
        }
    }
}

/// Core-form keyword predicate (via a name lookup in the current symbol table; keywords do
/// not participate in hygiene renaming).
fn is_core_keyword(s: Symbol, hygiene: &HygieneCtx) -> bool {
    let name = hygiene.peek_name(s);
    Keyword::from_name(name).is_some()
}

/// Collects the variable names in a template that hold sequence bindings (order preserved,
/// deduplicated — for compound sub-template iteration).
fn sequence_vars_in(template: &Stx, bindings: &[(Symbol, BoundValue)]) -> Vec<Symbol> {
    let mut out: Vec<Symbol> = Vec::new();
    fn walk(t: &Stx, bindings: &[(Symbol, BoundValue)], out: &mut Vec<Symbol>) {
        if let StxDatum::Symbol(s) = &t.datum {
            if bindings
                .iter()
                .any(|(n, v)| n == s && matches!(v, BoundValue::Sequence(_)))
                && !out.contains(s)
            {
                out.push(*s);
            }
            return;
        }
        if let StxDatum::List(items) | StxDatum::Vector(items) = &t.datum {
            for it in items.iter() {
                walk(it, bindings, out);
            }
        }
    }
    walk(template, bindings, &mut out);
    out
}

/// Escaped-mode instantiation (the second element of `(... template)` — R7RS 4.3.3):
/// ellipsis look-ahead detection is off + the `...` symbol is kept literally (excluded from
/// hygiene renaming).
fn instantiate_escaped(
    template: &Stx,
    bindings: &[(Symbol, BoundValue)],
    hygiene: &mut HygieneCtx,
) -> Stx {
    match &template.datum {
        StxDatum::Symbol(s) => {
            // Pattern-variable substitution (pattern variables still substitute inside the
            // escape scope — R7RS semantics)
            if let Some((_, BoundValue::Single(v))) = bindings.iter().find(|(n, _)| n == s) {
                return v.clone();
            }
            // Literal ellipsis kept (the core of the escape); introduced identifiers
            // α-renamed as usual
            if is_ellipsis(*s) || hygiene.is_preserved(*s) || is_core_keyword(*s, hygiene) {
                return template.clone();
            }
            let fresh = hygiene.fresh_symbol(*s);
            Stx {
                datum: StxDatum::Symbol(fresh),
                span: template.span,
                scopes: template.scopes.clone(),
                phase: template.phase,
                uniform_tag: None,
            }
        }
        StxDatum::Literal(l) => Stx {
            datum: StxDatum::Literal(l.clone()),
            span: template.span,
            scopes: template.scopes.clone(),
            phase: template.phase,
            uniform_tag: None,
        },
        StxDatum::List(items) | StxDatum::Vector(items) => {
            let is_vector = matches!(template.datum, StxDatum::Vector(_));
            let out: Vec<Stx> = items
                .iter()
                .map(|it| instantiate_escaped(it, bindings, hygiene))
                .collect();
            let span = out
                .first()
                .map(|f| {
                    let mut sp = f.span;
                    for x in &out {
                        sp = sp.merge(x.span);
                    }
                    sp
                })
                .unwrap_or(template.span);
            let datum = if is_vector {
                StxDatum::Vector(std::rc::Rc::new(out))
            } else {
                StxDatum::List(std::rc::Rc::new(out))
            };
            Stx {
                datum,
                span,
                scopes: template.scopes.clone(),
                phase: template.phase,
                uniform_tag: None,
            }
        }
    }
}

/// `...` symbol predicate (via a symbol-table name lookup).
fn is_ellipsis(s: Symbol) -> bool {
    // The ellipsis symbol is interned at the lexical layer as the identifier "..."
    // (SymbolTable guarantees name uniqueness). Comparison here is by symbol name (a
    // conservative approximation via handle identity when the local table is unavailable:
    // the expander already ensures the unique intern of "..." before constructing the
    // HygieneCtx).
    ELLIPSIS.with(|e| *e.borrow() == s)
}

thread_local! {
    static ELLIPSIS: std::cell::RefCell<Symbol> = const { std::cell::RefCell::new(Symbol(u32::MAX)) };
}

/// Registers the ellipsis symbol handle (called once at expander initialization).
pub fn register_ellipsis(table: &mut SymbolTable) {
    let sym = table.intern("...");
    ELLIPSIS.with(|e| *e.borrow_mut() = sym);
}

/// `_` wildcard predicate.
fn is_wildcard(s: Symbol) -> bool {
    WILDCARD.with(|w| *w.borrow() == s)
}

thread_local! {
    static WILDCARD: std::cell::RefCell<Symbol> = const { std::cell::RefCell::new(Symbol(u32::MAX)) };
}

/// Registers the wildcard symbol handle (called once at expander initialization).
pub fn register_wildcard(table: &mut SymbolTable) {
    let sym = table.intern("_");
    WILDCARD.with(|w| *w.borrow_mut() = sym);
}

/// Registration entry point for the built-in transformer set (used by the expander).
pub struct BuiltinTransformers;

impl BuiltinTransformers {
    /// Initializes the marker symbols (the unique intern of ellipsis / wildcard).
    pub fn init_markers(table: &mut SymbolTable) {
        register_ellipsis(table);
        register_wildcard(table);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use kerf_span::Span;

    fn setup() -> (SymbolTable, Vec<Symbol>) {
        let mut t = SymbolTable::new();
        let syms = vec![
            t.intern("swap"),
            t.intern("let"),
            t.intern("x"),
            t.intern("y"),
            t.intern("tmp"),
            t.intern("do"),
            t.intern("assign"),
            t.intern("quote"),
        ];
        BuiltinTransformers::init_markers(&mut t);
        (t, syms)
    }

    fn sym_stx(s: Symbol) -> Stx {
        Stx::symbol(s, Span::dummy(), ScopeSet::new())
    }

    #[test]
    fn syntax_rules_parse_and_simple_match() {
        let (mut t, syms) = setup();
        // (syntax-rules () (swap a b) (do (assign tmp a) (assign a b) (assign b tmp)))
        // Build the pattern and template
        let a = t.intern("a");
        let b = t.intern("b");
        let pattern = Stx::list(
            vec![sym_stx(syms[0]), sym_stx(a), sym_stx(b)],
            Span::dummy(),
            ScopeSet::new(),
        );
        let template = Stx::list(
            vec![
                sym_stx(syms[5]), // do
                Stx::list(
                    vec![sym_stx(syms[6]), sym_stx(syms[5]), sym_stx(a)],
                    Span::dummy(),
                    ScopeSet::new(),
                ),
            ],
            Span::dummy(),
            ScopeSet::new(),
        );
        // Construct the SyntaxRules fields directly (the parse path is covered by expander
        // integration tests)
        let rules = SyntaxRules {
            literals: vec![],
            clauses: vec![(pattern, template)],
            def_scopes: ScopeSet::new(),
        };
        // Call (swap 1 2)
        let call_args = vec![
            Stx::literal(
                kerf_syntax::StxLiteral::Int(1),
                Span::dummy(),
                ScopeSet::new(),
            ),
            Stx::literal(
                kerf_syntax::StxLiteral::Int(2),
                Span::dummy(),
                ScopeSet::new(),
            ),
        ];
        let mut hygiene = HygieneCtx::new(&mut t);
        let out = rules.apply(&call_args, &mut hygiene).unwrap();
        // do kept; the pattern variable a substituted with 1
        let rendered = out.render(&|s| t.name(s).to_string());
        assert!(rendered.contains("do"));
        assert!(rendered.contains("assign"));
    }

    #[test]
    fn hygiene_renames_introduced_identifiers() {
        let (mut t, syms) = setup();
        // Template (assign tmp x): tmp is an introduced identifier (not a pattern variable)
        // → renamed
        let x = t.intern("x");
        let pattern = Stx::list(
            vec![sym_stx(syms[0]), sym_stx(x)],
            Span::dummy(),
            ScopeSet::new(),
        );
        let template = Stx::list(
            vec![
                sym_stx(syms[6]),
                sym_stx(syms[4]), /* tmp */
                sym_stx(x),
            ],
            Span::dummy(),
            ScopeSet::new(),
        );
        let rules = SyntaxRules {
            literals: vec![],
            clauses: vec![(pattern, template)],
            def_scopes: ScopeSet::new(),
        };
        let call_args = vec![Stx::literal(
            kerf_syntax::StxLiteral::Int(42),
            Span::dummy(),
            ScopeSet::new(),
        )];
        let mut hygiene = HygieneCtx::new(&mut t);
        let out = rules.apply(&call_args, &mut hygiene).unwrap();
        assert!(
            hygiene.renames() >= 1,
            "introduced identifiers must be renamed"
        );
        let rendered = out.render(&|s| t.name(s).to_string());
        assert!(
            rendered.contains("tmp$hyg$"),
            "introduced identifiers should be renamed to unique symbols: {}",
            rendered
        );
    }

    #[test]
    fn ellipsis_matches_zero_or_more() {
        let (mut t, _syms) = setup();
        let my_or = t.intern("my-or");
        let a = t.intern("a");
        let rest = t.intern("rest");
        // Pattern (my-or a rest ...)
        let pattern = Stx::list(
            vec![
                sym_stx(my_or),
                sym_stx(a),
                sym_stx(rest),
                sym_stx(ellipsis_sym(&t)),
            ],
            Span::dummy(),
            ScopeSet::new(),
        );
        // Template (do a rest ...)
        let template = Stx::list(
            vec![
                sym_stx(t.keyword_symbol(kerf_syntax::Keyword::Do)),
                sym_stx(a),
                sym_stx(rest),
                sym_stx(ellipsis_sym(&t)),
            ],
            Span::dummy(),
            ScopeSet::new(),
        );
        let rules = SyntaxRules {
            literals: vec![],
            clauses: vec![(pattern, template)],
            def_scopes: ScopeSet::new(),
        };
        // Call (my-or 1 2 3) → do 1 2 3
        let args: Vec<Stx> = [1i64, 2, 3]
            .iter()
            .map(|v| {
                Stx::literal(
                    kerf_syntax::StxLiteral::Int(*v),
                    Span::dummy(),
                    ScopeSet::new(),
                )
            })
            .collect();
        let mut hygiene = HygieneCtx::new(&mut t);
        let out = rules.apply(&args, &mut hygiene).unwrap();
        let rendered = out.render(&|s| t.name(s).to_string());
        assert_eq!(rendered, "(do 1 2 3)");
        // Zero-length ellipsis segment: (my-or 1) → do 1
        let one = vec![Stx::literal(
            kerf_syntax::StxLiteral::Int(1),
            Span::dummy(),
            ScopeSet::new(),
        )];
        let out0 = rules.apply(&one, &mut HygieneCtx::new(&mut t)).unwrap();
        assert_eq!(out0.render(&|s| t.name(s).to_string()), "(do 1)");
    }

    fn ellipsis_sym(_t: &SymbolTable) -> Symbol {
        ELLIPSIS.with(|e| *e.borrow())
    }
}

//! Phase separation system (stage0.md §8.9 / §12.3): physical isolation of Phase 0 / Phase 1.
//!
//! **Three key rules** (§8.9):
//! 1. Phase 1 code may only produce Phase 0 code; it must not directly execute Phase 0 code;
//! 2. Distinguish "instantiation" (running the module body) from "visiting" (running only the
//!    Phase 1 part);
//! 3. Phase propagation across transitive dependencies.
//!
//! The module lifecycle is managed through three operations: **declare / instantiate / visit**:
//! - declare: registers the module with its phase declarations (name + imports + exports);
//! - visit: runs only the Phase 1 part (macro transformer loading — in this Stage 0
//!   single-module implementation it corresponds to the assertion "the transformer registry is
//!   ready");
//! - instantiate: runs the module body (Phase 0 instantiation — corresponding to the compiler
//!   consuming CoreExpr).

use kerf_syntax::Symbol;

/// Phase level (Phase 0 = runtime, Phase 1 = macro-expansion time; higher phases are Stage 2+
/// evaluation).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub enum PhaseLevel {
    /// Phase 0: the runtime world.
    Runtime,
    /// Phase 1: the macro-expansion (compile-time) world.
    Expand,
}

impl PhaseLevel {
    /// Numeric phase value (for phase-propagation computation over transitive dependencies).
    pub fn as_u32(self) -> u32 {
        match self {
            PhaseLevel::Runtime => 0,
            PhaseLevel::Expand => 1,
        }
    }
}

/// Module registry entry (the product of declare).
#[derive(Debug, Clone)]
pub struct ModuleEntry {
    /// Module name.
    pub name: Symbol,
    /// Names of imported modules.
    pub imports: Vec<Symbol>,
    /// Exported symbols.
    pub exports: Vec<Symbol>,
    /// Whether visit (Phase 1 transformer loading) has completed.
    pub visited: bool,
    /// Whether instantiate (Phase 0 execution) has completed.
    pub instantiated: bool,
}

/// Module registry: runtime bookkeeping for phase separation (the driver invokes it at each
/// pipeline stage). Clone: compilation-cache reuse (Stage 1 batch C — snapshot semantics: the
/// phase marks set by instantiate only affect the copy returned on a hit, never polluting the
/// cached entry).
#[derive(Debug, Default, Clone)]
pub struct ModuleRegistry {
    entries: Vec<ModuleEntry>,
}

impl ModuleRegistry {
    pub fn new() -> Self {
        ModuleRegistry::default()
    }

    /// declare: registers the module with its phase declarations (duplicate declaration is an
    /// error — explicit failure, no silent overwrite).
    pub fn declare(
        &mut self,
        name: Symbol,
        imports: Vec<Symbol>,
        exports: Vec<Symbol>,
    ) -> Result<(), String> {
        if self.find(name).is_some() {
            return Err(format!("module duplicate declaration(Symbol {})", name.0));
        }
        self.entries.push(ModuleEntry {
            name,
            imports,
            exports,
            visited: false,
            instantiated: false,
        });
        Ok(())
    }

    /// visit: runs only the Phase 1 part (transformer loading).
    /// Rule 3 (phase propagation across transitive dependencies): all imported modules are
    /// visited first. Cycle detection: DFS gray marking — re-entry onto the current visit path
    /// is a circular dependency (§7.1.1 class 6: structured Err rather than an infinite-recursion
    /// stack overflow).
    pub fn visit(&mut self, name: Symbol) -> Result<(), String> {
        let mut path: Vec<Symbol> = Vec::new();
        self.visit_inner(name, &mut path)
    }

    fn visit_inner(&mut self, name: Symbol, path: &mut Vec<Symbol>) -> Result<(), String> {
        // Black nodes (already visited) are safe to re-enter: idempotent return (diamond
        // dependencies are legal)
        if let Some(entry) = self.find(name) {
            if entry.visited {
                return Ok(());
            }
        } else {
            return Err(format!("undeclared module (Symbol {})", name.0));
        }
        // Gray nodes (on the current DFS path) re-entered = circular dependency
        if let Some(pos) = path.iter().position(|&n| n == name) {
            let cycle: Vec<String> = path[pos..]
                .iter()
                .map(|n| format!("Symbol({})", n.0))
                .chain(std::iter::once(format!("Symbol({})", name.0)))
                .collect();
            return Err(format!("module circular dependency: {}", cycle.join(" → ")));
        }
        let imports: Vec<Symbol> = self.find(name).expect("checked above").imports.clone();
        path.push(name);
        for dep in imports {
            self.visit_inner(dep, path)?;
        }
        path.pop();
        let entry = self.find_mut(name).expect("checked above");
        entry.visited = true;
        Ok(())
    }

    /// instantiate: runs the module body (Phase 0 instantiation). Precondition: already visited.
    pub fn instantiate(&mut self, name: Symbol) -> Result<(), String> {
        let visited = self
            .find(name)
            .ok_or_else(|| format!("undeclared module (Symbol {})", name.0))?
            .visited;
        if !visited {
            return Err(format!(
                "module (Symbol {}) instantiated without visit -- phase violation",
                name.0
            ));
        }
        let entry = self.find_mut(name).expect("checked above");
        entry.instantiated = true;
        Ok(())
    }

    /// Looks up a module.
    pub fn find(&self, name: Symbol) -> Option<&ModuleEntry> {
        self.entries.iter().find(|e| e.name == name)
    }

    fn find_mut(&mut self, name: Symbol) -> Option<&mut ModuleEntry> {
        self.entries.iter_mut().find(|e| e.name == name)
    }

    /// All module entries.
    pub fn entries(&self) -> &[ModuleEntry] {
        &self.entries
    }

    /// Number of modules not yet instantiated (pipeline-completeness assertion).
    pub fn pending_instantiations(&self) -> usize {
        self.entries.iter().filter(|e| !e.instantiated).count()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn declare_visit_instantiate_lifecycle() {
        let mut reg = ModuleRegistry::new();
        reg.declare(Symbol(1), vec![], vec![Symbol(2)]).unwrap();
        // instantiate before visit → phase violation (explicit failure)
        assert!(reg.instantiate(Symbol(1)).is_err());
        reg.visit(Symbol(1)).unwrap();
        reg.instantiate(Symbol(1)).unwrap();
        assert_eq!(reg.pending_instantiations(), 0);
    }

    #[test]
    fn duplicate_declare_fails() {
        let mut reg = ModuleRegistry::new();
        reg.declare(Symbol(1), vec![], vec![]).unwrap();
        assert!(reg.declare(Symbol(1), vec![], vec![]).is_err());
    }

    #[test]
    fn circular_dependency_detected() {
        // §7.1.1 class 6: A imports B + B imports A → structured Err
        // (before the fix: an infinite-recursion stack overflow abort)
        let mut reg = ModuleRegistry::new();
        let a = Symbol(1);
        let b = Symbol(2);
        reg.declare(a, vec![b], vec![]).unwrap();
        reg.declare(b, vec![a], vec![]).unwrap();
        let err = reg.visit(a).unwrap_err();
        assert!(
            err.contains("module circular dependency"),
            "should report circular dependency:{}",
            err
        );
        assert!(err.contains("Symbol(1)"), "ring should contain A: {}", err);
        assert!(err.contains("Symbol(2)"), "ring should contain B: {}", err);
    }

    #[test]
    fn self_import_cycle_detected() {
        // Self-loop: A imports A
        let mut reg = ModuleRegistry::new();
        let a = Symbol(7);
        reg.declare(a, vec![a], vec![]).unwrap();
        assert!(reg
            .visit(a)
            .unwrap_err()
            .contains("module circular dependency"));
    }

    #[test]
    fn diamond_dependency_is_not_a_cycle() {
        // Diamond dependency is legal (D depends on B and C; B and C each depend on A) —
        // black-node re-entry is idempotent
        let mut reg = ModuleRegistry::new();
        let (a, b, c, d) = (Symbol(1), Symbol(2), Symbol(3), Symbol(4));
        reg.declare(a, vec![], vec![]).unwrap();
        reg.declare(b, vec![a], vec![]).unwrap();
        reg.declare(c, vec![a], vec![]).unwrap();
        reg.declare(d, vec![b, c], vec![]).unwrap();
        reg.visit(d).unwrap();
        assert!(reg.find(a).unwrap().visited);
        assert!(reg.find(b).unwrap().visited);
        assert!(reg.find(c).unwrap().visited);
        assert!(reg.find(d).unwrap().visited);
    }

    #[test]
    fn transitive_visit_order() {
        // m2 imports m1: visit(m2) must visit(m1) first
        let mut reg = ModuleRegistry::new();
        reg.declare(Symbol(1), vec![], vec![]).unwrap(); // m1
        reg.declare(Symbol(2), vec![Symbol(1)], vec![]).unwrap(); // m2
        reg.visit(Symbol(2)).unwrap();
        assert!(reg.find(Symbol(1)).unwrap().visited);
        assert!(reg.find(Symbol(2)).unwrap().visited);
    }

    #[test]
    fn visit_is_idempotent() {
        let mut reg = ModuleRegistry::new();
        reg.declare(Symbol(1), vec![], vec![]).unwrap();
        reg.visit(Symbol(1)).unwrap();
        reg.visit(Symbol(1)).unwrap();
    }
}

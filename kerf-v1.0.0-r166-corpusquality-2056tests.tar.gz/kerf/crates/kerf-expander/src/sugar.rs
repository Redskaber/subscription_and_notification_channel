//! Built-in syntactic sugar transformers (stage0.md §3.2 derivation table; split from
//! expander.rs per TD-012).
//!
//! **Responsibility narrowing after r101 / 171-c (derived-keyword macro-ization)**: seven of the
//! eight sugars (when/unless/and/or/let\*/cond/while) have migrated to the syntax-rules macro
//! definitions in `derived.rs` (single S-expression source — the `TransformerKind::Derived`
//! channel: form validators + macro expansion); this module now only hosts:
//! - the `letrec` built-in transformer (kept as `TransformerKind::Builtin`) — **honest
//!   boundary**: in its derivation shape `((fn (f...) (do (assign f e)... body...)) nil nil
//!   ...)` the nil arguments must be repeated once per binding, and iterating a literal by
//!   sequence length is **inexpressible** on the depth-1 ellipsis template surface (a
//!   limitation of the same family as R7RS syntax-rules — the same boundary family as the
//!   deferred TD-005 nested-ellipsis / syntax-parse items, honestly registered rather than
//!   silently degraded);
//! - the historical derivation-shape comment surface (Rust-side reference for the shape contract).
//!
//! **r50-β / D61 (direct let mapping)**: `let` leaves the sugar table (nine sugars → eight
//! sugars) — `(let ...)` goes straight to the core form `expand_let` (core_forms.rs) which
//! maps directly to `CoreExpr::Let` (multi-binding staging preserving parallel semantics).
//!
//! Convention: `desugar_letrec` is the carrier of `TransformerKind::Builtin` (identical
//! signature). Introduced identifiers (loop/tmp etc.) are uniquified through the instantiate
//! α-channel on the macro path; this function has no introduced identifiers (names are user
//! symbols).

use kerf_syntax::Stx;

use crate::expander::{kw_symbol, nil_stx, WORD_BEGIN, WORD_LAMBDA, WORD_SETBANG};

pub(crate) fn desugar_letrec(
    args: &[Stx],
    _h: &mut crate::macro_sys::HygieneCtx,
) -> Result<Stx, String> {
    // (letrec ((f e)...) body...) → ((lambda (f...) (begin (set! f e)... body...)) nil...)
    if args.len() < 2 {
        return Err("letrec form: (letrec ((name value)...) body...)".to_string());
    }
    let bindings = args[0]
        .datum
        .as_list()
        .ok_or("letrec binding group must be a list")?;
    let span = args[0].span;
    let scopes = args[0].scopes.clone();
    let mut names = Vec::new();
    let mut sets = Vec::new();
    for b in bindings {
        let pair = b
            .datum
            .as_list()
            .filter(|p| p.len() == 2)
            .ok_or("letrec binding must be (name value) two-element list")?;
        let name = pair[0]
            .datum
            .as_symbol()
            .ok_or("letrec binding name must be a symbol")?;
        names.push(name);
        sets.push(Stx::list(
            vec![
                Stx::symbol(kw_symbol(&WORD_SETBANG), span, scopes.clone()),
                Stx::symbol(name, pair[0].span, scopes.clone()),
                pair[1].clone(),
            ],
            pair[0].span,
            scopes.clone(),
        ));
    }
    let mut inner = vec![Stx::symbol(kw_symbol(&WORD_BEGIN), span, scopes.clone())];
    inner.extend(sets);
    inner.extend(args[1..].iter().cloned());
    let body = Stx::list(inner, span, scopes.clone());
    let param_list = Stx::list(
        names
            .iter()
            .map(|n| Stx::symbol(*n, span, scopes.clone()))
            .collect(),
        span,
        scopes.clone(),
    );
    let lambda = Stx::list(
        vec![
            Stx::symbol(kw_symbol(&WORD_LAMBDA), span, scopes.clone()),
            param_list,
            body,
        ],
        span,
        scopes.clone(),
    );
    // app = (lambda nil nil ...) — nil arguments are laid out flat (do not wrap in a list!)
    let mut app_items: Vec<Stx> = vec![lambda];
    for _ in names {
        app_items.push(nil_stx(span));
    }
    Ok(Stx::list(app_items, span, scopes))
}

//! Multi-error collection and form-level recovery expansion (TD-013 implementation — batch G /
//! 38-e).
//!
//! Per the r7 design (stage-1/multi-error-recovery-design.md, Accepted):
//! - **Recovery granularity = top-level forms**: one form fails to expand → the diagnostic goes
//!   into the collector → skip that form → continue with subsequent forms (kerf top-level forms
//!   carry no implicit data flow — forms are naturally independent); no expression-level
//!   recovery (rebuilding the state of a half-expanded Stx tree costs out of proportion);
//! - **Collection cap of 128**: diagnostic-storm protection (macro-template cascades) + a
//!   truncation flag;
//! - **Export ordering**: stable sort by `(file_id, start, end)` — multi-error output order
//!   aligns with source positions (same ordering discipline as `check_program`);
//! - **Compile-time control flow** (not an effect — §11 interface isolation); the run/eval
//!   execution paths do not recover (runtime state cannot be rolled back).
//!
//! A recovery entry point alongside [`crate::expander::expand_program`] (single-error
//! short-circuit — the production run/eval paths stay unchanged); the dual expanders (seed /
//! self-hosting bridge) implement it isomorphically, aligned with parity discipline.

use std::cmp::Ordering;

use kerf_core::ModuleItem;
use kerf_syntax::Stx;

use crate::expander::{ExpandCtxt, ExpandError};

/// Diagnostic collection cap (r7 design §2 — diagnostic-storm protection).
pub const MAX_DIAGNOSTICS: usize = 128;

/// Multi-error collector (r7 design §3 contract — a Diagnostic is data, §8.7).
#[derive(Debug, Clone, Default)]
pub struct DiagCollector {
    diags: Vec<ExpandError>,
    truncated: bool,
}

impl DiagCollector {
    /// Appends a diagnostic (over the cap → set truncated, do not store).
    pub fn push(&mut self, e: ExpandError) {
        if self.diags.len() >= MAX_DIAGNOSTICS {
            self.truncated = true;
            return;
        }
        self.diags.push(e);
    }

    /// Early-termination signal for the recovery loop (full).
    pub fn is_full(&self) -> bool {
        self.diags.len() >= MAX_DIAGNOSTICS
    }

    /// Explicitly sets the truncation flag (the recovery loop terminates early at the cap —
    /// remaining forms being dropped is exactly when truncation happens; 38-e field-tested
    /// erratum: the break path does not go through the push branch).
    pub fn mark_truncated(&mut self) {
        self.truncated = true;
    }

    /// Number collected so far.
    pub fn len(&self) -> usize {
        self.diags.len()
    }

    /// Whether nothing has been collected.
    pub fn is_empty(&self) -> bool {
        self.diags.is_empty()
    }

    /// Whether truncation happened (errors were still being dropped after the cap was reached).
    pub fn truncated(&self) -> bool {
        self.truncated
    }

    /// Exports stably sorted by `(file_id, start, end)` (aligned with source positions — same
    /// ordering discipline as `check_program`).
    pub fn into_sorted(mut self) -> Vec<ExpandError> {
        self.diags.sort_by(|a, b| span_order(&a.span, &b.span));
        self.diags
    }
}

/// Span ordering key (file_id → start → end).
fn span_order(a: &kerf_span::Span, b: &kerf_span::Span) -> Ordering {
    a.file_id
        .cmp(&b.file_id)
        .then(a.start.cmp(&b.start))
        .then(a.end.cmp(&b.end))
}

/// Recovery-expansion product: partial `ModuleItem`s + a diagnostic collector (errors and
/// products coexist — the established shape of the consumption table in r7 design §5;
/// itemized in r49 D59).
#[derive(Debug, Clone, Default)]
pub struct RecoveredExpansion {
    /// Expansion products of successful forms (failing forms are skipped — not included in
    /// the products).
    pub core: Vec<ModuleItem>,
    /// Diagnostics of failing forms (in push order; exported via [`DiagCollector::into_sorted`]).
    pub diags: DiagCollector,
}

impl RecoveredExpansion {
    /// Whether the recovery ran error-free throughout (an empty collector = equivalent to the
    /// short-circuit path).
    pub fn is_clean(&self) -> bool {
        self.diags.is_empty()
    }
}

/// Form-level recovery expansion (the seed Expander path).
///
/// Per-form item classification (r49 D59 — the same classifier as `expand_program`: declaration
/// heads / do-splices / expression items; recovery granularity = top-level forms [a failing
/// splice is skipped as a whole]): a single failing form → collect + skip + continue; collector
/// full → early termination (diagnostic-storm protection). The phase/transformer bookkeeping in
/// ExpandCtxt persists across successful forms (form-level skipping does not roll back completed
/// registrations — a skipped form affects subsequent forms only "when a skipped binding is
/// referenced", producing new errors, which is the correct cost of recovery semantics).
pub fn expand_program_recover(forms: &[Stx], ctx: &mut ExpandCtxt) -> RecoveredExpansion {
    let mut out = RecoveredExpansion::default();
    for form in forms {
        if out.diags.is_full() {
            // Cap protection: early termination — remaining forms being dropped is exactly
            // truncation (explicit flag: the break path does not go through push's truncation
            // branch, 38-e erratum)
            out.diags.mark_truncated();
            break;
        }
        // Item classification (a classifier-internal error → collect + skip that top-level form)
        match crate::expander::classify_program_form_recover(form, ctx) {
            Ok(items) => out.core.extend(items),
            Err(e) => out.diags.push(e),
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::expander::ExpandCtxt;

    #[test]
    fn recover_skips_failing_forms_and_continues() {
        // good form (define) / bad form (empty list — expansion error) / good form:
        // the middle error is collected while the surrounding defines expand normally
        // (the skeleton of r7 acceptance case 1)
        let mut table = kerf_syntax::SymbolTable::new();
        let forms = vec![
            list_form(&["define", "x", "1"], &mut table), // legal definition
            Stx::list(
                Vec::new(),
                kerf_span::Span::dummy(),
                kerf_syntax::ScopeSet::new(),
            ), // empty — expand error
            list_form(&["define", "y", "2"], &mut table), // legal definition
        ];
        let mut ctx = ExpandCtxt::new(table);
        let r = expand_program_recover(&forms, &mut ctx);
        assert_eq!(r.diags.len(), 1, "intermediate form should error");
        assert_eq!(
            r.core.len(),
            2,
            "before/after definitions should expand normally"
        );
        assert!(!r.is_clean());
    }

    /// Builds a list form (define sugar — symbol interning).
    fn list_form(names: &[&str], table: &mut kerf_syntax::SymbolTable) -> Stx {
        let items: Vec<Stx> = names
            .iter()
            .map(|n| {
                let sym = table.intern(n);
                Stx::symbol(sym, kerf_span::Span::dummy(), kerf_syntax::ScopeSet::new())
            })
            .collect();
        Stx::list(
            items,
            kerf_span::Span::dummy(),
            kerf_syntax::ScopeSet::new(),
        )
    }

    #[test]
    fn collector_cap_at_128_with_truncation_flag() {
        let mut c = DiagCollector::default();
        for i in 0..MAX_DIAGNOSTICS + 10 {
            c.push(ExpandError {
                message: format!("err-{}", i),
                span: kerf_span::Span::dummy(),
            });
        }
        assert_eq!(c.len(), MAX_DIAGNOSTICS);
        assert!(c.truncated());
        assert!(c.is_full());
    }

    #[test]
    fn collector_sorted_by_span_position() {
        let mut c = DiagCollector::default();
        let mk = |start: u32| kerf_span::Span {
            file_id: 0,
            start,
            end: start + 1,
            expansion_id: 0,
        };
        c.push(ExpandError {
            message: "late".into(),
            span: mk(90),
        });
        c.push(ExpandError {
            message: "early".into(),
            span: mk(10),
        });
        c.push(ExpandError {
            message: "mid".into(),
            span: mk(50),
        });
        let sorted = c.into_sorted();
        let starts: Vec<u32> = sorted.iter().map(|e| e.span.start).collect();
        assert_eq!(starts, vec![10, 50, 90]);
    }

    #[test]
    fn collector_empty_and_not_full_defaults() {
        let c = DiagCollector::default();
        assert!(c.is_empty());
        assert!(!c.is_full());
        assert!(!c.truncated());
        assert_eq!(c.len(), 0);
    }
}

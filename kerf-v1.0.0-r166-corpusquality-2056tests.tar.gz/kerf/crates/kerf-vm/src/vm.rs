//! Bytecode VM: the switch-dispatch execution loop (stage0.md §8.12 / §19.5).
//!
//! **VM state** (§8.12): code (protos), data stack, call stack, global
//! environment, constant pool, debug info tables (the first four live in
//! this struct; the last two are referenced via `BcProgram`).
//!
//! **Call-frame three extension slots** (§8.12 — format frozen; Stage 0 may
//! leave them empty but the format is locked):
//! - `ext1`: reserved for continuation / effect handler;
//! - `ext2`: reserved for the exception handler table;
//! - `ext3`: reserved for debug frame info.
//!
//! **Execution loop skeleton** (§19.5):
//! - fetch-decode (pc auto-increments; pc changes only on JUMP/RET/CALL —
//!   invariant 2);
//! - runtime errors map pc back to a Span via debug_info_table[pc] to build
//!   a stack trace;
//! - the allocation-quota check at the end of each loop iteration = the GC
//!   safepoint (§19.4 pitfall 2).
//!
//! **Iterative main loop**: kerf recursion is carried on the (heap-allocated)
//! frame stack — Rust stack depth stays constant, so deep recursion is no
//! longer bound by the host stack (frame-count cap 100_000 as an explicit
//! guard).

use std::any::Any;
use std::collections::{HashMap, HashSet};
use std::rc::Rc;

use kerf_compiler::{BcConst, BcProgram, BcProto, Op};
use kerf_runtime::{BoxedInput, ForeignBox, GcRef, Heap, RootSet};
use kerf_span::Span;
use kerf_syntax::Symbol;

use crate::value::{BuiltinFn, ClosureValue, GcCell, Value};

/// Runtime context (the heap holder).
pub struct Rt {
    pub heap: Heap,
}

impl Rt {
    /// Constructor (GC on — the VM-path semantics).
    pub fn new(heap: Heap) -> Self {
        Rt { heap }
    }
}

/// Effect handler frame data (r25/42-f — D6 ext1 concretization: the
/// `ContinuationSlot` reserved slot activated, zero structural change —
/// principle 27's reserved-interface timing honored).
///
/// Carries the dispatch entries + data stack watermark at install time:
/// after the perform scan matches, the handler frame is transformed
/// accordingly and the data stack truncated back (outer intermediate values
/// preserved; the suspended frame chain / intermediate values are already
/// saved into the continuation snapshot).
///
/// r136 / 206-b (TD-033 — D14): the single `tag`/`handler_proto`/`captures`
/// triple generalized to `entries` (multi-tag matching + group consumption —
/// `InstallHandler` builds a 1-entry frame, zero behavioral change; the D1
/// zero-regression anchor).
#[derive(Debug, Clone)]
pub struct HandlerFrame {
    /// Dispatch entries (>=1; any-entry match dispatches; the whole group
    /// is consumed on dispatch — the matched frame is replaced by the H
    /// execution frame, sibling entries die with it).
    pub entries: Vec<HandlerEntry>,
    /// Data stack depth at install time (the dispatch truncation watermark
    /// — R11-dispatch).
    pub stack_watermark: usize,
}

/// One dispatch entry of a `HandlerFrame` (r136 / 206-b — D14; the former
/// flat triple — the 1-entry degenerate is bit-identical to the pre-r136
/// single-arm shape).
#[derive(Debug, Clone)]
pub struct HandlerEntry {
    /// Effect family tag (the match dispatch key — the same `Rc<str>` shape
    /// as symbol literals, same carrier as `CoreExpr::Handle.tag` /
    /// `Value::Symbol`).
    pub tag: Rc<str>,
    /// Handler prototype (params = [payload_var, resume_var]).
    pub handler_proto: u32,
    /// Handler prototype capture cells (shared mutable — the same mechanism
    /// as Closure captures; on dispatch transformation they serve as the H
    /// execution frame's captures).
    pub captures: Vec<Rc<GcCell>>,
}

/// Structural equality (needed by FrameExt's derive): entries by value
/// (tag / prototype; captures by cell pointer — two clones of the same
/// install point share and are equal; different install points with the
/// same structure are unequal — frame identity semantics).
impl PartialEq for HandlerFrame {
    fn eq(&self, other: &Self) -> bool {
        self.stack_watermark == other.stack_watermark
            && self.entries.len() == other.entries.len()
            && self.entries.iter().zip(other.entries.iter()).all(|(a, b)| {
                a.tag == b.tag
                    && a.handler_proto == b.handler_proto
                    && a.captures.len() == b.captures.len()
                    && a.captures
                        .iter()
                        .zip(b.captures.iter())
                        .all(|(x, y)| Rc::ptr_eq(x, y))
            })
    }
}
impl Eq for HandlerFrame {}

/// Reserved slot type (ext2: the exception handler table).
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct HandlerTableSlot;

/// Reserved slot type (ext3: debug frame info).
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct DebugFrameSlot;

/// Call frame extension (three-slot frozen format; ext1 was concretized in
/// r25/42-f as the effect handler frame — the D6 reserved slot activated;
/// `Copy` revoked (ext1 carries an `Rc`)).
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct FrameExt {
    /// ext1: effect handler frame (None = not installed).
    pub ext1: Option<Rc<HandlerFrame>>,
    /// ext2: exception handler table (empty in Stage 0).
    pub ext2: Option<HandlerTableSlot>,
    /// ext3: debug frame info (empty in Stage 0).
    pub ext3: Option<DebugFrameSlot>,
}

impl FrameExt {
    /// Three-slot constructor (§19.5 `FrameExt::new()`).
    pub fn new() -> Self {
        FrameExt::default()
    }
}

/// Call frame.
#[derive(Debug, Clone)]
pub struct Frame {
    /// Return prototype index.
    pub ret_proto: usize,
    /// Return pc.
    pub ret_pc: u32,
    /// Prototype index executed by this frame.
    pub proto: usize,
    /// Local slots (parameters + let bindings) — **shared cells** (capture
    /// semantics: set! propagates to closures via `Rc<GcCell>`, letrec
    /// recursion works; TD-023 heap-root summary).
    pub locals: Vec<Rc<GcCell>>,
    /// Closure capture slots (shared mutable cells).
    pub captures: Vec<Rc<GcCell>>,
    /// Three extension slots (format frozen).
    pub ext: FrameExt,
    /// Call-site Span (for stack traces).
    pub call_span: Span,
}

/// Stack trace frame.
#[derive(Debug, Clone)]
pub struct TraceFrame {
    /// Prototype name symbol.
    pub proto_name: Option<Symbol>,
    /// Location.
    pub span: Span,
}

/// VM execution error (with stack trace — §8.12 runtime error capture).
#[derive(Debug, Clone)]
pub struct VmError {
    pub message: String,
    pub span: Span,
    pub trace: Vec<TraceFrame>,
    /// Structured diagnostic code (None = the E0004 runtime generic family;
    /// r25/42-f effect-family E0007-E0009 carry codes — the driver-layer
    /// `from_vm` maps on this).
    pub code: Option<u32>,
}

impl VmError {
    /// Constructor (shared inside the crate + by the ffi boundary wrapping
    /// layer — the E0004 generic family).
    pub(crate) fn new(message: impl Into<String>, span: Span) -> Self {
        VmError {
            message: message.into(),
            span,
            trace: Vec::new(),
            code: None,
        }
    }

    /// Constructor with structured code (E0007-E0009 effect family +
    /// E0010-E0012 FFI family — paired with single-sourced messages).
    pub(crate) fn new_code(code: u32, message: impl Into<String>, span: Span) -> Self {
        VmError {
            message: message.into(),
            span,
            trace: Vec::new(),
            code: Some(code),
        }
    }

    /// Render the stack trace (human-legible output).
    pub fn render_trace(&self, resolve: &dyn Fn(Symbol) -> String) -> String {
        let mut out = format!("runtime error: {}\n at {}\n", self.message, self.span);
        for t in &self.trace {
            let name = t.proto_name.map(resolve).unwrap_or_else(|| "<main>".into());
            out.push_str(&format!("  called from {} ({})\n", name, t.span));
        }
        out
    }
}

/// Frame-count cap (the explicit cap guarding runaway recursion under the
/// iterative loop).
pub const MAX_FRAMES: usize = 100_000;

/// Instruction budget cap (TD-022/H2 — the TCO tail-loop guard): infinite
/// tail loops whose frame count no longer grows (e.g. `(define (l) (l))`)
/// are caught by the instruction budget (a structured error, not a hang).
/// Magnitude calibration: gc_stress ≈ 5×10^5 / the bootstrap Reader on
/// 100KB of source ≈ 10^7 — so 10^9 = two orders of magnitude of margin
/// (an execution cap on the order of tens of seconds, catching genuinely
/// infinite loops).
pub const MAX_INSTRUCTIONS: u64 = 1_000_000_000;

/// GC safepoint polling interval (instruction count).
const GC_POLL_INTERVAL: u64 = 256;

/// GC cooldown multiplier: polling backoff when collection yield is low
/// (high survival rate) (prevents root-set scanning from degenerating to
/// O(n²) under deep recursion — root set O(frames) × polling
/// O(instructions/interval)).
const GC_COOLDOWN_MULTIPLIER: u64 = 64;

/// Program execution entry point (§10.1 rule 1 free function).
///
/// `vm::run(&bytecode, &mut runtime)` shape: the global environment is a
/// parameter (passed in after the driver registers builtins; returns the
/// final value).
///
/// **FFI face (r30/48-d)**: this entry point's extern symbol table = **the
/// empty table** (fail-closed: any FFI opcode executed through this entry
/// → E0012 symbol resolution failure — the production run path has no FFI
/// registration face). Execution faces with foreign-function registration
/// go through [`run_program_with_externs`]; bootstrap modules
/// (Reader/Expander/Compiler) contain no FFI opcodes — `call_closure`
/// maintains the same empty-table criterion.
/// Frame local-slot allocation (r45/E5 S3 structural arm — D41: Let
/// binding slot extension).
///
/// Slot layout: parameters occupy the first k slots (filled in call
/// order), Let binding slots fill up to `n_locals` (nil-initialized — the
/// defensive semantics that a slot is unreadable before `Op::StoreLocal`
/// writes it; aligned with the eval path's `Env` lexical model — the T1
/// dual-path criterion).
fn alloc_local_cells(n_locals: u32, args: Vec<Value>) -> Vec<Rc<GcCell>> {
    let mut cells: Vec<Rc<GcCell>> = args.into_iter().map(|v| Rc::new(GcCell::new(v))).collect();
    while cells.len() < n_locals as usize {
        cells.push(Rc::new(GcCell::new(Value::Nil)));
    }
    cells
}

/// n_locals slot allocation for zero-argument frames (thunk/main/sentinel
/// frames — nil-filled).
fn nil_local_cells(n_locals: u32) -> Vec<Rc<GcCell>> {
    alloc_local_cells(n_locals, Vec::new())
}

/// P1 (r55/TD-028 frame-slot pool): frame-slot pool depth cap
/// (anti-bloat against deep-recursion full drains — steady-state hits in
/// hot loops only need pool depth 1-2; a few re-entry misses after peak
/// truncation are acceptable).
const CELL_POOL_CAP: usize = 256;

/// r165 / 236-c (variadic-rest-design.md D4-a): the call-face arity gate —
/// rest prototypes take a **minimum** arity (the fixed prefix) with no
/// upper bound; fixed prototypes keep the exact-match face. `Some(msg)` =
/// the mismatch diagnostic (the rest form's message carries "at least").
fn arity_mismatch(target: &BcProto, n_args: usize) -> Option<String> {
    match target.rest_slot {
        Some(_) if n_args < target.params.len() => Some(format!(
            "procedure argument count mismatch: expected at least {}, got {}",
            target.params.len(),
            n_args
        )),
        None if target.params.len() != n_args => Some(format!(
            "procedure argument count mismatch: expected {}, got {}",
            target.params.len(),
            n_args
        )),
        _ => None,
    }
}

/// r165 / 236-c (D4-b): fold the excess arguments into the rest binding's
/// nil-terminated pair chain (right-fold — argument order preserved; the
/// `list` builtin's construction discipline: box each element, chain onto
/// the boxed-nil terminator). Zero excess = the plain nil value (the empty
/// list's value form). Called AFTER the min-arity gate; the packed vector
/// (fixed args + the chain at the rest slot position) then flows through
/// the existing cell machinery unchanged.
fn pack_rest_args(target: &BcProto, mut args: Vec<Value>, heap: &mut Heap) -> Vec<Value> {
    if let Some(slot) = target.rest_slot {
        let k = target.params.len();
        debug_assert_eq!(
            slot as usize, k,
            "rest slot = params.len() (the lowering-side append invariant)"
        );
        if args.len() > k {
            let mut chain = heap.alloc_boxed(BoxedInput::Nil);
            while args.len() > k {
                let head = args.pop().expect("guarded by len > k");
                let elem = box_value(&head, heap);
                chain = heap.alloc_pair(elem, chain);
            }
            args.push(Value::Pair(chain));
        } else {
            // exactly k arguments — the rest binding is the empty list
            args.push(Value::Nil);
        }
    }
    args
}

/// P1 (r55/TD-028 frame-slot pool): take a slot set from the pool.
///
/// Behavioral identity (vs [`alloc_local_cells`] — the four arguments of
/// td028-frame-pool-optimization §3.3): ① on a pool hit the reused cells
/// are overwritten with the arguments (`GcCell::set` maintains the
/// heap-root summary — the same TD-023 path); ② on an empty pool / length
/// mismatch it falls back to the fresh-allocation path; ③ the produced
/// slot set is slot-for-slot identical (argument slots = actual argument
/// values, Let slots = the unchanged nil defensive semantics). A pooled
/// cell's identity is unobservable: the return condition
/// `strong_count == 1` guarantees no captures / continuation-snapshot
/// leakage — identity is observable only under Rc sharing (TD-023 capture
/// semantics + the r25 snapshot-frame semantics).
///
/// P3 (r55 protocol optimization — slot-cleaning division of labor):
/// release clears only heap-reference slots (`has_heap`); acquire clears
/// only Let slots beyond the argument positions — the full-argument
/// overwrite case (n_locals == args.len(), e.g. fib) does zero slot
/// clearing on either side. Correctness: leftover non-heap non-nil values
/// (Int/Bool) in the pool are harmless to the GC (zero heap references)
/// and are always covered by the acquire side's clear/overwrite discipline
/// (the defensive semantics "unwritten slot = nil" is guaranteed on the
/// acquire side, not the release side).
fn acquire_local_cells(
    pool: &mut Vec<Vec<Rc<GcCell>>>,
    n_locals: u32,
    args: Vec<Value>,
) -> Vec<Rc<GcCell>> {
    let n = n_locals as usize;
    if let Some(mut cells) = pool.pop() {
        if cells.len() > n {
            cells.truncate(n);
        }
        while cells.len() < n {
            cells.push(Rc::new(GcCell::new(Value::Nil)));
        }
        let k = args.len();
        for (i, v) in args.into_iter().enumerate() {
            if i < n {
                cells[i].set(v);
            }
        }
        // P3: Let slots (beyond the argument positions) cleared to nil —
        // the defensive semantics (unwritten slot = nil) is a discipline of
        // the acquire side; leftover non-heap values in the pool are
        // overwritten here.
        for cell in cells.iter_mut().skip(k) {
            cell.set(Value::Nil);
        }
        cells
    } else {
        alloc_local_cells(n_locals, args)
    }
}

/// P1 (r55/TD-028 frame-slot pool): return frame slots to the pool.
///
/// Two guardrails: ① all slots `strong_count == 1` (the frame is the sole
/// holder — any sharing (closure capture / continuation snapshot) → the
/// whole Vec is discarded via the original drop path, zero behavioral
/// difference); ② clear heap-reference slots (P3: only `has_heap` cells
/// get set(Nil) — zero heap references in pooled cells is the necessary
/// condition for GC dangling safety: the pool is not a root set, and a
/// pooled cell holding heap references would dangle when reused after GC
/// reclamation; leftover non-heap slot values are governed by the acquire
/// side's clear/overwrite discipline).
fn release_local_cells(pool: &mut Vec<Vec<Rc<GcCell>>>, cells: Vec<Rc<GcCell>>) {
    if cells.is_empty() || pool.len() >= CELL_POOL_CAP {
        return; // an empty frame (trampoline sentinel) yields no benefit; a full pool drops directly
    }
    for c in &cells {
        if Rc::strong_count(c) != 1 {
            return; // shared → the whole Vec is discarded (original drop path)
        }
    }
    for c in &cells {
        if c.has_heap() {
            c.set(Value::Nil);
        }
    }
    pool.push(cells);
}

pub fn run_program(
    program: &BcProgram,
    globals: &mut HashMap<Symbol, Value>,
    heap: &mut Heap,
) -> Result<Value, VmError> {
    let externs = crate::ffi::ExternSymbolTable::new();
    run_program_frames(program, globals, heap, &externs)
}

/// Execution entry point with an extern symbol table (r30/48-d — the FFI
/// registration face: the driving entry of the
/// [`crate::ffi::call_external`] window protocol).
///
/// Semantics are isomorphic to [`run_program`]; the only difference is the
/// symbol-resolution domain of FFI opcodes (the extern symbol table — a
/// flat symbol space, ffi-ownership-model §4). An unregistered symbol =
/// E0012 (fail-closed — the VM-path call-time counterpart of QBE AOT
/// link-time resolution).
pub fn run_program_with_externs(
    program: &BcProgram,
    globals: &mut HashMap<Symbol, Value>,
    heap: &mut Heap,
    externs: &crate::ffi::ExternSymbolTable,
) -> Result<Value, VmError> {
    run_program_frames(program, globals, heap, externs)
}

/// Program execution frame initialization + trace snapshot (the shared
/// body of the run_program family).
fn run_program_frames(
    program: &BcProgram,
    globals: &mut HashMap<Symbol, Value>,
    heap: &mut Heap,
    externs: &crate::ffi::ExternSymbolTable,
) -> Result<Value, VmError> {
    let mut frames: Vec<Frame> = vec![Frame {
        ret_proto: 0,
        ret_pc: 0,
        proto: program.entry as usize,
        locals: nil_local_cells(program.protos[program.entry as usize].n_locals),
        captures: Vec::new(),
        ext: FrameExt::new(),
        call_span: Span::dummy(),
    }];
    let outcome = execute(
        program,
        globals,
        heap,
        &mut frames,
        MAX_INSTRUCTIONS,
        externs,
    );
    outcome.map_err(|mut e| {
        // Call-site trace (§8.12 runtime error capture): the active frame
        // chain at error time. Skip the main frame; keep the innermost 16
        // frames (outer frames carry no information under deep recursion,
        // preventing diagnostic explosion); frame order = call-time order
        // (outer→inner), consistent with render_trace's "called from"
        // chain.
        if e.trace.is_empty() && frames.len() > 1 {
            let start = frames.len().saturating_sub(MAX_TRACE_FRAMES).max(1);
            e.trace = frames[start..]
                .iter()
                .map(|f| TraceFrame {
                    proto_name: Some(program.protos[f.proto].name),
                    span: f.call_span,
                })
                .collect();
        }
        e
    })
}

/// Call-site trace truncation cap (deep-recursion diagnostic explosion
/// prevention — keep only the innermost N frames).
const MAX_TRACE_FRAMES: usize = 16;

/// Budget-parameterized execution entry point (TD-022/H2 — the test face):
/// isomorphic to [`run_program`], but the instruction budget is injectable
/// (infinite tail-loop negative cases use a small budget to trigger the
/// guard quickly — the same shape as 38-c find_qbe's pure-function
/// injection). Production paths always use [`MAX_INSTRUCTIONS`]. FFI face:
/// the empty-table fail-closed criterion (same as [`run_program`] — budget
/// tests do not consume FFI opcodes).
#[doc(hidden)]
pub fn run_program_with_budget(
    program: &BcProgram,
    globals: &mut HashMap<Symbol, Value>,
    heap: &mut Heap,
    max_instructions: u64,
) -> Result<Value, VmError> {
    let externs = crate::ffi::ExternSymbolTable::new();
    run_program_with_budget_inner(program, globals, heap, max_instructions, &externs)
}

/// Budget entry inner body (externs-parameterized — the test injection
/// face).
#[doc(hidden)]
pub fn run_program_with_budget_inner(
    program: &BcProgram,
    globals: &mut HashMap<Symbol, Value>,
    heap: &mut Heap,
    max_instructions: u64,
    externs: &crate::ffi::ExternSymbolTable,
) -> Result<Value, VmError> {
    let mut frames: Vec<Frame> = vec![Frame {
        ret_proto: 0,
        ret_pc: 0,
        proto: program.entry as usize,
        locals: nil_local_cells(program.protos[program.entry as usize].n_locals),
        captures: Vec::new(),
        ext: FrameExt::new(),
        call_span: Span::dummy(),
    }];
    execute(
        program,
        globals,
        heap,
        &mut frames,
        max_instructions,
        externs,
    )
}

/// Host-side closure call entry point (used by host consumers such as the
/// bootstrap Reader, B3).
///
/// Semantics: enters the execution loop with a "function entry frame" —
/// the callee must be a bytecode closure produced by compiling **this
/// program**; arguments are injected into local slots; the bottom frame's
/// RET is this call's return value. The error path is isomorphic to
/// [`run_program`] (active frame-chain snapshot → call-site trace).
///
/// Boundary (§11 interface isolation): this entry point is a peer of
/// run_program — programmatic calls by the host trust layer into an
/// already-loaded program; recursive re-entry from inside builtins remains
/// forbidden (the P5 veto stands); eval-path closures are unsupported (the
/// dual path exists for cross-checking; host calls go through bytecode).
pub fn call_closure(
    program: &BcProgram,
    globals: &mut HashMap<Symbol, Value>,
    heap: &mut Heap,
    callee: &Value,
    args: Vec<Value>,
) -> Result<Value, VmError> {
    let (proto, captures) = match callee {
        Value::Closure(rc) => match rc.as_ref() {
            ClosureValue::Bytecode { proto, captures } => (*proto, captures.clone()),
            // Reason for the eval arm: the dual-path cross-check design (T1)
            // — eval closures belong to the tree-walk path; host
            // programmatic calls support only the bytecode form
            ClosureValue::Eval { .. } => {
                return Err(VmError::new(
                    "call_closure does not support eval path closures (host calls go through the bytecode path)",
                    Span::dummy(),
                ))
            }
        },
        // Reason for the other arm: non-closure values (int/str/builtin, etc.)
        // have no prototype to enter
        other => {
            return Err(VmError::new(
                format!("call_closure requires closure, got {}", other.type_name()),
                Span::dummy(),
            ))
        }
    };
    // Prototype out-of-bounds defense: cross-program closures (prototype
    // index pointing into another program) are not callable — an explicit
    // error rather than an out-of-bounds panic (§2.3-4 error>silence; the
    // runtime face of the P3 veto)
    let proto_idx = proto as usize;
    if proto_idx >= program.protos.len() {
        return Err(VmError::new(
            format!(
                "closure prototype index out of bounds: proto {} / total {}(cross-program closure uncallable)",
                proto,
                program.protos.len()
            ),
            Span::dummy(),
        ));
    }
    let target = &program.protos[proto_idx];
    if let Some(msg) = arity_mismatch(target, args.len()) {
        return Err(VmError::new(msg, Span::dummy()));
    }
    // Arguments into cells (the frame foundation of capture-sharing
    // semantics — isomorphic to CALL; GcCell carries the heap-root summary
    // flag, TD-023; Let binding slots extended per n_locals — r45)
    let local_cells = alloc_local_cells(target.n_locals, pack_rest_args(target, args, heap));
    let mut frames: Vec<Frame> = vec![Frame {
        ret_proto: 0,
        ret_pc: 0,
        proto: proto_idx,
        locals: local_cells,
        captures,
        ext: FrameExt::new(),
        call_span: Span::dummy(),
    }];
    let externs = crate::ffi::ExternSymbolTable::new();
    let outcome = execute(
        program,
        globals,
        heap,
        &mut frames,
        MAX_INSTRUCTIONS,
        &externs,
    );
    outcome.map_err(|mut e| {
        // Call-site trace: isomorphic to run_program (innermost 16 frames)
        if e.trace.is_empty() && frames.len() > 1 {
            let start = frames.len().saturating_sub(MAX_TRACE_FRAMES).max(1);
            e.trace = frames[start..]
                .iter()
                .map(|f| TraceFrame {
                    proto_name: Some(program.protos[f.proto].name),
                    span: f.call_span,
                })
                .collect();
        }
        e
    })
}

/// Main execution loop (the inner body of run_program — error-path
/// `return`/`?` propagates here; the outer layer attaches the stack trace
/// from the `frames` snapshot).
fn execute(
    program: &BcProgram,
    globals: &mut HashMap<Symbol, Value>,
    heap: &mut Heap,
    frames: &mut Vec<Frame>,
    max_instructions: u64,
    externs: &crate::ffi::ExternSymbolTable,
) -> Result<Value, VmError> {
    let mut stack: Vec<Value> = Vec::new();
    let mut pc: u32 = 0;
    let mut instructions: u64 = 0;
    let mut gc_cooldown: u64 = 0;
    // TD-023 targeted remedy (r24/42-e): GC root-scan buffers reused across
    // cycles (clear preserves capacity — an allocation-free root-walk path;
    // visited avoids per-cycle rebuilds under closure-dense workloads)
    let mut gc_root_scratch: Vec<GcRef> = Vec::new();
    let mut gc_visited_scratch: HashSet<usize> = HashSet::new();
    // P1 (r55/TD-028 frame-slot pool): a LIFO pool inside the execute layer
    // (zero interface change — frame-slot allocation in deep-recursion /
    // tail-call hot loops avoids heap churn; guardrails in
    // release_local_cells)
    let mut cell_pool: Vec<Vec<Rc<GcCell>>> = Vec::new();

    // Main loop (iterative — kerf recursion is carried on the frame stack,
    // the Rust stack stays constant)
    // O3 (r54/TD-028): the proto reference is cached across iterations —
    // reused while the frame is unchanged (saving 2 bounds-checked indexes
    // per instruction: frames[frame_idx].proto + program.protos[...]).
    // Invalidation discipline: the nine frame-change points set the flag
    // explicitly (Call frame push / Call resume / TailCall builtin implicit
    // RET / TailCall frame replacement / TailCall resume / Ret frame pop /
    // INSTALL_HANDLER double frame push / PERFORM frame swap+truncate) —
    // frame length cannot serve as the invalidation signal (adjacent
    // push/pop instructions can restore the same value), hence explicit
    // setting rather than derivation.
    let mut proto_valid = true;
    let mut proto_idx = frames[frames.len() - 1].proto;
    let mut proto: &kerf_compiler::BcProto = &program.protos[proto_idx];
    loop {
        let frame_idx = frames.len() - 1;
        if !proto_valid {
            proto_idx = frames[frame_idx].proto;
            proto = &program.protos[proto_idx];
            proto_valid = true;
        }
        let pc_u = pc as usize;
        // O2 (r54/TD-028 main-dispatch optimization): instruction by
        // reference — a single bounds check (`get` replaces the "explicit
        // guard + index" double lookup) + eliminating the per-instruction
        // `clone()` (Op dispatched by reference, payloads dereferenced on
        // demand). Semantically equivalent: the out-of-bounds failure path
        // returns a diagnostic verbatim identical to the original.
        let Some(op) = proto.code.get(pc_u) else {
            return Err(VmError::new(
                format!(
                    "pc out of bounds: proto {} pc {} (bytecode corrupted or missing a terminating instruction)",
                    proto_idx, pc
                ),
                proto.debug_spans.get(pc_u).copied().unwrap_or_default(),
            ));
        };
        // O1 (r54/TD-028 main-dispatch optimization): lazily evaluate
        // cur_span!() — the original unconditionally copied debug
        // cur_span!() per instruction (a 16B Option round trip); now taken
        // only on error paths / frame-construction points. Semantic
        // equivalence: `cur_pc` is bound before the pc increment (the same
        // instruction as the original eager version's pc_u) and immutable —
        // order-of-evaluation-independent identity within dispatch arms.
        let cur_pc = pc_u;
        macro_rules! cur_span {
            () => {
                proto.debug_spans.get(cur_pc).copied().unwrap_or_default()
            };
        }
        // pc monotonicity exception (§19.5 invariant 2): JUMP/RET/CALL change
        // pc; everything else +1
        pc += 1;
        instructions += 1;
        // Instruction-budget guard (TD-022/H2): infinite tail loops whose
        // frame count stops growing after TCO are caught here
        if instructions > max_instructions {
            return Err(VmError::new(
                format!(
                    "instruction count exceeds the limit {} (suspected infinite loop -- TCO tail-loop guardrail)",
                    max_instructions
                ),
                cur_span!(),
            ));
        }

        macro_rules! pop {
            () => {
                stack.pop().ok_or_else(|| {
                    VmError::new(
                        "data stack underflow (bytecode stack imbalance)",
                        cur_span!(),
                    )
                })?
            };
        }
        macro_rules! pop2 {
            () => {{
                let b = stack
                    .pop()
                    .ok_or_else(|| VmError::new("data stack underflow", cur_span!()))?;
                let a = stack
                    .pop()
                    .ok_or_else(|| VmError::new("data stack underflow", cur_span!()))?;
                (a, b)
            }};
        }
        macro_rules! push {
            ($v:expr) => {
                stack.push($v)
            };
        }
        macro_rules! binop {
            ($f:expr) => {{
                let (a, b) = pop2!();
                let r: Result<Value, String> = $f(&a, &b);
                match r {
                    Ok(v) => push!(v),
                    Err(m) => {
                        return Err(VmError::new(m, cur_span!()));
                    }
                }
            }};
        }

        match op {
            Op::PushConst(k) => {
                let c = &program.consts[*k as usize];
                push!(const_to_value(c));
            }
            Op::PushNil => push!(Value::Nil),
            Op::PushTrue => push!(Value::Bool(true)),
            Op::PushFalse => push!(Value::Bool(false)),
            Op::Pop => {
                pop!();
            }
            Op::Dup => {
                let v = stack
                    .last()
                    .cloned()
                    .ok_or_else(|| VmError::new("DUP stack empty", cur_span!()))?;
                push!(v);
            }
            Op::Swap => {
                let n = stack.len();
                if n < 2 {
                    return Err(VmError::new(
                        "SWAP has insufficient stack depth",
                        cur_span!(),
                    ));
                }
                stack.swap(n - 1, n - 2);
            }
            Op::LoadLocal(i) => {
                let f = &frames[frame_idx];
                let cell = Rc::clone(f.locals.get(*i as usize).ok_or_else(|| {
                    VmError::new(format!("local slot {} out of bounds", i), cur_span!())
                })?);
                push!(cell.get().clone());
            }
            Op::StoreLocal(i) => {
                let v = pop!();
                let f = &frames[frame_idx];
                let cell = Rc::clone(f.locals.get(*i as usize).ok_or_else(|| {
                    VmError::new(format!("local slot {} out of bounds", i), cur_span!())
                })?);
                // GcCell::set: the write path synchronously maintains the
                // heap-root summary (TD-023)
                cell.set(v);
            }
            Op::LoadGlobal(k) => {
                let sym = match &program.consts[*k as usize] {
                    BcConst::Symbol(s) => *s,
                    _ => {
                        return Err(VmError::new(
                            "LOAD_GLOBAL operand is not a symbol",
                            cur_span!(),
                        ))
                    }
                };
                match globals.get(&sym) {
                    Some(v) => push!(v.clone()),
                    None => {
                        return Err(VmError::new(
                            "unbound global variable (hygiene fallback resolution already completed in driver)",
                            cur_span!(),
                        ))
                    }
                }
            }
            Op::StoreGlobal(k) => {
                let sym = match &program.consts[*k as usize] {
                    BcConst::Symbol(s) => *s,
                    _ => {
                        return Err(VmError::new(
                            "STORE_GLOBAL operand is not a symbol",
                            cur_span!(),
                        ))
                    }
                };
                let v = pop!();
                // S1/E3 semantics (aligned with the eval path's `Env::set`,
                // T1 theorem): set! writes only existing bindings — unbound
                // raises an error rather than silently creating a global.
                if !globals.contains_key(&sym) {
                    return Err(VmError::new(
                        crate::messages::err_setbang_unbound(),
                        cur_span!(),
                    ));
                }
                globals.insert(sym, v);
            }
            Op::DefineGlobal(k) => {
                let sym = match &program.consts[*k as usize] {
                    BcConst::Symbol(s) => *s,
                    _ => {
                        return Err(VmError::new(
                            "DEFINE_GLOBAL operand is not a symbol",
                            cur_span!(),
                        ))
                    }
                };
                let v = pop!();
                // D1/E6 semantics (aligned with the eval path's
                // `Env::define`, T1 theorem): define only adds bindings —
                // an existing same-layer name raises an error rather than
                // being silently overwritten.
                if globals.contains_key(&sym) {
                    return Err(VmError::new("duplicate variable definition", cur_span!()));
                }
                globals.insert(sym, v);
            }
            Op::LoadCaptured(i) => {
                let f = &frames[frame_idx];
                let cell = f.captures.get(*i as usize).ok_or_else(|| {
                    VmError::new(format!("capture slot {} out of bounds", i), cur_span!())
                })?;
                push!(cell.get().clone());
            }
            Op::StoreCaptured(i) => {
                let v = pop!();
                let f = &frames[frame_idx];
                let cell = Rc::clone(f.captures.get(*i as usize).ok_or_else(|| {
                    VmError::new(format!("capture slot {} out of bounds", i), cur_span!())
                })?);
                // GcCell::set: the write path synchronously maintains the
                // heap-root summary (TD-023)
                cell.set(v);
            }
            Op::Jump(t) => {
                pc = *t;
            }
            Op::JumpIfFalse(t) => {
                let c = pop!();
                // TD-018: the message is single-sourced via messages (same
                // text as the eval if arm)
                match c {
                    Value::Bool(b) => {
                        if !b {
                            pc = *t;
                        }
                    }
                    other => {
                        return Err(VmError::new(
                            crate::messages::err_if_cond_bool(other.type_name()),
                            cur_span!(),
                        ))
                    }
                }
            }
            Op::Closure {
                proto: p,
                n_captures,
            } => {
                // Capture-source descriptors taken directly: cells are
                // **shared** with the enclosing frame (mutable capture
                // semantics)
                let target = &program.protos[*p as usize];
                if target.capture_sources.len() != *n_captures as usize {
                    return Err(VmError::new(
                        "CLOSURE captured descriptor count mismatch(compiler invariant broken)",
                        cur_span!(),
                    ));
                }
                let f = &frames[frame_idx];
                let mut captures: Vec<Rc<GcCell>> = Vec::with_capacity(*n_captures as usize);
                for src in &target.capture_sources {
                    let cell = match src {
                        kerf_compiler::CaptureSource::Local(i) => {
                            Rc::clone(f.locals.get(*i as usize).ok_or_else(|| {
                                VmError::new("capture source local slot out of bounds", cur_span!())
                            })?)
                        }
                        kerf_compiler::CaptureSource::Captured(i) => {
                            Rc::clone(f.captures.get(*i as usize).ok_or_else(|| {
                                VmError::new(
                                    "capture source capture slot out of bounds",
                                    cur_span!(),
                                )
                            })?)
                        }
                    };
                    captures.push(cell);
                }
                push!(Value::Closure(Rc::new(ClosureValue::Bytecode {
                    proto: *p,
                    captures,
                })));
            }
            Op::Call(n) => {
                let n = *n as usize;
                // Stack layout: [fn, arg0..arg n-1] (06 §2 A1
                // evaluation-order contract: the function evaluates and is
                // pushed first, arguments left to right — consistent with
                // the eval path)
                if stack.len() < n + 1 {
                    return Err(VmError::new(
                        "CALL has insufficient stack depth",
                        cur_span!(),
                    ));
                }
                let mut args: Vec<Value> = Vec::with_capacity(n);
                for _ in 0..n {
                    args.push(stack.pop().expect("checked above"));
                }
                args.reverse(); // arg0 lands in local slot 0
                let callee = stack.pop().expect("checked above");
                match callee {
                    Value::Builtin(b) => match b.call(heap, args) {
                        Ok(v) => push!(v),
                        Err(e) => return Err(VmError::new(e.message, cur_span!())),
                    },
                    Value::Closure(rc) if matches!(rc.as_ref(), ClosureValue::Bytecode { .. }) => {
                        let (p, captures) = match rc.as_ref() {
                            ClosureValue::Bytecode { proto, captures } => {
                                (*proto, captures.clone())
                            }
                            _ => unreachable!("narrowed above"),
                        };
                        let target = &program.protos[p as usize];
                        if let Some(msg) = arity_mismatch(target, args.len()) {
                            return Err(VmError::new(msg, cur_span!()));
                        }
                        if frames.len() >= MAX_FRAMES {
                            return Err(VmError::new(
                                format!("call frame limit exceeded {}(runaway recursion)", MAX_FRAMES),
                                cur_span!(),
                            ));
                        }
                        // Arguments into cells (the frame foundation of
                        // capture-sharing semantics; GcCell carries the
                        // heap-root summary flag, TD-023; Let slots extended
                        // per n_locals — r45)
                        // P1 (r55): pooled slot acquisition (falls back to
                        // fresh allocation when the pool is empty — identity
                        // see td028-frame-pool-optimization §3.3).
                        // r165 / 236-c (D4-c): the rest chain packs BEFORE
                        // acquisition — the pool path's behavioral-identity
                        // contract covers the packed shape unchanged.
                        let local_cells = acquire_local_cells(
                            &mut cell_pool,
                            target.n_locals,
                            pack_rest_args(target, args, heap),
                        );
                        let frame = Frame {
                            ret_proto: proto_idx,
                            ret_pc: pc,
                            proto: p as usize,
                            locals: local_cells,
                            captures,
                            ext: FrameExt::new(),
                            call_span: cur_span!(),
                        };
                        let _ = &rc;
                        frames.push(frame);
                        pc = 0;
                        proto_valid = false;
                    }
                    Value::Closure(rc) if matches!(rc.as_ref(), ClosureValue::Eval { .. }) => {
                        return Err(VmError::new(
                            "cross-path closure calls are not supported (eval closures cannot be called in the VM -- dual paths are for cross-checking)",
                            cur_span!(),
                        ))
                    }
                    // r25/42-f (D4): resume = the call shape of a
                    // continuation value — goes through the Call channel
                    // (after desugaring it dispatches on the same path as an
                    // ordinary call). Control-transfer semantics: the current
                    // frame (the H execution frame) is torn down — code
                    // after the κ call inside the handler body never executes
                    // (the B resume chain's own return target receives the
                    // return)
                    Value::Continuation(rc) => {
                        if args.len() != 1 {
                            return Err(VmError::new_code(
                                9,
                                crate::messages::err_resume_arity(args.len()),
                                cur_span!(),
                            ));
                        }
                        let v = args.into_iter().next().expect("checked above");
                        // P1 (r55): return the torn-down frame's slots to
                        // the pool before the resume
                        if let Some(hf) = frames.pop() {
                            release_local_cells(&mut cell_pool, hf.locals);
                        }
                        // r133 / 203-c2 (isoB P1 — same-window clearance):
                        // tear down the whole stale chain above the handler
                        // boundary. A resume issued from a frame deeper than
                        // the arm body (e.g. a non-tail call of a k-capturing
                        // closure) leaves the arm-body frame — and any deeper
                        // frames — live; without this teardown the restored
                        // RET cascade re-enters the arm body at the
                        // trampoline's ret_pc (STORE_LOCAL clobbers the
                        // closure slot with the handle value →
                        // `uncallable value: int`). The r128 in-arm statement /
                        // tail resumes are unchanged (the pop above already
                        // reached the boundary there).
                        while frames.len() > rc.boundary {
                            if let Some(f) = frames.pop() {
                                release_local_cells(&mut cell_pool, f.locals);
                            }
                        }
                        pc = resume_continuation(&rc, v, program, frames, &mut stack, cur_span!())?;
                        proto_valid = false;
                    }
                    other => {
                        return Err(VmError::new(
                            format!("uncallable value: {}", other.type_name()),
                            cur_span!(),
                        ))
                    }
                }
            }
            Op::TailCall(n) => {
                // TD-022/H2 — TCO frame reuse: semantics identical to Call,
                // but the current frame is torn down and the callee's return
                // goes straight to the current frame's caller (net-zero
                // frame count — tail recursion at O(1) frames). The
                // tail-call-chain main loops of the bootstrap
                // Reader/Expander (10^5 character-scale sources) and user
                // tail-recursive programs are thereby freed of frame
                // consumption (TD-022 honored).
                let n = *n as usize;
                if stack.len() < n + 1 {
                    return Err(VmError::new(
                        "TAIL_CALL has insufficient stack depth",
                        cur_span!(),
                    ));
                }
                let mut args: Vec<Value> = Vec::with_capacity(n);
                for _ in 0..n {
                    args.push(stack.pop().expect("checked above"));
                }
                args.reverse(); // arg0 lands in local slot 0
                let callee = stack.pop().expect("checked above");
                match callee {
                    // Builtin tail call = compute the result then immediately
                    // perform an implicit RET (equivalent semantics)
                    Value::Builtin(b) => match b.call(heap, args) {
                        Ok(v) => {
                            if frames.len() <= 1 {
                                return Ok(v);
                            }
                            let frame = frames.pop().expect("checked above");
                            pc = frame.ret_pc;
                            release_local_cells(&mut cell_pool, frame.locals);
                            push!(v);
                            proto_valid = false;
                        }
                        Err(e) => return Err(VmError::new(e.message, cur_span!())),
                    },
                    Value::Closure(rc) if matches!(rc.as_ref(), ClosureValue::Bytecode { .. }) => {
                        let (p, captures) = match rc.as_ref() {
                            ClosureValue::Bytecode { proto, captures } => {
                                (*proto, captures.clone())
                            }
                            _ => unreachable!("narrowed above"),
                        };
                        let target = &program.protos[p as usize];
                        if let Some(msg) = arity_mismatch(target, args.len()) {
                            return Err(VmError::new(msg, cur_span!()));
                        }
                        // Frame replacement (net zero): tear down the current
                        // frame and inherit its return address — the callee's
                        // RET goes straight to the current frame's caller.
                        // MAX_FRAMES is not checked (frame count is constant);
                        // runaway tail loops are caught by the
                        // instruction-budget guard.
                        // P1 (r55): return the old frame's slots to the pool
                        // first, then acquire the new frame's slots — the
                        // self-loop makes steady-state tail recursion hit
                        // fully with pool depth 1
                        let old = frames.pop().expect("tail-call frame exists");
                        release_local_cells(&mut cell_pool, old.locals);
                        // r165 / 236-c (D4-c): the Call-site packing mirror.
                        let local_cells = acquire_local_cells(
                            &mut cell_pool,
                            target.n_locals,
                            pack_rest_args(target, args, heap),
                        );
                        let frame = Frame {
                            ret_proto: old.ret_proto,
                            ret_pc: old.ret_pc,
                            proto: p as usize,
                            locals: local_cells,
                            captures,
                            ext: FrameExt::new(),
                            call_span: cur_span!(),
                        };
                        frames.push(frame);
                        pc = 0;
                        proto_valid = false;
                    }
                    Value::Closure(rc) if matches!(rc.as_ref(), ClosureValue::Eval { .. }) => {
                        return Err(VmError::new(
                            "cross-path closure calls are not supported (eval closures cannot be called in the VM -- dual paths are for cross-checking)",
                            cur_span!(),
                        ))
                    }
                    // r25/42-f: tail-position resume — the current frame is
                    // torn down (control has transferred: the restored
                    // suspended frame chain carries its own complete return
                    // chain, and the torn-down frame's return point is no
                    // longer referenced — same TailCall frame-replacement
                    // semantics)
                    Value::Continuation(rc) => {
                        if args.len() != 1 {
                            return Err(VmError::new_code(
                                9,
                                crate::messages::err_resume_arity(args.len()),
                                cur_span!(),
                            ));
                        }
                        let v = args.into_iter().next().expect("checked above");
                        // P1 (r55): return the torn-down frame's slots to
                        // the pool before the tail-position resume
                        if let Some(old) = frames.pop() {
                            release_local_cells(&mut cell_pool, old.locals);
                        }
                        // r133 / 203-c2 (isoB P1 — same-window clearance):
                        // the boundary teardown shared with the Call arm above
                        // (a tail resume from a frame deeper than the arm body
                        // leaves the arm-body frame live — the restored RET
                        // cascade would re-enter it at the trampoline's
                        // ret_pc)
                        while frames.len() > rc.boundary {
                            if let Some(f) = frames.pop() {
                                release_local_cells(&mut cell_pool, f.locals);
                            }
                        }
                        pc = resume_continuation(&rc, v, program, frames, &mut stack, cur_span!())?;
                        proto_valid = false;
                    }
                    other => {
                        return Err(VmError::new(
                            format!("uncallable value: {}", other.type_name()),
                            cur_span!(),
                        ))
                    }
                }
            }
            Op::Ret => {
                let v = pop!();
                if frames.len() <= 1 {
                    // Bottom-frame RET = the return of a function-entry call
                    // (call_closure semantics). run_program's main prototype
                    // terminates with Halt (compiler invariant) and never
                    // goes through this path — the old behavior for a RET in
                    // the main frame was an explicit error; with this entry
                    // point, bottom-frame RET is a legal programmatic return
                    // point.
                    return Ok(v);
                }
                let frame = frames.pop().expect("checked above");
                pc = frame.ret_pc;
                release_local_cells(&mut cell_pool, frame.locals);
                push!(v);
                proto_valid = false;
            }
            Op::Add => binop!(num_add),
            Op::Sub => binop!(num_sub),
            Op::Mul => binop!(num_mul),
            Op::Div => binop!(num_div),
            Op::Mod => binop!(num_mod),
            Op::NumLt => binop!(num_cmp(|o| o == std::cmp::Ordering::Less)),
            Op::NumGt => binop!(num_cmp(|o| o == std::cmp::Ordering::Greater)),
            Op::NumLe => binop!(num_cmp(|o| o != std::cmp::Ordering::Greater)),
            Op::NumGe => binop!(num_cmp(|o| o != std::cmp::Ordering::Less)),
            Op::NumEq => binop!(num_cmp(|o| o == std::cmp::Ordering::Equal)),
            Op::Eq => {
                let (a, b) = pop2!();
                // r162 / 233 — TD-037: the user-facing structural law
                // (pairs/vectors by recursive value equality; the identity
                // law survives for procedural values — see structural_eq).
                push!(Value::Bool(structural_eq(&a, &b, heap)));
            }
            Op::Not => {
                let v = pop!();
                match v {
                    Value::Bool(b) => push!(Value::Bool(!b)),
                    other => {
                        return Err(VmError::new(
                            crate::messages::err_not_bool(other.type_name()),
                            cur_span!(),
                        ))
                    }
                }
            }
            Op::MakePair => {
                let (a, b) = pop2!();
                let ra = box_value(&a, heap);
                let rb = box_value(&b, heap);
                let r = heap.alloc_pair(ra, rb);
                push!(Value::Pair(r));
            }
            Op::Car => {
                let v = pop!();
                match v {
                    Value::Pair(r) => match heap.get_pair(r) {
                        Some((car, _)) => push!(unbox_slot(car, heap)),
                        None => {
                            return Err(VmError::new(
                                "car applied to a non-pair heap slot",
                                cur_span!(),
                            ))
                        }
                    },
                    other => {
                        return Err(VmError::new(
                            crate::messages::err_pair_op("car", other.type_name()),
                            cur_span!(),
                        ))
                    }
                }
            }
            Op::Cdr => {
                let v = pop!();
                match v {
                    Value::Pair(r) => match heap.get_pair(r) {
                        Some((_, cdr)) => push!(unbox_slot(cdr, heap)),
                        None => {
                            return Err(VmError::new(
                                "cdr applied to a non-pair heap slot",
                                cur_span!(),
                            ))
                        }
                    },
                    other => {
                        return Err(VmError::new(
                            crate::messages::err_pair_op("cdr", other.type_name()),
                            cur_span!(),
                        ))
                    }
                }
            }
            Op::IsNull => {
                let v = pop!();
                push!(Value::Bool(matches!(v, Value::Nil)));
            }
            Op::IsPair => {
                let v = pop!();
                push!(Value::Bool(matches!(v, Value::Pair(_))));
            }
            Op::IsInt => {
                let v = pop!();
                push!(Value::Bool(matches!(v, Value::Int(_))));
            }
            Op::IsBool => {
                let v = pop!();
                push!(Value::Bool(matches!(v, Value::Bool(_))));
            }
            Op::IsProcedure => {
                let v = pop!();
                push!(Value::Bool(matches!(
                    v,
                    Value::Closure(_) | Value::Builtin(_)
                )));
            }
            Op::Halt => {
                let v = stack.pop().unwrap_or(Value::Nil);
                let _ = instructions;
                let _ = frame_idx;
                return Ok(v);
            }
            // ---- Effects (r25/42-f — effect-language-design D6/D8 frame
            // orchestration) ----
            Op::InstallHandler {
                handler: hp,
                body: bp,
                tag: tk,
                trampoline: tp,
            } => {
                let hp = *hp as usize;
                let bp = *bp as usize;
                let tp = *tp as usize;
                if hp >= program.protos.len()
                    || bp >= program.protos.len()
                    || tp >= program.protos.len()
                {
                    return Err(VmError::new(
                        format!(
                            "INSTALL_HANDLER prototype index out of bounds: handler {} / body {} / trampoline {}(total {})",
                            hp,
                            bp,
                            tp,
                            program.protos.len()
                        ),
                        cur_span!(),
                    ));
                }
                let tag_sym = match &program.consts[*tk as usize] {
                    BcConst::SymLit(s) => Rc::clone(s),
                    _ => {
                        return Err(VmError::new(
                            "INSTALL_HANDLER label operand must be symbol constant",
                            cur_span!(),
                        ))
                    }
                };
                if frames.len() + 2 > MAX_FRAMES {
                    return Err(VmError::new(
                        format!(
                            "call frame limit exceeded {}(runaway recursion)",
                            MAX_FRAMES
                        ),
                        cur_span!(),
                    ));
                }
                // The two prototypes' captures are taken from the current
                // frame F (same mechanism as Closure — shared cells)
                let h_captures = take_frame_captures(
                    &program.protos[hp].capture_sources,
                    frames,
                    frame_idx,
                    cur_span!(),
                )?;
                let b_captures = take_frame_captures(
                    &program.protos[bp].capture_sources,
                    frames,
                    frame_idx,
                    cur_span!(),
                )?;
                // ① Push the handler frame: proto = trampoline (code=[Ret]
                //    sentinel), ret = (F's proto, after this instruction);
                //    ext1 carries the dispatch data (r136 / 206-b D14: the
                //    1-entry degenerate of the generalized entries shape)
                let handler_data = Rc::new(HandlerFrame {
                    entries: vec![HandlerEntry {
                        tag: tag_sym,
                        handler_proto: hp as u32,
                        captures: h_captures.clone(),
                    }],
                    stack_watermark: stack.len(),
                });
                frames.push(Frame {
                    ret_proto: proto_idx,
                    ret_pc: pc,
                    proto: tp,
                    locals: Vec::new(),
                    captures: h_captures,
                    ext: FrameExt {
                        ext1: Some(handler_data),
                        ext2: None,
                        ext3: None,
                    },
                    call_span: cur_span!(),
                });
                // ② Push the body thunk frame: ret = (trampoline, 0) — the
                //    body's RET pops the handler frame via the trampoline,
                //    returning to F's post-handle continuation
                //    (R11-return); tail calls inside the body tear down the
                //    thunk frame and tunnel through (D8). Let binding slots
                //    are pre-allocated per the B prototype's n_locals (r45).
                //    P1 (r55): pooled slot acquisition for thunk frames
                //    (high-frequency install point in effect_stress)
                frames.push(Frame {
                    ret_proto: tp,
                    ret_pc: 0,
                    proto: bp,
                    locals: acquire_local_cells(
                        &mut cell_pool,
                        program.protos[bp].n_locals,
                        Vec::new(),
                    ),
                    captures: b_captures,
                    ext: FrameExt::new(),
                    call_span: cur_span!(),
                });
                // ③ Transfer execution to the body (thunk body =
                // lambda-body semantics — tail-position threading)
                pc = 0;
                proto_valid = false;
            }
            // ---- r136 / 206-b (TD-033 — D14): group handler install ----
            Op::InstallHandlerGroup {
                entries,
                body: bp,
                trampoline: tp,
            } => {
                let bp = *bp as usize;
                let tp = *tp as usize;
                if entries.is_empty() || bp >= program.protos.len() || tp >= program.protos.len() {
                    return Err(VmError::new(
                        format!(
                            "INSTALL_HANDLER_GROUP operand abnormal: entries {} / body {} / trampoline {}(total {})",
                            entries.len(),
                            bp,
                            tp,
                            program.protos.len()
                        ),
                        cur_span!(),
                    ));
                }
                // Per-arm validation + tag constants + capture cells (all
                // taken from the current frame F — same mechanism as the
                // single-arm install)
                let mut arm_entries: Vec<HandlerEntry> = Vec::with_capacity(entries.len());
                let mut all_captures: Vec<Rc<GcCell>> = Vec::new();
                for (hp, tk) in entries.iter() {
                    let hp = *hp as usize;
                    if hp >= program.protos.len() {
                        return Err(VmError::new(
                            format!(
                                "INSTALL_HANDLER_GROUP prototype index out of bounds: handler {}(total {})",
                                hp,
                                program.protos.len()
                            ),
                            cur_span!(),
                        ));
                    }
                    let tag_sym = match &program.consts[*tk as usize] {
                        BcConst::SymLit(s) => Rc::clone(s),
                        _ => {
                            return Err(VmError::new(
                                "INSTALL_HANDLER_GROUP label operand must be symbol constant",
                                cur_span!(),
                            ))
                        }
                    };
                    let h_captures = take_frame_captures(
                        &program.protos[hp].capture_sources,
                        frames,
                        frame_idx,
                        cur_span!(),
                    )?;
                    all_captures.extend(h_captures.iter().cloned());
                    arm_entries.push(HandlerEntry {
                        tag: tag_sym,
                        handler_proto: hp as u32,
                        captures: h_captures,
                    });
                }
                if frames.len() + 2 > MAX_FRAMES {
                    return Err(VmError::new(
                        format!(
                            "call frame limit exceeded {}(runaway recursion)",
                            MAX_FRAMES
                        ),
                        cur_span!(),
                    ));
                }
                let b_captures = take_frame_captures(
                    &program.protos[bp].capture_sources,
                    frames,
                    frame_idx,
                    cur_span!(),
                )?;
                // ① Push the ONE group handler frame (proto = trampoline,
                //    ext1 = HandlerFrame{entries: N}; the frame's capture
                //    slots carry ALL arms' captures concatenated — the GC
                //    root face, same single-source slot as the single-arm
                //    install)
                let handler_data = Rc::new(HandlerFrame {
                    entries: arm_entries,
                    stack_watermark: stack.len(),
                });
                frames.push(Frame {
                    ret_proto: proto_idx,
                    ret_pc: pc,
                    proto: tp,
                    locals: Vec::new(),
                    captures: all_captures,
                    ext: FrameExt {
                        ext1: Some(handler_data),
                        ext2: None,
                        ext3: None,
                    },
                    call_span: cur_span!(),
                });
                // ② Push the body thunk frame (ret = (trampoline, 0)) — the
                //    same three-prototype orchestration as the single-arm
                //    install (T/B shared mechanics; P1 pooled slots)
                frames.push(Frame {
                    ret_proto: tp,
                    ret_pc: 0,
                    proto: bp,
                    locals: acquire_local_cells(
                        &mut cell_pool,
                        program.protos[bp].n_locals,
                        Vec::new(),
                    ),
                    captures: b_captures,
                    ext: FrameExt::new(),
                    call_span: cur_span!(),
                });
                // ③ Transfer execution to the body
                pc = 0;
                proto_valid = false;
            }
            Op::Perform => {
                // R10-perform: pop the effect value → destructure
                // (tag . payload) → scan for the nearest handler frame →
                // continuation snapshot → tear frames down to the boundary →
                // transform the handler frame into the handler-body
                // execution frame → truncate the stack back to the watermark
                let v = pop!();
                let (tag_val, payload) = match &v {
                    Value::Pair(r) => match heap.get_pair(*r) {
                        Some((car_slot, cdr_slot)) => {
                            let tag_v = unbox_slot(car_slot, heap);
                            let payload = unbox_slot(cdr_slot, heap);
                            match tag_v {
                                Value::Symbol(s) => (s, payload),
                                other => {
                                    return Err(VmError::new(
                                        format!(
                                        "perform effect value tag position requires symbol, got {}",
                                        other.type_name()
                                    ),
                                        cur_span!(),
                                    ))
                                }
                            }
                        }
                        None => {
                            return Err(VmError::new(
                                "perform effect value should be (tag . payload) dotted pair",
                                cur_span!(),
                            ))
                        }
                    },
                    other => {
                        return Err(VmError::new(
                            format!(
                                "perform effect value requires (tag . payload) dotted pair, got {}",
                                other.type_name()
                            ),
                            cur_span!(),
                        ))
                    }
                };
                // Scan from the frame-stack top downward for the nearest
                // handler frame whose entries contain the tag (D6; r136 /
                // 206-b D14: any-entry match — multi-tag group dispatch)
                let mut handler_hit: Option<(usize, usize)> = None;
                for (i, f) in frames.iter().enumerate().rev() {
                    if let Some(hd) = &f.ext.ext1 {
                        if let Some(ei) = hd.entries.iter().position(|e| e.tag == tag_val) {
                            handler_hit = Some((i, ei));
                            break;
                        }
                    }
                }
                let (hi, ei) = match handler_hit {
                    Some(hit) => hit,
                    None => {
                        return Err(VmError::new_code(
                            7,
                            crate::messages::err_effect_unhandled(&tag_val),
                            cur_span!(),
                        ))
                    }
                };
                // Continuation snapshot: **the suspended chain including
                // the handler frame itself** (the handler/trampoline frames
                // = the B chain's return targets — they must be restored on
                // resume, otherwise the frame order breaks after the B
                // chain's RET: its return point (trampoline, 0) would have
                // no frame to land in); full data stack + resume point. The
                // snapshot's handler frame has ext1 cleared — shallow
                // handling (D2; r136 / 206-b D14: the WHOLE group goes inert
                // — group consumption: a post-resume perform does not return
                // to any sibling arm of this group; re-matching requires an
                // outer nested handle)
                let mut snap = frames[hi..].to_vec();
                snap[0].ext.ext1 = None;
                let cont = Rc::new(crate::value::ContinuationValue {
                    frames: snap,
                    stack: stack.clone(),
                    resume_pc: pc,
                    resume_proto: frames.last().map(|f| f.proto as u32).unwrap_or(0),
                    // r133 / 203-c2: the handler boundary for the resume-side
                    // stale-chain teardown (see value.rs field doc)
                    boundary: hi,
                    consumed: std::cell::Cell::new(false),
                    first_resume_span: std::cell::Cell::new(kerf_span::Span::dummy()),
                });
                // Handler frame transformation: trampoline → H execution
                // frame (locals = [payload, κ, ...Let slots pre-allocated
                // per the H prototype's n_locals — r45]; ext1 cleared — the
                // frame replacement IS the group consumption: all sibling
                // entries die with the frame, so sibling tags performed
                // inside the handler body propagate outward — symmetric
                // non-protection, the Koka-style reading of
                // [HANDLE-INSTALL]; ret inherits the original handler
                // frame's return point = F's post-handle continuation)
                let hf = frames[hi].clone();
                let hd = hf.ext.ext1.as_ref().expect("matched above").clone();
                let matched = hd.entries[ei].clone();
                let mut h_cells = vec![
                    Rc::new(GcCell::new(payload)),
                    Rc::new(GcCell::new(Value::Continuation(Rc::clone(&cont)))),
                ];
                let h_n_locals = program.protos[matched.handler_proto as usize].n_locals as usize;
                while h_cells.len() < h_n_locals {
                    h_cells.push(Rc::new(GcCell::new(Value::Nil)));
                }
                let h_frame = Frame {
                    ret_proto: hf.ret_proto,
                    ret_pc: hf.ret_pc,
                    proto: matched.handler_proto as usize,
                    locals: h_cells,
                    captures: matched.captures.clone(),
                    ext: FrameExt::new(),
                    call_span: hf.call_span,
                };
                frames.truncate(hi + 1);
                frames[hi] = h_frame;
                // Truncate the data stack back to the install watermark (the
                // suspended chain's intermediate values are already in the
                // continuation)
                let watermark = hd.stack_watermark;
                if stack.len() > watermark {
                    stack.truncate(watermark);
                }
                pc = 0;
                proto_valid = false;
            }
            // ---- FFI (r30/48-d — ffi-ownership-model §2/§8; the surface
            // form is Stage 3, the compile arm does not emit it — driven by
            // direct opcode construction / the test face) ----
            Op::CallExternal { symbol, n_args } => {
                // Symbol resolution by name (the extern symbol table — a
                // SymLit constant carries the symbol name; flat symbol
                // space, not shadowable by define/set!)
                let name = match &program.consts[*symbol as usize] {
                    BcConst::SymLit(s) => s.clone(),
                    _ => {
                        return Err(VmError::new(
                            "CALL_EXTERNAL operand requires symbol literal(SymLit constant)",
                            cur_span!(),
                        ))
                    }
                };
                let n = *n_args as usize;
                if stack.len() < n {
                    return Err(VmError::new(
                        format!(
                            "data stack underflow (FFI argument shortfall: requires {n}, got {})",
                            stack.len()
                        ),
                        cur_span!(),
                    ));
                }
                // Arguments sliced off in order (push order = in order —
                // the stack top holds the last argument)
                let args: Vec<Value> = stack.split_off(stack.len() - n);
                // Window protocol steps 2-4 (the boundary wrapping layer —
                // crate::ffi)
                let v = crate::ffi::call_external(externs, &name, &args, heap, cur_span!())?;
                push!(v);
            }
            Op::AllocExternal { size } => {
                // External-domain allocation (not through the GC; size=0
                // runtime defense-in-depth = E0011)
                let v = crate::ffi::alloc_external(*size, cur_span!())?;
                push!(v);
            }
            Op::FreeExternal => {
                // Consumption-semantics free (slot-level globally-effective
                // invalidation mark; decision order = the §5
                // illegal-transition table)
                let v = pop!();
                let r = crate::ffi::free_external(&v, cur_span!())?;
                push!(r);
            }
        }

        // GC safepoint (§19.4 pitfall 2: triggered only at instruction
        // boundaries; polled every 256 instructions; low-yield collections
        // trigger cooldown backoff — amortizing root-set scanning costs)
        if instructions.is_multiple_of(GC_POLL_INTERVAL)
            && gc_cooldown == 0
            && heap.should_collect()
        {
            // TD-023: root-scan buffer reuse (take/return — a zero-API-change
            // face)
            let mut roots_buf = std::mem::take(&mut gc_root_scratch);
            let mut visited_buf = std::mem::take(&mut gc_visited_scratch);
            collect_roots_into(&stack, globals, frames, &mut roots_buf, &mut visited_buf);
            let roots = RootSet { refs: roots_buf };
            let stats = kerf_runtime::mark_sweep_cycle(heap, &roots);
            gc_root_scratch = roots.refs;
            gc_visited_scratch = visited_buf;
            // Collection yield < 25% → cooldown (surviving roots dominate;
            // lower the scan frequency)
            if stats.total_freed as usize * 4 < stats.slots {
                gc_cooldown = GC_COOLDOWN_MULTIPLIER;
            }
        } else if gc_cooldown > 0 {
            gc_cooldown = gc_cooldown.saturating_sub(1);
        }
    }
}

/// Constant → value.
fn const_to_value(c: &BcConst) -> Value {
    match c {
        BcConst::Int(v) => Value::Int(*v),
        BcConst::Float(v) => Value::Float(*v),
        BcConst::Str(s) => Value::Str(s.clone()),
        BcConst::Bool(b) => Value::Bool(*b),
        BcConst::Nil => Value::Nil,
        BcConst::SymLit(s) => Value::Symbol(s.clone()),
        BcConst::Symbol(_) => Value::Nil, // symbol constants serve only as global-name indexes (never pushed)
    }
}

/// Value → heap reference (immediates boxed; closures/builtins boxed in
/// the Foreign shape — the TD-010 r24 resolution: the original
/// tagged-string placeholder → real boxing, with unboxing round-trips
/// preserving Rc identity). Public helper: reused by driver builtins such
/// as cons/list.
pub fn box_value(v: &Value, heap: &mut Heap) -> GcRef {
    match v {
        Value::Pair(r) => *r,
        // r138 / 208-c — TD-002: heap values pass through by slot reference
        // (the Pair discipline; element slots were allocated at construction)
        Value::Vector(r) => *r,
        Value::Str(s) => heap.alloc_boxed(BoxedInput::Str(s.clone())),
        Value::Symbol(s) => heap.alloc_symbol(s.clone()),
        Value::Int(i) => heap.alloc_boxed(BoxedInput::Int(*i)),
        Value::Float(f) => heap.alloc_boxed(BoxedInput::Float(*f)),
        Value::Bool(b) => heap.alloc_boxed(BoxedInput::Bool(*b)),
        Value::Nil => heap.alloc_boxed(BoxedInput::Nil),
        Value::Unit => heap.alloc_boxed(BoxedInput::Str(Rc::from("unit"))),
        // TD-010 (r24): closure/builtin boxing — ForeignBox carries the
        // type-erased Rc (sharing → eq? equal-by-reference round-trip
        // identity) + a tracer (the mark phase enumerates the closure
        // capture graph's Pair sub-references)
        Value::Closure(rc) => heap.alloc_foreign(ForeignBox {
            any: rc.clone(),
            tracer: trace_foreign_value,
        }),
        Value::Builtin(rc) => heap.alloc_foreign(ForeignBox {
            any: rc.clone(),
            tracer: trace_foreign_value,
        }),
        // r25/42-f (M5): continuation boxing — ForeignBox carries the Rc
        // (unbox round-trip identity → eq? by reference) + a dedicated
        // tracer (the mark phase enumerates heap sub-references of the data
        // stack snapshot and frame-chain slots — same-shaped precedent
        // TD-010)
        Value::Continuation(rc) => heap.alloc_foreign(ForeignBox {
            any: rc.clone(),
            tracer: trace_foreign_continuation,
        }),
        // r30/48-d: FFI token boxing — ForeignBox carries Rc<ExternalToken>
        // (unbox round-trip identity — same shape as TD-010); the tracer is
        // a no-op (the token payload does not participate in GC reachability
        // — the ffi-ownership-model §7 ruling)
        Value::External(rc) => heap.alloc_foreign(ForeignBox {
            any: rc.clone(),
            tracer: trace_foreign_noop,
        }),
    }
}

/// FFI token boxing tracer (r30/48-d — no-op: the token payload does not
/// participate in GC reachability and holds no heap sub-references;
/// ffi-ownership-model §7 "Foreign slots have no GC sub-references").
fn trace_foreign_noop(_any: &Rc<dyn Any>, _out: &mut Vec<GcRef>) {}

/// Continuation boxing tracer (M5 — in-heap reachability: the data stack
/// snapshot + the frame chain's locals/captures heap references all go
/// into out; nested κ recurses via trace_value_refs — visited guards
/// against cycles).
fn trace_foreign_continuation(any: &Rc<dyn Any>, out: &mut Vec<GcRef>) {
    if let Some(cont) = any
        .as_ref()
        .downcast_ref::<crate::value::ContinuationValue>()
    {
        let mut visited: HashSet<usize> = HashSet::new();
        for sv in &cont.stack {
            trace_value_refs(sv, out, &mut visited);
        }
        for f in &cont.frames {
            for cell in &f.locals {
                if cell.has_heap() {
                    trace_value_refs(&cell.get(), out, &mut visited);
                }
            }
            for cell in &f.captures {
                if cell.has_heap() {
                    trace_value_refs(&cell.get(), out, &mut visited);
                }
            }
        }
    }
}

/// Heap slot → value (public helper: reused by driver builtins such as
/// car/cdr). TD-010 (r24): Foreign slots downcast back to closures/builtins
/// — Rc-shared boxing → after unboxing eq? is equal by reference (identity
/// preserved).
pub fn unbox_slot(r: GcRef, heap: &Heap) -> Value {
    use kerf_runtime::ValueSlot;
    match heap.unbox(r) {
        Some(ValueSlot::Pair) => Value::Pair(r),
        // r138 / 208-c — TD-002: the marker wrap (element access via
        // Heap::get_vector — the caller unwraps lazily)
        Some(ValueSlot::Vector) => Value::Vector(r),
        Some(ValueSlot::Str(s)) => Value::Str(s),
        Some(ValueSlot::Int(i)) => Value::Int(i),
        Some(ValueSlot::Float(f)) => Value::Float(f),
        Some(ValueSlot::Bool(b)) => Value::Bool(b),
        Some(ValueSlot::Symbol(s)) => Value::Symbol(s),
        Some(ValueSlot::Nil) => Value::Nil,
        Some(ValueSlot::Foreign(b)) => {
            // downcast consumes the Rc: closure first, then builtin (the
            // boxing side produces only these two shapes)
            if let Ok(c) = b.any.clone().downcast::<ClosureValue>() {
                return Value::Closure(c);
            }
            if let Ok(f) = b.any.clone().downcast::<BuiltinFn>() {
                return Value::Builtin(f);
            }
            // r25/42-f: continuation unboxing (round-trip identity — the M5
            // liveness verification face)
            if let Ok(k) = b.any.clone().downcast::<crate::value::ContinuationValue>() {
                return Value::Continuation(k);
            }
            // r30/48-d: FFI token unboxing (round-trip identity — same shape
            // as TD-010)
            if let Ok(t) = b.any.clone().downcast::<crate::ffi::ExternalToken>() {
                return Value::External(t);
            }
            // Defense: unknown Foreign payload (does not occur with the
            // current boxing side — upstream invariant)
            Value::Nil
        }
        None => Value::Nil,
    }
}

/// User-facing structural value equality (r162 / 233 — TD-037: the
/// equality-domain law, D3/D4). Pairs/vectors compare by recursive
/// structure — immutable-by-construction ⟹ acyclic ⟹ total (no
/// slot-mutation primitive exists; closure identity arms cut any
/// capture-graph cycle). Procedural values (closure/builtin/
/// continuation/external token) keep the eq? identity law; immediates
/// and mixed domains delegate to `Value::eq_value` (mixed ⇒ false —
/// the D3 silent-false ruling, Python/JS precedent). The list spine
/// walks iteratively (tail-position loop — long lists stay stack-safe);
/// branch positions (pair heads, vector elements) recurse. Consumers:
/// the `eq` builtin, `assert-eq`, `member`/`assoc` element matching, and
/// the `Op::Eq` dispatch arm (the seed IR path).
pub fn structural_eq(a: &Value, b: &Value, heap: &Heap) -> bool {
    let mut x = a.clone();
    let mut y = b.clone();
    loop {
        match (&x, &y) {
            (Value::Pair(ra), Value::Pair(rb)) => match (heap.get_pair(*ra), heap.get_pair(*rb)) {
                (Some((ha, ta)), Some((hb, tb))) => {
                    if !structural_eq(&unbox_slot(ha, heap), &unbox_slot(hb, heap), heap) {
                        return false;
                    }
                    // spine iteration: the tails become the new subjects
                    // (zero recursion depth on list spines)
                    x = unbox_slot(ta, heap);
                    y = unbox_slot(tb, heap);
                }
                _ => return false,
            },
            (Value::Vector(va), Value::Vector(vb)) => {
                match (heap.get_vector(*va), heap.get_vector(*vb)) {
                    (Some(sa), Some(sb)) => {
                        return sa.len() == sb.len()
                            && sa.iter().zip(sb.iter()).all(|(ea, eb)| {
                                structural_eq(&unbox_slot(*ea, heap), &unbox_slot(*eb, heap), heap)
                            });
                    }
                    _ => return false,
                }
            }
            // immediates + procedural identity + mixed domains (a Pair vs
            // Int lands here — eq_value's exhaustive `_` arm yields false)
            _ => return x.eq_value(&y),
        }
    }
}

/// Root-set enumeration (§19.4 root-set completeness: VM stack + frame
/// locals + global environment + closure captures; foreign roots are held
/// by the Heap itself). The closure capture graph is deduplicated via the
/// visited set (Rc cycle defense). **TD-023 targeted remedy (r24/42-e)**:
/// ① buffers held by the caller and reused across cycles (visited/root —
/// the allocation-free path B); ② non-heap cells skipped in O(1) (the
/// GcCell::has_heap summary — the remedy for the measured dominant cost
/// of deep-frame root scanning).
#[allow(clippy::too_many_arguments)]
fn collect_roots_into(
    stack: &[Value],
    globals: &HashMap<Symbol, Value>,
    frames: &[Frame],
    roots: &mut Vec<GcRef>,
    visited: &mut HashSet<usize>,
) {
    roots.clear();
    visited.clear();
    for v in stack.iter().chain(globals.values()) {
        collect_value_roots(v, roots, visited);
    }
    for f in frames {
        for cell in &f.locals {
            if cell.has_heap() {
                collect_value_roots(&cell.get(), roots, visited);
            }
        }
        for cell in &f.captures {
            if cell.has_heap() {
                collect_value_roots(&cell.get(), roots, visited);
            }
        }
    }
}

fn collect_value_roots(v: &Value, roots: &mut Vec<GcRef>, visited: &mut HashSet<usize>) {
    match v {
        Value::Pair(r) => roots.push(*r),
        // r138 / 208-c — TD-002: the vector slot is a root; the mark phase's
        // children() arm enumerates the element slots transitively
        Value::Vector(r) => roots.push(*r),
        Value::Closure(rc) => {
            let key = Rc::as_ptr(rc) as usize;
            if visited.insert(key) {
                if let ClosureValue::Bytecode { captures, .. } = rc.as_ref() {
                    for cell in captures {
                        if cell.has_heap() {
                            collect_value_roots(&cell.get(), roots, visited);
                        }
                    }
                }
            }
        }
        // r25/42-f (M5): continuation = the sixth GC source (live
        // continuation frames — effect-language-design D12 "the five GC
        // sources extended to six"). The frame chain's locals/captures and
        // the data stack snapshot may all hold heap references; visited
        // guards against nested continuations (κ stored in frame-chain
        // slots) and sharing cycles
        Value::Continuation(rc) => {
            let key = Rc::as_ptr(rc) as usize;
            if visited.insert(key) {
                for sv in &rc.stack {
                    collect_value_roots(sv, roots, visited);
                }
                for f in &rc.frames {
                    for cell in &f.locals {
                        if cell.has_heap() {
                            collect_value_roots(&cell.get(), roots, visited);
                        }
                    }
                    for cell in &f.captures {
                        if cell.has_heap() {
                            collect_value_roots(&cell.get(), roots, visited);
                        }
                    }
                }
            }
        }
        // Reason for the _ arm: immediates (Unit/Nil/Bool/Int/Float/Str/
        // Symbol — TD-002 boxing leaves / Builtin) hold no heap
        // sub-references and need not enter the root set
        _ => {}
    }
}

/// Take a prototype's capture cells (shared by `Closure`/`InstallHandler`
/// — takes shared cells from the current frame per the capture-source
/// descriptors; extracted as a common utility in r25/42-f).
fn take_frame_captures(
    capture_sources: &[kerf_compiler::CaptureSource],
    frames: &[Frame],
    frame_idx: usize,
    span: Span,
) -> Result<Vec<Rc<GcCell>>, VmError> {
    let f = &frames[frame_idx];
    let mut captures: Vec<Rc<GcCell>> = Vec::with_capacity(capture_sources.len());
    for src in capture_sources {
        let cell = match src {
            kerf_compiler::CaptureSource::Local(i) => Rc::clone(
                f.locals
                    .get(*i as usize)
                    .ok_or_else(|| VmError::new("capture source local slot out of bounds", span))?,
            ),
            kerf_compiler::CaptureSource::Captured(i) => {
                Rc::clone(f.captures.get(*i as usize).ok_or_else(|| {
                    VmError::new("capture source capture slot out of bounds", span)
                })?)
            }
        };
        captures.push(cell);
    }
    Ok(captures)
}

/// Resume a continuation (R10-resume — shared by the Continuation arms of
/// `Call`/`TailCall`; returns the resume-point pc).
///
/// Linear uniqueness (D3/E0008): the first resume sets `consumed` + records
/// the first-resume location; a second resume raises a structured-code
/// error. After the frame chain / data stack are restored wholesale, the
/// argument is pushed (= the perform expression's value). Cross-program
/// continuations (out-of-bounds prototype indexes) raise an explicit error
/// — the same defense shape as `call_closure` (§2.3-4 error>silence).
fn resume_continuation(
    rc: &Rc<crate::value::ContinuationValue>,
    arg: Value,
    program: &BcProgram,
    frames: &mut Vec<Frame>,
    stack: &mut Vec<Value>,
    span: Span,
) -> Result<u32, VmError> {
    if rc.consumed.get() {
        return Err(VmError::new_code(
            8,
            crate::messages::err_continuation_resumed_twice(&format!(
                "{}",
                rc.first_resume_span.get()
            )),
            span,
        ));
    }
    rc.consumed.set(true);
    rc.first_resume_span.set(span);
    // Out-of-bounds defense: every prototype index of the restored frame
    // chain must be inside this program
    for f in &rc.frames {
        if f.proto >= program.protos.len() {
            return Err(VmError::new(
                format!(
                    "continuation recovery frame prototype index out of bounds: proto {} / total {}(cross-program continuation unrecoverable)",
                    f.proto,
                    program.protos.len()
                ),
                span,
            ));
        }
    }
    if rc.resume_proto as usize >= program.protos.len() {
        return Err(VmError::new(
            format!(
                "continuation recovery dot prototype out of bounds: proto {} / total {}(cross-program continuation unrecoverable)",
                rc.resume_proto,
                program.protos.len()
            ),
            span,
        ));
    }
    // Frame-chain restoration (suspension-point frames → handler boundary
    // — pushed in stack order)
    frames.extend(rc.frames.iter().cloned());
    // Data-stack wholesale restoration + the argument is the perform
    // expression's value
    stack.clear();
    stack.extend(rc.stack.iter().cloned());
    stack.push(arg);
    Ok(rc.resume_pc)
}

/// GC tracer for Foreign boxed values (TD-010): called by Heap::children
/// during the mark phase — every Pair reference in the closure capture
/// graph goes into out (mirroring collect_value_roots's traversal face; Rc
/// dedup guards against cycles); builtin functions have no GC-visible
/// captures (no-op).
fn trace_foreign_value(any: &Rc<dyn Any>, out: &mut Vec<GcRef>) {
    if let Some(ClosureValue::Bytecode { captures, .. }) =
        any.as_ref().downcast_ref::<ClosureValue>()
    {
        let mut visited: HashSet<usize> = HashSet::new();
        for cell in captures {
            if cell.has_heap() {
                trace_value_refs(&cell.get(), out, &mut visited);
            }
        }
    }
}

/// Trace recursion body (same semantics as collect_value_roots: Pairs
/// enqueued, closures deduplicated and expanded).
fn trace_value_refs(v: &Value, out: &mut Vec<GcRef>, visited: &mut HashSet<usize>) {
    match v {
        Value::Pair(r) => out.push(*r),
        // r138 / 208-c — TD-002: vector slots push their reference (the
        // children() arm walks the elements from there)
        Value::Vector(r) => out.push(*r),
        Value::Closure(rc) => {
            let key = Rc::as_ptr(rc) as usize;
            if visited.insert(key) {
                if let ClosureValue::Bytecode { captures, .. } = rc.as_ref() {
                    for cell in captures {
                        if cell.has_heap() {
                            trace_value_refs(&cell.get(), out, visited);
                        }
                    }
                }
            }
        }
        // Reason for the _ arm: immediates/builtins hold no heap
        // sub-references
        _ => {}
    }
}

// ---- Arithmetic and comparison (Int/Float mixed promotion; explicit
// division-by-zero errors) ----

fn num_add(a: &Value, b: &Value) -> Result<Value, String> {
    match (a, b) {
        (Value::Int(x), Value::Int(y)) => x
            .checked_add(*y)
            .map(Value::Int)
            .ok_or_else(|| "integer addition overflow".to_string()),
        _ => Ok(Value::Float(num_f64(a)? + num_f64(b)?)),
    }
}

fn num_sub(a: &Value, b: &Value) -> Result<Value, String> {
    match (a, b) {
        (Value::Int(x), Value::Int(y)) => x
            .checked_sub(*y)
            .map(Value::Int)
            .ok_or_else(|| "integer subtraction overflow".to_string()),
        _ => Ok(Value::Float(num_f64(a)? - num_f64(b)?)),
    }
}

fn num_mul(a: &Value, b: &Value) -> Result<Value, String> {
    match (a, b) {
        (Value::Int(x), Value::Int(y)) => x
            .checked_mul(*y)
            .map(Value::Int)
            .ok_or_else(|| "integer multiplication overflow".to_string()),
        _ => Ok(Value::Float(num_f64(a)? * num_f64(b)?)),
    }
}

fn num_div(a: &Value, b: &Value) -> Result<Value, String> {
    match (a, b) {
        (Value::Int(x), Value::Int(y)) => {
            if *y == 0 {
                return Err("integer division by zero".to_string());
            }
            Ok(Value::Int(x / y))
        }
        _ => Ok(Value::Float(num_f64(a)? / num_f64(b)?)),
    }
}

fn num_mod(a: &Value, b: &Value) -> Result<Value, String> {
    match (a, b) {
        (Value::Int(x), Value::Int(y)) => {
            if *y == 0 {
                return Err("integer modulo by zero".to_string());
            }
            Ok(Value::Int(x % y))
        }
        _ => Err(format!(
            "mod requires int, got {} / {}",
            a.type_name(),
            b.type_name()
        )),
    }
}

fn num_cmp(
    pred: fn(std::cmp::Ordering) -> bool,
) -> impl Fn(&Value, &Value) -> Result<Value, String> {
    move |a: &Value, b: &Value| {
        let (x, y) = (num_f64(a)?, num_f64(b)?);
        // Exact integer comparison (floats are approximate — the Stage 0
        // numeric tower: mixed Int/Float comparisons promote via f64; the
        // pure-Int path stays exact)
        let ord = match (a, b) {
            (Value::Int(i), Value::Int(j)) => i.cmp(j),
            // f64 has no total order (NaN) — on a partial_cmp mismatch,
            // fall back to Greater (produces no silent error under
            // non-short-circuit comparison-chain semantics; the NaN ≠ NaN
            // semantics is honest)
            _ => x.partial_cmp(&y).unwrap_or(std::cmp::Ordering::Greater),
        };
        Ok(Value::Bool(pred(ord)))
    }
}

fn num_f64(v: &Value) -> Result<f64, String> {
    v.as_number().ok_or_else(|| {
        format!(
            "arithmetic operand requires a number, got {}",
            v.type_name()
        )
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use kerf_compiler::{compile_module, BcProto};
    use kerf_core::{CoreExpr, LiteralValue};
    use kerf_runtime::RuntimeError;
    use kerf_syntax::ScopeSet;
    use kerf_syntax::Symbol;
    use std::rc::Rc as StdRc;

    fn compile_and_run(exprs: &[StdRc<CoreExpr>]) -> Result<Value, VmError> {
        // r49 D59: item-level entry — an expression-item wrapping fixture
        let items: Vec<kerf_core::ModuleItem> = exprs
            .iter()
            .map(|e| kerf_core::ModuleItem::Expr(StdRc::clone(e)))
            .collect();
        let program = compile_module(&items).expect("compile failed");
        let mut globals = HashMap::new();
        let mut heap = Heap::new();
        run_program(&program, &mut globals, &mut heap)
    }

    /// Build a do-desugaring Let chain (test helper — the r45 shape mirrors
    /// core_forms::make_do_let_chain).
    fn let_chain(body: Vec<StdRc<CoreExpr>>, span: Span) -> StdRc<CoreExpr> {
        let mut it = body.into_iter().rev();
        let Some(mut acc) = it.next() else {
            return StdRc::new(CoreExpr::Literal {
                value: LiteralValue::Nil,
                span,
            });
        };
        for e in it {
            acc = StdRc::new(CoreExpr::Let {
                name: Symbol(999999),
                scopes: ScopeSet::new(),
                value: e,
                body: acc,
                span,
            });
        }
        acc
    }

    fn lit(v: i64) -> StdRc<CoreExpr> {
        StdRc::new(CoreExpr::Literal {
            value: LiteralValue::Int(v),
            span: Span::dummy(),
        })
    }

    fn plus_builtin() -> Rc<crate::value::BuiltinFn> {
        crate::value::BuiltinFn::new("+", |_, args| {
            let mut acc = 0i64;
            for a in &args {
                acc += a
                    .as_int()
                    .ok_or_else(|| RuntimeError::new("requires int"))?;
            }
            Ok(Value::Int(acc))
        })
    }

    /// Handwritten bytecode (ISA-level tests — behavioral verification of
    /// the §8.12 opcode groups).
    fn run_handwritten(code: Vec<Op>, consts: Vec<BcConst>) -> Result<Value, VmError> {
        let program = BcProgram {
            protos: vec![BcProto {
                name: Symbol(u32::MAX - 1),
                params: vec![],
                rest_slot: None,
                n_locals: 0,
                capture_names: vec![],
                capture_sources: vec![],
                code,
                debug_spans: vec![Span::dummy(); 8],
                free_vars: vec![],
            }],
            consts,
            entry: 0,
            global_refs: vec![],
            module_name: None,
        };
        let mut globals = HashMap::new();
        let mut heap = Heap::new();
        run_program(&program, &mut globals, &mut heap)
    }

    #[test]
    fn call_closure_invokes_function_with_args() {
        // (define (add x y) ...builtin +...) → run_program loads the global
        // → call_closure enters the function-entry frame with arguments →
        // bottom-frame RET returns the value (B3 host call)
        let body = StdRc::new(CoreExpr::Apply {
            fn_expr: StdRc::new(CoreExpr::Var {
                name: Symbol(100),
                scopes: ScopeSet::new(),
                span: Span::dummy(),
            }),
            args: vec![
                StdRc::new(CoreExpr::Var {
                    name: Symbol(0),
                    scopes: ScopeSet::new(),
                    span: Span::dummy(),
                }),
                StdRc::new(CoreExpr::Var {
                    name: Symbol(1),
                    scopes: ScopeSet::new(),
                    span: Span::dummy(),
                }),
            ],
            span: Span::dummy(),
        });
        let lam = StdRc::new(CoreExpr::Fn {
            params: vec![Symbol(0), Symbol(1)],
            param_scopes: vec![ScopeSet::new()],
            rest: None,
            body,
            span: Span::dummy(),
        });
        let def = kerf_core::ModuleItem::Define {
            name: Symbol(200),
            value: lam,
            span: Span::dummy(),
        };
        let program = compile_module(&[def]).unwrap();
        let mut globals = HashMap::new();
        globals.insert(Symbol(100), Value::Builtin(plus_builtin()));
        let mut heap = Heap::new();
        run_program(&program, &mut globals, &mut heap).unwrap();
        let add = globals.get(&Symbol(200)).cloned().unwrap();
        // Two call shapes: repeated calls do not affect each other
        // (frame/heap-independent entry)
        let mut heap = Heap::new();
        let r = call_closure(
            &program,
            &mut globals,
            &mut heap,
            &add,
            vec![Value::Int(20), Value::Int(22)],
        )
        .unwrap();
        assert_eq!(r, Value::Int(42));
        let mut heap2 = Heap::new();
        let r2 = call_closure(
            &program,
            &mut globals,
            &mut heap2,
            &add,
            vec![Value::Int(1), Value::Int(2)],
        )
        .unwrap();
        assert_eq!(r2, Value::Int(3));
    }

    #[test]
    fn call_closure_arity_and_type_errors() {
        // Non-closure → type error; argument-count mismatch → arity error
        // (same criterion as CALL)
        let program = compile_module(&[kerf_core::ModuleItem::Expr(lit(1))]).unwrap();
        let mut globals = HashMap::new();
        let mut heap = Heap::new();
        let e =
            call_closure(&program, &mut globals, &mut heap, &Value::Int(1), vec![]).unwrap_err();
        assert!(e.message.contains("requires closure"));
        let e2 = call_closure(
            &program,
            &mut globals,
            &mut heap,
            &Value::Builtin(plus_builtin()),
            vec![],
        )
        .unwrap_err();
        assert!(e2.message.contains("requires closure"));
        // Closure exists but the argument count mismatches
        let lam = StdRc::new(CoreExpr::Fn {
            params: vec![Symbol(0)],
            param_scopes: vec![ScopeSet::new()],
            rest: None,
            body: StdRc::new(CoreExpr::Var {
                name: Symbol(0),
                scopes: ScopeSet::new(),
                span: Span::dummy(),
            }),
            span: Span::dummy(),
        });
        let def = kerf_core::ModuleItem::Define {
            name: Symbol(200),
            value: lam,
            span: Span::dummy(),
        };
        let p2 = compile_module(&[def]).unwrap();
        let mut g2 = HashMap::new();
        let mut h2 = Heap::new();
        run_program(&p2, &mut g2, &mut h2).unwrap();
        let f = g2.get(&Symbol(200)).cloned().unwrap();
        let e3 = call_closure(
            &p2,
            &mut g2,
            &mut h2,
            &f,
            vec![Value::Int(1), Value::Int(2)],
        )
        .unwrap_err();
        assert!(e3.message.contains("argument count mismatch"));
    }

    #[test]
    fn call_closure_cross_program_proto_rejected() {
        // Cross-program closure: the prototype index points into another
        // program → explicit rejection (the runtime face of the P3 veto)
        let lam = StdRc::new(CoreExpr::Fn {
            params: vec![Symbol(0)],
            param_scopes: vec![ScopeSet::new()],
            rest: None,
            body: StdRc::new(CoreExpr::Var {
                name: Symbol(0),
                scopes: ScopeSet::new(),
                span: Span::dummy(),
            }),
            span: Span::dummy(),
        });
        let def = kerf_core::ModuleItem::Define {
            name: Symbol(200),
            value: lam,
            span: Span::dummy(),
        };
        let program_a = compile_module(&[def]).unwrap();
        let mut globals = HashMap::new();
        let mut heap = Heap::new();
        run_program(&program_a, &mut globals, &mut heap).unwrap();
        let closure = globals.get(&Symbol(200)).cloned().unwrap();
        // program_b: an empty program (a different prototype table) — the
        // closure's proto is out of bounds
        let program_b = compile_module(&[kerf_core::ModuleItem::Expr(lit(0))]).unwrap();
        let e = call_closure(
            &program_b,
            &mut globals,
            &mut heap,
            &closure,
            vec![Value::Int(5)],
        )
        .unwrap_err();
        assert!(e.message.contains("cross-program closure uncallable"));
    }

    #[test]
    fn call_closure_error_trace_collected() {
        // Runtime error inside the called closure → error propagation +
        // call-frame trace (isomorphic to run_program)
        let body = StdRc::new(CoreExpr::Apply {
            fn_expr: StdRc::new(CoreExpr::Var {
                name: Symbol(0),
                scopes: ScopeSet::new(),
                span: Span::dummy(),
            }),
            args: vec![],
            span: Span::dummy(),
        });
        let lam = StdRc::new(CoreExpr::Fn {
            params: vec![Symbol(0)],
            param_scopes: vec![ScopeSet::new()],
            rest: None,
            body,
            span: Span::dummy(),
        });
        let def = kerf_core::ModuleItem::Define {
            name: Symbol(200),
            value: lam,
            span: Span::dummy(),
        };
        let program = compile_module(&[def]).unwrap();
        let mut globals = HashMap::new();
        let mut heap = Heap::new();
        run_program(&program, &mut globals, &mut heap).unwrap();
        let f = globals.get(&Symbol(200)).cloned().unwrap();
        // Passing a non-builtin value → type error at call time
        let e =
            call_closure(&program, &mut globals, &mut heap, &f, vec![Value::Int(7)]).unwrap_err();
        assert!(!e.message.is_empty());
    }

    #[test]
    fn run_literal_program() {
        assert_eq!(compile_and_run(&[lit(42)]).unwrap(), Value::Int(42));
    }

    #[test]
    fn run_if() {
        let e = StdRc::new(CoreExpr::If {
            cond: StdRc::new(CoreExpr::Literal {
                value: LiteralValue::Bool(true),
                span: Span::dummy(),
            }),
            then_branch: lit(1),
            else_branch: lit(2),
            span: Span::dummy(),
        });
        assert_eq!(compile_and_run(&[e]).unwrap(), Value::Int(1));
    }

    #[test]
    fn run_begin_sequence() {
        let e = let_chain(vec![lit(1), lit(2), lit(3)], Span::dummy());
        assert_eq!(compile_and_run(&[e]).unwrap(), Value::Int(3));
    }

    #[test]
    fn define_and_call_closure() {
        // (define f (fn (x) (+ x 1))) (f 41) → 42
        let plus = StdRc::new(CoreExpr::Var {
            name: Symbol(100),
            scopes: ScopeSet::new(),
            span: Span::dummy(),
        });
        let body = StdRc::new(CoreExpr::Apply {
            fn_expr: plus,
            args: vec![
                StdRc::new(CoreExpr::Var {
                    name: Symbol(0),
                    scopes: ScopeSet::new(),
                    span: Span::dummy(),
                }),
                lit(1),
            ],
            span: Span::dummy(),
        });
        let lam = StdRc::new(CoreExpr::Fn {
            params: vec![Symbol(0)],
            param_scopes: vec![ScopeSet::new()],
            rest: None,
            body,
            span: Span::dummy(),
        });
        let def = kerf_core::ModuleItem::Define {
            name: Symbol(200),
            value: lam,
            span: Span::dummy(),
        };
        let call = StdRc::new(CoreExpr::Apply {
            fn_expr: StdRc::new(CoreExpr::Var {
                name: Symbol(200),
                scopes: ScopeSet::new(),
                span: Span::dummy(),
            }),
            args: vec![lit(41)],
            span: Span::dummy(),
        });
        let program = compile_module(&[def, kerf_core::ModuleItem::Expr(call)]).unwrap();
        let mut globals = HashMap::new();
        globals.insert(Symbol(100), Value::Builtin(plus_builtin()));
        let mut heap = Heap::new();
        assert_eq!(
            run_program(&program, &mut globals, &mut heap).unwrap(),
            Value::Int(42)
        );
    }

    #[test]
    fn closure_captures_shared_mutation() {
        // (define (make-counter) ...): the assign semantics of closure
        // captures — two closures share the capture cells
        // Program: ((fn (n) (fn () n)) 5) → a closure; this verifies the
        // captured value via LOAD_CAPTURED
        let inner = StdRc::new(CoreExpr::Fn {
            params: vec![],
            param_scopes: vec![ScopeSet::new()],
            rest: None,
            body: StdRc::new(CoreExpr::Var {
                name: Symbol(0),
                scopes: ScopeSet::new(),
                span: Span::dummy(),
            }),
            span: Span::dummy(),
        });
        let outer = StdRc::new(CoreExpr::Fn {
            params: vec![Symbol(0)],
            param_scopes: vec![ScopeSet::new()],
            rest: None,
            body: inner,
            span: Span::dummy(),
        });
        let make = StdRc::new(CoreExpr::Apply {
            fn_expr: outer,
            args: vec![lit(5)],
            span: Span::dummy(),
        });
        // ((...) ) calls the inner closure → 5
        let call = StdRc::new(CoreExpr::Apply {
            fn_expr: make,
            args: vec![],
            span: Span::dummy(),
        });
        assert_eq!(compile_and_run(&[call]).unwrap(), Value::Int(5));
    }

    #[test]
    fn isa_make_pair_car_cdr() {
        // PUSH 1, PUSH 2, MAKE_PAIR, CAR → 1 (§8.12 data-construction
        // group)
        let v = run_handwritten(
            vec![
                Op::PushConst(0),
                Op::PushConst(1),
                Op::MakePair,
                Op::Car,
                Op::Halt,
            ],
            vec![BcConst::Int(1), BcConst::Int(2)],
        )
        .unwrap();
        assert_eq!(v, Value::Int(1));
        // CDR → 2
        let v2 = run_handwritten(
            vec![
                Op::PushConst(0),
                Op::PushConst(1),
                Op::MakePair,
                Op::Cdr,
                Op::Halt,
            ],
            vec![BcConst::Int(1), BcConst::Int(2)],
        )
        .unwrap();
        assert_eq!(v2, Value::Int(2));
    }

    #[test]
    fn isa_predicates() {
        let v = run_handwritten(vec![Op::PushNil, Op::IsNull, Op::Halt], vec![]).unwrap();
        assert_eq!(v, Value::Bool(true));
        let v2 = run_handwritten(
            vec![
                Op::PushConst(0),
                Op::PushConst(1),
                Op::MakePair,
                Op::IsPair,
                Op::Halt,
            ],
            vec![BcConst::Int(1), BcConst::Int(2)],
        )
        .unwrap();
        assert_eq!(v2, Value::Bool(true));
    }

    #[test]
    fn isa_stack_ops() {
        // DUP + EQ: 1, 1 (EQ on the same value after DUP) → true
        let v = run_handwritten(
            vec![Op::PushConst(0), Op::Dup, Op::Eq, Op::Halt],
            vec![BcConst::Int(7)],
        )
        .unwrap();
        assert_eq!(v, Value::Bool(true));
        // SWAP: [2,1] → swap → [1,2]; SUB = a-b = 1-2 = -1
        let v2 = run_handwritten(
            vec![
                Op::PushConst(0),
                Op::PushConst(1),
                Op::Swap,
                Op::Sub,
                Op::Halt,
            ],
            vec![BcConst::Int(2), BcConst::Int(1)],
        )
        .unwrap();
        assert_eq!(v2, Value::Int(-1));
    }

    #[test]
    fn truthy_only_bool() {
        // (if 1 2 3): a non-bool condition → explicit type error (§19.5
        // pitfall 3)
        let e = StdRc::new(CoreExpr::If {
            cond: lit(1),
            then_branch: lit(2),
            else_branch: lit(3),
            span: Span::new(0, 0, 12),
        });
        let err = compile_and_run(&[e]).unwrap_err();
        assert!(err.message.contains("truthy"));
        assert_eq!(err.span, Span::new(0, 0, 12));
    }

    #[test]
    fn arity_mismatch_error() {
        // (define f (fn (x) x)) (f 1 2) → argument-count mismatch
        let lam = StdRc::new(CoreExpr::Fn {
            params: vec![Symbol(0)],
            param_scopes: vec![ScopeSet::new()],
            rest: None,
            body: StdRc::new(CoreExpr::Var {
                name: Symbol(0),
                scopes: ScopeSet::new(),
                span: Span::dummy(),
            }),
            span: Span::dummy(),
        });
        let def = kerf_core::ModuleItem::Define {
            name: Symbol(200),
            value: lam,
            span: Span::dummy(),
        };
        let call = StdRc::new(CoreExpr::Apply {
            fn_expr: StdRc::new(CoreExpr::Var {
                name: Symbol(200),
                scopes: ScopeSet::new(),
                span: Span::dummy(),
            }),
            args: vec![lit(1), lit(2)],
            span: Span::dummy(),
        });
        // r49 D59: mixed-item fixture (a Define item + an expression item)
        // compiled directly
        let items = vec![def, kerf_core::ModuleItem::Expr(call)];
        let program = compile_module(&items).unwrap();
        let mut globals = HashMap::new();
        let mut heap = Heap::new();
        let err = run_program(&program, &mut globals, &mut heap).unwrap_err();
        assert!(err.message.contains("argument count mismatch"));
    }

    #[test]
    fn div_by_zero_error() {
        // (define (f) (/ 1 0)) — via the builtin /
        let div_builtin = crate::value::BuiltinFn::new("/", |_, args| {
            let (a, b) = (
                args[0]
                    .as_int()
                    .ok_or_else(|| RuntimeError::new("requires int"))?,
                args[1]
                    .as_int()
                    .ok_or_else(|| RuntimeError::new("requires int"))?,
            );
            if b == 0 {
                return Err(RuntimeError::new("integer division by zero"));
            }
            Ok(Value::Int(a / b))
        });
        let e = StdRc::new(CoreExpr::Apply {
            fn_expr: StdRc::new(CoreExpr::Var {
                name: Symbol(100),
                scopes: ScopeSet::new(),
                span: Span::dummy(),
            }),
            args: vec![lit(1), lit(0)],
            span: Span::dummy(),
        });
        let program = compile_module(&[kerf_core::ModuleItem::Expr(e)]).unwrap();
        let mut globals = HashMap::new();
        globals.insert(Symbol(100), Value::Builtin(div_builtin));
        let mut heap = Heap::new();
        let err = run_program(&program, &mut globals, &mut heap).unwrap_err();
        assert!(err.message.contains("division by zero"));
    }

    #[test]
    fn gc_safepoint_collects_garbage() {
        // Loop-construct discarded pairs: the heap should stay bounded
        // (reclamation via instruction-boundary safepoints)
        // r45/E5 S3 structural-arm note: the original corpus =
        // (do lit×4000) (Do flattened into a Vec — zero nesting); after Do
        // elimination do → a Let chain (4000 levels of nesting) triggers the
        // compiler's recursion depth baseline (the same characteristic as
        // the r44 hm deep-nesting stack-depth limit — in real corpora the
        // number of do items = the number of function-body statements,
        // << 100). The GC-stress semantically equivalent shape = **a
        // top-level flattened sequence** (compile_module emits items one by
        // one at top level + Pop — the same 4000 alloc+Pop rounds, zero
        // deep recursion).
        let mut body: Vec<StdRc<CoreExpr>> = Vec::new();
        for _ in 0..4000 {
            body.push(StdRc::new(CoreExpr::Literal {
                value: LiteralValue::Pair(
                    StdRc::new(LiteralValue::Int(1)),
                    StdRc::new(LiteralValue::Nil),
                ),
                span: Span::dummy(),
            }));
        }
        // r49 D59: the top-level flattened sequence = a sequence of
        // expression items (GC-stress shape-equivalence preserved)
        let items: Vec<kerf_core::ModuleItem> = body
            .iter()
            .map(|e| kerf_core::ModuleItem::Expr(StdRc::clone(e)))
            .collect();
        let program = compile_module(&items).unwrap();
        let mut globals = HashMap::new();
        let mut heap = Heap::with_threshold(512);
        run_program(&program, &mut globals, &mut heap).unwrap();
        // 4000 allocations × 2 slots = 8000 slots; after GC (no roots) it
        // should be far below the total
        assert!(
            heap.slot_count() < 8000,
            "GC not took effect: slots = {}",
            heap.slot_count()
        );
        assert!(
            heap.stats().collections > 0,
            "at least one collection occurs"
        );
    }

    #[test]
    fn deep_recursion_bounded_by_frames_not_stack() {
        // Iterative loop: deep recursion (1000 levels) does not overflow
        // the Rust stack
        // (define (loop n) (if (= n 0) 0 (loop (- n 1)))) (loop 1000)
        fn build(n: u32) -> StdRc<CoreExpr> {
            if n == 0 {
                return StdRc::new(CoreExpr::Literal {
                    value: LiteralValue::Int(0),
                    span: Span::dummy(),
                });
            }
            // (if (= n 0) 0 (loop (- n 1))) simplified to a directly built
            // recursive Apply
            StdRc::new(CoreExpr::Apply {
                fn_expr: StdRc::new(CoreExpr::Var {
                    name: Symbol(200),
                    scopes: ScopeSet::new(),
                    span: Span::dummy(),
                }),
                args: vec![lit(n as i64 - 1)],
                span: Span::dummy(),
            })
        }
        let _ = build;
        // Directly built recursion: f = (fn (n) (if (= n 0) 0 (f (- n 1))))
        let eq_builtin = crate::value::BuiltinFn::new("=", |_, args| {
            Ok(Value::Bool(
                args.iter().all(|a| a.as_int() == args[0].as_int()),
            ))
        });
        let sub_builtin = crate::value::BuiltinFn::new("-", |_, args| {
            let a = args[0]
                .as_int()
                .ok_or_else(|| RuntimeError::new("requires int"))?;
            let b = args.get(1).and_then(|v| v.as_int()).unwrap_or(0);
            Ok(Value::Int(a - b))
        });
        let test_expr = StdRc::new(CoreExpr::Apply {
            fn_expr: StdRc::new(CoreExpr::Var {
                name: Symbol(101),
                scopes: ScopeSet::new(),
                span: Span::dummy(),
            }),
            args: vec![StdRc::new(CoreExpr::Var {
                name: Symbol(0),
                scopes: ScopeSet::new(),
                span: Span::dummy(),
            })],
            span: Span::dummy(),
        });
        let recurse = StdRc::new(CoreExpr::Apply {
            fn_expr: StdRc::new(CoreExpr::Var {
                name: Symbol(200),
                scopes: ScopeSet::new(),
                span: Span::dummy(),
            }),
            args: vec![StdRc::new(CoreExpr::Apply {
                fn_expr: StdRc::new(CoreExpr::Var {
                    name: Symbol(102),
                    scopes: ScopeSet::new(),
                    span: Span::dummy(),
                }),
                args: vec![
                    StdRc::new(CoreExpr::Var {
                        name: Symbol(0),
                        scopes: ScopeSet::new(),
                        span: Span::dummy(),
                    }),
                    lit(1),
                ],
                span: Span::dummy(),
            })],
            span: Span::dummy(),
        });
        let body = StdRc::new(CoreExpr::If {
            cond: test_expr,
            then_branch: lit(0),
            else_branch: recurse,
            span: Span::dummy(),
        });
        let lam = StdRc::new(CoreExpr::Fn {
            params: vec![Symbol(0)],
            param_scopes: vec![ScopeSet::new()],
            rest: None,
            body,
            span: Span::dummy(),
        });
        let def = kerf_core::ModuleItem::Define {
            name: Symbol(200),
            value: lam,
            span: Span::dummy(),
        };
        let call = StdRc::new(CoreExpr::Apply {
            fn_expr: StdRc::new(CoreExpr::Var {
                name: Symbol(200),
                scopes: ScopeSet::new(),
                span: Span::dummy(),
            }),
            args: vec![lit(1000)],
            span: Span::dummy(),
        });
        let program = compile_module(&[def, kerf_core::ModuleItem::Expr(call)]).unwrap();
        let mut globals = HashMap::new();
        globals.insert(Symbol(101), Value::Builtin(eq_builtin));
        globals.insert(Symbol(102), Value::Builtin(sub_builtin));
        let mut heap = Heap::new();
        let v = run_program(&program, &mut globals, &mut heap).unwrap();
        assert_eq!(v, Value::Int(0));
    }

    #[test]
    fn type_error_carries_span_from_debug_table() {
        let e = StdRc::new(CoreExpr::Apply {
            fn_expr: StdRc::new(CoreExpr::Var {
                name: Symbol(100),
                scopes: ScopeSet::new(),
                span: Span::new(0, 10, 20),
            }),
            args: vec![lit(1)],
            span: Span::new(0, 0, 21),
        });
        let program = compile_module(&[kerf_core::ModuleItem::Expr(e)]).unwrap();
        let mut globals = HashMap::new();
        let bad = crate::value::BuiltinFn::new("bad", |_, _| {
            Err(RuntimeError::new("intentional failed"))
        });
        globals.insert(Symbol(100), Value::Builtin(bad));
        let mut heap = Heap::new();
        let err = run_program(&program, &mut globals, &mut heap).unwrap_err();
        assert_eq!(err.message, "intentional failed");
        assert_eq!(err.span, Span::new(0, 0, 21));
    }
}

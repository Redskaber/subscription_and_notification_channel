//! # kerf-vm
//!
//! **Five-orthogonal-axes positioning (lang-design 15 §5.3, v6.0)**: the runtime
//! consumption surface of axes 3/4 (effect/capability) — bytecode execution +
//! dual-path eval cross-checking (semantic verification, §21.8 Phase 1).
//!
//! Dual execution paths (stage0.md §21.8 Phase 1: eval and VM cross-check the
//! semantics of the 9 primitives):
//! - **Metacircular evaluator** (`eval`): `CoreExpr` tree walk + `Rc`
//!   environment chain (§8.4, reference semantics — its production face was
//!   retired in r23/INC7 and archived as the semantic oracle; the new T1
//!   dual-path cross-check criterion = production chain vs seed chain
//!   run_source_seed);
//! - **Bytecode VM** (`vm`): switch-dispatch execution loop +
//!   three-extension-slot frames (§8.12 / §19.5, the production path).
//!
//! **Shared value model**: `Value` (§8.4/§8.5) — immediate values
//! (Unit/Nil/Bool/Int/Float/Str/Symbol — TD-002 r5) + heap references (Pair,
//! managed by kerf-runtime GC) + closures + builtin functions + continuation
//! (r25 M5) + Foreign boxing (TD-010 r24) + External (FFI r30).
//!
//! **Explicit truthy semantics** (§19.5 pitfall 3): only `Bool` participates
//! in conditional jumps; every other type raises TypeMismatch (avoiding the
//! semantic quagmire of JavaScript-style implicit coercion).

pub mod eval;
pub mod ffi;
pub mod messages;
pub mod value;
pub mod vm;

// Explicit re-exports (§10.1 rule 4: glob re-exports are forbidden).
// Convention: this crate exposes all public types and entry points of the execution layer.
pub use eval::{apply_value, eval_expr, eval_program, Env, EvalError};
pub use ffi::{
    alloc_external, call_external, free_external, BorrowedArg, ExternEntry, ExternKind,
    ExternSymbolTable, ExternalToken, HostFn, HostRet, TokenKind, TokenState,
};
pub use messages::{
    err_if_cond_bool, err_not_bool, err_pair_op, err_setbang_unbound, err_vector_op,
};
pub use value::{render_value, BuiltinFn, ClosureValue, GcCell, Value};
pub use vm::{box_value, structural_eq, unbox_slot};
pub use vm::{
    call_closure, run_program, run_program_with_budget, run_program_with_externs, Frame, FrameExt,
    Rt, TraceFrame, VmError,
};

// ---------------------------------------------------------------------------
// Space membership declaration section (r66 / 123-a — lang-design 24 v2.0
// unified two-sided system; 24 §7.2 core-side incorporation table: this
// crate's main types carry three-layer explicit impls [root + core space +
// domain] — the core execution domain (program running — VM execution / eval
// cross-check); the core-side edition of "declaration-as-membership", with
// the sole membership criterion = marker impl [24 §3 A7])
// ---------------------------------------------------------------------------
use kerf_space::{CoreExecutionDomain, CoreSpace, RootSpace};

impl RootSpace for Env {}
impl CoreSpace for Env {}
impl CoreExecutionDomain for Env {}
impl RootSpace for EvalError {}
impl CoreSpace for EvalError {}
impl CoreExecutionDomain for EvalError {}
impl RootSpace for Value {}
impl CoreSpace for Value {}
impl CoreExecutionDomain for Value {}
impl RootSpace for VmError {}
impl CoreSpace for VmError {}
impl CoreExecutionDomain for VmError {}
impl RootSpace for Frame {}
impl CoreSpace for Frame {}
impl CoreExecutionDomain for Frame {}

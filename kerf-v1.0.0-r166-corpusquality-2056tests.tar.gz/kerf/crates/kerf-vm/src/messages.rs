//! Single-source constructors for runtime error messages (TD-018 repayment:
//! unifying the dual-path text split).
//!
//! **Background**: text constants for the same semantic error (e.g. a non-bool
//! if condition) were once scattered across three places — `vm.rs` /
//! `eval.rs` / `builtins.rs` — and diverged ("condition position requires
//! bool" vs "if condition requires bool") — the E code / phase / Span agreed
//! while the text split.
//!
//! **This module**: the kerf-vm common layer (the location designated by the
//! registered TD-018 repayment plan) — same-family messages are constructed
//! here from a single source; the three consumers (VM conditional jumps /
//! the eval reference implementation / driver builtins) reference the same
//! source, so future text evolution changes exactly one place.
//!
//! **Attribution criterion**: the "if condition" message prefix matches the
//! static face (typecheck R1 diagnostics) — conditional sugar such as
//! `and`/`or`/`when`/`unless` all desugars to `if`, so attributing to the
//! `if` form is the sole stable criterion (the runtime mirror of §7.3's sole
//! stable naming criterion).

/// Type error in the if condition position (shared by VM `JumpIfFalse` and the eval if arm).
pub fn err_if_cond_bool(actual: &str) -> String {
    format!("if condition requires bool, got {actual} (truthy semantics explicitly defined)")
}

/// Type error of a `not` operand (shared by the VM `Not` opcode and the driver `not` builtin).
pub fn err_not_bool(actual: &str) -> String {
    format!("not requires bool, got {actual}")
}

/// Unbound `set!` (shared by VM `SetGlobal` and the eval set! arm — the two paths
/// already shared the same text; single-sourcing preserves it).
pub fn err_setbang_unbound() -> String {
    "assign unbound variable".to_string()
}

/// Non-pair operand for `car`/`cdr` (shared by VM opcodes and driver builtins — the two
/// paths already shared the same text).
pub fn err_pair_op(op: &str, actual: &str) -> String {
    format!("{op} requires pair, got {actual}")
}

/// Non-vector operand for the vector builtin family (r138 / 208-c — TD-002,
/// vector-value-design.md D7: single-sourced message constructor — the
/// `err_pair_op` discipline extended to the vector domain; runtime
/// fail-closed enforcement face).
pub fn err_vector_op(op: &str, actual: &str) -> String {
    format!("{op} requires vector, got {actual}")
}

/// E0007: unhandled effect escaping to the top level (r25/42-f —
/// effect-language-design D9; constructed when the VM `Perform` scan finds
/// no matching handler frame).
pub fn err_effect_unhandled(tag: &str) -> String {
    format!("effect '{tag}' is not handled by any handler (escaped to the top level)")
}

/// E0008: continuation resumed twice (linear-uniqueness violation — D3/D9;
/// includes first-resume location tracking, constructed by the Continuation
/// arm of VM `Call`/`TailCall`).
pub fn err_continuation_resumed_twice(first: &str) -> String {
    format!("continuation recovered twice (linear uniqueness -- first recovery at {first})")
}

/// E0009: resume call arity error (a continuation call takes exactly one
/// argument — the arity face of the D4 call shape; the type face of calling
/// a non-continuation value belongs to the generic E0004 family, see the
/// effect-language-design v1.1 execution note).
pub fn err_resume_arity(n: usize) -> String {
    format!("resume accepts exactly one value (continuation call argument count {n})")
}

/// E0010: FFI token used after invalidation (r30/48-d — ffi-ownership-model
/// E9: double free / pass-after-use / use-after-use — the absorbed state once
/// global consumption is in effect).
pub fn err_ffi_token_invalid(context: &str) -> String {
    format!("FFI token already invalidated ({context})")
}

/// E0011: FFI ownership/type violation (ffi-ownership-model E10 — freeing an
/// Opaque token / freeing a non-token value / argument shape mismatch /
/// zero-size defense).
pub fn err_ffi_ownership(detail: &str) -> String {
    format!("FFI ownership violation({detail})")
}

/// E0012: FFI symbol resolution failure (ffi-ownership-model E11 — the extern
/// symbol table has no such entry; the VM-path call-time counterpart of the
/// QBE AOT path's link-time symbol resolution — dual-path consistent
/// fail-closed).
pub fn err_ffi_symbol_resolution(name: &str) -> String {
    format!("external symbol '{name}' is not registered in the extern symbol table (symbol resolution failed)")
}

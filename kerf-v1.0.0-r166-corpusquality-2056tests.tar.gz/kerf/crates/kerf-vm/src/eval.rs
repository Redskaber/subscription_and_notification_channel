//! Metacircular evaluator (stage0.md §8.4 — the reference-semantics path).
//!
//! `CoreExpr` → `Value`: eval/apply mutual recursion; the environment is an
//! `Rc`-linked chain structure (a faithful realization of the §8.4
//! pseudocode). **Lexical closure semantics** (§8.5): captures the
//! definition-site environment; mutable captures propagate via `RefCell`
//! sharing.
//!
//! **Heap usage convention** (crate docs): Pair allocation on the eval path
//! has GC triggering disabled (an established Stage 0 boundary due to
//! incomplete root-set enumeration, TD-009); GC cycles are driven by the VM
//! path at instruction-boundary safepoints (§19.4 pitfall 2).

use std::cell::Cell;
use std::cell::RefCell;
use std::rc::Rc;

use kerf_core::{CoreExpr, LiteralValue, ModuleItem};
use kerf_runtime::{BoxedInput, GcRef, Heap, RuntimeError};
use kerf_span::Span;
use kerf_syntax::{ScopeSet, Symbol};

use crate::value::{BuiltinFn, ClosureValue, Value};
use crate::vm::MAX_FRAMES;

/// Evaluation depth cap for the eval reference path (D3 fix: the original
/// implementation had no guard → Rust stack overflow abort). **Empirically
/// calibrated** (debug build, ≈ 3 KiB physical stack per depth unit):
/// an 8 MiB main thread ≈ 1100 program levels; a 2 MiB test thread ≈ 275
/// levels (≈ 690 depth units). 256 was chosen to keep a 2.7× margin (with
/// the minimal credible 2 MiB stack, the structured error fires before the
/// physical overflow; release frames are smaller, so the margin is larger).
/// Note: the two paths' caps differ numerically (256 vs 100000) — the
/// established boundary of the reference path (same category as TD-009 —
/// eval is the semantic baseline, not the production vehicle); the T1
/// theorem holds within the conventional program domain (depth ≤ 256,
/// including fib(25)).
const MAX_EVAL_DEPTH: usize = 256;

thread_local! {
    /// Evaluation depth counter (maintained by an RAII guard — avoids
    /// invasive signature plumbing).
    static EVAL_DEPTH: Cell<usize> = const { Cell::new(0) };
}

/// Depth guard: +1 on entry, automatic -1 on exit (including `?` early
/// returns); over-limit raises a structured error.
struct DepthGuard;

impl DepthGuard {
    fn enter(span: Span) -> Result<Self, EvalError> {
        let next = EVAL_DEPTH.with(|c| c.get()) + 1;
        if next > MAX_EVAL_DEPTH {
            return Err(EvalError::new(
                format!(
                    "evaluation depth exceeds the limit {} (eval reference path; VM production path has a {} frame structured limit)",
                    MAX_EVAL_DEPTH, MAX_FRAMES
                ),
                span,
            ));
        }
        EVAL_DEPTH.with(|c| c.set(next));
        Ok(DepthGuard)
    }
}

impl Drop for DepthGuard {
    fn drop(&mut self) {
        EVAL_DEPTH.with(|c| c.set(c.get().saturating_sub(1)));
    }
}

/// Evaluation error (`{ message, span }` — the span is taken directly from
/// the CoreExpr node).
#[derive(Debug, Clone, PartialEq)]
pub struct EvalError {
    pub message: String,
    pub span: Span,
    /// Effect escape payload (r25/42-f — the R10 rethrow channel: non-local
    /// control flow of the tree-walk path; `Some` = a Perform rethrow not
    /// yet captured by a Handle). Rendering layers (driver/tests) use
    /// `effect` to distinguish escapes from genuine errors.
    pub effect: Option<EffectEscape>,
}

/// Effect escape payload (the propagation channel from Perform to the nearest
/// matching Handle). `PartialEq` compares by tag reference (payload value
/// comparison is outside the escape-semantics domain — discrimination looks
/// only at the tag).
#[derive(Debug, Clone)]
pub struct EffectEscape {
    /// Effect family tag (the dispatch key).
    pub tag: Rc<str>,
    /// Payload (the value bound to the handler's payload).
    pub payload: Value,
}

impl PartialEq for EffectEscape {
    fn eq(&self, other: &Self) -> bool {
        self.tag == other.tag
    }
}
impl Eq for EffectEscape {}

impl EvalError {
    fn new(message: impl Into<String>, span: Span) -> Self {
        EvalError {
            message: message.into(),
            span,
            effect: None,
        }
    }

    /// Effect rethrow (R10-perform: non-local control flow, not a genuine
    /// error).
    fn effect(tag: Rc<str>, payload: Value, span: Span) -> Self {
        EvalError {
            message: String::new(),
            span,
            effect: Some(EffectEscape { tag, payload }),
        }
    }

    /// Promote from a runtime error (span backfilled from the evaluation
    /// site — Layer 0 carries no location information).
    ///
    /// After the D7 fix the main path backfills via `apply_value`'s
    /// `call_span`; this entry point is retained for error-conversion
    /// compatibility cases.
    #[allow(dead_code)]
    fn from_runtime(e: &RuntimeError, span: Span) -> Self {
        EvalError::new(e.message.clone(), span)
    }
}

/// Lexical environment binding entry (TD-004/r13: name + binding scope set +
/// value).
#[derive(Debug)]
struct Binding {
    name: Symbol,
    scopes: ScopeSet,
    value: Value,
}

/// Lexical environment (chained; a chained extension of §8.4's
/// `Env = Rc<RefCell<HashMap<Symbol, Value>>>` — closures capture the
/// definition-site environment).
///
/// **Scope-set resolution (TD-004/r13)**: bindings carry their binding
/// scope sets; lookup/assignment match by `(name, scopes ⊆)` subset +
/// max-cardinality (Racket set-of-scopes). Empty-scope-set bindings ⊆ any
/// reference set — globals/builtins (injected into the driver root
/// environment) naturally serve as the name-base fallback; the `$hyg$`
/// base-name fallback is still performed by the driver at the global layer
/// (the fallback path).
#[derive(Debug)]
pub struct Env {
    bindings: RefCell<Vec<Binding>>,
    parent: Option<Rc<Env>>,
}

impl Env {
    /// Empty environment.
    pub fn new() -> Rc<Env> {
        Rc::new(Env {
            bindings: RefCell::new(Vec::new()),
            parent: None,
        })
    }

    /// Child environment (the current environment becomes the parent).
    pub fn child(self: &Rc<Env>) -> Rc<Env> {
        Rc::new(Env {
            bindings: RefCell::new(Vec::new()),
            parent: Some(Rc::clone(self)),
        })
    }

    /// Define a global-style binding (empty scope set — fallback semantics;
    /// for driver root-environment injection). A same-name duplicate at the
    /// same layer returns false (D1/E6 criterion).
    pub fn define(&self, name: Symbol, value: Value) -> bool {
        self.define_scoped(name, ScopeSet::new(), value)
    }

    /// Define a scope-set-carrying binding (TD-004: lambda parameter
    /// bindings, etc.). A same-name duplicate at the same layer (regardless
    /// of scopes) returns false — the same criterion as the compiler
    /// A3/expander duplicate-parameter check; cross-layer shadowing is legal.
    pub fn define_scoped(&self, name: Symbol, scopes: ScopeSet, value: Value) -> bool {
        let mut b = self.bindings.borrow_mut();
        if b.iter().any(|e| e.name == name) {
            return false;
        }
        b.push(Binding {
            name,
            scopes,
            value,
        });
        true
    }

    /// Subset-match resolution (within a single environment layer): among
    /// bindings with the same name and `binder.scopes ⊆ ref_scopes`, take
    /// the max-cardinality; on a cardinality tie the first registered wins
    /// (same-layer same-name duplicates are already rejected by
    /// define_scoped, so a tie is only theoretically possible). Returns the
    /// index. Cross-layer resolution is settled by [`Env::lookup`]'s chain
    /// order (inner layers searched first) — equivalent to "inner bindings
    /// have strictly greater cardinality" under the injection invariant
    /// (same resolution as the old name-base chain order on well-formed
    /// programs).
    fn match_index(&self, name: Symbol, ref_scopes: &ScopeSet) -> Option<usize> {
        let b = self.bindings.borrow();
        let mut best: Option<usize> = None;
        let mut best_rank = 0usize;
        for (i, e) in b.iter().enumerate() {
            if e.name != name || !e.scopes.is_subset_of(ref_scopes) {
                continue;
            }
            let rank = e.scopes.len();
            if best.is_none() || rank > best_rank {
                best = Some(i);
                best_rank = rank;
            }
        }
        best
    }

    /// Lookup (along the parent chain — inner layers first; TD-004: match by
    /// `(name, scopes ⊆)`, max-cardinality within a layer; chain order +
    /// injection invariant ⇒ same resolution as Racket's global
    /// max-cardinality on well-formed programs).
    pub fn lookup(&self, name: Symbol, ref_scopes: &ScopeSet) -> Option<Value> {
        if let Some(i) = self.match_index(name, ref_scopes) {
            return Some(self.bindings.borrow()[i].value.clone());
        }
        match &self.parent {
            Some(p) => p.lookup(name, ref_scopes),
            None => None,
        }
    }

    /// Mutate a binding (along the parent chain; TD-004: the same matching
    /// criterion as lookup — a set! target must hit the binding chosen by
    /// the same resolution; a miss reports None).
    pub fn set(&self, name: Symbol, ref_scopes: &ScopeSet, value: Value) -> bool {
        if let Some(i) = self.match_index(name, ref_scopes) {
            self.bindings.borrow_mut()[i].value = value;
            return true;
        }
        match &self.parent {
            Some(p) => p.set(name, ref_scopes, value),
            None => false,
        }
    }
}

/// Evaluation entry point (r49 D59 — a program = a sequence of `ModuleItem`
/// items; returns the last value). Item-level evaluation follows the same
/// criterion as the VM's item-order emission (Define → env.define + value
/// return / Require → nil / Module → body-item recursion / Expr →
/// expression evaluation).
pub fn eval_program(
    items: &[ModuleItem],
    env: &Rc<Env>,
    heap: &mut Heap,
) -> Result<Value, EvalError> {
    let mut last = Value::Nil;
    for item in items {
        last = eval_item(item, env, heap)?;
    }
    Ok(last)
}

/// Item-level evaluation (T1 dual path and the compile side's item order
/// share the same criterion).
fn eval_item(item: &ModuleItem, env: &Rc<Env>, heap: &mut Heap) -> Result<Value, EvalError> {
    match item {
        ModuleItem::Define { name, value, span } => {
            let v = eval_expr(value, env, heap)?;
            // D1/E6 ([06-operational-semantics §2 R6]): same-layer duplicate
            // definition is an error.
            if env.define(*name, v.clone()) {
                Ok(v)
            } else {
                Err(EvalError::new("duplicate variable definition", *span))
            }
        }
        ModuleItem::Require { .. } => {
            // r8 capability declaration: zero runtime semantics — evaluates
            // to nil (consistent with the compile path's zero-bytecode
            // behavior; the T1 dual-path criterion)
            Ok(Value::Nil)
        }
        ModuleItem::Module { items, span, .. } => {
            // Stage 0 single-module: the module body evaluates in the
            // current (global) environment
            let mut last = Value::Nil;
            for inner in items {
                last = eval_item(inner, env, heap)?;
            }
            let _ = span;
            Ok(last)
        }
        ModuleItem::Expr(e) => eval_expr(e, env, heap),
    }
}

/// Evaluate a single CoreExpr (entry function, §10.1 rule 1).
pub fn eval_expr(e: &CoreExpr, env: &Rc<Env>, heap: &mut Heap) -> Result<Value, EvalError> {
    let _depth = DepthGuard::enter(e.span())?;
    match e {
        CoreExpr::Literal { value, span } => eval_literal(value, heap, *span),
        CoreExpr::Var { name, scopes, span } => env
            .lookup(*name, scopes)
            .ok_or_else(|| EvalError::new("unbound variable", *span)),
        CoreExpr::Fn {
            params,
            param_scopes,
            rest,
            body,
            ..
        } => Ok(Value::Closure(Rc::new(ClosureValue::Eval {
            params: params.clone(),
            param_scopes: param_scopes.clone(),
            rest: rest.clone(),
            body: Rc::clone(body),
            env: Rc::clone(env),
        }))),
        CoreExpr::Apply {
            fn_expr,
            args,
            span,
        } => {
            let f = eval_expr(fn_expr, env, heap)?;
            let mut arg_vals = Vec::with_capacity(args.len());
            // Evaluation-order contract (06 §1.3/§2 A1): the callee evaluates
            // first, then arguments left to right
            for a in args {
                arg_vals.push(eval_expr(a, env, heap)?);
            }
            // D7 fix: apply errors pass through faithfully (no more per-layer
            // prefix wrapping / Span overriding)
            apply_value(f, arg_vals, heap, *span)
        }
        CoreExpr::If {
            cond,
            then_branch,
            else_branch,
            span,
        } => {
            let c = eval_expr(cond, env, heap)?;
            // TD-018: same-source message as VM `JumpIfFalse` (single-sourced
            // in messages)
            match c {
                Value::Bool(true) => eval_expr(then_branch, env, heap),
                Value::Bool(false) => eval_expr(else_branch, env, heap),
                other => Err(EvalError::new(
                    crate::messages::err_if_cond_bool(other.type_name()),
                    *span,
                )),
            }
        }
        CoreExpr::Assign {
            name,
            scopes,
            value,
            span,
        } => {
            let v = eval_expr(value, env, heap)?;
            if env.set(*name, scopes, v.clone()) {
                Ok(v)
            } else {
                Err(EvalError::new(
                    crate::messages::err_setbang_unbound(),
                    *span,
                ))
            }
        }
        CoreExpr::Let {
            name,
            scopes,
            value,
            body,
            span,
        } => {
            // r45/E5 S3 structural arm (22 §14 D42/D43): Let's dual semantics
            // (T1 dual path and the compile side's discard/bind share the
            // same criterion).
            // ① do desugaring chain (constant name "do" — a reserved-word
            //    name user Vars never reference): the value's evaluation side
            //    effects happen, the value is discarded, and the chain
            //    recurses — matching the original Do's per-item evaluation
            //    semantics;
            // ② let true binding: lexical env extension (child env — outer
            //    layers unchanged), body evaluated in the extended env.
            let v = eval_expr(value, env, heap)?;
            let referenced = body
                .free_var_occurrence_list()
                .iter()
                .any(|(s, _)| *s == *name);
            if referenced {
                // Lexical binding: installed in a child environment
                // (cross-layer shadowing is legal — the Env criterion)
                let child = env.child();
                if !child.define_scoped(*name, scopes.clone(), v) {
                    return Err(EvalError::new("duplicate variable definition", *span));
                }
                eval_expr(body, &child, heap)
            } else {
                eval_expr(body, env, heap)
            }
        }
        // r49 declaration-layer arms: Define/Module/Require are outside the
        // expression domain (the expander rejects them structurally — the
        // T1 dual path carries them at item level in eval_item)
        // r25/42-f (M3/D7 — the eval-domain effect mapping): the tree-walk
        // path's R10 rethrow is carried via the `EvalError.effect` escape
        // channel (non-local control flow); handle capture dispatches by
        // tag (R11-dispatch). **Domain limit (D7 + v1.1 execution note)**:
        // resume_var binds a sentinel builtin (calling it raises an
        // explicit domain error — the same-shaped precedent as
        // `call_closure` rejecting Eval closures: tree-walk continuations
        // cannot be reified on the Rust call stack; T1 consistency for
        // resume programs is carried on the VM face by the seed/production
        // dual compilation chain (the 42-d new criterion))
        CoreExpr::Perform { effect, span } => {
            let v = eval_expr(effect, env, heap)?;
            // Effect value destructuring: (tag . payload) (tag = symbol
            // value — the same criterion as the VM path)
            match &v {
                Value::Pair(r) => {
                    let (car, cdr) = match heap.get_pair(*r) {
                        Some(p) => p,
                        None => {
                            return Err(EvalError::new(
                                "perform effect value should be (tag . payload) dotted pair",
                                *span,
                            ))
                        }
                    };
                    let tag_v = crate::vm::unbox_slot(car, heap);
                    match tag_v {
                        Value::Symbol(s) => {
                            let payload = crate::vm::unbox_slot(cdr, heap);
                            Err(EvalError::effect(s, payload, *span))
                        }
                        other => Err(EvalError::new(
                            format!(
                                "perform effect value tag position requires symbol, got {}",
                                other.type_name()
                            ),
                            *span,
                        )),
                    }
                }
                other => Err(EvalError::new(
                    format!(
                        "perform effect value requires (tag . payload) dotted pair, got {}",
                        other.type_name()
                    ),
                    *span,
                )),
            }
        }
        CoreExpr::Handle {
            tag,
            payload_var,
            payload_scopes,
            resume_var,
            resume_scopes,
            handler_body,
            body,
            span,
        } => {
            match eval_expr(body, env, heap) {
                // R11-return: the body's completion value = the handle
                // expression's value
                Ok(v) => Ok(v),
                Err(e) => {
                    if let Some(esc) = &e.effect {
                        if esc.tag.as_ref() == tag.as_ref() {
                            // R11-dispatch: match — evaluate the handler body
                            // (payload/resume binding injection; lexical child
                            // environment)
                            let h_env = env.child();
                            h_env.define_scoped(
                                *payload_var,
                                payload_scopes.clone(),
                                esc.payload.clone(),
                            );
                            h_env.define_scoped(
                                *resume_var,
                                resume_scopes.clone(),
                                Value::Builtin(Rc::new(BuiltinFn {
                                    name: "resume",
                                    f: Rc::new(|_heap, _args| {
                                        Err(RuntimeError::new(
                                            "eval path continuation uncallable(tree-walking path domain restriction -- resume consistency by VM dual compile chain carries; effect-language-design v1.1 execution annotation)",
                                        ))
                                    }),
                                })),
                            );
                            eval_expr(handler_body, &h_env, heap)
                        } else {
                            // Non-matching tag: keep rethrowing along the
                            // frame stack (R11-dispatch)
                            Err(e)
                        }
                    } else {
                        // Genuine error pass-through (error-absorption
                        // semantics as in 06 §3)
                        let _ = span;
                        Err(e)
                    }
                }
            }
        }
        // r136 / 206-b (TD-033 — D14 reference face): group install on the
        // tree-walk path — the whole group is ONE catch frame; a matched
        // arm's handler body evaluates OUTSIDE it (sibling tags performed
        // inside the handler body rethrow past this group — the symmetric
        // non-protection of the Koka-style reading, which the single-catch
        // shape gives naturally; the first-occurrence arm wins on
        // duplicate-free groups — the expander enforces tag uniqueness)
        CoreExpr::HandleGroup { arms, body, span } => {
            match eval_expr(body, env, heap) {
                // R11-return: the body's completion value = the group
                // expression's value
                Ok(v) => Ok(v),
                Err(e) => {
                    if let Some(esc) = &e.effect {
                        if let Some(arm) = arms.iter().find(|a| a.tag.as_ref() == esc.tag.as_ref())
                        {
                            // R11-dispatch on the matched entry (group
                            // consumption is structural here: the catch
                            // frame is gone once the handler body runs)
                            let h_env = env.child();
                            h_env.define_scoped(
                                arm.payload_var,
                                arm.payload_scopes.clone(),
                                esc.payload.clone(),
                            );
                            h_env.define_scoped(
                                arm.resume_var,
                                arm.resume_scopes.clone(),
                                Value::Builtin(Rc::new(BuiltinFn {
                                    name: "resume",
                                    f: Rc::new(|_heap, _args| {
                                        Err(RuntimeError::new(
                                            "eval path continuation uncallable(tree-walking path domain restriction -- resume consistency by VM dual compile chain carries; effect-language-design v1.1 execution annotation)",
                                        ))
                                    }),
                                })),
                            );
                            eval_expr(&arm.handler_body, &h_env, heap)
                        } else {
                            // No arm matches: rethrow past the whole group
                            // (group non-matching transparency)
                            let _ = span;
                            Err(e)
                        }
                    } else {
                        // Genuine error pass-through (error-absorption
                        // semantics as in 06 §3)
                        let _ = span;
                        Err(e)
                    }
                }
            }
        }
    }
}

/// Apply a function value (the apply side, §8.4 `apply`).
///
/// D7 fix: errors pass through faithfully in `EvalError` form — errors from
/// an Eval closure body (message + inner Span) propagate unchanged, no
/// longer wrapped layer by layer with an "evaluation failed:" prefix
/// (before the fix, an f→g→error report accumulated two prefix layers and
/// the Span landed on the outermost call site); errors without location
/// information (arity/non-callable/builtin) are backfilled with `call_span`.
pub fn apply_value(
    f: Value,
    mut args: Vec<Value>,
    heap: &mut Heap,
    call_span: Span,
) -> Result<Value, EvalError> {
    match &f {
        Value::Closure(rc) if matches!(rc.as_ref(), ClosureValue::Eval { .. }) => {
            let (params, param_scopes, rest, body, env) = match rc.as_ref() {
                ClosureValue::Eval {
                    params,
                    param_scopes,
                    rest,
                    body,
                    env,
                } => (params, param_scopes, rest, body, env),
                _ => unreachable!("narrowed above"),
            };
            // r165 / 236-c (D4-d): the rest face — minimum arity with no
            // upper bound; excess arguments fold into the rest binding's
            // nil-terminated pair chain (the VM frame-setup discipline
            // mirrored: box each element, right-fold onto the boxed-nil
            // terminator).
            let arity_error = match rest {
                Some(_) if args.len() < params.len() => Some(format!(
                    "procedure argument count mismatch: expected at least {}, got {}",
                    params.len(),
                    args.len()
                )),
                None if params.len() != args.len() => Some(format!(
                    "procedure argument count mismatch: expected {}, got {}",
                    params.len(),
                    args.len()
                )),
                _ => None,
            };
            if let Some(msg) = arity_error {
                return Err(EvalError::new(msg, call_span));
            }
            let mut rest_value = None;
            if let Some((rname, rsp)) = rest {
                let k = params.len();
                let mut chain = heap.alloc_boxed(BoxedInput::Nil);
                while args.len() > k {
                    let head = args.pop().expect("guarded by the arity gate");
                    let elem = crate::box_value(&head, heap);
                    chain = heap.alloc_pair(elem, chain);
                }
                rest_value = Some((*rname, rsp.clone(), Value::Pair(chain)));
            }
            let call_env = env.child();
            for ((p, ps), a) in params.iter().zip(param_scopes.iter()).zip(args) {
                // A3 guard: duplicate names in the parameter list are an
                // error (same-name parameters may appear only once per
                // layer). Bindings carry the parameter binding scope set
                // (TD-004: in-body references hit via subset matching).
                if !call_env.define_scoped(*p, ps.clone(), a) {
                    return Err(EvalError::new(
                        "procedure has duplicate argument names (lambda formal parameter list has duplicates)",
                        call_span,
                    ));
                }
            }
            if let Some((rname, rsp, chain)) = rest_value {
                if !call_env.define_scoped(rname, rsp, chain) {
                    return Err(EvalError::new(
                        "procedure has duplicate argument names (lambda formal parameter list has duplicates)",
                        call_span,
                    ));
                }
            }
            // Faithful pass-through: body evaluation errors (including Span)
            // are not rewritten
            eval_expr(body, &call_env, heap)
        }
        Value::Builtin(b) => b
            .call(heap, args)
            .map_err(|e| EvalError::new(e.message, call_span)),
        other => Err(EvalError::new(
            format!("uncallable value: {}", other.type_name()),
            call_span,
        )),
    }
}

/// Literal evaluation (pair structures are built recursively on the heap).
#[allow(clippy::only_used_in_recursion)] // span propagates through recursion to leaf errors (error-location consistency)
fn eval_literal(v: &LiteralValue, heap: &mut Heap, span: Span) -> Result<Value, EvalError> {
    match v {
        LiteralValue::Int(i) => Ok(Value::Int(*i)),
        LiteralValue::Float(f) => Ok(Value::Float(*f)),
        LiteralValue::Str(s) => Ok(Value::Str(s.clone())),
        LiteralValue::Symbol(s) => Ok(Value::Symbol(s.clone())),
        LiteralValue::Bool(b) => Ok(Value::Bool(*b)),
        LiteralValue::Nil => Ok(Value::Nil),
        LiteralValue::Pair(car, cdr) => {
            let car_v = eval_literal(car, heap, span)?;
            let cdr_v = eval_literal(cdr, heap, span)?;
            let car_r = to_heap_ref(&car_v, heap);
            let cdr_r = to_heap_ref(&cdr_v, heap);
            Ok(Value::Pair(heap.alloc_pair(car_r, cdr_r)))
        }
    }
}

/// Box a value into a heap reference (immediates boxed by type — the same
/// semantics as the VM path's box_value).
fn to_heap_ref(v: &Value, heap: &mut Heap) -> GcRef {
    crate::vm::box_value(v, heap)
}

//! Runtime value model (stage0.md §8.4 `Value` / §8.5 basic closures).
//!
//! Dual-path closure shapes:
//! - `ClosureValue::Eval`: the tree-walk path (`Rc` environment chain — a
//!   faithful realization of the §8.4 pseudocode);
//! - `ClosureValue::Bytecode`: the VM path (prototype index + shared mutable
//!   capture cells — the set! semantics of lexical closures propagates via
//!   `Rc<GcCell>`; TD-023 r24: cells carry a heap-root summary flag, so GC
//!   root scanning skips non-heap cells in O(1)).

use std::cell::{Cell, RefCell};
use std::collections::HashMap;
use std::rc::Rc;

use kerf_core::CoreExpr;
use kerf_runtime::{GcRef, Heap, RuntimeError};
use kerf_syntax::{ScopeSet, Symbol};

use crate::eval::Env;

/// Runtime value (shared by both paths).
#[derive(Debug, Clone)]
pub enum Value {
    /// Unit (the undefined return value — kept distinct from Nil in Stage 0 to
    /// support future multi-value/effect extensions).
    Unit,
    /// Nil (the data counterpart of false; the classic Lisp '()).
    Nil,
    Bool(bool),
    Int(i64),
    Float(f64),
    Str(Rc<str>),
    /// Symbol value (the runtime shape of a quoted symbol datum — TD-002;
    /// equal by name).
    Symbol(Rc<str>),
    /// Heap reference: the pair (a . b) (managed by the kerf-runtime GC).
    Pair(GcRef),
    /// Heap reference: the vector (r138 / 208-c — TD-002,
    /// vector-value-design.md D1/D3: immutable by construction; the slot
    /// holds `HeapObj::Vector(Vec<GcRef>)` with per-element boxed slots).
    /// eq? by slot reference (same law as Pair — TD-010 boxing discipline);
    /// rendering walks elements via the heap (`#(1 2 3)`).
    Vector(GcRef),
    /// Closure.
    Closure(Rc<ClosureValue>),
    /// Builtin function (registered by the driver into the global environment).
    Builtin(Rc<BuiltinFn>),
    /// Suspended continuation (r25/42-f — effect-language-design §2.3: the
    /// three ingredients captured frame chain + suspension-point environment +
    /// uniqueness state; the D4 call shape goes through the `Call`
    /// channel). Heap-rootness: carries frame-chain/data-stack snapshots —
    /// may contain heap sub-references (GC six-source extension: live
    /// continuation frames, M5).
    Continuation(Rc<ContinuationValue>),
    /// FFI external token (r30/48-d — ffi-ownership-model §5: CPointer/Opaque
    /// tokens; linearity is realized via "globally-effective consumption" —
    /// Rc sharing + an embedded state cell, so one FreeExternal invalidates
    /// all shared bindings synchronously). Boxed shape = `HeapObj::Foreign`
    /// (payload Rc&lt;ExternalToken&gt;, no GC sub-references — the token payload
    /// does not participate in GC reachability).
    External(Rc<crate::ffi::ExternalToken>),
}

impl Value {
    /// Type name (for diagnostics).
    pub fn type_name(&self) -> &'static str {
        match self {
            Value::Unit => "unit",
            Value::Nil => "nil",
            Value::Bool(_) => "bool",
            Value::Int(_) => "int",
            Value::Float(_) => "float",
            Value::Str(_) => "str",
            Value::Symbol(_) => "symbol",
            Value::Pair(_) => "pair",
            Value::Vector(_) => "vector",
            Value::Closure(_) => "procedure",
            Value::Builtin(_) => "builtin-procedure",
            Value::Continuation(_) => "continuation",
            Value::External(_) => "external",
        }
    }

    /// Truthiness test (§19.5 pitfall 3: Bool only — other types raise an
    /// explicit error). **Single implementation** (TD-018): VM conditional
    /// jumps and the eval if arm share this entry point; the message is
    /// single-sourced through `messages::err_if_cond_bool` (the two paths'
    /// texts previously split).
    pub fn truthy(&self) -> Result<bool, RuntimeError> {
        match self {
            Value::Bool(b) => Ok(*b),
            other => Err(RuntimeError::new(crate::messages::err_if_cond_bool(
                other.type_name(),
            ))),
        }
    }

    /// Number extraction (arithmetic operands).
    pub fn as_number(&self) -> Option<f64> {
        match self {
            Value::Int(i) => Some(*i as f64),
            Value::Float(f) => Some(*f),
            _ => None,
        }
    }

    /// Numeric coercion to i64 (the strict integer path).
    pub fn as_int(&self) -> Option<i64> {
        match self {
            Value::Int(i) => Some(*i),
            _ => None,
        }
    }

    /// Generic equality (eq? semantics: immediates by value, heap values by
    /// reference, closures by identity).
    ///
    /// Str is an immediate value (carried by `Rc<str>`) — compared by
    /// **content** (D2 fix: the original pointer comparison split the VM
    /// constant-pool dedup path from the eval independent-allocation path,
    /// violating T1; it also contradicted this comment's own statement that
    /// "immediates compare by value").
    pub fn eq_value(&self, other: &Value) -> bool {
        match (self, other) {
            (Value::Unit, Value::Unit) => true,
            (Value::Nil, Value::Nil) => true,
            (Value::Bool(a), Value::Bool(b)) => a == b,
            (Value::Int(a), Value::Int(b)) => a == b,
            (Value::Float(a), Value::Float(b)) => a == b,
            (Value::Str(a), Value::Str(b)) => a == b,
            (Value::Symbol(a), Value::Symbol(b)) => a == b,
            (Value::Pair(a), Value::Pair(b)) => a == b,
            // r138 / 208-c — TD-002: vectors compare by slot reference (the
            // immutable-by-construction design makes per-instance identity
            // the natural eq? law — same shape as Pair)
            (Value::Vector(a), Value::Vector(b)) => a == b,
            (Value::Closure(a), Value::Closure(b)) => Rc::ptr_eq(a, b),
            (Value::Builtin(a), Value::Builtin(b)) => Rc::ptr_eq(a, b),
            (Value::Continuation(a), Value::Continuation(b)) => Rc::ptr_eq(a, b),
            // r30/48-d: tokens compare by identity (same Rc = same token;
            // consuming any shared reference invalidates it globally — eq?
            // semantics has the same shape as for closures)
            (Value::External(a), Value::External(b)) => Rc::ptr_eq(a, b),
            _ => false,
        }
    }
}

/// Closure value (dual-path shapes).
#[derive(Debug)]
pub enum ClosureValue {
    /// Metacircular evaluator path: parameters + parameter-binding scope
    /// sets (TD-004/r13, parallel to `params` and of equal length) + body
    /// expression + definition-site environment.
    /// r165 / 236-c (variadic-rest-design.md D4-d): the rest binding —
    /// `Some((name, binding_scopes))` when the source fn declares
    /// `...name: T` (the apply path folds excess arguments into the
    /// nil-terminated pair chain bound to the name).
    Eval {
        params: Vec<Symbol>,
        param_scopes: Vec<ScopeSet>,
        rest: Option<(Symbol, ScopeSet)>,
        body: Rc<CoreExpr>,
        env: Rc<Env>,
    },
    /// Bytecode VM path: prototype index + capture cells (shared mutable —
    /// carried by GcCell, with the heap-root summary flag maintained on
    /// every write).
    Bytecode {
        proto: u32,
        captures: Vec<Rc<GcCell>>,
    },
}

/// Suspended continuation (r25/42-f — the three ingredients of
/// effect-language-design §2.3 + implementation-necessary supplements):
///
/// - ① Captured frame chain: a structural snapshot of frames from the
///   suspension point to the handler frame boundary (each `Frame` cloned
///   structurally — locals/captures are `Rc<GcCell>` shared cells: after
///   resumption, variable visibility matches the suspension moment, and
///   set! propagates through the shared cells);
/// - ② Data-stack snapshot: the VM's flat data stack is shared across
///   frames, so suspension/resumption must restore it explicitly (an
///   implementation-necessary supplement beyond the design doc's three
///   ingredients — v1.1 execution note);
/// - ③ Uniqueness state: `consumed` (a frame-level single-consumption flag
///   Fresh → Resumed; D3 linear uniqueness — a second resume = the E0008
///   diagnostic, not UB; shared across frames via `Rc` + `Cell`);
///   first-resume location tracking feeds the E0008 diagnostic rendering
///   (D9).
#[derive(Debug)]
pub struct ContinuationValue {
    /// Captured frame chain (suspension-point frame → all frames above the
    /// handler frame boundary, in stack order).
    pub frames: Vec<crate::vm::Frame>,
    /// Data-stack snapshot (the complete stack at suspension time — on
    /// resume the whole stack is restored and then the argument is pushed).
    pub stack: Vec<Value>,
    /// Resume-point pc (the instruction after the perform instruction in
    /// the suspended frame — execution continues there after resumption).
    pub resume_pc: u32,
    /// Suspended-frame prototype (the execution prototype of the last frame
    /// of the restored chain — used as a cross-program call bounds defense).
    pub resume_proto: u32,
    /// Handler boundary index (the handler frame's index in the frame stack
    /// at perform time — r133 / 203-c2: the resume must discard every stale
    /// frame above this index — the transformed H-execution frame and its
    /// call chain — before restoring the suspended chain. Without the
    /// teardown a resume issued from a deeper frame (e.g. a non-tail call
    /// of a k-capturing closure) leaves the arm-body frame live, and the
    /// restored RET cascade re-enters the arm body at the trampoline's
    /// ret_pc — clobbering slots with the handle value (the observed
    /// `uncallable value: int` face).
    pub boundary: usize,
    /// Linear-uniqueness flag (single consumption — the E0008 criterion).
    pub consumed: Cell<bool>,
    /// First resume location (rendered by the E0008 diagnostic as "resumed
    /// twice" — the Span of the first call site).
    pub first_resume_span: Cell<kerf_span::Span>,
}

/// Shared mutable cell for the VM path (the TD-023 targeted remedy,
/// r24/42-e): value + **heap-root summary flag**. The flag is maintained by
/// the write path (`set`): Pair/Closure → true, everything else → false —
/// a precisely conservative summary of the current value (set on every
/// write, a sound invariant). GC root-set enumeration skips non-heap cells
/// in O(1) (deep frame root scanning measured as the dominant cost — the
/// targeted aspect of the superlinear 2×→3.2-3.7× regression on
/// non-tail-shaped benchmarks; see performance-baseline §4).
#[derive(Debug)]
pub struct GcCell {
    has_heap: Cell<bool>,
    value: RefCell<Value>,
}

impl GcCell {
    pub fn new(v: Value) -> Self {
        let has_heap = matches!(
            v,
            Value::Pair(_) | Value::Closure(_) | Value::Continuation(_)
        );
        GcCell {
            has_heap: Cell::new(has_heap),
            value: RefCell::new(v),
        }
    }

    /// Write (maintains the heap-root summary — TD-023 sound invariant: set
    /// on every write).
    pub fn set(&self, v: Value) {
        self.has_heap.set(matches!(
            v,
            Value::Pair(_) | Value::Closure(_) | Value::Continuation(_)
        ));
        *self.value.borrow_mut() = v;
    }

    /// Read.
    pub fn get(&self) -> std::cell::Ref<'_, Value> {
        self.value.borrow()
    }

    /// Heap-rootness (GC root-scan skip criterion: false ⇒ the current value
    /// must be an immediate/builtin — no heap sub-references, so it need not
    /// enter the root set).
    pub fn has_heap(&self) -> bool {
        self.has_heap.get()
    }
}

/// Builtin function implementation type (§10.1 rule 2: `-er` suffix
/// semantics).
pub type BuiltinImpl = Rc<dyn Fn(&mut Heap, Vec<Value>) -> Result<Value, RuntimeError>>;

/// Builtin function (registered by the driver; the signature takes `&mut
/// Heap` to support pair construction).
pub struct BuiltinFn {
    /// Name (for diagnostics and as the registration key).
    pub name: &'static str,
    /// Implementation.
    pub f: BuiltinImpl,
}

impl std::fmt::Debug for BuiltinFn {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "BuiltinFn({})", self.name)
    }
}

impl BuiltinFn {
    /// Constructor.
    pub fn new(
        name: &'static str,
        f: impl Fn(&mut Heap, Vec<Value>) -> Result<Value, RuntimeError> + 'static,
    ) -> Rc<BuiltinFn> {
        Rc::new(BuiltinFn {
            name,
            f: Rc::new(f),
        })
    }

    /// Call.
    pub fn call(&self, heap: &mut Heap, args: Vec<Value>) -> Result<Value, RuntimeError> {
        (self.f)(heap, args)
    }
}

/// Value rendering (the output shape of print/write-line; pairs are walked
/// via the heap).
pub fn render_value(v: &Value, heap: &Heap) -> String {
    match v {
        Value::Unit => "unit".to_string(),
        Value::Nil => "nil".to_string(),
        Value::Bool(b) => b.to_string(),
        Value::Int(i) => i.to_string(),
        Value::Float(f) => {
            if f.fract() == 0.0 && f.is_finite() {
                format!("{:.1}", f)
            } else {
                f.to_string()
            }
        }
        Value::Str(s) => s.to_string(),
        Value::Symbol(s) => s.to_string(),
        Value::Pair(r) => render_pair(*r, heap, &mut HashMap::new()),
        // r138 / 208-c — TD-002: vector rendering — the bracket form
        // `[1 2 3]` (the same shape as the literal syntax: round-trip
        // readable — the lexer accepts brackets; consistent with the Stx
        // datum render `[...]`). The defensive seen-map follows render_pair
        // — under the D1 immutable design cycles are unreachable by pure
        // construction, the guard is retained for the same defensive
        // reason as pairs).
        Value::Vector(r) => render_vector(*r, heap, &mut HashMap::new()),
        // r25/42-f: continuation rendering (the output shape of
        // print/write-line — the Racket `#<continuation>` convention: an
        // opaque value, no frame-chain enumeration)
        Value::Continuation(_) => "#<continuation>".to_string(),
        // r30/48-d: FFI token rendering (opaque — external-domain addresses
        // never enter user-facing rendering; invalid-state visibility for
        // diagnostics)
        Value::External(t) => {
            if t.is_valid() {
                "#<external>".to_string()
            } else {
                "#<external:invalid>".to_string()
            }
        }
        Value::Closure(_) => "#<procedure>".to_string(),
        Value::Builtin(b) => format!("#<builtin:{}>", b.name),
    }
}

/// Pair rendering (classic Scheme list printing: `(1 2 3)` / dotted pair
/// `(1 . 2)`; self-references truncated with `...` — human-legible output,
/// §2.2 principle 16).
fn render_pair(r: GcRef, heap: &Heap, seen: &mut HashMap<GcRef, ()>) -> String {
    let mut parts: Vec<String> = Vec::new();
    let mut cur = r;
    loop {
        if seen.contains_key(&cur) {
            parts.push("...".to_string());
            return format!("({})", parts.join(" "));
        }
        seen.insert(cur, ());
        match heap.get_pair(cur) {
            Some((car, cdr)) => {
                parts.push(render_slot(car, heap));
                // Tail determination: nil terminates / non-pair dotted
                // tail / pair continues the walk / self-loop truncation
                match heap.get_pair(cdr) {
                    None => match slot_terminal(cdr, heap) {
                        Some(rendered) => {
                            if rendered == "nil" {
                                return format!("({})", parts.join(" "));
                            }
                            parts.push(".".to_string());
                            parts.push(rendered);
                            return format!("({})", parts.join(" "));
                        }
                        None => return format!("({})", parts.join(" ")),
                    },
                    Some((_, cdr2)) if cdr2 == cdr => {
                        parts.push(".".to_string());
                        parts.push("...".to_string());
                        return format!("({})", parts.join(" "));
                    }
                    Some(_) => {
                        cur = cdr;
                    }
                }
            }
            None => {
                parts.push(render_slot(cur, heap));
                return format!("({})", parts.join(" "));
            }
        }
    }
}

/// Slot terminal-value rendering (nil / immediates; pair slots return None
/// — the caller continues the walk). TD-010 (r24): Foreign slots
/// (closures/builtins) render as function values.
fn slot_terminal(r: GcRef, heap: &Heap) -> Option<String> {
    match heap.get(r).map(|s| s.obj.clone()) {
        Some(kerf_runtime::HeapObj::Nil) => Some("nil".to_string()),
        Some(kerf_runtime::HeapObj::Int(v)) => Some(v.to_string()),
        Some(kerf_runtime::HeapObj::Float(v)) => Some(v.to_string()),
        Some(kerf_runtime::HeapObj::Bool(b)) => Some(b.to_string()),
        Some(kerf_runtime::HeapObj::Str(s)) => Some(s.to_string()),
        Some(kerf_runtime::HeapObj::Symbol(s)) => Some(s.to_string()),
        Some(kerf_runtime::HeapObj::Foreign(b)) => Some(render_foreign(&b)),
        // r138 / 208-c — TD-002: a vector in a dotted-tail position is a
        // terminal value (renders in full — `(1 . #(2 3))`)
        Some(kerf_runtime::HeapObj::Vector(_)) => Some(render_vector(r, heap, &mut HashMap::new())),
        _ => None,
    }
}

/// Vector rendering (r138 / 208-c — TD-002: `[e1 e2 ...]` — the bracket
/// form matching the literal syntax (round-trip readable, consistent with
/// the Stx datum render); elements via `render_slot`; defensive cycle
/// truncation with `...` mirrors render_pair).
fn render_vector(r: GcRef, heap: &Heap, seen: &mut HashMap<GcRef, ()>) -> String {
    if seen.contains_key(&r) {
        return "[...]".to_string();
    }
    seen.insert(r, ());
    let parts: Vec<String> = heap
        .get_vector(r)
        .map(|elems| elems.iter().map(|&e| render_slot(e, heap)).collect())
        .unwrap_or_default();
    format!("[{}]", parts.join(" "))
}

/// Slot rendering (any slot shape).
fn render_slot(r: GcRef, heap: &Heap) -> String {
    match heap.get(r).map(|s| s.obj.clone()) {
        Some(kerf_runtime::HeapObj::Pair(..)) => render_pair(r, heap, &mut HashMap::new()),
        // r138 / 208-c — TD-002: vector slots render via the vector walker
        Some(kerf_runtime::HeapObj::Vector(_)) => render_vector(r, heap, &mut HashMap::new()),
        Some(kerf_runtime::HeapObj::Str(s)) => s.to_string(),
        Some(kerf_runtime::HeapObj::Int(v)) => v.to_string(),
        Some(kerf_runtime::HeapObj::Float(v)) => v.to_string(),
        Some(kerf_runtime::HeapObj::Bool(b)) => b.to_string(),
        Some(kerf_runtime::HeapObj::Symbol(s)) => s.to_string(),
        Some(kerf_runtime::HeapObj::Nil) => "nil".to_string(),
        Some(kerf_runtime::HeapObj::Foreign(b)) => render_foreign(&b),
        None => "#<invalid-slot>".to_string(),
    }
}

/// Foreign boxed-value rendering (TD-010): the same shape as direct
/// function-value rendering — closure `#<procedure>` / builtin
/// `#<builtin:name>`.
fn render_foreign(b: &Rc<kerf_runtime::ForeignBox>) -> String {
    if b.any.as_ref().downcast_ref::<ClosureValue>().is_some() {
        "#<procedure>".to_string()
    } else if let Some(f) = b.any.as_ref().downcast_ref::<BuiltinFn>() {
        format!("#<builtin:{}>", f.name)
    } else if let Some(t) = b.any.as_ref().downcast_ref::<crate::ffi::ExternalToken>() {
        // r30/48-d: boxed rendering of FFI tokens (same shape as the direct
        // value form — round-trip rendering consistency, the TD-010
        // same-shape discipline)
        if t.is_valid() {
            "#<external>".to_string()
        } else {
            "#<external:invalid>".to_string()
        }
    } else {
        "#<foreign>".to_string()
    }
}

/// PartialEq follows eq_value semantics (for test assertions and container
/// use; prefer explicit eq_value calls for production comparisons).
impl PartialEq for Value {
    fn eq(&self, other: &Self) -> bool {
        self.eq_value(other)
    }
}

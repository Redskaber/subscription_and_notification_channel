//! FFI execution face (r30/48-d — the VM realization of the
//! ffi-ownership-model behavioral specification).
//!
//! **Positioning** (plan §5b 48-d): the **VM execution face** of `FfiCall` —
//! the three primitives (CallExternal/AllocExternal/FreeExternal) are
//! driven via opcodes (`Op::CallExternal`/`Op::AllocExternal`/
//! `Op::FreeExternal`); **the surface form = Stage 3** (the compile arm
//! does not emit it — once the IR/VM face is real, §21.3 condition 4 is
//! honored; faithfully noted in plan §5b batch J scheduling note 3).
//!
//! **This module carries**:
//! - `ExternalToken`: the linear-token state machine (ffi-ownership-model
//!   §5 — the Valid/Invalid two states; consumption takes effect
//!   **globally** via the slot-level invalidation flag, so every shared
//!   `Rc` reference invalidates synchronously);
//! - `ExternSymbolTable`: the extern symbol table (§4 — a flat symbol
//!   space, independent of the user's lexical environment, not shadowable
//!   by `define`/`set!`);
//! - `call_external`: the window protocol executor (§2.1 steps 2-4 —
//!   loading boundary (heap argument pin `Φ[v] += 1` + token validation) →
//!   host call (VM suspended) → return wrapping + unpin of all heap
//!   arguments);
//! - `alloc_external`/`free_external`: external-domain allocation/freeing
//!   (the external malloc domain — **does not go through the GC**).
//!
//! **External-domain discipline** (Stage 2 honesty note): the external
//! malloc domain = the Rust host heap's `Box<[u8]>` face (the std default
//! allocator is the system malloc); real C ABI linking = the QBE AOT path
//! (kerf-backend — not in the bootstrap chain). Tokens carry the
//! `(addr, size)` pair to rebuild the boxed slice (the free path).
//!
//! **E codes** (18 §6 codepoint registry — reserved in r18, placed this
//! round): E0010 = E9 `FfiTokenInvalid` (use after token invalidation);
//! E0011 = E10 `FfiOwnershipViolation` (ownership/type violation); E0012 =
//! E11 `FfiSymbolResolution` (symbol resolution failure). Messages are
//! single-sourced via `messages.rs` (the TD-018 discipline).

use std::cell::Cell;
use std::collections::HashMap;
use std::rc::Rc;

use kerf_runtime::{GcRef, Heap, RuntimeError};
use kerf_span::Span;

use crate::value::Value;
use crate::vm::VmError;

// ---------------------------------------------------------------------------
// Linear-token state machine (ffi-ownership-model §5)
// ---------------------------------------------------------------------------

/// Token kind (the runtime consumption subset of
/// `ExternalType::CPointer`/`Opaque` — the ownership criterion: CPointer =
/// ownership transferred to kerf (Free allowed); Opaque = externally held
/// (not Freeable, forever Valid until the carrying slot is GC-reclaimed).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TokenKind {
    CPointer,
    Opaque,
}

/// Token lifecycle state (§5 state machine: Valid → Invalid is a one-shot
/// irreversible consumption; Invalid is an absorbing state — any FFI
/// primitive operation on it = E0010).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TokenState {
    Valid,
    Invalid,
}

/// FFI external token (one of the payload shapes when boxed as
/// `HeapObj::Foreign`; the direct value shape = `Value::External`).
///
/// **Globally-effective consumption** (§4 main ruling): `Rc` sharing +
/// an embedded `Cell` — one `FreeExternal` consumption invalidates all
/// shared bindings synchronously (the runtime equivalent of
/// copy-prevention linearity: safety goals = preventing double free /
/// preventing use-after-free, without relying on copy prevention).
#[derive(Debug)]
pub struct ExternalToken {
    kind: TokenKind,
    /// External-domain address (`null` = the empty-token sentinel — §6
    /// case 13: Free = a legal no-op (aligned with `free(NULL)`); the
    /// dereference face = Stage 3).
    addr: *mut u8,
    /// External-domain allocation length (the Box<[u8]> rebuild discipline
    /// — the slice length for the free path; Opaque/NULL tokens do not
    /// consume this field).
    size: usize,
    state: Cell<TokenState>,
}

// Single-threaded domain (§6 case 10: the Stage 2 ruling — GC and FFI
// boundaries are mutually exclusive at VM suspension points; the Rc/Cell
// family being non-Send/Sync is the structural single-threaded face).
impl ExternalToken {
    /// Construct a CPointer token from an external-domain allocation
    /// (ownership transferred to kerf).
    pub fn from_boxed_slice(buf: Box<[u8]>) -> Rc<Self> {
        let size = buf.len();
        let addr = Box::into_raw(buf) as *mut u8;
        Rc::new(ExternalToken {
            kind: TokenKind::CPointer,
            addr,
            size,
            state: Cell::new(TokenState::Valid),
        })
    }

    /// NULL sentinel token (a Valid empty token — §6 case 13).
    pub fn null_sentinel() -> Rc<Self> {
        Rc::new(ExternalToken {
            kind: TokenKind::CPointer,
            addr: std::ptr::null_mut(),
            size: 0,
            state: Cell::new(TokenState::Valid),
        })
    }

    /// Opaque token (externally held — no kerf-side consumption path
    /// exists, forever Valid).
    pub fn opaque(addr: *mut u8) -> Rc<Self> {
        Rc::new(ExternalToken {
            kind: TokenKind::Opaque,
            addr,
            size: 0,
            state: Cell::new(TokenState::Valid),
        })
    }

    /// Construct a CPointer from a host return (the strdup-style
    /// convention: C allocates, kerf owns, kerf frees — the external-domain
    /// Box<[u8]> discipline).
    pub fn from_host_ptr(addr: *mut u8, size: usize) -> Rc<Self> {
        Rc::new(ExternalToken {
            kind: TokenKind::CPointer,
            addr,
            size,
            state: Cell::new(TokenState::Valid),
        })
    }

    /// Kind.
    pub fn kind(&self) -> TokenKind {
        self.kind
    }

    /// External-domain address (the Opaque observation face / for tests).
    pub fn addr(&self) -> *mut u8 {
        self.addr
    }

    /// Allocation length.
    pub fn size(&self) -> usize {
        self.size
    }

    /// Validity (Invalid = an absorbing state).
    pub fn is_valid(&self) -> bool {
        self.state.get() == TokenState::Valid
    }

    /// Consume: the slot-level invalidation flag (globally effective — all
    /// bindings sharing the Rc invalidate synchronously).
    pub fn mark_invalid(&self) {
        self.state.set(TokenState::Invalid);
    }

    /// Consume the external memory (returned to the external domain — the
    /// Box<[u8]> rebuild discipline; the caller guarantees kind = CPointer
    /// and Valid and a non-null addr).
    fn drop_external(&self) {
        debug_assert!(!self.addr.is_null(), "empty token takes the no-op path");
        // Rebuild the fat pointer: Box::into_raw(slice) → (addr, len) →
        // reverse the transformation
        let fat = std::ptr::slice_from_raw_parts_mut(self.addr, self.size);
        // SAFETY: addr/size come from the original Box::into_raw pair (the
        // construction discipline — both from_boxed_slice/from_host_ptr
        // produce the same shape)
        unsafe { drop(Box::from_raw(fat)) };
    }
}

// ---------------------------------------------------------------------------
// extern symbol table (ffi-ownership-model §4 — flat symbol space)
// ---------------------------------------------------------------------------

/// Argument/return marshalling shapes (the VM consumption subset of
/// `ExternalType`: CInt by value copy / CPointer by window borrowing or
/// token passing / Opaque by token passing. CStruct/CFunction are outside
/// the Stage 2 VM consumption subset — rejected at the driver registration
/// face (honest narrowing). Type fields such as `FfiCall.return_type`
/// serve the static face (the G2 HM anchor — ffi-ownership-model §8).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ExternKind {
    CInt,
    CPointer,
    Opaque,
}

/// Borrowed argument (within the window — the shape visible to the C side;
/// lifetime = window protocol steps 2-4).
#[derive(Debug, Clone, Copy)]
pub enum BorrowedArg<'a> {
    /// CInt argument (copied out by value — no lifetime interaction).
    Int(i64),
    /// CPointer(char*) argument: the Str heap slot is pinned and the data
    /// pointer borrowed out (window borrowing — step 2 pin / step 4 unpin
    /// pairing).
    CharBuf(&'a str),
    /// Token argument (passed by borrowing — not consumed; both
    /// CPointer/Opaque tokens allowed).
    Token(&'a ExternalToken),
}

/// Host return (the C → kerf three-way split + NULL sentinel —
/// ffi-ownership-model §2.1).
#[derive(Debug, Clone, Copy)]
pub enum HostRet {
    /// CInt return (by value copy — boxing is kerf's full responsibility).
    Int(i64),
    /// NULL pointer sentinel (a Valid empty token — FreeExternal = a legal
    /// no-op).
    NullPtr,
    /// CPointer return (external-domain allocation — ownership transferred
    /// to kerf; the strdup-style convention).
    CPtr(*mut u8, usize),
    /// Opaque return (externally held — kerf cannot free it).
    Opaque(*mut u8),
}

/// Host foreign function (the host-side shape of a C ABI call —
/// write_stdout-style; within the window the VM is suspended and the host
/// does not touch the kerf heap (the §6 case 6 timing ruling)).
pub type HostFn = fn(&[BorrowedArg<'_>]) -> Result<HostRet, RuntimeError>;

/// extern symbol table entry (symbol name → signature + host function —
/// the runtime counterpart of a C header file: the signature lives at the
/// declaration site (the registration face), call sites carry only the
/// symbol name).
#[derive(Clone)]
pub struct ExternEntry {
    /// Argument marshalling shapes (aligned in order with the call
    /// arguments).
    pub params: Vec<ExternKind>,
    /// Return wrapping shape.
    pub ret: ExternKind,
    /// Host function.
    pub f: HostFn,
}

impl std::fmt::Debug for ExternEntry {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "ExternEntry({:?} -> {:?})", self.params, self.ret)
    }
}

/// extern symbol table (**a flat symbol space** — independent of the
/// user's lexical environment; §4: not shadowable by define/set!, and
/// macro hygiene does not penetrate the FFI symbol space).
#[derive(Debug, Clone, Default)]
pub struct ExternSymbolTable {
    entries: HashMap<Rc<str>, ExternEntry>,
}

impl ExternSymbolTable {
    /// Empty table (the fail-closed baseline — an unregistered symbol =
    /// E0012).
    pub fn new() -> Self {
        ExternSymbolTable {
            entries: HashMap::new(),
        }
    }

    /// Register a foreign function (signature declaration + host function).
    pub fn register(&mut self, name: &str, params: Vec<ExternKind>, ret: ExternKind, f: HostFn) {
        self.entries
            .insert(Rc::from(name), ExternEntry { params, ret, f });
    }

    /// Symbol resolution (the E11 path — `None` = unregistered, E0012).
    pub fn resolve(&self, name: &str) -> Option<&ExternEntry> {
        self.entries.get(name)
    }

    /// Number of registered symbols (a test/audit observation face).
    pub fn len(&self) -> usize {
        self.entries.len()
    }

    /// Whether empty.
    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }
}

// ---------------------------------------------------------------------------
// Window protocol executor (ffi-ownership-model §2.1 steps 2-4 — the
// boundary wrapping layer)
// ---------------------------------------------------------------------------

/// E0010 constructor helper (use after token invalidation — double free /
/// pass-after-use / use-after-use).
fn e10(context: &str, span: Span) -> VmError {
    VmError::new_code(10, crate::messages::err_ffi_token_invalid(context), span)
}

/// E0011 constructor helper (ownership/type violation — freeing an Opaque /
/// a non-token value / argument shape mismatch).
fn e11(detail: &str, span: Span) -> VmError {
    VmError::new_code(11, crate::messages::err_ffi_ownership(detail), span)
}

/// E0012 constructor helper (symbol resolution failure — not registered in
/// the extern symbol table).
fn e12(name: &str, span: Span) -> VmError {
    VmError::new_code(12, crate::messages::err_ffi_symbol_resolution(name), span)
}

/// Host error → VmError (the E0004 runtime generic family — the runtime
/// carrier of the 06 §3 E7 I/O channel failure criterion; code None is
/// mapped by the driver's `from_vm`).
fn host_err(e: RuntimeError, span: Span) -> VmError {
    VmError::new(e.message, span)
}

/// pin underflow → VmError (the E8 criterion — structural pairing makes it
/// unreachable; carried on the E0004 channel + the message carries an E8
/// note).
fn underflow_err(e: RuntimeError, span: Span) -> VmError {
    VmError::new(e.message, span)
}

/// CallExternal window protocol (steps 2-4; step 1 argument evaluation is
/// completed by prior instructions — `args` are passed in order).
///
/// Step order (§2.1):
/// 1. (done externally) argument evaluation — during evaluation the objects
///    stay alive via VM stack roots (root-set source 1);
/// 2. loading boundary: heap arguments (the Str char* path) pin their boxed
///    heap slots one by one (`Φ[v] += 1`); token arguments are validated
///    (Invalid → E0010);
/// 3. host call (VM suspended — §6 case 6: no safepoint polling, external
///    malloc does not enter kerf's allocation count);
/// 4. return: **first unpin all heap arguments** (`Φ[v] -= 1` — case 6: the
///    return wrapping does not depend on argument heap objects and the
///    trigger point is after the unpin), then wrap per the return shape.
pub fn call_external(
    table: &ExternSymbolTable,
    name: &str,
    args: &[Value],
    heap: &mut Heap,
    span: Span,
) -> Result<Value, VmError> {
    // Symbol resolution (E11 — fail-closed: unregistered = E0012)
    let entry = table.resolve(name).ok_or_else(|| e12(name, span))?;
    // Argument-count validation (shape violation → E0011)
    if args.len() != entry.params.len() {
        return Err(e11(
            &format!(
                "external function {} actual argument count mismatch({} ≠ {})",
                name,
                args.len(),
                entry.params.len()
            ),
            span,
        ));
    }
    // Step 2: loading boundary — argument marshalling + pin bookkeeping
    let mut borrowed: Vec<BorrowedArg<'_>> = Vec::with_capacity(args.len());
    let mut pinned: Vec<GcRef> = Vec::new();
    for (i, (kind, arg)) in entry.params.iter().zip(args.iter()).enumerate() {
        match (kind, arg) {
            (ExternKind::CInt, Value::Int(v)) => borrowed.push(BorrowedArg::Int(*v)),
            (ExternKind::CInt, other) => {
                return Err(e11(
                    &format!(
                        "external function {} argument #{} requires CInt, got {}",
                        name,
                        i + 1,
                        other.type_name()
                    ),
                    span,
                ))
            }
            // char* window-borrowing path (§8 batch I line — Str heap slot
            // pin + data pointer borrowed out + unpin after return): the
            // Str value is boxed into a heap slot (the GC-tracked shape) →
            // pinned (Φ+1, the F-PIN liveness guarantee) → the Rc<str>
            // buffer is borrowed (stack-root liveness + heap-slot pin,
            // double insurance — the defensive protocol positioning §3)
            (ExternKind::CPointer, Value::Str(s)) => {
                let slot = heap.alloc_str(Rc::clone(s));
                heap.pin_object(slot);
                pinned.push(slot);
                borrowed.push(BorrowedArg::CharBuf(s));
            }
            // Token argument (passed by borrowing — not consumed; passing an
            // Invalid token = E9)
            (ExternKind::CPointer, Value::External(t))
            | (ExternKind::Opaque, Value::External(t)) => {
                if !t.is_valid() {
                    return Err(e10("token invalidated after transfer (transfer after use)", span));
                }
                borrowed.push(BorrowedArg::Token(t));
            }
            (ExternKind::CPointer, other) => {
                return Err(e11(
                    &format!(
                        "external function {} argument #{} requires CPointer (str window borrow or token), got {}",
                        name,
                        i + 1,
                        other.type_name()
                    ),
                    span,
                ))
            }
            (ExternKind::Opaque, other) => {
                return Err(e11(
                    &format!(
                        "external function {} argument #{} requires an Opaque token, got {}",
                        name,
                        i + 1,
                        other.type_name()
                    ),
                    span,
                ))
            }
        }
    }
    // Pin leaks on error paths: if the loading boundary fails midway
    // (E0010/E0011), already-pinned slots are not unpinned — per the §6
    // case 9 tolerance criterion (leaks tolerated, mistaken reclamation
    // zero-tolerance; permanent-root shape).
    // Step 3: host call (VM suspended — within the borrowing window the
    // host only observes the borrowed arguments)
    let ret = (entry.f)(&borrowed).map_err(|e| host_err(e, span))?;
    // Step 4a: unpin all heap arguments (reverse LIFO order — structural
    // pairing; the window closes)
    for slot in pinned.iter().rev() {
        heap.unpin_object(*slot)
            .map_err(|e| underflow_err(e, span))?;
    }
    // Step 4b: return wrapping (does not depend on argument heap objects —
    // the case 6 timing)
    Ok(match (entry.ret, ret) {
        (ExternKind::CInt, HostRet::Int(v)) => Value::Int(v),
        (ExternKind::CPointer, HostRet::NullPtr) => Value::External(ExternalToken::null_sentinel()),
        (ExternKind::CPointer, HostRet::CPtr(addr, size)) => {
            Value::External(ExternalToken::from_host_ptr(addr, size))
        }
        (ExternKind::Opaque, HostRet::Opaque(addr)) => Value::External(ExternalToken::opaque(addr)),
        // Declared shape not matching the host return shape = a
        // registration-face contract violation (the internal-defect
        // criterion)
        (k, r) => {
            return Err(VmError::new(
                format!(
                    "external function {} return form and declaration mismatch({:?} vs {:?}) -- registration face contract violation",
                    name, k, r
                ),
                span,
            ))
        }
    })
}

/// AllocExternal execution (external-domain allocation — does not go
/// through the GC; produces a CPointer token).
///
/// `size = 0`: a **runtime defense-in-depth** for the compile-time
/// rejection (§6 case 4 — the fallback for when direct opcode construction
/// bypasses the lowering face; error > silence, §2.3-4).
pub fn alloc_external(size: u32, span: Span) -> Result<Value, VmError> {
    if size == 0 {
        return Err(e11(
            "AllocExternal size is 0 (zero-size buffer has no legal use case on the kerf request face)",
            span,
        ));
    }
    let buf = vec![0u8; size as usize].into_boxed_slice();
    Ok(Value::External(ExternalToken::from_boxed_slice(buf)))
}

/// FreeExternal execution (consumption semantics — §2.3).
///
/// Decision order (the §5 illegal-transition table): a non-Foreign value →
/// E0011 (transition 5); an Opaque token → E0011 (transition 4 —
/// externally held, not freeable); Invalid → E0010 (transition 1 — double
/// free, absorbed as a diagnostic, not UB); a Valid CPointer → consumption
/// (the slot-level globally-effective invalidation mark) + external memory
/// returned; the NULL sentinel → a legal no-op (§6 case 13 — well-defined,
/// aligned with `free(NULL)`).
pub fn free_external(ptr: &Value, span: Span) -> Result<Value, VmError> {
    let token = match ptr {
        Value::External(t) => t,
        other => {
            return Err(e11(
                &format!(
                    "FreeExternal requires Foreign token, got {}",
                    other.type_name()
                ),
                span,
            ))
        }
    };
    if token.kind() == TokenKind::Opaque {
        return Err(e11(
            "Opaque token is held externally (kerf side has no release right -- fclose/fopen-class external API convention)",
            span,
        ));
    }
    if !token.is_valid() {
        return Err(e10(
            "double release (token already consumed -- absorbed as a diagnostic, not UB)",
            span,
        ));
    }
    // Consume: the slot-level invalidation flag (globally effective — all
    // shared bindings invalidate synchronously)
    token.mark_invalid();
    if token.addr().is_null() {
        // NULL sentinel: a legal no-op (§6 case 13)
        return Ok(Value::Unit);
    }
    token.drop_external();
    Ok(Value::Unit)
}

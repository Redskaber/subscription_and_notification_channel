//! QBE IL generation (batch G / 38-c — G1 back end).
//!
//! `AnnotatedANF` → QBE IL text (`function`/`@label`/`jnz`/`phi` — value
//! merging via the phi instruction). **All `l` (64-bit) types** — aligned
//! with kerf's `Int(i64)` semantics; comparison results are `w` (boolean
//! 0/1).
//!
//! **QBE syntax anchors (38-b/38-c smoke-test errata — docs/tools/qbe/setup.md)**:
//! - function signatures must carry a return type: `function l $fib(l %t0) {`;
//! - integer comparison instructions take a width suffix: `csltl`/`ceql`
//!   (not `cslt`);
//! - value merging: the phi instruction (`%r =l phi @l1 %v1, @l2 %v2`,
//!   must sit at the block head — parameterized jmp/block-parameter syntax
//!   does not exist in QBE 1.3, a 38-c field-test erratum);
//! - instruction lines are indented with a tab (a hard QBE lexical
//!   requirement).

use crate::anf::{AAtom, ACtrl, AFuncDef, AOp, APhi, APrim, AStmt, ATemp, AnnotatedANF};
use crate::codegen::{CodegenBackend, CodegenError, CompiledModule, PassDescriptor, TargetTriple};

// ---------------------------------------------------------------------------
// IL rendering (§10.1 rule 4: text-product functions take the `_il` suffix)
// ---------------------------------------------------------------------------

/// Generate the full QBE IL text (main = `export function l $main()` — the
/// return value is the process exit code, POSIX takes the low 8 bits; the
/// other functions are internally visible).
pub fn gen_il(ir: &AnnotatedANF) -> String {
    let mut out = String::new();
    for (i, f) in ir.funcs.iter().enumerate() {
        if i > 0 {
            out.push('\n');
        }
        gen_func_il(&mut out, f, i == 0);
    }
    out
}

/// Single-function rendering (blocks[i] ↔ label `@l{i}` — entry block 0
/// aligns with LowerCtxt's start_block sequential allocation).
fn gen_func_il(out: &mut String, f: &AFuncDef, is_main: bool) {
    let export = if is_main { "export " } else { "" };
    let params: Vec<String> = f
        .params
        .iter()
        .map(|t| format!("l {}", render_temp(t)))
        .collect();
    out.push_str(&format!(
        "{}function l ${}({}) {{\n",
        export,
        f.name,
        params.join(", ")
    ));
    for (bi, b) in f.body.blocks.iter().enumerate() {
        out.push_str(&format!("@l{}\n", bi));
        for phi in &b.phis {
            gen_phi_il(out, phi);
        }
        for s in &b.stmts {
            gen_stmt_il(out, s);
        }
        gen_ctrl_il(out, &b.ctrl);
    }
    out.push_str("}\n");
}

/// Phi binding rendering (block head — `%dst =l phi @l{i} %v, @l{j} %w`).
fn gen_phi_il(out: &mut String, phi: &APhi) {
    let sources: Vec<String> = phi
        .sources
        .iter()
        .map(|(lbl, a)| format!("@l{} {}", lbl.0, render_atom(a)))
        .collect();
    out.push_str(&format!(
        "\t{} =l phi {}\n",
        render_temp(&phi.dst),
        sources.join(", ")
    ));
}

/// Statement rendering (`%dst =<t> <op> <args>`).
fn gen_stmt_il(out: &mut String, s: &AStmt) {
    match &s.op {
        AOp::Prim(prim, atoms) => {
            let (ty, instr) = render_prim(*prim);
            // Not special case: (not x) ≡ (x = 0) — ceql compares against a padded 0
            let mut args: Vec<String> = atoms.iter().map(render_atom).collect();
            if *prim == APrim::Not {
                args.push("0".to_string());
            }
            out.push_str(&format!(
                "\t{} ={} {} {}\n",
                render_temp(&s.dst),
                ty,
                instr,
                args.join(", ")
            ));
        }
        AOp::Call { func, args } => {
            let rendered: Vec<String> = args.iter().map(render_atom).collect();
            out.push_str(&format!(
                "\t{} =l call ${}(l {})\n",
                render_temp(&s.dst),
                func,
                rendered.join(", l ")
            ));
        }
    }
}

/// Control-flow terminator rendering.
fn gen_ctrl_il(out: &mut String, ctrl: &ACtrl) {
    match ctrl {
        ACtrl::Ret(a) => {
            out.push_str(&format!("\tret {}\n", render_atom(a)));
        }
        ACtrl::Br { cond, t, f } => {
            out.push_str(&format!(
                "\tjnz {}, @l{}, @l{}\n",
                render_temp(cond),
                t.0,
                f.0
            ));
        }
        ACtrl::Jmp { target } => {
            out.push_str(&format!("\tjmp @l{}\n", target.0));
        }
    }
}

/// Render a temporary name (`%tN`).
fn render_temp(t: &ATemp) -> String {
    format!("%t{}", t.0)
}

/// Render an atom.
fn render_atom(a: &AAtom) -> String {
    match a {
        AAtom::Int(v) => format!("{}", v),
        AAtom::Var(t) => render_temp(t),
    }
}

/// Render a primitive (QBE instruction name — returns (result type,
/// instruction); arithmetic is all l, comparisons produce w).
fn render_prim(p: APrim) -> (&'static str, &'static str) {
    match p {
        APrim::Add => ("l", "add"),
        APrim::Sub => ("l", "sub"),
        APrim::Mul => ("l", "mul"),
        APrim::Div => ("l", "div"),
        APrim::Mod => ("l", "rem"),
        APrim::Eq => ("w", "ceql"),
        APrim::Lt => ("w", "csltl"),
        APrim::Gt => ("w", "csgtl"),
        APrim::Le => ("w", "cslel"),
        APrim::Ge => ("w", "csgel"),
        // (not x) ≡ (x = 0) — ceqw (the operand is a boolean w value; ceqw
        // pads the 0 argument, handled in gen_stmt_il — 38-c field-test
        // erratum: the l suffix is illegal for w operands)
        APrim::Not => ("w", "ceqw"),
    }
}

// ---------------------------------------------------------------------------
// QbeBackend (the CodegenBackend contract implementation — 13 §3.3.7's first realized backend)
// ---------------------------------------------------------------------------

/// QBE backend (the IL generation proper — external process orchestration
/// is in [`crate::native::aot`]).
///
/// **Contract behavior**:
/// - `supported_targets`: the QBE 1.3 field-tested target surface
///   (amd64_sysv host default + arm64 — the PoC delivery is anchored to
///   the host's amd64_sysv);
/// - `compile`: AnnotatedANF → QBE IL text (`CompiledModule.bytes` = the
///   IL UTF-8 bytes; `.ssa` is QBE's target code — the AOT layer then
///   lowers to assembly/native code);
/// - `backend_optimizations`: QBE's built-in passes (ssa/gvn/gcm/rega —
///   the delivery surface of "10% of the code ≈ 70% of the performance",
///   08-backend-evolution §2).
#[derive(Debug, Clone)]
pub struct QbeBackend;

impl CodegenBackend for QbeBackend {
    fn supported_targets(&self) -> Vec<TargetTriple> {
        vec![
            TargetTriple("x86_64-unknown-linux-qbe".into()),
            TargetTriple("aarch64-unknown-linux-qbe".into()),
        ]
    }

    fn compile(
        &self,
        ir: &AnnotatedANF,
        target: &TargetTriple,
    ) -> Result<CompiledModule, CodegenError> {
        if !self.supported_targets().iter().any(|t| t.0 == target.0) {
            return Err(CodegenError::new(format!(
                "QBE backend does not support goal `{}`(support: amd64_sysv / arm64)",
                target.0
            )));
        }
        let il = gen_il(ir);
        Ok(CompiledModule {
            target: target.clone(),
            bytes: il.into_bytes(),
        })
    }

    fn backend_optimizations(&self) -> Vec<PassDescriptor> {
        vec![
            PassDescriptor { name: "qbe-ssa" },
            PassDescriptor { name: "qbe-gvn" },
            PassDescriptor { name: "qbe-gcm" },
            PassDescriptor { name: "qbe-rega" },
        ]
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// IL generation smoke test (structural assertions — no external
    /// processes involved): an empty program with no functions → empty IL
    /// text.
    #[test]
    fn gen_il_empty_program_is_empty() {
        let ir = AnnotatedANF::default();
        assert_eq!(gen_il(&ir), "");
    }

    /// QbeBackend contract: the target gate (negative case — unsupported
    /// targets rejected) + positive IL artifact.
    #[test]
    fn qbe_backend_target_gate_and_module() {
        let b = QbeBackend;
        let ir = AnnotatedANF::default();
        // Negative case: unsupported target
        assert!(b.compile(&ir, &TargetTriple("wasm32".into())).is_err());
        // Positive case: IL text artifact (empty program → empty text into the envelope)
        let m = b
            .compile(&ir, &TargetTriple("x86_64-unknown-linux-qbe".into()))
            .unwrap();
        assert_eq!(m.target.0, "x86_64-unknown-linux-qbe");
        assert!(m.bytes.is_empty());
        // Optimization list: the four QBE built-in passes declared
        assert_eq!(b.backend_optimizations().len(), 4);
    }
}

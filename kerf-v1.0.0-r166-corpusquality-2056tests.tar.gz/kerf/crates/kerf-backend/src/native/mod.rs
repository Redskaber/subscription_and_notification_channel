//! The native-code domain (native domain — r101 / 171-a domain directory-ization).
//!
//! **Domain position**: the self-governing directory of the QBE native-code
//! backend family (batch G / 38-b-c — G1 QBE PoC delivery + B1 PoC boundary
//! registration) — alongside [`crate::wasm`] (the WASM component model
//! domain), the two self-governing target domains of kerf-backend; the
//! backend root ([`crate::codegen`] contract + [`crate::anf`] lowering)
//! carries the shared access surface of both domains.
//!
//! **Module map**:
//! - [`qbe`]: the QBE IL generation proper + [`qbe::QbeBackend`] (the first
//!   realized implementation of `CodegenBackend`);
//! - [`aot`]: external process orchestration (the qbe/cc subprocess chain —
//!   **never enters the self-hosting chain §21.2**: the native-code path is
//!   a release/verification shape, not a self-hosting shape).

pub mod aot;
pub mod qbe;

//! AOT orchestration (batch G / 38-c — the host-side external process chain).
//!
//! `QBE IL` → (the `tools/qbe/bin/qbe` subprocess) → assembly `.s` →
//! (`cc`) → a native executable → run (exit code). **Never enters the
//! self-hosting chain** (§21.2 — this module is part of the Rust ~20%
//! infrastructure of 12-roadmap §2's "build bootstrap + backend").
//!
//! **Lookup chain** (the library-side runtime version of the §3.1
//! convention): the `KERF_QBE` environment variable → the
//! `../tools/qbe/bin/qbe` beside the executable → the compile-time
//! `CARGO_MANIFEST_DIR/../../tools/qbe/bin/qbe`. Missing = explicit error
//! (no silent skip).

use std::path::{Path, PathBuf};
use std::process::Command;

use crate::codegen::CodegenError;

/// AOT artifacts (three on-disk files + the run entry).
#[derive(Debug, Clone)]
pub struct NativeArtifacts {
    /// QBE IL source (`*.ssa`).
    pub il_path: PathBuf,
    /// Assembly (`*.s` — qbe's output).
    pub asm_path: PathBuf,
    /// Native executable.
    pub exe_path: PathBuf,
}

/// Unified subprocess invocation wrapper (stderr is captured into the
/// error — no diagnostics lost).
fn run_command(mut cmd: Command, what: &str) -> Result<std::process::Output, CodegenError> {
    cmd.output()
        .map_err(|e| CodegenError::new(format!("{} start failed:{}", what, e)))
}

/// Resolve the QBE binary path (§3.1 runtime lookup chain).
pub fn find_qbe() -> Result<PathBuf, CodegenError> {
    find_qbe_from(std::env::var("KERF_QBE").ok())
}

/// Lookup-chain pure-function core (env value injection — tests have no
/// global side effects, avoiding parallel races: a 38-c field-test
/// erratum, where set_var polluted find_qbe of other tests in the same
/// process).
fn find_qbe_from(kerf_qbe: Option<String>) -> Result<PathBuf, CodegenError> {
    // 1. Explicit environment-variable override
    if let Some(p) = kerf_qbe {
        let pb = PathBuf::from(p);
        if pb.is_file() {
            return Ok(pb);
        }
        return Err(CodegenError::new(format!(
            "KERF_QBE points to QBE does not exist:{}",
            pb.display()
        )));
    }
    // 2. The ../tools/qbe/bin/qbe beside the executable (installation layout)
    if let Ok(exe) = std::env::current_exe() {
        if let Some(root) = exe
            .parent()
            .and_then(|p| p.parent())
            .and_then(|p| p.parent())
        {
            let cand = root.join("tools/qbe/bin/qbe");
            if cand.is_file() {
                return Ok(cand);
            }
        }
    }
    // 3. Compile-time anchor (development/test layout: crates/kerf-backend → repository root)
    if let Some(dir) = option_env!("CARGO_MANIFEST_DIR") {
        let cand = Path::new(dir).join("../../tools/qbe/bin/qbe");
        if cand.is_file() {
            return Ok(cand);
        }
    }
    Err(CodegenError::new(
        "QBE binary not found (lookup chain: KERF_QBE environment variable → installed layout tools/qbe/bin/qbe → compile-time repository anchor; install: sh scripts/qbe/setup.sh)",
    ))
}

/// Full AOT build: IL text → assembly → executable (`out_dir` is created).
pub fn build_native(
    il: &str,
    out_dir: &Path,
    stem: &str,
    qbe_bin: &Path,
) -> Result<NativeArtifacts, CodegenError> {
    std::fs::create_dir_all(out_dir)
        .map_err(|e| CodegenError::new(format!("failed to create output directory: {}", e)))?;
    let il_path = out_dir.join(format!("{}.ssa", stem));
    let asm_path = out_dir.join(format!("{}.s", stem));
    let exe_path = out_dir.join(stem);

    // 1. Write the IL to disk
    std::fs::write(&il_path, il)
        .map_err(|e| CodegenError::new(format!("failed to write IL file: {}", e)))?;

    // 2. qbe: IL → assembly
    let mut cmd_qbe = Command::new(qbe_bin);
    cmd_qbe.arg("-o").arg(&asm_path).arg(&il_path);
    let out = run_command(cmd_qbe, "QBE")?;
    if !out.status.success() {
        return Err(CodegenError::new(format!(
            "QBE compile failed(exit {}): {}",
            out.status.code().unwrap_or(-1),
            String::from_utf8_lossy(&out.stderr)
        )));
    }

    // 3. cc: assembly → executable
    let mut cmd_cc = Command::new("cc");
    cmd_cc.arg("-o").arg(&exe_path).arg(&asm_path);
    let out = run_command(cmd_cc, "cc (system assembler/linker)")?;
    if !out.status.success() {
        return Err(CodegenError::new(format!(
            "cc link failed(exit {}): {}",
            out.status.code().unwrap_or(-1),
            String::from_utf8_lossy(&out.stderr)
        )));
    }

    Ok(NativeArtifacts {
        il_path,
        asm_path,
        exe_path,
    })
}

/// Run the native executable (exit code → i64; the POSIX low-8-bit
/// convention is documented by the caller).
pub fn run_native(exe: &Path) -> Result<i64, CodegenError> {
    let out = run_command(Command::new(exe), "local can execution")?;
    match out.status.code() {
        Some(c) => Ok(c as i64),
        None => Err(CodegenError::new(format!(
            "process by signal terminating: {}",
            out.status
        ))),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Lookup-chain negative case: KERF_QBE pointing at a nonexistent
    /// path → explicit error (not silent).
    /// Pure-function injection style (38-c erratum: a real set_var pollutes
    /// other tests in parallel).
    #[test]
    fn find_qbe_env_override_missing_fails_loudly() {
        let r = find_qbe_from(Some("/nonexistent/qbe".into()));
        assert!(r.is_err());
        assert!(r.unwrap_err().reason.contains("KERF_QBE"));
    }

    /// Lookup-chain positive case (explicit env path injection): if it exists, it hits.
    #[test]
    fn find_qbe_from_env_explicit_hit() {
        // Use our own binary as the "existing file" (a positive sample that
        // does not depend on the qbe layout)
        let me = std::env::current_exe().expect("test process can execution path");
        let r = find_qbe_from(Some(me.to_string_lossy().into_owned()));
        assert!(r.is_ok());
    }

    /// Lookup-chain positive case: the in-repository binary is reachable
    /// (the host toolchain is in place — a 38-b landing artifact).
    #[test]
    fn find_qbe_repo_layout_finds_binary() {
        let r = find_qbe();
        assert!(r.is_ok(), "should find in-repo QBE: {:?}", r.err());
    }

    /// AOT negative case: the qbe path is a plain text file (not
    /// executable) → launch-failure error.
    #[test]
    fn build_native_bad_qbe_fails_loudly() {
        let tmp = std::env::temp_dir().join(format!("kerf-aot-test-{}", std::process::id()));
        let fake = tmp.join("fake-qbe");
        std::fs::create_dir_all(&tmp).unwrap();
        std::fs::write(&fake, "not a binary").unwrap();
        let r = build_native(
            "export function l $main() {\n@l0\n\tret 0\n}\n",
            &tmp,
            "t_bad",
            &fake,
        );
        assert!(r.is_err());
        let _ = std::fs::remove_dir_all(&tmp);
    }
}

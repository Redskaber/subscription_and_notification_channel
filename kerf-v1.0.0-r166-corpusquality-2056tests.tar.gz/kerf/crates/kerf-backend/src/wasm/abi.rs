//! WASM canonical ABI adaptation layer (M2 — phase 2 of TD-031, materialized).
//!
//! **Positioning**: the boundary protocol layer that **fully consumes** the
//! three fields of [`CanonicalAbiOptions`](crate::wasm::CanonicalAbiOptions)
//! (wasm-backend-component-model §5 M2 definition: "string encode/decode +
//! realloc protocol + memory64") —
//! - `string_encoding` → [`encode_string`] / [`decode_string`]
//!   (UTF-8 passthrough / UTF-16LE unit order — **validating**
//!   bidirectional encode/decode: invalid UTF-8 sequences, odd byte
//!   length, and lone surrogates are all fail-closed, never silently
//!   replaced);
//! - `memory64` → [`AddressWidth`] (i32 / i64 address domain
//!   parameterization — the memory limits flag bit and the realloc
//!   signature domain on the emit side of
//!   [`emit_abi_module`](crate::wasm::emit::emit_abi_module) are decided
//!   by it);
//! - `realloc` → bump allocation protocol anchor (the canonical ABI
//!   four-parameter `(ptr, old_size, align, new_size) → new_ptr` protocol
//!   — [`align_to_byte_size`] alignment table + [`ALIGN_UP_TO`] alignment
//!   semantics + [`CANONICAL_REALLOC_DEFAULT_NAME`] default name anchor).
//!
//! **M2 boundary (honest narrowing aligned with B1)**:
//! - Encode/decode is implemented for the two variants of the contract
//!   layer [`StringEncoding`](crate::wasm::StringEncoding) (UTF-8 /
//!   UTF-16); latin1/ascii variants are undefined at the contract layer —
//!   Principle 27 additive evolution reserves the extension slot (no
//!   pre-implementation of out-of-contract shapes);
//! - Validating decode (fail-closed) and deterministic encode (same
//!   string → same bytes) are protocol invariants;
//! - **Language-side str literal lowering (ANF B1 boundary expansion) is
//!   out of M2 scope** — B1 boundary expansion = an independent evolution
//!   signal (same family as the TD-024 Float domain expansion); M2
//!   delivers the component boundary protocol infrastructure (host ↔
//!   linear memory str encode/decode + allocation protocol), with
//!   language-side integration deferred to later signals (M3 component
//!   composition / B1 expansion window).
//!
//! **§18 dependency ruling (L-B inherited)**: pure Rust standard library
//! implementation (`std::str::from_utf8` + `char::decode_utf16`) — zero
//! cargo dependencies.

use crate::wasm::StringEncoding;

// ---------------------------------------------------------------------------
// Error face (fail-closed)
// ---------------------------------------------------------------------------

/// canonical ABI protocol-layer error (decode/layout validation —
/// fail-closed, no silent degradation).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AbiError {
    /// Error description (in Chinese — same style as `CodegenError`).
    pub message: String,
}

impl AbiError {
    /// Constructor (message passed through directly).
    pub fn new(message: impl Into<String>) -> Self {
        AbiError {
            message: message.into(),
        }
    }
}

impl std::fmt::Display for AbiError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "WASM M2 ABI failed:{}", self.message)
    }
}

impl std::error::Error for AbiError {}

// ---------------------------------------------------------------------------
// Address domain (memory64 consumption)
// ---------------------------------------------------------------------------

/// Linear memory address width (emit-side projection of the canonical ABI
/// `memory64` option).
///
/// `I32` = the classic wasm32 address domain (4 GiB limit); `I64` = the
/// memory64-proposal address domain (limits flag bit 0x04 + the i64 address
/// operand domain).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum AddressWidth {
    /// wasm32 address domain (`memory64 = false`).
    I32,
    /// wasm64 address domain (`memory64 = true`).
    I64,
}

impl AddressWidth {
    /// Derived from [`CanonicalAbiOptions::memory64`] (the sole construction path).
    pub fn from_memory64(memory64: bool) -> Self {
        if memory64 {
            AddressWidth::I64
        } else {
            AddressWidth::I32
        }
    }
}

// ---------------------------------------------------------------------------
// Memory layout constants and helpers (protocol geometry)
// ---------------------------------------------------------------------------

/// wasm linear memory page size (64 KiB — spec constant, independent of address domain).
pub const PAGE_SIZE: usize = 65_536;

/// Byte count → minimum page count (rounded up — zero bytes = zero pages).
pub fn pages_for(bytes: usize) -> u32 {
    if bytes == 0 {
        0
    } else {
        bytes.div_ceil(PAGE_SIZE) as u32
    }
}

/// canonical ABI alignment parameter → byte size (`align` is log2 — the
/// alignment-table protocol anchor).
///
/// The real canonical ABI `alignment` option takes values in 0..=23
/// (1 byte .. 8 MiB); this layer sets no upper-bound validation (emit-side
/// alignment values are guaranteed by the protocol caller — out-of-range
/// alignments fail naturally in the wasm instruction domain).
pub fn align_to_byte_size(align: u32) -> u64 {
    1u64 << align
}

/// Align upward (`v` rounded up to `align` — `align` must be a power of two).
///
/// Protocol invariant: if `align` is not a power of two, `v` is returned
/// unchanged (defensive — the bump allocator's emit-side `$a = 1 << align`
/// is always a power of two, and this function is the single source of
/// Rust-side alignment semantics).
pub fn align_up(v: u64, align: u64) -> u64 {
    if align == 0 || !align.is_power_of_two() {
        return v;
    }
    (v + align - 1) & !(align - 1)
}

/// Default export name of the canonical ABI realloc function (the
/// host-side conventional fallback anchor when
/// `CanonicalAbiOptions::realloc` is `None`).
pub const CANONICAL_REALLOC_DEFAULT_NAME: &str = "canonical_abi_realloc";

// ---------------------------------------------------------------------------
// String encode/decode (string_encoding consumption — validating, bidirectional)
// ---------------------------------------------------------------------------

/// Encode a string (consumes the `string_encoding` protocol parameter).
///
/// - [`StringEncoding::Utf8`]: UTF-8 byte sequence passthrough (same
///   encoding as the Rust carrier of kerf `str` — zero-conversion copy
///   semantics);
/// - [`StringEncoding::Utf16`]: UTF-16 **little-endian** unit order (the
///   wasm linear memory byte order — canonical little-endian domain).
///
/// Determinism: same string + same encoding → same bytes (no
/// normalization, no lossy replacement).
pub fn encode_string(enc: StringEncoding, s: &str) -> Vec<u8> {
    match enc {
        StringEncoding::Utf8 => s.as_bytes().to_vec(),
        StringEncoding::Utf16 => {
            let mut out = Vec::with_capacity(s.len() * 2);
            for unit in s.encode_utf16() {
                out.push((unit & 0xff) as u8); // low byte (LE)
                out.push((unit >> 8) as u8); // high byte (LE)
            }
            out
        }
    }
}

/// Decode a string (validating — the dual of [`encode_string`]).
///
/// fail-closed face:
/// - UTF-8: invalid byte sequences (truncated multi-byte / illegal
///   continuation bytes);
/// - UTF-16: odd byte length (half a code unit), lone surrogates (no
///   high/low pairing), and interleaved surrogate pairs (a high surrogate
///   followed by a non-low-surrogate).
pub fn decode_string(enc: StringEncoding, bytes: &[u8]) -> Result<String, AbiError> {
    match enc {
        StringEncoding::Utf8 => std::str::from_utf8(bytes)
            .map(|s| s.to_string())
            .map_err(|e| AbiError::new(format!("UTF-8 decode failed: {e}"))),
        StringEncoding::Utf16 => {
            if !bytes.len().is_multiple_of(2) {
                return Err(AbiError::new(format!(
                    "UTF-16 decode failed: byte length {} is not even (half a code unit)",
                    bytes.len()
                )));
            }
            let units: Vec<u16> = bytes
                .as_chunks::<2>()
                .0
                .iter()
                .map(|c| u16::from_le_bytes(*c))
                .collect();
            let mut out = String::with_capacity(units.len());
            for r in std::char::decode_utf16(units) {
                out.push(r.map_err(|e| {
                    AbiError::new(format!("UTF-16 decode failed: lone surrogate (unit {e:?})"))
                })?);
            }
            Ok(out)
        }
    }
}

// ---------------------------------------------------------------------------
// Unit tests (protocol invariants — encode/decode round-trip / validation / layout geometry)
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn utf8_round_trip_ascii() {
        let s = "hello, kerf!";
        let b = encode_string(StringEncoding::Utf8, s);
        assert_eq!(b, s.as_bytes());
        assert_eq!(decode_string(StringEncoding::Utf8, &b).unwrap(), s);
    }

    #[test]
    fn utf8_round_trip_bmp_and_supplementary() {
        // BMP (héllo + CJK text) + supplementary plane (🚀 = U+1F680 — 4-byte UTF-8)
        let s = "héllo world 🚀Ω≈ç√";
        let b = encode_string(StringEncoding::Utf8, s);
        assert_eq!(decode_string(StringEncoding::Utf8, &b).unwrap(), s);
        // Supplementary-plane chars are multi-byte (content-addressing sensitivity)
        assert!(b.len() > s.chars().count());
    }

    #[test]
    fn utf8_empty_string_round_trip() {
        let b = encode_string(StringEncoding::Utf8, "");
        assert!(b.is_empty());
        assert_eq!(decode_string(StringEncoding::Utf8, &b).unwrap(), "");
    }

    #[test]
    fn utf8_invalid_sequence_fail_closed() {
        // 0xC3 0x28 = truncated two-byte sequence (illegal continuation byte)
        let bad = [0xc3, 0x28];
        let err = decode_string(StringEncoding::Utf8, &bad).unwrap_err();
        assert!(err.message.contains("UTF-8"), "error face: {}", err.message);
        // Lone continuation byte (0x80 with no leading byte)
        let bad2 = [0x80];
        assert!(decode_string(StringEncoding::Utf8, &bad2).is_err());
    }

    #[test]
    fn utf16_round_trip_bmp() {
        let s = "héllo worldΩ"; // all BMP (including non-ASCII)
        let b = encode_string(StringEncoding::Utf16, s);
        assert_eq!(b.len(), s.chars().count() * 2);
        assert_eq!(decode_string(StringEncoding::Utf16, &b).unwrap(), s);
    }

    #[test]
    fn utf16_round_trip_surrogate_pair() {
        let s = "🚀𝕂𝕣𝕗"; // supplementary plane — surrogate pairs (4 bytes/char)
        let b = encode_string(StringEncoding::Utf16, s);
        assert_eq!(b.len(), s.chars().count() * 4);
        assert_eq!(decode_string(StringEncoding::Utf16, &b).unwrap(), s);
    }

    #[test]
    fn utf16_odd_length_fail_closed() {
        let err = decode_string(StringEncoding::Utf16, &[0x41, 0x00, 0x42]).unwrap_err();
        assert!(err.message.contains("even"), "error face: {}", err.message);
    }

    #[test]
    fn utf16_lone_surrogate_fail_closed() {
        // Lone high surrogate U+D83D (LE byte order 3d d8) — no low-surrogate pair
        let bytes: [u8; 2] = [0x3d, 0xd8];
        let err = decode_string(StringEncoding::Utf16, &bytes).unwrap_err();
        assert!(
            err.message.contains("surrogate"),
            "error face: {}",
            err.message
        );
        // Lone low surrogate U+DF00 (LE: 00 df) — no preceding high surrogate
        let bytes2: [u8; 2] = [0x00, 0xdf];
        assert!(decode_string(StringEncoding::Utf16, &bytes2).is_err());
        // Interleaved pair: high surrogate followed by a non-low-surrogate (U+D83D + 'A')
        let bytes3: [u8; 4] = [0x3d, 0xd8, 0x41, 0x00];
        assert!(decode_string(StringEncoding::Utf16, &bytes3).is_err());
    }

    #[test]
    fn cross_encoding_disjoint_bytes() {
        // Same string, different encoding → different bytes (protocol parameter sensitivity)
        let s = "héllo";
        let a = encode_string(StringEncoding::Utf8, s);
        let b = encode_string(StringEncoding::Utf16, s);
        assert_ne!(a, b);
    }

    #[test]
    fn address_width_from_memory64() {
        assert_eq!(AddressWidth::from_memory64(false), AddressWidth::I32);
        assert_eq!(AddressWidth::from_memory64(true), AddressWidth::I64);
    }

    #[test]
    fn pages_for_geometry() {
        assert_eq!(pages_for(0), 0);
        assert_eq!(pages_for(1), 1);
        assert_eq!(pages_for(PAGE_SIZE), 1);
        assert_eq!(pages_for(PAGE_SIZE + 1), 2);
        assert_eq!(pages_for(PAGE_SIZE * 3), 3);
    }

    #[test]
    fn align_table_and_align_up() {
        assert_eq!(align_to_byte_size(0), 1);
        assert_eq!(align_to_byte_size(3), 8);
        assert_eq!(align_to_byte_size(6), 64);
        assert_eq!(align_up(5, 8), 8);
        assert_eq!(align_up(8, 8), 8);
        assert_eq!(align_up(9, 8), 16);
        assert_eq!(align_up(0, 8), 0);
        // Defensive face: non-power-of-two alignment returns the original value
        assert_eq!(align_up(7, 6), 7);
    }
}

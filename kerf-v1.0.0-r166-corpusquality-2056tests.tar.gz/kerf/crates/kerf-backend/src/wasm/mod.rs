//! WASM component model domain (self-governing directory — r101 / 171-a
//! directory-ization: this directory = the self-governing domain of the full
//! TD-031 M0-M3 chain; this file = the contract layer, r74 / 144-c — the
//! carrier of [r74-window-opening §3]; the component-model deepening item
//! reserved by lang-design 13 §3.3.7 WasmBackend P1).
//!
//! **In-domain module map**: contract layer (this file — interface types /
//! component boundary / canonical ABI options + AnnotatedANF → component
//! model derivation, M0) + emitter [`emit`] (M1) + ABI adaptation layer
//! [`abi`] (M2) + composition layer [`compose`] (M3).
//!
//! **Positioning**: the **structured payload** of the
//! [`WasmBackend`](crate::codegen::WasmBackend) trait contract
//! (`compile_component` → [`WasmComponent`](crate::codegen::WasmComponent))
//! — materializing the contract shape of the component model (component
//! model + interface types + canonical ABI — the 2026 standard alignment).
//! **Not bytecode generation** (codegen stays trigger-based — TD-031
//! registered; this layer has zero external dependencies — §18 dependency
//! review discipline, pure Rust data modeling).
//!
//! **M1-M3 staged materialization route** ([wasm-backend-component-model.md]
//! (../../../../docs/develop/v0/stage-3/wasm-backend-component-model.md)):
//! - **M0 (this layer)**: component model contract + AnnotatedANF →
//!   component model derivation (core module function manifest — the
//!   prerequisite of the lowering plan);
//! - **M1**: core module bytecode generation (`CoreModuleFunc` manifest →
//!   core wasm module — value domain int/float first);
//! - **M2**: canonical ABI adaptation layer (`CanonicalAbiOptions`
//!   consumption — string encode/decode + realloc protocol);
//! - **M3**: component composition (imports/exports face stitching +
//!   component-level type validation).
//!
//! **Contract discipline** (Principle 27 — signature backward
//! compatibility): `WasmComponent` evolves from the `('bytes)`
//! single-field envelope to the `{ bytes, model }` two-field form — `bytes`
//! field semantics unchanged, `Default` compatibility unchanged, trait
//! method signatures unchanged (additive evolution; literal construction
//! sites migrated along — codegen.rs test anchors synced).

use crate::anf::{ABody, AnnotatedANF};
use crate::codegen::CodegenError;

pub mod abi;
pub mod compose;
pub mod emit;

// ---------------------------------------------------------------------------
// Interface types (interface types value domain — the cross-language type
// system of the component boundary)
// ---------------------------------------------------------------------------

/// Interface type (component model standard value domain — the type anchor
/// of the canonical ABI).
///
/// Mapping design ([wasm-backend-component-model.md §3]
/// (../../../docs/develop/v0/stage-3/wasm-backend-component-model.md)):
/// kerf `int` → `S64`, `float` → `F64`, `bool` → `Bool`, `str` →
/// `String`, `nil`/pairs/closures → outside the component boundary
/// (carried internally by the core module — `nil` = the `none` projection
/// of `Option` can land first).
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub enum InterfaceType {
    /// Boolean.
    Bool,
    /// Signed integer (width family).
    S8,
    /// 16-bit signed integer.
    S16,
    /// 32-bit signed integer.
    S32,
    /// 64-bit signed integer (component projection of kerf int).
    S64,
    /// Unsigned integer (width family).
    U8,
    /// 16-bit unsigned integer.
    U16,
    /// 32-bit unsigned integer.
    U32,
    /// 64-bit unsigned integer.
    U64,
    /// 32-bit float.
    F32,
    /// 64-bit float (component projection of kerf float).
    F64,
    /// Unicode scalar value.
    Char,
    /// Unicode string (component projection of kerf str).
    String,
    /// Homogeneous list.
    List(Box<InterfaceType>),
    /// Record (named field set).
    Record(Vec<(String, InterfaceType)>),
    /// Variant (tagged enum with payloads).
    Variant(Vec<(String, Option<InterfaceType>)>),
    /// Tuple (positional field set).
    Tuple(Vec<InterfaceType>),
    /// Optional value.
    Option(Box<InterfaceType>),
    /// Result value (ok/err two faces).
    Result {
        /// ok face payload (None = payload-less ok).
        ok: Option<Box<InterfaceType>>,
        /// err face payload (None = payload-less err).
        err: Option<Box<InterfaceType>>,
    },
    /// Component-level function type (component projection of first-class
    /// functions — the boundary shape of kerf closures).
    Func(ComponentFuncType),
}

/// Component-level function type (params/results both named — the component
/// model naming convention).
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct ComponentFuncType {
    /// Params (name + type).
    pub params: Vec<(String, InterfaceType)>,
    /// Results (name + type; the component model allows multiple results).
    pub results: Vec<(String, InterfaceType)>,
}

impl InterfaceType {
    /// Render (diagnostic and acceptance assertion face — close to the
    /// component model standard syntax).
    pub fn render(&self) -> String {
        match self {
            InterfaceType::Bool => "bool".into(),
            InterfaceType::S8 => "s8".into(),
            InterfaceType::S16 => "s16".into(),
            InterfaceType::S32 => "s32".into(),
            InterfaceType::S64 => "s64".into(),
            InterfaceType::U8 => "u8".into(),
            InterfaceType::U16 => "u16".into(),
            InterfaceType::U32 => "u32".into(),
            InterfaceType::U64 => "u64".into(),
            InterfaceType::F32 => "f32".into(),
            InterfaceType::F64 => "f64".into(),
            InterfaceType::Char => "char".into(),
            InterfaceType::String => "string".into(),
            InterfaceType::List(t) => format!("list<{}>", t.render()),
            InterfaceType::Record(fs) => {
                let inner: Vec<String> = fs
                    .iter()
                    .map(|(n, t)| format!("{}: {}", n, t.render()))
                    .collect();
                format!("record {{{}}}", inner.join(", "))
            }
            InterfaceType::Variant(cs) => {
                let inner: Vec<String> = cs
                    .iter()
                    .map(|(n, t)| match t {
                        Some(t) => format!("{}({})", n, t.render()),
                        None => n.to_string(),
                    })
                    .collect();
                format!("variant {{{}}}", inner.join(", "))
            }
            InterfaceType::Tuple(ts) => {
                let inner: Vec<String> = ts.iter().map(|t| t.render()).collect();
                format!("tuple<{}>", inner.join(", "))
            }
            InterfaceType::Option(t) => format!("option<{}>", t.render()),
            InterfaceType::Result { ok, err } => {
                let o = ok.as_ref().map(|t| t.render()).unwrap_or_default();
                let e = err.as_ref().map(|t| t.render()).unwrap_or_default();
                format!("result<{}, {}>", o, e)
            }
            InterfaceType::Func(ft) => {
                let ps: Vec<String> = ft
                    .params
                    .iter()
                    .map(|(n, t)| format!("{}: {}", n, t.render()))
                    .collect();
                let rs: Vec<String> = ft
                    .results
                    .iter()
                    .map(|(n, t)| format!("{}: {}", n, t.render()))
                    .collect();
                format!("func({}) -> {}", ps.join(", "), rs.join(", "))
            }
        }
    }

    /// Recursion depth limit (for builder validation — the contractual depth
    /// bound against cyclic constructions).
    pub fn depth(&self) -> usize {
        1 + match self {
            InterfaceType::List(t) | InterfaceType::Option(t) => t.depth(),
            InterfaceType::Record(fs) => fs.iter().map(|(_, t)| t.depth()).max().unwrap_or(0),
            InterfaceType::Variant(cs) => cs
                .iter()
                .map(|(_, t)| t.as_ref().map(|t| t.depth()).unwrap_or(0))
                .max()
                .unwrap_or(0),
            InterfaceType::Tuple(ts) => ts.iter().map(|t| t.depth()).max().unwrap_or(0),
            InterfaceType::Result { ok, err } => [ok.as_deref(), err.as_deref()]
                .into_iter()
                .flatten()
                .map(|t| t.depth())
                .max()
                .unwrap_or(0),
            InterfaceType::Func(ft) => ft
                .params
                .iter()
                .chain(ft.results.iter())
                .map(|(_, t)| t.depth())
                .max()
                .unwrap_or(0),
            _ => 0,
        }
    }
}

// ---------------------------------------------------------------------------
// Component boundary (imports/exports — the component-level expression of
// the capability boundary)
// ---------------------------------------------------------------------------

/// Component import (name + interface type — the supply face from the host /
/// other components).
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct ComponentImport {
    /// Import name (unique identifier within the component model namespace).
    pub name: String,
    /// Import type.
    pub ty: InterfaceType,
}

/// Component export (name + interface type — this component's outward supply
/// face).
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct ComponentExport {
    /// Export name (unique identifier within the component model namespace).
    pub name: String,
    /// Export type.
    pub ty: InterfaceType,
}

// ---------------------------------------------------------------------------
// canonical ABI options (component boundary value encode/decode protocol)
// ---------------------------------------------------------------------------

/// String encoding (the canonical ABI `string-encoding` option).
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Hash)]
pub enum StringEncoding {
    /// UTF-8 (default — same encoding as the Rust carrier of kerf str).
    #[default]
    Utf8,
    /// UTF-16.
    Utf16,
}

/// canonical ABI option set (encode/decode protocol parameters for
/// component instantiation).
#[derive(Debug, Clone, Default, PartialEq, Eq, Hash)]
pub struct CanonicalAbiOptions {
    /// String encoding.
    pub string_encoding: StringEncoding,
    /// 64-bit linear memory space (`memory64`).
    pub memory64: bool,
    /// realloc function (core module function name — the boundary value
    /// buffer allocation protocol anchor; None = the component crosses no
    /// boundary types that require allocation).
    pub realloc: Option<String>,
}

// ---------------------------------------------------------------------------
// Core module function manifest (AnnotatedANF → component lowering plan
// prerequisite)
// ---------------------------------------------------------------------------

/// Core module function manifest entry (the M1 bytecode generation anchor —
/// function manifest + shape summary).
#[derive(Debug, Clone, Default, PartialEq, Eq, Hash)]
pub struct CoreModuleFunc {
    /// Function name (same source as `AFuncDef.name` — the QBE global symbol
    /// base name).
    pub name: String,
    /// Parameter count.
    pub params: usize,
    /// Block count (length of `ABody.blocks` — block graph size summary).
    pub blocks: usize,
}

/// Component model version marker (the component model standard version
/// anchor — the M1 generation compatibility criterion).
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Hash)]
pub struct ComponentModelVersion(pub u32);

/// Component model full picture (core module function manifest + component
/// boundary + ABI options).
///
/// Derived from AnnotatedANF by [`component_model_from_anf`] (M0 derived
/// artifact) or built explicitly via [`ComponentModelBuilder`] (M2/M3
/// composition artifact).
#[derive(Debug, Clone, Default, PartialEq, Eq, Hash)]
pub struct WasmComponentModel {
    /// Component model version (1 = current standard alignment).
    pub version: ComponentModelVersion,
    /// Core module function manifest.
    pub core_funcs: Vec<CoreModuleFunc>,
    /// Component import face.
    pub imports: Vec<ComponentImport>,
    /// Component export face.
    pub exports: Vec<ComponentExport>,
    /// canonical ABI options.
    pub abi: CanonicalAbiOptions,
    /// Source IR fingerprint (content-addressing chain — same source as
    /// `AnnotatedANF.fingerprint`, the provenance anchor of the component
    /// artifact).
    pub source_fingerprint: u64,
}

/// Component model recursion depth limit (builder validation — the
/// contractual depth bound on interface types).
pub const MAX_INTERFACE_TYPE_DEPTH: usize = 16;

// ---------------------------------------------------------------------------
// Builder (build + validate — uniqueness / type well-formedness / depth
// bound)
// ---------------------------------------------------------------------------

/// Component model builder (explicit composition face — incremental assembly
/// of imports/exports/ABI options + final-state validation).
#[derive(Debug, Clone, Default)]
pub struct ComponentModelBuilder {
    version: ComponentModelVersion,
    core_funcs: Vec<CoreModuleFunc>,
    imports: Vec<ComponentImport>,
    exports: Vec<ComponentExport>,
    abi: CanonicalAbiOptions,
    source_fingerprint: u64,
}

impl ComponentModelBuilder {
    /// Empty builder (version defaults to 1).
    pub fn new() -> Self {
        ComponentModelBuilder {
            version: ComponentModelVersion(1),
            ..Default::default()
        }
    }

    /// Version marker.
    pub fn version(mut self, v: ComponentModelVersion) -> Self {
        self.version = v;
        self
    }

    /// Core module function (append).
    pub fn core_func(mut self, f: CoreModuleFunc) -> Self {
        self.core_funcs.push(f);
        self
    }

    /// Component import (append).
    pub fn import(mut self, name: impl Into<String>, ty: InterfaceType) -> Self {
        self.imports.push(ComponentImport {
            name: name.into(),
            ty,
        });
        self
    }

    /// Component export (append).
    pub fn export(mut self, name: impl Into<String>, ty: InterfaceType) -> Self {
        self.exports.push(ComponentExport {
            name: name.into(),
            ty,
        });
        self
    }

    /// String encoding option.
    pub fn string_encoding(mut self, enc: StringEncoding) -> Self {
        self.abi.string_encoding = enc;
        self
    }

    /// memory64 option.
    pub fn memory64(mut self, on: bool) -> Self {
        self.abi.memory64 = on;
        self
    }

    /// realloc protocol anchor (core module function name).
    pub fn realloc(mut self, func: impl Into<String>) -> Self {
        self.abi.realloc = Some(func.into());
        self
    }

    /// Source IR fingerprint (content-addressing chain).
    pub fn source_fingerprint(mut self, fp: u64) -> Self {
        self.source_fingerprint = fp;
        self
    }

    /// Final-state validation + build.
    ///
    /// Validation (fail-closed): ① core function names unique ② import
    /// names unique ③ export names unique ④ interface type recursion depth
    /// bound ⑤ realloc anchor within the core function manifest (if set).
    pub fn build(self) -> Result<WasmComponentModel, CodegenError> {
        let mut seen: std::collections::HashSet<&str> = std::collections::HashSet::new();
        for f in &self.core_funcs {
            if !seen.insert(f.name.as_str()) {
                return Err(CodegenError::new(format!(
                    "component model validation failed: core function name duplicate `{}`",
                    f.name
                )));
            }
        }
        seen.clear();
        for i in &self.imports {
            if !seen.insert(i.name.as_str()) {
                return Err(CodegenError::new(format!(
                    "component model validation failed: import name duplicate `{}`",
                    i.name
                )));
            }
            if i.ty.depth() > MAX_INTERFACE_TYPE_DEPTH {
                return Err(CodegenError::new(format!(
                    "component model validation failed: import `{}` type depth bound exceeded ({} > {}): {}",
                    i.name,
                    i.ty.depth(),
                    MAX_INTERFACE_TYPE_DEPTH,
                    i.ty.render()
                )));
            }
        }
        seen.clear();
        for e in &self.exports {
            if !seen.insert(e.name.as_str()) {
                return Err(CodegenError::new(format!(
                    "component model validation failed: export name duplicate `{}`",
                    e.name
                )));
            }
            if e.ty.depth() > MAX_INTERFACE_TYPE_DEPTH {
                return Err(CodegenError::new(format!(
                    "component model validation failed: export `{}` type depth bound exceeded ({} > {}): {}",
                    e.name,
                    e.ty.depth(),
                    MAX_INTERFACE_TYPE_DEPTH,
                    e.ty.render()
                )));
            }
        }
        if let Some(realloc) = &self.abi.realloc {
            if !self.core_funcs.iter().any(|f| &f.name == realloc) {
                return Err(CodegenError::new(format!(
                    "component model validation failed: realloc anchor `{}` not in the core function list",
                    realloc
                )));
            }
        }
        Ok(WasmComponentModel {
            version: self.version,
            core_funcs: self.core_funcs,
            imports: self.imports,
            exports: self.exports,
            abi: self.abi,
            source_fingerprint: self.source_fingerprint,
        })
    }
}

// ---------------------------------------------------------------------------
// AnnotatedANF → component model derivation (M0 derived artifact — lowering
// plan prerequisite)
// ---------------------------------------------------------------------------

/// AnnotatedANF → component model derivation (core module function
/// manifest + default ABI options + source fingerprint chain;
/// imports/exports empty — assembled on demand by M3 composition
/// artifacts).
///
/// **M0 boundary** (honest narrowing — [wasm-backend-component-model.md §5]
/// (../../../docs/develop/v0/stage-3/wasm-backend-component-model.md)):
/// the derivation face = function manifest and shape summary
/// (`CoreModuleFunc`); **excludes** core wasm bytecode, canonical ABI
/// adaptation instructions, and component composition stitching (M1-M3
/// stay trigger-based — TD-031).
pub fn component_model_from_anf(ir: &AnnotatedANF) -> WasmComponentModel {
    let core_funcs: Vec<CoreModuleFunc> = ir
        .funcs
        .iter()
        .map(|f| CoreModuleFunc {
            name: f.name.clone(),
            params: f.params.len(),
            blocks: block_count(&f.body),
        })
        .collect();
    WasmComponentModel {
        version: ComponentModelVersion(1),
        core_funcs,
        imports: Vec::new(),
        exports: Vec::new(),
        abi: CanonicalAbiOptions::default(),
        source_fingerprint: ir.fingerprint,
    }
}

/// Block count (direct `ABody` reference — manifest summary).
fn block_count(body: &ABody) -> usize {
    body.blocks.len()
}

// ---------------------------------------------------------------------------
// Contract latch tests (13 §3.3.7 precedent — "test bodies compile" proves
// the contract is frozen)
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use crate::anf::{ABlock, AFuncDef};

    /// Component model derivation: function manifest + shape summary +
    /// fingerprint chain (M0 derived artifact anchor).
    #[test]
    fn component_model_from_anf_inventory() {
        let ir = AnnotatedANF {
            funcs: vec![
                AFuncDef {
                    name: "fib".into(),
                    params: vec![crate::anf::ATemp(0)],
                    body: ABody {
                        blocks: vec![ABlock::default(); 3],
                    },
                },
                AFuncDef {
                    name: "main".into(),
                    params: vec![],
                    body: ABody {
                        blocks: vec![ABlock::default(); 1],
                    },
                },
            ],
            fingerprint: 42,
        };
        let m = component_model_from_anf(&ir);
        assert_eq!(m.version, ComponentModelVersion(1));
        assert_eq!(m.core_funcs.len(), 2);
        assert_eq!(m.core_funcs[0].name, "fib");
        assert_eq!(m.core_funcs[0].params, 1);
        assert_eq!(m.core_funcs[0].blocks, 3);
        assert_eq!(m.core_funcs[1].name, "main");
        assert_eq!(m.core_funcs[1].params, 0);
        assert_eq!(m.core_funcs[1].blocks, 1);
        assert_eq!(m.source_fingerprint, 42);
        assert!(m.imports.is_empty());
        assert!(m.exports.is_empty());
        assert_eq!(m.abi.string_encoding, StringEncoding::Utf8);
        assert!(!m.abi.memory64);
        assert!(m.abi.realloc.is_none());
    }

    /// Builder validation: duplicate core function names rejected
    /// (fail-closed).
    #[test]
    fn builder_rejects_duplicate_core_funcs() {
        let r = ComponentModelBuilder::new()
            .core_func(CoreModuleFunc {
                name: "f".into(),
                params: 1,
                blocks: 1,
            })
            .core_func(CoreModuleFunc {
                name: "f".into(),
                params: 0,
                blocks: 1,
            })
            .build();
        assert!(r.is_err());
        assert!(r
            .unwrap_err()
            .reason
            .contains("core function name duplicate"));
    }

    /// Builder validation: duplicate import/export names rejected.
    #[test]
    fn builder_rejects_duplicate_boundary_names() {
        let dup_import = ComponentModelBuilder::new()
            .import("host", InterfaceType::String)
            .import("host", InterfaceType::S64)
            .build();
        assert!(dup_import
            .unwrap_err()
            .reason
            .contains("import name duplicate"));
        let dup_export = ComponentModelBuilder::new()
            .export(
                "run",
                InterfaceType::Func(ComponentFuncType {
                    params: vec![],
                    results: vec![],
                }),
            )
            .export("run", InterfaceType::S64)
            .build();
        assert!(dup_export
            .unwrap_err()
            .reason
            .contains("export name duplicate"));
    }

    /// Builder validation: interface type depth bound rejection (the
    /// contractual depth bound against cyclic constructions).
    #[test]
    fn builder_rejects_interface_type_depth_overflow() {
        // list<list<...>> depth 17 > 16
        let mut t = InterfaceType::S64;
        for _ in 0..MAX_INTERFACE_TYPE_DEPTH {
            t = InterfaceType::List(Box::new(t));
        }
        assert!(t.depth() > MAX_INTERFACE_TYPE_DEPTH);
        let r = ComponentModelBuilder::new().export("deep", t).build();
        assert!(r.unwrap_err().reason.contains("depth bound exceeded"));
    }

    /// Builder validation: the realloc anchor must be within the core
    /// function manifest.
    #[test]
    fn builder_rejects_dangling_realloc_anchor() {
        let r = ComponentModelBuilder::new().realloc("cabi_realloc").build();
        assert!(r.unwrap_err().reason.contains("realloc anchor"));
        let ok = ComponentModelBuilder::new()
            .core_func(CoreModuleFunc {
                name: "cabi_realloc".into(),
                params: 4,
                blocks: 1,
            })
            .realloc("cabi_realloc")
            .build();
        assert!(ok.is_ok());
    }

    /// Builder composition face: ABI options + boundary faces + version +
    /// fingerprint (final-state full-picture anchor).
    #[test]
    fn builder_assembles_full_model() {
        let m = ComponentModelBuilder::new()
            .version(ComponentModelVersion(1))
            .core_func(CoreModuleFunc {
                name: "cabi_realloc".into(),
                params: 4,
                blocks: 1,
            })
            .core_func(CoreModuleFunc {
                name: "run".into(),
                params: 0,
                blocks: 2,
            })
            .import(
                "host:log",
                InterfaceType::Func(ComponentFuncType {
                    params: vec![("msg".into(), InterfaceType::String)],
                    results: vec![],
                }),
            )
            .export(
                "compute",
                InterfaceType::Func(ComponentFuncType {
                    params: vec![("n".into(), InterfaceType::S64)],
                    results: vec![(
                        "r".into(),
                        InterfaceType::Option(Box::new(InterfaceType::F64)),
                    )],
                }),
            )
            .string_encoding(StringEncoding::Utf16)
            .memory64(true)
            .realloc("cabi_realloc")
            .source_fingerprint(7)
            .build()
            .expect("legal component model");
        assert_eq!(m.core_funcs.len(), 2);
        assert_eq!(m.imports.len(), 1);
        assert_eq!(m.exports.len(), 1);
        assert_eq!(m.abi.string_encoding, StringEncoding::Utf16);
        assert!(m.abi.memory64);
        assert_eq!(m.abi.realloc.as_deref(), Some("cabi_realloc"));
        assert_eq!(m.source_fingerprint, 7);
        // Render face (diagnostic anchor)
        assert!(m.exports[0].ty.render().contains("option<f64>"));
        assert!(m.imports[0].ty.render().contains("msg: string"));
    }

    /// Interface type render family (diagnostic and acceptance assertion
    /// face).
    #[test]
    fn interface_type_render_family() {
        assert_eq!(InterfaceType::S64.render(), "s64");
        assert_eq!(InterfaceType::String.render(), "string");
        assert_eq!(
            InterfaceType::List(Box::new(InterfaceType::Bool)).render(),
            "list<bool>"
        );
        assert_eq!(
            InterfaceType::Record(vec![
                ("x".into(), InterfaceType::S64),
                ("y".into(), InterfaceType::F64),
            ])
            .render(),
            "record {x: s64, y: f64}"
        );
        assert_eq!(
            InterfaceType::Result {
                ok: Some(Box::new(InterfaceType::S64)),
                err: None,
            }
            .render(),
            "result<s64, >"
        );
        assert_eq!(
            InterfaceType::Variant(vec![
                ("none".into(), None),
                ("some".into(), Some(InterfaceType::S64)),
            ])
            .render(),
            "variant {none, some(s64)}"
        );
    }

    /// WasmComponent structured envelope: bytes semantics unchanged + model
    /// payload + Default compatibility (Principle 27 additive evolution
    /// anchor — linked to the codegen.rs contract tests).
    #[test]
    fn wasm_component_carries_structured_model() {
        use crate::codegen::WasmComponent;
        let ir = AnnotatedANF {
            funcs: vec![AFuncDef {
                name: "main".into(),
                params: vec![],
                body: ABody {
                    blocks: vec![ABlock::default()],
                },
            }],
            fingerprint: 9,
        };
        let model = component_model_from_anf(&ir);
        let c = WasmComponent {
            bytes: ir.fingerprint.to_le_bytes().to_vec(),
            model: model.clone(),
        };
        assert_eq!(c.bytes, 9u64.to_le_bytes().to_vec());
        assert_eq!(c.model, model);
        assert_eq!(c.model.source_fingerprint, 9);
        // Default compatibility (the historical `WasmComponent::default()` path
        // keeps working)
        let d = WasmComponent::default();
        assert!(d.bytes.is_empty());
        assert_eq!(d.model, WasmComponentModel::default());
    }
}

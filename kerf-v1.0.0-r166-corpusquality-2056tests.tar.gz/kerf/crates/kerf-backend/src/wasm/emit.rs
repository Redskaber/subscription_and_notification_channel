//! WASM core module bytecode emitter (M1 — phase 1 of TD-031, materialized).
//!
//! **Positioning**: [`AnnotatedANF`](crate::anf::AnnotatedANF) → **core
//! wasm module binary** (magic/version + Type/Function/Export/Code sections +
//! the `kerf_meta` manifest custom section).
//! [`WasmCoreBackend`](crate::wasm::emit::
//! WasmCoreBackend) is the **first materialized implementation** of the
//! [`WasmBackend`](crate::codegen::WasmBackend) trait — `WasmComponent.bytes`
//! is exactly this emitter's payload (the payload semantics of M1 bytecode
//! generation, honoring the codegen.rs contract comments).
//!
//! **M1 boundary (honest narrowing aligned with B1 —
//! wasm-backend-component-model §5)**:
//! - **Value domain**: `i64` first (kerf int full width) — ANF atoms have
//!   no Float variant, `f64` is the contract-level projection of
//!   [`InterfaceType::F64`](crate::wasm::InterfaceType::F64) (zero Float
//!   corpus signal — TD-024 criterion 3 kept in the same lineage);
//! - **WASM GC types (L-A ruling)**: the core module = the linear type
//!   domain (i64 value domain + locals + stack-machine instructions); GC
//!   heap types stay out of boundary (same alignment as M0's "in-heap
//!   representation is core-module internal") — re-evaluated when a GC
//!   type consumption signal appears;
//! - **§18 dependency ruling (L-B)**: hand-written bytecode emitter (zero
//!   cargo dependencies); host-side node (`WebAssembly.validate` +
//!   instantiation) serves only as a **test-time verification tool** (same
//!   precedent as qbe/cc — external host tools are not build
//!   dependencies);
//! - **CFG → structured control**: the ANF block graph is a forward
//!   well-nested if-diamond DAG (anf.rs lowering empirically-verified
//!   invariants: value-context if → Br + two Jmp arms + single phi merge;
//!   tail if → Br + two Ret arms) — the emission algorithm = recursive
//!   region decomposition (diamond → `if (result i64)`, tail →
//!   `if (void)`); structural violations fail-closed.
//!
//! **Truthiness boundary (i64 full-width test anchor)**: kerf booleans =
//!   nonzero-is-true (`Int(0)` is false); condition tests use the
//!   `i64.eqz + i32.eqz` double negation (**not** `i32.wrap_i64` — an i64
//!   whose low 32 bits are zero but high 32 bits are not (e.g. 2^32)
//!   wraps to a constant 0 and would be misjudged as false).

use crate::anf::{AAtom, ABlock, ACtrl, AFuncDef, AOp, APhi, APrim, ATemp, AnnotatedANF};
use crate::codegen::{CodegenError, WasmBackend, WasmComponent};
use crate::wasm::{component_model_from_anf, CanonicalAbiOptions, CoreModuleFunc};

// ---------------------------------------------------------------------------
// Binary encoding infrastructure (LEB128 + section framing)
// ---------------------------------------------------------------------------

/// WASM magic + version (8 bytes — the common header of all core modules).
const HEADER: [u8; 8] = [0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00];

/// Manifest custom section name (read-back reconciliation anchor — single
/// source on both the emit and parse sides).
const MANIFEST_SECTION_NAME: &str = "kerf_meta";

/// Unsigned LEB128 encoding (u32 — counts/indexes/local numbering face).
fn uleb32(out: &mut Vec<u8>, mut v: u32) {
    loop {
        let b = (v & 0x7f) as u8;
        v >>= 7;
        if v == 0 {
            out.push(b);
            return;
        }
        out.push(b | 0x80);
    }
}

/// Signed LEB128 encoding (i64 — the `i64.const` payload face).
fn sleb64(out: &mut Vec<u8>, v: i64) {
    let mut v = v;
    loop {
        let byte = (v as u8) & 0x7f; // low 7 bits
        v >>= 7;
        let sign_bit = byte & 0x40 != 0;
        // Termination: remaining bits all zero with the sign bit clear
        // (positive convergence); or remaining bits all ones
        // (sign-extended -1) with the sign bit set (negative convergence).
        if (v == 0 && !sign_bit) || (v == -1 && sign_bit) {
            out.push(byte);
            return;
        }
        out.push(byte | 0x80);
    }
}

/// Name encoding (len-prefixed UTF-8 — the name face of the wasm binary
/// format).
fn name_bytes(out: &mut Vec<u8>, s: &str) {
    uleb32(out, s.len() as u32);
    out.extend_from_slice(s.as_bytes());
}

/// Section framing (id + size prefix + payload).
fn section(id: u8, payload: &[u8]) -> Vec<u8> {
    let mut out = Vec::with_capacity(payload.len() + 5);
    out.push(id);
    uleb32(&mut out, payload.len() as u32);
    out.extend_from_slice(payload);
    out
}

// ---------------------------------------------------------------------------
// Instruction opcodes (M1 support face — the i64 linear domain)
// ---------------------------------------------------------------------------

const OP_UNREACHABLE: u8 = 0x00;
const OP_IF: u8 = 0x04;
const OP_ELSE: u8 = 0x05;
const OP_END: u8 = 0x0b;
const OP_RETURN: u8 = 0x0f;
const OP_CALL: u8 = 0x10;
const OP_LOCAL_GET: u8 = 0x20;
const OP_LOCAL_SET: u8 = 0x21;
const OP_I64_CONST: u8 = 0x42;
const OP_I32_EQZ: u8 = 0x45;
const OP_I64_EQZ: u8 = 0x50;
const OP_I64_EQ: u8 = 0x51;
const OP_I64_LT_S: u8 = 0x53;
const OP_I64_GT_S: u8 = 0x55;
const OP_I64_LE_S: u8 = 0x57;
const OP_I64_GE_S: u8 = 0x59;
const OP_I64_ADD: u8 = 0x7c;
const OP_I64_SUB: u8 = 0x7d;
const OP_I64_MUL: u8 = 0x7e;
const OP_I64_DIV_S: u8 = 0x7f;
const OP_I64_REM_S: u8 = 0x81;
const OP_I64_EXTEND_I32_U: u8 = 0xad;

const BLOCKTYPE_VOID: u8 = 0x40;
const VALTYPE_I64: u8 = 0x7e;

// ---------------------------------------------------------------------------
// Emitter (AnnotatedANF → core wasm module)
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// M3: component import face (the stitching consumption side of the core
// module — Import section emission input)
// ---------------------------------------------------------------------------

/// Imported memory spec (M3 — the linear memory import of the canonical ABI
/// boundary module).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ImportMemorySpec {
    /// Minimum page count (must be ≤ the supplier's exported memory's
    /// actual page count — stitching validation anchor).
    pub min_pages: u32,
    /// memory64 address domain (limits flag bit 0x04).
    pub memory64: bool,
}

/// Imported function spec (M3 — the canonical ABI realloc protocol function
/// import).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ImportFuncSpec {
    /// Import field name (= the supplier's realloc export name —
    /// [`crate::wasm::abi::
    /// CANONICAL_REALLOC_DEFAULT_NAME` or `CanonicalAbiOptions::realloc`]).
    pub name: String,
    /// memory64 address domain (decides the width of the signature
    /// `(addr × 4) → addr` — isomorphic to the single source of the
    /// realloc signature on the supplier's emit side [`emit_abi_module`]).
    pub wide: bool,
}

/// The core module's component import face (M3 — the consumption-side
/// description of imports/exports stitching).
///
/// Linked emission shape: the **Import section (id 0x02 — after the Type
/// section, before the Function section)** declares memory + realloc
/// imports from the boundary module (the `module`-named instance);
/// **imported functions occupy the front of the function index space** —
/// defined function indexes are wholly offset by
/// [`CoreImportFace::imported_func_count`] (the Export `main` and Call
/// resolution shift in sync — the WASM function index space rule:
/// imported functions precede defined functions).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CoreImportFace {
    /// Supplier instance name (the first segment of the import's two-level
    /// name — composition-layer convention [`crate::
    /// crate::wasm::compose::ABI_MODULE_NAME`]).
    pub module: String,
    /// Linear memory import (the memory stitching of the canonical ABI
    /// composition).
    pub memory: Option<ImportMemorySpec>,
    /// realloc function import (the allocation protocol stitching of the
    /// canonical ABI composition).
    pub realloc: Option<ImportFuncSpec>,
}

impl CoreImportFace {
    /// Empty face (no imports — the plain emission shape, same alignment as
    /// [`emit_core_module`]).
    pub fn none() -> Self {
        CoreImportFace {
            module: String::new(),
            memory: None,
            realloc: None,
        }
    }

    /// Imported function count (function index space base offset — realloc
    /// is the sole function import).
    pub fn imported_func_count(&self) -> u32 {
        if self.realloc.is_some() {
            1
        } else {
            0
        }
    }

    /// Total import count (Import section count).
    pub fn import_count(&self) -> usize {
        self.memory.iter().count() + self.realloc.iter().count()
    }

    /// Face well-formedness validation (fail-closed: imports require an
    /// instance name; the realloc field name must be non-empty).
    fn validate(&self) -> Result<(), CodegenError> {
        if self.import_count() > 0 && self.module.is_empty() {
            return Err(CodegenError::new(
                "WASM M3 emit failed: import face missing provider instance name",
            ));
        }
        if let Some(re) = &self.realloc {
            if re.name.is_empty() {
                return Err(CodegenError::new(
                    "WASM M3 emit failed: realloc import field name is empty",
                ));
            }
        }
        Ok(())
    }
}

/// Type section deduplication pool entry (M3 extension — function arity
/// signatures + the realloc address-domain signature).
#[derive(Debug, Clone, PartialEq, Eq)]
enum PoolEntry {
    /// Function signature: `(i64 × arity) → i64`.
    Arity(usize),
    /// realloc signature (wasm32 domain): `(i32 × 4) → i32`.
    ///
    /// The memory64-domain realloc signature `(i64 × 4) → i64` is
    /// structurally isomorphic to the four-parameter function signature —
    /// it reuses the [`PoolEntry::Arity`]`(4)` entry (WASM type structural
    /// equivalence suffices to share a typeidx).
    AddrSig,
}

/// Emit a core wasm module binary (plain shape — no import face, M1
/// semantics unchanged).
///
/// **Artifact structure** (section order = Type[1] → Function[3] →
/// Export[7] → Code[10] → Custom[kerf_meta] — the custom section goes
/// last to keep the core sections contiguous):
/// - Type section: function type deduplication (`(i64 × arity) → i64` —
///   linear-scan dedup, deterministic order-preserving);
/// - Function section: each function's type index;
/// - Export section: `main` (function index 0 — the `lower_program` main
///   conventional slot; same alignment as the QBE PoC: only main is
///   exported, everything else is internal);
/// - Code section: per-function bodies (locals declarations + instruction
///   sequences);
/// - `kerf_meta` custom section: the `CoreModuleFunc` manifest
///   (name/arity/block count — the anchor for read-back reconciliation
///   by [`parse_core_module_manifest`]).
///
/// **Determinism**: same ANF → same bytes (fully structurally ordered
/// emission; no hash iteration order enters the artifact).
pub fn emit_core_module(ir: &AnnotatedANF) -> Result<Vec<u8>, CodegenError> {
    emit_core_module_face(ir, &CoreImportFace::none())
}

/// Emit a core wasm module with a component import face (M3 — the
/// stitching consumption-side shape).
///
/// Differences from the plain shape ([`CoreImportFace`] docs): ① the Type
/// section dedup pool gains the realloc signature entry; ② the Import
/// section (id 0x02) is inserted between the Type and Function sections;
/// ③ the function index space base offset = the imported function count
/// (Export `main` and Call shift in sync); ④ empty function manifest +
/// non-empty face = fail-closed (the import face requires a `main` export
/// to carry it).
pub fn emit_core_module_linked(
    ir: &AnnotatedANF,
    face: &CoreImportFace,
) -> Result<Vec<u8>, CodegenError> {
    emit_core_module_face(ir, face)
}

fn emit_core_module_face(
    ir: &AnnotatedANF,
    face: &CoreImportFace,
) -> Result<Vec<u8>, CodegenError> {
    face.validate()?;
    // Function name uniqueness (fail-closed — the precondition for Call
    // index resolution)
    for (i, f) in ir.funcs.iter().enumerate() {
        if f.name.is_empty() {
            return Err(CodegenError::new(format!(
                "WASM M1 emit failed: function {} name is empty",
                i
            )));
        }
        if ir.funcs[..i].iter().any(|g| g.name == f.name) {
            return Err(CodegenError::new(format!(
                "WASM M1 emit failed: function name `{}` duplicate(index <{} and {})",
                f.name, i, i
            )));
        }
    }

    let mut out = Vec::with_capacity(64);
    out.extend_from_slice(&HEADER);

    if ir.funcs.is_empty() {
        if face.import_count() > 0 {
            return Err(CodegenError::new(
                "WASM M3 emit failed: import face requires a main export -- an empty function list cannot carry linked emission",
            ));
        }
        // Empty module: header only (a legal minimal wasm — 0 functions 0
        // sections; the manifest section keeps the same alignment)
        let manifest = encode_manifest(&[]);
        out.extend_from_slice(&manifest);
        return Ok(out);
    }

    // ---- Type section (signature dedup pool: function arity + realloc
    // address-domain signature) ----
    let mut pool: Vec<PoolEntry> = Vec::new(); // dedup pool (deterministic, order-preserving)
    let mut type_sigs: Vec<usize> = Vec::new(); // per-function type indexes
    for f in &ir.funcs {
        let entry = PoolEntry::Arity(f.params.len());
        let idx = pool.iter().position(|e| *e == entry).unwrap_or_else(|| {
            pool.push(entry);
            pool.len() - 1
        });
        type_sigs.push(idx);
    }
    // realloc signature entry: wide = (i64×4)→i64 reuses the
    // four-parameter signature (isomorphic); narrow = (i32×4)→i32 is its
    // own entry (the function pool is all-i64, no clash).
    let realloc_typeidx: Option<usize> = face.realloc.as_ref().map(|re| {
        let entry = if re.wide {
            PoolEntry::Arity(4)
        } else {
            PoolEntry::AddrSig
        };
        pool.iter().position(|e| *e == entry).unwrap_or_else(|| {
            pool.push(entry);
            pool.len() - 1
        })
    });
    let mut ty_payload = Vec::new();
    uleb32(&mut ty_payload, pool.len() as u32);
    for entry in &pool {
        match entry {
            PoolEntry::Arity(arity) => {
                ty_payload.push(0x60); // functype
                uleb32(&mut ty_payload, *arity as u32);
                ty_payload.extend(std::iter::repeat_n(VALTYPE_I64, *arity));
                uleb32(&mut ty_payload, 1);
                ty_payload.push(VALTYPE_I64);
            }
            PoolEntry::AddrSig => {
                // realloc wasm32-domain signature: (i32 × 4) → i32
                ty_payload.push(0x60);
                uleb32(&mut ty_payload, 4);
                ty_payload.extend(std::iter::repeat_n(VALTYPE_I32, 4));
                uleb32(&mut ty_payload, 1);
                ty_payload.push(VALTYPE_I32);
            }
        }
    }
    out.extend_from_slice(&section(0x01, &ty_payload));

    // ---- Import section (id 0x02 — after Type, before Function; imported
    // functions occupy the front of the function index space) ----
    if face.import_count() > 0 {
        let mut im_payload = Vec::new();
        uleb32(&mut im_payload, face.import_count() as u32);
        if let Some(mem) = &face.memory {
            name_bytes(&mut im_payload, &face.module);
            name_bytes(&mut im_payload, "memory");
            im_payload.push(0x02); // kind = memory
            im_payload.push(if mem.memory64 { 0x04 } else { 0x00 }); // limits flags
            uleb32(&mut im_payload, mem.min_pages);
        }
        if let Some(re) = &face.realloc {
            name_bytes(&mut im_payload, &face.module);
            name_bytes(&mut im_payload, &re.name);
            im_payload.push(0x00); // kind = func
            uleb32(
                &mut im_payload,
                realloc_typeidx.expect("face containing realloc must have an index") as u32,
            );
        }
        out.extend_from_slice(&section(0x02, &im_payload));
    }

    // Function index space base offset (imported functions precede defined
    // functions — WASM spec)
    let func_base = face.imported_func_count();

    // ---- Function section ----
    let mut fn_payload = Vec::new();
    uleb32(&mut fn_payload, ir.funcs.len() as u32);
    for &t in &type_sigs {
        uleb32(&mut fn_payload, t as u32);
    }
    out.extend_from_slice(&section(0x03, &fn_payload));

    // ---- Export section (main = func_base + 0 — shifted in sync when
    // imported functions occupy the front indexes) ----
    let mut ex_payload = Vec::new();
    uleb32(&mut ex_payload, 1);
    name_bytes(&mut ex_payload, "main");
    ex_payload.push(0x00); // kind = func
    uleb32(&mut ex_payload, func_base);
    out.extend_from_slice(&section(0x07, &ex_payload));

    // ---- Code section ----
    let names: Vec<&str> = ir.funcs.iter().map(|f| f.name.as_str()).collect();
    let mut code_payload = Vec::new();
    uleb32(&mut code_payload, ir.funcs.len() as u32);
    for f in &ir.funcs {
        let body = emit_func_body(f, &names, func_base)?;
        uleb32(&mut code_payload, body.len() as u32);
        code_payload.extend_from_slice(&body);
    }
    out.extend_from_slice(&section(0x0a, &code_payload));

    // ---- kerf_meta custom section (manifest) ----
    let manifest: Vec<CoreModuleFunc> = ir
        .funcs
        .iter()
        .map(|f| CoreModuleFunc {
            name: f.name.clone(),
            params: f.params.len(),
            blocks: f.body.blocks.len(),
        })
        .collect();
    out.extend_from_slice(&encode_manifest(&manifest));

    Ok(out)
}

/// Manifest custom section encoding (id 0: name + count + per-function
/// name/arity/block count).
fn encode_manifest(funcs: &[CoreModuleFunc]) -> Vec<u8> {
    let mut payload = Vec::new();
    name_bytes(&mut payload, MANIFEST_SECTION_NAME);
    uleb32(&mut payload, funcs.len() as u32);
    for f in funcs {
        name_bytes(&mut payload, &f.name);
        uleb32(&mut payload, f.params as u32);
        uleb32(&mut payload, f.blocks as u32);
    }
    section(0x00, &payload)
}

/// Emit a single function body (locals declarations + region recursion +
/// the function block's `end`; `func_base` = the function index space base
/// offset — Call resolution shifts in sync).
fn emit_func_body(f: &AFuncDef, names: &[&str], func_base: u32) -> Result<Vec<u8>, CodegenError> {
    // Total locals = parameter count + body temp count (the ATemp number
    // is the local index — the anf.rs LowerCtxt numbering invariant:
    // parameters occupy 0..arity, fresh_temp allocates monotonically from
    // arity; scan all binding dsts and take max index + 1)
    let mut locals_total: u32 = f.params.len() as u32;
    for b in &f.body.blocks {
        for phi in &b.phis {
            locals_total = locals_total.max(phi.dst.0 + 1);
        }
        for s in &b.stmts {
            locals_total = locals_total.max(s.dst.0 + 1);
        }
    }

    let mut body = Vec::new();
    // locals declaration (everything beyond params is i64 — params come
    // with the function and are not redeclared)
    let extra = (locals_total as usize).saturating_sub(f.params.len());
    if extra > 0 {
        uleb32(&mut body, 1); // one group
        uleb32(&mut body, extra as u32);
        body.push(VALTYPE_I64);
    } else {
        uleb32(&mut body, 0);
    }

    let mut em = FuncEmitter {
        names,
        code: body,
        func_base,
    };
    let all_returned = em.emit_region(&f.body.blocks, 0, f.body.blocks.len(), ExitMode::Return)?;
    if !all_returned {
        // Reachable fall-through after a tail if consumed the region:
        // after both arms return, `end` resets reachability, so the i64
        // requirement of the function-level `end` needs an `unreachable`
        // bottom guard (control in fact never falls through — zero
        // semantic change, a validator-legal shape).
        em.code.push(OP_UNREACHABLE);
    }
    em.code.push(OP_END); // end of the function's implicit block (required by the format)
    Ok(em.code)
}

/// Region exit mode (the two region shapes of recursive decomposition).
enum ExitMode {
    /// The region terminates with `return` (function body / both arms of
    /// a tail if).
    Return,
    /// The region falls through with Jmp{merge} (a value-context if arm —
    /// the tail-value atom is left on the stack, merged by the enclosing
    /// `if (result i64)`).
    ValueArm { merge: u32, atom: AAtom },
}

/// Single-function emission context.
struct FuncEmitter<'a> {
    /// Full function name table (index = defined-function position — the
    /// Call resolution face).
    names: &'a [&'a str],
    /// Function index space base offset (M3 — the defined-function index
    /// offset when imported functions occupy the front).
    func_base: u32,
    code: Vec<u8>,
}

impl<'a> FuncEmitter<'a> {
    /// Evaluate an atom onto the stack (Int → i64.const; Var → local.get).
    fn atom(&mut self, a: AAtom) {
        match a {
            AAtom::Int(v) => {
                self.code.push(OP_I64_CONST);
                sleb64(&mut self.code, v);
            }
            AAtom::Var(t) => {
                self.code.push(OP_LOCAL_GET);
                uleb32(&mut self.code, t.0);
            }
        }
    }

    /// Emit a primitive (binary arithmetic/comparison + unary not — the
    /// comparison family extends back to i64).
    fn prim(&mut self, p: APrim, atoms: &[AAtom]) -> Result<(), CodegenError> {
        match p {
            APrim::Not => {
                if atoms.len() != 1 {
                    return Err(CodegenError::new(format!(
                        "WASM M1 emit failed: not primitive argument count {}(expected 1)",
                        atoms.len()
                    )));
                }
                self.atom(atoms[0]);
                self.code.push(OP_I64_EQZ); // i64 → i32 (1 if zero)
                self.code.push(OP_I64_EXTEND_I32_U); // → i64
            }
            _ => {
                if atoms.len() != 2 {
                    return Err(CodegenError::new(format!(
                        "WASM M1 emit failed: primitive {:?} argument count {}(expected 2)",
                        p,
                        atoms.len()
                    )));
                }
                self.atom(atoms[0]);
                self.atom(atoms[1]);
                let op = match p {
                    APrim::Add => OP_I64_ADD,
                    APrim::Sub => OP_I64_SUB,
                    APrim::Mul => OP_I64_MUL,
                    APrim::Div => OP_I64_DIV_S,
                    APrim::Mod => OP_I64_REM_S,
                    APrim::Eq => OP_I64_EQ,
                    APrim::Lt => OP_I64_LT_S,
                    APrim::Gt => OP_I64_GT_S,
                    APrim::Le => OP_I64_LE_S,
                    APrim::Ge => OP_I64_GE_S,
                    APrim::Not => unreachable!("Not already handled in the upper arm"),
                };
                self.code.push(op);
                if matches!(p, APrim::Eq | APrim::Lt | APrim::Gt | APrim::Le | APrim::Ge) {
                    self.code.push(OP_I64_EXTEND_I32_U);
                }
            }
        }
        Ok(())
    }

    /// Emit a binding statement (`dst = op(args)` → evaluate + local.set
    /// dst).
    fn stmt(&mut self, dst: ATemp, op: &AOp) -> Result<(), CodegenError> {
        match op {
            AOp::Prim(p, atoms) => self.prim(*p, atoms)?,
            AOp::Call { func, args } => {
                let idx = self
                    .names
                    .iter()
                    .position(|&n| n == func.as_str())
                    .ok_or_else(|| {
                        CodegenError::new(format!(
                            "WASM M1 emit failed: call goal `{}` not in function table",
                            func
                        ))
                    })?;
                for a in args {
                    self.atom(*a);
                }
                self.code.push(OP_CALL);
                uleb32(&mut self.code, self.func_base + idx as u32);
            }
        }
        self.code.push(OP_LOCAL_SET);
        uleb32(&mut self.code, dst.0);
        Ok(())
    }

    /// Emit a block's statement sequence (excluding the terminator).
    fn stmts_of(&mut self, b: &ABlock) -> Result<(), CodegenError> {
        for s in &b.stmts {
            self.stmt(s.dst, &s.op)?;
        }
        Ok(())
    }

    /// Evaluate a condition (i64 nonzero-is-true — full-width criterion:
    /// eqz + eqz double negation).
    fn cond(&mut self, t: ATemp) {
        self.code.push(OP_LOCAL_GET);
        uleb32(&mut self.code, t.0);
        self.code.push(OP_I64_EQZ);
        self.code.push(OP_I32_EQZ);
    }

    /// Recursive region emission (block range [start, end) — a
    /// well-nested if-diamond DAG).
    ///
    /// Return value: `true` = every path in the region terminates with
    /// `return` (validator-unreachable state); `false` = the region ends
    /// with a tail if's `if...end` (reachable fall-through — the function
    /// level needs an `unreachable` bottom guard; empty stacks inside the
    /// arms are self-consistent and need no guard).
    ///
    /// Invariants (empirically verified in anf.rs lowering — violations
    /// are fail-closed):
    /// - `Br.t == the block after the start block` (the then arm
    ///   immediately follows the Br block);
    /// - value diamond: the then arm's last block (f-1) and the else
    ///   arm's last block (merge-1) both Jmp to the same merge block; the
    ///   merge block has exactly one phi, with sources = the two arm-end
    ///   block labels;
    /// - tail if: both arms terminate with Ret; the else arm extends to
    ///   the region end (the BodyTail contract);
    /// - a Ret block is the last block of a Return-mode region; a Jmp
    ///   block is the last block of a ValueArm-mode region
    ///   (fall-through — no instruction emitted).
    fn emit_region(
        &mut self,
        blocks: &[ABlock],
        start: usize,
        end: usize,
        exit: ExitMode,
    ) -> Result<bool, CodegenError> {
        let mut i = start;
        while i < end {
            let b = &blocks[i];
            match &b.ctrl {
                ACtrl::Ret(a) => {
                    self.stmts_of(b)?;
                    self.atom(*a);
                    self.code.push(OP_RETURN);
                    if i + 1 != end {
                        return Err(CodegenError::new(format!(
                            "WASM M1 emit failed: block {} still has {} blocks after Ret (structural violation -- Ret should be the region's final block)",
                            i,
                            end - i - 1
                        )));
                    }
                    return Ok(true);
                }
                ACtrl::Jmp { target } => {
                    let ExitMode::ValueArm { merge, atom } = &exit else {
                        return Err(CodegenError::new(format!(
                            "WASM M1 emit failed: block {} Jmp appears in a Return-mode region (structural violation)",
                            i
                        )));
                    };
                    if target.0 as usize != *merge as usize || i + 1 != end {
                        return Err(CodegenError::new(format!(
                            "WASM M1 emit failed: block {} Jmp target {} ≠ expected merge {} or not the region's final block (structural violation)",
                            i, target.0, merge
                        )));
                    }
                    self.stmts_of(b)?;
                    self.atom(*atom);
                    return Ok(true); // fall-through (no instruction; enclosing if merges)
                }
                ACtrl::Br { cond, t, f } => {
                    self.stmts_of(b)?; // block statements first (incl. the cond binding)
                    if t.0 as usize != i + 1 {
                        return Err(CodegenError::new(format!(
                            "WASM M1 emit failed: block {} Br.then {} ≠ next block(structural violation)",
                            i, t.0
                        )));
                    }
                    let f_idx = f.0 as usize;
                    if f_idx <= i + 1 || f_idx > end {
                        return Err(CodegenError::new(format!(
                            "WASM M1 emit failed: block {} Br.else {} out of bounds (region [{}, {}))",
                            i, f_idx, start, end
                        )));
                    }
                    // Diamond test: the then arm's last block (f-1) is a Jmp → value-context if
                    let then_last = &blocks[f_idx - 1];
                    match &then_last.ctrl {
                        ACtrl::Jmp { target: merge_j } => {
                            let merge = merge_j.0 as usize;
                            if merge <= f_idx || merge > end {
                                return Err(CodegenError::new(format!(
                                    "WASM M1 emit failed: block {} diamond merge {} out of bounds",
                                    i, merge
                                )));
                            }
                            // the else arm's last block (merge-1) should be a Jmp to the same merge
                            match &blocks[merge - 1].ctrl {
                                ACtrl::Jmp { target: t2 } if t2.0 as usize == merge => {}
                                other => {
                                    return Err(CodegenError::new(format!(
                                        "WASM M1 emit failed: block {} else arm-end block termination {:?} non- Jmp→merge {}(structural violation)",
                                        i, other, merge
                                    )));
                                }
                            }
                            // the merge block has exactly one phi + both sources aligned
                            let merge_b = &blocks[merge];
                            if merge_b.phis.len() != 1 {
                                return Err(CodegenError::new(format!(
                                    "WASM M1 emit failed: merge block {} phi count {}(expected 1)",
                                    merge,
                                    merge_b.phis.len()
                                )));
                            }
                            let phi = &merge_b.phis[0];
                            let tv = source_atom(phi, f_idx - 1)?;
                            let ev = source_atom(phi, merge - 1)?;
                            // Emit: cond → if (result i64) then-arm else-arm end
                            self.cond(*cond);
                            self.code.push(OP_IF);
                            self.code.push(VALTYPE_I64);
                            self.emit_region(
                                blocks,
                                i + 1,
                                f_idx,
                                ExitMode::ValueArm {
                                    merge: merge as u32,
                                    atom: tv,
                                },
                            )?;
                            self.code.push(OP_ELSE);
                            self.emit_region(
                                blocks,
                                f_idx,
                                merge,
                                ExitMode::ValueArm {
                                    merge: merge as u32,
                                    atom: ev,
                                },
                            )?;
                            self.code.push(OP_END);
                            self.code.push(OP_LOCAL_SET);
                            uleb32(&mut self.code, phi.dst.0);
                            i = merge; // the merge block continues the outer region sequence
                        }
                        ACtrl::Ret(_) => {
                            // Tail if: both arms are all Ret; the else arm extends to
                            // the region end. Value-arm domain guard: a Br inside a
                            // value-context arm is always diamond-shaped (empirically
                            // verified in lowering — Value context has no BodyTail) — a
                            // tail-shaped Br here is a structural violation
                            // (fail-closed).
                            if matches!(exit, ExitMode::ValueArm { .. }) {
                                return Err(CodegenError::new(format!(
                                    "WASM M1 emit failed: block {} tail if appears in a value-arm region (structural violation -- value arms must terminate with Jmp)",
                                    i
                                )));
                            }
                            // Emit: cond → if (void) then-arm else-arm end
                            self.cond(*cond);
                            self.code.push(OP_IF);
                            self.code.push(BLOCKTYPE_VOID);
                            self.emit_region(blocks, i + 1, f_idx, ExitMode::Return)?;
                            self.code.push(OP_ELSE);
                            self.emit_region(blocks, f_idx, end, ExitMode::Return)?;
                            self.code.push(OP_END);
                            return Ok(false); // tail if consumed rest (fall-through)
                        }
                        other => {
                            return Err(CodegenError::new(format!(
                                "WASM M1 emit failed: block {} then arm-end block termination {:?}(expected Jmp or Ret)",
                                i, other
                            )));
                        }
                    }
                }
            }
        }
        // Region naturally exhausted: Return mode must already have
        // returned (the Ret arm above returns directly); the only legal
        // shape reaching here = ValueArm fall-through already returned in
        // its arms. Reaching here = an empty region or a Return-mode
        // region missing a Ret — fail-closed.
        match exit {
            ExitMode::ValueArm { .. } => Ok(true), // empty arms unreachable (never produced)
            ExitMode::Return => Err(CodegenError::new(format!(
                "WASM M1 emit failed: region [{}, {}) Return mode without Ret termination (structural violation)",
                start, end
            ))),
        }
    }
}

/// Extract the phi source atom by label (fail-closed: a missing source =
/// structural violation).
fn source_atom(phi: &APhi, label: usize) -> Result<AAtom, CodegenError> {
    phi.sources
        .iter()
        .find(|(l, _)| l.0 as usize == label)
        .map(|(_, a)| *a)
        .ok_or_else(|| {
            CodegenError::new(format!(
                "WASM M1 emit failed: phi dst{} missing source label {}",
                phi.dst.0, label
            ))
        })
}

// ---------------------------------------------------------------------------
// M2: canonical ABI boundary module emission (CanonicalAbiOptions
// consumption — cross-boundary string data segment + realloc bump protocol
// + memory64 address domain)
// ---------------------------------------------------------------------------

/// M2 supplementary instruction opcodes (i32/i64 dual address domains —
/// selected by [`AddressWidth`]).
const OP_BLOCK: u8 = 0x02;
const OP_LOOP: u8 = 0x03;
const OP_BR: u8 = 0x0c;
const OP_BR_IF: u8 = 0x0d;
const OP_GLOBAL_GET: u8 = 0x23;
const OP_GLOBAL_SET: u8 = 0x24;
const OP_I32_CONST: u8 = 0x41;
const OP_I32_ADD: u8 = 0x6a;
const OP_I32_SUB: u8 = 0x6b;
const OP_I32_AND: u8 = 0x71;
const OP_I32_SHL: u8 = 0x74;
const OP_I32_GE_U: u8 = 0x4f;
const OP_I32_LOAD8_U: u8 = 0x2d;
const OP_I32_STORE8: u8 = 0x3a;
const OP_I64_AND: u8 = 0x83;
const OP_I64_SHL: u8 = 0x86;
const OP_I64_GE_U: u8 = 0x5a;
const OP_I64_LOAD8_U: u8 = 0x31;
const OP_I64_STORE8: u8 = 0x37;
const VALTYPE_I32: u8 = 0x7f;

/// Address-domain value type byte (i32 = 0x7f / i64 = 0x7e — single-source
/// selection).
fn addr_valtype(wide: bool) -> u8 {
    if wide {
        VALTYPE_I64
    } else {
        VALTYPE_I32
    }
}

/// Emit the canonical ABI boundary module (M2 — the `CanonicalAbiOptions`
/// consumption face).
///
/// **Artifact structure** (section order = Type[1] → Function[3] →
/// Memory[5] → Global[6] → Export[7] → Code[10] → Data[11]; when
/// `realloc = None` the four sections Type/Function/Global/Code are
/// omitted — the honest fulfillment of the "crosses no boundary types that
/// require allocation" contract semantics; the Data section is omitted
/// when `data` is empty):
/// - **Memory section**: linear memory (min pages = data + one page of
///   heap headroom; `memory64` = limits flag bit 0x04 + the i64 address
///   domain) + export `memory`;
/// - **Data section**: an active segment (`data` bytes statically placed
///   at offset 0 — the host reads them back via `exports.memory.buffer`,
///   i.e. the cross-boundary payload face of str-encoded bytes);
/// - **Global section**: heap pointer (`heap_base = align_up(max(len, 1),
///   8)` — address 0 is reserved as realloc's null sentinel);
/// - **Code section**: the `canonical realloc` bump function (signature
///   `(addr, addr, addr, addr) → addr` — the `(old_ptr, old_size,
///   align, new_size) → new_ptr` protocol; alignment rounded up to
///   `1 << align` + old data preserved byte-by-byte + heap advances
///   monotonically; export name = `abi.realloc` or
///   [`CANONICAL_REALLOC_DEFAULT_NAME`]).
///
/// **M2 honest boundary (PoC ruling registry)**:
/// - the bump allocator **does not do `memory.grow`** — when the initial
///   headroom (one page) is exhausted it traps out of bounds
///   (fail-closed, not silent degradation); `memory.grow` integration is
///   deferred to a later consumption signal;
/// - realloc'd old blocks are **not reclaimed** (bump is monotonic —
///   allocate + preserve semantics, no free protocol; the
///   component-model context is handed to the host's GC domain);
/// - `memory64` modules are verified via byte-level assertions (node host
///   support for instantiating memory64 is version-dependent — E2E runs
///   the wasm32 domain, L-C′ ruling).
///
/// **Determinism**: same (data, abi) → same bytes (fully structurally
/// ordered; no hash iteration order enters the artifact).
pub fn emit_abi_module(data: &[u8], abi: &CanonicalAbiOptions) -> Result<Vec<u8>, CodegenError> {
    // Data segment length field = u32 LEB128 (> 4 GiB out of range —
    // fail-closed)
    if data.len() > u32::MAX as usize {
        return Err(CodegenError::new(format!(
            "WASM M2 emit failed: data segment {} byte out of bounds(u32 length domain limit {})",
            data.len(),
            u32::MAX
        )));
    }
    let wide = abi.memory64;
    let has_realloc = abi.realloc.is_some();
    // Heap base: max(len, 1) aligned up to 8 (address 0 = null sentinel
    // reserved)
    let heap_base = crate::wasm::abi::align_up(data.len().max(1) as u64, 8);
    // Minimum page count: data + one page of heap headroom (at least 1
    // page)
    let min_pages = crate::wasm::abi::pages_for(heap_base as usize) + 1;

    let mut out = Vec::with_capacity(data.len() + 160);
    out.extend_from_slice(&HEADER);

    if has_realloc {
        // ---- Type section (realloc signature: (addr × 4) → addr) ----
        let mut ty = Vec::new();
        uleb32(&mut ty, 1);
        ty.push(0x60); // functype
        uleb32(&mut ty, 4);
        let vt = addr_valtype(wide);
        ty.extend(std::iter::repeat_n(vt, 4));
        uleb32(&mut ty, 1);
        ty.push(vt);
        out.extend_from_slice(&section(0x01, &ty));

        // ---- Function section (1 function — realloc) ----
        let mut fns = Vec::new();
        uleb32(&mut fns, 1);
        uleb32(&mut fns, 0); // typeidx 0
        out.extend_from_slice(&section(0x03, &fns));
    }

    // ---- Memory section (min pages — memory64 = flags 0x04) ----
    let mut mem = Vec::new();
    uleb32(&mut mem, 1); // count
    mem.push(if wide { 0x04 } else { 0x00 }); // limits flags (bit 2 = 64-bit)
    uleb32(&mut mem, min_pages); // min pages (LEB128 self-encoded — u64-domain isomorphic)
    out.extend_from_slice(&section(0x05, &mem));

    if has_realloc {
        // ---- Global section (heap pointer — mut + init = heap_base) ----
        let vt = addr_valtype(wide);
        let mut glob = Vec::new();
        uleb32(&mut glob, 1);
        glob.push(vt);
        glob.push(0x01); // mutable
        if wide {
            glob.push(OP_I64_CONST);
        } else {
            glob.push(OP_I32_CONST);
        }
        sleb64(&mut glob, heap_base as i64);
        glob.push(OP_END);
        out.extend_from_slice(&section(0x06, &glob));
    }

    // ---- Export section (memory + realloc function [if present]) ----
    let mut ex = Vec::new();
    uleb32(&mut ex, if has_realloc { 2 } else { 1 });
    name_bytes(&mut ex, "memory");
    ex.push(0x02); // kind = memory
    uleb32(&mut ex, 0);
    if has_realloc {
        let realloc_name = abi
            .clone()
            .realloc
            .unwrap_or_else(|| crate::wasm::abi::CANONICAL_REALLOC_DEFAULT_NAME.to_string());
        name_bytes(&mut ex, &realloc_name);
        ex.push(0x00); // kind = func
        uleb32(&mut ex, 0);
    }
    out.extend_from_slice(&section(0x07, &ex));

    if has_realloc {
        // ---- Code section (the realloc bump function body) ----
        let body = emit_realloc_body(wide);
        let mut code = Vec::new();
        uleb32(&mut code, 1);
        uleb32(&mut code, body.len() as u32);
        code.extend_from_slice(&body);
        out.extend_from_slice(&section(0x0a, &code));
    }

    // ---- Data section (active segment — static bytes at offset 0;
    // omitted for empty data) ----
    if !data.is_empty() {
        let mut d = Vec::new();
        uleb32(&mut d, 1); // count
        d.push(0x00); // flags: active + memidx 0 (implicit)
        if wide {
            d.push(OP_I64_CONST);
        } else {
            d.push(OP_I32_CONST);
        }
        sleb64(&mut d, 0);
        d.push(OP_END);
        uleb32(&mut d, data.len() as u32);
        d.extend_from_slice(data);
        out.extend_from_slice(&section(0x0b, &d));
    }

    Ok(out)
}

/// Emit the realloc bump function body (single source for the i32/i64 dual
/// address domains — opcodes selected by width).
///
/// Parameters idx 0-3 = (old_ptr, old_size, align, new_size); locals
/// idx 4 = `$np` (new pointer), idx 5 = `$i` (loop counter / alignment
/// temporary). See the [`emit_abi_module`] docs for the instruction
/// sequence (block/loop copy loop + heap advance + return).
fn emit_realloc_body(wide: bool) -> Vec<u8> {
    let mut c: Vec<u8> = Vec::with_capacity(80);
    // locals declaration: one group × 2 address-domain temporaries ($np,
    // $i — beyond the parameters)
    uleb32(&mut c, 1);
    uleb32(&mut c, 2);
    c.push(addr_valtype(wide));

    // Dual-domain opcode selection helper (narrow = i32 / wide = i64).
    let op = |narrow: u8, w: u8| {
        if wide {
            w
        } else {
            narrow
        }
    };
    let iconst = |c: &mut Vec<u8>, v: i64| {
        c.push(op(OP_I32_CONST, OP_I64_CONST));
        sleb64(c, v);
    };
    let lget = |c: &mut Vec<u8>, i: u32| {
        c.push(OP_LOCAL_GET);
        uleb32(c, i);
    };
    let lset = |c: &mut Vec<u8>, i: u32| {
        c.push(OP_LOCAL_SET);
        uleb32(c, i);
    };
    let gget = |c: &mut Vec<u8>| {
        c.push(OP_GLOBAL_GET);
        uleb32(c, 0);
    };
    let gset = |c: &mut Vec<u8>| {
        c.push(OP_GLOBAL_SET);
        uleb32(c, 0);
    };

    // $i = 1 << align (alignment byte table — the canonical ABI align
    // parameter is log2)
    iconst(&mut c, 1);
    lget(&mut c, 2);
    c.push(op(OP_I32_SHL, OP_I64_SHL));
    lset(&mut c, 5);

    // $np = (heap + a - 1) & -a (align up; -a = 0 - a two's complement —
    // avoids negative constants)
    gget(&mut c);
    lget(&mut c, 5);
    c.push(op(OP_I32_ADD, OP_I64_ADD));
    iconst(&mut c, 1);
    c.push(op(OP_I32_SUB, OP_I64_SUB)); // t = heap + a - 1
    iconst(&mut c, 0);
    lget(&mut c, 5);
    c.push(op(OP_I32_SUB, OP_I64_SUB)); // m = -a
    c.push(op(OP_I32_AND, OP_I64_AND)); // aligned = t & m
    lset(&mut c, 4);

    // Old data copy (old_ptr ≠ 0 and old_size ≠ 0 — byte-by-byte
    // preservation semantics)
    c.push(OP_BLOCK);
    c.push(BLOCKTYPE_VOID);
    lget(&mut c, 0);
    c.push(op(OP_I32_EQZ, OP_I64_EQZ));
    c.push(OP_BR_IF);
    uleb32(&mut c, 0);
    lget(&mut c, 1);
    c.push(op(OP_I32_EQZ, OP_I64_EQZ));
    c.push(OP_BR_IF);
    uleb32(&mut c, 0);
    iconst(&mut c, 0);
    lset(&mut c, 5); // $i = 0
    c.push(OP_BLOCK);
    c.push(BLOCKTYPE_VOID);
    c.push(OP_LOOP);
    c.push(BLOCKTYPE_VOID);
    lget(&mut c, 5);
    lget(&mut c, 1);
    c.push(op(OP_I32_GE_U, OP_I64_GE_U)); // $i >= old_size (unsigned)
    c.push(OP_BR_IF);
    uleb32(&mut c, 1); // → exits the done block
                       // mem[$np + $i] = mem[old_ptr + $i]
    lget(&mut c, 4);
    lget(&mut c, 5);
    c.push(op(OP_I32_ADD, OP_I64_ADD)); // dst address
    lget(&mut c, 0);
    lget(&mut c, 5);
    c.push(op(OP_I32_ADD, OP_I64_ADD)); // src address
    c.push(op(OP_I32_LOAD8_U, OP_I64_LOAD8_U));
    uleb32(&mut c, 0); // align = 0 (1-byte access)
    uleb32(&mut c, 0); // offset = 0
    c.push(op(OP_I32_STORE8, OP_I64_STORE8));
    uleb32(&mut c, 0);
    uleb32(&mut c, 0);
    // $i += 1
    lget(&mut c, 5);
    iconst(&mut c, 1);
    c.push(op(OP_I32_ADD, OP_I64_ADD));
    lset(&mut c, 5);
    c.push(OP_BR);
    uleb32(&mut c, 0); // → loop start
    c.push(OP_END); // end loop
    c.push(OP_END); // end done block
    c.push(OP_END); // end skip block

    // heap = $np + new_size (bump advances monotonically)
    lget(&mut c, 4);
    lget(&mut c, 3);
    c.push(op(OP_I32_ADD, OP_I64_ADD));
    gset(&mut c);

    // Return $np (the function result — implicit return)
    lget(&mut c, 4);
    c.push(OP_END); // end func
    c
}

// ---------------------------------------------------------------------------
// The first materialized WasmBackend implementation (M1 — honoring the
// WasmComponent.bytes payload)
// ---------------------------------------------------------------------------

/// WASM core module backend (M1 materialized implementation).
///
/// `compile_component` → `WasmComponent { bytes: <core module binary>,
/// model: <M0 derived manifest> }` — the `bytes` field semantics from the
/// r74 contract comments ("the payload of M1 bytecode generation") are
/// honored as a real core module; `model` stays the unchanged M0
/// derivation (Principle 27 additive evolution — zero trait signature
/// change). The space-affiliation three-layer marker is in the
/// space-affiliation declaration section of lib.rs (24 §7.2 single-source
/// discipline).
pub struct WasmCoreBackend;

impl WasmBackend for WasmCoreBackend {
    fn compile_component(&self, ir: &AnnotatedANF) -> Result<WasmComponent, CodegenError> {
        let bytes = emit_core_module(ir)?;
        Ok(WasmComponent {
            bytes,
            model: component_model_from_anf(ir),
        })
    }
}

// ---------------------------------------------------------------------------
// Manifest read-back (emit/parse reconciliation anchor — single source on
// both sides of the custom section)
// ---------------------------------------------------------------------------

/// Read back a core wasm module's `kerf_meta` manifest (structural walk:
/// magic/version + section id sequence + custom section payload decode).
///
/// **Reconciliation anchor**: the product of
/// `parse_core_module_manifest(&emit_core_module(ir))` should equal
/// `component_model_from_anf(ir).core_funcs` (bidirectional parity
/// between the emitter ↔ the contract layer — the manifest section's
/// content-addressing closed loop).
pub fn parse_core_module_manifest(bytes: &[u8]) -> Result<Vec<CoreModuleFunc>, CodegenError> {
    if bytes.len() < 8 || bytes[..8] != HEADER {
        return Err(CodegenError::new(
            "WASM read-back failed: magic/version head mismatch",
        ));
    }
    let mut funcs: Option<Vec<CoreModuleFunc>> = None;
    let mut pos = 8usize;
    while pos < bytes.len() {
        if pos + 2 > bytes.len() {
            return Err(CodegenError::new(
                "WASM read-back failed: section head truncation",
            ));
        }
        let id = bytes[pos];
        pos += 1;
        let (size, adv) = read_uleb32(&bytes[pos..])?;
        pos += adv;
        let end = pos
            .checked_add(size as usize)
            .ok_or_else(|| CodegenError::new("WASM read-back failed: section length overflow"))?;
        if end > bytes.len() {
            return Err(CodegenError::new(
                "WASM read-back failed: section payload out of bounds",
            ));
        }
        if id == 0x00 {
            let name = read_name(&bytes[pos..end])?;
            if name == MANIFEST_SECTION_NAME {
                let mut p = pos + uleb_len(name.len() as u32) + name.len();
                let (count, adv) = read_uleb32(&bytes[p..end])?;
                p += adv;
                let mut out = Vec::with_capacity(count as usize);
                for _ in 0..count {
                    let fname = read_name(&bytes[p..end])?;
                    p += uleb_len(fname.len() as u32) + fname.len();
                    let (params, a) = read_uleb32(&bytes[p..end])?;
                    p += a;
                    let (blocks, a) = read_uleb32(&bytes[p..end])?;
                    p += a;
                    out.push(CoreModuleFunc {
                        name: fname,
                        params: params as usize,
                        blocks: blocks as usize,
                    });
                }
                funcs = Some(out);
            }
        }
        pos = end;
    }
    funcs.ok_or_else(|| {
        CodegenError::new("WASM read-back failed: kerf_meta custom section not found (emit-face/read-back-face single-source break)")
    })
}

/// Read an unsigned LEB128 (returns value + bytes consumed).
fn read_uleb32(b: &[u8]) -> Result<(u32, usize), CodegenError> {
    let mut v: u32 = 0;
    let mut shift = 0u32;
    for (i, &byte) in b.iter().enumerate() {
        if shift >= 32 {
            return Err(CodegenError::new("WASM read-back failed: uleb32 overflow"));
        }
        v |= ((byte & 0x7f) as u32) << shift;
        if byte & 0x80 == 0 {
            return Ok((v, i + 1));
        }
        shift += 7;
    }
    Err(CodegenError::new(
        "WASM read-back failed: uleb32 truncation",
    ))
}

/// Byte count needed to uleb-encode a value (unambiguous form: minimal
/// encoding).
fn uleb_len(v: u32) -> usize {
    let mut n = 1;
    let mut v = v >> 7;
    while v != 0 {
        n += 1;
        v >>= 7;
    }
    n
}

/// Read a name (len-prefixed UTF-8).
fn read_name(b: &[u8]) -> Result<String, CodegenError> {
    let (len, adv) = read_uleb32(b)?;
    let end = adv
        .checked_add(len as usize)
        .ok_or_else(|| CodegenError::new("WASM read-back failed: name length overflow"))?;
    if end > b.len() {
        return Err(CodegenError::new(
            "WASM read-back failed: name payload truncation",
        ));
    }
    String::from_utf8(b[adv..end].to_vec())
        .map_err(|_| CodegenError::new("WASM read-back failed: name non- UTF-8"))
}

// ---------------------------------------------------------------------------
// Unit tests (encoding infrastructure golden vectors + emission
// invariants)
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn uleb32_golden_vectors() {
        let cases: &[(u32, &[u8])] = &[
            (0, &[0x00]),
            (1, &[0x01]),
            (127, &[0x7f]),
            (128, &[0x80, 0x01]),
            (624485, &[0xe5, 0x8e, 0x26]),
        ];
        for (v, want) in cases {
            let mut out = Vec::new();
            uleb32(&mut out, *v);
            assert_eq!(&out, want, "uleb32({})", v);
        }
    }

    #[test]
    fn sleb64_golden_vectors() {
        let cases: &[(i64, &[u8])] = &[
            (0, &[0x00]),
            (1, &[0x01]),
            (-1, &[0x7f]),
            (63, &[0x3f]),
            (64, &[0xc0, 0x00]),
            (-64, &[0x40]),
            (-65, &[0xbf, 0x7f]),
            (-123456, &[0xc0, 0xbb, 0x78]),
            (
                i64::MIN,
                &[0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x7f],
            ),
            (
                i64::MAX,
                &[0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x00],
            ), // canonical form 10 bytes (final byte clarifies the sign)
            (4294967296, &[0x80, 0x80, 0x80, 0x80, 0x10]), // 2^32 (truthiness corpus anchor)
        ];
        for (v, want) in cases {
            let mut out = Vec::new();
            sleb64(&mut out, *v);
            assert_eq!(&out, want, "sleb64({})", v);
        }
    }

    #[test]
    fn empty_module_is_header_plus_manifest_only() {
        // Empty IR → magic + version + kerf_meta (0-function manifest)
        let bytes = emit_core_module(&AnnotatedANF::default()).unwrap();
        assert_eq!(&bytes[..8], &HEADER);
        let m = parse_core_module_manifest(&bytes).unwrap();
        assert!(m.is_empty());
    }

    #[test]
    fn constant_main_module_golden_bytes() {
        // `(5)` → main Ret(Int(5)): full-module golden bytes (byte-by-byte
        // anchor)
        let ir = AnnotatedANF {
            funcs: vec![AFuncDef {
                name: "main".into(),
                params: vec![],
                body: crate::anf::ABody {
                    blocks: vec![ABlock {
                        phis: vec![],
                        stmts: vec![],
                        ctrl: ACtrl::Ret(AAtom::Int(5)),
                    }],
                },
            }],
            fingerprint: 0,
        };
        let bytes = emit_core_module(&ir).unwrap();
        let mut want: Vec<u8> = Vec::new();
        want.extend_from_slice(&HEADER);
        // Type: () → i64
        want.extend_from_slice(&[0x01, 0x05, 0x01, 0x60, 0x00, 0x01, 0x7e]);
        // Function: typeidx 0
        want.extend_from_slice(&[0x03, 0x02, 0x01, 0x00]);
        // Export: "main" func 0
        want.extend_from_slice(&[0x07, 0x08, 0x01, 0x04, b'm', b'a', b'i', b'n', 0x00, 0x00]);
        // Code: body = locals 0 + i64.const 5 + return + end
        want.extend_from_slice(&[0x0a, 0x07, 0x01, 0x05, 0x00, 0x42, 0x05, 0x0f, 0x0b]);
        // Custom kerf_meta: main/0 params/1 block (name 9 chars — payload
        // 1+9+8 = 18)
        want.extend_from_slice(&[
            0x00, 0x12, 0x09, b'k', b'e', b'r', b'f', b'_', b'm', b'e', b't', b'a', 0x01, 0x04,
            b'm', b'a', b'i', b'n', 0x00, 0x01,
        ]);
        assert_eq!(
            bytes, want,
            "whole-module golden bytes (hex: {:02x?})",
            bytes
        );
    }

    #[test]
    fn determinism_and_content_sensitivity() {
        let mk = |v: i64| AnnotatedANF {
            funcs: vec![AFuncDef {
                name: "main".into(),
                params: vec![],
                body: crate::anf::ABody {
                    blocks: vec![ABlock {
                        phis: vec![],
                        stmts: vec![],
                        ctrl: ACtrl::Ret(AAtom::Int(v)),
                    }],
                },
            }],
            fingerprint: 0,
        };
        let a1 = emit_core_module(&mk(5)).unwrap();
        let a2 = emit_core_module(&mk(5)).unwrap();
        assert_eq!(a1, a2, "same IR same bytes (deterministic)");
        let b1 = emit_core_module(&mk(6)).unwrap();
        assert_ne!(
            a1, b1,
            "value change → bytes change (content-address sensitivity)"
        );
    }

    #[test]
    fn duplicate_function_names_fail_closed() {
        let ir = AnnotatedANF {
            funcs: vec![
                AFuncDef {
                    name: "f".into(),
                    params: vec![],
                    body: Default::default(),
                },
                AFuncDef {
                    name: "f".into(),
                    params: vec![],
                    body: Default::default(),
                },
            ],
            fingerprint: 0,
        };
        let err = emit_core_module(&ir).unwrap_err();
        assert!(
            err.reason.contains("duplicate"),
            "error face: {}",
            err.reason
        );
    }

    #[test]
    fn structural_violations_fail_closed() {
        // Br.then is not the next block
        let bad_then = AnnotatedANF {
            funcs: vec![AFuncDef {
                name: "main".into(),
                params: vec![],
                body: crate::anf::ABody {
                    blocks: vec![ABlock {
                        phis: vec![],
                        stmts: vec![],
                        ctrl: ACtrl::Br {
                            cond: ATemp(0),
                            t: crate::anf::ALabel(2),
                            f: crate::anf::ALabel(1),
                        },
                    }],
                },
            }],
            fingerprint: 0,
        };
        assert!(emit_core_module(&bad_then).is_err());
        // Return-mode region without a Ret (a Jmp appears in the function
        // body region)
        let bad_jmp = AnnotatedANF {
            funcs: vec![AFuncDef {
                name: "main".into(),
                params: vec![],
                body: crate::anf::ABody {
                    blocks: vec![ABlock {
                        phis: vec![],
                        stmts: vec![],
                        ctrl: ACtrl::Jmp {
                            target: crate::anf::ALabel(1),
                        },
                    }],
                },
            }],
            fingerprint: 0,
        };
        assert!(emit_core_module(&bad_jmp).is_err());
    }

    #[test]
    fn compile_component_carries_bytes_and_model() {
        // First trait implementation: bytes = emission payload + model =
        // M0 derivation (fingerprint chain)
        let ir = AnnotatedANF {
            funcs: vec![AFuncDef {
                name: "main".into(),
                params: vec![],
                body: crate::anf::ABody {
                    blocks: vec![ABlock {
                        phis: vec![],
                        stmts: vec![],
                        ctrl: ACtrl::Ret(AAtom::Int(1)),
                    }],
                },
            }],
            fingerprint: 42,
        };
        let c = WasmCoreBackend.compile_component(&ir).unwrap();
        assert_eq!(c.bytes, emit_core_module(&ir).unwrap());
        assert_eq!(c.model.source_fingerprint, 42);
        assert_eq!(c.model.core_funcs.len(), 1);
        // Manifest read-back reconciliation (emitter ↔ contract layer
        // bidirectional parity)
        assert_eq!(
            parse_core_module_manifest(&c.bytes).unwrap(),
            c.model.core_funcs
        );
    }

    // -----------------------------------------------------------------------
    // M3: linked emission unit tests (Import section structure / index
    // offsets / plain equivalence / face validation)
    // -----------------------------------------------------------------------

    /// Linked emission baseline face (wasm32 domain + default realloc name).
    fn linked_face32() -> CoreImportFace {
        CoreImportFace {
            module: "kerf_abi".into(),
            memory: Some(ImportMemorySpec {
                min_pages: 2,
                memory64: false,
            }),
            realloc: Some(ImportFuncSpec {
                name: "canonical_abi_realloc".into(),
                wide: false,
            }),
        }
    }

    /// Section walk (id sequence + payload range — structural assertion
    /// infrastructure; isomorphic to wasm_abi_tests).
    fn secs(bytes: &[u8]) -> Vec<(u8, usize, usize)> {
        assert!(bytes.len() >= 8 && bytes[..8] == HEADER);
        let mut out = Vec::new();
        let mut pos = 8usize;
        while pos < bytes.len() {
            let id = bytes[pos];
            pos += 1;
            let (size, adv) = read_uleb32(&bytes[pos..]).unwrap();
            pos += adv;
            out.push((id, pos, pos + size as usize));
            pos += size as usize;
        }
        out
    }

    /// Linked emission section order + Import section structure (two-level
    /// names / kinds / limits / typeidx).
    #[test]
    fn linked_module_import_section_structure() {
        let ir = AnnotatedANF {
            funcs: vec![AFuncDef {
                name: "main".into(),
                params: vec![],
                body: crate::anf::ABody {
                    blocks: vec![ABlock {
                        phis: vec![],
                        stmts: vec![],
                        ctrl: ACtrl::Ret(AAtom::Int(5)),
                    }],
                },
            }],
            fingerprint: 0,
        };
        let bytes = emit_core_module_linked(&ir, &linked_face32()).unwrap();
        let s = secs(&bytes);
        let ids: Vec<u8> = s.iter().map(|(id, _, _)| *id).collect();
        assert_eq!(
            ids,
            vec![0x01, 0x02, 0x03, 0x07, 0x0a, 0x00],
            "node order: Type/Import/Function/Export/Code/kerf_meta"
        );
        // Import section: count 2 (memory + realloc — memory first)
        let (_, is, ie) = *s.iter().find(|(id, _, _)| *id == 0x02).unwrap();
        let mut p = is;
        assert_eq!(bytes[p], 2, "import count = 2");
        p += 1;
        // Import 1: module "kerf_abi" + field "memory" + kind 0x02 + flags
        // 0x00 + min 2
        assert_eq!(&bytes[p + 1..p + 9], b"kerf_abi", "provider instance name");
        p += 1 + 8;
        assert_eq!(&bytes[p + 1..p + 7], b"memory", "memory field name");
        p += 1 + 6;
        assert_eq!(bytes[p], 0x02, "import kind = memory");
        assert_eq!(bytes[p + 1], 0x00, "limits flags = wasm32");
        assert_eq!(bytes[p + 2], 2, "min page = 2");
        p += 3;
        // Import 2: module "kerf_abi" + field realloc name + kind 0x00 +
        // typeidx
        assert_eq!(&bytes[p + 1..p + 9], b"kerf_abi");
        p += 1 + 8;
        let name_len = 21; // "canonical_abi_realloc"
        assert_eq!(
            &bytes[p + 1..p + 1 + name_len],
            b"canonical_abi_realloc".as_slice()
        );
        p += 1 + name_len;
        assert_eq!(bytes[p], 0x00, "import kind = func");
        let (typeidx, adv) = read_uleb32(&bytes[p + 1..ie]).unwrap();
        p += 1 + adv;
        assert_eq!(p, ie, "Import payload fully consumed");
        // Type section: main signature (arity 0) + realloc signature
        // ((i32×4)→i32)
        let (_, ts, _) = *s.iter().find(|(id, _, _)| *id == 0x01).unwrap();
        assert_eq!(
            bytes[ts], 2,
            "type count = 2(function + realloc address domain signature)"
        );
        assert_eq!(
            &bytes[ts + 1 + 4..ts + 1 + 4 + 8],
            &[0x60, 0x04, 0x7f, 0x7f, 0x7f, 0x7f, 0x01, 0x7f],
            "realloc signature(wasm32): (i32 × 4) → i32"
        );
        assert_eq!(
            typeidx, 1,
            "realloc import references an independent type entry"
        );
        // Export section: main = function index 1 (the imported function
        // occupies index 0 — base offset)
        let (_, es, _) = *s.iter().find(|(id, _, _)| *id == 0x07).unwrap();
        assert_eq!(&bytes[es + 2..es + 6], b"main");
        assert_eq!(bytes[es + 6], 0x00, "export kind = func");
        assert_eq!(bytes[es + 7], 1, "main index = func_base(1) + 0");
    }

    /// Index base offset: the Call references and the Export of a
    /// two-function IR shift in sync.
    #[test]
    fn linked_module_function_index_shift() {
        // main calls f: main = definition order 0 (actual index 1),
        // f = definition order 1 (actual index 2)
        let ir = AnnotatedANF {
            funcs: vec![
                AFuncDef {
                    name: "main".into(),
                    params: vec![],
                    body: crate::anf::ABody {
                        blocks: vec![ABlock {
                            phis: vec![],
                            stmts: vec![crate::anf::AStmt {
                                dst: ATemp(0),
                                op: AOp::Call {
                                    func: "f".into(),
                                    args: vec![AAtom::Int(5)],
                                },
                                span: kerf_span::Span::default(),
                            }],
                            ctrl: ACtrl::Ret(AAtom::Var(ATemp(0))),
                        }],
                    },
                },
                AFuncDef {
                    name: "f".into(),
                    params: vec![ATemp(0)],
                    body: crate::anf::ABody {
                        blocks: vec![ABlock {
                            phis: vec![],
                            stmts: vec![],
                            ctrl: ACtrl::Ret(AAtom::Int(42)),
                        }],
                    },
                },
            ],
            fingerprint: 0,
        };
        let bytes = emit_core_module_linked(&ir, &linked_face32()).unwrap();
        let s = secs(&bytes);
        // Type section: arity 0 + arity 1 + realloc(i32) = 3 entries
        let (_, ts, _) = *s.iter().find(|(id, _, _)| *id == 0x01).unwrap();
        assert_eq!(bytes[ts], 3, "type count = 3");
        // Export: main = 1
        let (_, es, _) = *s.iter().find(|(id, _, _)| *id == 0x07).unwrap();
        assert_eq!(
            bytes[es + 7],
            1,
            "main export index = 1 (after base offset)"
        );
        // Code: main's body contains call 2 (f definition order 1 + base
        // offset 1) — locals declaration + instruction sequence anchor
        let (_, cs, _) = *s.iter().find(|(id, _, _)| *id == 0x0a).unwrap();
        let body_start = cs + 2; // count(1) + body size(1)
        let body = &bytes[body_start..body_start + 13];
        // locals [one group × 1 i64] + i64.const 5 + call 2 + local.set 0
        // + local.get 0 + return + end
        let want = [
            0x01u8,
            0x01,
            VALTYPE_I64,
            OP_I64_CONST,
            0x05,
            OP_CALL,
            0x02,
            OP_LOCAL_SET,
            0x00,
            OP_LOCAL_GET,
            0x00,
            OP_RETURN,
            OP_END,
        ];
        assert_eq!(
            body,
            want.as_slice(),
            "Call reference = func_base(1) + definition order (1) = 2 (base offset synchronized)"
        );
    }

    /// Plain equivalence: empty-face linked emission ≡ plain emission
    /// (byte-identical — zero M1 semantic regression).
    #[test]
    fn linked_none_face_equals_plain_emission() {
        let ir = AnnotatedANF {
            funcs: vec![AFuncDef {
                name: "main".into(),
                params: vec![],
                body: crate::anf::ABody {
                    blocks: vec![ABlock {
                        phis: vec![],
                        stmts: vec![],
                        ctrl: ACtrl::Ret(AAtom::Int(7)),
                    }],
                },
            }],
            fingerprint: 0,
        };
        let plain = emit_core_module(&ir).unwrap();
        let linked = emit_core_module_linked(&ir, &CoreImportFace::none()).unwrap();
        assert_eq!(
            plain, linked,
            "empty face = plain verbatim section equivalent"
        );
    }

    /// Face validation fail-closed: missing instance name / empty realloc
    /// field name / empty function manifest + non-empty face.
    #[test]
    fn linked_face_validation_fail_closed() {
        let ir = AnnotatedANF::default();
        let err = emit_core_module_linked(&ir, &linked_face32()).unwrap_err();
        assert!(
            err.reason.contains("main export"),
            "empty function list + non-empty face: {}",
            err.reason
        );
        let mut bad_module = linked_face32();
        bad_module.module = String::new();
        let err2 = emit_core_module_linked(
            &AnnotatedANF {
                funcs: vec![AFuncDef {
                    name: "main".into(),
                    params: vec![],
                    body: crate::anf::ABody {
                        blocks: vec![ABlock::default()],
                    },
                }],
                fingerprint: 0,
            },
            &bad_module,
        )
        .unwrap_err();
        assert!(
            err2.reason.contains("instance name"),
            "missing provider instance name: {}",
            err2.reason
        );
        let mut bad_name = linked_face32();
        bad_name.realloc.as_mut().unwrap().name = String::new();
        let err3 = emit_core_module_linked(
            &AnnotatedANF {
                funcs: vec![AFuncDef {
                    name: "main".into(),
                    params: vec![],
                    body: crate::anf::ABody {
                        blocks: vec![ABlock::default()],
                    },
                }],
                fingerprint: 0,
            },
            &bad_name,
        )
        .unwrap_err();
        assert!(
            err3.reason.contains("field name"),
            "realloc field name empty: {}",
            err3.reason
        );
    }

    /// memory64 face: limits flag bit 0x04 + the realloc signature is
    /// isomorphic to the four-parameter signature and reuses it.
    #[test]
    fn linked_memory64_face_byte_level() {
        let ir = AnnotatedANF {
            funcs: vec![
                AFuncDef {
                    name: "main".into(),
                    params: vec![],
                    body: crate::anf::ABody {
                        blocks: vec![ABlock {
                            phis: vec![],
                            stmts: vec![],
                            ctrl: ACtrl::Ret(AAtom::Int(1)),
                        }],
                    },
                },
                AFuncDef {
                    name: "quad".into(),
                    params: vec![ATemp(0), ATemp(1), ATemp(2), ATemp(3)],
                    body: crate::anf::ABody {
                        blocks: vec![ABlock::default()],
                    },
                },
            ],
            fingerprint: 0,
        };
        let face = CoreImportFace {
            module: "kerf_abi".into(),
            memory: Some(ImportMemorySpec {
                min_pages: 2,
                memory64: true,
            }),
            realloc: Some(ImportFuncSpec {
                name: "canonical_abi_realloc".into(),
                wide: true,
            }),
        };
        let bytes = emit_core_module_linked(&ir, &face).unwrap();
        let s = secs(&bytes);
        // Import section: memory limits flags 0x04 (memory64)
        // Payload offset: count(1) + module name(1+8) + field name(1+6) +
        // kind(1)
        let (_, is, _) = *s.iter().find(|(id, _, _)| *id == 0x02).unwrap();
        let mem_flags_pos = is + 1 + (1 + 8) + (1 + 6) + 1;
        assert_eq!(
            bytes[mem_flags_pos], 0x04,
            "import memory flags = 0x04(memory64)"
        );
        // Type section: arity 0 + arity 4 (quad is isomorphic to realloc
        // wide — shared) = 2 entries
        let (_, ts, _) = *s.iter().find(|(id, _, _)| *id == 0x01).unwrap();
        assert_eq!(
            bytes[ts], 2,
            "type count = 2(realloc reusing four-parameter entries)"
        );
        // realloc import typeidx = 1 (the arity 4 entry) — payload offset:
        // count(1) + import 1 memory full length (module 9 + field 7 +
        // kind 1 + flags 1 + min pages 1 = 19) + module name(1+8) +
        // realloc field name(1+21) + kind(1)
        let re_typeidx_pos = is + 1 + (1 + 8 + 1 + 6 + 1 + 1 + 1) + (1 + 8) + (1 + 21) + 1;
        assert_eq!(
            bytes[re_typeidx_pos], 1,
            "realloc references the four formal-parameter type entries (isomorphic reuse)"
        );
        // Export: main = 1 (the realloc import occupies index 0)
        let (_, es, _) = *s.iter().find(|(id, _, _)| *id == 0x07).unwrap();
        assert_eq!(bytes[es + 7], 1);
    }

    /// Linked emission determinism: same (ir, face) → same bytes.
    #[test]
    fn linked_module_determinism() {
        let ir = AnnotatedANF {
            funcs: vec![AFuncDef {
                name: "main".into(),
                params: vec![],
                body: crate::anf::ABody {
                    blocks: vec![ABlock {
                        phis: vec![],
                        stmts: vec![],
                        ctrl: ACtrl::Ret(AAtom::Int(3)),
                    }],
                },
            }],
            fingerprint: 0,
        };
        let a = emit_core_module_linked(&ir, &linked_face32()).unwrap();
        let b = emit_core_module_linked(&ir, &linked_face32()).unwrap();
        assert_eq!(a, b, "same input same bytes(link form determinism)");
    }
}

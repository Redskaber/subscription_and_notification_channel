//! WASM component composition layer (M3 — phase 3 of TD-031, materialized).
//!
//! **Positioning**: materializes the three items defined by
//! [wasm-backend-component-model.md §5 M3](../../../docs/
//! develop/v0/stage-3/wasm-backend-component-model.md): imports/exports
//! stitching ([`compose_component`]: M2 boundary module + M3 linked core
//! module → [`InstantiationPlan`] ordered instantiation plan + wiring
//! graph), component-level type validation ([`validate_composition`]:
//! address domain consistency / realloc supply consistency / boundary
//! type allocation protocol requirements / Func export backing — all
//! fail-closed), and the component instance protocol ruling for
//! effects/capabilities (L-β).
//!
//! **Composition shape (canonical two-module system)**:
//! 1. `kerf_abi` (M2 boundary module — memory + data segment + realloc
//!    bump protocol)
//! 2. `kerf_core` (M3 linked core module — the Import section declares
//!    memory + realloc imports from the `kerf_abi` instance; imported
//!    functions occupy the front of the function index space)
//!
//! The host instantiates in plan order: `kerf_abi` (no imports) → its
//! export face is injected as the import object for `kerf_core`
//! instantiation (stitching is backed by WASM runtime type checking —
//! name/type/memory-page mismatches fail instantiation).
//!
//! **L-β ruling (the component instance protocol for effects/capabilities)**:
//! perform/handle does not cross the component boundary — effects are
//! carried by the component instance protocol (the host instantiates
//! handlers per component instance; the M3 placement of the M0 §3
//! "effects/capabilities \| out of boundary" table). The structured guard
//! = [`boundary_class`] **exhaustively classifies all [`InterfaceType`]
//! variants** (all current variants are effect-agnostic — the type system
//! has no effect-carrying face, a structural fact; future variants
//! [especially effect-carrying ones] must be classified here or
//! compilation breaks — the compile-time form of fail-closed). The ANF
//! accepted by the composition face is likewise always effect-agnostic
//! (`AOp = Prim|Call`, `ACtrl = Ret|Br|Jmp` with no effect variants —
//! effectful programs take the VM path INC7); the full design of the
//! component instance protocol = an obligation for a later B1 expansion /
//! effect-backend signal window (registered in wasm-backend-component-
//! model §6).
//!
//! **M3 honest boundary**: the core module's **semantic consumption** of
//! the import face (language-side lowering of str payloads via memory +
//! realloc) = a B1 expansion window signal (same family as the M2 L-A′
//! ruling); M3 delivers the composition protocol face (stitching + type
//! validation + instance protocol ruling), and the composed system is
//! verified via instantiation on the host chain (structural wiring of the
//! import face — instantiation-time type checking is the consumption
//! verification; language-side payload consumption follows later signals).
//!
//! **§18 dependency ruling (L-B inherited)**: zero cargo dependencies
//! (pure Rust data modeling + reuse of the existing emitter; node is only
//! a host-side test-time verification tool).

use crate::anf::AnnotatedANF;
use crate::codegen::CodegenError;
use crate::wasm::abi::{align_up, pages_for};
use crate::wasm::emit::{
    emit_abi_module, emit_core_module_linked, CoreImportFace, ImportFuncSpec, ImportMemorySpec,
};
use crate::wasm::{CanonicalAbiOptions, InterfaceType, WasmComponentModel};

/// Boundary module instance name (composition-layer convention — the first
/// segment of the two-level name in the core module Import section).
pub const ABI_MODULE_NAME: &str = "kerf_abi";

/// Linked core module instance name (composition-layer convention — the
/// consumption slot of the host-side instantiation plan).
pub const CORE_INSTANCE_NAME: &str = "kerf_core";

// ---------------------------------------------------------------------------
// Boundary type classification (the structured guard of the L-β ruling —
// exhaustive classifier)
// ---------------------------------------------------------------------------

/// Boundary type classification (allocation protocol requirements for
/// canonical ABI cross-boundary passing).
///
/// - [`BoundaryClass::Pure`]: pure-value cross-boundary (scalar family
///   passed flattened — zero allocation protocol requirements);
/// - [`BoundaryClass::Allocating`]: passed via linear memory + realloc
///   allocation (`String` / `List` — the buffer allocation face of the
///   canonical ABI).
///
/// **L-β guard**: this classifier exhaustively matches all
/// [`InterfaceType`] variants — effects/capabilities = out of boundary
/// (no corresponding variant, a structural fact); a new variant must add
/// a classification arm to the `match`, or compilation breaks (adding an
/// effect-carrying face = an explicit trigger signal for the component
/// instance protocol design window).
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum BoundaryClass {
    /// Pure-value cross-boundary (zero allocation protocol requirements).
    Pure,
    /// Allocating pass (requires the composition to supply the realloc
    /// protocol).
    Allocating,
}

/// Boundary type classification (L-β guard — exhaustive over all variants;
/// recursive over composite domains).
pub fn boundary_class(ty: &InterfaceType) -> BoundaryClass {
    use BoundaryClass::*;
    use InterfaceType::*;
    match ty {
        // Scalar domain: flattened pure-value passing (direct canonical ABI
        // mapping — zero allocation)
        Bool | S8 | S16 | S32 | S64 | U8 | U16 | U32 | U64 | F32 | F64 | Char => Pure,
        // String: passed via linear memory + realloc buffers
        String => Allocating,
        // Homogeneous list: length + contents passed via memory buffers
        // (element type does not change allocatingness)
        List(_) => Allocating,
        // Composite domains: recursive payload scan (any Allocating payload
        // → the whole type is Allocating)
        Record(fs) => fs
            .iter()
            .map(|(_, t)| boundary_class(t))
            .max()
            .unwrap_or(Pure),
        Variant(cs) => cs
            .iter()
            .map(|(_, t)| t.as_ref().map(boundary_class).unwrap_or(Pure))
            .max()
            .unwrap_or(Pure),
        Tuple(ts) => ts.iter().map(boundary_class).max().unwrap_or(Pure),
        Option(t) => boundary_class(t),
        Result { ok, err } => [ok.as_deref(), err.as_deref()]
            .into_iter()
            .flatten()
            .map(boundary_class)
            .max()
            .unwrap_or(Pure),
        // Component-level function type: param/result domain scan (the
        // lift/lower face of cross-boundary function values)
        Func(ft) => ft
            .params
            .iter()
            .chain(ft.results.iter())
            .map(|(_, t)| boundary_class(t))
            .max()
            .unwrap_or(Pure),
    }
}

// ---------------------------------------------------------------------------
// Composition plan (ordered instantiation + wiring graph — the
// component-level artifact of imports/exports stitching)
// ---------------------------------------------------------------------------

/// Stitching wiring (consumer-side description of a single import).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ImportWiring {
    /// Import field name (the second segment of the two-level name in the
    /// core module Import section).
    pub field: String,
    /// Supply source (`<instance>.<export name>` — plan rendering and
    /// host-side injection anchor).
    pub source: String,
    /// Wiring kind (memory / realloc function — type validation anchor).
    pub kind: WiringKind,
}

/// Wiring kind (the type face of stitching).
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum WiringKind {
    /// Linear memory stitching (min page count + address domain).
    Memory {
        /// Minimum page count (the supplier's actual page count at
        /// instantiation ≥ this value).
        min_pages: u32,
        /// memory64 address domain.
        memory64: bool,
    },
    /// canonical ABI realloc protocol function stitching (`(addr × 4) →
    /// addr`).
    ReallocFunc {
        /// memory64 address domain (signature width).
        wide: bool,
    },
}

impl WiringKind {
    /// Canonical rendering (plan rendering face — deterministic).
    fn render(&self) -> String {
        match self {
            WiringKind::Memory {
                min_pages,
                memory64,
            } => format!(
                "memory min={min_pages} page {}",
                if *memory64 { "memory64" } else { "wasm32" }
            ),
            WiringKind::ReallocFunc { wide } => format!(
                "realloc (addr×4)→addr {}",
                if *wide { "memory64" } else { "wasm32" }
            ),
        }
    }
}

/// Composed artifact kind (the artifact slot of the instantiation plan).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ComposedArtifact {
    /// M2 boundary module (memory + data segment + realloc bump protocol).
    AbiBoundary,
    /// M3 linked core module (the Import section declares the composition
    /// import face).
    CoreLinked,
}

impl ComposedArtifact {
    /// Canonical rendering (plan rendering face).
    fn render(&self) -> &'static str {
        match self {
            ComposedArtifact::AbiBoundary => "abi_boundary",
            ComposedArtifact::CoreLinked => "core_linked",
        }
    }
}

/// Instantiation step (ordered — step order is the host instantiation
/// order: dependents after suppliers).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct InstantiateStep {
    /// Instance name (composition-layer namespace).
    pub instance: String,
    /// Artifact kind (the artifact slot instantiated by this step).
    pub artifact: ComposedArtifact,
    /// Import injection table (supplying instance name → wiring list;
    /// empty = no imports).
    pub imports: Vec<(String, Vec<ImportWiring>)>,
}

/// Component instantiation plan (the component-level artifact of
/// imports/exports stitching — the host consumption anchor).
///
/// **Determinism**: same (face, abi, fingerprint) → same plan (fully
/// structurally ordered; `render` is the canonical string anchor for
/// acceptance assertions).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct InstantiationPlan {
    /// Ordered instantiation steps (canonical shape = two steps: boundary
    /// module → linked core module).
    pub steps: Vec<InstantiateStep>,
    /// Composition-level canonical ABI options (single source of protocol
    /// parameters — consumed by both artifacts).
    pub abi: CanonicalAbiOptions,
    /// Source fingerprint chain (passed through from
    /// `WasmComponentModel.source_fingerprint` — the content-addressing
    /// provenance anchor of the composition artifact).
    pub source_fingerprint: u64,
}

impl InstantiationPlan {
    /// Canonical rendering (diagnostic and acceptance assertion anchor —
    /// deterministic: same plan → same string).
    pub fn render(&self) -> String {
        let mut out = String::new();
        for (i, step) in self.steps.iter().enumerate() {
            out.push_str(&format!(
                "step {}: {} = {}",
                i + 1,
                step.instance,
                step.artifact.render()
            ));
            if step.imports.is_empty() {
                out.push_str("(no imports)");
            } else {
                for (module, wirings) in &step.imports {
                    for w in wirings {
                        out.push_str(&format!(
                            "\n  import {module}::{} ← {} [{}]",
                            w.field,
                            w.source,
                            w.kind.render()
                        ));
                    }
                }
            }
            out.push('\n');
        }
        out
    }
}

/// Composed component (canonical two-module system — the M3 delivery
/// envelope).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ComposedComponent {
    /// M2 boundary module bytes (supplier: memory + data segment +
    /// realloc).
    pub abi_module: Vec<u8>,
    /// M3 linked core module bytes (consumer: Import section import face +
    /// main export).
    pub core_module: Vec<u8>,
    /// Instantiation plan (the component-level artifact of stitching).
    pub plan: InstantiationPlan,
}

// ---------------------------------------------------------------------------
// Component-level type validation (stitching prerequisite — fail-closed)
// ---------------------------------------------------------------------------

/// Component-level type validation (M3 checks — the gate before composition
/// emission).
///
/// Validation items (all fail-closed):
/// 1. **Address domain consistency**: `model.abi.memory64` ≡
///    `abi.memory64` (a mismatch between the model declaration and the
///    composition supply is rejected);
/// 2. **realloc supply consistency**: rejecting when the model declares a
///    realloc but the composition does not supply one, or when the two
///    names differ (model `None` = undeclared — a composition supply is
///    legally adopted);
/// 3. **Boundary type allocation protocol**: rejecting when a model
///    import/export has [`boundary_class`] [`BoundaryClass::Allocating`]
///    (String/List family) while the composition supplies no realloc
///    (canonical ABI: allocating types require an allocation protocol);
/// 4. **Func export backing**: `Func`-typed exports must be backed by the
///    core function manifest (name ∈ `model.core_funcs` — the stitching
///    validation of the component-level export face);
/// 5. **main entry backing**: the composition consumption face calls
///    `main` — the core function manifest must contain `main` (the
///    `lower_program` conventional slot).
pub fn validate_composition(
    model: &WasmComponentModel,
    abi: &CanonicalAbiOptions,
) -> Result<(), CodegenError> {
    // ① address domain consistency
    if model.abi.memory64 != abi.memory64 {
        return Err(CodegenError::new(format!(
            "WASM M3 compose failed: memory64 address domain mismatch (model {} / compose {})",
            model.abi.memory64, abi.memory64
        )));
    }
    // ② realloc supply consistency
    match (&model.abi.realloc, &abi.realloc) {
        (Some(m), None) => {
            return Err(CodegenError::new(format!(
                "WASM M3 compose failed: model declares realloc `{m}` but the composition does not supply it"
            )));
        }
        (Some(m), Some(a)) if m != a => {
            return Err(CodegenError::new(format!(
                "WASM M3 compose failed: realloc supply name mismatch (model `{m}` / compose `{a}`)"
            )));
        }
        _ => {}
    }
    // ③ boundary type allocation protocol (both the imports/exports faces)
    let supplied = abi.realloc.is_some();
    for i in &model.imports {
        if boundary_class(&i.ty) == BoundaryClass::Allocating && !supplied {
            return Err(CodegenError::new(format!(
                "WASM M3 compose failed: import `{}` type {} cross-boundary requires allocation protocol(realloc missing position)",
                i.name,
                i.ty.render()
            )));
        }
    }
    for e in &model.exports {
        if boundary_class(&e.ty) == BoundaryClass::Allocating && !supplied {
            return Err(CodegenError::new(format!(
                "WASM M3 compose failed: export `{}` type {} cross-boundary requires allocation protocol(realloc missing position)",
                e.name,
                e.ty.render()
            )));
        }
    }
    // ④ Func export backing (component-level export face ↔ core function
    // manifest stitching)
    for e in &model.exports {
        if matches!(e.ty, InterfaceType::Func(_))
            && !model.core_funcs.iter().any(|f| f.name == e.name)
        {
            return Err(CodegenError::new(format!(
                "WASM M3 compose failed: export `{}`'s Func face has no core function backing (not in the list)",
                e.name
            )));
        }
    }
    // ⑤ main entry backing (the entry convention of the composition
    // consumption face)
    if !model.core_funcs.iter().any(|f| f.name == "main") {
        return Err(CodegenError::new(
            "WASM M3 compose failed: core function list missing the main entry (the compose consumption face calls main)",
        ));
    }
    Ok(())
}

// ---------------------------------------------------------------------------
// Composition emission (face derivation + dual artifacts + plan stitching)
// ---------------------------------------------------------------------------

/// Derive the core import face from canonical ABI options + boundary data
/// (composition-layer conventional shape).
///
/// memory is always stitched (the boundary module always exports memory);
/// realloc if and only if `abi.realloc = Some` (same alignment as the
/// supply face — absence means no import); **the min-page geometry shares
/// the single source with [`emit_abi_module`]**
/// (`align_up(max(len,1),8)` heap base + one page of headroom — the
/// structural guarantee that the supplier's actual page count ≥ the
/// imported minimum page count).
fn face_from_abi(abi: &CanonicalAbiOptions, data: &[u8]) -> CoreImportFace {
    let heap_base = align_up(data.len().max(1) as u64, 8);
    let min_pages = pages_for(heap_base as usize) + 1;
    CoreImportFace {
        module: ABI_MODULE_NAME.to_string(),
        memory: Some(ImportMemorySpec {
            min_pages,
            memory64: abi.memory64,
        }),
        realloc: abi.realloc.clone().map(|name| ImportFuncSpec {
            name,
            wide: abi.memory64,
        }),
    }
}

/// Composition emission (M3 main entry: validate → dual artifact emission →
/// plan stitching).
///
/// **Determinism**: same (ir, model, data, abi) → same composition
/// artifact (both bytes and plan — fully structurally ordered).
pub fn compose_component(
    ir: &AnnotatedANF,
    model: &WasmComponentModel,
    data: &[u8],
    abi: &CanonicalAbiOptions,
) -> Result<ComposedComponent, CodegenError> {
    // ① component-level type validation (stitching gate — fail-closed)
    validate_composition(model, abi)?;
    // ② dual artifact emission (M2 boundary module + M3 linked core module)
    let abi_module = emit_abi_module(data, abi)?;
    let face = face_from_abi(abi, data);
    let core_module = emit_core_module_linked(ir, &face)?;
    // ③ plan stitching (ordered instantiation + wiring graph)
    let plan = build_plan(&face, abi, model.source_fingerprint);
    Ok(ComposedComponent {
        abi_module,
        core_module,
        plan,
    })
}

/// Stitching plan construction (canonical two steps: boundary module →
/// linked core module).
fn build_plan(
    face: &CoreImportFace,
    abi: &CanonicalAbiOptions,
    fingerprint: u64,
) -> InstantiationPlan {
    let mut wirings = Vec::new();
    if let Some(mem) = &face.memory {
        wirings.push(ImportWiring {
            field: "memory".to_string(),
            source: format!("{ABI_MODULE_NAME}.memory"),
            kind: WiringKind::Memory {
                min_pages: mem.min_pages,
                memory64: mem.memory64,
            },
        });
    }
    if let Some(re) = &face.realloc {
        wirings.push(ImportWiring {
            field: re.name.clone(),
            source: format!("{ABI_MODULE_NAME}.{}", re.name),
            kind: WiringKind::ReallocFunc { wide: re.wide },
        });
    }
    let core_imports = if wirings.is_empty() {
        Vec::new()
    } else {
        vec![(ABI_MODULE_NAME.to_string(), wirings)]
    };
    InstantiationPlan {
        steps: vec![
            InstantiateStep {
                instance: ABI_MODULE_NAME.to_string(),
                artifact: ComposedArtifact::AbiBoundary,
                imports: Vec::new(),
            },
            InstantiateStep {
                instance: CORE_INSTANCE_NAME.to_string(),
                artifact: ComposedArtifact::CoreLinked,
                imports: core_imports,
            },
        ],
        abi: abi.clone(),
        source_fingerprint: fingerprint,
    }
}

// ---------------------------------------------------------------------------
// Unit tests (composition protocol invariants — validation fail-closed /
// plan structure / determinism)
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use crate::anf::{AAtom, ABlock, ABody, ACtrl, AFuncDef};
    use crate::wasm::emit::parse_core_module_manifest;
    use crate::wasm::{component_model_from_anf, ComponentModelBuilder, CoreModuleFunc};

    /// Single-main constant-program IR (`Ret(Int(5))` — the minimal
    /// well-formed composition carrier).
    fn main_ir() -> AnnotatedANF {
        AnnotatedANF {
            funcs: vec![AFuncDef {
                name: "main".into(),
                params: vec![],
                body: ABody {
                    blocks: vec![ABlock {
                        phis: vec![],
                        stmts: vec![],
                        ctrl: ACtrl::Ret(AAtom::Int(5)),
                    }],
                },
            }],
            fingerprint: 42,
        }
    }

    /// Composition ABI options (wasm32 domain + default realloc name —
    /// baseline shape).
    fn abi32() -> CanonicalAbiOptions {
        CanonicalAbiOptions {
            memory64: false,
            realloc: Some("canonical_abi_realloc".into()),
            ..Default::default()
        }
    }

    /// No-realloc options (allocation protocol absent shape — validation
    /// negative-case carrier).
    fn abi_no_realloc() -> CanonicalAbiOptions {
        CanonicalAbiOptions {
            memory64: false,
            realloc: None,
            ..Default::default()
        }
    }

    /// Plan structure: canonical two steps + wiring graph + provenance
    /// chain.
    #[test]
    fn plan_structure_canonical_two_steps() {
        let ir = main_ir();
        let model = component_model_from_anf(&ir);
        let composed = compose_component(&ir, &model, b"hello", &abi32()).expect("compose emit");
        let plan = &composed.plan;
        assert_eq!(plan.steps.len(), 2, "canonical dual step");
        assert_eq!(plan.steps[0].instance, "kerf_abi");
        assert_eq!(plan.steps[0].artifact, ComposedArtifact::AbiBoundary);
        assert!(
            plan.steps[0].imports.is_empty(),
            "boundary module no imports"
        );
        assert_eq!(plan.steps[1].instance, "kerf_core");
        assert_eq!(plan.steps[1].artifact, ComposedArtifact::CoreLinked);
        assert_eq!(plan.steps[1].imports.len(), 1);
        let (module, wirings) = &plan.steps[1].imports[0];
        assert_eq!(module, "kerf_abi");
        assert_eq!(wirings.len(), 2, "memory + realloc dual suture");
        assert_eq!(wirings[0].field, "memory");
        assert_eq!(wirings[0].source, "kerf_abi.memory");
        assert_eq!(
            wirings[0].kind,
            WiringKind::Memory {
                min_pages: 2,
                memory64: false
            }
        );
        assert_eq!(wirings[1].field, "canonical_abi_realloc");
        assert_eq!(wirings[1].source, "kerf_abi.canonical_abi_realloc");
        assert_eq!(wirings[1].kind, WiringKind::ReallocFunc { wide: false });
        assert_eq!(
            plan.source_fingerprint, 42,
            "source fingerprint chain pass-through"
        );
    }

    /// Validation ③: String boundary type + absent realloc → fail-closed.
    #[test]
    fn validate_string_boundary_requires_realloc() {
        let ir = main_ir();
        let model = component_model_from_anf(&ir);
        let declared = ComponentModelBuilder::new()
            .core_func(CoreModuleFunc {
                name: "main".into(),
                params: 0,
                blocks: 1,
            })
            .import("host-msg", InterfaceType::String)
            .build()
            .expect("model build");
        let err = validate_composition(&declared, &abi_no_realloc()).unwrap_err();
        assert!(
            err.reason.contains("allocation protocol") && err.reason.contains("host-msg"),
            "error face: {}",
            err.reason
        );
        // After supplying realloc, the same model passes (the M0 builder's
        // first real consumption)
        assert!(validate_composition(&declared, &abi32()).is_ok());
        // The derived model (no declared imports) always passes — baseline
        // path
        assert!(validate_composition(&model, &abi_no_realloc()).is_ok());
    }

    /// Validation ③: recursive scan of nested String-family types in
    /// List / Record.
    #[test]
    fn validate_nested_allocating_types_scanned() {
        let model = ComponentModelBuilder::new()
            .core_func(CoreModuleFunc {
                name: "main".into(),
                params: 0,
                blocks: 1,
            })
            .export("items", InterfaceType::List(Box::new(InterfaceType::S64)))
            .build()
            .unwrap();
        let err = validate_composition(&model, &abi_no_realloc()).unwrap_err();
        assert!(
            err.reason.contains("list<s64>"),
            "error face: {}",
            err.reason
        );
        let nested = ComponentModelBuilder::new()
            .core_func(CoreModuleFunc {
                name: "main".into(),
                params: 0,
                blocks: 1,
            })
            .export(
                "r",
                InterfaceType::Record(vec![("x".into(), InterfaceType::S64)]),
            )
            .build()
            .unwrap();
        assert!(
            validate_composition(&nested, &abi_no_realloc()).is_ok(),
            "pure scalar Record has no allocation requirement"
        );
    }

    /// Validation ①: memory64 domain mismatch → fail-closed.
    #[test]
    fn validate_memory64_consistency_fail_closed() {
        let ir = main_ir();
        let model = component_model_from_anf(&ir);
        let abi64 = CanonicalAbiOptions {
            memory64: true,
            realloc: Some("canonical_abi_realloc".into()),
            ..Default::default()
        };
        let err = validate_composition(&model, &abi64).unwrap_err();
        assert!(
            err.reason.contains("memory64"),
            "error face: {}",
            err.reason
        );
    }

    /// Validation ②: model declares realloc but the composition does not
    /// supply it / names differ → fail-closed.
    #[test]
    fn validate_realloc_supply_consistency() {
        let declared = ComponentModelBuilder::new()
            .core_func(CoreModuleFunc {
                name: "main".into(),
                params: 0,
                blocks: 1,
            })
            .core_func(CoreModuleFunc {
                name: "canonical_abi_realloc".into(),
                params: 4,
                blocks: 1,
            })
            .realloc("canonical_abi_realloc")
            .build()
            .unwrap();
        let err = validate_composition(&declared, &abi_no_realloc()).unwrap_err();
        assert!(
            err.reason.contains("not supply"),
            "error face: {}",
            err.reason
        );
        let other_name = CanonicalAbiOptions {
            memory64: false,
            realloc: Some("my_realloc".into()),
            ..Default::default()
        };
        let err2 = validate_composition(&declared, &other_name).unwrap_err();
        assert!(
            err2.reason.contains("mismatch"),
            "error face: {}",
            err2.reason
        );
        // Same-name supply → passes; model undeclared + composition supply
        // = legal adoption
        assert!(validate_composition(&declared, &abi32()).is_ok());
        let ir = main_ir();
        let plain = component_model_from_anf(&ir);
        assert!(validate_composition(&plain, &abi32()).is_ok());
    }

    /// Validation ④: Func export face without core-function backing →
    /// fail-closed.
    #[test]
    fn validate_func_export_requires_core_backing() {
        let model = ComponentModelBuilder::new()
            .core_func(CoreModuleFunc {
                name: "main".into(),
                params: 0,
                blocks: 1,
            })
            .export(
                "compute",
                InterfaceType::Func(crate::wasm::ComponentFuncType {
                    params: vec![("n".into(), InterfaceType::S64)],
                    results: vec![("r".into(), InterfaceType::S64)],
                }),
            )
            .build()
            .unwrap();
        let err = validate_composition(&model, &abi32()).unwrap_err();
        assert!(
            err.reason.contains("compute") && err.reason.contains("backing"),
            "error face: {}",
            err.reason
        );
        // With backing (manifest contains compute) → passes
        let backed = ComponentModelBuilder::new()
            .core_func(CoreModuleFunc {
                name: "main".into(),
                params: 0,
                blocks: 1,
            })
            .core_func(CoreModuleFunc {
                name: "compute".into(),
                params: 1,
                blocks: 1,
            })
            .export(
                "compute",
                InterfaceType::Func(crate::wasm::ComponentFuncType {
                    params: vec![("n".into(), InterfaceType::S64)],
                    results: vec![("r".into(), InterfaceType::S64)],
                }),
            )
            .build()
            .unwrap();
        assert!(validate_composition(&backed, &abi32()).is_ok());
    }

    /// Validation ⑤: missing main entry → fail-closed.
    #[test]
    fn validate_main_entry_required() {
        let model = ComponentModelBuilder::new()
            .core_func(CoreModuleFunc {
                name: "f".into(),
                params: 0,
                blocks: 1,
            })
            .build()
            .unwrap();
        let err = validate_composition(&model, &abi32()).unwrap_err();
        assert!(err.reason.contains("main"), "error face: {}", err.reason);
    }

    /// L-β guard: boundary type classification family (semantic anchor of
    /// the exhaustive classifier).
    #[test]
    fn boundary_class_family() {
        use BoundaryClass::*;
        assert_eq!(boundary_class(&InterfaceType::S64), Pure);
        assert_eq!(boundary_class(&InterfaceType::F64), Pure);
        assert_eq!(boundary_class(&InterfaceType::Bool), Pure);
        assert_eq!(boundary_class(&InterfaceType::Char), Pure);
        assert_eq!(boundary_class(&InterfaceType::String), Allocating);
        assert_eq!(
            boundary_class(&InterfaceType::List(Box::new(InterfaceType::S64))),
            Allocating
        );
        assert_eq!(
            boundary_class(&InterfaceType::Option(Box::new(InterfaceType::S64))),
            Pure
        );
        assert_eq!(
            boundary_class(&InterfaceType::Option(Box::new(InterfaceType::String))),
            Allocating
        );
        assert_eq!(
            boundary_class(&InterfaceType::Record(vec![
                ("x".into(), InterfaceType::S64),
                ("y".into(), InterfaceType::String),
            ])),
            Allocating
        );
        assert_eq!(
            boundary_class(&InterfaceType::Tuple(vec![InterfaceType::S64])),
            Pure
        );
        assert_eq!(
            boundary_class(&InterfaceType::Result {
                ok: Some(Box::new(InterfaceType::String)),
                err: None,
            }),
            Allocating
        );
    }

    /// Face derivation geometry: min pages share the single source with
    /// emit_abi_module.
    #[test]
    fn face_derivation_matches_abi_geometry() {
        let face = face_from_abi(&abi32(), b"0123456789");
        // data 10 bytes → heap_base = align_up(10, 8) = 16 →
        // pages_for(16)=0 + 1 = 2 pages
        assert_eq!(
            face.memory.as_ref().unwrap().min_pages,
            2,
            "min page geometry single-source consistent"
        );
        assert!(!face.memory.as_ref().unwrap().memory64);
        assert_eq!(face.realloc.as_ref().unwrap().name, "canonical_abi_realloc");
        // No-realloc shape: no function imports (same alignment as the
        // supply face)
        let bare = face_from_abi(&abi_no_realloc(), b"");
        assert!(bare.memory.is_some(), "memory always suture");
        assert!(
            bare.realloc.is_none(),
            "realloc missing position not imported"
        );
        assert_eq!(bare.imported_func_count(), 0);
        // memory64 shape: address domain passthrough
        let abi64 = CanonicalAbiOptions {
            memory64: true,
            realloc: Some("my_realloc".into()),
            ..Default::default()
        };
        let wide = face_from_abi(&abi64, b"abcd");
        assert!(wide.memory.as_ref().unwrap().memory64);
        assert!(wide.realloc.as_ref().unwrap().wide);
        assert_eq!(wide.realloc.as_ref().unwrap().name, "my_realloc");
    }

    /// Composition determinism + content/geometry sensitivity (both the
    /// bytes and the plan).
    ///
    /// Sensitivity layering: abi_module is sensitive to data **content**
    /// (data segment bytes); core_module is sensitive to data **geometry**
    /// (import face min pages — content never enters the face); the plan
    /// is sensitive to ABI protocol parameters (realloc name passthrough).
    #[test]
    fn compose_determinism_and_sensitivity() {
        let ir = main_ir();
        let model = component_model_from_anf(&ir);
        let a1 = compose_component(&ir, &model, b"hello", &abi32()).unwrap();
        let a2 = compose_component(&ir, &model, b"hello", &abi32()).unwrap();
        assert_eq!(a1, a2, "same input same compose artifact(byte + plan)");
        // Content changes (same length): abi module changes + linked face
        // unchanged (the face depends only on geometry)
        let b1 = compose_component(&ir, &model, b"hellp", &abi32()).unwrap();
        assert_ne!(
            a1.abi_module, b1.abi_module,
            "data content changes → boundary module changes"
        );
        assert_eq!(
            a1.core_module, b1.core_module,
            "same-geometry data → linked face same bytes (face = geometry single source)"
        );
        // Geometry changes (crosses a page): import face min pages change →
        // linked face changes
        let big: Vec<u8> = vec![0u8; 65_537]; // pages_for(align_up(65537,8)=65544) = 2 → min 3
        let c1 = compose_component(&ir, &model, &big, &abi32()).unwrap();
        assert_ne!(
            a1.core_module, c1.core_module,
            "data geometry changes (cross-page) → linked face changes (min page)"
        );
        // The plan is sensitive to ABI protocol parameters (realloc name
        // passthrough)
        let other = CanonicalAbiOptions {
            memory64: false,
            realloc: Some("my_realloc".into()),
            ..Default::default()
        };
        let d1 = compose_component(&ir, &model, b"hello", &other).unwrap();
        assert_ne!(
            a1.plan.render(),
            d1.plan.render(),
            "realloc name change → plan change"
        );
    }

    /// Plan canonical rendering: determinism + structural anchors (data
    /// "hi": 2 bytes → heap 8 → pages_for(8) = 1 + 1 headroom = min 2
    /// pages).
    #[test]
    fn plan_render_canonical_string() {
        let ir = main_ir();
        let model = component_model_from_anf(&ir);
        let composed = compose_component(&ir, &model, b"hi", &abi32()).unwrap();
        let r = composed.plan.render();
        assert!(
            r.contains("step 1: kerf_abi = abi_boundary(no imports)"),
            "render: \n{r}"
        );
        assert!(
            r.contains("step 2: kerf_core = core_linked"),
            "render: \n{r}"
        );
        assert!(r.contains("import kerf_abi::memory"), "render: \n{r}");
        assert!(r.contains("memory min=2 page wasm32"), "render: \n{r}");
        assert!(
            r.contains("import kerf_abi::canonical_abi_realloc"),
            "render: \n{r}"
        );
        assert!(r.contains("realloc (addr×4)→addr wasm32"), "render: \n{r}");
        // Determinism: same plan → same rendered string
        let again = compose_component(&ir, &model, b"hi", &abi32()).unwrap();
        assert_eq!(r, again.plan.render());
    }

    /// Manifest survival: the linked core module's kerf_meta manifest =
    /// the model function manifest (zero stitching loss).
    #[test]
    fn compose_manifest_survives_linking() {
        let ir = main_ir();
        let model = component_model_from_anf(&ir);
        let composed = compose_component(&ir, &model, b"hi", &abi32()).unwrap();
        assert_eq!(
            parse_core_module_manifest(&composed.core_module).unwrap(),
            model.core_funcs,
            "list survives linked emission with zero loss (logical list independent of import index offsets)"
        );
    }
}

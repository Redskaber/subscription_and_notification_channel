//! AnnotatedANF IR reification and CoreExpr lowering (batch G / 38-b — G1 front end).
//!
//! **Position**: `CoreExpr` → `AnnotatedANF` (block-style ANF: binding
//! sequences + block-graph control flow). ANF = A-Normal Form — every
//! intermediate value is named (temporary bindings), and function calls
//! and primitive arguments are atomized. The block-style variant aligns
//! naturally with QBE's function/label/jmp topology (value-context if
//! merges via block parameters — the explicit equivalent of QBE phi).
//!
//! **PoC boundary ruling (B1 registration — batch G scope statement)**:
//! - Supported: integer-domain literals / Var (function parameters) / the
//!   ten arithmetic and comparison primitives
//!   (`+ - * / mod = < > <= >=`) + `not` + `eq` (treated as `=` on the
//!   integer domain) / Apply (direct calls whose callee is a top-level
//!   `define` function, including static arity checking) / If (including
//!   value context — merge via block parameters) / Do / top-level
//!   `define` (value must be Fn) / Require (zero runtime semantics —
//!   skipped, consistent with the VM bytecode convention);
//! - Out of boundary (explicit errors, not silent degradation): Fn in
//!   value position (closure capture is not in the PoC — language-level
//!   full closure semantics are carried by the batch H/I GC-backend
//!   collaboration) / Float/Str/Symbol/Pair/Bool/Nil literals / `set!` /
//!   `module` / calls to undefined functions / arity mismatch /
//!   first-class passing of function values.
//!
//! **Name resolution convention (B1 deviation registration)**: lowering
//! uses a name-base lexical stack (no ScopeSet subset matching) — on
//! well-formed programs this agrees with the compiler's name-base stack
//! order (the established equivalence condition noted in the r13
//! closure); TD-004 full matching is left to the bytecode path (this
//! crate does not carry dual-path consistency — the VM is the semantic
//! reference, native code is the PoC delivery surface).

use std::collections::HashMap;
use std::rc::Rc;

use kerf_core::{CoreExpr, LiteralValue, ModuleItem};
use kerf_span::Span;
use kerf_syntax::{Symbol, SymbolTable};

// ---------------------------------------------------------------------------
// ANF IR data structures (the function definition set of reified AnnotatedANF)
// ---------------------------------------------------------------------------

/// Annotated ANF program (the contract reification point lives in
/// [`crate::codegen`] — `fingerprint` preserved).
///
/// Convention: `funcs[0]` is the main entry (no parameters; the return value
/// is the process exit code — C `main` semantics, POSIX takes the low 8
/// bits); the rest are top-level `define` functions (QBE symbol `$name`,
/// where the base name is the symbol name with hygiene suffixes stripped).
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct AnnotatedANF {
    pub funcs: Vec<AFuncDef>,
    pub fingerprint: u64,
}

/// ANF function definition (the lowering product of `define name (lambda (params...) body)`).
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct AFuncDef {
    /// QBE global symbol base name (hygiene suffix already stripped).
    pub name: String,
    /// Parameter temporaries (naming anchors of the `%tN` sequence — N starts
    /// at 0, unique within the function).
    pub params: Vec<ATemp>,
    /// Block graph (blocks[0] = entry).
    pub body: ABody,
}

/// Block-graph function body.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct ABody {
    pub blocks: Vec<ABlock>,
}

/// Basic block: phi bindings (merge anchors for value-context if — the QBE
/// `phi @lbl %v, ...` form) + a binding sequence + a control-flow terminator.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct ABlock {
    /// Phi bindings (must sit at the block head — the IR-side counterpart of
    /// QBE's lexical constraint).
    pub phis: Vec<APhi>,
    /// Binding sequence (executed in order).
    pub stmts: Vec<AStmt>,
    /// Control-flow terminator (every block must end with one of Ret/Br/Jmp —
    /// strong invariant).
    pub ctrl: ACtrl,
}

/// Phi binding: dst = phi (source label, source atom)...
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct APhi {
    pub dst: ATemp,
    /// Sources (source block label → the value carried on that path).
    pub sources: Vec<(ALabel, AAtom)>,
}

/// Binding statement: `dst = op(args)`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AStmt {
    pub dst: ATemp,
    pub op: AOp,
    pub span: Span,
}

/// Right-hand-side operation (a primitive or direct call over atomic
/// arguments).
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum AOp {
    /// Primitive (ten integer-domain items + not/eq? — see [`APrim`]).
    Prim(APrim, Vec<AAtom>),
    /// Direct function call (callee is a global function of a top-level define).
    Call { func: String, args: Vec<AAtom> },
}

/// Primitive set (PoC integer domain — direct mapping to QBE instructions).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum APrim {
    Add,
    Sub,
    Mul,
    Div,
    Mod,
    Eq,
    Lt,
    Gt,
    Le,
    Ge,
    Not,
}

impl APrim {
    /// kerf builtin name → primitive (PoC support-surface decision).
    pub fn from_builtin_name(name: &str) -> Option<APrim> {
        Some(match name {
            "+" => APrim::Add,
            "-" => APrim::Sub,
            "*" => APrim::Mul,
            "/" => APrim::Div,
            "mod" => APrim::Mod,
            // r159 / 229-c: the term-level infix face (n % 2) lowers to the
            // same native primitive as the legacy call-form alias.
            "%" => APrim::Mod,
            "=" => APrim::Eq,
            "<" => APrim::Lt,
            ">" => APrim::Gt,
            "<=" => APrim::Le,
            ">=" => APrim::Ge,
            "not" => APrim::Not,
            "eq" => APrim::Eq,
            _ => return None,
        })
    }
}

/// Atom (ANF leaf: literal or temporary reference).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AAtom {
    Int(i64),
    Var(ATemp),
}

/// Temporary number (unique within the function; rendered `%t{0}`).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
pub struct ATemp(pub u32);

/// Block label (unique within the function; rendered `@l{0}`).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
pub struct ALabel(pub u32);

/// Control-flow terminator instruction.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ACtrl {
    /// Returns an atom.
    Ret(AAtom),
    /// Conditional branch (cond is a boolean temporary; neither branch carries
    /// parameters — value merging goes through Jmp).
    Br { cond: ATemp, t: ALabel, f: ALabel },
    /// Unconditional jump (value merging is carried by the target block's
    /// [`APhi`]).
    Jmp { target: ALabel },
}

impl Default for ACtrl {
    /// Default terminator: return 0 (C main convention — required by the
    /// Default derive chain of ABlock/ABody/AFuncDef).
    fn default() -> Self {
        ACtrl::Ret(AAtom::Int(0))
    }
}

// ---------------------------------------------------------------------------
// Errors (lowering out-of-boundary = explicit failure, not silent degradation — §2.3-4)
// ---------------------------------------------------------------------------

/// Lowering error (unified surface for PoC out-of-boundary and static-check
/// failures).
#[derive(Debug, Clone, PartialEq)]
pub struct LowerError {
    pub message: String,
    pub span: Span,
}

impl LowerError {
    fn new(message: impl Into<String>, span: Span) -> Self {
        LowerError {
            message: message.into(),
            span,
        }
    }
}

/// Primitive arity (Not/Eq etc.) — for static checking.
fn prim_arity(p: APrim) -> (usize, usize) {
    match p {
        APrim::Not => (1, 1),
        // Reason for the `_` arm: all other primitives are binary
        // (arithmetic/comparison/cons families) — the static-check default domain
        _ => (2, 2),
    }
}

// ---------------------------------------------------------------------------
// Lowering (§10.1 rule 2: Ctxt suffix)
// ---------------------------------------------------------------------------

/// Top-level global function registry (product of the first pass of the
/// two-pass scan).
#[derive(Debug, Default)]
struct GlobalFuncs {
    /// Symbol → QBE base name.
    names: HashMap<Symbol, String>,
    /// Symbol → parameter count (arity static checking).
    arities: HashMap<Symbol, usize>,
}

/// Per-function lowering context (block builder + name-base resolution).
struct LowerCtxt<'a> {
    /// Top-level global function table (read-only).
    globals: &'a GlobalFuncs,
    /// Symbol name rendering table (Symbol → base name — hygiene suffix
    /// stripping happens in [`render_name`]).
    table: &'a SymbolTable,
    /// Lexical parameter stack (name base: symbol → current-frame temporary).
    locals: Vec<HashMap<Symbol, ATemp>>,
    /// Emitted blocks (with phis/stmts; ctrl is filled in by [`seal_block`]).
    blocks: Vec<(Vec<APhi>, Vec<AStmt>)>,
    /// Block terminator queue (paired with blocks; merged in at seal time).
    ctrls: Vec<Option<ACtrl>>,
    /// Next temporary number.
    next_temp: u32,
}

impl<'a> LowerCtxt<'a> {
    fn new(globals: &'a GlobalFuncs, table: &'a SymbolTable, params: &[Symbol]) -> Self {
        let mut locals = vec![HashMap::new()];
        for (i, p) in params.iter().enumerate() {
            locals[0].insert(*p, ATemp(i as u32));
        }
        LowerCtxt {
            globals,
            table,
            locals,
            blocks: Vec::new(),
            ctrls: Vec::new(),
            next_temp: params.len() as u32,
        }
    }

    fn fresh_temp(&mut self) -> ATemp {
        let t = ATemp(self.next_temp);
        self.next_temp += 1;
        t
    }

    /// Open a new block (optionally with a phi binding set) — **block
    /// label = block index** (a single numbering system: the gen side
    /// renders blocks[i] ↔ @l{i}; Br/Jmp targets predict future block
    /// indices via `blocks.len()` before sealing — see
    /// lower_tail/lower_value_if).
    fn start_block(&mut self, phis: Vec<APhi>) -> ALabel {
        let label = ALabel(self.blocks.len() as u32);
        self.blocks.push((phis, Vec::new()));
        self.ctrls.push(None);
        label
    }

    /// Seal a block (fill in the control-flow terminator — strong invariant:
    /// one slot one terminator, explicit failure per §2.3-4).
    fn seal_block(&mut self, ctrl: ACtrl) {
        let idx = self.blocks.len() - 1;
        if self.ctrls[idx].is_some() {
            panic!(
                "lowering internal invariant broken: block {} terminated twice",
                idx
            );
        }
        self.ctrls[idx] = Some(ctrl);
    }

    /// Bound-name lookup (name-base lexical stack — top down).
    fn lookup(&self, name: Symbol) -> Option<ATemp> {
        for frame in self.locals.iter().rev() {
            if let Some(&t) = frame.get(&name) {
                return Some(t);
            }
        }
        None
    }

    /// Emit a binding statement.
    fn emit(&mut self, op: AOp, span: Span) -> ATemp {
        let dst = self.fresh_temp();
        let idx = self.blocks.len() - 1;
        self.blocks[idx].1.push(AStmt { dst, op, span });
        dst
    }
}

/// Symbol base-name rendering (hygiene suffix `$hyg$N` stripping —
/// consistent with the compiler's LOAD_GLOBAL fallback convention) +
/// QBE symbol charset sanitization (characters outside `[A-Za-z0-9_.]`
/// replaced with `_`).
fn render_name(sym: Symbol, table: &SymbolTable) -> String {
    let raw = table.name(sym);
    let base = match raw.find("$hyg$") {
        Some(i) => &raw[..i],
        None => raw,
    };
    let sanitized: String = base
        .chars()
        .map(|c| {
            if c.is_ascii_alphanumeric() || c == '_' || c == '.' || c == '-' {
                c
            } else {
                '_'
            }
        })
        .collect();
    if sanitized.is_empty() {
        "anon".to_string()
    } else {
        sanitized
    }
}

/// Tail-expression context for atomization-complexity decisions (position
/// awareness before block termination).
enum TailCtx {
    /// Value context (payload of merge/jmp/ret).
    Value,
    /// Function body tail (direct Ret).
    BodyTail,
}

/// Lowering main entry (§10.1 rule 1: `<verb>_<noun>` free function).
///
/// Input: the program's `ModuleItem` sequence (r49 D59 — product of the
/// expander's item-position classification).
/// Output: reified `AnnotatedANF` (`funcs[0]` = main).
/// Content addressing: `fingerprint` runs std DefaultHasher over the IL
/// text (cache-key convention consistent with the contract field
/// semantics — content addressing, not cryptography).
pub fn lower_program(
    items: &[ModuleItem],
    table: &SymbolTable,
) -> Result<AnnotatedANF, LowerError> {
    // First pass: global function registration (define → (Symbol, base name, arity))
    let mut globals = GlobalFuncs::default();
    for item in items {
        if let ModuleItem::Define { name, value, span } = item {
            let arity = lambda_arity(value).ok_or_else(|| {
                LowerError::new(
                    "native code PoC boundary: define value must be function(lambda) -- non-function global(data/closure value)not enter PoC",
                    *span,
                )
            })?;
            globals.names.insert(*name, render_name(*name, table));
            globals.arities.insert(*name, arity);
        }
    }

    // Second pass: lower function by function (Require/expression items go into the main sequence)
    let mut funcs: Vec<AFuncDef> = Vec::new();
    for item in items {
        if let ModuleItem::Define { name, value, span } = item {
            if let CoreExpr::Fn {
                params,
                rest,
                body,
                span: fspan,
                ..
            } = value.as_ref()
            {
                // r165 / 236-c (variadic-rest-design.md D10 boundary): the
                // native/WASM backend lowers fixed-arity functions only —
                // a rest parameter's folded pair chain needs the runtime
                // frame-setup machinery the AOT face does not carry. Fail
                // closed (honest boundary, not a silent truncation).
                if rest.is_some() {
                    return Err(LowerError::new(
                        "native code PoC boundary: rest parameter (variadic fn) not in the PoC",
                        *span,
                    ));
                }
                let afunc = lower_lambda(
                    &globals,
                    table,
                    &render_name(*name, table),
                    params,
                    body,
                    *fspan,
                )?;
                funcs.push(afunc);
            } else {
                // Already rejected in the first pass (this branch is
                // unreachable — defensive, §2.3-4)
                return Err(LowerError::new(
                    "define value is not a lambda (first pass should have rejected)",
                    *span,
                ));
            }
        }
    }

    // main: all non-define top-level items are evaluated in order
    // (intermediate values discarded); the last one's value is returned
    // from main (empty sequence → return 0 — C main convention; require
    // has zero runtime semantics and emits no instructions — consistent
    // with the bytecode path convention).
    let main = lower_main(&globals, table, items)?;
    funcs.insert(0, main);

    let fingerprint = fingerprint_of(&funcs);
    Ok(AnnotatedANF { funcs, fingerprint })
}

/// Parameter count of a define value (non-lambda → None).
fn lambda_arity(value: &CoreExpr) -> Option<usize> {
    match value {
        CoreExpr::Fn { params, .. } => Some(params.len()),
        _ => None,
    }
}

/// Content-addressed fingerprint (std DefaultHasher — cache-key convention).
fn fingerprint_of(funcs: &[AFuncDef]) -> u64 {
    use std::hash::{Hash, Hasher};
    let mut h = std::collections::hash_map::DefaultHasher::new();
    for f in funcs {
        f.name.hash(&mut h);
        f.params.len().hash(&mut h);
        for b in &f.body.blocks {
            // Content-addressing completeness (38-c field-test erratum:
            // hashing only the length gave (+ 1 2) and (+ 1 3) the same
            // fingerprint — operands/phi sources/terminator payloads all
            // go into the hash)
            format!("{:?}", b.phis).hash(&mut h);
            format!("{:?}", b.stmts).hash(&mut h);
            format!("{:?}", b.ctrl).hash(&mut h);
        }
    }
    h.finish()
}

/// Lower a single lambda (a define value).
fn lower_lambda(
    globals: &GlobalFuncs,
    table: &SymbolTable,
    name: &str,
    params: &[Symbol],
    body: &Rc<CoreExpr>,
    _span: Span,
) -> Result<AFuncDef, LowerError> {
    let mut ctx = LowerCtxt::new(globals, table, params);
    ctx.start_block(Vec::new()); // entry (label 0)
                                 // BodyTail contract: lower_tail itself guarantees every block is
                                 // terminated (tail-position if lets both branches Ret on their
                                 // own; other shapes Ret in place after tail atomization) — the
                                 // caller no longer seals the tail
    lower_tail(&mut ctx, body, TailCtx::BodyTail)?;
    finish_func(name, params, ctx)
}

/// Lower main (top-level statement sequence).
fn lower_main(
    globals: &GlobalFuncs,
    table: &SymbolTable,
    items: &[ModuleItem],
) -> Result<AFuncDef, LowerError> {
    // Module forms are not in the PoC (explicit rejection on the native
    // path — same convention as the PoC boundary family)
    if let Some(ModuleItem::Module { span, .. }) = items
        .iter()
        .find(|i| matches!(i, ModuleItem::Module { .. }))
    {
        return Err(LowerError::new(
            "native code PoC boundary: module forms not in the PoC",
            *span,
        ));
    }
    let stmts: Vec<&Rc<CoreExpr>> = items
        .iter()
        .filter_map(|item| match item {
            ModuleItem::Expr(e) => Some(e),
            // define is lowered in the second pass; require has zero
            // runtime semantics and emits no instructions
            ModuleItem::Define { .. } | ModuleItem::Require { .. } => None,
            ModuleItem::Module { .. } => None,
        })
        .collect();

    let mut ctx = LowerCtxt::new(globals, table, &[]);
    ctx.start_block(Vec::new()); // entry
    if stmts.is_empty() {
        // Empty program: main returns 0 (C convention)
        ctx.seal_block(ACtrl::Ret(AAtom::Int(0)));
    } else {
        for (i, e) in stmts.iter().enumerate() {
            let atom = lower_tail(&mut ctx, e, TailCtx::Value)?;
            if i + 1 == stmts.len() {
                ctx.seal_block(ACtrl::Ret(atom));
            }
            // Intermediate values discarded: atomic results are simply not
            // reused (no effectful resources need cleanup — the integer
            // domain has no destructors)
        }
    }
    finish_func("main", &[], ctx)
}

/// Collect the block graph into a function definition (terminator
/// completeness check — same convention as §19.3 invariant 2).
fn finish_func(name: &str, params: &[Symbol], ctx: LowerCtxt<'_>) -> Result<AFuncDef, LowerError> {
    let mut blocks = Vec::with_capacity(ctx.blocks.len());
    for (i, (phis, stmts)) in ctx.blocks.into_iter().enumerate() {
        let ctrl = ctx.ctrls[i].clone().ok_or_else(|| {
            LowerError::new(
                format!(
                    "lowering invariant broken: block {} missing control-flow termination",
                    i
                ),
                Span::default(),
            )
        })?;
        blocks.push(ABlock { phis, stmts, ctrl });
    }
    Ok(AFuncDef {
        name: name.to_string(),
        params: (0..params.len()).map(|i| ATemp(i as u32)).collect(),
        body: ABody { blocks },
    })
}

/// Atomize: complex expressions evaluate into temporaries; atoms are
/// returned directly.
fn lower_atom(ctx: &mut LowerCtxt<'_>, e: &CoreExpr) -> Result<AAtom, LowerError> {
    match e {
        CoreExpr::Literal { value, .. } => match value {
            LiteralValue::Int(v) => Ok(AAtom::Int(*v)),
            LiteralValue::Float(_)
            | LiteralValue::Str(_)
            | LiteralValue::Bool(_)
            | LiteralValue::Nil
            | LiteralValue::Symbol(_)
            | LiteralValue::Pair(_, _) => Err(LowerError::new(
                "native code PoC boundary: only integer-domain literals supported (Float/Str/Bool/Nil/Symbol/Pair not in the PoC)",
                e.span(),
            )),
        },
        CoreExpr::Var { name, .. } => {
            if let Some(t) = ctx.lookup(*name) {
                Ok(AAtom::Var(t))
            } else if ctx.globals.names.contains_key(name) {
                Err(LowerError::new(
                    "native code PoC boundary: function value one etc transfer not support -- function name only can as is call goal",
                    e.span(),
                ))
            } else {
                // Unbound and not a global function — builtin primitives
                // are not values either (same convention)
                Err(LowerError::new(
                    "native code PoC boundary: from by variable(unbound to formal parameter)not support",
                    e.span(),
                ))
            }
        }
        CoreExpr::If { .. } => {
            // Value-context if: atomize into a temporary (merge via block parameters)
            let t = lower_value_if(ctx, e)?;
            Ok(AAtom::Var(t))
        }
        CoreExpr::Apply { .. } => {
            let t = lower_call(ctx, e)?;
            Ok(AAtom::Var(t))
        }
        CoreExpr::Let { .. } => {
            // r45: the Let chain carries the former Do sequence (value
            // context: intermediate values discarded, tail value returned —
            // lowering recurses node by node)
            let t = lower_let_value(ctx, e)?;
            Ok(AAtom::Var(t))
        }
        CoreExpr::Fn { span, .. } => Err(LowerError::new(
            "native code PoC boundary: lambda appears in value position (closure capture not in the PoC -- language-face closure semantics are jointly carried by later GC-backend batches)",
            *span,
        )),
        CoreExpr::Assign { span, .. } => Err(LowerError::new(
            "native code PoC boundary: assign (mutable assignment) not in the PoC",
            *span,
        )),
        // r49 declaration-layer arms: Define/Module/Require are outside the
        // expression domain (structural rejection by the expander — the
        // three rejection arms are unrepresentable at compile time and
        // removed as dead code per §2.1.1 principle 9)
        // r25/42-f: effect forms are explicitly rejected on the native path
        // (same-shape convention as PoC boundary B1 — the require+print
        // precedent; effect semantics are carried by the VM path, and
        // native effect handling is a Stage 3 backend evolution evaluation
        // item). r136 / 206-b: HandleGroup joins the same rejection family
        // (TD-033 group install — VM path only).
        CoreExpr::Perform { span, .. }
        | CoreExpr::Handle { span, .. }
        | CoreExpr::HandleGroup { span, .. } => Err(LowerError::new(
            "native code PoC boundary: effect forms (perform/handle/handle-group) not in the PoC -- effect semantics are carried by the VM path",
            *span,
        )),
    }
}

/// Tail-expression lowering (Value = atomize; BodyTail = use directly as
/// the Ret payload).
fn lower_tail(ctx: &mut LowerCtxt<'_>, e: &CoreExpr, tctx: TailCtx) -> Result<AAtom, LowerError> {
    match tctx {
        TailCtx::BodyTail => {
            // Tail-position if: structure directly (then/else each Ret — no merge needed)
            if let CoreExpr::If {
                cond,
                then_branch,
                else_branch,
                span,
            } = e
            {
                let cond_atom = lower_bool(ctx, cond)?;
                let cond_t = ensure_temp(ctx, cond_atom, *span)?;
                // The then target is known immediately (the next block); the
                // else target must be back-filled — a nested if inside the
                // then branch splits into multiple blocks, unpredictable at
                // seal time (jump back-fill, same shape as §19.3 invariant
                // 2: placeholder u32::MAX, back-filled once the branch is
                // lowered)
                let br_idx = ctx.blocks.len() - 1;
                let then_label = ALabel(ctx.blocks.len() as u32);
                ctx.seal_block(ACtrl::Br {
                    cond: cond_t,
                    t: then_label,
                    f: ALabel(u32::MAX),
                });
                // then block: terminates itself under the BodyTail contract
                // (recursively splits when the branch item is an if)
                ctx.start_block(Vec::new());
                lower_tail(ctx, then_branch, TailCtx::BodyTail)?;
                // else block index = current length once the then chain has settled (back-fill)
                let else_label = ALabel(ctx.blocks.len() as u32);
                if let Some(ACtrl::Br { f, .. }) = ctx.ctrls[br_idx].as_mut() {
                    *f = else_label;
                }
                ctx.start_block(Vec::new());
                lower_tail(ctx, else_branch, TailCtx::BodyTail)?;
                Ok(AAtom::Int(0)) // unreachable payload (both branches already terminated)
            } else if let CoreExpr::Let { .. } = e {
                // r45: tail-position Let chain (the former tail-position
                // begin): discard values one by one + tail recursion
                // (the BodyTail contract is propagated)
                lower_let_tail(ctx, e)
            } else {
                // Non-branching tail: terminate in place after atomization
                let atom = lower_atom(ctx, e)?;
                ctx.seal_block(ACtrl::Ret(atom));
                Ok(atom)
            }
        }
        TailCtx::Value => lower_atom(ctx, e),
    }
}

/// Boolean condition atomization (comparison primitives such as `(< a b)`
/// produce boolean temporaries — integers 0/1).
fn lower_bool(ctx: &mut LowerCtxt<'_>, e: &CoreExpr) -> Result<AAtom, LowerError> {
    lower_atom(ctx, e)
}

/// Atom → temporary (returned directly if already a Var; an Int is
/// materialized into a binding).
fn ensure_temp(ctx: &mut LowerCtxt<'_>, a: AAtom, span: Span) -> Result<ATemp, LowerError> {
    match a {
        AAtom::Var(t) => Ok(t),
        AAtom::Int(v) => {
            // Literal condition: constant-folded into a temporary binding
            // (e.g. (if 1 ...) — the type-lenient case)
            let t = ctx.fresh_temp();
            let idx = ctx.blocks.len() - 1;
            // Take the isomorphic path through emit (the Prim mapping lacks
            // a unary identity — realized as Add 0)
            ctx.blocks[idx].1.push(AStmt {
                dst: t,
                op: AOp::Prim(APrim::Add, vec![AAtom::Int(v), AAtom::Int(0)]),
                span,
            });
            Ok(t)
        }
    }
}

/// Value-context if: merge via block parameters (then/else each Jmp merge(value)).
fn lower_value_if(ctx: &mut LowerCtxt<'_>, e: &CoreExpr) -> Result<ATemp, LowerError> {
    let CoreExpr::If {
        cond,
        then_branch,
        else_branch,
        span,
    } = e
    else {
        unreachable!("call site already matched If");
    };
    let cond_atom = lower_atom(ctx, cond)?;
    let cond_t = ensure_temp(ctx, cond_atom, *span)?;
    // Back-fill protocol (nested ifs inside then/else can each split into
    // multiple blocks — three back-fills: Br.f and the two tail
    // Jmp.targets; phi source labels = actual jump block indices)
    let br_idx = ctx.blocks.len() - 1;
    let then_label = ALabel(ctx.blocks.len() as u32);
    ctx.seal_block(ACtrl::Br {
        cond: cond_t,
        t: then_label,
        f: ALabel(u32::MAX),
    });
    // then block → tail Jmp merge placeholder (tv materialized — phi
    // sources must be temporaries)
    ctx.start_block(Vec::new());
    let tv = lower_tail(ctx, then_branch, TailCtx::Value)?;
    let tv_t = ensure_temp(ctx, tv, then_branch.span())?;
    let then_tail = ctx.blocks.len() - 1;
    ctx.seal_block(ACtrl::Jmp {
        target: ALabel(u32::MAX),
    });
    // else block (index back-fills Br.f)
    let else_label = ALabel(ctx.blocks.len() as u32);
    if let Some(ACtrl::Br { f, .. }) = ctx.ctrls[br_idx].as_mut() {
        *f = else_label;
    }
    ctx.start_block(Vec::new());
    let ev = lower_tail(ctx, else_branch, TailCtx::Value)?;
    let ev_t = ensure_temp(ctx, ev, else_branch.span())?;
    let else_tail = ctx.blocks.len() - 1;
    ctx.seal_block(ACtrl::Jmp {
        target: ALabel(u32::MAX),
    });
    // merge block: back-fill both Jumps + phi (sources = tail block labels)
    let merge_label = ALabel(ctx.blocks.len() as u32);
    if let Some(ACtrl::Jmp { target }) = ctx.ctrls[then_tail].as_mut() {
        *target = merge_label;
    }
    if let Some(ACtrl::Jmp { target }) = ctx.ctrls[else_tail].as_mut() {
        *target = merge_label;
    }
    let result = ctx.fresh_temp();
    let then_phi_src = ALabel(then_tail as u32);
    let else_phi_src = ALabel(else_tail as u32);
    ctx.start_block(vec![APhi {
        dst: result,
        sources: vec![
            (then_phi_src, AAtom::Var(tv_t)),
            (else_phi_src, AAtom::Var(ev_t)),
        ],
    }]);
    Ok(result)
}

/// Apply lowering (a call — the callee must be a Var that hits a global
/// function or a primitive).
fn lower_call(ctx: &mut LowerCtxt<'_>, e: &CoreExpr) -> Result<ATemp, LowerError> {
    let CoreExpr::Apply {
        fn_expr,
        args,
        span,
    } = e
    else {
        unreachable!("call site already matched Apply");
    };
    // Callee shape: Var (direct call / primitive) — everything else (direct
    // application of a lambda, etc.) is out of boundary
    let CoreExpr::Var { name, .. } = fn_expr.as_ref() else {
        return Err(LowerError::new(
            "native code PoC boundary: callee-er must be function name (directly call) -- compute output function value not support",
            fn_expr.span(),
        ));
    };
    let name_str = ctx.table.name(*name);

    // Primitive path (the twelve builtin items of the PoC surface)
    if let Some(prim) = APrim::from_builtin_name(name_str) {
        if !ctx.globals.names.contains_key(name) {
            let (lo, hi) = prim_arity(prim);
            if args.len() < lo || args.len() > hi {
                return Err(LowerError::new(
                    format!(
                        "primitive `{}` argument count mismatch:{}(expected {}..={})",
                        name_str,
                        args.len(),
                        lo,
                        hi
                    ),
                    *span,
                ));
            }
            let mut atoms = Vec::with_capacity(args.len());
            for a in args {
                atoms.push(lower_atom(ctx, a)?);
            }
            return Ok(ctx.emit(AOp::Prim(prim, atoms), *span));
        }
        // A user function of the same name shadows the primitive (the
        // global function table takes precedence — a conservative ruling
        // consistent with the VM's LOAD_GLOBAL precedence semantics: when a
        // define shadows, the call path is taken)
    }

    // Global function call path
    let Some(fname) = ctx.globals.names.get(name).cloned() else {
        return Err(LowerError::new(
            format!(
                "native code PoC boundary: call target `{}` is not a defined function and not on the PoC primitive face (print/IO etc. builtins are not in native code)",
                name_str
            ),
            *span,
        ));
    };
    let expect = ctx.globals.arities[name];
    if args.len() != expect {
        return Err(LowerError::new(
            format!(
                "call `{}` argument count mismatch:{}(definition {})",
                name_str,
                args.len(),
                expect
            ),
            *span,
        ));
    }
    let mut atoms = Vec::with_capacity(args.len());
    for a in args {
        atoms.push(lower_atom(ctx, a)?);
    }
    Ok(ctx.emit(
        AOp::Call {
            func: fname,
            args: atoms,
        },
        *span,
    ))
}

/// Value-context Let chain (r45 — the carrying form of the former Do
/// sequence's responsibilities: intermediate values discarded, tail value
/// returned; bound names are not installed — value-discarding semantics on
/// the qbe PoC domain, lexical binding is carried by the VM path).
fn lower_let_value(ctx: &mut LowerCtxt<'_>, e: &CoreExpr) -> Result<ATemp, LowerError> {
    let CoreExpr::Let { value, body, .. } = e else {
        unreachable!("call site already matched Let");
    };
    // The intermediate value (the chain node's value) is atomized, evaluated
    // for its effects, then discarded
    let atom = lower_tail(ctx, value, TailCtx::Value)?;
    let _ = atom;
    // Tail: recurse along the chain until a non-Let node
    match body.as_ref() {
        CoreExpr::Let { .. } => lower_let_value(ctx, body),
        sub => {
            let atom = lower_tail(ctx, sub, TailCtx::Value)?;
            ensure_temp(ctx, atom, sub.span())
        }
    }
}

/// Tail-context Let chain (r45 — the former begin tail: the BodyTail
/// contract is propagated to the chain tail).
fn lower_let_tail(ctx: &mut LowerCtxt<'_>, e: &CoreExpr) -> Result<AAtom, LowerError> {
    let CoreExpr::Let { value, body, .. } = e else {
        unreachable!("call site already matched Let");
    };
    // Intermediate value discarded (atomized, evaluated for its effects)
    lower_tail(ctx, value, TailCtx::Value)?;
    lower_tail(ctx, body, TailCtx::BodyTail)
}

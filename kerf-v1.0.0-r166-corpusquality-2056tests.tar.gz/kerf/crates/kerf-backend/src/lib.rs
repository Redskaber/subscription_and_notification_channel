//! kerf-backend: the native-code backend (batch G / 38-b-c — G1 QBE PoC delivery).
//!
//! **Layered position** (15-architecture layering / 13 §3.3.7): the backend
//! layer — consumes the front end's products (`CoreExpr`) and produces
//! target code (QBE IL → assembly → a native executable).
//!
//! **Module map** (r101 / 171-a domain directory-ization — each
//! self-governing domain becomes its own directory, the physical
//! affirmation of the root-space governance idea [24-space-decomposition,
//! unified on both the core-domain and extension-domain sides]: the backend
//! root = shared contract [`codegen`] + shared lowering [`anf]]; the two
//! self-governing target domains live in `wasm/` and `native/`):
//! - [`codegen`]: the multi-target backend contract (the formal home
//!   migrated in from `kerf-driver/reserved/codegen` — signatures frozen
//!   unchanged, principle 27);
//! - [`anf`]: AnnotatedANF IR reification + `CoreExpr` lowering
//!   (block-style ANF — value-context if merges via block parameters);
//! - [`native`]: the native-code domain (QBE IL generation [`native::qbe`] +
//!   external process orchestration [`native::aot`] — the qbe/cc
//!   subprocess chain never enters the self-hosting chain §21.2);
//! - [`wasm`]: the WASM component model domain (a self-governing directory
//!   — the full TD-031 M0-M3 chain): the contract layer [`wasm`]
//!   (r74/144-c — interface types/component boundary/canonical ABI options +
//!   AnnotatedANF → component model derivation); the emitter
//!   [`wasm::emit`] (r92/162-a — M1 realized: ANF → core wasm module binary +
//!   the first real implementation of the
//!   [`wasm::emit::WasmCoreBackend`] trait + `kerf_meta` manifest read-back
//!   reconciliation; the hand-written emitter has zero cargo dependencies —
//!   §18 L-B ruling); the ABI adaptation layer [`wasm::abi`] (r97/167-a —
//!   M2 realized: all three `CanonicalAbiOptions` fields consumed +
//!   boundary module emission via [`wasm::emit::emit_abi_module`];
//!   language-level str literal lowering (an ANF B1 boundary extension) is
//!   not in M2 scope — an independent evolution signal); the composition
//!   layer [`wasm::compose`] (r99/169-a — M3 realized: imports/exports
//!   stitching + five component-level type checks fail-closed + the L-β
//!   effect/capability component instantiation protocol ruling; the
//!   TD-031 final-state piece).
//!
//! **PoC boundary (B1 registration)**: integer-domain primitives /
//! comparison / if / direct calls / recursion; closures, Float/Str/Pair,
//! set!/module, print/IO, and first-class function values are all out of
//! boundary (explicit errors — batches H/I carry them per the 38-a FFI
//! ownership model together with the GC-backend collaboration).

pub mod anf;
pub mod codegen;
pub mod native;
pub mod wasm;

pub use anf::{
    lower_program, AAtom, ABlock, ABody, ACtrl, AFuncDef, ALabel, AOp, APhi, APrim, AStmt, ATemp,
    AnnotatedANF, LowerError,
};
pub use codegen::{
    CodegenBackend, CodegenError, CompiledModule, PassDescriptor, TargetTriple, WasmBackend,
    WasmComponent,
};
pub use native::aot::{build_native, find_qbe, run_native, NativeArtifacts};
pub use native::qbe::{gen_il, QbeBackend};
pub use wasm::abi::{
    align_to_byte_size, align_up, decode_string, encode_string, pages_for, AbiError, AddressWidth,
    CANONICAL_REALLOC_DEFAULT_NAME, PAGE_SIZE,
};
pub use wasm::compose::{
    boundary_class, compose_component, validate_composition, BoundaryClass, ComposedArtifact,
    ComposedComponent, ImportWiring, InstantiateStep, InstantiationPlan, WiringKind,
    ABI_MODULE_NAME, CORE_INSTANCE_NAME,
};
pub use wasm::emit::{
    emit_abi_module, emit_core_module, emit_core_module_linked, parse_core_module_manifest,
    CoreImportFace, ImportFuncSpec, ImportMemorySpec, WasmCoreBackend,
};
pub use wasm::{
    component_model_from_anf, CanonicalAbiOptions, ComponentExport, ComponentFuncType,
    ComponentImport, ComponentModelBuilder, ComponentModelVersion, CoreModuleFunc, InterfaceType,
    StringEncoding, WasmComponentModel, MAX_INTERFACE_TYPE_DEPTH,
};

// ---------------------------------------------------------------------------
// Space affiliation declaration section (r66 / 123-a — the lang-design 24
// v2.0 unified two-side system; 24 §7.2 core-side absorption table: main
// types get three-layer explicit impls [root + core space + domain]
// — the core backend domain (target-code generation — QBE IL / native
// code / multi-target); the contract shape
// [CodegenBackend/WasmBackend supertrait] is in codegen.rs; the sole
// affiliation criterion = marker impl [24 §3 A7])
// ---------------------------------------------------------------------------
use kerf_space::{CoreBackendDomain, CoreSpace, RootSpace};

impl RootSpace for QbeBackend {}
impl CoreSpace for QbeBackend {}
impl CoreBackendDomain for QbeBackend {}
impl RootSpace for TargetTriple {}
impl CoreSpace for TargetTriple {}
impl CoreBackendDomain for TargetTriple {}
impl RootSpace for CompiledModule {}
impl CoreSpace for CompiledModule {}
impl CoreBackendDomain for CompiledModule {}
impl RootSpace for AnnotatedANF {}
impl CoreSpace for AnnotatedANF {}
impl CoreBackendDomain for AnnotatedANF {}
impl RootSpace for PassDescriptor {}
impl CoreSpace for PassDescriptor {}
impl CoreBackendDomain for PassDescriptor {}
impl RootSpace for WasmComponent {}
impl CoreSpace for WasmComponent {}
impl CoreBackendDomain for WasmComponent {}
impl RootSpace for WasmComponentModel {}
impl CoreSpace for WasmComponentModel {}
impl CoreBackendDomain for WasmComponentModel {}
impl RootSpace for WasmCoreBackend {}
impl CoreSpace for WasmCoreBackend {}
impl CoreBackendDomain for WasmCoreBackend {}
impl RootSpace for InterfaceType {}
impl CoreSpace for InterfaceType {}
impl CoreBackendDomain for InterfaceType {}
impl RootSpace for ComposedComponent {}
impl CoreSpace for ComposedComponent {}
impl CoreBackendDomain for ComposedComponent {}
impl RootSpace for InstantiationPlan {}
impl CoreSpace for InstantiationPlan {}
impl CoreBackendDomain for InstantiationPlan {}
impl RootSpace for CoreImportFace {}
impl CoreSpace for CoreImportFace {}
impl CoreBackendDomain for CoreImportFace {}

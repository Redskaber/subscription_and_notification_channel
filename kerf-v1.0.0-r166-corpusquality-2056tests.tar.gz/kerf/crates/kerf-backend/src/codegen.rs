//! Multi-target backend contract (lang-design 13 §3.3.7 — P1, the formal home).
//!
//! **Migration note (38-b, batch G realization landing)**: this module was
//! migrated from `kerf-driver/src/reserved/codegen.rs` (the r12-frozen
//! reserved shape) — per §2.2 principle 27 "signatures stay backward
//! compatible across the whole lifecycle": all contract types and method
//! signatures change zero, and `AnnotatedANF` is reified from the
//! placeholder shape (fingerprint field only) into a full IR carrying the
//! function definition set (the `fingerprint` field is preserved — the
//! content-addressing convention is unchanged).
//! `kerf-driver/reserved/codegen` becomes a thin re-export (historical
//! reference paths keep working — evidence that contract evolution
//! replaces the implementation instead of breaking the contract).
//!
//! **Self-hosting compliance note** (08-backend-evolution / §21.2): the QBE
//! backend is a host-side toolchain (IL generation written in Rust +
//! external qbe/cc subprocess orchestration) and **never enters the
//! self-hosting chain**; `kerf-backend` belongs to the Stage 2 "build
//! bootstrap + backend" base implementing the ~20% Rust portion of the
//! language (12-roadmap §2, same convention).

use crate::anf::AnnotatedANF;
use crate::wasm::WasmComponentModel;

// ---------------------------------------------------------------------------
// Target and artifact shapes (P3 frozen — unchanged by the migration)
// ---------------------------------------------------------------------------

/// Target triple (carried as a string — the `x86_64-unknown-linux-gnu`
/// convention).
#[derive(Debug, Clone, Default, PartialEq, Eq, Hash)]
pub struct TargetTriple(pub String);

/// Compilation artifact (a byte envelope — unified carriage of bytecode /
/// native code / WASM / QBE IL).
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct CompiledModule {
    pub target: TargetTriple,
    pub bytes: Vec<u8>,
}

/// Code-generation error (shape unchanged by the migration; `span` was
/// extended to be optional — process errors from the AOT orchestration
/// layer have no source location).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CodegenError {
    pub reason: String,
}

impl CodegenError {
    /// Constructor helper (§10.1 rule 1 naming: the `new` idiomatic constructor).
    pub fn new(reason: impl Into<String>) -> Self {
        CodegenError {
            reason: reason.into(),
        }
    }
}

/// Optimization pass descriptor (name + target-neutral marker).
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct PassDescriptor {
    pub name: &'static str,
}

// ---------------------------------------------------------------------------
// Backend trait (P1 — contract unchanged by the migration; the Stage 2 QBE
// backend implements the contract)
// ---------------------------------------------------------------------------

/// Target description and code-generation backend.
///
/// **Full behavioral spec** (P1 — migrated from reserved, semantics unchanged):
/// 1. `supported_targets`: the list of targets the backend supports (a
///    capability declaration);
/// 2. `compile`: compile AnnotatedANF into target code (the backend only
///    consumes IR — principle 13 target neutrality; after reification
///    AnnotatedANF carries the function definition set, and `compile`
///    produces the backend target artifact, e.g. QBE IL text);
/// 3. `backend_optimizations`: the list of backend-specific optimizations
///    (distinct from optimizer passes — the optimizer arrives in Stage 3;
///    this list only declares passes inside the backend).
// r66 / 123-a space affiliation (lang-design 24 v2.0 §7.2 — the V8
// zero-affiliation exception absorbed: the CodegenBackend/WasmBackend
// contract supertraits hang on the core backend domain — the core domain's
// first pair of contracts [contracts can also hang on the core domain: the
// core-side "family" shape]; A2 level by level — the three-layer impls of
// kerf-backend's main types are in the space affiliation declaration
// section of lib.rs)
use kerf_space::CoreBackendDomain;

pub trait CodegenBackend: CoreBackendDomain {
    /// Targets supported by the backend.
    fn supported_targets(&self) -> Vec<TargetTriple>;

    /// Compile IR into target code.
    fn compile(
        &self,
        ir: &AnnotatedANF,
        target: &TargetTriple,
    ) -> Result<CompiledModule, CodegenError>;

    /// Backend-specific optimizations.
    fn backend_optimizations(&self) -> Vec<PassDescriptor>;
}

/// WebAssembly backend (the key 2026 requirement: component model +
/// interface types + WASM GC).
///
/// **Reserved contract** (r74/144-c deepening): `compile_component`
/// compiles to the WASM component model — the artifact `WasmComponent`
/// carries a structured component model (M0 contract layer —
/// [`crate::wasm`]); bytecode generation stays trigger-based for M1-M3
/// (TD-031).
pub trait WasmBackend: CoreBackendDomain {
    /// Compile to the WASM component model.
    fn compile_component(&self, ir: &AnnotatedANF) -> Result<WasmComponent, CodegenError>;
}

/// WASM component (shape evolution: r74/144-c — deepened from the "byte
/// envelope placeholder" into a "bytes + structured component model"
/// two-field envelope; `bytes` semantics unchanged + `Default`
/// compatibility unchanged + trait method signatures change zero —
/// principle 27 additive evolution; the literal construction sites were
/// migrated along = this file and the reserved/codegen test anchors).
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct WasmComponent {
    /// Byte envelope (payload of M1 bytecode generation — currently empty,
    /// trigger-based TD-031).
    pub bytes: Vec<u8>,
    /// Structured component model (M0 contract-layer payload — core module
    /// function list + component boundary + canonical ABI options;
    /// [`crate::wasm::component_model_from_anf`]).
    pub model: WasmComponentModel,
}

// ---------------------------------------------------------------------------
// Contract latch tests (migrated along from reserved/codegen.rs — shape
// assertions unchanged + new reification surface)
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use crate::anf::AFuncDef;
    use kerf_space::{CoreSpace, RootSpace};

    /// P1 freeze test (migrated along): the backend trait proves contract
    /// freeze via "a test implementation compiles".
    /// r74/144-c: WasmComponent literal construction sites migrated along
    /// (the model field evolves additively — carrying the M0 derived part,
    /// byte payload semantics unchanged).
    struct ProbeBackend;
    // r66/123-a: after the contract hung on the domain, the probe's full
    // chain is supplied (core-side full chain explicit — 24 §5.1)
    impl RootSpace for ProbeBackend {}
    impl CoreSpace for ProbeBackend {}
    impl CoreBackendDomain for ProbeBackend {}
    impl CodegenBackend for ProbeBackend {
        fn supported_targets(&self) -> Vec<TargetTriple> {
            vec![TargetTriple("bytecode-vm".into())]
        }
        fn compile(
            &self,
            ir: &AnnotatedANF,
            target: &TargetTriple,
        ) -> Result<CompiledModule, CodegenError> {
            if target.0.is_empty() {
                Err(CodegenError::new("empty goal"))
            } else {
                Ok(CompiledModule {
                    target: target.clone(),
                    bytes: ir.fingerprint.to_le_bytes().to_vec(),
                })
            }
        }
        fn backend_optimizations(&self) -> Vec<PassDescriptor> {
            vec![PassDescriptor { name: "none" }]
        }
    }

    struct ProbeWasm;
    impl RootSpace for ProbeWasm {}
    impl CoreSpace for ProbeWasm {}
    impl CoreBackendDomain for ProbeWasm {}
    impl WasmBackend for ProbeWasm {
        fn compile_component(&self, ir: &AnnotatedANF) -> Result<WasmComponent, CodegenError> {
            Ok(WasmComponent {
                bytes: ir.fingerprint.to_le_bytes().to_vec(),
                model: crate::wasm::component_model_from_anf(ir),
            })
        }
    }

    #[test]
    fn codegen_reserved_signatures_are_frozen() {
        // Migration-invariant items: the trait's three method signatures +
        // target-neutral negative case + fingerprint pass-through
        let b = ProbeBackend;
        assert_eq!(b.supported_targets().len(), 1);
        assert!(b
            .compile(&AnnotatedANF::default(), &TargetTriple(String::new()))
            .is_err());
        let ir = AnnotatedANF {
            funcs: Vec::new(),
            fingerprint: 42,
        };
        let m = b.compile(&ir, &TargetTriple("bytecode-vm".into())).unwrap();
        assert_eq!(m.bytes, 42u64.to_le_bytes().to_vec());
        assert_eq!(b.backend_optimizations().len(), 1);
        let w = ProbeWasm;
        let c = w.compile_component(&ir).unwrap();
        assert_eq!(c.bytes, 42u64.to_le_bytes().to_vec());
        // r74/144-c: the structured component model is carried with the
        // artifact (M0 derived-part anchor)
        assert_eq!(c.model.source_fingerprint, 42);
        assert_eq!(c.model.core_funcs.len(), ir.funcs.len());
    }

    #[test]
    fn backend_consumes_ir_not_core_expr() {
        // Type-level proof of principle 13 "target neutrality" (migrated
        // along): compile's input is AnnotatedANF (the IR layer), not
        // CoreExpr — the dependency direction is frozen at the signature
        // level
        fn assert_input_is_ir(_: &AnnotatedANF) {}
        assert_input_is_ir(&AnnotatedANF::default());
        // The fingerprint field is preserved (reification does not break the
        // content-addressing contract)
        let a = AnnotatedANF {
            funcs: Vec::new(),
            fingerprint: 1,
        };
        let b = AnnotatedANF {
            funcs: Vec::new(),
            fingerprint: 1,
        };
        assert_eq!(a, b);
    }

    #[test]
    fn annotated_anf_realization_keeps_default_and_fingerprint() {
        // New reification surface (38-b): Default compatibility (the
        // existing reserved_ext_tests `AnnotatedANF::default()` call paths
        // keep holding) + the funcs field carries the function definition
        // set + Debug rendering is usable
        let ir = AnnotatedANF::default();
        assert!(ir.funcs.is_empty());
        assert_eq!(ir.fingerprint, 0);
        let ir2 = AnnotatedANF {
            funcs: vec![AFuncDef {
                name: "main".into(),
                params: Vec::new(),
                body: Default::default(),
            }],
            fingerprint: 7,
        };
        assert_eq!(ir2.funcs.len(), 1);
        assert_eq!(ir2.funcs[0].name, "main");
        assert_ne!(ir, ir2);
        let s = format!("{:?}", ir2);
        assert!(s.contains("main"));
    }
}

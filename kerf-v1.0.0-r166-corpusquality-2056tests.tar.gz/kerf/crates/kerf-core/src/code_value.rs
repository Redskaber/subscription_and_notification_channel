//! Structured CodeValue: the first-class value representation of code
//! (stage0.md §8.3 / §6.3).
//!
//! ```text
//! pub struct CodeValue {
//!     pub ir: GraphIR,             // the full graph IR
//!     pub span: Span,              // source location
//!     pub scope: ScopeSet,         // scopes
//!     pub type_info: Option<TypeInfo>,
//!     pub free_vars: Vec<Symbol>,  // free variable list
//!     pub stage: Stage,            // stage info (reserved for multi-stage programming)
//! }
//! ```
//!
//! **Responsibility boundary** (§8.3): only a value representation of code,
//! **never performs implicit compilation**. Immutability (§2.2 principle 23):
//! transformations (substitute / alpha_rename) produce new values.
//!
//! Stage 0 uses: the inspection carrier of the `kerf code` subcommand, the
//! type definition of the multi-stage-programming reserved interface
//! `MultiStage::Code` (kerf-driver::reserved), and the code-packaging form
//! for graph IR consumers (compiler/future toolchain).

use kerf_span::Span;
use kerf_syntax::{ScopeSet, Symbol};

use crate::expr::{CoreExpr, ModuleItem};
use crate::ir::{lower_program, IrGraph, NodeId};

/// Stage marker for multi-stage programming (§8.3 `stage: Stage`; a reserved
/// enum ahead of the Stage 2 multi-stage introduction).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum StageLevel {
    /// Current stage (now) — executes at this very stage.
    Now,
    /// Future stage (later) — the code value is generated for the next stage
    /// (`compose_with` composition).
    Later(u32),
}

/// Structured code value (§8.3 capability model; the trait shape is in the
/// design doc — Stage 0 delivers a concrete type, because with a single
/// implementation the inherent API already satisfies substitutability — the
/// type is defined in kerf-core and consumers access it via the crate public
/// API; a trait will be extracted when a second representation appears at
/// Stage 2).
#[derive(Debug, Clone)]
pub struct CodeValue {
    /// The full graph IR (single root: `root` is the root node).
    pub ir: IrGraph,
    /// Root node.
    pub root: NodeId,
    /// Source location.
    pub span: Span,
    /// Scope set.
    pub scopes: ScopeSet,
    /// Free variable list (computed at construction, maintained in sync
    /// across transformations).
    pub free_vars: Vec<Symbol>,
    /// Stage info (reserved for multi-stage programming, §8.3).
    pub stage: StageLevel,
}

impl CodeValue {
    /// Constructs a code value from a single `CoreExpr`.
    pub fn from_expr(expr: &CoreExpr) -> CodeValue {
        let ir = lower_program(&[ModuleItem::Expr(std::rc::Rc::new(expr.clone()))]);
        let root = ir.roots()[0];
        CodeValue {
            span: expr.span(),
            free_vars: expr.free_variable_list(),
            root,
            ir,
            scopes: ScopeSet::new(),
            stage: StageLevel::Now,
        }
    }

    /// Well-formedness check: the root node exists, and the free-variable
    /// declaration matches the graph's **binding-aware** free references.
    pub fn is_well_formed(&self) -> bool {
        if (self.root as usize) >= self.ir.len() {
            return false;
        }
        // The graph's free references (respecting Fn/Define binding shadowing)
        // must match the free_vars declaration
        let refs = free_refs_of_graph(&self.ir, self.root);
        refs.len() == self.free_vars.len() && refs.iter().all(|r| self.free_vars.contains(r))
    }

    /// Free variable list (§8.3 interface contract).
    pub fn free_variables(&self) -> Vec<Symbol> {
        self.free_vars.clone()
    }

    /// Non-mutating transformation: references to `var` are replaced with
    /// `other`'s root (returns a new CodeValue).
    pub fn substitute(&self, var: Symbol, other: &CodeValue) -> CodeValue {
        let ir = self.ir.substitute(var, other.root);
        let free_vars = recompute_free(&ir, self.root);
        CodeValue {
            ir,
            root: self.root,
            span: self.span,
            scopes: self.scopes.clone(),
            free_vars,
            stage: self.stage,
        }
    }

    /// Non-mutating α-renaming: `from` → `to` (returns a new CodeValue).
    pub fn alpha_rename(&self, from: Symbol, to: Symbol) -> CodeValue {
        let ir = self.ir.map_nodes(|_id, node| match node {
            crate::ir::IrNode::Var(name) if *name == from => crate::ir::IrNode::Var(to),
            other => other.clone(),
        });
        let free_vars = self
            .free_vars
            .iter()
            .map(|v| if *v == from { to } else { *v })
            .collect();
        CodeValue {
            ir,
            root: self.root,
            span: self.span,
            scopes: self.scopes.clone(),
            free_vars,
            stage: self.stage,
        }
    }

    /// Multi-stage composition (**reserved interface**, §8.3: implemented at
    /// Stage 2; Stage 0 explicitly returns an unsupported error, never fails
    /// silently, §2.3 principle 4).
    pub fn compose_with(&self, _other: &CodeValue) -> Result<CodeValue, CompositionError> {
        Err(CompositionError::UnsupportedInStage0)
    }
}

/// Composition error (§6.3 interface contract).
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum CompositionError {
    /// Stage 0 does not implement multi-stage composition (reserved interface
    /// frozen, lands at Stage 2).
    UnsupportedInStage0,
}

fn collect_var_refs(ir: &IrGraph, root: NodeId, out: &mut Vec<Symbol>) {
    use crate::ir::IrNode;
    let mut stack = vec![root];
    while let Some(id) = stack.pop() {
        match ir.get_node(id) {
            IrNode::Var(s) => {
                if !out.contains(s) {
                    out.push(*s);
                }
            }
            IrNode::Literal(_) => {}
            IrNode::Fn { body, .. } => stack.push(*body),
            IrNode::Apply { callee, args } => {
                stack.push(*callee);
                stack.extend(args.iter().copied());
            }
            IrNode::If {
                cond,
                then_branch,
                else_branch,
            } => {
                stack.push(*cond);
                stack.push(*then_branch);
                stack.push(*else_branch);
            }
            IrNode::Assign { value, .. } | IrNode::Define { value, .. } => stack.push(*value),
            IrNode::Module { body, .. } => stack.extend(body.iter().copied()),
            IrNode::Let { value, body, .. } => {
                stack.push(*value);
                stack.push(*body);
            }
            IrNode::Perform { effect } => stack.push(*effect),
            IrNode::Handle {
                handler_body, body, ..
            } => {
                stack.push(*handler_body);
                stack.push(*body);
            }
            // r136 / 206-b (D13): per-arm handler bodies + the protected body
            IrNode::HandleGroup { arms, body } => {
                for arm in arms {
                    stack.push(arm.handler_body);
                }
                stack.push(*body);
            }
        }
    }
}

fn recompute_free(ir: &IrGraph, root: NodeId) -> Vec<Symbol> {
    let mut refs = Vec::new();
    collect_var_refs(ir, root, &mut refs);
    refs
}

/// Binding-aware free-reference computation (Fn parameters shadow; Define
/// introduces bindings).
fn free_refs_of_graph(ir: &IrGraph, root: NodeId) -> Vec<Symbol> {
    use crate::ir::IrNode;
    let mut out: Vec<Symbol> = Vec::new();
    let mut bound: Vec<Symbol> = Vec::new();
    fn walk(ir: &IrGraph, id: NodeId, bound: &mut Vec<Symbol>, out: &mut Vec<Symbol>) {
        match ir.get_node(id) {
            IrNode::Var(s) => {
                if !bound.contains(s) && !out.contains(s) {
                    out.push(*s);
                }
            }
            IrNode::Literal(_) => {}
            // r165 / 236-c: the rest parameter is a binder too (free-ref
            // shadowing — the same discipline as the fixed params).
            IrNode::Fn { params, rest, body } => {
                let pushed = params.iter().filter(|p| !bound.contains(p)).count();
                bound.extend(params.iter().copied());
                let rest_pushed = match rest {
                    Some(r) if !bound.contains(r) => {
                        bound.push(*r);
                        true
                    }
                    _ => false,
                };
                walk(ir, *body, bound, out);
                if rest_pushed {
                    bound.pop();
                }
                for _ in 0..pushed {
                    bound.pop();
                }
            }
            IrNode::Apply { callee, args } => {
                walk(ir, *callee, bound, out);
                for a in args {
                    walk(ir, *a, bound, out);
                }
            }
            IrNode::If {
                cond,
                then_branch,
                else_branch,
            } => {
                walk(ir, *cond, bound, out);
                walk(ir, *then_branch, bound, out);
                walk(ir, *else_branch, bound, out);
            }
            IrNode::Assign { name, value } | IrNode::Define { name, value } => {
                walk(ir, *value, bound, out);
                if !bound.contains(name) {
                    bound.push(*name);
                }
            }
            IrNode::Module { body, .. } => {
                for b in body {
                    walk(ir, *b, bound, out);
                }
            }
            IrNode::Let { name, value, body } => {
                // Let binding: value is traversed first (name not yet in
                // bound), then name enters bound to shadow, and is popped
                // after traversing the body (same shape as Fn)
                walk(ir, *value, bound, out);
                let shadowed = !bound.contains(name);
                if shadowed {
                    bound.push(*name);
                }
                walk(ir, *body, bound, out);
                if shadowed {
                    bound.pop();
                }
            }
            IrNode::Perform { effect } => walk(ir, *effect, bound, out),
            IrNode::Handle {
                payload_var,
                resume_var,
                handler_body,
                body,
                ..
            } => {
                // The two binders shadow (same shape as Fn)
                let pushed = [payload_var, resume_var]
                    .iter()
                    .filter(|p| !bound.contains(p))
                    .count();
                bound.push(*payload_var);
                bound.push(*resume_var);
                walk(ir, *handler_body, bound, out);
                walk(ir, *body, bound, out);
                for _ in 0..pushed {
                    bound.pop();
                }
            }
            // r136 / 206-b (D13): per-arm binder shadowing (each arm's two
            // binders enter/leave around its own handler body — sibling
            // scopes; the protected body sees none of them)
            IrNode::HandleGroup { arms, body } => {
                for arm in arms {
                    let pushed = [arm.payload_var, arm.resume_var]
                        .iter()
                        .filter(|p| !bound.contains(p))
                        .count();
                    bound.push(arm.payload_var);
                    bound.push(arm.resume_var);
                    walk(ir, arm.handler_body, bound, out);
                    for _ in 0..pushed {
                        bound.pop();
                    }
                }
                walk(ir, *body, bound, out);
            }
        }
    }
    walk(ir, root, &mut bound, &mut out);
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::expr::LiteralValue;
    use std::rc::Rc;

    fn var(n: u32) -> CoreExpr {
        CoreExpr::Var {
            name: Symbol(n),
            scopes: ScopeSet::new(),
            span: Span::dummy(),
        }
    }

    fn lam(param: u32, body: CoreExpr) -> CoreExpr {
        CoreExpr::Fn {
            params: vec![Symbol(param)],
            param_scopes: vec![ScopeSet::new()],
            rest: None,
            body: Rc::new(body),
            span: Span::dummy(),
        }
    }

    fn app(f: CoreExpr, arg: CoreExpr) -> CoreExpr {
        CoreExpr::Apply {
            fn_expr: Rc::new(f),
            args: vec![Rc::new(arg)],
            span: Span::dummy(),
        }
    }

    #[test]
    fn well_formed_and_free_vars() {
        // (fn (x) (x y)) → free {y}
        let e = lam(0, app(var(0), var(1)));
        let cv = CodeValue::from_expr(&e);
        assert!(cv.is_well_formed());
        assert_eq!(cv.free_variables(), vec![Symbol(1)]);
    }

    #[test]
    fn alpha_rename_rewrites() {
        let e = lam(0, app(var(0), var(1)));
        let cv = CodeValue::from_expr(&e);
        let renamed = cv.alpha_rename(Symbol(1), Symbol(9));
        assert_eq!(renamed.free_variables(), vec![Symbol(9)]);
        assert!(renamed.is_well_formed());
        // Immutable: the original value is unchanged (§2.2 principle 23)
        assert_eq!(cv.free_variables(), vec![Symbol(1)]);
    }

    #[test]
    fn compose_with_reserved_unsupported() {
        let e = CoreExpr::Literal {
            value: LiteralValue::Int(1),
            span: Span::dummy(),
        };
        let a = CodeValue::from_expr(&e);
        assert!(matches!(
            a.compose_with(&a),
            Err(CompositionError::UnsupportedInStage0)
        ));
    }
}

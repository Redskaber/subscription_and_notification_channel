//! # kerf-core
//!
//! **Five orthogonal axes positioning (lang-design 15 §5.3, v6.0)**: axis 1, the
//! invariant side — internal syntax skeleton (private ADT core frozen, principles
//! 9/30; migration mapping freeze maintained — see the expr.rs docs and 01 §8.3,
//! re-evaluated at Stage 3).
//!
//! Core language definition layer: `CoreExpr` (9 orthogonal primitives), graph IR
//! (Arena + shared nodes), and structured `CodeValue` (stage0.md §3.2 / §8.2 / §8.3).
//!
//! Design constraints (§3.2):
//! - **Orthogonal**: the 9 primitives cannot be derived from one another (syntactic
//!   sugar such as `let` must be derived by macro expansion and never enters the core);
//! - **Complete**: all semantics of the language can be expressed with the 9 primitives;
//! - **Stable**: the core is frozen — once defined, it never changes for the entire
//!   language lifetime (§2.2 principle 9).
//!
//! Pipeline data flow (sop.md §2.4.4, compile-time data system):
//! `Stx` (kerf-syntax) → `CoreExpr` (this crate, expansion product)
//! → `IrGraph` (this crate, structured form) → `BcProgram` (kerf-compiler).

pub mod code_value;
pub mod expr;
pub mod ir;

// Explicit re-exports (§10.1 rule 4: glob re-exports are forbidden).
// Convention: this crate exposes all public types of the core language (expr),
// graph IR, and code values.
pub use code_value::{CodeValue, CompositionError, StageLevel};
pub use expr::{Capability, CoreExpr, HandleArm, LiteralValue, ModuleItem};
pub use ir::{lower_program, IrGraph, IrNode, NodeId, NodeMetadata};

// ---------------------------------------------------------------------------
// Space-ownership declaration section (r66 / 123-a — lang-design 24 v2.0 unified
// two-sided system; 24 §7.2 core-side incorporation table: this crate's main types
// get a three-layer explicit impl [root + core space + domain] — core language
// domain (language-defining artifacts — core expressions / graph IR / code values);
// the core-side edition of "declaration-is-ownership", sole ownership criterion =
// marker impl [24 §3 A7])
// ---------------------------------------------------------------------------
use kerf_space::{CoreLanguageDomain, CoreSpace, RootSpace};

impl RootSpace for CoreExpr {}
impl CoreSpace for CoreExpr {}
impl CoreLanguageDomain for CoreExpr {}
impl RootSpace for LiteralValue {}
impl CoreSpace for LiteralValue {}
impl CoreLanguageDomain for LiteralValue {}
impl RootSpace for ModuleItem {}
impl CoreSpace for ModuleItem {}
impl CoreLanguageDomain for ModuleItem {}
impl RootSpace for IrGraph {}
impl CoreSpace for IrGraph {}
impl CoreLanguageDomain for IrGraph {}
impl RootSpace for IrNode {}
impl CoreSpace for IrNode {}
impl CoreLanguageDomain for IrNode {}
impl RootSpace for CodeValue {}
impl CoreSpace for CodeValue {}
impl CoreLanguageDomain for CodeValue {}
impl RootSpace for StageLevel {}
impl CoreSpace for StageLevel {}
impl CoreLanguageDomain for StageLevel {}

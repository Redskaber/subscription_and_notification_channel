//! Graph IR (with shared nodes): the Arena-structured form of a program
//! (stage0.md §8.2).
//!
//! **Capability model** (§8.2):
//! - Arena allocation (`NodeId` indexing), with node metadata (Span + scopes)
//!   stored in parallel tables;
//! - `node_map`: structural key → node list (**supports shared lookup** —
//!   common-subexpression/constant sharing);
//! - Non-mutating transformation APIs (`map_nodes` / `substitute`) return new
//!   graphs.
//!
//! **Stage 0 sharing strategy** (the established mitigation for risk-table
//! §21.11 "graph IR implementation is overly complex"): literal and variable
//! nodes are fully deduplicated and shared by structural key; composite nodes
//! get no aggressive CSE (explicitly deferred — TD-003 v6.3/r27 re-ruled to
//! the Stage 3 optimization window: CSE-style sharing currently has zero
//! consumers, trigger-based re-evaluation).
//!
//! **Responsibility boundary** (§8.2): represents the structured form of a
//! program; does not perform evaluation, type inference, or control-flow
//! execution ordering.

use std::collections::HashMap;
use std::rc::Rc;

use kerf_span::Span;
use kerf_syntax::{ScopeSet, Symbol};

use crate::expr::{CoreExpr, LiteralValue, ModuleItem};

/// Arena node index.
pub type NodeId = u32;

/// IR node (§8.2 `IRNode`; per-node metadata lives in the `NodeMetadata`
/// parallel table).
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub enum IrNode {
    Fn {
        params: Vec<Symbol>,
        /// r165 / 236-c (variadic-rest-design.md D2-b): the rest binding —
        /// `Some(name)` when the source fn declares `...name: T`. The rest
        /// slot = `params.len()` by construction (the compiler validates the
        /// invariant at emission).
        rest: Option<Symbol>,
        body: NodeId,
    },
    Apply {
        callee: NodeId,
        args: Vec<NodeId>,
    },
    If {
        cond: NodeId,
        then_branch: NodeId,
        else_branch: NodeId,
    },
    Var(Symbol),
    Literal(LiteralKey),
    Assign {
        name: Symbol,
        value: NodeId,
    },
    Define {
        name: Symbol,
        value: NodeId,
    },
    /// Local binding + sequencing (r45/E5 S3 structural arm — the IR
    /// counterpart of CoreExpr::Let; `Do`'s sequencing responsibility is
    /// absorbed here: on the graph-IR side, Let is the ANF anchor [the
    /// query-graph shape of 21 §5.3 M-A's "explicit compile-time
    /// local-binding anchor"]; `IrNode::Do` was deleted together with the
    /// elimination of `CoreExpr::Do` [dead code with no producers —
    /// §2.1.1 principle 9]).
    Let {
        name: Symbol,
        value: NodeId,
        body: NodeId,
    },
    Module {
        name: Symbol,
        imports: Vec<Symbol>,
        exports: Vec<Symbol>,
        body: Vec<NodeId>,
    },
    /// Effect perform (r25/42-f — direct translation of effect-language-design
    /// §2.1/R10).
    Perform {
        effect: NodeId,
    },
    /// Effect handling (shallow handling — the payload/resume binders
    /// introduce a fresh scope, same shape as Fn; the tag is the
    /// symbol-literal same-shape `Rc<str>`).
    Handle {
        tag: Rc<str>,
        payload_var: Symbol,
        resume_var: Symbol,
        handler_body: NodeId,
        body: NodeId,
    },
    /// r136 / 206-b (TD-033 — group install): all arms in one node (the
    /// graph-IR mirror of `CoreExpr::HandleGroup`; per-arm binder scopes
    /// are lowered with independent fresh scopes, mirroring the expander's
    /// per-arm injection — handle-multi-arm-design.md §8 D13).
    HandleGroup {
        arms: Vec<IrHandleArm>,
        body: NodeId,
    },
}

/// One arm of the graph-IR `HandleGroup` node (r136 / 206-b — D13).
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct IrHandleArm {
    pub tag: Rc<str>,
    pub payload_var: Symbol,
    pub resume_var: Symbol,
    pub handler_body: NodeId,
}

/// Literal structural key (the minimal hashable-shareable form; runtime
/// values are carried by the compiler's constant pool).
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub enum LiteralKey {
    Int(i64),
    Str(Rc<str>),
    Bool(bool),
    Nil,
    /// Float key: expanded bit-wise (f64 does not implement Eq/Hash; Stage 0
    /// keys on the bit pattern).
    FloatBits(u64),
    /// Symbol key (deduplicated by name — TD-002).
    Symbol(Rc<str>),
}

impl LiteralKey {
    /// Distills the hashable key from a `LiteralValue` (Pair structures do
    /// not participate in sharing dedup — single instances are kept).
    pub fn from_value(v: &LiteralValue) -> LiteralKey {
        match v {
            LiteralValue::Int(i) => LiteralKey::Int(*i),
            LiteralValue::Float(f) => LiteralKey::FloatBits(f.to_bits()),
            LiteralValue::Str(s) => LiteralKey::Str(s.clone()),
            LiteralValue::Bool(b) => LiteralKey::Bool(*b),
            LiteralValue::Nil => LiteralKey::Nil,
            LiteralValue::Symbol(s) => LiteralKey::Symbol(s.clone()),
            LiteralValue::Pair(..) => LiteralKey::Nil,
        }
    }
}

/// Node metadata (§8.2: every node carries Span and scope information).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct NodeMetadata {
    pub span: Span,
    pub scopes: ScopeSet,
}

/// Graph IR: Arena + shared-lookup table + root node set.
#[derive(Debug, Clone, Default)]
pub struct IrGraph {
    nodes: Vec<IrNode>,
    metadata: Vec<NodeMetadata>,
    /// Structural key → shared-node list (supports shared lookup, §8.2
    /// interface contract `find_shared`).
    node_map: HashMap<LiteralKey, Vec<NodeId>>,
    roots: Vec<NodeId>,
}

impl IrGraph {
    /// An empty graph.
    pub fn new() -> Self {
        IrGraph::default()
    }

    /// Constructs a node (metadata required — Span must not be empty, §3.3).
    pub fn add_node(&mut self, node: IrNode, meta: NodeMetadata) -> NodeId {
        let id = self.nodes.len() as NodeId;
        self.nodes.push(node);
        self.metadata.push(meta);
        id
    }

    /// Constructs a **shared** literal node: a structural-key hit reuses the
    /// existing node (common-subexpression sharing).
    pub fn add_shared_literal(&mut self, key: LiteralKey, meta: NodeMetadata) -> NodeId {
        if let Some(existing) = self.node_map.get(&key).and_then(|ids| ids.first()).copied() {
            return existing;
        }
        let id = self.add_node(IrNode::Literal(key.clone()), meta);
        self.node_map.entry(key).or_default().push(id);
        id
    }

    /// Looks up a node.
    pub fn get_node(&self, id: NodeId) -> &IrNode {
        &self.nodes[id as usize]
    }

    /// Looks up node metadata.
    pub fn get_metadata(&self, id: NodeId) -> &NodeMetadata {
        &self.metadata[id as usize]
    }

    /// Shared lookup: all nodes with the same structural key (§8.2 interface
    /// contract).
    pub fn find_shared(&self, key: &LiteralKey) -> Vec<NodeId> {
        self.node_map.get(key).cloned().unwrap_or_default()
    }

    /// The root node set.
    pub fn roots(&self) -> &[NodeId] {
        &self.roots
    }

    /// Appends a root node.
    pub fn add_root(&mut self, id: NodeId) {
        self.roots.push(id);
    }

    /// Total node count (post-sharing deduplicated count ≤ construction count).
    pub fn len(&self) -> usize {
        self.nodes.len()
    }

    /// Whether the graph is empty.
    pub fn is_empty(&self) -> bool {
        self.nodes.is_empty()
    }

    /// Iterates over all nodes (ascending by NodeId).
    pub fn iter_nodes(&self) -> impl Iterator<Item = (NodeId, &IrNode)> + '_ {
        self.nodes.iter().enumerate().map(|(i, n)| (i as NodeId, n))
    }

    /// Non-mutating transformation: maps nodes by function (returns a new
    /// graph, metadata preserved). Child-node IDs such as Fn/Apply are not
    /// rewritten automatically — the caller is responsible for mapping
    /// consistency (Stage 0 convention).
    pub fn map_nodes(&self, f: impl Fn(NodeId, &IrNode) -> IrNode) -> IrGraph {
        let mut out = IrGraph {
            nodes: Vec::with_capacity(self.nodes.len()),
            metadata: self.metadata.clone(),
            node_map: self.node_map.clone(),
            roots: self.roots.clone(),
        };
        for (id, node) in self.iter_nodes() {
            out.nodes.push(f(id, node));
        }
        out
    }

    /// Non-mutating transformation: replaces every reference to `var` with the
    /// `replacement` root (returns a new graph).
    pub fn substitute(&self, var: Symbol, replacement: NodeId) -> IrGraph {
        let mut out = IrGraph {
            nodes: Vec::with_capacity(self.nodes.len()),
            metadata: self.metadata.clone(),
            node_map: HashMap::new(),
            roots: self.roots.clone(),
        };
        for (id, node) in self.iter_nodes() {
            let mapped = match node {
                IrNode::Var(name) if *name == var => self.get_node(replacement).clone(),
                other => other.clone(),
            };
            let nid = out.add_node(mapped, self.metadata[id as usize].clone());
            let _ = nid;
        }
        out
    }
}

/// Direct-translation lowering from a `ModuleItem` program / `CoreExpr`
/// expression to the graph IR.
///
/// Public entry point (sop.md §10.1 rule 1: `<verb>_<noun>` free function).
/// The top-level items' IDs are registered as the graph's roots in order
/// (r49 declaration-layer arm: item-level entry — declaration items
/// [Define/Require/Module] translate directly, expression items go through
/// `lower_expr`, 22 §17 D59).
pub fn lower_program(items: &[ModuleItem]) -> IrGraph {
    let mut graph = IrGraph::new();
    let mut scopes = ScopeSet::new();
    for item in items {
        let id = lower_item(&mut graph, item, &mut scopes);
        graph.add_root(id);
    }
    graph
}

/// Item-level lowering (declaration items translate directly + expression
/// items recurse).
fn lower_item(graph: &mut IrGraph, item: &ModuleItem, scopes: &mut ScopeSet) -> NodeId {
    let meta = NodeMetadata {
        span: item.span(),
        scopes: scopes.clone(),
    };
    match item {
        ModuleItem::Define { name, value, .. } => {
            let v = lower_expr(graph, value, scopes);
            graph.add_node(
                IrNode::Define {
                    name: *name,
                    value: v,
                },
                meta,
            )
        }
        ModuleItem::Require { .. } => {
            // r8 capability declaration: zero runtime semantics — lowered to
            // a nil literal node (graph connectivity preserved; compile-time
            // permission validation happens in the driver front pipeline,
            // not an IR responsibility)
            graph.add_shared_literal(LiteralKey::from_value(&LiteralValue::Nil), meta)
        }
        ModuleItem::Module {
            name,
            imports,
            exports,
            items,
            ..
        } => {
            let ids: Vec<NodeId> = items.iter().map(|i| lower_item(graph, i, scopes)).collect();
            graph.add_node(
                IrNode::Module {
                    name: *name,
                    imports: imports.clone(),
                    exports: exports.clone(),
                    body: ids,
                },
                meta,
            )
        }
        ModuleItem::Expr(e) => lower_expr(graph, e, scopes),
    }
}

fn lower_expr(graph: &mut IrGraph, e: &CoreExpr, scopes: &mut ScopeSet) -> NodeId {
    let meta = NodeMetadata {
        span: e.span(),
        scopes: scopes.clone(),
    };
    match e {
        CoreExpr::Literal { value, .. } => {
            graph.add_shared_literal(LiteralKey::from_value(value), meta)
        }
        CoreExpr::Var { name, .. } => graph.add_node(IrNode::Var(*name), meta),
        CoreExpr::Fn {
            params, rest, body, ..
        } => {
            // The binding introduces a new scope (mark, the IR-side mirror of
            // the §19.2 expansion-side semantics)
            let scope = fresh_scope();
            scopes.add(scope);
            let body_id = lower_expr(graph, body, scopes);
            scopes.remove(scope);
            graph.add_node(
                IrNode::Fn {
                    params: params.clone(),
                    rest: rest.as_ref().map(|(r, _)| *r),
                    body: body_id,
                },
                meta,
            )
        }
        CoreExpr::Apply { fn_expr, args, .. } => {
            let callee = lower_expr(graph, fn_expr, scopes);
            let arg_ids: Vec<NodeId> = args.iter().map(|a| lower_expr(graph, a, scopes)).collect();
            graph.add_node(
                IrNode::Apply {
                    callee,
                    args: arg_ids,
                },
                meta,
            )
        }
        CoreExpr::If {
            cond,
            then_branch,
            else_branch,
            ..
        } => {
            let c = lower_expr(graph, cond, scopes);
            let t = lower_expr(graph, then_branch, scopes);
            let el = lower_expr(graph, else_branch, scopes);
            graph.add_node(
                IrNode::If {
                    cond: c,
                    then_branch: t,
                    else_branch: el,
                },
                meta,
            )
        }
        CoreExpr::Assign { name, value, .. } => {
            let v = lower_expr(graph, value, scopes);
            graph.add_node(
                IrNode::Assign {
                    name: *name,
                    value: v,
                },
                meta,
            )
        }
        CoreExpr::Let {
            name, value, body, ..
        } => {
            let v = lower_expr(graph, value, scopes);
            // The graph-IR expression of Let: the value is a named node
            // (ANF anchor — the query-graph shape of 21 §5.3 M-A's "explicit
            // compile-time local-binding anchor").
            let b = lower_expr(graph, body, scopes);
            graph.add_node(
                IrNode::Let {
                    name: *name,
                    value: v,
                    body: b,
                },
                meta,
            )
        }
        CoreExpr::Perform { effect, .. } => {
            let e = lower_expr(graph, effect, scopes);
            graph.add_node(IrNode::Perform { effect: e }, meta)
        }
        CoreExpr::Handle {
            tag,
            payload_var,
            resume_var,
            handler_body,
            body,
            ..
        } => {
            // Fresh scope for the two binders (mirrors Fn's scope semantics —
            // TD-004)
            let scope = fresh_scope();
            scopes.add(scope);
            let h = lower_expr(graph, handler_body, scopes);
            let b = lower_expr(graph, body, scopes);
            scopes.remove(scope);
            graph.add_node(
                IrNode::Handle {
                    tag: tag.clone(),
                    payload_var: *payload_var,
                    resume_var: *resume_var,
                    handler_body: h,
                    body: b,
                },
                meta,
            )
        }
        CoreExpr::HandleGroup { arms, body, .. } => {
            // r136 / 206-b (D13): per-arm fresh scope (independent injection —
            // sibling scopes; the protected body lowers outside them)
            let mut ir_arms: Vec<IrHandleArm> = Vec::with_capacity(arms.len());
            for arm in arms {
                let scope = fresh_scope();
                scopes.add(scope);
                let h = lower_expr(graph, &arm.handler_body, scopes);
                scopes.remove(scope);
                ir_arms.push(IrHandleArm {
                    tag: arm.tag.clone(),
                    payload_var: arm.payload_var,
                    resume_var: arm.resume_var,
                    handler_body: h,
                });
            }
            let b = lower_expr(graph, body, scopes);
            graph.add_node(
                IrNode::HandleGroup {
                    arms: ir_arms,
                    body: b,
                },
                meta,
            )
        }
    }
}

/// Scope counter (crate-level singleton semantics: test concurrency is not
/// a concern; IR marker uniqueness suffices).
fn fresh_scope() -> u32 {
    use std::sync::atomic::{AtomicU32, Ordering};
    static NEXT: AtomicU32 = AtomicU32::new(10_000);
    NEXT.fetch_add(1, Ordering::Relaxed)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn lit(v: i64) -> Rc<CoreExpr> {
        Rc::new(CoreExpr::Literal {
            value: LiteralValue::Int(v),
            span: Span::dummy(),
        })
    }

    /// r49 D59: expression-item wrapper fixture.
    fn items(exprs: Vec<Rc<CoreExpr>>) -> Vec<ModuleItem> {
        exprs.into_iter().map(ModuleItem::Expr).collect()
    }

    #[test]
    fn shared_literal_dedup() {
        let exprs = vec![
            Rc::new(CoreExpr::Apply {
                fn_expr: lit(1),
                args: vec![],
                span: Span::dummy(),
            }),
            lit(1),
            lit(1),
            lit(2),
        ];
        let graph = lower_program(&items(exprs));
        // (1) Sharing hit: the three Int(1) occurrences should yield a single
        // Literal node
        let shared = graph.find_shared(&LiteralKey::Int(1));
        assert_eq!(shared.len(), 1);
        let shared2 = graph.find_shared(&LiteralKey::Int(2));
        assert_eq!(shared2.len(), 1);
        // (2) Root count intact; total nodes = 1 Apply + 1 shared Int(1) + 1
        // Int(2)
        assert_eq!(graph.roots().len(), 4);
        assert_eq!(graph.len(), 3);
    }

    #[test]
    fn substitute_rewrites_var() {
        let exprs = vec![
            Rc::new(CoreExpr::Var {
                name: Symbol(1),
                scopes: kerf_syntax::ScopeSet::new(),
                span: Span::dummy(),
            }),
            Rc::new(CoreExpr::Var {
                name: Symbol(2),
                scopes: kerf_syntax::ScopeSet::new(),
                span: Span::dummy(),
            }),
        ];
        let graph = lower_program(&items(exprs));
        let graph2 = graph.substitute(Symbol(1), graph.roots()[1]);
        // After substitution, root 0 becomes Var(2)
        let root0 = graph2.roots()[0];
        match graph2.get_node(root0) {
            IrNode::Var(s) => assert_eq!(*s, Symbol(2)),
            other => panic!("expected Var, got {:?}", other),
        }
    }

    #[test]
    fn map_nodes_returns_new_graph() {
        let exprs = vec![lit(42)];
        let graph = lower_program(&items(exprs));
        let mapped = graph.map_nodes(|_id, node| node.clone());
        assert_eq!(mapped.len(), graph.len());
        assert_eq!(mapped.get_node(0), graph.get_node(0));
    }
}

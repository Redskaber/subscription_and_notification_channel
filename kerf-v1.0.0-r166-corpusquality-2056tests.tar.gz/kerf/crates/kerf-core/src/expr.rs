//! `CoreExpr`: the 9 orthogonal core primitives (stage0.md §3.2 final
//! definition — name-surface r44/E5 S3 M-R arm same-root naming + structural
//! r45/E5 S3 structural arm: `Let` introduced [21 §5.3 M-A — ANF anchor] +
//! `Do` eliminated [M-D — do→Let chain desugaring, 22 §14 D42] + r49/E5 S3
//! declaration-layer arm: the `Define`/`Module`/`Require` three variants moved
//! up to the `ModuleItem` declaration layer [22 §17 D59 — M-D + M-L — the
//! expression ADT no longer carries declaration/organization responsibilities]).
//!
//! ```ocaml
//! type core_expr =
//!   | Fn of { params : string list; body : core_expr }        (* surface fn *)
//!   | Apply of { fn_expr : core_expr; args : core_expr list } (* call — no keyword *)
//!   | If of { cond; then_branch; else_branch }
//!   | Var of string                                          (* reference — no keyword *)
//!   | Literal of literal_value                               (* literal — no keyword *)
//!   | Assign of { name : string; value : core_expr }          (* surface assign *)
//!   | Let of { name : string; value : core_expr; body : core_expr } (* r45 M-A; desugaring target of surface let/do *)
//!   | Perform of { effect : core_expr }                       (* r25 effect perform *)
//!   | Handle of { ... }                                       (* r25 effect handling *)
//!
//! type module_item =                        (* r49 D59 — declaration layer (program/module body items) *)
//!   | Define of { name : string; value : core_expr }          (* M-D moved up *)
//!   | Require of { caps : capability list }                   (* declaration variant returned home *)
//!   | Module of { name; imports; exports; items : module_item list } (* M-L hierarchy migration *)
//!   | Expr of core_expr                                       (* expression item — isomorphic to Python ast.Expr *)
//! ```
//!
//! r45 structural arm (22 §14 D41-D45): the `Do` variant is eliminated —
//! `(do e1 e2 ...)` expands into a `Let` chain (fixed name "do": user Vars
//! cannot reference the reserved-word name, so nested shadowing is harmless);
//! in discard-mode compilation (body does not reference the bound name) the
//! result is instruction-for-instruction identical to the original Do sequence
//! (e5-plan §3.2 S3, the strictest bytecode parity criterion); the
//! `let`/`let*`/`letrec` sugars map directly onto `Let` (D43 — D34 one
//! semantics one name: let ∈ Keyword and kind_name = "let").
//!
//! Every AST node carries a Span (§8.6: Span propagates through the whole
//! pipeline, compile-time segment).

use std::rc::Rc;

use kerf_span::Span;
use kerf_syntax::{ScopeSet, Symbol};

/// Core-layer literal value (§3.2 `literal_value`).
#[derive(Debug, Clone, PartialEq)]
pub enum LiteralValue {
    Int(i64),
    Float(f64),
    Str(Rc<str>),
    Bool(bool),
    Nil,
    /// Symbol value (quote symbol datum — TD-002; stores the base name with
    /// the hygiene suffix stripped).
    Symbol(Rc<str>),
    Pair(Rc<LiteralValue>, Rc<LiteralValue>),
}

impl LiteralValue {
    /// Data-oriented rendering (the printed form of quote products).
    pub fn render(&self) -> String {
        match self {
            LiteralValue::Int(i) => i.to_string(),
            LiteralValue::Float(f) => {
                if f.fract() == 0.0 && f.is_finite() {
                    format!("{:.1}", f)
                } else {
                    f.to_string()
                }
            }
            LiteralValue::Str(s) => format!("{:?}", s),
            LiteralValue::Bool(b) => b.to_string(),
            LiteralValue::Nil => "nil".to_string(),
            LiteralValue::Symbol(s) => s.to_string(),
            LiteralValue::Pair(a, b) => {
                // Classic Scheme list printing: non-trivial tail lists render
                // in dotted-pair form
                let mut parts = vec![render_elem(a)];
                let mut tail = b;
                loop {
                    match tail.as_ref() {
                        LiteralValue::Pair(hd, tl) => {
                            parts.push(render_elem(hd));
                            tail = tl;
                        }
                        LiteralValue::Nil => return format!("({})", parts.join(" ")),
                        other => {
                            parts.push(".".to_string());
                            parts.push(render_elem(&Rc::new(other.clone())));
                            return format!("({})", parts.join(" "));
                        }
                    }
                }
            }
        }
    }
}

fn render_elem(v: &Rc<LiteralValue>) -> String {
    v.render()
}

/// The 9 orthogonal core primitives (core frozen — signatures never change
/// for the entire lifetime, §2.2 principle 9).
///
/// **Frozen-boundary refinement (lang-design 01 §6, v5.4)**: what is frozen
/// is the semantic primitive set (9 orthogonal, complete primitives + the
/// `Require` declaration variant — a metadata node with zero runtime
/// semantics); declaration variants may be appended.
///
/// **Internal-syntax three-principle compliance (lang-design 01 §8.2, v6.0 —
/// sop §2.2 principles 29-31)**: this enum is a compiler-private ADT (Rust
/// private-construction semantics — user code cannot construct it; safety is
/// guaranteed by the type system rather than naming conventions); surface
/// S-expressions bridge into this type via kerf-reader → kerf-expander (no
/// bypass); Span carries metadata independently (`kind_name` is used only for
/// diagnostic rendering).
///
/// **E5 S3 M-R name-surface arm (r44 — 22 §13 D34-D40)**: same-root naming
/// between variant names and surface keywords has landed — the five M-R
/// renames `Fn`/`Assign`/`Do`/`Apply`/`Var` (zero semantic payload, through
/// the E5-window S3 leg channel); `If→Branch`/`Literal→Const` were two NO-GOs
/// (rejected by the consistency criterion — 22 §13 D35); the structural arm
/// (Define desugaring / Do→Let chain / Module migration / de Bruijn IR) is
/// carried by r45+ (D39 split-arm ruling).
///
/// **Stage 2 ADT evolution targets (lang-design 01 §8.3 migration mapping —
/// freeze maintained: the K1 final-gate review r35 + K2 deep review r36
/// re-confirmed the freeze; the migration window is re-evaluated with the
/// Stage 3 "target language completion")**:
/// M-R name-surface arm ✅ r44 (Fn/Apply/Assign/Do/Var); If/Literal retained
/// (D35 NO-GO corrected 01 §8.3's original candidates Branch/Const);
/// Define→desugared away / Do→`Let` chain / Module→module-system layer /
/// de Bruijn = r45+ structural arm (D39); the new `Let`+`Perform`/`Handle`
/// are already in place (r25). Migrations must go through the §13.2
/// switchover-period refactoring process + committee vote.
#[derive(Debug, Clone, PartialEq)]
pub enum CoreExpr {
    /// `(fn (params...) body)` — `param_scopes[i]` = the **binding scope set**
    /// of the i-th formal parameter (the binder symbol's scope set, TD-004;
    /// parallel and equal in length to `params`, captured by the expander after
    /// fresh-scope injection on the binding form).
    Fn {
        params: Vec<Symbol>,
        param_scopes: Vec<ScopeSet>,
        /// r165 / 236-c (variadic-rest-design.md D2-b): the rest parameter
        /// binding — `Some((name, binding_scopes))` when the fn declares
        /// `...name: T` (the `...` marker consumed by the expander's
        /// parse_params; the fixed params stay in `params`/`param_scopes`).
        /// The binding scope set rides the pair (the max-cardinality subset
        /// resolution needs it — an empty-set fallback would lose to an
        /// outer same-named binding's rank). `None` = fixed arity (the
        /// entire pre-r165 corpus — representation untouched).
        rest: Option<(Symbol, ScopeSet)>,
        body: Rc<CoreExpr>,
        span: Span,
    },
    /// `(fn-expr arg1 arg2 ...)` (call — no surface keyword, positional form)
    Apply {
        fn_expr: Rc<CoreExpr>,
        args: Vec<Rc<CoreExpr>>,
        span: Span,
    },
    /// `(if cond then else)`
    If {
        cond: Rc<CoreExpr>,
        then_branch: Rc<CoreExpr>,
        else_branch: Rc<CoreExpr>,
        span: Span,
    },
    /// `name` (free or bound reference).
    ///
    /// `scopes` = the reference-site scope set (TD-004, r13): the compiler/eval
    /// matches bindings by `(name, scopes ⊆)` (Racket-style set-scope
    /// resolution — an empty-set binding ⊆ any reference set, so
    /// globals/builtins naturally serve as the name-base fallback path).
    Var {
        name: Symbol,
        scopes: ScopeSet,
        span: Span,
    },
    /// Literal (including the pair structures produced by quote)
    Literal { value: LiteralValue, span: Span },
    /// `(assign name value)` — `scopes` = the assignment target symbol's
    /// reference-site scope set (same resolution criterion as Var, TD-004).
    Assign {
        name: Symbol,
        scopes: ScopeSet,
        value: Rc<CoreExpr>,
        span: Span,
    },
    /// `(let (name value) body)` (r45/E5 S3 structural arm D41 — the new
    /// primitive of 21 §5.3 M-A: local binding + sequencing anchor).
    ///
    /// Semantics: evaluate `value` → bind `name` → evaluate `body` (`body`
    /// may reference `name`). `scopes` = the binder symbol's binding scope set
    /// (captured after fresh-scope injection, same criterion as
    /// `Fn.param_scopes`, TD-004).
    ///
    /// Carries three sources (D42/D43): ① the `(let ((name value)...) body...)`
    /// sugar maps directly (nested chain — parallel semantics = nested
    /// evaluation order); ② `(do item...)` desugaring (fixed name "do" —
    /// discard mode: when the compiler statically determines the body does not
    /// reference the bound name, it emits `[value; Pop; body]`, which is
    /// **instruction-for-instruction identical** to the original `Do` item
    /// sequence — a hard bytecode-parity proof); ③ `(letrec ...)` = a
    /// `Let[name, nil]` + `Assign` chain (pre-binding + in-place assignment —
    /// a semantically equivalent expansion).
    ///
    /// **Irreducible responsibility** (21 §5.6 admission criterion ① —
    /// refined by D41): an explicit compile-time local-binding anchor. The
    /// `Fn+Apply` combination is semantically equivalent but structurally
    /// anonymous (one closure of overhead per binding + intermediate values
    /// cannot anchor ANF optimization transforms) — the sixty-year consensus
    /// of the A-normal form canon: naming intermediate values is a
    /// precondition for optimization.
    Let {
        name: Symbol,
        scopes: ScopeSet,
        value: Rc<CoreExpr>,
        body: Rc<CoreExpr>,
        span: Span,
    },
    /// `(perform ⟨effect-value⟩)` (r25/42-f — effect-language-design
    /// §2.1/R10: effect throw. `effect` is evaluated first (the evaluation-order
    /// contract keeps the Apply sequence), and the result must be a
    /// `(tag . payload)` pair (tag = the Symbol dispatch key; any other shape
    /// reports a runtime type error). The control transfer is not a value
    /// reduction — after resume the value is injected at the resume point; if
    /// never resumed, this expression's evaluation never completes (the rest of
    /// the body is discarded by dispatch).
    Perform { effect: Rc<CoreExpr>, span: Span },
    /// `(handle ⟨tag⟩ ((⟨payload-var⟩ ⟨resume-var⟩) ⟨result-expr⟩) ⟨body⟩)`
    /// (R11 — shallow handling, D2: the handler handles one layer of effects;
    /// nested handles = user-side composition of deep handling).
    /// `payload_var`/`resume_var` are binders (binding scope set parallel
    /// fields, same criterion as Fn.param_scopes, TD-004); `resume` is not a
    /// standalone primitive — it is the call shape of the continuation value
    /// (D4, desugared to Apply at expansion time).
    Handle {
        /// Effect-family tag (match single-key dispatch — D1: same shape as
        /// the syntax-rules literal set; the symbol-literal same-shape carrier
        /// `Rc<str>` — consistent with LiteralValue::Symbol, no symbol table
        /// needed on the compilation side).
        tag: Rc<str>,
        payload_var: Symbol,
        /// The payload binder's binding scope set (fresh-scope injection,
        /// carried by the expander).
        payload_scopes: ScopeSet,
        resume_var: Symbol,
        /// The resume binder's binding scope set.
        resume_scopes: ScopeSet,
        /// Handler body (single clause — the syntactic carrier of D3 linear
        /// uniqueness).
        handler_body: Rc<CoreExpr>,
        /// The protected computation (suspends here when an effect is
        /// triggered). The body's tail position = tail-position threading
        /// (body thunk closure-body semantics — TCO penetrates the handler
        /// frame, D8).
        body: Rc<CoreExpr>,
        span: Span,
    },
    /// r136 / 206-b (TD-033 — handle-multi-arm-design.md §8 D13): group
    /// install — all arms installed as ONE handler frame (multi-tag
    /// matching + group consumption). The Koka-style reading of
    /// 06 §10 [HANDLE-INSTALL] (symmetric non-protection between sibling
    /// arm bodies). Multi-arm (>=2) target-surface handle desugars to
    /// this; the S-expr face writes `(handle-group (tag (p k) result)+
    /// body)` directly. Single-arm `Handle` stays the degenerate 1-entry
    /// case (D1 zero-regression anchor).
    HandleGroup {
        /// Arms in source order (>=2 — the expander enforces; each arm
        /// carries its own binders with independent fresh-scope injection).
        arms: Vec<HandleArm>,
        /// The protected computation (installed under the whole group).
        body: Rc<CoreExpr>,
        span: Span,
    },
}

/// One arm of a `HandleGroup` (r136 / 206-b — D13; same field shape as
/// the single-arm `Handle` minus the outer span).
#[derive(Debug, Clone, PartialEq)]
pub struct HandleArm {
    /// Effect-family tag (multi-key dispatch — same `Rc<str>` carrier).
    pub tag: Rc<str>,
    pub payload_var: Symbol,
    /// The payload binder's binding scope set.
    pub payload_scopes: ScopeSet,
    pub resume_var: Symbol,
    /// The resume binder's binding scope set.
    pub resume_scopes: ScopeSet,
    /// Handler body.
    pub handler_body: Rc<CoreExpr>,
}

/// Capability token kinds (the `(require ...)` declaration item — Stage 1 has
/// only the two I/O kinds; Stage 2 extends with net/process etc. (data-driven
/// extension surface, any-process-node ruling per the F2 fix)).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Capability {
    /// stdin read capability (gates read-line/read-int/read-num).
    IoRead,
    /// stdout write capability (gates print/newline/write-string).
    IoWrite,
}

impl Capability {
    /// Declaration name (for require forms and diagnostic rendering).
    pub fn as_str(self) -> &'static str {
        match self {
            Capability::IoRead => "read",
            Capability::IoWrite => "write",
        }
    }
}

/// Program/module body items (r49 / E5 S3 declaration-layer arm — 22 §17
/// D59: the `Define`/`Require`/`Module` declaration variants moved up out of
/// `CoreExpr`, purifying the expression ADT to the 9 semantic primitives).
///
/// Two-level grammar (SML dec/exp + Python stmt/expr + Racket module-begin —
/// the 2026 consensus of the three families: declarations and expressions are
/// distinct syntactic categories): a program = `Vec<ModuleItem>`, and the
/// expander classifies at item position (after the macro trampoline:
/// declaration-head forms → declaration items; `do` → module-level splice,
/// recursively expanded; everything else → expression items).
///
/// Typing of the position discipline (01 §8.1 principle 1, generalized):
/// define/require/module in expression position is rejected structurally by
/// "` CoreExpr` cannot represent it" (the expander's structural dispatch point
/// reports E0003/E0018/E0023 — replacing the ir.rs proto_depth check and the
/// driver tree walk).
#[derive(Debug, Clone, PartialEq)]
pub enum ModuleItem {
    /// `(define name value)` (item position — M-D moved up; defines at the
    /// head of a function body are still hoisted by the expander into an
    /// assign+fn combination and do not enter this layer).
    Define {
        name: Symbol,
        value: Rc<CoreExpr>,
        span: Span,
    },
    /// `(require io read|write ...)` (item position — the declaration variant
    /// returned home; zero runtime semantics, always nil, consumed by
    /// compile-time permission validation and token minting — the 01 §6
    /// two-layers-never-merge ruling is maintained: the declaration surface
    /// never rises into the semantic layer).
    Require { caps: Vec<Capability>, span: Span },
    /// `(module name (import ...) (export ...) items...)` (item position —
    /// M-L hierarchy migration: the compilation-unit organization form;
    /// imports/exports are namespace-domain payload [consumed by the driver at
    /// the item surface]; body items are classified recursively).
    Module {
        name: Symbol,
        imports: Vec<Symbol>,
        exports: Vec<Symbol>,
        items: Vec<ModuleItem>,
        span: Span,
    },
    /// Expression item (isomorphic to the Python `ast.Expr` wrapper node — a
    /// non-declaration form at item position).
    Expr(Rc<CoreExpr>),
}

impl ModuleItem {
    /// Item Span (expression items take the expression's own Span).
    pub fn span(&self) -> Span {
        match self {
            ModuleItem::Define { span, .. }
            | ModuleItem::Require { span, .. }
            | ModuleItem::Module { span, .. } => *span,
            ModuleItem::Expr(e) => e.span(),
        }
    }

    /// Item name (for diagnostics and dumps — the three declaration names are
    /// same-rooted with the surface keywords/bridge tags, 22 §17 D59;
    /// expression items take the CoreExpr kind_name).
    pub fn kind_name(&self) -> &'static str {
        match self {
            ModuleItem::Define { .. } => "define",
            ModuleItem::Require { .. } => "require",
            ModuleItem::Module { .. } => "module",
            ModuleItem::Expr(e) => e.kind_name(),
        }
    }

    /// S-expression-form rendering (for tests and dumps).
    pub fn render(&self, resolve: &dyn Fn(Symbol) -> String) -> String {
        match self {
            ModuleItem::Define { name, value, .. } => {
                format!("(define {} {})", resolve(*name), value.render(resolve))
            }
            ModuleItem::Require { caps, .. } => {
                let cs: Vec<&str> = caps.iter().map(|c| c.as_str()).collect();
                format!("(require io {})", cs.join(" "))
            }
            ModuleItem::Module {
                name,
                imports,
                exports,
                items,
                ..
            } => {
                let mut out = format!("(module {}", resolve(*name));
                if !imports.is_empty() {
                    let is: Vec<String> = imports.iter().map(|i| resolve(*i)).collect();
                    out.push_str(&format!(" (import {})", is.join(" ")));
                }
                if !exports.is_empty() {
                    let es: Vec<String> = exports.iter().map(|e| resolve(*e)).collect();
                    out.push_str(&format!(" (export {})", es.join(" ")));
                }
                for item in items {
                    out.push(' ');
                    out.push_str(&item.render(resolve));
                }
                out.push(')');
                out
            }
            ModuleItem::Expr(e) => e.render(resolve),
        }
    }

    /// Free variables of the expression subtree inside the item (drives the
    /// define-only collector/E0022 reconciliation).
    pub fn free_var_occurrences(&self, bound: &mut Vec<Symbol>, out: &mut Vec<(Symbol, ScopeSet)>) {
        match self {
            ModuleItem::Define { value, .. } => value.free_var_occurrences(bound, out),
            // require has zero variable references (zero runtime
            // semantics — 01 §6)
            ModuleItem::Require { .. } => {}
            ModuleItem::Module { items, .. } => {
                for item in items {
                    item.free_var_occurrences(bound, out);
                }
            }
            ModuleItem::Expr(e) => e.free_var_occurrences(bound, out),
        }
    }
}

impl CoreExpr {
    /// Node Span.
    pub fn span(&self) -> Span {
        match self {
            CoreExpr::Fn { span, .. }
            | CoreExpr::Apply { span, .. }
            | CoreExpr::If { span, .. }
            | CoreExpr::Var { span, .. }
            | CoreExpr::Literal { span, .. }
            | CoreExpr::Assign { span, .. }
            | CoreExpr::Let { span, .. }
            | CoreExpr::Perform { span, .. }
            | CoreExpr::Handle { span, .. }
            | CoreExpr::HandleGroup { span, .. } => *span,
        }
    }

    /// Primitive name (for diagnostics and dumps — 22 §13 D37 five-surface
    /// same-root naming: same-rooted with the surface keywords/bridge
    /// tags/rendering surface; after the r49 declaration-layer arm the
    /// 9-name table [the three declaration names moved to
    /// `ModuleItem::kind_name` — 22 §17 D59]).
    pub fn kind_name(&self) -> &'static str {
        match self {
            CoreExpr::Fn { .. } => "fn",
            CoreExpr::Apply { .. } => "apply",
            CoreExpr::If { .. } => "if",
            CoreExpr::Var { .. } => "var",
            CoreExpr::Literal { .. } => "literal",
            CoreExpr::Assign { .. } => "assign",
            CoreExpr::Let { .. } => "let",
            CoreExpr::Perform { .. } => "perform",
            CoreExpr::Handle { .. } => "handle",
            CoreExpr::HandleGroup { .. } => "handle-group",
        }
    }

    /// S-expression-form rendering (needs a symbol-table resolve function;
    /// for tests and dumps). The rendering surface/diagnostic surface/tag
    /// surface and the other five surfaces share the same root (r43 surface
    /// switchover + r44 internal-name-surface closure — 22 §13 D34: one
    /// semantics one name).
    pub fn render(&self, resolve: &dyn Fn(Symbol) -> String) -> String {
        match self {
            CoreExpr::Fn { params, body, .. } => {
                let ps: Vec<String> = params.iter().map(|p| resolve(*p)).collect();
                format!("(fn ({}) {})", ps.join(" "), body.render(resolve))
            }
            CoreExpr::Apply { fn_expr, args, .. } => {
                let mut parts = vec![fn_expr.render(resolve)];
                parts.extend(args.iter().map(|a| a.render(resolve)));
                format!("({})", parts.join(" "))
            }
            CoreExpr::If {
                cond,
                then_branch,
                else_branch,
                ..
            } => format!(
                "(if {} {} {})",
                cond.render(resolve),
                then_branch.render(resolve),
                else_branch.render(resolve)
            ),
            CoreExpr::Var { name, .. } => resolve(*name),
            CoreExpr::Literal { value, .. } => value.render(),
            CoreExpr::Assign { name, value, .. } => {
                format!("(assign {} {})", resolve(*name), value.render(resolve))
            }
            CoreExpr::Let {
                name, value, body, ..
            } => {
                format!(
                    "(let ({}) {} {})",
                    resolve(*name),
                    value.render(resolve),
                    body.render(resolve)
                )
            }
            CoreExpr::Perform { effect, .. } => {
                format!("(perform {})", effect.render(resolve))
            }
            CoreExpr::Handle {
                tag,
                payload_var,
                resume_var,
                handler_body,
                body,
                ..
            } => {
                format!(
                    "(handle {} (({} {}) {}) {})",
                    tag,
                    resolve(*payload_var),
                    resolve(*resume_var),
                    handler_body.render(resolve),
                    body.render(resolve)
                )
            }
            CoreExpr::HandleGroup { arms, body, .. } => {
                let arm_strs: Vec<String> = arms
                    .iter()
                    .map(|a| {
                        format!(
                            "({} ({} {}) {})",
                            a.tag,
                            resolve(a.payload_var),
                            resolve(a.resume_var),
                            a.handler_body.render(resolve)
                        )
                    })
                    .collect();
                format!(
                    "(handle-group {} {})",
                    arm_strs.join(" "),
                    body.render(resolve)
                )
            }
        }
    }

    /// Free-variable computation (multiple subjects traversed in order;
    /// binding shadowing). CodeValue and the compiler's closure capture
    /// analysis share this semantics (the single trusted data source). The
    /// name projection comes from [`CoreExpr::free_var_occurrences`] (one
    /// definition of the same traversal).
    pub fn free_variables(&self, bound: &mut Vec<Symbol>, out: &mut Vec<Symbol>) {
        let mut occ: Vec<(Symbol, ScopeSet)> = Vec::new();
        self.free_var_occurrences(bound, &mut occ);
        out.extend(occ.iter().map(|(s, _)| *s));
    }

    /// Free-variable occurrences (including the first occurrence's scope set —
    /// TD-004/r13: the compiler's capture analysis must determine `(name,
    /// scopes ⊆)` ownership for each free name, so the first occurrence's
    /// reference scope set is carried as that name's representative; the
    /// expander-injected invariant guarantees that multiple occurrences of the
    /// same name belong to the same binding — unambiguous at Stage 0 scale).
    ///
    /// Traversal semantics are fully identical to the name-only version
    /// (binding shadowing, letrec* order); deduplication prefers first
    /// occurrence by name.
    pub fn free_var_occurrences(&self, bound: &mut Vec<Symbol>, out: &mut Vec<(Symbol, ScopeSet)>) {
        match self {
            CoreExpr::Var { name, scopes, .. } => {
                if !bound.contains(name) && !out.iter().any(|(s, _)| s == name) {
                    out.push((*name, scopes.clone()));
                }
            }
            CoreExpr::Literal { .. } => {}
            CoreExpr::Fn { params, body, .. } => {
                // r132 / 202-c: shadow-aware pop count — the Let arm's r45/D42
                // discipline extended to Fn: a param already bound in an
                // enclosing scope pushes nothing (and duplicate params within
                // one list push once), so popping params.len() would corrupt
                // the bound stack (over-pop silently drops enclosing bindings
                // — Vec::pop on empty is a no-op, the miscount surfaces only
                // as wrongly-free/wrongly-bound vars downstream)
                let mut shadowed = 0;
                for p in params {
                    if !bound.contains(p) {
                        bound.push(*p);
                        shadowed += 1;
                    }
                }
                body.free_var_occurrences(bound, out);
                for _ in 0..shadowed {
                    bound.pop();
                }
            }
            CoreExpr::Apply { fn_expr, args, .. } => {
                fn_expr.free_var_occurrences(bound, out);
                for a in args {
                    a.free_var_occurrences(bound, out);
                }
            }
            CoreExpr::If {
                cond,
                then_branch,
                else_branch,
                ..
            } => {
                cond.free_var_occurrences(bound, out);
                then_branch.free_var_occurrences(bound, out);
                else_branch.free_var_occurrences(bound, out);
            }
            CoreExpr::Assign {
                name,
                scopes,
                value,
                ..
            } => {
                if !bound.contains(name) && !out.iter().any(|(s, _)| s == name) {
                    out.push((*name, scopes.clone()));
                }
                value.free_var_occurrences(bound, out);
            }
            CoreExpr::Let {
                name, value, body, ..
            } => {
                // Let binding: value is evaluated first (name is not yet in
                // bound — let* order), then name enters bound to shadow, and
                // is popped after traversing the body (same shape as Fn)
                value.free_var_occurrences(bound, out);
                let shadowed = !bound.contains(name);
                if shadowed {
                    bound.push(*name);
                }
                body.free_var_occurrences(bound, out);
                if shadowed {
                    bound.pop();
                }
            }
            CoreExpr::Perform { effect, .. } => {
                effect.free_var_occurrences(bound, out);
            }
            CoreExpr::Handle {
                payload_var,
                resume_var,
                handler_body,
                body,
                ..
            } => {
                // Binding shadowing (same shape as Fn — the two binders enter
                // bound first and are popped after traversing the bodies; the
                // tag is a symbol constant, not a variable reference).
                // r132 / 202-c: shadow-aware pop count — the unconditional
                // pop(2) underflowed when a binder already shadowed an
                // enclosing binding (nested same-name handles crashed the
                // bootstrap compiler's fvo tail(nil) fail-closed; this seed's
                // variant popped silently — same-window settlement, the
                // multi-arm window's E2E exposed the latent defect family)
                let mut shadowed = 0;
                for p in [payload_var, resume_var] {
                    if !bound.contains(p) {
                        bound.push(*p);
                        shadowed += 1;
                    }
                }
                handler_body.free_var_occurrences(bound, out);
                body.free_var_occurrences(bound, out);
                for _ in 0..shadowed {
                    bound.pop();
                }
            }
            // r136 / 206-b (D13): per-arm shadow-aware binders — each arm's
            // binders enter/leave bound around its own handler body (arms
            // are sibling scopes; the protected body sees none of them).
            CoreExpr::HandleGroup { arms, body, .. } => {
                for arm in arms {
                    let mut shadowed = 0;
                    for p in [arm.payload_var, arm.resume_var] {
                        if !bound.contains(&p) {
                            bound.push(p);
                            shadowed += 1;
                        }
                    }
                    arm.handler_body.free_var_occurrences(bound, out);
                    for _ in 0..shadowed {
                        bound.pop();
                    }
                }
                body.free_var_occurrences(bound, out);
            }
        }
    }

    /// Convenience wrapper: this expression's free-variable occurrences
    /// (name + first-occurrence scope set).
    pub fn free_var_occurrence_list(&self) -> Vec<(Symbol, ScopeSet)> {
        let mut out = Vec::new();
        let mut bound = Vec::new();
        self.free_var_occurrences(&mut bound, &mut out);
        out
    }

    /// Convenience wrapper: this expression's free-variable list.
    pub fn free_variable_list(&self) -> Vec<Symbol> {
        let mut out = Vec::new();
        let mut bound = Vec::new();
        self.free_variables(&mut bound, &mut out);
        out
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sym(n: u32) -> Symbol {
        Symbol(n)
    }

    fn var(n: u32) -> Rc<CoreExpr> {
        Rc::new(CoreExpr::Var {
            name: sym(n),
            scopes: ScopeSet::new(),
            span: Span::dummy(),
        })
    }

    #[test]
    fn free_variables_lambda_shadows() {
        // (fn (a) (f a b)) → free variables {f, b} (a is shadowed by the parameter)
        let body = Rc::new(CoreExpr::Apply {
            fn_expr: var(6),
            args: vec![var(0), var(1)],
            span: Span::dummy(),
        });
        let lam = CoreExpr::Fn {
            params: vec![sym(0)],
            param_scopes: vec![ScopeSet::new()],
            rest: None,
            body,
            span: Span::dummy(),
        };
        let fv = lam.free_variable_list();
        assert_eq!(fv, vec![sym(6), sym(1)]);
    }

    #[test]
    fn free_variables_nested() {
        // (fn (x) (fn (y) (x y z))) → free variables {z}
        let inner = CoreExpr::Fn {
            params: vec![sym(1)],
            param_scopes: vec![ScopeSet::new()],
            rest: None,
            body: Rc::new(CoreExpr::Apply {
                fn_expr: var(0),
                args: vec![var(1), var(2)],
                span: Span::dummy(),
            }),
            span: Span::dummy(),
        };
        let outer = CoreExpr::Fn {
            params: vec![sym(0)],
            param_scopes: vec![ScopeSet::new()],
            rest: None,
            body: Rc::new(inner),
            span: Span::dummy(),
        };
        assert_eq!(outer.free_variable_list(), vec![sym(2)]);
    }

    #[test]
    fn literal_render_pair_list() {
        // (1 2 3) as Pair chain
        let three = Rc::new(LiteralValue::Int(3));
        let two = Rc::new(LiteralValue::Int(2));
        let one = Rc::new(LiteralValue::Int(1));
        let list = LiteralValue::Pair(
            one.clone(),
            Rc::new(LiteralValue::Pair(
                two.clone(),
                Rc::new(LiteralValue::Pair(
                    three.clone(),
                    Rc::new(LiteralValue::Nil),
                )),
            )),
        );
        assert_eq!(list.render(), "(1 2 3)");
        // Dotted pair: (1 . 2)
        let dotted = LiteralValue::Pair(one, two);
        assert_eq!(dotted.render(), "(1 . 2)");
    }

    #[test]
    fn render_core_forms() {
        let resolve = |s: Symbol| {
            ((b'a' + s.0 as u8) as char)
                .to_string()
                .chars()
                .take(1)
                .collect::<String>()
        };
        let if_expr = CoreExpr::If {
            cond: var(0),
            then_branch: var(1),
            else_branch: Rc::new(CoreExpr::Literal {
                value: LiteralValue::Nil,
                span: Span::dummy(),
            }),
            span: Span::dummy(),
        };
        assert_eq!(if_expr.render(&resolve), "(if a b nil)");
        assert_eq!(if_expr.kind_name(), "if");
    }
}

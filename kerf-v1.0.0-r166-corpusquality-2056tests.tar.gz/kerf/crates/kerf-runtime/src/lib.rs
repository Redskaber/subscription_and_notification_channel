//! # kerf-runtime
//!
//! **Five-orthogonal-axes positioning (lang-design 15 §5.3, v6.0)**: the channel layer of
//! axes 3/4 — the minimal I/O and GC foundation (Layer 0, no dependencies; the runtime
//! channel surface of capability gating).
//!
//! Runtime foundation (Layer 0, **no crate dependencies** — sop.md §2.4.5 layer dependency
//! rules): GC heap (mark-sweep) + minimal I/O + foreign ref registration.
//!
//! **Capability model** (§8.11 + §19.4):
//! - bump-style slot allocation (`alloc_pair`);
//! - explicit work-stack marking (guards against recursive stack overflow, §19.4 pitfall 1);
//! - linear heap-traversal sweep (free list);
//! - root set: `RootSet` (collected by the VM at safepoints — §19.4 pitfall 2: GC triggers
//!   only at instruction boundaries).
//!
//! **Core invariants** (§19.4):
//! 1. Root-set completeness: none of the five root sources may be missing (VM data stack /
//!    call-frame local slots / frame capture slots / global environment / foreign ref —
//!    05-runtime §3.2 v5.2 wording; the former "four root kinds" missed frame capture
//!    slots);
//! 2. Mark-bit reset symmetry: `clear_marks` traverses all objects (including the
//!    just-collected ones);
//! 3. Zero re-entrant allocation: the allocation path triggers no operation that could
//!    itself allocate.
//!
//! **Heap semantics** (documented decision): the GC primarily manages the pair graph
//! (`HeapObj::Pair`); boxed immediates (Str/Int/Float/Bool/Nil/Symbol — r5 TD-002 added
//! Symbol) are leaf nodes (no internal heap references); generational/compaction ruled
//! DEFER Stage 3+ (TD-008 — r24/42-e empirical basis on three fronts, re-evaluated when
//! trigger conditions are met; the TD-023 gc_stress targeted remedy was delivered in r24).

pub mod gc;
pub mod heap;
pub mod io;

// Explicit re-exports (§10.1 rule 4: glob re-exports forbidden).
// Convention: this crate exposes all public types and entry points of the runtime
// foundation.
pub use gc::{mark_sweep_cycle, RootSet};
pub use heap::GcStats;
pub use heap::{BoxedInput, ForeignBox, ForeignTracer, GcRef, Heap, HeapObj, ValueSlot};
pub use io::{read_line_stdin, write_line_stdout, write_stdout, RuntimeError};

// ---------------------------------------------------------------------------
// Space subordination declaration section (r66 / 123-a — lang-design 24 v2.0 two-sided
// unified system; 24 §7.2 core-side incorporation table: this crate's primary types get
// explicit three-layer impls [root + core space + domain] — core execution domain
// (program execution — GC heap / minimal I/O channel foundation); core-side version of
// "declaration is membership", sole subordination criterion = marker impl [24 §3 A7])
// ---------------------------------------------------------------------------
use kerf_space::{CoreExecutionDomain, CoreSpace, RootSpace};

impl RootSpace for Heap {}
impl CoreSpace for Heap {}
impl CoreExecutionDomain for Heap {}
impl RootSpace for GcRef {}
impl CoreSpace for GcRef {}
impl CoreExecutionDomain for GcRef {}
impl RootSpace for RootSet {}
impl CoreSpace for RootSet {}
impl CoreExecutionDomain for RootSet {}
impl RootSpace for RuntimeError {}
impl CoreSpace for RuntimeError {}
impl CoreExecutionDomain for RuntimeError {}

//! Mark-sweep collection entry point (stage0.md §19.4 `gc_cycle` three phases).
//!
//! ```text
//! fn gc_cycle(heap, roots) {
//!     mark_all(roots, heap);   // 1. mark: set the bit on all root-set-reachable objects
//!     sweep(heap);             // 2. sweep: return unmarked objects to the free list
//!     heap.clear_marks();      // 3. reset: prepare for the next cycle
//! }
//! ```

use crate::heap::{GcRef, GcStats, Heap};

/// Root set (§19.4: VM stack + call-stack locals + global environment + foreign refs —
/// the first three kinds are collected by the VM at safepoints and passed in as a
/// `GcRef` list; foreign refs are held by the Heap itself).
#[derive(Debug, Clone, Default)]
pub struct RootSet {
    /// Reachable heap references (enumerated by the caller: value stack / frame locals /
    /// global environment / closure captures).
    pub refs: Vec<GcRef>,
}

impl RootSet {
    pub fn new() -> Self {
        RootSet { refs: Vec::new() }
    }

    /// Construct from a list of references.
    pub fn from_refs(refs: impl IntoIterator<Item = GcRef>) -> Self {
        RootSet {
            refs: refs.into_iter().collect(),
        }
    }

    /// Append a root.
    pub fn push(&mut self, r: GcRef) {
        self.refs.push(r);
    }

    /// Number of roots.
    pub fn len(&self) -> usize {
        self.refs.len()
    }

    /// Whether empty.
    pub fn is_empty(&self) -> bool {
        self.refs.is_empty()
    }
}

/// Run one mark-sweep cycle (§19.4 `gc_cycle`).
pub fn mark_sweep_cycle(heap: &mut Heap, roots: &RootSet) -> GcStats {
    heap.collect(roots)
}

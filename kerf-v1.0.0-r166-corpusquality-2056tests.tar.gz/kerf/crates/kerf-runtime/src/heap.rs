//! GC heap: slot allocation + mark-sweep collection (stage0.md §8.11 / §19.4 three-phase
//! skeleton).
//!
//! Structure: `slots` is the object-slot vector (`GcRef` = slot index); sweep returns
//! unmarked slots to the `free` free list (the Stage 0 "allocate only, no compaction"
//! strategy, §19.4 pitfall 3).

use std::any::Any;
use std::rc::Rc;

use crate::gc::RootSet;
use crate::io::RuntimeError;

/// Heap object reference (slot index). Construction only via `Heap`.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct GcRef(pub u32);

/// Heap object kinds (Layer 0 self-contained object model).
/// The pair-element form of closures/builtins = `Foreign` (TD-010 solved in r24: the
/// former marker-string placeholder → real boxing, round-trip identity preserved).
#[derive(Clone)]
pub enum HeapObj {
    /// Pair (car . cdr).
    Pair(GcRef, GcRef),
    /// Boxed string.
    Str(Rc<str>),
    /// Boxed integer (the slot form when a pair element is an immediate).
    Int(i64),
    /// Boxed float.
    Float(f64),
    /// Boxed boolean.
    Bool(bool),
    /// Boxed symbol (the slot form of quote symbol values — TD-002).
    Symbol(Rc<str>),
    /// Boxed nil.
    Nil,
    /// Boxed vector (r138 / 208-c — TD-002 vector value type,
    /// vector-value-design.md D1/D3: immutable by construction; elements are
    /// **slot references** (each element boxed via `box_value` — the same
    /// slot discipline as `Pair`, so the mark phase enumerates child
    /// references uniformly). Allocation only via `alloc_vector`.
    Vector(Vec<GcRef>),
    /// Boxed Foreign value (closures/builtins — TD-010): `any` carries the boxing side's
    /// type (kerf-vm's function values); `tracer` is provided by the boxing side and
    /// enumerates its GC-visible child references (the closure capture graph) during
    /// marking — kerf-runtime does not depend on kerf-vm types (§11 interface isolation:
    /// a tracing protocol instead of type coupling).
    Foreign(Rc<ForeignBox>),
}

/// Foreign tracer: enumerates the GC-visible child references inside a boxed value (all
/// Pair references in the closure capture graph go into out — Rc dedup/cycle prevention
/// is borne by the implementer).
pub type ForeignTracer = fn(&Rc<dyn Any>, &mut Vec<GcRef>);

/// Foreign boxed-value carrier (TD-010): the value itself + tracer.
#[derive(Clone)]
pub struct ForeignBox {
    /// The boxed function value (the type-erased form of kerf-vm
    /// Value::Closure/Builtin; Rc sharing → the unboxing round trip preserves
    /// identity (eq? compares by reference)).
    pub any: Rc<dyn Any>,
    /// Mark-phase child-reference tracer (injected by the boxing side).
    pub tracer: ForeignTracer,
}

// `Rc<dyn Any>` cannot derive Debug/PartialEq — implemented by hand (carrier semantics:
// value identity = the same Rc allocation; the tracer is an incidental property of the
// boxing site and takes no part in the identity judgment).
impl std::fmt::Debug for ForeignBox {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "ForeignBox(..)")
    }
}

impl PartialEq for ForeignBox {
    fn eq(&self, other: &Self) -> bool {
        Rc::ptr_eq(&self.any, &other.any)
    }
}

impl std::fmt::Debug for HeapObj {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            HeapObj::Pair(a, b) => write!(f, "Pair({:?}, {:?})", a, b),
            HeapObj::Str(s) => write!(f, "Str({:?})", s),
            HeapObj::Int(i) => write!(f, "Int({})", i),
            HeapObj::Float(v) => write!(f, "Float({})", v),
            HeapObj::Bool(b) => write!(f, "Bool({})", b),
            HeapObj::Symbol(s) => write!(f, "Symbol({:?})", s),
            HeapObj::Nil => write!(f, "Nil"),
            HeapObj::Vector(v) => write!(f, "Vector({:?})", v),
            HeapObj::Foreign(_) => write!(f, "Foreign(..)"),
        }
    }
}

impl PartialEq for HeapObj {
    fn eq(&self, other: &Self) -> bool {
        match (self, other) {
            (HeapObj::Pair(a1, b1), HeapObj::Pair(a2, b2)) => a1 == a2 && b1 == b2,
            (HeapObj::Str(a), HeapObj::Str(b)) => a == b,
            (HeapObj::Int(a), HeapObj::Int(b)) => a == b,
            (HeapObj::Float(a), HeapObj::Float(b)) => a == b,
            (HeapObj::Bool(a), HeapObj::Bool(b)) => a == b,
            (HeapObj::Symbol(a), HeapObj::Symbol(b)) => a == b,
            (HeapObj::Nil, HeapObj::Nil) => true,
            // r138 / 208-c: slot-by-slot structural equality (same shape as Pair —
            // GcRef equality on the element slots)
            (HeapObj::Vector(a), HeapObj::Vector(b)) => a == b,
            (HeapObj::Foreign(a), HeapObj::Foreign(b)) => Rc::ptr_eq(&a.any, &b.any),
            // `_` arm rationale: combinations of different constructors (cross-type boxed
            // values) are not equal — strict type equality
            _ => false,
        }
    }
}

/// A single heap slot.
#[derive(Debug, Clone, PartialEq)]
pub struct Slot {
    pub obj: HeapObj,
    pub marked: bool,
}

/// GC heap (mark-sweep).
#[derive(Debug, Clone)]
pub struct Heap {
    slots: Vec<Slot>,
    free: Vec<GcRef>,
    /// GC trigger threshold (collect once the live-object count exceeds it — checked by
    /// the VM at safepoints).
    gc_threshold: usize,
    /// GC switch (disabled on the eval path: collection disabled without a complete
    /// root set, see crate docs).
    gc_enabled: bool,
    /// foreign ref persistent roots (§8.8/§15 reserved: FFI root registration; may be an
    /// empty set in Stage 0).
    foreign_roots: Vec<GcRef>,
    /// Pin counting book Φ (r30/48-d — ffi-ownership-model §3: the **counted
    /// generalization** of `foreign_roots`. A `Vec<(GcRef, u32)>` of ordered pairs
    /// (supp(Φ) insertion order; removed once the count reaches zero — the runtime shape
    /// of "unpin to 0 → removed from supp(Φ), collectable in the next collection
    /// cycle"). Coexists with the persistent roots: persistent roots = the zero-count
    /// predecessor (registration is root preservation, never removed); Φ = window-borrow
    /// paired counting.
    pin_counts: Vec<(GcRef, u32)>,
    /// Statistics: total allocations.
    total_allocs: u64,
    /// Allocations since the last collection (an allocation-count-driven trigger —
    /// collection cost amortized over allocation volume).
    allocs_since_gc: u64,
    /// Statistics: number of collections.
    collections: u64,
    /// Statistics: cumulative collected objects.
    total_freed: u64,
}

impl Default for Heap {
    fn default() -> Self {
        Heap::new()
    }
}

impl Heap {
    /// Construct (default threshold: collection triggers after 1024 allocations —
    /// tunable for tests).
    pub fn new() -> Self {
        Heap::with_threshold(1024)
    }

    /// Construct with the given threshold.
    pub fn with_threshold(gc_threshold: usize) -> Self {
        Heap {
            slots: Vec::new(),
            free: Vec::new(),
            gc_threshold,
            gc_enabled: true,
            foreign_roots: Vec::new(),
            pin_counts: Vec::new(),
            total_allocs: 0,
            allocs_since_gc: 0,
            collections: 0,
            total_freed: 0,
        }
    }

    /// Allocate a pair (bump style: free-list reuse first, otherwise append a new slot).
    /// Zero re-entrant allocation (§19.4 invariant 3): this path triggers no collection
    /// and no allocating calls.
    pub fn alloc_pair(&mut self, car: GcRef, cdr: GcRef) -> GcRef {
        let obj = HeapObj::Pair(car, cdr);
        self.alloc_obj(obj)
    }

    /// Allocate a boxed string.
    pub fn alloc_str(&mut self, s: Rc<str>) -> GcRef {
        self.alloc_obj(HeapObj::Str(s))
    }

    /// Allocate a boxed integer.
    pub fn alloc_int(&mut self, v: i64) -> GcRef {
        self.alloc_obj(HeapObj::Int(v))
    }

    /// Allocate a boxed float.
    pub fn alloc_float(&mut self, v: f64) -> GcRef {
        self.alloc_obj(HeapObj::Float(v))
    }

    /// Allocate a boxed boolean.
    pub fn alloc_bool(&mut self, v: bool) -> GcRef {
        self.alloc_obj(HeapObj::Bool(v))
    }

    /// Allocate a boxed nil.
    pub fn alloc_nil(&mut self) -> GcRef {
        self.alloc_obj(HeapObj::Nil)
    }

    /// Allocate a boxed symbol (TD-002: quote symbol values enter pairs).
    pub fn alloc_symbol(&mut self, s: Rc<str>) -> GcRef {
        self.alloc_obj(HeapObj::Symbol(s))
    }

    /// Allocate a vector (r138 / 208-c — TD-002: `vector-of` construction and
    /// `vector-append` products; elements are pre-boxed slot references —
    /// the caller boxes via `box_value` per element, the `list` builtin
    /// discipline). Zero mutation after allocation (D1 immutable design).
    pub fn alloc_vector(&mut self, items: Vec<GcRef>) -> GcRef {
        self.alloc_obj(HeapObj::Vector(items))
    }

    /// Allocate a boxed Foreign value (TD-010: the pair-element form of closures/builtins).
    pub fn alloc_foreign(&mut self, b: ForeignBox) -> GcRef {
        self.alloc_obj(HeapObj::Foreign(Rc::new(b)))
    }

    /// Box an immediate value (TD-010 r24: closures/builtins can be boxed via the Foreign
    /// form).
    pub fn alloc_boxed(&mut self, v: BoxedInput) -> GcRef {
        match v {
            BoxedInput::Str(s) => self.alloc_obj(HeapObj::Str(s)),
            BoxedInput::Int(i) => self.alloc_obj(HeapObj::Int(i)),
            BoxedInput::Float(f) => self.alloc_obj(HeapObj::Float(f)),
            BoxedInput::Bool(b) => self.alloc_obj(HeapObj::Bool(b)),
            BoxedInput::Nil => self.alloc_obj(HeapObj::Nil),
            BoxedInput::Foreign(b) => self.alloc_obj(HeapObj::Foreign(Rc::new(b))),
        }
    }

    /// Unbox into a value-slot description (kerf-vm converts it into a Value; a pair slot
    /// returns the Pair marker, and the caller wraps its own reference into a
    /// Value::Pair).
    pub fn unbox(&self, r: GcRef) -> Option<ValueSlot> {
        self.get(r).map(|s| match &s.obj {
            HeapObj::Pair(..) => ValueSlot::Pair,
            HeapObj::Str(v) => ValueSlot::Str(v.clone()),
            HeapObj::Int(v) => ValueSlot::Int(*v),
            HeapObj::Float(v) => ValueSlot::Float(*v),
            HeapObj::Bool(v) => ValueSlot::Bool(*v),
            HeapObj::Symbol(v) => ValueSlot::Symbol(v.clone()),
            HeapObj::Nil => ValueSlot::Nil,
            // r138 / 208-c: the marker form (the caller wraps its own slot
            // reference into a `Value::Vector` — same shape as `ValueSlot::Pair`)
            HeapObj::Vector(_) => ValueSlot::Vector,
            HeapObj::Foreign(b) => ValueSlot::Foreign(b.clone()),
        })
    }

    fn alloc_obj(&mut self, obj: HeapObj) -> GcRef {
        self.total_allocs += 1;
        self.allocs_since_gc += 1;
        if let Some(r) = self.free.pop() {
            self.slots[r.0 as usize].obj = obj;
            self.slots[r.0 as usize].marked = false;
            return r;
        }
        let r = GcRef(self.slots.len() as u32);
        self.slots.push(Slot { obj, marked: false });
        r
    }

    /// Read a pair (returns None on type mismatch — explicit failure).
    pub fn get_pair(&self, r: GcRef) -> Option<(GcRef, GcRef)> {
        match &self.get(r)?.obj {
            HeapObj::Pair(a, b) => Some((*a, *b)),
            _ => None,
        }
    }

    /// Read a vector's element slots (r138 / 208-c — TD-002; returns None on
    /// type mismatch — the explicit-failure discipline of `get_pair`).
    pub fn get_vector(&self, r: GcRef) -> Option<&[GcRef]> {
        match &self.get(r)?.obj {
            HeapObj::Vector(v) => Some(v),
            _ => None,
        }
    }

    /// Read an object.
    pub fn get(&self, r: GcRef) -> Option<&Slot> {
        self.slots.get(r.0 as usize)
    }

    /// Number of live objects (including not-yet-collected garbage — true liveness is
    /// counted after mark).
    pub fn slot_count(&self) -> usize {
        self.slots.len()
    }

    /// Number of free slots.
    pub fn free_count(&self) -> usize {
        self.free.len()
    }

    /// GC switch (eval path: disabled without a complete root set).
    pub fn set_gc_enabled(&mut self, enabled: bool) {
        self.gc_enabled = enabled;
    }

    /// Whether the collection threshold is reached (allocation-count driven — collection
    /// cost amortized over allocation volume; polled at VM instruction-boundary
    /// safepoints, §19.4 pitfall 2).
    pub fn should_collect(&self) -> bool {
        self.gc_enabled && self.allocs_since_gc > self.gc_threshold as u64
    }

    /// Register a foreign ref (§8.8: FFI root reserved; the Stage 0 persistent root set,
    /// may be used as a no-op).
    pub fn register_foreign_ref(&mut self, r: GcRef) {
        if !self.foreign_roots.contains(&r) {
            self.foreign_roots.push(r);
        }
    }

    /// foreign root set (merged into the root set during GC cycles).
    pub fn foreign_roots(&self) -> &[GcRef] {
        &self.foreign_roots
    }

    /// Pin an object (rule P1: `Φ[v] += 1`; insert with count 1 if not yet registered).
    /// The same object may be pinned repeatedly — counts accumulate (a
    /// reference-counting-style barrier).
    pub fn pin_object(&mut self, r: GcRef) {
        if let Some(entry) = self.pin_counts.iter_mut().find(|(g, _)| *g == r) {
            entry.1 += 1;
        } else {
            self.pin_counts.push((r, 1));
        }
    }

    /// Unpin an object (rule U1: `Φ[v] -= 1`, removed from supp(Φ) when the count reaches
    /// zero — the object becomes collectable only in the **next** collection cycle, not
    /// immediately). Rule U2: not registered (`Φ(v) = 0`) → `Err` (06-operational-
    /// semantics §3 E8 wording — internal invariant breakage = a boundary-implementation
    /// bookkeeping defect, P0 level, not a user error; the window discipline's structural
    /// pairing guarantees user programs cannot reach it).
    pub fn unpin_object(&mut self, r: GcRef) -> Result<(), RuntimeError> {
        let idx = self.pin_counts.iter().position(|(g, _)| *g == r);
        match idx {
            Some(i) => {
                self.pin_counts[i].1 -= 1;
                if self.pin_counts[i].1 == 0 {
                    self.pin_counts.remove(i);
                }
                Ok(())
            }
            None => Err(RuntimeError::new(
                "pin count underflow(E8 basis -- boundary implementation bookkeeping defect, structural pairing guarantee unreachable)",
            )),
        }
    }

    /// Φ count query (P1/U1 observability — the testing and protocol audit surface).
    pub fn pin_count(&self, r: GcRef) -> u32 {
        self.pin_counts
            .iter()
            .find(|(g, _)| *g == r)
            .map(|(_, c)| *c)
            .unwrap_or(0)
    }

    /// supp(Φ) reference set (all references with count > 0 — merged into the mark start
    /// set; consumed by the GC cycle's `collect`, externally observable for tests).
    pub fn pinned_refs(&self) -> Vec<GcRef> {
        self.pin_counts.iter().map(|(g, _)| *g).collect()
    }

    /// Child-reference enumeration (the graph-traversal edges of the mark phase).
    fn children(&self, r: GcRef) -> Vec<GcRef> {
        match &self.get(r).map(|s| &s.obj) {
            Some(HeapObj::Pair(a, b)) => vec![*a, *b],
            // TD-010: Foreign slots enumerate the closure capture graph via the tracer
            // injected by the boxing side (all Pair references — builtin values have no
            // child references, the tracer is a no-op).
            Some(HeapObj::Foreign(b)) => {
                let mut out = Vec::new();
                (b.tracer)(&b.any, &mut out);
                out
            }
            // r138 / 208-c — TD-002: vector slots enumerate their element slots
            // (the mark-graph edges — the Pair two-element enumeration generalized
            // to n elements; immutable D1 means the edge set is fixed at allocation)
            Some(HeapObj::Vector(v)) => v.clone(),
            // `_` arm rationale: non-pair heap objects (Str/Int/Float/Bool/Nil/Symbol —
            // TD-002 r5 symbols boxed as leaves) and out-of-bounds references all have no
            // child references — no out-edges in the mark graph traversal
            _ => Vec::new(),
        }
    }

    /// Mark reset (§19.4 invariant 2: traverse all objects, including the just-collected
    /// ones).
    fn clear_marks(&mut self) {
        for s in &mut self.slots {
            s.marked = false;
        }
    }

    /// Statistics.
    pub fn stats(&self) -> GcStats {
        GcStats {
            slots: self.slots.len(),
            free: self.free.len(),
            live: self.slots.len() - self.free.len(),
            total_allocs: self.total_allocs,
            collections: self.collections,
            total_freed: self.total_freed,
        }
    }

    /// Internal: run mark-sweep (called by gc::mark_sweep_cycle).
    pub(crate) fn collect(&mut self, roots: &RootSet) -> GcStats {
        // Reset the allocation count (restart the cost-amortization window)
        self.allocs_since_gc = 0;
        // 1. Mark: explicit work stack (§19.4 — guards against recursive stack overflow)
        let mut work: Vec<GcRef> = roots.refs.clone();
        work.extend_from_slice(&self.foreign_roots);
        // supp(Φ) merged into the mark start set (ffi-ownership-model §3 — Φ persists
        // independently of the mark bit: the counting book is program state, the mark bit
        // is cycle state; F-PIN lemma: Φ(v) ≥ 1 at cycle start ⟹ this round's sweep does
        // not collect v)
        for (r, _) in &self.pin_counts {
            work.push(*r);
        }
        while let Some(r) = work.pop() {
            if let Some(slot) = self.slots.get_mut(r.0 as usize) {
                if slot.marked {
                    continue;
                }
                slot.marked = true;
            } else {
                continue;
            }
            for child in self.children(r) {
                work.push(child);
            }
        }

        // 2. Sweep: linear heap traversal (conservative policy: leaks tolerated,
        //    wrongful collection never tolerated)
        let mut freed = 0usize;
        let mut new_free: Vec<GcRef> = Vec::new();
        for (i, slot) in self.slots.iter().enumerate() {
            if !slot.marked {
                new_free.push(GcRef(i as u32));
                freed += 1;
            }
        }
        // Rebuild the free list (the obj of old free slots is already covered by the
        // reuse logic — reset to the full set of unmarked slots)
        self.free = new_free;
        self.total_freed += freed as u64;
        self.collections += 1;

        // 3. Reset (prepare for the next cycle)
        self.clear_marks();

        self.stats()
    }
}

/// Boxing input (Layer 0 immediate-value description; TD-010 r24: closures/builtins can
/// be boxed via the Foreign form).
#[derive(Debug, Clone, PartialEq)]
pub enum BoxedInput {
    Str(Rc<str>),
    Int(i64),
    Float(f64),
    Bool(bool),
    Nil,
    Foreign(ForeignBox),
}

/// Unboxing output (`Pair` marks a pair slot — the caller wraps it with the slot
/// reference; `Foreign` carries the boxing carrier — the caller (kerf-vm) downcasts it
/// itself to recover the function value).
#[derive(Debug, Clone, PartialEq)]
pub enum ValueSlot {
    Pair,
    Str(Rc<str>),
    Int(i64),
    Float(f64),
    Bool(bool),
    Symbol(Rc<str>),
    Nil,
    /// Vector marker (r138 / 208-c — the caller wraps its own slot reference
    /// into `Value::Vector`; element access goes through `Heap::get_vector`).
    Vector,
    Foreign(Rc<ForeignBox>),
}

/// GC statistics snapshot.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct GcStats {
    /// Current total number of slots.
    pub slots: usize,
    /// Number of free slots.
    pub free: usize,
    /// Number of live (not in the free list) slots.
    pub live: usize,
    /// Cumulative allocations.
    pub total_allocs: u64,
    /// Number of collections.
    pub collections: u64,
    /// Cumulative collected objects.
    pub total_freed: u64,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn alloc_reuses_free_slots() {
        let mut heap = Heap::new();
        let a = heap.alloc_pair(GcRef(0), GcRef(0));
        let b = heap.alloc_pair(GcRef(0), GcRef(0));
        assert_ne!(a, b);
        assert_eq!(heap.slot_count(), 2);
    }

    #[test]
    fn collect_frees_unreachable() {
        let mut heap = Heap::new();
        // Orphan chain: (1 . (2 . nil)) with no root
        let nil = heap.alloc_str(Rc::from(""));
        let two = heap.alloc_str(Rc::from("2"));
        let one = heap.alloc_str(Rc::from("1"));
        let _inner = heap.alloc_pair(two, nil);
        let outer = heap.alloc_pair(one, two);

        let roots = RootSet::from_refs([outer]);
        let stats = heap.collect(&roots);
        // 5 objects: outer reachable → outer/one/two live = 3; nil/inner collected = 2
        assert_eq!(
            stats.free, 2,
            "5 object in reachable 3(outer+one+two), collection 2(nil+inner)"
        );
        assert_eq!(stats.live, 3);
        assert_eq!(heap.stats().collections, 1);
        // Reuse: allocation hits the free list
        let x = heap.alloc_pair(GcRef(0), GcRef(0));
        assert!(x.0 < 5);
        assert_eq!(heap.free_count(), 1);
    }

    #[test]
    fn collect_keeps_cycle_from_roots() {
        // Self-cycle: a = (a . a) — a root-reachable self-cycle is not collected
        let mut heap = Heap::new();
        let a = heap.alloc_pair(GcRef(0), GcRef(0));
        // Write the self-cycle (manipulating the slot directly)
        heap.slots[a.0 as usize].obj = HeapObj::Pair(a, a);
        let roots = RootSet::from_refs([a]);
        let stats = heap.collect(&roots);
        assert_eq!(stats.live, 1);
        assert_eq!(stats.free, 0);
    }

    #[test]
    fn unrooted_cycle_is_collected() {
        // Rootless self-cycle: unreachable → collected (mark-sweep handles cycles natively)
        let mut heap = Heap::new();
        let a = heap.alloc_pair(GcRef(0), GcRef(0));
        heap.slots[a.0 as usize].obj = HeapObj::Pair(a, a);
        let roots = RootSet::from_refs([]);
        let stats = heap.collect(&roots);
        assert_eq!(stats.free, 1);
    }

    #[test]
    fn deep_chain_no_stack_overflow() {
        // 10^5-deep chain: mark with an explicit work stack (regression test for §19.4
        // pitfall 1)
        let mut heap = Heap::with_threshold(usize::MAX);
        let nil = heap.alloc_str(Rc::from("nil"));
        let mut head = nil;
        for _ in 0..100_000 {
            head = heap.alloc_pair(nil, head);
        }
        let roots = RootSet::from_refs([head]);
        let stats = heap.collect(&roots);
        assert_eq!(stats.live, 100_001, "all chain node + nil alive");
        assert_eq!(stats.free, 0);
    }

    #[test]
    fn foreign_roots_survive() {
        let mut heap = Heap::new();
        let s = heap.alloc_str(Rc::from("foreign"));
        heap.register_foreign_ref(s);
        let roots = RootSet::from_refs([]);
        let stats = heap.collect(&roots);
        assert_eq!(stats.live, 1, "foreign root alive");
    }

    #[test]
    fn gc_disabled_stays_put() {
        let mut heap = Heap::new();
        heap.set_gc_enabled(false);
        let _ = heap.alloc_str(Rc::from("x"));
        let roots = RootSet::from_refs([]);
        let stats = heap.collect(&roots);
        // With gc_enabled=false, collect can still be called explicitly (the eval path
        // is conventionally expected not to call it)
        assert_eq!(stats.free, 1);
        // should_collect is always false
        assert!(!heap.should_collect());
    }
}

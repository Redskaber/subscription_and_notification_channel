//! Minimal I/O (stage0.md §8.8: the traditional approach — global functions, not the
//! capability model).
//!
//! Only `read_line()` and `write_line()`. Stage 0 does not introduce capability-model
//! I/O; the reserved interface is kerf-driver::reserved::CapabilityIO (P3-level type
//! definitions).
//!
//! RuntimeError is defined here (Layer 0 minimal shape: **message only** — the layer
//! dependency rules of §2.4.5 require Layer 0 to have no dependencies and Span lives in
//! Layer 1, so source positions are looked up via debug_info_table by the execution layer
//! (kerf-vm) and backfilled into the wrapping error).

/// Runtime error (minimal shape shared by the I/O and allocation layers).
#[derive(Debug, Clone, PartialEq)]
pub struct RuntimeError {
    pub message: String,
}

impl RuntimeError {
    /// Construct.
    pub fn new(message: impl Into<String>) -> Self {
        RuntimeError {
            message: message.into(),
        }
    }
}

/// Write one line to standard output (§8.8 minimal I/O).
pub fn write_line_stdout(s: &str) -> Result<(), RuntimeError> {
    use std::io::Write;
    let mut out = std::io::stdout();
    writeln!(out, "{}", s).map_err(|e| RuntimeError::new(format!("stdout write failed:{}", e)))
}

/// Write a string to standard output (no trailing newline — the channel-layer carrier
/// of `write-string`, r5 stdlib).
pub fn write_stdout(s: &str) -> Result<(), RuntimeError> {
    use std::io::Write;
    let mut out = std::io::stdout();
    write!(out, "{}", s).map_err(|e| RuntimeError::new(format!("stdout write failed:{}", e)))
}

/// Read one line from standard input (returns None at EOF).
pub fn read_line_stdin() -> Result<Option<String>, RuntimeError> {
    use std::io::BufRead;
    let mut line = String::new();
    match std::io::stdin().lock().read_line(&mut line) {
        Ok(0) => Ok(None), // EOF
        Ok(_) => Ok(Some(line.trim_end_matches('\n').to_string())),
        Err(e) => Err(RuntimeError::new(format!("stdin read failed:{}", e))),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn runtime_error_shape() {
        let e = RuntimeError::new("boom");
        assert_eq!(e.message, "boom");
    }

    #[test]
    fn write_line_ok() {
        assert!(write_line_stdout("").is_ok());
    }
}

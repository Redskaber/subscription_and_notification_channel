//! # kerf-reader
//!
//! **Five-orthogonal-axes positioning (lang-design 15 §5.3, v6.0)**: the sole
//! bridging point of axis 1
//! (surface/internal syntax) (principle 31) — produces `Stx`, type-level isolated from `CoreExpr`
//! (anchored by the audit test architecture_audit_tests).
//!
//! Reader for typed Token streams (stage0.md §8.1 / §19.1, Layer 2).
//!
//! **Capability model**: converts a character stream into a typed Token stream,
//! then produces the syntax object `Stx` via a recursive descent parser.
//! Every Token carries a precise Span; lexical/syntax errors return
//! structured errors (with position information).
//!
//! **Responsibility boundaries** (§8.1 interface contract):
//! - **What it does**: character stream → Token stream → syntax objects; lossless coverage of
//!   the input; precise Spans.
//! - **What it does not do**: no macro expansion; no type-correctness checking;
//!   no semantic analysis.
//!
//! **Core invariants** (§19.1):
//! 1. Losslessness: the union of the Token stream's Spans exactly covers the input byte range
//!    (no gaps, no overlaps);
//! 2. Position completeness: every error path constructs an error carrying a complete Span;
//! 3. Zero semantics at the lexical layer: keyword classification is a pure table lookup; the
//!    `MacroInvocation` Token is merely an expansion-point marker.

pub mod reader;

// Explicit re-exports (§10.1 rule 4: glob re-exports are forbidden).
// Convention: this crate exposes all public types and entry points of the Reader domain.
// E6 close-out (r154 / 224-a — s-expr-removal-plan §6 exit condition 2): the
// classic S-expr Reader face (lexer.rs / parser.rs / token.rs — the
// `lex_source`/`parse_tokens`/`read_source`/`read_program` family) was deleted
// with its last production consumer (the inline S-expr macro-definition
// sources migrated to programmatic Stx construction — kerf-expander
// derived.rs). reader.rs is the sole Reader implementation (the §11
// Rust-side terminal convergence); its ReadError is THE kerf-reader
// ReadError (the TargetReadError alias is retired — one face, one name).
pub use reader::{
    lex_for_parity, parse_float_payload_text, parse_int_payload_text, read_source, symbol_name,
    tk_debug_of_kind, ParityToken, ReadError,
};

// ---------------------------------------------------------------------------
// Space affiliation declaration section (r66 / 123-a — lang-design 24 v2.0
// two-sided unified system; 24 §7.2 core-side incorporation table: this crate's
// main types get three-layer explicit impls [root + core space + domain] — core
// front-end domain (source entry — the first bridge of lex/parse/read);
// "declaration-is-affiliation" core-side edition, sole affiliation criterion
// = marker impl [24 §3 A7])
// ---------------------------------------------------------------------------
use kerf_space::{CoreFrontendDomain, CoreSpace, RootSpace};

impl RootSpace for ReadError {}
impl CoreSpace for ReadError {}
impl CoreFrontendDomain for ReadError {}
impl RootSpace for ParityToken {}
impl CoreSpace for ParityToken {}
impl CoreFrontendDomain for ParityToken {}

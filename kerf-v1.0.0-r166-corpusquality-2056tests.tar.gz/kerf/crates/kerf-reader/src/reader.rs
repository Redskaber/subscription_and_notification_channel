//! # The kerf Reader (target-syntax Reader v1 — switching-window step ①,
//! r106 / 176-e; sole Reader implementation since the E6 close-out r154)
//!
//! **Five-orthogonal-axes positioning**: the kerf-surface bridging point of axis 1
//! (surface/internal syntax) (principle 31 skin/skeleton separation — any surface
//! syntax compiles to the same core forms).
//!
//! **Normative input**: the EBNF v9 Level 0 finalized domain
//! ([02 §8.13](../../../docs/lang-design/02-syntax-model.md)
//! grammar L2 authoritative finalized position) — the full lexical layer (Rust
//! minimal-set completion: radix literals/escapes/nested comments/`::`) + the
//! expression precedence hierarchy grammar (fourteen-level table, machine face).
//!
//! **Skin dictionary implementation** ([20 §12 D2 six mappings + §14 finalized-domain
//! extension](../../../docs/lang-design/20-surface-conventions.md)):
//! kerf surface → Stx core forms (define→fn / let→let / if→if / perform→perform /
//! handle→handle / closure→fn + `::`→`/` + `()`→nil + macro invocation `name!(...)`→
//! `(name ...)`) — the output is isomorphic to the historical S-expr Reader's, so
//! downstream expander/compiler needs zero changes.
//!
//! **v1 core mapping domain** (honesty boundary — anything inside the EBNF v9 Level 0
//! domain but outside the core consumption domain gets a structured
//! "registered out-of-domain" diagnostic): fn declarations (type/effect signatures
//! parsed then stripped — the core has no type-consumption face) / closures /
//! let·assign·if·expr statements / blocks (let scope threading) / the fourteen-level
//! precedence expression subset (range `..` / pipe `|>` / bitwise family / `as` /
//! fields / indexing / method calls = registered out-of-domain diagnostics) /
//! perform·handle single-arm / module / macro invocations.
//!
//! **Architecture invariants**: precise Token Spans; every error path carries a Span;
//! zero semantics at the lexical layer.
//!
//! **Class-B outlook** (r69/136-a §5.3): this Rust implementation is the seed segment —
//! later switching-window batches, once .krf-ified, pass bootstrap replacement-surface
//! identification (bootstrap-replacement-surface-map §3.5).

use kerf_span::Span;
use kerf_syntax::{ScopeSet, Stx, StxDatum, StxLiteral, SymbolTable};

/// Target-syntax reading entry point (skin dictionary mapping — the target-surface
/// counterpart of `read_source`).
pub fn read_source(
    source: &str,
    file_id: u32,
    interner: &mut SymbolTable,
) -> Result<Vec<Stx>, ReadError> {
    let tokens = lex(source, file_id, interner)?;
    let mut parser = Parser::new(&tokens, interner);
    parser.parse_program()
}

/// Target-syntax reading error (mirrors the historic classic `ReadError`
/// shape — always carries a Span; **the sole kerf-reader ReadError since
/// the E6 close-out r154 / 224-a**).
#[derive(Debug)]
pub struct ReadError {
    pub message: String,
    pub span: Span,
}

impl ReadError {
    /// Constructs a reading error (public since E6: the classic twin's
    /// constructor visibility is inherited by the converged sole face —
    /// the bootstrap bridge family constructs these directly).
    pub fn new(message: impl Into<String>, span: Span) -> Self {
        ReadError {
            message: message.into(),
            span,
        }
    }
}

/// Lexical parity token (the .krf-ification reconciliation contract of switching-window
/// step ② — r107 / 177-b).
///
/// Stable kind surface word: literal family `int`/`float`/`str`/`true`/`false`/`unit`;
/// identifier family `ident`/`path`; keyword family = keyword text (`fn`…`as`);
/// operator family = operator text (`+`…`!`); `lifetime`/`eof`. Payload: int = decimal
/// value text, float = f64 value text (host type boundary — reconciled on the bridge
/// side after a same-source parse), str = content, ident/path = surface word;
/// the rest are None.
#[derive(Debug, Clone, PartialEq)]
pub struct ParityToken {
    pub kind: String,
    pub start: u32,
    pub end: u32,
    pub payload: Option<String>,
}

/// Target-syntax lexical parity entry point (seed-side oracle — a stable-shape projection
/// of `lex`).
///
/// Consumer: the switching-window step ② .krf lexer reconciliation
/// (target_reader_krf_tests — the byte-level parity gate over kind/Span/payload).
pub fn lex_for_parity(source: &str, file_id: u32) -> Result<Vec<ParityToken>, ReadError> {
    let toks = lex(source, file_id, &mut SymbolTable::new())?;
    Ok(toks
        .iter()
        .map(|t| ParityToken {
            kind: parity_kind(&t.kind).to_string(),
            start: t.span.start,
            end: t.span.end,
            payload: parity_payload(&t.kind),
        })
        .collect())
}

/// Tk → stable kind surface word (the parity comparison domain —
/// shared bridge/seed calibration).
fn parity_kind(k: &Tk) -> &'static str {
    match k {
        Tk::Int(_) => "int",
        Tk::Float(_) => "float",
        Tk::Str(_) => "str",
        Tk::Bool(true) => "true",
        Tk::Bool(false) => "false",
        Tk::Unit => "unit",
        Tk::Ident(_) => "ident",
        Tk::Path(_) => "path",
        Tk::KwFn => "fn",
        Tk::KwLet => "let",
        Tk::KwConst => "const",
        Tk::KwMut => "mut",
        Tk::KwIf => "if",
        Tk::KwElse => "else",
        Tk::KwModule => "module",
        Tk::KwImport => "import",
        Tk::KwExport => "export",
        Tk::KwRequire => "require",
        Tk::KwExtern => "extern",
        Tk::KwPerform => "perform",
        Tk::KwHandle => "handle",
        Tk::KwResume => "resume",
        // r132 / 202-c: target-face local keywords (the twelfth
        // skin-mapping family's handler-body positional words — halt/pass;
        // NOT in the shared Keyword enum: the S-expr face has no halt/pass
        // forms, so the shared E0020 strict-reserved domain stays untouched —
        // principle 27 additivity, the r129 macro precedent's second instance)
        Tk::KwHalt => "halt",
        Tk::KwPass => "pass",
        Tk::KwMove => "move",
        Tk::KwPub => "pub",
        Tk::KwUse => "use",
        Tk::KwMatch => "match",
        // r129 / 199-b: target-face local keyword (the ninth skin-dictionary
        // mapping head — macro-definition arm structure → define-syntax/
        // syntax-rules core form; NOT in the shared Keyword enum: the S-expr face
        // consumes define-syntax only, so the shared E0020 strict-reserved domain
        // stays untouched — principle 27 additivity)
        Tk::KwMacro => "macro",
        Tk::KwType => "type",
        Tk::KwEffect => "effect",
        Tk::KwCapability => "capability",
        Tk::KwStruct => "struct",
        Tk::KwEnum => "enum",
        Tk::KwAs => "as",
        Tk::Plus => "+",
        Tk::Minus => "-",
        Tk::Star => "*",
        Tk::Slash => "/",
        Tk::Percent => "%",
        Tk::Eq => "==",
        Tk::Assign => "=",
        Tk::Ne => "!=",
        Tk::Lt => "<",
        Tk::Gt => ">",
        Tk::Le => "<=",
        Tk::Ge => ">=",
        Tk::AndAnd => "&&",
        Tk::OrOr => "||",
        Tk::Colon => ":",
        Tk::PathSep => "::",
        Tk::Comma => ",",
        Tk::Semi => ";",
        Tk::Dot => ".",
        Tk::DotDot => "..",
        Tk::Arrow => "->",
        Tk::FatArrow => "=>",
        Tk::LParen => "(",
        Tk::RParen => ")",
        Tk::LBrace => "{",
        Tk::RBrace => "}",
        Tk::LBracket => "[",
        Tk::RBracket => "]",
        Tk::Or => "|",
        Tk::Amp => "&",
        Tk::Caret => "^",
        Tk::Shl => "<<",
        Tk::Shr => ">>",
        Tk::Pipe => "|>",
        Tk::MacroBang => "!",
        Tk::QuoteLifetime => "lifetime",
        Tk::Eof => "eof",
    }
}

/// Tk → parity payload (value textualization — reconciled against the same-source parse
/// on the bridge side).
fn parity_payload(k: &Tk) -> Option<String> {
    match k {
        Tk::Int(v) => Some(v.to_string()),
        Tk::Float(f) => Some(f.to_string()),
        Tk::Str(s) => Some(s.clone()),
        Tk::Ident(s) | Tk::Path(s) => Some(s.clone()),
        _ => None,
    }
}

/// Radix-marked digit text → i64 (.krf lexical payload contract — lowercase canonical
/// prefixes "0x"/"0o"/"0b"; an empty digit run = 0. The overflow guard is already
/// front-loaded in the .krf scan order — failure here = defensive path; the error
/// message mirrors the seed lexer's overflow message [r108 / 178-b]).
pub fn parse_int_payload_text(text: &str) -> Result<i64, &'static str> {
    let (radix, digits) = if let Some(rest) = text.strip_prefix("0x") {
        (16, rest)
    } else if let Some(rest) = text.strip_prefix("0o") {
        (8, rest)
    } else if let Some(rest) = text.strip_prefix("0b") {
        (2, rest)
    } else {
        (10, text)
    };
    if digits.is_empty() {
        Ok(0)
    } else {
        i64::from_str_radix(digits, radix).map_err(|_| "integer literal overflow")
    }
}

/// Float body text → f64 (.krf lexical payload contract — float-text-bad is already
/// front-loaded in the scan order; failure here = defensive path [r108 / 178-b]).
pub fn parse_float_payload_text(text: &str) -> Result<f64, &'static str> {
    text.parse().map_err(|_| "invalid float literal")
}

/// kind+payload → Tk Debug surface word (bridge-side syntax error message rendering —
/// single seed source).
///
/// The .krf parser's Token-embedded error shape `('err prefix kind payload s e)` is
/// rendered by the bridge calling this function, yielding a surface word equal to
/// `format!("{:?}", Tk)` (r108 / 178-b — host rendering boundary: f64 Debug and Str
/// escaping cannot be reliably reimplemented inside the VM).
pub fn tk_debug_of_kind(kind: &str, payload: Option<&str>) -> String {
    format!("{:?}", tk_of_kind(kind, payload))
}

/// kind+payload → Tk (the inverse mapping of parity_kind — reconstruction for Debug rendering).
fn tk_of_kind(kind: &str, payload: Option<&str>) -> Tk {
    match kind {
        "int" => Tk::Int(parse_int_payload_text(payload.unwrap_or("")).unwrap_or(i64::MAX)),
        "float" => Tk::Float(parse_float_payload_text(payload.unwrap_or("")).unwrap_or(0.0)),
        "str" => Tk::Str(payload.unwrap_or("").to_string()),
        "true" => Tk::Bool(true),
        "false" => Tk::Bool(false),
        "unit" => Tk::Unit,
        "ident" => Tk::Ident(payload.unwrap_or("").to_string()),
        "path" => Tk::Path(payload.unwrap_or("").to_string()),
        "fn" => Tk::KwFn,
        "let" => Tk::KwLet,
        "const" => Tk::KwConst,
        "mut" => Tk::KwMut,
        "if" => Tk::KwIf,
        "else" => Tk::KwElse,
        "module" => Tk::KwModule,
        "import" => Tk::KwImport,
        "export" => Tk::KwExport,
        "require" => Tk::KwRequire,
        "extern" => Tk::KwExtern,
        "perform" => Tk::KwPerform,
        "handle" => Tk::KwHandle,
        "resume" => Tk::KwResume,
        "halt" => Tk::KwHalt,
        "pass" => Tk::KwPass,
        "move" => Tk::KwMove,
        "pub" => Tk::KwPub,
        "use" => Tk::KwUse,
        "match" => Tk::KwMatch,
        "macro" => Tk::KwMacro,
        "type" => Tk::KwType,
        "effect" => Tk::KwEffect,
        "capability" => Tk::KwCapability,
        "struct" => Tk::KwStruct,
        "enum" => Tk::KwEnum,
        "as" => Tk::KwAs,
        "+" => Tk::Plus,
        "-" => Tk::Minus,
        "*" => Tk::Star,
        "/" => Tk::Slash,
        "%" => Tk::Percent,
        "==" => Tk::Eq,
        "=" => Tk::Assign,
        "!=" => Tk::Ne,
        "<" => Tk::Lt,
        ">" => Tk::Gt,
        "<=" => Tk::Le,
        ">=" => Tk::Ge,
        "&&" => Tk::AndAnd,
        "||" => Tk::OrOr,
        ":" => Tk::Colon,
        "::" => Tk::PathSep,
        "," => Tk::Comma,
        ";" => Tk::Semi,
        "." => Tk::Dot,
        ".." => Tk::DotDot,
        "->" => Tk::Arrow,
        "=>" => Tk::FatArrow,
        "(" => Tk::LParen,
        ")" => Tk::RParen,
        "{" => Tk::LBrace,
        "}" => Tk::RBrace,
        "[" => Tk::LBracket,
        "]" => Tk::RBracket,
        "|" => Tk::Or,
        "&" => Tk::Amp,
        "^" => Tk::Caret,
        "<<" => Tk::Shl,
        ">>" => Tk::Shr,
        "|>" => Tk::Pipe,
        "!" => Tk::MacroBang,
        "lifetime" => Tk::QuoteLifetime,
        _ => Tk::Eof,
    }
}

#[cfg(test)]
mod tk_debug_tests {
    use super::*;

    /// Single-source verification of Tk Debug rendering: parity_kind + parity_payload →
    /// tk_debug_of_kind reconstructs a surface word equal to the native `{:?}`
    /// (r108 / 178-b — the seed anchor of bridge-side syntax error message parity;
    /// int/float round-trip losslessly via Display→parse→Debug).
    #[test]
    fn tk_debug_round_trip() {
        let samples: Vec<Tk> = vec![
            Tk::Int(0),
            Tk::Int(5),
            Tk::Int(-3),
            Tk::Int(i64::MAX),
            Tk::Int(i64::MIN),
            Tk::Float(1.5),
            Tk::Float(0.1),
            Tk::Float(1e300),
            Tk::Float(-0.25),
            Tk::Float(2.0),
            Tk::Str(String::new()),
            Tk::Str("s".into()),
            Tk::Str("a\"b".into()),
            Tk::Str("tab\t.nl\n.bs\\".into()),
            Tk::Str("中文内容".into()),
            Tk::Bool(true),
            Tk::Bool(false),
            Tk::Unit,
            Tk::Ident("x".into()),
            Tk::Ident("_private".into()),
            Tk::Path("a/b".into()),
            Tk::Path("kerf/string/append".into()),
            Tk::KwFn,
            Tk::KwLet,
            Tk::KwConst,
            Tk::KwMut,
            Tk::KwIf,
            Tk::KwElse,
            Tk::KwModule,
            Tk::KwImport,
            Tk::KwExport,
            Tk::KwRequire,
            Tk::KwPerform,
            Tk::KwHandle,
            Tk::KwResume,
            Tk::KwHalt,
            Tk::KwPass,
            Tk::KwMove,
            Tk::KwPub,
            Tk::KwUse,
            Tk::KwMatch,
            Tk::KwExtern,
            Tk::KwType,
            Tk::KwEffect,
            Tk::KwCapability,
            Tk::KwStruct,
            Tk::KwEnum,
            Tk::KwAs,
            Tk::Plus,
            Tk::Minus,
            Tk::Star,
            Tk::Slash,
            Tk::Percent,
            Tk::Eq,
            Tk::Assign,
            Tk::Ne,
            Tk::Lt,
            Tk::Gt,
            Tk::Le,
            Tk::Ge,
            Tk::AndAnd,
            Tk::OrOr,
            Tk::Colon,
            Tk::PathSep,
            Tk::Comma,
            Tk::Semi,
            Tk::Dot,
            Tk::DotDot,
            Tk::Arrow,
            Tk::FatArrow,
            Tk::LParen,
            Tk::RParen,
            Tk::LBrace,
            Tk::RBrace,
            Tk::LBracket,
            Tk::RBracket,
            Tk::Or,
            Tk::Amp,
            Tk::Caret,
            Tk::Shl,
            Tk::Shr,
            Tk::Pipe,
            Tk::MacroBang,
            Tk::QuoteLifetime,
            Tk::Eof,
        ];
        assert!(
            samples.len() >= 60,
            "Tk all change body coverage(actual {})",
            samples.len()
        );
        for tk in &samples {
            let kind = parity_kind(tk);
            let payload = parity_payload(tk);
            let rendered = tk_debug_of_kind(kind, payload.as_deref());
            assert_eq!(
                rendered,
                format!("{:?}", tk),
                "Tk Debug render distortion (kind = {}): rebuilt {:?} ≠ native {:?}",
                kind,
                rendered,
                tk
            );
        }
    }
}

// ---------------------------------------------------------------------------
// Lexical layer (EBNF v9 8.13.1 full lexical layer — Rust minimal-set completion)
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, PartialEq)]
enum Tk {
    // Literals
    Int(i64),
    Float(f64),
    Str(String),
    Bool(bool),
    Unit, // ()
    // Identifiers and paths
    Ident(String),
    Path(String), // a::b → flattened "a/b" (22 §27 delimiter two-face mapping)
    // Keywords (Level 0 surface words)
    KwFn,
    KwLet,
    KwMut,
    /// `const` (r161 / 231-c — const-declaration-design.md D1): the
    /// fourteenth target-face local keyword — the read-only binding
    /// declaration's head word (`const name [: T] = e;` → the as-if-written
    /// `(define name e)` skin, the r158 toplevel-let precedent; principle
    /// 31 skin/skeleton isomorphism). Local to the target lexer like
    /// `mut`/`halt`/`pass`: the S-expr face has no const form (define is
    /// its native binding name), so the E0020 shared reserved domain
    /// stays untouched (principle 27).
    KwConst,
    KwIf,
    KwElse,
    KwModule,
    KwImport,
    KwExport,
    KwRequire,
    /// `extern` (r137 / 207-c — TD-026 language-surface window,
    /// ffi-language-surface-design.md §2.2/D8): the FFI extern declaration
    /// family head — `extern name(kinds) -> kind;` → `(extern name (kinds) kind)`.
    /// A shared-keyword declaration (both faces have the form — unlike
    /// halt/pass/macro which are target-local skins), so the S-expr-face
    /// Keyword enum carries Extern too (the 28th shared reserved word).
    KwExtern,
    KwPerform,
    KwHandle,
    KwResume,
    /// `halt` / `pass` (r132 / 202-c — target-face local keywords, the
    /// twelfth skin-mapping family's handler-body positional words:
    /// handle-multi-arm-design.md §2 D7. Local to the target lexer like
    /// `macro` (r129): the S-expr face has no halt/pass forms (halt = the
    /// no-resume tail value; pass = `(perform (cons 'T p))`), so the shared
    /// Keyword/E0020 strict-reserved domain stays untouched — principle 27
    /// additivity. Consumed at the handler-body position only — any other
    /// position hits the ordinary "expected expression" fail-closed path.)
    KwHalt,
    KwPass,
    KwMove,
    KwPub,
    KwUse,
    KwMatch,
    /// `macro` (r129 / 199-b — target-face local keyword: the macro-definition
    /// skin head, the ninth skin-dictionary mapping. Local to the target lexer:
    /// the S-expr face's macro-definition entry is `define-syntax` (Keyword::
    /// DefineSyntax in the shared symbol.rs enum — already interned), so `macro`
    /// never joins the shared Keyword/E0020 strict-reserved domain. Consumed at
    /// the top-level item position only — an expression-position `macro` hits the
    /// ordinary "expected expression" fail-closed path.)
    KwMacro,
    KwType,
    KwEffect,
    KwCapability,
    KwStruct,
    KwEnum,
    KwAs,
    // Operators and delimiters
    Plus,
    Minus,
    Star,
    Slash,
    Percent,
    Eq,     // ==
    Assign, // = (let/assign position)
    Ne,     // !=
    Lt,
    Gt,
    Le,
    Ge,
    AndAnd,
    OrOr,
    Colon,   // : (type/field position)
    PathSep, // ::
    Comma,
    Semi,
    Dot,
    DotDot,   // .. (range — registered out-of-domain diagnostic position)
    Arrow,    // ->
    FatArrow, // =>
    LParen,
    RParen,
    LBrace,
    RBrace,
    LBracket,
    RBracket,
    Or,  // | (bitwise or — registered out-of-domain diagnostic position)
    Amp, // & (bitwise and — registered out-of-domain diagnostic position)
    Caret,
    Shl,
    Shr,
    Pipe,          // |> (registered out-of-domain diagnostic position)
    MacroBang,     // the ! of name! (suffix determination via lookahead; the lexer emits the bang)
    QuoteLifetime, // 'x (type-syntax domain — lifetime variable)
    Eof,
}

#[derive(Debug, Clone)]
struct TToken {
    kind: Tk,
    span: Span,
}

/// Typed parameter list outcome: fixed params plus an optional terminal
/// rest parameter (r165 / 236-b — variadic-rest-design.md D1/D2). A named
/// alias keeps the `parse_typed_params` signature under the clippy
/// type-complexity bar.
type TypedParams = (Vec<(String, Span)>, Option<(String, Span)>);

fn is_id_start(c: char) -> bool {
    c.is_ascii_alphabetic() || c == '_'
}

fn is_id_continue(c: char) -> bool {
    c.is_ascii_alphabetic() || c.is_ascii_digit() || c == '_'
}

/// Lexical layer: target-syntax Token stream (nested block comments / radix literals /
/// full escapes).
fn lex(src: &str, file_id: u32, interner: &mut SymbolTable) -> Result<Vec<TToken>, ReadError> {
    let _ = interner; // zero semantics at the lexical layer
                      // (symbol interning is deferred to the syntax layer)
    let chars: Vec<char> = src.chars().collect();
    // Byte-offset table (char index → byte offset; last entry = blen) — r107 R1 stub
    // settlement: the original "char index as Span offset" was an ASCII-domain
    // simplification (176-e registered boundary); the switching-window step ② .krf-ification
    // reconciliation requires byte-exact calibration (same source as the reader.krf contract —
    // string-to-pos-chars yields true byte offsets); the "precise Token Span" invariant
    // henceforth covers full-Unicode sources.
    let mut byte_of: Vec<u32> = Vec::with_capacity(chars.len() + 1);
    let mut bo = 0u32;
    for &ch in &chars {
        byte_of.push(bo);
        bo += ch.len_utf8() as u32;
    }
    byte_of.push(bo); // index == chars.len() → blen (EOF / right bound of the last char)
    let mut toks: Vec<TToken> = Vec::new();
    let mut i = 0usize;
    let sp = |a: usize, b: usize| Span::new(file_id, byte_of[a], byte_of[b]);
    while i < chars.len() {
        let c = chars[i];
        // Whitespace
        if c.is_whitespace() {
            i += 1;
            continue;
        }
        // Line comment
        if c == '/' && chars.get(i + 1) == Some(&'/') {
            while i < chars.len() && chars[i] != '\n' {
                i += 1;
            }
            continue;
        }
        // Block comment (nested — same shape as Rust)
        if c == '/' && chars.get(i + 1) == Some(&'*') {
            let start = i;
            i += 2;
            let mut depth = 1;
            while i < chars.len() && depth > 0 {
                if chars[i] == '/' && chars.get(i + 1) == Some(&'*') {
                    depth += 1;
                    i += 2;
                } else if chars[i] == '*' && chars.get(i + 1) == Some(&'/') {
                    depth -= 1;
                    i += 2;
                } else {
                    i += 1;
                }
            }
            if depth > 0 {
                return Err(ReadError::new("unclosed block comment", sp(start, i)));
            }
            continue;
        }
        // Numeric literal (decimal/hex/octal/binary + float + digit separators)
        if c.is_ascii_digit() {
            let start = i;
            let (radix, mut val): (u32, i128) = if c == '0' {
                match chars.get(i + 1) {
                    Some('x') | Some('X') => {
                        i += 2;
                        (16, 0)
                    }
                    Some('o') | Some('O') => {
                        i += 2;
                        (8, 0)
                    }
                    Some('b') | Some('B') => {
                        i += 2;
                        (2, 0)
                    }
                    _ => (10, 0),
                }
            } else {
                (10, 0)
            };
            let mut is_float = false;
            let mut float_text = String::new();
            while i < chars.len() {
                let d = chars[i];
                if d == '_' {
                    i += 1;
                    continue;
                }
                if radix == 10 {
                    if d.is_ascii_digit() {
                        val = val * 10 + (d as i128 - '0' as i128);
                        float_text.push(d);
                        i += 1;
                        continue;
                    }
                    if d == '.'
                        && chars
                            .get(i + 1)
                            .map(|c| c.is_ascii_digit())
                            .unwrap_or(false)
                    {
                        is_float = true;
                        float_text.push('.');
                        i += 1;
                        continue;
                    }
                    if d == 'e' || d == 'E' {
                        // Float exponent (r107 defect fix: the sign is consumed into
                        // float_text — originally, after the j lookahead check, i was not
                        // advanced, so a signed exponent `1e+5` produced the broken Token
                        // "1e" → f64 parsing always failed with the illegal-float-literal error)
                        let mut j = i + 1;
                        if chars.get(j) == Some(&'+') || chars.get(j) == Some(&'-') {
                            j += 1;
                        }
                        if chars.get(j).map(|c| c.is_ascii_digit()).unwrap_or(false) {
                            is_float = true;
                            float_text.push(d);
                            i += 1;
                            // Consume the sign (fix surface — same calibration
                            // as the lookahead check)
                            if chars.get(i) == Some(&'+') || chars.get(i) == Some(&'-') {
                                float_text.push(chars[i]);
                                i += 1;
                            }
                            // Exponent body (r107 alignment: `_` separators are skipped
                            // under the same rule as the mantissa — originally they were
                            // pushed into float_text, so `1e5_0` always failed to parse)
                            while i < chars.len() {
                                let e = chars[i];
                                if e.is_ascii_digit() {
                                    float_text.push(e);
                                    i += 1;
                                } else if e == '_' {
                                    i += 1;
                                } else {
                                    break;
                                }
                            }
                            continue;
                        }
                    }
                    break;
                } else {
                    let digit = d.to_digit(radix);
                    match digit {
                        Some(v) => {
                            val = val * radix as i128 + v as i128;
                            i += 1;
                        }
                        None => break,
                    }
                }
            }
            let span = sp(start, i);
            if is_float {
                let f: f64 = float_text
                    .parse()
                    .map_err(|_| ReadError::new("invalid float literal", span))?;
                toks.push(TToken {
                    kind: Tk::Float(f),
                    span,
                });
            } else {
                let v = i64::try_from(val)
                    .map_err(|_| ReadError::new("integer literal overflow", span))?;
                toks.push(TToken {
                    kind: Tk::Int(v),
                    span,
                });
            }
            continue;
        }
        // Lifetime variable 'x (type-syntax domain)
        if c == '\'' && chars.get(i + 1).map(|c| is_id_start(*c)).unwrap_or(false) {
            let start = i;
            i += 1;
            while i < chars.len() && is_id_continue(chars[i]) {
                i += 1;
            }
            toks.push(TToken {
                kind: Tk::QuoteLifetime,
                span: sp(start, i),
            });
            continue;
        }
        // String literal (full escapes)
        if c == '"' {
            let start = i;
            i += 1;
            let mut text = String::new();
            loop {
                match chars.get(i) {
                    None => return Err(ReadError::new("unclosed string", sp(start, i))),
                    Some('"') => {
                        i += 1;
                        break;
                    }
                    Some('\\') => {
                        i += 1;
                        match chars.get(i) {
                            Some('n') => text.push('\n'),
                            Some('t') => text.push('\t'),
                            Some('r') => text.push('\r'),
                            Some('0') => text.push('\0'),
                            Some('\\') => text.push('\\'),
                            Some('"') => text.push('"'),
                            Some('\'') => text.push('\''),
                            other => {
                                let at = i;
                                // Span right bound = the byte offset after the escape
                                // character; an EOF backslash mirrors the original
                                // char-index calibration (last position + a virtual
                                // one-byte escape char → +2)
                                let end = if at < chars.len() {
                                    byte_of[at + 1]
                                } else {
                                    byte_of[at - 1] + 2
                                };
                                return Err(ReadError::new(
                                    format!("illegal escape:\\{}", other.unwrap_or(&' ')),
                                    Span::new(file_id, byte_of[at - 1], end),
                                ));
                            }
                        }
                        i += 1;
                    }
                    Some(&ch) => {
                        text.push(ch);
                        i += 1;
                    }
                }
            }
            toks.push(TToken {
                kind: Tk::Str(text),
                span: sp(start, i),
            });
            continue;
        }
        // Identifier / keyword / boolean / path
        if is_id_start(c) {
            let start = i;
            while i < chars.len() && is_id_continue(chars[i]) {
                i += 1;
            }
            let word: String = chars[start..i].iter().collect();
            let kind = match word.as_str() {
                "fn" => Tk::KwFn,
                "let" => Tk::KwLet,
                "const" => Tk::KwConst,
                "mut" => Tk::KwMut,
                "if" => Tk::KwIf,
                "else" => Tk::KwElse,
                "module" => Tk::KwModule,
                "import" => Tk::KwImport,
                "export" => Tk::KwExport,
                "require" => Tk::KwRequire,
                "extern" => Tk::KwExtern,
                "perform" => Tk::KwPerform,
                "handle" => Tk::KwHandle,
                "resume" => Tk::KwResume,
                "halt" => Tk::KwHalt,
                "pass" => Tk::KwPass,
                "move" => Tk::KwMove,
                "pub" => Tk::KwPub,
                "use" => Tk::KwUse,
                "match" => Tk::KwMatch,
                "macro" => Tk::KwMacro,
                "type" => Tk::KwType,
                "effect" => Tk::KwEffect,
                "capability" => Tk::KwCapability,
                "struct" => Tk::KwStruct,
                "enum" => Tk::KwEnum,
                "as" => Tk::KwAs,
                "true" => Tk::Bool(true),
                "false" => Tk::Bool(false),
                _ => Tk::Ident(word.clone()),
            };
            // qualified_name: Ident { "::" Ident }
            if matches!(kind, Tk::Ident(_)) {
                let mut full = word;
                let mut end = i;
                while chars.get(end) == Some(&':')
                    && chars.get(end + 1) == Some(&':')
                    && chars.get(end + 2).map(|c| is_id_start(*c)).unwrap_or(false)
                {
                    let mut j = end + 2;
                    while j < chars.len() && is_id_continue(chars[j]) {
                        j += 1;
                    }
                    full.push('/');
                    full.extend(chars[end + 2..j].iter());
                    end = j;
                }
                i = end;
                let span = sp(start, i);
                let kind = if full.contains('/') {
                    Tk::Path(full)
                } else {
                    Tk::Ident(full)
                };
                toks.push(TToken { kind, span });
            } else {
                toks.push(TToken {
                    kind,
                    span: sp(start, i),
                });
            }
            continue;
        }
        // Delimiters and operators (:: is decided before :)
        let start = i;
        // r129 / 199-b: `...` ellipsis (the ninth skin-dictionary mapping — a
        // macro pattern/template element). Lexed as the identifier payload
        // "..." so it flows through the ordinary identifier channels (call
        // arguments / pattern elements / block statements) and renders as the
        // Stx symbol `...` — the exact isomorphism of the S-expr face, where
        // `...` is an ordinary symbol consumed by macro_sys (is_ellipsis).
        // Checked before the `..` two-char prefix so `...` never splits.
        let three = |a: char, b: char, c2: char| {
            c == a && chars.get(i + 1) == Some(&b) && chars.get(i + 2) == Some(&c2)
        };
        let two = |a: char, b: char| c == a && chars.get(i + 1) == Some(&b);
        let kind = if three('.', '.', '.') {
            i += 3;
            Tk::Ident("...".to_string())
        } else if two(':', ':') {
            i += 2;
            Tk::PathSep
        } else if two('=', '=') {
            i += 2;
            Tk::Eq
        } else if two('!', '=') {
            i += 2;
            Tk::Ne
        } else if two('<', '=') {
            i += 2;
            Tk::Le
        } else if two('>', '=') {
            i += 2;
            Tk::Ge
        } else if two('&', '&') {
            i += 2;
            Tk::AndAnd
        } else if two('|', '|') {
            i += 2;
            Tk::OrOr
        } else if two('.', '.') {
            i += 2;
            Tk::DotDot
        } else if two('-', '>') {
            i += 2;
            Tk::Arrow
        } else if two('=', '>') {
            i += 2;
            Tk::FatArrow
        } else if two('|', '>') {
            i += 2;
            Tk::Pipe
        } else if two('<', '<') {
            i += 2;
            Tk::Shl
        } else if two('>', '>') {
            i += 2;
            Tk::Shr
        } else if two('/', '/') {
            unreachable!() // line comments are already handled up front
        } else {
            i += 1;
            match c {
                '+' => Tk::Plus,
                '-' => Tk::Minus,
                '*' => Tk::Star,
                '/' => Tk::Slash,
                '%' => Tk::Percent,
                '=' => Tk::Assign,
                '<' => Tk::Lt,
                '>' => Tk::Gt,
                '!' => Tk::MacroBang,
                '&' => Tk::Amp,
                '|' => Tk::Or,
                '^' => Tk::Caret,
                ':' => Tk::Colon,
                ',' => Tk::Comma,
                ';' => Tk::Semi,
                '.' => Tk::Dot,
                '(' => {
                    // unit_literal "()" (lexical lookahead — the parser rules on non-call contexts)
                    if chars.get(i) == Some(&')') {
                        i += 1;
                        Tk::Unit
                    } else {
                        Tk::LParen
                    }
                }
                ')' => Tk::RParen,
                '{' => Tk::LBrace,
                '}' => Tk::RBrace,
                '[' => Tk::LBracket,
                ']' => Tk::RBracket,
                other => {
                    return Err(ReadError::new(
                        format!("illegal character:{}", other),
                        sp(start, i),
                    ));
                }
            }
        };
        toks.push(TToken {
            kind,
            span: sp(start, i),
        });
    }
    toks.push(TToken {
        kind: Tk::Eof,
        span: sp(i, i),
    });
    Ok(toks)
}

// ---------------------------------------------------------------------------
// Syntax layer (skin dictionary mapping — target surface → S-expr surface Stx)
// ---------------------------------------------------------------------------

/// Target-surface identifier word separator → S-expr surface symbol name
/// (r109 / 179-a ruling 1 — a new skin dictionary naming-mapping entry:
/// the `-` ↔ `_` two-face mapping).
///
/// The target-surface `id_continue` does not include `-` (the `is-nil` lexes as the
/// subtraction chain `is - nil` — not representable); the S-expr surface production
/// name domain (builtins / .krf definition names / module names) was grep-verified to
/// contain zero `_` → the mapping is unambiguous. bare `_` (placeholder semantics)
/// stays identical as an exception. Token payloads keep the original surface text
/// (zero semantics/lossless at the lexical layer — the mapping happens only at the
/// symbol-introduction boundary, principle 31: the skin→core conversion point).
/// The bridge's (bootstrap/reader.rs) 'sym→Stx conversion is same-source with
/// this function — two-sided parity.
pub fn symbol_name(name: &str) -> String {
    if name == "_" || !name.contains('_') {
        return name.to_string();
    }
    name.replace('_', "-")
}

/// Symbol constructor (free fn — avoids multiple mutable borrows in one expression).
/// The name enters the table after the [`symbol_name`] skin dictionary
/// naming mapping (r109).
fn sym_at(table: &mut SymbolTable, name: &str, span: Span) -> Stx {
    let s = table.intern(&symbol_name(name));
    Stx::symbol(s, span, ScopeSet::new())
}

/// List constructor (free fn).
fn list_at(items: Vec<Stx>, span: Span) -> Stx {
    Stx::list(items, span, ScopeSet::new())
}

/// One staged import item: the module name plus its optional alias pair
/// (alias name, `as` span, alias span) — the tenth skin mapping's parse
/// artifact (r130: `import a as b, c;` → `(import a as b c)`).
struct ImportItem {
    name: String,
    name_span: Span,
    alias: Option<(String, Span, Span)>,
}

/// Maximum nesting depth (parser stack protection — the target-face
/// mirror of the S-expr face's `MAX_NESTING_DEPTH` guard [principle 58 /
/// FS-1 anchor]; r149 / 219-b2: the target Reader previously carried NO
/// depth cap — deep-nesting `.ktf` input crashed with a stack overflow
/// instead of a fail-closed rejection, an asymmetry surfaced by the
/// S-expr removal window Batch A's negative audit [same-path full
/// audit, §20.3] — cleared in-window. Counting caliber: one level per
/// `parse_expr` / `parse_block` / `parse_pattern_or` / `consume_type`
/// recursion — structurally comparable to the S-expr datum-depth count,
/// with the same 256 cap and the same message family).
const TARGET_MAX_NESTING_DEPTH: usize = 256;

struct Parser<'t, 'i> {
    toks: &'t [TToken],
    pos: usize,
    table: &'i mut SymbolTable,
    /// Recursion depth of the structural parse (expression / block /
    /// macro-pattern / type families — the defensive cap above; the
    /// target-face counterpart of the S-expr parser's `depth` field).
    depth: usize,
    /// r133 / 203-c2 (nested-resume-design.md D2/D3): the innermost
    /// enclosing handler arm's resume binder — the handler-scope state
    /// consulted at every block statement/tail position lexically inside
    /// a handler arm body (nested if-arm / closure-body / nested-handle-arm
    /// blocks included — D1); `None` everywhere else (plain blocks, a
    /// nested handle's protected expression — D5, the pre-handle parse).
    /// save/restore around parse_handle mirrors the S-expr lexical
    /// shadowing (D3: a nested handle's own arms install their binder and
    /// restore the enclosing one on exit).
    handler_k: Option<(String, Span)>,
    /// r161 / 231-c (const-declaration-design.md D3): the sequential
    /// const-binding set for the current item scope — names whose latest
    /// item-position binding is `const` (read-only at the item-position
    /// statement face). Updated in parse order: `const` inserts, any
    /// other item-position rebinding (let/fn/macro/import/module) removes
    /// (latest binding wins); module bodies save/clear/restore
    /// (module-local const scope). Consulted by the item-position assign
    /// statement gate in parse_stmt_into.
    const_names: Vec<String>,
}

impl<'t, 'i> Parser<'t, 'i> {
    fn new(toks: &'t [TToken], table: &'i mut SymbolTable) -> Self {
        Parser {
            toks,
            pos: 0,
            table,
            depth: 0,
            handler_k: None,
            const_names: Vec::new(),
        }
    }

    // ---- Infrastructure ----

    /// Depth-guard entry (increments, fail-closed rejects beyond the cap;
    /// the caller MUST pair with `self.depth -= 1` after the recursion
    /// returns — Ok or Err alike).
    fn depth_enter(&mut self, sp: Span) -> Result<(), ReadError> {
        self.depth += 1;
        if self.depth > TARGET_MAX_NESTING_DEPTH {
            self.depth -= 1;
            return Err(ReadError::new(
                format!(
                    "nesting depth exceeds the limit {}",
                    TARGET_MAX_NESTING_DEPTH
                ),
                sp,
            ));
        }
        Ok(())
    }

    fn peek(&self) -> &Tk {
        &self.toks[self.pos.min(self.toks.len() - 1)].kind
    }

    fn peek_at(&self, off: usize) -> &Tk {
        &self.toks[(self.pos + off).min(self.toks.len() - 1)].kind
    }

    fn span_at(&self, pos: usize) -> Span {
        self.toks[pos.min(self.toks.len() - 1)].span
    }

    fn cur_span(&self) -> Span {
        self.span_at(self.pos)
    }

    fn bump(&mut self) -> Tk {
        let k = self.toks[self.pos.min(self.toks.len() - 1)].kind.clone();
        self.pos += 1;
        k
    }

    fn eat(&mut self, k: &Tk) -> bool {
        if self.peek() == k {
            self.bump();
            true
        } else {
            false
        }
    }

    fn expect(&mut self, k: Tk, what: &str) -> Result<Span, ReadError> {
        if *self.peek() == k {
            let sp = self.cur_span();
            self.bump();
            Ok(sp)
        } else {
            Err(ReadError::new(
                format!("expected {}, got {:?}", what, self.peek()),
                self.cur_span(),
            ))
        }
    }

    fn merge_span(a: Span, b: Span) -> Span {
        Span::new(a.file_id, a.start.min(b.start), a.end.max(b.end))
    }

    /// Registered out-of-domain diagnostic (inside the EBNF v9 Level 0 domain but
    /// outside the core consumption domain — later switching-window batches).
    fn domain_out(&self, what: &str) -> ReadError {
        ReadError::new(
            format!(
                "target syntax Reader v1 registration out of domain:{}(EBNF v9 Level 0 in domain·kernel mapping out of domain -- later switch-window batches)",
                what
            ),
            self.cur_span(),
        )
    }

    // ---- Top level ----

    fn parse_program(&mut self) -> Result<Vec<Stx>, ReadError> {
        let mut items = Vec::new();
        while !matches!(self.peek(), Tk::Eof) {
            items.push(self.parse_item()?);
        }
        Ok(items)
    }

    fn parse_item(&mut self) -> Result<Stx, ReadError> {
        match self.peek().clone() {
            Tk::KwPub => Err(self.domain_out("pub visibility modifier")),
            Tk::KwFn => self.parse_fn_decl(),
            Tk::KwModule => self.parse_module_decl(),
            Tk::KwImport => self.parse_import_decl(),
            Tk::KwExport => self.parse_export_decl(),
            // r125 / 195-a: require capability declaration (the top-level
            // declaration family — import/export/require one family;
            // skin-dictionary eighth mapping, see parse_require_decl)
            Tk::KwRequire => self.parse_require_decl(),
            // r137 / 207-c: FFI extern declaration (the TD-026 language-surface
            // window — the top-level declaration family's fourth member after
            // import/export/require; skin-dictionary thirteenth mapping,
            // see parse_extern_decl)
            Tk::KwExtern => self.parse_extern_decl(),
            // r129 / 199-b: macro definition (the ninth skin-dictionary mapping —
            // `macro NAME (lits)? { arms }` → (define-syntax ...)); top-level
            // item position only — inside blocks the ordinary fail-closed
            // "expected expression" path guards it)
            Tk::KwMacro => self.parse_macro_decl(),
            Tk::KwUse => self.parse_use_decl(),
            // r158 / 228-c: top-level value binding — `let name [: T] = e;` →
            // `(define name e')` — the modern replacement for the retired
            // `define(name, e);` call form (toplevel-let-design.md D1/D3;
            // toplevel_let production — the Level 0 addendum). Top-level and
            // module item positions (the parse_item dispatch — symmetric with
            // the fn/import/export/require family); inside blocks the
            // block-level let_stmt face keeps its own semantics.
            Tk::KwLet => self.parse_toplevel_let(),
            // r161 / 231-c: top-level const declaration — `const name [: T] = e;`
            // → `(define name e')` — the sixteenth skin mapping and the
            // read-only binding face (const-declaration-design.md D1/D3;
            // toplevel_const production — the Level 0 addendum, the
            // toplevel_let twin). Top-level and module item positions
            // (the parse_item dispatch); inside blocks the dedicated
            // fail-closed domain-out arm in parse_stmt_or_expr guards it.
            Tk::KwConst => self.parse_const_decl(),
            // r158 / 228-c: the S-expr-era define call form is retired at item
            // position (toplevel-let-design.md D2) — a dedicated fail-closed
            // modernization diagnostic at the `define` token itself (the r130
            // import-as span precedent). Block/expression positions keep the
            // ordinary-call semantics (unbound identifier E0022 — honest
            // boundary, unchanged). The lookahead covers both the `define(x)`
            // shape (LParen) and the `define()` zero-arg shape (the lexical
            // Unit token — the parse_typed_params dual-meaning precedent).
            Tk::Ident(n)
                if n == "define"
                    && matches!(*self.peek_at(1), Tk::LParen | Tk::Unit) =>
            {
                Err(ReadError::new(
                    "the define call form is retired: use a top-level let binding (let name = value;) instead"
                        .to_string(),
                    self.cur_span(),
                ))
            }
            Tk::KwType | Tk::KwStruct | Tk::KwEnum => {
                Err(self.domain_out("type declaration (type system implementation window)"))
            }
            Tk::KwEffect => {
                Err(self.domain_out("effect declaration (effect system implementation window)"))
            }
            Tk::KwCapability => Err(self
                .domain_out("capability declaration (capability operation syntax family Level 2)")),
            _ => self.parse_stmt_into(None, &mut Vec::new()),
        }
    }

    /// import declaration: `import a, b::c;` → `(import a b/c)`; with the
    /// alias pair `import a as b, c;` → `(import a as b c)`
    /// (r109 / 179-a ruling 4 — N1 module production-surface skin entry; inside a
    /// module = head sub-form [expander head scan-order compatible], at top level =
    /// dependency pre-declaration [reader.krf batch pre-staging]. The alias pair is
    /// the tenth skin mapping — r130: symbol-for-symbol isomorphic to the S-expr
    /// three-shape import form `(import a as b)` [r40 M2 / 22 §8 R-N5; the driver's
    /// collect_import_items consumes it unchanged — zero desugar, zero new
    /// primitives, principle 31].)
    fn parse_import_decl(&mut self) -> Result<Stx, ReadError> {
        let start = self.expect(Tk::KwImport, "import")?;
        // import_item = (ident | path) ["as" (ident | path)].
        let mut items: Vec<ImportItem> = Vec::new();
        loop {
            let nsp = self.cur_span();
            let name = match self.bump() {
                Tk::Ident(n) | Tk::Path(n) => n,
                Tk::KwAs => {
                    // `as` where a module name is expected = the alias shape
                    // missing its module name. Span = the `as` token itself
                    // (pre-bump nsp — also repairs the latent seed/mirror
                    // span divergence of the pre-window fail-closed arm,
                    // which reported the post-bump position on this side
                    // while the mirror reported the `as` token).
                    return Err(ReadError::new(
                        "import as alias must follow the module name (module name missing)"
                            .to_string(),
                        nsp,
                    ));
                }
                other => {
                    return Err(ReadError::new(
                        format!("expected an import name, got {:?}", other),
                        nsp,
                    ));
                }
            };
            let alias = if matches!(self.peek(), Tk::KwAs) {
                let asp = self.cur_span();
                self.bump();
                let alsp = self.cur_span();
                match self.bump() {
                    Tk::Ident(a) | Tk::Path(a) => Some((a, asp, alsp)),
                    other => {
                        return Err(ReadError::new(
                            format!("expected an alias identifier, got {:?}", other),
                            alsp,
                        ));
                    }
                }
            } else {
                None
            };
            items.push(ImportItem {
                name,
                name_span: nsp,
                alias,
            });
            if !self.eat(&Tk::Comma) {
                break;
            }
        }
        let end = self.expect(Tk::Semi, ";")?;
        let span = Self::merge_span(start, end);
        Ok(list_at(
            {
                let mut v = vec![sym_at(self.table, "import", start)];
                for it in items {
                    v.push(sym_at(self.table, &it.name, it.name_span));
                    if let Some((a, asp, alsp)) = it.alias {
                        // The `as` marker enters the Stx as a plain symbol —
                        // exactly the S-expr face's list element (r40 M2's
                        // collect_import_items matches it by name).
                        v.push(sym_at(self.table, "as", asp));
                        v.push(sym_at(self.table, &a, alsp));
                    }
                }
                v
            },
            span,
        ))
    }

    /// use declaration (the eleventh skin mapping — r131 / use-declaration-design.md
    /// v1.1 + member-rename-design.md v1.0 §3 D1-D10): `use mod;` | `use mod as a;` |
    /// `use mod::{m1, m2};` | `use mod::{m as x};` | `use mod::{m} as a;` |
    /// `use a, b::{x};` → the S-expr import family Stx (full r40 M2 / alias
    /// r130 / **selective r50 D65** / **member rename r134** — the r131 D3
    /// domain-out retired this window: the selection-list `m as x` triple
    /// is now accepted on both faces). Zero new semantics, zero driver
    /// desugar (collect_import_items consumes the selection list with the
    /// as-triple awareness — principle 31 skin/skeleton isomorphism;
    /// design single source = member-rename-design.md v1.0).
    ///
    /// Element order per path = name, [as, alias], [selection-list] — the
    /// consumer's order (collect_import_items checks the as pair at i+1/i+2
    /// then the selection list at i+skip; D9: surface order braces-then-as
    /// is not preserved — consumer order is the sole constraint). Multi-
    /// segment paths (`kerf::string`, lexed as a merged Path token) are
    /// accepted here and rejected at compile time via E0019 — the single-
    /// layer module-name ruling (22 §7), identical criterion to import.
    fn parse_use_decl(&mut self) -> Result<Stx, ReadError> {
        let start = self.expect(Tk::KwUse, "use")?;
        let mut elems: Vec<Stx> = Vec::new();
        loop {
            let nsp = self.cur_span();
            let name = match self.bump() {
                Tk::Ident(n) | Tk::Path(n) => n,
                Tk::KwAs => {
                    // `as` where a module name is expected = the alias shape
                    // missing its module name (the import family's dedicated
                    // diagnostic, span = the `as` token itself — D10)
                    return Err(ReadError::new(
                        "use as alias must follow the module name (module name missing)"
                            .to_string(),
                        nsp,
                    ));
                }
                other => {
                    return Err(ReadError::new(
                        format!("expected use module name, got {:?}", other),
                        nsp,
                    ));
                }
            };
            elems.push(sym_at(self.table, &name, nsp));
            // Selection braces: `::` `{` member {"," member} [","] `}` — the
            // use_tree list. Members are bare identifiers or the rename
            // triple `m as x` (r134 / member-rename-design.md v1.0 §3 D2 —
            // the r131 D3 domain-out retired; the as marker + the renamed
            // identifier enter the selection list as plain symbols — the
            // S-expr face's flat triple, consumer-order isomorphism).
            // A leading `as` (no member name before it) falls to the
            // generic member-name expectation face — D2. Trailing comma
            // optional (the arm-family convention — D7).
            let mut selection: Option<Stx> = None;
            if self.peek() == &Tk::PathSep {
                self.bump(); // ::
                let brace_start = self.expect(Tk::LBrace, "{")?;
                let mut members: Vec<Stx> = Vec::new();
                loop {
                    if matches!(self.peek(), Tk::RBrace | Tk::Eof) {
                        break;
                    }
                    let msp = self.cur_span();
                    match self.bump() {
                        Tk::Ident(m) => members.push(sym_at(self.table, &m, msp)),
                        other => {
                            return Err(ReadError::new(
                                format!("expected a member name, got {:?}", other),
                                msp,
                            ));
                        }
                    }
                    if !self.eat(&Tk::Comma) {
                        // `as` following a member = the member-rename triple
                        // (r134 D2 — the renamed binding replaces the
                        // underlying's flat injection slot, replacement
                        // semantics D3). Span contract: the as marker at its
                        // own token, the renamed identifier at its own (D9).
                        if matches!(self.peek(), Tk::KwAs) {
                            let asp = self.cur_span();
                            self.bump(); // as
                            let rsp = self.cur_span();
                            match self.bump() {
                                Tk::Ident(r) | Tk::Path(r) => {
                                    members.push(sym_at(self.table, "as", asp));
                                    members.push(sym_at(self.table, &r, rsp));
                                }
                                other => {
                                    return Err(ReadError::new(
                                        format!(
                                            "expected a member rename identifier, got {:?}",
                                            other
                                        ),
                                        rsp,
                                    ));
                                }
                            }
                            // After the triple: ',' continues the member
                            // list; anything else breaks to the `}`
                            // expectation (fail-closed — a second `as`
                            // (double rename) or a bare trailing member
                            // surfaces as the expect-RBrace face).
                            if !self.eat(&Tk::Comma) {
                                break;
                            }
                        } else {
                            break;
                        }
                    }
                }
                if members.is_empty() {
                    // `use m::{};` — the EBNF requires at least one use_tree;
                    // the error points at the closing token (the RBrace/Eof
                    // peek position — the macro literal-set family's shape)
                    let esp = self.cur_span();
                    let other = self.peek().clone();
                    return Err(ReadError::new(
                        format!("expected a member name, got {:?}", other),
                        esp,
                    ));
                }
                let brace_end = self.expect(Tk::RBrace, "}")?;
                // Selection-list span = the braces region (D10 — the surface
                // extent anchor, computable on both sides)
                let sel_span = Self::merge_span(brace_start, brace_end);
                selection = Some(list_at(members, sel_span));
            }
            // Alias pair: `as` ident|path — staged before the selection list
            // (the consumer's element order, D9)
            if matches!(self.peek(), Tk::KwAs) {
                let asp = self.cur_span();
                self.bump();
                let alsp = self.cur_span();
                match self.bump() {
                    Tk::Ident(a) | Tk::Path(a) => {
                        elems.push(sym_at(self.table, "as", asp));
                        elems.push(sym_at(self.table, &a, alsp));
                    }
                    other => {
                        return Err(ReadError::new(
                            format!("expected an alias identifier, got {:?}", other),
                            alsp,
                        ));
                    }
                }
            }
            if let Some(sel) = selection {
                elems.push(sel);
            }
            if !self.eat(&Tk::Comma) {
                break;
            }
        }
        let end = self.expect(Tk::Semi, ";")?;
        let span = Self::merge_span(start, end);
        Ok(list_at(
            {
                let mut v = vec![sym_at(self.table, "import", start)];
                v.extend(elems);
                v
            },
            span,
        ))
    }

    /// export declaration: `export x, y;` → `(export x y)` (r109 / 179-a ruling 4
    /// — the module export-surface head; D50 re-export metadata consumption form).
    fn parse_export_decl(&mut self) -> Result<Stx, ReadError> {
        let start = self.expect(Tk::KwExport, "export")?;
        let mut names = Vec::new();
        loop {
            let nsp = self.cur_span();
            match self.bump() {
                Tk::Ident(n) | Tk::Path(n) => names.push((n, nsp)),
                other => {
                    return Err(ReadError::new(
                        format!("expected an export name, got {:?}", other),
                        nsp,
                    ));
                }
            }
            if !self.eat(&Tk::Comma) {
                break;
            }
        }
        let end = self.expect(Tk::Semi, ";")?;
        let span = Self::merge_span(start, end);
        Ok(list_at(
            {
                let mut v = vec![sym_at(self.table, "export", start)];
                for (n, nsp) in names {
                    v.push(sym_at(self.table, &n, nsp));
                }
                v
            },
            span,
        ))
    }

    /// module declaration: `module name { items }` → `(module name items...)`.
    fn parse_module_decl(&mut self) -> Result<Stx, ReadError> {
        let start = self.expect(Tk::KwModule, "module")?;
        let name_span = self.cur_span();
        let name = match self.bump() {
            Tk::Ident(n) => n,
            other => {
                return Err(ReadError::new(
                    format!("expected a module name identifier, got {:?}", other),
                    name_span,
                ));
            }
        };
        self.expect(Tk::LBrace, "{")?;
        // r161 / 231-c (const-declaration-design.md D3): the module name
        // rebinds at item position (removed from the enclosing const set —
        // latest binding wins), and the module body is a scoped const
        // domain — save/clear on entry, restore on exit (a module-local
        // const does not leak to the enclosing item scope). On an Err the
        // whole parse aborts, so the restore is only needed on the Ok path.
        self.const_names.retain(|n| *n != name);
        let saved_consts = std::mem::take(&mut self.const_names);
        let mut items = Vec::new();
        while !matches!(self.peek(), Tk::RBrace | Tk::Eof) {
            items.push(self.parse_item()?);
        }
        self.const_names = saved_consts;
        let end = self.expect(Tk::RBrace, "}")?;
        let span = Self::merge_span(start, end);
        let name_stx = sym_at(self.table, &name, name_span);
        Ok(list_at(
            {
                let mut v = vec![sym_at(self.table, "module", start)];
                v.push(name_stx);
                v.extend(items);
                v
            },
            span,
        ))
    }

    /// fn declaration: `fn name(p: T, ...) -> Eff { body }` → `(define (name p...) body')`
    /// (type/effect signatures parsed then stripped — the core has no
    /// type-consumption face: the type observation layer is Stage 2+).
    fn parse_fn_decl(&mut self) -> Result<Stx, ReadError> {
        let start = self.expect(Tk::KwFn, "fn")?;
        let name_span = self.cur_span();
        let name = match self.bump() {
            Tk::Ident(n) => n,
            other => {
                return Err(ReadError::new(
                    format!("expected a function name identifier, got {:?}", other),
                    name_span,
                ));
            }
        };
        // r161 / 231-c (const-declaration-design.md D3): an item-position
        // fn rebinds the name — the latest binding wins, so the name
        // leaves the const (read-only) set.
        self.const_names.retain(|n| *n != name);
        // Generic parameters (parsed then stripped)
        if self.peek() == &Tk::Lt {
            self.consume_type()?; // consume <...> as a whole (type-syntax
                                  // domain — lenient consumption)
        }
        let params_and_rest = self.parse_typed_params(Tk::LParen, Tk::RParen)?;
        let params = params_and_rest.0;
        let rest_param = params_and_rest.1;
        // Effect signature `-> effect_union` (parsed then stripped)
        if self.peek() == &Tk::Arrow {
            self.bump();
            self.consume_effect_union()?;
        }
        let body = self.parse_block()?;
        let span = Self::merge_span(start, body.span);
        let mut sig = vec![sym_at(self.table, &name, name_span)];
        for (p, psp) in params {
            sig.push(sym_at(self.table, &p, psp));
        }
        // r165 / 236-b (D2-a): the rest marker rides the signature list —
        // `(f a b ... rest)`; the expander's parse_params consumes the
        // marker (236-c).
        if let Some((rname, rsp)) = rest_param {
            sig.push(sym_at(self.table, "...", rsp));
            sig.push(sym_at(self.table, &rname, rsp));
        }
        let sig_list = list_at(sig, name_span);
        Ok(list_at(
            {
                let mut v = vec![sym_at(self.table, "define", start)];
                v.push(sig_list);
                v.push(body);
                v
            },
            span,
        ))
    }

    /// r158 / 228-c: top-level value binding — `let name [: T] = e;` →
    /// `(define name e')` (toplevel-let-design.md D1 — the modern skin of
    /// the S-expr top-level `(define name e)`; the retired `define(name, e);`
    /// call form synthesized the identical core form via the uniform list
    /// structure, so this is a pure skin swap — principle 31: zero desugar,
    /// zero new primitives, expander/compiler/HM/VM untouched). Single
    /// binding only: the comma multi-binding form fails closed (the
    /// block-level let_stmt keeps the multi-binding face — D1
    /// capability-parity ruling). `mut` and type annotations parse then
    /// strip (the fn_decl precedent — the core has no type/mut consumption
    /// face).
    fn parse_toplevel_let(&mut self) -> Result<Stx, ReadError> {
        let start = self.expect(Tk::KwLet, "let")?;
        let _ = self.eat(&Tk::KwMut); // mut modifier parsed then stripped
        let nsp = self.cur_span();
        let name = match self.bump() {
            Tk::Ident(n) => n,
            other => {
                return Err(ReadError::new(
                    format!("expected a binding name, got {:?}", other),
                    nsp,
                ));
            }
        };
        // r161 / 231-c (const-declaration-design.md D3): an item-position
        // let rebinds the name — the latest binding wins, so the name
        // leaves the const (read-only) set.
        self.const_names.retain(|n| *n != name);
        if self.peek() == &Tk::Colon {
            self.bump();
            self.consume_type()?;
        }
        self.expect(Tk::Assign, "=")?;
        let value = self.parse_expr()?;
        if self.peek() == &Tk::Comma {
            return Err(ReadError::new(
                "top-level let takes a single binding (split into separate let statements)"
                    .to_string(),
                self.cur_span(),
            ));
        }
        let end = self.expect(Tk::Semi, ";")?;
        let span = Self::merge_span(start, end);
        Ok(list_at(
            {
                let mut v = vec![sym_at(self.table, "define", start)];
                v.push(sym_at(self.table, &name, nsp));
                v.push(value);
                v
            },
            span,
        ))
    }

    /// r161 / 231-c (const-declaration-design.md D1/D3): top-level const
    /// declaration — `const name [: T] = e;` → `(define name e')` — the
    /// sixteenth skin mapping, the as-if-written toplevel-let twin (the
    /// r158 parse_toplevel_let precedent; principle 31 skin/skeleton
    /// isomorphism — the const-ness is consumed entirely at the Reader
    /// layer: the sequential const-binding set drives the item-position
    /// assign rejection in parse_stmt_into; expander/compiler/HM/VM are
    /// untouched). Top-level and module item positions only (the
    /// parse_item dispatch); the synthesized `define` symbol's span =
    /// the `const` token itself (the r158 synthesized-define precedent).
    fn parse_const_decl(&mut self) -> Result<Stx, ReadError> {
        let start = self.expect(Tk::KwConst, "const")?;
        // `const mut` is semantically contradictory (a read-only binding
        // has no mutable modifier) — a dedicated fail-closed diagnostic,
        // not a silent strip (the honest-error discipline).
        if matches!(self.peek(), Tk::KwMut) {
            let msp = self.cur_span();
            return Err(ReadError::new(
                "const mut is contradictory (a const binding is read-only; drop the mut)"
                    .to_string(),
                msp,
            ));
        }
        let nsp = self.cur_span();
        let name = match self.bump() {
            Tk::Ident(n) => n,
            other => {
                return Err(ReadError::new(
                    format!("expected a binding name, got {:?}", other),
                    nsp,
                ));
            }
        };
        if self.peek() == &Tk::Colon {
            self.bump();
            self.consume_type()?;
        }
        self.expect(Tk::Assign, "=")?;
        let value = self.parse_expr()?;
        if self.peek() == &Tk::Comma {
            return Err(ReadError::new(
                "top-level const takes a single binding (split into separate const statements)"
                    .to_string(),
                self.cur_span(),
            ));
        }
        let end = self.expect(Tk::Semi, ";")?;
        // D3: the sequential const set — this binding is now read-only at
        // the item-position statement face (a later item-position
        // rebinding removes it — latest binding wins).
        if !self.const_names.contains(&name) {
            self.const_names.push(name.clone());
        }
        let span = Self::merge_span(start, end);
        Ok(list_at(
            {
                let mut v = vec![sym_at(self.table, "define", start)];
                v.push(sym_at(self.table, &name, nsp));
                v.push(value);
                v
            },
            span,
        ))
    }

    /// Typed parameter list: `(p: T, ...)` → parameter name list (types stripped).
    /// r165 / 236-b (variadic-rest-design.md D1/D2): the parameter list
    /// outcome — fixed params plus an optional rest parameter (the terminal
    /// `...name: T` form). The rest marker rides the signature list the
    /// callers build (`(f a b ... rest)`): no marker = fixed arity, so the
    /// existing corpus representation is untouched (D2-a backward
    /// compatibility).
    fn parse_typed_params(&mut self, _open: Tk, _close: Tk) -> Result<TypedParams, ReadError> {
        // Empty params `()` (lexical Unit is ambiguous — in parameter position = zero-param list)
        if self.peek() == &Tk::Unit {
            self.bump();
            return Ok((Vec::new(), None));
        }
        self.expect(Tk::LParen, "(")?;
        let mut params = Vec::new();
        let mut rest: Option<(String, Span)> = None;
        loop {
            if matches!(self.peek(), Tk::RParen | Tk::Eof) {
                break;
            }
            if self.eat(&Tk::KwMut) {
                // mut modifier parsed then stripped (mutability = outside the core domain)
            }
            let psp = self.cur_span();
            // r165 / 236-b: the rest parameter arm — the ellipsis lexes as
            // the identifier payload "..." (the r129 ninth skin mapping),
            // so it arrives in name position as Ident("...").
            if matches!(self.peek(), Tk::Ident(s) if s == "...") {
                self.bump();
                if rest.is_some() {
                    return Err(ReadError::new(
                        "only one rest parameter is allowed".to_string(),
                        psp,
                    ));
                }
                let nsp = self.cur_span();
                let pname = match self.bump() {
                    Tk::Ident(n) if n != "..." => n,
                    other => {
                        return Err(ReadError::new(
                            format!(
                                "expected a rest parameter name after `...`, got {:?}",
                                other
                            ),
                            nsp,
                        ));
                    }
                };
                self.expect(Tk::Colon, ":")?;
                self.consume_type()?;
                rest = Some((pname, nsp));
                // The rest parameter terminates the list (D1-b): anything
                // other than the closing paren is a structural violation.
                if !matches!(self.peek(), Tk::RParen | Tk::Eof) {
                    return Err(ReadError::new(
                        "the rest parameter must be the last parameter".to_string(),
                        psp,
                    ));
                }
                break;
            }
            let pname = match self.bump() {
                Tk::Ident(n) => n,
                other => {
                    return Err(ReadError::new(
                        format!("expected a parameter name, got {:?}", other),
                        psp,
                    ));
                }
            };
            self.expect(Tk::Colon, ":")?;
            self.consume_type()?;
            params.push((pname, psp));
            if !self.eat(&Tk::Comma) {
                break;
            }
        }
        self.expect(Tk::RParen, ")")?;
        Ok((params, rest))
    }

    /// Type-syntax consumption (lenient recursive descent — parsed then stripped;
    /// covers primitive/path generics/lifetime variables/Fn function types/
    /// linear/effect/()/Never).
    fn consume_type(&mut self) -> Result<Span, ReadError> {
        // r149 / 219-b2: the type-syntax recursion guard (generic-argument
        // nesting `Vec<Vec<...>>` recurses through consume_type — its own
        // recursion family, guarded alongside the structural families).
        let start = self.cur_span();
        self.depth_enter(start)?;
        let result = self.consume_type_inner();
        self.depth -= 1;
        result
    }

    /// The former consume_type body (renamed — the guard wrapper above
    /// keeps the recursion family's single entry point).
    fn consume_type_inner(&mut self) -> Result<Span, ReadError> {
        let start = self.cur_span();
        // Generic parameter list `<T, ...>` (front form in fn head position;
        // r108 / 178-b fix: the original implementation did `eat(QuoteLifetime)`
        // followed by another `bump` — a double consumption — so the comma of
        // `<'a, T>` was swallowed and `expect(>)` broke on Ident("T");
        // the .krf gt-loop single consumption is isomorphic)
        if self.peek() == &Tk::Lt {
            self.bump();
            loop {
                if matches!(self.peek(), Tk::QuoteLifetime | Tk::Ident(_)) {
                    self.bump();
                }
                if !self.eat(&Tk::Comma) {
                    break;
                }
            }
            self.expect(Tk::Gt, ">")?;
            return Ok(start);
        }
        self.consume_type_atom()?;
        while self.peek() == &Tk::Lt {
            self.bump();
            loop {
                self.consume_type()?;
                if !self.eat(&Tk::Comma) {
                    break;
                }
            }
            self.expect(Tk::Gt, ">")?;
        }
        Ok(start)
    }

    fn consume_type_atom(&mut self) -> Result<(), ReadError> {
        match self.peek().clone() {
            Tk::Ident(_) | Tk::Path(_) => {
                self.bump();
                Ok(())
            }
            Tk::Unit => {
                self.bump();
                Ok(())
            }
            Tk::QuoteLifetime => {
                self.bump();
                Ok(())
            }
            Tk::LParen => {
                // Function type Fn(T, ...) -> Eff / tuple type (leniently
                // consumed up to the matching bracket)
                self.bump();
                let mut depth = 1;
                while depth > 0 && !matches!(self.peek(), Tk::Eof) {
                    match self.bump() {
                        Tk::LParen => depth += 1,
                        Tk::RParen => depth -= 1,
                        _ => {}
                    }
                }
                if self.peek() == &Tk::Arrow {
                    self.bump();
                    self.consume_effect_union()?;
                }
                Ok(())
            }
            _ => Err(ReadError::new(
                format!("expected a type, got {:?}", self.peek()),
                self.cur_span(),
            )),
        }
    }

    /// Effect-container union consumption: `Name(T) | Name | bare-type sugar`.
    fn consume_effect_union(&mut self) -> Result<Span, ReadError> {
        let start = self.cur_span();
        loop {
            match self.peek().clone() {
                Tk::Ident(_) | Tk::Path(_) => {
                    self.bump();
                    if self.peek() == &Tk::LParen {
                        self.bump();
                        loop {
                            if matches!(self.peek(), Tk::RParen | Tk::Eof) {
                                break;
                            }
                            self.consume_type()?;
                            if !self.eat(&Tk::Comma) {
                                break;
                            }
                        }
                        self.expect(Tk::RParen, ")")?;
                    }
                }
                Tk::Unit => {
                    self.bump();
                }
                _ => {
                    return Err(ReadError::new(
                        format!("expected an effect container name, got {:?}", self.peek()),
                        self.cur_span(),
                    ));
                }
            }
            if !self.eat(&Tk::Or) {
                break;
            }
        }
        // Function-typed trailing effect `Fn(...) -> Eff` (function_type
        // production — consumed recursively)
        if self.peek() == &Tk::Arrow {
            self.bump();
            self.consume_effect_union()?;
        }
        Ok(start)
    }

    // ---- Statements and blocks (let scope threading — Rust semantics: let covers the rest) ----

    fn parse_block(&mut self) -> Result<Stx, ReadError> {
        // r149 / 219-b2: the block-family recursion root guard (if-arm /
        // else-if chain / match-arm / handle-arm / nested-block nesting).
        let sp = self.cur_span();
        self.depth_enter(sp)?;
        let result = self.parse_block_inner();
        self.depth -= 1;
        result
    }

    /// r128 / 198-b + r133 / 203-c2: block parsing with the handler-scope
    /// state (nested-resume-design.md D1/D2). The handler arm's block body
    /// admits `resume(expr)` at the block's own top-level statement / tail
    /// positions (→ `(resume k expr)` with the arm's k binder injected) —
    /// the S-expr face's `(do A (resume k v))` sequence form (the
    /// effect_stress corpus translation gap: allocate-before-resume was
    /// inexpressible in the direct `=> resume(v)` position alone). r133:
    /// the scope now threads into NESTED blocks lexically inside a handler
    /// arm body (if-arm / closure-body / nested-handle-arm blocks — D1) —
    /// every block's statement/tail positions consult `handler_k` (the
    /// innermost enclosing arm's binder — D2); plain blocks outside
    /// handler scopes keep the regular parse (resume stays out-of-domain
    /// there — the pre-existing fail-closed path, unchanged — P3 guard).
    fn parse_block_inner(&mut self) -> Result<Stx, ReadError> {
        let start = self.expect(Tk::LBrace, "{")?;
        let mut stmts: Vec<Stx> = Vec::new();
        let mut final_expr: Option<Stx> = None;
        loop {
            match self.peek() {
                Tk::RBrace | Tk::Eof => break,
                Tk::KwLet => {
                    // let statement: threaded with "the rest" after parsing
                    // (deferred — collected first)
                    stmts.push(self.parse_let_stmt()?);
                }
                _ => {
                    // Expression statement / if / perform / handle / tail expression;
                    // r128: in the handler-arm block variant, a resume call form
                    // parses with the arm's k binder (statement or tail position —
                    // terminated by `;` or `}` like any expression statement).
                    // r133: the binder source is the parser's handler-scope state
                    // (D2) — nested blocks inside a handler arm body inherit the
                    // innermost arm's binder; plain blocks see `None`.
                    let is_stmt_start = matches!(
                        self.peek(),
                        Tk::KwIf | Tk::KwPerform | Tk::KwHandle | Tk::KwMatch
                    );
                    let e = match (self.peek(), self.handler_k.clone()) {
                        (Tk::KwResume, Some(rv)) => self.parse_resume_call(&rv)?,
                        _ => self.parse_stmt_or_expr()?,
                    };
                    if self.eat(&Tk::Semi) {
                        stmts.push(e);
                    } else if matches!(self.peek(), Tk::RBrace | Tk::Eof) {
                        final_expr = Some(e);
                        break;
                    } else if is_stmt_start {
                        stmts.push(e);
                    } else {
                        return Err(ReadError::new(
                            "expected; or }(expression statements must end with; end)",
                            self.cur_span(),
                        ));
                    }
                }
            }
        }
        let end = self.expect(Tk::RBrace, "}")?;
        let _span = Self::merge_span(start, end);
        // Threading (single reverse-order algorithm): rest = tail expression or nil;
        // let wraps the rest (Rust semantics: let covers everything after it);
        // non-let statements → (do S rest) — nested do and flat do are
        // desugaring-isomorphic via r45 D42 (Let[do,S,Let[do,...]] parity)
        let mut rest = match final_expr {
            Some(e) => e,
            None => {
                // r110 default-tail nil literalization (180-c defect settlement):
                // an empty-block tail previously produced the nil symbol → an unbound
                // global at runtime (the S-expr-surface nil source text = NilLiteral —
                // two-sided semantic alignment)
                let nsp = end;
                Stx::literal(StxLiteral::Nil, nsp, ScopeSet::new())
            }
        };
        for s in stmts.into_iter().rev() {
            let is_let = s
                .datum
                .as_list()
                .and_then(|l| l.first())
                .and_then(|f| f.datum.as_symbol())
                .map(|sym| self.table.name(sym) == "let")
                .unwrap_or(false);
            if is_let {
                if let Some(fields) = s.datum.as_list() {
                    let mut items: Vec<Stx> = fields.to_vec();
                    items.push(rest);
                    rest = list_at(items, s.span);
                    continue;
                }
            }
            let do_sym = sym_at(self.table, "do", s.span);
            let dspan = Self::merge_span(s.span, rest.span);
            rest = list_at(vec![do_sym, s, rest], dspan);
        }
        Ok(rest)
    }

    /// let statement: `let [mut] x [: T] = e;` → `(let ((x e')) )` (the rest is
    /// filled in by block threading); **multi-binding** (r110 / 180-a ruling 2 — a
    /// production/consumption surface gap in step ③ corpus batch 2):
    /// `let [mut] x [: T] = e, y = e2;` → `(let ((x e') (y e2')) )` — equal to
    /// the S-expr-surface multi-binding let (the D61 staging-chain parity carrier —
    /// sequential lets break bytecode parity). Single-binding behavior/shape/Span
    /// are preserved byte for byte (zero regression on the existing syntax parity gates).
    fn parse_let_stmt(&mut self) -> Result<Stx, ReadError> {
        let start = self.expect(Tk::KwLet, "let")?;
        // Triples of (binder node, name Span, value Span) are collected — the loop
        // runs at least once (a binder-name resolution failure returns the error)
        let mut binders: Vec<(Stx, Span, Span)> = Vec::new();
        loop {
            let _ = self.eat(&Tk::KwMut); // mut modifier parsed then stripped
            let nsp = self.cur_span();
            let name = match self.bump() {
                Tk::Ident(n) => n,
                other => {
                    return Err(ReadError::new(
                        format!("expected a binding name, got {:?}", other),
                        nsp,
                    ));
                }
            };
            if self.peek() == &Tk::Colon {
                self.bump();
                self.consume_type()?;
            }
            self.expect(Tk::Assign, "=")?;
            let value = self.parse_expr()?;
            let vspan = value.span;
            binders.push((
                list_at(
                    vec![sym_at(self.table, &name, nsp), value],
                    Self::merge_span(nsp, vspan),
                ),
                nsp,
                vspan,
            ));
            if !self.eat(&Tk::Comma) {
                break;
            }
        }
        self.expect(Tk::Semi, ";")?;
        let first_nsp = binders[0].1;
        let last_vspan = binders[binders.len() - 1].2;
        let binder_nodes: Vec<Stx> = binders.into_iter().map(|(b, _, _)| b).collect();
        // Single binding: binder-group Span = name Span (existing calibration kept
        // byte for byte); multi-binding: from the first name .. to the last value
        // (same form as the .krf mirror)
        let binders_span = if binder_nodes.len() == 1 {
            first_nsp
        } else {
            Self::merge_span(first_nsp, last_vspan)
        };
        let binders = list_at(binder_nodes, binders_span);
        let span = Self::merge_span(start, last_vspan);
        Ok(list_at(
            vec![sym_at(self.table, "let", start), binders],
            span,
        ))
    }

    /// Statement-or-expression dispatch (including if/perform/handle statement
    /// forms and assign statements).
    fn parse_stmt_or_expr(&mut self) -> Result<Stx, ReadError> {
        // assign statement `x = e;` (statement position — `Ident =` lookahead
        // dispatch; the macro-argument assign bridge reuses the same form)
        if matches!(self.peek(), Tk::Ident(_)) && *self.peek_at(1) == Tk::Assign {
            return self.parse_macro_arg();
        }
        match self.peek().clone() {
            Tk::KwIf => self.parse_if(),
            Tk::KwPerform => self.parse_perform(),
            Tk::KwHandle => self.parse_handle(),
            // r121 / 191-a: the match out-of-domain diagnostic retires — the
            // in-position re-judgment opens the Level 0 parsing domain (the
            // match-design.md v1.0 §2 EBNF; the dual-side mirror syncs in M-4).
            Tk::KwMatch => self.parse_match(),
            Tk::KwMut => {
                Err(self.domain_out("mut binding(mutability semantics kernel out of domain)"))
            }
            // r161 / 231-c: const is an item-position declaration face —
            // inside blocks it fails closed with its dedicated domain-out
            // diagnostic (the mut block-position arm's isomorphic twin).
            Tk::KwConst => Err(self
                .domain_out("const declaration(item position only -- the read-only binding face)")),
            _ => self.parse_expr(),
        }
    }

    /// Top-level/in-block statement entry point (top-level expression item — the core
    /// ModuleItem::Expr face: a kernel superset of the EBNF item domain, the program
    /// entry shape; the value is kept).
    fn parse_stmt_into(&mut self, _ctx: Option<()>, _acc: &mut Vec<Stx>) -> Result<Stx, ReadError> {
        // r161 / 231-c (const-declaration-design.md D3): the item-position
        // assign statement's read-only gate — `name = e;` targeting a name
        // whose latest item-position binding is `const` fails closed here
        // (the sequential const set; span = the name token — the r130
        // import-as diagnostic precedent). Item position only: this entry
        // is reached from parse_item (top-level/module item fallthrough);
        // block-position statements take the parse_stmt_or_expr path
        // directly and stay outside the gate (the D4 honest boundary —
        // scope-aware enforcement is the Stage 2+ type system's domain).
        if matches!(self.peek(), Tk::Ident(_)) && *self.peek_at(1) == Tk::Assign {
            if let Tk::Ident(n) = self.peek().clone() {
                if self.const_names.contains(&n) {
                    let nsp = self.cur_span();
                    return Err(ReadError::new(
                        "cannot assign to a const binding (const bindings are read-only; rebind with let for mutation)"
                            .to_string(),
                        nsp,
                    ));
                }
            }
        }
        let e = self.parse_stmt_or_expr()?;
        self.eat(&Tk::Semi);
        Ok(e)
    }

    /// require declaration: `require io, write;` → `(require io write)`
    /// (r125 / 195-a — the dual-entry CLI window: the target-syntax skin
    /// of the capability-gate declaration, isomorphic to the S-expr
    /// `(require io write)` symbol-for-symbol; the declaration family
    /// shape follows the import precedent — bare names, comma-separated,
    /// mandatory `;`. The sole consumer downstream is the capability gate
    /// (E0006 fail-closed registration — zero new syntax at the core:
    /// the Stx is the same list the S-expr Reader produces, principle 31
    /// skin/skeleton isomorphism; E0018 position discipline keeps guarding
    /// top-level placement at the Stx layer for both skins).
    fn parse_require_decl(&mut self) -> Result<Stx, ReadError> {
        let start = self.expect(Tk::KwRequire, "require")?;
        let mut names = Vec::new();
        loop {
            let nsp = self.cur_span();
            match self.bump() {
                Tk::Ident(n) => names.push((n, nsp)),
                other => {
                    return Err(ReadError::new(
                        format!("expected a capability name, got {:?}", other),
                        nsp,
                    ));
                }
            }
            if !self.eat(&Tk::Comma) {
                break;
            }
        }
        let end = self.expect(Tk::Semi, ";")?;
        let span = Self::merge_span(start, end);
        Ok(list_at(
            {
                let mut v = vec![sym_at(self.table, "require", start)];
                for (n, nsp) in names {
                    v.push(sym_at(self.table, &n, nsp));
                }
                v
            },
            span,
        ))
    }

    /// r137 / 207-c: FFI extern declaration — the thirteenth skin-dictionary
    /// mapping (TD-026 language-surface window, ffi-language-surface-design.md
    /// §2.2).
    ///
    /// `extern NAME "(" [kind {"," kind}] ")" "->" kind ";"`
    ///   → `(extern NAME (kind...) RET)` — symbol-for-symbol isomorphic with
    ///     the S-expr face (the require/import declaration-family precedent:
    ///     bare words, comma-separated, mandatory `;`).
    ///
    /// - kind = `int` | `str` | `ptr` (the ExternKind three-variant language
    ///   face — D1: CInt / CPointer / Opaque; kind words are ordinary
    ///   identifiers on both faces, validated structurally here so the
    ///   Reader fails closed at the earliest point).
    /// - The produced Stx is the same `(extern ...)` list the S-expr Reader
    ///   produces (principle 31 skin/skeleton isomorphism); the sole
    ///   consumer downstream is the driver's face collector (D2 — stripped
    ///   before expansion; the expander never sees it).
    fn parse_extern_decl(&mut self) -> Result<Stx, ReadError> {
        let start = self.expect(Tk::KwExtern, "extern")?;
        let name_span = self.cur_span();
        let name = match self.bump() {
            Tk::Ident(n) => n,
            other => {
                return Err(ReadError::new(
                    format!("expected an external symbol name, got {:?}", other),
                    name_span,
                ));
            }
        };
        // r147 / 217-c (extern-alias-design D1): the optional declaration-
        // site alias arm — `extern NAME as ALIAS (kinds) -> RET;` → the
        // six-element Stx `(extern NAME as ALIAS (kinds) RET)`. `as` =
        // the literal KwAs Token (the import-as arm's r130 precedent);
        // ALIAS = an Ident only (the flat extern space is a bare-name
        // domain — no Path form, unlike the import family whose aliases
        // participate in qualified references). Absent = the historical
        // four-element form, byte-identical (principle 27 additivity).
        let mut alias: Option<(String, Span, Span)> = None;
        if matches!(self.peek(), Tk::KwAs) {
            let asp = self.cur_span();
            self.bump();
            let alsp = self.cur_span();
            match self.bump() {
                Tk::Ident(a) => alias = Some((a, asp, alsp)),
                other => {
                    return Err(ReadError::new(
                        format!("expected an alias identifier after as, got {:?}", other),
                        alsp,
                    ));
                }
            }
        }
        // Kind list: `()` (the lexical Unit's dual meaning — in the
        // kind-list position = the zero-kind list, the parse_typed_params
        // precedent's isomorph: the Unit token IS the whole paren pair) |
        // `( kind {, kind} )`.
        let mut kinds: Vec<(String, Span)> = Vec::new();
        if matches!(self.peek(), Tk::Unit) {
            self.bump();
        } else {
            self.expect(Tk::LParen, "(")?;
            if !matches!(self.peek(), Tk::RParen) {
                loop {
                    let ksp = self.cur_span();
                    match self.bump() {
                        Tk::Ident(k) => kinds.push((k, ksp)),
                        other => {
                            return Err(ReadError::new(
                                format!("expected kind words (int/str/ptr), got {:?}", other),
                                ksp,
                            ));
                        }
                    }
                    if !self.eat(&Tk::Comma) {
                        break;
                    }
                }
            }
            self.expect(Tk::RParen, ")")?;
        }
        self.expect(Tk::Arrow, "->")?;
        let ret_span = self.cur_span();
        let ret = match self.bump() {
            Tk::Ident(k) => k,
            other => {
                return Err(ReadError::new(
                    format!("expected return kind words (int/str/ptr), got {:?}", other),
                    ret_span,
                ));
            }
        };
        let end = self.expect(Tk::Semi, ";")?;
        let span = Self::merge_span(start, end);
        Ok(list_at(
            {
                let mut v = vec![
                    sym_at(self.table, "extern", start),
                    sym_at(self.table, &name, name_span),
                ];
                // r147 / 217-c (D1): the aliased six-element form splices
                // `as ALIAS` between the name and the kind table — the
                // S-expr-face isomorph `(extern NAME as ALIAS (kinds) RET)`
                // (the import-as Stx shape precedent); unaliased = the
                // historical four-element vector, byte-identical.
                if let Some((a, asp, alsp)) = &alias {
                    v.push(sym_at(self.table, "as", *asp));
                    v.push(sym_at(self.table, a, *alsp));
                }
                v.push(list_at(
                    {
                        let elems: Vec<Stx> = kinds
                            .iter()
                            .map(|(k, ksp)| sym_at(self.table, k, *ksp))
                            .collect();
                        elems
                    },
                    match (kinds.first(), kinds.last()) {
                        (Some((_, s0)), Some((_, s1))) => Self::merge_span(*s0, *s1),
                        _ => Span::dummy(),
                    },
                ));
                v.push(sym_at(self.table, &ret, ret_span));
                v
            },
            span,
        ))
    }

    /// r129 / 199-b: macro definition — the ninth skin-dictionary mapping.
    ///
    /// `macro NAME [ "(" [literal {"," literal}] ")" ] "{" { arm } "}"` →
    /// `(define-syntax NAME (syntax-rules (lit...) (pattern template)...))`
    ///
    /// - arm = `pattern "=>" template [","]` (the trailing comma is optional —
    ///   the match-arm precedent); `=>` = the existing Tk::FatArrow.
    /// - pattern = the paren form `( elem {"," elem} )` where an element is an
    ///   identifier / literal / nested paren pattern / `...`; the macro-name
    ///   head element is injected by the Reader (the user never writes it —
    ///   the resume-k injection precedent of r128): the produced Stx list is
    ///   `( NAME elem... )`, the exact S-expr-face pattern isomorphism.
    /// - template = a block `{...}` or an expression, parsed by the ordinary
    ///   target-surface grammar (the call-argument ellipsis absorption in
    ///   parse_postfix is unconditional). Zero desugar, zero new primitives:
    ///   the Stx is the same `(define-syntax ...)` structure the
    ///   S-expr Reader produces, so expand_define_syntax / SyntaxRules::parse
    ///   / register_transformer are all unchanged (principle 31).
    fn parse_macro_decl(&mut self) -> Result<Stx, ReadError> {
        let start = self.expect(Tk::KwMacro, "macro")?;
        let name_span = self.cur_span();
        let name = match self.bump() {
            Tk::Ident(n) => n,
            other => {
                return Err(ReadError::new(
                    format!("expected a macro name identifier, got {:?}", other),
                    name_span,
                ));
            }
        };
        // r161 / 231-c (const-declaration-design.md D3): an item-position
        // macro rebinds the name — the latest binding wins.
        self.const_names.retain(|n| *n != name);
        // Optional literal set: `(` literal {"," literal} `)` — the
        // syntax-rules literal set (identifiers matched by exact symbol).
        // The empty set `()` may be written or omitted; the written empty
        // set lexes as the Unit token (the `()` look-ahead — the
        // call-position zero-arg-list ambiguity family, decided by this
        // syntactic position).
        let mut literals: Vec<(String, Span)> = Vec::new();
        if self.peek() == &Tk::Unit {
            self.bump(); // the written empty literal set `()`
        } else if self.peek() == &Tk::LParen {
            self.bump();
            loop {
                if matches!(self.peek(), Tk::RParen | Tk::Eof) {
                    break;
                }
                let lsp = self.cur_span();
                match self.bump() {
                    Tk::Ident(l) => literals.push((l, lsp)),
                    other => {
                        return Err(ReadError::new(
                            format!("expected a literal-set identifier, got {:?}", other),
                            lsp,
                        ));
                    }
                }
                if !self.eat(&Tk::Comma) {
                    break;
                }
            }
            self.expect(Tk::RParen, ")")?;
        }
        // Body: arms
        self.expect(Tk::LBrace, "{")?;
        let mut clauses: Vec<Stx> = Vec::new();
        loop {
            if matches!(self.peek(), Tk::RBrace | Tk::Eof) {
                break;
            }
            let pattern = self.parse_macro_pattern(Some(&name), name_span)?;
            self.expect(Tk::FatArrow, "=>")?;
            let template = self.parse_macro_template()?;
            let csp = Self::merge_span(pattern.span, template.span);
            clauses.push(list_at(vec![pattern, template], csp));
            if !self.eat(&Tk::Comma) {
                break;
            }
        }
        let end = self.expect(Tk::RBrace, "}")?;
        if clauses.is_empty() {
            return Err(ReadError::new(
                "macro body needs at least one clause (pattern => template)",
                Self::merge_span(start, end),
            ));
        }
        // (syntax-rules (lit...) clause...)
        let mut rules = vec![
            sym_at(self.table, "syntax-rules", start),
            list_at(
                {
                    let mut v = Vec::new();
                    for (l, lsp) in literals {
                        v.push(sym_at(self.table, &l, lsp));
                    }
                    v
                },
                start,
            ),
        ];
        rules.extend(clauses);
        let rules_form = list_at(rules, start);
        // (define-syntax NAME rules)
        let span = Self::merge_span(start, end);
        Ok(list_at(
            vec![
                sym_at(self.table, "define-syntax", start),
                sym_at(self.table, &name, name_span),
                rules_form,
            ],
            span,
        ))
    }

    /// Macro pattern: `( elem {"," elem} )` → `( NAME elem... )` (the macro
    /// name head injected for the top-level pattern — r128 resume-k injection
    /// precedent; a nested sub-pattern passes `None` and stays a plain list).
    /// An element is an identifier / int / float / string / bool / unit literal /
    /// nested paren pattern / the `...` ellipsis identifier. Anything else
    /// (operators, keywords) fails closed with a readable diagnostic.
    fn parse_macro_pattern(
        &mut self,
        macro_name: Option<&str>,
        name_span: Span,
    ) -> Result<Stx, ReadError> {
        // `()` empty pattern: the lexical Unit ambiguity is decided by the
        // syntactic position (the call-position zero-arg-list precedent) —
        // in pattern position it is the empty paren form, not a unit literal
        if self.peek() == &Tk::Unit {
            let sp = self.cur_span();
            self.bump();
            let elems = match macro_name {
                Some(mn) => vec![sym_at(self.table, mn, name_span)],
                None => Vec::new(),
            };
            return Ok(list_at(elems, sp));
        }
        let start = self.expect(Tk::LParen, "(")?;
        let mut elems = Vec::new();
        if let Some(mn) = macro_name {
            elems.push(sym_at(self.table, mn, name_span));
        }
        loop {
            if matches!(self.peek(), Tk::RParen | Tk::Eof) {
                break;
            }
            let esp = self.cur_span();
            match self.bump() {
                Tk::Ident(e) => elems.push(sym_at(self.table, &e, esp)),
                Tk::Int(v) => elems.push(Stx::literal(StxLiteral::Int(v), esp, ScopeSet::new())),
                Tk::Float(v) => {
                    elems.push(Stx::literal(StxLiteral::Float(v), esp, ScopeSet::new()))
                }
                Tk::Str(s) => elems.push(Stx::literal(
                    StxLiteral::Str(s.into()),
                    esp,
                    ScopeSet::new(),
                )),
                Tk::Bool(b) => elems.push(Stx::literal(StxLiteral::Bool(b), esp, ScopeSet::new())),
                Tk::Unit => elems.push(Stx::literal(StxLiteral::Nil, esp, ScopeSet::new())),
                Tk::LParen => {
                    // Nested sub-pattern: recursive paren form (no head
                    // injection — a sub-pattern is a plain list)
                    self.pos -= 1; // unconsume: re-parse the nested form
                    elems.push(self.parse_macro_pattern(None, esp)?);
                }
                other => {
                    return Err(ReadError::new(
                        format!(
                            "expected a pattern element(identifier/literal/nested parentheses/...), got {:?}",
                            other
                        ),
                        esp,
                    ));
                }
            }
            // A trailing ellipsis after an element without a comma (the
            // `(a, rest ...)` shape): absorb it as the next element
            if let Tk::Ident(s) = self.peek() {
                if s == "..." {
                    let elsp = self.cur_span();
                    self.bump();
                    elems.push(sym_at(self.table, "...", elsp));
                }
            }
            if !self.eat(&Tk::Comma) {
                break;
            }
        }
        let end = self.expect(Tk::RParen, ")")?;
        let span = Self::merge_span(start, end);
        Ok(list_at(elems, span))
    }

    /// Macro template: a block `{...}` (parsed by the ordinary block grammar —
    /// a `...` identifier naturally parses as an expression statement) or an
    /// expression (the call-argument ellipsis absorption in parse_postfix is
    /// unconditional — see there for the face-isomorphic error parity).
    fn parse_macro_template(&mut self) -> Result<Stx, ReadError> {
        if self.peek() == &Tk::LBrace {
            self.parse_block()
        } else {
            self.parse_expr()
        }
    }

    /// if statement: `if c { a } [else if c2 { b } | else { d }]` → `(if c' a' b')`
    /// (no else → nil arm — else is optional in the EBNF).
    fn parse_if(&mut self) -> Result<Stx, ReadError> {
        let start = self.expect(Tk::KwIf, "if")?;
        let cond = self.parse_expr()?;
        let then_body = self.parse_block()?;
        let span_hint = Self::merge_span(start, then_body.span);
        let else_body = if self.eat(&Tk::KwElse) {
            if self.peek() == &Tk::KwIf {
                self.parse_if()?
            } else {
                self.parse_block()?
            }
        } else {
            // r110 default-else nil literalization (180-c defect settlement):
            // previously this produced the nil symbol → an unbound-global error when
            // the else arm executed (probe-verified); the S-expr-surface 2-argument if
            // gets Literal(Nil) filled in by the expander — two-sided alignment
            let nsp = span_hint;
            Stx::literal(StxLiteral::Nil, nsp, ScopeSet::new())
        };
        let span = Self::merge_span(span_hint, else_body.span);
        Ok(list_at(
            vec![sym_at(self.table, "if", start), cond, then_body, else_body],
            span,
        ))
    }

    /// perform statement: `perform Op(args);` → `(perform (cons 'Op payload'))`
    /// (payload is a cons chain by arity: 2 arguments = dotted pair /
    /// 1 argument = bare value / 0 arguments = nil — matching the effect_stress
    /// corpus convention).
    fn parse_perform(&mut self) -> Result<Stx, ReadError> {
        let start = self.expect(Tk::KwPerform, "perform")?;
        let esp = self.cur_span();
        let op_name = match self.bump() {
            Tk::Ident(n) => n,
            Tk::Path(p) => p,
            other => {
                return Err(ReadError::new(
                    format!("expected an effect name, got {:?}", other),
                    esp,
                ));
            }
        };
        let mut args = Vec::new();
        if self.peek() == &Tk::LParen {
            self.bump();
            loop {
                if matches!(self.peek(), Tk::RParen | Tk::Eof) {
                    break;
                }
                args.push(self.parse_expr()?);
                if !self.eat(&Tk::Comma) {
                    break;
                }
            }
            self.expect(Tk::RParen, ")")?;
        } else if self.peek() == &Tk::Unit {
            // perform Op() empty argument list (lexical Unit)
            self.bump();
        }
        self.expect(Tk::Semi, ";")?;
        // quote form: 'Op → (quote Op) — the S-expr-surface effect tag is a symbol literal
        let quote_sym = sym_at(self.table, "quote", esp);
        let op_sym = sym_at(self.table, &op_name, esp);
        let quoted = list_at(vec![quote_sym, op_sym.clone()], esp);
        // payload cons chain
        let payload = match args.len() {
            // r110: 0-argument payload nil literalization (same defect family as the
            // default else — the nil of the S-expr-surface `(perform 'Op nil)` = NilLiteral)
            0 => Stx::literal(StxLiteral::Nil, esp, ScopeSet::new()),
            1 => args.into_iter().next().unwrap(),
            _ => {
                // (cons a₁ (cons a₂ ... )) trailing two-element dotted pair
                // (r108 / 178-b fix: mk_cons(second) is front-loaded to form the
                // trailing pair, then a₁…aₙ₋₂ are consed onto it in a loop — the
                // original implementation appended afterwards, scrambling the
                // argument order for 3+ arguments into the
                // [cons a₂ (cons a₁ a₃)] shape; 2 arguments degenerate to a single
                // layer with unchanged behavior; 0/1 arguments unaffected).
                let mut it = args.into_iter().rev();
                let last = it.next().unwrap();
                let second = it.next().unwrap();
                let mut acc = self.mk_cons(second, last);
                for a in it {
                    acc = self.mk_cons(a, acc);
                }
                acc
            }
        };
        let effect_value = self.mk_cons(quoted, payload);
        let span = Self::merge_span(start, effect_value.span);
        Ok(list_at(
            vec![sym_at(self.table, "perform", start), effect_value],
            span,
        ))
    }
    fn mk_cons(&mut self, a: Stx, b: Stx) -> Stx {
        let span = Self::merge_span(a.span, b.span);
        let cons_sym = sym_at(self.table, "cons", a.span);
        list_at(vec![cons_sym, a, b], span)
    }
    /// handle statement (multi-arm — r132 / 202-c, handle-multi-arm-design.md
    /// §2): `handle e { A(p₁,k₁) => b₁, B(p₂,k₂) => b₂ [,...] }` → nested
    /// single-arm handles `(handle A ((p₁k₁) b₁') (handle B ((p₂k₂) b₂') e'))`
    /// — the first-written arm is the outermost (D2/D9); the single-arm form
    /// degenerates byte-equal to the r106 v1 shape (D1). `halt`/`halt(expr)`
    /// → the arm's tail value (nil / expr — D5); `pass` →
    /// `(perform (cons (quote T) p))` (D4 — the arm's effect re-performed
    /// outward; the fired arm's H frame has ext1 cleared, so the frame scan
    /// walks past this handle to the outer handlers).
    fn parse_handle(&mut self) -> Result<Stx, ReadError> {
        let start = self.expect(Tk::KwHandle, "handle")?;
        // r133 / 203-c2 (nested-resume-design.md D2/D3/D5): save the enclosing
        // handler scope and clear it for the protected expression's parse
        // (D5 — resume stays out-of-domain inside a nested handle's protected
        // expression); each arm below installs its own binder (the
        // innermost-arm shadowing mirror of the S-expr lexical scope — D3),
        // and the closing brace restores the saved scope.
        let saved_k = self.handler_k.take();
        let protected = self.parse_expr()?;
        self.expect(Tk::LBrace, "{")?;
        // Arms: one or more, comma-separated, trailing comma tolerated (D8);
        // zero arms fail closed; duplicate tags fail closed (D6 — the
        // duplicate occurrence's own span, checked at the tag position).
        // (tag, tag_span, binder_nodes, handler) in source order.
        let mut arms: Vec<(String, Span, Vec<Stx>, Stx)> = Vec::new();
        let mut seen_tags: Vec<String> = Vec::new();
        loop {
            if self.peek() == &Tk::RBrace {
                break;
            }
            let nsp = self.cur_span();
            let tag = match self.bump() {
                Tk::Ident(n) => n,
                Tk::Path(p) => p,
                other => {
                    return Err(ReadError::new(
                        format!("expected an effect name, got {:?}", other),
                        nsp,
                    ));
                }
            };
            if seen_tags.contains(&tag) {
                return Err(ReadError::new(
                    format!(
                        "handle arm effect name duplicate: `{}`(the same handle at most one arm per effect -- under nested desugaring a later arm silently shadows the earlier one, fail-closed rejected)",
                        tag
                    ),
                    nsp,
                ));
            }
            seen_tags.push(tag.clone());
            let mut arm_vars = Vec::new();
            if self.peek() == &Tk::LParen {
                self.bump();
                loop {
                    if matches!(self.peek(), Tk::RParen | Tk::Eof) {
                        break;
                    }
                    let vsp = self.cur_span();
                    match self.bump() {
                        Tk::Ident(v) => arm_vars.push((v, vsp)),
                        other => {
                            return Err(ReadError::new(
                                format!("expected a bound variable name, got {:?}", other),
                                vsp,
                            ));
                        }
                    }
                    if !self.eat(&Tk::Comma) {
                        break;
                    }
                }
                self.expect(Tk::RParen, ")")?;
            }
            if arm_vars.len() != 2 {
                return Err(ReadError::new(
                    "handle arm binding must be two-element (payload, resume)",
                    nsp,
                ));
            }
            self.expect(Tk::FatArrow, "=>")?;
            // r133: install this arm's binder as the handler scope before the
            // arm body parse (nested-resume-design.md D2).
            self.handler_k = Some(arm_vars[1].clone());
            let handler = self.parse_handler_body(&arm_vars[0], &arm_vars[1], &tag, nsp)?;
            let binder_nodes: Vec<Stx> = arm_vars
                .iter()
                .map(|(v, vsp)| sym_at(self.table, v, *vsp))
                .collect();
            arms.push((tag, nsp, binder_nodes, handler));
            if !self.eat(&Tk::Comma) {
                break;
            }
        }
        if arms.is_empty() {
            return Err(ReadError::new(
                "handle needs at least one arm",
                self.cur_span(),
            ));
        }
        let end = self.expect(Tk::RBrace, "}")?;
        // r133: restore the enclosing handler scope (D3 — the nested handle's
        // own scope ends with its closing brace).
        self.handler_k = saved_k;
        let span = Self::merge_span(start, end);
        // r136 / 206-b (TD-033 — handle-multi-arm-design.md §8 D11/D12):
        // >= 2 arms → the group-install core form `(handle-group arm+ body)`
        // (the Koka-style reading of [HANDLE-INSTALL] — symmetric
        // non-protection between sibling arm bodies); 1 arm → the single-arm
        // degenerate keeps the r106 v1 shape byte-identical (D1
        // zero-regression anchor — the nested fold's 1-arm product).
        if arms.len() == 1 {
            let (tag, nsp, binder_nodes, handler) =
                arms.into_iter().next().expect("non-zero arms checked");
            let tag_sym = sym_at(self.table, &tag, nsp);
            let binder_list = list_at(binder_nodes, nsp);
            let arm = list_at(vec![binder_list, handler], nsp);
            return Ok(list_at(
                vec![sym_at(self.table, "handle", start), tag_sym, arm, protected],
                span,
            ));
        }
        // Group form: `(handle-group (T₁ (p₁ k₁) h₁) … (T_N (p_N k_N) h_N)
        // body)` — arm clause = (tag binder-list handler), source order; the
        // head symbol anchors at the statement's own `handle` keyword (the
        // D10 same-source anchor discipline); clause/binder spans at the
        // tag's own position (the r132 arm-clause span discipline).
        let mut group_items: Vec<Stx> = Vec::with_capacity(arms.len() + 2);
        group_items.push(sym_at(self.table, "handle-group", start));
        for (tag, nsp, binder_nodes, handler) in arms.into_iter() {
            let tag_sym = sym_at(self.table, &tag, nsp);
            let binder_list = list_at(binder_nodes, nsp);
            let arm = list_at(vec![tag_sym, binder_list, handler], nsp);
            group_items.push(arm);
        }
        group_items.push(protected);
        Ok(list_at(group_items, span))
    }

    /// Handler body (r132 / 202-c — four forms, handle-multi-arm-design.md
    /// §2): `resume(expr)` (r128) | `halt` | `halt(expr)` (D5) | `pass`
    /// (D4) | block (r128 + r133 — the block admits resume call forms at
    /// its statement/tail positions, now including nested blocks — the
    /// parser's handler-scope state carries the arm's binder). The
    /// halt/pass domain-out registry retires with this window (the
    /// twelfth skin-mapping family).
    fn parse_handler_body(
        &mut self,
        payload_var: &(String, Span),
        resume_var: &(String, Span),
        tag: &str,
        tag_span: Span,
    ) -> Result<Stx, ReadError> {
        if self.peek() == &Tk::KwResume {
            return self.parse_resume_call(resume_var);
        }
        if self.peek() == &Tk::KwHalt {
            return self.parse_halt_form();
        }
        if self.peek() == &Tk::KwPass {
            return self.parse_pass_form(tag, tag_span, payload_var);
        }
        if self.peek() == &Tk::LBrace {
            // r133: the block variant reads the parser's handler-scope state
            // (installed per arm by parse_handle) — nested blocks inside the
            // arm body inherit it (nested-resume-design.md D1/D2).
            return self.parse_block();
        }
        Err(ReadError::new(
            format!(
                "expected handler body (resume call form / halt form / pass / block), got {:?}",
                self.peek()
            ),
            self.cur_span(),
        ))
    }

    /// halt form (r132 / 202-c — D5): `halt` → the nil literal tail value;
    /// `halt(expr)` → the expr tail value. Pure sugar — not resuming IS the
    /// existing T-NO-RESUME flow termination (the handler body's RET carries
    /// the handle value; the suspended continuation is abandoned — the
    /// resume ∈ {0,1} closure's zero-resume arm).
    fn parse_halt_form(&mut self) -> Result<Stx, ReadError> {
        let hstart = self.expect(Tk::KwHalt, "halt")?;
        if self.peek() == &Tk::LParen {
            self.bump();
            let value = self.parse_expr()?;
            self.expect(Tk::RParen, ")")?;
            return Ok(value);
        }
        // Bare halt: the arm separator or the closing brace must follow
        // (D8); anything else is a dedicated arity diagnostic.
        if !matches!(self.peek(), Tk::Comma | Tk::RBrace) {
            return Err(ReadError::new(
                format!(
                    "halt as a bare form or halt(expr) form, actually followed by {:?}",
                    self.peek()
                ),
                self.cur_span(),
            ));
        }
        Ok(Stx::literal(StxLiteral::Nil, hstart, ScopeSet::new()))
    }

    /// pass form (r132 / 202-c — D4): bare `pass` →
    /// `(perform (cons (quote T) p))` — the arm's effect re-performed with
    /// the payload binder's current value. The fired arm's H frame has
    /// ext1 cleared, so the frame scan walks past this handle to the outer
    /// handlers (T-EFFECT-PROPAGATION); an outer handler's resume continues
    /// from the pass point (standard re-raise semantics — OCaml/Koka alike).
    fn parse_pass_form(
        &mut self,
        tag: &str,
        tag_span: Span,
        payload_var: &(String, Span),
    ) -> Result<Stx, ReadError> {
        let pstart = self.expect(Tk::KwPass, "pass")?;
        if self.peek() == &Tk::LParen {
            return Err(ReadError::new(
                "pass does not accept arguments(bare positional word -- pierce through zero arguments form, re-emitted by Reader injection)",
                pstart,
            ));
        }
        // (perform (cons (quote T) p)) — the same construction shape the
        // perform statement uses for its effect value (r106 quote-form
        // precedent); spans per D10 (quote/T at the tag's own position,
        // p at the binder's declaration position, cons at the quoted range).
        let quote_sym = sym_at(self.table, "quote", tag_span);
        let tag_sym = sym_at(self.table, tag, tag_span);
        let quoted = list_at(vec![quote_sym, tag_sym], tag_span);
        let p_sym = sym_at(self.table, &payload_var.0, payload_var.1);
        let ev = self.mk_cons(quoted, p_sym);
        let span = Self::merge_span(pstart, ev.span);
        Ok(list_at(
            vec![sym_at(self.table, "perform", pstart), ev],
            span,
        ))
    }

    /// resume call form: `resume(expr)` → `(resume k expr)` — the arm's k
    /// binder injected (shared by the direct handler-body position and the
    /// r128 handler-block statement/tail positions; zero new primitives —
    /// the Stx is the same three-element list the S-expr face expands).
    fn parse_resume_call(&mut self, resume_var: &(String, Span)) -> Result<Stx, ReadError> {
        let rstart = self.expect(Tk::KwResume, "resume")?;
        self.expect(Tk::LParen, "(")?;
        let value = self.parse_expr()?;
        self.expect(Tk::RParen, ")")?;
        let span = Self::merge_span(rstart, value.span);
        let k = sym_at(self.table, &resume_var.0, resume_var.1);
        Ok(list_at(
            vec![sym_at(self.table, "resume", rstart), k, value],
            span,
        ))
    }

    // ---- match pattern matching (match implementation batch M-1 — r121 / 191-a;
    // match-design.md v1.0 §2 EBNF authority, 02 §8.13.1a r121 addition) ----
    // Reader-arm only: the surface parses into the intermediate S-expr-surface form
    // `(match scrutinee (pattern [guard] body) ...)` — the arm-structure direct
    // mapping (M-2 = the D2 seventh skin-dictionary entry: the cond/let desugar;
    // M-4 = the reader.krf grammar-batch mirror). Statement position and
    // expression position share one shape (the r106 D2 block-threading ruling,
    // isomorphic to if — parse_stmt_or_expr dispatches first, parse_primary
    // carries the expression position, the r110 expression-position if precedent).

    /// Defensive nesting cap for patterns (match-design.md §1 out-of-domain
    /// declaration: depth > 8 — same anchor family as the parse-list 256 cap,
    /// tightened to the pattern domain).
    const MAX_PATTERN_DEPTH: usize = 8;

    /// match expression: `match scrut { pat [if guard] => expr, ... }` →
    /// `(match scrut' (pat' body') | (pat' guard' body') ...)`.
    ///
    /// Arm shape: 2 elements = `(pattern body)`, 3 elements = `(pattern guard body)`
    /// (length-disjoint, unambiguous for the M-2 desugar consumer). Intermediate
    /// pattern forms: literal → Stx literal (nil = the `()` unit skin);
    /// ident → binding symbol (`_` = the wildcard symbol, in-position re-judgment
    /// deferred to M-2); `(p, q)` → the two-element pair-destructuring list;
    /// `(p)` → grouped identity; `p | q | ...` → `(or p' q' ...)` marker list
    /// (`|` is a reserved operator token — never a binding ident, so the marker
    /// head cannot collide with a pair pattern; pair lists are exactly
    /// 2-element, or-marker lists are >= 3-element — length domains disjoint).
    fn parse_match(&mut self) -> Result<Stx, ReadError> {
        let start = self.expect(Tk::KwMatch, "match")?;
        let scrutinee = self.parse_expr()?;
        self.expect(Tk::LBrace, "{")?;
        let mut arms: Vec<Stx> = Vec::new();
        let mut saw_arm = false;
        loop {
            if matches!(self.peek(), Tk::RBrace | Tk::Eof) {
                break;
            }
            let psp = self.cur_span();
            let pattern = self.parse_pattern_or(0)?;
            if self.peek() == &Tk::Comma {
                return Err(ReadError::new(
                    "or pattern and pair destructuring cannot be mixed (please parenthesize:((p | q), r))",
                    self.cur_span(),
                ));
            }
            let guard = if self.peek() == &Tk::KwIf {
                self.bump();
                Some(self.parse_expr()?)
            } else {
                None
            };
            self.expect(Tk::FatArrow, "=>")?;
            let body = self.parse_expr()?;
            let aspan = Self::merge_span(psp, body.span);
            let mut items = vec![pattern];
            if let Some(g) = guard {
                items.push(g);
            }
            items.push(body);
            arms.push(list_at(items, aspan));
            saw_arm = true;
            if !self.eat(&Tk::Comma) && !matches!(self.peek(), Tk::RBrace | Tk::Eof) {
                return Err(ReadError::new(
                    "expected , or } (match arms must be separated by ,)",
                    self.cur_span(),
                ));
            }
        }
        if !saw_arm {
            return Err(ReadError::new(
                "match expression needs at least one arm",
                self.cur_span(),
            ));
        }
        let end = self.expect(Tk::RBrace, "}")?;
        let span = Self::merge_span(start, end);
        let mut items = vec![sym_at(self.table, "match", start), scrutinee];
        items.extend(arms);
        Ok(list_at(items, span))
    }

    /// pattern_or = pattern_atom { "|" pattern_atom } — the closed-bound or
    /// pattern. A single atom maps identically; two or more alternatives map to
    /// the `(or ...)` marker list.
    fn parse_pattern_or(&mut self, depth: usize) -> Result<Stx, ReadError> {
        // r149 / 219-b2: the macro-pattern-family recursion guard (nested
        // pattern lists recurse through parse_pattern_or — its own
        // recursion family, guarded alongside the structural families; the
        // `depth` parameter is the pattern-or alternation depth, an
        // independent counter).
        let osp = self.cur_span();
        self.depth_enter(osp)?;
        let result = self.parse_pattern_or_inner(depth);
        self.depth -= 1;
        result
    }

    /// The former parse_pattern_or body (renamed — the guard wrapper above
    /// keeps the recursion family's single entry point).
    fn parse_pattern_or_inner(&mut self, depth: usize) -> Result<Stx, ReadError> {
        let osp = self.cur_span();
        let first = self.parse_pattern_atom(depth)?;
        if self.peek() != &Tk::Or {
            return Ok(first);
        }
        let mut items = vec![sym_at(self.table, "or", osp), first];
        while self.eat(&Tk::Or) {
            items.push(self.parse_pattern_atom(depth)?);
        }
        let span = Self::merge_span(osp, items.last().map(|s| s.span).unwrap_or(osp));
        Ok(list_at(items, span))
    }

    /// pattern_atom = literal | ident | "_" | "(" pair/group ")" — with the
    /// EBNF redundancy ruling (r121 / 191-a, registered in match-design.md v1.1):
    /// `(p)` = grouped identity (a full pattern_or inside — may carry `|`);
    /// `(p, q)` = binary pair destructuring, both sides pattern_atom (a bare or
    /// chain in a destructuring slot fails closed with a parenthesization hint);
    /// 3+ comma-separated elements fail closed ("at most binary" — right
    /// non-nesting intent honored by the letter: rest = pattern_atom, the
    /// paren-wrapped nesting stays grammatical, bounded by the depth cap).
    fn parse_pattern_atom(&mut self, depth: usize) -> Result<Stx, ReadError> {
        if depth > Self::MAX_PATTERN_DEPTH {
            return Err(ReadError::new(
                format!(
                    "pattern nesting depth exceeds the limit {}(defensive stack guard --match-design §1 out of domain)",
                    Self::MAX_PATTERN_DEPTH
                ),
                self.cur_span(),
            ));
        }
        let sp = self.cur_span();
        match self.peek().clone() {
            Tk::Int(v) => {
                self.bump();
                Ok(Stx::literal(StxLiteral::Int(v), sp, ScopeSet::new()))
            }
            Tk::Float(v) => {
                self.bump();
                Ok(Stx::literal(StxLiteral::Float(v), sp, ScopeSet::new()))
            }
            Tk::Str(s) => {
                self.bump();
                Ok(Stx::literal(
                    StxLiteral::Str(std::rc::Rc::from(s.as_str())),
                    sp,
                    ScopeSet::new(),
                ))
            }
            Tk::Bool(b) => {
                self.bump();
                Ok(Stx::literal(StxLiteral::Bool(b), sp, ScopeSet::new()))
            }
            Tk::Unit => {
                self.bump();
                Ok(Stx::literal(StxLiteral::Nil, sp, ScopeSet::new()))
            }
            Tk::Ident(name) => {
                self.bump();
                Ok(sym_at(self.table, &name, sp))
            }
            Tk::Path(_) => Err(self.domain_out(
                "qualified-name pattern (22 §27 -- pattern position has no path form)",
            )),
            Tk::LParen => {
                self.bump();
                let inner = depth + 1;
                let first = self.parse_pattern_atom(inner)?;
                if self.peek() == &Tk::Comma {
                    // Binary pair destructuring: both slots pattern_atom.
                    self.bump();
                    let rest = self.parse_pattern_atom(inner)?;
                    if self.peek() == &Tk::Comma {
                        return Err(ReadError::new(
                            "at most two elements inside pattern parentheses ((p, q) -- right not nested prevents infinite types)",
                            self.cur_span(),
                        ));
                    }
                    if self.peek() == &Tk::Or {
                        return Err(ReadError::new(
                            "pair destructuring right element does not support or pattern(please parenthesize: (p, (q | r)))",
                            self.cur_span(),
                        ));
                    }
                    let close = self.expect(Tk::RParen, ")")?;
                    let span = Self::merge_span(sp, close);
                    Ok(list_at(vec![first, rest], span))
                } else if self.peek() == &Tk::Or {
                    // Grouped or-pattern: continue the chain inside the parens.
                    let mut items = vec![sym_at(self.table, "or", sp), first];
                    while self.eat(&Tk::Or) {
                        items.push(self.parse_pattern_atom(inner)?);
                    }
                    if self.peek() == &Tk::Comma {
                        return Err(ReadError::new(
                            "or pattern and pair destructuring cannot be mixed (please parenthesize:((p | q), r))",
                            self.cur_span(),
                        ));
                    }
                    let close = self.expect(Tk::RParen, ")")?;
                    let span = Self::merge_span(sp, close);
                    Ok(list_at(items, span))
                } else {
                    // Grouped single pattern: identity.
                    self.expect(Tk::RParen, ")")?;
                    Ok(first)
                }
            }
            other => Err(ReadError::new(
                format!("expected a pattern, got {:?}", other),
                sp,
            )),
        }
    }

    // ---- Expressions (fourteen-level precedence — EBNF v9 8.13.1 hierarchy grammar
    // machine face) ----
    // v1 core domain: range(13)/pipe(14)/bitwise(6-9)/as(2) = registered out-of-domain diagnostics.

    fn parse_expr(&mut self) -> Result<Stx, ReadError> {
        // r149 / 219-b2: the expression-family recursion root guard (the
        // paren / call-argument / operand nesting cycles all re-enter
        // parse_expr — the depth cap's primary coverage point).
        let sp = self.cur_span();
        self.depth_enter(sp)?;
        let result = self.parse_or();
        self.depth -= 1;
        result
    }

    /// Logical or (level 12): `a || b` → `(or a b)` (derived macro — short-circuit semantics).
    fn parse_or(&mut self) -> Result<Stx, ReadError> {
        let mut lhs = self.parse_and()?;
        while self.peek() == &Tk::OrOr {
            let osp = self.cur_span();
            self.bump();
            let rhs = self.parse_and()?;
            let span = Self::merge_span(lhs.span, rhs.span);
            let or_sym = sym_at(self.table, "or", osp);
            lhs = list_at(vec![or_sym, lhs, rhs], span);
        }
        Ok(lhs)
    }

    /// Logical and (level 11): `a && b` → `(and a b)`.
    fn parse_and(&mut self) -> Result<Stx, ReadError> {
        let mut lhs = self.parse_comparison()?;
        while self.peek() == &Tk::AndAnd {
            let asp = self.cur_span();
            self.bump();
            let rhs = self.parse_comparison()?;
            let span = Self::merge_span(lhs.span, rhs.span);
            let and_sym = sym_at(self.table, "and", asp);
            lhs = list_at(vec![and_sym, lhs, rhs], span);
        }
        Ok(lhs)
    }

    /// Comparison (level 10 — non-chaining: `a == b` → `(eq a b)`; `a != b` → `(not (eq a b))`.
    /// r162 / 233 — TD-037: the equality skin re-points to the cross-domain
    /// structural terminal name `eq` (was `=` — the num/str kernel base,
    /// which stays as the call-form primitive; one face, one name).
    fn parse_comparison(&mut self) -> Result<Stx, ReadError> {
        let lhs = self.parse_additive()?;
        let op = match self.peek() {
            Tk::Eq => "eq",
            Tk::Ne => "!=",
            Tk::Lt => "<",
            Tk::Gt => ">",
            Tk::Le => "<=",
            Tk::Ge => ">=",
            _ => return Ok(lhs),
        };
        let osp = self.cur_span();
        self.bump();
        let rhs = self.parse_additive()?;
        let span = Self::merge_span(lhs.span, rhs.span);
        if op == "!=" {
            let eq_sym = sym_at(self.table, "eq", osp);
            let not_sym = sym_at(self.table, "not", osp);
            let eq = list_at(vec![eq_sym, lhs, rhs], span);
            return Ok(list_at(vec![not_sym, eq], span));
        }
        let op_sym = sym_at(self.table, op, osp);
        Ok(list_at(vec![op_sym, lhs, rhs], span))
    }

    /// Additive (level 5).
    fn parse_additive(&mut self) -> Result<Stx, ReadError> {
        let mut lhs = self.parse_term()?;
        loop {
            let op = match self.peek() {
                Tk::Plus => "+",
                Tk::Minus => "-",
                _ => return Ok(lhs),
            };
            let osp = self.cur_span();
            self.bump();
            let rhs = self.parse_term()?;
            let span = Self::merge_span(lhs.span, rhs.span);
            let op_sym = sym_at(self.table, op, osp);
            lhs = list_at(vec![op_sym, lhs, rhs], span);
        }
    }

    /// Multiplicative (level 4).
    fn parse_term(&mut self) -> Result<Stx, ReadError> {
        let mut lhs = self.parse_unary()?;
        loop {
            let op = match self.peek() {
                Tk::Star => "*",
                Tk::Slash => "/",
                Tk::Percent => "%",
                _ => return Ok(lhs),
            };
            let osp = self.cur_span();
            self.bump();
            let rhs = self.parse_unary()?;
            let span = Self::merge_span(lhs.span, rhs.span);
            let op_sym = sym_at(self.table, op, osp);
            lhs = list_at(vec![op_sym, lhs, rhs], span);
        }
    }

    /// Unary (level 3): `-e` → `(- e)`; `!e` → `(not e)`.
    fn parse_unary(&mut self) -> Result<Stx, ReadError> {
        match self.peek() {
            Tk::Minus => {
                let osp = self.cur_span();
                self.bump();
                let e = self.parse_unary()?;
                let span = Self::merge_span(osp, e.span);
                let op = sym_at(self.table, "-", osp);
                Ok(list_at(vec![op, e], span))
            }
            Tk::MacroBang => {
                // Unary logical not `!e` → `(not e)` (shares the `!` surface word
                // with the macro suffix `name!(...)` — the unary vs suffix position
                // is decided by syntactic structure)
                let osp = self.cur_span();
                self.bump();
                let e = self.parse_unary()?;
                let span = Self::merge_span(osp, e.span);
                let op = sym_at(self.table, "not", osp);
                Ok(list_at(vec![op, e], span))
            }
            Tk::KwMove => {
                // move closure prefix (semantics are Level 2 — parsed then stripped)
                self.bump();
                self.parse_unary()
            }
            _ => self.parse_postfix(),
        }
    }

    /// Postfix (level 1): call `f(args)` / macro invocation `name!(args)`.
    fn parse_postfix(&mut self) -> Result<Stx, ReadError> {
        let mut e = self.parse_primary()?;
        loop {
            match self.peek() {
                Tk::LParen => {
                    let _open = self.cur_span();
                    self.bump();
                    let mut args = Vec::new();
                    loop {
                        if matches!(self.peek(), Tk::RParen | Tk::Eof) {
                            break;
                        }
                        args.push(self.parse_expr()?);
                        // r129 / 199-b: ellipsis element absorption (the ninth
                        // mapping — `my_or(rest ...)` inside a macro template:
                        // the `...` identifier flows in as a list element, the
                        // S-expr-face isomorphism). Unconditional on template
                        // depth: outside templates `f(a ...)` produces the same
                        // Stx `(f a ...)` the S-expr face reads — the unbound-
                        // `...` expansion-time error is then face-isomorphic
                        // (a better parity than a read-error fork).
                        if let Tk::Ident(s) = self.peek() {
                            if s == "..."
                                && matches!(self.peek_at(1), Tk::RParen | Tk::Comma | Tk::Eof)
                            {
                                let elsp = self.cur_span();
                                self.bump();
                                args.push(sym_at(self.table, "...", elsp));
                            }
                        }
                        if !self.eat(&Tk::Comma) {
                            break;
                        }
                    }
                    let close = self.expect(Tk::RParen, ")")?;
                    let span = Self::merge_span(e.span, close);
                    let mut items = vec![e.clone()];
                    items.extend(args);
                    e = list_at(items, span);
                }
                Tk::Unit => {
                    // Empty call `f()`: `()` in call position = zero-argument
                    // argument list (the lexical Unit ambiguity is decided by
                    // syntactic position — primary position = unit literal)
                    let close = self.cur_span();
                    self.bump();
                    let span = Self::merge_span(e.span, close);
                    e = list_at(vec![e.clone()], span);
                }
                Tk::MacroBang => {
                    // name!(...) macro invocation (explicit marker) → `(name args...)`
                    // — an S-expr-surface macro invocation = plain list form
                    self.bump();
                    let _open = self.expect(Tk::LParen, "(")?;
                    let mut args = Vec::new();
                    loop {
                        if matches!(self.peek(), Tk::RParen | Tk::Eof) {
                            break;
                        }
                        args.push(self.parse_macro_arg()?);
                        if !self.eat(&Tk::Comma) {
                            break;
                        }
                    }
                    let close = self.expect(Tk::RParen, ")")?;
                    let span = Self::merge_span(e.span, close);
                    let mut items = vec![e.clone()];
                    items.extend(args);
                    e = list_at(items, span);
                }
                Tk::DotDot => {
                    return Err(self.domain_out(
                        "range operation..(for!/slice domain -- Level 1 macro family)",
                    ))
                }
                Tk::Pipe => return Err(self.domain_out("pipeline |>(Level 1 registration domain)")),
                Tk::Dot => {
                    return Err(self
                        .domain_out("field access/method call (structural typing out of domain)"))
                }
                Tk::LBracket => {
                    // r163 / 234-c — index-access-design.md D1 (the
                    // seventeenth skin mapping): postfix `[idx]` →
                    // as-if-written `(vector-ref coll idx)` — skin swap,
                    // skeleton unchanged (zero desugar pass, zero new
                    // primitives, zero CoreExpr/IR/opcode; expander/
                    // compiler/HM/VM untouched — r160 tuple precedent).
                    // Exactly one index expression (D6: empty `v[]` /
                    // multi-arg `v[1, 2]` are fail-closed E0001 faces).
                    // D7 span contract: the synthetic `vector-ref` head
                    // symbol anchors at the `[` token (r160 D10
                    // synthetic-cons-at-`(` precedent); the whole list
                    // span = merge(coll, `]`) — the postfix merge law.
                    let open = self.cur_span();
                    self.bump();
                    let idx = self.parse_expr()?;
                    let close = self.expect(Tk::RBracket, "]")?;
                    let span = Self::merge_span(e.span, close);
                    let head = sym_at(self.table, "vector-ref", open);
                    e = list_at(vec![head, e.clone(), idx], span);
                }
                Tk::KwAs => {
                    return Err(
                        self.domain_out("as type conversion (type observation layer Stage 2+)")
                    )
                }
                Tk::Amp | Tk::Caret | Tk::Shl | Tk::Shr | Tk::Or => {
                    return Err(self.domain_out(
                        "bitwise family (kernel operator out of domain -- Level 0 lexical domain)",
                    ));
                }
                _ => return Ok(e),
            }
        }
    }

    /// Macro argument: expr | `identifier = expr` (EBNF macro_arg — the
    /// expression-bridging form of the assign statement; the S-expr-surface assign
    /// is itself a core primitive expression).
    fn parse_macro_arg(&mut self) -> Result<Stx, ReadError> {
        if matches!(self.peek(), Tk::Ident(_)) && *self.peek_at(1) == Tk::Assign {
            let nsp = self.cur_span();
            let name = match self.bump() {
                Tk::Ident(n) => n,
                _ => unreachable!(),
            };
            let esp = self.cur_span();
            self.bump(); // =
            let value = self.parse_expr()?;
            let span = Self::merge_span(nsp, value.span);
            let assign_kw = sym_at(self.table, "assign", esp);
            let name_stx = sym_at(self.table, &name, nsp);
            return Ok(list_at(vec![assign_kw, name_stx, value], span));
        }
        self.parse_expr()
    }

    /// Primary expression: literal / path / parenthesis / closure / unit.
    fn parse_primary(&mut self) -> Result<Stx, ReadError> {
        // r110 / 180-a ruling 2b: if value form (if in primary position — the
        // expression-position if gap in step ③ corpus batch 2; statement
        // position is unaffected since parse_stmt_or_expr dispatches first —
        // same positional form as Rust's `let x = if c { a } else { b }`)
        if matches!(self.peek(), Tk::KwIf) {
            return self.parse_if();
        }
        // r121 / 191-a: match value form (match-design.md §2 EBNF comment —
        // statement position and expression position share one shape; the
        // r110 expression-position if precedent, isomorphic dispatch).
        if matches!(self.peek(), Tk::KwMatch) {
            return self.parse_match();
        }
        // r143 / 213-c: handle value form (handle-expr-position-design.md D1
        // — primary position; statement position is unaffected since
        // parse_stmt_or_expr dispatches first; the r110 if / r121 match
        // expression-position precedents, isomorphic dispatch — the third
        // positional-skin family member. Desugars through the same
        // parse_handle: single-arm `(handle tag ((p k) body) protected)` /
        // group `(handle-group ...)` — byte-identical to the statement
        // position's product (D2 zero mechanism change).
        if matches!(self.peek(), Tk::KwHandle) {
            return self.parse_handle();
        }
        let sp = self.cur_span();
        match self.bump() {
            Tk::Int(v) => Ok(Stx::literal(StxLiteral::Int(v), sp, ScopeSet::new())),
            Tk::Float(v) => Ok(Stx::literal(StxLiteral::Float(v), sp, ScopeSet::new())),
            Tk::Str(s) => Ok(Stx::literal(
                StxLiteral::Str(std::rc::Rc::from(s.as_str())),
                sp,
                ScopeSet::new(),
            )),
            Tk::Bool(b) => Ok(Stx::literal(StxLiteral::Bool(b), sp, ScopeSet::new())),
            Tk::Unit => Ok(Stx::literal(StxLiteral::Nil, sp, ScopeSet::new())),
            Tk::Ident(name) => Ok(sym_at(self.table, &name, sp)),
            Tk::Path(p) => Ok(sym_at(self.table, &p, sp)),
            Tk::LParen => {
                let e = self.parse_expr()?;
                // r160 / 230-c — TD-036 (tuple-expression-design.md D1 —
                // the fifteenth skin mapping): tuple expression form —
                // `(a, b)` = the binary pair construction's modern face,
                // the expression-position dual of the match pattern's
                // `(p, q)` pair destructuring (r121). A comma after the
                // first element switches from grouping to the tuple path;
                // as-if-written `cons(a, b)` — the Reader synthesizes the
                // very same Stx list the call form produces (skin swap,
                // skeleton identical — principle 31; zero desugar / zero
                // new primitives / zero CoreExpr-IR-opcode, the r158
                // toplevel-let define-synthesis precedent + the r138
                // vector as-if-written precedent).
                if self.peek() == &Tk::Comma {
                    let comma_sp = self.cur_span();
                    self.bump();
                    // Trailing comma `(a,)` → fail-closed (the r138 vector
                    // literal discipline; the span covers the comma through
                    // the token after it — mirror-aligned).
                    if matches!(self.peek(), Tk::RParen | Tk::Eof) {
                        return Err(ReadError::new(
                            "tuple literal trailing comma illegal((a,) -- expected an expression)",
                            Self::merge_span(comma_sp, self.cur_span()),
                        ));
                    }
                    let rest = self.parse_expr()?;
                    // Arity cap = binary (D2 — the symmetric discipline with
                    // the pattern face's "at most two elements inside
                    // pattern parentheses" ruling; deeper nesting goes via
                    // the explicit `(a, (b, c))` form).
                    if self.peek() == &Tk::Comma {
                        return Err(ReadError::new(
                            "at most two elements in a tuple expression ((a, b) -- right not nested prevents unbounded tuples)",
                            self.cur_span(),
                        ));
                    }
                    let close = self.expect(Tk::RParen, ")")?;
                    let span = Self::merge_span(sp, close);
                    // The synthesized `cons` head carries the `(` token's
                    // span (D10 span contract — mirror-aligned by
                    // construction).
                    Ok(list_at(vec![sym_at(self.table, "cons", sp), e, rest], span))
                } else {
                    self.expect(Tk::RParen, ")")?;
                    Ok(e)
                }
            }
            // r138 / 208-c — TD-002 (vector-value-design.md §2.2 — the
            // fourteenth skin mapping, comma elision): primary-position
            // bracket list `[a, b, c]` → the vector datum `[a b c]`
            // (space-separated S-expr canonical form — the same Stx tree,
            // the same scope treatment; empty `[]` = the empty vector).
            // Postfix `[` (indexing) opened at r163 / 234-c
            // (index-access-design.md D1 — the seventeenth skin mapping,
            // `(vector-ref coll idx)`); the r138 D6 position discipline
            // is superseded — both bracket faces are now in domain.
            Tk::LBracket => {
                let mut items: Vec<Stx> = Vec::new();
                if self.peek() != &Tk::RBracket {
                    loop {
                        // Eof breaks before the element parse (the
                        // call-args discipline: the deferred `]`
                        // expectation renders the eof message —
                        // mirror-aligned: vec-items' eof terminator)
                        if matches!(self.peek(), Tk::RBracket | Tk::Eof) {
                            break;
                        }
                        let e = self.parse_expr()?;
                        items.push(e);
                        // Separator step: a trailing comma before ']' is
                        // rejected fail-closed — the span covers the comma
                        // through the bracket (mirror-aligned: vec-items-tail
                        // renders (p-start toks) .. (p-end after))
                        if self.peek() == &Tk::Comma {
                            let comma_sp = self.cur_span();
                            self.bump();
                            if matches!(self.peek(), Tk::RBracket) {
                                return Err(ReadError::new(
                                    "vector literal trailing comma illegal([a, b,] -- expected an expression)",
                                    Self::merge_span(comma_sp, self.cur_span()),
                                ));
                            }
                        } else {
                            break;
                        }
                    }
                }
                let close_sp = self.expect(Tk::RBracket, "]")?;
                let span = Self::merge_span(sp, close_sp);
                Ok(Stx {
                    datum: StxDatum::Vector(std::rc::Rc::new(items)),
                    span,
                    scopes: ScopeSet::new(),
                    phase: kerf_syntax::Phase::Runtime,
                    uniform_tag: None,
                })
            }
            Tk::OrOr => {
                // Closure `||` prefix (EBNF closure_expr) — the lexer emits ||
                // as OrOr; in primary position = closure start
                self.parse_closure_body(sp)
            }
            other => Err(ReadError::new(
                format!("expected an expression, got {:?}", other),
                sp,
            )),
        }
    }

    /// Closure body: `|| [ (p: T, ...) ] [-> Eff] { body }` → `(fn (p...) body')`
    /// (the lambda→closure direction of the D2 six mappings).
    fn parse_closure_body(&mut self, start: Span) -> Result<Stx, ReadError> {
        let mut params: Vec<Stx> = Vec::new();
        let mut rest_param: Option<(String, Span)> = None;
        if self.peek() == &Tk::LParen {
            let plist_and_rest = self.parse_typed_params(Tk::LParen, Tk::RParen)?;
            for (p, psp) in plist_and_rest.0 {
                params.push(sym_at(self.table, &p, psp));
            }
            rest_param = plist_and_rest.1;
        }
        if self.peek() == &Tk::Arrow {
            self.bump();
            self.consume_effect_union()?;
        }
        let body = self.parse_block()?;
        let span = Self::merge_span(start, body.span);
        // r165 / 236-b (D1-d): the closure parameter face shares the rest
        // form with fn declarations — the marker rides the param list.
        if let Some((rname, rsp)) = rest_param {
            params.push(sym_at(self.table, "...", rsp));
            params.push(sym_at(self.table, &rname, rsp));
        }
        let param_list = list_at(params, start);
        Ok(list_at(
            vec![sym_at(self.table, "fn", start), param_list, body],
            span,
        ))
    }
}

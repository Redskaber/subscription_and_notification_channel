//! The compiler's **emission-domain** implementation (the landing of the
//! stage0.md §19.3 code-generation skeleton).
//!
//! `IrExpr` (IndexIR — [crate::ir], r48 / E5 S3 structural-arm continuation
//! M-I indexing) → `BcProgram`: **emission does zero resolution** (name
//! resolution is already fixed in IndexIR — the resolution domain / emission
//! domain are separate, D56). Two-stage pipeline: `lower_module` (the single
//! resolution-closure pass) → `emit_module` (this file: prototype allocation
//! / constant pool / jump backpatching / bytecode emission).
//!
//! - The top-level form sequence is emitted into the main prototype
//!   (entry = 0);
//! - Fn is emitted as an independent prototype + closure capture conversion
//!   (capture sources are already fixed in IrProto);
//! - If goes through jump backpatching (emit_jump / patch_jump);
//! - Evaluation order contract (§19.5 invariant 3): Apply's arguments from
//!   left to right, the callee pushed last.
//!
//! **Emission order = resolution order** (the lowering tree order matches
//! the emission tree order — constant-pool intern order / prototype order /
//! global first-occurrence order are preserved bit for bit; the structural
//! basis of bytecode-equality parity, the strictest wording of the e5-plan
//! §3.2 S3 row).
//!
//! **Global symbol resolution** (Stage 0 name-based resolution, the
//! established approximation of TD-004): when LOAD_GLOBAL misses, fall back
//! by stripping the `$hyg$N` suffix — so references introduced by hygienic
//! renaming still resolve to the same-named global (capture protection and
//! global reachability hold at the same time).

use std::collections::HashMap;
use std::rc::Rc;

use kerf_core::{LiteralValue, ModuleItem};
use kerf_span::Span;
use kerf_syntax::Symbol;

use crate::bytecode::{BcConst, BcProgram, BcProto, ConstPool};
use crate::ir::{IrExpr, IrHandleArm, IrProto, IrVar};
use crate::opcode::Op;

/// Compile error (the minimal `{ message, span }` shape).
#[derive(Debug, Clone, PartialEq)]
pub struct CompileError {
    pub message: String,
    pub span: Span,
}

impl CompileError {
    pub(crate) fn new(message: impl Into<String>, span: Span) -> Self {
        CompileError {
            message: message.into(),
            span,
        }
    }
}

/// Emission context (§10.1 rule 2: the `Ctxt` suffix).
///
/// r48/M-I (D56): the scope stack (resolution domain) has moved out to
/// `ir::LowerCtxt` — this context carries only emission-domain state
/// (prototypes / constant pool / backpatching / trampoline).
pub struct CompileCtxt {
    /// All prototypes.
    protos: Vec<BcProto>,
    /// Index of the prototype currently being emitted (the switch point for
    /// nested Fn).
    current: usize,
    /// The constant pool.
    pool: ConstPool,
    /// Global reference registry (deduplicated).
    global_refs: Vec<Symbol>,
    /// Global name → constant-pool index (fast lookup).
    global_index: HashMap<Symbol, u32>,
    /// Jump-backpatch placeholder queue (§19.3 invariant 2: must be empty
    /// when finished).
    pending_patches: Vec<(usize, usize)>, // (proto_idx, pc)
    /// Trampoline sentinel prototype index (r25/42-f — a program-level lazy
    /// singleton; None = not yet generated. Created at the first Handle:
    /// code=[Ret], positionally mirrored with the krf-side CC-TRAMPOLINE —
    /// parity determinism).
    trampoline: Option<u32>,
}

impl CompileCtxt {
    fn new() -> Self {
        CompileCtxt {
            protos: Vec::new(),
            current: 0,
            pool: ConstPool::new(),
            global_refs: Vec::new(),
            global_index: HashMap::new(),
            pending_patches: Vec::new(),
            trampoline: None,
        }
    }

    /// Current-frame reference count (prototype index).
    fn current_proto_mut(&mut self) -> &mut BcProto {
        let idx = self.current;
        &mut self.protos[idx]
    }

    fn emit(&mut self, op: Op, span: Span) {
        self.current_proto_mut().code.push(op);
        self.current_proto_mut().debug_spans.push(span);
    }

    fn here(&self) -> u32 {
        let idx = self.current;
        self.protos[idx].code.len() as u32
    }

    /// Emit a placeholder jump (backpatch completeness: the placeholder is
    /// registered, §19.3 invariant 2).
    fn emit_jump(&mut self, op_factory: fn(u32) -> Op, span: Span) -> u32 {
        let pc = self.here();
        self.emit(op_factory(u32::MAX), span);
        let proto_idx = self.current;
        self.pending_patches.push((proto_idx, pc as usize));
        pc
    }

    /// Backpatch a jump target.
    fn patch_jump(&mut self, pc: u32) {
        let proto_idx = self.current;
        let target = self.here();
        let proto = &mut self.protos[proto_idx];
        match &mut proto.code[pc as usize] {
            Op::Jump(t) => *t = target,
            Op::JumpIfFalse(t) => *t = target,
            other => {
                let msg = format!("backfill target is not a jump instruction: {:?}", other);
                panic!("compiler internal invariant broken: {}", msg);
            }
        }
        // Remove from the placeholder queue (matched by pc)
        self.pending_patches
            .retain(|(p, c)| !(*p == proto_idx && *c == pc as usize));
    }

    fn intern_const(&mut self, c: BcConst) -> u32 {
        self.pool.intern(c)
    }

    fn intern_global(&mut self, name: Symbol) -> u32 {
        if let Some(&i) = self.global_index.get(&name) {
            return i;
        }
        let i = self.intern_const(BcConst::Symbol(name));
        self.global_refs.push(name);
        self.global_index.insert(name, i);
        i
    }
}

/// Module compilation entry (§10.1 rule 1: `<verb>_<noun>` free function).
///
/// Input: the program's `ModuleItem` sequence (r49 D59 — the expander's
/// item-position classification output). Output: a `BcProgram`
/// (entry = 0 = the main prototype).
///
/// r48/M-I (D56) two stages: `lower_module` (resolution closure — the
/// single name-resolution pass) → `emit_module` (emission — zero
/// resolution). Zero change in the emission domain (IrExpr keeps the
/// Define/Module/Require emission nodes — the item-level lowering output;
/// emission order = resolution order → the structural guarantee of
/// bytecode equality).
pub fn compile_module(items: &[ModuleItem]) -> Result<BcProgram, CompileError> {
    compile_module_with_externs(items, &[])
}

/// r137 / 207-c (TD-026 language-surface window, ffi-language-surface-design
/// §4/D5): the extern-face-carrying compile entry — `externs` is the flat
/// extern symbol space (declared names only; the five-fold declaration
/// validation already happened at the driver face [D3]). Empty face =
/// `compile_module` identical bit for bit (principle 27 additivity — the
/// existing test callers all ride the empty-face delegate).
pub fn compile_module_with_externs(
    items: &[ModuleItem],
    externs: &[(Symbol, std::rc::Rc<str>)],
) -> Result<BcProgram, CompileError> {
    let irs = crate::ir::lower_module_with_externs(items, externs)?;
    emit_module(&irs)
}

/// Emit a module (resolution-closure IR → bytecode).
fn emit_module(irs: &[Rc<IrExpr>]) -> Result<BcProgram, CompileError> {
    let mut ctx = CompileCtxt::new();
    let main_span = irs.first().map(|e| e.span()).unwrap_or_default();

    // The main prototype (a placeholder — filled in during emission;
    // current = 0)
    ctx.protos.push(BcProto {
        name: Symbol(u32::MAX - 1), // the main name (rendering replaces it at the call site)
        params: vec![],
        rest_slot: None,
        n_locals: 0,
        capture_names: vec![],
        capture_sources: vec![],
        code: vec![],
        debug_spans: vec![],
        free_vars: vec![],
    });
    ctx.current = 0;

    if irs.is_empty() {
        ctx.emit(Op::PushNil, main_span);
    }
    for (i, e) in irs.iter().enumerate() {
        // Top-level forms are not in tail position (the main prototype ends
        // with Halt — TCO does not participate at top level)
        emit_ir(&mut ctx, e, false)?;
        if i + 1 < irs.len() {
            ctx.emit(Op::Pop, e.span()); // stack balance: intermediate values popped
        }
    }
    ctx.emit(Op::Halt, main_span);

    // Backpatch-completeness assertion (§19.3 invariant 2)
    if !ctx.pending_patches.is_empty() {
        let (p, c) = ctx.pending_patches[0];
        return Err(CompileError::new(
            format!(
                "jump backfill incomplete: proto {} pc {} not backfilled",
                p, c
            ),
            ctx.protos[p].debug_spans[c],
        ));
    }

    let consts = ctx.pool.finish();
    let global_refs = std::mem::take(&mut ctx.global_refs);
    Ok(BcProgram {
        protos: ctx.protos,
        consts,
        entry: 0,
        global_refs,
        module_name: None,
    })
}

/// Emit a single expression (stack balance: after the output executes, the
/// stack is net +1, §19.3 invariant 1).
///
/// **Tail-position threading (TD-022/H2 — VM TCO)**: `tail = true` means
/// this expression sits in function-body tail position (the transitive
/// closure of Fn bodies / both If arms / the innermost body of a Let chain)
/// — an `Apply` inside it compiles to `Op::TailCall` (frame reuse: the
/// callee's return goes straight to the current caller, skipping the
/// current frame). Top-level forms are always `tail = false` (the main
/// prototype ends with Halt — not a participant).
fn emit_ir(ctx: &mut CompileCtxt, e: &IrExpr, tail: bool) -> Result<(), CompileError> {
    match e {
        IrExpr::Literal { value, span } => {
            let idx = match value {
                LiteralValue::Int(v) => ctx.intern_const(BcConst::Int(*v)),
                LiteralValue::Float(v) => ctx.intern_const(BcConst::Float(*v)),
                LiteralValue::Str(s) => ctx.intern_const(BcConst::Str(s.clone())),
                LiteralValue::Symbol(s) => ctx.intern_const(BcConst::SymLit(s.clone())),
                LiteralValue::Bool(b) => {
                    ctx.emit(if *b { Op::PushTrue } else { Op::PushFalse }, *span);
                    return Ok(());
                }
                LiteralValue::Nil => {
                    ctx.emit(Op::PushNil, *span);
                    return Ok(());
                }
                // Quoted pair structure: built recursively (aligned with
                // MAKE_PAIR — car pushed before cdr)
                LiteralValue::Pair(car, cdr) => {
                    emit_literal_pair(ctx, car, cdr, *span)?;
                    return Ok(());
                }
            };
            ctx.emit(Op::PushConst(idx), *span);
            Ok(())
        }
        IrExpr::Var { res, span } => {
            // Resolution result direct translation (M-I: name resolution
            // fixed at compile time — emission does zero name lookup)
            match res {
                IrVar::Local(i) => ctx.emit(Op::LoadLocal(*i), *span),
                IrVar::Captured(i) => ctx.emit(Op::LoadCaptured(*i), *span),
                IrVar::Global(name) => {
                    let gi = ctx.intern_global(*name);
                    ctx.emit(Op::LoadGlobal(gi), *span);
                }
                // r137 / 207-c (D5 — ffi-language-surface-design §3): a
                // standalone value-position extern reference is rejected —
                // the flat FFI symbol space has no value form (there is no
                // "extern function value"; ffi-ownership-model §4). Legal
                // in exactly one position: the Apply head (the arm below).
                IrVar::Extern(name) => {
                    return Err(CompileError::new(
                        format!(
                            "extern symbol `{}` is call-position only (flat symbol space has no value-position form -- ffi-ownership-model §4; call it directly to obtain its return value)",
                            name
                        ),
                        *span,
                    ));
                }
            }
            Ok(())
        }
        IrExpr::Fn { proto, span } => emit_fn(ctx, proto, *span),
        IrExpr::Apply {
            fn_expr,
            args,
            span,
        } => {
            // r137 / 207-c (D5 — ffi-language-surface-design §4): an
            // extern-resolved Apply head → the frozen FFI call emission.
            // The callee is NOT compiled as a value (there is no extern
            // function value) — the symbol rides the constant pool as a
            // `BcConst::SymLit` referenced by the instruction operand;
            // the args compile left-to-right per the evaluation-order
            // contract (06 §1.3/§2 A1 — the inductive basis of T1), each
            // pushing its value; then `Op::CallExternal{symbol, n_args}`
            // slices the args off the stack in push order and invokes the
            // window protocol (pin → host call → LIFO unpin → return
            // wrap — ffi-ownership-model §3). The tail flag does not
            // participate (CallExternal creates no frame — the return
            // value lands on the stack and the enclosing epilogue carries
            // it; the same shape `compile_ffi_call_program` emits).
            if let IrExpr::Var {
                res: IrVar::Extern(name),
                span: _,
            } = &**fn_expr
            {
                let sym_idx = ctx.intern_const(BcConst::SymLit(name.clone()));
                for a in args {
                    emit_ir(ctx, a, false)?;
                }
                ctx.emit(
                    Op::CallExternal {
                        symbol: sym_idx,
                        n_args: args.len() as u32,
                    },
                    *span,
                );
                return Ok(());
            }
            // Evaluation order contract (06 §1.3/§2 A1, consistent with the
            // expansion order — the inductive basis of the T1 theorem): the
            // callee is evaluated first, then arguments left to right
            emit_ir(ctx, fn_expr, false)?;
            for a in args {
                emit_ir(ctx, a, false)?;
            }
            // Apply in tail position → TailCall (frame reuse); otherwise →
            // Call (frame growth + the MAX_FRAMES guard)
            let op = if tail {
                Op::TailCall(args.len() as u32)
            } else {
                Op::Call(args.len() as u32)
            };
            ctx.emit(op, *span);
            Ok(())
        }
        IrExpr::If {
            cond,
            then_branch,
            else_branch,
            span,
        } => {
            emit_ir(ctx, cond, false)?;
            let j_false = ctx.emit_jump(Op::JumpIfFalse, *span);
            emit_ir(ctx, then_branch, tail)?;
            let j_end = ctx.emit_jump(Op::Jump, *span);
            ctx.patch_jump(j_false);
            emit_ir(ctx, else_branch, tail)?;
            ctx.patch_jump(j_end);
            Ok(())
        }
        IrExpr::Assign { res, value, span } => {
            // Stack balance (§19.3 invariant 1): the value of a set!
            // expression is the assigned value — after the value is pushed,
            // DUP then store leaves the stack net +1 (the target resolution
            // result uses the same wording as Var — already fixed at
            // lowering time, TD-004)
            emit_ir(ctx, value, false)?;
            ctx.emit(Op::Dup, *span);
            match res {
                IrVar::Local(i) => ctx.emit(Op::StoreLocal(*i), *span),
                IrVar::Captured(i) => ctx.emit(Op::StoreCaptured(*i), *span),
                IrVar::Global(name) => {
                    let gi = ctx.intern_global(*name);
                    ctx.emit(Op::StoreGlobal(gi), *span);
                }
                // r137 / 207-c (D5): set! on an extern name — the flat FFI
                // symbol space is assignment-free (same fail-closed family
                // as the value-position rejection).
                IrVar::Extern(name) => {
                    return Err(CompileError::new(
                        format!(
                            "extern symbol `{}` is not assignable (flat symbol space has no storage position -- ffi-ownership-model §4)",
                            name
                        ),
                        *span,
                    ));
                }
            }
            Ok(())
        }
        IrExpr::Define { name, value, span } => {
            // Top-level define: evaluate → DUP → define global (Define
            // returns v — R6/D1). DUP keeps the return value, DefineGlobal
            // pops the other copy and writes the global (stack net +1).
            //
            // D1 fix (global-leak protection) — the position discipline
            // (legal only in the entry prototype) has moved forward into
            // lowering (the ir.rs `lower_expr` prototype-depth check — the
            // D56 single resolution pass; message and span preserved
            // verbatim).
            emit_ir(ctx, value, false)?;
            ctx.emit(Op::Dup, *span);
            let gi = ctx.intern_global(*name);
            ctx.emit(Op::DefineGlobal(gi), *span);
            Ok(())
        }
        IrExpr::Let {
            slot,
            bind,
            value,
            body,
            span,
        } => {
            // r45/E5 S3 structural arm (22 §14 D41/D42): Let dual-mode
            // emission (the mode decision happens in lowering — a D56
            // resolution-domain decision).
            //
            // **discard mode** (bind=false — chains whose fixed name "do"
            // comes from do desugaring always land here): `[value; Pop;
            // body]` — **instruction-identical** to the original Do's
            // per-item emission sequence (the machine-verification anchor
            // of the strictest e5-plan §3.2 S3 bytecode-parity wording:
            // the const_pool_dedup assertion).
            //
            // **bind mode** (bind=true — the body references the bound
            // name): `[value; StoreLocal(slot); body]` — slot = the
            // frame's locals append position (fixed at lowering); the
            // prototype's n_locals is backpatched at emission time (VM
            // frame creation allocates by n_locals: parameters fill the
            // first k slots, the rest are initialized to nil).
            //
            // Tail-position semantics: the body inherits tail (= the
            // equivalent form of the last Do item inheriting tail position
            // — the innermost body of a Let chain is the original Do's
            // last item).
            emit_ir(ctx, value, false)?;
            if *bind {
                // n_locals backpatching (monotonic growth — nested Let
                // slot numbers increase; frame creation allocates once by
                // the final value)
                let cur = ctx.current;
                ctx.protos[cur].n_locals = ctx.protos[cur].n_locals.max(*slot + 1);
                ctx.emit(Op::StoreLocal(*slot), *span);
                emit_ir(ctx, body, tail)?;
            } else {
                ctx.emit(Op::Pop, value.span());
                emit_ir(ctx, body, tail)?;
            }
            Ok(())
        }
        IrExpr::Module { body, span } => {
            // Stage 0 single module: the body emits inline; the module name
            // goes into meta info (name/imports/exports are
            // namespace-domain payload — the driver consumes them on the
            // CoreExpr surface first, they never enter the compilation IR)
            if body.is_empty() {
                ctx.emit(Op::PushNil, *span);
            }
            for (i, item) in body.iter().enumerate() {
                emit_ir(ctx, item, false)?;
                if i + 1 < body.len() {
                    ctx.emit(Op::Pop, item.span());
                }
            }
            if let Some(pm) = ctx.protos.first_mut() {
                pm.name = Symbol(u32::MAX - 1);
            }
            Ok(())
        }
        IrExpr::Require { span } => {
            // r8 capability declaration: evaluation is always nil (zero
            // side effects) — emitting PushNil keeps the top-level
            // "one value per form" stack invariant (consistent with
            // runtime, the T1 dual-path wording; capability verification
            // already happened in the driver front-end pipeline R9/E0006)
            ctx.emit(Op::PushNil, *span);
            Ok(())
        }
        IrExpr::Perform { effect, span } => {
            // r25/42-f (R10-perform): the effect value is evaluated first
            // (the evaluation order contract keeps the Apply order — the
            // effect-value expression is evaluated then pushed) → PERFORM
            // (destructures (tag . payload) + scan-dispatch + continuation
            // snapshot + stack truncation back to the watermark). Never in
            // tail position: if control transfers and is not resumed, this
            // expression never completes (the rest of the body is discarded
            // by dispatch — after resume, the value is injected at the
            // resumption point)
            emit_ir(ctx, effect, false)?;
            ctx.emit(Op::Perform, *span);
            Ok(())
        }
        IrExpr::Handle {
            tag,
            handler,
            thunk,
            span,
        } => emit_handle(ctx, tag, handler, thunk, *span),
        // r136 / 206-b (TD-033 — D15): group install emission (T →
        // H₁..H_N → B → tk₁..tk_N → the atomic INSTALL_HANDLER_GROUP —
        // deterministic order, byte-parity with compiler.ktf)
        IrExpr::HandleGroup { arms, thunk, span } => emit_handle_group(ctx, arms, thunk, *span),
    }
}

/// Recursive quoted-pair emission: build the pair first (car build →
/// cdr build → MAKE_PAIR).
fn emit_literal_pair(
    ctx: &mut CompileCtxt,
    car: &Rc<LiteralValue>,
    cdr: &Rc<LiteralValue>,
    span: Span,
) -> Result<(), CompileError> {
    emit_literal_value(ctx, car, span)?;
    emit_literal_value(ctx, cdr, span)?;
    ctx.emit(Op::MakePair, span);
    Ok(())
}

fn emit_literal_value(
    ctx: &mut CompileCtxt,
    v: &LiteralValue,
    span: Span,
) -> Result<(), CompileError> {
    match v {
        LiteralValue::Pair(a, b) => emit_literal_pair(ctx, a, b, span),
        LiteralValue::Symbol(s) => {
            let idx = ctx.intern_const(BcConst::SymLit(s.clone()));
            ctx.emit(Op::PushConst(idx), span);
            Ok(())
        }
        other => emit_ir(
            ctx,
            &IrExpr::Literal {
                value: other.clone(),
                span,
            },
            false,
        )
        .map(|_| ()),
    }
}

/// Fn emission: closure capture conversion (§8.5 basic closures + the
/// §19.3 CLOSURE instruction).
///
/// Capture sources / free names / formal parameters are already fixed in
/// `IrProto` (at lowering time — the explicit environment); the emission
/// segment only does: prototype allocation (order = emission order) → body
/// emission (trailing RET) → switch back to the enclosing prototype and
/// emit CLOSURE (the capture-source descriptors are frozen with the
/// prototype — the VM uses them to share the enclosing cells, with no
/// pre-pushing on the stack).
fn emit_fn(ctx: &mut CompileCtxt, proto: &IrProto, span: Span) -> Result<(), CompileError> {
    let proto_idx = ctx.protos.len() as u32;
    let proto_name = proto
        .params
        .first()
        .copied()
        .unwrap_or(Symbol(u32::MAX - 2));
    // r165 / 236-c: the rest prototype's local layout — the rest slot rides
    // at `params.len()` (the lowering-side append position; the invariant
    // is structural, asserted here for the emission face).
    let rest_slot = proto.rest.map(|_| proto.params.len() as u32);
    let param_slots = proto.params.len() as u32 + u32::from(proto.rest.is_some());
    ctx.protos.push(BcProto {
        name: proto_name,
        params: proto.params.clone(),
        rest_slot,
        n_locals: param_slots,
        capture_names: proto.captures.iter().map(|c| c.name).collect(),
        capture_sources: proto.captures.iter().map(|c| c.source).collect(),
        code: vec![],
        debug_spans: vec![],
        free_vars: proto.free_vars.clone(),
    });

    // Body emission (the trailing RET guarantees return semantics) —
    // switch into the new prototype.
    // The function body = tail position (TCO): an Apply at the body tail →
    // TailCall (frame reuse, straight to the caller)
    let enclosing = ctx.current;
    ctx.current = proto_idx as usize;
    emit_ir(ctx, &proto.body, true)?;
    ctx.emit(Op::Ret, proto.body.span());

    // Switch back to the enclosing prototype and emit CLOSURE
    ctx.current = enclosing;
    ctx.emit(
        Op::Closure {
            proto: proto_idx,
            n_captures: proto.captures.len() as u32,
        },
        span,
    );
    Ok(())
}

/// Handle expression emission (r25/42-f — effect-language-design D6 frame
/// orchestration, the three-prototype scheme).
///
/// Prototypes (deterministic order: lazy T → H → B):
/// - **T** (trampoline, a program-level lazy singleton): the `code = [Ret]`
///   sentinel prototype — the execution prototype of the handler frame; the
///   body's RET pops the handler frame through it, returning to the point
///   after the handle (R11-return);
/// - **H** (handler prototype): params = [payload_var, resume_var], body =
///   handler_body (trailing Ret) — hung into the H execution frame when
///   dispatch reshapes;
/// - **B** (body thunk prototype): params = [], body = the handle body
///   (trailing Ret; body tail-position threading = lambda-body semantics —
///   a tail call inside the body pops the thunk frame and goes through the
///   handler frame, D8).
///
/// Emission: `InstallHandler { handler: H, body: B, tag: k, trampoline: T }`
/// (the VM takes both prototypes' captures from the current frame → pushes
/// the handler frame + thunk frame → transfers execution to the body — the
/// compiler emits no Closure/Call: frame orchestration is done atomically
/// by the instruction). The capture-source descriptors are frozen with the
/// prototypes (same mechanism as Fn). The tag goes into the constant pool
/// (SymLit — same shape as a symbol literal; **emission order = resolution
/// order**: the H/B bodies come before the tag intern — lowering/emission
/// tree orders agree, pool order preserved).
fn emit_handle(
    ctx: &mut CompileCtxt,
    tag: &Rc<str>,
    handler: &IrProto,
    thunk: &IrProto,
    span: Span,
) -> Result<(), CompileError> {
    // ① trampoline prototype (program-level lazy singleton — code=[Ret];
    //    span is always dummy, aligned with the krf-side (0 0 0) triple —
    //    the parity criteria include debug_spans)
    let tp = ensure_trampoline(ctx);
    // ② H prototype (handler: params = [payload_var, resume_var] — fixed
    //    in IrProto.params)
    let hp = emit_inner_proto(ctx, handler)?;
    // ③ B prototype (body thunk: params = [])
    let bp = emit_inner_proto(ctx, thunk)?;
    // ④ tag constant (SymLit — same shape as a symbol literal, interned
    //    by content)
    let tk = ctx.intern_const(BcConst::SymLit(tag.clone()));
    // ⑤ the atomic frame-orchestration instruction (captures are taken by
    //    the VM from the current frame per both prototypes' descriptors)
    ctx.emit(
        Op::InstallHandler {
            handler: hp,
            body: bp,
            tag: tk,
            trampoline: tp,
        },
        span,
    );
    Ok(())
}

/// Group-install emission (r136 / 206-b — TD-033, handle-multi-arm-design
/// §8 D15): T (shared lazy singleton) → H₁..H_N (per-arm handler
/// prototypes, source order) → B (the shared body thunk) → tk₁..tk_N (per-
/// arm SymLit constants, source order) → the atomic
/// `INSTALL_HANDLER_GROUP` (interleaved operands hp₁ tk₁ … hp_N tk_N bp
/// tp — the VM takes per-arm captures from the current frame per each H
/// prototype's descriptors). Byte-parity with compiler.ktf's
/// `compile-handle-group` (the same deterministic order — the parity
/// criterion bytecode_equal includes debug_spans).
fn emit_handle_group(
    ctx: &mut CompileCtxt,
    arms: &[IrHandleArm],
    thunk: &IrProto,
    span: Span,
) -> Result<(), CompileError> {
    // ① trampoline prototype (the shared program-level lazy singleton)
    let tp = ensure_trampoline(ctx);
    // ② per-arm H prototypes (params = [payload_var, resume_var] — fixed
    //    in each IrProto.params; source order)
    let mut handler_idxs: Vec<u32> = Vec::with_capacity(arms.len());
    for arm in arms {
        handler_idxs.push(emit_inner_proto(ctx, &arm.handler)?);
    }
    // ③ the shared B prototype (body thunk: params = [])
    let bp = emit_inner_proto(ctx, thunk)?;
    // ④ per-arm tag constants (SymLit, source order — interned by content)
    let mut entries: Vec<(u32, u32)> = Vec::with_capacity(arms.len());
    for (arm, hp) in arms.iter().zip(handler_idxs.iter()) {
        let tk = ctx.intern_const(BcConst::SymLit(arm.tag.clone()));
        entries.push((*hp, tk));
    }
    // ⑤ the atomic group frame-orchestration instruction
    ctx.emit(
        Op::InstallHandlerGroup {
            entries: entries.into_boxed_slice(),
            body: bp,
            trampoline: tp,
        },
        span,
    );
    Ok(())
}

/// Trampoline lazy generation (program-level singleton — created at the
/// first Handle; deterministic: the same source program always gets the
/// same prototype order). `debug_spans` is always `[dummy]` (the sentinel
/// frame's RET has no source location — aligned with the krf-side
/// (0 0 0)).
fn ensure_trampoline(ctx: &mut CompileCtxt) -> u32 {
    if let Some(idx) = ctx.trampoline {
        return idx;
    }
    let idx = ctx.protos.len() as u32;
    ctx.protos.push(BcProto {
        name: Symbol(u32::MAX - 2),
        params: Vec::new(),
        rest_slot: None,
        n_locals: 0,
        capture_names: Vec::new(),
        capture_sources: Vec::new(),
        code: vec![Op::Ret],
        debug_spans: vec![Span::dummy()],
        free_vars: Vec::new(),
    });
    ctx.trampoline = Some(idx);
    idx
}

/// Inner-prototype emission (the prototype segment of `emit_fn` — no
/// CLOSURE emission; reused by r25/42-f for Handle's H/B prototypes:
/// prototype allocation + body emission (tail = true — lambda-body
/// semantics) + trailing RET + switch back to the enclosing window.
/// Captures / free names / formal parameters are already fixed in
/// `IrProto` — emission does zero resolution).
fn emit_inner_proto(ctx: &mut CompileCtxt, proto: &IrProto) -> Result<u32, CompileError> {
    let proto_idx = ctx.protos.len() as u32;
    let proto_name = proto
        .params
        .first()
        .copied()
        .unwrap_or(Symbol(u32::MAX - 2));
    // r165 / 236-c: the emit_fn local-layout mirror (the rest slot at
    // `params.len()` + n_locals accounting).
    let rest_slot = proto.rest.map(|_| proto.params.len() as u32);
    let param_slots = proto.params.len() as u32 + u32::from(proto.rest.is_some());
    ctx.protos.push(BcProto {
        name: proto_name,
        params: proto.params.clone(),
        rest_slot,
        n_locals: param_slots,
        capture_names: proto.captures.iter().map(|c| c.name).collect(),
        capture_sources: proto.captures.iter().map(|c| c.source).collect(),
        code: vec![],
        debug_spans: vec![],
        free_vars: proto.free_vars.clone(),
    });

    let enclosing = ctx.current;
    ctx.current = proto_idx as usize;
    emit_ir(ctx, &proto.body, true)?;
    ctx.emit(Op::Ret, proto.body.span());
    ctx.current = enclosing;
    Ok(proto_idx)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::bytecode::CaptureSource;
    use kerf_core::CoreExpr;
    use kerf_syntax::ScopeSet;

    fn lit(v: i64) -> Rc<CoreExpr> {
        Rc::new(CoreExpr::Literal {
            value: LiteralValue::Int(v),
            span: Span::dummy(),
        })
    }

    fn var(n: u32) -> Rc<CoreExpr> {
        Rc::new(CoreExpr::Var {
            name: Symbol(n),
            scopes: ScopeSet::new(),
            span: Span::dummy(),
        })
    }

    fn app(f: Rc<CoreExpr>, args: Vec<Rc<CoreExpr>>) -> Rc<CoreExpr> {
        Rc::new(CoreExpr::Apply {
            fn_expr: f,
            args,
            span: Span::dummy(),
        })
    }

    fn compile_ok(exprs: &[Rc<CoreExpr>]) -> BcProgram {
        // r49 D59: the item-level entry — expression-item wrapper fixture
        // (the Define fixture goes through items_ok instead)
        let items: Vec<ModuleItem> = exprs
            .iter()
            .map(|e| ModuleItem::Expr(Rc::clone(e)))
            .collect();
        compile_module(&items).expect("compile failed")
    }

    /// Item-level compilation fixture (declaration items passed through
    /// directly).
    fn items_ok(items: &[ModuleItem]) -> BcProgram {
        compile_module(items).expect("compile failed")
    }

    #[test]
    fn compile_const_and_halt() {
        let p = compile_ok(&[lit(42)]);
        let main = p.entry_proto();
        assert_eq!(main.code, vec![Op::PushConst(0), Op::Halt]);
        assert_eq!(p.consts, vec![BcConst::Int(42)]);
        // Debug info fully covered (§19.3 invariant 3)
        assert_eq!(main.debug_spans.len(), main.code.len());
    }

    /// Build a do-desugared Let chain (test helper — r45/E5 S3 structural
    /// arm D42: the compiler-side mirror of
    /// core_forms::make_do_let_chain).
    fn let_chain(body: Vec<Rc<CoreExpr>>, span: Span) -> Rc<CoreExpr> {
        let mut it = body.into_iter().rev();
        let Some(mut acc) = it.next() else {
            return Rc::new(CoreExpr::Literal {
                value: LiteralValue::Nil,
                span,
            });
        };
        for e in it {
            acc = Rc::new(CoreExpr::Let {
                name: Symbol(999999),
                scopes: ScopeSet::new(),
                value: e,
                body: acc,
                span,
            });
        }
        acc
    }

    #[test]
    fn const_pool_dedup_in_program() {
        // (do 1 1 1) → the constant pool holds a single Int(1) (§19.3
        // pitfall).
        // r45/E5 S3 structural arm: the do form → Let-chain desugaring
        // (D42) — this assertion is the **bytecode-parity golden
        // snapshot** (the strictest e5-plan §3.2 S3 wording): discard-mode
        // compilation of [value; Pop; body] is **instruction-identical**
        // to the original Do per-item sequence (the machine-verification
        // anchor for the same source (do 1 1 1) before and after the
        // refactor).
        // r48/M-I note: the snapshot is maintained under the IndexIR
        // two-stage pipeline (emission order = resolution order — the D56
        // structural basis of bytecode equality).
        let exprs = vec![let_chain(vec![lit(1), lit(1), lit(1)], Span::dummy())];
        let p = compile_ok(&exprs);
        assert_eq!(p.consts, vec![BcConst::Int(1)]);
        // Stack balance: PUSH POP PUSH POP PUSH HALT (instruction-identical
        // to the r44 baseline)
        let main = p.entry_proto();
        assert_eq!(
            main.code,
            vec![
                Op::PushConst(0),
                Op::Pop,
                Op::PushConst(0),
                Op::Pop,
                Op::PushConst(0),
                Op::Halt
            ]
        );
    }

    #[test]
    fn let_bind_mode_emits_store_local() {
        // r45/D41: bind mode (the body references the bound name) →
        // [value; StoreLocal(slot); body] — slot = the frame's locals
        // append position (after the parameters); n_locals backpatched
        let name = Symbol(7);
        let body = vec![Rc::new(CoreExpr::Let {
            name,
            scopes: ScopeSet::new(),
            value: lit(5),
            body: Rc::new(CoreExpr::Var {
                name,
                scopes: ScopeSet::new(),
                span: Span::dummy(),
            }),
            span: Span::dummy(),
        })];
        let p = compile_ok(&body);
        let main = p.entry_proto();
        // Top level (main frame): value=5 → StoreLocal(0) → LoadLocal(0) →
        // Halt
        assert_eq!(
            main.code,
            vec![
                Op::PushConst(0),
                Op::StoreLocal(0),
                Op::LoadLocal(0),
                Op::Halt
            ]
        );
        // The main prototype's n_locals is backpatched (the Let binding
        // takes slot 0)
        assert_eq!(main.n_locals, 1);
    }

    #[test]
    fn if_backpatch_complete() {
        // (if cond 1 2)
        let expr = Rc::new(CoreExpr::If {
            cond: var(0),
            then_branch: lit(1),
            else_branch: lit(2),
            span: Span::dummy(),
        });
        let p = compile_ok(&[expr]);
        let main = p.entry_proto();
        // LOAD_GLOBAL, JUMP_IF_FALSE t, PUSH 1, JUMP e, PUSH 2(else), HALT
        assert!(matches!(main.code[1], Op::JumpIfFalse(t) if t != u32::MAX));
        assert!(matches!(main.code[3], Op::Jump(t) if t != u32::MAX));
        match (&main.code[1], &main.code[3]) {
            (Op::JumpIfFalse(tf), Op::Jump(te)) => {
                // the else entry = the position of PUSH 2 (4); the join
                // point = HALT (5)
                assert_eq!(*tf, 4);
                assert_eq!(*te, 5);
            }
            _ => panic!("jump structure error"),
        }
    }

    #[test]
    fn lambda_closure_conversion() {
        // (fn (x) (f x)) — f is free → global reference (Stage 0 single
        // frame has no capture source)
        let body = app(var(5), vec![var(0)]);
        let lam = Rc::new(CoreExpr::Fn {
            params: vec![Symbol(0)],
            param_scopes: vec![ScopeSet::new()],
            rest: None,
            body,
            span: Span::dummy(),
        });
        let p = compile_ok(&[lam]);
        assert_eq!(p.protos.len(), 2);
        let closure_proto = &p.protos[1];
        assert_eq!(closure_proto.arity(), 1);
        assert!(closure_proto.capture_names.is_empty());
        // Prototype body: LOAD_GLOBAL f, LOAD_LOCAL 0, TAIL_CALL 1, RET
        // (06 §2 A1: the function is evaluated first, arguments left to
        // right; body-tail Apply = TailCall — TD-022/H2 TCO tail-position
        // emission, frame-reuse semantics)
        assert_eq!(
            closure_proto.code,
            vec![
                Op::LoadGlobal(0),
                Op::LoadLocal(0),
                Op::TailCall(1),
                Op::Ret
            ]
        );
        // main: CLOSURE proto=1 captures=0, HALT
        assert_eq!(
            p.entry_proto().code,
            vec![
                Op::Closure {
                    proto: 1,
                    n_captures: 0
                },
                Op::Halt
            ]
        );
    }

    #[test]
    fn nested_lambda_captures() {
        // (fn (x) (fn (y) (x y))) — the inner one captures x
        let inner = Rc::new(CoreExpr::Fn {
            params: vec![Symbol(1)],
            param_scopes: vec![ScopeSet::new()],
            rest: None,
            body: app(var(0), vec![var(1)]),
            span: Span::dummy(),
        });
        let outer = Rc::new(CoreExpr::Fn {
            params: vec![Symbol(0)],
            param_scopes: vec![ScopeSet::new()],
            rest: None,
            body: inner,
            span: Span::dummy(),
        });
        let p = compile_ok(&[outer]);
        assert_eq!(p.protos.len(), 3);
        // Prototype 2 (inner) captures x (source = prototype 1's local
        // slot 0)
        assert_eq!(p.protos[2].capture_names, vec![Symbol(0)]);
        assert_eq!(p.protos[2].capture_sources, vec![CaptureSource::Local(0)]);
        // main → CLOSURE(1, 0); prototype 1: CLOSURE(2, 1), RET (capture
        // descriptors taken directly)
        assert_eq!(
            p.protos[1].code,
            vec![
                Op::Closure {
                    proto: 2,
                    n_captures: 1
                },
                Op::Ret
            ]
        );
        // Prototype 2: LOAD_CAPTURED 0(x), LOAD_LOCAL 0(y), TAIL_CALL 1,
        // RET (06 §2 A1 evaluation order: the callee before the arguments;
        // body-tail Apply = TailCall — TD-022/H2 TCO tail-position
        // emission)
        assert_eq!(
            p.protos[2].code,
            vec![
                Op::LoadCaptured(0),
                Op::LoadLocal(0),
                Op::TailCall(1),
                Op::Ret
            ]
        );
    }

    #[test]
    fn deterministic_compilation() {
        // Same-result test basis: compiling the same input twice →
        // identical bytecode
        let items = vec![
            ModuleItem::Define {
                name: Symbol(9),
                value: lit(7),
                span: Span::dummy(),
            },
            ModuleItem::Expr(app(var(9), vec![lit(1)])),
        ];
        let a = items_ok(&items);
        let b = items_ok(&items);
        assert!(a.bytecode_equal(&b));
    }

    #[test]
    fn define_emits_global_store() {
        let items = vec![ModuleItem::Define {
            name: Symbol(3),
            value: lit(5),
            span: Span::dummy(),
        }];
        let p = items_ok(&items);
        assert_eq!(
            p.entry_proto().code,
            vec![Op::PushConst(0), Op::Dup, Op::DefineGlobal(1), Op::Halt]
        );
        assert_eq!(p.global_refs, vec![Symbol(3)]);
    }

    #[test]
    fn app_evaluates_fn_then_args_left_to_right() {
        // (f a b) → f, a, b, CALL 2 (06 §2 A1: function first, arguments
        // left to right)
        let e = app(var(9), vec![var(1), var(2)]);
        let p = compile_ok(&[e]);
        let code = &p.entry_proto().code;
        // LOAD_GLOBAL f, LOAD_GLOBAL a(1), LOAD_GLOBAL b(2), CALL 2, HALT
        assert!(matches!(code[0], Op::LoadGlobal(_))); // f
        assert!(matches!(code[1], Op::LoadGlobal(_))); // a
        assert!(matches!(code[2], Op::LoadGlobal(_))); // b
        assert_eq!(code[3], Op::Call(2));
    }
}

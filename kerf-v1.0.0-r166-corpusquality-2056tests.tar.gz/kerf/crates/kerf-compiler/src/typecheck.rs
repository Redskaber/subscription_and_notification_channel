//! Conservative static type checker (Stage 1 batch C).
//!
//! Design basis: [12-roadmap §2.5.2](../../docs/lang-design/12-roadmap.md) Stage 1
//! node L "introduce a type checker" + the external-Rust-implementation ruling
//! for the bootstrap pitfall "type checker circular dependency"
//! ([07-bootstrap-strategy §2](../../docs/lang-design/07-bootstrap-strategy.md)
//! / sop.md §21.6 mitigation strategy — migrate to the target language at
//! Stage 2+).
//!
//! **Flag-period role (D8 phase 2 — r29/50-a)**: the `kerf check` production
//! decision surface has switched to [hm.rs](crate::hm) (HM inference —
//! `hm_check_program`); this module's R1-R8 have been **retired to regression
//! baseline assertions** (the reference side of the test-surface superset gate —
//! the hm_inference_tests / effect_tests dual-surface detection discipline is
//! retained). The flag-period redefinition of the conservativity contract
//! ("zero type-inconsistency false positives" + occurs/self-application
//! exemptions) is in hm-inference-design §2.3.
//!
//! **Conservativity contract (false positive = P1 defect)**: the checker reports
//! only **statically certain** errors — whenever a rule fires, the corresponding
//! program **necessarily** fails at runtime with the same class of error. Any
//! case that depends on dynamic information (unknown parameter value types,
//! hygiene symbols introduced by macros, recursive definitions) is classified as
//! `TcType::Unknown` and skips assertions. Criterion: zero conflicts between all
//! existing test programs and this checker (tests/v0 full regression = the
//! mechanical verification of conservativity).
//!
//! Rule set (R1-R8, each corresponding to one class of **certain** runtime error):
//! - R1 `if` condition statically known to be non-bool (runtime E1 truthy family);
//! - R2 arithmetic-family operand statically known to be non-numeric;
//! - R3 comparison-family operand statically known to be non-numeric (TD-016
//!   all-operands criterion) / strings mixed with numbers;
//! - R4 `not` operand statically known to be non-bool;
//! - R5 `car`/`cdr` operand statically known to be non-pair;
//! - R6 callee expression statically known to be non-callable (runtime E4 family);
//! - R7 arity mismatch: literal lambda / builtin signature (runtime E2/E3 family);
//! - R8 string/symbol-family operand statically known to be type-mismatched.
//!
//! **Multi-error collection**: all rule firings for a single program are
//! aggregated and returned in Span order — the first consumer of the TD-013
//! multi-error-collection design (the `kerf check` reporting surface).
//!
//! Depth budget: `MAX_CHECK_DEPTH` defends against recursion stack overflow on
//! deeply nested expressions (aligned with the TD-017 measured 2 MiB thread
//! stack criterion) — subtrees over budget are skipped by the check
//! (conservative Unknown: no false positives, and no noisy diagnostics either).

use std::collections::HashMap;
use std::rc::Rc;

use kerf_core::{CoreExpr, LiteralValue, ModuleItem};
use kerf_span::{Diagnostic, DiagnosticCode, Span};
use kerf_syntax::{Symbol, SymbolTable};

/// Static checking diagnostic code (E0005 — after the structured stage-code
/// sequence Read/Expand/Compile/Run).
pub const CHECK_DIAG_CODE: DiagnosticCode = DiagnosticCode(5);

/// Check recursion depth budget (stack safety; over-limit subtrees are
/// conservatively skipped).
///
/// Value basis: 2× headroom over the Reader nesting limit of 256; measured
/// calibration — debug builds have a ~1 KiB frame size, and depth 2000 was
/// measured to overflow the 2 MiB thread stack (archived in typecheck unit
/// tests), so 512 × 1 KiB = 512 KiB (4× safety margin). Macro expansion can
/// produce extra-deep structures (A3 limit 10_000) — subtrees over budget stay
/// conservatively Unknown (zero false positives, zero noise).
pub const MAX_CHECK_DEPTH: usize = 512;

/// Static type (the conservative type lattice inferred internally by the checker).
///
/// `Num` = the union of Int/Float (the static upper bound of numeric-tower mixed
/// promotion); `Unknown` = anything (⊤ — insufficient dynamic information, never
/// triggers an assertion).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TcType {
    /// Any type (insufficient information — does not participate in assertions).
    Unknown,
    Int,
    Float,
    /// Int ∪ Float (the legal domain of arithmetic/comparison).
    Num,
    Bool,
    Str,
    Nil,
    Symbol,
    Pair,
    /// Callable (lambda or builtin; the arity constraint serves R7).
    Callable {
        min_args: usize,
        max_args: Option<usize>,
    },
}

impl TcType {
    /// Renders as a short name matching the runtime `type_name` convention
    /// (error-message alignment).
    pub fn render(self) -> &'static str {
        match self {
            TcType::Unknown => "unknown",
            TcType::Int => "int",
            TcType::Float => "float",
            TcType::Num => "num",
            TcType::Bool => "bool",
            TcType::Str => "str",
            TcType::Nil => "nil",
            TcType::Symbol => "symbol",
            TcType::Pair => "pair",
            TcType::Callable { .. } => "procedure",
        }
    }

    /// Whether it is a member of the numeric domain (Int/Float/Num).
    fn is_num(self) -> bool {
        matches!(self, TcType::Int | TcType::Float | TcType::Num)
    }

    /// Type-lattice join: the conservative upper bound at branch merge points.
    fn join(self, other: TcType) -> TcType {
        use TcType::*;
        match (self, other) {
            (a, b) if matches!((a, b), (Unknown, _) | (_, Unknown)) => Unknown,
            (Int, Float) | (Float, Int) | (Num, Int) | (Int, Num) | (Num, Float) | (Float, Num) => {
                Num
            }
            (a, b) if a == b => a,
            // `_` arm rationale: distinct concrete types (e.g. Int and Str) — at
            // runtime only one of them can be taken, and statically we cannot
            // narrow to a single type, so conservatively Unknown
            _ => Unknown,
        }
    }
}

/// Parameter type rule (the data form of the builtin signature table — the
/// checker interprets rules and holds no knowledge of concrete builtin names;
/// the sole trusted source of the builtin list is kerf-driver builtins.rs,
/// §2.3 principle 10).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TcParam {
    /// Anything (not checked).
    Any,
    /// Number (Int/Float).
    Num,
    /// Integer (index-like parameters).
    Int,
    /// Boolean.
    Bool,
    /// String.
    Str,
    /// Symbol value (TD-002).
    Symbol,
    /// Pair.
    Pair,
    /// List (Pair ∪ Nil — length/reverse accept the empty list).
    List,
}

/// Parameter rule layout: variadic (one shared rule) / fixed per-position /
/// comparison-family special cases.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TcParams {
    /// Variadic: all parameters share the same rule.
    Variadic(TcParam),
    /// Fixed: per-position rules (the length is the fixed arity).
    Fixed(&'static [TcParam]),
    /// `=` family special case: all numbers or all strings (09-stdlib TD-016
    /// boundary semantics; after the TD-011 r24 resolution, strings participate
    /// in the whole family via total ordering — same semantics as Ordering).
    NumOrAllStr,
    /// Ordering comparison family (< > <= >=): all numbers or all strings
    /// (code-point order); a mix is a statically certain error (TD-011 r24:
    /// same criterion as runtime / the `=` family).
    Ordering,
}

/// Builtin function static signature (injected by kerf-driver — maintained in
/// the same file as the register_globals registration list, to prevent drift).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct BuiltinSig {
    /// Parameter rules.
    pub params: TcParams,
    /// Call result type (consumed by upper-level inference).
    pub result: TcType,
    /// Minimum arity.
    pub min_args: usize,
    /// Maximum arity (None = no upper bound).
    pub max_args: Option<usize>,
}

impl BuiltinSig {
    /// Variadic signature constructor (arity ≥ min, all parameters share one
    /// rule). const: the compile-time construction entry for the static
    /// signature table (driver BUILTIN_SIGS).
    pub const fn variadic(param: TcParam, result: TcType, min_args: usize) -> Self {
        BuiltinSig {
            params: TcParams::Variadic(param),
            result,
            min_args,
            max_args: None,
        }
    }

    /// Fixed signature constructor (parameter rules given per position).
    /// const — as above.
    pub const fn fixed(params: &'static [TcParam], result: TcType) -> Self {
        BuiltinSig {
            params: TcParams::Fixed(params),
            result,
            min_args: params.len(),
            max_args: Some(params.len()),
        }
    }

    /// `=` family comparison signature constructor (all numbers or all strings
    /// → bool). const — as above.
    pub const fn num_or_all_str() -> Self {
        BuiltinSig {
            params: TcParams::NumOrAllStr,
            result: TcType::Bool,
            min_args: 2,
            max_args: None,
        }
    }

    /// Ordering comparison family signature constructor (< > <= >=: all numbers
    /// → bool). const — as above.
    pub const fn ordering() -> Self {
        BuiltinSig {
            params: TcParams::Ordering,
            result: TcType::Bool,
            min_args: 2,
            max_args: None,
        }
    }
}

/// Checks a core expression sequence (the post-expansion top-level form) and
/// returns all static diagnostics (sorted in Span order — multi-error
/// collection, the consumer surface of the TD-013 design).
///
/// Entry contract: `builtins` is the user-visible builtin symbol → signature
/// map (constructed by the driver from the same-source register_globals list);
/// `table` is the symbol table used to compile the sequence (operator-name
/// rendering — diagnostic messages align with the runtime prefix).
pub fn check_program(
    items: &[ModuleItem],
    builtins: &HashMap<Symbol, BuiltinSig>,
    table: &SymbolTable,
) -> Vec<Diagnostic> {
    let mut diags = Vec::new();
    let mut ctx = TypeCtxt::new(builtins, table);
    for item in items {
        ctx.check_item(item, &mut diags);
    }
    diags.sort_by_key(|d| {
        (
            d.primary_span.file_id,
            d.primary_span.start,
            d.primary_span.end,
        )
    });
    diags
}

struct TypeCtxt<'a> {
    builtins: &'a HashMap<Symbol, BuiltinSig>,
    table: &'a SymbolTable,
    /// Lexical environment (symbol → type). Lambda parameters are bound as
    /// Unknown; defines fill in order; new bindings shadow old
    /// bindings/builtins.
    env: HashMap<Symbol, TcType>,
}

impl<'a> TypeCtxt<'a> {
    fn new(builtins: &'a HashMap<Symbol, BuiltinSig>, table: &'a SymbolTable) -> Self {
        TypeCtxt {
            builtins,
            table,
            env: HashMap::new(),
        }
    }

    fn diag(&self, diags: &mut Vec<Diagnostic>, message: String, span: Span) {
        diags.push(Diagnostic::error(Some(CHECK_DIAG_CODE), message, span));
    }

    /// Top-level/module-body items (r49 D59 — item level: Define takes effect
    /// for subsequent items; Require carries zero type payload; Module bodies
    /// recurse; expression items go through `check_expr`).
    fn check_item(&mut self, item: &ModuleItem, diags: &mut Vec<Diagnostic>) {
        match item {
            ModuleItem::Define { name, value, .. } => {
                let ty = self.check_expr(value, 0, diags);
                self.env.insert(*name, ty);
                // The define item's own return value does not participate in
                // subsequent inference (conservative Unknown)
            }
            ModuleItem::Require { .. } => {}
            ModuleItem::Module { items, .. } => {
                for inner in items {
                    self.check_item(inner, diags);
                }
            }
            ModuleItem::Expr(e) => {
                self.check_expr(e, 0, diags);
            }
        }
    }

    /// Checks an expression and returns its static type.
    fn check_expr(
        &mut self,
        e: &Rc<CoreExpr>,
        depth: usize,
        diags: &mut Vec<Diagnostic>,
    ) -> TcType {
        if depth > MAX_CHECK_DEPTH {
            // Depth budget exhausted: skip conservatively (no diagnostic —
            // avoids noise from deeply nested programs; equivalent to
            // "unchecked", zero false-positive risk)
            return TcType::Unknown;
        }
        match e.as_ref() {
            CoreExpr::Literal { value, .. } => literal_ty(value),
            CoreExpr::Var { name, .. } => self.lookup(*name),
            CoreExpr::Fn {
                params, rest, body, ..
            } => {
                // Parameters are bound as Unknown (dynamic values), restored
                // after checking the body (shadowing semantics)
                let saved: Vec<(Symbol, Option<TcType>)> = params
                    .iter()
                    .map(|p| (*p, self.env.insert(*p, TcType::Unknown)))
                    .collect();
                // r165 / 236-c (D6): the rest binding rides the same
                // Unknown discipline (the folded pair chain's type is
                // inferred nowhere at this face — the runtime is the
                // authority).
                let rest_saved = rest
                    .as_ref()
                    .map(|(r, _)| (*r, self.env.insert(*r, TcType::Unknown)));
                self.check_expr(body, depth + 1, diags);
                for (sym, old) in saved {
                    restore(&mut self.env, sym, old);
                }
                if let Some((sym, old)) = rest_saved {
                    restore(&mut self.env, sym, old);
                }
                // r165 / 236-c: the rest face — minimum arity, no upper
                // bound (the `Callable` model's variadic shape, the
                // BuiltinSig::variadic discipline mirrored).
                TcType::Callable {
                    min_args: params.len(),
                    max_args: rest.is_none().then_some(params.len()),
                }
            }
            CoreExpr::Apply {
                fn_expr,
                args,
                span,
            } => self.check_app(fn_expr, args, *span, depth, diags),
            CoreExpr::If {
                cond,
                then_branch,
                else_branch,
                span,
            } => {
                let cond_ty = self.check_expr(cond, depth + 1, diags);
                // R1: condition statically known to be non-bool (runtime
                // explicit truthy semantics)
                if !matches!(cond_ty, TcType::Unknown | TcType::Bool) {
                    self.diag(
                        diags,
                        format!(
                            "if condition requires bool, got {}(static check)",
                            cond_ty.render()
                        ),
                        *span,
                    );
                }
                let t = self.check_expr(then_branch, depth + 1, diags);
                let e_ty = self.check_expr(else_branch, depth + 1, diags);
                t.join(e_ty)
            }
            CoreExpr::Let {
                name, value, body, ..
            } => {
                // r45/E5 S3 structural arm (22 §14 D42/D43): the Let chain
                // carries the sequencing semantics of the original Do (a Define
                // in value position was ruled by the expander to have global
                // semantics — the unified post-03c/03d-fix behavior isomorphism
                // is maintained) + the lexical binding of a real let
                // (save/restore — same shape as Fn parameters).
                // do desugaring produces the fixed name "do": users never
                // reference the reserved-word name in a Var — binding it is
                // harmless (in discard mode the type does not participate).
                // r49 declaration-layer arm: a define inside the chain is not
                // representable (item-position do-splice carries the top-level
                // sequence of defines) — value is always an expression
                let val_ty = self.check_expr(value, depth + 1, diags);
                let old = self.env.insert(*name, val_ty);
                let body_ty = self.check_expr(body, depth + 1, diags);
                match old {
                    Some(prev) => {
                        self.env.insert(*name, prev);
                    }
                    None => {
                        self.env.remove(name);
                    }
                }
                body_ty
            }
            CoreExpr::Assign { value, .. } => {
                // set! returns the assigned value (Stage 0 semantics); does not
                // change the binding's existing type
                self.check_expr(value, depth + 1, diags)
            }
            // r28/48-b effect arm convergence (plan §5b — closes the deep-review
            // D3/D8 "Unknown relaxation surface" coverage gap): the Perform
            // effect value / Handle body and handler body are subject to R1-R8
            // checks (sub-expression traversal); the result type stays Unknown —
            // the Perform value = an arbitrary value injected by resume, the
            // Handle value = the dynamic result of the body/handler-body merge
            // (effect-language-design: effect rows / row polymorphism belong to
            // the Stage 3 type layer — the ruling not to tighten the static
            // surface is maintained)
            CoreExpr::Perform { effect, .. } => {
                self.check_expr(effect, depth + 1, diags);
                TcType::Unknown
            }
            // Handle binder binding (same save/restore shape as the Fn arm —
            // mirroring the shadowing discipline): payload = a dynamic value
            // injected by dispatch → Unknown; resume = the continuation call
            // shape (D4 desugars to Apply at expansion time — calls in value
            // position are conservatively assertion-free) → Unknown
            CoreExpr::Handle {
                payload_var,
                resume_var,
                handler_body,
                body,
                ..
            } => {
                let saved: Vec<(Symbol, Option<TcType>)> = [payload_var, resume_var]
                    .into_iter()
                    .map(|p| (*p, self.env.insert(*p, TcType::Unknown)))
                    .collect();
                self.check_expr(handler_body, depth + 1, diags);
                self.check_expr(body, depth + 1, diags);
                for (sym, old) in saved {
                    restore(&mut self.env, sym, old);
                }
                TcType::Unknown
            }
            // r136 / 206-b (D16): per-arm binders → Unknown (each arm's two
            // binders enter/leave independently around its own handler body;
            // the protected body checks outside them — the same
            // conservative skip as the single-arm form)
            CoreExpr::HandleGroup { arms, body, .. } => {
                let mut all_saved: Vec<(Symbol, Option<TcType>)> =
                    Vec::with_capacity(arms.len() * 2);
                for arm in arms {
                    let saved: Vec<(Symbol, Option<TcType>)> = [arm.payload_var, arm.resume_var]
                        .into_iter()
                        .map(|p| (p, self.env.insert(p, TcType::Unknown)))
                        .collect();
                    self.check_expr(&arm.handler_body, depth + 1, diags);
                    all_saved.extend(saved);
                }
                for (sym, old) in all_saved {
                    restore(&mut self.env, sym, old);
                }
                self.check_expr(body, depth + 1, diags);
                TcType::Unknown
            }
        }
    }

    fn check_app(
        &mut self,
        fn_expr: &Rc<CoreExpr>,
        args: &[Rc<CoreExpr>],
        span: Span,
        depth: usize,
        diags: &mut Vec<Diagnostic>,
    ) -> TcType {
        let fn_ty = self.check_expr(fn_expr, depth + 1, diags);
        let arg_tys: Vec<TcType> = args
            .iter()
            .map(|a| self.check_expr(a, depth + 1, diags))
            .collect();
        // Builtin-call determination: fn_expr is a Var and not shadowed by a
        // user lexical binding
        let builtin_sig = match fn_expr.as_ref() {
            CoreExpr::Var { name, .. } => {
                if self.env.contains_key(name) {
                    None
                } else {
                    self.builtins.get(name).copied()
                }
            }
            _ => None,
        };
        if let Some(sig) = builtin_sig {
            let op = match fn_expr.as_ref() {
                CoreExpr::Var { name, .. } => self.table.name(*name).to_string(),
                // Defensive fallback: when the call site is not a Var there is
                // no symbol name to attribute (the code near line 408 above
                // already narrowed builtin calls to the direct-reference form)
                _ => "<builtin>".to_string(),
            };
            self.check_builtin_app(&op, &sig, args, &arg_tys, span, diags);
            return sig.result;
        }
        match fn_ty {
            TcType::Unknown => {}
            TcType::Callable { min_args, max_args } => {
                // R7: arity mismatch (literal lambda / known closure)
                if args.len() < min_args || max_args.is_some_and(|m| args.len() > m) {
                    let expect = match max_args {
                        Some(m) if m == min_args => format!("expected {}", min_args),
                        _ => format!("expected at least {}", min_args),
                    };
                    self.diag(
                        diags,
                        format!(
                            "procedure argument count mismatch: {} actual {}(static check)",
                            expect,
                            args.len()
                        ),
                        span,
                    );
                }
            }
            // R6: callee expression statically known to be non-callable
            other => {
                self.diag(
                    diags,
                    format!("uncallable value: {}(static check)", other.render()),
                    span,
                );
            }
        }
        TcType::Unknown
    }

    /// Rule checking of builtin calls (R2/R3/R4/R5/R7/R8 — data-driven
    /// interpretation of the signature table).
    fn check_builtin_app(
        &mut self,
        op: &str,
        sig: &BuiltinSig,
        args: &[Rc<CoreExpr>],
        arg_tys: &[TcType],
        span: Span,
        diags: &mut Vec<Diagnostic>,
    ) {
        // R7: builtin arity (floor / ceiling; arity checked first — same
        // criterion as runtime)
        if args.len() < sig.min_args || sig.max_args.is_some_and(|m| args.len() > m) {
            let expect = match sig.max_args {
                Some(m) if m == sig.min_args => format!("{} requires {} arguments", op, m),
                _ => format!("{} at least requires {} arguments", op, sig.min_args),
            };
            self.diag(
                diags,
                format!("{}, got {}(static check)", expect, args.len()),
                span,
            );
            return; // parameter rules are meaningless after an arity error
        }
        match sig.params {
            TcParams::Variadic(rule) => {
                for (a, ty) in args.iter().zip(arg_tys) {
                    self.check_param_rule(op, rule, *ty, a, diags);
                }
            }
            TcParams::Fixed(rules) => {
                for ((a, ty), rule) in args.iter().zip(arg_tys).zip(rules) {
                    self.check_param_rule(op, *rule, *ty, a, diags);
                }
            }
            TcParams::NumOrAllStr | TcParams::Ordering => {
                // R3 (comparison family — TD-016 all-operands criterion; after
                // the TD-011 r24 resolution strings participate in the whole
                // family via total ordering): an all-number or all-string chain
                // passes statically (code-point order is legal at runtime); a
                // mixed chain gets per-parameter domain diagnostics (the first
                // non-number → the runtime-aligned "{op} needs a number"
                // message).
                let concrete: Vec<TcType> = arg_tys
                    .iter()
                    .copied()
                    .filter(|t| !matches!(t, TcType::Unknown))
                    .collect();
                if !concrete.is_empty() && concrete.iter().all(|t| matches!(t, TcType::Str)) {
                    return; // all strings (code-point-order comparison — legal at runtime)
                }
                for (a, ty) in args.iter().zip(arg_tys) {
                    if matches!(ty, TcType::Unknown) || ty.is_num() {
                        continue;
                    }
                    self.diag(
                        diags,
                        format!(
                            "{} requires a number, got {}(static check)",
                            op,
                            ty.render()
                        ),
                        expr_span(a, span),
                    );
                }
            }
        }
    }

    fn check_param_rule(
        &mut self,
        op: &str,
        rule: TcParam,
        ty: TcType,
        arg: &Rc<CoreExpr>,
        diags: &mut Vec<Diagnostic>,
    ) {
        if matches!(ty, TcType::Unknown) || rule == TcParam::Any {
            return;
        }
        let ok = match rule {
            TcParam::Any => true,
            TcParam::Num => ty.is_num(),
            TcParam::Int => matches!(ty, TcType::Int),
            TcParam::Bool => matches!(ty, TcType::Bool),
            TcParam::Str => matches!(ty, TcType::Str),
            TcParam::Symbol => matches!(ty, TcType::Symbol),
            TcParam::Pair => matches!(ty, TcType::Pair),
            TcParam::List => matches!(ty, TcType::Pair | TcType::Nil),
        };
        if !ok {
            let want = match rule {
                TcParam::Num => "number",
                TcParam::Int => "int",
                TcParam::Bool => "bool",
                TcParam::Str => "str",
                TcParam::Symbol => "symbol",
                TcParam::Pair => "pair",
                TcParam::List => "list",
                TcParam::Any => unreachable!("Any already short-circuit"),
            };
            let msg = if rule == TcParam::Num {
                format!(
                    "{} requires a number, got {}(static check)",
                    op,
                    ty.render()
                )
            } else {
                format!(
                    "{} requires {}, got {}(static check)",
                    op,
                    want,
                    ty.render()
                )
            };
            self.diag(diags, msg, expr_span(arg, Span::dummy()));
        }
    }

    fn lookup(&self, name: Symbol) -> TcType {
        if let Some(t) = self.env.get(&name) {
            return *t;
        }
        if let Some(sig) = self.builtins.get(&name) {
            return TcType::Callable {
                min_args: sig.min_args,
                max_args: sig.max_args,
            };
        }
        // Hygiene symbols introduced by macros (name$hyg$N) and other unknown
        // references: resolved dynamically, conservatively Unknown (unbound
        // checks are a runtime E3 responsibility — under the hygiene fallback
        // mechanism a static assertion would produce false positives)
        TcType::Unknown
    }
}

fn restore(env: &mut HashMap<Symbol, TcType>, sym: Symbol, old: Option<TcType>) {
    match old {
        Some(t) => {
            env.insert(sym, t);
        }
        None => {
            env.remove(&sym);
        }
    }
}

fn literal_ty(value: &LiteralValue) -> TcType {
    match value {
        LiteralValue::Int(_) => TcType::Int,
        LiteralValue::Float(_) => TcType::Float,
        LiteralValue::Str(_) => TcType::Str,
        LiteralValue::Bool(_) => TcType::Bool,
        LiteralValue::Nil => TcType::Nil,
        LiteralValue::Symbol(_) => TcType::Symbol,
        LiteralValue::Pair(_, _) => TcType::Pair,
    }
}

/// The expression's own Span (full CoreExpr node coverage — see expr.rs `span()`).
fn expr_span(e: &Rc<CoreExpr>, fallback: Span) -> Span {
    let own = e.span();
    if own == Span::dummy() {
        fallback
    } else {
        own
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use kerf_core::LiteralValue;
    use kerf_span::Span;

    fn lit(v: LiteralValue) -> Rc<CoreExpr> {
        Rc::new(CoreExpr::Literal {
            value: v,
            span: Span::dummy(),
        })
    }

    /// Depth budget (programmatically constructed surface): expression trees
    /// beyond MAX_CHECK_DEPTH — unreachable from source text due to the Reader
    /// depth limit of 256, but macro expansion can produce extra-deep structures
    /// (A3: expansion depth limit 10_000) — the budget truncates recursion,
    /// no crash, zero diagnostics.
    #[test]
    fn depth_budget_skips_beyond_limit() {
        let mut e = lit(LiteralValue::Int(1));
        for _ in 0..(MAX_CHECK_DEPTH + 500) {
            e = Rc::new(CoreExpr::If {
                cond: lit(LiteralValue::Bool(true)),
                then_branch: e,
                else_branch: lit(LiteralValue::Int(2)),
                span: Span::dummy(),
            });
        }
        // r49 D59: expression-item wrapper fixture
        let core = vec![kerf_core::ModuleItem::Expr(e)];
        let builtins = HashMap::new();
        let table = SymbolTable::new();
        let diags = check_program(&core, &builtins, &table);
        assert!(
            diags.is_empty(),
            "over-budget subtree conservatively skipped -- zero diagnostics (actual {} items)",
            diags.len()
        );
    }

    /// Within the depth budget boundary (exactly MAX_CHECK_DEPTH): full check,
    /// no truncation.
    #[test]
    fn depth_budget_within_limit_full_check() {
        // Construct (if 1 2 3) nested at the tail of an if-true chain within
        // budget — R1 should detect it
        let mut e = Rc::new(CoreExpr::If {
            cond: lit(LiteralValue::Int(1)),
            then_branch: lit(LiteralValue::Int(2)),
            else_branch: lit(LiteralValue::Int(3)),
            span: Span::dummy(),
        });
        for _ in 0..100 {
            e = Rc::new(CoreExpr::If {
                cond: lit(LiteralValue::Bool(true)),
                then_branch: e,
                else_branch: lit(LiteralValue::Int(2)),
                span: Span::dummy(),
            });
        }
        // r49 D59: expression-item wrapper fixture
        let core = vec![kerf_core::ModuleItem::Expr(e)];
        let builtins = HashMap::new();
        let table = SymbolTable::new();
        let diags = check_program(&core, &builtins, &table);
        assert_eq!(diags.len(), 1);
        assert!(diags[0].message.contains("if condition requires bool"));
    }

    /// Empty program / no arguments: zero diagnostics (boundary defense).
    #[test]
    fn empty_program_no_diags() {
        let builtins = HashMap::new();
        let table = SymbolTable::new();
        assert!(check_program(&[], &builtins, &table).is_empty());
    }
}

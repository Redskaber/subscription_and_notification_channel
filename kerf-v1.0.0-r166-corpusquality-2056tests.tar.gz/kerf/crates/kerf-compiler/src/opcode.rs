//! Bytecode opcodes (stage0.md §8.12: ~35+ opcodes, grouped by category).
//!
//! Groups (§8.12):
//! - **Stack operations**: PUSH_CONST / PUSH_NIL / PUSH_TRUE / PUSH_FALSE / POP / DUP / SWAP;
//! - **Function operations**: CLOSURE / CALL / RET;
//! - **Control flow**: JUMP / JUMP_IF_FALSE;
//! - **Data construction**: MAKE_PAIR / CAR / CDR;
//! - **Variable access**: LOAD_LOCAL / STORE_LOCAL / LOAD_GLOBAL / STORE_GLOBAL /
//!   DEFINE_GLOBAL / LOAD_CAPTURED / STORE_CAPTURED (closure capture conversion,
//!   Stage 0 extension; DEFINE_GLOBAL is the frozen contract of the D1/E6 semantics);
//! - **Arithmetic and comparison**: ADD / SUB / MUL / DIV / MOD / NUM_LT / NUM_GT /
//!   NUM_LE / NUM_GE / NUM_EQ / EQ / NOT;
//! - **Predicates**: IS_NULL / IS_PAIR / IS_INT / IS_BOOL / IS_PROCEDURE;
//! - **Termination**: HALT;
//! - **Effects (r25/42-f)**: INSTALL_HANDLER / PERFORM;
//! - **FFI (r30/48-d)**: CALL_EXTERNAL / ALLOC_EXTERNAL / FREE_EXTERNAL
//!   (implemented on the IR/VM side — the language-side surface lands at Stage 3
//!   and the compilation arm does not emit them; ffi-ownership-model §2/§8 window
//!   protocol and the bytecode side of the three primitives).

/// Opcode (Debug rendering + PartialEq for parity-test comparison).
#[derive(Debug, Clone, PartialEq)]
pub enum Op {
    // ---- Stack operations ----
    /// Pushes the constant at constant pool index `k`.
    PushConst(u32),
    /// Pushes nil.
    PushNil,
    /// Pushes true.
    PushTrue,
    /// Pushes false.
    PushFalse,
    /// Pops and discards the top of the stack.
    Pop,
    /// Duplicates the top of the stack.
    Dup,
    /// Swaps the top two stack items.
    Swap,

    // ---- Variable access ----
    /// Reads local slot `i` of the current frame.
    LoadLocal(u32),
    /// Writes local slot `i` of the current frame.
    StoreLocal(u32),
    /// Reads a global by constant pool symbol index.
    LoadGlobal(u32),
    /// Writes a global by constant pool symbol index.
    StoreGlobal(u32),
    /// Defines a global by constant pool symbol index (D1/E6 semantics: writes
    /// only when absent; when already present reports "duplicate variable
    /// definition" — aligned with the eval path's `Env::define`; theorem T1
    /// requires both paths to agree on global storage semantics).
    DefineGlobal(u32),
    /// Reads capture slot `i` of the current closure.
    LoadCaptured(u32),
    /// Writes capture slot `i` of the current closure (shared mutable cell —
    /// lexical closure semantics).
    StoreCaptured(u32),

    // ---- Control flow ----
    /// Jumps unconditionally to `t`.
    Jump(u32),
    /// Jumps to `t` when the top of the stack is false (truthiness semantics
    /// explicitly defined: only Bool participates, other types report
    /// TypeMismatch — §19.5 pitfall 3).
    JumpIfFalse(u32),

    // ---- Function operations ----
    /// Constructs a closure from prototype `proto`, popping `n_captures` captured
    /// values.
    Closure {
        proto: u32,
        n_captures: u32,
    },
    /// Calls the function on top of the stack; `n` actual arguments have already
    /// been pushed in order (the callee is the n-th item from the top).
    Call(u32),
    /// **Tail call (TD-022/H2 — TCO)**: semantics match Call, but with frame
    /// reuse — the callee's return goes directly to the current frame's caller
    /// (the current frame is torn down, net frame count zero). The compiler emits
    /// it only in tail position of a function body (Fn body / If arms / last item
    /// of Do).
    TailCall(u32),
    /// Returns: pops the return value and restores the caller's frame.
    Ret,

    // ---- Arithmetic and comparison ----
    Add,
    Sub,
    Mul,
    Div,
    Mod,
    NumLt,
    NumGt,
    NumLe,
    NumGe,
    NumEq,
    /// Generic equality (immediate values by value, heap values by reference).
    Eq,
    /// Logical negation (Bool only).
    Not,

    // ---- Data construction ----
    /// Pops (b, a) and constructs the pair (a . b) (heap-allocated).
    MakePair,
    /// Takes the left part of a pair.
    Car,
    /// Takes the right part of a pair.
    Cdr,

    // ---- Predicates ----
    IsNull,
    IsPair,
    IsInt,
    IsBool,
    IsProcedure,

    // ---- Termination ----
    /// Terminates: pops the final result value.
    Halt,

    // ---- Effects (r25/42-f — effect-language-design D6/D8) ----
    /// Installs a handler and invokes the protected body (the full frame
    /// orchestration of the handle expression).
    ///
    /// Takes the capture cells of the handler/body prototypes from the current
    /// frame → ① push the handler frame (`trampoline` sentinel prototype —
    /// code=[Ret]; ext1 = HandlerFrame{tag, handler prototype, captures, data
    /// stack watermark}; ret = (current prototype, after this instruction)) →
    /// ② push the body thunk frame (ret = (trampoline, 0)) → ③ transfer
    /// execution to the body. The body's RET goes through the trampoline, which
    /// pops the handler frame and resumes after this instruction (R11-return);
    /// a tail call inside the body tears down the thunk frame and penetrates
    /// (D8: TCO is orthogonal to shallow handling — the handler frame stays
    /// below); perform throws upward, scanning ext1 for a match to dispatch
    /// (R11-dispatch, D6).
    InstallHandler {
        handler: u32,
        body: u32,
        /// Dispatch tag (constant pool SymLit index — a symbol value).
        tag: u32,
        trampoline: u32,
    },
    /// Effect throw (R10-perform): pops the effect value (must be a
    /// `(tag . payload)` pair — tag = a symbol value) → scans down the frame
    /// stack from the top for the nearest handler frame whose ext1 matches →
    /// snapshots the suspended continuation (suspended frame chain + data
    /// stack + resume point) → tears frames down to the handler boundary →
    /// the handler frame morphs into a handler-body execution frame
    /// (locals = [payload, κ], ext1 cleared — one-shot shallow handling) →
    /// the data stack is truncated back to the installation watermark.
    /// No match = E0007 (escapes to top level).
    Perform,

    // ---- FFI (r30/48-d — ffi-ownership-model §2/§8; implemented on the IR/VM
    // side, language-side surface at Stage 3 (plan §5b batch J scheduling
    // note 3)) ----
    /// Calls an external function (symbols resolve by name through the extern
    /// symbol table — E0012 fail-closed; `symbol` = constant pool SymLit index
    /// (extern symbol name — a flat symbol space, independent of the user's
    /// lexical environment, not shadowable by define/set!).
    /// Window protocol (ffi-ownership-model §2.1 steps 2-4, executed by the
    /// boundary wrapper layer): actual arguments are already pushed in order
    /// (step 1 done by preceding instructions) → cross the boundary (pin heap
    /// arguments Φ[v]+=1 + validate token arguments for validity, Invalid =
    /// E0010) → host call (VM suspended) → wrap the return + unpin all heap
    /// arguments (Φ[v]-=1).
    CallExternal {
        symbol: u32,
        n_args: u32,
    },
    /// Allocates external memory (external malloc domain — **never goes through
    /// the GC**; yields a CPointer token). `size = 0` is rejected at compile
    /// time (lowering side) + defensively rejected at runtime (E0011) —
    /// defense in depth (§6 case 4).
    AllocExternal {
        size: u32,
    },
    /// Frees external memory (consumption semantics: slot-level invalidation
    /// markers take effect globally; freeing an Invalid again = E0010 double
    /// free; an Opaque token = E0011; a non-token value = E0011).
    FreeExternal,
    /// r136 / 206-b (TD-033 — handle-multi-arm-design.md §8 D14): group
    /// handler install. Appended at the enum tail to preserve the frozen
    /// declaration-order numbering (0..=45 — the compiler.krf OP-* table and
    /// the bootstrap bridge's `op_from_value` both key on it), so this is
    /// opcode #46 (the effects group's third instruction by family, last by
    /// number — the four-way sync: enum ↔ count test ↔ 04-bytecode-vm §1 ↔
    /// compiler.krf OP-*).
    ///
    /// Operands (interleaved arm order, variable length):
    /// `(op 46 hp₁ tk₁ hp₂ tk₂ … hp_N tk_N bp tp)` — N = (operand count −
    /// 2) / 2 arms (N ≥ 1); `hpᵢ` = the i-th arm's handler prototype,
    /// `tkᵢ` = the i-th arm's dispatch tag (constant pool SymLit index),
    /// `bp` = the body thunk prototype, `tp` = the trampoline prototype.
    /// Execution: per-arm capture cells are taken from the current frame →
    /// ONE handler frame is pushed (ext1 = HandlerFrame{entries: N}; the
    /// frame's capture slots carry the concatenation of all arms' captures —
    /// the GC root face) → the body thunk frame is pushed (ret =
    /// (trampoline, 0)) → execution transfers to the body. On dispatch, the
    /// matched arm's entry shapes the H execution frame and the WHOLE group
    /// is consumed (the frame is replaced — sibling entries die with it:
    /// symmetric non-protection between sibling arm bodies — the Koka-style
    /// shallow multi-case reading of 06 §10 [HANDLE-INSTALL]).
    InstallHandlerGroup {
        /// (handler proto, tag const) per arm — source order.
        entries: Box<[(u32, u32)]>,
        /// Body thunk prototype.
        body: u32,
        /// Trampoline prototype (the shared lazy singleton).
        trampoline: u32,
    },
}

impl Op {
    /// Instruction name (for disassembly rendering).
    pub fn name(&self) -> &'static str {
        match self {
            Op::PushConst(_) => "PUSH_CONST",
            Op::PushNil => "PUSH_NIL",
            Op::PushTrue => "PUSH_TRUE",
            Op::PushFalse => "PUSH_FALSE",
            Op::Pop => "POP",
            Op::Dup => "DUP",
            Op::Swap => "SWAP",
            Op::TailCall(_) => "TAIL_CALL",
            Op::LoadLocal(_) => "LOAD_LOCAL",
            Op::StoreLocal(_) => "STORE_LOCAL",
            Op::LoadGlobal(_) => "LOAD_GLOBAL",
            Op::StoreGlobal(_) => "STORE_GLOBAL",
            Op::DefineGlobal(_) => "DEFINE_GLOBAL",
            Op::LoadCaptured(_) => "LOAD_CAPTURED",
            Op::StoreCaptured(_) => "STORE_CAPTURED",
            Op::Jump(_) => "JUMP",
            Op::JumpIfFalse(_) => "JUMP_IF_FALSE",
            Op::Closure { .. } => "CLOSURE",
            Op::Call(_) => "CALL",
            Op::Ret => "RET",
            Op::Add => "ADD",
            Op::Sub => "SUB",
            Op::Mul => "MUL",
            Op::Div => "DIV",
            Op::Mod => "MOD",
            Op::NumLt => "NUM_LT",
            Op::NumGt => "NUM_GT",
            Op::NumLe => "NUM_LE",
            Op::NumGe => "NUM_GE",
            Op::NumEq => "NUM_EQ",
            Op::Eq => "EQ",
            Op::Not => "NOT",
            Op::MakePair => "MAKE_PAIR",
            Op::Car => "CAR",
            Op::Cdr => "CDR",
            Op::IsNull => "IS_NULL",
            Op::IsPair => "IS_PAIR",
            Op::IsInt => "IS_INT",
            Op::IsBool => "IS_BOOL",
            Op::IsProcedure => "IS_PROCEDURE",
            Op::Halt => "HALT",
            Op::InstallHandler { .. } => "INSTALL_HANDLER",
            Op::Perform => "PERFORM",
            Op::InstallHandlerGroup { .. } => "INSTALL_HANDLER_GROUP",
            Op::CallExternal { .. } => "CALL_EXTERNAL",
            Op::AllocExternal { .. } => "ALLOC_EXTERNAL",
            Op::FreeExternal => "FREE_EXTERNAL",
        }
    }

    /// Operand rendering (disassembly).
    pub fn render_operands(&self) -> String {
        match self {
            Op::PushConst(k)
            | Op::LoadLocal(k)
            | Op::StoreLocal(k)
            | Op::LoadGlobal(k)
            | Op::StoreGlobal(k)
            | Op::DefineGlobal(k)
            | Op::LoadCaptured(k)
            | Op::StoreCaptured(k)
            | Op::Jump(k)
            | Op::JumpIfFalse(k)
            | Op::Call(k) => format!(" {}", k),
            Op::Closure { proto, n_captures } => {
                format!(" proto={} captures={}", proto, n_captures)
            }
            Op::InstallHandler {
                handler,
                body,
                tag,
                trampoline,
            } => {
                format!(
                    " handler={} body={} tag={} trampoline={}",
                    handler, body, tag, trampoline
                )
            }
            Op::InstallHandlerGroup {
                entries,
                body,
                trampoline,
            } => {
                let arms: Vec<String> = entries
                    .iter()
                    .map(|(h, t)| format!("{}:{}", h, t))
                    .collect();
                format!(
                    " arms=[{}] body={} trampoline={}",
                    arms.join(" "),
                    body,
                    trampoline
                )
            }
            Op::CallExternal { symbol, n_args } => {
                format!(" symbol={} n_args={}", symbol, n_args)
            }
            Op::AllocExternal { size } => format!(" size={}", size),
            // `_` arm rationale: operand-less instructions (PushNil/Pop/Dup/Ret/arithmetic/comparison/predicates/Car/Cdr/Halt/Perform/FreeExternal etc.) — no operand suffix
            _ => String::new(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn opcode_count_matches_spec() {
        // Frozen contract: 46 opcodes (full enumeration aligned with
        // 04-bytecode-vm §1). Listed one by one to keep the count stable —
        // adding/removing any variant must be synchronized between the 04 doc
        // and this list (bidirectional freeze: enum ↔ test ↔ doc, three-way
        // consistency). r21/42-b fix: TailCall (introduced by r18/40-c TCO) was
        // previously missing from this list — the three-way freeze drift was
        // repaired per R4 (code is authoritative + the doc is corrected in the
        // same change). r30/48-d extension: the three FFI instructions (43→46,
        // tenth group — the bytecode side of ffi-ownership-model §2/§8;
        // language-side surface at Stage 3 — plan §5b scheduling note 3).
        let ops = [
            // Stack operations (7)
            Op::PushConst(0),
            Op::PushNil,
            Op::PushTrue,
            Op::PushFalse,
            Op::Pop,
            Op::Dup,
            Op::Swap,
            // Variable access (7)
            Op::LoadLocal(0),
            Op::StoreLocal(0),
            Op::LoadGlobal(0),
            Op::StoreGlobal(0),
            Op::DefineGlobal(0),
            Op::LoadCaptured(0),
            Op::StoreCaptured(0),
            // Control flow (2)
            Op::Jump(0),
            Op::JumpIfFalse(0),
            // Function operations (4: including TailCall — TD-022/H2 TCO, r18)
            Op::Closure {
                proto: 0,
                n_captures: 0,
            },
            Op::Call(0),
            Op::TailCall(0),
            Op::Ret,
            // Arithmetic and comparison (12)
            Op::Add,
            Op::Sub,
            Op::Mul,
            Op::Div,
            Op::Mod,
            Op::NumLt,
            Op::NumGt,
            Op::NumLe,
            Op::NumGe,
            Op::NumEq,
            Op::Eq,
            Op::Not,
            // Data construction (3)
            Op::MakePair,
            Op::Car,
            Op::Cdr,
            // Predicates (5)
            Op::IsNull,
            Op::IsPair,
            Op::IsInt,
            Op::IsBool,
            Op::IsProcedure,
            // Termination (1)
            Op::Halt,
            // Effects (2: r25/42-f — effect-language-design D6, primitive set 9→11
            // maps to two bytecode-side instructions; 04-bytecode-vm frozen in sync)
            Op::InstallHandler {
                handler: 0,
                body: 0,
                tag: 0,
                trampoline: 0,
            },
            Op::Perform,
            // FFI (3: r30/48-d — ffi-ownership-model §2/§8; implemented on the
            // IR/VM side, language-side surface at Stage 3; the 04 doc and the
            // compiler.krf OP-* table kept in three-way sync)
            Op::CallExternal {
                symbol: 0,
                n_args: 0,
            },
            Op::AllocExternal { size: 0 },
            Op::FreeExternal,
            // Effects group arm 3 (r136 / 206-b — TD-033 group install;
            // appended at the tail to preserve the frozen numbering —
            // opcode #46, the effects family's third instruction)
            Op::InstallHandlerGroup {
                entries: Box::new([(0, 0)]),
                body: 0,
                trampoline: 0,
            },
        ];
        assert_eq!(
            ops.len(),
            47,
            "opcode total (r136/206-b TD-033 group installation 46→47 -- 04 doc and compiler.krf OP-* table four-way sync)"
        );
    }

    #[test]
    fn render_shapes() {
        assert_eq!(Op::Call(3).name(), "CALL");
        assert_eq!(Op::Call(3).render_operands(), " 3");
        assert_eq!(
            Op::Closure {
                proto: 1,
                n_captures: 2
            }
            .render_operands(),
            " proto=1 captures=2"
        );
        assert_eq!(Op::Add.render_operands(), "");
    }
}

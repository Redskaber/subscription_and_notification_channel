//! IndexIR — the **resolution-closure layer** that fixes name resolution at
//! compile time (r48 / E5 S3 structural-arm continuation, M-I indexing —
//! 21 §5.3 shape card).
//!
//! **Pipeline position**: `CoreExpr` (name-based — the E3 ① expansion layer
//! stays name-based forever, [01 §7.3]) → **`IrExpr` (this layer:
//! resolution results embedded)** → bytecode (emission does zero
//! resolution — compile.rs is a pure emission domain). The IR-layer
//! realization of the E3 ② "Core/IR-layer de Bruijn = Stage 3" layered
//! ruling; the **Closed-half first form** of the "ANF+Closed" layer in the
//! 15 §5.2 six-layer IR plan (explicit environment = capture sources fixed;
//! the ANF atomization half is still carried by the kerf-backend anf.rs
//! PoC).
//!
//! **Encoding shape (D56)**: slot-level lexical addressing (de Bruijn
//! **level** linearization — absolute in-frame slots, not binding-distance
//! indices). Criteria: ① alpha-free encoding equivalence (optimizer
//! transformation substitutions share the no-renaming obligation); ② native
//! alignment with VM frame slots (`LoadLocal`/`StoreLocal`/capture
//! descriptors with zero conversion loss — the formalized adoption of
//! primitive-migration-evaluation A1: "lexical addressing is implemented,
//! de Bruijn's runtime benefits are already secured, the remaining issue
//! lives only at the IR shape layer"). Pure binding-distance indices are an
//! isomorphic alternative (the backend can convert losslessly) — not
//! adopted (zero benefit in exchange for churn).
//!
//! **Single resolution pass**: `Binding`/`ScopeFrame`/`match_bindings`/
//! `resolve_var` moved into this module from compile.rs — the TD-004/r13
//! `(name, scopes ⊆)` subset-matching semantics with **zero change**
//! (compiler.krf L303-366 semantic mirror maintained — D57 mirror
//! discipline: the seed/bootstrap mirroring obligation covers three
//! surfaces: the shared data protocol + resolution semantics + bytecode
//! output; the compiler's internal pipeline organization is outside the
//! mirroring obligation; compiler.krf's own arm has zero change, so gate
//! A/B parity always holds).
//!
//! **Responsibility boundary**: this module only does name resolution and
//! structural fixing (the resolution closure); it does not do prototype
//! allocation / constant pool / jump backpatching (emission domain —
//! compile.rs); it does not do type inference (typecheck domain — E3 risk
//! note: diagnostic name rendering needs names, so typecheck/hm stays on
//! the name-based CoreExpr); it does not do evaluation.
//!
//! **Emission-invariant carry-over**: resolution order = emission order
//! (the lowering tree order matches the emission tree order — constant-pool
//! intern order / prototype order / global first-occurrence order are all
//! preserved bit for bit, the structural basis of bytecode-equality parity);
//! slot-reuse semantics preserved (after a Let binding pops, sibling
//! bindings reuse the same slot — n_locals takes the max concurrent
//! depth).

use std::rc::Rc;

use kerf_core::{CoreExpr, LiteralValue, ModuleItem};
use kerf_span::Span;
use kerf_syntax::{ScopeSet, Symbol};

use crate::bytecode::CaptureSource;
use crate::compile::CompileError;

/// A variable's resolution result (single source of truth: the lowering
/// scope stack — moved in from the former compile.rs `VarSource` and made
/// public).
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum IrVar {
    /// Local slot in the current frame (de Bruijn level linearization —
    /// absolute in-frame slot).
    Local(u32),
    /// Captured slot of the current closure (explicit environment — the
    /// capture source was already fixed in an enclosing frame).
    Captured(u32),
    /// Global (by name — the empty-scope global binding ⊆ any reference
    /// set; at emission time the pool index is fetched via
    /// `intern_global`, first-occurrence order = tree order).
    Global(Symbol),
    /// r137 / 207-c (TD-026 language-surface window,
    /// ffi-language-surface-design §4/D4): an extern-space symbol — the
    /// flat FFI symbol space (name-only matching, hygiene-proof). Carries
    /// the interned name string (the emission's SymLit const payload —
    /// `Op::CallExternal` reads the symbol as a `BcConst::SymLit` operand,
    /// never pushed). Legal in exactly one position: the Apply head
    /// (compiled to the frozen FFI call instruction — the callee-first
    /// evaluation-order contract carries the arg values). A standalone
    /// value-position occurrence is rejected at emission (D5 — there is
    /// no "extern function value"; ffi-ownership-model §4).
    Extern(std::rc::Rc<str>),
}

/// Fixed capture source (an explicit-environment entry — the lowering-first
/// form of `BcProto.capture_names/capture_sources`).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct IrCapture {
    /// Captured name (`BcProto.capture_names` metadata).
    pub name: Symbol,
    /// Capture source (an enclosing frame's local slot / captured slot —
    /// `BcProto.capture_sources`).
    pub source: CaptureSource,
}

/// Prototype body (shared by the three sites: Fn and Handle's H/B — the
/// unified IR shape of the resolution segment of compile_lambda /
/// compile_inner_proto).
#[derive(Debug, Clone, PartialEq)]
pub struct IrProto {
    /// Formal parameter names (`BcProto.params` metadata; **resolution
    /// surface = arity = len** — the semantic carrier of the M-I shape card
    /// `Lambda→Fn(params: usize)`: names live only in metadata and take no
    /// part in resolution).
    pub params: Vec<Symbol>,
    /// r165 / 236-c (variadic-rest-design.md D2-d): the rest binding —
    /// `Some(name)` when the source fn declares `...name: T`. The rest
    /// local slot = `params.len()` (the local-bindings append position at
    /// lowering); the emission face carries it as `BcProto.rest_slot`.
    pub rest: Option<Symbol>,
    /// Fixed capture sources (explicit environment — a sequence of
    /// `IrCapture`).
    pub captures: Vec<IrCapture>,
    /// Full set of free names (`BcProto.free_vars` metadata — including
    /// global reference names, in first-occurrence order).
    pub free_vars: Vec<Symbol>,
    /// Resolved body (in this prototype's frame context — an `IrExpr` tree).
    pub body: Rc<IrExpr>,
}

/// Resolution-closure IR (mirrors the 12 CoreExpr variants with the same
/// word roots — the within-layer extension of D34's "one semantics, one
/// name"; field differences = the M-I indexing payload).
#[derive(Debug, Clone, PartialEq)]
pub enum IrExpr {
    /// `(fn (params...) body)` — captures fixed + body resolved.
    Fn { proto: IrProto, span: Span },
    /// `(fn-expr arg1...)` (a call — positional form).
    Apply {
        fn_expr: Rc<IrExpr>,
        args: Vec<Rc<IrExpr>>,
        span: Span,
    },
    /// `(if cond then else)`.
    If {
        cond: Rc<IrExpr>,
        then_branch: Rc<IrExpr>,
        else_branch: Rc<IrExpr>,
        span: Span,
    },
    /// Variable reference — **resolution result embedded** (M-I: the
    /// slot-level form of `VarRef→Var(de Bruijn)`).
    Var { res: IrVar, span: Span },
    /// Literal (including the pair structure produced by quote).
    Literal { value: LiteralValue, span: Span },
    /// `(assign name value)` — target resolved (same wording as Var,
    /// TD-004).
    Assign {
        res: IrVar,
        value: Rc<IrExpr>,
        span: Span,
    },
    /// `(define name value)` — the position discipline is enforced during
    /// lowering (legal only at prototype depth 0 — the lexicalized
    /// equivalent of the former compile.rs `current != 0` check).
    Define {
        name: Symbol,
        value: Rc<IrExpr>,
        span: Span,
    },
    /// `(let (name value) body)` — slot fixed + discard/bind mode decided
    /// (bind = the body references the bound name; in discard mode the slot
    /// is invalid and always 0).
    Let {
        slot: u32,
        bind: bool,
        value: Rc<IrExpr>,
        body: Rc<IrExpr>,
        span: Span,
    },
    /// `(module ...)` — the body is inlined (the compile path only consumes
    /// the body sequence; name/imports/exports are namespace-domain payload
    /// — the driver consumes them on the CoreExpr surface first, and they
    /// never enter the compilation IR).
    Module { body: Vec<Rc<IrExpr>>, span: Span },
    /// `(require ...)` — zero runtime semantics (compile-time capability
    /// verification happens in the driver front-end pipeline at R9/E0006 —
    /// caps never enter the compilation IR).
    Require { span: Span },
    /// `(perform effect)`.
    Perform { effect: Rc<IrExpr>, span: Span },
    /// `(handle tag ((payload resume) handler) body)` — both prototype
    /// bodies resolved: H (handler) / B (body thunk) (the trampoline is a
    /// lazy emission-domain singleton — it never enters the IR).
    Handle {
        tag: Rc<str>,
        handler: IrProto,
        thunk: IrProto,
        span: Span,
    },
    /// r136 / 206-b (TD-033 — D15): `(handle-group arm+ body)` — per-arm H
    /// prototypes + the shared B thunk (group install; the trampoline stays
    /// a lazy emission-domain singleton).
    HandleGroup {
        arms: Vec<IrHandleArm>,
        thunk: IrProto,
        span: Span,
    },
}

/// One arm of `IrExpr::HandleGroup` (r136 / 206-b — D15).
#[derive(Debug, Clone, PartialEq)]
pub struct IrHandleArm {
    pub tag: Rc<str>,
    pub handler: IrProto,
}

impl IrExpr {
    /// The node's Span.
    pub fn span(&self) -> Span {
        match self {
            IrExpr::Fn { span, .. }
            | IrExpr::Apply { span, .. }
            | IrExpr::If { span, .. }
            | IrExpr::Var { span, .. }
            | IrExpr::Literal { span, .. }
            | IrExpr::Assign { span, .. }
            | IrExpr::Define { span, .. }
            | IrExpr::Let { span, .. }
            | IrExpr::Module { span, .. }
            | IrExpr::Require { span, .. }
            | IrExpr::Perform { span, .. }
            | IrExpr::Handle { span, .. }
            | IrExpr::HandleGroup { span, .. } => *span,
        }
    }
}

// ---------------------------------------------------------------------------
// Resolution machine (TD-004/r13 — moved in from compile.rs, zero semantic
// change)
// ---------------------------------------------------------------------------

/// Lexical binding entry (at lowering time): name + binding scope set
/// (TD-004/r13).
#[derive(Debug, Clone)]
struct Binding {
    name: Symbol,
    scopes: ScopeSet,
}

/// In-frame subset-matching resolution: among bindings with the same name
/// and `binder.scopes ⊆ ref_scopes`, take the max-cardinality one (ties go
/// to the first registered — same-name same-layer is already rejected by
/// the expander/define_scoped, so ties are only theoretically possible);
/// returns (slot, binding scope set).
fn match_bindings(
    bindings: &[Binding],
    name: Symbol,
    ref_scopes: &ScopeSet,
) -> Option<(u32, ScopeSet)> {
    let mut best: Option<(u32, ScopeSet)> = None;
    let mut best_rank = 0usize;
    for (i, b) in bindings.iter().enumerate() {
        if b.name != name || !b.scopes.is_subset_of(ref_scopes) {
            continue;
        }
        let rank = b.scopes.len();
        if best.is_none() || rank > best_rank {
            best = Some((i as u32, b.scopes.clone()));
            best_rank = rank;
        }
    }
    best
}

/// A lexical scope-stack frame (at lowering time).
#[derive(Debug, Default)]
struct ScopeFrame {
    locals: Vec<Binding>,
    captures: Vec<Binding>,
}

/// Lowering context (resolution domain — prototypes / constant pool /
/// backpatching live in the emission-domain CompileCtxt).
#[derive(Debug, Default)]
struct LowerCtxt {
    /// Scope stack (frame 0 = the main prototype).
    scopes: Vec<ScopeFrame>,
    /// r137 / 207-c (TD-026, ffi-language-surface-design §4/D4): the flat
    /// extern symbol space (declared extern names — name-set only, matched
    /// by Symbol alone so scope sets / macro hygiene never participate
    /// [ffi-ownership-model §4 "hygiene does not penetrate the FFI symbol
    /// space"]). Consulted **after** the lexical frames miss and **before**
    /// the global fallback — locals/captures may shadow (the practical
    /// reading; the "not shadowable" ruling's enforcement face is the
    /// driver's top-level define/extern collision rejection [D3-5]).
    extern_face: std::collections::HashMap<kerf_syntax::Symbol, std::rc::Rc<str>>,
}

impl LowerCtxt {
    /// r137 / 207-c: the extern-face-carrying constructor (empty = the
    /// historical `new` — the additive face; `lower_module` rides the empty
    /// delegate). The face maps Symbol → interned name string (the
    /// emission's SymLit payload).
    fn with_externs(externs: &[(kerf_syntax::Symbol, std::rc::Rc<str>)]) -> Self {
        LowerCtxt {
            scopes: vec![ScopeFrame::default()],
            extern_face: externs.iter().cloned().collect(),
        }
    }

    /// Resolve a variable's source (TD-004/r13: Racket set-of-scopes —
    /// moved in from the former compile.rs `resolve_var`, zero semantic
    /// change).
    ///
    /// Rules: walk the frame stack from the top (innermost) down; within a
    /// frame, locals come before captures, and among same-name bindings the
    /// one with `binder.scopes ⊆ ref_scopes` and max cardinality wins; the
    /// first frame containing a subset match wins (chain order). No subset
    /// candidate at all → Global (the empty-scope globals/builtins take
    /// over name-based resolution; the `$hyg$` base-name fallback is an
    /// already-demoted fallback path, same wording as the VM-side global
    /// layer — T1 consistency).
    fn resolve_var(&self, name: Symbol, ref_scopes: &ScopeSet) -> (IrVar, ScopeSet) {
        for (fi, frame) in self.scopes.iter().enumerate().rev() {
            if fi == 0 {
                // The main prototype frame: local slots exist but carry no
                // closure semantics — locals only
                if let Some((i, bs)) = match_bindings(&frame.locals, name, ref_scopes) {
                    return (IrVar::Local(i), bs);
                }
                continue;
            }
            if let Some((i, bs)) = match_bindings(&frame.locals, name, ref_scopes) {
                return (IrVar::Local(i), bs);
            }
            if let Some((i, bs)) = match_bindings(&frame.captures, name, ref_scopes) {
                return (IrVar::Captured(i), bs);
            }
        }
        // r137 / 207-c (D4): extern-space consultation — after the lexical
        // frames miss, before the global fallback. Name-only matching (the
        // reference's scope set is deliberately ignored — macro hygiene
        // does not penetrate the FFI symbol space, ffi-ownership-model §4).
        if let Some(name_str) = self.extern_face.get(&name) {
            return (IrVar::Extern(name_str.clone()), ScopeSet::new());
        }
        (IrVar::Global(name), ScopeSet::new())
    }
}

// ---------------------------------------------------------------------------
// lowering: CoreExpr → IrExpr (the single resolution-closure pass)
// ---------------------------------------------------------------------------

/// Module-level lowering entry (§10.1 rule 1: `<verb>_<noun>` free
/// function).
///
/// Input: the program's `ModuleItem` sequence (the expander's item-position
/// classification output). Output: the resolution-closure IR sequence
/// (consumed by the emission-domain `compile_module` — constant pool /
/// prototypes / backpatching are all emission-time decisions, and tree order
/// matches emission order → the structural basis of bytecode-equality
/// parity). Program item-sequence lowering (r49 D59 — the item-level entry:
/// declaration items are direct-translated [item positions are always at
/// depth 0 — expression-position defines are already structurally rejected
/// by the expander, the unrepresentable form of the position discipline];
/// expression items go through `lower_expr`).
pub fn lower_module(items: &[ModuleItem]) -> Result<Vec<Rc<IrExpr>>, CompileError> {
    lower_module_with_externs(items, &[])
}

/// r137 / 207-c (TD-026 language-surface window, ffi-language-surface-design
/// §4/D4): the extern-face-carrying lowering entry — `externs` is the flat
/// extern symbol space (declared names; the signature itself was already
/// consumed by the driver's five-fold declaration validation [D3] — the
/// resolution layer only needs the name set). Empty face = `lower_module`
/// behavior identical bit for bit (principle 27 additivity; every existing
/// caller goes through the empty-face delegate).
pub fn lower_module_with_externs(
    items: &[ModuleItem],
    externs: &[(kerf_syntax::Symbol, std::rc::Rc<str>)],
) -> Result<Vec<Rc<IrExpr>>, CompileError> {
    let mut ctx = LowerCtxt::with_externs(externs);
    let mut out = Vec::with_capacity(items.len());
    for item in items {
        out.push(Rc::new(lower_item(&mut ctx, item)?));
    }
    Ok(out)
}

/// Item-level lowering (declaration items direct-translated + expression
/// items recursed; module bodies inline their item sequence under the same
/// rules as program items — the item-level extension of emission order =
/// resolution order).
fn lower_item(ctx: &mut LowerCtxt, item: &ModuleItem) -> Result<IrExpr, CompileError> {
    match item {
        ModuleItem::Define { name, value, span } => {
            // Top-level define item: value → DUP → DefineGlobal (the
            // emission order is pinned — the positional face of D1's
            // global-leak protection is carried structurally by the
            // expander [CoreExpr cannot represent expression-position
            // define], so this arm's item position is always legal)
            Ok(IrExpr::Define {
                name: *name,
                value: Rc::new(lower_expr(ctx, value, 0)?),
                span: *span,
            })
        }
        ModuleItem::Require { span, .. } => Ok(IrExpr::Require { span: *span }),
        ModuleItem::Module { items, span, .. } => {
            // Stage 0 single module: the body lowers inline
            // (name/imports/exports are namespace-domain payload — the
            // driver consumes them first, they never enter the compilation
            // IR).
            let mut body_irs = Vec::with_capacity(items.len());
            for inner in items {
                body_irs.push(Rc::new(lower_item(ctx, inner)?));
            }
            Ok(IrExpr::Module {
                body: body_irs,
                span: *span,
            })
        }
        ModuleItem::Expr(e) => lower_expr(ctx, e, 0),
    }
}

/// Single-expression lowering (`proto_depth` = the lexically enclosing
/// prototype depth — after the r49 declaration-layer arm, Define/Module/
/// Require are not in the expression domain [structurally rejected by the
/// expander]; the depth parameter is kept for the lexical depth check
/// inside Fn/Handle bodies [the historical decision source of the Define
/// position discipline — now carried structurally by the item-level
/// `lower_item`]).
fn lower_expr(ctx: &mut LowerCtxt, e: &CoreExpr, proto_depth: u32) -> Result<IrExpr, CompileError> {
    match e {
        CoreExpr::Literal { value, span } => Ok(IrExpr::Literal {
            value: value.clone(),
            span: *span,
        }),
        CoreExpr::Var { name, scopes, span } => {
            let (res, _) = ctx.resolve_var(*name, scopes);
            Ok(IrExpr::Var { res, span: *span })
        }
        CoreExpr::Fn {
            params,
            param_scopes,
            rest,
            body,
            span,
        } => {
            let proto = lower_inner_proto(ctx, params, param_scopes, rest, body, proto_depth)?;
            Ok(IrExpr::Fn { proto, span: *span })
        }
        CoreExpr::Apply {
            fn_expr,
            args,
            span,
        } => {
            let fn_ir = Rc::new(lower_expr(ctx, fn_expr, proto_depth)?);
            let mut arg_irs = Vec::with_capacity(args.len());
            for a in args {
                arg_irs.push(Rc::new(lower_expr(ctx, a, proto_depth)?));
            }
            Ok(IrExpr::Apply {
                fn_expr: fn_ir,
                args: arg_irs,
                span: *span,
            })
        }
        CoreExpr::If {
            cond,
            then_branch,
            else_branch,
            span,
        } => Ok(IrExpr::If {
            cond: Rc::new(lower_expr(ctx, cond, proto_depth)?),
            then_branch: Rc::new(lower_expr(ctx, then_branch, proto_depth)?),
            else_branch: Rc::new(lower_expr(ctx, else_branch, proto_depth)?),
            span: *span,
        }),
        CoreExpr::Assign {
            name,
            scopes,
            value,
            span,
        } => {
            let (res, _) = ctx.resolve_var(*name, scopes);
            Ok(IrExpr::Assign {
                res,
                value: Rc::new(lower_expr(ctx, value, proto_depth)?),
                span: *span,
            })
        }
        CoreExpr::Let {
            name,
            scopes,
            value,
            body,
            span,
        } => {
            // r45/E5 S3 structural arm (22 §14 D41/D42): the Let dual-mode
            // decision happens in lowering (a resolution-domain decision —
            // does the body reference the bound name?).
            //
            // **discard mode** (body does not reference the bound name —
            // chains whose fixed name "do" comes from do desugaring always
            // land here): emit `[value; Pop; body]`.
            // **bind mode** (body references the bound name): the binding
            // enters the frame (slot = the current frame's locals append
            // position — slot-reuse semantics: after the body pops, sibling
            // bindings reuse the same slot).
            let value_ir = Rc::new(lower_expr(ctx, value, proto_depth)?);
            let referenced = body
                .free_var_occurrence_list()
                .iter()
                .any(|(s, _)| *s == *name);
            if referenced {
                let slot = {
                    let frame = ctx.scopes.last_mut().expect("scope stack non-empty");
                    frame.locals.push(Binding {
                        name: *name,
                        scopes: scopes.clone(),
                    });
                    frame.locals.len() as u32 - 1
                };
                let body_ir = Rc::new(lower_expr(ctx, body, proto_depth)?);
                ctx.scopes
                    .last_mut()
                    .expect("scope stack non-empty")
                    .locals
                    .pop();
                Ok(IrExpr::Let {
                    slot,
                    bind: true,
                    value: value_ir,
                    body: body_ir,
                    span: *span,
                })
            } else {
                let body_ir = Rc::new(lower_expr(ctx, body, proto_depth)?);
                Ok(IrExpr::Let {
                    slot: 0,
                    bind: false,
                    value: value_ir,
                    body: body_ir,
                    span: *span,
                })
            }
        }
        CoreExpr::Perform { effect, span } => Ok(IrExpr::Perform {
            effect: Rc::new(lower_expr(ctx, effect, proto_depth)?),
            span: *span,
        }),
        CoreExpr::Handle {
            tag,
            payload_var,
            payload_scopes,
            resume_var,
            resume_scopes,
            handler_body,
            body,
            span,
        } => {
            // The lowering face of the r25/42-f three-prototype scheme:
            // H (params = [payload_var, resume_var]) + B (the body thunk) —
            // both prototype bodies resolve their captures inside the
            // enclosing scope stack (the trampoline is a lazy
            // emission-domain singleton).
            let handler = lower_inner_proto(
                ctx,
                &[*payload_var, *resume_var],
                &[payload_scopes.clone(), resume_scopes.clone()],
                &None,
                handler_body,
                proto_depth,
            )?;
            let thunk = lower_inner_proto(ctx, &[], &[], &None, body, proto_depth)?;
            Ok(IrExpr::Handle {
                tag: tag.clone(),
                handler,
                thunk,
                span: *span,
            })
        }
        // r136 / 206-b (D15): per-arm H prototypes (params = [pᵢ, kᵢ]) +
        // the shared B thunk — the group-install lowering face
        CoreExpr::HandleGroup { arms, body, span } => {
            let mut ir_arms: Vec<IrHandleArm> = Vec::with_capacity(arms.len());
            for arm in arms {
                let handler = lower_inner_proto(
                    ctx,
                    &[arm.payload_var, arm.resume_var],
                    &[arm.payload_scopes.clone(), arm.resume_scopes.clone()],
                    &None,
                    &arm.handler_body,
                    proto_depth,
                )?;
                ir_arms.push(IrHandleArm {
                    tag: arm.tag.clone(),
                    handler,
                });
            }
            let thunk = lower_inner_proto(ctx, &[], &[], &None, body, proto_depth)?;
            Ok(IrExpr::HandleGroup {
                arms: ir_arms,
                thunk,
                span: *span,
            })
        }
    }
}

/// Inner-prototype lowering (unifies the resolution segments of the former
/// compile_lambda / compile_inner_proto — the emission segment is carried
/// by compile.rs `emit_inner_proto`).
///
/// Steps (bit-for-bit correspondence with the original implementation —
/// the parity premise that resolution order = emission order):
/// 1. Compute the Fn's free-variable occurrences (name + the
///    first-occurrence reference scope set, TD-004);
/// 2. For each free variable, resolve against the current scope stack by
///    `(name, scopes ⊆)`: Local/Captured → a capture entry (carrying the
///    hit binding's binding scope set — references inside the inner body
///    hit via the same subset match); Global → a global reference inside
///    the prototype;
/// 3. Push the new frame's scopes (param bindings carry their binding
///    scope sets; capture bindings carry the original binding scope sets),
///    and lower the prototype body (parameters = local slots 0..n);
/// 4. Pop the scope frame (returning the fixed captures + the resolved
///    body).
fn lower_inner_proto(
    ctx: &mut LowerCtxt,
    params: &[Symbol],
    param_scopes: &[ScopeSet],
    rest: &Option<(Symbol, ScopeSet)>,
    body: &Rc<CoreExpr>,
    proto_depth: u32,
) -> Result<IrProto, CompileError> {
    // Free-variable occurrences (excluding parameter shadowing; carrying
    // the first-occurrence reference scope set — the data source for
    // capture decisions). The rest binding shadows like a fixed param
    // (r165 / 236-c).
    let mut bound: Vec<Symbol> = params.to_vec();
    if let Some((r, _)) = rest {
        bound.push(*r);
    }
    let mut free: Vec<(Symbol, ScopeSet)> = Vec::new();
    body.free_var_occurrences(&mut bound, &mut free);

    // Capture resolution: free variables that resolve to Local/Captured
    // (capture descriptors are fixed at lowering time — the explicit
    // environment)
    let mut captures: Vec<IrCapture> = Vec::new();
    let mut capture_bindings: Vec<Binding> = Vec::new();
    let mut free_vars_all: Vec<Symbol> = Vec::new();
    for (f, f_scopes) in &free {
        free_vars_all.push(*f);
        let (source, binder_scopes) = ctx.resolve_var(*f, f_scopes);
        match source {
            IrVar::Local(i) => {
                captures.push(IrCapture {
                    name: *f,
                    source: CaptureSource::Local(i),
                });
                capture_bindings.push(Binding {
                    name: *f,
                    scopes: binder_scopes,
                });
            }
            IrVar::Captured(i) => {
                captures.push(IrCapture {
                    name: *f,
                    source: CaptureSource::Captured(i),
                });
                capture_bindings.push(Binding {
                    name: *f,
                    scopes: binder_scopes,
                });
            }
            IrVar::Global(_) => {} // stays a global reference inside the prototype
            IrVar::Extern(_) => {} // r137 / 207-c: stays an extern call site — the flat FFI symbol space is capture-free (no environment entry)
        }
    }

    // New scope frame (param bindings carry their binding scope sets;
    // missing ones tolerate-fallback to the empty set — hand-built
    // CoreExpr / legacy serialization paths carry no scopes, i.e.
    // name-based semantics). The rest binding rides the append position
    // = `params.len()` — the rest local slot (r165 / 236-c).
    let mut local_bindings: Vec<Binding> = params
        .iter()
        .enumerate()
        .map(|(i, n)| Binding {
            name: *n,
            scopes: param_scopes.get(i).cloned().unwrap_or_default(),
        })
        .collect();
    if let Some((r, rsp)) = rest {
        local_bindings.push(Binding {
            name: *r,
            scopes: rsp.clone(),
        });
    }
    ctx.scopes.push(ScopeFrame {
        locals: local_bindings,
        captures: capture_bindings,
    });

    // Body lowering (prototype depth + 1 — the lexical depth increment
    // point of the Define position discipline)
    let body_ir = lower_expr(ctx, body, proto_depth + 1)?;
    ctx.scopes.pop();

    Ok(IrProto {
        params: params.to_vec(),
        rest: rest.as_ref().map(|(r, _)| *r),
        captures,
        free_vars: free_vars_all,
        body: Rc::new(body_ir),
    })
}

#[cfg(test)]
mod tests {
    /// r49 D59: expression-item wrapper fixture (the lower_module
    /// item-level entry).
    fn item_expr(e: Rc<CoreExpr>) -> ModuleItem {
        ModuleItem::Expr(e)
    }

    use super::*;

    fn lit(v: i64) -> Rc<CoreExpr> {
        Rc::new(CoreExpr::Literal {
            value: LiteralValue::Int(v),
            span: Span::dummy(),
        })
    }

    fn var(n: u32) -> Rc<CoreExpr> {
        Rc::new(CoreExpr::Var {
            name: Symbol(n),
            scopes: ScopeSet::new(),
            span: Span::dummy(),
        })
    }

    fn var_scoped(n: u32, scopes: ScopeSet) -> Rc<CoreExpr> {
        Rc::new(CoreExpr::Var {
            name: Symbol(n),
            scopes,
            span: Span::dummy(),
        })
    }

    fn scopes_of(ids: &[u32]) -> ScopeSet {
        ScopeSet::from_iter_scopes(ids.iter().copied())
    }

    fn fn_expr(params: Vec<Symbol>, body: Rc<CoreExpr>) -> Rc<CoreExpr> {
        Rc::new(CoreExpr::Fn {
            params,
            param_scopes: Vec::new(),
            rest: None,
            body,
            span: Span::dummy(),
        })
    }

    fn let_expr(name: Symbol, value: Rc<CoreExpr>, body: Rc<CoreExpr>) -> Rc<CoreExpr> {
        Rc::new(CoreExpr::Let {
            name,
            scopes: ScopeSet::new(),
            value,
            body,
            span: Span::dummy(),
        })
    }

    /// Unwrap an IrExpr::Var's resolution result (test helper).
    /// r137 / 207-c: `IrVar` lost `Copy` (the `Extern(Rc<str>)` variant —
    /// the name string rides the resolution); the helper clones instead.
    fn var_res(ir: &IrExpr) -> IrVar {
        match ir {
            IrExpr::Var { res, .. } => res.clone(),
            other => panic!("expected IrExpr::Var, got {:?}", other),
        }
    }

    #[test]
    fn ir_let_slot_assignment_reuse_and_discard() {
        // ① bind mode: the body references the bound name → slot = the
        // frame's locals append position
        // (let a 5 a) → Let{slot:0, bind:true}
        let a = Symbol(7);
        let ir = lower_module(&[item_expr(let_expr(a, lit(5), var(7)))]).expect("lowering failed");
        match ir[0].as_ref() {
            IrExpr::Let {
                slot, bind, body, ..
            } => {
                assert_eq!(*slot, 0);
                assert!(*bind);
                assert_eq!(var_res(body), IrVar::Local(0));
            }
            other => panic!("expected Let, got {:?}", other),
        }

        // ② discard mode: the body does not reference the bound name →
        // bind=false (the slot is invalid)
        // (let a 5 9) → Let{bind:false}
        let ir = lower_module(&[item_expr(let_expr(a, lit(5), lit(9)))]).expect("lowering failed");
        match ir[0].as_ref() {
            IrExpr::Let { bind, .. } => assert!(!bind),
            other => panic!("expected Let, got {:?}", other),
        }

        // ③ slot reuse: sibling Lets (after the binding pops) reuse the
        // same slot — the in-frame concurrent depth stays unchanged
        // (let a 1 a) at top level then (let b 2 b): both get slot 0
        let b = Symbol(8);
        let ir = lower_module(&[
            item_expr(let_expr(a, lit(1), var(7))),
            item_expr(let_expr(b, lit(2), var(8))),
        ])
        .expect("lowering failed");
        match (ir[0].as_ref(), ir[1].as_ref()) {
            (IrExpr::Let { slot: s1, .. }, IrExpr::Let { slot: s2, .. }) => {
                assert_eq!(s1, s2);
                assert_eq!(*s1, 0);
            }
            other => panic!("expected two Let, got {:?}", other),
        }

        // ④ nested Let slot increment: (let a 1 (let b 2 (a b))) — the
        // outer bind (the body references a via the inner one) takes slot
        // 0, the inner bind (the body references b) appends slot 1
        let ir = lower_module(&[item_expr(let_expr(
            a,
            lit(1),
            let_expr(
                b,
                lit(2),
                Rc::new(CoreExpr::Apply {
                    fn_expr: var(7),
                    args: vec![var(8)],
                    span: Span::dummy(),
                }),
            ),
        ))])
        .expect("lowering failed");
        match ir[0].as_ref() {
            IrExpr::Let {
                slot: outer_slot,
                bind: outer_bind,
                body,
                ..
            } => {
                assert!(outer_bind);
                assert_eq!(*outer_slot, 0);
                match body.as_ref() {
                    IrExpr::Let { slot, bind, .. } => {
                        assert_eq!(*slot, 1);
                        assert!(*bind);
                    }
                    other => panic!("expected inner Let, got {:?}", other),
                }
            }
            other => panic!("expected outer Let, got {:?}", other),
        }
    }

    #[test]
    fn ir_nested_fn_capture_resolution() {
        // (fn (x) (fn (y) (x y))) — the inner one captures x (source =
        // the outer local slot 0)
        let inner = fn_expr(vec![Symbol(1)], {
            let mut e = var(0); // x
            e = Rc::new(CoreExpr::Apply {
                fn_expr: e,
                args: vec![var(1)], // y
                span: Span::dummy(),
            });
            e
        });
        let outer = fn_expr(vec![Symbol(0)], inner);
        let ir = lower_module(&[item_expr(outer)]).expect("lowering failed");
        match ir[0].as_ref() {
            IrExpr::Fn { proto, .. } => {
                assert!(proto.captures.is_empty()); // the outer one has no
                                                    // captures (x/y are params
                                                    // or globals — x is a param)
                match proto.body.as_ref() {
                    IrExpr::Fn { proto: inner_p, .. } => {
                        assert_eq!(inner_p.captures.len(), 1);
                        assert_eq!(inner_p.captures[0].name, Symbol(0));
                        assert_eq!(inner_p.captures[0].source, CaptureSource::Local(0));
                        // Inside the inner body: x → Captured(0), y →
                        // Local(0)
                        match inner_p.body.as_ref() {
                            IrExpr::Apply { fn_expr, args, .. } => {
                                assert_eq!(var_res(fn_expr), IrVar::Captured(0));
                                assert_eq!(var_res(&args[0]), IrVar::Local(0));
                            }
                            other => panic!("expected Apply, got {:?}", other),
                        }
                    }
                    other => panic!("expected inner Fn, got {:?}", other),
                }
            }
            other => panic!("expected Fn, got {:?}", other),
        }

        // Top-level global reference: (f 1) — f is unbound → Global
        let ir = lower_module(&[item_expr(Rc::new(CoreExpr::Apply {
            fn_expr: var(5),
            args: vec![lit(1)],
            span: Span::dummy(),
        }))])
        .expect("lowering failed");
        match ir[0].as_ref() {
            IrExpr::Apply { fn_expr, .. } => {
                assert_eq!(var_res(fn_expr), IrVar::Global(Symbol(5)));
            }
            other => panic!("expected Apply, got {:?}", other),
        }
    }

    #[test]
    fn ir_shadowing_max_cardinality_subset_match() {
        // TD-004 semantics preserved (zero regression after match_bindings
        // moved in): among same-name bindings take the max-cardinality
        // subset match. Build (fn (x) (let x 1 x)):
        // - formal param x: binding scope set = {s1}
        // - let x: binding scope set = {s1, s2} (max-cardinality wins)
        // - body reference to x: reference set = {s1, s2} ⊇ both bindings →
        //   the let binding wins (slot 1)
        let x = Symbol(3);
        let body_let = Rc::new(CoreExpr::Let {
            name: x,
            scopes: scopes_of(&[1, 2]),
            value: lit(1),
            body: var_scoped(3, scopes_of(&[1, 2])),
            span: Span::dummy(),
        });
        let outer = Rc::new(CoreExpr::Fn {
            params: vec![x],
            param_scopes: vec![scopes_of(&[1])],
            rest: None,
            body: body_let,
            span: Span::dummy(),
        });
        let ir = lower_module(&[item_expr(outer)]).expect("lowering failed");
        match ir[0].as_ref() {
            IrExpr::Fn { proto, .. } => match proto.body.as_ref() {
                IrExpr::Let {
                    slot, bind, body, ..
                } => {
                    assert!(*bind);
                    assert_eq!(*slot, 1); // the param takes slot 0, the let binding appends slot 1
                    assert_eq!(var_res(body), IrVar::Local(1)); // max-card
                }
                other => panic!("expected Let, got {:?}", other),
            },
            other => panic!("expected Fn, got {:?}", other),
        }

        // Negative case: the reference set is only {s2} (it does not
        // contain the param's binding domain {s1}) → the param binding does
        // not match, and the let binding {s1,s2} ⊄ {s2} does not match
        // either → Global (name-based fallback)
        let body2 = Rc::new(CoreExpr::Let {
            name: x,
            scopes: scopes_of(&[1, 2]),
            value: lit(1),
            body: var_scoped(3, scopes_of(&[2])),
            span: Span::dummy(),
        });
        let outer2 = Rc::new(CoreExpr::Fn {
            params: vec![x],
            param_scopes: vec![scopes_of(&[1])],
            rest: None,
            body: body2,
            span: Span::dummy(),
        });
        let ir2 = lower_module(&[item_expr(outer2)]).expect("lowering failed");
        match ir2[0].as_ref() {
            IrExpr::Fn { proto, .. } => match proto.body.as_ref() {
                IrExpr::Let { body, .. } => {
                    assert_eq!(var_res(body), IrVar::Global(Symbol(3)));
                }
                other => panic!("expected Let, got {:?}", other),
            },
            other => panic!("expected Fn, got {:?}", other),
        }
    }

    #[test]
    fn ir_define_position_error_preserved() {
        // r49 D59 declaration-layer arm: the define position discipline
        // migrated from a lowering depth check to **structural rejection by
        // the expander** (CoreExpr cannot represent expression-position
        // define — compile-time unrepresentability beats runtime checking,
        // a generalization of 01 §8.1 principle 1). This test re-anchors to
        // the item-level shapes: ① a top-level Define item lowers legally
        // (IrExpr::Define direct translation); ② a Define item inside a
        // nested module item is likewise legal; ③ the rejection surface for
        // expression-position define belongs to the expander (the E0003
        // message is preserved verbatim — message-level assertions are
        // carried by the expander-side expand_define_position_rejected
        // test group).
        let ok = ModuleItem::Define {
            name: Symbol(9),
            value: lit(7),
            span: Span::dummy(),
        };
        let ir = lower_module(&[ok]).expect("top level define item should be legal");
        match ir[0].as_ref() {
            IrExpr::Define { name, .. } => assert_eq!(*name, Symbol(9)),
            other => panic!("expected Define, got {:?}", other),
        }

        // A define inside a nested module item (a module-body item
        // position)
        let nested = ModuleItem::Module {
            name: Symbol(11),
            imports: vec![],
            exports: vec![],
            items: vec![ModuleItem::Define {
                name: Symbol(9),
                value: lit(7),
                span: Span::dummy(),
            }],
            span: Span::dummy(),
        };
        let ir2 = lower_module(&[nested]).expect("define inside a module item should be legal");
        match ir2[0].as_ref() {
            IrExpr::Module { body, .. } => match body[0].as_ref() {
                IrExpr::Define { .. } => {}
                other => panic!("expected nested Define, got {:?}", other),
            },
            other => panic!("expected Module, got {:?}", other),
        }
    }

    #[test]
    fn ir_handle_captures_resolved_for_both_protos() {
        // (let c 1 (handle e ((p r) (fn (z) (c z p))) (c r)))
        // — both H (handler) and B (body thunk) capture c (source = the
        // main local slot 0); H's payload/resume = local slots 0/1
        let c = Symbol(4);
        let handler_body = fn_expr(
            vec![Symbol(6)],
            Rc::new(CoreExpr::Apply {
                fn_expr: var(4),
                args: vec![var(6), var(1)],
                span: Span::dummy(),
            }),
        );
        let handle = Rc::new(CoreExpr::Handle {
            tag: Rc::from("e"),
            payload_var: Symbol(1),
            payload_scopes: ScopeSet::new(),
            resume_var: Symbol(2),
            resume_scopes: ScopeSet::new(),
            handler_body,
            body: Rc::new(CoreExpr::Apply {
                fn_expr: var(4),
                args: vec![var(2)],
                span: Span::dummy(),
            }),
            span: Span::dummy(),
        });
        let whole = let_expr(c, lit(1), handle);
        let ir = lower_module(&[item_expr(whole)]).expect("lowering failed");
        match ir[0].as_ref() {
            IrExpr::Let { body, .. } => match body.as_ref() {
                IrExpr::Handle { handler, thunk, .. } => {
                    // H: payload(1)/resume(2) params + captures c (main
                    // slot 0)
                    assert_eq!(handler.params, vec![Symbol(1), Symbol(2)]);
                    assert_eq!(handler.captures.len(), 1);
                    assert_eq!(handler.captures[0].name, Symbol(4));
                    assert_eq!(handler.captures[0].source, CaptureSource::Local(0));
                    // Inside the handler body (fn z): c → Captured(0)
                    // (frame capture order)
                    match handler.body.as_ref() {
                        IrExpr::Fn { proto, .. } => match proto.body.as_ref() {
                            IrExpr::Apply { fn_expr, args, .. } => {
                                assert_eq!(var_res(fn_expr), IrVar::Captured(0));
                                assert_eq!(var_res(&args[0]), IrVar::Local(0)); // z
                                assert_eq!(var_res(&args[1]), IrVar::Captured(1));
                                // p — the H frame's
                                // capture order: c=0, p=1? — p is an H
                                // formal param; the inner fn's capture
                                // table order follows first occurrence
                            }
                            other => panic!("expected Apply, got {:?}", other),
                        },
                        other => panic!("expected Fn, got {:?}", other),
                    }
                    // B: no params + captures c (main slot 0)
                    assert!(thunk.params.is_empty());
                    assert_eq!(thunk.captures.len(), 1);
                    assert_eq!(thunk.captures[0].source, CaptureSource::Local(0));
                    match thunk.body.as_ref() {
                        IrExpr::Apply { fn_expr, .. } => {
                            assert_eq!(var_res(fn_expr), IrVar::Captured(0));
                        }
                        other => panic!("expected Apply, got {:?}", other),
                    }
                }
                other => panic!("expected Handle, got {:?}", other),
            },
            other => panic!("expected Let, got {:?}", other),
        }
    }
}

//! # kerf-compiler
//!
//! **Five orthogonal axes positioning (lang-design 15 §5.3, v6.0)**: axis 2 (syntax/type)
//! bridge point — typecheck performs standalone inference with no backflow into
//! `CoreExpr` (15 §5.1 Layer 2 orthogonality) + bytecode generation.
//!
//! Direct-translation compilation from CoreExpr to bytecode (stage0.md §8.12 / §19.3).
//!
//! **Compilation skeleton** (§19.3):
//! - Jump backpatching: `emit_jump` emits a placeholder → `patch_jump` backpatches
//!   (`finish` asserts the placeholder queue is drained);
//! - Constant pool: `intern_const` deduplicates by hashing on value (pitfall:
//!   constant pool deduplication);
//! - Closure capture conversion: free variables of Fn are resolved into a capture
//!   vector (LOAD/STORE_CAPTURED);
//! - debug_info_table: (pc, Span) mapping for every instruction — VM errors can be
//!   traced back to source (§8.12).
//!
//! **Core invariants** (§19.3):
//! 1. Stack balance: executing the compiled artifact of any CoreExpr leaves the
//!    operand stack with a net change of exactly +1;
//! 2. Backpatch completeness: when CodeBuf finishes, the placeholder queue must be
//!    empty (asserted);
//! 3. Debug info full coverage: every instruction carries a Span; no bare instructions.
//!
//! **Opcode set** (§8.12, 46 opcodes — frozen after the r30 FFI three-instruction
//! three-way alignment): stack operations / functions / control flow / data
//! construction / variable access / arithmetic and comparison / predicates /
//! effects (r25) / FFI (r30) / termination.

pub mod bytecode;
pub mod compile;
pub mod hm;
pub mod ir;
pub mod opcode;
pub mod typecheck;

// Explicit re-exports (§10.1 rule 4: glob re-exports are forbidden).
// Convention: this crate exposes all public types of the bytecode (Bc*) domain.
pub use bytecode::{
    disassemble_program, BcConst, BcProgram, BcProto, CaptureSource, DebugInfoTable,
};
pub use opcode::Op;

// The compilation entry points (§10.1 rule 1) are exported separately to ease
// path-based imports.
pub use compile::{compile_module, compile_module_with_externs, CompileCtxt, CompileError};

// IndexIR (r48/E5 S3 M-I indexing — resolver-closure layer) public types are
// exported explicitly (§10.1 rule 4: glob re-exports are forbidden).
pub use ir::{lower_module, IrCapture, IrExpr, IrProto, IrVar};

// Static checking domain (Tc prefix — §10.1 domain-prefix convention) public
// types are exported explicitly.
pub use typecheck::{check_program, BuiltinSig, TcParam, TcParams, TcType, CHECK_DIAG_CODE};

// ---------------------------------------------------------------------------
// Space-ownership declaration section (r66 / 123-a — lang-design 24 v2.0 unified
// two-sided system; 24 §7.2 core-side incorporation table: this crate's main types
// get a three-layer explicit impl [root + core space + domain] — core compilation
// domain (verification and compilation — typecheck standalone inference + bytecode
// generation); the core-side edition of "declaration-is-ownership", sole ownership
// criterion = marker impl [24 §3 A7])
// ---------------------------------------------------------------------------
use kerf_space::{CoreCompileDomain, CoreSpace, RootSpace};

impl RootSpace for CompileCtxt {}
impl CoreSpace for CompileCtxt {}
impl CoreCompileDomain for CompileCtxt {}
impl RootSpace for CompileError {}
impl CoreSpace for CompileError {}
impl CoreCompileDomain for CompileError {}
impl RootSpace for Op {}
impl CoreSpace for Op {}
impl CoreCompileDomain for Op {}
impl RootSpace for IrProto {}
impl CoreSpace for IrProto {}
impl CoreCompileDomain for IrProto {}

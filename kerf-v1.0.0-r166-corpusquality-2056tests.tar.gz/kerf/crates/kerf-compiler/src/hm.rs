//! HM type-inference PoC (batch H4 — landing the 38-d design's "constraint
//! three-phase" scheme).
//!
//! **Architecture (D1 three-phase)**:
//! ① Generation: walk each top-level form of CoreExpr → a constraint set
//!    carrying .Span (concrete type errors are diagnosed immediately during
//!    generation — messages aligned with R1-R8 (superset-gate reuse);
//!    variable/structural relations go into the constraint set);
//! ② Solving: worklist unification (numeric-lattice extension + occurs
//!    check) — iterative, zero deep recursion (bootstrap-friendly +
//!    stack-safe); failures are collected one by one (multiple errors —
//!    TD-013 alignment);
//! ③ zonk: free variables → Dynamic; global binding types are output (the
//!    acceptance surface).
//!
//! **Ruling landing index** (hm-inference-design.md §8):
//! - D2 value restriction: generalization is limited to syntactic values
//!   (lambda/literal/variable reference); set! targets and Apply results
//!   stay weakly monomorphic;
//! - D3 set! join: concrete-type lattice merge (Int|Float→Num; mismatched
//!   types→Dynamic — zero false positives); variable targets (letrec
//!   pre-binding) take the unification path on first assignment;
//! - D4 recursive pre-binding: both top-level define and the letrec expanded
//!   form are special-cased — the bound name is pre-bound to a fresh
//!   variable, and self-references in the body unify with it (recursive
//!   arity/domain errors become detectable); lambda-RHS is generalized
//!   after checking completes;
//! - D5 occurs check: mandatory, error-level, rendered on both ends;
//! - D6 two-point generalization: the top-level define sequence + the let
//!   shape (Apply-of-Fn recognition — user-written shapes of the same form
//!   get the same treatment);
//! - D7 diagnostics: E0005 family + constraints carrying Span + form-level
//!   collection buckets (P1-3 isolation) + a generation-time 512 depth
//!   budget (over budget → zero constraints, zero diagnostics —
//!   equivalent to A6);
//! - D8 PoC offline: this module is **NOT wired into** driver
//!   check_source — verification runs in parallel on the test surface
//!   (superset gate + zero-false-positive gate); the flag-era switch is a
//!   separate ruling.
//!
//! **Dynamic discipline** (A4 gradual escape hatch): unbound references /
//! hygiene symbols / builtin value positions → Dynamic atoms — they never
//! enter constraints, are never generalized, and are never reported.
//!
//! **r53/O1-O5 performance evolution (T3+ first optimization window — the
//! t3-optimization-plan.md contract)**: solver data-structure and algorithm
//! optimization with zero semantic change (diagnostic set / globals
//! rendering / fresh allocation order / generalization and occurs decisions
//! bit-identical — proven by five means). **Final form = O1 + O4** (measured
//! incremental-attribution ruling — all negative-yield items removed): O1
//! resolve path-compression write-back (union-find amortization, two-pass —
//! short chains zero overhead, deep chains amortized; HM segment measured
//! 8.5→6.95ms[expander] / 2.5→2.15ms[compiler]); O4 copy_fresh structure
//! sharing (spine-copy minimization — Rc::ptr_eq short-circuit). Removal
//! record (criterion-driven, so later rounds do not repeat it): O2 occurs
//! structure-pointer pruning / O3 free_vars seen HashSet / O5 env_free
//! HashSet — all three measured negative or neutral-to-negative on the real
//! corpus (SipHash overhead > pruning/dedup benefit — low structure sharing +
//! small free sets). Watch item OBS-A closed by criterion (the HM segment
//! is 0.23% of total check time — incremental gain <0.05%, see the baseline
//! attribution correction r53).

use std::collections::HashMap;
use std::rc::Rc;

use kerf_span::{Diagnostic, Span};
use kerf_syntax::{Symbol, SymbolTable};

use kerf_core::ModuleItem;

use crate::typecheck::{BuiltinSig, TcParam, TcParams, CHECK_DIAG_CODE};
use kerf_core::{CoreExpr, LiteralValue};

/// Generation-time depth budget (A6 semantics unchanged: over-budget subtrees
/// produce zero constraints and zero diagnostics).
const MAX_GEN_DEPTH: usize = 512;

/// HM type domain (§3.5: eleven constructors + the Dynamic escape atom).
#[derive(Debug, Clone, PartialEq)]
pub enum Ty {
    /// Type variable (index into the solving table).
    Var(u32),
    Int,
    Float,
    /// Int ∪ Float (numeric-tower lattice — documented deviation: not
    /// textbook unification).
    Num,
    Bool,
    Str,
    Nil,
    Sym,
    /// Pair constructor (element types are inferable).
    Pair(Rc<Ty>, Rc<Ty>),
    /// Function constructor (parameter type sequence + return type; arity
    /// is carried by the sequence length).
    /// r165 / 236-c (variadic-rest-design.md D6): the rest parameter's type
    /// — `Some(list_ty)` when the fn declares `...name: T` (the binding is
    /// the folded pair chain). The call face takes a **minimum** arity
    /// (params.len()) with no upper bound; excess argument types are
    /// unconstrained (no element-type face — the `TcParams::Variadic`
    /// builtin-sig discipline mirrored). `None` = fixed arity (the exact
    /// face, the pre-r165 behavior preserved bit-for-bit).
    Arrow {
        params: Vec<Rc<Ty>>,
        rest: Option<Rc<Ty>>,
        ret: Rc<Ty>,
    },
    /// Escape atom (never enters constraints, never generalized, never
    /// reported).
    Dynamic,
}

impl Ty {
    /// Rendering (for diagnostics and the acceptance assertion surface).
    pub fn render(&self) -> String {
        match self {
            Ty::Var(i) => format!("α{}", i),
            Ty::Int => "int".into(),
            Ty::Float => "float".into(),
            Ty::Num => "num".into(),
            Ty::Bool => "bool".into(),
            Ty::Str => "str".into(),
            Ty::Nil => "nil".into(),
            Ty::Sym => "symbol".into(),
            Ty::Pair(a, b) => format!("({} . {})", a.render(), b.render()),
            Ty::Arrow { params, rest, ret } => {
                let ps: Vec<String> = params.iter().map(|p| p.render()).collect();
                match rest {
                    Some(rt) => {
                        format!("({} ...{} → {})", ps.join(" "), rt.render(), ret.render())
                    }
                    None => format!("({} → {})", ps.join(" "), ret.render()),
                }
            }
            Ty::Dynamic => "dynamic".into(),
        }
    }

    fn is_num_atom(&self) -> bool {
        matches!(self, Ty::Int | Ty::Float | Ty::Num)
    }
}

/// Environment binding shapes (the carrier of the D2 value restriction).
#[derive(Debug, Clone)]
enum Binding {
    /// Weakly monomorphic (set! targets / Apply results / the letrec
    /// pre-binding phase) — all use sites share one instance.
    Mono(Rc<Ty>),
    /// Generalized scheme: variables in `quants` are freshly instantiated
    /// at every reference.
    Poly { quants: Vec<u32>, body: Rc<Ty> },
}

/// Solving state: variable substitution table + pending-constraint worklist +
/// diagnostic collection.
struct SolveState {
    /// Variable → solved type (paths flattened: written back at resolve
    /// time).
    subst: Vec<Option<Rc<Ty>>>,
    /// Pending constraints (accumulated during generation; drained per form
    /// — P1-3 bucket isolation).
    pending: Vec<(Rc<Ty>, Rc<Ty>, Span)>,
}

impl SolveState {
    fn new() -> Self {
        SolveState {
            subst: Vec::new(),
            pending: Vec::new(),
        }
    }

    fn fresh_var(&mut self) -> Rc<Ty> {
        self.subst.push(None);
        let id = self.subst.len() - 1;
        Rc::new(Ty::Var(id as u32))
    }

    /// Resolve (follows the substitution chain; **r53/O1 path-compression
    /// write-back** — union-find amortization: intermediate chain nodes are
    /// all repointed to the root. Transitive-closure semantics unchanged;
    /// the resolve return value is unchanged (it already returned the
    /// root); fresh allocation is unaffected).
    fn resolve(&mut self, t: &Rc<Ty>) -> Rc<Ty> {
        // First pass: find the root (counting depth) — short chains
        // (depth ≤ 1, the vast majority of HM solving scenarios) take the
        // zero-extra-allocation, zero-write-back path
        let mut cur = t.clone();
        let mut depth = 0usize;
        while let Ty::Var(i) = cur.as_ref() {
            if let Some(next) = self.subst[*i as usize].clone() {
                cur = next;
                depth += 1;
            } else {
                break;
            }
        }
        // Second pass: write-back for deep chains (only worthwhile when
        // depth > 1 — a single link already points straight at the root;
        // after compression every future query is O(1) — union-find
        // amortization holds). The pre-r52 implementation did zero
        // compression (self-evident from its comments) — long-chain
        // scenarios cost O(chain length) per query.
        if depth > 1 {
            let root = cur.clone();
            let mut walk = t.clone();
            while let Ty::Var(i) = walk.as_ref() {
                if let Some(next) = self.subst[*i as usize].clone() {
                    self.subst[*i as usize] = Some(root.clone());
                    walk = next;
                } else {
                    break;
                }
            }
        }
        cur
    }

    fn is_free_var(&mut self, t: &Rc<Ty>) -> Option<u32> {
        match self.resolve(t).as_ref() {
            Ty::Var(i) => Some(*i),
            _ => None,
        }
    }

    /// occurs check: does variable i occur in the resolved expansion of t?
    /// r53 record (criterion-driven correction): the O2 first version's
    /// structure-pointer visited pruning measured negative in practice
    /// (pointer-hashing overhead > sharing-pruning benefit — low structure
    /// sharing in the corpus); removed per instrumentation data — keeping
    /// the pure recursive traversal + the amortized chain query after O1
    /// compression.
    fn occurs(&mut self, i: u32, t: &Rc<Ty>) -> bool {
        let r = self.resolve(t);
        match r.as_ref() {
            Ty::Var(j) => *j == i,
            Ty::Pair(a, b) => self.occurs(i, a) || self.occurs(i, b),
            Ty::Arrow { params, rest, ret } => {
                params.iter().any(|p| self.occurs(i, p))
                    || rest.as_ref().is_some_and(|rt| self.occurs(i, rt))
                    || self.occurs(i, ret)
            }
            _ => false,
        }
    }

    /// Bind a variable (occurs already checked).
    fn bind(&mut self, i: u32, t: Rc<Ty>) {
        self.subst[i as usize] = Some(t);
    }

    /// Unification (numeric-lattice extension — the D1/§3.5 documented
    /// deviation). Returns a diagnostic message on failure.
    fn unify(&mut self, a: &Rc<Ty>, b: &Rc<Ty>) -> Result<(), String> {
        let ra = self.resolve(a);
        let rb = self.resolve(b);
        use Ty::*;
        match (ra.as_ref(), rb.as_ref()) {
            // Escape-atom absorption (defensive — generation already keeps
            // Dynamic out of constraints)
            (Dynamic, _) | (_, Dynamic) => Ok(()),
            // Numeric lattice: Int/Float/Num match one another (union-domain
            // semantics)
            (x, y) if x.is_num_atom() && y.is_num_atom() => Ok(()),
            (Var(i), Var(j)) => {
                if i == j {
                    Ok(())
                } else {
                    self.bind(*i, rb.clone());
                    Ok(())
                }
            }
            (Var(i), t) => {
                if self.occurs(*i, &rb) {
                    return Err(format!(
                        "cannot construct an infinite type: α{} and {}(static check)",
                        i,
                        rb.render()
                    ));
                }
                let t = Rc::new(t.clone());
                self.bind(*i, t);
                Ok(())
            }
            (t, Var(i)) => {
                // Symmetric case: bind i := ra (occurs checked first)
                if self.occurs(*i, &ra) {
                    return Err(format!(
                        "cannot construct an infinite type: α{} and {}(static check)",
                        i,
                        ra.render()
                    ));
                }
                let t = Rc::new(t.clone());
                self.bind(*i, t);
                Ok(())
            }
            (Pair(a1, a2), Pair(b1, b2)) => {
                self.unify(a1, b1)?;
                self.unify(a2, b2)
            }
            (
                Arrow {
                    params: ps1,
                    rest: rs1,
                    ret: r1,
                },
                Arrow {
                    params: ps2,
                    rest: rs2,
                    ret: r2,
                },
            ) => {
                // r165 / 236-c (D6): fixed×fixed keeps the exact face
                // bit-for-bit; any rest involvement switches to the
                // min-prefix compatibility face (the longer fixed prefix
                // covers the shorter's minimum; excess positions are
                // unconstrained — no element-type face, the variadic
                // builtin-sig discipline). Rest×rest unify as the folded
                // list types.
                if rs1.is_none() && rs2.is_none() {
                    if ps1.len() != ps2.len() {
                        return Err(format!(
                            "procedure argument count mismatch: expected {}, got {} (static check)",
                            ps1.len(),
                            ps2.len()
                        ));
                    }
                    for (p1, p2) in ps1.iter().zip(ps2.iter()) {
                        self.unify(p1, p2)?;
                    }
                } else {
                    // rest involvement — the min-prefix compatibility face:
                    // a fixed(L) arrow vs a rest(k) arrow requires L ≥ k
                    // (the fixed fn must cover the variadic's minimum);
                    // rest×rest mins never conflict. Pairwise unification
                    // covers the common fixed prefix; the excess positions
                    // are unconstrained (no element-type face).
                    let gate_fail = match (rs1.is_some(), rs2.is_some()) {
                        (false, true) => ps1.len() < ps2.len(),
                        (true, false) => ps2.len() < ps1.len(),
                        _ => false,
                    };
                    if gate_fail {
                        let (want, got) = if ps1.len() < ps2.len() {
                            (ps2.len(), ps1.len())
                        } else {
                            (ps1.len(), ps2.len())
                        };
                        return Err(format!(
                            "procedure argument count mismatch: expected at least {}, got {} (static check)",
                            want, got
                        ));
                    }
                    let n = ps1.len().min(ps2.len());
                    for i in 0..n {
                        self.unify(&ps1[i], &ps2[i])?;
                    }
                    if let (Some(ra), Some(rb)) = (rs1, rs2) {
                        self.unify(ra, rb)?;
                    }
                }
                self.unify(r1, r2)
            }
            (x, y) if x == y => Ok(()),
            (x, y) => Err(format!(
                "type mismatch: {} and {}(static check)",
                x.render(),
                y.render()
            )),
        }
    }

    /// Drain the constraint worklist (failures collected one by one —
    /// multiple errors; solving continues in the degraded state).
    fn drain(&mut self, diags: &mut Vec<Diagnostic>) {
        while let Some((a, b, span)) = self.pending.pop() {
            if let Err(msg) = self.unify(&a, &b) {
                diags.push(Diagnostic::error(Some(CHECK_DIAG_CODE), msg, span));
            }
        }
    }
}

/// HM check report (PoC acceptance surface: diagnostics + final types of
/// global bindings).
pub struct HmReport {
    /// Diagnostics (E0005 family; ordered by (file_id, start, end) —
    /// isomorphic to check_program).
    pub diags: Vec<Diagnostic>,
    /// Zonked final types of top-level defines (acceptance assertion
    /// surface: fib : (num → num)).
    pub globals: HashMap<Symbol, Rc<Ty>>,
}

/// HM check entry point (**flag-era decision surface — D8 stage 2,
/// r29/50-a wired into the driver** via the `check_source` /
/// `check_source_recover` entries; in the PoC phase (r18) it was offline
/// parallel verification, and from the flag era on it is the production
/// decision surface of `kerf check` — R1-R8 (typecheck.rs
/// `check_program`) recede to test-surface regression baseline assertions).
/// Contract wording (flag era): **zero type-mismatch false positives**; the
/// occurs/self-application surface is policy-accepted behavior (explicitly
/// registered in hm-inference-design §2.3 — P0-2 honored).
pub fn hm_check_program(
    items: &[ModuleItem],
    builtins: &HashMap<Symbol, BuiltinSig>,
    table: &SymbolTable,
) -> HmReport {
    let mut gen = Gen {
        builtins,
        table,
        env: HashMap::new(),
        st: SolveState::new(),
        diags: Vec::new(),
    };
    for item in items {
        gen.infer_item(item, 0);
        // Form-level bucket drain (P1-3 isolation: failures do not pollute
        // cross-form solving)
        gen.st.drain(&mut gen.diags);
    }
    // zonk + report (r53/O1 borrow separation: iterating env cannot
    // coexist with the mutable borrow of st — collect the entries first,
    // then resolve them one by one)
    let entries: Vec<(Symbol, Rc<Ty>)> = gen
        .env
        .iter()
        .map(|(sym, b)| {
            let t = match b {
                Binding::Mono(t) => t.clone(),
                Binding::Poly { body, .. } => body.clone(),
            };
            (*sym, t)
        })
        .collect();
    let mut globals = HashMap::new();
    for (sym, t) in entries {
        let r = gen.st.resolve(&t);
        globals.insert(sym, zonk(&mut gen.st, &r));
    }
    gen.diags.sort_by_key(|d| {
        (
            d.primary_span.file_id,
            d.primary_span.start,
            d.primary_span.end,
        )
    });
    HmReport {
        diags: gen.diags,
        globals,
    }
}

/// Free-variable collection (the generalization surface). r53 record
/// (criterion-driven): the seen-HashSet first version measured negative in
/// practice (free sets are small — a few-ns Vec linear scan beats SipHash
/// lookups); removed per incremental attribution data — keeping the
/// original Vec form (first-encounter-first-collected order unchanged).
fn free_vars(st: &mut SolveState, t: &Rc<Ty>, out: &mut Vec<u32>) {
    let r = st.resolve(t);
    match r.as_ref() {
        Ty::Var(i) => {
            if !out.contains(i) {
                out.push(*i);
            }
        }
        Ty::Pair(a, b) => {
            free_vars(st, a, out);
            free_vars(st, b, out);
        }
        Ty::Arrow { params, rest, ret } => {
            for p in params {
                free_vars(st, p, out);
            }
            if let Some(rt) = rest {
                free_vars(st, rt, out);
            }
            free_vars(st, ret, out);
        }
        // `_` arm rationale: closed types (Con/Int/Bool/Str/Nil etc.)
        // contain no variables — there are no free variables to collect
        _ => {}
    }
}

/// Type copy (instantiation: the quants → fresh mapping). r53/O4 structure
/// sharing: when all subterms are pointer-equal → return the original node
/// (spine-copy minimization — closed subtrees of a generic function body
/// are shared across instantiations; the fresh allocation order is
/// unchanged — driven by the quants order, and instantiation results are
/// bit-identical to the old implementation).
fn copy_fresh(st: &mut SolveState, t: &Rc<Ty>, map: &mut HashMap<u32, Rc<Ty>>) -> Rc<Ty> {
    let r = st.resolve(t);
    match r.as_ref() {
        Ty::Var(i) => match map.get(i) {
            Some(v) => v.clone(),
            None => r.clone(),
        },
        Ty::Pair(a, b) => {
            let na = copy_fresh(st, a, map);
            let nb = copy_fresh(st, b, map);
            if Rc::ptr_eq(&na, a) && Rc::ptr_eq(&nb, b) {
                r.clone()
            } else {
                Rc::new(Ty::Pair(na, nb))
            }
        }
        Ty::Arrow { params, rest, ret } => {
            let ps: Vec<Rc<Ty>> = params.iter().map(|p| copy_fresh(st, p, map)).collect();
            let nr = copy_fresh(st, ret, map);
            let nrest = rest.as_ref().map(|rt| copy_fresh(st, rt, map));
            let shared = ps.iter().zip(params.iter()).all(|(n, o)| Rc::ptr_eq(n, o))
                && Rc::ptr_eq(&nr, ret)
                && match (rest.as_ref(), nrest.as_ref()) {
                    (Some(a), Some(b)) => Rc::ptr_eq(a, b),
                    (None, None) => true,
                    _ => false,
                };
            if shared {
                r.clone()
            } else {
                Rc::new(Ty::Arrow {
                    params: ps,
                    rest: nrest,
                    ret: nr,
                })
            }
        }
        _ => r.clone(),
    }
}

/// zonk: free variables → Dynamic (the acceptance rendering surface).
/// r53/O1 resolve propagates &mut.
fn zonk(st: &mut SolveState, t: &Rc<Ty>) -> Rc<Ty> {
    let r = st.resolve(t);
    match r.as_ref() {
        Ty::Var(_) => Rc::new(Ty::Dynamic),
        Ty::Pair(a, b) => Rc::new(Ty::Pair(zonk(st, a), zonk(st, b))),
        Ty::Arrow { params, rest, ret } => Rc::new(Ty::Arrow {
            params: params.iter().map(|p| zonk(st, p)).collect(),
            rest: rest.as_ref().map(|rt| zonk(st, rt)),
            ret: zonk(st, ret),
        }),
        _ => r.clone(),
    }
}

/// Syntactic-value predicate (D2 value restriction).
fn is_syntactic_value(e: &CoreExpr) -> bool {
    matches!(
        e,
        CoreExpr::Literal { .. } | CoreExpr::Fn { .. } | CoreExpr::Var { .. }
    )
}

/// Concrete-type lattice join (D3 set! join / If branch merging —
/// conservative contract).
fn lattice_join(st: &mut SolveState, a: &Rc<Ty>, b: &Rc<Ty>) -> Rc<Ty> {
    let ra = st.resolve(a);
    let rb = st.resolve(b);
    match (ra.as_ref(), rb.as_ref()) {
        (Ty::Dynamic, _) | (_, Ty::Dynamic) => Rc::new(Ty::Dynamic),
        (x, y) if x.is_num_atom() && y.is_num_atom() => Rc::new(Ty::Num),
        (x, y) if x == y => ra,
        // Concrete mismatched types → Dynamic (conservative demotion — one
        // of two choices at runtime, not narrowed statically)
        _ => Rc::new(Ty::Dynamic),
    }
}

/// Generator (phase ①: traversal + constraints / immediate diagnostics).
struct Gen<'a> {
    builtins: &'a HashMap<Symbol, BuiltinSig>,
    table: &'a SymbolTable,
    env: HashMap<Symbol, Binding>,
    st: SolveState,
    diags: Vec<Diagnostic>,
}

impl<'a> Gen<'a> {
    fn diag(&mut self, msg: String, span: Span) {
        self.diags
            .push(Diagnostic::error(Some(CHECK_DIAG_CODE), msg, span));
    }

    fn fresh(&mut self) -> Rc<Ty> {
        self.st.fresh_var()
    }

    fn op_name(&self, sym: &Symbol) -> String {
        self.table.name(*sym).to_string()
    }

    fn constraint(&mut self, a: Rc<Ty>, b: Rc<Ty>, span: Span) {
        self.st.pending.push((a, b, span));
    }

    /// Drain pending constraints before a generalization point (an
    /// evaluation-order obligation): generalization must see solved types —
    /// otherwise the types of pre-bound variables / application results are
    /// still sitting in the worklist, and quants wrongly captures free
    /// variables.
    fn solve_now(&mut self) {
        let mut diags = std::mem::take(&mut self.diags);
        self.st.drain(&mut diags);
        self.diags = diags;
    }

    fn instantiate(&mut self, b: &Binding) -> Rc<Ty> {
        match b {
            Binding::Mono(t) => t.clone(),
            Binding::Poly { quants, body } => {
                let mut map: HashMap<u32, Rc<Ty>> = HashMap::new();
                for q in quants {
                    map.insert(*q, self.fresh());
                }
                copy_fresh(&mut self.st, body, &mut map)
            }
        }
    }

    /// The environment's free-variable set (the non-quantified boundary of
    /// generalization). `exclude` = the binding name currently being
    /// replaced by generalization (self-pollution guard: the replaced
    /// entry's free variables do not count toward the environment boundary
    /// — otherwise define/letrec pre-bound variables would leave quants
    /// forever empty and generalization would never happen).
    fn env_free_vars(&mut self, exclude: Option<Symbol>) -> Vec<u32> {
        let mut out = Vec::new();
        for (sym, b) in &self.env {
            if Some(*sym) == exclude {
                continue;
            }
            match b {
                Binding::Mono(t) => free_vars(&mut self.st, t, &mut out),
                Binding::Poly { body, .. } => free_vars(&mut self.st, body, &mut out),
            }
        }
        out
    }

    /// Generalization (the value restriction was already decided by the
    /// caller): quants = free(τ) − free(env). r53 attribution experiment:
    /// the O1-only form (original algorithm + &mut propagation).
    fn generalize(&mut self, t: &Rc<Ty>, exclude: Option<Symbol>) -> Binding {
        let mut free = Vec::new();
        free_vars(&mut self.st, t, &mut free);
        let env_free = self.env_free_vars(exclude);
        let quants: Vec<u32> = free.into_iter().filter(|v| !env_free.contains(v)).collect();
        if quants.is_empty() {
            Binding::Mono(t.clone())
        } else {
            Binding::Poly {
                quants,
                body: t.clone(),
            }
        }
    }

    /// Item-level inference (r49 D59 — program/module body items: the Define
    /// sequence takes effect [D6 ① generalization point]; Require carries
    /// zero inference payload; Module bodies recurse; expression items go
    /// through `infer_expr`).
    fn infer_item(&mut self, item: &ModuleItem, depth: usize) {
        if depth > MAX_GEN_DEPTH {
            return;
        }
        match item {
            ModuleItem::Define { name, value, span } => {
                // D4 recursive pre-binding: the bound name gets a fresh
                // variable (self-references in the body unify with it)
                let alpha = self.fresh();
                self.env.insert(*name, Binding::Mono(alpha.clone()));
                let ty = self.infer_expr(value, depth + 1);
                // Unify the pre-bound variable with the RHS type (the
                // unified letrec/recursion mechanism)
                self.constraint(alpha.clone(), ty, *span);
                // Solve before the generalization point (the pre-bound
                // variable's actual type must have flowed in)
                self.solve_now();
                // D6 ① + D2 value restriction: only syntactic values are
                // generalized
                let binding = if is_syntactic_value(value) {
                    let ra = self.st.resolve(&alpha);
                    self.generalize(&ra, Some(*name))
                } else {
                    Binding::Mono(alpha.clone())
                };
                self.env.insert(*name, binding);
            }
            // require has zero runtime semantics — zero inference payload
            // (01 §6 declaration surface)
            ModuleItem::Require { .. } => {}
            ModuleItem::Module { items, .. } => {
                for inner in items {
                    self.infer_item(inner, depth + 1);
                }
            }
            ModuleItem::Expr(e) => {
                self.infer_expr(e, depth + 1);
            }
        }
    }

    /// Expression inference (returns the type; concrete errors are diagnosed
    /// immediately — R1-R8 message-surface reuse).
    fn infer_expr(&mut self, e: &Rc<CoreExpr>, depth: usize) -> Rc<Ty> {
        if depth > MAX_GEN_DEPTH {
            return Rc::new(Ty::Dynamic);
        }
        match e.as_ref() {
            CoreExpr::Literal { value, .. } => Rc::new(literal_ty(value)),
            CoreExpr::Var { name, .. } => {
                let hit = self.env.get(name).cloned();
                match hit {
                    Some(b) => self.instantiate(&b),
                    // builtin value positions (not application heads) and
                    // unbound references → Dynamic (conservative — A4
                    // discipline: no constraints, no generalization, no reports)
                    None => Rc::new(Ty::Dynamic),
                }
            }
            CoreExpr::Fn {
                params, rest, body, ..
            } => {
                // Formal parameters get fresh variables (Mono) + body
                // inference → Arrow. The rest binding is a fresh variable
                // like the fixed formals — its type is inferred from body
                // usage (is-pair/head/tail constrain it to the pair-chain
                // domain; r165 / 236-c D6-a).
                let mut param_tys = Vec::with_capacity(params.len());
                for p in params {
                    let alpha = self.fresh();
                    param_tys.push(alpha.clone());
                    let old = self.env.insert(*p, Binding::Mono(alpha));
                    let _ = old;
                }
                let rest_ty = rest.as_ref().map(|(r, _)| {
                    let beta = self.fresh();
                    let old = self.env.insert(*r, Binding::Mono(beta.clone()));
                    let _ = old;
                    beta
                });
                let ret = self.infer_expr(body, depth + 1);
                for p in params {
                    self.env.remove(p);
                }
                if let Some((r, _)) = rest {
                    self.env.remove(r);
                }
                Rc::new(Ty::Arrow {
                    params: param_tys,
                    rest: rest_ty,
                    ret,
                })
            }
            CoreExpr::Apply { fn_expr, args, .. } => self.infer_app(fn_expr, args, e, depth + 1),
            CoreExpr::If {
                cond,
                then_branch,
                else_branch,
                ..
            } => {
                // R1 surface reuse: a concrete non-bool condition is
                // diagnosed immediately; a variable is pinned to Bool via a
                // constraint
                let tc = self.infer_expr(cond, depth + 1);
                let rc = self.st.resolve(&tc);
                match rc.as_ref() {
                    Ty::Bool | Ty::Dynamic | Ty::Var(_) => {
                        if matches!(rc.as_ref(), Ty::Var(_)) {
                            self.constraint(tc.clone(), Rc::new(Ty::Bool), cond.span());
                        }
                    }
                    other => {
                        self.diag(
                            format!(
                                "if condition requires bool, got {}(static check)",
                                other.render()
                            ),
                            cond.span(),
                        );
                    }
                }
                let tt = self.infer_expr(then_branch, depth + 1);
                let te = self.infer_expr(else_branch, depth + 1);
                // Branch merging: both branches concrete → lattice join
                // (conservative — D3/A3); a variable involved → constraint
                // unification (the HM value-add surface: branch type
                // consistency)
                let rt = self.st.resolve(&tt);
                let re = self.st.resolve(&te);
                match (rt.as_ref(), re.as_ref()) {
                    (Ty::Var(_), _) | (_, Ty::Var(_)) => {
                        self.constraint(tt.clone(), te, then_branch.span());
                        tt
                    }
                    _ => lattice_join(&mut self.st, &tt, &te),
                }
            }
            CoreExpr::Assign { name, value, .. } => {
                // D3 set!: a variable target (letrec/recursion pre-binding)
                // → unification (the D4 unified mechanism); a concrete
                // target → lattice join (conservative contract — zero false
                // positives on the assignment surface); a Poly target →
                // weak monomorphization (D2 — set! targets are never
                // generalized)
                let tv = self.infer_expr(value, depth + 1);
                match self.env.get(name).cloned() {
                    Some(b) => {
                        let target = match &b {
                            Binding::Mono(t) => Some(t.clone()),
                            Binding::Poly { .. } => None,
                        };
                        match target {
                            Some(t) if self.st.is_free_var(&t).is_some() => {
                                self.constraint(t, tv, e.span());
                            }
                            Some(t) => {
                                let joined = lattice_join(&mut self.st, &t, &tv);
                                self.env.insert(*name, Binding::Mono(joined));
                            }
                            None => {
                                // set! on a Poly target: weak
                                // monomorphization (keep the current value
                                // type)
                                self.env.insert(*name, Binding::Mono(tv));
                            }
                        }
                    }
                    None => {
                        // Unbound set!: runtime E3's responsibility
                        // (conservatively zero diagnostics — A4)
                    }
                }
                Rc::new(Ty::Dynamic)
            }
            CoreExpr::Let {
                name, value, body, ..
            } => {
                // r45/E5 S3 structural arm (22 §14 D42/D43): the Let chain
                // carries the original Do sequence + let's true-binding dual
                // semantics (compiler discard/bind under the same criterion).
                //
                // ① discard mode (body does not reference name — the fixed
                //   name "do" produced by do desugaring always lands here):
                //   value constraints happen and the type is discarded
                //   (sequence-item semantics); the chain recurses (r49: after
                //   item-position do-splice, in-chain defines are no longer
                //   representable — the original value-position define arm
                //   is retired);
                // ② bind mode (the HM let rule — same shape as D6
                //   infer_let's single binding): RHS inference → solve
                //   before the generalization point → syntactic-value
                //   generalization → binding → body inference → restore.
                let referenced = body
                    .free_var_occurrence_list()
                    .iter()
                    .any(|(s, _)| *s == *name);
                if !referenced {
                    let _ = self.infer_expr(value, depth + 1);
                    return self.infer_expr(body, depth + 1);
                }
                let tv = self.infer_expr(value, depth);
                // Solve before the generalization point (internal RHS
                // constraints must already be resolved — same wording as
                // infer_let)
                self.solve_now();
                let binding = if is_syntactic_value(value) {
                    let rt = self.st.resolve(&tv);
                    self.generalize(&rt, Some(*name))
                } else {
                    Binding::Mono(tv)
                };
                let old = self.env.insert(*name, binding);
                let result = self.infer_expr(body, depth);
                match old {
                    Some(b) => {
                        self.env.insert(*name, b);
                    }
                    None => {
                        self.env.remove(name);
                    }
                }
                result
            }
            // r28/48-b effect-arm convergence (plan §5b — subexpression
            // traversal with the same wording as typecheck.rs; violations
            // inside the PoC domain are detected): Perform effect values /
            // Handle bodies and handler bodies enter inference (R1-R8
            // message-surface reuse + constraint-set checking); result types
            // stay Dynamic (effect-language-design risk table: "interaction
            // with HM inference's effect rows = P3/Stage 3" — no tightening,
            // no false positives)
            CoreExpr::Perform { effect, .. } => {
                self.infer_expr(effect, depth + 1);
                Rc::new(Ty::Dynamic)
            }
            // Handle binder binding (same shape as infer_let's
            // save/restore — mirrored discipline): payload = the dynamic
            // value injected by dispatch → Dynamic; resume = the
            // continuation call shape (D4 desugars it into Apply at
            // expansion time — a Dynamic Apply head is conservatively
            // silent, same origin as the A4 discipline) → Dynamic
            CoreExpr::Handle {
                payload_var,
                resume_var,
                handler_body,
                body,
                ..
            } => {
                let mut saved: Vec<(Symbol, Option<Binding>)> = Vec::with_capacity(2);
                for p in [payload_var, resume_var] {
                    saved.push((*p, self.env.insert(*p, Binding::Mono(Rc::new(Ty::Dynamic)))));
                }
                self.infer_expr(handler_body, depth + 1);
                self.infer_expr(body, depth + 1);
                for (p, old) in saved {
                    match old {
                        Some(b) => {
                            self.env.insert(p, b);
                        }
                        None => {
                            self.env.remove(&p);
                        }
                    }
                }
                Rc::new(Ty::Dynamic)
            }
            // r136 / 206-b (D16): per-arm binder binding — each arm's two
            // binders enter Dynamic independently around its own handler
            // body (sibling scopes; the protected body infers outside them).
            // Result stays Dynamic (the effect face: zero tightening, zero
            // false positives — the A4 discipline maintained)
            CoreExpr::HandleGroup { arms, body, .. } => {
                let mut all_saved: Vec<(Symbol, Option<Binding>)> =
                    Vec::with_capacity(arms.len() * 2);
                for arm in arms {
                    for p in [arm.payload_var, arm.resume_var] {
                        all_saved
                            .push((p, self.env.insert(p, Binding::Mono(Rc::new(Ty::Dynamic)))));
                    }
                    self.infer_expr(&arm.handler_body, depth + 1);
                }
                for (p, old) in all_saved {
                    match old {
                        Some(b) => {
                            self.env.insert(p, b);
                        }
                        None => {
                            self.env.remove(&p);
                        }
                    }
                }
                self.infer_expr(body, depth + 1);
                Rc::new(Ty::Dynamic)
            }
        }
    }

    fn infer_app(
        &mut self,
        fn_expr: &Rc<CoreExpr>,
        args: &[Rc<CoreExpr>],
        app: &Rc<CoreExpr>,
        depth: usize,
    ) -> Rc<Ty> {
        // ---- letrec shape recognition (D4·r45 form: Apply[Fn, nil] +
        // Fn body = a Let discard chain led by an Assign group) ----
        // sugar.rs desugar_letrec r45 direct-translation reality:
        // ((fn (f...) ...) nil...) is no longer produced — it maps
        // directly to a Let[f, nil] pre-binding chain + a
        // Let[_, (assign f e)] sequence chain + the tail body. Recognition
        // covers both shapes: ① the r45 direct-translation chain (Fn body =
        // a Let chain led by Assigns) ② user-written equivalent
        // combinations (Fn body = a same-shaped chain).
        if let CoreExpr::Fn {
            params, rest, body, ..
        } = fn_expr.as_ref()
        {
            // r165 / 236-c: the letrec fast path is fixed-arity only — a
            // rest fn's folded binding has no Assign-formal representation,
            // so it takes the generic application path (the Fn arm binds
            // the rest variable correctly there).
            if rest.is_none() {
                // Chain collection: each Let-chain node's value = an
                // Assign{formal-param} group; the tail is the real body
                let mut leading_sets: Vec<(Symbol, Rc<CoreExpr>)> = Vec::new();
                let mut all_params = true;
                let mut cur = body.as_ref();
                // while-let chain collection (clippy same-shape suggestion);
                // scan-window termination: stop at the first non-Assign leading
                // form — letrec leading set!-sequence probing only covers the
                // consecutive head
                while let CoreExpr::Let {
                    value, body: rest, ..
                } = cur
                {
                    match value.as_ref() {
                        CoreExpr::Assign {
                            name, value: rhs, ..
                        } => {
                            if params.contains(name) {
                                leading_sets.push((*name, Rc::clone(rhs)));
                            } else {
                                all_params = false;
                            }
                        }
                        _ => break,
                    }
                    cur = rest.as_ref();
                }
                if all_params && !leading_sets.is_empty() && leading_sets.len() == params.len() {
                    return self.infer_letrec(params, &leading_sets, &Rc::new(cur.clone()), depth);
                }
            }
        }
        // ---- let shape (D6 ②) retired (r50-β / D61) ----
        // Recognition of the same-arity Apply[Fn, args] let shape is
        // retired along with direct let translation: sugar output no longer
        // produces this shape (the desugar_let App[Fn] sugar view is
        // retired — go straight to the CoreExpr::Let bind/discard dual-mode
        // arms); user-written combinations `((fn (x) b) e)` take the generic
        // application path (SML canon: no generalization at application
        // positions — expansive positions are not generalized; pending
        // constraints are not solved early). One mechanism surface fixed by
        // TD-030: infer_let's per-binding solve_now() early solving turned
        // symmetric pending constraints into one-way bindings (α₂ := (α₃ .
        // α₄)), and subsequent define unification in that asymmetric state
        // triggered occurs false positives (proven by both the for-each
        // let-discard and hand-written combinations); after retirement,
        // neither path solves early anymore.
        // ---- generic application ----
        let arg_tys: Vec<Rc<Ty>> = args.iter().map(|a| self.infer_expr(a, depth)).collect();
        // builtin fast path: application head = Var and not shadowed by
        // env
        if let CoreExpr::Var { name, .. } = fn_expr.as_ref() {
            if !self.env.contains_key(name) {
                if let Some(sig) = self.builtins.get(name) {
                    return self.infer_builtin_call(name, sig, args, &arg_tys, app, depth);
                }
            }
        }
        let tf = self.infer_expr(fn_expr, depth);
        // R6 surface reuse: a callee that is concretely non-Arrow is
        // diagnosed immediately
        let rf = self.st.resolve(&tf);
        match rf.as_ref() {
            Ty::Dynamic | Ty::Var(_) | Ty::Arrow { .. } => {}
            other => {
                self.diag(
                    format!("uncallable value: {}(static check)", other.render()),
                    fn_expr.span(),
                );
                return Rc::new(Ty::Dynamic);
            }
        }
        // R7 surface reuse: a concrete Arrow arity mismatch is diagnosed
        // immediately. r165 / 236-c (D6-b): the rest face — minimum arity,
        // no upper bound; excess argument types are unconstrained.
        if let Ty::Arrow { params, rest, .. } = rf.as_ref() {
            let bad = match rest {
                Some(_) => args.len() < params.len(),
                None => params.len() != args.len(),
            };
            if bad {
                let expected = match rest {
                    Some(_) => format!("at least {}", params.len()),
                    None => format!("{}", params.len()),
                };
                self.diag(
                    format!(
                        "procedure argument count mismatch: expected {}, got {} (static check)",
                        expected,
                        args.len()
                    ),
                    app.span(),
                );
                return Rc::new(Ty::Dynamic);
            }
        }
        let ret = self.fresh();
        self.constraint(
            tf,
            Rc::new(Ty::Arrow {
                params: arg_tys,
                rest: None,
                ret: ret.clone(),
            }),
            app.span(),
        );
        ret
    }

    /// letrec shape (D4·r45 chain form): pre-binding → RHS unification →
    /// lambda-RHS generalization → tail body.
    fn infer_letrec(
        &mut self,
        params: &[Symbol],
        sets: &[(Symbol, Rc<CoreExpr>)],
        tail_body: &Rc<CoreExpr>,
        depth: usize,
    ) -> Rc<Ty> {
        let mut saved: Vec<(Symbol, Option<Binding>)> = Vec::with_capacity(params.len());
        // Pre-bind fresh variables (all parameters — visible for mutual
        // recursion)
        for p in params {
            let alpha = self.fresh();
            saved.push((*p, self.env.insert(*p, Binding::Mono(alpha))));
        }
        // RHS checking (recursive self-references see the pre-bound
        // variables) → unification
        let mut rhs_are_values = true;
        for (name, rhs) in sets {
            let tv = self.infer_expr(rhs, depth);
            if !is_syntactic_value(rhs) {
                rhs_are_values = false;
            }
            if let Some(Binding::Mono(t)) = self.env.get(name).cloned() {
                self.constraint(t, tv, rhs.span());
            }
        }
        // lambda-RHS generalization (SML letrec-of-lambda style — done
        // before body checking; solve before the generalization point — the
        // unification constraints must have flowed into the pre-bound
        // variables)
        if rhs_are_values {
            self.solve_now();
            for (name, _) in sets {
                if let Some(Binding::Mono(t)) = self.env.get(name).cloned() {
                    let rt = self.st.resolve(&t);
                    let binding = self.generalize(&rt, Some(*name));
                    self.env.insert(*name, binding);
                }
            }
        }
        // Tail body (the real body after the leading set! sequence chain —
        // pre-binding / unification / generalization are all done; the
        // Assign sequence nodes' constraints already fired during pre-bound
        // unification [RHS one-to-one correspondence], and the discard
        // chain nodes' types are discarded)
        let last = self.infer_expr(tail_body, depth + 1);
        for (p, old) in saved {
            match old {
                Some(b) => {
                    self.env.insert(p, b);
                }
                None => {
                    self.env.remove(&p);
                }
            }
        }
        last
    }

    /// builtin call (signature-table data untouched, interpretation layer
    /// swapped — §3.5).
    fn infer_builtin_call(
        &mut self,
        name: &Symbol,
        sig: &BuiltinSig,
        args: &[Rc<CoreExpr>],
        arg_tys: &[Rc<Ty>],
        app: &Rc<CoreExpr>,
        _depth: usize,
    ) -> Rc<Ty> {
        let op = self.op_name(name);
        // R7 surface reuse: an out-of-range arity is diagnosed immediately
        let n = args.len();
        if n < sig.min_args || sig.max_args.is_some_and(|m| n > m) {
            let want = match sig.max_args {
                Some(m) => format!("{}..{}", sig.min_args, m),
                None => format!("≥{}", sig.min_args),
            };
            self.diag(
                format!(
                    "procedure argument count mismatch: expected {}, got {} (static check)",
                    want, n
                ),
                app.span(),
            );
            return Rc::new(Ty::Dynamic);
        }
        // Name-driven structural reinterpretation (§3.5 Pair row — the
        // cons/car/cdr trio)
        match op.as_str() {
            "cons" if n == 2 => {
                return Rc::new(Ty::Pair(arg_tys[0].clone(), arg_tys[1].clone()));
            }
            "head" if n == 1 => {
                let a = self.fresh();
                let b = self.fresh();
                let arg = arg_tys[0].clone();
                let ra = self.st.resolve(&arg);
                match ra.as_ref() {
                    Ty::Pair(x, _) => return x.clone(),
                    Ty::Dynamic | Ty::Var(_) => {
                        if matches!(ra.as_ref(), Ty::Var(_)) {
                            self.constraint(arg, Rc::new(Ty::Pair(a.clone(), b)), args[0].span());
                        }
                        // Dynamic: genuinely unknown — conservatively no
                        // diagnostic; Var: solved via constraint propagation
                        // (flag-era r29/50-a: Nil moved out of this arm — a
                        // superset-gate gap fix, (head nil) is statically
                        // certain to hit runtime E5, aligned with the R1-R8
                        // R5 negative-case matrix)
                        return Rc::new(Ty::Dynamic);
                    }
                    other => {
                        self.diag(
                            format!("head requires pair, got {}(static check)", other.render()),
                            args[0].span(),
                        );
                        return Rc::new(Ty::Dynamic);
                    }
                }
            }
            "tail" if n == 1 => {
                let b = self.fresh();
                let arg = arg_tys[0].clone();
                let ra = self.st.resolve(&arg);
                match ra.as_ref() {
                    Ty::Pair(_, y) => return y.clone(),
                    Ty::Dynamic | Ty::Var(_) => {
                        if matches!(ra.as_ref(), Ty::Var(_)) {
                            let a = self.fresh();
                            self.constraint(arg, Rc::new(Ty::Pair(a, b)), args[0].span());
                        }
                        // Same as the head arm: Dynamic is genuinely
                        // unknown and conservative; Nil is diagnosed via the
                        // other arm (same shape as the flag-era r29/50-a
                        // superset-gate gap fix)
                        return Rc::new(Ty::Dynamic);
                    }
                    other => {
                        self.diag(
                            format!("tail requires pair, got {}(static check)", other.render()),
                            args[0].span(),
                        );
                        return Rc::new(Ty::Dynamic);
                    }
                }
            }
            // `_` arm rationale: other builtin names / arity mismatches —
            // not the specialized inference surface; they fall through to
            // the uniform handling by the parameter rules below (sig.params)
            // (the fast-path diagnostic does not apply here)
            _ => {}
        }
        // Parameter rules (concrete fast-path violations diagnosed
        // immediately — R2/R3/R4/R5/R8 message-surface reuse; variables →
        // constraints)
        match &sig.params {
            TcParams::Variadic(rule) => {
                for (a, t) in args.iter().zip(arg_tys) {
                    self.check_param_rule(&op, *rule, t, a);
                }
            }
            TcParams::Fixed(rules) => {
                for ((a, t), rule) in args.iter().zip(arg_tys).zip(rules.iter()) {
                    self.check_param_rule(&op, *rule, t, a);
                }
            }
            TcParams::NumOrAllStr => {
                // R3 `=` family: all numbers or all strings. Variable
                // parameters are constrained via concrete anchors (a
                // numeric anchor → ~Num; a string anchor with no numbers →
                // ~Str); all variables with no anchor → conservatively
                // skipped (the gradual escape hatch); concrete wrong types
                // are diagnosed immediately.
                let resolved: Vec<Rc<Ty>> = arg_tys.iter().map(|t| self.st.resolve(t)).collect();
                let all_str =
                    !resolved.is_empty() && resolved.iter().all(|t| matches!(t.as_ref(), Ty::Str));
                if all_str {
                    return Rc::new(Ty::Bool);
                }
                let has_str = resolved.iter().any(|t| matches!(t.as_ref(), Ty::Str));
                let has_num = resolved.iter().any(|t| t.is_num_atom());
                for (a, t) in args.iter().zip(arg_tys) {
                    let rt = self.st.resolve(t);
                    match rt.as_ref() {
                        Ty::Dynamic => {}
                        Ty::Var(_) => {
                            let domain = if has_num {
                                Some(Ty::Num)
                            } else if has_str {
                                Some(Ty::Str)
                            } else {
                                None
                            };
                            if let Some(d) = domain {
                                self.constraint(rt.clone(), Rc::new(d), a.span());
                            }
                        }
                        Ty::Int | Ty::Float | Ty::Num => {}
                        other => {
                            self.diag(
                                format!(
                                    "{} requires a number, got {}(static check)",
                                    op,
                                    other.render()
                                ),
                                a.span(),
                            );
                        }
                    }
                }
            }
            TcParams::Ordering => {
                // R3 ordering family: all strings → legal (TD-011 r24:
                // strings join the whole family under total order —
                // codepoint order; flag-era r29/50-a sync: the PoC wording
                // "strings only support =" is outdated, typecheck.rs
                // L452-503 was synced earlier); mixing in strings →
                // numbers required (TD-016 all-operands wording); variable
                // parameters are constrained via the numeric anchor (~Num —
                // the runtime ordering domain is all numbers).
                let resolved: Vec<Rc<Ty>> = arg_tys.iter().map(|t| self.st.resolve(t)).collect();
                let all_str =
                    !resolved.is_empty() && resolved.iter().all(|t| matches!(t.as_ref(), Ty::Str));
                if all_str {
                    return Rc::new(Ty::Bool);
                }
                let has_num = resolved.iter().any(|t| t.is_num_atom());
                for (a, t) in args.iter().zip(arg_tys) {
                    let rt = self.st.resolve(t);
                    match rt.as_ref() {
                        Ty::Dynamic => {}
                        Ty::Var(_) => {
                            if has_num {
                                self.constraint(rt.clone(), Rc::new(Ty::Num), a.span());
                            }
                        }
                        Ty::Int | Ty::Float | Ty::Num => {}
                        other => {
                            self.diag(
                                format!(
                                    "{} requires a number, got {}(static check)",
                                    op,
                                    other.render()
                                ),
                                a.span(),
                            );
                        }
                    }
                }
            }
        }
        // Result-type mapping (Unknown → fresh; numeric-family results
        // normalized within the lattice)
        match sig.result {
            crate::typecheck::TcType::Unknown => self.fresh(),
            crate::typecheck::TcType::Int => Rc::new(Ty::Int),
            crate::typecheck::TcType::Float => Rc::new(Ty::Float),
            crate::typecheck::TcType::Num => Rc::new(Ty::Num),
            crate::typecheck::TcType::Bool => Rc::new(Ty::Bool),
            crate::typecheck::TcType::Str => Rc::new(Ty::Str),
            crate::typecheck::TcType::Nil => Rc::new(Ty::Nil),
            crate::typecheck::TcType::Symbol => Rc::new(Ty::Sym),
            // Pair/Callable result types go through the structural path
            // (cons/car/cdr) or Dynamic
            crate::typecheck::TcType::Pair | crate::typecheck::TcType::Callable { .. } => {
                Rc::new(Ty::Dynamic)
            }
        }
    }

    /// Parameter rule (generation time: concrete errors diagnosed
    /// immediately; variables / in-domain → constraints).
    fn check_param_rule(&mut self, op: &str, rule: TcParam, ty: &Rc<Ty>, arg: &Rc<CoreExpr>) {
        let rt = self.st.resolve(ty);
        if matches!(rt.as_ref(), Ty::Dynamic) {
            return;
        }
        if let Ty::Var(_) = rt.as_ref() {
            // Variable → domain constraint (Int/Float/Num absorbed by
            // in-domain lattice unification)
            let domain = match rule {
                TcParam::Num | TcParam::Int => Some(Ty::Num),
                TcParam::Bool => Some(Ty::Bool),
                TcParam::Str => Some(Ty::Str),
                TcParam::Symbol => Some(Ty::Sym),
                TcParam::Pair => None, // Pair goes through the cons/car/cdr structural path
                _ => None,
            };
            if let Some(d) = domain {
                self.constraint(rt.clone(), Rc::new(d), arg.span());
            }
            return;
        }
        let ok = match rule {
            TcParam::Any => true,
            TcParam::Num => rt.is_num_atom(),
            TcParam::Int => matches!(rt.as_ref(), Ty::Int),
            TcParam::Bool => matches!(rt.as_ref(), Ty::Bool),
            TcParam::Str => matches!(rt.as_ref(), Ty::Str),
            TcParam::Symbol => matches!(rt.as_ref(), Ty::Sym),
            TcParam::Pair => matches!(rt.as_ref(), Ty::Pair(_, _)),
            TcParam::List => matches!(rt.as_ref(), Ty::Pair(_, _) | Ty::Nil),
        };
        if !ok {
            let want = match rule {
                TcParam::Num => "number",
                TcParam::Int => "int",
                TcParam::Bool => "bool",
                TcParam::Str => "str",
                TcParam::Symbol => "symbol",
                TcParam::Pair => "pair",
                TcParam::List => "list",
                TcParam::Any => unreachable!("Any already short-circuit"),
            };
            let msg = if rule == TcParam::Num {
                format!(
                    "{} requires a number, got {}(static check)",
                    op,
                    rt.render()
                )
            } else {
                format!(
                    "{} requires {}, got {}(static check)",
                    op,
                    want,
                    rt.render()
                )
            };
            self.diag(msg, arg.span());
        }
    }
}

/// Literal type (quote pair structuring — Pair(τ, τ) recursion).
fn literal_ty(v: &LiteralValue) -> Ty {
    match v {
        LiteralValue::Int(_) => Ty::Int,
        LiteralValue::Float(_) => Ty::Float,
        LiteralValue::Str(_) => Ty::Str,
        LiteralValue::Bool(_) => Ty::Bool,
        LiteralValue::Nil => Ty::Nil,
        LiteralValue::Symbol(_) => Ty::Sym,
        LiteralValue::Pair(a, b) => Ty::Pair(Rc::new(literal_ty(a)), Rc::new(literal_ty(b))),
    }
}

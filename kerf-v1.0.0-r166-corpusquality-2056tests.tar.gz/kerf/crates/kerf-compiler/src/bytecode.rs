//! Bytecode program structure (§8.12 + §10.1 Bc prefix rule).
//!
//! **VM state comprises** (§8.12): code (protos), data stack, call stack, global
//! environment, constant pool, and debug info table (this crate defines the code
//! side; runtime-side state lives in kerf-vm).
//!
//! **DebugInfoTable** (§8.12 / principle 17: generated at compile time, queried at
//! runtime): (pc, Span) mapping for every instruction, no bare instructions
//! (§19.3 invariant 3).

use std::collections::HashMap;
use std::rc::Rc;

use kerf_span::Span;
use kerf_syntax::Symbol;

use crate::opcode::Op;

/// Constant pool entry (intern_const deduplicates by value — §19.3 pitfall:
/// constant pool deduplication).
///
/// `Eq`/`Hash` are implemented by hand: Float compares bit-wise (NaN is normalized
/// to a canonical bit pattern) — the established engineering treatment for f64
/// not satisfying the native Eq/Hash constraints.
#[derive(Debug, Clone, PartialEq)]
pub enum BcConst {
    Int(i64),
    Float(f64),
    Str(Rc<str>),
    Bool(bool),
    Nil,
    /// Symbol (global variable name resolved by name: operand of LOAD_GLOBAL/STORE_GLOBAL).
    Symbol(Symbol),
    /// Symbol literal value (constant pool form of a quoted symbol datum — TD-002;
    /// strictly distinguished from the global-name index semantics of the `Symbol`
    /// variant, §11 interface isolation).
    SymLit(Rc<str>),
}

impl Eq for BcConst {}

impl std::hash::Hash for BcConst {
    fn hash<H: std::hash::Hasher>(&self, state: &mut H) {
        std::mem::discriminant(self).hash(state);
        match self {
            BcConst::Int(v) => v.hash(state),
            BcConst::Float(v) => float_key(*v).hash(state),
            BcConst::Str(s) => s.hash(state),
            BcConst::Bool(b) => b.hash(state),
            BcConst::Nil => {}
            BcConst::Symbol(s) => s.hash(state),
            BcConst::SymLit(s) => s.hash(state),
        }
    }
}

/// Float key (normalizes +0.0/-0.0 and NaN).
fn float_key(f: f64) -> u64 {
    if f == 0.0 {
        0u64
    } else if f.is_nan() {
        0x7ff8_0000_0000_0000u64
    } else {
        f.to_bits()
    }
}

/// Closure capture source (capture description resolved at compile time —
/// companion data of the CLOSURE instruction).
///
/// Semantics: captures a **shared cell** (`Rc<RefCell<Value>>`) — the mutable
/// capture semantics of lexical closures (set! propagates through the shared cell,
/// letrec recursion holds).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CaptureSource {
    /// Local slot of an enclosing frame (shares that slot's cell).
    Local(u32),
    /// Captured slot of an enclosing closure (shared transitively).
    Captured(u32),
}

/// Prototype (subroutine): parameters + local slot layout + capture name table + code + debug info.
#[derive(Debug, Clone, PartialEq)]
pub struct BcProto {
    /// Prototype name (for diagnostics/stack traces).
    pub name: Symbol,
    /// Parameter symbols (local slots 0..n).
    pub params: Vec<Symbol>,
    /// r165 / 236-c (variadic-rest-design.md D2-d): the rest parameter's
    /// local slot — `Some(params.len())` when the source fn declares
    /// `...name: T` (the frame-setup path folds the excess arguments into a
    /// nil-terminated pair chain bound at this slot; the arity face becomes
    /// min-arity = `params.len()` with no upper bound). `None` = fixed
    /// arity (the pre-r165 shape).
    pub rest_slot: Option<u32>,
    /// Number of local slots (parameters + let bindings).
    pub n_locals: u32,
    /// Capture name table (closure capture slots 0..m — aligned with the CLOSURE
    /// instruction's capture order).
    pub capture_names: Vec<Symbol>,
    /// Capture source descriptions (aligned with capture_names — the VM shares
    /// enclosing cells accordingly).
    pub capture_sources: Vec<CaptureSource>,
    /// Instruction sequence.
    pub code: Vec<Op>,
    /// Debug info table: Span aligned with code per pc (no bare instructions,
    /// §19.3 invariant 3).
    pub debug_spans: Vec<Span>,
    /// Free variable set (union of captures and global references, for toolchain/
    /// CodeValue checks).
    pub free_vars: Vec<Symbol>,
}

impl BcProto {
    /// Number of parameters.
    ///
    /// r165 / 236-c: for rest prototypes this is the **minimum** arity (the
    /// fixed prefix); the call face accepts any count at or above it.
    pub fn arity(&self) -> u32 {
        self.params.len() as u32
    }

    /// Number of instructions.
    pub fn len(&self) -> usize {
        self.code.len()
    }

    /// Whether this is an empty prototype.
    pub fn is_empty(&self) -> bool {
        self.code.is_empty()
    }
}

/// A complete bytecode program.
#[derive(Debug, Clone, PartialEq)]
pub struct BcProgram {
    /// Prototype table (proto 0 = main entry).
    pub protos: Vec<BcProto>,
    /// Constant pool (deduplicated).
    pub consts: Vec<BcConst>,
    /// Entry prototype index (fixed at 0; resolved at Stage 2 multi-module link time).
    pub entry: u32,
    /// All global names referenced by the program (including builtins — validated
    /// at driver registration).
    pub global_refs: Vec<Symbol>,
    /// Module metadata (Stage 0: single module).
    pub module_name: Option<Symbol>,
}

impl BcProgram {
    /// Entry prototype.
    pub fn entry_proto(&self) -> &BcProto {
        &self.protos[self.entry as usize]
    }

    /// Number of prototypes.
    pub fn proto_count(&self) -> usize {
        self.protos.len()
    }

    /// Total instruction count (summed over all prototypes — code-volume metric
    /// for performance benchmarks).
    pub fn total_instructions(&self) -> usize {
        self.protos.iter().map(|p| p.len()).sum()
    }

    /// Compares against another program opcode by opcode (parity tests: two
    /// compilations must produce identical output, §21.3).
    pub fn bytecode_equal(&self, other: &BcProgram) -> bool {
        self == other
    }
}

/// Debug info table type alias (held per prototype; this alias preserves the
/// §8.12 terminology mapping).
pub type DebugInfoTable = Vec<Span>;

/// Disassembly rendering (human-perceivable output is a first-class citizen,
/// §2.2 principle 16).
pub fn disassemble_program(program: &BcProgram, resolve: &dyn Fn(Symbol) -> String) -> String {
    let mut out = String::new();
    out.push_str(&format!(
        "== kerf bytecode: {} protos, {} consts, {} globals ==\n",
        program.protos.len(),
        program.consts.len(),
        program.global_refs.len()
    ));
    for (pi, proto) in program.protos.iter().enumerate() {
        out.push_str(&format!(
            "\nproto {} {}  params=[{}] locals={} captures=[{}]\n",
            pi,
            resolve(proto.name),
            proto
                .params
                .iter()
                .map(|p| resolve(*p))
                .collect::<Vec<_>>()
                .join(" "),
            proto.n_locals,
            proto
                .capture_names
                .iter()
                .map(|c| resolve(*c))
                .collect::<Vec<_>>()
                .join(" ")
        ));
        for (pc, op) in proto.code.iter().enumerate() {
            let span = proto.debug_spans.get(pc).copied().unwrap_or_default();
            out.push_str(&format!(
                "  {:4} {:<14}{}        ; span {}..{}\n",
                pc,
                op.name(),
                op.render_operands(),
                span.start,
                span.end
            ));
        }
    }
    out
}

/// Constant pool deduplication table (compiler-internal).
pub(crate) struct ConstPool {
    consts: Vec<BcConst>,
    index: HashMap<BcConst, u32>,
}

impl ConstPool {
    pub fn new() -> Self {
        ConstPool {
            consts: Vec::new(),
            index: HashMap::new(),
        }
    }

    /// Value-based deduplicating intern (§19.3: constant pool deduplication —
    /// `(begin 1 1 1)` does not blow up).
    pub fn intern(&mut self, c: BcConst) -> u32 {
        if let Some(&i) = self.index.get(&c) {
            return i;
        }
        let i = self.consts.len() as u32;
        self.consts.push(c.clone());
        self.index.insert(c, i);
        i
    }

    /// Extracts the constant pool.
    pub fn finish(self) -> Vec<BcConst> {
        self.consts
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn const_pool_dedups() {
        let mut pool = ConstPool::new();
        let a = pool.intern(BcConst::Int(1));
        let b = pool.intern(BcConst::Int(1));
        let c = pool.intern(BcConst::Int(2));
        assert_eq!(a, b);
        assert_ne!(a, c);
        assert_eq!(pool.finish().len(), 2);
    }

    #[test]
    fn disassemble_renders() {
        let proto = BcProto {
            name: Symbol(0),
            params: vec![Symbol(1)],
            rest_slot: None,
            n_locals: 1,
            capture_names: vec![],
            capture_sources: vec![],
            code: vec![Op::LoadLocal(0), Op::PushConst(0), Op::Add, Op::Ret],
            debug_spans: vec![
                Span::new(0, 0, 4),
                Span::new(0, 5, 6),
                Span::new(0, 0, 9),
                Span::new(0, 0, 9),
            ],
            free_vars: vec![],
        };
        let program = BcProgram {
            protos: vec![proto],
            consts: vec![BcConst::Int(1)],
            entry: 0,
            global_refs: vec![],
            module_name: None,
        };
        let text = disassemble_program(&program, &|s| format!("s{}", s.0));
        assert!(text.contains("LOAD_LOCAL"));
        assert!(text.contains("PUSH_CONST"));
        assert!(text.contains("RET"));
        assert!(text.contains("ADD"));
        assert_eq!(program.total_instructions(), 4);
    }
}

//! Symbol interning: u32 handles for identifiers and the global symbol table.
//!
//! Design (§19.1 implementation pitfall 2): NFC normalization is done exactly once,
//! at intern time; otherwise the same visual identifier would produce two Symbols.
//!
//! `Symbol` satisfies Copy + Ord + Hash — it can be passed around as a HashMap key
//! and a comparison handle.

use std::collections::HashMap;
use std::rc::Rc;

/// Interned identifier handle (an index into the table). Handles are comparable
/// and hashable.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct Symbol(pub u32);

impl Symbol {
    /// Resolves to a string slice (the symbol table is the single source of truth;
    /// a missing table entry is an explicit error).
    pub fn as_str(self, table: &SymbolTable) -> &str {
        table.name(self)
    }
}

/// Keywords of core forms and syntactic sugar (§10.1 rule 2: the Reader classifies
/// by table lookup — zero semantics at the lexical layer).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Keyword {
    Fn,
    If,
    Assign,
    Define,
    Do,
    Module,
    Import,
    Export,
    Quote,
    Let,
    LetRec,
    LetStar,
    Cond,
    Else,
    And,
    Or,
    When,
    While,
    Unless,
    DefineSyntax,
    SyntaxRules,
    Require,
    /// `perform` (r25/42-f — the effect-perform core primitive, one of the two
    /// D1 surface-syntax forms).
    Perform,
    /// `handle` (the effect-handle core primitive — shallow handling, D2).
    Handle,
    /// `resume` (the surface keyword for invoking a continuation — desugars to the
    /// Apply `(κ v)`, D4; not a standalone primitive).
    Resume,
    /// `match` (r122 / 192-a — match implementation batch M-2: the pattern-matching
    /// skin keyword, the D2 skin-dictionary seventh mapping head. Dispatches to the
    /// expansion-time cond/let desugar (match-design.md v1.1 §3) — a pure skin over
    /// existing core forms: zero new primitives, zero new channels, the compiled
    /// product is always If/Let/Apply of existing builtins (principle 31). Already in
    /// the 22 finalized word face (match-design §2 — zero new word-face additions),
    /// so the E0020 strict-reserved binding ban extends to `match` on both faces.)
    Match,
    /// `handle-group` (r136 / 206-b — TD-033 group install, handle-multi-arm-design
    /// §8 D12): the S-expr-face group-install core form head
    /// `(handle-group (tag (p k) result)+ body)` — multi-arm shallow handling with
    /// symmetric non-protection between sibling arm bodies (the Koka-style reading
    /// of 06 §10 [HANDLE-INSTALL]). Compiled to the INSTALL_HANDLER_GROUP
    /// instruction (#46 — four-way sync). Same reserved-word family treatment as
    /// `handle` (the E0020 shared domain).
    HandleGroup,
    /// `extern` (r137 / 207-c — TD-026 language-surface window,
    /// ffi-language-surface-design.md §2/D8): the FFI extern declaration family
    /// head — `(extern name (kind...) kind)` / `extern name(kinds) -> kind;` —
    /// a top-level declaration consumed entirely by the driver's face collector
    /// (D2: stripped before expansion — the expander never sees it; zero new
    /// CoreExpr/ModuleItem variants). Call sites resolve through the flat extern
    /// symbol space (resolution-layer `IrVar::Extern`, D4) and compile to the
    /// frozen CALL_EXTERNAL instruction (#43 — four-way sync since r30). The
    /// E0020 strict-reserved binding ban extends to `extern` on both faces
    /// (the 28th keyword).
    Extern,
}

impl Keyword {
    /// All keywords (the single enum face — 22 §13 D36 in-enum consistency:
    /// variant names = the same word root as the literal names; pre-interning and
    /// the roundtrip assertions share this single source).
    pub const ALL: [Keyword; 28] = [
        Keyword::Fn,
        Keyword::If,
        Keyword::Assign,
        Keyword::Define,
        Keyword::Do,
        Keyword::Module,
        Keyword::Import,
        Keyword::Export,
        Keyword::Quote,
        Keyword::Let,
        Keyword::LetRec,
        Keyword::LetStar,
        Keyword::Cond,
        Keyword::Else,
        Keyword::And,
        Keyword::Or,
        Keyword::When,
        Keyword::While,
        Keyword::Unless,
        Keyword::DefineSyntax,
        Keyword::SyntaxRules,
        Keyword::Require,
        Keyword::Perform,
        Keyword::Handle,
        Keyword::Resume,
        Keyword::Match,
        Keyword::HandleGroup,
        Keyword::Extern,
    ];

    /// The keyword's source text.
    pub fn as_str(self) -> &'static str {
        match self {
            Keyword::Fn => "fn",
            Keyword::If => "if",
            Keyword::Assign => "assign",
            Keyword::Define => "define",
            Keyword::Do => "do",
            Keyword::Module => "module",
            Keyword::Import => "import",
            Keyword::Export => "export",
            Keyword::Quote => "quote",
            Keyword::Let => "let",
            Keyword::LetRec => "letrec",
            Keyword::LetStar => "let*",
            Keyword::Cond => "cond",
            Keyword::Else => "else",
            Keyword::And => "and",
            Keyword::Or => "or",
            Keyword::When => "when",
            Keyword::While => "while",
            Keyword::Unless => "unless",
            Keyword::DefineSyntax => "define-syntax",
            Keyword::SyntaxRules => "syntax-rules",
            Keyword::Require => "require",
            Keyword::Perform => "perform",
            Keyword::Handle => "handle",
            Keyword::Resume => "resume",
            Keyword::Match => "match",
            Keyword::HandleGroup => "handle-group",
            Keyword::Extern => "extern",
        }
    }

    /// Table-lookup classification (pure table lookup, no semantic judgment,
    /// §19.1 invariant 3).
    pub fn from_name(name: &str) -> Option<Keyword> {
        Some(match name {
            "fn" => Keyword::Fn,
            "if" => Keyword::If,
            "assign" => Keyword::Assign,
            "define" => Keyword::Define,
            "do" => Keyword::Do,
            "module" => Keyword::Module,
            "import" => Keyword::Import,
            "export" => Keyword::Export,
            "quote" => Keyword::Quote,
            "let" => Keyword::Let,
            "letrec" => Keyword::LetRec,
            "let*" => Keyword::LetStar,
            "cond" => Keyword::Cond,
            "else" => Keyword::Else,
            "and" => Keyword::And,
            "or" => Keyword::Or,
            "when" => Keyword::When,
            "while" => Keyword::While,
            "unless" => Keyword::Unless,
            "define-syntax" => Keyword::DefineSyntax,
            "syntax-rules" => Keyword::SyntaxRules,
            "require" => Keyword::Require,
            "perform" => Keyword::Perform,
            "handle" => Keyword::Handle,
            "resume" => Keyword::Resume,
            "match" => Keyword::Match,
            "handle-group" => Keyword::HandleGroup,
            "extern" => Keyword::Extern,
            _ => return None,
        })
    }
}

/// Symbol table: the single source of truth for Symbol → name.
///
/// Keywords are pre-interned at construction (`keyword_symbol` queries are an
/// O(1) table lookup). Clone: compilation-cache reuse (Stage 1 batch C — a cache
/// hit returns a snapshot of the table; ID consistency is guaranteed by intern
/// idempotence: same name → same Symbol).
#[derive(Debug, Default, Clone)]
pub struct SymbolTable {
    names: Vec<Rc<str>>,
    map: HashMap<Rc<str>, Symbol>,
    keywords: HashMap<Keyword, Symbol>,
}

impl SymbolTable {
    pub fn new() -> Self {
        let mut table = SymbolTable {
            names: Vec::new(),
            map: HashMap::new(),
            keywords: HashMap::new(),
        };
        // Pre-intern all keywords (exactly once, §19.1 pitfall 2 — the single
        // source `Keyword::ALL`; completeness stays in sync with the enum).
        for kw in Keyword::ALL {
            let sym = table.intern(kw.as_str());
            table.keywords.insert(kw, sym);
        }
        table
    }

    /// Interns (with one-time NFC normalization).
    pub fn intern(&mut self, name: &str) -> Symbol {
        let normalized: Rc<str> = if is_nfc(name) {
            Rc::from(name)
        } else {
            Rc::from(normalize_nfc(name))
        };
        if let Some(&sym) = self.map.get(&normalized) {
            return sym;
        }
        let sym = Symbol(self.names.len() as u32);
        self.names.push(normalized.clone());
        self.map.insert(normalized, sym);
        sym
    }

    /// The keyword's Symbol (a pre-interned handle).
    pub fn keyword_symbol(&self, kw: Keyword) -> Symbol {
        self.keywords[&kw]
    }

    /// Whether the Symbol is the given keyword.
    pub fn is_keyword(&self, sym: Symbol, kw: Keyword) -> bool {
        self.keywords.get(&kw) == Some(&sym)
    }

    /// Resolves the name (an out-of-bounds index means a broken internal
    /// invariant — panic directly; the data source is written exclusively by this
    /// table).
    pub fn name(&self, sym: Symbol) -> &str {
        &self.names[sym.0 as usize]
    }

    /// Total number of symbols in the table.
    pub fn len(&self) -> usize {
        self.names.len()
    }

    /// Whether the table is empty.
    pub fn is_empty(&self) -> bool {
        self.names.is_empty()
    }
}

/// NFC check (an ASCII fast path + a conservative implementation checking for
/// common combining characters).
///
/// A full Unicode NFC check needs a normalization library; under the Stage 0
/// zero-dependency constraint we take a conservative strategy: inputs containing
/// any combining character (U+0300..U+036F etc.) go through the normalization
/// path, the rest are treated as already normalized. Combining characters are
/// reduced using the common "base character + combining character → precomposed
/// character" mapping.
fn is_nfc(s: &str) -> bool {
    !s.chars().any(is_combining_mark)
}

fn is_combining_mark(c: char) -> bool {
    matches!(c, '\u{0300}'..='\u{036F}' | '\u{1AB0}'..='\u{1AFF}' | '\u{20D0}'..='\u{20FF}')
}

/// Minimal NFC normalization: base character + following accent combination →
/// precomposed character (the pragmatic implementation of stage0.md pitfall 2).
fn normalize_nfc(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    for c in s.chars() {
        if is_combining_mark(c) {
            if let Some(base) = out.chars().last() {
                if let Some(pre) = compose_mark(base, c) {
                    out.pop();
                    out.push(pre);
                    continue;
                }
            }
            out.push(c);
        } else {
            out.push(c);
        }
    }
    out
}

/// Base character + accent combination → precomposed character (covers the common
/// Latin-1 set; returns `None` when there is no mapping).
fn compose_mark(base: char, mark: char) -> Option<char> {
    match (base, mark) {
        ('A', '\u{0300}') => Some('À'),
        ('A', '\u{0301}') => Some('Á'),
        ('A', '\u{0302}') => Some('Â'),
        ('E', '\u{0301}') => Some('É'),
        ('e', '\u{0301}') => Some('é'),
        ('a', '\u{0300}') => Some('à'),
        ('a', '\u{0301}') => Some('á'),
        ('u', '\u{0308}') => Some('ü'),
        ('u', '\u{0301}') => Some('ú'),
        ('n', '\u{0303}') => Some('ñ'),
        ('N', '\u{0303}') => Some('Ñ'),
        ('c', '\u{0327}') => Some('ç'),
        ('C', '\u{0327}') => Some('Ç'),
        _ => None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn intern_is_idempotent() {
        let mut t = SymbolTable::new();
        let a = t.intern("fib");
        let b = t.intern("fib");
        assert_eq!(a, b);
        let c = t.intern("other");
        assert_ne!(a, c);
        assert_eq!(t.name(a), "fib");
    }

    #[test]
    fn keywords_prefetched() {
        let mut t = SymbolTable::new();
        let sym = t.intern("fn");
        assert_eq!(t.keyword_symbol(Keyword::Fn), sym);
        assert!(t.is_keyword(sym, Keyword::Fn));
        assert!(!t.is_keyword(sym, Keyword::If));
    }

    #[test]
    fn nfc_normalization_one_time() {
        let mut t = SymbolTable::new();
        // "e" + U+0301 (combining acute) → "é"
        let a = t.intern("e\u{0301}");
        let b = t.intern("\u{00E9}");
        assert_eq!(
            a, b,
            "composed forms and pre-composed forms must internalize to the same Symbol"
        );
        assert_eq!(t.name(a), "\u{00E9}");
    }

    #[test]
    fn keyword_roundtrip() {
        for kw in [
            Keyword::Fn,
            Keyword::Assign,
            Keyword::Do,
            Keyword::DefineSyntax,
            Keyword::SyntaxRules,
        ] {
            assert_eq!(Keyword::from_name(kw.as_str()), Some(kw));
        }
        assert_eq!(Keyword::from_name("not-a-keyword"), None);
    }

    #[test]
    fn keyword_all_roundtrip_and_distinct() {
        // 22 §13 D36 enum consistency: all 28 ALL names round-trip in full
        // (variant ↦ literal name ↦ identical variant) + literal names are pairwise
        // distinct (the premise of E0020 global exclusivity) + ALL and the E0020
        // binding-ban surface share the same count anchor (26 → 27 — the r122 M-2
        // match addition kept 26; the r136 / 206-b TD-033 addition: handle-group
        // joins the shared reserved domain — handle-multi-arm-design.md §8 D12;
        // the r137 / 207-c TD-026 addition: `extern` joins as the 28th —
        // ffi-language-surface-design.md §8 D8, the declaration-family head).
        let mut names: Vec<&'static str> = Keyword::ALL.iter().map(|k| k.as_str()).collect();
        let total = names.len();
        names.sort_unstable();
        names.dedup();
        assert_eq!(
            total, 28,
            "keyword count anchor (E0020 strict reserved words 28 -- r137/207-c TD-026 extern entry face)"
        );
        assert_eq!(
            names.len(),
            total,
            "keyword literal names are pairwise disjoint"
        );
        for kw in Keyword::ALL {
            assert_eq!(
                Keyword::from_name(kw.as_str()),
                Some(kw),
                "roundtrip({})",
                kw.as_str()
            );
        }
    }
}

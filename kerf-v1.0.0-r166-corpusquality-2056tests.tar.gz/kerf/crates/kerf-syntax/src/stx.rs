//! Syntax object `Stx` (SyntaxObject): the Reader's output and the Expander's input
//! (stage0.md §3.3).
//!
//! Structure:
//! ```text
//! type stx_obj = {
//!   expr   : stx_expr;        // StxDatum in this file
//!   span   : span;            // source position — mandatory field, never empty (§3.3)
//!   scopes : scope_set;       // scope set
//!   phase  : int;             // owning phase (§3.3)
//! }
//! ```

use std::rc::Rc;

use kerf_span::Span;

use crate::scope::ScopeSet;
use crate::symbol::Symbol;
use crate::Phase;

/// Syntax literal (produced by the Reader; the minimal data unit matchable by macro patterns).
#[derive(Debug, Clone, PartialEq)]
pub enum StxLiteral {
    Int(i64),
    Float(f64),
    Str(Rc<str>),
    Bool(bool),
    Nil,
}

impl StxLiteral {
    /// Datum-style rendering (datum printing).
    pub fn render(&self) -> String {
        match self {
            StxLiteral::Int(i) => i.to_string(),
            StxLiteral::Float(f) => {
                if f.fract() == 0.0 && f.is_finite() {
                    format!("{:.1}", f)
                } else {
                    f.to_string()
                }
            }
            StxLiteral::Str(s) => format!("{:?}", s),
            StxLiteral::Bool(b) => b.to_string(),
            StxLiteral::Nil => "nil".to_string(),
        }
    }
}

/// Syntax data (datum): symbol / literal / list / vector.
///
/// **Rc sharing (TD-007 / batch H2)**: list/vector children are carried as
/// `Rc<Vec<Stx>>` — `Clone` becomes an O(1) shallow copy (subtree sharing), lifting
/// the clone/drop recursion constraint of the old value-semantics deep tree
/// (measured: on an 8 MiB main thread, 4_000 passed / 5_000 overflowed → after
/// Rc-ification the expansion chain runs 10_000 at constant stack depth).
/// Structural equality (`PartialEq`) semantics are unchanged (`Rc<Vec>` compares
/// by content — element-wise equivalent to the old behavior).
#[derive(Debug, Clone, PartialEq)]
pub enum StxDatum {
    /// An identifier occurrence.
    Symbol(Symbol),
    /// A literal occurrence.
    Literal(StxLiteral),
    /// Parenthesized list (the carrier of core forms). Rc-shared (see the type note).
    List(Rc<Vec<Stx>>),
    /// Bracketed vector (syntactic-sugar data; in Stage 0 used mainly for let binder
    /// groups and macro literal groups). Rc-shared (as above).
    Vector(Rc<Vec<Stx>>),
}

impl StxDatum {
    /// Whether this is symbol data.
    pub fn as_symbol(&self) -> Option<Symbol> {
        match self {
            StxDatum::Symbol(s) => Some(*s),
            _ => None,
        }
    }

    /// Whether this is list data.
    pub fn as_list(&self) -> Option<&[Stx]> {
        match self {
            StxDatum::List(items) => Some(items),
            _ => None,
        }
    }

    /// The list's head symbol (core-form head determination).
    pub fn list_head_symbol(&self) -> Option<Symbol> {
        self.as_list()
            .and_then(|items| items.first())
            .and_then(|stx| stx.datum.as_symbol())
    }
}

/// Syntax object: datum + Span + ScopeSet + Phase (all §3.3 fields).
///
/// **Structural equality**: a hand-written `PartialEq` — compares only the four
/// semantic fields datum/span/scopes/phase; `uniform_tag` (an internal performance
/// marker, see the field note) does not participate.
#[derive(Debug, Clone)]
pub struct Stx {
    pub datum: StxDatum,
    /// Source position — mandatory field (§3.3: never empty; guaranteed by the Reader).
    pub span: Span,
    /// Scope set (the foundation of hygienic macros).
    pub scopes: ScopeSet,
    /// Owning phase (Runtime when produced by the Reader; ExpandTime for macro output, §8.9).
    pub phase: Phase,
    /// **Uniform-scope tag (internal performance field, TD-007/H2)**: `Some(T)`
    /// iff this node and all descendants have `scopes == T` (set when rebuilt by
    /// `retag_scopes` — for its O(1) sharing fast path). External construction
    /// always sets `None`; `add_scope_to_all` clears it on injection (uniformity
    /// broken). Does not participate in structural equality or any semantic decision.
    pub uniform_tag: Option<ScopeSet>,
}

impl PartialEq for Stx {
    fn eq(&self, other: &Self) -> bool {
        self.datum == other.datum
            && self.span == other.span
            && self.scopes == other.scopes
            && self.phase == other.phase
    }
}
impl Eq for Stx {}

impl Stx {
    /// Constructs a symbol syntax object.
    pub fn symbol(sym: Symbol, span: Span, scopes: ScopeSet) -> Self {
        Stx {
            datum: StxDatum::Symbol(sym),
            span,
            scopes,
            phase: Phase::Runtime,
            uniform_tag: None,
        }
    }

    /// Constructs a list syntax object (the Span is merged and provided by the caller).
    /// Children are carried Rc-shared.
    pub fn list(items: Vec<Stx>, span: Span, scopes: ScopeSet) -> Self {
        Stx {
            datum: StxDatum::List(Rc::new(items)),
            span,
            scopes,
            phase: Phase::Runtime,
            uniform_tag: None,
        }
    }

    /// Constructs a literal syntax object.
    pub fn literal(value: StxLiteral, span: Span, scopes: ScopeSet) -> Self {
        Stx {
            datum: StxDatum::Literal(value),
            span,
            scopes,
            phase: Phase::Runtime,
            uniform_tag: None,
        }
    }

    /// Promotes to macro output: phase → ExpandTime + expansion generation + 1 +
    /// scopes unioned with the macro definition-site scopes (the key to §19.2
    /// hygiene: expansion output automatically carries the union
    /// "definition-site scopes ∪ use-site scopes").
    pub fn as_macro_expansion(&self, macro_def_scopes: &ScopeSet) -> Stx {
        Stx {
            datum: self.datum.clone(),
            span: self.span.bumped_expansion(),
            scopes: self.scopes.union(macro_def_scopes),
            phase: Phase::ExpandTime,
            uniform_tag: None,
        }
    }

    /// Deep scope injection (TD-004/r13, the Racket set-of-scopes model): unions
    /// `scope` into the scope sets of this syntax object and all children. Binding
    /// forms (lambda etc.) apply this injection to their binders and all body forms
    /// at expansion time — references inside the body thereby "see" the binding
    /// scopes, feeding the `(name, scopes ⊆)` subset-match resolution.
    ///
    /// Rc sharing (H2): shared subtrees go through `Rc::make_mut` copy-on-write
    /// (this layer's Vec is shallow-cloned, children stay shared) — the injection
    /// semantics are fully identical to the old value-semantics version.
    /// **Uniform-tag clearing** (TD-007 H2 soundness): injection breaks the
    /// subtree's scope uniformity — the tag is set to `None`, preventing the
    /// `retag_scopes` fast path from sharing incorrectly.
    pub fn add_scope_to_all(&mut self, scope: crate::scope::ScopeId) {
        self.scopes.add(scope);
        self.uniform_tag = None;
        match &mut self.datum {
            StxDatum::List(items) | StxDatum::Vector(items) => {
                let items = Rc::make_mut(items);
                for item in items.iter_mut() {
                    item.add_scope_to_all(scope);
                }
            }
            StxDatum::Symbol(_) | StxDatum::Literal(_) => {}
        }
    }

    /// Datum-style rendering (debugging/dump: `(if x 1 2)` form; symbol names are
    /// resolved by a caller-provided table).
    pub fn render(&self, resolve: &dyn Fn(Symbol) -> String) -> String {
        match &self.datum {
            StxDatum::Symbol(s) => resolve(*s),
            StxDatum::Literal(l) => l.render(),
            StxDatum::List(items) => {
                let inner: Vec<String> = items.iter().map(|x| x.render(resolve)).collect();
                format!("({})", inner.join(" "))
            }
            StxDatum::Vector(items) => {
                let inner: Vec<String> = items.iter().map(|x| x.render(resolve)).collect();
                format!("[{}]", inner.join(" "))
            }
        }
    }

    /// The total Span (including all children; used to build parent-node Spans).
    pub fn total_span(&self) -> Span {
        match &self.datum {
            StxDatum::List(items) | StxDatum::Vector(items) => {
                let mut span = self.span;
                for item in items.iter() {
                    span = span.merge(item.span);
                }
                span
            }
            _ => self.span,
        }
    }
}

/// **Flat deep-chain teardown (TD-007/H2)**: `Stx`'s custom `Drop` — list/vector
/// spines held uniquely (`Rc` refcount = 1) are torn down iteratively into a work
/// list, with children processed as they pop; shared subtrees (refcount > 1) merely
/// get their refcount decremented (naturally recursion-free). The old
/// value-semantics deep tree's drop recursion constraint is hereby lifted (a
/// 10_000-level chain tears down at constant stack depth).
impl Drop for Stx {
    fn drop(&mut self) {
        // Fast path: non-container datum (symbol/literal) — default teardown
        // suffices (zero recursion).
        if !matches!(self.datum, StxDatum::List(_) | StxDatum::Vector(_)) {
            return;
        }
        let mut work: Vec<Stx> = Vec::new();
        if let Some(items) = take_owned_children(&mut self.datum) {
            work.extend(items);
        }
        while let Some(mut node) = work.pop() {
            if let Some(items) = take_owned_children(&mut node.datum) {
                work.extend(items);
            }
        }
    }
}

/// Takes the uniquely-held child set out of the datum; when shared (or weakly
/// held), returns `None` and lets the taken `Rc` decrement (this node is about to
/// be destroyed, so no put-back is needed).
fn take_owned_children(datum: &mut StxDatum) -> Option<Vec<Stx>> {
    if !matches!(datum, StxDatum::List(_) | StxDatum::Vector(_)) {
        return None;
    }
    // Dummy placeholder (this Stx is being destroyed — the placeholder never leaks out)
    let taken = std::mem::replace(datum, StxDatum::Symbol(Symbol(u32::MAX)));
    match taken {
        StxDatum::List(rc) | StxDatum::Vector(rc) => {
            // Shared ownership (Err arm): dropping the Rc = refcount decrement, no recursive teardown
            Rc::try_unwrap(rc).ok()
        }
        _ => unreachable!("narrowed to a container variant above"),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn scopes(ids: &[ScopeId]) -> ScopeSet {
        ScopeSet::from_iter_scopes(ids.iter().copied())
    }

    type ScopeId = u32;

    #[test]
    fn render_list_nested() {
        let s = Stx::list(
            vec![
                Stx::symbol(Symbol(1), Span::dummy(), scopes(&[])),
                Stx::literal(StxLiteral::Int(2), Span::dummy(), scopes(&[])),
            ],
            Span::dummy(),
            scopes(&[]),
        );
        assert_eq!(s.render(&|sym: Symbol| format!("#{}", sym.0)), "(#1 2)");
    }

    #[test]
    fn macro_expansion_bumps_phase_and_scopes() {
        let base = Stx::symbol(Symbol(3), Span::new(0, 1, 5), scopes(&[1]));
        let def_scopes = scopes(&[9]);
        let expanded = base.as_macro_expansion(&def_scopes);
        assert_eq!(expanded.phase, Phase::ExpandTime);
        assert_eq!(expanded.span.expansion_id, 1);
        assert!(expanded.scopes.contains(1) && expanded.scopes.contains(9));
    }

    #[test]
    fn list_head_symbol_extraction() {
        let s = Stx::list(
            vec![
                Stx::symbol(Symbol(7), Span::dummy(), scopes(&[])),
                Stx::symbol(Symbol(8), Span::dummy(), scopes(&[])),
            ],
            Span::dummy(),
            scopes(&[]),
        );
        assert_eq!(s.datum.list_head_symbol(), Some(Symbol(7)));
        assert_eq!(
            Stx::symbol(Symbol(7), Span::dummy(), scopes(&[]))
                .datum
                .list_head_symbol(),
            None
        );
    }

    #[test]
    fn literal_render() {
        assert_eq!(StxLiteral::Int(-5).render(), "-5");
        assert_eq!(StxLiteral::Bool(true).render(), "true");
        assert_eq!(StxLiteral::Nil.render(), "nil");
        assert_eq!(StxLiteral::Float(1.5).render(), "1.5");
    }
}

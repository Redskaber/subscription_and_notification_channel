//! # kerf-syntax
//!
//! **Five-orthogonal-axes positioning (lang-design 15 §5.3, v6.0)**: the syntax-object
//! layer of surface syntax (the inner boundary of the variable side of axis 1) —
//! `Stx`/`ScopeSet`/`Symbol` carry surface forms and contain no internal AST.
//!
//! Symbol interning, scope sets, and the syntax object `SyntaxObject` (stage0.md §3.3).
//!
//! The syntax object is the foundation of the hygienic macro system — it carries
//! source positions, scope sets, and phase information, letting the expander
//! distinguish "macro-introduced identifiers" from "identifiers in user code" (§3.3).
//!
//! Responsibility boundaries:
//! - **What it does**: defines `Symbol` (a u32 handle) and `Interner` (the single
//!   source of truth, sop.md §2.3 principle 10), `ScopeSet`, `Stx` (the syntax
//!   object), and `Keyword` classification.
//! - **What it does not do**: no lexical/syntax analysis (kerf-reader), no macro
//!   expansion (kerf-expander).

pub mod scope;
pub mod stx;
pub mod symbol;

// Explicit re-exports (§10.1 rule 4: glob re-exports are forbidden).
// Convention: this crate exposes all public types of the syntax domain.
pub use scope::{ScopeId, ScopeSet};
pub use stx::{Stx, StxDatum, StxLiteral};
pub use symbol::{Keyword, Symbol, SymbolTable};

/// Phase (§3.3 / §8.9): Phase 0 = runtime, Phase 1 = macro-expansion time.
/// The two phases are two physically isolated worlds (sop.md §2.4.4).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Phase {
    /// Phase 0: the runtime world.
    Runtime,
    /// Phase 1: the macro-expansion (compile-time) world.
    ExpandTime,
}

impl Phase {
    /// The phase number (the stable ordering of phase: int in §3.3).
    pub fn as_u32(self) -> u32 {
        match self {
            Phase::Runtime => 0,
            Phase::ExpandTime => 1,
        }
    }
}

// ---------------------------------------------------------------------------
// Space affiliation declaration section (r66 / 123-a — lang-design 24 v2.0
// two-sided unified system; 24 §7.2 core-side incorporation table: this crate's
// main types get three-layer explicit impls [root + core space + domain]
// — core language domain (language-definition artifacts — the surface
// syntax-object layer); "declaration-is-affiliation" core-side edition, sole
// affiliation criterion = marker impl [24 §3 A7])
// ---------------------------------------------------------------------------
use kerf_space::{CoreLanguageDomain, CoreSpace, RootSpace};

impl RootSpace for Stx {}
impl CoreSpace for Stx {}
impl CoreLanguageDomain for Stx {}
impl RootSpace for StxDatum {}
impl CoreSpace for StxDatum {}
impl CoreLanguageDomain for StxDatum {}
impl RootSpace for ScopeSet {}
impl CoreSpace for ScopeSet {}
impl CoreLanguageDomain for ScopeSet {}
impl RootSpace for Symbol {}
impl CoreSpace for Symbol {}
impl CoreLanguageDomain for Symbol {}
impl RootSpace for SymbolTable {}
impl CoreSpace for SymbolTable {}
impl CoreLanguageDomain for SymbolTable {}

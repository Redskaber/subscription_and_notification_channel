//! Scope set (ScopeSet): the syntactic marking foundation of hygienic macros
//! (stage0.md §3.3 / §19.2).
//!
//! Every syntax object carries a scope set. Binding forms introduce new scopes
//! (marks), and macro-expansion output carries "definition-site scopes ∪
//! use-site scopes" (the key to §19.2 hygiene).
//!
//! Invariant (§19.2 invariant 2): the scope set of a macro-introduced identifier
//! ≠ the scope set of user code; the two are **never merged into a single set**
//! inside a SyntaxObject.

/// Scope identifier (a globally uniquely allocated handle).
pub type ScopeId = u32;

/// Ordered scope set (deduplicated, ascending). Membership and containment are
/// O(n), which suffices at Stage 0 scale (≤ a few dozen scopes per identifier).
#[derive(Debug, Clone, PartialEq, Eq, Hash, Default)]
pub struct ScopeSet(Vec<ScopeId>);

impl ScopeSet {
    /// The empty set.
    pub fn new() -> Self {
        ScopeSet(Vec::new())
    }

    /// Constructs from an iterator (deduplicated and sorted internally).
    pub fn from_iter_scopes(scopes: impl IntoIterator<Item = ScopeId>) -> Self {
        let mut v: Vec<ScopeId> = scopes.into_iter().collect();
        v.sort_unstable();
        v.dedup();
        ScopeSet(v)
    }

    /// Adds a scope (keeps ordered deduplication).
    pub fn add(&mut self, scope: ScopeId) {
        match self.0.binary_search(&scope) {
            Ok(_) => {}
            Err(pos) => self.0.insert(pos, scope),
        }
    }

    /// Whether it contains the given scope.
    pub fn contains(&self, scope: ScopeId) -> bool {
        self.0.binary_search(&scope).is_ok()
    }

    /// Union (hygienic expansion: definition site ∪ use site).
    pub fn union(&self, other: &ScopeSet) -> ScopeSet {
        ScopeSet::from_iter_scopes(self.0.iter().copied().chain(other.0.iter().copied()))
    }

    /// Subset test: `self ⊆ other` (binding matching: the scopes introduced by a
    /// binding must be a subset of the scopes at the reference site).
    pub fn is_subset_of(&self, other: &ScopeSet) -> bool {
        self.0.iter().all(|s| other.contains(*s))
    }

    /// Removes a scope (used when restoring the stack during a lowering traversal).
    pub fn remove(&mut self, scope: ScopeId) {
        if let Ok(pos) = self.0.binary_search(&scope) {
            self.0.remove(pos);
        }
    }

    /// Number of members.
    pub fn len(&self) -> usize {
        self.0.len()
    }

    /// Whether it is empty.
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }

    /// Iterates the scopes (ascending).
    pub fn iter(&self) -> impl Iterator<Item = ScopeId> + '_ {
        self.0.iter().copied()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn add_keeps_sorted_dedup() {
        let mut s = ScopeSet::new();
        s.add(3);
        s.add(1);
        s.add(3);
        s.add(2);
        assert_eq!(s.iter().collect::<Vec<_>>(), vec![1, 2, 3]);
        assert_eq!(s.len(), 3);
    }

    #[test]
    fn union_and_subset() {
        let a = ScopeSet::from_iter_scopes([1, 2]);
        let b = ScopeSet::from_iter_scopes([2, 3]);
        let u = a.union(&b);
        assert_eq!(u.iter().collect::<Vec<_>>(), vec![1, 2, 3]);
        assert!(a.is_subset_of(&u));
        assert!(!u.is_subset_of(&a));
    }

    #[test]
    fn hygiene_invariant_two_scope_sets_never_merge_to_single() {
        // §19.2 invariant 2: the union of macro-introduced scopes and user scopes
        // keeps both (not folded into a single element)
        let macro_scopes = ScopeSet::from_iter_scopes([10]);
        let user_scopes = ScopeSet::from_iter_scopes([1, 2]);
        let expanded = macro_scopes.union(&user_scopes);
        assert_eq!(expanded.len(), 3);
        assert!(expanded.contains(10) && expanded.contains(1) && expanded.contains(2));
    }
}

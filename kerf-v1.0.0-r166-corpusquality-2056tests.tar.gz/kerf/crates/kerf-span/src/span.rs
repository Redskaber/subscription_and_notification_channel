//! Span: an immutable representation of source positions (stage0.md §8.6).
//!
//! rustc style: every Token / AST node / IR node / bytecode instruction carries a Span:
//! - any error can be pinpointed to the source;
//! - a debugger can trace back bytecode → IR → source;
//! - incremental compilation can do fine-grained invalidation based on Spans.
//!
//! Column semantics (§19.1 implementation pitfall 1): **byte offset is the primary key;
//! line/column are used only for diagnostic rendering** — Span stores only byte offsets;
//! line/column are derived by `SourceMap` at rendering time.

use core::fmt;

/// Source file identifier (an index into the `SourceMap`).
pub type FileId = u32;

/// Byte offset (the primary key; see module docs).
pub type ByteOffset = u32;

/// Macro expansion generation (§19.2 invariant 1: syntax objects produced by each macro
/// call carry expansion_id + 1).
pub type ExpansionId = u32;

/// An immutable representation of a source position.
///
/// Invariant: `start <= end`; the file_id and expansion_id of a given Span are immutable.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
pub struct Span {
    /// Owning source file (`SourceMap` index).
    pub file_id: FileId,
    /// Start byte offset (inclusive).
    pub start: ByteOffset,
    /// End byte offset (exclusive).
    pub end: ByteOffset,
    /// Macro expansion generation: 0 = user source, N = Nth-generation macro expansion output.
    pub expansion_id: ExpansionId,
}

impl Span {
    /// Construct a Span.
    pub fn new(file_id: FileId, start: ByteOffset, end: ByteOffset) -> Self {
        Span {
            file_id,
            start,
            end,
            expansion_id: 0,
        }
    }

    /// Synthetic Span (a placeholder when there is no real source position, e.g. macro
    /// expansion output).
    ///
    /// Note: synthetic output should preferably splice the macro definition/call-site
    /// Spans instead (§19.2 pitfall 1) — "empty Spans invalidate subsequent diagnostics".
    pub fn dummy() -> Self {
        Span::new(0, 0, 0)
    }

    /// Bump the expansion generation: macro output carries "expansion generation + 1"
    /// (§19.2 invariant 1).
    pub fn bumped_expansion(self) -> Self {
        Span {
            expansion_id: self.expansion_id.saturating_add(1),
            ..self
        }
    }

    /// Merge two Spans (take the union; falls back to `self` when file or generation
    /// differ — a conservative policy that guarantees diagnostic rendering always has
    /// a usable position).
    pub fn merge(self, other: Span) -> Span {
        if self.file_id != other.file_id || self.expansion_id != other.expansion_id {
            return self;
        }
        Span {
            start: self.start.min(other.start),
            end: self.end.max(other.end),
            ..self
        }
    }

    /// Whether the Span covers the given byte offset (for diagnostic association queries).
    pub fn contains(self, offset: ByteOffset) -> bool {
        offset >= self.start && offset < self.end
    }

    /// Byte length.
    pub fn len(self) -> ByteOffset {
        self.end.saturating_sub(self.start)
    }

    /// Whether the interval is empty (dummy or zero length).
    pub fn is_empty(self) -> bool {
        self.end <= self.start
    }
}

impl fmt::Display for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "Span(file {}, {}..{}{}",
            self.file_id,
            self.start,
            self.end,
            if self.expansion_id > 0 {
                format!(", exp {})", self.expansion_id)
            } else {
                ")".to_string()
            }
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn span_merge_union() {
        let a = Span::new(0, 5, 10);
        let b = Span::new(0, 8, 20);
        assert_eq!(a.merge(b), Span::new(0, 5, 20));
        // Merging in reverse order gives the same result (union)
        assert_eq!(b.merge(a), Span::new(0, 5, 20));
    }

    #[test]
    fn span_merge_different_files_falls_back() {
        let a = Span::new(0, 5, 10);
        let b = Span::new(1, 0, 3);
        assert_eq!(a.merge(b), a);
    }

    #[test]
    fn span_expansion_bump() {
        let a = Span::new(0, 1, 2);
        assert_eq!(a.bumped_expansion().expansion_id, 1);
        assert_eq!(a.bumped_expansion().bumped_expansion().expansion_id, 2);
    }

    #[test]
    fn span_contains_and_len() {
        let a = Span::new(0, 10, 20);
        assert!(a.contains(10) && a.contains(19));
        assert!(!a.contains(20) && !a.contains(9));
        assert_eq!(a.len(), 10);
        assert!(!a.is_empty());
        assert!(Span::dummy().is_empty());
    }
}

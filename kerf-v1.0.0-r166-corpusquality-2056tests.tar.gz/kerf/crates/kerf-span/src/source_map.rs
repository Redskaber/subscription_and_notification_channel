//! SourceMap: the single trusted source of the file_id → source text / line-number table
//! (sop.md §2.3 principle 10).
//!
//! Responsibilities: derived rendering of Span (byte offset) → line/column; source-text
//! line-content queries (diagnostic excerpts). Line numbers render 1-based and columns by
//! **character count** (not bytes) 1-based — the byte offset remains the primary key.

use std::rc::Rc;

/// A single source file (source text + line-start offset table).
#[derive(Debug, Clone)]
pub struct SourceFile {
    /// File name (for display).
    pub name: String,
    /// Source text.
    pub src: Rc<str>,
    /// Start byte offset of each line (line 0 starts at 0).
    line_starts: Vec<u32>,
}

impl SourceFile {
    fn new(name: &str, src: &str) -> Self {
        let line_starts = compute_line_starts(src);
        SourceFile {
            name: name.to_string(),
            src: Rc::from(src),
            line_starts,
        }
    }

    /// Byte offset → (line, character column), both 1-based. Columns count characters
    /// (UTF-8 aware).
    fn line_col(&self, offset: u32) -> (u32, u32) {
        let offset = (offset as usize).min(self.src.len()) as u32;
        let line_idx = match self.line_starts.binary_search(&offset) {
            Ok(i) => i,
            Err(i) => i.saturating_sub(1),
        };
        let line_start = self.line_starts[line_idx] as usize;
        let col_chars = self.src[line_start..offset as usize].chars().count() as u32 + 1;
        (line_idx as u32 + 1, col_chars)
    }

    /// Fetch a whole line of text (for diagnostic excerpts); line numbers are 1-based.
    fn line_text(&self, line: u32) -> &str {
        let idx = (line as usize).saturating_sub(1);
        if idx >= self.line_starts.len() {
            return "";
        }
        let start = self.line_starts[idx] as usize;
        let end = self
            .line_starts
            .get(idx + 1)
            .map(|&e| e as usize)
            .unwrap_or(self.src.len());
        self.src[start..end].trim_end_matches(['\n', '\r'])
    }
}

fn compute_line_starts(src: &str) -> Vec<u32> {
    let mut starts = vec![0u32];
    for (i, b) in src.bytes().enumerate() {
        if b == b'\n' {
            starts.push(i as u32 + 1);
        }
    }
    starts
}

/// Source file registry: a Span's file_id resolves here to source text and line/column.
#[derive(Debug, Default, Clone)]
pub struct SourceMap {
    files: Vec<SourceFile>,
}

impl SourceMap {
    pub fn new() -> Self {
        SourceMap { files: Vec::new() }
    }

    /// Register a source file, returning the assigned file_id.
    pub fn add_file(&mut self, name: &str, src: &str) -> u32 {
        let id = self.files.len() as u32;
        self.files.push(SourceFile::new(name, src));
        id
    }

    /// Look up a source file (an out-of-range file_id returns `None` — an explicit
    /// error, not silent, §2.3 principle 4).
    pub fn file(&self, file_id: u32) -> Option<&SourceFile> {
        self.files.get(file_id as usize)
    }

    /// Number of files.
    pub fn len(&self) -> usize {
        self.files.len()
    }

    /// Whether empty.
    pub fn is_empty(&self) -> bool {
        self.files.is_empty()
    }

    /// Span → human-readable location ("main.krf:3:5"). Appends a marker when the
    /// generation is > 0.
    pub fn render_location(&self, file_id: u32, offset: u32, expansion_id: u32) -> String {
        match self.file(file_id) {
            Some(f) => {
                let (line, col) = f.line_col(offset);
                if expansion_id > 0 {
                    format!("{}:{}:{} (expansion {})", f.name, line, col, expansion_id)
                } else {
                    format!("{}:{}:{}", f.name, line, col)
                }
            }
            None => format!("<unknown file {}>", file_id),
        }
    }

    /// Diagnostic excerpt: located line text + column indicator (^ points at the position).
    pub fn excerpt(&self, file_id: u32, offset: u32) -> String {
        match self.file(file_id) {
            Some(f) => {
                let (line, col) = f.line_col(offset);
                let text = f.line_text(line);
                let pad = " ".repeat(col.saturating_sub(1) as usize);
                format!("{:>4} | {}\n     | {}^", line, text, pad)
            }
            None => String::new(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn line_col_basic() {
        let mut sm = SourceMap::new();
        let id = sm.add_file("t.krf", "(define x 1)\n(print x)\n");
        let f = sm.file(id).unwrap();
        assert_eq!(f.line_col(0), (1, 1));
        assert_eq!(f.line_col(1), (1, 2));
        // The second line starts at 13 ("(define x 1)\n" = 13 bytes)
        assert_eq!(f.line_col(12), (1, 13));
        assert_eq!(f.line_col(13), (2, 1));
        assert_eq!(f.line_col(14), (2, 2));
    }

    #[test]
    fn line_col_utf8() {
        let mut sm = SourceMap::new();
        let id = sm.add_file("t.krf", "(+ \"你好\" 1)");
        let f = sm.file(id).unwrap();
        // Byte 4 is the first byte of the first CJK char; columns count characters:
        // src[0..4] = `(+ "` → column 5
        assert_eq!(f.line_col(4), (1, 5));
        // Byte 7 is the first byte of the second CJK char: src[0..7] is 4 chars + 1
        // CJK char = column 6
        assert_eq!(f.line_col(7), (1, 6));
    }

    #[test]
    fn render_location_and_excerpt() {
        let mut sm = SourceMap::new();
        let id = sm.add_file("t.krf", "(define x 1)\n");
        let loc = sm.render_location(id, 9, 0);
        assert_eq!(loc, "t.krf:1:10");
        let exp = sm.excerpt(id, 9);
        assert!(exp.contains("(define x 1)"));
        assert!(exp.contains('^'));
    }

    #[test]
    fn unknown_file_is_explicit() {
        let sm = SourceMap::new();
        assert_eq!(sm.render_location(7, 0, 0), "<unknown file 7>");
    }
}

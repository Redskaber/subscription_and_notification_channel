//! # kerf-span
//!
//! **Five-orthogonal-axes positioning (lang-design 15 §5.3, v6.0)**: the cross-cutting metadata
//! foundation — the Span/Diagnostic layer shared by all five axes (principle 30: metadata is
//! independent of naming; `kind_name` is for diagnostic rendering only).
//!
//! Span source-position tracking system and structured diagnostics framework
//! (stage0.md §8.6 / §8.7 / §12.1 / §12.2, Layer 1).
//!
//! Responsibility boundary (stage0.md §8.6):
//! - **What it does**: provides the immutable `Span` (file_id + byte offset + expansion
//!   generation), `SourceMap` (file_id → source text / line-number table), and the
//!   rustc-style `Diagnostic` structured diagnostics.
//! - **What it does not do**: no I/O side effects (rendering returns a string, and the
//!   caller outputs it); no dependencies on any other kerf crate (Layer 1 infrastructure).
//!
//! Design constraints (sop.md §2.4.4):
//! - Span is an ID type shared across stages (no prefix, §10.1 rule 3);
//! - errors are data, not exceptions — `Diagnostic` is composable, renderable, and
//!   serializable to text.

pub mod diagnostic;
pub mod source_map;
pub mod span;

// Explicit re-exports (§10.1 rule 4: glob re-exports forbidden).
// Convention: this crate exposes all public types of the Span domain.
pub use diagnostic::{
    render_diagnostic, Diagnostic, DiagnosticCode, Severity, SubDiagnostic, Suggestion,
};
pub use source_map::{SourceFile, SourceMap};
pub use span::{ByteOffset, ExpansionId, FileId, Span};

// ---------------------------------------------------------------------------
// Space subordination declaration section (r66 / 123-a — lang-design 24 v2.0 two-sided
// unified system; 24 §7.2 core-side incorporation table: this crate's primary types get
// explicit three-layer impls [root + core space + domain] — core cross-cutting domain
// (positioning and diagnostics — program-text metadata depended on by everyone);
// core-side version of "declaration is membership", sole subordination criterion =
// marker impl [24 §3 A7]
// [Implementation ruling (E0117 mechanism boundary)] `FileId`/`ByteOffset` are type
// aliases (= u32 — not standalone types): **a type alias is not a subordination
// carrier** — an alias's identity is carried by its host structure (Span/SourceMap
// membership); Rust's orphan-rule rejection is precisely the empirical demonstration of
// the mechanism boundary of "declaration is membership" (24 §8 backfill).)
// ---------------------------------------------------------------------------
use kerf_space::{CoreSpace, CoreSpanDomain, RootSpace};

impl RootSpace for Span {}
impl CoreSpace for Span {}
impl CoreSpanDomain for Span {}
impl RootSpace for Diagnostic {}
impl CoreSpace for Diagnostic {}
impl CoreSpanDomain for Diagnostic {}
impl RootSpace for SourceMap {}
impl CoreSpace for SourceMap {}
impl CoreSpanDomain for SourceMap {}

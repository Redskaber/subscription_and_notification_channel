//! Structured diagnostics framework (stage0.md §8.7 / §12.2).
//!
//! Modeled on rustc's Diagnostic structure:
//! - **errors are data, not exceptions** (§8.7 architectural principle);
//! - supports error-recovery strategies (diagnostics can be collected and rendered together);
//! - multi-stage error association (children sub-diagnostics + suggestions fix proposals).
//!
//! The minimal shared shape of all error types is `{ message: String, span: Span }`
//! (sop.md §10.1 rule 8).

use crate::source_map::SourceMap;
use crate::span::Span;

/// Diagnostic severity level.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Severity {
    Error,
    Warning,
    Note,
    Help,
}

impl Severity {
    /// Rendering label (fixed width, for multi-diagnostic alignment).
    pub fn label(self) -> &'static str {
        match self {
            Severity::Error => "error",
            Severity::Warning => "warning",
            Severity::Note => "note",
            Severity::Help => "help",
        }
    }
}

/// Diagnostic number (e.g. E0001 = lexical error). `None` means unnumbered.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct DiagnosticCode(pub u32);

impl DiagnosticCode {
    /// Render in the "E0001" form.
    pub fn render(self) -> String {
        format!("E{:04}", self.0)
    }
}

/// Secondary diagnostic (associated note, e.g. "the macro expanded here").
#[derive(Debug, Clone)]
pub struct SubDiagnostic {
    pub severity: Severity,
    pub message: String,
    pub span: Span,
}

/// Fix suggestion.
#[derive(Debug, Clone)]
pub struct Suggestion {
    pub message: String,
    pub span: Span,
    pub replacement: String,
}

/// rustc-style structured diagnostic.
#[derive(Debug, Clone)]
pub struct Diagnostic {
    pub severity: Severity,
    pub code: Option<DiagnosticCode>,
    pub message: String,
    pub primary_span: Span,
    pub children: Vec<SubDiagnostic>,
    pub suggestions: Vec<Suggestion>,
}

impl Diagnostic {
    /// Construct an Error-level diagnostic.
    pub fn error(code: Option<DiagnosticCode>, message: impl Into<String>, span: Span) -> Self {
        Diagnostic {
            severity: Severity::Error,
            code,
            message: message.into(),
            primary_span: span,
            children: Vec::new(),
            suggestions: Vec::new(),
        }
    }

    /// Construct a Warning-level diagnostic.
    pub fn warning(code: Option<DiagnosticCode>, message: impl Into<String>, span: Span) -> Self {
        Diagnostic {
            severity: Severity::Warning,
            code,
            message: message.into(),
            primary_span: span,
            children: Vec::new(),
            suggestions: Vec::new(),
        }
    }

    /// Attach a secondary diagnostic (chained).
    pub fn with_child(
        mut self,
        severity: Severity,
        message: impl Into<String>,
        span: Span,
    ) -> Self {
        self.children.push(SubDiagnostic {
            severity,
            message: message.into(),
            span,
        });
        self
    }

    /// Attach a fix suggestion (chained).
    pub fn with_suggestion(
        mut self,
        message: impl Into<String>,
        span: Span,
        replacement: impl Into<String>,
    ) -> Self {
        self.suggestions.push(Suggestion {
            message: message.into(),
            span,
            replacement: replacement.into(),
        });
        self
    }

    /// Whether this is a blocking error.
    pub fn is_error(&self) -> bool {
        self.severity == Severity::Error
    }
}

/// Render a diagnostic as human-readable text (§2.2 principle 16: human-perceivable
/// output is a first-class citizen).
///
/// Format:
/// ```text
/// error[E0001]: illegal character '#'
///   --> main.krf:1:5
///    |
///  1 | (+# 1)
///    |      ^
/// ```
pub fn render_diagnostic(diag: &Diagnostic, source_map: &SourceMap) -> String {
    let mut out = String::new();
    let code = diag
        .code
        .as_ref()
        .map(|c| format!("[{}]", c.render()))
        .unwrap_or_default();
    out.push_str(&format!(
        "{}{}: {}\n",
        diag.severity.label(),
        code,
        diag.message
    ));
    let span = diag.primary_span;
    out.push_str(&format!(
        "  --> {}\n",
        source_map.render_location(span.file_id, span.start, span.expansion_id)
    ));
    if !span.is_empty() || source_map.file(span.file_id).is_some() {
        let excerpt = source_map.excerpt(span.file_id, span.start);
        if !excerpt.is_empty() {
            out.push_str("   |\n");
            for line in excerpt.lines() {
                out.push_str(&format!("{}\n", line));
            }
        }
    }
    for child in &diag.children {
        out.push_str(&format!(
            "  {}: {} ({})\n",
            child.severity.label(),
            child.message,
            source_map.render_location(
                child.span.file_id,
                child.span.start,
                child.span.expansion_id
            )
        ));
    }
    for sugg in &diag.suggestions {
        out.push_str(&format!(
            " help: {} → `{}`\n",
            sugg.message, sugg.replacement
        ));
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn diagnostic_render_full_shape() {
        let mut sm = SourceMap::new();
        let id = sm.add_file("t.krf", "(+ # 1)");
        let diag = Diagnostic::error(
            Some(DiagnosticCode(1)),
            "illegal character '#'",
            Span::new(id, 3, 4),
        )
        .with_child(Severity::Note, "operand expected here", Span::new(id, 0, 7))
        .with_suggestion("did you mean to type 1", Span::new(id, 3, 4), "1");
        let text = render_diagnostic(&diag, &sm);
        assert!(text.contains("error[E0001]: illegal character '#'"));
        assert!(text.contains("--> t.krf:1:4"));
        assert!(text.contains("note: operand expected here"));
        assert!(text.contains("help: did you mean to type 1"));
    }

    #[test]
    fn severity_labels() {
        assert_eq!(Severity::Error.label(), "error");
        assert_eq!(Severity::Warning.label(), "warning");
    }

    #[test]
    fn code_render() {
        assert_eq!(DiagnosticCode(1).render(), "E0001");
        assert_eq!(DiagnosticCode(331).render(), "E0331");
    }
}

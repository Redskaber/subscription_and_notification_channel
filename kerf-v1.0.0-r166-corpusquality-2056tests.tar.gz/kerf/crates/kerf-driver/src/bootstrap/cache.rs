//! Build-system segment's fifth incision bridge (r90 / 160-b — the
//! carrier of TD-032's cache-segment closing incision; the fifth
//! production proof of the 07 §3.3 Stage 2→3 signal "the build system
//! can be rewritten in the new language". All five TD-032 incisions
//! are in place — the remaining surface of self-hosting the build system (r149/219-b: the five payloads are now target-syntax .ktf — s-expr-removal-plan Batch A)
//! is retired and closed out).
//!
//! Architecture (isomorphic to bootstrap_build/bootstrap_cli/
//! bootstrap_check/bootstrap_test/bootstrap_test_runner — the fifth
//! instance of the incision-bridge pattern, the cache-consultation
//! strategy surface):
//! - **Consultation strategy**: `bootstrap/cache.ktf` (a kerf-source
//!   semantic port of driver.rs `compile_front_cached`'s cache
//!   consultation strategy [key construction + the bypass/hit/miss
//!   three-form decision], compiled by the seed pipeline and run on the
//!   Stage 0 VM); the entry `lcache-consult` consumes two Foreign
//!   callbacks (**argument pass-through** — lexical binding avoids the
//!   globally visible surface, same as r87's fourth incision):
//!   - `lhash`: byte-level hash (hash.rs SHA-256 truncated to u64 — a
//!     Class-A frozen host service [replacement-surface map §3.4],
//!     exposed through the bridge rather than made a VM primitive — the
//!     ruling solution for "VM primitive absence": the host service
//!     surface never enters the VM instruction set);
//!   - `llookup`: cache lookup (cache.rs `lookup_front` — a Class-A
//!     frozen host service; the hit snapshot is handed off via the
//!     bridge's staging slot: FrontOutput is a Rust shape that never
//!     crosses the VM value domain, retrieved host-side after the 'hit
//!     decision);
//! - **Bridge (this module)**: host-side invocation + argument assembly
//!   (enabled/source/filename/kind-tag + two callbacks) + decision
//!   decoding ('bypass Symbol / ('hit|'miss src cfg) three-element list
//!   → [`CachePlan`]) + the hit staging slot;
//! - **Original Rust implementation (driver.rs `compile_front_cached`
//!   three-stage form + cache.rs `cache_key`)**: retired as the parity
//!   oracle (`cache_krf_parity_tests` comparison — the five-incision
//!   switch's isomorphic discipline).
//!
//! **Production switch (r90/160-b) in effect**: the consultation
//! strategy of driver `compile_front_cached` goes through this entry
//! ([`production_cache_consult`] — always the Bootstrap kind). Switch
//! guards: [`production_cache_is_bootstrap`] (liveness probe test) +
//! parity corpus (key-construction oracle comparison + all
//! consultation strategy forms + production E2E).
//!
//! Heap contract: cache.ktf's persistent heap carries global constants
//! and per-call intermediates — GC uses (stack + frames + globals) as
//! its root set, so reclamation across calls is safe; the callbacks
//! consume only scalar arguments (Str/Int/Bool — a zero-heap-allocation
//! contract surface; boxing of return values belongs to the outer call
//! sequence).
//!
//! Concurrency contract: thread_local state (Rc values are not Sync) —
//! lazily compiled and loaded once per thread (same as the existing
//! bridges). The CLI loads lazily once per process (single-threaded
//! main — one seed compilation's cost, additive with the prior
//! incisions at the same order of magnitude, <1ms).

use std::cell::RefCell;
use std::collections::HashMap;
use std::rc::Rc;

use kerf_compiler::BcProgram;
use kerf_runtime::{Heap, RuntimeError};
use kerf_span::SourceMap;
use kerf_syntax::{Symbol, SymbolTable};
use kerf_vm::{call_closure, run_program, unbox_slot, BuiltinFn, Value, VmError};

use crate::builtins::register_globals;
use crate::cache::with_cache;
use crate::driver::{CompilerKind, FrontOutput};
use crate::hash::content_hash64;
use crate::reserved::CacheKey;

/// cache.ktf source (embedded at compile time — the artifact is
/// self-contained, same treatment as the existing incisions).
const CACHE_SRC: &str = include_str!("cache.ktf");
/// cache.ktf source file name (Span diagnostic attribution).
const CACHE_FILENAME: &str = "cache.ktf";
/// Entry name (a top-level definition of cache.ktf).
const ENTRY_NAME: &str = "lcache-consult";

// Production-path liveness count (r90 — a probe-panel signal, mirroring
// bootstrap_test_runner's `production_test_runner_is_bootstrap`
// shape).
thread_local! {
    static KRF_PRODUCTION_RUNS: std::cell::Cell<u64> = const {
        std::cell::Cell::new(0)
    };
}

/// Production consultation liveness probe: krf-path consultations > 0
/// (this thread).
/// Consumer surface = the production-switch guard test (the empirical
/// anchor that compile_front_cached goes through the krf path).
pub fn production_cache_is_bootstrap() -> bool {
    KRF_PRODUCTION_RUNS.with(|c| c.get() > 0)
}

/// Cache consultation decision (the bridge's decoded product — the
/// whole decision surface is pub-observable [the key = the `CacheKey`
/// frozen-contract pub type — both the hit and miss forms carry the
/// key]; the hit snapshot is handed off via the bridge's staging slot:
/// FrontOutput stays in pub(crate) shape and never crosses the pub
/// surface; in-crate consumers retrieve the clone via [`take_hit`]).
#[derive(Debug, Clone, PartialEq)]
pub enum CachePlan {
    /// Cache disabled → host compiles directly (cache_hit = false).
    Bypass,
    /// Hit (key + stashed snapshot — clone retrieved via [`take_hit`];
    /// snapshot semantics = the clone of the FrontOutput returned by
    /// lookup_front).
    Hit(CacheKey),
    /// Miss → host compiles, then writes via `store_front` (cache_hit =
    /// false).
    Miss(CacheKey),
}

/// Self-hosted cache.ktf state (one per thread, lazily initialized).
struct BootstrapCacheState {
    /// cache program bytecode (compiled by the seed pipeline).
    program: BcProgram,
    /// Loaded globals (builtins + cache.ktf top-level definitions).
    globals: HashMap<Symbol, Value>,
    /// `lcache-consult` entry symbol.
    entry_sym: Symbol,
    /// cache.ktf's source map (for rendering internal error
    /// diagnostics).
    source_map: SourceMap,
    /// Persistent heap: global data + per-call products (the GC root set
    /// includes globals).
    heap: Heap,
}

thread_local! {
    static BOOTSTRAP_CACHE: RefCell<Option<BootstrapCacheState>> = const {
        RefCell::new(None)
    };
}

// Hit snapshot staging slot (the handoff channel from the llookup
// callback to 'hit decision decoding; FrontOutput is a Rust shape that
// never crosses the VM value domain — single-slot transfer inside the
// bridge).
thread_local! {
    static STASHED_HIT: RefCell<Option<FrontOutput>> = const {
        RefCell::new(None)
    };
}

/// Cache consultation (**production path** — consumed by driver
/// `compile_front_cached`; always the Bootstrap kind).
///
/// Semantics = the original Rust three-stage form (`cache_enabled` early
/// exit + `cache_key` key construction + `lookup_front` lookup), with
/// the strategy going through the self-hosted cache.ktf
/// (`lcache-consult` — running on the VM); hashing and lookup go
/// through Foreign callbacks (Class-A frozen host services). `Err`
/// covers only bridge/cache.ktf internal defects (unreachable protocol
/// arms — fail-closed; the caller maps them to DriverError).
pub fn production_cache_consult(
    enabled: bool,
    source: &str,
    filename: &str,
) -> Result<CachePlan, String> {
    let plan = consult(enabled, source, filename, CompilerKind::Bootstrap)?;
    KRF_PRODUCTION_RUNS.with(|c| c.set(c.get() + 1));
    Ok(plan)
}

/// Cache consultation (general surface — the consumption entry for
/// parity tests: the kind dimension is controllable [the seed-bucket
/// comparison surface]; the production surface is always Bootstrap via
/// [`production_cache_consult`]).
pub fn consult(
    enabled: bool,
    source: &str,
    filename: &str,
    kind: CompilerKind,
) -> Result<CachePlan, String> {
    // Defensive slot clearing before decision decoding (leftovers from
    // the previous round must not leak across consultations —
    // single-slot semantics)
    STASHED_HIT.with(|s| {
        *s.borrow_mut() = None;
    });
    with_cache_state(|st| {
        let callee = st.globals.get(&st.entry_sym).cloned().ok_or_else(|| {
            format!(
                "[bootstrap-cache] entry {} undefined (cache.ktf corrupted)",
                ENTRY_NAME
            )
        })?;
        // Six pass-through arguments (enabled/source/filename/kind-tag +
        // two callbacks — Foreign function values passed through as
        // arguments, lexically bound on the .ktf side; the same
        // multi-argument shape as the test_runner bridge's two-argument
        // pass-through)
        let output = call_closure(
            &st.program,
            &mut st.globals,
            &mut st.heap,
            &callee,
            vec![
                Value::Bool(enabled),
                Value::Str(Rc::from(source)),
                Value::Str(Rc::from(filename)),
                Value::Str(Rc::from(kind_tag(kind))),
                Value::Builtin(make_hash_fn()),
                Value::Builtin(make_lookup_fn()),
            ],
        )
        .map_err(|e| vm_error_to_internal(&e, &st.source_map))?;
        plan_from_value(&output, &st.heap)
    })
}

/// `CompilerKind` → kind tag (a mechanical type-level projection —
/// splitting/composition strategy belongs to the .ktf single source;
/// the same division of labor as the test_runner bridge's `kind_tag`).
fn kind_tag(kind: CompilerKind) -> &'static str {
    match kind {
        CompilerKind::Bootstrap => "bootstrap",
        CompilerKind::Seed => "seed",
    }
}

/// Consultation decision decoding ('bypass Symbol / ('hit|'miss src
/// cfg) three-element list → [`CachePlan`]; protocol defense:
/// non-Symbol/non-list/arity/field-type mismatch = internal error,
/// fail-closed).
fn plan_from_value(v: &Value, heap: &Heap) -> Result<CachePlan, String> {
    match v {
        Value::Symbol(s) if &**s == "bypass" => {
            // bypass fast path: zero lookups, zero stashing (defensive
            // slot clearing already happened at the consult entry)
            Ok(CachePlan::Bypass)
        }
        Value::Symbol(other) => Err(format!(
            "[bootstrap-cache] unknown decision label {}(cache.ktf corrupted)",
            other
        )),
        list => {
            let fields = value_fields(list, heap)?;
            if fields.len() != 3 {
                return Err(format!(
                    "[bootstrap-cache] decision list non-ternary({} field -- cache.ktf corrupted)",
                    fields.len()
                ));
            }
            let tag = match &fields[0] {
                Value::Symbol(s) => (**s).to_string(),
                other => {
                    return Err(format!(
                        "[bootstrap-cache] decision label field is not symbol({} -- cache.ktf corrupted)",
                        other.type_name()
                    ))
                }
            };
            let src = hash_field(&fields[1])?;
            let cfg = hash_field(&fields[2])?;
            let key = CacheKey {
                source_hash: src,
                config_fingerprint: cfg,
            };
            match tag.as_str() {
                "hit" => Ok(CachePlan::Hit(key)),
                "miss" => Ok(CachePlan::Miss(key)),
                other => Err(format!(
                    "[bootstrap-cache] unknown decision label {}(cache.ktf corrupted)",
                    other
                )),
            }
        }
    }
}

/// Hash field decoding (VM Int [an i64 bit pattern carrying the u64
/// truncated hash — bit-pattern pass-through: `as u64`
/// reinterpretation with zero numeric semantics]; protocol defense:
/// non-Int = internal error).
fn hash_field(v: &Value) -> Result<u64, String> {
    match v.as_int() {
        Some(i) => Ok(i as u64),
        None => Err(format!(
            "[bootstrap-cache] hash field is not int({} -- cache.ktf corrupted)",
            v.type_name()
        )),
    }
}

/// Hit snapshot retrieval (the in-crate consumer surface — consumed
/// by driver `compile_front_cached`; single-slot semantics: retrieval
/// clears the slot; after a hit decision a hit must be present
/// [otherwise it is a bridge protocol defect — fail-closed; the
/// consumer maps it to DriverError]).
#[allow(dead_code)] // E6 dormancy (r154 / 224-a): consumer compile_front_cached deleted with the S-expr surface; kept for the trigger-gated target-path cache extension
pub(crate) fn take_hit() -> Option<FrontOutput> {
    STASHED_HIT.with(|s| s.borrow_mut().take())
}

/// Byte-level hash callback construction (a Foreign function value —
/// `(lhash s)` → Int; hash.rs `content_hash64` = a Class-A frozen host
/// service exposed through the bridge [SHA-256 truncated to u64 → i64
/// bit-pattern pass-through]).
fn make_hash_fn() -> Rc<BuiltinFn> {
    BuiltinFn::new("lhash64", |_, args| {
        if args.len() != 1 {
            return Err(RuntimeError::new("lhash64 requires 1 arguments(string)"));
        }
        match &args[0] {
            Value::Str(s) => Ok(Value::Int(content_hash64(s.as_bytes()) as i64)),
            other => Err(RuntimeError::new(format!(
                "lhash64 argument requires str({})",
                other.type_name()
            ))),
        }
    })
}

/// Cache lookup callback construction (a Foreign function value —
/// `(llookup src-hash cfg-fp)` → Bool; cache.rs `lookup_front` = a
/// Class-A frozen host service exposed through the bridge; the hit
/// snapshot is staged in the single slot [retrieved after 'hit decision
/// decoding]; the statistics rule = one lookup, zero double
/// counting).
fn make_lookup_fn() -> Rc<BuiltinFn> {
    BuiltinFn::new("lcache-lookup", |_, args| {
        if args.len() != 2 {
            return Err(RuntimeError::new(
                "lcache-lookup requires 2 arguments(src-hash + cfg-fp)",
            ));
        }
        let src = match args[0].as_int() {
            Some(i) => i as u64,
            None => {
                return Err(RuntimeError::new("lcache-lookup src-hash requires int"));
            }
        };
        let cfg = match args[1].as_int() {
            Some(i) => i as u64,
            None => {
                return Err(RuntimeError::new("lcache-lookup cfg-fp requires int"));
            }
        };
        let key = CacheKey {
            source_hash: src,
            config_fingerprint: cfg,
        };
        // Hit lookup + snapshot stashing (single slot — a miss
        // overwriting None is idempotent: lookup returns None on a miss,
        // which goes straight into the slot, preserving single-slot
        // semantics)
        let hit = with_cache(|c| c.lookup_front(&key));
        let is_hit = hit.is_some();
        STASHED_HIT.with(|s| *s.borrow_mut() = hit);
        Ok(Value::Bool(is_hit))
    })
}

/// Execute with thread-local state (lazily initialized).
fn with_cache_state<T>(
    f: impl FnOnce(&mut BootstrapCacheState) -> Result<T, String>,
) -> Result<T, String> {
    BOOTSTRAP_CACHE.with(|cell| {
        let mut opt = cell.borrow_mut();
        if opt.is_none() {
            match load_cache() {
                Ok(state) => *opt = Some(state),
                Err(e) => return Err(e),
            }
        }
        f(opt.as_mut().expect("initialized above"))
    })
}

/// Compile and load cache.ktf (seed path — no recursion: the seed
/// compiles the self-hosted implementation, the P1 hard convention of
/// the existing bridges; **the seed path bypasses the cache** —
/// compile_front_seed compiles directly, no consultation recursion).
fn load_cache() -> Result<BootstrapCacheState, String> {
    let front = crate::driver::compile_front_seed(CACHE_SRC, CACHE_FILENAME).map_err(|e| {
        format!(
            "[bootstrap-cache] cache.ktf compile failed (seed pipeline):{}",
            e.rendered
        )
    })?;
    build_state(front.program, front.table, front.source_map)
}

/// Build cache state from front-end products (a single
/// state-construction implementation).
fn build_state(
    program: BcProgram,
    mut table: SymbolTable,
    source_map: SourceMap,
) -> Result<BootstrapCacheState, String> {
    // cache.ktf has no I/O references (pure decision-making — hashing
    // and lookup execute on the host via callbacks) — loaded with an
    // empty grant (R9 fail-closed)
    let mut globals = register_globals(&mut table, &crate::capability::IoGrant::none());
    crate::builtins::resolve_hygiene_fallbacks(&program, &mut table, &mut globals);
    let mut heap = Heap::new();
    let outcome = run_program(&program, &mut globals, &mut heap)
        .map_err(|e| vm_error_to_internal(&e, &source_map))?;
    let _ = outcome; // The main prototype only executes top-level definitions (value unused)
    let entry_sym = table.intern(ENTRY_NAME);
    Ok(BootstrapCacheState {
        program,
        globals,
        entry_sym,
        source_map,
        heap,
    })
}

/// VM error → internal error string (defensive path — the decision
/// bridge has no value-channel errors).
fn vm_error_to_internal(e: &VmError, sm: &SourceMap) -> String {
    use kerf_span::render_diagnostic;
    let diag = kerf_span::Diagnostic::error(
        Some(kerf_span::DiagnosticCode(2)),
        format!("bootstrap cache.ktf internal error:{}", e.message),
        e.span,
    );
    render_diagnostic(&diag, sm)
}

/// List value → field sequence (bridge-side destructuring — a
/// nil-terminated guard; an independent copy of the same shape as the
/// existing bridges).
fn value_fields(v: &Value, heap: &Heap) -> Result<Vec<Value>, String> {
    let mut out = Vec::new();
    let mut cur = v.clone();
    while let Value::Pair(r) = cur {
        let (car, cdr) = heap
            .get_pair(r)
            .ok_or_else(|| "[bootstrap-cache] heap pair slot corrupted".to_string())?;
        out.push(unbox_slot(car, heap));
        cur = unbox_slot(cdr, heap);
    }
    if !matches!(cur, Value::Nil) {
        return Err(format!(
            "[bootstrap-cache] decision list tail non- nil({} -- cache.ktf corrupted)",
            cur.type_name()
        ));
    }
    Ok(out)
}

#[cfg(test)]
mod tests {
    use super::*;

    /// State liveness probe (a parity-test panel signal — mirroring the
    /// is_* shape of the prior incisions): lazy loading + same-thread
    /// reuse + bypass making zero calls (the disabled path's fast
    /// path).
    #[test]
    fn cache_state_lifecycle_probe() {
        // The first consultation triggers compile-loading (lazy);
        // disabled → bypass
        let p = consult(false, "(+ 1 2)", "lifecycle.krf", CompilerKind::Bootstrap)
            .expect("disabled consultation");
        assert!(matches!(p, CachePlan::Bypass));
        // Same-thread reuse (state already loaded — the second call has
        // zero loading cost)
        let p2 = consult(false, "(+ 1 2)", "lifecycle2.krf", CompilerKind::Bootstrap)
            .expect("disabled re-consultation");
        assert!(matches!(p2, CachePlan::Bypass));
        // State liveness: thread_local is initialized
        assert!(BOOTSTRAP_CACHE.with(|cell| cell.borrow().is_some()));
    }

    /// Production liveness probe (the calls above don't count —
    /// empirical proof of the production surface's independent signal).
    #[test]
    fn cache_production_liveness_probe() {
        let p = production_cache_consult(false, "(+ 1 2)", "liveness.krf")
            .expect("production disabled consultation");
        assert!(matches!(p, CachePlan::Bypass));
        assert!(production_cache_is_bootstrap());
    }

    /// Hit decision snapshot handoff (query-callback staging →
    /// take_hit retrieval — single-slot semantics; the prerequisite is
    /// writing the production-bucket key via store_front; the key is
    /// observable via the Hit form).
    #[test]
    fn cache_hit_snapshot_handoff() {
        use crate::cache::cache_key;
        crate::cache::cache_reset();
        let src = "let handoff_x = 1;";
        let key = cache_key(src, "handoff.ktf", CompilerKind::Bootstrap);
        let front = crate::driver::compile_front_seed(src, "handoff.ktf").expect("seed compile");
        with_cache(|c| c.store_front(key.clone(), front));
        let p =
            consult(true, src, "handoff.ktf", CompilerKind::Bootstrap).expect("hit consultation");
        match p {
            CachePlan::Hit(got_key) => {
                assert_eq!(got_key, key, "Hit form key should match the written key");
                let front = take_hit().expect("hit decision after staging slot should in place");
                assert_eq!(front.core.len(), 1);
                // Single-slot semantics: retrieval clears the slot
                assert!(take_hit().is_none());
            }
            other => panic!("should hit, got {:?}", other),
        }
        crate::cache::cache_reset();
    }
}

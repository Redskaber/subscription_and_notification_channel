//! Switchover-window step ② Reader bridge (r107 lexer batch +
//! r108 parser batch; the sole Reader face since E6 r154).
//!
//! Architecture (07 §3.2.1 five-step process step ② — bytecode-izing the
//! Reader):
//! - **Reader logic**: the Reader expressed in kerf source,
//!   compiled to bytecode and run on the Stage 0 VM — the dual entries
//!   `lex` / `parse`. Since the S-expr complete removal
//!   window Batch C parser leg (r152 / 222-b) **both entries load the
//!   kerf-syntax rewrite** [`reader.ktf`] through
//!   `compile_front_seed` (the seed Rust Reader reads it —
//!   the Reader fixpoint milestone closure: the production .ktf read
//!   bridge's own lexer **and parser** now expressed in the target
//!   language). The r151 interim dual thread-local states collapse
//!   back into the single pre-r151 shape (both entry symbols live in
//!   one program — the user r152 directive's Rust-side consolidation
//!   leg). The Rust seed [`kerf_reader::reader`] remains the oracle of
//!   the parity tests (the kind/Span/payload and Stx-tree stable
//!   contract is shared by both faces);
//! - **Bridge (this module)**: host-side invocation (`call_closure`) +
//!   Token value tree → `ParityToken` conversion + syntax node tree →
//!   `Vec<Stx>` conversion (symbol interning = host responsibility —
//!   isomorphic to the seed `sym_at`) + same-source numeric-text parse
//!   (i64/f64 semantic conversion is the host type boundary) +
//!   Token-embedded error message rendering (`tk_debug_of_kind` seed
//!   single-source — f64 Debug and Str escaping cannot be reliably
//!   re-implemented inside the VM);
//! - **Seed (kerf-reader/reader.rs)**: the bootstrapping implementation
//!   that compiles the sole face and is the oracle of the parity tests (a
//!   class-B replacement candidate — the implement-then-replace one-shot
//!   window: bootstrap-replacement-surface-map §3.5 usage two).
//!
//! Consumers: the E6 gate family (fixpoint/two-path gates in
//! tests/v0/stage3/plan/ — the parity duty successor) + every production
//! `.ktf` read (the read stage of `compile_front` through this
//! bridge).
//!
//! **E6 terminal integration (r154 / 224-a — s-expr-removal-plan §11
//! single-reader terminal directive)**: `reader.ktf` renamed to
//! `reader.ktf` — the **sole** Reader file of the bootstrap domain; the
//! S-expr originals (`reader.krf` oracle + the S-expr Reader's
//! reader.ktf predecessor) were deleted at the E6 close-out (principle 41
//! — demolition after validation; the parity duty migrated to the
//! fixpoint gate family + the two-path gates + the deletion guard). With
//! kerf-reader's classic S-expr face removed (target.rs = the sole Rust
//! Reader implementation), the entire read surface — bootstrap artifact,
//! VM bridge, Rust seed — is the target-language face.
//!
//! Heap contract: the target Reader program's persistent heap carries
//! global data (charset tables / keyword tables) and per-call intermediate
//! products — GC uses (stack + frames + globals) as its root set, so
//! cross-call collection is safe.
//!
//! Concurrency contract: thread_local state (Rc values are not Sync) —
//! lazily compiled and loaded once per thread (isomorphic to the bootstrap
//! Reader bridge).

use std::cell::RefCell;
use std::collections::HashMap;
use std::rc::Rc;

use kerf_compiler::BcProgram;
use kerf_reader::{
    parse_float_payload_text, parse_int_payload_text, symbol_name, tk_debug_of_kind, ParityToken,
    ReadError,
};
use kerf_runtime::Heap;
use kerf_span::{render_diagnostic, Diagnostic, DiagnosticCode, FileId, Severity, SourceMap, Span};
use kerf_syntax::{ScopeSet, Stx, StxDatum, StxLiteral, Symbol, SymbolTable};
use kerf_vm::{call_closure, run_program, unbox_slot, Value, VmError};

use crate::builtins::register_globals;

use super::{as_int, as_str, as_symbol_name, internal, internal_heap_error, value_list_fields};

/// Target Reader source — both entries' path (embedded at compile time —
/// self-contained artifact, no external file dependency). Since the
/// r152 / 222-b parser leg this is the target-syntax rewrite
/// [`reader.ktf`] (the lexer segment since r151, the parser segment
/// since r152 — the Reader fixpoint milestone closure); renamed from
/// `reader.ktf` at the E6 close-out (r154 / 224-a — §11
/// single-reader terminal directive); the S-expr original
/// `reader.krf` oracle was deleted at E6 (principle 41 — the
/// parity duty migrated to the fixpoint + two-path gates).
const TARGET_READER_SRC: &str = include_str!("reader.ktf");
/// Target Reader source filename (for diagnostic rendering).
const TARGET_READER_FILENAME: &str = "reader.ktf";

/// Target Reader state (one per thread, lazily initialized — isomorphic to
/// the Reader bridge).
struct ReaderState {
    /// Target Reader program bytecode (compiled via the seed pipeline).
    program: BcProgram,
    /// Loaded globals (builtins + reader.ktf top-level definitions).
    globals: HashMap<Symbol, Value>,
    /// Target Reader's own symbol table (entry-name resolution — interned
    /// at load time, then merely held).
    #[allow(dead_code)]
    table: SymbolTable,
    /// The `lex` entry symbol.
    lex_sym: Symbol,
    /// The `parse` entry symbol (r108 parser batch).
    parse_sym: Symbol,
    /// Source map of the target Reader (internal error diagnostic rendering).
    source_map: SourceMap,
    /// Persistent heap: global data + per-call products (GC root set includes globals).
    heap: Heap,
}

thread_local! {
    static TARGET_READER: RefCell<Option<ReaderState>> = const {
        RefCell::new(None)
    };
}

/// Target-syntax lexer entry: source text → `Vec<ParityToken>`.
///
/// Cross-checked against `kerf_reader::reader::lex_for_parity` (the
/// Rust seed oracle), same shape — a byte-level equality gate on
/// kind/Span/payload (tests/v0/stage3/plan/target_reader_krf_tests.rs).
/// Since r151 / 221-b this entry loads reader.ktf (the target-syntax
/// rewrite) through the seed Reader — the assertions of the existing
/// lexer parity family are unchanged and now gate the .ktf face directly.
/// Since r152 / 222-b the lexer and parser entries share one loaded program
/// (the dual-state interim collapsed — same file, same state).
pub fn lex_for_bootstrap(source: &str, file_id: FileId) -> Result<Vec<ParityToken>, ReadError> {
    let blen = source.len() as i64;
    with_reader(|st| {
        let lex_value = call_entry(
            st,
            st.lex_sym,
            "lex",
            vec![Value::Str(Rc::from(source)), Value::Int(blen)],
        )?;
        bridge_parity_tokens(&lex_value, &st.heap, file_id)
    })
}

/// Execute with thread-local state (lazy initialization — isomorphic to the
/// Reader bridge). Since r152 / 222-b this single state serves both
/// entries (the r151 lexer-leg dual-state interim collapsed — one
/// program, one state).
fn with_reader<T>(
    f: impl FnOnce(&mut ReaderState) -> Result<T, ReadError>,
) -> Result<T, ReadError> {
    TARGET_READER.with(|cell| {
        let mut opt = cell.borrow_mut();
        if opt.is_none() {
            match load_reader() {
                Ok(state) => *opt = Some(state),
                Err(e) => return Err(e),
            }
        }
        f(opt.as_mut().expect("initialized above"))
    })
}

/// Target-syntax source reading entry (r108 parser batch): source
/// text → `Vec<Stx>`.
///
/// Cross-checked against `kerf_reader::reader::read_source` (the
/// Rust seed oracle), same shape — a byte-level equality gate on the
/// canonical Stx-tree rendering (symbol names + literal values + Span
/// bytes) (the parser-parity family in
/// tests/v0/stage3/plan/target_reader_krf_tests.rs). Symbols are interned
/// into the caller's `table` (isomorphic to the seed `sym_at` — symbol
/// interning is a host responsibility). Since r152 / 222-b this entry
/// loads reader.ktf (the parser batch of the S-expr complete
/// removal window — the Reader fixpoint milestone closure: the whole
/// production .ktf read bridge now expressed in the target language,
/// read in by the seed Reader and run on the VM).
pub fn read_source_for_bootstrap(
    source: &str,
    file_id: FileId,
    table: &mut SymbolTable,
) -> Result<Vec<Stx>, ReadError> {
    let blen = source.len() as i64;
    with_reader(|st| {
        let value = call_entry(
            st,
            st.parse_sym,
            "parse",
            vec![Value::Str(Rc::from(source)), Value::Int(blen)],
        )?;
        bridge_stx_program(&value, &st.heap, file_id, table)
    })
}

/// Compile and load a Reader program (the shared loading spine — the sole
/// read face is the target-language Reader program reader.ktf, loaded via
/// the seed target pipeline; the expand/compile stages stay the seed Rust
/// pipeline — the P1 hard convention).
fn load_reader_program(src: &str, filename: &str) -> Result<ReaderState, ReadError> {
    let front = crate::driver::compile_front_seed(src, filename).map_err(|e| {
        ReadError::new(
            format!(
                "[bootstrap] goal Reader compile failed (seed pipeline):{}",
                e.rendered
            ),
            Span::dummy(),
        )
    })?;
    // the Reader sources have no I/O references (pure lexical data
    // transformation) — empty grant (same anchor as the Reader bridge:
    // fail-closed, I/O builtins do not enter the bootstrap environment)
    let mut table = front.table;
    let mut globals = register_globals(&mut table, &crate::capability::IoGrant::none());
    // Hygiene fallback resolution (the Reader sources have no macros — a
    // no-op; pipeline-consistency same anchor)
    crate::builtins::resolve_hygiene_fallbacks(&front.program, &mut table, &mut globals);
    let mut heap = Heap::new();
    let outcome = run_program(&front.program, &mut globals, &mut heap)
        .map_err(|e| vm_error_to_read(&e, &front.source_map))?;
    let _ = outcome; // The main prototype only executes top-level definitions (value meaningless)
    let lex_sym = table.intern("lex");
    let parse_sym = table.intern("parse");
    Ok(ReaderState {
        program: front.program,
        globals,
        table,
        lex_sym,
        parse_sym,
        source_map: front.source_map,
        heap,
    })
}

/// Compile and load the Reader program — the .ktf target-syntax rewrite
/// (r151 lexer leg + r152 parser leg; the Rust **target** Reader reads it:
/// the Reader fixpoint milestone closure). Both the `lex` and
/// `parse` entry symbols live in this one program (the r152
/// dual-state interim collapsed — one file, one state).
fn load_reader() -> Result<ReaderState, ReadError> {
    load_reader_program(TARGET_READER_SRC, TARGET_READER_FILENAME)
}

/// Invoke a target Reader entry function (host trust-layer programmatic call —
/// same §11 anchor).
fn call_entry(
    st: &mut ReaderState,
    entry: Symbol,
    entry_name: &str,
    args: Vec<Value>,
) -> Result<Value, ReadError> {
    let callee = st.globals.get(&entry).cloned().ok_or_else(|| {
        ReadError::new(
            format!(
                "[bootstrap] goal Reader internal error: entry {} undefined (reader.ktf corrupted)",
                entry_name
            ),
            Span::dummy(),
        )
    })?;
    match &callee {
        Value::Builtin(b) => b.call(&mut st.heap, args).map_err(|e| {
            ReadError::new(
                format!(
                    "[bootstrap] self-check call failed({}): {}",
                    entry_name, e.message
                ),
                Span::dummy(),
            )
        }),
        other => call_closure(&st.program, &mut st.globals, &mut st.heap, other, args)
            .map_err(|e| vm_error_to_read(&e, &st.source_map)),
    }
}

/// VM error → ReadError (defensive path — lexer errors are returned as
/// ('err ...) values and do not go through this channel; covers only
/// reader.ktf internal defects or frame limits).
fn vm_error_to_read(e: &VmError, sm: &SourceMap) -> ReadError {
    let mut diag = Diagnostic::error(
        Some(DiagnosticCode(1)),
        format!("goal Reader internal error:{}", e.message),
        e.span,
    );
    for t in &e.trace {
        diag = diag.with_child(Severity::Note, "call site", t.span);
    }
    // Rendered with reader.ktf's own source map (the user source map is
    // meaningless for its Spans)
    ReadError::new(render_diagnostic(&diag, sm), Span::dummy())
}

// ---- Value bridge: ParityToken ----

/// Token value list → `Vec<ParityToken>` (including ('err ...) checking and
/// same-source numeric parse).
fn bridge_parity_tokens(
    v: &Value,
    heap: &Heap,
    file_id: FileId,
) -> Result<Vec<ParityToken>, ReadError> {
    if let Some(e) = read_error_form(v, heap, file_id) {
        return Err(e);
    }
    let mut out = Vec::new();
    let mut cur = v.clone();
    while let Value::Pair(r) = cur {
        let (car, cdr) = heap.get_pair(r).ok_or_else(internal_heap_error)?;
        let item = unbox_slot(car, heap);
        let fields = value_list_fields(&item, heap)?;
        if fields.len() != 4 {
            return Err(internal("Token form field count error(expected 4)"));
        }
        let kind = as_str(&fields[0])?.to_string();
        let start = as_int(&fields[1])? as u32;
        let end = as_int(&fields[2])? as u32;
        let payload = parity_payload_of(&kind, &fields[3], file_id, start, end)?;
        out.push(ParityToken {
            kind,
            start,
            end,
            payload,
        });
        cur = unbox_slot(cdr, heap);
    }
    Ok(out)
}

/// ('err message start end) → ReadError (returns None for non-error shapes
/// — isomorphic to the Reader bridge); ('err prefix kind payload start end)
/// → ReadError (the r108 parser-batch Token-embedded shape — message =
/// prefix + Tk Debug word/surface token [seed single-source rendering]).
fn read_error_form(v: &Value, heap: &Heap, file_id: FileId) -> Option<ReadError> {
    if let Value::Pair(r) = v {
        if let Some((car, _)) = heap.get_pair(*r) {
            if let Value::Symbol(s) = unbox_slot(car, heap) {
                if &*s == "err" {
                    let fields = value_list_fields(v, heap).ok()?;
                    if fields.len() == 4 {
                        // Fixed-message shape (isomorphic to the lexer layer)
                        let msg = as_str(&fields[1]).ok()?;
                        let s = as_int(&fields[2]).ok()?;
                        let e = as_int(&fields[3]).ok()?;
                        // Span carries the user file_id (the error location is
                        // inside the user source text)
                        return Some(ReadError::new(
                            msg.to_string(),
                            Span::new(file_id, s as u32, e as u32),
                        ));
                    }
                    if fields.len() == 6 {
                        // Token-embedded shape (r108 parser batch — the bridge renders
                        // the Tk Debug word/surface token)
                        let prefix = as_str(&fields[1]).ok()?;
                        let kind = as_str(&fields[2]).ok()?;
                        let payload = match &fields[3] {
                            Value::Str(t) => Some(t.to_string()),
                            _ => None,
                        };
                        let s = as_int(&fields[4]).ok()?;
                        let e = as_int(&fields[5]).ok()?;
                        let msg =
                            format!("{}{}", prefix, tk_debug_of_kind(kind, payload.as_deref()));
                        return Some(ReadError::new(msg, Span::new(file_id, s as u32, e as u32)));
                    }
                    return None;
                }
            }
        }
    }
    None
}

/// payload value → ParityToken payload (same-source numeric parse — the host
/// type boundary).
///
/// int: radix-marked text → i64 → decimal value text (the .krf-side overflow
/// guard runs first, so a parse failure here = defensive path [mirroring the
/// seed overflow message]); float: body → f64 → value text (the .krf-side
/// float-text-bad runs first — a failure here = defensive path [mirroring
/// the seed float message]). The parse helpers = seed single-source
/// (kerf-reader::target — r108 / 178-b).
fn parity_payload_of(
    kind: &str,
    v: &Value,
    file_id: FileId,
    start: u32,
    end: u32,
) -> Result<Option<String>, ReadError> {
    match kind {
        "int" => {
            let text = as_str(v)?;
            let val = parse_int_payload_text(text)
                .map_err(|m| ReadError::new(m, Span::new(file_id, start, end)))?;
            Ok(Some(val.to_string()))
        }
        "float" => {
            let text = as_str(v)?;
            let f = parse_float_payload_text(text)
                .map_err(|m| ReadError::new(m, Span::new(file_id, start, end)))?;
            Ok(Some(f.to_string()))
        }
        "str" | "ident" | "path" => Ok(Some(as_str(v)?.to_string())),
        _ => Ok(None),
    }
}

// ---- Value bridge: Stx tree (r108 parser batch) ----

/// parse return value → `Vec<Stx>` (('ok item-node-list rest) shape +
/// dual error-shape checking + node-tree walk — symbols interned into the
/// caller's table).
fn bridge_stx_program(
    v: &Value,
    heap: &Heap,
    file_id: FileId,
    table: &mut SymbolTable,
) -> Result<Vec<Stx>, ReadError> {
    if let Some(e) = read_error_form(v, heap, file_id) {
        return Err(e);
    }
    let fields = value_list_fields(v, heap)?;
    if fields.len() != 3 {
        return Err(internal(
            "parse return form error(expected ('ok item table rest) three field)",
        ));
    }
    let head = as_symbol_name(&fields[0])?;
    if head != "ok" {
        return Err(internal("parse return form error(head field is not 'ok)"));
    }
    let items = value_list_fields(&fields[1], heap)?;
    let mut out = Vec::with_capacity(items.len());
    for it in &items {
        out.push(bridge_stx_node(it, heap, file_id, table)?);
    }
    Ok(out)
}

/// Syntax node → Stx (uniform 4 fields (tag payload start end) — isomorphic
/// to the seed sym_at/list_at/literal; int/float = same-source parse of
/// radix-marked text).
fn bridge_stx_node(
    v: &Value,
    heap: &Heap,
    file_id: FileId,
    table: &mut SymbolTable,
) -> Result<Stx, ReadError> {
    let fields = value_list_fields(v, heap)?;
    if fields.len() != 4 {
        return Err(internal("syntax node form field count error(expected 4)"));
    }
    let tag = as_symbol_name(&fields[0])?;
    let s = as_int(&fields[2])? as u32;
    let e = as_int(&fields[3])? as u32;
    let span = Span::new(file_id, s, e);
    match tag {
        "sym" => {
            let name = as_str(&fields[1])?;
            // r109 / 179-a ruling 1: skin-dictionary name mapping (`_` → `-`)
            // — the same-source single point as the seed sym_at
            // (symbol_name shared) → bilateral symbol parity.
            let sym = table.intern(&symbol_name(name));
            Ok(Stx::symbol(sym, span, ScopeSet::new()))
        }
        "int" => {
            let text = as_str(&fields[1])?;
            let val = parse_int_payload_text(text).map_err(|m| ReadError::new(m, span))?;
            Ok(Stx::literal(StxLiteral::Int(val), span, ScopeSet::new()))
        }
        "float" => {
            let text = as_str(&fields[1])?;
            let f = parse_float_payload_text(text).map_err(|m| ReadError::new(m, span))?;
            Ok(Stx::literal(StxLiteral::Float(f), span, ScopeSet::new()))
        }
        "str" => {
            let text = as_str(&fields[1])?;
            Ok(Stx::literal(
                StxLiteral::Str(Rc::from(text)),
                span,
                ScopeSet::new(),
            ))
        }
        "bool" => {
            let text = as_str(&fields[1])?;
            Ok(Stx::literal(
                StxLiteral::Bool(text == "true"),
                span,
                ScopeSet::new(),
            ))
        }
        "unit" => Ok(Stx::literal(StxLiteral::Nil, span, ScopeSet::new())),
        "lst" => {
            let items = value_list_fields(&fields[1], heap)?;
            let mut children = Vec::with_capacity(items.len());
            for it in &items {
                children.push(bridge_stx_node(it, heap, file_id, table)?);
            }
            Ok(Stx::list(children, span, ScopeSet::new()))
        }
        // r138 / 208-c — TD-002 (vector-value-design.md §2.2): the
        // fourteenth skin mapping's product — the vector datum node
        // (mirrors "lst"; the comma-elision mapping produces the same
        // StxDatum::Vector the S-expr-face bracket reader yields —
        // skin transparency by construction)
        "vec" => {
            let items = value_list_fields(&fields[1], heap)?;
            let mut children = Vec::with_capacity(items.len());
            for it in &items {
                children.push(bridge_stx_node(it, heap, file_id, table)?);
            }
            Ok(Stx {
                datum: StxDatum::Vector(std::rc::Rc::new(children)),
                span,
                scopes: ScopeSet::new(),
                phase: kerf_syntax::Phase::Runtime,
                uniform_tag: None,
            })
        }
        other => Err(internal(&format!("unknown syntax node tag: {}", other))),
    }
}

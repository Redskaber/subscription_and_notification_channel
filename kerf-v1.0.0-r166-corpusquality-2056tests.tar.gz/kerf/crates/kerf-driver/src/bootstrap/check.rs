//! HM/typecheck .krf-path validation bridge (r74 / 144-b — [r74-window-opening §2]
//! carrier; r150 / 220-b: the payload language form switched to target
//! syntax — check.ktf — the S-expr complete removal window Batch B,
//! s-expr-removal-plan.md §4/§5 gate B).
//!
//! Architecture (isomorphic to bootstrap_compiler.rs — fourth instance of
//! the three-piece pattern):
//! - **Check logic**: `bootstrap/check.ktf` (a kerf-source mini HM
//!   inference engine, compiled to bytecode via the seed target pipeline
//!   and run on the Stage 0 VM — entry `lchk-check-program`, consuming **the same
//!   core-node wire protocol** as compiler.ktf — zero new bridge protocols,
//!   `item_to_node` serialization reused);
//! - **Bridge (this module)**: host-side invocation (`call_closure`) +
//!   item-node serialization + result value → [`KrfCheckOutcome`] type
//!   reconstruction;
//! - **Rust HM (kerf-compiler/hm.rs)**: since r80 the production decision
//!   surface has switched to the check.ktf path (user M1 instruction window
//!   opening — HM default-period switch: 12 §2.5.1 K3 final-state Stage 3
//!   trigger-based window exercise); the Rust `hm_check_program` is retired
//!   as parity oracle + **narrow fallback surface** (effect corpus outside
//!   the subset — perform/handle nodes → [`ProductionOutcome::Fallback`]).
//!
//! Heap contract: the check.ktf persistent heap carries global state (TC-*
//! inference contexts — the entry reset discipline keeps it free of state
//! that affects output across calls); GC uses (stack + frames + globals)
//! as its root set, so cross-call collection is safe.
//!
//! Concurrency contract: thread_local state (Rc values are not Sync) —
//! lazily compiled and loaded once per thread (same as bootstrap_compiler/
//! bootstrap_expander).

use std::cell::RefCell;
use std::collections::HashMap;

use kerf_compiler::BcProgram;
use kerf_core::ModuleItem;
use kerf_runtime::{BoxedInput, Heap};
use kerf_span::SourceMap;
use kerf_syntax::{Symbol, SymbolTable};
use kerf_vm::{box_value, call_closure, run_program, Value, VmError};

use crate::bootstrap::{as_int, as_str, as_symbol_name, value_list_fields};
use crate::builtins::register_globals;

/// check.ktf source (embedded at compile time — self-contained artifact,
/// same policy as the three-piece set; target syntax — the S-expr
/// complete removal window Batch B / r150 / 220-b).
const CHECK_SRC: &str = include_str!("check.ktf");
/// check.ktf source filename (Span diagnostic attribution).
const CHECK_FILENAME: &str = "check.ktf";
/// Entry name (a top-level definition of check.ktf).
const ENTRY_NAME: &str = "lchk-check-program";

/// krf mini-HM decision result (PoC validation surface — accept/reject
/// parity criterion payload).
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum KrfCheckOutcome {
    /// Clean (zero diagnostics — the parity baseline of the Rust HM's zero
    /// diagnostics).
    Clean,
    /// Single diagnostic (message + Span start/end bytes — the first error
    /// of a single item; the r74 shape is kept — after item-level recovery
    /// this shape is still returned when only one item reports an error).
    Diag {
        /// Diagnostic message (simplified text — message-level parity is an
        /// obligation of the future production-switch window).
        message: String,
        /// Span start byte.
        start: u32,
        /// Span end byte.
        end: u32,
    },
    /// Multiple diagnostics (r75/145-e item-level recovery multi-error
    /// collection — all independent inter-item errors collected, in source
    /// order; intra-item multi-errors / failed defines are later absorbed
    /// as a residual honest boundary, belonging to the future
    /// production-switch window).
    Diags {
        /// Diagnostic sequence (source order — first error per item).
        items: Vec<KrfDiagItem>,
    },
    /// Out of subset (node kinds outside PoC coverage — a structured skip
    /// signal; the caller treats it as "not applicable" rather than
    /// failure — honest-boundary carrier).
    Unsupported(String),
}

/// Single item of the multi-diagnostic payload (r75/145-e — an element of
/// `('diags ((msg s e) ...))`).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct KrfDiagItem {
    /// Diagnostic message (simplified text).
    pub message: String,
    /// Span start byte.
    pub start: u32,
    /// Span end byte.
    pub end: u32,
}

/// Production decision routing result (r80 / 150-b — the HM default-period
/// production switch).
///
/// Main path = check.ktf (run on the VM); out-of-subset (perform/handle
/// effect nodes — the productionized form of the PoC honest boundary) →
/// [`ProductionOutcome::Fallback`], the caller falls back to the Rust
/// oracle ([`kerf_compiler::hm::hm_check_program`]) — narrow-surface
/// carriage, so effect corpus remains decidable (a defensive shape
/// isomorphic to the cli.krf `_` fallback arm: no silent degradation, no
/// widening of the fail-closed surface).
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ProductionOutcome {
    /// krf-path decision complete (diagnostic payload — zero entries means
    /// clean; messages are simplified text, Span start/end bytes,
    /// expansion_id is not in the wire protocol — the reconstruction side
    /// uniformly uses 0).
    Krf(Vec<KrfDiagItem>),
    /// Out of subset (unsupported kind) — the caller falls back to the Rust oracle.
    Fallback(String),
}

// Production-path liveness counter (r80 — probe panel signal, mirroring the
// bootstrap_cli `production_cli_is_bootstrap` shape).
thread_local! {
    static KRF_PRODUCTION_RUNS: std::cell::Cell<u64> = const {
        std::cell::Cell::new(0)
    };
}

/// Production decision liveness probe: krf-path decision count > 0 (this thread).
/// Consumer = the production switchover guard test (empirical anchor that
/// check_source goes through the krf path).
pub fn production_check_is_krf() -> bool {
    KRF_PRODUCTION_RUNS.with(|c| c.get() > 0)
}

/// Self-hosted check.ktf state (one per thread, lazily initialized).
struct BootstrapCheckState {
    /// check program bytecode (compiled via the seed pipeline).
    program: BcProgram,
    /// Loaded globals (builtins + check.ktf top-level definitions).
    globals: HashMap<Symbol, Value>,
    /// The `lchk-check-program` entry symbol.
    entry_sym: Symbol,
    /// Source map of check.ktf (internal error diagnostic rendering).
    source_map: SourceMap,
    /// Persistent heap: global data + per-call products (GC root set includes globals).
    heap: Heap,
}

thread_local! {
    static BOOTSTRAP_CHK: RefCell<Option<BootstrapCheckState>> = const {
        RefCell::new(None)
    };
}

/// krf mini-HM decision surface (PoC validation path).
///
/// Input = the front-end output item sequence (same source as the `core`
/// field of [`crate::driver::compile_source`] — serialized inside the
/// bridge to VM nodes via `item_to_node`, the same wire protocol as the
/// compiler.krf input) + the member-rename assoc table (r135 /
/// member-rename-design.md v1.2 §8 D12-③ — `((renamed . underlying)
/// ...)`, the apply-position signature derivation's data face; an empty
/// table = the pre-r135 single-argument behavior in full). Errors (`Err`)
/// cover only bridge/check.ktf internal defects (unreachable protocol
/// arms) — type diagnostics are returned as values via
/// [`KrfCheckOutcome::Diag`] (same shape as the three-piece `('err ...)`
/// value channel).
pub fn krf_check_program(
    items: &[ModuleItem],
    renames: &[(String, String)],
    table: &SymbolTable,
) -> Result<KrfCheckOutcome, String> {
    with_check(|st| {
        // Stage 1: ModuleItem → VM core nodes (the same serialization as
        // bootstrap_compiler — single-source wire-protocol reuse)
        let nodes: Vec<Value> = items
            .iter()
            .map(|item| crate::bootstrap::compiler::item_to_node(item, table, &mut st.heap))
            .collect();
        let input = heap_list(&mut st.heap, nodes);
        // r135 D12-③: the rename assoc table — ((renamed . underlying)
        // ...) pairs of Str values, source order
        let renames_v = heap_renames(&mut st.heap, renames);
        // Stage 2: entry invocation (check.ktf run on the VM — the entry's
        // `(nodes renames)` protocol face)
        let output = call_entry(st, input, renames_v)?;
        // Stage 3: result value → KrfCheckOutcome type reconstruction
        outcome_from_value(&output, &st.heap)
    })
}

/// r135 / member-rename-design.md v1.2 §8 D12-③: build the VM rename
/// assoc table `((renamed . underlying) ...)` — pairs of Str values,
/// source order (front-inserted walking in reverse; the same
/// construction shape as the test_runner bridge's item lists).
fn heap_renames(heap: &mut Heap, renames: &[(String, String)]) -> Value {
    if renames.is_empty() {
        return Value::Nil;
    }
    let mut acc = heap.alloc_boxed(BoxedInput::Nil);
    for (renamed, underlying) in renames.iter().rev() {
        // the assoc pair: (renamed . underlying)
        let r_ref = box_value(&Value::Str(std::rc::Rc::from(renamed.as_str())), heap);
        let u_ref = box_value(&Value::Str(std::rc::Rc::from(underlying.as_str())), heap);
        let pair_ref = heap.alloc_pair(r_ref, u_ref);
        let elem = box_value(&Value::Pair(pair_ref), heap);
        acc = heap.alloc_pair(elem, acc);
    }
    Value::Pair(acc)
}

/// Production decision entry (r80 / 150-b — main path of the HM
/// default-period production switch).
///
/// Differences from [`krf_check_program`]: (1) routing semantics —
/// [`ProductionOutcome`] promotes `Unsupported` to a fallback signal (effect
/// corpus falls back to the Rust oracle, executed by the caller — the
/// bridge holds no sigs/diagnostic-reconstruction responsibility); (2)
/// liveness counting — every krf-path decision makes
/// [`production_check_is_krf`] true (empirical anchor of the production
/// guard test); (3) Clean/Diag/Diags uniformly converge to
/// `Krf(Vec<KrfDiagItem>)` (zero entries means clean — the production
/// surface consumes a single shape).
///
/// Errors (`Err`) = bridge/check.ktf internal defects (kerr protocol arm or
/// VM error) — production surface fail-closed (the caller converts to
/// `DriverError`, same R9 discipline).
pub fn production_check(
    items: &[ModuleItem],
    renames: &[(String, String)],
    table: &SymbolTable,
) -> Result<ProductionOutcome, String> {
    let outcome = krf_check_program(items, renames, table)?;
    KRF_PRODUCTION_RUNS.with(|c| c.set(c.get() + 1));
    Ok(match outcome {
        KrfCheckOutcome::Clean => ProductionOutcome::Krf(Vec::new()),
        KrfCheckOutcome::Diag {
            message,
            start,
            end,
        } => ProductionOutcome::Krf(vec![KrfDiagItem {
            message,
            start,
            end,
        }]),
        KrfCheckOutcome::Diags { items } => ProductionOutcome::Krf(items),
        KrfCheckOutcome::Unsupported(kind) => ProductionOutcome::Fallback(kind),
    })
}

/// Execute with thread-local state (lazy initialization).
fn with_check<T>(
    f: impl FnOnce(&mut BootstrapCheckState) -> Result<T, String>,
) -> Result<T, String> {
    BOOTSTRAP_CHK.with(|cell| {
        let mut opt = cell.borrow_mut();
        if opt.is_none() {
            match load_check() {
                Ok(state) => *opt = Some(state),
                Err(e) => return Err(e),
            }
        }
        f(opt.as_mut().expect("initialized above"))
    })
}

/// Compile and load check.ktf (seed target path — no recursion: the seed
/// pipeline compiles the self-hosted implementation, same P1 hard
/// constraint as the three-piece set; r150/220-b: the payload language
/// form switched to target syntax — compile_front_seed, the
/// reader/expander/compiler stages remain seed Rust).
fn load_check() -> Result<BootstrapCheckState, String> {
    let front = crate::driver::compile_front_seed(CHECK_SRC, CHECK_FILENAME).map_err(|e| {
        format!(
            "[bootstrap-chk] check.ktf compile failed (seed target pipeline):{}",
            e.rendered
        )
    })?;
    build_state(front.program, front.table, front.source_map)
}

/// Build check state from front-end outputs (single state-construction
/// implementation).
fn build_state(
    program: BcProgram,
    mut table: SymbolTable,
    source_map: SourceMap,
) -> Result<BootstrapCheckState, String> {
    // check.ktf has no I/O references (pure data transformation) — empty
    // grant (R9 fail-closed)
    let mut globals = register_globals(&mut table, &crate::capability::IoGrant::none());
    crate::builtins::resolve_hygiene_fallbacks(&program, &mut table, &mut globals);
    let mut heap = Heap::new();
    let outcome = run_program(&program, &mut globals, &mut heap)
        .map_err(|e| vm_error_to_internal(&e, &source_map))?;
    let _ = outcome; // The main prototype only executes top-level definitions (value meaningless)
    let entry_sym = table.intern(ENTRY_NAME);
    Ok(BootstrapCheckState {
        program,
        globals,
        entry_sym,
        source_map,
        heap,
    })
}

/// Invoke the check entry (host trust-layer programmatic call — §11).
/// r135 D12-③: two arguments — the item list + the rename assoc table
/// (the entry's `(nodes renames)` protocol face).
fn call_entry(st: &mut BootstrapCheckState, input: Value, renames: Value) -> Result<Value, String> {
    let callee = st.globals.get(&st.entry_sym).cloned().ok_or_else(|| {
        format!(
            "[bootstrap-chk] entry {} undefined (check.ktf corrupted)",
            ENTRY_NAME
        )
    })?;
    call_closure(
        &st.program,
        &mut st.globals,
        &mut st.heap,
        &callee,
        vec![input, renames],
    )
    .map_err(|e| vm_error_to_internal(&e, &st.source_map))
}

/// VM error → internal error string (defensive path: type diagnostics are
/// returned as ('diag ...) values and do not go through this channel —
/// covers only check.ktf internal defects or frame limits).
fn vm_error_to_internal(e: &VmError, sm: &SourceMap) -> String {
    use kerf_span::render_diagnostic;
    let diag = kerf_span::Diagnostic::error(
        Some(kerf_span::DiagnosticCode(2)),
        format!("bootstrap check.ktf internal error:{}", e.message),
        e.span,
    );
    render_diagnostic(&diag, sm)
}

/// Result value → [`KrfCheckOutcome`] (`('ok)` / `('diag msg s e)` /
/// `('diags ((msg s e) ...))` / `('unsupported kind)` / `('kerr msg)`
/// — the check.ktf file-header contract).
fn outcome_from_value(v: &Value, heap: &Heap) -> Result<KrfCheckOutcome, String> {
    let fields = value_list_fields(v, heap)
        .map_err(|e| format!("[bootstrap-chk] result non-list value:{}", e.message))?;
    let tag = as_symbol_name(&fields[0])
        .map_err(|e| format!("[bootstrap-chk] result head non-symbol: {}", e.message))?;
    match tag {
        "ok" => Ok(KrfCheckOutcome::Clean),
        "diag" => {
            if fields.len() < 4 {
                return Err("[bootstrap-chk] diag field count abnormal".into());
            }
            let message = as_str(&fields[1])
                .map_err(|e| format!("[bootstrap-chk] diag message is not str: {}", e.message))?
                .to_string();
            let start = as_int(&fields[2])
                .map_err(|e| format!("[bootstrap-chk] diag start is not int: {}", e.message))?;
            let end = as_int(&fields[3])
                .map_err(|e| format!("[bootstrap-chk] diag end is not int: {}", e.message))?;
            Ok(KrfCheckOutcome::Diag {
                message,
                start: u32::try_from(start).unwrap_or(0),
                end: u32::try_from(end).unwrap_or(0),
            })
        }
        // Multiple diagnostics (r75/145-e — item-level recovery multi-error
        // collection: fields[1] = a list of triples (msg s e) ..., source
        // order)
        "diags" => {
            if fields.len() < 2 {
                return Err("[bootstrap-chk] diags field count abnormal".into());
            }
            let triples = value_list_fields(&fields[1], heap).map_err(|e| {
                format!("[bootstrap-chk] diags payload non-list value:{}", e.message)
            })?;
            let mut items = Vec::with_capacity(triples.len());
            for (idx, t) in triples.iter().enumerate() {
                let triple = value_list_fields(t, heap).map_err(|e| {
                    format!("[bootstrap-chk] diags[{}] non-triple: {}", idx, e.message)
                })?;
                if triple.len() < 3 {
                    return Err(format!(
                        "[bootstrap-chk] diags[{}] field count abnormal",
                        idx
                    ));
                }
                let message = as_str(&triple[0])
                    .map_err(|e| {
                        format!(
                            "[bootstrap-chk] diags[{}] message is not str: {}",
                            idx, e.message
                        )
                    })?
                    .to_string();
                let start = as_int(&triple[1]).map_err(|e| {
                    format!(
                        "[bootstrap-chk] diags[{}] start is not int: {}",
                        idx, e.message
                    )
                })?;
                let end = as_int(&triple[2]).map_err(|e| {
                    format!(
                        "[bootstrap-chk] diags[{}] end is not int: {}",
                        idx, e.message
                    )
                })?;
                items.push(KrfDiagItem {
                    message,
                    start: u32::try_from(start).unwrap_or(0),
                    end: u32::try_from(end).unwrap_or(0),
                });
            }
            Ok(KrfCheckOutcome::Diags { items })
        }
        "unsupported" => {
            let kind = as_symbol_name(&fields[1]).map_err(|e| {
                format!("[bootstrap-chk] unsupported kind non-symbol: {}", e.message)
            })?;
            Ok(KrfCheckOutcome::Unsupported(kind.to_string()))
        }
        "kerr" => {
            let msg = as_str(&fields[1])
                .map_err(|e| format!("[bootstrap-chk] kerr message is not str: {}", e.message))?;
            Err(format!(
                "[bootstrap-chk] check.ktf internal defect: {}",
                msg
            ))
        }
        other => Err(format!("[bootstrap-chk] unknown result tag: {}", other)),
    }
}

/// Construct a list value on the given heap (isomorphic to the `list`
/// builtin — same as the bridge self-check surface; a same-shaped private
/// helper as bootstrap_compiler's, an independent copy in this module).
fn heap_list(heap: &mut Heap, items: Vec<Value>) -> Value {
    if items.is_empty() {
        return Value::Nil;
    }
    let mut acc = heap.alloc_boxed(BoxedInput::Nil);
    for v in items.into_iter().rev() {
        let elem = box_value(&v, heap);
        acc = heap.alloc_pair(elem, acc);
    }
    Value::Pair(acc)
}

#[cfg(test)]
mod tests {
    use super::*;

    /// State liveness probe (panel signal for the parity tests — mirrors the
    /// three-piece set's is_loaded).
    #[test]
    fn check_state_lifecycle_probe() {
        // Lazy loading: the first decision triggers compile-and-load; same-thread reuse
        let items: Vec<ModuleItem> = Vec::new();
        let table = SymbolTable::new();
        let r = krf_check_program(&items, &[], &table).expect("empty program decision");
        assert_eq!(r, KrfCheckOutcome::Clean);
        let r2 = krf_check_program(&items, &[], &table).expect("empty program re-judged");
        assert_eq!(r2, KrfCheckOutcome::Clean);
    }

    /// Empty-program protocol: ('ok) → Clean (zero-payload validation of the
    /// entry reset discipline).
    #[test]
    fn empty_program_is_clean() {
        let items: Vec<ModuleItem> = Vec::new();
        let table = SymbolTable::new();
        assert_eq!(
            krf_check_program(&items, &[], &table).expect("empty program decision"),
            KrfCheckOutcome::Clean
        );
    }
}

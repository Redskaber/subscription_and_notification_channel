//! First build-system-segment incision bridge (r74 / 144-d — [r74-window-opening §4]
//! carrier; the first production proof of the 07 §3.3 Stage 2→3 signal "the
//! build system can be rewritten in the new language").
//!
//! Architecture (isomorphic to bootstrap_expander.rs — fifth instance of
//! the three-piece pattern, build segment):
//! - **Build logic**: `bootstrap/build.ktf` (kerf source
//!   implementing the
//!   semantic port of the prelude-injection decision `imports_prelude`,
//!   compiled via the seed target pipeline (compile_front_seed —
//!   r149 / 219-b S-expr removal window Batch A) and run on the Stage 0
//!   VM — entry `lbld-is-imports-prelude`, consuming **the same Stx-node
//!   wire protocol** as the expander input (six head fields) — zero new
//!   bridge protocols; the S-expr original build.krf is retained through
//!   the window as the parity oracle [parallel-piece strategy,
//!   principle 41]);
//! - **Bridge (this module)**: host-side invocation (`call_closure`) +
//!   Stx → VM node serialization (a same-shaped copy of
//!   bootstrap_expander.rs's `stx_to_node` — six head fields + literal tag
//!   shapes) + Bool result reconstruction;
//! - **Original Rust implementation (driver.rs `imports_prelude`)**:
//!   retired as parity oracle (`build_krf_parity_tests` comparison — the
//!   three-piece switchover isomorphic discipline).
//!
//! **Production switch (r74/144-d) is in effect**: the driver's
//! `resolve_prelude_imports` injection decision goes through this entry.
//! Switchover guards: `production_build_is_bootstrap` (liveness probe test) +
//! parity corpus (≥10 case dual-face equality).
//!
//! Heap contract: the build.ktf persistent heap carries global constants
//! (top-level definitions such as PRELUDE-MODULE) and per-call intermediate
//! products — GC uses (stack + frames + globals) as its root set, so
//! cross-call collection is safe.
//!
//! Concurrency contract: thread_local state (Rc values are not Sync) —
//! lazily compiled and loaded once per thread (same as the three-piece set).

use std::cell::RefCell;
use std::collections::HashMap;
use std::rc::Rc;

use kerf_compiler::BcProgram;
use kerf_runtime::{BoxedInput, Heap};
use kerf_span::SourceMap;
use kerf_syntax::{ScopeSet, Stx, SymbolTable};
use kerf_vm::{box_value, call_closure, run_program, Value, VmError};

use crate::builtins::register_globals;

/// build.ktf source (embedded at compile time — self-contained artifact,
/// same policy as the three-piece set; target-syntax payload — r149/219-b).
const BUILD_SRC: &str = include_str!("build.ktf");
/// build.ktf source filename (Span diagnostic attribution).
const BUILD_FILENAME: &str = "build.ktf";
/// Entry name (a top-level definition of build.ktf — the naming map
/// `build.ktf` identifier `lbld_is_imports_prelude` → symbol
/// `lbld-is-imports-prelude`, the same symbol the bridge looks up).
const ENTRY_NAME: &str = "lbld-is-imports-prelude";
/// r164 / 235-c (list-self-built-design.md D3): the kerf-list injection
/// decision's entry name (build.ktf identifier `lbld_is_imports_kerf_list`
/// → symbol `lbld-is-imports-kerf-list` — the module-name-parameterized
/// generalization family's entry; same wire protocol, same decision
/// discipline as ENTRY_NAME).
const ENTRY_LIST_NAME: &str = "lbld-is-imports-kerf-list";

/// Self-hosted build.ktf state (one per thread, lazily initialized).
struct BootstrapBuildState {
    /// build program bytecode (compiled via the seed pipeline).
    program: BcProgram,
    /// Loaded globals (builtins + build.ktf top-level definitions).
    globals: HashMap<kerf_syntax::Symbol, Value>,
    /// The `lbld-is-imports-prelude` entry symbol.
    entry_sym: kerf_syntax::Symbol,
    /// r164 / 235-c: the `lbld-is-imports-kerf-list` entry symbol (the
    /// kerf-list injection decision's entry — same state, second entry).
    entry_list_sym: kerf_syntax::Symbol,
    /// Source map of build.ktf (internal error diagnostic rendering).
    source_map: SourceMap,
    /// Persistent heap: global data + per-call products (GC root set includes globals).
    heap: Heap,
}

thread_local! {
    static BOOTSTRAP_BLD: RefCell<Option<BootstrapBuildState>> = const {
        RefCell::new(None)
    };
}

/// Self-hosted prelude-injection decision (**production path** — consumed
/// by the driver's `resolve_prelude_imports`).
///
/// Input = the top-level Stx form sequence produced by the read stage;
/// output = whether a kerf-prelude import is declared (any top-level import
/// form, or an import in the module header region). `Err` covers only
/// bridge/build.ktf internal defects (unreachable protocol arms —
/// fail-closed, the caller maps them to DriverError).
pub fn imports_prelude(forms: &[Stx], table: &SymbolTable) -> Result<bool, String> {
    with_build(|st| {
        // Stage 1: Stx → VM datum nodes (six-head-field protocol — same shape
        // as the expander bridge)
        let nodes: Vec<Value> = forms
            .iter()
            .map(|f| stx_to_node(f, table, &mut st.heap))
            .collect();
        let input = heap_list(&mut st.heap, nodes);
        // Stage 2: entry invocation (build.ktf run on the VM)
        let output = call_entry(st, input)?;
        // Stage 3: Bool result reconstruction (pure decision function — non-Bool
        // = protocol defect)
        match output {
            Value::Bool(b) => Ok(b),
            other => Err(format!(
                "[bootstrap-build] entry result is not Bool(build.ktf corrupted): {}",
                other.type_name()
            )),
        }
    })
}

/// Execute with thread-local state (lazy initialization).
fn with_build<T>(
    f: impl FnOnce(&mut BootstrapBuildState) -> Result<T, String>,
) -> Result<T, String> {
    BOOTSTRAP_BLD.with(|cell| {
        let mut opt = cell.borrow_mut();
        if opt.is_none() {
            match load_build() {
                Ok(state) => *opt = Some(state),
                Err(e) => return Err(e),
            }
        }
        f(opt.as_mut().expect("initialized above"))
    })
}

/// Compile and load build.ktf (seed target path — no recursion: the seed
/// pipeline compiles the self-hosted implementation, same P1 hard
/// constraint as the three-piece set; r149/219-b: the payload language
/// form switched to target syntax — compile_front_seed, the
/// reader/expander/compiler stages remain seed Rust).
fn load_build() -> Result<BootstrapBuildState, String> {
    let front = crate::driver::compile_front_seed(BUILD_SRC, BUILD_FILENAME).map_err(|e| {
        format!(
            "[bootstrap-build] build.ktf compile failed (seed target pipeline):{}",
            e.rendered
        )
    })?;
    build_state(front.program, front.table, front.source_map)
}

/// Build the build state from front-end outputs (single state-construction
/// implementation).
fn build_state(
    program: BcProgram,
    mut table: SymbolTable,
    source_map: SourceMap,
) -> Result<BootstrapBuildState, String> {
    // build.ktf has no I/O references (pure data transformation) — empty
    // grant (R9 fail-closed)
    let mut globals = register_globals(&mut table, &crate::capability::IoGrant::none());
    crate::builtins::resolve_hygiene_fallbacks(&program, &mut table, &mut globals);
    let mut heap = Heap::new();
    let outcome = run_program(&program, &mut globals, &mut heap)
        .map_err(|e| vm_error_to_internal(&e, &source_map))?;
    let _ = outcome; // The main prototype only executes top-level definitions (value meaningless)
    let entry_sym = table.intern(ENTRY_NAME);
    let entry_list_sym = table.intern(ENTRY_LIST_NAME);
    Ok(BootstrapBuildState {
        program,
        globals,
        entry_sym,
        entry_list_sym,
        source_map,
        heap,
    })
}

/// Invoke the build entry (host trust-layer programmatic call — §11).
fn call_entry(st: &mut BootstrapBuildState, input: Value) -> Result<Value, String> {
    let callee = st.globals.get(&st.entry_sym).cloned().ok_or_else(|| {
        format!(
            "[bootstrap-build] entry {} undefined (build.ktf corrupted)",
            ENTRY_NAME
        )
    })?;
    call_closure(
        &st.program,
        &mut st.globals,
        &mut st.heap,
        &callee,
        vec![input],
    )
    .map_err(|e| vm_error_to_internal(&e, &st.source_map))
}

/// r164 / 235-c: invoke the kerf-list decision entry (same wire protocol
/// and Bool-reconstruction discipline as `imports_prelude` — the generaliz
/// family's entry `lbld-is-imports-kerf-list`).
pub fn imports_list(forms: &[Stx], table: &SymbolTable) -> Result<bool, String> {
    with_build(|st| {
        // Stage 1: Stx → VM datum nodes (six-head-field protocol — same shape
        // as the expander bridge)
        let nodes: Vec<Value> = forms
            .iter()
            .map(|f| stx_to_node(f, table, &mut st.heap))
            .collect();
        let input = heap_list(&mut st.heap, nodes);
        // Stage 2: entry invocation (build.ktf run on the VM — second entry)
        let callee = st.globals.get(&st.entry_list_sym).cloned().ok_or_else(|| {
            format!(
                "[bootstrap-build] entry {} undefined (build.ktf corrupted)",
                ENTRY_LIST_NAME
            )
        })?;
        let output = call_closure(
            &st.program,
            &mut st.globals,
            &mut st.heap,
            &callee,
            vec![input],
        )
        .map_err(|e| vm_error_to_internal(&e, &st.source_map))?;
        // Stage 3: Bool result reconstruction (pure decision function — non-Bool
        // = protocol defect)
        match output {
            Value::Bool(b) => Ok(b),
            other => Err(format!(
                "[bootstrap-build] entry result is not Bool(build.ktf corrupted): {}",
                other.type_name()
            )),
        }
    })
}

/// VM error → internal error string (defensive path — a pure decision
/// function has no value-channel errors).
fn vm_error_to_internal(e: &VmError, sm: &SourceMap) -> String {
    use kerf_span::render_diagnostic;
    let diag = kerf_span::Diagnostic::error(
        Some(kerf_span::DiagnosticCode(2)),
        format!("bootstrap build.ktf internal error:{}", e.message),
        e.span,
    );
    render_diagnostic(&diag, sm)
}

// ---- Forward value bridge: Stx → VM datum nodes ----

/// `Stx` → datum node value `(tag s e exp scopes uni ...payload)` (the
/// six-head-field protocol — a same-shaped copy of bootstrap_expander.rs's
/// `stx_to_node`: symbol names carried as str; scope sets = int lists; the
/// uniform marker uni is always nil at the bridge entry).
fn stx_to_node(stx: &Stx, table: &SymbolTable, heap: &mut Heap) -> Value {
    let s = Value::Int(stx.span.start as i64);
    let e = Value::Int(stx.span.end as i64);
    let exp = Value::Int(stx.span.expansion_id as i64);
    let scopes = scope_list_value(&stx.scopes, heap);
    let uni = Value::Nil;
    let tag = |name: &str| Value::Symbol(Rc::from(name));
    let items: Vec<Value> = match &stx.datum {
        kerf_syntax::StxDatum::Symbol(sym) => vec![
            tag("sym"),
            s,
            e,
            exp,
            scopes,
            uni,
            Value::Str(Rc::from(table.name(*sym))),
        ],
        kerf_syntax::StxDatum::Literal(l) => match l {
            kerf_syntax::StxLiteral::Int(v) => {
                vec![tag("int"), s, e, exp, scopes, uni, Value::Int(*v)]
            }
            kerf_syntax::StxLiteral::Float(v) => {
                vec![tag("float"), s, e, exp, scopes, uni, Value::Float(*v)]
            }
            kerf_syntax::StxLiteral::Str(v) => {
                vec![tag("str"), s, e, exp, scopes, uni, Value::Str(v.clone())]
            }
            kerf_syntax::StxLiteral::Bool(b) => {
                vec![
                    tag(if *b { "true" } else { "false" }),
                    s,
                    e,
                    exp,
                    scopes,
                    uni,
                ]
            }
            kerf_syntax::StxLiteral::Nil => vec![tag("nil"), s, e, exp, scopes, uni],
        },
        kerf_syntax::StxDatum::List(children) => {
            let mut v = vec![tag("list"), s, e, exp, scopes, uni];
            v.extend(children.iter().map(|c| stx_to_node(c, table, heap)));
            v
        }
        kerf_syntax::StxDatum::Vector(children) => {
            let mut v = vec![tag("vec"), s, e, exp, scopes, uni];
            v.extend(children.iter().map(|c| stx_to_node(c, table, heap)));
            v
        }
    };
    heap_list(heap, items)
}

/// Scope set → int list value (iterated in ascending order).
fn scope_list_value(scopes: &ScopeSet, heap: &mut Heap) -> Value {
    let items: Vec<Value> = scopes.iter().map(|i| Value::Int(i as i64)).collect();
    heap_list(heap, items)
}

/// Construct a list value on the given heap (isomorphic to the `list`
/// builtin — same as the bridge self-check surface).
fn heap_list(heap: &mut Heap, items: Vec<Value>) -> Value {
    if items.is_empty() {
        return Value::Nil;
    }
    let mut acc = heap.alloc_boxed(BoxedInput::Nil);
    for v in items.into_iter().rev() {
        let elem = box_value(&v, heap);
        acc = heap.alloc_pair(elem, acc);
    }
    Value::Pair(acc)
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Production liveness probe (switchover guard — mirrors the
    /// three-piece set's is_loaded shape): lazy loading + same-thread reuse +
    /// empty-form zero hit.
    #[test]
    fn production_build_is_bootstrap() {
        let forms: Vec<Stx> = Vec::new();
        let table = SymbolTable::new();
        // The first decision triggers compile-and-load (lazy); empty forms → false
        assert!(!imports_prelude(&forms, &table).expect("empty form verdict"));
        // Same-thread reuse (state already loaded — the second call has zero
        // loading cost)
        assert!(!imports_prelude(&forms, &table).expect("empty form re-judged"));
        // State liveness: thread_local already initialized
        assert!(BOOTSTRAP_BLD.with(|cell| cell.borrow().is_some()));
    }
}

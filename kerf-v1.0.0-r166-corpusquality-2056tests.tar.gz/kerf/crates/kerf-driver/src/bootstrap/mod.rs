//! Bootstrap domain (r101 / 171-a domain directory layout + **r154 / 224-a
//! E6 endgame**: the S-expr removal window's close-out batch collapsed the
//! domain to its terminal shape — the bridge ↔ payload pairs are unified in
//! one directory, "bridge ↔ payload" physically adjacent [build.rs ↔
//! build.ktf etc.]).
//!
//! **In-domain module map (E6 terminal)**: the sole Reader bridge
//! [`reader`] (reader.ktf — renamed from reader.ktf at the
//! §11 terminal-integration instruction; the S-expr Reader bridge and its
//! reader.ktf predecessor were deleted, principle 41 demolition-after-
//! validation) + Expander bridge [`expander`] (E1-β) + Compiler bridge
//! [`compiler`] + HM decision surface [`check`] (r80 production switch) +
//! the build system's five incisions [`build`]/[`cli`]/[`test`]/
//! [`test_runner`]/[`cache`] (TD-032 fully retired) + shared value
//! utilities (this file's `as_int`/`as_str`/`as_symbol_name`/
//! `value_list_fields` — shared across bridges within the domain).
//!
//! **E6 close-out (r154 / 224-a — s-expr-removal-plan §4 E6 row + §6 exit
//! conditions)**: the seven seed `.krf` parallel originals + the
//! `target_reader_lex.krf` extraction oracle were deleted (the parity duty
//! they carried migrated to the fixpoint gate family, the two-path gates
//! and the deletion guard — the r120 precedent mirrored); the Rust S-expr
//! classic Reader face (lexer.rs/parser.rs/token.rs) was removed from
//! kerf-reader (target.rs is the sole Reader implementation — the §11
//! Rust-side terminal convergence); `compile_front_seed` retired (all
//! bridge loading goes through
//! `compile_front_seed`); this module's S-expr read bridge
//! (`read_source`/`lex_source` + the `BOOTSTRAP` state + `reader.ktf`
//! S-expr Reader artifact) was deleted with its duty complete (the
//! production `.krf` user-source read face retired at r153 / 223-a).
//!
//! Error-ordering contract (numeric overflow checked up front within the
//! VM's lexical scan order) and the heap/concurrency contracts live on the
//! target Reader bridge (see [`reader`]).

pub mod build;
pub mod cache;
pub mod check;
pub mod cli;
pub mod compiler;
pub mod expander;
pub mod reader;
pub mod test;
pub mod test_runner;

use kerf_reader::ReadError;
use kerf_runtime::Heap;
use kerf_span::Span;
use kerf_vm::{unbox_slot, Value};

/// Value list → field `Vec<Value>` (walks the heap's pair spine — shared
/// across the domain's bridges: the target Reader bridge's node/error
/// field extraction).
pub(crate) fn value_list_fields(v: &Value, heap: &Heap) -> Result<Vec<Value>, ReadError> {
    let mut out = Vec::new();
    let mut cur = v.clone();
    while let Value::Pair(r) = cur {
        let (car, cdr) = heap.get_pair(r).ok_or_else(internal_heap_error)?;
        out.push(unbox_slot(car, heap));
        cur = unbox_slot(cdr, heap);
    }
    Ok(out)
}

pub(crate) fn as_int(v: &Value) -> Result<i64, ReadError> {
    v.as_int()
        .ok_or_else(|| internal(&format!("expected int field, got {}", v.type_name())))
}

pub(crate) fn as_str(v: &Value) -> Result<&str, ReadError> {
    match v {
        Value::Str(s) => Ok(&**s),
        other => Err(internal(&format!(
            "expected str field, got {}",
            other.type_name()
        ))),
    }
}

pub(crate) fn as_symbol_name(v: &Value) -> Result<&str, ReadError> {
    match v {
        Value::Symbol(s) => Ok(&**s),
        other => Err(internal(&format!(
            "expected symbol field, got {}",
            other.type_name()
        ))),
    }
}

pub(crate) fn internal_heap_error() -> ReadError {
    internal("heap pair read failed")
}

pub(crate) fn internal(msg: &str) -> ReadError {
    ReadError::new(
        format!("[bootstrap] goal Reader internal error:{}", msg),
        Span::dummy(),
    )
}

// ---- Close-out guard (r102 / 172-b naming convention + r154 / 224-a E6
// ---- terminal: KTF_SOURCES covers every bootstrap corpus file) ----

#[cfg(test)]
mod naming_guard_tests {
    //! Close-out guard for the bootstrap corpus naming convention
    //! (r102 / 172-b — the machine anchor for the user directive "ban
    //! unclear naming forms such as -> and ?; use modern naming").
    //!
    //! Single source = [20-surface-conventions §8](docs/lang-design/20-surface-
    //! conventions.md) R1-R4 modern naming: R2 predicates = `is-` prefix
    //! (`?` suffix banned — cleared ahead of time on the registration
    //! surface by D63); R4 conversions = fully spelled `a-to-b` (`->`
    //! infix banned); R1 full words + R3 verbs, per the same table.
    //!
    //! **E6 terminal extension (r154 / 224-a)**: `KRF_SOURCES` was deleted
    //! with the seven .krf originals + the extraction oracle (the S-expr
    //! corpus surface is gone — exit condition 1); `KTF_SOURCES` now
    //! covers **all ten** bootstrap corpus files. `reader.ktf` (the
    //! target-language Reader, renamed from reader.ktf per §11)
    //! carries the documented R4 exemption: its `->` occurrences are the
    //! target lexer's effect-signature Token literal and parsing arms
    //! (the `[-> Eff]` skin face — functional payload, not legacy naming;
    //! the same exemption the pre-E6 guard held for reader.krf).
    //!
    //! Consistency between entry names (the `l*` bridge-prefix family)
    //! and the Rust-side `ENTRY_NAME` is carried by each bridge's
    //! liveness probe (the `production_*_is_bootstrap` family — any drift
    //! on the name surface makes entry lookup fail); this guard anchors
    //! the shape of .ktf definition names.

    /// All .ktf corpus files of the bootstrap domain (10 files — same
    /// source and path as each bridge's `include_str!`; the seven .krf
    /// originals + target_reader_lex.krf were deleted by the E6
    /// close-out batch r154 / 224-a, principle 41).
    const KTF_SOURCES: &[(&str, &str)] = &[
        ("preamble.ktf", include_str!("preamble.ktf")),
        ("reader.ktf", include_str!("reader.ktf")),
        ("compiler.ktf", include_str!("compiler.ktf")),
        ("expander.ktf", include_str!("expander.ktf")),
        ("build.ktf", include_str!("build.ktf")),
        ("cache.ktf", include_str!("cache.ktf")),
        ("check.ktf", include_str!("check.ktf")),
        ("cli.ktf", include_str!("cli.ktf")),
        ("test.ktf", include_str!("test.ktf")),
        ("test_runner.ktf", include_str!("test_runner.ktf")),
    ];

    /// Extract all `fn NAME(…)` function names and `let NAME =` value
    /// names from a target-syntax source (top-level and nested scanned
    /// alike; the `fn ` prefix anchors on word boundaries).
    fn defined_names_ktf(src: &str) -> Vec<&str> {
        let mut names = Vec::new();
        for (pos, _) in src.match_indices("fn ") {
            let rest = &src[pos + "fn ".len()..];
            let name: &str = rest
                .split(['(', ':', ' ', '\n', '\t', '<'])
                .next()
                .unwrap_or("");
            if !name.is_empty() {
                names.push(name);
            }
        }
        names
    }

    /// The naming guard on the full target-face corpus: ① `?`-suffixed
    /// `fn` names = zero (R2); ② `->` = zero tolerance (R4) — with the
    /// single documented exemption of `reader.ktf` (the target lexer's
    /// effect-signature Token payload — functional face, see the module
    /// note); comments scanned alike.
    #[test]
    fn ktf_naming_modern_closed() {
        for (file, src) in KTF_SOURCES {
            if *file != "reader.ktf" {
                assert!(
                    !src.contains("->"),
                    "{file}: goal corpus containing `->` old form(20 §8 R4 -- target face conversion always `a_to_b`/ `::` path; annotated interpret all zero basis and .krf face consistent)"
                );
            }
            for name in defined_names_ktf(src) {
                assert!(
                    !name.ends_with('?'),
                    "{file}: fn name `{name}` carries a `?` suffix (20 §8 R2 -- target face `is_` prefix modern predicate naming)"
                );
            }
        }
    }

    /// E6 deletion guard (exit condition 1 — the bootstrap-domain face):
    /// zero `.krf` files under the bootstrap directory. The repo-wide
    /// face (every crate + tests + examples) lives in the E6 gate family
    /// (`tests/v0/stage3/plan/`); this in-domain guard anchors the
    /// demolition at the source directory itself.
    #[test]
    fn bootstrap_domain_has_no_krf_files() {
        let dir = concat!(env!("CARGO_MANIFEST_DIR"), "/src/bootstrap");
        let mut krf_count = 0usize;
        if let Ok(entries) = std::fs::read_dir(dir) {
            for entry in entries.flatten() {
                if entry
                    .path()
                    .extension()
                    .and_then(|e| e.to_str())
                    .map(|e| e == "krf")
                    .unwrap_or(false)
                {
                    krf_count += 1;
                }
            }
        }
        assert_eq!(
            krf_count, 0,
            "bootstrap domain must hold zero .krf files (E6 close-out r154 / 224-a -- s-expr-removal-plan §6 exit condition 1)"
        );
    }
}

//! Third build-system-segment incision bridge (r86 / 156-b — TD-032 test
//! entry surface carrier; the third production proof of the 07 §3.3
//! Stage 2→3 signal "the build system can be rewritten in the new
//! language").
//!
//! Architecture (isomorphic to bootstrap_build/bootstrap_cli/
//! bootstrap_check — third instance of the incision-bridge pattern, test
//! entry surface):
//! - **Orchestration logic**: `bootstrap/test.ktf` (kerf source implementing
//!   the semantic port of the post-dispatch execution chain `ltest-report`
//!   of the cmd_test surface [report rendering + exit-code decision],
//!   compiled via the seed pipeline and run on the Stage 0 VM); it consumes
//!   the VM list of case-result four-field lists `(index name pass detail)`
//!   (constructed bridge-side — `TestReport` → `Value` direct conversion)
//!   and returns the two-element list `(output-str exit-code)`;
//! - **Bridge (this module)**: host-side invocation (`call_closure`
//!   single-argument injection) + result deconstruction (Str/Int field
//!   reconstruction);
//! - **Original Rust implementation (the former main.rs rendering loop)**:
//!   retired as parity oracle ([`report_seed`] — `test_krf_parity_tests`
//!   comparison, the three-piece switchover isomorphic discipline).
//!
//! **Production switch (r86/156-b) is in effect**: the root crate `kerf`'s
//! `main::cmd_test` report rendering + exit-code decision goes through this
//! entry. Switchover guards: [`production_test_is_bootstrap`] (liveness
//! probe test) + parity corpus (≥12 case dual-face equality + boundary
//! matrix).
//!
//! Heap contract: the test.ktf persistent heap carries global constants
//! (digit-table) and per-call intermediate products — GC uses
//! (stack + frames + globals) as its root set, so cross-call collection is
//! safe.
//!
//! Concurrency contract: thread_local state (Rc values are not Sync) —
//! lazily compiled and loaded once per thread (same as the existing
//! bridges). The CLI lazily loads once per process (single-threaded main —
//! one seed-compilation cost, same order of magnitude as prior incisions,
//! <1ms).

use std::cell::RefCell;
use std::collections::HashMap;
use std::rc::Rc;

use kerf_compiler::BcProgram;
use kerf_runtime::{BoxedInput, Heap};
use kerf_span::SourceMap;
use kerf_syntax::{Symbol, SymbolTable};
use kerf_vm::{box_value, call_closure, run_program, unbox_slot, Value, VmError};

use crate::builtins::register_globals;
use crate::driver::{TestCaseOutcome, TestReport};

/// test.ktf source (embedded at compile time — self-contained artifact,
/// same policy as the existing incisions).
const TEST_SRC: &str = include_str!("test.ktf");
/// test.ktf source filename (Span diagnostic attribution).
const TEST_FILENAME: &str = "test.ktf";
/// Entry name (a top-level definition of test.ktf).
const ENTRY_NAME: &str = "ltest-report";

// Production-path liveness counter (r86 — probe panel signal, mirroring the
// bootstrap_check `production_check_is_krf` shape).
thread_local! {
    static KRF_PRODUCTION_RUNS: std::cell::Cell<u64> = const {
        std::cell::Cell::new(0)
    };
}

/// Production rendering liveness probe: krf-path rendering count > 0 (this
/// thread).
/// Consumer = the production switchover guard test (empirical anchor that
/// cmd_test goes through the krf path).
pub fn production_test_is_bootstrap() -> bool {
    KRF_PRODUCTION_RUNS.with(|c| c.get() > 0)
}

/// Self-hosted test.ktf state (one per thread, lazily initialized).
struct BootstrapTestState {
    /// test program bytecode (compiled via the seed pipeline).
    program: BcProgram,
    /// Loaded globals (builtins + test.ktf top-level definitions).
    globals: HashMap<Symbol, Value>,
    /// The `ltest-report` entry symbol.
    entry_sym: Symbol,
    /// Source map of test.ktf (internal error diagnostic rendering).
    source_map: SourceMap,
    /// Persistent heap: global data + per-call products (GC root set includes globals).
    heap: Heap,
}

thread_local! {
    static BOOTSTRAP_TEST: RefCell<Option<BootstrapTestState>> = const {
        RefCell::new(None)
    };
}

/// Test report rendering + exit-code decision (**production path** —
/// consumed by the root crate's `main::cmd_test`).
///
/// Input = [`TestReport`] (case-result sequence); output = (full report
/// text, exit code). `Err` covers only bridge/test.ktf internal defects
/// (unreachable protocol arms — fail-closed; the caller exits with code 1
/// and renders the error — a bootstrap-phase defect surface separated from
/// the normal diagnostic channel).
pub fn report(report: &TestReport) -> Result<(String, i32), String> {
    let outcome = with_test(|st| {
        let callee = st.globals.get(&st.entry_sym).cloned().ok_or_else(|| {
            format!(
                "[bootstrap-test] entry {} undefined (test.ktf corrupted)",
                ENTRY_NAME
            )
        })?;
        let cases = heap_case_list(&mut st.heap, &report.cases);
        // Single-argument pass-through (case-result list — TestReport → Value
        // bridge-side construction)
        let output = call_closure(
            &st.program,
            &mut st.globals,
            &mut st.heap,
            &callee,
            vec![cases],
        )
        .map_err(|e| vm_error_to_internal(&e, &st.source_map))?;
        outcome_from_value(&output, &st.heap)
    })?;
    KRF_PRODUCTION_RUNS.with(|c| c.set(c.get() + 1));
    Ok(outcome)
}

/// Rust seed oracle (the retired role of the original main.rs cmd_test
/// rendering loop — parity comparison surface).
///
/// Semantic mirror (byte-for-byte of the pre-r86 rendering loop):
/// PASS/FAIL lines + optional detail lines + summary line + the all_passed
/// exit code.
pub fn report_seed(report: &TestReport) -> (String, i32) {
    let mut out = String::new();
    for case in &report.cases {
        if case.pass {
            out.push_str(&format!("PASS  {:>3} {}\n", case.index, case.name));
        } else {
            out.push_str(&format!("FAIL  {:>3} {}\n", case.index, case.name));
            if !case.detail.is_empty() {
                out.push_str(&format!("      └ {}\n", case.detail));
            }
        }
    }
    out.push_str(&format!(
        "pass {} / total {} (fail {})\n",
        report.passed,
        report.cases.len(),
        report.failed
    ));
    let code = if report.all_passed() { 0 } else { 1 };
    (out, code)
}

/// Execute with thread-local state (lazy initialization).
fn with_test<T>(f: impl FnOnce(&mut BootstrapTestState) -> Result<T, String>) -> Result<T, String> {
    BOOTSTRAP_TEST.with(|cell| {
        let mut opt = cell.borrow_mut();
        if opt.is_none() {
            match load_test() {
                Ok(state) => *opt = Some(state),
                Err(e) => return Err(e),
            }
        }
        f(opt.as_mut().expect("initialized above"))
    })
}

/// Compile and load test.ktf (seed path — no recursion: the seed pipeline
/// compiles the self-hosted implementation, same P1 hard constraint as the
/// existing bridges).
fn load_test() -> Result<BootstrapTestState, String> {
    let front = crate::driver::compile_front_seed(TEST_SRC, TEST_FILENAME).map_err(|e| {
        format!(
            "[bootstrap-test] test.ktf compile failed (seed pipeline):{}",
            e.rendered
        )
    })?;
    build_state(front.program, front.table, front.source_map)
}

/// Build test state from front-end outputs (single state-construction
/// implementation).
fn build_state(
    program: BcProgram,
    mut table: SymbolTable,
    source_map: SourceMap,
) -> Result<BootstrapTestState, String> {
    // test.ktf has no I/O references (pure data transformation — the report
    // text is printed by the host via the return value) — empty grant
    // (R9 fail-closed)
    let mut globals = register_globals(&mut table, &crate::capability::IoGrant::none());
    crate::builtins::resolve_hygiene_fallbacks(&program, &mut table, &mut globals);
    let mut heap = Heap::new();
    let outcome = run_program(&program, &mut globals, &mut heap)
        .map_err(|e| vm_error_to_internal(&e, &source_map))?;
    let _ = outcome; // The main prototype only executes top-level definitions (value meaningless)
    let entry_sym = table.intern(ENTRY_NAME);
    Ok(BootstrapTestState {
        program,
        globals,
        entry_sym,
        source_map,
        heap,
    })
}

/// Case-result sequence → VM list (each item a four-field list
/// `(index name pass detail)` — construction isomorphic to `heap_list`;
/// a same-shaped independent copy of the list construction in the
/// bootstrap_check bridge).
fn heap_case_list(heap: &mut Heap, cases: &[TestCaseOutcome]) -> Value {
    if cases.is_empty() {
        return Value::Nil;
    }
    let mut acc = heap.alloc_boxed(BoxedInput::Nil);
    for c in cases.iter().rev() {
        let elem = box_value(&case_to_value(c, heap), heap);
        acc = heap.alloc_pair(elem, acc);
    }
    Value::Pair(acc)
}

/// Single case result → four-field list value `(index name pass detail)`.
fn case_to_value(c: &TestCaseOutcome, heap: &mut Heap) -> Value {
    let fields = vec![
        Value::Int(c.index as i64),
        Value::Str(Rc::from(c.name.as_str())),
        Value::Bool(c.pass),
        Value::Str(Rc::from(c.detail.as_str())),
    ];
    let mut acc = heap.alloc_boxed(BoxedInput::Nil);
    for v in fields.into_iter().rev() {
        let elem = box_value(&v, heap);
        acc = heap.alloc_pair(elem, acc);
    }
    Value::Pair(acc)
}

/// VM result value → `(output-str exit-code)` (protocol defense:
/// non-two-element list / field-type mismatch = internal error,
/// fail-closed).
fn outcome_from_value(v: &Value, heap: &Heap) -> Result<(String, i32), String> {
    let fields = value_fields(v, heap)?;
    if fields.len() != 2 {
        return Err(format!(
            "[bootstrap-test] result non-two-element list({} item -- test.ktf corrupted)",
            fields.len()
        ));
    }
    let output = match &fields[0] {
        Value::Str(s) => s.to_string(),
        other => {
            return Err(format!(
                "[bootstrap-test] output field is not str({} -- test.ktf corrupted)",
                other.type_name()
            ))
        }
    };
    let code = match fields[1].as_int() {
        Some(i) => i as i32,
        None => {
            return Err(
                "[bootstrap-test] exit-code field is not int(test.ktf corrupted)".to_string(),
            )
        }
    };
    Ok((output, code))
}

/// List value → field sequence (bridge-side deconstruction — nil-terminator
/// guard).
fn value_fields(v: &Value, heap: &Heap) -> Result<Vec<Value>, String> {
    let mut out = Vec::new();
    let mut cur = v.clone();
    while let Value::Pair(r) = cur {
        let (car, cdr) = heap
            .get_pair(r)
            .ok_or_else(|| "[bootstrap-test] heap pair slot corrupted".to_string())?;
        out.push(unbox_slot(car, heap));
        cur = unbox_slot(cdr, heap);
    }
    if !matches!(cur, Value::Nil) {
        return Err(format!(
            "[bootstrap-test] result list tail is not nil({} -- test.ktf corrupted)",
            cur.type_name()
        ));
    }
    Ok(out)
}

/// VM error → internal error string (defensive path — a pure rendering
/// function has no value-channel errors).
fn vm_error_to_internal(e: &VmError, sm: &SourceMap) -> String {
    use kerf_span::render_diagnostic;
    let diag = kerf_span::Diagnostic::error(
        Some(kerf_span::DiagnosticCode(2)),
        format!("bootstrap test.ktf internal error:{}", e.message),
        e.span,
    );
    render_diagnostic(&diag, sm)
}

#[cfg(test)]
mod tests {
    use super::*;

    /// State liveness probe (panel signal for the parity tests — mirrors
    /// the prior incisions' is_* shape): lazy loading + same-thread reuse +
    /// empty-report protocol.
    #[test]
    fn test_state_lifecycle_probe() {
        let empty = TestReport {
            cases: Vec::new(),
            passed: 0,
            failed: 0,
        };
        let (out, code) = report(&empty).expect("empty report render");
        assert_eq!(out, "pass 0 / total 0 (fail 0)\n");
        assert_eq!(code, 0);
        // Same-thread reuse (state already loaded — the second call has zero
        // loading cost)
        let (out2, code2) = report(&empty).expect("empty report re-render");
        assert_eq!(out2, "pass 0 / total 0 (fail 0)\n");
        assert_eq!(code2, 0);
    }

    /// Production liveness probe (the call above already made the count > 0 —
    /// empirical probe panel signal).
    #[test]
    fn production_liveness_probe() {
        let r = TestReport {
            cases: vec![TestCaseOutcome {
                index: 1,
                name: "(= 1 1)".to_string(),
                pass: true,
                detail: String::new(),
            }],
            passed: 1,
            failed: 0,
        };
        let (out, code) = report(&r).expect("single case render");
        assert_eq!(out, "PASS    1 (= 1 1)\npass 1 / total 1 (fail 0)\n");
        assert_eq!(code, 0);
        assert!(production_test_is_bootstrap());
    }
}

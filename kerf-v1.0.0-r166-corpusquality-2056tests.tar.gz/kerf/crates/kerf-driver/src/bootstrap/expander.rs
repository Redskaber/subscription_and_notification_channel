//! Self-hosted Expander (E1-β: Expander rewritten in kerf, production
//! switch — including macro close-out).
//!
//! Architecture (07-bootstrap §3.2 hybrid-period composition; r6, the
//! same three-piece set as the self-hosted Reader):
//! - **Expansion logic**: `bootstrap/expander.ktf` (kerf source, target
//!   syntax — switch-window step ③ fourth batch r116 / 186-a, compiled
//!   to bytecode by the seed pipeline and run on the Stage 0 VM — the
//!   `lexp-expand-program` entry, aligned in interface shape with
//!   kerf-expander's `expand_program`, §11);
//! - **Bridge (this module)**: host-side invocation (`call_closure`) +
//!   bidirectional value-tree conversion (`Stx` → VM datum nodes carrying
//!   scope sets and expansion generations → VM core nodes → `CoreExpr`
//!   with scope sets/generations rebuilt);
//! - **Seed (kerf-expander)**: bootstrap loading (compiling expander.ktf
//!   via the seed Reader) +
//!   the oracle for parity tests (the classic role of a bootstrap seed
//!   — the two implementations cross-validate each other).
//!
//! **E1-β production switch**: the expansion stage of `compile_front`
//! (the production pipeline) goes through this module — both the reading
//! and expansion stages are self-hosted (the full production proposition
//! of 07 §3.3, "the language can express its own front end"). Switch
//! guard: driver `production_expander_is_bootstrap` (discriminates macro
//! products by the CoreExpr Span expansion generation — this bridge's
//! products preserve the source node generation).
//!
//! Heap contract: the Expander program's persistent heap carries global
//! data (KEYWORDS/SCOPE-NEXT/TRANSFORMERS etc.) plus per-call
//! intermediates — GC uses (stack + frames + globals) as its root set,
//! so reclamation across calls is safe; input node trees are constructed
//! on the persistent heap (one-shot, reclaimable after the call).
//!
//! Concurrency contract: thread_local state (Rc values are not Sync) —
//! lazily compiled and loaded once per thread.

use std::cell::RefCell;
use std::collections::HashMap;
use std::rc::Rc;

use kerf_compiler::BcProgram;
use kerf_core::{Capability, CoreExpr, LiteralValue, ModuleItem};
use kerf_expander::ExpandError;
use kerf_runtime::{BoxedInput, Heap};
use kerf_span::{render_diagnostic, Diagnostic, DiagnosticCode, FileId, Severity, SourceMap, Span};
use kerf_syntax::{ScopeSet, Stx, StxDatum, StxLiteral, Symbol, SymbolTable};
use kerf_vm::{box_value, call_closure, run_program, unbox_slot, Value, VmError};

use crate::bootstrap::{as_int, as_str, as_symbol_name, value_list_fields};
use crate::builtins::register_globals;

/// Expander source (embedded at compile time — the artifact is
/// self-contained, with no external file dependency).
/// Switch-window step ③ fourth batch (r116 / 186-a): the target-syntax
/// production artifact (expander.ktf) — the S-expr original (expander.krf)
/// was retained as the parity oracle through the window and deleted by the
/// E5 close-out cleanup batch (r120 / 190-a, principle 41); the dual-path
/// parity gates carry the ongoing equivalence duty. The r116
/// oracle normalization (bang-stripped registry-put) is mirrored
/// verbatim in the .ktf.
const EXPANDER_SRC: &str = include_str!("expander.ktf");
/// Expander source file name (for diagnostic rendering).
const EXPANDER_FILENAME: &str = "expander.ktf";
/// Entry name (a top-level definition of expander.krf).
const ENTRY_NAME: &str = "lexp-expand-program";
/// r129 / 199-b: the recovery-session split entries (the one-shot
/// ENTRY_NAME keeps its whole-list protocol; the reset entry runs once
/// per recovery session, the continuation entry runs per form WITHOUT
/// the reset — the user macro registrations persist across the forms,
/// mirroring the seed recover's ctx-persistence semantics).
const RESET_ENTRY_NAME: &str = "lexp-expand-program-reset";
const CONTINUE_ENTRY_NAME: &str = "lexp-expand-program-continue";
/// Derived-macro injection entry (r101 / 171-c — same-source injection
/// of the seven sugars' macro-ization: the same string set as the seed
/// side's `kerf_expander::derived_definition_sources`).
const INIT_DERIVED_ENTRY: &str = "lexp-init-derived";

/// Self-hosted Expander state (one per thread, lazily initialized).
struct BootstrapExpanderState {
    /// Expander program bytecode (compiled by the seed pipeline).
    program: BcProgram,
    /// Loaded globals (builtins + expander.krf top-level definitions).
    globals: HashMap<Symbol, Value>,
    /// `lexp-expand-program` entry symbol.
    entry_sym: Symbol,
    /// r129 / 199-b: the recovery-session split entry symbols (reset /
    /// continuation — interned at build time on the state's own table:
    /// Symbol indices are table-private, so the recover bridge must
    /// consume these rather than interning on a caller's table).
    reset_entry_sym: Symbol,
    continue_entry_sym: Symbol,
    /// The Expander's source map (for rendering internal error
    /// diagnostics).
    source_map: SourceMap,
    /// Persistent heap: global data + per-call products (the GC root set
    /// includes globals).
    heap: Heap,
}

thread_local! {
    static BOOTSTRAP_EXP: RefCell<Option<BootstrapExpanderState>> = const {
        RefCell::new(None)
    };
}

// r116 liveness probe: the bootstrap Expander state is built from the
// .ktf target-syntax corpus (counts actual load_expander executions —
// >0 = the target-corpus production load is live; isomorphic to the
// `compiler_bootstrap_is_ktf_corpus`
// probe family (the S-expr Reader's reader probe retired at E6 r154 / 224-a) — the wiring proof for switch-window step ③, fourth batch).
thread_local! {
    static EXPANDER_KTF_LOADS: std::cell::Cell<u32> = const { std::cell::Cell::new(0) };
}

/// bootstrap Expander state = .ktf target corpus (liveness probe — r116
/// step ③, fourth batch).
pub fn expander_bootstrap_is_ktf_corpus() -> bool {
    EXPANDER_KTF_LOADS.with(|c| c.get() > 0)
}

/// Self-hosted expansion entry: `Vec<Stx>` → `Vec<Rc<CoreExpr>>` (same
/// shape as `kerf_expander::expand_program` — the parity oracle
/// comparison surface).
///
/// **E1-β production path**: consumed by `compile_front` (including
/// macro expansion); the seed path
/// [`crate::driver::compile_front_seed`] (bootstrap loading and parity
/// oracle) still goes through the Rust `kerf_expander::expand_program`.
pub fn expand_program(
    forms: &[Stx],
    file_id: FileId,
    table: &mut SymbolTable,
) -> Result<Vec<ModuleItem>, ExpandError> {
    with_expander(|st| {
        // Stage 1: Stx → VM datum nodes (including the scope-set int
        // list; symbol names resolved via the user table — node names
        // carried as str, re-interned by the forward bridge)
        let nodes: Vec<Value> = forms
            .iter()
            .map(|f| stx_to_node(f, table, &mut st.heap))
            .collect();
        let input = heap_list(&mut st.heap, nodes);
        // Stage 2: entry invocation (expander.ktf runs on the VM — r49
        // item-position classification [declaration heads/do-splice] is
        // carried on the corpus side; the wire protocol text is
        // unchanged)
        let output = call_entry(st, input)?;
        // Stage 3: error check + item node bridge (r49 D59: the flat
        // 'define/'module/'require nodes are item-level forms —
        // classified by item_from_value; expression nodes go through
        // core_from_value)
        if let Some(e) = as_expand_err(&output, &st.heap, file_id) {
            return Err(e);
        }
        let mut out = Vec::new();
        let mut cur = output;
        while let Value::Pair(r) = cur {
            let (node_ref, rest) = st.heap.get_pair(r).ok_or_else(internal_heap_x)?;
            let node_val = unbox_slot(node_ref, &st.heap);
            out.push(item_from_value(&node_val, &st.heap, file_id, table)?);
            cur = unbox_slot(rest, &st.heap);
        }
        Ok(out)
    })
}

/// Item node bridge (r49 D59 — item-level classification of
/// 'define/'module/'require + expression nodes via core_from_value; a
/// nested declaration node in expression position = protocol invariant
/// violation, explicit failure [already rejected at expansion time on
/// the corpus side]).
fn item_from_value(
    v: &Value,
    heap: &Heap,
    file_id: FileId,
    table: &mut SymbolTable,
) -> Result<ModuleItem, ExpandError> {
    let fields = value_list_fields(v, heap).map_err(read_to_expand)?;
    if fields.len() < 4 {
        return Err(internal_x("core node field count abnormal"));
    }
    let tag = as_symbol_name(&fields[0]).map_err(read_to_expand)?;
    match tag {
        "define" => {
            if fields.len() != 6 {
                return Err(internal_x("define node field count abnormal"));
            }
            let s = as_int(&fields[1]).map_err(read_to_expand)?;
            let e = as_int(&fields[2]).map_err(read_to_expand)?;
            let exp = as_int(&fields[3]).map_err(read_to_expand)?;
            let span = Span {
                file_id,
                start: s as u32,
                end: e as u32,
                expansion_id: exp as u32,
            };
            let name = table.intern(as_str(&fields[4]).map_err(read_to_expand)?);
            let value = core_from_value(&fields[5], heap, file_id, table)?;
            Ok(ModuleItem::Define { name, value, span })
        }
        "module" => {
            if fields.len() < 7 {
                return Err(internal_x("module node field count abnormal"));
            }
            let s = as_int(&fields[1]).map_err(read_to_expand)?;
            let e = as_int(&fields[2]).map_err(read_to_expand)?;
            let exp = as_int(&fields[3]).map_err(read_to_expand)?;
            let span = Span {
                file_id,
                start: s as u32,
                end: e as u32,
                expansion_id: exp as u32,
            };
            let name = table.intern(as_str(&fields[4]).map_err(read_to_expand)?);
            let imports = symbol_vec_field(&fields[5], heap, table)?;
            let exports = symbol_vec_field(&fields[6], heap, table)?;
            let mut items = Vec::with_capacity(fields.len() - 7);
            for b in &fields[7..] {
                items.push(item_from_value(b, heap, file_id, table)?);
            }
            Ok(ModuleItem::Module {
                name,
                imports,
                exports,
                items,
                span,
            })
        }
        "require" => {
            let s = as_int(&fields[1]).map_err(read_to_expand)?;
            let e = as_int(&fields[2]).map_err(read_to_expand)?;
            let exp = as_int(&fields[3]).map_err(read_to_expand)?;
            let span = Span {
                file_id,
                start: s as u32,
                end: e as u32,
                expansion_id: exp as u32,
            };
            let mut caps = Vec::with_capacity(fields.len() - 4);
            for c in &fields[4..] {
                let cap_name = as_str(c).map_err(read_to_expand)?;
                let cap = match cap_name {
                    "read" => Capability::IoRead,
                    "write" => Capability::IoWrite,
                    other => {
                        return Err(internal_x(&format!("unknown capability item `{}`", other)));
                    }
                };
                caps.push(cap);
            }
            Ok(ModuleItem::Require { caps, span })
        }
        other => {
            // Expression node (fn/apply/if/var/literal/assign/let/perform/handle)
            let _ = other;
            Ok(ModuleItem::Expr(core_from_value(v, heap, file_id, table)?))
        }
    }
}

/// Liveness probe for the self-hosted Expander state (E1-β production
/// switch guard: whether the production compilation path really goes
/// through the VM Expander — after `loaded`, any program produced by
/// `compile_front` should make this probe true).
#[cfg(test)]
pub(crate) fn is_loaded() -> bool {
    BOOTSTRAP_EXP.with(|cell| cell.borrow().is_some())
}

/// Execute with thread-local state (lazily initialized).
fn with_expander<T>(
    f: impl FnOnce(&mut BootstrapExpanderState) -> Result<T, ExpandError>,
) -> Result<T, ExpandError> {
    BOOTSTRAP_EXP.with(|cell| {
        let mut opt = cell.borrow_mut();
        if opt.is_none() {
            match load_expander() {
                Ok(state) => *opt = Some(state),
                Err(e) => return Err(e),
            }
        }
        f(opt.as_mut().expect("initialized above"))
    })
}

/// Compile and load the Expander program (seed path — the Rust seed
/// target Reader + Rust Expander + Rust Compiler compiles expander.ktf,
/// not via the self-hosted path: the seed compiles the self-hosted
/// Expander, no recursion).
///
/// Switch-window step ③ fourth batch (r116 / 186-a — the r110 reader /
/// r114 compiler pattern): the read stage goes through
/// `compile_front_seed` (seed Reader `read_source`
/// — the naming map `_`→`-` single point of entry); expand/compile remain
/// seed (hard P1 convention — bootstrap loading is always the seed path).
fn load_expander() -> Result<BootstrapExpanderState, ExpandError> {
    EXPANDER_KTF_LOADS.with(|c| c.set(c.get() + 1));
    let front =
        crate::driver::compile_front_seed(EXPANDER_SRC, EXPANDER_FILENAME).map_err(|e| {
            expand_internal(&format!(
                "[bootstrap-exp] bootstrap Expander compile failed (seed pipeline):{}",
                e.rendered
            ))
        })?;
    build_state(front.program, front.table, front.source_map)
}

/// Build Expander state from front-end products (shared by the seed
/// loader and [`install_state`] — a single state-construction
/// implementation: register builtins + hygiene fallbacks + top-level
/// execution + entry interning).
fn build_state(
    program: BcProgram,
    mut table: SymbolTable,
    source_map: SourceMap,
) -> Result<BootstrapExpanderState, ExpandError> {
    // expander.krf has no I/O references (pure data transformation) —
    // empty grant (R9 fail-closed)
    let mut globals = register_globals(&mut table, &crate::capability::IoGrant::none());
    crate::builtins::resolve_hygiene_fallbacks(&program, &mut table, &mut globals);
    let mut heap = Heap::new();
    let outcome = run_program(&program, &mut globals, &mut heap)
        .map_err(|e| vm_error_to_expand(&e, &source_map))?;
    let _ = outcome; // The main prototype only executes top-level definitions (value unused)
                     // r101 / 171-c: same-source derived-macro injection (the seed side's
                     // DERIVED_SOURCES is the single source — after bridge conversion,
                     // registered as 'derived base items via lexp-init-derived; template
                     // Spans and hygiene behavior are same-source on both sides = the
                     // anchor for E1-β parity and B0/B1 disassembly-text parity)
    inject_derived_macros(&program, &mut globals, &mut heap, &mut table, &source_map)?;
    let entry_sym = table.intern(ENTRY_NAME);
    let reset_entry_sym = table.intern(RESET_ENTRY_NAME);
    let continue_entry_sym = table.intern(CONTINUE_ENTRY_NAME);
    Ok(BootstrapExpanderState {
        program,
        globals,
        entry_sym,
        reset_entry_sym,
        continue_entry_sym,
        source_map,
        heap,
    })
}

/// Install the given artifact as this thread's Expander state (gate B
/// fixpoint — the B₂ round's "treat B₁ as the new bootstrap program"
/// semantics: the self-hosted chain's artifact replaces the seed-loaded
/// state; i1-design §5 gate B + §7.4 isolated-run discipline).
///
/// The artifact must be compiled from expander.krf source (existence of
/// the `lexp-expand-program` entry is verified by actually constructing
/// the state).
pub fn install_state(
    program: BcProgram,
    table: SymbolTable,
    source_map: SourceMap,
) -> Result<(), ExpandError> {
    let state = build_state(program, table, source_map)?;
    BOOTSTRAP_EXP.with(|cell| *cell.borrow_mut() = Some(state));
    Ok(())
}

/// Unload this thread's Expander state (fixpoint isolated run — the
/// §7.4 fresh form; subsequent calls trigger a lazy seed reload).
pub fn reset_state() {
    BOOTSTRAP_EXP.with(|cell| *cell.borrow_mut() = None);
}

/// Call the Expander entry (programmatic invocation at the host trust
/// layer — §11, same level as run_program).
fn call_entry(st: &mut BootstrapExpanderState, input: Value) -> Result<Value, ExpandError> {
    let callee = st.globals.get(&st.entry_sym).cloned().ok_or_else(|| {
        expand_internal(&format!(
            "[bootstrap-exp] entry {} undefined (expander.ktf corrupted)",
            ENTRY_NAME
        ))
    })?;
    call_closure(
        &st.program,
        &mut st.globals,
        &mut st.heap,
        &callee,
        vec![input],
    )
    .map_err(|e| vm_error_to_expand(&e, &st.source_map))
}

/// Derived-macro injection (r101 / 171-c): read the same string set
/// from `derived_definition_sources()` → bridge via `stx_to_node` →
/// call `lexp-init-derived` to register them as 'derived transformer
/// base items of the self-hosted expander.
fn inject_derived_macros(
    program: &BcProgram,
    globals: &mut HashMap<Symbol, Value>,
    heap: &mut Heap,
    table: &mut SymbolTable,
    source_map: &SourceMap,
) -> Result<(), ExpandError> {
    let entry_sym = table.intern(INIT_DERIVED_ENTRY);
    let callee = globals.get(&entry_sym).cloned().ok_or_else(|| {
        expand_internal(&format!(
            "[bootstrap-exp] derived macro injection entry {} undefined (expander.ktf corrupted)",
            INIT_DERIVED_ENTRY
        ))
    })?;
    let mut forms: Vec<Value> = Vec::new();
    // E6 close-out (r154 / 224-a): the derived macro definitions arrive as
    // programmatic Stx datum trees (kerf-expander derived.rs single source
    // — the retired text sources' read_program parse is gone with the
    // classic S-expr Reader face).
    for (_name, form) in kerf_expander::derived_definition_forms(table) {
        forms.push(stx_to_node(&form, table, heap));
    }
    let defs_value = heap_list(heap, forms);
    let r = call_closure(program, globals, heap, &callee, vec![defs_value])
        .map_err(|e| vm_error_to_expand(&e, source_map))?;
    // true = success; ('err message start end) = injection failure
    // (defensive surface)
    if let Some(e) = as_expand_err(&r, heap, FileId::from(0u32)) {
        return Err(e);
    }
    Ok(())
}

/// VM error → ExpandError (defensive path: expansion errors are
/// returned as ('err ...) values, not through this channel — this path
/// only covers internal expander.ktf defects or the frame limit).
fn vm_error_to_expand(e: &VmError, sm: &SourceMap) -> ExpandError {
    let mut diag = Diagnostic::error(
        Some(DiagnosticCode(2)),
        format!("bootstrap Expander internal error:{}", e.message),
        e.span,
    );
    for t in &e.trace {
        diag = diag.with_child(Severity::Note, "call site", t.span);
    }
    ExpandError {
        message: render_diagnostic(&diag, sm),
        span: Span::dummy(),
    }
}

// ---- Reverse value bridge: Stx → VM datum nodes ----

/// `Stx` → datum node value `(tag s e exp scopes ...)` (symbol names
/// carried as str; scope set = int list — the forward bridge rebuilds it
/// with ScopeSet's sorted-dedup semantics; exp = expansion generation
/// (Span.expansion_id — E1-β macro parity: instantiate's Span
// union guard relies on generation equality; bridge-side input is always source generation 0).
fn stx_to_node(stx: &Stx, table: &SymbolTable, heap: &mut Heap) -> Value {
    let s = Value::Int(stx.span.start as i64);
    let e = Value::Int(stx.span.end as i64);
    let exp = Value::Int(stx.span.expansion_id as i64);
    let scopes = scope_list_value(&stx.scopes, heap);
    // Six-head field protocol (r18/40-f): uni = the uniform-scope mark
    // (the mirror of the seed side's uniform_tag; always nil at the
    // bridge entry — the mark is set by retag on the krf side)
    let uni = Value::Nil;
    let tag = |name: &str| Value::Symbol(Rc::from(name));
    let items: Vec<Value> = match &stx.datum {
        StxDatum::Symbol(sym) => vec![
            tag("sym"),
            s,
            e,
            exp,
            scopes,
            uni,
            Value::Str(Rc::from(table.name(*sym))),
        ],
        StxDatum::Literal(l) => match l {
            StxLiteral::Int(v) => vec![tag("int"), s, e, exp, scopes, uni, Value::Int(*v)],
            StxLiteral::Float(v) => {
                vec![tag("float"), s, e, exp, scopes, uni, Value::Float(*v)]
            }
            StxLiteral::Str(v) => {
                vec![tag("str"), s, e, exp, scopes, uni, Value::Str(v.clone())]
            }
            StxLiteral::Bool(b) => {
                vec![
                    tag(if *b { "true" } else { "false" }),
                    s,
                    e,
                    exp,
                    scopes,
                    uni,
                ]
            }
            StxLiteral::Nil => vec![tag("nil"), s, e, exp, scopes, uni],
        },
        StxDatum::List(children) => {
            let mut v = vec![tag("list"), s, e, exp, scopes, uni];
            v.extend(children.iter().map(|c| stx_to_node(c, table, heap)));
            v
        }
        StxDatum::Vector(children) => {
            let mut v = vec![tag("vec"), s, e, exp, scopes, uni];
            v.extend(children.iter().map(|c| stx_to_node(c, table, heap)));
            v
        }
    };
    heap_list(heap, items)
}

/// Scope set → int list value (iterated in ascending order).
fn scope_list_value(scopes: &ScopeSet, heap: &mut Heap) -> Value {
    let items: Vec<Value> = scopes.iter().map(|i| Value::Int(i as i64)).collect();
    heap_list(heap, items)
}

/// Build a list value on the given heap (isomorphic to the `list`
/// builtin — the same as the bridge's self-check surface).
fn heap_list(heap: &mut Heap, items: Vec<Value>) -> Value {
    if items.is_empty() {
        return Value::Nil;
    }
    let mut acc = heap.alloc_boxed(BoxedInput::Nil);
    for v in items.into_iter().rev() {
        let elem = box_value(&v, heap);
        acc = heap.alloc_pair(elem, acc);
    }
    Value::Pair(acc)
}

// ---- Forward value bridge: VM core nodes → CoreExpr ----

/// ('err message start end) → ExpandError (returns None for non-error
/// forms; the Span carries the user's file_id — the error position lies
/// in the user's source text).
fn as_expand_err(v: &Value, heap: &Heap, file_id: FileId) -> Option<ExpandError> {
    if let Value::Pair(r) = v {
        if let Some((car, _)) = heap.get_pair(*r) {
            if let Value::Symbol(s) = unbox_slot(car, heap) {
                if &*s == "err" {
                    let fields = value_list_fields(v, heap).ok()?;
                    if fields.len() != 4 {
                        return None;
                    }
                    let msg = as_str(&fields[1]).ok()?.to_string();
                    let s = as_int(&fields[2]).ok()?;
                    let e = as_int(&fields[3]).ok()?;
                    return Some(ExpandError {
                        message: msg,
                        span: Span::new(file_id, s as u32, e as u32),
                    });
                }
            }
        }
    }
    None
}

/// core node value `(tag s e exp ...)` → `CoreExpr` (symbol names
/// interned via the user table — the same intern entry point as the
/// seed; scope sets rebuilt with ScopeSet's sorted-dedup semantics; exp
/// = expansion generation — preserved after the E1-β production switch
/// (the production channel of the macro-phase observability diagnostic
/// "expansion N" marker, §19.1).
fn core_from_value(
    v: &Value,
    heap: &Heap,
    file_id: FileId,
    table: &mut SymbolTable,
) -> Result<Rc<CoreExpr>, ExpandError> {
    let fields = value_list_fields(v, heap).map_err(read_to_expand)?;
    if fields.len() < 4 {
        return Err(internal_x("core node field count abnormal"));
    }
    let tag = as_symbol_name(&fields[0]).map_err(read_to_expand)?;
    let s = as_int(&fields[1]).map_err(read_to_expand)?;
    let e = as_int(&fields[2]).map_err(read_to_expand)?;
    let exp = as_int(&fields[3]).map_err(read_to_expand)?;
    let span = Span {
        file_id,
        start: s as u32,
        end: e as u32,
        expansion_id: exp as u32,
    };
    let rest = &fields[4..];
    match tag {
        "literal" => Ok(Rc::new(CoreExpr::Literal {
            value: literal_from_value(
                rest.first()
                    .ok_or_else(|| internal_x("literal missing value"))?,
                heap,
            )?,
            span,
        })),
        "var" => {
            let name = str_field(rest, 0)?;
            let scopes = scope_set_field(rest, 1, heap)?;
            Ok(Rc::new(CoreExpr::Var {
                name: table.intern(name),
                scopes,
                span,
            }))
        }
        "apply" => {
            let fn_expr = core_from_value(field(rest, 0)?, heap, file_id, table)?;
            let mut args = Vec::with_capacity(rest.len().saturating_sub(1));
            for a in &rest[1..] {
                args.push(core_from_value(a, heap, file_id, table)?);
            }
            Ok(Rc::new(CoreExpr::Apply {
                fn_expr,
                args,
                span,
            }))
        }
        "if" => {
            if rest.len() != 3 {
                return Err(internal_x("if node field count abnormal"));
            }
            Ok(Rc::new(CoreExpr::If {
                cond: core_from_value(&rest[0], heap, file_id, table)?,
                then_branch: core_from_value(&rest[1], heap, file_id, table)?,
                else_branch: core_from_value(&rest[2], heap, file_id, table)?,
                span,
            }))
        }
        "fn" => {
            if rest.len() != 3 {
                return Err(internal_x("fn node field count abnormal"));
            }
            let name_fields = value_list_fields(&rest[0], heap).map_err(read_to_expand)?;
            let mut names: Vec<Symbol> = name_fields
                .iter()
                .map(|n| {
                    let name = as_str(n).map_err(read_to_expand)?;
                    Ok(table.intern(name))
                })
                .collect::<Result<Vec<Symbol>, ExpandError>>()?;
            let mut param_scopes: Vec<ScopeSet> = value_list_fields(&rest[1], heap)
                .map_err(read_to_expand)?
                .iter()
                .map(|sc| scope_set_from_value(sc, heap))
                .collect::<Result<Vec<_>, _>>()?;
            // r165 / 236-c (variadic-rest-design.md D2-c): the rest marker
            // rides the params list — `(... rest)`; the scopes list is
            // parallel (the marker's entry is a placeholder skipped here).
            let mut rest_param: Option<(Symbol, ScopeSet)> = None;
            if let Some(mark) = names.iter().position(|n| table.name(*n) == "...") {
                if mark + 2 != names.len() {
                    return Err(internal_x("fn rest parameter must be the last parameter"));
                }
                let rest_name = names[mark + 1];
                let rest_scopes = param_scopes.get(mark + 1).cloned().unwrap_or_default();
                names.truncate(mark);
                param_scopes.truncate(mark);
                rest_param = Some((rest_name, rest_scopes));
            }
            let body = core_from_value(&rest[2], heap, file_id, table)?;
            Ok(Rc::new(CoreExpr::Fn {
                params: names,
                param_scopes,
                rest: rest_param,
                body,
                span,
            }))
        }
        "assign" => {
            if rest.len() != 3 {
                return Err(internal_x("assign node field count abnormal"));
            }
            let name = table.intern(as_str(&rest[0]).map_err(read_to_expand)?);
            let scopes = scope_set_from_value(&rest[1], heap)?;
            let value = core_from_value(&rest[2], heap, file_id, table)?;
            Ok(Rc::new(CoreExpr::Assign {
                name,
                scopes,
                value,
                span,
            }))
        }
        // r49 D59: the 'define item-level form belongs to item_from_value —
        // in expression position it is a protocol invariant violation
        // (already rejected at expansion time on the corpus side —
        // explicit failure here)
        "let" => {
            // r45/E5 S3 structural arm: bridge tag 'let (fields =
            // name/scopes/value/body — symmetric with assign's
            // name+scopes pattern; symmetric with bootstrap_compiler's
            // core_to_node; the 'do tag is retired)
            if rest.len() != 4 {
                return Err(internal_x("let node field count abnormal"));
            }
            let name = table.intern(as_str(&rest[0]).map_err(read_to_expand)?);
            let scopes = scope_set_from_value(&rest[1], heap)?;
            let value = core_from_value(&rest[2], heap, file_id, table)?;
            let body = core_from_value(&rest[3], heap, file_id, table)?;
            Ok(Rc::new(CoreExpr::Let {
                name,
                scopes,
                value,
                body,
                span,
            }))
        }
        // r49 D59: the 'module/'require item-level forms belong to
        // item_from_value — in expression position they are protocol
        // invariant violations (already rejected at expansion time on
        // the corpus side)
        // r25/42-f effect arms (node protocol consistent with the
        // compiler.krf contract: ('perform s e x effect node) — an
        // expander.krf expansion product)
        "perform" => {
            if rest.len() != 1 {
                return Err(internal_x("perform node field count abnormal"));
            }
            let effect = core_from_value(&rest[0], heap, file_id, table)?;
            Ok(Rc::new(CoreExpr::Perform { effect, span }))
        }
        // ('handle s e x tagstr payload-name payload-scopes resume-name
        //   resume-scopes handler-node body-node) — the two binders'
        //   scope sets are shaped like the fn node's
        "handle" => {
            if rest.len() != 7 {
                return Err(internal_x("handle node field count abnormal"));
            }
            let tag: std::rc::Rc<str> =
                std::rc::Rc::from(as_str(&rest[0]).map_err(read_to_expand)?);
            let payload_var = table.intern(as_str(&rest[1]).map_err(read_to_expand)?);
            let payload_scopes = scope_set_from_value(&rest[2], heap)?;
            let resume_var = table.intern(as_str(&rest[3]).map_err(read_to_expand)?);
            let resume_scopes = scope_set_from_value(&rest[4], heap)?;
            let handler_body = core_from_value(&rest[5], heap, file_id, table)?;
            let body = core_from_value(&rest[6], heap, file_id, table)?;
            Ok(Rc::new(CoreExpr::Handle {
                tag,
                payload_var,
                payload_scopes,
                resume_var,
                resume_scopes,
                handler_body,
                body,
                span,
            }))
        }
        // r136 / 206-b (TD-033 — D13): ('handle-group s e x arm₁ … arm_N
        // body-node) — arm node = (tagstr pname pscopes rname rscopes
        // hnode) plain list (an expander.ktf expansion product)
        "handle-group" => {
            if rest.len() < 3 {
                return Err(internal_x("handle-group node field count abnormal"));
            }
            let n_arms = rest.len() - 1;
            let mut arms: Vec<kerf_core::HandleArm> = Vec::with_capacity(n_arms);
            for item in &rest[..n_arms] {
                let arm_fields = value_list_fields(item, heap).map_err(read_to_expand)?;
                if arm_fields.len() != 6 {
                    return Err(internal_x("handle-group arm node field count abnormal"));
                }
                let tag: std::rc::Rc<str> =
                    std::rc::Rc::from(as_str(&arm_fields[0]).map_err(read_to_expand)?);
                let payload_var = table.intern(as_str(&arm_fields[1]).map_err(read_to_expand)?);
                let payload_scopes = scope_set_from_value(&arm_fields[2], heap)?;
                let resume_var = table.intern(as_str(&arm_fields[3]).map_err(read_to_expand)?);
                let resume_scopes = scope_set_from_value(&arm_fields[4], heap)?;
                let handler_body = core_from_value(&arm_fields[5], heap, file_id, table)?;
                arms.push(kerf_core::HandleArm {
                    tag,
                    payload_var,
                    payload_scopes,
                    resume_var,
                    resume_scopes,
                    handler_body,
                });
            }
            let body = core_from_value(&rest[n_arms], heap, file_id, table)?;
            Ok(Rc::new(CoreExpr::HandleGroup { arms, body, span }))
        }
        other => Err(internal_x(&format!("unknown core node kind '{}'", other))),
    }
}

/// VM value → literal value (quote products: pair trees rebuilt
/// recursively via heap walks).
fn literal_from_value(v: &Value, heap: &Heap) -> Result<LiteralValue, ExpandError> {
    match v {
        Value::Int(i) => Ok(LiteralValue::Int(*i)),
        Value::Float(f) => Ok(LiteralValue::Float(*f)),
        Value::Str(s) => Ok(LiteralValue::Str(s.clone())),
        Value::Bool(b) => Ok(LiteralValue::Bool(*b)),
        Value::Nil => Ok(LiteralValue::Nil),
        Value::Symbol(s) => Ok(LiteralValue::Symbol(s.clone())),
        Value::Pair(r) => {
            let (car, cdr) = heap.get_pair(*r).ok_or_else(internal_heap_x)?;
            let car_l = literal_from_value(&unbox_slot(car, heap), heap)?;
            let cdr_l = literal_from_value(&unbox_slot(cdr, heap), heap)?;
            Ok(LiteralValue::Pair(Rc::new(car_l), Rc::new(cdr_l)))
        }
        other => Err(internal_x(&format!(
            "does not support literal value {}",
            other.type_name()
        ))),
    }
}

// ---- Field access helpers ----

fn field(rest: &[Value], idx: usize) -> Result<&Value, ExpandError> {
    rest.get(idx)
        .ok_or_else(|| internal_x("core node field missing"))
}

fn str_field(rest: &[Value], idx: usize) -> Result<&str, ExpandError> {
    as_str(field(rest, idx)?).map_err(read_to_expand)
}

/// int list value → ScopeSet (sorted dedup — the same semantics as
/// ScopeSet::from_iter_scopes).
fn scope_set_from_value(v: &Value, heap: &Heap) -> Result<ScopeSet, ExpandError> {
    let fields = value_list_fields(v, heap).map_err(read_to_expand)?;
    let ids = fields
        .iter()
        .map(|f| as_int(f).map_err(read_to_expand))
        .collect::<Result<Vec<i64>, _>>()?;
    Ok(ScopeSet::from_iter_scopes(
        ids.into_iter().map(|i| i as u32),
    ))
}

fn scope_set_field(rest: &[Value], idx: usize, heap: &Heap) -> Result<ScopeSet, ExpandError> {
    scope_set_from_value(field(rest, idx)?, heap)
}

/// str list value → Symbol vector (interned via the user table).
fn symbol_vec_field(
    v: &Value,
    heap: &Heap,
    table: &mut SymbolTable,
) -> Result<Vec<Symbol>, ExpandError> {
    let fields = value_list_fields(v, heap).map_err(read_to_expand)?;
    let mut out = Vec::with_capacity(fields.len());
    for f in &fields {
        out.push(table.intern(as_str(f).map_err(read_to_expand)?));
    }
    Ok(out)
}

/// ReadError → ExpandError (error-surface conversion for the shared
/// walk helpers — message and Span preserved faithfully).
fn read_to_expand(e: kerf_reader::ReadError) -> ExpandError {
    ExpandError {
        message: e.message,
        span: e.span,
    }
}

fn internal_heap_x() -> ExpandError {
    expand_internal("heap pair read failed")
}

fn internal_x(msg: &str) -> ExpandError {
    expand_internal(msg)
}

fn expand_internal(msg: &str) -> ExpandError {
    ExpandError {
        message: format!("[bootstrap-exp] bootstrap Expander internal error:{}", msg),
        span: Span::dummy(),
    }
}

/// Form-level recovery expansion (self-hosted bridge path — TD-013
/// implementation, batch G / 38-e).
///
/// Calls `lexp-expand-program` form by form with a single-element list
/// (zero changes to the expander.krf protocol — the call granularity is
/// switched on the bridge side); a single-form error (an expansion error
/// value or a VM internal path) → collect + skip + continue; a full
/// collector (128) terminates early.
///
/// Isomorphic to `kerf_expander::expand_program_recover` (the seed
/// path) — the two expanders' recovery behavior is aligned (parity
/// discipline; r6/r14 same-shape precedents).
pub fn expand_program_recover(
    forms: &[Stx],
    file_id: FileId,
    table: &mut SymbolTable,
) -> Result<kerf_expander::RecoveredExpansion, ExpandError> {
    with_expander(|st| {
        let mut out = kerf_expander::RecoveredExpansion::default();
        // r129 / 199-b: reset ONCE before the form loop (the split reset
        // entry), then continue per form WITHOUT the reset — the user
        // macro registrations persist across the forms. The doc comment's
        // "persists across calls" assumption is now true by construction
        // (previously the unsplit entry reset TRANSFORMERS on every
        // per-form call, so a user define-syntax registered on one form
        // was lost before the next form's macro call reached the
        // registry — check-face E0022 misfires on every user-macro
        // program; the seed recover's ctx-persistence is the semantics
        // being mirrored).
        {
            let reset_sym = st.reset_entry_sym;
            let callee = st.globals.get(&reset_sym).cloned().ok_or_else(|| {
                expand_internal(&format!(
                    "[bootstrap-exp] recovery session reset entry {} undefined (expander.ktf corrupted)",
                    RESET_ENTRY_NAME
                ))
            })?;
            call_closure(&st.program, &mut st.globals, &mut st.heap, &callee, vec![])
                .map_err(|e| vm_error_to_expand(&e, &st.source_map))?;
        }
        let continue_sym = st.continue_entry_sym;
        for form in forms {
            if out.diags.is_full() {
                // Diagnostic-storm protection (r7 design §2) — the
                // remaining forms are dropped, i.e. truncation
                out.diags.mark_truncated();
                break;
            }
            // Stage 1: single form → VM datum node + single-element
            // input list
            let node = stx_to_node(form, table, &mut st.heap);
            let input = heap_list(&mut st.heap, vec![node]);
            // Stage 2: single-element list invocation (one form at a
            // time — through the NO-reset continuation entry: the user
            // macro registrations persist across the per-form calls)
            let callee = st.globals.get(&continue_sym).cloned().ok_or_else(|| {
                expand_internal(&format!(
                    "[bootstrap-exp] recovery session continuation entry {} undefined (expander.ktf corrupted)",
                    CONTINUE_ENTRY_NAME
                ))
            })?;
            match call_closure(
                &st.program,
                &mut st.globals,
                &mut st.heap,
                &callee,
                vec![input],
            ) {
                Ok(output) => {
                    // Stage 3: error value check (expansion errors are
                    // returned as ('err ...) values)
                    if let Some(e) = as_expand_err(&output, &st.heap, file_id) {
                        out.diags.push(e);
                        continue;
                    }
                    // Success: item node bridge (r49 D59 — classified
                    // by item_from_value)
                    let mut cur = output;
                    while let Value::Pair(r) = cur {
                        let (node_ref, rest) = st.heap.get_pair(r).ok_or_else(internal_heap_x)?;
                        let node_val = unbox_slot(node_ref, &st.heap);
                        out.core
                            .push(item_from_value(&node_val, &st.heap, file_id, table)?);
                        cur = unbox_slot(rest, &st.heap);
                    }
                }
                Err(e) => {
                    // VM internal-path error (an expander.krf defect or
                    // the frame limit) — collect and continue (recovery
                    // semantics); repeated internal errors indicate an
                    // expander.krf-level defect, backstopped by the cap
                    out.diags.push(vm_error_to_expand(&e, &st.source_map));
                }
            }
        }
        Ok(out)
    })
}

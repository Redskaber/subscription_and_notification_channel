//! Fourth build-system-segment incision bridge (r87 / 157-b — TD-032 test
//! runner surface carrier; the fourth production proof of the 07 §3.3
//! Stage 2→3 signal "the build system can be rewritten in the new language").
//!
//! Architecture (isomorphic to bootstrap_build/bootstrap_cli/bootstrap_check/
//! bootstrap_test — fourth instance of the incision-bridge pattern, test
//! runner surface):
//! - **Orchestration logic**: `bootstrap/test_runner.ktf` (kerf source
//!   implementing the semantic port of `driver.rs test_source` prelude/case
//!   splitting and recovery orchestration [splitting decision + numbering +
//!   name truncation + per-case callback orchestration + result
//!   aggregation], compiled via the seed pipeline and run on the Stage 0
//!   VM); the entry `ltest-run` consumes the item-metadata list + the
//!   case-execution callback (Foreign function value **parameter
//!   pass-through** — lexical binding, avoiding the global visibility
//!   surface) and returns the case-result four-field list;
//! - **Bridge (this module)**: host-side invocation + item-metadata
//!   projection (`ModuleItem` variants → kind tag + fully rendered name) +
//!   callback construction (captures the front-end outputs — nested VM
//!   execution [`run_case` independent heap/globals: case isolation] +
//!   effect-boundary short-circuit/recovery [`handle_escape`/
//!   `TestFailure` — the mechanical layer of recovery orchestration]) +
//!   result deconstruction (`TestReport` reconstruction);
//! - **Original Rust implementation (`driver.rs test_source`)**: retired
//!   as the parity oracle (`test_runner_krf_parity_tests` comparison — the
//!   three-piece switchover isomorphic discipline).
//!
//! **Production switch (r87/157-b) is in effect**: the root crate `kerf`'s
//! `main::cmd_test` routes case splitting + execution orchestration +
//! aggregation through this entry. Switchover guards:
//! [`production_test_runner_is_bootstrap`] (liveness probe test) + parity
//! corpus (dual-face full-chain equality + full splitting matrix + real
//! corpus end-to-end).
//!
//! Heap contract: the test_runner.ktf persistent heap carries global
//! constants and per-call intermediate products — GC uses (stack + frames +
//! globals) as its root set, so cross-call collection is safe; callback
//! nested execution uses an independent heap/globals (mirroring the
//! `run_case` layer-2 case-isolation semantics — the outer heap only
//! carries the return-value boxing after nested execution completes).
//!
//! Concurrency contract: thread_local state (Rc values are not Sync) —
//! lazily compiled and loaded once per thread (same as the existing
//! bridges). The CLI lazily loads once per process (single-threaded main —
//! one seed-compilation cost, same order of magnitude as prior incisions,
//! <1ms).

use std::cell::RefCell;
use std::collections::HashMap;
use std::rc::Rc;

use kerf_compiler::BcProgram;
use kerf_core::{CoreExpr, ModuleItem};
use kerf_runtime::{BoxedInput, Heap, RuntimeError};
use kerf_span::SourceMap;
use kerf_syntax::{Symbol, SymbolTable};
use kerf_vm::{box_value, call_closure, run_program, unbox_slot, BuiltinFn, Value, VmError};

use crate::builtins::register_globals;
use crate::capability::{IoGrant, IoRequirements};
use crate::driver::{
    resolve_symbol, run_case, DriverError, FrontOutput, TestCaseOutcome, TestFailure, TestReport,
};

/// test_runner.ktf source (embedded at compile time — self-contained
/// artifact, same policy as the existing incisions).
const RUNNER_SRC: &str = include_str!("test_runner.ktf");
/// test_runner.ktf source filename (Span diagnostic attribution).
const RUNNER_FILENAME: &str = "test_runner.ktf";
/// Entry name (a top-level definition of test_runner.ktf).
const ENTRY_NAME: &str = "ltest-run";

// Production-path liveness counter (r87 — probe panel signal, mirroring the
// bootstrap_test `production_test_is_bootstrap` shape).
thread_local! {
    static KRF_PRODUCTION_RUNS: std::cell::Cell<u64> = const {
        std::cell::Cell::new(0)
    };
}

/// Production runner liveness probe: krf-path orchestration count > 0 (this thread).
/// Consumer = the production switchover guard test (empirical anchor that
/// cmd_test goes through the krf path).
pub fn production_test_runner_is_bootstrap() -> bool {
    KRF_PRODUCTION_RUNS.with(|c| c.get() > 0)
}

/// Test runner error (dual channel — the runner-surface isomorph of the
/// r86 report bridge's Err(String) separation philosophy).
#[derive(Debug)]
pub enum TestRunnerError {
    /// Front-end compilation error (real diagnostic channel — same-source
    /// DriverError as `test_source`).
    Front(DriverError),
    /// Internal defect of the self-hosted test_runner.ktf (fail-closed — a
    /// bootstrap-phase defect surface; parity corpus + full-suite
    /// zero-regression guard its unreachability).
    Internal(String),
}

impl std::fmt::Display for TestRunnerError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            TestRunnerError::Front(e) => write!(f, "{}", e),
            TestRunnerError::Internal(msg) => write!(f, "[bootstrap-test-runner] {}", msg),
        }
    }
}

/// Self-hosted test_runner.ktf state (one per thread, lazily initialized).
struct BootstrapTestRunnerState {
    /// test_runner program bytecode (compiled via the seed pipeline).
    program: BcProgram,
    /// Loaded globals (builtins + test_runner.ktf top-level definitions).
    globals: HashMap<Symbol, Value>,
    /// The `ltest-run` entry symbol.
    entry_sym: Symbol,
    /// Source map of test_runner.ktf (internal error diagnostic rendering).
    source_map: SourceMap,
    /// Persistent heap: global data + per-call products (GC root set includes globals).
    heap: Heap,
}

thread_local! {
    static BOOTSTRAP_TEST_RUNNER: RefCell<Option<BootstrapTestRunnerState>> = const {
        RefCell::new(None)
    };
}

/// Callback execution context (front-end outputs captured — `Rc`-shared
/// with the Foreign callback; nested execution consumes them read-only,
/// the slice/globals/heap are cloned and built inside `run_case`).
struct RunContext {
    /// Expanded program item sequence (source order — data source for the
    /// splitting projection and slice reconstruction).
    items: Vec<ModuleItem>,
    /// Symbol table (name rendering + nested-execution global registration).
    table: SymbolTable,
    /// Source map (nested-execution error diagnostic rendering).
    source_map: SourceMap,
    /// I/O grant (source-requirement projection — nested-execution global
    /// registration surface).
    grant: IoGrant,
}

/// Run a test source text (the sole test entry since the E6 close-out
/// r154 / 224-a: the S-expr twin `run` was deleted with the S-expr
/// surface — the CLI `kerf test` subcommand consumes this entry).
///
/// Front-end compilation goes through [`compile_front`] (the
/// `.ktf` read stage via the reader bridge; cache-free). The
/// case-splitting/orchestration logic is implemented once
/// ([`run_report_from_front`]): prelude/case splitting operates on
/// `ModuleItem` (CoreExpr level — syntax-neutral; a `fn` declaration is a
/// prelude Define, a top-level expression is a case).
#[allow(clippy::result_large_err)] // Error path carries full diagnostics — driver-entry convention
pub fn run_test_case(source: &str, filename: &str) -> Result<TestReport, TestRunnerError> {
    crate::effects::ensure_hook_installed();
    let front = crate::driver::compile_front(source, filename).map_err(TestRunnerError::Front)?;
    run_report_from_front(front)
}

/// Shared tail of the two syntax faces (front-end artifacts → case report;
/// single source — everything downstream of the front is skin-neutral).
#[allow(clippy::result_large_err)] // error path carries full diagnostics — driver-entry convention
fn run_report_from_front(front: FrontOutput) -> Result<TestReport, TestRunnerError> {
    let table = front.table;
    let source_map = front.source_map;
    let grant = IoGrant::from_requirements(IoRequirements::from_items(&front.core));

    // Item-metadata projection (ModuleItem variants → kind tag + fully
    // rendered name — the tag mapping is a type-level mechanical
    // projection; splitting decisions belong solely to the .ktf source)
    let items_meta: Vec<(String, String)> = front
        .core
        .iter()
        .map(|item| {
            (
                kind_tag(item).to_string(),
                item.render(&|s: Symbol| resolve_symbol(s, &table)),
            )
        })
        .collect();

    // Callback construction (captures front-end outputs — Rc-shared)
    let ctx = Rc::new(RunContext {
        items: front.core,
        table,
        source_map,
        grant,
    });
    let callback = make_run_case_callback(ctx);

    let report = with_runner(|st| {
        let callee = st.globals.get(&st.entry_sym).cloned().ok_or_else(|| {
            format!(
                "[bootstrap-test-runner] entry {} undefined (test_runner.ktf corrupted)",
                ENTRY_NAME
            )
        })?;
        let items_value = heap_item_list(&mut st.heap, &items_meta);
        // Two-argument pass-through (item-metadata list + execution
        // callback — the callback is passed through as a Foreign function
        // value parameter, lexically bound on the .ktf side)
        let output = call_closure(
            &st.program,
            &mut st.globals,
            &mut st.heap,
            &callee,
            vec![items_value, Value::Builtin(callback)],
        )
        .map_err(|e| vm_error_to_internal(&e, &st.source_map))?;
        report_from_value(&output, &st.heap)
    })
    .map_err(TestRunnerError::Internal)?;
    KRF_PRODUCTION_RUNS.with(|c| c.set(c.get() + 1));
    Ok(report)
}

/// Item kind tag (`ModuleItem` variant projection — isomorphic to the
/// `is_prelude_form` match structure; assign = set!-semantic expression
/// item).
fn kind_tag(item: &ModuleItem) -> &'static str {
    match item {
        ModuleItem::Define { .. } => "define",
        ModuleItem::Module { .. } => "module",
        ModuleItem::Require { .. } => "require",
        ModuleItem::Expr(e) => match e.as_ref() {
            CoreExpr::Assign { .. } => "assign",
            _ => "expr",
        },
    }
}

/// Case-execution callback construction (Foreign function value —
/// `(lrun-case prelude-ids case-id)` → `(pass detail)` two-element list).
///
/// Nested execution semantics (mirrors the `test_source` loop body):
/// slice = prelude item sequence ++ case item (cloned in source order) →
/// effect boundary (`handle_escape`/`TestFailure` — short-circuit at any
/// depth inside the case + recovery after capture) → nested VM execution
/// (`run_case` — independent heap/globals: state isolation between cases) →
/// (pass, detail) boxed into the outer heap.
fn make_run_case_callback(ctx: Rc<RunContext>) -> Rc<BuiltinFn> {
    BuiltinFn::new("lrun-case", move |heap, args| {
        if args.len() != 2 {
            return Err(RuntimeError::new(
                "lrun-case requires 2 arguments(pre- id list + case id)",
            ));
        }
        let prelude_ids = int_list(&args[0], heap)?;
        let case_id = match args[1].as_int() {
            Some(i) => i,
            None => {
                return Err(RuntimeError::new("lrun-case case id requires int"));
            }
        };
        // Boundary defense (fail-closed — orchestration protocol defect surface)
        let n = ctx.items.len() as i64;
        if case_id < 0 || case_id >= n {
            return Err(RuntimeError::new(format!(
                "lrun-case case id out of bounds:{}",
                case_id
            )));
        }
        for &p in &prelude_ids {
            if p < 0 || p >= n {
                return Err(RuntimeError::new(format!(
                    "lrun-case pre- id out of bounds:{}",
                    p
                )));
            }
        }
        // Slice reconstruction (source-order prelude ++ case — ownership cloned,
        // nested execution independent)
        let prelude: Vec<ModuleItem> = prelude_ids
            .iter()
            .map(|&i| ctx.items[i as usize].clone())
            .collect();
        let case = ctx.items[case_id as usize].clone();
        // Effect boundary (short-circuit + recovery — the mechanical layer
        // of recovery orchestration; the .ktf loop continuing = the
        // orchestration layer) + nested VM execution (independent
        // heap/globals — case isolation)
        let outcome = crate::effects::handle_escape::<(), TestFailure>(|| {
            run_case(&prelude, &case, &ctx.table, &ctx.source_map, &ctx.grant)
        });
        let (pass, detail) = match outcome {
            Ok(()) => (true, String::new()),
            Err(f) => (false, f.detail),
        };
        // (pass detail) two-element list → outer heap (nested execution is
        // complete — the outer heap only carries the return-value boxing)
        Ok(value_list(
            heap,
            vec![Value::Bool(pass), Value::Str(Rc::from(detail.as_str()))],
        ))
    })
}

/// Execute with thread-local state (lazy initialization).
fn with_runner<T>(
    f: impl FnOnce(&mut BootstrapTestRunnerState) -> Result<T, String>,
) -> Result<T, String> {
    BOOTSTRAP_TEST_RUNNER.with(|cell| {
        let mut opt = cell.borrow_mut();
        if opt.is_none() {
            match load_runner() {
                Ok(state) => *opt = Some(state),
                Err(e) => return Err(e),
            }
        }
        f(opt.as_mut().expect("initialized above"))
    })
}

/// Compile and load test_runner.ktf (seed path — no recursion: the seed
/// pipeline compiles the self-hosted implementation, same P1 hard
/// constraint as the existing bridges).
fn load_runner() -> Result<BootstrapTestRunnerState, String> {
    let front = crate::driver::compile_front_seed(RUNNER_SRC, RUNNER_FILENAME).map_err(|e| {
        format!(
            "[bootstrap-test-runner] test_runner.ktf compile failed (seed pipeline):{}",
            e.rendered
        )
    })?;
    build_state(front.program, front.table, front.source_map)
}

/// Build test_runner state from front-end outputs (single state-construction
/// implementation).
fn build_state(
    program: BcProgram,
    mut table: SymbolTable,
    source_map: SourceMap,
) -> Result<BootstrapTestRunnerState, String> {
    // test_runner.ktf has no I/O references (pure data orchestration —
    // case execution belongs to the callback's nested VM) — loaded with an
    // empty grant (R9 fail-closed)
    let mut globals = register_globals(&mut table, &crate::capability::IoGrant::none());
    crate::builtins::resolve_hygiene_fallbacks(&program, &mut table, &mut globals);
    let mut heap = Heap::new();
    let outcome = run_program(&program, &mut globals, &mut heap)
        .map_err(|e| vm_error_to_internal(&e, &source_map))?;
    let _ = outcome; // The main prototype only executes top-level definitions (value meaningless)
    let entry_sym = table.intern(ENTRY_NAME);
    Ok(BootstrapTestRunnerState {
        program,
        globals,
        entry_sym,
        source_map,
        heap,
    })
}

/// Item-metadata sequence → VM list (each item a two-element `(kind name)`
/// list — construction isomorphic to `heap_case_list`; a same-shaped
/// independent copy of the list construction in the bootstrap_check/
/// bootstrap_test bridges).
fn heap_item_list(heap: &mut Heap, items: &[(String, String)]) -> Value {
    if items.is_empty() {
        return Value::Nil;
    }
    let mut acc = heap.alloc_boxed(BoxedInput::Nil);
    for (kind, name) in items.iter().rev() {
        let elem = box_value(
            &value_list(
                heap,
                vec![
                    Value::Str(Rc::from(kind.as_str())),
                    Value::Str(Rc::from(name.as_str())),
                ],
            ),
            heap,
        );
        acc = heap.alloc_pair(elem, acc);
    }
    Value::Pair(acc)
}

/// Value sequence → VM list (field-list construction — isomorphic to `case_to_value`).
fn value_list(heap: &mut Heap, fields: Vec<Value>) -> Value {
    let mut acc = heap.alloc_boxed(BoxedInput::Nil);
    for v in fields.into_iter().rev() {
        let elem = box_value(&v, heap);
        acc = heap.alloc_pair(elem, acc);
    }
    Value::Pair(acc)
}

/// VM result value → `TestReport` (case four-field list deconstruction +
/// on-the-spot statistics — protocol defense: non-list / wrong arity /
/// field-type mismatch = internal error, fail-closed).
fn report_from_value(v: &Value, heap: &Heap) -> Result<TestReport, String> {
    let cases_v = value_fields(v, heap)?;
    let mut cases = Vec::with_capacity(cases_v.len());
    for (i, cv) in cases_v.iter().enumerate() {
        let fields = value_fields(cv, heap)?;
        if fields.len() != 4 {
            return Err(format!(
                "[bootstrap-test-runner] case result non-four element list(# {} item {} field -- test_runner.ktf corrupted)",
                i + 1,
                fields.len()
            ));
        }
        let index = match fields[0].as_int() {
            Some(n) if n > 0 => n as usize,
            _ => {
                return Err(format!(
                "[bootstrap-test-runner] case index field is not a positive integer (item #{} -- test_runner.ktf corrupted)",
                i + 1
            ))
            }
        };
        let name = match &fields[1] {
            Value::Str(s) => s.to_string(),
            other => {
                return Err(format!(
                    "[bootstrap-test-runner] case name segment non- str({} -- test_runner.ktf corrupted)",
                    other.type_name()
                ))
            }
        };
        let pass = match &fields[2] {
            Value::Bool(b) => *b,
            other => {
                return Err(format!(
                    "[bootstrap-test-runner] case pass field is not bool({} -- test_runner.ktf corrupted)",
                    other.type_name()
                ))
            }
        };
        let detail = match &fields[3] {
            Value::Str(s) => s.to_string(),
            other => {
                return Err(format!(
                    "[bootstrap-test-runner] case detail field is not a str ({} -- test_runner.ktf corrupted)",
                    other.type_name()
                ))
            }
        };
        cases.push(TestCaseOutcome {
            index,
            name,
            pass,
            detail,
        });
    }
    // On-the-spot statistics (mirror the test_source statistics policy —
    // the .ktf artifact is the single decision source)
    let passed = cases.iter().filter(|c| c.pass).count();
    Ok(TestReport {
        failed: cases.len() - passed,
        passed,
        cases,
    })
}

/// List value → field sequence (bridge-side deconstruction — nil-terminator
/// guard; a same-shaped independent copy of the bootstrap_test bridge).
fn value_fields(v: &Value, heap: &Heap) -> Result<Vec<Value>, String> {
    let mut out = Vec::new();
    let mut cur = v.clone();
    while let Value::Pair(r) = cur {
        let (car, cdr) = heap
            .get_pair(r)
            .ok_or_else(|| "[bootstrap-test-runner] heap pair slot corrupted".to_string())?;
        out.push(unbox_slot(car, heap));
        cur = unbox_slot(cdr, heap);
    }
    if !matches!(cur, Value::Nil) {
        return Err(format!(
            "[bootstrap-test-runner] result list tail is not nil({} -- test_runner.ktf corrupted)",
            cur.type_name()
        ));
    }
    Ok(out)
}

/// VM Int list value → id sequence (callback-argument deconstruction —
/// protocol defense).
fn int_list(v: &Value, heap: &Heap) -> Result<Vec<i64>, RuntimeError> {
    let mut out = Vec::new();
    let mut cur = v.clone();
    while let Value::Pair(r) = cur {
        let (car, cdr) = heap
            .get_pair(r)
            .ok_or_else(|| RuntimeError::new("lrun-case pre- id list heap slot corrupted"))?;
        let e = unbox_slot(car, heap);
        match e.as_int() {
            Some(i) => out.push(i),
            None => {
                return Err(RuntimeError::new(
                    "lrun-case pre- id list items require int",
                ));
            }
        }
        cur = unbox_slot(cdr, heap);
    }
    if !matches!(cur, Value::Nil) {
        return Err(RuntimeError::new("lrun-case pre- id list tail non- nil"));
    }
    Ok(out)
}

/// VM error → internal error string (defensive path — the orchestration
/// bridge has no value-channel errors).
fn vm_error_to_internal(e: &VmError, sm: &SourceMap) -> String {
    use kerf_span::render_diagnostic;
    let diag = kerf_span::Diagnostic::error(
        Some(kerf_span::DiagnosticCode(2)),
        format!("bootstrap test_runner.ktf internal error:{}", e.message),
        e.span,
    );
    render_diagnostic(&diag, sm)
}

#[cfg(test)]
mod tests {
    use super::*;

    /// State liveness probe (panel signal for the parity tests — mirrors
    /// the prior incisions' is_* shape): lazy loading + same-thread reuse +
    /// zero-case protocol (pure prelude source).
    #[test]
    fn runner_state_lifecycle_probe() {
        let r = run_test_case("let x = 1;", "lifecycle.ktf").expect("pure pre-source run");
        assert!(r.cases.is_empty());
        assert_eq!(r.passed, 0);
        assert_eq!(r.failed, 0);
        // Same-thread reuse (state already loaded — the second call has zero
        // loading cost)
        let r2 = run_test_case("1 == 1", "lifecycle2.ktf").expect("single case source re-run");
        assert_eq!(r2.cases.len(), 1);
        assert!(r2.cases[0].pass);
    }

    /// Production liveness probe (the call above already made the count > 0 —
    /// empirical probe panel signal).
    #[test]
    fn runner_production_liveness_probe() {
        let r = run_test_case("1 == 1", "liveness.ktf").expect("single case run");
        assert_eq!(r.cases.len(), 1);
        assert!(r.cases[0].pass);
        assert!(production_test_runner_is_bootstrap());
    }

    /// Front-end error channel separation (real diagnostics pass through
    /// Front — same source as test_source).
    #[test]
    fn runner_front_error_channel() {
        let e = run_test_case("let x = ;", "bad.ktf").expect_err("syntax error should Err");
        match e {
            TestRunnerError::Front(d) => {
                assert!(!d.rendered.is_empty());
            }
            TestRunnerError::Internal(msg) => {
                panic!("pre-stage error entered an internal channel:{}", msg);
            }
        }
    }
}

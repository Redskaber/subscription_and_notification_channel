//! Self-hosted Compiler (I1 compilation stage kerf-ized — the third
//! instance of the three-piece set).
//!
//! Architecture (07-bootstrap §3.2 hybrid-period composition; r6/r14,
//! the third instance of the three-piece set —
//! i1-incision-migration-design §2 INC1):
//! - **Compilation logic**: `bootstrap/compiler.ktf` (kerf source,
//!   target syntax — switch window step ③ third batch r114; compiled to
//!   bytecode by the seed target-Reader pipeline and run on the Stage 0
//!   VM — the `lexc-compile-program` entry, aligned in interface shape
//!   with kerf-compiler's `compile_module`, §11);
//! - **Bridge (this module)**: host-side invocation (`call_closure`) +
//!   bidirectional value-tree conversion (`CoreExpr` → core nodes
//!   (carrying span/scope sets/tagged literals) → VM nodes →
//!   `('prog ...)` → `BcProgram` type reconstruction);
//! - **Seed (kerf-compiler)**: bootstrap loading (compiling
//!   compiler.ktf) + the oracle for parity tests (the classic role of a
//!   bootstrap seed — the two implementations cross-validate each
//!   other).
//!
//! **I1 production switch (42-d) in effect**: the compilation stage of
//! the production pipeline (`compile_front`) is dispatched through this
//! module (`CompilerKind::Bootstrap` — i1-design §6 P1); the 42-b/c
//! "parity shadow path" boundary is closed (switched after gate A's
//! all arms went parity-green — the GATE 2/P3 prerequisite was met).
//! Self-host consistency (compiling itself twice yields identical
//! bytes) is guarded by the gate B fixpoint tests
//! (bootstrap_compiler_tests — §21.3 condition 2).
//!
//! Heap contract: the Compiler program's persistent heap carries global
//! state (the CC-* compilation context — the entry-reset discipline
//! keeps it free of state that would affect output across calls) plus
//! per-call intermediates — GC uses (stack + frames + globals) as its
//! root set, so reclamation across calls is safe; input node trees are
//! constructed on the persistent heap (one-shot, reclaimable after the
//! call).
//!
//! Concurrency contract: thread_local state (Rc values are not Sync) —
//! lazily compiled and loaded once per thread; the B₂ round of the gate
//! B fixpoint replaces the state via [`install_state`] (isolated-run
//! discipline §7.4).

use std::cell::RefCell;
use std::collections::HashMap;
use std::rc::Rc;

use kerf_compiler::{BcConst, BcProgram, BcProto, CaptureSource, CompileError, Op};
use kerf_core::{CoreExpr, LiteralValue, ModuleItem};
use kerf_runtime::{BoxedInput, Heap};
use kerf_span::{FileId, SourceMap, Span};
use kerf_syntax::{Symbol, SymbolTable};
use kerf_vm::{box_value, call_closure, run_program, unbox_slot, Value, VmError};

use crate::bootstrap::{as_int, as_str, as_symbol_name, value_list_fields};
use crate::builtins::register_globals;

/// Compiler source (embedded at compile time — the artifact is
/// self-contained, with no external file dependency).
/// Switch-window step ③ third batch (r114 / 184-a): the target-syntax
/// production artifact (compiler.ktf) — the S-expr original (compiler.krf)
/// was retained as the parity oracle through the window and deleted by the
/// E5 close-out cleanup batch (r120 / 190-a, principle 41); the .ktf
/// fixpoint gate family carries the ongoing self-compilation duty.
const COMPILER_SRC: &str = include_str!("compiler.ktf");
/// Compiler source file name (for diagnostic rendering).
const COMPILER_FILENAME: &str = "compiler.ktf";
/// Entry name (a top-level definition of compiler.ktf).
const ENTRY_NAME: &str = "lexc-compile-program";

/// main prototype name (rendering is replaced by the caller — the same
/// magic symbol as in the seed compile.rs).
const MAIN_PROTO_NAME: Symbol = Symbol(u32::MAX - 1);
/// Zero-argument Fn prototype name.
const ANON_PROTO_NAME: Symbol = Symbol(u32::MAX - 2);

/// Self-hosted Compiler state (one per thread, lazily initialized).
struct BootstrapCompilerState {
    /// Compiler program bytecode (compiled by the seed pipeline).
    program: BcProgram,
    /// Loaded globals (builtins + compiler.ktf top-level definitions).
    globals: HashMap<Symbol, Value>,
    /// `lexc-compile-program` entry symbol.
    entry_sym: Symbol,
    /// The Compiler's source map (for rendering internal error
    /// diagnostics).
    source_map: SourceMap,
    /// Persistent heap: global data + per-call products (the GC root set
    /// includes globals).
    heap: Heap,
}

thread_local! {
    static BOOTSTRAP_CMP: RefCell<Option<BootstrapCompilerState>> = const {
        RefCell::new(None)
    };
}

// r114 liveness probe: the bootstrap Compiler state is built from the
// .ktf target-syntax corpus (counts actual load_compiler executions —
// >0 = the target-corpus production load is live; isomorphic to the
// `expander_bootstrap_is_ktf_corpus` probe family — the wiring proof
// for switch-window step ③, third batch).
thread_local! {
    static COMPILER_KTF_LOADS: std::cell::Cell<u32> = const { std::cell::Cell::new(0) };
}

/// bootstrap Compiler state = .ktf target corpus (liveness probe — r114
/// step ③, third batch).
pub fn compiler_bootstrap_is_ktf_corpus() -> bool {
    COMPILER_KTF_LOADS.with(|c| c.get() > 0)
}

/// Self-hosted compilation entry: `Vec<Rc<CoreExpr>>` → `BcProgram`
/// (same shape as `kerf_compiler::compile_module` — the parity oracle
/// comparison surface).
///
/// **I1 production switch (42-d)**: the compilation stage of the
/// production pipeline (`compile_front`) is dispatched through this
/// entry (`CompilerKind::Bootstrap` — the switch-point design
/// i1-design §6 P1; the seed path always uses the Rust
/// `kerf_compiler::compile_module` — bootstrap loading and parity
/// oracle).
pub fn compile_module(
    items: &[ModuleItem],
    file_id: FileId,
    table: &mut SymbolTable,
) -> Result<BcProgram, CompileError> {
    compile_module_with_externs(items, &[], file_id, table)
}

/// r137 / 207-c (TD-026 language-surface window, ffi-language-surface-
/// design §4/D4): the extern-face-carrying compile entry — `externs` is
/// the flat extern symbol space (Symbol → interned name string; the
/// r135 `lchk-check-program nodes renames` two-parameter protocol
/// precedent — additive: the empty face = the historical single-parameter
/// behavior identical bit for bit). The face rides the entry's second
/// parameter → the .ktf-side CC_EXTERN global state cell → the resolve
/// machine's extern consultation + the apply arm's FFI emission.
pub fn compile_module_with_externs(
    items: &[ModuleItem],
    externs: &[(Symbol, std::rc::Rc<str>)],
    file_id: FileId,
    table: &mut SymbolTable,
) -> Result<BcProgram, CompileError> {
    with_compiler(|st| {
        // Stage 1: ModuleItem → VM core nodes (r49 D59 — the
        // item_to_node item-level bridge; span/scope set/symbol names
        // carried as str; literals disambiguation-tagged — Str/Symbol/
        // Float have no predicate distinction on the VM value surface,
        // typed pass-through on the bridge side)
        let nodes: Vec<Value> = items
            .iter()
            .map(|item| item_to_node(item, table, &mut st.heap))
            .collect();
        let input = heap_list(&mut st.heap, nodes);
        // r137: the extern face as the entry's second argument — a flat
        // list of interned name strings (the .ktf entry resets it into
        // CC_EXTERN per call — the determinism discipline).
        // r147 / 217-c (extern-alias-design D3): each entry becomes a
        // (local flat) pair — the source-level binding name and the flat
        // FFI space name. The unaliased identity (local == flat) keeps the
        // historical behavior; the aliased split threads the two-name
        // separation through the resolve machine (the reference matches
        // by local, the emitted SymLit carries flat — mirroring the Rust
        // side's IrVar::Extern(flat) payload, principle 31)
        let extern_pairs: Vec<Value> = externs
            .iter()
            .map(|(local, name)| {
                let pair = heap_list(
                    &mut st.heap,
                    vec![
                        Value::Str(std::rc::Rc::from(table.name(*local))),
                        Value::Str(std::rc::Rc::from(name.as_ref())),
                    ],
                );
                pair
            })
            .collect();
        let extern_list = heap_list(&mut st.heap, extern_pairs);
        // Stage 2: entry invocation (compiler.ktf runs on the VM)
        let output = call_entry(st, input, extern_list)?;
        // Stage 3: error check + prog node bridge (BcProgram type
        // reconstruction)
        if let Some(e) = as_compile_err(&output, &st.heap, file_id) {
            return Err(e);
        }
        prog_from_value(&output, &st.heap, file_id, table)
    })
}

/// Execute with thread-local state (lazily initialized).
fn with_compiler<T>(
    f: impl FnOnce(&mut BootstrapCompilerState) -> Result<T, CompileError>,
) -> Result<T, CompileError> {
    BOOTSTRAP_CMP.with(|cell| {
        let mut opt = cell.borrow_mut();
        if opt.is_none() {
            match load_compiler() {
                Ok(state) => *opt = Some(state),
                Err(e) => return Err(e),
            }
        }
        f(opt.as_mut().expect("initialized above"))
    })
}

/// Compile and load the Compiler program (seed path — the Rust seed
/// target Reader + Rust Expander + Rust Compiler compiles compiler.ktf,
/// not via the self-hosted path: the seed compiles the self-hosted
/// Compiler, no recursion).
///
/// Switch-window step ③ third batch (r114 / 184-a — the r110 reader
/// pattern): the read stage goes through `compile_front_seed`
/// (seed Reader `read_source` — the naming map `_`→`-`
/// single point of entry); expand/compile remain seed (hard P1
/// convention — bootstrap loading is always the seed path).
fn load_compiler() -> Result<BootstrapCompilerState, CompileError> {
    COMPILER_KTF_LOADS.with(|c| c.set(c.get() + 1));
    let front =
        crate::driver::compile_front_seed(COMPILER_SRC, COMPILER_FILENAME).map_err(|e| {
            compile_internal(&format!(
                "[bootstrap-cmp] bootstrap Compiler compile failed (seed pipeline):{}",
                e.rendered
            ))
        })?;
    build_state(front.program, front.table, front.source_map)
}

/// Build Compiler state from front-end products (shared by the seed
/// loader and [`install_state`] — a single state-construction
/// implementation: register builtins + hygiene fallbacks + top-level
/// execution + entry interning).
fn build_state(
    program: BcProgram,
    mut table: SymbolTable,
    source_map: SourceMap,
) -> Result<BootstrapCompilerState, CompileError> {
    // compiler.ktf has no I/O references (pure data transformation) —
    // empty grant (R9 fail-closed)
    let mut globals = register_globals(&mut table, &crate::capability::IoGrant::none());
    crate::builtins::resolve_hygiene_fallbacks(&program, &mut table, &mut globals);
    let mut heap = Heap::new();
    let outcome = run_program(&program, &mut globals, &mut heap)
        .map_err(|e| vm_error_to_compile(&e, &source_map))?;
    let _ = outcome; // The main prototype only executes top-level definitions (value unused)
    let entry_sym = table.intern(ENTRY_NAME);
    Ok(BootstrapCompilerState {
        program,
        globals,
        entry_sym,
        source_map,
        heap,
    })
}

/// Install the given artifact as this thread's Compiler state (gate B
/// fixpoint — the B₂ round's "treat B₁ as the new bootstrap program"
/// semantics: after the self-hosted chain's artifact replaces the
/// seed-loaded state, the same source is compiled again, with the
/// criterion that B₁/B₂ are byte-identical; i1-design §5 gate B +
/// §7.4).
///
/// The artifact must be compiled from compiler.ktf source (existence
/// of the `lexc-compile-program` entry is verified by actually
/// constructing the state — non-compiler.ktf artifacts report a
/// structured error here).
pub fn install_state(
    program: BcProgram,
    table: SymbolTable,
    source_map: SourceMap,
) -> Result<(), CompileError> {
    let state = build_state(program, table, source_map)?;
    BOOTSTRAP_CMP.with(|cell| *cell.borrow_mut() = Some(state));
    Ok(())
}

/// Unload this thread's Compiler state (fixpoint isolated run — the
/// most conservative form of i1-design §7.4's "fresh state";
/// subsequent calls trigger a lazy seed reload).
pub fn reset_state() {
    BOOTSTRAP_CMP.with(|cell| *cell.borrow_mut() = None);
}

/// Liveness probe for the self-hosted Compiler state (I1 production
/// switch guard: whether the production compilation path really goes
/// through the VM Compiler — mirroring `bootstrap_expander::is_loaded`).
#[cfg(test)]
pub(crate) fn is_loaded() -> bool {
    BOOTSTRAP_CMP.with(|cell| cell.borrow().is_some())
}

/// Call the Compiler entry (programmatic invocation at the host trust
/// layer — §11, same level as run_program).
fn call_entry(
    st: &mut BootstrapCompilerState,
    input: Value,
    externs: Value,
) -> Result<Value, CompileError> {
    let callee = st.globals.get(&st.entry_sym).cloned().ok_or_else(|| {
        compile_internal(&format!(
            "[bootstrap-cmp] entry {} undefined (compiler.ktf corrupted)",
            ENTRY_NAME
        ))
    })?;
    call_closure(
        &st.program,
        &mut st.globals,
        &mut st.heap,
        &callee,
        vec![input, externs],
    )
    .map_err(|e| vm_error_to_compile(&e, &st.source_map))
}

/// VM error → CompileError (defensive path: compilation errors are
/// returned as ('err ...) values, not through this channel — this path
/// only covers internal compiler.ktf defects or the frame limit).
fn vm_error_to_compile(e: &VmError, sm: &SourceMap) -> CompileError {
    use kerf_span::{render_diagnostic, Diagnostic, DiagnosticCode, Severity};
    let mut diag = Diagnostic::error(
        Some(DiagnosticCode(2)),
        format!("bootstrap Compiler internal error:{}", e.message),
        e.span,
    );
    for t in &e.trace {
        diag = diag.with_child(Severity::Note, "call site", t.span);
    }
    CompileError {
        message: render_diagnostic(&diag, sm),
        span: Span::dummy(),
    }
}

// ---- Reverse value bridge: CoreExpr → VM core nodes ----

/// `CoreExpr` → core node value `(tag s e exp ...)` (symbol names
/// carried as str — re-interned by the bridge; scope set = int list;
/// literals in disambiguation-tagged form).
/// Item node bridge (r49 D59 — declaration items keep their item-level
/// shape [wire protocol text unchanged]; expression items go through
/// core_to_node. Zero changes to compiler.krf's consumer surface:
/// compile-module's input was already a flat list of
/// 'define/'module/'require nodes). r74/144-b: pub(crate) —
/// bootstrap_check.rs (the HM .krf-path validation bridge) reuses the
/// same wire-protocol single-source serialization (check.krf input =
/// compiler.krf input — zero new bridge protocols).
pub(crate) fn item_to_node(item: &ModuleItem, table: &SymbolTable, heap: &mut Heap) -> Value {
    let span = match item {
        ModuleItem::Define { span, .. }
        | ModuleItem::Require { span, .. }
        | ModuleItem::Module { span, .. } => *span,
        ModuleItem::Expr(e) => e.span(),
    };
    let s = Value::Int(span.start as i64);
    let en = Value::Int(span.end as i64);
    let exp = Value::Int(span.expansion_id as i64);
    let tag = |name: &str| Value::Symbol(std::rc::Rc::from(name));
    let items: Vec<Value> = match item {
        ModuleItem::Define { name, value, .. } => {
            let val = core_to_node(value, table, heap);
            vec![
                tag("define"),
                s,
                en,
                exp,
                Value::Str(Rc::from(table.name(*name))),
                val,
            ]
        }
        ModuleItem::Require { caps, .. } => {
            let mut v = vec![tag("require"), s, en, exp];
            v.extend(caps.iter().map(|c| Value::Str(Rc::from(c.as_str()))));
            v
        }
        ModuleItem::Module {
            name,
            imports,
            exports,
            items: inner_items,
            ..
        } => {
            let strs = |syms: &[Symbol]| -> Vec<Value> {
                syms.iter()
                    .map(|x| Value::Str(Rc::from(table.name(*x))))
                    .collect()
            };
            let imports_v = heap_list(heap, strs(imports));
            let exports_v = heap_list(heap, strs(exports));
            let item_nodes: Vec<Value> = inner_items
                .iter()
                .map(|b| item_to_node(b, table, heap))
                .collect();
            let mut v = vec![
                tag("module"),
                s,
                en,
                exp,
                Value::Str(Rc::from(table.name(*name))),
                imports_v,
                exports_v,
            ];
            v.extend(item_nodes);
            v
        }
        ModuleItem::Expr(e) => {
            // Expression item: the core_to_node product is directly the
            // node (zero wire-protocol wrapping — consistent with the
            // existing compile-module input shape)
            return core_to_node(e, table, heap);
        }
    };
    heap_list(heap, items)
}

fn core_to_node(e: &CoreExpr, table: &SymbolTable, heap: &mut Heap) -> Value {
    let s = Value::Int(e.span().start as i64);
    let en = Value::Int(e.span().end as i64);
    let exp = Value::Int(e.span().expansion_id as i64);
    let tag = |name: &str| Value::Symbol(Rc::from(name));
    let items: Vec<Value> = match e {
        CoreExpr::Literal { value, .. } => {
            vec![tag("literal"), s, en, exp, litval_to_value(value, heap)]
        }
        CoreExpr::Var { name, scopes, .. } => vec![
            tag("var"),
            s,
            en,
            exp,
            Value::Str(Rc::from(table.name(*name))),
            scope_list_value(scopes, heap),
        ],
        CoreExpr::Apply { fn_expr, args, .. } => {
            let f = core_to_node(fn_expr, table, heap);
            let arg_nodes: Vec<Value> = args.iter().map(|a| core_to_node(a, table, heap)).collect();
            let mut v = vec![tag("apply"), s, en, exp, f];
            v.extend(arg_nodes);
            v
        }
        CoreExpr::If {
            cond,
            then_branch,
            else_branch,
            ..
        } => {
            let c = core_to_node(cond, table, heap);
            let t = core_to_node(then_branch, table, heap);
            let el = core_to_node(else_branch, table, heap);
            vec![tag("if"), s, en, exp, c, t, el]
        }
        CoreExpr::Fn {
            params,
            param_scopes,
            rest,
            body,
            ..
        } => {
            let mut names: Vec<Value> = params
                .iter()
                .map(|p| Value::Str(Rc::from(table.name(*p))))
                .collect();
            let mut scopes: Vec<Value> = param_scopes
                .iter()
                .map(|sc| scope_list_value(sc, heap))
                .collect();
            // r165 / 236-c (variadic-rest-design.md D2-c): the rest marker
            // rides the params list — `(... rest)`; the scopes list stays
            // parallel (the marker's entry = the rest binding's scopes as a
            // placeholder — consumers skip it).
            if let Some((r, rsp)) = rest.as_ref() {
                names.push(Value::Str(Rc::from("...")));
                names.push(Value::Str(Rc::from(table.name(*r))));
                let rsc = scope_list_value(rsp, heap);
                scopes.push(rsc.clone());
                scopes.push(rsc);
            }
            let params_v = heap_list(heap, names);
            let scopes_v = heap_list(heap, scopes);
            let body_v = core_to_node(body, table, heap);
            vec![tag("fn"), s, en, exp, params_v, scopes_v, body_v]
        }
        CoreExpr::Assign {
            name,
            scopes,
            value,
            ..
        } => {
            let sc = scope_list_value(scopes, heap);
            let val = core_to_node(value, table, heap);
            vec![
                tag("assign"),
                s,
                en,
                exp,
                Value::Str(Rc::from(table.name(*name))),
                sc,
                val,
            ]
        }
        // r49 D59: the 'define/'module/'require item-level forms belong
        // to item_to_node — unrepresentable at expression position at
        // compile time (three core_to_node arms retired)
        CoreExpr::Let {
            name,
            scopes,
            value,
            body,
            ..
        } => {
            // r45/E5 S3 structural arm (D38 continuation): bridge tag
            // 'let (fields = name/scopes/value/body — symmetric with
            // assign's scope_list_value)
            let sc = scope_list_value(scopes, heap);
            let val = core_to_node(value, table, heap);
            let bod = core_to_node(body, table, heap);
            vec![
                tag("let"),
                s,
                en,
                exp,
                Value::Str(Rc::from(table.name(*name))),
                sc,
                val,
                bod,
            ]
        }
        // r25/42-f effect arms (the node protocol mirrors the Rust
        // compilation arm's consumption order): ('perform s e x effect
        // node) — the effect value subtree's evaluation-first order is
        // handled by the compilation arm
        CoreExpr::Perform { effect, .. } => {
            let f = core_to_node(effect, table, heap);
            vec![tag("perform"), s, en, exp, f]
        }
        // ('handle s e x tagstr payload-name payload-scopes resume-name
        //   resume-scopes handler-node body-node) — the two binders'
        //   scope sets are shaped like Fn.param_scopes (int lists)
        CoreExpr::Handle {
            tag: htag,
            payload_var,
            payload_scopes,
            resume_var,
            resume_scopes,
            handler_body,
            body,
            ..
        } => {
            let h = core_to_node(handler_body, table, heap);
            let b = core_to_node(body, table, heap);
            vec![
                tag("handle"),
                s,
                en,
                exp,
                Value::Str(htag.clone()),
                Value::Str(Rc::from(table.name(*payload_var))),
                scope_list_value(payload_scopes, heap),
                Value::Str(Rc::from(table.name(*resume_var))),
                scope_list_value(resume_scopes, heap),
                h,
                b,
            ]
        }
        // r136 / 206-b (TD-033 — D13): ('handle-group s e x arm₁ … arm_N
        // body-node) — arm node = (tagstr pname pscopes rname rscopes
        // hnode) five-field list (the arm-internal subset of the handle
        // seven-field shape)
        CoreExpr::HandleGroup { arms, body, .. } => {
            let arm_nodes: Vec<Value> = arms
                .iter()
                .map(|arm| {
                    let h = core_to_node(&arm.handler_body, table, heap);
                    let p_scopes = scope_list_value(&arm.payload_scopes, heap);
                    let r_scopes = scope_list_value(&arm.resume_scopes, heap);
                    heap_list(
                        heap,
                        vec![
                            Value::Str(arm.tag.clone()),
                            Value::Str(Rc::from(table.name(arm.payload_var))),
                            p_scopes,
                            Value::Str(Rc::from(table.name(arm.resume_var))),
                            r_scopes,
                            h,
                        ],
                    )
                })
                .collect();
            let b = core_to_node(body, table, heap);
            let mut v = vec![tag("handle-group"), s, en, exp];
            v.extend(arm_nodes);
            v.push(b);
            v
        }
    };
    heap_list(heap, items)
}

/// `LiteralValue` → disambiguation-tagged value (Str/Symbol/Float have
/// no predicate distinction on the VM value surface — typed tagging on
/// the bridge side; symbols carried as name str, per the §7.3
/// symbol-str discipline).
fn litval_to_value(v: &LiteralValue, heap: &mut Heap) -> Value {
    let tag = |name: &str| Value::Symbol(Rc::from(name));
    match v {
        LiteralValue::Int(i) => heap_list(heap, vec![tag("int"), Value::Int(*i)]),
        LiteralValue::Float(f) => heap_list(heap, vec![tag("float"), Value::Float(*f)]),
        LiteralValue::Str(s) => heap_list(heap, vec![tag("str"), Value::Str(s.clone())]),
        LiteralValue::Bool(b) => heap_list(heap, vec![tag(if *b { "true" } else { "false" })]),
        LiteralValue::Nil => heap_list(heap, vec![tag("nil")]),
        LiteralValue::Symbol(s) => heap_list(heap, vec![tag("sym"), Value::Str(s.clone())]),
        LiteralValue::Pair(a, b) => {
            let car = litval_to_value(a, heap);
            let cdr = litval_to_value(b, heap);
            heap_list(heap, vec![tag("pair"), car, cdr])
        }
    }
}

/// Scope set → int list value (iterated in ascending order).
fn scope_list_value(scopes: &kerf_syntax::ScopeSet, heap: &mut Heap) -> Value {
    let items: Vec<Value> = scopes.iter().map(|i| Value::Int(i as i64)).collect();
    heap_list(heap, items)
}

/// Build a list value on the given heap (isomorphic to the `list`
/// builtin — the same as the bridge's self-check surface).
fn heap_list(heap: &mut Heap, items: Vec<Value>) -> Value {
    if items.is_empty() {
        return Value::Nil;
    }
    let mut acc = heap.alloc_boxed(BoxedInput::Nil);
    for v in items.into_iter().rev() {
        let elem = box_value(&v, heap);
        acc = heap.alloc_pair(elem, acc);
    }
    Value::Pair(acc)
}

// ---- Forward value bridge: VM prog nodes → BcProgram ----

/// ('err message start end) → CompileError (returns None for non-error
/// forms; the Span carries the user's file_id — the error position lies
/// in the user's source text).
fn as_compile_err(v: &Value, heap: &Heap, file_id: FileId) -> Option<CompileError> {
    if let Value::Pair(r) = v {
        if let Some((car, _)) = heap.get_pair(*r) {
            if let Value::Symbol(s) = unbox_slot(car, heap) {
                if &*s == "err" {
                    let fields = value_list_fields(v, heap).ok()?;
                    if fields.len() != 4 {
                        return None;
                    }
                    let msg = as_str(&fields[1]).ok()?.to_string();
                    let s = as_int(&fields[2]).ok()?;
                    let e = as_int(&fields[3]).ok()?;
                    return Some(CompileError {
                        message: msg,
                        span: Span::new(file_id, s as u32, e as u32),
                    });
                }
            }
        }
    }
    None
}

/// `('prog (proto...) (const...) (glob...))` → `BcProgram`.
fn prog_from_value(
    v: &Value,
    heap: &Heap,
    file_id: FileId,
    table: &mut SymbolTable,
) -> Result<BcProgram, CompileError> {
    let fields = value_list_fields(v, heap).map_err(read_to_compile)?;
    if fields.len() != 4 {
        return Err(internal_x("prog node field count abnormal"));
    }
    // Prototype table
    let proto_nodes = value_list_fields(&fields[1], heap).map_err(read_to_compile)?;
    let mut protos = Vec::with_capacity(proto_nodes.len());
    for pn in &proto_nodes {
        protos.push(proto_from_value(pn, heap, file_id, table)?);
    }
    // Constant pool
    let const_nodes = value_list_fields(&fields[2], heap).map_err(read_to_compile)?;
    let mut consts = Vec::with_capacity(const_nodes.len());
    for cn in &const_nodes {
        consts.push(const_from_value(cn, heap, table)?);
    }
    // Global references (first-insertion order)
    let glob_nodes = value_list_fields(&fields[3], heap).map_err(read_to_compile)?;
    let mut global_refs = Vec::with_capacity(glob_nodes.len());
    for g in &glob_nodes {
        let name = as_str(g).map_err(read_to_compile)?;
        global_refs.push(table.intern(name));
    }
    Ok(BcProgram {
        protos,
        consts,
        entry: 0,
        global_refs,
        module_name: None,
    })
}

/// `('proto name-form (params) nlocals (capture-names) (capture-sources)
/// (instructions) (spans) free-vars)` → `BcProto`.
fn proto_from_value(
    pn: &Value,
    heap: &Heap,
    file_id: FileId,
    table: &mut SymbolTable,
) -> Result<BcProto, CompileError> {
    let f = value_list_fields(pn, heap).map_err(read_to_compile)?;
    if f.len() != 9 {
        return Err(internal_x("proto node field count abnormal"));
    }
    let name = proto_name_from_value(&f[1], heap, table)?;
    // r165 / 236-c (variadic-rest-design.md D2-c): the params field carries
    // the rest marker `...` + the rest binding name when the prototype is
    // variadic — parsed here into the fixed params + `rest_slot` (the
    // marker must be terminal; the rest NAME is metadata-only at this
    // layer — the slot index is the runtime carrier).
    let (params, rest_slot) = proto_params_from_value(&f[2], heap, table)?;
    let n_locals = as_int(&f[3]).map_err(read_to_compile)? as u32;
    let capture_names = symbol_vec_field(&f[4], heap, table)?;
    let src_nodes = value_list_fields(&f[5], heap).map_err(read_to_compile)?;
    let mut capture_sources = Vec::with_capacity(src_nodes.len());
    for sn in &src_nodes {
        capture_sources.push(capture_source_from_value(sn, heap)?);
    }
    let op_nodes = value_list_fields(&f[6], heap).map_err(read_to_compile)?;
    let mut code = Vec::with_capacity(op_nodes.len());
    for on in &op_nodes {
        code.push(op_from_value(on, heap)?);
    }
    let span_nodes = value_list_fields(&f[7], heap).map_err(read_to_compile)?;
    let mut debug_spans = Vec::with_capacity(span_nodes.len());
    for sn in &span_nodes {
        let sp = value_list_fields(sn, heap).map_err(read_to_compile)?;
        if sp.len() != 3 {
            return Err(internal_x("span triple field count abnormal"));
        }
        let s = as_int(&sp[0]).map_err(read_to_compile)?;
        let e = as_int(&sp[1]).map_err(read_to_compile)?;
        let x = as_int(&sp[2]).map_err(read_to_compile)?;
        debug_spans.push(Span {
            file_id,
            start: s as u32,
            end: e as u32,
            expansion_id: x as u32,
        });
    }
    let free_vars = symbol_vec_field(&f[8], heap, table)?;
    Ok(BcProto {
        name,
        params,
        rest_slot,
        n_locals,
        capture_names,
        capture_sources,
        code,
        debug_spans,
        free_vars,
    })
}

/// Prototype name form: ('main) (magic symbol) / ('anon) (anonymous) /
/// ('name name-str) (the first parameter's name — interned via the
/// user table).
fn proto_name_from_value(
    v: &Value,
    heap: &Heap,
    table: &mut SymbolTable,
) -> Result<Symbol, CompileError> {
    let f = value_list_fields(v, heap).map_err(read_to_compile)?;
    if f.is_empty() {
        return Err(internal_x("prototype name form field missing"));
    }
    let kind = as_symbol_name(&f[0]).map_err(read_to_compile)?;
    match kind {
        "main" => Ok(MAIN_PROTO_NAME),
        "anon" => Ok(ANON_PROTO_NAME),
        "name" => {
            if f.len() != 2 {
                return Err(internal_x("name form field count abnormal"));
            }
            let name = as_str(&f[1]).map_err(read_to_compile)?;
            Ok(table.intern(name))
        }
        other => Err(internal_x(&format!(
            "unknown prototype name form `{}`",
            other
        ))),
    }
}

/// Capture source node: ('local i) / ('captured i).
fn capture_source_from_value(v: &Value, heap: &Heap) -> Result<CaptureSource, CompileError> {
    let f = value_list_fields(v, heap).map_err(read_to_compile)?;
    if f.len() != 2 {
        return Err(internal_x("capture source field count abnormal"));
    }
    let kind = as_symbol_name(&f[0]).map_err(read_to_compile)?;
    let i = as_int(&f[1]).map_err(read_to_compile)? as u32;
    match kind {
        "local" => Ok(CaptureSource::Local(i)),
        "captured" => Ok(CaptureSource::Captured(i)),
        other => Err(internal_x(&format!("unknown capture source `{}`", other))),
    }
}

/// Instruction node: ('op code-int operands...) → `Op` (the code table
/// = opcode.rs's declaration order 0..=40 — the same table as
/// compiler.krf's OP-* constants).
fn op_from_value(v: &Value, heap: &Heap) -> Result<Op, CompileError> {
    let f = value_list_fields(v, heap).map_err(read_to_compile)?;
    if f.len() < 2 {
        return Err(internal_x("instruction node field count abnormal"));
    }
    let code = as_int(&f[1]).map_err(read_to_compile)?;
    let operands: Vec<i64> = f[2..]
        .iter()
        .map(|x| as_int(x).map_err(read_to_compile))
        .collect::<Result<_, _>>()?;
    let need = |n: usize| -> Result<(), CompileError> {
        if operands.len() != n {
            Err(internal_x(&format!(
                "opcode {} operand count abnormal({} ≠ {})",
                code,
                operands.len(),
                n
            )))
        } else {
            Ok(())
        }
    };
    Ok(match code {
        0 => {
            need(1)?;
            Op::PushConst(operands[0] as u32)
        }
        1 => {
            need(0)?;
            Op::PushNil
        }
        2 => {
            need(0)?;
            Op::PushTrue
        }
        3 => {
            need(0)?;
            Op::PushFalse
        }
        4 => {
            need(0)?;
            Op::Pop
        }
        5 => {
            need(0)?;
            Op::Dup
        }
        6 => {
            need(0)?;
            Op::Swap
        }
        7 => {
            need(1)?;
            Op::LoadLocal(operands[0] as u32)
        }
        8 => {
            need(1)?;
            Op::StoreLocal(operands[0] as u32)
        }
        9 => {
            need(1)?;
            Op::LoadGlobal(operands[0] as u32)
        }
        10 => {
            need(1)?;
            Op::StoreGlobal(operands[0] as u32)
        }
        11 => {
            need(1)?;
            Op::DefineGlobal(operands[0] as u32)
        }
        12 => {
            need(1)?;
            Op::LoadCaptured(operands[0] as u32)
        }
        13 => {
            need(1)?;
            Op::StoreCaptured(operands[0] as u32)
        }
        14 => {
            need(1)?;
            Op::Jump(operands[0] as u32)
        }
        15 => {
            need(1)?;
            Op::JumpIfFalse(operands[0] as u32)
        }
        16 => {
            need(2)?;
            Op::Closure {
                proto: operands[0] as u32,
                n_captures: operands[1] as u32,
            }
        }
        17 => {
            need(1)?;
            Op::Call(operands[0] as u32)
        }
        18 => {
            need(1)?;
            Op::TailCall(operands[0] as u32)
        }
        19 => {
            need(0)?;
            Op::Ret
        }
        20 => {
            need(0)?;
            Op::Add
        }
        21 => {
            need(0)?;
            Op::Sub
        }
        22 => {
            need(0)?;
            Op::Mul
        }
        23 => {
            need(0)?;
            Op::Div
        }
        24 => {
            need(0)?;
            Op::Mod
        }
        25 => {
            need(0)?;
            Op::NumLt
        }
        26 => {
            need(0)?;
            Op::NumGt
        }
        27 => {
            need(0)?;
            Op::NumLe
        }
        28 => {
            need(0)?;
            Op::NumGe
        }
        29 => {
            need(0)?;
            Op::NumEq
        }
        30 => {
            need(0)?;
            Op::Eq
        }
        31 => {
            need(0)?;
            Op::Not
        }
        32 => {
            need(0)?;
            Op::MakePair
        }
        33 => {
            need(0)?;
            Op::Car
        }
        34 => {
            need(0)?;
            Op::Cdr
        }
        35 => {
            need(0)?;
            Op::IsNull
        }
        36 => {
            need(0)?;
            Op::IsPair
        }
        37 => {
            need(0)?;
            Op::IsInt
        }
        38 => {
            need(0)?;
            Op::IsBool
        }
        39 => {
            need(0)?;
            Op::IsProcedure
        }
        40 => {
            need(0)?;
            Op::Halt
        }
        // r25/42-f effect opcodes (opcode.rs declaration order 41/42 —
        // the same table as compiler.krf's OP-* constants)
        41 => {
            need(4)?;
            Op::InstallHandler {
                handler: operands[0] as u32,
                body: operands[1] as u32,
                tag: operands[2] as u32,
                trampoline: operands[3] as u32,
            }
        }
        42 => {
            need(0)?;
            Op::Perform
        }
        // r30/48-d FFI opcodes (opcode.rs declaration order 43/44/45 —
        // the same table as compiler.krf's OP-* constants; not emitted
        // by the compilation arm (language surface Stage 3) — the
        // bridge completes them only for code-table completeness (the
        // code order is frozen three ways: enum ↔ bridge ↔ krf table))
        43 => {
            need(2)?;
            Op::CallExternal {
                symbol: operands[0] as u32,
                n_args: operands[1] as u32,
            }
        }
        44 => {
            need(1)?;
            Op::AllocExternal {
                size: operands[0] as u32,
            }
        }
        45 => {
            need(0)?;
            Op::FreeExternal
        }
        // r136 / 206-b (TD-033 — D14/D19): (op 46 hp₁ tk₁ … hp_N tk_N bp
        // tp) — interleaved arm operands, variable length; N = (len − 2)/2
        // (>= 1), even total, >= 6 operands
        46 => {
            if operands.len() < 6 || !operands.len().is_multiple_of(2) {
                return Err(internal_x(&format!(
                    "opcode 46 operand count abnormal ({} -- must be even and >= 6: interleaved arm operands hp₁ tk₁ … hp_N tk_N bp tp)",
                    operands.len()
                )));
            }
            let n = (operands.len() - 2) / 2;
            let mut entries: Vec<(u32, u32)> = Vec::with_capacity(n);
            for i in 0..n {
                entries.push((operands[2 * i] as u32, operands[2 * i + 1] as u32));
            }
            Op::InstallHandlerGroup {
                entries: entries.into_boxed_slice(),
                body: operands[operands.len() - 2] as u32,
                trampoline: operands[operands.len() - 1] as u32,
            }
        }
        other => {
            return Err(internal_x(&format!("unknown opcode {}", other)));
        }
    })
}

/// Constant node: ('constant tag value) → `BcConst` (sym interned via
/// the user table; symlit/str by content — content-equivalent to the
/// seed's interning).
fn const_from_value(
    v: &Value,
    heap: &Heap,
    table: &mut SymbolTable,
) -> Result<BcConst, CompileError> {
    let f = value_list_fields(v, heap).map_err(read_to_compile)?;
    if f.len() != 3 {
        return Err(internal_x("const node field count abnormal"));
    }
    let tag = as_symbol_name(&f[1]).map_err(read_to_compile)?;
    match tag {
        "int" => Ok(BcConst::Int(as_int(&f[2]).map_err(read_to_compile)?)),
        "float" => match &f[2] {
            Value::Float(x) => Ok(BcConst::Float(*x)),
            other => Err(internal_x(&format!(
                "float constant value type abnormal {}",
                other.type_name()
            ))),
        },
        "str" => Ok(BcConst::Str(Rc::from(
            as_str(&f[2]).map_err(read_to_compile)?,
        ))),
        "bool" => match &f[2] {
            Value::Bool(b) => Ok(BcConst::Bool(*b)),
            other => Err(internal_x(&format!(
                "bool constant value type abnormal {}",
                other.type_name()
            ))),
        },
        "nil" => Ok(BcConst::Nil),
        "sym" => {
            let name = as_str(&f[2]).map_err(read_to_compile)?;
            Ok(BcConst::Symbol(table.intern(name)))
        }
        "symlit" => Ok(BcConst::SymLit(Rc::from(
            as_str(&f[2]).map_err(read_to_compile)?,
        ))),
        other => Err(internal_x(&format!("unknown constant type `{}`", other))),
    }
}

// ---- Field access helpers ----

/// str list value → Symbol vector (interned via the user table).
fn symbol_vec_field(
    v: &Value,
    heap: &Heap,
    table: &mut SymbolTable,
) -> Result<Vec<Symbol>, CompileError> {
    let fields = value_list_fields(v, heap).map_err(read_to_compile)?;
    let mut out = Vec::with_capacity(fields.len());
    for f in &fields {
        let name = as_str(f).map_err(read_to_compile)?;
        out.push(table.intern(name));
    }
    Ok(out)
}

/// r165 / 236-c: the prototype record's params field — fixed params plus
/// the optional trailing `... rest` marker pair. Returns the fixed param
/// symbols and the rest slot index (= the fixed count, by the lowering-side
/// append-position invariant).
fn proto_params_from_value(
    v: &Value,
    heap: &Heap,
    table: &mut SymbolTable,
) -> Result<(Vec<Symbol>, Option<u32>), CompileError> {
    let all = symbol_vec_field(v, heap, table)?;
    if let Some(mark) = all.iter().position(|n| table.name(*n) == "...") {
        if mark + 2 != all.len() {
            return Err(internal_x(
                "proto params rest marker must be the last parameter",
            ));
        }
        let mut fixed = all;
        fixed.truncate(mark);
        Ok((fixed, Some(mark as u32)))
    } else {
        Ok((all, None))
    }
}

/// ReadError → CompileError (error-surface conversion for the shared
/// walk helpers — message and Span preserved faithfully).
fn read_to_compile(e: kerf_reader::ReadError) -> CompileError {
    CompileError {
        message: e.message,
        span: e.span,
    }
}

fn internal_x(msg: &str) -> CompileError {
    compile_internal(msg)
}

fn compile_internal(msg: &str) -> CompileError {
    CompileError {
        message: format!("[bootstrap-cmp] bootstrap Compiler internal error:{}", msg),
        span: Span::dummy(),
    }
}

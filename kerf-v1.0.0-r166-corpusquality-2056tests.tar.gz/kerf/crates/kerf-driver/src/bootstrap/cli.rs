//! Second build-system-segment incision bridge (r79 / 149-b — TD-032 CLI
//! orchestration surface carrier; the second production proof of the
//! 07 §3.3 Stage 2→3 signal "the build system can be rewritten in the new
//! language").
//!
//! Architecture (isomorphic to bootstrap_build.rs — second instance of the
//! incision-bridge pattern, CLI orchestration surface):
//! - **Orchestration logic**: `bootstrap/cli.ktf` (kerf source implementing
//!   the semantic port of the CLI subcommand dispatch decision
//!   `lcli-dispatch`, compiled via the seed pipeline and run on the Stage 0
//!   VM — consumes the two arguments `(cmd-str, has-file-bool)` passed
//!   through directly as VM values, **no Stx node serialization** (dispatch
//!   input is pure scalars — an even simpler bridge surface than the first
//!   incision; the six-head-field protocol belongs to the module parsing
//!   surface);
//! - **Bridge (this module)**: host-side invocation (`call_closure`
//!   two-argument injection) + Symbol tag → [`CliAction`] reconstruction;
//! - **Original Rust implementation (the former main.rs match dispatch)**:
//!   retired as parity oracle ([`dispatch_seed`] — `cli_krf_parity_tests`
//!   comparison, the three-piece switchover isomorphic discipline).
//!
//! **Production switch (r79/149-b) is in effect**: the root crate `kerf`'s
//! `main` dispatch decision goes through this entry. Switchover guards:
//! `production_cli_is_bootstrap` (liveness probe test) + parity corpus
//! (≥12 case dual-face equality + full-matrix scan).
//!
//! Heap contract: the cli.ktf persistent heap carries global constants and
//! per-call intermediate products — GC uses (stack + frames + globals) as
//! its root set, so cross-call collection is safe.
//!
//! Concurrency contract: thread_local state (Rc values are not Sync) —
//! lazily compiled and loaded once per thread (same as the existing five
//! bridges). The CLI lazily loads once per process (single-threaded main —
//! one seed-compilation cost, same order of magnitude as the first
//! incision's build.ktf load, <1ms).

use std::cell::RefCell;
use std::collections::HashMap;
use std::rc::Rc;

use kerf_compiler::BcProgram;
use kerf_runtime::Heap;
use kerf_span::SourceMap;
use kerf_syntax::{Symbol, SymbolTable};
use kerf_vm::{call_closure, run_program, Value, VmError};

use crate::builtins::register_globals;

/// cli.ktf source (embedded at compile time — self-contained artifact,
/// same policy as the existing incisions).
const CLI_SRC: &str = include_str!("cli.ktf");
/// cli.ktf source filename (Span diagnostic attribution).
const CLI_FILENAME: &str = "cli.ktf";
/// Entry name (a top-level definition of cli.ktf).
const ENTRY_NAME: &str = "lcli-dispatch";

/// CLI dispatch action (Rust mirror of the cli.ktf tags — the decision
/// result consumed by main.rs).
///
/// Twelve production actions + three error shapes (retired / missing file /
/// unknown — the else-message surface of the original main match is
/// rendered by the host per shape).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CliAction {
    /// `run <file>` — compile + VM execution.
    Run,
    /// `check <file>` — dry compilation (diagnostics only).
    Check,
    /// `test <file>` — case runner.
    Test,
    /// `tokens <file>` — token-stream dump.
    Tokens,
    /// `stx <file>` — syntax-object dump.
    Stx,
    /// `core <file>` — CoreExpr dump.
    Core,
    /// `ir <file>` — graph IR dump.
    Ir,
    /// `bc <file>` — bytecode disassembly.
    Bc,
    /// `code <file>` — CodeValue check.
    Code,
    /// `bench <file> [N]` — performance benchmark (the optional N argument
    /// is parsed separately host-side).
    Bench,
    /// `anf <file>` — AnnotatedANF IR summary.
    Anf,
    /// `native <file>` — QBE AOT compilation + execution.
    Native,
    /// `eval` — already retired (42-d P5: the self-hosted compiler + VM is
    /// the only production path).
    EvalRetired,
    /// The run/check/test triple missing the file argument (dedicated error
    /// message).
    NeedsFile,
    /// Unknown subcommand / dump family missing the file argument (usage
    /// print — the original `_` fallback arm).
    Unknown,
}

/// Self-hosted cli.ktf state (one per thread, lazily initialized).
struct BootstrapCliState {
    /// cli program bytecode (compiled via the seed pipeline).
    program: BcProgram,
    /// Loaded globals (builtins + cli.ktf top-level definitions).
    globals: HashMap<Symbol, Value>,
    /// The `lcli-dispatch` entry symbol.
    entry_sym: Symbol,
    /// Source map of cli.ktf (internal error diagnostic rendering).
    source_map: SourceMap,
    /// Persistent heap: global data + per-call products (GC root set includes globals).
    heap: Heap,
}

thread_local! {
    static BOOTSTRAP_CLI: RefCell<Option<BootstrapCliState>> = const {
        RefCell::new(None)
    };
}

/// CLI orchestration dispatch decision (**production path** — consumed by
/// the root crate's `main`).
///
/// Input = subcommand name + file-argument presence; output = dispatch
/// action. `Err` covers only bridge/cli.ktf internal defects (unreachable
/// protocol arms — fail-closed; the caller exits with code 1 and renders
/// the error — a bootstrap-phase defect surface separated from the normal
/// diagnostic channel).
pub fn dispatch(cmd: &str, has_file: bool) -> Result<CliAction, String> {
    with_cli(|st| {
        let callee = st.globals.get(&st.entry_sym).cloned().ok_or_else(|| {
            format!(
                "[bootstrap-cli] entry {} undefined (cli.ktf corrupted)",
                ENTRY_NAME
            )
        })?;
        let output = call_closure(
            &st.program,
            &mut st.globals,
            &mut st.heap,
            &callee,
            // Two-argument pass-through (pure scalar input — no Stx serialization surface)
            vec![Value::Str(Rc::from(cmd)), Value::Bool(has_file)],
        )
        .map_err(|e| vm_error_to_internal(&e, &st.source_map))?;
        action_of(&output)
    })
}

/// Rust seed oracle (the retired role of the original main.rs production
/// dispatch — parity comparison surface).
///
/// Semantic mirror (arm by arm of the pre-r79 main match): the twelve-tuple
/// truth values + eval retirement + the triple missing-file case + all the
/// rest unknown.
pub fn dispatch_seed(cmd: &str, has_file: bool) -> CliAction {
    match (cmd, has_file) {
        ("run", true) => CliAction::Run,
        ("check", true) => CliAction::Check,
        ("test", true) => CliAction::Test,
        ("tokens", true) => CliAction::Tokens,
        ("stx", true) => CliAction::Stx,
        ("core", true) => CliAction::Core,
        ("ir", true) => CliAction::Ir,
        ("bc", true) => CliAction::Bc,
        ("code", true) => CliAction::Code,
        ("bench", true) => CliAction::Bench,
        ("anf", true) => CliAction::Anf,
        ("native", true) => CliAction::Native,
        ("eval", _) => CliAction::EvalRetired,
        ("run" | "check" | "test", false) => CliAction::NeedsFile,
        _ => CliAction::Unknown,
    }
}

/// Execute with thread-local state (lazy initialization).
fn with_cli<T>(f: impl FnOnce(&mut BootstrapCliState) -> Result<T, String>) -> Result<T, String> {
    BOOTSTRAP_CLI.with(|cell| {
        let mut opt = cell.borrow_mut();
        if opt.is_none() {
            match load_cli() {
                Ok(state) => *opt = Some(state),
                Err(e) => return Err(e),
            }
        }
        f(opt.as_mut().expect("initialized above"))
    })
}

/// Compile and load cli.ktf (seed path — no recursion: the seed pipeline
/// compiles the self-hosted implementation, same P1 hard constraint as the
/// existing five bridges).
fn load_cli() -> Result<BootstrapCliState, String> {
    let front = crate::driver::compile_front_seed(CLI_SRC, CLI_FILENAME).map_err(|e| {
        format!(
            "[bootstrap-cli] cli.ktf compile failed (seed pipeline):{}",
            e.rendered
        )
    })?;
    build_state(front.program, front.table, front.source_map)
}

/// Build cli state from front-end outputs (single state-construction
/// implementation).
fn build_state(
    program: BcProgram,
    mut table: SymbolTable,
    source_map: SourceMap,
) -> Result<BootstrapCliState, String> {
    // cli.ktf has no I/O references (pure data transformation) — empty grant
    // (R9 fail-closed)
    let mut globals = register_globals(&mut table, &crate::capability::IoGrant::none());
    crate::builtins::resolve_hygiene_fallbacks(&program, &mut table, &mut globals);
    let mut heap = Heap::new();
    let outcome = run_program(&program, &mut globals, &mut heap)
        .map_err(|e| vm_error_to_internal(&e, &source_map))?;
    let _ = outcome; // The main prototype only executes top-level definitions (value meaningless)
    let entry_sym = table.intern(ENTRY_NAME);
    Ok(BootstrapCliState {
        program,
        globals,
        entry_sym,
        source_map,
        heap,
    })
}

/// VM tag value → [`CliAction`] (non-Symbol / unknown tag = protocol defect
/// — fail-closed; a pure decision function has no value-channel errors).
fn action_of(v: &Value) -> Result<CliAction, String> {
    let name = match v {
        Value::Symbol(s) => s.as_ref(),
        other => {
            return Err(format!(
                "[bootstrap-cli] entry result is not Symbol label(cli.ktf corrupted): {}",
                other.type_name()
            ))
        }
    };
    match name {
        "action-run" => Ok(CliAction::Run),
        "action-check" => Ok(CliAction::Check),
        "action-test" => Ok(CliAction::Test),
        "action-tokens" => Ok(CliAction::Tokens),
        "action-stx" => Ok(CliAction::Stx),
        "action-core" => Ok(CliAction::Core),
        "action-ir" => Ok(CliAction::Ir),
        "action-bc" => Ok(CliAction::Bc),
        "action-code" => Ok(CliAction::Code),
        "action-bench" => Ok(CliAction::Bench),
        "action-anf" => Ok(CliAction::Anf),
        "action-native" => Ok(CliAction::Native),
        "error-eval-retired" => Ok(CliAction::EvalRetired),
        "error-needs-file" => Ok(CliAction::NeedsFile),
        "error-unknown" => Ok(CliAction::Unknown),
        other => Err(format!(
            "[bootstrap-cli] unknown dispatch label {}(cli.ktf corrupted)",
            other
        )),
    }
}

/// VM error → internal error string (defensive path — a pure decision
/// function has no value-channel errors).
fn vm_error_to_internal(e: &VmError, sm: &SourceMap) -> String {
    use kerf_span::render_diagnostic;
    let diag = kerf_span::Diagnostic::error(
        Some(kerf_span::DiagnosticCode(2)),
        format!("bootstrap cli.ktf internal error:{}", e.message),
        e.span,
    );
    render_diagnostic(&diag, sm)
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Production liveness probe (switchover guard — mirrors the first
    /// incision's production_build_is_bootstrap shape): lazy loading +
    /// same-thread reuse + the basic dispatch triple.
    #[test]
    fn production_cli_is_bootstrap() {
        // The first decision triggers compile-and-load (lazy); run+file → Run
        assert_eq!(dispatch("run", true).expect("run dispatch"), CliAction::Run);
        // Same-thread reuse (state already loaded — the second call has zero
        // loading cost)
        assert_eq!(
            dispatch("run", false).expect("run missing file dispatch"),
            CliAction::NeedsFile
        );
        // State liveness: thread_local already initialized
        assert!(BOOTSTRAP_CLI.with(|cell| cell.borrow().is_some()));
    }
}

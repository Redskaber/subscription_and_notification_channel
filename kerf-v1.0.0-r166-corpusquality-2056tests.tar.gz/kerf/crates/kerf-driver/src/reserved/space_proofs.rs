//! Space-subordination proof tests (r66 / 123-a — both-side migration of the former
//! root_space.rs tests; the skeleton itself has moved to the `kerf-space` crate
//! [24 §5.4 — dependency cycle broken + Layer -1]).
//!
//! **Proof faces** (24 §5.3 both-side, two-layer machine proofs):
//! - Extension side: domain ownership of the 20 reserved contracts (`F: family contract ⟹
//!   F: owning domain ⟹ F: ExtensionSpace` — an A2 compile-time traversal of level-by-level
//!   transference) + root ownership (four-layer chain transitive closure);
//! - Core side: the skeleton's self-proof lives in the kerf-space crate (both-side chimneys +
//!   mutual-exclusion structure proofs + zero-payload anchors); the three-layer impls of the
//!   core main types live in the declaration sections of each crate's lib.rs.
//!
//! Function signatures are the proofs (compiles = the full supertrait chain is satisfied —
//! Rust enforces it layer by layer; a cross-level direct attachment would make the proof miss
//! a layer and fail to compile [A2 negative verification]).

use crate::reserved::{
    AiAssistant, CapabilityIO, CapabilityModelFamily, CompilationCache, CompilerService,
    DebugInfoGenerator, DebugTraceable, Effect, EffectFamily, EffectSystem, ExternalModule,
    FfiBoundary, IncrementalAst, LanguageService, MultiStage, PackageManager, Query, QuerySystem,
    Serializable, TokenCalculus,
};
use kerf_space::{ExtensionSpace, RootSpace};
// Probe domain markers are referenced only by test bodies (r69 / 134-a·D-3 — cfg gating
// keeps the non-test compilation unit free of unused-import warnings).
#[cfg(test)]
use kerf_space::CapabilityDomain;

/// Domain-ownership proof primitive (extension side): `F: family contract ⟹ F: owning domain
/// ⟹ F: ExtensionSpace` (the front-end machine proof of A2's hierarchy-only attachment).
fn require_ext_domain<T: ExtensionSpace>(_: Option<T>) {}
/// Root-ownership proof primitive: `F: family contract ⟹ … ⟹ F: RootSpace` (full-chain
/// transitive closure).
fn require_root<T: RootSpace>(_: Option<T>) {}

// ------------------------------------------------------------------
// Capability domain (CapabilityDomain) ownership proofs
// ------------------------------------------------------------------
#[allow(dead_code)]
fn capability_model_family_in_capability_domain<F: CapabilityModelFamily>() {
    require_ext_domain::<F>(None);
}
#[allow(dead_code)]
fn token_calculus_in_capability_domain<F: TokenCalculus>() {
    require_ext_domain::<F>(None);
}
#[allow(dead_code)]
fn capability_io_in_capability_domain<F: CapabilityIO>() {
    require_ext_domain::<F>(None);
}

// ------------------------------------------------------------------
// Effect domain (EffectDomain) ownership proofs
// ------------------------------------------------------------------
#[allow(dead_code)]
fn effect_family_in_effect_domain<F: EffectFamily>() {
    require_ext_domain::<F>(None);
}
#[allow(dead_code)]
fn effect_in_effect_domain<F: Effect>() {
    require_ext_domain::<F>(None);
}
#[allow(dead_code)]
fn effect_system_in_effect_domain<F: EffectSystem>() {
    require_ext_domain::<F>(None);
}

// ------------------------------------------------------------------
// Metaprogramming domain (MetaprogrammingDomain — renamed from SyntaxDomain in v2.0)
// ownership proofs
// ------------------------------------------------------------------
#[allow(dead_code)]
fn multistage_in_metaprogramming_domain<F: MultiStage>() {
    require_ext_domain::<F>(None);
}

// ------------------------------------------------------------------
// Toolchain domain (ToolchainDomain) ownership proofs
// ------------------------------------------------------------------
#[allow(dead_code)]
fn compilation_cache_in_toolchain_domain<F: CompilationCache>() {
    require_ext_domain::<F>(None);
}
#[allow(dead_code)]
fn language_service_in_toolchain_domain<F: LanguageService>() {
    require_ext_domain::<F>(None);
}
#[allow(dead_code)]
fn incremental_ast_in_toolchain_domain<F: IncrementalAst>() {
    require_ext_domain::<F>(None);
}
#[allow(dead_code)]
fn debug_info_generator_in_toolchain_domain<F: DebugInfoGenerator>() {
    require_ext_domain::<F>(None);
}
#[allow(dead_code)]
fn debug_traceable_in_toolchain_domain<F: DebugTraceable>() {
    require_ext_domain::<F>(None);
}
#[allow(dead_code)]
fn query_system_in_toolchain_domain<F: QuerySystem>() {
    require_ext_domain::<F>(None);
}
#[allow(dead_code)]
fn query_in_toolchain_domain<F: Query>() {
    require_ext_domain::<F>(None);
}
#[allow(dead_code)]
fn compiler_service_in_toolchain_domain<F: CompilerService>() {
    require_ext_domain::<F>(None);
}
#[allow(dead_code)]
fn serializable_in_toolchain_domain<F: Serializable>() {
    require_ext_domain::<F>(None);
}
#[allow(dead_code)]
fn package_manager_in_toolchain_domain<F: PackageManager>() {
    require_ext_domain::<F>(None);
}
#[allow(dead_code)]
fn external_module_in_toolchain_domain<F: ExternalModule>() {
    require_ext_domain::<F>(None);
}
#[allow(dead_code)]
fn ai_assistant_in_toolchain_domain<F: AiAssistant>() {
    require_ext_domain::<F>(None);
}

// ------------------------------------------------------------------
// Foreign domain (ForeignDomain) ownership proofs
// ------------------------------------------------------------------
#[allow(dead_code)]
fn ffi_boundary_in_foreign_domain<F: FfiBoundary>() {
    require_ext_domain::<F>(None);
}

// ------------------------------------------------------------------
// Root-ownership proofs (existing since r62 — r65 four-layer chain / r66 v2.0 rename
// migration: probes implement the full chain explicitly so transference does not rely on
// inference magic; a cross-level direct attachment would make the probe miss a layer and fail
// to compile)
// ------------------------------------------------------------------
#[allow(dead_code)]
fn effect_family_in_root<F: EffectFamily>() {
    require_root::<F>(None);
}
#[allow(dead_code)]
fn effect_in_root<F: Effect>() {
    require_root::<F>(None);
}
#[allow(dead_code)]
fn effect_system_in_root<F: EffectSystem>() {
    require_root::<F>(None);
}
#[allow(dead_code)]
fn capability_model_family_in_root<F: CapabilityModelFamily>() {
    require_root::<F>(None);
}
#[allow(dead_code)]
fn token_calculus_in_root<F: TokenCalculus>() {
    require_root::<F>(None);
}
#[allow(dead_code)]
fn capability_io_in_root<F: CapabilityIO>() {
    require_root::<F>(None);
}
#[allow(dead_code)]
fn multistage_in_root<F: MultiStage>() {
    require_root::<F>(None);
}
#[allow(dead_code)]
fn compilation_cache_in_root<F: CompilationCache>() {
    require_root::<F>(None);
}
#[allow(dead_code)]
fn ffi_boundary_in_root<F: FfiBoundary>() {
    require_root::<F>(None);
}
#[allow(dead_code)]
fn language_service_in_root<F: LanguageService>() {
    require_root::<F>(None);
}
#[allow(dead_code)]
fn incremental_ast_in_root<F: IncrementalAst>() {
    require_root::<F>(None);
}
#[allow(dead_code)]
fn debug_info_generator_in_root<F: DebugInfoGenerator>() {
    require_root::<F>(None);
}
#[allow(dead_code)]
fn debug_traceable_in_root<F: DebugTraceable>() {
    require_root::<F>(None);
}
#[allow(dead_code)]
fn query_system_in_root<F: QuerySystem>() {
    require_root::<F>(None);
}
#[allow(dead_code)]
fn query_in_root<F: Query>() {
    require_root::<F>(None);
}
#[allow(dead_code)]
fn compiler_service_in_root<F: CompilerService>() {
    require_root::<F>(None);
}
#[allow(dead_code)]
fn serializable_in_root<F: Serializable>() {
    require_root::<F>(None);
}
#[allow(dead_code)]
fn package_manager_in_root<F: PackageManager>() {
    require_root::<F>(None);
}
#[allow(dead_code)]
fn external_module_in_root<F: ExternalModule>() {
    require_root::<F>(None);
}
#[allow(dead_code)]
fn ai_assistant_in_root<F: AiAssistant>() {
    require_root::<F>(None);
}

#[test]
fn root_space_membership_all_reserved_traits() {
    // The 20+20 proof functions above compiling = every reserved contract trait belongs to
    // the root space and its own domain via a complete supertrait chain (constraint-
    // conjunction transitive closure — the "skeleton" face of the 13 §3.8 three-layer
    // reservation system + 24 §5.3 two-layer machine proofs; the functions being uncalled
    // does not weaken the compile-time assertions — the signature is the proof).
    // Runtime anchor: the root marker carries no semantic payload (zero cost — a type-level
    // endorsement of the documentation discipline).
    fn is_root_marker_zero_cost<T: RootSpace>(_: &T) -> bool {
        // The marker is satisfiable by any zero-sized type — declaration is ownership.
        true
    }
    struct Anchor;
    impl RootSpace for Anchor {}
    impl ExtensionSpace for Anchor {}
    impl CapabilityDomain for Anchor {}
    assert!(is_root_marker_zero_cost(&Anchor));
}

/// Extension-side five-level chain chimney (v1.0 r65 migration + v2.0 rename version —
/// 24 §5.1): the implementation body explicitly declares all four layers of the chain
/// (root/extension/domain/family) — compiling proves the chain length is exactly four; a
/// cross-level direct attachment (missing the domain layer) makes this test fail to compile
/// (A2 negative verification). The core-side chimney (three-layer chain) is in the kerf-space
/// crate tests ([24 §5.3] both-side chimney pair).
#[test]
fn five_level_hierarchy_chain_smoke() {
    /// Chimney implementation body: the full chain declared explicitly (the hierarchical
    /// version of "declaration is ownership" — every level of subordination is an explicit
    /// ruling trace, 24 §5.1; the L3 family layer is covered generically by the 40 proof
    /// functions above — family contracts carry abstract methods and are not re-implemented
    /// here).
    struct ChimneyProbe;
    impl RootSpace for ChimneyProbe {}
    impl ExtensionSpace for ChimneyProbe {}
    impl CapabilityDomain for ChimneyProbe {}

    // Double anchor of domain ownership and root ownership (ChimneyProbe satisfies the
    // explicit four-layer chain)
    fn assert_domain<T: CapabilityDomain>(_: &T) {}
    fn assert_root<T: RootSpace>(_: &T) {}
    assert_domain(&ChimneyProbe);
    assert_root(&ChimneyProbe);
}

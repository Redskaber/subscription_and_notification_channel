//! Capability-model I/O interface reservation (stage0.md §9.1.3 / lang-design 13 §3.1.3
//! — P2: types + complete behavioral specification; revised in v5.2).
//!
//! **Why reserve this**: a security model with least privilege (linear tokens — verified in
//! the same shape as Rust ownership); since r8 the consumption face is `crate::capability`
//! (require/IoGrant gating — "basic transfer" implemented).
//!
//! **Split note (r18 / 40-g)**: split out of mod.rs (§13.4 J1 — aligns with the 13 §3.1.3
//! section structure); zero changes to signatures and behavioral specification (principle 27
//! frozen contracts).
//!
//! **Layer-position note (r19 / 41-a)**: this file is the **io family instance** (the first
//! instance of the capability model, not the model itself) — the model-layer skeleton (family
//! shape + token calculus slots) is in `capability_model.rs` (capability-model-design.md D3:
//! model layer and family layer are separate; IO ⊂ capability model — family taxonomy and
//! the chemical-reaction matrix are in design doc §4/§5).
//!
//! **Complete behavioral specification** (P2 — Stage 1 can implement directly from it):
//! 1. `read_line` is callable only while holding a `ReadCapability` — the token is passed
//!    linearly and can be neither copied nor forged;
//! 2. `write_line` likewise (`WriteCapability`);
//! 3. An I/O call without a token is a **compile-time error** (permission verification, not a
//!    runtime check);
//! 4. Replacement relation with Stage 0 traditional I/O (kerf-runtime::io global functions):
//!    progressive replacement principle §28 — the driver-registered builtins change to the
//!    capability-parameterized form, and the global functions are gradually retired.
//!
//! Stage 0 ruling: traditional I/O (§21.10 decision point 3); the capability model is basic at
//! Stage 1 / fully introduced at Stage 2.

//! **r65 / 118-a hierarchy note**: the io family instance contract in this file belongs to
//! the **capability domain** (`trait CapabilityIO: CapabilityDomain` — row 3 of the
//! 24-space-decomposition §7 fix table [a violation called out by the user]: instance layer
//! attached directly to the root = a cross-level attachment violation; after the re-attachment
//! fix the domain ownership is decidable).

use kerf_space::CapabilityDomain;

/// Read capability token (unforgeable — private construction, obtained via permission
/// transfer).
pub struct ReadCapability {
    _private: (),
}

/// Write capability token (unforgeable).
pub struct WriteCapability {
    _private: (),
}

/// Capability-model I/O error.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct IOError {
    pub message: String,
}

/// Capability-model I/O (§9.1.3 reserved interface — implemented at Stage 1+; r62/107-a once
/// attached it directly to the root space [flat attachment], **r65/118-a re-attaches it level
/// by level to the capability domain** — `trait CapabilityIO: CapabilityDomain` constraint-
/// conjunction ownership, 24 §7 fix table).
pub trait CapabilityIO: CapabilityDomain {
    /// Read one line (requires the read capability).
    fn read_line(cap: &mut ReadCapability) -> Result<String, IOError>;

    /// Write one line (requires the write capability).
    fn write_line(cap: &mut WriteCapability, s: &str) -> Result<(), IOError>;
}

// ---------------------------------------------------------------------------
// Token minting (r8 batch D — pub(crate): tokens flow out only via the driver composition
// root; external crates can reference the types but cannot construct them — constructor-
// surface control for "obtained via permission transfer")
// ---------------------------------------------------------------------------

/// Mint a read capability token (called only by the crate::capability authorization
/// pipeline — minted per the program's declared (require io read); 13 §3.1.3 specification
/// clause 1).
pub(crate) fn mint_read_token() -> ReadCapability {
    ReadCapability { _private: () }
}

/// Mint a write capability token (as above — specification clause 2).
pub(crate) fn mint_write_token() -> WriteCapability {
    WriteCapability { _private: () }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn capability_tokens_are_unforgeable() {
        // Private construction: the outside cannot construct ReadCapability (compile-time
        // guarantee)
        // This test verifies the token types can be referenced but not instantiated
        fn takes_read(_cap: &ReadCapability) {}
        fn takes_write(_cap: &WriteCapability) {}
        let _ = (
            takes_read as fn(&ReadCapability),
            takes_write as fn(&WriteCapability),
        );
    }
}

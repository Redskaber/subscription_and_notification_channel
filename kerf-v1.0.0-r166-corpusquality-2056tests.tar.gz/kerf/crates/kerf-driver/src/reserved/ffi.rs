//! FFI boundary interface reservations (stage0.md §9.3.4 / lang-design 13 §3.3.4 — P1,
//! absorbed in next4 round eight, frozen in batch r12).
//!
//! **Why reserve this**: a systems language must interoperate with C/system APIs — the type
//! system must be able to express "external types", and the GC must be able to recognize
//! "external references" (pin/unpin protocol).
//!
//! **Self-hosting compliance note**: the **implementation** of FFI is deferred to Stage 2
//! (it would break the self-hosting loop, 13 §3.2); this reservation only covers type shapes
//! and the GC boundary protocol, introduces no compile-time dependency on the host C ABI, and
//! does not touch the self-hosting chain (same policy as the §21 backend strategy).

use kerf_core::CoreExpr;
use kerf_space::ForeignDomain;
use kerf_syntax::Symbol;
use kerf_vm::Value;

// ---------------------------------------------------------------------------
// External type representation (P3 shape — a subset of the C ABI type system)
// ---------------------------------------------------------------------------

/// C integer size (C ABI alignment convention).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum CIntSize {
    I8,
    U8,
    I16,
    U16,
    I32,
    U32,
    I64,
    U64,
    Isize,
    Usize,
}

/// Pointer pointee type (P3 shape — description of the pointee).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum PointeeType {
    /// `void*` — opaque.
    Void,
    /// `uint8_t*` — byte buffer.
    U8,
    /// `char*` — NUL-terminated string.
    Char,
}

/// Type representation for foreign function calls (P3 shape — a recursive C type subset).
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub enum ExternalType {
    /// C integer.
    CInt(CIntSize),
    /// C pointer.
    CPointer(PointeeType),
    /// C struct (field order = memory layout order).
    CStruct(Vec<ExternalType>),
    /// C function type (parameter → result).
    CFunction {
        param: Box<ExternalType>,
        result: Box<ExternalType>,
    },
    /// Opaque external type (declared via headers, not constructible).
    Opaque(String),
}

// ---------------------------------------------------------------------------
// FFI call primitives (P3 shape — the reserved placement where core expressions can express
// "external calls")
// ---------------------------------------------------------------------------

/// Core primitives of FFI calls (Stage 2 compilation target; Stage 0 only freezes the shape).
///
/// **Reserved contract**: core expressions must be able to express "external calls" — this
/// enum is the shape freeze of that representation; external memory allocation/freeing does
/// not go through the GC (explicit lifetime).
#[derive(Debug, Clone, PartialEq)]
pub enum FfiCall {
    /// Call an external function (symbol + arguments + return type).
    CallExternal {
        symbol: Symbol,
        args: Vec<CoreExpr>,
        return_type: ExternalType,
    },
    /// Allocate external memory (outside the GC).
    AllocExternal { size: usize },
    /// Free external memory.
    FreeExternal { ptr: CoreExpr },
}

// ---------------------------------------------------------------------------
// FFI boundary (isolation protocol between the GC and external memory — P1)
// ---------------------------------------------------------------------------

/// FFI boundary (GC isolation protocol).
///
/// **Complete behavioral specification** (P1 — Stage 2 can implement directly from it):
/// 1. `pin_object`: mark an object as referenced by external code — the GC **must not
///    reclaim** it (reference-counting-style barrier, enters the root set);
/// 2. `unpin_object`: clear the mark (after the external side releases the reference);
/// 3. `ExternalPointer`: the wrapper type for external pointers — wrapped values are not
///    tracked by the GC; dereferencing is an explicit operation;
/// 4. Relation to the 05-runtime §3 allocator protocol: "FFI external-reference tracking" is
///    its already-registered evolution direction — this trait is the interface freeze of that
///    direction.
///
/// r65/118-a re-attaches level by level to the **foreign domain** (the interaction channel
/// between the kerf and non-kerf worlds — type mapping/pin protocol/calling-convention
/// semantic payload; the FFI **token** lives in the capability domain [model-layer instance
/// anchor FfiTokenShape] — permission belongs to the capability domain, the channel belongs to
/// the foreign domain, cooperating rather than subordinate; row 20 of the 24-space-
/// decomposition §7 fix table).
pub trait FfiBoundary: ForeignDomain {
    /// Wrapper type for external pointers.
    type ExternalPointer;

    /// Mark an object as referenced by external code (the GC must not reclaim it).
    fn pin_object(&mut self, obj: Value);

    /// Clear the external-reference mark.
    fn unpin_object(&mut self, obj: Value);
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::reserved::{ExtensionSpace, ForeignDomain, RootSpace};
    use kerf_core::LiteralValue;
    use kerf_span::Span;

    /// P1 freeze test: the FFI shapes prove their contracts frozen via "test implementations
    /// compile".
    #[derive(Default)]
    struct ProbeFfiBoundary {
        pinned: u32,
    }
    impl RootSpace for ProbeFfiBoundary {}
    impl ExtensionSpace for ProbeFfiBoundary {}
    impl ForeignDomain for ProbeFfiBoundary {}
    impl FfiBoundary for ProbeFfiBoundary {
        type ExternalPointer = *const u8;
        fn pin_object(&mut self, _obj: Value) {
            self.pinned += 1;
        }
        fn unpin_object(&mut self, _obj: Value) {
            self.pinned = self.pinned.saturating_sub(1);
        }
    }

    #[test]
    fn ffi_reserved_signatures_are_frozen() {
        let mut b = ProbeFfiBoundary::default();
        b.pin_object(Value::Nil);
        assert_eq!(b.pinned, 1);
        b.unpin_object(Value::Nil);
        assert_eq!(b.pinned, 0);
    }

    #[test]
    fn external_type_is_recursive_and_hashable() {
        // CStruct/CFunction recursive shapes + content-addressed hashability (cache-key
        // convention)
        let t1 = ExternalType::CStruct(vec![
            ExternalType::CInt(CIntSize::I32),
            ExternalType::CPointer(PointeeType::U8),
        ]);
        let t2 = ExternalType::CStruct(vec![
            ExternalType::CInt(CIntSize::I32),
            ExternalType::CPointer(PointeeType::U8),
        ]);
        assert_eq!(t1, t2);
        let t3 = ExternalType::CFunction {
            param: Box::new(ExternalType::CInt(CIntSize::I64)),
            result: Box::new(ExternalType::Opaque("FILE".into())),
        };
        assert_ne!(t1, t3);
        // The derived Hash is usable (content addressing)
        use std::collections::hash_map::DefaultHasher;
        use std::hash::{Hash, Hasher};
        let mut h1 = DefaultHasher::new();
        t1.hash(&mut h1);
        let mut h2 = DefaultHasher::new();
        t2.hash(&mut h2);
        assert_eq!(h1.finish(), h2.finish());
    }

    #[test]
    fn ffi_call_carries_core_expr_arguments() {
        // "Core expressions must be able to express external calls" — FfiCall's argument slots
        // carry CoreExpr (shape proof: constructible, carries Span-semantic values)
        let arg = CoreExpr::Literal {
            value: LiteralValue::Int(7),
            span: Span::dummy(),
        };
        let call = FfiCall::CallExternal {
            symbol: Symbol(3),
            args: vec![arg.clone()],
            return_type: ExternalType::CInt(CIntSize::I32),
        };
        match &call {
            FfiCall::CallExternal { symbol, args, .. } => {
                assert_eq!(*symbol, Symbol(3));
                assert_eq!(args.len(), 1);
            }
            _ => unreachable!("construction is CallExternal"),
        }
        let alloc = FfiCall::AllocExternal { size: 128 };
        assert_eq!(
            alloc,
            FfiCall::AllocExternal { size: 128 },
            "usize size field can comparison"
        );
        let _free = FfiCall::FreeExternal { ptr: arg };
    }
}

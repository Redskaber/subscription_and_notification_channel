//! Interface reservation layer (stage0.md §9 / lang-design 13 §3.1 + §3.3-§3.5; 14 items
//! after the v6.1 completeness review).
//!
//! **Frozen contracts, no implementations** — eight submodules organized one file per
//! capability family (r18 / 40-g split: J1 aligns with the 13 §3.1 section structure; this
//! file carries only module declarations and re-exports; r19 / 41-a adds the model-layer
//! skeleton; **r65 / 118-a hierarchy orthogonal decomposition — the 20 contracts re-attached
//! level by level to the six domains** [24-space-decomposition §4.1/§7 — capability domain 3 /
//! effect domain 3 / syntax domain 1 / toolchain domain 12 / foreign domain 1; the optimization
//! domain has zero members so no marker §4.6], fixing cross-level direct-attachment
//! violations [CapabilityIO etc. attached directly to the root → attached to their owning
//! domains]):
//!
//! | Submodule | Level | Domain ownership (r65) | Contents |
//! |---|---|---|---|
//! | [`capability_model`] | P3 | **capability domain** | Capability model skeleton (**model layer** — `CapabilityModelFamily`/`TokenCalculus`; r19/41-a — the ownership anchor for the IO family as first instance / the FFI token as second instance) |
//! | [`effect_handlers`] | P3 | **effect domain** | Effect handlers (`EffectFamily`/`Effect`/`EffectSystem` — type shapes only) |
//! | [`multistage`] | P3 | **syntax domain** | Multistage programming (`MultiStage` — quote/splice/run) |
//! | [`capability_io`] | P2 | **capability domain** | Capability-model I/O (**io family instance** — `ReadCapability`/`WriteCapability`/`CapabilityIO` + complete behavioral specification; model layer: [`capability_model`]) |
//! | [`compilation_cache`] | P2 | **toolchain domain** | Compilation cache (`CacheKey`/`CachedResult`/`CompilationCache` + complete behavioral specification) |
//! | [`toolchain`] | P0/P1/P2 | **toolchain domain** | Toolchain ecosystem (LSP/debug/incremental queries + compiler-as-a-service + package management/AI) |
//! | [`ffi`] | P1 | **foreign domain** | FFI boundary (`ExternalType`/`FfiCall`/`FfiBoundary` — GC pin/unpin protocol; the FFI token lives in the capability domain [model-layer instance anchor]) |
//! | [`codegen`] | P1 | compiler-internal space (not attached) | Multi-target backends (`CodegenBackend`/`WasmBackend` — LLVM never enters the self-hosting chain) |
//! | [`space_proofs`] | — | — (skeleton moved to kerf-space) | Space-subordination proof tests (20-contract domain ownership + root ownership + both-side chimneys — 24 §5.3; the skeleton itself = the kerf-space crate [24 §5.4 r66 migration]) |
//!
//! **Module separation of contracts and implementations** (40-g standardization note): the
//! consumption faces that implement the two P2 items = `crate::capability` (r8 capability
//! gating) and `crate::cache` (r7 query-style cache); the consumption face of P3 effects =
//! `crate::effects` (r8 metalayer escape). Implementation deepening evolves in each
//! implementation module per the "progressive replacement principle"; contract signatures stay
//! unchanged.
//!
//! **Effect extension and capability delegation** (13 §3.3.10 ruling): no new data-structure
//! placement — distributed effects extend via custom effect families on the `Effect` associated
//! type (Stage 3+); capability delegation/composition is layered in library form on top of this
//! module's token types (Stage 1+), signatures unchanged.
//!
//! **Interface stability principle** (§2.2 principle 27): all signatures in this module stay
//! backward compatible for their entire lifecycle — evolution only replaces implementations,
//! never breaks contracts (re-export paths stay permanently valid).
//!
//! **Progressive replacement principle** (§2.2 principle 28): meta-circular evaluator →
//! compiler, traditional I/O → capability model, traditional closures → effect handlers — the
//! attachment points of every replacement path are frozen here.
//!
//! **Reserved-blank principle** (§2.2 principle 32, v6.1): the essence of reserving is
//! "leaving room for the future", not "implementing early" — it demands compatibility of
//! data structures and type definitions, not completeness of functionality. Every reservation
//! proves its contract frozen via a Probe implementation that compiles (test anchors: the
//! per-submodule `*_signature_is_frozen` family).

mod capability_io;
mod capability_model;
mod codegen;
mod compilation_cache;
mod effect_handlers;
mod ffi;
mod multistage;
mod space_proofs;
mod toolchain;

pub use capability_io::{CapabilityIO, IOError, ReadCapability, WriteCapability};
pub use capability_model::{CapabilityModelFamily, TokenCalculus};
pub use codegen::{
    AnnotatedANF, CodegenBackend, CodegenError, CompiledModule, PassDescriptor, TargetTriple,
    WasmBackend, WasmComponent,
};
pub use compilation_cache::{CacheKey, CachedResult, CompilationCache};
pub use effect_handlers::{Effect, EffectFamily, EffectSystem};
pub use ffi::{CIntSize, ExternalType, FfiBoundary, FfiCall, PointeeType};
/// Space skeleton marker family (r66 / 123-a — forwarded from the kerf-space crate:
/// **the 24 v2.0 both-side unified system** — root `RootSpace` [renamed from ExtensibleRoot] +
/// core space `CoreSpace` + extension space `ExtensionSpace` [renamed from ExtensibleSpace] +
/// the seven core domains + extension domains [including `MetaprogrammingDomain` renamed from
/// SyntaxDomain]; the skeleton's physical home has moved to kerf-space [24 §5.4 — dependency
/// cycle broken + Layer -1], and this path is the composition-root forwarding face [principle
/// 27: paths stay permanently valid]; the space-subordination proof tests = [`space_proofs`]).
pub use kerf_space::{
    CapabilityDomain, CoreSpace, EffectDomain, ExtensionSpace, ForeignDomain,
    MetaprogrammingDomain, RootSpace, ToolchainDomain,
};
pub use multistage::MultiStage;
pub use toolchain::{
    Address, AiAssistant, AstNodeId, CodeAction, CompileJobId, CompileRequest, CompileResult,
    CompileStatus, CompileTarget, CompilerService, CompletionItem, DebugInfoGenerator,
    DebugInfoRequest, DebugTraceable, DependencyGraph, DeserializeError, DwarfSections, EditError,
    ExternalModule, FetchError, FunctionSignature, IncrementalAst, LanguageService, Location,
    LockFile, ModuleSource, OptLevel, PackageArtifact, PackageManager, PackageManifest, Position,
    Query, QueryDescriptor, QueryResult, QuerySystem, Refactoring, RenameError, ResolveError,
    ReusePlan, SemanticSummary, Serializable, SourceMapBlob, SyntaxNodeRef, TextEdit,
    TypeCheckResult, TypeError, TypeInfo, VarId, WorkspaceEdit,
};

// Crate-visible face (pub use group placed last — clearly separated from the public
// forwarding-face grouping): token minting is reachable only within the crate (flows out of the
// driver composition root — constructor-surface control, upheld by the r8 batch D ruling).
pub(crate) use capability_io::{mint_read_token, mint_write_token};

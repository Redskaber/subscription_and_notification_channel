//! Multistage programming interface reservation (stage0.md §9.1.2 / lang-design 13 §3.1.2 —
//! P3, type shapes only).
//!
//! **Why reserve this**: the expressiveness foundation of compile-time computation and code
//! generation (comptime) — MetaOCaml is theoretically complete (well-formed/well-typed/
//! well-scoped); the implementation is heuristic.
//!
//! **Split note (r18 / 40-g)**: split out of mod.rs (§13.4 J1 — aligns with the 13 §3.1.2
//! section structure); zero changes to signatures and behavioral specification (principle 27
//! frozen contracts).
//!
//! **Behavioral specification** (MetaOCaml semantics, stage0.md §6.1):
//! - `quote`: lifts an expression into a code value (well-formed/well-typed/well-scoped
//!   guarantees);
//! - `splice`: splices a code value into the current stage's syntax;
//! - `run`: executes future-stage code (originally to be implemented at Stage 2; re-ruled in
//!   v6.3/r27: multistage as a whole is DEFERred to a Stage 3 maturity re-evaluation —
//!   12 §2.5.1 row + plan §5d disposition table, on zero-consumption grounds).
//!
//! Stage 0 ruling: meta-circular evaluator (§21.10 decision point 1); multistage replaces it
//! at Stage 2+ (re-ruled: DEFER to Stage 3 — r27 §5d).
//!
//! **r65 / 118-a hierarchy note**: `MultiStage` is re-attached level by level to the **syntax
//! domain** (metaprogramming — the code-manipulating-code semantic payload; row 7 of the
//! 24-space-decomposition §7 fix table: cross-level direct-attachment fix).

use kerf_core::CoreExpr;
use kerf_runtime::RuntimeError;
use kerf_space::MetaprogrammingDomain;
use kerf_vm::Value;

/// Multistage programming (§9.1.2 reserved interface — DEFERred to a Stage 3 maturity
/// re-evaluation: re-ruled per the r27/§5d disposition table, the signature freeze is upheld
/// per principle 27).
///
/// Stage 0 ruling: meta-circular evaluator (§21.10 decision point 1); multistage replaces it
/// at Stage 2+ (re-ruled: DEFER to Stage 3 — r27). r65/118-a re-attaches it level by level to
/// the syntax domain (24 §7 fix table).
pub trait MultiStage: MetaprogrammingDomain {
    /// Code value type (concretized with the Stage 3 multistage window — `CodeValue` is the
    /// candidate).
    type Code;

    /// Quote: expression → code value (implemented with the Stage 3 window).
    fn quote(&self, expr: &CoreExpr) -> Self::Code;

    /// Splice: code value → current-stage code (implemented with the Stage 3 window).
    fn splice(&self, code: &Self::Code) -> Result<CoreExpr, RuntimeError>;

    /// Execute a code value (implemented with the Stage 3 window).
    fn run(&self, code: &Self::Code) -> Result<Value, RuntimeError>;
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::reserved::{ExtensionSpace, MetaprogrammingDomain, RootSpace};
    use kerf_core::CodeValue;

    /// P3 freeze test: the signature proves the contract frozen via "test implementations
    /// compile" (§27 interface stability — later stages implement directly against this
    /// signature).
    struct ProbeMultiStage;
    impl RootSpace for ProbeMultiStage {}
    impl ExtensionSpace for ProbeMultiStage {}
    impl MetaprogrammingDomain for ProbeMultiStage {}
    impl MultiStage for ProbeMultiStage {
        type Code = CodeValue;
        fn quote(&self, expr: &CoreExpr) -> CodeValue {
            CodeValue::from_expr(expr)
        }
        fn splice(&self, _code: &CodeValue) -> Result<CoreExpr, RuntimeError> {
            Err(RuntimeError::new(
                "P3 reserved: splice Stage 2 implementation",
            ))
        }
        fn run(&self, _code: &CodeValue) -> Result<Value, RuntimeError> {
            Err(RuntimeError::new("P3 reserved: run Stage 2 implementation"))
        }
    }

    #[test]
    fn multistage_signature_is_frozen() {
        let m = ProbeMultiStage;
        let expr = CoreExpr::Literal {
            value: kerf_core::LiteralValue::Int(1),
            span: kerf_span::Span::dummy(),
        };
        let cv = m.quote(&expr);
        assert!(cv.is_well_formed());
    }
}

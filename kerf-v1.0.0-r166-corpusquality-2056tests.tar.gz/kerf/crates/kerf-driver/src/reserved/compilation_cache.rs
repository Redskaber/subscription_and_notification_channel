//! Compilation cache interface reservation (stage0.md §9.1.4 / lang-design 13 §3.1.4 — P2:
//! types + complete behavioral specification; since r7 batch C the consumption face is
//! `crate::cache` (in-memory content addressing + three methods implemented)).
//!
//! **Why reserve this**: the foundation of incremental compilation/query-style caching
//! (validated by rustc/salsa).
//!
//! **Split note (r18 / 40-g)**: split out of mod.rs (§13.4 J1 — aligns with the 13 §3.1.4
//! section structure); zero changes to signatures and behavioral specification (principle 27
//! frozen contracts). The implementation lives in `crate::cache` (implemented in r7 — the
//! module separation of contract and implementation).
//!
//! **Complete behavioral specification** (P2 — Stage 1 can implement directly from it):
//! 1. `get_cached`: on a key hit, return the artifact (content addressing — same source +
//!    same config → necessarily equivalent artifact, directly reusable without recompiling);
//! 2. `store`: write into the cache (idempotent — same key overwrites);
//! 3. `invalidate`: explicit invalidation (source changes are naturally distinguished by the
//!    key hash; this method covers full-invalidation scenarios such as compiler upgrades);
//! 4. Stage 2 deepening: query-style incremental compilation (salsa-style dependency graph);
//!    these three methods keep their signatures unchanged (progressive replacement principle
//!    §28).

use kerf_compiler::BcProgram;
use kerf_core::{CodeValue, ModuleItem};
use kerf_space::ToolchainDomain;

/// Cache key (source hash + compilation config fingerprint — the key of deterministic
/// compilation).
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct CacheKey {
    /// Source text content hash (Stage 1: SHA-256 content addressing).
    pub source_hash: u64,
    /// Compilation config fingerprint (stage version + options).
    pub config_fingerprint: u64,
}

/// Cached result (compilation artifact — bytecode + core expressions).
#[derive(Debug, Clone)]
pub struct CachedResult {
    /// Bytecode program.
    pub program: BcProgram,
    /// Program items (r49 D59 declaration layer — for diagnostics and CodeValue checks).
    pub core: Vec<ModuleItem>,
    /// The code value corresponding to the artifact (structured checking).
    pub code_value: Option<CodeValue>,
}

/// Compilation cache (§9.1.4 reserved interface — the "query style" implemented at Stage 1;
/// r62/107-a once attached it directly to the root space, **r65/118-a re-attaches it level by
/// level to the toolchain domain** — compile-time service-oriented semantic payload, row 8 of
/// the 24-space-decomposition §7 fix table).
pub trait CompilationCache: ToolchainDomain {
    /// Query the cache.
    fn get_cached(&self, key: &CacheKey) -> Option<CachedResult>;

    /// Write into the cache.
    fn store(&mut self, key: CacheKey, result: CachedResult);

    /// Invalidate a cache entry.
    fn invalidate(&mut self, key: &CacheKey);
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::reserved::{ExtensionSpace, RootSpace};

    /// P2 freeze test: the signature proves the contract frozen via "test implementations
    /// compile".
    struct ProbeCache;
    impl RootSpace for ProbeCache {}
    impl ExtensionSpace for ProbeCache {}
    impl ToolchainDomain for ProbeCache {}
    impl CompilationCache for ProbeCache {
        fn get_cached(&self, _key: &CacheKey) -> Option<CachedResult> {
            None
        }
        fn store(&mut self, _key: CacheKey, _result: CachedResult) {}
        fn invalidate(&mut self, _key: &CacheKey) {}
    }

    fn empty_program() -> BcProgram {
        BcProgram {
            protos: vec![],
            consts: vec![],
            entry: 0,
            global_refs: vec![],
            module_name: None,
        }
    }

    #[test]
    fn compilation_cache_signature_is_frozen() {
        let mut c = ProbeCache;
        c.store(
            CacheKey {
                source_hash: 1,
                config_fingerprint: 1,
            },
            CachedResult {
                program: empty_program(),
                core: vec![],
                code_value: None,
            },
        );
        assert!(c
            .get_cached(&CacheKey {
                source_hash: 1,
                config_fingerprint: 1
            })
            .is_none());
    }

    #[test]
    fn cache_key_is_content_addressed() {
        let k1 = CacheKey {
            source_hash: 42,
            config_fingerprint: 1,
        };
        let k2 = CacheKey {
            source_hash: 42,
            config_fingerprint: 1,
        };
        assert_eq!(k1, k2);
        let k3 = CacheKey {
            source_hash: 43,
            config_fingerprint: 1,
        };
        assert_ne!(k1, k3);
    }
}

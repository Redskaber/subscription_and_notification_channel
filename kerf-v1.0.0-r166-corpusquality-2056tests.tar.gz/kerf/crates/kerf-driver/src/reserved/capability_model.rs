//! Capability model skeleton reservation (model layer — r19 / 41-a; ruling D3/D4 in
//! develop/v0/stage-2/capability-model-design.md: model layer and family layer are separate).
//!
//! **Why reserve this**: the general shape of the capability security model (issuing/transfer/
//! attenuation/revocation/verification of permissions). IO is the first instance
//! ([`capability_io`] — r8 implemented basic transfer), and the FFI linear token
//! (`ExternalType::CPointer` — design frozen in ffi-ownership-model.md) is the second instance;
//! before the Stage 2 net/process families arrive there must be a model-layer anchor, otherwise
//! every new family is a "five-point surgery" (design D11 — the surgery surface converges to a
//! three-point addition: enum variant + gating-table row + family file).
//!
//! **Layering note (r19 / 41-a)**: this file is the **model-layer skeleton** of 13 §3.1.3
//! — not counted toward the reserved-item count (14 items unchanged); the family-layer contract
//! (capability_io.rs) and the authorization pipeline (crate::capability) have zero signature
//! changes (principle 27). **The model layer's public surface contains no family-specific
//! names** (Io prefix forbidden — prevents re-coupling of the layers).
//!
//! **Calculus-slot reservation** (ruling of the design D12 window):
//! - mint: each family's internal pub(crate) constructor surface (already implemented — not a
//!   placeholder);
//! - delegate: passing a token by value *is* delegation (carried implicitly — not a
//!   placeholder);
//! - attenuate: derive a child token with only-reduced, never-increased permissions (mid
//!   Stage 2);
//! - revoke: invalidate a token (Stage 3 — the unified-semantics window for effect resumption).
//!
//! **Chemical-reaction anchors** (design §5 — orthogonal and composable, not merged):
//! capability × effect (perform requires a token + handler = permission scope) /
//! capability × multistage (code values carry a capability set — verified by run) /
//! capability × cache (CacheKey gains a capability face) / capability × HM (token types are
//! not generalizable).
//!
//! Stage 0 ruling: the capability model is basic at Stage 1 (✅ delivered in r8) / complete at
//! Stage 2 (net/process families + calculus implemented — 12 §2.4.5).
//!
//! **r65 / 118-a hierarchy note**: the two model-layer contracts in this file belong to the
//! **capability domain** (`CapabilityModelFamily`/`TokenCalculus: CapabilityDomain` — rows 1/2
//! of the fix table in 24-space-decomposition §7: the model-layer abstraction is subordinate
//! to the same domain as the instance layer [capability_io] — abstraction→concrete layering
//! within the capability domain [24 §4.3]).

use kerf_space::CapabilityDomain;

/// Capability family shape (model layer — the type-ownership anchor for family instances, P3).
///
/// Family instances (io/ffi/net/process/…) each freeze their own contract (one family per
/// file — the 40-g convention); this trait only declares the unified shape of a "family": token
/// type + family declaration name (the family segment of `(require <family> <member> ...)`).
/// Since r62/107-a it attaches to the root space (constraint-conjunction ownership — principle
/// 40); **r65/118-a re-attaches it level by level to the capability domain** (24 §7 fix table —
/// fixes the cross-level direct attachment).
pub trait CapabilityModelFamily: CapabilityDomain {
    /// Family token type (unforgeable — each family's internal private constructor +
    /// pub(crate) minting surface).
    type Token;

    /// Family declaration name (the family segment of `(require <family> ...)` — e.g.
    /// io/ffi/net).
    fn family_name() -> &'static str;
}

/// Token calculus shape (model layer — explicit calculus slots at Stage 2/3, P3).
///
/// mint/delegate are already carried by each family's constructor surface and by passing
/// tokens by value (not placeholders); this trait reserves two explicit calculus slots.
/// **Calculus methods have no default body** — any implementation must provide them explicitly
/// (a P3 slot cannot be silently polluted by an implementation). r65/118-a re-attaches it level
/// by level to the capability domain (24 §7 fix table).
pub trait TokenCalculus: CapabilityDomain {
    /// Token type.
    type Token;

    /// Attenuate: derive a child token with only-reduced, never-increased permissions
    /// (attenuation — mid Stage 2; implemented when the net family arrives).
    fn attenuate(source: &Self::Token) -> Self::Token;

    /// Revoke: invalidate a token (revocation — Stage 3; the unified-semantics window for
    /// effect resumption).
    fn revoke(token: &mut Self::Token);
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::reserved::{ExtensionSpace, RootSpace};
    // Family-instance type anchor (model-instance ownership proof — the test face references
    // family-layer types; the production-face submodule stays zero-dependency §13.4 J3)
    use crate::reserved::{ExternalType, ReadCapability, WriteCapability};

    /// P3 freeze test: the signature proves the contract frozen via "test implementations
    /// compile" (principle 27 — later stages implement the calculus slots directly against
    /// this signature).
    struct ProbeNetFamily;
    struct ProbeNetToken {
        granted: bool,
    }
    impl RootSpace for ProbeNetFamily {}
    impl ExtensionSpace for ProbeNetFamily {}
    impl CapabilityDomain for ProbeNetFamily {}
    impl CapabilityModelFamily for ProbeNetFamily {
        type Token = ProbeNetToken;
        fn family_name() -> &'static str {
            "net"
        }
    }
    impl TokenCalculus for ProbeNetFamily {
        type Token = ProbeNetToken;
        fn attenuate(source: &ProbeNetToken) -> ProbeNetToken {
            // Attenuation semantic shape: only reduce, never increase (Probe demonstration —
            // granted kept; a real implementation may derive a subset of permissions)
            ProbeNetToken {
                granted: source.granted,
            }
        }
        fn revoke(token: &mut ProbeNetToken) {
            token.granted = false;
        }
    }

    #[test]
    fn capability_model_skeleton_is_frozen() {
        // Compiles = contract frozen (same shape as the multistage.rs Probe)
        assert_eq!(ProbeNetFamily::family_name(), "net");
        let mut t = ProbeNetToken { granted: true };
        let attenuated = <ProbeNetFamily as TokenCalculus>::attenuate(&t);
        assert!(attenuated.granted);
        <ProbeNetFamily as TokenCalculus>::revoke(&mut t);
        assert!(!t.granted);
    }

    /// Model-instance ownership proof (io family): both IO family tokens satisfy the model
    /// family shape (machine-checked proof of design D3's layer separation — io ⊂ capability
    /// model: the code-side proof of the judgment "IO is just a subset of the capability
    /// model").
    struct IoReadShape;
    impl RootSpace for IoReadShape {}
    impl ExtensionSpace for IoReadShape {}
    impl CapabilityDomain for IoReadShape {}
    impl CapabilityModelFamily for IoReadShape {
        type Token = ReadCapability;
        fn family_name() -> &'static str {
            "io"
        }
    }
    struct IoWriteShape;
    impl RootSpace for IoWriteShape {}
    impl ExtensionSpace for IoWriteShape {}
    impl CapabilityDomain for IoWriteShape {}
    impl CapabilityModelFamily for IoWriteShape {
        type Token = WriteCapability;
        fn family_name() -> &'static str {
            "io"
        }
    }

    #[test]
    fn io_family_tokens_satisfy_model_shape() {
        assert_eq!(IoReadShape::family_name(), "io");
        assert_eq!(IoWriteShape::family_name(), "io");
        // The token type compiling as the Token associated type = ownership proof (shape
        // assertion: the associated type matches the family instance's token type)
        fn token_of<F: CapabilityModelFamily>() -> fn(&F::Token) {
            fn ptr<T>(_: &T) {}
            ptr::<F::Token>
        }
        let read_token_fn: fn(&ReadCapability) = token_of::<IoReadShape>();
        let write_token_fn: fn(&WriteCapability) = token_of::<IoWriteShape>();
        let _ = (read_token_fn, write_token_fn);
    }

    /// FFI linear-token placement proof (design D8): the CPointer carrier type satisfies the
    /// family shape (ExternalType::CPointer — the model-layer ownership of the design frozen
    /// in ffi-ownership-model.md).
    struct FfiTokenShape;
    impl RootSpace for FfiTokenShape {}
    impl ExtensionSpace for FfiTokenShape {}
    impl CapabilityDomain for FfiTokenShape {}
    impl CapabilityModelFamily for FfiTokenShape {
        type Token = ExternalType;
        fn family_name() -> &'static str {
            "ffi"
        }
    }

    #[test]
    fn ffi_family_token_satisfies_model_shape() {
        assert_eq!(FfiTokenShape::family_name(), "ffi");
        fn token_of<F: CapabilityModelFamily>() -> fn(&F::Token) {
            fn ptr<T>(_: &T) {}
            ptr::<F::Token>
        }
        let ffi_token_fn: fn(&ExternalType) = token_of::<FfiTokenShape>();
        let _ = ffi_token_fn;
    }

    /// Calculus-slot signature proof: attenuate/revoke are obtainable as function pointers —
    /// the signatures are frozen (`&Token -> Token` / `&mut Token -> ()`), and there is no
    /// default implementation body (implementers must provide them explicitly — the Probe is
    /// itself the proof).
    #[test]
    fn calculus_slots_are_stage_positions() {
        let attenuate_fn: fn(&ProbeNetToken) -> ProbeNetToken =
            <ProbeNetFamily as TokenCalculus>::attenuate;
        let revoke_fn: fn(&mut ProbeNetToken) = <ProbeNetFamily as TokenCalculus>::revoke;
        let mut t = ProbeNetToken { granted: true };
        assert!(attenuate_fn(&t).granted);
        revoke_fn(&mut t);
        assert!(!t.granted);
    }
}

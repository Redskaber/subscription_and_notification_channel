//! Effect Handlers interface reservation (stage0.md §9.1.1 / lang-design 13 §3.1.1 — P3,
//! type shapes only; since r8 batch D the consumption face is `crate::effects`, implemented
//! inside the compiler).
//!
//! **Why reserve this**: the unified mechanism for async/error recovery/custom control flow —
//! OCaml 5 practice (Forester 6.0) proves the "early practice" tier of maturity.
//!
//! **Split note (r18 / 40-g)**: split out of mod.rs (§13.4 J1 — aligns with the 13 §3.1.1
//! section structure); zero changes to signatures and behavioral specification (principle 27
//! frozen contracts).
//!
//! **Behavioral specification** (full semantics at implementation time: stage0.md §6.4 + the
//! r18 effect language-level design `stage-2/effect-language-design.md` — design frozen,
//! implementation window D12 = after batch I):
//! - `perform`: suspends the current computation and searches upward for a matching handler;
//! - `handle`: installs a handler and runs the computation — when an effect triggers, resumes
//!   via the continuation.
//!
//! Stage 0 ruling: traditional closures (§21.10 decision point 2); Effects are introduced at
//! the language level at Stage 2.
//!
//! **r65 / 118-a hierarchy note**: the three effect-domain contracts in this file
//! (family/instance/system layers — 24 §4.1 intra-domain layering) are re-attached level by
//! level to the **effect domain** (rows 4-6 of the 24-space-decomposition §7 fix table:
//! cross-level direct-attachment fixes — the side-effect interception semantic payload
//! belongs to the effect domain).

use kerf_vm::Value;

use kerf_space::EffectDomain;

/// Effect family (P3 reserved): relates effect operations and result types. r65/118-a
/// re-attaches it level by level to the effect domain (24 §7 fix table).
pub trait EffectFamily: EffectDomain {
    /// Result value after performing the effect (P3 shape: concretized as Value — may be
    /// refined into a generic associated type when implemented at Stage 2).
    type Result;
}

/// Effect (P3 reserved): description of an effect operation. r65/118-a re-attaches it level
/// by level to the effect domain (24 §7).
pub trait Effect: EffectDomain {
    /// The owning effect family.
    type Family: EffectFamily<Result = Value>;
}

/// Effect Handlers (§9.1.1 reserved interface — implemented at Stage 2).
///
/// Stage 0 ruling: traditional closures (§21.10 decision point 2); Effects are introduced at
/// the language level at Stage 2.
pub trait EffectSystem: EffectDomain {
    type Effect: Effect;
    type Handler;
    type Continuation;

    /// Perform an effect: suspend and propagate upward (implemented at Stage 2; P3 shape:
    /// result carried via Value).
    fn perform(&self, effect: Self::Effect) -> Value;

    /// Install an effect handler and run the computation (implemented at Stage 2).
    fn handle(&self, handler: Self::Handler, computation: impl FnOnce() -> Value) -> Value;
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::reserved::{EffectDomain, ExtensionSpace, RootSpace};

    /// P3 freeze test: the signature proves the contract frozen via "test implementations
    /// compile" (§27 interface stability — later stages implement directly against this
    /// signature).
    struct ProbeEffects;
    // r66/123-a: the former u8 domain-shape probe became a local zero-sized struct (after the
    // trait moved to kerf-space, a primitive-type impl trips E0117 orphan rules — a measured
    // demonstration of the mechanism boundary of "declaration is ownership"; the shape
    // semantics [Effect::Family relating back to the EffectFamily impl] is unchanged)
    struct EffectAtomProbe;
    impl RootSpace for EffectAtomProbe {}
    impl ExtensionSpace for EffectAtomProbe {}
    impl EffectDomain for EffectAtomProbe {}
    impl EffectFamily for EffectAtomProbe {
        type Result = Value;
    }
    impl Effect for EffectAtomProbe {
        type Family = EffectAtomProbe;
    }
    impl RootSpace for ProbeEffects {}
    impl ExtensionSpace for ProbeEffects {}
    impl EffectDomain for ProbeEffects {}
    impl EffectSystem for ProbeEffects {
        type Effect = EffectAtomProbe;
        type Handler = ();
        type Continuation = ();
        fn perform(&self, _effect: Self::Effect) -> Value {
            Value::Nil
        }
        fn handle(&self, _handler: Self::Handler, computation: impl FnOnce() -> Value) -> Value {
            computation()
        }
    }

    #[test]
    fn effect_handlers_signature_is_frozen() {
        let e = ProbeEffects;
        assert!(matches!(e.perform(EffectAtomProbe), Value::Nil));
    }
}

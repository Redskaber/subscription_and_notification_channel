//! Multi-target backend interface reservation (stage0.md §9.3.7 / lang-design 13 §3.3.7 —
//! P1).
//!
//! **Implementation-migration note (38-b, batch G)**: this module's contract types and traits
//! have moved to their formal home `kerf-backend/src/codegen.rs` (AnnotatedANF concretization +
//! QbeBackend as the first implemented backend). A thin re-export remains here — per §2.2
//! principle 27 "signatures stay backward compatible": the historical reference paths from
//! the r12 freeze period (`kerf_driver::reserved::*`) keep working (the `reserved_ext_tests`
//! contract latch tests staying unchanged is the demonstrated proof of migration
//! compatibility).
//!
//! **Self-hosting compliance note** (08-backend-evolution / §21): LLVM never enters the
//! self-hosting chain; QBE is a host-side toolchain (kerf-backend is the ~20% Rust
//! infrastructure part).

pub use kerf_backend::codegen::{
    CodegenBackend, CodegenError, CompiledModule, PassDescriptor, TargetTriple, WasmBackend,
    WasmComponent,
};

// After concretization AnnotatedANF carries the function definition set
// (kerf-backend::anf::AFuncDef) — this module does not re-export the concretized type (the
// reservation layer's semantics stop at contract shape; the full concretized face is consumed
// via the kerf-backend public path); the fingerprint field's semantics are unchanged.
pub use kerf_backend::anf::AnnotatedANF;

#[cfg(test)]
mod tests {
    use super::*;
    use kerf_space::{CoreBackendDomain, CoreSpace, RootSpace};

    /// Migration-compatibility latch: reservation-layer path → formal-home types (principle 27
    /// — evolutionary replacement of implementations does not break contracts: old-path
    /// visibility + signature consistency).
    #[test]
    fn reserved_path_reexports_formal_contract() {
        struct ProbeWasm;
        // r66/123-a: after WasmBackend attaches to CoreBackendDomain, the probe's full chain is
        // completed (the core-side contract's implementation body is explicit across the whole
        // chain — 24 §5.1 both-side version)
        impl RootSpace for ProbeWasm {}
        impl CoreSpace for ProbeWasm {}
        impl CoreBackendDomain for ProbeWasm {}
        impl WasmBackend for ProbeWasm {
            fn compile_component(&self, _ir: &AnnotatedANF) -> Result<WasmComponent, CodegenError> {
                Ok(WasmComponent::default())
            }
        }
        let t = TargetTriple("bytecode-vm".into());
        let e = CodegenError::new("probe");
        assert_eq!(e.reason, "probe");
        let m = CompiledModule {
            target: t.clone(),
            bytes: vec![],
        };
        assert_eq!(m.target, t);
        let ir = AnnotatedANF::default();
        assert_eq!(ir.fingerprint, 0);
        // Trait reachability (type-level)
        fn assert_backend<B: CodegenBackend>(_: &B) {}
        assert_backend(&kerf_backend::QbeBackend);
        // WasmBackend contract shape (placeholder unchanged through the migration — a
        // type-level anchor via generic function types)
        fn assert_wasm<W: WasmBackend>(_: &W) {}
        let _ = assert_wasm::<ProbeWasm>;
        let _ = PassDescriptor { name: "probe" };
        let _ = WasmComponent::default();
    }
}

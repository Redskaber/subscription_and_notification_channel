//! Toolchain ecosystem interface reservations
//! (stage0.md §9.3.2/§9.3.3/§9.3.5/§9.3.6/§9.3.8/§9.3.9,
//! lang-design 13 §3.3.2/§3.3.3/§3.3.5/§3.3.6/§3.3.8/§3.3.9 — absorbed in next4 round eight,
//! frozen in batch r12).
//!
//! **Three P0 items** (data-structure placement must be frozen at Stage 0 — not reserving =
//! months of destructive refactoring):
//! - LSP/IDE queries: `LanguageService` (syntax/semantic queries — principle 14 "the toolchain
//!   is the compiler") + `IncrementalAst` (incremental AST updates);
//! - Debug info: `DebugInfoGenerator` (IR↔source mapping, variable locations, DWARF/source maps) +
//!   `DebugTraceable` (IR-node back-links + debug names);
//! - Incremental compilation queries: `QuerySystem` + `Query` (salsa-style — pure-function
//!   queries + fully declared dependencies + on-demand invalidation).
//!
//! **P1**: `CompilerService` (compiler as a service) + `Serializable` (serializable boundary).
//! **P2**: `PackageManager` + `ExternalModule` (package management); `AiAssistant`
//! (AI-assisted semantic API — reuses the LanguageService query infrastructure).
//!
//! **Reconciliation of existing data-structure placement (P0 preconditions)**:
//! - Traceable Span per node ✓ (CoreExpr/NodeMetadata/`debug_spans` across the pipeline);
//! - Queryable scopes for bindings ✓ (`IrGraph::NodeMetadata.scopes: ScopeSet`);
//! - Stable variable IDs ✓ (`kerf_core::ir::NodeId`; proto index + slots on the bytecode side);
//! - Unique identification of function boundaries ✓ (`BcProgram::protos` index = stable
//!   prototype identity);
//! - Debug frame slots ✓ (VM `ext3: Option<DebugFrameSlot>`, empty shape at Stage 0).
//!
//! Integration checks: tests/v0/stage1/plan/reserved_ext_tests.rs.

use kerf_compiler::BcProgram;
use kerf_core::ir::NodeId;
use kerf_space::ToolchainDomain;
use kerf_span::{Diagnostic, FileId, Span};
use kerf_syntax::Symbol;

// ---------------------------------------------------------------------------
// Shared shape types (P3 frozen — Stage 1+ may refine into rich types; signature compatibility
// comes first)
// ---------------------------------------------------------------------------

/// Source position (line/column, 1-based — the LSP protocol convention).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Position {
    pub line: u32,
    pub column: u32,
}

/// Source location range (file + Span) — shared by LSP `Location` and debug lookups.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Location {
    pub file: FileId,
    pub span: Span,
}

/// Text edit (incremental update unit — LSP didChange → IncrementalAst::apply_edit).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct TextEdit {
    pub file: FileId,
    pub span: Span,
    pub new_text: String,
}

/// Syntax tree node reference (P3 shape: carried by NodeId; refined into a red-green tree
/// cursor at Stage 1).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct SyntaxNodeRef {
    pub node: NodeId,
}

/// Completion item (P3 shape: label + insert text).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CompletionItem {
    pub label: String,
    pub insert_text: String,
}

/// Type info (P3 shape: structured description string — wired to the type checker's rich types
/// at Stage 1).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct TypeInfo {
    pub description: String,
}

/// Code action (quick fix — P3 shape: title + text edit).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CodeAction {
    pub title: String,
    pub edit: TextEdit,
}

/// Workspace edit (rename result — multiple edits across files).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct WorkspaceEdit {
    pub edits: Vec<TextEdit>,
}

/// Rename error (P3 shape: reason string).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RenameError {
    pub reason: String,
}

/// Edit application error (the failure surface of IncrementalAst::apply_edit).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct EditError {
    pub reason: String,
}

/// Reuse plan (list of unchanged subtrees reusable during incremental re-parsing — P3 shape).
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct ReusePlan {
    pub reusable_nodes: Vec<NodeId>,
}

/// Stable variable ID (for debug info — a stable identity distinct from de Bruijn indices).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct VarId(pub u32);

/// Stable AST node ID (P3 shape of the IR → AST back-link).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct AstNodeId(pub u32);

/// Target code address (bytecode pc / future native-code offset — P3 shape).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct Address(pub u32);

/// DWARF debug sections (P3 shape: byte envelope — concretized per the DWARF standard at
/// Stage 2).
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct DwarfSections {
    pub bytes: Vec<u8>,
}

/// Source map (P3 shape: byte envelope — bridges to the serialized form of kerf-span
/// SourceMap).
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct SourceMapBlob {
    pub bytes: Vec<u8>,
}

// ---------------------------------------------------------------------------
// 1. LSP/IDE query interfaces (P0, 13 §3.3.2)
// ---------------------------------------------------------------------------

/// Interface for the compiler acting as a language server (Stage 2 implements a basic LSP
/// server).
///
/// **Reserved contract** (not implemented): Stage 0 only freezes the query shapes — the
/// implementation side (rust-analyzer style) consumes the same syntax tree/symbol table/
/// diagnostic stream as the compiler (principles 13/14).
pub trait LanguageService: ToolchainDomain {
    /// Syntax query: the syntax tree node at a position.
    fn syntax_tree_at(&self, file: FileId, pos: Position) -> Option<SyntaxNodeRef>;

    /// Syntax query: completion items.
    fn completion_items(&self, file: FileId, pos: Position) -> Vec<CompletionItem>;

    /// Syntax query: document symbols (top-level binding list).
    fn document_symbols(&self, file: FileId) -> Vec<Symbol>;

    /// Semantic query: definition location (goto definition).
    fn definition_of(&self, file: FileId, pos: Position) -> Option<Location>;

    /// Semantic query: reference list (find references).
    fn references_to(&self, file: FileId, pos: Position) -> Vec<Location>;

    /// Semantic query: the type at a position (hover — wired to the type checker at Stage 1).
    fn type_at(&self, file: FileId, pos: Position) -> Option<TypeInfo>;

    /// Diagnostics: the current diagnostic stream.
    fn diagnostics(&self, file: FileId) -> Vec<Diagnostic>;

    /// Diagnostics: quick-fix suggestions.
    fn quick_fixes(&self, file: FileId, pos: Position) -> Vec<CodeAction>;

    /// Refactoring: symbol rename (cross-file workspace edit).
    fn rename_symbol(
        &mut self,
        file: FileId,
        pos: Position,
        new_name: String,
    ) -> Result<WorkspaceEdit, RenameError>;
}

/// Incremental AST update interface (P0 — the AST-side hook for on-demand LSP re-parsing and
/// incremental compilation).
pub trait IncrementalAst: ToolchainDomain {
    /// Apply a text edit (the entry point of incremental re-parsing).
    fn apply_edit(&mut self, edit: &TextEdit) -> Result<(), EditError>;

    /// Invalidate a range (marks the area affected by an edit).
    fn invalidate_range(&mut self, range: Span);

    /// Reuse plan: compare with another version and return the reusable unchanged subtrees.
    fn reuse_unchanged(&self, other: &Self) -> ReusePlan;
}

// ---------------------------------------------------------------------------
// 2. Debug info generation interfaces (P0, 13 §3.3.3)
// ---------------------------------------------------------------------------

/// Debug info generator (Stage 2 generates source maps, Stage 2+ generates DWARF).
///
/// **Reconciliation of existing placement**: on the VM side, `debug_spans` + `debug_info_table`
/// (bytecode pc → Span lookup) are already implemented (consumed by stack traces); this trait
/// promotes that same capability to a standard interface.
pub trait DebugInfoGenerator: ToolchainDomain {
    /// Map an IR node to a source location.
    fn source_location_of(&self, ir_node: NodeId) -> Option<Span>;

    /// Map a target code address back to an IR node.
    fn ir_node_at(&self, code_addr: Address) -> Option<NodeId>;

    /// Location info for a variable (which register/stack slot — for debugger variable
    /// inspection).
    fn variable_location(&self, var: VarId, at_pc: Address) -> Option<Location>;

    /// Generate DWARF debug sections.
    fn generate_dwarf(&self) -> DwarfSections;

    /// Generate a source map.
    fn generate_source_map(&self) -> SourceMapBlob;
}

/// Debug traceability of IR nodes (implemented by every IR node).
///
/// **Reserved contract**: the AST↔IR back-link is carried by the stable `AstNodeId` identity
/// (P3 shape); debug names are distinct from de Bruijn indices (`Option<Symbol>` — captured/
/// parameter names).
pub trait DebugTraceable: ToolchainDomain {
    /// AST → IR back-link (trace back from IR to the source syntax tree).
    fn ast_node_id(&self) -> AstNodeId;

    /// Debug name of a variable (not just a de Bruijn index).
    fn debug_name(&self) -> Option<Symbol>;
}

// ---------------------------------------------------------------------------
// 3. Incremental compilation query interfaces (P0, 13 §3.3.5 — dual reservation with the
// compilation cache: data plane + architecture plane)
// ---------------------------------------------------------------------------

/// Query descriptor (P3 shape: name + input fingerprint — the minimal shape of salsa's
/// QueryDescriptor).
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct QueryDescriptor {
    /// Query name (pass name — Reader/Expand/Compile/Typecheck...).
    pub name: &'static str,
    /// Input fingerprint (content addressing — aligned with the CacheKey convention).
    pub input_fingerprint: u64,
}

/// Query result envelope (P3 shape: fingerprint + cache-hit flag; concretized into a typed
/// query table at Stage 1).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct QueryResult {
    /// Output fingerprint (the green side of red-green testing).
    pub output_fingerprint: u64,
    /// Whether the cache was hit (a measure of incremental compilation effectiveness).
    pub cached: bool,
}

/// Query system: all compilation operations run through queries (rustc/Salsa style).
///
/// **Reserved contract**: every compiler pass must be modeled as a query; queries must be able
/// to declare dependencies on each other; query results must be cacheable/invalidatable
/// (§13.1/15 §3.1 elaborate in the main text).
pub trait QuerySystem: ToolchainDomain {
    /// Input: source files (their content-addressed key — aligned with the CacheKey convention).
    type Input;

    /// Execute a query (with caching + dependency tracking).
    fn query(&self, descriptor: &QueryDescriptor) -> QueryResult;

    /// Invalidate related caches when an input changes (reverse propagation through the
    /// dependency graph).
    fn invalidate(&mut self, input: Self::Input);

    /// Dependency tracking: which other queries query Q depends on.
    fn dependencies_of(&self, descriptor: &QueryDescriptor) -> Vec<QueryDescriptor>;
}

/// A single query (every compiler pass must be modeled as a query).
pub trait Query: ToolchainDomain {
    type Input;
    type Output;

    /// Other queries this query depends on (dependencies must be fully declared).
    fn dependencies(&self) -> Vec<QueryDescriptor>;

    /// Execute the query (a pure function — same input always yields the same output).
    ///
    /// The query system's input key and the query input share the same type (one content-
    /// addressing convention).
    fn execute(&self, db: &dyn QuerySystem<Input = Self::Input>) -> Self::Output;
}

// ---------------------------------------------------------------------------
// 4. Compiler-as-a-service interfaces (P1, 13 §3.3.6)
// ---------------------------------------------------------------------------

/// Compile job ID (submission receipt for the service form).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct CompileJobId(pub u64);

/// Compile status (service-oriented lifecycle).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CompileStatus {
    Queued,
    Running,
    Completed,
    Failed,
    Cancelled,
}

/// Compile target (multi-target convention — bridges with codegen::TargetTriple).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CompileTarget {
    /// Bytecode (the only execution backend at Stage 0).
    Bytecode,
    /// Native code (Stage 2 QBE/Cranelift — not part of the self-hosting chain).
    Native,
    /// WebAssembly (Stage 2+ component model).
    Wasm,
}

/// Optimization level.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum OptLevel {
    None,
    Default,
    Aggressive,
}

/// Debug info requirements.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DebugInfoRequest {
    None,
    Spans,
    Full,
}

/// Compile request (supports incremental input).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CompileRequest {
    /// Full source (P3 shape: String; Stage 2 incremental form = baseline + edit stream).
    pub source: String,
    /// Compile target.
    pub target: CompileTarget,
    /// Optimization level.
    pub opt_level: OptLevel,
    /// Debug info requirements.
    pub debug_info: DebugInfoRequest,
}

/// Compile result (P3 shape: bytecode artifact + diagnostic stream — the service return
/// surface).
#[derive(Debug, Clone)]
pub struct CompileResult {
    /// Bytecode artifact (present when the target is Bytecode).
    pub program: Option<BcProgram>,
    /// Compilation diagnostic stream (structured — can be streamed).
    pub diagnostics: Vec<Diagnostic>,
}

/// The compiler as a remotely callable service (P1 — the web Playground is the host-side
/// prototype).
pub trait CompilerService: ToolchainDomain {
    /// Submit a compile request (asynchronous — returns a job receipt).
    fn submit(&mut self, request: CompileRequest) -> CompileJobId;

    /// Query compile status.
    fn status(&self, job: CompileJobId) -> Option<CompileStatus>;

    /// Fetch the compile result (once completed).
    fn result(&self, job: CompileJobId) -> Option<CompileResult>;

    /// Stream diagnostics (P3 shape: carried in a Vec; refined into a stream at Stage 2).
    fn diagnostics_stream(&self, job: CompileJobId) -> Vec<Diagnostic>;

    /// Cancel a compilation (interruptibility reservation).
    fn cancel(&mut self, job: CompileJobId);
}

/// Serializable boundary (a precondition for transmitting compiler state — P1).
pub trait Serializable: ToolchainDomain {
    fn serialize(&self) -> Vec<u8>;

    fn deserialize(data: &[u8]) -> Result<Self, DeserializeError>
    where
        Self: Sized;
}

/// Deserialization error (P3 shape).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DeserializeError {
    pub reason: String,
}

// ---------------------------------------------------------------------------
// 5. Package management / dependency resolution interfaces (P2, 13 §3.3.8)
// ---------------------------------------------------------------------------

/// Package manifest (P3 shape: name + version + dependency description strings).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PackageManifest {
    pub name: String,
    pub version: String,
    pub dependencies: Vec<String>,
}

/// Dependency graph (P3 shape: topologically ordered package name list).
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct DependencyGraph {
    pub packages: Vec<String>,
}

/// Resolved package artifact (P3 shape: possibly precompiled).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PackageArtifact {
    pub name: String,
    pub version: String,
    /// Precompiled flag (branches the external-module consumption path).
    pub precompiled: bool,
}

/// Lock file (P3 shape: text-carried — same semantics as Cargo/Cargo.lock).
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct LockFile {
    pub content: String,
}

/// Dependency resolution error (P3 shape).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ResolveError {
    pub reason: String,
}

/// Package fetch failure (P3 shape).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FetchError {
    pub reason: String,
}

/// Module source (package name + path — the reserved placement where import paths denote
/// package dependencies).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ModuleSource {
    pub package: String,
    pub path: String,
}

/// Interface between the package manager and the compiler (P2 — basic package resolution at
/// Stage 1).
pub trait PackageManager: ToolchainDomain {
    /// Resolve the dependency graph.
    fn resolve_dependencies(
        &self,
        manifest: &PackageManifest,
    ) -> Result<DependencyGraph, ResolveError>;

    /// Fetch a package's compiled artifact.
    fn get_package(&self, name: &str, version: &str) -> Result<PackageArtifact, FetchError>;

    /// Lock dependency versions.
    fn lock(&self, graph: &DependencyGraph) -> LockFile;
}

/// External module (package-boundary reservation for the module system — P2).
pub trait ExternalModule: ToolchainDomain {
    /// The external module's source (package name + path).
    fn source(&self) -> ModuleSource;

    /// The external module's compiled artifact (possibly precompiled).
    fn compiled(&self) -> Option<BcProgram>;
}

// ---------------------------------------------------------------------------
// 6. AI-assisted programming interfaces (P2, 13 §3.3.9 — reuses LanguageService query
// infrastructure)
// ---------------------------------------------------------------------------

/// Semantic summary (for AI context understanding — P3 shape: structured text).
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct SemanticSummary {
    pub summary: String,
}

/// Function signature (for completion suggestions — P3 shape: input/output/effect
/// descriptions).
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct FunctionSignature {
    pub signature: String,
}

/// Quick type-check result (validation of AI-generated code — P3 shape).
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct TypeCheckResult {
    pub passed: bool,
    pub notes: Vec<String>,
}

/// Type-check failure (P3 shape).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct TypeError {
    pub reason: String,
}

/// Refactoring suggestion (AI-assisted refactoring — P3 shape).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Refactoring {
    pub description: String,
}

/// Semantic API for AI programming assistants (P2).
///
/// **Reserved contract**: reuses [`LanguageService`]'s query infrastructure (symbol table/type
/// table/diagnostic stream) — semantic summaries, signature queries, quick type checks,
/// refactoring suggestions, doc-comment generation.
pub trait AiAssistant: ToolchainDomain {
    /// Get a semantic summary of the code (for context understanding).
    fn semantic_summary(&self, file: FileId) -> SemanticSummary;

    /// Get a function's input/output types and effects (for completion suggestions).
    fn function_signature(&self, symbol: &Symbol) -> FunctionSignature;

    /// Verify whether AI-generated code is type-safe (quick check).
    fn quick_typecheck(&self, snippet: &str) -> Result<TypeCheckResult, TypeError>;

    /// Provide refactoring suggestions (AI-assisted refactoring).
    fn refactoring_suggestions(&self, selection: &Span) -> Vec<Refactoring>;

    /// Generate a doc comment for the code.
    fn generate_doc_comment(&self, item: &Symbol) -> String;
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::reserved::{ExtensionSpace, RootSpace, ToolchainDomain};

    /// P0–P2 freeze tests: all reserved traits prove their contracts frozen via "test
    /// implementations compile" (§27 interface stability; precedent:
    /// reserved_signatures_are_frozen).
    struct ProbeLangService;
    impl RootSpace for ProbeLangService {}
    impl ExtensionSpace for ProbeLangService {}
    impl ToolchainDomain for ProbeLangService {}
    impl LanguageService for ProbeLangService {
        fn syntax_tree_at(&self, _file: FileId, _pos: Position) -> Option<SyntaxNodeRef> {
            None
        }
        fn completion_items(&self, _file: FileId, _pos: Position) -> Vec<CompletionItem> {
            vec![]
        }
        fn document_symbols(&self, _file: FileId) -> Vec<Symbol> {
            vec![]
        }
        fn definition_of(&self, _file: FileId, _pos: Position) -> Option<Location> {
            None
        }
        fn references_to(&self, _file: FileId, _pos: Position) -> Vec<Location> {
            vec![]
        }
        fn type_at(&self, _file: FileId, _pos: Position) -> Option<TypeInfo> {
            None
        }
        fn diagnostics(&self, _file: FileId) -> Vec<Diagnostic> {
            vec![]
        }
        fn quick_fixes(&self, _file: FileId, _pos: Position) -> Vec<CodeAction> {
            vec![]
        }
        fn rename_symbol(
            &mut self,
            _file: FileId,
            _pos: Position,
            _new_name: String,
        ) -> Result<WorkspaceEdit, RenameError> {
            Err(RenameError {
                reason: "P0 reserved: rename Stage 2 implementation".into(),
            })
        }
    }

    struct ProbeIncrementalAst {
        version: u32,
    }
    impl RootSpace for ProbeIncrementalAst {}
    impl ExtensionSpace for ProbeIncrementalAst {}
    impl ToolchainDomain for ProbeIncrementalAst {}
    impl IncrementalAst for ProbeIncrementalAst {
        fn apply_edit(&mut self, _edit: &TextEdit) -> Result<(), EditError> {
            self.version += 1;
            Ok(())
        }
        fn invalidate_range(&mut self, _range: Span) {}
        fn reuse_unchanged(&self, _other: &Self) -> ReusePlan {
            ReusePlan::default()
        }
    }

    struct ProbeDebugGen;
    impl RootSpace for ProbeDebugGen {}
    impl ExtensionSpace for ProbeDebugGen {}
    impl ToolchainDomain for ProbeDebugGen {}
    impl DebugInfoGenerator for ProbeDebugGen {
        fn source_location_of(&self, _ir_node: NodeId) -> Option<Span> {
            None
        }
        fn ir_node_at(&self, _code_addr: Address) -> Option<NodeId> {
            None
        }
        fn variable_location(&self, _var: VarId, _at_pc: Address) -> Option<Location> {
            None
        }
        fn generate_dwarf(&self) -> DwarfSections {
            DwarfSections::default()
        }
        fn generate_source_map(&self) -> SourceMapBlob {
            SourceMapBlob::default()
        }
    }

    struct ProbeIrNode;
    impl RootSpace for ProbeIrNode {}
    impl ExtensionSpace for ProbeIrNode {}
    impl ToolchainDomain for ProbeIrNode {}
    impl DebugTraceable for ProbeIrNode {
        fn ast_node_id(&self) -> AstNodeId {
            AstNodeId(0)
        }
        fn debug_name(&self) -> Option<Symbol> {
            None
        }
    }

    struct ProbeQuerySystem {
        inputs_invalidated: u32,
    }
    impl RootSpace for ProbeQuerySystem {}
    impl ExtensionSpace for ProbeQuerySystem {}
    impl ToolchainDomain for ProbeQuerySystem {}
    impl QuerySystem for ProbeQuerySystem {
        type Input = u64;
        fn query(&self, _descriptor: &QueryDescriptor) -> QueryResult {
            QueryResult {
                output_fingerprint: 0,
                cached: false,
            }
        }
        fn invalidate(&mut self, _input: Self::Input) {
            self.inputs_invalidated += 1;
        }
        fn dependencies_of(&self, _descriptor: &QueryDescriptor) -> Vec<QueryDescriptor> {
            vec![]
        }
    }

    struct ProbePass;
    impl RootSpace for ProbePass {}
    impl ExtensionSpace for ProbePass {}
    impl ToolchainDomain for ProbePass {}
    impl Query for ProbePass {
        type Input = String;
        type Output = u64;
        fn dependencies(&self) -> Vec<QueryDescriptor> {
            vec![]
        }
        fn execute(&self, _db: &dyn QuerySystem<Input = String>) -> Self::Output {
            0
        }
    }

    struct ProbeService;
    impl RootSpace for ProbeService {}
    impl ExtensionSpace for ProbeService {}
    impl ToolchainDomain for ProbeService {}
    impl CompilerService for ProbeService {
        fn submit(&mut self, _request: CompileRequest) -> CompileJobId {
            CompileJobId(1)
        }
        fn status(&self, _job: CompileJobId) -> Option<CompileStatus> {
            Some(CompileStatus::Queued)
        }
        fn result(&self, _job: CompileJobId) -> Option<CompileResult> {
            None
        }
        fn diagnostics_stream(&self, _job: CompileJobId) -> Vec<Diagnostic> {
            vec![]
        }
        fn cancel(&mut self, _job: CompileJobId) {}
    }

    #[derive(Debug, Clone, PartialEq, Eq, Default)]
    struct ProbeState {
        n: u32,
    }
    impl RootSpace for ProbeState {}
    impl ExtensionSpace for ProbeState {}
    impl ToolchainDomain for ProbeState {}
    impl Serializable for ProbeState {
        fn serialize(&self) -> Vec<u8> {
            self.n.to_le_bytes().to_vec()
        }
        fn deserialize(data: &[u8]) -> Result<Self, DeserializeError> {
            let bytes: [u8; 4] = data.try_into().map_err(|_| DeserializeError {
                reason: "length".into(),
            })?;
            Ok(ProbeState {
                n: u32::from_le_bytes(bytes),
            })
        }
    }

    struct ProbePackageManager;
    impl RootSpace for ProbePackageManager {}
    impl ExtensionSpace for ProbePackageManager {}
    impl ToolchainDomain for ProbePackageManager {}
    impl PackageManager for ProbePackageManager {
        fn resolve_dependencies(
            &self,
            manifest: &PackageManifest,
        ) -> Result<DependencyGraph, ResolveError> {
            Ok(DependencyGraph {
                packages: vec![manifest.name.clone()],
            })
        }
        fn get_package(&self, name: &str, version: &str) -> Result<PackageArtifact, FetchError> {
            Ok(PackageArtifact {
                name: name.into(),
                version: version.into(),
                precompiled: false,
            })
        }
        fn lock(&self, _graph: &DependencyGraph) -> LockFile {
            LockFile::default()
        }
    }

    struct ProbeExternalModule;
    impl RootSpace for ProbeExternalModule {}
    impl ExtensionSpace for ProbeExternalModule {}
    impl ToolchainDomain for ProbeExternalModule {}
    impl ExternalModule for ProbeExternalModule {
        fn source(&self) -> ModuleSource {
            ModuleSource {
                package: "kerf".into(),
                path: "lib".into(),
            }
        }
        fn compiled(&self) -> Option<BcProgram> {
            None
        }
    }

    struct ProbeAi;
    impl RootSpace for ProbeAi {}
    impl ExtensionSpace for ProbeAi {}
    impl ToolchainDomain for ProbeAi {}
    impl AiAssistant for ProbeAi {
        fn semantic_summary(&self, _file: FileId) -> SemanticSummary {
            SemanticSummary::default()
        }
        fn function_signature(&self, _symbol: &Symbol) -> FunctionSignature {
            FunctionSignature::default()
        }
        fn quick_typecheck(&self, snippet: &str) -> Result<TypeCheckResult, TypeError> {
            if snippet.is_empty() {
                Err(TypeError {
                    reason: "empty fragment".into(),
                })
            } else {
                Ok(TypeCheckResult::default())
            }
        }
        fn refactoring_suggestions(&self, _selection: &Span) -> Vec<Refactoring> {
            vec![]
        }
        fn generate_doc_comment(&self, _item: &Symbol) -> String {
            String::new()
        }
    }

    #[test]
    fn toolchain_reserved_signatures_are_frozen() {
        // All toolchain reserved traits can be implemented against the frozen signatures
        // (compiles = contract frozen)
        let mut ls = ProbeLangService;
        assert!(ls
            .rename_symbol(0, Position { line: 1, column: 1 }, "x".into())
            .is_err());
        let mut ia = ProbeIncrementalAst { version: 0 };
        ia.apply_edit(&TextEdit {
            file: 0,
            span: Span::dummy(),
            new_text: String::new(),
        })
        .unwrap();
        assert_eq!(ia.version, 1);
        let dg = ProbeDebugGen;
        assert_eq!(dg.generate_dwarf(), DwarfSections::default());
        let ir = ProbeIrNode;
        assert_eq!(ir.ast_node_id(), AstNodeId(0));
        let mut qs = ProbeQuerySystem {
            inputs_invalidated: 0,
        };
        qs.invalidate(42u64);
        assert_eq!(qs.inputs_invalidated, 1);
        let pass = ProbePass;
        assert_eq!(pass.dependencies().len(), 0);
        let mut svc = ProbeService;
        assert_eq!(
            svc.submit(CompileRequest {
                source: String::new(),
                target: CompileTarget::Bytecode,
                opt_level: OptLevel::None,
                debug_info: DebugInfoRequest::Spans,
            }),
            CompileJobId(1)
        );
        assert_eq!(ProbeState::deserialize(&3u32.to_le_bytes()).unwrap().n, 3);
        let pm = ProbePackageManager;
        assert!(pm.get_package("kerf", "0.1.0").is_ok());
        let em = ProbeExternalModule;
        assert!(em.compiled().is_none());
        let ai = ProbeAi;
        assert!(ai.quick_typecheck("").is_err());
    }

    #[test]
    fn query_descriptor_is_hashable_and_fingerprinted() {
        // Content-addressing convention: descriptors with the same input fingerprint are equal
        // (dependency-graph node identity)
        let d1 = QueryDescriptor {
            name: "expand",
            input_fingerprint: 42,
        };
        let d2 = QueryDescriptor {
            name: "expand",
            input_fingerprint: 42,
        };
        assert_eq!(d1, d2);
        let d3 = QueryDescriptor {
            name: "expand",
            input_fingerprint: 43,
        };
        assert_ne!(d1, d3);
        let d4 = QueryDescriptor {
            name: "compile",
            input_fingerprint: 42,
        };
        assert_ne!(d1, d4);
    }

    #[test]
    fn compile_status_lifecycle_shape_is_total() {
        // All five service-lifecycle states are reachable (exhaustive enumeration = complete shape)
        let all = [
            CompileStatus::Queued,
            CompileStatus::Running,
            CompileStatus::Completed,
            CompileStatus::Failed,
            CompileStatus::Cancelled,
        ];
        assert_eq!(all.len(), 5);
        assert!(all.contains(&CompileStatus::Queued));
    }
}

//! Builtin function registration (stage0.md §9 stdlib: zero builtins in the
//! language core — all injected via the driver).
//!
//! Arithmetic (+ - * / mod) · comparison (= < > <= >=) · pairs (cons head
//! tail list) · predicates (is-nil is-pair is-int is-bool is-procedure eq) ·
//! logic (not) · I/O (print read-line) · strings (string-append).
//!
//! Numeric tower: Int×Int → Int (overflow-checked); any Float → Float.
//! Comparison: chained ((= a b c) all equal).
//!
//! Also contains the self-hosting Reader primitives (4, B3):
//! string-to-pos-chars / char-is-whitespace / char-is-alphabetic /
//! string-is-int — serving reader.krf (see the boundary notes at each
//! registration site; r50 / D63 naming settlement: v0.4 legacy `?`/`->`
//! forms retired — R2 predicate is- prefix + R4 conversion -to- forms
//! [22 §18.1; user free surface unchanged — `?`/`->` remain legal
//! identifier characters]; domain-partition architecture (eight domains,
//! four elements / side-effect convergence — the basis for "gated table =
//! full I/O domain set") see docs/lang-design/21-capability-architecture.md
//! §3; naming mechanism (five layers N0-N4 / resolution / permission matrix
//! — input for the v0.6 batch M implementation) see
//! docs/lang-design/22-namespace-design.md).
//!
//! **Batch L (v0.5 alias layer, r38)**: `BUILTIN_ALIASES` dual registration
//! of 27 modern flat names (registration face 57→84 — the 20 §6.4 ①/§8
//! mapping table implemented single-source); aliases share the same
//! dispatch body as their old names (same behavior, same diagnostics —
//! natural parity, 20 §9.3); the six gated I/O names gain zero new names
//! (zero change to the gated table — 20 §6.4 ③).
//!
//! **Batch M first item M1 (v0.6 namespace layer, r39)**:
//! `STDLIB_MODULES` registration of the seven-module export face (N2
//! qualified-name visibility face — `ns/local-name` form, 47 qualified
//! names + 5 r138 vector rows = 52, 20 §5.2 single-source translation); io module qualified names
//! registered fail-closed against the authorization face (22 §5.1 matrix's
//! sole alignment point); E0014 not-exported / E0015 reserved domain
//! carried by the driver's compile-time verification
//! (verify_qualified_refs — 22 §3.3 R-N3 no fallback); qualified-name
//! signatures derived by underlying name in `builtin_sigs` (same dispatch
//! → same static check face).

use std::cell::RefCell;
use std::collections::HashMap;
use std::rc::Rc;

use kerf_compiler::{BcProgram, BuiltinSig, TcParam, TcType};
use kerf_runtime::{BoxedInput, GcRef, Heap, RuntimeError};
use kerf_syntax::{Symbol, SymbolTable};
use kerf_vm::{box_value, render_value, structural_eq, unbox_slot, BuiltinFn, Value};

use crate::capability::{IoGrant, StdCapabilityIO};
use crate::reserved::{CapabilityIO, ReadCapability, WriteCapability};

/// Register all builtin functions into the global environment (returns the global table).
pub fn register_globals(table: &mut SymbolTable, grant: &IoGrant) -> HashMap<Symbol, Value> {
    let mut defs: Vec<(&'static str, Rc<BuiltinFn>)> = Vec::new();
    defs.push(("+", arith_builtin("+", Fold::Add, 0)));
    defs.push(("-", arith_builtin("-", Fold::Sub, 1)));
    defs.push(("*", arith_builtin("*", Fold::Mul, 0)));
    defs.push(("/", arith_builtin("/", Fold::Div, 2)));
    defs.push(("mod", arith_builtin("mod", Fold::Mod, 2)));
    // r159 / 229-c (operator-surface parity): `%` is the EBNF Level 0
    // primary face for modulo (term-level infix — 02 §8.13 precedence
    // table); `mod` stays registered as the legacy alias (seed-corpus
    // call form — zero bootstrap churn, one-concept dual-name with the
    // r102 naming lineage).
    defs.push(("%", arith_builtin("%", Fold::Mod, 2)));
    defs.push(("=", cmp_builtin("=", Cmp::Eq)));
    defs.push(("<", cmp_builtin("<", Cmp::Lt)));
    defs.push((">", cmp_builtin(">", Cmp::Gt)));
    defs.push(("<=", cmp_builtin("<=", Cmp::Le)));
    defs.push((">=", cmp_builtin(">=", Cmp::Ge)));
    defs.push((
        "cons",
        BuiltinFn::new("cons", |heap, args| {
            two_args("cons", &args)?;
            let head = box_value(&args[0], heap);
            let tail = box_value(&args[1], heap);
            Ok(Value::Pair(heap.alloc_pair(head, tail)))
        }),
    ));
    defs.push((
        "head",
        BuiltinFn::new("head", |heap, args| {
            one_arg("head", &args)?;
            match &args[0] {
                Value::Pair(r) => match heap.get_pair(*r) {
                    Some((head, _)) => Ok(unbox_slot(head, heap)),
                    None => Err(RuntimeError::new("head applied to a non-pair heap slot")),
                },
                other => Err(RuntimeError::new(kerf_vm::err_pair_op(
                    "head",
                    other.type_name(),
                ))),
            }
        }),
    ));
    defs.push((
        "tail",
        BuiltinFn::new("tail", |heap, args| {
            one_arg("tail", &args)?;
            match &args[0] {
                Value::Pair(r) => match heap.get_pair(*r) {
                    Some((_, tail)) => Ok(unbox_slot(tail, heap)),
                    None => Err(RuntimeError::new("tail applied to a non-pair heap slot")),
                },
                other => Err(RuntimeError::new(kerf_vm::err_pair_op(
                    "tail",
                    other.type_name(),
                ))),
            }
        }),
    ));
    defs.push((
        "list",
        BuiltinFn::new("list", |heap, args| {
            // Right-fold construction; zero args → nil value form (same as '() — the empty list is nil)
            if args.is_empty() {
                return Ok(Value::Nil);
            }
            let mut acc = heap.alloc_boxed(BoxedInput::Nil);
            for a in args.iter().rev() {
                let elem = box_value(a, heap);
                acc = heap.alloc_pair(elem, acc);
            }
            Ok(Value::Pair(acc))
        }),
    ));
    defs.push((
        // r138 / 208-c — TD-002 (vector-value-design.md D4): the vector
        // constructor — per-element boxing (the `list` discipline) + one
        // vector slot; zero args → the empty vector (a heap value, NOT nil —
        // the empty list is nil but the empty vector is a distinct value).
        // The desugar target of `#(a b c)` literals (D2-a) and quote-vector
        // chains (D2-b).
        "vector",
        BuiltinFn::new("vector", |heap, args| {
            let items: Vec<_> = args.iter().map(|a| box_value(a, heap)).collect();
            Ok(Value::Vector(heap.alloc_vector(items)))
        }),
    ));
    defs.push((
        // r138 / 208-c — TD-002: element count (0-based domain; non-vector
        // args fail closed via the single-sourced message constructor).
        "vector-length",
        BuiltinFn::new("vector-length", |heap, args| {
            one_arg("vector-length", &args)?;
            match &args[0] {
                Value::Vector(r) => Ok(Value::Int(
                    heap.get_vector(*r).map(|v| v.len()).unwrap_or(0) as i64,
                )),
                other => Err(RuntimeError::new(kerf_vm::err_vector_op(
                    "vector-length",
                    other.type_name(),
                ))),
            }
        }),
    ));
    defs.push((
        // r138 / 208-c — TD-002: 0-based indexed access. Three fail-closed
        // faces: non-vector first arg / non-int index / out-of-bounds
        // (negative or >= len) — the latter two with dedicated messages
        // (index arithmetic is a distinct error family from domain errors).
        "vector-ref",
        BuiltinFn::new("vector-ref", |heap, args| {
            two_args("vector-ref", &args)?;
            let r = match &args[0] {
                Value::Vector(r) => *r,
                other => {
                    return Err(RuntimeError::new(kerf_vm::err_vector_op(
                        "vector-ref",
                        other.type_name(),
                    )))
                }
            };
            let idx = match &args[1] {
                Value::Int(i) => *i,
                other => {
                    return Err(RuntimeError::new(format!(
                        "vector-ref index requires int, got {}",
                        other.type_name()
                    )))
                }
            };
            let elems = heap.get_vector(r).ok_or_else(|| {
                RuntimeError::new("vector-ref should used for non-vector heap slot".to_string())
            })?;
            if idx < 0 || idx as usize >= elems.len() {
                return Err(RuntimeError::new(format!(
                    "vector-ref index out of bounds:{}(length {})",
                    idx,
                    elems.len()
                )));
            }
            Ok(unbox_slot(elems[idx as usize], heap))
        }),
    ));
    defs.push((
        // r138 / 208-c — TD-002: concatenation producing a NEW vector (D1
        // immutability — the operands are never mutated; shared element
        // slots are re-referenced, not copied).
        "vector-append",
        BuiltinFn::new("vector-append", |heap, args| {
            let mut items: Vec<_> = Vec::new();
            for a in args.iter() {
                match a {
                    Value::Vector(r) => {
                        if let Some(elems) = heap.get_vector(*r) {
                            items.extend_from_slice(elems);
                        }
                    }
                    other => {
                        return Err(RuntimeError::new(kerf_vm::err_vector_op(
                            "vector-append",
                            other.type_name(),
                        )))
                    }
                }
            }
            Ok(Value::Vector(heap.alloc_vector(items)))
        }),
    ));
    defs.push((
        // r138 / 208-c — TD-002: predicate (the is- family convention).
        "is-vector",
        BuiltinFn::new("is-vector", |_, args| {
            one_arg("is-vector", &args)?;
            Ok(Value::Bool(matches!(args[0], Value::Vector(_))))
        }),
    ));
    defs.push((
        "is-nil",
        BuiltinFn::new("is-nil", |_, args| {
            one_arg("is-nil", &args)?;
            Ok(Value::Bool(matches!(args[0], Value::Nil)))
        }),
    ));
    defs.push((
        "is-pair",
        BuiltinFn::new("is-pair", |_, args| {
            one_arg("is-pair", &args)?;
            Ok(Value::Bool(matches!(args[0], Value::Pair(_))))
        }),
    ));
    defs.push((
        "is-int",
        BuiltinFn::new("is-int", |_, args| {
            one_arg("is-int", &args)?;
            Ok(Value::Bool(matches!(args[0], Value::Int(_))))
        }),
    ));
    defs.push((
        "is-bool",
        BuiltinFn::new("is-bool", |_, args| {
            one_arg("is-bool", &args)?;
            Ok(Value::Bool(matches!(args[0], Value::Bool(_))))
        }),
    ));
    defs.push((
        "is-procedure",
        BuiltinFn::new("is-procedure", |_, args| {
            one_arg("is-procedure", &args)?;
            Ok(Value::Bool(matches!(
                args[0],
                Value::Closure(_) | Value::Builtin(_)
            )))
        }),
    ));
    // ---- Complete type-predicate face (r24 / 42-e stdlib gap closure: Value variant discrimination) ----
    defs.push((
        "is-string",
        BuiltinFn::new("is-string", |_, args| {
            one_arg("is-string", &args)?;
            Ok(Value::Bool(matches!(args[0], Value::Str(_))))
        }),
    ));
    defs.push((
        "is-symbol",
        BuiltinFn::new("is-symbol", |_, args| {
            one_arg("is-symbol", &args)?;
            Ok(Value::Bool(matches!(args[0], Value::Symbol(_))))
        }),
    ));
    defs.push((
        "is-float",
        BuiltinFn::new("is-float", |_, args| {
            one_arg("is-float", &args)?;
            Ok(Value::Bool(matches!(args[0], Value::Float(_))))
        }),
    ));
    defs.push((
        "is-number",
        BuiltinFn::new("is-number", |_, args| {
            one_arg("is-number", &args)?;
            // Numeric tower predicate: Int or Float (same domain as arithmetic operands)
            Ok(Value::Bool(matches!(
                args[0],
                Value::Int(_) | Value::Float(_)
            )))
        }),
    ));
    defs.push((
        "is-list",
        BuiltinFn::new("is-list", |heap, args| {
            one_arg("is-list", &args)?;
            // Proper-list check: nil, or a pair chain whose tail chain ends in
            // nil. Floyd tortoise-and-hare cycle detection (cycle → false:
            // a proper list's tail chain is acyclic; cf. Racket is-list semantics).
            match &args[0] {
                Value::Nil => Ok(Value::Bool(true)),
                Value::Pair(start) => {
                    let mut slow = *start;
                    let mut fast = *start;
                    loop {
                        // fast advances two steps / slow one step — each step adjudicated by slot kind
                        for _ in 0..2 {
                            match list_step(heap, fast) {
                                ListStep::End(is_list_end) => return Ok(Value::Bool(is_list_end)),
                                ListStep::Next(r) => fast = r,
                            }
                        }
                        match list_step(heap, slow) {
                            ListStep::End(is_list_end) => return Ok(Value::Bool(is_list_end)),
                            ListStep::Next(r) => slow = r,
                        }
                        if slow == fast {
                            return Ok(Value::Bool(false));
                        }
                    }
                }
                _ => Ok(Value::Bool(false)),
            }
        }),
    ));
    defs.push((
        "eq",
        BuiltinFn::new("eq", |heap, args| {
            two_args("eq", &args)?;
            // r162 / 233 — TD-037: the structural law (D3/D4 — pairs and
            // vectors by recursive value equality; procedural identity)
            Ok(Value::Bool(structural_eq(&args[0], &args[1], heap)))
        }),
    ));
    defs.push((
        "not",
        BuiltinFn::new("not", |_, args| {
            one_arg("not", &args)?;
            match &args[0] {
                Value::Bool(b) => Ok(Value::Bool(!b)),
                other => Err(RuntimeError::new(kerf_vm::err_not_bool(other.type_name()))),
            }
        }),
    ));
    // print / read-line capability-parameterized registration (r8 —
    // 13 §3.1.3 clause 4): moved to register_io_globals, registered in
    // IoGrant token-capture form (unauthorized → not registered —
    // fail-closed: no reachable entry for I/O without a token)
    register_io_globals(&mut defs, grant);
    defs.push((
        "string-append",
        BuiltinFn::new("string-append", |_, args| {
            if args.len() != 2 {
                return Err(RuntimeError::new("string-append requires 2 arguments"));
            }
            match (&args[0], &args[1]) {
                (Value::Str(a), Value::Str(b)) => {
                    Ok(Value::Str(Rc::from(format!("{}{}", a, b).as_str())))
                }
                _ => Err(RuntimeError::new("string-append requires 2 strings")),
            }
        }),
    ));

    // ------------------------------------------------------------------
    // Standard library minimal-set extension (r5, batch B — 07 §3.3 stage
    // gate criterion 3: list ops / string handling / basic I/O, ≥8
    // functions each)
    // ------------------------------------------------------------------

    // —— List operations (2 — r164 / 235-c: the seven fixed-arity faces
    // migrated to the self-built kerf source bootstrap/list.ktf [list-
    // self-built-design.md D1]; `list` (N1 variadic constructor) and
    // `append` stay Rust) ——
    // r165 / 236-d: the variadic LANGUAGE FACE landed (rest parameters —
    // variadic-rest-design.md D1-D6; TD-038 cleared) and the kerf append
    // implementation is PROVEN (E2E + byte-level error parity — the
    // ktf_variadic_rest_tests door); this registration stays because the
    // seed corpora consume `append` on their own hot paths (reader.ktf ×6 +
    // expander.ktf ×5 — the r164 member/assoc performance-boundary class)
    // and the injected define face cannot coexist with the registered
    // global (the reader's import pre-declare rejects the redefinition —
    // probe-verified r165). Full retirement = TD-041 (native-AOT recovery
    // + the corpus splice migration, trigger-gated).
    defs.push((
        "append",
        BuiltinFn::new("append", |heap, args| {
            // Variadic: 0 args → nil; last arg returned as-is (improper allowed); leading args must be lists
            if args.is_empty() {
                return Ok(Value::Nil);
            }
            let last = args[args.len() - 1].clone();
            if args.len() == 1 {
                return Ok(last);
            }
            // Collect the elements of the first n-1 chains (flattened into a vector — each arg must be nil-terminated)
            let mut elems: Vec<Value> = Vec::new();
            for (i, a) in args[..args.len() - 1].iter().enumerate() {
                let mut cur = a.clone();
                loop {
                    match cur {
                        Value::Nil => break,
                        Value::Pair(r) => match heap.get_pair(r) {
                            Some((head, tail)) => {
                                elems.push(unbox_slot(head, heap));
                                cur = unbox_slot(tail, heap);
                            }
                            None => {
                                return Err(RuntimeError::new(
                                    "append applied to a non-pair heap slot",
                                ));
                            }
                        },
                        other => {
                            return Err(RuntimeError::new(format!(
                                "append # {} requires list, got {}",
                                i + 1,
                                other.type_name()
                            )))
                        }
                    }
                }
            }
            // r101 / 171-c defect fix: all-leading-args-empty → last arg
            // returned **as-is** (nil → nil; atom → atom — canonical
            // improper-tail semantics; pair chain → the chain itself
            // [shared]). The old implementation always built
            // `Pair(box_value(&last))`: with a nil last arg it produced a
            // pseudo-pair pointing at a box (head/tail traversal then
            // crashed with "non-pair heap slot" — the mandatory path for
            // splicing empty-sequence sublists in macro templates
            // `(a ...)` [a = ∅], first exposed by derived-keyword macroization
            // [derived let* empty-rest splicing]; a pre-existing defect —
            // class-A foundation, non-duplicate and actionable, r74
            // precedent basis); with an atom last arg it produced a
            // one-element (atom) list instead of an improper tail — both
            // shapes now judged alike, settling the debt).
            if elems.is_empty() {
                return Ok(last);
            }
            // Right-fold rebuild (fresh chain — does not share the leading args' structure; the last arg's tail is shared)
            let mut acc = box_value(&last, heap);
            for e in elems.iter().rev() {
                let elem = box_value(e, heap);
                acc = heap.alloc_pair(elem, acc);
            }
            Ok(Value::Pair(acc))
        }),
    ));
    // r164 / 235-c performance-boundary ruling (list-self-built-design.md
    // §0.1 PoC + the expander-corpus check wall): assoc/member stay
    // Rust-registered — the check-HM segment's lookup consumption
    // (signature-table/environment queries — depth-sensitive, 10^5-call
    // scale) exceeds the VM interpreter's transitional instruction budget
    // (the 10^9 TCO guardrail tripped at 37s). Their kerf-source
    // implementations are PROVEN (E2E + byte-level error parity, this
    // window) — the migration re-opens trigger-gated once the native-AOT
    // performance-recovery path lands (TD-038-adjacent, stage-2 domain).
    defs.push((
        "member",
        BuiltinFn::new("member", |heap, args| {
            two_args("member", &args)?;
            // Element-wise lookup by eq; hit returns the sub-list, miss returns false
            let mut cur = args[1].clone();
            loop {
                match cur {
                    Value::Nil => return Ok(Value::Bool(false)),
                    Value::Pair(r) => match heap.get_pair(r) {
                        Some((head, tail)) => {
                            let elem = unbox_slot(head, heap);
                            if structural_eq(&elem, &args[0], heap) {
                                return Ok(Value::Pair(r));
                            }
                            cur = unbox_slot(tail, heap);
                        }
                        None => {
                            return Err(RuntimeError::new(
                                "member applied to a non-pair heap slot",
                            ));
                        }
                    },
                    other => {
                        return Err(RuntimeError::new(format!(
                            "member second argument requires list, got {}",
                            other.type_name()
                        )))
                    }
                }
            }
        }),
    ));
    defs.push((
        "assoc",
        BuiltinFn::new("assoc", |heap, args| {
            two_args("assoc", &args)?;
            // Association-list lookup by key eq; hit returns that entry (key-value pair), miss returns false
            let mut cur = args[1].clone();
            loop {
                match cur {
                    Value::Nil => return Ok(Value::Bool(false)),
                    Value::Pair(r) => match heap.get_pair(r) {
                        Some((entry, tail)) => {
                            let entry_v = unbox_slot(entry, heap);
                            match entry_v {
                                Value::Pair(ep) => match heap.get_pair(ep) {
                                    Some((key, _)) => {
                                        let key_v = unbox_slot(key, heap);
                                        if structural_eq(&key_v, &args[0], heap) {
                                            return Ok(Value::Pair(ep));
                                        }
                                        cur = unbox_slot(tail, heap);
                                    }
                                    None => return Err(RuntimeError::new(
                                        "assoc table item should applied to a non-pair heap slot",
                                    )),
                                },
                                other => {
                                    return Err(RuntimeError::new(format!(
                                        "assoc table item requires pair, got {}",
                                        other.type_name()
                                    )))
                                }
                            }
                        }
                        None => {
                            return Err(RuntimeError::new("assoc applied to a non-pair heap slot"));
                        }
                    },
                    other => {
                        return Err(RuntimeError::new(format!(
                            "assoc second argument requires list, got {}",
                            other.type_name()
                        )))
                    }
                }
            }
        }),
    ));

    // —— String handling (10, including TD-002 linked conversions) ——
    defs.push((
        "string-length",
        BuiltinFn::new("string-length", |_, args| {
            one_arg("string-length", &args)?;
            match &args[0] {
                Value::Str(s) => Ok(Value::Int(s.chars().count() as i64)),
                other => Err(RuntimeError::new(format!(
                    "string-length requires str, got {}",
                    other.type_name()
                ))),
            }
        }),
    ));
    defs.push((
        "string-substring",
        BuiltinFn::new("string-substring", |_, args| {
            if args.len() != 3 {
                return Err(RuntimeError::new("string-substring requires 3 arguments"));
            }
            let s = match &args[0] {
                Value::Str(s) => s.clone(),
                other => {
                    return Err(RuntimeError::new(format!(
                        "string-substring requires str, got {}",
                        other.type_name()
                    )))
                }
            };
            let (start, end) = match (&args[1], &args[2]) {
                (Value::Int(a), Value::Int(b)) => (*a, *b),
                (a, _) => {
                    return Err(RuntimeError::new(format!(
                        "string-substring index requires int, got {}",
                        a.type_name()
                    )))
                }
            };
            let len = s.chars().count() as i64;
            if start < 0 || end < start || end > len {
                return Err(RuntimeError::new(format!(
                    "string-substring index out of bounds:{}..{}(length {})",
                    start, end, len
                )));
            }
            let out: String = s
                .chars()
                .skip(start as usize)
                .take((end - start) as usize)
                .collect();
            Ok(Value::Str(Rc::from(out.as_str())))
        }),
    ));
    defs.push((
        "string-index-of",
        BuiltinFn::new("string-index-of", |_, args| {
            two_args("string-index-of", &args)?;
            match (&args[0], &args[1]) {
                (Value::Str(s), Value::Str(sub)) => {
                    // Character index (Unicode-safe: byte search first, then convert to character position)
                    let idx = s
                        .find(sub.as_ref())
                        .map(|b| s[..b].chars().count() as i64)
                        .unwrap_or(-1);
                    Ok(Value::Int(idx))
                }
                (a, b) => Err(RuntimeError::new(format!(
                    "string-index-of both operands require str, got {} and {}",
                    a.type_name(),
                    b.type_name()
                ))),
            }
        }),
    ));
    defs.push((
        "string-contains",
        BuiltinFn::new("string-contains", |_, args| {
            two_args("string-contains", &args)?;
            match (&args[0], &args[1]) {
                (Value::Str(s), Value::Str(sub)) => Ok(Value::Bool(s.contains(sub.as_ref()))),
                (a, b) => Err(RuntimeError::new(format!(
                    "string-contains both operands require str, got {} and {}",
                    a.type_name(),
                    b.type_name()
                ))),
            }
        }),
    ));
    defs.push((
        "string-starts-with",
        BuiltinFn::new("string-starts-with", |_, args| {
            two_args("string-starts-with", &args)?;
            match (&args[0], &args[1]) {
                (Value::Str(s), Value::Str(pre)) => Ok(Value::Bool(s.starts_with(pre.as_ref()))),
                (a, b) => Err(RuntimeError::new(format!(
                    "string-starts-with both operands require str, got {} and {}",
                    a.type_name(),
                    b.type_name()
                ))),
            }
        }),
    ));
    defs.push((
        "string-ends-with",
        BuiltinFn::new("string-ends-with", |_, args| {
            two_args("string-ends-with", &args)?;
            match (&args[0], &args[1]) {
                (Value::Str(s), Value::Str(suf)) => Ok(Value::Bool(s.ends_with(suf.as_ref()))),
                (a, b) => Err(RuntimeError::new(format!(
                    "string-ends-with both operands require str, got {} and {}",
                    a.type_name(),
                    b.type_name()
                ))),
            }
        }),
    ));
    defs.push((
        "string-to-upper",
        BuiltinFn::new("string-to-upper", |_, args| {
            one_arg("string-to-upper", &args)?;
            match &args[0] {
                Value::Str(s) => {
                    let out: String = s.chars().flat_map(char::to_uppercase).collect();
                    Ok(Value::Str(Rc::from(out.as_str())))
                }
                other => Err(RuntimeError::new(format!(
                    "string-to-upper requires str, got {}",
                    other.type_name()
                ))),
            }
        }),
    ));
    defs.push((
        "string-to-lower",
        BuiltinFn::new("string-to-lower", |_, args| {
            one_arg("string-to-lower", &args)?;
            match &args[0] {
                Value::Str(s) => {
                    let out: String = s.chars().flat_map(char::to_lowercase).collect();
                    Ok(Value::Str(Rc::from(out.as_str())))
                }
                other => Err(RuntimeError::new(format!(
                    "string-to-lower requires str, got {}",
                    other.type_name()
                ))),
            }
        }),
    ));
    defs.push((
        "string-to-symbol",
        BuiltinFn::new("string-to-symbol", |_, args| {
            one_arg("string-to-symbol", &args)?;
            match &args[0] {
                Value::Str(s) => Ok(Value::Symbol(s.clone())),
                other => Err(RuntimeError::new(format!(
                    "string-to-symbol requires str, got {}",
                    other.type_name()
                ))),
            }
        }),
    ));
    defs.push((
        "symbol-to-string",
        BuiltinFn::new("symbol-to-string", |_, args| {
            one_arg("symbol-to-string", &args)?;
            match &args[0] {
                Value::Symbol(s) => Ok(Value::Str(s.clone())),
                other => Err(RuntimeError::new(format!(
                    "symbol-to-string requires symbol, got {}",
                    other.type_name()
                ))),
            }
        }),
    ));

    // —— Self-hosting Reader primitives (4, B3: the runtime service layer
    // for the kerf rewrite of the Reader) ——
    // Boundary (§8.4.6 two-tier semantics + §11): lexing/parsing logic
    // lives in reader.krf (kerf source, running on the VM); character-level
    // indexing and Unicode property checks are runtime primitives (same
    // layer as Racket's string-ref/char-is-whitespace) — not part of the
    // language-level builtin semantic face.
    defs.push((
        "string-to-pos-chars",
        BuiltinFn::new("string-to-pos-chars", |heap, args| {
            one_arg("string-to-pos-chars", &args)?;
            match &args[0] {
                Value::Str(s) => {
                    // Source text → ((byte-offset . single-char str) ...)
                    // list: UTF-8 lengths are derivable from adjacent
                    // byte-offset differences (the last char uses the source
                    // byte length)
                    let mut acc = heap.alloc_boxed(BoxedInput::Nil);
                    let pairs: Vec<(usize, char)> = s.char_indices().collect();
                    for (off, ch) in pairs.iter().rev() {
                        let mut buf = [0u8; 4];
                        let ch_str = Value::Str(Rc::from(ch.encode_utf8(&mut buf)));
                        let off_val = Value::Int(*off as i64);
                        let head = box_value(&off_val, heap);
                        let tail = box_value(&ch_str, heap);
                        let elem = heap.alloc_pair(head, tail);
                        acc = heap.alloc_pair(elem, acc);
                    }
                    if s.is_empty() {
                        Ok(Value::Nil)
                    } else {
                        Ok(Value::Pair(acc))
                    }
                }
                other => Err(RuntimeError::new(format!(
                    "string-to-pos-chars requires str, got {}",
                    other.type_name()
                ))),
            }
        }),
    ));
    defs.push((
        "char-is-whitespace",
        BuiltinFn::new("char-is-whitespace", |_, args| {
            one_arg("char-is-whitespace", &args)?;
            match &args[0] {
                Value::Str(s) => {
                    let mut it = s.chars();
                    let (first, len_ok) = (it.next(), it.next().is_none());
                    match first {
                        Some(c) if len_ok => Ok(Value::Bool(c.is_whitespace())),
                        _ => Err(RuntimeError::new(
                            "char-is-whitespace requires 1 character str, got multiple characters",
                        )),
                    }
                }
                other => Err(RuntimeError::new(format!(
                    "char-is-whitespace requires str, got {}",
                    other.type_name()
                ))),
            }
        }),
    ));
    defs.push((
        "char-is-alphabetic",
        BuiltinFn::new("char-is-alphabetic", |_, args| {
            one_arg("char-is-alphabetic", &args)?;
            match &args[0] {
                Value::Str(s) => {
                    let mut it = s.chars();
                    let (first, len_ok) = (it.next(), it.next().is_none());
                    match first {
                        Some(c) if len_ok => Ok(Value::Bool(c.is_alphabetic())),
                        _ => Err(RuntimeError::new(
                            "char-is-alphabetic requires 1 character str, got multiple characters",
                        )),
                    }
                }
                other => Err(RuntimeError::new(format!(
                    "char-is-alphabetic requires str, got {}",
                    other.type_name()
                ))),
            }
        }),
    ));
    defs.push((
        "string-is-int",
        BuiltinFn::new("string-is-int", |_, args| {
            one_arg("string-is-int", &args)?;
            match &args[0] {
                // i64 domain check = Rust parse semantics verbatim (host
                // type boundary — error messages and byte-level behavior
                // guaranteed by the same-source parse on the bridge side;
                // the kerf side only does scan-order pre-validation to
                // preserve error-order parity)
                Value::Str(s) => Ok(Value::Bool(s.parse::<i64>().is_ok())),
                other => Err(RuntimeError::new(format!(
                    "string-is-int requires str, got {}",
                    other.type_name()
                ))),
            }
        }),
    ));

    // —— Basic I/O (all 6 capability-gated items moved to register_io_globals — r8) ——
    defs.push((
        "error",
        BuiltinFn::new("error", |_, args| {
            if args.is_empty() {
                return Err(RuntimeError::new(
                    "error requires ≥1 arguments(error message)",
                ));
            }
            let mut parts: Vec<String> = Vec::new();
            for a in args {
                // Message parts: str verbatim, others in rendered form (symbol name/number)
                match a {
                    Value::Str(s) => parts.push(s.to_string()),
                    other => parts.push(other.type_name().to_string()),
                }
            }
            Err(RuntimeError::new(parts.join(" ")))
        }),
    ));
    defs.push((
        "assert-eq",
        BuiltinFn::new("assert-eq", |heap, args| {
            two_args("assert-eq", &args)?;
            // r162 / 233 — TD-037: assert-eq inherits the structural law
            // (one equality law user-wide — D4 consumer set)
            if structural_eq(&args[0], &args[1], heap) {
                Ok(Value::Bool(true))
            } else {
                Err(RuntimeError::new(format!(
                    "assert-eq assertion failed: {} ≠ {}",
                    render_value(&args[0], heap),
                    render_value(&args[1], heap)
                )))
            }
        }),
    ));

    // ------------------------------------------------------------------
    // r42 / 63-b removal round S1 surface leg (v0.9) — 27 old names
    // retired: the batch L alias dual-registration mechanism goes offline
    // (20 §7 removal-round line honored; registration face 84→57 flat).
    // Old-name references → E0021 compile-time error (single-source
    // adjudication via REMOVED_BUILTIN_NAMES inside driver
    // `verify_qualified_refs` — diagnostics carry modern-name guidance);
    // deprecation-window lifecycle check (23 §3.4: W1001 landed in v0.7 →
    // v0.8 one stable release all-green → v0.9 removal, spanning two
    // versions).
    // ------------------------------------------------------------------

    let mut globals = HashMap::new();
    for (name, f) in defs {
        let sym = table.intern(name);
        globals.insert(sym, Value::Builtin(f));
    }
    // ------------------------------------------------------------------
    // Batch M first item M1 (v0.6 namespace layer, r39) — N2 qualified-name
    // visibility face: eight-module export face (52 qualified names — 47 + vector 5, r138
    // `ns/local-name` → shared underlying dispatch body).
    // Mechanism = 22 §2.1 N2 "qualified-name visibility face" + §3.3 R-N3
    // (no fallback: resolution consults only the export face — the E0014
    // diagnostic is carried at compile time by driver
    // verify_qualified_refs). io module fail-closed: registered per
    // authorization item (22 §5.1 matrix's sole alignment point "gated
    // full set ≡ exported full set" + red line 3 default deny).
    // ------------------------------------------------------------------
    for &(ns, local, underlying) in STDLIB_MODULES {
        if ns == "io" {
            // io qualified names: registered only when the corresponding
            // authorization item is present (fail-closed — unauthorized
            // qualified names are absent from the roster; compile-time
            // E0006 is blocked earlier by R9 normalization)
            let need_read = crate::capability::READ_GATED.contains(&underlying);
            let need_write = crate::capability::WRITE_GATED.contains(&underlying);
            let authorized = if need_read {
                grant.read_handle().is_some()
            } else if need_write {
                grant.write_handle().is_some()
            } else {
                true
            };
            if !authorized {
                continue;
            }
        }
        // r164 / 235-c: the seven self-built list faces carry export-face-only
        // rows (E0014/E0024 query faces) — their runtime bindings are the
        // injected module-body defines (bootstrap/list.ktf), so the qualified
        // registration pass skips them (no Rust BuiltinFn to alias).
        if SELF_BUILT_LIST_NAMES.contains(&underlying) {
            continue;
        }
        let u = table.intern(underlying);
        let f = match globals.get(&u) {
            Some(Value::Builtin(f)) => Rc::clone(f),
            _ => panic!(
                "qualified name underlying builtin not registered: {}/{} → {}",
                ns, local, underlying
            ),
        };
        let qualified = format!("{}/{}", ns, local);
        // --------------------------------------------------------------
        // Batch M second item M2 (v0.6, r40) — B1/B2 behavioral contract
        // modernization (20 §4): qualified names take the **modern
        // contract** (miss→nil) — a separate dispatch body not shared with
        // the underlying ("new name new contract, old name old contract
        // coexist until removal" — the 20 §4 migration invariant; old
        // names / flat new names keep the old contract, the r38 parity
        // anchor untouched). B3 (io/read-line strictly 0 args) is already
        // aligned at the underlying level (FS-4 fix surface — the R4
        // correction of the 20 §4 B3-row field-test note: purely a test
        // anchor, zero code change).
        // --------------------------------------------------------------
        let contracted: Option<Rc<BuiltinFn>> = match (ns, local) {
            // B1: string/index-of not-found -1 → nil (nil-as-absence —
            // same shape as the read-int EOF→nil precedent; sentinel
            // values are error-code-era legacy)
            ("string", "index-of") => {
                let inner = Rc::clone(&f);
                Some(BuiltinFn::new(
                    "string/index-of",
                    move |heap, args| match inner.call(heap, args) {
                        Ok(Value::Int(-1)) => Ok(Value::Nil),
                        other => other,
                    },
                ))
            }
            // B2: list/member and list/assoc miss false → nil (return type
            // unified: list-or-nil, no longer overlapping bool — in step
            // with purifying the HM type domain)
            ("list", "member") => {
                let inner = Rc::clone(&f);
                Some(BuiltinFn::new(
                    "list/member",
                    move |heap, args| match inner.call(heap, args) {
                        Ok(Value::Bool(false)) => Ok(Value::Nil),
                        other => other,
                    },
                ))
            }
            ("list", "assoc") => {
                let inner = Rc::clone(&f);
                Some(BuiltinFn::new(
                    "list/assoc",
                    move |heap, args| match inner.call(heap, args) {
                        Ok(Value::Bool(false)) => Ok(Value::Nil),
                        other => other,
                    },
                ))
            }
            _ => None,
        };
        let value = match contracted {
            Some(f2) => Value::Builtin(f2),
            None => Value::Builtin(f),
        };
        globals.insert(table.intern(&qualified), value);
    }
    globals
}

/// r42 / 63-b removal round S1 (v0.9): retired old-name table (27 entries
/// — direction = (old name, modern name)).
///
/// Single source = docs/lang-design/20-surface-conventions.md §8 (57-entry
/// mapping table — frozen since r38). Old-name references → E0021
/// compile-time error (diagnostics carry modern-name guidance — more
/// actionable than a bare E0004 unbound: 20 §7 "old-name reference =
/// E00xx error" honored). Adjudication consumer = driver
/// `verify_qualified_refs` (value and operator positions across the whole
/// domain — same traversal as E0014, same rules for shadowing/takeover
/// exemptions). Close-out guard `removed_names_closed_and_modern_registered`
/// (tests in this file): 27 pairs reconciled bidirectionally with zero
/// missing and zero surplus + zero old-name registration + all modern
/// names registered. The six gated I/O names have zero old names (zero
/// change to the gated table maintained — r38 field-test basis). The
/// v0.5-v0.8 dual-registration period ends (batch L introduced r38 →
/// W1001 deprecation r40 → removal r42 — the 23 §3.4 four-stage lifecycle
/// fully walked).
pub static REMOVED_BUILTIN_NAMES: &[(&str, &str)] = &[
    // Accessors (R1: head/tail final state)
    ("car", "head"),
    ("cdr", "tail"),
    // Lists (nth←list-ref, drop←list-tail)
    ("list-ref", "nth"),
    ("list-tail", "drop"),
    // Predicate family (R2: `is-`-style naming, final state)
    ("null?", "is-nil"),
    ("pair?", "is-pair"),
    ("int?", "is-int"),
    ("bool?", "is-bool"),
    ("procedure?", "is-procedure"),
    ("string?", "is-string"),
    ("symbol?", "is-symbol"),
    ("float?", "is-float"),
    ("number?", "is-number"),
    ("list?", "is-list"),
    // eq (R3: eq final state — exactly 2 args)
    ("eq?", "eq"),
    // String family (R1 full-word forms + R3 verbalized forms, final state)
    ("str-append", "string-append"),
    ("str-length", "string-length"),
    ("str-substring", "string-substring"),
    ("str-index-of", "string-index-of"),
    ("str-contains?", "string-contains"),
    ("str-prefix?", "string-starts-with"),
    ("str-suffix?", "string-ends-with"),
    // Conversion family (R4: `a-to-b` final state)
    ("str-upcase", "string-to-upper"),
    ("str-downcase", "string-to-lower"),
    ("string->symbol", "string-to-symbol"),
    ("symbol->string", "symbol-to-string"),
    // Assertions (R3: assertion is a verb)
    ("assert-eq?", "assert-eq"),
];

/// r47 / 68-b visibility-tightening leg (22 §15 D55): the **N1 core face**
/// — the full set of flat names visible in a compilation unit without any
/// declaration (38 names).
///
/// Semantic positioning = "the language's expression-layer vocabulary",
/// not "a library": value-model primitive operations
/// (operators/identity/logic/abort/assertion) + data-model vocabulary (pair
/// construction and access + list construction + the full predicate set —
/// the data model's primitive operations are part of the language, on par
/// with `+` for numbers; the mechanized corollary of D50 criterion ① "pair
/// construction is the oxygen line of homoiconic code": the oxygen line
/// gets no gate) + the six gated I/O items (**visibility permanently N1 +
/// authorization E0006 kept separate** — the two gates coincide at the io
/// family boundary: one `require io` declaration, two gates, D52 channel
/// table) + the four Reader bootstrap-private items (on the registration
/// roster [the reader.krf lifeline] — "not on the user face" is a
/// documentation discipline, not a registration-face split, 20 §5.2 note
/// maintained).
///
/// Consumers: driver `verify_unbound_refs` (E0022 visibility-face check
/// baseline) + `collect_warnings` (W1003/W1002 face-aware data source).
///
/// **Close-out guard**: `n1_core_and_module_flats_closed` (tests in this
/// file) — N1_CORE ∪ each module's flat underlying = the registration
/// face's full flat-name set (63) with zero missing and zero surplus
/// (single-source reconciliation — 22 §15 D54 ⑥ acceptance item;
/// r159 / 229-c: 62 → 63 with `%`).
pub static N1_CORE_NAMES: &[&str] = &[
    // Operator family (11 — numeric tower primitives; `%` = r159 the
    // EBNF Level 0 primary modulo face, `mod` = legacy call-form alias)
    "+",
    "-",
    "*",
    "/",
    "mod",
    "%",
    "=",
    "<",
    ">",
    "<=",
    ">=",
    // Identity/logic/abort/assertion (4 — cross-value-domain primitives)
    "eq",
    "not",
    "error",
    "assert-eq",
    // Pair construction/access + list construction (4 — data-model vocabulary)
    // + r138 / 208-c (TD-002 — vector-value-design.md D4): the vector
    // constructor joins the data-model vocabulary — REQUIRED for literal
    // usability (the desugar target of `[a b c]` must be import-free; a
    // literal demanding an import would be broken language design).
    // + r163 / 234-c (index-access-design.md D2/D3): vector-ref joins the
    // data-model vocabulary — REQUIRED for postfix-index usability (the
    // desugar target of `coll[idx]` must be import-free — the r138 D4
    // discipline extended to the index face; the VM global registration
    // predates this entry — this is a compiler-visible-face admission,
    // zero VM change; the hyphenated direct-write face stays lexically
    // intercepted by the r159 infix family, as with `=`/`eq` at r162).
    "cons",
    "head",
    "tail",
    "list",
    "vector",
    "vector-ref",
    // Full predicate set (10 + is-vector r138/208-c — the runtime face of
    // the type system; the vector value type's predicate, symmetric with
    // is-pair/is-list)
    "is-nil",
    "is-bool",
    "is-int",
    "is-float",
    "is-number",
    "is-string",
    "is-symbol",
    "is-pair",
    "is-list",
    "is-procedure",
    "is-vector",
    // Gated I/O (6 — N1 visibility + E0006 authorization kept separate)
    "print",
    "newline",
    "write-string",
    "read-line",
    "read-int",
    "read-num",
    // Reader bootstrap-private (4 — on the registration roster; user-face documentation discipline 20 §5.2)
    "string-to-pos-chars",
    "char-is-whitespace",
    "char-is-alphabetic",
    "string-is-int",
];

/// r47 / 68-b (D50 ② payload step): the prelude re-export face,
/// **single-source** (20 names — name-for-name identical to the
/// `bootstrap/preamble.krf` export list; the d50 contract test locks the
/// sync).
///
/// Derivation rule: the injection face of import kerf-prelude = this
/// list; the **flat visibility margin** = the names in it ∉ the N1 core
/// face (the five own HOFs + nth/drop [re-exported from kerf-list] = 7
/// names — the ten cons/head/tail/is-* items are N1-redundant; the
/// injection face includes them for the W1002 shadowing notification face
/// [consistent with the export declaration], and the flat reconciliation
/// face deduplicates automatically).
pub static PRELUDE_EXPORT_NAMES: &[&str] = &[
    // Five own items (defined in the preamble.krf body — kerf-source implementations)
    "map",
    "filter",
    "foldl",
    "foldr",
    "for-each",
    // Three pair items (re-exported from kerf-pair)
    "cons",
    "head",
    "tail",
    // Two list-domain items (re-exported from kerf-list)
    "nth",
    "drop",
    // Ten full-set predicates (re-exported from kerf-core)
    "is-nil",
    "is-bool",
    "is-int",
    "is-float",
    "is-number",
    "is-string",
    "is-symbol",
    "is-pair",
    "is-list",
    "is-procedure",
];

/// Module ns → flat visibility margin (underlying names — names among
/// `ns`'s exports ∉ the N1 core face; the flat runtime payload of
/// `import kerf-ns`). io returns the empty set (gated names permanently
/// N1 — the authorization gate is independent); core/pair/char return the
/// empty set (all underlying names are N1 — the import margin payload =
/// the qualified-name form); string/symbol share underlying names
/// (string-to-symbol/symbol-to-string, two local names on the same
/// underlying).
pub(crate) fn module_flat_underlying(ns: &str) -> Vec<&'static str> {
    STDLIB_MODULES
        .iter()
        .filter(|&&(m, _, _)| m == ns)
        .map(|&(_, _, u)| u)
        .filter(|u| !N1_CORE_NAMES.contains(u))
        .collect()
}

/// Flat name → suggested import module (the single source of suggestions
/// for the E0022 diagnostic "available after (import kerf-ns)":
/// underlying-name reverse lookup + prelude high-frequency set first —
/// nth/drop/mHOF suggest prelude, the rest suggest the source module).
pub(crate) fn suggest_import_for(name: &str) -> Option<&'static str> {
    // Prelude high-frequency set first (D50: the high-frequency-set shape of pairs/predicates/HOFs/nth/drop)
    if PRELUDE_EXPORT_NAMES.contains(&name) && !N1_CORE_NAMES.contains(&name) {
        return Some("kerf-prelude");
    }
    // Source-module reverse lookup (first hit — when string/symbol share
    // an underlying name, string comes first in table order, and the two
    // flat payloads are equivalent [same underlying, same dispatch body])
    STDLIB_MODULES
        .iter()
        .find(|&&(_, _, u)| u == name)
        .map(|&(m, _, _)| match m {
            "core" => "kerf-core",
            "pair" => "kerf-pair",
            "list" => "kerf-list",
            "string" => "kerf-string",
            "symbol" => "kerf-symbol",
            "io" => "kerf-io",
            "char" => "kerf-char",
            "vector" => "kerf-vector",
            _ => "kerf-core",
        })
}

/// W1003 macro-name shadowing adjudication (r42 / S1 — 22 §11 D11
/// scheduled removal-round same-window delivery): macro name ∈ the
/// builtin registration face (63 flat + 52 qualified) → W-level
/// notification. Consumer = driver `collect_warnings` (Stx-layer macro
/// name collection — after macro expansion the names vanish from
/// CoreExpr). Data sources = `BUILTIN_SIGS` (63 — read-line included
/// since r144 / 214-c; `%` since r159 / 229-c) + `STDLIB_MODULES`
/// qualified-name derivation (52).
pub(crate) fn builtin_name_exists(name: &str) -> bool {
    if BUILTIN_SIGS.iter().any(|(n, _)| *n == name) {
        return true;
    }
    STDLIB_MODULES
        .iter()
        .any(|&(ns, local, _)| name == format!("{}/{}", ns, local))
}

/// Batch M first item M1 (v0.6 namespace layer, r39) standard library
/// module table: the seven-module export face.
///
/// Row = (namespace segment, local name, underlying builtin name) — the
/// qualified name `ns/local-name` is registered sharing the same
/// `Rc<BuiltinFn>` as the underlying (same parity shape as the r38 alias
/// layer). Single source =
/// docs/lang-design/20-surface-conventions.md §5.2 (module-tree final
/// layout); mechanism rules = 22-namespace-design §2-§3 (N2 qualified-name
/// visibility face + R-N3 no fallback — the E0014 compile-time diagnostic
/// is carried by driver `verify_qualified_refs`).
/// The `io` module's qualified names are registered fail-closed against
/// the authorization face (22 §5.1 matrix's sole alignment point); the
/// operator family stays permanently N1 and out of the table (R-N7 — the
/// 20 §8 ruling "core does not export global operators"); the four Reader
/// runtime-service items (`string-to-pos-chars` etc.) are
/// bootstrap-private and stay off the user face (20 §5.2 note). M2 (r40)
/// carries the import injection face / aliases (R-N5) and the R-N1/N2
/// total order — this table lands M1 first, the "qualified-name visibility
/// face".
pub static STDLIB_MODULES: &[(&str, &str, &str)] = &[
    // kerf/core (14) — value-predicate domain + relation domain (20 §5.2 first row)
    ("core", "is-nil", "is-nil"),
    ("core", "is-bool", "is-bool"),
    ("core", "is-int", "is-int"),
    ("core", "is-float", "is-float"),
    ("core", "is-number", "is-number"),
    ("core", "is-string", "is-string"),
    ("core", "is-symbol", "is-symbol"),
    ("core", "is-pair", "is-pair"),
    ("core", "is-list", "is-list"),
    ("core", "is-procedure", "is-procedure"),
    ("core", "eq", "eq"),
    ("core", "not", "not"),
    ("core", "error", "error"),
    ("core", "assert-eq", "assert-eq"),
    // kerf/pair (3) — pair domain
    ("pair", "cons", "cons"),
    ("pair", "head", "head"),
    ("pair", "tail", "tail"),
    // kerf/list (9 — r164 / 235-c: five fixed-arity faces migrated to
    // the self-built kerf source bootstrap/list.ktf [forms-level injection —
    // the preamble.ktf isomorph]; `list` [N1 variadic constructor] and
    // `append` [variadic arity — TD-038] stay Rust-registered. The seven
    // migrated rows below are EXPORT-FACE-ONLY rows: the qualified-name
    // resolution face (E0014) and the selective-import face (E0024) consult
    // this table's export lists — their runtime bindings come from the
    // INJECTED module-body defines (list.ktf's export declaration is the
    // in-unit single source; this table row keeps the out-of-unit queries
    // whole), so the registration pass SKIPS them [SELF_BUILT_LIST_NAMES])
    ("list", "list", "list"),
    ("list", "append", "append"),
    ("list", "length", "length"),
    ("list", "reverse", "reverse"),
    ("list", "nth", "nth"),
    ("list", "drop", "drop"),
    ("list", "member", "member"),
    ("list", "assoc", "assoc"),
    ("list", "last-pair", "last-pair"),
    // kerf/string (11) — string domain (R4 bidirectional: to-symbol/from-symbol)
    ("string", "append", "string-append"),
    ("string", "length", "string-length"),
    ("string", "substring", "string-substring"),
    ("string", "index-of", "string-index-of"),
    ("string", "contains", "string-contains"),
    ("string", "starts-with", "string-starts-with"),
    ("string", "ends-with", "string-ends-with"),
    ("string", "to-upper", "string-to-upper"),
    ("string", "to-lower", "string-to-lower"),
    ("string", "to-symbol", "string-to-symbol"),
    ("string", "from-symbol", "symbol-to-string"),
    // kerf/symbol (2) — conversion domain, R4 bidirectional with two homes (dual to the string side)
    ("symbol", "to-string", "symbol-to-string"),
    ("symbol", "from-string", "string-to-symbol"),
    // kerf/io (6) — I/O domain (sole alignment point: gated full set ≡ exported full set)
    ("io", "print", "print"),
    ("io", "write-string", "write-string"),
    ("io", "newline", "newline"),
    ("io", "read-line", "read-line"),
    ("io", "read-int", "read-int"),
    ("io", "read-num", "read-num"),
    // kerf/char (2) — Unicode property-check domain (boundary ruling vs. bootstrap-private: 20 §5.2)
    ("char", "is-whitespace", "char-is-whitespace"),
    ("char", "is-alphabetic", "char-is-alphabetic"),
    // kerf/vector (5) — r138 / 208-c TD-002 vector value-type domain
    // (vector-value-design.md D4: local = flat — the ("list", "list",
    // "list") pattern; flat names carry the domain prefix where the list
    // family already owns the un-prefixed slot: length/append).
    ("vector", "vector", "vector"),
    ("vector", "vector-length", "vector-length"),
    ("vector", "vector-ref", "vector-ref"),
    ("vector", "vector-append", "vector-append"),
    ("vector", "is-vector", "is-vector"),
];

/// r164 / 235-c (list-self-built-design.md D1/D8 + the §0.1 performance-
/// boundary ruling): five list-domain faces migrated to the self-built kerf
/// source (bootstrap/list.ktf — forms-level injection; member/assoc stay
/// Rust-registered — the check-HM lookup segment's depth-sensitive hot
/// consumption trips the transitional VM instruction budget; re-migration
/// is trigger-gated on the native-AOT recovery path). Export-face-only rows
/// in `STDLIB_MODULES` (the E0014/E0024 qualified/selective query faces stay
/// whole) with NO Rust registration (the injected module-body defines are
/// the runtime single source). Consumers: the registration pass's skip
/// check + the closure guard's registered-face reconciliation (see
/// `n1_core_and_module_flats_closed`).
pub static SELF_BUILT_LIST_NAMES: &[&str] = &["length", "reverse", "nth", "drop", "last-pair"];

/// Capability-parameterized registration of the I/O builtins (r8 —
/// 13 §3.1.3 clause 4 "driver-registered builtin functions become
/// capability-parameterized in form").
///
/// **Gating semantics**: registered only when the token handle exists
/// (authorization face = declaration face, already aligned at compile
/// time by R9); the closure captures `Rc<RefCell<token>>` (F5 linear
/// approximation — borrow_mut exclusion = exclusive access during the
/// call). Error messages remain verbatim-compatible with r7 (anchored by
/// existing negative assertions); all I/O side effects go through the
/// frozen contract `StdCapabilityIO` (spec clauses 1/2 — the token
/// linearly occupies the signature slot).
fn register_io_globals(defs: &mut Vec<(&'static str, Rc<BuiltinFn>)>, grant: &IoGrant) {
    if let Some(write_cap) = grant.write_handle() {
        // —— print: render + write line (write capability) ——
        defs.push((
            "print",
            BuiltinFn::new("print", {
                let cap = write_cap.clone();
                move |heap, args| {
                    one_arg("print", &args)?;
                    let rendered = render_value(&args[0], heap);
                    cap_write_line(&cap, &rendered)?;
                    Ok(Value::Nil)
                }
            }),
        ));
        // —— newline: write an empty line (write capability) ——
        defs.push((
            "newline",
            BuiltinFn::new("newline", {
                let cap = write_cap.clone();
                move |_, args| {
                    if !args.is_empty() {
                        return Err(RuntimeError::new(format!(
                            "newline requires 0 arguments, got {}",
                            args.len()
                        )));
                    }
                    cap_write_line(&cap, "")?;
                    Ok(Value::Nil)
                }
            }),
        ));
        // —— write-string: write without newline (write capability;
        // direct write at the OS boundary — the frozen contract covers
        // only write_line; write_string is an r5 channel-layer extension) ——
        defs.push((
            "write-string",
            BuiltinFn::new("write-string", {
                let cap = write_cap.clone();
                move |_, args| {
                    one_arg("write-string", &args)?;
                    match &args[0] {
                        Value::Str(text) => {
                            // Token-occupancy check (capability in the signature — writes go through the authorization face)
                            let _ = cap.try_borrow_mut().map_err(|_| {
                                RuntimeError::new(
                                    "write capability token concurrently held (linearity violated)",
                                )
                            })?;
                            kerf_runtime::write_stdout(text)?;
                            Ok(Value::Nil)
                        }
                        other => Err(RuntimeError::new(format!(
                            "write-string requires str, got {}",
                            other.type_name()
                        ))),
                    }
                }
            }),
        ));
    }
    if let Some(read_cap) = grant.read_handle() {
        // —— read-line: read a line (read capability; EOF → nil — same as Stage 0) ——
        defs.push((
            "read-line",
            BuiltinFn::new("read-line", {
                let cap = read_cap.clone();
                move |_, args| {
                    if !args.is_empty() {
                        return Err(RuntimeError::new(format!(
                            "read-line requires 0 arguments, got {}",
                            args.len()
                        )));
                    }
                    match cap_read_line(&cap) {
                        Ok(s) => Ok(Value::Str(Rc::from(s.as_str()))),
                        Err(e) if e.message == "EOF" => Ok(Value::Nil),
                        Err(e) => Err(RuntimeError::new(e.message)),
                    }
                }
            }),
        ));
        // —— read-int: read a line and parse an integer (read capability) ——
        defs.push((
            "read-int",
            BuiltinFn::new("read-int", {
                let cap = read_cap.clone();
                move |_, args| {
                    if !args.is_empty() {
                        return Err(RuntimeError::new(format!(
                            "read-int requires 0 arguments, got {}",
                            args.len()
                        )));
                    }
                    match cap_read_line(&cap) {
                        Ok(s) => match s.trim().parse::<i64>() {
                            Ok(v) => Ok(Value::Int(v)),
                            Err(_) => Err(RuntimeError::new(format!(
                                "read-int parse failed: non-integer string `{}`",
                                s.trim()
                            ))),
                        },
                        Err(e) if e.message == "EOF" => Ok(Value::Nil),
                        Err(e) => Err(RuntimeError::new(e.message)),
                    }
                }
            }),
        ));
        // —— read-num: read a line and parse a number (read capability) ——
        defs.push((
            "read-num",
            BuiltinFn::new("read-num", {
                let cap = read_cap.clone();
                move |_, args| {
                    if !args.is_empty() {
                        return Err(RuntimeError::new(format!(
                            "read-num requires 0 arguments, got {}",
                            args.len()
                        )));
                    }
                    match cap_read_line(&cap) {
                        Ok(s) => {
                            let t = s.trim();
                            if let Ok(v) = t.parse::<i64>() {
                                return Ok(Value::Int(v));
                            }
                            match t.parse::<f64>() {
                                Ok(v) => Ok(Value::Float(v)),
                                Err(_) => Err(RuntimeError::new(format!(
                                    "read-num parse failed: non-digit string `{}`",
                                    t
                                ))),
                            }
                        }
                        Err(e) if e.message == "EOF" => Ok(Value::Nil),
                        Err(e) => Err(RuntimeError::new(e.message)),
                    }
                }
            }),
        ));
    }
}

/// Token-mediated write line (frozen-contract call — `CapabilityIO::write_line`).
fn cap_write_line(cap: &Rc<RefCell<WriteCapability>>, s: &str) -> Result<(), RuntimeError> {
    <StdCapabilityIO as CapabilityIO>::write_line(&mut cap.borrow_mut(), s)
        .map_err(|e| RuntimeError::new(e.message))
}

/// Token-mediated read line (frozen-contract call — EOF convention message "EOF", see StdCapabilityIO).
fn cap_read_line(cap: &Rc<RefCell<ReadCapability>>) -> Result<String, crate::reserved::IOError> {
    <StdCapabilityIO as CapabilityIO>::read_line(&mut cap.borrow_mut())
}

/// Hygiene fallback resolution: `$hyg$N` suffix stripping (the
/// established approximation of Stage 0 base-name resolution, see the
/// driver module docs). Unregistered global names in compiled output
/// attempt suffix-stripping fallback.
pub fn resolve_hygiene_fallbacks(
    program: &BcProgram,
    table: &mut SymbolTable,
    globals: &mut HashMap<Symbol, Value>,
) {
    for sym in program.global_refs.iter().copied() {
        if globals.contains_key(&sym) {
            continue;
        }
        let owned_name = table.name(sym).to_string();
        if let Some((base, suffix)) = owned_name.rsplit_once("$hyg$") {
            // The remaining suffix after the split must be digits (conservative check)
            if !suffix.is_empty() && suffix.chars().all(|c| c.is_ascii_digit()) {
                let base_sym = table.intern(base);
                if let Some(v) = globals.get(&base_sym).cloned() {
                    globals.insert(sym, v);
                }
            }
        }
    }
}

fn one_arg(name: &str, args: &[Value]) -> Result<(), RuntimeError> {
    if args.len() != 1 {
        return Err(RuntimeError::new(format!(
            "{} requires 1 arguments, got {}",
            name,
            args.len()
        )));
    }
    Ok(())
}

/// One-step cdr-chain adjudication for `list?` (r24 / 42-e): current slot
/// is a pair → Next(cdr); Nil → End(true) (proper-list termination);
/// anything else → End(false) (dotted pair / foreign object).
enum ListStep {
    Next(GcRef),
    End(bool),
}

fn list_step(heap: &Heap, r: GcRef) -> ListStep {
    match heap.get(r).map(|s| &s.obj) {
        Some(kerf_runtime::HeapObj::Pair(_, cdr)) => ListStep::Next(*cdr),
        Some(kerf_runtime::HeapObj::Nil) => ListStep::End(true),
        // _ arm rationale: Foreign/Str/Int/Float/Bool/Symbol slots — a
        // non-pair, non-nil terminator on the cdr chain (dotted-pair shape
        // or foreign object)
        _ => ListStep::End(false),
    }
}

fn two_args(name: &str, args: &[Value]) -> Result<(), RuntimeError> {
    if args.len() != 2 {
        return Err(RuntimeError::new(format!(
            "{} requires 2 arguments, got {}",
            name,
            args.len()
        )));
    }
    Ok(())
}

#[derive(PartialEq)]
enum Fold {
    Add,
    Sub,
    Mul,
    Div,
    Mod,
}

fn arith_builtin(name: &'static str, fold: Fold, min_args: usize) -> Rc<BuiltinFn> {
    BuiltinFn::new(name, move |_, args| {
        // Arity and identity-element boundaries (D5/D9 fixes, Scheme
        // conventions): (+) → 0, (*) → 1 (identity elements); (- x) → -x
        // (unary negation); / and mod have no identity element — zero or
        // insufficient args raise an arity error (before the fix, (+)
        // panicked on args[0] out-of-bounds; (- 5) wrongly returned 5).
        if args.is_empty() {
            return match fold {
                Fold::Add => Ok(Value::Int(0)),
                Fold::Mul => Ok(Value::Int(1)),
                _ => Err(RuntimeError::new(format!(
                    "{} at least requires {} arguments",
                    name, min_args
                ))),
            };
        }
        if args.len() < min_args {
            return Err(RuntimeError::new(format!(
                "{} at least requires {} arguments",
                name, min_args
            )));
        }
        if args.len() == 1 && fold == Fold::Sub {
            // Unary negation (D9): (- x) = 0 - x
            return match &args[0] {
                Value::Int(v) => v
                    .checked_neg()
                    .map(Value::Int)
                    .ok_or_else(|| RuntimeError::new("integer subtraction overflow")),
                Value::Float(v) => Ok(Value::Float(-v)),
                _ => Err(RuntimeError::new(format!("{} requires int", name))),
            };
        }
        let has_float = args.iter().any(|a| matches!(a, Value::Float(_)));
        if has_float {
            // Float path
            let mut acc = args[0]
                .as_number()
                .ok_or_else(|| RuntimeError::new(format!("{} requires a number", name)))?;
            for a in &args[1..] {
                let v = a
                    .as_number()
                    .ok_or_else(|| RuntimeError::new(format!("{} requires a number", name)))?;
                acc = match fold {
                    Fold::Add => acc + v,
                    Fold::Sub => acc - v,
                    Fold::Mul => acc * v,
                    Fold::Div => acc / v,
                    Fold::Mod => {
                        return Err(RuntimeError::new("mod does not accept float operands"));
                    }
                };
            }
            Ok(Value::Float(acc))
        } else {
            // Integer path (overflow-checked)
            let mut acc = args[0]
                .as_int()
                .ok_or_else(|| RuntimeError::new(format!("{} requires int", name)))?;
            for a in &args[1..] {
                let v = a
                    .as_int()
                    .ok_or_else(|| RuntimeError::new(format!("{} requires int", name)))?;
                acc = match fold {
                    Fold::Add => acc
                        .checked_add(v)
                        .ok_or_else(|| RuntimeError::new("integer addition overflow"))?,
                    Fold::Sub => acc
                        .checked_sub(v)
                        .ok_or_else(|| RuntimeError::new("integer subtraction overflow"))?,
                    Fold::Mul => acc
                        .checked_mul(v)
                        .ok_or_else(|| RuntimeError::new("integer multiplication overflow"))?,
                    Fold::Div => {
                        if v == 0 {
                            return Err(RuntimeError::new("integer division by zero"));
                        }
                        // D4 fix: i64::MIN / -1 overflow panic → structured error
                        acc.checked_div(v)
                            .ok_or_else(|| RuntimeError::new("integer division overflow"))?
                    }
                    Fold::Mod => {
                        if v == 0 {
                            return Err(RuntimeError::new("integer modulo by zero"));
                        }
                        // D4 fix: i64::MIN % -1 overflow panic → structured error
                        acc.checked_rem(v)
                            .ok_or_else(|| RuntimeError::new("integer modulo overflow"))?
                    }
                };
            }
            Ok(Value::Int(acc))
        }
    })
}

enum Cmp {
    Eq,
    Lt,
    Gt,
    Le,
    Ge,
}

// ---------------------------------------------------------------------------
// Static type-check signature table (Stage 1 batch C delivery; flag-period
// D8 phase 2 — injection data consumed twice, by the production
// adjudication face kerf_compiler::hm_check_program and by the
// check_program regression baseline assertions; the scheme-reinterpretation
// view is in hm-inference-design §3.5)
// ---------------------------------------------------------------------------

/// Static signature list for builtins (maintained in the same file as the
/// register_globals registry — single source of truth §2.3 principle 10;
/// anchored against drift by the `builtin_sigs_subset_of_registered`
/// test).
///
/// Signature rules align item-by-item with the runtime guards (arity
/// floor/ceiling consistent with the one_arg/two_args/args.len guards at
/// each registration site; parameter domains consistent with the match
/// guards). A builtin absent from the signature table = not statically
/// checked by the checker (conservatively skipped, no risk).
static BUILTIN_SIGS: &[(&str, BuiltinSig)] = &[
    // Arithmetic: numeric domain; identity-element arity floor ((+)/(*) legally take 0 args; (- x) unary negation)
    ("+", BuiltinSig::variadic(TcParam::Num, TcType::Num, 0)),
    ("-", BuiltinSig::variadic(TcParam::Num, TcType::Num, 1)),
    ("*", BuiltinSig::variadic(TcParam::Num, TcType::Num, 0)),
    ("/", BuiltinSig::variadic(TcParam::Num, TcType::Num, 2)),
    ("mod", BuiltinSig::variadic(TcParam::Num, TcType::Num, 2)),
    // r159 / 229-c: `%` shares the mod signature (same Fold::Mod dispatch
    // — one concept, two faces: infix primary + call-form alias).
    ("%", BuiltinSig::variadic(TcParam::Num, TcType::Num, 2)),
    // Comparison: all numbers or all strings (TD-011 r24: strings participate in the whole family via total order — code-point order)
    ("=", BuiltinSig::num_or_all_str()),
    ("<", BuiltinSig::ordering()),
    (">", BuiltinSig::ordering()),
    ("<=", BuiltinSig::ordering()),
    (">=", BuiltinSig::ordering()),
    // Pairs
    (
        "cons",
        BuiltinSig::fixed(&[TcParam::Any, TcParam::Any], TcType::Pair),
    ),
    ("head", BuiltinSig::fixed(&[TcParam::Pair], TcType::Unknown)),
    ("tail", BuiltinSig::fixed(&[TcParam::Pair], TcType::Unknown)),
    // list: zero args → nil (result domain Pair∪Nil → conservatively Unknown)
    (
        "list",
        BuiltinSig::variadic(TcParam::Any, TcType::Unknown, 0),
    ),
    // r138 / 208-c — TD-002 (vector-value-design.md D4/D5): the vector
    // family — params conservatively Any (negative coverage lands on the
    // runtime fail-closed enforcement face, the r137 extern D7 discipline),
    // results Unknown except the predicate (Bool) and the length (Int).
    // `vector` mirrors `list`'s variadic(Any, Unknown, 0) shape exactly.
    (
        "vector",
        BuiltinSig::variadic(TcParam::Any, TcType::Unknown, 0),
    ),
    (
        "vector-length",
        BuiltinSig::fixed(&[TcParam::Any], TcType::Int),
    ),
    (
        "vector-ref",
        BuiltinSig::fixed(&[TcParam::Any, TcParam::Any], TcType::Unknown),
    ),
    (
        "vector-append",
        BuiltinSig::variadic(TcParam::Any, TcType::Unknown, 0),
    ),
    (
        "is-vector",
        BuiltinSig::fixed(&[TcParam::Any], TcType::Bool),
    ),
    // Predicates (Bool result — consumed by upstream if-condition inference)
    ("is-nil", BuiltinSig::fixed(&[TcParam::Any], TcType::Bool)),
    ("is-pair", BuiltinSig::fixed(&[TcParam::Any], TcType::Bool)),
    ("is-int", BuiltinSig::fixed(&[TcParam::Any], TcType::Bool)),
    ("is-bool", BuiltinSig::fixed(&[TcParam::Any], TcType::Bool)),
    (
        "is-string",
        BuiltinSig::fixed(&[TcParam::Any], TcType::Bool),
    ),
    (
        "is-symbol",
        BuiltinSig::fixed(&[TcParam::Any], TcType::Bool),
    ),
    ("is-float", BuiltinSig::fixed(&[TcParam::Any], TcType::Bool)),
    (
        "is-number",
        BuiltinSig::fixed(&[TcParam::Any], TcType::Bool),
    ),
    ("is-list", BuiltinSig::fixed(&[TcParam::Any], TcType::Bool)),
    (
        "is-procedure",
        BuiltinSig::fixed(&[TcParam::Any], TcType::Bool),
    ),
    (
        "eq",
        BuiltinSig::fixed(&[TcParam::Any, TcParam::Any], TcType::Bool),
    ),
    // Logic
    ("not", BuiltinSig::fixed(&[TcParam::Bool], TcType::Bool)),
    // I/O (side-effect face — parameter domain unchecked, arity aligned)
    ("print", BuiltinSig::fixed(&[TcParam::Any], TcType::Nil)),
    ("newline", BuiltinSig::fixed(&[], TcType::Nil)),
    (
        "write-string",
        BuiltinSig::fixed(&[TcParam::Str], TcType::Nil),
    ),
    ("read-int", BuiltinSig::fixed(&[], TcType::Unknown)),
    ("read-num", BuiltinSig::fixed(&[], TcType::Unknown)),
    (
        // r144 / 214-c — read-line signature entry (read-line-sig-design
        // D2): the runtime has enforced exact 0-arity since the FS-4 fix
        // (20 §4 B3 contract "read-line strict arity"; the message was
        // re-anchored to the unified form in r141). The stale "runtime
        // does not check arity" rationale is retired — this entry mirrors
        // the read-int/read-num family form (gated, fixed 0-arg, Unknown
        // result: hit Str ∪ EOF Nil — no union constructor under the
        // 8-kind freeze, r142 member D3 precedent).
        "read-line",
        BuiltinSig::fixed(&[], TcType::Unknown),
    ),
    (
        "error",
        BuiltinSig::variadic(TcParam::Any, TcType::Unknown, 1),
    ),
    // List family — r164 / 235-c (list-self-built-design.md D7 + the
    // performance-boundary ruling §0.1): five fixed-arity faces (length/
    // reverse/nth/drop/last-pair) migrated to the self-built kerf source —
    // their static domains retire (the injected kerf definitions carry HM
    // generic inference; the runtime is-pair checks keep the fail-closed
    // error faces, messages verbatim); `append` (variadic — TD-038) and the
    // lookup pair member/assoc (check-HM depth-sensitive hot segment —
    // trigger-gated re-migration on the native-AOT recovery) stay registered.
    (
        "append",
        BuiltinSig::variadic(TcParam::Any, TcType::Unknown, 0),
    ),
    (
        "member",
        // r142 / 212-c — result widened Bool → Unknown (member-any-bool-model
        // design D3): the hit returns the sub-list (Pair) and only the miss
        // returns false, so the Bool predicate modeling false-positives every
        // value-consuming position; the r80 zero-false-positive contract
        // takes priority over predicate-result precision.
        BuiltinSig::fixed(&[TcParam::Any, TcParam::List], TcType::Unknown),
    ),
    (
        "assoc",
        BuiltinSig::fixed(&[TcParam::Any, TcParam::List], TcType::Unknown),
    ),
    (
        "append",
        BuiltinSig::variadic(TcParam::Any, TcType::Unknown, 0),
    ),
    // String family (r42/S1: full-word/verbalized modern names)
    (
        "string-length",
        BuiltinSig::fixed(&[TcParam::Str], TcType::Int),
    ),
    (
        "string-append",
        BuiltinSig::fixed(&[TcParam::Str, TcParam::Str], TcType::Str),
    ),
    (
        "string-substring",
        BuiltinSig::fixed(&[TcParam::Str, TcParam::Int, TcParam::Int], TcType::Str),
    ),
    (
        "string-index-of",
        BuiltinSig::fixed(&[TcParam::Str, TcParam::Str], TcType::Int),
    ),
    (
        "string-contains",
        BuiltinSig::fixed(&[TcParam::Str, TcParam::Str], TcType::Bool),
    ),
    (
        "string-starts-with",
        BuiltinSig::fixed(&[TcParam::Str, TcParam::Str], TcType::Bool),
    ),
    (
        "string-ends-with",
        BuiltinSig::fixed(&[TcParam::Str, TcParam::Str], TcType::Bool),
    ),
    (
        "string-to-upper",
        BuiltinSig::fixed(&[TcParam::Str], TcType::Str),
    ),
    (
        "string-to-lower",
        BuiltinSig::fixed(&[TcParam::Str], TcType::Str),
    ),
    (
        "string-to-symbol",
        BuiltinSig::fixed(&[TcParam::Str], TcType::Symbol),
    ),
    (
        "symbol-to-string",
        BuiltinSig::fixed(&[TcParam::Symbol], TcType::Str),
    ),
    // Reader primitives (B3)
    (
        "string-to-pos-chars",
        BuiltinSig::fixed(&[TcParam::Str], TcType::Pair),
    ),
    (
        "char-is-whitespace",
        BuiltinSig::fixed(&[TcParam::Str], TcType::Bool),
    ),
    (
        "char-is-alphabetic",
        BuiltinSig::fixed(&[TcParam::Str], TcType::Bool),
    ),
    (
        "string-is-int",
        BuiltinSig::fixed(&[TcParam::Str], TcType::Bool),
    ),
    // Assertions (r42/S1: verbalized)
    (
        "assert-eq",
        BuiltinSig::fixed(&[TcParam::Any, TcParam::Any], TcType::Bool),
    ),
    // r42/S1 removal note: the batch L dual-name sync segment (27 alias
    // entries) was deleted along with the retired old names — the main
    // signature section already holds the modern names directly (see the
    // r42/S1 notes on the sections above); the signature face stays at 56
    // base + vector five + read-line one + percent one = 63 (r144 / 214-c
    // + r159 / 229-c — the read-line entry cleared the r38 "not-listed"
    // historical anchor: the FS-4 runtime arity enforcement was already
    // in place, so the stale "runtime does not check arity" tail note is
    // retired; the percent entry cleared the r159 EBNF-vs-registration
    // gap: the term-level infix face is now first-class on the checker
    // face too).
];

/// Build the builtin static signature table (symbol → signature; the
/// injection entry for check_program).
///
/// Batch M first item M1 (r39): qualified-name signatures **derived from
/// the module table** — `ns/local-name` shares the underlying signature
/// (same dispatch → same static check face; an underlying miss skips the
/// derivation — a defensive path with zero live misses since r144 / 214-c
/// put read-line in the table: all 62 flat underlying names now carry
/// signatures). Derivation rather than static enumeration:
/// auto-syncs with `STDLIB_MODULES` (zero drift — the static face of the
/// 22 §8 R-N1/R-N3 rows).
pub fn builtin_sigs(table: &mut SymbolTable) -> HashMap<Symbol, BuiltinSig> {
    let mut map: HashMap<Symbol, BuiltinSig> = BUILTIN_SIGS
        .iter()
        .map(|(name, sig)| (table.intern(name), *sig))
        .collect();
    for &(ns, local, underlying) in STDLIB_MODULES {
        let u = table.intern(underlying);
        if let Some(sig) = map.get(&u).copied() {
            let qualified = format!("{}/{}", ns, local);
            map.insert(table.intern(&qualified), sig);
        }
    }
    map
}

/// r135 / member-rename-design.md v1.2 §8 D12: renamed-binding signature
/// derivation — `builtin_sigs` + the renamed → underlying derivation
/// loop (the r39 qualified-name derivation's member-rename analogue:
/// same dispatch body → same static check face; an underlying miss is
/// skipped — a defensive path with zero live misses since r144 / 214-c
/// put read-line in the table, so read-family renames now derive the
/// 0-arg signature and reject extra-arg call sites like the flat name).
/// The value-position-constant-Dynamic discipline (A4) is unchanged —
/// derivation entries are consumed only at the apply-position signature
/// lookup.
pub fn builtin_sigs_with_renames(
    table: &mut SymbolTable,
    renames: &[(String, String)],
) -> HashMap<Symbol, BuiltinSig> {
    let mut map = builtin_sigs(table);
    for (renamed, underlying) in renames {
        let u = table.intern(underlying.as_str());
        if let Some(sig) = map.get(&u).copied() {
            map.insert(table.intern(renamed.as_str()), sig);
        }
    }
    map
}

fn cmp_builtin(name: &'static str, cmp: Cmp) -> Rc<BuiltinFn> {
    BuiltinFn::new(name, move |_, args| {
        if args.len() < 2 {
            return Err(RuntimeError::new(format!(
                "{} at least requires 2 arguments",
                name
            )));
        }
        // TD-016 (batch C tightening) up-front whole-argument-domain check
        // + TD-011 (resolved r24): a comparison chain that short-circuits
        // does not skip type checks of later operands; **all-string chains
        // participate in the entire comparison family by Unicode code-point
        // order** (including the ordering family); other chains are checked
        // per-argument for value domain — first non-number → the "{op} needs
        // numbers" error (consistent with the mixed-string/non-number
        // two-arg message, keeping the TD-016 two-arg rule).
        let all_str = args.iter().all(|a| matches!(a, Value::Str(_)));
        if !all_str {
            for a in &args {
                if a.as_number().is_none() {
                    return Err(RuntimeError::new(format!("{} requires a number", name)));
                }
            }
        }
        // Chained comparison: (= a b c) is equivalent to every adjacent pair
        // holding (type domain already checked up front — the error arm
        // below becomes a defensive path)
        for w in args.windows(2) {
            let (a, b) = (&w[0], &w[1]);
            let ok = match (&cmp, a, b) {
                (Cmp::Eq, Value::Int(x), Value::Int(y)) => x == y,
                (Cmp::Lt, Value::Int(x), Value::Int(y)) => x < y,
                (Cmp::Gt, Value::Int(x), Value::Int(y)) => x > y,
                (Cmp::Le, Value::Int(x), Value::Int(y)) => x <= y,
                (Cmp::Ge, Value::Int(x), Value::Int(y)) => x >= y,
                // TD-011 (r24): string total order — `Rc<str>` comparison
                // is UTF-8 byte order (UTF-8 encoding preserves order →
                // identical to the Unicode code-point total order; the
                // 09-stdlib v6.3 code-point-order ruling)
                (c, Value::Str(x), Value::Str(y)) => match c {
                    Cmp::Eq => x == y,
                    Cmp::Lt => x < y,
                    Cmp::Gt => x > y,
                    Cmp::Le => x <= y,
                    Cmp::Ge => x >= y,
                },
                // _ arm rationale: combinations with Float or mixed types — promoted via as_number to f64 for uniform comparison; non-numbers error here
                _ => {
                    let x = a
                        .as_number()
                        .ok_or_else(|| RuntimeError::new(format!("{} requires a number", name)))?;
                    let y = b
                        .as_number()
                        .ok_or_else(|| RuntimeError::new(format!("{} requires a number", name)))?;
                    match cmp {
                        Cmp::Eq => x == y,
                        Cmp::Lt => x < y,
                        Cmp::Gt => x > y,
                        Cmp::Le => x <= y,
                        Cmp::Ge => x >= y,
                    }
                }
            };
            if !ok {
                return Ok(Value::Bool(false));
            }
        }
        Ok(Value::Bool(true))
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Full grant (read/write tokens both present — precondition for registering I/O builtins).
    fn full_grant() -> IoGrant {
        IoGrant::from_requirements(crate::capability::IoRequirements {
            read: true,
            write: true,
        })
    }

    /// r47 / 68-b visibility-tightening leg **close-out guard** (22 §15
    /// D54 ⑥ acceptance item): N1 core face (41) ∪ the seven modules'
    /// underlying full set == the registration face's full flat-name set
    /// (63 — registration keys without `/`) with zero missing and zero
    /// surplus — single-source reconciliation of the visibility face
    /// (machine anchor for the completeness of the N1-face/module-domain
    /// partition: every flat name on the registration face is either
    /// permanently N1 or belongs to exactly one module's export domain
    /// [import-visible] — no third state slips through).
    #[test]
    fn n1_core_and_module_flats_closed() {
        let mut t = SymbolTable::new();
        let g = register_globals(&mut t, &full_grant());
        let flat_registered: std::collections::HashSet<String> = g
            .keys()
            .map(|s| t.name(*s).to_string())
            // Qualified-name domain filtered out (contains `/` and length
            // > 1 — bare `/` is the division operator itself, same rule
            // as qualified_ref_diag [R-N4 lexical-domain convention])
            .filter(|n| n.len() <= 1 || !n.contains('/'))
            .collect();
        // N1 core face + the seven modules' underlying names (N1
        // redundancies included — the core/pair/predicate/io/char domains'
        // underlying names are all N1; the list/string domains' 19 names
        // are the contracted face)
        // r164 / 235-c: the seven self-built list faces carry export-face-only
        // rows — they are EXCLUDED from the registered-face reconciliation
        // (their runtime bindings are the injected module-body defines, not
        // Rust registrations) and reconciled separately below (the export-face
        // completeness assertion).
        let mut classified: std::collections::HashSet<String> =
            N1_CORE_NAMES.iter().map(|s| s.to_string()).collect();
        for &(_, _, u) in STDLIB_MODULES {
            if !SELF_BUILT_LIST_NAMES.contains(&u) {
                classified.insert(u.to_string());
            }
        }
        assert_eq!(
            flat_registered, classified,
            "N1 ∪ module underlying (minus self-built) and the registration face's flat-name universe should be equal name-by-name (58 — r164: 63 - 5 self-built)"
        );
        // Export-face completeness: every self-built name keeps its
        // STDLIB_MODULES list-domain row (the E0014/E0024 query faces stay
        // whole — an out-of-unit qualified/selective reference resolves).
        for n in SELF_BUILT_LIST_NAMES {
            assert!(
                STDLIB_MODULES.iter().any(|&(_, _, u)| u == *n),
                "self-built list face `{n}` lost its export-face row"
            );
        }
        // The N1 face itself has 42 names + 22 contracted names (list 8 + string/symbol 11 + vector 3 — r138; % r159; vector-ref r163)
        assert_eq!(
            N1_CORE_NAMES.len(),
            42,
            "N1 core face 42 names (D55 criteria set + vector/is-vector r138 + % r159 + vector-ref r163 index face)"
        );
        let contracted: Vec<&str> = flat_registered
            .iter()
            .filter(|n| !N1_CORE_NAMES.contains(&n.as_str()))
            .map(|s| s.as_str())
            .collect();
        assert_eq!(
            contracted.len(),
            16,
            "shrink face 16 names (list 4 [list/append/member/assoc] + string 11 + vector 2 -- r138; vector-ref moved N1 r163/234-c; r164/235-c: five self-built list faces left the REGISTERED face [length/reverse/nth/drop/last-pair — export-face rows persist, bindings = injected defines; member/assoc restored by the performance-boundary ruling])"
        );
        // PRELUDE export face, 20 names, single-source sync (the constant-side anchor of the d50 contract)
        assert_eq!(PRELUDE_EXPORT_NAMES.len(), 20);
    }

    // -----------------------------------------------------------------------
    // Static signature table vs. registry — bidirectional anti-drift anchor
    // (single source of truth §2.3 principle 10)
    // -----------------------------------------------------------------------

    /// Every signature-table name is registered (this test intercepts drift when builtins are renamed/deleted).
    #[test]
    fn builtin_sigs_subset_of_registered() {
        let mut t = SymbolTable::new();
        let g = register_globals(&mut t, &full_grant());
        let sigs = builtin_sigs(&mut t);
        for sym in sigs.keys() {
            assert!(
                g.contains_key(sym),
                "signature table entry not registration: {}",
                t.name(*sym)
            );
        }
    }

    /// r42 / S1 removal-round close-out guard (20 §7 removal-round line —
    /// the structural anchor for retiring the 27 old names; the
    /// removal-round evolution of the r38 alias close-out guard):
    /// ① table length 27; ② bidirectional reconciliation with zero
    /// duplicates; ③ zero old-name registration (including the
    /// zero-authorization face — fail-closed); ④ all modern names
    /// registered; ⑤ zero old-name signatures (the HM static face rejects
    /// old names equally — the BUILTIN_SIGS main section already holds the
    /// modern names directly); ⑥ zero old names on the gated face (the r38
    /// field-test basis maintained).
    #[test]
    fn removed_names_closed_and_modern_registered() {
        let mut t = SymbolTable::new();
        let g = register_globals(&mut t, &full_grant());
        let sigs = builtin_sigs(&mut t);
        assert_eq!(
            REMOVED_BUILTIN_NAMES.len(),
            27,
            "retired table length should be 27(20 §8)"
        );
        // r42/S1 count anchor → r138/208-c → r159/229-c → r164/235-c: full-
        // authorization face 105 (58 flat + 47 qualified; five self-built list
        // faces left both faces, member/assoc restored by the perf ruling)
        assert_eq!(
            g.len(),
            105,
            "fully-authorized registration face should be 105(58 flat + 47 qualified -- r159 after; r164/235-c: five self-built list faces left both faces [flat + qualified], member/assoc restored)"
        );
        let mut seen_old: Vec<&str> = Vec::new();
        let mut seen_new: Vec<&str> = Vec::new();
        for &(old, modern) in REMOVED_BUILTIN_NAMES {
            assert!(!seen_old.contains(&old), "old name duplicate: {}", old);
            assert!(
                !seen_new.contains(&modern),
                "modern name duplicate: {}",
                modern
            );
            assert_ne!(old, modern, "map must not point to itself: {}", old);
            seen_old.push(old);
            seen_new.push(modern);
            // ③ zero old-name registration (full-authorization face)
            let o = t.intern(old);
            assert!(
                !g.contains_key(&o),
                "retired old name must not register: {}",
                old
            );
            // ⑤ zero old-name signatures (the static face rejects equally)
            assert!(
                !sigs.contains_key(&o),
                "old name must not hold a signature: {}",
                old
            );
            // ④ all modern names registered + holding signatures (except
            // read-line — the not-listed rule; r164/235-c: except the
            // SELF_BUILT five — their bindings are the injected kerf defines,
            // not Rust registrations)
            let m = t.intern(modern);
            if !SELF_BUILT_LIST_NAMES.contains(&modern) {
                assert!(
                    g.contains_key(&m),
                    "modern name not registration: {}",
                    modern
                );
            }
            if modern != "read-line" && !SELF_BUILT_LIST_NAMES.contains(&modern) {
                assert!(
                    sigs.contains_key(&m),
                    "modern name missing signature: {}",
                    modern
                );
            }
            // ⑥ zero old names among the gated set (20 §6.4 ③ maintained)
            assert!(
                !crate::capability::READ_GATED.contains(&old)
                    && !crate::capability::WRITE_GATED.contains(&old),
                "retired old name {} not should appear in gating face",
                old
            );
        }
        // ③ (continued) zero old-name registration on the zero-authorization face too
        let mut t2 = SymbolTable::new();
        let none_grant = IoGrant::from_requirements(crate::capability::IoRequirements {
            read: false,
            write: false,
        });
        let g0 = register_globals(&mut t2, &none_grant);
        for &(old, _) in REMOVED_BUILTIN_NAMES {
            let o = t2.intern(old);
            assert!(
                !g0.contains_key(&o),
                "zero-authorization face old name must not register: {}",
                old
            );
        }
    }

    /// Batch M M1 module-table close-out guard (r39 — the structural anchor
    /// of the 22 §8 implementation reconciliation table; counts carried to
    /// the r138/208-c vector face): ① total row
    /// count 52 + per-module face counts (20 §5.2 line-by-line
    /// reconciliation: 14/3/9/11/2/6/2 + vector 5); ② full-authorization face: every
    /// qualified name registered + every underlying registered + the
    /// global table exactly 115 (63 base + 52 qualified
    /// names — the count anchor also intercepts the HashMap-overwrite trap
    /// of a qualified name colliding with a base name); ③ zero name
    /// overlap between qualified names and the base face (overwrite
    /// prevention); ④ zero-authorization face: the 46 non-io qualified
    /// names always registered (the io family is fail-closed per
    /// authorization item — 22 §5.1 matrix); ⑤ qualified-name signature
    /// derivation = underlying signature (except read-line — the
    /// no-underlying-entry rule maintained).
    #[test]
    fn stdlib_modules_closed_and_qualified_registered() {
        let mut t = SymbolTable::new();
        let g = register_globals(&mut t, &full_grant());
        let sigs = builtin_sigs(&mut t);
        // ① Row count and per-face counts (20 §5.2)
        assert_eq!(
            STDLIB_MODULES.len(),
            52,
            "module table total line count should be 52(47 + vector 5 -- r138)"
        );
        let mut per_ns: std::collections::HashMap<&str, usize> = std::collections::HashMap::new();
        for &(ns, _, _) in STDLIB_MODULES {
            *per_ns.entry(ns).or_default() += 1;
        }
        for (ns, expect) in [
            ("core", 14),
            ("pair", 3),
            ("list", 9),
            ("string", 11),
            ("symbol", 2),
            ("io", 6),
            ("char", 2),
            ("vector", 5),
        ] {
            assert_eq!(
                per_ns.get(ns).copied().unwrap_or(0),
                expect,
                "module {} face count drift (20 §5.2)",
                ns
            );
        }
        // ② Full authorization: dual registration + count anchor 105 (r164/235-c:
        // 58 flat + 47 qualified; five self-built faces left, member/assoc restored)
        assert_eq!(
            g.len(),
            105,
            "fully-authorized registration face should be 105(58 flat + 47 qualified -- r164/235-c: five self-built list faces left both faces, member/assoc restored)"
        );
        for &(ns, local, underlying) in STDLIB_MODULES {
            // r164/235-c: the SELF_BUILT five's rows are export-face-only
            // (qualified + flat bindings = the injected kerf defines) — skip
            // the registration asserts for them.
            if SELF_BUILT_LIST_NAMES.contains(&underlying) {
                continue;
            }
            let q = t.intern(&format!("{}/{}", ns, local));
            assert!(
                g.contains_key(&q),
                "qualified name not registration: {}/{}",
                ns,
                local
            );
            let u = t.intern(underlying);
            assert!(
                g.contains_key(&u),
                "underlying not registered: {}",
                underlying
            );
            // ⑤ Derived signature matches the underlying (except read-line — no underlying entry)
            let sig_q = sigs.get(&q);
            let sig_u = sigs.get(&u);
            if underlying != "read-line" {
                assert!(
                    sig_q.is_some(),
                    "qualified name missing derived signature: {}/{}",
                    ns,
                    local
                );
                assert_eq!(
                    sig_q.copied(),
                    sig_u.copied(),
                    "derived signature drift: {}/{} vs {}",
                    ns,
                    local,
                    underlying
                );
            }
        }
        // ④ Zero-authorization face: the 41 non-io qualified names always registered (io fail-closed — checked per item)
        let mut t2 = SymbolTable::new();
        let none_grant = IoGrant::from_requirements(crate::capability::IoRequirements {
            read: false,
            write: false,
        });
        let g0 = register_globals(&mut t2, &none_grant);
        // Zero authorization: base 57 (63 - 6 gated names unregistered) + 46 non-io qualified = 103
        assert_eq!(
            g0.len(),
            93,
            "zero-authorization face should be 93 (52 base + 41 non-io qualified -- r164/235-c: five self-built list faces left both faces, member/assoc restored)"
        );
        for &(ns, local, underlying) in STDLIB_MODULES {
            // r164/235-c: the SELF_BUILT five's qualified keys are not
            // registered (their bindings = the injected kerf defines) — skip.
            if SELF_BUILT_LIST_NAMES.contains(&underlying) {
                continue;
            }
            let q = t2.intern(&format!("{}/{}", ns, local));
            let registered = g0.contains_key(&q);
            assert_eq!(
                registered,
                ns != "io",
                "zero-authorization face qualified name registration state abnormal: {}/{} (io should fail-closed without registering)",
                ns,
                local
            );
        }
    }

    /// Gated leg of the three-way guard (r38 — 20 §9.4: registered ⊇
    /// signatures ⊆ gated, i.e. "gated ⊆ registered"): all six names of
    /// the R9 data-driven tables (READ_GATED/WRITE_GATED) are registered.
    /// r42/S1: the alias leg went offline with the retirement (zero
    /// old-name registration is already carried by clause ③ of
    /// `removed_names_closed_and_modern_registered`); zero intersection
    /// between gated names and retired old names is carried by guard ⑥
    /// of the same test.
    #[test]
    fn builtin_gating_names_subset_of_registered() {
        let mut t = SymbolTable::new();
        let g = register_globals(&mut t, &full_grant());
        for name in crate::capability::READ_GATED
            .iter()
            .chain(crate::capability::WRITE_GATED.iter())
        {
            let sym = t.intern(name);
            assert!(
                g.contains_key(&sym),
                "gating builtin not registration: {}",
                name
            );
        }
    }

    /// Full signature coverage of the operator families (arithmetic/
    /// comparison/pairs/logic/string conversion/assertion — intercepts new
    /// builtins added to these families without a signature).
    #[test]
    fn builtin_sigs_cover_operator_families() {
        let mut t = SymbolTable::new();
        let g = register_globals(&mut t, &full_grant());
        let sigs = builtin_sigs(&mut t);
        let families = [
            "+",
            "-",
            "*",
            "/",
            "mod",
            "%",
            "=",
            "<",
            ">",
            "<=",
            ">=",
            "cons",
            "head",
            "tail",
            "not",
            "eq",
            "string-length",
            "string-append",
            "string-to-symbol",
            "symbol-to-string",
            // r164/235-c: "length" left the registered face (self-built
            // injection) — removed from this family list; member/assoc stay.
            "assert-eq",
        ];
        for name in families {
            let sym = t.intern(name);
            assert!(g.contains_key(&sym), "builtin missing: {}", name);
            assert!(
                sigs.contains_key(&sym),
                "operator family missing signature: {}",
                name
            );
        }
    }

    #[test]
    fn globals_have_core_set() {
        let mut t = SymbolTable::new();
        let g = register_globals(&mut t, &full_grant());
        for name in ["+", "-", "cons", "head", "print", "read-line", "eq"] {
            let sym = t.intern(name);
            assert!(g.contains_key(&sym), "missing builtin {}", name);
        }
    }

    #[test]
    fn hygiene_fallback_resolves() {
        let mut t = SymbolTable::new();
        let mut g = register_globals(&mut t, &full_grant());
        let hyg = t.intern("+$hyg$3");
        let program = BcProgram {
            protos: vec![],
            consts: vec![],
            entry: 0,
            global_refs: vec![hyg],
            module_name: None,
        };
        resolve_hygiene_fallbacks(&program, &mut t, &mut g);
        assert!(
            g.contains_key(&hyg),
            "hygiene fallback should parse +$hyg$3 → +"
        );
    }

    #[test]
    fn hygiene_fallback_rejects_non_suffix() {
        let mut t = SymbolTable::new();
        let mut g = register_globals(&mut t, &full_grant());
        let not_hyg = t.intern("some-user-name");
        let program = BcProgram {
            protos: vec![],
            consts: vec![],
            entry: 0,
            global_refs: vec![not_hyg],
            module_name: None,
        };
        resolve_hygiene_fallbacks(&program, &mut t, &mut g);
        assert!(
            !g.contains_key(&not_hyg),
            "plain unbound names must not be silently resolved"
        );
    }
}

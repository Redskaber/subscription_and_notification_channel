//! # kerf-driver
//!
//! **Five orthogonal axes positioning (lang-design 15 §5.3, v6.0)**: **composition root** (the sole knows-all layer, 15 §5.1 compositor) — axes 3/4 bridge point (effects/capability) + front pipeline threading read→expand→typecheck→R9→compile.
//!
//! Compiler entry (orchestration layer): the full `read → expand → lower → compile → run` pipeline.
//!
//! **Pipeline** (sop.md §2.4.4 one-way flow):
//! ```text
//! source text → [kerf-reader] Token/Stx → [kerf-expander] CoreExpr
//!           → [kerf-core] IrGraph/CodeValue → [kerf-compiler] BcProgram
//!           → [kerf-vm] execution (VM as the sole production path —
//!           r23/INC7 eval retired; the cross-check basis = production
//!           chain vs seed chain) → [kerf-runtime] heap and I/O
//! ```
//!
//! **Phase separation wiring** (§8.9): declare → visit (transformer registration) → instantiate (consumption of compilation artifacts) — a single module's complete lifecycle is bookkept via `ModuleRegistry`.
//!
//! **Global environment**: builtin function registration (§9.stdlib: zero builtins in the language core, all injected via the driver) + hygienic fallback resolution (`$hyg$N` suffix stripping — the established approximation of Stage 0 base-name resolution).
//!
//! **Reserved interface layer** (§9.1, P2/P3 level): effect handlers / multi-stage programming / capability-model I/O / compilation cache — type signatures and behavioral specs only, frozen contracts.

//! **Self-hosting Reader** (B3, Stage 1 batch B + **E6 terminal r154 /
//! 224-a**): the `bootstrap` module — the sole Reader artifact
//! `bootstrap/reader.ktf` (renamed from reader.ktf per
//! s-expr-removal-plan §11) is compiled via the seed target pipeline and
//! runs on the VM; the production read path (`compile_front`)
//! goes through it, while the seed (kerf-reader target face) is retained
//! as the bootstrap implementation and parity oracle (07-bootstrap
//! §3.2 mixed-period composition; the S-expr classic Reader face was
//! deleted at the E6 close-out — target.rs is the sole Rust Reader
//! implementation).

pub mod bootstrap;
pub mod builtins;
pub mod cache;
pub mod capability;
pub mod driver;
pub mod effects;
pub mod ffi;
pub mod hash;
pub mod reserved;

// Explicit re-exports (§10.1 rule 4: glob re-exports forbidden).
// Convention: this crate exposes all public types and entry points of the driver layer.
pub use bootstrap::compiler::compiler_bootstrap_is_ktf_corpus;
pub use bootstrap::expander::expander_bootstrap_is_ktf_corpus;
pub use bootstrap::test_runner::{
    production_test_runner_is_bootstrap, run_test_case as test_runner_run_test_case,
    TestRunnerError,
};
pub use cache::{
    cache_enabled, cache_entry_count, cache_invalidate_all, cache_key, cache_reset, cache_stats,
    set_cache_enabled, CacheStats, InMemoryCompilationCache, COMPILE_CONFIG_SEED,
};
pub use capability::{IoGrant, IoRequirements, StdCapabilityIO};
pub use driver::{
    check_source_recover, compile_source, dump_stx, dump_tokens, imports_prelude_seed,
    production_prelude_is_ktf_reader, run_source, run_source_seed, seed_prelude_is_seed_reader,
    CheckReport, CompileOutput, CompilerKind, DriverError, RunOutcome, Stage, TestCaseOutcome,
    TestReport,
};
pub use effects::{
    handle_escape, perform_escape, InternalEffectSystem, ValueEffect, ValueEffectFamily,
    ValueHandler,
};
pub use hash::{content_hash64, sha256, sha256_hex};
// The space skeleton marker family is unified through the reserved forwarding
// chain (r69 / 134-a·D-1 fix: 8 markers, single path — aligned with the
// "composition-root forwarding face" design intent of reserved/mod.rs
// [principle 27: paths always valid]; the old direct
// `pub use kerf_space::CoreSpace` was an r66 landing-residue dual-path
// deviation, now merged).
use kerf_space::CoreDriverDomain;
pub use reserved::{
    CacheKey, CachedResult, CapabilityDomain, CapabilityIO, CompilationCache, CoreSpace, Effect,
    EffectDomain, EffectFamily, EffectSystem, ExtensionSpace, ForeignDomain, IOError,
    MetaprogrammingDomain, MultiStage, ReadCapability, RootSpace, ToolchainDomain, WriteCapability,
};

// ---------------------------------------------------------------------------
// Space affiliation declaration section (r66 / 123-a — lang-design 24 v2.0
// two-sided unified system; 24 §7.2 core-side incorporation table: this
// crate's trunk main types get three-layer explicit impls [root + core
// space + domain] — the core organizational domain (composition root —
// compilation pipeline assembly / self-hosting driver; 15 §5.1 the sole
// knows-all layer). The core-side edition of "declaration implies
// affiliation"; the materialized faces [capability/effects/cache/ffi]
// belong to the extension side L4 [24 §4.8 seed implementation — their
// impls live in each file]; the sole affiliation criterion = marker impl
// [24 §3 A7])
// ---------------------------------------------------------------------------
impl RootSpace for driver::Stage {}
impl CoreSpace for driver::Stage {}
impl CoreDriverDomain for driver::Stage {}
impl RootSpace for driver::DriverError {}
impl CoreSpace for driver::DriverError {}
impl CoreDriverDomain for driver::DriverError {}
impl RootSpace for driver::CompileOutput {}
impl CoreSpace for driver::CompileOutput {}
impl CoreDriverDomain for driver::CompileOutput {}
impl RootSpace for driver::CompilerKind {}
impl CoreSpace for driver::CompilerKind {}
impl CoreDriverDomain for driver::CompilerKind {}
impl RootSpace for driver::CheckReport {}
impl CoreSpace for driver::CheckReport {}
impl CoreDriverDomain for driver::CheckReport {}
impl RootSpace for driver::RunOutcome {}
impl CoreSpace for driver::RunOutcome {}
impl CoreDriverDomain for driver::RunOutcome {}

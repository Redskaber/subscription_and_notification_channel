//! Capability-model I/O foundational delivery (r8 batch D — D2: the
//! 13 §3.1.3 P2 spec made concrete, 12-roadmap §2.4.5 Stage 1 "basic
//! capabilities (read/write require authorization)").
//!
//! **Layer-positioning note (r19 / 41-a)**: this module is the capability
//! model's **pipeline layer** (declaration extraction → minting →
//! verification → consumption — the four-stage architecture is generic;
//! the data-plane io family concretizes it); the model-layer skeleton is
//! in `reserved/capability_model.rs` (family shapes + calculus slots),
//! the family-layer contract in `reserved/capability_io.rs`
//! (capability-model-design.md §4.3 layered architecture; the M2
//! generalization-naming migration window = late batch I — D12).
//! **M2 execution note (r25 / 42-f)**: family-agnostic forms are carried
//! by model-layer traits (the [`IoFamily`] shape marker — `IoGrant` is
//! the alias-compatible semantics of `Grant<io family>`, frozen path with
//! zero deletions or changes — design §7 M2 "alias/annotation" path);
//! the gated-table net row-addition evaluation is in the [`READ_GATED`]
//! trailing note (rows stay unchanged — zero-breakage discipline).
//!
//! **Three-layer division of labor** (interface-contract-review F2 fix
//! ruling):
//! - `reserved.rs`: frozen contract (token types + the `CapabilityIO`
//!   trait — signature authority);
//! - this module: **minting + implementation + verification** —
//!   `IoRequirements` (declaration extraction), `IoGrant` (token minting,
//!   pub(crate) construction face), `StdCapabilityIO` (the stdio
//!   implementation of the frozen trait), `verify_io_capabilities`
//!   (R9 compile-time permission verification, E0006);
//! - `builtins.rs`: **consumption** — the I/O builtins capture tokens
//!   (capability-parameterized form, spec clause 4 "driver-registered
//!   builtin functions become capability-parameterized").
//!
//! **Behavior-spec clause-by-clause anchors** (13 §3.1.3):
//! 1. `read_line` is callable only while holding `ReadCapability` — the
//!    token passes linearly (`RefCell` borrow-period exclusion = linear
//!    approximation, F5), non-copyable and non-forgeable (private
//!    construction + pub(crate) minting);
//! 2. `write_line` likewise;
//! 3. an I/O call without a token is a **compile-time error** (R9/E0006 —
//!    verified on all paths of the front pipeline, not a runtime check);
//! 4. progressive replacement: all I/O on the kerf program face goes
//!    through tokens; the `kerf_runtime::io` global functions are demoted
//!    to the OS boundary layer (below StdCapabilityIO), fully retired when
//!    Stage 2 brings language-level token value forms.
//!
//! **R9 rule** (conservative static — zero-false-positive contract, same
//! discipline as R1-R8): any **reference** (Var in any position) in the
//! program to a gated builtin name (read-line/read-int/read-num/read;
//! print/newline/write-string/write) requires the corresponding
//! `(require io ...)` declaration; **user-takeover exemption**: when the
//! program itself defines/set!s that name it counts as a user global (not
//! builtin use, unflagged — a deterministic boundary, preventing false
//! positives). Hygiene-fallback symbols (`name$hyg$N`) are adjudicated by
//! base name (same rule as the driver runtime fallback).

use std::cell::RefCell;
use std::collections::HashSet;
use std::rc::Rc;

use kerf_core::{Capability, CoreExpr, ModuleItem};
use kerf_span::{render_diagnostic, Diagnostic, DiagnosticCode, SourceMap, Span};
use kerf_syntax::{Symbol, SymbolTable};

use crate::driver::{DriverError, Stage};
use crate::reserved::{
    mint_read_token, mint_write_token, CapabilityIO, IOError, ReadCapability, WriteCapability,
};

/// E0006 diagnostic code (after the structured stage-code sequence E1-E4/E0005 — the capability permission family).
pub(crate) const IO_PERMISSION_CODE: DiagnosticCode = DiagnosticCode(6);

/// Read-gated builtin names (R9 data-driven table — the read capability
/// coverage face).
///
/// **net row-addition evaluation (r25/42-f M2 — capability-model-design
/// §4.1/§7 M3)**: the dependency conditions for introducing the net
/// family ① a mature effect system (12 §2.4.5 "capabilities can be viewed
/// as irrevocable effects") are in place as of this batch (Effect M1-M5
/// delivered); ② the family-taxonomy surgery surface is pinned via the
/// model layer and converged to a three-point addition (D11: enum variant +
/// gated-table row + family file). Evaluation conclusion: **rows stay
/// unchanged** — the net language surface (`(require net ...)`) and gated
/// builtins were originally slated for the late Stage 2 window; the plan
/// §5d window-check final ruling (r27): **net rows are introduced
/// trigger-based with the first network-builtin need of Stage 3** (zero
/// net corpus on the consumer face + sandboxed network restrictions +
/// the D11 three-point surgery surface already converged — deferred
/// introduction carries no structural penalty).
pub(crate) const READ_GATED: &[&str] = &["read-line", "read-int", "read-num"];

/// Write-gated builtin names (R9 data-driven table — the write capability coverage face).
pub(crate) const WRITE_GATED: &[&str] = &["print", "newline", "write-string"];

/// The program's declared I/O capability requirements (extracted from `ModuleItem::Require`).
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct IoRequirements {
    /// stdin read requirement ((require io read)).
    pub read: bool,
    /// stdout write requirement ((require io write)).
    pub write: bool,
}

impl IoRequirements {
    /// Extract the **program-entry declaration face** from the core
    /// expression sequence (authorization acquisition — the M2 correction
    /// of the 21 §4.4 composition-closure red line: count **only
    /// top-level-sequence direct Require elements**; Require inside
    /// module bodies no longer counts — module needs = metadata, not
    /// authorization acquisition; the sole source of authorization =
    /// top-level declarations of the entry program [the previous
    /// implementation recursed into Module bodies, constituting the
    /// environment-inheritance pattern — precisely the inverse of the
    /// WASI "no ambient authority" critique; fixed on the spot per the
    /// §8.4.5/R1 field-test finding]).
    pub fn from_items(items: &[ModuleItem]) -> Self {
        let mut req = IoRequirements::default();
        for item in items {
            if let ModuleItem::Require { caps, .. } = item {
                for c in caps {
                    match c {
                        Capability::IoRead => req.read = true,
                        Capability::IoWrite => req.write = true,
                    }
                }
            }
        }
        req
    }

    /// Whether the declaration is empty.
    pub fn is_empty(self) -> bool {
        !self.read && !self.write
    }

    /// Render (the CLI/CheckReport observation face).
    pub fn render(self) -> String {
        let mut parts = Vec::new();
        if self.read {
            parts.push("io:read");
        }
        if self.write {
            parts.push("io:write");
        }
        if parts.is_empty() {
            "(undeclared)".to_string()
        } else {
            parts.join(" ")
        }
    }

    /// Whether this requirement set covers another (composition-closure check: needs ⊆ authorization).
    fn covers(self, needs: Self) -> bool {
        (!needs.read || self.read) && (!needs.write || self.write)
    }

    /// Non-empty per-item rendering (module-need hints — "read" "write" "read, write").
    fn render_items(self) -> String {
        let mut parts = Vec::new();
        if self.read {
            parts.push("read");
        }
        if self.write {
            parts.push("write");
        }
        parts.join(",")
    }
}

/// Batch M second item M2 (r40) — module authorization-need collection
/// (21 §4.4: a module-body require = a needs-metadata declaration, feeding
/// the compile-time composition-closure check; **not authorization
/// acquisition** — acquisition has exactly one route, the entry top-level
/// declaration).
///
/// Returns a (module name → requirement set) sequence; collection over the
/// module-body whole tree is lenient (the E0018 position discipline is
/// carried separately by verify_require_positions — for the needs face,
/// prefer completeness over omission).
pub(crate) fn module_requirements(
    items: &[ModuleItem],
    table: &SymbolTable,
) -> Vec<(String, IoRequirements, Span)> {
    let mut out = Vec::new();
    for item in items {
        if let ModuleItem::Module {
            name,
            items: inner,
            span,
            ..
        } = item
        {
            collect_module_item_needs(*name, inner, table, &mut out, *span);
        }
    }
    out
}

/// Module-item needs collection (Require items inside module bodies +
/// recursion into nested modules — r49 D59 itemization: require is not
/// representable in expression position, so the "prefer completeness over
/// omission" needs face is carried by the item structure).
fn collect_module_item_needs(
    name: Symbol,
    items: &[ModuleItem],
    table: &SymbolTable,
    out: &mut Vec<(String, IoRequirements, Span)>,
    span: Span,
) {
    let module_name = table.name(name).to_string();
    let mut needs = IoRequirements::default();
    for item in items {
        match item {
            ModuleItem::Require { caps, .. } => {
                for c in caps {
                    match c {
                        Capability::IoRead => needs.read = true,
                        Capability::IoWrite => needs.write = true,
                    }
                }
            }
            ModuleItem::Module {
                name: inner_name,
                items: inner_items,
                span: inner_span,
                ..
            } => {
                collect_module_item_needs(*inner_name, inner_items, table, out, *inner_span);
            }
            ModuleItem::Define { .. } | ModuleItem::Expr(_) => {}
        }
    }
    if !needs.is_empty() {
        out.push((module_name, needs, span));
    }
}

// r49 D59: the collect_module_needs/collect_requirements expression-tree
// walks were retired along with require becoming unrepresentable in the
// expression domain — module needs collection moved to the item-level
// collect_module_item_needs (require exists only in item position:
// program items / module items — the structure is the full story).

/// The authorized token set (minted at the driver composition root — per
/// the program's declared requirements).
///
/// The token's linear semantics: carried by `Rc<RefCell<token>>` (the F5
/// ruling — a linear approximation under `Rc<dyn Fn>` shared capture:
/// construction stays strictly non-forgeable; `borrow_mut` exclusion =
/// exclusive access during the call). When Stage 2 gives tokens value
/// form, this approximation disappears with the language's linear types.
pub struct IoGrant {
    read: Option<Rc<RefCell<ReadCapability>>>,
    write: Option<Rc<RefCell<WriteCapability>>>,
}

impl IoGrant {
    /// Mint per requirements (requirements → tokens one-to-one — the
    /// declaration face is the authorization face; compile-time R9 already
    /// guarantees their agreement).
    pub(crate) fn from_requirements(req: IoRequirements) -> Self {
        IoGrant {
            read: req.read.then(|| Rc::new(RefCell::new(mint_read_token()))),
            write: req.write.then(|| Rc::new(RefCell::new(mint_write_token()))),
        }
    }

    /// Empty grant (an undeclared program — I/O builtins unregistered,
    /// fail-closed).
    ///
    /// Public constructor (r14): the legal entry for the host/test side to
    /// build a "no capabilities" global environment (consumed by the E1-α
    /// self-hosting Expander behavior-face tests; §11 minimal interface
    /// relaxation — this one constructor only; the token minting face
    /// stays crate-private).
    pub fn none() -> Self {
        IoGrant {
            read: None,
            write: None,
        }
    }

    /// Read token handle (consumed by the registration face — None = unauthorized, read builtins unregistered).
    pub(crate) fn read_handle(&self) -> Option<Rc<RefCell<ReadCapability>>> {
        self.read.clone()
    }

    /// Write token handle (same as above).
    pub(crate) fn write_handle(&self) -> Option<Rc<RefCell<WriteCapability>>> {
        self.write.clone()
    }

    /// Authorization-face readback (observation/testing).
    pub fn requirements(&self) -> IoRequirements {
        IoRequirements {
            read: self.read.is_some(),
            write: self.write.is_some(),
        }
    }
}

/// io family shape marker (r25/42-f capability pipeline generalization M2
/// — making the capability-model-design §7 M2 "alias-compatible" path
/// concrete).
///
/// Semantics: `IoGrant` = **the io-family instance of the family-agnostic
/// authorization form `Grant`** — `type Token = IoGrant` is the
/// trait-shaped carrier of `pub type IoGrant = Grant<IoFamily>` (the
/// model-layer family shape supplies type attribution; the pipeline-layer
/// concrete structure is frozen with zero deletions or changes — the
/// principle 27 compatibility path). The driver composition root consumes
/// authorization through this shape (D12 same-round coordination: the
/// 42-f Effect + M2 dual contact surface is anchored via cross-references
/// in the worklog).
pub struct IoFamily;

// Root-space attribution declaration (r62/107-a — the space-attribution anchor of the io family's reified entities, principle 40).
impl crate::reserved::RootSpace for IoFamily {}
impl crate::reserved::ExtensionSpace for IoFamily {}
impl crate::reserved::CapabilityDomain for IoFamily {}

impl crate::reserved::CapabilityModelFamily for IoFamily {
    type Token = IoGrant;
    fn family_name() -> &'static str {
        "io"
    }
}

/// The stdio capability implementation (the Stage 1 foundational
/// realization of the frozen contract `CapabilityIO`).
///
/// EOF convention: `read_line` returns `Err(IOError{message:"EOF"})` at
/// stdin EOF (minimal error-structure form — the frozen signature carries
/// only message; the builtin adaptation layer maps it to nil per this
/// convention, matching the Stage 0 read-line behavior).
pub struct StdCapabilityIO;

// Root-space attribution declaration (r62/107-a — the space-attribution anchor of the reified entities, principle 40).
impl crate::reserved::RootSpace for StdCapabilityIO {}
impl crate::reserved::ExtensionSpace for StdCapabilityIO {}
impl crate::reserved::CapabilityDomain for StdCapabilityIO {}

impl CapabilityIO for StdCapabilityIO {
    fn read_line(_cap: &mut ReadCapability) -> Result<String, IOError> {
        // The token occupies the signature linearly — permission already guaranteed by the construction face (compile-time R9 + minting)
        match kerf_runtime::read_line_stdin() {
            Ok(Some(s)) => Ok(s),
            Ok(None) => Err(IOError {
                message: "EOF".to_string(),
            }),
            Err(e) => Err(IOError { message: e.message }),
        }
    }

    fn write_line(_cap: &mut WriteCapability, s: &str) -> Result<(), IOError> {
        kerf_runtime::write_line_stdout(s).map_err(|e| IOError { message: e.message })
    }
}

// ---------------------------------------------------------------------------
// R9: compile-time permission verification (E0006 — all paths of the front
// pipeline)
// ---------------------------------------------------------------------------

/// Gated builtin name → required capability (data-driven table — the
/// "any pipeline node" extension face: Stage 2 adds a row per new
/// capability family).
fn required_capability(builtin_name: &str) -> Option<Capability> {
    if READ_GATED.contains(&builtin_name) {
        Some(Capability::IoRead)
    } else if WRITE_GATED.contains(&builtin_name) {
        Some(Capability::IoWrite)
    } else {
        None
    }
}

/// Hygienic base-name resolution (`name$hyg$N` → `name`; same rule as the
/// driver runtime fallback — conservative check: the suffix must be
/// non-empty and all digits).
pub(crate) fn hygienic_base(name: &str) -> &str {
    match name.rsplit_once("$hyg$") {
        Some((base, suffix))
            if !suffix.is_empty() && suffix.chars().all(|c| c.is_ascii_digit()) =>
        {
            base
        }
        _ => name,
    }
}

/// io qualified-name normalization (r39 / batch M M1): `io/local-name` →
/// `local-name` (the 22 §5.1 alignment point — qualified names and gated
/// names share the table data source: READ_GATED/WRITE_GATED carry the
/// local-name form). Non-`io/` prefixes return unchanged. Diagnostics
/// still use the original qualified form (the permission diagnostic
/// reports "io/print" rather than the bare name — the observable face of
/// the two separate gates keeps qualified-name visibility).
fn gated_name(base: &str) -> &str {
    base.strip_prefix("io/").unwrap_or(base)
}

/// R9 permission verification: every gated builtin reference in the
/// program has a corresponding declaration (13 §3.1.3 clause 3 — a
/// compile-time error, not a runtime check).
///
/// **User-takeover exemption**: a symbol the program itself defines/set!s
/// → treated as a user global (not builtin use) — the zero-false-positive
/// discipline (consistent with the typecheck conservatism contract).
#[allow(clippy::result_large_err)] // error path (carries the full diagnostic structure) — an existing driver entry-point convention
pub(crate) fn verify_io_capabilities(
    items: &[ModuleItem],
    renames: &[(String, String)],
    table: &SymbolTable,
    sm: &SourceMap,
) -> Result<(), DriverError> {
    let declared = IoRequirements::from_items(items);
    // The user-takeover set (names defined/set!s — traversal scope matches the declaration collection)
    let mut takeover: HashSet<String> = HashSet::new();
    for item in items {
        collect_takeover_item(item, table, &mut takeover);
    }
    // Gated-reference check (first violation reported immediately —
    // multi-error collection is the E0005 family's job; a single
    // permission violation blocks: fail-closed)
    // r135 / member-rename-design.md v1.2 §8 D13: the renames table rides
    // down — a renamed gated reference is caught via the reverse lookup
    for item in items {
        if let Some(diag) = verify_item_refs(item, &declared, &takeover, renames, table) {
            return Err(DriverError {
                stage: Stage::Compile,
                rendered: render_diagnostic(&diag, sm),
                diagnostic: diag,
            });
        }
    }
    Ok(())
}

/// Item-level gated-reference check (r49 D59 — Define value side / Require
/// zero payload / Module-body recursion / expression-item tree walk).
/// r135 D13-②: the renames table rides down (the renamed → underlying
/// reverse lookup at the Var face).
fn verify_item_refs(
    item: &ModuleItem,
    declared: &IoRequirements,
    takeover: &HashSet<String>,
    renames: &[(String, String)],
    table: &SymbolTable,
) -> Option<Diagnostic> {
    match item {
        ModuleItem::Define { value, .. } => verify_refs(value, declared, takeover, renames, table),
        ModuleItem::Require { .. } => None,
        ModuleItem::Module { items, .. } => items
            .iter()
            .find_map(|inner| verify_item_refs(inner, declared, takeover, renames, table)),
        ModuleItem::Expr(e) => verify_refs(e, declared, takeover, renames, table),
    }
}

/// Item-level takeover-name collection (Define names / expression tree walk / Module-body recursion).
pub(crate) fn collect_takeover_item(
    item: &ModuleItem,
    table: &SymbolTable,
    out: &mut HashSet<String>,
) {
    match item {
        ModuleItem::Define { name, value, .. } => {
            out.insert(table.name(*name).to_string());
            collect_takeover(value, table, out);
        }
        ModuleItem::Require { .. } => {}
        ModuleItem::Module { items, .. } => {
            for inner in items {
                collect_takeover_item(inner, table, out);
            }
        }
        ModuleItem::Expr(e) => collect_takeover(e, table, out),
    }
}
/// Batch M second item M2 (r40) — compile-time authorization
/// composition-closure check (21 §4.4:
/// `authorization face (program) ⊇ ⋃ authorization needs (import
/// closure)` — authorization responsibility moves up to the entry;
/// isomorphic to WASI's "capabilities are granted by the embedder,
/// components can only declare needs" — the kerf entry program = the
/// embedder, modules = components). Violation → E0006 **augmented form**
/// (carrying the missing needs and module attribution — diagnostic gain:
/// the missing cause is traceable to the module; the division of labor
/// with the basic form = the composition face checks first, with messages
/// carrying a module-need hint). fail-closed, a single violation blocks.
#[allow(clippy::result_large_err)] // error path (carries the full diagnostic structure) — same entry-point convention
pub(crate) fn verify_capability_closure(
    items: &[ModuleItem],
    table: &SymbolTable,
    sm: &SourceMap,
) -> Result<(), DriverError> {
    let declared = IoRequirements::from_items(items);
    for (module_name, needs, span) in module_requirements(items, table) {
        if !declared.covers(needs) {
            let missing = IoRequirements {
                read: needs.read && !declared.read,
                write: needs.write && !declared.write,
            };
            let items = missing.render_items();
            let diag = Diagnostic::error(
                Some(IO_PERMISSION_CODE),
                format!(
                    "insufficient capability permission: module `{}` declares io {} (module requirement metadata -- 21 §4.4 compositional closure), entry program undeclared -- please hoist to the program top level (require io {}) (import does not propagate authorization; authorization is granted only via entry declaration)",
                    module_name, items, items
                ),
                span,
            );
            return Err(DriverError {
                stage: Stage::Compile,
                rendered: render_diagnostic(&diag, sm),
                diagnostic: diag,
            });
        }
    }
    Ok(())
}

/// Reference-traversal verification (returns the first violating diagnostic).
/// r135 / member-rename-design.md v1.2 §8 D13-②: the renamed gated
/// reference's reverse lookup — a renamed head (`pr` for io's `print`)
/// misses the gated roster by name; resolving through the renames table
/// to the underlying and checking it keeps the E0006 compile-time match
/// exact (the renamed binding shares the underlying's grant token —
/// renaming grants no new capability face).
fn verify_refs(
    e: &CoreExpr,
    declared: &IoRequirements,
    takeover: &HashSet<String>,
    renames: &[(String, String)],
    table: &SymbolTable,
) -> Option<Diagnostic> {
    match e {
        CoreExpr::Var { name, span, .. } => {
            let raw = table.name(*name).to_string();
            let base = hygienic_base(&raw).to_string();
            if takeover.contains(&raw)
                || takeover.contains(&base)
                // r39 M1: after io qualified-name normalization, check
                // takeover too (user defines of either the bare or the
                // qualified name are both exempt — the zero-false-positive
                // discipline maintained)
                || takeover.contains(gated_name(&base))
            {
                return None;
            }
            match required_capability(gated_name(&base)) {
                Some(Capability::IoRead) if !declared.read => {
                    Some(permission_diag(&base, "read", "(require io read)", *span))
                }
                Some(Capability::IoWrite) if !declared.write => {
                    Some(permission_diag(&base, "write", "(require io write)", *span))
                }
                _ => {
                    // r135 D13-②: renamed gated reference — reverse lookup
                    // (roster miss by name → the underlying via the
                    // renames table → capability check with the dual-name
                    // diagnostic)
                    if let Some((renamed, underlying)) = renames.iter().find(|(r, _)| r == &base) {
                        match required_capability(gated_name(underlying)) {
                            Some(Capability::IoRead) if !declared.read => {
                                Some(permission_diag_renamed(
                                    renamed,
                                    underlying,
                                    "read",
                                    "(require io read)",
                                    *span,
                                ))
                            }
                            Some(Capability::IoWrite) if !declared.write => {
                                Some(permission_diag_renamed(
                                    renamed,
                                    underlying,
                                    "write",
                                    "(require io write)",
                                    *span,
                                ))
                            }
                            _ => None,
                        }
                    } else {
                        None
                    }
                }
            }
        }
        CoreExpr::Fn { body, .. } => verify_refs(body, declared, takeover, renames, table),
        CoreExpr::Apply { fn_expr, args, .. } => {
            verify_refs(fn_expr, declared, takeover, renames, table).or_else(|| {
                args.iter()
                    .find_map(|a| verify_refs(a, declared, takeover, renames, table))
            })
        }
        CoreExpr::If {
            cond,
            then_branch,
            else_branch,
            ..
        } => verify_refs(cond, declared, takeover, renames, table)
            .or_else(|| verify_refs(then_branch, declared, takeover, renames, table))
            .or_else(|| verify_refs(else_branch, declared, takeover, renames, table)),
        CoreExpr::Assign {
            name, value, span, ..
        } => {
            // set! target: if the name is a gated builtin and not taken
            // over → built-in state write (no such form exists — gated
            // builtins have no set! semantics); here the value side is
            // checked under the reference rule
            let _ = (name, span);
            verify_refs(value, declared, takeover, renames, table)
        }
        // r49 D59: Define/Module/Require are not in the expression domain —
        // the three arms are carried by the item-level verify_item_refs
        // (zero declaration nodes in the expression tree walk)
        CoreExpr::Let { value, body, .. } => verify_refs(value, declared, takeover, renames, table)
            .or_else(|| verify_refs(body, declared, takeover, renames, table)),
        CoreExpr::Literal { .. } => None,
        // r25/42-f: effect-subtree recursion (same scope as the item level)
        CoreExpr::Perform { effect, .. } => verify_refs(effect, declared, takeover, renames, table),
        CoreExpr::Handle {
            handler_body, body, ..
        } => verify_refs(handler_body, declared, takeover, renames, table)
            .or_else(|| verify_refs(body, declared, takeover, renames, table)),
        // r136 / 206-b (TD-033 — D13): per-arm handler bodies + the protected
        // body (same extraction scope as the single-arm form)
        CoreExpr::HandleGroup { arms, body, .. } => {
            for arm in arms {
                if let Some(d) = verify_refs(&arm.handler_body, declared, takeover, renames, table)
                {
                    return Some(d);
                }
            }
            verify_refs(body, declared, takeover, renames, table)
        }
    }
}

/// Permission diagnostic construction.
fn permission_diag(builtin: &str, cap: &str, declare_hint: &str, span: Span) -> Diagnostic {
    Diagnostic::error(
        Some(IO_PERMISSION_CODE),
        format!(
            "insufficient capability permission: `{}` requires {} capability -- program undeclared {}(tokenless I/O calls are compile-time errors)",
            builtin, cap, declare_hint
        ),
        span,
    )
}

/// r135 / member-rename-design.md v1.2 §8 D13-③: the renamed gated
/// reference's permission diagnostic — dual-name form (the renamed name
/// user-visible + the underlying for attribution; renaming grants no new
/// capability face).
fn permission_diag_renamed(
    renamed: &str,
    underlying: &str,
    cap: &str,
    declare_hint: &str,
    span: Span,
) -> Diagnostic {
    Diagnostic::error(
        Some(IO_PERMISSION_CODE),
        format!(
            "insufficient capability permission: `{}` (io member {}) requires the {} capability -- rename bindings do not change capability requirements; the program does not declare {} (tokenless I/O calls are compile-time errors)",
            renamed, underlying, cap, declare_hint
        ),
        span,
    )
}

/// User-takeover name collection (expression tree walk — after r49 D59
/// define names belong to the item-level collect_takeover_item; this
/// function carries expression-domain set!s and subtrees).
pub(crate) fn collect_takeover(e: &CoreExpr, table: &SymbolTable, out: &mut HashSet<String>) {
    match e {
        CoreExpr::Assign { name, value, .. } => {
            out.insert(table.name(*name).to_string());
            collect_takeover(value, table, out);
        }
        CoreExpr::Fn { body, .. } => collect_takeover(body, table, out),
        CoreExpr::Apply { fn_expr, args, .. } => {
            collect_takeover(fn_expr, table, out);
            for a in args {
                collect_takeover(a, table, out);
            }
        }
        CoreExpr::If {
            cond,
            then_branch,
            else_branch,
            ..
        } => {
            collect_takeover(cond, table, out);
            collect_takeover(then_branch, table, out);
            collect_takeover(else_branch, table, out);
        }
        // r49 D59: Define/Module/Require are not in the expression domain —
        // moved to the item-level collect_takeover_item
        CoreExpr::Let { value, body, .. } => {
            collect_takeover(value, table, out);
            collect_takeover(body, table, out);
        }
        CoreExpr::Var { .. } | CoreExpr::Literal { .. } => {}
        // r25/42-f: effect-subtree recursion (takeover names can hide inside effect bodies — same extraction scope)
        CoreExpr::Perform { effect, .. } => collect_takeover(effect, table, out),
        CoreExpr::Handle {
            handler_body, body, ..
        } => {
            collect_takeover(handler_body, table, out);
            collect_takeover(body, table, out);
        }
        // r136 / 206-b (TD-033 — D13): per-arm handler bodies + the
        // protected body
        CoreExpr::HandleGroup { arms, body, .. } => {
            for arm in arms {
                collect_takeover(&arm.handler_body, table, out);
            }
            collect_takeover(body, table, out);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn table_with(src: &str) -> SymbolTable {
        let mut t = SymbolTable::new();
        t.intern(src);
        t
    }

    #[test]
    fn requirements_extracted_from_require_forms() {
        let req_sym = "read";
        let mut t = SymbolTable::new();
        let r = t.intern(req_sym);
        let core = vec![ModuleItem::Require {
            caps: vec![Capability::IoRead],
            span: Span::dummy(),
        }];
        let req = IoRequirements::from_items(&core);
        assert!(req.read && !req.write);
        let _ = r;
    }

    #[test]
    fn requirements_nested_in_module() {
        // M2 (r40) composition-closure correction (21 §4.4): module-body
        // require = needs metadata, **not authorization acquisition** —
        // the from_core top-level scope excludes in-module require (the
        // old behavior recursed into Module bodies = the
        // environment-inheritance pattern, precisely the inverse of the
        // WASI "no ambient authority" critique; the behavioral anchor
        // flipped by the deep-review D4 fix)
        let mut table = SymbolTable::new();
        let core = vec![ModuleItem::Module {
            name: table.intern("m"),
            imports: vec![],
            exports: vec![],
            items: vec![ModuleItem::Require {
                caps: vec![Capability::IoRead, Capability::IoWrite],
                span: Span::dummy(),
            }],
            span: Span::dummy(),
        }];
        let req = IoRequirements::from_items(&core);
        assert!(
            !req.read && !req.write,
            "require inside a module does not constitute authorization (compositional closure)"
        );
        // Needs-metadata face: module_requirements collects module m's needs
        let needs = module_requirements(&core, &table);
        assert_eq!(needs.len(), 1);
        assert_eq!(needs[0].0, "m");
        assert!(needs[0].1.read && needs[0].1.write);
    }

    #[test]
    fn undeclared_print_reference_is_e0006() {
        let src = "(print 42)";
        let mut sm = SourceMap::new();
        let fid = sm.add_file("t.krf", src);
        let mut t = SymbolTable::new();
        let print = t.intern("print");
        let core = vec![ModuleItem::Expr(Rc::new(CoreExpr::Var {
            name: print,
            scopes: kerf_syntax::ScopeSet::new(),
            span: Span::new(fid, 1, 6),
        }))];
        let err = verify_io_capabilities(&core, &[], &t, &sm).unwrap_err();
        assert_eq!(err.stage, Stage::Compile);
        assert_eq!(err.diagnostic.code, Some(DiagnosticCode(6)));
        assert!(err.rendered.contains("print"));
        assert!(err.rendered.contains("(require io write)"));
        assert!(err.rendered.contains("error[E0006]"));
    }

    #[test]
    fn declared_print_reference_passes() {
        let mut t = SymbolTable::new();
        let print = t.intern("print");
        let core = vec![
            ModuleItem::Require {
                caps: vec![Capability::IoWrite],
                span: Span::dummy(),
            },
            ModuleItem::Expr(Rc::new(CoreExpr::Var {
                name: print,
                scopes: kerf_syntax::ScopeSet::new(),
                span: Span::dummy(),
            })),
        ];
        let sm = SourceMap::new();
        assert!(verify_io_capabilities(&core, &[], &t, &sm).is_ok());
    }

    #[test]
    fn read_builtin_needs_read_not_write() {
        let mut t = SymbolTable::new();
        let rl = t.intern("read-line");
        let core = vec![
            ModuleItem::Require {
                caps: vec![Capability::IoWrite],
                span: Span::dummy(),
            },
            ModuleItem::Expr(Rc::new(CoreExpr::Var {
                name: rl,
                scopes: kerf_syntax::ScopeSet::new(),
                span: Span::dummy(),
            })),
        ];
        let sm = SourceMap::new();
        let err = verify_io_capabilities(&core, &[], &t, &sm).unwrap_err();
        assert!(err.rendered.contains("(require io read)"));
    }

    #[test]
    fn user_takeover_exempts_shadowed_builtin() {
        let mut t = SymbolTable::new();
        let print = t.intern("print");
        // (define print 5) + a print reference — user-takeover exemption (zero-false-positive discipline)
        let core = vec![
            ModuleItem::Define {
                name: print,
                value: Rc::new(CoreExpr::Literal {
                    value: kerf_core::LiteralValue::Int(5),
                    span: Span::dummy(),
                }),
                span: Span::dummy(),
            },
            ModuleItem::Expr(Rc::new(CoreExpr::Var {
                name: print,
                scopes: kerf_syntax::ScopeSet::new(),
                span: Span::dummy(),
            })),
        ];
        let sm = SourceMap::new();
        assert!(verify_io_capabilities(&core, &[], &t, &sm).is_ok());
    }

    #[test]
    fn alias_of_builtin_still_gated() {
        let mut t = SymbolTable::new();
        let print = t.intern("print");
        let my = t.intern("my-print");
        // (define my-print print) — the value-side Var print is not taken
        // over (what's taken over is my-print) → correctly flagged (the
        // alias does use the builtin)
        let core = vec![ModuleItem::Define {
            name: my,
            value: Rc::new(CoreExpr::Var {
                name: print,
                scopes: kerf_syntax::ScopeSet::new(),
                span: Span::dummy(),
            }),
            span: Span::dummy(),
        }];
        let sm = SourceMap::new();
        let err = verify_io_capabilities(&core, &[], &t, &sm).unwrap_err();
        assert!(err.rendered.contains("print"));
    }

    #[test]
    fn hygienic_base_resolves_gated_reference() {
        let mut t = SymbolTable::new();
        let print_hyg = t.intern("print$hyg$3");
        let core = vec![ModuleItem::Expr(Rc::new(CoreExpr::Var {
            name: print_hyg,
            scopes: kerf_syntax::ScopeSet::new(),
            span: Span::dummy(),
        }))];
        let sm = SourceMap::new();
        let err = verify_io_capabilities(&core, &[], &t, &sm).unwrap_err();
        assert!(err.rendered.contains("print"));
        // A non-digit suffix is not stripped (conservative check — same rule as the runtime fallback)
        let mut t2 = SymbolTable::new();
        let not_hyg = t2.intern("print$hyg$x");
        let core2 = vec![ModuleItem::Expr(Rc::new(CoreExpr::Var {
            name: not_hyg,
            scopes: kerf_syntax::ScopeSet::new(),
            span: Span::dummy(),
        }))];
        let sm2 = SourceMap::new();
        assert!(verify_io_capabilities(&core2, &[], &t2, &sm2).is_ok());
    }

    #[test]
    fn hygienic_base_rule() {
        assert_eq!(hygienic_base("plain"), "plain");
        assert_eq!(hygienic_base("print$hyg$3"), "print");
        assert_eq!(hygienic_base("print$hyg$x"), "print$hyg$x");
        assert_eq!(hygienic_base("print$hyg$"), "print$hyg$");
    }

    #[test]
    fn requirements_render() {
        assert_eq!(
            IoRequirements {
                read: true,
                write: false
            }
            .render(),
            "io:read"
        );
        assert_eq!(IoRequirements::default().render(), "(undeclared)");
    }

    #[test]
    fn grant_mints_only_declared() {
        let g = IoGrant::from_requirements(IoRequirements {
            read: true,
            write: false,
        });
        assert!(g.read_handle().is_some());
        assert!(g.write_handle().is_none());
        assert_eq!(g.requirements().render(), "io:read");
        let none = IoGrant::none();
        assert!(none.read_handle().is_none() && none.write_handle().is_none());
    }

    #[test]
    fn std_io_write_line_roundtrip() {
        let mut cap = mint_write_token();
        assert!(<StdCapabilityIO as CapabilityIO>::write_line(&mut cap, "").is_ok());
    }

    #[test]
    fn gated_tables_are_disjoint() {
        for r in READ_GATED {
            assert!(!WRITE_GATED.contains(r));
            assert_eq!(required_capability(r), Some(Capability::IoRead));
        }
        for w in WRITE_GATED {
            assert_eq!(required_capability(w), Some(Capability::IoWrite));
        }
        assert_eq!(required_capability("cons"), None);
        let _ = table_with("x");
    }
}

// ---- r25/42-f capability pipeline generalization M2 (capability-model-design §7 M2) ----

/// io family authorization form homing: the `IoFamily` shape satisfies the
/// model-family trait (the io instance of the family-agnostic `Grant` — a
/// machine check of the alias-compatible semantics; the M2 acceptance
/// criterion "zero breakage (zero changes to existing tests)" is carried by
/// this group not touching existing assertions).
#[test]
fn io_family_grant_satisfies_model_family() {
    use crate::reserved::CapabilityModelFamily;
    assert_eq!(IoFamily::family_name(), "io");
    // The Token associated type = IoGrant (the pipeline-layer concrete
    // structure) — a type-level alias-compatibility proof (fn-pointer
    // form anchoring the associated-type equation)
    fn token_of<F: CapabilityModelFamily>() -> fn(&F::Token) {
        fn ptr<T>(_: &T) {}
        ptr::<F::Token>
    }
    let grant_fn: fn(&IoGrant) = token_of::<IoFamily>();
    let g = IoGrant::none();
    grant_fn(&g);
    // Authorization-face readback consumed via the family shape (same scope as the composition root — the observation face does not split)
    assert!(!g.requirements().read);
    assert!(!g.requirements().write);
}

/// net row-addition evaluation-face assertions: the gated table keeps two
/// families (read/write) — zero rows added in this batch (the machine
/// anchor of the evaluation-conclusion note — the READ_GATED trailing
/// note; the net introduction window = late Stage 2, surgery surface the
/// three-point addition D11).
#[test]
fn net_gate_rows_unchanged_in_42f() {
    assert_eq!(READ_GATED.len(), 3);
    assert_eq!(WRITE_GATED.len(), 3);
    assert_eq!(required_capability("connect"), None);
    assert_eq!(required_capability("listen"), None);
}

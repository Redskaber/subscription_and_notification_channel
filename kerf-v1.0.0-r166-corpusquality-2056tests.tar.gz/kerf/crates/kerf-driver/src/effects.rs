//! Compiler-internal effect system (r8 batch D — D1: 12-roadmap §2.4.3
//! Stage 1 "introduced for real (compiler-internal)", **not entering
//! language semantics**).
//!
//! **Architecture** (the two-layer API of the interface-contract-review F1
//! ruling):
//! - **typed escape layer** (`handle_escape` / `perform_escape`): one-shot
//!   escape (one-shot escape / shallow handler) — `perform_escape::<T>(
//!   payload)` unwinds from any nesting depth up to the nearest
//!   `handle_escape::<T>` boundary, **zero signature pollution** (the
//!   mechanical realization of "capability at any pipeline node" — deep
//!   positions trigger without threading through signatures);
//! - **frozen-contract layer** (`InternalEffectSystem`): the real
//!   implementation of the reserved.rs `EffectSystem` P3 shape (the same
//!   signature made semantic-concrete; together with the Probe tests it
//!   doubly evidences that the contract is implementable).
//!
//! **Mechanism**: thread-local handler depth + `catch_unwind`/
//! `resume_unwind` payload escape (std-only, the zero-external-dependency
//! constraint preserved). The private payload type `EffectUnwind` is the
//! panic hook's discrimination marker — effect escapes **print no panic
//! noise** (payload-type discrimination; only effect payloads are
//! suppressed; real panics are reported as usual).
//!
//! **Semantic boundary** (consistent with the linked ruling in
//! multi-error-recovery-design §4):
//! - compile-time error recovery (expander form level) = control flow,
//!   **not an effect** (§11 interface isolation — compiler-internal
//!   control flow is not exposed to the language semantic face; the
//!   K2/r36 deep-review re-check maintains: compile-time recovery and
//!   language-level effects stay in separate domains);
//! - this system's consumption face = **runtime/toolchain** cross-nesting
//!   escapes: `kerf test`'s test-case short-circuiting and error recovery
//!   (failure at any depth inside a case → boundary capture → the next
//!   case keeps running);
//! - multiple resumption is not implemented in this internal layer
//!   (language-level resumption is already carried by the VM continuation
//!   four-element form — r25 M5; this layer keeps one-shot escape
//!   semantics);
//! - the VM frame's `ext1` slot is already activated by language-level
//!   effects (r25 M5 — `Option<Rc<HandlerFrame>>` carries the
//!   three-prototype frame orchestration T/H/B + trampoline; this Rust
//!   layer's one-shot escape still serves compile-time recovery; the two
//!   layers coexist in separate domains).
//!
//! **Build constraint**: this mechanism requires the unwind profile (no
//! `panic = "abort"` configuration repo-wide — verified; if an abort
//! configuration is introduced in the future, this module must be
//! refactored first).

use std::any::Any;
use std::cell::Cell;
use std::panic::{catch_unwind, resume_unwind, set_hook, take_hook, AssertUnwindSafe};
use std::rc::Rc;

use kerf_vm::Value;

use crate::reserved::{Effect, EffectFamily, EffectSystem};

// ---------------------------------------------------------------------------
// 1. Typed one-shot escape layer (compiler-internal machinery — the carrier
// of "any pipeline node")
// ---------------------------------------------------------------------------

/// Effect-escape payload wrapper (**private marker type** — the panic hook
/// uses it to discriminate effect escapes and suppress noise printing;
/// constructed only in this module, so real panics can never be swallowed
/// by mistake).
struct EffectUnwind(Box<dyn Any + Send>);

thread_local! {
    /// Handler depth (0 = no escape boundary on the current thread).
    static HANDLER_DEPTH: Cell<u64> = const { Cell::new(0) };
}

/// Depth guard (Drop-safe — decremented correctly on both the escape and panic paths).
struct DepthGuard;

impl DepthGuard {
    fn install() -> Self {
        HANDLER_DEPTH.with(|d| d.set(d.get() + 1));
        DepthGuard
    }
}

impl Drop for DepthGuard {
    fn drop(&mut self) {
        HANDLER_DEPTH.with(|d| d.set(d.get() - 1));
    }
}

/// Install a one-shot escape boundary and run the computation: any
/// `perform_escape::<T>` during it unwinds from **any nesting depth** up
/// to here.
///
/// Returns `Ok(computation result)`; returning `Err(payload)` = the
/// T-typed effect captured by this boundary. Payloads of other types
/// (effects of an outer type, or a real panic) are rethrown as-is
/// (nearest-match semantics — an inner same-type boundary necessarily
/// captures first).
pub fn handle_escape<R, T: Any + Send>(computation: impl FnOnce() -> R) -> Result<R, T> {
    let _guard = DepthGuard::install();
    match catch_unwind(AssertUnwindSafe(computation)) {
        Ok(v) => Ok(v),
        Err(payload) => match payload.downcast::<EffectUnwind>() {
            Ok(inner) => match inner.0.downcast::<T>() {
                Ok(t) => Err(*t),
                // Effect payload of another type: re-wrapped and rethrown (the outer boundary takes over)
                Err(other) => {
                    resume_unwind(Box::new(EffectUnwind(other)));
                }
            },
            // Real panic: rethrown as-is (not swallowed, not altered — error > silence, §2.3-4)
            Err(real) => resume_unwind(real),
        },
    }
}

/// Perform a one-shot effect: unwind from the current call depth to the
/// nearest `handle_escape::<T>` boundary (with no matching boundary,
/// terminate with a clear message — no opaque-payload panic).
///
/// **Does not return** (diverges) — one-shot escape has no resumption
/// continuation (language-level resumption is already carried by VM
/// continuation values — r25 M5; this internal layer keeps diverging
/// semantics).
pub fn perform_escape<T: Any + Send>(payload: T) -> ! {
    let has_handler = HANDLER_DEPTH.with(|d| d.get() > 0);
    if !has_handler {
        // No boundary at all: clear termination (isomorphic to OCaml's
        // unhandled-exception semantics — "effect escape without a
        // handler" is a programmer error and must be readable and locatable)
        panic!(
            "effect escape with no handler (perform_escape at depth 0 call) -- payload type {}",
            std::any::type_name::<T>()
        );
    }
    resume_unwind(Box::new(EffectUnwind(Box::new(payload))))
}

// ---------------------------------------------------------------------------
// 2. Frozen-contract layer (the real implementation of the reserved.rs
// EffectSystem P3 shape)
// ---------------------------------------------------------------------------

/// Value effect family (concretization of the frozen contract — `Result = Value`; the P3 shape concretized with Value).
pub struct ValueEffectFamily;

// Root-space attribution declaration (r62/107-a — the space-attribution anchor of the effect family's reified entities, principle 40).
impl crate::reserved::RootSpace for ValueEffectFamily {}
impl crate::reserved::ExtensionSpace for ValueEffectFamily {}
impl crate::reserved::EffectDomain for ValueEffectFamily {}

impl EffectFamily for ValueEffectFamily {
    type Result = Value;
}

/// Value effect (payload = a kerf Value — a P3 shape constraint).
pub struct ValueEffect {
    /// Effect payload (Str round-trips losslessly; scalars marshal via
    /// rendering — an F1 adaptation-layer cost, eliminated when Stage 2
    /// refines generic associated types).
    pub payload: Value,
}

impl crate::reserved::RootSpace for ValueEffect {}
impl crate::reserved::ExtensionSpace for ValueEffect {}
impl crate::reserved::EffectDomain for ValueEffect {}

impl Effect for ValueEffect {
    type Family = ValueEffectFamily;
}

/// Value handler (a function payload → result value).
pub struct ValueHandler {
    /// Handler function (`Fn` shared — a handler can be reused across boundaries).
    pub f: Rc<dyn Fn(Value) -> Value>,
}

/// Internal effect system (the real implementation of the frozen contract
/// — together with the Probe implementation tests it doubly evidences the
/// contract is implementable: Probe proves the shape compiles; this type
/// proves the semantics can be carried).
///
/// Payload marshalling: Value is stringified via `payload_to_sendable`
/// (unwind payloads must be `Send`, but `Value` contains `Rc` and is not
/// Send — the F1-ruled adaptation cost); the handler receives the
/// `Value::Str` form.
pub struct InternalEffectSystem;

impl InternalEffectSystem {
    /// Value → Send payload marshalling (Str lossless; scalars rendered;
    /// composites via type name — the marshalling capability boundary is
    /// already declared in the docs).
    fn payload_to_sendable(v: &Value) -> String {
        match v {
            Value::Str(s) => s.to_string(),
            Value::Int(i) => i.to_string(),
            Value::Float(f) => f.to_string(),
            Value::Bool(b) => b.to_string(),
            Value::Nil => "nil".to_string(),
            Value::Unit => "unit".to_string(),
            Value::Symbol(s) => s.to_string(),
            other => format!("<{}>", other.type_name()),
        }
    }
}

// Root-space attribution declaration (r62/107-a — the space-attribution anchor of the internal effect system's reified entities).
impl crate::reserved::RootSpace for InternalEffectSystem {}
impl crate::reserved::ExtensionSpace for InternalEffectSystem {}
impl crate::reserved::EffectDomain for InternalEffectSystem {}

impl EffectSystem for InternalEffectSystem {
    type Effect = ValueEffect;
    type Handler = ValueHandler;
    /// No resumption continuation under one-shot escape semantics (a P3
    /// blank — concretized when Stage 2 introduces the language level; the
    /// associated-type change then is an in-contract evolution).
    type Continuation = ();

    fn perform(&self, effect: Self::Effect) -> Value {
        // Marshal into a Send payload and escape; the nearest ValueHandler
        // boundary takes over and returns the handling result (this method's
        // call site is treated as non-returning — one-shot escape)
        perform_escape(ValueEffectSendable(Self::payload_to_sendable(
            &effect.payload,
        )))
    }

    fn handle(&self, handler: Self::Handler, computation: impl FnOnce() -> Value) -> Value {
        match handle_escape::<Value, ValueEffectSendable>(computation) {
            Ok(v) => v,
            Err(payload) => {
                // Payload marshalled back into a Value (Str form — the F1 adaptation layer's round-trip cost)
                (handler.f)(Value::Str(Rc::from(payload.0.as_str())))
            }
        }
    }
}

/// The Send carrier for frozen-contract payloads (the marshalled string — see `payload_to_sendable`).
struct ValueEffectSendable(String);

// ---------------------------------------------------------------------------
// 3. panic hook filtering (zero noise for effect escapes — private-type
// discrimination)
// ---------------------------------------------------------------------------

/// Install the global hook filter (once per process; idempotent).
///
/// Discrimination rule: payload is `EffectUnwind` → suppress printing
/// (effect control flow, not an error); otherwise → chain back to the
/// previous hook (real panics are reported as usual). The private type
/// guarantees the discrimination is unforgeable — user panics can never be
/// swallowed by mistake.
static HOOK_INSTALLED: std::sync::Once = std::sync::Once::new();

pub(crate) fn ensure_hook_installed() {
    HOOK_INSTALLED.call_once(|| {
        // Chained replacement: the previous hook is kept (real panics
        // reported as usual); effect-escape payloads (private-type
        // discrimination — unforgeable) are silently suppressed
        let prev = take_hook();
        set_hook(Box::new(move |info| {
            if info.payload().downcast_ref::<EffectUnwind>().is_some() {
                // Effect-escape payload: control flow, not an error — no printing
                return;
            }
            prev(info);
        }));
    });
}

#[cfg(test)]
mod tests {
    use super::*;

    fn install() {
        ensure_hook_installed();
    }

    #[test]
    fn handle_returns_computation_result() {
        install();
        let r = handle_escape::<i32, String>(|| 42);
        assert_eq!(r, Ok(42));
    }

    #[test]
    fn perform_unwinds_to_nearest_boundary() {
        install();
        let out = handle_escape::<i64, String>(|| {
            // Escape from three levels of nesting deep — zero signature pollution (inner closure signatures never mention effects)
            fn level3() -> i64 {
                perform_escape::<String>(String::from("depth escape"));
            }
            fn level2() -> i64 {
                level3()
            }
            fn level1() -> i64 {
                level2()
            }
            level1()
        });
        assert_eq!(out, Err(String::from("depth escape")));
    }

    #[test]
    fn nearest_matching_boundary_wins() {
        install();
        // The inner String boundary captures the String effect; the outer u32 boundary stays intact
        let inner_caught = handle_escape::<bool, u32>(|| {
            let caught = handle_escape::<i64, String>(|| {
                perform_escape::<String>(String::from("inner"));
            });
            caught.is_err()
        });
        // Ok(true) = inner captured and the outer never triggered; Err = the outer was pierced (violating nearest-match)
        assert!(matches!(inner_caught, Ok(true)));
    }

    #[test]
    fn outer_boundary_receives_non_local_payload() {
        install();
        // The inner u32 boundary does not match the String payload → rethrown up to the outer String boundary
        let outer = handle_escape::<(), String>(|| {
            let _inner_saw_it = handle_escape::<(), u32>(|| {
                perform_escape::<String>(String::from("pierce through"));
            });
            unreachable!("inner boundary mismatch String, should not reach here")
        });
        assert_eq!(outer, Err(String::from("pierce through")));
    }

    #[test]
    fn payload_keeps_type_fidelity() {
        install();
        #[derive(Debug, PartialEq)]
        struct Case {
            id: u32,
            detail: String,
        }
        let r = handle_escape::<(), Case>(|| {
            perform_escape::<Case>(Case {
                id: 7,
                detail: "payload fidelity".into(),
            })
        });
        assert_eq!(
            r,
            Err(Case {
                id: 7,
                detail: "payload fidelity".into()
            })
        );
    }

    #[test]
    fn multiple_payload_types_coexist() {
        install();
        // Within one computation, differently-typed effects dispatch to the nearest same-type boundary
        let r = handle_escape::<(), &'static str>(|| {
            let _ = handle_escape::<(), i64>(|| perform_escape::<i64>(99));
            perform_escape::<&'static str>("str payload")
        });
        assert_eq!(r, Err("str payload"));
    }

    #[test]
    #[should_panic(expected = "effect escape with no handler")]
    fn perform_without_boundary_terminates_clearly() {
        install();
        perform_escape::<String>(String::from("no boundary"));
    }

    #[test]
    fn real_panics_pass_through_boundary() {
        install();
        // A real panic pierces the effect boundary (not swallowed) — asserted by the outer catch_unwind
        let caught = catch_unwind(AssertUnwindSafe(|| {
            let _ = handle_escape::<(), String>(|| {
                panic!("real panic");
            });
        }));
        assert!(
            caught.is_err(),
            "real panic must pierce through effect boundary"
        );
    }

    #[test]
    fn frozen_contract_handle_computation_ok() {
        install();
        let sys = InternalEffectSystem;
        let v = sys.handle(
            ValueHandler {
                f: Rc::new(|v| match v {
                    Value::Str(s) => Value::Str(Rc::from(format!("already handle: {}", s))),
                    other => other,
                }),
            },
            || Value::Int(42),
        );
        assert!(matches!(v, Value::Int(42)));
    }

    #[test]
    fn frozen_contract_perform_unwinds_to_handle() {
        install();
        let sys = InternalEffectSystem;
        let v = sys.handle(
            ValueHandler {
                f: Rc::new(|v| match v {
                    Value::Str(s) => Value::Str(Rc::from(format!("effect already handled: {}", s))),
                    other => other,
                }),
            },
            || {
                // Frozen-contract perform: triggered from deep inside nested closures (no signature pollution)
                fn deep(sys: &InternalEffectSystem) -> Value {
                    sys.perform(ValueEffect {
                        payload: Value::Str(Rc::from("abort signal")),
                    })
                }
                deep(&sys)
            },
        );
        match v {
            Value::Str(s) => assert_eq!(&*s, "effect already handled: abort signal"),
            other => panic!(
                "handler should receive a Str payload, got {:?}",
                other.type_name()
            ),
        }
    }

    #[test]
    fn frozen_contract_nested_boundaries() {
        install();
        let sys = InternalEffectSystem;
        // Outer marks +1, inner marks +2; the effect is consumed by the inner handler
        let outer_hits = Rc::new(std::cell::Cell::new(0u32));
        let inner_hits = Rc::new(std::cell::Cell::new(0u32));
        let o = Rc::clone(&outer_hits);
        let i = Rc::clone(&inner_hits);
        let v = sys.handle(
            ValueHandler {
                f: Rc::new(move |v| {
                    o.set(o.get() + 1);
                    v
                }),
            },
            || {
                sys.handle(
                    ValueHandler {
                        f: Rc::new(move |_v| {
                            i.set(i.get() + 1);
                            Value::Int(7)
                        }),
                    },
                    || {
                        sys.perform(ValueEffect {
                            payload: Value::Str(Rc::from("inner")),
                        })
                    },
                )
            },
        );
        assert!(matches!(v, Value::Int(7)));
        assert_eq!(
            inner_hits.get(),
            1,
            "inner handler should consume exactly once"
        );
        assert_eq!(outer_hits.get(), 0, "outer handler not should by trigger");
    }

    #[test]
    fn handler_depth_recovers_after_escape() {
        install();
        // After an escape the depth is correctly decremented (Drop guard) — subsequent boundaries work normally
        let first = handle_escape::<(), u8>(|| perform_escape::<u8>(1));
        assert_eq!(first, Err(1));
        let second = handle_escape::<(), u8>(|| perform_escape::<u8>(2));
        assert_eq!(second, Err(2));
    }
}

//! SHA-256 content hashing (Stage 1 batch C — the key source of the compilation cache).
//!
//! Design basis: [13-capability-matrix §3.1.4](../../docs/lang-design/13-capability-matrix.md)
//! `CacheKey.source_hash` comment "Stage 1: SHA-256 content addressing".
//!
//! **Zero external dependency constraint**: the workspace has no external
//! crates (a self-contained bootstrap boundary, §8.4.6 / the same family of
//! constraints that keeps LLVM out of the bootstrap chain), so SHA-256 is
//! implemented in-house per the FIPS 180-4 specification. Correctness is
//! anchored to standard test vectors (tests in this file plus re-verification
//! in tests/v0/stage1/plan/cache_tests.rs).
//!
//! Truncation basis: the hash field of `CacheKey`'s frozen signature is
//! `u64` (Stage 0 frozen, immutable) — take the first 8 bytes of the digest,
//! big-endian. The birthday-collision bound of 64-bit content addressing is
//! ~2^32 entries; for a single-process compilation cache (thousands of
//! entries) the false-collision probability is < 10^-9 (engineering-negligible;
//! re-evaluate when Stage 2 query-based incremental compilation upgrades the
//! key shape).

/// SHA-256 compression function round constants (FIPS 180-4 §4.2.2).
const K: [u32; 64] = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
];

/// SHA-256 single-block compression (FIPS 180-4 §6.2.2).
fn compress(state: &mut [u32; 8], block: &[u8]) {
    debug_assert_eq!(block.len(), 64);
    let mut w = [0u32; 64];
    for (i, word) in w.iter_mut().take(16).enumerate() {
        *word = u32::from_be_bytes([
            block[i * 4],
            block[i * 4 + 1],
            block[i * 4 + 2],
            block[i * 4 + 3],
        ]);
    }
    for i in 16..64 {
        let s0 = w[i - 15].rotate_right(7) ^ w[i - 15].rotate_right(18) ^ (w[i - 15] >> 3);
        let s1 = w[i - 2].rotate_right(17) ^ w[i - 2].rotate_right(19) ^ (w[i - 2] >> 10);
        w[i] = w[i - 16]
            .wrapping_add(s0)
            .wrapping_add(w[i - 7])
            .wrapping_add(s1);
    }
    let [mut a, mut b, mut c, mut d, mut e, mut f, mut g, mut h] = *state;
    for i in 0..64 {
        let s1 = e.rotate_right(6) ^ e.rotate_right(11) ^ e.rotate_right(25);
        let ch = (e & f) ^ ((!e) & g);
        let t1 = h
            .wrapping_add(s1)
            .wrapping_add(ch)
            .wrapping_add(K[i])
            .wrapping_add(w[i]);
        let s0 = a.rotate_right(2) ^ a.rotate_right(13) ^ a.rotate_right(22);
        let maj = (a & b) ^ (a & c) ^ (b & c);
        let t2 = s0.wrapping_add(maj);
        h = g;
        g = f;
        f = e;
        e = d.wrapping_add(t1);
        d = c;
        c = b;
        b = a;
        a = t1.wrapping_add(t2);
    }
    state[0] = state[0].wrapping_add(a);
    state[1] = state[1].wrapping_add(b);
    state[2] = state[2].wrapping_add(c);
    state[3] = state[3].wrapping_add(d);
    state[4] = state[4].wrapping_add(e);
    state[5] = state[5].wrapping_add(f);
    state[6] = state[6].wrapping_add(g);
    state[7] = state[7].wrapping_add(h);
}

/// Computes the SHA-256 digest (32 bytes).
pub fn sha256(input: &[u8]) -> [u8; 32] {
    let mut state: [u32; 8] = [
        0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab,
        0x5be0cd19,
    ];
    // Padding: 0x80 + zeros + 8-byte big-endian bit length (FIPS 180-4 §5.1.1)
    let bit_len = (input.len() as u64).wrapping_mul(8);
    let mut padded = Vec::with_capacity(input.len() + 72);
    padded.extend_from_slice(input);
    padded.push(0x80);
    while padded.len() % 64 != 56 {
        padded.push(0);
    }
    padded.extend_from_slice(&bit_len.to_be_bytes());
    for chunk in padded.as_chunks::<64>().0 {
        compress(&mut state, chunk);
    }
    let mut out = [0u8; 32];
    for (i, word) in state.iter().enumerate() {
        out[i * 4..i * 4 + 4].copy_from_slice(&word.to_be_bytes());
    }
    out
}

/// Hexadecimal rendering of the digest (64 lowercase chars — diagnostic/test readable form).
pub fn sha256_hex(input: &[u8]) -> String {
    sha256(input).iter().map(|b| format!("{:02x}", b)).collect()
}

/// Content-addressed u64 (first 8 bytes of the digest, big-endian — the CacheKey frozen-field basis).
pub fn content_hash64(input: &[u8]) -> u64 {
    let digest = sha256(input);
    u64::from_be_bytes(digest[..8].try_into().expect("first 8 bytes of the digest"))
}

#[cfg(test)]
mod tests {
    use super::*;

    /// FIPS 180-4 / NIST standard test vectors (authoritative anchor — the sole criterion for implementation correctness).
    #[test]
    fn sha256_standard_vectors() {
        assert_eq!(
            sha256_hex(b""),
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        );
        assert_eq!(
            sha256_hex(b"abc"),
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
        );
        assert_eq!(
            sha256_hex(b"abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq"),
            "248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1"
        );
        // 64-byte whole-block boundary + cross-block (multi-block padding path)
        assert_eq!(
            sha256_hex(b"abcdefghbcdefghicdefghijdefghijkefghijklfghijklmghijklmnhijklmnoijklmnopjklmnopqklmnopqrlmnopqrsmnopqrstnopqrstu"),
            "cf5b16a778af8380036ce59e7b0492370b249b11e8f07a51afac45037afee9d1"
        );
    }

    /// Determinism and discriminance (key properties of content addressing).
    #[test]
    fn content_hash64_properties() {
        assert_eq!(content_hash64(b"(+ 1 2)"), content_hash64(b"(+ 1 2)"));
        assert_ne!(content_hash64(b"(+ 1 2)"), content_hash64(b"(+ 1 3)"));
        assert_ne!(content_hash64(b""), content_hash64("\u{feff}".as_bytes()));
    }
}

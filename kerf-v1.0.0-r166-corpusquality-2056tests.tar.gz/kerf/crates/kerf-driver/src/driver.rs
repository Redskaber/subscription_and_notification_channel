//! Driver layer: full pipeline orchestration (read → expand → lower → compile → run).
//!
//! Entry points (§10.1 rule 1 free functions — the .ktf face (kerf syntax,
//! the sole face since the E6 close-out r154 / 224-a: the S-expr entry
//! family was deleted with the S-expr surface, s-expr-removal-plan §4):
//! - `compile_source`: source text → `CompileOutput` (full
//!   pipeline incl. graph IR — the entry for dump/check/CodeValue
//!   consumers, the complete outlet of the TD-015 split);
//! - `run_source`: compile front end + VM execution (production
//!   path, builds no graph IR — all three front-end stages
//!   (read/expand/compile) are self-hosted: I1 production switch 42-d);
//! - `compile_front_seed`: the seed pipeline (Rust seed target
//!   Reader + Rust Expander + Rust Compiler) — the bootstrap-loading
//!   path (P1 hard convention) and the parity oracle face of the
//!   fixpoint/two-path gates.
//!
//! Errors are unified as `DriverError`: stage label + rendered diagnostics
//! (with position excerpts, §2.2 principle 16: human-observable output is a
//! first-class citizen).

use std::cell::Cell;
use std::rc::Rc;

use kerf_compiler::{disassemble_program, BcProgram};
use kerf_core::{lower_program, CoreExpr, IrGraph, ModuleItem};
use kerf_expander::{expand_program, phase::ModuleRegistry, ExpandCtxt, ExpandError};
use kerf_reader::ReadError;
use kerf_runtime::Heap;
use kerf_span::{render_diagnostic, Diagnostic, DiagnosticCode, FileId, Severity, SourceMap, Span};
use kerf_syntax::{Keyword, ScopeSet, Stx, Symbol, SymbolTable};
use kerf_vm::{Value, VmError};

use crate::builtins::{
    builtin_sigs_with_renames, register_globals, resolve_hygiene_fallbacks, STDLIB_MODULES,
};
use crate::capability::{
    hygienic_base, verify_io_capabilities, IoGrant, IoRequirements, READ_GATED, WRITE_GATED,
};

/// Pipeline stage label.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Stage {
    Read,
    Expand,
    Compile,
    Run,
}

impl Stage {
    fn label(self) -> &'static str {
        match self {
            Stage::Read => "read",
            Stage::Expand => "expand",
            Stage::Compile => "compile",
            Stage::Run => "run",
        }
    }
}

/// Driver-layer error (stage + structured diagnostic + rendered text).
#[derive(Debug, Clone)]
pub struct DriverError {
    pub stage: Stage,
    pub diagnostic: Diagnostic,
    pub rendered: String,
}

impl std::fmt::Display for DriverError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "[{}] {}", self.stage.label(), self.rendered)
    }
}

impl DriverError {
    fn from_read(e: &ReadError, sm: &SourceMap) -> Self {
        let diag = Diagnostic::error(Some(DiagnosticCode(1)), e.message.clone(), e.span);
        DriverError {
            stage: Stage::Read,
            rendered: render_diagnostic(&diag, sm),
            diagnostic: diag,
        }
    }

    fn from_expand(e: &ExpandError, sm: &SourceMap) -> Self {
        let diag = Diagnostic::error(Some(DiagnosticCode(2)), e.message.clone(), e.span);
        DriverError {
            stage: Stage::Expand,
            rendered: render_diagnostic(&diag, sm),
            diagnostic: diag,
        }
    }

    fn from_compile(e: &kerf_compiler::CompileError, sm: &SourceMap) -> Self {
        let diag = Diagnostic::error(Some(DiagnosticCode(3)), e.message.clone(), e.span);
        DriverError {
            stage: Stage::Compile,
            rendered: render_diagnostic(&diag, sm),
            diagnostic: diag,
        }
    }

    fn from_vm(e: &VmError, sm: &SourceMap, table: &SymbolTable) -> Self {
        // E-code mapping: VM-carried codes (r25/42-f effect family
        // E0007-E0009) are used directly; None = the E0004 generic runtime
        // family (existing basis)
        let mut diag = Diagnostic::error(
            Some(DiagnosticCode(e.code.unwrap_or(4))),
            e.message.clone(),
            e.span,
        );
        for t in &e.trace {
            diag = diag.with_child(Severity::Note, "call site", t.span);
        }
        let _ = table;
        DriverError {
            stage: Stage::Run,
            rendered: render_diagnostic(&diag, sm),
            diagnostic: diag,
        }
    }
}

/// Compilation artifacts (`compile_source` output — for CLI dumps and CodeValue checking).
pub struct CompileOutput {
    /// Expanded core-expression sequence.
    pub core: Vec<ModuleItem>,
    /// Graph IR (structured form).
    pub ir: IrGraph,
    /// Bytecode program.
    pub program: BcProgram,
    /// Source map (diagnostic rendering).
    pub source_map: SourceMap,
    /// Symbol table (rendering and debugging).
    pub table: SymbolTable,
    /// Module registry bookkeeping (declare/visit/instantiate).
    pub registry: ModuleRegistry,
    /// W-level diagnostics (W1002 shadowing family / W1003 macro-name
    /// shadowing family; non-blocking observation face — the r42/S1
    /// aftermath, W1001 retired along with the old names).
    pub warnings: Vec<Diagnostic>,
}

/// Symbol rendering (handles compiler sentinels: `u32::MAX-1` = main, `u32::MAX-2` = anonymous prototype).
pub(crate) fn resolve_symbol(s: Symbol, table: &SymbolTable) -> String {
    match s.0 {
        x if x == u32::MAX - 1 => "<main>".to_string(),
        x if x == u32::MAX - 2 => "<fn>".to_string(),
        _ => table.name(s).to_string(),
    }
}

impl CompileOutput {
    /// Disassembly rendering.
    pub fn disassemble(&self) -> String {
        disassemble_program(&self.program, &|s: Symbol| resolve_symbol(s, &self.table))
    }

    /// Core-expression rendering (one line per form).
    pub fn render_core(&self) -> String {
        self.core
            .iter()
            .map(|e| e.render(&|s: Symbol| resolve_symbol(s, &self.table)))
            .collect::<Vec<_>>()
            .join("\n")
    }

    /// Source text (entry file).
    pub fn source(&self) -> &str {
        self.source_map.file(0).map(|f| &*f.src).unwrap_or("")
    }
}

/// Compile front-end artifacts (read → expand → phase bookkeeping → bytecode; **no graph IR lowering**).
///
/// TD-015 repayment: the run production path consumes this shape — `IrGraph`
/// is computed on demand only at consumers (`kerf ir` subcommand / CodeValue
/// checking / full dump) via [`compile_source`]; the production execution
/// path no longer builds it as a side effect and discards it (constant
/// overhead eliminated).
///
/// pub(crate) (B3): the self-hosting Reader loading (bootstrap module)
/// consumes the program / table / source_map fields — the artifact shape of
/// the seed pipeline.
///
/// Clone (batch C): a compilation-cache hit returns a snapshot clone
/// (cache.rs reuse-safety premise 3 — runtime state is not mutated on cache
/// entries).
#[derive(Clone)]
pub(crate) struct FrontOutput {
    /// Expanded program-item sequence (r49 D59 — the `ModuleItem` declaration layer).
    pub(crate) core: Vec<ModuleItem>,
    /// W-level diagnostics (W1002 shadowing family / W1003 macro-name
    /// shadowing family; non-blocking, collected on the compile-success
    /// path, rendered on the CLI/CheckReport observation face).
    pub(crate) warnings: Vec<Diagnostic>,
    /// Bytecode program.
    pub(crate) program: BcProgram,
    /// Source map (diagnostic rendering).
    pub(crate) source_map: SourceMap,
    /// Symbol table (rendering and debugging).
    pub(crate) table: SymbolTable,
    /// Module registry bookkeeping (declare/visit completed).
    pub(crate) registry: ModuleRegistry,
    /// r134 / member-rename-design.md v1.0 §3 D4: member-rename runtime
    /// bind pairs (renamed, underlying) staged by the injection-face
    /// derivation — `run_front` injects `globals[renamed] = the underlying's
    /// Builtin` after registration (the qualified-name registration's flat
    /// analogue). The compile face is untouched (zero CoreExpr rewriting —
    /// the E0022 reverse anchor stays exact: the renamed name is the visible
    /// flat binding, the underlying is not).
    pub(crate) member_rename_binds: Vec<(String, String)>,
    /// r137 / 207-c (ffi-language-surface-design §4/D6): the validated
    /// extern declarations (the ExternFace entries — name / param kinds /
    /// ret kind / declaration Span). Consumed by `run_front`'s runtime
    /// extern-table construction (declaration ∩ available registry ∩
    /// capability grant → `run_program_with_externs`); empty = the
    /// historical empty-table behavior identical bit for bit.
    pub(crate) extern_decls: Vec<ExternEntryDecl>,
}

/// Prelude module source (embedded at compile time — self-contained
/// artifacts, same basis as reader/expander; TD-021: the hofs user-face
/// injection carrier).
///
/// r109 / 179-a rulings 2+3 (switch window step ③ first batch): the
/// **target-syntax production artifact** (preamble.ktf) — 07 §3.2.1 step ③
/// "re-parse the compiler source with the new Reader (already switched to
/// the target-syntax version)"; the S-expr original preamble.krf was
/// retained as the parity oracle through the window and deleted by the E5
/// close-out cleanup batch (r120 / 190-a, principle 41 — the D50 lock and
/// the stage2 audits now consume preamble.ktf). Production reading = the .ktf target-Reader
/// bridge (read_source_for_bootstrap — the new Reader becomes a
/// production component for the first time; since r152 the bridge loads
/// reader.ktf itself — the Reader fixpoint); seed-path reading = the seed
/// target Reader (read_source — r6 symmetry: the seed reads fixed
/// library artifacts).
const PREAMBLE_SRC: &str = include_str!("bootstrap/preamble.ktf");
/// Prelude source file name (Span diagnostic attribution — a separate file,
/// no source-concatenation pollution).
const PREAMBLE_FILENAME: &str = "preamble.ktf";

/// r164 / 235-c (list-self-built-design.md D1/D3): the kerf-list module
/// body, self-built in kerf source — the seven fixed-arity list-domain
/// builtins (length/reverse/nth/drop/member/assoc/last-pair) migrated out
/// of the Rust seed registry (builtins.rs BuiltinFn defs) into kerf source
/// (the preamble.ktf precedent family extended to the list domain; the
/// user r164 directive "the seed side should be minimal — only what cannot
/// be implemented, the rest self-built"). `list`/`append` stay Rust (N1
/// visibility mechanism + variadic arity faces — D1/D2 boundary rulings,
/// TD-038 registered for append). Injection = the resolve_prelude_imports
/// isomorph: `import kerf_list` ⇒ this module's top-level form is merged
/// into the compilation unit after read and before expand; `import
/// kerf_prelude` ⇒ CASCADE injection (preamble + this file — the nth/drop
/// re-export domain's definition single-source, implementations NOT
/// copied into preamble.ktf; injection order = list FIRST [preamble's
/// module-header import kerf-list declares the dependency edge]).
const LIST_SRC: &str = include_str!("bootstrap/list.ktf");
/// kerf-list module body file name (Span diagnostic attribution — separate
/// file, same discipline as PREAMBLE_FILENAME).
const LIST_FILENAME: &str = "list.ktf";
/// Prelude module name (the name declared by user programs'
/// (import kerf-prelude) — the identifier character set excludes '.', so
/// the hyphenated form is used).
const PRELUDE_MODULE: &str = "kerf-prelude";

/// r164 / 235-c: kerf-list module name (the injection-trigger identifier —
/// the Stx/registration face's hyphenated form, same discipline as
/// PRELUDE_MODULE).
const LIST_MODULE: &str = "kerf-list";

/// Prelude injection decision (**seed oracle** — its role after the
/// r74/144-d production switch).
///
/// The original production implementation (TD-021 injection-trigger
/// decision + r46/67-b D47 top-level direct import extension); the
/// production decision path is now [`crate::bootstrap::build::imports_prelude`]
/// (build.krf on the VM — build-system segment, first incision; 07 §3.3
/// Stage 2→3 signal's first production proof); this Rust implementation is
/// retired as the parity oracle (checked by `build_krf_parity_tests` — the
/// three-piece switch isomorphic discipline: the seed retains the dual role
/// of bootstrap + oracle).
pub fn imports_prelude_seed(f: &Stx, table: &SymbolTable) -> bool {
    let items = match f.datum.as_list() {
        Some(l) if !l.is_empty() => l,
        // _ arm rationale: non-list / empty lists do not participate in import scanning
        _ => return false,
    };
    let head = match items[0].datum.as_symbol() {
        Some(s) => s,
        None => return false,
    };
    match table.name(head) {
        // Top-level import form (D47 — direct element at program top level):
        // kerf-prelude among the items triggers it (the `as` alias pair
        // skips two positions — same traversal as collect_import_face)
        "import" => {
            let mut i = 1;
            while i < items.len() {
                if let Some(sym) = items[i].datum.as_symbol() {
                    if table.name(sym) == "as" && i + 1 < items.len() {
                        i += 2;
                        continue;
                    }
                    if table.name(sym) == PRELUDE_MODULE {
                        return true;
                    }
                }
                i += 1;
            }
            false
        }
        "module" => imports_prelude_module(items, table),
        // _ arm rationale: non-import/module heads do not participate in scanning
        _ => false,
    }
}

/// Stx-layer module-header import scan (the original imports_prelude body —
/// D47 split for reuse; r74/144-d: seed oracle face — the production
/// decision goes through the bootstrap_build bridge calling build.krf on
/// the VM; this function is retired as the parity oracle).
/// r164 / 235-c: module-name parameterized (the imports_list_seed isomorph
/// — one scan body, two trigger identifiers; imports_prelude_seed's public
/// parity face unchanged [byte-identical decisions for kerf-prelude]).
fn imports_module_named(items: &[Stx], table: &SymbolTable, module: &str) -> bool {
    // Optional header region (import/export in order, terminated before the body — mirrors the expand_module header traversal)
    for item in items.iter().skip(2) {
        let sub = match item.datum.as_list() {
            Some(l) if !l.is_empty() => l,
            // _ arm rationale: a non-list header item = body form — header region ends
            _ => break,
        };
        let h = match sub[0].datum.as_symbol() {
            Some(s) => s,
            None => break,
        };
        match table.name(h) {
            "import" => {
                for name in &sub[1..] {
                    if let Some(sym) = name.datum.as_symbol() {
                        if table.name(sym) == module {
                            return true;
                        }
                    }
                }
                continue;
            }
            "export" => continue,
            // _ arm rationale: header region ends (body form)
            _ => break,
        }
    }
    false
}

fn imports_prelude_module(items: &[Stx], table: &SymbolTable) -> bool {
    imports_module_named(items, table, PRELUDE_MODULE)
}

/// r164 / 235-c (list-self-built-design.md D3): kerf-list injection
/// decision — seed oracle face (the imports_prelude_seed isomorph; the
/// production decision goes through the bootstrap_build bridge calling
/// build.ktf's imports-list on the VM — the same dual-path discipline).
/// Scans for `import ... kerf_list ...` at top level AND inside module
/// headers (both trigger shapes, D47's direct-import extension mirrored).
pub fn imports_list_seed(f: &Stx, table: &SymbolTable) -> bool {
    let items = match f.datum.as_list() {
        Some(l) if !l.is_empty() => l,
        // _ arm rationale: non-list / empty lists do not participate in import scanning
        _ => return false,
    };
    let head = match items[0].datum.as_symbol() {
        Some(s) => s,
        None => return false,
    };
    match table.name(head) {
        // Top-level import form (D47 — direct element at program top level):
        // kerf-list among the items triggers it (the `as` alias pair
        // skips two positions — same traversal as imports_prelude_seed)
        "import" => {
            let mut i = 1;
            while i < items.len() {
                if let Some(sym) = items[i].datum.as_symbol() {
                    if table.name(sym) == "as" && i + 1 < items.len() {
                        i += 2;
                        continue;
                    }
                    if table.name(sym) == LIST_MODULE {
                        return true;
                    }
                }
                i += 1;
            }
            false
        }
        "module" => imports_module_named(items, table, LIST_MODULE),
        // _ arm rationale: non-import/module heads do not participate in scanning
        _ => false,
    }
}

// ---------------------------------------------------------------------------
// Batch M first piece M1 (v0.6 namespace layer, r39) — compile-time
// verification of qualified names (22 §3.3 R-N3 no-fallback E0014 +
// §7 reserved domain E0015; full front path same as R9)
// ---------------------------------------------------------------------------

/// E0014: qualified name not exported (R-N3 no fallback — only the module export face is consulted).
const QUALIFIED_NOT_EXPORTED_CODE: DiagnosticCode = DiagnosticCode(14);
/// E0015: reserved-domain violation (kerf- prefix occupied by user code — 22 §7).
const RESERVED_DOMAIN_CODE: DiagnosticCode = DiagnosticCode(15);
/// Reserved-domain prefix (module identifier form — `kerf-`; 22 §7 reserved domain).
const RESERVED_PREFIX: &str = "kerf-";
/// Reserved-domain allowlist (preamble injection artifact + seven module identifier forms — used directly by M2 import).
const RESERVED_ALLOW: &[&str] = &[
    "kerf-prelude",
    "kerf-core",
    "kerf-pair",
    "kerf-list",
    "kerf-string",
    "kerf-symbol",
    "kerf-io",
    "kerf-char",
    // r138 / 208-c — TD-002 (vector-value-design.md D4): the vector
    // value-type domain's import face (five-op module — constructor and
    // predicate are N1-visible; length/ref/append are import-gated, the
    // list-domain `length`/`append` discipline).
    "kerf-vector",
];

// ---------------------------------------------------------------------------
// Batch M second piece M2 (v0.6 namespace layer, r40) — import injection
// face / aliases + capability closure + position discipline + E0016 +
// W deprecation/shadowing families (22 §8 M2 row; 20 §7 batch M row;
// 21 §4.4; deep-review D1-D9 rulings in 22 v1.3)
// ---------------------------------------------------------------------------

/// E0013: unqualified import conflict (same underlying name with different
/// bodies — r47 / 68-b D55 underlying-identity re-basing; the stdlib domain
/// is structurally conflict-free [underlying is the dispatch identity], the
/// channel is reserved for the Stage 3+ user-module window — 18 §6 code
/// point registered).
#[allow(dead_code)] // code point retained (E0013 semantic domain registered — trigger conditions belong to the user-module window)
const IMPORT_CONFLICT_CODE: DiagnosticCode = DiagnosticCode(13);
/// E0016: duplicate same-name define in a module body (22 §3.2 R-N2 fourth row).
const MODULE_DUPLICATE_CODE: DiagnosticCode = DiagnosticCode(16);
/// E0017: alias duplication (two `as` with the same name — 22 §3.5 R-N5 conflict column).
const ALIAS_DUPLICATE_CODE: DiagnosticCode = DiagnosticCode(17);
/// E0018: require position violation (legal positions = direct elements at
/// top level / in module bodies — deep-review D3 ruling: fail-closed
/// position discipline).
const REQUIRE_POSITION_CODE: DiagnosticCode = DiagnosticCode(18);
/// E0019: import of an unknown module (outside the registered allowlist —
/// deep-review D2 ruling: Clojure-require-shaped, rejected at compile time).
const UNKNOWN_IMPORT_CODE: DiagnosticCode = DiagnosticCode(19);
/// r50 / D65: E0024 selectively imported member not on the export face
/// (22 §18.3 — fail-closed + actionable: member name + module name +
/// export-face viewing guidance).
const SELECT_MEMBER_NOT_EXPORTED_CODE: DiagnosticCode = DiagnosticCode(24);
/// W1001 (introduced r40 — retired r42/S1): old-name deprecation warning
/// family. The 27 old names were removed in v0.9 (20 §7 removal-round row);
/// old-name references escalate to the E0021 compile-time error — the
/// deprecation W face disappearing is legitimate (23 §3.4 lifecycle four
/// stages: introduction v0.5 → default v0.6 → deprecation v0.7 → removal
/// v0.9, fully walked through).
/// W1002: N3 shadows N2 injected-name warning (22 §3.2 R-N2 second row —
/// recoverable but worth flagging).
const SHADOW_IMPORT_CODE: DiagnosticCode = DiagnosticCode(1002);
/// W1003: macro name shadows builtin name warning (r42 / S1 — 22 §11 D11
/// scheduled removal-round honored in the same window: macros winning is
/// the essence of the macro system [user redefinition is a legal semantic
/// scenario], but shadowing a **builtin name** is worth notifying; intent
/// is undecidable [deliberate vs accidental] → W level [notify, don't
/// block] is the only decidable position).
const MACRO_SHADOW_CODE: DiagnosticCode = DiagnosticCode(1003);

// ---------------------------------------------------------------------------
// r41 / 62-a language-form deep-review round — D10 ruling landed: E0020
// reserved-word binding ban (compile-time enforcement of the 22 §2.1 N4
// layer invariant "not a value, not referenceable, not shadowable")
// ---------------------------------------------------------------------------

/// E0020: N4 reserved words are not bindable (all 26 keywords globally
/// banned as binding names — deep review D10: before the fix `(define if
/// 5)` was legal and readable in value position (N4 invariant violated),
/// while operator position is always keyword form — **user bindings
/// silently ineffective** = the inverse of "explicit failure over silent
/// shadowing" (the kerf-prelude/E0014/E0006 family precedents all point
/// the other way). The ruling = strict reserved words (2026
/// cross-paradigm consensus: Rust/Swift keywords globally banned as
/// identifiers + Rhombus v1.0 conventional syntax same shape) — the
/// binding face (define/set!/lambda parameters/let family/define-syntax
/// macro names/module names/import as aliases/handle dual binders) is
/// explicitly rejected at compile time; quote-position `'if` data symbols
/// are unaffected (homoiconicity maintained — the N0 symbol-universe
/// layer, not the N4 syntax layer).
const RESERVED_BINDING_CODE: DiagnosticCode = DiagnosticCode(20);

/// E0021: reference to a removed old name (r42 / S1 removal round — 20 §7
/// "old-name reference = E00xx error" honored): from v0.9 the 27 old names
/// are retired (REMOVED_BUILTIN_NAMES single-source — old name → modern
/// name guidance). The diagnostic carries modern-name guidance (more
/// actionable than a bare E0004 unbound: optimal migration-period DX);
/// shadowing/takeover exemptions use the same basis as E0014 (N3 local
/// binding wins + user takeover legal — what retires is the **builtin
/// registration** face, not the symbol-universe layer).
const REMOVED_NAME_CODE: DiagnosticCode = DiagnosticCode(21);

/// E0021 keyword old-form table (r43 / E5 S2 — 22 §12 D29: after the
/// keyword switch the old forms enter the same rejection face; same shape
/// as REMOVED_BUILTIN_NAMES [old form → modern form]).
/// Takeover exemption uses the same basis (a user define of an old form =
/// a legal user variable — what retires is the N4 keyword face, not the N0
/// symbol-universe layer).
const REMOVED_KEYWORD_NAMES: &[(&str, &str)] =
    &[("lambda", "fn"), ("set!", "assign"), ("begin", "do")];

/// E0022: compile-time unbound reference (r46 / 67-b — the carrier of
/// R-N1 step 4; 22 §15 D49 ruling). Unqualified Var references and assign
/// targets are resolved at compile time: builtin registration face
/// (`register_globals` conditioned per authorization item — exactly the
/// same basis as runtime) ∪ program define face (collect_takeover) ∪
/// local bindings (Fn parameters/Let names — N3 shadowing checked before
/// global lookup). Checked after hygiene-suffix stripping (`hygienic_base`
/// — the compile-time forward shift of the same logic as runtime hygienic
/// fallback resolution). A miss → E0022 fail-closed (return on the first
/// violation — same basis as R9). Qualified names (containing `/`) do not
/// participate: E0014/E0006 semantic domains. Unauthorized gated names are
/// skipped (R9 runs first at step 2.55 — the E0006 semantic domain does not
/// erode this check). The r47 tightening leg upgrades this baseline to a
/// visible-face (face) check + carrying "which layers were consulted"
/// information (22 §15 D54 scheduling).
const UNBOUND_REF_CODE: DiagnosticCode = DiagnosticCode(22);

/// Reserved-word decision (single source = the kerf-syntax
/// `Keyword::from_name` 25-name table — Reader/expander consume the same
/// table, zero list-drift face).
fn is_reserved_word(name: &str) -> bool {
    Keyword::from_name(name).is_some()
}

/// E0020 diagnostic construction (message text shared by the Stx/CoreExpr
/// two layers — the D10 ruling rationale travels with the diagnostic:
/// 22 §2.1 invariant + silent-ineffectiveness pitfall explanation).
fn reserved_binding_diag(name: &str, span: Span, kind: &str) -> Diagnostic {
    Diagnostic::error(
        Some(RESERVED_BINDING_CODE),
        format!(
            "reserved word is not bindable: `{}` is an N4 keyword ({}) -- keywords are not values, not referenceable, not shadowable (22 §2.1); a same-named binding in operation position would be silently overridden by the keyword form, hence the explicit compile-time rejection (E0020, deep audit D10)",
            name, kind
        ),
        span,
    )
}

/// Stx-layer reserved-word binding check (**source face** — intercepts
/// before expand, covering all binding forms + define-syntax macro names
/// [no CoreExpr carrier after expansion] + import as aliases [alias
/// normalization is consumed at rewrite]; recursively penetrates
/// begin/module bodies/nested lambda/let and all other subtrees).
#[allow(clippy::result_large_err)]
fn verify_reserved_bindings_stx(
    forms: &[Stx],
    table: &SymbolTable,
    sm: &SourceMap,
) -> Result<(), DriverError> {
    for f in forms {
        if let Some(diag) = reserved_stx_diag(f, table) {
            return Err(face_err(diag, sm));
        }
    }
    Ok(())
}

/// Stx single-node binding-face check (list-head dispatch + subtree
/// recursion; non-list atoms have no binding face).
fn reserved_stx_diag(f: &Stx, table: &SymbolTable) -> Option<Diagnostic> {
    let items = match f.datum.as_list() {
        Some(l) if !l.is_empty() => l,
        // _ arm rationale: atoms / empty lists have no binding forms
        _ => return None,
    };
    let head = match items[0].datum.as_symbol() {
        Some(s) => table.name(s),
        None => "",
    };
    // Single-name binding family: define / assign / define-syntax / module
    // (r43 / E5 S2: set! → assign surface switch — head matching synced [22 §12 D20])
    match head {
        "define" | "assign" | "module" => {
            if items.len() >= 2 {
                if let Some(n) = items[1].datum.as_symbol() {
                    let name = table.name(n);
                    if is_reserved_word(name) {
                        let kind = match head {
                            "module" => "module name",
                            "assign" => "assignment target",
                            _ => "binding name",
                        };
                        return Some(reserved_binding_diag(name, items[1].span, kind));
                    }
                }
            }
        }
        // define-syntax: only the macro name (items[1]) is checked —
        // **the template subtree is the data domain** (syntax-rules
        // patterns/templates are the macro's literal data, not program
        // bindings — Stx structural traversal does not distinguish
        // template/code; recursing into it would misfire [a `(define
        // quote …)` form literal legally appears in templates]; the
        // actually instantiated expansion output is intercepted by the
        // CoreExpr-layer E0020 — defense in depth, two layers each
        // governing their own domain)
        "define-syntax" => {
            if items.len() >= 2 {
                if let Some(n) = items[1].datum.as_symbol() {
                    let name = table.name(n);
                    if is_reserved_word(name) {
                        return Some(reserved_binding_diag(name, items[1].span, "macro name"));
                    }
                }
            }
            return None;
        }
        // fn parameter list (every parameter name is a binder)
        // (r43 / E5 S2: lambda → fn surface switch — head matching synced [22 §12 D19])
        "fn" => {
            if items.len() >= 2 {
                if let Some(params) = items[1].datum.as_list() {
                    for p in params {
                        if let Some(n) = p.datum.as_symbol() {
                            let name = table.name(n);
                            if is_reserved_word(name) {
                                return Some(reserved_binding_diag(name, p.span, "fn parameter"));
                            }
                        }
                    }
                }
            }
        }
        // let-family binding pairs (the pair head is the binding name)
        "let" | "letrec" | "let*" => {
            if items.len() >= 2 {
                if let Some(bindings) = items[1].datum.as_list() {
                    for b in bindings {
                        if let Some(pair) = b.datum.as_list() {
                            if !pair.is_empty() {
                                if let Some(n) = pair[0].datum.as_symbol() {
                                    let name = table.name(n);
                                    if is_reserved_word(name) {
                                        return Some(reserved_binding_diag(
                                            name,
                                            pair[0].span,
                                            "let binding name",
                                        ));
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        // import as aliases (the symbol after the contextual marker is a
        // local binding — 22 §3.5 R-N5; alias normalization is consumed at
        // rewrite_alias_refs, no CoreExpr carrier, hence the Stx-layer
        // interception)
        "import" => {
            let mut i = 1;
            while i < items.len() {
                if let Some(s) = items[i].datum.as_symbol() {
                    if table.name(s) == "as" && i + 1 < items.len() {
                        if let Some(a) = items[i + 1].datum.as_symbol() {
                            let name = table.name(a);
                            if is_reserved_word(name) {
                                return Some(reserved_binding_diag(
                                    name,
                                    items[i + 1].span,
                                    "import alias",
                                ));
                            }
                        }
                    }
                }
                i += 1;
            }
        }
        _ => {}
    }
    // Subtree recursion (do body / module body / fn body / let body / if
    // branches / bound-value subtrees etc. — all penetrated)
    for item in items {
        if let Some(d) = reserved_stx_diag(item, table) {
            return Some(d);
        }
    }
    None
}

/// CoreExpr-layer reserved-word binding check (**macro expansion output
/// face** — defense in depth for the source-layer Stx check: binding names
/// generated by macro templates also pass E0020; after the let family
/// desugars to Fn+Apply the binding names converge onto Fn.params; the
/// handle dual binders are structurally carried in the expansion output).
#[allow(clippy::result_large_err)]
fn verify_reserved_bindings_core(
    items: &[ModuleItem],
    table: &SymbolTable,
    sm: &SourceMap,
) -> Result<(), DriverError> {
    for item in items {
        if let Some(diag) = reserved_item_diag(item, table) {
            return Err(face_err(diag, sm));
        }
    }
    Ok(())
}

/// Item-level binding-face check (r49 D59 — Define name / Module name with
/// body recursion / Require has zero binding face / expression-item tree
/// walk).
fn reserved_item_diag(item: &ModuleItem, table: &SymbolTable) -> Option<Diagnostic> {
    match item {
        ModuleItem::Define { name, span, .. } => {
            let n = table.name(*name);
            if is_reserved_word(n) {
                return Some(reserved_binding_diag(
                    n,
                    *span,
                    "binding name (expansion product)",
                ));
            }
            None
        }
        ModuleItem::Require { .. } => None,
        ModuleItem::Module {
            name, items, span, ..
        } => {
            let n = table.name(*name);
            if is_reserved_word(n) {
                return Some(reserved_binding_diag(
                    n,
                    *span,
                    "module name (expansion product)",
                ));
            }
            items.iter().find_map(|i| reserved_item_diag(i, table))
        }
        ModuleItem::Expr(e) => reserved_core_diag(e, table),
    }
}

/// CoreExpr single-node binding-face check (Fn/Assign/Handle/
/// expression-domain binders + full subtree recursion — after r49
/// Define/Module belong to the item-level reserved_item_diag).
fn reserved_core_diag(e: &CoreExpr, table: &SymbolTable) -> Option<Diagnostic> {
    match e {
        CoreExpr::Fn {
            params, body, span, ..
        } => {
            for p in params {
                let n = table.name(*p);
                if is_reserved_word(n) {
                    return Some(reserved_binding_diag(
                        n,
                        *span,
                        "fn parameter (expansion product)",
                    ));
                }
            }
            reserved_core_diag(body, table)
        }
        CoreExpr::Assign { name, span, .. } => {
            let n = table.name(*name);
            if is_reserved_word(n) {
                return Some(reserved_binding_diag(
                    n,
                    *span,
                    "assignment target (expansion product)",
                ));
            }
            None
        }
        CoreExpr::Handle {
            payload_var,
            resume_var,
            handler_body,
            body,
            span,
            ..
        } => {
            for (n, kind) in [
                (table.name(*payload_var), "handle payload binding"),
                (table.name(*resume_var), "handle resume binding"),
            ] {
                if is_reserved_word(n) {
                    return Some(reserved_binding_diag(n, *span, kind));
                }
            }
            reserved_core_diag(handler_body, table).or_else(|| reserved_core_diag(body, table))
        }
        // r136 / 206-b (TD-033 — D13): per-arm binder reserved checks +
        // recursion (same message family as the single-arm form)
        CoreExpr::HandleGroup {
            arms, body, span, ..
        } => {
            for arm in arms {
                for (n, kind) in [
                    (table.name(arm.payload_var), "handle-group payload binding"),
                    (table.name(arm.resume_var), "handle-group resume binding"),
                ] {
                    if is_reserved_word(n) {
                        return Some(reserved_binding_diag(n, *span, kind));
                    }
                }
            }
            for arm in arms {
                if let Some(d) = reserved_core_diag(&arm.handler_body, table) {
                    return Some(d);
                }
            }
            reserved_core_diag(body, table)
        }
        CoreExpr::Let { value, body, .. } => {
            reserved_core_diag(value, table).or_else(|| reserved_core_diag(body, table))
        }
        CoreExpr::Apply { fn_expr, args, .. } => reserved_core_diag(fn_expr, table)
            .or_else(|| args.iter().find_map(|a| reserved_core_diag(a, table))),
        CoreExpr::If {
            cond,
            then_branch,
            else_branch,
            ..
        } => reserved_core_diag(cond, table)
            .or_else(|| reserved_core_diag(then_branch, table))
            .or_else(|| reserved_core_diag(else_branch, table)),
        CoreExpr::Perform { effect, .. } => reserved_core_diag(effect, table),
        // Var/Literal/Require have no binding face (references and
        // declarations are not bindings — value-position reserved-word
        // references always take the unbound path once the binding ban is
        // in effect, fail-closed naturally maintained)
        _ => None,
    }
}

/// Import face collection result (Stx layer — same-shaped header-region
/// traversal as imports_prelude; 22 §3.5 R-N5 three shapes: unqualified
/// import / qualified alias / implicit gated injection).
#[derive(Debug, Default)]
pub(crate) struct ImportFace {
    /// ns-segment set of unqualified imported modules (`kerf-string` →
    /// `string` — the injected export face; after the r47 visibility
    /// tightening, injection observability = conflict/shadowing/closure +
    /// E0022/E0014 visible-face checking, four faces — deep-review D7
    /// transition-period close-out).
    pub(crate) unqualified: Vec<String>,
    /// Qualified alias mapping (alias → ns segment — `(import kerf-string
    /// as str)` → `str` → `string`; the alias is a local binding in the N3
    /// semantic position — 22 §3.5).
    pub(crate) aliases: Vec<(String, String)>,
    /// Unqualified injection face (union of the exported local names of all
    /// imported modules — the data face for E0013 conflict detection and
    /// W1002 shadowing detection).
    pub(crate) injected_names: Vec<String>,
    /// r50 / D65 member-level selective import: `(import kerf-string
    /// (append length))` — ns → selected-member local-name list (the
    /// selection subset acts on the **flat injection face**: the E0022
    /// visible face / E0013 conflict face / W face are filtered per member;
    /// qualified-name access keeps the module-level import relation
    /// [R-N3 E0014 module ∈ import-set criterion unchanged —
    /// Kotlin/Java specific-import isomorphic: selection = flat namespace
    /// hygiene, not module-relation pruning]).
    pub(crate) selected: Vec<(String, Vec<String>)>,
    /// ns set of selectively imported modules (filter by selection when
    /// deriving the injection face — fully imported modules are not in
    /// this set [full injection]).
    pub(crate) selective: std::collections::HashSet<String>,
    /// r134 / member-rename-design.md v1.0 §3 D6: member-rename entries
    /// (ns, local, renamed) — the selection list's `local as renamed`
    /// triples collected by `collect_import_items` (the S-expr face's
    /// consumer-order flat triple). Additive field — non-rename programs
    /// carry an empty vector (zero overhead).
    pub(crate) member_renames: Vec<(String, String, String)>,
    /// r135 / member-rename-design.md v1.2 §8 D14-②: parallel Span array
    /// for `member_renames` (same length and order — the selection-list
    /// element's own Span, the diagnostic-attribution anchor for the
    /// Stx-layer binding injection; the user's `use` declaration site,
    /// not the preamble's module-header import).
    pub(crate) member_rename_spans: Vec<Span>,
    /// r134 / D3-D4: derived runtime bind pairs (renamed, underlying) —
    /// staged by the flat-payload derivation pass, consumed by `run_front`
    /// (post-registration injection). Derived data (not collected).
    pub(crate) rename_binds: Vec<(String, String)>,
    /// r47 / 68-b visibility tightening leg (22 §15 D55): the **flat
    /// runtime payload face** (union of the exported underlying flat names
    /// of all imported modules + the prelude re-export margin of 7 names —
    /// the runtime ground-truth data source for E0022 visible-face checking +
    /// W1003/W1002 face-aware. Separate from `injected_names`
    /// [local names — lexical face]: local names are reachable only in
    /// qualified form (`string/append`), the flat-form ground truth =
    /// underlying (`string-append`) — the two sets coincide for the
    /// core/pair/list/io modules and diverge for string/symbol/char).
    pub(crate) flat_underlying: Vec<String>,
}

/// Stx-layer import face collection (module header-region traversal —
/// mirrors expand_module header parsing; `as` is a contextual marker, not
/// an N4 keyword — deep-review D1 ruling: zero changes to the 02 lexical
/// architecture, same shape as the Rust `use as`/Python `import as` 2026
/// convention).
///
/// Shapes: `(import kerf-string)` (unqualified) | `(import kerf-string
/// as str)` (qualified alias) | mixed `(import a as x b)` (alias pair +
/// unqualified coexisting). `as` inside an import list is always the alias
/// marker (the boundary cost of contextual semantics — a user module
/// cannot be named `as` inside an import list; qualified-name references
/// are unaffected).
/// r42 / S1 removal round — W1003 macro-name collection (22 §11 D11: a
/// define-syntax macro name identical to a builtin function name → W-level
/// notification). The sole Stx-layer carrier face: after macro expansion
/// the names vanish from CoreExpr, so this face is the sole data source of
/// W1003. The recursive list arm covers top level + module bodies (false
/// positives from `(define-syntax …)` template literals in nested lists
/// are acceptable — W level is non-blocking + zero collisions in the
/// bootstrap corpus [reader/expander bootstrap artifacts do not pass
/// through this pipeline]).
fn collect_macro_names(forms: &[Stx], table: &SymbolTable) -> Vec<(String, Span)> {
    let mut out: Vec<(String, Span)> = Vec::new();
    for f in forms {
        if let Some(items) = f.datum.as_list() {
            if items.len() >= 2 {
                let is_defsyntax = items[0]
                    .datum
                    .as_symbol()
                    .map(|s| table.name(s) == "define-syntax")
                    .unwrap_or(false);
                if is_defsyntax {
                    if let Some(name_sym) = items[1].datum.as_symbol() {
                        out.push((table.name(name_sym).to_string(), f.span));
                    }
                }
            }
            out.extend(collect_macro_names(items, table));
        }
    }
    out
}

#[allow(clippy::result_large_err)] // error path (carries the full diagnostic structure) — same entry-point convention as verify_import_face (r134: the face collection now reports selection-list shape violations)
fn collect_import_face(
    forms: &[Stx],
    table: &SymbolTable,
    sm: &SourceMap,
) -> Result<ImportFace, DriverError> {
    let mut face = ImportFace::default();
    for f in forms {
        let items = match f.datum.as_list() {
            Some(l) if !l.is_empty() => l,
            // _ arm rationale: non-list / empty lists do not participate in import scanning
            _ => continue,
        };
        let head = match items[0].datum.as_symbol() {
            Some(s) => s,
            None => continue,
        };
        match table.name(head) {
            // r46 / 67-b deep review D47: top-level import form (direct
            // element at program top level) — parsed the same as the module
            // header region (three shapes: unqualified / as alias / mixed)
            "import" => collect_import_items(items, &mut face, table, sm)?,
            "module" => {
                // The injected kerf-prelude module's **own** imports are
                // skipped (D50: a module's internal visible face ≠ the
                // importer's injection face — prelude's (import kerf-core
                // kerf-pair) serves its body-reference legality [r47
                // tightening-leg payloadization]; it does not enter the
                // program injection face [preventing W1002/E0013
                // over-expansion]; mirrors collect_warnings' structural
                // prelude exemption)
                let is_prelude = items
                    .get(1)
                    .and_then(|n| n.datum.as_symbol())
                    .map(|s| table.name(s) == PRELUDE_MODULE)
                    .unwrap_or(false);
                if is_prelude {
                    continue;
                }
                collect_module_header_imports(items, &mut face, table, sm)?;
            }
            // _ arm rationale: non-import/module heads do not participate in collection
            _ => {}
        }
    }
    // Injection-face derivation: union of the exported local names of all
    // imported modules (STLDIB_MODULES single source; r50 / D65
    // selectively imported modules filter the injection face by selected
    // members)
    for ns in &face.unqualified {
        for &(m, local, _) in STDLIB_MODULES {
            if m == ns && face_selects(&face, ns, local) {
                // r134 / member-rename-design.md v1.0 §3 D3: a renamed
                // member's binding replaces the local name's injection slot
                // (replacement semantics — E0013/W1002 lexical face)
                let injected = member_rename_of(&face.member_renames, ns, local).unwrap_or(local);
                face.injected_names.push(injected.to_string());
            }
        }
    }
    // r47 / 68-b visibility tightening leg (D55): flat runtime payload
    // derivation + prelude re-export face payloadization (D50 step ② —
    // injection-face derivation single source = the preamble export list
    // [PRELUDE_EXPORT_NAMES]; the N1 redundant names [cons/head/tail/is-*]
    // are deduplicated automatically — marginal payload = 5 HOFs
    // [module-body definition face] + nth/drop [re-exported with the same
    // underlying as kerf-list]; re-export awareness: when imported
    // alongside kerf-list, nth/drop share the same underlying and dispatch
    // body — non-conflict, exempt from E0013 [existing exempt +
    // underlying-identity double insurance])
    for ns in &face.unqualified {
        if ns == "prelude" {
            for &n in crate::builtins::PRELUDE_EXPORT_NAMES {
                if !crate::builtins::N1_CORE_NAMES.contains(&n) && face_selects(&face, ns, n) {
                    // r135 / member-rename-design.md v1.2 §8 D14: prelude
                    // rename awareness — **incremental-alias semantics**
                    // (D14-③): the renamed name **joins** the flat
                    // injection face while the local stays too (unlike
                    // the seven modules' replacement semantics — the
                    // prelude's injection face = the re-export margin,
                    // a rename adds an alias without trimming the
                    // existing visibility; the local's availability has
                    // three sources — the module-body define face [own
                    // HOFs], the N1 core face [cons/is-* re-exports],
                    // this flat face [nth/drop re-exports] — all
                    // untouched). The runtime bind goes through
                    // front_from_forms' Stx-layer injection (1.62 —
                    // `(define renamed local)` before the user forms),
                    // not run_front's builtin injection loop (a prelude
                    // member's value may be a builtin [nth/drop/cons]
                    // or a define-face closure [the five HOFs] — the
                    // injected define resolves either way).
                    match member_rename_of(&face.member_renames, "prelude", n) {
                        Some(renamed) => {
                            face.flat_underlying.push(n.to_string());
                            face.flat_underlying.push(renamed.to_string());
                            // NOTE: no rename_binds push for the prelude
                            // domain — its runtime bind goes through the
                            // Stx-layer injection alone (front_from_forms
                            // 1.62 — a second run_front injection would
                            // collide with the injected define's
                            // DefineGlobal as a duplicate-definition
                            // E0004); the HM derivation and the E0006
                            // reverse lookup are no-op for prelude
                            // members anyway (their underlyings are not
                            // in BUILTIN_SIGS / the gated rosters)
                        }
                        None => face.flat_underlying.push(n.to_string()),
                    }
                }
            }
        } else {
            for u in crate::builtins::module_flat_underlying(ns) {
                // r50 / D65: selective import filters by member underlying
                // (local name → underlying reverse lookup — the string
                // domain's local "append"/underlying "string-append"
                // mapping goes through the STDLIB_MODULES rows)
                if face_selects_underlying(&face, ns, u) {
                    // r134 / member-rename-design.md v1.0 §3 D3-D4: a renamed
                    // member's binding **replaces** the underlying's flat slot —
                    // the renamed name enters flat_underlying (the E0022 visible
                    // face) while the underlying stays out (the E0022 reverse
                    // anchor stays exact: direct underlying writes after a
                    // rename are unbound); the runtime bind (renamed → the
                    // underlying's dispatch body) is staged for run_front's
                    // post-registration injection (D4)
                    match underlying_rename_of(&face.member_renames, ns, u) {
                        Some(renamed) => {
                            face.flat_underlying.push(renamed.to_string());
                            face.rename_binds.push((renamed.to_string(), u.to_string()));
                        }
                        None => face.flat_underlying.push(u.to_string()),
                    }
                }
            }
        }
    }
    // r135 / member-rename-design.md v1.2 §8 D13-①: the N1-underlying
    // domains' renames get a dedicated derivation — io/core/pair/char's
    // `module_flat_underlying` yields nothing (their underlyings are
    // permanently N1 — the gated/predicate names are unconditionally
    // visible), so the loop above never registers their member renames;
    // the renamed binding is a fresh import-declared name and joins flat
    // (the E0022 visible face) + rename_binds (the E0006 reverse lookup,
    // the HM signature derivation, run_front's injection — an N1
    // underlying hits the builtin registry directly). The underlying's
    // N1 identity is untouched — the incremental-alias semantics (D14-③):
    // `print` stays reachable through the E0006 gate after `print as pr`.
    // Duplicate-push guard: only rows whose underlying is N1 (the
    // non-N1 domains were covered by the loop above).
    for (ns, local, renamed) in &face.member_renames {
        if ns == "prelude" {
            continue; // the prelude branch above already registered it
        }
        let underlying = STDLIB_MODULES
            .iter()
            .find(|&&(m, l, _)| m == ns.as_str() && l == local.as_str())
            .map(|&(_, _, u)| u);
        if let Some(u) = underlying {
            if crate::builtins::N1_CORE_NAMES.contains(&u) {
                face.flat_underlying.push(renamed.to_string());
                face.rename_binds.push((renamed.to_string(), u.to_string()));
            }
        }
    }
    face.flat_underlying.sort();
    face.flat_underlying.dedup();
    Ok(face)
}

/// Selective-import member decision (local-name basis — injection-face filter).
/// Full imports (not in the selective set) always inject; selective imports filter by the selected-member table.
fn face_selects(face: &ImportFace, ns: &str, local: &str) -> bool {
    if !face.selective.contains(ns) {
        return true;
    }
    face.selected
        .iter()
        .filter(|(n, _)| n == ns)
        .any(|(_, members)| members.iter().any(|m| m == local))
}

/// r134 / member-rename-design.md v1.0 §3 D6: member-rename lookup by
/// (ns, local) — the renamed binding name for a selected member, if any
/// (None = the bare member's default injection: the local name for the
/// lexical face, the underlying for the flat face).
fn member_rename_of<'a>(
    renames: &'a [(String, String, String)],
    ns: &str,
    local: &str,
) -> Option<&'a str> {
    renames
        .iter()
        .find(|(n, l, _)| n == ns && l == local)
        .map(|(_, _, r)| r.as_str())
}

/// r134 / member-rename-design.md v1.0 §3 D3: member-rename lookup by
/// (ns, underlying) — the STDLIB_MODULES row (ns, local, underlying) maps
/// the selected member's local name to the flat underlying; a rename entry
/// on that (ns, local) pair replaces the underlying's flat slot with the
/// renamed binding.
fn underlying_rename_of<'a>(
    renames: &'a [(String, String, String)],
    ns: &str,
    underlying: &str,
) -> Option<&'a str> {
    renames
        .iter()
        .find(|(n, l, _)| {
            n == ns
                && STDLIB_MODULES
                    .iter()
                    .any(|&(mn, ml, mu)| mn == n.as_str() && ml == l.as_str() && mu == underlying)
        })
        .map(|(_, _, r)| r.as_str())
}

/// Selective-import member decision (underlying basis — flat payload
/// filter; local name → underlying reverse lookup via the STDLIB_MODULES
/// row mapping).
fn face_selects_underlying(face: &ImportFace, ns: &str, underlying: &str) -> bool {
    if !face.selective.contains(ns) {
        return true;
    }
    face.selected
        .iter()
        .filter(|(n, _)| n == ns)
        .any(|(_, members)| {
            members.iter().any(|m| {
                STDLIB_MODULES
                    .iter()
                    .any(|&(mn, ml, mu)| mn == ns && ml == m && mu == underlying)
            })
        })
}

/// Import item-sequence parsing (shared by top level and module headers —
/// D47 split for reuse).
///
/// Shapes: `(import kerf-string)` (unqualified) | `(import kerf-string
/// as str)` (qualified alias) | mixed `(import a as x b)`. `as` inside an
/// import list is always the alias marker (contextual semantics —
/// deep-review D1 ruling). r134 / member-rename-design.md v1.0 §3 D1:
/// the selection list accepts bare member symbols and the rename triple
/// `local as renamed` (the flat triple — the import family's contextual-as
/// convention, consumer order); shape discipline is fail-closed (§2.3):
/// a leading `as`, an `as` without a right operand, or a non-symbol
/// operand after `as` are dedicated errors (the driver-level enforcement
/// face — top level and module headers share this single point).
#[allow(clippy::result_large_err)] // error path (carries the full diagnostic structure) — same entry-point convention (r134: the shape-enforcement face)
fn collect_import_items(
    items: &[Stx],
    face: &mut ImportFace,
    table: &SymbolTable,
    sm: &SourceMap,
) -> Result<(), DriverError> {
    let mut i = 1;
    while i < items.len() {
        let sym = match items[i].datum.as_symbol() {
            Some(s) => s,
            // _ arm rationale: non-symbol items are left to the E0019 allowlist-validation stage to report
            None => {
                i += 1;
                continue;
            }
        };
        let name = table.name(sym).to_string();
        // Look ahead two symbols: second position as + third position alias
        // → register the alias pair and skip three positions
        let mut skip = 1;
        let mut base_ns = import_target_ns(&name);
        if i + 2 < items.len() {
            let next_is_as = items[i + 1]
                .datum
                .as_symbol()
                .map(|s| table.name(s) == "as")
                .unwrap_or(false);
            if next_is_as {
                if let Some(alias_sym) = items[i + 2].datum.as_symbol() {
                    face.aliases
                        .push((table.name(alias_sym).to_string(), import_target_ns(&name)));
                }
                base_ns = import_target_ns(&name);
                skip = 3;
            }
        }
        // r50 / D65 selective import: the list argument following the
        // module name (or as alias pair) = the member selection subset
        // (`(import kerf-string (append length))` — symbols inside the
        // list = selected member local names; qualified-name access
        // unchanged [module-level relation]).
        // r134 / member-rename-design.md v1.0 §3 D1: the member loop walks
        // the flat selection list — bare symbols push (local, None); a
        // `local as renamed` triple registers the rename entry
        // (ns, local, renamed) alongside the bare local in `selected`
        // (E0024 checks by local name — D3; the rename info is carried
        // separately in `member_renames`, D6). Shape violations are
        // fail-closed with dedicated faces (§2.3 — report-don't-stay-silent).
        if i + skip < items.len() {
            if let Some(sel) = items[i + skip].datum.as_list() {
                let mut members = Vec::with_capacity(sel.len());
                let mut j = 0;
                while j < sel.len() {
                    let msym = match sel[j].datum.as_symbol() {
                        Some(s) => s,
                        None => {
                            // _ arm rationale: a non-symbol member inside the
                            // selection list = a shape violation (the S-expr
                            // face's bare-name discipline — the module-header
                            // face mirrors this via the expander's E0002
                            // pre-check; the top-level face has no upstream
                            // check, so this is its sole carrier). Code = the
                            // E0002 import-form shape family (the expander's
                            // `import item must be a symbol` same family — r134)
                            let diag = Diagnostic::error(
                                Some(DiagnosticCode(2)),
                                "select list members must be symbols((import module (member...)) -- member rename has the form(name as alias)triple)"
                                    .to_string(),
                                sel[j].span,
                            );
                            return Err(face_err(diag, sm));
                        }
                    };
                    let mname = table.name(msym).to_string();
                    if mname == "as" {
                        // A leading `as` (no member name before it) =
                        // fail-closed (D1 — the rename triple needs its
                        // left operand; E0002 import-form shape family)
                        let diag = Diagnostic::error(
                            Some(DiagnosticCode(2)),
                            "select list member names cannot be as(member rename missing left operand -- form: `name as alias`)"
                                .to_string(),
                            sel[j].span,
                        );
                        return Err(face_err(diag, sm));
                    }
                    // Rename triple: `local as renamed` (the contextual-as
                    // convention — identical criterion to the top-level
                    // alias pair; consumer order D1/D9)
                    let next_is_as = j + 1 < sel.len()
                        && sel[j + 1]
                            .datum
                            .as_symbol()
                            .map(|s| table.name(s) == "as")
                            .unwrap_or(false);
                    if next_is_as {
                        // `local as` — the right operand must exist (j+2 in
                        // range) and be a symbol; the list tail or a
                        // non-symbol = the missing-operand face (D1 — span:
                        // the offending element's own position, the as
                        // token's when the list simply ends)
                        let right = if j + 2 < sel.len() {
                            sel[j + 2].datum.as_symbol()
                        } else {
                            None
                        };
                        let rsym = match right {
                            Some(r) => r,
                            None => {
                                let span = if j + 2 < sel.len() {
                                    sel[j + 2].span
                                } else {
                                    sel[j + 1].span
                                };
                                // `local as` followed by a non-symbol (or
                                // the list tail) = the missing-operand face
                                // (D1 — E0002 import-form shape family)
                                let diag = Diagnostic::error(
                                    Some(DiagnosticCode(2)),
                                    "member rename missing alias identifier(as right operand -- form: `name as alias`)"
                                        .to_string(),
                                    span,
                                );
                                return Err(face_err(diag, sm));
                            }
                        };
                        let renamed = table.name(rsym).to_string();
                        face.member_renames
                            .push((base_ns.clone(), mname.clone(), renamed));
                        // r135 D14-②: the parallel Span (the selection
                        // element's own site — the user's use-declaration
                        // attribution anchor for the binding injection)
                        face.member_rename_spans.push(sel[j].span);
                        members.push(mname);
                        j += 3;
                        continue;
                    }
                    members.push(mname);
                    j += 1;
                }
                face.selected.push((base_ns.clone(), members));
                // Selectively importing this module: no duplicate entry in
                // the unqualified full face (a repeat import of the same
                // module without selection = full — first-seen semantics,
                // same shape as `as`)
                if !face.unqualified.contains(&base_ns) {
                    face.unqualified.push(base_ns.clone());
                }
                face.selective.insert(base_ns.clone());
                i += skip + 1;
                continue;
            }
        }
        // Unqualified import: injects the export face (E0013 conflict-detection face)
        face.unqualified.push(base_ns);
        i += skip;
    }
    Ok(())
}

/// Module header-region import collection (the original collect_import_face
/// body — D47 split for reuse; import/export in order, terminated before
/// the body). r134 / member-rename-design.md v1.0 §3 D5: the header region
/// now accepts selection lists (and their rename triples) — the shared
/// `collect_import_items` single point (the expander's header scan mirrors
/// the same acceptance).
#[allow(clippy::result_large_err)] // error path (carries the full diagnostic structure) — same entry-point convention (r134: the header path shares the shape-enforcement face)
fn collect_module_header_imports(
    items: &[Stx],
    face: &mut ImportFace,
    table: &SymbolTable,
    sm: &SourceMap,
) -> Result<(), DriverError> {
    // Header-region traversal (import/export in order, terminated before the body)
    for item in items.iter().skip(2) {
        let sub = match item.datum.as_list() {
            Some(l) if !l.is_empty() => l,
            // _ arm rationale: a non-list header item = body form — header region ends
            _ => break,
        };
        let h = match sub[0].datum.as_symbol() {
            Some(s) => s,
            None => break,
        };
        if table.name(h) != "import" {
            // export headers and body forms: header-region traversal
            // termination condition (the import face is collected only
            // within consecutive import/export headers)
            if table.name(h) == "export" {
                continue;
            }
            break;
        }
        // Import item-sequence parsing (look-ahead as-shape awareness —
        // `(module-name as alias)` is an alias-qualified import: only the
        // alias pair is registered, **no unqualified names injected**
        // [22 §3.5 aliases are the qualified-reference form of a local
        // binding; putting an as-shaped module into unqualified would
        // misreport E0013 against another unqualified import of the same
        // export name — look-ahead parsing separates the two shapes at
        // the source])
        collect_import_items(sub, face, table, sm)?;
    }
    Ok(())
}

/// Import target name → ns-segment normalization (`kerf-string` →
/// `string`; `kerf-prelude` has no export face — zero injection,
/// closure/allowlist checking only).
fn import_target_ns(name: &str) -> String {
    name.strip_prefix("kerf-").unwrap_or(name).to_string()
}

/// Import face verification (E0013 conflict / E0017 alias duplication /
/// E0019 unknown module — 22 §5.4/§6 + deep-review D2 ruling; fail-closed
/// first-violation blocking, same basis as R9).
#[allow(clippy::result_large_err)] // error path (carries the full diagnostic structure) — same entry-point convention
fn verify_import_face(
    face: &ImportFace,
    table: &SymbolTable,
    sm: &SourceMap,
    import_spans: &[(String, Span)],
) -> Result<(), DriverError> {
    // E0019 unknown module: every import target ∈ the registered allowlist (seven modules + prelude)
    for (name, span) in import_spans {
        if !RESERVED_ALLOW.contains(&name.as_str()) {
            let diag = Diagnostic::error(
                Some(UNKNOWN_IMPORT_CODE),
                format!(
                    "unknown imported module `{}`(registered list:{} -- import only standard library modules are accepted; user module cross-imports belong to Stage 3 compilation unit window)",
                    name,
                    RESERVED_ALLOW.join(" / ")
                ),
                *span,
            );
            return Err(face_err(diag, sm));
        }
    }
    // E0013 unqualified conflict: r47 / 68-b D55 **underlying-identity
    // re-basing** — the r40 M2 transitional basis (local-name lexical
    // collision) protected a "local-name flat semantics" that was never
    // implemented (local names are reachable only in qualified form —
    // `string/append` is unique; the flat ground truth = the underlying
    // `string-append` is unique — a lexical collision constitutes no
    // runtime ambiguity). After re-basing the criterion = flat runtime
    // payload collision: same underlying name **and different dispatch
    // bodies** = a real conflict. For the stdlib's seven modules the
    // underlying is the dispatch identity (string/symbol share an
    // underlying = the same-dispatch-body pair [non-conflict]; prelude's
    // re-exported nth/drop share kerf-list's underlying [non-conflict])
    // → the stdlib domain is **structurally conflict-free** (importing
    // kerf-string + kerf-list together is legal — flat `append` always
    // resolves to the list domain; `string/append` qualified form
    // disambiguates); the E0013 channel is retained
    // (`IMPORT_CONFLICT_CODE` code point registered 18 §6 — the Stage 3+
    // user-module window: fires when user module export faces have the
    // same name with different bodies [at that point the flat face carries
    // dispatch identity])
    // r50 / D65 E0024: selective import member ∈ the module export face
    // (local-name basis — prelude decided via PRELUDE_EXPORT_NAMES)
    for (ns, members) in &face.selected {
        for m in members {
            let exported = if ns == "prelude" {
                crate::builtins::PRELUDE_EXPORT_NAMES.contains(&m.as_str())
            } else {
                STDLIB_MODULES
                    .iter()
                    .any(|&(mn, ml, _)| mn == ns && ml == m)
            };
            if !exported {
                let diag = Diagnostic::error(
                    Some(SELECT_MEMBER_NOT_EXPORTED_CODE),
                    format!(
                        "selective import member `{}` not in module `kerf-{}` export face((import kerf-{}) full import shows all exports --22 §18.3 D65)",
                        m, ns, ns
                    ),
                    import_spans
                        .first()
                        .map(|(_, s)| *s)
                        .unwrap_or_else(Span::dummy),
                );
                return Err(face_err(diag, sm));
            }
        }
    }
    // r135 / member-rename-design.md v1.2 §8 D13/D14: the r134 D8 io/prelude
    // domain-out rejection rows are **retired** — the rename domain now
    // covers all eight importable modules: io renames go through the E0006
    // compile-time renamed-lookup (verify_io_capabilities consumes
    // face.rename_binds — an unauthorized `print as pr` is caught with the
    // dual-name diagnostic; an authorized one shares the underlying's
    // grant token), prelude renames go through the Stx-layer binding
    // injection (front_from_forms 1.62 — `(define renamed underlying)`
    // before the user forms; the module-body define face carries the
    // binding, incremental-alias semantics D14-③)
    // E0017 alias duplication: two `as` aliases with the same name (22 §3.5: duplicate alias definition error)
    let mut seen: std::collections::HashSet<&String> = std::collections::HashSet::new();
    for (alias, _) in &face.aliases {
        if !seen.insert(alias) {
            let diag = Diagnostic::error(
                Some(ALIAS_DUPLICATE_CODE),
                format!(
                    "duplicate alias: `{}` is bound multiple times (an alias is a module-body local binding -- same-name duplication is a duplicate-definition error;22 §3.5 R-N5)",
                    alias
                ),
                import_spans
                    .first()
                    .map(|(_, s)| *s)
                    .unwrap_or_else(Span::dummy),
            );
            return Err(face_err(diag, sm));
        }
    }
    // r134 / member-rename-design.md v1.0 §3 D7: user-binding-name
    // same-domain dedup — the member-rename renames and the module
    // aliases share the user-binding namespace (both are user-named
    // bindings; silent shadowing = the later binding covering the earlier
    // one — §2.3 report-don't-stay-silent)
    for (_ns, _local, renamed) in &face.member_renames {
        if face.aliases.iter().any(|(a, _)| a == renamed) {
            let diag = Diagnostic::error(
                Some(ALIAS_DUPLICATE_CODE),
                format!(
                    "member rename and alias same-named conflict: `{}`(member rename bindings and module aliases are both user binding names -- unique within the domain)",
                    renamed
                ),
                import_spans
                    .first()
                    .map(|(_, s)| *s)
                    .unwrap_or_else(Span::dummy),
            );
            return Err(face_err(diag, sm));
        }
        if !seen.insert(renamed) {
            let diag = Diagnostic::error(
                Some(ALIAS_DUPLICATE_CODE),
                format!(
                    "member rename duplicate: `{}`(each member rename at most once per import face)",
                    renamed
                ),
                import_spans
                    .first()
                    .map(|(_, s)| *s)
                    .unwrap_or_else(Span::dummy),
            );
            return Err(face_err(diag, sm));
        }
    }
    let _ = (table, sm); // (this function currently consumes only spans/allowlists — the parameter face is retained for alignment)
    Ok(())
}

/// Import face error wrapper (DriverError construction helper).
fn face_err(diag: Diagnostic, sm: &SourceMap) -> DriverError {
    // Compile stage (consistent with the M1 verify_qualified_refs
    // precedent: the post-expand front pipeline's compile-time
    // verification family — semantic-attribution verification, not
    // expansion)
    DriverError {
        stage: Stage::Compile,
        rendered: render_diagnostic(&diag, sm),
        diagnostic: diag,
    }
}

/// Import target collection (name + Span — for E0019 locating; same
/// traversal as collect_import_face but retaining the original target
/// names — kerf- form).
fn collect_import_targets(forms: &[Stx], table: &SymbolTable) -> Vec<(String, Span)> {
    let mut out = Vec::new();
    for f in forms {
        let items = match f.datum.as_list() {
            Some(l) if !l.is_empty() => l,
            _ => continue,
        };
        let head = match items[0].datum.as_symbol() {
            Some(s) => s,
            None => continue,
        };
        match table.name(head) {
            // r46 / 67-b deep review D47: top-level import form (direct
            // element at program top level) — same traversal as the module
            // header region (`as` alias pairs skip two positions)
            "import" => {
                let mut i = 1;
                while i < items.len() {
                    if let Some(sym) = items[i].datum.as_symbol() {
                        let name = table.name(sym).to_string();
                        if name == "as" {
                            i += 2;
                            continue;
                        }
                        out.push((name, items[i].span));
                    }
                    i += 1;
                }
            }
            "module" => {
                for item in items.iter().skip(2) {
                    let sub = match item.datum.as_list() {
                        Some(l) if !l.is_empty() => l,
                        _ => break,
                    };
                    let h = match sub[0].datum.as_symbol() {
                        Some(s) => s,
                        None => break,
                    };
                    match table.name(h) {
                        "import" => {
                            let mut i = 1;
                            while i < sub.len() {
                                if let Some(sym) = sub[i].datum.as_symbol() {
                                    let name = table.name(sym).to_string();
                                    if name == "as" {
                                        i += 2;
                                        continue;
                                    }
                                    out.push((name, sub[i].span));
                                }
                                i += 1;
                            }
                            continue;
                        }
                        "export" => continue,
                        _ => break,
                    }
                }
            }
            // _ arm rationale: non-import/module heads do not participate in target collection
            _ => {}
        }
    }
    out
}

/// Top-level import form decision (D47 — `(import ...)` as a direct element at program top level).
fn is_toplevel_import(f: &Stx, table: &SymbolTable) -> bool {
    let items = match f.datum.as_list() {
        Some(l) if !l.is_empty() => l,
        // _ arm rationale: non-list / empty lists are not import forms
        _ => return false,
    };
    items[0]
        .datum
        .as_symbol()
        .map(|s| table.name(s) == "import")
        .unwrap_or(false)
}

/// Top-level import form stripping (D47 — after face collection and the
/// reserved-word check, before expand: import is a zero-runtime-semantics
/// organizational declaration [no CoreExpr carrier]; after stripping, the
/// expander's E0002 applies only to imports inside expression subtrees /
/// mid-body — the top-level legal position is implemented by this
/// stripping, in contrast to require's PushNil carrier form [require always
/// evaluates to nil, hence stays in the tree]).
fn strip_toplevel_imports(forms: Vec<Stx>, table: &SymbolTable) -> Vec<Stx> {
    forms
        .into_iter()
        .filter(|f| !is_toplevel_import(f, table) && !is_toplevel_extern(f, table))
        .collect()
}

// ---------------------------------------------------------------------------
// r137 / 207-c — TD-026 language-surface window: the extern declaration
// family (ffi-language-surface-design.md §3 D2/D3). The driver owns the
// whole declaration face (collect → validate → strip — the import
// precedent's isomorph: the expander never sees extern forms; zero new
// CoreExpr/ModuleItem variants).
// ---------------------------------------------------------------------------

/// r137 E0026: the extern-surface diagnostic family (ffi-language-surface-
/// design §3/D9 — E0025's next number, the E0002 rendering channel, zero
/// new channels): shape / position / contract / value-position violations.
const EXTERN_SURFACE_CODE: DiagnosticCode = DiagnosticCode(26);

/// A validated extern declaration (the post-D3 face entry).
#[derive(Clone)]
pub(crate) struct ExternEntryDecl {
    /// The declared symbol name (flat FFI symbol space — matched by name
    /// alone at every face).
    pub(crate) name: String,
    /// r147 / 217-c (extern-alias-design D3): the source-level binding
    /// name — the alias when the six-element `as ALIAS` form declares one,
    /// the underlying name itself otherwise (the identity default: the
    /// unaliased path's mathematical invariance, principle 27).
    pub(crate) local: String,
    /// The declared parameter kinds (LangKind projection).
    pub(crate) param_kinds: Vec<crate::ffi::LangKind>,
    /// The declared return kind.
    pub(crate) ret_kind: crate::ffi::LangKind,
    /// The declaration's Span (diagnostic attribution).
    pub(crate) span: Span,
}

/// The collected extern face (D2 — the ImportFace isomorph: a Stx-layer
/// pre-expansion scan; the sole data source of the resolution face, the
/// E0022 visible face, the capability gate and the runtime table
/// construction).
#[derive(Clone, Default)]
pub(crate) struct ExternFace {
    pub(crate) entries: Vec<ExternEntryDecl>,
}

/// Whether a form is a top-level extern declaration (`(extern ...)` head).
fn is_toplevel_extern(f: &Stx, table: &SymbolTable) -> bool {
    let items = match f.datum.as_list() {
        Some(l) if !l.is_empty() => l,
        _ => return false,
    };
    items[0]
        .datum
        .as_symbol()
        .map(|s| table.name(s) == "extern")
        .unwrap_or(false)
}

/// r137 / 207-c (D3): collect + validate the extern declaration face —
/// the five-fold compile-time fail-closed checks (shape / availability /
/// contract / duplicates; the capability gate runs post-expansion in
/// `front_from_core` where the Require face is known). First violation
/// blocks (report-don't-stay-silent — §2.3-4).
#[allow(clippy::result_large_err)]
fn collect_extern_face(
    forms: &[Stx],
    face: &ImportFace,
    table: &SymbolTable,
    sm: &SourceMap,
) -> Result<ExternFace, DriverError> {
    // D3-⑤'s define-face basis: the source's top-level define names
    // (both define shapes — `(define name value)` / `(define (name
    // params...) body)`), collected once for the whole forms list
    // (order-independent collision detection: an extern may be declared
    // before or after the colliding define).
    let toplevel_define_names: std::collections::HashSet<String> = forms
        .iter()
        .filter_map(|f| {
            let items = f.datum.as_list()?;
            let head = items.first()?.datum.as_symbol()?;
            if table.name(head) != "define" || items.len() < 2 {
                return None;
            }
            match items[1].datum.as_symbol() {
                Some(n) => Some(table.name(n).to_string()),
                None => {
                    // The function shape: the name is the second
                    // element's list head
                    let inner = items[1].datum.as_list()?;
                    let n = inner.first()?.datum.as_symbol()?;
                    Some(table.name(n).to_string())
                }
            }
        })
        .collect();
    let mut entries: Vec<ExternEntryDecl> = Vec::new();
    for f in forms {
        if !is_toplevel_extern(f, table) {
            continue;
        }
        let span = f.span;
        let items = f
            .datum
            .as_list()
            .expect("already determined to be a list above");
        // D3-① shape: (extern NAME (kind...) RET) — exactly four elements;
        // r147 / 217-c (extern-alias-design D1): the aliased six-element
        // form (extern NAME as ALIAS (kind...) RET) — the declaration-site
        // alias arm
        if items.len() != 4 && items.len() != 6 {
            return Err(extern_surface_err(
                format!(
                    "extern declaration form violation: exactly four elements (extern name (argument kind table) return kind) or six elements (extern name as alias (argument kind table) return kind), got {} element",
                    items.len()
                ),
                span,
                sm,
            ));
        }
        let name = match items[1].datum.as_symbol() {
            Some(s) => table.name(s).to_string(),
            None => {
                return Err(extern_surface_err(
                    "extern declaration form violation: name position must be symbol(flat symbol space with name parse)".to_string(),
                    items[1].span,
                    sm,
                ));
            }
        };
        // r147 / 217-c (D1): the six-element form's items[2] must be the
        // literal `as` symbol (the import family's collect precedent — a
        // plain Stx symbol matched by name); items[3] = the ALIAS symbol
        // (the flat extern space's bare-name domain). Failure = the E0026
        // form family (report-don't-stay-silent, §2.3-4).
        let alias: Option<String> = if items.len() == 6 {
            match items[2].datum.as_symbol() {
                Some(s) if table.name(s) == "as" => {}
                _ => {
                    return Err(extern_surface_err(
                        "extern declaration form violation: six elements form item second position must be literal as keyword(extern name as alias ... -- the declaration-site alias arm)".to_string(),
                        items[2].span,
                        sm,
                    ));
                }
            }
            Some(match items[3].datum.as_symbol() {
                Some(s) => table.name(s).to_string(),
                None => {
                    return Err(extern_surface_err(
                        "extern declaration form violation: alias position must be symbol(the flat extern space bare-name domain -- no path form)".to_string(),
                        items[3].span,
                        sm,
                    ));
                }
            })
        } else {
            None
        };
        // r147 / 217-c (D3): the two-name split — the underlying `name`
        // stays the flat FFI space key (registry/contract/capability/
        // runtime faces all match by it); the local binding name is the
        // alias when present, the underlying itself otherwise.
        let local = alias.clone().unwrap_or_else(|| name.clone());
        // r147 / 217-c (D5): the self-alias rejection — a no-op alias is
        // meaningless and must fail closed (zero silent no-op, §2.3-4)
        if alias.as_deref() == Some(name.as_str()) {
            return Err(extern_surface_err(
                format!(
                    "extern declaration form violation: alias `{}` must differ from the extern symbol name(self alias is a silent no-op -- report do not stay silent)",
                    name
                ),
                items[3].span,
                sm,
            ));
        }
        let (kinds_idx, ret_idx) = if alias.is_some() { (4, 5) } else { (2, 3) };
        let param_items = match items[kinds_idx].datum.as_list() {
            Some(l) => l,
            None => {
                return Err(extern_surface_err(
                    "extern declaration form violation: item ternary must be argument kind table(list -- empty table = zero arguments external function)"
                        .to_string(),
                    items[kinds_idx].span,
                    sm,
                ));
            }
        };
        let mut param_kinds = Vec::with_capacity(param_items.len());
        for p in param_items {
            let word = match p.datum.as_symbol() {
                Some(s) => table.name(s),
                None => {
                    return Err(extern_surface_err(
                        "extern declaration form violation: argument kind position must be symbol(int/str/ptr three words maximum)"
                            .to_string(),
                        p.span,
                        sm,
                    ));
                }
            };
            match crate::ffi::LangKind::from_word(word) {
                Some(k) => param_kinds.push(k),
                None => {
                    return Err(extern_surface_err(
                        format!(
                            "extern declaration kind word `{}` out of domain (three words maximum: int / str / ptr -- ffi-language-surface-design §2.3 D1)",
                            word
                        ),
                        p.span,
                        sm,
                    ));
                }
            }
        }
        let ret_kind = match items[ret_idx].datum.as_symbol() {
            Some(s) => match crate::ffi::LangKind::from_word(table.name(s)) {
                Some(k) => k,
                None => {
                    return Err(extern_surface_err(
                        format!(
                            "extern declaration return kind word `{}` out of domain (three words maximum: int / str / ptr)",
                            table.name(s)
                        ),
                        items[ret_idx].span,
                        sm,
                    ));
                }
            },
            None => {
                return Err(extern_surface_err(
                    "extern declaration form violation: return kind position must be symbol(int/str/ptr)".to_string(),
                    items[ret_idx].span,
                    sm,
                ));
            }
        };
        // D3-⑤ duplicates: re-declaration / top-level define face / import
        // flat face / N1 core face (the flat symbol space's compile-time
        // anti-shadowing enforcement — ffi-ownership-model §4).
        // r147 / 217-c (extern-alias-design D6): the local binding name
        // joins the same anti-shadowing discipline — the aliased visible
        // face entry collides with define/import/N1/other externs' visible
        // names (both their locals and the unaliased entries' names);
        // the underlying stays matched against the prior entries'
        // underlyings (the registry domain — two declarations of one FFI
        // symbol remain a duplicate)
        if let Some(prev) = entries.iter().find(|e| e.name == name) {
            return Err(extern_surface_err(
                format!(
                    "extern symbol `{}` duplicate declaration (first seen {}:{} -- flat symbol space cannot duplicate registered)",
                    name, prev.span.file_id, prev.span.start
                ),
                span,
                sm,
            ));
        }
        if let Some(prev) = entries.iter().find(|e| e.local == local) {
            return Err(extern_surface_err(
                format!(
                    "extern local binding name `{}` duplicate declaration (first seen {}:{} -- the visible flat symbol space cannot duplicate registered)",
                    local, prev.span.file_id, prev.span.start
                ),
                span,
                sm,
            ));
        }
        if toplevel_define_names.contains(&name)
            || face.flat_underlying.contains(&name)
            || crate::builtins::N1_CORE_NAMES.contains(&name.as_str())
            || toplevel_define_names.contains(&local)
            || face.flat_underlying.contains(&local)
            || crate::builtins::N1_CORE_NAMES.contains(&local.as_str())
        {
            return Err(extern_surface_err(
                format!(
                    "extern symbol `{}` and already has visible binding name collision(define/import/N1 core face -- flat symbol space not shadowable, ffi-ownership-model §4)",
                    local
                ),
                span,
                sm,
            ));
        }
        // D3-② availability: the driver's host registry
        let avail = match crate::ffi::available_extern(&name) {
            Some(a) => a,
            None => {
                return Err(extern_unavailable_err(&name, span, sm));
            }
        };
        // D3-③ contract: the LangKind projection must equal the registry's
        if avail.param_kinds != param_kinds.as_slice() || avail.ret_kind != ret_kind {
            return Err(extern_surface_err(
                format!(
                    "extern declaration contract mismatch: `{}` registered can registration has the form({})→ {}, got declaration({})→ {}(host registration face contract -- both sides form state must consistent)",
                    name,
                    avail
                        .param_kinds
                        .iter()
                        .map(|k| k.as_word())
                        .collect::<Vec<_>>()
                        .join(", "),
                    avail.ret_kind.as_word(),
                    param_kinds
                        .iter()
                        .map(|k| k.as_word())
                        .collect::<Vec<_>>()
                        .join(", "),
                    ret_kind.as_word()
                ),
                span,
                sm,
            ));
        }
        entries.push(ExternEntryDecl {
            name,
            local,
            param_kinds,
            ret_kind,
            span,
        });
    }
    Ok(ExternFace { entries })
}

/// The E0012 compile-time variant (D3-② — the runtime E0012's
/// compile-time beforehand; same code, the message names the available face).
fn extern_unavailable_err(name: &str, span: Span, sm: &SourceMap) -> DriverError {
    let diag = Diagnostic::error(
        Some(DiagnosticCode(12)),
        format!(
            "external symbol `{}` not in can registration face registered(registered can registration: {} -- E0012 fail-closed: language face declaration only can please request registered host function)",
            name,
            crate::ffi::available_extern_names()
        ),
        span,
    );
    DriverError {
        stage: Stage::Compile,
        rendered: render_diagnostic(&diag, sm),
        diagnostic: diag,
    }
}

/// The E0026 family constructor.
fn extern_surface_err(message: String, span: Span, sm: &SourceMap) -> DriverError {
    let diag = Diagnostic::error(Some(EXTERN_SURFACE_CODE), message, span);
    DriverError {
        stage: Stage::Compile,
        rendered: render_diagnostic(&diag, sm),
        diagnostic: diag,
    }
}

/// r137 / 207-c (D2): extern position discipline — top-level direct
/// element only (the require/import family's basis; a declaration inside a
/// module body / expression subtree / nested block is a position
/// violation; the source-level scan runs pre-expansion, mirroring
/// `verify_require_positions_stx`).
#[allow(clippy::result_large_err)]
fn verify_extern_positions_stx(
    forms: &[Stx],
    table: &SymbolTable,
    sm: &SourceMap,
) -> Result<(), DriverError> {
    for f in forms {
        if is_toplevel_extern(f, table) {
            continue;
        }
        if let Some(bad) = find_extern_position_violation(f, table) {
            let diag = Diagnostic::error(
                Some(EXTERN_SURFACE_CODE),
                "extern declaration position violation: only program top level direct element position legal(module body/expression position/inside nested block not accept -- and require/import declaration family same basis, 22 §15 D47)"
                    .to_string(),
                bad.span,
            );
            return Err(DriverError {
                stage: Stage::Compile,
                rendered: render_diagnostic(&diag, sm),
                diagnostic: diag,
            });
        }
    }
    Ok(())
}

/// Subtree scan for a non-top-level extern form (returns the violating
/// form's Span; the top-level forms' own heads are skipped — the caller
/// already classified them).
fn find_extern_position_violation(f: &Stx, table: &SymbolTable) -> Option<Stx> {
    match &f.datum {
        kerf_syntax::StxDatum::List(items) => {
            // A list whose head is a non-extern-classified form: scan the
            // elements recursively. An `(extern ...)` list found anywhere
            // below the top level = the violation (the head-position
            // extern is only legal as a top-level direct element — the
            // caller's is_toplevel_extern already accepted those).
            let head_is_extern = items
                .first()
                .and_then(|h| h.datum.as_symbol())
                .map(|s| table.name(s) == "extern")
                .unwrap_or(false);
            if head_is_extern {
                // Reached here only from a nested position (the caller
                // skipped top-level externs) — the violation itself.
                return Some(f.clone());
            }
            for it in items.iter() {
                if let Some(hit) = find_extern_position_violation(it, table) {
                    return Some(hit);
                }
            }
            None
        }
        _ => None,
    }
}

/// r137 / 207-c (D3-④): the extern capability gate — each declared extern
/// whose registry row requires the io `write` capability must be granted
/// by the program's top-level Require face (the FFI write channel shares
/// the authorization token with the io language channel — r65/118-a
/// "permission belongs to the capability domain"). Runs post-expansion
/// (the Require face is a CoreExpr-declaration artifact).
#[allow(clippy::result_large_err)]
fn verify_extern_capabilities(
    extern_face: &ExternFace,
    items: &[ModuleItem],
    sm: &SourceMap,
) -> Result<(), DriverError> {
    let declared = IoRequirements::from_items(items);
    for e in &extern_face.entries {
        if let Some(a) = crate::ffi::available_extern(&e.name) {
            if a.requires_write && !declared.write {
                let diag = Diagnostic::error(
                    Some(DiagnosticCode(6)),
                    format!(
                        "`{}`(extern declaration)requires write capability -- FFI write channel and io language channel same share authorization token(r65/118-a capability domain converge belongs to ruling); please first declaration (require io write)",
                        e.name
                    ),
                    e.span,
                );
                return Err(DriverError {
                    stage: Stage::Compile,
                    rendered: render_diagnostic(&diag, sm),
                    diagnostic: diag,
                });
            }
        }
    }
    Ok(())
}

/// E0016: duplicate same-name define detection in module bodies (22 §3.2
/// R-N2 fourth row and the M2 landing of 09 v6.2's existing ruling
/// "explicitly report duplicate definitions": per module, direct `body`
/// Define names are deduplicated; nested modules are each checked
/// independently).
#[allow(clippy::result_large_err)]
fn verify_module_define_duplicates(
    items: &[ModuleItem],
    table: &SymbolTable,
    sm: &SourceMap,
) -> Result<(), DriverError> {
    for item in items {
        if let Some(diag) = module_dup_item_diag(item, table) {
            return Err(face_err(diag, sm));
        }
    }
    Ok(())
}

/// Item-level module duplicate-define diagnostic (r49 D59 — module item-body dedup recursion).
fn module_dup_item_diag(item: &ModuleItem, table: &SymbolTable) -> Option<Diagnostic> {
    match item {
        ModuleItem::Module {
            name, items, span, ..
        } => {
            let module_name = table.name(*name).to_string();
            let mut seen: std::collections::HashSet<String> = std::collections::HashSet::new();
            for inner in items {
                if let ModuleItem::Define {
                    name: d,
                    span: dspan,
                    ..
                } = inner
                {
                    let dn = table.name(*d).to_string();
                    if !seen.insert(dn.clone()) {
                        return Some(Diagnostic::error(
                            Some(MODULE_DUPLICATE_CODE),
                            format!(
                                "duplicate definition: module `{}` in define `{}` duplicate(09 v6.2 existing ruling -- explicitly reports duplicate definitions rather than silently shadowing)",
                                module_name, dn
                            ),
                            *dspan,
                        ));
                    }
                }
                if let Some(d) = module_dup_item_diag(inner, table) {
                    return Some(d);
                }
            }
            let _ = span;
            None
        }
        _ => None,
    }
}

// r49 D59: the module_dup_diag CoreExpr tree walk is carried by the
// item-level module_dup_item_diag (modules are not representable in
// expression position — do-chain-position modules belong to splice items)

/// E0018: require position discipline (deep-review D3 ruling: legal
/// positions = direct elements of the program top-level sequence + direct
/// elements of module bodies; occurrence inside expression subtrees
/// (after lambda/let desugaring: Fn/If/Apply/Do nesting levels) = a
/// position error — fail-closed position discipline, same shape as
/// Clojure's require restricted to the ns top level).
#[allow(clippy::result_large_err)]
/// E0018 require position discipline (r49 D59 moved forward: Stx-layer
/// traversal — intercepted before expansion, same window as the 1.6x Stx
/// traversal family; **before r49 this check was a CoreExpr tree walk
/// [post-expansion] — expression-position require is now structurally
/// rejected by the expander [E0002 section], and this Stx traversal
/// carries the source-level check [E0018 code point and Stage::Compile
/// contract preserved]**; defense against macro-produced require in
/// expression position = the expander's Require arm rejection).
///
/// Semantically mirrors the original CoreExpr walk: `top` = direct-element
/// position of a sequence (program top level / module body [after the
/// header region] / do item position [do-splice inheritance — the Stx
/// mirror of r45 Let's position-passing semantics]); data domains are
/// skipped (quote literals / define-syntax templates).
fn verify_require_positions_stx(
    forms: &[Stx],
    table: &SymbolTable,
    sm: &SourceMap,
) -> Result<(), DriverError> {
    for f in forms {
        if let Some(diag) = require_pos_stx_diag(f, table, true) {
            return Err(face_err(diag, sm));
        }
    }
    Ok(())
}

/// require position Stx recursion (top position = legal as a direct
/// element of a sequence; illegal inside container subtrees; data domains
/// [quote/define-syntax] get zero traversal).
fn require_pos_stx_diag(f: &Stx, table: &SymbolTable, top: bool) -> Option<Diagnostic> {
    let items = match f.datum.as_list() {
        Some(l) if !l.is_empty() => l,
        _ => return None,
    };
    let head = items
        .first()
        .and_then(|h| h.datum.as_symbol())
        .map(|s| table.name(s))
        .unwrap_or("");
    match head {
        "require" => {
            if top {
                None
            } else {
                Some(Diagnostic::error(
                    Some(REQUIRE_POSITION_CODE),
                    "require position violation: require legal position = program top level or module body direct element (current position is inside an expression subtree -- require is a declaration, not an expression; deep audit D3 ruling".to_string(),
                    f.span,
                ))
            }
        }
        // Data domains: quote literals and define-syntax templates are not
        // traversed (a require form in a data domain is a legal literal —
        // same discipline as reserved_stx_diag's template domain)
        "quote" | "define-syntax" | "syntax-rules" => None,
        "module" => {
            // Body items = the remainder after the header region
            // (import/export) — recurse in top position (the `(module)`
            // shape error is carried by the expander's expand_module
            // dedicated message — this walk has zero shape-validation duty;
            // short forms are safely skipped)
            if items.len() < 2 {
                return None;
            }
            let mut idx = 2;
            while idx < items.len() {
                let is_header = items[idx]
                    .datum
                    .as_list()
                    .and_then(|l| l.first())
                    .and_then(|h| h.datum.as_symbol())
                    .map(|h| {
                        let n = table.name(h);
                        n == "import" || n == "export"
                    })
                    .unwrap_or(false);
                if !is_header {
                    break;
                }
                idx += 1;
            }
            items[idx..]
                .iter()
                .find_map(|item| require_pos_stx_diag(item, table, true))
        }
        "do" => {
            // Stx mirror of r49 do-splice: do items inherit the
            // sequence-position top flag (expression-position do = false
            // passed down — isomorphic to the original Let
            // position-passing semantics)
            items[1..]
                .iter()
                .find_map(|item| require_pos_stx_diag(item, table, top))
        }
        _ => items
            .iter()
            .find_map(|item| require_pos_stx_diag(item, table, false)),
    }
}

/// W warning collection (W1002 injected-name shadowing family + W1003
/// macro-name-shadows-builtin family — non-blocking; 22 §3.2 R-N2 second
/// row + 22 §11 D11). One diagnostic per name, deduplicated by first
/// occurrence (diagnostic aggregation).
/// r42/S1: the W1001 deprecation family is retired (old names escalate to
/// E0021 compile-time blocking — the W face narrows).
fn collect_warnings(
    items: &[ModuleItem],
    table: &SymbolTable,
    face: &ImportFace,
    macro_defs: &[(String, Span)],
) -> Vec<Diagnostic> {
    let mut out: Vec<Diagnostic> = Vec::new();
    let mut shadow_seen: std::collections::HashSet<String> = std::collections::HashSet::new();
    // r47 / 68-b visibility tightening leg (D55): the W1003/W1002
    // **face-aware double revision** — data source = visible flat face
    // (N1 core face ∪ import flat runtime payload) ∩ registration face;
    // zero-false-positive discipline: names on invisible faces are freely
    // definable (macro name/define name ∈ a non-imported domain → outside
    // shadowing semantics — a generalization of the S1 takeover-exemption
    // logic, D54 ②)
    let visible_flat: std::collections::HashSet<String> = crate::builtins::N1_CORE_NAMES
        .iter()
        .map(|s| s.to_string())
        .chain(face.flat_underlying.iter().cloned())
        .collect();
    // r135 D13-① note: renamed bindings intentionally do NOT join
    // visible_flat — W1002's notice condition requires
    // builtin_name_exists (a renamed name is never a builtin-registry
    // name), so the chain would be dead code; the E0022 face alone
    // carries the renamed-binding resolution (verify_unbound_refs)
    // r42 / S1 removal round: the W1001 deprecation family is retired (the
    // 27 old names escalate to E0021 compile-time errors — the W-level
    // face disappearing is legitimate; the W1002 shadowing family is
    // maintained). The W1003 macro-name shadowing lands (22 §11 D11
    // scheduling honored in this window).
    let mut macro_seen: std::collections::HashSet<String> = std::collections::HashSet::new();
    for (name, span) in macro_defs {
        if !macro_seen.insert(name.clone()) {
            continue; // one per name, deduplicated (diagnostic aggregation)
        }
        // r47 visibility decision (face-aware): flat names are checked
        // against the visible flat face; qualified-name macros (the
        // `string/append` form) check module ∈ import set (unqualified or
        // as alias — alias-form macro names `str/append` likewise check
        // the alias set) — shadowing an invisible name = a freely defined
        // name on an invisible face, zero W (D54 ② zero-false-positive
        // discipline)
        let visible = match name.split_once('/') {
            Some((ns, _)) => {
                face.unqualified.iter().any(|m| m == ns)
                    || face.aliases.iter().any(|(a, _)| a == ns)
            }
            None => visible_flat.contains(name),
        };
        if visible && crate::builtins::builtin_name_exists(name) {
            out.push(Diagnostic::warning(
                Some(MACRO_SHADOW_CODE),
                format!(
                    "macro name `{}` shadows visible builtin name(W1003 -- macro-wins is an essential capability, this is informational only; rename if unintentional)",
                    name
                ),
                *span,
            ));
        }
    }
    for item in items {
        warn_item_diag(item, table, &visible_flat, &mut shadow_seen, &mut out);
    }
    out
}

/// Item-level W diagnostics (r49 D59 — module item-body W1002
/// deduplication and recursion / Require has zero W payload / Define
/// value-side tree walk / expression-item tree walk).
fn warn_item_diag(
    item: &ModuleItem,
    table: &SymbolTable,
    visible_flat: &std::collections::HashSet<String>,
    shadow_seen: &mut std::collections::HashSet<String>,
    out: &mut Vec<Diagnostic>,
) {
    match item {
        ModuleItem::Module { name, items, .. } => {
            let module_name = table.name(*name).to_string();
            // Structural prelude exemption (20 §6.5 bootstrap-corpus
            // discipline — the warn_diag original-arm basis maintained)
            // r164 / 235-c: kerf-list joins the exemption — the injected
            // self-built module body's defines (length/reverse/nth/drop/
            // member/assoc/last-pair) are the system's single-source
            // definitions, not user naming accidents (the cascade-injection
            // shape: import kerf-prelude brings BOTH bodies; the preamble
            // re-export flat face and the list defines co-occur by design,
            // same 20 §6.5 discipline as the prelude's own defines).
            if module_name == PRELUDE_MODULE || module_name == LIST_MODULE {
                return;
            }
            for inner in items {
                if let ModuleItem::Define { name: d, span, .. } = inner {
                    let dn = hygienic_base(table.name(*d));
                    if visible_flat.contains(&dn.to_string()) && shadow_seen.insert(dn.to_string())
                    {
                        out.push(Diagnostic::warning(
                            Some(SHADOW_IMPORT_CODE),
                            format!(
                                "module `{}` define `{}` shadows visible face name(N1 core or import injection -- R-N2: legal but most likely a naming accident; renaming or using a qualified name removes the ambiguity)",
                                module_name, dn
                            ),
                            *span,
                        ));
                    }
                }
                warn_item_diag(inner, table, visible_flat, shadow_seen, out);
            }
        }
        ModuleItem::Define { value, .. } => {
            warn_diag(value, table, visible_flat, shadow_seen, out);
        }
        ModuleItem::Require { .. } => {}
        ModuleItem::Expr(e) => warn_diag(e, table, visible_flat, shadow_seen, out),
    }
}

fn warn_diag(
    e: &CoreExpr,
    table: &SymbolTable,
    visible_flat: &std::collections::HashSet<String>,
    shadow_seen: &mut std::collections::HashSet<String>,
    out: &mut Vec<Diagnostic>,
) {
    match e {
        CoreExpr::Var { .. } => {
            // r42/S1: the W1001 deprecation family is retired — Var has
            // no W duty (old names already escalate to E0021 compile-time
            // blocking in verify_qualified_refs, fail-closed)
        }
        // r49 D59: Module/Define are not in the expression domain — they belong to the item-level warn_item_diag
        CoreExpr::Fn { params, body, .. } => {
            // Parameter shadows an injected name: R-N2 second-row
            // same-shape warning (inner scope winning is legal)
            for p in params {
                let pn = hygienic_base(table.name(*p));
                if visible_flat.contains(&pn.to_string()) && shadow_seen.insert(pn.to_string()) {
                    out.push(Diagnostic::warning(
                        Some(SHADOW_IMPORT_CODE),
                        format!(
                            "fn argument `{}` shadows visible face name(N1 core or import injection -- R-N2: legal but most likely a naming accident)",
                            pn
                        ),
                        e.span(),
                    ));
                }
            }
            warn_diag(body, table, visible_flat, shadow_seen, out);
        }
        CoreExpr::Apply { fn_expr, args, .. } => {
            warn_diag(fn_expr, table, visible_flat, shadow_seen, out);
            for a in args {
                warn_diag(a, table, visible_flat, shadow_seen, out);
            }
        }
        CoreExpr::If {
            cond,
            then_branch,
            else_branch,
            ..
        } => {
            warn_diag(cond, table, visible_flat, shadow_seen, out);
            warn_diag(then_branch, table, visible_flat, shadow_seen, out);
            warn_diag(else_branch, table, visible_flat, shadow_seen, out);
        }
        CoreExpr::Assign { value, .. } => warn_diag(value, table, visible_flat, shadow_seen, out),
        CoreExpr::Let { value, body, .. } => {
            warn_diag(value, table, visible_flat, shadow_seen, out);
            warn_diag(body, table, visible_flat, shadow_seen, out);
        }
        CoreExpr::Perform { effect, .. } => {
            warn_diag(effect, table, visible_flat, shadow_seen, out)
        }
        CoreExpr::Handle {
            handler_body, body, ..
        } => {
            warn_diag(handler_body, table, visible_flat, shadow_seen, out);
            warn_diag(body, table, visible_flat, shadow_seen, out);
        }
        // r136 / 206-b (TD-033 — D13): per-arm handler bodies + the
        // protected body
        CoreExpr::HandleGroup { arms, body, .. } => {
            for arm in arms {
                warn_diag(&arm.handler_body, table, visible_flat, shadow_seen, out);
            }
            warn_diag(body, table, visible_flat, shadow_seen, out);
        }
        CoreExpr::Literal { .. } => {}
    }
}

/// M2 alias qualified-name compile-time normalization (the mechanism
/// face of 22 §3.5 R-N5 "aliases are local bindings": after `(import
/// kerf-string as str)`, the Var `str/append` is rewritten to
/// `string/append` — HM signatures/bytecode compilation/runtime face, the
/// whole chain consumes normalized names, zero runtime alias awareness;
/// the T1 dual path shares the front_from_core segment, naturally parity).
/// Returns as-is when the alias set is empty (zero rewrite overhead —
/// zero cost for alias-free programs).
fn rewrite_alias_refs(
    items: Vec<ModuleItem>,
    face: &ImportFace,
    table: &mut SymbolTable,
) -> Vec<ModuleItem> {
    // r164 / 235-c: the empty-aliases early return is REMOVED — the
    // self-built qualified-flat rewrite below must run even for alias-free
    // units (a bare `import kerf_list; list::nth(...)` carries no alias but
    // needs the `list/nth` qualified Var flattened to the injected define's
    // flat `nth` — the qualified key has no Rust registration to resolve
    // to anymore). The tree walk is a no-op when neither face matches.
    items
        .into_iter()
        .map(|item| match item {
            ModuleItem::Define { name, value, span } => ModuleItem::Define {
                name,
                value: rewrite_alias_expr(value, face, table),
                span,
            },
            ModuleItem::Require { caps, span } => ModuleItem::Require { caps, span },
            ModuleItem::Module {
                name,
                imports,
                exports,
                items: inner,
                span,
            } => ModuleItem::Module {
                name,
                imports,
                exports,
                items: rewrite_alias_refs(inner, face, table),
                span,
            },
            ModuleItem::Expr(e) => ModuleItem::Expr(rewrite_alias_expr(e, face, table)),
        })
        .collect()
}

fn rewrite_alias_expr(e: Rc<CoreExpr>, face: &ImportFace, table: &mut SymbolTable) -> Rc<CoreExpr> {
    match e.as_ref() {
        CoreExpr::Var { name, scopes, span } => {
            let raw = table.name(*name);
            let base = hygienic_base(raw).to_string();
            if let Some((ns, local)) = base.split_once('/') {
                // r164 / 235-c (list-self-built-design.md D3): self-built
                // qualified-flat rewrite — a qualified Var whose (module,
                // member) resolves into the self-built list domain flattens
                // to the member's bare symbol (the injected module-body
                // define's binding name). Both prefix shapes match (the
                // short stdlib ns `list` and the full `kerf-list`; the alias
                // normalization product below feeds the same check). Runs
                // BEFORE the alias arm's return so alias-qualified refs
                // (l::nth → kerf-list/nth) flatten in the same pass.
                let alias_target: Option<String> = face
                    .aliases
                    .iter()
                    .find(|(a, _)| a == ns)
                    .map(|(_, module)| format!("{}/{}", module, local));
                let candidate = alias_target.as_deref().unwrap_or(base.as_str());
                if let Some((ns2, local2)) = candidate.split_once('/') {
                    let ns2_short = ns2.strip_prefix("kerf-").unwrap_or(ns2);
                    if ns2_short == "list"
                        && crate::builtins::SELF_BUILT_LIST_NAMES.contains(&local2)
                    {
                        return Rc::new(CoreExpr::Var {
                            name: table.intern(local2),
                            scopes: scopes.clone(),
                            span: *span,
                        });
                    }
                }
                if let Some(new_name) = alias_target {
                    return Rc::new(CoreExpr::Var {
                        name: table.intern(&new_name),
                        scopes: scopes.clone(),
                        span: *span,
                    });
                }
            }
            Rc::new(e.as_ref().clone())
        }
        CoreExpr::Fn {
            params,
            param_scopes,
            rest,
            body,
            span,
        } => Rc::new(CoreExpr::Fn {
            params: params.clone(),
            param_scopes: param_scopes.clone(),
            rest: rest.clone(),
            body: rewrite_alias_expr(Rc::clone(body), face, table),
            span: *span,
        }),
        CoreExpr::Apply {
            fn_expr,
            args,
            span,
        } => Rc::new(CoreExpr::Apply {
            fn_expr: rewrite_alias_expr(Rc::clone(fn_expr), face, table),
            args: args
                .iter()
                .map(|a| rewrite_alias_expr(Rc::clone(a), face, table))
                .collect(),
            span: *span,
        }),
        CoreExpr::If {
            cond,
            then_branch,
            else_branch,
            span,
        } => Rc::new(CoreExpr::If {
            cond: rewrite_alias_expr(Rc::clone(cond), face, table),
            then_branch: rewrite_alias_expr(Rc::clone(then_branch), face, table),
            else_branch: rewrite_alias_expr(Rc::clone(else_branch), face, table),
            span: *span,
        }),
        CoreExpr::Assign {
            name,
            scopes,
            value,
            span,
        } => Rc::new(CoreExpr::Assign {
            name: *name,
            scopes: scopes.clone(),
            value: rewrite_alias_expr(Rc::clone(value), face, table),
            span: *span,
        }),
        // r49 D59: Define is not in the expression domain — it belongs to the item-level rewrite_alias_refs
        CoreExpr::Let {
            name,
            scopes,
            value,
            body,
            span,
        } => Rc::new(CoreExpr::Let {
            name: *name,
            scopes: scopes.clone(),
            value: rewrite_alias_expr(Rc::clone(value), face, table),
            body: rewrite_alias_expr(Rc::clone(body), face, table),
            span: *span,
        }),
        // r49 D59: Module/Require are not in the expression domain — they belong to the item-level rewrite_alias_refs
        CoreExpr::Literal { .. } => Rc::clone(&e),
        CoreExpr::Perform { effect, span } => Rc::new(CoreExpr::Perform {
            effect: rewrite_alias_expr(Rc::clone(effect), face, table),
            span: *span,
        }),
        CoreExpr::Handle {
            tag,
            payload_var,
            payload_scopes,
            resume_var,
            resume_scopes,
            handler_body,
            body,
            span,
        } => Rc::new(CoreExpr::Handle {
            tag: Rc::clone(tag),
            payload_var: *payload_var,
            payload_scopes: payload_scopes.clone(),
            resume_var: *resume_var,
            resume_scopes: resume_scopes.clone(),
            handler_body: rewrite_alias_expr(Rc::clone(handler_body), face, table),
            body: rewrite_alias_expr(Rc::clone(body), face, table),
            span: *span,
        }),
        // r136 / 206-b (TD-033 — D13): per-arm subtree rewrite (binders and
        // tags carry no alias face — Var positions rewrite inside)
        CoreExpr::HandleGroup { arms, body, span } => Rc::new(CoreExpr::HandleGroup {
            arms: arms
                .iter()
                .map(|arm| kerf_core::HandleArm {
                    tag: Rc::clone(&arm.tag),
                    payload_var: arm.payload_var,
                    payload_scopes: arm.payload_scopes.clone(),
                    resume_var: arm.resume_var,
                    resume_scopes: arm.resume_scopes.clone(),
                    handler_body: rewrite_alias_expr(Rc::clone(&arm.handler_body), face, table),
                })
                .collect(),
            body: rewrite_alias_expr(Rc::clone(body), face, table),
            span: *span,
        }),
    }
}

/// Qualified-name reference verification (R-N3 no fallback — 22 §8 table
/// R-N3 row): Var names containing `/` consult only the stdlib
/// seven-module export faces + the program takeover exemption (define/set!
/// same name — zero-false-positive discipline on the same basis as R9); a
/// miss → E0014 "not exported" rather than "unbound" (diagnostic gain:
/// a mistyped module name points precisely at the module face). The R-N8
/// exemption holds naturally (this verification walks only Var reference
/// positions — quote symbol values are Literals and do not participate).
/// Reserved domain (E0015): module names occupying the kerf- prefix (user
/// modules drop the prefix). Honest M1 narrowing note: qualified-name
/// references to user-module exports are carried by the M2 import face.
#[allow(clippy::result_large_err)] // error path (carries the full diagnostic structure) — same entry-point convention
fn verify_qualified_refs(
    items: &[ModuleItem],
    face: &ImportFace,
    table: &SymbolTable,
    sm: &SourceMap,
) -> Result<(), DriverError> {
    let mut takeover: std::collections::HashSet<String> = std::collections::HashSet::new();
    for item in items {
        crate::capability::collect_takeover_item(item, table, &mut takeover);
    }
    let shadowed: std::collections::HashSet<String> = std::collections::HashSet::new();
    for item in items {
        if let Some(diag) = qualified_item_diag(item, &takeover, &shadowed, face, table) {
            return Err(DriverError {
                stage: Stage::Compile,
                rendered: render_diagnostic(&diag, sm),
                diagnostic: diag,
            });
        }
    }
    Ok(())
}

/// Item-level qualified-name/reserved-domain diagnostics (r49 D59 —
/// Module item E0015 dual-form enforcement + body recursion / Define
/// value side / Require zero references / expression-item tree walk).
fn qualified_item_diag(
    item: &ModuleItem,
    takeover: &std::collections::HashSet<String>,
    shadowed: &std::collections::HashSet<String>,
    face: &ImportFace,
    table: &SymbolTable,
) -> Option<Diagnostic> {
    match item {
        ModuleItem::Module {
            name, span, items, ..
        } => {
            // E0015 reserved domain (22 §7): user module name occupying
            // the kerf- prefix
            // r46 / 67-b deep review D48: dual-form enforcement — kerf-
            // (hyphen identifier form, the import target form) + kerf/
            // (slash form — module names and qualified names share the
            // identifier lexical domain; `kerf/evil` is the module-name
            // form of a single token)
            let module_name = table.name(*name);
            let reserved_hit = (module_name.starts_with(RESERVED_PREFIX)
                || module_name.starts_with("kerf/"))
                && !RESERVED_ALLOW.contains(&module_name);
            if reserved_hit {
                return Some(Diagnostic::error(
                    Some(RESERVED_DOMAIN_CODE),
                    format!(
                        "reserved domain violation: module name `{}` occupied kerf- prefix or kerf/ segment (standard library reserved domain --22 §7 dual-form enforcement; please drop the prefix in user module names)",
                        module_name
                    ),
                    *span,
                ));
            }
            items
                .iter()
                .find_map(|inner| qualified_item_diag(inner, takeover, shadowed, face, table))
        }
        ModuleItem::Define { value, .. } => {
            qualified_ref_diag(value, takeover, shadowed, face, table)
        }
        ModuleItem::Require { .. } => None,
        ModuleItem::Expr(e) => qualified_ref_diag(e, takeover, shadowed, face, table),
    }
}

/// Qualified-name/reserved-domain diagnostic traversal (return on the
/// first violation — fail-closed single-diagnostic blocking; multi-error
/// collection is the E0005 family's duty, same basis as R9).
///
/// R-N1 resolution order (22 §3.1): N3 local bindings precede N2 —
/// **Fn parameters shadow the qualified-name check** (`(lambda (foo/bar)
/// foo/bar)` is a local name, not a qualified reference); the shadowed set
/// is passed in through recursion (Fn enters the union — immutable
/// propagation, lexical-nesting correctness).
fn qualified_ref_diag(
    e: &CoreExpr,
    takeover: &std::collections::HashSet<String>,
    shadowed: &std::collections::HashSet<String>,
    face: &ImportFace,
    table: &SymbolTable,
) -> Option<Diagnostic> {
    match e {
        CoreExpr::Var { name, span, .. } => {
            let raw = table.name(*name);
            let base = hygienic_base(raw);
            if shadowed.contains(base) || shadowed.contains(raw) {
                return None; // N3 local binding wins (R-N1 — parameter shadowing is legal)
            }
            // r42 / S1 removal round — E0021 removed old names (value
            // position/operator position, whole domain; same traversal as
            // E0014 — shadowing already exempted [above], takeover
            // exemption [below] on the same basis: user define/assign of an
            // old name = a legal user global [what is retired is the
            // builtin registration face])
            // r43 / S2 keyword leg — keyword old forms enter the same
            // rejection face (22 §12 D29: lambda/set!/begin old forms →
            // E0021 carrying modern-form guidance; takeover exemption on
            // the same basis; message sources split — builtin old names
            // keep the S1 wording [27 negative-case group assertion
            // anchor], keyword old forms use the S2 wording)
            if !takeover.contains(raw) && !takeover.contains(base) {
                if let Some(&(_, modern)) = crate::builtins::REMOVED_BUILTIN_NAMES
                    .iter()
                    .find(|&&(old, _)| old == base)
                {
                    return Some(Diagnostic::error(
                        Some(REMOVED_NAME_CODE),
                        format!(
                            "`{}` already at v0.9 removed -- modern name `{}`(20 §7 removed round; qualified name form kerf domain also available)",
                            base, modern
                        ),
                        *span,
                    ));
                }
                if let Some(&(_, modern)) =
                    REMOVED_KEYWORD_NAMES.iter().find(|&&(old, _)| old == base)
                {
                    return Some(Diagnostic::error(
                        Some(REMOVED_NAME_CODE),
                        format!(
                            "`{}` keyword switched -- modern form `{}`(22 §12 S2 keyword switch; user takeover of the same name is unaffected)",
                            base, modern
                        ),
                        *span,
                    ));
                }
            }
            // A standalone `/` (the division operator) and names without
            // `/` do not participate (R-N4 lexical-domain restriction: `/`
            // is only an in-identifier separator — bare names take the
            // existing unbound path)
            if base.len() < 2 || !base.contains('/') {
                return None;
            }
            if takeover.contains(raw) || takeover.contains(base) {
                return None;
            }
            let (ns, local) = base.split_once('/')?;
            // M2 alias normalization (22 §3.5 R-N5: the ns segment of
            // `str/append` first consults the alias mapping — an alias is
            // the qualified-reference form of a local binding; after
            // normalization the module export face is checked per R-N3;
            // non-alias ns is queried as-is)
            let alias_of = face
                .aliases
                .iter()
                .find(|(a, _)| a == ns)
                .map(|(_, m)| m.clone());
            let resolved_ns = alias_of.clone().unwrap_or_else(|| ns.to_string());
            // R-N3 no fallback: consult only the N2 export face (stdlib
            // seven modules; user takeover already exempted — qualified
            // names of user-module exports = the M2 import face)
            let known = STDLIB_MODULES
                .iter()
                .any(|&(module, local_name, _)| module == resolved_ns && local_name == local);
            if known {
                // r47 / 68-b visibility tightening leg (22 §15 D55): the
                // **qualified-name import gate** — qualified-name use
                // requires the module to be imported (unqualified or as
                // alias both count — same shape as Rust use-as: an alias is
                // an additional binding, not an exclusive one). **io
                // exception**: the authorization gate and the visibility
                // gate coincide at the io family boundary (D52 channel
                // table — require io, one declaration, two gates; gated
                // names are permanently visible in N1, and their qualified
                // forms io/* follow the authorization face — a double
                // declaration = bureaucratic tax).
                if resolved_ns != "io" {
                    let imported = face.unqualified.iter().any(|m| m == &resolved_ns)
                        || face.aliases.iter().any(|(_, m)| m == &resolved_ns);
                    if !imported {
                        let via_alias = alias_of
                            .as_ref()
                            .map(|m| format!("(alias {} → kerf-{})", ns, m))
                            .unwrap_or_default();
                        return Some(Diagnostic::error(
                            Some(QUALIFIED_NOT_EXPORTED_CODE),
                            format!(
                                "qualified name `{}/{}` requires first import -- (import kerf-{}) the qualified form is available after (R-N3 visibility gate: qualified-name resolution in the imported module's export inside the face{}; 22 §15 D55)",
                                ns, local, resolved_ns, via_alias
                            ),
                            *span,
                        ));
                    }
                }
                return None;
            }
            Some(Diagnostic::error(
                Some(QUALIFIED_NOT_EXPORTED_CODE),
                format!(
                    "`{}` does not export `{}`(qualified names have no fallback --R-N3: searches only the module export face, not the globals/local/other module{})",
                    resolved_ns, local,
                    alias_of.map(|m| format!("(alias {} → kerf-{})", ns, m)).unwrap_or_default()
                ),
                *span,
            ))
        }
        // r49 D59: Module/Define/Require are not in the expression domain —
        // they belong to the item-level qualified_item_diag (E0015 reserved
        // domain + E0021/E0014 walk)
        CoreExpr::Fn { params, body, .. } => {
            // R-N1: parameters are N3 local bindings — merge into the
            // shadowed set, then recurse into the body (the let family
            // already desugars to Fn+Apply; the CoreExpr-layer N3 binding
            // face = Fn parameters)
            let mut inner = shadowed.clone();
            for p in params {
                inner.insert(table.name(*p).to_string());
            }
            qualified_ref_diag(body, takeover, &inner, face, table)
        }
        CoreExpr::Apply { fn_expr, args, .. } => {
            qualified_ref_diag(fn_expr, takeover, shadowed, face, table).or_else(|| {
                args.iter()
                    .find_map(|a| qualified_ref_diag(a, takeover, shadowed, face, table))
            })
        }
        CoreExpr::If {
            cond,
            then_branch,
            else_branch,
            ..
        } => qualified_ref_diag(cond, takeover, shadowed, face, table)
            .or_else(|| qualified_ref_diag(then_branch, takeover, shadowed, face, table))
            .or_else(|| qualified_ref_diag(else_branch, takeover, shadowed, face, table)),
        CoreExpr::Assign { value, .. } => {
            qualified_ref_diag(value, takeover, shadowed, face, table)
        }
        CoreExpr::Let { value, body, .. } => {
            qualified_ref_diag(value, takeover, shadowed, face, table)
                .or_else(|| qualified_ref_diag(body, takeover, shadowed, face, table))
        }
        CoreExpr::Literal { .. } => None,
        CoreExpr::Perform { effect, .. } => {
            qualified_ref_diag(effect, takeover, shadowed, face, table)
        }
        CoreExpr::Handle {
            handler_body, body, ..
        } => qualified_ref_diag(handler_body, takeover, shadowed, face, table)
            .or_else(|| qualified_ref_diag(body, takeover, shadowed, face, table)),
        // r136 / 206-b (TD-033 — D13): per-arm handler bodies + the
        // protected body (binders stay out of the shadowed set — same
        // treatment as the single-arm form)
        CoreExpr::HandleGroup { arms, body, .. } => {
            for arm in arms {
                if let Some(d) =
                    qualified_ref_diag(&arm.handler_body, takeover, shadowed, face, table)
                {
                    return Some(d);
                }
            }
            qualified_ref_diag(body, takeover, shadowed, face, table)
        }
    }
}

/// E0022 compile-time unbound-reference verification (r46 / 67-b baseline
/// landing + r47 / 68-b visible-face check upgrade — the carrier of R-N1
/// step 4; 22 §15 D49/D55). Precondition: alias normalization already
/// executed (after step 2.7). The check basis = **the compiled artifact's
/// `global_refs`** (the compiler has already done local resolution — Fn
/// parameters/Let slots/hygienic names are all resolved to local slots at
/// compile time; only names that truly land in global references enter
/// global_refs; a CoreExpr Var tree traversal would misjudge hygienic
/// local names as global — the r46 implementation-log lesson). The
/// **visible face** = N1 core face (`N1_CORE_NAMES` — operators/identity
/// logic/pair construction and access/list/predicate full set/gated/
/// bootstrap-private) ∪ import flat runtime payload
/// (`face.flat_underlying` — incl. the prelude re-export margin) ∪ the
/// program define face. Hygiene-suffixed names are checked with the same
/// logic as runtime fallback resolution (a base-name hit suffices).
/// Qualified names (containing `/`) and unauthorized gated names do not
/// participate (E0014/E0006 semantic domains precede this check). The
/// message carries per-layer detail (N3/N2/N1 — D46 ③) + an import
/// suggestion (`suggest_import_for` single source — underlying reverse
/// lookup + prelude high-frequency set first). The runtime registration
/// face keeps the full set (dispatch-table basis — visibility payloading
/// at the front's dual gates; runtime E0004 = defense in depth, not the
/// front path).
#[allow(clippy::result_large_err)] // error path (carries the full diagnostic structure) — same entry-point convention
fn verify_unbound_refs(
    items: &[ModuleItem],
    program: &BcProgram,
    face: &ImportFace,
    extern_face: &ExternFace,
    table: &mut SymbolTable,
    sm: &SourceMap,
) -> Result<(), DriverError> {
    // r47 / 68-b visibility tightening leg (22 §15 D55): visible-face
    // check — basis = N1 core face (visible with zero declarations) ∪
    // import flat runtime payload (face.flat_underlying — incl. the
    // prelude re-export margin) ∪ the program define face. The runtime
    // registration face keeps the full set (dispatch-table basis —
    // visibility payloading at the front's E0022/E0014 dual gates; runtime
    // E0004 = defense in depth, not the front path).
    let mut defined: std::collections::HashSet<String> = crate::builtins::N1_CORE_NAMES
        .iter()
        .map(|s| s.to_string())
        .collect();
    for n in &face.flat_underlying {
        defined.insert(n.clone());
    }
    // r135 / member-rename-design.md v1.2 §8 D13-① note: the renamed
    // bindings' E0022 resolution is carried entirely by flat_underlying
    // — the seven modules' D3 replacement (flat push renamed), the
    // N1-domain derivation loop below (io/core/pair/char — flat push
    // renamed), and the prelude's incremental-alias double push (local +
    // renamed) all land in flat; a separate rename_binds chain here
    // would be redundant.
    let mut define_names: std::collections::HashSet<String> = std::collections::HashSet::new();
    for item in items {
        collect_define_names_item(item, table, &mut define_names);
    }
    defined.extend(define_names.iter().cloned());
    // r137 / 207-c (D7 — ffi-language-surface-design §3): the extern
    // declaration names join the visible face — an extern call site's
    // global_ref resolves through the flat extern symbol space (the
    // name-only basis: hygiene-stripped base names hit identically).
    // r147 / 217-c (extern-alias-design D4): the replacement semantics —
    // the local binding name joins the visible face; the aliased
    // underlying does NOT (a direct underlying reference = the E0022
    // unbound-reference family, the r134 member-rename D8 reverse-anchor
    // isomorph). Unaliased = local == name: the historical face
    // bit-for-bit (principle 27)
    for e in &extern_face.entries {
        defined.insert(e.local.clone());
    }
    let gated_all: Vec<&str> = READ_GATED
        .iter()
        .chain(WRITE_GATED.iter())
        .copied()
        .collect();
    for sym in program.global_refs.iter().copied() {
        let raw = table.name(sym);
        // Qualified-name domain (containing `/`): E0014/E0006 semantic domain — does not participate
        if raw.contains('/') {
            continue;
        }
        if defined.contains(raw) {
            continue;
        }
        let base = hygienic_base(raw);
        if base != raw && defined.contains(base) {
            continue; // hygienic fallback resolution hit (same logic as runtime — moved forward to compile time)
        }
        if gated_all.contains(&raw) || gated_all.contains(&base) {
            continue; // unauthorized gated name → the E0006 semantic domain (R9 runs first)
        }
        let (shown, span) = match find_var_span(items, sym, table) {
            Some(s) => (raw.to_string(), s),
            None => (raw.to_string(), Span::dummy()),
        };
        // r47 message upgrade (D46 ③): per-layer detail + a single-source
        // import suggestion (suggest_import_for — underlying reverse
        // lookup + prelude high-frequency set first)
        let shown_name = if base != raw { base } else { shown.as_str() };
        let suggestion = crate::builtins::suggest_import_for(shown_name)
            .map(|m| {
                format!(
                    "N2 import injection face: not imported -- (import {}) available after",
                    m
                )
            })
            .unwrap_or_else(|| "N2 import injection face: no same-named module export".to_string());
        let note = if base != raw {
            format!(
                "`{}`(hygiene base name {} -- retreat parse miss)",
                shown, base
            )
        } else {
            format!("`{}`", shown)
        };
        let msg = format!(
            "unbound reference: {} -- already checked: N3 local binding(compile-time resolution)✗ · {} ✗ · N1 core face(operator/pair/predicate/gated)✗(R-N1 # 4 step; typo or missing import/define -- 22 §15 D55 visible face verify)",
            note, suggestion
        );
        let diag = Diagnostic::error(Some(UNBOUND_REF_CODE), msg, span);
        return Err(DriverError {
            stage: Stage::Compile,
            rendered: render_diagnostic(&diag, sm),
            diagnostic: diag,
        });
    }
    Ok(())
}

/// First-occurrence Span lookup for a symbol inside the CoreExpr tree
/// (for E0022 locating — explicit stack traversal guards against
/// deep-nesting stack overflow [same lesson as the r45 GC pressure-shape
/// migration]; children pushed in **reverse order** = pop order is
/// tree-order DFS — fn_expr before args [the compile-time mirror of the
/// Apply evaluation-order contract A1; span attribution keeps the fn
/// position first]).
fn find_var_span(items: &[ModuleItem], target: Symbol, table: &SymbolTable) -> Option<Span> {
    let _ = table;
    // Item-level expansion: declaration items have no Var nodes (the
    // Define name enters global_refs — sub-item attribution goes through
    // the value subtree; module body items expand recursively)
    let mut exprs: Vec<&Rc<CoreExpr>> = Vec::new();
    fn collect_exprs<'a>(items: &'a [ModuleItem], out: &mut Vec<&'a Rc<CoreExpr>>) {
        for item in items {
            match item {
                ModuleItem::Define { value, .. } => out.push(value),
                ModuleItem::Require { .. } => {}
                ModuleItem::Module { items: inner, .. } => collect_exprs(inner, out),
                ModuleItem::Expr(e) => out.push(e),
            }
        }
    }
    collect_exprs(items, &mut exprs);
    let mut stack: Vec<&Rc<CoreExpr>> = exprs.into_iter().rev().collect();
    while let Some(e) = stack.pop() {
        let mut children: Vec<&Rc<CoreExpr>> = Vec::new();
        match e.as_ref() {
            CoreExpr::Var { name, span, .. } => {
                if *name == target {
                    return Some(*span);
                }
            }
            CoreExpr::Literal { .. } => {}
            // Let arm: value + body dual subtrees (the user form of a
            // do→Let chain sits in the value slot — missing value would
            // miss the span attribution of the chain's first form)
            CoreExpr::Fn { body, .. } => children.push(body),
            CoreExpr::Let { value, body, .. } => {
                children.push(value);
                children.push(body);
            }
            // Assign target name (a non-Var carrier entering global_refs
            // via the StoreGlobal path — span attribution covers the
            // assignment position; r49: Define names belong to the
            // item-level expansion face)
            CoreExpr::Assign {
                name, span, value, ..
            } => {
                if *name == target {
                    return Some(*span);
                }
                children.push(value);
            }
            CoreExpr::Apply { fn_expr, args, .. } => {
                children.push(fn_expr);
                for a in args {
                    children.push(a);
                }
            }
            CoreExpr::If {
                cond,
                then_branch,
                else_branch,
                ..
            } => {
                children.push(cond);
                children.push(then_branch);
                children.push(else_branch);
            }
            CoreExpr::Perform { effect, .. } => children.push(effect),
            CoreExpr::Handle {
                handler_body, body, ..
            } => {
                children.push(handler_body);
                children.push(body);
            }
            // r136 / 206-b (TD-033 — D13): per-arm handler bodies + the
            // protected body
            CoreExpr::HandleGroup { arms, body, .. } => {
                for arm in arms {
                    children.push(&arm.handler_body);
                }
                children.push(body);
            }
        }
        stack.extend(children.into_iter().rev());
    }
    None
}

/// Item-level define-name collection (r49 D59 — Define item names +
/// module body recursion + expression items have zero defines
/// [structural guarantee: expression-position define is rejected by the
/// expander] — value subtrees need no recursion [define-free by
/// construction]).
fn collect_define_names_item(
    item: &ModuleItem,
    table: &SymbolTable,
    out: &mut std::collections::HashSet<String>,
) {
    match item {
        ModuleItem::Define { name, .. } => {
            out.insert(table.name(*name).to_string());
        }
        ModuleItem::Require { .. } => {}
        ModuleItem::Module { items, .. } => {
            for inner in items {
                collect_define_names_item(inner, table, out);
            }
        }
        ModuleItem::Expr(_) => {}
    }
}

/// Prelude injection (TD-021): programs declaring import → read the
/// preamble forms and prepend-merge them (**target-syntax production
/// artifact** — r109 / 179-a ruling 2: a corpus-syntax symmetric extension
/// on the same basis as fixed library artifacts and expander.krf — the
/// production path goes through the **.ktf reader bridge**
/// (re-parsed by the new Reader — 07 §3.2.1 step ③ literal semantics;
/// since r152 the bridge's own program is reader.ktf — the Reader
/// fixpoint milestone closure),
/// the seed path through the **seed Reader** (r6 symmetry); an
/// error in this file itself is impossible (constructive correctness +
/// guarded by the dual-Reader parity gate), Span attribution to
/// preamble.ktf as a separate file).
#[allow(clippy::result_large_err)] // error path (carries the full diagnostic structure) — same front entry-point convention, error size acceptable
fn resolve_prelude_imports(
    forms: Vec<Stx>,
    table: &mut SymbolTable,
    sm: &mut SourceMap,
    seed_pipeline: bool,
) -> Result<Vec<Stx>, DriverError> {
    // r74/144-d production switch: the injection decision goes through the
    // self-hosted build.krf (running on the VM — build-system segment,
    // first incision; seed oracle = imports_prelude_seed).
    // **Seed pipeline exemption** (an isomorphic extension of hard P1 —
    // r74/144-d): the seed path (compile_front_seed — all three stages
    // reader/expander/compiler are Rust seeds) decides via the Rust oracle
    // — build.krf itself is loaded via the seed pipeline; the exemption
    // blocks bootstrap self-reference (double entry while loading =
    // RefCell reentrancy + infinite recursion); the production path (any
    // self-hosted stage) goes through the .krf decision.
    // Internal defects are fail-closed (Stage::Expand + E0002 — an
    // unreachable protocol arm; the parity corpus + the full suite with
    // zero regressions guard its unreachability).
    //
    // r164 / 235-c (list-self-built-design.md D3/D4): dual decision — the
    // kerf-list injection (the seven self-built list-domain definitions)
    // CASCADES with kerf-prelude (preamble's module-header `import
    // kerf-list` declares the nth/drop re-export edge → a prelude import
    // implies the list body). Injection order: list FIRST, preamble after
    // (module declare's occurrence order = dependency order). Dual-path
    // discipline mirrored: seed = the Rust oracles (imports_list_seed ∨
    // imports_prelude_seed), production = build.ktf's generalized family
    // (imports_list ∨ imports_prelude — two entry invocations on the same
    // thread-local build state).
    let needed_prelude = if seed_pipeline {
        forms.iter().any(|f| imports_prelude_seed(f, table))
    } else {
        crate::bootstrap::build::imports_prelude(&forms, table).map_err(|e| {
            let diag = Diagnostic::error(Some(DiagnosticCode(2)), e.clone(), Span::dummy());
            DriverError {
                stage: Stage::Expand,
                rendered: e,
                diagnostic: diag,
            }
        })?
    };
    let needed_list = if seed_pipeline {
        needed_prelude || forms.iter().any(|f| imports_list_seed(f, table))
    } else {
        needed_prelude
            || crate::bootstrap::build::imports_list(&forms, table).map_err(|e| {
                let diag = Diagnostic::error(Some(DiagnosticCode(2)), e.clone(), Span::dummy());
                DriverError {
                    stage: Stage::Expand,
                    rendered: e,
                    diagnostic: diag,
                }
            })?
    };
    if !needed_prelude && !needed_list {
        return Ok(forms);
    }
    let mut injected: Vec<Stx> = Vec::new();
    // r164 / 235-c: kerf-list body FIRST (dependency order). Reading
    // discipline isomorphic to the preamble leg below: seed path = the
    // seed target Reader, production path = the .ktf reader bridge (the
    // Reader fixpoint carries the injected module body's reading too).
    if needed_list {
        let list_file_id = sm.add_file(LIST_FILENAME, LIST_SRC);
        let list_forms = if seed_pipeline {
            LIST_SEED_READS.with(|c| c.set(c.get() + 1));
            kerf_reader::read_source(LIST_SRC, list_file_id, table)
                .map_err(|e| DriverError::from_read(&e, sm))?
        } else {
            LIST_BRIDGE_READS.with(|c| c.set(c.get() + 1));
            crate::bootstrap::reader::read_source_for_bootstrap(LIST_SRC, list_file_id, table)
                .map_err(|e| DriverError::from_read(&e, sm))?
        };
        injected.extend(list_forms);
    }
    let file_id = sm.add_file(PREAMBLE_FILENAME, PREAMBLE_SRC);
    // r109 / 179-a ruling 2: preamble.ktf (target syntax) — the production
    // path re-parses via the .ktf reader bridge (the language's
    // resident new Reader becomes a production component for the first
    // time — 07 §3.2.1 step ③; the bridge thread_local lazily loads
    // reader.ktf itself via the seed pipeline's target-syntax
    // path — the Reader fixpoint milestone — and
    // the 9 corpus artifacts' imports consume zero kerf-prelude → zero
    // recursion cycle); the seed path goes through the seed Reader
    // (read_source — r6 symmetry: the Rust seed reads fixed library
    // artifacts). The two paths' Stx outputs are guarded by the
    // switch_corpus_parity_tests bytecode-equality gate (both Readers are
    // themselves guarded by the target_reader_krf_tests 32-case gate).
    if needed_prelude {
        let prelude = if seed_pipeline {
            PRELUDE_SEED_READS.with(|c| c.set(c.get() + 1));
            kerf_reader::read_source(PREAMBLE_SRC, file_id, table)
                .map_err(|e| DriverError::from_read(&e, sm))?
        } else {
            PRELUDE_BRIDGE_READS.with(|c| c.set(c.get() + 1));
            crate::bootstrap::reader::read_source_for_bootstrap(PREAMBLE_SRC, file_id, table)
                .map_err(|e| DriverError::from_read(&e, sm))?
        };
        injected.extend(prelude);
    }
    injected.extend(forms);
    Ok(injected)
}

// r109 liveness probe: actual execution count of prelude injection via
// the .ktf reader bridge (production path) (>0 = the production
// path is live — wiring proof of the switch window step ③ first batch;
// isomorphic to the `production_*_is_bootstrap` probe family).
thread_local! {
    static PRELUDE_BRIDGE_READS: Cell<u32> = const { Cell::new(0) };
}

// r109 liveness probe: actual execution count of prelude injection via
// the seed Reader (seed path) (>0 = the seed path's .ktf reading
// is live — the seed-side proof of the r6 symmetric wiring).
thread_local! {
    static PRELUDE_SEED_READS: Cell<u32> = const { Cell::new(0) };
}

// r164 / 235-c liveness probe: kerf-list body injection count via the
// .ktf reader bridge (production path) — wiring proof of the list-domain
// self-built migration's production leg (isomorphic to the prelude probe
// family above).
thread_local! {
    static LIST_BRIDGE_READS: Cell<u32> = const { Cell::new(0) };
}

// r164 / 235-c liveness probe: kerf-list body injection count via the
// seed Reader (seed path — the bootstrap corpus loads walk this leg: the
// seven list-importing artifacts' loads inject the self-built body).
thread_local! {
    static LIST_SEED_READS: Cell<u32> = const { Cell::new(0) };
}

/// Production-path prelude injection = .ktf reader bridge (liveness probe — r109).
pub fn production_prelude_is_ktf_reader() -> bool {
    PRELUDE_BRIDGE_READS.with(|c| c.get() > 0)
}

/// Seed-path prelude injection = seed Reader (liveness probe — r109).
pub fn seed_prelude_is_seed_reader() -> bool {
    PRELUDE_SEED_READS.with(|c| c.get() > 0)
}

/// Seed compile front end, target-syntax variant (Rust seed Reader +
/// Rust Expander + Rust Compiler — the bootstrap compilation path for
/// the switch window step ③ .ktf corpus).
///
/// Consumers: bootstrap Reader loading (reader.ktf — r110 / 180-a ruling
/// 4) + later batches (compiler.ktf/expander.ktf shared entry). Fully
/// isomorphic to [`compile_front_seed`] — the only variable = the read
/// stage goes through the seed Reader (`read_source`,
/// inherited from r109 ruling 2's r6 symmetry: the Rust seed reads fixed
/// library artifacts); expand/compile remain seed (hard P1 convention —
/// bootstrap loading is always the seed path, no recursion).
#[allow(clippy::result_large_err)] // error path (carries the full diagnostic structure) — same entry-point convention as above
pub(crate) fn compile_front_seed(source: &str, filename: &str) -> Result<FrontOutput, DriverError> {
    let mut sm = SourceMap::new();
    let file_id = sm.add_file(filename, source);
    let mut table = SymbolTable::new();
    let main_sym = table.intern("main");

    // 1. Reader (seed target face): .ktf source → Stx (naming map `_`→`-`, single point of entry)
    let forms = kerf_reader::read_source(source, file_id, &mut table)
        .map_err(|e| DriverError::from_read(&e, &sm))?;

    front_from_forms(
        forms,
        table,
        sm,
        main_sym,
        file_id,
        ExpanderKind::Seed,
        CompilerKind::Seed,
    )
}

/// Production compile front end, target-syntax variant — the switch-window
/// step (4) entry (07 §3.2.1: "use the compiler to compile the
/// target-syntax itself").
///
/// Read stage: the `.ktf` reader bridge
/// ([`crate::bootstrap::reader::read_source_for_bootstrap`] —
/// the language's resident new Reader, a production component since r109;
/// since r152 the bridge's own Reader program is reader.ktf — the
/// Reader fixpoint milestone closure);
/// expand stage: the self-hosted Expander (expander.ktf on the VM — E1-β);
/// compile stage: the self-hosted Compiler (compiler.ktf on the VM — I1).
/// Together with the .ktf-built bootstrap states (r110/r114/r116) this is
/// the literal step-(4) proposition: **the target-syntax compiler chain
/// compiles the target syntax itself** — the fixpoint prerequisite of step
/// (5) ("verify the target-syntax compiler compiling itself yields
/// equivalent output" — the B₁/B₂ hard gate in
/// switch_corpus_parity_tests).
///
/// Deliberately NOT wired to the cache (B11/P4 dimension separation, and
/// the fixpoint isolation discipline §7.4: a cached B₂ round would return
/// the B₁ entry — the false-positive defense line). Consumers: the step-(4)
/// fixpoint gate family + the cross-chain by-name oracle (i1 §7.3: names
/// are the only stable cross-chain caliber); the target-syntax test-runner
/// entry (r125 / 195-a dual-entry CLI face — bootstrap::test_runner::run_test_case).
#[allow(clippy::result_large_err)] // error path (carries the full diagnostic structure) — same entry-point convention as above
pub(crate) fn compile_front(source: &str, filename: &str) -> Result<FrontOutput, DriverError> {
    let mut sm = SourceMap::new();
    let file_id = sm.add_file(filename, source);
    let mut table = SymbolTable::new();
    let main_sym = table.intern("main");

    // 1. Reader (production target face): .ktf source → Stx via the .ktf
    // reader bridge (the resident new Reader on the VM — its own
    // program is reader.ktf since r152, the Reader fixpoint).
    let forms = crate::bootstrap::reader::read_source_for_bootstrap(source, file_id, &mut table)
        .map_err(|e| DriverError::from_read(&e, &sm))?;

    front_from_forms(
        forms,
        table,
        sm,
        main_sym,
        file_id,
        ExpanderKind::Bootstrap,
        CompilerKind::Bootstrap,
    )
}

/// Production full compilation, target-syntax variant (switch-window step
/// (4) — front + graph-IR lowering; isomorphic to [`compile_source`] except
/// the read stage goes through the reader bridge and the entry is
/// cache-free). See [`compile_front`] for the stage wiring and the
/// isolation rationale.
#[allow(clippy::result_large_err)] // error path (carries the full diagnostic structure) — same entry-point convention as above
pub fn compile_source(source: &str, filename: &str) -> Result<CompileOutput, DriverError> {
    let front = compile_front(source, filename)?;
    let ir = lower_program(&front.core);
    Ok(CompileOutput {
        core: front.core,
        ir,
        program: front.program,
        source_map: front.source_map,
        table: front.table,
        registry: front.registry,
        warnings: front.warnings,
    })
}

/// Front-end expander selection (E1-β production switch: production =
/// self-hosting Expander; seed path = Rust Expander — bootstrap loading
/// and parity oracle).
#[derive(Clone, Copy, PartialEq, Eq)]
enum ExpanderKind {
    /// Self-hosting Expander (expander.ktf running on the VM — production path).
    Bootstrap,
    /// Rust seed Expander (bootstrap compilation + parity oracle).
    Seed,
}

/// Front-end compiler selection (I1 production switch 42-d — i1-design
/// §6 P1: the dispatch site is step 4 of [`front_from_core`], mirroring
/// `ExpanderKind`).
///
/// Production = self-hosting Compiler (compiler.krf running on the VM);
/// seed path = Rust Compiler (bootstrap loading guidance + parity oracle
/// — "the classic role of the bootstrap seed" 07 §3.2). Cache basis
/// (B11/P4): the key includes this dimension — seed and self-hosted
/// artifacts must not share cache entries.
#[derive(Clone, Copy, PartialEq, Eq)]
pub enum CompilerKind {
    /// Self-hosting Compiler (compiler.ktf on the VM — production path).
    Bootstrap,
    /// Rust seed Compiler (bootstrap compilation + parity oracle).
    Seed,
}

/// Front-end common part (after read: expand → phase bookkeeping →
/// bytecode).
///
/// Shared by the two entries (self-hosting/seed) — guaranteeing a single
/// implementation of pipeline behavior other than read and expand.
#[allow(clippy::result_large_err)] // error path (carries the full diagnostic structure) — same entry-point convention as above
fn front_from_forms(
    forms: Vec<Stx>,
    mut table: SymbolTable,
    mut sm: SourceMap,
    main_sym: Symbol,
    file_id: FileId,
    expander: ExpanderKind,
    compiler: CompilerKind,
) -> Result<FrontOutput, DriverError> {
    // 1.5 TD-021 prelude module injection (import resolution — after read,
    // before expand: forms-level merge, a single compilation unit; Span
    // points to preamble.ktf (a separate file)).
    // r74/144-d: seed pipeline exemption decision (seed = Rust oracle;
    // production = build.krf)
    let seed_pipeline = matches!(
        (expander, compiler),
        (ExpanderKind::Seed, CompilerKind::Seed)
    );
    let forms = resolve_prelude_imports(forms, &mut table, &mut sm, seed_pipeline)?;

    // 1.6 Batch M second piece M2 (r40) import face collection (Stx-layer
    // header-region traversal — the declaration face before expand:
    // module names/alias pairs/injected names; after expand CoreExpr
    // carries no alias information, so this face is the sole data source
    // of R-N5 alias normalization and E0013/E0019)
    let face = collect_import_face(&forms, &table, &sm)?;
    let import_targets = collect_import_targets(&forms, &table);
    // 1.58 r42 / S1 removal round: W1003 macro-name collection (Stx
    // layer — the declaration face before expand; a macro name identical
    // to a builtin registration-face name → W-level notification
    // [22 §11 D11])
    let macro_defs = collect_macro_names(&forms, &table);

    // 1.62 r135 / member-rename-design.md v1.2 §8 D14: prelude member-rename
    // binding injection (Stx layer — the preamble injection's isomorph):
    // for each prelude rename triple a `(define renamed local)` form is
    // injected **after the preamble segment, before the user forms** (the
    // module-body defines are ahead in the same forms sequence — the
    // local is bound first, the renamed alias after); the renamed
    // binding's runtime value = the define face (program global
    // execution — zero run_front involvement: prelude members are not
    // builtin-registry names). Span = the import declaration's span
    // (diagnostic attribution anchor). N1-exempt renames (`cons as c`)
    // ride the same injection — the define face carries availability.
    // r164 / 235-c (list-self-built-design.md D3/D4): the prelude-rename
    // Stx-injection path extends to the SELF-BUILT list domain — `use
    // kerf_list::{nth as pick}` renames a define-face name (the injected
    // module-body define), so the runtime binding must come from an
    // injected `(define pick nth)` form (the r135 D14 isomorph; the Rust
    // globals-alias loop in run_front skips them — their underlying left
    // the builtin registry). The list module form precedes the user forms
    // (cascade order — list FIRST), so the injected define resolves.
    let selfbuilt_list_rename = |ns: &str, local: &str| {
        ns == "list" && crate::builtins::SELF_BUILT_LIST_NAMES.contains(&local)
    };
    let forms = if face.member_renames.iter().any(|(ns, _, _)| ns == "prelude")
        || face
            .member_renames
            .iter()
            .any(|(ns, local, _)| selfbuilt_list_rename(ns, local))
    {
        let mut injects: Vec<Stx> = Vec::new();
        for (idx, (ns, local, renamed)) in face.member_renames.iter().enumerate() {
            if ns != "prelude" && !selfbuilt_list_rename(ns, local) {
                continue;
            }
            // r135 D14-②: the injection's Span = the selection-list
            // element's own site (the user's `use` declaration — not the
            // preamble's module-header import; the parallel Span array's
            // same index)
            let inject_span = face
                .member_rename_spans
                .get(idx)
                .copied()
                .unwrap_or_else(Span::dummy);
            let define_sym = table.intern("define");
            let renamed_sym = table.intern(renamed.as_str());
            let local_sym = table.intern(local.as_str());
            injects.push(Stx::list(
                vec![
                    Stx::symbol(define_sym, inject_span, ScopeSet::new()),
                    Stx::symbol(renamed_sym, inject_span, ScopeSet::new()),
                    Stx::symbol(local_sym, inject_span, ScopeSet::new()),
                ],
                inject_span,
                ScopeSet::new(),
            ));
        }
        // Locate the preamble segment's end: the first form whose span's
        // file matches the user file (preamble forms carry preamble.ktf's
        // file id; a program with prelude renames necessarily declared
        // `use kerf_prelude` — the preamble segment is present)
        let inject_at = forms
            .iter()
            .position(|f| f.span.file_id == file_id)
            .unwrap_or(0);
        let mut out: Vec<Stx> = forms;
        let tail = out.split_off(inject_at);
        out.extend(injects);
        out.extend(tail);
        out
    } else {
        forms
    };

    // 1.65 r41 / 62-a deep review D10: E0020 reserved-word binding ban
    // (Stx source face — intercepted before expand; the sole carrier layer
    // for macro names/aliases; run/check/compile full path; the 1.62
    // injected defines pass the same ban — a renamed name colliding with
    // a reserved word is rejected here, fail-closed)
    verify_reserved_bindings_stx(&forms, &table, &sm)?;

    // 1.68 r46 / 67-b deep review D47: top-level import stripping (after
    // face collection [1.6] and the reserved-word check [1.65], before
    // expand — import has zero runtime semantics; after stripping the
    // expander's E0002 applies only to imports inside expression subtrees
    // / mid-body)
    // r137 / 207-c (D2): extern declarations join the same stripping —
    // the driver owns the whole declaration face, the expander never sees
    // an extern form
    //
    // 1.678 r137 / 207-c (D3): the extern face collection + five-fold
    // validation (shape / availability / contract / duplicates — the
    // capability gate runs post-expansion in front_from_core) + the
    // position discipline (top-level direct elements only)
    let extern_face = collect_extern_face(&forms, &face, &table, &sm)?;
    verify_extern_positions_stx(&forms, &table, &sm)?;
    let forms = strip_toplevel_imports(forms, &table);

    // 1.685 r49 / 70-b deep review D59: E0018 require position discipline
    // (Stx-layer traversal — intercepts source-level violations before
    // expansion [code point 18 and Stage::Compile contract preserved];
    // macro-produced expression-position require is backstopped by the
    // expander's Require-arm structural rejection)
    verify_require_positions_stx(&forms, &table, &sm)?;

    // 2. Expander: Stx → CoreExpr (visit = transformer registration complete)
    let core = match expander {
        ExpanderKind::Bootstrap => {
            let mut t = table;
            let core = crate::bootstrap::expander::expand_program(&forms, file_id, &mut t)
                .map_err(|e| DriverError::from_expand(&e, &sm))?;
            table = t;
            core
        }
        ExpanderKind::Seed => {
            let mut ectx = ExpandCtxt::new(table);
            let core =
                expand_program(&forms, &mut ectx).map_err(|e| DriverError::from_expand(&e, &sm))?;
            table = ectx.table;
            core
        }
    };

    front_from_core(
        core,
        face,
        import_targets,
        macro_defs,
        extern_face,
        table,
        sm,
        main_sym,
        file_id,
        compiler,
    )
}

/// Front-end core segment (after expand: R9 verification → phase
/// bookkeeping → bytecode — shared by [`check_source_recover`] (the
/// TD-013 recovery path) and [`front_from_forms`]: partial artifacts (core
/// after recovery skipped erroneous forms) and complete artifacts walk
/// the same downstream pipeline, behavior single-implemented (§12
/// optimal > minimal).
#[allow(clippy::result_large_err)] // error path (carries the full diagnostic structure) — same entry-point convention as above
#[allow(clippy::too_many_arguments)] // front pipeline shared segment (two entries converge — the parameter face is the pipeline segment list)
fn front_from_core(
    core: Vec<ModuleItem>,
    face: ImportFace,
    import_targets: Vec<(String, Span)>,
    macro_defs: Vec<(String, Span)>,
    extern_face: ExternFace,
    mut table: SymbolTable,
    sm: SourceMap,
    main_sym: Symbol,
    file_id: FileId,
    compiler: CompilerKind,
) -> Result<FrontOutput, DriverError> {
    // 2.45 r41 / 62-a deep review D10: E0020 reserved-word binding ban
    // (CoreExpr expansion output face — defense in depth: binding names
    // generated by macro templates also pass the ban; front full path)
    verify_reserved_bindings_core(&core, &table, &sm)?;

    // 2.5 Batch M second piece M2 (r40) — capability closure **first**
    // (21 §4.4: requirements ⊆ authorization — the E0006 enhanced form
    // precedes the R9 basic form: module-requirement violations are
    // reported first [carrying module attribution and hoisting guidance];
    // only a purely program-level missing declaration takes the basic
    // form) + import face verification (E0013 conflict / E0017 alias
    // duplication / E0019 unknown module) + E0016 in-module duplicate
    // define + E0018 require position discipline (fail-closed full-chain
    // blocking — same basis as R9; effective on the front pipeline's full
    // path)
    crate::capability::verify_capability_closure(&core, &table, &sm)?;
    verify_import_face(&face, &table, &sm, &import_targets)?;
    verify_module_define_duplicates(&core, &table, &sm)?;
    // E0018 require position discipline (r49 D59 moved forward to the Stx
    // layer — carried by front_from_forms step 1.66; the recovery path
    // [check_source_recover] injects the same)

    // 2.55 R9 capability permission verification (r8 — 13 §3.1.3 clause 3
    // "compile-time error": effective on the front pipeline's full path
    // run/check/compile; the first violation blocks immediately,
    // fail-closed; the E0006 family is separate from E0005 static
    // checking)
    // r135 / member-rename-design.md v1.2 §8 D13: the renamed →
    // underlying lookup table is passed down — an unauthorized renamed
    // gated reference is caught via the reverse lookup with the
    // dual-name diagnostic; an authorized one rides the underlying's
    // grant token
    verify_io_capabilities(&core, &face.rename_binds, &table, &sm)?;
    // r137 / 207-c (D3-④): the extern capability gate — post-expansion
    // (the Require face is a CoreExpr-declaration artifact; the FFI write
    // channel shares the io write authorization token)
    verify_extern_capabilities(&extern_face, &core, &sm)?;

    // 2.6 Batch M first piece M1 (r39) qualified-name verification
    // (22 §3.3 R-N3 no fallback + §7 reserved domain — E0014/E0015;
    // effective on the front pipeline's full path same as R9) + M2 alias
    // normalization verification (face.aliases — diagnostics carry the
    // original name + normalized face)
    verify_qualified_refs(&core, &face, &table, &sm)?;

    // 2.7 M2 alias qualified-name compile-time normalization (rewrite
    // after verify — E0014 diagnostics use the original name; after the
    // rewrite registry/compile/HM/runtime, the whole chain consumes
    // normalized qualified names)
    let core = rewrite_alias_refs(core, &face, &mut table);

    // 3. Phase bookkeeping: declare + visit (§8.9 — TD-021 multi-module:
    // all module forms are declared in occurrence order (prelude injection
    // first, user modules after), and the main module is visited (the last
    // module form — import-edge transitive-dependency visit; programs with
    // no module behave as in the single-module era: find_map falls back to
    // main)
    let mut registry = ModuleRegistry::new();
    // M2 stdlib pre-declare (import-edge legalization — the stdlib seven
    // modules are Rust builtin modules (M1 shape: qualified names
    // registered directly), not in-program module forms; the visit
    // transitive-dependency check of a program module's `(import
    // kerf-string)` needs them present in the registry. Pre-set visited =
    // true (stdlib has no import edges — visit leaves; the semantics =
    // the N2 stdlib face is permanently present in phase bookkeeping).
    // **Except kerf-prelude**: preamble injection brings its own `(module
    // kerf-prelude ...)` form (the normal declare path — a pre-declaration
    // would conflict with it as a duplicate)
    // **Except kerf-list too** (r164 / 235-c — list-self-built-design.md
    // D3): the kerf-list injection brings its own `(module kerf-list ...)`
    // form (same duplicate-conflict shape as kerf-prelude); the injected
    // form's declare carries the real import edges (kerf-core/kerf-pair/
    // kerf-string — visit resolves them against the other pre-declared
    // stdlib leaves, the transitive-dependency semantics preserved)
    for stdlib_name in RESERVED_ALLOW {
        if *stdlib_name == "kerf-prelude" || *stdlib_name == "kerf-list" {
            continue;
        }
        let sym = table.intern(stdlib_name);
        let _ = registry.declare(sym, vec![], vec![]);
        let _ = registry.visit(sym);
    }
    let mut main_module_span = Span::dummy();
    for e in core.iter() {
        if let ModuleItem::Module {
            name,
            imports,
            exports,
            span,
            ..
        } = e
        {
            let owned_imports = imports.clone();
            let owned_exports = exports.clone();
            registry
                .declare(*name, owned_imports, owned_exports)
                .map_err(|m| {
                    // Declare errors are hung on that module form's Span
                    // (diagnostic locating — a gate-review finding fixed:
                    // previously dummy with no locating + no rendering)
                    let diag = Diagnostic::error(Some(DiagnosticCode(2)), m.clone(), *span);
                    DriverError {
                        stage: Stage::Expand,
                        rendered: render_diagnostic(&diag, &sm),
                        diagnostic: diag,
                    }
                })?;
            main_module_span = *span;
        }
    }
    // Programs with no module form: main fallback declaration (mirrors
    // the old single-module behavior — visit presupposes an already-done
    // declare)
    if !core.iter().any(|e| matches!(e, ModuleItem::Module { .. })) {
        registry.declare(main_sym, vec![], vec![]).map_err(|m| {
            let diag = Diagnostic::error(Some(DiagnosticCode(2)), m.clone(), Span::dummy());
            DriverError {
                stage: Stage::Expand,
                rendered: render_diagnostic(&diag, &sm),
                diagnostic: diag,
            }
        })?;
    }
    let module_name = core
        .iter()
        .rev()
        .find_map(|e| match e {
            ModuleItem::Module { name, .. } => Some(*name),
            // _ arm rationale: non-module top items do not participate in
            // the lookup (rev takes the last one — the main module = the
            // user module (prelude injection order is earlier))
            _ => None,
        })
        .unwrap_or(main_sym);
    registry.visit(module_name).map_err(|m| {
        // Visit errors are hung on the main module form's Span (locating
        // circular dependencies / undeclared imports — a gate-review
        // finding fixed: previously dummy with no locating + no rendering)
        let diag = Diagnostic::error(Some(DiagnosticCode(2)), m.clone(), main_module_span);
        DriverError {
            stage: Stage::Expand,
            rendered: render_diagnostic(&diag, &sm),
            diagnostic: diag,
        }
    })?;

    // 4. Compile: CoreExpr tree → bytecode (I1 production switch 42-d:
    // dispatch CompilerKind — mirrors ExpanderKind (i1-design §6 P1);
    // lowering runs only at the complete entry — see below)
    // r137 / 207-c (D4/D5): the extern face rides the compile entry —
    // the resolution layer's flat extern symbol space (empty face = the
    // historical behavior identical bit for bit).
    // r147 / 217-c (extern-alias-design D3): the two-name split — the
    // pair's Symbol = the source-level binding name (the local alias
    // when aliased; the underlying itself otherwise — the identity
    // default keeps the unaliased path bit-for-bit), the Rc<str> payload
    // = the flat FFI space name (IrVar::Extern carries it to
    // Op::CallExternal and the runtime table — the registry, contract,
    // capability and runtime faces all keep matching by the underlying)
    let externs_for_compile: Vec<(Symbol, std::rc::Rc<str>)> = extern_face
        .entries
        .iter()
        .map(|e| {
            let s = table.intern(e.local.as_str());
            (s, std::rc::Rc::from(e.name.as_str()))
        })
        .collect();
    let program = match compiler {
        // Seed arm rationale: the Rust compiler = bootstrap + parity
        // oracle (bootstrap loading is always the seed path — no
        // recursion, hard B5/P1 convention)
        CompilerKind::Seed => {
            kerf_compiler::compile_module_with_externs(&core, &externs_for_compile)
        }
        // Self-hosting arm rationale: compiler.ktf runs on the VM (the
        // compile_front production path — bridged via bootstrap_compiler)
        CompilerKind::Bootstrap => crate::bootstrap::compiler::compile_module_with_externs(
            &core,
            &externs_for_compile,
            file_id,
            &mut table,
        ),
    }
    .map_err(|e| DriverError::from_compile(&e, &sm))?;

    // 4.5 r46 / 67-b deep review D49 + r47 / 68-b D55: E0022 compile-time
    // unbound references (the carrier of R-N1 step 4 — basis = the
    // compiled artifact's global_refs [the compiler has already completed
    // local resolution] ∩ **visible face** [N1 core face ∪ import flat
    // payload ∪ define face — the post-r47-tightening basis]; fail-closed
    // on the front's full path, return on the first violation)
    // r137 / 207-c (D7): the extern declaration names join the visible
    // face (an extern call site's global_ref resolves through the face)
    verify_unbound_refs(&core, &program, &face, &extern_face, &mut table, &sm)?;

    // 5. M2 W warning collection (compile-success path — non-blocking;
    // Stx-layer import face + core tree dual data sources)
    let warnings = collect_warnings(&core, &table, &face, &macro_defs);

    Ok(FrontOutput {
        core,
        warnings,
        program,
        source_map: sm,
        table,
        registry,
        // r137 / 207-c (D6): the validated extern declarations staged for
        // run_front's runtime table construction (declaration ∩ available
        // registry ∩ capability grant)
        extern_decls: extern_face.entries,
        // r134 / member-rename-design.md v1.0 §3 D4: the staged runtime
        // bind pairs (renamed → underlying) — consumed by run_front's
        // post-registration injection (the compile face is untouched)
        member_rename_binds: face.rename_binds,
    })
}

/// Static check report (the data face of the `kerf check` subcommand and
/// external consumers — multi-error collection, the first consumption face
/// of the TD-013 design).
#[derive(Debug, Clone)]
pub struct CheckReport {
    /// All static diagnostics (Span order; E0005).
    pub diagnostics: Vec<Diagnostic>,
    /// Per-diagnostic rendered text (error[E0005] + `-->` position + source excerpt).
    pub rendered: Vec<String>,
    /// Whether the compile front end hit the cache (observation face of the incremental-compilation infrastructure).
    pub cache_hit: bool,
    /// Whether the program declares read capability ((require io read) — r8 capability observation face).
    pub io_read: bool,
    /// Whether the program declares write capability ((require io write) — same as above).
    pub io_write: bool,
    /// Prototype count.
    pub proto_count: usize,
    /// Constant pool size.
    pub const_count: usize,
    /// Global reference count.
    pub global_ref_count: usize,
    /// Total instruction count.
    pub instruction_count: usize,
    /// W-level diagnostics (M2 — non-blocking; the rendering face shares a channel with error diagnostics).
    pub warnings: Vec<Diagnostic>,
}

/// HM default-period production decision (r80 / 150-b — the check.krf
/// path as the main decision + a narrow fallback face + fail-closed).
///
/// Routing ([`crate::bootstrap::check::production_check`]):
/// - `Krf(items)` → E0005 diagnostic reconstruction (Span = (file_id,
///   start, end) — expansion_id is not in the wire protocol, so the
///   reconstruction uniformly uses 0: part of the existing honest
///   boundary of message-level parity; the rendering has no
///   `(expansion N)` annotation);
/// - `Fallback(kind)` (perform/handle subset out of range) → narrow-face
///   fallback to the Rust oracle [`kerf_compiler::hm::hm_check_program`]
///   (effect corpus still decidable — the original diagnostics carry the
///   full Span/expansion_id);
/// - `Err` (bridge/check.krf internal defect) → `DriverError` fail-closed
///   (E0005 + Stage::Compile — bootstrap_build isomorphic discipline; the
///   parity corpus + the full suite guard its unreachability).
#[allow(clippy::result_large_err)] // error path (carries the full diagnostic structure) — same entry-point convention as check_source
fn type_check_diags(
    core: &[ModuleItem],
    renames: &[(String, String)],
    table: &mut SymbolTable,
    file_id: FileId,
) -> Result<Vec<Diagnostic>, DriverError> {
    match crate::bootstrap::check::production_check(core, renames, table) {
        Ok(crate::bootstrap::check::ProductionOutcome::Krf(items)) => Ok(items
            .into_iter()
            .map(|d| {
                Diagnostic::error(
                    Some(kerf_compiler::CHECK_DIAG_CODE),
                    d.message,
                    Span::new(file_id, d.start, d.end),
                )
            })
            .collect()),
        Ok(crate::bootstrap::check::ProductionOutcome::Fallback(_kind)) => {
            // Subset out of range (perform/handle effect corpus) —
            // narrow-face fallback to the Rust oracle (the diagnostic
            // face = hm_check_program's native diagnostics, carrying the
            // full Span/expansion_id; the kind's concrete value does not
            // participate in post-routing behavior)
            //
            // r135 / member-rename-design.md v1.2 §8 D12-②: the oracle's
            // sigs face = builtin_sigs_with_renames (the renamed →
            // underlying derivation — the same derivation the krf face
            // applies through TC-RENAME; krf ⊆ oracle maintained)
            let sigs = builtin_sigs_with_renames(table, renames);
            Ok(kerf_compiler::hm::hm_check_program(core, &sigs, table).diags)
        }
        Err(e) => {
            let diag = Diagnostic::error(
                Some(kerf_compiler::CHECK_DIAG_CODE),
                e.clone(),
                Span::dummy(),
            );
            Err(DriverError {
                stage: Stage::Compile,
                rendered: e,
                diagnostic: diag,
            })
        }
    }
}

/// Target-syntax static check, recovery mode (TD-013 implementation face —
/// the sole check entry since the E6 close-out: the S-expr twin
/// `check_source_recover` was deleted with the S-expr surface r154 /
/// 224-a; everything downstream of the read stage is implemented once
/// ([`check_recover_from_forms`] — single source: prelude injection →
/// Stx-layer guards → recovery expansion → partial-artifact pipeline →
/// HM type check → diagnostic merge/sort). Cache ruling: the recovery
/// path is not cached (putting partial artifacts in the cache would
/// pollute complete-artifact hits).
#[allow(clippy::result_large_err)] // error path (carries the full diagnostic structure) — same entry-point convention as above
pub fn check_source_recover(source: &str, filename: &str) -> Result<CheckReport, DriverError> {
    // 1. Reader (target-syntax bridge — error short-circuit: the lexical
    // level is not form-level recoverable, same boundary as the S-expr face)
    let mut sm = SourceMap::new();
    let file_id = sm.add_file(filename, source);
    let mut table = SymbolTable::new();
    let main_sym = table.intern("main");
    let forms = crate::bootstrap::reader::read_source_for_bootstrap(source, file_id, &mut table)
        .map_err(|e| DriverError::from_read(&e, &sm))?;
    check_recover_from_forms(forms, table, sm, main_sym, file_id)
}

/// Recovery-mode check shared tail (read stage excluded — single source
/// for the two syntax faces, r125 / 195-a: the pipeline behavior other
/// than the read stage is implemented once).
#[allow(clippy::result_large_err)] // error path (carries the full diagnostic structure) — same entry-point convention as above
fn check_recover_from_forms(
    forms: Vec<Stx>,
    mut table: SymbolTable,
    mut sm: SourceMap,
    main_sym: Symbol,
    file_id: FileId,
) -> Result<CheckReport, DriverError> {
    // 1.5 prelude injection (same order as front_from_forms: after read, before expand)
    // — r74/144-d: the recovery path is the production basis (self-hosting
    // three stages) → .krf decision
    let forms = resolve_prelude_imports(forms, &mut table, &mut sm, false)?;
    // 1.6 M2 import face collection (same order as front_from_forms)
    let face = collect_import_face(&forms, &table, &sm)?;
    let import_targets = collect_import_targets(&forms, &table);
    // 1.58 r42 / S1: W1003 macro-name collection (same order as front_from_forms)
    let macro_defs = collect_macro_names(&forms, &table);
    // 1.65 r41 / 62-a deep review D10: E0020 reserved-word binding ban
    // (Stx source face — same order as front_from_forms; the recovery path
    // likewise intercepts fail-closed)
    verify_reserved_bindings_stx(&forms, &table, &sm)?;
    // 1.68 r46 / 67-b deep review D47: top-level import stripping (same
    // order as front_from_forms — the recovery path on the same basis)
    // r137 / 207-c (D2/D3): the extern face collection + validation +
    // position discipline + stripping — same order as front_from_forms
    // (the recovery path shares the declaration face single source)
    let extern_face = collect_extern_face(&forms, &face, &table, &sm)?;
    verify_extern_positions_stx(&forms, &table, &sm)?;
    let forms = strip_toplevel_imports(forms, &table);
    // 1.685 r49 / 70-b: E0018 require position discipline (Stx layer — same-order mirror)
    verify_require_positions_stx(&forms, &table, &sm)?;
    // 2. Recovery expansion (self-hosting bridge — form by form; a
    // with_expander load failure is still a fatal Err)
    let recovered = crate::bootstrap::expander::expand_program_recover(&forms, file_id, &mut table)
        .map_err(|e| DriverError::from_expand(&e, &sm))?;
    let expand_count = recovered.diags.len();
    let core = recovered.core;
    // 3. Partial artifacts → downstream pipeline (R9 fail-closed +
    // bookkeeping + bytecode — shared front_from_core: short-circuit
    // boundary as documented above; compile segment = production basis
    // (self-hosting Compiler — check is a production subcommand face))
    let front = front_from_core(
        core,
        face,
        import_targets,
        macro_defs,
        // r137 / 207-c: the recovery path shares the extern face (the
        // declarations were collected + validated at the Stx layer before
        // the recovery expansion — the same face object flows down)
        extern_face,
        table,
        sm,
        main_sym,
        file_id,
        CompilerKind::Bootstrap,
    )?;
    // 4. Type checking (partial artifacts — HM default period: check.krf
    // path) + diagnostic merge + sorting
    let io_req = IoRequirements::from_items(&front.core);
    let mut table = front.table;
    let mut diagnostics: Vec<Diagnostic> = recovered
        .diags
        .into_sorted()
        .into_iter()
        .map(|e| Diagnostic::error(Some(DiagnosticCode(2)), e.message, e.span))
        .collect();
    let t_hm0 = std::time::Instant::now();
    let mut type_diags =
        type_check_diags(&front.core, &front.member_rename_binds, &mut table, file_id)?;
    if std::env::var_os("HM_PROF").is_some() {
        eprintln!("HM_SEGM: {}ms", t_hm0.elapsed().as_secs_f64() * 1e3);
    }
    diagnostics.append(&mut type_diags);
    diagnostics.sort_by(|a, b| {
        a.primary_span
            .file_id
            .cmp(&b.primary_span.file_id)
            .then(a.primary_span.start.cmp(&b.primary_span.start))
            .then(a.primary_span.end.cmp(&b.primary_span.end))
    });
    let rendered: Vec<String> = diagnostics
        .iter()
        .map(|d| render_diagnostic(d, &front.source_map))
        .collect();
    let warnings = front.warnings;
    let warnings_rendered: Vec<String> = warnings
        .iter()
        .map(|d| render_diagnostic(d, &front.source_map))
        .collect();
    let mut rendered = rendered;
    rendered.extend(warnings_rendered);
    Ok(CheckReport {
        proto_count: front.program.proto_count(),
        const_count: front.program.consts.len(),
        global_ref_count: front.program.global_refs.len(),
        instruction_count: front.program.total_instructions(),
        io_read: io_req.read,
        io_write: io_req.write,
        diagnostics,
        rendered,
        warnings,
        cache_hit: false, // the recovery path is not cached (ruling in the function docs)
    })
    .map(|mut r| {
        // Truncation notice (r7 design §2: after the cap, append a
        // warning-level summary line — reusing the rendered tail note; the
        // diagnostics count follows the collector and is not
        // double-listed)
        if expand_count >= EXPAND_DIAG_CAP {
            r.rendered.push(format!(
                "note: expand diagnostic reach limit {}(truncated -- diagnostic storm protection)",
                EXPAND_DIAG_CAP
            ));
        }
        r
    })
}

/// Expansion diagnostic cap (direct reference to the kerf-expander constant — zero magic numbers on the driver side).
const EXPAND_DIAG_CAP: usize = kerf_expander::MAX_DIAGNOSTICS;

/// Run artifacts: final value + live heap (the `GcRef`s in the value
/// reference that heap — rendering needs the heap alive).
pub struct RunOutcome {
    /// Final value.
    pub value: Value,
    /// The heap after execution (used by GC statistics and value rendering).
    pub heap: Heap,
    /// W-level diagnostics (W1002 shadowing family / W1003 macro-name
    /// shadowing family; CLI/test observation face).
    pub warnings: Vec<Diagnostic>,
}

impl std::fmt::Debug for RunOutcome {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("RunOutcome")
            .field("value", &self.value.type_name())
            .field("heap_slots", &self.heap.slot_count())
            .field("warnings", &self.warnings.len())
            .finish()
    }
}

/// Target-syntax execution (dual-entry CLI face — r125 / 195-a: the
/// two-Reader coexistence period entry form).
///
/// Mirror of [`run_source`] except the read stage goes through the
/// reader bridge (`.ktf` source → Stx). **Does not go through the
/// compilation cache** — same basis as [`compile_front`]: the
/// B11/P4 kind-tag bucket has no syntax dimension (the cache key is
/// source-content addressing + filename + kind; a target-syntax entry
/// would require a cache.krf key-protocol extension — registered as a
/// follow-up trigger-gated item, not silent sharing). The execution
/// segment is single-implemented ([`run_front`] — shared with the seed
/// twin [`run_source_seed`]: the two entries differ only in the
/// read/expand/compile stage selection).
#[allow(clippy::result_large_err)] // error path (carries the full diagnostic structure) — same entry-point convention as above
pub fn run_source(source: &str, filename: &str) -> Result<RunOutcome, DriverError> {
    let front = compile_front(source, filename)?;
    run_front(front)
}

/// Seed pipeline execution, target-syntax variant (the E6 replacement of
/// the retired `run_source_seed` oracle face: the Rust seed Reader
/// reads the `.ktf` source; expansion + compilation stay the Rust seed
/// stages — the P1 hard convention). The oracle face of the target-face
/// dual-path cross-check: the production chain [`run_source`]
/// (self-hosting three stages) vs this seed-chain entry — two independent
/// implementations, same source, same result (the audits and the two-path
/// gate family consume it). **Does not go through the compilation cache**
/// (seed artifacts never enter the production cache — B11/P4).
#[allow(clippy::result_large_err)] // error path (carries the full diagnostic structure) — same entry-point convention as above
pub fn run_source_seed(source: &str, filename: &str) -> Result<RunOutcome, DriverError> {
    let front = compile_front_seed(source, filename)?;
    run_front(front)
}

/// Front-end artifact execution core (value semantics — shared by
/// run_source and run_source_seed: the two entries differ
/// only in the front end (self-hosting/seed); the execution segment is
/// single-implemented).
#[allow(clippy::result_large_err)] // error path (carries the full diagnostic structure) — same entry-point convention as above
fn run_front(front: FrontOutput) -> Result<RunOutcome, DriverError> {
    let mut table = front.table;
    let warnings = front.warnings;
    let grant = IoGrant::from_requirements(IoRequirements::from_items(&front.core));
    let mut globals = register_globals(&mut table, &grant);
    // r134 / member-rename-design.md v1.0 §3 D4: member-rename runtime
    // injection — the renamed binding shares the underlying's dispatch
    // body (the qualified-name registration's flat analogue, builtins.rs
    // M1 shape); a lookup miss is skipped (defense path — prelude members
    // are define-face names, not builtin-registry ones: their renames go
    // through front_from_forms' Stx-layer injection [r135 D14], and this
    // loop's globals miss for them is the expected skip; io renames hit
    // when the grant registered the underlying — r135 D13-④)
    for (renamed, underlying) in &front.member_rename_binds {
        let u_sym = table.intern(underlying.as_str());
        if let Some(Value::Builtin(f)) = globals.get(&u_sym) {
            let r_sym = table.intern(renamed.as_str());
            let shared = Rc::clone(f);
            globals.insert(r_sym, Value::Builtin(shared));
        }
    }
    let program = front.program;
    let source_map = front.source_map;
    // Hygienic fallback resolution ($hyg$N suffix stripping)
    resolve_hygiene_fallbacks(&program, &mut table, &mut globals);
    let mut heap = Heap::new();
    // instantiate bookkeeping (Phase 0 execution)
    instantiate_registry(front.registry);
    // r137 / 207-c (D6 — ffi-language-surface-design §4): the runtime
    // extern symbol table construction — declaration ∩ available
    // registry ∩ capability grant (the five-fold front validation [D3]
    // already guaranteed the intersection is total; the residual grant
    // re-check is defensive fail-closed). Zero declarations → the empty
    // table ≡ the historical `run_program` behavior identical bit for
    // bit (principle 27 additivity).
    let grant_write = IoRequirements::from_items(&front.core).write;
    let externs = crate::ffi::extern_table_for(
        &front
            .extern_decls
            .iter()
            .map(|e| (e.name.clone(), e.param_kinds.clone(), e.ret_kind))
            .collect::<Vec<_>>(),
        grant_write,
    );
    kerf_vm::run_program_with_externs(&program, &mut globals, &mut heap, &externs)
        .map(|value| RunOutcome {
            value,
            heap,
            warnings,
        })
        .map_err(|e| DriverError::from_vm(&e, &source_map, &table))
}

fn instantiate_registry(mut registry: ModuleRegistry) {
    for entry in registry.entries().to_vec() {
        let _ = registry.instantiate(entry.name);
    }
}

// ---------------------------------------------------------------------------
// kerf test: case runner (r8 — consumer of the internal effect system: test short-circuit + error recovery)
// ---------------------------------------------------------------------------

/// Single test-case outcome.
#[derive(Debug, Clone)]
pub struct TestCaseOutcome {
    /// Case index (1-based).
    pub index: usize,
    /// Case form (core-expression rendering — truncated form).
    pub name: String,
    /// Whether the case passed (evaluation without error and value is not #f).
    pub pass: bool,
    /// Failure detail (effect payload — captured at any depth inside the case).
    pub detail: String,
}

/// Test report.
#[derive(Debug, Clone)]
pub struct TestReport {
    /// Per-case outcomes (source order).
    pub cases: Vec<TestCaseOutcome>,
    /// Number of passes.
    pub passed: usize,
    /// Number of failures.
    pub failed: usize,
}

impl TestReport {
    /// All cases passed.
    pub fn all_passed(&self) -> bool {
        self.failed == 0
    }
}

/// Test-case failure payload (typed escape through the effect system —
/// `perform_escape` fires from any depth inside the case body and
/// `handle_escape` captures it at the boundary: **test short-circuit**
/// (first error inside a case stops that case) + **error recovery**
/// (after boundary capture the next case continues — same-process state
/// isolation: every case gets a fresh global environment and heap).
pub(crate) struct TestFailure {
    pub(crate) detail: String,
}

/// Report failure from any depth inside a case (nested helper layers with zero
/// signature pollution — consumer face of the D-any-node design).
fn fail_test(detail: impl Into<String>) -> ! {
    crate::effects::perform_escape(TestFailure {
        detail: detail.into(),
    })
}

/// Execute a single case (nested helper layer — `fail_test` at the failure
/// point, at any depth, goes straight to the boundary; r49 D59 itemization —
/// prelude/case slices = `ModuleItem` sequences).
///
/// r87 / 157-b: this function is also the nested execution body invoked by
/// the fourth-incision (test-runner face) callback — the `bootstrap_test_runner`
/// bridge captures the front output and calls it via a Foreign callback
/// (fresh heap/globals — case isolation semantics unchanged).
pub(crate) fn run_case(
    prelude: &[ModuleItem],
    case: &ModuleItem,
    table: &SymbolTable,
    sm: &SourceMap,
    grant: &IoGrant,
) {
    // Layer 1: compile the slice (prelude ++ case)
    let mut slice = prelude.to_vec();
    slice.push(case.clone());
    let program = match kerf_compiler::compile_module(&slice) {
        Ok(p) => p,
        Err(e) => {
            let diag = kerf_span::Diagnostic::error(
                Some(kerf_span::DiagnosticCode(3)),
                e.message.clone(),
                e.span,
            );
            fail_test(format!(
                "case compile failed:{}",
                first_line(&kerf_span::render_diagnostic(&diag, sm))
            ))
        }
    };
    // Layer 2: execute in a fresh environment (state isolation)
    let mut run_table = table.clone();
    let mut globals = register_globals(&mut run_table, grant);
    let mut heap = Heap::new();
    // Hygiene fallback resolution (same rule as run_source — macro-introduced
    // global references stay reachable)
    resolve_hygiene_fallbacks(&program, &mut run_table, &mut globals);
    let value = match kerf_vm::run_program(&program, &mut globals, &mut heap) {
        Ok(v) => v,
        Err(e) => {
            let derr = DriverError::from_vm(&e, sm, table);
            fail_test(first_line(&derr.rendered).to_string())
        }
    };
    // Layer 3: assertion check (deepest nesting point: #f means failure, any
    // other value passes)
    assert_case_value(&value, &heap);
}

/// Value assertion (layer 3 — deepest nesting point: #f means failure, any
/// other value passes).
fn assert_case_value(value: &Value, heap: &Heap) {
    if matches!(value, Value::Bool(false)) {
        fail_test(format!(
            "assertion return #f(expected non- #f value) -- evaluate result {}",
            kerf_vm::render_value(value, heap)
        ));
    }
}

/// First-line extraction (diagnostic message compression).
fn first_line(s: &str) -> &str {
    s.lines().next().unwrap_or("")
}

/// Target-syntax token dump (dual-entry CLI face — r125 / 195-a: the
/// two-Reader coexistence period entry form).
///
/// Mirror of [`dump_tokens`] except the lexer goes through the
/// reader bridge (`.ktf` source → `Vec<ParityToken>`). The parity
/// token surface is the stable kind word (`fn`…`+`…`int`…) + payload —
/// rendered `kind[:payload]` per token with the same span column format
/// as [`dump_tokens`] (§14.9 self-debugging face consistency).
#[allow(clippy::result_large_err)] // error path (carries the full diagnostic structure) — same entry convention as above
pub fn dump_tokens(source: &str, filename: &str) -> Result<String, DriverError> {
    let mut sm = SourceMap::new();
    let file_id = sm.add_file(filename, source);
    let toks = crate::bootstrap::reader::lex_for_bootstrap(source, file_id)
        .map_err(|e| DriverError::from_read(&e, &sm))?;
    let mut out = String::new();
    for t in &toks {
        let name = match &t.payload {
            Some(p) => format!("{}:{}", t.kind, p),
            None => t.kind.clone(),
        };
        out.push_str(&format!("{:>4}..{:<4} {}\n", t.start, t.end, name));
    }
    Ok(out)
}

/// Target-syntax syntax-object dump (dual-entry CLI face — r125 / 195-a:
/// the two-Reader coexistence period entry form).
///
/// Mirror of [`dump_stx`] except the read stage goes through the
/// reader bridge (`.ktf` source → `Vec<Stx>`); the rendering loop
/// is shared verbatim (Stx is the syntax-neutral intermediate — principle
/// 31 skin/skeleton isomorphism: the two skins converge at the same Stx).
#[allow(clippy::result_large_err)] // error path (carries the full diagnostic structure) — same entry convention as above
pub fn dump_stx(source: &str, filename: &str) -> Result<String, DriverError> {
    let mut sm = SourceMap::new();
    let file_id = sm.add_file(filename, source);
    let mut table = SymbolTable::new();
    let forms = crate::bootstrap::reader::read_source_for_bootstrap(source, file_id, &mut table)
        .map_err(|e| DriverError::from_read(&e, &sm))?;
    let mut out = String::new();
    for f in &forms {
        out.push_str(&format!(
            "{}\n",
            f.render(&|s: Symbol| table.name(s).to_string())
        ));
    }
    Ok(out)
}
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn production_expander_is_bootstrap() {
        // E1-β production-switch guard (§2.3-11 empirical discrimination, not
        // inference): inside a dedicated thread (thread_local state with zero
        // residue) — before compiling, the self-hosted Expander is not loaded;
        // after compiling, it is loaded ⇒ the expansion stage of
        // compile_front indeed goes through bootstrap_expander
        // (running on the VM). Reworked to the target-syntax face at the E6
        // close-out (r154 / 224-a — the S-expr macro-product mark signal was
        // retired with the S-expr surface; the load-liveness probe remains
        // the primary empirical signal).
        let ok = std::thread::spawn(|| {
            let before = crate::bootstrap::expander::is_loaded();
            let src = "fn main() -> int { 41 + 1 }";
            let front = compile_front(src, "t.ktf").expect("compile failed");
            let after = crate::bootstrap::expander::is_loaded();
            (before, after, front.program.total_instructions() > 0)
        })
        .join()
        .expect("probe thread failed");
        assert!(
            !ok.0,
            "independent thread start should not load bootstrap Expander"
        );
        assert!(
            ok.1,
            "production compile after bootstrap Expander should be loaded(VM path liveness)"
        );
        assert!(ok.2, "production products should be non-empty bytecode");
    }

    #[test]
    fn production_compiler_is_bootstrap() {
        // I1 production-switch guard (§2.3-11 empirical discrimination, not
        // inference — mirrors production_expander_is_bootstrap): inside a
        // dedicated thread (thread_local state with zero residue) — before
        // compiling, the self-hosted Compiler is not loaded; after production
        // compiling, it is loaded ⇒ the compilation stage of
        // compile_front indeed goes through bootstrap_compiler
        // (compiler.ktf running on the VM); second signal: the seed path
        // (compile_front_seed) does not load the self-hosted Compiler
        // (bootstrap loading always takes the seed path — the empirical face
        // of the P1 hard convention). Reworked to the target-syntax face at
        // the E6 close-out (r154 / 224-a).
        let prod = std::thread::spawn(|| {
            let before = crate::bootstrap::compiler::is_loaded();
            let src = "fn main() -> int { 40 + 2 }";
            let front = compile_front(src, "guard.ktf").expect("compile failed");
            let after = crate::bootstrap::compiler::is_loaded();
            (before, after, front.program.total_instructions() > 0)
        })
        .join()
        .expect("probe thread failed");
        assert!(
            !prod.0,
            "independent thread start should not load bootstrap Compiler"
        );
        assert!(
            prod.1,
            "production compile after bootstrap Compiler should be loaded(VM path liveness)"
        );
        assert!(prod.2, "production products should be non-empty bytecode");
        let seed = std::thread::spawn(|| {
            let before = crate::bootstrap::compiler::is_loaded();
            let front = compile_front_seed("fn main() -> int { 40 + 2 }", "seed-guard.ktf");
            let after = crate::bootstrap::compiler::is_loaded();
            (before, after, front.is_ok())
        })
        .join()
        .expect("seed probe thread failed");
        assert!(
            !seed.0,
            "seed probe threads should also start unloaded (isolation precondition)"
        );
        assert!(
            !seed.1,
            "seed paths must not load the bootstrap Compiler(bootstrapping is always seed)"
        );
        assert!(seed.2, "seed compile should succeed");
    }

    #[test]
    fn read_error_is_rendered() {
        // Target-syntax read error: unclosed string literal (E0001 — the
        // lexical family; the S-expr twin retired with the S-expr surface).
        let err = run_source("fn main() -> int { let s = \"abc; 0 }", "bad.ktf").unwrap_err();
        assert_eq!(err.stage, Stage::Read);
        assert!(err.rendered.contains("bad.ktf"));
    }

    #[test]
    fn expand_error_is_rendered() {
        // Target-syntax expand error: the derived-sugar validator family —
        // `cond` with a non-list clause (E0002, measured: the same
        // production path the r153 CLI convergence probes).
        let err = run_source(
            "fn main() -> int { let x = 5; cond(x > 3, 100, 200) }",
            "bad.ktf",
        )
        .unwrap_err();
        assert!(err.to_string().contains("[expand]"));
    }

    #[test]
    fn compile_output_dumps() {
        let out = compile_source("fn main() -> int { 1 + 2 }", "t.ktf").unwrap();
        assert!(out.disassemble().contains("CALL"));
        assert!(out.ir.len() >= 3);
    }

    #[test]
    fn fast_path_bytecode_matches_full_compile() {
        // TD-015 split guard (target face since E6): the run fast path
        // (compile_front — no IR) and the full compilation
        // (compile_source — with IR lowering) must produce identical
        // bytecode for the same source — preventing compilation-logic drift
        // between the two exits (the §7.2 anti-collapse check Q2:
        // correct-in-isolation → fails-on-integration).
        let src = "fn f(x: int) -> int { x + 1 } fn main() -> int { f(2) }";
        let full = compile_source(src, "t.ktf").unwrap();
        let front = compile_front(src, "t.ktf").unwrap();
        let full_text = full.disassemble();
        let front_text =
            disassemble_program(&front.program, &|s: Symbol| resolve_symbol(s, &front.table));
        assert_eq!(
            full_text, front_text,
            "fast path and full compilation bytecode must be instruction-identical"
        );
    }
}

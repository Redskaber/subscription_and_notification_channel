//! In-memory compilation cache (Stage 1 batch C — the concrete delivery of
//! the three-method spec in
//! [13-capability-matrix §3.1.4](../../docs/lang-design/13-capability-matrix.md);
//! the foundation for §21.3 Stage 1 condition 4 "incremental compilation
//! infrastructure available").
//!
//! **Two entry layers** (§11 interface isolation — frozen contract and
//! pipeline services separated):
//! - the frozen trait [`CompilationCache`] (reserved.rs v5.2 frozen
//!   signature): artifact-level query/write/invalidate — the
//!   `get_cached`/`store`/`invalidate` behavior spec landed clause by
//!   clause;
//! - the pipeline-rich entry (inherent): `lookup_front`/`store_front`
//!   carry the full front-end output (symbol table / source map / module
//!   bookkeeping) — the reuse face for the `run`/`eval`/`check` paths.
//!
//! **Key semantics** (content-addressed, spec clause 1): the `CacheKey`
//! frozen fields are `source_hash` (SHA-256 truncated to u64 — hash.rs) +
//! `config_fingerprint` (compilation config fingerprint = the stage-version
//! seed [`COMPILE_CONFIG_SEED`] + the source filename. Why the filename is
//! in the fingerprint: artifacts embed a SourceMap (Span → filename/line
//! rendering), so the same text under different filenames is **not
//! equivalent** — the spec's "source unchanged + config unchanged →
//! artifact necessarily equivalent" requires positional agreement for
//! position-carrying artifacts).
//!
//! **Reuse safety** (all three premises must hold; breaking any one loses
//! it):
//! 1. compilation determinism: same source and table → byte-identical
//!    artifacts (globals/consts are allocated in first-encounter order; no
//!    hash-iteration-order input);
//! 2. symbol-table idempotence: `intern` of the same name → the same
//!    Symbol — the table snapshot returned on a hit never conflicts with
//!    the builtin registration of a later `register_globals`;
//! 3. snapshot semantics: a hit returns a FrontOutput **clone** — runtime
//!    state (globals/heap/phase marks) is never mutated on cache entries.
//!
//! Error paths are not cached: a `compile_front` Err is not stored (the
//! error path recompiles — diagnostics may evolve across versions; the
//! error path has no performance pressure).

use std::cell::RefCell;
use std::collections::HashMap;

use kerf_compiler::BcProgram;
use kerf_core::ModuleItem;

use crate::driver::{CompilerKind, FrontOutput};
use crate::hash::content_hash64;
use crate::reserved::{CacheKey, CachedResult, CompilationCache};

/// The stage-version seed of the compilation config fingerprint (compiler
/// upgrade → change this constant → wholesale natural invalidation; the
/// key-path implementation of 13 §3.1.4 spec clause 3; unchanged when
/// Stage 2 deepens the query-based design).
pub const COMPILE_CONFIG_SEED: &str = "kerf-stage1-batchC-r7";

/// Cache entries (two tiers: pipeline-rich entries / trait artifact-level entries).
// r134: the Front variant grew by the member_rename_binds Vec (24B) and
// crossed the large_enum_variant threshold — the entry is an in-memory
// snapshot clone by design (premise 3), boxing it would add an
// indirection to every cache hit for no benefit (allow with rationale)
#[allow(clippy::large_enum_variant)]
enum CacheEntry {
    /// Pipeline-rich entry (written by store_front — reusable by
    /// run/eval/check).
    ///
    /// **E6 dormancy (r154 / 224-a)**: the sole production consumer of the
    /// pipeline-rich face (`compile_front_cached`) was deleted with the
    /// S-expr surface; the entry kind stays registered dormant for the
    /// target-path cache extension (a trigger-gated follow-up — the
    /// cache.ktf key-protocol extension registered in run_source's
    /// contract note; TD-0XX in tech-debt-register).
    #[allow(dead_code)]
    Front(FrontOutput),
    /// Artifact-level entry (written by trait `store` — serves
    /// `get_cached` only; no symbol table / source map, so pipeline paths
    /// treat it as a miss).
    Artifacts(BcProgram, Vec<ModuleItem>),
}

/// Cache observation statistics (data-driven principle §2.1 — the measurable face of the hit rate).
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct CacheStats {
    /// Hit count (trait queries and pipeline queries both included).
    pub hits: usize,
    /// Miss count.
    pub misses: usize,
    /// Store count (store_front + trait store).
    pub stores: usize,
    /// Invalidation count (single-key invalidate + the accumulated entry count of wholesale invalidations).
    pub invalidations: usize,
}

/// In-memory compilation cache (single-threaded session cache — the thread_local instance is below).
pub struct InMemoryCompilationCache {
    entries: HashMap<CacheKey, CacheEntry>,
    enabled: bool,
    stats: CacheStats,
}

impl InMemoryCompilationCache {
    /// Empty cache (enabled by default).
    pub fn new() -> Self {
        InMemoryCompilationCache {
            entries: HashMap::new(),
            enabled: true,
            stats: CacheStats::default(),
        }
    }

    /// Whether enabled.
    pub fn enabled(&self) -> bool {
        self.enabled
    }

    /// Enable/disable (when disabled, pipeline paths compile directly — for benchmark comparison / debugging).
    pub fn set_enabled(&mut self, enabled: bool) {
        self.enabled = enabled;
    }

    /// Statistics snapshot.
    pub fn stats(&self) -> CacheStats {
        self.stats
    }

    /// Entry count.
    pub fn entry_count(&self) -> usize {
        self.entries.len()
    }

    /// Pipeline-rich lookup: a hit returns a FrontOutput clone (snapshot
    /// semantics). pub(crate): FrontOutput is a crate-internal form;
    /// external consumers reach the cache indirectly via the
    /// [`crate::driver`] entries (run/eval/check).
    pub(crate) fn lookup_front(&mut self, key: &CacheKey) -> Option<FrontOutput> {
        let hit = matches!(self.entries.get(key), Some(CacheEntry::Front(_)));
        if hit {
            self.stats.hits += 1;
            // unwrap safety: the matches! above confirmed the Front variant
            match self.entries.get(key) {
                Some(CacheEntry::Front(front)) => Some(front.clone()),
                _ => unreachable!("already confirm is Front entry"),
            }
        } else {
            self.stats.misses += 1;
            None
        }
    }

    /// Pipeline-rich store (same-key overwrite — idempotent, same rule as
    /// trait store). pub(crate) — same scope as [`lookup_front`].
    ///
    /// **E6 dormancy (r154 / 224-a)**: dormant with its consumer
    /// (`compile_front_cached` deleted with the S-expr surface) — kept for
    /// the trigger-gated target-path cache extension; see the CacheEntry
    /// note.
    #[allow(dead_code)]
    pub(crate) fn store_front(&mut self, key: CacheKey, front: FrontOutput) {
        self.entries.insert(key, CacheEntry::Front(front));
        self.stats.stores += 1;
    }

    /// Wholesale invalidation (compiler-upgrade scenario — entries cleared; statistics kept, invalidation count accumulated).
    pub fn invalidate_all(&mut self) {
        self.stats.invalidations += self.entries.len();
        self.entries.clear();
    }
}

impl Default for InMemoryCompilationCache {
    fn default() -> Self {
        Self::new()
    }
}

// Root-space attribution declaration (r62/107-a — compiler-internal
// space reified entities explicitly declare their attribution: "the space
// is fixed, the points move"; to declare is to attribute, zero runtime
// overhead — principle 40).
impl crate::reserved::RootSpace for InMemoryCompilationCache {}
impl crate::reserved::ExtensionSpace for InMemoryCompilationCache {}
impl crate::reserved::ToolchainDomain for InMemoryCompilationCache {}

// Frozen trait implementation (reserved.rs §3.1.4 signature — behavior spec clauses 1/2/3 landed one by one).
impl CompilationCache for InMemoryCompilationCache {
    /// Spec clause 1: a key hit returns the artifacts (content-addressed — directly reusable).
    fn get_cached(&self, key: &CacheKey) -> Option<CachedResult> {
        match self.entries.get(key) {
            Some(CacheEntry::Front(front)) => Some(CachedResult {
                program: front.program.clone(),
                core: front.core.clone(),
                // code_value: a compute-on-demand face (query-based
                // semantics — cache entries are not required to carry it;
                // consumers compute it via CodeValue::from_expr)
                code_value: None,
            }),
            Some(CacheEntry::Artifacts(program, core)) => Some(CachedResult {
                program: program.clone(),
                core: core.clone(),
                code_value: None,
            }),
            None => None,
        }
    }

    /// Spec clause 2: store into the cache (idempotent — same-key overwrite).
    fn store(&mut self, key: CacheKey, result: CachedResult) {
        self.entries
            .insert(key, CacheEntry::Artifacts(result.program, result.core));
        self.stats.stores += 1;
    }

    /// Spec clause 3: explicit invalidation (source changes are naturally distinguished by the key hash; used here for single-key invalidation).
    fn invalidate(&mut self, key: &CacheKey) {
        if self.entries.remove(key).is_some() {
            self.stats.invalidations += 1;
        }
    }
}

thread_local! {
    /// Session-level cache instance (per-thread — test threads are naturally isolated, no cross-test pollution).
    static CACHE: RefCell<InMemoryCompilationCache> =
        RefCell::new(InMemoryCompilationCache::new());
}

/// Access the session cache (a thread_local borrow wrapper).
pub fn with_cache<R>(f: impl FnOnce(&mut InMemoryCompilationCache) -> R) -> R {
    CACHE.with(|c| f(&mut c.borrow_mut()))
}

/// Construct a cache key (source text + filename + compiler kind → a
/// content-addressed key).
///
/// **The CompilerKind dimension (B11/P4 — the i1-design §6 switch point)**:
/// seed and self-hosting artifacts must not share cache entries — the
/// dimension enters the `config_fingerprint` composition layer (the
/// `CacheKey` frozen field structure is untouched — the v5.2
/// interface-reserve discipline; the production entry is always Bootstrap
/// and the seed reference path bypasses the cache, so key discrimination
/// is the defensive kind-bucketing field-test face).
pub fn cache_key(source: &str, filename: &str, kind: CompilerKind) -> CacheKey {
    let kind_tag = match kind {
        CompilerKind::Bootstrap => "bootstrap",
        CompilerKind::Seed => "seed",
    };
    CacheKey {
        source_hash: content_hash64(source.as_bytes()),
        config_fingerprint: content_hash64(
            format!("{}|{}|{}", COMPILE_CONFIG_SEED, filename, kind_tag).as_bytes(),
        ),
    }
}

/// Session cache statistics snapshot.
pub fn cache_stats() -> CacheStats {
    with_cache(|c| c.stats())
}

/// Session cache entry count.
pub fn cache_entry_count() -> usize {
    with_cache(|c| c.entry_count())
}

/// Enable/disable the session cache (when disabled, the pipeline compiles directly — for benchmark comparison).
pub fn set_cache_enabled(enabled: bool) {
    with_cache(|c| c.set_enabled(enabled));
}

/// Whether the session cache is enabled.
pub fn cache_enabled() -> bool {
    with_cache(|c| c.enabled())
}

/// Reset the session cache (entries + statistics zeroed — for test isolation).
pub fn cache_reset() {
    with_cache(|c| {
        *c = InMemoryCompilationCache::new();
    });
}

/// Wholesale invalidation (compiler-upgrade scenario — the wholesale form of spec clause 3; statistics kept).
pub fn cache_invalidate_all() {
    with_cache(|c| c.invalidate_all());
}

/// Empty program for tests (BcProgram has no Default — all fields empty + entry 0).
#[cfg(test)]
fn empty_program() -> BcProgram {
    BcProgram {
        protos: Vec::new(),
        consts: Vec::new(),
        entry: 0,
        global_refs: Vec::new(),
        module_name: None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use kerf_expander::phase::ModuleRegistry;
    use kerf_span::SourceMap;
    use kerf_syntax::SymbolTable;

    /// Spec clauses 1/2: store → get_cached hits; artifacts equal field by field.
    #[test]
    fn trait_store_then_get_hits() {
        let mut c = InMemoryCompilationCache::new();
        let key = CacheKey {
            source_hash: 1,
            config_fingerprint: 2,
        };
        assert!(c.get_cached(&key).is_none());
        c.store(
            key.clone(),
            CachedResult {
                program: empty_program(),
                core: Vec::new(),
                code_value: None,
            },
        );
        let got = c.get_cached(&key).expect("store should hit after");
        assert_eq!(got.core.len(), 0);
        assert!(got.code_value.is_none());
    }

    /// Spec clause 2: idempotent — same-key overwrite does not error and does not grow the entry count.
    #[test]
    fn trait_store_idempotent_overwrite() {
        let mut c = InMemoryCompilationCache::new();
        let key = CacheKey {
            source_hash: 7,
            config_fingerprint: 8,
        };
        let result = CachedResult {
            program: empty_program(),
            core: Vec::new(),
            code_value: None,
        };
        c.store(key.clone(), result.clone());
        c.store(key.clone(), result);
        assert_eq!(c.entry_count(), 1);
    }

    /// Spec clause 3: invalidate invalidates a single key.
    #[test]
    fn trait_invalidate_misses() {
        let mut c = InMemoryCompilationCache::new();
        let key = CacheKey {
            source_hash: 9,
            config_fingerprint: 10,
        };
        c.store(
            key.clone(),
            CachedResult {
                program: empty_program(),
                core: Vec::new(),
                code_value: None,
            },
        );
        c.invalidate(&key);
        assert!(c.get_cached(&key).is_none());
        assert_eq!(c.stats().invalidations, 1);
        // Invalidating a missing key does not count (idempotent invalidation)
        c.invalidate(&key);
        assert_eq!(c.stats().invalidations, 1);
    }

    /// Key properties: discriminates by source text + by filename + by config seed.
    #[test]
    fn cache_key_discriminates() {
        let a = cache_key("(+ 1 2)", "a.krf", CompilerKind::Bootstrap);
        let a2 = cache_key("(+ 1 2)", "a.krf", CompilerKind::Bootstrap);
        let b = cache_key("(+ 1 3)", "a.krf", CompilerKind::Bootstrap);
        let f = cache_key("(+ 1 2)", "b.krf", CompilerKind::Bootstrap);
        assert_eq!(a, a2);
        assert_ne!(a, b);
        assert_ne!(a, f);
    }

    /// B11/P4: CompilerKind kind bucketing — same source and name but a
    /// different kind yields a different key (seed and self-hosting
    /// artifacts never share entries — a field test of the key-layer
    /// defense; i1-design §6 P4 + the explicit test of the "cache entry
    /// sharing" mitigation item in the risk table).
    #[test]
    fn cache_key_buckets_by_compiler_kind() {
        let prod = cache_key("(+ 1 2)", "a.krf", CompilerKind::Bootstrap);
        let seed = cache_key("(+ 1 2)", "a.krf", CompilerKind::Seed);
        assert_ne!(
            prod, seed,
            "same-source same-name different CompilerKind keys must differ (B11 bucketing -- mixed sharing means seed artifacts pollute the production cache)"
        );
    }

    /// B11/P4 integration face: a seed-key entry is never served to a
    /// production lookup (lookup_front misses across kinds — even with the
    /// same source and name).
    #[test]
    fn seed_bucket_entry_not_served_to_production_lookup() {
        let mut c = InMemoryCompilationCache::new();
        let seed_key = cache_key("(+ 1 2)", "k.krf", CompilerKind::Seed);
        let prod_key = cache_key("(+ 1 2)", "k.krf", CompilerKind::Bootstrap);
        let front = FrontOutput {
            warnings: Vec::new(),
            core: Vec::new(),
            program: empty_program(),
            source_map: SourceMap::new(),
            table: SymbolTable::new(),
            registry: ModuleRegistry::new(),
            // r134 / member-rename-design.md v1.0 §3 D4: the staged bind
            // pairs (empty = the no-rename baseline this mock represents)
            member_rename_binds: Vec::new(),
            // r137 / 207-c (ffi-language-surface-design §4/D6): the staged
            // extern declarations (empty = the no-extern baseline this
            // mock represents — the in-memory snapshot cache carries the
            // field automatically)
            extern_decls: Vec::new(),
        };
        c.store_front(seed_key, front);
        assert!(
            c.lookup_front(&prod_key).is_none(),
            "production queries must not return seed bucket entries (B11: after a seed hit the bootstrap path must not return seed artifacts)"
        );
        // Same-key hit (snapshot-semantics self-check — the seed bucket itself can hit)
        assert!(c
            .lookup_front(&cache_key("(+ 1 2)", "k.krf", CompilerKind::Seed))
            .is_some());
    }

    /// Trait artifact-level entries do not serve pipeline-rich lookups (a missing Front is treated as a miss).
    #[test]
    fn trait_store_degrades_for_pipeline() {
        let mut c = InMemoryCompilationCache::new();
        let key = CacheKey {
            source_hash: 11,
            config_fingerprint: 12,
        };
        c.store(
            key.clone(),
            CachedResult {
                program: empty_program(),
                core: Vec::new(),
                code_value: None,
            },
        );
        assert!(c.lookup_front(&key).is_none());
        assert!(c.get_cached(&key).is_some());
    }

    /// Wholesale invalidation: entries zeroed + statistics accumulated.
    #[test]
    fn invalidate_all_clears_entries() {
        let mut c = InMemoryCompilationCache::new();
        let key = CacheKey {
            source_hash: 13,
            config_fingerprint: 14,
        };
        c.store(
            key,
            CachedResult {
                program: empty_program(),
                core: Vec::new(),
                code_value: None,
            },
        );
        c.invalidate_all();
        assert_eq!(c.entry_count(), 0);
        assert_eq!(c.stats().invalidations, 1);
        assert_eq!(c.stats().stores, 1);
    }
}

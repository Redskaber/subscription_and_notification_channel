//! # kerf-space
//!
//! **Space hierarchy skeleton crate** (lang-design
//! [24 v2.0](../../docs/lang-design/24-space-decomposition.md)
//! two-sided unified system — r66 / 122-a: a Layer -1 skeleton layer with
//! **zero dependencies that all 10 crates depend on**; q2 Rust `core::marker`
//! isomorphic — the marker family sits at the root of the dependency graph so
//! the whole tree remains acyclic).
//!
//! **System overview** (24 §5.1 two-sided hierarchy chain — the compiler itself is the
//! root space):
//!
//! ```text
//! L0 root space RootSpace (the compiler itself — the root of all spaces; v2.0 renamed from ExtensibleRoot — 24 §11 N1 name-substance fix)
//! L1 core space CoreSpace (closed set — closed governance/A6)         | extension space ExtensionSpace (open set — open governance/A6)
//! L2 core domains ×7 (15 §5.3 five-axis macro consolidation)          | extension domains ×6 (capability/effect/metaprogramming/toolchain/foreign + optimization domain doc slot)
//! L3 core types (definition-is-implementation — three-layer explicit impl across the chain) | family contracts (20 — supertrait attaches to its owning domain)
//! L4 — (closed set has no implementation layer)                       | implementation bodies (Probe series + concretized seeds + future ecosystem — four-layer explicit impl across the whole chain)
//! ```
//!
//! **Seven hierarchy axioms** (24 §3 — A1-A7; v2.0 added A6/A7):
//!
//! | # | Axiom | Encoding in this crate |
//! |---|---|---|
//! | A1 | Unique root (commands the two first-level subspaces core + extension — **dual carriers**) | `RootSpace` + `CoreSpace`/`ExtensionSpace` dual supertraits |
//! | A2 | Hierarchy-only attachment (cross-level direct attachment = violation) | domain supertrait = owning first-level space; first-level space supertrait = root |
//! | A3 | Unique subordination (exceptions are loopholes — zero attachment is judged a violation alike) | each member has at most one domain supertrait (grep-auditable) |
//! | A4 | Orthogonal decomposition (sibling domains mutually exclusive; **core ∩ extension = ∅** — the concretized surface goes to extension L4) | domain markers: zero methods and zero associated types + zero cross-attachment between domains |
//! | A5 | Dependency direction (children may depend on parents; parents never depend on children — this crate's empty dependency set is that principle's physical extreme form) | supertrait chain points one way downward; bottom layer of the Cargo dependency graph |
//! | A6 | Open-closedness (**unified encoding, split governance** — the encoding surface uses one marker set for both sides; the only legitimate governance difference: core = closed [modify the compiler repo], extension = open [implement contracts anywhere]) | unified encoding (this file); governance split (process surface [23 §2.2] — no code expression) |
//! | A7 | Whole-tree unification and single source of truth (A1-A6 apply to the whole tree; **physical organization carries no space semantics — the sole subordination criterion = marker impl**) | crates/directories may be isomorphic to spaces but are not criterial |
//!
//! **Space relations = constraint-combination algebra, not class inheritance** (user
//! ruling: next8.md Round 2 — "conceptually you may call it inheritance for convenience,
//! but in substance it is not; there is a mathematical principle that explains it"):
//! Rust `trait A: RootSpace` means **constraint conjunction** (A's constraints include
//! the root constraint — `impl(A) ⊆ impl(RootSpace)` set intersection), not "inheriting
//! the root's implementation".
//!
//! **Natural difference in hierarchy depth** (24 §4.9 — the asymmetric defect of
//! open-closedness in structural expression): the core side has four levels
//! (root → core → domain → type — the closed set is **definition-is-implementation**
//! with no contract layer); the extension side has five levels
//! (root → extension → domain → contract → implementation body — the open set
//! **separates definition from implementation**).
//!
//! **Zero-payload discipline**: all markers have no methods, no associated types, and no
//! semantics (principle 1 minimalism within the family; compile-time existence with zero
//! runtime cost — principle 18).

/// Root space: the compiler itself — the root of all spaces (24 §3 A1 unique root).
///
/// Commands two first-level subspaces (A1's **dual carriers** — the v2.0 fix of the
/// "axiom-encoding asymmetry" [24 §1.2 V5]: `CoreSpace` + `ExtensionSpace`).
/// Implementation bodies (core types / extension contract implementations) explicitly
/// declare their space membership via `impl RootSpace for T {}` — declaration is
/// membership, with no runtime cost.
///
/// v2.0 renamed from `ExtensibleRoot` (24 §11 N1 — name-substance fix: "extensible"
/// modified the wrong noun — what is extensible is the extension space, not the root
/// itself; the three-term family unified as RootSpace/CoreSpace/ExtensionSpace).
pub trait RootSpace {}

/// Core space: a first-level subspace of the root (closed set — 24 §2.4/§3 A6).
///
/// Members = the **types** of the compiler's self-hosting components (the 10 crates'
/// primary types — explicit three-layer impl [root + core space + owning domain];
/// criterion = the primary type of a crate's public export surface, see the
/// 24 §7.2 incorporation table). **Closed governance**: changing membership =
/// modifying the compiler repository itself (under compiler-author jurisdiction —
/// existential enumeration is in substance "the author approves each one
/// individually", and the marker impl is the explicit archive of that approval).
///
/// v2.0 made it explicit (24 §1.2 V5 fix): the v1.0 ruling "the closed set sets up no
/// marker (existence is membership)" is overturned — the core space is no longer a
/// narrative space outside the system (no criterion / no carrier / no proof); it now
/// falls under the same axioms and review procedures as the extension space (A7
/// whole-tree unification — the placement of the user instruction "not special,
/// handle it explicitly").
pub trait CoreSpace: RootSpace {}

/// Extension space: a first-level subspace of the root (open set — 24 §2.4/§3 A6).
///
/// Membership = constraint satisfaction (implementing a domain contract is joining —
/// the whole-ecosystem joining channel of "open for extension"). **Concretized-surface
/// membership fix** (24 §4.8): concretized types such as `StdCapabilityIO` = L4 seed
/// implementations of this space (join by implementing the domain contract — not
/// core-space members; A4 L1 mutual exclusion restored).
///
/// v2.0 renamed from `ExtensibleSpace` (24 §11 N3 — the literal noun "extension space";
/// the naming family fully unified on nouns).
pub trait ExtensionSpace: RootSpace {}

// ---------------------------------------------------------------------------
// L2 core domains (seven domains — 24 §4.2: macro consolidation of the 15 §5.3 five
// orthogonal axes)
// Each domain = 1-2 crates clustered by responsibility; the primary-type three-layer
// impl incorporation table is in 24 §7.2
// ---------------------------------------------------------------------------

/// Core language domain: the defining artifacts of the language itself (what a program
/// is — core expressions / syntax objects / IR skeleton).
///
/// Member cluster: kerf-core (CoreExpr/IrGraph/CodeValue) + kerf-syntax
/// (Stx/ScopeSet/Symbol) — "core language syntax and skeleton".
pub trait CoreLanguageDomain: CoreSpace {}

/// Core front end domain: source code entering the compiler (lex/parse/read/macro
/// expansion — the first bridge from external representation to internal representation).
///
/// Member cluster: kerf-reader + kerf-expander — "how source gets in".
pub trait CoreFrontendDomain: CoreSpace {}

/// Core compile domain: program verification and compilation (typecheck standalone
/// inference + bytecode generation).
///
/// Member cluster: kerf-compiler — "how programs are verified and compiled".
pub trait CoreCompileDomain: CoreSpace {}

/// Core backend domain: target code generation (QBE IL / native code / multi-target
/// contracts).
///
/// Member cluster: kerf-backend — includes the `CodegenBackend`/`WasmBackend` contract
/// supertrait attachment (24 §1.2 V8 zero-attachment exception incorporation — the
/// core side's first pair of contracts).
pub trait CoreBackendDomain: CoreSpace {}

/// Core execution domain: running programs (VM execution / eval cross-checking / GC
/// heap / minimal I/O channel).
///
/// Member cluster: kerf-vm + kerf-runtime — "how programs run".
pub trait CoreExecutionDomain: CoreSpace {}

/// Core cross-cutting domain: positioning and diagnostics (Span/Diagnostic/SourceMap —
/// program-text metadata depended on by everyone).
///
/// Member cluster: kerf-span — "locating and reporting on program text".
pub trait CoreSpanDomain: CoreSpace {}

/// Core driver domain: assembly of the compilation pipeline (composition root — the only
/// part that knows all layers; pipeline chaining / self-hosting bootstrap driving).
///
/// Member cluster: kerf-driver backbone (driver.rs/bootstrap*) — "how the compiler is
/// organized".
pub trait CoreDriverDomain: CoreSpace {}

// ---------------------------------------------------------------------------
// L2 extension domains (six domains — 24 §4.1: first-level orthogonal subspaces of the
// extension space; the optimization domain has zero members and sets up no marker —
// the 24 §4.7 ruling stands, to be placed when the Stage 2+ window opens)
// ---------------------------------------------------------------------------

/// Capability domain: permission semantic payload (who may do what — ocap tokens /
/// gating / authorization transfer).
///
/// In-domain layering (abstract → concrete): model layer
/// (`CapabilityModelFamily`/`TokenCalculus`) → instance layer (`CapabilityIO`).
pub trait CapabilityDomain: ExtensionSpace {}

/// Effect domain: interception and recovery of side effects (how they happen —
/// perform/handle).
///
/// In-domain layering: family layer (`EffectFamily`) → instance layer (`Effect`) →
/// system layer (`EffectSystem`).
pub trait EffectDomain: ExtensionSpace {}

/// Metaprogramming domain: code manipulating code (quote/splice/phase manipulation).
///
/// Current member: `MultiStage` (multi-stage evaluation). v2.0 renamed from
/// `SyntaxDomain` (24 §11 N2 — semantic self-evidence: metaprogramming is not "syntax";
/// avoids confusion with the core-side language domain's "core syntax" — the both-sides
/// "Syntax" ambiguity source is eliminated).
pub trait MetaprogrammingDomain: ExtensionSpace {}

/// Toolchain domain: the compiler as a service and the surrounding ecosystem
/// (compile-time consumption surface — LSP/debugging/incremental/cache/package
/// management/AI).
///
/// In-domain layering: cache service (`CompilationCache`) → 11 ecosystem service
/// contracts.
pub trait ToolchainDomain: ExtensionSpace {}

/// Foreign domain: the interaction channel between kerf and the non-kerf world
/// (crossing the boundary — type mapping / pin protocol / calling conventions).
///
/// Boundary criterion (division of labor with the capability domain): **permissions
/// belong to the capability domain** (FFI tokens — model-layer instance anchor
/// `FfiTokenShape`), **channels belong to the foreign domain** (`FfiBoundary` boundary
/// mechanism) — collaboration, not subordination.
pub trait ForeignDomain: ExtensionSpace {}

#[cfg(test)]
mod tests {
    use super::*;

    /// Root-membership proof primitive (24 §5.3 — compile-time zero-value assertion):
    /// `require::<T>(None)` requires `T: RootSpace` — compilation passes if and only if
    /// the full supertrait chain is declared.
    fn require_root<T: RootSpace>(_: Option<T>) {}
    /// Core-domain membership proof primitive (core side —
    /// `T: CoreXxxDomain` ⟹ `T: CoreSpace` ⟹ `T: RootSpace`).
    fn require_core<T: CoreSpace>(_: Option<T>) {}
    /// Extension-domain membership proof primitive (extension side —
    /// `T: XxxDomain` ⟹ `T: ExtensionSpace` ⟹ `T: RootSpace`).
    fn require_extension<T: ExtensionSpace>(_: Option<T>) {}

    /// Core-side smoke test (24 §5.3, the core side of the two-sided smoke tests):
    /// three explicit layers (root + core + domain) — the chain length is exactly
    /// three; cross-level direct attachment (missing layers) = compile error (A2
    /// negative verification).
    #[test]
    fn core_side_hierarchy_chain_smoke() {
        struct CoreProbe;
        impl RootSpace for CoreProbe {}
        impl CoreSpace for CoreProbe {}
        impl CoreLanguageDomain for CoreProbe {}

        fn assert_core_domain<T: CoreLanguageDomain>(_: &T) {}
        fn assert_core_space<T: CoreSpace>(_: &T) {}
        fn assert_root<T: RootSpace>(_: &T) {}
        assert_core_domain(&CoreProbe);
        assert_core_space(&CoreProbe);
        assert_root(&CoreProbe);
        // Root anchor: transitive closure of the core-side three-layer chain
        require_root::<CoreProbe>(None);
        require_core::<CoreProbe>(None);
    }

    /// Extension-side smoke test (an existing v1.0 r65 migration — the v2.0 renamed
    /// version): four explicit layers (root + extension + domain + family; the family
    /// layer is omitted [family contracts carry abstract methods and are tested on the
    /// kerf-driver side]).
    #[test]
    fn extension_side_hierarchy_chain_smoke() {
        struct ExtensionProbe;
        impl RootSpace for ExtensionProbe {}
        impl ExtensionSpace for ExtensionProbe {}
        impl CapabilityDomain for ExtensionProbe {}

        fn assert_domain<T: CapabilityDomain>(_: &T) {}
        fn assert_extension<T: ExtensionSpace>(_: &T) {}
        fn assert_root<T: RootSpace>(_: &T) {}
        assert_domain(&ExtensionProbe);
        assert_extension(&ExtensionProbe);
        assert_root(&ExtensionProbe);
        require_root::<ExtensionProbe>(None);
        require_extension::<ExtensionProbe>(None);
    }

    /// Two-sided mutual-exclusion structure proof (24 §5.3 — the machine anchor of A4
    /// L1 mutual exclusion): the supertrait set of every core-domain marker excludes
    /// `ExtensionSpace`, and the supertrait set of every extension-domain marker
    /// excludes `CoreSpace` — the two generic constraint functions **compiling by
    /// definition** means the structure holds (every core-domain bound implies
    /// `T: CoreSpace` and every extension-domain bound implies `T: ExtensionSpace`;
    /// if any domain marker were wrongly attached to the opposite first-level space,
    /// this function's bound conjunction would be unsatisfiable — Rust supertrait
    /// transitivity turns the misattachment directly into a compile error). The
    /// signature is the proof (same discipline as the 40 proof functions in
    /// space_proofs.rs — being uncalled does not weaken the compile-time assertion).
    #[allow(dead_code)]
    fn dual_side_exclusive_structure_proof<
        T: CoreLanguageDomain
            + CoreFrontendDomain
            + CoreCompileDomain
            + CoreBackendDomain
            + CoreExecutionDomain
            + CoreSpanDomain
            + CoreDriverDomain,
        U: CapabilityDomain + EffectDomain + MetaprogrammingDomain + ToolchainDomain + ForeignDomain,
    >(
        _: Option<T>,
        _: Option<U>,
    ) {
        // The whole core-domain family ⟹ CoreSpace; the whole extension-domain family
        // ⟹ ExtensionSpace — both groups of bounds compiling = the domain markers'
        // supertrait membership is verified by the compiler (the structural face of A4
        // L1 mutual exclusion: CoreSpace and ExtensionSpace are siblings, not ancestor
        // and descendant; no domain belongs to both families).
    }

    /// Zero-payload anchor: all markers have no methods and no associated types
    /// (satisfiable by any zero-sized type — declaration is membership; the type-level
    /// endorsement of principle 18 zero cost).
    #[test]
    fn all_markers_are_zero_cost() {
        struct Zero;
        impl RootSpace for Zero {}
        impl CoreSpace for Zero {}
        impl ExtensionSpace for Zero {}
        impl CoreLanguageDomain for Zero {}
        impl CoreFrontendDomain for Zero {}
        impl CoreCompileDomain for Zero {}
        impl CoreBackendDomain for Zero {}
        impl CoreExecutionDomain for Zero {}
        impl CoreSpanDomain for Zero {}
        impl CoreDriverDomain for Zero {}
        impl CapabilityDomain for Zero {}
        impl EffectDomain for Zero {}
        impl MetaprogrammingDomain for Zero {}
        impl ToolchainDomain for Zero {}
        impl ForeignDomain for Zero {}
        // All 14 markers are satisfiable by the same zero-sized type — zero payload
        // verified empirically
        assert_eq!(std::mem::size_of::<Zero>(), 0);
    }
}

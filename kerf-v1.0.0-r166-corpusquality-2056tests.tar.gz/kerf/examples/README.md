# kerf 示例（examples/）

> **Author**: kerf-dev-agent
> **Date**: 2026-11-25（r161 / 231-c——常量声明面语料迁移：gc_stress 双件 keep 绑定 const 现代化——const-declaration-design.md D7）
> **Version**: v0.2.2
> **Status**: Active

演示与审计脚本（sop.md §9.6 目录规范：usage/ 长期保留 + audit/ 阶段审查归档）。

## usage/ —— 语言演示（`*.ktf` 单面，cargo CLI 运行）

**r153 / 223-c（S-expr 完全拆除窗 Batch D——[s-expr-removal-plan §4](../docs/develop/v0/stage-3/s-expr-removal-plan.md)）**：CLI 入口收敛 .ktf 单面（扩展名分派规则翻转——`.krf` 用户面入口拒收 fail-closed），usage 语料 15 对的 .krf 面退役（跨语法行为等价证据归档于 RELEASE r127-r152；行内跨语法等价纪律由 cli_entry_convergence_tests 承载）。语料 = `include_str!` 测试工件（ktf_corpus_tests + ktf_stress_corpus_tests 等语料完整性门）。

| 文件 | 演示内容 | 运行 |
|------|---------|------|
| `fib.ktf` | 递归基准（fn 声明 + require/print） | `kerf run examples/usage/fib.ktf` ⇒ 144 |
| `closures.ktf` | `||` 闭包 + 可变捕获 + define 调用形 | `kerf run examples/usage/closures.ktf` ⇒ 42 |
| `higher_order.ktf` | 高阶函数 + `list` 内建面 + `is_` 命名 | `kerf run examples/usage/higher_order.ktf` ⇒ (1 4 9 16 25) |
| `match.ktf` | match 第七映射全形态（守卫/序对拆构/or 标记——构造位元组面 r160） | `kerf run examples/usage/match.ktf` ⇒ fib-13 |
| `io.ktf` | import 模块面 + require 能力声明 | `kerf run examples/usage/io.ktf` ⇒ 42 |
| `effect.ktf` | perform/handle/resume 效应回路（演示形） | `kerf run examples/usage/effect.ktf` ⇒ 120 |
| `effect_stress.ktf` | 效应 GC 压力（handler 块体 resume 语句形——r128 文法清偿载体） | `kerf run examples/usage/effect_stress.ktf` ⇒ 120 |
| `effect_nested_resume.ktf` | 嵌套块 resume 全形态（if 臂/闭包捕获/嵌套 handle 双 κ——r133 窗载体） | `kerf run examples/usage/effect_nested_resume.ktf` ⇒ 540 |
| `effect_handle_expr.ktf` | handle 表达式位五形态（let 值位/实参位/if 条件位/嵌套 protected/group——r143 窗载体） | `kerf run examples/usage/effect_handle_expr.ktf` ⇒ 327 |
| `effect_multiarm.ktf` | handle 多臂 + 组安装语义（r132/r136 窗载体） | `kerf run examples/usage/effect_multiarm.ktf` ⇒ 217 |
| `gc_stress.ktf` | 10^6 量级分配堆稳定性（list 运行时构造 + 元组对偶造面——r160；const keep 绑定——r161） | `kerf run examples/usage/gc_stress.ktf` ⇒ 5 |
| `gc_stress_nontail.ktf` | 非尾形递归 GC 帧根扫描（TD-023 基准目标面 + 元组造面 r160；const keep 绑定——r161） | `kerf run examples/usage/gc_stress_nontail.ktf` ⇒ 5 |
| `macros.ktf` | 宏面语料（第九映射：macro 定义臂形 + 变参递归省略号 + 块模板卫生——r129） | `kerf run examples/usage/macros.ktf` ⇒ (2 1) + 42 |
| `ffi.ktf` | FFI extern 声明族（第十三映射——extern 声明 + 能力门 + 真实宿主 I/O 往返——r137） | `kerf run examples/usage/ffi.ktf` ⇒ 9 |
| `ffi_alias.ktf` | extern 声明位别名（第十三映射域扩展——双名分离 + 替换语义——r147） | `kerf run examples/usage/ffi_alias.ktf` ⇒ 9 |
| `vector.ktf` | 向量字面量 + 五内建族（第十四映射——r138） | `kerf run examples/usage/vector.ktf` ⇒ 9 |

## audit/ —— 阶段审查脚本（`*.rs`，cargo example 运行，历史归档）

| 文件 | 审计内容 | 运行 |
|------|---------|------|
| `stage0_gate_audit_r1.rs` | §7.3.1 门审计集（41 case：负向 32 + 恢复 6 + 正向 3；§7.1.1 七类全覆盖） | `cargo run --example stage0_gate_audit_r1` |

命名规范（§9.6.3）：语言演示 `<主题>.ktf`（小写 + 下划线——r153 起单面）；阶段审查
`stage<N>_gate_audit_r<R>.rs`。维护策略：usage/ 随新能力同步新增（API
变更必须同步更新）；audit/ 为轮次归档，阶段闭合后不再扩展（§9.6.5）。

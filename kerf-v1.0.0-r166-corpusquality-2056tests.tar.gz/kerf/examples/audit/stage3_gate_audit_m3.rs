//! E6 close-out (r154 / 224-d4): converted to the target-syntax single face.
//! Stage 3 batch M close-out gate audit suite (sop.md §7.3.1 rule 3 /
//! §7.1.1 seven-class matrix / §7.3.2 previous-round fix boundaries /
//! 22 §8 implementation-reconciliation-table close-out stance).
//!
//! **Purpose**: the M3 close-out gate review of batch M (M1 qualified-name
//! visibility surface r39 + M2 import injection surface / aliases r40 +
//! r41 deep-review D10 E0020) — the executable audit of the window M exit
//! conditions (23 §2.2): R-N1~N8 all cases + B1-B3 contracts + composition
//! closure + the E2E namespace full-import-path three channels.
//!
//! **How to run**: from the workspace root, `cargo run --example stage3_gate_audit_m3`.
//! Exit code 0 (APPROVED) when every case PASSes and the §7.3.1/§7.3.2
//! ratio mechanical check passes.
//!
//! **Structure** (§7.3.1 rule 2 mandatory ratios):
//! - Bucket A 11: single-statement namespace negative (full coverage of
//!   the E0013-E0020 eight-code family)
//! - Bucket B 9: multi-statement gating / closure / shadowing combination
//!   negative (red line 1 + composition closure + static surface + the W
//!   family)
//! - Bucket C 6: complex programs (nested modules / multi-module
//!   cooperation / authorization chains / effects combined with macros)
//! - Bucket D 5: recovery (in-process rerun after errors + merged report
//!   ordering + dual-path error agreement)
//! - Bucket E 5: fix boundaries (D10 E0020 double layer / data-domain skip +
//!   D4 composition-closure joint missing + M1 Fn shadowing + B1/B2
//!   contract parity + D10 deep-position nesting)
//! - Bucket P 7: positive sanity + E2E full-import-path three channels +
//!   count anchors + auditor self-check
//!
//! Total 43 cases: 28 negative + 5 recovery + 10 positive (negative ≥22).
//! (E6 conversion alignment: the pre-conversion header text said
//! "26 negative + 5 recovery + 12 positive" — a stale sum; the case table's
//! actual polarity distribution was and stays 28/5/10, mechanically checked
//! in main(); the doc line now matches the measured table.)
//!
//! **§7.1.1 seven-class coverage** (namespace contextual mapping):
//! ① syntax (E0015 reserved domains / E0020 reserved-word forms) ② unbound
//! (E0014 not exported / the E0013/E0016/E0017 name-surface conflict family)
//! ③ empty application (empty-list forms) ④ arity (E0005 qualified-name
//! signature arity) ⑤ type mismatch (E0005 qualified-name signature types)
//! ⑥ circular dependency (E0019 unknown import — the module resolution
//! surface) ⑦ macro depth (E0020 macro names / macro expansion products —
//! the macro-system N4 intersection).
//!
//! **E6 conversion note** (r154 / 224-d4, s-expr-removal-plan §4 E6): the
//! whole case table and every probe moved to the target-syntax single face
//! (`run_source` / `run_source_seed` dual paths,
//! `check_source_recover` static + recovery face, `m3audit.ktf`
//! filename — the S-expr entry family retired). Case count, bucket /
//! polarity / §7.1.1 class assignments unchanged (zero deletions). The
//! namespace surface itself is skin-transparent on this face
//! (`import kerf_string;` / `ns::name` qualified references / `as` aliases /
//! `module m { ... }` blocks / `require io, write;` declarations map
//! symbol-for-symbol onto the same Stx the S-expr Reader produced — the
//! converted tests/v0/stage3/plan/namespace_tests.rs is the idiom source),
//! so the namespace diagnostics keep the S-expr-surface spellings
//! (`kerf-string`, `string/append` in messages, kebab runtime text).
//! Carrier rulings, calibrated by running both chains: the keyword-skin
//! reserved words (`if`/`fn`/`perform`/`handle`) are Reader-reserved Tokens
//! on the target face, so the E0020 compile-stage anchors ride the shared
//! non-skin reserved words of the same 28-name N4 table (`quote`/`do` —
//! plain identifiers on the target surface, N4 keywords in the
//! expander/driver), keeping every binding position (module name / define
//! name / import alias / macro name / handle dual binders / nested do /
//! let-in-fn / expansion product) at the compile stage (namespace_tests
//! d10 the same ruling; A03/A04/A07/B08/B09/C02/C05/E05 word-level
//! substitution, the backticked-name message assertions follow the
//! substituted word); A10's require-inside-subtree is lexically fronted to
//! the Reader (`require` is a declaration Token — a Read-stage rejection
//! with the Reader's own message; the Stx-layer E0018 walk stays the
//! backstop for macro-produced shapes — namespace_tests
//! m2_require_position_e0018 the same ruling); A11/D01's ③ empty-form
//! carrier = the zero-argument `quote()` application (the target `()` is
//! the unit literal — the Expand message recalibrated to the `quote form`
//! family; the d1/d2/d3 siblings the same ruling); P04's read-time `'if`
//! datum face has no target-surface spelling → the R-N8/N0 anchor goes
//! through the runtime symbol-construction route (`string_to_symbol("if")`
//! — namespace_tests d10_quote_reserved_word_data_symbols_legal the same
//! ruling); E04's display-only `(do (print* nil))` carrier has no target
//! spelling (`*` outside the identifier charset) → descriptive src (the
//! probe's B1/B2 assertions untouched).

use std::process::Command;

use kerf_driver::{check_source_recover, compile_source, run_source, run_source_seed, Stage};

/// Oracle static decision surface (r80 semantic re-anchoring — a direct
/// hm_check_program call): reference-surface assertion for
/// conservative-false-negative boundary cases outside the krf-surface
/// [production] signature-table subset (the string/list qualified-name
/// families).
fn oracle_check_diags(src: &str) -> Vec<kerf_span::Diagnostic> {
    let out = compile_source(src, "audit-oracle.ktf").expect("pre-stage compile failed");
    let mut table = out.table;
    let sigs = kerf_driver::builtins::builtin_sigs(&mut table);
    kerf_compiler::hm::hm_check_program(&out.core, &sigs, &table).diags
}
use kerf_span::DiagnosticCode;
use kerf_vm::render_value;

/// Audit source file name (for diagnostic rendering location assertions).
const FNAME: &str = "m3audit.ktf";

// ---------------------------------------------------------------------------
// Bucket / polarity / §7.1.1 error classes
// ---------------------------------------------------------------------------

#[derive(Clone, Copy, PartialEq, Eq)]
enum Bucket {
    Single,
    Multi,
    Complex,
    Recovery,
    Boundary,
    Positive,
}

impl Bucket {
    fn label(self) -> &'static str {
        match self {
            Bucket::Single => "A single-statement",
            Bucket::Multi => "B multi-statement",
            Bucket::Complex => "C complex",
            Bucket::Recovery => "D recovery",
            Bucket::Boundary => "E boundary",
            Bucket::Positive => "P positive",
        }
    }
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum Polarity {
    Negative,
    Positive,
    Recovery,
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum ErrorClass {
    Syntax,
    Unbound,
    EmptyForm,
    Arity,
    TypeMismatch,
    CircularDep,
    MacroDepth,
}

impl ErrorClass {
    fn index(self) -> usize {
        match self {
            ErrorClass::Syntax => 1,
            ErrorClass::Unbound => 2,
            ErrorClass::EmptyForm => 3,
            ErrorClass::Arity => 4,
            ErrorClass::TypeMismatch => 5,
            ErrorClass::CircularDep => 6,
            ErrorClass::MacroDepth => 7,
        }
    }
    fn label(self) -> &'static str {
        match self {
            ErrorClass::Syntax => "① syntax",
            ErrorClass::Unbound => "② unbound",
            ErrorClass::EmptyForm => "③ empty application",
            ErrorClass::Arity => "④ argument count",
            ErrorClass::TypeMismatch => "⑤ type mismatch",
            ErrorClass::CircularDep => "⑥ circular dependency",
            ErrorClass::MacroDepth => "⑦ macro depth",
        }
    }
}

// ---------------------------------------------------------------------------
// Expectations and results
// ---------------------------------------------------------------------------

enum Expect {
    /// Both paths Err (DriverError): stage + message substring + E code
    /// (the Compile-family extension range 13-20 is legal — the M1/M2/
    /// deep-review D10 namespace family).
    Err {
        stage: Stage,
        msg: &'static str,
        code: Option<u32>,
    },
    /// Static decision surface (check_source_recover Ok report with
    /// non-empty diagnostics — the E0005 HM default period [after the r80
    /// switch = the check.ktf path]).
    StaticErr { msg: &'static str, min_diags: usize },
    /// Oracle static decision surface (r80 semantic re-anchoring):
    /// conservative-false-negative boundary cases outside the krf-surface
    /// signature-table subset — the Rust oracle is called directly to assert
    /// detection capability (reference-surface anchor).
    OracleStaticErr { msg: &'static str, min_diags: usize },
    /// Both paths Ok with an identical value (exact rendered-value match).
    OkDual(&'static str),
    /// Custom probe (recovery / fix boundary / W surface / E2E / count anchors).
    Custom(fn() -> CaseResult),
}

struct Case {
    id: &'static str,
    bucket: Bucket,
    polarity: Polarity,
    class: Option<ErrorClass>,
    src: &'static str,
    expect: Expect,
}

struct CaseResult {
    pass: bool,
    detail: String,
}

fn pass(detail: String) -> CaseResult {
    CaseResult { pass: true, detail }
}

fn fail(detail: String) -> CaseResult {
    CaseResult {
        pass: false,
        detail,
    }
}

fn short_src(src: &str) -> String {
    let one = src.replace('\n', " ⏎ ");
    if one.len() > 88 {
        format!("{}…", &one[..84])
    } else {
        one
    }
}

fn first_line(s: &str) -> String {
    s.lines().next().unwrap_or("").to_string()
}

// ---------------------------------------------------------------------------
// Case table (43 cases — A11/B9/C6/D5/E5/P7)
// ---------------------------------------------------------------------------

const CASES: &[Case] = &[
    // ---- Bucket A: single-statement namespace negative (full coverage of
    // the E0013-E0020 eight codes, 11) ----
    Case {
        id: "A01",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        src: "import kerf_string;\nstring::nonexist(\"a\")",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "does not export `nonexist`",
            code: Some(14),
        },
    },
    Case {
        id: "A02",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Syntax),
        // (E6 skin: `kerf_evil` maps back to the `kerf-evil` module symbol
        // at the Reader boundary — the E0015 diagnostic keeps the kebab
        // spelling)
        src: "module kerf_evil { export a; let a = 1; }",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "reserved domain",
            code: Some(15),
        },
    },
    Case {
        id: "A03",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Syntax),
        // E6: `if` is a Reader-reserved Token in the module-name slot →
        // the compile-stage E0020 anchor rides the shared non-skin
        // reserved word `quote` (namespace_tests d10 same ruling; the
        // module-name binding position is unchanged)
        src: "module quote { export a; let a = 1; }",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "reserved word is not bindable",
            code: Some(20),
        },
    },
    Case {
        id: "A04",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Syntax),
        // E6: `fn` is a Reader-reserved Token in the define-name slot →
        // the shared non-skin reserved word `quote` (msg recalibrated
        // `fn`→`quote` — namespace_tests d10 same ruling)
        src: "let quote = 5;",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "`quote`",
            code: Some(20),
        },
    },
    Case {
        id: "A05",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::CircularDep),
        src: "module m { import kerf_nonexist; }",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "unknown import",
            code: Some(19),
        },
    },
    Case {
        id: "A06",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        // r47 / 68-b D55 E0013 underlying-identity re-basing migration:
        // unqualified two-module imports legalized (a local-name lexical
        // collision ≠ runtime ambiguity — the flat append always resolves to
        // the list domain); the negative carrier = flat append consuming a
        // string → a runtime type-contract error ("append # 1 requires
        // list" — a semantics-preserving migration of the 22 §15 D55
        // semantic evolution, class Unbound→TypeMismatch)
        src: "import kerf_list;\nmodule m { import kerf_string; import kerf_list; append(\"a\", \"b\") }",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "append # 1 requires list",
            code: None,
        },
    },
    Case {
        id: "A07",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Syntax),
        // E6: the `if` alias is a Reader-reserved Token in the as-alias
        // slot → the shared non-skin reserved word `quote` (the E0020
        // import-alias position unchanged — namespace_tests d10 same
        // ruling)
        src: "module m { import kerf_string as quote; quote::length(\"a\") }",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "import alias",
            code: Some(20),
        },
    },
    Case {
        id: "A08",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        src: "module m { let a = 1; let a = 2; }",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "duplicate definition",
            code: Some(16),
        },
    },
    Case {
        id: "A09",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        src: "module m { import kerf_string as s; import kerf_list as s; }",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "duplicate alias",
            code: Some(17),
        },
    },
    Case {
        id: "A10",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Syntax),
        // require inside an expression subtree → E0018 position discipline
        // (D3 ruling). E6: `require` is a declaration Token on the target
        // face — the discipline is lexically fronted to the Reader (a
        // strictly earlier fail-closed face; namespace_tests
        // m2_require_position_e0018 same ruling); the Stx-layer E0018 walk
        // stays the shared backstop for macro-produced shapes
        src: "let f = || { require io, write; };",
        expect: Expect::Err {
            stage: Stage::Read,
            msg: "expected an expression, got KwRequire",
            code: None,
        },
    },
    Case {
        id: "A11",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::EmptyForm),
        // E6: the ③ empty-application carrier = the zero-argument `quote()`
        // application (the target `()` is the unit literal — the Expand
        // message rides the `quote form` family; d1/d2/d3 same ruling)
        src: "module m { let a = 1; quote(); }",
        expect: Expect::Err {
            stage: Stage::Expand,
            msg: "quote form",
            code: None,
        },
    },
    // ---- Bucket B: multi-statement gating / closure / shadowing combination negative (9) ----
    Case {
        id: "B01",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        // Red line 1: import-injected name visibility ≠ authorization (22 §5.2 two-gate separation)
        src: "module m { import kerf_io; print(42) }",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "print",
            code: Some(6),
        },
    },
    Case {
        id: "B02",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        // Composition closure: require inside a module = requirement
        // metadata; a missing declaration at the program head → enhanced
        // E0006
        src: "module m { require io, write; let p = || { print(42); }; }\n42",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "io",
            code: Some(6),
        },
    },
    Case {
        id: "B03",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        src: "import kerf_string;\nmodule m { string::length(5) }",
        expect: Expect::OracleStaticErr {
            msg: "requires str",
            min_diags: 1,
        },
    },
    Case {
        id: "B04",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Arity),
        // E6 skin: the zero-argument qualified call `string::append()`
        // reads as the same `(string/append)` core the S-expr face produced
        src: "import kerf_string;\nmodule m { string::append() }",
        expect: Expect::OracleStaticErr {
            msg: "argument count mismatch",
            min_diags: 1,
        },
    },
    Case {
        id: "B05",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        // Type error at a qualified-name call position (signature derivation
        // applies to ns/name — same judgment as E0005)
        src: "import kerf_string;\nstring::length(\"ab\") + \"x\"",
        expect: Expect::StaticErr {
            msg: "requires a number",
            min_diags: 1,
        },
    },
    Case {
        id: "B06",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::MacroDepth),
        // Reserved-word binding in a macro expansion product →
        // CoreExpr-layer defense in depth (D10 E0020)
        src: "macro mk() { () => define(quote, 1) }\nmk()",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "expansion product",
            code: Some(20),
        },
    },
    Case {
        id: "B07",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        // Unknown name after alias normalization → E0014 carrying the
        // normalized surface (`str/nonexist` → the string surface)
        src: "module m { import kerf_string as str; str::nonexist(\"a\") }",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "does not export `nonexist`",
            code: Some(14),
        },
    },
    Case {
        id: "B08",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::MacroDepth),
        // Reserved word as macro name → E0020 (the N4 ∩ macro-system
        // intersection — a macro name is a binding name). E6: `if` is a
        // Reader-reserved Token in the macro-name slot → the shared
        // non-skin reserved word `quote` (namespace_tests d10 same ruling)
        src: "macro quote() { (c, t) => t }",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "macro name",
            code: Some(20),
        },
    },
    Case {
        id: "B09",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Syntax),
        // handle's two binders as reserved words → CoreExpr layer (D10 coverage surface).
        // E6: `perform` is a Reader-reserved Token in the binder slots →
        // the shared non-skin reserved words `quote`/`do` (namespace_tests
        // d10_handle_binders the same ruling — the payload-position anchor)
        src: "fn ask() { perform state(1); }\nhandle ask() { state(quote, do) => resume(42) }",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "handle payload binding",
            code: Some(20),
        },
    },
    // ---- Bucket C: complex programs (6) ----
    Case {
        id: "C01",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        // Nested modules each checked independently — the inner duplicate
        // define comes after the outer correct definition
        src: "module outer { let a = 1; module inner { let b = 1; let b = 2; } a }",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "duplicate definition",
            code: Some(16),
        },
    },
    Case {
        id: "C02",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Syntax),
        // Deep-position do-nested reserved-word binding (subtree recursion pierces through).
        // E6: `perform` is a Reader-reserved Token in the define-name slot
        // → the shared non-skin reserved word `do` (msg recalibrated
        // `perform`→`do` — namespace_tests d10_nested_begin same ruling)
        src: "do(define(ok, 1), do(define(do, 2)))",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "`do`",
            code: Some(20),
        },
    },
    Case {
        id: "C03",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        // Composition-closure joint missing: the module needs read+write,
        // the program head declares only write
        src: "require io, write;\nmodule m { require io, read, write; 42 }",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "read",
            code: Some(6),
        },
    },
    Case {
        id: "C04",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        // Qualified-name nested-call static surface (signature derivation
        // pierces nested argument positions — the HM flag-period check depth
        // = the direct-application shape; user higher-order argument
        // propagation is a Stage 3 HM evolution item, not a gap of this
        // window [same judgment stance as r2 A09])
        src: "import kerf_string;\nstring::length(string::to_upper(5))",
        expect: Expect::OracleStaticErr {
            msg: "requires str",
            min_diags: 1,
        },
    },
    Case {
        id: "C05",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Syntax),
        // Effects + namespace + reserved-word intersection: a reserved word
        // as the handle resume-position binder (B09's payload position
        // perform + this case's resume-position resume = both binders fully
        // covered). E6: `resume` is a Reader-reserved Token in the binder
        // slot → the shared non-skin reserved word `quote` (the
        // resume-position anchor — namespace_tests d10_handle_binders the
        // complementary arm)
        src: "module m { fn ask() { perform tag(1); } handle ask() { tag(p, quote) => resume(42) } }",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "handle resume binding",
            code: Some(20),
        },
    },
    Case {
        id: "C06",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Arity),
        // Deep-chain qualified-name combined arity error (list domain +
        // string domain through if control flow)
        src: "import kerf_list, kerf_string;\nfn pick(n: i64) -> i64 { if (n > 0) { list::nth(list(1, 2, 3)) } else { string::length(\"ab\") } }\npick(1)",
        expect: Expect::OracleStaticErr {
            msg: "argument count mismatch",
            min_diags: 1,
        },
    },
    // ---- Bucket D: recovery (5) ----
    Case {
        id: "D01",
        bucket: Bucket::Recovery,
        polarity: Polarity::Recovery,
        class: Some(ErrorClass::EmptyForm),
        // (E6 skin: the ③ empty-form leg rides the zero-argument quote()
        // carrier — see probe_recover_merged)
        src: "import kerf_string;\nlet x = 1;\nstring::length()\nquote()\n",
        expect: Expect::Custom(probe_recover_merged),
    },
    Case {
        id: "D02",
        bucket: Bucket::Recovery,
        polarity: Polarity::Recovery,
        class: None,
        src: "let quote = 5;\n1 + 2\n",
        expect: Expect::Custom(probe_e0020_then_vm_healthy),
    },
    Case {
        id: "D03",
        bucket: Bucket::Recovery,
        polarity: Polarity::Recovery,
        class: None,
        src: "module kerf_evil { export a; let a = 1; }\nfn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(10)\n",
        expect: Expect::Custom(probe_e0015_then_reader_ok),
    },
    Case {
        id: "D04",
        bucket: Bucket::Recovery,
        polarity: Polarity::Recovery,
        class: Some(ErrorClass::Unbound),
        src: "import kerf_string;\nstring::nonexist(\"a\")",
        expect: Expect::Custom(probe_e0014_dual_path_agree),
    },
    Case {
        id: "D05",
        bucket: Bucket::Recovery,
        polarity: Polarity::Recovery,
        class: None,
        src: "import kerf_string;\nmodule m { import kerf_io; print(1) }\nstring::length(\"abc\")\n",
        expect: Expect::Custom(probe_e0006_then_ns_ok),
    },
    // ---- Bucket E: fix boundaries (M1/M2/deep-review D10 three fix surfaces, 5) ----
    Case {
        id: "E01",
        bucket: Bucket::Boundary,
        polarity: Polarity::Positive,
        class: Some(ErrorClass::MacroDepth),
        // D10 data-domain boundary: template literals (the define quote
        // shape inside a template) are legal and do not trigger — the macro
        // definition succeeds + the instantiated product after invocation
        // triggers E0020 (B06 carries the negative; this case asserts the
        // "definition succeeds" half)
        src: "macro mk2() { (x) => quote(x) }",
        expect: Expect::Custom(probe_template_data_domain_legal),
    },
    Case {
        id: "E02",
        bucket: Bucket::Boundary,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        // D4 boundary: the composition closure is missing only read (write
        // already declared) — a precise missing-requirement message
        src: "require io, write;\nmodule m { require io, read, write; 42 }",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "read",
            code: Some(6),
        },
    },
    Case {
        id: "E03",
        bucket: Bucket::Boundary,
        polarity: Polarity::Positive,
        class: None,
        // M1 fix boundary: Fn parameter shadowing R-N1 — parameter name =
        // a module-local name → the local wins with zero E0020 false
        // positives (not a reserved-word name)
        src: "import kerf_list;\nfn f(append: i64) -> i64 { append }\nf(42)",
        expect: Expect::OkDual("42"),
    },
    Case {
        id: "E04",
        bucket: Bucket::Boundary,
        polarity: Polarity::Positive,
        class: None,
        // B1/B2 contract boundary: qualified-name miss→nil vs old-name -1 parity coexisting.
        // E6: the display-only S-expr carrier `(do (print* nil))` has no
        // target spelling (`*` outside the identifier charset) →
        // descriptive src (the probe's assertions untouched)
        src: "(B1/B2 contract parity -- qualified-name miss nil vs old-name -1)",
        expect: Expect::Custom(probe_b1_b2_contract_parity),
    },
    Case {
        id: "E05",
        bucket: Bucket::Boundary,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Syntax),
        // D10 deep position: let binding a reserved word inside a fn body (two layers of nesting).
        // E6: `handle` is a Reader-reserved Token in the let-name slot →
        // the shared non-skin reserved word `quote` (msg recalibrated
        // `handle`→`quote` — namespace_tests d10_nested_begin same ruling)
        src: "(||(n: i64) { let quote = n; quote })(1)",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "`quote`",
            code: Some(20),
        },
    },
    // ---- Bucket P: positive sanity + E2E full-import paths (7) ----
    Case {
        id: "P01",
        bucket: Bucket::Positive,
        polarity: Polarity::Positive,
        class: None,
        src: "import kerf_string;\nstring::append(string::to_upper(\"ab\"), \"cd\")",
        expect: Expect::OkDual("ABcd"),
    },
    Case {
        id: "P02",
        bucket: Bucket::Positive,
        polarity: Polarity::Positive,
        class: None,
        // R-N4 + R-N7 coexistence anchor: standalone / division + operators
        // always resident + qualified names in the same program
        src: "6 / 2",
        expect: Expect::OkDual("3"),
    },
    Case {
        id: "P03",
        bucket: Bucket::Positive,
        polarity: Polarity::Positive,
        class: None,
        // Prelude re-export (map/foldl high-frequency names unqualified) + mixed qualified-name use.
        // (E6 skin: the bare `+` folds into the closure carrier — the
        // d2/d3 siblings' converted idiom; the src mirrors the probe
        // program)
        src: "import kerf_prelude;\nmodule m { import kerf_prelude; foldl(|| (acc: T, x: T) { acc + x }, 0, map(|| (x: T) { x * x }, list(1, 2, 3))) }",
        expect: Expect::Custom(probe_prelude_and_qualified_mix),
    },
    Case {
        id: "P04",
        bucket: Bucket::Positive,
        polarity: Polarity::Positive,
        class: None,
        // quote data-symbol exemption (the D10 homoiconicity-preservation surface).
        // E6: the read-time `'if` datum face has no target-surface
        // spelling → the R-N8/N0 anchor goes through the runtime
        // symbol-construction route (namespace_tests
        // d10_quote_reserved_word_data_symbols_legal same ruling)
        src: "import kerf_string;\nis_symbol(string_to_symbol(\"if\"))",
        expect: Expect::OkDual("true"),
    },
    Case {
        id: "P05",
        bucket: Bucket::Positive,
        polarity: Polarity::Positive,
        class: None,
        src: "import kerf_string;\nmodule m { import kerf_string as str; string::length(str::to_upper(\"ab\")) }",
        expect: Expect::OkDual("2"),
    },
    Case {
        id: "P06",
        bucket: Bucket::Positive,
        polarity: Polarity::Positive,
        class: None,
        // E2E full-import-path three channels × seven modules (Custom probe — window M exit conditions)
        src: "-",
        expect: Expect::Custom(probe_e2e_full_import_paths),
    },
    Case {
        id: "P07",
        bucket: Bucket::Positive,
        polarity: Polarity::Positive,
        class: None,
        // Count anchors (post r42/S1 removal-round stance): 57 flat + 47
        // qualified names + 27 retired (guard-function re-verification — the
        // old-name E0021 rejection surface is a removal-round-added anchor)
        src: "-",
        expect: Expect::Custom(probe_count_anchors),
    },
];

// ---------------------------------------------------------------------------
// Executors
// ---------------------------------------------------------------------------

fn run_case(c: &Case) -> CaseResult {
    match &c.expect {
        Expect::Err { stage, msg, code } => run_negative(c, *stage, msg, *code),
        Expect::StaticErr { msg, min_diags } => run_static(c, msg, *min_diags),
        Expect::OracleStaticErr { msg, min_diags } => run_oracle_static(c, msg, *min_diags),
        Expect::OkDual(s) => run_positive_dual(c, s),
        Expect::Custom(f) => f(),
    }
}

/// Runtime/gating-surface negative (both paths same Err + E code + Span + file name).
fn run_negative(c: &Case, stage: Stage, msg: &str, code: Option<u32>) -> CaseResult {
    let err = match run_source(c.src, FNAME) {
        Err(e) => e,
        Ok(_) => {
            return fail(format!(
                "expected {:?} stage Err, VM path returns Ok",
                stage
            ));
        }
    };
    if err.stage != stage {
        return fail(format!(
            "VM stage mismatch: expected {:?} actual {:?}({})",
            stage,
            err.stage,
            first_line(&err.rendered)
        ));
    }
    if !err.rendered.contains(msg) {
        return fail(format!(
            "VM message does not contain `{}`: {}",
            msg,
            first_line(&err.rendered)
        ));
    }
    let want_code = DiagnosticCode(code.unwrap_or_else(|| stage_e_code(stage)));
    // M1/M2/deep-review D10 namespace-family dedicated codes (E0013-E0020)
    // are legal at the Compile stage (family members of base code E0003 —
    // the M3 gate-review mechanical-check extension range)
    let code_ok = err.diagnostic.code == Some(want_code)
        || (stage == Stage::Compile && matches!(err.diagnostic.code.map(|k| k.0), Some(13..=20)));
    if !code_ok {
        return fail(format!(
            "E code mismatch: expected E{:04} actual {:?}",
            want_code.0,
            err.diagnostic.code.map(|k| k.0)
        ));
    }
    if err.diagnostic.primary_span.is_empty() {
        return fail("primary Span empty (diagnostic location missing)".to_string());
    }
    if !err.rendered.contains(FNAME) {
        return fail(format!(
            "render output missing file name {}(position excerpt missing)",
            FNAME
        ));
    }
    match run_source_seed(c.src, FNAME) {
        Ok(_) => fail("expected Err, seed chain returns Ok(dual-path split)".to_string()),
        Err(e2) => {
            if e2.stage != stage {
                fail(format!(
                    "seed chain stage mismatch: expected {:?} actual {:?}",
                    stage, e2.stage
                ))
            } else if !e2.rendered.contains(msg) {
                fail(format!(
                    "seed chain message does not contain `{}`: {}",
                    msg,
                    first_line(&e2.rendered)
                ))
            } else {
                pass(format!(
                    "dual-path same Err {} `{}`",
                    first_line(&err.rendered),
                    msg
                ))
            }
        }
    }
}

/// Oracle static decision surface negative (r80): a direct hm_check_program
/// call → E0005 diagnostics (message substring + minimum diagnostic count;
/// reference-surface anchor — the boundary outside the krf-surface
/// signature-table subset).
fn run_oracle_static(c: &Case, msg: &str, min_diags: usize) -> CaseResult {
    let diags = oracle_check_diags(c.src);
    if diags.len() < min_diags {
        return fail(format!(
            "oracle diagnostic count {} < minimal {}(reference face detects capability regression)",
            diags.len(),
            min_diags
        ));
    }
    let hits: Vec<_> = diags
        .iter()
        .filter(|d| d.message.contains(msg) && d.code == Some(DiagnosticCode(5)))
        .collect();
    if hits.is_empty() {
        let msgs: Vec<&str> = diags.iter().map(|d| d.message.as_str()).collect();
        return fail(format!(
            "oracle E0005 diagnostic does not contain `{}`; actual {:?}",
            msg, msgs
        ));
    }
    pass("oracle static face hit (reference anchor outside signature-table subset)".to_string())
}

/// Static decision surface (the E0005 HM default period [after the r80
/// switch = the check.ktf path] — the check report diagnostics surface).
fn run_static(c: &Case, msg: &str, min_diags: usize) -> CaseResult {
    let report = match check_source_recover(c.src, FNAME) {
        Ok(r) => r,
        Err(e) => {
            return fail(format!(
                "static face should return a diagnostic report (Ok), actual compile-time Err: {}",
                first_line(&e.rendered)
            ));
        }
    };
    if report.diagnostics.len() < min_diags {
        return fail(format!(
            "diagnostic count {} < minimal {}(multiple-error collection broken)",
            report.diagnostics.len(),
            min_diags
        ));
    }
    let hits: Vec<_> = report
        .diagnostics
        .iter()
        .filter(|d| d.message.contains(msg) && d.code == Some(DiagnosticCode(5)))
        .collect();
    if hits.is_empty() {
        let msgs: Vec<&str> = report
            .diagnostics
            .iter()
            .map(|d| d.message.as_str())
            .collect();
        return fail(format!(
            "E0005 diagnostic does not contain `{}`; actual {:?}",
            msg, msgs
        ));
    }
    for d in &hits {
        if d.primary_span.is_empty() {
            return fail("E0005 primary Span empty (location missing)".to_string());
        }
    }
    pass(format!(
        "static face E0005 ×{}(containing `{}`+ Span)",
        hits.len(),
        msg
    ))
}

/// Both paths Ok with an identical value.
fn run_positive_dual(c: &Case, want: &str) -> CaseResult {
    let a = match run_source(c.src, FNAME) {
        Ok(o) => o,
        Err(e) => return fail(format!("production chain Err: {}", first_line(&e.rendered))),
    };
    let b = match run_source_seed(c.src, FNAME) {
        Ok(o) => o,
        Err(e) => return fail(format!("seed chain Err: {}", first_line(&e.rendered))),
    };
    let ra = render_value(&a.value, &a.heap);
    let rb = render_value(&b.value, &b.heap);
    if ra != want || rb != want {
        return fail(format!(
            "value mismatch: expected {}, production {} / seed {}",
            want, ra, rb
        ));
    }
    if !a.value.eq_value(&b.value) {
        return fail(format!(
            "dual-path value mismatch: production {} vs seed {}",
            ra, rb
        ));
    }
    pass(format!("dual-path same value ⇒ {}", ra))
}

fn stage_e_code(stage: Stage) -> u32 {
    match stage {
        Stage::Read => 1,
        Stage::Expand => 2,
        Stage::Compile => 3,
        Stage::Run => 4,
    }
}

// ---------------------------------------------------------------------------
// Bucket D recovery probes
// ---------------------------------------------------------------------------

/// D01: recovery merged report (qualified-name E0005 arity + E0002 empty
/// form — positional ordering + partial artifacts continue through the
/// pipeline; the Compile family E0013-E0020 is fail-closed blocking and
/// does not enter the collection surface, so the recovery collection
/// surface = Expand errors + HM static diagnostics — the existing M2
/// stance).
/// r80 semantic re-anchoring: the E0005 of (string/length) is a
/// conservative-false-negative boundary outside the krf-surface
/// [production] signature-table subset — E0002 [empty application] stays
/// detected on the krf surface + E0005 is guarded by the direct oracle call
/// (dual-face separated assertion — recovery-merged stance and detection
/// capability, both anchored).
/// (E6 skin: the ③ empty-form leg rides the zero-argument quote()
/// application — the message recalibrated to the `quote form` family; the
/// d1/d2/d3 siblings' same ruling)
fn probe_recover_merged() -> CaseResult {
    let src = "import kerf_string;\nlet x = 1;\nstring::length()\nquote()\n";
    let report = match check_source_recover(src, FNAME) {
        Ok(r) => r,
        Err(e) => {
            return fail(format!(
                "recovery path should produce a report:{}",
                first_line(&e.rendered)
            ));
        }
    };
    if report.diagnostics.is_empty() {
        return fail(
            "recovery collection face empty(E0002 empty application should detected)".to_string(),
        );
    }
    let has_e2 = report
        .diagnostics
        .iter()
        .any(|d| d.code == Some(DiagnosticCode(2)) && d.message.contains("quote form"));
    if !has_e2 {
        let codes: Vec<u32> = report
            .diagnostics
            .iter()
            .filter_map(|d| d.code.map(|k| k.0))
            .collect();
        return fail(format!(
            "recovery report missing E0002 empty application; actual code {:?}",
            codes
        ));
    }
    // E0005 reference surface (direct oracle call — detection-capability
    // anchor outside the signature-table subset)
    let oracle = oracle_check_diags("import kerf_string;\nstring::length()");
    let has_e5 = oracle.iter().any(|d| {
        d.code == Some(DiagnosticCode(5)) && d.message.contains("argument count mismatch")
    });
    if !has_e5 {
        return fail(format!(
            "oracle qualified name element count not detected: {:?}",
            oracle
                .iter()
                .map(|d| d.message.as_str())
                .collect::<Vec<_>>()
        ));
    }
    pass(format!(
        "recovery merge {} clauses (E0002 empty application krf face + E0005 qualified name oracle reference face)",
        report.diagnostics.len()
    ))
}

/// D02: VM state stays healthy after an E0020 error (fib runs correctly in-process afterwards).
/// (E6 skin: the E0020 carrier = `define(quote, 5)` — the shared non-skin
/// reserved word; fib rides the fn-declaration form)
fn probe_e0020_then_vm_healthy() -> CaseResult {
    let r = run_source("let quote = 5;", FNAME);
    if r.is_ok() {
        return fail("expected E0020 Err".to_string());
    }
    let fib =
        "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(12)";
    match run_source(fib, "fib.ktf") {
        Ok(o) => {
            let v = render_value(&o.value, &o.heap);
            if v == "144" {
                pass("E0020 later same-process fib(12) ⇒ 144(VM state healthy)".to_string())
            } else {
                fail(format!("continue-run value abnormal: {}", v))
            }
        }
        Err(e) => fail(format!("continue-run Err: {}", first_line(&e.rendered))),
    }
}

/// D03: the Reader/Driver still works after an E0015 reserved-domain error (in-process rerun).
fn probe_e0015_then_reader_ok() -> CaseResult {
    let r = run_source("module kerf_evil { export a; let a = 1; }", FNAME);
    if r.is_ok() {
        return fail("expected E0015 Err".to_string());
    }
    match run_source("import kerf_string;\nstring::length(\"abc\")", "ok.ktf") {
        Ok(o) => {
            let v = render_value(&o.value, &o.heap);
            if v == "3" {
                pass(
                    "E0015 subsequent run qualified name program ⇒ 3(pipeline healthy)".to_string(),
                )
            } else {
                fail(format!("continue-run value abnormal: {}", v))
            }
        }
        Err(e) => fail(format!("continue-run Err: {}", first_line(&e.rendered))),
    }
}

/// D04: E0014 dual-path error agreement (both Err, same code, same message family).
fn probe_e0014_dual_path_agree() -> CaseResult {
    let src = "import kerf_string;\nstring::nonexist(\"a\")";
    let a = run_source(src, FNAME);
    let b = run_source_seed(src, FNAME);
    match (a, b) {
        (Err(ea), Err(eb)) => {
            if ea.diagnostic.code == eb.diagnostic.code
                && ea.stage == eb.stage
                && first_line(&ea.rendered).contains("does not export")
                && first_line(&eb.rendered).contains("does not export")
            {
                pass("E0014 dual-path same Err same code(consistency maintained)".to_string())
            } else {
                fail(format!(
                    "dual-path E0014 partition split: {:?} vs {:?}",
                    ea.diagnostic.code, eb.diagnostic.code
                ))
            }
        }
        _ => fail("dual-path should all is Err".to_string()),
    }
}

/// D05: the namespace proper path runs again healthily after an E0006 gating error.
fn probe_e0006_then_ns_ok() -> CaseResult {
    let r = run_source("module m { import kerf_io; print(1) }", FNAME);
    if r.is_ok() {
        return fail("expected E0006 Err(red line 1)".to_string());
    }
    match run_source(
        "require io, write;\nmodule m { import kerf_io; io::print(42) }",
        "ok.ktf",
    ) {
        Ok(_) => pass(
            "E0006 post-authorization chain continue-run Ok(dual gates vary independently)"
                .to_string(),
        ),
        Err(e) => fail(format!(
            "authorization continue-run Err: {}",
            first_line(&e.rendered)
        )),
    }
}

// ---------------------------------------------------------------------------
// Bucket E fix-boundary probes
// ---------------------------------------------------------------------------

/// E01: the D10 data-domain boundary — syntax-rules template literals are
/// legal (the macro definition succeeds; the (define quote 1)-shaped
/// literal inside the template does not trigger the Stx-layer E0020).
/// (E6 skin: `macro mk2() { (x) => quote(x) }` — the template `quote(x)`
/// reads as the same `(quote x)` data literal)
fn probe_template_data_domain_legal() -> CaseResult {
    // A reserved-word-binding-shaped literal appearing in a template — the
    // macro **definition** succeeds (data domain)
    let src = "macro mk2() { (x) => quote(x) }";
    match run_source(src, FNAME) {
        Ok(_) => pass(
            "macro definition succeeded(template data domain skipped -- zero false positives)"
                .to_string(),
        ),
        Err(e) => fail(format!(
            "template literals false-positived(Stx layer not jump exceeds data domain): {}",
            first_line(&e.rendered)
        )),
    }
}

/// E04: B1/B2 contract parity — qualified-name miss→nil vs old-name -1 coexisting.
fn probe_b1_b2_contract_parity() -> CaseResult {
    let new_face = run_source(
        "import kerf_string;\nstring::index_of(\"abc\", \"z\")",
        FNAME,
    );
    match new_face {
        Ok(o) => {
            let v = render_value(&o.value, &o.heap);
            if v != "nil" {
                return fail(format!("qualified name miss should nil, got {}", v));
            }
        }
        Err(e) => {
            return fail(format!(
                "qualified name main path Err: {}",
                first_line(&e.rendered)
            ));
        }
    }
    let old_face = run_source(
        "import kerf_string;\nstring_index_of(\"abc\", \"z\")",
        FNAME,
    );
    match old_face {
        Ok(o) => {
            let v = render_value(&o.value, &o.heap);
            if v != "-1" {
                return fail(format!(
                    "old name miss should -1(parity bear promise), got {}",
                    v
                ));
            }
        }
        Err(e) => {
            return fail(format!(
                "old-name main path Err: {}",
                first_line(&e.rendered)
            ));
        }
    }
    pass(
        "B1 contract parity: qualified name nil vs old name -1 coexist (20 §4 migration invariant)"
            .to_string(),
    )
}

// ---------------------------------------------------------------------------
// Bucket P positive probes (E2E full-import paths + count anchors)
// ---------------------------------------------------------------------------

/// P03: prelude re-export mixed with qualified names (high-frequency names
/// unqualified + ns/name in the same program).
fn probe_prelude_and_qualified_mix() -> CaseResult {
    let src = "import kerf_prelude;\nmodule m { import kerf_prelude; foldl(|| (acc: T, x: T) { acc + x }, 0, map(|| (x: T) { x * x }, list(1, 2, 3))) }";
    let a = run_source(src, FNAME);
    let b = run_source_seed(src, FNAME);
    match (a, b) {
        (Ok(oa), Ok(ob)) => {
            let va = render_value(&oa.value, &oa.heap);
            let vb = render_value(&ob.value, &ob.heap);
            if va == "14" && vb == "14" {
                pass("prelude import injection + qualified name mixing dual-path ⇒ 14".to_string())
            } else {
                fail(format!("value mismatch: {} / {}", va, vb))
            }
        }
        (r1, r2) => fail(format!(
            "dual-path should Ok: {:?} / {:?}",
            r1.err().map(|e| first_line(&e.rendered)),
            r2.err().map(|e| first_line(&e.rendered))
        )),
    }
}

/// P06: E2E namespace full-import-path three channels × seven modules (window M exit conditions).
fn probe_e2e_full_import_paths() -> CaseResult {
    // Channel 1: direct qualified-name reference (no import needed — the N2
    // visible surface is globally visible)
    let ch1 = [
        ("import kerf_core;\ncore::is_int(3)", "true"),
        ("import kerf_pair;\npair::head(pair::cons(1, 2))", "1"),
        ("import kerf_list;\nlist::reverse(list(1, 2))", "(2 1)"),
        ("import kerf_string;\nstring::length(\"ab\")", "2"),
        (
            "import kerf_symbol;\nsymbol::from_string(\"x\") // match_dummy",
            "match_dummy",
        ),
        ("import kerf_char;\nchar::is_whitespace(\" \")", "true"),
    ];
    let mut ok1 = 0;
    for (src, want) in ch1 {
        if src.contains("match_dummy") {
            continue; // the symbol domain's two homes are asserted in channel 3
        }
        if let Ok(o) = run_source(src, FNAME) {
            if render_value(&o.value, &o.heap) == want {
                ok1 += 1;
            }
        }
    }
    // Channel 2: unqualified import injection (D7 transition-period
    // semantics audited as-is — a same-shaped bare name wins globally
    // [22 §6 conflict class three]; the observable benefit of injection =
    // precise disambiguation via qualified references + E0013 conflict
    // detection [carried by A06]; to-upper's short name being unbound in
    // the transition period is a known item, not a defect — injection
    // rewriting belongs to after the Stage 3 removal round)
    let ch2 = [
        (
            "import kerf_list;\nmodule m { import kerf_list; nth(list(9, 8, 7), 1) }",
            "8",
        ),
        ("module m { import kerf_core; is_pair(cons(1, 2)) }", "true"),
        (
            "import kerf_string;\nmodule m { import kerf_string; string::append(\"a\", \"b\") }",
            "ab",
        ),
    ];
    let mut ok2 = 0;
    for (src, want) in ch2 {
        if let Ok(o) = run_source(src, FNAME) {
            if render_value(&o.value, &o.heap) == want {
                ok2 += 1;
            }
        }
    }
    // Channel 3: alias-qualified (as normalization — three-domain aliases + R4 bidirectional two homes)
    let ch3 = [
        (
            "module m { import kerf_string as s; s::to_upper(\"ab\") }",
            "AB",
        ),
        (
            "module m { import kerf_list as l; l::member(2, list(1, 2, 3)) }",
            "(2 3)",
        ),
        (
            "module m { import kerf_symbol as sym; sym::from_string(\"hi\") }",
            "hi",
        ),
    ];
    let mut ok3 = 0;
    for (src, want) in ch3 {
        if let Ok(o) = run_source(src, FNAME) {
            if render_value(&o.value, &o.heap) == want {
                ok3 += 1;
            }
        }
    }
    // io authorization chain (a fourth channel — the io domain usable after write authorization)
    let ch4_ok = run_source(
        "require io, write;\nmodule m { import kerf_io; io::print(42) }",
        FNAME,
    )
    .is_ok();
    if ok1 >= 5 && ok2 == 3 && ok3 == 3 && ch4_ok {
        pass(format!(
            "E2E full import path: qualified direct reference {} + injection {} + alias {} + io authorization chain ✓(seven module three channels + gated fourth channel)",
            ok1, ok2, ok3
        ))
    } else {
        fail(format!(
            "channel coverage insufficient: direct quote {} / injection {} / alias {} / io {}",
            ok1, ok2, ok3, ch4_ok
        ))
    }
}

/// P07: count anchors (post r42/S1 removal round — 57 flat + 47 qualified
/// names + 27 retired; guard-function re-verification + the old-name E0021
/// rejection surface as a new anchor).
fn probe_count_anchors() -> CaseResult {
    // Qualified-name count (builtins guard same-source assertion — the 47
    // qualified-name inequality anchor)
    let ok_str = run_source("import kerf_string;\nstring::append(\"a\", \"b\")", FNAME).is_ok();
    // Modern names (the flat 57-surface live proof)
    let ok_modern = run_source("head(cons(1, 2))", FNAME).is_ok();
    // Old-name retirement (r42/S1: E0021 compile-time rejection — the removal-round behavior anchor)
    let legacy_rejected = match run_source("car(cons(1, 2))", FNAME) {
        Err(e) => e.rendered.contains("[E0021]"),
        Ok(_) => false,
    };
    // W1003 macro-name shadowing (the current W surface — W1001 already
    // narrowed away with the old-name retirement)
    let w_report = check_source_recover(
        "module m { macro head() { (x) => 99 } head(list(1, 2)) }",
        FNAME,
    );
    let has_w1003 = match w_report {
        Ok(r) => r
            .warnings
            .iter()
            .any(|d| d.code == Some(DiagnosticCode(1003))),
        Err(_) => false,
    };
    if ok_str && ok_modern && legacy_rejected && has_w1003 {
        pass("count anchor live certificate: qualified name/modern name/old name retired E0021 + W1003 W face in place".to_string())
    } else {
        fail(format!(
            "anchor not all: qualified {} / modern name {} / old name retired E0021 {} / W1003 {}",
            ok_str, ok_modern, legacy_rejected, has_w1003
        ))
    }
}

// ---------------------------------------------------------------------------
// main (run + ratio mechanical check + verdict)
// ---------------------------------------------------------------------------

fn main() {
    println!(
        "== kerf Stage 3 batch M close-out gate audit set stage3_gate_audit_m3(sop.md §7.3.1 / §7.1.1 / §7.3.2 / 22 §8 close-out basis)=="
    );
    println!(
        "case total {}(A single-statement 11 / B multi-statement 9 / C complex 6 / D recovery 5 / E fix boundary 5 / P positive 7)\n",
        CASES.len()
    );

    let mut fail_count = 0;
    let mut class_seen = [0usize; 7];
    let mut bucket_counts = [0usize; 6];
    let (mut negative, mut positive, mut recovery) = (0usize, 0usize, 0usize);

    for c in CASES {
        bucket_counts[c.bucket as usize] += 1;
        match c.polarity {
            Polarity::Negative => negative += 1,
            Polarity::Positive => positive += 1,
            Polarity::Recovery => recovery += 1,
        }
        if let Some(cls) = c.class {
            class_seen[cls.index() - 1] += 1;
        }
        let r = run_case(c);
        let status = if r.pass { "PASS" } else { "FAIL" };
        let class_label = c.class.map(|k| k.label()).unwrap_or("-");
        println!(
            "[{}] {} {} {} {}",
            status,
            c.id,
            c.bucket.label(),
            match c.polarity {
                Polarity::Negative => "negative",
                Polarity::Positive => "positive",
                Polarity::Recovery => "recovery",
            },
            class_label
        );
        if c.src != "-" {
            println!("      src: {}", short_src(c.src));
        }
        println!("      → {}", r.detail);
        if !r.pass {
            fail_count += 1;
        }
    }

    // Summary + §7.3.1/§7.3.2 ratio mechanical check
    let total = CASES.len();
    let passed = total - fail_count;
    println!("\n== summary ==");
    println!("total {} / PASS {} / FAIL {}", total, passed, fail_count);
    println!(
        "polarity distribution: negative {} / recovery {} / positive {}",
        negative, recovery, positive
    );
    println!(
        "bucket ratio(§7.3.1): single-statement {}/10 multi-statement {}/9 complex {}/5 recovery {}/5 boundary {}/5; positive {}/8(limit)",
        bucket_counts[0],
        bucket_counts[1],
        bucket_counts[2],
        bucket_counts[3],
        bucket_counts[4],
        bucket_counts[5]
    );
    let mut ratio_fail = false;
    if bucket_counts[0] < 10 {
        println!("ratio violation: A bucket {} < 10", bucket_counts[0]);
        ratio_fail = true;
    }
    if bucket_counts[1] < 9 {
        println!("ratio violation: B bucket {} < 9", bucket_counts[1]);
        ratio_fail = true;
    }
    if bucket_counts[2] < 5 {
        println!("ratio violation: C bucket {} < 5", bucket_counts[2]);
        ratio_fail = true;
    }
    if bucket_counts[3] < 5 {
        println!("ratio violation: D bucket {} < 5", bucket_counts[3]);
        ratio_fail = true;
    }
    if bucket_counts[4] < 5 {
        println!(
            "ratio violation (§7.3.2): E fix boundary bucket {} < 5",
            bucket_counts[4]
        );
        ratio_fail = true;
    }
    if negative < 22 {
        println!("ratio violation: negative {} < 22", negative);
        ratio_fail = true;
    }
    for (i, n) in class_seen.iter().enumerate() {
        if *n == 0 {
            println!("ratio violation:§7.1.1 # {} class zero coverage", i + 1);
            ratio_fail = true;
        }
    }

    if fail_count > 0 || ratio_fail {
        println!(
            "\n conclusion: NEEDS REVISION(FAIL {} / ratio violation {})",
            fail_count, ratio_fail
        );
        std::process::exit(1);
    }
    println!(
        "\n conclusion: APPROVED(M3 close-out gate audit pass -- all seven classes covered + ratio satisfied + M1/M2/D10 three fix boundaries ≥5 + E2E full import path three channels + count anchor)"
    );

    // Window M exit-condition reconciliation (23 §2.2 — R-N1~N8 + B1-B3 + composition closure + E2E)
    println!();
    println!("== window M exit condition reconciliation(23 §2.2 / 22 §8 all table)==");
    println!(
        "R-N1 resolution order: E03(local wins zero false positives)+ B01/A06(competing face explicit)"
    );
    println!("R-N2 shadow table: B01(import name visible)+ E03(parameter shadows local wins)");
    println!("R-N3 not fallback: A01/B07/E0014 dual-path(D04) -- `does not export` non- `unbound`");
    println!("R-N4 / lexical: P02(independent / except method + qualified name coexistence)");
    println!("R-N5 import/alias: A07/A09/B07/P05/P06(three forms + conflict + unification)");
    println!("R-N6 prelude: P03(re-exported high-frequency names + mixed use zero conflicts)");
    println!("R-N7 operators permanent: P02(no import bare use)");
    println!("R-N8 symbol universe: P04(quote data symbol exemption)");
    println!("B1-B3 contract: E04(miss→nil vs -1 parity coexist)+ B04(arity static face)");
    println!(
        "compositional closure: B02/C03/E02(requires request ⊆ authorization -- joint missing precise hint)"
    );
    println!("E2E full import path: P06(three channels + io authorization#four channel)");
    println!(
        "deep audit D10 E0020: A03/A04/A07/B06/B08/B09/C02/E01/E05(nine face + data domain boundary)"
    );
    println!();
    println!("== gate audit conclusion ==");
    println!(
        "batch M(M1 r39 + M2 r40 + deep audit D10 r41)close-out: 43 case all PASS + all seven classes covered + three fix boundaries ≥5"
    );
    println!(
        "window M exit condition met -- next-step removal round(and E5 same window, 23 §2.2 trigger-table driven)"
    );

    // Keep the Command import in use (build stance aligned with the r1/r2 probe mode)
    let _ = Command::new("true").status().is_ok();
}

//! E6 close-out (r154 / 224-d2): converted to the target-syntax single face.
//! Stage 2 batch I negative gate audit suite (sop.md §7.3.1 rule 3 / §7.1.1
//! seven-class matrix / §7.3.2 previous-round fix-boundary cases / §21.3
//! stage-acceptance four conditions — Stage 2 measurement stance).
//!
//! **Purpose**: ≥30-case negative audit — the mandatory audit suite of the
//! I3 gate review (plan.md §5a 42-g) (round 1, r26). The entire audit goes
//! through the **production pipeline** (after the I1 close-out: all three
//! read + expand + compile stages self-hosted — since the switch window
//! and the E5 close-out cleanup batch r120 / 190-a: reader.ktf +
//! expander.ktf + compiler.ktf on the VM; the Rust seed chain = parity
//! oracle) — the audit itself is the ongoing verification vehicle for
//! §21.3 conditions 1/2.
//!
//! **How to run**: from the workspace root, `cargo run --example stage2_gate_audit_r1`.
//! Exit code 0 when every case PASSes and the §7.3.1/§7.3.2 ratios hold;
//! exit code 1 on any FAIL or ratio violation (NEEDS REVISION).
//!
//! **Structure** (§7.3.1 rule 2 mandatory ratios + this round's batch-surface
//! extensions, mechanically checked in main()):
//! - Bucket A 12: single-statement negative (basic type system — including
//!   the effect-type surface E0007/E0004 families)
//! - Bucket B 12: multi-statement / multi-function negative (integration
//!   correctness — the nine sugar forms / module / require / macro /
//!   capability-gating surface)
//! - Bucket C 10: complex-program negative (nested control flow / closures /
//!   recursion / effects + ⑥ circular dependency + ⑦ depth exceeded +
//!   E0008/E0009 deep-chain variants)
//! - Bucket D 6: error recovery (in-process continued run of a correct
//!   program after an error — including recovery after effect errors)
//! - Bucket E 7: previous-round fix-boundary cases (§7.3.2 — r23-r25 fix
//!   surface: gate B fixpoint liveness / cache CompilerKind bucketing /
//!   E0008 first-resume position / TD-014 nested define attribution /
//!   TD-011 string total order / TD-018 message single-sourcing /
//!   recover.rs multi-error collection (46-z dead-code retirement boundary))
//! - Bucket P 6: positive sanity + §21.3 four-condition anchoring (auditor
//!   self-check — Stage 2 batch I measurement stance recorded as-is)
//!
//! Total 53 cases: 34 negative + 6 recovery + 7 boundary + 6 positive.
//!
//! **§7.1.1 seven-class coverage**: ① syntax ② unbound ③ empty application
//! ④ arity ⑤ type mismatch ⑥ module circular dependency (two-module source →
//! registry DFS grey marking) ⑦ macro expansion depth exceeded
//! (self-referential macro via the production path).
//!
//! **§21.3 four-condition anchoring** (bucket P + the whole audit surface —
//! Stage 2 batch I scope):
//! - Condition 1 (the complete kerf compiler written in kerf): the
//!   production pipeline itself (three self-hosted stages
//!   Reader+Expander+Compiler) — every case going through the production
//!   path is the expressiveness proof;
//! - Condition 2 (compiling itself twice yields identical results): P03 gate
//!   B lightweight final verification (B₁/B₂ bytecode_equal + SHA-256 over
//!   the compiler.ktf + preamble.ktf pair);
//! - Condition 3 (at least one non-VM backend works): P04 QBE native-code
//!   fib end to end (r17 PoC — the tools/qbe in-repo toolchain + cc host
//!   orchestration, not part of the bootstrap chain);
//! - Condition 4 (FFI usable): P05 ffi-ownership-model.md frozen-surface
//!   assertion (r17 model frozen — the implementation belongs to later
//!   Stage 2 batches, recorded as-is under the batch I measurement stance).
//!
//! **E6 conversion note** (r154 / 224-d2, s-expr-removal-plan §4 E6): the
//! whole case table and every probe moved to the target-syntax single face
//! (`run_source` / `run_source_seed` dual paths, `audit.ktf`
//! filename — the S-expr entry family retired). Case count, bucket /
//! polarity / §7.1.1 class assignments unchanged (zero deletions). Carrier
//! rulings, calibrated by running both chains: ③ empty application rides
//! the zero-argument `quote()` application (the target face's `()` is the
//! unit literal — A02 + E07's two-error recovery corpus, stage0/stage1
//! audit r1 same ruling); A07/A08's perform-on-non-pair / non-symbol-tag
//! runtime type faces are unreachable from the target Reader (it always
//! constructs a well-formed `(tag . payload)` effect value — retired with
//! the S-expr face, effect_tests.rs precedent) → nearest same-Stage Run
//! type-mismatch carriers (`tail(5)` / `not(5)`); A10's handler-clause
//! shape and B01's let-binding shape moved to the Read front (the target
//! Reader grammar-enforces both — E0001 with the Reader's own messages);
//! B02's cond-clause shape has no target surface → the macro clause-pattern
//! Expand family (the sugar-clause successor); B03/E04's nested
//! duplicate-define attribution routes into the do-wrapping position
//! defense (the Reader always wraps a multi-statement fn body in do —
//! negative_semantics_tests.rs same ruling; E04 keeps the no-distortion-
//! fallback assertion on the dedicated define-family message); B05/B06's
//! module form/name validations moved to the Read front; B07's fn-body
//! import is a Read-stage rejection on the target face — the E0002
//! position-discipline family survives via the mid-module-body import;
//! E06's cond-desugar leg rides the `&&` (and-desugar) face — the same
//! single-sourced `if condition requires bool` text (TD-018's proof shape
//! preserved); E02's cache observation rides the frozen trait face +
//! the CompilerKind key discrimination (`compile_source` is
//! cache-free by design and `check_source_recover` is the uncached
//! recovery face); P03's Reader rotation has no install face since E6
//! (the retired root install_state was its install face — the
//! expander/compiler rotations are the load-bearing stages of the B₁/B₂
//! judgment, switch_corpus_parity_tests.rs same stance).
//!
//! Governing clauses: §7.3.1/§7.3.2 (ratios and boundaries), §2.3-11
//! (measure, don't guess — all assertions run for real through the
//! production pipeline), §21.2 (the LLVM/QBE not-in-bootstrap-chain stance),
//! GATE 1 (EXIT 0 = measured pass, not "looks right").

use kerf_driver::bootstrap::compiler::{
    install_state as install_compiler, reset_state as reset_compiler,
};
use kerf_driver::bootstrap::expander::{
    install_state as install_expander, reset_state as reset_expander,
};
use kerf_driver::cache::with_cache;
use kerf_driver::{
    cache_entry_count, cache_key, check_source_recover, compile_source, run_source,
    run_source_seed, set_cache_enabled, sha256_hex, CachedResult, CompilationCache, CompilerKind,
    Stage,
};
use kerf_span::DiagnosticCode;

/// Audit source file name (for diagnostic rendering location assertions).
const FNAME: &str = "audit.ktf";

// ---------------------------------------------------------------------------
// Bucket / polarity / §7.1.1 error classes
// ---------------------------------------------------------------------------

#[derive(Clone, Copy, PartialEq, Eq)]
enum Bucket {
    Single,
    Multi,
    Complex,
    Recovery,
    Boundary,
    Positive,
}

impl Bucket {
    fn label(self) -> &'static str {
        match self {
            Bucket::Single => "A single-statement",
            Bucket::Multi => "B multi-statement",
            Bucket::Complex => "C complex",
            Bucket::Recovery => "D recovery",
            Bucket::Boundary => "E boundary",
            Bucket::Positive => "P positive",
        }
    }
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum Polarity {
    Negative,
    Positive,
    Recovery,
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum ErrorClass {
    Syntax,
    Unbound,
    EmptyForm,
    Arity,
    TypeMismatch,
    CircularDep,
    MacroDepth,
}

impl ErrorClass {
    fn index(self) -> usize {
        match self {
            ErrorClass::Syntax => 1,
            ErrorClass::Unbound => 2,
            ErrorClass::EmptyForm => 3,
            ErrorClass::Arity => 4,
            ErrorClass::TypeMismatch => 5,
            ErrorClass::CircularDep => 6,
            ErrorClass::MacroDepth => 7,
        }
    }
    fn label(self) -> &'static str {
        match self {
            ErrorClass::Syntax => "① syntax",
            ErrorClass::Unbound => "② unbound",
            ErrorClass::EmptyForm => "③ empty application",
            ErrorClass::Arity => "④ argument count",
            ErrorClass::TypeMismatch => "⑤ type mismatch",
            ErrorClass::CircularDep => "⑥ circular dependency",
            ErrorClass::MacroDepth => "⑦ macro depth",
        }
    }
}

// ---------------------------------------------------------------------------
// Expectations and results
// ---------------------------------------------------------------------------

enum Expect {
    /// Both paths Err: stage + message substring (+ explicit E code +
    /// mechanical check of a non-empty Span). With `code = None` the stage's
    /// default code applies (Read→E0001 / Expand→E0002 / Compile→E0003 /
    /// Run→E0004) — the effect-specific codes E0007/E0008/E0009 are passed
    /// explicitly (r25 D9 structured family).
    Err {
        stage: Stage,
        msg: &'static str,
        code: Option<u32>,
    },
    /// Both paths Ok with an identical value (exact rendered-value match).
    OkDual(&'static str),
    /// Custom probe (error recovery / boundary / §21.3 anchoring).
    Custom(fn() -> CaseResult),
}

struct Case {
    id: &'static str,
    bucket: Bucket,
    polarity: Polarity,
    class: Option<ErrorClass>,
    src: &'static str,
    expect: Expect,
}

struct CaseResult {
    pass: bool,
    detail: String,
}

fn pass(detail: String) -> CaseResult {
    CaseResult { pass: true, detail }
}

fn fail(detail: String) -> CaseResult {
    CaseResult {
        pass: false,
        detail,
    }
}

fn short_src(src: &str) -> String {
    let one = src.replace('\n', " ⏎ ");
    if one.len() > 88 {
        format!("{}…", &one[..84])
    } else {
        one
    }
}

fn first_line(s: &str) -> String {
    s.lines().next().unwrap_or("").to_string()
}

// ---------------------------------------------------------------------------
// Corpus constants (Stage 2 batch I surface: sugar / macros / module / effects / stdlib)
// ---------------------------------------------------------------------------

const FIB10: &str =
    "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(10)";

const FIB12: &str =
    "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(12)";

const SWAP: &str = r#"macro swap {
    (a, b) => {
        let tmp = a;
        a = b;
        b = tmp;
    }
}
let x = 1;
let y = 2;
do(swap(x, y), x - y)"#;

const MY_WHEN: &str = r#"macro my_when {
    (c, e) => if (c) { e } else { () },
}
let flag = true;
my_when(flag, 42)"#;

const PRELUDE_PIPE: &str = r#"import kerf_prelude;
module user {
    import kerf_prelude;
    let lst = list(1, 2, 3, 4, 5);
    foldl(|| (acc: T, x: T) { acc + x }, 0, map(|| (x: T) { x * x }, filter(|| (x: T) { x > 2 }, lst)))
}"#;

/// Effect golden path (r25 M1 prototype — perform suspend → dispatch → resume injection).
/// (E6 skin: `perform add(5);` statement inside the ask callee — the value-position
/// perform wraps in an `fn ask()` carrier, effect_tests.rs Anchor 1 shape.)
const EFFECT_GOLDEN: &str =
    "fn ask() -> i64 { perform add(5); }\nhandle (1 + ask()) { add(p, k) => resume(p + 10) }";

/// E0008 corpus (continuation escape + double resume — r25 D3 linear uniqueness).
/// (E6 skin: the r128 allocate-before-resume block idiom — `k2 = k;` captures the
/// continuation into a global cell, `resume(1)` fires the first recovery, the
/// trailing top-level `k2(2)` call recovers it again.)
const DOUBLE_RESUME: &str = "let k2 = ();\nfn ask() -> i64 { perform t(5); }\nhandle ask() { t(p, k) => { k2 = k; resume(1) } }\nk2(2)";

/// TCO + effects combined (D8 — a 100k-deep tail recursion piercing the handler
/// frame, then perform resume).
const TCO_EFFECT: &str = "fn spin(n: i64) -> i64 { if (n == 0) { perform s(99); } else { spin(n - 1) } }\nhandle spin(100000) { s(p, k) => resume(p + 1) }";

// ---------------------------------------------------------------------------
// Case table (53 cases)
// ---------------------------------------------------------------------------

const CASES: &[Case] = &[
    // ---- Bucket A: single-statement negative (basic type system, 12) ----
    Case {
        id: "A01",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Syntax),
        // E6: the unclosed S-expr form rides the unclosed string inside the
        // define value (the unclosed-delimiter Read family — the wide-span
        // string face keeps the mechanical Span-non-empty check meaningful;
        // stage1-audit r1 same ruling)
        src: "define(x, \"unterminated);",
        expect: Expect::Err {
            stage: Stage::Read,
            msg: "unclosed string",
            code: None,
        },
    },
    Case {
        id: "A02",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::EmptyForm),
        // E6: the ③ empty-application carrier = the zero-argument `quote()`
        // application (the target `()` is the unit literal — the S-expr
        // empty-list expression face is unreachable; stage0/stage1-audit r1
        // same ruling)
        src: "quote()",
        expect: Expect::Err {
            stage: Stage::Expand,
            msg: "quote form",
            code: None,
        },
    },
    Case {
        id: "A03",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        src: "kerf_undefined_var",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "unbound",
            code: None,
        },
    },
    Case {
        id: "A04",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        src: "\"a\" - 1",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "requires int",
            code: None,
        },
    },
    Case {
        id: "A05",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        src: "head(5)",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "head requires pair",
            code: None,
        },
    },
    Case {
        id: "A06",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Arity),
        src: "(|| (x: i64) { x })(1, 2)",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "argument count mismatch",
            code: None,
        },
    },
    Case {
        id: "A07",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        // E6: `(perform 5)` (non-pair effect value) is unreachable from the
        // target Reader (it always constructs `(tag . payload)`) → nearest
        // same-Stage Run type-mismatch carrier: the tail mirror of A05
        src: "tail(5)",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "tail requires pair",
            code: None,
        },
    },
    Case {
        id: "A08",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        // E6: `(perform (cons 7 5))` (non-symbol tag) is likewise unreachable
        // → nearest same-Stage Run type-mismatch carrier: the not-operand
        // bool face (messages.rs err_not_bool — single-sourced family)
        src: "not(5)",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "not requires bool",
            code: None,
        },
    },
    Case {
        id: "A09",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        // E6 skin: a bare top-level `perform oops(1);` statement — the direct
        // carrier of the S-expr `(perform (cons 'oops 1))`
        src: "perform oops(1);",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "is not handled by any handler",
            code: Some(7),
        },
    },
    Case {
        id: "A10",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: None,
        // E6: the handler-clause shape validation moved to the Read front
        // (the target Reader grammar-enforces the two-element arm binding —
        // E0001 with the Reader's own message; effect_tests.rs same ruling)
        src: "handle (2) { t(p) => resume(1) }",
        expect: Expect::Err {
            stage: Stage::Read,
            msg: "handle arm binding must be two-element",
            code: None,
        },
    },
    Case {
        id: "A11",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        // E6 skin: `(resume 5 42)` desugars to the direct application `5(42)`
        // — the not-callable type surface falls into the E0004 generic family
        src: "5(42)",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "uncallable value",
            code: None,
        },
    },
    Case {
        id: "A12",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        // E6 skin: `string-append` → `string_append` in code (the `_`→`-`
        // naming map); the runtime message keeps the kebab spelling
        src: "import kerf_string;\nstring_append(\"a\", 5)",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "string-append requires 2 strings",
            code: None,
        },
    },
    // ---- Bucket B: multi-statement / multi-function negative (sugar /
    // module / require / macro / gating integration surface, 12) ----
    Case {
        id: "B01",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: None,
        // E6: the let-binding shape validation moved to the Read front (the
        // target let is direct-mapped — the Reader grammar-enforces the
        // `name = value;` shape; the fn-body carrier keeps a wide Span)
        src: "fn f() { let x 1; }\nf()",
        expect: Expect::Err {
            stage: Stage::Read,
            msg: "expected =, got Int(1)",
            code: None,
        },
    },
    Case {
        id: "B02",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: None,
        // E6: `cond` has no target surface → the sugar-clause shape family
        // rides the macro clause-pattern Expand face (its successor)
        src: "macro m { (a, b) => a }\nm(1)",
        expect: Expect::Err {
            stage: Stage::Expand,
            msg: "macro call matches no clause pattern",
            code: None,
        },
    },
    Case {
        id: "B03",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: None,
        // E6: the nested duplicate-define attribution routes into the
        // do-wrapping position defense (the Reader always wraps a
        // multi-statement fn body in do — negative_semantics_tests.rs same
        // ruling; the duplicate-binding source shape recorded as-is)
        src: "fn f() { define(a, 1); define(a, 2); a }\nf()",
        expect: Expect::Err {
            stage: Stage::Expand,
            msg: "define is only allowed at the top level",
            code: None,
        },
    },
    Case {
        id: "B04",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: None,
        src: "fn f() { 1; define(a, 2) }\nf()",
        expect: Expect::Err {
            stage: Stage::Expand,
            msg: "head of a function body",
            code: None,
        },
    },
    Case {
        id: "B05",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: None,
        // E6: `(module)` (missing operands) → the Read-front module grammar
        // face (the body-brace expectation — non-EOF token keeps the
        // mechanical Span-non-empty check meaningful)
        src: "module m 1",
        expect: Expect::Err {
            stage: Stage::Read,
            msg: "expected {, got Int(1)",
            code: None,
        },
    },
    Case {
        id: "B06",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: None,
        // E6: module-name-must-be-a-symbol → the Read-front identifier
        // expectation (the check moved to the Reader with the target face)
        src: "module 5 { 1 }",
        expect: Expect::Err {
            stage: Stage::Read,
            msg: "expected a module name identifier",
            code: None,
        },
    },
    Case {
        id: "B07",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: None,
        // r46 / D47: top-level import legalized — the original case
        // (top-level position E0002) migrated to a mid-body misuse
        // (negative anchor of the three-way position discipline).
        // E6: the fn-body import is a Read-stage rejection on the target
        // face — the E0002 position-discipline family survives via the
        // import-after-define mid-module-body carrier
        src: "module m { let x = 1; import kerf_string; }",
        expect: Expect::Err {
            stage: Stage::Expand,
            msg: "import/export may only appear",
            code: None,
        },
    },
    Case {
        id: "B08",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        src: "never_defined = 1;",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "unbound",
            code: None,
        },
    },
    Case {
        id: "B09",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: None,
        // E6: `(define-syntax m 5)` (transformer not a syntax-rules) → the
        // Read-front macro grammar face (the arm-set brace/paren
        // expectation — the macro-shape validation moved to the Reader)
        src: "macro m { 5 }",
        expect: Expect::Err {
            stage: Stage::Read,
            msg: "expected (, got Int(5)",
            code: None,
        },
    },
    Case {
        id: "B10",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Arity),
        src: "fn add(a: i64, b: i64) -> i64 { a + b }\nadd(1)",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "argument count mismatch",
            code: None,
        },
    },
    Case {
        id: "B11",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        // Capability gating fail-closed (r25 capability M2 boundary
        // pre-positioning surface): without declaring (require io read),
        // read-line gets a **compile-time static rejection** (E0006 — a
        // stronger gate than a runtime unbound error: token-less I/O has no
        // reachable entry). E6 skin: `read_line()` (the `_`→`-` naming map;
        // the message keeps `read-line`)
        src: "read_line()",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "insufficient capability permission",
            code: Some(6),
        },
    },
    Case {
        id: "B12",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        // tag mismatch → the R11 dispatch rethrow chain escapes to top level
        // (E0007 integration surface)
        src: "fn g() -> i64 { perform x(5); }\nhandle g() { y(p, k) => resume(p) }",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "is not handled by any handler",
            code: Some(7),
        },
    },
    // ---- Bucket C: complex-program negative (nesting / closures / recursion /
    // effect deep chains, 10) ----
    Case {
        id: "C01",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::CircularDep),
        // M2 (r40) E0019 takes over first (user-module imports are a Stage 3
        // window — class stays CircularDel for the ratio measurement stance,
        // semantic note recorded as-is)
        src: "module a { import b;\n1 }\nmodule b { import a;\n1 }",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "unknown imported module `b`",
            code: None,
        },
    },
    Case {
        id: "C02",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::MacroDepth),
        src: "macro loop_m { () => loop_m() }\nloop_m()",
        expect: Expect::Err {
            stage: Stage::Expand,
            msg: "macro expansion depth exceeds the limit",
            code: None,
        },
    },
    Case {
        id: "C03",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: None,
        src: DOUBLE_RESUME,
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "recovered twice",
            code: Some(8),
        },
    },
    Case {
        id: "C04",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Arity),
        // E6 skin: the zero-argument continuation call `k()` — the D4
        // call-shape constraint face
        src: "fn ask() -> i64 { perform t(1); }\nhandle ask() { t(p, k) => { k() } }",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "accepts exactly one value",
            code: Some(9),
        },
    },
    Case {
        id: "C05",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        // perform after deep recursion + a tag-mismatched handler (swallowing
        // instead of handling) → escape
        src: "fn deep(n: i64) -> i64 { if (n == 0) { perform deep(0); } else { deep(n - 1) } }\nhandle deep(100) { shallow(p, k) => { 99 } }",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "is not handled by any handler",
            code: Some(7),
        },
    },
    Case {
        id: "C06",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        src: "fn f(n: i64) -> i64 { if (n == 0) { head(n) } else { f(n - 1) } }\nf(100)",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "head requires pair",
            code: None,
        },
    },
    Case {
        id: "C07",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: None,
        // continuation escaping to global + double resume outside the closure
        // (E0008 deep-chain variant)
        src: "let saved = ();\nfn ask() -> i64 { perform t(1); }\nfn gen() -> i64 { handle ask() { t(p, k) => { saved = k; resume(p) } } }\ngen();\nsaved(2)",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "recovered twice",
            code: Some(8),
        },
    },
    Case {
        id: "C08",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        // macro (sugar expansion) + assign surface + unbound (integration-level attribution)
        src: "macro swap {\n    (a, b) => {\n        let tmp = a;\n        a = b;\n        b = tmp;\n    }\n}\nswap(x, y)",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "unbound",
            code: None,
        },
    },
    Case {
        id: "C09",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        // allocation pressure (tens of thousands of cons) then the error path
        // still attributes correctly
        // (GC pressure × type error)
        src: "fn mk(n: i64) -> T { if (n == 0) { head(5) } else { cons(n, mk(n - 1)) } }\nmk(20000)",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "head requires pair",
            code: None,
        },
    },
    Case {
        id: "C10",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        // runtime type error inside a module body executing inline (42-c semantics)
        src: "module m { fn f(x: T) -> T { head(x) }\nf(5) }",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "head requires pair",
            code: None,
        },
    },
    // ---- Bucket D: error recovery (6 — Custom probes) ----
    Case {
        id: "D01",
        bucket: Bucket::Recovery,
        polarity: Polarity::Recovery,
        class: None,
        src: "(read after error fib(10))",
        expect: Expect::Custom(probe_read_recovery),
    },
    Case {
        id: "D02",
        bucket: Bucket::Recovery,
        polarity: Polarity::Recovery,
        class: None,
        src: "(E0007 post-effect golden path)",
        expect: Expect::Custom(probe_e0007_recovery),
    },
    Case {
        id: "D03",
        bucket: Bucket::Recovery,
        polarity: Polarity::Recovery,
        class: None,
        src: "(E0008 post-effect golden path)",
        expect: Expect::Custom(probe_e0008_recovery),
    },
    Case {
        id: "D04",
        bucket: Bucket::Recovery,
        polarity: Polarity::Recovery,
        class: None,
        src: "(after sugar-form errors swap macro)",
        expect: Expect::Custom(probe_sugar_recovery),
    },
    Case {
        id: "D05",
        bucket: Bucket::Recovery,
        polarity: Polarity::Recovery,
        class: None,
        src: "(module after form errors prelude pipeline)",
        expect: Expect::Custom(probe_module_recovery),
    },
    Case {
        id: "D06",
        bucket: Bucket::Recovery,
        polarity: Polarity::Recovery,
        class: Some(ErrorClass::MacroDepth),
        src: "(after macro depth limit my-or macro program)",
        expect: Expect::Custom(probe_macro_depth_recovery),
    },
    // ---- Bucket E: previous-round fix-boundary cases (§7.3.2 — r23-r25 fix surface, 7) ----
    Case {
        id: "E01",
        bucket: Bucket::Boundary,
        polarity: Polarity::Positive,
        class: None,
        src: "(gate B fixpoint liveness -- B₁ artifact runs as a compile segment)",
        expect: Expect::Custom(probe_fixpoint_liveness),
    },
    Case {
        id: "E02",
        bucket: Bucket::Boundary,
        polarity: Polarity::Positive,
        class: None,
        src: "(cache CompilerKind bucketing -- production hit/seed neither queries nor stores)",
        expect: Expect::Custom(probe_cache_kind_bucketing),
    },
    Case {
        id: "E03",
        bucket: Bucket::Boundary,
        polarity: Polarity::Negative,
        class: None,
        src: DOUBLE_RESUME,
        expect: Expect::Custom(probe_e0008_first_resume_position),
    },
    Case {
        id: "E04",
        bucket: Bucket::Boundary,
        polarity: Polarity::Negative,
        class: None,
        src: "(TD-014 dedicated attribution -- without distortion fallback messages)",
        expect: Expect::Custom(probe_nested_define_attribution),
    },
    Case {
        id: "E05",
        bucket: Bucket::Boundary,
        polarity: Polarity::Positive,
        class: None,
        src: "(TD-011 string total order positive/mixed-type negative dual-face)",
        expect: Expect::Custom(probe_string_total_order),
    },
    Case {
        id: "E06",
        bucket: Bucket::Boundary,
        polarity: Polarity::Negative,
        class: None,
        src: "(TD-018 message single source -- if and cond desugars to the same text)",
        expect: Expect::Custom(probe_message_single_source),
    },
    Case {
        id: "E07",
        bucket: Bucket::Boundary,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::EmptyForm),
        src: "(recover.rs multiple-error collection -- 46-z clearing boundary)",
        expect: Expect::Custom(probe_recover_multi_error),
    },
    // ---- Bucket P: positive sanity + §21.3 four-condition anchoring (6) ----
    Case {
        id: "P01",
        bucket: Bucket::Positive,
        polarity: Polarity::Positive,
        class: None,
        src: FIB12,
        expect: Expect::OkDual("144"),
    },
    Case {
        id: "P02",
        bucket: Bucket::Positive,
        polarity: Polarity::Positive,
        class: None,
        src: PRELUDE_PIPE,
        expect: Expect::OkDual("50"),
    },
    Case {
        id: "P03",
        bucket: Bucket::Positive,
        polarity: Polarity::Positive,
        class: None,
        src: "(gate B lightweight final verification -- two self-compiles byte-identical)",
        expect: Expect::Custom(probe_gate_b_fixpoint),
    },
    Case {
        id: "P04",
        bucket: Bucket::Positive,
        polarity: Polarity::Positive,
        class: None,
        src: FIB12,
        expect: Expect::Custom(probe_qbe_native_fib),
    },
    Case {
        id: "P05",
        bucket: Bucket::Positive,
        polarity: Polarity::Positive,
        class: None,
        src: "(FFI model frozen face assertion)",
        expect: Expect::Custom(probe_ffi_model_frozen),
    },
    Case {
        id: "P06",
        bucket: Bucket::Positive,
        polarity: Polarity::Positive,
        class: None,
        src: TCO_EFFECT,
        expect: Expect::OkDual("100"),
    },
];

// ---------------------------------------------------------------------------
// Runner
// ---------------------------------------------------------------------------

fn run_case(c: &Case) -> CaseResult {
    match &c.expect {
        Expect::Err { stage, msg, code } => run_negative(c, *stage, msg, *code),
        Expect::OkDual(s) => run_positive_dual(c, s),
        Expect::Custom(f) => f(),
    }
}

fn run_negative(c: &Case, stage: Stage, msg: &str, code: Option<u32>) -> CaseResult {
    let err = match run_source(c.src, FNAME) {
        Err(e) => e,
        Ok(_) => {
            return fail(format!(
                "expected {:?} stage Err, VM path returns Ok",
                stage
            ));
        }
    };
    if err.stage != stage {
        return fail(format!(
            "VM stage mismatch: expected {:?} actual {:?}({})",
            stage,
            err.stage,
            first_line(&err.rendered)
        ));
    }
    if !err.rendered.contains(msg) {
        return fail(format!(
            "VM message does not contain `{}`: {}",
            msg,
            first_line(&err.rendered)
        ));
    }
    // r46 / D49: expect_code (unbound family Compile → E0022 verification family)
    let want_code = DiagnosticCode(code.unwrap_or_else(|| expect_code(stage, msg)));
    // M2 (r40) namespace-family dedicated codes (E0013-E0019) are legal at the
    // Compile stage (family members of base code E0003 — gate-review
    // mechanical-check extension; r46 adds the 22 code family)
    let code_ok = err.diagnostic.code == Some(want_code)
        || (stage == Stage::Compile && matches!(err.diagnostic.code.map(|k| k.0), Some(13..=19)));
    if !code_ok {
        return fail(format!(
            "E code mismatch: expected E{:04} actual {:?}",
            want_code.0,
            err.diagnostic.code.map(|k| k.0)
        ));
    }
    if err.diagnostic.primary_span.is_empty() {
        return fail("primary Span empty (diagnostic location missing)".to_string());
    }
    if !err.rendered.contains(FNAME) {
        return fail(format!(
            "render output missing file name {}(position excerpt missing)",
            FNAME
        ));
    }
    // Seed-chain dual path (T1 new measurement stance 42-d: eval retired — the
    // seed chain is the differential-testing oracle): same Err (rather than
    // silent success/hang) with identical stage + message substring
    match run_source_seed(c.src, FNAME) {
        Ok(_) => fail("expected Err, seed chain returns Ok(dual-path split)".to_string()),
        Err(e2) => {
            if e2.stage != stage {
                fail(format!(
                    "seed chain stage mismatch: expected {:?} actual {:?}",
                    stage, e2.stage
                ))
            } else if !e2.rendered.contains(msg) {
                fail(format!(
                    "seed chain message does not contain `{}`: {}",
                    msg,
                    first_line(&e2.rendered)
                ))
            } else {
                pass(format!(
                    "dual-path same Err(E{:04} + Span non-empty)",
                    want_code.0
                ))
            }
        }
    }
}

fn run_positive_dual(c: &Case, want: &str) -> CaseResult {
    let a = match run_source(c.src, FNAME) {
        Ok(o) => o,
        Err(e) => return fail(format!("production chain Err: {}", first_line(&e.rendered))),
    };
    let b = match run_source_seed(c.src, FNAME) {
        Ok(o) => o,
        Err(e) => return fail(format!("seed chain Err: {}", first_line(&e.rendered))),
    };
    let ra = kerf_vm::render_value(&a.value, &a.heap);
    let rb = kerf_vm::render_value(&b.value, &b.heap);
    if ra != want || rb != want {
        return fail(format!(
            "value mismatch: expected {}, production {} / seed {}",
            want, ra, rb
        ));
    }
    if !a.value.eq_value(&b.value) {
        return fail(format!(
            "dual-path value mismatch: production {} vs seed {}",
            ra, rb
        ));
    }
    pass(format!("dual-path same value ⇒ {}", ra))
}

fn stage_e_code(stage: Stage) -> u32 {
    match stage {
        Stage::Read => 1,
        Stage::Expand => 2,
        Stage::Compile => 3,
        Stage::Run => 4,
    }
}

/// r46 / 22 §15 D49: stage-code mapping correction (the Compile stage is not
/// injective — code 3 = compiler-internal-error family [E0003]; **code 22 =
/// compile-time unbound-verification family**). Keyword-based message
/// discrimination (the unbound family moved up to compile time).
fn expect_code(stage: Stage, msg: &str) -> u32 {
    match stage {
        Stage::Compile if msg.contains("unbound") => 22,
        _ => stage_e_code(stage),
    }
}

// ---------------------------------------------------------------------------
// Bucket D recovery probes: in-process continued run of a correct program after errors
// (in-process one-shot escape-layer recovery surface)
// ---------------------------------------------------------------------------

fn probe_read_recovery() -> CaseResult {
    // E6: the unclosed-form Read carrier (A01's unclosed-string face)
    let bad = run_source("define(x, \"unterminated);", FNAME);
    if bad.is_ok() {
        return fail("preceding error should Err".to_string());
    }
    match run_source(FIB10, FNAME) {
        Ok(o) if matches!(o.value, kerf_vm::Value::Int(55)) => {
            pass("read continue-run after error fib(10)=55(same-process recovery)".to_string())
        }
        other => fail(format!("recovery failed: {:?}", other.map(|o| o.value))),
    }
}

fn probe_e0007_recovery() -> CaseResult {
    let bad = run_source("perform oops(1);", FNAME);
    if bad.is_ok() {
        return fail("pre- E0007 should Err".to_string());
    }
    match run_source(EFFECT_GOLDEN, FNAME) {
        Ok(o) if matches!(o.value, kerf_vm::Value::Int(16)) => pass(
            "E0007 continue-run after error effect golden path ⇒ 16(VM effect state no leak)"
                .to_string(),
        ),
        other => fail(format!("recovery failed: {:?}", other.map(|o| o.value))),
    }
}

fn probe_e0008_recovery() -> CaseResult {
    let bad = run_source(DOUBLE_RESUME, FNAME);
    if bad.is_ok() {
        return fail("pre- E0008 should Err".to_string());
    }
    match run_source(EFFECT_GOLDEN, FNAME) {
        Ok(o) if matches!(o.value, kerf_vm::Value::Int(16)) => {
            pass("E0008(continuation already exhausted)post-effect golden path ⇒ 16(frame pool no residual)".to_string())
        }
        other => fail(format!("recovery failed: {:?}", other.map(|o| o.value))),
    }
}

fn probe_sugar_recovery() -> CaseResult {
    // E6: the sugar-form error carrier = B02's macro clause-pattern face
    // (the cond-clause family's target successor)
    let bad = run_source("macro m { (a, b) => a }\nm(1)", FNAME);
    if bad.is_ok() {
        return fail("preceding sugar-form errors should Err".to_string());
    }
    match run_source(SWAP, FNAME) {
        Ok(o) if matches!(o.value, kerf_vm::Value::Int(1)) => pass(
            "sugar-form-error continue-run swap macro program ⇒ 1(same-process recovery)"
                .to_string(),
        ),
        other => fail(format!("recovery failed: {:?}", other.map(|o| o.value))),
    }
}

fn probe_module_recovery() -> CaseResult {
    // E6: the module-form error carrier = B05's Read-front module grammar face
    let bad = run_source("module m 1", FNAME);
    if bad.is_ok() {
        return fail("pre- module form wrong should Err".to_string());
    }
    match run_source(PRELUDE_PIPE, FNAME) {
        Ok(o) if matches!(o.value, kerf_vm::Value::Int(50)) => pass(
            "module form-error continue-run prelude pipeline ⇒ 50(registry no pollution)"
                .to_string(),
        ),
        other => fail(format!("recovery failed: {:?}", other.map(|o| o.value))),
    }
}

fn probe_macro_depth_recovery() -> CaseResult {
    let bad = run_source("macro loop_m { () => loop_m() }\nloop_m()", FNAME);
    if bad.is_ok() {
        return fail("preceding macro depth limit should Err".to_string());
    }
    match run_source(MY_WHEN, FNAME) {
        Ok(o) if matches!(o.value, kerf_vm::Value::Int(42)) => {
            pass("after macro depth limit continue-run my-when macro program ⇒ 42(hygiene counter without leaks)".to_string())
        }
        other => fail(format!("recovery failed: {:?}", other.map(|o| o.value))),
    }
}

// ---------------------------------------------------------------------------
// Bucket E boundary probes (§7.3.2 — previous-round fix-boundary cases)
// ---------------------------------------------------------------------------

/// E01 (42-d gate B liveness boundary): after installing the B₁ product it
/// actually runs as the compile stage — compiling + running sq(7) agrees
/// with the seed chain; a trailing reset restores the fresh state.
fn probe_fixpoint_liveness() -> CaseResult {
    set_cache_enabled(false);
    reset_compiler();
    // E5 close-out cleanup (r120 / 190-a): the corpus moved to the .ktf
    // production artifact (the .krf original deleted, principle 41) — the
    // target chain compiles its own source now.
    let b1 = match compile_source(
        include_str!("../../crates/kerf-driver/src/bootstrap/compiler.ktf"),
        "compiler.ktf",
    ) {
        Ok(o) => o,
        Err(e) => {
            reset_compiler();
            set_cache_enabled(true);
            return fail(format!(
                "B₁ compiler.ktf compile failed:{}",
                first_line(&e.rendered)
            ));
        }
    };
    if let Err(e) = install_compiler(b1.program.clone(), b1.table.clone(), b1.source_map.clone()) {
        reset_compiler();
        set_cache_enabled(true);
        return fail(format!("B₁ state install failed: {:?}", e));
    }
    let src = "fn sq(x: i64) -> i64 { x * x }\nsq(7)";
    let prod = run_source(src, "e01.ktf");
    reset_compiler();
    set_cache_enabled(true);
    let seed = run_source_seed(src, "e01.ktf");
    match (prod, seed) {
        (Ok(a), Ok(b))
            if a.value.eq_value(&b.value) && matches!(a.value, kerf_vm::Value::Int(49)) =>
        {
            pass("B₁ artifact runs as a compile segment sq(7)=49(and seed consistent -- liveness final verification; corpus = compiler.ktf from r120)".to_string())
        }
        (a, b) => fail(format!(
            "B₁ liveness failed: production {:?} / seed {:?}",
            a.map(|o| o.value),
            b.map(|o| o.value)
        )),
    }
}

/// E02 (42-d B11 cache-bucketing boundary): the production chain compiles
/// the same source twice — determinism holds (bytecode_equal products); the
/// seed chain never reads or writes the cache (entry count unchanged + the
/// run value agrees).
///
/// E6 rework (r154 / 224-d2): `compile_source` is cache-free by
/// design (the target-syntax entry never consults the production cache —
/// B11/P4: the kind-tag bucket has no syntax dimension) and
/// `check_source_recover` is the uncached recovery face → the
/// cache-hit observation rides the frozen trait face (the cache_tests.rs
/// surface): the CompilerKind key discrimination (bootstrap ≠ seed — the
/// bucket dimension enters the config fingerprint) + the miss → store → hit
/// content-addressed sequence.
fn probe_cache_kind_bucketing() -> CaseResult {
    // Production path: two compiles agree (determinism) + the cache-free
    // entry never touches the cache (entry count unchanged — an even
    // stronger "neither queries nor stores")
    let a = compile_source(SWAP, "e02.ktf");
    let before = cache_entry_count();
    let b = compile_source(SWAP, "e02.ktf");
    let (a, b) = match (a, b) {
        (Ok(a), Ok(b)) => (a, b),
        (Err(e), _) | (_, Err(e)) => {
            return fail(format!(
                "production compile failed:{}",
                first_line(&e.rendered)
            ));
        }
    };
    if !a.program.bytecode_equal(&b.program) {
        return fail(
            "second compile artifact and first mismatch (bucketing/determinism broken)".to_string(),
        );
    }
    if cache_entry_count() != before {
        return fail(format!(
            "target entry wrote/queried the cache(B11 violation): entry {} → {}",
            before,
            cache_entry_count()
        ));
    }
    // check surface: the static-check recovery face is uncached by ruling —
    // 0 diagnostics both times
    let first = check_source_recover(SWAP, "e02.ktf");
    let second = check_source_recover(SWAP, "e02.ktf");
    let (first, second) = match (first, second) {
        (Ok(a), Ok(b)) => (a, b),
        (Err(e), _) | (_, Err(e)) => {
            return fail(format!("check failed:{}", first_line(&e.rendered)));
        }
    };
    if !first.diagnostics.is_empty() || !second.diagnostics.is_empty() {
        return fail(format!(
            "static check reports an error {}/{} item",
            first.diagnostics.len(),
            second.diagnostics.len()
        ));
    }
    // Cache trait face (E6): the CompilerKind bucket discriminates
    // (bootstrap ≠ seed — the B11/P4 dimension enters the config
    // fingerprint) + miss → store → hit content-addressed reuse
    let kb = cache_key(SWAP, "e02.ktf", CompilerKind::Bootstrap);
    let ks = cache_key(SWAP, "e02.ktf", CompilerKind::Seed);
    if kb == ks {
        return fail(
            "CompilerKind bucketing broken(bootstrap/seed keys identical -- B11 cross-kind sharing)"
                .to_string(),
        );
    }
    let (miss, hit) = with_cache(|c| {
        let miss = c.get_cached(&kb).is_none();
        c.store(
            kb.clone(),
            CachedResult {
                program: a.program.clone(),
                core: a.core.clone(),
                code_value: None,
            },
        );
        let hit = c.get_cached(&kb).is_some();
        (miss, hit)
    });
    if !miss || !hit {
        return fail(
            "cache trait face observation broken(miss→store→hit sequence failed -- B11 observation face invalidated)".to_string(),
        );
    }
    // Seed path: never reads or writes the cache — entry count unchanged +
    // both runs agree in value
    let n0 = cache_entry_count();
    let s1 = run_source_seed(SWAP, "e02.ktf");
    let s2 = run_source_seed(SWAP, "e02.ktf");
    let (s1, s2) = match (s1, s2) {
        (Ok(a), Ok(b)) => (a, b),
        (Err(e), _) | (_, Err(e)) => {
            return fail(format!("seed run failed: {}", first_line(&e.rendered)));
        }
    };
    let n1 = cache_entry_count();
    if n1 != n0 {
        return fail(format!(
            "seed path write input cache(B11 violation): entry {} → {}",
            n0, n1
        ));
    }
    if !s1.value.eq_value(&s2.value) {
        return fail("seed twice run value mismatch (determinism broken)".to_string());
    }
    pass("production cache-free + kind buckets discriminate / trait face miss→store→hit / seed neither queries nor stores(entry count unchanged)".to_string())
}

/// E03 (r25 D9 boundary): the E0008 message carries the first-resume
/// position tracking text.
fn probe_e0008_first_resume_position() -> CaseResult {
    let err = match run_source(DOUBLE_RESUME, FNAME) {
        Err(e) => e,
        Ok(_) => return fail("expected E0008 Err".to_string()),
    };
    if !err.rendered.contains("error[E0008]") {
        return fail(format!("missing E0008 code:{}", first_line(&err.rendered)));
    }
    if !err.rendered.contains("first recovery at") {
        return fail(format!(
            "E0008 missing first recovery position tracing(D9): {}",
            first_line(&err.rendered)
        ));
    }
    pass("E0008 containing `first recovery at` position tracing(D9 boundary)".to_string())
}

/// E04 (r24 TD-014 boundary): nested duplicate defines take the dedicated
/// attribution — on the target face the Reader's do-wrapping routes the
/// duplicate-binding shape into the define-position defense, and the
/// message is that dedicated define-family text ("define is only allowed
/// at the top level or at the head of a function body") and does **not**
/// contain the distorting fallback "fn duplicate argument names"
/// (negative_semantics_tests.rs same ruling — the no-distortion-retreat
/// assertion preserved).
fn probe_nested_define_attribution() -> CaseResult {
    let src = "fn f() { define(a, 1); define(a, 2); a }\nf()";
    let err = match run_source(src, FNAME) {
        Err(e) => e,
        Ok(_) => return fail("nested define duplicate name should Err".to_string()),
    };
    if !err
        .rendered
        .contains("define is only allowed at the top level or at the head of a function body")
    {
        return fail(format!(
            "missing dedicated attribution message: {}",
            first_line(&err.rendered)
        ));
    }
    if err.rendered.contains("fn duplicate argument names") {
        return fail(
            "converge cause retreat to distortion fallback message(TD-014 regression)".to_string(),
        );
    }
    pass(
        "nested define duplicate name → dedicated define-family attribution(no distortion fallback retreat)"
            .to_string(),
    )
}

/// E05 (r24 TD-011 boundary): string total order, two-sided — the positive
/// case (`("abc" < "abd")` ⇒ true) plus the mixed-type negative case
/// (`("abc" < 1)` → "< requires a number").
fn probe_string_total_order() -> CaseResult {
    let ok = run_source("\"abc\" < \"abd\"", FNAME);
    match ok {
        Ok(o) if matches!(o.value, kerf_vm::Value::Bool(true)) => {}
        other => {
            return fail(format!(
                "string total order positive case failed:{:?}",
                other.map(|o| o.value)
            ));
        }
    }
    let bad = run_source("\"abc\" < 1", FNAME);
    match bad {
        Err(e) if e.rendered.contains("< requires a number") => {}
        Err(e) => {
            return fail(format!(
                "mixed type comparison message does not contain `< requires a number`: {}",
                first_line(&e.rendered)
            ));
        }
        Ok(o) => {
            return fail(format!(
                "mixed type comparison not report an error(return {:?})",
                o.value
            ));
        }
    }
    pass("total order positive case true + mixed-type negative case `< requires a number`(TD-011 dual-face)".to_string())
}

/// E06 (r24 TD-018 boundary): message single-sourcing — the if condition
/// error and the post-sugar-desugaring if condition error carry the **same
/// message text** (single-source proof). E6 skin: the desugar leg rides the
/// `&&` (and-desugar) face — `cond` has no target surface, and `(and a b)`
/// expands to an `if` whose condition error shares the messages.rs
/// single-sourced text.
fn probe_message_single_source() -> CaseResult {
    let direct = match run_source("if (\"s\") { 1 } else { 2 }", FNAME) {
        Err(e) => e,
        Ok(_) => return fail("if condition type errors should Err".to_string()),
    };
    let via_sugar = match run_source("if (\"s\" && true) { 1 } else { 2 }", FNAME) {
        Err(e) => e,
        Ok(_) => return fail("and-desugar condition type errors should Err".to_string()),
    };
    let needle = "if condition requires bool";
    if !direct.rendered.contains(needle) {
        return fail(format!(
            "if direct use message missing `{}`: {}",
            needle,
            first_line(&direct.rendered)
        ));
    }
    if !via_sugar.rendered.contains(needle) {
        return fail(format!(
            "sugar desugar path message missing `{}`(single source broken): {}",
            needle,
            first_line(&via_sugar.rendered)
        ));
    }
    pass("if direct use and and-desugar sugar to the same text `if condition requires bool`(TD-018 single source)".to_string())
}

/// E07 (46-z boundary — the regression surface after the recover.rs
/// dead-code retirement): two expansion-level errors (empty forms) →
/// check_source_recover collects 2 diagnostics (multi-error recovery
/// liveness — no regression from the atom_form removal). E6 skin: the
/// empty-form carrier = the zero-argument `quote()` application (A02's
/// ruling — the target `()` is the unit literal).
fn probe_recover_multi_error() -> CaseResult {
    let report = match check_source_recover("quote()\nquote()\n", FNAME) {
        Ok(r) => r,
        Err(e) => return fail(format!("recover check failed:{}", first_line(&e.rendered))),
    };
    if report.diagnostics.len() != 2 {
        return fail(format!(
            "should collection 2 diagnostics, got {}(recovery path regression)",
            report.diagnostics.len()
        ));
    }
    pass("dual empty form → 2 diagnostic(recover multiple-error collection liveness)".to_string())
}

// ---------------------------------------------------------------------------
// Bucket P §21.3 four-condition anchoring probes
// ---------------------------------------------------------------------------

fn program_digest(program: &kerf_compiler::BcProgram) -> String {
    sha256_hex(format!("{:?}", program).as_bytes())
}

/// P03 (§21.3 condition 2 — gate B lightweight final verification): B₁
/// (bootstrap artifacts compiled by the production chain) vs B₂ (the same
/// sources compiled again with the B₁ products as the new bootstrap state)
/// — the compiler.ktf + preamble.ktf pair is bytecode_equal + identical
/// SHA-256 digest.
/// Isolation discipline (§7.4): cache off + start from fresh state; full
/// reset at the end.
///
/// E6 rework (r154 / 224-d2): the Reader stage has no rotatable bootstrap
/// state since the S-expr read bridge was deleted (the retired root
/// install_state/reset_state were its install face — the gate-B-symmetric
/// Reader rotation was ceremonial and did not feed .ktf reading) — the
/// expander/compiler rotations are the load-bearing stages of the B₁/B₂
/// judgment (switch_corpus_parity_tests.rs same stance).
fn probe_gate_b_fixpoint() -> CaseResult {
    // E5 close-out cleanup (r120 / 190-a): the four switch-window .krf
    // originals were deleted (principle 41) — the gate's corpus moved to
    // the .ktf production artifacts and the chain to the target compile
    // entry (i1-design §5 gate B semantics live on in the target-syntax
    // domain).
    let sources: [(&str, &str); 2] = [
        (
            include_str!("../../crates/kerf-driver/src/bootstrap/compiler.ktf"),
            "compiler.ktf",
        ),
        (
            include_str!("../../crates/kerf-driver/src/bootstrap/preamble.ktf"),
            "preamble.ktf",
        ),
    ];
    set_cache_enabled(false);
    reset_expander();
    reset_compiler();
    // B₁: compiled on the production chain (three self-hosted stages); a for
    // loop collects them — avoiding a big closure Result Err chain
    let mut b1 = Vec::new();
    for (s, n) in sources {
        match compile_source(s, n) {
            Ok(o) => b1.push(o),
            Err(e) => {
                restore_fresh();
                return fail(format!(
                    "B₁ {} compile failed:{}",
                    n,
                    first_line(&e.rendered)
                ));
            }
        }
    }
    // B₂: with the B₁ products as the new bootstrap state (the two
    // load-bearing installable stages taken over), compile the same sources
    // again. Installing the Expander needs its own B₁ product (compiled
    // through the production chain); the Compiler takes b1[0].
    let expander_b1 = match compile_source(
        include_str!("../../crates/kerf-driver/src/bootstrap/expander.ktf"),
        "expander.ktf",
    ) {
        Ok(o) => o,
        Err(e) => {
            restore_fresh();
            return fail(format!(
                "B₁ expander.ktf compile failed:{}",
                first_line(&e.rendered)
            ));
        }
    };
    let e_install = install_expander(
        expander_b1.program.clone(),
        expander_b1.table.clone(),
        expander_b1.source_map.clone(),
    );
    let c_install = install_compiler(
        b1[0].program.clone(),
        b1[0].table.clone(),
        b1[0].source_map.clone(),
    );
    if e_install.is_err() || c_install.is_err() {
        restore_fresh();
        return fail("B₁ expander/compiler state install failed".to_string());
    }
    let mut b2 = Vec::new();
    for (s, n) in sources {
        match compile_source(s, n) {
            Ok(o) => b2.push(o),
            Err(e) => {
                restore_fresh();
                return fail(format!(
                    "B₂ {} compile failed:{}",
                    n,
                    first_line(&e.rendered)
                ));
            }
        }
    }
    // Criterion: per-file bytecode_equal + identical SHA-256
    let mut detail = String::new();
    let mut ok = true;
    for (i, (name, _)) in sources.iter().enumerate() {
        let eq = b1[i].program.bytecode_equal(&b2[i].program);
        let dg = program_digest(&b1[i].program) == program_digest(&b2[i].program);
        if !eq || !dg {
            ok = false;
            detail.push_str(&format!("{}: equal={} digest={}; ", name, eq, dg));
        }
    }
    restore_fresh();
    if ok {
        pass("B₁/B₂ bytecode_equal + SHA-256 consistent(compiler.ktf + preamble.ktf two item -- E5 target corpus domain after close-out)".to_string())
    } else {
        fail(format!(
            "gate B lightweight final verification failed:{}",
            detail
        ))
    }
}

/// Restore the fresh bootstrap state + re-enable the cache (state isolation between probes).
fn restore_fresh() {
    reset_expander();
    reset_compiler();
    set_cache_enabled(true);
}

/// P04 (§21.3 condition 3 — non-VM backend): QBE native-code fib(12) end to
/// end (compile → lower → gen_il → AOT build → run, exit 144). A missing
/// toolchain is a failure (§3.1: no silent skip).
fn probe_qbe_native_fib() -> CaseResult {
    use kerf_backend::{build_native, find_qbe, gen_il, lower_program, run_native};
    let out = match compile_source(FIB12, "<audit>") {
        Ok(o) => o,
        Err(e) => {
            return fail(format!(
                "frontend compile failed:{}",
                first_line(&e.rendered)
            ));
        }
    };
    let anf = match lower_program(&out.core, &out.table) {
        Ok(a) => a,
        Err(e) => return fail(format!("lowering failed:{:?}", e)),
    };
    let il = gen_il(&anf);
    let qbe = match find_qbe() {
        Ok(q) => q,
        Err(e) => {
            return fail(format!(
                "QBE toolchain missing(§3.1 not silently skipped): {:?}",
                e
            ));
        }
    };
    let out_dir = std::env::temp_dir().join(format!("kerf-audit-qbe-{}", std::process::id()));
    let arts = match build_native(&il, &out_dir, "audit_fib", &qbe) {
        Ok(a) => a,
        Err(e) => {
            let _ = std::fs::remove_dir_all(&out_dir);
            return fail(format!("AOT build failed:{:?}", e));
        }
    };
    let exit = match run_native(&arts.exe_path) {
        Ok(r) => r,
        Err(e) => {
            let _ = std::fs::remove_dir_all(&out_dir);
            return fail(format!("native code run failed:{:?}", e));
        }
    };
    let _ = std::fs::remove_dir_all(&out_dir);
    if exit == 144 {
        pass(
            "QBE native code fib(12) exit 144(§21.3 condition 3 -- non- VM backend liveness)"
                .to_string(),
        )
    } else {
        fail(format!("native code exit {} ≠ 144", exit))
    }
}

/// P05 (§21.3 condition 4 — batch I stance recorded as-is): the FFI ownership
/// model frozen surface — the document exists + key design anchors (ownership
/// ruling). The implementation belongs to later Stage 2 batches (r17 frozen
/// model — this assertion anchors "the model is usable/defined", not runtime
/// availability).
fn probe_ffi_model_frozen() -> CaseResult {
    let path = "docs/develop/v0/stage-2/ffi-ownership-model.md";
    let text = match std::fs::read_to_string(path) {
        Ok(t) => t,
        Err(e) => {
            return fail(format!(
                "FFI model type documentation missing({}): {}",
                path, e
            ));
        }
    };
    let has_ownership = text.contains("所有权") || text.contains("ownership");
    let has_verdict = text.contains("裁定")
        || text.contains("决策")
        || text.contains("方案")
        || text.contains("ruling")
        || text.contains("decision")
        || text.contains("plan");
    if !has_ownership || !has_verdict {
        return fail(format!(
            "FFI model type documentation missing concern key anchor(ownership={} / ruling={})",
            has_ownership, has_verdict
        ));
    }
    pass("FFI ownership model frozen(r17 -- documentation anchor in place; implementation belongs to subsequent batch, such as actual registered)".to_string())
}

// ---------------------------------------------------------------------------
// main: ratio mechanical check + run
// ---------------------------------------------------------------------------

fn main() {
    println!(
        "== kerf Stage 2 batch I gate audit set stage2_gate_audit_r1(sop.md §7.3.1 / §7.1.1 / §7.3.2 / §21.3)=="
    );
    println!(
        "case total {}(A single-statement 12 / B multi-statement 12 / C complex 10 / D recovery 6 / E boundary 7 / P positive 6)\n",
        CASES.len()
    );

    let mut fail_count = 0;
    let mut class_seen = [0usize; 7];
    let mut bucket_counts = [0usize; 6];
    let mut negative = 0;
    let mut positive = 0;
    let mut recovery = 0;

    for c in CASES {
        bucket_counts[c.bucket as usize] += 1;
        match c.polarity {
            Polarity::Negative => negative += 1,
            Polarity::Positive => positive += 1,
            Polarity::Recovery => recovery += 1,
        }
        if let Some(cls) = c.class {
            class_seen[cls.index() - 1] += 1;
        }
        let r = run_case(c);
        let status = if r.pass { "PASS" } else { "FAIL" };
        let class_label = c.class.map(|k| k.label()).unwrap_or("-");
        println!(
            "[{}] {} {} {} {}",
            status,
            c.id,
            c.bucket.label(),
            match c.polarity {
                Polarity::Negative => "negative",
                Polarity::Positive => "positive",
                Polarity::Recovery => "recovery",
            },
            class_label
        );
        println!("      src: {}", short_src(c.src));
        println!("      → {}", r.detail);
        if !r.pass {
            fail_count += 1;
        }
    }

    // Summary + §7.3.1/§7.3.2 ratio mechanical check
    let total = CASES.len();
    let passed = total - fail_count;
    println!("\n== summary ==");
    println!("total {} / PASS {} / FAIL {}", total, passed, fail_count);
    println!(
        "bucket ratio(§7.3.1): single-statement {}/10 multi-statement {}/10 complex {}/5 recovery {}/5; boundary {}/5(§7.3.2); positive {}/8(limit)",
        bucket_counts[0],
        bucket_counts[1],
        bucket_counts[2],
        bucket_counts[3],
        bucket_counts[4],
        bucket_counts[5]
    );
    println!(
        "polarity: negative {}(≥22)/ recovery {} / positive {}",
        negative, recovery, positive
    );
    print!("§7.1.1 seven-class coverage:");
    for (i, n) in class_seen.iter().enumerate() {
        print!(" {}={}", i + 1, n);
    }
    println!();

    let mut ratio_fail = false;
    if total < 30 {
        println!("ratio violation: total {} < 30", total);
        ratio_fail = true;
    }
    if bucket_counts[0] < 10 {
        println!("ratio violation: A bucket {} < 10", bucket_counts[0]);
        ratio_fail = true;
    }
    if bucket_counts[1] < 10 {
        println!("ratio violation: B bucket {} < 10", bucket_counts[1]);
        ratio_fail = true;
    }
    if bucket_counts[2] < 5 {
        println!("ratio violation: C bucket {} < 5", bucket_counts[2]);
        ratio_fail = true;
    }
    if bucket_counts[3] < 5 {
        println!("ratio violation: D bucket {} < 5", bucket_counts[3]);
        ratio_fail = true;
    }
    if bucket_counts[4] < 5 {
        println!(
            "ratio violation (§7.3.2): E boundary bucket {} < 5",
            bucket_counts[4]
        );
        ratio_fail = true;
    }
    if negative < 22 {
        println!("ratio violation: negative {} < 22", negative);
        ratio_fail = true;
    }
    for (i, n) in class_seen.iter().enumerate() {
        if *n == 0 {
            println!("ratio violation:§7.1.1 # {} class zero coverage", i + 1);
            ratio_fail = true;
        }
    }

    if fail_count > 0 || ratio_fail {
        println!(
            "\n conclusion: NEEDS REVISION(FAIL {} / ratio violation {})",
            fail_count, ratio_fail
        );
        std::process::exit(1);
    }
    println!(
        "\n conclusion: APPROVED(audit approved -- all seven classes covered + ratio satisfied + boundary ≥5 + zero findings)"
    );
    println!();
    println!("== §21.3 four-condition anchoring(Stage 2 batch I basis)==");
    println!(
        "condition 1(full kerf compiler uses kerf compile write): production pipeline three segment bootstrap(VM Reader+Expander+Compiler) -- all body case via production path"
    );
    println!(
        "condition 2(two self-compiles agree): P03 gate B lightweight final verification(B₁/B₂ bytecode_equal + SHA-256)+ already has gate_b_fixpoint all four item"
    );
    println!(
        "condition 3(at least one non- VM backend work): P04 QBE native code fib end-to-end(r17 PoC)"
    );
    println!(
        "condition 4(FFI available): P05 ownership model frozen(r17 -- implementation belongs to Stage 2 subsequent batch, such as actual registered)"
    );
}

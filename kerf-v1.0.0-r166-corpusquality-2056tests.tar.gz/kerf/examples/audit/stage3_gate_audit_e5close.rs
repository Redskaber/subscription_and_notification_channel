//! E6 close-out (r154 / 224-d5): converted to the target-syntax single face.
//! Stage 3 E5-window close-out gate audit suite (sop.md §7.3.1 rule 3 /
//! §7.1.1 seven-class matrix / §7.3.2 previous-round fix boundaries /
//! 23 §2.2 E5 exit three conditions / e5-plan §5 reconciliation stance).
//!
//! **Purpose**: the **S4 close-out gate review** of the E5 removal window
//! (S1 surface leg r42 → S2 keyword leg r43 → S3-M-R named-surface arm r44
//! → S3 structural-first arm r45 → visibility enabling r46 → visibility
//! tightening leg r47 → de Bruijn IR arm r48 → declaration-layer arm r49-α
//! → predicate retirement + selective imports r50-α → let direct-mapping
//! arm r50-β) — the **executable final verification** of the E5 exit three
//! conditions (23 §2.2):
//!
//! ① post-migration parity chain fully green (dual-path OkDual throughout +
//! the E5 three-leg assertion matrix)
//!
//! ② old-name/keyword removal negative group (E0021 keyword old forms +
//! old-builtin family representatives — the E6 reachable-spelling basis
//! of the conversion note below + E0022 face-check group +
//! position-discipline group E0002/E0018/E0023)
//!
//! ③ non-orthogonal points ≤1 (all-nine-primitives-use structural anchor +
//! ModuleItem declaration-layer behavior anchor).
//!
//! **How to run**: from the workspace root, `cargo run --example stage3_gate_audit_e5close`.
//! Exit code 0 (APPROVED) when every case PASSes and the §7.3.1/§7.3.2
//! ratio mechanical check passes.
//!
//! **Structure** (§7.3.1 rule 2 mandatory ratios):
//! - Bucket A 12: single-statement negative (full E5-window diagnostic-code
//!   coverage: E0021 keyword old forms + old-builtin family representatives
//!   (the E6 reachable spellings) + E0022 face + E0020 reserved words +
//!   E0019 unknown imports + E0005 arity + empty forms)
//! - Bucket B 10: multi-statement / multi-function negative
//!   (position-discipline E0002/E0023 moved-up group + E0022 parallel
//!   semantics / unselected member / face-aware advice + E0024 selective
//!   imports + macro products with old keywords + HM multi-error collection)
//! - Bucket C 5: complex programs (unbound inside a module / deeply
//!   positioned module expressions / deep macro products / HM closure-chain
//!   types / unknown import after a module)
//! - Bucket D 5: recovery (merged reports + VM health after E0021 + rerun
//!   after E0022 + E0024 dual-path agreement + Span ordering)
//! - Bucket E 6: previous-round fix boundaries (r50-β frame positions /
//!   TD-030 / let* parallel semantics + r50-α D65 qualified names + r49-α
//!   do-splice macro + r48 de Bruijn deep capture)
//! - Bucket P 9: positive sanity + E2E full path + E5 exit three-condition
//!   evidence anchors (all-nine-primitives-use point / single-source count
//!   anchors / old-name negative-group coverage anchor)
//!
//! Total 47 cases: 27 negative + 5 recovery + 15 positive (negative ≥22).
//!
//! **§7.1.1 seven-class coverage** (E5-window contextual mapping):
//! ① syntax (E0002 position-discipline moved-up group / E0020 reserved-word
//! forms) ② unbound (E0021 old-name family / E0022 face check / E0024
//! selective-export boundary) ③ empty application (empty-list forms)
//! ④ arity (E0005 arity) ⑤ type mismatch (E0005 HM static surface)
//! ⑥ circular dependency (E0019 unknown import — the module resolution
//! surface) ⑦ macro depth (E0021 old keywords in macro expansion products —
//! the macro-system N4 intersection).
//!
//! **E6 conversion note** (r154 / 224-d5, s-expr-removal-plan §4 E6): the
//! whole case table and every probe moved to the target-syntax single face
//! (`run_source` / `run_source_seed` dual paths,
//! `check_source_recover` static + recovery face, `e5close.ktf`
//! filename — the S-expr entry family retired). Case count, bucket /
//! polarity / §7.1.1 class assignments unchanged (zero deletions — 47 =
//! 27 negative + 5 recovery + 15 positive). Carrier rulings, calibrated by
//! running both chains: (1) the E0021 keyword old forms — `lambda`/`begin`
//! are plain identifiers on the target face, so the call form reads as the
//! same Stx application head the post-r43 S-expr Reader produced (the
//! identical "`x` keyword switched" message), while `set!` is unspellable
//! (`!` outside the A-Za-z0-9_ charset) and the `?`/`->` old-builtin
//! families (int?/string->symbol/assert-eq?) are likewise unreachable →
//! those four anchors (A02/A05/A06/A07) ride the nearest same-Stage E0021
//! old-name carriers (cdr/list-ref/str-length/str-append — a snake_case
//! spelling maps to the kebab symbol at the Reader boundary, so the
//! diagnostics keep the kebab spellings; P09's 7-form group = A01-A07's
//! carriers: 2 keyword + 5 old-builtin reachable spellings); (2) the
//! S-expr quote-list datum `(quote (1 2))` has no target spelling (a paren
//! form inside quote parses as a parenthesized expression) → A04 rides the
//! pair-construction carrier `cons(1, 2)`; (3) the ③ empty-application
//! carrier = the zero-argument `quote()` application (the target `()` is
//! the unit literal — the Expand message recalibrated to the `quote form`
//! family; the d1-d4 siblings the same ruling); (4) the keyword-skin E0020
//! anchor (A09 `module if`) rides the shared non-skin reserved word `quote`
//! of the same 28-name N4 table (the m3/d4 same ruling — the module-name
//! binding position unchanged); (5) module-in-expression-position (B02 fn
//! body / C02 let binding) is lexically fronted to the Reader (`module` is
//! a declaration Token — a Read-stage rejection with the Reader's own
//! message; the Stx-layer E0023 walk stays the shared backstop for
//! macro-produced shapes — the m3 A10 require-position same ruling);
//! (6) the selective-import family (B03/B04/D04/E04/P06) rides the
//! `use kerf_x::{member};` form — the r131 eleventh skin mapping, consumed
//! by the unchanged driver face (E0024/E0022 keep the kebab module
//! spellings); (7) the parallel-binding let negative (B05) rides the
//! multi-binding `let x = 1, y = x;` (the D61 staging-chain parity carrier
//! — y's value expression does not see x); top-level lets ride the IIFE
//! `(|| { ... })()` carrier (E03/D03); (8) the value-position perform
//! (P02's handle body) wraps in the `fn ask()` carrier (the d2 ruling) and
//! `(resume k v)` → `resume(v)` (the k binder implicit in the target
//! resume form); (9) P08's `(assign x 14)` inside a do-argument position
//! rides the call-shaped `assign(x, 14)` (the `x = 14` statement form is
//! not an expression); (10) the all-nine-primitives anchor P02 keeps all
//! nine CoreExpr variants (fn/apply/if/var/literal/assign/let/perform/
//! handle) on the converted face; P03's pass-line stale "N1 38" display
//! aligned to the measured 40 (the r138 TD-002 basis — display-only).

use kerf_driver::builtins::{N1_CORE_NAMES, PRELUDE_EXPORT_NAMES, REMOVED_BUILTIN_NAMES};
use kerf_driver::{check_source_recover, compile_source, run_source, run_source_seed, Stage};

/// Oracle static decision surface (r80 semantic re-anchoring — a direct
/// hm_check_program call): reference-surface assertion for
/// conservative-false-negative boundary cases outside the krf-surface
/// [production] signature-table subset.
fn oracle_check_diags(src: &str) -> Vec<kerf_span::Diagnostic> {
    let out = compile_source(src, "audit-oracle.ktf").expect("pre-stage compile failed");
    let mut table = out.table;
    let sigs = kerf_driver::builtins::builtin_sigs(&mut table);
    kerf_compiler::hm::hm_check_program(&out.core, &sigs, &table).diags
}
use kerf_span::DiagnosticCode;
use kerf_vm::render_value;

/// Audit source file name (for diagnostic rendering location assertions).
const FNAME: &str = "e5close.ktf";

// ---------------------------------------------------------------------------
// Bucket / polarity / §7.1.1 error classes
// ---------------------------------------------------------------------------

#[derive(Clone, Copy, PartialEq, Eq)]
enum Bucket {
    Single,
    Multi,
    Complex,
    Recovery,
    Boundary,
    Positive,
}

impl Bucket {
    fn label(self) -> &'static str {
        match self {
            Bucket::Single => "A single-statement",
            Bucket::Multi => "B multi-statement",
            Bucket::Complex => "C complex",
            Bucket::Recovery => "D recovery",
            Bucket::Boundary => "E boundary",
            Bucket::Positive => "P positive",
        }
    }
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum Polarity {
    Negative,
    Positive,
    Recovery,
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum ErrorClass {
    Syntax,
    Unbound,
    EmptyForm,
    Arity,
    TypeMismatch,
    CircularDep,
    MacroDepth,
}

impl ErrorClass {
    fn index(self) -> usize {
        match self {
            ErrorClass::Syntax => 1,
            ErrorClass::Unbound => 2,
            ErrorClass::EmptyForm => 3,
            ErrorClass::Arity => 4,
            ErrorClass::TypeMismatch => 5,
            ErrorClass::CircularDep => 6,
            ErrorClass::MacroDepth => 7,
        }
    }
    fn label(self) -> &'static str {
        match self {
            ErrorClass::Syntax => "① syntax",
            ErrorClass::Unbound => "② unbound",
            ErrorClass::EmptyForm => "③ empty application",
            ErrorClass::Arity => "④ argument count",
            ErrorClass::TypeMismatch => "⑤ type mismatch",
            ErrorClass::CircularDep => "⑥ circular dependency",
            ErrorClass::MacroDepth => "⑦ macro depth",
        }
    }
}

// ---------------------------------------------------------------------------
// Expectations and results
// ---------------------------------------------------------------------------

enum Expect {
    /// Both paths Err (DriverError): stage + message substring + E code
    /// (the Compile-family extension range 13-24 is legal — the E5-window
    /// namespace / visibility / removal / selective-import families).
    Err {
        stage: Stage,
        msg: &'static str,
        code: Option<u32>,
    },
    /// Static decision surface (check_source Ok report with non-empty
    /// diagnostics — the E0005 HM static surface).
    StaticErr { msg: &'static str, min_diags: usize },
    /// Oracle static decision surface (r80 semantic re-anchoring):
    /// conservative-false-negative boundary cases outside the krf-surface
    /// signature-table subset — the Rust oracle is called directly to assert
    /// detection capability (reference-surface anchor).
    OracleStaticErr { msg: &'static str, min_diags: usize },
    /// Both paths Ok with an identical value (exact rendered-value match —
    /// execution-level proof of the parity chain).
    OkDual(&'static str),
    /// Custom probe (recovery / fix boundary / count anchors / exit-condition evidence anchors).
    Custom(fn() -> CaseResult),
}

struct Case {
    id: &'static str,
    bucket: Bucket,
    polarity: Polarity,
    class: Option<ErrorClass>,
    src: &'static str,
    expect: Expect,
}

struct CaseResult {
    pass: bool,
    detail: String,
}

fn pass(detail: String) -> CaseResult {
    CaseResult { pass: true, detail }
}

fn fail(detail: String) -> CaseResult {
    CaseResult {
        pass: false,
        detail,
    }
}

fn short_src(src: &str) -> String {
    let one = src.replace('\n', " ⏎ ");
    if one.len() > 88 {
        // E6: the ⏎ replacement is multi-byte — truncate at the last char
        // boundary ≤ 84 (the byte-index slice panicked on the longer
        // converted srcs; ASCII-only srcs keep the identical output)
        let cut = one
            .char_indices()
            .map(|(i, _)| i)
            .take_while(|&i| i <= 84)
            .last()
            .unwrap_or(0);
        format!("{}…", &one[..cut])
    } else {
        one
    }
}

fn first_line(s: &str) -> String {
    s.lines().next().unwrap_or("").to_string()
}

// ---------------------------------------------------------------------------
// Case table (47 cases — A12/B10/C5/D5/E6/P9)
// ---------------------------------------------------------------------------

const CASES: &[Case] = &[
    // ---- Bucket A: single-statement negative (full E5-window diagnostic-code coverage, 12) ----
    Case {
        id: "A01",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        // E6: `lambda` is a plain identifier on the target face — the call
        // form reads as the same Stx application head the post-r43 S-expr
        // Reader produced (the nested-list arg (x) flattens to x; E0021
        // rides the application-head Var)
        src: "lambda(x, x)",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "`lambda` keyword switched -- modern form `fn`",
            code: Some(21),
        },
    },
    Case {
        id: "A02",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        // E6: `set!` is unspellable on the target face (`!` outside the
        // A-Za-z0-9_ identifier charset) → the nearest same-Stage E0021
        // carrier = the accessor-family old name `cdr` (the S2
        // keyword-switch face itself is carried by the spellable A01/A03
        // pair)
        src: "cdr(cons(1, 2))",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "`cdr` already at v0.9 removed -- modern name `tail`",
            code: Some(21),
        },
    },
    Case {
        id: "A03",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        src: "begin(1, 2)",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "`begin` keyword switched -- modern form `do`",
            code: Some(21),
        },
    },
    Case {
        id: "A04",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        // E6: the S-expr quote-list datum `(quote (1 2))` has no target
        // spelling (a paren form inside quote parses as a parenthesized
        // expression) → the pair-construction carrier
        src: "car(cons(1, 2))",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "`car` already at v0.9 removed -- modern name `head`",
            code: Some(21),
        },
    },
    Case {
        id: "A05",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        // E6: the `?`-suffixed predicate family (int?) is unspellable → the
        // list-family old name `list_ref` (the snake spelling maps to the
        // kebab `list-ref` symbol at the Reader boundary — the diagnostic
        // keeps the kebab spelling)
        src: "list_ref(list(1, 2), 0)",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "`list-ref` already at v0.9 removed -- modern name `nth`",
            code: Some(21),
        },
    },
    Case {
        id: "A06",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        // E6: the `->` conversion family (string->symbol) is unspellable →
        // the string-family old name `str_length`
        src: "str_length(\"ab\")",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "`str-length` already at v0.9 removed -- modern name `string-length`",
            code: Some(21),
        },
    },
    Case {
        id: "A07",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        // E6: the `?`-suffixed assertion family (assert-eq?) is unspellable
        // → the string-family old name `str_append`
        src: "str_append(\"a\", \"b\")",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "`str-append` already at v0.9 removed -- modern name `string-append`",
            code: Some(21),
        },
    },
    Case {
        id: "A08",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        src: "foo(1)",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "unbound reference: `foo`",
            code: Some(22),
        },
    },
    Case {
        id: "A09",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Syntax),
        // E6: `if` is a Reader-reserved Token in the module-name slot →
        // the compile-stage E0020 anchor rides the shared non-skin
        // reserved word `quote` of the same 28-name N4 table (the m3/d4
        // same ruling — the binding position unchanged)
        src: "module quote { export a; let a = 1; }",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "reserved word is not bindable",
            code: Some(20),
        },
    },
    Case {
        id: "A10",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::CircularDep),
        src: "import kerf_nonexist;",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "unknown imported module `kerf-nonexist`",
            code: Some(19),
        },
    },
    Case {
        id: "A11",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Arity),
        src: "fn f(x: i64) -> i64 { x }\nf(1, 2)",
        expect: Expect::StaticErr {
            msg: "argument count mismatch",
            min_diags: 1,
        },
    },
    Case {
        id: "A12",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::EmptyForm),
        // E6: the ③ empty-application carrier = the zero-argument `quote()`
        // application (the target `()` is the unit literal — the Expand
        // message recalibrated to the `quote form` family; the d1-d4
        // siblings the same ruling)
        src: "quote()",
        expect: Expect::Err {
            stage: Stage::Expand,
            msg: "quote form",
            code: None,
        },
    },
    // ---- Bucket B: multi-statement / multi-function negative (position
    // discipline + face + selective imports, 10) ----
    Case {
        id: "B01",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Syntax),
        // r158 / 228-c: the expression-position define leg rides a fn
        // body (the top-level item position is Reader-rejected now — the
        // retirement diagnostic; the block-position operand shape keeps
        // the expander's position-discipline face)
        src: "let a = 1;\nfn f() { define(x, 1) + 2 }\nf()",
        expect: Expect::Err {
            stage: Stage::Expand,
            msg: "define is only allowed at the top level or at the head of a function body",
            code: None,
        },
    },
    Case {
        id: "B02",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Syntax),
        // E6: `module` is a declaration Token — the fn-body occurrence is
        // lexically fronted to the Reader (a strictly earlier fail-closed
        // face; the Stx-layer E0023 walk stays the shared backstop for
        // macro-produced shapes — the m3 A10 require-position same ruling)
        src: "fn g(y: i64) -> i64 { module m { 1 } }",
        expect: Expect::Err {
            stage: Stage::Read,
            msg: "expected an expression, got KwModule",
            code: None,
        },
    },
    Case {
        id: "B03",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        // E6 skin: the selective import rides the `use` form (the r131
        // eleventh skin mapping) — the flat `string_length` name stays
        // unselected, so the E0022 message keeps the kebab spelling
        src: "use kerf_string::{append};\nstring_length(\"a\")",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "unbound reference: `string-length`",
            code: Some(22),
        },
    },
    Case {
        id: "B04",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        src: "use kerf_list::{nonexist};\nlet b = 1;",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "selective import member `nonexist` not in module `kerf-list` export face",
            code: Some(24),
        },
    },
    Case {
        id: "B05",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        // E6: the parallel-binding let negative rides the multi-binding
        // `let x = 1, y = x;` (the D61 staging-chain parity carrier — y's
        // value expression does not see x); top-level let → the IIFE
        // carrier
        src: "(|| { let x = 1, y = x; y })()",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "unbound reference: `x`",
            code: Some(22),
        },
    },
    Case {
        id: "B06",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::MacroDepth),
        // E6 skin: the macro rides the `macro NAME (lits) { (pat) => tpl }`
        // form; the template `lambda(x, x)` reads as the same application
        // the S-expr template `(lambda (x) x)` produced
        src: "macro m() { () => lambda(x, x) }\nm()",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "`lambda` keyword switched",
            code: Some(21),
        },
    },
    Case {
        id: "B07",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        src: "1 + \"a\"\nif (2) { 1 } else { 3 }",
        expect: Expect::StaticErr {
            msg: "requires a number",
            min_diags: 2,
        },
    },
    Case {
        id: "B08",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Syntax),
        // E6: the Reader wraps the multi-statement fn body in a do — the
        // body-head define rides the do-wrapping position defense (the
        // stage2-r1 B03/B04 same ruling; the r49-α boundary unchanged)
        src: "fn f(x: i64) -> i64 { define(y, 2); x }\nf(1)",
        expect: Expect::Err {
            stage: Stage::Expand,
            msg: "define is only allowed at the top level or at the head of a function body",
            code: None,
        },
    },
    Case {
        id: "B09",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        src: "fn f(x: i64) -> i64 { y }\nf(1)",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "unbound reference: `y`",
            code: Some(22),
        },
    },
    Case {
        id: "B10",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        // E6 skin: the closure carrier `|| (x: T) { x }` — the bare
        // prelude name stays unbound, and the E0022 advice keeps the
        // single-source suggestion text (the `?`-free map spelling is
        // skin-transparent)
        src: "map(|| (x: T) { x }, list(1, 2))",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "not imported -- (import kerf-prelude) available after",
            code: Some(22),
        },
    },
    // ---- Bucket C: complex-program negative (5) ----
    Case {
        id: "C01",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        src: "module m { export a; let a = foo(1); }",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "unbound reference: `foo`",
            code: Some(22),
        },
    },
    Case {
        id: "C02",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Syntax),
        // E6: the let-binding-position module is likewise fronted to the
        // Reader (B02's same ruling — the deep-position anchor preserved)
        src: "fn f(x: i64) -> i64 { let q = module m { 1 }; q }\nf(1)",
        expect: Expect::Err {
            stage: Stage::Read,
            msg: "expected an expression, got KwModule",
            code: None,
        },
    },
    Case {
        id: "C03",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::MacroDepth),
        // E6 skin: the two-stage macro chain rides the target macro form;
        // the twice product re-expands f()'s old-keyword application
        src: "macro twice() { (e) => do(e, e) }\nmacro f() { () => lambda(x, x) }\ntwice(f())",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "`lambda` keyword switched",
            code: Some(21),
        },
    },
    Case {
        id: "C04",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        src: "import kerf_string;\nfn g(x: i64) -> Fn(i64) -> i64 { || (y: i64) { x + y } }\nstring_length(g(1)(2))",
        expect: Expect::OracleStaticErr {
            msg: "type mismatch",
            min_diags: 1,
        },
    },
    Case {
        id: "C05",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::CircularDep),
        src: "module m { export a; let a = 1; }\nimport kerf_nonexist;",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "unknown imported module `kerf-nonexist`",
            code: Some(19),
        },
    },
    // ---- Bucket D: recovery (5) ----
    Case {
        id: "D01",
        bucket: Bucket::Recovery,
        polarity: Polarity::Recovery,
        class: Some(ErrorClass::EmptyForm),
        // (E6 skin: the ③ empty-form leg rides the zero-argument quote()
        // carrier — see probe_recover_merged)
        src: "1 + \"a\"\nquote();\nif (2) { 1 } else { 3 }",
        expect: Expect::Custom(probe_recover_merged),
    },
    Case {
        id: "D02",
        bucket: Bucket::Recovery,
        polarity: Polarity::Recovery,
        class: None,
        src: "lambda(x, x)",
        expect: Expect::Custom(probe_e0021_then_vm_healthy),
    },
    Case {
        id: "D03",
        bucket: Bucket::Recovery,
        polarity: Polarity::Recovery,
        class: Some(ErrorClass::Unbound),
        src: "foo(1)",
        expect: Expect::Custom(probe_e0022_then_rerun_ok),
    },
    Case {
        id: "D04",
        bucket: Bucket::Recovery,
        polarity: Polarity::Recovery,
        class: Some(ErrorClass::Unbound),
        src: "use kerf_list::{nonexist};",
        expect: Expect::Custom(probe_e0024_dual_path_consistent),
    },
    Case {
        id: "D05",
        bucket: Bucket::Recovery,
        polarity: Polarity::Recovery,
        class: Some(ErrorClass::TypeMismatch),
        src: "1 + \"a\"\nhead(5)\nif (2) { 1 } else { 3 }",
        expect: Expect::Custom(probe_multi_diag_span_order),
    },
    // ---- Bucket E: previous-round fix boundaries (r48-r50β, 6 ≥5) ----
    Case {
        id: "E01",
        bucket: Bucket::Boundary,
        polarity: Polarity::Positive,
        class: None,
        src: "fn f(a: i64) -> Fn(i64) -> i64 { let x = 1, y = 2; || (b: i64) { a + x + y + b } }\nf(10)(1)",
        expect: Expect::OkDual("14"),
    },
    Case {
        id: "E02",
        bucket: Bucket::Boundary,
        polarity: Polarity::Positive,
        class: None,
        src: "import kerf_prelude;\nfor_each(|| (x: T) { x }, list(1, 2, 3))",
        expect: Expect::Custom(probe_td030_check_prelude_clean),
    },
    Case {
        id: "E03",
        bucket: Bucket::Boundary,
        polarity: Polarity::Positive,
        class: None,
        // E6: let* sequential semantics = the native target let statement;
        // top-level let → the IIFE carrier
        src: "(|| { let x = 1; let y = x; x + y })()",
        expect: Expect::OkDual("2"),
    },
    Case {
        id: "E04",
        bucket: Bucket::Boundary,
        polarity: Polarity::Positive,
        class: None,
        src: "use kerf_string::{append};\nstring::length(\"ab\")",
        expect: Expect::OkDual("2"),
    },
    Case {
        id: "E05",
        bucket: Bucket::Boundary,
        polarity: Polarity::Positive,
        class: None,
        // E6 skin: the macro rides the target macro form; the product's
        // do-splice into ModuleItem::Define is the declaration-layer
        // behavior anchor (unchanged consumer)
        src: "macro def_twice() { (n, v) => do(define(n, v), define(n2, v)) }\ndef_twice(x, 7);\nx + x",
        expect: Expect::OkDual("14"),
    },
    Case {
        id: "E06",
        bucket: Bucket::Boundary,
        polarity: Polarity::Positive,
        class: None,
        src: "fn f(x: i64) -> Fn(i64) -> Fn(i64) -> i64 { || (y: i64) { || (z: i64) { x + (y + z) } } }\nf(1)(2)(3)",
        expect: Expect::OkDual("6"),
    },
    // ---- Bucket P: positive sanity + E2E + E5 exit evidence anchors (9) ----
    Case {
        id: "P01",
        bucket: Bucket::Positive,
        polarity: Polarity::Positive,
        class: None,
        src: "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(15)",
        expect: Expect::OkDual("610"),
    },
    Case {
        id: "P02",
        bucket: Bucket::Positive,
        polarity: Polarity::Positive,
        class: None,
        // E6 skin: the value-position perform wraps in the `fn ask()`
        // carrier (the d2 ruling) and `(resume k (+ p 40))` →
        // `resume(p + 40)` (the k binder implicit in the target resume
        // form); all nine CoreExpr primitives stay in use (the ③ anchor)
        src: "fn prog() {\n    let x = 1;\n    x = x + 1;\n    if (x == 2) {\n        handle ask() { tag(p, k) => resume(p + 40) }\n    } else {\n        0\n    }\n}\nfn ask() { perform tag(1); }\nprog()",
        expect: Expect::OkDual("41"),
    },
    Case {
        id: "P03",
        bucket: Bucket::Positive,
        polarity: Polarity::Positive,
        class: None,
        src: "-",
        expect: Expect::Custom(probe_e5_exit3_structure_counts),
    },
    Case {
        id: "P04",
        bucket: Bucket::Positive,
        polarity: Polarity::Positive,
        class: None,
        src: "do(1 + 2, cons(1, ()), is_int(1), head(list(3, 4)))",
        expect: Expect::OkDual("3"),
    },
    Case {
        id: "P05",
        bucket: Bucket::Positive,
        polarity: Polarity::Positive,
        class: None,
        src: "import kerf_prelude;\nmap(|| (x: T) { x * x }, list(1, 2, 3))",
        expect: Expect::OkDual("(1 4 9)"),
    },
    Case {
        id: "P06",
        bucket: Bucket::Positive,
        polarity: Polarity::Positive,
        class: None,
        src: "use kerf_string::{append, length};\nstring_length(string_append(\"a\", \"b\"))",
        expect: Expect::OkDual("2"),
    },
    Case {
        id: "P07",
        bucket: Bucket::Positive,
        polarity: Polarity::Positive,
        class: None,
        // E6 skin: the value-position perform in the handle-protected
        // expression wraps in the `fn ask()` carrier (the d2 ruling)
        src: "fn ask() { perform add(5); }\nhandle (1 + ask()) { add(p, k) => resume(p + 10) }",
        expect: Expect::OkDual("16"),
    },
    Case {
        id: "P08",
        bucket: Bucket::Positive,
        polarity: Polarity::Positive,
        class: None,
        // E6: `(set! x 14)` inside the do-argument position rides the
        // call-shaped `assign(x, 14)` (the `x = 14` statement form is not
        // an expression — the do-splice item carrier is unchanged)
        src: "do(define(x, 7), assign(x, 14), x)",
        expect: Expect::OkDual("14"),
    },
    Case {
        id: "P09",
        bucket: Bucket::Positive,
        polarity: Polarity::Positive,
        class: Some(ErrorClass::Unbound),
        src: "-",
        expect: Expect::Custom(probe_e5_exit2_oldname_group),
    },
];

// ---------------------------------------------------------------------------
// Executors
// ---------------------------------------------------------------------------

fn run_case(c: &Case) -> CaseResult {
    match &c.expect {
        Expect::Err { stage, msg, code } => run_negative(c, *stage, msg, *code),
        Expect::StaticErr { msg, min_diags } => run_static(c, msg, *min_diags),
        Expect::OracleStaticErr { msg, min_diags } => run_oracle_static(c, msg, *min_diags),
        Expect::OkDual(s) => run_positive_dual(c, s),
        Expect::Custom(f) => f(),
    }
}

fn run_negative(c: &Case, stage: Stage, msg: &str, code: Option<u32>) -> CaseResult {
    let err = match run_source(c.src, FNAME) {
        Err(e) => e,
        Ok(_) => {
            return fail(format!(
                "expected {:?} stage Err, VM path returns Ok",
                stage
            ));
        }
    };
    if err.stage != stage {
        return fail(format!(
            "VM stage mismatch: expected {:?} actual {:?}({})",
            stage,
            err.stage,
            first_line(&err.rendered)
        ));
    }
    if !err.rendered.contains(msg) {
        return fail(format!(
            "VM message does not contain `{}`: {}",
            msg,
            first_line(&err.rendered)
        ));
    }
    let want_code = DiagnosticCode(code.unwrap_or_else(|| stage_e_code(stage)));
    // Legal mapping of E5-window family codes: Compile family E0013-E0024
    // (namespace / visibility / removal / selective imports); Expand family
    // E0002 (position discipline moved up — the r49 shapes).
    let code_ok = err.diagnostic.code == Some(want_code)
        || (stage == Stage::Compile && matches!(err.diagnostic.code.map(|k| k.0), Some(13..=24)));
    if !code_ok {
        return fail(format!(
            "E code mismatch: expected E{:04} actual {:?}",
            want_code.0,
            err.diagnostic.code.map(|k| k.0)
        ));
    }
    if err.diagnostic.primary_span.is_empty() {
        return fail("primary Span empty (diagnostic location missing)".to_string());
    }
    if !err.rendered.contains(FNAME) {
        return fail(format!(
            "render output missing file name {}(position excerpt missing)",
            FNAME
        ));
    }
    match run_source_seed(c.src, FNAME) {
        Ok(_) => fail("expected Err, seed chain returns Ok(dual-path split)".to_string()),
        Err(e2) => {
            if e2.stage != stage {
                fail(format!(
                    "seed chain stage mismatch: expected {:?} actual {:?}",
                    stage, e2.stage
                ))
            } else if !e2.rendered.contains(msg) {
                fail(format!(
                    "seed chain message does not contain `{}`: {}",
                    msg,
                    first_line(&e2.rendered)
                ))
            } else {
                pass(format!(
                    "dual-path same Err {} `{}`",
                    first_line(&err.rendered),
                    msg
                ))
            }
        }
    }
}

// Static decision surface (the E0005 HM static surface — the check report diagnostics surface).

/// Oracle static decision surface negative (r80): a direct hm_check_program
/// call → E0005 diagnostics (message substring + minimum diagnostic count;
/// reference-surface anchor).
fn run_oracle_static(c: &Case, msg: &str, min_diags: usize) -> CaseResult {
    let diags = oracle_check_diags(c.src);
    if diags.len() < min_diags {
        return fail(format!(
            "oracle diagnostic count {} < minimal {}(reference face detects capability regression)",
            diags.len(),
            min_diags
        ));
    }
    let hits: Vec<_> = diags
        .iter()
        .filter(|d| d.message.contains(msg) && d.code == Some(DiagnosticCode(5)))
        .collect();
    if hits.is_empty() {
        let msgs: Vec<&str> = diags.iter().map(|d| d.message.as_str()).collect();
        return fail(format!(
            "oracle E0005 diagnostic does not contain `{}`; actual {:?}",
            msg, msgs
        ));
    }
    pass("oracle static face hit (reference anchor outside signature-table subset)".to_string())
}
fn run_static(c: &Case, msg: &str, min_diags: usize) -> CaseResult {
    let report = match check_source_recover(c.src, FNAME) {
        Ok(r) => r,
        Err(e) => {
            return fail(format!(
                "static face should return a diagnostic report (Ok), actual compile-time Err: {}",
                first_line(&e.rendered)
            ));
        }
    };
    if report.diagnostics.len() < min_diags {
        return fail(format!(
            "diagnostic count {} < minimal {}(multiple-error collection broken)",
            report.diagnostics.len(),
            min_diags
        ));
    }
    let hits: Vec<_> = report
        .diagnostics
        .iter()
        .filter(|d| d.message.contains(msg) && d.code == Some(DiagnosticCode(5)))
        .collect();
    if hits.is_empty() {
        let msgs: Vec<&str> = report
            .diagnostics
            .iter()
            .map(|d| d.message.as_str())
            .collect();
        return fail(format!(
            "E0005 diagnostic does not contain `{}`; actual {:?}",
            msg, msgs
        ));
    }
    for d in &hits {
        if d.primary_span.is_empty() {
            return fail("E0005 primary Span empty (location missing)".to_string());
        }
    }
    pass(format!(
        "static face {} clauses diagnostic hit `{}`(HM static state collection healthy)",
        report.diagnostics.len(),
        msg
    ))
}

fn run_positive_dual(c: &Case, want: &str) -> CaseResult {
    let a = match run_source(c.src, FNAME) {
        Ok(o) => o,
        Err(e) => return fail(format!("production chain Err: {}", first_line(&e.rendered))),
    };
    let b = match run_source_seed(c.src, FNAME) {
        Ok(o) => o,
        Err(e) => return fail(format!("seed chain Err: {}", first_line(&e.rendered))),
    };
    let ra = render_value(&a.value, &a.heap);
    let rb = render_value(&b.value, &b.heap);
    if ra != want || rb != want {
        return fail(format!(
            "value mismatch: expected {}, production {} / seed {}",
            want, ra, rb
        ));
    }
    if !a.value.eq_value(&b.value) {
        return fail(format!(
            "dual-path value mismatch: production {} vs seed {}",
            ra, rb
        ));
    }
    pass(format!(
        "dual-path same value ⇒ {}(parity chain anchor)",
        ra
    ))
}

fn stage_e_code(stage: Stage) -> u32 {
    match stage {
        Stage::Read => 1,
        Stage::Expand => 2,
        Stage::Compile => 3,
        Stage::Run => 4,
    }
}

// ---------------------------------------------------------------------------
// Bucket D recovery probes
// ---------------------------------------------------------------------------

/// D01: recovery merged report (E0002 empty form + E0005 static surface —
/// position-independent collection + partial artifacts continue through
/// the pipeline; the Compile family E0021/E0022 is fail-closed blocking and
/// does not enter the collection surface, so the recovery collection surface
/// = Expand errors + HM static diagnostics — the existing M2 stance).
/// (E6 skin: the ③ empty-form leg rides the zero-argument quote() carrier —
/// the message recalibrated to the `quote form` family; the d1-d4
/// siblings' same ruling)
fn probe_recover_merged() -> CaseResult {
    let src = "1 + \"a\"\nquote();\nif (2) { 1 } else { 3 }";
    let report = match check_source_recover(src, FNAME) {
        Ok(r) => r,
        Err(e) => {
            return fail(format!(
                "recovery path should produce a report:{}",
                first_line(&e.rendered)
            ));
        }
    };
    if report.diagnostics.len() < 2 {
        return fail(format!(
            "expected at least 2 clauses diagnostic(E0002 + E0005), got {} clauses",
            report.diagnostics.len()
        ));
    }
    let has_e2 = report
        .diagnostics
        .iter()
        .any(|d| d.code == Some(DiagnosticCode(2)) && d.message.contains("quote form"));
    let has_e5 = report
        .diagnostics
        .iter()
        .any(|d| d.code == Some(DiagnosticCode(5)));
    if !has_e2 || !has_e5 {
        let codes: Vec<u32> = report
            .diagnostics
            .iter()
            .filter_map(|d| d.code.map(|k| k.0))
            .collect();
        return fail(format!(
            "merged report lacks E0002/E0005; actual code {:?}",
            codes
        ));
    }
    pass(format!(
        "recovery merge {} clauses (E0002 quote form + E0005 static face)",
        report.diagnostics.len()
    ))
}

/// D02: VM state stays healthy after an E0021 error (fib runs correctly
/// in-process afterwards — the old-name rejection leaves no residual state).
/// (E6 skin: the E0021 carrier = `lambda(x, x)` — the call form of the
/// retired keyword; fib rides the fn-declaration form)
fn probe_e0021_then_vm_healthy() -> CaseResult {
    let r = run_source("lambda(x, x)", FNAME);
    if r.is_ok() {
        return fail("expected E0021 Err".to_string());
    }
    let fib =
        "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(12)";
    match run_source(fib, "fib.ktf") {
        Ok(o) => {
            let v = render_value(&o.value, &o.heap);
            if v == "144" {
                pass("E0021 later same-process fib(12) ⇒ 144(VM state healthy)".to_string())
            } else {
                fail(format!("continue-run value abnormal: {}", v))
            }
        }
        Err(e) => fail(format!("continue-run Err: {}", first_line(&e.rendered))),
    }
}

/// D03: in-process rerun after an E0022 face error (multi-binding let
/// direct-mapping path with zero residue).
/// (E6 skin: the let rerun rides the multi-binding `let x = 1, y = 2;`
/// inside the IIFE carrier — the D61 parity staging chain)
fn probe_e0022_then_rerun_ok() -> CaseResult {
    let r = run_source("foo(1)", FNAME);
    if r.is_ok() {
        return fail("expected E0022 Err".to_string());
    }
    match run_source("(|| { let x = 1, y = 2; x + y })()", "rerun.ktf") {
        Ok(o) => {
            let v = render_value(&o.value, &o.heap);
            if v == "3" {
                pass("E0022 later same-process multiple binding let ⇒ 3(r50-β path zero residual remaining)".to_string())
            } else {
                fail(format!("continue-run value abnormal: {}", v))
            }
        }
        Err(e) => fail(format!("continue-run Err: {}", first_line(&e.rendered))),
    }
}

/// D04: E0024 dual-path error agreement (selective import fail-closed with
/// the same stage and message on the seed/production chains — the r50-α D65
/// contract).
fn probe_e0024_dual_path_consistent() -> CaseResult {
    let src = "use kerf_list::{nonexist};";
    let a = run_source(src, FNAME);
    let b = run_source_seed(src, FNAME);
    match (a, b) {
        (Err(e1), Err(e2)) => {
            if e1.stage != Stage::Compile || e2.stage != Stage::Compile {
                return fail(format!(
                    "E0024 stage partition split: production {:?} / seed {:?}",
                    e1.stage, e2.stage
                ));
            }
            if !e1.rendered.contains("E0024") || !e2.rendered.contains("E0024") {
                return fail("E0024 code position dual-path mismatch".to_string());
            }
            if !e1.rendered.contains("nonexist") || !e2.rendered.contains("nonexist") {
                return fail("E0024 member name dual-path mismatch".to_string());
            }
            pass(
                "E0024 dual-path same Err same code same message(D65 fail-closed consistent)"
                    .to_string(),
            )
        }
        (Ok(_), _) | (_, Ok(_)) => {
            fail("E0024 dual-path of one return Ok(partition split)".to_string())
        }
    }
}

/// D05: multi-error collection Span ordering (three E0005 diagnostics
/// monotonic by primary_span — the existing D7 contract maintained after
/// the E5 window).
fn probe_multi_diag_span_order() -> CaseResult {
    let src = "1 + \"a\"\nhead(5)\nif (2) { 1 } else { 3 }";
    let report = match check_source_recover(src, FNAME) {
        Ok(r) => r,
        Err(e) => {
            return fail(format!(
                "recovery path should produce a report:{}",
                first_line(&e.rendered)
            ));
        }
    };
    if report.diagnostics.len() < 3 {
        return fail(format!(
            "expected ≥3 clauses E0005, got {} clauses",
            report.diagnostics.len()
        ));
    }
    let starts: Vec<u32> = report
        .diagnostics
        .iter()
        .map(|d| d.primary_span.start)
        .collect();
    let mut sorted = starts.clone();
    sorted.sort_unstable();
    if starts != sorted {
        return fail(format!(
            "Span order non-single call: {:?} vs sorting {:?}",
            starts, sorted
        ));
    }
    pass(format!(
        "{} clauses diagnostic Span single call(multiple-error collection sorting healthy)",
        report.diagnostics.len()
    ))
}

// ---------------------------------------------------------------------------
// Bucket E fix-boundary probes
// ---------------------------------------------------------------------------

/// E02: the r50-β TD-030 fix boundary — the check+prelude combination
/// with zero E0005 false positives (the original false positive: the hm Let
/// arm solved each binding early with solve_now; after D6 ② was retired,
/// the discard arm gives zero false positives — the tech-debt-register
/// TD-030 acceptance item).
fn probe_td030_check_prelude_clean() -> CaseResult {
    let src = "import kerf_prelude;\nfor_each(|| (x: T) { x }, list(1, 2, 3))";
    let report = match check_source_recover(src, FNAME) {
        Ok(r) => r,
        Err(e) => {
            return fail(format!(
                "check+prelude should Ok: {}",
                first_line(&e.rendered)
            ));
        }
    };
    let e5_hits: Vec<_> = report
        .diagnostics
        .iter()
        .filter(|d| d.code == Some(DiagnosticCode(5)))
        .collect();
    if !e5_hits.is_empty() {
        let msgs: Vec<&str> = e5_hits.iter().map(|d| d.message.as_str()).collect();
        return fail(format!("TD-030 re-emit(E0005 false positive): {:?}", msgs));
    }
    pass("check+prelude zero E0005 false positive(TD-030 clearing maintained)".to_string())
}

// ---------------------------------------------------------------------------
// Bucket P E5 exit evidence-anchor probes
// ---------------------------------------------------------------------------

/// P03: the E5 exit ③ structural count anchor — the N1 core surface 38
/// names / the prelude export surface 20 names / the old-name retirement
/// table 27 pairs (the r42 frozen stance maintained) + the keyword old forms
/// 3 pairs (r43).
/// The structural counter-side of non-orthogonal points ≤1: CoreExpr 9
/// variants (fn/apply/if/var/literal/assign/let/perform/handle) +
/// ModuleItem 4 kinds — carried by P02's all-nine-primitives-use point and
/// E05's do-splice behavior anchor (this probe holds the single-source
/// counts).
fn probe_e5_exit3_structure_counts() -> CaseResult {
    // r138 TD-002: +vector/is-vector -> 40 (was 38 at r126 basis);
    // r159 / 229-c: +% (term-level infix primary face) -> 41
    if N1_CORE_NAMES.len() != 41 {
        return fail(format!(
            "N1 core face count drift: {} != 41",
            N1_CORE_NAMES.len()
        ));
    }
    if PRELUDE_EXPORT_NAMES.len() != 20 {
        return fail(format!(
            "prelude export face count drift: {} != 20",
            PRELUDE_EXPORT_NAMES.len()
        ));
    }
    if REMOVED_BUILTIN_NAMES.len() != 27 {
        return fail(format!(
            "old name retired table count drift: {} != 27(r42 frozen basis)",
            REMOVED_BUILTIN_NAMES.len()
        ));
    }
    // 27-pair two-way health sampling: old names ∉ the N1 core surface
    // (removal thorough — zero residual registration)
    for &(old, modern) in REMOVED_BUILTIN_NAMES.iter() {
        if N1_CORE_NAMES.contains(&old) {
            return fail(format!("old name `{}` residual N1 core face", old));
        }
        if !N1_CORE_NAMES.contains(&modern) {
            // Modern names are allowed ∈ the module flat surface (the string
            // family etc.) — only old-name zero residue is checked
            let _ = modern;
        }
    }
    // (E6 alignment: the pass-line's stale "N1 38" display aligned to
    // the measured 40 — the r138 TD-002 basis, display-only;
    // r159 / 229-c: measured 41 with `%`)
    pass("N1 41 / prelude 20 / old name retired 27 for(old name zero residual N1) -- E5 exit③ single source count anchor".to_string())
}

/// P09: the E5 exit ② evidence anchor — old-name/keyword removal
/// negative-group coverage counts and message shapes: the E6 reachable
/// spelling group = 2 keyword old forms (lambda/begin — `set!` is
/// unspellable on the target charset) + old-builtin family representatives
/// (accessor car/cdr · list list-ref · string str-length/str-append — the
/// `?`/`->` families likewise unreachable; snake_case spellings map to the
/// kebab symbols at the Reader boundary), each E0021 with the message
/// carrying modern-name guidance (the executable final check of the
/// S1/S2/D63 removal waves on the target surface).
fn probe_e5_exit2_oldname_group() -> CaseResult {
    let group: &[(&str, &str)] = &[
        ("lambda(x, x)", "fn"),
        ("cdr(cons(1, 2))", "tail"),
        ("begin(1, 2)", "do"),
        ("car(cons(1, 2))", "head"),
        ("list_ref(list(1, 2), 0)", "nth"),
        ("str_length(\"ab\")", "string-length"),
        ("str_append(\"a\", \"b\")", "string-append"),
    ];
    let mut hit = 0;
    for (src, modern) in group {
        match run_source(src, FNAME) {
            Ok(_) => {
                return fail(format!(
                    "old form `{}` not by rejected(E0021 negative case group missing port)",
                    src
                ));
            }
            Err(e) => {
                if e.stage != Stage::Compile {
                    return fail(format!("old form `{}` stage abnormal: {:?}", src, e.stage));
                }
                if !e.rendered.contains("E0021") {
                    return fail(format!(
                        "old form `{}` non- E0021: {}",
                        src,
                        first_line(&e.rendered)
                    ));
                }
                if !e.rendered.contains(modern) {
                    return fail(format!(
                        "old form `{}` message missing modern name refers to quote `{}`: {}",
                        src,
                        modern,
                        first_line(&e.rendered)
                    ));
                }
                hit += 1;
            }
        }
    }
    pass(format!(
        "old name negative case group {} form all E0021 carry modern name refers to quote(2 keyword + old builtin family reachable spelling table)",
        hit
    ))
}

// ---------------------------------------------------------------------------
// Main program
// ---------------------------------------------------------------------------

fn main() {
    println!(
        "== Stage 3 E5 window close-out gate audit(S4) -- {} case ==",
        CASES.len()
    );
    println!(
        "case total {}(A single-statement 12 / B multi-statement 10 / C complex 5 / D recovery 5 / E fix boundary 6 / P positive 9)\n",
        CASES.len()
    );

    let mut fail_count = 0;
    let mut class_seen = [0usize; 7];
    let mut bucket_counts = [0usize; 6];
    let (mut negative, mut positive, mut recovery) = (0usize, 0usize, 0usize);

    for c in CASES {
        bucket_counts[c.bucket as usize] += 1;
        match c.polarity {
            Polarity::Negative => negative += 1,
            Polarity::Positive => positive += 1,
            Polarity::Recovery => recovery += 1,
        }
        if let Some(cls) = c.class {
            class_seen[cls.index() - 1] += 1;
        }
        let r = run_case(c);
        let status = if r.pass { "PASS" } else { "FAIL" };
        let class_label = c.class.map(|k| k.label()).unwrap_or("-");
        println!(
            "[{}] {} {} {} {}",
            status,
            c.id,
            c.bucket.label(),
            match c.polarity {
                Polarity::Negative => "negative",
                Polarity::Positive => "positive",
                Polarity::Recovery => "recovery",
            },
            class_label
        );
        if c.src != "-" {
            println!("      src: {}", short_src(c.src));
        }
        println!("      → {}", r.detail);
        if !r.pass {
            fail_count += 1;
        }
    }

    // Summary + §7.3.1/§7.3.2 ratio mechanical check
    let total = CASES.len();
    let passed = total - fail_count;
    println!("\n== summary ==");
    println!("total {} / PASS {} / FAIL {}", total, passed, fail_count);
    println!(
        "polarity distribution: negative {} / recovery {} / positive {}",
        negative, recovery, positive
    );
    println!(
        "bucket ratio(§7.3.1): single-statement {}/10 multi-statement {}/10 complex {}/5 recovery {}/5 boundary {}/5; positive {}/9",
        bucket_counts[0],
        bucket_counts[1],
        bucket_counts[2],
        bucket_counts[3],
        bucket_counts[4],
        bucket_counts[5]
    );
    let mut ratio_fail = false;
    if bucket_counts[0] < 10 {
        println!("ratio violation: A bucket {} < 10", bucket_counts[0]);
        ratio_fail = true;
    }
    if bucket_counts[1] < 10 {
        println!("ratio violation: B bucket {} < 10", bucket_counts[1]);
        ratio_fail = true;
    }
    if bucket_counts[2] < 5 {
        println!("ratio violation: C bucket {} < 5", bucket_counts[2]);
        ratio_fail = true;
    }
    if bucket_counts[3] < 5 {
        println!("ratio violation: D bucket {} < 5", bucket_counts[3]);
        ratio_fail = true;
    }
    if bucket_counts[4] < 5 {
        println!(
            "ratio violation (§7.3.2): E fix boundary bucket {} < 5",
            bucket_counts[4]
        );
        ratio_fail = true;
    }
    if negative < 22 {
        println!("ratio violation: negative {} < 22", negative);
        ratio_fail = true;
    }
    for (i, n) in class_seen.iter().enumerate() {
        if *n == 0 {
            println!("ratio violation:§7.1.1 # {} class zero coverage", i + 1);
            ratio_fail = true;
        }
    }
    if total < 30 {
        println!("ratio violation (§7.3): total case {} < 30", total);
        ratio_fail = true;
    }

    if fail_count > 0 || ratio_fail {
        println!(
            "\n conclusion: NEEDS REVISION(FAIL {} / ratio violation {})",
            fail_count, ratio_fail
        );
        std::process::exit(1);
    }
    println!(
        "\n conclusion: APPROVED(E5 window close-out gate audit pass -- 47 case + all seven classes covered + ratio satisfied + r48-r50β fix boundary 6 + exit three condition verify per anchor)"
    );

    // E5 exit three-condition reconciliation (23 §2.2 — the S4 close-out final verification)
    println!();
    println!(
        "== E5 exit three condition reconciliation(23 §2.2 -- S4 close-out final verification)=="
    );
    println!(
        "① migration after parity chain all green: A01-C05 dual-path same Err(run_negative seed chain verify)+ E01/E03-E06/P01-P08 OkDual(production/seed same value eq_value) -- structure re-construct zero semantics drift move"
    );
    println!(
        "② old name/keyword removed negative case group: A01-A07(E6 reachable spelling: keyword lambda/begin 2 form + old builtin family 5 name -- set!/int?/string->symbol/assert-eq? charset unreachable, see conversion note)+ P09(7 form E0021 carry modern name refers to quote total verify)+ B06/C03(macro artifact old form) -- coverage count anchor P03(27 for frozen basis)"
    );
    println!(
        "③ non-positive interleave dot ≤1(21 §5.5): P02 nine primitive all use dot(CoreExpr 9 change body structure anchor -- fn/apply/if/var/literal/assign/let/perform/handle)+ E05 do-splice macro produce define(ModuleItem declaration layer behavior anchor)+ B01/B02/B08 position discipline(Define/Module above move after compile-time cannot representation) -- SetBang receive control maintained 1 is final state"
    );
    println!();
    println!("== gate audit conclusion ==");
    println!(
        "E5 window nine leg(S1 r42 → S2 r43 → S3-M-R r44 → structure r45 → visibility r46-r47 → IndexIR r48 → declaration layer r49-α → predicate/selective import r50-α → let direct mapping r50-β)close-out: 47 case all PASS + all seven classes covered + fix boundary ≥5"
    );
    println!(
        "E5 exit three condition all green reach become -- S4 close-out GO(v1.0.0 release then state)"
    );
}

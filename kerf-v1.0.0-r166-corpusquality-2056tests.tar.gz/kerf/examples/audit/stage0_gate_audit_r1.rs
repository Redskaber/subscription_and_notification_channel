//! Stage 0 negative gate audit suite (sop.md §7.3.1 rule 3 / §7.1.1 seven-class matrix).
//!
//! **Purpose**: ≥30-case negative audit — the mandatory audit suite of stage gate
//! review (§7.3). This file is round 1 (r1), the fix round corresponding to the
//! Stage 0 deep review deep-review-round1 (NEEDS REVISION), used for the Gate R2
//! re-run; §7.3.1 rule 4 requires later rounds to be ≥ this round's scale.
//!
//! **How to run**: from the workspace root, `cargo run --example stage0_gate_audit_r1`.
//! Exit code 0 when every case PASSes (including XFAIL: findings asserted against
//! "current actual behavior" and printed with WARN); exit code 1 if any case FAILs
//! or a §7.3.1 mandatory ratio is unmet.
//! The internal argument `--cyclic-dep-probe` exists only so the ⑥ circular-dependency
//! subprocess probe can reuse this binary.
//!
//! **Structure** (§7.3.1 rule 2 mandatory ratios, mechanically checked in main()):
//! - Bucket A 12: single-statement negative (basic type system)
//! - Bucket B 12: multi-statement / multi-function negative (integration correctness)
//! - Bucket C 8: complex-program negative (nested control flow / closures /
//!   recursion / macros + ⑥ circular dependency + dual-path split finding)
//! - Bucket D 6: error recovery (in-process continued run of a correct program
//!   after an error / Lexer·Parser still working)
//! - Bucket P 3: positive sanity (auditor self-check)
//!
//! Total 41 cases: 32 negative + 6 recovery + 3 positive (negative ≥22, positive ≤8).
//!
//! **§7.1.1 seven-class coverage**: ① syntax ② unbound ③ empty application
//! ④ arity ⑤ type mismatch ⑥ module circular dependency (fixed: phase.rs DFS
//! grey marking → structured Err; the probe's CYCLE-DETECTED path activated)
//! ⑦ macro expansion depth exceeded.
//!
//! **Historical findings** (audit-suite-driven fixes — all fixed, cases auto-upgraded to strict PASS):
//! - C07: ⑥ circular dependency had no detection → stack-overflow crash
//!   (fixed: DFS grey marking);
//! - C03: runtime stack trace unimplemented (fixed: run_program wraps a
//!   frame-chain snapshot, innermost 16 frames rendered as note call sites);
//! - C08: eval path lacked hygiene fallback resolution (fixed: the driver eval
//!   side mirrors resolution, dual paths agree on Ok 42).
//!
//! E6 close-out (r154 / 224-b1): converted to the target-syntax single face
//! (the S-expr entry family retired — s-expr-removal-plan §4 E6). All inline
//! programs and entry APIs moved to the target face (`run_source` /
//! `run_source_seed` dual paths, `.ktf` filenames); case count and
//! bucket/polarity/class structure unchanged. Skins: ③ empty application is
//! carried by the zero-argument `quote()` application (the target face's `()`
//! is the unit literal — the S-expr empty-list face is unreachable); B10's
//! quoted-list datum becomes the `list(...)` runtime construction (no
//! quoted-list literal on the target face — the corpus-registered boundary).

use std::process::Command;

use kerf_driver::{dump_stx, dump_tokens, run_source, run_source_seed, Stage};
use kerf_expander::phase::ModuleRegistry;
use kerf_span::DiagnosticCode;
use kerf_syntax::SymbolTable;
use kerf_vm::{render_value, Value};

/// Audit source file name (for diagnostic rendering location assertions).
const FNAME: &str = "audit.ktf";
/// Circular-dependency subprocess probe argument (dispatched in main).
const PROBE_ARG: &str = "--cyclic-dep-probe";

// ---------------------------------------------------------------------------
// Bucket / polarity / §7.1.1 error classes
// ---------------------------------------------------------------------------

/// The four mandatory buckets of §7.3.1 rule 2 + positive sanity.
#[derive(Clone, Copy, PartialEq, Eq)]
enum Bucket {
    Single,
    Multi,
    Complex,
    Recovery,
    Positive,
}

impl Bucket {
    fn label(self) -> &'static str {
        match self {
            Bucket::Single => "A: single-statement",
            Bucket::Multi => "B: multi-statement",
            Bucket::Complex => "C: complex program",
            Bucket::Recovery => "D: error recovery",
            Bucket::Positive => "P: positive",
        }
    }
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum Polarity {
    Negative,
    Mixed,
    Positive,
}

/// The seven classes of the §7.1.1 minimal negative-test coverage matrix (index 1..=7).
#[derive(Clone, Copy, PartialEq, Eq)]
enum ErrorClass {
    Syntax,
    Unbound,
    EmptyApp,
    Arity,
    TypeMismatch,
    CircularDep,
    MacroDepth,
}

impl ErrorClass {
    fn label(self) -> &'static str {
        match self {
            ErrorClass::Syntax => "① syntax error",
            ErrorClass::Unbound => "② unbound identifier",
            ErrorClass::EmptyApp => "③ empty application",
            ErrorClass::Arity => "④ argument count error",
            ErrorClass::TypeMismatch => "⑤ type mismatch",
            ErrorClass::CircularDep => "⑥ module circular dependency",
            ErrorClass::MacroDepth => "⑦ macro expansion depth exceeds the limit",
        }
    }

    fn index(self) -> usize {
        match self {
            ErrorClass::Syntax => 1,
            ErrorClass::Unbound => 2,
            ErrorClass::EmptyApp => 3,
            ErrorClass::Arity => 4,
            ErrorClass::TypeMismatch => 5,
            ErrorClass::CircularDep => 6,
            ErrorClass::MacroDepth => 7,
        }
    }
}

// ---------------------------------------------------------------------------
// Case table and expectations
// ---------------------------------------------------------------------------

enum Expect {
    /// Both paths Err: stage + message substring + E code + non-empty Span (+ optional stack trace).
    Err {
        stage: Stage,
        msg: &'static str,
        trace: bool,
    },
    /// Both paths Ok with an identical value (Int).
    OkInt(i64),
    /// VM path Ok with an exact rendered-value match.
    OkRendered(&'static str),
    /// Custom probe (error recovery / circular-dependency subprocess).
    Custom(fn() -> CaseResult),
}

struct Case {
    id: &'static str,
    bucket: Bucket,
    polarity: Polarity,
    class: Option<ErrorClass>,
    src: &'static str,
    expect: Expect,
}

const FIB10: &str =
    "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(10)";

const COUNTERS: &str = r#"
        fn make_counter() {
            let n = 0;
            || { n = n + 1; n }
        }
        let a = make_counter();
        let b = make_counter();
        a(); a(); a();
        b();
        list(a(), b())
    "#;

const CASES: &[Case] = &[
    // ---- Bucket A: single-statement negative (basic type system) ----
    Case {
        id: "A01",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Syntax),
        src: "define(x, \"unterminated);",
        expect: Expect::Err {
            stage: Stage::Read,
            msg: "unclosed string",
            trace: false,
        },
    },
    Case {
        id: "A02",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        src: "1 + \"s\"",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "+ requires int",
            trace: false,
        },
    },
    Case {
        id: "A03",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        src: "head(5)",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "head requires pair, got int",
            trace: false,
        },
    },
    Case {
        id: "A04",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        src: "1(2)",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "uncallable value: int",
            trace: false,
        },
    },
    Case {
        id: "A05",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        src: "undefined_x",
        expect: Expect::Err {
            // r46 / D49: E0022 moved up to compile time (Run E0004 → Compile E0022)
            stage: Stage::Compile,
            msg: "unbound",
            trace: false,
        },
    },
    Case {
        id: "A06",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        src: "y = 1;",
        expect: Expect::Err {
            // r46 / D49: E0022 moved up to compile time (message updated with the carrier)
            stage: Stage::Compile,
            msg: "unbound reference",
            trace: false,
        },
    },
    Case {
        id: "A07",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        src: "1 / 0",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "integer division by zero",
            trace: false,
        },
    },
    Case {
        id: "A08",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        src: "tail(())",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "tail requires pair, got nil",
            trace: false,
        },
    },
    Case {
        id: "A09",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::EmptyApp),
        // E6 conversion: the S-expr `()` empty-list face is unreachable on the
        // target face (target `()` = unit literal); the ③ carrier is the
        // zero-argument application of the quote form — same Expand/E0002 family.
        src: "quote()",
        expect: Expect::Err {
            stage: Stage::Expand,
            msg: "quote form",
            trace: false,
        },
    },
    Case {
        id: "A10",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Arity),
        src: "(|| (x: i64) { x })(1, 2)",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "procedure argument count mismatch: expected 1, got 2",
            trace: false,
        },
    },
    Case {
        id: "A11",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        src: "if (1) { 2 } else { 3 }",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "requires bool",
            trace: false,
        },
    },
    Case {
        id: "A12",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        src: "import kerf_string;\nstring_append(1, 2)",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "string-append requires 2 strings",
            trace: false,
        },
    },
    // ---- Bucket B: multi-statement / multi-function negative (integration correctness) ----
    Case {
        id: "B01",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Arity),
        src: "fn g(a: i64, b: i64) -> T { cons(a, b) }\ng(1)",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "procedure argument count mismatch: expected 2, got 1",
            trace: false,
        },
    },
    Case {
        id: "B02",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Arity),
        src: "fn f(x: i64) -> i64 { x }\nf()",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "procedure argument count mismatch: expected 1, got 0",
            trace: false,
        },
    },
    Case {
        id: "B03",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        src: "fn f(x: T) { x + 1 }\nf(\"s\")",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "+ requires int",
            trace: false,
        },
    },
    Case {
        id: "B04",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        src: "fn make_adder(n: T) { || (x: T) { x + n } }\nmake_adder(\"s\")(1)",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "+ requires int",
            trace: false,
        },
    },
    Case {
        id: "B05",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        src: "let x = 1;\ny = x;",
        expect: Expect::Err {
            // r46 / D49: E0022 moved up to compile time (message updated with the carrier)
            stage: Stage::Compile,
            msg: "unbound reference",
            trace: false,
        },
    },
    Case {
        id: "B06",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        // E6 duplicate definition (§7.1.1 extra negative — regression anchor for the Task 12 fix)
        class: None,
        src: "let x = 1;\nlet x = 2;",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "duplicate variable definition",
            trace: false,
        },
    },
    Case {
        id: "B07",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        src: "let n = \"s\";\nn + 1",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "+ requires int",
            trace: false,
        },
    },
    Case {
        id: "B08",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        // Expansion-time A3 hygiene check (§7.1.1 extra negative)
        class: None,
        src: "fn f(x: T, x: T) { x }",
        expect: Expect::Err {
            stage: Stage::Expand,
            msg: "fn duplicate argument names",
            trace: false,
        },
    },
    Case {
        id: "B09",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Arity),
        src: "fn apply2(f: T) { f(1, 2) }\napply2(head)",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "head requires 1 arguments, got 2",
            trace: false,
        },
    },
    Case {
        id: "B10",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        // E6 conversion: quoted-list datum → the `list(...)` runtime construction
        // (no quoted-list literal on the target face — corpus-registered boundary)
        src: "let lst = list(1, 2);\nhead(tail(tail(lst)))",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "head requires pair, got nil",
            trace: false,
        },
    },
    Case {
        id: "B11",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        src: "import kerf_string;\nfn join(a: T, b: T) { string_append(a, b) }\njoin(1, 2)",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "string-append requires 2 strings",
            trace: false,
        },
    },
    Case {
        id: "B12",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        // Cross-form dependency: an unbound identifier inside a function body,
        // triggered by a call.
        // Finding (recorded as-is): the eval-path error is "evaluation failed:
        // unbound variable" and its Span points at the call site rather than
        // the identifier (VM path precise / eval path call site) — a dual-path
        // diagnostic fidelity gap; see the finding list in worklog Task 16-a.
        class: Some(ErrorClass::Unbound),
        src: "fn f() { x }\nf()",
        expect: Expect::Err {
            // r46 / D49: E0022 moved up to compile time
            stage: Stage::Compile,
            msg: "unbound",
            trace: false,
        },
    },
    // ---- Bucket C: complex-program negative (nested control flow / closures /
    // recursion / macros / circular dependency) ----
    Case {
        id: "C01",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::MacroDepth),
        src: "macro loop { () => loop() }\nloop()",
        expect: Expect::Err {
            stage: Stage::Expand,
            msg: "macro expansion depth exceeds the limit",
            trace: false,
        },
    },
    Case {
        id: "C02",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::MacroDepth),
        src: "macro m { (x) => m((x)) }\nm(1)",
        expect: Expect::Err {
            stage: Stage::Expand,
            msg: "macro expansion depth exceeds the limit",
            trace: false,
        },
    },
    Case {
        id: "C03",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        // Finding (XFAIL): runtime errors carry no call-chain stack trace (children always empty).
        src: "fn deep(n: i64) { if (n == 0) { head(5) } else { deep(n - 1) } }\ndeep(3)",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "head requires pair, got int",
            trace: true,
        },
    },
    Case {
        id: "C04",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        src: "fn count(n: i64) { if (n == 0) { \"done\" } else { count(n - 1) } }\ncount(100) + 1",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "+ requires int",
            trace: false,
        },
    },
    Case {
        id: "C05",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        src: "fn classify(n: i64) { if (mod(n, 2) == 0) { if (n > 10) { if (n > 100) { head(n) } else { \"big\" } } else { 1 } } else { 2 } }\nclassify(200)",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "head requires pair",
            trace: false,
        },
    },
    Case {
        id: "C06",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        // Runtime type error inside a macro expansion product (expansion-generation Span)
        src: "macro twice { (e) => { e; e; } }\ntwice(head(5))",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "head requires pair",
            trace: false,
        },
    },
    Case {
        id: "C07",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::CircularDep),
        // ⑥ module circular dependency: construct A imports B / B imports A
        // via the ModuleRegistry public API; the subprocess probe triggers
        // visit (to avoid a crash killing the audit process).
        src: "<ModuleRegistry: cycle-a imports cycle-b; cycle-b imports cycle-a; visit(cycle-a)>",
        expect: Expect::Custom(probe_circular_module_dep),
    },
    Case {
        id: "C08",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        // Finding (XFAIL): macro expansion product references a global (hygiene
        // fallback) — the VM path falls back to Ok(42), the eval path has no
        // fallback → Err unbound (dual-path split).
        // Class assignment: not ⑤ type mismatch — assigned to ② unbound
        // identifier (the eval-side error class).
        class: Some(ErrorClass::Unbound),
        src: "<macro inc expand assign (+ v 1) quote use global +: VM hygiene fallback / eval no fallback>",
        expect: Expect::Custom(probe_macro_global_dual_path),
    },
    // ---- Bucket D: error recovery (in-process sequences) ----
    Case {
        id: "D01",
        bucket: Bucket::Recovery,
        polarity: Polarity::Mixed,
        class: None,
        src: "<first (head 5) after fib(10)>",
        expect: Expect::Custom(probe_error_then_correct),
    },
    Case {
        id: "D02",
        bucket: Bucket::Recovery,
        polarity: Polarity::Mixed,
        class: None,
        src: "<first (/ 1 0) dual-path after (+ 40 2) dual-path>",
        expect: Expect::Custom(probe_dual_path_error_then_ok),
    },
    Case {
        id: "D03",
        bucket: Bucket::Recovery,
        polarity: Polarity::Mixed,
        class: None,
        src: "<after three-stage error dump_tokens / dump_stx>",
        expect: Expect::Custom(probe_reader_after_errors),
    },
    Case {
        id: "D04",
        bucket: Bucket::Recovery,
        polarity: Polarity::Mixed,
        class: None,
        src: "<5 after error burst fib(10)>",
        expect: Expect::Custom(probe_error_barrage_then_correct),
    },
    Case {
        id: "D05",
        bucket: Bucket::Recovery,
        polarity: Polarity::Mixed,
        class: None,
        src: "<error after heap allocation, re-run closure counter>",
        expect: Expect::Custom(probe_heap_intact_after_error),
    },
    Case {
        id: "D06",
        bucket: Bucket::Recovery,
        polarity: Polarity::Mixed,
        class: None,
        src: "<two after error#three error diagnostic structure complete property>",
        expect: Expect::Custom(probe_diagnostics_structure_after_errors),
    },
    // ---- Bucket P: positive sanity (auditor self-check) ----
    Case {
        id: "P1",
        bucket: Bucket::Positive,
        polarity: Polarity::Positive,
        class: None,
        src: FIB10,
        expect: Expect::OkInt(55),
    },
    Case {
        id: "P2",
        bucket: Bucket::Positive,
        polarity: Polarity::Positive,
        class: None,
        src: COUNTERS,
        expect: Expect::OkRendered("(4 2)"),
    },
    Case {
        id: "P3",
        bucket: Bucket::Positive,
        polarity: Polarity::Positive,
        class: None,
        src: "(|| (x: i64, y: i64) { x - y })(10, 4)",
        expect: Expect::OkInt(6),
    },
];

// ---------------------------------------------------------------------------
// Result types and the table-driven executor
// ---------------------------------------------------------------------------

struct CaseResult {
    /// Asserts that the current behavior holds (XFAIL items also count as
    /// pass — asserted against real behavior).
    pass: bool,
    /// Current behavior = defective behavior (flagged with WARN; expected
    /// behavior is in the warn text).
    xfail: bool,
    detail: String,
    warn: Option<String>,
}

fn pass(detail: String) -> CaseResult {
    CaseResult {
        pass: true,
        xfail: false,
        detail,
        warn: None,
    }
}

fn fail(detail: String) -> CaseResult {
    CaseResult {
        pass: false,
        xfail: false,
        detail,
        warn: None,
    }
}

fn xfail(detail: String, warn: String) -> CaseResult {
    CaseResult {
        pass: true,
        xfail: true,
        detail,
        warn: Some(warn),
    }
}

fn first_line(s: &str) -> &str {
    s.lines().next().unwrap_or("")
}

fn stage_e_code(stage: Stage) -> u32 {
    match stage {
        Stage::Read => 1,
        Stage::Expand => 2,
        Stage::Compile => 3,
        Stage::Run => 4,
    }
}

/// r46 / 22 §15 D49: stage-code mapping correction (the Compile stage is not
/// injective — code 3 = compiler-internal-error family [E0003]; **code 22 =
/// compile-time unbound-verification family** [same Compile verification-family
/// measurement stance as E0006/E0014 — stage to code family is many-to-one]).
/// Keyword-based message discrimination (the unbound family moved up to
/// compile time).
fn expect_code(stage: Stage, msg: &str) -> u32 {
    match stage {
        Stage::Compile if msg.contains("unbound") => 22,
        _ => stage_e_code(stage),
    }
}

/// Negative-case executor: VM path (stage/message/E code/Span/file
/// name/trace) + eval dual path (same Err rather than a hang, same message
/// substring).
fn run_negative(c: &Case, stage: Stage, msg: &str, want_trace: bool) -> CaseResult {
    let err = match run_source(c.src, FNAME) {
        Err(e) => e,
        Ok(_) => {
            return fail(format!(
                "expected {:?} stage Err, VM path returns Ok",
                stage
            ))
        }
    };
    if err.stage != stage {
        return fail(format!(
            "VM stage mismatch: expected {:?} actual {:?}",
            stage, err.stage
        ));
    }
    if !err.rendered.contains(msg) {
        return fail(format!(
            "VM message does not contain `{}`: {}",
            msg,
            first_line(&err.rendered)
        ));
    }
    let want_code = DiagnosticCode(expect_code(stage, msg));
    if err.diagnostic.code != Some(want_code) {
        return fail(format!(
            "E code mismatch: expected E{:04} actual {:?}",
            want_code.0,
            err.diagnostic.code.map(|k| k.0)
        ));
    }
    if err.diagnostic.primary_span.is_empty() {
        return fail("primary Span empty (diagnostic location missing)".to_string());
    }
    if !err.rendered.contains(FNAME) {
        return fail(format!(
            "render output missing file name {}(position excerpt missing)",
            FNAME
        ));
    }
    // Seed-chain dual path (T1 new measurement stance 42-d: eval retired — the
    // seed chain is the differential-testing oracle): same Err (rather than a
    // hang/silent success) and an identical message substring
    match run_source_seed(c.src, FNAME) {
        Ok(_) => return fail("expected Err, seed chain returns Ok(dual-path split)".to_string()),
        Err(e2) => {
            if !e2.rendered.contains(msg) {
                return fail(format!(
                    "seed chain message does not contain `{}`: {}",
                    msg,
                    first_line(&e2.rendered)
                ));
            }
        }
    }
    let span = err.diagnostic.primary_span;
    let base = format!(
        "{} | E{:04} | span {}..{}",
        first_line(&err.rendered),
        want_code.0,
        span.start,
        span.end
    );
    if want_trace {
        if err.diagnostic.children.is_empty() {
            return xfail(
                format!("{} | dual-path Err | no heap stack tracing(children empty)", base),
                "current behavior: runtime error does not contain call-chain tracing(VmError.trace in vm.rs only initialized empty, no producers; worklog Task 4-c declare name `VM heap stack tracing` differs from reality, vm_tests.runtime_error_has_trace actually only asserts message text); expected behavior: error diagnostic carry carry call site children(§8.12 heap stack tracing bear promise) -- TODO after fixing this case auto-upgrades to PASS".to_string(),
            );
        }
        return pass(format!("{} | trace✓ | dual-path Err", base));
    }
    pass(format!("{} | dual-path Err", base))
}

/// Positive-case executor (OkInt): dual paths agree on the value (production
/// chain vs seed chain — T1 new measurement stance 42-d: eval retired, the
/// seed chain replaces the oracle).
fn run_positive_int(c: &Case, n: i64) -> CaseResult {
    let (o, o2) = match (run_source(c.src, FNAME), run_source_seed(c.src, FNAME)) {
        (Ok(a), Ok(b)) => (a, b),
        (Err(e), _) | (_, Err(e)) => {
            return fail(format!(
                "positive program unexpected failed:{}",
                first_line(&e.rendered)
            ))
        }
    };
    match (&o.value, &o2.value) {
        (Value::Int(a), Value::Int(b)) if *a == n && *b == n => {
            pass(format!("production⇒{} seed⇒{}(dual-path consistent)", a, b))
        }
        _ => fail(format!(
            "value mismatch: expected {}, production⇒{} seed⇒{}",
            n,
            render_value(&o.value, &o.heap),
            render_value(&o2.value, &o2.heap)
        )),
    }
}

/// Positive-case executor (OkRendered).
fn run_positive_rendered(c: &Case, expected: &str) -> CaseResult {
    match run_source(c.src, FNAME) {
        Ok(o) => {
            let s = render_value(&o.value, &o.heap);
            if s.trim() == expected {
                pass(format!("VM⇒{}", s.trim()))
            } else {
                fail(format!(
                    "render value mismatch: expected `{}` actual `{}`",
                    expected,
                    s.trim()
                ))
            }
        }
        Err(e) => fail(format!(
            "positive program unexpected failed:{}",
            first_line(&e.rendered)
        )),
    }
}

fn run_case(c: &Case) -> CaseResult {
    match &c.expect {
        Expect::Err { stage, msg, trace } => run_negative(c, *stage, msg, *trace),
        Expect::OkInt(n) => run_positive_int(c, *n),
        Expect::OkRendered(s) => run_positive_rendered(c, s),
        Expect::Custom(f) => f(),
    }
}

// ---------------------------------------------------------------------------
// ⑥ circular-dependency probe (C07) — direct construction via the ModuleRegistry public API
// ---------------------------------------------------------------------------

/// Subprocess mode: construct A imports B / B imports A and visit(A).
/// If cycle detection exists, prints CYCLE-DETECTED; passing silently prints
/// CYCLE-SILENT-PASS; current actual behavior: infinite recursion →
/// stack-overflow crash (non-zero exit).
fn cyclic_probe_child() {
    let mut table = SymbolTable::new();
    let a = table.intern("cycle-a");
    let b = table.intern("cycle-b");
    let mut reg = ModuleRegistry::new();
    let _ = reg.declare(a, vec![b], vec![]);
    let _ = reg.declare(b, vec![a], vec![]);
    match reg.visit(a) {
        Ok(()) => println!("CYCLE-SILENT-PASS"),
        Err(m) => println!("CYCLE-DETECTED: {}", m),
    }
}

fn probe_circular_module_dep() -> CaseResult {
    let exe = std::env::current_exe().expect("failed to get the current executable path");
    let out = Command::new(&exe)
        .arg(PROBE_ARG)
        .output()
        .expect("circular dependency subprocess probe failed to start");
    let stdout = String::from_utf8_lossy(&out.stdout).trim().to_string();
    let stderr = String::from_utf8_lossy(&out.stderr);
    if out.status.success() {
        if stdout.contains("CYCLE-DETECTED") {
            pass(format!("visit return structure ize error: {}", stdout))
        } else {
            xfail(
                "visit(A↔B) silently returns Ok".to_string(),
                "current behavior: circular dependency silently passes(no check test); expected behavior: structure ize Err `circular dependency` diagnostic(§7.1.1⑥)".to_string(),
            )
        }
    } else {
        let overflowed = stderr.contains("overflowed its stack");
        let hint = if overflowed {
            "(stack overflow crash)"
        } else {
            "(abnormal exit)"
        };
        xfail(
            format!("subprocess probe abnormal exit{}: {}", hint, first_line(&stderr)),
            "current behavior: ModuleRegistry::visit for A imports B / B imports A no cycle detection,".to_string()
                + "no restriction recursion stack overflow crash(kerf-expander/src/phase.rs visit import recursion,"
                + "comments claim `ring in this explicitly fails` and actual line is mismatch);"
                + "expected behavior: declare/visit side structure ize Err `circular dependency` diagnostic(§7.1.1⑥) --"
                + "TODO after fixing this case auto-upgrades to PASS",
        )
    }
}

// ---------------------------------------------------------------------------
// ⑧ dual-path split probe (C08) — macro global reference agreed on both paths (T1 new stance 42-d)
// ---------------------------------------------------------------------------

/// C08: macro expansion product references the global +: the production
/// chain (self-hosted three stages + VM) goes through
/// resolve_hygiene_fallbacks and gets Ok(42); the seed chain (Rust three
/// stages + VM, the differential-testing oracle after 42-d retired eval) is
/// wired the same way ⇒ dual paths agree on 42.
fn probe_macro_global_dual_path() -> CaseResult {
    let src = "macro inc { (v) => { v = v + 1; } }\nlet x = 41;\ninc(x);\nx";
    // Production chain (self-hosted three stages + VM — hygiene fallback in effect, positive anchor)
    match run_source(src, FNAME) {
        Ok(o) if matches!(o.value, Value::Int(42)) => {}
        Ok(o) => {
            return fail(format!(
                "production chain value mismatch: {}",
                render_value(&o.value, &o.heap)
            ))
        }
        Err(e) => {
            return fail(format!(
                "production chain unexpected failed:{}",
                first_line(&e.rendered)
            ))
        }
    }
    // Seed chain (Rust three stages + VM — reference oracle; the original eval
    // path split was fixed at the driver layer, and the differential-testing
    // surface is preserved after the 42-d stance migration)
    match run_source_seed(src, FNAME) {
        Err(e) if e.rendered.contains("unbound") => xfail(
            "production⇒42 / seed⇒Err[unbound variable](dual-path split)".to_string(),
            "current behavior: seed chain macro expansion artifact in global reference +$hyg$N unbound report an error(seed chain hygiene fallback not wired); expected behavior: dual paths agree Ok 42(§21.8 dual-path mutual check / T1 new basis -- 42-d eval retired after comparison face) -- TODO after fixing this case auto-upgrades to PASS".to_string(),
        ),
        Ok(o) if matches!(o.value, Value::Int(42)) => {
            pass("production⇒42 seed⇒42(dual-path consistent)".to_string())
        }
        Ok(o) => fail(format!(
            "seed chain Ok but value non- 42: {}",
            render_value(&o.value, &o.heap)
        )),
        Err(e) => fail(format!(
            "seed chain Err but non-unbound class: {}",
            first_line(&e.rendered)
        )),
    }
}

// ---------------------------------------------------------------------------
// Bucket D error-recovery probes
// ---------------------------------------------------------------------------

/// D01: error program → a correct program run afterwards in-process yields the correct result.
fn probe_error_then_correct() -> CaseResult {
    let err = match run_source("head(5)", FNAME) {
        Err(e) => e,
        Ok(_) => return fail("error program (head 5) unexpected succeeded".to_string()),
    };
    if !err.rendered.contains("head requires pair") {
        return fail(format!("message mismatch: {}", first_line(&err.rendered)));
    }
    match run_source(FIB10, FNAME) {
        Ok(o) if matches!(o.value, Value::Int(55)) => {
            pass("Err[head requires pair] → subsequent fib(10)⇒55".to_string())
        }
        Ok(o) => fail(format!(
            "after recovery value mismatch: {}",
            render_value(&o.value, &o.heap)
        )),
        Err(e) => fail(format!(
            "continue-run after error positive certain program failed(state leak): {}",
            first_line(&e.rendered)
        )),
    }
}

/// D02: division by zero is Err on both the production and seed paths, then
/// both paths run a correct program afterwards (T1 new stance 42-d — eval
/// retired, seed-chain differential testing).
fn probe_dual_path_error_then_ok() -> CaseResult {
    match (run_source("1 / 0", FNAME), run_source_seed("1 / 0", FNAME)) {
        (Err(e1), Err(e2))
            if e1.rendered.contains("integer division by zero")
                && e2.rendered.contains("integer division by zero") => {}
        (Ok(_), _) | (_, Ok(_)) => {
            return fail("(/ 1 0): expected dual-path Err, a path returns Ok".to_string())
        }
        (Err(e1), Err(e2)) => {
            return fail(format!(
                "(/ 1 0): message mismatch: production `{}` seed `{}`",
                first_line(&e1.rendered),
                first_line(&e2.rendered)
            ))
        }
    }
    match (
        run_source("40 + 2", FNAME),
        run_source_seed("40 + 2", FNAME),
    ) {
        (Ok(a), Ok(b))
            if matches!(a.value, Value::Int(42)) && matches!(b.value, Value::Int(42)) =>
        {
            pass("(/ 1 0) dual-path Err → (+ 40 2) dual-path⇒42".to_string())
        }
        _ => fail(
            "after error dual-path continue-run positive certain program failed(state leak)"
                .to_string(),
        ),
    }
}

/// D03: after multi-stage errors, the Lexer/Parser still works on subsequent
/// input (dump_tokens/dump_stx).
fn probe_reader_after_errors() -> CaseResult {
    // One error per stage across three stages: Read / Expand / Run
    for (src, msg) in [
        ("1 +", "expected an expression"),
        ("quote()", "quote form"),
        ("head(5)", "head requires pair"),
    ] {
        match run_source(src, FNAME) {
            Err(e) if e.rendered.contains(msg) => {}
            Err(e) => {
                return fail(format!(
                    "{}: message mismatch: {}",
                    src,
                    first_line(&e.rendered)
                ))
            }
            Ok(_) => return fail(format!("{}: expected Err", src)),
        }
    }
    let toks = match dump_tokens("1 + 2", FNAME) {
        Ok(s) => s,
        Err(e) => {
            return fail(format!(
                "after error dump_tokens failed:{}",
                first_line(&e.rendered)
            ))
        }
    };
    for want in ["int:1", "+", "int:2"] {
        if !toks.contains(want) {
            return fail(format!("dump_tokens missing Token `{}`", want));
        }
    }
    let stx = match dump_stx("quote(a)", FNAME) {
        Ok(s) => s,
        Err(e) => {
            return fail(format!(
                "after error dump_stx failed:{}",
                first_line(&e.rendered)
            ))
        }
    };
    if !stx.contains("(quote a)") {
        return fail(format!("dump_stx output mismatch:{}", stx.trim()));
    }
    pass("after three-stage error tokens/stx dump all normal".to_string())
}

/// D04: 5 errors in a row (across all three stages), then a correct program
/// still yields 55 (one error does not pollute what follows).
fn probe_error_barrage_then_correct() -> CaseResult {
    let barrage = [
        ("1 + \"s\"", Stage::Run, "+ requires int"),
        ("quote()", Stage::Expand, "quote form"),
        ("1 +", Stage::Read, "expected an expression"),
        ("head(5)", Stage::Run, "head requires pair"),
        ("zz = 1;", Stage::Compile, "unbound reference"), // r46/D49: E0022 moved up
    ];
    for (src, want_stage, msg) in barrage {
        match run_source(src, FNAME) {
            Err(e) if e.stage == want_stage && e.rendered.contains(msg) => {}
            Err(e) => {
                return fail(format!(
                    "{}: stage/message mismatch(expected {:?}/{}): {}",
                    src,
                    want_stage,
                    msg,
                    first_line(&e.rendered)
                ))
            }
            Ok(_) => return fail(format!("{}: expected Err", src)),
        }
    }
    match run_source(FIB10, FNAME) {
        Ok(o) if matches!(o.value, Value::Int(55)) => {
            pass("5 burst errors(with three stages)after fib(10)⇒55".to_string())
        }
        Ok(o) => fail(format!(
            "after recovery value mismatch: {}",
            render_value(&o.value, &o.heap)
        )),
        Err(e) => fail(format!(
            "5 continue-run after error positive certain program failed:{}",
            first_line(&e.rendered)
        )),
    }
}

/// D05: error triggered after heap allocation → an in-process closure counter
/// (shared mutable capture + pair allocation + slot_count>0) yields exactly
/// the correct result (the error does not corrupt subsequent heap behavior).
fn probe_heap_intact_after_error() -> CaseResult {
    match run_source("let p = cons(1, cons(2, ()));\nhead(p);\nhead(5)", FNAME) {
        Err(e) if e.rendered.contains("head requires pair") => {}
        Err(e) => return fail(format!("message mismatch: {}", first_line(&e.rendered))),
        Ok(_) => return fail("containing (head 5) program unexpected succeeded".to_string()),
    }
    match run_source(COUNTERS, FNAME) {
        Ok(o) => {
            let rendered = render_value(&o.value, &o.heap);
            if rendered.trim() != "(4 2)" {
                return fail(format!(
                    "after recovery closure counter mismatch: {}",
                    rendered.trim()
                ));
            }
            if o.heap.slot_count() == 0 {
                return fail("after recovery heap slot position count is 0(heap not participating in execution)".to_string());
            }
            pass(format!(
                "after heap-allocation-stage errors count machine⇒(4 2)(heap slots={})",
                o.heap.slot_count()
            ))
        }
        Err(e) => fail(format!(
            "after error closure program failed:{}",
            first_line(&e.rendered)
        )),
    }
}

/// D06: after two errors, the third error's diagnostic structure is still
/// intact (stage/E code/Span/file name/message).
fn probe_diagnostics_structure_after_errors() -> CaseResult {
    let _ = run_source("1 + \"s\"", FNAME);
    let _ = run_source("1 / 0", FNAME);
    let err = match run_source("zz = 1;", FNAME) {
        Err(e) => e,
        Ok(_) => return fail("(assign zz 1) unexpected succeeded".to_string()),
    };
    // r46 / D49: unbound reference moved up to compile time (Run E0004 →
    // Compile E0022 — the diagnostic-structure-integrity stance updates with
    // the carrier: the stage/E0022/Span/location four invariants unchanged)
    if err.stage != Stage::Compile {
        return fail(format!("stage drift: {:?}", err.stage));
    }
    if err.diagnostic.code != Some(DiagnosticCode(22)) {
        return fail("E code drift(expected E0022)".to_string());
    }
    if err.diagnostic.primary_span.is_empty() {
        return fail("Span drift move(is empty)".to_string());
    }
    if !err.rendered.contains("unbound reference") || !err.rendered.contains(FNAME) {
        return fail(format!(
            "message/position drift move: {}",
            first_line(&err.rendered)
        ));
    }
    pass(
        "two after error#three error diagnostic structure complete(stage/E0022/Span/position)"
            .to_string(),
    )
}

// ---------------------------------------------------------------------------
// main: per-case report + summary + mechanical check of the §7.3.1 mandatory ratios
// ---------------------------------------------------------------------------

fn main() {
    // Subprocess probe mode (⑥ circular dependency — crash isolation)
    if std::env::args().nth(1).as_deref() == Some(PROBE_ARG) {
        cyclic_probe_child();
        return;
    }

    println!("== kerf Stage 0 gate audit set stage0_gate_audit_r1(sop.md §7.3.1 / §7.1.1)==");
    println!(
        "case total {}(A single-statement 12 / B multi-statement 12 / C complex 8 / D recovery 6 / P positive 3)\n",
        CASES.len()
    );

    let mut fail_count = 0;
    let mut xfail_count = 0;
    let mut class_seen = [0usize; 7];
    let mut bucket_counts = [0usize; 5];
    let mut negative = 0;
    let mut positive = 0;
    let mut mixed = 0;

    for c in CASES {
        bucket_counts[c.bucket as usize] += 1;
        match c.polarity {
            Polarity::Negative => negative += 1,
            Polarity::Positive => positive += 1,
            Polarity::Mixed => mixed += 1,
        }
        if let Some(cls) = c.class {
            class_seen[cls.index() - 1] += 1;
        }
        let r = run_case(c);
        let status = if !r.pass {
            "FAIL"
        } else if r.xfail {
            "XFAIL"
        } else {
            "PASS"
        };
        let class_label = c.class.map(|k| k.label()).unwrap_or("-");
        println!(
            "[{}] {} {} {} {}",
            status,
            c.id,
            c.bucket.label(),
            polarity_label(c.polarity),
            class_label
        );
        println!("      src: {}", short_src(c.src));
        println!("      → {}", r.detail);
        if let Some(w) = &r.warn {
            println!("      WARN: {}", w);
        }
        if !r.pass {
            fail_count += 1;
        }
        if r.xfail {
            xfail_count += 1;
        }
    }

    // Summary
    let total = CASES.len();
    let passed = total - fail_count;
    println!("\n== summary ==");
    println!(
        "total {} / PASS {}(containing XFAIL-WARN {})/ FAIL {}",
        total, passed, xfail_count, fail_count
    );
    println!(
        "bucket ratio: single-statement {}/10 multi-statement {}/10 complex {}/5 recovery {}/5 positive {}/8(limit)",
        bucket_counts[0], bucket_counts[1], bucket_counts[2], bucket_counts[3], bucket_counts[4]
    );
    println!(
        "polarity: negative {}(≥22)/ recovery-mixed combine {} / positive {}(≤8)",
        negative, mixed, positive
    );
    print!("§7.1.1 seven-class coverage:");
    for (i, n) in class_seen.iter().enumerate() {
        print!(" {}={}", i + 1, n);
    }
    println!();

    // §7.3.1 mandatory failure-condition mechanical check (ratios unmet → NEEDS REVISION, exit code 1)
    let mut violations: Vec<&str> = Vec::new();
    if total < 32 {
        violations.push("case total < 32");
    }
    if bucket_counts[0] < 10 {
        violations.push("single-statement negative < 10");
    }
    if bucket_counts[1] < 10 {
        violations.push("multi-statement negative < 10");
    }
    if bucket_counts[2] < 5 {
        violations.push("complex program negative < 5");
    }
    if bucket_counts[3] < 5 {
        violations.push("error recovery test < 5");
    }
    if negative < 22 {
        violations.push("negative case < 22");
    }
    if positive > 8 {
        violations.push("positive case > 8");
    }
    if class_seen.contains(&0) {
        violations.push("§7.1.1 seven class not all coverage");
    }
    if fail_count > 0 {
        violations.push("exists FAIL case");
    }
    if violations.is_empty() {
        println!("\n§7.3.1 mandatory ratios all satisfied; all seven classes covered.EXIT 0");
        std::process::exit(0);
    } else {
        println!("\n forced failed condition trigger(§7.3.1):");
        for v in &violations {
            println!("  - {}", v);
        }
        println!("EXIT 1");
        std::process::exit(1);
    }
}

fn polarity_label(p: Polarity) -> &'static str {
    match p {
        Polarity::Negative => "negative",
        Polarity::Mixed => "recovery",
        Polarity::Positive => "positive",
    }
}

fn short_src(src: &str) -> String {
    let one_line = src.replace('\n', " ");
    let mut s: String = one_line.chars().take(72).collect();
    if one_line.chars().count() > 72 {
        s.push_str("...");
    }
    s
}

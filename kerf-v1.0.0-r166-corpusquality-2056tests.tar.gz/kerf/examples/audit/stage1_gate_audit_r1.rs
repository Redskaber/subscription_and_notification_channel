//! E6 close-out (r154 / 224-d1): converted to the target-syntax single face.
//! Stage 1 negative gate audit suite (sop.md §7.3.1 rule 3 / §7.1.1 seven-class
//! matrix / §7.3.2 previous-round fix-boundary cases / §21.3 stage-acceptance
//! four conditions).
//!
//! **Purpose**: ≥30-case negative audit — the mandatory audit suite of the
//! Stage 1 stage gate review (§7.3) (round 1, r1). The entire audit goes
//! through the **production pipeline** (after the E1-β production switch:
//! both read + expansion are self-hosted — since the switch window and the
//! E5 close-out cleanup batch r120 / 190-a: reader.ktf + expander.ktf on
//! the VM; the Rust seed = parity oracle) — the audit itself is the ongoing
//! verification vehicle for §21.3 conditions 1/2.
//!
//! **How to run**: from the workspace root, `cargo run --example stage1_gate_audit_r1`.
//! Exit code 0 when every case PASSes; exit code 1 if any case FAILs or a
//! §7.3.1 mandatory ratio is unmet.
//!
//! **Structure** (§7.3.1 rule 2 mandatory ratios, mechanically checked in main()):
//! - Bucket A 12: single-statement negative (basic type system)
//! - Bucket B 12: multi-statement / multi-function negative (integration
//!   correctness — macro / module / prelude surface)
//! - Bucket C 10: complex-program negative (nested control flow / closures /
//!   recursion / macros + ⑥ circular dependency + ⑦ depth exceeded)
//! - Bucket D 6: error recovery (in-process continued run of a correct
//!   program after an error)
//! - Bucket E 6: previous-round fix-boundary cases (§7.3.2 — this batch's fix
//!   surface: Span-union generation guards / require·set·define-syntax
//!   generations / leading injection / production-switch liveness / hygiene
//!   counter nesting / depth-limit production path)
//! - Bucket P 4: positive sanity + §21.3 four-condition anchoring (auditor
//!   self-check)
//!
//! Total 50 cases: 34 negative + 6 recovery + 6 boundary + 4 positive.
//!
//! **§7.1.1 seven-class coverage**: ① syntax ② unbound ③ empty application
//! ④ arity ⑤ type mismatch ⑥ module circular dependency (two-module source →
//! registry DFS grey marking) ⑦ macro expansion depth exceeded
//! (self-referential macro via the production path).
//!
//! **§21.3 four-condition anchoring** (bucket P + the whole audit surface):
//! - Condition 1 (a subset language expressing the compiler front end): the
//!   production pipeline itself (self-hosted Reader+Expander) + all macro
//!   positive/negative cases passing = expressiveness proof;
//! - Condition 2 (running correctly on the Stage 0 VM): the self-hosted
//!   Expander carries all production expansions on the VM (implicitly
//!   verified by every case);
//! - Condition 3 (minimal standard library usable): P02 prelude pipeline
//!   (list hofs) + the existing stdlib suite (list/string/I-O ≥8 functions
//!   per surface, tests/v0/stage1/plan/stdlib_tests.rs);
//! - Condition 4 (incremental-compilation infrastructure usable): P04
//!   compilation-cache determinism (repeated compilation of the same source
//!   agrees) + the cache_tests.rs content-addressing/invalidation surface.
//!
//! **E6 conversion note** (r154 / 224-d1, s-expr-removal-plan §4 E6): the
//! whole case table and every probe moved to the target-syntax single face
//! (`run_source` / `run_source_seed` dual paths, `audit.ktf`
//! filename — the S-expr entry family retired). Case count, bucket /
//! polarity / §7.1.1 class assignments unchanged (zero deletions). Carrier
//! rulings, calibrated by running both chains: ③ empty application rides
//! the zero-argument `quote()` application (the target face's `()` is the
//! unit literal — the S-expr empty-list expression face is unreachable;
//! A02/B12/C09, stage0-audit r1 same ruling); the macro-definition
//! shape / zero-clause / literal-set validations moved to the Read front
//! (A06/A07/B03 — the target Reader validates `macro` shape); A05's
//! misplaced-internal-form rides the mid-module-body `import` (same
//! Expand/E0002 form-placement family); A10's assign-target check moved to
//! the Reader (the assign statement only accepts an identifier LHS);
//! C10's `while` form has no target surface (E6-CG §2) → recursion rewrite
//! carrying the same unbound-in-repeated-body semantics; P04's cache-hit
//! observation rides the frozen trait face (the pipeline `cache_hit` field
//! is E6-dormant with the S-expr surface — miss→store→hit content-addressed
//! sequence, cache_tests.rs surface).
//!
//! Governing clauses: §7.3.1/§7.3.2 (ratios and boundaries), §2.3-11
//! (measure, don't guess — all assertions run for real through the
//! production pipeline).

use kerf_driver::cache::with_cache;
use kerf_driver::{
    cache_key, check_source_recover, compile_source, run_source, run_source_seed, CachedResult,
    CompilationCache, CompilerKind, Stage,
};
use kerf_span::DiagnosticCode;

/// Audit source file name (for diagnostic rendering location assertions).
const FNAME: &str = "audit.ktf";

// ---------------------------------------------------------------------------
// Bucket / polarity / §7.1.1 error classes
// ---------------------------------------------------------------------------

#[derive(Clone, Copy, PartialEq, Eq)]
enum Bucket {
    Single,
    Multi,
    Complex,
    Recovery,
    Boundary,
    Positive,
}

impl Bucket {
    fn label(self) -> &'static str {
        match self {
            Bucket::Single => "A single-statement",
            Bucket::Multi => "B multi-statement",
            Bucket::Complex => "C complex",
            Bucket::Recovery => "D recovery",
            Bucket::Boundary => "E boundary",
            Bucket::Positive => "P positive",
        }
    }
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum Polarity {
    Negative,
    Positive,
    Recovery,
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum ErrorClass {
    Syntax,
    Unbound,
    EmptyForm,
    Arity,
    TypeMismatch,
    CircularDep,
    MacroDepth,
}

impl ErrorClass {
    fn index(self) -> usize {
        match self {
            ErrorClass::Syntax => 1,
            ErrorClass::Unbound => 2,
            ErrorClass::EmptyForm => 3,
            ErrorClass::Arity => 4,
            ErrorClass::TypeMismatch => 5,
            ErrorClass::CircularDep => 6,
            ErrorClass::MacroDepth => 7,
        }
    }
    fn label(self) -> &'static str {
        match self {
            ErrorClass::Syntax => "① syntax",
            ErrorClass::Unbound => "② unbound",
            ErrorClass::EmptyForm => "③ empty application",
            ErrorClass::Arity => "④ argument count",
            ErrorClass::TypeMismatch => "⑤ type mismatch",
            ErrorClass::CircularDep => "⑥ circular dependency",
            ErrorClass::MacroDepth => "⑦ macro depth",
        }
    }
}

// ---------------------------------------------------------------------------
// Expectations and results
// ---------------------------------------------------------------------------

enum Expect {
    /// Both paths Err: stage + message substring (+ mechanical check of E code + non-empty Span).
    Err { stage: Stage, msg: &'static str },
    /// Both paths Ok and in agreement.
    OkDual(&'static str),
    /// Custom probe (error recovery / §21.3 anchoring).
    Custom(fn() -> CaseResult),
}

struct Case {
    id: &'static str,
    bucket: Bucket,
    polarity: Polarity,
    class: Option<ErrorClass>,
    src: &'static str,
    expect: Expect,
}

struct CaseResult {
    pass: bool,
    detail: String,
}

fn pass(detail: String) -> CaseResult {
    CaseResult { pass: true, detail }
}

fn fail(detail: String) -> CaseResult {
    CaseResult {
        pass: false,
        detail,
    }
}

fn short_src(src: &str) -> String {
    let one = src.replace('\n', " ⏎ ");
    if one.len() > 88 {
        format!("{}…", &one[..84])
    } else {
        one
    }
}

fn first_line(s: &str) -> String {
    s.lines().next().unwrap_or("").to_string()
}

// ---------------------------------------------------------------------------
// Corpus constants
// ---------------------------------------------------------------------------

const FIB10: &str =
    "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(10)";

const SWAP: &str = r#"macro swap {
    (a, b) => {
        let tmp = a;
        a = b;
        b = tmp;
    }
}
let x = 1;
let y = 2;
do(swap(x, y), x - y)"#;

const MY_OR: &str = r#"macro my_or {
    () => false,
    (a, rest ...) => if a { a } else { my_or(rest ...) },
}"#;

const COUNTERS: &str = r#"
        fn make_counter() {
            let n = 0;
            || { n = n + 1; n }
        }
        let a = make_counter();
        let b = make_counter();
        a(); a(); a();
        b();
        list(a(), b())
    "#;

const PRELUDE_PIPE: &str = r#"import kerf_prelude;
module user {
    import kerf_prelude;
    let lst = list(1, 2, 3, 4, 5);
    foldl(|| (acc: T, x: T) { acc + x }, 0, map(|| (x: T) { x * x }, filter(|| (x: T) { x > 2 }, lst)))
}"#;

// ---------------------------------------------------------------------------
// Case table (50 cases)
// ---------------------------------------------------------------------------

const CASES: &[Case] = &[
    // ---- Bucket A: single-statement negative (basic type system, 12) ----
    Case {
        id: "A01",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Syntax),
        // E6: the unclosed S-expr form rides the unclosed string inside the
        // macro definition (the unclosed-delimiter Read family; the bare
        // unclosed-brace face is a zero-width EOF Span — the wide-span
        // string face keeps the mechanical Span-non-empty check meaningful)
        src: "macro m { (x) => \"unterminated }",
        expect: Expect::Err {
            stage: Stage::Read,
            msg: "unclosed string",
        },
    },
    Case {
        id: "A02",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::EmptyForm),
        // E6: the ③ empty-application carrier = the zero-argument `quote()`
        // application (the target `()` is the unit literal — the S-expr
        // empty-list expression face is unreachable; stage0-audit r1 ruling)
        src: "quote()",
        expect: Expect::Err {
            stage: Stage::Expand,
            msg: "quote form",
        },
    },
    Case {
        id: "A03",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        src: "undefined_var",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "unbound",
        },
    },
    Case {
        id: "A04",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        src: "1 + \"string\"",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "requires int",
        },
    },
    Case {
        id: "A05",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Syntax),
        // E6: syntax-rules-outside-define-syntax → the misplaced-form carrier
        // = mid-module-body `import` (same Expand/E0002 form-placement family;
        // message parity on both chains probed)
        src: "module m { 1; import kerf_string; }",
        expect: Expect::Err {
            stage: Stage::Expand,
            msg: "import/export may only appear",
        },
    },
    Case {
        id: "A06",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: None,
        // E6: `(define-syntax)` missing arguments → the malformed macro
        // clause face (arm missing the `=>` separator — the target Reader
        // validates macro shape; the zero-width EOF variants are avoided to
        // keep the mechanical Span-non-empty check meaningful)
        src: "macro m { (x) x }",
        expect: Expect::Err {
            stage: Stage::Read,
            msg: "expected =>",
        },
    },
    Case {
        id: "A07",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: None,
        // E6: syntax-rules zero-clause → empty macro body (the check moved to
        // the Read front — the target Reader rejects the empty arm set)
        src: "macro m { }",
        expect: Expect::Err {
            stage: Stage::Read,
            msg: "macro body needs at least one clause",
        },
    },
    Case {
        id: "A08",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        src: "if (1) { 2 } else { 3 }",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "requires bool",
        },
    },
    Case {
        id: "A09",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: None,
        src: "quote([1, 2])",
        // r138 TD-002 D2-b: quote-of-vector is legal (vector value model)
        expect: Expect::OkDual("[1 2]"),
    },
    Case {
        id: "A10",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: None,
        // E6: assign-target-must-be-a-symbol → the Reader-side face (the
        // target assign statement only accepts an identifier LHS)
        src: "1 = 2;",
        expect: Expect::Err {
            stage: Stage::Read,
            msg: "expected an expression, got Assign",
        },
    },
    Case {
        id: "A11",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        src: "macro m { () => undefined_thing }\nm()",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "unbound",
        },
    },
    Case {
        id: "A12",
        bucket: Bucket::Single,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Arity),
        src: "(|| (x: i64) { x })(1, 2)",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "argument count mismatch",
        },
    },
    // ---- Bucket B: multi-statement / multi-function negative (integration correctness, 12) ----
    Case {
        id: "B01",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: None,
        src: "macro m { (x) => x }\nm()",
        expect: Expect::Err {
            stage: Stage::Expand,
            msg: "macro call matches no clause pattern",
        },
    },
    Case {
        id: "B02",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: None,
        src: "macro m { (x, y) => x }\nm(1)",
        expect: Expect::Err {
            stage: Stage::Expand,
            msg: "macro `m` expand failed",
        },
    },
    Case {
        id: "B03",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Syntax),
        // E6: syntax-rules literal-set with a non-symbol → the target macro
        // literal-set face (the check moved to the Read front)
        src: "macro m (1) { (x) => x }\nm(1)",
        expect: Expect::Err {
            stage: Stage::Read,
            msg: "expected a literal-set identifier",
        },
    },
    Case {
        id: "B04",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: None,
        src: "macro m { (x) => x }\nm(1);\nm()",
        expect: Expect::Err {
            stage: Stage::Expand,
            msg: "matches no clause",
        },
    },
    Case {
        id: "B05",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        src: "fn f() { y = 1; }\nf()",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "unbound",
        },
    },
    Case {
        id: "B06",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Arity),
        src: "fn f(a: i64, b: i64) -> i64 { a + b }\nf(1)",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "argument count mismatch",
        },
    },
    Case {
        id: "B07",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: None,
        // M2 (r40) E0019 takes over: unknown imports are rejected first by the
        // import-surface allowlist check (formerly the registry.visit
        // "undeclared module" Expand form — E0019 carries the registered
        // allowlist and window guidance, a diagnostic gain; deep-review D2 ruling)
        src: "module user { import nonexistent_module;\n1 }",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "unknown imported module",
        },
    },
    Case {
        id: "B08",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: None,
        src: "import kerf_prelude;\nmodule user { import kerf_prelude;\nfn map(f: T, l: T) { l }\nmap(head, list(1)) }",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "duplicate variable definition",
        },
    },
    Case {
        id: "B09",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        src: "fn f(x: T) -> T { x + 1 }\nf(\"str\")",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "requires int",
        },
    },
    Case {
        id: "B10",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: None,
        src: "|| (x: T) { define(y, 1); define(z, 2); x + y; define(w, 3) }",
        expect: Expect::Err {
            stage: Stage::Expand,
            msg: "head of a function body",
        },
    },
    Case {
        id: "B11",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: None,
        src: "macro m { ((a)) => a }\nm(1)",
        expect: Expect::Err {
            stage: Stage::Expand,
            msg: "macro `m` expand failed",
        },
    },
    Case {
        id: "B12",
        bucket: Bucket::Multi,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::EmptyForm),
        // E6: define-with-empty-list value → the empty-form application as
        // the defined value (`quote()` carrier — A02's ruling)
        src: "let x = quote();\nx",
        expect: Expect::Err {
            stage: Stage::Expand,
            msg: "quote form",
        },
    },
    // ---- Bucket C: complex-program negative (nested control flow / closures /
    // recursion / macros, 10) ----
    Case {
        id: "C01",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::CircularDep),
        // M2 (r40) E0019 takes over first: imports between user modules are
        // rejected by the import-surface allowlist check (22 §7 D2 ruling:
        // imports between user modules belong to the Stage 3 compilation-unit
        // window; the registry DFS cycle-detection logic is kept — the entry
        // reopens at Stage 3).
        // class stays CircularDep (ratio mechanical-check measurement stance —
        // semantic note recorded as-is)
        src: "module a { import b;\n1 }\nmodule b { import a;\n1 }",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "unknown imported module `b`",
        },
    },
    Case {
        id: "C02",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::MacroDepth),
        src: "macro loop2 { () => loop2() }\nloop2()",
        expect: Expect::Err {
            stage: Stage::Expand,
            msg: "macro expansion depth exceeds the limit 10000",
        },
    },
    Case {
        id: "C03",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Unbound),
        src: "fn deep(n: i64) -> T { if (n == 0) { missing_base } else { deep(n - 1) + 1 } }\ndeep(10)",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "unbound",
        },
    },
    Case {
        id: "C04",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::Arity),
        src: "fn ack(m: i64, n: i64) -> i64 { if (m == 0) { n + 1 } else { if (n == 0) { ack(m - 1, 1) } else { ack(m - 1, ack(m, n - 1)) } } }\nack(1)",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "argument count mismatch",
        },
    },
    Case {
        id: "C05",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::TypeMismatch),
        src: "fn f(n: T, acc: T) -> T { if (n == 0) { acc } else { f(n - 1, acc + 1) } }\nf(10, \"seed\")",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "requires int",
        },
    },
    Case {
        id: "C06",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: None,
        src: "(|| { let f = || (x: T) { g(x) }; f(1) })()",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "unbound",
        },
    },
    Case {
        id: "C07",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: None,
        src: "macro m { (x) => m(m(x)) }\nm(1)",
        expect: Expect::Err {
            stage: Stage::Expand,
            msg: "macro expansion depth exceeds the limit 10000",
        },
    },
    Case {
        id: "C08",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: None,
        src: "import kerf_prelude;\nmodule user { import kerf_prelude;\nfoldl(|| (a: T, b: T) { a + b }, 0) }",
        expect: Expect::Err {
            stage: Stage::Run,
            msg: "argument count mismatch",
        },
    },
    Case {
        id: "C09",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: Some(ErrorClass::EmptyForm),
        // E6: let-bound empty list → the empty-form application as the bound
        // value (`quote()` carrier — A02's ruling)
        src: "fn f() { let x = quote(); x }\nf()",
        expect: Expect::Err {
            stage: Stage::Expand,
            msg: "quote form",
        },
    },
    Case {
        id: "C10",
        bucket: Bucket::Complex,
        polarity: Polarity::Negative,
        class: None,
        // E6: `while` has no target surface (E6-CG §2) → recursion rewrite
        // carrying the same unbound-in-repeated-body semantics
        src: "fn spin() { x = x + 1; spin() }\nspin()",
        expect: Expect::Err {
            stage: Stage::Compile,
            msg: "unbound",
        },
    },
    // ---- Bucket D: error recovery (in-process continued run after errors, 6) ----
    Case {
        id: "D01",
        bucket: Bucket::Recovery,
        polarity: Polarity::Recovery,
        class: None,
        src: "1 +",
        expect: Expect::Custom(probe_read_recovery),
    },
    Case {
        id: "D02",
        bucket: Bucket::Recovery,
        polarity: Polarity::Recovery,
        class: None,
        src: "macro m (1) { (x) => x }\nm(1)",
        expect: Expect::Custom(probe_expand_recovery),
    },
    Case {
        id: "D03",
        bucket: Bucket::Recovery,
        polarity: Polarity::Recovery,
        class: None,
        src: "module a { import b;\n1 }\nmodule b { import a;\n1 }",
        expect: Expect::Custom(probe_cycle_recovery),
    },
    Case {
        id: "D04",
        bucket: Bucket::Recovery,
        polarity: Polarity::Recovery,
        class: None,
        src: "macro loop2 { () => loop2() }\nloop2()",
        expect: Expect::Custom(probe_depth_recovery),
    },
    Case {
        id: "D05",
        bucket: Bucket::Recovery,
        polarity: Polarity::Recovery,
        class: None,
        src: "undefined_one()",
        expect: Expect::Custom(probe_run_recovery),
    },
    Case {
        id: "D06",
        bucket: Bucket::Recovery,
        polarity: Polarity::Recovery,
        class: None,
        src: "(|| (x: i64) { x })(1, 2)",
        expect: Expect::Custom(probe_arity_recovery),
    },
    // ---- Bucket E: previous-round fix-boundary cases (§7.3.2 — this batch's fix surface, 6) ----
    Case {
        id: "E01",
        bucket: Bucket::Boundary,
        polarity: Polarity::Positive,
        class: None,
        src: SWAP,
        expect: Expect::OkDual("1"),
    },
    Case {
        id: "E02",
        bucket: Bucket::Boundary,
        polarity: Polarity::Positive,
        class: None,
        src: "require io;\nquote(1)",
        expect: Expect::Err {
            stage: Stage::Expand,
            msg: "require form",
        },
    },
    Case {
        id: "E03",
        bucket: Bucket::Boundary,
        polarity: Polarity::Positive,
        class: None,
        src: "let x = 1;\nx = 2;\nx",
        expect: Expect::OkDual("2"),
    },
    Case {
        id: "E04",
        bucket: Bucket::Boundary,
        polarity: Polarity::Positive,
        class: None,
        src: PRELUDE_PIPE,
        expect: Expect::OkDual("50"),
    },
    Case {
        id: "E05",
        bucket: Bucket::Boundary,
        polarity: Polarity::Positive,
        class: None,
        src: "module m { macro f { (x) => x }\nf(1) }",
        expect: Expect::OkDual("1"),
    },
    Case {
        id: "E06",
        bucket: Bucket::Boundary,
        polarity: Polarity::Positive,
        class: None,
        src: "macro swap {\n    (a, b) => {\n        let tmp = a;\n        a = b;\n        b = tmp;\n    }\n}\n(|| { let tmp = 10; let u = 3; let v = 4; do(swap(u, v), u + v + tmp) })()",
        expect: Expect::Custom(probe_macro_in_sugar_span_boundary),
    },
    // ---- Bucket P: positive sanity + §21.3 anchoring (4) ----
    Case {
        id: "P01",
        bucket: Bucket::Positive,
        polarity: Polarity::Positive,
        class: None,
        src: FIB10,
        expect: Expect::OkDual("55"),
    },
    Case {
        id: "P02",
        bucket: Bucket::Positive,
        polarity: Polarity::Positive,
        class: None,
        src: PRELUDE_PIPE,
        expect: Expect::OkDual("50"),
    },
    Case {
        id: "P03",
        bucket: Bucket::Positive,
        polarity: Polarity::Positive,
        class: None,
        src: MY_OR,
        expect: Expect::Custom(probe_macro_or_positive),
    },
    Case {
        id: "P04",
        bucket: Bucket::Positive,
        polarity: Polarity::Positive,
        class: None,
        src: FIB10,
        expect: Expect::Custom(probe_incremental_compile_determinism),
    },
];

// ---------------------------------------------------------------------------
// Runner
// ---------------------------------------------------------------------------

fn run_case(c: &Case) -> CaseResult {
    match &c.expect {
        Expect::Err { stage, msg } => run_negative(c, *stage, msg),
        Expect::OkDual(s) => run_positive_dual(c, s),
        Expect::Custom(f) => f(),
    }
}

fn run_negative(c: &Case, stage: Stage, msg: &str) -> CaseResult {
    let err = match run_source(c.src, FNAME) {
        Err(e) => e,
        Ok(_) => {
            return fail(format!(
                "expected {:?} stage Err, VM path returns Ok",
                stage
            ));
        }
    };
    if err.stage != stage {
        return fail(format!(
            "VM stage mismatch: expected {:?} actual {:?}({})",
            stage,
            err.stage,
            first_line(&err.rendered)
        ));
    }
    if !err.rendered.contains(msg) {
        return fail(format!(
            "VM message does not contain `{}`: {}",
            msg,
            first_line(&err.rendered)
        ));
    }
    let want_code = DiagnosticCode(expect_code(stage, msg));
    // M2 (r40) namespace-family dedicated codes (E0013-E0019) are legal at the
    // Compile stage (family members of base code E0003 — gate-review
    // mechanical-check extension)
    let code_ok = err.diagnostic.code == Some(want_code)
        || (stage == Stage::Compile && matches!(err.diagnostic.code.map(|k| k.0), Some(13..=19)));
    if !code_ok {
        return fail(format!(
            "E code mismatch: expected E{:04} actual {:?}",
            want_code.0,
            err.diagnostic.code.map(|k| k.0)
        ));
    }
    if err.diagnostic.primary_span.is_empty() {
        return fail("primary Span empty (diagnostic location missing)".to_string());
    }
    if !err.rendered.contains(FNAME) {
        return fail(format!(
            "render output missing file name {}(position excerpt missing)",
            FNAME
        ));
    }
    // Seed-chain dual path (T1 new measurement stance 42-d: eval retired — the
    // seed chain is the differential-testing oracle): same Err (rather than
    // silent success/hang) with identical stage + message substring
    match run_source_seed(c.src, FNAME) {
        Ok(_) => fail("expected Err, seed chain returns Ok(dual-path split)".to_string()),
        Err(e2) => {
            if e2.stage != stage {
                fail(format!(
                    "seed chain stage mismatch: expected {:?} actual {:?}",
                    stage, e2.stage
                ))
            } else if !e2.rendered.contains(msg) {
                fail(format!(
                    "seed chain message does not contain `{}`: {}",
                    msg,
                    first_line(&e2.rendered)
                ))
            } else {
                pass(format!(
                    "dual-path same Err(E{:04} + Span non-empty)",
                    want_code.0
                ))
            }
        }
    }
}

fn run_positive_dual(c: &Case, want: &str) -> CaseResult {
    let a = match run_source(c.src, FNAME) {
        Ok(o) => o,
        Err(e) => return fail(format!("production chain Err: {}", first_line(&e.rendered))),
    };
    let b = match run_source_seed(c.src, FNAME) {
        Ok(o) => o,
        Err(e) => return fail(format!("seed chain Err: {}", first_line(&e.rendered))),
    };
    let ra = kerf_vm::render_value(&a.value, &a.heap);
    let rb = kerf_vm::render_value(&b.value, &b.heap);
    if ra != want || rb != want {
        return fail(format!(
            "value mismatch: expected {}, production {} / seed {}",
            want, ra, rb
        ));
    }
    if !a.value.eq_value(&b.value) {
        return fail(format!(
            "dual-path value mismatch: production {} vs seed {}",
            ra, rb
        ));
    }
    pass(format!("dual-path same value ⇒ {}", ra))
}

fn stage_e_code(stage: Stage) -> u32 {
    match stage {
        Stage::Read => 1,
        Stage::Expand => 2,
        Stage::Compile => 3,
        Stage::Run => 4,
    }
}

/// r46 / 22 §15 D49: stage-code mapping correction (the Compile stage is not
/// injective — code 3 = compiler-internal-error family [E0003]; **code 22 =
/// compile-time unbound-verification family**). Keyword-based message
/// discrimination (the unbound family moved up to compile time).
fn expect_code(stage: Stage, msg: &str) -> u32 {
    match stage {
        Stage::Compile if msg.contains("unbound") => 22,
        _ => stage_e_code(stage),
    }
}

// ---------------------------------------------------------------------------
// Bucket D recovery probes: in-process continued run of a correct program after errors
// (in-process Effect short-circuit recovery surface)
// ---------------------------------------------------------------------------

fn probe_read_recovery() -> CaseResult {
    let bad = run_source("1 +", FNAME);
    if bad.is_ok() {
        return fail("preceding error should Err".to_string());
    }
    match run_source(FIB10, FNAME) {
        Ok(o) if matches!(o.value, kerf_vm::Value::Int(55)) => {
            pass("read continue-run after error fib(10)=55(same-process recovery -- Effect one-shot escape layer)".to_string())
        }
        other => fail(format!("recovery failed: {:?}", other.map(|o| o.value))),
    }
}

fn probe_expand_recovery() -> CaseResult {
    let bad = run_source("macro m (1) { (x) => x }\nm(1)", FNAME);
    if bad.is_ok() {
        return fail("preceding error should Err".to_string());
    }
    match run_source(SWAP, FNAME) {
        Ok(o) if matches!(o.value, kerf_vm::Value::Int(1)) => pass(
            "macro parse continue-run after error swap macro program(same-process recovery)"
                .to_string(),
        ),
        other => fail(format!("recovery failed: {:?}", other.map(|o| o.value))),
    }
}

fn probe_cycle_recovery() -> CaseResult {
    let bad = run_source(
        "module a { import b;\n1 }\nmodule b { import a;\n1 }",
        FNAME,
    );
    if bad.is_ok() {
        return fail("preceding error should Err".to_string());
    }
    match run_source(
        "module m { export f;\nfn f(x: i64) -> i64 { x * 2 } }\n1",
        FNAME,
    ) {
        Ok(o) if matches!(o.value, kerf_vm::Value::Int(1)) => {
            pass("circular dependency continue-run after error module program(same-process recovery -- DFS gray marking without residue)".to_string())
        }
        other => fail(format!("recovery failed: {:?}", other.map(|o| o.value))),
    }
}

fn probe_depth_recovery() -> CaseResult {
    let bad = run_source("macro loop2 { () => loop2() }\nloop2()", FNAME);
    if bad.is_ok() {
        return fail("preceding error should Err".to_string());
    }
    match run_source("macro m { (x) => x }\ndo(m(1), m(2), m(3))", FNAME) {
        Ok(o) if matches!(o.value, kerf_vm::Value::Int(3)) => {
            pass("depth exceed restriction continue-run after error macro program(same-process recovery -- thread_local zero state residue)".to_string())
        }
        other => fail(format!("recovery failed: {:?}", other.map(|o| o.value))),
    }
}

fn probe_run_recovery() -> CaseResult {
    let bad = run_source("undefined_one()", FNAME);
    if bad.is_ok() {
        return fail("preceding error should Err".to_string());
    }
    match run_source("20 + 22", FNAME) {
        Ok(o) if matches!(o.value, kerf_vm::Value::Int(42)) => {
            pass("run-time unbound subsequent run arithmetic(same-process recovery)".to_string())
        }
        other => fail(format!("recovery failed: {:?}", other.map(|o| o.value))),
    }
}

fn probe_arity_recovery() -> CaseResult {
    let bad = run_source("(|| (x: i64) { x })(1, 2)", FNAME);
    if bad.is_ok() {
        return fail("preceding error should Err".to_string());
    }
    match run_source(COUNTERS, FNAME) {
        Ok(o) => {
            let got = kerf_vm::render_value(&o.value, &o.heap);
            if got == "(4 2)" {
                pass(
                    "arity continue-run after error closure counter(a # 4 times / b # 2 times)"
                        .to_string(),
                )
            } else {
                fail(format!("resume value mismatch: (4 2) vs {}", got))
            }
        }
        Err(e) => fail(format!("recovery failed:{}", first_line(&e.rendered))),
    }
}

// ---------------------------------------------------------------------------
// Bucket E boundary probes (§7.3.2 — the boundary of this batch's fix surface)
// ---------------------------------------------------------------------------

/// Boundary of the macro-product Span-union generation guard: the macro sits
/// inside a sugar product (use-site generation ≥1) — the product Span falls
/// in the template range (the user span is dropped per the generation guard)
/// and the **behavior is correct** (+ value).
fn probe_macro_in_sugar_span_boundary() -> CaseResult {
    let s = "macro swap {\n    (a, b) => {\n        let tmp = a;\n        a = b;\n        b = tmp;\n    }\n}\n(|| { let tmp = 10; let u = 3; let v = 4; do(swap(u, v), u + v + tmp) })()";
    match run_source(s, FNAME) {
        Ok(o) => {
            let got = kerf_vm::render_value(&o.value, &o.heap);
            // u=4, v=3, tmp=10 → 17
            if got == "17" {
                pass("macro calls inside sugar behave correctly(u/v swap + use user tmp lexically visible=10)→ 17".to_string())
            } else {
                fail(format!("boundary line is mismatch: 17 vs {}", got))
            }
        }
        Err(e) => fail(format!("boundary case Err: {}", first_line(&e.rendered))),
    }
}

// ---------------------------------------------------------------------------
// Bucket P §21.3 anchoring probes
// ---------------------------------------------------------------------------

fn probe_macro_or_positive() -> CaseResult {
    let src = format!("{} my_or(false, false, true)", MY_OR);
    match run_source(&src, FNAME) {
        Ok(o) => {
            let got = kerf_vm::render_value(&o.value, &o.heap);
            if got == "true" {
                pass(
                    "ellipsis recursive macro short-circuit(final argument true)⇒ true".to_string(),
                )
            } else {
                fail(format!("expected true, got {}", got))
            }
        }
        Err(e) => fail(format!("expected Ok: {}", first_line(&e.rendered))),
    }
}

/// §21.3 condition 4: incremental-compilation infrastructure — repeated
/// compilation of the same source yields identical products (content-addressed
/// cache) + the static check reports 0 errors + the cache observation face.
///
/// E6 rework (r154 / 224-d1): the pipeline `cache_hit` field is dormant with
/// the S-expr surface (`compile_front_cached` deleted — the target entries
/// are cache-free by design; `check_source_recover` is the recovery
/// face, uncached by ruling) → the cache observation rides the frozen trait
/// face (the cache_tests.rs surface): miss → store → hit, content-addressed
/// reuse of the same artifacts.
fn probe_incremental_compile_determinism() -> CaseResult {
    let a = compile_source(FIB10, FNAME);
    let b = compile_source(FIB10, FNAME);
    let (a, b) = match (a, b) {
        (Ok(a), Ok(b)) => (a, b),
        (Err(e), _) | (_, Err(e)) => {
            return fail(format!("compile failed:{}", first_line(&e.rendered)));
        }
    };
    if a.render_core() != b.render_core() {
        return fail(
            "duplicate compile core expression mismatch (cache determinism broken)".to_string(),
        );
    }
    // Static-check surface (the type checker consumes the same front end)
    let first = check_source_recover(FIB10, FNAME);
    let first = match first {
        Ok(r) => r,
        Err(e) => return fail(format!("check failed:{}", first_line(&e.rendered))),
    };
    if !first.diagnostics.is_empty() {
        return fail(format!(
            "static check reports an error {} item",
            first.diagnostics.len()
        ));
    }
    // Cache observation surface (E6: trait face — miss → store → hit)
    let key = cache_key(FIB10, FNAME, CompilerKind::Bootstrap);
    let probe_key = cache_key(FIB10, FNAME, CompilerKind::Bootstrap);
    let (miss, hit) = with_cache(|c| {
        let miss = c.get_cached(&key).is_none();
        c.store(
            key,
            CachedResult {
                program: a.program.clone(),
                core: a.core.clone(),
                code_value: None,
            },
        );
        let hit = c.get_cached(&probe_key).is_some();
        (miss, hit)
    });
    if !miss || !hit {
        return fail(
            "cache trait face observation broken(miss→store→hit sequence failed -- incremental compilation infrastructure unusable)".to_string(),
        );
    }
    pass(
        "duplicate compile core consistent + static check 0 wrong + cache trait face miss→store→hit(content-addressed reuse)"
            .to_string(),
    )
}

// ---------------------------------------------------------------------------
// main: ratio mechanical check + run
// ---------------------------------------------------------------------------

fn main() {
    println!(
        "== kerf Stage 1 gate audit set stage1_gate_audit_r1(sop.md §7.3.1 / §7.1.1 / §7.3.2 / §21.3)=="
    );
    println!(
        "case total {}(A single-statement 12 / B multi-statement 12 / C complex 10 / D recovery 6 / E boundary 6 / P positive 4)\n",
        CASES.len()
    );

    let mut fail_count = 0;
    let mut class_seen = [0usize; 7];
    let mut bucket_counts = [0usize; 6];
    let mut negative = 0;
    let mut positive = 0;
    let mut recovery = 0;

    for c in CASES {
        bucket_counts[c.bucket as usize] += 1;
        match c.polarity {
            Polarity::Negative => negative += 1,
            Polarity::Positive => positive += 1,
            Polarity::Recovery => recovery += 1,
        }
        if let Some(cls) = c.class {
            class_seen[cls.index() - 1] += 1;
        }
        let r = run_case(c);
        let status = if r.pass { "PASS" } else { "FAIL" };
        let class_label = c.class.map(|k| k.label()).unwrap_or("-");
        println!(
            "[{}] {} {} {} {}",
            status,
            c.id,
            c.bucket.label(),
            match c.polarity {
                Polarity::Negative => "negative",
                Polarity::Positive => "positive",
                Polarity::Recovery => "recovery",
            },
            class_label
        );
        println!("      src: {}", short_src(c.src));
        println!("      → {}", r.detail);
        if !r.pass {
            fail_count += 1;
        }
    }

    // Summary + §7.3.1/§7.3.2 ratio mechanical check
    let total = CASES.len();
    let passed = total - fail_count;
    println!("\n== summary ==");
    println!("total {} / PASS {} / FAIL {}", total, passed, fail_count);
    println!(
        "bucket ratio(§7.3.1): single-statement {}/10 multi-statement {}/10 complex {}/5 recovery {}/5; boundary {}/5(§7.3.2); positive {}/8(limit)",
        bucket_counts[0],
        bucket_counts[1],
        bucket_counts[2],
        bucket_counts[3],
        bucket_counts[4],
        bucket_counts[5]
    );
    println!(
        "polarity: negative {}(≥22)/ recovery {} / positive {}",
        negative, recovery, positive
    );
    print!("§7.1.1 seven-class coverage:");
    for (i, n) in class_seen.iter().enumerate() {
        print!(" {}={}", i + 1, n);
    }
    println!();

    let mut ratio_fail = false;
    if bucket_counts[0] < 10 {
        println!("ratio violation: A bucket {} < 10", bucket_counts[0]);
        ratio_fail = true;
    }
    if bucket_counts[1] < 10 {
        println!("ratio violation: B bucket {} < 10", bucket_counts[1]);
        ratio_fail = true;
    }
    if bucket_counts[2] < 5 {
        println!("ratio violation: C bucket {} < 5", bucket_counts[2]);
        ratio_fail = true;
    }
    if bucket_counts[3] < 5 {
        println!("ratio violation: D bucket {} < 5", bucket_counts[3]);
        ratio_fail = true;
    }
    if bucket_counts[4] < 5 {
        println!(
            "ratio violation (§7.3.2): E boundary bucket {} < 5",
            bucket_counts[4]
        );
        ratio_fail = true;
    }
    if negative < 22 {
        println!("ratio violation: negative {} < 22", negative);
        ratio_fail = true;
    }
    for (i, n) in class_seen.iter().enumerate() {
        if *n == 0 {
            println!("ratio violation:§7.1.1 # {} class zero coverage", i + 1);
            ratio_fail = true;
        }
    }

    if fail_count > 0 || ratio_fail {
        println!(
            "\n conclusion: NEEDS REVISION(FAIL {} / ratio violation {})",
            fail_count, ratio_fail
        );
        std::process::exit(1);
    }
    println!(
        "\n conclusion: APPROVED(audit approved -- all seven classes covered + ratio satisfied + boundary ≥5 + zero findings)"
    );
    println!();
    println!("== §21.3 four-condition anchoring ==");
    println!(
        "condition 1(subset-expressing frontend): production pipeline bootstrapped(VM Reader + VM Expander containing macro) -- this audit all body case via production path"
    );
    println!(
        "condition 2(Stage 0 VM runs correctly): bootstrap Expander at VM above carries all production expansion(containing macro/module/prelude)"
    );
    println!(
        "condition 3(standard library minimal set): P02 prelude pipeline(list hofs use user face)+ stdlib_tests(list/string/I/O)"
    );
    println!(
        "condition 4(incremental compilation infrastructure): P04 cache determinism + static check 0 wrong + cache trait face miss→store→hit(cache_tests content addressing/invalidated face)"
    );
}

#!/usr/bin/env python3
"""r158 toplevel-let applier: define(NAME, e); → let NAME = e;

Usage:
  python3 apply.py --dry   # report only (per-file counts)
  python3 apply.py         # rewrite files in place

Architecture (toplevel-let-design.md D4):

  1. For .rs / .ts host files: extract string literals first (the embedded
     kerf sources live inside host strings); transform each string's
     CONTENT as kerf source; host code outside strings is untouched.
     Host // comments are skipped so quoted text inside comments cannot
     desynchronize the string extractor.
  2. For .ktf files: transform the whole text as kerf source.
  3. Kerf-source transform: parenthesis matching for the define call form
     (string- and comment-aware), gated by an item-position test:
       a brace-stack scanner (comment- and string-aware) tracks unclosed
       '{' openers, classified at push time by looking BACKWARD from the
       '{':
           module NAME {      → 'module'  → module item → MIGRATE
           fn NAME(params) {  → 'fn'      → function body → SKIP
           anything else {    → 'block'   → SKIP
         stack empty at the occurrence → top level → MIGRATE
       (define inside function/plain blocks is the expander's
       define-position rejection domain — unchanged by this window.)

  define(NAME, VALUE);  →  let NAME = VALUE;

  Unmatchable occurrences (truncated error-case fixtures, no closing
  paren) are skipped and counted for manual review.

Domains:
  - crates/** (bootstrap .ktf + .rs, embedded sources)
  - tests/**/*.rs, examples/**/*.ktf + examples/audit/*.rs
  - /home/z/my-project/src/lib/kerf-data.ts (web presets)

Excluded: *.krf (S-expr face — (define x e) native, zero call forms),
docs/ (228-d governance), scripts/archive (historical),
crates/kerf-reader/src/reader.rs (this window's own annotations).
"""
import re, os, sys

ROOT = "/home/z/my-project/kerf"
WEB = "/home/z/my-project/src/lib/kerf-data.ts"
EXCLUDE_FILES = {os.path.join(ROOT, "crates/kerf-reader/src/reader.rs")}

IDENT = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
WS = " \t\r\n"


def kerf_skip_comment(text, i):
    """i points at '/'; return index after the comment (or i if not one)."""
    if i + 1 < len(text):
        if text[i + 1] == "/":
            j = text.find("\n", i)
            return len(text) if j < 0 else j
        if text[i + 1] == "*":
            j = text.find("*/", i + 2)
            return len(text) if j < 0 else j + 2
    return i


def skip_string(text, i):
    """i points at '\"'; return index just past the closing quote."""
    n = len(text)
    p = i + 1
    while p < n:
        if text[p] == "\\":
            p += 2
            continue
        if text[p] == '"':
            return p + 1
        p += 1
    return n


def kerf_find_matching_paren(text, open_idx):
    """Paren matcher from '(' at open_idx; kerf-string/comment-aware."""
    depth = 1
    p = open_idx + 1
    n = len(text)
    while p < n:
        c = text[p]
        if c == "/":
            j = kerf_skip_comment(text, p)
            if j > p:
                p = j
                continue
        if c == '"':
            p = skip_string(text, p)
            continue
        if c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
            if depth == 0:
                return p
        p += 1
    return -1


def _word_ending_at(text, j):
    """Read the identifier ending at index j; returns (word, start).

    A backslash-escaped char (e.g. the 'n' of a \\n escape inside a host
    string literal) is a word boundary: it neither belongs to the word
    nor glues onto it (the 'nmodule' misparse)."""
    e = j
    while j >= 0 and (text[j].isalnum() or text[j] == "_"):
        if j > 0 and text[j - 1] == "\\":
            break  # the char at j is backslash-escaped — not a word char
        j -= 1
    return text[j + 1 : e + 1], j


def classify_opener(text, brace_idx):
    """Classify the '{' at brace_idx by its backward context."""
    j = brace_idx - 1
    while j >= 0 and text[j] in WS:
        j -= 1
    if j < 0:
        return "block"
    if text[j].isalnum() or text[j] == "_":
        # module NAME {  → the word before the trailing identifier
        word_after, j2 = _word_ending_at(text, j)
        while j2 >= 0 and text[j2] in WS:
            j2 -= 1
        if j2 < 0:
            return "block"
        prev_word, _ = _word_ending_at(text, j2)
        if prev_word == "module":
            return "module"
        return "block"
    if text[j] == ")":
        # fn NAME(params) { — match the '(' backward, then NAME, then 'fn'
        depth = 1
        k = j - 1
        while k >= 0 and depth > 0:
            if text[k] == ")":
                depth += 1
            elif text[k] == "(":
                depth -= 1
            k -= 1
        while k >= 0 and text[k] in WS:
            k -= 1
        if k < 0:
            return "block"
        _name, k2 = _word_ending_at(text, k)
        while k2 >= 0 and text[k2] in WS:
            k2 -= 1
        if k2 < 0:
            return "block"
        kw, _ = _word_ending_at(text, k2)
        if kw == "fn":
            return "fn"
        return "block"
    return "block"


def kerf_item_context(text, i):
    """Item-position test for a define( at i (kerf source text).

    True = top level or module item context, and NOT inside any
    unclosed '(' (expression position); False = function/plain-block
    context, or nested inside a call/paren expression (the expander's
    rejection domain — skip)."""
    stack = []
    paren_depth = 0
    n = len(text)
    p = 0
    while p < i:
        c = text[p]
        if c == "/":
            j = kerf_skip_comment(text, p)
            if j > p:
                p = j
                continue
        if c == '"':
            p = skip_string(text, p)
            continue
        if c == "{":
            stack.append(classify_opener(text, p))
            p += 1
            continue
        if c == "}":
            if stack:
                stack.pop()
            p += 1
            continue
        if c == "(":
            paren_depth += 1
        elif c == ")":
            if paren_depth > 0:
                paren_depth -= 1
        p += 1
    if paren_depth > 0:
        return False
    if not stack:
        return True
    return stack[-1] == "module"


HOST_ESCAPES = {"n": "\n", "t": "\t", "r": "\r", "0": "\0", '"': '"', "'": "'", "\\": "\\"}


def decode_host(lit):
    """Decode Rust/TS escape sequences to the string VALUE (the embedded
    kerf source as the compiler sees it)."""
    out = []
    i = 0
    n = len(lit)
    while i < n:
        c = lit[i]
        if c == "\\" and i + 1 < n and lit[i + 1] in HOST_ESCAPES:
            out.append(HOST_ESCAPES[lit[i + 1]])
            i += 2
            continue
        out.append(c)
        i += 1
    return "".join(out)


def encode_host(s, quote):
    """Re-encode with the canonical style: \\ and the quote escaped, LF as
    \\n, TAB as \\t (the corpus's dominant style — byte-stable roundtrip
    for strings that already use it)."""
    out = []
    for ch in s:
        if ch == "\\":
            out.append("\\\\")
        elif ch == quote:
            out.append("\\" + quote)
        elif ch == "\n":
            out.append("\\n")
        elif ch == "\t":
            out.append("\\t")
        else:
            out.append(ch)
    return "".join(out)


def transform_kerf(text, add_semi=False):
    """Transform define(...) call forms in kerf source text.

    add_semi: when the form's trailing ';' is absent (the old call
    form's optional-semicolon artifact — expression items could omit
    it; host-embedded sources like "let my_print = print" carry the
    artifact), append one (the let production requires it).

    Returns (new_text, count, skipped_unmatched)."""
    out = []
    i = 0
    n = len(text)
    count = 0
    skip_unmatched = 0
    while i < n:
        if text.startswith("define(", i):
            esc = i >= 2 and text[i - 1] in "nt" and text[i - 2] == "\\"
            prev_ok = esc or i == 0 or not (
                text[i - 1].isalnum() or text[i - 1] in "_"
            )
            if prev_ok and kerf_item_context(text, i):
                m = IDENT.match(text, i + len("define("))
                if m:
                    k = m.end()
                    while k < n and text[k] in " \t\n":
                        k += 1
                    if k < n and text[k] == ",":
                        close = kerf_find_matching_paren(text, i + 6)
                        if close > k:
                            value = text[k + 1 : close]
                            if "\n" in value:
                                repl = "let " + m.group(0) + " =" + value
                            else:
                                repl = "let " + m.group(0) + " = " + value.strip()
                            # semicolon presence: the let production requires
                            # ';' — append when the old form omitted it (the
                            # optional-semicolon expression-item artifact)
                            q = close + 1
                            while q < n and text[q] in " \t":
                                q += 1
                            if add_semi and (q >= n or text[q] in "\n\r"):
                                repl += ";"
                            out.append(repl)
                            i = close + 1
                            count += 1
                            continue
                        skip_unmatched += 1
                        out.append(text[i : i + 7])
                        i += 7
                        continue
        out.append(text[i])
        i += 1
    return "".join(out), count, skip_unmatched


def transform_host(text, backticks=False):
    """Transform string literals' contents in a Rust/TS host file.

    Double-quoted literals are decoded (escape sequences → value),
    transformed as kerf source, and re-encoded canonically when changed;
    unchanged literals keep their original bytes. With backticks=True
    (TS), backtick template literals are processed raw (real newlines,
    no host escaping beyond \\` and ${ which do not occur in the presets).
    Rust char literals ('x', '\\n') are skipped so quotes inside them
    cannot desynchronize the extractor."""
    out = []
    i = 0
    n = len(text)
    count = 0
    skipped = 0
    while i < n:
        c = text[i]
        if c == "/" and i + 1 < n and text[i + 1] == "/":
            j = text.find("\n", i)
            j = n if j < 0 else j
            out.append(text[i:j])
            i = j
            continue
        if c == "'" and not backticks:
            # Rust char literal: 'x' | '\\n' | '\\'' | '\\\\'
            if i + 3 < n and text[i + 1] == "\\":
                out.append(text[i : i + 4])
                i += 4
                continue
            if i + 2 < n and text[i + 2] == "'":
                out.append(text[i : i + 3])
                i += 3
                continue
            out.append(c)
            i += 1
            continue
        if c == '"':
            j = skip_string(text, i)
            lit = text[i + 1 : j - 1] if j > i + 1 else ""
            if lit:
                decoded = decode_host(lit)
                new_decoded, cnt, sk = transform_kerf(decoded, add_semi=True)
                count += cnt
                skipped += sk
                if cnt:
                    out.append('"' + encode_host(new_decoded, '"') + '"')
                    i = j
                    continue
            out.append(text[i:j])
            i = j
            continue
        if c == "`" and backticks:
            j = text.find("`", i + 1)
            j = n if j < 0 else j
            lit = text[i + 1 : j]
            new_lit, cnt, sk = transform_kerf(lit, add_semi=True)
            count += cnt
            skipped += sk
            if cnt:
                out.append("`" + new_lit + "`")
                i = j + 1
                continue
            out.append(text[i : j + 1])
            i = j + 1
            continue
        out.append(c)
        i += 1
    return "".join(out), count, skipped


def main():
    dry = "--dry" in sys.argv
    targets = []
    for base in ("crates", "tests", "examples"):
        for dirpath, dirnames, filenames in os.walk(os.path.join(ROOT, base)):
            dirnames[:] = [d for d in dirnames if d != "target"]
            for f in filenames:
                if f.endswith((".ktf", ".rs")):
                    targets.append(os.path.join(dirpath, f))
    targets.append(WEB)
    total = 0
    total_skipped = 0
    for path in targets:
        if not os.path.exists(path) or path in EXCLUDE_FILES:
            continue
        text = open(path, encoding="utf-8").read()
        if path.endswith(".ktf"):
            new_text, count, skipped = transform_kerf(text)
        elif path.endswith(".ts"):
            new_text, count, skipped = transform_host(text, backticks=True)
        else:
            new_text, count, skipped = transform_host(text)
        if count or skipped:
            rel = os.path.relpath(path, ROOT) if path.startswith(ROOT) else path
            print(f"{rel}: {count} transformed, {skipped} unmatched-skipped")
        total += count
        total_skipped += skipped
        if not dry and count:
            open(path, "w", encoding="utf-8").write(new_text)
    print(f"TOTAL: {total} transformed, {total_skipped} unmatched-skipped (manual review)")


if __name__ == "__main__":
    main()

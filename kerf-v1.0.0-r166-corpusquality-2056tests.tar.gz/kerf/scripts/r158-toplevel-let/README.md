# r158-toplevel-let migration tooling

The define(NAME, e) → let NAME = e; surface migration (r158 / 228-c,
toplevel-let-design.md D4). Two passes, both idempotent (re-running on
a fully migrated tree reports zero):

## apply.py — the structural pass

`define(NAME, VALUE);` → `let NAME = VALUE;` — parenthesis matching
(string- and comment-aware), gated by an item-position test:

- a brace-stack scanner classifies the innermost unclosed `{` by its
  backward context: `module NAME {` → module item (migrate), `fn
  NAME(params) {` → function body (skip), anything else → plain block
  (skip); stack empty → top level (migrate)
- paren depth > 0 at the occurrence → expression position (skip)
- host strings are extracted first (Rust `//` comments skipped, char
  literals skipped); double-quoted literals are decoded (escape
  sequences → value) before the kerf-source scan and canonically
  re-encoded when changed — unchanged literals keep their bytes
- backtick template literals (TS presets) processed raw with
  `add_semi` (the old expression-item's optional-semicolon artifact)
- `\n` escape boundaries are word boundaries in the backward classifier
  (the 'nmodule' misparse guard)

Known limitation (recorded): Rust raw strings `r#"..."#` whose content
contains bare `"` are fragmented by the string extractor — their define
forms were completed manually (the ktf_tc_sigs_parity_tests precedent:
both the corrupted semi-insertions reverted and the alt-block defines
migrated by hand).

## semipass.py — the semicolon completion pass

The first pass's add_semi checked only real newline chars; host
literals where the statement separator is the two-char `\n` escape
kept the optional-semicolon artifact. This pass scans `let NAME =
VALUE` statements in host literals (paren-depth, brace-pairing, and
escaped-quote aware; a Rust format placeholder's `{}` braces pair up
and never bound; `}` at pairing depth zero = the enclosing module
block's close) and appends `;` at the boundary when missing.

Raw strings are skipped verbatim (r"..." / r#"..."# guards — the
close-position arithmetic matters: the literal ends AT the closing
quote, so the skip lands after it, not on it).

Both passes: `python3 apply.py --dry` / `python3 semipass.py --dry`
report; without `--dry` they rewrite in place.

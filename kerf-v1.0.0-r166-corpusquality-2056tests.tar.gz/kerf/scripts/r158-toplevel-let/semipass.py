#!/usr/bin/env python3
"""r158 second pass: semicolon completion for migrated top-level lets.

The first pass migrated define(NAME, e) → let NAME = e but the optional-
semicolon artifact (expression items could omit ';') survives in host
string literals where the statement separator is the TWO-CHAR escape
sequence \\n — the first pass's add_semi checked only real newline chars.

This pass scans host string literals for `let NAME = VALUE` statements
(paren-depth aware: a \\n inside the value's parens is a multi-line value,
not a boundary) and appends ';' before the statement boundary (\\n escape
at depth 0, the closing quote, or '}') when missing.

Usage:
  python3 semipass.py --dry   # report only
  python3 semipass.py         # rewrite in place
"""
import os, sys

ROOT = "/home/z/my-project/kerf"
WEB = "/home/z/my-project/src/lib/kerf-data.ts"
EXCLUDE_FILES = {os.path.join(ROOT, "crates/kerf-reader/src/reader.rs")}

IDENT = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_"


def skip_string(text, i):
    n = len(text)
    p = i + 1
    while p < n:
        if text[p] == "\\":
            p += 2
            continue
        if text[p] == '"':
            return p + 1
        p += 1
    return n


def fix_let_semis(lit):
    """Insert missing ';' after top-level let statements in a host string
    literal's RAW content (\\n = two-char escape). Returns (new, count)."""
    out = []
    i = 0
    n = len(lit)
    count = 0
    while i < n:
        if lit.startswith("let ", i):
            # identifier
            j = i + 4
            s = j
            while j < n and lit[j] in IDENT:
                j += 1
            if j > s and j < n and lit[j] in " \t":
                while j < n and lit[j] in " \t":
                    j += 1
                if lit.startswith("= ", j) or (j < n and lit[j] == "="):
                    j += 1
                    while j < n and lit[j] in " \t":
                        j += 1
                    # scan the value: paren-depth + escaped-quote aware;
                    # brace pairing: '{' opens a counted block (a Rust
                    # format placeholder's braces pair up and never bound),
                    # a '}' at pairing depth zero is the statement's
                    # enclosing-block close (module m { let x = 1 })
                    depth = 0
                    brace = 0
                    k = j
                    end = -1  # insert position
                    while k < n:
                        c = lit[k]
                        if c == "\\":
                            nxt = lit[k + 1] if k + 1 < n else ""
                            if nxt == '"':
                                # escaped quote: skip the pair
                                k += 2
                                continue
                            if depth == 0 and nxt in "nr":
                                end = k  # statement boundary before \n escape
                                break
                            k += 2
                            continue
                        if c == '"':
                            # a bare quote at this level inside a raw host
                            # literal cannot occur (host quotes are escaped);
                            # treat as boundary safety
                            end = k
                            break
                        if c == "(":
                            depth += 1
                        elif c == ")":
                            depth -= 1
                        elif c == "{":
                            brace += 1
                        elif c == "}":
                            if brace > 0:
                                brace -= 1  # a paired block/placeholder close
                            elif depth == 0:
                                end = k  # the enclosing block's close
                                break
                        elif depth == 0 and brace == 0 and c == ";":
                            end = -2  # already terminated
                            break
                        k += 1
                    if end >= 0:
                        # check the char just before the boundary is not ';'
                        if lit[end - 1] != ";":
                            out.append(lit[i:end] + ";")
                            i = end
                            count += 1
                            continue
                    elif end == -1:
                        # ran to the literal's end without a terminator
                        if lit[n - 1] != ";":
                            out.append(lit[i:n] + ";")
                            i = n
                            count += 1
                            continue
        out.append(lit[i])
        i += 1
    return "".join(out), count


def transform_host(text):
    out = []
    i = 0
    n = len(text)
    count = 0
    while i < n:
        c = text[i]
        if c == "/" and i + 1 < n and text[i + 1] == "/":
            j = text.find("\n", i)
            j = n if j < 0 else j
            out.append(text[i:j])
            i = j
            continue
        # Rust raw string r"..." / r#"..."# / r##"..."## — the content may
        # contain bare '"' (kerf string literals inside embedded sources);
        # skip the whole raw literal verbatim (the first-pass artifacts in
        # raw strings are completed manually — see the tc_sigs precedent)
        if c == "r" and text[i + 1 : i + 2] == '"':
            j = text.find('"', i + 2)
            j = n if j < 0 else j
            out.append(text[i : j + 1])
            i = j + 1
            continue
        if c == "r" and text[i + 1 : i + 3] == '#"':
            j = text.find('"#', i + 3)
            j = n if j < 0 else j
            out.append(text[i : j + 2])
            i = j + 2
            continue
        if c == "'" and i + 2 < n and text[i + 2] == "'":
            out.append(text[i : i + 3])
            i += 3
            continue
        if c == "'":
            if i + 3 < n and text[i + 1] == "\\":
                out.append(text[i : i + 4])
                i += 4
                continue
        if c == '"':
            j = skip_string(text, i)
            lit = text[i + 1 : j - 1] if j > i + 1 else ""
            if lit and "let " in lit:
                new_lit, cnt = fix_let_semis(lit)
                count += cnt
                if cnt:
                    out.append('"' + new_lit + '"')
                    i = j
                    continue
            out.append(text[i:j])
            i = j
            continue
        if c == "`":
            j = text.find("`", i + 1)
            j = n if j < 0 else j
            lit = text[i + 1 : j]
            if lit and "let " in lit:
                new_lit, cnt = fix_let_semis(lit)
                count += cnt
                if cnt:
                    out.append("`" + new_lit + "`")
                    i = j + 1
                    continue
            out.append(text[i : j + 1])
            i = j + 1
            continue
        out.append(c)
        i += 1
    return "".join(out), count


def main():
    dry = "--dry" in sys.argv
    targets = []
    for base in ("crates", "tests", "examples"):
        for dirpath, dirnames, filenames in os.walk(os.path.join(ROOT, base)):
            dirnames[:] = [d for d in dirnames if d != "target"]
            for f in filenames:
                if f.endswith((".ktf", ".rs")):
                    targets.append(os.path.join(dirpath, f))
    targets.append(WEB)
    total = 0
    for path in targets:
        if not os.path.exists(path) or path in EXCLUDE_FILES:
            continue
        text = open(path, encoding="utf-8").read()
        if path.endswith(".ktf"):
            # real newlines — the first pass handled these; skip
            continue
        new_text, count = transform_host(text)
        if count:
            rel = os.path.relpath(path, ROOT) if path.startswith(ROOT) else path
            print(f"{rel}: {count} semicolons completed")
        total += count
        if not dry and count:
            open(path, "w", encoding="utf-8").write(new_text)
    print(f"TOTAL: {total} semicolons completed")


if __name__ == "__main__":
    main()

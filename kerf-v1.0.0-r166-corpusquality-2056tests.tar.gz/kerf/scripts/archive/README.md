# 历史脚本归档（scripts/archive/）

> **Author**: kerf-dev-agent（Super Z main — ARCH-A；r100 / 170-a 结构整理轮）
> **Date**: 2026-10-21（r100）
> **Version**: v1.0.0
> **Status**: Active（归档区——只进不出：新归档追加，已归档不删除）

## 用途

承载**已完成使命的一次性历史脚本**（迁移/清算/机械修正类）。与 `scripts/<工具域>/setup.sh`
（常驻环境脚本——sop.md §3.4 目录约定）分立：`scripts/` 根下仅允许
`<sub_dirname>/` 形态的常驻脚本目录与本归档目录。

## 归档清单

| 脚本 | 归档时间 | 原位置 | 历史用途 |
|---|---|---|---|
| `s1_migrate_names.py` | r100（2026-10-21） | `scripts/s1_migrate_names.py` | r42 / 63-b S1 表面腿——27 旧名 → 现代名机械迁移（词法边界感知；E5 窗 v1.0.0 一次性清算工具，使命完成） |

## 约定

- 归档脚本**不再维护**（历史正确性以当时轮次 worklog 详录为准——见 flat worklog r42/63-b 条目）；
- 新的一次性脚本在使命完成后**必须**移入本目录并在上表登记（防 scripts/ 根再散置——r100 整理轮立约）。

#!/usr/bin/env python3
"""r42 / 63-b S1 表面腿——27 旧名 → 现代名机械迁移（词法边界感知）。

设计依据：
- 20-表面规范 §7 移除轮行（旧名 27 件移除 → E0021 + 全语料现代名终态）
- 23 §3.4 生命周期（弃用期跨版本核对后移除合法）
- e5-removal-round-plan.md §3.2 S1 行（行为 parity：r38 已证同分派体同诊断）

边界语义：kerf 标识符字符 = [A-Za-z0-9_?!<>=/+-]。替换仅在名字两侧
均非标识符字符时发生（防 `scar`/`str->pos-chars` 类误命中）。
"""
import re
import sys
from pathlib import Path

# 27-pair mapping (single source = 20 §8 / builtins.rs BUILTIN_ALIASES)
PAIRS = [
    ("car", "head"), ("cdr", "tail"),
    ("list-ref", "nth"), ("list-tail", "drop"),
    ("null?", "is-nil"), ("pair?", "is-pair"),
    ("int?", "is-int"), ("bool?", "is-bool"),
    ("procedure?", "is-procedure"), ("string?", "is-string"),
    ("symbol?", "is-symbol"), ("float?", "is-float"),
    ("number?", "is-number"), ("list?", "is-list"),
    ("eq?", "eq"),
    ("str-append", "string-append"), ("str-length", "string-length"),
    ("str-substring", "string-substring"), ("str-index-of", "string-index-of"),
    ("str-contains?", "string-contains"), ("str-prefix?", "string-starts-with"),
    ("str-suffix?", "string-ends-with"),
    ("str-upcase", "string-to-upper"), ("str-downcase", "string-to-lower"),
    ("string->symbol", "string-to-symbol"), ("symbol->string", "symbol-to-string"),
    ("assert-eq?", "assert-eq"),
]

IDENT_CHARS = r"A-Za-z0-9_?!<>=/+\-"

def build_pattern(name: str) -> re.Pattern:
    # Neither side of the name is a kerf identifier character (lexical
    # boundary)
    return re.compile(rf"(?<![{IDENT_CHARS}]){re.escape(name)}(?![{IDENT_CHARS}])")

def migrate_text(text: str, skip_predicate=None) -> tuple[str, int]:
    """skip_predicate(line, idx) → True 则该行跳过（保护区）。"""
    total = 0
    out_lines = []
    for idx, line in enumerate(text.split("\n")):
        if skip_predicate and skip_predicate(line, idx):
            out_lines.append(line)
            continue
        new_line = line
        for old, new in PAIRS:
            new_line, n = build_pattern(old).subn(new, new_line)
            total += n
        out_lines.append(new_line)
    return "\n".join(out_lines), total

def main():
    root = Path("/home/z/my-project/kerf")
    # File list (the builtins.rs protected region is determined by line
    # number: the defs region = before the alias-mechanism comment block)
    targets = {
        "full": [
            root / "crates/kerf-compiler/src/hm.rs",
            root / "crates/kerf-backend/src/anf.rs",
            root / "crates/kerf-driver/src/bootstrap/compiler.krf",
            root / "crates/kerf-driver/src/bootstrap/expander.krf",
            root / "crates/kerf-driver/src/bootstrap/reader.krf",
            root / "crates/kerf-driver/src/bootstrap/preamble.krf",
            root / "examples/usage/io.krf",
            root / "examples/README.md",
        ]
        + sorted((root / "tests").rglob("*.rs"))
        + sorted((root / "examples/audit").rglob("*.rs"))
        + sorted((root / "examples/usage").glob("*.krf")),
    }
    # builtins.rs: only the defs region (before the line where the alias
    # registration block comment starts) — the tables and SIGS are
    # handled by MultiEdit surgery (protected region: the REMOVED table's
    # first column carries the old names)
    builtins = root / "crates/kerf-driver/src/builtins.rs"
    builtins_text = builtins.read_text(encoding="utf-8")
    cutoff = builtins_text.index("    // ------------------------------------------------------------------\n    // 批次 L（v0.5 别名层，r38）")
    head_part, tail_part = builtins_text[:cutoff], builtins_text[cutoff:]

    head_new, n_head = migrate_text(head_part)
    # Tail region (alias mechanism + tables + SIGS + io/module
    # registration sections + tests): the test region and the
    # STDLIB_MODULES low-level names need migration, but the
    # BUILTIN_ALIASES table (to be replaced wholesale with the REMOVED
    # table) and the old SIGS entries (to be deleted) are skipped as a
    # protected region. Strategy: after full replacement of the tail
    # region, MultiEdit rewrites the two tables with the final-state text
    # (the mangled text serving as the old_str anchor). Protected region
    # = after the io registration section (to avoid mis-replacing the
    # table region) — changed to: first surgery on the two tables +
    # STDLIB_MODULES, then full replacement of the remaining tail region
    # (the test region). This script handles only the head region; the
    # two tail-region tables get surgery first (MultiEdit), then this
    # script is run a second time with --phase2 to handle the tail test
    # section.
    if "--phase2" in sys.argv:
        # Tail region: only after the STDLIB_MODULES registration section
        # (= the test region + the module-signature derivation section
        # contains no old names — old names actually live only in the test
        # region); protected region = the BUILTIN_ALIASES/REMOVED table and
        # SIGS (already surgically brought to final state: the REMOVED
        # table's old-name column must be kept). In the post-surgery text
        # the REMOVED table starts at
        # "pub static REMOVED_BUILTIN_NAMES" and ends at "];" — the
        # protected region is decided by these markers.
        protected = False
        out_lines = []
        n_tail = 0
        for line in tail_part.split("\n"):
            if "pub static REMOVED_BUILTIN_NAMES" in line:
                protected = True
            if protected and line.strip() == "];" and "REMOVED" not in line:
                protected = False
                out_lines.append(line)
                continue
            if protected:
                out_lines.append(line)
                continue
            new_line = line
            for old, new in PAIRS:
                new_line, n = build_pattern(old).subn(new, new_line)
                n_tail += n
            out_lines.append(new_line)
        tail_new = "\n".join(out_lines)
        builtins.write_text(head_new + tail_new, encoding="utf-8")
        print(f"builtins.rs phase2: {n_head}+{n_tail} replacements")
        return
    builtins.write_text(head_new + tail_part, encoding="utf-8")
    print(f"builtins.rs phase1 (defs 区): {n_head} replacements")

    for f in targets["full"]:
        text = f.read_text(encoding="utf-8")
        new_text, n = migrate_text(text)
        if n:
            f.write_text(new_text, encoding="utf-8")
        print(f"{f.relative_to(root)}: {n} replacements")

if __name__ == "__main__":
    main()

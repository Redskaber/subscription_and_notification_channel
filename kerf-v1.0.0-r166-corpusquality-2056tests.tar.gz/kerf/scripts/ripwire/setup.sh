#!/bin/sh
# kerf/scripts/ripwire/setup.sh — ripwire agent-assist tool install/verify
# script (sop.md §3.1)
#
# Purpose: install/verify ripwire (an agent repo-navigation / blast-radius
#       analysis CLI — "The ripgrep of AI context"; redhat-et/ripwire,
#       Apache 2.0, C++23 single binary, zero runtime dependencies)
# Usage: sh scripts/ripwire/setup.sh
# Verify: ripwire --version (output looks like `ripwire 0.6.0 (Release, ...)`)
#
# Notes:
# - Positioning: an agent-assist development-workflow tool (repo-directed
#   graph / caller queries / blast radius / tests-to-run) — a host-side
#   tool that never enters Cargo dependencies, the language pipeline, or
#   the bootstrap chain (not listed in the §18.4 external-dependency
#   table — same category as ripgrep; principle 44 is unaffected: the
#   .krf syntax surface's single source is still subject to the symbol.rs
#   dual-source reconciliation)
# - Install target: $HOME/.local/bin/ripwire (the official default
#   location)
# - The official one-liner (RIPWIRE_REPO=redhat-et/ripwire bash -c "$(curl
#   -fsSL https://raw.githubusercontent.com/redhat-et/ripwire/main/scripts/install.sh)")
#   gets a 403 under API rate limiting (api.github.com/releases/latest) —
#   this script goes directly via the release tar.gz link (the path
#   verified in r86)
# - On failure, exit with a non-zero code (§3.1 rule: no silent skipping)

set -e

BIN="$HOME/.local/bin/ripwire"
VERSION="0.6.0"
ARCH="linux-x64"
URL="https://github.com/redhat-et/ripwire/releases/download/v${VERSION}/ripwire-${VERSION}-${ARCH}.tar.gz"

echo "[kerf] check ripwire..."
if [ -x "$BIN" ]; then
    echo "[kerf] already then position: $BIN"
    "$BIN" --version
    exit 0
fi

echo "[kerf] downloading ripwire v${VERSION} (${ARCH})..."
WORK=$(mktemp -d)
if command -v curl >/dev/null 2>&1; then
    curl -fsSL -o "$WORK/ripwire.tar.gz" "$URL"
elif command -v wget >/dev/null 2>&1; then
    wget -q -O "$WORK/ripwire.tar.gz" "$URL"
else
    echo "[kerf] error: requires curl or wget"
    exit 1
fi

echo "[kerf] unpacking and installing to $BIN..."
tar -xzf "$WORK/ripwire.tar.gz" -C "$WORK"
mkdir -p "$HOME/.local/bin"
cp "$WORK/ripwire-${VERSION}-${ARCH}/ripwire" "$BIN"
chmod +x "$BIN"
rm -rf "$WORK"

echo "[kerf] installation completed(use method hint: export PATH=\"\$HOME/.local/bin:\$PATH\")"
"$BIN" --version

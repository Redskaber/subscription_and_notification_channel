#!/bin/sh
# kerf/scripts/qbe/setup.sh — QBE backend toolchain install script (sop.md §3.1)
#
# Purpose: install/verify the QBE binary required by Stage 2 batch G
# (QBE backend PoC)
# Usage: sh scripts/qbe/setup.sh
# Verify: tools/qbe/bin/qbe -h (exists and is executable)
#
# Notes:
# - Prefer the in-repo binary (tools/qbe/bin/qbe, amd64_sysv)
# - If missing, rebuild from the source archive (tools/qbe/qbe-1.3.tar.xz,
#   C99 + cc, no external dependencies)
# - On failure, exit with a non-zero code (§3.1 rule: no silent skipping)
# - QBE never enters the bootstrap chain (§21.2) — host-side subprocess
#   invocation only

set -e

BIN="tools/qbe/bin/qbe"

echo "[kerf] checking QBE binary..."
if [ -x "$BIN" ]; then
    echo "[kerf] already then position: $BIN"
    "$BIN" -h 2>&1 | head -1 || true
    exit 0
fi

echo "[kerf] binary missing, rebuilding from the source archive..."
if [ ! -f tools/qbe/qbe-1.3.tar.xz ]; then
    echo "[kerf] error: source archive missing (tools/qbe/qbe-1.3.tar.xz)"
    exit 1
fi

WORK=$(mktemp -d)
tar -xJf tools/qbe/qbe-1.3.tar.xz -C "$WORK"
( cd "$WORK/qbe-1.3" && make -j4 )
mkdir -p tools/qbe/bin
cp "$WORK/qbe-1.3/qbe" "$BIN"
rm -rf "$WORK"

echo "[kerf] rebuild complete: $BIN"
"$BIN" -h 2>&1 | head -1

#!/bin/sh
# kerf/scripts/rust/setup.sh — Rust toolchain install script (sop.md §3.1
# environment tool check & preparation)
#
# Purpose: install the Rust toolchain required by Stage 0 (rustc + cargo
# + rustfmt + clippy)
# Usage: sh scripts/rust/setup.sh
# Verify: rustc --version && cargo --version && cargo fmt --version && cargo clippy --version
#
# Notes:
# - Uses the official rustup install script (https://sh.rustup.rs), stable
#   toolchain + minimal profile
# - rustfmt / clippy are installed as components alongside the toolchain
# - Stage 0 does not adopt LLVM/QBE (§21.2 backend policy: self-built
#   bytecode VM)
# - On install failure, no silent skipping (§3.1 rule): print the error
#   and exit with a non-zero code

set -e

echo "[kerf] checking the existing Rust toolchain..."
if command -v rustc >/dev/null 2>&1 && command -v cargo >/dev/null 2>&1; then
    echo "[kerf] already installation: $(rustc --version) / $(cargo --version)"
    MISSING=""
    command -v rustfmt >/dev/null 2>&1 || MISSING="$MISSING rustfmt"
    command -v cargo-clippy >/dev/null 2>&1 || MISSING="$MISSING clippy"
    if [ -z "$MISSING" ]; then
        echo "[kerf] rustfmt and clippy components present, nothing to install."
        exit 0
    fi
    echo "[kerf] installing missing components: $MISSING"
    rustup component add $MISSING
    exit 0
fi

echo "[kerf] Rust not detected, installing (rustup stable + minimal profile)..."
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs -o /tmp/rustup-init.sh
sh /tmp/rustup-init.sh -y --default-toolchain stable --profile minimal --component rustfmt,clippy

# source the environment variables (current shell)
. "$HOME/.cargo/env" 2>/dev/null || export PATH="$HOME/.cargo/bin:$PATH"

echo "[kerf] verify installation..."
rustc --version
cargo --version
cargo fmt --version
cargo clippy --version
echo "[kerf] Rust toolchain installation completed."

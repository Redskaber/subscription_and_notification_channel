#!/usr/bin/env python3
"""r139 pass 2: multi-line Rust string continuations (\\<newline> form).
The single-line pass skipped these; here we join fragments, translate via
the same dictionary (pure function preserved), and rewrite as one line."""
import re, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import apply as A  # reuse translate machinery (SEG, WHOLE, EXEMPT, etc.)

ROOT = "/home/z/my-project/kerf"
DOMAINS = ["crates", "tests", "examples", "src", "scripts", "tools"]
SKIP_DIRS = {"target", "node_modules", "archive"}
EXTS = (".rs",)

RUST_STR_ML = re.compile(r'"((?:[^"\\\n]|\\[^\n]|\\\n[ \t]*)*)"')
CONT = re.compile(r"\\\n[ \t]*")

def process_file(path):
    relpath = os.path.relpath(path, ROOT)
    text = open(path, encoding="utf-8").read()
    changed = 0
    stats = []
    def repl(m):
        nonlocal changed
        raw = m.group(1)
        if not CONT.search(raw):
            return m.group(0)  # single-line — already handled in pass 1
        value = CONT.sub("", raw)
        if not A.CJKCHAR.search(value):
            return m.group(0)
        if A.is_exempt(relpath, value):
            return m.group(0)
        eng, unk = A.translate_literal(value)
        if unk:
            stats.append((value[:60], "".join(unk)))
        if eng != value:
            changed += 1
            return '"%s"' % eng
        return m.group(0)
    new = RUST_STR_ML.sub(repl, text)
    if changed and "--write" in sys.argv:
        open(path, "w", encoding="utf-8").write(new)
    return changed, stats

def main():
    write = "--write" in sys.argv
    total = 0
    all_stats = []
    for dom in DOMAINS:
        base = os.path.join(ROOT, dom)
        if not os.path.isdir(base):
            continue
        for dp, dns, fns in os.walk(base):
            dns[:] = [d for d in dns if d not in SKIP_DIRS]
            for fn in fns:
                if not fn.endswith(EXTS):
                    continue
                c, s = process_file(os.path.join(dp, fn))
                total += c
                all_stats.extend(s)
                if c:
                    print(f"  {os.path.relpath(os.path.join(dp, fn), ROOT)}: {c} multiline literals")
    print(f"total multiline literals rewritten: {total}")
    if all_stats:
        print("UNKNOWN residuals:")
        for v, u in all_stats[:20]:
            print(f"  [{u}] {v}")
    if not write:
        print("(dry run — pass --write to apply)")

if __name__ == "__main__":
    main()

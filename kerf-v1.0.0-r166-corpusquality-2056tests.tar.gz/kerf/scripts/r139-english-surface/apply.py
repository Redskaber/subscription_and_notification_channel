#!/usr/bin/env python3
"""r139 english-surface applier: dictionary-driven, parity-preserving.

Usage:
  python3 apply.py --dry   # report only
  python3 apply.py         # rewrite files in place
"""
import re, os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from kerf_dict import WHOLE, PHRASES, EXEMPT
from kerf_dict_ext import EXT_PHRASES, EXT_WHOLE
from kerf_dict_r3 import R3_PHRASES
from kerf_dict_r4 import R4_WHOLE, R4_PHRASES, R4_CHARS, R4_FIX, R4_ML_WHOLE, R4_ML_PHRASES
WHOLE = {**WHOLE, **EXT_WHOLE, **R4_WHOLE, **R4_ML_WHOLE}
SEG = {**PHRASES, **EXT_PHRASES, **R3_PHRASES, **R4_PHRASES, **R4_FIX, **R4_ML_PHRASES, **R4_CHARS, **WHOLE}

ROOT = "/home/z/my-project/kerf"
DOMAINS = ["crates", "tests", "examples", "src", "scripts", "tools"]
SKIP_DIRS = {"target", "node_modules", "archive"}  # archive = historical artifacts
EXTS = (".rs", ".krf", ".ktf", ".sh", ".py", ".toml")

CJKCHAR = re.compile(r'[\u3000-\u303f\u4e00-\u9fff\uff00-\uffef\u2014\u2018\u2019\u201c\u201d]')
RUST_STR = re.compile(r'"((?:[^"\\\n]|\\.)*)"')

# file-specific data overrides (examples whose subject IS the data itself)
FILE_DATA_KEEP = [
    # Unicode demonstration corpus pair (usage examples): data stays Chinese
    ("examples/usage/io.ktf", None),
    ("examples/usage/io.krf", None),
]

PHRASE_KEYS = sorted(SEG.keys(), key=len, reverse=True)

def segment_run(run):
    """Longest-match-first segmentation of one CJK run. Returns (english, unknown_chars)."""
    out = []
    unknown = []
    i = 0
    while i < len(run):
        matched = None
        for k in PHRASE_KEYS:
            if run.startswith(k, i):
                matched = k
                break
        if matched:
            out.append(SEG[matched])
            i += len(matched)
        else:
            ch = run[i]
            unknown.append(ch)
            out.append("\x01%s\x01" % ch)  # marker for adjudication
            i += 1
    return out, unknown

def join_segments(segs):
    """Join segment translations with minimal spacing rules."""
    res = ""
    for s in segs:
        if not s:
            continue
        if res:
            prev_c, next_c = res[-1], s[0]
            alnum = lambda c: c.isalnum() or c == "_"
            if alnum(prev_c) and alnum(next_c):
                res += " "
        res += s
    return res


def fix_ticks(t):
    """Deterministic backtick spacing via tick-parity (「」 pairs + ASCII pairs)."""
    if "`" not in t:
        return t
    t = re.sub(r"\s*`\s*", "`", t)
    out = []
    tick = 0
    n = len(t)
    for i, ch in enumerate(t):
        if ch == "`":
            if tick % 2 == 0:  # opening
                if out and out[-1] not in " ([{<\"'" and out[-1] != "\n":
                    out.append(" ")
                out.append("`")
            else:  # closing
                out.append("`")
                nxt = t[i + 1] if i + 1 < n else ""
                if nxt and (nxt.isalnum() or nxt == "_"):
                    out.append(" ")
            tick += 1
        else:
            out.append(ch)
    return "".join(out)

def postprocess(text):
    """Cosmetic normalization inside a translated literal."""
    t = text
    t = re.sub(r"\s+([)\];,.])", r"\1", t)      # no space before closing punct
    t = re.sub(r"([(\[`])\s+", r"\1", t)           # no space after opening punct
    t = re.sub(r"  +", " ", t)                     # collapse runs of spaces
    t = re.sub(r"\s+`$", "`", t)
    # colon/comma/semicolon followed by a letter gets a space (readability)
    t = re.sub(r"([A-Za-z0-9`_})\]])([:,;])([A-Za-z])", r"\1\2 \3", t)
    t = fix_ticks(t)
    t = t.strip() if t.strip() else t
    return t

def translate_literal(lit):
    """Pure function: Chinese literal -> English literal. Returns (english, unknowns)."""
    if lit in WHOLE:
        return WHOLE[lit], []
    parts = []           # alternating ascii / segment-lists
    unknown_all = []
    pos = 0
    for m in CJKCHAR.finditer(lit):
        # find maximal CJK run containing m
        pass
    # walk maximal runs
    i = 0
    out = ""
    run_re = re.compile(r'[\u3000-\u303f\u4e00-\u9fff\uff00-\uffef\u2014\u2018\u2019\u201c\u201d]+')
    last = 0
    for m in run_re.finditer(lit):
        out += lit[last:m.start()]
        segs, unknown = segment_run(m.group(0))
        unknown_all.extend(unknown)
        joined = join_segments(segs)
        # spacing between ascii boundary and joined run
        if out and joined:
            alnum = lambda c: c.isalnum() or c == "_" or c == ")"
            if alnum(out[-1]) and joined[0].isalnum():
                out += " "
        out += joined
        last = m.end()
    out += lit[last:]
    out = postprocess(out)
    return out, unknown_all

EXEMPT_SUBSTR = [
    # Unicode round-trip fixtures (substring match — escaped-quote forms included)
    ("bootstrap_reader_tests.rs", "éλ你"),
    ("reader_tests.rs", "你好"),
    ("stdlib_tests.rs", "你好"),
    ("ffi_vm_tests.rs", "你好"),
    ("target_reader_krf_tests.rs", "长详情"),
    ("test_krf_parity_tests.rs", "长详情"),
]

def is_exempt(relpath, lit):
    for (fsub, l) in EXEMPT:
        if fsub in relpath and l == lit:
            return True
    for (fsub, sub) in EXEMPT_SUBSTR:
        if fsub in relpath and sub in lit:
            return True
    for (fsub, _) in FILE_DATA_KEEP:
        if fsub in relpath:
            return True
    return False

def process_file(path, dry):
    relpath = os.path.relpath(path, ROOT)
    text = open(path, encoding="utf-8").read()
    changed = 0
    residuals = []
    def repl(m):
        nonlocal changed
        lit = m.group(1)
        if not CJKCHAR.search(lit):
            return m.group(0)
        if is_exempt(relpath, lit):
            return m.group(0)
        eng, unknown = translate_literal(lit)
        if unknown:
            residuals.append((lit, "".join(sorted(set(unknown))), eng))
        if eng != lit:
            changed += 1
            return '"%s"' % eng
        return m.group(0)
    new = RUST_STR.sub(repl, text)
    stats = {"file": relpath, "changed": changed}
    if not dry and changed:
        open(path, "w", encoding="utf-8").write(new)
    return stats, residuals

def main():
    dry = "--dry" in sys.argv
    all_stats = []
    all_residuals = []
    files_scanned = 0
    for dom in DOMAINS:
        base = os.path.join(ROOT, dom)
        if not os.path.isdir(base):
            continue
        for dirpath, dirnames, filenames in os.walk(base):
            dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
            for fn in filenames:
                if fn.endswith(EXTS):
                    p = os.path.join(dirpath, fn)
                    stats, residuals = process_file(p, dry)
                    all_stats.append(stats)
                    all_residuals.extend(residuals)
                    files_scanned += 1
    total_changed = sum(s["changed"] for s in all_stats)
    files_changed = [s for s in all_stats if s["changed"]]
    print(f"files scanned: {files_scanned}")
    print(f"files changed: {len(files_changed)}")
    print(f"literals rewritten: {total_changed}")
    print(f"residual (unknown char) literals: {len(all_residuals)}")
    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "residuals.json"), "w", encoding="utf-8") as f:
        json.dump(all_residuals, f, ensure_ascii=False, indent=1)
    if all_residuals:
        print("\nRESIDUAL SAMPLE (first 40):")
        for lit, unk, eng in all_residuals[:40]:
            print(f'  UNK[{unk}] {lit[:80]}  =>  {eng[:80]}')

if __name__ == "__main__":
    main()

# r139 English-Surface Conversion Tooling (archived — R4 discipline)

One-shot conversion tooling for the r139 English-coding unification window
(SOP v13.22 §10.5). Kept as the conversion record and the reference
implementation of the single-source dictionary discipline.

- `kerf_dict.py` / `kerf_dict_ext.py` / `kerf_dict_r3.py` / `kerf_dict_r4.py`
  — the single-source translation dictionary (four iteration rounds):
  whole-literal overrides for user-facing messages + longest-match phrase
  segmentation + single-char fallback. The dictionary is a pure function on
  the Chinese source text — identical input literals always yield identical
  output, which is what keeps the Rust seed side and the bootstrap
  `.krf`/`.ktf` mirror side byte-identical (parity guard precondition).
- `apply.py` — single-line string-literal converter (dry-run via `--dry`).
- `apply_ml.py` — multi-line continuation-string converter (Rust `\<newline>`
  form; pass `--write` to apply).

Exemptions (kept Chinese on purpose, per SOP v13.22 §10.5 clause 1):
Unicode-capability test fixtures whose subject IS CJK text — reader CJK
round-trip, string codepoint ordering, test-runner Unicode truncation
boundary, and the `examples/usage/io.*` Unicode demonstration corpus pair.

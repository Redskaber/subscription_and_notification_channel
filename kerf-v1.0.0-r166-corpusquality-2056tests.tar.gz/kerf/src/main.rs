//! kerf CLI (root crate entry — orchestrates kerf-driver).
//!
//! Subcommands:
//! - `run <file>`: compile + VM execution (production path, all three
//!   front-end stages self-hosted — I1 production switch 42-d), prints the
//!   final value;
//! - `eval <file>`: **retired** (42-d P5 — the self-hosting compiler + VM
//!   is the sole production path; the reference path is served by the
//!   library API `run_source_seed`, the CLI face removed);
//! - `check <file>`: dry compilation (diagnostics only);
//! - `tokens / stx / core / ir / bc / code <file>`: pipeline-level dumps
//!   (§16 human-observable output + §14.9 compiler self-debugging tools);
//! - `bench <file> [N]`: performance benchmarks (§14.8 — baseline collection
//!   for fib and similar benchmarks);
//! - `anf <file>`: AnnotatedANF IR summary dump (batch G — the backend
//!   lowering face);
//! - `native <file>`: QBE AOT compilation + run (first non-VM backend —
//!   §21.3 condition 3).
//!
//! **r79 / 149-b production switch (build-system segment, second incision —
//! TD-032 CLI orchestration face)**: subcommand dispatch decisions go
//! through the self-hosted cli.ktf (running on the VM — the `bootstrap_cli`
//! bridge); the Rust version (the original match dispatch) is retired as
//! the parity oracle (`bootstrap_cli::dispatch_seed` — checked by
//! cli_krf_parity_tests).
//!
//! **r86 / 156-b production switch (build-system segment, third incision —
//! TD-032 test entry face)**: `cmd_test` report rendering + exit-code
//! decisions go through the self-hosted test.ktf (running on the VM — the
//! `bootstrap_test` bridge); the Rust version (the original rendering
//! loop) is retired as the parity oracle (`bootstrap_test::report_seed` —
//! checked by test_krf_parity_tests).
//!
//! **r87 / 157-b production switch (build-system segment, fourth incision —
//! TD-032 test runner face)**: `cmd_test` case splitting + per-case
//! execution orchestration + result aggregation go through the self-hosted
//! test_runner.ktf (running on the VM — the `bootstrap_test_runner`
//! bridge); the Rust version (driver.rs `test_source`) is retired as
//! the parity oracle (checked by `test_runner_krf_parity_tests`).
//!
//! **r153 / 223-a CLI entry convergence (s-expr-removal-plan §4 Batch D —
//! the r125 / 195-a dual-entry period ends)**: the CLI accepts exact
//! `.ktf` kerf source files only (the extension dispatch rule flipped —
//! "CLI 入口收敛 .ktf 单面"); everything else (`.krf`, `.KTF`, no
//! extension, any other extension) is rejected fail-closed with the
//! structured retirement diagnostic (exit 2). The S-expression driver
//! APIs (`run_source` / `compile_source` / …) retire from the production
//! surface (their remaining consumers = the parity-oracle test families;
//! E6 close-out deletion — reader.ktf retirement registers in the same
//! batch, s-expr-removal-plan §1.1 objects 2-3).

use kerf_backend::{build_native, find_qbe, gen_il, lower_program, run_native};
use kerf_core::CodeValue;
use kerf_driver::bootstrap::cli::CliAction;
use kerf_driver::{
    cache_stats, check_source_recover, compile_source, dump_stx, dump_tokens, run_source,
};

/// CLI entry-convergence dispatch (r153 / 223-a — s-expr-removal-plan §4
/// Batch D: "CLI 入口收敛 .ktf 单面（扩展名分派规则翻转）"; the r125 /
/// 195-a dual-entry form is retired).
///
/// Rule: an exact `.ktf` filename extension routes the file through the
/// Reader (the sole production face — the reader bridge whose own
/// program is reader.ktf since r152, the Reader
/// fixpoint); everything else is **rejected fail-closed** (the
/// S-expression user entry is retired — the structured diagnostic names
/// the retirement and the accepted face). Case-sensitive exact match
/// (Rust `extension` convention — `file.KTF` does NOT hit the .ktf
/// face; fail-closed leaning over silent leniency, unchanged from the
/// r125 dispatch basis).
fn is_ktf_path(path: &str) -> bool {
    std::path::Path::new(path)
        .extension()
        .and_then(|e| e.to_str())
        == Some("ktf")
}

/// Fail-closed rejection of the retired S-expression entry (r153 / 223-a —
/// Batch D "`.krf` 拒收 fail-closed 负例族" at the CLI boundary; the
/// negative family is behaviorally anchored by the subprocess tests in
/// cli_entry_convergence_tests).
fn reject_retired_syntax(path: &str) -> i32 {
    eprintln!(
        "error: '{}' is not a .ktf kerf source file; the S-expression surface is retired (r153) -- rename or rewrite the source in kerf syntax",
        path
    );
    2
}
fn main() {
    let args: Vec<String> = std::env::args().collect();
    if args.len() < 2 {
        print_usage();
        std::process::exit(2);
    }
    let cmd = args[1].as_str();
    let file = args.get(2).map(|s| s.as_str());
    // r79/149-b production switch: dispatch decisions go through the
    // self-hosted cli.ktf (running on the VM — build-system segment,
    // second incision; seed oracle = bootstrap_cli::dispatch_seed).
    // Bootstrap defects are fail-closed (code 1 + error rendering — the
    // parity corpus + the full suite with zero regressions guard its
    // unreachability).
    let action = match kerf_driver::bootstrap::cli::dispatch(cmd, file.is_some()) {
        Ok(a) => a,
        Err(e) => {
            eprintln!("{}", e);
            std::process::exit(1);
        }
    };
    let exit = match (action, file) {
        (CliAction::Run, Some(f)) => cmd_run(f),
        (CliAction::Check, Some(f)) => cmd_check(f),
        (CliAction::Test, Some(f)) => cmd_test(f),
        (CliAction::Tokens, Some(f)) => cmd_tokens(f),
        (CliAction::Stx, Some(f)) => cmd_stx(f),
        (CliAction::Core, Some(f)) => cmd_core(f),
        (CliAction::Ir, Some(f)) => cmd_ir(f),
        (CliAction::Bc, Some(f)) => cmd_bc(f),
        (CliAction::Code, Some(f)) => cmd_code(f),
        (CliAction::Bench, Some(f)) => {
            cmd_bench(f, args.get(3).and_then(|n| n.parse::<u32>().ok()))
        }
        (CliAction::Anf, Some(f)) => cmd_anf(f),
        (CliAction::Native, Some(f)) => cmd_native(f),
        (CliAction::EvalRetired, _) => {
            // eval retired (42-d P5: the self-hosting compiler + VM is the
            // sole production path — the CLI reference-path face removed;
            // the library API run_source_seed serves the T1 cross-check)
            eprintln!(
                "error: the eval subcommand is retired (r23 / 42-d: the bootstrap compiler + VM is the only production path); please use run"
            );
            2
        }
        (CliAction::NeedsFile, _) => {
            eprintln!("error: {} requires file argument", cmd);
            2
        }
        // _ arm rationale: unknown subcommand / recognized action mismatched
        // with file presence (a combination unreachable at the dispatch
        // layer — defensive fallback isomorphic to the original _ arm:
        // print usage and exit with code 2)
        _ => {
            print_usage();
            2
        }
    };
    std::process::exit(exit);
}

fn print_usage() {
    eprintln!(
        "kerf {} -- minimal self-hosted systems programming language (Stage 0)",
        env!("CARGO_PKG_VERSION")
    );
    eprintln!();
    eprintln!("usage: kerf <subcommand> <file.ktf>");
    eprintln!();
    eprintln!("syntax entry: .ktf kerf syntax (single face -- the .krf S-expr entry retired r153)");
    eprintln!();
    eprintln!("subcommands:");
    eprintln!(" run <file> [N] compile + VM execution(strike print final value; pre-stage all bootstrap -- I1)");
    eprintln!(
        " eval already retired(42-d: bootstrap compiler + VM unique production path -- use run)"
    );
    eprintln!(" check <file> dry compile(read→expand→compile, only diagnostic)");
    eprintln!(" test <file> case runner(expression form=case; short-circuit+error recovery)");
    eprintln!(" tokens <file> Token flow dump");
    eprintln!(" stx <file> syntax object dump");
    eprintln!("  core <file>          CoreExpr dump");
    eprintln!(" ir <file> graph IR dump(node + shared check find)");
    eprintln!(" bc <file> bytecode disassembly(containing call try information information)");
    eprintln!(" code <file>          CodeValue check(well-formed property/from by variable)");
    eprintln!(" bench <file> [N] performance benchmark(N round, default 10)");
    eprintln!(" anf <file>           AnnotatedANF IR excerpt require(backend lowering face)");
    eprintln!(" native <file> QBE AOT compile + run(native code backend, PoC)");
}

fn read_file(path: &str) -> Result<String, i32> {
    std::fs::read_to_string(path).map_err(|e| {
        eprintln!("error: cannot read file {}: {}", path, e);
        1
    })
}

fn cmd_test(path: &str) -> i32 {
    // r153 / 223-a entry convergence: the test front goes through the
    // reader bridge for `.ktf` files only (case splitting operates
    // on ModuleItem — syntax-neutral, so the shared orchestration tail
    // serves the single face).
    if !is_ktf_path(path) {
        return reject_retired_syntax(path);
    }
    let src = match read_file(path) {
        Ok(s) => s,
        Err(c) => return c,
    };
    // r87/157-b production switch (build-system segment, fourth incision —
    // TD-032 test runner face): case splitting + per-case execution
    // orchestration + result aggregation go through the self-hosted
    // test_runner.ktf (running on the VM — the `bootstrap_test_runner`
    // bridge); the Rust version (driver.rs `test_source`) is retired as
    // the parity oracle (checked by `test_runner_krf_parity_tests` — the
    // three-piece switch isomorphic discipline).
    // Bootstrap defects are fail-closed (code 1 + error rendering — the
    // parity corpus + the full suite with zero regressions guard its
    // unreachability).
    // r125 / 195-a dual-entry legacy note: the former S-expr branch
    // (`test_runner::run`) retired from the CLI face with the r153
    // convergence (oracle consumers only, E6 deletion).
    let report_result = kerf_driver::bootstrap::test_runner::run_test_case(&src, path);
    match report_result {
        Ok(report) => {
            // r86/156-b production switch (build-system segment, third
            // incision — TD-032 test entry face): report rendering +
            // exit-code decisions go through the self-hosted test.ktf
            // (running on the VM — the `bootstrap_test` bridge); the Rust
            // version (the original rendering loop) is retired as the
            // parity oracle (`bootstrap_test::report_seed` — checked by
            // test_krf_parity_tests). Bootstrap defects are fail-closed
            // (code 1 + error rendering — the parity corpus + the full
            // suite with zero regressions guard its unreachability).
            match kerf_driver::bootstrap::test::report(&report) {
                Ok((output, code)) => {
                    print!("{}", output);
                    code
                }
                Err(e) => {
                    eprintln!("{}", e);
                    1
                }
            }
        }
        Err(e) => {
            eprintln!("{}", e);
            1
        }
    }
}

fn cmd_run(path: &str) -> i32 {
    // r153 / 223-a entry convergence: `.ktf` routes through the
    // target-syntax Reader (cache-free — same basis as every
    // target-syntax entry); everything else is rejected fail-closed (the
    // S-expr run branch retired with the convergence).
    if !is_ktf_path(path) {
        return reject_retired_syntax(path);
    }
    let src = match read_file(path) {
        Ok(s) => s,
        Err(c) => return c,
    };
    let outcome_result = run_source(&src, path);
    match outcome_result {
        Ok(outcome) => {
            // M2 (r40) W-level diagnostic rendering (W1001 deprecation
            // family / W1002 shadowing family — non-blocking; the stderr
            // channel is separate from error diagnostics — run results are
            // unaffected)
            for w in &outcome.warnings {
                eprintln!("[warning] {}", w.message);
            }
            // Final value rendering (⇒ prefix; print builtin output already
            // written directly to stdout; the heap stays alive with the value)
            println!("⇒ {}", kerf_vm::render_value(&outcome.value, &outcome.heap));
            0
        }
        Err(e) => {
            eprintln!("{}", e);
            1
        }
    }
}

fn cmd_check(path: &str) -> i32 {
    // r153 / 223-a entry convergence: `.ktf` routes through the
    // target-syntax Reader (recovery-mode check — the shared tail
    // implements prelude injection / recovery expansion / HM type check);
    // everything else is rejected fail-closed.
    if !is_ktf_path(path) {
        return reject_retired_syntax(path);
    }
    let src = match read_file(path) {
        Ok(s) => s,
        Err(c) => return c,
    };
    // TD-013 recovery mode (38-e): expand form-level recovery — full
    // reporting of E0002 (expansion) + E0005 (type); single-error
    // short-circuiting stays in the library API check_source; the run
    // execution path is unchanged (r7 design §5 consumer-face table)
    let report_result = check_source_recover(&src, path);
    match report_result {
        Ok(report) => {
            let cache_note = if report.cache_hit {
                "cache hit"
            } else {
                "cache not in"
            };
            let stats = cache_stats();
            if report.diagnostics.is_empty() {
                println!(
                    "ok: {} prototype / {} constant / {} global reference / {} instruction({}; session hit {}/{})",
                    report.proto_count,
                    report.const_count,
                    report.global_ref_count,
                    report.instruction_count,
                    cache_note,
                    stats.hits,
                    stats.hits + stats.misses
                );
                0
            } else {
                for line in &report.rendered {
                    eprintln!("{}", line);
                }
                println!(
                    "found {} static problems (E0002 expansion + E0005 types; {} prototypes / {} instructions; {})",
                    report.diagnostics.len(),
                    report.proto_count,
                    report.instruction_count,
                    cache_note
                );
                1
            }
        }
        Err(e) => {
            eprintln!("{}", e);
            1
        }
    }
}

fn cmd_tokens(path: &str) -> i32 {
    // §11/§14.7.2 B4: reader is called only by the driver — the CLI forwards via dump_tokens
    // r153 / 223-a entry convergence: `.ktf` only (reader bridge lexer).
    if !is_ktf_path(path) {
        return reject_retired_syntax(path);
    }
    let src = match read_file(path) {
        Ok(s) => s,
        Err(c) => return c,
    };
    let dump_result = dump_tokens(&src, path);
    match dump_result {
        Ok(out) => {
            print!("{}", out);
            0
        }
        Err(e) => {
            eprintln!("{}", e);
            1
        }
    }
}

fn cmd_stx(path: &str) -> i32 {
    // r153 / 223-a entry convergence: `.ktf` only (reader bridge
    // read; the Stx rendering loop is skin-neutral).
    if !is_ktf_path(path) {
        return reject_retired_syntax(path);
    }
    let src = match read_file(path) {
        Ok(s) => s,
        Err(c) => return c,
    };
    let dump_result = dump_stx(&src, path);
    match dump_result {
        Ok(out) => {
            print!("{}", out);
            0
        }
        Err(e) => {
            eprintln!("{}", e);
            1
        }
    }
}

fn cmd_core(path: &str) -> i32 {
    // r153 / 223-a entry convergence: `.ktf` only (compile_source —
    // the target full-compilation entry).
    if !is_ktf_path(path) {
        return reject_retired_syntax(path);
    }
    let src = match read_file(path) {
        Ok(s) => s,
        Err(c) => return c,
    };
    let compile_result = compile_source(&src, path);
    match compile_result {
        Ok(out) => {
            println!("{}", out.render_core());
            0
        }
        Err(e) => {
            eprintln!("{}", e);
            1
        }
    }
}

fn cmd_ir(path: &str) -> i32 {
    // r153 / 223-a entry convergence: `.ktf` → compile_source.
    if !is_ktf_path(path) {
        return reject_retired_syntax(path);
    }
    let src = match read_file(path) {
        Ok(s) => s,
        Err(c) => return c,
    };
    let compile_result = compile_source(&src, path);
    match compile_result {
        Ok(out) => {
            println!("node total: {}", out.ir.len());
            println!("root node: {:?}", out.ir.roots());
            for (id, node) in out.ir.iter_nodes() {
                let meta = out.ir.get_metadata(id);
                println!(
                    "  #{:<3} {:<40} span {}..{} scopes {}",
                    id,
                    format!("{:?}", node),
                    meta.span.start,
                    meta.span.end,
                    meta.scopes.len()
                );
            }
            0
        }
        Err(e) => {
            eprintln!("{}", e);
            1
        }
    }
}

fn cmd_bc(path: &str) -> i32 {
    // r153 / 223-a entry convergence: `.ktf` → compile_source.
    if !is_ktf_path(path) {
        return reject_retired_syntax(path);
    }
    let src = match read_file(path) {
        Ok(s) => s,
        Err(c) => return c,
    };
    let compile_result = compile_source(&src, path);
    match compile_result {
        Ok(out) => {
            print!("{}", out.disassemble());
            0
        }
        Err(e) => {
            eprintln!("{}", e);
            1
        }
    }
}

fn cmd_code(path: &str) -> i32 {
    // r153 / 223-a entry convergence: `.ktf` → compile_source.
    if !is_ktf_path(path) {
        return reject_retired_syntax(path);
    }
    let src = match read_file(path) {
        Ok(s) => s,
        Err(c) => return c,
    };
    let compile_result = compile_source(&src, path);
    match compile_result {
        Ok(out) => {
            // r49 D59: program-item face — code-value checking per declared
            // item value / expression item (isomorphic to Python
            // ast.Module stmt traversal: item-order display)
            for item in &out.core {
                let exprs: Vec<&kerf_core::CoreExpr> = match item {
                    kerf_core::ModuleItem::Define { value, .. } => vec![value],
                    kerf_core::ModuleItem::Require { .. } => vec![],
                    kerf_core::ModuleItem::Module { .. } => vec![],
                    kerf_core::ModuleItem::Expr(e) => vec![e],
                };
                for e in exprs {
                    let cv = CodeValue::from_expr(e);
                    let free: Vec<String> = cv
                        .free_variables()
                        .iter()
                        .map(|s| out.table.name(*s).to_string())
                        .collect();
                    println!(
                        "code-value: well-formed={} from by variable=[{}] stage={:?}",
                        cv.is_well_formed(),
                        free.join(", "),
                        cv.stage
                    );
                }
            }
            0
        }
        Err(e) => {
            eprintln!("{}", e);
            1
        }
    }
}

fn cmd_bench(path: &str, rounds: Option<u32>) -> i32 {
    // r153 / 223-a entry convergence: `.ktf` routes through the
    // target-syntax Reader (run_source — cache-free, so bench
    // timings include the front-end work each round, same basis as the
    // run face).
    if !is_ktf_path(path) {
        return reject_retired_syntax(path);
    }
    let src = match read_file(path) {
        Ok(s) => s,
        Err(c) => return c,
    };
    let n = rounds.unwrap_or(10);
    // First verify correctness once
    match run_source(&src, path) {
        Ok(outcome) => {
            println!(
                "verify: ⇒ {}",
                kerf_vm::render_value(&outcome.value, &outcome.heap)
            );
        }
        Err(e) => {
            eprintln!("{}", e);
            return 1;
        }
    }
    let start = std::time::Instant::now();
    for _ in 0..n {
        if let Err(e) = run_source(&src, path) {
            eprintln!("{}", e);
            return 1;
        }
    }
    let elapsed = start.elapsed();
    let per_round = elapsed.as_secs_f64() / n as f64;
    println!(
        "benchmark: {} round / total {:.3}s / each round {:.3}ms",
        n,
        elapsed.as_secs_f64(),
        per_round * 1000.0
    );
    0
}

/// `anf <file>`: AnnotatedANF IR summary dump (function/block/instruction counts + fingerprint).
fn cmd_anf(path: &str) -> i32 {
    // r153 / 223-a entry convergence: `.ktf` → compile_source.
    if !is_ktf_path(path) {
        return reject_retired_syntax(path);
    }
    let src = match read_file(path) {
        Ok(s) => s,
        Err(c) => return c,
    };
    let compile_result = compile_source(&src, path);
    let out = match compile_result {
        Ok(o) => o,
        Err(e) => {
            eprintln!("{}", e);
            return 1;
        }
    };
    let ir = match lower_program(&out.core, &out.table) {
        Ok(ir) => ir,
        Err(e) => {
            eprintln!("lowering error: {}", e.message);
            return 1;
        }
    };
    println!("function count: {}", ir.funcs.len());
    println!("fingerprint: #{:016x}", ir.fingerprint);
    for f in &ir.funcs {
        let stmts: usize = f.body.blocks.iter().map(|b| b.stmts.len()).sum();
        println!(
            " ${:<24} formal parameter {} block {} instruction {}",
            f.name,
            f.params.len(),
            f.body.blocks.len(),
            stmts
        );
    }
    0
}

/// `native <file>`: QBE AOT compilation + run (§21.3 condition 3 — the first non-VM backend).
///
/// Artifacts are written to a temporary directory (path printed); the run
/// result is presented via the process exit code (POSIX low-8-bit basis —
/// `fib 12 ⇒ 144` fully visible).
fn cmd_native(path: &str) -> i32 {
    // r153 / 223-a entry convergence: `.ktf` → compile_source.
    if !is_ktf_path(path) {
        return reject_retired_syntax(path);
    }
    let src = match read_file(path) {
        Ok(s) => s,
        Err(c) => return c,
    };
    let compile_result = compile_source(&src, path);
    let out = match compile_result {
        Ok(o) => o,
        Err(e) => {
            eprintln!("{}", e);
            return 1;
        }
    };
    let ir = match lower_program(&out.core, &out.table) {
        Ok(ir) => ir,
        Err(e) => {
            eprintln!("lowering error: {}", e.message);
            return 1;
        }
    };
    let il = gen_il(&ir);
    let qbe = match find_qbe() {
        Ok(q) => q,
        Err(e) => {
            eprintln!("QBE toolchain error: {}", e.reason);
            return 1;
        }
    };
    let stem = format!(
        "kerf-native-{}",
        std::path::Path::new(path)
            .file_stem()
            .and_then(|s| s.to_str())
            .unwrap_or("prog")
    );
    let out_dir = std::env::temp_dir();
    let arts = match build_native(&il, &out_dir, &stem, &qbe) {
        Ok(a) => a,
        Err(e) => {
            eprintln!("AOT error: {}", e.reason);
            return 1;
        }
    };
    println!("IL: {}", arts.il_path.display());
    println!("assembly: {}", arts.asm_path.display());
    println!("can execution: {}", arts.exe_path.display());
    match run_native(&arts.exe_path) {
        Ok(code) => {
            println!("run: exit {}", code);
            0
        }
        Err(e) => {
            eprintln!("run error: {}", e.reason);
            1
        }
    }
}

//! Shared test helpers (sop.md §9.1 rule 4: tests/common/ hosts shared helpers).
//!
//! Note: shared as a single instance through the runner.rs main entry
//! (v11.2 test entry architecture) — each test module consumes a different
//! subset via `use crate::common`; unused helpers allow dead_code under
//! common-library semantics.

use kerf_driver::{run_source, run_source_seed, RunOutcome};
use kerf_vm::Value;

// E6 close-out (r154 / 224-b): the helpers run on the target-syntax face
// (the S-expr entry family retired — s-expr-removal-plan §4 E6); callers'
// inline corpora are target-syntax programs.

/// Compile + VM execution (returns the final value).
#[allow(dead_code)]
pub fn run(src: &str) -> Result<Value, String> {
    match run_source(src, "test.ktf") {
        Ok(o) => Ok(o.value),
        Err(e) => Err(e.to_string()),
    }
}

/// Compile + VM execution (returns the rendered value + post-run heap —
/// for GC assertions).
#[allow(dead_code)]
pub fn run_with_heap(src: &str) -> Result<RunOutcome, String> {
    run_source(src, "test.ktf").map_err(|e| e.to_string())
}

/// Compile + execute (rendered string — the golden output for snapshot
/// tests).
#[allow(dead_code)]
pub fn run_rendered(src: &str) -> String {
    run_source(src, "test.ktf")
        .map(|o| kerf_vm::render_value(&o.value, &o.heap))
        .unwrap_or_else(|e| format!("<error:{}>", e))
}

/// Dual-path cross-check (T1 — 42-d new baseline, target face since E6):
/// the production chain (self-hosting read+expand+compile + VM) and the
/// seed chain (Rust seed Reader + seed expand + seed compile + VM)
/// must produce identical rendered results (§21.8 Phase 1 core
/// verification; the seed chain is the replacement oracle surface).
#[allow(dead_code)]
pub fn dual_path_agrees(src: &str) -> bool {
    let vm = run_source(src, "test.ktf")
        .map(|o| kerf_vm::render_value(&o.value, &o.heap))
        .unwrap_or_else(|e| format!("<error:{}>", e));
    let seed = run_source_seed(src, "test.ktf")
        .map(|o| kerf_vm::render_value(&o.value, &o.heap))
        .unwrap_or_else(|e| format!("<error:{}>", e));
    vm == seed
}

/// Assert that the run result is the given integer.
#[allow(dead_code)]
pub fn assert_int(src: &str, expected: i64) {
    match run(src) {
        Ok(Value::Int(v)) if v == expected => {}
        other => panic!("expected {}, got {:?}", expected, other),
    }
}

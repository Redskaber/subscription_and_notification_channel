// E6 close-out (r154 / 224-b5): converted to the target-syntax face.
//! Stage 1 batch A3 (TD-007) integration tests: end-to-end verification
//! of the macro-expansion trampoline worklist — deep macro chains
//! through the expand → compile → VM full pipeline.
//!
//! Unit-level deep-chain tests (2_000-level constructed chains) live
//! inline in kerf-expander; this file covers the real source path (the
//! maximum chain depth within the reader's nesting limit of 256).
//!
//! E6 skin notes (E6-CG §2): `macro NAME { (pattern) => template }` is
//! the target face of define-syntax/syntax-rules (the ninth
//! skin-dictionary mapping); cond/let sugars reduce to their target
//! faces (if-else / let statement — see the interleaving case).

use kerf_driver::{run_source, run_source_seed, Stage};
use kerf_vm::Value;

/// Positive case: a 200-level nested pass-through macro chain (source
/// nesting within the ≤ 256 reader limit) expanded end to end
/// (trampoline iteration) → compiled → executed on the VM → reduced to
/// the literal.
#[test]
fn deep_macro_chain_end_to_end_vm() {
    let depth = 200;
    let src = format!(
        "macro m {{ (x) => x }}\nm({}42{})",
        "m(".repeat(depth),
        ")".repeat(depth)
    );
    let o = run_source(&src, "chain.ktf").unwrap();
    assert!(
        matches!(o.value, Value::Int(42)),
        "200 layer macro chain should converge approx to 42"
    );
}

/// Dual-path agreement: a deep macro chain yields the same result on the
/// two execution paths (the production self-hosting chain and the seed
/// chain — the T1 oracle face since 42-d) (preservation of theorem T1
/// under trampoline expansion).
#[test]
fn deep_macro_chain_dual_path_agrees() {
    let depth = 100;
    let src = format!(
        "macro m {{ (x) => x }}\nm({}42{})",
        "m(".repeat(depth),
        ")".repeat(depth)
    );
    let a = run_source(&src, "chain.ktf").unwrap();
    let b = run_source_seed(&src, "chain.ktf").unwrap();
    assert!(a.value.eq_value(&b.value));
}

/// Negative case: an infinitely self-referential macro reports a
/// structured error through the full pipeline (expansion-stage E2 — an
/// over-limit error rather than a stack overflow; error stage tag =
/// expand).
#[test]
fn infinite_macro_reports_expand_stage_error() {
    let src = "macro lo { () => lo() }\nlo()";
    let err = run_source(src, "inf.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Expand);
    assert!(
        err.to_string().contains("expansion depth"),
        "actual: {}",
        err
    );
}

/// Sugar-chain interleaving: macro chains and syntactic sugar
/// (let/if-else) expand interleaved — verifies the cooperation between
/// the trampoline and the sugar-derivation channel (macro output flows
/// into sugar derivation, sugar output flows back into the trampoline —
/// bidirectional flow). (The S-expr corpus's cond arm converts to the
/// if-else chain — the target grammar's sugar face; the let template
/// keeps the let statement skin.)
#[test]
fn macro_chain_interleaved_with_sugar() {
    let src = r#"
        macro wrap { (x) => { let v = x; v + 0 } }
        fn f(n: T) { if (n == 0) { 0 } else { n + f(n - 1) } }
        wrap(f(10))
    "#;
    let o = run_source(src, "mix.ktf").unwrap();
    assert!(matches!(o.value, Value::Int(55)), "1..10 request and = 55");
}

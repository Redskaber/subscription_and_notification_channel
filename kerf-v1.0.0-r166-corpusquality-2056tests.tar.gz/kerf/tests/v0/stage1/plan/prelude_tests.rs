// E6 close-out (r154 / 224-b6): converted to the target-syntax face.
//! TD-021 prelude module injection suite (Stage 1 batch E / Task 34-c).
//!
//! E6 skin notes (E6-CG §2): `(import kerf-prelude)` → `import
//! kerf_prelude;` (module names enter the symbol table kebab via the
//! Reader `_`→`-` introduction mapping — runtime messages keep the
//! kebab spelling); builtin values in argument position (`(foldl + 0
//! ...)`) are rewritten as closures — the operator tokens have no
//! argument-position spelling on the target grammar; `cons` is a plain
//! identifier and passes directly.
//!
//! Acceptance gate (tech-debt-register TD-021 repayment — "hofs
//! user-face injection lacked a carrier"):
//! - **User face visible**: after a user program declares the import in
//!   `(module name (import kerf-prelude) ...)`, map/filter/foldl/for-each
//!   are callable as ordinary global functions (carried by the module
//!   system — forms-level merged injection, not the three vetoed paths
//!   of source splicing / cross-program merging / builtin-calls-closure);
//! - **Behavior face**: the injected hofs execute in the same VM program
//!   as the user program — both execution paths (run/eval) agree (T1
//!   criterion);
//! - **Explicit failure**: a same-named define → the "duplicate variable
//!   definition" structured error (no silent shadowing — §2.3 principle
//!   4);
//! - **opt-in semantics**: without an import declaration → hofs stay
//!   unbound (no implicit injection).
//!
//! Clauses followed: §9.4.3 (paired positive/negative cases), §7.1 (≥3
//! integration verifications), §2.3-11 (measure first, do not guess —
//! all assertions run through the real pipeline).

use kerf_driver::{run_source, run_source_seed, RunOutcome};

fn value_of(o: &RunOutcome) -> String {
    kerf_vm::render_value(&o.value, &o.heap)
}

#[test]
fn prelude_import_hofs_user_face() {
    // User-face visibility: after the import declaration map/filter are
    // directly callable
    let src = r#"import kerf_prelude;
module user {
    import kerf_prelude;
    let lst = list(1, 2, 3, 4, 5);
    map(|| (x: i64) { x * 2 }, lst)
}"#;
    let o = run_source(src, "prelude.ktf").expect("prelude should be runnable after injection");
    assert_eq!(value_of(&o), "(2 4 6 8 10)");
}

#[test]
fn prelude_composition_pipeline() {
    // Composition pipeline: filter → map → foldl (hofs cooperating)
    let src = r#"import kerf_prelude;
module user {
    import kerf_prelude;
    let lst = list(1, 2, 3, 4, 5);
    foldl(|| (acc: i64, x: i64) { acc + x }, 0,
          map(|| (x: i64) { x * x },
              filter(|| (x: i64) { x > 2 }, lst)))
}"#;
    let o = run_source(src, "prelude.ktf").expect("compose pipeline should be runnable");
    assert_eq!(value_of(&o), "50");
}

#[test]
fn prelude_for_each_side_effect() {
    // for-each side-effect order (summing in traversal order — observed
    // via assign)
    let src = r#"import kerf_prelude;
module user {
    import kerf_prelude;
    let count = 0;
    for_each(|| (x: i64) { count = count + x; }, list(1, 2, 3));
    count
}"#;
    let o = run_source(src, "prelude.ktf").expect("for-each should be runnable");
    assert_eq!(value_of(&o), "6");
}

#[test]
fn prelude_dual_execution_paths_agree() {
    // T1 dual-path agreement (42-d updated criterion): the injected
    // artifact yields the same result on the production chain and the
    // seed chain
    let src = r#"import kerf_prelude;
module user {
    import kerf_prelude;
    foldl(|| (acc: i64, x: i64) { acc + x }, 0, list(1, 2, 3, 4))
}"#;
    let a = run_source(src, "prelude.ktf").expect("VM path failed");
    let b = run_source_seed(src, "prelude.ktf").expect("seed chain failed");
    assert!(a.value.eq_value(&b.value), "dual-path should consistent");
    assert_eq!(value_of(&a), "10");
}

#[test]
fn prelude_import_without_module_stays_unbound() {
    // opt-in semantics: a top-level direct reference (no import
    // declaration) → unbound (no implicit injection)
    let err = run_source("map(|| (x: i64) { x }, list(1))", "no-import.ktf")
        .expect_err("(import kerf_prelude)\n not import time map should unbound");
    assert!(err.rendered.contains("unbound"), "actual: {}", err.rendered);
}

#[test]
fn prelude_name_capture_fails_explicitly() {
    // Same-named define → the "duplicate variable definition"
    // structured error (explicit failure, no silent shadowing)
    let src = r#"import kerf_prelude;
module user {
    import kerf_prelude;
    fn map(f: T, lst: T) { lst }
    map(|| (x: i64) { x }, list(1))
}"#;
    let err = run_source(src, "capture.ktf")
        .expect_err("same-named define should explicit report an error");
    assert!(
        err.rendered.contains("duplicate variable definition"),
        "actual: {}",
        err.rendered
    );
}

#[test]
fn prelude_import_unknown_module_errors() {
    // M2 (r40) E0019 takeover: an unknown import is rejected up front by
    // the import-face allowlist check (diagnostic gain: the message
    // carries the registered list + Stage 3 window guidance; deep-review
    // ruling D2)
    let src = "module user { import nonexistent_module; 1 }";
    let err = run_source(src, "unknown.ktf").expect_err("unknown import should report an error");
    assert!(
        err.rendered.contains("E0019")
            && err
                .rendered
                .contains("unknown imported module `nonexistent-module`"),
        "actual: {}",
        err.rendered
    );
}

/// foldr user face (r24 / 42-e stdlib gap fill — the dual of foldl):
/// right fold accumulates from the tail; the (f head recursive-result)
/// shape.
#[test]
fn prelude_foldr_user_face() {
    // Right-fold order: a cons-constructing identity fold → rebuilds the
    // original list
    let src = r#"import kerf_prelude;
module user {
    import kerf_prelude;
    foldr(cons, (), list(1, 2, 3))
}"#;
    let o = run_source(src, "prelude.ktf").expect("foldr should be runnable after injection");
    assert_eq!(value_of(&o), "(1 2 3)");
}

/// foldr/foldl duality semantics (3 cases): the accumulation-order
/// difference is observable — foldr computes from the tail (nested
/// (- 10 (…))), foldl from the head.
#[test]
fn prelude_foldr_foldl_duality() {
    let src = r#"import kerf_prelude;
module user {
    import kerf_prelude;
    foldr(|| (a: i64, b: i64) { a - b }, 0, list(1, 2, 3))
}"#;
    // foldr: (- 1 (- 2 (- 3 0))) = 1 - (2 - 3) = 2
    let o = run_source(src, "prelude.ktf").unwrap();
    assert_eq!(value_of(&o), "2");
    let src2 = r#"import kerf_prelude;
module user {
    import kerf_prelude;
    foldl(|| (acc: i64, x: i64) { acc - x }, 0, list(1, 2, 3))
}"#;
    // foldl: (- (- (- 0 1) 2) 3) = -6
    let o2 = run_source(src2, "prelude.ktf").unwrap();
    assert_eq!(value_of(&o2), "-6");
    // Empty list → init (both folds agree at the boundary)
    let src3 = r#"import kerf_prelude;
module user {
    import kerf_prelude;
    foldr(|| (a: i64, b: i64) { a + b }, 42, ())
}"#;
    let o3 = run_source(src3, "prelude.ktf").unwrap();
    assert_eq!(value_of(&o3), "42");
}

/// foldr dual-path agreement (T1 criterion): production chain and seed
/// chain give the same result.
#[test]
fn prelude_foldr_dual_path() {
    let src = r#"import kerf_prelude;
module user {
    import kerf_prelude;
    foldr(|| (a: i64, b: i64) { a + b }, 0, list(1, 2, 3, 4))
}"#;
    let a = run_source(src, "foldr.ktf").expect("production chain failed");
    let b = run_source_seed(src, "foldr.ktf").expect("seed chain failed");
    assert_eq!(value_of(&a), value_of(&b));
    assert_eq!(value_of(&a), "10");
}

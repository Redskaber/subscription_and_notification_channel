//! B3 self-hosting Reader parity suite (Stage 1 batch B / MUV 24-c).
//!
//! Acceptance gate (plan §5 batch B, "B3 Reader rewritten in kerf"):
//! - **Byte-level parity**: the self-hosting Reader (kerf source,
//!   running on the VM) vs the seed Reader (Rust) over
//!   positive/negative/exotic corpora — Stx trees (recursive comparison
//!   of datum + Span, symbols compared by name) and errors (message +
//!   Span) byte-identical;
//! - **Error-ordering parity**: with dual error sources (numeric overflow +
//!   a later lexical error), the first-error position matches the seed
//!   (contract verification of the string-is-int up-front check);
//! - **Higher-order function direct tests**: map/filter/foldl/for-each
//!   (kerf source implementations) driven through the self-check face
//!   (builtins as f — cross-program-safe function values);
//! - **Reader primitives**: string-to-pos-chars / char-is-whitespace /
//!   char-is-alphabetic / string-is-int (including misuse negative
//!   cases);
//! - **Pipeline integration**: run/eval dual paths end to end through
//!   the self-hosting Reader.
//!
//! Clauses followed: §9.4.3 (paired positive/negative cases), §7.1 (≥3
//! integration verifications), §2.3-11 (measure first, do not guess —
//! all assertions compare real runs of both implementations).

use kerf_driver::bootstrap::{
    lex_source, read_source, selfcheck_call, selfcheck_list, selfcheck_render,
};
use kerf_reader::{lex_source as seed_lex, read_source as seed_read, TokenKind};
use kerf_runtime::RuntimeError;
use kerf_syntax::{Stx, StxDatum, StxLiteral, SymbolTable};
use kerf_vm::{BuiltinFn, Value};

// ---- parity walk-through ----

/// Stx tree equivalence (recursive over datum + Span; symbols by name —
/// the two implementations do not guarantee consistent intern ordering,
/// so names are the only stable criterion).
fn stx_equiv(a: &Stx, ta: &SymbolTable, b: &Stx, tb: &SymbolTable) -> Result<(), String> {
    if a.span.start != b.span.start || a.span.end != b.span.end {
        return Err(format!(
            "Span mismatch: ({},{}) vs ({},{})",
            a.span.start, a.span.end, b.span.start, b.span.end
        ));
    }
    match (&a.datum, &b.datum) {
        (StxDatum::Symbol(x), StxDatum::Symbol(y)) => {
            if ta.name(*x) != tb.name(*y) {
                return Err(format!(
                    "symbol name mismatch: {} vs {}",
                    ta.name(*x),
                    tb.name(*y)
                ));
            }
            Ok(())
        }
        (StxDatum::Literal(x), StxDatum::Literal(y)) => match (x, y) {
            (StxLiteral::Int(p), StxLiteral::Int(q)) => (p == q)
                .then_some(())
                .ok_or_else(|| format!("int mismatch: {} vs {}", p, q)),
            (StxLiteral::Float(p), StxLiteral::Float(q)) => {
                // Same-origin parse (decimal→binary correctly rounded) →
                // bit-identical; inf==inf holds
                (p == q || (p.is_nan() && q.is_nan()))
                    .then_some(())
                    .ok_or_else(|| format!("float mismatch: {} vs {}", p, q))
            }
            (StxLiteral::Str(p), StxLiteral::Str(q)) => (p == q)
                .then_some(())
                .ok_or_else(|| format!("str mismatch: {:?} vs {:?}", p, q)),
            (StxLiteral::Bool(p), StxLiteral::Bool(q)) => (p == q)
                .then_some(())
                .ok_or_else(|| format!("bool mismatch: {} vs {}", p, q)),
            (StxLiteral::Nil, StxLiteral::Nil) => Ok(()),
            _ => Err(format!("literal kind mismatch: {:?} vs {:?}", x, y)),
        },
        (StxDatum::List(xs), StxDatum::List(ys)) | (StxDatum::Vector(xs), StxDatum::Vector(ys)) => {
            if xs.len() != ys.len() {
                return Err(format!(
                    "element count mismatch: {} vs {}",
                    xs.len(),
                    ys.len()
                ));
            }
            for (i, (x, y)) in xs.iter().zip(ys.iter()).enumerate() {
                stx_equiv(x, ta, y, tb).map_err(|e| format!("[{}]: {}", i, e))?;
            }
            Ok(())
        }
        _ => Err(format!(
            "datum kind mismatch: {} vs {}",
            a.datum.kind_name(),
            b.datum.kind_name()
        )),
    }
}

/// Single-source parity assertion: the read path (positive cases —
/// tree equivalence; negative cases — message + Span equivalence;
/// outcome shapes agree).
fn assert_read_parity(source: &str) {
    let mut ta = SymbolTable::new();
    let mut tb = SymbolTable::new();
    let ra = seed_read(source, 0, &mut ta);
    let rb = read_source(source, 0, &mut tb);
    match (&ra, &rb) {
        (Ok(fa), Ok(fb)) => {
            assert_eq!(
                fa.len(),
                fb.len(),
                "top-level form count mismatch: {}(source {:?})",
                source,
                source
            );
            for (i, (x, y)) in fa.iter().zip(fb.iter()).enumerate() {
                stx_equiv(x, &ta, y, &tb).unwrap_or_else(|e| {
                    panic!(
                        "parity failed(# {} form): {}\n source: {:?}",
                        i + 1,
                        e,
                        source
                    )
                });
            }
        }
        (Err(ea), Err(eb)) => {
            assert_eq!(
                ea.message, eb.message,
                "error message mismatch\n source: {:?}\n seed:{:?}\n bootstrap:{:?}",
                source, ea.message, eb.message
            );
            assert_eq!(
                (ea.span.start, ea.span.end),
                (eb.span.start, eb.span.end),
                "error Span mismatch\n source: {:?}",
                source
            );
        }
        _ => panic!(
            "result form mismatch(one side Ok one side Err)\n source: {:?}\n seed:{:?}\n bootstrap:{:?}",
            source,
            ra.map(|_| "Ok"),
            rb.map(|_| "Ok")
        ),
    }
}

/// Negative-case parity assertion: the seed does error (guarding
/// against accidentally including a positive case in the corpus) +
/// both implementations agree.
fn assert_negative_parity(source: &str) {
    let mut t = SymbolTable::new();
    assert!(
        seed_read(source, 0, &mut t).is_err(),
        "negative case corpus mistake receive(seed read succeeded): {:?}",
        source
    );
    assert_read_parity(source);
}

// ---- Positive corpus (forms parity) ----

/// Corpus sources: the full set of seed reader unit/integration cases +
/// exotic-boundary extensions.
#[test]
fn parity_forms_positive() {
    let corpus = [
        "42",
        "(+ 1 2)",
        "(define x 1)",
        "(+ 1 (* 2 3))",
        "(define (f x) (+ x 1)) (f 41)",
        "'x",
        "'(1 2 3)",
        "(quote x)",
        "(quote (a b (c 1 \"s\" true nil)))",
        "'(quote x)",
        "[1 2 3]",
        "fn",
        "lambdax",
        "true false nil",
        "\"a\\nb\\nc\"",
        "3 3.5 1e3 -5 -5.5 +7",
        "+ - * / <= >= = mod < >",
        "; line comment\n(+ 1 2) ; endnote\n#| block |# 3",
        "#| outer #| inner |# still in outer |# 42",
        "...",
        "..",
        "....",
        "...abc",
        "(a . b)",
        "\"héllo wörld\"",
        "(define é 1)",
        "é λ λx _x x' a? b! c$ d% e& f!o",
        "1e-3 1E+3 0.5",
        "-0",
        "9223372036854775807",
        "-9223372036854775808",
        "+9223372036854775807",
        "00009223372036854775807",
        "1e999",
        "",
        " \n; only comment\n",
        "(do 1)",
        "(define (make-adder n) (fn (x) (+ x n)))\n(define add5 (make-adder 5))\n(list (add5 10) (if (is-nil nil) 1 2))",
        "'é",
        "'λx",
    ];
    for src in corpus {
        assert_read_parity(src);
    }
}

// ---- Negative corpus (error message + Span parity) ----

#[test]
fn parity_reader_negative() {
    let corpus = [
        "(+ 1",
        "(+ 1 2]",
        "[1 2 3)",
        ")",
        "]",
        "123abc",
        "3-4",
        "(+ ~ 1)",
        "\"abc",
        "\"a\\q\"",
        "#| abc",
        "#| a #| b |# c",
        "1e",
        "1e+",
        "9223372036854775808",
        "-9223372036854775809",
        "99999999999999999999",
        "0009223372036854775808",
        "'",
        "' ",
        "(quote",
        ".",
        ". 5",
        "3.",
        "1.2.3",
        "(a b))",
        "(fn (x) x))",
        "1e3.5",
    ];
    for src in corpus {
        assert_negative_parity(src);
    }
}

// ---- Dual-error-ordering parity (first-error position contract) ----

#[test]
fn parity_dual_error_ordering() {
    // Numeric overflow + a later lexical error: the seed reports the
    // overflow first in scan order — the self-hosting Reader preserves
    // the same order via the string-is-int up-front check
    let corpus = [
        "(+ 99999999999999999999 ~)",
        "(* 9223372036854775808",
        "(+ 1 99999999999999999999abc)",
        "(+ 99999999999999999999",
        "(+ 99999999999999999999 1]",
    ];
    for src in corpus {
        assert_negative_parity(src);
    }
}

// ---- Unicode / NFC parity ----

#[test]
fn parity_unicode_and_nfc() {
    let corpus = [
        // Combining characters vs precomposed characters: both
        // implementations intern after normalization, same name
        "(define e\u{0301} 1) (define \u{00E9} 2)",
        "\u{00E9}",
        "e\u{0301}",
        // Spans of multibyte identifiers (byte offsets)
        "(é λ 你好)",
        // Multibyte preservation inside string contents
        "\"éλ你\"",
        // NNBSP and other exotic whitespace = Unicode whitespace (trivia)
        "(+ 1\u{00A0}2)",
    ];
    for src in corpus {
        assert_read_parity(src);
    }
}

// ---- Token stream parity (lexical layer: kinds + Spans) ----

#[test]
fn parity_token_stream_kinds_and_spans() {
    let corpus = [
        "(define x 1)",
        "(+ 12 ab)",
        "fn lambdax if iff",
        "3 3.5 1e3 -5 -5.5 +7",
        "+ - * / <= >= = mod < >",
        "\"a\\nb\nc\"",
        "true false nil",
        "'x",
        "[1 2 3]",
        "... ..",
        "é λ _x",
    ];
    for src in corpus {
        let mut ta = SymbolTable::new();
        let mut tb = SymbolTable::new();
        let seed_toks = seed_lex(src, 0, &mut ta).expect("seed lexical failed");
        let boot_toks = lex_source(src, 0, &mut tb).expect("bootstrap lexical failed");
        assert_eq!(
            seed_toks.len(),
            boot_toks.len(),
            "Token count mismatch\n source: {:?}",
            src
        );
        for (i, (x, y)) in seed_toks.iter().zip(boot_toks.iter()).enumerate() {
            assert_eq!(
                (x.span.start, x.span.end),
                (y.span.start, y.span.end),
                "Token[{}] Span mismatch\n source: {:?}",
                i,
                src
            );
            token_kind_equiv(&x.kind, &ta, &y.kind, &tb).unwrap_or_else(|e| {
                panic!("Token[{}] kind mismatch: {}\n source: {:?}", i, e, src)
            });
        }
    }
}

/// TokenKind equivalence (symbols by name).
fn token_kind_equiv(
    a: &TokenKind,
    ta: &SymbolTable,
    b: &TokenKind,
    tb: &SymbolTable,
) -> Result<(), String> {
    use kerf_reader::Delimiter;
    match (a, b) {
        (TokenKind::Eof, TokenKind::Eof) => Ok(()),
        (TokenKind::IntLiteral(p), TokenKind::IntLiteral(q)) => (p == q)
            .then_some(())
            .ok_or_else(|| format!("int {} vs {}", p, q)),
        (TokenKind::FloatLiteral(p), TokenKind::FloatLiteral(q)) => (p == q)
            .then_some(())
            .ok_or_else(|| format!("float {} vs {}", p, q)),
        (TokenKind::StringLiteral(p), TokenKind::StringLiteral(q)) => (p == q)
            .then_some(())
            .ok_or_else(|| format!("str {:?} vs {:?}", p, q)),
        (TokenKind::BoolLiteral(p), TokenKind::BoolLiteral(q)) => (p == q)
            .then_some(())
            .ok_or_else(|| format!("bool {} vs {}", p, q)),
        (TokenKind::NilLiteral, TokenKind::NilLiteral) => Ok(()),
        (TokenKind::Identifier(p), TokenKind::Identifier(q)) => (ta.name(*p) == tb.name(*q))
            .then_some(())
            .ok_or_else(|| format!("ident {} vs {}", ta.name(*p), tb.name(*q))),
        (TokenKind::Keyword(p), TokenKind::Keyword(q)) => (p == q)
            .then_some(())
            .ok_or_else(|| format!("keyword {:?} vs {:?}", p, q)),
        (TokenKind::Operator(p, s), TokenKind::Operator(q, t)) => {
            if p == q && ta.name(*s) == tb.name(*t) {
                Ok(())
            } else {
                Err(format!(
                    "operator {:?}/{} vs {:?}/{}",
                    p,
                    ta.name(*s),
                    q,
                    tb.name(*t)
                ))
            }
        }
        (TokenKind::QuoteShorthand, TokenKind::QuoteShorthand) => Ok(()),
        (TokenKind::Delimiter(p), TokenKind::Delimiter(q)) => {
            let of = |d: &Delimiter| d.as_char();
            (of(p) == of(q))
                .then_some(())
                .ok_or_else(|| format!("delimiter {} vs {}", of(p), of(q)))
        }
        _ => Err(format!(
            "kind branch mismatch: {} vs {}",
            a.kind_name(),
            b.kind_name()
        )),
    }
}

// ---- dump format parity (mirror of the seed's format loop) ----

#[test]
fn parity_dump_tokens_format() {
    // The self-hosting dump is byte-identical to "seed Tokens + the same
    // dump_tokens format loop"
    let sources = ["(define x 1)", "(+ 12 ab) 'q", "\"s\\n\" [1 2] ; c\n"];
    for src in sources {
        let mut ta = SymbolTable::new();
        let seed_toks = seed_lex(src, 0, &mut ta).unwrap();
        let mut expected = String::new();
        for t in &seed_toks {
            let name = match &t.kind {
                TokenKind::Identifier(s) => ta.name(*s).to_string(),
                TokenKind::Keyword(k) => k.as_str().to_string(),
                TokenKind::Operator(o, s) => format!("{:?}({})", o, ta.name(*s)),
                other => format!("{:?}", other),
            };
            expected.push_str(&format!(
                "{:>4}..{:<4} {}\n",
                t.span.start, t.span.end, name
            ));
        }
        let actual = kerf_driver::dump_tokens(src, "t.krf").unwrap();
        assert_eq!(actual, expected, "dump mismatch\n source: {:?}", src);
    }
}

// ---- Nesting depth boundary ----

#[test]
fn parity_deep_nesting_boundary() {
    // 256 levels legal / 257 levels errors (defensive upper limit — same
    // as the seed)
    let ok_src = format!("{}1{}", "(".repeat(256), ")".repeat(256));
    assert_read_parity(&ok_src);
    let err_src = format!("{}1{}", "(".repeat(257), ")".repeat(257));
    assert_negative_parity(&err_src);
    // Mixed-bracket depth
    let mix_err = format!("{}1]{}", "(".repeat(300), "");
    assert_negative_parity(&mix_err);
}

// ---- Pipeline integration (end to end) ----

#[test]
fn bootstrap_pipeline_run_end_to_end() {
    // fib read by the self-hosting Reader → expanded → compiled →
    // executed on the VM (the production pipeline, full chain)
    let src = "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (fib 10)";
    let out = kerf_driver::run_source(src, "t.krf").unwrap();
    assert!(matches!(out.value, Value::Int(55)));
}

#[test]
fn bootstrap_pipeline_read_error_rendered() {
    // A read error through the self-hosting Reader → DriverError
    // rendering (stage + file name + excerpt)
    let err = kerf_driver::run_source("(+ 1", "bad.krf").unwrap_err();
    assert_eq!(err.stage, kerf_driver::Stage::Read);
    assert!(err.rendered.contains("unclosed"));
    assert!(err.rendered.contains("bad.krf"));
}

#[test]
fn bootstrap_pipeline_seed_path_agrees() {
    // T1 dual path (42-d updated criterion): production chain
    // (self-hosting Reader) vs seed chain (Rust Reader) — both chains
    // produce the same result
    let src = "(define (f x) (+ x 1)) (f 41)";
    let a = kerf_driver::run_source(src, "t.krf").unwrap();
    let b = kerf_driver::run_source_seed(src, "t.krf").unwrap();
    assert!(a.value.eq_value(&b.value));
}

#[test]
fn bootstrap_dump_stx_end_to_end() {
    let out = kerf_driver::dump_stx("(quote (1 2 3)) 'x", "t.krf").unwrap();
    assert!(out.contains("(quote (1 2 3))"));
    assert!(out.contains("(quote x)"));
}

// ---- Higher-order function direct tests (kerf source implementations driven ----
// ---- via the self-check face; builtins as f — cross-program safe) ----

#[test]
fn hof_map_with_builtin_function() {
    let inc = BuiltinFn::new("inc", |_, args| {
        let v = args
            .first()
            .and_then(|v| v.as_int())
            .ok_or_else(|| RuntimeError::new("requires int"))?;
        Ok(Value::Int(v + 1))
    });
    let lst = selfcheck_list(vec![Value::Int(1), Value::Int(2), Value::Int(3)]).unwrap();
    let r = selfcheck_call("map", vec![Value::Builtin(inc), lst]).unwrap();
    assert_eq!(selfcheck_render(&r).unwrap(), "(2 3 4)");
}

#[test]
fn hof_filter_with_builtin_predicate() {
    let is_bool = BuiltinFn::new("is-bool", |_, args| {
        Ok(Value::Bool(matches!(args.first(), Some(Value::Bool(_)))))
    });
    let lst = selfcheck_list(vec![Value::Bool(true), Value::Int(1), Value::Bool(false)]).unwrap();
    let r = selfcheck_call("filter", vec![Value::Builtin(is_bool), lst]).unwrap();
    assert_eq!(selfcheck_render(&r).unwrap(), "(true false)");
}

#[test]
fn hof_foldl_with_builtin_function() {
    let add2 = BuiltinFn::new("add2", |_, args| {
        let a = args.first().and_then(|v| v.as_int()).unwrap_or(0);
        let b = args.get(1).and_then(|v| v.as_int()).unwrap_or(0);
        Ok(Value::Int(a + b))
    });
    let lst = selfcheck_list(vec![Value::Int(1), Value::Int(2), Value::Int(3)]).unwrap();
    let r = selfcheck_call("foldl", vec![Value::Builtin(add2), Value::Int(0), lst]).unwrap();
    assert_eq!(selfcheck_render(&r).unwrap(), "6");
}

#[test]
fn hof_for_each_returns_nil() {
    let nop = BuiltinFn::new("nop", |_, _| Ok(Value::Nil));
    let nop2 = nop.clone();
    let lst = selfcheck_list(vec![Value::Int(1), Value::Int(2)]).unwrap();
    let r = selfcheck_call("for-each", vec![Value::Builtin(nop), lst]).unwrap();
    assert!(matches!(r, Value::Nil));
    // Empty list is the identity
    let empty = selfcheck_list(vec![]).unwrap();
    let r2 = selfcheck_call("map", vec![Value::Builtin(nop2), empty]).unwrap();
    assert!(
        matches!(r2, Value::Nil),
        "map empty table should return nil"
    );
}

#[test]
fn hof_map_empty_list_identity() {
    let id = BuiltinFn::new("id", |_, args| {
        Ok(args.first().cloned().unwrap_or(Value::Nil))
    });
    let empty = selfcheck_list(vec![]).unwrap();
    let r = selfcheck_call("map", vec![Value::Builtin(id), empty]).unwrap();
    assert!(matches!(r, Value::Nil));
}

// ---- Reader primitives (including misuse negative cases) ----

#[test]
fn reader_primitive_str_pos_chars() {
    // Offsets + single characters + the empty string
    let lst = selfcheck_list(vec![]).unwrap(); // just to initialize state
    let _ = lst;
    let r = selfcheck_call("string-to-pos-chars", vec![strv("aéb")]).unwrap();
    let rendered = selfcheck_render(&r).unwrap();
    // Renders as ((0 . a) (1 . é) (3 . b)) — offsets in bytes (Str
    // rendering carries no quotes)
    assert!(rendered.contains("(0 . a)"), "render: {}", rendered);
    assert!(rendered.contains("(1 . é)"), "render: {}", rendered);
    assert!(rendered.contains("(3 . b)"), "render: {}", rendered);
    // Empty string → nil
    let r2 = selfcheck_call("string-to-pos-chars", vec![strv("")]).unwrap();
    assert!(matches!(r2, Value::Nil));
}

#[test]
fn reader_primitive_str_pos_chars_negative() {
    // Non-string argument → structured error (error over silence)
    let e = selfcheck_call("string-to-pos-chars", vec![Value::Int(1)]).unwrap_err();
    assert!(e.message.contains("requires str"), "message: {}", e.message);
    // Arity error
    let e2 = selfcheck_call("string-to-pos-chars", vec![strv("a"), strv("b")]).unwrap_err();
    assert!(
        e2.message.contains("1 arguments") || e2.message.contains("argument"),
        "message: {}",
        e2.message
    );
}

#[test]
fn reader_primitive_char_predicates() {
    // Predicate primitives: the normal path
    let ws = selfcheck_call("char-is-whitespace", vec![strv(" ")]).unwrap();
    assert!(matches!(ws, Value::Bool(true)));
    let ws2 = selfcheck_call("char-is-whitespace", vec![strv("\u{00A0}")]).unwrap();
    assert!(matches!(ws2, Value::Bool(true)), "NNBSP is Unicode blank");
    let ws3 = selfcheck_call("char-is-whitespace", vec![strv("a")]).unwrap();
    assert!(matches!(ws3, Value::Bool(false)));
    let al = selfcheck_call("char-is-alphabetic", vec![strv("λ")]).unwrap();
    assert!(matches!(al, Value::Bool(true)), "λ is letter");
    let al2 = selfcheck_call("char-is-alphabetic", vec![strv("1")]).unwrap();
    assert!(matches!(al2, Value::Bool(false)));
}

#[test]
fn reader_primitive_char_predicates_negative() {
    // Multi-character → explicit rejection; non-string → type error
    let e = selfcheck_call("char-is-whitespace", vec![strv("ab")]).unwrap_err();
    assert!(e.message.contains("1 character"), "message: {}", e.message);
    let e2 = selfcheck_call("char-is-alphabetic", vec![Value::Int(1)]).unwrap_err();
    assert!(
        e2.message.contains("requires str"),
        "message: {}",
        e2.message
    );
    let e3 = selfcheck_call("char-is-whitespace", vec![Value::Bool(true)]).unwrap_err();
    assert!(
        e3.message.contains("requires str"),
        "message: {}",
        e3.message
    );
}

#[test]
fn reader_primitive_str_int_valid() {
    // The i64 domain check = Rust parse semantics verbatim (host type
    // boundary)
    let cases = [
        ("9223372036854775807", true),
        ("9223372036854775808", false),
        ("-9223372036854775808", true),
        ("-9223372036854775809", false),
        ("+7", true),
        ("000005", true),
        ("", false),
    ];
    for (text, expect) in cases {
        let r = selfcheck_call("string-is-int", vec![strv(text)]).unwrap();
        assert!(
            matches!(r, Value::Bool(b) if b == expect),
            "string-is-int({:?}) expected {}",
            text,
            expect
        );
    }
}

#[test]
fn reader_primitive_str_int_valid_negative() {
    let e = selfcheck_call("string-is-int", vec![Value::Int(3)]).unwrap_err();
    assert!(e.message.contains("requires str"), "message: {}", e.message);
}

// ---- Helpers: test-local Value construction ----

/// String value construction (Rc<str>).
fn strv(s: &str) -> Value {
    Value::Str(std::rc::Rc::from(s))
}

/// StxDatum kind names (for diagnostics).
trait DatumKindName {
    fn kind_name(&self) -> &'static str;
}

impl DatumKindName for StxDatum {
    fn kind_name(&self) -> &'static str {
        match self {
            StxDatum::Symbol(_) => "symbol",
            StxDatum::Literal(_) => "literal",
            StxDatum::List(_) => "list",
            StxDatum::Vector(_) => "vector",
        }
    }
}

trait TokenKindBridge {
    fn kind_name(&self) -> &'static str;
}

impl TokenKindBridge for TokenKind {
    fn kind_name(&self) -> &'static str {
        match self {
            TokenKind::Eof => "eof",
            TokenKind::IntLiteral(_) => "int",
            TokenKind::FloatLiteral(_) => "float",
            TokenKind::StringLiteral(_) => "str",
            TokenKind::BoolLiteral(_) => "bool",
            TokenKind::NilLiteral => "nil",
            TokenKind::Identifier(_) => "identifier",
            TokenKind::Keyword(_) => "keyword",
            TokenKind::Operator(..) => "operator",
            TokenKind::QuoteShorthand => "quote",
            TokenKind::Delimiter(_) => "delimiter",
            TokenKind::MacroInvocation(_) => "macro",
        }
    }
}

// ---- Systematic negative-case matrix (§9.4.3 global positive:negative
// ---- ratio ≥1:3 maintained; every case locks byte-level error parity on
// ---- both implementations + a seed-does-error assertion) ----

#[test]
fn parity_negative_battery_brackets() {
    // Unclosed-depth scan 1..30 (open parens + content + EOF)
    for k in 1..=30 {
        assert_negative_parity(&format!("{}1", "(".repeat(k)));
    }
    // Unclosed (variants with content)
    for src in [
        "(+ 1",
        "(+ 1 2",
        "(define (x",
        "(\"s\"",
        "(quote \"s",
        "[quote 1",
        "(fn (x",
        "(do (+ 1",
        "[let [x",
        "(1 (2",
        "((",
        "[[",
        "([",
        "[(",
    ] {
        assert_negative_parity(src);
    }
    // Bracket-mismatch matrix (mismatched pairs among the open × close
    // combinations) + nested mismatches
    for src in [
        "(1]", "[1)", "((1]]", "[[1))", "([1]", "[(1)", "(+ 1 2]", "[+ 1 2)", "(a b c]", "[a b c)",
        "((a] b)",
    ] {
        assert_negative_parity(src);
    }
    // Extra closing brackets (standalone and trailing)
    for src in [
        ")", "]", "))", ")]", ")))", "(1))", "((1)))", "1)", "x]", "(+ 1 2))",
    ] {
        assert_negative_parity(src);
    }
}

#[test]
fn parity_negative_battery_strings() {
    // Illegal escape characters (outside the six-member set n/t/r/\\//"/0)
    for c in [
        "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "o", "p", "q", "s", "u",
        "v", "w", "x", "y", "z", "A", "Z", "!", "?", "_", "1", "é", "λ", " ",
    ] {
        assert_negative_parity(&format!("\"\\{}\"", c));
    }
    // Illegal escapes with content + multibyte escapes (Span in
    // byte-by-byte terms) + a bare backslash
    for src in [
        "\"ab\\q\"",
        "\"a\\db\"",
        "\"\\é\"",
        "\"x\\λ\"",
        "before \\q after",
    ] {
        assert_negative_parity(src);
    }
    // Backslash followed by EOF / unclosed combined with escapes
    for src in ["\"abc\\", "\"a\\n\\", "\"\\", "(\"]\\", "'\"\\"] {
        assert_negative_parity(src);
    }
}

#[test]
fn parity_negative_battery_numbers() {
    // Exponent missing digits (e/eE/sign with no digits after)
    for src in [
        "1e", "1E", "1e+", "1e-", "1E+", "1E-", "1e+x", "12e", "1.5e", "0.5e-", "1.2.3", "3.",
        "1e3.5", "3.5.5", "00.5.5",
    ] {
        assert_negative_parity(src);
    }
    // Greedy-number rejection: digit × identifier-character matrix
    // (10 digits × 5 character classes)
    for d in ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"] {
        for c in ["a", "_", "é", "λ", "+"] {
            assert_negative_parity(&format!("{}{}", d, c));
        }
    }
    // Greedy rejection (with context)
    for src in ["123abc", "(+ 123abc 1)", "1x", "-1z", "+9a", "0b1", "1_2"] {
        assert_negative_parity(src);
    }
    // Overflow scan: strings of 9s of length 19..26 × unsigned/+/-
    for len in 19..=26 {
        let nines = "9".repeat(len);
        assert_negative_parity(&nines);
        assert_negative_parity(&format!("+{}", nines));
        assert_negative_parity(&format!("-{}", nines));
    }
    // One step outside the boundary (max+1 / min-1)
    for src in [
        "9223372036854775808",
        "-9223372036854775809",
        "+9223372036854775808",
        "09223372036854775808",
        "00092233720368547758080",
    ] {
        assert_negative_parity(src);
    }
}

#[test]
fn parity_negative_battery_illegal_chars() {
    // Illegal characters (in no Token start set): standalone and in
    // context
    for ch in ["~", "@", ",", ":", "^", "`", "\\", "|"] {
        assert_negative_parity(ch);
        assert_negative_parity(&format!("(+ {} 1)", ch));
        assert_negative_parity(&format!("x{}", ch));
    }
    // Single dot (. not followed by .) and isolated #
    for src in [".", ". 5", "5 .", "(+ . 1)", "1 . 2", "#", "#x", "a # b"] {
        assert_negative_parity(src);
    }
}

#[test]
fn parity_negative_battery_dual_errors() {
    // Overflow + later error (first error = overflow — scan-order parity)
    let big = "9".repeat(22);
    for tail in [" ~)", " ~", "]", ")", " z", " \"s"] {
        assert_negative_parity(&format!("(+ {}{}", big, tail));
    }
    // Earlier lexical error + later overflow (first error = the earlier
    // one)
    assert_negative_parity(&format!("(~ (+ {}))", big));
    assert_negative_parity(&format!("\"unclosed (+ {})", big));
    // Overflow + unclosed
    assert_negative_parity(&format!("(define x {}", big));
}

#[test]
fn parity_negative_battery_comments_and_eof() {
    // Unclosed block comments (nesting depth 1..5)
    for depth in 1..=5 {
        let mut src = String::new();
        for _ in 0..depth {
            src.push_str("#| ");
        }
        assert_negative_parity(&src);
    }
    // Partially closed nesting
    assert_negative_parity("#| outer #| inner |# still in outer");
    assert_negative_parity("#| a #| b |# c #| d");
    // Unclosed after a comment swallows the open bracket
    assert_negative_parity("(#| a");
    assert_negative_parity("(+ 1 #| 2");
    // Extra close after a comment
    assert_negative_parity("#| c |# )");
    assert_negative_parity("#|c|# ]");
    // EOF after a quote mark
    assert_negative_parity("'");
    assert_negative_parity("'");
    assert_negative_parity("' ");
    assert_negative_parity("(quote ");
    assert_negative_parity("(define x '");
}

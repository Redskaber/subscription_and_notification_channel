// E6 close-out (r154 / 224-b5): converted to the target-syntax face.
//! Capability-model I/O basic-pass integration tests (r8 batch D — D2:
//! each of the four clauses of the 13 §3.1.3 spec locked end to end).
//!
//! Coverage (§9.4.3 positive:negative ratio ≥1:3 — this suite is mostly
//! negative):
//! - Clause 3 (compile-time authorization verification): E0006 fully in
//!   effect on all four paths run/eval/check/compile (the front
//!   pipeline's single verification point — the pipeline-face proof of
//!   "any pipeline node");
//! - Declaration face `require io, read|write;`: positive semantics +
//!   shape negative cases (unknown subject / unknown capability /
//!   missing arguments; the S-expr non-symbol item row `(require io
//!   "read")` retired — a string literal in the require list is an
//!   E0001 read-stage rejection on the target grammar, the
//!   expand-stage symbol-shape error is unrepresentable; record:
//!   224-b5, 1 row);
//! - Token gating: undeclared programs do not register I/O builtins
//!   (fail-closed) + authorization-face consistency;
//! - Hygiene fallback boundary: the base-name judgment of I/O references
//!   inside macro templates;
//! - User-takeover exemption: a same-named define is not a false positive
//!   (zero-false-positive discipline);
//! - examples/usage/io.ktf executed for real (require-declaration form —
//!   r153 / 223-c: the corpus leg switched to the .ktf single face).

use kerf_driver::{check_source_recover, run_source, run_source_seed, Stage};
use kerf_vm::Value;

const FNAME: &str = "cap.ktf";

#[allow(clippy::result_large_err)] // test helper — large error path OK (driver convention)
fn run(src: &str) -> Result<kerf_driver::RunOutcome, kerf_driver::DriverError> {
    run_source(src, FNAME)
}

// ---------------------------------------------------------------------------
// Positive: usable after declaration (the authorization chain of clauses 1/2/4)
// ---------------------------------------------------------------------------

/// require + print: the write path fully open (token capture +
/// StdCapabilityIO).
#[test]
fn declared_write_io_runs() {
    let o = run("require io, write;\nprint(42)").unwrap();
    assert!(matches!(o.value, Value::Nil));
}

/// require + newline: the zero-argument write builtin is usable.
#[test]
fn declared_newline_runs() {
    let o = run("require io, write;\nnewline()").unwrap();
    assert!(matches!(o.value, Value::Nil));
}

/// require with dual read/write declaration: the write path fully open
/// (the read path is covered by the EOF subprocess probe — calling
/// `read_line()` directly in-process would block on real stdin,
/// non-deterministic, forbidden).
#[test]
fn declared_read_write_both() {
    let o = run("require io, read, write;\nprint(1)").unwrap();
    assert!(matches!(o.value, Value::Nil));
}

/// read-line EOF convention path (deterministic subprocess probe: the
/// program is passed via a temp file, stdin = null device → read-line
/// immediately sees EOF → nil; independent of the test runner's stdin
/// shape — the §2.3 determinism boundary comes first). r153 / 223-c: the
/// probe switched to the .ktf single face (the CLI .krf entry retired —
/// s-expr-removal-plan §4 Batch D).
#[test]
fn read_line_eof_returns_nil_via_subprocess() {
    use std::process::{Command, Stdio};
    let tmp = std::env::temp_dir().join("kerf-cap-eof-probe.ktf");
    std::fs::write(&tmp, "require io, read;\nread_line()").expect("write input probe program");
    let out = Command::new(env!("CARGO_BIN_EXE_kerf"))
        .args(["run", tmp.to_str().unwrap()])
        .stdin(Stdio::null())
        .output()
        .expect("should can start kerf sub process");
    let stdout = String::from_utf8_lossy(&out.stdout);
    assert!(
        out.status.success(),
        "EOF read should succeed, stderr: {}",
        String::from_utf8_lossy(&out.stderr)
    );
    assert!(
        stdout.contains("nil"),
        "EOF read should yield nil, got: {}",
        stdout
    );
    let _ = std::fs::remove_file(&tmp);
}

/// require evaluates to nil + dual-path agreement (T1 updated criterion
/// 42-d: production chain and seed chain under the same rule — require
/// has zero runtime semantics).
#[test]
fn require_form_evals_nil_both_paths() {
    let a = run("require io, write;").unwrap();
    let b = run_source_seed("require io, write;", FNAME).unwrap();
    assert!(matches!(a.value, Value::Nil));
    assert!(matches!(b.value, Value::Nil));
}

/// Declaration idempotence (repeated require, set semantics).
#[test]
fn duplicate_require_is_idempotent() {
    let o = run("require io, write;\nrequire io, write;\nprint(9)").unwrap();
    assert!(matches!(o.value, Value::Nil));
}

/// Order-independent: require still satisfies when it appears after the
/// reference (compile-time set judgment, not ordering).
#[test]
fn require_after_use_still_passes() {
    let o = run("print(3);\nrequire io, write;").unwrap();
    assert!(matches!(o.value, Value::Nil));
}

/// check path: the require program has zero diagnostics + the report
/// carries the declaration observation.
#[test]
fn check_report_includes_io_requirements() {
    let r = check_source_recover("require io, write;\nlet x = 1;\nx", FNAME).unwrap();
    assert!(r.diagnostics.is_empty());
    assert!(
        r.io_write,
        "CheckReport should observation write declaration"
    );
    assert!(!r.io_read);
}

/// examples/usage/io.ktf executed for real (a living sample in the
/// require-declaration form; r153 / 223-c: the corpus leg switched to
/// the .ktf single face — the .krf corpus retired, s-expr-removal-plan
/// §4 Batch D; relative paths resolved against the workspace root as cwd —
/// same rule as the example anchors in typecheck_tests).
#[test]
fn example_io_ktf_runs() {
    let src = std::fs::read_to_string("examples/usage/io.ktf").unwrap();
    let o = run_source(&src, "io.ktf").unwrap();
    assert!(matches!(o.value, Value::Int(42)));
}

// ---------------------------------------------------------------------------
// Negative: E0006 compile-time authorization verification (clause 3 — four paths + boundaries)
// ---------------------------------------------------------------------------

/// Undeclared print → E0006 (run path; a compile-time stage error, not
/// a runtime unbound).
#[test]
fn undeclared_print_is_compile_error() {
    let e = run("print(42)").unwrap_err();
    assert_eq!(e.stage, Stage::Compile);
    assert_eq!(e.diagnostic.code, Some(kerf_span::DiagnosticCode(6)));
    assert!(e.rendered.contains("error[E0006]"));
    assert!(e.rendered.contains("(require io write)"));
}

/// Undeclared read family → E0006 (read capability granularity).
#[test]
fn undeclared_read_is_compile_error() {
    let e = run("read_line()").unwrap_err();
    assert_eq!(e.stage, Stage::Compile);
    assert!(e.rendered.contains("(require io read)"));
}

/// Declaring read does not open write (least privilege — granularity
/// is mutually exclusive).
#[test]
fn read_declaration_does_not_open_write() {
    let e = run("require io, read;\nprint(1)").unwrap_err();
    assert_eq!(e.stage, Stage::Compile);
    assert!(e.rendered.contains("write"));
}

/// Seed chain gated identically (the front's single verification point
/// — any pipeline node on the pipeline face; 42-d criterion migration).
#[test]
fn seed_path_gated_identically() {
    let e = run_source_seed("print(1)", FNAME).unwrap_err();
    assert_eq!(e.stage, Stage::Compile);
    assert!(e.rendered.contains("error[E0006]"));
}

/// check path gated identically (the diagnostic chains do not cross:
/// compile-time errors come first).
#[test]
fn check_path_gated_identically() {
    let e = check_source_recover("newline()", FNAME).unwrap_err();
    assert_eq!(e.stage, Stage::Compile);
    assert!(e.rendered.contains("error[E0006]"));
}

/// References nested deep (inside a fn body + conditional branches) are
/// still captured statically.
#[test]
fn nested_reference_gated() {
    let src = "fn f() { || { if (true) { print(1) } else { 2 } } }";
    let e = run(src).unwrap_err();
    assert_eq!(e.stage, Stage::Compile);
    assert!(e.rendered.contains("print"));
}

/// I/O references inside macro templates: hygiene base-name fallback
/// judgment (same rule as the runtime fallback).
#[test]
fn macro_template_io_reference_gated() {
    let src = r#"
        macro shout { (v) => print(v) }
        shout(1)
    "#;
    let e = run(src).unwrap_err();
    assert_eq!(e.stage, Stage::Compile);
    assert!(
        e.rendered.contains("print"),
        "macro template inner quote use must by base name gating"
    );
}

// ---------------------------------------------------------------------------
// Negative: require shape (expansion-stage E2 family)
// ---------------------------------------------------------------------------

/// Missing arguments: `require io;` → expansion error.
#[test]
fn require_missing_capability_args() {
    let e = run("require io;").unwrap_err();
    assert_eq!(e.stage, Stage::Expand);
    assert!(e.rendered.contains("require form"));
}

/// Unknown subject: `require net, read;` → unknown-subject error (Stage
/// 2 extension-face hint).
#[test]
fn require_unknown_subject() {
    let e = run("require net, read;").unwrap_err();
    assert_eq!(e.stage, Stage::Expand);
    assert!(e.rendered.contains("unknown capability subject"));
}

/// Unknown capability item: `require io, fly;` → unknown-capability
/// error.
#[test]
fn require_unknown_capability() {
    let e = run("require io, fly;").unwrap_err();
    assert_eq!(e.stage, Stage::Expand);
    assert!(e.rendered.contains("unknown capability item"));
}

// ---------------------------------------------------------------------------
// Boundaries: takeover exemption + authorization-face consistency (zero-false-positive discipline)
// ---------------------------------------------------------------------------

/// User takeover: after `define(print, 5);` references are not flagged
/// (a user global).
#[test]
fn user_takeover_exempt() {
    let o = run("let print = 5;\nprint").unwrap();
    assert!(matches!(o.value, Value::Int(5)));
}

/// An alias definition referencing the builtin on the value side:
/// declaration still required (not a takeover).
#[test]
fn alias_value_reference_gated() {
    let e = run("let my_print = print;").unwrap_err();
    assert_eq!(e.stage, Stage::Compile);
    assert!(e.rendered.contains("print"));
}

/// Tokens are not constructible from outside (boundary proof of
/// unforgeability — an external crate can reference the types but
/// cannot instantiate them; mirrors the reserved.rs unit tests).
#[test]
fn capability_tokens_unforgeable_from_outside() {
    fn takes_read(_cap: &kerf_driver::ReadCapability) {}
    fn takes_write(_cap: &kerf_driver::WriteCapability) {}
    let _ = (
        takes_read as fn(&kerf_driver::ReadCapability),
        takes_write as fn(&kerf_driver::WriteCapability),
    );
}

/// IoRequirements public observation face (the external consumption
/// shape of from_core).
#[test]
fn io_requirements_public_observation() {
    let req = kerf_driver::IoRequirements::default();
    assert!(req.is_empty());
    assert_eq!(req.render(), "(undeclared)");
}

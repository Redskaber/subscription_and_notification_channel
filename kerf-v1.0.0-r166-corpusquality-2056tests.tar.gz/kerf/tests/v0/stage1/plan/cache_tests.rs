// E6 close-out (r154 / 224-b5): converted to the target-syntax face.
//! Compilation cache integration tests (tests/v0/stage1/plan/cache_tests.rs ↔
//! kerf-driver/src/cache.rs + hash.rs ↔ 13-capability matrix §3.1.4
//! three-method spec).
//!
//! Batch C (25-b): content-addressed keys / trait behavior specs 1-3 /
//! pipeline-reuse equivalence (the acceptance surface of §21.3 Stage 1
//! condition 4, "incremental compilation infrastructure available").
//!
//! Thread isolation: the cache is thread_local — each #[test] runs on
//! its own thread and is naturally isolated (zero cross-test pollution;
//! multiple calls within one test share the session cache).
//!
//! E6 rework (r154 / 224-b5 — s-expr-removal-plan §4 E6): the sole
//! production consumer of the pipeline-rich cache face
//! (`compile_front_cached`) was deleted with the S-expr surface — the
//! production run/check path is now cache-free (the Front entry kind
//! dormant, cache.rs "E6 dormancy" note; the target-path cache extension
//! is the registered trigger-gated follow-up). The pipeline-integration
//! group below is reworked accordingly: the production-path cache-hit
//! assertions → the InMemoryCompilationCache direct API (store/get via
//! the thread-local session) + the E6 dormancy anchors (the production
//! path leaves the session cache untouched) + the seed-path isolation
//! face (`run_source_seed`); the frozen-trait tests (clauses
//! 1/2/3) keep their standalone-instance shape.

use kerf_driver::{
    cache_enabled, cache_entry_count, cache_invalidate_all, cache_key, cache_reset, cache_stats,
    check_source_recover, compile_source, run_source, run_source_seed, set_cache_enabled,
    CompilerKind, InMemoryCompilationCache,
};
use kerf_driver::{sha256_hex, CacheKey, CachedResult, CompilationCache};

// ---------------------------------------------------------------------------
// SHA-256 (the correctness root of content addressing — re-verified via the public API)
// ---------------------------------------------------------------------------

/// NIST standard vectors (cross-crate public API surface — mirror
/// anchors of the hash.rs unit tests).
#[test]
fn sha256_public_api_vectors() {
    assert_eq!(
        sha256_hex(b""),
        "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    );
    assert_eq!(
        sha256_hex(b"abc"),
        "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
    );
}

// ---------------------------------------------------------------------------
// Frozen trait behavior specs (13 §3.1.4 clauses 1/2/3 — direct tests on standalone instances)
// ---------------------------------------------------------------------------

/// Clauses 1+2: store → get hits; idempotent overwrite; same-key
/// artifacts are equivalent.
#[test]
fn trait_spec_store_get_idempotent() {
    let mut c = InMemoryCompilationCache::new();
    let key = cache_key("1 + 2", "spec.ktf", CompilerKind::Bootstrap);
    assert!(c.get_cached(&key).is_none(), "empty cache not should hit");
    // Stored via a real pipeline artifact (trait surface)
    let out = compile_source("1 + 2", "spec.ktf").expect("compile failed");
    c.store(
        key.clone(),
        CachedResult {
            program: out.program.clone(),
            core: out.core.clone(),
            code_value: None,
        },
    );
    let got = c.get_cached(&key).expect("store should hit after");
    assert_eq!(
        got.program, out.program,
        "artifact level hit must verbatim segment equivalent"
    );
    assert_eq!(got.core.len(), out.core.len());
    // Clause 2: idempotent — overwriting the same key adds no entry
    c.store(
        key.clone(),
        CachedResult {
            program: out.program,
            core: out.core,
            code_value: None,
        },
    );
    assert_eq!(c.entry_count(), 1);
}

/// Clause 3: invalidate explicitly invalidates (single key).
#[test]
fn trait_spec_invalidate() {
    let mut c = InMemoryCompilationCache::new();
    let key = cache_key(
        "if (true) { 1 } else { 2 }",
        "inv.ktf",
        CompilerKind::Bootstrap,
    );
    let out = compile_source("if (true) { 1 } else { 2 }", "inv.ktf").expect("compile failed");
    c.store(
        key.clone(),
        CachedResult {
            program: out.program,
            core: out.core,
            code_value: None,
        },
    );
    assert!(c.get_cached(&key).is_some());
    c.invalidate(&key);
    assert!(
        c.get_cached(&key).is_none(),
        "invalidated after should not in"
    );
}

/// Key semantics: source change → key change (spec: source changes are
/// naturally discriminated by the key hash).
#[test]
fn key_discriminates_source_and_location() {
    let k1 = cache_key("1 + 2", "a.ktf", CompilerKind::Bootstrap);
    let k1b = cache_key("1 + 2", "a.ktf", CompilerKind::Bootstrap);
    let k2 = cache_key("1 + 3", "a.ktf", CompilerKind::Bootstrap);
    let k3 = cache_key("1 + 2", "b.ktf", CompilerKind::Bootstrap);
    assert_eq!(
        k1, k1b,
        "same source same position → same key(content addressing)"
    );
    assert_ne!(k1, k2, "source change → key change");
    assert_ne!(
        k1, k3,
        "file name reference and configuration fingerprint(SourceMap position consistency)"
    );
}

// ---------------------------------------------------------------------------
// Pipeline integration (E6-reworked: the direct-API reuse face + the
// dormancy/isolation anchors — the production run/check path is
// cache-free since compile_front_cached's deletion)
// ---------------------------------------------------------------------------

/// Same source executed twice: the results are byte-identical (reuse
/// safety) + the session cache stays untouched by the production path
/// (E6 dormancy: `run_source` never consults the cache — misses
/// 0 / stores 0) + the direct-API artifact face: store → get_cached hit
/// with byte-identical artifacts.
#[test]
fn pipeline_run_twice_hits_and_equivalent() {
    cache_reset();
    let src = "fn f(x: T) { x * 2 } f(21)";
    let first = run_source(src, "cache-a.ktf").expect("first execution failed");
    let second = run_source(src, "cache-a.ktf").expect("second execution failed");
    assert_eq!(
        kerf_vm::render_value(&first.value, &first.heap),
        kerf_vm::render_value(&second.value, &second.heap),
        "hit execution result must and first verbatim section equivalent"
    );
    assert_eq!(kerf_vm::render_value(&second.value, &second.heap), "42");
    // E6 dormancy anchor: the production path is cache-free (zero
    // consultations, zero stores — the Front entry kind dormant)
    assert_eq!(
        cache_stats().misses,
        0,
        "production path should not check cache(E6 dormancy)"
    );
    assert_eq!(cache_stats().stores, 0);
    // Direct-API reuse face: the compiled artifact stored under its
    // content-addressed key is served verbatim on the hit
    let out = compile_source(src, "cache-a.ktf").expect("compile failed");
    let key = cache_key(src, "cache-a.ktf", CompilerKind::Bootstrap);
    kerf_driver::cache::with_cache(|c| {
        c.store(
            key.clone(),
            CachedResult {
                program: out.program.clone(),
                core: out.core.clone(),
                code_value: None,
            },
        )
    });
    let got = kerf_driver::cache::with_cache(|c| c.get_cached(&key))
        .expect("direct-API store should hit after");
    assert_eq!(
        got.program, out.program,
        "artifact level hit must verbatim segment equivalent"
    );
    assert_eq!(cache_entry_count(), 1);
}

/// Source change → a distinct key (content-addressed coexistence): two
/// distinct sources stored under their own keys coexist as two entries
/// (the production runs of both succeed side by side).
#[test]
fn pipeline_source_change_misses() {
    cache_reset();
    let _ = run_source("1 + 2", "cache-b.ktf");
    let _ = run_source("1 + 3", "cache-b.ktf");
    // Distinct sources → distinct keys → the direct-API face stores two
    // coexisting entries
    for src in ["1 + 2", "1 + 3"] {
        let out = compile_source(src, "cache-b.ktf").expect("compile failed");
        let key = cache_key(src, "cache-b.ktf", CompilerKind::Bootstrap);
        kerf_driver::cache::with_cache(|c| {
            c.store(
                key,
                CachedResult {
                    program: out.program,
                    core: out.core,
                    code_value: None,
                },
            )
        });
    }
    assert_eq!(cache_entry_count(), 2, "two item coexist");
}

/// Seed-path cache isolation (B11/P4 — the seed reference path
/// bypasses the production cache — no lookups, no stores; production
/// entries never serve the seed path, and seed compilation does not
/// pollute the production cache). (E6 rework: exercised through
/// `run_source_seed` — the target-syntax seed entry whose
/// contract is "does not go through the compilation cache".)
#[test]
fn pipeline_seed_path_cache_isolated() {
    cache_reset();
    let src = "fn g(x: T) { x + 1 } g(41)";
    let _ = run_source(src, "cache-c.ktf").expect("run failed");
    let stats_before = cache_stats();
    let outcome = run_source_seed(src, "cache-c.ktf").expect("seed chain failed");
    let stats_after = cache_stats();
    assert_eq!(
        stats_after.hits, 0,
        "seed path not get hit production entry(B11 isolation)"
    );
    assert_eq!(
        stats_after.misses, 0,
        "seed path not get check query production cache(not check does not exist)"
    );
    assert_eq!(
        stats_after.stores, stats_before.stores,
        "seed path not get write input cache"
    );
    assert_eq!(kerf_vm::render_value(&outcome.value, &outcome.heap), "42");
}

/// Cache disabled: the flag round-trips and the pipeline path is
/// unaffected (baseline control path) — statistics unchanged. (E6
/// rework: with the production path cache-free, the disabled flag's
/// remaining observable face is the session-flag itself + the zero-touch
/// anchor.)
#[test]
fn pipeline_disabled_bypasses_cache() {
    cache_reset();
    set_cache_enabled(false);
    assert!(!cache_enabled());
    let _ = run_source("2 + 2", "cache-d.ktf").expect("execution failed");
    assert_eq!(
        cache_stats().misses,
        0,
        "stop use time pipeline path not check cache"
    );
    assert_eq!(cache_entry_count(), 0, "stop use time not write cache");
    set_cache_enabled(true);
    assert!(cache_enabled());
}

/// Compile-time errors are not cached: both runs of the same source
/// leave the session cache empty (errors leave no entry — diagnostics
/// may evolve across versions; the front-end artifact of a runtime
/// error is a legitimate cache artifact on the direct-API face — a
/// successful compilation is an equivalent artifact).
#[test]
fn pipeline_compile_errors_not_cached() {
    cache_reset();
    let src = "1 +"; // Read-stage error (truncated expression)
    assert!(run_source(src, "cache-e.ktf").is_err());
    assert!(run_source(src, "cache-e.ktf").is_err());
    assert_eq!(
        cache_stats().misses,
        0,
        "compile error twice all should not in(E6: production path never consults)"
    );
    assert_eq!(cache_entry_count(), 0, "compile error not lands cache");
    // The front-end artifact of a runtime error is cacheable on the
    // direct-API face (compilation succeeded — content-addressed
    // artifact equivalence): the same source errors identically at
    // runtime on both runs
    let rt_src = "1 + \"a\"";
    assert!(run_source(rt_src, "cache-e2.ktf").is_err());
    assert!(run_source(rt_src, "cache-e2.ktf").is_err());
    let out = compile_source(rt_src, "cache-e2.ktf").expect("compile failed");
    let key = cache_key(rt_src, "cache-e2.ktf", CompilerKind::Bootstrap);
    kerf_driver::cache::with_cache(|c| {
        c.store(
            key.clone(),
            CachedResult {
                program: out.program.clone(),
                core: out.core.clone(),
                code_value: None,
            },
        )
    });
    assert!(
        kerf_driver::cache::with_cache(|c| c.get_cached(&key)).is_some(),
        "run-time error compile pre-stage artifact should hit(direct-API face)"
    );
}

/// Compilation artifact equivalence (deterministic-compilation proof):
/// cache-hit artifact == freshly compiled artifact. (E6 rework: both
/// compilations go through the cache-free `compile_source` —
/// the determinism face is unchanged; the hit artifact comes from the
/// direct-API store/get pair.)
#[test]
fn cached_program_equals_fresh_compile() {
    cache_reset();
    let src = "fn fact(n: T) { if (n == 0) { 1 } else { n * fact(n - 1) } } fact(10)";
    let _ = run_source(src, "cache-f.ktf").expect("execution failed");
    // Artifact from the direct-API hit path
    let key = cache_key(src, "cache-f.ktf", CompilerKind::Bootstrap);
    let out = compile_source(src, "cache-f.ktf").expect("hit compile failed");
    kerf_driver::cache::with_cache(|c| {
        c.store(
            key,
            CachedResult {
                program: out.program.clone(),
                core: out.core.clone(),
                code_value: None,
            },
        )
    });
    let cached = kerf_driver::cache::with_cache(|c| {
        c.get_cached(&cache_key(src, "cache-f.ktf", CompilerKind::Bootstrap))
    })
    .expect("direct-API hit failed");
    // Freshly compiled artifact
    let fresh = compile_source(src, "cache-f.ktf").expect("new compile failed");
    assert_eq!(
        cached.program, fresh.program,
        "cache hit artifact must and new compile artifact verbatim section consistent(determinism compile)"
    );
    // IR-surface equivalence (consumer artifacts share the same origin —
    // node counts aligned)
    assert_eq!(cached.core.len(), fresh.core.len());
}

/// check_source cache observation surface (E6 rework: the target check
/// face `check_source_recover` is the recovery path — its
/// documented ruling is "the recovery path is not cached", so
/// CheckReport.cache_hit is false on every call; both calls report the
/// same zero-diagnostic surface).
#[test]
fn check_source_cache_hit_flag() {
    cache_reset();
    let src = "1 + 2";
    let r1 = check_source_recover(src, "cache-g.ktf").expect("first check failed");
    assert!(!r1.cache_hit, "first should miss(recovery path not cached)");
    let r2 = check_source_recover(src, "cache-g.ktf").expect("second check failed");
    assert!(
        !r2.cache_hit,
        "second should still miss(recovery path not cached)"
    );
    // Both diagnostic surfaces are equivalent (0 diagnostics)
    assert!(r1.diagnostics.is_empty() && r2.diagnostics.is_empty());
    assert_eq!(cache_stats().misses, 0, "check path not check cache");
}

/// Full invalidation: entries reset to zero, a re-store re-lands the
/// entry (compiler-upgrade scenario — the full form of clause 3).
#[test]
fn invalidate_all_returns_to_miss() {
    cache_reset();
    let src = "5 + 5";
    let _ = run_source(src, "cache-h.ktf").expect("execution failed");
    let out = compile_source(src, "cache-h.ktf").expect("compile failed");
    let key = cache_key(src, "cache-h.ktf", CompilerKind::Bootstrap);
    kerf_driver::cache::with_cache(|c| {
        c.store(
            key,
            CachedResult {
                program: out.program,
                core: out.core,
                code_value: None,
            },
        )
    });
    assert_eq!(cache_entry_count(), 1);
    cache_invalidate_all();
    assert_eq!(cache_entry_count(), 0);
    // After wholesale invalidation the entry is gone (a re-lookup on
    // the direct-API face misses — the entry must be re-stored)
    let gone = cache_key("5 + 5", "cache-h.ktf", CompilerKind::Bootstrap);
    assert!(
        kerf_driver::cache::with_cache(|c| c.get_cached(&gone)).is_none(),
        "invalidated after should re-new not in"
    );
}

/// Direct cache-key construction (public API shape — consumers can
/// precompute keys for external indexing).
#[test]
fn cache_key_public_shape() {
    let k = CacheKey {
        source_hash: 42,
        config_fingerprint: 7,
    };
    assert_eq!(k.source_hash, 42);
    assert_eq!(k.config_fingerprint, 7);
    let k2 = cache_key("x", "y.ktf", CompilerKind::Bootstrap);
    assert!(k2.source_hash != 0 || k2.config_fingerprint != 0);
}

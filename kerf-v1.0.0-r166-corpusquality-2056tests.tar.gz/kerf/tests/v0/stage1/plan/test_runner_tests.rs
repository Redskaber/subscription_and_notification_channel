// E6 close-out (r154 / 224-b6): converted to the target-syntax face.
//! Test-case runner integration tests (r8 batch D — the D1 consumer
//! face: the `test_source` convention locked down).
//!
//! Coverage (§9.4.3 — mostly negative; the global face's 1089/346 ≈
//! 1:3.15 ratio is maintained):
//! - **Convention face** (zero new syntax — the test face is the language
//!   face): prelude forms (define/set!/module/require) = the common
//!   prelude replayed per case; every other top-level expression = a case
//!   (evaluation without error and a value other than #f = PASS);
//! - **Effect consumer face** (the end-to-end proof of effects.rs):
//!   short-circuit (a failure at any depth within a case stops that case) +
//!   recovery (after the boundary catches, the next case keeps running) +
//!   state isolation (each case gets a fresh global environment and
//!   heap — a failing case does not poison later cases);
//! - **Report face**: per-case results / counts / name rendering /
//!   source-order preservation;
//! - **front error face**: a source-level syntax error → a whole-file
//!   DriverError (not a case FAIL).
//!
//! Note: the "case compile failure" branch of `run_case` is a defensive
//! path (the front's read/expand stages already intercept shape errors,
//! and compile_module produces no structural errors for valid core
//! expressions) — that branch's correctness is guaranteed by the type
//! system's exhaustive matching; this suite does not construct it
//! artificially (recorded in the conventions section of
//! docs/tests/v0/stage1/plan/test-runner.md).
//!
//! E6 skin notes (E6-CG §2): the test face is the language face —
//! top-level fn/define/require forms are the prelude, expression
//! statements (`;`-separated) are the cases; `(= a b)` assertions →
//! `a == b`; the short-circuit do fixture moved into a `|| { ... }`
//! closure body (a top-level do would splice into multiple items —
//! r49 D59).

use kerf_driver::bootstrap::test_runner::run_test_case;
use kerf_driver::Stage;

const FNAME: &str = "runner.ktf";

fn report(src: &str) -> kerf_driver::TestReport {
    run_test_case(src, FNAME).expect("test source should can compile execution")
}

// ---------------------------------------------------------------------------
// Positive: convention face (PASS judgment + prelude splitting + report counting)
// ---------------------------------------------------------------------------

/// A single assertion case that is true → PASS (the `(= a b)` predicate
/// is the assertion).
#[test]
fn single_assertion_case_passes() {
    let r = report("1 == 1");
    assert_eq!(r.cases.len(), 1);
    assert!(r.cases[0].pass);
    assert_eq!(r.passed, 1);
    assert_eq!(r.failed, 0);
    assert!(r.all_passed());
}

/// Multiple cases all pass (source order preserved — index 1..n).
#[test]
fn multiple_cases_all_pass_in_order() {
    let r = report("1 == 1; 2 == 2; 3 == 3");
    assert_eq!(r.cases.len(), 3);
    for (i, c) in r.cases.iter().enumerate() {
        assert!(c.pass, "case {} should pass", i + 1);
        assert_eq!(
            c.index,
            i + 1,
            "case order number should source order 1 start"
        );
    }
    assert_eq!(r.passed, 3);
}

/// Non-bool truthy values (42 / nil) → PASS (convention = any value other
/// than #f passes).
#[test]
fn non_false_truthy_values_pass() {
    let r = report("42; ()");
    assert_eq!(r.cases.len(), 2);
    assert!(r.cases[0].pass);
    assert!(r.cases[1].pass);
}

/// A prelude define replayed per case: each case is a pure function of
/// the prelude (the positive face of state isolation).
#[test]
fn prelude_define_shared_across_cases() {
    let src = "let x = 10; x == 10; x + 1 == 11";
    let r = report(src);
    assert_eq!(r.cases.len(), 2, "define is pre-, not effect case");
    assert!(r.all_passed());
}

/// require/assign are prelude forms (not counted as cases).
#[test]
fn require_and_setbang_are_prelude_forms() {
    let src = "let x = 1; x = 2; require io, write; x == 2";
    let r = report(src);
    assert_eq!(r.cases.len(), 1, "only most after one = form is case");
    assert!(r.all_passed());
}

/// An empty (prelude-only) source: zero cases → all_passed (the empty
/// set trivially passes).
#[test]
fn prelude_only_source_has_zero_cases() {
    let r = report("let a = 1; let b = 2;");
    assert!(r.cases.is_empty());
    assert_eq!((r.passed, r.failed), (0, 0));
    assert!(r.all_passed());
}

// ---------------------------------------------------------------------------
// Negative: assertion failures and runtime errors (FAIL judgment + short-circuit + recovery)
// ---------------------------------------------------------------------------

/// An assertion returning #f → FAIL; detail carries the assertion
/// semantics.
#[test]
fn false_assertion_fails_with_detail() {
    let r = report("1 == 2");
    assert!(!r.cases[0].pass);
    assert_eq!(r.failed, 1);
    assert!(
        r.cases[0].detail.contains("#f"),
        "failed detail should contain #f semantics, got: {}",
        r.cases[0].detail
    );
}

/// A #f literal case → FAIL (the dual face of the non-bool truthiness
/// convention).
#[test]
fn literal_false_case_fails() {
    let r = report("false");
    assert!(!r.cases[0].pass);
}

/// A runtime error (unbound variable) → FAIL with the error's first
/// line in the detail.
#[test]
fn runtime_error_case_fails_with_error_detail() {
    // r46 / D49: unbound references moved up to compile time — the case
    // error carrier now uses a runtime error (division by zero: E5) — the
    // runner's failure-detail semantics are unchanged
    let r = report("1 / 0");
    assert!(!r.cases[0].pass);
    assert!(
        !r.cases[0].detail.is_empty(),
        "runtime error case should carry failed detail"
    );
}

/// **Error recovery (the core of the effect consumer face)**: after the
/// first case fails, the next case keeps running.
#[test]
fn failure_recovers_next_case_continues() {
    let src = "1 == 2; 2 == 2; 3 == 3";
    let r = report(src);
    assert_eq!(r.cases.len(), 3);
    assert!(!r.cases[0].pass);
    assert!(
        r.cases[1].pass,
        "failed case subsequent case should continue-run(recovery)"
    );
    assert!(r.cases[2].pass);
    assert_eq!((r.passed, r.failed), (2, 1));
}

/// **Short-circuit**: the first error within a case stops it — later
/// expressions do not execute (no side effects leak out).
#[test]
fn first_error_short_circuits_within_case() {
    // case = ((fn () (do (/ 1 0) (= 1 2)))): the first expression's error
    // stops immediately, the whole case is a single FAIL (detail is the
    // first error, not the #f assertion).
    // r46 / D49: the error carrier switched to division by zero (unbound
    // is already compile-time — two-stage division of labor);
    // r49 / D59: top-level do → module-level splice (multiple items) —
    // the fixture shape that preserves case granularity = do moved into
    // the fn body (do in expression position = Let chain, short-circuit
    // semantics unchanged)
    let src = "let x = 1; (|| { 1 / 0; 1 == 2 })()";
    let r = report(src);
    assert_eq!(r.cases.len(), 1);
    assert!(!r.cases[0].pass);
    assert!(
        !r.cases[0].detail.contains("#f"),
        "short-circuit semantics: first wrong namely stop, not should reaching #f assertion, got: {}",
        r.cases[0].detail
    );
}

/// **Deep-position failure with zero signature pollution**: an error
/// deep inside nested functions reaches the boundary directly (any
/// depth).
#[test]
fn deep_nested_failure_reaches_boundary() {
    // r46 / D49: the error carrier switched to division by zero (unbound
    // is already compile-time); the deep-to-boundary semantics are
    // unchanged
    let src = r#"
        fn level3() { 1 / 0 }
        fn level2() { level3() }
        fn level1() { level2() }
        level1();
        1 == 1
    "#;
    let r = report(src);
    assert_eq!(r.cases.len(), 2, "define all is pre-");
    assert!(!r.cases[0].pass, "deep layer error should verdict FAIL");
    assert!(
        r.cases[1].pass,
        "deep position failed after under one case recovery"
    );
}

/// **State isolation**: a failing case's dirty state does not poison
/// later cases (each case gets a fresh environment and heap — the
/// prelude is replayed per case: the assign inside case 1 does not leak
/// into case 2).
#[test]
fn failing_case_does_not_poison_following_cases() {
    // r49 / D59: do moved into the fn body to preserve case granularity
    // (a top-level do would splice into multiple items)
    let src = "let x = 5; (|| { x = 6; 1 == 2 })(); x == 5";
    let r = report(src);
    assert_eq!(
        r.cases.len(),
        2,
        "define is pre-, fn case and = case each one"
    );
    assert!(!r.cases[0].pass, "first case #f assertion should failed");
    assert!(
        r.cases[1].pass,
        "second case independent replay precondition(x=5) -- first case assign not leak(isolation)"
    );
}

/// All-fail report: 0 passed / N failed / all_passed is false.
#[test]
fn all_fail_report_counts() {
    let r = report("1 == 2; false; 3 == 4");
    assert_eq!(r.cases.len(), 3);
    assert!((r.passed, r.failed) == (0, 3));
    assert!(!r.all_passed());
}

/// A failing case has non-empty detail + the case name carries the
/// form rendering.
#[test]
fn case_name_and_detail_rendered() {
    // r162 / 233 — TD-037: the `==` skin desugars to the `eq` terminal
    // name, so the form rendering carries `eq` (was `=` pre-r162)
    let r = report("99 == 100");
    assert!(
        r.cases[0].name.contains("eq"),
        "case name should be form render, got: {}",
        r.cases[0].name
    );
    assert!(!r.cases[0].detail.is_empty());
}

// ---------------------------------------------------------------------------
// Negative: front error face (whole-file DriverError — not a case FAIL)
// ---------------------------------------------------------------------------

/// A source-level syntax error (unclosed parenthesis) → a whole-file
/// Err (Stage::Read); no report is produced.
/// Unwrap the front-error channel (TestRunnerError::Front carries the
/// whole-file DriverError; Internal = a bridge defect we never expect
/// here — panic on sight).
fn expect_front(
    e: kerf_driver::bootstrap::test_runner::TestRunnerError,
) -> kerf_driver::DriverError {
    match e {
        kerf_driver::bootstrap::test_runner::TestRunnerError::Front(d) => d,
        kerf_driver::bootstrap::test_runner::TestRunnerError::Internal(m) => {
            panic!("expected a front error, got internal: {}", m)
        }
    }
}

#[test]
fn syntax_error_returns_whole_file_error() {
    let e = expect_front(run_test_case("define(x, 1", FNAME).unwrap_err());
    assert_eq!(e.stage, Stage::Read);
}

/// A require shape error → a whole-file Err (Stage::Expand — the front
/// intercepts before case splitting).
#[test]
fn malformed_require_returns_expand_error() {
    let e = expect_front(run_test_case("require io; 1 == 1", FNAME).unwrap_err());
    assert_eq!(e.stage, Stage::Expand);
}

/// A case with undeclared I/O → a whole-file E0006 (R9: the front's
/// single verification point precedes the runner).
#[test]
fn undeclared_io_gates_whole_test_source() {
    let e = expect_front(run_test_case("print(1); 1 == 1", FNAME).unwrap_err());
    assert_eq!(e.stage, Stage::Compile);
    assert!(e.rendered.contains("error[E0006]"));
}

// E6 close-out (r154 / 224-b5): converted to the target-syntax face.
//! Type-checker integration tests (tests/v0/stage1/plan/typecheck_tests.rs ↔
//! kerf-compiler/src/typecheck.rs ↔ 12-roadmap §2.5.2 Stage 1 L node).
//!
//! Batch C (25-a/25-c): the conservative static type-checking R1-R8 rule
//! set + multi-error collection (the TD-013 consumer face) + check_source
//! pipeline integration.
//!
//! **Flag-period criterion (D8 stage 2 — r29 / 50-a / MUV 48-c,
//! hm-inference-design §3.7 evolution-track stage 2)**: the
//! `check_source` decision face has switched to HM inference
//! (`hm_check_program`) — exercised through the production entry point,
//! this suite is the flag period's **superset gate** (the R1-R8 negative
//! matrix fully detected) + **zero-false-positive gate** (examples/
//! dynamic boundaries with zero diagnostics); R1-R8 (check_program) is
//! demoted to regression baseline assertions (the hm_inference_tests /
//! effect_tests dual-face detection discipline is retained). The
//! conservatism contract is redefined for the flag period: the **zero
//! type-mismatch false positives** criterion + the occurs/self-
//! application faces exempted as accepted behavior (explicitly
//! registered for the flag period in hm-inference-design §2.3 — P0-2
//! fulfilled). Assertion substrings have been re-anchored to the HM
//! rendering wording (structured types + arity ranges —
//! semantics/detection/location unchanged).
//!
//! Acceptance anchors (§9.4.3, re-anchored to the flag-period criterion):
//! - **Zero type-mismatch false positives**: all examples/ programs + all
//!   existing semantic-boundary programs → 0 diagnostics (insufficient
//!   dynamic information is always skipped as Dynamic; the
//!   occurs/self-application faces are policy exemptions — see the
//!   flag-period test group at the end);
//! - ≥3 negative cases per rule (table-driven matrix);
//! - **Consistency** sampling of static diagnostics vs runtime behavior:
//!   maintained within the superset gate (a program that errors
//!   statically definitely reports a Run-stage error when actually run);
//!   the occurs face is exempt (policy behavior, no bidirectional anchor
//!   promised);
//! - Multi-error collection: all N errors of a single program returned in
//!   Span order.
//!
//! E6 note (224-b5): `check_source`/`compile_source`/`run_source` →
//! `check_source_recover`/`compile_source`/
//! `run_source` (the sole decision/oracle/run faces since the
//! S-expr removal); the corpus is target-syntax (`fn f(x: T)` with
//! stripped-after-parse annotations — the annotation carries no HM
//! constraint, `x: i64` behaves exactly as `x: T`). Chained
//! comparison/arithmetic S-expr rows reduce to their binary infix faces
//! (the target grammar is non-chaining on comparisons; arithmetic chains
//! stay left-associative).

use crate::common;

use kerf_driver::builtins::builtin_sigs;
use kerf_driver::{check_source_recover, compile_source, run_source, Stage};

/// Rust oracle direct-call assertion (r80 semantic re-anchor: three
/// kinds of conservative false-negative boundaries on the production
/// decision face [the check.ktf path] — the signature-table subset
/// [string/symbol family parameters and arities], the occurs narrowing
/// face [fixes ③④], and within-item multi-error granularity — guarded
/// by oracle direct calls preserving the reference face's detection
/// capability; behavioral boundaries of the ktf face are asserted by
/// dedicated tests).
fn oracle_diag(src: &str, msg: &str) {
    let out = compile_source(src, "typecheck-oracle.ktf").expect("compile failed");
    let mut table = out.table;
    let sigs = builtin_sigs(&mut table);
    let diags = kerf_compiler::hm::hm_check_program(&out.core, &sigs, &table).diags;
    assert!(
        diags.iter().any(|d| d.message.contains(msg)),
        "oracle not detected `{}`: \n program: {}",
        msg,
        src
    );
}

/// Asserts the source text's static check = 0 diagnostics (conservatism
/// anchor).
fn expect_clean(src: &str) {
    let report = check_source_recover(src, "typecheck-pos.ktf").expect("compile failed");
    assert!(
        report.diagnostics.is_empty(),
        "expected 0 diagnostic, got {} clauses: {}\n program: {}",
        report.diagnostics.len(),
        report.rendered.join("\n"),
        src
    );
}

/// Asserts the source text produces a static diagnostic containing the
/// given message substring (E0005).
fn expect_diag(src: &str, msg: &str) {
    let report = check_source_recover(src, "typecheck-neg.ktf").expect("compile failed");
    assert!(
        report.diagnostics.iter().any(|d| d.message.contains(msg)),
        "not detected diagnostic `{}`; actual {} clauses: {}\n program: {}",
        msg,
        report.diagnostics.len(),
        report.rendered.join("\n"),
        src
    );
    for d in &report.diagnostics {
        assert_eq!(
            d.code.map(|c| c.render()),
            Some("E0005".to_string()),
            "diagnostic code must is E0005"
        );
    }
}

/// Asserts the source text's static diagnostic count = N (multi-error
/// collection anchor).
fn expect_diag_count(src: &str, n: usize) {
    let report = check_source_recover(src, "typecheck-multi.ktf").expect("compile failed");
    assert_eq!(
        report.diagnostics.len(),
        n,
        "diagnostic count mismatch:{}\n program: {}",
        report.rendered.join("\n"),
        src
    );
}

/// Asserts a program that errors statically also fails at runtime (the
/// conservatism reverse anchor — static-determinism verification;
/// flag-period r29/50-a scope re-anchor: **maintained within the
/// superset gate** (the R1-R8 negative matrix's statically certain
/// errors — a Run-stage error is guaranteed at runtime); the
/// **occurs/self-application faces are exempt** — no bidirectional
/// anchor is promised for the runtime behavior of programs that error
/// statically with infinite types (accepted policy behavior, explicitly
/// registered for the flag period in hm-inference-design §2.3)).
fn static_error_is_runtime_error(src: &str) {
    match run_source(src, "typecheck-rt.ktf") {
        Ok(_) => panic!(
            "static state report an error program run-time pass(static state false positive suspect suspect): {}",
            src
        ),
        Err(e) => assert_eq!(e.stage, Stage::Run, "run-time error stage: {}", e),
    }
}

// ---------------------------------------------------------------------------
// Conservatism (zero false positives) — the "no false positives" face of R1-R8
// ---------------------------------------------------------------------------

/// All example programs in examples/ with zero diagnostics (6 cases —
/// real-program regression anchors; r153 / 223-c: the corpus legs switched
/// to the .ktf single face — the .krf corpus retired, s-expr-removal-plan
/// §4 Batch D; the conservatism duty on the real user corpus now runs on
/// the production face).
#[test]
fn examples_all_clean() {
    for name in [
        "fib.ktf",
        "closures.ktf",
        "macros.ktf",
        "higher_order.ktf",
        "gc_stress.ktf",
        "io.ktf",
    ] {
        let path = format!("examples/usage/{}", name);
        let src = std::fs::read_to_string(&path).unwrap_or_else(|e| panic!("{}", e));
        let report = check_source_recover(&src, name)
            .unwrap_or_else(|e| panic!("{}: target check failed:{}", name, e));
        assert!(
            report.diagnostics.is_empty(),
            "example {} expected 0 diagnostics: {}",
            name,
            report.rendered.join("\n")
        );
    }
}

/// Dynamic-semantics boundary programs with zero diagnostics
/// (parameterized value paths do not trigger static assertions).
#[test]
fn dynamic_programs_clean() {
    // Parameter passing (value type unknowable) — conservatively Unknown
    expect_clean("fn f(x: T) { if (x) { 1 } else { 2 } } f(true)");
    // Recursive self-reference in the definition (referenced before
    // definition → Unknown)
    expect_clean("fn fact(n: T) { if (n == 0) { 1 } else { n * fact(n - 1) } } fact(5)");
    // Hygiene symbols introduced by macros (the $hyg$N suffix — runtime
    // hygiene fallback resolution)
    expect_clean("require io, write; let x = 42; print(x)");
    // Numeric-tower mixing (Int/Float union = the legal Num domain)
    expect_clean("1 + 2.5");
    expect_clean("1 < 2.0");
    // head of a quoted list (list construction → Pair)
    expect_clean("head(list(1, 2, 3))");
    // Builtin shadowing (a user definition shadows the builtin — follows
    // the user's type)
    expect_clean("fn head(x: T) { 42 } head(5)");
    // set!/begin/if branch mixing
    expect_clean(
        "require io, write; let x = 1; x = x + 1; do(print(x), if (is_nil(())) { x } else { 2 })",
    );
    // Predicate result as if condition (result type inferred Bool)
    expect_clean("if (is_nil(())) { 1 } else { 2 }");
    expect_clean("if (eq(quote(a), quote(a))) { 1 } else { 2 }");
    // Correct string-family usage
    expect_clean("import kerf_string;\nstring_append(\"a\", \"b\")");
    expect_clean("import kerf_string;\nstring_to_symbol(\"foo\")");
    expect_clean("import kerf_string;\nsymbol_to_string(quote(foo))");
    // All-string equality comparison (string equality of ==)
    expect_clean("\"a\" == \"b\"");
}

/// Deep nesting (maximum depth within the Reader limit) with zero
/// diagnostics + stack safety (the programmatic-construction surface for
/// depth budgets far above MAX_CHECK_DEPTH is covered by the typecheck.rs
/// unit tests — the Reader's cap of 256 keeps source text from reaching
/// the budget threshold; here we verify zero false positives for deep
/// nesting within the limit).
#[test]
fn deep_nesting_within_reader_limit_clean() {
    let mut src = String::from("1");
    for _ in 0..250 {
        src = format!("if (true) {{ {} }} else {{ 2 }}", src);
    }
    expect_clean(&src);
}

// ---------------------------------------------------------------------------
// R1: if condition statically known non-bool
// ---------------------------------------------------------------------------

/// R1 negative matrix (8 cases: int/float/str/nil/symbol/pair/
/// quote-pair/procedure).
#[test]
fn r1_if_condition_non_bool() {
    expect_diag("if (1) { 2 } else { 3 }", "if condition requires bool");
    expect_diag("if (1.5) { 2 } else { 3 }", "if condition requires bool");
    expect_diag("if (\"s\") { 2 } else { 3 }", "if condition requires bool");
    expect_diag("if (()) { 2 } else { 3 }", "if condition requires bool");
    expect_diag(
        "if (quote(sym)) { 2 } else { 3 }",
        "if condition requires bool",
    );
    expect_diag(
        "if (cons(1, 2)) { 2 } else { 3 }",
        "if condition requires bool",
    );
    // E6 r154 / 224-c6: the quoted-pair leg retired — `list(1)` is a
    // runtime constructor whose HM type is the conservative Dynamic (A4)
    // face, not a static pair datum; the static non-bool family is
    // carried by the cons/quote-symbol legs above.
    expect_diag(
        "if (|| (x: T) { x }) { 2 } else { 3 }",
        "if condition requires bool",
    );
    // Static-determinism reverse anchor: indeed fails at runtime
    static_error_is_runtime_error("if (1) { 2 } else { 3 }");
    static_error_is_runtime_error("if (\"s\") { 2 } else { 3 }");
}

/// R1 nested positions (the condition of a nested if is also checked —
/// not only the top level).
#[test]
fn r1_nested_if_condition() {
    expect_diag(
        "if (true) { 1 } else { if (()) { 2 } else { 3 } }",
        "if condition requires bool",
    );
}

// ---------------------------------------------------------------------------
// R2: arithmetic-family operands statically known non-numeric
// ---------------------------------------------------------------------------

/// R2 negative matrix (5 operators × non-numeric variants).
#[test]
fn r2_arithmetic_non_numeric() {
    // infix operators + the mod call form (the target faces of the
    // S-expr five-operator family)
    expect_diag("1 + \"a\"", "requires a number");
    expect_diag("1 - \"a\"", "requires a number");
    expect_diag("1 * \"a\"", "requires a number");
    expect_diag("1 / \"a\"", "requires a number");
    expect_diag("mod(1, \"a\")", "requires a number");
    // Left position non-numeric
    expect_diag("\"a\" + 1", "requires a number");
    expect_diag("quote(sym) * 2", "requires a number");
    expect_diag("() - 2", "requires a number");
    expect_diag("mod(true, 2)", "requires a number");
    expect_diag("cons(1, 2) + 5", "requires a number");
    // Deep position (mid-chain — left-associative chain, the tail
    // operand is checked)
    expect_diag("1 + 2 + \"a\" + 4", "requires a number");
    // Static-determinism reverse anchor
    static_error_is_runtime_error("1 + \"a\"");
}

/// R2 numeric-tower boundary: Int/Float mixing does not false-positive
/// (the Num union domain).
#[test]
fn r2_numeric_tower_clean() {
    expect_clean("1 + 2.5 + 3");
    expect_clean("2.5 - 1");
    expect_clean("1.5 * 2.0 * 3");
}

// ---------------------------------------------------------------------------
// R3: comparison family (= and ordering) — TD-016 all-operand static criterion
// E6 note: the target grammar's comparison is binary infix — the S-expr
// chained rows `(< 3 1 "a")` / `(= 1 2 "s")` retired with that face
// (record: 224-b5, 2 static rows + their runtime anchors); the binary
// mixed-type rows keep the TD-016 criterion (both operands checked).
// ---------------------------------------------------------------------------

/// R3 ordering-family negatives (4 operators × non-numeric).
#[test]
fn r3_ordering_non_numeric() {
    expect_diag("1 < \"a\"", "requires a number");
    expect_diag("1 > \"a\"", "requires a number");
    expect_diag("\"a\" <= 1", "requires a number");
    expect_diag("1 >= \"a\"", "requires a number");
    // TD-011 (r24): all-string ordering comparisons pass statically
    // (codepoint order — same criterion as runtime)
    expect_clean("\"a\" < \"b\"");
    expect_clean("\"a\" <= \"a\"");
    // Static-determinism reverse anchor
    static_error_is_runtime_error("\"a\" < 1");
}

/// R3 equality family all-string legal (zero-false-positive anchor) +
/// mixed-string detection. (The S-expr chained rows `(= \"a\" \"b\"
/// \"c\")` / `(= 1 2 'sym)` reduce to the binary faces; record: 224-b5.)
#[test]
fn r3_equality_string_domain() {
    expect_clean("\"a\" == \"b\"");
    // r162 / 233 — TD-037: the mixed row `"a" == 1` retired from the
    // E0005 family (the `==` skin now targets the cross-domain `eq` sig
    // (Any, Any) → Bool — statically clean, silent `false` at runtime;
    // see ktf_equality_domain_tests). The ordering family keeps the
    // static domain check:
    expect_clean("\"a\" == 1");
    expect_diag("\"a\" < 1", "requires a number");
}

// ---------------------------------------------------------------------------
// R4/R5: not and car/cdr
// ---------------------------------------------------------------------------

/// R4 not non-boolean (3 cases + reverse anchor).
#[test]
fn r4_not_non_bool() {
    expect_diag("not(1)", "requires bool");
    expect_diag("not(\"s\")", "requires bool");
    expect_diag("not(())", "requires bool");
    static_error_is_runtime_error("not(1)");
}

/// R5 car/cdr non-pair (6 cases + reverse anchor).
#[test]
fn r5_car_cdr_non_pair() {
    expect_diag("head(5)", "head requires pair");
    expect_diag("tail(5)", "tail requires pair");
    expect_diag("head(\"s\")", "head requires pair");
    expect_diag("head(quote(sym))", "head requires pair");
    expect_diag("tail(true)", "tail requires pair");
    expect_diag("head(())", "head requires pair");
    // Quoted pair literals legal (zero-false-positive anchor)
    expect_clean("head(list(1, 2))");
    expect_clean("tail(list(1, 2))");
    static_error_is_runtime_error("head(5)");
}

// ---------------------------------------------------------------------------
// R6: callee expression statically known non-callable
// ---------------------------------------------------------------------------

/// R6 non-callable (4 cases + reverse anchor).
#[test]
fn r6_not_callable() {
    expect_diag("5(6)", "uncallable value");
    expect_diag("\"s\"(1)", "uncallable value");
    expect_diag("cons(1, 2)(3)", "uncallable value");
    expect_diag("true(1)", "uncallable value");
    // Static-determinism reverse anchor
    static_error_is_runtime_error("5(6)");
}

// ---------------------------------------------------------------------------
// R7: arity mismatch (literal fn / builtin signatures)
// ---------------------------------------------------------------------------

/// R7 literal fn arity (3 cases).
#[test]
fn r7_lambda_arity() {
    expect_diag(
        "(|| (x: T) { x })(1, 2)",
        "procedure argument count mismatch",
    );
    expect_diag(
        "(|| (x: T, y: T) { x })(1)",
        "procedure argument count mismatch",
    );
    expect_diag("(|| { 1 })(5)", "procedure argument count mismatch");
    static_error_is_runtime_error("(|| (x: T) { x })(1, 2)");
}

/// R7 builtin arity (5 cases — same criterion as the runtime arity
/// guard; r80 semantic re-anchor: the core (head/cons/not/</>) is
/// detected on the ktf face; string-append is outside the
/// signature-table subset (the ktf face's generic path does not check —
/// a conservative false-negative boundary), guarded by the oracle direct
/// call). (The S-expr unary-comparison row `(< 1)` retired — a unary
/// comparison is unparseable on the non-chaining target grammar;
/// record: 224-b5, 1 row.)
#[test]
fn r7_builtin_arity() {
    expect_diag("head(1, 2)", "procedure argument count mismatch");
    expect_diag("cons(1)", "procedure argument count mismatch");
    expect_diag("not(1, 2)", "procedure argument count mismatch");
    // Signature-table subset boundary: string-append is not in the
    // check.ktf TC-SIGS (off-table names go through the generic
    // application path, conservatively Dynamic) — the oracle direct call
    // keeps the detection-capability assertion
    oracle_diag(
        "import kerf_string;\nstring_append(\"a\")",
        "procedure argument count mismatch",
    );
    static_error_is_runtime_error("head(1, 2)");
}

/// R7 user-defined closure arity (define → Callable inference).
#[test]
fn r7_defined_closure_arity() {
    expect_diag(
        "fn f(x: T) { x } f(1, 2)",
        "procedure argument count mismatch",
    );
    // Parameterized calls do not false-positive (f passed as a parameter
    // → Unknown callable)
    expect_clean("fn f(x: T) { x } fn g(f: T) { f(1, 2) } g(f)");
}

// ---------------------------------------------------------------------------
// R8: string/symbol family operand type mismatch
// ---------------------------------------------------------------------------

/// R8 string family (4 cases + reverse anchor). r80 semantic re-anchor:
/// string-family parameter type checks are outside the check.ktf
/// signature-table subset (a conservative false-negative boundary) —
/// the oracle direct call keeps the detection capability; non-detection
/// on the ktf face is a boundary fact (no expect_clean assertion added
/// — non-detection is not an assertion face for "clean", avoiding
/// semantic confusion).
#[test]
fn r8_string_family_type() {
    oracle_diag(
        "import kerf_string;\nstring_length(5)",
        "string-length requires str",
    );
    oracle_diag(
        "import kerf_string;\nstring_to_upper(quote(sym))",
        "string-to-upper requires str",
    );
    oracle_diag(
        "import kerf_string;\nstring_contains(1, \"a\")",
        "string-contains requires str",
    );
    oracle_diag(
        "import kerf_string;\nstring_to_symbol(true)",
        "string-to-symbol requires str",
    );
    static_error_is_runtime_error("import kerf_string;\nstring_length(5)");
}

/// R8 symbol conversion (2 cases). r80 semantic re-anchor: same as the
/// string family — a conservative false-negative boundary outside the
/// signature-table subset, guarded by the oracle direct call.
#[test]
fn r8_symbol_conversion() {
    oracle_diag(
        "import kerf_string;\nsymbol_to_string(5)",
        "symbol-to-string requires symbol",
    );
    oracle_diag(
        "import kerf_string;\nsymbol_to_string(\"s\")",
        "symbol-to-string requires symbol",
    );
    static_error_is_runtime_error("import kerf_string;\nsymbol_to_string(5)");
}

// ---------------------------------------------------------------------------
// Multi-error collection (TD-013 consumer face)
// ---------------------------------------------------------------------------

/// Single-program multi-error full collection + Span order (empirical
/// consumption of the TD-013 design).
#[test]
fn multi_error_collection_span_order() {
    // Three independent errors (if/arithmetic/non-callable) all returned
    let report = check_source_recover(
        "if (1) { 2 } else { 3 };\n1 + \"a\";\n5(6)",
        "typecheck-multi.ktf",
    )
    .expect("compile failed");
    assert_eq!(
        report.diagnostics.len(),
        3,
        "{}",
        report.rendered.join("\n")
    );
    // Span order (source order)
    let starts: Vec<u32> = report
        .diagnostics
        .iter()
        .map(|d| d.primary_span.start)
        .collect();
    let mut sorted = starts.clone();
    sorted.sort();
    assert_eq!(
        starts, sorted,
        "diagnostic must by Span start offset sorting"
    );
    // Rendering contains locations and E0005
    assert!(report.rendered[0].contains("error[E0005]"));
    assert!(report.rendered[0].contains("-->"));
}

/// Multiple errors within one expression (r80 semantic re-anchor: the
/// production decision face [ktf item-level recovery] stops at the
/// first error within an item — the granularity gap is the honest
/// boundary of the r75 residual axis ①; the oracle's constraint-level
/// full collection is guarded on the reference face by direct calls).
#[test]
fn multi_error_continues_after_error() {
    // r126 (HM deepening): within-item recovery — both argument violations
    // collected (oracle parity; the r80 re-anchored granularity [2→1]
    // returns to 2 = the constraint-level full-drain observable)
    expect_diag_count("\"a\" + \"b\"", 2);
    oracle_diag("\"a\" + \"b\"", "requires a number");
    // r126: a recorded branch error no longer aborts the item — the else
    // branch is still inferred (both branches checked, oracle parity)
    expect_diag_count("if (true) { 1 + \"a\" } else { 2 + \"b\" }", 2);
    oracle_diag(
        "if (true) { 1 + \"a\" } else { 2 + \"b\" }",
        "requires a number",
    );
}

/// Multi-form program: per-form collection (forms after define are
/// still checked).
#[test]
fn multi_error_across_forms() {
    expect_diag_count(
        "let x = 1;\nif (()) { 2 } else { 3 };\nx + \"a\";\nhead(5)",
        3,
    );
}

// ---------------------------------------------------------------------------
// Pipeline integration (check_source and execution paths)
// ---------------------------------------------------------------------------

/// check_source compile-error passthrough (Read/Expand stage errors
/// still return as DriverError). (The S-expr unclosed-paren leg
/// converts to the target Reader's truncated-expression negative;
/// the `(if)` malformed-core-form leg converts to the empty-quote
/// expand negative — the target-face error families, E6-CG §2.)
#[test]
fn check_source_compile_error_passthrough() {
    let err = check_source_recover("1 +", "typecheck-err.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Read);
    // E6 r154 / 224-c6: `quote()` at the recovery face lands as a
    // collected E0002 (not an Err — the recovery contract); the compile
    // short-circuit leg rides the R9 capability fail-closed face (E0006 —
    // Stage::Compile Err per the recover-mode boundary contract).
    let err = check_source_recover("print(1)", "typecheck-err.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Compile);
}

/// check_source compile statistics face (proto/instruction counts — the
/// data source of the check subcommand's output).
#[test]
fn check_report_stats_present() {
    let report = check_source_recover("1 + 2", "typecheck-stats.ktf").expect("compile failed");
    assert!(report.proto_count >= 1);
    assert!(report.instruction_count >= 3);
    assert!(report.rendered.is_empty());
}

/// Dual-path agreement: static diagnostics do not change run/eval
/// behavior (checking is a side-channel report — compilation output is
/// unaffected by the check).
#[test]
fn typecheck_does_not_affect_execution() {
    let src = "fn f(x: T) { x + 1 } f(41)";
    expect_clean(src);
    assert!(common::dual_path_agrees(src));
    assert_eq!(common::run_rendered(src), "42");
}

/// Stack safety under the deep-nesting budget (250 levels within the
/// Reader limit — the TD-017 2 MiB stack criterion).
#[test]
fn deep_nesting_stack_safe() {
    let mut src = String::from("1");
    for _ in 0..250 {
        src = format!("if (true) {{ {} }} else {{ 2 }}", src);
    }
    // No crash, no diagnostics
    let _ = check_source_recover(&src, "typecheck-deep.ktf");
}

// ---------------------------------------------------------------------------
// Flag-period decision face (D8 stage 2 — r29 / 50-a / MUV 48-c)
//
// The decision face = direct production evidence of HM inference
// (hm_check_program via the check_source production entry point) + test
// anchors of the contract redefinition (hm-inference-design §2.3). The
// R1-R8 superset gate / zero-false-positive gate through the production
// entry point is already covered by this file's existing matrices
// (after the switch they automatically become the flag-period gates).
// ---------------------------------------------------------------------------

/// HM value-add face detected via the production entry point
/// (constraint-propagation detections that R1-R8 silently pass — direct
/// evidence of the decision-face switch; one of the four gap classes ①:
/// user fn argument type error).
#[test]
fn flag_period_hm_value_added_via_production() {
    // R1-R8 face: f's parameter is Unknown → both (x + 1) and f("s")
    // stay silent; HM face: α ~ str vs α ~ Num constraint conflict →
    // detected
    expect_diag("fn f(x: T) { x + 1 } f(\"s\")", "type mismatch");
}

/// The occurs face exempted as accepted policy behavior (flag-period
/// contract — hm-inference-design §2.3: infinite types error
/// statically; no bidirectional anchor promised for runtime behavior).
/// r80 semantic re-anchor: after fixes ③④, the ktf face (production)
/// narrows the occurs detection face (infinite type construction not
/// reported — a conservative false negative, within the flag period's
/// occurs-domain elasticity); the Rust oracle's detection capability is
/// guarded by direct calls.
#[test]
fn flag_period_occurs_exempt_policy() {
    // (cons x (f x)): f : α → (α . β) is an infinite type — the oracle's
    // occurs check reports it (reference-face evidence); **do not** call
    // static_error_is_runtime_error (exempted face — under strict
    // evaluation the runtime does not terminate)
    oracle_diag("fn f(x: T) { cons(x, f(x)) } 1", "infinite type");
}

/// Dual-face fix regression anchors (two dual-face drifts exposed by
/// real runs during the flag-period switch — hm-inference-design §2.3
/// measured reconciliation: TD-011 Ordering sync + car/cdr Nil
/// detection).
#[test]
fn flag_period_dual_face_fix_anchors() {
    // ① TD-011 r24 string total order: `"a" < "b"` zero diagnostics
    //    (the hm.rs Ordering arm's old PoC criterion once false-positived
    //    — the fix anchor)
    expect_clean("\"a\" < \"b\"");
    expect_clean("\"b\" >= \"a\"");
    // ② (head nil) detected (the hm.rs head arm once let Nil slip into
    //    the conservative skip — the missed-detection fix anchor; runtime
    //    determinism E5 → bidirectional anchor maintained)
    expect_diag("head(())", "head requires pair");
    static_error_is_runtime_error("head(())");
}

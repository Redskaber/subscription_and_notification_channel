// E6 close-out (r154 / 224-b6): converted to the target-syntax face.
//! Stage 1 batch E (TD-004, r13) integration tests: scope set resolution
//! (Racket-style `(name, scopes ⊆)` matching + max-cardinality) end-to-end
//! semantic anchors.
//!
//! E6 skin notes (E6-CG §2): source-level cases run on the target face
//! (define call form / `||` closures / do call form / macro declaration);
//! the hand-constructed CoreExpr legs are skin-invariant (no source text).
//!
//! Coverage bar (original A4 acceptance: ≥6 Racket-style semantic anchor
//! tests, including ≥3 negative cases):
//! - **Positive cases**: nested shadowing (inner binding wins) / closure
//!   capture (the captured binding carries its binding scope set) /
//!   assign hits the lexical binding rather than the global — all agree
//!   across both paths (VM + eval; preservation of theorem T1 under
//!   scope-set resolution);
//! - **Negative cases**: when the reference scope set does **not** contain
//!   the binding scope set, Racket semantics judges the reference unbound
//!   (VM → falls back to the global, then reports the unbound-global
//!   error; eval → the unbound-variable error) — this is the behavioral
//!   divergence point from the old name-based resolution (name matches
//!   but scopes do not ≠ a resolution hit); assign follows the same rule;
//!   macro-introduced bindings do not capture user bindings of the same
//!   name.
//!
//! Source-level positive/negative cases go through the driver's dual entry
//! points; scope-mismatch negative cases use hand-constructed CoreExpr
//! values (the expander's injection invariant guarantees that real source
//! never produces this shape, so hand construction is the only observable
//! carrier of this semantics — same origin as the compiler/eval unit
//! tests).

use std::rc::Rc;

use kerf_compiler::compile_module;
use kerf_core::CoreExpr;
use kerf_driver::{run_source, run_source_seed};
use kerf_runtime::Heap;
use kerf_span::Span;
use kerf_syntax::{ScopeId, ScopeSet, SymbolTable};
use kerf_vm::{eval_program, run_program, Env, Value};

/// r49 D59: expression → expression-item wrapping (fixture adaptation for
/// the compile/eval item-level entry points).
fn expr_items(exprs: &[std::rc::Rc<kerf_core::CoreExpr>]) -> Vec<kerf_core::ModuleItem> {
    exprs
        .iter()
        .map(|e| kerf_core::ModuleItem::Expr(std::rc::Rc::clone(e)))
        .collect()
}

fn int_of(v: &Value) -> i64 {
    match v {
        Value::Int(i) => *i,
        other => panic!("expected Int, got {:?}", other),
    }
}

/// Constructs `((fn (x) x) 42)` with binding scope set = {binder} and
/// reference scope set = {ref}; when `binder ⊄ ref_scopes` the reference
/// must not hit the binding.
fn mismatched_lambda(binder: ScopeId, ref_scope: ScopeId) -> Vec<Rc<CoreExpr>> {
    let mut table = SymbolTable::new();
    let x = table.intern("x");
    let binder_scopes = ScopeSet::from_iter_scopes([binder]);
    let ref_scopes = ScopeSet::from_iter_scopes([ref_scope]);
    let body = Rc::new(CoreExpr::Var {
        name: x,
        scopes: ref_scopes,
        span: Span::dummy(),
    });
    let lam = Rc::new(CoreExpr::Fn {
        params: vec![x],
        param_scopes: vec![binder_scopes],
        rest: None,
        body,
        span: Span::dummy(),
    });
    let arg = Rc::new(CoreExpr::Literal {
        value: kerf_core::LiteralValue::Int(42),
        span: Span::dummy(),
    });
    vec![Rc::new(CoreExpr::Apply {
        fn_expr: lam,
        args: vec![arg],
        span: Span::dummy(),
    })]
}

// ---- Positive cases (both paths agree) ----

/// Positive case 1: shadowing — the inner parameter shadows the
/// same-named global (max-cardinality = the inner binding scope set has a
/// strictly larger cardinality). Both paths.
#[test]
fn shadowing_resolves_innermost_dual_path() {
    let src = "let x = 10; (|| (x: i64) { x })(20)";
    let a = run_source(src, "s1.ktf").unwrap();
    let b = run_source_seed(src, "s1.ktf").unwrap();
    assert_eq!(int_of(&a.value), 20, "VM inner binding wins on path");
    assert_eq!(int_of(&b.value), 20, "eval inner binding wins on path");
}

/// Positive case 2: two-level same-name nested shadowing —
/// `((fn (x) ((fn (x) x) 2)) 1)` → 2 (innermost binding; scope injection
/// invariant: the inner binding scope set strictly contains the outer
/// one). Both paths.
#[test]
fn nested_shadowing_innermost_wins_dual_path() {
    let src = "let x = 0; (|| (x: i64) { (|| (x: i64) { x })(2) })(1)";
    let a = run_source(src, "s2.ktf").unwrap();
    let b = run_source_seed(src, "s2.ktf").unwrap();
    assert_eq!(int_of(&a.value), 2);
    assert_eq!(int_of(&b.value), 2);
}

/// Positive case 3: closure capture — the captured binding carries its
/// original binding scope set, and references inside the inner function's
/// body hit the captured slot via the same subset matching.
/// `((fn (x) ((fn (y) (+ x y)) 2)) 1)` → 3. Both paths.
#[test]
fn closure_capture_by_scope_set_dual_path() {
    let src = "(|| (x: i64) { (|| (y: i64) { x + y })(2) })(1)";
    let a = run_source(src, "s3.ktf").unwrap();
    let b = run_source_seed(src, "s3.ktf").unwrap();
    assert_eq!(int_of(&a.value), 3, "VM capture via subset match");
    assert_eq!(int_of(&b.value), 3, "eval capture via subset match");
}

/// Positive case 4: assign target resolution — hits the lexical parameter
/// binding rather than the global (the global is unchanged after the
/// assignment). `(define g 0) (do ((fn (x) (assign x 5) x) 9) g)` → 0.
/// Both paths (same result as the old name-based resolution, verifying
/// that the switch is regression-free).
#[test]
fn setbang_hits_lexical_not_global_dual_path() {
    let src = "let g = 0; do((|| (x: i64) { x = 5; x })(9), g)";
    let a = run_source(src, "s4.ktf").unwrap();
    let b = run_source_seed(src, "s4.ktf").unwrap();
    assert_eq!(int_of(&a.value), 0, "VM: assign hit parameter, g unchanged");
    assert_eq!(
        int_of(&b.value),
        0,
        "eval: assign hit parameter, g unchanged"
    );
}

// ---- Negative cases (Racket semantics divergence: scope mismatch ≠ name match) ----

/// Negative case 1: the reference scope set does not contain the binding
/// scope set → the lexical binding does not hit (VM path: resolves to
/// the global → the unbound-global runtime error). The old name-based
/// implementation would hit the parameter slot (erroneous capture); this
/// test anchors the discriminating point of the new semantics.
#[test]
fn scope_mismatch_reference_unbound_vm() {
    let exprs = mismatched_lambda(7, 9); // binding {7} ⊄ reference {9}
    let program = compile_module(&expr_items(&exprs)).unwrap();
    let mut globals = std::collections::HashMap::new();
    let mut heap = Heap::new();
    let err = run_program(&program, &mut globals, &mut heap).unwrap_err();
    assert!(
        err.message.contains("unbound global variable"),
        "VM actual error: {}",
        err.message
    );
}

/// Negative case 2: same as above (eval path) — `Env::lookup` subset
/// matching does not hit → the unbound-variable error. Both paths judge
/// the same (T1).
#[test]
fn scope_mismatch_reference_unbound_eval() {
    let exprs = mismatched_lambda(7, 9);
    let root = Env::new();
    let mut heap = Heap::new();
    let err = eval_program(&expr_items(&exprs), &root, &mut heap).unwrap_err();
    assert!(
        err.message.contains("unbound variable"),
        "eval actual error: {}",
        err.message
    );
}

/// Negative case 3: the assign target scope set does not contain the
/// binding scope set → the lexical binding does not hit (VM: StoreGlobal
/// → the assign-on-unbound-variable error; eval: env.set finds no hit →
/// same report).
/// Constructs the `(fn (x) (assign x 1) x)` shape: binding {7}, target
/// reference {9}.
#[test]
fn scope_mismatch_setbang_unbound_dual_path() {
    let mut table = SymbolTable::new();
    let x = table.intern("x");
    let binder = ScopeSet::from_iter_scopes([7]);
    let mismatch = ScopeSet::from_iter_scopes([9]);
    let one = Rc::new(CoreExpr::Literal {
        value: kerf_core::LiteralValue::Int(1),
        span: Span::dummy(),
    });
    let setb = Rc::new(CoreExpr::Assign {
        name: x,
        scopes: mismatch,
        value: one,
        span: Span::dummy(),
    });
    // r45: do sequence → Let chain (a single-element sequence is the bare
    // term with no wrapping — make_do_let_chain returns the single element
    // directly; this mirrors the single-item (do (assign x 1)) shape)
    let body = setb;
    let lam = Rc::new(CoreExpr::Fn {
        params: vec![x],
        param_scopes: vec![binder],
        rest: None,
        body,
        span: Span::dummy(),
    });
    // Apply the closure so the body executes: ((fn (x) (do (assign x 1))) 2)
    let two = Rc::new(CoreExpr::Literal {
        value: kerf_core::LiteralValue::Int(2),
        span: Span::dummy(),
    });
    let app = Rc::new(CoreExpr::Apply {
        fn_expr: lam.clone(),
        args: vec![two],
        span: Span::dummy(),
    });
    // VM path
    let program = compile_module(&expr_items(&[std::rc::Rc::clone(&app)])).unwrap();
    let mut globals = std::collections::HashMap::new();
    let mut heap = Heap::new();
    let err_vm = run_program(&program, &mut globals, &mut heap).unwrap_err();
    assert!(
        err_vm.message.contains("assign unbound variable"),
        "VM actual error: {}",
        err_vm.message
    );
    // eval path
    let root = Env::new();
    let mut heap2 = Heap::new();
    let err_ev =
        eval_program(&expr_items(&[std::rc::Rc::clone(&app)]), &root, &mut heap2).unwrap_err();
    assert!(
        err_ev.message.contains("assign unbound variable"),
        "eval actual error: {}",
        err_ev.message
    );
}

/// Negative case 4: a macro-introduced binding does not capture the
/// user's same-named lexical binding (hygiene + scope set as dual
/// safeguards). `(define-syntax self7 ... (let ((t 7)) t))`; the user's
/// parameter `t` = 99; the macro expansion references its own t (α
/// renaming + the binder scope set contains the union of the
/// macro-introduced fresh scope and the use-site scope) → result 7. If
/// capture were broken (the user's t leaked into the macro body) → 99.
/// Both paths.
#[test]
fn macro_introduced_binding_does_not_capture_user_binding() {
    let src = r#"
        macro self7 { () => { let t = 7; t } }
        (|| (t: i64) { self7() })(99)
    "#;
    let a = run_source(src, "s5.ktf").unwrap();
    let b = run_source_seed(src, "s5.ktf").unwrap();
    assert_eq!(
        int_of(&a.value),
        7,
        "VM: macro-introduced t not by user t capture"
    );
    assert_eq!(
        int_of(&b.value),
        7,
        "eval: macro-introduced t not by user t capture"
    );
}

/// Control case (positive case 5): a matching reference scope set (one
/// containing the binding scope set) hits — under the same
/// hand-constructed skeleton, `binder ⊆ ref` ({7} ⊆ {7, 9}) resolves to
/// the parameter. Together with negative cases 1/2 it forms a
/// same-skeleton positive/negative pair, proving that the discriminating
/// difference is precisely the subset relation.
#[test]
fn scope_subset_match_resolves_to_param() {
    let mut table = SymbolTable::new();
    let x = table.intern("x");
    let binder = ScopeSet::from_iter_scopes([7]);
    let sup = ScopeSet::from_iter_scopes([7, 9]);
    let body = Rc::new(CoreExpr::Var {
        name: x,
        scopes: sup,
        span: Span::dummy(),
    });
    let lam = Rc::new(CoreExpr::Fn {
        params: vec![x],
        param_scopes: vec![binder],
        rest: None,
        body,
        span: Span::dummy(),
    });
    let arg = Rc::new(CoreExpr::Literal {
        value: kerf_core::LiteralValue::Int(42),
        span: Span::dummy(),
    });
    let app = Rc::new(CoreExpr::Apply {
        fn_expr: lam,
        args: vec![arg],
        span: Span::dummy(),
    });
    // VM path: hits the parameter → 42
    let program = compile_module(&expr_items(&[std::rc::Rc::clone(&app)])).unwrap();
    let mut globals = std::collections::HashMap::new();
    let mut heap = Heap::new();
    let r = run_program(&program, &mut globals, &mut heap).unwrap();
    assert!(matches!(r, Value::Int(42)), "VM subset match hit: {:?}", r);
    // eval path
    let root = Env::new();
    let mut heap2 = Heap::new();
    let r2 = eval_program(&expr_items(&[std::rc::Rc::clone(&app)]), &root, &mut heap2).unwrap();
    assert!(
        matches!(r2, Value::Int(42)),
        "eval subset match hit: {:?}",
        r2
    );
}

/// Negative case 5 (TD-018 r24 regression): non-bool if condition with
/// **message text identical across both paths** — VM (`JumpIfFalse`) and
/// eval (if arm) both construct the message from the single source
/// `messages::err_if_cond_bool` (previously the VM and eval sides emitted
/// two different message texts for this same error — a split that has
/// been eliminated). Hand-constructed `(if 1 2 3)` in the same skeleton,
/// run on both paths with comparison assertions.
#[test]
fn td018_if_cond_message_unified_dual_path() {
    let one = Rc::new(CoreExpr::Literal {
        value: kerf_core::LiteralValue::Int(1),
        span: Span::dummy(),
    });
    let two = Rc::new(CoreExpr::Literal {
        value: kerf_core::LiteralValue::Int(2),
        span: Span::dummy(),
    });
    let three = Rc::new(CoreExpr::Literal {
        value: kerf_core::LiteralValue::Int(3),
        span: Span::dummy(),
    });
    let if_expr = Rc::new(CoreExpr::If {
        cond: one,
        then_branch: two,
        else_branch: three,
        span: Span::dummy(),
    });
    // VM path
    let program = compile_module(&expr_items(&[std::rc::Rc::clone(&if_expr)])).unwrap();
    let mut globals = std::collections::HashMap::new();
    let mut heap = Heap::new();
    let err_vm = run_program(&program, &mut globals, &mut heap).unwrap_err();
    // eval path
    let root = Env::new();
    let mut heap2 = Heap::new();
    let err_ev = eval_program(
        &expr_items(&[std::rc::Rc::clone(&if_expr)]),
        &root,
        &mut heap2,
    )
    .unwrap_err();
    assert!(
        err_vm
            .message
            .contains("if condition requires bool, got int"),
        "VM message should contain unified prefix: {}",
        err_vm.message
    );
    assert!(
        err_ev
            .message
            .contains("if condition requires bool, got int"),
        "eval message should and VM same text: {}",
        err_ev.message
    );
    // TD-018 core criterion: the two paths' message texts are identical
    // (regression anchor for the elimination of the split)
    assert_eq!(
        err_vm.message, err_ev.message,
        "TD-018: if condition message must dual-path same text"
    );
}

// E6 close-out (r154 / 224-b5): converted to the target-syntax face.
//! Standard library minimal-set integration tests
//! (tests/v0/stage1/plan/stdlib_tests.rs ↔ docs/lang-design/09-stdlib.md
//! §2 inventory + 07 §3.3 stage-gate condition 3).
//!
//! r5 (batch B MUV 22-c): list operations / string processing / basic
//! I/O, ≥8 functions each. All positive and negative messages calibrated
//! against real runs (§9.4.3 forbids guessing); higher-order functions
//! (map/filter/foldl) are explicitly deferred to the B3 Reader-in-kerf
//! rewrite batch (implemented as a kerf-source preamble — verifying the
//! self-hosting proposition itself, §12 optimal>minimal: a Rust
//! implementation would remove B3's verification content).
//!
//! E6 skin notes (E6-CG §2): kebab builtin names are written snake_case
//! in source (`string-length` → `string_length` — the `-` ↔ `_` Reader
//! symbol-introduction mapping) while runtime messages keep the kebab
//! spelling; quoted-list datums have no target literal (r127 honest
//! boundary) — list data is built at runtime via `list(...)`/`cons(...)`
//! and `'sym` becomes `quote(sym)`; `'()` becomes `()` (unit = nil);
//! imports `(import kerf-list)` → `import kerf_list;`. Chained
//! comparisons are non-chaining on the target grammar — the TD-016
//! chained rows reduce to their binary infix faces (see
//! `comparison_chain_*`).

use crate::common;

use kerf_driver::{run_source, Stage};

/// Generic assertion: src fails at the Run stage (E0004), message
/// contains the substring.
fn expect_run_err(src: &str, msg: &str) {
    let err = match run_source(src, "stdlib-neg.ktf") {
        Ok(_) => panic!("expected an error, got Ok: {}", src),
        Err(e) => e,
    };
    assert_eq!(
        err.stage,
        Stage::Run,
        "stage mismatch:{}\n{}",
        src,
        err.rendered
    );
    assert!(
        err.rendered.contains(msg),
        "message missing `{}`: {}\n complete error: {}",
        msg,
        src,
        err.rendered
    );
}

// ---------------------------------------------------------------------------
// List operations (8 functions: length/append/reverse/list-ref/list-tail/member/assoc/last-pair)
// ---------------------------------------------------------------------------

/// List positive semantics (≥8 positive cases).
#[test]
fn list_ops_positive_semantics() {
    assert_eq!(common::run_rendered("import kerf_list;\nlength(())"), "0");
    assert_eq!(
        common::run_rendered("import kerf_list;\nlength(list(1, 2, 3))"),
        "3"
    );
    assert_eq!(
        common::run_rendered("import kerf_list;\nappend(list(1, 2), list(3, 4))"),
        "(1 2 3 4)"
    );
    assert_eq!(common::run_rendered("import kerf_list;\nappend()"), "nil");
    assert_eq!(
        common::run_rendered("import kerf_list;\nappend(list(1), 5)"),
        "(1 . 5)"
    ); // last argument returned as-is (improper allowed)
    assert_eq!(
        common::run_rendered("import kerf_list;\nreverse(list(1, 2, 3))"),
        "(3 2 1)"
    );
    assert_eq!(
        common::run_rendered("import kerf_list;\nreverse(())"),
        "nil"
    ); // the empty list = the nil value shape (same as '())
    assert_eq!(
        common::run_rendered("import kerf_list;\nnth(list(quote(a), quote(b), quote(c)), 0)"),
        "a"
    );
    assert_eq!(
        common::run_rendered("import kerf_list;\nnth(list(quote(a), quote(b), quote(c)), 2)"),
        "c"
    );
    assert_eq!(
        common::run_rendered(
            "import kerf_list;\ndrop(list(quote(a), quote(b), quote(c), quote(d)), 2)"
        ),
        "(c d)"
    );
    assert_eq!(
        common::run_rendered("import kerf_list;\ndrop(list(quote(a), quote(b)), 0)"),
        "(a b)"
    );
    assert_eq!(
        common::run_rendered("import kerf_list;\nmember(2, list(1, 2, 3))"),
        "(2 3)"
    );
    assert_eq!(
        common::run_rendered("import kerf_list;\nmember(9, list(1, 2, 3))"),
        "false"
    );
    assert_eq!(
        common::run_rendered(
            "import kerf_list;\nassoc(quote(b), list(list(quote(a), 1), list(quote(b), 2)))"
        ),
        "(b 2)"
    );
    assert_eq!(
        common::run_rendered("import kerf_list;\nassoc(quote(z), list(list(quote(a), 1)))"),
        "false"
    );
    assert_eq!(
        common::run_rendered("import kerf_list;\nlast_pair(list(1, 2, 3))"),
        "(3)"
    );
}

/// List negative semantics (arity/type/index boundaries, ≥12 cases).
#[test]
fn list_ops_negative_semantics() {
    expect_run_err("import kerf_list;\nlength(5)", "length requires list");
    expect_run_err(
        "import kerf_list;\nlength()",
        "procedure argument count mismatch: expected 1",
    );
    expect_run_err(
        "import kerf_list;\nlength(cons(1, 2))",
        "length requires list",
    ); // improper (runtime construction — the reader has no dotted-pair syntax)
    expect_run_err(
        "import kerf_list;\nreverse(quote(a))",
        "reverse requires list, got symbol",
    );
    expect_run_err(
        "import kerf_list;\nreverse(42)",
        "reverse requires list, got int",
    );
    expect_run_err(
        "import kerf_list;\nnth(list(quote(a), quote(b)), 5)",
        "index 5 out of list range",
    );
    expect_run_err(
        "import kerf_list;\nnth(list(quote(a), quote(b)), -1)",
        "index requires a non-negative integer, got -1",
    );
    expect_run_err(
        "import kerf_list;\nnth(list(quote(a), quote(b)), quote(x))",
        "nth index requires int, got symbol",
    );
    expect_run_err(
        "import kerf_list;\ndrop(list(quote(a)), 3)",
        "index 3 out of list range",
    );
    expect_run_err(
        "import kerf_list;\nmember(quote(a), 5)",
        "member second argument requires list, got int",
    );
    expect_run_err(
        "import kerf_list;\nassoc(quote(a), list(1, 2))",
        "assoc table item requires pair, got int",
    );
    expect_run_err(
        "import kerf_list;\nlast_pair(())",
        "last-pair requires non-empty list",
    );
    expect_run_err(
        "import kerf_list;\nappend(list(1, 2), 5, list(3))",
        "append # 2 requires list, got int",
    );
    expect_run_err(
        "import kerf_list;\nappend(quote(a), quote(b))",
        "append # 1 requires list, got symbol",
    );
}

// ---------------------------------------------------------------------------
// String processing (10 functions: str-length/substring/index-of/contains?/prefix?/
// suffix?/upcase/downcase/string->symbol/symbol->string + the string-append baseline)
// ---------------------------------------------------------------------------

/// String positive semantics (Unicode semantics: character indices, not
/// bytes; ≥10 positive cases).
#[test]
fn string_ops_positive_semantics() {
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring_length(\"\")"),
        "0"
    );
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring_length(\"héllo\")"),
        "5"
    ); // Unicode character count
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring_substring(\"héllo\", 1, 3)"),
        "él"
    );
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring_substring(\"abc\", 0, 3)"),
        "abc"
    );
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring_index_of(\"héllo wörld\", \"w\")"),
        "6"
    ); // character position
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring_index_of(\"abc\", \"z\")"),
        "-1"
    );
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring_contains(\"abc\", \"bc\")"),
        "true"
    );
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring_contains(\"abc\", \"z\")"),
        "false"
    );
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring_starts_with(\"abc\", \"ab\")"),
        "true"
    );
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring_starts_with(\"abc\", \"bc\")"),
        "false"
    );
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring_ends_with(\"abc\", \"bc\")"),
        "true"
    );
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring_to_upper(\"aé\")"),
        "AÉ"
    );
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring_to_lower(\"AÉ\")"),
        "aé"
    );
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring_append(\"a\", \"b\")"),
        "ab"
    );
    // TD-002 paired conversion (symbol values ↔ strings)
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring_to_symbol(\"foo\")"),
        "foo"
    );
    assert_eq!(
        common::run_rendered("import kerf_string;\nsymbol_to_string(quote(foo))"),
        "foo"
    );
    assert_eq!(
        common::run_rendered("import kerf_string;\neq(string_to_symbol(\"a\"), quote(a))"),
        "true"
    );
}

/// String negative semantics (type/index boundaries, ≥10 cases).
#[test]
fn string_ops_negative_semantics() {
    expect_run_err(
        "import kerf_string;\nstring_length(quote(a))",
        "string-length requires str, got symbol",
    );
    expect_run_err(
        "import kerf_string;\nstring_length(5)",
        "string-length requires str, got int",
    );
    expect_run_err(
        "import kerf_string;\nstring_substring(\"abc\", 0, 9)",
        "index out of bounds:0..9(length 3)",
    );
    expect_run_err(
        "import kerf_string;\nstring_substring(\"abc\", 2, 1)",
        "index out of bounds:2..1(length 3)",
    );
    expect_run_err(
        "import kerf_string;\nstring_substring(\"abc\", -1, 2)",
        "index out of bounds:-1..2",
    );
    expect_run_err(
        "import kerf_string;\nstring_substring(\"abc\", quote(a), quote(b))",
        "string-substring index requires int",
    );
    expect_run_err(
        "import kerf_string;\nstring_index_of(\"a\", 1)",
        "both operands require str, got str and int",
    );
    expect_run_err(
        "import kerf_string;\nstring_contains(1, \"a\")",
        "both operands require str, got int and str",
    );
    expect_run_err(
        "import kerf_string;\nstring_starts_with(1, 2)",
        "both operands require str",
    );
    expect_run_err(
        "import kerf_string;\nstring_to_symbol(5)",
        "string-to-symbol requires str, got int",
    );
    expect_run_err(
        "import kerf_string;\nsymbol_to_string(\"s\")",
        "symbol-to-string requires symbol, got str",
    );
}

// ---------------------------------------------------------------------------
// Basic I/O (6 functions: newline/write-string/read-int/read-num/error/assert-eq?)
// ---------------------------------------------------------------------------

/// I/O positive semantics (non-interactive functions; anchoring the EOF
/// and parsing behavior of read-int/read-num via stdin redirection
/// inside dual-path tests is not feasible — verified at the CLI layer;
/// ≥6 positive cases).
#[test]
fn io_ops_positive_semantics() {
    assert_eq!(common::run_rendered("require io, write;\nnewline()"), "nil");
    assert_eq!(
        common::run_rendered("require io, write;\nwrite_string(\"x\")"),
        "nil"
    );
    assert_eq!(
        common::run_rendered("assert_eq(quote(a), quote(a))"),
        "true"
    );
    assert_eq!(common::run_rendered("assert_eq(1, 1)"), "true");
    assert_eq!(common::run_rendered("assert_eq(\"s\", \"s\")"), "true");
    // error message passthrough (user structured error reporting)
    let err = run_source("error(\"custom msg\")", "io.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Run);
    assert!(err.rendered.contains("custom msg"));
}

/// I/O negative semantics (arity/type, ≥6 cases).
#[test]
fn io_ops_negative_semantics() {
    expect_run_err(
        "require io, write;\nnewline(1)",
        "newline requires 0 arguments",
    );
    expect_run_err(
        "require io, write;\nwrite_string(5)",
        "write-string requires str, got int",
    );
    expect_run_err(
        "require io, read;\nread_int(1)",
        "read-int requires 0 arguments",
    );
    expect_run_err(
        "require io, read;\nread_num(1)",
        "read-num requires 0 arguments",
    );
    expect_run_err("error()", "error requires ≥1 arguments");
    expect_run_err("assert_eq(1, 2)", "assert-eq assertion failed: 1 ≠ 2");
    expect_run_err("assert_eq(1)", "assert-eq requires 2 arguments");
}

// ---------------------------------------------------------------------------
// Dual-path agreement (T1: VM and eval renderings equivalent — high density via dual_path_agrees)
// ---------------------------------------------------------------------------

/// Standard library dual-path agreement (the pure-function subset — I/O
/// side-effecting functions excluded).
#[test]
fn stdlib_dual_path_agreement() {
    assert!(common::dual_path_agrees(
        "import kerf_list;\nlength(list(1, 2, 3))"
    ));
    assert!(common::dual_path_agrees(
        "import kerf_list;\nappend(list(1, 2), list(3))"
    ));
    assert!(common::dual_path_agrees(
        "import kerf_list;\nreverse(list(1, 2, 3))"
    ));
    assert!(common::dual_path_agrees(
        "import kerf_list;\nnth(list(quote(a), quote(b), quote(c)), 1)"
    ));
    assert!(common::dual_path_agrees(
        "import kerf_list;\ndrop(list(quote(a), quote(b), quote(c)), 1)"
    ));
    assert!(common::dual_path_agrees(
        "import kerf_list;\nmember(2, list(1, 2, 3))"
    ));
    assert!(common::dual_path_agrees(
        "import kerf_list;\nassoc(quote(a), list(list(quote(a), 1)))"
    ));
    assert!(common::dual_path_agrees(
        "import kerf_list;\nlast_pair(list(1, 2))"
    ));
    assert!(common::dual_path_agrees(
        "import kerf_string;\nstring_length(\"héllo\")"
    ));
    assert!(common::dual_path_agrees(
        "import kerf_string;\nstring_substring(\"héllo\", 1, 3)"
    ));
    assert!(common::dual_path_agrees(
        "import kerf_string;\nstring_to_symbol(\"x\")"
    ));
    assert!(common::dual_path_agrees(
        "import kerf_string;\nsymbol_to_string(quote(x))"
    ));
    assert!(common::dual_path_agrees(
        "import kerf_string;\nstring_to_upper(\"aé\")"
    ));
    assert!(common::dual_path_agrees(
        "import kerf_string;\nstring_index_of(\"abc\", \"b\")"
    ));
}

// ---------------------------------------------------------------------------
// Negative-matrix expansion (§9.4.3 global ≥1:3 maintained: 24 new
// functions × arity/type/boundary)
// All messages calibrated against real runs (2026-09-10 probe batch +
// the 224-b5 target-face re-calibration)
// ---------------------------------------------------------------------------

/// Arity matrix (24 functions one by one: 0-arg/too-few/too-many forms
/// per each contract).
#[test]
fn stdlib_negative_arity_matrix() {
    let cases: &[(&str, &str)] = &[
        (
            "import kerf_list;\nlength()",
            "procedure argument count mismatch: expected 1, got 0",
        ),
        (
            "import kerf_list;\nlength(1, 2)",
            "procedure argument count mismatch: expected 1, got 2",
        ),
        (
            "import kerf_list;\nreverse()",
            "procedure argument count mismatch: expected 1, got 0",
        ),
        (
            "import kerf_list;\nreverse(1, 2)",
            "procedure argument count mismatch: expected 1, got 2",
        ),
        (
            "import kerf_list;\nnth()",
            "procedure argument count mismatch: expected 2, got 0",
        ),
        (
            "import kerf_list;\ndrop()",
            "procedure argument count mismatch: expected 2, got 0",
        ),
        (
            "import kerf_list;\nmember()",
            "member requires 2 arguments, got 0",
        ),
        (
            "import kerf_list;\nmember(1)",
            "member requires 2 arguments, got 1",
        ),
        (
            "import kerf_list;\nassoc()",
            "assoc requires 2 arguments, got 0",
        ),
        (
            "import kerf_list;\nassoc(quote(a))",
            "assoc requires 2 arguments, got 1",
        ),
        (
            "import kerf_list;\nlast_pair()",
            "procedure argument count mismatch: expected 1, got 0",
        ),
        (
            "import kerf_string;\nstring_length()",
            "string-length requires 1 arguments, got 0",
        ),
        (
            "import kerf_string;\nstring_substring(\"a\")",
            "string-substring requires 3 arguments",
        ),
        (
            "import kerf_string;\nstring_index_of(\"a\")",
            "string-index-of requires 2 arguments, got 1",
        ),
        (
            "import kerf_string;\nstring_contains(\"a\")",
            "string-contains requires 2 arguments, got 1",
        ),
        (
            "import kerf_string;\nstring_starts_with(\"a\")",
            "string-starts-with requires 2 arguments, got 1",
        ),
        (
            "import kerf_string;\nstring_to_upper()",
            "string-to-upper requires 1 arguments, got 0",
        ),
        (
            "import kerf_string;\nstring_to_symbol()",
            "string-to-symbol requires 1 arguments, got 0",
        ),
        (
            "import kerf_string;\nsymbol_to_string()",
            "symbol-to-string requires 1 arguments, got 0",
        ),
        (
            "require io, write;\nnewline(1, 2)",
            "newline requires 0 arguments, got 2",
        ),
        (
            "require io, write;\nwrite_string()",
            "write-string requires 1 arguments, got 0",
        ),
        (
            "require io, read;\nread_int(1, 2)",
            "read-int requires 0 arguments, got 2",
        ),
        (
            "require io, read;\nread_num(quote(a))",
            "read-num requires 0 arguments, got 1",
        ),
        ("error()", "error requires ≥1 arguments"),
        ("assert_eq()", "assert-eq requires 2 arguments, got 0"),
    ];
    for (src, msg) in cases {
        expect_run_err(src, msg);
    }
}

/// Type matrix (parameter type misuse — including two-argument type
/// combination reports).
#[test]
fn stdlib_negative_type_matrix() {
    let cases: &[(&str, &str)] = &[
        (
            "import kerf_list;\nlength(\"s\")",
            "length requires list(nil terminated pair chain), got str",
        ),
        (
            "import kerf_list;\nappend(1, 2)",
            "append # 1 requires list, got int",
        ),
        (
            "import kerf_list;\nappend(\"a\", ())",
            "append # 1 requires list, got str",
        ),
        (
            "import kerf_list;\nreverse(\"s\")",
            "reverse requires list, got str",
        ),
        (
            "import kerf_list;\ndrop(5, 0)",
            "drop requires list, got int",
        ),
        (
            "import kerf_list;\nmember(2, cons(1, 2))",
            "member second argument requires list, got int",
        ),
        (
            "import kerf_list;\nassoc(quote(a), 5)",
            "assoc second argument requires list, got int",
        ),
        (
            "import kerf_list;\nassoc(quote(a), list(1))",
            "assoc table item requires pair, got int",
        ),
        (
            "import kerf_list;\nlast_pair(5)",
            "last-pair requires list, got int",
        ),
        (
            "import kerf_list;\nlast_pair(cons(1, 2))",
            "last-pair requires list, got int",
        ),
        (
            "import kerf_string;\nstring_length(true)",
            "string-length requires str, got bool",
        ),
        (
            "import kerf_string;\nstring_substring(1, 0, 1)",
            "string-substring requires str, got int",
        ),
        (
            "import kerf_string;\nstring_substring(\"abc\", quote(a), quote(b))",
            "string-substring index requires int, got symbol",
        ),
        (
            "import kerf_string;\nstring_index_of(1, 2)",
            "string-index-of both operands require str, got int and int",
        ),
        (
            "import kerf_string;\nstring_contains(quote(a), quote(b))",
            "string-contains both operands require str, got symbol and symbol",
        ),
        (
            "import kerf_string;\nstring_starts_with((), ())",
            "string-starts-with both operands require str, got nil and nil",
        ),
        (
            "import kerf_string;\nstring_to_upper(quote(a))",
            "string-to-upper requires str, got symbol",
        ),
        (
            "import kerf_string;\nstring_to_symbol(quote(a))",
            "string-to-symbol requires str, got symbol",
        ),
        (
            "import kerf_string;\nsymbol_to_string(5)",
            "symbol-to-string requires symbol, got int",
        ),
        (
            "require io, write;\nwrite_string(quote(a))",
            "write-string requires str, got symbol",
        ),
        (
            "import kerf_string;\nstring_substring(\"abc\", 2, 1)",
            "index out of bounds:2..1(length 3)",
        ),
    ];
    for (src, msg) in cases {
        expect_run_err(src, msg);
    }
}

/// Boundary matrix (index/empty-structure/improper boundaries +
/// structured error-report content).
#[test]
fn stdlib_negative_boundary_matrix() {
    let cases: &[(&str, &str)] = &[
        (
            "import kerf_list;\nnth(list(quote(a)), 1)",
            "nth index 1 out of list range",
        ),
        (
            "import kerf_list;\nnth(quote(a), 0)",
            "nth index 0 out of list range",
        ),
        (
            "import kerf_list;\ndrop(list(quote(a)), 3)",
            "drop index 3 out of list range",
        ),
        (
            "import kerf_list;\ndrop(list(quote(a), quote(b)), 5)",
            "drop index 5 out of list range",
        ),
        (
            "import kerf_list;\nlast_pair(())",
            "last-pair requires non-empty list",
        ),
        ("error(quote(sym))", "symbol"), // non-string parts render as type names
        (
            "assert_eq(quote(a), 1)",
            "assert-eq assertion failed: a ≠ 1",
        ),
        (
            "assert_eq(\"a\", \"b\")",
            "assert-eq assertion failed: a ≠ b",
        ),
        (
            "import kerf_list;\nmember(9, cons(1, 2))",
            "member second argument requires list, got int",
        ),
    ];
    for (src, msg) in cases {
        expect_run_err(src, msg);
    }
}

/// Racket semantics boundary notes (positive cases confirmed by real
/// runs — the inverse archival of the negative matrix):
/// - `append(1)` → 1 (single-argument identity — the last argument
///   as-is, same as Racket);
/// - `member(1, cons(1, 2))` → (1 . 2) (an improper list returns
///   immediately on a first-element hit).
#[test]
fn stdlib_racket_semantics_boundary_notes() {
    assert_eq!(common::run_rendered("import kerf_list;\nappend(1)"), "1");
    assert_eq!(
        common::run_rendered("import kerf_list;\nmember(1, cons(1, 2))"),
        "(1 . 2)"
    );
    // drop k=0 identity (list input)
    assert_eq!(
        common::run_rendered("import kerf_list;\ndrop(list(quote(a), quote(b)), 0)"),
        "(a b)"
    );
    assert_eq!(
        common::run_rendered("import kerf_list;\ndrop((), 0)"),
        "nil"
    );
}

// ---------------------------------------------------------------------------
// Type-matrix expansion (§9.4.3 global ≥1:3 maintained — type-name
// message templates verified with many samples: str functions × non-str
// inputs / list functions × non-list inputs, full type scans)
// ---------------------------------------------------------------------------

/// Full type scan of the first argument of str functions (the "needs
/// str, actual TYPE" message template verified stable by real runs).
#[test]
fn stdlib_negative_str_type_scan() {
    // Representative non-str values: int / float / bool / nil / symbol /
    // pair
    let type_repr: &[(&str, &str)] = &[
        ("5", "int"),
        ("1.5", "float"),
        ("true", "bool"),
        ("()", "nil"),
        ("quote(sym)", "symbol"),
        ("list(1)", "pair"),
    ];
    let single_arg_fns: &[&str] = &[
        "string_length",
        "string_to_upper",
        "string_to_lower",
        "string_to_symbol",
        "write_string",
    ];
    for fn_name in single_arg_fns {
        for (val, ty) in type_repr {
            // write_string gating (r8 R9): declare the write capability
            // first, then trigger the type error
            let src = if *fn_name == "write_string" {
                format!("require io, write;\n{}({})", fn_name, val)
            } else {
                // r47 visibility tightening: string-domain flat names
                // need import kerf_string
                format!("import kerf_string;\n{}({})", fn_name, val)
            };
            // kebab message face (the `-` ↔ `_` mapping is source-side
            // only — runtime messages keep the kebab spelling)
            let kebab = fn_name.replace('_', "-");
            let msg = format!("{} requires str, got {}", kebab, ty);
            expect_run_err(&src, &msg);
        }
    }
    // symbol-to-string reverse scan (needs symbol, actual non-symbol)
    for (val, ty) in type_repr {
        if *ty != "symbol" {
            let src = format!("import kerf_string;\nsymbol_to_string({})", val);
            let msg = format!("symbol-to-string requires symbol, got {}", ty);
            expect_run_err(&src, &msg);
        }
    }
}

/// Full input-type scan of list functions (the "needs list…, actual
/// TYPE" message template verified stable by real runs).
#[test]
fn stdlib_negative_list_type_scan() {
    let type_repr: &[(&str, &str)] = &[
        ("5", "int"),
        ("1.5", "float"),
        ("\"s\"", "str"),
        ("true", "bool"),
        ("quote(sym)", "symbol"),
    ];
    // length/reverse/last-pair: single-argument list contracts
    for fn_name in &["length", "reverse", "last_pair"] {
        for (val, ty) in type_repr {
            // r47 visibility tightening: list-domain flat names need
            // import kerf_list
            let src = format!("import kerf_list;\n{}({})", fn_name, val);
            let prefix = if *fn_name == "length" {
                "list(nil terminated pair chain)"
            } else {
                "list"
            };
            let kebab = fn_name.replace('_', "-");
            let msg = format!("{} requires {}, got {}", kebab, prefix, ty);
            expect_run_err(&src, &msg);
        }
    }
    // drop: second argument is the list (k=0 still rejects non-list —
    // per-step shape validation)
    for (val, ty) in type_repr {
        let src = format!("import kerf_list;\ndrop({}, 0)", val);
        let msg = format!("drop requires list, got {}", ty);
        expect_run_err(&src, &msg);
    }
}

/// assert-eq structural semantics boundary (r162 / 233 — TD-037 D4/D5:
/// eq/assert-eq/member/assoc inherit the structural value-equality law —
/// isomorphic lists are NOW equal; procedural identity + no implicit
/// numeric tower (Int ≠ Float) stay).
#[test]
fn stdlib_eq_semantics_boundaries() {
    // r162 law: isomorphic but distinct list allocations are equal
    // (structural walk; the pre-r162 reference-identity expectation
    // retired with the equality-domain window)
    assert_eq!(common::run_rendered("assert_eq(list(1), list(1))"), "true");
    // eq has no numeric tower: 1 ≠ 1.0
    expect_run_err("assert_eq(1, 1.0)", "assert-eq assertion failed: 1 ≠ 1.0");
    // Strings by content (D2 fix semantics) — positive case
    assert_eq!(common::run_rendered("assert_eq(\"a\", \"a\")"), "true");
    // Symbols by name (TD-002) — positive case
    assert_eq!(
        common::run_rendered("import kerf_string;\nassert_eq(string_to_symbol(\"a\"), quote(a))"),
        "true"
    );
}

/// Type scan of the second argument of two-argument str functions
/// (first argument a valid str, second argument misused per type — the
/// "both arguments need str, actual str and TYPE" template verified
/// stable by real runs).
#[test]
fn stdlib_negative_str_second_arg_scan() {
    let bad: &[(&str, &str)] = &[
        ("5", "int"),
        ("1.5", "float"),
        ("true", "bool"),
        ("()", "nil"),
        ("quote(sym)", "symbol"),
    ];
    for fn_name in &[
        "string_index_of",
        "string_contains",
        "string_starts_with",
        "string_ends_with",
    ] {
        for (val, ty) in bad {
            // r47 visibility tightening: string-domain flat names need
            // import kerf_string
            let src = format!("import kerf_string;\n{}(\"a\", {})", fn_name, val);
            let kebab = fn_name.replace('_', "-");
            let msg = format!("{} both operands require str, got str and {}", kebab, ty);
            expect_run_err(&src, &msg);
        }
    }
    // string-append two-argument contract (second argument wrong type)
    for (val, _ty) in bad {
        let src = format!("import kerf_string;\nstring_append(\"a\", {})", val);
        expect_run_err(&src, "string-append requires 2 strings");
    }
    // member/assoc first argument is anything (eq compares anything) —
    // the second argument is already scanned; supplement append's
    // middle-argument types (non-tail positions — the tail argument
    // as-is allows improper)
    expect_run_err(
        "import kerf_list;\nappend(list(), 5, list())",
        "append # 2 requires list, got int",
    );
    expect_run_err(
        "import kerf_list;\nappend(list(), list(), 5, list())",
        "append # 3 requires list, got int",
    );
    expect_run_err(
        "import kerf_list;\nappend(list(), \"s\", list())",
        "append # 2 requires list, got str",
    );
}

// ---------------------------------------------------------------------------
// TD-016 (batch C): up-front validation of all chained-comparison operands
// E6 note: the target grammar's comparison is non-chaining (binary infix
// — pipeline_tests `builtin_library_registered` anchor); the S-expr
// chained rows `(< 3 1 "a")` / `(>= 5 2 'sym)` / `(= 1 2 "s")` /
// `(< 1 2 3 "a" 4)` and the chained positives `(< 1 2 3)` / `(< 3 1 2)`
// / `(= 1 1 1)` / `(= "a" "a" "a")` are retired with that face (record:
// 224-b5, 8 rows) — the binary face checks both operands up front by
// construction (each operand is always evaluated and checked), which is
// the TD-016 criterion in its target-face form.
// ---------------------------------------------------------------------------

/// TD-016 negatives (binary face): a comparison's operands are checked
/// before the verdict — the mixed-type rows keep the "requires a
/// number" criterion (first non-numeric operand blamed, regardless of
/// position).
#[test]
fn comparison_chain_all_operands_checked() {
    // Right operand non-numeric (checked — not skipped by a verdict)
    expect_run_err("\"a\" < 1", "< requires a number");
    expect_run_err("1 > quote(sym)", "> requires a number");
    // r162 / 233 — TD-037: the equality row retired (mixed `\"s\" == 1`
    // is silent `false` by design — see ktf_equality_domain_tests);
    // the ordering family keeps the operand-checked criterion
    // Left operand non-numeric (position-symmetric criterion)
    expect_run_err("quote(sym) >= 2", ">= requires a number");
    // All-numeric comparisons unaffected (positive regression anchor —
    // short-circuit value semantics preserved)
    assert_eq!(common::run_rendered("1 < 2"), "true");
    assert_eq!(common::run_rendered("3 < 1"), "false");
    assert_eq!(common::run_rendered("1 == 1"), "true");
    // All-string equality unaffected (string equality of == preserved)
    assert_eq!(common::run_rendered("\"a\" == \"a\""), "true");
}

/// TD-016 convergence note: mixed-string comparisons unify on the
/// "needs number" message (the first non-numeric operand is blamed; the
/// two-argument message criterion is unchanged). (The S-expr chained
/// mixed rows `(< "a" "b" 1)` / `(> 1 "a" "b")` retired with the
/// non-chaining grammar — record: 224-b5, 2 rows.)
#[test]
fn comparison_chain_mixed_string_converges() {
    expect_run_err("\"a\" < 1", "< requires a number");
    expect_run_err("1 > \"a\"", "> requires a number");
    // Two-argument mixed-string criterion unchanged (regression anchor)
    expect_run_err("\"a\" < 1", "< requires a number");
}

// ---------------------------------------------------------------------------
// String total-order comparison (TD-011 resolved in r24: codepoint order)
// ---------------------------------------------------------------------------

/// String total-order positive semantics (12 cases): Unicode codepoint
/// order = UTF-8 byte order (order-preserving encoding); all four
/// ordering operators + codepoint boundaries (ASCII uppercase
/// < lowercase; non-ASCII multibyte order).
#[test]
fn string_ordering_codepoint_positive() {
    // Basic lexicographic order (ASCII)
    assert_eq!(common::run_rendered("\"a\" < \"b\""), "true");
    assert_eq!(common::run_rendered("\"b\" > \"a\""), "true");
    assert_eq!(common::run_rendered("\"a\" <= \"a\""), "true");
    assert_eq!(common::run_rendered("\"a\" >= \"a\""), "true");
    assert_eq!(common::run_rendered("\"b\" < \"a\""), "false");
    // Codepoint-order boundary: uppercase Z (0x5A) < lowercase a (0x61)
    assert_eq!(common::run_rendered("\"Z\" < \"a\""), "true");
    // Multibyte codepoint order: z (0x7A) < é (0xE9) < U+4E2D (the CJK
    // character used below)
    assert_eq!(common::run_rendered("\"z\" < \"é\""), "true");
    assert_eq!(common::run_rendered("\"é\" < \"中\""), "true");
    assert_eq!(common::run_rendered("\"中\" > \"é\""), "true");
    // Prefix order: shorter string < longer string with the same prefix
    // ("ab" < "abc")
    assert_eq!(common::run_rendered("\"ab\" < \"abc\""), "true");
}

/// String total-order negatives (2 cases, §9.4.3 paired positive/
/// negative): the boundary with the existing numeric-domain message (a
/// non-string mixed into a string ordering → the first non-numeric
/// operand is blamed — the TD-016 criterion preserved). (The S-expr
/// arity row `(< \"a\")` retired — a unary comparison is unparseable on
/// the non-chaining target grammar; record: 224-b5, 1 row.)
#[test]
fn string_ordering_negative_boundary() {
    expect_run_err("\"a\" < 1", "< requires a number");
    // Symbol values are not strings (outside the ordering-comparison
    // domain)
    expect_run_err("quote(a) < quote(b)", "< requires a number");
}

// ---------------------------------------------------------------------------
// Closure/builtin boxing (TD-010 resolved in r24: pair elements truly boxed)
// ---------------------------------------------------------------------------

/// Boxing round-trip positive semantics (10 cases): closures/builtins
/// as pair elements — unboxing restores callable values (Rc identity →
/// eq equality by reference; is-procedure discrimination; list
/// construction boxes element by element; rendering `#<procedure>` /
/// `#<builtin:NAME>`).
#[test]
fn procedure_boxing_roundtrip_positive() {
    // Closure boxed → unboxed → called immediately
    assert_eq!(
        common::run_rendered("(head(cons(|| (x: T) { x }, ())))(42)"),
        "42"
    );
    // Builtin boxed → unboxed → called
    assert_eq!(
        common::run_rendered("(head(cons(head, ())))(list(7, 8))"),
        "7"
    );
    // is-procedure discrimination preserved through the round trip
    assert_eq!(
        common::run_rendered("is_procedure(head(cons(|| (x: T) { x }, ())))"),
        "true"
    );
    assert_eq!(
        common::run_rendered("is_procedure(head(cons(head, ())))"),
        "true"
    );
    // eq identity (Rc-shared boxing — equal by reference)
    assert_eq!(
        common::run_rendered("let f = || (x: T) { x }; eq(head(cons(f, ())), f)"),
        "true"
    );
    // list construction boxes element by element (the list-of-functions
    // pattern — the prerequisite for library-ization)
    assert_eq!(
        common::run_rendered(
            "let fs = list(|| (x: T) { x * 2 }, || (x: T) { x + 1 }); (head(fs))(21)"
        ),
        "42"
    );
    assert_eq!(
        common::run_rendered(
            "let fs = list(|| (x: T) { x * 2 }, || (x: T) { x + 1 }); (head(tail(fs)))(41)"
        ),
        "42"
    );
    // map applied to a list of functions (prelude higher-order face +
    // boxing cooperating)
    assert_eq!(
        common::run_rendered(
            "import kerf_prelude;\nmodule m { import kerf_prelude;\n let fs = list(|| (x: T) { x * 2 });\n head(map(|| (f: T) { f(21) }, fs)) }"
        ),
        "42"
    );
    // Rendering shape (r42/S1: modernized primary names — #<builtin:head>)
    assert_eq!(
        common::run_rendered("head(cons(|| (x: T) { x }, ()))"),
        "#<procedure>"
    );
    assert_eq!(
        common::run_rendered("cons(1, cons(head, ()))"),
        "(1 #<builtin:head>)"
    );
    // Dotted-pair shape (the tail is directly a boxed value)
    assert_eq!(
        common::run_rendered("cons(1, head(cons(head, ())))"),
        "(1 . #<builtin:head>)"
    );
}

/// Boxing boundary negatives (2 cases, §9.4.3): boxed values are still
/// values — data-position semantics unchanged (arithmetic positions
/// reject function values; pair rendering does not misprint them as
/// strings).
#[test]
fn procedure_boxing_negative_boundary() {
    expect_run_err("1 + head(cons(|| (x: T) { x }, ()))", "+ requires int");
    expect_run_err(
        "head(head(cons(|| (x: T) { x }, ())))",
        "head requires pair, got procedure",
    );
}

// ---------------------------------------------------------------------------
// Type-predicate completeness face (r24 / 42-e stdlib gap fill: 5 Value-variant discriminators)
// ---------------------------------------------------------------------------

/// New predicate positive semantics (17 cases): string?/symbol?/float?/
/// number?/list? — positive and negative cases per predicate × no
/// cross-type confusion; is-list covers the proper-list/dotted/cyclic
/// three states.
#[test]
fn type_predicates_positive() {
    // is-string
    assert_eq!(common::run_rendered("is_string(\"a\")"), "true");
    assert_eq!(common::run_rendered("is_string(1)"), "false");
    assert_eq!(common::run_rendered("is_string(quote(a))"), "false");
    // is-symbol
    assert_eq!(common::run_rendered("is_symbol(quote(a))"), "true");
    assert_eq!(common::run_rendered("is_symbol(\"a\")"), "false");
    assert_eq!(common::run_rendered("is_symbol(())"), "false");
    // is-float / is-number (the numeric tower's two states)
    assert_eq!(common::run_rendered("is_float(1.5)"), "true");
    assert_eq!(common::run_rendered("is_float(1)"), "false");
    assert_eq!(common::run_rendered("is_number(1)"), "true");
    assert_eq!(common::run_rendered("is_number(1.5)"), "true");
    assert_eq!(common::run_rendered("is_number(\"1\")"), "false");
    // is-list: nil / proper list / dotted pair / non-list value
    assert_eq!(common::run_rendered("is_list(())"), "true");
    assert_eq!(common::run_rendered("is_list(list(1, 2, 3))"), "true");
    assert_eq!(common::run_rendered("is_list(())"), "true");
    assert_eq!(common::run_rendered("is_list(cons(1, 2))"), "false");
    assert_eq!(common::run_rendered("is_list(5)"), "false");
    // Cooperation with the existing predicate family (spot-checking
    // discriminator-face mutual exclusivity)
    assert_eq!(common::run_rendered("is_list(cons(1, ()))"), "true");
    assert_eq!(common::run_rendered("is_pair(cons(1, 2))"), "true");
}

/// is-list cycle safety (2 cases): a cyclic tail chain → false (Floyd
/// tortoise-and-hare — a proper list's tail chain has no cycles;
/// following Racket semantics). Cycles are constructed via assign tail.
#[test]
fn list_predicate_cycle_safe() {
    // Self-cycle: (define x (list 1)) (assign ... tail ...) — assign
    // acts on pair elements and needs the car/cdr boxing round trip;
    // kerf has no set-car!/set-cdr! (pairs are immutable), so cycles
    // cannot be constructed from the user face → this case is anchored
    // at the unit layer (a face unreachable by vm integration), and the
    // assertion becomes: a long proper list is judged correctly (Floyd
    // terminates on deep chains)
    assert_eq!(
        common::run_rendered("is_list(list(1, 2, 3, 4, 5, 6, 7, 8, 9, 10))"),
        "true"
    );
    assert_eq!(
        common::run_rendered("import kerf_list;\nis_list(append(list(1, 2), cons(3, 4)))"),
        "false"
    );
}

/// New predicate negatives (3 cases, §9.4.3): arity validation.
#[test]
fn type_predicates_negative_arity() {
    expect_run_err("is_string()", "is-string requires 1 arguments");
    expect_run_err("is_number(1, 2)", "is-number requires 1 arguments, got 2");
    expect_run_err("is_list((), ())", "is-list requires 1 arguments, got 2");
}

// ---------------------------------------------------------------------------
// r42 / 63-b removal round S1 (v0.9) — retired-old-name negative
// group (the 20 §7 removal-round line: old-name reference = E0021
// compile-time error, diagnostics carry modern-name guidance —
// fail-closed). Mapping single source = 20 §8; registration single
// source = builtins.rs REMOVED_BUILTIN_NAMES (the closure guard
// removed_names_group_covers_all_27 reconciles — guarding against the
// bidirectional drifts "retired but not rejected" and "rejected but
// not retired"). The removal-round evolution of the r38 parity group:
// the dual-name same-behavior parity assertions (the v0.5-v0.8 dual
// registration period) converge into "unique names + old-name
// rejection" (the v0.9 removal period — 23 §3.4's lifecycle four
// stages walked in full).
//
// E6 note (224-b5): the target-face identifier charset is
// [A-Za-z0-9_] (kerf-reader target.rs is_id_start/is_id_continue) —
// old names whose kebab spelling is hyphen-only (`list-ref`,
// `str-append`, …) stay writable via the snake spelling (the `-` ↔ `_`
// Reader mapping reaches the same retired symbol); the 17 old names
// carrying `?` or `->` (`null?`/`pair?`/`int?`/`bool?`/`procedure?`/
// `string?`/`symbol?`/`float?`/`number?`/`list?`/`eq?`/`str-contains?`/
// `str-prefix?`/`str-suffix?`/`string->symbol`/`symbol->string`/
// `assert-eq?`) are lexically unwritable on the target face (E0001
// illegal character / `->` operator domain) — their nine S-expr test
// groups below are retired with that boundary (record: 224-b5; the
// E0021 rejection itself stays guarded by the nine lexable-name groups
// + the closure guard's lexable-subset leg + the driver-side unit
// surface).
// ---------------------------------------------------------------------------

/// Retired-old-name negatives: compile-time E0021 (stage Compile +
/// code [E0021] + message carries modern-name guidance and the removal
/// version). Rejected uniformly in value and operator positions across
/// the whole domain (same traversal as E0014).
fn expect_removed(old_src: &str, modern: &str) {
    let err = match run_source(old_src, "removed-neg.ktf") {
        Ok(_) => panic!(
            "old name expected E0021 compile-time rejected, got Ok: {}",
            old_src
        ),
        Err(e) => e,
    };
    assert_eq!(
        err.stage,
        Stage::Compile,
        "stage should be Compile(old name compile-time block assert): {}\n{}",
        old_src,
        err.rendered
    );
    assert!(
        err.rendered.contains("[E0021]"),
        "should be E0021 code position: {}\n complete error: {}",
        old_src,
        err.rendered
    );
    assert!(
        err.rendered.contains(&format!("modern name `{}`", modern)),
        "message should contain modern name refers to quote `{}`: {}\n complete error: {}",
        modern,
        old_src,
        err.rendered
    );
}

/// `car`/`cdr` retired (R1 accessors — modern names head/tail).
#[test]
fn removed_rejects_car_cdr() {
    expect_removed("car(list(1, 2, 3))", "head");
    expect_removed("cdr(list(1, 2, 3))", "tail");
    expect_removed("(|| (x: T) { car(x) })(list(1, 2))", "head"); // nested value position rejected likewise
}

/// `list-ref`/`list-tail` retired (R1 compression — modern names
/// nth/drop).
#[test]
fn removed_rejects_list_ref_list_tail() {
    expect_removed("list_ref(list(quote(a), quote(b), quote(c)), 0)", "nth");
    expect_removed("list_tail(list(quote(a), quote(b), quote(c)), 1)", "drop");
}

/// `str-append`/`str-length` retired (R1 full words — modern names
/// string-*).
#[test]
fn removed_rejects_str_append_length() {
    expect_removed("str_append(\"a\", \"b\")", "string-append");
    expect_removed("str_length(\"ab\")", "string-length");
}

/// `str-substring`/`str-index-of` retired (R1 — modern names
/// string-*).
#[test]
fn removed_rejects_str_substring_index() {
    expect_removed("str_substring(\"abc\", 0, 2)", "string-substring");
    expect_removed("str_index_of(\"abc\", \"b\")", "string-index-of");
}

/// `str-upcase`/`str-downcase` retired (R4 conversion-direction
/// words).
#[test]
fn removed_rejects_str_case() {
    expect_removed("str_upcase(\"a\")", "string-to-upper");
    expect_removed("str_downcase(\"A\")", "string-to-lower");
}

/// N3 local-shadowing exemption (R-N1 — same criterion as E0014): an
/// fn parameter named with an old name is legal (what is retired is
/// the builtin registration face, not the symbol-universe layer; after
/// the parameter shadows it, references in the body = the local name).
#[test]
fn removed_shadowed_by_param_is_legal() {
    // (|| (car) car) — car is a parameter name, not a builtin
    // reference: compiles, behaves as the identity
    let out = common::run_rendered("(|| (car: T) { car })(5)");
    assert_eq!(
        out, "5",
        "argument shadow old name should be legal(N3 local binding wins output)"
    );
}

/// User-takeover exemption: a user define of an old name = a legal
/// user global (same takeover criterion as E0014).
#[test]
fn removed_user_takeover_is_legal() {
    let out = common::run_rendered("fn car(x: T) { x + 1 } car(5)");
    assert_eq!(
        out, "6",
        "user takeover old name should be legal(retired is builtin registration face)"
    );
}

/// Retirement closure guard (bidirectional reconciliation of the
/// 20 §7 removal-round line): this group's static modern-name list ↔
/// the driver's retired table, reconciled name by name — zero missing
/// (retired but not rejected), zero excess (rejected but not retired),
/// count exactly 27; every lexable name's E0021 verified by real runs
/// (the old name rejected through the full production pipeline) + the
/// modern name resolvable on the normal path (the inverse of testing
/// unregistered names). (The 17 charset-unwritable old names — `?` /
/// `->` spellings — are skipped on the E0021 real-run leg with the
/// boundary noted above; their rejection face remains anchored by the
/// driver-side REMOVED_BUILTIN_NAMES table + the nine lexable-name
/// groups.)
#[test]
fn removed_names_group_covers_all_27() {
    // This group's static list (corresponding to the modern names of
    // the #[test] fn removed_rejects_* above)
    let tested: &[&str] = &[
        "head",
        "tail",
        "nth",
        "drop",
        "is-nil",
        "is-pair",
        "is-int",
        "is-bool",
        "is-procedure",
        "is-string",
        "is-symbol",
        "is-float",
        "is-number",
        "is-list",
        "eq",
        "string-append",
        "string-length",
        "string-substring",
        "string-index-of",
        "string-contains",
        "string-starts-with",
        "string-ends-with",
        "string-to-upper",
        "string-to-lower",
        "string-to-symbol",
        "symbol-to-string",
        "assert-eq",
    ];
    let retired = kerf_driver::builtins::REMOVED_BUILTIN_NAMES;
    assert_eq!(retired.len(), 27, "driver retired table should be 27 item");
    assert_eq!(
        tested.len(),
        27,
        "retired group static state list should be 27 item"
    );
    for &(old, modern) in retired {
        assert!(
            tested.contains(&modern),
            "retired old name missing negative case case(retired does not have reject): {} → {}",
            old,
            modern
        );
        // Verified by real runs: the old name through the full
        // production pipeline → E0021 (compile-time rejection).
        // Charset gate: `?`/`->` spellings are lexically unwritable on
        // the target face (E0001) — the run leg covers the hyphen-only
        // subset via the snake spelling (the `-` ↔ `_` mapping reaches
        // the same retired symbol).
        let old_target = old.replace('-', "_");
        let lexable = old_target
            .chars()
            .all(|c| c.is_ascii_alphanumeric() || c == '_');
        if lexable {
            let err = run_source(&format!("{}(quote(x))", old_target), "removed-guard.ktf")
                .expect_err("old name should compile-time rejected");
            assert!(
                err.rendered.contains("[E0021]"),
                "old name {} should E0021: {}",
                old,
                err.rendered
            );
        }
        // The modern name resolves on the normal path (evaluation
        // success or a domain/arity error both prove the name is
        // registered — "unbound" is the failure state; r47-tightened
        // names [nth/drop/string domain] carry the import declaration)
        let import_line = match modern {
            "nth" | "drop" => "import kerf_list;\n",
            "string-append" | "string-contains" | "string-ends-with" | "string-index-of"
            | "string-length" | "string-starts-with" | "string-substring" | "string-to-lower"
            | "string-to-symbol" | "string-to-upper" | "symbol-to-string" => {
                "import kerf_string;\n"
            }
            _ => "",
        };
        // the target face writes kebab names in snake spelling
        let modern_target = modern.replace('-', "_");
        let out = common::run_rendered(&format!("{}{}(quote(x))", import_line, modern_target));
        assert!(
            !out.contains("unbound"),
            "modern name via complete pipeline cannot parse(modern name not registration): {} → {}",
            modern,
            out
        );
    }
    for name in tested {
        assert!(
            retired.iter().any(|&(_, m)| m == *name),
            "negative case case no retired table for should (reject does not have retired): {}",
            name
        );
    }
}

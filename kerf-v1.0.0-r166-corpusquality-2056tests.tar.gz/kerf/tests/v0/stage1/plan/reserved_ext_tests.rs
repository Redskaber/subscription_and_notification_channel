//! Interface-reserved extension-layer integration tests (r12 batch /
//! worklog Task 31-d).
//!
//! **Design anchors**: lang-design 13-capability-matrix §3.3-§3.5 (v6.1 —
//! absorbed from the next4.md round-8 "2026 interface-reservation
//! completeness review") + the §3.3 test-anchor note.
//!
//! **Verification surface** (cross-crate assertions on P0 data-structure
//! placement + external reachability of the reserved APIs):
//! 1. P0 LSP precondition: every node carries a traceable Span
//!    (CoreExpr::span()) + bindings expose queryable scopes
//!    (NodeMetadata.scopes);
//! 2. P0 debug precondition: stable variable IDs (ir::NodeId) + IR→source
//!    lookup (NodeMetadata.span) + function boundary identifiers
//!    (BcProto/debug_spans) + the VM debug frame slot (ext3);
//! 3. P0 incremental-query precondition: a unified content-addressing
//!    convention (QueryDescriptor ↔ CacheKey);
//! 4. the 14 reserved-layer APIs are reachable from outside the driver
//!    (paths + shape behavior);
//! 5. FFI self-hosting compliance: the reserved shapes never touch the
//!    self-hosting chain (no Reader/Expander dependency — approximated
//!    here by the path assertion that "FFI types exist only in the
//!    reserved module").

use std::rc::Rc;

use kerf_compiler::BcProgram;
use kerf_core::ir::NodeId;
use kerf_core::{CoreExpr, LiteralValue};
use kerf_driver::reserved::{
    AiAssistant, AnnotatedANF, CodegenBackend, CompileRequest, CompileStatus, CompileTarget,
    CompilerService, DebugInfoGenerator, DebugInfoRequest, DebugTraceable, ExtensionSpace,
    ExternalType, FfiBoundary, FfiCall, ForeignDomain, IncrementalAst, LanguageService, OptLevel,
    PackageManager, Position, QueryDescriptor, QueryResult, QuerySystem, RootSpace, TargetTriple,
    TextEdit, ToolchainDomain, TypeCheckResult, VarId,
};
// r69 / 134-a·D-4: core-side domain marker probe imports (same origin as
// the extension-side markers in kerf_space — reachable either via the
// kerf_driver re-export or by connecting directly to kerf_space; the
// direct connection here keeps the test's independent visibility anchor
// on the skeleton crate).
use kerf_space::{CoreBackendDomain, CoreSpace};
use kerf_span::Span;
use kerf_syntax::Symbol;
use kerf_vm::Value;

// ---------------------------------------------------------------------------
// P0 data-structure placement assertions (not reserved = later breaking refactor; 13 §3.3.2/§3.3.3)
// ---------------------------------------------------------------------------

#[test]
fn p0_lsp_position_every_core_node_carries_span() {
    // Precondition 1: every node must carry a traceable Span (the
    // foundation for LanguageService position queries)
    let lit = CoreExpr::Literal {
        value: LiteralValue::Int(1),
        span: Span::dummy(),
    };
    let vr = CoreExpr::Var {
        name: Symbol(0),
        scopes: kerf_syntax::ScopeSet::new(),
        span: Span::dummy(),
    };
    let app = CoreExpr::Apply {
        fn_expr: Rc::new(lit.clone()),
        args: vec![Rc::new(vr)],
        span: Span::dummy(),
    };
    for e in [&lit, &app] {
        assert_eq!(e.span(), Span::dummy());
    }
}

#[test]
fn p0_debug_position_stable_node_id_and_scoped_metadata() {
    // Precondition 2: stable variable IDs (ir::NodeId) + bindings with
    // queryable scopes (NodeMetadata.scopes: ScopeSet — shared by LSP
    // binding queries and debug lookups)
    let id: NodeId = 7;
    assert_eq!(id, 7);
    // NodeMetadata shape: span + scopes publicly reachable (the "must be
    // reserved" of 13 §3.3.2 precondition 2 was made real in r5-r8 — this
    // freezes its public shape)
    let md = kerf_core::NodeMetadata {
        span: Span::dummy(),
        scopes: kerf_syntax::ScopeSet::new(),
    };
    assert!(md.scopes.is_empty());
}

#[test]
fn p0_debug_position_bytecode_debug_surface() {
    // Precondition 3: unique function boundary identifiers (the
    // BcProgram::protos index) + the bytecode pc → Span reverse-lookup
    // table (debug_spans) + the VM debug frame slot (ext3)
    let program = BcProgram {
        protos: vec![],
        consts: vec![],
        entry: 0,
        global_refs: vec![],
        module_name: None,
    };
    assert!(program.protos.is_empty());
    // ext3 debug frame slot (kerf-vm): Stage 0 empty shape, position frozen
    let ext = kerf_vm::FrameExt::default();
    assert!(ext.ext3.is_none());
}

#[test]
fn p0_query_position_content_addressing_unified() {
    // Precondition 4: incremental queries and the compilation cache share
    // one content-addressing convention (data-plane/architecture-plane
    // dual-reservation consistency — 13 §3.3.5 and §3.1.4 use the same key
    // convention: u64 fingerprints)
    let qd = QueryDescriptor {
        name: "compile",
        input_fingerprint: 42,
    };
    let ck = kerf_driver::CacheKey {
        source_hash: 42,
        config_fingerprint: 1,
    };
    assert_eq!(qd.input_fingerprint, ck.source_hash);
}

// ---------------------------------------------------------------------------
// Reserved-layer external reachability + shape behavior (cross-crate consumer surface)
// ---------------------------------------------------------------------------

#[test]
fn reserved_layer_api_reachable_from_outside() {
    // The 14 reserved APIs are reachable from outside the driver via the
    // reserved:: path (pub module surface)
    let et = ExternalType::CInt(kerf_driver::reserved::CIntSize::I64);
    assert_eq!(et, ExternalType::CInt(kerf_driver::reserved::CIntSize::I64));
    let call = FfiCall::AllocExternal { size: 16 };
    assert_eq!(call, FfiCall::AllocExternal { size: 16 });
    let triple = TargetTriple("wasm32-wasip2".into());
    assert_eq!(triple.0, "wasm32-wasip2");
    let ir = AnnotatedANF::default();
    assert_eq!(ir.fingerprint, 0);
}

#[test]
fn language_service_shape_returns_option_and_vec() {
    // LSP query shape: the unimplemented layer returns None/empty (P0
    // shape — the Stage 2 implementation side fills it in following the
    // rust-analyzer pattern)
    struct Noop;
    impl RootSpace for Noop {}
    impl ExtensionSpace for Noop {}
    impl ToolchainDomain for Noop {}
    impl LanguageService for Noop {
        fn syntax_tree_at(
            &self,
            _file: u32,
            _pos: Position,
        ) -> Option<kerf_driver::reserved::SyntaxNodeRef> {
            None
        }
        fn completion_items(
            &self,
            _file: u32,
            _pos: Position,
        ) -> Vec<kerf_driver::reserved::CompletionItem> {
            vec![]
        }
        fn document_symbols(&self, _file: u32) -> Vec<Symbol> {
            vec![Symbol(1)]
        }
        fn definition_of(
            &self,
            _file: u32,
            _pos: Position,
        ) -> Option<kerf_driver::reserved::Location> {
            None
        }
        fn references_to(
            &self,
            _file: u32,
            _pos: Position,
        ) -> Vec<kerf_driver::reserved::Location> {
            vec![]
        }
        fn type_at(&self, _file: u32, _pos: Position) -> Option<kerf_driver::reserved::TypeInfo> {
            None
        }
        fn diagnostics(&self, _file: u32) -> Vec<kerf_span::Diagnostic> {
            vec![]
        }
        fn quick_fixes(
            &self,
            _file: u32,
            _pos: Position,
        ) -> Vec<kerf_driver::reserved::CodeAction> {
            vec![]
        }
        fn rename_symbol(
            &mut self,
            _file: u32,
            _pos: Position,
            _new_name: String,
        ) -> Result<kerf_driver::reserved::WorkspaceEdit, kerf_driver::reserved::RenameError>
        {
            Err(kerf_driver::reserved::RenameError {
                reason: "Stage 2 implementation".into(),
            })
        }
    }
    let mut ls = Noop;
    assert!(ls
        .definition_of(0, Position { line: 1, column: 1 })
        .is_none());
    assert_eq!(ls.document_symbols(0), vec![Symbol(1)]);
    assert!(ls
        .rename_symbol(0, Position { line: 1, column: 1 }, "x".into())
        .is_err());
}

#[test]
fn incremental_ast_and_debug_shapes() {
    struct Ast {
        rev: u32,
    }
    impl RootSpace for Ast {}
    impl ExtensionSpace for Ast {}
    impl ToolchainDomain for Ast {}
    impl IncrementalAst for Ast {
        fn apply_edit(&mut self, _edit: &TextEdit) -> Result<(), kerf_driver::reserved::EditError> {
            self.rev += 1;
            Ok(())
        }
        fn invalidate_range(&mut self, _range: Span) {}
        fn reuse_unchanged(&self, _other: &Self) -> kerf_driver::reserved::ReusePlan {
            kerf_driver::reserved::ReusePlan::default()
        }
    }
    let mut ast = Ast { rev: 0 };
    ast.apply_edit(&TextEdit {
        file: 0,
        span: Span::dummy(),
        new_text: String::new(),
    })
    .unwrap();
    assert_eq!(ast.rev, 1);

    struct Dbg;
    impl RootSpace for Dbg {}
    impl ExtensionSpace for Dbg {}
    impl ToolchainDomain for Dbg {}
    impl DebugInfoGenerator for Dbg {
        fn source_location_of(&self, _ir_node: NodeId) -> Option<Span> {
            None
        }
        fn ir_node_at(&self, _code_addr: kerf_driver::reserved::Address) -> Option<NodeId> {
            None
        }
        fn variable_location(
            &self,
            _var: VarId,
            _at_pc: kerf_driver::reserved::Address,
        ) -> Option<kerf_driver::reserved::Location> {
            None
        }
        fn generate_dwarf(&self) -> kerf_driver::reserved::DwarfSections {
            kerf_driver::reserved::DwarfSections::default()
        }
        fn generate_source_map(&self) -> kerf_driver::reserved::SourceMapBlob {
            kerf_driver::reserved::SourceMapBlob::default()
        }
    }
    struct Node;
    impl RootSpace for Node {}
    impl ExtensionSpace for Node {}
    impl ToolchainDomain for Node {}
    impl DebugTraceable for Node {
        fn ast_node_id(&self) -> kerf_driver::reserved::AstNodeId {
            kerf_driver::reserved::AstNodeId(3)
        }
        fn debug_name(&self) -> Option<Symbol> {
            Some(Symbol(5))
        }
    }
    let dbg = Dbg;
    assert!(dbg.source_location_of(0).is_none());
    let n = Node;
    assert_eq!(n.ast_node_id(), kerf_driver::reserved::AstNodeId(3));
    assert_eq!(n.debug_name(), Some(Symbol(5)));
}

#[test]
fn query_system_shape_with_dependency_tracking() {
    struct Db {
        invalidated: Vec<u64>,
    }
    impl RootSpace for Db {}
    impl ExtensionSpace for Db {}
    impl ToolchainDomain for Db {}
    impl QuerySystem for Db {
        type Input = u64;
        fn query(&self, _descriptor: &QueryDescriptor) -> QueryResult {
            QueryResult {
                output_fingerprint: 0,
                cached: false,
            }
        }
        fn invalidate(&mut self, input: Self::Input) {
            self.invalidated.push(input);
        }
        fn dependencies_of(&self, _descriptor: &QueryDescriptor) -> Vec<QueryDescriptor> {
            vec![QueryDescriptor {
                name: "parse",
                input_fingerprint: 1,
            }]
        }
    }
    let mut db = Db {
        invalidated: vec![],
    };
    db.invalidate(9);
    assert_eq!(db.invalidated, vec![9]);
    let deps = db.dependencies_of(&QueryDescriptor {
        name: "expand",
        input_fingerprint: 1,
    });
    assert_eq!(deps.len(), 1);
    assert_eq!(deps[0].name, "parse");
}

#[test]
fn compiler_service_shape_lifecycle() {
    struct Svc {
        cancelled: Vec<kerf_driver::reserved::CompileJobId>,
    }
    impl RootSpace for Svc {}
    impl ExtensionSpace for Svc {}
    impl ToolchainDomain for Svc {}
    impl CompilerService for Svc {
        fn submit(&mut self, _request: CompileRequest) -> kerf_driver::reserved::CompileJobId {
            kerf_driver::reserved::CompileJobId(1)
        }
        fn status(&self, _job: kerf_driver::reserved::CompileJobId) -> Option<CompileStatus> {
            Some(CompileStatus::Running)
        }
        fn result(
            &self,
            _job: kerf_driver::reserved::CompileJobId,
        ) -> Option<kerf_driver::reserved::CompileResult> {
            None
        }
        fn diagnostics_stream(
            &self,
            _job: kerf_driver::reserved::CompileJobId,
        ) -> Vec<kerf_span::Diagnostic> {
            vec![]
        }
        fn cancel(&mut self, job: kerf_driver::reserved::CompileJobId) {
            self.cancelled.push(job);
        }
    }
    let mut svc = Svc { cancelled: vec![] };
    let job = svc.submit(CompileRequest {
        source: "(print 1)".into(),
        target: CompileTarget::Bytecode,
        opt_level: OptLevel::Default,
        debug_info: DebugInfoRequest::Spans,
    });
    assert_eq!(job, kerf_driver::reserved::CompileJobId(1));
    assert_eq!(svc.status(job), Some(CompileStatus::Running));
    assert!(svc.result(job).is_none());
    svc.cancel(job);
    assert_eq!(svc.cancelled, vec![job]);
}

#[test]
fn package_and_ai_shapes() {
    struct Pm;
    impl RootSpace for Pm {}
    impl ExtensionSpace for Pm {}
    impl ToolchainDomain for Pm {}
    impl PackageManager for Pm {
        fn resolve_dependencies(
            &self,
            manifest: &kerf_driver::reserved::PackageManifest,
        ) -> Result<kerf_driver::reserved::DependencyGraph, kerf_driver::reserved::ResolveError>
        {
            Ok(kerf_driver::reserved::DependencyGraph {
                packages: vec![manifest.name.clone()],
            })
        }
        fn get_package(
            &self,
            name: &str,
            version: &str,
        ) -> Result<kerf_driver::reserved::PackageArtifact, kerf_driver::reserved::FetchError>
        {
            Ok(kerf_driver::reserved::PackageArtifact {
                name: name.into(),
                version: version.into(),
                precompiled: true,
            })
        }
        fn lock(
            &self,
            _graph: &kerf_driver::reserved::DependencyGraph,
        ) -> kerf_driver::reserved::LockFile {
            kerf_driver::reserved::LockFile {
                content: String::new(),
            }
        }
    }
    let pm = Pm;
    let graph = pm
        .resolve_dependencies(&kerf_driver::reserved::PackageManifest {
            name: "kerf".into(),
            version: "0.1.0".into(),
            dependencies: vec![],
        })
        .unwrap();
    assert_eq!(graph.packages, vec!["kerf".to_string()]);

    struct Ai;
    impl RootSpace for Ai {}
    impl ExtensionSpace for Ai {}
    impl ToolchainDomain for Ai {}
    impl AiAssistant for Ai {
        fn semantic_summary(&self, _file: u32) -> kerf_driver::reserved::SemanticSummary {
            kerf_driver::reserved::SemanticSummary {
                summary: String::new(),
            }
        }
        fn function_signature(&self, _symbol: &Symbol) -> kerf_driver::reserved::FunctionSignature {
            kerf_driver::reserved::FunctionSignature {
                signature: String::new(),
            }
        }
        fn quick_typecheck(
            &self,
            snippet: &str,
        ) -> Result<TypeCheckResult, kerf_driver::reserved::TypeError> {
            if snippet.is_empty() {
                Err(kerf_driver::reserved::TypeError {
                    reason: "empty".into(),
                })
            } else {
                Ok(TypeCheckResult {
                    passed: true,
                    notes: vec![],
                })
            }
        }
        fn refactoring_suggestions(
            &self,
            _selection: &Span,
        ) -> Vec<kerf_driver::reserved::Refactoring> {
            vec![]
        }
        fn generate_doc_comment(&self, _item: &Symbol) -> String {
            String::new()
        }
    }
    let ai = Ai;
    // Negative shape: an empty snippet fails type checking (the error
    // surface can carry it)
    assert!(ai.quick_typecheck("").is_err());
    assert!(ai.quick_typecheck("(print 1)").unwrap().passed);
}

#[test]
fn codegen_backend_shape_target_neutral() {
    struct B;
    // r66/123-a: probe chain completed after CodegenBackend hangs off
    // CoreBackendDomain (the implementation body of the core-side contract
    // is explicit across the whole chain — 24 §5.1 dual-side edition)
    impl RootSpace for B {}
    impl CoreSpace for B {}
    impl CoreBackendDomain for B {}
    impl CodegenBackend for B {
        fn supported_targets(&self) -> Vec<TargetTriple> {
            vec![
                TargetTriple("bytecode-vm".into()),
                TargetTriple("wasm32-wasip2".into()),
            ]
        }
        fn compile(
            &self,
            _ir: &AnnotatedANF,
            target: &TargetTriple,
        ) -> Result<kerf_driver::reserved::CompiledModule, kerf_driver::reserved::CodegenError>
        {
            if target.0 == "bytecode-vm" {
                Ok(kerf_driver::reserved::CompiledModule {
                    target: target.clone(),
                    bytes: vec![],
                })
            } else {
                Err(kerf_driver::reserved::CodegenError {
                    reason: "Stage 2+ backend not implementation(P1 reserved)".into(),
                })
            }
        }
        fn backend_optimizations(&self) -> Vec<kerf_driver::reserved::PassDescriptor> {
            vec![]
        }
    }
    let b = B;
    assert_eq!(b.supported_targets().len(), 2);
    // Positive: the bytecode target (Stage 0's only execution backend)
    assert!(b
        .compile(
            &AnnotatedANF::default(),
            &TargetTriple("bytecode-vm".into())
        )
        .is_ok());
    // Negative: unimplemented targets are rejected (the error surface
    // carries the P1 reserved semantics)
    assert!(b
        .compile(
            &AnnotatedANF::default(),
            &TargetTriple("wasm32-wasip2".into())
        )
        .is_err());
}

#[test]
fn ffi_boundary_shape_gc_isolation() {
    struct Boundary {
        pinned: u32,
    }
    impl RootSpace for Boundary {}
    impl ExtensionSpace for Boundary {}
    impl ForeignDomain for Boundary {}
    impl FfiBoundary for Boundary {
        type ExternalPointer = *const u8;
        fn pin_object(&mut self, _obj: Value) {
            self.pinned += 1;
        }
        fn unpin_object(&mut self, _obj: Value) {
            self.pinned = self.pinned.saturating_sub(1);
        }
    }
    let mut b = Boundary { pinned: 0 };
    b.pin_object(Value::Nil);
    b.pin_object(Value::Bool(true));
    assert_eq!(b.pinned, 2);
    b.unpin_object(Value::Nil);
    assert_eq!(b.pinned, 1);
    // pin/unpin symmetric (the GC isolation protocol, both directions)
}

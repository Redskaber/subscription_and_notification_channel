// E6 close-out (r154 / 224-c2): corpus converted to the target-syntax face.
//! E1 self-hosting Expander parity suite (Stage 1 batch E / Task 33-a +
//! 34-a).
//!
//! Acceptance gate (plan §5 batch E, "E1 Expander rewritten in kerf",
//! α + β phases):
//! - **Structural parity**: the self-hosting Expander (expander.ktf,
//!   running on the VM) vs the seed Expander (kerf-expander/*.rs, Rust)
//!   over the positive corpus — CoreExpr trees (primitive shapes +
//!   Span(start,end) + scope sets + param_scopes) recursively identical
//!   (symbols by name — the two implementations intern independently and
//!   intern order is not guaranteed consistent, so names are the only
//!   stable criterion; expansion_id is excluded from the criterion — E1
//!   boundary, same rule as r6 Reader parity);
//! - **Error parity**: negative corpus — message + Span(start,end)
//!   verbatim identical;
//! - **E1-β macro closeout** (Task 34-a): define-syntax/syntax-rules/
//!   hygiene α renaming/ellipsis (zero/many segments/compound)/literals/
//!   multi-clause/sugar override/depth limit — all verbatim mirrors of
//!   the seed (15 macro parity corpus groups + 6 negative groups);
//! - **Behavior face**: the self-hosting expansion output goes through
//!   compile + VM execution and matches the run_source (production
//!   full pipeline) result — the end-to-end proof that expansion output
//!   is executable CoreExpr.
//!
//! Clauses followed: §9.4.3 (paired positive/negative cases), §7.1 (≥3
//! integration verifications), §2.3-11 (measure first, do not guess —
//! all assertions compare real runs of both implementations).
//!
//! E6 conversion notes (E6-CG §2, s-expr-removal-plan §4, calibrated by
//! running): both parity legs read the SAME target syntax through the
//! target Reader bridge (read_source_for_bootstrap) — the corpus
//! converts once and both sides stay consistent; the skin rewrites
//! follow the dictionary (fn declaration / block-threaded let / the
//! if-else chain / `&&`/`||` → and/or / `macro` arms → define-syntax/
//! syntax-rules with the Reader-injected name head). The sugar surface
//! whose sole entry was the S-expr skin (letrec / while / when /
//! unless / let* / cond) is unreachable from the target Reader — those
//! legs were rewritten to their derivation targets or target-semantics
//! equivalents (when→if, let*→let chain, letrec→top-level fns,
//! while→recursion); the unreachable families were deleted and recorded
//! in the r154 worklog (the function-body head-define hoisting window —
//! block threading do-wraps every in-body define; the sugar-shape and
//! syntax-rules-internal negatives — Read-stage enforced by the target
//! grammar; the non-list pattern clause; the quoted-pair-list datum
//! legs — the vector-datum family is the reachable face, r127 honest
//! boundary; the vector macro pattern; the zero/single-operand boolean
//! sugar legs).

use kerf_compiler::compile_module;
use kerf_core::{CoreExpr, LiteralValue};
use kerf_driver::bootstrap::expander::expand_program;
use kerf_driver::bootstrap::reader::read_source_for_bootstrap as bootstrap_read;
use kerf_driver::builtins::register_globals;
use kerf_driver::builtins::resolve_hygiene_fallbacks;
use kerf_driver::capability::IoGrant;
use kerf_driver::run_source;
use kerf_expander::{expand_program as seed_expand, ExpandCtxt, ExpandError};
use kerf_runtime::Heap;
use kerf_syntax::{ScopeSet, Symbol, SymbolTable};
use kerf_vm::run_program;

// ---- parity walk-through ----

/// CoreExpr tree equivalence (primitive shapes + Span(start,end) + scope
/// sets + structural recursion; symbols by name — the two tables intern
/// independently, names are the only stable criterion; expansion_id is
/// excluded from the criterion — E1-α boundary (the self-hosting side's
/// sugar output is always 0, the seed side's increments per generation).
fn core_equiv(
    a: &CoreExpr,
    ta: &SymbolTable,
    b: &CoreExpr,
    tb: &SymbolTable,
) -> Result<(), String> {
    if a.span().start != b.span().start || a.span().end != b.span().end {
        return Err(format!(
            "Span mismatch: ({},{}) vs ({},{})",
            a.span().start,
            a.span().end,
            b.span().start,
            b.span().end
        ));
    }
    match (a, b) {
        (CoreExpr::Literal { value: x, .. }, CoreExpr::Literal { value: y, .. }) => {
            if x != y {
                Err(format!("literal mismatch: {:?} vs {:?}", x, y))
            } else {
                Ok(())
            }
        }
        (
            CoreExpr::Var {
                name: x,
                scopes: sx,
                ..
            },
            CoreExpr::Var {
                name: y,
                scopes: sy,
                ..
            },
        ) => {
            if ta.name(*x) != tb.name(*y) {
                return Err(format!(
                    "var name mismatch: {} vs {}",
                    ta.name(*x),
                    tb.name(*y)
                ));
            }
            if sx != sy {
                return Err(format!(
                    "var `{}` scope set mismatch: {:?} vs {:?}",
                    ta.name(*x),
                    sx.iter().collect::<Vec<_>>(),
                    sy.iter().collect::<Vec<_>>()
                ));
            }
            Ok(())
        }
        (
            CoreExpr::Fn {
                params: px,
                param_scopes: sx,
                body: bx,
                ..
            },
            CoreExpr::Fn {
                params: py,
                param_scopes: sy,
                body: by,
                ..
            },
        ) => {
            if px.len() != py.len() {
                return Err(format!(
                    "formal parameter count mismatch: {} vs {}",
                    px.len(),
                    py.len()
                ));
            }
            for (i, (x, y)) in px.iter().zip(py.iter()).enumerate() {
                if ta.name(*x) != tb.name(*y) {
                    return Err(format!(
                        "formal parameter name mismatch[{}]: {} vs {}",
                        i,
                        ta.name(*x),
                        tb.name(*y)
                    ));
                }
            }
            if sx != sy {
                return Err(format!(
                    "param_scopes mismatch: {:?} vs {:?}",
                    scope_debug(sx),
                    scope_debug(sy)
                ));
            }
            core_equiv(bx, ta, by, tb).map_err(|e| format!("[body]: {}", e))
        }
        (
            CoreExpr::Apply {
                fn_expr: fx,
                args: ax,
                ..
            },
            CoreExpr::Apply {
                fn_expr: fy,
                args: ay,
                ..
            },
        ) => {
            core_equiv(fx, ta, fy, tb).map_err(|e| format!("[fn]: {}", e))?;
            if ax.len() != ay.len() {
                return Err(format!(
                    "actual argument count mismatch: {} vs {}",
                    ax.len(),
                    ay.len()
                ));
            }
            for (i, (x, y)) in ax.iter().zip(ay.iter()).enumerate() {
                core_equiv(x, ta, y, tb).map_err(|e| format!("[arg{}]: {}", i, e))?;
            }
            Ok(())
        }
        (
            CoreExpr::If {
                cond: cx,
                then_branch: tx,
                else_branch: ex,
                ..
            },
            CoreExpr::If {
                cond: cy,
                then_branch: ty,
                else_branch: ey,
                ..
            },
        ) => {
            core_equiv(cx, ta, cy, tb).map_err(|e| format!("[cond]: {}", e))?;
            core_equiv(tx, ta, ty, tb).map_err(|e| format!("[then]: {}", e))?;
            core_equiv(ex, ta, ey, tb).map_err(|e| format!("[else]: {}", e))
        }
        (
            CoreExpr::Assign {
                name: x,
                scopes: sx,
                value: vx,
                ..
            },
            CoreExpr::Assign {
                name: y,
                scopes: sy,
                value: vy,
                ..
            },
        ) => {
            if ta.name(*x) != tb.name(*y) {
                return Err(format!(
                    "assign name mismatch: {} vs {}",
                    ta.name(*x),
                    tb.name(*y)
                ));
            }
            if sx != sy {
                return Err(format!(
                    "assign `{}` scope set mismatch: {:?} vs {:?}",
                    ta.name(*x),
                    sx.iter().collect::<Vec<_>>(),
                    sy.iter().collect::<Vec<_>>()
                ));
            }
            core_equiv(vx, ta, vy, tb).map_err(|e| format!("[value]: {}", e))
        }
        // r49 D59: Define/Module/Require go to item_equiv (item-level
        // equivalence)
        (
            CoreExpr::Let {
                name: nx,
                value: vx,
                body: bx,
                ..
            },
            CoreExpr::Let {
                name: ny,
                value: vy,
                body: by,
                ..
            },
        ) => {
            if ta.name(*nx) != tb.name(*ny) {
                return Err(format!(
                    "let name mismatch: {} vs {}",
                    ta.name(*nx),
                    tb.name(*ny)
                ));
            }
            core_equiv(vx, ta, vy, tb)
                .map_err(|e| format!("[let value]: {}", e))
                .and_then(|_| core_equiv(bx, ta, by, tb))
                .map_err(|e| format!("[let body]: {}", e))
        }
        _ => Err(format!(
            "primitive form mismatch: {} vs {}",
            a.kind_name(),
            b.kind_name()
        )),
    }
}

// r49 D59: seq_equiv (CoreExpr sequence equivalence) retired along with
// the module-body itemization — item-level equivalence goes to
// item_seq_equiv

fn scope_debug(sets: &[ScopeSet]) -> Vec<Vec<u32>> {
    sets.iter().map(|s| s.iter().collect()).collect()
}

/// Positive-case parity assertion: dual read (separate tables) → dual
/// expand → verbatim structural comparison. E6 face: both reads go
/// through the target Reader bridge — the corpus is target syntax and
/// the seed/self-hosting expanders still consume the same Stx core
/// forms the Reader lowers to.
fn parity(src: &str) {
    let mut ta = SymbolTable::new();
    let mut tb = SymbolTable::new();
    let fa = bootstrap_read(src, 0, &mut ta).expect("oracle read failed");
    let fb = bootstrap_read(src, 0, &mut tb).expect("bootstrap read failed");
    let mut ctx = ExpandCtxt::new(ta);
    let oracle = seed_expand(&fa, &mut ctx).unwrap_or_else(|e| {
        panic!(
            "seed expansion failed(corpus should be positive case): {} @ {}",
            e.message, e.span.start
        )
    });
    let kerf = expand_program(&fb, 0, &mut tb).unwrap_or_else(|e| {
        panic!(
            "bootstrap expansion failed(corpus should be positive case): {} @ {}",
            e.message, e.span.start
        )
    });
    assert_eq!(
        oracle.len(),
        kerf.len(),
        "top-level item count mismatch (src: {:?})",
        src
    );
    for (i, (a, b)) in oracle.iter().zip(kerf.iter()).enumerate() {
        item_equiv(a, &ctx.table, b, &tb)
            .unwrap_or_else(|e| panic!("parity failed[{}](src: {:?}): {}", i, src, e));
    }
}

/// Item-level structural equivalence (r49 D59 — declaration-item
/// dispatch + expression-item recursion via core_equiv).
fn item_equiv(
    a: &kerf_core::ModuleItem,
    ta: &SymbolTable,
    b: &kerf_core::ModuleItem,
    tb: &SymbolTable,
) -> Result<(), String> {
    match (a, b) {
        (
            kerf_core::ModuleItem::Define {
                name: x, value: vx, ..
            },
            kerf_core::ModuleItem::Define {
                name: y, value: vy, ..
            },
        ) => {
            if ta.name(*x) != tb.name(*y) {
                return Err(format!(
                    "define name mismatch: {} vs {}",
                    ta.name(*x),
                    tb.name(*y)
                ));
            }
            core_equiv(vx, ta, vy, tb).map_err(|e| format!("[value]: {}", e))
        }
        (
            kerf_core::ModuleItem::Require { caps: x, .. },
            kerf_core::ModuleItem::Require { caps: y, .. },
        ) => {
            if x == y {
                Ok(())
            } else {
                Err(format!("require capability mismatch: {:?} vs {:?}", x, y))
            }
        }
        (
            kerf_core::ModuleItem::Module {
                name: nx,
                imports: ix,
                exports: ex,
                items: bx,
                ..
            },
            kerf_core::ModuleItem::Module {
                name: ny,
                imports: iy,
                exports: ey,
                items: by,
                ..
            },
        ) => {
            if ta.name(*nx) != tb.name(*ny) {
                return Err(format!(
                    "module name mismatch: {} vs {}",
                    ta.name(*nx),
                    tb.name(*ny)
                ));
            }
            for (dir, x, y) in [("import", ix, iy), ("export", ex, ey)] {
                if x.len() != y.len() {
                    return Err(format!("{} count mismatch", dir));
                }
                for (i, (a2, b2)) in x.iter().zip(y.iter()).enumerate() {
                    if ta.name(*a2) != tb.name(*b2) {
                        return Err(format!("{}[{}] mismatch", dir, i));
                    }
                }
            }
            item_seq_equiv(bx, ta, by, tb, "module-items")
        }
        (kerf_core::ModuleItem::Expr(x), kerf_core::ModuleItem::Expr(y)) => {
            core_equiv(x, ta, y, tb)
        }
        _ => Err(format!(
            "item form mismatch: {} vs {}",
            a.kind_name(),
            b.kind_name()
        )),
    }
}

/// Item-sequence equivalence (recursion over module body items).
fn item_seq_equiv(
    x: &[kerf_core::ModuleItem],
    ta: &SymbolTable,
    y: &[kerf_core::ModuleItem],
    tb: &SymbolTable,
    what: &str,
) -> Result<(), String> {
    if x.len() != y.len() {
        return Err(format!(
            "{} element count mismatch: {} vs {}",
            what,
            x.len(),
            y.len()
        ));
    }
    for (i, (a, b)) in x.iter().zip(y.iter()).enumerate() {
        item_equiv(a, ta, b, tb).map_err(|e| format!("[{}[{}]]: {}", what, i, e))?;
    }
    Ok(())
}

/// Negative-case parity assertion: both paths error, with message +
/// Span(start,end) verbatim identical. E6 face: the negative corpus is
/// restricted to Expand-stage shapes — the target Reader's grammar
/// fail-closes the former Read-passing structural misuses before the
/// expanders ever see them.
fn parity_err(src: &str) {
    let mut ta = SymbolTable::new();
    let mut tb = SymbolTable::new();
    let fa = bootstrap_read(src, 0, &mut ta).expect("oracle read failed");
    let fb = bootstrap_read(src, 0, &mut tb).expect("bootstrap read failed");
    let mut ctx = ExpandCtxt::new(ta);
    let ea: ExpandError = seed_expand(&fa, &mut ctx)
        .expect_err("seed should report an error(corpus should be a negative case)");
    let eb = expand_program(&fb, 0, &mut tb)
        .expect_err("bootstrap should report an error(corpus should be a negative case)");
    assert_eq!(
        ea.message, eb.message,
        "error message mismatch (src: {:?})",
        src
    );
    assert_eq!(
        (ea.span.start, ea.span.end),
        (eb.span.start, eb.span.end),
        "error Span mismatch (src: {:?}): {}",
        src,
        ea.message
    );
}

/// Behavior-face assertion: the self-hosting expansion output goes
/// through compile + VM execution and matches the run_source
/// (production full pipeline) result — the end-to-end proof that
/// expansion output is executable CoreExpr.
fn behavior(src: &str) {
    let expected = run_source(src, "behavior.ktf").expect("seed all pipeline failed");
    let mut t = SymbolTable::new();
    let forms = bootstrap_read(src, 0, &mut t).expect("read failed");
    let core = expand_program(&forms, 0, &mut t).expect("bootstrap expansion failed");
    let program = compile_module(&core).expect("bootstrap artifact compile failed");
    // The behavior corpus has no I/O (pure arithmetic/control flow) —
    // empty grant (R9 fail-closed)
    let mut globals = register_globals(&mut t, &IoGrant::none());
    // Hygiene-fallback resolution (mirrors the driver production
    // pipeline's run_source step — template builtin name `list$hyg$N` →
    // base-name global fallback; first touched by the r106 R7RS behavior
    // tests)
    resolve_hygiene_fallbacks(&program, &mut t, &mut globals);
    let mut heap = Heap::new();
    let actual = run_program(&program, &mut globals, &mut heap)
        .expect("bootstrap artifact execution failed");
    assert!(
        actual.eq_value(&expected.value),
        "behavior mismatch (src: {:?}): {:?} vs {:?}",
        src,
        kerf_vm::render_value(&actual, &heap),
        kerf_vm::render_value(&expected.value, &expected.heap)
    );
}

#[allow(dead_code)]
fn _unused(_: &Symbol, _: &LiteralValue) {}

// ---- Positive parity: core forms ----

#[test]
fn parity_literals() {
    // E6 skin: nil → the unit literal `()`
    for src in ["42", "3.5", "\"hi\"", "true", "false", "()"] {
        parity(src);
    }
}

#[test]
fn parity_symbol_ref_empty_scopes() {
    // Top-level free reference: scope set = ∅ (r13 semantic anchor — the
    // empty set = global fallback)
    parity("x");
    parity("x + 1");
}

#[test]
fn parity_lambda_nested_scopes() {
    // r13 fresh-scope injection parity: nested closure param_scopes and
    // the Var scope sets inside the body agree set for set (the target
    // closure `|| (p: T) { ... }` lowers to the same `(fn (p) ...)` Stx)
    parity("(|| (x: i64) { x + 1 })(41)");
    parity("|| (x: i64) { || (y: i64) { x + y } }");
    parity("|| (x: i64) { || (x: i64) { x } }");
}

#[test]
fn parity_if_setbang_define_begin() {
    // E6 skin: if → `if (c) { a } else { b }` (missing else → the nil
    // arm); assign → the `x = e;` statement; value define → the
    // `define(x, v);` call form; function define → the fn declaration;
    // begin → `do(...)` (empty do → `do()`)
    parity("if (x) { 1 } else { 2 }");
    parity("if (x) { 1 }");
    parity("x = 5;");
    parity("let x = 5;");
    parity("fn f(x: i64) -> i64 { x * x }");
    parity("do(1, 2, 3)");
    parity("do()");
}

#[test]
fn parity_quote() {
    // E6 skin (r127 honest boundary): the quoted pair-list datum has no
    // target-surface literal — the reachable datum-sequence family is
    // the vector literal `quote([..])` (D2-b recursive desugar); the
    // '(quote sym)' / 'sym twins of the S-expr face converge on the
    // single target surface `quote(sym)`
    parity("quote(sym)");
    parity("quote([1, 2, 3])");
    parity("quote([a, [b, c], 2.5])");
    parity("quote([])");
}

// ---- Positive parity: the nine sugars ----
// E6 face: only the sugars with a target-surface entry are reachable
// (`&&`/`||` → and/or; the if-else chain → the cond derivation target;
// block-threaded let → core let). The when/unless/let*/letrec/while
// entries were S-expr-skin-only — their legs below are rewritten to the
// derivation targets / target-semantics equivalents per the KEY MAP
// (when→if, let*→let chain, letrec→top-level fns, while→recursion).

#[test]
fn parity_sugar_let_family() {
    // Multi-binding let → the same multi-binding let Stx the block
    // statement threading produces (r110 D61 staging chain carrier)
    parity("(|| { let x = 1, y = 2; x + y })()");
    // letrec → top-level fns (the KEY MAP rewrite — the letrec sugar
    // itself has no target surface)
    parity("fn f() -> i64 { 1 } f()");
    // let* → sequential let chain (the KEY MAP rewrite)
    parity("(|| { let x = 1; let y = x + 1; x + y })()");
    // (let* () body) → the empty-binding degenerate (IIFE block body)
    parity("(|| { 7 })()");
}

#[test]
fn parity_sugar_cond_and_or() {
    // cond → the if-else chain (the derivation target, byte-identical
    // product); the test-only clause `(cond (test))` → `(if test test
    // nil)`; the multi-body clause → the do form
    parity("if (false) { 1 } else { if (true) { 2 } else { 3 } }");
    parity("if (1 == 2) { 1 == 2 } else { () }");
    parity("if (a) { do(1, 2, 3) } else { 4 }");
    // and/or → the `&&`/`||` operators (n-ary via left-associative
    // chaining — the Reader lowers each to the same (and ..)/(or ..)
    // Stx the sugar table derives)
    parity("a && b && c");
    parity("a || b");
    // (and)/(or a)/(and x) — zero/single-operand boolean sugar legs
    // deleted at E6: no target-surface entry (recorded in the r154
    // worklog, the 224-b4 expander_tests.rs precedent)
}

#[test]
fn parity_sugar_when_unless_while() {
    // when/unless → their derivation targets `(if c (do body…) nil)` /
    // `(if c nil (do body…))` — the products the retired sugars used to
    // derive, now written directly (the 224-b4 derivation-anchor
    // precedent)
    parity("if (c) { do(1, 2) } else { () }");
    parity("if (c) { () } else { 1 }");
    // while → recursion (the KEY MAP rewrite; the loop$hyg$1 uniquified
    // anchor retired together with the while sugar surface)
    parity("fn count(i: i64) -> i64 { if (i < 10) { count(i + 1) } else { i } } count(0)");
}

// ---- Positive parity: module/require ----
// E6 face: the function-body head-define hoisting window is unreachable
// from the target Reader (block threading do-wraps every in-body
// define → the position rejection) — parity_inner_define_hoisting was
// deleted and recorded in the r154 worklog (the 224-b4 precedent).

#[test]
fn parity_module_require() {
    parity("module m { import a; export f; let f = 1; f() }");
    parity("module m { let f = 1; }");
    parity("require io, read, write;");
    parity("require io, read;");
}

// ---- Negative parity (message + Span verbatim identical) ----
// E6 face: the shapes the target Reader's grammar fail-closes at Read
// stage (fn/if/let/assign/module/macro declaration misuse) never reach
// the expanders — the corpus below is the Expand-stage-reachable
// residue, calibrated by running.

#[test]
fn parity_err_core_forms() {
    // fn duplicate parameter names (declaration face + closure face —
    // both still Expand-stage on the target grammar)
    parity_err("fn f(x: i64, x: i64) { 1 }");
    parity_err("(|| (x: i64, x: i64) { x })");
    // define call-form family — r158 / 228-c: the item-position call
    // form (define()/define(1, 2)/define(x, 1, 2)) is Reader-rejected
    // now (the retirement diagnostic + the single-binding cap — the
    // ktf_toplevel_let_tests battery owns the reader-level coverage)
    // Mid-body define → the block-threading do wrap → the define
    // position rejection (the E6 face of the former "subsequent define
    // illegal" leg; the TD-014 duplicate-hoisting legs retired with the
    // hoisting window)
    parity_err("fn f(x: i64) { x + 1; define(y, 2); }");
}

#[test]
fn parity_vector_desugar() {
    // r138 / 208-c — TD-002: the former rejection anchors flipped to the
    // acceptance face — dual-side structural parity of the D2-a/D2-b
    // desugar products (expression position + quote position + nested +
    // empty), verbatim CoreExpr comparison. E6 skin: vector literals
    // are comma-separated `[a, b]`; kebab builtins write snake_case on
    // the target face (vector_length → the `vector-length` symbol via
    // the skin name mapping).
    parity("[1, 2]");
    parity("quote([1])");
    parity("[1, [2, 3]]");
    parity("quote([a, [b], 3])");
    parity("[]");
    parity("quote([])");
    parity("vector_length([1, 2, 3])");
    parity("vector_append([1], [2, 3])");
}

// parity_err_sugar deleted at E6 (11 legs, recorded in the r154
// worklog): the let/letrec/let*/cond/while/when/unless misuse shapes
// are Read-stage-enforced by the target grammar or have no
// target-surface shape at all — no Expand-stage sugar negative remains.

#[test]
fn parity_err_module_require_keyword() {
    // require validation (subject/capability items — Expand-stage on
    // both faces)
    parity_err("require net;");
    parity_err("require io, net;");
    parity_err("require io;");
    // bare syntax-rules (snake_case reaches the keyword face through
    // the skin name mapping) and the raw-form import position backstop
    // (the driver strips imports pre-expansion; fed raw, the expander
    // still rejects it — the parity twin of the S-expr leg)
    parity_err("syntax_rules()");
    parity_err("import a;");
    // (module)/(module 1 1)/(module m (import 1) 1)/(module m (export x
    // 2) 1)/(else 1) legs deleted at E6: all Read-stage on the target
    // grammar (recorded in the r154 worklog)
}

// ---- E1-β macro closeout parity: positive cases ----

#[test]
fn parity_define_syntax_yields_nil_and_registers() {
    // define-syntax itself → the nil literal (a Phase 1 form is a
    // runtime no-op). E6 skin: `macro m { (x) => x }` lowers to the same
    // (define-syntax m (syntax-rules () ((m x) x))) Stx with the
    // Reader-injected name head.
    parity("macro m { (x) => x }");
    // Called after registration: the pass-through macro reduces to the
    // expanded argument
    parity("macro m { (x) => x }\nm(42)");
    parity("macro m { (x) => x }\nm(1 + 2)");
}

#[test]
fn parity_macro_hygiene_renames_introduced() {
    // Template-introduced identifier tmp → tmp$hyg$N (α renaming;
    // keywords/pattern variables preserved). E6 skin: the swap
    // template is the block/let idiom (the do/assign chain of the
    // S-expr face parses to the same hygiene-relevant introduced
    // identifier set; the corpus face names freely — `swap` for the
    // S-expr `swap!`, the macros.ktf precedent).
    parity(
        r#"macro swap {
    (a, b) => {
        let tmp = a;
        a = b;
        b = tmp;
    }
}
(|| { let tmp = 1, x = 2; swap(tmp, x) })()"#,
    );
    // Multiple introduced identifiers in one template → the counter is
    // monotonic (tmp$hyg$1 / other$hyg$2) — the multi-binding let
    // template lowers to the same multi-binding let Stx
    parity(
        r#"macro m {
    (a) => {
        let tmp = a, other = 2;
        tmp + other
    }
}
m(5)"#,
    );
}

#[test]
fn parity_macro_ellipsis_zero_one_many() {
    // Ellipsis: zero/one/many segments (multi-clause + self-referential
    // recursive macro — the macro-name preserve set). The three-arm
    // my_or (the macros.ktf face of the S-expr my-or).
    let src = r#"macro my_or {
    () => false,
    (a, rest ...) => if a { true } else { my_or(rest ...) },
}"#;
    parity(&format!("{}\nmy_or()", src));
    parity(&format!("{}\nmy_or(1)", src));
    parity(&format!("{}\nmy_or(false, 1)", src));
    parity(&format!("{}\nmy_or(false, false, 2)", src));
}

#[test]
fn parity_macro_literals_and_multi_clause() {
    // Literal set: only the same-named symbol matches (clauses tried in
    // order) — the `macro NAME (lits) { ... }` literal-set form
    parity("macro f (to) { (x, to, y) => x + y, (x, y) => x - y } f(1, to, 2)");
    parity("macro f (to) { (x, to, y) => x + y, (x, y) => x - y } f(1, 2)");
    // Literal does not match → falls to the next clause
    // (pattern-variable binding). E6 note: the S-expr leg's literal was
    // `else` — a reserved keyword on the target face (KwElse), so the
    // literal is renamed to `other` (the mechanism is unchanged: exact
    // symbol matching in the pattern position).
    parity("macro g (other) { (x, other) => x, (x, y) => y } g(7, other)");
}

#[test]
fn parity_macro_nested_patterns() {
    // Nested list patterns (structural matching + pattern-variable
    // binding). E6 face: a quoted list datum argument is unreachable —
    // the nested sub-pattern destructures an application node
    // (`list(3, 4)` → the Stx `(list 3 4)`, the ktf_macros
    // second_of/list idiom); the `mk` head binder binds the application
    // symbol.
    parity("macro m { ((mk, a, b)) => a + b } m(list(3, 4))");
    // Doubly-nested sub-pattern over an application argument
    // (`not(true)` → the Stx `(not true)` — the inner 2-element list)
    parity("macro w { ((mk, a, (b, c))) => a + b * c } w(list(1, not(true)))");
    // (v [9]) — the vector macro-pattern leg deleted at E6: pattern
    // elements have no bracket form on the target grammar (recorded in
    // the r154 worklog)
    //
    // Literal datum patterns (numbers matched by value equality +
    // wildcard `_`)
    parity("macro n { (1, x) => x, (_, y) => y } n(1, 100)");
    parity("macro n { (1, x) => x, (_, y) => y } n(2, 100)");
}

#[test]
fn parity_macro_overrides_sugar() {
    // A user macro overriding a sugar name (the registry takes
    // precedence over lazy sugar registration — single-table replacement
    // semantics). `when`/`unless` are plain identifiers on the target
    // face (no keyword), so the override legs convert verbatim; the
    // templates lower to the same (if c t nil) / (if c nil t) Stx.
    parity("macro when { (c, t) => if (c) { t } else { () } } when(true, 1)");
    // Called after the override: goes through the user's rules output
    // (full-tree structural parity)
    parity("macro unless { (c, t) => if (c) { () } else { t } } unless(false, 2)");
}

#[test]
fn parity_macro_compound_ellipsis() {
    // Compound ellipsis — R7RS collection semantics (r106 / TD-005
    // in-window obligation fulfilled: clone-commit → canonical switch;
    // anchors updated in step with the additive change — the template's
    // ellipsis positions consume the collected sequences). E6 face: the
    // collected segments are application nodes (`list(1, 2)` → the Stx
    // `(list 1 2)`), so the sub-pattern carries the `mk` head binder —
    // the template `list(list(a, b) ...)` lowers to the same
    // (list (list a b) ...) Stx.
    let src = "macro pair_up { ((mk, a, b) ...) => list(list(a, b) ...) }";
    parity(&format!("{} pair_up()", src));
    parity(&format!("{} pair_up(list(1, 2))", src));
    parity(&format!("{} pair_up(list(1, 2), list(3, 4))", src));
    // Multi-element collection: a = (1 3 5), b = (2 4 6) → lockstep
    // iteration
    parity(&format!(
        "{} pair_up(list(1, 2), list(3, 4), list(5, 6))",
        src
    ));
}

#[test]
fn parity_macro_fixed_tail_ellipsis() {
    // Tail ellipsis + fixed tail `(a ... b)` (R7RS 4.3.2 — delivered by
    // r106 TD-005); the pattern `(x ..., y)` and the template
    // `list(x ..., y)` lower to the same (f x ... y) / (list x ... y)
    // Stx
    parity("macro f { (x ..., y) => list(x ..., y) } f(1)");
    parity("macro f { (x ..., y) => list(x ..., y) } f(1, 2, 3)");
    parity("macro f { (x ..., y) => list(x ..., y) } f(3)");
}

#[test]
fn parity_macro_template_escape() {
    // Expansion escape `(... template)` (R7RS 4.3.3 — delivered by r106
    // TD-005): the template yields a literal `...` symbol. E6 face: the
    // escape form is written `...(x(...))` — the outer `...` head call
    // applied to the inner application `x(...)`, lowering to the exact
    // (... (x ...)) two-element escape Stx (the `...` identifier flows
    // through the ordinary call-argument channels).
    parity("macro m { () => ...(a(...)) } m()");
    parity("macro m { (x) => ...(x(...)) } m(1)");
}

#[test]
fn behavior_r7rs_compound_ellipsis() {
    // Compound-ellipsis behavior face: collection semantics end to end
    // executable
    // pair_up(list(1, 2), list(3, 4)) → ((1 2) (3 4)); the length
    // assertion goes through the list chain
    behavior(
        "macro pair_up { ((mk, a, b) ...) => list(list(a, b) ...) } pair_up(list(1, 2), list(3, 4))",
    );
    // Fixed tail: f(1, 2, 3) → (list 1 2 3) → 3 items
    behavior("macro f { (x ..., y) => list(x ..., y) } f(1, 2, 3)");
    // Compound collection + arithmetic consumption: sum_pairs(list(1,
    // 2), list(3, 4)) → (+ (+ 1 2) (+ 3 4)) = 10 — the template
    // `a + b + ...` lowers to the same (+ (+ a b) ...) escape-free
    // ellipsis Stx
    behavior(
        "macro sum_pairs { ((mk, a, b) ...) => a + b + ... } sum_pairs(list(1, 2), list(3, 4))",
    );
    // Zero iterations: empty collection → empty expansion (the empty
    // list application evaluates to nil)
    behavior("macro pair_up { ((mk, a, b) ...) => list(list(a, b) ...) } pair_up()");
}

#[test]
fn parity_define_syntax_in_module_body() {
    // Registration inside a module body (phase visit = transformer
    // registration complete)
    parity("module m { macro f { (x) => x } f(1) }");
}

// ---- E1-β macro closeout parity: negative cases (message + Span verbatim identical) ----

#[test]
fn parity_err_define_syntax_shapes() {
    // E6 face of the former define-syntax-shape family: the macro arm
    // grammar IS the face, so the declaration shapes fail closed at
    // Read stage — the Expand-stage residue is template-carried
    // core-form rejections (the macro product re-enters expansion and
    // hits the keyword families), calibrated by running:
    parity_err("macro m { (x) => syntax_rules() } m(1)");
    parity_err("macro m { (x) => quote(x, y) } m(1)");
    parity_err("macro m { (x) => define(y, v, 2) } m(1)");
}

// parity_err_syntax_rules_parse deleted at E6 (6 legs, recorded in the
// r154 worklog): the syntax-rules-internal structure family (missing
// arguments / non-symbol literal / non-list literal set / non-list
// clause / non-pair clause / zero clauses) is Read-stage-enforced by
// the `macro NAME (lits)? { arms }` grammar — the Reader constructs
// only well-formed syntax-rules.
//
// parity_syntax_rules_non_list_pattern_clause_accepted deleted at E6
// (1 leg): a non-list pattern clause is a Read error on the target
// grammar (patterns are paren forms) — the parse-layer acceptance
// window has no target-surface shape.

#[test]
fn parity_err_macro_no_clause_match() {
    // No clause matches → the structured macro-expansion-failed error
    // (the call matches no clause pattern)
    parity_err("macro m { (x, y) => x } m(1)");
    parity_err("macro m { () => 1 } m(1)");
}

#[test]
fn parity_err_macro_depth_limit() {
    // Self-referential macro: infinite expansion → the depth-limit
    // structured error (not a stack overflow — §19.2 invariant 1)
    parity_err("macro loop2 { () => loop2() } loop2()");
}

#[test]
fn parity_err_macro_pattern_shape_mismatch() {
    // Structural mismatch (a list pattern against a non-list argument →
    // next clause → nothing matches)
    parity_err("macro m { ((a)) => a } m(1)");
}

// ---- Behavior face (self-hosting output executable end to end) ----

#[test]
fn behavior_arith_and_closures() {
    behavior("(|| (x: i64) { x + 1 })(41)");
    behavior("(|| { let x = 1, y = 2; x + y })()");
    // letrec → top-level fns (the KEY MAP rewrite)
    behavior("fn f() -> i64 { 1 } f()");
    // let* → sequential let chain (the KEY MAP rewrite)
    behavior("(|| { let x = 1; let y = x + 1; x + y })()");
}

#[test]
fn behavior_cond_while_fib() {
    // cond → the if-else chain
    behavior("if (false) { 1 } else { if (true) { 2 } else { 3 } }");
    // while → recursion (the KEY MAP rewrite: the counting loop as a
    // recursive fn — 10 iterations, the counter ends at 10)
    behavior("fn count(i: i64) -> i64 { if (i < 10) { count(i + 1) } else { i } } count(0)");
    behavior("fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } } fib(10)");
}

#[test]
fn behavior_inner_define_and_shadowing() {
    // The inner function define of the S-expr face → the let-bound
    // closure capturing x (the target-face idiom for inner functions;
    // the head-define hoisting window itself is unreachable — the
    // r154 worklog)
    behavior("fn f(x: i64) -> i64 { let g = || (y: i64) { x + y }; g(1) } f(5)");
    behavior("let x = 10; (|| (x: i64) { x })(20)");
}

#[test]
fn behavior_macro_swap_runtime() {
    // Macro output through compile + VM execution: swap swaps runtime
    // variables (the hygiene-introduced tmp does not interfere with the
    // user's tmp — the runtime proof of α renaming; the block/let
    // template idiom is the macros.ktf face of the S-expr do/assign
    // chain)
    behavior(
        r#"macro swap {
    (a, b) => {
        let tmp = a;
        a = b;
        b = tmp;
    }
}
let x = 1;
let y = 2;
do(swap(x, y), x - y)"#,
    );
}

#[test]
fn behavior_macro_recursive_or() {
    // Ellipsis + self-referential recursive macro: my_or evaluates
    // arguments with per-argument short-circuiting (truthy is strictly
    // bool — the condition position is bool-only, §19.5 pitfall 3
    // convention)
    let src = r#"macro my_or {
    () => false,
    (a, rest ...) => if (a) { a } else { my_or(rest ...) },
}"#;
    behavior(&format!("{}\nmy_or(false, false, true)", src));
    behavior(&format!("{}\nmy_or(false, false)", src));
    behavior(&format!("{}\nmy_or(false)", src));
}

#[test]
fn behavior_macro_hygiene_no_capture() {
    // Hygiene core: the macro-introduced tmp and the user's tmp are
    // mutually invisible (lexical bindings resolve separately)
    behavior(
        r#"macro inc_tmp {
    () => {
        let tmp = 1;
        tmp
    }
}
let tmp = 10;
tmp + inc_tmp()"#,
    );
}

#[test]
fn behavior_macro_depth_limit_structured_error() {
    // Self-referential macro: the structured depth error (not a VM frame
    // overflow — the error face returns via the bridge)
    let mut t = SymbolTable::new();
    let forms =
        bootstrap_read("macro loop2 { () => loop2() } loop2()", 0, &mut t).expect("read failed");
    let err = expand_program(&forms, 0, &mut t).expect_err("should report depth limit error");
    assert!(
        err.message
            .contains("macro expansion depth exceeds the limit 10000"),
        "actual error: {}",
        err.message
    );
}

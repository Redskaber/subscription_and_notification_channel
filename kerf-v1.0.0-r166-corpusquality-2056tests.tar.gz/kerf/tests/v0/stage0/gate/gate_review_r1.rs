// E6 close-out (r154 / 224-b4): converted to the target-syntax face.
//! Stage gate review tests (tests/v0/stage0/gate/gate_review_r1.rs ↔
//! docs/tests/v0/stage0/gate/gate-review-round1.md).
//!
//! **Executable audit** of the §22.3 first-milestone verification checklist
//! (each checklist item maps to at least one assertion):
//!
//! - [x] Reader parses the syntax of all 9 core primitives correctly
//! - [x] Expander expands all core forms correctly
//! - [x] Compiler generates bytecode correctly (including debug_info)
//! - [x] VM executes all opcodes correctly
//! - [x] GC collects unreferenced objects correctly
//! - [x] Span propagates correctly through all stages
//! - [x] Effect Handlers interface defined (implementation empty)
//! - [x] Multi-stage programming interface defined
//! - [x] Capability model I/O types defined
//! - [x] Compilation cache interface defined
//!
//! (50+ snapshot tests and performance baselines are covered in full by the
//! plan/ tree — see docs/tests/matrix.md.)

use crate::common;

use kerf_driver::{compile_source, run_source};
use kerf_vm::Value;

/// G1: Reader parses the syntax of the 9 core primitives (one read per
/// primitive — target-surface forms; the Reader lowers each to the same
/// core-form Stx).
#[test]
fn gate_g1_reader_parses_nine_primitives() {
    let forms = [
        "fn f(x: i64) { x }",
        "f(1, 2)",
        "if (a) { b } else { c }",
        "x",
        "42",
        "x = 1;",
        "let x = 1;",
        "do(1, 2)",
        "module m { let x = 1; x }",
    ];
    for src in forms {
        let mut t = kerf_syntax::SymbolTable::new();
        let forms = kerf_reader::read_source(src, 0, &mut t)
            .unwrap_or_else(|e| panic!("Reader parse failed [{}]: {}", src, e.message));
        assert!(!forms.is_empty(), "Reader empty artifact [{}]", src);
    }
}

/// G2: Expander expands the 9 core forms (no errors + semantic correctness
/// verified via G3-G4).
#[test]
fn gate_g2_expander_expands_all_core_forms() {
    let src = r#"
        let x = 1;
        x = 2;
        do(x, x);
        if (x == 2) { 10 } else { 20 }
        (|| (y: i64) { y + 1 })(5);
        module m { let z = 3; z }
    "#;
    let out = compile_source(src, "gate.ktf").unwrap();
    // r49 D59: module-level do-splice — `do(x, x)` in top-level position
    // flattens into two expression items (6 forms → 7 items; bytecode
    // identical — do chain [item; Pop]* ≡ item order)
    assert_eq!(out.core.len(), 7);
}

/// G3: Compiler generates bytecode + full debug_info coverage.
#[test]
fn gate_g3_compiler_debug_info_complete() {
    let out = compile_source("fn f(x: i64) -> i64 { x + 1 } f(2)", "gate.ktf").unwrap();
    assert!(out.program.proto_count() >= 2);
    for proto in &out.program.protos {
        assert_eq!(proto.code.len(), proto.debug_spans.len());
    }
    assert!(out.program.total_instructions() >= 8);
}

/// G4: VM executes every opcode group (at least one opcode per group
/// reached through a real program).
#[test]
fn gate_g4_vm_executes_opcode_groups() {
    // stack ops (DUP via assign) / variable access (local/captured/global)
    // / control flow (jump) / functions (closure/call/ret) / arithmetic /
    // data construction / predicates / termination
    // (The S-expr quoted-list datum converts to the runtime `list(...)`
    // construction — the r127 honest boundary: no quoted-list literal on
    // the target face; the assign inside the final list element converts
    // to the block-form IIFE — assign is a statement-position form.)
    let src = r#"
        fn make_adder(n: i64) { || (x: i64) { x + n } }
        let add5 = make_adder(5);
        let lst = list(1, 2, 3);
        let acc = 0;
        list(
          add5(10),
          if (is_nil(())) { 1 } else { 2 },
          is_pair(lst),
          eq(head(lst), 1),
          mod(7, 3),
          (|| { acc = 1; acc })()
        )
    "#;
    let o = run_source(src, "gate.ktf").unwrap();
    assert!(matches!(o.value, Value::Pair(_)));
}

/// G5: GC collects unreferenced objects (§21.3 acceptance — bounded heap).
#[test]
fn gate_g5_gc_collects_unreferenced() {
    let src = r#"
        fn spin(n: i64) -> i64 {
            if (n == 0) { 0 }
            else { do(cons(1, 2), cons(3, 4), cons(5, 6), cons(7, 8),
                     cons(9, 10), cons(11, 12), spin(n - 1)) }
        }
        spin(30000)
    "#;
    let o = run_source(src, "gate.ktf").unwrap();
    assert!(matches!(o.value, Value::Int(0)));
    assert!(o.heap.stats().collections > 0);
}

/// G6: Span propagation through the whole pipeline (§21.3 acceptance item 4).
#[test]
fn gate_g6_span_propagation() {
    let out = compile_source("let x = 1; x", "gate.ktf").unwrap();
    assert!(!out.core[0].span().is_empty());
    assert!(!out.ir.get_metadata(out.ir.roots()[0]).span.is_empty());
    for p in &out.program.protos {
        assert_eq!(p.code.len(), p.debug_spans.len());
    }
}

/// G7-G10: four reserved interfaces frozen (§21.3 acceptance item 6:
/// reserved interface freeze).
#[test]
fn gate_g7_to_g10_reserved_interfaces() {
    // G7 Effect Handlers (P3) — the trait name being nameable means frozen
    // (P2/P3 have no implementation bodies)
    fn effect_family_name() -> &'static str {
        "EffectFamily"
    }
    assert_eq!(effect_family_name(), "EffectFamily");
    // G8 multi-stage programming (P3) — CodeValue's compose_with reservation
    let expr = kerf_core::CoreExpr::Literal {
        value: kerf_core::LiteralValue::Int(1),
        span: Default::default(),
    };
    let cv = kerf_core::CodeValue::from_expr(&expr);
    assert!(matches!(
        cv.compose_with(&cv),
        Err(kerf_core::CompositionError::UnsupportedInStage0)
    ));
    // G9 capability model I/O (P2) — token types frozen
    fn cap_shape(_r: &kerf_driver::ReadCapability, _w: &kerf_driver::WriteCapability) {}
    let _ = cap_shape as fn(&kerf_driver::ReadCapability, &kerf_driver::WriteCapability);
    // G10 compilation cache (P2) — key and trait frozen
    let key = kerf_driver::CacheKey {
        source_hash: 1,
        config_fingerprint: 1,
    };
    assert_eq!(key, key.clone());
    fn cache_shape<C: kerf_driver::CompilationCache + ?Sized>() {}
    let _ = cache_shape::<dyn kerf_driver::CompilationCache> as fn();
}

/// P3 frozen-shape proof: effect families can be implemented (stable
/// signatures).
#[allow(dead_code)] // shape-proof type (used only in generic positions)
struct TestFamily;
// Root-space ownership declaration (r62/107-a — explicit declaration for
// the entity, principle 40).
impl kerf_driver::RootSpace for TestFamily {}
impl kerf_driver::ExtensionSpace for TestFamily {}
impl kerf_driver::EffectDomain for TestFamily {}
impl kerf_driver::EffectFamily for TestFamily {
    type Result = Value;
}

/// fib(25): semantic verification baseline (§20.1 Week 3 acceptance —
/// numeric correctness).
#[test]
fn gate_fib_25_semantics() {
    let src = "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } } fib(25)";
    common::assert_int(src, 75025);
}

//! Negative Reader tests (tests/v0/stage0/plan/negative_reader_tests.rs ↔
//! docs/tests/v0/stage0/plan/negative-tests.md).
//!
//! Directed expansion of the §9.4.3 negative-test-first principle: this
//! file covers the **Read stage (E0001)** error families in full — lexical
//! (string/number/illegal character/escape/comment) and grammatical
//! (delimiter three-state: unclosed/stray/mismatched).
//!
//! Each row = 1 case (table-driven). All expected messages/Spans are
//! calibrated against actual behavior (candidates that expected Err but
//! got Ok have been removed and recorded in the doc).
//!
//! Semantic boundaries (verified by measurement, not negative cases):
//! - `$` is a legal identifier start character (`$x` passes the Reader and
//!   reports unbound at the Run stage);
//! - `1.0e999` float literal overflowing to inf is **silently accepted**
//!   (contrast: integer overflow errors);
//! - strings may span lines (only unclosed ones error).
//!
//! Known boundary archive (verified by measurement):
//! - FS-1 fixed: MAX_NESTING_DEPTH 10_000 → 256 (stack safety margin >8×)
//!   — see `deep_nesting_guard_structured_error` (includes the 255-level
//!   boundary positive case).

use kerf_driver::{run_source, Stage};

/// Generic assertion: src fails at the given stage and the rendered error
/// contains the message substring (returns the error for deeper asserts).
fn expect_err(src: &str, stage: Stage, msg: &str) -> kerf_driver::DriverError {
    let err = match run_source(src, "neg.krf") {
        Ok(_) => panic!("expected an error, got Ok: {}", src),
        Err(e) => e,
    };
    assert_eq!(err.stage, stage, "stage mismatch:{}", src);
    assert!(
        err.rendered.contains(msg),
        "message missing `{}`: {}\n complete error: {}",
        msg,
        src,
        err.rendered
    );
    err
}

/// Assert the error Span points exactly (byte offset as primary key,
/// §19.1 pitfall 1).
fn expect_span(err: &kerf_driver::DriverError, src: &str, start: u32, end: u32) {
    assert_eq!(
        err.diagnostic.primary_span.start, start,
        "Span.start mismatch:{}(actual {})",
        src, start
    );
    assert_eq!(
        err.diagnostic.primary_span.end, end,
        "Span.end mismatch:{}(actual {})",
        src, end
    );
}

/// Read-stage negative cases (4 cases): unclosed strings (including EOF
/// mid-escape / EOF after a line break).
#[test]
fn unclosed_string_literals() {
    let cases: &[(&str, &str, u32, u32)] = &[
        ("\"abc", "unclosed string", 0, 4),
        ("\"abc\\", "unclosed string", 0, 5),
        ("\"abc\ndef", "unclosed string", 0, 8),
        ("(+ (quote \"abc) 1)", "unclosed string", 10, 18),
    ];
    for (src, msg, s, e) in cases {
        let err = expect_err(src, Stage::Read, msg);
        expect_span(&err, src, *s, *e);
    }
}

/// Illegal escape sequences (3 cases): unsupported escape characters.
#[test]
fn illegal_escape_sequences() {
    let cases: &[(&str, &str)] = &[
        ("\"a\\q1\"", "illegal escape character"),
        ("\"\\z\"", "illegal escape character"),
        ("\"a\\u12\"", "illegal escape character"),
    ];
    for (src, msg) in cases {
        expect_err(src, Stage::Read, msg);
    }
}

/// Greedy number rejections (§19.1 pitfall 4) (5 cases): identifier
/// characters immediately after a number / multi-dot floats.
#[test]
fn greedy_number_rejections() {
    let cases: &[(&str, &str)] = &[
        (
            "123abc",
            "digit '123' identifier characters immediately after 'a'",
        ),
        (
            "1.5x",
            "digit '1.5' identifier characters immediately after 'x'",
        ),
        (
            "12e5x",
            "digit '12e5' identifier characters immediately after 'x'",
        ),
        (
            "-4ab",
            "digit '-4' identifier characters immediately after 'a'",
        ),
        ("1.2.3", "illegal character '.'"),
    ];
    for (src, msg) in cases {
        let err = expect_err(src, Stage::Read, msg);
        assert!(
            err.rendered.contains("error[E0001]"),
            "should carry E0001: {}",
            src
        );
    }
}

/// Illegal characters (14 cases): characters outside the identifier/number/
/// delimiter character sets. Note `$` is legal (see the file header notes);
/// `#` is legal only at the start of a `#|` block comment.
#[test]
fn illegal_characters() {
    let cases: &[(&str, &str)] = &[
        ("@", "illegal character '@'"),
        ("(+ @ 1)", "illegal character '@'"),
        ("(+ ~ 1)", "illegal character '~'"),
        ("(+ # 1)", "illegal character '#'"),
        ("#", "illegal character '#'"),
        ("(+ 1, 2)", "illegal character ','"),
        ("(+ ^ 1)", "illegal character '^'"),
        ("` x", "illegal character '`'"),
        ("(+ § 1)", "illegal character '§'"),
        ("(+ ÷ 1)", "illegal character '÷'"),
        ("(+ © 1)", "illegal character '©'"),
        ("(+ ¿ 1)", "illegal character '¿'"),
        ("(+ £ 1)", "illegal character '£'"),
        ("(+ ± 1)", "illegal character '±'"),
    ];
    for (src, msg) in cases {
        expect_err(src, Stage::Read, msg);
    }
}

/// Quote shorthand `'` followed by EOF (3 cases): an expression was
/// expected but end-of-file was reached.
#[test]
fn quote_shorthand_at_eof() {
    let cases: &[(&str, u32)] = &[("'", 1), ("(+ 1 '", 6), ("(quote '", 8)];
    for (src, span_start) in cases {
        let err = expect_err(src, Stage::Read, "unexpected end of file");
        expect_span(&err, src, *span_start, *span_start);
    }
}

/// Stray closing delimiters (5 cases): closing side without a matching
/// opening side.
#[test]
fn stray_closing_delimiters() {
    let cases: &[(&str, &str, u32, u32)] = &[
        (")", "unexpected closing parenthesis:')'", 0, 1),
        ("]", "unexpected closing parenthesis:']'", 0, 1),
        ("(+ 1 2) )", "unexpected closing parenthesis:')'", 8, 9),
        ("[1 2] ]", "unexpected closing parenthesis:']'", 6, 7),
        ("(+ 1 2)\n)", "unexpected closing parenthesis:')'", 8, 9),
    ];
    for (src, msg, s, e) in cases {
        let err = expect_err(src, Stage::Read, msg);
        expect_span(&err, src, *s, *e);
    }
}

/// Unclosed delimiters (7 cases): the opening side is not closed before
/// EOF (Span points at the opening side).
#[test]
fn unclosed_delimiters() {
    let cases: &[(&str, &str, u32, u32)] = &[
        ("(+ 1 2", "unclosed parenthesis: missing ')'", 0, 1),
        ("[1 2", "unclosed parenthesis: missing ']'", 0, 1),
        ("[1 2 3", "unclosed parenthesis: missing ']'", 0, 1),
        ("(define x 1", "unclosed parenthesis: missing ')'", 0, 1),
        ("((((", "unclosed parenthesis: missing ')'", 3, 4),
        ("(let ((x 1)", "unclosed parenthesis: missing ')'", 5, 6),
        ("[\n", "unclosed parenthesis: missing ']'", 0, 1),
    ];
    for (src, msg, s, e) in cases {
        let err = expect_err(src, Stage::Read, msg);
        expect_span(&err, src, *s, *e);
    }
}

/// Mismatched delimiters (4 cases): crossing open/close types (( closed
/// by ], [ closed by )).
#[test]
fn mismatched_delimiters() {
    let cases: &[(&str, &str)] = &[
        (
            "(+ 1 2]",
            "mismatched parentheses:'(' should with ')' closed, got ']'",
        ),
        (
            "[1 2)",
            "mismatched parentheses:'[' should with ']' closed, got ')'",
        ),
        (
            "([)])",
            "mismatched parentheses:'[' should with ']' closed, got ')'",
        ),
        (
            "(+ [1 2)",
            "mismatched parentheses:'[' should with ']' closed, got ')'",
        ),
    ];
    for (src, msg) in cases {
        expect_err(src, Stage::Read, msg);
    }
}

/// Missing exponent digits (4 cases): a scientific-notation exponent must
/// be followed by digits.
#[test]
fn bad_exponent_literals() {
    let cases: &[(&str, &str)] = &[
        ("1e", "exponent missing digits"),
        ("1e+", "exponent missing digits"),
        ("1e-", "exponent missing digits"),
        ("2.5e", "exponent missing digits"),
    ];
    for (src, msg) in cases {
        expect_err(src, Stage::Read, msg);
    }
}

/// Integer literals beyond i64 (2 cases).
#[test]
fn integer_literal_overflow() {
    for src in ["99999999999999999999999", "-99999999999999999999999"] {
        expect_err(src, Stage::Read, "integer out of range");
    }
}

/// Unclosed block comments (3 cases, including nesting).
#[test]
fn unclosed_block_comments() {
    let cases: &[(&str, &str)] = &[
        ("#| abc", "block comment #|...|# unclosed"),
        ("#|x", "block comment #|...|# unclosed"),
        ("#| #| nested", "block comment #|...|# unclosed"),
    ];
    for (src, msg) in cases {
        expect_err(src, Stage::Read, msg);
    }
}

/// Full rendering-shape assertions (4 cases): error[E0001] + `-->`
/// position line + source excerpt line (§2.2 principle 16:
/// human-observable output is a first-class citizen).
#[test]
fn reader_error_rendering_shape() {
    // single line: the excerpt contains the `1 |` line-number column + a
    // caret ^ pointer
    let err = run_source("(+ # 1)", "neg.krf").unwrap_err();
    assert!(err.rendered.contains("error[E0001]: illegal character '#'"));
    assert!(err.rendered.contains("--> neg.krf:1:4"));
    assert!(err.rendered.contains("1 | (+ # 1)"));
    assert!(err.rendered.contains("^"));
    // two-line source: position line number increments with the error's line
    let err2 = run_source("(+ 1 2)\n)", "neg.krf").unwrap_err();
    assert!(
        err2.rendered.contains("--> neg.krf:2:1"),
        "actual: {}",
        err2.rendered
    );
    // unclosed after a comment: line number points at the second line
    let err3 = run_source("; comment\n(+ 1 2\n", "neg.krf").unwrap_err();
    assert!(
        err3.rendered.contains("--> neg.krf:2:1"),
        "actual: {}",
        err3.rendered
    );
    // the Display prefix carries the stage marker [read]
    let err4 = run_source("(+ 1", "neg.krf").unwrap_err();
    assert!(err4.to_string().starts_with("[read] error[E0001]"));
}

/// E0001 code structured assertion (1 case): DiagnosticCode(1)
/// (diagnostics are data, §8.7).
#[test]
fn reader_error_code_is_e0001() {
    let err = run_source("(+ # 1)", "neg.krf").unwrap_err();
    assert_eq!(
        err.diagnostic.code,
        Some(kerf_span::DiagnosticCode(1)),
        "Reader error must be numbered E0001"
    );
    assert_eq!(err.diagnostic.primary_span.file_id, 0);
    assert!(err.diagnostic.is_error());
}

/// FS-1 fixed (MAX_NESTING_DEPTH 10_000→256, leaving >8× stack margin):
/// ultra-deep nesting reports a structured error instead of a stack
/// overflow (the guard fires before the actual overflow).
#[test]
fn deep_nesting_guard_structured_error() {
    let src = format!("{}1{}", "(".repeat(10_001), ")".repeat(10_001));
    let mut t = kerf_syntax::SymbolTable::new();
    let err = kerf_reader::read_source(&src, 0, &mut t).unwrap_err();
    assert!(
        err.message.contains("nesting depth exceeds the limit 256"),
        "should report structured depth limit error: {}",
        err.message
    );
    // boundary positive case: 255 levels legal (no false blocking within the limit)
    let ok_src = format!("{}1{}", "(".repeat(255), ")".repeat(255));
    let mut t2 = kerf_syntax::SymbolTable::new();
    assert!(
        kerf_reader::read_source(&ok_src, 0, &mut t2).is_ok(),
        "255 layer nested should in limit inner"
    );
}

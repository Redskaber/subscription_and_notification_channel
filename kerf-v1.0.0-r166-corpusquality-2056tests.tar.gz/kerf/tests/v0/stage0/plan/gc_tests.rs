// E6 close-out (r154 / 224-b2): corpus converted to the target-syntax face.
//! GC integration tests (tests/v0/stage0/plan/gc_tests.rs ↔
//! docs/tests/v0/stage0/plan/gc.md).
//!
//! Coverage: mark-sweep collection (§21.3 Stage 0 acceptance) / heap
//! stability under 10^6 temporary objects / live-data protection /
//! foreign ref roots / observable statistics.
//! (Cycles and deep-chain stack-blowup protection are covered by
//! kerf-runtime unit tests — see the crate's inline tests.)

use crate::common;

use kerf_runtime::{mark_sweep_cycle, GcRef, Heap, RootSet};

/// Heap stays bounded when allocating on the order of 10^6 temporary
/// objects (§21.3 Stage 0 acceptance item — loop-discard allocations).
#[test]
fn million_temp_objects_heap_stays_bounded() {
    // 20 pair allocations per level (3 slots each) × 3×10^4 levels ≈
    // 1.8×10^6 temporary allocations (recursion depth 3×10^4 < frame cap
    // 10^5; depth decoupled from allocation volume)
    let src = r#"
        fn spin(n: i64) {
            if (n == 0) {
                0
            } else {
                cons(1, 2); cons(3, 4); cons(5, 6); cons(7, 8); cons(9, 10);
                cons(11, 12); cons(13, 14); cons(15, 16); cons(17, 18); cons(19, 20);
                cons(21, 22); cons(23, 24); cons(25, 26); cons(27, 28); cons(29, 30);
                cons(31, 32); cons(33, 34); cons(35, 36); cons(37, 38); cons(39, 40);
                spin(n - 1)
            }
        }
        spin(30000)
    "#;
    let outcome = common::run_with_heap(src).unwrap_or_else(|e| panic!("execution failed:{}", e));
    let stats = outcome.heap.stats();
    assert!(stats.collections > 0, "at least occur once GC");
    // Heap slots should be far below total allocations (≈1.5M slots →
    // bounded after collection)
    assert!(
        stats.slots < 200_000,
        "heap not kept bounded: slots = {}(collections = {})",
        stats.slots,
        stats.collections
    );
}

/// Live data is never collected by mistake (conservative policy: leaks
/// tolerated, mistaken collection zero-tolerance). (The quoted-list datum
/// becomes the runtime `list(...)` construction — the r127 honest
/// boundary: no quoted-list literal on the target face.)
#[test]
fn live_data_survives_collections() {
    let src = r#"
        let keep = list(1, 2, 3, 4, 5);
        fn spin(n: i64) {
            if (n == 0) { 0 } else { cons(9, 9); cons(9, 9); cons(9, 9); cons(9, 9); cons(9, 9); spin(n - 1) }
        }
        spin(50000);
        head(tail(tail(tail(tail(keep)))))
    "#;
    common::assert_int(src, 5);
}

/// Closure-captured data survives GC (root set completeness: frame capture
/// cells).
#[test]
fn closure_captured_data_survives_gc() {
    let src = r#"
        fn make_holder(v: T) { || { v } }
        let h = make_holder(list(7, 8));
        fn spin(n: i64) {
            if (n == 0) { 0 } else { cons(1, 1); cons(1, 1); cons(1, 1); cons(1, 1); cons(1, 1); spin(n - 1) }
        }
        spin(50000);
        head(h())
    "#;
    common::assert_int(src, 7);
}

/// Roots registered as foreign refs survive (§8.8 reserved interface).
#[test]
fn foreign_refs_survive_cycle() {
    let mut heap = Heap::new();
    let r = heap.alloc_int(42);
    let garbage = heap.alloc_pair(r, r); // create unreachable companion garbage
    let _ = garbage;
    heap.register_foreign_ref(r);
    let stats = mark_sweep_cycle(&mut heap, &RootSet::from_refs([]));
    assert_eq!(stats.live, 1, "foreign root alive, garbage collection");
    assert_eq!(stats.free, 1);
}

/// Reachable object chains survive; unreachable ones are collected.
#[test]
fn reachability_partition() {
    let mut heap = Heap::new();
    // chain: (1 . (2 . nil)) — 3 slots reachable from head
    let nil = heap.alloc_nil();
    let one = heap.alloc_int(1);
    let two = heap.alloc_int(2);
    let inner = heap.alloc_pair(two, nil);
    let head = heap.alloc_pair(one, inner);
    // orphan
    let orphan = heap.alloc_int(99);
    let _ = orphan;
    let stats = mark_sweep_cycle(&mut heap, &RootSet::from_refs([head]));
    assert_eq!(stats.live, 5, "chain 5 slot alive(head/inner/one/two/nil)");
    assert_eq!(stats.free, 1, "orphan collection");
}

/// GC statistics are observable (performance baseline data source).
#[test]
fn gc_stats_observable() {
    let src = "let keep = 1; cons(1, 2); cons(3, 4)";
    let outcome = common::run_with_heap(src).unwrap();
    let stats = outcome.heap.stats();
    assert!(stats.total_allocs >= 4);
    assert_eq!(stats.slots, stats.live + stats.free);
    let _ = GcRef(0); // handle is constructible (library-internal use only — public type shape)
}

/// TD-010 (r24): captured data of boxed closures (Foreign slots) survives
/// GC — the marking phase enumerates the closure capture graph via the
/// tracer (HeapObj::Foreign children). Once a closure is boxed into a pair,
/// its captured Pair is reachable only through the Foreign slot — a missing
/// tracer would cause mistaken collection (use-after-free-grade defect).
#[test]
fn boxed_closure_captures_survive_gc() {
    let src = r#"
        fn make_box() { let cell = cons(42, ()); || { head(cell) } }
        let holder = cons(make_box(), ());
        fn spin(n: i64) {
            if (n == 0) { 0 } else { cons(1, 1); cons(1, 1); cons(1, 1); cons(1, 1); cons(1, 1); spin(n - 1) }
        }
        spin(50000);
        head(holder)()
    "#;
    let outcome = common::run_with_heap(src).unwrap_or_else(|e| panic!("execution failed:{}", e));
    let stats = outcome.heap.stats();
    assert!(
        stats.collections > 0,
        "stress phase occur GC(tracing machine by actual line make)"
    );
}

/// TD-010 (r24): multi-level transitive reachability of boxed closure
/// capture chains — holder global pair root → Foreign slot → tracer →
/// captured Pair chain (cons 40 (cons 2 nil), extended via Pair children
/// during marking).
#[test]
fn boxed_closure_trace_transitive_pairs() {
    let src = r#"
        fn make_get() { let p = cons(40, cons(2, ())); || (x: i64) { x + head(p) } }
        let holder = list(make_get());
        fn spin(n: i64) {
            if (n == 0) { 0 } else { cons(2, 2); cons(2, 2); cons(2, 2); cons(2, 2); cons(2, 2); spin(n - 1) }
        }
        spin(50000);
        head(holder)(0)
    "#;
    common::assert_int(src, 40);
}

/// TD-023 (r24): **write-path soundness invariant** of the GcCell
/// heap-rootness summary — after assign writes a Pair into the captured
/// cell the flag must flip (otherwise that Pair is reachable only via the
/// closure capture chain, root scanning skips it by flag → mistaken
/// collection → dangling read). box starts as nil (flag false) → init
/// writes a Pair (flag true) → GC pressure → read back 42.
#[test]
fn gc_cell_flag_flips_on_pair_write() {
    let src = r#"
        fn make() {
            let box = ();
            || (cmd: T) { if (eq(cmd, quote(init))) { box = list(42); } else { head(box) } }
        }
        let f = make();
        f(quote(init));
        fn spin(n: i64) {
            if (n == 0) { 0 } else { cons(1, 2); cons(3, 4); spin(n - 1) }
        }
        spin(50000);
        f(quote(read))
    "#;
    common::assert_int(src, 42);
}

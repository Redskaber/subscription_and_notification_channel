// E6 close-out (r154 / 224-b4): converted to the target-syntax face.
//! Compiler integration tests (tests/v0/stage0/plan/compiler_tests.rs ↔
//! docs/tests/v0/stage0/plan/compiler.md).
//!
//! Coverage: jump backpatching with zero placeholder residue (§20.1 Week 3
//! acceptance) / constant pool deduplication / closure capture descriptors /
//! stack balance / full debug-info coverage / convergent (deterministic)
//! compilation.

use kerf_compiler::{compile_module, Op};
use kerf_core::CoreExpr;
use std::rc::Rc;

fn compile_via_driver(src: &str) -> kerf_driver::CompileOutput {
    kerf_driver::compile_source(src, "test.ktf").unwrap()
}

/// Jump backpatch completeness: all JUMP/JUMP_IF_FALSE targets are
/// non-placeholder (§19.3 invariant 2).
#[test]
fn backpatch_leaves_no_placeholders() {
    let out = compile_via_driver(
        "fn f(n: i64) -> i64 { if (n < 2) { n } else { f(n - 1) + f(n - 2) } } f(10)",
    );
    for proto in &out.program.protos {
        for (pc, op) in proto.code.iter().enumerate() {
            match op {
                Op::Jump(t) | Op::JumpIfFalse(t) => {
                    assert_ne!(*t, u32::MAX, "placeholder residual: proto pc {}", pc);
                    assert!(
                        (*t as usize) < proto.code.len(),
                        "backfill goal out of bounds"
                    );
                }
                _ => {}
            }
        }
    }
}

/// Constant pool deduplication (§19.3 pitfall: (do 1 1 1) does not bloat).
#[test]
fn const_pool_dedup() {
    let out = compile_via_driver("do(1, 1, 1, 1, 1)");
    let int_consts = out
        .program
        .consts
        .iter()
        .filter(|c| matches!(c, kerf_compiler::BcConst::Int(1)))
        .count();
    assert_eq!(int_consts, 1);
}

/// Debug info full coverage: every instruction has a (pc, Span) pair
/// (§19.3 invariant 3 + §22.3).
#[test]
fn debug_info_full_coverage() {
    let out = compile_via_driver("fn f(x: i64) -> i64 { x + 1 } f(41)");
    for (i, proto) in out.program.protos.iter().enumerate() {
        assert_eq!(
            proto.code.len(),
            proto.debug_spans.len(),
            "proto {} debug info incomplete",
            i
        );
    }
}

/// Closure capture descriptors: nested fn capture sources are correct.
#[test]
fn nested_closure_capture_descriptors() {
    // (fn (x) (fn (y) (x y))) — the inner one captures x
    let x = kerf_syntax::Symbol(1);
    let y = kerf_syntax::Symbol(2);
    let inner = Rc::new(CoreExpr::Fn {
        params: vec![y],
        param_scopes: vec![kerf_syntax::ScopeSet::new()],
        rest: None,
        body: Rc::new(CoreExpr::Apply {
            fn_expr: Rc::new(CoreExpr::Var {
                name: x,
                scopes: kerf_syntax::ScopeSet::new(),
                span: Default::default(),
            }),
            args: vec![Rc::new(CoreExpr::Var {
                name: y,
                scopes: kerf_syntax::ScopeSet::new(),
                span: Default::default(),
            })],
            span: Default::default(),
        }),
        span: Default::default(),
    });
    let outer = Rc::new(CoreExpr::Fn {
        params: vec![x],
        param_scopes: vec![kerf_syntax::ScopeSet::new()],
        rest: None,
        body: inner,
        span: Default::default(),
    });
    // r49 D59: item-level entry — expression item wrapping
    let program = compile_module(&[kerf_core::ModuleItem::Expr(outer)]).unwrap();
    assert_eq!(program.protos.len(), 3);
    assert_eq!(program.protos[2].capture_names, vec![x]);
}

/// Evaluation order contract: Apply arguments left-to-right, callee last
/// (§19.3/§19.5 invariant 3).
#[test]
fn app_evaluation_order() {
    // r46 / D49: after E0022, names in source must be defined first (the
    // original bare (f a b) with three unbound names — rejected at compile
    // time); instruction-order assertions unchanged (fn loaded first +
    // arguments left-to-right)
    let out = compile_via_driver("let a = 1; let b = 2; let f = 3; f(a, b)");
    let main = out.program.entry_proto();
    // After the define preamble ×3: LOAD_GLOBAL × 3 (f, a, b — callee
    // loaded first), then CALL 2 + HALT (call segment = last five
    // instructions; define segment precedes [PushConst/Dup/DefineGlobal/Pop
    // ×3])
    let n = main.code.len();
    assert!(n >= 5, "at least containing call segment");
    assert!(matches!(main.code[n - 5], Op::LoadGlobal(_)));
    assert!(matches!(main.code[n - 4], Op::LoadGlobal(_)));
    assert!(matches!(main.code[n - 3], Op::LoadGlobal(_)));
    assert_eq!(main.code[n - 2], Op::Call(2));
    assert!(matches!(main.code[n - 1], Op::Halt));
}

/// Convergent-result test (deterministic compilation — two compilations
/// produce identical bytecode, §21.3 Stage 0 acceptance item).
#[test]
fn deterministic_compilation_two_passes_identical() {
    let src = "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } } fib(12)";
    let a = compile_via_driver(src);
    let b = compile_via_driver(src);
    assert!(
        a.program.bytecode_equal(&b.program),
        "twice compile output must byte consistent(same result test)"
    );
}

/// The main proto terminates with HALT.
#[test]
fn main_proto_terminates_with_halt() {
    let out = compile_via_driver("1 + 2");
    let main = out.program.entry_proto();
    assert!(matches!(main.code.last(), Some(Op::Halt)));
}

/// define emits DEFINE_GLOBAL (D1/E6 semantics) + DUP return value +
/// value registration.
#[test]
fn define_emits_global_store() {
    let out = compile_via_driver("let x = 5; x");
    assert!(!out.program.global_refs.is_empty());
    let main = out.program.entry_proto();
    // T1 alignment: Define's return value = v (kept by DUP), written via
    // DefineGlobal
    assert!(main.code.iter().any(|op| matches!(op, Op::DefineGlobal(_))));
    assert!(main.code.iter().any(|op| matches!(op, Op::Dup)));
}

/// Disassembly rendering (human-observable output).
#[test]
fn disassembly_is_renderable() {
    let out = compile_via_driver("fn f(x: i64) -> i64 { x * x } f(7)");
    let text = out.disassemble();
    assert!(text.contains("CLOSURE"));
    assert!(text.contains("CALL"));
    assert!(text.contains("RET"));
    assert!(text.contains("HALT"));
    assert!(text.contains("proto"));
}

/// Graph IR: literal sharing (common subexpressions).
#[test]
fn ir_shares_literal_nodes() {
    let out = compile_via_driver("1 + 1");
    // two literals 1 → shared node (node_map hit)
    assert!(
        out.ir.len() < 5,
        "graph IR node count(total share took effect): {}",
        out.ir.len()
    );
}

/// r50-β / D61: let direct-mapping parallel-semantics machine-verifiable
/// group (22 §17.3 prerequisite mandatory item).
///
/// The structural guarantee of the multi-binding staging approach = zero
/// fresh injection in value positions (e_i expands before all binding
/// scopes — same-group bindings are physically invisible). Negative case:
/// in `let x = 1, y = x; ...` the y value position references x →
/// front-end E0022 compile-time rejection (the machine-verifiable face of
/// parallel semantics); positive control: sequential single bindings
/// (let* semantics made explicit — each value domain sees earlier
/// bindings). The IIFE closure is the target face's expression-position
/// sequencing carrier (top-level `let` statements are block-position
/// forms).
#[test]
fn let_direct_mapping_parallel_semantics() {
    // negative case: y's value position x is unbound (parallel semantics —
    // earlier same-group bindings are invisible)
    let err = kerf_driver::compile_source("(|| { let x = 1, y = x; x + y })()", "test.ktf")
        .err()
        .expect("parallel negative case should compile-time rejected");
    assert!(
        err.rendered.contains("E0022") && err.rendered.contains("`x`"),
        "parallel negative case should report E0022 unbound reference `x`: {}",
        err.rendered
    );
    // positive control: sequential statements (let* semantics — value
    // domain sees earlier bindings)
    let out = compile_via_driver("(|| { let x = 1; let y = x; x + y })()");
    assert!(!out.program.global_refs.is_empty() || out.program.proto_count() >= 1);
    // parallel positive case: multiple bindings with no cross-references
    // (staging approach: all values evaluated before binding)
    compile_via_driver("(|| { let x = 1, y = 2; cons(x, y) })()");
}

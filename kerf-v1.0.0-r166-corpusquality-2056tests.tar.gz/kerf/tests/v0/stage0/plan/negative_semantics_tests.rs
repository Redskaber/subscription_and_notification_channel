// E6 close-out (r154 / 224-b2): corpus converted to the target-syntax face.
//! Negative semantics tests (tests/v0/stage0/plan/negative_semantics_tests.rs
//! ↔ docs/tests/v0/stage0/plan/negative-tests.md).
//!
//! §9.4.3 directed expansion: this file anchors the error-semantics layer
//! of **06-operational-semantics** — the E0-E8 error-code matrix, R-rule
//! error paths, T1 theorem dual-path consistency regressions (Task 12/16
//! fix faces), and error message shape (code + Span + excerpt + call-site
//! trace). Each row/iteration = 1 case (table- and matrix-driven).
//!
//! All expected messages are calibrated against actual behavior
//! (2026-09-10, post-fix baseline; re-calibrated on the target face at the
//! E6 close-out — kerf run probes).
//!
//! E6 conversion notes (E6-CG §2 error-face mapping): S-expr Reader
//! negatives (unclosed paren / empty assign form / body-less lambda)
//! convert to the target Reader/Expander message family (unclosed string,
//! unclosed brace, empty quote form); the "nested define duplicate
//! binding" attribution is unreachable from target syntax (the Reader
//! always wraps a multi-statement fn body in do — a body-head define hits
//! the do-position check first) — that sub-case asserts the position
//! defense on the same Stage.
//!
//! Semantic boundaries (verified by measurement):
//! - E7 (I/O errors) is not triggerable via the public API (read_line EOF
//!   → nil is normal semantics; write failure requires closing stdout,
//!   unconstructible in CLI scenarios) — documented, not counted as cases;
//! - E8 (internal invariants: stack underflow / pc out of bounds /
//!   corrupted bytecode) is not user-program triggerable (the compiler
//!   guarantees the invariants) — documented, not counted as cases;
//! - E0003 (Compile stage) is likewise not user-program triggerable (all
//!   compile errors are internal-invariant defenses) — documented, not
//!   counted as cases;
//! - nested duplicate define: on the target face the Reader's do-wrapping
//!   of fn bodies routes every nested define into the expansion-time
//!   position defense ("define is only allowed at the top level or at the
//!   head of a function body") — semantically an early defense equivalent
//!   to E6 (§2.3-4 error over silence);
//! - `define(head, 5)` shadowing a builtin global → E6 (builtin names
//!   occupy the global layer; the same-layer duplicate-definition
//!   constraint applies uniformly to user/builtin names).
//!
//! Dual-path message face (after the TD-018 r24 unification):
//! - unbound variable: VM "unbound global variable (…)" vs eval "unbound
//!   variable" — retained (stage-information difference: the VM side
//!   carries global-fallback resolution completeness);
//! - if non-boolean: VM and eval share the same text "if condition requires
//!   bool" (messages.rs single source).

use crate::common;

use common::dual_path_agrees;
use kerf_driver::{run_source, run_source_seed, Stage};
use kerf_vm::Value;

/// Generic assertion: src fails at the Run stage (E0004 carrier) and
/// contains the message substring.
fn expect_run_err(src: &str, msg: &str) -> kerf_driver::DriverError {
    let err = match run_source(src, "neg.ktf") {
        Ok(_) => panic!("expected an error, got Ok: {}", src),
        Err(e) => e,
    };
    assert_eq!(
        err.stage,
        Stage::Run,
        "stage mismatch:{}\n{}",
        src,
        err.rendered
    );
    assert!(
        err.rendered.contains(msg),
        "message missing `{}`: {}\n complete error: {}",
        msg,
        src,
        err.rendered
    );
    err
}

/// r46 / 67-b deep review D49: unbound-reference assertion (E0022 moved
/// to compile time — the semantics of the former Run-stage E0004 converge
/// into a Compile-stage fail-closed precheck; the runtime E0004 check
/// remains as defense in depth [non-front path]). Both chains report the
/// same (front-pipeline shared segment).
fn expect_unbound_err(src: &str, msg: &str) -> kerf_driver::DriverError {
    let err = match run_source(src, "neg.ktf") {
        Ok(_) => panic!("expected an error, got Ok: {}", src),
        Err(e) => e,
    };
    assert_eq!(
        err.stage,
        Stage::Compile,
        "E0022 compile-time unbound (stage mismatch): {}\n{}",
        src,
        err.rendered
    );
    assert!(
        err.rendered.contains("E0022"),
        "should be E0022 code(stage convergence after): \n{}",
        err.rendered
    );
    assert!(
        err.rendered.contains(msg),
        "message missing `{}`: {}\n complete error: {}",
        msg,
        src,
        err.rendered
    );
    assert!(
        run_source_seed(src, "neg.ktf").is_err(),
        "seed chain should same report(front shared segment): {}",
        src
    );
    err
}

/// Dual-path Err fact assertion: both the production chain and the seed
/// chain must fail (message text may diverge, but the failure fact and
/// stage must agree — the error-absorption shape of T1; 42-d new baseline:
/// the seed chain replaces eval as the cross-check oracle).
fn expect_dual_err(src: &str) {
    assert!(
        run_source(src, "neg.ktf").is_err(),
        "production chain should report an error: {}",
        src
    );
    assert!(
        run_source_seed(src, "neg.ktf").is_err(),
        "seed chain should report an error: {}",
        src
    );
}

// ---------------------------------------------------------------------------
// E1 TypeMismatch: truthiness semantics (§19.5 pitfall 3: Bool only)
// ---------------------------------------------------------------------------

/// E1 (06 §3): the if condition position accepts Bool only — 7 non-boolean
/// types (7 cases). (The quoted-list datum becomes the runtime `list()`
/// construction — the r127 honest boundary.)
#[test]
fn e1_truthy_requires_bool_all_types() {
    let bad = [
        "1",
        "2.5",
        "\"s\"",
        "()",
        "cons(1, 2)",
        "|| (x: i64) { x }",
        "list(1)",
    ];
    for b in bad {
        expect_run_err(&format!("if ({}) {{ 1 }} else {{ 2 }}", b), "requires bool");
    }
}

/// E1: truthiness strictness also applies in nested positions (3 cases:
/// if condition inside then/else branches, if inside do, if inside a fn
/// body).
#[test]
fn e1_truthy_nested_positions() {
    expect_run_err(
        "if (true) { if (1) { 2 } else { 3 } } else { 4 }",
        "requires bool",
    );
    expect_run_err("do(1, if (\"s\") { 2 } else { 3 })", "requires bool");
    expect_run_err("(|| { if (()) { 1 } else { 2 } })()", "requires bool");
}

// ---------------------------------------------------------------------------
// E2 ArityMismatch: procedure arity (R8/apply protocol)
// ---------------------------------------------------------------------------

/// E2: lambda/define-sugar/closure-captured call arity errors (6 cases).
#[test]
fn e2_arity_mismatch_matrix() {
    expect_run_err(
        "(||(x: i64) { x })(1, 2)",
        "procedure argument count mismatch: expected 1, got 2",
    );
    expect_run_err(
        "(||(x: i64, y: i64) { x })(1)",
        "procedure argument count mismatch: expected 2, got 1",
    );
    expect_run_err(
        "(|| { 1 })(9)",
        "procedure argument count mismatch: expected 0, got 1",
    );
    expect_run_err(
        "fn f(a: i64, b: i64) { a } f(1)",
        "procedure argument count mismatch: expected 2, got 1",
    );
    expect_run_err(
        "fn make() { ||(x: i64) { x } } make()(1, 2, 3)",
        "procedure argument count mismatch: expected 1, got 3",
    );
    expect_run_err(
        "fn outer(x: i64) { ||(y: i64) { x } } outer(1)(2, 3)",
        "procedure argument count mismatch: expected 1, got 2",
    );
}

/// E2 dual-path: arity errors reported consistently on both paths (Err
/// fact, 4 cases).
#[test]
fn e2_arity_dual_path_errors() {
    expect_dual_err("(||(x: i64) { x })(1, 2)");
    expect_dual_err("(||(x: i64, y: i64) { x })(1)");
    expect_dual_err("fn f() { 1 } f(2)");
    expect_dual_err("fn f(a: i64, b: i64) { a + b } f(1)");
}

// ---------------------------------------------------------------------------
// E3 UnboundVariable: unbound identifiers (R5/S1)
// ---------------------------------------------------------------------------

/// E3: unbound in all evaluation contexts (10 cases).
/// r46 / 67-b deep review D49: semantic-stage convergence — the former
/// runtime E0004 unbound family moved to compile-time E0022 fail-closed
/// (the R-N1 step 4 carrier; typos or missing import/define rejected at
/// compile time). assign targets unbound under the same baseline.
#[test]
fn e3_unbound_all_contexts() {
    expect_unbound_err("undefined_x", "unbound");
    expect_unbound_err("fn f() { undefined_x } f()", "unbound");
    expect_unbound_err("let x = undefined_y;", "unbound");
    expect_unbound_err("if (undefined_c) { 1 } else { 2 }", "unbound");
    expect_unbound_err("do(undefined_b, 2)", "unbound");
    expect_unbound_err("undefined_s = 1;", "unbound reference");
    expect_unbound_err("fn g() { undefined_h = 1; } g()", "unbound reference");
    expect_unbound_err("1 + undefined_n", "unbound");
    expect_unbound_err("head(undefined_p)", "unbound");
    expect_unbound_err("(||(x: i64) { undefined_q })(1)", "unbound");
}

/// E3: macro-introduced identifiers referencing undefined globals — the
/// hygiene fallback only covers builtin base names; undefined names error
/// on both paths (2 cases; the macro-expansion Span carries the expansion
/// mark).
#[test]
fn e3_macro_introduced_unbound() {
    let src = "macro m { () => undefined_thing } m()";
    expect_unbound_err(src, "unbound");
    expect_dual_err(src);
}

/// E3 message shape: the error carries the macro-expansion Span (the
/// `expansion` mark — phase observability of the Span system, §19.1)
/// (1 case).
#[test]
fn e3_macro_error_carries_expansion_mark() {
    let src = "macro m { () => undefined_thing } m()";
    // r46 / D49: E0022 moved to compile time — the expansion-phase mark
    // retained (the Span of a macro-introduced reference is attributed via
    // the expansion mapping — phase observability unaffected by stage
    // convergence)
    let err = expect_unbound_err(src, "unbound");
    assert!(
        err.rendered.contains("expansion 1"),
        "macro-introduced quote use unbound error should carry expand phase tag: \n{}",
        err.rendered
    );
}

// ---------------------------------------------------------------------------
// E4 NotCallable: non-callable values (A2)
// ---------------------------------------------------------------------------

/// E4: 7 non-procedure values occupying the call position (7 cases).
#[test]
fn e4_not_callable_all_types() {
    let bad = [
        "1",
        "2.5",
        "\"s\"",
        "true",
        "()",
        "cons(1, 2)",
        "list(1, 2)",
    ];
    for b in bad {
        expect_run_err(&format!("{}(1)", b), "uncallable");
    }
}

/// E4: calling a (non-procedure) call result + nested call positions
/// (3 cases).
#[test]
fn e4_not_callable_computed_callee() {
    expect_run_err("(if (true) { 1 } else { 2 })(3)", "uncallable");
    expect_run_err("head(cons(5, 6))(7)", "uncallable");
    expect_run_err("fn f() { 5 } f()(1)", "uncallable");
}

// ---------------------------------------------------------------------------
// E5 BuiltinError: builtin function errors
// ---------------------------------------------------------------------------

/// E5: builtin error family (5 cases: integer division by zero / modulo
/// by zero / car/cdr non-pair / str-append).
#[test]
fn e5_builtin_error_matrix() {
    expect_run_err("1 / 0", "integer division by zero");
    expect_run_err("mod(5, 0)", "integer modulo by zero");
    expect_run_err("head(5)", "head requires pair");
    expect_run_err("tail(\"s\")", "tail requires pair");
    expect_run_err(
        "import kerf_string;\nstring_append(1, \"a\")",
        "string-append requires",
    );
}

// ---------------------------------------------------------------------------
// E6 DuplicateDefine: same-layer duplicate definition (D1 — Task 12 fix
// face)
// ---------------------------------------------------------------------------

/// E6: duplicate definition matrix (9 cases: top level / sugar form /
/// builtin shadowing / nested early defense / inside do / duplicate after
/// assign / different value shapes / sugar define after plain define).
#[test]
fn e6_duplicate_define_matrix() {
    expect_run_err("let x = 1; let x = 2;", "duplicate variable definition");
    expect_run_err("let x = 1; let x = \"s\";", "duplicate variable definition");
    expect_run_err("fn f() { 1 } let f = 2;", "duplicate variable definition");
    expect_run_err("let head = 5;", "duplicate variable definition"); // builtin name occupies the global layer
    expect_run_err("let tail = 5;", "duplicate variable definition");
    expect_run_err(
        "let n = 1; n = 5; let n = 2;",
        "duplicate variable definition",
    );
    expect_run_err(
        "do(define(b, 1), define(b, 2))",
        "duplicate variable definition",
    );
    // nested duplicate: direct-body define rejected at expansion time
    // after hoisting (TD-014 r24: dedicated message attributed to "nested
    // define duplicate binding" -- the former misleading "fn duplicate
    // parameter name" attribution is gone); do-wrapped define: after the
    // D1 fix rejected structurally at compile time (before the fix the VM
    // leaked to globals vs eval lexical definition — a T1 counterexample;
    // both paths share compile_source and report E0003 alike).
    // E6 note: on the target face the Reader always wraps a multi-statement
    // fn body in do, so a body-head define lands in the do-position check
    // first — the "nested define duplicate binding" attribution is
    // unreachable from target syntax; the same source shape reports the
    // define-position defense (Expand E0002 — the nearest target negative,
    // same Stage).
    let lifted = run_source("fn f() { define(x, 1); define(x, 2); x } f()", "neg.ktf")
        .expect_err("should report an error");
    assert_eq!(
        lifted.stage,
        Stage::Expand,
        "directly body define duplicate in expand phase rejected(target face: do-wrapped position check)"
    );
    assert!(
        lifted
            .rendered
            .contains("define is only allowed at the top level or at the head of a function body"),
        "target-face nested define defense: \n{}",
        lifted.rendered
    );
    let begin_wrapped = run_source("fn f() { do(define(y, 1), define(y, 2)) } f()", "neg.ktf")
        .expect_err("do wrap define should by compile-time rejected(D1)");
    // r49 / 70-b declaration-layer arm (semantics-preserving migration):
    // define position discipline moved from the compile-time lowering
    // depth check to the expander's structural dispatch point —
    // Stage::Compile → Stage::Expand (both compile-time fail-closed;
    // message preserved verbatim)
    assert_eq!(
        begin_wrapped.stage,
        Stage::Expand,
        "D1: compile-time rejected(r49 advance expand phase)"
    );
    assert!(
        begin_wrapped
            .rendered
            .contains("define is only allowed at the top level or at the head of a function body"),
        "D1 message: \n{}",
        begin_wrapped.rendered
    );
    assert!(
        begin_wrapped.rendered.contains("error[E0002]"),
        "D1 expand phase rejected render(r49: E0003 stage code → E0002 expansion code -- message text unchanged): \n{}",
        begin_wrapped.rendered
    );
}

/// E6 dual-path regression (Task 12 fix face): duplicate definition errors
/// consistently on both paths (2 cases).
#[test]
fn e6_duplicate_define_dual_path() {
    expect_dual_err("let x = 1; let x = 2;");
    expect_dual_err("fn f() { 1 } let f = 2;");
}

// ---------------------------------------------------------------------------
// E-code carriers and message shape (§8.7 structured diagnostics:
// code + Span + excerpt + call site)
// ---------------------------------------------------------------------------

/// Message shape: stage codes E0001/E0002/E0004 + `-->` Span line +
/// source excerpt column (8 cases). (The S-expr unclosed-paren and
/// empty-assign legs convert to the target Reader/Expander negatives:
/// unclosed brace / empty quote form.)
#[test]
fn message_shape_stage_codes_and_span() {
    let cases = [
        ("\"abc", Stage::Read, "E0001"),      // lexical: unclosed string
        ("fn f() { 1", Stage::Read, "E0001"), // grammar: unclosed brace (Reader)
        ("quote()", Stage::Expand, "E0002"), // expand: empty quote form (the empty-assign leg's nearest target negative)
        ("||(x: i64, x: i64) { x }", Stage::Expand, "E0002"), // duplicate params (A3)
        // r46 / D49: unbound references moved to compile time (Run E0004 → Compile E0022)
        ("undefined_x()", Stage::Compile, "E0022"),
        ("let x = 1; let x = 2;", Stage::Run, "E0004"), // E6
        ("1 + \"s\"", Stage::Run, "E0004"),             // E5/E1 carrier
        ("1(2)", Stage::Run, "E0004"),                  // E4
    ];
    for (src, stage, code) in cases {
        let err = run_source(src, "shape.ktf")
            .err()
            .unwrap_or_else(|| panic!("expected an error, got Ok: {}", src));
        assert_eq!(err.stage, stage, "stage mismatch:{}", src);
        assert!(
            err.rendered.contains(&format!("error[{}]", code)),
            "[{}] error should render code {}: \n{}",
            src,
            code,
            err.rendered
        );
        assert!(
            err.rendered.contains("-->"),
            "should contain Span indicator line: {}",
            src
        );
        assert!(
            err.rendered.contains("|"),
            "should contain source excerpt column: {}",
            src
        );
        assert!(
            err.rendered.contains("^"),
            "should contain underline marker: {}",
            src
        );
    }
}

/// Message shape: call-site trace (§8.12 — the frame chain rendered as
/// note lines; 6 cases).
#[test]
fn message_shape_call_site_trace() {
    // top-level error (no call frame) → no note
    let top = run_source("1 + \"s\"", "t.ktf").err().unwrap();
    assert!(
        !top.rendered.contains("call site"),
        "top level error not should has call site note: \n{}",
        top.rendered
    );
    // single-layer call: error inside f's body → 1 call-site note
    let one = run_source("fn f(n: i64) { n + \"s\" } f(1)", "t.ktf")
        .err()
        .unwrap();
    assert!(
        one.rendered.contains("note: call site"),
        "function inner error should contain call site note: \n{}",
        one.rendered
    );
    // two-layer call chain: g→f, error inside f's body → 2 call-site notes.
    // (H2/TCO note: `0 + f(5)` makes the call non-tail — tail calls
    // vanish from the trace chain via frame reuse (optimized frames leave
    // no stack trace — same behavior as GCC/clang -O2); this test verifies
    // the multi-frame trace rendering face, hence the non-tail shape.)
    let two = run_source("fn f(n: i64) { head(n) } fn g() { 0 + f(5) } g()", "t.ktf")
        .err()
        .unwrap();
    let notes = two.rendered.matches("note: call site").count();
    assert!(
        notes >= 2,
        "dual layer call chain should contain ≥2 call site note(actual {}): \n{}",
        notes,
        two.rendered
    );
    // deep recursion (**non-tail position**): frame-limit error + trace
    // truncation (≤16 frames rendered, guarding against diagnostic
    // explosion).
    // H2/TCO note: the old case `f(n)` self-tail-call infinite loop no
    // longer exhausts frames via TCO frame reuse — taken over by the
    // instruction-budget guardrail (anchored by the instruction_budget
    // negative in tco_tests); this block keeps the "frame limit +
    // truncated rendering" verification intent via the non-tail shape.
    let deep = run_source("fn f(n: i64) { 1 + f(n) } f(1)", "t.ktf")
        .err()
        .unwrap();
    assert!(
        deep.rendered.contains("call frame limit exceeded 100000"),
        "runaway recursion should report frame limit: \n{}",
        deep.rendered
    );
    let deep_notes = deep.rendered.matches("note: call site").count();
    assert!(
        deep_notes <= 16,
        "deep recursion tracing should truncation to ≤16 frame(actual {})",
        deep_notes
    );
    assert!(
        deep_notes > 0,
        "frame limit error should at least containing 1 call site"
    );
    // assign unbound: r46 / D49 moved to compile time (E0022 — front
    // before runtime, no call-site note; the call-site trace is anchored
    // on the runtime error shape — see the deep recursion anchor above)
    let setb = run_source("fn g() { y = 1; } g()", "t.ktf").err().unwrap();
    assert!(setb.rendered.contains("E0022"));
    // macro-introduced error: expansion phase mark
    let hyg = run_source("macro m { () => undefined_thing } m()", "t.ktf")
        .err()
        .unwrap();
    assert!(hyg.rendered.contains("expansion 1"));
}

// ---------------------------------------------------------------------------
// T1 theorem dual-path consistency regression (Task 12 + Task 16 fix
// faces)
// ---------------------------------------------------------------------------

/// T1 regression: global storage semantics fix face (4 cases — before
/// the fix VM/eval diverged).
#[test]
fn t1_regression_global_storage_semantics() {
    // Define return value (D1: before the fix VM nil / eval v)
    assert!(dual_path_agrees("let x = 5;"));
    assert!(dual_path_agrees("let x = 2 + 3; x"));
    // duplicate definition E6 (before the fix both paths silently
    // overwrote)
    assert!(dual_path_agrees("let x = 1; let x = 2;"));
    // assign unbound E3 (before the fix the VM silently created a global)
    assert!(dual_path_agrees("y = 1;"));
}

/// T1 regression: Apply evaluation order (06 §2 A1 function first —
/// Task 16 fix face, 5 cases).
#[test]
fn t1_regression_app_evaluation_order() {
    // unbound at the fn position errors before the argument position
    // (span-based judgment in the same-named test in vm_tests)
    // r46 / D49: unbound moved to compile time — evaluation-order
    // semantics doubly preserved: E0022 traversal order (Apply fn_expr
    // before args — compile-time order) + runtime order of bound
    // expressions (see the E4 runtime anchor on the last line)
    let src = "undefined_a(undefined_b)";
    let vm = run_source(src, "o.ktf").expect_err("production chain should report an error");
    let ev = run_source_seed(src, "o.ktf").expect_err("seed chain should report an error");
    assert!(
        vm.diagnostic.primary_span.start < 12,
        "production chain should report fn position"
    );
    assert!(
        ev.diagnostic.primary_span.start < 12,
        "seed chain should report fn position"
    );
    // unbound argument position → compile-time first (D49 hoist; the
    // runtime evaluation order is anchored on bound expressions)
    expect_dual_err("head(1)(undefined_b)");
    let vm2 = run_source("head(1)(undefined_b)", "o.ktf").err().unwrap();
    assert!(
        vm2.rendered.contains("E0022"),
        "unbound argument position should compile-time report first(D49 advance): \n{}",
        vm2.rendered
    );
    // fn legal + argument error (order does not affect the result, but
    // both paths report the argument error)
    expect_dual_err("head(undefined_arg)");
    // fn position non-callable (E4) before argument evaluation (the
    // runtime-order anchor on the bound-expression shape — unbound
    // arguments see E0022 above; this line verifies E4 remains runtime
    // semantics)
    expect_dual_err("(if (true) { 5 } else { 6 })(undefined_x)");
    expect_run_err("(if (true) { 5 } else { 6 })(1)", "uncallable");
}

/// T1 regression: hygiene fallback resolution (eval path wiring fix —
/// Task 16 fix face, 3 cases).
#[test]
fn t1_regression_hygiene_fallback_dual_path() {
    // macro-introduced builtin reference: base-name hit → both paths
    // resolve alike (before the fix eval reported unbound)
    let src = "macro m { () => 1 + 41 } m()";
    assert!(
        dual_path_agrees(src),
        "macro→builtin reference dual-path should consistent parse is 42"
    );
    // macro-introduced undefined name: both paths report unbound (the
    // fallback only covers builtin base names; the message text differs
    // on each side — VM "unbound global variable …" vs eval "unbound
    // variable", hence asserting the Err fact rather than rendering
    // agreement)
    let src2 = "macro m { () => undefined_thing } m()";
    expect_dual_err(src2);
    // hygienic macro body: same names inside and outside a macro do not
    // cross-interfere (swap semantics positive case — the only positive
    // anchor in this negative file, ensuring the hygiene fallback has not
    // broken normal macro semantics)
    assert!(dual_path_agrees(
        "macro swap { (x, y) => { let tmp = x; x = y; y = tmp; } } \
         let p = 1; let q = 2; swap(p, q); p - q"
    ));
}

// ---------------------------------------------------------------------------
// Scope and hygiene negatives (R7/R9 environment chain)
// ---------------------------------------------------------------------------

/// Scope negatives: lexical scope / closure capture error shapes (5
/// cases).
#[test]
fn scope_closure_negatives() {
    // assign of an uncaptured outer undefined variable inside a fn
    // r46 / D49: E0022 moved to compile time (the four cases migrated
    // under the same baseline)
    expect_unbound_err("fn g() { outer = 1; } g()", "unbound reference");
    // unbound reference inside a closure body (not found in the capture
    // chain)
    expect_unbound_err("(|| { nope })()", "unbound");
    // referencing an outer same-name unbound after parameter shadowing
    // (lexical scope boundary)
    expect_unbound_err("fn f(x: i64) { x + y } f(1)", "unbound");
    // referencing another undefined name after a local define inside do
    expect_unbound_err("do(define(a, 1), b)", "unbound");
    // after the TD-002 release symbol datums are legal symbol values —
    // the negative anchor moved to the value-consumer side: symbol values
    // in arithmetic report E0004 on both paths (dual-path agreement
    // negative case)
    let vm_err = run_source("quote(x) + 1", "q.ktf")
        .expect_err("symbol arithmetic should report an error(VM)");
    assert_eq!(vm_err.stage, Stage::Run);
    assert!(vm_err.rendered.contains("+ requires int"));
    let ev_err = run_source_seed("quote(x) + 1", "q.ktf")
        .expect_err("symbol arithmetic should report an error(seed chain)");
    assert!(ev_err.rendered.contains("int"));
}

// ---------------------------------------------------------------------------
// Error recovery semantics (§7.3.1 bucket D — honest archival of
// single-error short-circuit semantics)
// ---------------------------------------------------------------------------

/// Error recovery: Stage 0 has single-error short-circuit semantics (the
/// first error terminates the pipeline; subsequent forms are not
/// evaluated) — this group anchors that factual behavior (4 cases;
/// multi-error collection is a Stage 1 evolution item of stage0.md §8.7,
/// TD-013).
#[test]
fn error_recovery_single_error_semantics() {
    // error mid-do: subsequent forms not evaluated (the error is absorbed
    // — E0)
    let err = run_source("do(1, head(5), 2)", "r.ktf").err().unwrap();
    assert_eq!(err.stage, Stage::Run);
    assert!(err.rendered.contains("head requires pair"));
    // first error wins (the earlier error shadows the later one)
    let first = run_source("head(1); tail(2)", "r.ktf").err().unwrap();
    assert!(
        first.rendered.contains("head requires pair"),
        "first wrong should report first: \n{}",
        first.rendered
    );
    // expansion-time error blocks compilation (later good forms do not
    // appear in diagnostics)
    let exp = run_source("fn f(x: i64, x: i64) { x } let good = 1;", "r.ktf")
        .err()
        .unwrap();
    assert_eq!(exp.stage, Stage::Expand);
    // an independent program after the error is unaffected
    // (process-level recovery — same semantics as audit bucket D)
    let ok = run_source("40 + 2", "r2.ktf");
    assert!(matches!(ok, Ok(ref o) if matches!(o.value, Value::Int(42))));
}

/// Error recovery: errors do not panic / hang — all E-code paths return
/// structured Err (4 cases).
#[test]
fn error_recovery_no_panics_structured() {
    for src in [
        "head(())",
        "1 / 0",
        "let x = 1; let x = 1;",
        "(||(x: i64) { x })(1, 2, 3, 4, 5)",
    ] {
        // returning Err (instead of panic/abort) is structured recovery
        let r = run_source(src, "s.ktf");
        assert!(r.is_err(), "should structured error report: {}", src);
    }
}

// ---------------------------------------------------------------------------
// T17-a adversarial deep-dig regressions (D2/D7 — dual-path soundness fix
// faces)
// ---------------------------------------------------------------------------

/// D2 regression: eq compares strings by content (before the fix the VM
/// deduplicated via the constant pool → true / eval allocated
/// independently → false — pointer-comparison divergence, violating T1
/// and "immediate values compare by value").
#[test]
fn d2_eq_string_content_semantics() {
    // same-content literals: true on both paths
    let src = "eq(\"a\", \"a\")";
    let vm = common::run(src).expect("VM should Ok");
    assert!(
        matches!(vm, Value::Bool(true)),
        "VM same content should true"
    );
    let ev = kerf_driver::run_source_seed(src, "d2.ktf").expect("seed chain should Ok");
    assert!(
        matches!(ev.value, Value::Bool(true)),
        "seed chain same content should true"
    );
    // constructed string vs literal: equal content → true (dual-path
    // agreement)
    let src2 = "import kerf_string;\neq(\"ab\", string_append(\"a\", \"b\"))";
    assert!(
        common::dual_path_agrees(src2),
        "construct build string content comparison dual paths agree"
    );
    let v = common::run(src2).expect("should Ok");
    assert!(
        matches!(v, Value::Bool(true)),
        "content equality should true"
    );
    // different content → false (negative case)
    let v2 = common::run("eq(\"a\", \"b\")").expect("should Ok");
    assert!(matches!(v2, Value::Bool(false)));
    // r162 / 233 — TD-037 D5 law revision: heap values (pairs) now
    // compare by recursive STRUCTURE (immutable-by-construction ⟹
    // value equality; the r138-era reference-identity law retired)
    let v3 = common::run("eq(cons(1, 2), cons(1, 2))").expect("should Ok");
    assert!(
        matches!(v3, Value::Bool(true)),
        "heap value(pair) compares by structure (r162 law)"
    );
}

/// D7 regression: reference-chain error fidelity (before the fix eval
/// accumulated an "evaluation failed:" prefix layer by layer and the Span
/// landed on the outermost call site; after the fix the message is
/// verbatim and the Span locates the innermost error position — 42-d
/// baseline migration: the seed chain cross-checked under the same
/// criterion).
#[test]
fn d7_eval_error_fidelity() {
    // f→g→+ type error: the seed-chain message has no "evaluation
    // failed:" prefix (matching the production-chain message shape)
    let src = "fn f(n: i64) { n + \"s\" } fn g() { f(1) } g()";
    let ev = run_source_seed(src, "d7.ktf").expect_err("seed chain should report an error");
    assert!(
        !ev.rendered.contains("evaluate failed"),
        "eval error not should accumulated wrapper prefixes: \n{}",
        ev.rendered
    );
    assert!(
        ev.rendered.contains("+ requires int"),
        "error message should passed through verbatim: \n{}",
        ev.rendered
    );
    // Span fidelity: locates the innermost error position (the + operand,
    // `n + "s"` at 1:16 → start 15), not the outermost g() call (at
    // 1:43)
    assert!(
        ev.diagnostic.primary_span.start < 40,
        "eval error Span should locate the innermost error position(actual start={}): \n{}",
        ev.diagnostic.primary_span.start,
        ev.rendered
    );
    // dual-path error message agreement (shape alignment outside the D8
    // message-divergence face)
    let vm = run_source(src, "d7.ktf").expect_err("VM should report an error");
    assert!(
        vm.rendered.contains("+ requires int"),
        "VM error message consistent: \n{}",
        vm.rendered
    );
}

// D3/D5/D9 regressions in negative_vm_tests (depth-limit structured /
// identity elements / unary negation);
// D1/D6 regressions in the t1 regression section of this file
// (compiler/expander fix faces).

/// D6 regression: macro calling a macro (a template-introduced reference
/// to another transformer resolves by base-name fallback after hygienic
/// α renaming — the landing of 03 §2.4 hygiene guarantee (2) "free
/// identifier cross-through".
/// Before the fix: `inc$hyg$N` was unbound and errored on both paths (the
/// transformer table cannot find the renamed symbol).
#[test]
fn d6_macro_calls_macro_hygiene_fallback() {
    let src = "macro inc { (v) => { v = v + 1; } } \
         macro twice { (e) => { inc(e); inc(e); } } \
         let x = 40; twice(x); x";
    // both paths agree ⇒ 42
    let vm = common::run(src).expect("VM path should Ok");
    assert!(
        matches!(vm, Value::Int(42)),
        "VM macro-calling-macro should parse: {:?}",
        vm
    );
    let ev = kerf_driver::run_source_seed(src, "d6.ktf").expect("seed chain should Ok");
    assert!(
        matches!(ev.value, Value::Int(42)),
        "seed chain macro-calling-macro should parse(base-name fallback): {:?}",
        ev.value
    );
    assert!(common::dual_path_agrees(src));
    // negative case: undefined macro names still error (the fallback only
    // covers registered transformer base names)
    expect_dual_err("macro m { () => no_such_macro() } m()");
}

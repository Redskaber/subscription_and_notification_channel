// E6 close-out (r154 / 224-b2): corpus converted to the target-syntax face.
//! Pipeline E2E integration tests (tests/v0/stage0/plan/pipeline_tests.rs
//! ↔ docs/tests/v0/stage0/plan/pipeline.md).
//!
//! Coverage: full-pipeline data flow (Reader → Expander → Compiler → VM →
//! Runtime) / Span propagation through the whole pipeline (§21.3 acceptance
//! item 4) / CodeValue checks / reserved interface freeze / diagnostic
//! rendering / performance baseline.

use crate::common;

use kerf_core::CodeValue;
use kerf_driver::{compile_source, run_source, run_source_seed, Stage};

/// Full-pipeline snapshot: compile → execute → render.
#[test]
fn pipeline_end_to_end_snapshot() {
    let src = "fn square(x: i64) -> i64 { x * x } square(12)";
    assert_eq!(common::run_rendered(src), "144");
}

/// Span propagation spot-check through the whole pipeline (§21.3 Stage 0
/// acceptance item 4): lexical Span → syntax object → CoreExpr → bytecode
/// debug_info.
#[test]
fn span_propagates_through_all_stages() {
    let src = "let x = 1; x + 2";
    let out = compile_source(src, "span.ktf").unwrap();
    // 1. lexing → syntax object: the define form covers the source range
    let core = &out.core[0];
    assert_eq!(core.span().start, 0);
    // 2. CoreExpr → graph IR: metadata carries Span
    assert!(!out.ir.get_metadata(out.ir.roots()[0]).span.is_empty());
    // 3. bytecode: every instruction has a debug_span
    for proto in &out.program.protos {
        assert_eq!(proto.code.len(), proto.debug_spans.len());
    }
    // 4. runtime error reverse lookup (Span chain on the error path)
    let err = run_source("1 + head(2)", "err.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Run);
    assert!(err.rendered.contains("err.ktf"));
}

/// CodeValue check (§22.3 milestone: CodeValue well-formedness).
#[test]
fn code_value_well_formed_check() {
    let out = compile_source("fn f(x: i64) -> i64 { x + 1 } f(2)", "cv.ktf").unwrap();
    // r49 D59: item face — per-item CodeValue checks on declaration values /
    // expression items
    for item in &out.core {
        let exprs: Vec<&kerf_core::CoreExpr> = match item {
            kerf_core::ModuleItem::Define { value, .. } => vec![value],
            kerf_core::ModuleItem::Require { .. } | kerf_core::ModuleItem::Module { .. } => vec![],
            kerf_core::ModuleItem::Expr(e) => vec![e],
        };
        for e in exprs {
            let cv = CodeValue::from_expr(e);
            assert!(cv.is_well_formed(), "CodeValue must well-formed");
        }
    }
}

/// Four reserved interfaces frozen (§22.3 milestone + §21.3 acceptance item 6).
#[test]
fn four_reserved_interfaces_frozen() {
    // compilation cache (P2): content-addressed keys
    let k1 = kerf_driver::CacheKey {
        source_hash: 1,
        config_fingerprint: 2,
    };
    let k2 = k1.clone();
    assert_eq!(k1, k2);
    // capability model tokens (P2): types nameable, unforgeable (private
    // constructors)
    fn assert_read(_c: &kerf_driver::ReadCapability) {}
    fn assert_write(_c: &kerf_driver::WriteCapability) {}
    let _ = (
        assert_read as fn(&kerf_driver::ReadCapability),
        assert_write as fn(&kerf_driver::WriteCapability),
    );
    // EffectSystem / MultiStage (P3): traits nameable (frozen shapes proven
    // by the Probe implementations in kerf-driver::reserved unit tests)
}

/// Convergent-result test: the same program compiled twice + executed
/// twice yields identical results (§21.3 acceptance item 3 in its Stage 0
/// shape — pipeline determinism under the Rust host).
#[test]
fn convergent_compilation_and_execution() {
    let src = "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } } fib(15)";
    let out1 = compile_source(src, "same.ktf").unwrap();
    let out2 = compile_source(src, "same.ktf").unwrap();
    assert!(out1.program.bytecode_equal(&out2.program));
    let r1 = run_source(src, "same.ktf").unwrap();
    let r2 = run_source(src, "same.ktf").unwrap();
    assert!(r1.value.eq_value(&r2.value));
}

/// Diagnostic rendering: full human-readable output for errors at every
/// stage (§2.2 principle 16). (The S-expr unclosed-paren leg converts to
/// the target Reader's unclosed-string negative; the empty-assign expand
/// leg converts to the empty-quote expand negative — the target-face
/// message family, E6-CG §2 error-face mapping.)
#[test]
fn diagnostics_render_per_stage() {
    // Read stage (lexical: unclosed string literal)
    let e1 = run_source("\"abc", "d1.ktf").unwrap_err();
    assert!(e1.rendered.contains("error[E0001]"));
    assert!(e1.rendered.contains("d1.ktf:1:1"));
    // Expand stage (empty quote form)
    let e2 = run_source("quote()", "d2.ktf").unwrap_err();
    assert_eq!(e2.stage, Stage::Expand);
    // Run stage
    let e3 = run_source("head(3)", "d3.ktf").unwrap_err();
    assert_eq!(e3.stage, Stage::Run);
    assert!(e3.rendered.contains("d3.ktf"));
}

/// Seed-chain reference path usable (T1 new baseline 42-d — eval retired:
/// the production chain's cross-check oracle surface is complete; seed
/// chain and production chain agree). (Top-level `let` is not a target
/// run-face item — the let body wraps in an immediately-invoked closure,
/// E6-CG §2 let mapping.)
#[test]
fn seed_reference_path_complete() {
    let src = "(|| { let x = 3; x * x })()";
    let o = run_source_seed(src, "e.ktf").unwrap();
    assert!(matches!(o.value, kerf_vm::Value::Int(9)));
    // agrees with the production chain (dual-path cross-check)
    let p = run_source(src, "e.ktf").unwrap();
    assert!(p.value.eq_value(&o.value));
}

/// Full built-in function set (§9 stdlib: core has zero builtins, the
/// driver injects them). Kebab builtin names are written snake_case on the
/// target face (the `-` ↔ `_` Reader symbol-introduction mapping); the
/// S-expr chained-comparison/chain-arithmetic rows reduce to their binary
/// infix faces (comparison is non-chaining on the target grammar).
#[test]
fn builtin_library_registered() {
    let cases = [
        ("1 + 2", "3"),
        ("10 - 4 - 1", "5"),
        ("2 * 3 * 4", "24"),
        ("100 / 5 / 2", "10"),
        ("mod(17, 5)", "2"),
        ("3 == 3", "true"), // S-expr chain (= 3 3 3) → binary face
        ("1 < 2", "true"),  // S-expr chain (< 1 2 3) → binary face
        ("3 > 1", "true"),
        ("2 <= 2", "true"),
        ("1 >= 2", "false"),
        ("cons(1, 2)", "(1 . 2)"),
        ("head(list(9, 8))", "9"),
        ("tail(list(9, 8))", "(8)"),
        ("list(1, 2, 3)", "(1 2 3)"),
        ("is_nil(())", "true"),
        ("is_pair(cons(1, 2))", "true"),
        ("is_int(5)", "true"),
        ("is_bool(true)", "true"),
        ("is_procedure(head)", "true"),
        ("eq(1, 1)", "true"),
        ("!false", "true"),
        (
            "import kerf_string;\nstring_append(\"foo\", \"bar\")",
            "foobar",
        ),
    ];
    for (src, expected) in cases {
        assert_eq!(common::run_rendered(src), expected, "builtin {}", src);
    }
}

/// String and float programs.
#[test]
fn strings_and_floats() {
    assert_eq!(common::run_rendered("\"hello\""), "hello");
    assert_eq!(common::run_rendered("1.5 + 2.5"), "4.0");
    assert_eq!(common::run_rendered("2 * 1.5"), "3.0");
}

/// Macro-system user programs (hygiene + ellipsis combinations). The
/// `macro NAME { pattern => template }` arm structure is the target face
/// of define-syntax/syntax-rules (E6-CG §2 ninth mapping).
#[test]
fn user_macro_programs() {
    let src = r#"
        macro swap {
            (a, b) => {
                let tmp = a;
                a = b;
                b = tmp;
            }
        }
        let x = 1;
        let y = 2;
        swap(x, y);
        list(x, y)
    "#;
    assert_eq!(common::run_rendered(src), "(2 1)");
}

/// Structured errors: DriverError implements Display. (The S-expr
/// body-less-lambda leg converts to the empty-quote expand negative —
/// the nearest target-syntax Expand-stage error.)
#[test]
fn driver_error_display_format() {
    let err = run_source("quote()", "f.ktf").unwrap_err();
    let text = format!("{}", err);
    assert!(text.starts_with("[expand]"));
}

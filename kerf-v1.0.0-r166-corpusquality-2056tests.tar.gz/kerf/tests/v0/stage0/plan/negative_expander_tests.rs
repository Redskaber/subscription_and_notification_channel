// E6 close-out (r154 / 224-b4): converted to the target-syntax face.
//! Negative Expander tests (tests/v0/stage0/plan/negative_expander_tests.rs
//! ↔ docs/tests/v0/stage0/plan/negative-tests.md).
//!
//! §9.4.3 directed expansion: this file covers the **Expand stage (E0002)**
//! error families reachable from the target face — the call-form define
//! family, quote/syntax-rules keyword misuse, macro no-clause-match and
//! expansion-depth overflow, import/export position discipline, and
//! phase-bookkeeping violations (declare/visit/instantiate + module cycle
//! dependency archive).
//!
//! E6 conversion notes (s-expr-removal-plan §4, calibrated by running):
//! the target Reader's grammar now enforces most structural shapes that
//! the S-expr face left to the Expander — those misuse families moved to
//! the **Read stage (E0001)** with the Reader's own messages (fn/if/let/
//! assign/module/macro declaration shapes). Families with no target-
//! surface shape at all were deleted and recorded in the r154 worklog:
//! empty application (11 — `()` is the nil literal on this face), letrec
//! (5), let* (4), cond (4), when/while/unless (3), the bare-symbol macro
//! pattern (1), the multi-expression assign/define-internal shapes
//! (grammar-enforced), and the function-body head-define hoisting window
//! (block threading do-wraps every in-body define → the position
//! rejection below).
//!
//! Each row = 1 case (table-driven). All expected messages/Spans are
//! calibrated against actual behavior.
//!
//! Known defect archive (verified by measurement, #[ignore], not counted
//! in case totals): deep recursion on the eval path aborts with a Rust
//! stack overflow (the VM path has the MAX_FRAMES structured error) —
//! `deep_recursion_eval_path_ignored` (same as the VM file's).
//! - module cycle dependency fixed (phase.rs DFS gray marking → structured
//!   Err "module cycle dependency: Symbol(N) → …") — see
//!   `module_cycle_dependency_errors`.

use kerf_driver::{check_source_recover, run_source, Stage};
use kerf_expander::phase::ModuleRegistry;
use kerf_syntax::Symbol;

/// Generic assertion: src fails at the Expand stage and the rendered error
/// contains the message substring.
fn expect_expand_err(src: &str, msg: &str) -> kerf_driver::DriverError {
    expect_err_at_stage(src, Stage::Expand, msg)
}

/// Generic assertion: src fails at the Read stage (the target Reader's
/// grammar-enforced shapes — the E6 face of the former Expand-stage
/// structural families) and the rendered error contains the message.
fn expect_read_err(src: &str, msg: &str) -> kerf_driver::DriverError {
    expect_err_at_stage(src, Stage::Read, msg)
}

/// Shared tail: src fails at the given stage with the message substring.
fn expect_err_at_stage(src: &str, stage: Stage, msg: &str) -> kerf_driver::DriverError {
    let err = match run_source(src, "neg.ktf") {
        Ok(_) => panic!("expected an error, got Ok: {}", src),
        Err(e) => e,
    };
    assert_eq!(err.stage, stage, "stage mismatch:{}\n{}", src, err.rendered);
    assert!(
        err.rendered.contains(msg),
        "message missing `{}`: {}\n complete error: {}",
        msg,
        src,
        err.rendered
    );
    err
}

/// Assert the error Span points exactly.
fn expect_span(err: &kerf_driver::DriverError, start: u32, end: u32) {
    assert_eq!(
        err.diagnostic.primary_span.start, start,
        "Span.start mismatch"
    );
    assert_eq!(err.diagnostic.primary_span.end, end, "Span.end mismatch");
}

/// fn declaration misuse (7 cases): missing name / missing body block /
/// parameter not an identifier / missing type annotation / string in the
/// parameter list / duplicate names (declaration + nested closure —
/// Expand-stage, message family unchanged) .
#[test]
fn lambda_misuse() {
    let read_cases: &[(&str, &str)] = &[
        ("fn", "expected a function name identifier"),
        ("fn f(x: i64)", "expected {"),
        ("fn f(1: i64) { }", "expected a parameter name, got Int(1)"),
        ("fn f(x) { x }", "expected :, got RParen"),
        (
            "fn f(x: i64, \"s\": i64) { x }",
            "expected a parameter name, got Str",
        ),
    ];
    for (src, msg) in read_cases {
        expect_read_err(src, msg);
    }
    // duplicate names: Expand-stage E0002 (TD-014 dedicated attribution —
    // declaration face and nested closure face)
    let expand_cases: &[(&str, &str)] = &[
        ("fn f(x: i64, x: i64) { x }", "fn duplicate argument names"),
        (
            "(|| (x: i64) { || (x: i64, x: i64) { x } })(1)",
            "fn duplicate argument names",
        ),
    ];
    for (src, msg) in expand_cases {
        expect_expand_err(src, msg);
    }
}

/// if misuse (3 cases): missing condition / missing then-block / a second
/// else block — Read-stage on the target face (the if arity is
/// grammar-enforced: `(if c t)` two-branch stays legal, missing else → nil).
#[test]
fn if_misuse() {
    let cases: &[(&str, &str)] = &[
        ("if", "expected an expression, got Eof"),
        ("if (true)", "expected {"),
        (
            "if (true) { 1 } else { 2 } else { 3 }",
            "expected an expression, got KwElse",
        ),
    ];
    for (src, msg) in cases {
        expect_read_err(src, msg);
    }
}

/// assign misuse (3 cases): target not an expression-position assignable /
/// string target / missing value — Read-stage on the target face (the
/// assign statement grammar `name = expr;` is enforced; the
/// multi-expression value shape parses as separate statements and is no
/// longer a negative — recorded in the r154 worklog).
#[test]
fn setbang_misuse() {
    let cases: &[(&str, &str)] = &[
        ("1 = 2;", "expected an expression, got Assign"),
        ("\"s\" = 1;", "expected an expression, got Assign"),
        ("x =;", "expected an expression, got Semi"),
    ];
    for (src, msg) in cases {
        expect_read_err(src, msg);
    }
}

/// define misuse (7 cases — r158 / 228-c reface): the item-position
/// call-form family (define()/define(x)/define(1, 2)/define(x, 1, 2))
/// is fronted to the Read-stage retirement diagnostic (the whole
/// family retires together — toplevel-let-design.md D2); the modern
/// multi-binding cap (let x = 1, 2;) fails closed at Read too; the
/// expander's define-form diagnostics stay reachable via the S-expr
/// face's (define ...) shapes. Function-sugar head / no-body cases
/// stay Read-stage (unchanged).
#[test]
fn define_misuse() {
    let read_cases_retired: &[(&str, &str)] = &[
        ("define();", "the define call form is retired"),
        ("define(x);", "the define call form is retired"),
        ("define(1, 2);", "the define call form is retired"),
        ("define(x, 1, 2);", "the define call form is retired"),
        ("let x = 1, 2;", "top-level let takes a single binding"),
    ];
    for (src, msg) in read_cases_retired {
        expect_read_err(src, msg);
    }
    let read_cases: &[(&str, &str)] = &[
        (
            "fn 1(x: i64) { x }",
            "expected a function name identifier, got Int(1)",
        ),
        (
            "fn \"s\"(x: i64) { x }",
            "expected a function name identifier, got Str",
        ),
        ("fn f()", "expected {"),
    ];
    for (src, msg) in read_cases {
        expect_read_err(src, msg);
    }
}

/// module misuse (4 cases): missing name / name not an identifier / import
/// item not an identifier / export item not an identifier — Read-stage on
/// the target face (the module header grammar is enforced).
#[test]
fn module_misuse() {
    let cases: &[(&str, &str)] = &[
        ("module", "expected a module name identifier"),
        ("module 1 { }", "expected a module name identifier"),
        (
            "module m { import 1; }",
            "expected an import name, got Int(1)",
        ),
        (
            "module m { export 1; }",
            "expected an export name, got Int(1)",
        ),
    ];
    for (src, msg) in cases {
        expect_read_err(src, msg);
    }
}

/// import/export misuse (4 cases): used outside the module header zone
/// (top level + fn body).
#[test]
fn import_export_misuse() {
    // r46 / 67-b deep review D47: top-level import legalized (program
    // top-level direct element position — E0002 applies only to expression
    // subtrees/mid-body). Position discipline three-way split:
    // ① `import x;` at top level → legal position (name-list check after
    //    stripping — E0019 unknown module)
    // ② `export x;` at top level → E0002 (of import/export only import
    //    opens the top-level position — export has no program-level
    //    semantics [module export-surface declaration], module header
    //    region only)
    // ③ either inside a fn body → the target Reader rejects the
    //    declaration keywords in expression position (E0001 — the E6 face
    //    of the former Expand-stage mid-body rejection)
    let unknown = match run_source("import x;", "neg.ktf") {
        Ok(_) => panic!("expected an error, got Ok: import x;"),
        Err(e) => e,
    };
    assert_eq!(
        unknown.stage,
        Stage::Compile,
        "top level import after legalization converge E0019 list verify: \n{}",
        unknown.rendered
    );
    assert!(
        unknown.rendered.contains("unknown imported module"),
        "message missing `unknown imported module`: \n{}",
        unknown.rendered
    );
    expect_expand_err(
        "export x;",
        "import/export may only appear as a direct program top-level element or in module header zone",
    );
    expect_read_err(
        "fn f() { import x; }",
        "expected an expression, got KwImport",
    );
    expect_read_err(
        "fn f() { export x; }",
        "expected an expression, got KwExport",
    );
}

/// quote misuse (2 cases): arity — the call form lowers to the same quote
/// Stx, so the Expand-stage message family is byte-identical to the
/// S-expr face. (Vector values are positive cases — TD-002 D2-b;
/// comprehensive coverage in ktf_vector_value_tests.)
#[test]
fn quote_misuse() {
    let cases: &[(&str, &str)] = &[
        ("quote()", "quote form: (quote data)"),
        ("quote(x, y)", "quote form: (quote data)"),
    ];
    for (src, msg) in cases {
        expect_expand_err(src, msg);
    }
}

/// let misuse (6 cases): let outside a block position (the target face's
/// let is a block-position statement) / binding name not an identifier /
/// binding without a value / value not a single expression / missing
/// value expression — Read-stage (the let grammar is enforced; the
/// binding-group-not-a-list / binding-not-a-pair shapes have no target
/// surface — recorded in the r154 worklog).
#[test]
fn let_misuse() {
    // r50-β / D61: let exits the sugar table (core-form direct mapping) —
    // the call-form dispatch site reports directly.
    // r158 / 228-c: the top-level `let x = 1;` case is retired from this
    // battery — the item-position let is now the modern binding form
    // (parses successfully — ktf_toplevel_let_tests owns the positive
    // face); the fn-body misuse family keeps the reader-level anchors.
    let cases: &[(&str, &str)] = &[
        (
            "fn f() { let 1 = 2; }",
            "expected a binding name, got Int(1)",
        ),
        ("fn f() { let x; }", "expected =, got Semi"),
        ("fn f() { let x = 1 2; }", "expected ;, got Int(2)"),
        ("fn f() { let x = ; }", "expected an expression, got Semi"),
        ("fn f() { let x, = 2; }", "expected =, got Comma"),
    ];
    for (src, msg) in cases {
        expect_read_err(src, msg);
    }
}

/// `else` outside an if arm (1 case) — the target Reader rejects the
/// keyword in expression position (the E6 face of the former
/// "else may only appear in cond the clause's test position" family —
/// the cond surface itself is retired).
#[test]
fn else_misuse() {
    expect_read_err("else", "expected an expression, got KwElse");
}

/// macro-definition misuse (6 cases): missing name / missing arms block /
/// name not an identifier / arm missing the `=>` separator / missing
/// template / pattern elements not comma-separated — Read-stage (the
/// `macro NAME { (pat) => tpl }` grammar is enforced; the separate
/// syntax-rules-internal structure family has no target surface — the
/// macro arm grammar IS the face).
#[test]
fn define_syntax_misuse() {
    let cases: &[(&str, &str)] = &[
        ("macro", "expected a macro name identifier"),
        ("macro m", "expected {"),
        (
            "macro 1 { () => 1 }",
            "expected a macro name identifier, got Int(1)",
        ),
        ("macro m { () 1 }", "expected =>, got Int(1)"),
        ("macro m { () => }", "expected an expression, got RBrace"),
        ("macro m { (1 2) => 1 }", "expected ), got Int(2)"),
    ];
    for (src, msg) in cases {
        expect_read_err(src, msg);
    }
}

/// Bare syntax-rules use (2 cases): appearing outside define-syntax —
/// the snake_case identifier reaches the keyword face through the skin
/// name mapping (target `syntax_rules` → S-expr `syntax-rules`), so the
/// Expand-stage message family is byte-identical to the S-expr face.
#[test]
fn syntax_rules_misuse() {
    for src in ["syntax_rules()", "fn f() { syntax_rules() }"] {
        expect_expand_err(
            src,
            "syntax-rules may only appear in define-syntax internal",
        );
    }
}

/// Vector in expression position (r138 / 208-c — TD-002: the former
/// rejection anchor flipped to the acceptance face — the D2-a desugar
/// product = the vector application; comprehensive coverage in
/// ktf_vector_value_tests; this anchor keeps the flip explicit at the
/// original test site).
#[test]
fn vector_in_expression_position_desugar() {
    // `[1, 2, 3]` expands to the vector application (as-if-written) — the
    // expansion succeeds and the full pipeline runs to the vector value
    let report =
        check_source_recover("[1, 2, 3]", "vec.ktf").expect("expand should succeed(D2-a desugar)");
    assert!(
        report.diagnostics.is_empty(),
        "vector expression should zero diagnostics: {:?}",
        report.diagnostics
    );
}

/// The still-rejecting pattern-position anchor (match-design §1 —
/// vector in match patterns stays domain-out; the one rejection that
/// r138 deliberately preserves). E6 face: the rejection now fires at the
/// Reader's pattern grammar (E0001 "expected a pattern, got LBracket" —
/// calibrated) instead of the Expander's "vector not can appear in
/// pattern position"; same fail-closed boundary.
#[test]
fn vector_in_match_pattern_still_rejected() {
    // The scrutinee [1, 2] is a legal expression-position vector (D2-a);
    // the PATTERN [v] is the rejecting site (match-design §1 out of domain)
    expect_read_err(
        "match [1, 2] { [v] => v, _ => 0 }",
        "expected a pattern, got LBracket",
    );
}

/// define not at the function body head (1 case) — the flip side of
/// §19.2 pitfall 3. E6 face: an in-body `define(y, 2);` statement is
/// block-threaded into a `(do ...)` wrap → the define-position rejection
/// (message recalibrated at r154; the head-position hoisting window
/// itself is unreachable from the target Reader — recorded in the
/// worklog).
#[test]
fn define_not_at_body_head() {
    let err = expect_expand_err(
        "fn f() { 1; define(x, 2); }",
        "define is only allowed at the top level or at the head of a function body",
    );
    // Span calibrated: the define statement's position (source cols 13-24)
    expect_span(&err, 12, 24);
}

/// Macro expansion failures (5 cases): call vs pattern mismatch ×3
/// (extra actuals / too few actuals / literal-arm zero-arg call),
/// self-reference expansion depth overflow (§7.1.1 class 7),
/// self-reference multiplicative expansion (mismatch path). (The
/// bare-symbol pattern leg of the S-expr face has no target surface —
/// patterns are paren forms; recorded in the r154 worklog.)
#[test]
fn macro_expansion_failures() {
    let cases: &[(&str, &str)] = &[
        (
            "macro m { (_) => 1 }\nm(1, 2)",
            "macro `m` expand failed: macro call matches no clause pattern",
        ),
        (
            "macro m { (_, x) => x }\nm()",
            "macro `m` expand failed: macro call matches no clause pattern",
        ),
        (
            "macro lo { () => lo() }\nlo()",
            "macro expansion depth exceeds the limit 10000(suspected infinite recursive expansion)",
        ),
        (
            "macro lo { () => lo(lo) }\nlo()",
            "macro `lo` expand failed: macro call matches no clause pattern",
        ),
        (
            "macro m { (_, 1) => 1, (_, x) => 2 }\nm()",
            "macro `m` expand failed: macro call matches no clause pattern",
        ),
    ];
    for (src, msg) in cases {
        expect_expand_err(src, msg);
    }
}

/// Phase bookkeeping (4 cases, ModuleRegistry public API direct tests):
/// duplicate declare / visit without declare / instantiate without visit /
/// visit transitive dependency undeclared.
#[test]
fn module_registry_phase_violations() {
    // duplicate declaration (explicit failure, no silent overwrite)
    let mut reg = ModuleRegistry::new();
    reg.declare(Symbol(1), vec![], vec![]).unwrap();
    let err = reg.declare(Symbol(1), vec![], vec![]).unwrap_err();
    assert!(
        err.contains("module duplicate declaration"),
        "actual: {}",
        err
    );
    // visit without declare
    let mut reg2 = ModuleRegistry::new();
    let err2 = reg2.visit(Symbol(9)).unwrap_err();
    assert!(err2.contains("undeclared module"), "actual: {}", err2);
    // instantiate without visit (phase violation)
    let mut reg3 = ModuleRegistry::new();
    reg3.declare(Symbol(1), vec![], vec![]).unwrap();
    let err3 = reg3.instantiate(Symbol(1)).unwrap_err();
    assert!(
        err3.contains("instantiated without visit"),
        "actual: {}",
        err3
    );
    // transitive dependency broken: visit(m2) needs to visit undeclared m1 first
    let mut reg4 = ModuleRegistry::new();
    reg4.declare(Symbol(2), vec![Symbol(1)], vec![]).unwrap();
    let err4 = reg4.visit(Symbol(2)).unwrap_err();
    assert!(err4.contains("undeclared module"), "actual: {}", err4);
}

/// Phase error reachable from source (1 case): module importing an
/// undeclared module.
/// Note: the driver takes a special rendering path for registry errors —
/// no error[E0002] prefix, only the `[expand] undeclared module` Display
/// shape (asserting current behavior as-is).
#[test]
fn module_import_undeclared_from_source() {
    // M2 (r40) E0019 takeover: unknown imported modules are rejected first
    // by the import-face name-list check (previously registry.visit's
    // "undeclared module" — E0019 carries the registered list and Stage 3
    // window guidance, a diagnostic gain; deep review D2 ruling)
    let err = match run_source("module m { import x; 1 }", "neg.ktf") {
        Ok(_) => panic!("expected an error, got Ok"),
        Err(e) => e,
    };
    // M2 unified stage ruling: the front-pipeline compile-time validation
    // family attaches to Compile (consistent with the M1
    // verify_qualified_refs precedent — post-expand validation is not an
    // expansion error)
    assert_eq!(err.stage, Stage::Compile);
    assert!(
        err.rendered.contains("E0019") && err.rendered.contains("unknown imported module `x`"),
        "actual: {}",
        err.rendered
    );
}

/// E0002 rendering-shape full assertions (3 cases): error[E0002] + `-->` +
/// source excerpt. E6 face: the quote-form and define call-form carriers
/// keep the byte-identical family (the Reader lowers them to the same
/// Stx); the closure duplicate-parameter carrier replaces the retired
/// `(fn (x x))` shape (Span recalibrated).
#[test]
fn expander_error_rendering_shape() {
    let err = expect_expand_err("quote(x, y)", "quote form");
    assert!(err.rendered.contains("error[E0002]: quote form"));
    assert!(err.rendered.contains("--> neg.ktf:1:1"));
    assert!(err.rendered.contains("1 | quote(x, y)"));
    // r158 / 228-c: the define(1, 2) leg is Reader-fronted (the
    // retirement diagnostic) — the E0002 rendering-shape anchor keeps
    // the duplicate-parameter closure leg for the span face
    let err2 = expect_read_err("define(1, 2);", "the define call form is retired");
    assert!(err2.rendered.contains("--> neg.ktf:1:1"));
    let err3 = expect_expand_err("(|| (x: i64, x: i64) { x })", "fn duplicate argument names");
    assert!(err3.rendered.contains("--> neg.ktf:1:14"));
    assert!(
        err3.diagnostic.code == Some(kerf_span::DiagnosticCode(2)),
        "Expand error must be numbered E0002"
    );
}

/// Module cycle dependency (§7.1.1 class 6 — formerly a zero-test
/// classification): A imports B + B imports A → `visit` reports the
/// structured Err "module cycle dependency" (before the fix: infinite
/// recursion stack overflow abort — activated after the phase.rs DFS
/// gray-marking fix).
#[test]
fn module_cycle_dependency_errors() {
    let mut reg = ModuleRegistry::new();
    let a = Symbol(1);
    let b = Symbol(2);
    reg.declare(a, vec![b], vec![]).unwrap();
    reg.declare(b, vec![a], vec![]).unwrap();
    let err = reg.visit(a).unwrap_err();
    assert!(
        err.contains("module circular dependency"),
        "should report circular dependency:{}",
        err
    );
}

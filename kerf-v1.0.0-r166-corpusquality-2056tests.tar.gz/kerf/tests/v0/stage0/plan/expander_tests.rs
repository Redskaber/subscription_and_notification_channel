// E6 close-out (r154 / 224-b4): converted to the target-syntax face.
//! Expander integration tests (tests/v0/stage0/plan/expander_tests.rs ↔
//! docs/tests/v0/stage0/plan/expander.md).
//!
//! Coverage: core-form expansions / reachable derivations on the target
//! face (§3.2 table) / hygienic macros / phase separation / expansion
//! depth limit.
//!
//! E6 conversion notes (s-expr-removal-plan §4): the sugar surface whose
//! sole entry was the S-expr skin (letrec / while / the function-body
//! head-define hoisting window) is unreachable from the target Reader —
//! those three derivation tests were deleted and recorded in the r154
//! worklog; every remaining derivation is reached through a target-surface
//! construct the Reader lowers to the same Stx (`&&`/`||` → and/or, the
//! if-else chain → nested if, block-threaded let → core let, `macro`
//! arms → define-syntax/syntax-rules).

use kerf_expander::{expand_program, phase::ModuleRegistry, ExpandCtxt};
use kerf_reader::read_source;
use kerf_syntax::SymbolTable;

fn expand(src: &str) -> Result<String, String> {
    let mut table = SymbolTable::new();
    let forms = read_source(src, 0, &mut table).map_err(|e| e.message)?;
    let mut ctx = ExpandCtxt::new(table);
    let core = expand_program(&forms, &mut ctx).map_err(|e| e.message)?;
    Ok(core
        .iter()
        .map(|e| e.render(&|s| ctx.table.name(s).to_string()))
        .collect::<Vec<_>>()
        .join("\n"))
}

/// Core-form snapshot: let direct mapping (r50-β / D61 — 22 §17.3:
/// multi-binding staging `Let[t0, e1, Let[t1, e2, Let[x, Var(t0),
/// Let[y, Var(t1), b]]]]`; the App[Fn] sugar view is retired).
/// Target face: the multi-binding let statement `let x = 1, y = 2;`
/// lowers to the same multi-binding let Stx (carried inside the IIFE
/// closure the target face uses for expression-position sequencing).
#[test]
fn let_derives_to_lambda_app() {
    let out = expand("(|| { let x = 1, y = 2; x + y })()").unwrap();
    assert!(
        out.contains(
            "(let (let$st0) 1 (let (let$st1) 2 (let (x) let$st0 (let (y) let$st1 (+ x y))))"
        ),
        "multi-binding staging chain must be present: {}",
        out
    );
}

/// cond-family derivation → nested if (§3.2 table row 3). Target face:
/// the else-if chain lowers to the same nested `(if t a b)` Stx the
/// cond macro used to derive — the derivation target is asserted
/// unchanged.
#[test]
fn cond_derives_to_nested_if() {
    assert_eq!(
        expand("if (a) { 1 } else { if (b) { 2 } else { 3 } }").unwrap(),
        "(if a 1 (if b 2 3))"
    );
}

/// and/or derivations (§3.2 table rows 4-5) — reached on the target face
/// through the `&&`/`||` operators (the Reader lowers them to the same
/// `(and a b)`/`(or a b)` Stx the sugar table derives).
/// (The zero-argument `(and)`/`(or)` legs of the S-expr face have no
/// target surface — deleted at E6, recorded in the r154 worklog.)
#[test]
fn and_or_derive() {
    assert_eq!(expand("a && b").unwrap(), "(if a b false)");
    assert_eq!(expand("a || b").unwrap(), "(if a true b)");
    assert_eq!(
        expand("a && b && c").unwrap(),
        "(if (if a b false) c false)"
    );
}

/// Function sugar: `fn f(x: i64) { x }` → the Reader's define-sugar Stx
/// `(define (f x) x)` → `(define f (fn (x) x))`.
#[test]
fn define_function_sugar() {
    assert_eq!(
        expand("fn f(x: i64) { x }").unwrap(),
        "(define f (fn (x) x))"
    );
}

/// Inner define after an expression statement is an error (§19.2 pitfall 3
/// flip side). Target face: `define(y, 2);` in non-head statement position
/// is block-threaded into a `(do ...)` wrap → the define-position
/// rejection (message recalibrated to the E6 face at r154).
#[test]
fn inner_define_after_expression_is_error() {
    let err = expand("fn f(x: i64) { x + 1; define(y, 2); }").unwrap_err();
    assert!(
        err.contains("define is only allowed at the top level or at the head of a function body"),
        "actual: {}",
        err
    );
}

/// Hygienic macros: same names inside and outside a macro do not
/// cross-interfere (§20.1 Week 2 acceptance item).
#[test]
fn hygiene_renames_introduced_identifiers() {
    let out = expand("macro m { (a) => { let tmp = 1; a + tmp } }\nm(x)").unwrap();
    assert!(
        out.contains("tmp$hyg$"),
        "quote input tmp must rename: {}",
        out
    );
    // the user identifier x keeps its original name (not renamed)
    assert!(
        !out.contains("x$hyg$"),
        "user identifiers must not be renamed: {}",
        out
    );
    assert!(
        out.contains(" x "),
        "use user identifier x reserved: {}",
        out
    );
}

/// Macro self-references are not renamed (recursive macro correctness).
#[test]
fn macro_self_reference_preserved() {
    let out = expand("macro loop2 { () => loop2() }").unwrap();
    // define-syntax itself expands to nil; loop2 in the template is not
    // renamed (preserved set)
    assert_eq!(out, "nil");
}

/// Expansion depth limit (§19.2 invariant 1).
#[test]
fn expansion_depth_limit_errors() {
    let mut table = SymbolTable::new();
    let src = "macro l2 { () => l2() }\nl2()";
    let forms = read_source(src, 0, &mut table).unwrap();
    let mut ctx = ExpandCtxt::new(table);
    let err = expand_program(&forms, &mut ctx).unwrap_err();
    assert!(
        err.message.contains("expansion depth"),
        "actual: {}",
        err.message
    );
}

/// Ellipsis macros: zero-or-more matching.
#[test]
fn ellipsis_macro_expands() {
    let out = expand("macro my_list { (x ...) => list(x ...) }\nmy_list(1, 2, 3)").unwrap();
    let last = out.lines().last().unwrap_or("");
    assert!(last.contains("list"), "expand: {}", last);
    assert!(last.contains("1") && last.contains("3"));
}

/// Phase lifecycle: declare → visit → instantiate (§8.9).
#[test]
fn module_phase_lifecycle() {
    let mut reg = ModuleRegistry::new();
    let mut table = SymbolTable::new();
    let m = table.intern("m");
    reg.declare(m, vec![], vec![]).unwrap();
    // instantiate before visit → phase violation
    assert!(reg.instantiate(m).is_err());
    reg.visit(m).unwrap();
    reg.instantiate(m).unwrap();
}

/// quote data-ification. Target face: the quoted pair-list datum has no
/// target-surface literal (r127 honest boundary) — the reachable
/// datum-sequence family is the vector literal `quote([1, 2, 3])` (the
/// D2-b recursive desugar → the vector application).
#[test]
fn quote_list_becomes_pairs() {
    assert_eq!(expand("quote([1, 2, 3])").unwrap(), "(vector 1 2 3)");
}

/// quote symbol values (TD-002 release: symbol datum → symbol literal).
#[test]
fn quote_symbol_becomes_symbol_literal() {
    assert_eq!(expand("quote(sym)").unwrap(), "sym");
    // symbol inside a datum sequence (vector literal — the target face's
    // reachable mixed-datum family)
    assert_eq!(
        expand("quote([a, 1, \"s\"])").unwrap(),
        "(vector a 1 \"s\")"
    );
}

/// quote symbols inside macro templates: hygienic renames ($hyg$N) are
/// stripped at the datum layer — the symbol value's name = the
/// user-visible name (approximating Racket semantics, TD-004 explicit
/// name-base approximation baseline).
#[test]
fn quote_symbol_from_macro_template_strips_hygiene() {
    // the swap macro: the template introduces identifier t; quote(t)'s
    // datum carries the hygiene suffix, which quote data-ification should
    // strip back to t
    let src = "macro m { () => quote(t) }\nm()";
    // the macro definition itself data-ifies to nil (transformer
    // registration is a phase effect); m() expands to (quote t$hyg$N) →
    // datum stripping → symbol literal t
    assert_eq!(expand(src).unwrap(), "nil\nt");
}

/// Module form expansion.
#[test]
fn module_form_snapshot() {
    let out = expand("module m { import a; export f; let f = 1; }").unwrap();
    assert!(out.starts_with("(module m (import a) (export f)"));
}

/// Sugar-derivation positive anchors (01 §5 anchor-table completion —
/// T15-b gap item). E6 face: the when/unless/let* sugar keywords have no
/// target surface, but their **derivation targets** stay assertable
/// through the direct forms the Reader lowers to the same Stx — the
/// if/do/let products below are the derivation outputs of the retired
/// sugar row, byte-identical.
#[test]
fn derived_forms_sugar_expansion_anchors() {
    // let* → nested single-binding let direct mapping (r50-β / D61: let
    // exits the sugar table — sequential let statements go straight to
    // the core direct-mapping Let chain, not an fn application)
    let out = expand("(|| { let a = 1; let b = 2; a + b })()").unwrap();
    assert!(
        out.contains("(let (a) 1"),
        "sequential let outer should direct mapping single binding Let: {}",
        out
    );
    assert!(
        out.contains("(let (b) 2"),
        "sequential let inner nested: {}",
        out
    );
    // when → (if x (do body…) nil) — the do form → Let-chain desugaring
    // (fixed name "do"), rendered = (let (do) 1 2) (name-value-body
    // triple — (do value body) chain shape; the bytecode discard pattern
    // is instruction-by-instruction identical to the original Do
    // sequence — parity golden anchor const_pool_dedup_in_program)
    let when_out = expand("if (x) { do(1, 2) } else { () }").unwrap();
    assert_eq!(when_out, "(if x (let (do) 1 2) nil)");
    // unless → (if x nil (do body…)) — single-element do chain with zero
    // wrapping (tail item returned directly — make_do_let_chain
    // single-element shape: binding unfolds only for multi-element
    // sequences)
    let unless_out = expand("if (x) { () } else { 1 }").unwrap();
    assert_eq!(unless_out, "(if x nil 1)");
}

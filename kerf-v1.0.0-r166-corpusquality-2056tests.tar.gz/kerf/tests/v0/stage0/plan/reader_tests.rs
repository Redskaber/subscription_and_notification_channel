//! Reader integration tests (tests/v0/stage0/plan/reader_tests.rs ↔
//! docs/tests/v0/stage0/plan/reader.md).
//!
//! Coverage: token losslessness / Span precision / lexical classification /
//! error structuring / quote shorthand.

use kerf_reader::{lex_source, read_source};
use kerf_span::Span;
use kerf_syntax::SymbolTable;

/// Token stream snapshot: lossless coverage of `(define (fib n) (+ n 1))`.
#[test]
fn tokens_snapshot_fib() {
    let src = "(define (fib n) (+ n 1))";
    let mut t = SymbolTable::new();
    let toks = lex_source(src, 0, &mut t).unwrap();
    let mut out = String::new();
    for tok in &toks {
        if tok.is_eof() {
            break;
        }
        let name = match &tok.kind {
            kerf_reader::TokenKind::Identifier(s) => t.name(*s).to_string(),
            kerf_reader::TokenKind::Keyword(k) => k.as_str().to_string(),
            kerf_reader::TokenKind::IntLiteral(v) => v.to_string(),
            kerf_reader::TokenKind::Operator(_, s) => t.name(*s).to_string(),
            kerf_reader::TokenKind::Delimiter(d) => d.as_char().to_string(),
            other => format!("{:?}", other),
        };
        out.push_str(&format!("{}:{}..{} ", name, tok.span.start, tok.span.end));
    }
    // golden snapshot (exact per-token spans)
    assert_eq!(
        out.trim(),
        "(:0..1 define:1..7 (:8..9 fib:9..12 n:13..14 ):14..15 (:16..17 +:17..18 n:19..20 1:21..22 ):22..23 ):23..24"
    );
}

/// Span losslessness: the union of token spans exactly covers the input
/// (no gaps, no overlaps — §19.1 invariant 1).
#[test]
fn tokens_cover_input_losslessly() {
    for src in [
        "(+ 1 2)",
        "(define x -5)",
        "\"str\" (quote '(1 2))",
        "; comment\n[1 2 3]",
    ] {
        let mut t = SymbolTable::new();
        let toks = lex_source(src, 0, &mut t).unwrap();
        let mut prev_end = 0;
        for tok in &toks {
            if tok.is_eof() {
                continue;
            }
            assert!(tok.span.start >= prev_end, "span overlap: {:?}", tok.span);
            prev_end = tok.span.end;
        }
        assert!(prev_end <= src.len() as u32, "out-of-bounds overwrite");
    }
}

/// Syntax-object tree snapshot.
#[test]
fn stx_snapshot_nested() {
    let mut t = SymbolTable::new();
    let forms = read_source("(if x 1 (* x 2))", 0, &mut t).unwrap();
    assert_eq!(forms.len(), 1);
    let rendered = forms[0].render(&|s| t.name(s).to_string());
    assert_eq!(rendered, "(if x 1 (* x 2))");
}

/// Quote shorthand expands to (quote x).
#[test]
fn quote_shorthand_snapshot() {
    let mut t = SymbolTable::new();
    let forms = read_source("'(a b)", 0, &mut t).unwrap();
    assert_eq!(forms[0].render(&|s| t.name(s).to_string()), "(quote (a b))");
}

/// Every error carries a full Span (§19.1 invariant 2).
#[test]
fn all_reader_errors_carry_spans() {
    let cases: Vec<(&str, u32, u32)> = vec![
        ("(+ 1", 0, 1),    // unclosed paren → open position
        ("\"abc", 0, 4),   // unclosed string
        ("(+ # 1)", 3, 4), // illegal character
        ("(+ 1 2]", 6, 7), // bracket mismatch → close position
    ];
    for (src, start, end) in cases {
        let mut t = SymbolTable::new();
        let err = read_source(src, 0, &mut t).unwrap_err();
        assert!(
            !err.span.is_empty()
                || (err.span.start == start && err.span.end == end)
                || !err.span.is_empty(),
            "error [{}] position missing: {:?}",
            src,
            err.span
        );
        assert_eq!(err.span.file_id, 0);
    }
}

/// Greedy number rejection: `123abc` errors (§19.1 pitfall 4).
#[test]
fn greedy_number_rejected_snapshot() {
    let mut t = SymbolTable::new();
    let err = lex_source("123abc", 0, &mut t).unwrap_err();
    assert!(
        err.message
            .contains("identifier characters immediately after"),
        "actual: {}",
        err.message
    );
}

/// Comments are fully skipped (line comments + nested block comments).
#[test]
fn comments_fully_skipped() {
    let mut t = SymbolTable::new();
    let toks = lex_source("; a\n#| b #| c |# d |# 42", 0, &mut t).unwrap();
    let non_eof: Vec<_> = toks.iter().filter(|t| !t.is_eof()).collect();
    assert_eq!(non_eof.len(), 1);
    assert!(matches!(
        non_eof[0].kind,
        kerf_reader::TokenKind::IntLiteral(42)
    ));
}

/// Unicode identifiers (XID subset).
#[test]
fn unicode_identifier() {
    let mut t = SymbolTable::new();
    let toks = lex_source("(definition π 3)", 0, &mut t).unwrap();
    let non_eof: Vec<_> = toks.iter().filter(|t| !t.is_eof()).collect();
    assert_eq!(non_eof.len(), 5); // ( <identifier> π 3 )
    assert!(matches!(
        non_eof[2].kind,
        kerf_reader::TokenKind::Identifier(_)
    ));
}

/// Empty program.
#[test]
fn empty_program_reads_to_nothing() {
    let mut t = SymbolTable::new();
    let forms = read_source("; only comments\n", 0, &mut t).unwrap();
    assert!(forms.is_empty());
}

/// Span merging (syntax-object level).
#[test]
fn list_span_merges_children() {
    let src = "(do 1)";
    let mut t = SymbolTable::new();
    let forms = read_source(src, 0, &mut t).unwrap();
    assert_eq!(forms[0].span, Span::new(0, 0, src.len() as u32));
}

// E6 close-out (r154 / 224-b2): corpus converted to the target-syntax face.
//! VM integration tests (tests/v0/stage0/plan/vm_tests.rs ↔
//! docs/tests/v0/stage0/plan/vm.md).
//!
//! Coverage: execution semantics of the 9 core primitives (§21.3 Stage 0
//! acceptance item 1) / fib(25) / runtime errors with stack traces /
//! dual-path cross-checking.
//!
//! E6 skin notes (E6-CG §2): quoted-list datums have no target-surface
//! literal (r127 honest boundary) — list data is built at runtime via
//! `list(...)`/`cons(...)` applications; symbol datums keep the
//! `quote(sym)` single-datum form.

use crate::common;

use common::{assert_int, dual_path_agrees};

/// Per-primitive semantic verification of the 9 primitives: Literal / Var /
/// Fn / Apply / If / Assign / Define / Do / Module.
#[test]
fn nine_primitives_semantics() {
    // Literal
    assert_int("42", 42);
    assert_int("\"str\"; 1", 1); // string value + trailing expression
    assert_int("(); 7", 7); // unit value + trailing expression
                            // Var / Define
    assert_int("let x = 99; x", 99);
    // Fn / Apply (immediately-invoked closures — the target lambda face)
    assert_int("(||(x: i64) { x })(42)", 42);
    assert_int("(||(x: i64, y: i64) { x - y })(10, 4)", 6);
    // If (true/false)
    assert_int("if (true) { 1 } else { 2 }", 1);
    assert_int("if (false) { 1 } else { 2 }", 2);
    // Assign
    assert_int("let n = 1; n = 5; n", 5);
    // Do
    assert_int("do(1, 2, 3)", 3);
    // Module
    assert_int("module m { let x = 8; x }", 8);
}

/// fib(25) executes correctly on the VM (§20.1 Week 3 acceptance).
#[test]
fn fib_25_correct_on_vm() {
    let src = "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } } fib(25)";
    common::assert_int(src, 75025);
}

/// Recursion depth 10_000: iterative loops are not bound by the Rust stack.
#[test]
fn deep_recursion_10k() {
    let src = "fn count(n: i64) { if (n == 0) { 0 } else { count(n - 1) } } count(10000)";
    common::assert_int(src, 0);
}

/// Lexical closures: shared mutable captures (counter independence).
#[test]
fn closures_share_mutable_captures() {
    let src = r#"
        fn make_counter() {
            let n = 0;
            || { n = n + 1; n }
        }
        let a = make_counter();
        let b = make_counter();
        a(); a(); a();
        b();
        list(a(), b())
    "#;
    assert_eq!(common::run_rendered(src), "(4 2)");
}

/// Higher-order functions: map via explicit recursion.
#[test]
fn higher_order_functions() {
    let src = r#"
        fn map(f: T, lst: T) {
            if (is_nil(lst)) { () } else { cons(f(head(lst)), map(f, tail(lst))) }
        }
        map(|| (x: i64) { x * x }, list(1, 2, 3, 4, 5))
    "#;
    assert_eq!(common::run_rendered(src), "(1 4 9 16 25)");
}

/// Explicit truthiness semantics: non-bool conditions error (§19.5 pitfall 3).
#[test]
fn truthy_requires_bool() {
    let err = common::run("if (1) { 2 } else { 3 }").unwrap_err();
    assert!(err.contains("truthy") || err.contains("bool"));
}

/// Runtime error captures include a stack trace (§8.12).
#[test]
fn runtime_error_has_trace() {
    let src = "fn inner() { head(5) } fn outer() { inner() } outer()";
    let err = common::run(src).unwrap_err();
    assert!(err.contains("head") || err.contains("pair"));
}

/// Unbound variable error.
#[test]
fn unbound_variable_error() {
    let err = common::run("undefined_fn(1)").unwrap_err();
    assert!(err.contains("unbound"));
}

/// Division-by-zero error.
#[test]
fn division_by_zero_error() {
    let err = common::run("1 / 0").unwrap_err();
    assert!(err.contains("division by zero"));
}

/// Argument count mismatch.
#[test]
fn arity_mismatch_error() {
    let err = common::run("fn f(x: i64) { x } f(1, 2)").unwrap_err();
    assert!(err.contains("argument count"));
}

/// Dual-path cross-check: VM and eval agree on the core program set
/// (§21.8 Phase 1).
#[test]
fn dual_execution_paths_cross_validate() {
    let programs = [
        "1 + 2 + 3",
        "fn f(x: i64) -> i64 { x + 1 } f(41)",
        "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } } fib(12)",
        "(|| { let x = 1; let y = 2; x + y })()",
        // letrec mutual recursion → top-level mutually-recursive fns
        "fn is_even(n: i64) -> bool { if (n == 0) { true } else { is_odd(n - 1) } } \
          fn is_odd(n: i64) -> bool { if (n == 0) { false } else { is_even(n - 1) } } is_even(10)",
        // cond → if-else chain
        "if (1 < 0) { 1 } else { if (1 > 0) { 2 } else { 3 } }",
        "fn make_counter() { let n = 0; || { n = n + 1; n } } \
          let c = make_counter(); c(); c(); c()",
        "head(list(1, 2, 3))",
        "(||(x: i64, y: i64) { cons(x, y) })(1, 2)",
    ];
    for src in programs {
        assert!(dual_path_agrees(src), "dual-path result mismatch: {}", src);
    }
}

/// quote data operations: pair construction and traversal (list data built
/// at runtime — the r127 honest boundary: no quoted-list literal on the
/// target face).
#[test]
fn pair_construction_and_traversal() {
    assert_eq!(common::run_rendered("cons(1, 2)"), "(1 . 2)");
    assert_eq!(common::run_rendered("list(1, 2, 3)"), "(1 2 3)");
    assert_eq!(common::run_rendered("tail(list(1, 2, 3))"), "(2 3)");
    assert_eq!(common::run_rendered("head(tail(list(1, 2, 3)))"), "2");
    assert_eq!(common::run_rendered("is_nil(list())"), "true");
}

/// T1 reconciliation ([06-operational-semantics §2 R6/D1]): Define's
/// return value is the defined value — both paths must agree (before the
/// fix the VM returned nil, eval returned v).
#[test]
fn define_returns_value_dual_path() {
    assert!(dual_path_agrees("let x = 5;"));
    assert!(dual_path_agrees("let x = 2 + 3; x"));
    assert_int("let x = 5;", 5); // D1: the value of a Define expression = v
}

/// E6 ([06-operational-semantics §3]): same-layer duplicate definition
/// errors — dual-path agreement (before the fix eval silently overwrote,
/// VM silently overwrote).
#[test]
fn duplicate_define_errors_dual_path() {
    let src = "let x = 1; let x = 2;";
    let err = common::run(src).unwrap_err();
    assert!(
        err.contains("duplicate variable definition"),
        "VM path should report E6: {}",
        err
    );
    // seed chain (reference path — T1 new baseline 42-d)
    let ev = kerf_driver::run_source_seed(src, "test.ktf").err().unwrap();
    assert!(
        ev.to_string().contains("duplicate variable definition"),
        "seed chain should report E6"
    );
    assert!(dual_path_agrees(src)); // error-message shape agreement (rendering-layer reconciliation)
}

/// E3 ([06-operational-semantics §2 R5/S1]): assigning an unbound variable
/// errors on the VM path too (before the fix the VM silently created a
/// global — diverging from eval, violating T1).
#[test]
fn set_unbound_errors_on_vm() {
    // r46 / D49: unbound assignment targets moved to compile time (E0022);
    // the VM runtime check is kept as defense in depth (non-front path)
    let err = common::run("y = 1;").unwrap_err();
    assert!(
        err.contains("unbound reference"),
        "should report E0022: {}",
        err
    );
    assert!(dual_path_agrees("y = 1;"));
    // positive case: bound (define first, then assign) succeeds on both paths
    assert!(dual_path_agrees("let n = 1; n = 5; n"));
}

/// A3 guard ([06-operational-semantics §2]): duplicate fn parameter names
/// rejected at expansion time (single-point defense upstream of both
/// execution paths).
#[test]
fn lambda_duplicate_params_rejected_at_expand() {
    let err = common::run("||(x: i64, x: i64) { x }").unwrap_err();
    assert!(
        err.contains("duplicate argument names"),
        "expand phase should reject duplicate formal parameter: {}",
        err
    );
}

/// T1 reconciliation ([06-operational-semantics §1.3/§2 A1]): Apply
/// evaluation order = function first, arguments left-to-right.
/// Error-ordering scenario: (undefined_a)(undefined_b) must report the
/// unbound name at the fn position on both paths (span pointing at
/// undefined_a), not the argument position (before the fix the VM evaluated
/// arguments first and would report undefined-b — the T1 theorem
/// counterexample face).
#[test]
fn app_evaluation_order_fn_first_dual_path() {
    let src = "undefined_a(undefined_b)";
    // "undefined_a" is at source 0..11; "undefined_b" is at 12..24
    let fn_pos = 0u32;
    let arg_pos = 12u32;
    // VM path (production path)
    let vm_err = kerf_driver::run_source(src, "test.ktf").expect_err("VM path should report wrong");
    assert!(
        vm_err.diagnostic.primary_span.start >= fn_pos
            && vm_err.diagnostic.primary_span.start < arg_pos,
        "VM path should report fn positional unbound(actual span.start={}): {}",
        vm_err.diagnostic.primary_span.start,
        vm_err.rendered
    );
    // seed chain (reference path — T1 new baseline 42-d: eval retired, the
    // seed chain is the cross-check oracle)
    let ev_err = kerf_driver::run_source_seed(src, "test.ktf")
        .expect_err("seed chain should report an error");
    assert!(
        ev_err.diagnostic.primary_span.start >= fn_pos
            && ev_err.diagnostic.primary_span.start < arg_pos,
        "seed chain should report fn positional unbound(actual span.start={}): {}",
        ev_err.diagnostic.primary_span.start,
        ev_err.rendered
    );
    // r46 / D49: unbound references moved to compile time — both sides are
    // Compile-stage E0022 carriers (span attribution keeps fn-position
    // priority [find_var_span tree-order DFS — the compile-time mirror of
    // Apply fn_expr before args])
    assert!(vm_err.rendered.contains("E0022"));
    assert!(ev_err.rendered.contains("E0022"));
    // positive case: function-first evaluation does not change results of
    // correct programs
    assert!(dual_path_agrees("(||(x: i64) { x * x })(6)"));
    assert!(dual_path_agrees("fn f(a: i64, b: i64) { a + b } f(1, 2)"));
}

// ---------------------------------------------------------------------------
// TD-002 symbol values (quote symbol datum → Value::Symbol): VM semantics
// + dual path
// ---------------------------------------------------------------------------

/// Symbol value basics: quote symbol / symbol lists / mixed lists / eq by
/// name equality. (The `'x` sugar collapses to the single `quote(x)`
/// surface on the target face; list data is runtime-constructed.)
#[test]
fn quote_symbol_value_semantics() {
    assert_eq!(common::run_rendered("quote(sym)"), "sym");
    assert_eq!(common::run_rendered("quote(sym)"), "sym"); // 'sym → same single quote surface
                                                           // symbol list (symbols in heap pairs — HeapObj::Symbol slot shape)
    assert_eq!(
        common::run_rendered("list(quote(a), quote(b), quote(c))"),
        "(a b c)"
    );
    // mixed datum list (VM rendering layer: Str without quotes —
    // render_value semantics)
    assert_eq!(common::run_rendered("list(quote(a), 1, \"s\")"), "(a 1 s)");
    // eq by name equality (value semantics)
    assert_eq!(common::run_rendered("eq(quote(a), quote(a))"), "true");
    assert_eq!(common::run_rendered("eq(quote(a), quote(b))"), "false");
    // symbol ≠ string (strict typing)
    assert_eq!(common::run_rendered("eq(quote(a), \"a\")"), "false");
}

/// Symbol value construction paths: cons/list builtins boxing symbols +
/// head extraction.
#[test]
fn symbol_construction_and_extraction() {
    assert_eq!(
        common::run_rendered("cons(quote(a), list(quote(b)))"),
        "(a b)"
    );
    assert_eq!(common::run_rendered("list(quote(a), quote(b))"), "(a b)");
    // head extracts the symbol (heap slot → Value::Symbol round trip)
    assert_eq!(common::run_rendered("head(list(quote(a), quote(b)))"), "a");
    assert_eq!(
        common::run_rendered("head(tail(list(quote(a), quote(b))))"),
        "b"
    );
}

/// Symbol values agree across both paths (T1: VM and eval render
/// equivalently — TD-002 touchpoint dual-path coverage).
#[test]
fn quote_symbol_dual_path_agreement() {
    assert!(dual_path_agrees("quote(sym)"));
    assert!(dual_path_agrees("list(quote(a), quote(b), quote(c))"));
    assert!(dual_path_agrees("eq(quote(a), quote(a))"));
    assert!(dual_path_agrees("cons(quote(x), list(quote(y)))"));
    assert!(dual_path_agrees("head(list(quote(a), quote(b)))"));
}

// E6 close-out (r154 / 224-b4): converted to the target-syntax face.
//! Architecture compliance audit tests (v6.0 — test landing of the
//! lang-design [01 §8.5](../../../docs/lang-design/01-core-forms.md) /
//! [02 §8.1](../../../docs/lang-design/02-syntax-model.md) /
//! [15 §5.3](../../../docs/lang-design/15-architecture-layers.md) anchors;
//! architecture shape audit of sop §2.2 principles 29-31).
//!
//! Audit targets (the "architecture shape" face of the three principles —
//! naming itself is frozen, see the 01 §8.2 ruling):
//! - **Principle 30 (type safety over naming safety)**: `CoreExpr` is a
//!   compiler-private ADT — the variant set is frozen (exhaustive match =
//!   compile-time proof of exactly ten variants; adding a variant fails
//!   compilation), every variant carries its own Span (metadata separate
//!   from naming: `kind_name` is for diagnostic rendering only), and field
//!   shapes are anchored per-field via construction (no type/effect/
//!   capability annotation fields — the syntactic-layer purity of the four
//!   orthogonal layers, 15 §5.1 Layer 1).
//! - **Principle 31 (strict surface/internal syntax separation)**: the
//!   Reader produces `Stx`, never `CoreExpr` (type-level assertion); the
//!   Expander is the sole `Stx → CoreExpr` bridge (proof that translation
//!   happens — surface syntax details cannot bypass into core forms); the
//!   same source compiled twice yields byte-identical core forms
//!   (determinism baseline of the sole target-syntax Reader face —
//!   kerf-reader target.rs is the one Rust Reader since the E6 close-out,
//!   02 §8.1).

use std::rc::Rc;

use kerf_core::{Capability, CoreExpr, LiteralValue, ModuleItem};
use kerf_driver::compile_source;
use kerf_expander::{expand_program, ExpandCtxt};
use kerf_reader::read_source;
use kerf_syntax::ScopeSet;
use kerf_syntax::{Keyword, Stx, Symbol, SymbolTable};

// ---------------------------------------------------------------------------
// Principle 30: private ADT freeze + Span metadata independence
// (01 §8.5 anchor 1)
// ---------------------------------------------------------------------------

/// Exhaustive match over the ten variants (compile-time proof the variant
/// set is frozen) + per-variant field-shape anchoring (integration-face
/// reinforcement of the existing 01 §5 anchors) + `span()`/`kind_name()`
/// passing for every variant (metadata separate from naming — Span
/// carried independently, `kind_name` for diagnostic rendering only).
/// One instance constructed per twelve variants (shared construction face:
/// reused by the freeze test and the five-face same-lexeme test).
fn frozen_instances(sp: kerf_span::Span) -> Vec<CoreExpr> {
    let s0 = Symbol(0);
    let lit = CoreExpr::Literal {
        value: LiteralValue::Int(7),
        span: sp,
    };
    vec![
        CoreExpr::Fn {
            params: vec![s0],
            param_scopes: vec![kerf_syntax::ScopeSet::new()],
            rest: None,
            body: Rc::new(lit.clone()),
            span: sp,
        },
        CoreExpr::Apply {
            fn_expr: Rc::new(lit.clone()),
            args: vec![],
            span: sp,
        },
        CoreExpr::If {
            cond: Rc::new(lit.clone()),
            then_branch: Rc::new(lit.clone()),
            else_branch: Rc::new(lit.clone()),
            span: sp,
        },
        CoreExpr::Var {
            name: s0,
            scopes: kerf_syntax::ScopeSet::new(),
            span: sp,
        },
        lit,
        CoreExpr::Assign {
            name: s0,
            scopes: kerf_syntax::ScopeSet::new(),
            value: Rc::new(CoreExpr::Var {
                name: s0,
                scopes: kerf_syntax::ScopeSet::new(),
                span: sp,
            }),
            span: sp,
        },
        // r49 D59: Define/Module/Require lifted to the ModuleItem
        // declaration layer — the expression ADT has 9 variants (item-level
        // instances in item_frozen_instances)
        CoreExpr::Let {
            name: s0,
            scopes: kerf_syntax::ScopeSet::new(),
            value: Rc::new(CoreExpr::Literal {
                value: LiteralValue::Nil,
                span: sp,
            }),
            body: Rc::new(CoreExpr::Literal {
                value: LiteralValue::Nil,
                span: sp,
            }),
            span: sp,
        },
        // r49 D59: Module/Require lifted to the declaration layer (see
        // item_frozen_instances)
        // r25/42-f: the two effect primitives (primitive set 9→11 —
        // effect-language-design §2.1/W1 write-back; frozen in sync with
        // the Perform/Handle variants)
        CoreExpr::Perform {
            effect: Rc::new(CoreExpr::Literal {
                value: LiteralValue::Int(1),
                span: sp,
            }),
            span: sp,
        },
        CoreExpr::Handle {
            tag: Rc::from("tag"),
            payload_var: Symbol(1),
            payload_scopes: ScopeSet::new(),
            resume_var: Symbol(2),
            resume_scopes: ScopeSet::new(),
            handler_body: Rc::new(CoreExpr::Literal {
                value: LiteralValue::Nil,
                span: sp,
            }),
            body: Rc::new(CoreExpr::Literal {
                value: LiteralValue::Nil,
                span: sp,
            }),
            span: sp,
        },
        // r136 / 206-b (TD-033 — handle-multi-arm-design.md §8 D13): the
        // group-install carrier — Handle's multi-arm form (NOT a new
        // semantic primitive: the same effect-handle primitive,
        // group-installed; the 8-primitive invariance is unaffected —
        // the ADT variant count grows by the committee-sanctioned
        // mechanism-change window)
        CoreExpr::HandleGroup {
            arms: vec![
                kerf_core::HandleArm {
                    tag: Rc::from("tagA"),
                    payload_var: Symbol(3),
                    payload_scopes: ScopeSet::new(),
                    resume_var: Symbol(4),
                    resume_scopes: ScopeSet::new(),
                    handler_body: Rc::new(CoreExpr::Literal {
                        value: LiteralValue::Nil,
                        span: sp,
                    }),
                },
                kerf_core::HandleArm {
                    tag: Rc::from("tagB"),
                    payload_var: Symbol(5),
                    payload_scopes: ScopeSet::new(),
                    resume_var: Symbol(6),
                    resume_scopes: ScopeSet::new(),
                    handler_body: Rc::new(CoreExpr::Literal {
                        value: LiteralValue::Nil,
                        span: sp,
                    }),
                },
            ],
            body: Rc::new(CoreExpr::Literal {
                value: LiteralValue::Nil,
                span: sp,
            }),
            span: sp,
        },
    ]
}

/// Exhaustive match over the twelve variants (compile-time proof the
/// variant set is frozen) + per-variant field-shape anchoring
/// (integration-face reinforcement of the existing 01 §5 anchors) +
/// `span()`/`kind_name()` passing for every variant (metadata separate
/// from naming — Span carried independently, `kind_name` for diagnostic
/// rendering only).
#[test]
fn core_expr_variant_set_frozen_exhaustive() {
    let sp = kerf_span::Span::dummy();
    let instances = frozen_instances(sp);

    let prove_frozen = |e: &CoreExpr| -> &'static str {
        match e {
            CoreExpr::Fn { .. } => "fn",
            CoreExpr::Apply { .. } => "apply",
            CoreExpr::If { .. } => "if",
            CoreExpr::Var { .. } => "var",
            CoreExpr::Literal { .. } => "literal",
            CoreExpr::Assign { .. } => "assign",
            CoreExpr::Let { .. } => "let",
            CoreExpr::Perform { .. } => "perform",
            CoreExpr::Handle { .. } => "handle",
            CoreExpr::HandleGroup { .. } => "handle-group",
        }
    };
    let names: Vec<&'static str> = instances.iter().map(prove_frozen).collect();

    // kind_name is pairwise distinct across all variants (full mapping on
    // the diagnostic rendering face + zero collisions).
    let mut sorted = names.clone();
    sorted.sort_unstable();
    sorted.dedup();
    assert_eq!(
        sorted.len(),
        names.len(),
        "kind_name all variants pairwise distinct"
    );
    assert_eq!(
        names.len(),
        10,
        "frozen change body set = 10 load body(r49 D59 declaration layer arm: Define/Module/Require above move ModuleItem -- expression ADT clean ize; r136 D13: HandleGroup enters the set -- Handle primitive many arm group installation load body non-new semantics primitive, semantics primitive count unchanged -- TD-033 committee sanctioned machine make change window)"
    );
    for (e, n) in instances.iter().zip(&names) {
        assert_eq!(e.kind_name(), *n);
        // Span carried independently: retrievable for every variant and
        // consistent with the constructed value (metadata does not depend
        // on naming conventions — the "Span system carries metadata
        // independently" face of principle 30).
        assert_eq!(e.span(), sp);
    }
}

// ---------------------------------------------------------------------------
// r44 / E5 S3 M-R name-face arm: five faces, same lexeme (22 §13
// D34/D37 — diagnostic face ↔ keyword registry face penetration
// assertion)
// ---------------------------------------------------------------------------

/// Five-face same-lexeme penetration (machine assertion of 22 §13 D34
/// "one semantics, one name"):
/// - primitive-level keyword variants (9 names): `kind_name` must be a
///   **registered keyword** and identical to `Keyword::as_str` (diagnostic
///   face = keyword face = surface = bridge tag = rendering);
/// - internal-name variants (apply/var/literal, 3 names): `kind_name`
///   **must not** be a keyword (semantics without a surface keyword — the
///   internal-name independent domain, which does not erode the E0020
///   whole-domain exclusivity face).
#[test]
fn s3mr_kind_name_keyword_face_penetration() {
    let instances = frozen_instances(kerf_span::Span::dummy());
    // primitive-level keyword face (10 names): kind_name ∈ Keyword registry
    // face (same-name penetration).
    // r49 D59: define/module/require belong to ModuleItem::kind_name
    // (item-level penetration assertions in module_item_kind_keyword_face)
    // — 7 primitive-level keywords in the expression domain (r136 D13:
    // handle-group joins — Handle's group-install carrier, same lexeme on
    // all five faces)
    let primitive_keywords = [
        "fn",
        "if",
        "assign",
        "let",
        "perform",
        "handle",
        "handle-group",
    ];
    // internal-name face (3 names): no surface keyword counterpart — an
    // independent internal-name domain sharing names across the three
    // faces (bridge/ADT/diagnostic).
    let internal_names = ["apply", "var", "literal"];
    let mut seen = 0;
    for e in &instances {
        let n = e.kind_name();
        if primitive_keywords.contains(&n) {
            assert!(
                Keyword::from_name(n).is_some(),
                "primitive level kind_name `{}` must be registration keyword(five face same word root)",
                n
            );
            seen += 1;
        } else if internal_names.contains(&n) {
            assert!(
                Keyword::from_name(n).is_none(),
                "internal name `{}` must not occupy keyword face(internal name independent domain)",
                n
            );
        } else {
            panic!("unclassified kind_name `{}`(10 name table invalidated)", n);
        }
    }
    assert_eq!(
        seen, 7,
        "primitive level keyword change body exactly 7 name (7+3 = 10 name table; r136 D13: handle-group input primitive level character face)"
    );
    assert_eq!(
        instances.len(),
        10,
        "10 name table count anchor(r49 D59 -- declaration three name converge ModuleItem item face; r136 D13 -- handle-group enters the set)"
    );
}

// ---------------------------------------------------------------------------
// Principle 31: strict surface/internal syntax separation (02 §8.1
// anchors 1/3)
// ---------------------------------------------------------------------------

/// The Reader produces `Stx` (type-level assertion) — surface-syntax
/// parsing stops at the syntax-object layer; `CoreExpr` can only be
/// produced via the Expander bridge (no bypass). E6 face: the sole
/// Reader is kerf-reader target.rs (the target-syntax face — the
/// classic S-expr Reader was deleted at the E6 close-out r154).
#[test]
fn reader_emits_stx_not_core_expr() {
    let mut interner = SymbolTable::new();
    // the type is the assertion: read_source's output type is
    // Vec<Stx> — this binding fails to compile if it mismatches the
    // internal AST type (type-level isolation of Reader from CoreExpr).
    let forms: Result<Vec<Stx>, _> = read_source("do(1, 2)", 0, &mut interner);
    let forms = forms.expect("Reader produce syntax object");
    assert!(
        !forms.is_empty(),
        "target face syntax via Reader reduces to Stx"
    );
}

/// The Expander is the sole `Stx → CoreExpr` bridge and **translation
/// really happens**: the literal `42` becomes `CoreExpr::Literal` (internal
/// shape) after expansion, not a verbatim pass-through of the syntax object
/// (zero leakage of surface syntax details — the "mapping" face of the
/// near-identity desugaring).
#[test]
fn expander_is_sole_stx_to_core_bridge() {
    let mut interner = SymbolTable::new();
    let forms = read_source("42", 0, &mut interner).expect("read");
    let mut ctx = ExpandCtxt::new(interner);
    let core = expand_program(&forms, &mut ctx).expect("expand");
    // assert the translation product is the internal ADT shape (not a Stx
    // pass-through).
    let first = core
        .first()
        .expect("single form program produce single item");
    assert!(
        matches!(first, ModuleItem::Expr(e) if matches!(e.as_ref(), CoreExpr::Literal { .. })),
        "42 via Expander translation is ModuleItem::Expr(CoreExpr::Literal) -- translation occur and non-pass-through"
    );
}

/// The same source compiled twice yields byte-identical core forms
/// (`render_core` identity) — the determinism baseline of the sole
/// target-syntax Reader face (kerf-reader target.rs — the classic
/// S-expr twin was deleted at the E6 close-out r154; the Stage 0
/// precondition of 02 §8.1 anchor 2 now guards the one-and-only
/// surface's compile determinism).
#[test]
fn same_surface_source_compiles_to_identical_core() {
    // M2 (r40) compositional closure (21 §4.4): require lifted to program
    // top level — require inside a module body = demand metadata, not
    // granted acquisition (the sole source of grant = entry top-level
    // declaration)
    let src = "require io, write;\nmodule m { export main; fn main() { print(1); 42 } }\n";
    let a = compile_source(src, "a.ktf").expect("compile a");
    let b = compile_source(src, "b.ktf").expect("compile b");
    assert_eq!(
        a.render_core(),
        b.render_core(),
        "the same target face syntax → identical internal core form(determinism bridge accept)"
    );
}

// ---------------------------------------------------------------------------
// r49 / E5 S3 declaration-layer arm (22 §17 D59): ModuleItem item-face
// audit — declaration three-name keyword penetration + item-level
// exhaustiveness + kind_name distinctness
// ---------------------------------------------------------------------------

/// Declaration-layer item instances (four kinds — Define/Require/Module/
/// Expr).
fn item_frozen_instances(sp: kerf_span::Span) -> Vec<kerf_core::ModuleItem> {
    let s0 = Symbol(0);
    vec![
        kerf_core::ModuleItem::Define {
            name: s0,
            value: Rc::new(CoreExpr::Var {
                name: s0,
                scopes: kerf_syntax::ScopeSet::new(),
                span: sp,
            }),
            span: sp,
        },
        kerf_core::ModuleItem::Require {
            caps: vec![Capability::IoRead],
            span: sp,
        },
        kerf_core::ModuleItem::Module {
            name: s0,
            imports: vec![],
            exports: vec![],
            items: vec![],
            span: sp,
        },
        kerf_core::ModuleItem::Expr(Rc::new(CoreExpr::Literal {
            value: LiteralValue::Nil,
            span: sp,
        })),
    ]
}

/// Item-name exhaustiveness (compile-time proof the item set is frozen) +
/// kind_name pairwise distinct across items + the declaration three names
/// ∈ the Keyword registry face (item-level five-face same lexeme —
/// 22 §17 D59).
#[test]
fn module_item_kind_keyword_face() {
    let sp = kerf_span::Span::dummy();
    let items = item_frozen_instances(sp);
    let prove = |item: &kerf_core::ModuleItem| -> &'static str {
        match item {
            kerf_core::ModuleItem::Define { .. } => "define",
            kerf_core::ModuleItem::Require { .. } => "require",
            kerf_core::ModuleItem::Module { .. } => "module",
            kerf_core::ModuleItem::Expr(_) => "literal",
        }
    };
    let names: Vec<&'static str> = items.iter().map(prove).collect();
    let mut sorted = names.clone();
    sorted.sort_unstable();
    sorted.dedup();
    assert_eq!(
        sorted.len(),
        names.len(),
        "item kind_name pairwise distinct"
    );
    assert_eq!(
        names.len(),
        4,
        "declaration layer item set = four kind(D59)"
    );
    for (item, n) in items.iter().zip(&names) {
        assert_eq!(item.kind_name(), *n);
        assert_eq!(item.span(), sp);
    }
    // declaration three names ∈ Keyword registry face (keyword penetration
    // — same lexeme as the surface keywords)
    for kw in ["define", "require", "module"] {
        assert!(
            Keyword::from_name(kw).is_some(),
            "item level name `{kw}` must is registration keyword"
        );
    }
}

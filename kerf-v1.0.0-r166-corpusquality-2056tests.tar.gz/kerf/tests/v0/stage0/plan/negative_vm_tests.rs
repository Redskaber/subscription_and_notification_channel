// E6 close-out (r154 / 224-b2): corpus converted to the target-syntax face.
//! Negative VM tests (tests/v0/stage0/plan/negative_vm_tests.rs ↔
//! docs/tests/v0/stage0/plan/negative-tests.md).
//!
//! §9.4.3 directed expansion: this file covers the **Run stage (E0004)**
//! negative-test table for the 24-builtin system (arity × type rules ×
//! left/right position) + call/evaluation errors + dual-path agreement
//! negative cases. Each row/iteration = 1 case (table- and matrix-driven).
//!
//! All expected messages are cross-checked against the builtins.rs source
//! and calibrated by actual runs (no speculation allowed). Builtin names
//! are written snake_case on the target face; the runtime messages keep
//! the registered kebab form ("is-nil", "string-append", "read-line" —
//! the `-` ↔ `_` Reader symbol-introduction mapping).
//!
//! E6 conversion notes (E6-CG §2 error-face mapping):
//! - the infix operators (+ - * / < > <= >= ==) are non-callable on the
//!   target grammar — bare/under-arity operator applications ((+) / (-) /
//!   (/ 5) / (< 1) …) and the identity-element faces ((+)→0, (*)→1) are
//!   unrepresentable → 9 case rows deleted (see arithmetic_arity_floor /
//!   comparison_arity_floor);
//! - the S-expr chained-comparison faces ((< a b c) …) reduce to their
//!   binary infix forms (non-chaining comparison grammar) — the
//!   mixed-type intrusion negative is preserved in binary form;
//! - i64::MIN literals are unrepresentable on the target lexer (digit-run
//!   overflow) — the overflow carriers compute the value at runtime
//!   (-9223372036854775807 - 1).
//!
//! Semantic boundaries (verified by measurement, not negative cases):
//! - numeric-tower mixing `1 < 2.0` is legal (Int/Float compared via
//!   as_number);
//! - `1 == 1.0` is legal (numeric-tower equality); `"a" == "b"` is legal
//!   (string equality); `"a" < "b"` is legal (TD-011 r24: string total
//!   order by code point — positive anchor in stdlib_tests; this file's
//!   negative face = mixed-type rejection);
//! - `1 / 0.0` is legal (IEEE754 → inf; only integer division by zero
//!   errors with E5);
//! - `list()` is variadic (zero args → empty list, no arity error);
//! - chained comparisons pre-check all operands (TD-016 batch C tightened
//!   semantics, 09-stdlib §2 v5.5) — the S-expr chain face; the target
//!   binary face reports the same `{op} requires a number` message on
//!   mixed-type operands. The static-checking face (kerf check) converged
//!   in sync — typecheck_tests R3.
//! - `read_line` validates arity exactly (0 actuals — the FS-4 fix; the
//!   r144 / 214-c static signature entry mirrors the runtime contract on
//!   the check face while this runtime layer stays the E0004 fail-closed
//!   bottom).
//!
//! Dual-path message face (after the TD-018 r24 unification):
//! - if non-boolean: VM and eval share the same text "if condition requires
//!   bool, got …" (messages.rs single source);
//! - unbound variable: VM "unbound global variable (…)" vs eval "unbound
//!   variable" — retained (stage-information difference: the VM side
//!   carries global-fallback resolution completeness);
//! - lifted expression errors: eval wraps an extra "evaluation failed:"
//!   prefix (archived reference face).
//!
//! Fixed defects (formerly archived #[ignore], activated after the D3/D4
//! fixes):
//! - `mod(i64::MIN, -1)`: checked_rem structured error
//!   (`mod_i64_min_structured_error`);
//! - deep recursion on the eval path: MAX_EVAL_DEPTH=4096 structured error
//!   (`deep_recursion_eval_path_structured_error`).
//!
//! Known boundaries (verified by measurement, #[ignore], none counted):
//! - none — the historical `read_line_arity_ignored` boundary was resolved
//!   by the FS-4 fix (arity enforced; see `read_line_arity` below) and the
//!   stale module-doc claim was corrected in r144 / 214-c (R4: docs follow
//!   the code).

use crate::common;

use kerf_driver::{run_source, Stage};
use kerf_vm::Value;

/// Generic assertion: src fails at the Run stage and the rendered error
/// contains the message substring.
fn expect_run_err(src: &str, msg: &str) -> kerf_driver::DriverError {
    let err = match run_source(src, "neg.ktf") {
        Ok(_) => panic!("expected an error, got Ok: {}", src),
        Err(e) => e,
    };
    assert_eq!(
        err.stage,
        Stage::Run,
        "stage mismatch:{}\n{}",
        src,
        err.rendered
    );
    assert!(
        err.rendered.contains(msg),
        "message missing `{}`: {}\n complete error: {}",
        msg,
        src,
        err.rendered
    );
    err
}

// ---------------------------------------------------------------------------
// Arithmetic (+ - * / mod): type rules × arity × division by zero × overflow
// ---------------------------------------------------------------------------

/// Non-numeric operands ×5 operators × left/right position ×6 types
/// (60 cases, integer path). Message shape: `{op} requires int` (the
/// builtins.rs integer-path as_int message validates each actual).
/// (+ - * / are infix faces; mod keeps the call face.)
#[test]
fn arithmetic_non_numeric_operands() {
    let infix_ops = ["+", "-", "*", "/"];
    let bad = [
        "\"s\"",
        "true",
        "()",
        "cons(1, 2)",
        "|| (x: i64) { x }",
        "head",
    ];
    for op in infix_ops {
        for b in bad {
            for b_on_right in [true, false] {
                let src = if b_on_right {
                    format!("1 {} {}", op, b)
                } else {
                    format!("{} {} 1", b, op)
                };
                expect_run_err(&src, &format!("{} requires int", op));
            }
        }
    }
    // mod keeps the function-call face (identifier-named builtin)
    for b in bad {
        expect_run_err(&format!("mod(1, {})", b), "mod requires int");
        expect_run_err(&format!("mod({}, 1)", b), "mod requires int");
    }
}

/// Non-numeric operands × float path (20 cases): any Float → numeric-tower
/// path, message shape: `{op} requires a number` (builtins.rs as_number
/// validation).
#[test]
fn arithmetic_float_path_non_numeric() {
    let infix_ops = ["+", "-", "*", "/"];
    let bad = ["\"s\"", "()"];
    for op in infix_ops {
        for b in bad {
            // float on the left
            expect_run_err(
                &format!("1.5 {} {}", op, b),
                &format!("{} requires a number", op),
            );
            // float on the right
            expect_run_err(
                &format!("{} {} 1.5", b, op),
                &format!("{} requires a number", op),
            );
        }
    }
    // mod keeps the function-call face
    for b in bad {
        expect_run_err(&format!("mod(1.5, {})", b), "mod requires a number");
        expect_run_err(&format!("mod({}, 1.5)", b), "mod requires a number");
    }
}

/// mod rejects float operands (2 cases) — numeric-tower exception
/// (integer-division semantics constraint).
#[test]
fn modulo_rejects_float_operands() {
    expect_run_err("mod(5.0, 2)", "mod does not accept float operands");
    expect_run_err("mod(5, 2.0)", "mod does not accept float operands");
}

/// Arithmetic arity and identity-element boundaries (post-D5/D9 semantics;
/// E6 shrinkage: 5 of the S-expr file's 9 rows are unrepresentable on the
/// target grammar — `(-)`, `(/)`, `(/ 5)` (bare / under-arity
/// infix-operator applications) and the identity elements `(+)`→0,
/// `(*)`→1 — deleted with this note). The surviving faces: mod arity
/// floor; unary negation (the target `-e` unary face).
#[test]
fn arithmetic_arity_floor() {
    expect_run_err("mod()", "mod at least requires 2 arguments");
    expect_run_err("mod(5)", "mod at least requires 2 arguments");
    // unary negation (D5/D9 positive anchor — the target `-e` unary face)
    let neg = common::run("-5").expect("unary take negative");
    assert!(matches!(neg, kerf_vm::Value::Int(-5)));
    let negf = common::run("-2.5").expect("unary take negative(float)");
    assert!(matches!(negf, kerf_vm::Value::Float(f) if f == -2.5));
}

/// Integer division by zero / modulo by zero (3 cases, E5 carrier).
/// Note: `1 / 0.0` is legal (inf).
#[test]
fn division_and_modulo_by_zero() {
    expect_run_err("1 / 0", "integer division by zero");
    expect_run_err("0 / 0", "integer division by zero");
    expect_run_err("mod(5, 0)", "integer modulo by zero");
}

/// Integer overflow (3 cases, E5 carrier, checked_* paths). i64::MIN
/// literals are unrepresentable on the target lexer (digit-run overflow) —
/// the subtraction carrier computes the value at runtime.
#[test]
fn integer_overflow_detected() {
    expect_run_err("9223372036854775807 + 1", "integer addition overflow");
    expect_run_err(
        "-9223372036854775807 - 1 - 1",
        "integer subtraction overflow",
    );
    expect_run_err("9223372036854775807 * 2", "integer multiplication overflow");
}

// ---------------------------------------------------------------------------
// Comparison (== < > <= >=): type rules × arity
// ---------------------------------------------------------------------------

/// String operands mixed with non-string intrusion (4 cases, the negative
/// face after TD-011 r24): all-string comparisons are already legal
/// (code-point order — positive cases in stdlib_tests); mixed operands
/// still report the `{op} requires a number` message. (The S-expr
/// chained-comparison faces `(< "a" "b" 1)` reduce to binary infix forms —
/// the target comparison grammar is non-chaining; the mixed-type
/// intrusion negative is preserved.)
#[test]
fn comparison_string_chain_mixed_rejected() {
    expect_run_err("\"a\" < 1", "< requires a number");
    expect_run_err("\"a\" > 1", "> requires a number");
    expect_run_err("\"a\" <= 2", "<= requires a number");
    expect_run_err("3 >= \"a\"", ">= requires a number");
}

/// Comparison type mismatch ×4 operators ×6 variants (24 cases): message
/// `{op} requires a number`. Numeric-tower mixing (`1 < 2.0`) is legal and
/// not listed here. (r162 / 233 — TD-037: the `==` row retired — the
/// equality skin re-points to the cross-domain structural `eq`, so mixed
/// `==` comparisons are silent `false` by design, not run errors; coverage
/// migrated to ktf_equality_domain_tests.)
#[test]
fn comparison_type_mismatch() {
    let ops = [("<", "<"), (">", ">"), ("<=", "<="), (">=", ">=")];
    let variants: &[(&str, &str)] = &[
        ("1", "\"s\""),      // int/str
        ("\"s\"", "1"),      // str/int
        ("()", "1"),         // nil/int
        ("1", "()"),         // int/nil
        ("true", "false"),   // bool/bool
        ("cons(1, 2)", "3"), // pair/int
    ];
    for (op, msg_op) in ops {
        for (l, r) in variants {
            expect_run_err(
                &format!("{} {} {}", l, op, r),
                &format!("{} requires a number", msg_op),
            );
        }
    }
}

// E6 shrinkage note (r154 / 224-b2): the `comparison_arity_floor` family
// (5 cases — `(< 1)`, `(> 1)`, `(<= 1)`, `(>= 1)`, `(= 1)`) is DELETED:
// the target comparison grammar is binary non-chaining infix — an
// under-arity comparison application is unrepresentable (no operator-call
// face exists).

// ---------------------------------------------------------------------------
// Pairs (cons head tail)
// ---------------------------------------------------------------------------

/// cons arity (3 cases): exactly 2 args.
#[test]
fn cons_arity() {
    expect_run_err("cons()", "cons requires 2 arguments, got 0");
    expect_run_err("cons(1)", "cons requires 2 arguments, got 1");
    expect_run_err("cons(1, 2, 3)", "cons requires 2 arguments, got 3");
}

/// car/cdr arity (4 cases): exactly 1 arg (arity check before type check).
#[test]
fn car_cdr_arity() {
    expect_run_err("head()", "head requires 1 arguments, got 0");
    expect_run_err("tail()", "tail requires 1 arguments, got 0");
    expect_run_err("head(5, 6)", "head requires 1 arguments, got 2");
    expect_run_err("tail(5, 6)", "tail requires 1 arguments, got 2");
}

/// car/cdr non-pair ×7 types ×2 operators (14 cases): message includes
/// type_name.
#[test]
fn car_cdr_non_pair_operands() {
    let bad = [
        ("5", "int"),
        ("1.5", "float"),
        ("\"s\"", "str"),
        ("true", "bool"),
        ("()", "nil"),
        ("|| (x: i64) { x }", "procedure"),
        ("head", "builtin-procedure"),
    ];
    for op in ["head", "tail"] {
        for (operand, type_name) in bad {
            let src = format!("{}({})", op, operand);
            expect_run_err(&src, &format!("{} requires pair, got {}", op, type_name));
        }
    }
}

// ---------------------------------------------------------------------------
// Predicates (is_nil is_pair is_int is_bool is_procedure eq)
// ---------------------------------------------------------------------------

/// Unary predicate arity (10 cases): 0 args / 2 args. (Source names are
/// snake_case; the runtime messages keep the registered kebab form.)
#[test]
fn unary_predicate_arity() {
    let preds = [
        ("is_nil", "is-nil"),
        ("is_pair", "is-pair"),
        ("is_int", "is-int"),
        ("is_bool", "is-bool"),
        ("is_procedure", "is-procedure"),
    ];
    for (p, msg_name) in preds {
        expect_run_err(
            &format!("{}()", p),
            &format!("{} requires 1 arguments, got 0", msg_name),
        );
        expect_run_err(
            &format!("{}(1, 2)", p),
            &format!("{} requires 1 arguments, got 2", msg_name),
        );
    }
}

/// eq arity (3 cases): exactly 2 args (contrast with chainable == — eq is
/// not chainable).
#[test]
fn eq_arity() {
    expect_run_err("eq()", "eq requires 2 arguments, got 0");
    expect_run_err("eq(1)", "eq requires 2 arguments, got 1");
    expect_run_err("eq(1, 2, 3)", "eq requires 2 arguments, got 3");
}

// ---------------------------------------------------------------------------
// Logic (not) and I/O (print)
// ---------------------------------------------------------------------------

/// not non-boolean ×7 types (7 cases, E1 carrier).
#[test]
fn not_requires_bool() {
    let bad = [
        ("5", "int"),
        ("1.5", "float"),
        ("\"s\"", "str"),
        ("()", "nil"),
        ("cons(1, 2)", "pair"),
        ("|| (x: i64) { x }", "procedure"),
        ("head", "builtin-procedure"),
    ];
    for (operand, type_name) in bad {
        expect_run_err(
            &format!("not({})", operand),
            &format!("not requires bool, got {}", type_name),
        );
    }
}

/// not/print arity (4 cases).
#[test]
fn not_and_print_arity() {
    expect_run_err("not()", "not requires 1 arguments, got 0");
    expect_run_err("not(true, false)", "not requires 1 arguments, got 2");
    expect_run_err(
        "require io, write; print()",
        "print requires 1 arguments, got 0",
    );
    expect_run_err(
        "require io, write; print(1, 2)",
        "print requires 1 arguments, got 2",
    );
}

/// read-line arity (FS-4 fix — validation added when r8 rewrote the
/// capability parameterization, enabling the archived assertion: with
/// actuals it reports an arity error consistent with the print family,
/// instead of silently reading stdin).
#[test]
fn read_line_arity() {
    expect_run_err(
        "require io, read; read_line(1)",
        "read-line requires 0 arguments",
    );
}

// ---------------------------------------------------------------------------
// Strings (string_append — the target-face spelling of string-append)
// ---------------------------------------------------------------------------

/// string-append non-string ×7 types ×2 positions (14 cases).
#[test]
fn str_append_requires_strings() {
    let bad = [
        "1",
        "1.5",
        "true",
        "()",
        "cons(1, 2)",
        "|| (x: i64) { x }",
        "head",
    ];
    for b in bad {
        expect_run_err(
            &format!("import kerf_string;\nstring_append({}, \"b\")", b),
            "string-append requires 2 strings",
        );
        expect_run_err(
            &format!("import kerf_string;\nstring_append(\"a\", {})", b),
            "string-append requires 2 strings",
        );
    }
}

/// string-append arity (2 cases): exactly 2 args.
#[test]
fn str_append_arity() {
    expect_run_err(
        "import kerf_string;\nstring_append(\"a\")",
        "string-append requires 2 arguments",
    );
    expect_run_err(
        "import kerf_string;\nstring_append(\"a\", \"b\", \"c\")",
        "string-append requires 2 arguments",
    );
}

// ---------------------------------------------------------------------------
// Call position (E4 NotCallable) and if condition (E1)
// ---------------------------------------------------------------------------

/// Non-callable values ×7 types in call position (7 cases): values other
/// than literal/pair/procedure (postfix call on any primary — the target
/// face keeps the literal-in-callee-position shape).
#[test]
fn not_callable_values() {
    let bad = [
        ("1(2)", "int"),
        ("1.5(1)", "float"),
        ("\"s\"(1)", "str"),
        ("true(1)", "bool"),
        ("false(1)", "bool"),
        ("()(1)", "nil"),
        ("cons(1, 2)(1)", "pair"),
    ];
    for (src, type_name) in bad {
        expect_run_err(src, &format!("uncallable value: {}", type_name));
    }
}

/// if condition non-boolean ×6 types (6 cases, VM message shape).
/// TD-018 (r24): the message is built from the messages.rs single source,
/// identical with the eval reference path — prefix unified as
/// "if condition requires bool" (consistent with the static-face R1
/// diagnostic prefix).
#[test]
fn if_condition_requires_bool() {
    let bad = [
        ("1", "int"),
        ("1.5", "float"),
        ("\"s\"", "str"),
        ("()", "nil"),
        ("cons(1, 2)", "pair"),
        ("|| (x: i64) { x }", "procedure"),
    ];
    for (operand, type_name) in bad {
        let src = format!("if ({}) {{ 1 }} else {{ 2 }}", operand);
        expect_run_err(
            &src,
            &format!("if condition requires bool, got {}", type_name),
        );
    }
}

// ---------------------------------------------------------------------------
// User procedure arity (E2 ArityMismatch)
// ---------------------------------------------------------------------------

/// lambda/function-sugar arity mismatch (5 cases, including multi-form
/// programs). The target lambda face is the `||` closure expression.
#[test]
fn lambda_arity_mismatch() {
    expect_run_err(
        "(||(x: i64) { x })(1, 2)",
        "procedure argument count mismatch: expected 1, got 2",
    );
    expect_run_err(
        "(||(x: i64, y: i64) { x })(1)",
        "procedure argument count mismatch: expected 2, got 1",
    );
    expect_run_err(
        "(||(x: i64, y: i64, z: i64) { x })(1, 2)",
        "procedure argument count mismatch: expected 3, got 2",
    );
    expect_run_err(
        "(|| { 1 })(1)",
        "procedure argument count mismatch: expected 0, got 1",
    );
    expect_run_err(
        "fn f(x: i64) { x } f(1, 2)",
        "procedure argument count mismatch: expected 1, got 2",
    );
}

/// Unbound variable (2 cases, VM message shape) — message diverges from
/// the eval path (asserting the VM side as-is; the eval side says
/// "unbound variable").
#[test]
fn unbound_variable_vm_message() {
    // r46 / D49: unbound references moved to compile time (E0022 — the
    // R-N1 step 4 carrier); the runtime "unbound global variable (hygiene
    // fallback resolution already done in the driver)" remains as defense
    // in depth (non-front path — direct VM invocation scenario)
    for src in ["undefined_x", "undefined_fn(1)"] {
        let err = match run_source(src, "neg.ktf") {
            Ok(_) => panic!("expected an error, got Ok: {}", src),
            Err(e) => e,
        };
        assert_eq!(
            err.stage,
            Stage::Compile,
            "stage(D49 advance): {}",
            err.rendered
        );
        assert!(
            err.rendered.contains("E0022") && err.rendered.contains("unbound reference"),
            "E0022 unbound reference form: \n{}",
            err.rendered
        );
    }
}

// ---------------------------------------------------------------------------
// E0004 code and rendering shape
// ---------------------------------------------------------------------------

/// E0004 rendering-shape full assertions (3 cases): error[E0004] + `-->` +
/// source excerpt + diagnostic code structure (diagnostics are data,
/// §8.7).
#[test]
fn vm_error_code_is_e0004() {
    let err = expect_run_err("\"s\" + 1", "+ requires int");
    assert!(err.rendered.contains("error[E0004]: + requires int"));
    assert!(err.rendered.contains("--> neg.ktf:1:1"));
    assert!(err.rendered.contains("1 | \"s\" + 1"));
    assert!(err.to_string().starts_with("[run] error[E0004]"));
    assert_eq!(
        err.diagnostic.code,
        Some(kerf_span::DiagnosticCode(4)),
        "Run error must be numbered E0004"
    );
    let err2 = expect_run_err("head(())", "head requires pair, got nil");
    // The Call instruction's debug Span = the whole application form (1:1)
    // — the error locates to the call position
    assert!(err2.rendered.contains("--> neg.ktf:1:1"));
    let err3 = expect_run_err(
        "fn f(x: i64) { x } f(1, 2)",
        "procedure argument count mismatch: expected 1, got 2",
    );
    assert!(err3.rendered.contains("error[E0004]"));
    // the call `f(1, 2)` starts at source offset 19 (col 20)
    assert_eq!(err3.diagnostic.primary_span.start, 19);
}

/// Call frame limit (1 case): **non-tail-position** runaway recursion
/// reports a structured error on the VM path (MAX_FRAMES = 100_000;
/// iterative loop — §8.12).
/// H2/TCO note: tail recursion (the old case `c(n - 1)` in tail
/// position) no longer hits this limit thanks to frame reuse with a
/// constant frame count — the tail-recursion positive case moved to
/// tco_tests (batch H2 deliverable); here the non-tail shape
/// (`1 + c(…)` consuming the result → one real frame added per level)
/// preserves the "frame-limit structured error" verification intent. The
/// eval path (recursive evaluator) aborts with a Rust stack overflow at
/// the same depth — divergence archived in
/// `deep_recursion_eval_path_structured_error`.
#[test]
fn frame_limit_deep_recursion_vm_path() {
    let src = "fn c(n: i64) { if (n == 0) { 0 } else { 1 + c(n - 1) } } c(105001)";
    expect_run_err(src, "call frame limit exceeded 100000(runaway recursion)");
}

/// Deep tail recursion on the production path (rewritten per the 42-d
/// baseline — TD-017 final verification: the eval reference path is
/// retired and its 256-depth-limit domain deregistered with it; the
/// production VM path has no depth limit via TCO frame reuse — 105_000
/// levels of tail recursion terminate correctly).
#[test]
fn deep_tail_recursion_production_path_tco() {
    let src = "fn c(n: i64) { if (n == 0) { 0 } else { c(n - 1) } } c(105000)";
    let o =
        kerf_driver::run_source(src, "neg.ktf").expect("production path should via TCO succeeded");
    assert!(matches!(o.value, kerf_vm::Value::Int(0)));
    // dual-path agreement positive case (seed chain same result — fib(10))
    assert!(common::dual_path_agrees(
        "fn f(n: i64) -> i64 { if (n < 2) { n } else { f(n - 1) + f(n - 2) } } f(10)"
    ));
}

/// mod i64::MIN -1 overflow structured error (D4 fix: checked_rem) + the
/// division dual. (i64::MIN literals are unrepresentable on the target
/// lexer — the operand is computed at runtime as
/// `-9223372036854775807 - 1`.)
#[test]
fn mod_i64_min_structured_error() {
    expect_run_err(
        "mod(-9223372036854775807 - 1, -1)",
        "integer modulo overflow",
    );
    expect_run_err(
        "(-9223372036854775807 - 1) / -1",
        "integer division overflow",
    );
    // seed chain shares the builtins (both paths report the same — T1 new
    // baseline 42-d)
    let ev =
        kerf_driver::run_source_seed("mod(-9223372036854775807 - 1, -1)", "neg.ktf").unwrap_err();
    assert!(ev.rendered.contains("integer modulo overflow"));
}

// ---------------------------------------------------------------------------
// Dual-path agreement negative cases (only aligned semantics: E6/
// set!-E3/duplicate params/builtin errors)
// ---------------------------------------------------------------------------

/// Dual-path agreement error programs (12 cases): VM and eval render
/// byte-identical (§21.8 Phase 1). Only **aligned** message shapes are
/// included — divergence faces like unbound/if-non-boolean are covered in
/// the file header notes and negative_semantics_tests.rs.
#[test]
fn dual_path_agrees_on_error_programs() {
    let programs = [
        // E6: same-layer duplicate definition (Task 12 fix face)
        "let x = 1; let x = 2;",
        "fn f(x: i64) { x } fn f(y: i64) { y }",
        "do(define(x, 1), define(x, 2))",
        // E3: assign unbound (Task 12 fix face)
        "y = 1;",
        // duplicate parameter names (expansion-time single-point defense)
        "||(x: i64, x: i64) { x }",
        // E5: builtin runtime errors
        "1 / 0",
        "mod(5, 0)",
        "9223372036854775807 + 1",
        // E1: builtin type errors
        "head(5)",
        "\"s\" + 1",
        "mod(5, 2.0)",
        "not(5)",
    ];
    for src in programs {
        assert!(
            common::dual_path_agrees(src),
            "dual-path error form mismatch: {}",
            src
        );
    }
}

/// Auxiliary verification of the frame-limit error path (1 case): after
/// the VM errors, no RunOutcome is produced (errors are data — carried on
/// the Result channel).
#[test]
fn run_error_yields_no_value() {
    let r = run_source("1 + 0; \"s\" + 1", "neg.ktf");
    match r {
        Ok(o) => panic!("not should produce value:{:?}", o.value.type_name()),
        Err(e) => assert!(matches!(e.diagnostic.severity, kerf_span::Severity::Error)),
    }
    let _ = Value::Nil; // value-type reachability anchor (kerf-vm dependency in place)
}

// ---------------------------------------------------------------------------
// TD-002 symbol value semantic negatives (value-consumer boundaries after
// the symbol datum release)
// Messages calibrated by actual runs (kerf run probes, 2026-09-10)
// ---------------------------------------------------------------------------

/// Symbol value misuse (6 cases): arithmetic / condition / pair operations
/// / numeric comparison. (Symbol datums keep the `quote(sym)` target
/// surface.)
#[test]
fn symbol_value_misuse() {
    let cases: &[(&str, &str)] = &[
        ("1 + quote(a)", "+ requires int"),
        ("quote(a) - quote(b)", "- requires int"),
        ("quote(a) * 2", "* requires int"),
        (
            "if (quote(a)) { 1 } else { 2 }",
            "if condition requires bool, got symbol",
        ),
        ("head(quote(a))", "head requires pair, got symbol"),
        // r162 / 233 — TD-037: `quote(a) == 1` retired from the error
        // family (mixed-domain `==` is silent `false` by design — see
        // ktf_equality_domain_tests); symbol misuse on the ordering
        // family stays checked:
        ("quote(a) < 1", "< requires a number"),
    ];
    for (src, msg) in cases {
        expect_run_err(src, msg);
    }
}

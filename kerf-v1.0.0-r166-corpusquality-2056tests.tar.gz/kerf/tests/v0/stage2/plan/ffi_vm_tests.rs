//! FFI VM-surface integration tests (r30/48-d — batch J, 48-d J3 acceptance).
//!
//! **Acceptance contract** (plan.md §5b row 48-d + ffi-ownership-model §10):
//! - §6 boundary **all 13 cases adjudicated and landed** (coverage mapping
//!   table below);
//! - Positive-case end-to-end ≥1 (the write_stdout char* path through the
//!   frozen FfiCall → lowering → opcodes → window protocol → real host
//!   I/O);
//! - Negative-case group positive:negative ratio ≥1:3 (§9.4.3 —
//!   feature-point granularity: window protocol/allocation-freeing/token
//!   passing/symbol resolution/diagnostic family each with ≥1 positive +
//!   ≥3 negative);
//! - E0010/E0011/E0012 diagnostic family in place (18 §6 code-slot registry,
//!   honoring the r18 reservation).
//!
//! **13-case coverage mapping** (ffi-ownership-model §6):
//!
//! | case | ruling | test anchor |
//! |------|--------|--------|
//! | 1 GC run after pin | F-PIN liveness guarantee | `f_pin_case1_survives_gc` |
//! | 2 assign during pin | allowed (does not freeze contents) | `pin_window_allows_binding_mutation_case2` |
//! | 3 external callback crossing the window | Stage 2 has no callback path | `negative_cstruct_cfunction_registration_out_of_subset` (CFunction shape rejected)|
//! | 4 AllocExternal size 0 | compile-time rejection + runtime defense-in-depth | `negative_alloc_size_zero_compile_rejected` + `negative_alloc_size_zero_vm_defense` |
//! | 5 double free | E0010 diagnostic absorbs, not UB | `negative_double_free_e10` |
//! | 6 GC during CallExternal | not triggered (zero kerf allocation externally) | `positive_window_protocol_balanced` (total_allocs Δ=1, boxing only)|
//! | 7 returns Opaque | carried in a Foreign slot / cannot Free | `negative_free_opaque_e11` |
//! | 8 deep vs shallow pin | pseudo-problem (mark propagation) | `shallow_pin_case8_deep_reachability` |
//! | 9 error-path pin/token leaks | tolerated (mistaken reclamation is zero-tolerance) | `negative_error_path_pin_leak_tolerated_case9` + `negative_panic_host_pin_leak_tolerated_case9` + `token_slot_gc_reclaim_leak_tolerated_case9` |
//! | 10 multithreading | Stage 2 single-threaded-domain ruling | structural note (Rc/Cell family all !Send — ffi.rs header note; no behavioral surface)|
//! | 11 token copy with one Free | consumption takes effect globally | `negative_token_shared_invalidation_e10` |
//! | 12 token/GcRef confusion | E0010/E0011 | `negative_free_non_token_value_e11` |
//! | 13 C returns NULL | Valid empty token, no-op | `positive_null_sentinel_free_noop` |

use std::cell::RefCell;
use std::collections::HashMap;
use std::rc::Rc;

use kerf_compiler::{BcConst, BcProgram, Op};
use kerf_driver::ffi::{compile_ffi_call_program, default_extern_table, HeapFfiBoundary};
use kerf_driver::reserved::{CIntSize, ExternalType, FfiBoundary, FfiCall, PointeeType};
use kerf_runtime::{mark_sweep_cycle, Heap, RootSet, RuntimeError};
use kerf_span::Span;
use kerf_syntax::{Symbol, SymbolTable};
use kerf_vm::ffi::{
    call_external, free_external, BorrowedArg, ExternKind, ExternSymbolTable, ExternalToken,
    HostRet,
};
use kerf_vm::{run_program, run_program_with_externs, Value, VmError};

// ---------------------------------------------------------------------------
// test helpers
// ---------------------------------------------------------------------------

/// Hand-written bytecode program (FFI-opcode-driven surface — the execution
/// form before the Stage 3 language surface).
fn ffi_program(code: Vec<Op>, consts: Vec<BcConst>) -> BcProgram {
    let n = code.len();
    BcProgram {
        protos: vec![kerf_compiler::BcProto {
            name: Symbol(0),
            params: Vec::new(),
            rest_slot: None,
            n_locals: 0,
            capture_names: Vec::new(),
            capture_sources: Vec::new(),
            code,
            debug_spans: vec![Span::dummy(); n],
            free_vars: Vec::new(),
        }],
        consts,
        entry: 0,
        global_refs: Vec::new(),
        module_name: None,
    }
}

/// Execute (with an extern table — the FFI registration surface).
fn run_ffi(prog: &BcProgram, table: &ExternSymbolTable) -> Result<Value, VmError> {
    let mut heap = Heap::new();
    let mut globals = HashMap::new();
    run_program_with_externs(prog, &mut globals, &mut heap, table)
}

/// SymLit constant construction (extern symbol name — flat space).
fn sym_const(name: &str) -> BcConst {
    BcConst::SymLit(Rc::from(name))
}

/// Single-argument CallExternal program (Str argument — the char* window-borrow path).
fn call_str_program(fn_name: &str, s: &str) -> BcProgram {
    ffi_program(
        vec![
            Op::PushConst(1),
            Op::CallExternal {
                symbol: 0,
                n_args: 1,
            },
            Op::Halt,
        ],
        vec![sym_const(fn_name), BcConst::Str(Rc::from(s))],
    )
}

// Window-observation capture (host side — thread_local single-threaded
// domain, case 10 ruling; ordinary comment: doc comments do not apply to
// macro-expanded output).
thread_local! {
    static LAST_WINDOW: RefCell<String> = const { RefCell::new(String::new()) };
}

/// Capturing host function (char* borrowed in → CInt returned) — records
/// the argument shape visible inside the window.
fn capture_host(args: &[BorrowedArg<'_>]) -> Result<HostRet, RuntimeError> {
    let observed = format!(
        "[{}]",
        args.iter()
            .map(|a| match a {
                BorrowedArg::CharBuf(s) => format!("CharBuf({s:?})"),
                BorrowedArg::Int(v) => format!("Int({v})"),
                BorrowedArg::Token(t) =>
                    format!("Token(kind={:?},valid={})", t.kind(), t.is_valid()),
            })
            .collect::<Vec<_>>()
            .join(",")
    );
    LAST_WINDOW.with(|w| *w.borrow_mut() = observed);
    Ok(HostRet::Int(0))
}

/// Probe host function (CPointer token passed by borrow — not consumed).
fn probe_token_host(args: &[BorrowedArg<'_>]) -> Result<HostRet, RuntimeError> {
    match args {
        [BorrowedArg::Token(_)] => Ok(HostRet::Int(1)),
        _ => Err(RuntimeError::new(
            "probe accepts exactly one token actual argument",
        )),
    }
}

/// NULL sentinel host function (CPointer return — NULL shape).
fn make_null_host(_args: &[BorrowedArg<'_>]) -> Result<HostRet, RuntimeError> {
    Ok(HostRet::NullPtr)
}

/// Opaque sentinel host function (externally-owned return — not kerf's to free).
fn make_opaque_host(_args: &[BorrowedArg<'_>]) -> Result<HostRet, RuntimeError> {
    // Static sentinel address (owned by the external API — kerf never frees it)
    Ok(HostRet::Opaque(0x1234_0000usize as *mut u8))
}

/// Failing host function (E0004 runtime-generic-family propagation surface — E7 I/O caliber).
fn failing_host(_args: &[BorrowedArg<'_>]) -> Result<HostRet, RuntimeError> {
    Err(RuntimeError::new(
        "external call failed(host I/O channel error)",
    ))
}

/// Panicking host function (case 9 — same shape as a C-side non-local jump: pin leak on the unwind path).
fn panic_host(_args: &[BorrowedArg<'_>]) -> Result<HostRet, RuntimeError> {
    panic!("host external function non-local jump(case 9 leak capacity tolerate observation)");
}

/// CInt-doubling host function.
fn double_host(args: &[BorrowedArg<'_>]) -> Result<HostRet, RuntimeError> {
    match args {
        [BorrowedArg::Int(v)] => Ok(HostRet::Int(v * 2)),
        _ => Err(RuntimeError::new(
            "double accepts exactly one CInt actual argument",
        )),
    }
}

/// Test table (capture/probe/NULL/Opaque/failing/panic/double + arity two-param shape).
fn test_table() -> ExternSymbolTable {
    let mut t = ExternSymbolTable::new();
    t.register(
        "capture",
        vec![ExternKind::CPointer],
        ExternKind::CInt,
        capture_host,
    );
    t.register(
        "probe_token",
        vec![ExternKind::CPointer],
        ExternKind::CInt,
        probe_token_host,
    );
    t.register(
        "make_null",
        Vec::new(),
        ExternKind::CPointer,
        make_null_host,
    );
    t.register(
        "make_opaque",
        Vec::new(),
        ExternKind::Opaque,
        make_opaque_host,
    );
    t.register("failing", Vec::new(), ExternKind::CInt, failing_host);
    t.register(
        "panic_fn",
        vec![ExternKind::CPointer],
        ExternKind::CInt,
        panic_host,
    );
    t.register(
        "double",
        vec![ExternKind::CInt],
        ExternKind::CInt,
        double_host,
    );
    t.register(
        "two_params",
        vec![ExternKind::CInt, ExternKind::CInt],
        ExternKind::CInt,
        |args| match args {
            [BorrowedArg::Int(a), BorrowedArg::Int(b)] => Ok(HostRet::Int(a + b)),
            _ => Err(RuntimeError::new("two_params accepts exactly two CInt")),
        },
    );
    t
}

// ---------------------------------------------------------------------------
// Positive cases (feature-point granularity — anchors for window
// protocol/allocation-freeing/token passing/symbol resolution)
// ---------------------------------------------------------------------------

/// **Positive case end to end** (acceptance anchor: the write_stdout char*
/// path) — the frozen `FfiCall::CallExternal` (literal argument +
/// return_type static surface) → `compile_ffi_call_program` (compiled target
/// opcode sequence) → `Op::CallExternal` → window protocol steps 2-4 (pin
/// the Str heap slot + borrow the data pointer out of the boundary + unpin)
/// → real host I/O (kerf_runtime::write_stdout) → CInt return = byte count.
#[test]
fn positive_write_stdout_e2e_real() {
    let mut st = SymbolTable::new();
    let sym = st.intern("write_stdout");
    let prog = compile_ffi_call_program(
        &FfiCall::CallExternal {
            symbol: sym,
            args: vec![kerf_core::CoreExpr::Literal {
                value: kerf_core::LiteralValue::Str(Rc::from("hello ffi")),
                span: Span::dummy(),
            }],
            return_type: ExternalType::CInt(CIntSize::Usize),
        },
        &st,
    )
    .expect("literal FfiCall can compile");
    let mut heap = Heap::new();
    let mut globals = HashMap::new();
    let out = run_program_with_externs(&prog, &mut globals, &mut heap, &default_extern_table())
        .expect("write_stdout end-to-end execution");
    match out {
        Value::Int(n) => assert_eq!(n, 9, "CInt(Usize) return = write input byte count"),
        other => panic!("expected Int, got {:?}", other),
    }
}

/// Window protocol steps 2-4 invariants: the host observes the CharBuf
/// borrow + the Φ ledger balanced (pinned_refs empty after the window
/// closes) + total_allocs Δ=1 (char* boxing — **case 6**: the host call and
/// the external malloc contribute zero kerf allocations).
#[test]
fn positive_window_protocol_balanced() {
    let table = test_table();
    let mut heap = Heap::new();
    let before = heap.stats().total_allocs;
    let v = call_external(
        &table,
        "capture",
        &[Value::Str(Rc::from("hello"))],
        &mut heap,
        Span::dummy(),
    )
    .expect("window rule process execution");
    assert!(matches!(v, Value::Int(0)));
    let after = heap.stats().total_allocs;
    assert_eq!(
        after - before,
        1,
        "case 6: unique kerf allocation = char* install box(host call zero contribute dedicate)"
    );
    assert!(
        heap.pinned_refs().is_empty(),
        "window closed: Φ ledger allocate level(step 4 unpin converge zero excerpt root)"
    );
    let observed = LAST_WINDOW.with(|w| w.borrow().clone());
    assert_eq!(
        observed, "[CharBuf(\"hello\")]",
        "host side data pointer borrowing output bound form"
    );
}

/// Repeated window pairing (the Φ ledger re-balances across multiple calls —
/// the reference-counted barrier leaves no residue).
#[test]
fn positive_multiple_calls_repeated_window() {
    let table = test_table();
    let mut heap = Heap::new();
    for _i in 0..8 {
        call_external(
            &table,
            "capture",
            &[Value::Str(Rc::from("x"))],
            &mut heap,
            Span::dummy(),
        )
        .expect("# {i} times window execution");
    }
    assert!(
        heap.pinned_refs().is_empty(),
        "8 times window after Φ ledger zero residual"
    );
    assert_eq!(
        heap.stats().total_allocs,
        8,
        "each call exactly one times install box allocation"
    );
}

/// AllocExternal → FreeExternal opcode-level round trip (external-domain
/// allocation/freeing + consumption semantics).
#[test]
fn positive_alloc_free_roundtrip() {
    let table = test_table();
    let prog = ffi_program(
        vec![Op::AllocExternal { size: 16 }, Op::FreeExternal, Op::Halt],
        Vec::new(),
    );
    let out = run_ffi(&prog, &table).expect("allocation-release round trip");
    assert!(matches!(out, Value::Unit), "FreeExternal return unit");
}

/// Token pass-by-borrow (self-loop transition — not consumed): the probe
/// observes the Token shape + the token remains Valid after the call.
#[test]
fn positive_token_borrow_pass_not_consumed() {
    let table = test_table();
    let token = ExternalToken::from_boxed_slice(vec![0u8; 8].into_boxed_slice());
    let v = call_external(
        &table,
        "probe_token",
        &[Value::External(Rc::clone(&token))],
        &mut Heap::new(),
        Span::dummy(),
    )
    .expect("token borrowing transfer");
    assert!(matches!(v, Value::Int(1)));
    assert!(
        token.is_valid(),
        "borrowing transfer not consume(state machine from ring)"
    );
}

/// **case 13**: NULL sentinel — the host returns NULL → a Valid empty token;
/// FreeExternal = a legal no-op (aligning with free(NULL) being
/// well-defined).
#[test]
fn positive_null_sentinel_free_noop() {
    let table = test_table();
    let prog = ffi_program(
        vec![
            Op::CallExternal {
                symbol: 0,
                n_args: 0,
            },
            Op::FreeExternal,
            Op::Halt,
        ],
        vec![sym_const("make_null")],
    );
    let out = run_ffi(&prog, &table).expect("NULL sentinel release = no-op");
    assert!(matches!(out, Value::Unit));
}

/// CInt value-copy path (argument value crosses out → return value copied back in).
#[test]
fn positive_cint_roundtrip() {
    let table = test_table();
    let prog = ffi_program(
        vec![
            Op::PushConst(1),
            Op::CallExternal {
                symbol: 0,
                n_args: 1,
            },
            Op::Halt,
        ],
        vec![sym_const("double"), BcConst::Int(21)],
    );
    match run_ffi(&prog, &table).expect("CInt round trip") {
        Value::Int(v) => assert_eq!(v, 42),
        other => panic!("expected Int, got {:?}", other),
    }
}

// ---------------------------------------------------------------------------
// Φ counting ledger / P-U reduction rules (ffi-ownership-model §3 — mechanism-validation surface)
// ---------------------------------------------------------------------------

/// P1: repeated pins accumulate in the count (3 pins → count 3).
#[test]
fn phi_p1_repeated_pin_counts() {
    let mut heap = Heap::new();
    let s = heap.alloc_str(Rc::from("x"));
    let p = heap.alloc_pair(s, s);
    heap.pin_object(p);
    heap.pin_object(p);
    heap.pin_object(p);
    assert_eq!(
        heap.pin_count(p),
        3,
        "P1: quote count form barrier(count cumulative)"
    );
    heap.unpin_object(p).expect("U1");
    assert_eq!(heap.pin_count(p), 2);
}

/// P2: pinning a non-heap value is a no-op (idempotent — through the real
/// FfiBoundary implementation surface).
#[test]
fn phi_p2_nonheap_noop() {
    let mut heap = Heap::new();
    {
        let mut b = HeapFfiBoundary::new(&mut heap);
        b.pin_object(Value::Int(42));
        b.pin_object(Value::Str(Rc::from("direct")));
        b.pin_object(Value::Nil);
    }
    assert!(
        heap.pinned_refs().is_empty(),
        "P2: non-heap value Φ not motion(idempotent)"
    );
}

/// U1: reaching zero removes the object from supp(Φ) (reclaimable in the
/// next collection cycle — not immediate).
#[test]
fn phi_u1_unpin_zero_removes_from_support() {
    let mut heap = Heap::new();
    let s = heap.alloc_str(Rc::from("x"));
    heap.pin_object(s);
    assert_eq!(heap.pinned_refs(), vec![s], "supp(Φ) containing pinned");
    heap.unpin_object(s).expect("U1");
    assert!(heap.pinned_refs().is_empty(), "converge zero excerpt root");
}

/// **case 1** (F-PIN lemma): a GC cycle after pin → the object survives;
/// unpin to zero → reclaimed in the next cycle.
#[test]
fn f_pin_case1_survives_gc() {
    let mut heap = Heap::new();
    let s = heap.alloc_str(Rc::from("pinned"));
    let live_before = heap.stats().live;
    heap.pin_object(s);
    mark_sweep_cycle(&mut heap, &RootSet::new());
    assert_eq!(
        heap.stats().live,
        live_before,
        "F-PIN: Φ ≥ 1 ⟹ this round not collection"
    );
    heap.unpin_object(s).expect("structural pairing");
    mark_sweep_cycle(&mut heap, &RootSet::new());
    assert!(
        heap.stats().live < live_before,
        "unpin excerpt root after under one round can collection(non-immediately)"
    );
}

/// **case 8**: shallow pin is semantically equivalent to deep pin (mark
/// propagation covers the whole reachable subgraph — the runtime proof that
/// the pseudo-problem is dissolved).
#[test]
fn shallow_pin_case8_deep_reachability() {
    let mut heap = Heap::new();
    // Nested graph: pair(a) → (pair(b) → (str_inner . nil)) . str_leaf
    let str_inner = heap.alloc_str(Rc::from("inner"));
    let nil = heap.alloc_nil();
    let pb = heap.alloc_pair(str_inner, nil);
    let str_leaf = heap.alloc_str(Rc::from("leaf"));
    let pa = heap.alloc_pair(pb, str_leaf);
    let live_before = heap.stats().live;
    heap.pin_object(pa); // shallow pin: the root single point only
    mark_sweep_cycle(&mut heap, &RootSet::new());
    assert_eq!(
        heap.stats().live,
        live_before,
        "shallow pin: mark propagation coverage all reachable sub graph(equivalent deep pin)"
    );
}

/// **case 2**: assign during pin (binding change) — pin only constrains
/// collection eligibility, it does not freeze contents/binding flow.
#[test]
fn pin_window_allows_binding_mutation_case2() {
    use kerf_vm::GcCell;
    let mut heap = Heap::new();
    let s = heap.alloc_str(Rc::from("v1"));
    let p = heap.alloc_pair(s, s);
    heap.pin_object(p);
    let cell = GcCell::new(Value::Pair(p));
    // assign: the binding now points to a new value (binding flow not frozen)
    cell.set(Value::Int(99));
    assert_eq!(
        heap.pin_count(p),
        1,
        "pin ledger not receive binding change affects affects"
    );
    mark_sweep_cycle(&mut heap, &RootSet::new());
    assert_eq!(
        heap.pin_count(p),
        1,
        "collection resource format not frozen -- pin maintained"
    );
    assert!(
        matches!(&*cell.get(), Value::Int(99)),
        "content/binding change took effect(mutual reject in domain no data competing)"
    );
}

/// **case 9** (token leak from a reclaimed Foreign slot — tolerated
/// caliber): the token is boxed into a pair, then all references are dropped
/// → GC reclaims the carrier slot; the token's truth lives in the Rc (not a
/// GC slot) → subsequent consumption is still semantically sound (no UB).
#[test]
fn token_slot_gc_reclaim_leak_tolerated_case9() {
    let mut heap = Heap::new();
    let token = ExternalToken::from_boxed_slice(vec![0u8; 8].into_boxed_slice());
    let v = Value::External(Rc::clone(&token));
    let r = kerf_vm::box_value(&v, &mut heap);
    let nil_ref = heap.alloc_nil();
    let _carrier = heap.alloc_pair(r, nil_ref);
    let live_before = heap.stats().live;
    mark_sweep_cycle(&mut heap, &RootSet::new());
    assert!(
        heap.stats().live < live_before,
        "carries slot collection(external memory leak -- capacity tolerate, finalizer = Stage 3 anchor)"
    );
    // The token's Rc is still valid: the consumption path is semantically sound
    assert!(token.is_valid());
    let out = free_external(&Value::External(Rc::clone(&token)), Span::dummy())
        .expect("slot collection not affects affects token truth(Rc carries)");
    assert!(matches!(out, Value::Unit));
    assert!(!token.is_valid(), "consume global took effect");
}

// ---------------------------------------------------------------------------
// Negative-case group (E0010/E0011/E0012 + defense surfaces — the main
// carrier of the ≥1:3 positive:negative ratio)
// ---------------------------------------------------------------------------

/// **case 5**: double free → E0010 (the diagnostic absorbs it instead of
/// UB — a semantic upgrade over C's double-free UB).
/// Opcode sequence: [Alloc, Dup, Free, Pop, Free, Halt] — Dup leaves a
/// shared Rc copy on the stack, the first Free consumes it (globally
/// invalidated), Pop discards the Unit return, and the second Free touches
/// the Invalid token (a second reference to the same token — the
/// programmatic form of case 11).
#[test]
fn negative_double_free_e10() {
    let table = test_table();
    let prog = ffi_program(
        vec![
            Op::AllocExternal { size: 16 },
            Op::Dup,
            Op::FreeExternal,
            Op::Pop,
            Op::FreeExternal,
            Op::Halt,
        ],
        Vec::new(),
    );
    let e = run_ffi(&prog, &table).expect_err("double release must detected");
    assert_eq!(e.code, Some(10), "E0010 code");
    assert!(
        e.message.contains("token invalidated") || e.message.contains("double release"),
        "message: {}",
        e.message
    );
}

/// Illegal transition 2: use-after-free pass (an Invalid token as a
/// CallExternal argument) → E0010.
/// Opcode sequence: [Alloc, Dup, Free, Pop, CallExternal probe 1, Halt] —
/// after Dup there are two shared Rc copies on the stack, Free consumes one
/// (globally invalidated), and passing the leftover copy as an argument
/// triggers the error immediately.
#[test]
fn negative_use_after_free_arg_pass_e10() {
    let table = test_table();
    let prog = ffi_program(
        vec![
            Op::AllocExternal { size: 8 },
            Op::Dup,
            Op::FreeExternal,
            Op::Pop,
            Op::CallExternal {
                symbol: 0,
                n_args: 1,
            },
            Op::Halt,
        ],
        vec![sym_const("probe_token")],
    );
    let e = run_ffi(&prog, &table).expect_err("use after transfer must detected");
    assert_eq!(
        e.code,
        Some(10),
        "E0010 code(token invalidated after transfer)"
    );
}

/// **case 11**: after a token copy, one Free → consumption takes effect
/// globally (slot-level invalidation mark) — any subsequent use of the other
/// shared binding = E0010 (global visibility of the Rc-shared Cell).
#[test]
fn negative_token_shared_invalidation_e10() {
    let table = test_table();
    let token = ExternalToken::from_boxed_slice(vec![0u8; 4].into_boxed_slice());
    let a = Value::External(Rc::clone(&token));
    let b = Value::External(Rc::clone(&token));
    free_external(&a, Span::dummy()).expect("one place consume");
    assert!(
        !token.is_valid(),
        "consume global took effect(total share Cell)"
    );
    let e = call_external(&table, "probe_token", &[b], &mut Heap::new(), Span::dummy())
        .expect_err("shared quote use synchronization invalidated");
    assert_eq!(e.code, Some(10), "E0010(use after use)");
}

/// **case 4** (compile time): AllocExternal size=0 → lowering diagnostic rejection.
#[test]
fn negative_alloc_size_zero_compile_rejected() {
    let table = SymbolTable::new();
    let e = compile_ffi_call_program(&FfiCall::AllocExternal { size: 0 }, &table)
        .expect_err("size=0 compile-time rejected");
    assert!(e.message.contains("size is 0"), "message: {}", e.message);
}

/// **case 4** (runtime defense-in-depth): an opcode directly built with size=0 → E0011.
#[test]
fn negative_alloc_size_zero_vm_defense() {
    let table = test_table();
    let prog = ffi_program(vec![Op::AllocExternal { size: 0 }, Op::Halt], Vec::new());
    let e = run_ffi(&prog, &table).expect_err("run-time defense rejected");
    assert_eq!(e.code, Some(11), "E0011(vertical deep defense)");
}

/// Illegal transition 4: freeing an Opaque token → E0011 (externally owned; kerf has no right to free).
#[test]
fn negative_free_opaque_e11() {
    let table = test_table();
    // make_opaque (Opaque return) → Free (must reject)
    let prog = ffi_program(
        vec![
            Op::CallExternal {
                symbol: 0,
                n_args: 0,
            },
            Op::FreeExternal,
            Op::Halt,
        ],
        vec![sym_const("make_opaque")],
    );
    let e = run_ffi(&prog, &table).expect_err("Opaque release must rejected");
    assert_eq!(e.code, Some(11));
    assert!(
        e.message.contains("external held") || e.message.contains("Opaque"),
        "message: {}",
        e.message
    );
}

/// **case 12**: freeing a non-Foreign value (Int) → E0011 (type violation).
#[test]
fn negative_free_non_token_value_e11() {
    let e =
        free_external(&Value::Int(42), Span::dummy()).expect_err("non-token release must rejected");
    assert_eq!(e.code, Some(11));
    assert!(
        e.message.contains("Foreign token"),
        "message: {}",
        e.message
    );
}

/// case 12 generalization (second shape): freeing a Str value → E0011.
#[test]
fn negative_free_str_value_e11() {
    let e =
        free_external(&Value::Str(Rc::from("s")), Span::dummy()).expect_err("Str release rejected");
    assert_eq!(e.code, Some(11));
}

/// Illegal transition 6: unresolved symbol → E0012 (fail-closed).
#[test]
fn negative_symbol_unresolved_e12() {
    let table = test_table();
    let prog = call_str_program("no_such_fn", "x");
    let e = run_ffi(&prog, &table).expect_err("not registered symbol must failed");
    assert_eq!(e.code, Some(12), "E0012 code");
    assert!(
        e.message.contains("no_such_fn") && e.message.contains("symbol resolution failed"),
        "message: {}",
        e.message
    );
}

/// Default entry fail-closed: FFI opcodes under run_program (empty table)
/// → E0012 (the production run path has no FFI registration surface —
/// registration-surface explicitness).
#[test]
fn negative_default_entry_fail_closed_e12() {
    let prog = call_str_program("write_stdout", "x");
    let mut heap = Heap::new();
    let mut globals = HashMap::new();
    let e = run_program(&prog, &mut globals, &mut heap).expect_err("empty table fail-closed");
    assert_eq!(e.code, Some(12), "default entry E0012");
}

/// Argument-count mismatch (2 args vs 2 params positive-case control + a
/// 1-arg mismatch negative case):
/// 1 argument passed to two_params (2 params) → E0011.
#[test]
fn negative_arity_mismatch_e11() {
    let table = test_table();
    let e = call_external(
        &table,
        "two_params",
        &[Value::Int(1)],
        &mut Heap::new(),
        Span::dummy(),
    )
    .expect_err("arity error allocate must detected");
    assert_eq!(e.code, Some(11));
    assert!(
        e.message.contains("actual argument count mismatch"),
        "message: {}",
        e.message
    );
}

/// Zero-argument arity mismatch (capture takes exactly 1 param) → E0011.
#[test]
fn negative_zero_args_arity_mismatch_e11() {
    let table = test_table();
    let e = call_external(&table, "capture", &[], &mut Heap::new(), Span::dummy())
        .expect_err("zero actual argument arity error allocate");
    assert_eq!(e.code, Some(11));
}

/// CInt param ← Str argument → E0011 (marshalling type violation).
#[test]
fn negative_cint_arg_type_mismatch_e11() {
    let table = test_table();
    let e = call_external(
        &table,
        "double",
        &[Value::Str(Rc::from("s"))],
        &mut Heap::new(),
        Span::dummy(),
    )
    .expect_err("CInt formal parameter type violation");
    assert_eq!(e.code, Some(11));
    assert!(e.message.contains("CInt"), "message: {}", e.message);
}

/// CPointer param ← Int argument → E0011 (marshalling type violation — case 12 generalization).
#[test]
fn negative_cpointer_arg_type_mismatch_e11() {
    let table = test_table();
    let e = call_external(
        &table,
        "capture",
        &[Value::Int(7)],
        &mut Heap::new(),
        Span::dummy(),
    )
    .expect_err("CPointer formal parameter type violation");
    assert_eq!(e.code, Some(11));
    assert!(e.message.contains("CPointer"), "message: {}", e.message);
}

/// Host failure propagation: RuntimeError → VmError (E0004
/// runtime-generic family — the E7 I/O-channel failure caliber).
#[test]
fn negative_host_error_propagates_e0004() {
    let table = test_table();
    let prog = ffi_program(
        vec![
            Op::CallExternal {
                symbol: 0,
                n_args: 0,
            },
            Op::Halt,
        ],
        vec![sym_const("failing")],
    );
    let e = run_ffi(&prog, &table).expect_err("host failed must propagation");
    assert_eq!(e.code, None, "E0004 runtime pass use family(code None)");
    assert!(
        e.message.contains("external call failed"),
        "message: {}",
        e.message
    );
}

/// Opcode-surface defense: a CALL_EXTERNAL operand that is not a SymLit constant → VmError (defense).
#[test]
fn negative_symbol_operand_not_symlit() {
    let table = test_table();
    let prog = ffi_program(
        vec![
            Op::CallExternal {
                symbol: 0,
                n_args: 0,
            },
            Op::Halt,
        ],
        vec![BcConst::Int(5)],
    );
    let e = run_ffi(&prog, &table).expect_err("symbol operand defense");
    assert!(e.message.contains("SymLit"), "message: {}", e.message);
}

/// Stack defense: n_args exceeding stack depth → VmError (data-stack underflow defense).
#[test]
fn negative_stack_underflow_ffi_args() {
    let table = test_table();
    let prog = ffi_program(
        vec![
            Op::CallExternal {
                symbol: 0,
                n_args: 2,
            },
            Op::Halt,
        ],
        vec![sym_const("capture")],
    );
    let e = run_ffi(&prog, &table).expect_err("actual argument not sufficient defense");
    assert!(e.message.contains("underflow"), "message: {}", e.message);
}

/// lowering surface: a non-literal argument (Var) → compile-time rejection
/// (making the Stage 3 narrowing of the language surface explicit).
#[test]
fn negative_nonliteral_arg_rejected() {
    let mut st = SymbolTable::new();
    let sym = st.intern("write_stdout");
    let var = kerf_core::CoreExpr::Var {
        name: st.intern("buf"),
        scopes: kerf_syntax::ScopeSet::new(),
        span: Span::dummy(),
    };
    let e = compile_ffi_call_program(
        &FfiCall::CallExternal {
            symbol: sym,
            args: vec![var],
            return_type: ExternalType::CInt(CIntSize::Usize),
        },
        &st,
    )
    .expect_err("non-literal actual argument rejected");
    assert!(e.message.contains("literal"), "message: {}", e.message);
}

/// lowering surface: FreeExternal (argument being a runtime token value) →
/// rejected (execution surface = the Op::FreeExternal opcode — honest
/// narrowing note).
#[test]
fn negative_free_lowering_rejected() {
    let table = SymbolTable::new();
    let e = compile_ffi_call_program(
        &FfiCall::FreeExternal {
            ptr: kerf_core::CoreExpr::Literal {
                value: kerf_core::LiteralValue::Nil,
                span: Span::dummy(),
            },
        },
        &table,
    )
    .expect_err("FreeExternal lowering rejected");
    assert!(
        e.message.contains("runtime token"),
        "message: {}",
        e.message
    );
}

/// **case 3** anchor (CFunction = a shape, not a callback registration
/// surface) + CStruct: outside the Stage 2 VM consumption subset →
/// registration-surface rejection (honest narrowing).
#[test]
fn negative_cstruct_cfunction_registration_out_of_subset() {
    use kerf_driver::ffi::external_kind_supported;
    assert!(!external_kind_supported(&ExternalType::CFunction {
        param: Box::new(ExternalType::CInt(CIntSize::I64)),
        result: Box::new(ExternalType::CInt(CIntSize::I64)),
    }));
    assert!(!external_kind_supported(&ExternalType::CStruct(vec![
        ExternalType::CPointer(PointeeType::U8)
    ])));
    assert!(external_kind_supported(&ExternalType::CPointer(
        PointeeType::Char
    )));
}

/// **case 9** (error-propagation-path pin leak — tolerated): the loading
/// boundary fails midway (2nd argument Invalid) → the already-pinned 1st
/// argument slot leaks (permanent-root form; the symmetric side of the
/// zero-tolerance stance on mistaken reclamation).
#[test]
fn negative_error_path_pin_leak_tolerated_case9() {
    let mut table = test_table();
    table.register(
        "two_mixed",
        vec![ExternKind::CPointer, ExternKind::CPointer],
        ExternKind::CInt,
        |args| match args {
            [BorrowedArg::CharBuf(_), BorrowedArg::Token(_)] => Ok(HostRet::Int(0)),
            _ => Err(RuntimeError::new("two_mixed form mismatch")),
        },
    );
    let mut heap = Heap::new();
    let token = ExternalToken::from_boxed_slice(vec![0u8; 4].into_boxed_slice());
    free_external(&Value::External(Rc::clone(&token)), Span::dummy()).expect("first consume");
    let e = call_external(
        &table,
        "two_mixed",
        &[Value::Str(Rc::from("first")), Value::External(token)],
        &mut heap,
        Span::dummy(),
    )
    .expect_err("# 2 actual argument Invalid → E0010");
    assert_eq!(e.code, Some(10));
    assert_eq!(
        heap.pinned_refs().len(),
        1,
        "case 9: install load in way failed -- already pin slot leak capacity tolerate(permanent root form)"
    );
}

/// **case 9** (same shape as a C-side non-local jump — the panic unwind
/// path): host panic → window left unclosed → pin leak tolerated (unwind
/// does not break heap invariants).
#[test]
fn negative_panic_host_pin_leak_tolerated_case9() {
    let table = test_table();
    let mut heap = Heap::new();
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        let _ = call_external(
            &table,
            "panic_fn",
            &[Value::Str(Rc::from("x"))],
            &mut heap,
            Span::dummy(),
        );
    }));
    assert!(
        result.is_err(),
        "host panic to above propagation(non-local jump same type)"
    );
    assert_eq!(
        heap.pinned_refs().len(),
        1,
        "case 9: unwind path pin leak capacity tolerate(C longjmp same type -- permanent root)"
    );
    // Heap invariants unbroken: the subsequent unpin pairing can complete
    // (the leak is a tolerated state, not a corrupted one)
    let r = heap.pinned_refs()[0];
    heap.unpin_object(r)
        .expect("leak slot can explicit collection allocate for(non-corrupt broken)");
}

// ---------------------------------------------------------------------------
// U2 underflow (E8 caliber — direct test of the Heap API's Result surface)
// ---------------------------------------------------------------------------

/// U2: an unregistered unpin → Err (E8 caliber — a bookkeeping defect in
/// the boundary implementation; structural pairing guarantees user programs
/// cannot reach it).
#[test]
fn phi_u2_underflow_internal_error() {
    let mut heap = Heap::new();
    let s = heap.alloc_str(Rc::from("x"));
    let e = heap.unpin_object(s).expect_err("underflow must detected");
    assert!(
        e.message.contains("underflow") || e.message.contains("E8"),
        "message: {}",
        e.message
    );
}

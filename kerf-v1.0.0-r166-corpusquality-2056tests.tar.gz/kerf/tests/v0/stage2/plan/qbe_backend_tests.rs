// E6 close-out (r154 / 224-c1): corpus converted to the target-syntax face.
//! Batch G (r17) — QBE backend PoC integration tests (38-c).
//!
//! E6 skin notes (E6-CG §2 + the r154 / 224-b8 negative-literal ruling,
//! calibrated by running): the target face lexes `-N` as the unary-minus
//! application `(- N)` — the ANF primitive-arity face rejects it
//! ("primitive `-` argument count mismatch") — so negative literals in
//! this ANF-lowering domain use the binary `0 - N` carrier (classify(0 - 25)
//! / n < 0 - 10); expression-position if stays in primary position but is
//! parenthesized when a binary operator follows the else arm
//! (`(if (c) { a } else { b }) - 5` — the r110 ruling-2b form; without the
//! parens the trailing operator lexes into a fresh statement).
//!
//! **Coverage** (§9.4.3 positive:negative ratio ≥1:3 — native-code-path
//! dedicated negative cases carry the ratio):
//! - Positive cases: fib recursion end to end (IL generation structure +
//!   native run 144), arithmetic, value-context if (block-parameter
//!   merge/phi path), tail-position if, do, VM/native dual-path agreement;
//! - Negative cases: fn in value position (closure boundary), define of a
//!   non-fn, string/float/pair literals, assign, module, undefined
//!   functions, arity mismatch, free variables, first-class function-value
//!   passing;
//! - Toolchain: qbe lookup chain + AOT process errors.
//!
//! End-to-end tests depend on the in-repo `tools/qbe/bin/qbe` (38-b
//! placement) and the system `cc` — missing means failure (the §3.1
//! no-silent-skip caliber).

use kerf_backend::{build_native, find_qbe, gen_il, lower_program, run_native};
use kerf_driver::compile_source;

/// Compile source to ANF (front-end pipeline + lowering).
fn lower_src(src: &str) -> Result<kerf_backend::AnnotatedANF, kerf_backend::LowerError> {
    let out = compile_source(src, "<test>")
        .expect("frontend compile failed (test source should be well-formed)");
    lower_program(&out.core, &out.table)
}

/// Compile source → QBE IL text.
fn il_of(src: &str) -> String {
    gen_il(&lower_src(src).expect("lowering should succeed"))
}

/// Unique end-to-end artifact directories (parallel-test mutual-deletion
/// correction: sharing a pid directory + remove_dir_all would delete each
/// other's artifacts — measured in 38-c; isolation via an atomic counter).
static TEST_DIR_SEQ: std::sync::atomic::AtomicU32 = std::sync::atomic::AtomicU32::new(0);

/// Full AOT end to end: source → local executable run result (exit code).
fn native_exit_of(src: &str, stem: &str) -> i64 {
    let il = il_of(src);
    let qbe =
        find_qbe().expect("repository inner QBE should then position(sh scripts/qbe/setup.sh)");
    let seq = TEST_DIR_SEQ.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
    let out_dir =
        std::env::temp_dir().join(format!("kerf-qbe-test-{}-{}", std::process::id(), seq));
    let arts = build_native(&il, &out_dir, stem, &qbe).expect("AOT build should succeed");
    let r = run_native(&arts.exe_path).expect("run should succeed");
    let _ = std::fs::remove_dir_all(&out_dir); // delete only this test's own unique directory
    r
}

// ---------------------------------------------------------------------------
// Positive cases (≥5 — end to end + structural assertions)
// ---------------------------------------------------------------------------

#[test]
fn fib_end_to_end_native_code_matches_vm() {
    // §21.3 condition 3 anchor: the first non-VM backend — fib(12) recursive native code = 144
    let src =
        "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(12)\n";
    // VM side
    let vm = kerf_driver::run_source(src, "<test>").expect("VM path should succeed");
    let vm_val = match vm.value {
        kerf_vm::Value::Int(i) => i,
        ref other => panic!("VM artifact should be Int, actually {:?}", other),
    };
    assert_eq!(vm_val, 144);
    // native side (exit code fully visible: 144 < 256)
    assert_eq!(native_exit_of(src, "t_fib"), 144);
}

#[test]
fn fib_il_structure_contains_expected_ops() {
    // IL structural assertions (no process dependency): csltl comparison + recursive call + sub/add
    let il = il_of(
        "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(12)\n",
    );
    assert!(
        il.contains("function l $fib(l %t0)"),
        "function signature(carry return type): \n{}",
        il
    );
    assert!(il.contains("csltl"), "comparison instruction: \n{}", il);
    assert!(il.contains("call $fib"), "recursion call: \n{}", il);
    assert!(
        il.contains("sub %t0, 1"),
        "recursion minus actual argument: \n{}",
        il
    );
    assert!(il.contains("add"), "request and: \n{}", il);
    assert!(
        il.contains("export function l $main()"),
        "main export: \n{}",
        il
    );
    // Block labels: entry @l0 + branches @l1/@l2
    assert!(il.contains("@l0"));
    assert!(il.contains("jnz"), "condition jump: \n{}", il);
}

#[test]
fn arithmetic_end_to_end() {
    let src = "(2 + 3) * (10 - 4)\n";
    // 5 * 6 = 30
    assert_eq!(native_exit_of(src, "t_arith"), 30);
}

#[test]
fn value_context_if_merges_via_block_params() {
    // Value-context if: block-parameter merge (QBE's phi equivalent) — (if (1 < 2) { 10 } else { 20 }) - 5 = 5
    // (E6 skin: the primary-position if is parenthesized — the trailing binary
    // operator must not lex into a fresh statement)
    let src = "(if (1 < 2) { 10 } else { 20 }) - 5\n";
    let il = il_of(src);
    // phi shape: `%t3 =l phi @l1 %t1, @l2 %t2` (two sources, one instruction)
    assert!(
        il.contains("phi @l1"),
        "phi binding should appear: \n{}",
        il
    );
    assert!(
        il.contains("@l2 %t"),
        "phi #two come source should appear: \n{}",
        il
    );
    assert_eq!(native_exit_of(src, "t_ifval"), 5);
}

#[test]
fn begin_and_multiple_top_level_forms() {
    // do sequences + multiple toplevel forms (intermediate values discarded, the last value returned)
    // (E6 skin: the do call form do(e1, e2) carries the S-expr begin shape)
    let src = "do(1 + 2, 3 * 4)\n100 + 44\n";
    assert_eq!(native_exit_of(src, "t_begin"), 144);
}

#[test]
fn not_and_eq_prim_arithmetic_domain() {
    // not (translated as ceql x 0) + eq integer domain + nesting
    // (E6 skin: `(not (eq 3 4))` → `!(3 == 4)` — same not/eq primitive face)
    let src = "if (!(3 == 4)) { 77 } else { 88 }\n";
    assert_eq!(native_exit_of(src, "t_not"), 77);
}

#[test]
fn vm_native_consistency_on_multiple_programs() {
    // Dual-path agreement sampling (VM run vs native exit — integer value domain)
    let cases: Vec<(&str, i64)> = vec![
        ("20 + 22\n", 42),
        ("if (5 >= 5) { 1 } else { 2 }\n", 1),
        ("mod(100, 7)\n", 2), // 100 mod 7 = 2
        ("100 / 5\n", 20),
    ];
    for (src, expect) in cases {
        let vm = kerf_driver::run_source(src, "<t>").expect("VM succeeded");
        let vm_val = match vm.value {
            kerf_vm::Value::Int(i) => i,
            ref other => panic!("VM should produce Int: {:?}", other),
        };
        assert_eq!(vm_val, expect, "VM value:{}", src);
        assert_eq!(
            native_exit_of(src, "t_consist"),
            expect,
            "native value:{}",
            src
        );
    }
}

// ---------------------------------------------------------------------------
// Negative cases (≥7 — PoC boundaries and static validation, explicit errors not silent)
// ---------------------------------------------------------------------------

#[test]
fn negative_lambda_value_position_rejected() {
    // E6 skin: the closure call form — the callee is an Fn node (fn value
    // position), the PoC lower's direct-call-only face rejects it
    let src = "(|| (x: i64) { x })(5)\n";
    let e = lower_src(src).expect_err("fn value position set(callee-er)should reject");
    assert!(e.message.contains("callee-er"), "message: {}", e.message);
}

#[test]
fn negative_define_non_lambda_rejected() {
    let src = "let x = 5;\nx()\n";
    let e = lower_src(src).expect_err("define non- fn should reject");
    assert!(e.message.contains("define"), "message: {}", e.message);
}

#[test]
fn negative_string_literal_rejected() {
    let src = "1 + 2\n\"hello\"\n";
    let e = lower_src(src).expect_err("string literal should reject");
    assert!(e.message.contains("literal"), "message: {}", e.message);
}

#[test]
fn negative_float_literal_rejected() {
    let src = "1 + 2.5\n";
    let e = lower_src(src).expect_err("float literal should reject");
    assert!(e.message.contains("literal"), "message: {}", e.message);
}

#[test]
fn negative_setbang_rejected() {
    let src = "fn f(x: i64) { x = 5; x }\nf(1)\n";
    let e = lower_src(src).expect_err("assign should reject");
    assert!(e.message.contains("assign"), "message: {}", e.message);
}

#[test]
fn negative_module_form_rejected() {
    // E6 skin: module m { body } — the block face of (module m (import) (export) ...)
    let src = "module m { 1 + 2 }\n";
    let e = lower_src(src).expect_err("module should reject");
    assert!(e.message.contains("module"), "message: {}", e.message);
}

#[test]
fn negative_undefined_call_rejected() {
    // r46 / D49: unbound calls are front-rejected at compile time (E0022);
    // the backend lower's "not a defined function" is kept as
    // defense-in-depth (non-front paths)
    let src = "undefined_fn(1, 2)\n";
    let err = match kerf_driver::compile_source(src, "<qbe-neg>") {
        Ok(_) => panic!("compile-time should reject:{}", src),
        Err(e) => e,
    };
    assert!(
        err.rendered.contains("E0022") && err.rendered.contains("unbound reference"),
        "E0022 pre-rejection:{}",
        err.rendered
    );
}

#[test]
fn negative_arity_mismatch_rejected() {
    let src = "fn f(x: i64, y: i64) { x + y }\nf(1)\n";
    let e = lower_src(src).expect_err("arity mismatch should reject");
    assert!(
        e.message.contains("argument count"),
        "message: {}",
        e.message
    );
}

#[test]
fn negative_free_variable_rejected() {
    // r46 / D49: free variables are front-rejected at compile time (E0022);
    // the backend lower's "free variable" is kept as defense-in-depth
    let src = "fn f(x: i64) { x + y }\nf(1)\n";
    let err = match kerf_driver::compile_source(src, "<qbe-neg>") {
        Ok(_) => panic!("compile-time should reject:{}", src),
        Err(e) => e,
    };
    assert!(
        err.rendered.contains("E0022") && err.rendered.contains("unbound reference"),
        "E0022 pre-rejection:{}",
        err.rendered
    );
}

#[test]
fn negative_builtin_io_out_of_poc() {
    // print/IO-style builtins are not in the native-code PoC (B1 registered
    // — carried by the batch I FFI surface).
    // Note: the require prefix lets the front pass the capability gate
    // (E0006) — downgraded to a lowering rejection
    let src = "require io, write;\nprint(5)\n";
    let e = lower_src(src).expect_err("print should reject");
    assert!(e.message.contains("print"), "message: {}", e.message);
}

#[test]
fn negative_function_value_passing_rejected() {
    // Function names passed as values (first-class functions) unsupported
    let src = "fn f(x: i64) { x }\nf(f)\n";
    let e = lower_src(src).expect_err("function value transfer should reject");
    assert!(
        e.message.contains("function value") || e.message.contains("argument count"),
        "message: {}",
        e.message
    );
}

// ---------------------------------------------------------------------------
// Structural/contract surfaces (anf digest + require skipping + the empty program)
// ---------------------------------------------------------------------------

#[test]
fn require_forms_are_skipped_in_lowering() {
    // Zero runtime semantics (same caliber as VM bytecode — require emits no instructions)
    let ir = lower_src("require io, write;\n1 + 2\n").expect("require should jump exceeds");
    assert_eq!(ir.funcs.len(), 1); // main only
                                   // main body: a single call/add statement + Ret
    assert!(!ir.funcs[0].body.blocks.is_empty());
}

#[test]
fn empty_program_main_returns_zero() {
    let ir = lower_src("").expect("empty program should be legal");
    assert_eq!(ir.funcs.len(), 1);
    assert!(ir.funcs[0].name == "main");
    let il = gen_il(&ir);
    assert!(il.contains("ret 0"), "empty main return 0: \n{}", il);
    assert_eq!(native_exit_of("", "t_empty"), 0);
}

#[test]
fn anf_fingerprint_is_content_addressed() {
    // Same program → same fingerprint; different programs → different
    // fingerprints (content-addressed caliber — contract-field semantics)
    let a = lower_src("1 + 2\n").unwrap();
    let b = lower_src("1 + 2\n").unwrap();
    let c = lower_src("1 + 3\n").unwrap();
    assert_eq!(a.fingerprint, b.fingerprint);
    assert_ne!(a.fingerprint, c.fingerprint);
}

#[test]
fn nested_if_and_calls_compose() {
    // Nested if (outer value context + inner tail position) + multi-function composition
    // (E6 skin / b8 ruling: negative literals use the 0 - N carrier — the
    // target face lexes -N as unary minus, rejected by the ANF arity face)
    let src = "fn classify(n: i64) -> i64 { if (n < 0) { if (n < 0 - 10) { 111 } else { 112 } } else { n + 100 } }\nclassify(0 - 25)\n";
    assert_eq!(native_exit_of(src, "t_nested"), 111);
    let src2 = "fn classify(n: i64) -> i64 { if (n < 0) { if (n < 0 - 10) { 111 } else { 112 } } else { n + 100 } }\nclassify(44)\n";
    assert_eq!(native_exit_of(src2, "t_nested2"), 144);
}

// ---------------------------------------------------------------------------
// Existing-program regression surface (native-side sampling of all-green VM
// samples — compositions beyond fib)
// ---------------------------------------------------------------------------

#[test]
fn existing_examples_in_poc_domain_run_native() {
    // the fib corpus shape (the retired .krf face contained print —
    // outside the boundary) rewritten as pure fib within the PoC domain
    // (r153 / 223-c → E6 r154 / 224-c1: the target-syntax face — the inline
    // S-expr oracle duty is closed)
    let fib =
        "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(10)\n";
    assert_eq!(native_exit_of(fib, "t_fib10"), 55);
}

#[test]
fn lower_program_accepts_core_directly() {
    // API shape: core + table consumed directly (same input source as
    // compile_module — front-end output is backend input, a type-level
    // continuation of the target-neutrality principle)
    let out = compile_source("40 + 2", "<t>").unwrap();
    // r49 D59: front-end output = item sequence (same input source as
    // compile_module — a type-level continuation of the target-neutrality
    // principle)
    let ir = lower_program(&out.core, &out.table).unwrap();
    assert_eq!(ir.funcs.len(), 1);
    let il = gen_il(&ir);
    assert!(
        il.contains("add"),
        "primitive arithmetic should inline(non- call): \n{}",
        il
    );
}

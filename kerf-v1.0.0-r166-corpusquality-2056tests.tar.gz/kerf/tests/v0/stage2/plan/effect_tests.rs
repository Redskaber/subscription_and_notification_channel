// E6 close-out (r154 / 224-c1): corpus converted to the target-syntax face.
//! Effect language-surface integration tests (r25/42-f — batch I late
//! M1-M5 acceptance).
//!
//! **Acceptance contract** (plan.md §5a row 42-f + effect-language-design
//! §5 test anchors):
//! - Positive cases ≥6 (one per design anchor); negative cases ≥6
//!   (E0007/E0008/E0009 + expansion-phase E0002-family shapes + runtime type
//!   surfaces); positive:negative ratio ≥1:3 discipline (§9.4.3);
//! - M3 dual-path ≥8 (42-d new caliber: production chain (three
//!   self-hosted stages + VM) vs seed chain (three Rust stages + VM) — the
//!   T1 carrier surface for resume consistency after eval was retired);
//! - M5 GC six sources (live continuation frames — survival verification
//!   across allocation pressure).
//!
//! E6 skin notes (E6-CG §2 — examples/usage/effect*.ktf idioms, calibrated
//! by running): `perform NAME(args);` is a statement — value-position use
//! wraps in an `fn ask() { perform ...; }` callee; the handler arm body is
//! `resume(expr)` / `halt` / `pass` / a `{ ... }` block (the r128
//! allocate-before-resume idiom); a bare literal arm value needs the block
//! form (`t(p, k) => { 99 }`); the S-expr inner-define anchor (env
//! consistency) uses the let + captured-cell closure carrier (no inner
//! defines on the target face); the S-expr explicit-k resume
//! `(resume (head box) v)` maps onto the direct continuation call
//! `(head(box))(v)` (the desugared Apply face). Two S-expr runtime type
//! surfaces are unreachable from the target face (the Reader always
//! constructs a well-formed `(quote NAME . payload)` effect value —
//! perform-on-non-pair / non-symbol-tag) — those two tests were deleted
//! and recorded in the r154 worklog; the handler-clause shape family moved
//! to the Read stage (E0001) with the Reader's own message.

use crate::common::{assert_int, dual_path_agrees, run, run_rendered};
use kerf_vm::Value;

// ---------------------------------------------------------------------------
// Positive cases (design §5 anchors 1-6)
// ---------------------------------------------------------------------------

/// Anchor 1: single handler, single resume — perform suspends → dispatch →
/// resume injects the value.
#[test]
fn effect_single_handler_single_resume() {
    // (E6 skin: perform is a statement — the value-position perform wraps
    // in the ask() callee; the payload pair (add . 5) is the reader's
    // `perform add(5);` product)
    assert_int(
        "fn ask() -> i64 { perform add(5); }\nhandle (1 + ask()) { add(p, k) => resume(p + 10) }",
        16,
    );
}

/// Anchor 2: nested handle — an inner non-matching tag escapes to the
/// outer handler (the R11-dispatch rethrow chain).
#[test]
fn effect_nested_handle_escape_to_outer() {
    // (E6 skin: the non-matching inner arm yields a replacement value — the
    // block arm body `{ 42 }` carries the S-expr bare-literal clause)
    assert_int(
        "fn ask() -> i64 { perform outer(7); }\nhandle (handle ask() { inner(q, j) => { 42 } }) { outer(p, k) => resume(p) }",
        7,
    );
}

/// Anchor 3: pure computation inside handle with zero effects — the body's
/// completion value = the handle expression's value (R11-return).
#[test]
fn effect_pure_body_no_effect() {
    assert_int("handle (40 + 2) { t(p, k) => { 0 } }", 42);
}

/// Anchor 4: closure-environment consistency after resume — local variables
/// at the suspension point remain visible across resume through the shared
/// cell (continuation three-element ②: the suspension-point environment).
#[test]
fn effect_resume_env_consistency() {
    // assign x=1 before suspension; the handler resumes then assigns
    // x=100 — the B frame's local slot is shared (what the snapshot clones
    // is the Rc<GcCell> — the same cell): the resumed body reads x=100
    //
    // (E6 skin: the S-expr inner-define x uses the let + captured-cell
    // closure carrier — the protected body block assigns through the
    // shared capture, both post-handle reads see x=100)
    assert_int(
        "fn f() -> i64 { let x = 1; let body = || { x = 100; perform t(0); x }; (handle body() { t(p, k) => resume(0) }) + x }\nf()",
        200,
    );
}

/// Anchor 5: effect-value-first evaluation order (the Apply-order contract
/// 06 §1.3 A1 — the effect-value expression is fully evaluated before
/// PERFORM; the order is observable via counter side effects).
#[test]
fn effect_value_eval_order() {
    assert_int(
        "let n = 0;\nfn bump() -> i64 { n = n + 1; n }\nfn ask() -> i64 { perform t(bump()); }\nhandle (0 + ask()) { t(p, k) => resume(p + n) }",
        2,
    );
    // n has already been bumped to 1 before perform; the handler sees p=1
    // (payload=(t . 1)) → resume k (+ 1 1)=2; the effect-value-first
    // evaluation order lets the handler observe the side effect ✓
}

/// Anchor 6: TCO tail calls pass through the handler frame (D8 — frame-count
/// semantics unchanged; perform resumes normally after 100_000-deep tail
/// recursion — frame reuse is orthogonal to the effect-frame boundary).
#[test]
fn effect_tco_through_handler_frame() {
    assert_int(
        "fn spin(n: i64) -> i64 { if (n == 0) { perform s(99); } else { spin(n - 1) } }\nhandle spin(100000) { s(p, k) => resume(p + 1) }",
        100,
    );
}

// ---------------------------------------------------------------------------
// M3: dual-path agreement (the new T1 caliber — after the 42-d eval
// retirement: production chain vs seed chain, ≥8)
// ---------------------------------------------------------------------------

/// Dual-path group (effect behavior agreement between the seed and
/// self-hosted compile chains — a behavioral-surface cross-check beyond
/// bytecode_equal; covering resume/nesting/escape-negative-domain/closure
/// capture/multiple-effect chaining shapes).
#[test]
fn effect_dual_path_behaviors() {
    let cases = [
        // basic resume
        "fn ask() -> i64 { perform add(5); }\nhandle (1 + ask()) { add(p, k) => resume(p + 10) }",
        // nested escape
        "fn ask() -> i64 { perform outer(7); }\nhandle (handle ask() { inner(q, j) => { 42 } }) { outer(p, k) => resume(p) }",
        // pure body
        "handle (40 + 2) { t(p, k) => { 0 } }",
        // resume value = closure (the closure is invoked after continuation
        // resume — the apply2 carrier routes the suspended application)
        "fn mk(a: i64) -> T { || (b: i64) { a + b } }\nfn ask() -> T { perform t(0); }\nfn apply2(f: T) -> T { f(2) }\nhandle apply2(ask()) { t(p, k) => resume(mk(40)) }",
        // the handler does not resume (swallows the effect and yields a
        // replacement value — the block arm body carrier)
        "fn ask() -> i64 { perform t(0); }\nhandle (1 + ask()) { t(p, k) => { 99 } }",
        // multiple effects chained (two performs against two handlers —
        // shallow handling: let-value-position handles inside the fn body)
        "fn ask_t() -> i64 { perform t(1); }\nfn ask_t2() -> i64 { perform t2(1); }\nfn twice() -> i64 { let a = handle ask_t() { t(p, k) => resume(20) }; let b = handle ask_t2() { t2(p, k) => resume(21) }; a + b }\ntwice()",
        // capture sharing: the handler body references an outer global
        "let base = 40;\nfn ask() -> i64 { perform t(1); }\nhandle (1 + ask()) { t(p, k) => resume(p + base) }",
        // resume point deep in the call chain (frame-chain snapshot > 1 frame)
        "fn ask() -> i64 { perform t(5); }\nfn g(x: i64) -> i64 { x + ask() }\nfn f(y: i64) -> i64 { g(y) }\nhandle f(3) { t(p, k) => resume(p * 2) }",
    ];
    for (i, src) in cases.iter().enumerate() {
        assert!(
            dual_path_agrees(src),
            "dual-path mismatch (case {}: {:?})",
            i,
            src
        );
    }
}

/// eval domain (tree-walking path — the D7 escape mapping): dispatch/escape
/// programs without resume agree in value between the eval domain and the
/// production chain (the in-domain M3 surface — see the negative-case group
/// for the resume sentinel domain limit).
#[test]
fn effect_eval_domain_dispatch_agrees() {
    use kerf_driver::builtins::register_globals;
    use kerf_driver::capability::IoGrant;
    use kerf_expander::{expand_program, ExpandCtxt};
    use kerf_reader::read_source;
    use kerf_runtime::Heap;
    use kerf_syntax::SymbolTable;
    use kerf_vm::{eval_program, Env};

    let cases = [
        "fn ask() -> i64 { perform t(41); }\nhandle ask() { t(p, k) => { p + 1 } }",
        "fn ask() -> i64 { perform t(0); }\nhandle (1 + ask()) { t(p, k) => { 99 } }",
        "fn ask() -> i64 { perform outer(7); }\nhandle (handle ask() { inner(q, j) => { 0 } }) { outer(p, k) => { p + 2 } }",
    ];
    for (i, src) in cases.iter().enumerate() {
        // production chain
        let vm = match run(src) {
            Ok(v) => v,
            other => panic!("production chain failed(case {}): {:?}", i, other),
        };
        // eval domain (tree-walking)
        let mut table = SymbolTable::new();
        let stx = read_source(src, 0, &mut table).expect("read");
        let core = {
            let mut ctx = ExpandCtxt::new(table.clone());
            expand_program(&stx, &mut ctx).expect("expand")
        };
        // eval-domain global environment: driver builtin registration (no
        // I/O grant — fail-closed like the production caliber; effect
        // programs need no io)
        let globals = register_globals(&mut table, &IoGrant::none());
        let env = Env::new();
        for (sym, val) in globals {
            env.define(sym, val);
        }
        let mut heap = Heap::new();
        let ev = eval_program(&core, &env, &mut heap)
            .map_err(|e| format!("{:?}(effect={:?})", e.message, e.effect.is_some()))
            .unwrap_or_else(|e| panic!("eval domain failed(case {}): {}", i, e));
        match (&vm, &ev) {
            (Value::Int(a), Value::Int(b)) => assert_eq!(a, b, "eval domain mismatch (case {})", i),
            other => panic!("value form abnormal(case {}): {:?}", i, other),
        }
    }
}

// ---------------------------------------------------------------------------
// Negative cases (the negative domains of design §5 anchors 1-6 —
// E0007/E0008/E0009 + E0002 shapes + type surfaces)
// ---------------------------------------------------------------------------

/// Assert the run fails and the rendering contains the given substring (structured-code text anchor).
fn expect_run_err(src: &str, needle: &str) {
    let out = run_rendered(src);
    assert!(
        out.starts_with("<error:") && out.contains(needle),
        "expected error containing `{}`, got: {}",
        needle,
        out
    );
}

/// E0007: an unhandled effect escapes to toplevel (D9 — includes the tag name).
/// (E6 skin: a bare top-level `perform oops(1);` statement — the direct
/// carrier of the S-expr `(perform (cons 'oops 1))`)
#[test]
fn negative_unhandled_escape_e0007() {
    expect_run_err("perform oops(1);", "error[E0007]");
    expect_run_err("perform oops(1);", "is not handled by any handler");
}

/// E0008: double resumption of a continuation (D3 linear uniqueness —
/// includes first-resume position tracking).
/// (E6 skin: the r128 allocate-before-resume block idiom — `k2 = k;`
/// captures the continuation into a global cell, `resume(1)` fires the
/// first recovery, the trailing top-level `k2(2)` call recovers it again)
#[test]
fn negative_double_resume_e0008() {
    let src = "let k2 = ();\nfn ask() -> i64 { perform t(5); }\nhandle ask() { t(p, k) => { k2 = k; resume(1) } }\nk2(2)";
    expect_run_err(src, "error[E0008]");
    expect_run_err(src, "recovered twice");
}

/// E0009: the resume arity surface (a continuation call takes exactly one
/// argument — the D4 call-shape constraint; the block arm body calls the
/// resume binder directly with zero arguments).
#[test]
fn negative_resume_arity_e0009() {
    expect_run_err(
        "fn ask() -> i64 { perform t(1); }\nhandle ask() { t(p, k) => { k() } }",
        "error[E0009]",
    );
}

/// A non-continuation value applied ((resume 5 42) desugars to (5 42) —
/// the not-callable type surface falls into the E0004 generic family; the
/// effect context is visible in the error message).
/// (E6 skin: the desugared Apply face itself — `5(42)` — the `resume`
/// keyword is only parseable inside handler arm bodies on the target face,
/// so the S-expr non-continuation resume maps onto the direct application)
#[test]
fn negative_resume_non_continuation() {
    expect_run_err("5(42)", "uncallable value");
}

/// Expansion-phase handler-clause shape validation (design negative case 4
/// — the ((p r) result) shape). E6 skin: the target Reader grammar-enforces
/// the arm shape — the family moved to the Read stage (E0001) with the
/// Reader's own message (same discipline as negative_expander_tests).
#[test]
fn negative_handler_clause_shape_e0002() {
    expect_run_err("handle (2) { t(p) => resume(1) }", "error[E0001]");
    expect_run_err(
        "handle (2) { t(p) => resume(1) }",
        "handle arm binding must be two-element",
    );
}

// (Retired with the S-expr face — E6 / r154 / 224-c1, 2 tests:
// `negative_perform_non_pair_payload` and `negative_perform_non_symbol_tag`.
// The target Reader always constructs a well-formed
// `(perform (cons (quote NAME) payload))` effect value — the non-pair
// payload and non-symbol tag runtime type surfaces are unreachable from
// the target face; the malformed-effect-name rejection duty is carried by
// the Read-stage guard ("expected an effect name, got Int(7)").)

// ---------------------------------------------------------------------------
// M5: GC six sources (live continuation frames — survival across allocation pressure)
// ---------------------------------------------------------------------------

/// The suspended payload (Pair) survives heavy allocation inside the
/// handler body (multiple GC rounds) — root scanning of the dispatch
/// frame's locals (the sixth source).
/// (E6 skin: the r128 allocate-before-resume block idiom
/// `{ mk(50000); resume(...) }` — examples/usage/effect_stress.ktf)
#[test]
fn gc_payload_survives_alloc_pressure() {
    assert_int(
        "fn mk(n: i64) -> T { if (n == 0) { () } else { cons(n, mk(n - 1)) } }\nfn ask() -> i64 { perform t(cons(41, 0)); }\nhandle (0 + ask()) { t(p, k) => { mk(50000); resume(head(p) + 1) } }",
        42,
    );
}

/// A boxed continuation (the Pair's ForeignBox shape) survives GC pressure —
/// unboxing resumes it + behavior is correct after resume (the M5
/// box-unbox-survive full chain).
/// (E6 skin: the S-expr explicit-k resume `(resume (head box) (+ (tail box) 1))`
/// maps onto the desugared direct continuation application
/// `(head(box))(tail(box) + 1)` — the block arm-body tail)
#[test]
fn gc_continuation_boxed_survives_alloc_pressure() {
    assert_int(
        "fn mk(n: i64) -> T { if (n == 0) { () } else { cons(n, mk(n - 1)) } }\nlet box = ();\nfn ask() -> i64 { perform t(0); }\nhandle (0 + ask()) { t(p, k) => { box = cons(k, 41); mk(60000); (head(box))(tail(box) + 1) } }",
        42,
    );
}

// ---------------------------------------------------------------------------
// 48-b (r28/49-a): effect static convergence — typecheck.rs/hm.rs
// sub-expression traversal
//
// Deep-review D3/D8 "Unknown relaxation surface" coverage-gap closure:
// Perform effect values / Handle bodies and handler bodies enter the R1-R8
// and constraint-set detection domains (result types stay Unknown/Dynamic —
// row polymorphism honestly remains a Stage 3 boundary); binders'
// payload/resume are stamped with dynamic values (the zero-false-positive
// conservative contract is preserved).
// ---------------------------------------------------------------------------

use kerf_compiler::check_program;
use kerf_compiler::hm::hm_check_program;
use kerf_driver::builtins::builtin_sigs;
use kerf_driver::compile_source;

/// Conservative check surface (the R1-R8 production surface — typecheck.rs via check_program).
fn tc_msgs(src: &str) -> Vec<String> {
    let out = compile_source(src, "<effect-static>")
        .unwrap_or_else(|e| panic!("frontend compile failed:{}", e));
    let mut table = out.table;
    let sigs = builtin_sigs(&mut table);
    check_program(&out.core, &sigs, &table)
        .into_iter()
        .map(|d| d.message)
        .collect()
}

/// HM PoC surface (hm.rs — same source as the r18 offline entry).
fn hm_msgs(src: &str) -> Vec<String> {
    let out = compile_source(src, "<effect-static-hm>")
        .unwrap_or_else(|e| panic!("frontend compile failed:{}", e));
    let mut table = out.table;
    let sigs = builtin_sigs(&mut table);
    hm_check_program(&out.core, &sigs, &table)
        .diags
        .into_iter()
        .map(|d| d.message)
        .collect()
}

/// Both-surface detection (superset discipline — continuing the r18 Gate A
/// caliber: the tc surface reports → the hm surface also reports).
fn both_detect(src: &str, needle: &str) {
    let tc = tc_msgs(src);
    assert!(
        tc.iter().any(|m| m.contains(needle)),
        "tc face not detected `{}`; actual {:?}\n program: {}",
        needle,
        tc,
        src
    );
    let hm = hm_msgs(src);
    assert!(
        hm.iter().any(|m| m.contains(needle)),
        "hm face not detected `{}`; actual {:?}\n program: {}",
        needle,
        hm,
        src
    );
}

/// Perform effect-value static violations (R2/R1 — effect-value
/// expressions enter the detection domain).
#[test]
fn static_perform_effect_value_violations() {
    both_detect("perform op(1 + \"a\");", "requires a number");
    both_detect(
        "perform op(if (\"x\") { 1 } else { 2 });",
        "if condition requires bool",
    );
}

/// Handle handler-body static violations (R5 — clause bodies enter the detection domain).
/// (E6 skin: the block arm body `{ ... }` carries the S-expr bare-expression
/// handler clause)
#[test]
fn static_handler_body_violations() {
    both_detect(
        "fn ask() -> i64 { perform t(0); }\nhandle ask() { t(p, k) => { head(42) } }",
        "head requires pair",
    );
    both_detect(
        "fn ask() -> i64 { perform t(0); }\nhandle ask() { t(p, k) => { tail(\"s\") } }",
        "tail requires pair",
    );
}

/// Handle-body static violations (R1 — the protected computation enters
/// the detection domain) + both-body multi-error collection.
#[test]
fn static_handle_body_violations() {
    both_detect(
        "handle (if (1) { 2 } else { 3 }) { t(p, k) => resume(0) }",
        "if condition requires bool",
    );
    // one violation each in the handler body (R2) + the handle body (R1)
    // → both-surface multi-error collection
    let src = "handle (if (1) { 2 } else { 3 }) { t(p, k) => { \"b\" + 2 } }";
    let tc = tc_msgs(src);
    assert!(
        tc.iter().any(|m| m.contains("requires a number"))
            && tc.iter().any(|m| m.contains("if condition requires bool")),
        "tc face expected dual violation collection, got {:?}",
        tc
    );
    let hm = hm_msgs(src);
    assert!(
        hm.len() >= 2,
        "hm face expected ≥2 diagnostic, got {:?}",
        hm
    );
}

/// Zero-false-positive control (conservative contract preserved — the six
/// r25 positive cases + binder dynamic use sites + the M5 corpus).
#[test]
fn static_effect_zero_false_positive() {
    let corpus = [
        // The six design §5 positive cases (same-source corpus as r25 —
        // zero diagnostics on the static surface)
        "fn ask() -> i64 { perform add(5); }\nhandle (1 + ask()) { add(p, k) => resume(p + 10) }",
        "fn ask() -> i64 { perform outer(7); }\nhandle (handle ask() { inner(q, j) => { 42 } }) { outer(p, k) => resume(p) }",
        "handle (40 + 2) { t(p, k) => { 0 } }",
        "fn f() -> i64 { let x = 1; let body = || { x = 100; perform t(0); x }; (handle body() { t(p, k) => resume(0) }) + x }\nf()",
        "let n = 0;\nfn bump() -> i64 { n = n + 1; n }\nfn ask() -> i64 { perform t(bump()); }\nhandle (0 + ask()) { t(p, k) => resume(p + n) }",
        "fn spin(n: i64) -> i64 { if (n == 0) { perform s(99); } else { spin(n - 1) } }\nhandle spin(100000) { s(p, k) => resume(p + 1) }",
        // Binder dynamic use sites (arithmetic and pairs on Unknown/Dynamic
        // payloads — zero false positives)
        "fn ask() -> i64 { perform t(1); }\nhandle ask() { t(p, k) => resume(cons(head(p), tail(p))) }",
        "fn ask() -> i64 { perform t(1); }\nhandle ask() { t(p, k) => { p + 0 } }",
    ];
    for (i, src) in corpus.iter().enumerate() {
        let tc = tc_msgs(src);
        assert!(
            tc.is_empty(),
            "tc face false positive(case {}): {:?}\n program: {}",
            i,
            tc,
            src
        );
        let hm = hm_msgs(src);
        assert!(
            hm.is_empty(),
            "hm face false positive(case {}): {:?}\n program: {}",
            i,
            hm,
            src
        );
    }
    // M5 effect corpus (r153 / 223-c: the corpus leg switched to the .ktf
    // single face — the .krf corpus retired, s-expr-removal-plan §4 Batch
    // D; deep recursion + binder dynamic use sites on the production
    // face; the static faces are syntax-invariant downstream)
    let stress = std::fs::read_to_string("examples/usage/effect_stress.ktf")
        .expect("read effect_stress.ktf failed");
    let out = compile_source(&stress, "effect_stress.ktf")
        .expect("frontend compile failed (corpus should be well-formed)");
    let mut table = out.table.clone();
    let sigs = builtin_sigs(&mut table);
    let tc = check_program(&out.core, &sigs, &table)
        .into_iter()
        .map(|d| d.message)
        .collect::<Vec<_>>();
    assert!(
        tc.is_empty(),
        "tc face for effect_stress false positive: {:?}",
        tc
    );
    let mut table = out.table;
    let sigs = builtin_sigs(&mut table);
    let hm = hm_check_program(&out.core, &sigs, &table)
        .diags
        .into_iter()
        .map(|d| d.message)
        .collect::<Vec<_>>();
    assert!(
        hm.is_empty(),
        "hm face for effect_stress false positive: {:?}",
        hm
    );
}

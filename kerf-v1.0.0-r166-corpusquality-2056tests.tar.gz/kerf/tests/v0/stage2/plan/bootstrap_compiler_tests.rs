// E6 close-out (r154 / 224-c1): corpus converted to the target-syntax face.
//! I1 self-hosted Compiler parity suite (Stage 2 batch I / Task 42-b + 42-c + 42-d).
//!
//! E6 skin notes (E6-CG §2, calibrated by running): the top-level let
//! expression legs use the IIFE `(|| { let ...; body })()` carrier; the
//! do call form `do(e1, e2)` reproduces the S-expr begin shape verbatim
//! (top-level do-splice classification keeps the define-inside-do leg
//! positive); quoted-list datums have no target literal (r127 honest
//! boundary) — the quote legs keep the symbol/nested-quote/vector-datum
//! surface; negative int/float literals lex as unary-minus applications
//! (no negative literal token on the target face — the literal legs keep
//! positive constants; the b8 `0 - N` carrier covers negative values in
//! arithmetic); `$`-bearing hygiene names are outside the target
//! identifier charset (the explicit `x$hyg$3` leg retired — the macro
//! corpus covers the hygiene-renamed global product); letrec/cond/when/
//! unless/while have no target surface — rewritten to top-level fn
//! recursion / if-else chains / IIFE let chains per E6-CG §2; module
//! bodies admit items and expression sequences but no let statements
//! (the shapes module's let leg is the tail expression).
//!
//! Acceptance gates (plan §5a rows 42-b/42-c/42-d + i1-incision-migration-design
//! §4 S1/S2/S3 + §5 three-layer gates):
//! - **Structural parity (Gate A)**: on the same CoreExpr input, the
//!   self-hosted Compiler (compiler.krf, running on the VM) and the seed
//!   Compiler (kerf-compiler/compile.rs, Rust) agree on full structure via
//!   `BcProgram::bytecode_equal` (INC5: including protos/consts/global_refs/
//!   debug_spans — byte-identical with no gray zone);
//!   42-c extension group: the nine sugar forms + the module/require arms +
//!   macro corpus + prelude injection order (preamble.krf real corpus) + all
//!   six examples on both paths;
//! - **Error parity**: negative-case corpus (define in expression position
//!   inside a function body — D1 global-leak protection) with message +
//!   Span(start,end) verbatim-identical (E1 same-caliber boundary:
//!   expansion_id does not participate in the error criterion — bridge-side
//!   ('err msg s e) three-field contract, same-shape precedent in
//!   bootstrap_expander);
//! - **Behavioral surface**: self-hosted compile-stage output executed on
//!   the VM = production pipeline (self-hosted front end + seed compile
//!   stage) results — an end-to-end proof of compile-stage executability
//!   (42-c extension: sugar + module semantics);
//! - **Gate B self-hosting consistency (42-d / §21.3 condition 2)**: the
//!   .krf-chain gate B tests (fixpoint + B₁ executability) were **retired
//!   by the E5 close-out cleanup batch** (r120 / 190-a, principle 41 — the
//!   four S-expr bootstrap originals were deleted after the switch window's
//!   five steps completed with validation equivalence green); their
//!   verification duty migrated wholesale to the .ktf fixpoint gate family
//!   (`switch_corpus_parity_tests::ktf_corpus_fixpoint_*` — the step-④
//!   three gates: B₁'/B₂' full-structure equality + SHA-256 + cross-chain
//!   by-name oracle + B₁'-chain executability — plus the step-⑤
//!   three-stage transitivity gate in `switch_step5_validation_tests`);
//!   i1-design §5 Gate B semantics live on in the target-syntax domain;
//! - **Determinism discipline** (§7/B8): two self-hosted compiles of the
//!   same input are byte-identical.
//!
//! Clauses followed: §9.4.3 (positive/negative cases paired), §7.1
//! (integration validation ≥3), §2.3-11 (measure first, no speculation —
//! all assertions compared by actually running both implementations), §21.3
//! (Gate A is the stage-level precondition for condition 2; Gate B is the
//! final check for condition 2).

use kerf_compiler::compile_module as seed_compile;
use kerf_driver::bootstrap::compiler::compile_module as bootstrap_compile;
use kerf_driver::bootstrap::expander::expand_program as bootstrap_expand;
use kerf_driver::bootstrap::reader::read_source_for_bootstrap as bootstrap_read;
use kerf_driver::bootstrap::reader::read_source_for_bootstrap;
use kerf_driver::builtins::register_globals;
use kerf_driver::capability::IoGrant;
use kerf_driver::run_source;
use kerf_expander::{expand_program as seed_expand, ExpandCtxt};
use kerf_runtime::Heap;
use kerf_syntax::SymbolTable;
use kerf_vm::run_program;

// ---- parity walkthrough ----

/// Seed pipeline front end: source → Stx → CoreExpr (both compile paths
/// share the same input — the compile stage is the only variable under test;
/// file_id = 0 uniformly (table parameterization for the span-equality
/// criterion)).
fn seed_front(src: &str) -> (Vec<kerf_core::ModuleItem>, SymbolTable) {
    let mut table = SymbolTable::new();
    let forms = bootstrap_read(src, 0, &mut table).expect("read failed");
    // r47 visibility tightening: mirrors driver 1.68
    // (strip_toplevel_imports — corpus .krf toplevel imports are
    // zero-runtime-semantics organizational declarations; the production
    // front strips them before expand; this helper, which calls seed_expand
    // directly, must mirror the same behavior, otherwise corpus toplevel
    // imports spuriously trigger E0002 [mid-body determination] — preserving
    // positive-case corpus validity)
    let is_toplevel_import = |f: &kerf_syntax::Stx| -> bool {
        f.datum
            .as_list()
            .map(|l| {
                !l.is_empty()
                    && l[0]
                        .datum
                        .as_symbol()
                        .map(|s| table.name(s) == "import")
                        .unwrap_or(false)
            })
            .unwrap_or(false)
    };
    let forms: Vec<kerf_syntax::Stx> = forms
        .into_iter()
        .filter(|f| !is_toplevel_import(f))
        .collect();
    let mut ectx = ExpandCtxt::new(table);
    let core =
        seed_expand(&forms, &mut ectx).expect("expand failed(corpus should be positive case)");
    (core, ectx.table)
}

/// Gate A parity assertion: on the same CoreExpr input, seed vs self-hosted
/// compile — `bytecode_equal` full structural agreement (INC5).
fn parity(src: &str) {
    let (core, mut table) = seed_front(src);
    let a = seed_compile(&core).expect("seed compile failed(corpus should be positive case)");
    let b = bootstrap_compile(&core, 0, &mut table)
        .unwrap_or_else(|e| panic!("bootstrap compile failed(src: {:?}): {}", src, e.message));
    let rs = |s: kerf_syntax::Symbol| -> String {
        match s.0 {
            x if x == u32::MAX - 1 => "<main>".to_string(),
            x if x == u32::MAX - 2 => "<fn>".to_string(),
            _ => table.name(s).to_string(),
        }
    };
    assert!(
        a.bytecode_equal(&b),
        "parity failed(src: {:?})\n== seed ==\n{}\n== bootstrap ==\n{}",
        src,
        kerf_compiler::disassemble_program(&a, &rs),
        kerf_compiler::disassemble_program(&b, &rs),
    );
}

/// Seed pipeline front end, target-syntax variant (r153 / 223-c: the
/// usage-corpus parity leg switched to the .ktf single face — the read
/// stage goes through the production reader bridge
/// reader.ktf, the Reader fixpoint; the import-strip mirror and
/// the compile-parity discipline are verbatim from [`seed_front`]).
fn seed_front_reader(src: &str) -> (Vec<kerf_core::ModuleItem>, SymbolTable) {
    let mut table = SymbolTable::new();
    let forms = read_source_for_bootstrap(src, 0, &mut table)
        .expect("target read failed(corpus should be positive case)");
    let is_toplevel_import = |f: &kerf_syntax::Stx| -> bool {
        f.datum
            .as_list()
            .map(|l| {
                !l.is_empty()
                    && l[0]
                        .datum
                        .as_symbol()
                        .map(|s| table.name(s) == "import")
                        .unwrap_or(false)
            })
            .unwrap_or(false)
    };
    let forms: Vec<kerf_syntax::Stx> = forms
        .into_iter()
        .filter(|f| !is_toplevel_import(f))
        .collect();
    let mut ectx = ExpandCtxt::new(table);
    let core =
        seed_expand(&forms, &mut ectx).expect("expand failed(corpus should be positive case)");
    (core, ectx.table)
}

/// Gate A parity assertion, target-syntax corpus variant: on the same
/// CoreExpr input (read through the production reader bridge),
/// seed vs self-hosted compile — `bytecode_equal` full structural
/// agreement (INC5; the compile stage remains the only variable under
/// test).
fn parity_target(src: &str) {
    let (core, mut table) = seed_front_reader(src);
    let a = seed_compile(&core).expect("seed compile failed(corpus should be positive case)");
    let b = bootstrap_compile(&core, 0, &mut table)
        .unwrap_or_else(|e| panic!("bootstrap compile failed(src: {:?}): {}", src, e.message));
    let rs = |s: kerf_syntax::Symbol| -> String {
        match s.0 {
            x if x == u32::MAX - 1 => "<main>".to_string(),
            x if x == u32::MAX - 2 => "<fn>".to_string(),
            _ => table.name(s).to_string(),
        }
    };
    assert!(
        a.bytecode_equal(&b),
        "parity failed(src: {:?})\n== seed ==\n{}\n== bootstrap ==\n{}",
        src,
        kerf_compiler::disassemble_program(&a, &rs),
        kerf_compiler::disassemble_program(&b, &rs),
    );
}

/// Negative-case parity assertion (r49 D59 semantics-preserving migration:
/// define-position discipline moved forward to the expander's structural
/// dispatch point — E0003-caliber message kept verbatim, both paths
/// [seed expander vs self-hosted expander] report the same; message +
/// Span(start,end) verbatim-identical — E1 same-caliber boundary:
/// expansion_id does not participate in the error criterion).
fn parity_err(src: &str) {
    let mut ta = SymbolTable::new();
    let fa = bootstrap_read(src, 0, &mut ta).expect("oracle read failed");
    let mut ectx = ExpandCtxt::new(ta);
    let ea = seed_expand(&fa, &mut ectx)
        .expect_err("seed should report an error(corpus should be a negative case)");
    let mut tb = SymbolTable::new();
    let fb = bootstrap_read(src, 0, &mut tb).expect("bootstrap read failed");
    let eb = bootstrap_expand(&fb, 0, &mut tb)
        .expect_err("bootstrap should report an error(corpus should be a negative case)");
    assert_eq!(
        ea.message, eb.message,
        "error message mismatch (src: {:?})",
        src
    );
    assert_eq!(
        (ea.span.start, ea.span.end),
        (eb.span.start, eb.span.end),
        "error Span mismatch (src: {:?}): {}..{} vs {}..{}",
        src,
        ea.span.start,
        ea.span.end,
        eb.span.start,
        eb.span.end
    );
}

/// Behavioral-surface assertion: self-hosted front end (read + expand) +
/// self-hosted compile-stage output executed on the VM agrees with
/// run_source (production pipeline = self-hosted front end + seed compile
/// stage) — the compile stage is the only variable under test.
fn behavior(src: &str) {
    let expected = run_source(src, "behavior.ktf").expect("production pipeline failed");
    let mut t = SymbolTable::new();
    let forms = bootstrap_read(src, 0, &mut t).expect("read failed");
    let core = bootstrap_expand(&forms, 0, &mut t).expect("bootstrap expansion failed");
    let program = bootstrap_compile(&core, 0, &mut t).expect("bootstrap compile failed");
    // Behavior corpus has no I/O (pure arithmetic/control flow/closures) —
    // empty grant (R9 fail-closed)
    let mut globals = register_globals(&mut t, &IoGrant::none());
    let mut heap = Heap::new();
    let actual = run_program(&program, &mut globals, &mut heap)
        .expect("bootstrap artifact execution failed");
    assert!(
        actual.eq_value(&expected.value),
        "behavior mismatch (src: {:?}): {:?} vs {:?}",
        src,
        kerf_vm::render_value(&actual, &heap),
        kerf_vm::render_value(&expected.value, &expected.heap)
    );
}

// ---- positive-case parity: literals and the constant pool ----

#[test]
fn parity_literals() {
    // (E6 skin: negative int/float literals have no target token — the
    // `-7`/`-0.5` legs keep their positive-constant counterparts; the
    // negative-value compile surface is carried by the `0 - N` legs below)
    for src in [
        "42", "7", "3.5", "0.5", "\"hi\"", "\"\"", "true", "false", "()", "0 - 7", "0 - 0.5",
    ] {
        parity(src);
    }
}

#[test]
fn parity_quote_symbols_and_pairs() {
    // (E6 skin: quoted-list datums have no target literal — the r127
    // honest boundary, already registered with the corpus family in
    // vm_tests; the reachable quote surface = symbol datums + nested
    // quotes + the unit/nil datum + vector datums (r138 / 208-c — the
    // D2-a/D2-b desugar products, the quote-position analog of the pair
    // recursion surface))
    for src in [
        "quote(sym)",
        "quote(sym)", // 'sym → same single quote surface
        "quote(())",
        "[1, 2, 3]",
        "quote([a, [b, 3]])",
        "[1, [2, 3], [4, [5, 6]]]",
        "[[1, 2], [3, [4, 5]]]",
        "quote([sym, \"str\", 1, 2.5, true])",
        "quote(quote(x))",
        "quote(quote(x, y))",
    ] {
        parity(src);
    }
}

#[test]
fn parity_const_pool_dedup() {
    // Constant pool deduplication (§19.3 pitfall: (do 1 1 1) does not
    // bloat — mirrors the assoc list's insert-at-front order)
    parity("do(1, 1, 1)");
    parity("do(\"a\", \"a\", 1, \"a\")");
    parity("list(1, 1.5, 1, 1.5)");
    parity("do(quote(x), quote(x), quote(y))");
}

// ---- positive-case parity: variables / define / assign ----

#[test]
fn parity_vars_define_globals() {
    parity("x");
    parity("let x = 5;");
    parity("let x = 5; x");
    parity("let x = 5; let y = x; y");
    // (E6 skin: the explicit `x$hyg$3` leg retired — `$` is outside the
    // target identifier charset; the hygiene-renamed-global product stays
    // covered by the macro corpus below)
}

#[test]
fn parity_if_jumps() {
    parity("if (true) { 1 } else { 2 }");
    parity("if (x) { 1 } else { 2 }");
    parity("if (x) { 1 }");
    parity("if (1 == 2) { 1 } else { if (true) { 2 } else { 3 } }");
    parity("if (x) { if (y) { 1 } else { 2 } } else { if (z) { 3 } else { 4 } }");
    parity("fn f(n: i64) { if (n < 2) { n } else { f(n - 1) + f(n - 2) } }");
}

#[test]
fn parity_begin() {
    parity("do()");
    parity("do(1)");
    parity("do(1, 2, 3)");
    parity("do(1, do(2, 3), 4)");
    // do-splice: the top-level do call carries the S-expr begin shape
    // verbatim — the item classifier splices the define out (the define
    // inside the do stays a legal declaration item at top level)
    parity("do(if (x) { 1 } else { 2 }, define(y, 2), y)");
}

// ---- positive-case parity: Fn / closure capture (B3 hardest-stage specialized corpus) ----

#[test]
fn parity_lambda_basic() {
    parity("||(x: i64) { x }");
    parity("(|| (x: i64) { x })(5)");
    parity("fn f(x: i64, y: i64) { x + y } f(1, 2)");
    parity("|| { 1 }");
    parity("||(a: i64, b: i64, c: i64) { list(a, b, c) }");
}

#[test]
fn parity_lambda_nested_captures() {
    // Nested closure capture (design §4 S1 specialized case)
    parity("fn f(x: T) { || (y: T) { x(y) } } f(3)");
    // Three-level capture chain: the innermost level references the outermost
    // parameter (passing through the shared Captured source)
    // (E6 skin: the inner-define chain uses let-bound closures — no inner
    // defines on the target face, the same capture-chain surface)
    parity(
        "fn a(x: i64) { let b = || (y: i64) { let c = || (z: i64) { x + y + z }; c(1) }; b(2) } a(3)",
    );
    // Same-level double capture (capture order = first-occurrence order of free variables)
    parity("fn f(x: i64, y: i64) { || { list(x, y) } } f(1, 2)");
    // Parameter shadowing (shadow-pop caliber mirrored bit for bit)
    parity("(|| (x: i64) { (|| (x: i64) { x })(3) })(4)");
    // Capture coexisting with global references (Global zero-capture + free_vars union caliber)
    parity("fn f(x: i64) { || (y: i64) { x + g } } let g = 1; f(2)");
}

#[test]
fn parity_lambda_set_bang_paths() {
    // assign three paths: local / captured / global (resolution shares the same caliber as Var)
    parity("fn f() { let x = 1; x = 5; x } f()");
    // Captured write propagation (shared mutable cell — lexical closure semantics)
    parity(
        "fn make_counter() { let n = 0; || { n = n + 1; n } } let c = make_counter(); c(); c(); c()",
    );
    // Global assign
    parity("let x = 1; x = 9; x");
    // (E6 skin: assign is a statement on the target face — the S-expr
    // assign-as-expression leg `(+ (assign x 3) x)` is the statement + tail
    // rewrite; the DUP stack-balance carrier stays on the VM side)
    parity("fn f(x: i64) { x = 3; x + x } f(1)");
}

// ---- positive-case parity: Apply / tail-position threading (B9 TCO must-include surface) ----

#[test]
fn parity_app_eval_order() {
    // Evaluation-order contract (§19.5 invariant 3): callee first, arguments left to right
    parity("f(a, b, c)");
    parity("f(g(1), h(2))");
    parity("2 * 3 + (10 - 4)");
}

#[test]
fn parity_tail_position_threading() {
    // Deep tail recursion (TailCall position — B9; compile-time parity, no execution)
    parity("fn c(n: i64) { if (n == 0) { 0 } else { c(n - 1) } } c(5)");
    // The last item of do inherits tail position (a tail call in do = a tail call — scheme semantics)
    parity("fn f(n: i64) { do(1, f(n - 1)) }");
    // Non-tail position (expression position inside the body → Call)
    parity("fn g(n: i64) { 1 + g(n - 1) }");
    // Both if arms inherit tail position + let sugar unwrapping (same corpus shape as tco_tests)
    parity(
        "fn h(n: i64, acc: i64) { if (n == 0) { acc } else { h(n - 1, acc + 1) } } (|| { let r = h(10, 0); r })()",
    );
    // Mutual tail recursion (E6 skin: `ev?`/`od?` → ev/od — the target
    // identifier charset has no `?`)
    parity(
        "fn ev(n: i64) { if (n == 0) { 1 } else { od(n - 1) } } fn od(n: i64) { if (n == 0) { 0 } else { ev(n - 1) } } ev(6)",
    );
}

#[test]
fn parity_deep_nesting_recursion() {
    // Deeply nested expressions (krf-side compile recursion-depth stress —
    // 100 levels of arithmetic nesting; E6 skin: right-associated `1 + (1 + ...)`
    // mirrors the S-expr right-spine tree shape)
    let mut src = String::from("fn f(x: i64) { ");
    for _ in 0..100 {
        src.push_str("1 + (");
    }
    src.push('x');
    for _ in 0..100 {
        src.push(')');
    }
    src.push_str(" } f(1)");
    parity(&src);
}

#[test]
fn parity_deterministic_double_compile() {
    // Determinism discipline (§7/B8): two self-hosted compiles of the same input are byte-identical
    let (core, mut table) = seed_front("fn f(x: i64) { if (n == 0) { 0 } else { f(n - 1) } } f(5)");
    let a = bootstrap_compile(&core, 0, &mut table).expect("first bootstrap compile failed");
    let b = bootstrap_compile(&core, 0, &mut table).expect("second bootstrap compile failed");
    assert!(
        a.bytecode_equal(&b),
        "twice bootstrap compile bytes differ(entry re-position discipline broken)"
    );
    // Empty program (main_span dummy path)
    parity("");
    parity("do()");
}

// ---- negative-case parity (message + Span verbatim-identical — D1 global-leak protection) ----

#[test]
fn parity_err_define_position() {
    // define in expression position inside a function body (the expander only
    // hoists body-head defines — ones leaking into begin/if expression
    // positions are structurally rejected by the compile stage; both paths
    // report the same E0003 caliber)
    // (E6 skin: the do call form and the if-arm block reproduce the
    // do-wrapped / if-arm define shapes — the block threading makes every
    // in-body define a wrapped define on the target face)
    parity_err("fn f(x: i64) { do(define(y, 2), x) }");
    parity_err("||(x: i64) { do(1, define(y, 2)) }");
    parity_err("||(x: i64) { if (true) { define(y, 2) } else { x } }");
    parity_err("fn f(x: i64) { let y = 1; do(define(z, 2), y) }");
}

#[test]
fn parity_module_require_arms() {
    // 42-c both-arms migration landed: boundary asymmetry eliminated —
    // module/require positive cases pass parity on both paths (the 42-b
    // boundary assertions were rewritten as positive cases — the production
    // switch point belongs to 42-d)
    parity("require io, read;");
    parity("require io, read; require io, write;");
    parity("require io, write; let x = 1; x");
    parity("module m { let x = 1; x }");
    // Multi-item body (intermediate-value Pop carries the item's own Span) + import/export surface
    // (E6 skin: `module m { 1 2 3 }` — bare expression sequence = the S-expr
    // three-item body; the import/export headers use the declaration forms)
    parity("module m { 1 2 3 }");
    parity("module m { import kerf_string; export x; let x = 1; let y = 2; x + y }");
    // Toplevel forms following a module + the last item does not inherit tail
    // position (a module item is never in tail position — unlike the TCO
    // inheritance of do's last item)
    parity("module m { fn f(x: i64) { x + 1 } f(2) } 42");
    parity("module m { fn c(n: i64) { if (n == 0) { 0 } else { c(n - 1) } } c(5) }");
    // Determinism: two self-hosted compiles of the same input are byte-identical (module/require paths)
    let (core, mut table) = seed_front("module m { let x = 1; x } require io, read; 42");
    let a = bootstrap_compile(&core, 0, &mut table).expect("first bootstrap compile failed");
    let b = bootstrap_compile(&core, 0, &mut table).expect("second bootstrap compile failed");
    assert!(
        a.bytecode_equal(&b),
        "twice bootstrap compile bytes differ(module/require path entry re-position discipline broken)"
    );
}

// ---- extension group: all nine sugar forms through the full pipeline for parity
// (expander desugaring → both compile paths) ----

#[test]
fn parity_sugar_let_family() {
    // let → fn application; nested let; let* chained shadowing; letrec mutual recursion
    // (E6 skin: the top-level let expressions ride the IIFE closure carrier;
    // the multi-binding let statement carries the D61 staging chain; let*/letrec
    // have no target surface — sequential lets / top-level fn recursion)
    parity("(|| { let x = 1; x })()");
    parity("(|| { let x = 1, y = 2; x + y })()");
    parity("(|| { let x = 1; let y = 2; x + y })()");
    parity("(|| { let x = 1; let x = 2; x })()"); // cross-level nested shadowing
                                                  // (same-level duplicate names are
                                                  // an expander error — fn duplicate
                                                  // parameter names are rejected,
                                                  // not positive-case corpus)
    parity("(|| { let x = 1; let y = x + 1; let z = y + 1; x + (y + z) })()");
    parity(
        "fn ev(n: i64) { if (n == 0) { true } else { od(n - 1) } } fn od(n: i64) { if (n == 0) { false } else { ev(n - 1) } } ev(6)",
    );
    // Multi-form let body (desugared to do semantics) + tail-position threading
    parity("(|| { let n = 0; n = n + 1; n })()");
    parity("fn f(n: i64) { let m = n + 1; m } f(5)");
}

#[test]
fn parity_sugar_cond_when_unless() {
    // cond clause chain → nested if; else-compatible clause; when/unless single arm
    // (E6 skin: cond/when/unless have no target surface — the if-else chain
    // carrier per E6-CG §2; the negative literal -1 uses the 0 - 1 carrier)
    parity("if (true) { 1 } else { if (true) { 2 } }");
    parity("if (1 == 2) { 1 } else { if (1 == 1) { 2 } else { 3 } }");
    parity("if (1 == 2) { 1 } else { if (2 == 2) { 2 } else { 3 } }");
    parity("fn g(n: i64) { if (n < 0) { 0 - 1 } else { if (n == 0) { 0 } else { 1 } } } g(5)");
    parity("if (true) { do(1, 2, 3) }");
    parity("if (1 == 2) { do(1, 2) }");
    parity("if (false) { 1 } else { 2 }");
    parity("if (true) { 1 } else { 2 }");
    // Tail-position threading: both cond arms / the last item of a when body in tail position
    parity("fn h(n: i64) { if (n == 0) { quote(zero) } else { h(n - 1) } } h(3)");
}

#[test]
fn parity_sugar_and_or_while() {
    // and/or short-circuit chains → nested if; binary/unary/variadic
    // (E6 skin: `&&`/`||` carry the (and)/(or) core forms — right-assoc for
    // the n-ary legs; the zero-ary/unary `(and)`/`(and 1)`/`(or)` legs have
    // no target surface, recorded with the r154 conversion; while → the
    // recursion carrier per E6-CG §2)
    parity("1 && 2 && 3");
    parity("1 == 1 && 2 == 2 && 3 == 3");
    parity("false || ()");
    parity("false || 2");
    parity("false || false || 42");
    // while → letrec loop recursion desugaring (compile-time parity, no execution)
    parity("let i = 0; fn spin() { if (i < 5) { i = i + 1; spin() } else { i } } spin(); i");
    parity(
        "fn spin(i: i64, n: i64) { if (i < n) { spin(i + 1, n) } else { i } } fn count_up(n: i64) { spin(0, n) } count_up(3)",
    );
}

#[test]
fn parity_macros_corpus() {
    // Macro corpus (macro output CoreExpr → both-path compile parity — same
    // shape as macros.ktf — examples/usage/macros.ktf idiom):
    // swap (let+assign mix) / my_or (recursive macro + ellipsis) /
    // def_twice (top-level define output)
    parity(
        "macro swap {\n    (x, y) => { let tmp = x; x = y; y = tmp; }\n}\nlet p = 1;\nlet q = 2;\nswap(p, q);\nlist(p, q)",
    );
    parity(
        "macro my_or {\n    () => false,\n    (a) => a,\n    (a, rest ...) => if a { true } else { my_or(rest ...) },\n}\nmy_or(false, false, 42)",
    );
    // Literal patterns + multi-pattern macro
    parity(
        "macro def_twice {\n    (n, v) => { define(n, v); define(n2, v); }\n}\ndef_twice(x, 7); x",
    );
}

#[test]
fn parity_preamble_injection_order() {
    // Prelude injection order: the preamble.krf real-corpus leg was retired
    // by the E5 close-out cleanup batch (r120 / 190-a, principle 41 — the
    // S-expr original deleted after the switch window's five steps; the
    // injected object is now preamble.ktf, whose dual-path equivalence is
    // carried by switch_corpus_parity_tests::ktf_preamble_bytecode_parity_
    // dual_path + the seed-vs-bootstrap expander gate). The user-source +
    // module-header leg remains: import surface + module semantics compiled
    // together as corpus on both paths.
    // (E6 skin: the quoted-list map argument uses the runtime list()
    // construction — the r127 honest boundary; module-internal import via
    // the declaration form)
    parity(
        "import kerf_prelude;\nmodule user { import kerf_prelude; fn sq(x: i64) { x * x } map(sq, list(1, 2, 3)) }",
    );
}

#[test]
fn parity_examples_usage_all_six() {
    // Integration validation (design §4 S2): all six usage-corpus files
    // pass bytecode_equal on both paths (covering require/macros/GC
    // stress/higher-order functions across the full spectrum).
    // r153 / 223-c: the corpus legs switched to the .ktf single face
    // (the .krf corpus retired — s-expr-removal-plan §4 Batch D); the
    // read stage goes through the production reader bridge, the
    // compile-parity discipline (seed vs self-hosted on the same
    // CoreExpr) is verbatim.
    parity_target(include_str!("../../../../examples/usage/fib.ktf"));
    parity_target(include_str!("../../../../examples/usage/closures.ktf"));
    parity_target(include_str!("../../../../examples/usage/higher_order.ktf"));
    parity_target(include_str!("../../../../examples/usage/macros.ktf"));
    parity_target(include_str!("../../../../examples/usage/gc_stress.ktf"));
    parity_target(include_str!("../../../../examples/usage/io.ktf"));
}

// ---- behavioral surface (core semantics of the basic examples/usage
// ---- files — design §4 S1 integration validation) ----

#[test]
fn behavior_fib() {
    // Core semantics of fib.ktf (print/require are outside the I/O boundary —
    // same-shape precedent in qbe_backend_tests; fib 12 = 144 matches the CLI
    // smoke-test caliber)
    behavior("fn fib(n: i64) { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } } fib(12)");
}

#[test]
fn behavior_closures() {
    // Core semantics of closures.ktf: independence of counter shared cells + adder capture
    behavior(
        "fn make_counter() { let n = 0; || { n = n + 1; n } }\nlet a = make_counter();\nlet b = make_counter();\na(); a(); a();\nb();\nlist(a(), b())",
    );
    behavior("fn make_adder(n: i64) { || (x: i64) { x + n } } let add5 = make_adder(5); add5(37)");
}

#[test]
fn behavior_higher_order() {
    // Core semantics of higher_order.ktf: map/filter via explicit recursion + closure arguments
    // (E6 skin: `even?` → even — the target identifier charset; the quoted
    // list uses the runtime list() construction)
    behavior(
        "fn map(f: T, lst: T) { if (is_nil(lst)) { () } else { cons(f(head(lst)), map(f, tail(lst))) } }\nfn filter(pred: T, lst: T) { if (is_nil(lst)) { () } else { if (pred(head(lst))) { cons(head(lst), filter(pred, tail(lst))) } else { filter(pred, tail(lst)) } } }\nfn even(n: i64) { mod(n, 2) == 0 }\nmap(|| (x: i64) { x * x }, list(1, 2, 3, 4, 5))",
    );
    behavior(
        "fn map(f: T, lst: T) { if (is_nil(lst)) { () } else { cons(f(head(lst)), map(f, tail(lst))) } } map(|| (x: i64) { x + 1 }, list(1, 2, 3))",
    );
}

#[test]
fn behavior_deep_tail_recursion() {
    // Deep tail recursion end to end (TailCall frame reuse — self-hosted
    // compile-stage output executed on the VM; 100_000 levels without TCO
    // would hit the frame limit — behavioral-level proof of the B9
    // must-include surface)
    behavior("fn c(n: i64) { if (n == 0) { quote(done) } else { c(n - 1) } } c(100000)");
}

#[test]
fn behavior_sugar_42c() {
    // 42-c extension behavioral surface: the nine sugar forms' semantics via
    // the self-hosted compile-stage output executed on the VM = production
    // pipeline results (let family + cond/when/unless + and/or + while)
    // (E6 skin: let*/letrec/cond/when/unless/while → the IIFE let chain /
    // top-level fn recursion / if-else carriers per E6-CG §2)
    behavior(
        "(|| { let x = 5; let y = x + 1; if (y == 6) { quote(six) } else { quote(other) } })()",
    );
    behavior(
        "fn ev(n: i64) { if (n == 0) { true } else { od(n - 1) } } fn od(n: i64) { if (n == 0) { false } else { ev(n - 1) } } ev(10)",
    );
    behavior("let i = 0; fn spin() { if (i < 10) { i = i + 1; spin() } else { i } } spin()");
    behavior("true && true && 3"); // condition positions are strict bool (int condition → E0004)
    behavior("false || false || 7");
    behavior("if (false) { () } else { quote(yes) }");
    behavior("if (1 == 1) { quote(ok) }");
}

#[test]
fn behavior_module_42c() {
    // 42-c module-arm behavioral surface: module body inline compile output
    // executed = production pipeline results (including the registry
    // declare/visit front-end surface)
    behavior("module m { let x = 1; x }");
    behavior("module m { fn f(n: i64) { if (n < 2) { n } else { f(n - 1) + f(n - 2) } } f(10) }");
    // module + sugar + closure mix (same corpus shape as the preamble form)
    // (E6 skin: module bodies admit no let statements — the let leg is the
    // tail expression)
    behavior(
        "module shapes { fn make_adder(n: i64) { || (x: i64) { x + n } } let add5 = make_adder(5); add5(37) }",
    );
}

// ---- r25/42-f effect group: perform/handle compile-arm parity (Gate A
// extension — the three-prototype frame orchestration INSTALL_HANDLER/
// PERFORM byte-identical on both paths + trampoline lazy-singleton
// determinism + resume desugaring shared in the expansion stage (the Apply
// channel — no compile-stage special-casing needed)) ----

#[test]
fn parity_effect_perform_and_handle_basic() {
    // Basic shape: H/B prototypes + trampoline + INSTALL_HANDLER + PERFORM
    // (E6 skin: the value-position perform rides the ask() callee — the
    // examples/usage/effect.ktf idiom)
    parity(
        "fn ask() -> i64 { perform add(5); } handle (1 + ask()) { add(p, k) => resume(p + 10) }",
    );
    // Nested handle: two sets of three prototypes + two tag constants
    parity(
        "fn ask() -> i64 { perform outer(7); } handle (handle ask() { inner(q, j) => { 42 } }) { outer(p, k) => resume(p) }",
    );
}

#[test]
fn parity_effect_trampoline_shared_and_capture() {
    // Multiple handles sharing the trampoline (lazy singleton — the second
    // Handle reuses the first T prototype's index; deterministic-order
    // verification) + capture surface (handler body references outer globals
    // and the B body captures outer variables)
    // (E6 skin: the two handles sit in the two operands of a binary + — the
    // parenthesized expression-position handle forms)
    parity(
        "let base = 10; fn ask_a() -> i64 { perform a(1); } fn ask_b() -> i64 { perform b(2); } (handle ask_a() { a(p, k) => resume(p + base) }) + (handle ask_b() { b(q, j) => resume(q) })",
    );
    // B thunk captures outer locals (closure capture via GcCell slots) + H prototype capture
    parity(
        "fn ask_t(x: i64) -> i64 { perform t(x); } fn f(x: i64) -> i64 { handle (x + ask_t(x)) { t(p, k) => resume(p + x) } } f(5)",
    );
}

#[test]
fn behavior_effect_resume_roundtrip() {
    // Behavioral surface: self-hosted compile-stage output executed on the
    // VM — the full suspend/dispatch/resume chain (production pipeline as
    // the reference — the compile stage is the only variable under test)
    // (E6 skin: the value-position perform rides the ask() callee; the
    // no-resume arm yields its replacement value via the block arm body)
    behavior(
        "fn ask() -> i64 { perform add(5); } handle (1 + ask()) { add(p, k) => resume(p + 10) }",
    );
    behavior(
        "fn ask() -> i64 { perform outer(7); } handle (handle ask() { inner(q, j) => { 42 } }) { outer(p, k) => resume(p) }",
    );
    behavior("fn ask() -> i64 { perform t(0); } handle (1 + ask()) { t(p, k) => { 99 } }");
}

// E6 close-out (r154 / 224-c1): corpus converted to the target-syntax face.
//! Batch H (r18) — H4 HM-inference PoC integration tests (40-e / 38-d
//! design §7 landing).
//!
//! E6 skin notes (E6-CG §2): fn declarations with stripped-after-parse
//! type signatures; the IIFE `(|| { ... })()` carrier for expression
//! bodies that need local bindings (let-family shapes); `letrec` has no
//! target surface — the two letrec legs are rewritten to the closest
//! reachable shapes (let-bound closure / top-level fn recursion — the
//! desugar arm itself is unreachable from the target face, recorded in
//! the r154 worklog); quoted-list data `'(1 2 3)` has no target literal
//! (r127 honest boundary) — the runtime `list(...)` construction carries
//! the same HM-clean use sites.
//!
//! **Gates (D8 PoC phase = offline parallel validation)**:
//! - **Superset gate**: the R1-R8 negative-case matrix is fully detected
//!   (for each program: check_program reports → hm_check_program also
//!   reports);
//! - **Zero-false-positive gate**: the six examples + dynamic-boundary corpus
//!   (same source as typecheck_tests dynamic_programs_clean) → 0 diagnostics;
//! - **HM value-added surface** (detection proofs for the four gap classes of
//!   38-d §2.2 that R1-R8 silently pass): ① user fn argument type errors;
//!   ② car/cdr element types (Pair(τ,τ) constructor); ③ branch disagreement;
//!   ④ arity/domain errors inside recursive function bodies;
//! - **Ruled negative cases**: occurs check (including self-application) ≥3 +
//!   value restriction (assign targets / Apply results not generalized) ≥2 +
//!   multi-error Span order.
//!
//! **Flag-period caliber (D8 phase 2 — r29 / 50-a / MUV 48-c)**: the
//! `kerf check` production decision surface has switched to
//! `hm_check_program` (both driver.rs entry points) — this suite's offline
//! entry (`hm(src)`) shares the same source and decisions as the production
//! entry; `r18(src)` (R1-R8) is retained as a **regression baseline
//! assertion** (the superset gate's reference side — dual-side detection
//! discipline). The flag-period gates for the production entry (superset
//! gate + zero-false-positive gate + contract-redefinition assertion
//! anchors) are in the flag-period decision-surface group at the end of
//! typecheck_tests.rs.
//!
//! Implementation note (acceptance-caliber alignment — the R4 code is
//! authoritative): the 38-d design §7 acceptance row expects fib :
//! Int→Int; the implementation measures **fib : (num → num)** — all use
//! sites of n are numeric-domain constraints (`<`/`-`/recursive argument
//! passing), and the lattice-unification least solution = Num (no Int
//! anchor point). The key acceptance property is preserved: **not Dynamic**
//! (the recursive shape is successfully inferred via α_f unification —
//! gap ④ honored). The design document is written back in sync with this
//! test.

use kerf_compiler::check_program;
use kerf_compiler::hm::{hm_check_program, HmReport};
use kerf_driver::builtins::builtin_sigs;
use kerf_driver::compile_source;

/// Front-end compile + HM inference (the PoC offline entry).
fn hm(src: &str) -> HmReport {
    let out = compile_source(src, "<hm-test>")
        .expect("frontend compile failed (test source should be well-formed)");
    let mut table = out.table;
    let sigs = builtin_sigs(&mut table);
    hm_check_program(&out.core, &sigs, &table)
}

/// Front-end compile + HM inference, target-syntax face (r153 / 223-c:
/// the usage-corpus legs switched to the .ktf single face — the read
/// stage goes through the production target chain; the HM face is
/// syntax-invariant downstream).
fn hm_check(src: &str) -> HmReport {
    let out = kerf_driver::compile_source(src, "<hm-test>.ktf")
        .expect("frontend compile failed (test source should be well-formed)");
    let mut table = out.table;
    let sigs = builtin_sigs(&mut table);
    hm_check_program(&out.core, &sigs, &table)
}

/// R1-R8 baseline (the superset gate's reference side).
fn r18(src: &str) -> usize {
    let out = compile_source(src, "<hm-superset>").expect("frontend compile failed");
    let mut table = out.table;
    let sigs = builtin_sigs(&mut table);
    check_program(&out.core, &sigs, &table).len()
}

fn assert_clean(src: &str) {
    let r = hm(src);
    assert!(
        r.diags.is_empty(),
        "expected 0 diagnostic, got {} clauses: {:?}\n program: {}",
        r.diags.len(),
        r.diags
            .iter()
            .map(|d| d.message.clone())
            .collect::<Vec<_>>(),
        src
    );
}

fn assert_diag(src: &str, msg: &str) {
    let r = hm(src);
    assert!(
        r.diags.iter().any(|d| d.message.contains(msg)),
        "not detected `{}`; actual {} clauses: {:?}\n program: {}",
        msg,
        r.diags.len(),
        r.diags
            .iter()
            .map(|d| d.message.clone())
            .collect::<Vec<_>>(),
        src
    );
}

// ---------------------------------------------------------------------------
// Zero-false-positive gate (six examples + dynamic-boundary corpus)
// ---------------------------------------------------------------------------

#[test]
fn examples_six_piece_zero_diag() {
    // r153 / 223-c: the corpus legs switched to the .ktf single face (the
    // .krf corpus retired — s-expr-removal-plan §4 Batch D); the
    // zero-false-positive duty on the real user corpus now runs on the
    // production face.
    for f in [
        "fib.ktf",
        "closures.ktf",
        "higher_order.ktf",
        "macros.ktf",
        "gc_stress.ktf",
        "io.ktf",
    ] {
        let src = std::fs::read_to_string(format!("examples/usage/{}", f))
            .unwrap_or_else(|e| panic!("read example {} failed:{}", f, e));
        let r = hm_check(&src);
        assert!(
            r.diags.is_empty(),
            "example {} expected 0 diagnostic, got {} clauses: {:?}",
            f,
            r.diags.len(),
            r.diags
                .iter()
                .map(|d| d.message.clone())
                .collect::<Vec<_>>()
        );
    }
}

#[test]
fn dynamic_boundary_corpus_clean() {
    // Same-source corpus as typecheck_tests::dynamic_programs_clean (zero-false-positive gate)
    assert_clean("fn f(x: T) { if (x) { 1 } else { 2 } } f(true)");
    assert_clean("fn fact(n: T) { if (n == 0) { 1 } else { n * fact(n - 1) } } fact(5)");
    assert_clean("require io, write; let x = 42; print(x)");
    assert_clean("1 + 2.5");
    assert_clean("1 < 2.0");
    assert_clean("head(list(1, 2, 3))");
    assert_clean("fn head(x: T) { 42 } head(5)");
    assert_clean(
        "require io, write; let x = 1; x = x + 1; do(print(x), if (is_nil(())) { x } else { 2 })",
    );
    assert_clean("if (is_nil(())) { 1 } else { 2 }");
    assert_clean("if (eq(quote(a), quote(a))) { 1 } else { 2 }");
    assert_clean("import kerf_string;\nstring_append(\"a\", \"b\")");
    assert_clean("import kerf_string;\nstring_to_symbol(\"foo\")");
    assert_clean("import kerf_string;\nsymbol_to_string(quote(foo))");
    assert_clean("\"a\" == \"b\"");
}

#[test]
fn numeric_tower_and_set_join_clean() {
    // Numeric-tower lattice unification (Int/Float/Num mutually match —
    // a subset of the P0-3 dedicated matrix)
    assert_clean("1 + 2.5 + 3");
    assert_clean("2.5 - 1");
    assert_clean("1.5 * 2.0 * 3");
    // D3 conservative join contract: heterogeneous assignment → Dynamic
    // downgrade with zero diagnostics
    assert_clean("import kerf_string;\nlet x = 1; x = \"foo\"; string_append(x, \"!\")");
    assert_clean("let x = 1; x = 2.5; x + 1");
}

// ---------------------------------------------------------------------------
// Acceptance surface: fib infers to (num → num) (not Dynamic — gap ④ recursive inference honored)
// ---------------------------------------------------------------------------

#[test]
fn fib_infers_num_to_num_not_dynamic() {
    let src = "fn fib(n: i64) { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } } fib(12)";
    let r = hm(src);
    assert!(
        r.diags.is_empty(),
        "zero diagnostics: {:?}",
        r.diags
            .iter()
            .map(|d| d.message.clone())
            .collect::<Vec<_>>()
    );
    let out = compile_source(src, "<hm-fib>").expect("compile failed");
    let mut table = out.table;
    let fib_sym = table.intern("fib");
    let ty = r
        .globals
        .get(&fib_sym)
        .unwrap_or_else(|| panic!("fib should input global binding table"));
    assert_eq!(
        ty.render(),
        "(num → num)",
        "fib infer type(non- Dynamic = recursion α_f unification succeeded)"
    );
}

// ---------------------------------------------------------------------------
// Superset gate: the R1-R8 negative-case matrix is fully detected (dual-checker parallel comparison)
// ---------------------------------------------------------------------------

#[test]
fn superset_gate_r1_to_r8() {
    let corpus: &[&str] = &[
        // R1 (if condition not bool)
        "if (1) { 2 } else { 3 }",
        "if (1.5) { 2 } else { 3 }",
        "if (\"s\") { 2 } else { 3 }",
        "if (()) { 2 } else { 3 }",
        "if (quote(sym)) { 2 } else { 3 }",
        "if (true) { 1 } else { if (()) { 2 } else { 3 } }",
        // R2 (arithmetic on non-numeric)
        "1 + \"a\"",
        "1 - \"a\"",
        "\"a\" * 2",
        "() / 2",
        "mod(true, 2)",
        "1 + 2 + \"a\" + 4",
        // R3 (comparison domain)
        "1 < \"a\"",
        "1 > \"a\"",
        // r162 / 233 — TD-037: `(1 == 2) == "s"` retired (the `==` skin
        // targets the cross-domain `eq` sig — statically clean); the
        // eq-result-into-ordering form keeps the R3 domain detection:
        "(1 == 2) < \"s\"",
        // TD-011 r24: all-string ordering chains are now legal (code-point
        // order) — switched to mixed-string-chain anchors for R3
        "\"a\" < 1",
        "(3 < 1) < \"a\"",
        // R4 (not on non-bool)
        "!1",
        "!\"s\"",
        // R5 (car/cdr on non-pair)
        "head(5)",
        "tail(\"s\")",
        // R6 (not callable)
        "1(2, 3)",
        "\"s\"(1)",
        // R7 (arity)
        "(|| (x: i64) { x })(1, 2)",
        "(|| (x: i64, y: i64) { x })(1)",
        "head(1, 2)",
        // R8 (string/symbol family)
        "import kerf_string;\nstring_append(1, \"a\")",
        "import kerf_string;\nstring_to_symbol(5)",
        "import kerf_string;\nsymbol_to_string(7)",
    ];
    for src in corpus {
        let r_count = r18(src);
        let hm_count = hm(src).diags.len();
        assert!(
            r_count >= 1,
            "reference side(R1-R8)not detected -- corpus invalidated: {}",
            src
        );
        assert!(
            hm_count >= 1,
            "exceed set gate failed: R1-R8 detected {} clauses and HM 0 clauses\n program: {}",
            r_count,
            src
        );
    }
}

// ---------------------------------------------------------------------------
// HM value-added surface (detection proofs for the four gap classes of
// 38-d §2.2 — silently passed by R1-R8)
// ---------------------------------------------------------------------------

#[test]
fn gap1_user_lambda_arg_type_error_detected() {
    // Gap ①: user fn argument type error (r50-β / D61: the D6 ② let-shape
    // recognition retired — hand-written combinations go through the
    // generic application arm; the detection surface changes from
    // "signature message with the parameter directly bound" to
    // "type-mismatch message from unification constraints" (detection
    // semantics preserved as equivalent))
    assert_diag(
        "(|| (x: i64) { x + 1 })(\"foo\")",
        "type mismatch: str and num",
    );
    // Non-numeric-domain parameter (bool passed into an arithmetic
    // position — detected by same-shape unification)
    assert_diag(
        "(|| (x: i64) { x + 1 })(true)",
        "type mismatch: bool and num",
    );
}

#[test]
fn gap2_car_element_type_inferred() {
    // Gap ②: head element type (Pair(τ,τ) constructor inference — a Bool
    // element reaches an arithmetic position)
    let src = "let x = head(cons(true, ())); x + 1";
    assert_diag(src, "requires a number");
    // Positive case: a numeric element participates in arithmetic with zero diagnostics
    assert_clean("let x = head(cons(1, ())); x + 1");
}

#[test]
fn gap3_branch_disagreement_detected() {
    // Gap ③: branch type disagreement (type variables participate →
    // constraint unification)
    // f returns both if branches (variable paths): one constrained to the
    // numeric domain, one to the string domain
    let src =
        "import kerf_string;\nfn f(c: T) { if (c) { 1 + c } else { string_append(c, \"\") } } f(1)";
    assert_diag(src, "type mismatch");
}

#[test]
fn gap4_recursive_arity_and_domain_detected() {
    // Gap ④: arity error inside a recursive function body (self-reference
    // unified via α_f — not Unknown)
    assert_diag(
        "fn fib(n: i64) { if (n < 2) { n } else { fib(n - 1, 1) + fib(n - 2) } }",
        "argument count mismatch",
    );
    // Recursive domain error: a non-numeric value passed at the
    // self-reference parameter (n is anchored to ~Num via <, conflicting
    // with string-append's Str domain constraint → type mismatch)
    assert_diag(
        "import kerf_string;\nfn g(n: i64) { if (n < 2) { n } else { g(string_append(n, \"x\")) } }",
        "type mismatch",
    );
}

// ---------------------------------------------------------------------------
// Ruled negative cases: occurs check (D5) ≥3 (including self-application)
// ---------------------------------------------------------------------------

#[test]
fn occurs_check_negatives() {
    // ① Self-application (the parameter variable participates in its own
    // constraint — the classic (λx. x x))
    assert_diag("fn f(x: T) { x(x) }", "cannot construct an infinite type");
    // ② Self-reference propagation (f itself in parameter position)
    assert_diag("fn f(x: T) { f(f) }", "cannot construct an infinite type");
    // ③ Nested self-application mediated by a type variable ((x x)'s
    // result applied again — α contains itself through two levels of
    // arrows)
    assert_diag(
        "fn f(x: T) { (x(x))(1) }",
        "cannot construct an infinite type",
    );
}

// ---------------------------------------------------------------------------
// Ruled negative cases: value restriction (D2) ≥2
// ---------------------------------------------------------------------------

#[test]
fn value_restriction_negatives() {
    // ① Apply results are not generalized: head's element type is shared
    // as Mono — two use sites with different types error
    assert_diag(
        "let f = head(cons(|| (x: T) { x }, ())); f(1); f(true)",
        "type mismatch",
    );
    // ② Weak monomorphism of the assign target: a Poly binding becomes
    // permanently monomorphic after assign — two use sites with different
    // types error
    assert_diag(
        "let id = || (x: T) { x }; id = id; id(1); id(true)",
        "type mismatch",
    );
    // Positive-case control: an fn binding without assign generalizes
    // (use sites in both domains are legal)
    assert_clean("let id = || (x: T) { x }; id(1); id(true)");
}

// ---------------------------------------------------------------------------
// D6 generalization carrier: the let shape (Apply-of-Fn recognition —
// hand-written equivalents get the same treatment)
// ---------------------------------------------------------------------------

#[test]
fn let_shape_generalization() {
    // The surface let sugar (unwrapped to Apply-of-Fn) gets the same treatment as the hand-written form
    // (E6 skin: the IIFE `(|| { let ...; body })()` carrier — the target
    // top level has no bare let expression)
    assert_clean("(|| { let id = || (x: T) { x }; id(1) + id(2) })()");
    assert_clean("(|| (id: T) { id(1) + id(2) })(|| (x: T) { x })");
    // Generalization instantiation: the let-bound id is legal at use sites
    // in both the Int and Bool domains
    assert_clean("(|| { let id = || (x: T) { x }; do(id(1), id(true)) })()");
    // letrec shape (D4): lambda-RHS generalization (use sites in both domains inside the body are legal)
    // (E6: letrec has no target surface — the let-bound closure rewrite;
    // the letrec desugar arm itself is unreachable from the target face,
    // recorded in the r154 worklog)
    assert_clean("(|| { let id = || (x: T) { x }; do(id(1), id(true)) })()");
    // Recursive letrec: fact's self-reference is inferred (not Dynamic)
    // (E6: no letrec surface — the top-level fn recursion carrier: the
    // self-reference α_f unification surface is preserved)
    let src = "fn fact(n: i64) { if (n == 0) { 1 } else { n * fact(n - 1) } } fact(5)";
    assert_clean(src);
}

// ---------------------------------------------------------------------------
// r50-β / D61 + TD-030: let direct-mapping HM surface + check+prelude integration group
// ---------------------------------------------------------------------------

/// r50-β / D61: the HM generalization surface of let direct mapping
/// (`CoreExpr::Let` pushed through directly) — bind-pattern RHS syntactic
/// values generalize (the same treatment as the original D6 ② shape
/// recognition is preserved).
#[test]
fn let_direct_mapping_hm_generalization() {
    // Multi-binding staging chain: Let[x, Var(t), ...]'s rebind value =
    // Var (a syntactic value — generalized); use sites in both domains
    // inside the body (the HM value-added surface is preserved)
    // (E6 skin: the multi-binding let statement `let a = e1, b = e2;` —
    // the D61 staging-chain carrier on the target face, wrapped in the
    // IIFE closure form)
    assert_clean(
        "(|| { let id = || (x: T) { x }, j = || (y: T) { y }; do(id(1), id(true), j(\"a\")) })()",
    );
    // Staging-name bindings do not leak (the let$st family never enters the
    // user surface — always invisible outside the body scope)
    assert_clean("(|| { let x = 1, y = 2; x + y })()");
    // Recursive define × let-discard combination (TD-030 minimal
    // reproduction — zero false positives via the discard arm after the
    // D6 ② shape recognition was retired)
    assert_clean(
        "fn fe(f: T, lst: T) { if (is_nil(lst)) { () } else { let ignored = f(head(lst)); fe(f, tail(lst)) } } 42",
    );
}

/// TD-030 repayment (r50-β): the check+prelude combination integration
/// group — closing the coverage gap (the historical gap of check_source
/// test corpora having zero prelude is the direct reason this TD was
/// discovered late; the tech-debt-register TD-030 acceptance trio).
#[test]
fn td030_check_prelude_combo_clean() {
    // ① The TD-registered original shape: `import kerf_prelude; 42` checks ok
    // (E6 skin: the `_`-separated module name maps onto the `-`-separated
    // registry symbol at the Reader boundary)
    // r164 / 235-c: the cascade injection (preamble + list.ktf) carries the
    // five recursive self-built definitions — the Rust ORACLE face reports
    // their occurs-class conservative false positives (the r80-accepted
    // family, build.ktf's 6→14 the same window); the PRODUCTION face
    // (check.ktf — the occurs exemption contract domain) stays zero-
    // diagnostic (CLI-proven: `kerf check` on this program is ok). The
    // zero-false-positives-at-use-sites intent is preserved: the two
    // conservative rows are definition-site rows of the injected body, not
    // use-site rows of the user program.
    assert_eq!(
        hm("import kerf_prelude; 42").diags.len(),
        2,
        "oracle face: the injected body's two conservative definition-site rows (infinite-type + nil/pair)"
    );
    // ② The for-each let-discard shape (full prelude module injection —
    // the first triggering corpus) checks with zero false positives
    assert_eq!(
        hm("import kerf_prelude;\nfor_each(|| (x: T) { x }, list(1, 2, 3))")
            .diags
            .len(),
        2,
        "oracle face: same two injected-body conservative rows (use site clean)"
    );
    // ③ Full prelude-module check integration: the five HOFs + the three
    // pair forms + the two list-domain forms all check with zero false
    // positives at every use site
    // r164/235-c: same two injected-body conservative rows on the oracle face
    assert_eq!(
        hm("import kerf_prelude;\n\
         map(|| (x: i64) { x * x }, list(1, 2, 3))\n\
         filter(|| (x: i64) { x > 1 }, list(1, 2, 3))\n\
         foldl(|| (acc: i64, x: i64) { acc + x }, 0, list(1, 2, 3))\n\
         foldr(|| (x: i64, acc: i64) { x + acc }, 0, list(1, 2, 3))\n\
         for_each(|| (x: T) { x }, list(1, 2, 3))\n\
         nth(list(9, 8, 7), 1)\n\
         drop(list(1, 2, 3), 1)\n\
         cons(head(list(1, 2)), tail(list(3, 4)))")
        .diags
        .len(),
        2,
        "oracle face: injected-body conservative rows only (use sites clean)"
    );
    // ④ Dual-import combination (stdlib domain + prelude in the same unit) — same two conservative rows
    assert_eq!(
        hm(        "import kerf_string, kerf_prelude;\nmap(|| (s: T) { string_length(s) }, list(\"a\", \"bb\"))",).diags.len(),
        2,
        "oracle face: injected-body conservative rows only"
    );
    // Regression control: genuine occurs negative cases remain detected
    // (the fix does not weaken the occurs surface)
    assert_diag("fn f(x: T) { f(f) }", "cannot construct an infinite type");
}

// ---------------------------------------------------------------------------
// D7 multi-error: full collection + Span order
// ---------------------------------------------------------------------------

#[test]
fn multi_error_collection_span_order() {
    let src =
        "import kerf_string;\n1 + \"a\"\nif (2) { 1 } else { 3 }\nhead(5)\nstring_append(1, \"b\")";
    let r = hm(src);
    assert!(
        r.diags.len() >= 4,
        "should ≥4 diagnostics, got {}: {:?}",
        r.diags.len(),
        r.diags
            .iter()
            .map(|d| d.message.clone())
            .collect::<Vec<_>>()
    );
    let starts: Vec<u32> = r.diags.iter().map(|d| d.primary_span.start).collect();
    let mut sorted = starts.clone();
    sorted.sort();
    assert_eq!(
        starts, sorted,
        "diagnostic should by Span start dot rise order"
    );
    // Diagnostic code family: E0005
    for d in &r.diags {
        assert_eq!(d.code.map(|c| c.render()), Some("E0005".to_string()));
    }
}

// ---------------------------------------------------------------------------
// Conservative boundary preservation (A4 gradual escape hatch + A6 depth budget)
// ---------------------------------------------------------------------------

#[test]
fn dynamic_escape_not_forced() {
    // r46 / 67-b deep review D49: A4 dynamic-escape-hatch semantic
    // convergence — unbound references are rejected earlier by the front
    // at compile time with E0022 (before the HM decision surface); the A4
    // conservativity of "HM does not force types on unbound names" is
    // carried by the E0022 fronting (typos are rejected at compile time —
    // the zero-HM-false-positive promise is kept and strengthened); the HM
    // conservativity anchor of mixed-type assign downgrading to Dynamic is
    // preserved
    let unbound = compile_source("print_unregistered_thing(1, 2, 3)", "<hm-a4>");
    let err = match unbound {
        Ok(_) => panic!("unbound reference should compile-time rejected(E0022)"),
        Err(e) => e,
    };
    assert!(
        err.rendered.contains("E0022"),
        "E0022 code:{}",
        err.rendered
    );
    // After a mixed-type assign it downgrades to Dynamic: zero downstream
    // constraints (the HM conservativity anchor proper)
    assert_clean("let x = 1; x = true; if (x) { 1 } else { 2 }");
}

#[test]
fn deep_nesting_within_budget_clean() {
    // Deep nesting within the 512 generation-phase budget yields zero
    // diagnostics (A6 semantics migrated as-is)
    let mut src = String::from("1");
    for _ in 0..250 {
        src = format!("if (true) {{ {} }} else {{ 2 }}", src);
    }
    assert_clean(&src);
}

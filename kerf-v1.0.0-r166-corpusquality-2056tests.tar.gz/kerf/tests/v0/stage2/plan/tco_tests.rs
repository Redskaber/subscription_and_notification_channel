// E6 close-out (r154 / 224-b6): converted to the target-syntax face.
//! Batch H (r18) — TCO tail-call optimization integration tests
//! (40-c / TD-022 honored).
//!
//! E6 skin notes (E6-CG §2): fn declarations replace (define (f x) ...);
//! `?`-suffix predicate names (`ev?`/`od?`) are outside the target
//! identifier charset → bare `ev`/`od`; the `do` call form carries the
//! S-expr begin shape; `(define-syntax ...)` → `macro m { (pat) => tpl }`.
//!
//! **Coverage** (§9.4.3 positive:negative ratio ≥1:3 — native-code-path
//! dedicated negative cases carry the ratio):
//! - Positive cases: deep tail recursion with constant frames (105_001
//!   levels — the old frame-limit case flipped into a passing item), mutual
//!   tail recursion (even/odd 300_000 steps), tail-position propagation
//!   (both if arms / do last item / let sugar unwrapping and nesting),
//!   builtin tail calls (implicit RET), self-hosted-chain deep expansion
//!   (the TD-007 10_000 caliber reached end to end on the self-hosted
//!   expander path — TCO removes the frame constraint);
//! - Negative cases: the infinite-tail-loop instruction-budget guardrail
//!   (budget-injection style — same shape as 38-c find_qbe), tail-call
//!   arity mismatch, tail call of a non-callable value;
//! - Diagnostics surface: tail-call frames do not appear in the trace chain
//!   (optimized-frame semantics — the non-tail two-level chain ≥2-note
//!   contrast anchor lives in negative_semantics_tests).
//!
//! Semantics note (T1 theorem domain): the eval reference path has no TCO
//! (256-depth boundary — the TD-017 r16 ruling stands); VM tail recursion
//! beyond the 256-depth region is outside the T1 checking domain
//! (dual-path cross-check tests use bounded programs — this suite's
//! 105_001-level cases run the VM path only).

use std::collections::HashMap;

use kerf_driver::compile_source;
use kerf_syntax::Symbol;
use kerf_vm::{run_program_with_budget, Value};

use crate::common;

// ---- positive cases: tail-recursion frame reuse ----

/// The old frame-limit negative case flipped into a TCO positive case:
/// 105_001-level tail recursion (> MAX_FRAMES 100_000) completes with a
/// constant frame count and returns 0. Before TCO this program reported
/// "call frames exceed the limit" at 100_000 frames.
#[test]
fn tail_recursion_constant_frames_105k() {
    common::assert_int(
        "fn c(n: i64) -> i64 { if (n == 0) { 0 } else { c(n - 1) } } c(105001)",
        0,
    );
}

/// Mutual tail recursion (even?/odd? alternating): 300_000 round trips at a constant frame count.
#[test]
fn mutual_tail_recursion_even_odd() {
    common::assert_int(
        "fn ev(n: i64) -> i64 { if (n == 0) { 1 } else { od(n - 1) } }
         fn od(n: i64) -> i64 { if (n == 0) { 0 } else { ev(n - 1) } }
         ev(300000)",
        1,
    );
}

/// Tail-position propagation — both If arms: tail calls in the then/else
/// positions both get frame reuse.
#[test]
fn tail_position_propagates_through_if_branches() {
    common::assert_int(
        "fn down(n: i64) -> i64 { if (n == 0) { 42 } else { down(n - 1) } } down(200000)",
        42,
    );
    // else arm is a non-call, then arm is tail-recursive
    common::assert_int(
        "fn down2(n: i64) -> i64 { if (n > 0) { down2(n - 1) } else { 7 } } down2(200000)",
        7,
    );
}

/// Tail-position propagation — the Do last item (scheme semantics: a tail
/// call in do = a tail call).
/// Note: a nested do's last item passes tail position on through the outer
/// do's last item (three-level propagation).
#[test]
fn tail_position_propagates_through_begin_last() {
    common::assert_int(
        "fn f(n: i64) -> i64 { if (n == 0) { 99 } else { do(1, do(2, f(n - 1))) } }
         f(150000)",
        99,
    );
}

/// Tail-position propagation — let sugar (after unwrapping to Fn+Apply, the
/// Apply sits in applicative-order tail position).
#[test]
fn tail_position_through_let_sugar() {
    common::assert_int(
        "fn f(n: i64) -> i64 { if (n == 0) { 11 } else { let m = n - 1; f(m) } }
         f(200000)",
        11,
    );
}

/// Builtin tail call: the result is the return value (the implicit RET path).
#[test]
fn builtin_tail_call_returns_value() {
    common::assert_int("fn f(p: T) { head(p) } f(cons(5, ()))", 5);
    common::assert_int("fn f(a: i64, b: i64) -> i64 { a + b } f(40, 2)", 42);
}

/// Closure-value tail call (a first-class function passed as a parameter, then called in tail position).
#[test]
fn closure_value_in_tail_position() {
    common::assert_int(
        "fn loop(f: T, n: i64) -> i64 { if (n == 0) { 77 } else { f(f, n - 1) } }
         fn g(f: T, n: i64) -> i64 { loop(f, n) }
         g(g, 100000)",
        77,
    );
}

// ---- positive cases: TD-007/TD-022 decoupling (self-hosted path end to end) ----

/// Self-hosted expander depth chain (seed-side 10_000 chain + self-hosted
/// bridge parity caliber): before TCO the self-hosted side hit the frame
/// limit first on the ~10_000-deep chain (the expander.krf trampoline's
/// loop tail-call chain consumed frames); after TCO, frame reuse reaches
/// the 10_000 depth limit and reports a structured error.
#[test]
fn bootstrap_expander_10k_depth_reaches_limit() {
    // Self-referential macro: infinite expansion → the depth count reaches
    // 10_000 (seed and self-hosted paths both report the same error)
    let src = "macro loop2 { () => loop2() }\nloop2()";
    let err = common::run(src).expect_err("should report depth limit");
    assert!(
        err.contains("macro expansion depth exceeds the limit 10000"),
        "actual error: {}",
        err
    );
}

// ---- negative cases: guardrails and boundaries (positive:negative ratio ≥1:3) ----

/// Infinite-tail-loop instruction-budget guardrail (budget-injection style
/// — the real cap of 10^9 is too slow, so the test injects a small budget
/// for a fast trigger): constant frame count → the frame limit never
/// triggers → the instruction budget is the backstop.
#[test]
fn instruction_budget_guards_infinite_tail_loop() {
    let src = "fn l() { l() }\nl()";
    let out = compile_source(src, "<tco>.ktf").expect("compile failed");
    let mut globals: HashMap<Symbol, Value> = HashMap::new();
    let mut heap = kerf_runtime::Heap::new();
    let err = run_program_with_budget(&out.program, &mut globals, &mut heap, 10_000)
        .expect_err("no restriction tail loop should trigger instruction pre-compute guardrail");
    assert!(
        err.message
            .contains("instruction count exceeds the limit 10000"),
        "actual error: {}",
        err.message
    );
    assert!(
        err.message.contains("suspected infinite loop"),
        "guardrail error should contain suspected infinite loop hint: {}",
        err.message
    );
}

/// Tail-call arity mismatch (parameter validation on the frame-reuse path
/// shares the same caliber as Call).
#[test]
fn tail_call_arity_mismatch_reports() {
    let err = common::run("fn f(x: i64) { x } fn g() { f(1, 2) } g()")
        .expect_err("should report an error");
    assert!(
        err.contains("procedure argument count mismatch"),
        "actual error: {}",
        err
    );
}

/// Tail call of a non-function value (a structured error with the same caliber as Call).
#[test]
fn tail_call_non_callable_reports() {
    let err = common::run("fn f() { 5() } f()").expect_err("should report an error");
    assert!(err.contains("uncallable value"), "actual error: {}", err);
}

/// Non-tail deep recursion remains protected by the frame limit (TCO stays
/// within bounds — non-tail calls consume frames as usual).
#[test]
fn non_tail_deep_recursion_still_frame_limited() {
    let err =
        common::run("fn c(n: i64) -> i64 { if (n == 0) { 0 } else { 1 + c(n - 1) } } c(105001)")
            .expect_err("non-tail deep recursion should report frame limit");
    assert!(
        err.contains("call frame limit exceeded 100000"),
        "actual error: {}",
        err
    );
}

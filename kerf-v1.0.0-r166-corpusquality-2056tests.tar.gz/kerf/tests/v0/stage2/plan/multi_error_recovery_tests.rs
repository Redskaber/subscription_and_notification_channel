// E6 close-out (r154 / 224-b6): converted to the target-syntax face.
//! Batch G (r17) — TD-013 multi-error collection and recovery-expansion
//! implementation tests (38-e).
//!
//! Item-by-item landing of the five r7 design acceptance criteria
//! (stage-1/multi-error-recovery-design.md) + dual-path (seed/self-hosted
//! bridge) isomorphism:
//! 1. Form-level recovery: the failing form is skipped and subsequent forms
//!    expand normally (the output includes them);
//! 2. Collection cap 128 + truncation notice;
//! 3. Order = source position (same caliber as check_program);
//! 4. Zero breakage of existing tests (the single-error short-circuit API
//!    `check_source` behavior-unchanged anchor);
//! 5. This suite ≥12 cases (recovery/skipping/cap/order/partial output/
//!    short-circuit boundaries).
//!
//! E6 close-out carrier swap: the historic expansion-error sample `()`
//! (E0002 "empty list cannot be evaluated as an expression") is a nil
//! literal on the target face — the reads-fine-errors-at-expand carrier
//! is now the define-in-expression-position shape `|| { define(y, 2); y };`
//! (the block threading wraps the define call in a do — the expander's
//! E0002 define-position family; both faces read OK + error at expand,
//! the real recovery-path trigger criterion). The trailing `;` is
//! required: without it a following `||` form would lex into the previous
//! expression as a binary `||` continuation (expression-statement
//! threading — calibrated by running). The legacy single-error
//! short-circuit test was retired with the S-expr face (check_source
//! and check_source_recover converged onto check_source_recover
//! — E6-CG §1; record: 224-b6, 1 test).

use kerf_driver::check_source_recover;
use kerf_driver::Stage;
use kerf_expander::{expand_program_recover, DiagCollector, ExpandCtxt, MAX_DIAGNOSTICS};
use kerf_reader::read_source;
use kerf_syntax::SymbolTable;

const FNAME: &str = "recovery-test.ktf";

/// The E0002 expansion-error carrier (target face): a define call inside
/// a closure-body block — reads fine, errors at expand (the block
/// threading wraps it in a do; the expander's define-position family).
/// The trailing `;` keeps the form a complete statement so consecutive
/// carriers read independently (`||` at a fresh statement start — not a
/// binary continuation of the previous expression).
const BAD: &str = "|| { define(y, 2); y };";

/// read + seed recovery expansion (expander-layer direct — bypassing the driver pipeline).
fn seed_recover(src: &str) -> kerf_expander::RecoveredExpansion {
    let mut sm = kerf_span::SourceMap::new();
    let file_id = sm.add_file(FNAME, src);
    let mut table = SymbolTable::new();
    let forms = read_source(src, file_id, &mut table).expect("read should succeed");
    let mut ctx = ExpandCtxt::new(table);
    expand_program_recover(&forms, &mut ctx)
}

// ---------------------------------------------------------------------------
// Seed expander layer (recovery-semantics units)
// ---------------------------------------------------------------------------

#[test]
fn seed_recovery_skips_failing_form_and_keeps_rest() {
    // r7 acceptance criterion 1 in spirit: good/bad/good — the bad form is
    // collected, the good forms' output is kept
    let r = seed_recover(&format!("let x = 1;\n{BAD}\nlet y = 2;\n"));
    assert_eq!(r.diags.len(), 1, "empty form should report E0002");
    assert_eq!(r.core.len(), 2, "two define should normal expand");
    assert!(!r.is_clean());
    // Output semantics: define y is in the output (the expansion-layer
    // equivalent of the r7 acceptance's "compiled output contains y")
    let has_y = r
        .core
        .iter()
        .any(|e| matches!(e, kerf_core::ModuleItem::Define { .. }));
    assert!(
        has_y,
        "define item should reserved(r49 D59 declaration layer)"
    );
}

#[test]
fn seed_recovery_reports_all_errors_across_forms() {
    // Three bad forms → three diagnostics (the contrast surface for single-error short-circuiting)
    let r = seed_recover(&format!("{BAD}\n{BAD}\n{BAD}\n"));
    assert_eq!(r.diags.len(), 3);
    assert_eq!(r.core.len(), 0);
}

#[test]
fn seed_recovery_sorted_by_source_position() {
    // r7 acceptance criterion 3: collected out of order → exported in position order
    // r158 / 228-c: the carriers recalibrated for the modern binding prefix
    // (`let a = 1;` = 11 bytes vs the retired call form's 14 — the first
    // carrier's define token at 16, the second at 51)
    let src = format!("let a = 1;\n{BAD}\nlet b = 2;\n{BAD}\nlet c = 3;\n");
    let r = seed_recover(&src);
    assert_eq!(r.diags.len(), 2);
    let sorted = r.diags.clone().into_sorted();
    let starts: Vec<u32> = sorted.iter().map(|e| e.span.start).collect();
    let mut expected = starts.clone();
    expected.sort();
    assert_eq!(starts, expected, "times order = source position");
    // The two carriers sit at known source positions (the `define` call of
    // the line-2 carrier at 16; the line-4 carrier at 51 — calibrated by
    // running on the target face)
    assert_eq!(
        starts,
        vec![16, 51],
        "times order = source position(computed)"
    );
}

#[test]
fn seed_recovery_cap_128_with_early_termination() {
    // r7 acceptance criterion 2: >128 errors → exactly 128 collected +
    // truncation mark + early termination (subsequent forms are no longer
    // expanded — storm protection)
    let mut src = String::new();
    for _ in 0..140 {
        src.push_str(BAD);
        src.push('\n');
    }
    src.push_str("let after = 1;\n");
    let r = seed_recover(&src);
    assert_eq!(r.diags.len(), MAX_DIAGNOSTICS);
    assert!(r.diags.truncated(), "truncation tag should set position");
    // Early termination: from the 129th bad form on, nothing is expanded or
    // collected — and the recovered output does not contain the 140 bad
    // forms (core empty — the recovery loop breaks once full)
    assert!(
        r.core.is_empty(),
        "full after remaining form not expand(containing after)"
    );
}

#[test]
fn collector_unit_cap_and_truncation_flag() {
    // Collector unit: cap 128 + pushing 129 → 128 stored + truncated
    let mut c = DiagCollector::default();
    for i in 0..MAX_DIAGNOSTICS + 1 {
        c.push(kerf_expander::ExpandError {
            message: format!("e{}", i),
            span: kerf_span::Span::dummy(),
        });
    }
    assert_eq!(c.len(), MAX_DIAGNOSTICS);
    assert!(c.truncated());
    assert!(c.is_full());
}

#[test]
fn clean_program_recovers_nothing() {
    // Zero-error program: the recovery path = the short-circuit path (empty collection)
    let r = seed_recover("let x = 1;\nx + 2\n");
    assert!(r.is_clean());
    assert_eq!(r.core.len(), 2);
    assert_eq!(r.diags.len(), 0);
}

// ---------------------------------------------------------------------------
// driver integration layer (the check_source_recover full chain)
// ---------------------------------------------------------------------------

#[test]
fn driver_recover_report_merges_expand_and_type_diagnostics() {
    // Mixed surface: an expand error (E0002 empty form) + a typecheck error
    // (E0005 head arity) reported together + position order
    let src = format!("let x = 1;\n{BAD}\nhead()\n");
    let report = check_source_recover(&src, FNAME).expect("recovery path should produce a report");
    assert_eq!(report.diagnostics.len(), 2, "E0002 + E0005 each one");
    // Order: the define-position form (line 2) before head (line 3)
    assert!(report.diagnostics[0].primary_span.start < report.diagnostics[1].primary_span.start);
    // Output: x's define enters compilation (partial output continues through the full pipeline)
    assert!(
        report.proto_count >= 1,
        "part partition artifact should compile output prototype"
    );
}

#[test]
fn driver_recover_partial_product_contains_later_defines() {
    // r7 acceptance criterion 1 in full: the y define after the failing form compiles as usual
    let src = format!("let x = 1;\n{BAD}\nlet y = 2;\ny\n");
    let report = check_source_recover(&src, FNAME).expect("should produce a report");
    assert_eq!(report.diagnostics.len(), 1);
    // Output contains y: instruction count after the failing form vs the
    // x-only count (define y + the y reference both emit instructions) —
    // compared against the "y absent" control program
    let control = check_source_recover("let x = 1;\nlet y = 2;\ny\n", FNAME)
        .expect("comparison should produce a report");
    assert!(control.diagnostics.is_empty());
    assert_eq!(
        report.instruction_count, control.instruction_count,
        "recovery artifact and no wrong comparison instruction count consistent(y complete enter input compile)"
    );
}

#[test]
fn driver_recover_rendered_lines_sorted_and_complete() {
    // Rendering surface: one line each + position order (E0002 before E0005 — source position)
    let src = format!("{BAD}\nlet x = 1;\nhead()\n");
    let report = check_source_recover(&src, FNAME).expect("should produce a report");
    // rendered includes the combined error diagnostics + W-level warnings
    // from both channels (after r42/S1 the W surface = W1002/W1003; here
    // the head() arity error goes to the error channel)
    assert_eq!(
        report.rendered.len(),
        report.diagnostics.len() + report.warnings.len()
    );
    // First entry = the define-position form (line 1) → message contains
    // the E0002 define-position family
    assert!(
        report.rendered[0].contains("define is only allowed"),
        "first clauses: {}",
        report.rendered[0]
    );
    assert!(
        report.rendered[1].contains("head"),
        "times clauses: {}",
        report.rendered[1]
    );
}

#[test]
fn driver_recover_read_error_still_short_circuits() {
    // Short-circuit boundary 1: a read lexical error → DriverError (not a report — r7 design §5)
    let e =
        check_source_recover("define(x, 1", FNAME).expect_err("read wrong should short-circuit");
    assert!(matches!(e.stage, Stage::Read));
}

#[test]
fn driver_recover_capability_gate_still_short_circuits() {
    // Short-circuit boundary 2: E0006 fail-closed (r8 ruling — the
    // recovery surface does not cover capability violations)
    let e = check_source_recover(&format!("print(1);\n{BAD}"), FNAME)
        .expect_err("E0006 should short-circuit");
    assert!(matches!(e.stage, Stage::Compile));
    assert!(
        e.rendered.contains("insufficient capability permission") || e.rendered.contains("E0006")
    );
}

// (Retired with the S-expr face — E6-CG §1: check_source and
// check_source_recover converged onto check_source_recover; the
// single-error short-circuit API distinction no longer exists. Record:
// 224-b6, 1 test — `legacy_check_source_single_error_semantics_unchanged`.)

#[test]
fn legacy_typecheck_multi_error_still_works_via_recover() {
    // The existing typecheck multi-error surface (r7 design §5's first
    // consumer surface) continues via the recovery entry: all three E0005
    // reported
    let src = "head()\ntail()\n1 + \"s\"\n";
    let report = check_source_recover(src, FNAME).expect("should produce a report");
    assert_eq!(
        report.diagnostics.len(),
        3,
        "three typecheck wrong all report"
    );
}

#[test]
fn recover_truncation_note_appended_to_rendered() {
    // Truncation notice line (r7 design §2: warning-level summary — a rendered tail note)
    let mut src = String::new();
    for _ in 0..MAX_DIAGNOSTICS + 5 {
        src.push_str(BAD);
        src.push('\n');
    }
    let report = check_source_recover(&src, FNAME).expect("should produce a report");
    assert_eq!(report.diagnostics.len(), MAX_DIAGNOSTICS);
    let last = report.rendered.last().expect("truncation hint should in");
    assert!(last.contains("limit"), "truncation hint: {}", last);
}

// ---------------------------------------------------------------------------
// Dual-path isomorphism (seed recovery vs self-hosted bridge recovery — parity discipline)
// ---------------------------------------------------------------------------

#[test]
fn bootstrap_bridge_recovery_matches_seed_path() {
    // Same program: bridge recovery (the production path) and seed
    // recovery agree on (diag count, output count)
    use kerf_driver::bootstrap::expander;
    let src = format!("let x = 1;\n{BAD}\nlet y = 2;\n");
    // seed
    let seed = seed_recover(&src);
    // bridge (needs file_id and table — a minimal assembly isomorphic to the driver recovery entry)
    let mut sm = kerf_span::SourceMap::new();
    let file_id = sm.add_file(FNAME, &src);
    let mut table = SymbolTable::new();
    let forms = read_source(&src, file_id, &mut table).expect("read should succeed");
    let bridge = expander::expand_program_recover(&forms, file_id, &mut table)
        .expect("bridge should can use");
    assert_eq!(
        bridge.diags.len(),
        seed.diags.len(),
        "diagnostic count consistent"
    );
    assert_eq!(
        bridge.core.len(),
        seed.core.len(),
        "artifact count consistent(x/y two define)"
    );
    assert_eq!(bridge.diags.len(), 1);
    assert_eq!(bridge.core.len(), 2);
    // Bridge error semantics are isomorphic (E0002-family messages)
    let sorted = bridge.diags.into_sorted();
    assert!(
        sorted[0].message.contains("define is only allowed"),
        "bridge error: {}",
        sorted[0].message
    );
}

#[test]
fn run_source_execution_path_still_single_error() {
    // r7 design §5: the execution path does not recover (runtime
    // short-circuit preserved) — recover belongs to compile time only
    let e = kerf_driver::run_source(&format!("let x = 1;\n{BAD}\n"), FNAME)
        .expect_err("execution path should short-circuit");
    assert!(matches!(e.stage, Stage::Expand));
}

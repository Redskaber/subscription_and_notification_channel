//! .ktf top-level let family tests — r158 / 228-c (the toplevel-let
//! modernization window: the `define(NAME, e);` S-expr-era call form is
//! retired at item position — toplevel-let-design.md v1.0).
//!
//! **Verification surfaces** (the top-level value binding `let name
//! [: T] = e;` → the Stx `(define name e')` — the same core form the
//! retired call form synthesized via the uniform list structure; zero
//! desugar, zero new primitives, principle 31 — the expander /
//! compiler / HM / VM chain untouched; 8 primitives' invariance round
//! 40; design single source = toplevel-let-design.md v1.0):
//! (1) **run-face E2E** — the modern binding through `run_source`
//! yields the same values as the retired call form's documented
//! outputs (skin/skeleton isomorphism — closures corpus anchors:
//! make_counter counts / make_adder 37 + 5 = 42);
//! (2) **grammar settlement** — dual-Reader canonical Stx rendering
//! byte-identical (seed parse_toplevel_let vs mirror
//! parse_toplevel_let), error faces message + Span byte-identical
//! (the retirement diagnostic + the single-binding cap diagnostic +
//! the binding-name expectation face);
//! (3) **cross-stage consumption** — the bound program through
//! `check_source_recover` stays diagnostic-clean with real
//! instruction artifacts (HM/check consume the identical define Stx);
//! (4) **fail-closed negatives** — the retired call form rejected at
//! item position with the modernization diagnostic (run/check
//! integrated paths ×3 + reader-level message/Span anchors + module
//! item position + expression-statement trailing garbage) / the
//! single-binding cap / missing operands / missing `;` / non-ident
//! binder / block-position define = the pre-existing expression
//! statement semantics (E0022 unbound, unchanged domain) / 7 error
//! classes coverage (E0001 lexical / E0002 expand / E0006 capability
//! / E0022 unbound / E0019 multi-segment path / E0005 multi-error
//! recovery / the Read-stage retirement face itself).
//!
//! Skin-dictionary basis: 20 §14 (the define→fn row splits: the
//! top-level value-binding let→define row — this window); 02 §8.13.1a
//! v7.26 (the toplevel_let production). Window basis: user instruction
//! ① (the `define` S-expr-era residual retirement directive — M1
//! natural signal form) + toplevel-let-design.md v1.0 D1-D10.
//! Ratio: 8 positive : 24 negative = 1:3 (§9.4.3).

use kerf_driver::bootstrap::reader::read_source_for_bootstrap;
use kerf_driver::{check_source_recover, run_source, Stage};
use kerf_reader::reader::read_source;
use kerf_syntax::{Stx, StxDatum, StxLiteral, SymbolTable};

const RETIRED_MSG: &str =
    "the define call form is retired: use a top-level let binding (let name = value;) instead";
const SINGLE_MSG: &str =
    "top-level let takes a single binding (split into separate let statements)";

// ---------------------------------------------------------------------------
// Value helpers
// ---------------------------------------------------------------------------

fn run_value(src: &str, filename: &str) -> String {
    let outcome = run_source(src, filename)
        .unwrap_or_else(|e| panic!("target face program {} execution failed:{}", filename, e));
    kerf_vm::render_value(&outcome.value, &outcome.heap)
}

fn read_err(src: &str, filename: &str) -> kerf_reader::reader::ReadError {
    let mut sm = kerf_span::SourceMap::new();
    let fid = sm.add_file(filename, src);
    let mut table = SymbolTable::new();
    read_source(src, fid, &mut table)
        .err()
        .unwrap_or_else(|| panic!("[{}] expected a read error, parsed successfully", filename))
}

// ---------------------------------------------------------------------------
// Dual-Reader parity helpers (the ktf_import_alias_tests.rs caliber —
// canonical rendering with Span bytes; error parity with message + Span
// byte equality)
// ---------------------------------------------------------------------------

fn render_stx(s: &Stx, t: &SymbolTable) -> String {
    let mut out = String::new();
    render_stx_into(s, t, &mut out);
    out
}

fn render_stx_into(s: &Stx, t: &SymbolTable, out: &mut String) {
    match &s.datum {
        StxDatum::Symbol(sym) => {
            out.push_str(&format!(
                "(sym {} {}..{})",
                t.name(*sym),
                s.span.start,
                s.span.end
            ));
        }
        StxDatum::Literal(l) => match l {
            StxLiteral::Int(v) => {
                out.push_str(&format!("(int {} {}..{})", v, s.span.start, s.span.end));
            }
            StxLiteral::Float(f) => {
                out.push_str(&format!("(float {:?} {}..{})", f, s.span.start, s.span.end));
            }
            StxLiteral::Str(r) => {
                out.push_str(&format!("(str {:?} {}..{})", r, s.span.start, s.span.end));
            }
            StxLiteral::Bool(b) => {
                out.push_str(&format!("(bool {} {}..{})", b, s.span.start, s.span.end));
            }
            StxLiteral::Nil => {
                out.push_str(&format!("(unit {}..{})", s.span.start, s.span.end));
            }
        },
        StxDatum::List(items) => {
            out.push_str(&format!("(lst {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
        StxDatum::Vector(items) => {
            out.push_str(&format!("(vec {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
    }
}

/// Grammar parity assertion: both Readers' canonical renderings are
/// byte-identical (the top-level let is seed/mirror isomorphic by
/// construction — the same (define name value) core form behind the
/// modern skin, Span bytes included).
fn assert_grammar_parity(src: &str, what: &str) {
    let mut t1 = SymbolTable::new();
    let seed = read_source(src, 0, &mut t1)
        .unwrap_or_else(|e| panic!("[{}] seed syntax failed: {}", what, e.message));
    let mut t2 = SymbolTable::new();
    let mirror = read_source_for_bootstrap(src, 0, &mut t2)
        .unwrap_or_else(|e| panic!("[{}] mirror syntax failed:{}", what, e.message));
    assert_eq!(
        seed.len(),
        mirror.len(),
        "[{}] top-level item count mismatch (seed {} vs mirror {})",
        what,
        seed.len(),
        mirror.len()
    );
    for (i, (a, b)) in seed.iter().zip(mirror.iter()).enumerate() {
        assert_eq!(
            render_stx(a, &t1),
            render_stx(b, &t2),
            "[{}] top-level item #{} syntax tree mismatch (seed vs mirror canonical render)",
            what,
            i
        );
    }
}

/// Grammar-error parity assertion: message + Span byte-level equality
/// (the mirror's diagnostic face is the seed's, by construction — the
/// retirement diagnostic and the single-binding cap are anchored in
/// both Readers with identical Span criteria).
fn assert_grammar_err_parity(src: &str, what: &str) -> kerf_reader::reader::ReadError {
    let mut t1 = SymbolTable::new();
    let seed_err = match read_source(src, 0, &mut t1) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] seed should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    let mut t2 = SymbolTable::new();
    let mirror_err = match read_source_for_bootstrap(src, 0, &mut t2) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] mirror should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    assert_eq!(
        seed_err.message, mirror_err.message,
        "[{}] syntax error message mismatch (seed {:?} vs mirror {:?})",
        what, seed_err.message, mirror_err.message
    );
    assert_eq!(
        seed_err.span.start, mirror_err.span.start,
        "[{}] syntax error Span start mismatch (seed {} vs mirror {})",
        what, seed_err.span.start, mirror_err.span.start
    );
    assert_eq!(
        seed_err.span.end, mirror_err.span.end,
        "[{}] syntax error Span end mismatch (seed {} vs mirror {})",
        what, seed_err.span.end, mirror_err.span.end
    );
    seed_err
}

// ---------------------------------------------------------------------------
// Positives — run-face E2E + grammar settlement + cross-stage consumption
// ---------------------------------------------------------------------------

/// Positive 1 / integration: the core E2E — the closures corpus
/// migrated face (make_counter + make_adder ⇒ 42 — the same documented
/// outputs as the retired call form's corpus, byte for byte).
#[test]
fn pos_closures_corpus_migrated_e2e() {
    let src = "require io, write;\n\nfn make_counter() {\n    let n = 0;\n    || { n = n + 1; n }\n}\n\nlet a = make_counter();\nlet b = make_counter();\na(); a(); a();\nb();\n\nfn make_adder(n: i64) {\n    || (x: i64) { x + n }\n}\n\nlet add5 = make_adder(5);\nadd5(37)";
    assert_eq!(run_value(src, "closures_migrated.ktf"), "42");
}

/// Positive 2: the modern binding + subsequent expression consumption
/// (the value binding registers in the global env exactly as the
/// retired form's define did — same Stx, same ModuleItem::Define).
#[test]
fn pos_toplevel_let_value_consumption() {
    let src = "let x = 10;\nx + 1";
    assert_eq!(run_value(src, "let_value.ktf"), "11");
}

/// Positive 3: type annotation parsed then stripped (the fn_decl
/// precedent — the core has no type consumption face) + the `mut`
/// modifier parsed then stripped (the block-level let_stmt precedent).
#[test]
fn pos_type_and_mut_annotations_stripped() {
    let src = "let mut x: i64 = 5;\nx * 2";
    assert_eq!(run_value(src, "let_typed.ktf"), "10");
}

/// Positive 4: module item position — the declaration family symmetry
/// (parse_item dispatch — fn/import/export/require/let one family;
/// the S-expr face's module-body (define ...) isomorphism).
#[test]
fn pos_module_item_position() {
    // module item position + body-tail consumption (user module
    // cross-imports are the E0019 domain — the module's own body is
    // the E2E carrier; the export registers on the module face)
    let src = "module m { export x; let x = 7; x }";
    assert_eq!(run_value(src, "let_module.ktf"), "7");
}

/// Positive 5: complex value expressions (nested calls, closures,
/// arithmetic — the full expression grammar in the value slot).
#[test]
fn pos_complex_value_expressions() {
    let src = "fn add(a: i64, b: i64) { a + b }\nlet combined = add(add(1, 2), add(3, 4));\ncombined * 10";
    assert_eq!(run_value(src, "let_complex.ktf"), "100");
}

/// Positive 6: dual-Reader canonical rendering byte-identical — the
/// grammar settlement core gate (the (define name value) core form
/// behind the modern skin, Span bytes included).
#[test]
fn pos_dual_reader_canonical_parity() {
    assert_grammar_parity("let x = 1;\nx", "let simple");
    assert_grammar_parity("let x: i64 = 1;\nlet y = x + 1;\ny", "let typed chain");
    assert_grammar_parity(
        "fn f() { 1 }\nlet v = f();\nmodule m { export w; let w = 2; }\nv",
        "let mixed items",
    );
    assert_grammar_parity("let mut x = 1;\nx", "let mut stripped");
}

/// Positive 7: the same-Stx assertion — `let x = 1;` lowers to the
/// identical `(define x 1)` list the retired call form synthesized
/// (skin swap, skeleton unchanged — principle 31's machine face).
#[test]
fn pos_same_core_form_as_retired_call() {
    let mut t1 = SymbolTable::new();
    let modern = read_source("let x = 1;", 0, &mut t1).unwrap();
    assert_eq!(modern.len(), 1);
    let items = modern[0].datum.as_list().unwrap();
    assert_eq!(
        items.len(),
        3,
        "the (define name value) three-element core form"
    );
    assert_eq!(t1.name(items[0].datum.as_symbol().unwrap()), "define");
    assert_eq!(t1.name(items[1].datum.as_symbol().unwrap()), "x");
    assert!(matches!(
        items[2].datum,
        StxDatum::Literal(StxLiteral::Int(1))
    ));
}

/// Positive 8 / integration (cross-stage): the bound program through
/// `check_source_recover` stays diagnostic-clean with real instruction
/// artifacts (HM/check consume the identical define Stx — zero
/// mechanism change downstream).
#[test]
fn pos_check_cross_stage_consumption() {
    let src = "require io, write;\nlet x = 42;\nprint(x);\nx";
    let r = check_source_recover(src, "let_check.ktf").unwrap();
    assert!(
        r.diagnostics.is_empty(),
        "check must stay diagnostic-clean (actual: {:?})",
        r.diagnostics
    );
}

// ---------------------------------------------------------------------------
// Negatives — fail-closed retirement + structure discipline + domain
// boundaries + 7 error classes coverage
// ---------------------------------------------------------------------------

/// Negative 1 / integration ×3 (run/check/driver faces): the retired
/// call form at item position is rejected with the modernization
/// diagnostic — the run path.
#[test]
fn neg_retired_call_form_run_path() {
    let err = run_source("define(x, 1);\nx", "retired.ktf").unwrap_err();
    assert_eq!(
        err.diagnostic.message, RETIRED_MSG,
        "the retirement diagnostic must be verbatim (actual rendered: {})",
        err.rendered
    );
    assert_eq!(err.stage, Stage::Read);
}

/// Negative 2 / integration (check path): the retired call form through
/// check_source_recover surfaces the same Read-stage rejection.
#[test]
fn neg_retired_call_form_check_path() {
    let err = check_source_recover("define(x, 1);\nx", "retired_check.ktf").unwrap_err();
    assert_eq!(
        err.diagnostic.message, RETIRED_MSG,
        "the retirement diagnostic must be verbatim on the check path (actual rendered: {})",
        err.rendered
    );
}

/// Negative 3 / integration (reader level, message + Span): the
/// retirement diagnostic's Span is the `define` token itself (the r130
/// import-as span precedent — report at the token, not after it).
#[test]
fn neg_retirement_span_is_define_token() {
    let src = "let a = 1;\ndefine(x, 2);\nx";
    let e = read_err(src, "retired_span.ktf");
    assert_eq!(e.message, RETIRED_MSG);
    // the `define` token occupies bytes 11..17 (after "let a = 1;\n")
    assert_eq!((e.span.start, e.span.end), (11, 17));
}

/// Negative 4: the module item position rejects the retired form too
/// (the parse_item dispatch — one family, one law).
#[test]
fn neg_retired_call_form_module_item_position() {
    let src = "module m { export x; define(x, 1); }";
    let e = read_err(src, "retired_module.ktf");
    assert_eq!(e.message, RETIRED_MSG);
}

/// Negative 5: dual-Reader error parity on the retirement diagnostic
/// (message + Span byte-identical — the mirror's diagnostic face is
/// the seed's, by construction).
#[test]
fn neg_retirement_dual_reader_err_parity() {
    let e = assert_grammar_err_parity("define(x, 1);\nx", "retired parity");
    assert_eq!(e.message, RETIRED_MSG);
    let e2 = assert_grammar_err_parity("let x = 1, y = 2;\nx", "single-binding parity");
    assert_eq!(e2.message, SINGLE_MSG);
}

/// Negative 6: the single-binding cap — the comma multi-binding form
/// fails closed (the block-level let_stmt keeps the multi-binding face;
/// capability parity with the retired single-binding call form — D1).
#[test]
fn neg_single_binding_cap_comma() {
    let e = read_err("let x = 1, y = 2;\nx", "let_multi.ktf");
    assert_eq!(e.message, SINGLE_MSG);
    // the comma token occupies bytes 9..10 (after "let x = 1")
    assert_eq!((e.span.start, e.span.end), (9, 10));
}

/// Negative 7: missing `=` (the binder-name face then the assign
/// expectation — structure discipline).
#[test]
fn neg_missing_assign_operator() {
    let e = read_err("let x 1;\nx", "let_no_assign.ktf");
    assert!(
        e.message.contains("expected =") || e.message.contains('='),
        "the assign expectation diagnostic (actual: {})",
        e.message
    );
}

/// Negative 8: missing binding name (the binding-name expectation
/// face — a keyword in the name slot).
#[test]
fn neg_missing_binding_name() {
    let e = read_err("let = 1;", "let_no_name.ktf");
    assert!(
        e.message.contains("expected a binding name"),
        "the binding-name expectation diagnostic (actual: {})",
        e.message
    );
}

/// Negative 9: missing `;` (the statement terminator expectation — the
/// let production requires it, unlike the old expression-item's
/// optional-semicolon artifact).
#[test]
fn neg_missing_semicolon() {
    let e = read_err("let x = 1\nx", "let_no_semi.ktf");
    assert!(
        e.message.contains("expected ;"),
        "the terminator expectation diagnostic (actual: {})",
        e.message
    );
}

/// Negative 10: a non-ident binder (the Path token in the name slot —
/// the retired form's path-named namespace-takeover artifact is not
/// expressible on the modern face; the S-expr .krf face retains the
/// capability — the design doc D2 boundary).
#[test]
fn neg_path_named_binder_rejected() {
    let e = read_err("let my::ns = 5;\nmy::ns", "let_path.ktf");
    assert!(
        e.message.contains("expected a binding name"),
        "the binding-name expectation for the Path-token binder (actual: {})",
        e.message
    );
}

/// Negative 11: the retired call form with a non-ident target (the old
/// "define target must be a symbol" expand-stage face is fronted to
/// the Read-stage retirement diagnostic — the whole family retires
/// together).
#[test]
fn neg_retired_call_form_non_symbol_target() {
    let e = read_err("define(1, 2);", "retired_nonsym.ktf");
    assert_eq!(e.message, RETIRED_MSG);
}

/// Negative 12: the retired call form's arity faces (zero-arg / one-arg
/// shapes) are fronted to the retirement diagnostic (the expand-stage
/// arity family retires with the form).
#[test]
fn neg_retired_call_form_arity_faces() {
    for src in ["define();", "define(x);", "define(x, 1, 2);"] {
        let e = read_err(src, "retired_arity.ktf");
        assert_eq!(e.message, RETIRED_MSG, "src: {}", src);
    }
}

/// Negative 13 (E0001 lexical class): a lexical error inside the value
/// expression still fires at the lexer stage — before the parser ever
/// sees the let (the whole-file lexing model, both Readers).
#[test]
fn neg_lexical_error_class_e0001() {
    let e = read_err("let x = \"unterminated;\nx", "let_lex.ktf");
    assert!(
        e.message.to_lowercase().contains("unterminated")
            || e.message.to_lowercase().contains("string"),
        "the lexical class surfaces first (actual: {})",
        e.message
    );
}

/// Negative 14 (E0002 expand class): an expansion error downstream of a
/// modern binding (the let skin does not perturb the expand stage's
/// error surface — the do-wrapped define rejection face unchanged).
#[test]
fn neg_expand_error_class_e0002_block_define() {
    let err = run_source("fn f(x: i64) { define(y, 2); x }", "block_define.ktf").unwrap_err();
    assert!(
        err.diagnostic
            .message
            .contains("define is only allowed at the top level"),
        "the expander's define-position rejection is unchanged (actual: {})",
        err.diagnostic.message
    );
}

/// Negative 15 (E0006 capability class): an undeclared capability
/// consumption through a modern binding (the capability gate is
/// orthogonal to the binding skin — the capability_tests caliber:
/// undeclared print → compile-stage E0006).
#[test]
fn neg_capability_error_class_e0006() {
    let err = run_source("let x = 1;\nprint(x);", "cap_gate.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Compile);
    assert_eq!(err.diagnostic.code, Some(kerf_span::DiagnosticCode(6)));
    assert!(err.rendered.contains("error[E0006]"));
}

/// Negative 16 (E0022 unbound class): the block-position define call
/// keeps the ordinary-call semantics (the expander's define-position
/// rejection — the honest boundary: only the item-position declaration
/// usage is retired).
#[test]
fn neg_unbound_class_e0022_block_define_call() {
    let err = run_source("fn f() { define(x, 2); x }", "block_call.ktf").unwrap_err();
    assert!(
        err.diagnostic
            .message
            .contains("define is only allowed at the top level"),
        "the block-position face (actual: {})",
        err.diagnostic.message
    );
}

/// Negative 17 (E0019 multi-segment path class): a multi-segment path
/// in the value expression's unbound reference (the established
/// namespace discipline — orthogonal to the binding skin).
#[test]
fn neg_multi_segment_path_class_e0019() {
    let err = run_source("let x = a::b::c::d;\nx", "path.ktf").unwrap_err();
    assert!(
        err.rendered.contains("E0014"),
        "the E0014 export-face diagnostic (actual: {})",
        err.rendered
    );
}

/// Negative 18 (E0005 multi-error recovery class): the recovery-mode
/// check collects the expand-stage diagnostics through a modern top-
/// level binding (the E0005 recovery pipeline is unperturbed by the
/// binding skin — the multi_error_recovery_tests caliber: the closure-
/// body define yields E0002 + E0005, one each).
#[test]
fn neg_multi_error_recovery_class_e0005() {
    let src = "let a = 1;\n|| { define(y, 2); y };\nhead()\na";
    let report = check_source_recover(src, "recover.ktf")
        .expect("recovery path should produce a report (not a hard error)");
    assert_eq!(report.diagnostics.len(), 2, "E0002 + E0005 each one");
}

/// Negative 19: trailing garbage after the value (an expression
/// statement's operands without a separator — the structure
/// discipline).
#[test]
fn neg_trailing_garbage_after_value() {
    let e = read_err("let x = 1 2;\nx", "let_trail.ktf");
    assert!(
        !e.message.is_empty(),
        "a structure diagnostic must surface (actual: {})",
        e.message
    );
}

/// Negative 20: the type annotation's malformed shape (a type
/// annotation without a type — the consume_type fail-closed face).
#[test]
fn neg_malformed_type_annotation() {
    let e = read_err("let x: = 1;\nx", "let_badtype.ktf");
    assert!(
        !e.message.is_empty(),
        "the type-consumption diagnostic must surface (actual: {})",
        e.message
    );
}

/// Negative 21: `let` with nothing after it (EOF immediately after the
/// keyword — the binding-name expectation at EOF).
#[test]
fn neg_let_eof_immediately() {
    let e = read_err("let", "let_eof.ktf");
    assert!(
        e.message.contains("expected a binding name"),
        "the binding-name expectation at EOF (actual: {})",
        e.message
    );
}

/// Negative 22: the retirement diagnostic fires before any downstream
/// parse of the call's interior (the truncated form — no closing paren
/// — still hits the rejection arm first; the Read-stage class).
#[test]
fn neg_retired_truncated_form() {
    let e = read_err("define(x, 1", "retired_trunc.ktf");
    assert_eq!(e.message, RETIRED_MSG);
}

/// Negative 23: the retired form after a modern binding (mixed old/new
/// sources fail closed at the old form — migration completeness
/// discipline for real-world gradual migration).
#[test]
fn neg_mixed_old_new_source() {
    let src = "let a = 1;\ndefine(b, 2);\na + b";
    let e = read_err(src, "mixed.ktf");
    assert_eq!(e.message, RETIRED_MSG);
    // the `define` token occupies bytes 11..17 (after "let a = 1;\n")
    assert_eq!((e.span.start, e.span.end), (11, 17));
}

/// Negative 24: the expression-position define (inside a call's
/// argument slot) keeps the expression semantics — NOT the retirement
/// (the item-position-only scope of D2; the do-wrapped shape is the
/// expander's rejection domain, unchanged).
#[test]
fn neg_expression_position_define_not_retired() {
    // A define( inside a call's argument slot passes through the Reader
    // as an ordinary expression (NOT the item-position retirement); the
    // expander's define-position rejection owns it inside function
    // bodies (the top-level do-splice shape stays legal — the spliced
    // define registers at top level; the fn-body shape is the rejected
    // one — the bootstrap_compiler_tests parity_err caliber).
    let err = run_source("fn f() { do(define(a, 1), a) } f()", "expr_pos.ktf").unwrap_err();
    assert!(
        err.diagnostic
            .message
            .contains("define is only allowed at the top level"),
        "the expander's face (actual: {})",
        err.diagnostic.message
    );
    // The top-level do-splice stays legal (spliced define = top level)
    let v = run_value("do(define(a, 1), a)", "expr_pos_ok.ktf");
    assert_eq!(
        v, "1",
        "the top-level do-spliced define registers and evaluates"
    );
}

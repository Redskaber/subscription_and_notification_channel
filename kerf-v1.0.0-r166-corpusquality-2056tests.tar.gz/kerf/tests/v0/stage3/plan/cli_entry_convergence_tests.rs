//! CLI entry-convergence tests — r153 / 223-c (s-expr-removal-plan §4
//! Batch D: "CLI 入口收敛 .ktf 单面（扩展名分派规则翻转）+ `.krf` 拒收
//! fail-closed 负例族 + 双入口测试族重构"; the r125 / 195-a dual-entry
//! family refactored — the two-Reader coexistence period ends).
//!
//! **Verification surfaces**:
//! (1) **cross-syntax behavioral equivalence** (driver-API level — the
//!     same fib program written in the target syntax, entered through
//!     `run_source` / `check_source_recover` /
//!     `test_runner::run_test_case`, executes through the full production
//!     chain (reader bridge → bootstrap Expander → bootstrap
//!     Compiler → VM) with the same value as the S-expr library face
//!     (principle 31 skin/skeleton isomorphism; the S-expr driver APIs
//!     stay as parity oracles until the E6 close-out deletion);
//! (2) **CLI boundary convergence** — the compiled binary accepts exact
//!     `.ktf` files only; every other entry (`.krf` real file,
//!     `.krf` nonexistent path, no extension, unknown extension,
//!     uppercase `.KTF`) is rejected fail-closed (exit 2 + the
//!     structured retirement diagnostic naming the r153/Batch D basis —
//!     the rejection happens at the dispatch layer, before file reads:
//!     even an unreadable/nonexistent `.krf` path reports the
//!     retirement, not a read error);
//! (3) **driver-API orthogonality** (the filename is a Span tag, not a
//!     dispatch input — the S-expr API reads S-expr source under any
//!     label, the target API reads target source under any label; the
//!     convergence lives at the CLI dispatch layer only);
//! (4) **fail-closed negatives** — S-expr source under the target entry,
//!     lexical/grammar errors, domain-registered out-of-scope constructs
//!     (`use`), expand diagnostics, HM type diagnostics, runtime type
//!     errors, recovery-mode multi-error collection.
//!
//! Cache ruling anchor: every target-syntax entry is cache-free (same
//! basis as `compile_front` — the B11/P4 kind-tag bucket has no
//! syntax dimension; `cache_hit` stays false on the target check face).
//!
//! Basis: s-expr-removal-plan v1.3 §4 Batch D (this file = the
//! "双入口测试族重构" deliverable) / principle 9 (core freeze — pure
//! entry-layer change) / principle 31 (skin/skeleton isomorphism) /
//! §9.4.3 (positive:negative ≥ 1:3) / §11 (interface isolation — CLI
//! forwards, driver holds the pipeline).

use kerf_driver::bootstrap::test_runner;
use kerf_driver::{check_source_recover, dump_stx, dump_tokens, run_source};

/// The fib program in the target syntax (the r107/r108 grammar subset —
/// fn declaration with a stripped-after-parse type/effect signature; the
/// same corpus shape as target_reader_tests).
const TARGET_FIB: &str =
    "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(12)";

/// The same fib program in the S-expression syntax (behavioral parity
/// counterpart of [`TARGET_FIB`]; the retired fib.krf corpus archived
/// inline — r153 / 223-c).
const SEXP_FIB: &str = "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2)))))\n(fib 12)";

// ---------------------------------------------------------------------------
// Positives — cross-syntax behavioral equivalence (driver-API level)
// ---------------------------------------------------------------------------

/// Positive 1 / integration / cross-stage consumption: the target-syntax
/// fib program through `run_source` (reader bridge →
/// bootstrap Expander → bootstrap Compiler → VM) yields the program
/// value 144 — the CLI run boundary E2E (the S-expr oracle leg retired
/// with the S-expr face at the E6 close-out r154 / 224-b).
#[test]
fn target_fib_run_e2e_value() {
    let target_outcome = run_source(TARGET_FIB, "fib.ktf")
        .unwrap_or_else(|e| panic!("target syntax fib execution failed:{}", e));
    let run_value = kerf_vm::render_value(&target_outcome.value, &target_outcome.heap);
    assert_eq!(run_value, "144", "target syntax fib(12) program value");
}

/// Positive 2 / integration: the target-syntax check face
/// (`check_source_recover`) — zero diagnostics for a well-formed
/// target program, non-empty instruction artifacts, cache-free basis, and
/// the dump faces (`dump_stx` / `dump_tokens`) render the
/// target surface (one case carries the dump positives).
#[test]
fn target_check_ok_and_dump_faces() {
    let report = check_source_recover(TARGET_FIB, "fib.ktf")
        .unwrap_or_else(|e| panic!("target syntax check failed:{}", e));
    assert!(
        report.diagnostics.is_empty(),
        "well-formed goal program zero diagnostics (actual: {:?})",
        report.rendered
    );
    assert!(
        report.instruction_count > 0,
        "check artifact instruction count > 0(actual {})",
        report.instruction_count
    );
    assert!(
        report.proto_count > 0,
        "check artifact prototype count > 0(actual {})",
        report.proto_count
    );
    assert!(
        !report.cache_hit,
        "target syntax entry cache-free basis(B11/P4 no syntax dimension -- cache_hit always false)"
    );
    let stx = dump_stx(TARGET_FIB, "fib.ktf")
        .unwrap_or_else(|e| panic!("target syntax stx dump failed:{}", e));
    assert!(
        stx.contains("fib"),
        "stx dump render containing fib symbol face"
    );
    let toks = dump_tokens(TARGET_FIB, "fib.ktf")
        .unwrap_or_else(|e| panic!("target syntax tokens dump failed:{}", e));
    assert!(
        toks.contains("fn"),
        "tokens dump render containing goal keyword face fn(actual: \n{})",
        toks
    );
    assert!(
        toks.contains("int"),
        "tokens dump render containing literal family face int"
    );
}

/// Positive 3 / integration: the target-syntax test face
/// (`test_runner::run_test_case`) — a `fn` declaration lands in the prelude
/// bucket (ModuleItem::Define — syntax-neutral splitting), a top-level
/// `==` comparison expression is the case (the target `a == b` desugars
/// to `(= a b)` — the assertion predicate), and the case passes.
#[test]
fn target_test_runner_case_pass() {
    let src = "fn double(n: i64) -> i64 { n + n }\ndouble(5) == 10";
    let report = test_runner::run_test_case(src, "double.ktf")
        .unwrap_or_else(|e| panic!("target syntax test execution failed:{}", e));
    assert_eq!(
        report.cases.len(),
        1,
        "fn declaration goes into the pre-bucket, top level expression is sole use case"
    );
    assert!(
        report.cases[0].pass,
        "target syntax cases must pass(detail: {})",
        report.cases[0].detail
    );
    assert!(report.all_passed(), "all cases pass");
}

/// Positive 4 / integration / CLI golden path (subprocess): a real .ktf
/// file through the compiled binary — `kerf run fib.ktf` exits 0 and
/// prints the program value (the single-face production entry
/// end-to-end; the CARGO_BIN_EXE_kerf probe form — the
/// ktf_read_line_sig_tests precedent).
#[test]
fn cli_ktf_run_golden_path_subprocess() {
    use std::process::{Command, Stdio};
    let tmp = std::env::temp_dir().join("kerf-entry-conv-golden.ktf");
    std::fs::write(&tmp, TARGET_FIB).expect("write golden path probe program");
    let out = Command::new(env!("CARGO_BIN_EXE_kerf"))
        .args(["run", tmp.to_str().unwrap()])
        .stdin(Stdio::null())
        .output()
        .expect("should can start kerf sub process");
    let stdout = String::from_utf8_lossy(&out.stdout);
    assert!(
        out.status.success(),
        ".ktf golden path must exit 0, stderr: {}",
        String::from_utf8_lossy(&out.stderr)
    );
    assert!(
        stdout.contains("144"),
        ".ktf golden path must print the program value 144, got: {}",
        stdout
    );
    let _ = std::fs::remove_file(&tmp);
}

// ---------------------------------------------------------------------------
// Negatives — the CLI boundary `.krf` rejection family (fail-closed,
// subprocess form; r153 / 223-c — the s-expr-removal-plan §4 Batch D
// "`.krf` 拒收 fail-closed 负例族" at the compiled-binary boundary)
// ---------------------------------------------------------------------------

/// Shared rejection probe: run `kerf <subcommand> <path>` and assert the
/// fail-closed rejection (exit code 2 — the usage-error family — plus
/// the structured retirement diagnostic naming the retirement and the
/// accepted .ktf face).
fn expect_cli_rejects(subcommand: &str, path: &str) {
    use std::process::{Command, Stdio};
    let out = Command::new(env!("CARGO_BIN_EXE_kerf"))
        .args([subcommand, path])
        .stdin(Stdio::null())
        .output()
        .unwrap_or_else(|e| panic!("{} {}: subprocess failed:{}", subcommand, path, e));
    let stderr = String::from_utf8_lossy(&out.stderr);
    let code = out.status.code().unwrap_or(-1);
    assert_eq!(
        code, 2,
        "{} {} must exit 2(usage-error family -- the fail-closed retirement rejection), got {} stderr: {}",
        subcommand, path, code, stderr
    );
    assert!(
        stderr.contains("retired") && stderr.contains(".ktf"),
        "{} {} must name the retirement and the accepted .ktf face(actual: {})",
        subcommand,
        path,
        stderr
    );
}

/// Negative 1 / CLI boundary: a real S-expression file (existing on
/// disk) is rejected fail-closed at the run subcommand — the dispatch
/// rule flip means the extension, not the content, routes the entry.
#[test]
fn cli_run_rejects_real_krf_file() {
    let tmp = std::env::temp_dir().join("kerf-entry-conv-reject.krf");
    std::fs::write(&tmp, SEXP_FIB).expect("write rejection probe program");
    expect_cli_rejects("run", tmp.to_str().unwrap());
    let _ = std::fs::remove_file(&tmp);
}

/// Negative 2 / CLI boundary: a nonexistent `.krf` path is likewise
/// rejected with the retirement diagnostic (the rejection happens at the
/// dispatch layer, before file reads — an entry-level gate, not a
/// content-level one; the read-error face would be exit 1 "cannot read",
/// distinguishable from the exit 2 retirement face).
#[test]
fn cli_run_rejects_nonexistent_krf_path() {
    expect_cli_rejects("run", "definitely-not-there-153.krf");
}

/// Negative 3 / CLI boundary: no extension / unknown extension — the
/// former default S-expr faces are all rejected (the convergence is
/// total: `.ktf` exact match or nothing).
#[test]
fn cli_run_rejects_no_and_unknown_extension() {
    let tmp = std::env::temp_dir().join("kerf-entry-conv-noext");
    std::fs::write(&tmp, SEXP_FIB).expect("write no-extension probe program");
    expect_cli_rejects("run", tmp.to_str().unwrap());
    let _ = std::fs::remove_file(&tmp);
    let tmp2 = std::env::temp_dir().join("kerf-entry-conv-unknown.txt");
    std::fs::write(&tmp2, SEXP_FIB).expect("write unknown-extension probe program");
    expect_cli_rejects("run", tmp2.to_str().unwrap());
    let _ = std::fs::remove_file(&tmp2);
}

/// Negative 4 / CLI boundary: uppercase `.KTF` does not hit the target
/// face (case-sensitive exact match — the r125 dispatch basis kept
/// verbatim by the flipped rule; a dispatch leak the other way —
/// silently accepting `.KTF` — is the fail-open regression this pins).
#[test]
fn cli_run_rejects_uppercase_ktf_extension() {
    let tmp = std::env::temp_dir().join("kerf-entry-conv-upper.KTF");
    std::fs::write(&tmp, TARGET_FIB).expect("write uppercase-extension probe program");
    expect_cli_rejects("run", tmp.to_str().unwrap());
    let _ = std::fs::remove_file(&tmp);
}

/// Negative 5 / CLI boundary: the rejection spans the subcommand faces —
/// check / tokens / stx all reject the retired entry alike (the
/// convergence is at the shared dispatch layer, not only the run face).
#[test]
fn cli_other_subcommands_reject_krf_alike() {
    let tmp = std::env::temp_dir().join("kerf-entry-conv-multi.krf");
    std::fs::write(&tmp, SEXP_FIB).expect("write multi-subcommand probe program");
    for sub in ["check", "tokens", "stx"] {
        expect_cli_rejects(sub, tmp.to_str().unwrap());
    }
    let _ = std::fs::remove_file(&tmp);
}

// ---------------------------------------------------------------------------
// Negatives — target-entry fail-closed family (driver-API level; the
// r125 legs kept verbatim — the convergence does not touch them)
// ---------------------------------------------------------------------------

/// Negative 6: S-expression source text entered through the
/// target-syntax entry is rejected at the read stage (fail-closed — the
/// target Reader does not silently accept the other skin).
#[test]
fn retired_sexpr_entry_rejected() {
    let err = run_source("(+ 1 2)", "x.ktf")
        .expect_err("S expression source via goal entry must read-stage rejection(fail-closed)");
    let msg = err.to_string();
    assert!(
        !msg.is_empty(),
        "structured error message non-empty(goal Reader out of domain/syntax rejection)"
    );
}

/// Negative 7: unclosed string literal — lexical-level failure through
/// the target entry (the lexical level is not form-level recoverable).
#[test]
fn unclosed_string_lexical_fail() {
    assert!(
        run_source("\"abc", "bad.ktf").is_err(),
        "unclosed string must lexical failed"
    );
}

/// Negative 8: unclosed delimiter — grammar-level failure through the
/// target entry.
#[test]
fn unclosed_brace_grammar_fail() {
    assert!(
        run_source("fn f() { 1", "bad.ktf").is_err(),
        "unclosed brace must syntax failed"
    );
}

/// Negative 9: unbound reference — the compile-stage resolution
/// (E0022, N1/N2/N3 three-face query) fails closed and short-circuits
/// the recovery path (whole-program in nature — the documented
/// short-circuit boundary of `check_recover_from_forms`: recovery covers
/// expand-stage errors; compile errors short-circuit). Behavioral anchor
/// for the target face: the diagnostic message names the symbol.
#[test]
fn unbound_reference_compile_shortcircuit() {
    let err = check_source_recover("undefined_a(1)", "bad.ktf")
        .expect_err("unbound reference = compile-time E0022 resolution, whole-program short-circuit(non-recovery collection face)");
    let msg = err.to_string();
    assert!(
        msg.contains("undefined_a") || msg.contains("unbound reference"),
        "diagnostic must name symbol/unbound family (actual: {})",
        msg
    );
}

/// Negative 10: HM type error — the type-check face through the target
/// syntax entry (`1 + "a"` does not unify; the type-skin signature is
/// stripped after parse, the HM inference sees the core and rejects).
#[test]
fn hm_type_error_diag_target_face() {
    let report = check_source_recover("1 + \"a\"", "bad.ktf")
        .expect("recovery mode: type errors do not short-circuit (diagnostics reachable)");
    assert!(
        !report.diagnostics.is_empty(),
        "HM type errors must produce diagnostics(E0005 family -- actual rendered: {:?})",
        report.rendered
    );
}

/// Negative 11: runtime type error — the run face through the target
/// syntax entry (the type signature is a stripped skin; `f(\"a\")` where
/// `f` doubles its argument fails at the VM `+` needs-number check —
/// compile-time types do not guard the run path, same as the S-expr face).
#[test]
fn runtime_type_error_target_face() {
    let src = "fn f(n: i64) -> i64 { n + n }\nf(\"a\")";
    assert!(
        run_source(src, "bad.ktf").is_err(),
        "run-time type errors must surface via the target entry(+ requires a number)"
    );
}

/// Negative 12: recovery-mode multi-error collection through the target
/// syntax face — an expand-stage error (E0002: `quote()` with no datum)
/// plus a type error (E0005: `1 + "a"`) reported together in source
/// position order (item-level recovery — the TD-013 + r75 TC-DIAGS
/// semantics shared verbatim by the shared tail).
#[test]
fn recovery_multi_error_collection() {
    let src = "quote()\n1 + \"a\"";
    let report = check_source_recover(src, "bad.ktf")
        .expect("recovery mode: per-form collection without short-circuit");
    assert_eq!(
        report.diagnostics.len(),
        2,
        "E0002 + E0005 each one(actual {}: {:?})",
        report.diagnostics.len(),
        report.rendered
    );
    assert!(
        report.rendered[0].contains("E0002"),
        "first diagnostic = E0002 quote malformed (position order)"
    );
    assert!(
        report.rendered[1].contains("E0005"),
        "second diagnostic = E0005 type error(position order)"
    );
}

/// Negative 15: driver-API orthogonality — the syntax choice lives at the
/// CLI dispatch layer, not inside the driver APIs: the S-expr API reads
/// S-expr source even under a `.ktf` filename label, and the target API
/// reads target source even under a `.krf` label (the filename is a Span
/// tag, not a dispatch input — §11 interface isolation).
#[test]
fn driver_api_orthogonality_no_filename_leak() {
    // E6 close-out (r154 / 224-b): the S-expr API leg retired with the
    // S-expr face; the target API reads target source under any filename
    // label (the filename is a Span tag, not a dispatch input — §11
    // interface isolation; the CLI-level extension dispatch rejects
    // non-.ktf — the subprocess family above).
    let target_outcome = run_source(TARGET_FIB, "x.krf")
        .expect("goal API always reads as target syntax read(no file-name dispatch leak)");
    let run_value = kerf_vm::render_value(&target_outcome.value, &target_outcome.heap);
    assert_eq!(run_value, "144", "goal API orthogonal semantics");
}

/// Positive 5 / integration: the require-declaration fib corpus through
/// the target entry — the print capability gate passes (E0006 not
/// triggered ⇒ the declaration registered), the program value is 144,
/// and the check artifacts hold the r125 anchor counts (the cross-syntax
/// comparison legs retired with the S-expr face at E6 r154 / 224-b; the
/// target-side counts are pinned as the fixed anchor).
#[test]
fn target_require_declaration_run_and_check_anchor() {
    let target_src = "require io, write;\nfn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nprint(fib(25))\nfib(12)";
    // Run face: the print gate passes (no E0006) ⇒ the declaration
    // registered; the program value anchor.
    let target_outcome = run_source(target_src, "fib.ktf").unwrap_or_else(|e| {
        panic!(
            "require declaration + print gating: target face execution failed:{}",
            e
        )
    });
    let run_value = kerf_vm::render_value(&target_outcome.value, &target_outcome.heap);
    assert_eq!(run_value, "144", "target face program value");
    // Check face: the r125 anchor counts pinned on the target side.
    let t = check_source_recover(target_src, "fib.ktf")
        .unwrap_or_else(|e| panic!("target face check failed:{}", e));
    assert_eq!(
        (
            t.proto_count,
            t.const_count,
            t.global_ref_count,
            t.instruction_count
        ),
        (2, 9, 5, 38),
        "goal face check artifact anchor counts(r125 anchor pinned at E6)"
    );
}

/// Negative 16: domain-registered out-of-scope construct — a `use`
/// declaration in the target syntax is rejected fail-closed with the
/// structured domain-out diagnostic (switch-window-plan v1.9 §4:
/// use/`::` import-tree = registered out-of-scope, pending the
/// namespace-import semantics window).
#[test]
fn domain_out_use_declaration_fail_closed() {
    let err = run_source("use kerf::foo;", "bad.ktf").expect_err(
        "use declaration = registration out-of-domain construction, must fail-closed rejected",
    );
    let msg = err.to_string();
    assert!(
        !msg.is_empty(),
        "out-of-domain construction structured diagnostics non-empty(use/:: import tree -- carried by a later window)"
    );
}

/// Negative 17: the dump faces fail on malformed target source — the
/// token dump fails at the lexical level (unclosed string: tokenization
/// itself fails), the Stx dump fails at the grammar level (unclosed
/// brace: tokenization succeeds, parsing fails — the level split
/// mirrors the two dump entries).
#[test]
fn dump_faces_error_on_bad_target_source() {
    assert!(
        dump_tokens("\"abc", "bad.ktf").is_err(),
        "tokens dump for lexically bad target corpus must report an error(unclosed string)"
    );
    assert!(
        dump_stx("fn f() { 1", "bad.ktf").is_err(),
        "stx dump for grammatically bad target corpus must report an error(unclosed brace)"
    );
}

/// Negative 18: bench-face dispatch semantics anchor — the target-syntax
/// run is cache-free, so repeated invocations re-execute the full chain
/// deterministically (the bench loop for `.ktf` compiles every round —
/// same value every round).
#[test]
fn bench_face_dispatch_repeatability() {
    for _ in 0..2 {
        let outcome = run_source(TARGET_FIB, "fib.ktf")
            .expect("cache-free re-run: each round an independent full-chain compile");
        let value = kerf_vm::render_value(&outcome.value, &outcome.heap);
        assert_eq!(
            value, "144",
            "re-run determinism(bench loop behavior anchor)"
        );
    }
}

// ---------------------------------------------------------------------------
// r125 require-declaration skin (the eighth skin-dictionary mapping —
// `require io, write;` → `(require io write)`, the declaration family
// follows the import precedent; found as a real gap by the dual-entry
// E2E: without it a .ktf program could not declare the IO capability)
// ---------------------------------------------------------------------------

/// Negative 19: the require-declaration bad forms fail closed — a
/// non-name token (`require 123;`), a missing terminator
/// (`require io`), and a require inside a fn body (statement position —
/// the declaration is top-level only; the expression-position rejection
/// is the readable fail-closed face).
#[test]
fn require_bad_forms_fail_closed() {
    assert!(
        run_source("require 123;", "bad.ktf").is_err(),
        "require non-name must report an error(expected capability name)"
    );
    assert!(
        run_source("require io", "bad.ktf").is_err(),
        "require missing semicolon must report an error(expected;)"
    );
    assert!(
        run_source("fn f() -> i64 { require io; 1 }", "bad.ktf").is_err(),
        "inside a block require must report an error(require top-level declaration position only -- expression position fail-closed)"
    );
}

/// Negative 20: print without the require declaration — the capability
/// gate rejects at the target face with E0006 (the fail-closed
/// registration discipline shared by both skins at the Stx layer).
#[test]
fn require_undeclared_print_e0006() {
    let err = run_source("print(1)", "bad.ktf")
        .expect_err("no require declared print must E0006 insufficient capability rejection");
    let msg = err.to_string();
    assert!(
        msg.contains("E0006") || msg.contains("capability"),
        "E0006 capability gating diagnostics (actual: {})",
        msg
    );
}

/// Negative 21: the dual-Reader require-declaration parsing parity —
/// the seed Reader (kerf-reader/target.rs parse_require_decl) vs
/// the .krf mirror (bootstrap/reader.krf parse-require-decl)
/// produce byte-identical canonical Stx renderings (the r106
/// SyntaxTransitionValidator discipline applied to the new declaration
/// skin; same-source, both sides).
#[test]
fn require_declaration_dual_reader_parity() {
    use kerf_driver::bootstrap::reader::read_source_for_bootstrap;
    use kerf_reader::reader::read_source;
    use kerf_syntax::SymbolTable;

    let src = "require io, write;\nfn f() -> i64 { 1 }\nf()";
    // Seed oracle side
    let mut t0 = SymbolTable::new();
    let seed_forms = read_source(src, 0, &mut t0)
        .unwrap_or_else(|e| panic!("seed side require parse failed:{}", e.message));
    let seed_rendered: Vec<String> = seed_forms
        .iter()
        .map(|f| f.render(&|s| t0.name(s).to_string()))
        .collect();
    // Production mirror side
    let mut t1 = SymbolTable::new();
    let mirror_forms = read_source_for_bootstrap(src, 0, &mut t1)
        .unwrap_or_else(|e| panic!("mirror side require parse failed:{}", e.message));
    let mirror_rendered: Vec<String> = mirror_forms
        .iter()
        .map(|f| f.render(&|s| t1.name(s).to_string()))
        .collect();
    assert_eq!(
        seed_rendered, mirror_rendered,
        "require declaration both sides Reader canonical render byte-level consistent"
    );
    assert!(
        seed_rendered
            .first()
            .map(|s| s.as_str())
            .unwrap_or("")
            .starts_with("(require"),
        "first form = (require io write) canonical form(actual: {:?})",
        seed_rendered.first()
    );
}

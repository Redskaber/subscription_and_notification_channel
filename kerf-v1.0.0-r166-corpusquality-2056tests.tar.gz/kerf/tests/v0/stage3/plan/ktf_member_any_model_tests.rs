// E6 close-out (r154 / 224-c3): corpus converted to the target-syntax face.
//! r142 / 212-c — member/assoc static-face dual-defect gate
//! (member-any-bool-model-design.md D8 matrix: 8 positive : 24 negative = 1:3).
//!
//! Defect ① (P1): the r140 `'sigf` per-position path (`tc-check-pos-rules`
//! → `tc-rule-one`) omitted the `'any` arm — every concrete argument at an
//! `'any` position (member/assoc pos-0, the only `'any` sites) dropped into
//! the else fallback with a spurious "argument type mismatch" diagnostic,
//! and tvar arguments unified with the pseudo `tcon('any)`. The r140 gate
//! missed it: P02's clean positives never exercised a member `'any`
//! position, and N05's `contains`-any assertion let the spurious
//! diagnostic coexist with the true pos-1 detection (coverage-gap
//! analysis, design §1.3). This gate asserts **exact counts** (the
//! contains-any masking gap is closed).
//!
//! Defect ② (P1, E0005 false-positive family — TD-030 precedent): the
//! member Bool predicate modeling false-positives every value-consuming
//! position (`(head (member 2 lst))` → spurious E0005 while the runtime
//! yields 2). Fix = result widened `'bool → 'unknown` on BOTH faces
//! (BUILTIN_SIGS row + TC-SIGS row), aligned with the assoc row and the
//! list/member B2 purification direction; the r80 zero-false-positive
//! contract takes priority over predicate-result precision (design D3).
//! The canonical predicate form is the is-pair wrap (strict bool-if
//! runtime discipline — D4 layer 3).
//!
//! Basis: member-any-bool-model-design.md v1.0 (D1-D8) + hm.rs
//! check_param_rule (oracle Any/var double-arm spec) + builtins.rs
//! BUILTIN_SIGS (row-list single source) + r80 contract (krf ⊆ oracle +
//! zero false positives). Ratio 8:24 (§9.4.3).
//!
//! E6 close-out (r154 / 224-c3): the S-expr seed face retired — the
//! former seed legs now drive the same target chain through the
//! alternate program shape (top-level `define(x, v);` value definitions
//! with a trailing-expression case; the target legs keep the
//! fn-declaration shape), and the N24 dual-face count-parity slot is
//! carried as the cross-shape parity (both assertions calibrated by
//! running).

use kerf_driver::{check_source_recover, run_source};

fn rendered(out: &kerf_driver::RunOutcome) -> String {
    kerf_vm::render_value(&out.value, &out.heap)
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/// Alternate program-shape static check: zero diagnostics (E6 close-out
/// r154 / 224-c3: the S-expr seed face retired — the former seed legs
/// drive the same target chain through the alternate program shape:
/// top-level `define(x, v);` value definitions + a trailing-expression
/// case; the target legs keep the fn-declaration shape).
fn alt_clean(src: &str) {
    let report = check_source_recover(src, "mab.ktf").expect("check must pass compile");
    assert!(
        report.diagnostics.is_empty(),
        "alternate shape must be diagnostic-free: {:?}\nsrc: {}",
        report.rendered,
        src
    );
}

/// Target-face static check: zero diagnostics.
fn target_clean(src: &str) {
    let report = check_source_recover(src, "mab.ktf").expect("check must pass compile");
    assert!(
        report.diagnostics.is_empty(),
        "target face must be diagnostic-free: {:?}\nsrc: {}",
        report.rendered,
        src
    );
}

/// Alternate program-shape static check: exactly `count` diagnostics,
/// one containing `needle` (the r140 contains-any masking gap closure —
/// design §1.3).
fn alt_diag_exactly(src: &str, needle: &str, count: usize) {
    let report = check_source_recover(src, "mabneg.ktf").expect("check must pass compile");
    assert_eq!(
        report.diagnostics.len(),
        count,
        "alternate shape must report exactly {} diagnostic(s): {:?}\nsrc: {}",
        count,
        report
            .diagnostics
            .iter()
            .map(|d| d.message.as_str())
            .collect::<Vec<_>>(),
        src
    );
    assert!(
        report
            .diagnostics
            .iter()
            .any(|d| d.message.contains(needle)),
        "alternate shape diagnostic must contain `{}`\nsrc: {}",
        needle,
        src
    );
}

/// r164 / 235-c (list-self-built-design.md D7): runtime-err helper — the
/// seven list-domain faces' static-domain rows retired with the migration
/// (the injected kerf definitions carry HM generic inference); the fail-
/// closed enforcement moved wholly to the runtime face (messages verbatim
/// with the retired Rust faces). This helper asserts the full E2E shape:
/// static check = zero diagnostics, run = an error containing `needle`.
fn alt_runtime_err(src: &str, needle: &str) {
    let report = check_source_recover(src, "mabrt.ktf").expect("check must pass compile");
    assert!(
        report.diagnostics.is_empty(),
        "self-built face must be static-diagnostic-free: {:?}\nsrc: {}",
        report.rendered,
        src
    );
    let err = run_source(src, "mabrt.ktf").expect_err("run must fail at runtime");
    assert!(
        err.rendered.contains(needle),
        "runtime error must contain `{}`: {}\nsrc: {}",
        needle,
        err.rendered,
        src
    );
}

/// Target-face static check: exactly `count` diagnostics, one containing
/// `needle`.
fn target_diag_exactly(src: &str, needle: &str, count: usize) {
    let report = check_source_recover(src, "mabneg.ktf").expect("check must pass compile");
    assert_eq!(
        report.diagnostics.len(),
        count,
        "target face must report exactly {} diagnostic(s): {:?}\nsrc: {}",
        count,
        report
            .diagnostics
            .iter()
            .map(|d| d.message.as_str())
            .collect::<Vec<_>>(),
        src
    );
    assert!(
        report
            .diagnostics
            .iter()
            .any(|d| d.message.contains(needle)),
        "target face diagnostic must contain `{}`\nsrc: {}",
        needle,
        src
    );
}

/// Alternate program-shape run: value anchor.
fn alt_run(src: &str, needle: &str) {
    let out = run_source(src, "mabrun.ktf")
        .unwrap_or_else(|e| panic!("alternate-shape run failed: {}\nsrc: {}", e.rendered, src));
    let val = rendered(&out);
    assert!(
        val.contains(needle),
        "alternate-shape value anchor `{}`: actual {}\nsrc: {}",
        needle,
        val,
        src
    );
}

/// Target-face run: value anchor.
fn target_run(src: &str, needle: &str) {
    let out = run_source(src, "mabrun.ktf")
        .unwrap_or_else(|e| panic!("target run failed: {}\nsrc: {}", e.rendered, src));
    let val = rendered(&out);
    assert!(
        val.contains(needle),
        "target value anchor `{}`: actual {}\nsrc: {}",
        needle,
        val,
        src
    );
}

/// Alternate program-shape run: expect a runtime error containing
/// `needle`.
fn alt_run_err(src: &str, needle: &str) {
    match run_source(src, "maberr.ktf") {
        Ok(_) => panic!("expected a run-time error, got Ok: {}", src),
        Err(e) => assert!(
            e.rendered.contains(needle),
            "alternate-shape runtime error missing `{}`: {}\nsrc: {}",
            needle,
            e.rendered,
            src
        ),
    }
}

/// Target-face run: expect a runtime error containing `needle`.
fn target_run_err(src: &str, needle: &str) {
    match run_source(src, "maberr.ktf") {
        Ok(_) => panic!("expected a run-time error, got Ok: {}", src),
        Err(e) => assert!(
            e.rendered.contains(needle),
            "target runtime error missing `{}`: {}\nsrc: {}",
            needle,
            e.rendered,
            src
        ),
    }
}

/// Alternate program-shape static check that fails compilation: expect a
/// DriverError whose rendered output contains `needle` (E0022-family
/// hard errors on the Compile stage are Err, not collected diagnostics).
fn alt_check_err(src: &str, needle: &str) {
    match check_source_recover(src, "maberr.ktf") {
        Ok(_) => panic!("expected a check compile error, got Ok: {}", src),
        Err(e) => assert!(
            e.rendered.contains(needle),
            "alternate-shape check error missing `{}`: {}\nsrc: {}",
            needle,
            e.rendered,
            src
        ),
    }
}

/// Target-face static check that fails compilation: expect a DriverError
/// containing `needle`.
fn target_check_err(src: &str, needle: &str) {
    match check_source_recover(src, "maberr.ktf") {
        Ok(_) => panic!("expected a check compile error, got Ok: {}", src),
        Err(e) => assert!(
            e.rendered.contains(needle),
            "target check error missing `{}`: {}\nsrc: {}",
            needle,
            e.rendered,
            src
        ),
    }
}

// ---------------------------------------------------------------------------
// Bucket P: positive (8)
// ---------------------------------------------------------------------------

/// P01: the `'any` position accepts every concrete argument family with
/// zero diagnostics on both shapes (defect ① fix — the r140 fallback
/// false positive is gone; exact-count clean, not contains-any).
#[test]
fn p01_any_position_concrete_families_clean() {
    // int / string / bool / symbol first arguments (the define-value
    // alternate shape — the E6 conversion of the former seed legs)
    alt_clean("import kerf_list;\nlet x = member(2, list(1, 2, 3));\nx");
    alt_clean("import kerf_list;\nlet x = member(\"s\", list(1, 2, 3));\nx");
    alt_clean("import kerf_list;\nlet x = member(true, list(1, 2, 3));\nx");
    alt_clean("import kerf_list;\nlet x = member(quote(sym), list(1, 2, 3));\nx");
    alt_clean("import kerf_list;\nlet x = assoc(2, list(list(2, 9)));\nx");
    alt_clean("import kerf_list;\nlet x = assoc(\"k\", list(list(\"k\", 1)));\nx");
    target_clean("import kerf_list;\nfn f() -> bool { is_pair(member(2, list(1, 2, 3))) }");
    target_clean(
        "import kerf_list;\nfn f() -> bool { is_pair(assoc(\"k\", list(list(\"k\", 1)))) }",
    );
}

/// P02: the value-consumption tension flip anchor — `(head (member 2 lst))`
/// checks clean and runs to 2 on both shapes (defect ② fix — the spurious
/// E0005 is gone while the runtime yields the hit head).
#[test]
fn p02_value_consumption_tension_flip() {
    alt_clean(
        "import kerf_list;\nlet lst = list(1, 2, 3);\nlet first = head(member(2, lst));\nfirst",
    );
    alt_run(
        "import kerf_list;\nlet lst = list(1, 2, 3);\nlet first = head(member(2, lst));\nfirst",
        "2",
    );
    target_clean(
        "import kerf_list;\nfn f() -> i64 { let l = list(1, 2, 3); head(member(2, l)) }\nf()",
    );
    target_run(
        "import kerf_list;\nfn f() -> i64 { let l = list(1, 2, 3); head(member(2, l)) }\nf()",
        "2",
    );
}

/// P03: the canonical predicate form (is-pair wrap — strict bool-if
/// runtime discipline, design D4 layer 3): static clean + runtime 10 on
/// both shapes.
#[test]
fn p03_canonical_predicate_is_pair_wrap() {
    alt_clean(
        "import kerf_list;\nlet r = if (is_pair(member(2, list(1, 2, 3)))) { 10 } else { 20 };\nr",
    );
    alt_run(
        "import kerf_list;\nlet r = if (is_pair(member(2, list(1, 2, 3)))) { 10 } else { 20 };\nr",
        "10",
    );
    target_clean(
        "import kerf_list;\nfn f() -> i64 { if (is_pair(member(2, list(1, 2, 3)))) { 10 } else { 20 } }\nf()",
    );
    target_run(
        "import kerf_list;\nfn f() -> i64 { if (is_pair(member(2, list(1, 2, 3)))) { 10 } else { 20 } }\nf()",
        "10",
    );
}

/// P04: the tvar `'any` position stays unconstrained and unpolluted — a
/// parameter flowing into member pos-0 generalizes cleanly, and its
/// result flows into a value-consuming position without the pseudo
/// `tcon('any)` (defect ① tvar path + defect ② compound).
#[test]
fn p04_tvar_any_position_unpolluted() {
    alt_clean(
        "import kerf_list;\nfn f(x: T) -> T { let m = member(x, list(1, 2)); head(m) }\nf(2)",
    );
    alt_run(
        "import kerf_list;\nfn f(x: T) -> T { let m = member(x, list(1, 2)); head(m) }\nf(2)",
        "2",
    );
    target_clean("import kerf_list;\nfn f(x: T) -> T { head(member(x, list(1, 2))) }\nf(2)");
    target_run(
        "import kerf_list;\nfn f(x: T) -> T { head(member(x, list(1, 2))) }\nf(2)",
        "2",
    );
}

/// P05: the assoc value-consumption control row (existing unknown
/// modeling unchanged) — `(head (tail (assoc 1 al)))` yields the entry
/// value on both shapes.
#[test]
fn p05_assoc_value_consumption_control() {
    alt_clean("import kerf_list;\nlet a = assoc(1, list(list(1, \"x\")));\nhead(tail(a))");
    alt_run(
        "import kerf_list;\nlet a = assoc(1, list(list(1, \"x\")));\nhead(tail(a))",
        "x",
    );
    target_clean(
        "import kerf_list;\nfn f() -> str { let a = assoc(1, list(list(1, \"x\"))); head(tail(a)) }\nf()",
    );
    target_run(
        "import kerf_list;\nfn f() -> str { let a = assoc(1, list(list(1, \"x\"))); head(tail(a)) }\nf()",
        "x",
    );
}

/// P06: the member result is a generalized fresh consumed at multiple
/// positions from one binding (predicate via is-pair + value via head —
/// the r140 D3 fresh-generalization semantics).
#[test]
fn p06_fresh_generalization_multi_consumption() {
    alt_clean(
        "import kerf_list;\nlet m = member(2, list(1, 2, 3));\nlet a = if (is_pair(m)) { 10 } else { 20 };\nlet b = head(m);\na + b",
    );
    alt_run(
        "import kerf_list;\nlet m = member(2, list(1, 2, 3));\nlet a = if (is_pair(m)) { 10 } else { 20 };\nlet b = head(m);\na + b",
        "12",
    );
    target_clean(
        "import kerf_list;\nfn f() -> i64 { let m = member(2, list(1, 2, 3)); let a = if (is_pair(m)) { 10 } else { 20 }; let b = head(m); a + b }\nf()",
    );
}

/// P07: the miss-form runtime anchors — `(member 9 lst)` renders false
/// and a miss-fed if-condition (bool, legitimately) yields 2 (the
/// runtime value-domain split is the pre-existing Racket member
/// semantics; B2 purification stays out-of-domain).
#[test]
fn p07_miss_form_runtime_anchors() {
    alt_run(
        "import kerf_list;\nlet m = member(9, list(1, 2, 3));\nm",
        "false",
    );
    alt_run(
        "import kerf_list;\nlet r = if (member(9, list(1, 2, 3))) { 1 } else { 2 };\nr",
        "2",
    );
    target_run(
        "import kerf_list;\nfn f() -> bool { member(9, list(1, 2, 3)) }\nf()",
        "false",
    );
}

/// P08: cross-stage consumption integration — member/assoc through the
/// .ktf target chain end-to-end (Reader → Expander → Compiler → VM)
/// with value anchors (GATE 6 cross-stage consumption slot).
#[test]
fn p08_cross_stage_target_chain_e2e() {
    target_run(
        "import kerf_list;\nfn find() -> i64 { let l = list(1, 2, 3); head(member(2, l)) }\nfind()",
        "2",
    );
    target_run(
        "import kerf_list;\nfn entry() -> str { let al = list(list(1, \"x\"), list(2, \"y\")); head(tail(assoc(2, al))) }\nentry()",
        "y",
    );
    target_run(
        "import kerf_list;\nfn probe() -> i64 { if (is_pair(member(5, list(1, 5)))) { 7 } else { 8 } }\nprobe()",
        "7",
    );
}

// ---------------------------------------------------------------------------
// Bucket N: negative (24)
// ---------------------------------------------------------------------------

/// N01: member pos-1 non-list (str) — exact single diagnostic (the r140
/// contains-any masking gap closure: the pos-0 'any spurious diagnostic
/// is gone, only the true pos-1 detection remains).
#[test]
fn n01_member_pos1_str_exact_single() {
    alt_diag_exactly(
        "import kerf_list;\nlet x = member(2, \"ab\");\nx",
        "member requires list, got str",
        1,
    );
    alt_diag_exactly(
        "import kerf_list;\nfn f() -> bool { member(2, \"ab\") }\nf()",
        "member requires list, got str",
        1,
    );
}

/// N02: member pos-1 non-list (int) — exact single diagnostic.
#[test]
fn n02_member_pos1_int_exact_single() {
    alt_diag_exactly(
        "import kerf_list;\nlet x = member(2, 7);\nx",
        "member requires list, got int",
        1,
    );
    alt_diag_exactly(
        "import kerf_list;\nfn f() -> bool { member(2, 7) }\nf()",
        "member requires list, got int",
        1,
    );
}

/// N03: member pos-1 non-list (bool) — exact single diagnostic.
#[test]
fn n03_member_pos1_bool_exact_single() {
    alt_diag_exactly(
        "import kerf_list;\nlet x = member(2, true);\nx",
        "member requires list, got bool",
        1,
    );
    alt_diag_exactly(
        "import kerf_list;\nfn f() -> bool { member(2, true) }\nf()",
        "member requires list, got bool",
        1,
    );
}

/// N04: member pos-1 non-list (symbol) — exact single diagnostic
/// (alternate shape; the symbol literal is the quote form).
#[test]
fn n04_member_pos1_sym_exact_single() {
    alt_diag_exactly(
        "import kerf_list;\nlet x = member(2, quote(s));\nx",
        "member requires list, got symbol",
        1,
    );
}

/// N05: member arity — 1 argument.
#[test]
fn n05_member_arity_one() {
    alt_diag_exactly(
        "import kerf_list;\nlet x = member(2);\nx",
        "procedure argument count mismatch: expected 2, got 1",
        1,
    );
    target_diag_exactly(
        "import kerf_list;\nfn f() -> bool { member(2) }",
        "procedure argument count mismatch: expected 2, got 1",
        1,
    );
}

/// N06: member arity — 3 arguments.
#[test]
fn n06_member_arity_three() {
    alt_diag_exactly(
        "import kerf_list;\nlet x = member(2, list(1, 2), 9);\nx",
        "procedure argument count mismatch: expected 2, got 3",
        1,
    );
    target_diag_exactly(
        "import kerf_list;\nfn f() -> bool { member(2, list(1, 2), 9) }",
        "procedure argument count mismatch: expected 2, got 3",
        1,
    );
}

/// N07: assoc pos-1 non-list (str) — exact single diagnostic.
#[test]
fn n07_assoc_pos1_str_exact_single() {
    alt_diag_exactly(
        "import kerf_list;\nlet x = assoc(2, \"ab\");\nx",
        "assoc requires list, got str",
        1,
    );
    alt_diag_exactly(
        "import kerf_list;\nfn f() -> bool { is_pair(assoc(2, \"ab\")) }\nf()",
        "assoc requires list, got str",
        1,
    );
}

/// N08: assoc pos-1 non-list (int) — exact single diagnostic.
#[test]
fn n08_assoc_pos1_int_exact_single() {
    alt_diag_exactly(
        "import kerf_list;\nlet x = assoc(2, 7);\nx",
        "assoc requires list, got int",
        1,
    );
}

/// N09: assoc pos-1 non-list (bool) — exact single diagnostic.
#[test]
fn n09_assoc_pos1_bool_exact_single() {
    alt_diag_exactly(
        "import kerf_list;\nlet x = assoc(2, true);\nx",
        "assoc requires list, got bool",
        1,
    );
}

/// N10: assoc pos-1 non-list (symbol) — exact single diagnostic.
#[test]
fn n10_assoc_pos1_sym_exact_single() {
    alt_diag_exactly(
        "import kerf_list;\nlet x = assoc(2, quote(s));\nx",
        "assoc requires list, got symbol",
        1,
    );
}

/// N11: assoc arity — 1 argument.
#[test]
fn n11_assoc_arity_one() {
    alt_diag_exactly(
        "import kerf_list;\nlet x = assoc(2);\nx",
        "procedure argument count mismatch: expected 2, got 1",
        1,
    );
}

/// N12: assoc arity — 3 arguments.
#[test]
fn n12_assoc_arity_three() {
    alt_diag_exactly(
        "import kerf_list;\nlet x = assoc(2, list(1, 2), 9);\nx",
        "procedure argument count mismatch: expected 2, got 3",
        1,
    );
}

/// N13: 'sigf neighbor discipline — nth pos-1 non-int (str) stays
/// detected (design D5: the neighbor rows are untouched).
#[test]
fn n13_nth_pos1_str_neighbor() {
    // r164/235-c: the self-built generic face's honest static behavior — the
    // HM unification of (T, T) reports the num/str conflict (fail-closed
    // maintained, message generalized); the runtime face carries the exact
    // retired-Rust message.
    alt_diag_exactly(
        "import kerf_list;\nlet x = nth(list(1, 2), \"i\");\nx",
        "type mismatch",
        1,
    );
    let err13 = run_source(
        "import kerf_list;\nlet x = nth(list(1, 2), \"i\");\nx",
        "n13rt.ktf",
    )
    .expect_err("run must fail at runtime");
    assert!(
        err13.rendered.contains("nth index requires int, got str"),
        "n13 runtime face: {}",
        err13.rendered
    );
}

/// N14: 'sigf neighbor discipline — drop pos-1 non-int (str) stays
/// detected.
#[test]
fn n14_drop_pos1_str_neighbor() {
    alt_diag_exactly(
        "import kerf_list;\nlet x = drop(list(1, 2), \"i\");\nx",
        "type mismatch",
        1,
    );
    let err14 = run_source(
        "import kerf_list;\nlet x = drop(list(1, 2), \"i\");\nx",
        "n14rt.ktf",
    )
    .expect_err("run must fail at runtime");
    assert!(
        err14.rendered.contains("drop index requires int, got str"),
        "n14 runtime face: {}",
        err14.rendered
    );
}

/// N15: 'sigf neighbor discipline — nth pos-0 non-list (int) stays
/// detected.
#[test]
fn n15_nth_pos0_int_neighbor() {
    alt_runtime_err(
        "import kerf_list;\nlet x = nth(5, 0);\nx",
        "nth index 0 out of list range",
    );
}

/// N16: 'sigf neighbor discipline — string-substring pos-2 non-int (str)
/// stays detected.
#[test]
fn n16_substring_pos2_str_neighbor() {
    alt_diag_exactly(
        "import kerf_string;\nlet x = string_substring(\"abc\", \"x\", 2);\nx",
        "string-substring requires int, got str",
        1,
    );
}

/// N17: head non-pair true detection stays (the head family enforcement
/// is not weakened by the result widening).
#[test]
fn n17_head_non_pair_maintained() {
    alt_diag_exactly(
        "import kerf_list;\nlet x = head(1);\nx",
        "head requires pair, got int",
        1,
    );
}

/// N18: tail non-pair true detection stays.
#[test]
fn n18_tail_non_pair_maintained() {
    alt_diag_exactly(
        "import kerf_list;\nlet x = tail(\"s\");\nx",
        "tail requires pair, got str",
        1,
    );
}

/// N19: if-condition concrete non-bool (int) true detection stays (the
/// if-condition enforcement is not polluted by the widening — D4 layer
/// 2's static counterpart).
#[test]
fn n19_if_cond_int_maintained() {
    alt_diag_exactly(
        "let r = if (1) { 10 } else { 20 };\nr",
        "if condition requires bool, got int",
        1,
    );
}

/// N20: if-condition concrete non-bool (str) true detection stays.
#[test]
fn n20_if_cond_str_maintained() {
    alt_diag_exactly(
        "let r = if (\"s\") { 10 } else { 20 };\nr",
        "if condition requires bool, got str",
        1,
    );
}

/// N21: unimported member — E0022 unbound stays (both shapes; the E0022
/// family surfaces as a Compile-stage hard error on the check channel).
#[test]
fn n21_unimported_member_e0022() {
    alt_check_err("let x = member(2, list(1, 2));\nx", "unbound reference");
    target_check_err(
        "fn f() -> bool { member(2, list(1, 2)) }",
        "unbound reference",
    );
}

/// N22: unimported assoc — E0022 unbound stays.
#[test]
fn n22_unimported_assoc_e0022() {
    alt_check_err("let x = assoc(2, list(1, 2));\nx", "unbound reference");
}

/// N23: the miss-fed value consumption stays a true runtime violation —
/// `(head (member 9 lst))` checks clean statically (fresh result) but
/// the runtime honestly rejects the bool head (fail-closed face
/// untouched by the static widening).
#[test]
fn n23_miss_value_consumption_runtime_violation() {
    alt_clean("import kerf_list;\nlet x = head(member(9, list(1, 2, 3)));\nx");
    alt_run_err(
        "import kerf_list;\nlet x = head(member(9, list(1, 2, 3)));\nx",
        "head requires pair, got bool",
    );
    target_run_err(
        "import kerf_list;\nfn f() -> i64 { head(member(9, list(1, 2, 3))) }\nf()",
        "head requires pair, got bool",
    );
}

/// N24: the bare predicate form is a runtime E0004 honest violation —
/// static clean (fresh unifies bool) + runtime strict bool-if discipline
/// rejects the Pair hit (truthy semantics explicitly defined) — plus
/// the cross-shape diagnostic-count parity assertion on a member 'any
/// probe (GATE 6 parity slot; E6 close-out rework: the S-expr face
/// retired — the parity is carried by the two target program shapes).
#[test]
fn n24_bare_predicate_runtime_e0004_and_parity() {
    alt_clean("import kerf_list;\nlet r = if (member(2, list(1, 2, 3))) { 10 } else { 20 };\nr");
    alt_run_err(
        "import kerf_list;\nlet r = if (member(2, list(1, 2, 3))) { 10 } else { 20 };\nr",
        "if condition requires bool, got pair",
    );
    target_run_err(
        "import kerf_list;\nfn f() -> i64 { if (member(2, list(1, 2, 3))) { 10 } else { 20 } }\nf()",
        "if condition requires bool, got pair",
    );
    // Cross-shape diagnostic-count parity on the 'any probe (E6 close-out
    // rework r154 / 224-c3: the S-expr face retired — the parity slot is
    // carried by the two target program shapes): the define-value form
    // and the fn form report the same single true detection (pos-1),
    // zero spurious.
    let define_shape = "import kerf_list;\nlet x = member(2, \"ab\");\nx";
    let fn_shape = "import kerf_list;\nfn f() -> bool { member(2, \"ab\") }";
    let r1 = check_source_recover(define_shape, "par_a.ktf").expect("check must pass compile");
    let r2 = check_source_recover(fn_shape, "par_b.ktf").expect("check must pass compile");
    assert_eq!(
        r1.diagnostics.len(),
        r2.diagnostics.len(),
        "cross-shape count parity: define-value {:?} vs fn {:?}",
        r1.diagnostics
            .iter()
            .map(|d| d.message.as_str())
            .collect::<Vec<_>>(),
        r2.diagnostics
            .iter()
            .map(|d| d.message.as_str())
            .collect::<Vec<_>>()
    );
}

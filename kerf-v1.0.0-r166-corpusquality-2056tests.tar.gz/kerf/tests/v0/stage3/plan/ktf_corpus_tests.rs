//! .ktf usage-corpus family tests — r127 / 197-b (M2 consumption form).
//!
//! **Verification surfaces** (the user-facing .ktf corpus family placed at
//! `examples/usage/*.ktf` — six files consuming the full implemented
//! target-surface subset through the production dual-entry chain):
//! (1) **run-face E2E** — each corpus file through `run_source`
//! (reader bridge → bootstrap Expander → bootstrap Compiler → VM)
//! yields the same program value as its S-expr face counterpart (principle
//! 31 skin/skeleton isomorphism — the corpus is the artifact under test,
//! consumed via `include_str!` so any corpus edit that breaks the chain
//! fails here: the corpus-integrity gate); (2) **cross-stage consumption**
//! — the same corpus family through `check_source_recover` (the HM
//! type face) stays diagnostic-clean with real instruction artifacts, and
//! through `test_runner::run_test_case` (the test entry) passes all cases —
//! three production entries consuming one corpus; (3) **fail-closed
//! negatives** — corpus-shaped rejections across the error classes
//! (lexical / grammar / position / domain-out / capability / unbound /
//! E0025 exhaustiveness / HM / runtime / recovery), including the r126
//! failed-define ∀α absorption consumed on the target face.
//!
//! Skin-dictionary basis: 20 §14 v1.19 (the eight mappings — naming
//! `-`↔`_`, module production face, multi-binding let, quote/define call
//! forms, match seventh, require eighth, `||` closure, `x = e;` assign);
//! 02 §8.13.1a (Level 0 implemented productions). Corpus placement basis:
//! switch-window-plan v1.10 next-batch recommendation + t3plus-trigger-audit
//! v1.46 r126 note (the M2 corpus-consumption form candidate — trigger
//! table #5 family neighborhood). Ratio: 8 positive : 24 negative = 1:3
//! (§9.4.3).

use kerf_driver::bootstrap::test_runner;
use kerf_driver::{check_source_recover, dump_stx, run_source};

// ---------------------------------------------------------------------------
// Corpus family (the artifacts under test — include_str! makes every file
// a tested artifact: the corpus-integrity gate)
// ---------------------------------------------------------------------------

const CORPUS_FIB: &str = include_str!("../../../../examples/usage/fib.ktf");
const CORPUS_CLOSURES: &str = include_str!("../../../../examples/usage/closures.ktf");
const CORPUS_HIGHER_ORDER: &str = include_str!("../../../../examples/usage/higher_order.ktf");
const CORPUS_MATCH: &str = include_str!("../../../../examples/usage/match.ktf");
const CORPUS_IO: &str = include_str!("../../../../examples/usage/io.ktf");
const CORPUS_EFFECT: &str = include_str!("../../../../examples/usage/effect.ktf");

/// Run a corpus file through the target-syntax entry and render the
/// program value (the shared positive helper).
fn corpus_value(src: &str, filename: &str) -> String {
    let outcome = run_source(src, filename)
        .unwrap_or_else(|e| panic!("corpus {} execution failed:{}", filename, e));
    kerf_vm::render_value(&outcome.value, &outcome.heap)
}

// ---------------------------------------------------------------------------
// Positives — run-face E2E (one per corpus file) + cross-stage consumption
// ---------------------------------------------------------------------------

/// Positive 1 / integration: fib.ktf (fn declaration + recursion + infix
/// operators + require/print) through the production run chain — the
/// program value matches the S-expr face counterpart (fib.krf ⇒ 144).
#[test]
fn corpus_fib_run_e2e() {
    assert_eq!(
        corpus_value(CORPUS_FIB, "fib.ktf"),
        "144",
        "fib(12) program value"
    );
}

/// Positive 2 / integration: closures.ktf (`||` closure expression, `let`
/// binding, `n = n + 1;` assign capture, `define(NAME, e);` call form)
/// through the production run chain — the program value matches the
/// S-expr face counterpart (closures.krf ⇒ 42).
#[test]
fn corpus_closures_run_e2e() {
    assert_eq!(
        corpus_value(CORPUS_CLOSURES, "closures.ktf"),
        "42",
        "add5(37) program value(closure + mutable capture chain)"
    );
}

/// Positive 3 / integration: higher_order.ktf (higher-order fn parameters,
/// `||` closure argument, the `list` builtin call face) through the
/// production run chain — the program value matches the S-expr face
/// counterpart (higher_order.krf ⇒ (1 4 9 16 25)).
#[test]
fn corpus_higher_order_run_e2e() {
    assert_eq!(
        corpus_value(CORPUS_HIGHER_ORDER, "higher_order.ktf"),
        "(1 4 9 16 25)",
        "map square program value(higher-order function + closure argument)"
    );
}

/// Positive 4 / integration: match.ktf (the seventh skin-dictionary
/// mapping — literal arms, guard arms, pair destructuring with nested
/// or-in-pair-left, arm-level or markers, single-evaluation scrutinee)
/// through the production run chain — the program value matches the
/// S-expr face counterpart (match.krf ⇒ fib-13).
#[test]
fn corpus_match_run_e2e() {
    assert_eq!(
        corpus_value(CORPUS_MATCH, "match.ktf"),
        "fib-13",
        "match single times evaluate scrutinee program value"
    );
}

/// Positive 5 / integration: io.ktf (`import kerf_string;` + `require io,
/// write;` + print + string_append through the word-separation mapping)
/// through the production run chain — the program value matches the
/// S-expr face counterpart (io.krf ⇒ 42).
#[test]
fn corpus_io_run_e2e() {
    assert_eq!(
        corpus_value(CORPUS_IO, "io.ktf"),
        "42",
        "io corpus program value"
    );
}

/// Positive 6 / integration: effect.ktf (`perform gift(0, 20);` + `handle
/// e { Name(p, k) => resume(v) }` — the effect round-trip) through the
/// production run chain — the program value matches the S-expr face
/// counterpart shape (effect_stress.krf ⇒ 120).
#[test]
fn corpus_effect_run_e2e() {
    assert_eq!(
        corpus_value(CORPUS_EFFECT, "effect.ktf"),
        "120",
        "effect loop program value(perform/handle/resume)"
    );
}

/// Positive 7 / integration / cross-stage consumption: the whole corpus
/// family through the check face (`check_source_recover`) —
/// diagnostic-clean with real instruction artifacts. The run face and the
/// check face consume the same corpus: one corpus, two pipeline stages
/// (cross-stage consumption — the M2 form's consumption surface).
#[test]
fn corpus_family_check_clean_cross_stage() {
    let family = [
        ("fib.ktf", CORPUS_FIB),
        ("closures.ktf", CORPUS_CLOSURES),
        ("higher_order.ktf", CORPUS_HIGHER_ORDER),
        ("match.ktf", CORPUS_MATCH),
        ("io.ktf", CORPUS_IO),
        ("effect.ktf", CORPUS_EFFECT),
    ];
    for (name, src) in family {
        let report = check_source_recover(src, name)
            .unwrap_or_else(|e| panic!("corpus {} check failed:{}", name, e));
        assert!(
            report.diagnostics.is_empty(),
            "corpus {} must have zero diagnostics (actual: {:?})",
            name,
            report.rendered
        );
        assert!(
            report.instruction_count > 0,
            "corpus {} check artifact instruction count > 0(actual {})",
            name,
            report.instruction_count
        );
    }
}

/// Positive 8 / integration / third-entry consumption: match.ktf through
/// the test face (`test_runner::run_test_case`) — the fn declarations land in
/// the prelude bucket, each top-level expression becomes a case, and all
/// cases pass (truthy values). The run/check/test trio of production
/// entries consumes one corpus family.
#[test]
fn corpus_match_test_runner_entry() {
    let report = test_runner::run_test_case(CORPUS_MATCH, "match.ktf")
        .unwrap_or_else(|e| panic!("corpus match.ktf test execution failed:{}", e));
    assert_eq!(
        report.cases.len(),
        5,
        "match.ktf top level expression = 5 case(classify/sign/describe/small/match tail)"
    );
    assert!(
        report.all_passed(),
        "all cases pass(detail: {:?})",
        report
            .cases
            .iter()
            .map(|c| c.detail.clone())
            .collect::<Vec<_>>()
    );
}

// ---------------------------------------------------------------------------
// Negatives — corpus-shaped fail-closed rejections (§9.4.3 ratio 1:3
// carrier: 24 negatives across the error classes)
// ---------------------------------------------------------------------------

/// Negative 1 (lexical): unclosed string literal in a corpus-shaped source.
#[test]
fn neg_unclosed_string_lexical_fail() {
    assert!(
        run_source("print(\"abc", "bad.ktf").is_err(),
        "unclosed string must be a lexical error"
    );
}

/// Negative 2 (grammar): unclosed brace in a corpus-shaped fn body.
#[test]
fn neg_unclosed_brace_grammar_fail() {
    assert!(
        run_source("fn f() { 1", "bad.ktf").is_err(),
        "unclosed brace must be a grammar error"
    );
}

/// Negative 3 (read — target-face type discipline): a fn parameter without
/// the mandatory `: type` annotation (the stripped-after-parse skin
/// signature is still grammatically mandatory on the target face).
#[test]
fn neg_fn_param_missing_type_read_fail() {
    let err = run_source("fn f(n) { n }", "bad.ktf")
        .expect_err("target face parameter type annotations grammatically required(post-strip parsing face discipline)");
    assert!(
        err.to_string().contains("expected :"),
        "diagnostic must name the missing `:`(actual: {})",
        err
    );
}

/// Negative 4 (read — eighth-mapping form discipline): `require` without
/// the mandatory trailing semicolon.
#[test]
fn neg_require_missing_semicolon_read_fail() {
    let err = run_source("require io, write\nprint(1);", "bad.ktf")
        .expect_err("require declaration forced semicolon(#eight map form discipline)");
    assert!(
        err.to_string().contains(';'),
        "diagnostic must name the missing semicolon(actual: {})",
        err
    );
}

/// Negative 5 (read — seventh-mapping form discipline): match arms without
/// the mandatory comma separator.
#[test]
fn neg_match_arm_missing_comma_read_fail() {
    let err = run_source(
        "fn f(x: i64) { match x { 0 => \"a\" 1 => \"b\", _ => \"c\" } }",
        "bad.ktf",
    )
    .expect_err("match arms must be separated by , (seventh mapping form discipline)");
    assert!(
        err.to_string()
            .contains("match arms must be separated by ,"),
        "diagnostic must name arm separator discipline(actual: {})",
        err
    );
}

/// Negative 6 (read — pattern grammar): an unparenthesized or-pattern
/// mixed into a pair-destructuring slot (the disambiguation ruling: wrap
/// it — `((p | q), r)`).
#[test]
fn neg_or_pattern_mixed_with_pair_read_fail() {
    let err = run_source(
        "fn f(p: T) { match p { (0 | 1, c) => 1, _ => 2 } }",
        "bad.ktf",
    )
    .expect_err("or pattern and pair destructuring cannot mixing(disambiguation ruling)");
    assert!(
        err.to_string().contains("parenthesize"),
        "diagnostic must given parenthesization guidance(actual: {})",
        err
    );
}

/// Negative 7 (read — position discipline): `require` inside a block (the
/// E0018 position discipline is shared at the Stx layer across both skins
/// — top-level declaration family only).
#[test]
fn neg_require_in_block_position_read_fail() {
    let err = run_source("fn f() { require io, write; 1 }", "bad.ktf").expect_err(
        "require top-level declaration position only(E0018 position discipline dual skin shared)",
    );
    assert!(
        err.to_string().contains("KwRequire"),
        "diagnostic must name require keyword position(actual: {})",
        err
    );
}

/// Negative 8 (entry skin integrity): S-expression source under the
/// target-syntax entry is rejected (the entry dispatch is skin-authoritative).
#[test]
fn neg_sexp_source_under_target_entry_rejected() {
    assert!(
        run_source("(+ 1 2)", "bad.ktf").is_err(),
        "S expression source in goal entry must rejected"
    );
}

/// Negative 9 (dump face): dump_stx errors on a bad corpus source.
#[test]
fn neg_dump_stx_error_on_bad_corpus_source() {
    assert!(
        dump_stx("fn f() { 1", "bad.ktf").is_err(),
        "bad source stx dump must report an error"
    );
}

/// Negative 10 (single-layer ruling): multi-segment `use` path — the
/// r131 legalization anchor flip (the pre-window domain-out row retired
/// with the diagnostic — `use kerf::foo;` now parses and the D1 ruling
/// rejects the merged Path token at compile time via E0019, identical
/// face to import; the grammar-level domain-out battery moved to
/// ktf_use_decl_tests.rs's dedicated negatives).
#[test]
fn neg_use_decl_multisegment_path_e0019_fail_closed() {
    let err = run_source("use kerf::foo;", "bad.ktf")
        .expect_err("multi-segment path use must E0019(single-layer ruling enforcement face)");
    assert!(
        err.to_string().contains("E0019") && err.to_string().contains("kerf/foo"),
        "diagnostic must is E0019 unknown module with path name(actual: {})",
        err
    );
}

/// Negative 11 (fail-closed domain migration — r163 / 234-c): the postfix
/// index face opened (the seventeenth skin mapping — `coll[idx]` →
/// as-if-written `(vector-ref coll idx)`); a pair-list index now fails at
/// the VM domain check (E0004 vector-ref requires vector) instead of the
/// Reader domain-out — D6 honest boundary: pair-list indexing stays on
/// the `nth` call form (import kerf_list).
#[test]
fn neg_index_domain_out_fail_closed() {
    let err = run_source("let lst = list(1, 2);\nlst[0];", "bad.ktf")
        .expect_err("pair-list index = the VM vector-ref domain check fail-closed");
    assert!(
        err.to_string().contains("E0004") && err.to_string().contains("vector"),
        "diagnostic must name the vector-ref domain check(actual: {})",
        err
    );
}

/// Negative 12 (capability — E0006): `print` without the `require io,
/// write;` declaration — the capability gate is compile-time fail-closed
/// (the eighth mapping's consumption face).
#[test]
fn neg_print_without_require_capability_fail() {
    let err = run_source("print(\"hi\");", "bad.ktf")
        .expect_err("no require declared I/O call = compile-time E0006 capability gating");
    assert!(
        err.to_string().contains("E0006"),
        "diagnostic must be E0006 capability permission (actual: {})",
        err
    );
}

/// Negative 13 (expand/compile — E0022 short-circuit): an unbound
/// reference resolves and short-circuits at the compile stage (the
/// whole-program resolution is not a recovery-collection face).
#[test]
fn neg_unbound_reference_compile_shortcircuit() {
    let err = check_source_recover("undefined_a(1)", "bad.ktf").expect_err(
        "unbound reference = compile-time E0022 resolution whole-program short-circuit",
    );
    assert!(
        err.to_string().contains("undefined_a") || err.to_string().contains("unbound reference"),
        "diagnostic must name symbol/unbound family (actual: {})",
        err
    );
}

/// Negative 14 (expand/compile — N2 import face): `string_append` without
/// `import kerf_string;` — the import-injection face hint rides the E0022
/// diagnostic (the word-separation mapping resolves to the S-expr face
/// name `string-append`, which lives behind the module import).
#[test]
fn neg_import_face_unbound_without_import() {
    let err = check_source_recover("string_append(\"a\", \"b\")", "bad.ktf")
        .expect_err("not imported kerf-string string_append = E0022(N2 injection face)");
    assert!(
        err.to_string().contains("string-append"),
        "diagnostic must name mapped symbol string-append(actual: {})",
        err
    );
}

/// Negative 15 (expand — E0025 collected): a non-exhaustive match (no
/// wildcard arm) is collected in recovery mode (the expand-stage
/// diagnostic rides the E0002 channel; the conservative rule —
/// match-design §4).
#[test]
fn neg_match_nonexhaustive_e0025_collected() {
    let report = check_source_recover("fn f(x: i64) { match x { 0 => 1 } }", "bad.ktf")
        .expect("in recovery mode E0025 collection does not short-circuit (diagnostics reachable)");
    assert_eq!(
        report.diagnostics.len(),
        1,
        "non-exhaustive match = exactly one diagnostic (actual {}: {:?})",
        report.diagnostics.len(),
        report.rendered
    );
    assert!(
        report.rendered[0].contains("E0025"),
        "diagnostic must carry E0025 exhaustiveness basis(actual: {})",
        report.rendered[0]
    );
}

/// Negative 16 (HM — E0005): `1 + "a"` through the check face — the
/// stripped type skin leaves the core to HM, which rejects the
/// numeric-operator application on a string operand.
#[test]
fn neg_hm_type_error_corpus_shaped() {
    let report = check_source_recover("1 + \"a\"", "bad.ktf")
        .expect("recovery mode: type errors do not short-circuit (diagnostics reachable)");
    assert!(
        !report.diagnostics.is_empty(),
        "HM type errors must produce diagnostics(E0005 family -- actual rendered: {:?})",
        report.rendered
    );
}

/// Negative 17 (HM — E0005 argument mismatch): calling the corpus fib with
/// a string argument fails the HM unification at the check face (the same
/// program runs into the VM `+` guard instead — compile-time types do not
/// guard the run path, which negative 21 covers).
#[test]
fn neg_hm_arg_mismatch_fib_string() {
    let src =
        "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(\"x\")";
    let report = check_source_recover(src, "bad.ktf").expect(
        "in recovery mode parameter type errors do not short-circuit(diagnostic reachable)",
    );
    assert!(
        report.rendered.iter().any(|r| r.contains("E0005")),
        "fib(\"x\") must E0005 type mismatch(actual: {:?})",
        report.rendered
    );
}

/// Negative 18 (HM — E0005 through a defined global): `define(x, "a");`
/// binds a string global (the fifth skin-dictionary call form), and the
/// `x + 1` operand unification fails — a corpus-shaped type error through
/// the define-value global chain. (The pair-operand form `list(1, 2) + 1`
/// is HM-lenient and fails at the VM guard instead — negative 22's class;
/// the honest boundary: HM rejects the string/number mismatch, not the
/// pair operand.)
#[test]
fn neg_hm_pair_operand_type_error() {
    let report = check_source_recover("let x = \"a\";\nx + 1", "bad.ktf")
        .expect("recovery mode: type errors do not short-circuit (diagnostics reachable)");
    assert!(
        report.rendered.iter().any(|r| r.contains("E0005")),
        "let x = \"a\" + x + 1 must E0005(actual: {:?});",
        report.rendered
    );
}

/// Negative 19 (runtime — E0004): calling a non-function value (an int)
/// through the target entry.
#[test]
fn neg_runtime_call_non_function_fail() {
    let err = run_source("let x = 5;\nx(1)", "bad.ktf")
        .expect_err("uncallable values must be run-time errors(E0004)");
    assert!(
        err.to_string().contains("uncallable"),
        "diagnostic must name uncallable(actual: {})",
        err
    );
}

/// Negative 20 (runtime — E0004): `head` of a non-pair value.
#[test]
fn neg_runtime_head_of_non_pair_fail() {
    let err = run_source("head(5)", "bad.ktf")
        .expect_err("head non-pairs must be run-time errors(E0004)");
    assert!(
        err.to_string().contains("head"),
        "diagnostic must name head predicate family(actual: {})",
        err
    );
}

/// Negative 21 (runtime — E0004 run face): the corpus fib called with a
/// string argument — the run face does not guard types (the stripped type
/// skin is not a run-path contract); the VM `+` needs-number check fires.
#[test]
fn neg_runtime_plus_needs_int_run_face() {
    let src = "fn f(n: i64) -> i64 { n + n }\nf(\"a\")";
    assert!(
        run_source(src, "bad.ktf").is_err(),
        "run-time type errors must surface via the target entry(+ requires a number -- and S S-expr face same basis)"
    );
}

/// Negative 22 (runtime — E0004 string operand): a string operand under
/// the numeric `+` operator on the run face.
#[test]
fn neg_runtime_string_operand_run_face() {
    assert!(
        run_source("\"a\" + \"b\"", "bad.ktf").is_err(),
        "string as + operands must be run-time errors(+ requires int)"
    );
}

/// Negative 23 (recovery — position-ordered collection): an expand-stage
/// error (E0002 `quote()` with no datum) plus an HM type error (E0005)
/// collected together in source position order — the item-level recovery
/// semantics shared verbatim by the shared tail.
#[test]
fn neg_recovery_multi_error_position_order() {
    let src = "quote()\n1 + \"a\"";
    let report = check_source_recover(src, "bad.ktf")
        .expect("recovery mode: per-form collection without short-circuit");
    assert_eq!(
        report.diagnostics.len(),
        2,
        "E0002 + E0005 each one(actual {}: {:?})",
        report.diagnostics.len(),
        report.rendered
    );
    assert!(
        report.rendered[0].contains("E0002"),
        "first diagnostic = E0002 quote malformed (position order)"
    );
    assert!(
        report.rendered[1].contains("E0005"),
        "second diagnostic = E0005 type error(position order)"
    );
}

/// Negative 24 (recovery — r126 failed-define ∀α absorption on the target
/// face): a define whose body carries an E0005 still binds (the r126
/// tc-check-define unify-failure ∀α generalization), so the subsequent
/// call checks clean — exactly one diagnostic, zero pollution of the
/// following items (the corpus-shaped consumption of the HM-deepening
/// window's absorption boundary).
#[test]
fn neg_recovery_failed_define_absorption_zero_pollution() {
    let src = "fn f(n: T) { 1 + \"a\" }\nf(1)";
    let report = check_source_recover(src, "bad.ktf")
        .expect("recovery mode: failure define absorbs subsequent items with zero pollution(r126 ∀α binding)");
    assert_eq!(
        report.diagnostics.len(),
        1,
        "exactly one diagnostic (in body E0005; subsequent f(1) call zero-pollution -- actual {}: {:?})",
        report.diagnostics.len(),
        report.rendered
    );
    assert!(
        report.rendered[0].contains("E0005"),
        "unique diagnostic = in body E0005(actual: {})",
        report.rendered[0]
    );
}

//! .ktf import-alias family tests — r130 / 200-b (the import-alias window:
//! the tenth skin-dictionary mapping).
//!
//! **Verification surfaces** (the target-face alias pair
//! `import mod as alias;` — symbol-for-symbol isomorphic to the S-expr
//! three-shape import form `(import mod as alias)` [r40 M2 / 22 §8 R-N5];
//! the driver's collect_import_items / rewrite_alias_refs consume it
//! unchanged — zero desugar, zero new primitives, principle 31):
//! (1) **run-face E2E** — the alias pair + `alias::member` qualified
//! references through `run_source` yield the same values as the
//! S-expr face counterparts (skin/skeleton isomorphism — the CLI
//! dual-entry architecture's expressive-parity gap closed);
//! (2) **the r130 grammar settlement** — the alias arm is verified
//! dual-Reader: seed vs mirror canonical Stx rendering byte-identical
//! (including the `as` marker symbol and its Span), error faces message +
//! Span byte-identical — the name-position diagnostic also repairs the
//! latent seed/mirror Span divergence of the pre-window fail-closed arm
//! (seed reported the post-bump token, mirror the `as` token);
//! (3) **cross-stage consumption** — the alias program through
//! `check_source_recover` stays diagnostic-clean with real
//! instruction artifacts;
//! (4) **fail-closed negatives** — reader-level position/structure
//! discipline (name-position `as` / missing operand / double alias /
//! missing comma / unclosed / block & expression positions / export &
//! require have no alias form) + driver-level semantic discipline
//! (E0019 unknown module / E0017 duplicate alias / E0014 unknown member
//! / E0022 bare-alias unbound / E0004 runtime type — the established
//! families, mirrored from the S-expr face's namespace_tests anchors).
//!
//! Skin-dictionary basis: 20 §14 v1.22 (the tenth mapping — the import
//! alias pair); 02 §8.13.1a v7.15 (the Level 0 production update).
//! Window basis: switch-window-plan v1.10 §4 out-of-domain registration row (the import-alias
//! follow-up row) + 22 §8 R-N5 (the S-expr three-shape import since
//! r40 M2) + t3plus-trigger-audit v1.49 (zero-signal maintenance —
//! user-instruction order, M1 form).
//! Ratio: 8 positive : 24 negative = 1:3 (§9.4.3).

use kerf_driver::bootstrap::reader::read_source_for_bootstrap;
use kerf_driver::{check_source_recover, run_source};
use kerf_reader::reader::read_source;
use kerf_syntax::{Stx, StxDatum, StxLiteral, SymbolTable};

// ---------------------------------------------------------------------------
// Value helpers
// ---------------------------------------------------------------------------

fn run_value(src: &str, filename: &str) -> String {
    let outcome = run_source(src, filename)
        .unwrap_or_else(|e| panic!("target face program {} execution failed:{}", filename, e));
    kerf_vm::render_value(&outcome.value, &outcome.heap)
}

// ---------------------------------------------------------------------------
// Dual-Reader parity helpers (the ktf_macros_corpus_tests.rs caliber —
// canonical rendering with Span bytes; error parity with message + Span
// byte equality)
// ---------------------------------------------------------------------------

fn render_stx(s: &Stx, t: &SymbolTable) -> String {
    let mut out = String::new();
    render_stx_into(s, t, &mut out);
    out
}

fn render_stx_into(s: &Stx, t: &SymbolTable, out: &mut String) {
    match &s.datum {
        StxDatum::Symbol(sym) => {
            out.push_str(&format!(
                "(sym {} {}..{})",
                t.name(*sym),
                s.span.start,
                s.span.end
            ));
        }
        StxDatum::Literal(l) => match l {
            StxLiteral::Int(v) => {
                out.push_str(&format!("(int {} {}..{})", v, s.span.start, s.span.end));
            }
            StxLiteral::Float(f) => {
                out.push_str(&format!("(float {:?} {}..{})", f, s.span.start, s.span.end));
            }
            StxLiteral::Str(r) => {
                out.push_str(&format!("(str {:?} {}..{})", r, s.span.start, s.span.end));
            }
            StxLiteral::Bool(b) => {
                out.push_str(&format!("(bool {} {}..{})", b, s.span.start, s.span.end));
            }
            StxLiteral::Nil => {
                out.push_str(&format!("(unit {}..{})", s.span.start, s.span.end));
            }
        },
        StxDatum::List(items) => {
            out.push_str(&format!("(lst {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
        // r138 / 208-c — TD-002: vectors now reach both Readers (the
        // fourteenth skin mapping) — full canonical rendering
        StxDatum::Vector(items) => {
            out.push_str(&format!("(vec {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
    }
}

/// Grammar parity assertion: both Readers' canonical renderings are
/// byte-identical (the r130 grammar settlement's core gate — the alias
/// pair form is seed/mirror isomorphic by construction, including the
/// `as` marker symbol and its Span bytes).
fn assert_grammar_parity(src: &str, what: &str) {
    let mut t1 = SymbolTable::new();
    let seed = read_source(src, 0, &mut t1)
        .unwrap_or_else(|e| panic!("[{}] seed syntax failed: {}", what, e.message));
    let mut t2 = SymbolTable::new();
    let mirror = read_source_for_bootstrap(src, 0, &mut t2)
        .unwrap_or_else(|e| panic!("[{}] mirror syntax failed:{}", what, e.message));
    assert_eq!(
        seed.len(),
        mirror.len(),
        "[{}] top-level item count mismatch (seed {} vs mirror {})",
        what,
        seed.len(),
        mirror.len()
    );
    for (i, (a, b)) in seed.iter().zip(mirror.iter()).enumerate() {
        assert_eq!(
            render_stx(a, &t1),
            render_stx(b, &t2),
            "[{}] top-level item #{} syntax tree mismatch (seed vs mirror canonical render)",
            what,
            i
        );
    }
}

/// Grammar-error parity assertion: message + Span byte-level equality
/// (the mirror's diagnostic face is the seed's, by construction — the
/// name-position `as` case additionally anchors the r130 latent-divergence
/// repair: both sides now report the `as` Token's own Span).
fn assert_grammar_err_parity(src: &str, what: &str) -> String {
    let mut t1 = SymbolTable::new();
    let seed_err = match read_source(src, 0, &mut t1) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] seed should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    let mut t2 = SymbolTable::new();
    let mirror_err = match read_source_for_bootstrap(src, 0, &mut t2) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] mirror should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    assert_eq!(
        seed_err.message, mirror_err.message,
        "[{}] syntax error message mismatch (seed {:?} vs mirror {:?})",
        what, seed_err.message, mirror_err.message
    );
    assert_eq!(
        seed_err.span.start, mirror_err.span.start,
        "[{}] syntax error Span start mismatch (seed {} vs mirror {})",
        what, seed_err.span.start, mirror_err.span.start
    );
    assert_eq!(
        seed_err.span.end, mirror_err.span.end,
        "[{}] syntax error Span end mismatch (seed {} vs mirror {})",
        what, seed_err.span.end, mirror_err.span.end
    );
    seed_err.message.clone()
}

// ---------------------------------------------------------------------------
// Positives — run-face E2E + grammar settlement + cross-stage consumption
// ---------------------------------------------------------------------------

/// Positive 1 / integration: the core E2E — `import kerf_string as str;` +
/// the `str::append` qualified reference through the production run chain
/// (Reader → Stx `(import kerf-string as str)` → collect_import_items
/// alias registration → rewrite_alias_refs → qualified resolution).
#[test]
fn alias_qualified_ref_e2e() {
    let v = run_value(
        "import kerf_string as str;\nstr::append(\"a\", \"b\")",
        "alias.ktf",
    );
    assert_eq!(
        v, "ab",
        "alias qualified reference must produce ab(actual: {})",
        v
    );
}

/// Positive 2 / integration: cross-grammar value parity — the same alias
/// program in both faces yields the same value (principle 31: the Stx is
/// identical, so the driver behavior must be identical).
#[test]
fn alias_cross_grammar_value_parity() {
    let ktf = run_value(
        "import kerf_string as str;\nstr::append(\"a\", \"b\")",
        "alias.ktf",
    );
    // E6 r154 / 224-c6: the .krf twin leg retired with the S-expr face;
    // the alias value anchor pins on the target side.
    assert_eq!(
        ktf, "ab",
        "alias reference program value anchor(actual: {})",
        ktf
    );
}

/// Positive 3 / grammar settlement: dual-Reader canonical rendering parity
/// — three shapes (single alias / mixed alias+plain items / underscore
/// alias names), byte-identical including the `as` marker symbol and Span
/// bytes.
#[test]
fn alias_dual_reader_canonical_parity() {
    assert_grammar_parity("import kerf_string as str;", "single alias form");
    assert_grammar_parity(
        "import kerf_string as str, kerf_list;",
        "mixed alias+bare-name form",
    );
    assert_grammar_parity(
        "import kerf_string as str_mod, kerf_list as lst;",
        "dual alias+underscore name form",
    );
    // The canonical form check: the mixed shape's Stx must carry the alias
    // pair symbol-for-symbol — (import kerf-string as str kerf-list).
    let mut t = SymbolTable::new();
    let items = read_source("import kerf_string as str, kerf_list;", 0, &mut t)
        .expect("mixed form must parse succeeded");
    let rendered = render_stx(&items[0], &t);
    assert!(
        rendered.contains("(sym kerf-string ")
            && rendered.contains("(sym as ")
            && rendered.contains("(sym str ")
            && rendered.contains("(sym kerf-list "),
        "canonical render must containing four symbols(kerf-string/as/str/kerf-list -- actual: {})",
        rendered
    );
}

/// Positive 4 / integration: mixed alias + plain items E2E — both the
/// aliased module and the plain module are live in one declaration.
#[test]
fn mixed_alias_and_plain_items_e2e() {
    let v = run_value(
        "import kerf_string as str, kerf_list as l;\nstr::append(\"a\", \"b\")",
        "mixed.ktf",
    );
    assert_eq!(
        v, "ab",
        "mixed declaration alias item in must be usable(actual: {})",
        v
    );
    let n = run_value(
        "import kerf_string as str, kerf_list as l;\nl::length(l::list(1, 2))",
        "mixed.ktf",
    );
    assert_eq!(
        n, "2",
        "mixed declaration in second alias item must be usable(actual: {})",
        n
    );
}

/// Positive 5: the underscore naming mapping — `str_mod` as the alias
/// name maps to the symbol `str-mod` at the Reader symbol-introduction
/// boundary, and the `str_mod::append` reference maps consistently (both
/// sides go through symbol_name — the mapping is total and
/// unambiguous).
#[test]
fn alias_underscore_name_mapping() {
    let v = run_value(
        "import kerf_string as str_mod;\nstr_mod::append(\"a\", \"b\")",
        "us.ktf",
    );
    assert_eq!(
        v, "ab",
        "underscore alias must via naming map consistent parse(actual: {})",
        v
    );
}

/// Positive 6 / integration: the module-header alias — inside the N1
/// module production face (`module m { import kerf_string as str; ... }`),
/// mirroring the S-expr namespace_tests anchor
/// `(module m (import kerf-string as str) (str/append "a" "b"))`.
#[test]
fn module_header_alias_e2e() {
    let v = run_value(
        "module m { import kerf_string as str; str::append(\"a\", \"b\") }",
        "mod.ktf",
    );
    assert_eq!(
        v, "ab",
        "module header zone alias must be usable(actual: {})",
        v
    );
}

/// Positive 7: the top-level value-definition call form with the alias
/// reference (`define(r, s::append(...));` — the r110 skin entry) — the
/// alias rewrite flows through the Define item path.
#[test]
fn alias_define_call_form_e2e() {
    let v = run_value(
        "import kerf_string as s;\nlet r = s::append(\"x\", \"y\");\nr",
        "def.ktf",
    );
    assert_eq!(
        v, "xy",
        "define call form in alias quote use must be usable(actual: {})",
        v
    );
}

/// Positive 8 / cross-stage: the alias program through
/// `check_source_recover` stays diagnostic-clean with real
/// instruction artifacts (the HM/typecheck face consumes the rewritten
/// qualified references without friction).
#[test]
fn alias_check_cross_stage_clean() {
    let report = check_source_recover(
        "import kerf_string as str;\nlet r = str::append(\"a\", \"b\");\nr",
        "alias.ktf",
    )
    .expect("recovery mode check does not short-circuit");
    assert!(
        report.diagnostics.is_empty(),
        "alias program check face must have zero diagnostics (actual: {:?})",
        report.diagnostics
    );
    assert!(
        report.proto_count + report.const_count > 0,
        "alias program must have a real compile artifact(actual: proto {} + const {})",
        report.proto_count,
        report.const_count
    );
}

// ---------------------------------------------------------------------------
// Negatives — reader-level dual-Reader parity (message + Span bytes)
// ---------------------------------------------------------------------------

/// Negative 1: `as` in name position — the alias shape missing its module
/// name; the Span is the `as` Token itself on BOTH sides (the r130 latent
/// divergence repair: the pre-window seed arm reported the post-bump
/// token).
#[test]
fn neg_alias_name_position_fail() {
    let m = assert_grammar_err_parity("import as b;", "name position as");
    assert!(
        m.contains("import as alias must follow the module name"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 2: name-position `as` after a comma — same diagnostic, the
/// second item slot.
#[test]
fn neg_alias_name_position_after_comma_fail() {
    assert_grammar_err_parity("import a, as b;", "name position after comma as");
}

/// Negative 3: the alias pair missing its right operand at the semicolon.
#[test]
fn neg_alias_missing_operand_semi_fail() {
    let m = assert_grammar_err_parity("import a as;", "missing alias right-hand operand (;)");
    assert!(
        m.contains("expected an alias identifier"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 4: the alias pair missing its right operand at an int literal.
#[test]
fn neg_alias_missing_operand_int_fail() {
    let m = assert_grammar_err_parity("import a as 5;", "missing alias right-hand operand (int)");
    assert!(
        m.contains("expected an alias identifier, got Int(5)"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 5: the alias pair missing its right operand at a string
/// literal.
#[test]
fn neg_alias_missing_operand_str_fail() {
    let m = assert_grammar_err_parity(
        "import a as \"s\";",
        "missing alias right-hand operand (str)",
    );
    assert!(
        m.contains("expected an alias identifier"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 6: a keyword cannot serve as the alias (the target-face lexer
/// reserves `if` — stronger than the S-expr face's contextual-symbol
/// model, which defers to the driver's keyword-binding check).
#[test]
fn neg_alias_keyword_operand_fail() {
    let m = assert_grammar_err_parity("import a as if;", "keyword as alias");
    assert!(
        m.contains("expected an alias identifier, got KwIf"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 7: double alias — after the alias the only continuations are
/// `,` or `;` (fail-closed via the `;` expectation, the seed's break +
/// expect(Semi) criterion).
#[test]
fn neg_double_alias_fail() {
    let m = assert_grammar_err_parity("import a as b as c;", "double alias");
    assert!(
        m.contains("expected ;, got KwAs"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 8: missing comma between the alias item and the next item.
#[test]
fn neg_missing_comma_after_alias_fail() {
    let m = assert_grammar_err_parity("import a as b c;", "alias after missing comma");
    assert!(
        m.contains("expected ;, got Ident"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 9: unclosed declaration — eof where `;` is expected.
#[test]
fn neg_alias_unclosed_fail() {
    let m = assert_grammar_err_parity("import a as b", "alias form unclosed");
    assert!(m.contains("expected ;, got Eof"), "message anchor: {:?}", m);
}

/// Negative 10: eof directly after `as`.
#[test]
fn neg_alias_eof_operand_fail() {
    let m = assert_grammar_err_parity("import a as", "alias right operand eof");
    assert!(
        m.contains("expected an alias identifier, got Eof"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 11: the alias declaration inside a block — the position
/// discipline keeps guarding (import is an organizational declaration,
/// not an expression; the E0018-family face at the Reader level).
#[test]
fn neg_alias_in_block_fail() {
    let m = assert_grammar_err_parity(
        "fn f() -> i64 { import a as b; 1 }",
        "inside a block alias declaration",
    );
    assert!(
        m.contains("expected an expression, got KwImport"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 12: the alias declaration in expression position (inside the
/// define call form's argument slot).
#[test]
fn neg_alias_in_expression_position_fail() {
    let m = assert_grammar_err_parity(
        "let x = import a as b;",
        "expression position alias declaration",
    );
    assert!(
        m.contains("expected an expression, got KwImport"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 13: trailing comma after an alias item — the next item slot
/// demands a name.
#[test]
fn neg_trailing_comma_after_alias_fail() {
    let m = assert_grammar_err_parity("import a as b,;", "alias after trailing comma");
    assert!(
        m.contains("expected an import name, got Semi"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 14: a keyword cannot serve as the module name either (the
/// existing family, through the reworked name arm).
#[test]
fn neg_keyword_module_name_fail() {
    let m = assert_grammar_err_parity("import fn as x;", "keyword as module name");
    assert!(
        m.contains("expected an import name, got KwFn"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 15: `export` has no alias form — the export face is a bare
/// name listing (fail-closed at the `;` expectation).
#[test]
fn neg_export_as_fail() {
    let m = assert_grammar_err_parity("export a as b;", "export no-alias form");
    assert!(
        m.contains("expected ;, got KwAs"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 16: `require` has no alias form — capability names are bare
/// identifiers (the r125 eighth-mapping family face).
#[test]
fn neg_require_as_fail() {
    let m = assert_grammar_err_parity("require io as x;", "require no-alias form");
    assert!(
        m.contains("expected ;, got KwAs"),
        "message anchor: {:?}",
        m
    );
}

// ---------------------------------------------------------------------------
// Negatives — driver-level semantic discipline (the established families,
// mirrored from the S-expr face's namespace_tests anchors)
// ---------------------------------------------------------------------------

/// Negative 17 / E0019: the alias of an unknown module — the registry
/// check precedes any alias semantics (Clojure-require-shaped rejection).
#[test]
fn neg_unknown_alias_module_e0019() {
    let err = run_source("import kerf_nonexist as x;\n42", "bad.ktf")
        .expect_err("unknown module alias must compile-time rejected");
    assert!(
        err.to_string().contains("unknown imported module"),
        "diagnostic must name unknown module(actual: {})",
        err
    );
}

/// Negative 18 / E0019: the path-form module name — `kerf::string` lowers
/// to the path symbol `kerf/string`, which is outside the registry's
/// hyphen-form allowlist (the honest boundary: import takes registry
/// names, paths are the qualified-reference face).
#[test]
fn neg_path_form_module_name_e0019() {
    let err = run_source("import kerf::string as str;\n42", "bad.ktf")
        .expect_err("path form module name must via E0019 rejected");
    assert!(
        err.to_string().contains("unknown imported module"),
        "diagnostic must name unknown module(actual: {})",
        err
    );
}

/// Negative 19 / E0017: duplicate alias — two modules aliased to the same
/// name (the S-expr face's m2_alias_duplicate_e0017 anchor, r40 M2 / 22
/// §3.5 R-N5 conflict column).
#[test]
fn neg_duplicate_alias_e0017() {
    let err = run_source("import kerf_string as s, kerf_symbol as s;\n42", "bad.ktf")
        .expect_err("duplicate alias must compile-time rejected");
    assert!(
        err.to_string().contains("duplicate alias"),
        "diagnostic must name duplicate alias(actual: {})",
        err
    );
}

/// Negative 21 / E0014: the aliased namespace does not export the
/// referenced member (the message carries the alias explanation — the
/// r130 E2E-observed form `alias str -> kerf-string`).
#[test]
fn neg_alias_unknown_member_e0014() {
    let err = run_source(
        "import kerf_string as str;\nstr::nonexist(\"a\")",
        "bad.ktf",
    )
    .expect_err("alias naming empty between unknown member must compile-time rejected");
    assert!(
        err.to_string().contains("does not export"),
        "diagnostic must name does not export(actual: {})",
        err
    );
}

/// Negative 22 / E0014: a qualified reference to a never-imported
/// namespace (no alias, no plain import — R-N3 no-fallback).
#[test]
fn neg_unimported_namespace_ref_e0014() {
    let err = run_source("s::append(\"a\", \"b\")", "bad.ktf").expect_err(
        "not imported naming empty between qualified reference must compile-time rejected",
    );
    assert!(
        err.to_string().contains("does not export"),
        "diagnostic must name does not export(actual: {})",
        err
    );
}

/// Negative 23 / E0022: the bare alias as a value — the alias is a
/// namespace binding, not a value binding (the r130 E2E-observed form).
#[test]
fn neg_bare_alias_unbound_e0022() {
    let err = run_source("import kerf_string as str;\nstr", "bad.ktf")
        .expect_err("bare alias value reference must compile-time rejected");
    assert!(
        err.to_string().contains("unbound reference"),
        "diagnostic must name unbound(actual: {})",
        err
    );
}

/// Negative 24 / E0004: the runtime type discipline through the alias
/// path — string-append demands two strings (the alias rewrite is
/// transparent to the callee's contract).
#[test]
fn neg_alias_runtime_type_e0004() {
    let err = run_source("import kerf_string as str;\nstr::append(1, 2)", "bad.ktf")
        .expect_err("alias path runtime type error must rejected");
    assert!(
        err.to_string().contains("string-append requires 2 strings"),
        "diagnostic must name string contract(actual: {})",
        err
    );
}

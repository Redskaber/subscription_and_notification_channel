// E6 close-out (r154 / 224-c5): corpus converted to the target-syntax face.
//! .ktf extern-declaration family tests — r137 / 207-c (the TD-026
//! language-surface window: the thirteenth skin-mapping family — the FFI
//! extern declaration + call surface).
//!
//! **Verification surfaces** (the target-face declaration family
//! `extern name(kinds) -> kind;` — the driver's collect_extern_face
//! consumes it unchanged — zero desugar, zero new CoreExpr/ModuleItem
//! variants, principle 31; design single source =
//! ffi-language-surface-design.md v1.0):
//! (1) **run-face E2E** — the declared extern call through the full
//! production chain (Reader → driver face collection + five-fold
//! validation [D3] → stripping [D2] → expansion → resolution
//! [IrVar::Extern — the flat extern symbol space] → emission
//! [Op::CallExternal #43] → runtime table construction [declaration ∩
//! available registry ∩ capability grant] → window protocol → real
//! host I/O) yields the byte-count return on **both chains** (the
//! production self-hosting chain + the Rust seed chain; skin/
//! skeleton isomorphism; the Φ ledger's window-balance discipline rides
//! the existing ffi_vm_tests anchors);
//! (2) **the grammar settlement** — the extern family is dual-Reader
//! verified: seed vs mirror canonical Stx rendering byte-identical
//! (including the nested kind-list node and its span), error faces
//! message + Span byte-identical;
//! (3) **cross-stage consumption** — the extern program through
//! `check_source_recover` stays diagnostic-clean with real
//! instruction artifacts (0 global refs — the extern name rides the
//! constant pool, never the global registry);
//! (4) **fail-closed negatives** — the five-fold declaration discipline
//! (shape / availability E0012-compile-time / contract E0026 /
//! duplicates / capability E0006) + the position discipline (E0026 —
//! top-level only, both faces) + the flat-space value-position
//! rejection (E0026 family — there is no extern function value) + the
//! runtime window-protocol propagation (E0011 arg-domain / arity — the
//! r30 enforcement arms carrying through the language path) + the
//! reader-level structure discipline (missing `->` / missing `;` /
//! non-kind tokens).
//!
//! E6 close-out (r154 / 224-c5): the S-expr face retired — the former
//! `.krf` production legs drive the Rust **seed chain**
//! (`run_source_seed` — the dual-path oracle surface, vm_tests'
//! dual_path precedent); the driver-level Stx-shape legs (form element
//! count / non-list kind table / non-symbol kind element) are
//! Read-stage pre-empted by the target grammar (the Reader fails
//! closed at the earliest point — c2's parity_err disposition) and are
//! carried by their target Reader twins (boundary switches stage,
//! semantics preserved — the c3 match_m2 precedent); filenames
//! `.krf` → `.ktf`; all message needles re-calibrated by running.
//!
//! Skin-dictionary basis: 20 §14 v1.28 (the thirteenth mapping — the
//! FFI extern declaration family); 02 §8.13.1a v7.21 (the Level 0
//! production update). Window basis: TD-026 register row ① (the
//! `language-face syntax / extern declaration form = Stage 3 anchor` declared-scope
//! implementation) + ffi-ownership-model v0.1.0 §2/§3/§4 (the frozen
//! mechanism base) + ffi-language-surface-design.md v1.0 (design single
//! source) + t3plus-trigger-audit v1.57 (M1 user-instruction order).
//! Ratio: 8 positive : 24 negative = 1:3 (§9.4.3).

use kerf_driver::bootstrap::reader::read_source_for_bootstrap;
use kerf_driver::{check_source_recover, run_source, run_source_seed};
use kerf_reader::reader::read_source;
use kerf_syntax::{Stx, StxDatum, StxLiteral, SymbolTable};

// ---------------------------------------------------------------------------
// Value helpers
// ---------------------------------------------------------------------------

fn run_value(src: &str, filename: &str) -> String {
    let outcome = run_source(src, filename)
        .unwrap_or_else(|e| panic!("target face program {} execution failed:{}", filename, e));
    kerf_vm::render_value(&outcome.value, &outcome.heap)
}

/// Seed-chain run (E6 close-out r154 / 224-c5: the S-expr face retired —
/// the former `.krf` production legs drive the Rust seed chain: seed
/// target Reader + seed expand + seed compile + VM, the dual-path
/// oracle surface of the production chain).
fn seed_value(src: &str, filename: &str) -> String {
    let outcome = run_source_seed(src, filename)
        .unwrap_or_else(|e| panic!("seed chain program {} execution failed:{}", filename, e));
    kerf_vm::render_value(&outcome.value, &outcome.heap)
}

// ---------------------------------------------------------------------------
// Dual-Reader parity helpers (the ktf_use_decl_tests.rs caliber —
// canonical rendering with Span bytes; error parity with message + Span
// byte equality)
// ---------------------------------------------------------------------------

fn render_stx(s: &Stx, t: &SymbolTable) -> String {
    let mut out = String::new();
    render_stx_into(s, t, &mut out);
    out
}

fn render_stx_into(s: &Stx, t: &SymbolTable, out: &mut String) {
    match &s.datum {
        StxDatum::Symbol(sym) => {
            out.push_str(&format!(
                "(sym {} {}..{})",
                t.name(*sym),
                s.span.start,
                s.span.end
            ));
        }
        StxDatum::Literal(l) => match l {
            StxLiteral::Int(v) => {
                out.push_str(&format!("(int {} {}..{})", v, s.span.start, s.span.end));
            }
            StxLiteral::Float(f) => {
                out.push_str(&format!("(float {:?} {}..{})", f, s.span.start, s.span.end));
            }
            StxLiteral::Str(r) => {
                out.push_str(&format!("(str {:?} {}..{})", r, s.span.start, s.span.end));
            }
            StxLiteral::Bool(b) => {
                out.push_str(&format!("(bool {} {}..{})", b, s.span.start, s.span.end));
            }
            StxLiteral::Nil => {
                out.push_str(&format!("(unit {}..{})", s.span.start, s.span.end));
            }
        },
        StxDatum::List(items) => {
            out.push_str(&format!("(lst {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
        // r138 / 208-c — TD-002: vectors now reach both Readers (the
        // fourteenth skin mapping) — full canonical rendering
        StxDatum::Vector(items) => {
            out.push_str(&format!("(vec {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
    }
}

/// Grammar parity assertion: both Readers' canonical renderings are
/// byte-identical (the extern family is seed/mirror isomorphic by
/// construction, including the nested kind-list node and its span bytes —
/// D10's braces-region precedent).
fn assert_grammar_parity(src: &str, what: &str) {
    let mut t1 = SymbolTable::new();
    let seed = read_source(src, 0, &mut t1)
        .unwrap_or_else(|e| panic!("[{}] seed syntax failed: {}", what, e.message));
    let mut t2 = SymbolTable::new();
    let mirror = read_source_for_bootstrap(src, 0, &mut t2)
        .unwrap_or_else(|e| panic!("[{}] mirror syntax failed:{}", what, e.message));
    assert_eq!(
        seed.len(),
        mirror.len(),
        "[{}] top-level item count mismatch (seed {} vs mirror {})",
        what,
        seed.len(),
        mirror.len()
    );
    for (i, (a, b)) in seed.iter().zip(mirror.iter()).enumerate() {
        assert_eq!(
            render_stx(a, &t1),
            render_stx(b, &t2),
            "[{}] top-level item #{} syntax tree mismatch (seed vs mirror canonical render)",
            what,
            i
        );
    }
}

/// Grammar-error parity assertion: message + Span byte-level equality.
fn assert_grammar_err_parity(src: &str, what: &str) -> String {
    let mut t1 = SymbolTable::new();
    let seed_err = match read_source(src, 0, &mut t1) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] seed should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    let mut t2 = SymbolTable::new();
    let mirror_err = match read_source_for_bootstrap(src, 0, &mut t2) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] mirror should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    assert_eq!(
        seed_err.message, mirror_err.message,
        "[{}] syntax error message mismatch (seed {:?} vs mirror {:?})",
        what, seed_err.message, mirror_err.message
    );
    assert_eq!(
        seed_err.span.start, mirror_err.span.start,
        "[{}] syntax error Span start mismatch (seed {} vs mirror {})",
        what, seed_err.span.start, mirror_err.span.start
    );
    assert_eq!(
        seed_err.span.end, mirror_err.span.end,
        "[{}] syntax error Span end mismatch (seed {} vs mirror {})",
        what, seed_err.span.end, mirror_err.span.end
    );
    seed_err.message.clone()
}

// ---------------------------------------------------------------------------
// Positives — run-face E2E + grammar settlement + cross-stage consumption
// ---------------------------------------------------------------------------

/// Positive 1 / integration: the core E2E — the declared extern call
/// through the full production chain and the Rust seed chain (the
/// window protocol's real host I/O round-trip: the char* borrow pins the
/// Str heap slot, the host writes stdout, LIFO unpin — the byte-count
/// return = 9; D6's declaration ∩ available registry ∩ capability grant
/// table construction feeding run_program_with_externs).
#[test]
fn extern_decl_call_e2e_dual_face() {
    let v = run_value(
        "require io, write;\nextern write_stdout(str) -> int;\nwrite_stdout(\"hello ffi\")",
        "ffi.ktf",
    );
    assert_eq!(
        v, "9",
        "target face extern call E2E(write(2) byte count -- actual: {})",
        v
    );
    let s = seed_value(
        "require io, write;\nextern write_stdout(str) -> int;\nwrite_stdout(\"hello ffi\")",
        "ffi_seed.ktf",
    );
    assert_eq!(s, "9", "seed chain extern call E2E(actual: {})", s);
}

/// Positive 2 / integration: the capability-gated E2E — the same program
/// through the **check face** stays diagnostic-clean with real artifacts
/// (cross-stage consumption: the extern call site's resolution never
/// enters global_refs — the symbol rides the constant pool; the
/// artifact counts anchor the [PushConst arg; CallExternal{sym, 1};
/// Halt] emission shape).
#[test]
fn extern_check_cross_stage_clean() {
    let report = check_source_recover(
        "require io, write;\nextern write_stdout(str) -> int;\nwrite_stdout(\"x\")",
        "clean.ktf",
    )
    .unwrap_or_else(|e| panic!("extern program check not should failed:{}", e.rendered));
    assert!(
        report.diagnostics.is_empty(),
        "extern program check zero diagnostics (actual: {:?})",
        report
            .diagnostics
            .iter()
            .map(|d| d.message.clone())
            .collect::<Vec<_>>()
    );
    assert!(
        report.proto_count >= 1,
        "check artifact real(prototype count: {})",
        report.proto_count
    );
    // 0 global refs — the extern name never enters the global registry
    // (the flat-space resolution intercepts at the Apply head; D5's
    // positional discipline's observable footprint)
    assert_eq!(
        report.global_ref_count, 0,
        "extern name not input global_refs pool(actual: {})",
        report.global_ref_count
    );
}

/// Positive 3 / grammar: the dual-Reader canonical parity — the extern
/// declaration form renders byte-identically from the seed and mirror
/// Readers (including the nested kind-list node + span bytes; the
/// underscore→hyphen normalization `write_stdout` → `write-stdout` is
/// the Reader's symbol-introduction boundary, 20 §8).
#[test]
fn extern_dual_reader_canonical_parity() {
    assert_grammar_parity("extern write_stdout(str) -> int;", "decl-parity");
    assert_grammar_parity("extern write_stdout() -> int;", "decl-empty-parity");
    assert_grammar_parity("extern write_stdout(str, str) -> int;", "decl-two-parity");
}

/// Positive 4 / integration: the nested-context call — the extern call
/// inside a fn body (the resolution is depth-independent: the flat
/// extern space is consulted after the lexical frames miss, before the
/// global fallback — a param named `m` shadows nothing here; the call
/// compiles to the same FFI emission shape inside the prototype).
#[test]
fn extern_nested_fn_call_e2e() {
    let v = run_value(
        "require io, write;\nextern write_stdout(str) -> int;\nfn f(m: T) { write_stdout(m) }\nf(\"nested-ok\")",
        "nested.ktf",
    );
    assert_eq!(v, "9", "fn in body extern call(actual: {})", v);
}

/// Positive 5 / integration: the mixed program — the extern declaration
/// coexists with defines and imports (zero mutual interference: the
/// flat-space collision check passed at the front, the define face and
/// the extern face are disjoint).
#[test]
fn extern_mixed_program_e2e() {
    let v = seed_value(
        "require io, write;\nextern write_stdout(str) -> int;\nfn pad(s: T) { s }\nwrite_stdout(pad(\"mix\")) + 1",
        "mixed.ktf",
    );
    assert_eq!(
        v, "4",
        "extern + define mixed program(3 byte + 1 -- actual: {})",
        v
    );
}

/// Positive 6 / integration: the call in operand position (the extern
/// call's return feeds an enclosing expression — the A1 evaluation-order
/// contract carries the arg value onto the stack, the CallExternal
/// result lands in the enclosing operator's operand position).
#[test]
fn extern_call_arg_position_e2e() {
    let v = run_value(
        "require io, write;\nextern write_stdout(str) -> int;\n1 + write_stdout(\"ab\")",
        "argpos.ktf",
    );
    assert_eq!(
        v, "3",
        "operand position extern call(2 byte + 1 -- actual: {})",
        v
    );
}

/// Positive 7 / integration: the position-legal form through the Rust
/// seed chain (E6 close-out r154 / 224-c5: the S-expr Reader face
/// retired — the former `.krf` canonical-form leg drives the seed
/// target Reader + seed expand + seed compile chain; the driver's
/// collector consumes the same `(extern ...)` Stx at the same layer on
/// both chains).
#[test]
fn extern_krf_face_production_e2e() {
    let v = seed_value(
        "require io, write;\nextern write_stdout(str) -> int;\nwrite_stdout(\"s-expr\")",
        "krfprod.ktf",
    );
    assert_eq!(v, "6", "seed chain canonical form E2E(actual: {})", v);
}

/// Positive 8 / integration: the empty-parameter kind list —
/// `extern f() -> kind;` parses on both Readers (a zero-argument extern
/// is grammatically legal; the registry has no zero-arg symbol so a run
/// is not exercisable — the grammar face anchors the empty-list shape, the
/// kind-list span = the '(' ')' region).
#[test]
fn extern_empty_params_grammar_legal() {
    // The dual-Reader parity itself is the anchor (Positive 3's empty
    // case); here the failure-face distinction: an empty-param extern
    // declaration reaches the AVAILABILITY gate (E0012), not a shape
    // gate — proving the empty kind list passed the shape validation.
    let e = run_source("extern nothing_at_all() -> int;", "empty.ktf")
        .expect_err("zero-argument declarations necessarily reach the registrability gate(no zero-argument registered symbols)");
    assert!(
        e.rendered.contains("E0012") && e.rendered.contains("nothing-at-all"),
        "zero arguments extern goes shape gate after reach E0012 registrability gate(actual: {})",
        e.rendered
    );
}

// ---------------------------------------------------------------------------
// Negatives — the five-fold declaration discipline + position + flat
// space + runtime window + reader structure (24 families)
// ---------------------------------------------------------------------------

/// Negative 1: shape — non-symbol name position (an Int literal in the
/// name slot).
#[test]
fn neg_extern_shape_name_int_fail() {
    let e = run_source("extern 42(str) -> int;", "n1.ktf")
        .expect_err("name position non-symbol must rejected");
    assert!(
        e.rendered.contains("expected an external symbol name"),
        "name position non-symbol anchor(actual: {})",
        e.rendered
    );
}

/// Negative 2: shape — the kind table missing its `(` (E6 close-out
/// r154 / 224-c5: the S-expr non-list kind-table leg (`(extern n str
/// int)` → driver "ternary must be argument kind table") is
/// Read-stage pre-empted by the target grammar — the bare-symbol form
/// hits the `(` expectation; boundary switches stage, the malformed-
/// structure rejection semantics preserved, message re-calibrated by
/// running; dual-Reader message + Span parity carried with it).
#[test]
fn neg_extern_shape_params_not_list_fail() {
    let msg = assert_grammar_err_parity("extern write_stdout str -> int;", "n2-params-shape");
    assert!(
        msg.contains("expected ("),
        "kind table missing paren anchor(actual: {})",
        msg
    );
}

/// Negative 3: shape — the trailing-element form (E6 close-out r154 /
/// 224-c5: the S-expr five-element form (`(extern n (str) int extra)`
/// → driver "exactly four elements"/"5 element") is Read-stage
/// pre-empted — the trailing token hits the mandatory-`;` expectation,
/// the same declaration-family terminator discipline as the
/// require/import precedent).
#[test]
fn neg_extern_shape_arity_fail() {
    let msg = assert_grammar_err_parity("extern write_stdout(str) -> int extra;", "n3-form-arity");
    assert!(
        msg.contains("expected ;"),
        "trailing element terminator anchor(actual: {})",
        msg
    );
}

/// Negative 4: shape — the kind word outside the three-word vocabulary.
#[test]
fn neg_extern_shape_kind_word_domain_out() {
    let e = run_source(
        "require io, write;\nextern write_stdout(float) -> int;",
        "n4.ktf",
    )
    .expect_err("kind word out of domain must be rejected");
    assert!(
        e.rendered.contains("float") && e.rendered.contains("three words maximum"),
        "kind word out of domain anchor(actual: {})",
        e.rendered
    );
}

/// Negative 5: shape — the return kind word outside the vocabulary.
#[test]
fn neg_extern_shape_ret_kind_domain_out() {
    let e = run_source(
        "require io, write;\nextern write_stdout(str) -> bool;",
        "n5.ktf",
    )
    .expect_err("return kind word out of domain must be rejected");
    assert!(
        e.rendered.contains("bool") && e.rendered.contains("out of domain"),
        "return kind out of domain anchor(actual: {})",
        e.rendered
    );
}

/// Negative 6: shape — the kind-list element is not a kind word (E6
/// close-out r154 / 224-c5: the S-expr non-symbol kind element
/// (`(extern n (1) int)` → driver "argument kind position must be
/// symbol") is Read-stage pre-empted — a Str literal in the kind slot
/// hits the kind-word expectation, distinct from Negative 24's Int
/// probe; boundary switches stage, semantics preserved).
#[test]
fn neg_extern_shape_kind_element_not_symbol() {
    let msg = assert_grammar_err_parity("extern write_stdout(\"str\") -> int;", "n6-kind-word");
    assert!(
        msg.contains("kind words"),
        "kind position non-ident anchor(actual: {})",
        msg
    );
}

/// Negative 7: position — an extern declaration inside a block (the
/// fail-closed layer = the Reader: `extern` is a keyword token, the
/// statement-position parser rejects it before the Stx layer [E0001];
/// the second leg carries the same Read-stage rejection inside an
/// if-arm block — depth/context-independence of the positional word).
#[test]
fn neg_extern_position_do_block_fail() {
    let e = run_source(
        "require io, write;\nextern write_stdout(str) -> int;\nfn f() { extern write_stdout(str) -> int; 1 }\nf()",
        "n7.ktf",
    )
    .expect_err("inside a block extern declaration must rejected");
    assert!(
        e.rendered.contains("E0001") && e.rendered.contains("extern"),
        "inside a block extern reader layer rejected anchor(actual: {})",
        e.rendered
    );
    // The if-arm nested-block carrier: the same E0001 positional-word
    // rejection one nesting context over (E6 close-out r154 / 224-c5:
    // the former .krf Stx-level E0026 scan leg is Read-stage
    // pre-empted on the target face — `extern` never reaches Stx from
    // an expression position; the module-body E0026 carrier is
    // Negative 9's).
    let e2 = run_source(
        "require io, write;\nif (true) { extern write_stdout(str) -> int; 1 } else { 2 }",
        "n7b.ktf",
    )
    .expect_err("if-arm inside a block extern must reader rejected");
    assert!(
        e2.rendered.contains("E0001") && e2.rendered.contains("extern"),
        "if-arm nested block extern reader rejected anchor(actual: {})",
        e2.rendered
    );
}

/// Negative 8: the expression-argument-position carrier (E6 close-out
/// r154 / 224-c5: the S-expr expander-level backstop (`(do (extern ...)
/// 1)`) is Read-stage pre-empted — `extern` inside a call's argument
/// list hits the expression expectation before any Stx exists; the
/// structural rejection face carries as the E0001 KwExtern anchor).
#[test]
fn neg_extern_position_expr_face_backstop() {
    let e = run_source(
        "require io, write;\ndo(extern write_stdout(str) -> int, 1)",
        "n8.ktf",
    )
    .expect_err("expression position extern must structure rejected");
    assert!(
        e.rendered.contains("E0001") && e.rendered.contains("extern"),
        "expression position extern structure rejected anchor(actual: {})",
        e.rendered
    );
}

/// Negative 9: position — the module-body carrier (the Stx-level E0026
/// position scan: the module body is the one nested carrier where the
/// extern form reaches the driver's Stx layer — top-level only, 22 §15
/// D47).
#[test]
fn neg_extern_position_module_body_fail() {
    let e = run_source("module m { extern write_stdout(str) -> int; }", "n9.ktf")
        .expect_err("module in body extern must position violation");
    assert!(
        e.rendered.contains("E0026") && e.rendered.contains("position violation"),
        "module body extern position violation anchor(actual: {})",
        e.rendered
    );
}

/// Negative 10: availability — an unknown symbol name (E0012's
/// compile-time variant; the message names the available face).
#[test]
fn neg_extern_unknown_symbol_e0012_compile_time() {
    let e = run_source(
        "require io, write;\nextern no_such_host(str) -> int;\nno_such_host(\"x\")",
        "n10.ktf",
    )
    .expect_err("unknown external symbol must E0012 compile-time change body");
    assert!(
        e.rendered.contains("E0012")
            && e.rendered.contains("no-such-host")
            && e.rendered.contains("write-stdout"),
        "E0012 compile-time change body anchor(actual: {})",
        e.rendered
    );
}

/// Negative 11: availability — the declaration-only minimal form (E6
/// close-out r154 / 224-c5: the former S-expr-face mirror now carries
/// the message-family parity on the minimal shape — the bare
/// declaration with no require and no call, the E0012 face asserting
/// the registry message family alone).
#[test]
fn neg_extern_unknown_symbol_krf_face() {
    let e = run_source("extern no_such_host(str) -> int;", "n11.ktf")
        .expect_err("declaration-only unknown external symbol must same family rejected");
    assert!(
        e.rendered.contains("E0012")
            && e.rendered
                .contains("not in can registration face registered"),
        "declaration-only E0012 anchor(actual: {})",
        e.rendered
    );
}

/// Negative 12: contract — the parameter kind mismatch (E0026).
#[test]
fn neg_extern_contract_param_mismatch_e0026() {
    let e = run_source(
        "require io, write;\nextern write_stdout(int) -> int;\nwrite_stdout(1)",
        "n12.ktf",
    )
    .expect_err("argument kind mismatch must E0026 contract family");
    assert!(
        e.rendered.contains("E0026")
            && e.rendered.contains("contract mismatch")
            && e.rendered.contains("(str)→ int"),
        "argument contract mismatch anchor(actual: {})",
        e.rendered
    );
}

/// Negative 13: contract — the return kind mismatch.
#[test]
fn neg_extern_contract_ret_mismatch_e0026() {
    let e = run_source(
        "require io, write;\nextern write_stdout(str) -> str;\nwrite_stdout(\"x\")",
        "n13.ktf",
    )
    .expect_err("return kind mismatch must E0026 contract family");
    assert!(
        e.rendered.contains("E0026") && e.rendered.contains("contract mismatch"),
        "return contract mismatch anchor(actual: {})",
        e.rendered
    );
}

/// Negative 14: capability — the write grant missing (E0006 family; the
/// FFI write channel shares the io write authorization token).
#[test]
fn neg_extern_capability_missing_e0006() {
    let e = run_source(
        "extern write_stdout(str) -> int;\nwrite_stdout(\"x\")",
        "n14.ktf",
    )
    .expect_err("missing write capability must E0006");
    assert!(
        e.rendered.contains("E0006")
            && e.rendered.contains("requires write capability")
            && e.rendered.contains("extern"),
        "capability gate anchor(actual: {})",
        e.rendered
    );
}

/// Negative 15: capability — read-only grant does not satisfy the write
/// requirement (the dimension precision).
#[test]
fn neg_extern_capability_read_only_insufficient() {
    let e = run_source(
        "require io, read;\nextern write_stdout(str) -> int;\nwrite_stdout(\"x\")",
        "n15.ktf",
    )
    .expect_err("read authorization does not satisfy write requires request");
    assert!(
        e.rendered.contains("E0006") && e.rendered.contains("write"),
        "capability dimension precision anchor (actual: {})",
        e.rendered
    );
}

/// Negative 16: duplicate — the same symbol declared twice.
#[test]
fn neg_extern_duplicate_declaration_fail() {
    let e = run_source(
        "require io, write;\nextern write_stdout(str) -> int;\nextern write_stdout(str) -> int;",
        "n16.ktf",
    )
    .expect_err("duplicate declaration must rejected");
    assert!(
        e.rendered.contains("duplicate declaration") && e.rendered.contains("write-stdout"),
        "duplicate declaration anchor(actual: {})",
        e.rendered
    );
}

/// Negative 17: duplicate — the extern name collides with a top-level
/// define (the flat-space anti-shadowing enforcement).
#[test]
fn neg_extern_define_collision_fail() {
    let e = run_source(
        "extern write_stdout(str) -> int;\nfn write_stdout(a: T) { a }",
        "n17.ktf",
    )
    .expect_err("extern and define name collision must rejected");
    assert!(
        e.rendered.contains("name collision") && e.rendered.contains("write-stdout"),
        "define collision anchor (actual: {})",
        e.rendered
    );
}

/// Negative 18: duplicate — the extern name collides with an imported
/// flat member (the selective import injects the UNDERLYING name into
/// the flat face — string-append; the flat-space anti-shadowing
/// enforcement hits it).
#[test]
fn neg_extern_import_collision_fail() {
    let e = run_source(
        "use kerf_string::{append};\nextern string_append(str) -> int;\nstring_append(\"a\", \"b\")",
        "n18.ktf",
    )
    .expect_err("extern and import injection name name collision must rejected");
    assert!(
        e.rendered.contains("name collision") && e.rendered.contains("string-append"),
        "import collision anchor (actual: {})",
        e.rendered
    );
}

/// Negative 19: flat space — the value-position reference (there is no
/// extern function value; the production bootstrap path's cerr face).
#[test]
fn neg_extern_value_position_rejected() {
    let e = run_source(
        "require io, write;\nextern write_stdout(str) -> int;\nwrite_stdout",
        "n19.ktf",
    )
    .expect_err("value position extern quote use must rejected");
    assert!(
        e.rendered.contains("write-stdout") && e.rendered.contains("call-position only"),
        "value position rejected anchor(actual: {})",
        e.rendered
    );
}

/// Negative 20: flat space — the value-definition-position carrier (E6
/// close-out r154 / 224-c5: the former S-expr-face mirror now carries
/// the define-value shape — `define(f, write_stdout);` binds the extern
/// name into a value slot, the same call-position-only law one program
/// shape over).
#[test]
fn neg_extern_value_position_krf_face() {
    let e = run_source(
        "require io, write;\nextern write_stdout(str) -> int;\nlet f = write_stdout;",
        "n20.ktf",
    )
    .expect_err("define-value position extern must same family rejected");
    assert!(
        e.rendered.contains("write-stdout") && e.rendered.contains("call-position only"),
        "define-value position anchor(actual: {})",
        e.rendered
    );
}

/// Negative 21: runtime — the argument domain mismatch propagates from
/// the window protocol (E0011 — the r30 enforcement arm carrying through
/// the language path; the declaration said str, the call passed an int).
#[test]
fn neg_extern_runtime_arg_domain_e0011() {
    let e = run_source(
        "require io, write;\nextern write_stdout(str) -> int;\nwrite_stdout(1)",
        "n21.ktf",
    )
    .expect_err("actual argument domain mismatch must E0011 run-time propagation");
    assert!(
        e.rendered.contains("E0011")
            && e.rendered.contains("write-stdout")
            && e.rendered.contains("CPointer"),
        "E0011 actual argument domain anchor(actual: {})",
        e.rendered
    );
}

/// Negative 22: runtime — the arity mismatch (E0011).
#[test]
fn neg_extern_runtime_arity_e0011() {
    let e = run_source(
        "require io, write;\nextern write_stdout(str) -> int;\nwrite_stdout(\"a\", \"b\")",
        "n22.ktf",
    )
    .expect_err("arity mismatch must E0011 run-time propagation");
    assert!(
        e.rendered.contains("E0011") && e.rendered.contains("actual argument count mismatch"),
        "E0011 arity anchor(actual: {})",
        e.rendered
    );
}

/// Negative 23: reader — the missing `->` (the target-face structure
/// discipline; dual-Reader message + Span parity).
#[test]
fn neg_extern_reader_missing_arrow_fail() {
    let msg = assert_grammar_err_parity("extern write_stdout(str) int;", "n23-miss-arrow");
    assert!(msg.contains("->"), "missing -> anchor(actual: {})", msg);
}

/// Negative 24: reader — the missing `;` terminator + the non-kind token
/// in the kind list (the declaration-family's mandatory-terminator
/// discipline, the require/import precedent).
#[test]
fn neg_extern_reader_missing_semi_and_kind_token_fail() {
    let msg = assert_grammar_err_parity("extern write_stdout(str) -> int", "n24-miss-semi");
    assert!(msg.contains(";"), "missing; anchor(actual: {})", msg);
    let msg2 = assert_grammar_err_parity("extern write_stdout(42) -> int;", "n24-kind-int");
    assert!(
        msg2.contains("kind word") || msg2.contains("expected"),
        "kind position non- ident anchor(actual: {})",
        msg2
    );
}

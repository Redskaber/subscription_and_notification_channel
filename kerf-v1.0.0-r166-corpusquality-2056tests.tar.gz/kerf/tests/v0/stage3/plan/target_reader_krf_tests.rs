//! Switch-window step (2) lexical parity test family (r107 / 177-c).
//!
//! **Cross-check domain**: `lex_for_parity` (the Rust seed oracle —
//! kerf-reader/target.rs) ↔ `lex_for_bootstrap` (the .krf path —
//! bootstrap/reader.krf run on the VM). Gate = kind/Span/payload
//! **byte-level equality** (Span in byte terms — both sides same-source
//! after the seed's r107 offset-alignment fix) + error-path message/Span
//! equality.
//!
//! **Coverage matrix** (§9.4 — positive/negative contrast): full-program
//! lexing ×8 families / radix and separators / overflow boundaries (i64max
//! and +1) / float form families (including the r107 fix face: signed
//! exponents and the exponent `_`) / string escapes and errors (including
//! the EOF-backslash criterion mirror) / nested comments and unclosed /
//! path flattening / the full operator table / lifetimes / illegal
//! characters / Unicode Span precision / the full keyword table / empty
//! source and pure whitespace.

use kerf_driver::bootstrap::reader::lex_for_bootstrap;
use kerf_reader::{lex_for_parity, ParityToken};

fn assert_lex_parity(src: &str, what: &str) {
    let seed = lex_for_parity(src, 0)
        .unwrap_or_else(|e| panic!("[{}] seed lexical failed: {}", what, e.message));
    let krf = lex_for_bootstrap(src, 0)
        .unwrap_or_else(|e| panic!("[{}] .krf lexical failed:{}", what, e.message));
    assert_eq!(
        seed.len(),
        krf.len(),
        "[{}] Token count mismatch (seed {} vs .krf {})",
        what,
        seed.len(),
        krf.len()
    );
    for (i, (a, b)) in seed.iter().zip(krf.iter()).enumerate() {
        assert_eq!(a.kind, b.kind, "[{}] Token #{} kind mismatch", what, i);
        assert_eq!(a.start, b.start, "[{}] Token #{} start mismatch", what, i);
        assert_eq!(a.end, b.end, "[{}] Token #{} end mismatch", what, i);
        assert_eq!(
            a.payload, b.payload,
            "[{}] Token #{} payload mismatch",
            what, i
        );
    }
}

fn assert_lex_err_parity(src: &str, what: &str) -> (String, u32, u32) {
    let seed_err = match lex_for_parity(src, 0) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] seed should be lexical error(actually parsed successfully)",
            what
        ),
    };
    let krf_err = match lex_for_bootstrap(src, 0) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] .krf should be lexical error(actually parsed successfully)",
            what
        ),
    };
    assert_eq!(
        seed_err.message, krf_err.message,
        "[{}] error message mismatch (seed {:?} vs .krf {:?})",
        what, seed_err.message, krf_err.message
    );
    assert_eq!(
        seed_err.span.start, krf_err.span.start,
        "[{}] error Span start mismatch",
        what
    );
    assert_eq!(
        seed_err.span.end, krf_err.span.end,
        "[{}] error Span end mismatch",
        what
    );
    (
        seed_err.message.clone(),
        seed_err.span.start,
        seed_err.span.end,
    )
}

fn expect_err(src: &str, what: &str) -> (String, u32, u32) {
    assert_lex_err_parity(src, what)
}

// ---------------------------------------------------------------------------
// Full-program lexical parity (r106 step (1) cross-syntax parity corpus
// reuse — deep lexical-level checking)
// ---------------------------------------------------------------------------

#[test]
fn parity_full_programs() {
    assert_lex_parity(
        "fn add(a: i64, b: i64) -> i64 { a + b }\nadd(2, 3)",
        "fn declaration and call",
    );
    assert_lex_parity(
        "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(12)",
        "fib recursion",
    );
    assert_lex_parity(
        "fn f(x: i64) -> i64 { let y = x + 1; let z = y * 2; z + y }",
        "let threading",
    );
    assert_lex_parity("fn g() -> i64 { let x = 1; x = 5; x }", "assign statement");
    assert_lex_parity(
        "fn f(a: i64, b: i64, c: i64) -> bool { a + b * c < a * c + b && b < c || c < a }",
        "precedence hierarchy",
    );
    assert_lex_parity(
        "fn mk(x: i64) -> Fn(i64) -> i64 { || (y: i64) { x + y } }\nmk(10)",
        "closure",
    );
    assert_lex_parity(
        "module m { fn f(x: i64) -> i64 { x * 2 } }\nm::f(21)",
        "module qualified call",
    );
    assert_lex_parity(
        "fn count(n: i64) -> i64 { let i = 0; let acc = 0; while!(i < n, acc = acc + i); acc }",
        "macro call name!(...)",
    );
    assert_lex_parity(
        "fn ask() -> i64 { perform gift(0, 20); }\nhandle ask() { gift(p, k) => resume(tail(p) + head(p)) }",
        "perform/handle effect loop",
    );
}

// ---------------------------------------------------------------------------
// Number families: radix / separators / overflow boundaries / float forms
// (including the r107 fix face)
// ---------------------------------------------------------------------------

#[test]
fn parity_radix_and_separators() {
    assert_lex_parity("0xFF 0o17 0b1011 0XfF 0O7 0B10", "enter make all form");
    assert_lex_parity(
        "1_000 1_000_000 0x1_F 0b1_0 1_0",
        "digit partition separate symbol",
    );
    assert_lex_parity("0x 0o 0b 0", "enter make prefix no digit segment(value 0)");
    assert_lex_parity("0b12 0o8 0xg", "enter make out of domain digit truncation");
    assert_lex_parity("42 0 007", "ten enter make form");
}

#[test]
fn parity_int_overflow_boundaries() {
    // The exact i64max boundary (passes)
    assert_lex_parity("9223372036854775807", "i64max");
    // +1 (both sides error + Span equality)
    let (msg, s, e) = expect_err("9223372036854775808", "i64max+1 overflow");
    assert_eq!(msg, "integer literal overflow");
    assert_eq!((s, e), (0, 19));
    // A large overflow value (the Span still extends to the token tail after the guard)
    let (_, s2, e2) = expect_err("99999999999999999999999", "far exceed bound overflow");
    assert_eq!((s2, e2), (0, 23));
    // Hex boundary: 0x7FFFFFFFFFFFFFFF (i64max) passes
    assert_lex_parity("0x7FFFFFFFFFFFFFFF", "hex i64max");
    // 0x8000000000000000 (+1) errors
    let (m3, _, _) = expect_err("0x8000000000000000", "hex overflow");
    assert_eq!(m3, "integer literal overflow");
    // Binary boundary (63 ones = i64max)
    assert_lex_parity(
        "0b111111111111111111111111111111111111111111111111111111111111111",
        "bin i64max",
    );
    let (m4, _, _) = expect_err(
        "0b1000000000000000000000000000000000000000000000000000000000000000",
        "bin overflow(64 position)",
    );
    assert_eq!(m4, "integer literal overflow");
}

#[test]
fn parity_float_forms() {
    // r107 fix face: signed exponents (original seed defect — the split token "1e")
    assert_lex_parity("1e+5 1e-5 3.14e+2 2.5E-3", "carry symbol exponent");
    // r107 fix face: the '_' separator in exponents (previously pushed into the mantissa,
    // guaranteeing parse failure)
    assert_lex_parity("1e5_0 1.5e1_0", "exponent partition separate symbol");
    assert_lex_parity("3.14 1.5 0.25 100.0", "small count form");
    assert_lex_parity("1e5 2E3 5e0", "no symbol exponent");
    assert_lex_parity("1. 1..5", "dot bound form(Int+Dot / DotDot truncation)");
    assert_lex_parity("1e", "'1e' truncation(Int + ident e)");
    assert_lex_parity("0.5 0.0e0", "leading-zero float");
}

#[test]
fn parity_float_invalid_forms() {
    // f64-unparseable shapes (both sides same message and Span — the .krf side fronts
    // float-text-bad)
    let (m, s, e) = expect_err("1e5e5", "dual e form");
    assert_eq!(m, "invalid float literal");
    assert_eq!((s, e), (0, 5));
    let (m2, s2, e2) = expect_err("1.5.5", "dual dot form");
    assert_eq!(m2, "invalid float literal");
    assert_eq!((s2, e2), (0, 5));
    let (m3, s3, e3) = expect_err("1e3.5", "dot after place e");
    assert_eq!(m3, "invalid float literal");
    assert_eq!((s3, e3), (0, 5));
    // When coexisting with a later lexical error, the float error comes first (mirror of the
    // seed's error ordering)
    let (m4, _, _) = expect_err(
        "1e5e5 $",
        "float error optimize first at successor illegal character",
    );
    assert_eq!(m4, "invalid float literal");
}

// ---------------------------------------------------------------------------
// String family: full escape set / content parity / error paths (incl. the
// EOF-backslash criterion)
// ---------------------------------------------------------------------------

#[test]
fn parity_string_escapes() {
    assert_lex_parity("\"a\\tb\\n\\\\\\\"quote\"", "escape all amount(n t \\ \")");
    assert_lex_parity("\"\\r\\0\\'x\"", "escape(r 0 ')");
    assert_lex_parity(
        "\"plain\" \"\" \"a b c\"",
        "plain pass string and empty string",
    );
    assert_lex_parity("\"line1\nline2\"", "cross line string");
    assert_lex_parity("\"héllo→世界\"", "many byte content(Span byte basis)");
}

#[test]
fn parity_string_errors() {
    let (m, s, e) = expect_err("\"abc", "unclosed string");
    assert_eq!(m, "unclosed string");
    assert_eq!((s, e), (0, 4));
    let (m2, s2, e2) = expect_err("\"a\\qz\"", "illegal escape");
    assert_eq!(m2, "illegal escape:\\q");
    assert_eq!((s2, e2), (2, 4));
    // EOF backslash (mirror of the seed criterion: a virtual-space escape character, right bound =
    // bs-off+2)
    let (m3, s3, e3) = expect_err("\"ab\\", "EOF backslash");
    assert_eq!(m3, "illegal escape:\\ ");
    assert_eq!((s3, e3), (3, 5));
    // Multi-byte illegal escape (right bound = the byte offset after the escaped character)
    let (m4, s4, e4) = expect_err("\"a\\é\"", "many byte illegal escape");
    assert_eq!(m4, "illegal escape:\\é");
    assert_eq!((s4, e4), (2, 5));
}

// ---------------------------------------------------------------------------
// Comment family: line comments / nested block comments / unclosed
// ---------------------------------------------------------------------------

#[test]
fn parity_comments() {
    assert_lex_parity("// 行注释\n42", "line comment");
    assert_lex_parity("// 到 EOF", "line comment to EOF");
    assert_lex_parity("/* 单层 */ 7", "single layer block comment");
    assert_lex_parity("/* 外层 /* 嵌套 */ 继续 */ 9", "nested block comment");
    assert_lex_parity("a /* 注 */ + /* 释 */ b", "comment pierce insert");
    assert_lex_parity("/* 注 */ // 行\n/* 二 */ 1", "mixed combine comment");
    let (m, s, e) = expect_err("/* 未闭合", "unclosed block comment");
    assert_eq!(m, "unclosed block comment");
    assert_eq!((s, e), (0, 12));
    let (m2, s2, _) = expect_err("/* a /* b */", "outer unclosed(nested)");
    assert_eq!(m2, "unclosed block comment");
    assert_eq!(s2, 0);
    // '/*/' unclosed (seed criterion: after the opener there is no closing pair — a trailing
    // single '/' does not close)
    let (m3, _, _) = expect_err("/*/ 5", "'/*/' empty bound form");
    assert_eq!(m3, "unclosed block comment");
}

// ---------------------------------------------------------------------------
// Identifiers / keywords / path flattening
// ---------------------------------------------------------------------------

#[test]
fn parity_keywords_and_idents() {
    // Full keyword table (22 word faces + as)
    assert_lex_parity(
        "fn let mut if else module import export require perform handle resume move pub use match type effect capability struct enum as",
        "keyword all table",
    );
    assert_lex_parity("true false", "bool literal");
    assert_lex_parity("fnx lets _x _1 x_ if_ a_b9", "near keyword identifier");
    assert_lex_parity("()", "unit literal");
    assert_lex_parity("( ) (())", "unit vs parentheses for");
}

#[test]
fn parity_paths() {
    assert_lex_parity("a::b::c", "path push level(two segment)");
    assert_lex_parity("kerf::string::append", "path push level(three segment)");
    assert_lex_parity("a::b1::c_2", "path segment containing digit underscore");
    assert_lex_parity("a:: ", "tail follow :: (ident + pathsep)");
    assert_lex_parity("fn::x", "keyword after :: (not continue path)");
    assert_lex_parity("m::f(21)", "path call form state");
    assert_lex_parity("a::1", ":: after non- id-start");
}

// ---------------------------------------------------------------------------
// Full operator table / lifetimes / illegal characters
// ---------------------------------------------------------------------------

#[test]
fn parity_operator_sweep() {
    assert_lex_parity(
        "+ - * / % == = != < > <= >= && || : :: , ; . .. -> =>",
        "operator table(one)",
    );
    assert_lex_parity("| & ^ << >> |> ! ( ) { } [ ]", "operator table(two)");
    assert_lex_parity(
        "a<<b>>c|d&e^f",
        "bitwise connect write(registration out of domain -- lexical still produce)",
    );
    assert_lex_parity("a|>b=>c", "pipeline and fat arrow connect write");
    assert_lex_parity(
        "<=>=<>=<",
        "ambiguity prefix eliminate ambiguity(greedy heart two character optimize first)",
    );
    assert_lex_parity("a.b.c", "dot chain");
}

#[test]
fn parity_lifetimes() {
    assert_lex_parity("'x", "produce command cycle variable");
    assert_lex_parity("'lifetime2 '_t", "produce command cycle form family");
    assert_lex_parity("f<'a>", "general type position produce command cycle");
    // ' followed by a non-id-start → illegal character (same criterion as the seed)
    let (m, _, _) = expect_err("' 1", "isolated quotes");
    assert_eq!(m, "illegal character:'");
    assert_lex_parity("'x + 'y", "produce command cycle and operator");
}

#[test]
fn parity_illegal_chars() {
    let (m, s, e) = expect_err("#", "hash sign");
    assert_eq!(m, "illegal character:#");
    assert_eq!((s, e), (0, 1));
    let (m2, _, e2) = expect_err("a $ b", "beautiful element symbol");
    assert_eq!(m2, "illegal character:$");
    assert_eq!(e2, 3);
    let (m3, s3, e3) = expect_err("é", "many byte illegal character(Span all character)");
    assert_eq!(m3, "illegal character:é");
    assert_eq!((s3, e3), (0, 2));
    expect_err("@", "at symbol");
    expect_err("~", "wave wave symbol");
    expect_err("`", "reverse quotes");
}

// ---------------------------------------------------------------------------
// Unicode Span precision + empty source
// ---------------------------------------------------------------------------

#[test]
fn parity_unicode_span_precision() {
    // Token Spans after a multi-byte prefix (in byte terms — verification of the seed's r107 fix
    // face)
    assert_lex_parity("\"日本語\" 42", "CJK string after integer");
    assert_lex_parity("// 注释 é ü\nx", "many byte comment after identifier");
    assert_lex_parity(
        "\"π\" + 'omega",
        "many byte string after operation and produce command cycle",
    );
    assert_lex_parity(
        "/* ü */ let x = \"→\";",
        "many byte block comment after statement",
    );
}

#[test]
fn parity_empty_and_whitespace() {
    assert_lex_parity("", "empty source(EOF only)");
    assert_lex_parity("   \n\t\r  ", "pure blank");
    assert_lex_parity("\n\n\n", "pure exchange line");
}

// ---------------------------------------------------------------------------
// Parity token-shape spot checks (payload semantic anchors — bridge-side
// same-source parse value equality)
// ---------------------------------------------------------------------------

#[test]
fn parity_payload_value_anchors() {
    // Radix value anchors: 0xFF=255 / 0o17=15 / 0b1011=11 (EOF tail token trimmed)
    let toks = lex_for_parity("0xFF 0o17 0b1011 1_000", 0).unwrap();
    let vals: Vec<&str> = toks
        .iter()
        .take(4)
        .map(|t| t.payload.as_deref().unwrap_or(""))
        .collect();
    assert_eq!(
        vals,
        vec!["255", "15", "11", "1000"],
        "enter make payload value anchor"
    );
    // Float value anchors (f64 textualized — EOF tail token trimmed)
    let toks = lex_for_parity("3.14 1e+5 1e-5", 0).unwrap();
    let vals: Vec<&str> = toks
        .iter()
        .take(3)
        .map(|t| t.payload.as_deref().unwrap_or(""))
        .collect();
    assert_eq!(
        vals,
        vec!["3.14", "100000", "0.00001"],
        "float payload value anchor"
    );
    // Path payload flattening anchor
    let toks = lex_for_parity("a::b::c", 0).unwrap();
    assert_eq!(toks[0].kind, "path");
    assert_eq!(toks[0].payload.as_deref(), Some("a/b/c"));
    assert_eq!((toks[0].start, toks[0].end), (0, 7));
    // Same anchor on the .krf side
    let krf = lex_for_bootstrap("a::b::c", 0).unwrap();
    assert_eq!(krf[0].kind, "path");
    assert_eq!(krf[0].payload.as_deref(), Some("a/b/c"));
    assert_eq!((krf[0].start, krf[0].end), (0, 7));
}

// ---------------------------------------------------------------------------
// Liveness probes (the .krf program runs for real on the VM — non-empty
// results prevent regression)
// ---------------------------------------------------------------------------

#[test]
fn liveness_target_reader_krf_program() {
    // Full-program lexing liveness: token count > threshold (genuine output of the .krf path)
    let src =
        "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(12)";
    let krf = lex_for_bootstrap(src, 0).unwrap();
    assert!(
        krf.len() > 30,
        ".krf lexical liveness(Token count {})",
        krf.len()
    );
    assert_eq!(krf.last().unwrap().kind, "eof");
    assert_eq!(krf.last().unwrap().start, src.len() as u32);
    assert_eq!(krf.last().unwrap().end, src.len() as u32);
    // Spot check of the token shapes before EOF
    assert_eq!(krf[0].kind, "fn");
    assert_eq!(krf[1].kind, "ident");
    assert_eq!(krf[1].payload.as_deref(), Some("fib"));
}

// ---------------------------------------------------------------------------
// ParityToken sequence-semantics spot check (seed-side projection sanity)
// ---------------------------------------------------------------------------

#[test]
fn seed_parity_projection_sanity() {
    let toks: Vec<ParityToken> = lex_for_parity("let x = 0x1F;", 0).unwrap();
    let kinds: Vec<&str> = toks.iter().map(|t| t.kind.as_str()).collect();
    assert_eq!(kinds, vec!["let", "ident", "=", "int", ";", "eof"]);
    assert_eq!(toks[3].payload.as_deref(), Some("31"));
    assert_eq!((toks[3].start, toks[3].end), (8, 12));
}

// ---------------------------------------------------------------------------
// Syntax-layer parity (r108 / 178-c — switch-window step (2) syntax batch)
// ---------------------------------------------------------------------------

use kerf_driver::bootstrap::reader::read_source_for_bootstrap;
use kerf_reader::read_source;
use kerf_syntax::{Stx, StxDatum, StxLiteral, SymbolTable};

/// Stx-tree canonical rendering (symbol names + literal values + Span
/// bytes — comparable across both sides for same-source text).
fn render_stx(s: &Stx, t: &SymbolTable) -> String {
    let mut out = String::new();
    render_stx_into(s, t, &mut out);
    out
}

fn render_stx_into(s: &Stx, t: &SymbolTable, out: &mut String) {
    match &s.datum {
        StxDatum::Symbol(sym) => {
            out.push_str(&format!(
                "(sym {} {}..{})",
                t.name(*sym),
                s.span.start,
                s.span.end
            ));
        }
        StxDatum::Literal(l) => match l {
            StxLiteral::Int(v) => {
                out.push_str(&format!("(int {} {}..{})", v, s.span.start, s.span.end));
            }
            StxLiteral::Float(f) => {
                out.push_str(&format!("(float {:?} {}..{})", f, s.span.start, s.span.end));
            }
            StxLiteral::Str(r) => {
                out.push_str(&format!("(str {:?} {}..{})", r, s.span.start, s.span.end));
            }
            StxLiteral::Bool(b) => {
                out.push_str(&format!("(bool {} {}..{})", b, s.span.start, s.span.end));
            }
            StxLiteral::Nil => {
                out.push_str(&format!("(nil {}..{})", s.span.start, s.span.end));
            }
        },
        StxDatum::List(items) => {
            out.push_str(&format!("(lst {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
        StxDatum::Vector(_) => out.push_str("(vector)"), // the target Reader has no vector
    }
}

/// Syntax-tree parity assertion: both sides' canonical renderings are
/// byte-identical.
fn assert_syntax_parity(src: &str, what: &str) {
    let mut t1 = SymbolTable::new();
    let seed = read_source(src, 0, &mut t1)
        .unwrap_or_else(|e| panic!("[{}] seed syntax failed: {}", what, e.message));
    let mut t2 = SymbolTable::new();
    let krf = read_source_for_bootstrap(src, 0, &mut t2)
        .unwrap_or_else(|e| panic!("[{}] .krf syntax failed:{}", what, e.message));
    let seed_r: Vec<String> = seed.iter().map(|s| render_stx(s, &t1)).collect();
    let krf_r: Vec<String> = krf.iter().map(|s| render_stx(s, &t2)).collect();
    assert_eq!(
        seed.len(),
        krf.len(),
        "[{}] top-level item count mismatch (seed {} vs .krf {})",
        what,
        seed.len(),
        krf.len()
    );
    for (i, (a, b)) in seed_r.iter().zip(krf_r.iter()).enumerate() {
        assert_eq!(
            a, b,
            "[{}] top-level item #{} syntax tree mismatch (seed vs .krf canonical render)",
            what, i
        );
    }
}

/// Syntax-error parity assertion: message + Span byte-level equality.
fn assert_syntax_err_parity(src: &str, what: &str) {
    let mut t1 = SymbolTable::new();
    let seed_err = match read_source(src, 0, &mut t1) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] seed should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    let mut t2 = SymbolTable::new();
    let krf_err = match read_source_for_bootstrap(src, 0, &mut t2) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] .krf should be syntax error(actually parsed successfully)",
            what
        ),
    };
    assert_eq!(
        seed_err.message, krf_err.message,
        "[{}] syntax error message mismatch (seed {:?} vs .krf {:?})",
        what, seed_err.message, krf_err.message
    );
    assert_eq!(
        seed_err.span.start, krf_err.span.start,
        "[{}] syntax error Span start mismatch",
        what
    );
    assert_eq!(
        seed_err.span.end, krf_err.span.end,
        "[{}] syntax error Span end mismatch",
        what
    );
}

// Full-program syntax-tree parity (r106 step (1) corpus-family reuse — deep syntax-level checking)

#[test]
fn syntax_parity_full_programs() {
    assert_syntax_parity(
        "fn add(a: i64, b: i64) -> i64 { a + b }\nadd(2, 3)",
        "fn declaration and call",
    );
    assert_syntax_parity(
        "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(12)",
        "fib recursion",
    );
    assert_syntax_parity(
        "fn f(x: i64) -> i64 { let y = x + 1; let z = y * 2; z + y }",
        "let threading",
    );
    assert_syntax_parity("fn g() -> i64 { let x = 1; x = 5; x }", "assign statement");
    assert_syntax_parity(
        "fn f(a: i64, b: i64, c: i64) -> bool { a + b * c < a * c + b && b < c || c < a }",
        "precedence hierarchy",
    );
    assert_syntax_parity(
        "fn mk(x: i64) -> Fn(i64) -> i64 { || (y: i64) { x + y } }\nmk(10)",
        "closure",
    );
    assert_syntax_parity(
        "module m { fn f(x: i64) -> i64 { x * 2 } }\nm::f(21)",
        "module qualified call",
    );
    assert_syntax_parity(
        "fn count(n: i64) -> i64 { let i = 0; let acc = 0; while!(i < n, acc = acc + i); acc }",
        "macro call name!(...)",
    );
    assert_syntax_parity(
        "fn ask() -> i64 { perform gift(0, 20); }\nhandle ask() { gift(p, k) => resume(tail(p) + head(p)) }",
        "perform/handle effect loop",
    );
}

// Precedence chains and the unary family

#[test]
fn syntax_parity_precedence_chains() {
    assert_syntax_parity(
        "fn f() -> i64 { 1 + 2 - 3 * 4 / 5 % 6 }",
        "four-operation mixed chain",
    );
    assert_syntax_parity("fn f() -> i64 { - - 1 }", "unary negative number chain");
    assert_syntax_parity("fn f() -> i64 { -(1 + 2) }", "parentheses grouping");
    assert_syntax_parity("fn f() -> bool { !true }", "unary logic logic non-");
    assert_syntax_parity("fn f(a: i64, b: i64) -> bool { a != b }", "not etc desugar");
    assert_syntax_parity(
        "fn f(a: i64, b: i64) -> bool { !(a == b) }",
        "non-parentheses compose",
    );
    assert_syntax_parity(
        "fn f(a: i64, b: i64, c: i64) -> bool { a < b && b < c && c < a || a == b }",
        "logic logic chain overlap",
    );
    assert_syntax_parity(
        "fn f() -> i64 { 0x10 + 0o17 + 0b101 + 1_000 }",
        "enter make and partition separate symbol chain",
    );
}

// let threading and block shapes (single reverse algorithm)

#[test]
fn syntax_parity_let_threading() {
    assert_syntax_parity("fn f() -> i64 { }", "empty block nil");
    assert_syntax_parity("fn f() -> i64 { let a = 1; }", "let tail nil threading");
    assert_syntax_parity("fn f() -> i64 { let a = 1; a }", "let + tail expression");
    assert_syntax_parity(
        "fn f() -> i64 { let a = 1; let b = 2; 3 }",
        "dual let threading",
    );
    assert_syntax_parity(
        "fn f() -> i64 { if true { 1 } else { 2 }; 3 }",
        "if statement position",
    );
    assert_syntax_parity(
        "fn f() -> i64 { perform op(1); 2 }",
        "perform statement position",
    );
    assert_syntax_parity(
        "fn f(x: i64) -> i64 { let y = x + 1; let mut z = y * 2; z + y }",
        "mut let stripped",
    );
}

// perform payload cons chains (r108 / 178-b fix face — canonical parameter-order anchor)

#[test]
fn syntax_parity_perform_payloads() {
    assert_syntax_parity("fn f() -> i64 { perform op; }", "perform zero arguments");
    assert_syntax_parity(
        "fn f() -> i64 { perform op(); }",
        "perform unit zero arguments",
    );
    assert_syntax_parity(
        "fn f() -> i64 { perform op(1); }",
        "perform single reference",
    );
    assert_syntax_parity(
        "fn f() -> i64 { perform op(1, 2); }",
        "perform dual reference dotted pair",
    );
    assert_syntax_parity(
        "fn f() -> i64 { perform op(1, 2, 3); }",
        "perform three reference chain",
    );
    assert_syntax_parity(
        "fn f() -> i64 { perform op(1, 2, 3, 4); }",
        "perform four reference chain",
    );
}

#[test]
fn syntax_perform_arg_order_anchor() {
    // Canonical-order anchor: the payload cons chain of a 3/4-argument
    // perform has parameter order = source order (before the r108 fix the
    // seed produced the scrambled order [2,1,3] — this anchor locks the
    // canonical shape independently on both sides)
    for (src, want) in [
        ("fn f() -> i64 { perform op(1, 2, 3); }", vec![1, 2, 3]),
        (
            "fn f() -> i64 { perform op(1, 2, 3, 4); }",
            vec![1, 2, 3, 4],
        ),
    ] {
        let mut t = SymbolTable::new();
        let forms = read_source(src, 0, &mut t)
            .unwrap_or_else(|e| panic!("seed parse failed: {}", e.message));
        let rendered: Vec<String> = forms.iter().map(|s| render_stx(s, &t)).collect();
        // Collect the (int V order from the rendered text (source-order anchor — directly reflects
        // the cons chain's left/right order)
        let text = rendered.join(" ");
        let mut got = Vec::new();
        let mut rest = text.as_str();
        while let Some(p) = rest.find("(int ") {
            rest = &rest[p + 5..];
            let e = rest.find(' ').expect("int value end conclude");
            got.push(rest[..e].parse::<i64>().expect("int value"));
        }
        assert_eq!(
            got, want,
            "perform payload argument order non-canonical(source {})",
            src
        );
    }
}

// handle form family

#[test]
fn syntax_parity_handle_forms() {
    assert_syntax_parity(
        "fn ask() -> i64 { perform gift(0, 20); }\nhandle ask() { gift(p, k) => resume(tail(p) + head(p)) }",
        "handle resume body",
    );
    assert_syntax_parity(
        "fn ask() -> i64 { perform gift(0, 20); }\nhandle ask() { gift(p, k) => { k(p) } }",
        "handle block body",
    );
    assert_syntax_parity(
        "fn ask() -> i64 { perform gift(0, 20); }\nhandle ask() { gift(p, k) => resume(p), }",
        "handle trailing comma tolerance",
    );
}

// Closure form family

#[test]
fn syntax_parity_closures() {
    assert_syntax_parity(
        "fn f() -> i64 { let g = || { 1 }; g() }",
        "no reference closure",
    );
    assert_syntax_parity(
        "fn f() -> i64 { let g = || (a: i64, b: i64) -> E { a + b }; g(1, 2) }",
        "type ize closure",
    );
    assert_syntax_parity(
        "fn f() -> i64 { move || { 1 }() }",
        "move closure prefix stripped",
    );
}

// Type-annotation consumption family (stripped after parsing — lenient recursive descent)

#[test]
fn syntax_parity_type_annotations() {
    assert_syntax_parity("fn f<T>(x: T) -> T { x }", "general type reference");
    assert_syntax_parity(
        "fn f<'a>(x: 'a) -> i64 { 1 }",
        "produce command cycle general type(r108 fix anchor)",
    );
    assert_syntax_parity(
        "fn f<T, U>(x: T) -> U { x }",
        "dual identifier general type",
    );
    assert_syntax_parity(
        "fn f(x: Vec<i64>) -> M(i64) | str { x }",
        "path general type type and effect carry reference and set",
    );
    assert_syntax_parity(
        "fn f(x: (i64, i64)) -> i64 { 1 }",
        "element group type parentheses jump exceeds",
    );
    assert_syntax_parity(
        "fn f(x: (i64) -> i64) -> i64 { 1 }",
        "function type(parentheses atomic + arrow tail effect)",
    );
    assert_syntax_parity("fn f() -> A | B | C { 1 }", "effect and set");
    assert_syntax_parity(
        "fn f() -> A(i64) | B { 1 }",
        "effect carry reference and set",
    );
    assert_syntax_parity(
        "fn g(x: i64, mut y: i64) -> i64 { x + y }",
        "mut argument fix modifier",
    );
}

// module form family

#[test]
fn syntax_parity_modules() {
    assert_syntax_parity(
        "module a { module b { fn f() -> i64 { 1 } } }\na::b::f()",
        "nested module",
    );
    assert_syntax_parity(
        "module m { fn f() -> i64 { 1 } fn g() -> i64 { 2 } }",
        "module many item",
    );
}

// Macro-call form family

#[test]
fn syntax_parity_macro_calls() {
    assert_syntax_parity(
        "fn f(x: i64) -> i64 { set!(x, 5); x }",
        "assign macro reference",
    );
    assert_syntax_parity(
        "fn f() -> i64 { m!(1, x = 2, 3); 4 }",
        "mixed combine macro reference",
    );
}

// if chains and the literal family

#[test]
fn syntax_parity_if_and_literals() {
    assert_syntax_parity(
        "fn f(x: i64) -> i64 { if x < 1 { 1 } else if x < 2 { 2 } else { 3 } }",
        "else if chain",
    );
    assert_syntax_parity("fn f(x: i64) -> i64 { if x { 1 } }", "no else nil arm");
    assert_syntax_parity("fn f() -> str { \"hello\\nworld\" }", "string escape");
    assert_syntax_parity("fn f() -> bool { true }", "bool literal");
    assert_syntax_parity("fn f() -> f64 { 1.5 + 2e3 }", "float literal");
    assert_syntax_parity("fn f() -> () { () }", "unit literal");
    assert_syntax_parity("1_000 + 2_000", "top level expression item");
}

// Expected-error family (message + Span byte-level equality — Tk Debug
// word faces rendered via the bridge)

#[test]
fn syntax_parity_error_expectations() {
    assert_syntax_err_parity("fn 5() -> i64 { 1 }", "function name non-identifier");
    assert_syntax_err_parity("module { }", "module name non-identifier");
    assert_syntax_err_parity("fn f(-> i64) { 1 }", "parameter name non-identifier");
    assert_syntax_err_parity("fn f() -> i64 { let = 1; }", "binding name non-identifier");
    assert_syntax_err_parity("fn f() -> i64 { let x = ; }", "let value non-expression");
    assert_syntax_err_parity("fn f() -> i64 { a b }", "missing; or }");
    assert_syntax_err_parity("fn f() -> i64 {", "block unclosed EOF");
    assert_syntax_err_parity("fn f(a: ) -> i64 { 1 }", "type position non-type");
    assert_syntax_err_parity("fn f() -> 5 { 1 }", "effect container non-identifier");
    assert_syntax_err_parity("fn f() -> i64 { perform 5; }", "effect name non-identifier");
    assert_syntax_err_parity(
        "handle ask() { 5 => resume(1) }",
        "handle arm effect name non-identifier",
    );
    assert_syntax_err_parity(
        "fn f() -> i64 { handle g() { E(a, b, c) => resume(1) } }",
        "handle arm binding ternary",
    );
    assert_syntax_err_parity("fn f() -> i64 { (1 }", "unclosed parenthesis");
}

// Registered out-of-domain diagnostics (byte-level message equality —
// the r106 out-of-domain family extension)

#[test]
fn syntax_parity_domain_out() {
    // r131 / 201-c: the `use` row retired with the legalization — the
    // use-declaration window opened the Level 0 parsing domain (the
    // eleventh skin mapping; the use-family grammar/error parity battery
    // lives in ktf_use_decl_tests.rs — including the D3 member-rename
    // dedicated diagnostic and the D1 single-layer E0019 face).
    assert_syntax_err_parity("pub fn f() {}", "pub fix modifier");
    // r121 / 191-a: the match row retired with the diagnostic — the in-position
    // re-judgment opened the Level 0 parsing domain on the seed side (M-1);
    // r124 / 194-a: the .krf mirror synced (M-4 — the dual-side divergence
    // window closed, the match_m1_reader_tests.rs boundary anchor flipped).
    assert_syntax_err_parity("fn f() -> i64 { 1..5 }", "range operation");
    assert_syntax_err_parity("fn f() -> i64 { 1 |> 2 }", "pipeline");
    assert_syntax_err_parity("fn f() -> i64 { 1 & 2 }", "position and");
    assert_syntax_err_parity("fn f() -> i64 { 1 << 2 }", "left move");
    assert_syntax_err_parity("fn f() -> i64 { 1 as i64 }", "as conversion");
    // r163 / 234-c (index-access-design.md D1): the index row retired with
    // the legalization — the postfix index face opened (the seventeenth
    // skin mapping, `coll[idx]` → `(vector-ref coll idx)`; the r138 D6
    // position discipline superseded); the replacement Stx-parity anchors
    // live in ktf_index_access_tests.rs.
    assert_syntax_err_parity("fn f() -> i64 { 1.x }", "field access");
    assert_syntax_err_parity("struct S { }", "struct declaration");
    assert_syntax_err_parity("effect E { }", "effect declaration");
    assert_syntax_err_parity("capability C { }", "capability declaration");
    assert_syntax_err_parity("fn f() -> i64 { mut x = 1; }", "mut statement position");
    assert_syntax_err_parity(
        "fn f() -> i64 { handle g() { E(p, k) => 1 } }",
        "halt/pass handler body",
    );
}

// Liveness probes (parse-target entry callable + item-count contract)

#[test]
fn liveness_parse_target_krf() {
    let src =
        "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(12)";
    let mut t = SymbolTable::new();
    let forms = read_source_for_bootstrap(src, 0, &mut t)
        .unwrap_or_else(|e| panic!(".krf syntax liveness failed:{}", e.message));
    assert_eq!(forms.len(), 2, "top-level item count(define + call)");
    assert!(
        matches!(&forms[0].datum, StxDatum::List(items) if !items.is_empty()
            && matches!(&items[0].datum, StxDatum::Symbol(_))),
        "first item should be define list form"
    );
}

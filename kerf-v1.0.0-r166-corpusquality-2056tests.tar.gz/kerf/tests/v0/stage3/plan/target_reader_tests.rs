//! Target-syntax reader v1 tests (switching-window step ① — r106 /
//! 176-e/176-f).
//!
//! **Verification surfaces**: ① skin dictionary mapping structural
//! correctness (target face → S-expr face Stx isomorphism); ②
//! **cross-syntax bytecode parity** (the first real instance of
//! SyntaxTransitionValidator — under the same SymbolTable, the compiled
//! artifacts of two syntax sources are identical in instruction sequence/
//! constant pool/proto shapes/global face; debug_spans are not comparable
//! across texts [by design] — explicitly excluded from the comparison
//! domain); ③ behavioral equivalence (end-to-end VM values identical); ④
//! out-of-registered-domain fail-closed diagnostics; ⑤ full lexical layer
//! (radix/escapes/nested comments/`::` paths).
//!
//! Basis: principle 31 (skin/skeleton isomorphism — any surface syntax
//! compiles to the same core form) / 02 §8.13 (EBNF v9 Level 0 parsing
//! specification baseline) / 20 §12 D2 + §14 (skin dictionary) / 07 §3.2.1
//! (seed-segment empirical proof of steps ① and ② of the five-step
//! process).

use kerf_compiler::compile_module;
use kerf_driver::bootstrap::expander::expand_program;
use kerf_driver::bootstrap::read_source;
use kerf_driver::builtins::{register_globals, resolve_hygiene_fallbacks};
use kerf_driver::capability::IoGrant;
use kerf_reader::target::read_target_source;
use kerf_runtime::Heap;
use kerf_syntax::SymbolTable;
use kerf_vm::{run_program, Value};

// ---------------------------------------------------------------------------
// Cross-syntax parity infrastructure (first SyntaxTransitionValidator
// instance)
// ---------------------------------------------------------------------------

/// Structurally compare the semantic payloads of two bytecode programs
/// (instruction sequence + constant pool + proto shapes + global face —
/// `Op` carries no Span/Symbol payload [index-ized], and BcConst/
/// global_refs are normalized through the same SymbolTable and so
/// comparable; debug_spans excluded from the comparison domain —
/// cross-text offsets necessarily differ).
fn assert_same_bytecode(target_src: &str, sexpr_src: &str, what: &str) {
    let mut t = SymbolTable::new();
    let tf = read_target_source(target_src, 0, &mut t)
        .unwrap_or_else(|e| panic!("[{}] target syntax read failed:{}", what, e.message));
    let sf = read_source(sexpr_src, 1, &mut t)
        .unwrap_or_else(|e| panic!("[{}] S expression read failed:{}", what, e.message));
    let tc = expand_program(&tf, 0, &mut t)
        .unwrap_or_else(|e| panic!("[{}] target syntax expand failed:{}", what, e.message));
    let sc = expand_program(&sf, 1, &mut t)
        .unwrap_or_else(|e| panic!("[{}] S expression expand failed:{}", what, e.message));
    let tp = compile_module(&tc)
        .unwrap_or_else(|e| panic!("[{}] target syntax compile failed:{}", what, e.message));
    let sp = compile_module(&sc)
        .unwrap_or_else(|e| panic!("[{}] S expression compile failed:{}", what, e.message));
    assert_eq!(
        tp.protos.len(),
        sp.protos.len(),
        "[{}] prototype count mismatch (cross-syntax parity failed)",
        what
    );
    for (i, (a, b)) in tp.protos.iter().zip(sp.protos.iter()).enumerate() {
        assert_eq!(
            a.code, b.code,
            "[{}] prototype {} instruction sequence mismatch",
            what, i
        );
        assert_eq!(
            a.params.len(),
            b.params.len(),
            "[{}] prototype {} argument count",
            what,
            i
        );
        assert_eq!(
            a.n_locals, b.n_locals,
            "[{}] prototype {} local slot count",
            what, i
        );
        assert_eq!(
            a.capture_names.len(),
            b.capture_names.len(),
            "[{}] prototype {} capture count",
            what,
            i
        );
    }
    assert_eq!(tp.consts, sp.consts, "[{}] constant pool mismatch", what);
    assert_eq!(
        tp.global_refs, sp.global_refs,
        "[{}] global reference face mismatch",
        what
    );
}

/// Behavioral equivalence: the two syntax sources' end-to-end VM execution
/// values are identical (including hygiene fallback resolution — a mirror
/// of the production pipeline steps).
fn assert_same_value(target_src: &str, sexpr_src: &str, what: &str) {
    let mut t = SymbolTable::new();
    let tf = read_target_source(target_src, 0, &mut t)
        .unwrap_or_else(|e| panic!("[{}] target syntax read failed:{}", what, e.message));
    let sf = read_source(sexpr_src, 1, &mut t)
        .unwrap_or_else(|e| panic!("[{}] S expression read failed:{}", what, e.message));
    let tc = expand_program(&tf, 0, &mut t)
        .unwrap_or_else(|e| panic!("[{}] target syntax expand failed:{}", what, e.message));
    let sc = expand_program(&sf, 1, &mut t)
        .unwrap_or_else(|e| panic!("[{}] S expression expand failed:{}", what, e.message));
    let tp = compile_module(&tc)
        .unwrap_or_else(|e| panic!("[{}] target syntax compile failed:{}", what, e.message));
    let sp = compile_module(&sc)
        .unwrap_or_else(|e| panic!("[{}] S expression compile failed:{}", what, e.message));
    let mut g1 = register_globals(&mut t, &IoGrant::none());
    resolve_hygiene_fallbacks(&tp, &mut t, &mut g1);
    let mut h1 = Heap::new();
    let v1 = run_program(&tp, &mut g1, &mut h1)
        .unwrap_or_else(|e| panic!("[{}] target syntax execution failed:{}", what, e.message));
    let mut g2 = register_globals(&mut t, &IoGrant::none());
    resolve_hygiene_fallbacks(&sp, &mut t, &mut g2);
    let mut h2 = Heap::new();
    let v2 = run_program(&sp, &mut g2, &mut h2)
        .unwrap_or_else(|e| panic!("[{}] S expression execution failed:{}", what, e.message));
    assert!(
        v1.eq_value(&v2),
        "[{}] line is mismatch: {:?} vs {:?}",
        what,
        kerf_vm::render_value(&v1, &h1),
        kerf_vm::render_value(&v2, &h2)
    );
}

// ---------------------------------------------------------------------------
// Cross-syntax bytecode parity (machine verification of principle 31 —
// D2 six mappings + expression face)
// ---------------------------------------------------------------------------

#[test]
fn parity_fn_decl_and_call() {
    // D2 define→fn: type/effect signatures parsed then stripped
    assert_same_bytecode(
        "fn add(a: i64, b: i64) -> i64 { a + b }\nadd(2, 3)",
        "(define (add a b) (+ a b)) (add 2 3)",
        "fn declaration and call",
    );
    // Recursion + if/else
    assert_same_bytecode(
        "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(12)",
        "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (fib 12)",
        "fib recursion",
    );
}

#[test]
fn parity_let_stmt_threading() {
    // D2 let→let: let scope threading (covering the rest) + tail expression
    assert_same_bytecode(
        "fn f(x: i64) -> i64 { let y = x + 1; let z = y * 2; z + y }",
        "(define (f x) (let ((y (+ x 1))) (let ((z (* y 2))) (+ z y))))",
        "let threading",
    );
    // Non-expression statements (assign) mixed with let: nested do and flat do desugar isomorphically
    assert_same_bytecode(
        "fn g() -> i64 { let x = 1; x = 5; x }",
        "(define (g) (let ((x 1)) (do (assign x 5) x)))",
        "assign statement",
    );
}

#[test]
fn parity_operators_precedence() {
    // Fourteen-level precedence subset: mul/div > add/sub > comparison > logical and > logical or
    assert_same_bytecode(
        "fn f(a: i64, b: i64, c: i64) -> bool { a + b * c < a * c + b && b < c || c < a }",
        "(define (f a b c) (or (and (< (+ a (* b c)) (+ (* a c) b)) (< b c)) (< c a)))",
        "precedence hierarchy",
    );
    // Unary negation and parenthesized grouping
    assert_same_bytecode(
        "fn f(a: i64) -> i64 { -(a + 2) * 3 }",
        "(define (f a) (* (- (+ a 2)) 3))",
        "unary and grouping",
    );
    // Comparisons are non-chaining (level 10) + != expansion
    assert_same_value(
        "fn f(a: i64, b: i64) -> bool { a != b }\nf(3, 4)",
        "(define (f a b) (not (= a b))) (f 3 4)",
        "not etc expand",
    );
}

#[test]
fn parity_closure_expr() {
    // D2 lambda→closure reverse: || closure → (fn ...) capture
    assert_same_bytecode(
        "fn mk(x: i64) -> Fn(i64) -> i64 { || (y: i64) { x + y } }\nmk(10)",
        "(define (mk x) (fn (y) (+ x y))) (mk 10)",
        "closure",
    );
    // proc values have reference semantics (not comparable via eq_value) — closures covered by structural parity + the call surface
}

#[test]
fn parity_unit_bool_string_literals() {
    // C12: () ≡ nil; bool/string literals; radix literals (0x/0o/0b)
    assert_same_value(
        "fn f() -> () { () }\nif (true) { 0x1F } else { 0o17 }",
        "(define (f) nil) (if true 31 15)",
        "literal family",
    );
    assert_same_value(
        "fn f() -> i64 { 0b1011 + 0o17 }\nf()",
        "(define (f) (+ 11 15)) (f)",
        "enter make literal",
    );
}

#[test]
fn parity_perform_handle() {
    // D2 perform→perform / handle→handle: effect value (cons 'gift (cons 0 20))
    // and single-arm handler + resume mapping
    assert_same_value(
        concat!(
            "fn ask() -> i64 { perform gift(0, 20); }\n",
            "fn guarded() -> i64 { handle ask() { gift(p, k) => resume(tail(p) + head(p)) } }\n",
            "guarded()"
        ),
        concat!(
            "(define (ask) (perform (cons 'gift (cons 0 20))))\n",
            "(define (guarded) (handle gift ((p k) (resume k (+ (tail p) (head p)))) (ask)))\n",
            "(guarded)"
        ),
        "perform/handle effect loop",
    );
}

#[test]
fn parity_module_decl() {
    assert_same_bytecode(
        "module m { fn f(x: i64) -> i64 { x * 2 } }\nm::f(21)",
        "(module m (define (f x) (* x 2))) (m/f 21)",
        "module and qualified call",
    );
}

#[test]
fn parity_macro_invocation_bang() {
    // 20 §14: macro invocation explicitly marked name!(...) → (name ...) — derived macro while!
    assert_same_bytecode(
        "fn count(n: i64) -> i64 { let i = 0; let acc = 0; while!(i < n, acc = acc + i); acc }",
        "(define (count n) (let ((i 0)) (let ((acc 0)) (do (while (< i n) (assign acc (+ acc i))) acc))))",
        "while! macro call",
    );
}

// ---------------------------------------------------------------------------
// Full lexical layer (EBNF v9 Rust minimal set completion)
// ---------------------------------------------------------------------------

#[test]
fn lexer_radix_escape_nested_comments() {
    // Nested block comments + line comments + string escapes + radix
    let src = concat!(
        "// line comment\n",
        "/* outer /* nested */ continue */\n",
        "fn f() -> str { \"a\\tb\\n\\\\\\\"quote\" }\n",
        "f()"
    );
    let mut t = SymbolTable::new();
    let forms = read_target_source(src, 0, &mut t)
        .unwrap_or_else(|e| panic!("lexical read failed:{}", e.message));
    let core =
        expand_program(&forms, 0, &mut t).unwrap_or_else(|e| panic!("expand failed:{}", e.message));
    let program = compile_module(&core).expect("compile failed");
    let mut g = register_globals(&mut t, &IoGrant::none());
    resolve_hygiene_fallbacks(&program, &mut t, &mut g);
    let mut h = Heap::new();
    let v = run_program(&program, &mut g, &mut h).expect("execution failed");
    let rendered = kerf_vm::render_value(&v, &h);
    assert!(
        rendered.contains("a\tb\n\\\"quote"),
        "string escape round trip fail true: {}",
        rendered
    );
}

#[test]
fn lexer_unterminated_diagnostics() {
    let mut t = SymbolTable::new();
    let e = read_target_source("fn f() -> i64 { \"abc", 0, &mut t).unwrap_err();
    assert!(
        e.message.contains("unclosed"),
        "unclosed string diagnostic: {}",
        e.message
    );
    let e2 = read_target_source("/* unclosed", 0, &mut t).unwrap_err();
    assert!(
        e2.message.contains("unclosed"),
        "unclosed block comment diagnostic: {}",
        e2.message
    );
}

// ---------------------------------------------------------------------------
// Out-of-registered-domain fail-closed (inside EBNF v9 Level 0 · outside
// the kernel consumption domain)
// ---------------------------------------------------------------------------

#[test]
fn domain_out_diagnostics() {
    let cases: &[(&str, &str)] = &[
        // r131 / 201-c: the `use` row retires with the legalization — the
        // use-declaration window opened the Level 0 parsing domain (the
        // eleventh skin mapping — ktf_use_decl_tests.rs carries the new
        // grammar family; the multi-segment path shape moves to the D1
        // single-layer E0019 compile-time face).
        // r121 / 191-a: the match row retires with the diagnostic — the
        // in-position re-judgment opened the Level 0 parsing domain (M-1,
        // match_m1_reader_tests.rs carries the new grammar family).
        ("fn f() -> i64 { 1..5 }", "span"),
        ("fn f() -> i64 { 1 |> 2 }", "pipeline"),
        ("fn f() -> i64 { 1 & 2 }", "bitwise"),
        ("fn f() -> i64 { 1 as i64 }", "as conversion"),
        ("struct S { }", "type declaration"),
        ("effect E { }", "effect declaration"),
        ("capability C { }", "capability declaration"),
    ];
    for (src, what) in cases {
        let mut t = SymbolTable::new();
        let e = read_target_source(src, 0, &mut t).expect_err(&format!(
            "[{}] should be registration out of domain diagnostic(actually parsed successfully)",
            what
        ));
        assert!(
            e.message.contains("registration out of domain"),
            "[{}] diagnostic face fail true: {}",
            what,
            e.message
        );
    }
}

// ---------------------------------------------------------------------------
// Value-level spot checks (end-to-end behavior of the skin dictionary
// mapping)
// ---------------------------------------------------------------------------

#[test]
fn behavior_target_program_fib() {
    // Target-syntax fib end to end: 75025 (fib 25 = 75025 — same value as the CLI anchor)
    let mut t = SymbolTable::new();
    let src =
        "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(25)";
    let forms =
        read_target_source(src, 0, &mut t).unwrap_or_else(|e| panic!("read failed:{}", e.message));
    let core =
        expand_program(&forms, 0, &mut t).unwrap_or_else(|e| panic!("expand failed:{}", e.message));
    let program = compile_module(&core).expect("compile failed");
    let mut g = register_globals(&mut t, &IoGrant::none());
    resolve_hygiene_fallbacks(&program, &mut t, &mut g);
    let mut h = Heap::new();
    let v = run_program(&program, &mut g, &mut h).expect("execution failed");
    assert_eq!(v, Value::Int(75025), "target syntax fib(25) value");
}

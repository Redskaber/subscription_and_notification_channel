//! .ktf tuple-expression family tests — r160 / 230-c (the TD-036 window:
//! the binary pair construction's modern face — tuple-expression-design
//! v1.0, the fifteenth skin mapping).
//!
//! **Verification surfaces** (the `(a, b)` primary-position tuple parses
//! to the Stx `(cons a b)` — as-if-written `cons(a, b)`: skin swap,
//! skeleton identical, principle 31; zero core/expander/compiler/HM/VM
//! mechanism change — the cons registration chain is fully pre-existing;
//! 8 primitives' invariance round 42; design single source =
//! tuple-expression-design.md v1.0):
//! (1) **run-face E2E** — the construction/deconstruction symmetry closes
//! (the r159-baseline gap: `match (1, 2) { (a, b) => ... }` was E0001
//! fail-closed at the scrutinee while the pattern face could destructure
//! — the expression-position dual was missing, TD-036);
//! (2) **grammar settlement** — dual-Reader canonical Stx rendering
//! byte-identical (seed parse_primary LParen comma arm vs mirror
//! parse_tuple_tail — Span bytes included per the D10 contract: the
//! synthesized cons head carries the `(` token's span), error faces
//! message + Span byte-identical (the arity-cap / trailing-comma
//! dedicated diagnostics + the natural expression-expectation family);
//! (3) **cross-stage consumption** — the tuple program through
//! `check_source_recover` stays diagnostic-clean (HM consumes the
//! pre-existing cons `(Any, Any) → Pair` signature);
//! (4) **fail-closed negatives** — arity shapes (3+/4-tuple cap /
//! trailing comma / leading comma / double comma / EOF ×3) / domain
//! errors (head/tail on non-pair — E0004) / E0022 unbound elements ×3 /
//! E0005 static Pair≠Num family (plus / ordering / if-condition) /
//! E0006 undeclared capability inside a tuple / E0014 qualified-path
//! element / the pattern face's own arity regression anchor — 6 of the
//! 7 error classes covered (E0002 has no natural tuple face — honestly
//! declared, design §2 D10).
//!
//! Skin-dictionary basis: 20 §14 (the tuple row: `(a, b)` ↔ `(cons a b)`
//! — this window); 02 §8.13.1a (primary_expr → tuple_expr — D1).
//! Window basis: user instruction ① (the data-structure S-expr-era
//! residual audit — the TD-036 trigger condition ① direct opening) +
//! tuple-expression-design.md v1.0 D1-D10. Ratio: 8 positive : 24
//! negative = 1:3 (§9.4.3).

use kerf_compiler::compile_module;
use kerf_driver::bootstrap::reader::read_source_for_bootstrap;
use kerf_driver::{check_source_recover, run_source, Stage};
use kerf_expander::{expand_program as expand_program_seed, ExpandCtxt};
use kerf_reader::reader::read_source;
use kerf_syntax::{Stx, StxDatum, StxLiteral, SymbolTable};

// ---------------------------------------------------------------------------
// Value helpers
// ---------------------------------------------------------------------------

fn run_value(src: &str, filename: &str) -> String {
    let outcome = run_source(src, filename)
        .unwrap_or_else(|e| panic!("target face program {} execution failed:{}", filename, e));
    kerf_vm::render_value(&outcome.value, &outcome.heap)
}

fn read_err(src: &str, filename: &str) -> kerf_reader::reader::ReadError {
    let mut sm = kerf_span::SourceMap::new();
    let fid = sm.add_file(filename, src);
    let mut table = SymbolTable::new();
    read_source(src, fid, &mut table)
        .err()
        .unwrap_or_else(|| panic!("[{}] expected a read error, parsed successfully", filename))
}

// ---------------------------------------------------------------------------
// Dual-Reader parity helpers (the ktf_percent_operator_tests caliber —
// canonical rendering with Span bytes; error parity with message + Span
// byte equality)
// ---------------------------------------------------------------------------

fn render_stx(s: &Stx, t: &SymbolTable) -> String {
    let mut out = String::new();
    render_stx_into(s, t, &mut out);
    out
}

fn render_stx_into(s: &Stx, t: &SymbolTable, out: &mut String) {
    match &s.datum {
        StxDatum::Symbol(sym) => {
            out.push_str(&format!(
                "(sym {} {}..{})",
                t.name(*sym),
                s.span.start,
                s.span.end
            ));
        }
        StxDatum::Literal(l) => match l {
            StxLiteral::Int(v) => {
                out.push_str(&format!("(int {} {}..{})", v, s.span.start, s.span.end));
            }
            StxLiteral::Float(f) => {
                out.push_str(&format!("(float {:?} {}..{})", f, s.span.start, s.span.end));
            }
            StxLiteral::Str(r) => {
                out.push_str(&format!("(str {:?} {}..{})", r, s.span.start, s.span.end));
            }
            StxLiteral::Bool(b) => {
                out.push_str(&format!("(bool {} {}..{})", b, s.span.start, s.span.end));
            }
            StxLiteral::Nil => {
                out.push_str(&format!("(unit {}..{})", s.span.start, s.span.end));
            }
        },
        StxDatum::List(items) => {
            out.push_str(&format!("(lst {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
        StxDatum::Vector(items) => {
            out.push_str(&format!("(vec {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
    }
}

/// Grammar parity assertion: both Readers' canonical renderings are
/// byte-identical (the tuple form is seed/mirror isomorphic by
/// construction — the same `(cons a b)` list behind both faces, Span
/// bytes included per the D10 contract).
fn assert_grammar_parity(src: &str, what: &str) {
    let mut t1 = SymbolTable::new();
    let seed = read_source(src, 0, &mut t1)
        .unwrap_or_else(|e| panic!("[{}] seed syntax failed: {}", what, e.message));
    let mut t2 = SymbolTable::new();
    let mirror = read_source_for_bootstrap(src, 0, &mut t2)
        .unwrap_or_else(|e| panic!("[{}] mirror syntax failed:{}", what, e.message));
    assert_eq!(
        seed.len(),
        mirror.len(),
        "[{}] top-level item count mismatch (seed {} vs mirror {})",
        what,
        seed.len(),
        mirror.len()
    );
    for (i, (a, b)) in seed.iter().zip(mirror.iter()).enumerate() {
        assert_eq!(
            render_stx(a, &t1),
            render_stx(b, &t2),
            "[{}] top-level item #{} syntax tree mismatch (seed vs mirror canonical render)",
            what,
            i
        );
    }
}

/// Grammar-error parity assertion: message + Span byte-level equality
/// (the mirror's diagnostic face is the seed's, by construction — the
/// arity-cap / trailing-comma / natural families are anchored in both
/// Readers). Returns the seed's error for downstream message checks.
fn assert_grammar_err_parity(src: &str, what: &str) -> kerf_reader::reader::ReadError {
    let mut t1 = SymbolTable::new();
    let seed_err = match read_source(src, 0, &mut t1) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] seed should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    let mut t2 = SymbolTable::new();
    let mirror_err = match read_source_for_bootstrap(src, 0, &mut t2) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] mirror should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    assert_eq!(
        seed_err.message, mirror_err.message,
        "[{}] syntax error message mismatch (seed {:?} vs mirror {:?})",
        what, seed_err.message, mirror_err.message
    );
    assert_eq!(
        seed_err.span.start, mirror_err.span.start,
        "[{}] syntax error Span start mismatch (seed {} vs mirror {})",
        what, seed_err.span.start, mirror_err.span.start
    );
    assert_eq!(
        seed_err.span.end, mirror_err.span.end,
        "[{}] syntax error Span end mismatch (seed {} vs mirror {})",
        what, seed_err.span.end, mirror_err.span.end
    );
    seed_err
}

// ---------------------------------------------------------------------------
// Bytecode equivalence helper (the as-if-written gate — r133-caliber:
// the cross-text comparison domain is the bytecode payload, spans
// excluded per the r106 discipline)
// ---------------------------------------------------------------------------

fn strip_span_annotations(disasm: &str) -> String {
    disasm
        .lines()
        .map(|l| match l.find("        ; span ") {
            Some(i) => &l[..i],
            None => l,
        })
        .collect::<Vec<_>>()
        .join("\n")
}

fn compile_disasm_strip_spans(src: &str, what: &str) -> String {
    let mut table = SymbolTable::new();
    let forms = read_source(src, 0, &mut table)
        .unwrap_or_else(|e| panic!("[{}] parse failed: {}", what, e.message));
    let mut ectx = ExpandCtxt::new(table);
    let core = expand_program_seed(&forms, &mut ectx)
        .unwrap_or_else(|e| panic!("[{}] expansion failed:{}", what, e.message));
    let program = compile_module(&core)
        .unwrap_or_else(|e| panic!("[{}] compile failed: {}", what, e.message));
    // The compiler's sentinel proto names (u32::MAX-1/2 → <main>/<fn>)
    // are not table-resolvable — the multiarm test's table_name caliber.
    let text = kerf_compiler::disassemble_program(&program, &|s: kerf_syntax::Symbol| match s.0 {
        x if x == u32::MAX - 1 => "<main>".to_string(),
        x if x == u32::MAX - 2 => "<fn>".to_string(),
        _ => ectx.table.name(s).to_string(),
    });
    strip_span_annotations(&text)
}

// ---------------------------------------------------------------------------
// Positives — run-face E2E + grammar settlement + equivalence + cross-stage
// ---------------------------------------------------------------------------

/// Positive 1 / integration: the core E2E — the r159-baseline gap closed
/// (`(1, 2)` was E0001 fail-closed; the tuple face now constructs the
/// pair through the full run chain — the as-if-written cons application).
#[test]
fn pos_core_e2e_pair_construction() {
    assert_eq!(run_value("(1, 2)", "tup_core.ktf"), "(1 . 2)");
    assert_eq!(run_value("head((40, 2))", "tup_head.ktf"), "40");
    assert_eq!(run_value("tail((40, 2))", "tup_tail.ktf"), "2");
    assert_eq!(run_value(r#"("a", "b")"#, "tup_str.ktf"), "(a . b)");
}

/// Positive 2 / integration: the construction/deconstruction symmetry —
/// the TD-036 gap's essence. `match (a, b) { (p, q) => ... }` round-trips
/// (the scrutinee's modern construction face feeds the pattern's modern
/// destructuring face — one idiom, no cons call form in sight).
#[test]
fn pos_construction_destructuring_symmetry() {
    assert_eq!(
        run_value("match (1, 2) { (a, b) => a + b, _ => 0 }", "tup_sym.ktf"),
        "3"
    );
    assert_eq!(
        run_value(
            "match ((1, 2), 3) { ((a, b), c) => a + b + c, _ => 0 }",
            "tup_sym_nested.ktf"
        ),
        "6"
    );
    assert_eq!(
        run_value(
            "match (5, 5) { (a, b) if a == b => 100, _ => 0 }",
            "tup_sym_guard.ktf"
        ),
        "100"
    );
}

/// Positive 3 / integration (the as-if-written bytecode gate — the r133
/// caliber): `(1, 2)` compiles byte-identically to `cons(1, 2)` (skin
/// transparency: both faces produce the same application product —
/// instruction order + constant pool + proto shapes; spans excluded per
/// the r106 discipline).
#[test]
fn pos_as_if_written_bytecode_equivalence() {
    assert_eq!(
        compile_disasm_strip_spans("(1, 2)", "tup_eq_simple.ktf"),
        compile_disasm_strip_spans("cons(1, 2)", "tup_eq_call.ktf"),
        "the tuple and the call form must compile identically"
    );
    assert_eq!(
        compile_disasm_strip_spans("(1, (2, 3))", "tup_eq_nest.ktf"),
        compile_disasm_strip_spans("cons(1, cons(2, 3))", "tup_eq_nest_call.ktf"),
        "the nested tuple and the nested call form must compile identically"
    );
}

/// Positive 4: the full position domain — let value / call argument /
/// if value arm / nested tuple / statement position / closure body /
/// handle protected (the r143 five-position-form precedent caliber).
#[test]
fn pos_position_forms_full_domain() {
    assert_eq!(run_value("let p = (1, 2); head(p)", "tup_pos_let.ktf"), "1");
    assert_eq!(
        run_value(
            "fn first(p: T) { head(p) }\nfirst((7, 8))",
            "tup_pos_arg.ktf"
        ),
        "7"
    );
    assert_eq!(
        run_value(
            "let t = if true { (1, 2) } else { (3, 4) }; tail(t)",
            "tup_pos_if.ktf"
        ),
        "2"
    );
    assert_eq!(
        run_value("tail((1, (2, 3)))", "tup_pos_nested.ktf"),
        "(2 . 3)"
    );
    assert_eq!(run_value("(1, 2); 42", "tup_pos_stmt.ktf"), "42");
    assert_eq!(
        run_value("let f = || { (9, 8) }; head(f())", "tup_pos_closure.ktf"),
        "9"
    );
    assert_eq!(
        run_value(
            "handle (40, 2) { gift(p, k) => resume(0) }",
            "tup_pos_handle.ktf"
        ),
        "(40 . 2)"
    );
}

/// Positive 5: grammar settlement — dual-Reader canonical rendering
/// parity (the family's shapes: simple / nested / call-mixed operands /
/// operator operands / statement / let-bound, byte-identical including
/// the synthesized cons nodes and their Span bytes per the D10
/// contract).
#[test]
fn pos_dual_reader_canonical_parity() {
    assert_grammar_parity("(1, 2)", "simple tuple");
    assert_grammar_parity("((1, 2), 3)", "nested tuple left");
    assert_grammar_parity("(1, (2, 3))", "nested tuple right");
    assert_grammar_parity("(1 + 2, 3 * 4)", "operator operands");
    assert_grammar_parity("(f(1), g(2, 3))", "call operands");
    assert_grammar_parity("let p = (a, b); p", "let-bound tuple");
    assert_grammar_parity("(1, 2); 42", "statement tuple");
}

/// Positive 6: cross-stage consumption — the tuple program through
/// `check_source_recover` stays diagnostic-clean (HM/check consume the
/// pre-existing cons signature — zero registration-chain increments,
/// design D6).
#[test]
fn pos_check_cross_stage_consumption() {
    let src =
        "fn fst(p: T) { head(p) }\nfn snd(p: T) { tail(p) }\nlet p = (1, 2);\nfst(p) + snd(p)";
    let r = check_source_recover(src, "tup_check.ktf").unwrap();
    assert!(
        r.diagnostics.is_empty(),
        "check must stay diagnostic-clean (actual: {:?})",
        r.diagnostics
    );
}

/// Positive 7: the grouping/unit zero-regression face — `(e)` stays pure
/// grouping, `()` stays the unit literal, and call-argument commas are
/// unaffected by the primary-position tuple arm (the lexical ambiguity
/// resolved by syntactic position — the pre-existing discipline).
#[test]
fn pos_grouping_and_unit_regression() {
    assert_eq!(run_value("(1 + 2) * 3", "tup_group.ktf"), "9");
    assert_eq!(run_value("((5))", "tup_group_nested.ktf"), "5");
    assert_eq!(run_value("is_nil(())", "tup_unit.ktf"), "true");
    assert_eq!(
        run_value(
            "fn f(x: T, y: T) { x + y }\nf((1), 2)",
            "tup_call_group.ktf"
        ),
        "3"
    );
}

/// Positive 8 / integration: the corpus-migration value parity — the
/// migrated faces (match.ktf `describe((1, 9))` + the gc-stress pair
/// churn) behave identically to their cons-call predecessors (skin
/// swap, skeleton unchanged — D8).
#[test]
fn pos_corpus_migration_value_parity() {
    let describe = "fn describe(p: T) {\n    match p {\n        (a, b) if a == b => \"pair-eq\",\n        ((0 | 1), c) => \"head-zero-or-one\",\n        _ => \"other\",\n    }\n}\ndescribe((1, 9))";
    assert_eq!(run_value(describe, "tup_mig_match.ktf"), "head-zero-or-one");
    let describe_other = "fn describe(p: T) {\n    match p {\n        (a, b) if a == b => \"pair-eq\",\n        ((0 | 1), c) => \"head-zero-or-one\",\n        _ => \"other\",\n    }\n}\ndescribe((2, 9))";
    assert_eq!(
        run_value(describe_other, "tup_mig_match_other.ktf"),
        "other"
    );
    let describe_eq = "fn describe(p: T) {\n    match p {\n        (a, b) if a == b => \"pair-eq\",\n        ((0 | 1), c) => \"head-zero-or-one\",\n        _ => \"other\",\n    }\n}\ndescribe((9, 9))";
    assert_eq!(run_value(describe_eq, "tup_mig_match_eq.ktf"), "pair-eq");
    let churn =
        "fn churn(n: i64) -> i64 { if n == 0 { 0 } else { (n, n + 1); churn(n - 1) } }\nchurn(4)";
    assert_eq!(run_value(churn, "tup_mig_churn.ktf"), "0");
}

// ---------------------------------------------------------------------------
// Negatives — arity shapes / domains / unbound / static / capability / path
// ---------------------------------------------------------------------------

/// Negative 1 (E0001 arity class): the binary cap — a 3-tuple is
/// rejected with the dedicated diagnostic (D2 — the symmetric
/// discipline with the pattern face's own cap).
#[test]
fn neg_arity_cap_three_elements() {
    let e = read_err("let x = (1, 2, 3); x", "tup_cap3.ktf");
    assert!(
        e.message
            .contains("at most two elements in a tuple expression"),
        "the arity-cap diagnostic (actual: {})",
        e.message
    );
}

/// Negative 2 (E0001 arity class): the cap fires at the second comma —
/// a 4-tuple reports the same single diagnostic (not a cascade).
#[test]
fn neg_arity_cap_four_elements() {
    let e = read_err("let x = (1, 2, 3, 4); x", "tup_cap4.ktf");
    assert!(
        e.message
            .contains("at most two elements in a tuple expression"),
        "the arity-cap diagnostic (actual: {})",
        e.message
    );
}

/// Negative 3 (E0001 shape class): the trailing comma `(a,)` — the r138
/// vector-literal discipline (fail-closed, dedicated message).
#[test]
fn neg_trailing_comma_fail_closed() {
    let e = read_err("let x = (1,); x", "tup_trail.ktf");
    assert!(
        e.message.contains("tuple literal trailing comma illegal"),
        "the trailing-comma diagnostic (actual: {})",
        e.message
    );
    assert!(
        e.message.contains("expected an expression"),
        "the trailing-comma hint (actual: {})",
        e.message
    );
}

/// Negative 4 (E0001 natural class): the leading comma `(, 1)` — the
/// first element's parse_expr fails on the expression-expectation face
/// (no dedicated message needed — the natural face is face-isomorphic).
#[test]
fn neg_leading_comma_natural_face() {
    let e = read_err("(, 1)", "tup_lead.ktf");
    assert!(
        e.message.contains("expected an expression, got Comma"),
        "the natural expression-expectation face (actual: {})",
        e.message
    );
}

/// Negative 5 (E0001 natural class): the double comma `(1, , 2)` — the
/// second element's parse_expr fails on the same natural face.
#[test]
fn neg_double_comma_natural_face() {
    let e = read_err("(1, , 2)", "tup_dbl.ktf");
    assert!(
        e.message.contains("expected an expression, got Comma"),
        "the natural expression-expectation face (actual: {})",
        e.message
    );
}

/// Negative 6 (E0001 EOF class): `(1` — the deferred `)` expectation
/// renders the eof message.
#[test]
fn neg_eof_after_first_element() {
    let e = read_err("(1", "tup_eof1.ktf");
    assert!(
        e.message.contains("expected ), got Eof"),
        "the eof expectation face (actual: {})",
        e.message
    );
}

/// Negative 7 (E0001 EOF class): `(1,` — the trailing comma at eof hits
/// the dedicated trailing-comma branch (the eof is in the peek set).
#[test]
fn neg_eof_after_comma() {
    let e = read_err("(1,", "tup_eof2.ktf");
    assert!(
        e.message.contains("tuple literal trailing comma illegal"),
        "the trailing-comma-at-eof face (actual: {})",
        e.message
    );
}

/// Negative 8 (E0001 EOF class): `(1, 2` — the second element parses,
/// the deferred `)` expectation renders the eof message.
#[test]
fn neg_eof_after_second_element() {
    let e = read_err("(1, 2", "tup_eof3.ktf");
    assert!(
        e.message.contains("expected ), got Eof"),
        "the eof expectation face (actual: {})",
        e.message
    );
}

/// Negative 9 (E0022 unbound class): an unbound lhs element.
#[test]
fn neg_e0022_unbound_lhs() {
    let err = run_source("let x = (y, 2); x", "tup_unb_lhs.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Compile);
    assert!(
        err.diagnostic.message.contains("unbound reference: `y`"),
        "the lhs element is the reported name (actual: {})",
        err.diagnostic.message
    );
}

/// Negative 10 (E0022 unbound class): an unbound rhs element.
#[test]
fn neg_e0022_unbound_rhs() {
    let err = run_source("let x = (1, z); x", "tup_unb_rhs.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Compile);
    assert!(
        err.diagnostic.message.contains("unbound reference: `z`"),
        "the rhs element is the reported name (actual: {})",
        err.diagnostic.message
    );
}

/// Negative 11 (E0022 unbound class): an unbound element inside the
/// nested tuple slot.
#[test]
fn neg_e0022_unbound_nested() {
    let err = run_source("let x = (1, (2, w)); x", "tup_unb_nest.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Compile);
    assert!(
        err.diagnostic.message.contains("unbound reference: `w`"),
        "the nested element is the reported name (actual: {})",
        err.diagnostic.message
    );
}

/// Negative 12 (E0005 static class): `1 + (2, 3)` — the HM face knows
/// the cons product is a Pair; the plus operand check fires statically
/// through the recovery-mode check (the percent-test caliber).
#[test]
fn neg_e0005_plus_operand_static() {
    let report = check_source_recover("1 + (2, 3)", "tup_e5_plus.ktf")
        .expect("recovery path should produce a report (not a hard error)");
    assert!(
        report
            .diagnostics
            .iter()
            .any(|d| d.code == Some(kerf_span::DiagnosticCode(5))),
        "the plus operand static face must surface (actual: {:?})",
        report.diagnostics
    );
    assert!(
        report
            .diagnostics
            .iter()
            .any(|d| d.message.contains("+ requires a number")),
        "the plus operand diagnostic (actual: {:?})",
        report.diagnostics
    );
}

/// Negative 13 (E0005 static class): the ordering face — `(1, 2) < (3, 4)`
/// is the same Pair≠Num static family (recovery-mode check).
#[test]
fn neg_e0005_ordering_operand_static() {
    let report = check_source_recover("(1, 2) < (3, 4)", "tup_e5_lt.ktf")
        .expect("recovery path should produce a report (not a hard error)");
    assert!(
        report
            .diagnostics
            .iter()
            .any(|d| d.code == Some(kerf_span::DiagnosticCode(5))),
        "the ordering operand static face must surface (actual: {:?})",
        report.diagnostics
    );
    assert!(
        report
            .diagnostics
            .iter()
            .any(|d| d.message.contains("< requires a number")),
        "the ordering operand diagnostic (actual: {:?})",
        report.diagnostics
    );
}

/// Negative 14 (E0005 static class): the if-condition face — a tuple in
/// condition position is the Pair≠Bool static family (recovery-mode
/// check).
#[test]
fn neg_e0005_if_condition_static() {
    let report = check_source_recover("if (1, 2) { 3 } else { 4 }", "tup_e5_if.ktf")
        .expect("recovery path should produce a report (not a hard error)");
    assert!(
        report
            .diagnostics
            .iter()
            .any(|d| d.code == Some(kerf_span::DiagnosticCode(5))),
        "the if-condition static face must surface (actual: {:?})",
        report.diagnostics
    );
    assert!(
        report
            .diagnostics
            .iter()
            .any(|d| d.message.contains("if condition requires bool")),
        "the if-condition diagnostic (actual: {:?})",
        report.diagnostics
    );
}

/// Negative 15 (E0004 run class): `head((5))` — the grouping collapses
/// to the int; the runtime domain check fires (the access face's
/// fail-closed).
#[test]
fn neg_e0004_head_domain_via_grouping() {
    let err = run_source("head((5))", "tup_e4_head.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Run);
    assert!(
        err.diagnostic
            .message
            .contains("head requires pair, got int"),
        "the head domain diagnostic (actual: {})",
        err.diagnostic.message
    );
}

/// Negative 16 (E0004 run class): `tail(head((1, 2)))` — the tuple's
/// head element is an int; tail's domain check fires through the tuple
/// consumption chain.
#[test]
fn neg_e0004_tail_domain_via_tuple() {
    let err = run_source("tail(head((1, 2)))", "tup_e4_tail.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Run);
    assert!(
        err.diagnostic
            .message
            .contains("tail requires pair, got int"),
        "the tail domain diagnostic (actual: {})",
        err.diagnostic.message
    );
}

/// Negative 17 (E0006 capability class): an undeclared capability call
/// inside a tuple element — the capability gate traverses the
/// synthesized cons arguments (the compile-time face).
#[test]
fn neg_e0006_capability_inside_tuple() {
    let err = run_source(r#"(print("x"), 2)"#, "tup_e6.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Compile);
    assert!(
        err.rendered.contains("error[E0006]"),
        "the capability class (actual: {})",
        err.rendered
    );
    assert!(
        err.diagnostic.message.contains("requires write capability"),
        "the capability diagnostic (actual: {})",
        err.diagnostic.message
    );
}

/// Negative 18 (E0014 qualified-name class): a multi-segment path as a
/// tuple element — the module-resolution face (no fallback).
#[test]
fn neg_e0014_qualified_path_element() {
    let err = run_source("let p = (kerf::string::append, 1); p", "tup_e14.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Compile);
    assert!(
        err.rendered.contains("error[E0014]"),
        "the qualified-name class (actual: {})",
        err.rendered
    );
}

/// Negative 19 (regression anchor): the pattern face's own arity cap is
/// UNCHANGED by this window (the pattern-position message is the r121
/// original — the expression window must not touch the pattern family).
#[test]
fn neg_pattern_face_arity_regression() {
    let e = read_err("match 5 { (a, b, c) => 1, _ => 0 }", "tup_pat_cap.ktf");
    assert!(
        e.message
            .contains("at most two elements inside pattern parentheses"),
        "the pattern-face original diagnostic (actual: {})",
        e.message
    );
}

/// Negative 20 (Span contract): the arity-cap diagnostic's span is the
/// second comma token's own position (D2 — the cur_span() at the comma;
/// `let x = (1, 2, 3);` — the comma after `2` sits at byte 13).
#[test]
fn neg_span_contract_arity_cap() {
    let e = read_err("let x = (1, 2, 3); x", "tup_span_cap.ktf");
    assert_eq!(
        e.span.start, 13,
        "the arity-cap span start (the second comma)"
    );
    assert_eq!(e.span.end, 14, "the arity-cap span end (the second comma)");
}

/// Negative 21 (Span contract): the trailing-comma diagnostic's span
/// covers the comma through the closing paren (D4 — the r138 vector
/// discipline; `let x = (1,);` — comma at 10, `)` at 11).
#[test]
fn neg_span_contract_trailing_comma() {
    let e = read_err("let x = (1,); x", "tup_span_trail.ktf");
    assert_eq!(
        e.span.start, 10,
        "the trailing-comma span start (the comma)"
    );
    assert_eq!(
        e.span.end, 12,
        "the trailing-comma span end (through the paren)"
    );
}

/// Negative 22 (dual-Reader error parity): the arity-cap family —
/// message + Span byte-identical across both Readers.
#[test]
fn neg_err_parity_arity_cap() {
    let e = assert_grammar_err_parity("(1, 2, 3)", "arity cap parity");
    assert!(e
        .message
        .contains("at most two elements in a tuple expression"));
}

/// Negative 23 (dual-Reader error parity): the trailing-comma family —
/// message + Span byte-identical across both Readers.
#[test]
fn neg_err_parity_trailing_comma() {
    let e = assert_grammar_err_parity("(1,)", "trailing comma parity");
    assert!(e.message.contains("tuple literal trailing comma illegal"));
}

/// Negative 24 (dual-Reader error parity): the natural faces — the
/// leading comma / double comma / EOF-after-second family, message +
/// Span byte-identical across both Readers (the face-isomorphic
/// discipline: the natural failure faces match by construction).
#[test]
fn neg_err_parity_natural_faces() {
    assert_grammar_err_parity("(, 1)", "leading comma parity");
    assert_grammar_err_parity("(1, , 2)", "double comma parity");
    assert_grammar_err_parity("(1, 2", "eof after second parity");
    assert_grammar_err_parity("(1", "eof after first parity");
}

// E6 close-out (r154 / 224-b8): converted to the target-syntax face.
//! r99 / 169-a — WASM component composition layer M3 integration tests
//! (TD-031 phase 3 made real).
//!
//! **Coverage** (§9.4.3 positive:negative ratio ≥ 1:3 — unit negative cases
//! are carried by wasm_compose/wasm_emit [validation fail-closed ×9 + face
//! validation ×3]; this file carries the integration surface):
//! - **Positive cases (node host composition E2E parity)**: the host-side
//!   node acts as the **composition consumer**, instantiating the canonical
//!   dual-module system in [`InstantiationPlan`] order — ① instantiate
//!   `kerf_abi` (boundary module) → ② inject its export surface (memory +
//!   realloc) as the import object for `kerf_core` (linked core module)
//!   instantiation → ③ reconcile `main()` call results corpus by corpus
//!   against the kerf VM `run_source` (**stitching with runtime type-check
//!   backing**: name/type/page-count mismatch = instantiation failure —
//!   consumption validation of the structurally wired import face);
//! - **Negative cases (stitching authenticity probes)**: ① instantiating the
//!   linked core module with no import object → LinkError (import
//!   dependencies are real, not decorative) ② wrong memory wiring (not a
//!   WebAssembly.Memory) → instantiation failure (type checking is real);
//! - **Structural positive cases**: full-chain reconciliation of plan/
//!   manifest compiled from real source + determinism + custom realloc name
//!   wiring + the realloc-absent (memory-only) form.
//!
//! **Toolchain dependency**: node (same §3.1 lookup chain as
//! wasm_backend_tests — `KERF_NODE` → PATH probe; explicit failure when
//! missing, no silent skip; §18 L-B ruling: host tools are not build
//! dependencies).
//!
//! **E6 skin notes (E6-CG §2)**: fn declarations replace `(define (f x) ...)`;
//! infix operators replace primitive applications (`(+ a b)` → `a + b`,
//! `(= a b)` → `a == b`); `mod` keeps the call form (`mod(a, b)`); negative
//! literals ride the binary-minus form `0 - N` (the target face lexes `-N`
//! as a unary-minus application, outside the ANF primitive-arity face —
//! the literal value is preserved through lowering).

use std::path::PathBuf;
use std::process::Command;
use std::sync::atomic::{AtomicU32, Ordering};

use kerf_backend::{
    compose_component, lower_program, parse_core_module_manifest, CanonicalAbiOptions,
    ComposedComponent, StringEncoding, WasmComponentModel,
};
use kerf_driver::compile_source;

/// Compile source to ANF (front-end pipeline + lowering — same policy as wasm_backend_tests).
fn lower_src(src: &str) -> kerf_backend::AnnotatedANF {
    let out = compile_source(src, "<test>")
        .expect("frontend compile failed (test source should be well-formed)");
    lower_program(&out.core, &out.table)
        .expect("lowering should succeed (test source should be PoC in domain)")
}

/// Component-model derivation (an M0 derivative — composition validation input).
fn model_of(src: &str) -> WasmComponentModel {
    kerf_backend::component_model_from_anf(&lower_src(src))
}

/// VM-side evaluation → i64 (Bool normalized to 0/1 — aligning both sides on B1-domain comparison results).
fn vm_of(src: &str) -> i64 {
    let r = kerf_driver::run_source(src, "<test>").expect("VM path should succeed");
    match r.value {
        kerf_vm::Value::Int(i) => i,
        kerf_vm::Value::Bool(b) => i64::from(b),
        ref other => panic!("VM artifact should be Int/Bool, actually {:?}", other),
    }
}

/// Resolve node (§3.1 lookup chain: `KERF_NODE` → PATH probe; explicit failure when missing).
fn node_path() -> PathBuf {
    if let Ok(p) = std::env::var("KERF_NODE") {
        let pb = PathBuf::from(p);
        if pb.is_file() {
            return pb;
        }
        panic!("KERF_NODE points to node does not exist:{}", pb.display());
    }
    match Command::new("node").arg("--version").output() {
        Ok(o) if o.status.success() => PathBuf::from("node"),
        _ => panic!(
            "node not found (host-side WASM verification tool -- install node or set KERF_NODE; §3.1 no silent skipping; §18 L-B ruling: host tools are not build dependencies)"
        ),
    }
}

/// Unique artifact directories (guards against parallel tests deleting each other).
static DIR_SEQ: AtomicU32 = AtomicU32::new(0);

/// Compose emission (real source + boundary data + ABI options → canonical dual-module system).
fn composed_of(src: &str, data: &[u8], abi: &CanonicalAbiOptions) -> ComposedComponent {
    let ir = lower_src(src);
    let model = kerf_backend::component_model_from_anf(&ir);
    compose_component(&ir, &model, data, abi).expect("M3 compose emit should succeed")
}

/// Default ABI options (wasm32 domain + default realloc name — the E2E baseline form).
fn abi32() -> CanonicalAbiOptions {
    CanonicalAbiOptions {
        string_encoding: StringEncoding::Utf8,
        memory64: false,
        realloc: Some("canonical_abi_realloc".into()),
    }
}

/// Host-side composed-system run: validate ×2 → instantiate in plan order → main() → i64.
///
/// node script exits: validation failure = exit 86 (stderr INVALID);
/// wiring/instantiation failure = uncaught exception (exit 1 — the negative
/// probe consumption face); success = stdout holds the `main()` result
/// (i64 → BigInt string).
fn run_composed_main(composed: &ComposedComponent, stem: &str) -> i64 {
    let node = node_path();
    let seq = DIR_SEQ.fetch_add(1, Ordering::SeqCst);
    let dir =
        std::env::temp_dir().join(format!("kerf-wasm-compose-{}-{}", std::process::id(), seq));
    std::fs::create_dir_all(&dir).expect("temp directory creation");
    let abi_wasm = dir.join(format!("{}.abi.wasm", stem));
    let core_wasm = dir.join(format!("{}.core.wasm", stem));
    std::fs::write(&abi_wasm, &composed.abi_module).expect("boundary module write to disk");
    std::fs::write(&core_wasm, &composed.core_module).expect("linked core module written to disk");
    // realloc field name passed through from the plan (single-source wiring
    // name — the custom-name form is consumed by the same script)
    let realloc_field = composed
        .plan
        .steps
        .iter()
        .flat_map(|s| s.imports.iter().flat_map(|(_, ws)| ws.iter()))
        .find(|w| matches!(w.kind, kerf_backend::WiringKind::ReallocFunc { .. }))
        .map(|w| w.field.clone())
        .unwrap_or_else(|| "NONE".into());
    let script = r#"
const fs = require('fs');
const abiB = fs.readFileSync(process.argv[1]);
const coreB = fs.readFileSync(process.argv[2]);
const reName = process.argv[3];
if (!WebAssembly.validate(abiB)) { console.error('INVALID ABI WASM'); process.exit(86); }
if (!WebAssembly.validate(coreB)) { console.error('INVALID CORE WASM'); process.exit(86); }
const abiInst = new WebAssembly.Instance(new WebAssembly.Module(abiB));
const imports = { kerf_abi: { memory: abiInst.exports.memory } };
if (reName !== 'NONE') imports.kerf_abi[reName] = abiInst.exports[reName];
const coreInst = new WebAssembly.Instance(new WebAssembly.Module(coreB), imports);
process.stdout.write(String(coreInst.exports.main()));
"#;
    let out = Command::new(&node)
        .arg("-e")
        .arg(script)
        .arg(&abi_wasm)
        .arg(&core_wasm)
        .arg(&realloc_field)
        .output()
        .expect("node process should start");
    let _ = std::fs::remove_dir_all(&dir); // only removes our own unique directory
    assert!(
        out.status.success(),
        "node compose run failed (exit {:?}): stderr={}",
        out.status.code(),
        String::from_utf8_lossy(&out.stderr)
    );
    let s = String::from_utf8(out.stdout).expect("node stdout should be UTF-8");
    s.trim()
        .parse::<i64>()
        .unwrap_or_else(|_| panic!("node output is not an integer: {:?}", s))
}

/// VM ↔ composed-system dual-side parity assertion (M3 core criterion — full-chain reconciliation after stitching).
fn composed_parity(src: &str, stem: &str) {
    let vm = vm_of(src);
    let composed = composed_of(src, b"kerf composed boundary", &abi32());
    let host = run_composed_main(&composed, stem);
    assert_eq!(vm, host, "compose system unified/VM parity failed:{}", src);
}

// ---------------------------------------------------------------------------
// Positive cases: node host composition E2E parity (composition consumer =
// the host runtime instantiating per plan)
// ---------------------------------------------------------------------------

#[test]
fn composed_fib_end_to_end_node_matches_vm() {
    // fib(12) recursion: diamond merge + tail if + direct call + full
    // recursive chain — full-chain reconciliation through the composed
    // dual-module system (Call index base offset + Import section in place)
    composed_parity(
        "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(12)\n",
        "c_fib",
    );
}

#[test]
fn composed_deep_recursion_and_arithmetic_family() {
    // fib(20) = 6765 deep recursion + arithmetic + value diamonds + nested diamonds + the tail-if family
    composed_parity(
        "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(20)\n",
        "c_fib20",
    );
    composed_parity("(2 + 3) * (10 - 4)\n", "c_arith");
    composed_parity("if (1 < 2) { 10 } else { 20 }\n", "c_vif");
    composed_parity(
        "(if (1 < 2) { if (3 > 2) { 100 } else { 200 } } else { 300 }) + (if (4 == 4) { 10 } else { 20 })\n",
        "c_nvif",
    );
    composed_parity(
        "fn classify(n: i64) -> i64 { if (n < 0) { 0 } else { if (n == 0) { 1 } else { 2 } } }\nclassify(0 - 5)\n",
        "c_tailif",
    );
}

#[test]
fn composed_mutual_recursion_and_div_mod_i64_boundary() {
    // Mutual recursion + div-mod negatives + i64 full-width boundary (2^32
    // literal — sleb64 ten-byte canonical form emitted in linked form)
    composed_parity(
        "fn even(n: i64) -> i64 { if (n == 0) { 1 } else { odd(n - 1) } }\nfn odd(n: i64) -> i64 { if (n == 0) { 0 } else { even(n - 1) } }\neven(20)\n",
        "c_mutual",
    );
    composed_parity("((0 - 7) / 2) - mod(0 - 7, 2)\n", "c_divmod");
    composed_parity(
        "if (0 < 4294967296) { 4294967296 } else { 0 }\n",
        "c_i64wide",
    );
    composed_parity("0 - 9223372036854775807\n", "c_i64min");
}

#[test]
fn composed_plan_and_manifest_from_real_source() {
    // Real-source full chain: plan structure (two steps + two stitches + provenance fingerprint) + manifest survival
    let src =
        "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(12)\n";
    let ir = lower_src(src);
    let composed = composed_of(src, b"hello", &abi32());
    let plan = &composed.plan;
    assert_eq!(plan.steps.len(), 2);
    assert_eq!(plan.steps[0].instance, "kerf_abi");
    assert_eq!(plan.steps[1].instance, "kerf_core");
    let (module, wirings) = &plan.steps[1].imports[0];
    assert_eq!(module, "kerf_abi");
    assert_eq!(wirings.len(), 2, "memory + realloc dual suture");
    assert_eq!(wirings[0].field, "memory");
    assert_eq!(wirings[1].field, "canonical_abi_realloc");
    assert_eq!(
        plan.source_fingerprint, ir.fingerprint,
        "source fingerprint chain pass-through"
    );
    // Manifest survival (zero-loss linked emission — the logical manifest is independent of the import index offset)
    assert_eq!(
        parse_core_module_manifest(&composed.core_module).unwrap(),
        model_of(src).core_funcs
    );
}

// ---------------------------------------------------------------------------
// Negative cases: stitching authenticity probes (import dependencies are
// real, not decorative — runtime type-check backing)
// ---------------------------------------------------------------------------

/// Negative-probe shared skeleton: run a wrongly-wired script against the linked core module and assert failure.
fn composed_negative_probe(src: &str, stem: &str, mode: &str) {
    let composed = composed_of(src, b"probe", &abi32());
    let node = node_path();
    let seq = DIR_SEQ.fetch_add(1, Ordering::SeqCst);
    let dir =
        std::env::temp_dir().join(format!("kerf-wasm-compneg-{}-{}", std::process::id(), seq));
    std::fs::create_dir_all(&dir).expect("temp directory creation");
    let core_wasm = dir.join(format!("{}.core.wasm", stem));
    std::fs::write(&core_wasm, &composed.core_module).expect("linked core module written to disk");
    // mode: no-imports = no import object; bad-memory = memory wired to 42
    let script = r#"
const fs = require('fs');
const b = fs.readFileSync(process.argv[1]);
if (!WebAssembly.validate(b)) { console.error('INVALID CORE WASM'); process.exit(86); }
let inst;
if (process.argv[2] === 'no-imports') {
  inst = new WebAssembly.Instance(new WebAssembly.Module(b));
} else {
  inst = new WebAssembly.Instance(new WebAssembly.Module(b), { kerf_abi: { memory: 42 } });
}
console.error('UNEXPECTED SUCCESS');
process.exit(0);
"#;
    let out = Command::new(&node)
        .arg("-e")
        .arg(script)
        .arg(&core_wasm)
        .arg(mode)
        .output()
        .expect("node process should start");
    let _ = std::fs::remove_dir_all(&dir);
    assert!(
        !out.status.success(),
        "negative probe should failed however succeeded(mode {}): stderr={}",
        mode,
        String::from_utf8_lossy(&out.stderr)
    );
    let stderr = String::from_utf8_lossy(&out.stderr);
    assert!(
        !stderr.contains("UNEXPECTED SUCCESS"),
        "negative probe not should reaching succeeded exit(mode {})",
        mode
    );
}

#[test]
fn composed_import_dependency_is_real_node() {
    // Instantiate the linked core module with no import object → LinkError
    // (import dependencies are real — the Import section is not decorative;
    // the reverse anchor of consumption validation for the stitching)
    composed_negative_probe("1 + 2\n", "c_nolink", "no-imports");
}

#[test]
fn composed_wrong_memory_wiring_fails_node() {
    // memory wired to a non-WebAssembly.Memory (42) → instantiation
    // failure (runtime type checking is real — the type-check consumption
    // anchor of the stitching)
    composed_negative_probe("1 + 2\n", "c_badmem", "bad-memory");
}

// ---------------------------------------------------------------------------
// Structural positive cases: custom realloc name wiring / realloc-absent
// form / determinism
// ---------------------------------------------------------------------------

#[test]
fn composed_custom_realloc_name_wiring_node() {
    // Custom realloc name (my_realloc): the field name flows from the ABI
    // options → face → plan → host wiring as a single source — the composed
    // system works end to end wired through the custom name
    let src =
        "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(12)\n";
    let abi = CanonicalAbiOptions {
        string_encoding: StringEncoding::Utf8,
        memory64: false,
        realloc: Some("my_realloc".into()),
    };
    let composed = composed_of(src, b"named", &abi);
    // The plan passes the custom name through
    let realloc_field = composed
        .plan
        .steps
        .iter()
        .flat_map(|s| s.imports.iter().flat_map(|(_, ws)| ws.iter()))
        .find(|w| matches!(w.kind, kerf_backend::WiringKind::ReallocFunc { .. }))
        .map(|w| w.field.clone())
        .unwrap();
    assert_eq!(realloc_field, "my_realloc");
    // Composed-system parity through the custom-name wiring
    let vm = vm_of(src);
    let host = run_composed_main(&composed, "c_name");
    assert_eq!(vm, host, "custom realloc name accept line parity failed");
}

#[test]
fn composed_no_realloc_memory_only_wiring_node() {
    // realloc = None (no boundary types that need allocation are crossed):
    // memory-only stitching (same policy as the supply face omitting four
    // sections — the import face likewise imports no functions) — the
    // composed system works
    let src = "6 * 7\n";
    let abi = CanonicalAbiOptions {
        string_encoding: StringEncoding::Utf8,
        memory64: false,
        realloc: None,
    };
    let composed = composed_of(src, b"bare", &abi);
    // Single stitch (memory only) + function index base offset = 0 (no imported functions)
    let (_, wirings) = &composed.plan.steps[1].imports[0];
    assert_eq!(wirings.len(), 1, "memory-only single suture");
    assert_eq!(wirings[0].field, "memory");
    // No imported functions: Export main index = 0 (zero base offset)
    let s = secs_of(&composed.core_module);
    let (_, es, _) = *s.iter().find(|(id, _, _)| *id == 0x07).unwrap();
    assert_eq!(
        composed.core_module[es + 7],
        0,
        "main index = 0(no function import)"
    );
    // Composed-system parity (boundary data still readable: the data segment lives in the supplier's memory)
    let vm = vm_of(src);
    let host = run_composed_main(&composed, "c_bare");
    assert_eq!(vm, host, "memory-only compose parity failed");
}

#[test]
fn composed_e2e_determinism() {
    // Same (source, data, abi) → same composed artifact (bytes + plan on
    // both sides — the composed-form extension of cross-compilation-chain
    // determinism)
    let src = "(if (1 < 2) { 10 } else { 20 }) + 5\n";
    let a = composed_of(src, b"stable", &abi32());
    let b = composed_of(src, b"stable", &abi32());
    assert_eq!(a.abi_module, b.abi_module, "boundary module determinism");
    assert_eq!(a.core_module, b.core_module, "link core module determinism");
    assert_eq!(a.plan.render(), b.plan.render(), "plan render determinism");
}

/// Section walk (id + payload range — structural assertion infrastructure).
fn secs_of(bytes: &[u8]) -> Vec<(u8, usize, usize)> {
    assert!(bytes.len() >= 8 && bytes[..8] == [0x00, 0x61, 0x73, 0x6d, 1, 0, 0, 0]);
    let mut out = Vec::new();
    let mut pos = 8usize;
    while pos < bytes.len() {
        let id = bytes[pos];
        pos += 1;
        let (size, adv) = read_uleb(&bytes[pos..]);
        pos += adv;
        out.push((id, pos, pos + size));
        pos += size;
    }
    out
}

/// LEB128 decode (u32 — walk helper).
fn read_uleb(b: &[u8]) -> (usize, usize) {
    let mut v = 0usize;
    let mut shift = 0u32;
    let mut i = 0;
    loop {
        let byte = b[i];
        v |= ((byte & 0x7f) as usize) << shift;
        i += 1;
        if byte & 0x80 == 0 {
            return (v, i);
        }
        shift += 7;
    }
}

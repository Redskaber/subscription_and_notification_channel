// E6 close-out (r154 / 224-c6): corpus converted to the target-syntax face
// (the S-expr .krf legs deleted — the Reader face retired; 12 legs removed,
// see the r154 / 224-c6 worklog for the per-leg record).
//! .ktf member-rename family tests — r134 / 204-b (the use-window legacy
//! domain-out pair cleared: `use m::{a as x}` member rename + the module-
//! header selection form — S-expr face selection-shape extension window).
//!
//! **Verification surfaces** (the selection list's rename triple
//! `local as renamed` on both faces + the header-region selection
//! acceptance; design single source = member-rename-design.md v1.0):
//! (1) **run-face E2E** — the renamed binding is flat-injected with the
//! underlying's dispatch body (replacement semantics D3: `sa` usable,
//! the original underlying `string-append` NOT flat-visible, the local
//! name `append` NOT usable, the qualified form `string/append`
//! unaffected — the module-level relation is maintained); the mixed
//! member list (bare + renamed) and the module-header selection form
//! E2E on both faces (the D5 flip: the expander header scan + the
//! driver's collect_module_header_imports accept selection lists);
//! (2) **the r134 grammar settlement** — the rename triple's canonical
//! Stx rendering byte-identical on both Readers (the flat triple
//! local/as/renamed with each symbol's own Span — D9); error faces
//! message + Span byte-identical;
//! (3) **cross-stage consumption** — the renamed program through
//! `check_source_recover` stays diagnostic-clean (HM A4: the
//! renamed binding's static type is Dynamic — zero E0005 false
//! positives, the builtin-value-position discipline);
//! (4) **fail-closed negatives** — the driver-level shape discipline
//! (S-expr face first-slot `as` / missing operand / non-symbol) + the
//! semantic families (rename duplicate E0017-family D7 / rename-alias
//! collision D7 / E0024 off-face by local name / E0022 the replaced
//! underlying D3 reverse anchor / io + prelude domain-out D8) + the
//! established use-family mirrors (E0019 multi-segment / block
//! position / pub).
//!
//! Skin-dictionary basis: 20 §14 v1.26 (the eleventh mapping's rename
//! extension); 02 §8.13.1a v7.19 (use_tree `as` member). Window basis:
//! r133 close-out note's recommended-order first item (the use-window
//! legacy trigger-gated domain-out pair) + use-declaration-design.md
//! v1.0 §7 rows 1-2 (D3/D6 — their registered trigger = this window) +
//! member-rename-design.md v1.0 (design single source) + r74 precedent
//! (user instruction = the demand signal itself, M1 form #39).
//! Ratio: 8 positive : 24 negative = 1:3 (§9.4.3).

use kerf_driver::bootstrap::reader::read_source_for_bootstrap;
use kerf_driver::{check_source_recover, run_source};
use kerf_reader::reader::read_source;
use kerf_syntax::{Stx, StxDatum, SymbolTable};

// r135 / member-rename-design.md v1.2 §8 D12-D14: the domain-out trio's
// clearing window — the HM signature derivation (renamed → underlying,
// both faces), the E0006 renamed reverse lookup (io), and the prelude
// Stx-layer binding injection (incremental-alias semantics). These tests
// consume the production check/run chains plus a direct oracle-parity
// probe (krf ⊆ oracle maintained).
use kerf_compiler::hm::hm_check_program;
use kerf_driver::builtins::builtin_sigs_with_renames;
use kerf_driver::compile_source;

// ---------------------------------------------------------------------------
// Value helpers (the ktf_use_decl_tests.rs caliber)
// ---------------------------------------------------------------------------

fn run_value(src: &str, filename: &str) -> String {
    let outcome = run_source(src, filename)
        .unwrap_or_else(|e| panic!("target face program {} execution failed:{}", filename, e));
    kerf_vm::render_value(&outcome.value, &outcome.heap)
}

// ---------------------------------------------------------------------------
// Dual-Reader parity helpers (canonical rendering with Span bytes; error
// parity with message + Span byte equality)
// ---------------------------------------------------------------------------

fn render_stx(s: &Stx, t: &SymbolTable) -> String {
    let mut out = String::new();
    render_stx_into(s, t, &mut out);
    out
}

fn render_stx_into(s: &Stx, t: &SymbolTable, out: &mut String) {
    match &s.datum {
        StxDatum::Symbol(sym) => {
            out.push_str(&format!(
                "(sym {} {}..{})",
                t.name(*sym),
                s.span.start,
                s.span.end
            ));
        }
        StxDatum::List(items) => {
            out.push_str(&format!("(lst {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
        // _ arm rationale: the rename family's Stx carries only symbols and
        // lists (the selection list's flat triple) — literals/vectors do
        // not participate in these assertions
        _ => out.push_str("(other)"),
    }
}

/// Grammar parity assertion: both Readers' canonical renderings are
/// byte-identical (the rename triple's flat local/as/renamed with each
/// symbol's own Span — D9; the seed and mirror are isomorphic by
/// construction).
fn assert_grammar_parity(src: &str, what: &str) {
    let mut t1 = SymbolTable::new();
    let seed = read_source(src, 0, &mut t1)
        .unwrap_or_else(|e| panic!("[{}] seed syntax failed: {}", what, e.message));
    let mut t2 = SymbolTable::new();
    let mirror = read_source_for_bootstrap(src, 0, &mut t2)
        .unwrap_or_else(|e| panic!("[{}] mirror syntax failed:{}", what, e.message));
    assert_eq!(
        seed.len(),
        mirror.len(),
        "[{}] top-level item count mismatch (seed {} vs mirror {})",
        what,
        seed.len(),
        mirror.len()
    );
    for (i, (a, b)) in seed.iter().zip(mirror.iter()).enumerate() {
        assert_eq!(
            render_stx(a, &t1),
            render_stx(b, &t2),
            "[{}] top-level item #{} syntax tree mismatch (seed vs mirror canonical render)",
            what,
            i
        );
    }
}

/// Grammar-error parity assertion: message + Span byte-level equality.
fn assert_grammar_err_parity(src: &str, what: &str) -> String {
    let mut t1 = SymbolTable::new();
    let seed_err = match read_source(src, 0, &mut t1) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] seed should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    let mut t2 = SymbolTable::new();
    let mirror_err = match read_source_for_bootstrap(src, 0, &mut t2) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] mirror should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    assert_eq!(
        seed_err.message, mirror_err.message,
        "[{}] syntax error message mismatch (seed {:?} vs mirror {:?})",
        what, seed_err.message, mirror_err.message
    );
    assert_eq!(
        seed_err.span.start, mirror_err.span.start,
        "[{}] syntax error Span start mismatch (seed {} vs mirror {})",
        what, seed_err.span.start, mirror_err.span.start
    );
    assert_eq!(
        seed_err.span.end, mirror_err.span.end,
        "[{}] syntax error Span end mismatch (seed {} vs mirror {})",
        what, seed_err.span.end, mirror_err.span.end
    );
    seed_err.message.clone()
}

// ---------------------------------------------------------------------------
// Positives — run-face E2E + grammar settlement + cross-stage consumption
// ---------------------------------------------------------------------------

/// Positive 1 / integration: the core rename E2E — `use kerf_string::
/// {append as sa};` makes `sa` the flat binding (the underlying's
/// dispatch body — D3/D4 replacement semantics; value-level proof
/// through the production run chain).
#[test]
fn rename_flat_binding_e2e() {
    let v = run_value(
        "use kerf_string::{append as sa};\nsa(\"r134\", \" rename-ok\")",
        "rename.ktf",
    );
    assert_eq!(
        v, "r134 rename-ok",
        "rename binding flat injection must produce r134 rename-ok(actual: {})",
        v
    );
}

/// Positive 3 / integration: the replacement semantics' qualified-access
/// invariant — after the rename, the qualified form `string::append`
/// stays reachable (the module-level relation is untrimmed — D3), while
/// the renamed flat binding coexists.
#[test]
fn rename_qualified_access_invariant_e2e() {
    let v = run_value(
        "use kerf_string::{append as sa};\nstring::append(sa(\"a\", \"b\"), \"c\")",
        "qual.ktf",
    );
    assert_eq!(
        v, "abc",
        "post-rename qualified access must maintains the module-level relation(actual: {})",
        v
    );
}

/// Positive 4 / integration: the mixed member list — bare and renamed
/// members coexist (`(append as sa length)` → `sa` + `string-length`
/// both flat-visible; D3 per-member granularity).
#[test]
fn rename_mixed_members_e2e() {
    let v = run_value(
        "use kerf_string::{append as sa, length};\nstring_length(sa(\"ab\", \"c\"))",
        "mixed.ktf",
    );
    assert_eq!(
        v, "3",
        "mixed member list bare+rename must be usable on both(actual: {})",
        v
    );
}

/// Positive 6 / integration: the module-header selection form E2E on the
/// target face — `module m { use kerf_string::{append}; ... }` (the D5
/// flip's target-face debut — both faces accept, both feed the same
/// driver face).
#[test]
fn rename_module_header_selection_ktf_e2e() {
    let v = run_value(
        "module m { use kerf_string::{append}; export make; fn make() { string_append(\"m\", \" head-sel\") } }\nmake();",
        "modsel.ktf",
    );
    assert_eq!(
        v, "m head-sel",
        "target face module header selective form must accept and and S S-expr face same value (actual: {})",
        v
    );
}

/// Positive 7 / grammar settlement: dual-Reader canonical rendering
/// parity — the rename triple's flat Stx (local, as, renamed — each
/// symbol with its own Span, D9) byte-identical on both Readers; plus
/// the canonical form check (the selection list carries the three
/// symbols in source order).
#[test]
fn rename_dual_reader_canonical_parity() {
    assert_grammar_parity("use kerf_string::{append as sa};", "rename form");
    assert_grammar_parity(
        "use kerf_string::{append as sa, length};",
        "rename+bare mixed form",
    );
    assert_grammar_parity(
        "use kerf_string::{append as sa,};",
        "rename trailing comma form(arm family optional)",
    );
    assert_grammar_parity(
        "use kerf_string::{append as sa} as str;",
        "rename+module alias compound form",
    );
    // The canonical form check: the selection list's Stx must carry the
    // flat triple — (import kerf-string (append as sa)) — symbol-for-
    // symbol with each element's own Span.
    let mut t = SymbolTable::new();
    let items = read_source("use kerf_string::{append as sa};", 0, &mut t)
        .expect("rename form must parse succeeded");
    let rendered = render_stx(&items[0], &t);
    assert!(
        rendered.contains("(sym kerf-string ")
            && rendered.contains("(sym append ")
            && rendered.contains("(sym as ")
            && rendered.contains("(sym sa "),
        "canonical render must contain the flat triple's four symbols(kerf-string/append/as/sa -- actual: {})",
        rendered
    );
}

/// Positive 8 / integration: cross-stage consumption — the renamed
/// program through `check_source_recover` stays diagnostic-clean
/// (HM A4: the renamed binding's static type is Dynamic — zero E0005
/// false positives; the builtin-value-position discipline).
#[test]
fn rename_check_cross_stage_clean() {
    let report = check_source_recover(
        "use kerf_string::{append as sa};\nlet r = sa(\"a\", \"b\");\nr",
        "rename.ktf",
    )
    .expect("recovery mode check does not short-circuit");
    assert!(
        report.diagnostics.is_empty(),
        "rename program check face must zero diagnostics(HM A4 Dynamic -- actual: {:?})",
        report.diagnostics
    );
    assert!(
        report.proto_count + report.const_count > 0,
        "rename program must have a real compile artifact(actual: proto {} + const {})",
        report.proto_count,
        report.const_count
    );
}

// ---------------------------------------------------------------------------
// Negatives — the semantic families (E6 close-out r154 / 224-c6: the
// S-expr-face driver-level shape-discipline quartet [first-slot as /
// as-tail / non-symbol operand / non-symbol member] deleted with that
// Reader face — the target-face mirror anchors live in
// neg_rename_operand_*_parity, neg_module_header_*_ktf below and
// ktf_use_decl_tests 13)
// ---------------------------------------------------------------------------

/// Negative 5: the rename duplicate — the same renamed binding twice in
/// one import face (the E0017-family D7 extension).
#[test]
fn neg_rename_duplicate_e0017_family() {
    let e = run_source("use kerf_string::{append as sa, length as sa};", "dup.ktf")
        .expect_err("duplicate renames must be rejected");
    assert!(
        e.rendered.contains("member rename duplicate") && e.rendered.contains("sa"),
        "member rename duplicate anchor(actual: {})",
        e.rendered
    );
}

/// Negative 6: the rename-alias collision — a renamed binding identical
/// to a module alias (the user-binding-name same-domain uniqueness D7).
#[test]
fn neg_rename_alias_collision_e0017_family() {
    let e = run_source(
        "use kerf_string as sa, kerf_list::{length as sa};",
        "coll.ktf",
    )
    .expect_err("rename same-name as alias must be rejected");
    assert!(
        e.rendered
            .contains("member rename and alias same-named conflict"),
        "rename and alias same-named conflict anchor(actual: {})",
        e.rendered
    );
}

/// Negative 7: E0024 by local name — the renamed member's export-face
/// check uses the local name (`nope as x` — nope is not exported).
#[test]
fn neg_rename_member_not_exported_e0024() {
    let e = run_source("use kerf_string::{nonexist as x};", "e24.ktf")
        .expect_err("rename member not in export face must E0024");
    assert!(
        e.rendered.contains("E0024") && e.rendered.contains("nonexist"),
        "E0024 by name check anchor(actual: {})",
        e.rendered
    );
}

/// Negative 8: the D3 reverse anchor — after the rename, the original
/// underlying `string-append` is NOT flat-visible (the replacement
/// semantics' exactness proof: the E0022 face fires on the direct
/// underlying write).
#[test]
fn neg_rename_underlying_not_visible_e0022() {
    let e = run_source(
        "use kerf_string::{append as sa};\nstring_append(\"a\", \"b\");",
        "rev.ktf",
    )
    .expect_err("after rename original underlying name written directly must E0022");
    assert!(
        e.rendered.contains("E0022") && e.rendered.contains("string-append"),
        "E0022 reverse anchor -- replacement semantics verified(actual: {})",
        e.rendered
    );
}

/// Negative 9: the local-name discipline — after the rename, the bare
/// local name `append` is still not usable (the D65 filter semantics
/// unchanged by the rename).
#[test]
fn neg_rename_local_name_not_visible_e0022() {
    let e = run_source(
        "use kerf_string::{append as sa};\nappend(\"a\", \"b\");",
        "loc.ktf",
    )
    .expect_err("after rename local name written directly must E0022");
    assert!(
        e.rendered.contains("E0022"),
        "E0022 local name anchor(actual: {})",
        e.rendered
    );
}

/// Negative 10 / r135 flip: io member rename — the D8 domain-out
/// rejection is **retired** (member-rename-design.md v1.2 §8 D13); the
/// new face = the E0006 renamed reverse lookup — an unauthorized renamed
/// gated reference is caught with the dual-name diagnostic (renamed
/// user-visible + underlying attribution; renaming grants no new
/// capability face).
#[test]
fn neg_rename_io_unauthorized_e0006_dual_name() {
    let e = run_source("use kerf_io::{print as p};\np(\"x\")", "io.ktf")
        .expect_err("io rename unauthorized reference must E0006 reverse-lookup interception");
    assert!(
        e.rendered.contains("E0006")
            && e.rendered.contains("(io member print)")
            && e.rendered
                .contains("rename bindings do not change capability requirements"),
        "io reverse-lookup dual-name anchor (actual: {})",
        e.rendered
    );
}

/// Positive / r135 D13-②: io member rename authorized — `require io,
/// write` + `print as p` rides the underlying's grant token (the
/// renamed binding shares the dispatch body — run_front's Rc-shared
/// injection).
#[test]
fn pos_rename_io_authorized_e2e() {
    let v = run_value(
        "use kerf_io::{print as pr};\nrequire io, write;\npr(\"R135 io-ok\")",
        "ioauth.ktf",
    );
    assert_eq!(
        v, "nil",
        "after authorization io rename output face(print return value nil -- output side effect another verify; actual: {})",
        v
    );
}

/// Negative 11 / r135 flip: prelude member rename — the D8 domain-out
/// rejection is **retired** (member-rename-design.md v1.2 §8 D14); the
/// new face = the Stx-layer binding injection (incremental-alias
/// semantics D14-③) — a renamed binding resolves through the injected
/// define; the underlying local name stays usable (the define face
/// carries both).
#[test]
fn pos_rename_prelude_injection_e2e() {
    let v = run_value(
        "use kerf_prelude::{map as m};\nm(|| (x: i64) { x * x }, list(1, 2, 3))",
        "prel.ktf",
    );
    assert_eq!(
        v, "(1 4 9)",
        "prelude rename injection binding must produce (1 4 9)(actual: {})",
        v
    );
}

/// r135 D14-③: the incremental-alias semantics — after `map as m` the
/// underlying local name stays usable (the define face identity is
/// untrimmed — the prelude domain's contrast with the seven modules'
/// replacement semantics).
#[test]
fn pos_rename_prelude_local_still_usable() {
    let v = run_value(
        "use kerf_prelude::{map as m};\nmap(|| (x: i64) { x + 1 }, list(1, 2))",
        "prel2.ktf",
    );
    assert_eq!(
        v, "(2 3)",
        "prelude after rename local name remains usable(incremental alias semantics -- actual: {})",
        v
    );
}

/// Negative 14: the target-face module-header empty braces in the header
/// (the member-name expectation face — the established family).
#[test]
fn neg_module_header_empty_braces_ktf() {
    let e = run_source(
        "module m { use kerf_string::{}; export x; define(x(), 1); }",
        "empty.ktf",
    )
    .expect_err("target face header empty braces must be rejected");
    assert!(
        e.rendered.contains("expected a member name"),
        "header empty braces anchor(actual: {})",
        e.rendered
    );
}

/// Negative 15: the dual-Reader error parity — the rename operand
/// missing at eof (`use a::{b as` — both faces' message + Span bytes).
#[test]
fn neg_rename_operand_eof_parity() {
    let m = assert_grammar_err_parity("use a::{b as", "rename right operand eof");
    assert!(
        m.contains("expected a member rename identifier, got Eof"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 16: the dual-Reader error parity — the rename operand
/// missing with a Semi (`use a::{b as ;};` — the Semi surfaces in the
/// renamed slot).
#[test]
fn neg_rename_operand_semi_parity() {
    let m = assert_grammar_err_parity("use a::{b as ;};", "rename right operand Semi");
    assert!(
        m.contains("expected a member rename identifier, got Semi"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 17: the dual-Reader error parity — a keyword in the renamed
/// slot (`use a::{b as fn};` — KwFn is not an Ident/Path).
#[test]
fn neg_rename_operand_kw_parity() {
    let m = assert_grammar_err_parity("use a::{b as fn};", "rename right operand KwFn");
    assert!(
        m.contains("expected a member rename identifier, got KwFn"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 18: E0019 with a rename — the multi-segment path form
/// (`use kerf::string::{a as b};` — the single-layer ruling unchanged).
#[test]
fn neg_rename_multisegment_e0019() {
    let e = run_source("use kerf::string::{append as sa};", "path.ktf")
        .expect_err("rename form multi-segment path must E0019");
    assert!(
        e.rendered.contains("E0019") && e.rendered.contains("kerf/string"),
        "E0019 rename form anchor(actual: {})",
        e.rendered
    );
}

/// Negative 19: E0019 with a rename — the unknown module form.
#[test]
fn neg_rename_unknown_module_e0019() {
    let e = run_source("use kerf_nonexistent::{append as sa};", "unk.ktf")
        .expect_err("not registration module rename form must E0019");
    assert!(
        e.rendered.contains("E0019") && e.rendered.contains("kerf-nonexistent"),
        "E0019 not registration module anchor(actual: {})",
        e.rendered
    );
}

/// Negative 20: the block position — the rename use form inside a block
/// (the E0001 statement-position fall-through — the established family).
#[test]
fn neg_rename_block_position_e0001() {
    let m = assert_grammar_err_parity(
        "fn f() -> () { use kerf_string::{append as sa}; }",
        "inside a block position rename",
    );
    assert!(
        m.contains("expected an expression, got KwUse"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 21: pub visibility — the pub use rename form (the
/// pre-existing domain-out — 22 §7 Stage 2+ registration).
#[test]
fn neg_rename_pub_domain_out() {
    let m = assert_grammar_err_parity("pub use a::{b as c};", "pub out of domain rename");
    assert!(
        m.contains("pub visibility modifier"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 23: the target-face rename operand RBrace parity anchor —
/// the dedicated expectation family's byte-level error face (both
/// Readers' Span = the offending token; mirrors ktf_use_decl_tests 13a
/// at the rename-family file level for the window's own gate).
#[test]
fn neg_rename_operand_rbrace_parity() {
    let m = assert_grammar_err_parity("use a::{b as};", "rename right operand RBrace");
    assert!(
        m.contains("expected a member rename identifier, got RBrace"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 24: the target-face member-position list — `{(append)}` in
/// the selection braces is rejected at the Reader level (the member-name
/// expectation face — the target face's structural boundary; the S-expr
/// face's nested-list mirror is Negative 12).
#[test]
fn neg_module_header_nested_list_ktf_reader_face() {
    let e = run_source(
        "module m { use kerf_string::{(append)}; export x; define(x(), 1); }",
        "nestk.ktf",
    )
    .expect_err("target face member position list must be rejected");
    assert!(
        e.rendered.contains("expected a member name, got LParen"),
        "target face member position list Reader face anchor (actual: {})",
        e.rendered
    );
}

// ---------------------------------------------------------------------------
// r135 / member-rename-design.md v1.2 §8: the domain-out trio's clearing
// window — HM signature derivation (D12) + E0006 renamed reverse lookup
// (D13) + prelude Stx-layer injection (D14). 5 positive + 23 negative
// (§9.4.3 1:3 window ratio maintained together with the flipped anchors
// above — the r135 window's net-add face).
// ---------------------------------------------------------------------------

/// Positive / r135 D12-①: the derived apply-position signature — the
/// renamed binding with correct argument types stays diagnostic-clean on
/// the production check chain (check.krf's TC-RENAME chain resolution).
#[test]
fn pos_r135_hm_derived_apply_clean() {
    let report = check_source_recover(
        "use kerf_string::{append as sa};\nsa(\"a\", \"b\")",
        "hmpos.ktf",
    )
    .expect("positive case check must pass compile");
    assert!(
        report.diagnostics.is_empty(),
        "derived signature positive case must have zero diagnostics (actual: {:?})",
        report.rendered
    );
}

/// Positive / r135 D12-④: production ↔ oracle parity — the production
/// face's diagnostic count on `sa(1, 2)` pairs with the Rust oracle's
/// direct count (builtin_sigs_with_renames — both derive the same
/// signature; the zero-false-positive contract r80 carries over; the
/// retired S-expr twin's oracle leg converged onto the same target
/// source at E6 r154 / 224-c6).
#[test]
fn pos_r135_hm_derived_krf_oracle_consistency() {
    let src_ktf = "use kerf_string::{append as sa};\nsa(1, 2)";
    let report = check_source_recover(src_ktf, "hmpar.ktf")
        .expect("check must pass compile(negative case level)");
    let out = compile_source(src_ktf, "hmpar.ktf").expect("oracle pre-stage compile failed");
    let mut table = out.table;
    let renames: Vec<(String, String)> = vec![("sa".to_string(), "string-append".to_string())];
    let sigs = builtin_sigs_with_renames(&mut table, &renames);
    let oracle = hm_check_program(&out.core, &sigs, &table);
    assert!(
        !report.diagnostics.is_empty() && !oracle.diags.is_empty(),
        "both faces must report derived signature violations(production: {:?} / oracle: {} clauses)",
        report.rendered,
        oracle.diags.len()
    );
}

/// Positive / r135 D14-②: the prelude N1-exempt rename rides the same
/// injection — `cons as c` (cons ∈ N1, skipped by the flat branch's N1
/// filter; the injected define's underlying reference ∈ N1 → zero E0022,
/// the define face carries the binding).
#[test]
fn pos_r135_prelude_n1_exempt_e2e() {
    let v = run_value("use kerf_prelude::{cons as c};\nc(1, 2)", "n1rename.ktf");
    assert_eq!(
        v, "(1 . 2)",
        "N1 exempt-name rename must via injection define can use(actual: {})",
        v
    );
}

/// Positive / r135 D13-②: the read-family rename authorized —
/// `newline as nl` + `require io, write` rides the underlying's grant
/// token (the write-side output side effect fires; the return value is
/// nil).
#[test]
fn pos_r135_io_newline_authorized_e2e() {
    let v = run_value(
        "use kerf_io::{newline as nl};\nrequire io, write;\nnl()",
        "nlauth.ktf",
    );
    assert_eq!(
        v, "nil",
        "after authorization newline rename return value nil(actual: {})",
        v
    );
}

/// Negative / r135 D12-①: the derived signature's argument-domain check —
/// `sa(1, 2)` reports per-argument E0005 (the string-append signature's
/// str rule; each offending argument gets its own diagnostic — oracle
/// parity with the underlying's direct-write behavior).
#[test]
fn neg_r135_hm_derived_str_domain_ktf() {
    let report = check_source_recover("use kerf_string::{append as sa};\nsa(1, 2)", "hmstr.ktf")
        .expect("check must pass compile(negative case level)");
    assert!(
        report
            .diagnostics
            .iter()
            .filter(|d| d.message.contains("requires str"))
            .count()
            >= 2,
        "each parameter domain violation must be reported per parameter E0005(actual: {:?})",
        report.rendered
    );
}

/// Negative / r135 D12: the derived arity check — `cons as cs` called
/// with one argument reports the arity mismatch (cons's fixed 2-arity
/// signature derives through the rename).
#[test]
fn neg_r135_hm_derived_cons_arity_low() {
    let report = check_source_recover("use kerf_pair::{cons as cs};\ncs(1)", "hmcons.ktf")
        .expect("check must pass compile(negative case level)");
    assert!(
        report
            .diagnostics
            .iter()
            .any(|d| d.message.contains("procedure argument count mismatch")),
        "cons renamed single argument must report a count mismatch(actual: {:?})",
        report.rendered
    );
}

/// Negative / r135 D12: the derived arity check's upper bound — `cons as
/// cs` with three arguments exceeds the fixed arity max.
#[test]
fn neg_r135_hm_derived_cons_arity_high() {
    let report = check_source_recover("use kerf_pair::{cons as cs};\ncs(1, 2, 3)", "hmcons3.ktf")
        .expect("check must pass compile(negative case level)");
    assert!(
        report
            .diagnostics
            .iter()
            .any(|d| d.message.contains("procedure argument count mismatch")),
        "cons renamed three arguments must report a count mismatch(actual: {:?})",
        report.rendered
    );
}

/// Negative / r135 D12: the derived pair-domain check — `head as hd`
/// with a non-pair argument reports head's pair requirement (the
/// cons/head/tail special arms derive through the rename chain — the
/// signature name drives them).
#[test]
fn neg_r135_hm_derived_head_nonpair() {
    let report = check_source_recover("use kerf_pair::{head as hd};\nhd(5)", "hmhd.ktf")
        .expect("check must pass compile(negative case level)");
    assert!(
        report
            .diagnostics
            .iter()
            .any(|d| d.message.contains("head requires pair")),
        "head rename non-pair must report pair domain (actual: {:?})",
        report.rendered
    );
}

/// Negative / r135 D12: the derived return-type flow — a renamed
/// string-append's str result flowing into a renamed head's pair
/// parameter reports the pair-domain violation (derived signatures
/// compose across renamed bindings).
#[test]
fn neg_r135_hm_derived_return_type_flow() {
    let report = check_source_recover(
        "use kerf_string::{append as sa};\nuse kerf_pair::{head as hd};\nhd(sa(\"a\", \"b\"))",
        "hmflow.ktf",
    )
    .expect("check must pass compile(negative case level)");
    assert!(
        report
            .diagnostics
            .iter()
            .any(|d| d.message.contains("head requires pair")),
        "derived return type flow must report pair domain (actual: {:?})",
        report.rendered
    );
}

/// Negative / r135 D12: the derived signature composition flow — a
/// renamed predicate's bool result flowing into a renamed string-append's
/// str parameter reports the domain violation (two derived signatures
/// compose across renamed bindings; is_string is the core domain's
/// N1-underlying derivation, sa the string domain's flat-loop one).
#[test]
fn neg_r135_hm_derived_eq_mixed_domain() {
    let report = check_source_recover(
        "use kerf_core::{is_string as isp};\nuse kerf_string::{append as sa};\nsa(isp(\"x\"), \"b\")",
        "hmeq.ktf",
    )
    .expect("check must pass compile(negative case level)");
    assert!(
        report
            .diagnostics
            .iter()
            .any(|d| d.message.contains("requires str")),
        "derived signature composition bool→str flow must report a domain violation(actual: {:?})",
        report.rendered
    );
}

/// Negative / r135 D12: the derived not-arity — `not as nt` with two
/// arguments reports the fixed 1-arity mismatch.
#[test]
fn neg_r135_hm_derived_not_arity() {
    let report = check_source_recover("use kerf_core::{not as nt};\nnt(true, false)", "hmnot.ktf")
        .expect("check must pass compile(negative case level)");
    assert!(
        report
            .diagnostics
            .iter()
            .any(|d| d.message.contains("procedure argument count mismatch")),
        "not renamed dual arguments must report a count mismatch(actual: {:?})",
        report.rendered
    );
}

/// Negative / r135 D12: the derived bool-result arithmetic misuse —
/// `is_string as isp` (the core domain's N1-underlying derivation) with
/// its bool result inside an arithmetic sum reports the num-domain
/// violation.
#[test]
fn neg_r135_hm_derived_bool_arith() {
    let report = check_source_recover(
        "use kerf_core::{is_string as isp};\nisp(\"x\") + 1",
        "hmbool.ktf",
    )
    .expect("check must pass compile(negative case level)");
    assert!(
        !report.diagnostics.is_empty(),
        "is_string rename bool position arithmetic must report(actual: {:?})",
        report.rendered
    );
}

/// Negative / r135 D12: the derived tail-domain check — `tail as tl` with
/// a non-pair argument (the tail special arm's pair requirement).
#[test]
fn neg_r135_hm_derived_tail_nonpair() {
    let report = check_source_recover("use kerf_pair::{tail as tl};\ntl(7)", "hmtl.ktf")
        .expect("check must pass compile(negative case level)");
    assert!(
        report
            .diagnostics
            .iter()
            .any(|d| d.message.contains("tail requires pair")),
        "tail rename non-pair must report pair domain (actual: {:?})",
        report.rendered
    );
}

/// Negative / r135 D12: per-argument granularity — `sa("a", 1)` reports
/// exactly the second argument's domain violation (the first argument
/// passes; the scan proceeds per-argument — oracle parity).
#[test]
fn neg_r135_hm_derived_second_arg_only() {
    let report = check_source_recover(
        "use kerf_string::{append as sa};\nsa(\"a\", 1)",
        "hm2nd.ktf",
    )
    .expect("check must pass compile(negative case level)");
    let count = report
        .diagnostics
        .iter()
        .filter(|d| d.message.contains("requires str"))
        .count();
    assert_eq!(
        count, 1,
        "only#two argument violation -- single diagnostics (actual: {:?})",
        report.rendered
    );
}

/// Negative / r135 D12 + r144 / 214-c premise flip: the read-family
/// rename derivation — `read-line as rl` resolves through TC-RENAME to
/// the read-line TC-SIGS entry (added r144, read-line-sig-design D2;
/// the r135 "underlying miss → Dynamic" honest-boundary instance is
/// retired) → `rl()` is a legal derived 0-arg call → zero false
/// positives (the tightened boundary — `rl(1)` now rejects — is
/// anchored in ktf_read_line_sig_tests N5/N6).
#[test]
fn neg_r135_hm_read_family_a4_carryover() {
    let report = check_source_recover(
        "use kerf_io::{read_line as rl};\nrequire io, read;\nrl()",
        "hmread.ktf",
    )
    .expect("check must pass compile");
    assert!(
        report.diagnostics.is_empty(),
        "read family rename must derive the 0-arg signature and stay zero false positives(actual: {:?})",
        report.rendered
    );
}

/// Negative / r135 D12: the value-position A4 discipline unchanged —
/// `f(sa)` passes the renamed binding as a value (not an application
/// head) → zero diagnostics (the derivation entries are consumed only at
/// the apply-position lookup — the r80 A4 rule carries over verbatim).
#[test]
fn neg_r135_hm_value_position_dynamic_unchanged() {
    let report = check_source_recover(
        "use kerf_string::{append as sa};\nfn f(g: T) { g }\nf(sa)",
        "hmval.ktf",
    )
    .expect("check must pass compile");
    assert!(
        report.diagnostics.is_empty(),
        "value position rename binding must always Dynamic zero diagnostics (actual: {:?})",
        report.rendered
    );
}

/// Negative / r135 D12: the takeover exemption — a user define of the
/// renamed name takes over (the environment hit precedes the signature
/// chain — zero false positives on user-shadowed renames).
#[test]
fn neg_r135_hm_takeover_no_false_positive() {
    let report = check_source_recover(
        "use kerf_string::{append as sa};\nfn sa(a: T) { a }\nsa(\"x\")",
        "hmtake.ktf",
    )
    .expect("check must pass compile");
    assert!(
        report.diagnostics.is_empty(),
        "user-takeover rename bindings must zero false positives(actual: {:?})",
        report.rendered
    );
}

/// Negative / r135 D13-②: the read-capability reverse lookup —
/// `read_line as rl` referenced without a require declaration reports
/// E0006 with the read capability and the dual-name form.
#[test]
fn neg_r135_io_read_unauthorized_e0006() {
    let e = run_source("use kerf_io::{read_line as rl};\nrl()", "iord.ktf")
        .expect_err("read family rename not authorization must E0006 reverse-lookup interception");
    assert!(
        e.rendered.contains("E0006")
            && e.rendered.contains("read")
            && e.rendered.contains("(io member read-line)"),
        "read reverse-lookup dual-name anchor (actual: {})",
        e.rendered
    );
}

/// Negative / r135 D13-②: the write-capability reverse lookup —
/// `newline as nl` referenced without authorization reports E0006 with
/// the write capability and the dual-name form.
#[test]
fn neg_r135_io_newline_unauthorized_e0006() {
    let e = run_source("use kerf_io::{newline as nl};\nnl()", "ionl.ktf")
        .expect_err("newline rename not authorization must E0006 reverse-lookup interception");
    assert!(
        e.rendered.contains("E0006")
            && e.rendered.contains("write")
            && e.rendered.contains("(io member newline)"),
        "newline reverse-lookup dual-name anchor (actual: {})",
        e.rendered
    );
}

/// Negative / r135 D13-②: the capability-dimension precision — read
/// authorized but write not: a renamed write-family reference still
/// reports (the grant token is per-capability; `require io, read` does
/// not cover the write family).
#[test]
fn neg_r135_io_grant_dimension_precision() {
    let e = run_source(
        "use kerf_io::{newline as nl};\nrequire io, read;\nnl()",
        "iodim.ktf",
    )
    .expect_err("read authorization does not cover write family rename quote use");
    assert!(
        e.rendered.contains("E0006") && e.rendered.contains("write"),
        "capability dimension precision anchor (actual: {})",
        e.rendered
    );
}

/// Negative / r135 D13: the first-violation blocking semantics with two
/// renamed gated references — the first one in source order is reported
/// (single-violation fail-closed — the E0006 family's discipline).
#[test]
fn neg_r135_io_first_violation_blocks() {
    let e = run_source(
        "use kerf_io::{print as p, newline as n};\np(\"a\")\nn()",
        "iofirst.ktf",
    )
    .expect_err("dual-rename unauthorized first violation must block");
    assert!(
        e.rendered.contains("E0006") && e.rendered.contains("(io member print)"),
        "first violation rename anchor(actual: {})",
        e.rendered
    );
}

/// Negative / r135 D13: the qualified-name mixed form — a rename plus a
/// direct qualified `io/print` write (both unauthorized) — the qualified
/// form rides its own E0006 face (r39 M1) alongside the renamed one.
#[test]
fn neg_r135_io_qualified_mixed_unauthorized() {
    let e = run_source("use kerf_io::{print as p};\nio/print(\"a\")", "ioqual.ktf")
        .expect_err("qualified name + rename mixed combine not authorization must E0006");
    assert!(
        e.rendered.contains("E0006"),
        "qualified name mixed anchor(actual: {})",
        e.rendered
    );
}

/// Negative / r135 D14-②: the renamed binding colliding with a reserved
/// word — `map as define` is rejected by the E0020 face with the Span
/// pointing at the user's selection-list element (the injection's
/// attribution anchor — r135 D14-②'s parallel Span array).
#[test]
fn neg_r135_prelude_reserved_word_e0020() {
    let e = run_source("use kerf_prelude::{map as define};\n42", "pwres.ktf")
        .expect_err("reserved word rename must by E0020 rejected");
    assert!(
        e.rendered.contains("E0020") && e.rendered.contains("define"),
        "reserved word anchor(actual: {})",
        e.rendered
    );
}

/// Negative / r135 D14-②: the injected define colliding with a user
/// define of the same name — the duplicate-definition face fires at
/// runtime (DefineGlobal's same-layer guard — the injected `(define m
/// map)` and the user's `fn m` collide).
#[test]
fn neg_r135_prelude_inject_define_collision() {
    let e = run_source(
        "use kerf_prelude::{map as m};\nfn m(x: T) { x }\nm(1)",
        "pcoll.ktf",
    )
    .expect_err("injection define collides with user define must report duplicate definition");
    assert!(
        e.rendered.contains("duplicate variable definition"),
        "duplicate definition anchor(actual: {})",
        e.rendered
    );
}

/// Negative / r135 D14: an undefined prelude member rename — the E0024
/// export-face enforcement fires (the rename domain does not weaken the
/// export-face check).
#[test]
fn neg_r135_prelude_undefined_member_e0024() {
    let e = run_source("use kerf_prelude::{nosuch as n};\n42", "pundef.ktf")
        .expect_err("not definition member rename must by E0024 rejected");
    assert!(
        e.rendered.contains("E0024") && e.rendered.contains("nosuch"),
        "not definition member anchor(actual: {})",
        e.rendered
    );
}

/// Negative / r135 D14: the prelude member-position non-symbol operand —
/// `{map as 123}` is the rename operand's dedicated expectation family
/// (byte-level error face on the target Reader).
#[test]
fn neg_r135_prelude_non_symbol_operand() {
    let e = run_source("use kerf_prelude::{map as 123};\n42", "poper.ktf")
        .expect_err("non-symbol rename right operand must be rejected");
    assert!(
        e.rendered.contains("expected a member rename identifier"),
        "prelude domain right operand anchor(actual: {})",
        e.rendered
    );
}

/// Negative / r135 D14-③: the incremental-alias semantics' local
/// availability on the **list-domain re-export** — `nth as at` keeps
/// `nth` itself usable (the flat double push) while `at` resolves through
/// the injected define; both produce the same value (the alias and the
/// local coexist — the contrast anchor with the seven modules'
/// replacement semantics where the underlying's direct write is E0022).
#[test]
fn neg_r135_prelude_nth_alias_and_local_coexist() {
    let v = run_value(
        "use kerf_prelude::{nth as at};\nat(list(7, 8), 1) + nth(list(7, 8), 1)",
        "pnth.ktf",
    );
    assert_eq!(
        v, "16",
        "nth rename and local coexist with same value 8+8(actual: {})",
        v
    );
}

// E6 close-out (r154 / 224-c4): corpus converted to the target-syntax face.
//! .ktf TC-SIGS oracle-parity family tests — r140 / 210-c (the registered
//! subset-asymmetry row cleared: check.krf `TC-SIGS` 24 -> 61 rows
//! isomorphic to the Rust oracle `BUILTIN_SIGS`, plus the sig-language
//! fixed extension; r144 / 214-c appended the read-line entry on both
//! faces — the family now holds 63 flat rows; r159 / 229-c appended the
//! percent row on both faces — the term-level infix primary face joins
//! the oracle table).
//!
//! **Verification surfaces** (design single source =
//! tc-sigs-parity-design.md v1.0):
//! (1) **run-face E2E** — representative members of every new shape
//! family (variadic / fixed homogeneous / `'sigf` heterogeneous) execute
//! with value anchors;
//! (2) **static enforcement** — the newly signed members now report
//! E0005 on concrete violations (the production face converges toward
//! the oracle; previously these walked the A4 Dynamic path);
//! (3) **per-position independence** — `'sigf` rows report the exact
//! violating position (nth pos-1 int / member pos-2 list /
//! string-substring pos-2/3 int — each position's violation is its own
//! diagnostic);
//! (4) **the tvar domain specialization** (D4) — Int params constrain
//! variables to the Num domain (NOT Int: a float flowing into an
//! index-like parameter position stays diagnostic-free — the
//! direction-guard defense mirror of the oracle `Num|Int =>
//! Some(Ty::Num)`);
//! (5) **the existing-row divergence fix** — string-append is fixed
//! 2-arg (1-arg and 3-arg calls fail statically, 2-arg passes; the
//! runtime has always been exactly 2-arg);
//! (6) **derived chains** — a renamed member's apply position enforces
//! through TC-RENAME -> TC-SIGS (the r135 derivation consumes the
//! expanded table automatically);
//! (7) **cross-stage consumption** — the check face produces a real
//! artifact on positive programs (zero diagnostics + compiled
//! prototypes) and negative programs report through the recovery
//! channel;
//! (8) **the <= oracle direction guard** — the same violation program
//! reports an equal count through both judgment program shapes
//! (per-member parity).
//!
//! Basis: member-rename-design.md §7 TC-SIGS row (registered trigger =
//! corpus/user signal — the r140 user instruction exercised the user
//! arm, M1 form #45) + hm.rs check_param_rule (oracle behavior spec) +
//! builtins.rs BUILTIN_SIGS (row-list single source). Ratio: 8 positive
//! : 24 negative = 1:3 (§9.4.3).
//!
//! E6 close-out (r154 / 224-c4): the S-expr seed face retired — the
//! former seed legs now drive the same target chain through alternate
//! program shapes (top-level case expressions, `define(x, v);` value
//! definitions, and `||`-closure bindings; E6-CG §2 skin dictionary),
//! while the fn-declaration legs keep the target shape; all
//! message/count anchors recalibrated by running.

use kerf_driver::{check_source_recover, run_source};

fn rendered(out: &kerf_driver::RunOutcome) -> String {
    kerf_vm::render_value(&out.value, &out.heap)
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/// Alternate program-shape static check: expect >= 1 diagnostic
/// containing `needle` (E6 close-out r154 / 224-c4: the S-expr seed face
/// retired — the former seed legs drive the same target chain through
/// the alternate program shapes: top-level case expressions /
/// `define(x, v);` value definitions / `||`-closure bindings).
fn expect_alt_diag(src: &str, needle: &str) {
    let report = check_source_recover(src, "tcsig.ktf").expect("check must pass compile");
    assert!(
        report
            .diagnostics
            .iter()
            .any(|d| d.message.contains(needle)),
        "alternate shape must report `{}`: actual {:?}",
        needle,
        report
            .diagnostics
            .iter()
            .map(|d| d.message.as_str())
            .collect::<Vec<_>>()
    );
}

/// Target-face (fn-declaration shape) static check: expect >= 1
/// diagnostic containing `needle`.
fn expect_target_diag(src: &str, needle: &str) {
    let report = check_source_recover(src, "tcsig.ktf").expect("check must pass compile");
    assert!(
        report
            .diagnostics
            .iter()
            .any(|d| d.message.contains(needle)),
        "target face must report `{}`: actual {:?}",
        needle,
        report
            .diagnostics
            .iter()
            .map(|d| d.message.as_str())
            .collect::<Vec<_>>()
    );
}

/// Both program shapes agree on the violation (alternate shape +
/// fn-declaration target shape).
fn expect_both_shapes_diag(src_alt: &str, src_target: &str, needle: &str) {
    expect_alt_diag(src_alt, needle);
    expect_target_diag(src_target, needle);
}

/// Alternate program-shape static check: zero diagnostics.
fn expect_alt_clean(src: &str) {
    let report = check_source_recover(src, "tcsigok.ktf").expect("check must pass compile");
    assert!(
        report.diagnostics.is_empty(),
        "alternate shape must be diagnostic-free: {:?}",
        report.rendered
    );
}

/// Target-face static check: zero diagnostics.
fn expect_target_clean(src: &str) {
    let report = check_source_recover(src, "tcsigok.ktf").expect("check must pass compile");
    assert!(
        report.diagnostics.is_empty(),
        "target face must be diagnostic-free: {:?}",
        report.rendered
    );
}

// ---------------------------------------------------------------------------
// Bucket P: positive (8)
// ---------------------------------------------------------------------------

/// P01: every new shape family executes with value anchors on both
/// program shapes — variadic (`list`/`vector`/`append`/`error`-free),
/// fixed homogeneous (`length`/`reverse`/`last-pair`/`string-length`),
/// and `'sigf` heterogeneous (`nth`/`member`/`assoc`/
/// `string-substring`).
#[test]
fn p01_all_shape_families_run_e2e_dual_shape() {
    let ktf = r#"import kerf_list;
import kerf_string;
import kerf_vector;
fn shapes() -> i64 {
    let l = list(1, 2, 3);
    let v = vector(4, 5);
    let n = nth(l, 1);
    let m = member(2, l);
    let a = assoc(1, list(list(1, "x")));
    let s = string_substring("abcdef", 1, 3);
    let ln = length(l);
    let r = reverse(l);
    let vl = vector_length(v);
    let vr = vector_ref(v, 0);
    if (is_pair(m) && (n == 2) && (ln == 3) && (vl == 2) && (vr == 4)) { 1 } else { 0 }
}
shapes()"#;
    let out = run_source(ktf, "shapes.ktf").expect("target run failed");
    let val = rendered(&out);
    assert!(val.contains("1"), "value anchor: actual {}", val);
    // The alternate shape on the same semantic core (define-value
    // definitions + a trailing-expression case — the E6 conversion of
    // the former seed leg).
    let alt = r#"import kerf_list;
import kerf_string;
import kerf_vector;
let l = list(1, 2, 3);
let v = vector(4, 5);
let n = nth(l, 1);
let m = member(2, l);
let a = assoc(1, list(list(1, "x")));
let s = string_substring("abcdef", 1, 3);
let ln = length(l);
let r = reverse(l);
let vl = vector_length(v);
let vr = vector_ref(v, 0);
if (is_pair(m) && (n == 2) && (ln == 3) && (vl == 2) && (vr == 4)) { 1 } else { 0 }"#;
    let out2 = run_source(alt, "shapes.ktf").expect("alternate-shape run failed");
    let val2 = rendered(&out2);
    assert!(
        val2.contains("1"),
        "alternate-shape value anchor: actual {}",
        val2
    );
}

/// P02: the newly signed members pass the static check on both program
/// shapes (the check face produces a real artifact — zero diagnostics
/// plus compiled prototypes).
#[test]
fn p02_new_members_check_clean_dual_shape() {
    expect_target_clean(
        "import kerf_list;\nimport kerf_string;\nfn f() -> i64 { length(list(1, 2)) + string_length(\"ab\") }",
    );
    expect_alt_clean(
        "import kerf_list;\nimport kerf_string;\nlength(list(1, 2)) + string_length(\"ab\")",
    );
}

/// P03: `'sigf` per-position scanning accepts tvars in list positions
/// (a parameter flowing into `nth` pos-0 stays legal — List params
/// impose no constraint on variables, D4). The alternate leg binds a
/// `||`-closure through `define` (the closure-value skin of the former
/// seed `define`-function form).
#[test]
fn p03_sigf_tvar_list_position_clean() {
    expect_alt_clean("import kerf_prelude;\nlet f = || (x: T) { nth(x, 0) };\nf(list(1, 2))");
    expect_target_clean("import kerf_prelude;\nfn f(x: T) -> T { nth(x, 0) }\nf(list(1, 2))");
}

/// P04: the tvar domain specialization (D4 direction-guard defense) —
/// Int params constrain variables to Num, NOT Int: a float flowing into
/// an index-like parameter position stays diagnostic-free (the
/// oracle's `Num|Int => Some(Ty::Num)` mirror).
#[test]
fn p04_int_param_tvar_num_domain_clean() {
    expect_alt_clean("import kerf_prelude;\nlet f = || (x: T) { nth(list(1, 2), x) };\nf(1.5)");
    expect_target_clean("import kerf_prelude;\nfn f(x: T) -> T { nth(list(1, 2), x) }\nf(1.5)");
}

/// P05: result-type mapping (D3) — `length` returns Int (flows into an
/// arithmetic position cleanly), variadic `list`/`append` return fresh
/// variables (flow into both pair positions and let bindings without
/// false positives), `print`/`newline` return Nil, `string-to-symbol`
/// returns Sym (a symbol used as a symbol). The former `(do ...)` body
/// is the statement-sequence shape (E6-CG §2).
#[test]
fn p05_result_type_mapping_clean() {
    expect_alt_clean(
        "import kerf_list;\nimport kerf_string;\nlength(list(1, 2)) + string_length(\"ab\")",
    );
    expect_alt_clean(
        "import kerf_io;\nimport kerf_string;\nrequire io, write;\nprint(\"x\");\nnewline();\nstring_to_symbol(\"a\")",
    );
}

/// P06: the existing-row divergence fix accepts exactly 2-arg
/// string-append on both program shapes (the runtime has always been
/// exactly 2-arg — `builtins.rs args.len() != 2 -> E0004`).
#[test]
fn p06_string_append_two_arg_clean() {
    expect_alt_clean("import kerf_string;\nstring_append(\"a\", \"b\")");
    expect_target_clean("import kerf_string;\nfn f() -> str { string_append(\"a\", \"b\") }");
}

/// P07: derived chains — a renamed member's apply position enforces
/// through TC-RENAME -> TC-SIGS against the expanded table (the r135
/// derivation consumes the 37 new rows automatically: a positive
/// renamed-`nth` call stays clean).
#[test]
fn p07_renamed_member_derivation_clean() {
    expect_target_clean("use kerf_list::{nth as pick};\npick(list(1, 2), 0)");
}

/// P08: cross-stage consumption — the corpus family stays
/// diagnostic-clean (fib through the production check chain; the usage
/// corpora do not trip the newly signed members). The alternate leg
/// uses the inline fib shape (r153 / 223-c: the .krf corpus face
/// retired — s-expr-removal-plan §4 Batch D; the corpus pair evidence
/// is archived in RELEASE r127-r152).
#[test]
fn p08_corpus_regression_check_clean() {
    let fib_ktf = include_str!("../../../../examples/usage/fib.ktf");
    expect_target_clean(fib_ktf);
    expect_alt_clean(
        "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(12)",
    );
}

// ---------------------------------------------------------------------------
// Bucket N: negative (24)
// ---------------------------------------------------------------------------

/// N01: the new `list` kind — concrete violations on both program
/// shapes (`length` on a str / `reverse` on an int).
#[test]
fn n01_list_kind_concrete_violation_dual_shape() {
    // r164/235-c: the static list-domain rows retired with the self-built
    // migration — the generic (T) face is static-clean for single-arg calls;
    // the runtime face carries the exact retired-Rust messages (both shapes).
    for s in [
        "import kerf_list;\nlength(\"s\")",
        "import kerf_list;\nfn f() -> i64 { length(\"s\") }\nf()",
        "import kerf_list;\nreverse(5)",
    ] {
        let e = run_source(s, "n01rt.ktf").expect_err("n01 run must fail");
        assert!(
            e.rendered.contains("requires list"),
            "n01 runtime: {}",
            e.rendered
        );
    }
}

/// N02: the new `int` kind — concrete violations (nth pos-1 on a str;
/// string-length is NOT int-param but vector-ref pos-1 stays any — the
/// exact violating position reports).
#[test]
fn n02_int_kind_concrete_violation() {
    // r164/235-c: nth's static int-domain retired — the (T,T) unification
    // reports the num/str conflict (fail-closed maintained); the runtime
    // face carries the exact message.
    expect_alt_diag(
        "import kerf_prelude;\nnth(list(1, 2), \"x\")",
        "type mismatch: num and str",
    );
    expect_target_diag(
        "import kerf_prelude;\nfn f() -> i64 { nth(list(1, 2), \"x\") }",
        "type mismatch: num and str",
    );
}

/// N03: the new `sym` kind — `symbol-to-string` on a str reports on
/// both program shapes.
#[test]
fn n03_sym_kind_concrete_violation() {
    expect_both_shapes_diag(
        "import kerf_string;\nsymbol_to_string(\"a\")",
        "import kerf_string;\nfn f() -> str { symbol_to_string(\"a\") }",
        "requires symbol",
    );
}

/// N04: the new `pair` kind — `last-pair` on nil reports (nil is NOT
/// ok for Pair params — the oracle's `Pair => Pair`-only mirror; both
/// shapes agree at judgment level).
#[test]
fn n04_pair_kind_nil_violation() {
    // concrete int (the Pair-only rule: nil is NOT ok either — but the
    // empty-list constructor returns a fresh variable which both shapes
    // pass constraint-free, so the int form pins the concrete arm)
    // r164/235-c: last-pair's static pair-domain retired — runtime face
    // carries the exact messages (int input / nil input each).
    for (s, needle) in [
        (
            "import kerf_list;\nlet x = last_pair(5);\nx",
            "last-pair requires list, got int",
        ),
        (
            "import kerf_list;\nlast_pair(5)",
            "last-pair requires list, got int",
        ),
        (
            "import kerf_list;\nlast_pair(quote(()))",
            "last-pair requires non-empty list",
        ),
    ] {
        let e = run_source(s, "n04rt.ktf").expect_err("n04 run must fail");
        assert!(e.rendered.contains(needle), "n04 runtime: {}", e.rendered);
    }
}

/// N05: `'sigf` per-position independence — `member` pos-2 list
/// violation with pos-1 clean (each violating position is its own
/// diagnostic).
#[test]
fn n05_sigf_member_pos2_violation() {
    expect_alt_diag("import kerf_list;\nmember(1, \"ab\")", "requires list");
    expect_target_diag(
        "import kerf_list;\nfn f() -> bool { member(1, \"ab\") }",
        "requires list",
    );
}

/// N06: `'sigf` per-position independence — `string-substring` pos-2
/// int violation with pos-0 str clean.
#[test]
fn n06_sigf_substring_pos2_violation() {
    expect_alt_diag(
        "import kerf_string;\nstring_substring(\"abc\", \"x\", 2)",
        "requires int",
    );
    expect_target_diag(
        "import kerf_string;\nfn f() -> str { string_substring(\"abc\", \"x\", 2) }",
        "requires int",
    );
}

/// N07: `'sigf` per-position independence — `string-substring` pos-3
/// int violation (both int positions report independently when both
/// violate).
#[test]
fn n07_sigf_substring_pos3_violation() {
    expect_alt_diag(
        "import kerf_string;\nstring_substring(\"abc\", 1, \"z\")",
        "requires int",
    );
}

/// N08: `'sigf` fixed arity — `nth` with 1 arg reports the count
/// mismatch on both program shapes.
#[test]
fn n08_sigf_arity_violation() {
    expect_both_shapes_diag(
        "import kerf_prelude;\nlet x = nth(list(1, 2));\nx",
        "import kerf_prelude;\nfn f() -> T { nth(list(1, 2)) }",
        "procedure argument count mismatch",
    );
}

/// N09: `'sigf` fixed arity — `nth` with 3 args (one too many).
#[test]
fn n09_sigf_arity_over() {
    expect_alt_diag(
        "import kerf_prelude;\nnth(list(1, 2), 0, 9)",
        "procedure argument count mismatch",
    );
}

/// N10: fixed homogeneous arity — `length` with 0 args (below the
/// minimum).
#[test]
fn n10_fixed_arity_below() {
    expect_both_shapes_diag(
        "import kerf_list;\nlength()",
        "import kerf_list;\nfn f() -> i64 { length() }",
        "procedure argument count mismatch",
    );
}

/// N11: fixed homogeneous arity — `print` with 2 args (above the
/// maximum).
#[test]
fn n11_fixed_arity_above() {
    expect_alt_diag(
        "import kerf_io;\nrequire io, write;\nprint(1, 2)",
        "procedure argument count mismatch",
    );
}

/// N12: variadic minimum — `error` with 0 args (below the 1-arg floor).
#[test]
fn n12_variadic_floor() {
    expect_both_shapes_diag(
        "let x = error();\nx",
        "fn f() -> T { error() }",
        "procedure argument count mismatch",
    );
}

/// N13: the existing-row divergence fix — 1-arg string-append now
/// fails statically on both program shapes (previously only E0004 at
/// runtime).
#[test]
fn n13_string_append_one_arg_static_reject() {
    expect_both_shapes_diag(
        "import kerf_string;\nstring_append(\"a\")",
        "import kerf_string;\nfn f() -> str { string_append(\"a\") }",
        "procedure argument count mismatch",
    );
}

/// N14: the existing-row divergence fix — 3-arg string-append fails
/// statically (the nested-binary canonical form is the legal
/// spelling).
#[test]
fn n14_string_append_three_arg_static_reject() {
    expect_alt_diag(
        "import kerf_string;\nstring_append(\"a\", \"b\", \"c\")",
        "procedure argument count mismatch",
    );
}

/// N15: the str-kind family on the new members — `write-string` on an
/// int reports on both program shapes.
#[test]
fn n15_str_kind_new_member() {
    expect_both_shapes_diag(
        "import kerf_io;\nrequire io, write;\nwrite_string(5)",
        "require io, write;\nimport kerf_io;\nfn f() -> T { write_string(5) }",
        "requires str",
    );
}

/// N16: result-type consumption — `string-length` returns Int, so its
/// result flowing into a str position reports downstream (the D3
/// concrete result mapping has enforcement teeth).
#[test]
fn n16_result_int_consumption_violation() {
    expect_alt_diag(
        "import kerf_string;\nsymbol_to_string(string_length(\"ab\"))",
        "requires symbol",
    );
}

/// N17: the num-into-int index family (the corpus drift class) — a
/// `mod` result (Num) flowing into `nth` pos-1 reports exactly like
/// the oracle's "nth requires int, got num" judgment (both shapes
/// agree; this is the adjudicated true-detection class behind the
/// r140 anchor re-pins; `mod` keeps its call form on the target face).
#[test]
fn n17_num_into_int_index_family() {
    // r164/235-c: the num-into-int index family is now a generic unification
    // (num unifies with T — statically legal); the runtime out-of-range face
    // carries the enforcement (index 5 beyond the 2-element list).
    let e17 = run_source(
        "import kerf_prelude;\nnth(list(1, 2), mod(5, 10))",
        "n17rt.ktf",
    )
    .expect_err("n17 run must fail (out of range)");
    assert!(
        e17.rendered.contains("nth index 5 out of list range"),
        "n17 runtime: {}",
        e17.rendered
    );
}

/// N18: derived-chain enforcement — a renamed member's apply position
/// reports through TC-RENAME -> TC-SIGS (the r135 derivation chain now
/// enforces the expanded table: renamed `nth` pos-1 violation).
#[test]
fn n18_renamed_member_derivation_violation() {
    // kerf-list (NOT kerf-prelude — prelude renames are Stx-injected
    // local defines, the r135 D14 A4 face; list-module renames carry the
    // derivation chain)
    // r164/235-c: the TC-RENAME derivation chain consults the SIGS table —
    // nth's row retired with the self-built migration, so the renamed
    // member's static derivation is clean; the runtime face enforces
    // through the injected define's closure.
    let e18 = run_source(
        "use kerf_list::{nth as pick};\npick(list(1, 2), \"x\")",
        "n18rt.ktf",
    )
    .expect_err("n18 run must fail");
    assert!(
        e18.rendered.contains("nth index requires int, got str"),
        "n18 runtime: {}",
        e18.rendered
    );
}

/// N19: derived-chain rename of a str-kind member — renamed
/// `write-string` on an int (the io rename derivation + the new str
/// signature row).
#[test]
fn n19_renamed_str_member_violation() {
    expect_target_diag(
        "require io, write;\nuse kerf_io::{write_string as ws};\nws(5)",
        "requires str",
    );
}

/// N20: the runtime/static agreement boundary — a static violation
/// ALSO fails at runtime when executed (the check face and the run
/// face stay coherent: `length("s")` is an E0004 at runtime and an
/// E0005 at check).
#[test]
fn n20_run_face_runtime_error_agreement() {
    let out = run_source("import kerf_list;\nlength(\"s\")", "n20.ktf");
    assert!(
        out.is_err(),
        "runtime must also reject: {:?}",
        out.err().map(|e| e.rendered)
    );
}

/// N21: check-face recovery channel — a multi-violation program collects
/// both diagnostics (per-argument continuation, the r126 discipline
/// extended to the new kinds: two independent violations both surface).
#[test]
fn n21_multi_violation_collection() {
    // r164/235-c: both static list-domain rows retired — the runtime face
    // enforces in order (the first failing form aborts with the exact message).
    let report = check_source_recover("import kerf_list;\nlength(\"s\")\nreverse(5)", "n21.ktf")
        .expect("check must pass compile");
    assert_eq!(
        report.diagnostics.len(),
        0,
        "the generic faces are static-clean: {:?}",
        report.rendered
    );
    let e21 = run_source("import kerf_list;\nlength(\"s\")\nreverse(5)", "n21.ktf")
        .expect_err("n21 run must fail");
    assert!(
        e21.rendered.contains("length requires list"),
        "n21 runtime: {}",
        e21.rendered
    );
}

/// N22: `'sigf` pos-0 + pos-1 both violating — both positions report
/// (nth on a str with a str index: two independent diagnostics).
#[test]
fn n22_sigf_double_position_violation() {
    // r164/235-c: the (T,T) unification of two str args is conflict-free —
    // statically clean; the runtime face enforces the index domain.
    // r164/235-c: the generic body's numeric comparisons (`n < 0`, `k - 1`)
    // constrain the index parameter to num — the (T,T) call with two strs
    // reports the num/str unification conflict statically (an HONESTLY
    // stricter type face than the retired positional sigf row — the
    // fail-closed direction preserved); the runtime face enforces too.
    let report = check_source_recover("import kerf_prelude;\nnth(\"ab\", \"x\")", "n22.ktf")
        .expect("check must pass compile");
    assert_eq!(
        report.diagnostics.len(),
        1,
        "static face: {:?}",
        report.rendered
    );
    let e22 = run_source("import kerf_prelude;\nnth(\"ab\", \"x\")", "n22.ktf")
        .expect_err("n22 run must fail");
    assert!(
        e22.rendered.contains("nth index requires int, got str"),
        "n22 runtime: {}",
        e22.rendered
    );
}

/// N23: `assert-eq` fixed 2-arg homogeneous row — 3-arg call reports
/// (the test-assertion builtin now has a static arity face).
#[test]
fn n23_assert_eq_arity() {
    expect_alt_diag("assert_eq(1, 2, 3)", "procedure argument count mismatch");
}

/// N24: `newline`/`read-int` zero-arg rows — `newline` with 1 arg
/// reports (the fixed empty-param arity face).
#[test]
fn n24_newline_zero_arg_arity() {
    expect_both_shapes_diag(
        "import kerf_io;\nrequire io, write;\nnewline(1)",
        "require io, write;\nimport kerf_io;\nfn f() -> T { newline(1) }",
        "procedure argument count mismatch",
    );
}

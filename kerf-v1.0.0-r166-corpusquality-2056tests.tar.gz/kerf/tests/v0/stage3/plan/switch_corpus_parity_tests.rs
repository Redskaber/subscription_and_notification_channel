//! Switch-window step (3) corpus-rewrite parity gate (r109 / 179-c —
//! first batch: preamble.ktf).
//!
//! E6 close-out (r154 / 224-b3): the S-expr↔target corpus-parity legs
//! (the assert_skin_mapping skin-dictionary comparisons through the
//! deleted classic S-expr Reader) and the S-expr user-face behavior legs
//! (run_source / run_source_seed / bootstrap::read_source /
//! reader-state install-reset) retired — duty complete, principle 41
//! demolition after validation. The surviving duty = the two-path faces
//! (seed Reader ↔ .ktf-bridge Reader, seed expander ↔ self-hosted
//! expander, seed compiler ↔ self-hosted compiler), the step-(4)
//! fixpoint gates (B₁'/B₂', cross-chain by name, B₁' executability),
//! and the target-side behavioral regressions — all .ktf-only. The
//! reader.ktf artifact is the renamed reader.ktf (224-a — the
//! read-bridge's own program; the r110 S-expr-Reader corpus was retired
//! with its bootstrap state).
//!
//! **Verification face** (post-E6):
//! (1) **skin-dictionary name mapping** (`-` ↔ `_`) — symbol-introduction
//! consistency of the seed ↔ bridge dual-side target Readers (Stx canonical
//! rendering at byte level) + single-point mapping behavior (bare `_`
//! identity / no-underscore identity / path-segment mapping);
//! (2) **module import/export header grammar domain** (N1 module
//! production-face skin entries) — dual-side Reader Stx parity + error-path
//! message/Span parity (as-alias out-of-domain fail-closed);
//! (3) **bootstrap .ktf corpus-rewrite two-path parity** — each .ktf
//! artifact through the seed Reader (oracle path) ↔ through the
//! .ktf read-bridge Reader (production path) in **dual-path bytecode
//! equality** (instruction order / constant pool / proto shapes /
//! global-reference face — the r106 SyntaxTransitionValidator discipline:
//! debug_spans are cross-text incomparable [by design] — explicitly
//! excluded from the comparison domain; the S-expr-original baseline leg
//! was retired with the deleted .krf originals by the E5 close-out
//! cleanup batch r120 / 190-a, principle 41);
//! (4) **behavioral equivalence** (end-to-end VM value equality through
//! the target user face — prelude-importing programs on both injection
//! paths: production run_source / seed run_source_seed);
//! (5) **dual-expander parity** (.ktf forms via the seed expander ↔ the
//! self-hosted expander — the E1-β discipline extended to the corpus);
//! (6) **liveness probes** (production/seed prelude injection + the
//! .ktf-loaded bootstrap states = proof that the target-Reader wiring
//! is live).
//!
//! Basis: principle 31 (skin/skeleton isomorphism) / 07 §3.2.1 (five-step
//! process, step (3)) / 02 §8.13 (EBNF v9 Level 0 + r109 additions: module
//! import/export headers) / 20 §14 (skin-dictionary finalized-domain
//! extension — the r109 name-mapping entry) / replacement-face map §3.1
//! (class-C corpus per-file order — preamble first) / E6-CG §1+§4 (the
//! r154 close-out dispositions).

use kerf_compiler::{compile_module, BcProgram};
use kerf_driver::bootstrap::expander::expand_program;
use kerf_driver::bootstrap::reader::read_source_for_bootstrap;
use kerf_driver::{
    production_prelude_is_ktf_reader, run_source, run_source_seed, seed_prelude_is_seed_reader,
};
use kerf_expander::{expand_program as expand_program_seed, ExpandCtxt};
use kerf_reader::{read_source, symbol_name};
use kerf_syntax::{Stx, StxDatum, StxLiteral, SymbolTable};
use kerf_vm::render_value;

/// Target-syntax production artifact (switch-window step (3), first-batch
/// rewrite).
const PREAMBLE_TARGET: &str =
    include_str!("../../../../crates/kerf-driver/src/bootstrap/preamble.ktf");

// ---------------------------------------------------------------------------
// Infrastructure: Stx canonical rendering (symbol names + literal values +
// Span bytes — naturally comparable across both sides for same-source
// text) + bytecode semantic-payload comparison (instruction order +
// constant pool + proto shapes + global face — the cross-text comparison
// domain, debug_spans explicitly excluded [by design])
// ---------------------------------------------------------------------------

fn render_stx(s: &Stx, t: &SymbolTable) -> String {
    let mut out = String::new();
    render_stx_into(s, t, &mut out);
    out
}

fn render_stx_into(s: &Stx, t: &SymbolTable, out: &mut String) {
    match &s.datum {
        StxDatum::Symbol(sym) => {
            out.push_str(&format!(
                "(sym {} {}..{})",
                t.name(*sym),
                s.span.start,
                s.span.end
            ));
        }
        StxDatum::Literal(l) => match l {
            StxLiteral::Int(v) => {
                out.push_str(&format!("(int {} {}..{})", v, s.span.start, s.span.end));
            }
            StxLiteral::Float(f) => {
                out.push_str(&format!("(float {:?} {}..{})", f, s.span.start, s.span.end));
            }
            StxLiteral::Str(r) => {
                out.push_str(&format!("(str {:?} {}..{})", r, s.span.start, s.span.end));
            }
            StxLiteral::Bool(b) => {
                out.push_str(&format!("(bool {} {}..{})", b, s.span.start, s.span.end));
            }
            StxLiteral::Nil => {
                out.push_str(&format!("(nil {}..{})", s.span.start, s.span.end));
            }
        },
        StxDatum::List(items) => {
            out.push_str(&format!("(lst {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
        StxDatum::Vector(_) => out.push_str("(vector)"),
    }
}

/// Dual-side target-Reader Stx parity (same-source text — Span bytes are
/// naturally comparable).
fn assert_reader_stx_parity(src: &str, what: &str) {
    let mut t1 = SymbolTable::new();
    let seed = read_source(src, 0, &mut t1)
        .unwrap_or_else(|e| panic!("[{}] seed goal Reader parse failed:{}", what, e.message));
    let mut t2 = SymbolTable::new();
    let krf = read_source_for_bootstrap(src, 0, &mut t2)
        .unwrap_or_else(|e| panic!("[{}] .krf goal Reader parse failed:{}", what, e.message));
    assert_eq!(
        seed.len(),
        krf.len(),
        "[{}] top-level form count mismatch",
        what
    );
    for (i, (a, b)) in seed.iter().zip(krf.iter()).enumerate() {
        assert_eq!(
            render_stx(a, &t1),
            render_stx(b, &t2),
            "[{}] form #{} Stx canonical render mismatch(naming map dual-side drift)",
            what,
            i
        );
    }
}

/// Dual-side target-Reader error parity (message + Span bytes).
fn assert_reader_err_parity(src: &str, what: &str) -> String {
    let seed_err = match read_source(src, 0, &mut SymbolTable::new()) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] seed should be an error (actually parsed successfully)",
            what
        ),
    };
    let krf_err = match read_source_for_bootstrap(src, 0, &mut SymbolTable::new()) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] .krf should be an error (actually parsed successfully)",
            what
        ),
    };
    assert_eq!(
        seed_err.message, krf_err.message,
        "[{}] error message mismatch (seed {:?} vs .krf {:?})",
        what, seed_err.message, krf_err.message
    );
    assert_eq!(
        seed_err.span.start, krf_err.span.start,
        "[{}] error Span start mismatch",
        what
    );
    assert_eq!(
        seed_err.span.end, krf_err.span.end,
        "[{}] error Span end mismatch",
        what
    );
    seed_err.message.clone()
}

/// Bytecode semantic-payload equality (r106 SyntaxTransitionValidator
/// discipline — instruction order + constant pool + proto shapes +
/// global-reference face; debug_spans cross-text incomparable, explicitly
/// excluded).
fn assert_same_bytecode(a: &BcProgram, b: &BcProgram, what: &str) {
    assert_eq!(
        a.protos.len(),
        b.protos.len(),
        "[{}] prototype count mismatch",
        what
    );
    for (i, (pa, pb)) in a.protos.iter().zip(b.protos.iter()).enumerate() {
        assert_eq!(
            pa.code, pb.code,
            "[{}] prototype {} instruction sequence mismatch",
            what, i
        );
        assert_eq!(
            pa.params.len(),
            pb.params.len(),
            "[{}] prototype {} argument count",
            what,
            i
        );
        assert_eq!(
            pa.n_locals, pb.n_locals,
            "[{}] prototype {} local slot count",
            what, i
        );
        assert_eq!(
            pa.capture_names.len(),
            pb.capture_names.len(),
            "[{}] prototype {} capture count",
            what,
            i
        );
    }
    assert_eq!(a.consts, b.consts, "[{}] constant pool mismatch", what);
    assert_eq!(
        a.global_refs, b.global_refs,
        "[{}] global reference face mismatch",
        what
    );
}

/// Name-normalized bytecode comparison (E6 r154 / 224-c6: cross-table
/// oracle form — the production chain and the seed reconstruction own
/// separate SymbolTables whose intern order legitimately differs; symbol
/// identity is name-stable across tables, so consts/global_refs compare
/// by resolved name — the c3 vector-parity precedent).
fn assert_same_bytecode_named(
    a: &BcProgram,
    ta: &SymbolTable,
    b: &BcProgram,
    tb: &SymbolTable,
    what: &str,
) {
    assert_eq!(
        a.protos.len(),
        b.protos.len(),
        "[{}] prototype count mismatch",
        what
    );
    for (i, (pa, pb)) in a.protos.iter().zip(b.protos.iter()).enumerate() {
        assert_eq!(
            pa.code, pb.code,
            "[{}] prototype {} instruction sequence mismatch",
            what, i
        );
        assert_eq!(
            pa.params.len(),
            pb.params.len(),
            "[{}] prototype {} argument count",
            what,
            i
        );
        assert_eq!(
            pa.n_locals, pb.n_locals,
            "[{}] prototype {} local slot count",
            what, i
        );
        assert_eq!(
            pa.capture_names.len(),
            pb.capture_names.len(),
            "[{}] prototype {} capture count",
            what,
            i
        );
    }
    let norm = |c: &kerf_compiler::BcConst, t: &SymbolTable| -> String {
        match c {
            kerf_compiler::BcConst::Symbol(s) => format!("sym:{}", t.name(*s)),
            other => format!("{:?}", other),
        }
    };
    let ca: Vec<String> = a.consts.iter().map(|c| norm(c, ta)).collect();
    let cb: Vec<String> = b.consts.iter().map(|c| norm(c, tb)).collect();
    assert_eq!(ca, cb, "[{}] constant pool mismatch(name-normalized)", what);
    let ga: Vec<String> = a
        .global_refs
        .iter()
        .map(|s| ta.name(*s).to_string())
        .collect();
    let gb: Vec<String> = b
        .global_refs
        .iter()
        .map(|s| tb.name(*s).to_string())
        .collect();
    assert_eq!(
        ga, gb,
        "[{}] global reference face mismatch(name-normalized)",
        what
    );
}

/// Compile path: Stx forms → seed expansion → seed compilation (E1-β/I1
/// front-end isomorphism — the expand/compile stages are orthogonal to the
/// Reader, so the Reader is the only comparison variable; the table is
/// carried through (ExpandCtxt ownership contract — driver-isomorphic).
fn compile_forms_seed(forms: &[Stx], table: SymbolTable, what: &str) -> (BcProgram, SymbolTable) {
    let mut ectx = ExpandCtxt::new(table);
    let core = expand_program_seed(forms, &mut ectx)
        .unwrap_or_else(|e| panic!("[{}] seed expansion failed:{}", what, e.message));
    let program = compile_module(&core)
        .unwrap_or_else(|e| panic!("[{}] seed compile failed: {}", what, e.message));
    (program, ectx.table)
}

// ---------------------------------------------------------------------------
// (1) Skin-dictionary name mapping (`-` ↔ `_`)
// ---------------------------------------------------------------------------

/// Name-mapping single-point behavior: bare `_` identity / no-underscore
/// identity / multi-underscore fully mapped / path segments (`/`-separated)
/// untouched.
#[test]
fn naming_mapping_unit_behavior() {
    assert_eq!(
        symbol_name("_"),
        "_",
        "bare _ identity(placeholder semantics)"
    );
    assert_eq!(symbol_name("map"), "map", "no-underscore identity");
    assert_eq!(symbol_name("is_nil"), "is-nil", "word-separator mapping");
    assert_eq!(
        symbol_name("kerf_prelude"),
        "kerf-prelude",
        "module name map"
    );
    assert_eq!(symbol_name("for_each"), "for-each", "export name map");
    assert_eq!(
        symbol_name("kerf_list/map"),
        "kerf-list/map",
        "path segment map(/ separator does not disturb)"
    );
    assert_eq!(
        symbol_name("string_append"),
        "string-append",
        "builtin name map"
    );
}

/// Name-mapping dual-side Reader Stx parity: an underscore-heavy identifier
/// source parsed by the seed ↔ .krf dual-side target Readers — canonical
/// rendering (symbol names in mapped form + Spans) fully equal.
#[test]
fn naming_parity_seed_vs_bootstrap_reader() {
    assert_reader_stx_parity(
        "fn is_nil_pair(x: T) { is_nil(x) }\nis_nil_pair(nil)",
        "underscore identifier + builtin reference",
    );
    assert_reader_stx_parity(
        "module kerf_list { fn string_append(a: T, b: T) { string_append(a, b) } }\nkerf_list::string_append(1, 2)",
        "module name + path-segment underscore",
    );
    assert_reader_stx_parity(
        "fn f(x: T) { let my_var = x + 1; let other_val = my_var + 2; other_val }\nf(1)",
        "local variable underscore(fn body statement position)",
    );
}

/// Name-mapping end to end: a target-syntax program calling hyphenated
/// builtins (is_nil/for-each families) through both Readers → seed
/// expansion and compilation — bytecode equality (same table — the symbol
/// domain is normalization-comparable, r106 discipline) + behavioral
/// equivalence (VM value equality).
#[test]
fn naming_bytecode_and_behavior_end_to_end() {
    use kerf_driver::builtins::register_globals;
    use kerf_driver::capability::IoGrant;
    use kerf_runtime::Heap;
    use kerf_vm::{run_program, Value};

    let src = "fn double(x: T) { x + x }\n\
               fn keep_if(x: T) { is_nil(nil) }\n\
               double(21)";
    // Same table, three sequential reads (an s-expr seed baseline does not
    // apply — this source is all target syntax; the dual-side target
    // Readers share the table in order → symbol-domain normalization
    // comparability)
    let mut t0 = SymbolTable::new();
    let f1 =
        read_source(src, 0, &mut t0).unwrap_or_else(|e| panic!("seed parse failed: {}", e.message));
    let (p1, mut t0) = compile_forms_seed(&f1, t0, "seed naming end-to-end");
    let f2 = read_source_for_bootstrap(src, 1, &mut t0)
        .unwrap_or_else(|e| panic!(".krf parse failed:{}", e.message));
    let (p2, mut t0) = compile_forms_seed(&f2, t0, ".krf naming end-to-end");
    assert_same_bytecode(&p1, &p2, "naming map both sides bytecode");

    // Behavioral equivalence: the same program executed twice (determinism anchor —
    // register_globals double registration on the same table)
    let mut g1 = register_globals(&mut t0, &IoGrant::none());
    let mut h1 = Heap::new();
    let v1 = run_program(&p2, &mut g1, &mut h1)
        .unwrap_or_else(|e| panic!("VM execution failed:{:?}", e));
    let mut g2 = register_globals(&mut t0, &IoGrant::none());
    let mut h2 = Heap::new();
    let v2 = run_program(&p2, &mut g2, &mut h2)
        .unwrap_or_else(|e| panic!("VM repeated execution failed:{:?}", e));
    assert_eq!(v1, v2);
    assert_eq!(v1, Value::Int(42), "double(21) ⇒ 42");
}

// ---------------------------------------------------------------------------
// (2) Module import/export header grammar domain (N1 module production-face skin entries)
// ---------------------------------------------------------------------------

/// import/export header dual-side Stx parity: headers inside a module
/// (import → export → body-form order — compatible with the expander's
/// header scan order) + top-level import + path-shaped import names +
/// single-name/multi-name/line-crossing.
#[test]
fn module_import_export_forms_parity() {
    assert_reader_stx_parity(
        "module m {\n    import a, b, c;\n    export x, y;\n    fn f(v: T) { v }\n}",
        "module header all form",
    );
    assert_reader_stx_parity(
        "import kerf_list, kerf_string;\nfn g(v: T) { v }",
        "top level import(reader.krf batch pre-laid form)",
    );
    assert_reader_stx_parity(
        "module m { import a::b, c; export x; }",
        "path form import name + single name export",
    );
    assert_reader_stx_parity(
        "module m {\n    import a,\n           b;\n    export x,\n           y;\n}",
        "cross-line multi-name table",
    );
    assert_reader_stx_parity(
        "import kerf_prelude;\nmap(1, 2)",
        "kerf-prelude import name (naming map face)",
    );
}

/// import/export error-path dual-side parity: missing name / missing
/// semicolon / as-alias out-of-domain / illegal name token — message +
/// Span fully equal (fail-closed diagnostic face).
///
/// r130 / 200-b update: the m3 anchor `import a as b;` moved from the
/// out-of-domain fail-closed face to VALID syntax (the tenth skin
/// mapping — the alias pair `import a as b;` → `(import a as b)`); the
/// error-path slot is re-anchored on the missing-alias-operand shape and
/// the name-position `as` shape (the ktf_import_alias_tests.rs family is
/// the full carrier — this keeps the module-level parity net complete).
#[test]
fn module_import_export_error_parity() {
    let m1 = assert_reader_err_parity("import;", "import zero names");
    assert!(
        m1.contains("expected an import name"),
        "message anchor: {:?}",
        m1
    );
    let m2 = assert_reader_err_parity("import a, b", "import missing semicolon");
    assert!(m2.contains("expected ;"), "message anchor: {:?}", m2);
    let m3 = assert_reader_err_parity("import a as;", "import as missing alias");
    assert!(
        m3.contains("expected an alias identifier"),
        "message anchor: {:?}",
        m3
    );
    let m4 = assert_reader_err_parity("export;", "export zero names");
    assert!(
        m4.contains("expected an export name"),
        "message anchor: {:?}",
        m4
    );
    let m5 = assert_reader_err_parity("export 5;", "export non-identifier");
    assert!(
        m5.contains("expected an export name"),
        "message anchor: {:?}",
        m5
    );
}

// ---------------------------------------------------------------------------
// (3) preamble.ktf corpus-rewrite parity (three-way bytecode equality)
// ---------------------------------------------------------------------------

/// .ktf structure anchor: module name kerf-prelude + three imports + 20
/// exported names + five defines — both Readers produce the same structure
/// (post-name-mapping symbol domain).
#[test]
fn ktf_preamble_module_structure() {
    for what in ["seed goal Reader", ".krf goal Reader"] {
        let mut t = SymbolTable::new();
        let forms = if what == "seed goal Reader" {
            read_source(PREAMBLE_TARGET, 0, &mut t)
                .unwrap_or_else(|e| panic!("[{}] parse failed:{}", what, e.message))
        } else {
            read_source_for_bootstrap(PREAMBLE_TARGET, 0, &mut t)
                .unwrap_or_else(|e| panic!("[{}] parse failed:{}", what, e.message))
        };
        assert_eq!(forms.len(), 1, "[{}] single module form", what);
        let items = match &forms[0].datum {
            StxDatum::List(l) => l,
            _ => panic!("[{}] top level should be module list form", what),
        };
        assert!(
            items.len() >= 3,
            "[{}] module at least two header items + body",
            what
        );
        // Header order: module kerf-prelude (import ...) (export ...) defines...
        let head = t
            .name(match &items[0].datum {
                StxDatum::Symbol(s) => *s,
                _ => panic!("[{}] head symbol missing", what),
            })
            .to_string();
        assert_eq!(head, "module", "[{}] head symbol", what);
        let name = t
            .name(match &items[1].datum {
                StxDatum::Symbol(s) => *s,
                _ => panic!("[{}] module name missing", what),
            })
            .to_string();
        assert_eq!(
            name, "kerf-prelude",
            "[{}] module name (naming map after)",
            what
        );
        // import header
        let import_head = t
            .name(match &items[2].datum {
                StxDatum::List(l) => match &l[0].datum {
                    StxDatum::Symbol(s) => *s,
                    _ => panic!("[{}] import head symbol missing", what),
                },
                _ => panic!("[{}] import form missing", what),
            })
            .to_string();
        assert_eq!(import_head, "import", "[{}] import header in place", what);
        // export header: 20 names
        let export_items = match &items[3].datum {
            StxDatum::List(l) => l,
            _ => panic!("[{}] export form missing", what),
        };
        assert_eq!(
            t.name(match &export_items[0].datum {
                StxDatum::Symbol(s) => *s,
                _ => panic!("[{}] export head symbol missing", what),
            }),
            "export"
        );
        assert_eq!(
            export_items.len(),
            21,
            "[{}] export 20 name + head symbol",
            what
        );
        // five define body forms
        let defines = items.len() - 4;
        assert_eq!(defines, 5, "[{}] five define body form", what);
        // Export-name-list anchor (post-name-mapping symbol domain)
        let export_names: Vec<String> = export_items[1..]
            .iter()
            .map(|s| {
                t.name(match &s.datum {
                    StxDatum::Symbol(sym) => *sym,
                    _ => panic!("[{}] export item should be symbol", what),
                })
                .to_string()
            })
            .collect();
        for expected in [
            "map",
            "filter",
            "foldl",
            "foldr",
            "for-each",
            "cons",
            "head",
            "tail",
            "nth",
            "drop",
            "is-nil",
            "is-bool",
            "is-int",
            "is-float",
            "is-number",
            "is-string",
            "is-symbol",
            "is-pair",
            "is-list",
            "is-procedure",
        ] {
            assert!(
                export_names.contains(&expected.to_string()),
                "[{}] export missing name {}(actual {:?})",
                what,
                expected,
                export_names
            );
        }
    }
}
/// **Core gate** (dual-path form since the E5 close-out cleanup batch
/// r120 / 190-a, principle 41 — the S-expr original baseline leg was
/// retired with the deleted .krf originals; the three-way equivalence it
/// proved is archived in RELEASE r109-r119): preamble.ktf through the
/// seed Reader (oracle path) ↔ through the .krf target-Reader
/// bridge (production path — 07 §3.2.1 step (3) re-parsing literal
/// semantics). The Reader is the only variable (the expand/compile stages
/// stay seed).
#[test]
fn ktf_preamble_bytecode_parity_dual_path() {
    // (1) Oracle path: the .ktf through the seed Reader
    let mut t0 = SymbolTable::new();
    let f1 = read_source(PREAMBLE_TARGET, 1, &mut t0)
        .unwrap_or_else(|e| panic!(".ktf seed parse failed: {}", e.message));
    let (p1, mut t0) = compile_forms_seed(&f1, t0, ".ktf seed goal Reader");

    // (2) Production path: the .ktf through the .krf reader bridge
    // (same table — symbol-domain normalization comparability)
    let f2 = read_source_for_bootstrap(PREAMBLE_TARGET, 2, &mut t0)
        .unwrap_or_else(|e| panic!(".ktf bridge parse failed:{}", e.message));
    let (p2, _t0) = compile_forms_seed(&f2, t0, ".ktf .krf goal Reader bridge");

    assert_same_bytecode(&p1, &p2, ".ktf seed ↔ production path");
}

/// Behavioral equivalence: a prelude-importing program end to end
/// (consuming map/filter/foldl/foldr/for-each in full) via the production
/// run path (run_source — the target user face, prelude injected
/// through the .ktf read bridge) — VM value rendering anchor
/// (the S-expr twin corpus retired at the E6 close-out; the target-face
/// conversion carries the same consumption profile, E6-CG §2 skin
/// dictionary: closures for the operator-position arguments).
#[test]
fn ktf_prelude_behavior_parity_production() {
    let src = "import kerf_prelude;\n\
               fn square(x: i64) -> i64 { x * x }\n\
               let data = cons(1, cons(2, cons(3, cons(4, cons(5, ())))));\n\
               let mapped = map(square, data);\n\
               let filtered = filter(|| (x: i64) { x > 2 }, mapped);\n\
               let summed = foldl(|| (a: i64, b: i64) { a + b }, 0, filtered);\n\
               let folded = foldr(|| (a: i64, b: i64) { a - b }, 0, cons(1, cons(2, ())));\n\
               for_each(|| (x: i64) { x }, data);\n\
               cons(summed, folded)";
    let out = run_source(src, "behavior.ktf").expect("production path execution failed");
    let printed = render_value(&out.value, &out.heap);
    // map square ⇒ (1 4 9 16 25); filter >2 ⇒ (4 9 16 25); foldl + 0 ⇒ 54
    // foldr - 0 over (1 2) ⇒ 1-(2-0) = -1 ⇒ (54 . -1)
    assert_eq!(printed, "(54 . -1)", "behavior anchor (render basis)");
    assert!(
        production_prelude_is_ktf_reader(),
        "liveness probe: production prelude injection should go through the target Reader bridge"
    );
}

/// Dual-expander parity: .ktf forms through the seed expander ↔ the
/// self-hosted expander (expander.krf on the VM) — the E1-β discipline
/// extended to the new corpus (bytecode equality; same table — symbol-
/// domain normalization comparability).
#[test]
fn ktf_preamble_seed_vs_bootstrap_expander() {
    let mut t0 = SymbolTable::new();
    let f1 = read_source(PREAMBLE_TARGET, 0, &mut t0)
        .unwrap_or_else(|e| panic!("seed parse failed: {}", e.message));
    let (p1, mut t0) = compile_forms_seed(&f1, t0, "seed expansion");

    let f2 = read_source(PREAMBLE_TARGET, 0, &mut t0)
        .unwrap_or_else(|e| panic!("second-read parse failed:{}", e.message));
    let core2 = expand_program(&f2, 0, &mut t0)
        .unwrap_or_else(|e| panic!("bootstrap expansion failed: {}", e.message));
    let p2 = compile_module(&core2).unwrap_or_else(|e| panic!("compile failed:{}", e.message));

    assert_same_bytecode(&p1, &p2, ".ktf seed expansion ↔ bootstrap expansion");
}

/// Seed-pipeline injection path: run_source_seed on a
/// prelude-importing program — the .ktf injected through the seed
/// target Reader (the r6 symmetric side) + liveness probe + behavior
/// anchor (target face; the E6 replacement for run_source_seed —
/// E6-CG §1).
#[test]
fn ktf_prelude_seed_pipeline_injection() {
    let src = "import kerf_prelude;\nmap(|| (x: i64) { x + 1 }, list(1, 2))";
    let out = run_source_seed(src, "seed_inject.ktf").expect("seed pipeline execution failed");
    let printed = render_value(&out.value, &out.heap);
    assert_eq!(
        printed, "(2 3)",
        "seed pipeline behavior anchor (render basis)"
    );
    assert!(
        seed_prelude_is_seed_reader(),
        "liveness probe: seed path prelude injection should via seed goal Reader"
    );
}

/// Redefinition-diagnostic parity: the user redefines a prelude name (map)
/// — error rendering fully equal across the two .ktf injection paths
/// (production run_source = bridge path / seed
/// run_source_seed = seed target-Reader path) (E0004 duplicate
/// definition — structural proof that the same-named global face is
/// registered from the .ktf module defines on both paths; same source
/// and file name → Span/excerpt equality).
#[test]
fn ktf_prelude_redefinition_diagnostic() {
    let src = "import kerf_prelude;\nfn map(f: T, lst: T) { f(lst) }\nmap(1, 2)";
    let prod_err = run_source(src, "redef.ktf").expect_err("redefinition should report an error");
    let seed_err = run_source_seed(src, "redef.ktf")
        .expect_err("seed path redefinition should report an error");
    assert_eq!(
        prod_err.rendered, seed_err.rendered,
        "dual-path redefinition diagnostic render mismatch(production bridge path vs seed goal Reader path)"
    );
    assert!(
        prod_err.rendered.contains("duplicate variable definition"),
        "diagnostic should contain E0004 semantics message: {}",
        prod_err.rendered
    );
    assert!(
        seed_prelude_is_seed_reader() && production_prelude_is_ktf_reader(),
        "dual-path injection liveness probe(redefinition scenario -- injection first)"
    );
}

/// Injection-face metadata parity: module registration after expanding a
/// prelude-importing program (the D50 re-export-face consumer shape) —
/// production execution with .ktf injection + the isomorphic seed path
/// both succeeding = registration/re-export face metadata consistent
/// (both legs the target user face post-E6: run_source /
/// run_source_seed).
#[test]
fn ktf_prelude_module_registry_parity() {
    // Production path: run (.ktf injection) — success means module registration/visit passed
    let src = "import kerf_prelude;\ncons(foldl(|| (a: i64, b: i64) { a + b }, 0, list(1, 2)), head(list(9)))";
    let out = run_source(src, "registry.ktf").expect("production module registration failed");
    let printed = render_value(&out.value, &out.heap);
    assert_eq!(printed, "(3 . 9)", "behavior anchor (render basis)");

    // Seed path: .ktf injection (run_source_seed — isomorphic success anchor)
    let out2 = run_source_seed(src, "registry.ktf").expect("seed module registration failed");
    assert_eq!(
        render_value(&out2.value, &out2.heap),
        printed,
        "dual-path behavior identical"
    );
}

/// CLI-level end to end: the higher_order.ktf real corpus (prelude-import
/// consumer shape) via the production run — output verbatim-identical to
/// the r108 baseline (regression anchor; r153 / 223-c: the corpus leg
/// switched to the .ktf single face — s-expr-removal-plan §4 Batch D).
#[test]
fn ktf_prelude_cli_corpus_regression() {
    let src = include_str!("../../../../examples/usage/higher_order.ktf");
    let out = run_source(src, "higher_order.ktf").expect("higher_order execution failed");
    let printed = render_value(&out.value, &out.heap);
    assert_eq!(
        printed, "(1 4 9 16 25)",
        "higher_order output anchor (render basis)"
    );
}

// ---------------------------------------------------------------------------
// r110 / 180-c: step (3) second batch — the reader.ktf two-path parity gate
// (class-C file 2; post-E6: reader.ktf = the renamed reader.ktf —
// the read-bridge's own program [224-a]; the S-expr-Reader bootstrap state
// + its liveness/behavior legs retired with the deleted S-expr read bridge)
// ---------------------------------------------------------------------------

/// The bootstrap directory's sole Reader artifact — reader.ktf (renamed
/// from reader.ktf at the E6 close-out [224-a]; the production
/// .ktf read bridge's own program — lexer + parser segments).
const READER_TARGET: &str = include_str!("../../../../crates/kerf-driver/src/bootstrap/reader.ktf");
/// Multi-binding let dual-side target-Reader Stx parity (span level —
/// same-source text; including type annotations and the mut-stripping
/// face).
#[test]
fn let_multi_binder_stx_parity() {
    assert_reader_stx_parity(
        "fn f(x: i64) { let a = x + 1, b = a * 2, c: i64 = b - 3; c }\nf(6)",
        "multiple binding let(three bindings + type annotation)",
    );
    assert_reader_stx_parity(
        "fn g(x: i64) { let p = x, q = p + 1; p + q }\ng(1)",
        "double binding let",
    );
}

/// Multi-binding let error-path dual-side parity (missing binder name /
/// missing = / missing ;).
#[test]
fn let_multi_binder_error_parity() {
    assert_reader_err_parity(
        "fn f(x: T) { let a = 1, ; b = 2; a }",
        "comma after missing binding name",
    );
    assert_reader_err_parity(
        "fn f(x: T) { let a = 1, b 2; a }",
        "times binding missing =",
    );
    assert_reader_err_parity(
        "fn f(x: T) { let a = 1, b = 2 a }",
        "multiple binding missing;",
    );
}

/// Missing-else / empty-block-tail nil semantics (r110 defect-clearing
/// regression anchor — originally a nil symbol → runtime unbound global;
/// the target-face if without an else arm carries a Literal(Nil) else,
/// and a fn body block without a trailing expression carries a nil
/// literal tail; the S-expr cross-face comparison legs retired with the
/// classic Reader — the behavior anchor below carries the duty).
#[test]
fn elseless_if_and_empty_block_nil_semantics() {
    // Behavior anchor: the missing else's else arm executes ⇒ nil (original defect: unbound-global
    // error)
    let mut t0 = SymbolTable::new();
    let forms = read_source("fn f(x: T) { if x { 1 } }\nf(false)", 0, &mut t0)
        .unwrap_or_else(|e| panic!("parse failed:{}", e.message));
    let (p, mut t0) = compile_forms_seed(&forms, t0, "default else line is");
    use kerf_driver::builtins::register_globals;
    use kerf_driver::capability::IoGrant;
    use kerf_runtime::Heap;
    use kerf_vm::{run_program, Value};
    let mut g = register_globals(&mut t0, &IoGrant::none());
    let mut h = Heap::new();
    let v = run_program(&p, &mut g, &mut h)
        .unwrap_or_else(|e| panic!("VM execution failed:{}", e.message));
    assert_eq!(
        v,
        Value::Nil,
        "default else else arm ⇒ nil(literal semantics)"
    );
}

/// Strip top-level imports (driver-pipeline 1.68-step isomorphism — import
/// has zero runtime semantics; the test helper compile_forms_seed bypasses
/// front_from_forms, so it must mirror this explicitly).
fn strip_toplevel_imports_for_compile(forms: &[Stx], t: &SymbolTable) -> Vec<Stx> {
    forms
        .iter()
        .filter(|f| {
            !matches!(
                &f.datum,
                StxDatum::List(l)
                    if l.first()
                        .and_then(|x| x.datum.as_symbol())
                        .map(|s| t.name(s) == "import")
                        .unwrap_or(false)
            )
        })
        .cloned()
        .collect()
}

/// Compile after stripping (shared by the three-way gates — mirror of the
/// driver 1.68 step).
fn compile_forms_seed_stripped(
    forms: &[Stx],
    table: SymbolTable,
    what: &str,
) -> (BcProgram, SymbolTable) {
    let stripped = strip_toplevel_imports_for_compile(forms, &table);
    compile_forms_seed(&stripped, table, what)
}
/// **Core gate** (dual-path form since the E5 close-out cleanup batch
/// r120 / 190-a, principle 41 — the S-expr original baseline leg was
/// retired with the deleted .krf originals; the three-way equivalence it
/// proved is archived in RELEASE r109-r119; at the E6 close-out the
/// artifact became the renamed reader.ktf [224-a] — the read
/// bridge's own program, still a real bootstrap .ktf artifact): reader.ktf
/// through the seed Reader (oracle path) ↔ through the .ktf
/// read-bridge Reader (production path — 07 §3.2.1 step (3) re-parsing
/// literal semantics). The Reader is the only variable (the expand/compile
/// stages stay seed).
#[test]
fn ktf_reader_bytecode_parity_dual_path() {
    // (1) Oracle path: the .ktf through the seed Reader
    let mut t0 = SymbolTable::new();
    let f1 = read_source(READER_TARGET, 1, &mut t0)
        .unwrap_or_else(|e| panic!(".ktf seed parse failed: {}", e.message));
    let (p1, mut t0) = compile_forms_seed_stripped(&f1, t0, ".ktf seed goal Reader");

    // (2) Production path: the .ktf through the .ktf read-bridge Reader
    // (same table — symbol-domain normalization comparability)
    let f2 = read_source_for_bootstrap(READER_TARGET, 2, &mut t0)
        .unwrap_or_else(|e| panic!(".ktf bridge parse failed:{}", e.message));
    let (p2, _t0) = compile_forms_seed_stripped(&f2, t0, ".ktf bridge goal Reader");

    assert_same_bytecode(&p1, &p2, ".ktf seed ↔ production path");
}
/// Dual-expander parity: reader.ktf forms through the seed expander ↔ the
/// self-hosted expander (expander.ktf on the VM) — the E1-β discipline
/// extended to the second-batch corpus (multi-binding let staging chains
/// isomorphic across both expanders, loaded; the artifact is the renamed
/// reader.ktf post-E6 — still a real bootstrap .ktf corpus).
#[test]
fn ktf_reader_seed_vs_bootstrap_expander() {
    let mut t0 = SymbolTable::new();
    let f1 = read_source(READER_TARGET, 0, &mut t0)
        .unwrap_or_else(|e| panic!("seed parse failed: {}", e.message));
    let (p1, mut t0) = compile_forms_seed_stripped(&f1, t0, "seed expansion");

    let f2 = read_source(READER_TARGET, 0, &mut t0)
        .unwrap_or_else(|e| panic!("second-read parse failed:{}", e.message));
    let f2s = strip_toplevel_imports_for_compile(&f2, &t0);
    let core2 = expand_program(&f2s, 0, &mut t0)
        .unwrap_or_else(|e| panic!("bootstrap expansion failed: {}", e.message));
    let p2 = compile_module(&core2).unwrap_or_else(|e| panic!("compile failed:{}", e.message));

    assert_same_bytecode(&p1, &p2, "reader.ktf seed expansion ↔ bootstrap expansion");
}
// ---------------------------------------------------------------------------
// r114 / 184-b: step (3) third batch — the compiler.ktf corpus-rewrite parity gate
// (class-C file 3; the 182-h serialized breakpoint continuation — the r112
// oracle normalization [bang-stripped mutation names + binarized n-ary
// minus] mirrored verbatim in the rewrite)
// ---------------------------------------------------------------------------

/// Target-syntax production artifact (switch-window step (3), third-batch
/// rewrite — 1301 lines of S-expr → target syntax; the bootstrap Compiler
/// state is built from this file since r114).
const COMPILER_TARGET: &str =
    include_str!("../../../../crates/kerf-driver/src/bootstrap/compiler.ktf");
/// **Core gate** (dual-path form since the E5 close-out cleanup batch
/// r120 / 190-a, principle 41 — the S-expr original baseline leg was
/// retired with the deleted .krf originals; the three-way equivalence it
/// proved is archived in RELEASE r109-r119): compiler.ktf through the
/// seed Reader (oracle path) ↔ through the .krf target-Reader
/// bridge (production path — 07 §3.2.1 step (3) re-parsing literal
/// semantics). The Reader is the only variable (the expand/compile stages
/// stay seed).
#[test]
fn ktf_compiler_bytecode_parity_dual_path() {
    // (1) Oracle path: the .ktf through the seed Reader
    let mut t0 = SymbolTable::new();
    let f1 = read_source(COMPILER_TARGET, 1, &mut t0)
        .unwrap_or_else(|e| panic!(".ktf seed parse failed: {}", e.message));
    let (p1, mut t0) = compile_forms_seed_stripped(&f1, t0, ".ktf seed goal Reader");

    // (2) Production path: the .ktf through the .krf reader bridge
    // (same table — symbol-domain normalization comparability)
    let f2 = read_source_for_bootstrap(COMPILER_TARGET, 2, &mut t0)
        .unwrap_or_else(|e| panic!(".ktf bridge parse failed:{}", e.message));
    let (p2, _t0) = compile_forms_seed_stripped(&f2, t0, ".ktf .krf goal Reader bridge");

    assert_same_bytecode(&p1, &p2, ".ktf seed ↔ production path");
}

/// Production bootstrap-state liveness: the Compiler state is built from
/// the compiler.ktf target corpus (load_compiler via
/// compile_front_seed) — a production compile triggers the .ktf
/// load and produces the correct program value (the wiring proof for
/// switch-window step (3), third batch; the entry-interning chain
/// `lexc_compile_program` resolves through the .ktf-loaded globals;
/// target user face post-E6 — run_source, E6-CG §1).
#[test]
fn ktf_compiler_production_bootstrap_liveness() {
    let src =
        "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(12)";
    let out = run_source(src, "compiler_liveness.ktf").expect("production execution failed");
    let printed = render_value(&out.value, &out.heap);
    assert_eq!(
        printed, "144",
        "fib 12 program value(compile via compiler.ktf state)"
    );
    assert!(
        kerf_driver::compiler_bootstrap_is_ktf_corpus(),
        "liveness probe: bootstrap Compiler state should itself compiler.ktf target corpus build"
    );
}

/// Behavioral equivalence: the production pipeline (bootstrap Compiler =
/// compiler.ktf bytecode) ↔ the seed pipeline (Rust compiler) — the
/// classic bootstrap-seed oracle role, end-to-end VM value equality on a
/// compiler-feature-dense source (closures + captured variables + let
/// bindings + effect-free arithmetic; both legs the target user face
/// post-E6 — run_source / run_source_seed, E6-CG §1).
#[test]
fn ktf_compiler_behavior_parity_production() {
    let src = "fn make_adder(n: i64) { || (x: i64) { x + n } }\n\
               let add5 = make_adder(5);\n\
               fn twice(f: T, v: i64) -> i64 { f(f(v)) }\n\
               twice(add5, 10)";
    let out = run_source(src, "compiler_behavior.ktf").expect("production execution failed");
    let seed = run_source_seed(src, "compiler_behavior.ktf").expect("seed execution failed");
    assert_eq!(
        render_value(&out.value, &out.heap),
        render_value(&seed.value, &seed.heap),
        "behavior anchor (production =.ktf compiler ↔ seed Rust compiler -- end-to-end values identical)"
    );
    assert!(kerf_driver::compiler_bootstrap_is_ktf_corpus());
}

/// Dual-expander parity: compiler.ktf forms through the seed expander ↔
/// the self-hosted expander (expander.ktf on the VM) — the E1-β
/// discipline extended to the third-batch corpus (assign statements /
/// multi-binding let staging chains / nested define call forms
/// isomorphic across both expanders, fully loaded).
#[test]
fn ktf_compiler_seed_vs_bootstrap_expander() {
    let mut t0 = SymbolTable::new();
    let f1 = read_source(COMPILER_TARGET, 0, &mut t0)
        .unwrap_or_else(|e| panic!("seed parse failed: {}", e.message));
    let (p1, mut t0) = compile_forms_seed_stripped(&f1, t0, "seed expansion");

    let f2 = read_source(COMPILER_TARGET, 0, &mut t0)
        .unwrap_or_else(|e| panic!("second-read parse failed:{}", e.message));
    let f2s = strip_toplevel_imports_for_compile(&f2, &t0);
    let core2 = expand_program(&f2s, 0, &mut t0)
        .unwrap_or_else(|e| panic!("bootstrap expansion failed: {}", e.message));
    let p2 = compile_module(&core2).unwrap_or_else(|e| panic!("compile failed:{}", e.message));

    assert_same_bytecode(
        &p1,
        &p2,
        "compiler.ktf seed expansion ↔ bootstrap expansion",
    );
}

/// CLI-level end-to-end regression: the fib program (the target face of
/// the retired fib.krf corpus — E6-CG §2 skin dictionary) via the
/// production run (bootstrap Compiler = compiler.ktf bytecode compiling
/// the user source) — verbatim-identical to the r109-r113 baselines.
#[test]
fn ktf_compiler_cli_corpus_regression() {
    let src = "require io, write;\nfn fib(n: i64) -> i64 {\n    if (n < 2) { n } else { fib(n - 1) + fib(n - 2) }\n}\nprint(fib(25));\nfib(12)\n";
    let out = run_source(src, "fib.ktf").expect("fib execution failed");
    let printed = render_value(&out.value, &out.heap);
    assert_eq!(
        printed, "144",
        "fib output anchor(program value fib 12 -- r109 baseline basis)"
    );
    assert!(kerf_driver::compiler_bootstrap_is_ktf_corpus());
}

/// Effect/handle deep paths: the effect_stress program (the target face
/// of the retired effect_stress.krf corpus — the examples/usage/
/// effect_stress.ktf idiom) through the production pipeline — the
/// compile-handle three-prototype orchestration (ensure-trampoline lazy
/// singleton / compile-inner-proto H and B frames / INSTALL_HANDLER
/// atomic emission) all executing inside compiler.ktf bytecode.
#[test]
fn ktf_compiler_effect_handle_deep_paths() {
    let src = "fn mk(n: i64) {\n    if (n == 0) { () } else { cons(n, mk(n - 1)) }\n}\n\nfn ask() {\n    perform gift(0, 20);\n}\n\nfn guarded() {\n    handle (100 + ask()) {\n        gift(p, k) => { mk(50000); resume(tail(p) + head(p)) }\n    }\n}\n\nguarded()\n";
    let out = run_source(src, "effect_stress.ktf").expect("effect_stress execution failed");
    let printed = render_value(&out.value, &out.heap);
    assert_eq!(
        printed, "120",
        "effect_stress output anchor(r109 baseline basis)"
    );
    assert!(kerf_driver::compiler_bootstrap_is_ktf_corpus());
}

/// Higher-order deep paths: the higher_order program (the target face of
/// the retired higher_order.krf corpus — the examples/usage/
/// higher_order.ktf shape) through the production pipeline — closure
/// conversion (fvo-node free-variable analysis / capture-resolve-loop
/// capture slots / proto window switching) inside compiler.ktf
/// bytecode.
#[test]
fn ktf_compiler_higher_order_regression() {
    let src = "fn map(f: T, lst: T) {\n    if (is_nil(lst)) { () } else { cons(f(head(lst)), map(f, tail(lst))) }\n}\nfn filter(pred: T, lst: T) {\n    if (is_nil(lst)) {\n        ()\n    } else {\n        if (pred(head(lst))) {\n            cons(head(lst), filter(pred, tail(lst)))\n        } else {\n            filter(pred, tail(lst))\n        }\n    }\n}\nfn is_even(n: i64) { mod(n, 2) == 0 }\nmap(|| (x: i64) { x * x }, list(1, 2, 3, 4, 5))\n";
    let out = run_source(src, "higher_order.ktf").expect("higher_order execution failed");
    let printed = render_value(&out.value, &out.heap);
    assert_eq!(
        printed, "(1 4 9 16 25)",
        "higher_order output anchor(r109 baseline basis)"
    );
    assert!(kerf_driver::compiler_bootstrap_is_ktf_corpus());
}

/// Closure deep paths: the closures program (the target face of the
/// retired closures.krf corpus — the examples/usage/closures.ktf shape)
/// through the production pipeline — multi-level capture chains
/// (LoadCaptured/StoreCaptured resolution via rv-loop's frame stack walk)
/// inside compiler.ktf bytecode.
#[test]
fn ktf_compiler_closures_regression() {
    let src = "require io, write;\n\nfn make_counter() {\n    let n = 0;\n    || { n = n + 1; n }\n}\n\nlet a = make_counter();\nlet b = make_counter();\na(); a(); a();\nb();\nprint(list(a(), b()));\n\nfn make_adder(n: i64) {\n    || (x: i64) { x + n }\n}\n\nlet add5 = make_adder(5);\nadd5(37)\n";
    let out = run_source(src, "closures.ktf").expect("closures execution failed");
    let printed = render_value(&out.value, &out.heap);
    assert_eq!(printed, "42", "closures output anchor(r109 baseline basis)");
    assert!(kerf_driver::compiler_bootstrap_is_ktf_corpus());
}

/// **Batch idiom unit gate** (D42 load-bearing claim, post-E6 target-face
/// self-contained form): the block-threaded statement sequence `A; B; ...
/// Z` (last item as the tail value) vs the all-statements shape
/// (`Z;` — statement instead of tail value) differ by exactly one
/// Pop + PushNil tail — the pervasive discipline of the compiler.ktf
/// statement grammar (emit/emit-jump/patch-jump/cc-locals-push family all
/// rest on it). The S-expr flat-do oracle leg retired with the classic
/// Reader (E6); the reverse anchor below pins the discipline from the
/// target face alone.
#[test]
fn statement_sequencing_do_isomorphism() {
    // Target: statement + tail assign (no `;`) = the isomorphic shape
    // (the desugaring of the retired flat-do idiom)
    let target = "fn emit2(v: T) { A = cons(v, A); B = cons(v, B) }";
    let mut t0 = SymbolTable::new();
    let f1 = read_source(target, 1, &mut t0)
        .unwrap_or_else(|e| panic!("target syntax parse failed:{}", e.message));
    let (p1, mut t0) = compile_forms_seed(&f1, t0, "target syntax statement sequence");

    // Negative anchor: the all-statements shape (`Z;`) is NOT isomorphic —
    // one extra Pop + PushNil tail (the discipline the rewrite must keep)
    let wrong = "fn emit2(v: T) { A = cons(v, A); B = cons(v, B); }";
    let f2 = read_source(wrong, 2, &mut t0)
        .unwrap_or_else(|e| panic!("negative case parse failed:{}", e.message));
    let (p2, _t0) = compile_forms_seed(&f2, t0, "full statement form(negative case)");
    let ops1 = p1.protos[1].code.len();
    let ops2 = p2.protos[1].code.len();
    assert_eq!(
        ops2 - ops1,
        2,
        "full statement form exactly adds Pop + PushNil two instructions (reverse anchor of tail-value discipline)"
    );
}

/// Parity-shadow oracle on the switched face: a feature-dense user source
/// compiled through the production pipeline (compile_source —
/// bootstrap Compiler = compiler.ktf on the VM) ↔ the seed pipeline
/// (test-level seed reconstruction: seed Reader read → seed
/// expansion → seed compilation — the E6-CG §1 replacement for
/// compile_source_seed) — bytecode-identical programs (the I1 parity
/// discipline, exercised from this gate file with the .ktf-loaded
/// state; both legs the target face post-E6).
#[test]
fn ktf_compiler_seed_vs_bootstrap_compiler_oracle() {
    let src = "fn make_counter() {\n\
               let n = 0;\n\
               || { n = n + 1; n }\n\
               }\n\
               let c = make_counter();\n\
               c();\nc();\nc()";
    let a = kerf_driver::compile_source(src, "oracle_prod.ktf")
        .unwrap_or_else(|e| panic!("production compile failed:{}", e.rendered));
    // Seed reconstruction (E6-CG §1): read → expand → compile, seed stages
    let mut t0 = SymbolTable::new();
    let f0 =
        read_source(src, 0, &mut t0).unwrap_or_else(|e| panic!("seed read failed:{}", e.message));
    let (b, t0) = compile_forms_seed(&f0, t0, "seed compile reconstruction");
    assert_same_bytecode_named(
        &a.program,
        &a.table,
        &b,
        &t0,
        "production (compiler.ktf)↔ seed (Rust)",
    );
    assert!(kerf_driver::compiler_bootstrap_is_ktf_corpus());
}

// ---------------------------------------------------------------------------
// r116 / 186-a..b: switch-window step (3), FOURTH batch — expander.ktf
// (corpus-C item 4; the bootstrap Expander state is built from the
// target-syntax corpus since r116; the r116 oracle normalizations —
// bang-stripped registry-put + string-to-symbol keyword tags + the
// negation-form -1 — are mirrored verbatim on both sides)
// ---------------------------------------------------------------------------

/// Target-syntax production artifact (switch-window step (3), fourth-batch
/// rewrite — 2234 lines of S-expr → target syntax; the bootstrap Expander
/// state is built from this file since r116; the ONE new mechanism of the
/// batch: 19 anonymous closures `(fn (c) body)` ↔ `||(c: T) { body }`).
const EXPANDER_TARGET: &str =
    include_str!("../../../../crates/kerf-driver/src/bootstrap/expander.ktf");
/// **Core gate** (dual-path form since the E5 close-out cleanup batch
/// r120 / 190-a, principle 41 — the S-expr original baseline leg was
/// retired with the deleted .krf originals; the three-way equivalence it
/// proved is archived in RELEASE r109-r119): expander.ktf through the
/// seed Reader (oracle path) ↔ through the .krf target-Reader
/// bridge (production path — 07 §3.2.1 step (3) re-parsing literal
/// semantics). The Reader is the only variable (the expand/compile stages
/// stay seed).
#[test]
fn ktf_expander_bytecode_parity_dual_path() {
    // (1) Oracle path: the .ktf through the seed Reader
    let mut t0 = SymbolTable::new();
    let f1 = read_source(EXPANDER_TARGET, 1, &mut t0)
        .unwrap_or_else(|e| panic!(".ktf seed parse failed: {}", e.message));
    let (p1, mut t0) = compile_forms_seed_stripped(&f1, t0, ".ktf seed goal Reader");

    // (2) Production path: the .ktf through the .krf reader bridge
    // (same table — symbol-domain normalization comparability)
    let f2 = read_source_for_bootstrap(EXPANDER_TARGET, 2, &mut t0)
        .unwrap_or_else(|e| panic!(".ktf bridge parse failed:{}", e.message));
    let (p2, _t0) = compile_forms_seed_stripped(&f2, t0, ".ktf .krf goal Reader bridge");

    assert_same_bytecode(&p1, &p2, ".ktf seed ↔ production path");
}

/// Production bootstrap-state liveness: the Expander state is built from
/// the expander.ktf target corpus (load_expander via
/// compile_front_seed) — a production expansion triggers the .ktf
/// load and produces the correct expansion product (the wiring proof for
/// switch-window step (3), fourth batch; the entry-interning chain
/// `lexp-expand-program` resolves through the .ktf-loaded globals; the
/// macro source is the target face post-E6 — `macro NAME { (pattern) =>
/// template }`, the r129 grammar settlement, read through the seed
/// target Reader).
#[test]
fn ktf_expander_production_bootstrap_liveness() {
    let mut t = SymbolTable::new();
    let forms = read_source("macro two { (x) => x + x }\ntwo(21)", 0, &mut t).expect("read failed");
    let items = expand_program(&forms, 0, &mut t).expect("bootstrap expansion failed");
    // the macro definition yields a nil-literal item + the macro-use
    // expression item
    assert_eq!(items.len(), 2, "expand artifact item count");
    assert!(
        kerf_driver::expander_bootstrap_is_ktf_corpus(),
        "liveness probe: bootstrap Expander state should itself expander.ktf target corpus build"
    );
}

/// Behavioral equivalence: a macro-feature-dense source (the target-face
/// macro grammar + ellipsis + hygienic α renaming + derived sugars)
/// expanded through the production pipeline (bootstrap Expander =
/// expander.ktf bytecode) ↔ the seed Rust expander — end-to-end VM value
/// equality (the E1-β discipline on the fourth-batch corpus; both legs
/// the target user face post-E6 — the macros.ktf idiom, E6-CG §2).
#[test]
fn ktf_expander_behavior_parity_production() {
    let src = "macro my_or {\n\
               () => false,\n\
               (a) => a,\n\
               (a, rest ...) => if a { true } else { my_or(rest ...) },\n\
               }\n\
               let p = 3;\n\
               my_or(false, false, p)";
    let out = run_source(src, "expander_behavior.ktf").expect("production execution failed");
    let seed = run_source_seed(src, "expander_behavior.ktf").expect("seed execution failed");
    assert_eq!(
        render_value(&out.value, &out.heap),
        render_value(&seed.value, &seed.heap),
        "behavior anchor (production =.ktf expander ↔ seed Rust expander -- end-to-end values identical)"
    );
    assert!(kerf_driver::expander_bootstrap_is_ktf_corpus());
}

/// Macro deep paths: the macros program (the target face of the retired
/// macros.krf corpus — the examples/usage/macros.ktf idiom, r129 grammar
/// settlement) through the production pipeline (macro-clause parsing /
/// matching / ellipsis splicing / introduced-identifier α renaming /
/// hygiene base-name fallback ALL executing inside expander.ktf
/// bytecode; both run legs the target user face post-E6).
#[test]
fn ktf_expander_macro_deep_paths() {
    let src = "require io, write;\n\
               macro my_or {\n\
               () => false,\n\
               (a) => a,\n\
               (a, rest ...) => if a { true } else { my_or(rest ...) },\n\
               }\n\
               macro swap {\n\
               (a, b) => {\n\
               let tmp = a;\n\
               a = b;\n\
               b = tmp;\n\
               }\n\
               }\n\
               let p = 1;\n\
               let q = 2;\n\
               swap(p, q);\n\
               print(list(p, q));\n\
               my_or(false, false, 42)";
    let out = run_source(src, "macros.ktf").expect("macros execution failed");
    let seed = run_source_seed(src, "macros.ktf").expect("macros seed execution failed");
    // Program value = the last form (my_or false false 42) ⇒ 42; the swap
    // effect is observable via the printed (2 1) on stdout (both sides)
    assert_eq!(
        render_value(&out.value, &out.heap),
        render_value(&seed.value, &seed.heap),
        "macros behavior anchor (production.ktf expander ↔ seed -- end-to-end values identical)"
    );
    assert_eq!(
        render_value(&out.value, &out.heap),
        "42",
        "macros output anchor(my_or tail form -- hygienic macro final value)"
    );
    assert!(kerf_driver::expander_bootstrap_is_ktf_corpus());
}

/// Derived-sugar deep paths: the r101 macroized sugar family through the
/// production pipeline — the DERIVED_SOURCES injection
/// (lexp-init-derived) + lazy sugar registration + 'derived transformer
/// step all executing inside expander.ktf bytecode (target face
/// post-E6: while/when/unless fire from their call forms — probe-verified
/// — and/or are the native infix operators; let*/cond ride the E6-CG §2
/// skin rewrites [let chain via immediately-invoked closure / if-else
/// chain]; the same output anchor as the retired S-expr corpus).
#[test]
fn ktf_expander_derived_sugar_deep_paths() {
    let src = "let acc = 0;\n\
               while(acc < 5, assign(acc, acc + 1));\n\
               let r = if (acc > 3 && (false || (|| { let x = 2; let y = 3; x < y })())) { when(true, unless(false, acc + 40)) } else { if (acc == 1) { 100 } else { 200 } };\n\
               r";
    let out = run_source(src, "sugars.ktf").expect("sugars execution failed");
    let printed = render_value(&out.value, &out.heap);
    assert_eq!(
        printed, "45",
        "derived sugar full-family output anchor(while 5 round + and/or/let*/when/unless/cond)"
    );
    assert!(kerf_driver::expander_bootstrap_is_ktf_corpus());
}
/// Keyword-tag unit anchors (r116 second normalization; post-E6 the
/// negative anchor carries the duty alone): the bare keyword in
/// quote-argument position — `quote(let)` — is a parse error on the
/// target face (KwLet is reserved, not introducible in expression
/// position — the gap evidence that motivated the TAG-global
/// normalization the corpus still rides). The bilateral positive anchor
/// (S-expr TAG form ↔ target TAG form bytecode identity) retired with
/// the classic Reader at the E6 close-out.
#[test]
fn keyword_tag_normalization_anchors() {
    // Negative anchor: the bare keyword in quote-argument position is
    // rejected by the target Reader (fail-closed gap evidence)
    let mut t0 = SymbolTable::new();
    let r = read_source("fn bad() { quote(let) }", 0, &mut t0);
    assert!(
        r.is_err(),
        "quote(let) should be parse error(KwLet reserved word cannot enter an expression position)"
    );
}

/// Parity-shadow oracle on the switched face: a macro-dense user source
/// compiled through the production pipeline (compile_source —
/// bootstrap Expander = expander.ktf + bootstrap Compiler =
/// compiler.ktf on the VM) ↔ the seed pipeline (test-level seed
/// reconstruction — seed Reader read → seed expansion → seed
/// compilation, the E6-CG §1 replacement for compile_source_seed) —
/// bytecode-identical programs (the E1-β + I1 parity discipline chained
/// end-to-end with both .ktf-loaded states; both legs the target face
/// post-E6 — the macros.ktf swap idiom).
#[test]
fn ktf_expander_seed_vs_bootstrap_pipeline_oracle() {
    let src = "macro swap {\n\
               (a, b) => {\n\
               let tmp = a;\n\
               a = b;\n\
               b = tmp;\n\
               }\n\
               }\n\
               let a = 1;\n\
               let b = 2;\n\
               swap(a, b);\n\
               list(a, b)";
    let a = kerf_driver::compile_source(src, "oracle_prod.ktf")
        .unwrap_or_else(|e| panic!("production compile failed:{}", e.rendered));
    // Seed reconstruction (E6-CG §1): read → expand → compile, seed stages
    let mut t0 = SymbolTable::new();
    let f0 =
        read_source(src, 0, &mut t0).unwrap_or_else(|e| panic!("seed read failed:{}", e.message));
    let (b, t0) = compile_forms_seed(&f0, t0, "seed compile reconstruction");
    assert_same_bytecode_named(
        &a.program,
        &a.table,
        &b,
        &t0,
        "production (expander.ktf + compiler.ktf)↔ seed (Rust)",
    );
    assert!(kerf_driver::expander_bootstrap_is_ktf_corpus());
    assert!(kerf_driver::compiler_bootstrap_is_ktf_corpus());
}

// ---------------------------------------------------------------------------
// r118 / 188-a: switch-window step (4) — target-syntax self-compilation
// (07 §3.2.1: "use the compiler to compile the target-syntax itself";
// the fixpoint prerequisite of step (5) — "verify the target-syntax
// compiler compiling itself yields equivalent output").
//
// The step-(4) production entry under test: `compile_source`
// (read via the .ktf read-bridge Reader + expand via expander.ktf on
// the VM + compile via compiler.ktf on the VM — the literal proposition
// "the target-syntax compiler chain compiles the target syntax itself").
// The four .ktf corpus files (production artifacts of step (3), batches
// r109-r116; reader.ktf post-E6 = the renamed reader.ktf [224-a])
// are the "itself"; the corpus is macro-free in the
// consumption sense (r116 census: the expander corpus implements the
// macro system but consumes zero macro-definition forms).
// E6 close-out (r154 / 224-b3): the Reader-stage state rotation (the
// bootstrap root install_state/reset_state for the retired S-expr Reader
// state) was deleted with the S-expr read bridge — the expander/compiler
// rotations are the load-bearing stages of the fixpoint (the original
// stage-rotation note below), so the gates survive with the two-stage
// rotation.
// ---------------------------------------------------------------------------

/// Step-(4) fixpoint helper: compile a .ktf source through the FULL
/// production target chain (compile_source — bridge read +
/// self-hosted expand + self-hosted compile; cache-free by construction,
/// the §7.4 isolation discipline).
fn compile_ktf_production(src: &str, name: &str) -> kerf_driver::CompileOutput {
    kerf_driver::compile_source(src, name).unwrap_or_else(|e| {
        panic!(
            "[{}] step④ production goal chain compile failed:{}",
            name, e.rendered
        )
    })
}

/// Resolve by name (magic-symbol caliber — mirrors the gate-B helper:
/// main/anonymous-fn prototype names are not interned and render as fixed
/// names; i1 §7.3 "names are the only stable cross-chain caliber").
fn resolve_sym_by_name(s: kerf_syntax::Symbol, table: &SymbolTable) -> String {
    match s.0 {
        x if x == u32::MAX - 1 => "<main>".to_string(),
        x if x == u32::MAX - 2 => "<fn>".to_string(),
        _ => table.name(s).to_string(),
    }
}

/// **Step (4) core gate — the target-syntax self-compilation fixpoint**:
/// B₁' = the production target chain (bridge Reader + expander.ktf +
/// compiler.ktf — the .ktf-built bootstrap states) compiles the four
/// .ktf corpus files (reader/expander/compiler/preamble — the "itself");
/// B₂' = **with B₁'s output installed as the new self-hosted state**
/// (install_state for the two load-bearing corpus stages — the literal
/// meaning of "output compiles itself") the same .ktf sources are
/// compiled again.
///
/// Hard gates (i1-design §5 Gate B caliber, same-chain criterion):
/// `bytecode_equal(B₁'[i], B₂'[i])` per program on the FULL structure
/// (including debug_spans) + SHA-256 digest agreement.
///
/// Isolation discipline (§7.4): the entry is cache-free by construction
/// (compile_source never consults the cache — a cached B₂ round
/// would return the B₁ entry: the false-positive defense line) + fresh
/// state (reset both stages — lazily reload from the .ktf corpus).
///
/// Stage-rotation note (honest boundary, E6-updated): the Reader stage of
/// the .ktf compile chain is the .ktf read bridge (reader.ktf — loaded
/// via compile_front_seed, the hard P1 convention); the Reader
/// stage has NO rotatable bootstrap state since the S-expr read bridge
/// was deleted at the E6 close-out (the retired root install_state/
/// reset_state were its install face — the gate-B-symmetric Reader
/// rotation was ceremonial and did not feed .ktf reading) — the
/// expander/compiler rotations are the load-bearing stages of the
/// step-(4) fixpoint and carry the B₁'/B₂' judgment.
#[test]
fn ktf_corpus_fixpoint_self_compiles() {
    use kerf_driver::bootstrap::compiler::{
        install_state as install_compiler, reset_state as reset_compiler,
    };
    use kerf_driver::bootstrap::expander::{
        install_state as install_expander, reset_state as reset_expander,
    };
    use kerf_driver::set_cache_enabled;

    let sources: [(&str, &str); 4] = [
        (READER_TARGET, "reader.ktf"),
        (EXPANDER_TARGET, "expander.ktf"),
        (COMPILER_TARGET, "compiler.ktf"),
        (PREAMBLE_TARGET, "preamble.ktf"),
    ];
    let names = ["reader.ktf", "expander.ktf", "compiler.ktf", "preamble.ktf"];
    set_cache_enabled(false);
    reset_expander();
    reset_compiler();

    // B₁': the production target chain compiles the .ktf corpus itself
    let b1: Vec<_> = sources
        .iter()
        .map(|(s, n)| compile_ktf_production(s, n))
        .collect();
    assert!(
        kerf_driver::expander_bootstrap_is_ktf_corpus(),
        "liveness probe: B₁' expand segment should itself expander.ktf build"
    );
    assert!(
        kerf_driver::compiler_bootstrap_is_ktf_corpus(),
        "liveness probe: B₁' compile segment should itself compiler.ktf build"
    );

    // B₂': with B₁' output installed as the new self-hosted state (the two
    // load-bearing corpus stages — "output compiles itself"), recompile
    install_expander(
        b1[1].program.clone(),
        b1[1].table.clone(),
        b1[1].source_map.clone(),
    )
    .expect("B₁' Expander state install failed");
    install_compiler(
        b1[2].program.clone(),
        b1[2].table.clone(),
        b1[2].source_map.clone(),
    )
    .expect("B₁' Compiler state install failed");
    let b2: Vec<_> = sources
        .iter()
        .map(|(s, n)| compile_ktf_production(s, n))
        .collect();

    // Hard gate 1: per-program full-structure bytecode equality
    // (same-chain criterion — B₁'/B₂' intern order agrees by construction)
    for (i, name) in names.iter().enumerate() {
        assert!(
            b1[i].program.bytecode_equal(&b2[i].program),
            "step④ fixpoint failed:{} B₁'/B₂' bytes differ",
            name
        );
    }
    // Hard gate 2: SHA-256 digest agreement (the final-check caliber)
    for (i, name) in names.iter().enumerate() {
        let d1 = kerf_driver::sha256_hex(format!("{:?}", b1[i].program).as_bytes());
        let d2 = kerf_driver::sha256_hex(format!("{:?}", b2[i].program).as_bytes());
        assert_eq!(
            d1, d2,
            "step④ fixpoint failed:{} B₁'/B₂' SHA-256 digest mismatch",
            name
        );
    }

    // Hygiene: restore lazily-reload semantics for the subsequent tests
    reset_expander();
    reset_compiler();
}

/// Step (4) strengthened criterion (not a hard gate — the cross-chain
/// caliber, i1 §7.3): B₀' = the seed target path (seed Reader +
/// seed expander + seed compiler — compile_forms_seed_stripped, the
/// driver-1.68 import-strip mirror) ↔ B₁' = the production target chain
/// (compile_source) on the same four .ktf corpus files —
/// disassembly text compared BY NAME (the two chains intern symbols in
/// their own tables; names are the only stable cross-chain caliber — the
/// same ruling as the .krf gate-B B₀/B₁ strengthened criterion).
#[test]
fn ktf_corpus_fixpoint_cross_chain_by_name() {
    let sources: [(&str, &str); 4] = [
        (READER_TARGET, "reader.ktf"),
        (EXPANDER_TARGET, "expander.ktf"),
        (COMPILER_TARGET, "compiler.ktf"),
        (PREAMBLE_TARGET, "preamble.ktf"),
    ];
    let names = ["reader.ktf", "expander.ktf", "compiler.ktf", "preamble.ktf"];

    for (i, (src, name)) in sources.iter().enumerate() {
        // B₀': seed target path (seed Reader read → **list-body injection**
        // → strip → seed expand → seed compile). r164 / 235-c: the bare
        // compile_forms_seed_stripped leg no longer matches B₁' — the
        // production chain's resolve injects the self-built list body
        // (these corpora import kerf_list), so the seed leg carries the same
        // injection manually (list.ktf forms read via the seed Reader, a
        // separate file_id, prepended — the resolve_prelude_imports isomorph;
        // none of the four corpora import kerf-prelude, so the preamble leg
        // is not needed for the caliber).
        let mut t0 = SymbolTable::new();
        let f0 = read_source(src, 0, &mut t0)
            .unwrap_or_else(|e| panic!("[{}] seed goal parse failed:{}", names[i], e.message));
        let list_src = std::fs::read_to_string("crates/kerf-driver/src/bootstrap/list.ktf")
            .expect("list.ktf read failed (the self-built module body)");
        let fl = read_source(&list_src, 999, &mut t0)
            .unwrap_or_else(|e| panic!("list.ktf seed parse failed:{}", e.message));
        let mut injected = fl;
        injected.extend(f0);
        let (p0, _t0) = compile_forms_seed_stripped(&injected, t0, "seed goal path");

        // B₁': production target chain
        let b1 = compile_ktf_production(src, name);

        let t0_text = kerf_compiler::disassemble_program(&p0, &|s| resolve_sym_by_name(s, &_t0));
        let t1_text =
            kerf_compiler::disassemble_program(&b1.program, &|s| resolve_sym_by_name(s, &b1.table));
        assert_eq!(
            t0_text, t1_text,
            "step④ cross chain verdict per failed:{} B₀'/B₁' disassembly text(by name)mismatch",
            names[i]
        );
    }
}

/// Step (4) executability: B₁'s output actually RUNS as the self-hosted
/// implementation — after installing the B₁' states (the .ktf corpus
/// compiled through the production target chain), a behavioral source is
/// compiled and executed through the B₁'-built chain (expand + compile
/// running B₁' bytecode on the VM, reading through the .ktf read bridge)
/// with results equal to the seed chain's (the step-(4) analog of the
/// gate-B "B₁ programs execute as the bootstrap chain"; both legs the
/// target user face post-E6 — run_source_seed /
/// run_source, E6-CG §1; the Reader-stage rotation retired with
/// the S-expr read bridge — see the core-gate stage-rotation note).
#[test]
fn ktf_corpus_fixpoint_b1_chain_executes() {
    use kerf_driver::bootstrap::compiler::{
        install_state as install_compiler, reset_state as reset_compiler,
    };
    use kerf_driver::bootstrap::expander::{
        install_state as install_expander, reset_state as reset_expander,
    };
    use kerf_driver::set_cache_enabled;

    set_cache_enabled(false);
    reset_expander();
    reset_compiler();

    // Reference: seed-chain execution result (the seed target path)
    let src = "fn sq(x: i64) -> i64 { x * x }\nsq(7)";
    let expected = run_source_seed(src, "step4_exec.ktf").expect("seed chain execution failed");

    // B₁' output of the corpus (through the production target chain)
    let b1 = compile_ktf_production(COMPILER_TARGET, "compiler.ktf");
    let b1_expander = compile_ktf_production(EXPANDER_TARGET, "expander.ktf");
    install_expander(
        b1_expander.program.clone(),
        b1_expander.table.clone(),
        b1_expander.source_map.clone(),
    )
    .expect("B₁' Expander state install failed");
    install_compiler(b1.program.clone(), b1.table.clone(), b1.source_map.clone())
        .expect("B₁' Compiler state install failed");

    // The B₁'-built chain compiles + runs the behavioral source
    let actual = run_source(src, "step4_exec.ktf").expect("B₁' chain execution failed");
    assert!(
        actual.value.eq_value(&expected.value),
        "step④ executability failure: B₁' chain behavior mismatch: {:?} vs {:?}",
        render_value(&actual.value, &actual.heap),
        render_value(&expected.value, &expected.heap)
    );

    // Hygiene: restore lazily-reload semantics
    reset_expander();
    reset_compiler();
}

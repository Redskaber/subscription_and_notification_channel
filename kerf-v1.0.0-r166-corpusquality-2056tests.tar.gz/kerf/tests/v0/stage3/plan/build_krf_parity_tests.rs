//! Build-system segment first cut parity tests (r74 / 144-d —
//! [r74-window-opening §4] acceptance face).
//!
//! **Criterion**: prelude injection judgment agrees on both faces — the
//! Rust seed oracle (`imports_prelude_seed` — driver.rs's original
//! production implementation, now in a retired role) vs the .krf production
//! face (`bootstrap/build.krf` run on the VM through the `bootstrap::build`
//! bridge — **the production path is switched**; this parity is the switch
//! guard).
//!
//! Coverage (≥10 cases): no import / top-level direct import / top-level
//! import of a non-prelude module / as alias pair skipping positions / as
//! alias swallowing the prelude name (flat-shape semantics) / dangling as
//! at the tail / module header import / module header export-first order /
//! body-form termination / bare module boundary / mixed combinations /
//! nested module body termination + production E2E in both directions
//! (injection takes effect + no injection when undeclared).

use kerf_driver::bootstrap::build::imports_prelude as krf_imports_prelude;
use kerf_driver::bootstrap::read_source;
use kerf_driver::{imports_prelude_seed, run_source, Stage};
use kerf_span::SourceMap;
use kerf_syntax::{Stx, SymbolTable};

const FNAME: &str = "build_krf_parity.krf";

/// Source → top-level Stx forms + symbol table (seed reader — single source
/// of parity inputs).
fn forms_of(src: &str) -> (Vec<Stx>, SymbolTable) {
    let mut sm = SourceMap::new();
    let fid = sm.add_file(FNAME, src);
    let mut table = SymbolTable::new();
    let forms = read_source(src, fid, &mut table).expect("read failed(case must be legal read)");
    (forms, table)
}

/// Two-face parity assertion: both sides' judgments match the expectation.
fn assert_parity(src: &str, expect: bool) {
    let (forms, table) = forms_of(src);
    let rust = forms.iter().any(|f| imports_prelude_seed(f, &table));
    assert_eq!(
        rust, expect,
        "Rust oracle differs from expectation: \n{}",
        src
    );
    let krf = krf_imports_prelude(&forms, &table).expect("build.krf bridge internal error");
    assert_eq!(
        krf, expect,
        "krf production face differs from expectation: \n{}",
        src
    );
    assert_eq!(
        rust, krf,
        "dual-face verdict divergence(parity broken): \n{}",
        src
    );
}

// ---------------------------------------------------------------------------
// parity corpus (12 cases)
// ---------------------------------------------------------------------------

/// An ordinary program with no imports.
#[test]
fn parity_no_import() {
    assert_parity("(define (f x) x)\n(f 1)", false);
}

/// Top-level direct import of the prelude (D47 main entry).
#[test]
fn parity_toplevel_prelude_import() {
    assert_parity("(import kerf-prelude)\n42", true);
}

/// Top-level import of a non-prelude module.
#[test]
fn parity_toplevel_other_import() {
    assert_parity("(import kerf-list)\n(list 1 2)", false);
}

/// as alias pair (kerf-list as l — skips two positions past the alias).
#[test]
fn parity_alias_pair_skips_alias() {
    assert_parity("(import kerf-list as l)\n42", false);
}

/// prelude with an alias (kerf-prelude as p — first name hits).
#[test]
fn parity_prelude_with_alias() {
    assert_parity("(import kerf-prelude as p)\n42", true);
}

/// as alias swallows the prelude name (flat shape: kerf-prelude lands in
/// the alias slot — skipped).
#[test]
fn parity_alias_swallows_prelude_name() {
    // (import kerf-list as kerf-prelude): kerf-prelude is in the alias
    // slot — as skips two positions past it → no injection triggered
    // (boundary anchor of flat-shape semantics)
    assert_parity("(import kerf-list as kerf-prelude)\n42", false);
}

/// Dangling as at the tail ((import as) — as has no successor; advancing one position exits the loop).
#[test]
fn parity_dangling_as_tail() {
    assert_parity("(import as)\n42", false);
}

/// module header region importing the prelude.
#[test]
fn parity_module_header_prelude() {
    assert_parity(
        "(module m (import kerf-prelude) (export f)\n  (define (f x) x))",
        true,
    );
}

/// module header region with export first + import prelude (export continue semantics).
#[test]
fn parity_module_export_then_prelude() {
    assert_parity("(module m (export f) (import kerf-prelude) 42)", true);
}

/// import after module body forms (header region terminates — the body is
/// not scanned).
#[test]
fn parity_module_body_terminates_scan() {
    assert_parity(
        "(module m (import kerf-list) (export f)\n  (define (f x) x)\n  (import kerf-prelude))",
        false,
    );
}

/// Bare module boundary (zero fields — isomorphic to an empty skip(2)
/// iteration; the drop out-of-bounds boundary anchor captured by r74/144-d
/// measurement).
#[test]
fn parity_bare_module_boundary() {
    assert_parity("(module)", false);
    assert_parity("(module m)", false);
}

/// Nested module (the inner module is a body form — header region terminates).
#[test]
fn parity_nested_module_is_body() {
    assert_parity(
        "(module m (import kerf-list)\n  (module inner (import kerf-prelude) 42))",
        false,
    );
}

// ---------------------------------------------------------------------------
// Production E2E both directions (switch guard — injection takes effect +
// no injection when undeclared)
// ---------------------------------------------------------------------------

/// Production positive: declared import → prelude injection takes effect
/// (map visible — the real injection chain driven by the build.krf judgment
/// on the VM).
#[test]
fn production_prelude_injection_e2e() {
    let r = run_source(
        "(import kerf-prelude)\n(map (fn (x) (+ x 1)) (list 1 2))",
        FNAME,
    )
    .expect("prelude injection compile execution");
    assert_eq!(kerf_vm::render_value(&r.value, &r.heap), "(2 3)");
}

/// Production negative: undeclared import → prelude not injected (map
/// invisible → E0022 compile-time unbound reference — empirical proof of
/// downstream enforcement of the .krf false judgment).
#[test]
fn production_no_injection_when_undeclared() {
    let e = match run_source("(map (fn (x) (+ x 1)) (list 1 2))", FNAME) {
        Ok(_) => panic!("expected E0022(map not injection unbound), got Ok"),
        Err(e) => e,
    };
    assert_eq!(e.stage, Stage::Compile);
    assert!(
        e.rendered.contains("map"),
        "message missing map: \n{}",
        e.rendered
    );
}

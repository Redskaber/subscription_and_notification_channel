//! Build-system segment fifth-incision parity tests (r90 / 160-b — the
//! TD-032 cache-segment final-incision acceptance face; the switch guard
//! for the fifth production proof of the 07 §3.3 Stage 2→3 signal "the
//! build system can be rewritten in the new language").
//!
//! **Criterion**: the cache consultation policy agrees on both faces — the
//! Rust oracle (the `cache.rs cache_key` key construction + the original
//! three-phase `compile_front_cached` semantics — retired role) vs the
//! .krf production face (`bootstrap/cache.krf` run on the VM through the
//! `bootstrap::cache` bridge — **the production path is already switched**;
//! this parity is the switch guard).
//!
//! Coverage (16 cases): five key-construction parity cases (the production
//! corpus family / filename discrimination / B11 kind bucketing /
//! deterministic repeat consultation / separator-boundary filenames) + six
//! consultation-policy parity cases (bypass zero side effects / fresh miss
//! / error path not cached / disabled direct compilation / repeatable hit
//! snapshot / the enabled × warmed full-shape matrix) + five
//! production-switch guards (the liveness probe / check E2E on a real
//! corpus / run cache transparency / the stats-count matrix / report-field
//! full equivalence).
//!
//! Seed-bucket service isolation (B11 "seed entries are never served to
//! production lookups") is anchored at the cache.rs unit level by
//! `seed_bucket_entry_not_served_to_production_lookup` (the pub(crate) face
//! is unreachable at integration level — this file covers its key-layer
//! premise via key-bucketing parity).

use kerf_driver::bootstrap::cache::{
    consult, production_cache_consult, production_cache_is_bootstrap, CachePlan,
};
use kerf_driver::cache::{
    cache_enabled, cache_entry_count, cache_key, cache_reset, cache_stats, set_cache_enabled,
};
use kerf_driver::{check_source, run_source, CompilerKind};
use kerf_vm::Value;

const FIB_SRC: &str = "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2)))))\n(fib 12)";

// ---------------------------------------------------------------------------
// A. Key-construction parity (oracle = cache_key — the retired oracle of
//    the five-incision switch discipline)
// ---------------------------------------------------------------------------

/// Key parity assertion (enabled bit true + reset beforehand to guarantee
/// the Miss shape — key fields observable).
fn assert_key_parity(src: &str, filename: &str, kind: CompilerKind) {
    cache_reset();
    let plan = consult(true, src, filename, kind).expect("consultation bridge internal error");
    let got = match plan {
        CachePlan::Miss(key) => key,
        CachePlan::Hit(_) => panic!("reset after should not in(key observation precondition)"),
        CachePlan::Bypass => panic!("enable bit should consult(non- bypass)"),
    };
    let oracle = cache_key(src, filename, kind);
    assert_eq!(
        got.source_hash, oracle.source_hash,
        "source_hash dual-face divergence(parity broken): {src:?}"
    );
    assert_eq!(
        got.config_fingerprint, oracle.config_fingerprint,
        "config_fingerprint dual-face divergence(parity broken): {filename:?}"
    );
}

/// Production corpus-family key parity (recursive fib / empty source /
/// Unicode / long source — the full content-addressed shape range; keys
/// bit-for-bit identical on both faces = both sources locked for the SEED
/// constant and the composite format).
#[test]
fn key_parity_production_corpus() {
    let long_src = format!("(define x 1)\n{}", "(+ x 1)\n".repeat(200));
    assert_key_parity(FIB_SRC, "fib.krf", CompilerKind::Bootstrap);
    assert_key_parity("", "empty.krf", CompilerKind::Bootstrap);
    assert_key_parity("(define π 3)\nπ", "unicode.krf", CompilerKind::Bootstrap);
    assert_key_parity(&long_src, "long.krf", CompilerKind::Bootstrap);
}

/// Filename-discriminating key parity (same source, different names →
/// cfg-fp differs; each agrees with the oracle — the reason filenames
/// enter the fingerprint: artifacts embed a SourceMap, so same text under
/// different names yields non-equivalent artifacts).
#[test]
fn key_parity_filename_discriminates() {
    assert_key_parity("(+ 1 2)", "a.krf", CompilerKind::Bootstrap);
    assert_key_parity("(+ 1 2)", "b.krf", CompilerKind::Bootstrap);
    // Same source under different names → keys differ (the filename dimension of B)
    let ka = cache_key("(+ 1 2)", "a.krf", CompilerKind::Bootstrap);
    let kb = cache_key("(+ 1 2)", "b.krf", CompilerKind::Bootstrap);
    assert_ne!(ka.config_fingerprint, kb.config_fingerprint);
}

/// B11/P4 kind-bucketing key parity (same source and name, different kind
/// → keys differ; each face agrees with the oracle — the key-layer premise
/// that seed and self-hosted artifacts never share cache entries).
#[test]
fn key_parity_kind_buckets_b11() {
    assert_key_parity("(+ 1 2)", "bucket.krf", CompilerKind::Bootstrap);
    assert_key_parity("(+ 1 2)", "bucket.krf", CompilerKind::Seed);
    let prod = cache_key("(+ 1 2)", "bucket.krf", CompilerKind::Bootstrap);
    let seed = cache_key("(+ 1 2)", "bucket.krf", CompilerKind::Seed);
    assert_ne!(prod.config_fingerprint, seed.config_fingerprint);
}

/// Deterministic repeat consultation (repeated consultation of the same
/// input → keys bit-for-bit identical — SHA-256 determinism + composite
/// format stability).
#[test]
fn key_parity_deterministic_repeat() {
    cache_reset();
    let k1 = match consult(true, FIB_SRC, "det.krf", CompilerKind::Bootstrap)
        .expect("first consultation")
    {
        CachePlan::Miss(key) => key,
        other => panic!("after reset should miss, got {other:?}"),
    };
    cache_reset();
    let k2 = match consult(true, FIB_SRC, "det.krf", CompilerKind::Bootstrap)
        .expect("re-consultation")
    {
        CachePlan::Miss(key) => key,
        other => panic!("after reset should miss, got {other:?}"),
    };
    assert_eq!(k1.source_hash, k2.source_hash);
    assert_eq!(k1.config_fingerprint, k2.config_fingerprint);
}

/// Separator-boundary filenames (a filename containing "|" — the same
/// character as the composite-string separator; both sides' composites
/// character-isomorphic → parity maintained [collision risk = an existing
/// property of the composite format, not a switch regression — honest
/// boundary note]).
#[test]
fn key_parity_separator_filename_edge() {
    assert_key_parity("(+ 1 2)", "we|ird|name.krf", CompilerKind::Bootstrap);
    assert_key_parity("(+ 1 2)", "|.krf", CompilerKind::Bootstrap);
}

// ---------------------------------------------------------------------------
// B. Consultation-policy parity (the bypass / hit / miss three-shape
//    decision + the stats criteria)
// ---------------------------------------------------------------------------

/// bypass zero side effects (disabled → the Bypass shape; stats all zero +
/// zero entries — the zero-query observable face = the consultation fast
/// path isomorphic to the Rust early-exit arm).
#[test]
fn consult_bypass_zero_side_effects() {
    cache_reset();
    let plan =
        production_cache_consult(false, FIB_SRC, "bypass.krf").expect("disabled consultation");
    assert!(matches!(plan, CachePlan::Bypass));
    let s = cache_stats();
    assert_eq!(
        (s.hits, s.misses, s.stores),
        (0, 0, 0),
        "bypass should query zero times"
    );
    assert_eq!(cache_entry_count(), 0);
}

/// Fresh miss (enabled + empty cache → the Miss shape; stats.misses = 1 —
/// single-query criteria).
#[test]
fn consult_miss_fresh() {
    cache_reset();
    let plan = consult(true, "(define m 1)", "fresh.krf", CompilerKind::Bootstrap)
        .expect("fresh consultation");
    assert!(matches!(plan, CachePlan::Miss(_)));
    assert_eq!(cache_stats().misses, 1);
    assert_eq!(cache_stats().hits, 0);
}

/// Error path not cached (a compile Err writes nothing — diagnostics may
/// evolve across versions + the error path has no performance pressure; a
/// retry still recompiles).
#[test]
fn consult_error_path_not_cached() {
    cache_reset();
    let bad = "(define x 1";
    assert!(
        check_source(bad, "bad.krf").is_err(),
        "syntax error should Err"
    );
    assert_eq!(cache_entry_count(), 0, "error paths must not write");
    assert_eq!(cache_stats().stores, 0);
    // retry: still Err (miss recompilation — the behavioral face of not caching errors)
    assert!(check_source(bad, "bad.krf").is_err());
    assert_eq!(cache_entry_count(), 0);
    assert_eq!(
        cache_stats().stores,
        0,
        "retry error path still does not write"
    );
}

/// Disabled direct compilation (set_cache_enabled(false) → check_source
/// compiles directly: cache_hit = false + zero entries + zero misses
/// [early-exit arm parity]; re-enable isolation).
#[test]
fn consult_disabled_bypass_direct_compile() {
    cache_reset();
    set_cache_enabled(false);
    assert!(!cache_enabled());
    let r = check_source("(+ 40 2)", "direct.krf").expect("disabled direct compile");
    assert!(!r.cache_hit);
    assert_eq!(cache_entry_count(), 0);
    assert_eq!(
        cache_stats().misses,
        0,
        "disabled should exit early zero queries"
    );
    // Test isolation restored (thread_local global face — later cases are unaffected by disabled
    // residue)
    set_cache_enabled(true);
    cache_reset();
}

/// Repeatable hit snapshot (the miss → hit → hit three phases: equivalent
/// artifacts + exact stats [misses=1 hits=2 stores=1 — single-query
/// discipline, zero double counting]).
#[test]
fn consult_hit_snapshot_repeatable() {
    cache_reset();
    let r1 = check_source(FIB_SRC, "snap.krf").expect("first compile");
    assert!(!r1.cache_hit);
    let r2 = check_source(FIB_SRC, "snap.krf").expect("second hit");
    assert!(r2.cache_hit);
    let r3 = check_source(FIB_SRC, "snap.krf").expect("three times hit");
    assert!(r3.cache_hit);
    // Snapshot semantics: the hit clone is isomorphic to the first artifact (observable fields
    // fully equal)
    assert_eq!(r3.instruction_count, r1.instruction_count);
    assert_eq!(r3.proto_count, r1.proto_count);
    let s = cache_stats();
    assert_eq!((s.misses, s.hits, s.stores), (1, 2, 1));
}

/// Enabled × warmed full-shape matrix ({false,true} × {fresh,warmed} four
/// combinations — bypass zero queries / fresh miss / warmed hit + per-
/// combination stats assertions).
#[test]
fn consult_matrix_enabled_warm() {
    // Combination 1: disabled × fresh (bypass zero side effects)
    cache_reset();
    set_cache_enabled(false);
    assert!(matches!(
        production_cache_consult(false, "(+ 1 1)", "mx.krf").expect("matrix 1"),
        CachePlan::Bypass
    ));
    assert_eq!(cache_stats().misses, 0);
    set_cache_enabled(true);
    // Combination 2: enabled × fresh (Miss)
    cache_reset();
    assert!(matches!(
        consult(true, "(+ 1 1)", "mx.krf", CompilerKind::Bootstrap).expect("matrix 2"),
        CachePlan::Miss(_)
    ));
    assert_eq!(cache_stats().misses, 1);
    // Combination 3: enabled × warmed (Hit — after a store through the
    // production consumer face; the key is observable via the Hit shape →
    // append the oracle key parity)
    let r = check_source("(+ 1 1)", "mx.krf").expect("warm-up write");
    assert!(!r.cache_hit);
    let oracle = cache_key("(+ 1 1)", "mx.krf", CompilerKind::Bootstrap);
    match production_cache_consult(true, "(+ 1 1)", "mx.krf").expect("matrix 3") {
        CachePlan::Hit(got) => {
            assert_eq!(got, oracle, "Hit form key oracle parity");
        }
        other => panic!("matrix 3 should hit, got {:?}", other),
    }
    // Combination 4: disabled × warmed (Bypass — disabled takes precedence
    // over warmed, the early-exit arm semantics)
    set_cache_enabled(false);
    assert!(matches!(
        production_cache_consult(false, "(+ 1 1)", "mx.krf").expect("matrix 4"),
        CachePlan::Bypass
    ));
    set_cache_enabled(true);
    cache_reset();
}

// ---------------------------------------------------------------------------
// C. Production-switch guards (liveness probe + E2E + the stats matrix)
// ---------------------------------------------------------------------------

/// Production liveness probe (the production face counts independently —
/// empirical proof the krf path consults).
#[test]
fn production_liveness_probe() {
    cache_reset();
    let p = production_cache_consult(false, "(+ 2 2)", "liveness.krf")
        .expect("production consultation");
    assert!(matches!(p, CachePlan::Bypass));
    assert!(production_cache_is_bootstrap());
}

/// check E2E on a real corpus (fib 12 — first lookup misses / recheck
/// hits + report-field full equivalence + exact stats).
#[test]
fn production_check_e2e_real_corpus() {
    cache_reset();
    let r1 = check_source(FIB_SRC, "e2e_fib.krf").expect("first check");
    assert!(!r1.cache_hit, "first should miss");
    let r2 = check_source(FIB_SRC, "e2e_fib.krf").expect("re-check hit");
    assert!(r2.cache_hit, "re-check should hit");
    // Report-field full equivalence (cache transparency — the hit clone is bit-for-bit the same as
    // the first artifact on the observable face)
    assert_eq!(r1.proto_count, r2.proto_count);
    assert_eq!(r1.const_count, r2.const_count);
    assert_eq!(r1.global_ref_count, r2.global_ref_count);
    assert_eq!(r1.instruction_count, r2.instruction_count);
    assert_eq!(r1.io_read, r2.io_read);
    assert_eq!(r1.io_write, r2.io_write);
    assert_eq!(r1.diagnostics.len(), r2.diagnostics.len());
    let s = cache_stats();
    assert_eq!((s.misses, s.hits, s.stores), (1, 1, 1));
    assert_eq!(cache_entry_count(), 1);
}

/// run cache transparency (the execution path twice — the result value is
/// 144 both times; the cache switch has zero effect on execution results).
#[test]
fn production_run_e2e_cache_transparent() {
    cache_reset();
    let o1 = run_source(FIB_SRC, "run_trans.krf").expect("first execution");
    assert!(matches!(o1.value, Value::Int(144)));
    let o2 = run_source(FIB_SRC, "run_trans.krf").expect("second execution(hit)");
    assert!(matches!(o2.value, Value::Int(144)));
    // The hit path's warning face is isomorphic (snapshot reuse, zero drift)
    assert_eq!(o1.warnings.len(), o2.warnings.len());
}

/// Stats-count matrix (N=3 distinct sources × M=3 recompiles — misses=3 /
/// hits=6 / stores=3 / entry_count=3: full-shape count reconciliation of
/// content-addressed key discrimination + single-query discipline).
#[test]
fn production_stats_accounting_matrix() {
    cache_reset();
    let srcs = ["(define a 1)\na", "(define b 2)\nb", "(define c 3)\nc"];
    for (i, src) in srcs.iter().enumerate() {
        for _ in 0..3 {
            let r = check_source(src, &format!("stat{i}.krf")).expect("matrix compile");
            let _ = r;
        }
    }
    let s = cache_stats();
    assert_eq!(s.misses, 3, "three distinct sources one miss each");
    assert_eq!(s.hits, 6, "three distinct sources two hits each");
    assert_eq!(s.stores, 3, "three distinct sources one write each");
    assert_eq!(cache_entry_count(), 3);
}

/// Report-field full equivalence (the miss report vs the hit report —
/// field-by-field comparison of the CheckReport observable face; including
/// the rendered text string-by-string and warning/diagnostic counts
/// [Diagnostic is not PartialEq — count + rendered-face double anchor]).
#[test]
fn production_report_field_parity_hit_vs_miss() {
    cache_reset();
    let r1 = check_source(FIB_SRC, "field_parity.krf").expect("miss report");
    let r2 = check_source(FIB_SRC, "field_parity.krf").expect("hit report");
    assert!(!r1.cache_hit && r2.cache_hit);
    assert_eq!(
        r1.rendered, r2.rendered,
        "render text face should be string-by-string identical"
    );
    assert_eq!(
        r1.warnings.len(),
        r2.warnings.len(),
        "warning count should consistent"
    );
    assert_eq!(
        r1.diagnostics.len(),
        r2.diagnostics.len(),
        "diagnostic count should consistent"
    );
}

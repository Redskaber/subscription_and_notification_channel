//! .ktf macros-corpus family tests — r129 / 199-b (the macro-surface
//! corpus window: the ninth skin-dictionary mapping).
//!
//! **Verification surfaces** (the macro corpus file placed at
//! `examples/usage/macros.ktf` — the target face of its .krf counterpart,
//! completing the .ktf family to ten files, at parity with the .krf
//! family):
//! (1) **run-face E2E** — the macro corpus through `run_source`
//! yields the same program value as its S-expr face counterpart
//! (principle 31 skin/skeleton isomorphism — 42, consumed via
//! `include_str!` so any corpus edit that breaks the chain fails here);
//! (2) **the r129 grammar settlement** — the macro-definition arm form
//! (`macro NAME (lits)? { (pattern) => template, ... }` → the
//! `(define-syntax NAME (syntax-rules ...))` core form) is verified
//! dual-Reader: seed vs mirror canonical Stx rendering byte-identical,
//! error faces message + Span byte-identical, and the hygienic macro
//! machinery (pattern-variable substitution + ellipsis splicing +
//! introduced-identifier renaming) value-anchored through the
//! unchanged expand_define_syntax / SyntaxRules::parse /
//! register_transformer chain; (3) **cross-stage consumption** — the
//! corpus through `check_source_recover` stays diagnostic-clean
//! with real instruction artifacts; (4) **fail-closed negatives** —
//! corpus-shaped rejections across the error classes (the new form's
//! position/structure discipline + the ellipsis absorption boundary +
//! the established families: lexical / grammar / position / unbound /
//! no-clause-match / hygiene / runtime).
//!
//! Skin-dictionary basis: 20 §14 v1.21 (the ninth mapping — the
//! macro-definition arm structure); 02 §8.13.1a v7.14 (the Level 0
//! production). Corpus placement basis: switch-window-plan v1.10
//! next-batch recommendation (macro surface first) + t3plus-trigger-audit
//! v1.48 r128 note (macros.ktf = the only family gap). Ratio:
//! 8 positive : 24 negative = 1:3 (§9.4.3).

use kerf_driver::bootstrap::reader::read_source_for_bootstrap;
use kerf_driver::{check_source_recover, run_source};
use kerf_reader::reader::read_source;
use kerf_syntax::{Stx, StxDatum, StxLiteral, SymbolTable};

// ---------------------------------------------------------------------------
// Corpus family (the artifact under test — include_str! makes the file a
// tested artifact: the corpus-integrity gate)
// ---------------------------------------------------------------------------

const CORPUS_MACROS: &str = include_str!("../../../../examples/usage/macros.ktf");

fn corpus_value(src: &str, filename: &str) -> String {
    let outcome = run_source(src, filename)
        .unwrap_or_else(|e| panic!("corpus {} execution failed:{}", filename, e));
    kerf_vm::render_value(&outcome.value, &outcome.heap)
}

// ---------------------------------------------------------------------------
// Dual-Reader parity helpers (the ktf_stress_corpus_tests.rs caliber —
// canonical rendering with Span bytes; error parity with message + Span
// byte equality)
// ---------------------------------------------------------------------------

fn render_stx(s: &Stx, t: &SymbolTable) -> String {
    let mut out = String::new();
    render_stx_into(s, t, &mut out);
    out
}

fn render_stx_into(s: &Stx, t: &SymbolTable, out: &mut String) {
    match &s.datum {
        StxDatum::Symbol(sym) => {
            out.push_str(&format!(
                "(sym {} {}..{})",
                t.name(*sym),
                s.span.start,
                s.span.end
            ));
        }
        StxDatum::Literal(l) => match l {
            StxLiteral::Int(v) => {
                out.push_str(&format!("(int {} {}..{})", v, s.span.start, s.span.end));
            }
            StxLiteral::Float(f) => {
                out.push_str(&format!("(float {:?} {}..{})", f, s.span.start, s.span.end));
            }
            StxLiteral::Str(r) => {
                out.push_str(&format!("(str {:?} {}..{})", r, s.span.start, s.span.end));
            }
            StxLiteral::Bool(b) => {
                out.push_str(&format!("(bool {} {}..{})", b, s.span.start, s.span.end));
            }
            StxLiteral::Nil => {
                out.push_str(&format!("(nil {}..{})", s.span.start, s.span.end));
            }
        },
        StxDatum::List(items) => {
            out.push_str(&format!("(lst {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
        // r138 / 208-c — TD-002: vectors now reach both Readers (the
        // fourteenth skin mapping) — full canonical rendering
        StxDatum::Vector(items) => {
            out.push_str(&format!("(vec {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
    }
}

/// Grammar parity assertion: both Readers' canonical renderings are
/// byte-identical (the r129 grammar settlement's core gate — the macro
/// definition form is seed/mirror isomorphic by construction).
fn assert_grammar_parity(src: &str, what: &str) {
    let mut t1 = SymbolTable::new();
    let seed = read_source(src, 0, &mut t1)
        .unwrap_or_else(|e| panic!("[{}] seed syntax failed: {}", what, e.message));
    let mut t2 = SymbolTable::new();
    let mirror = read_source_for_bootstrap(src, 0, &mut t2)
        .unwrap_or_else(|e| panic!("[{}] mirror syntax failed:{}", what, e.message));
    assert_eq!(
        seed.len(),
        mirror.len(),
        "[{}] top-level item count mismatch (seed {} vs mirror {})",
        what,
        seed.len(),
        mirror.len()
    );
    for (i, (a, b)) in seed.iter().zip(mirror.iter()).enumerate() {
        assert_eq!(
            render_stx(a, &t1),
            render_stx(b, &t2),
            "[{}] top-level item #{} syntax tree mismatch (seed vs mirror canonical render)",
            what,
            i
        );
    }
}

/// Grammar-error parity assertion: message + Span byte-level equality
/// (the mirror's diagnostic face is the seed's, by construction).
fn assert_grammar_err_parity(src: &str, what: &str) {
    let mut t1 = SymbolTable::new();
    let seed_err = match read_source(src, 0, &mut t1) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] seed should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    let mut t2 = SymbolTable::new();
    let mirror_err = match read_source_for_bootstrap(src, 0, &mut t2) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] mirror should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    assert_eq!(
        seed_err.message, mirror_err.message,
        "[{}] syntax error message mismatch (seed {:?} vs mirror {:?})",
        what, seed_err.message, mirror_err.message
    );
    assert_eq!(
        seed_err.span.start, mirror_err.span.start,
        "[{}] syntax error Span start mismatch (seed {} vs mirror {})",
        what, seed_err.span.start, mirror_err.span.start
    );
    assert_eq!(
        seed_err.span.end, mirror_err.span.end,
        "[{}] syntax error Span end mismatch (seed {} vs mirror {})",
        what, seed_err.span.end, mirror_err.span.end
    );
}

// ---------------------------------------------------------------------------
// Positives — run-face E2E + grammar settlement + cross-stage consumption
// ---------------------------------------------------------------------------

/// Positive 1 / integration: macros.ktf (the r129 grammar settlement's
/// carrier — the ninth skin-dictionary mapping: two hygienic macros, a
/// variadic recursive `my_or` with the ellipsis splicing and a block
/// template `swap` with introduced-identifier renaming) through the
/// production run chain — the program value matches the S-expr face
/// counterpart (macros.krf ⇒ 42).
#[test]
fn corpus_macros_run_e2e() {
    assert_eq!(corpus_value(CORPUS_MACROS, "macros.ktf"), "42");
}

/// Positive 2 / integration / cross-grammar behavioral parity (inline
/// pair — r153 / 223-c: the .krf corpus face retired, the corpus pair
/// leg with it; the inline swap pair keeps the cross-grammar
/// equivalence discipline alive on the driver-API level until E6): the
/// swap shape inlined on both faces ((2 1) = (2 1)) — the corpus faces
/// name freely (`swap` on the target face, `swap!` on the S-expr face),
/// the behavioral parity gates the pair.
#[test]
fn corpus_macros_cross_grammar_value_parity() {
    assert_eq!(corpus_value(CORPUS_MACROS, "macros.ktf"), "42");
    let ktf_swap = "macro swap {\n    (a, b) => {\n        let tmp = a;\n        a = b;\n        b = tmp;\n    }\n}\nlet p = 1;\nlet q = 2;\nswap(p, q)\nlist(p, q)\n";
    assert_eq!(corpus_value(ktf_swap, "swap.ktf"), "(2 1)");
    // E6 r154 / 224-c6: the swap! S-expr twin leg retired with the
    // S-expr face — the swap macro's value anchor pins on the target leg
    // above ("(2 1)").
}

/// Positive 3 / integration: the full corpus is dual-Reader
/// byte-identical in canonical Stx rendering — the macro-definition arm
/// form, the ellipsis elements, the pattern/template trees, and the
/// ordinary statement forms all parse isomorphically (the r129 core
/// gate).
#[test]
fn macro_decl_dual_reader_parity() {
    assert_grammar_parity(CORPUS_MACROS, "macros.ktf all corpus");
    // The literal-set forms: explicit empty set, non-empty set, and the
    // trailing-comma tolerance (the match-arm family convention — both
    // faces parse to the same Stx):
    assert_grammar_parity(
        "macro m (x) { (a) => a }\nmacro n () { (b) => b }\nmacro o (y,) { (c) => c }\nm(1)",
        "literal set three form(explicit empty set + non-empty set + trailing comma tolerated)",
    );
    // The empty-pattern arm + nested sub-pattern + literal elements:
    assert_grammar_parity(
        "macro m {\n    () => false,\n    (1, (a, b), \"s\") => a,\n}\nm()",
        "empty pattern + nested sub-pattern + literal element",
    );
}

/// Positive 4: the variadic recursive macro semantics — the three-arm
/// `my_or` (zero-arg false / one-arg identity / n-arg short-circuit)
/// exercises the clause-ordered matching + the ellipsis sequence
/// splicing + the recursive self-application inside the template.
#[test]
fn recursive_macro_three_arm_semantics() {
    let src = "macro my_or {\n    () => false,\n    (a) => a,\n    (a, rest ...) => if a { true } else { my_or(rest ...) },\n}\nmy_or()\n";
    assert_eq!(corpus_value(src, "t.ktf"), "false");
    let short = "macro my_or {\n    () => false,\n    (a) => a,\n    (a, rest ...) => if a { true } else { my_or(rest ...) },\n}\nmy_or(true, 999)\n";
    assert_eq!(corpus_value(short, "t.ktf"), "true");
    let deep = "macro my_or {\n    () => false,\n    (a) => a,\n    (a, rest ...) => if a { true } else { my_or(rest ...) },\n}\nmy_or(false, false, false, false, false, 42)\n";
    assert_eq!(corpus_value(deep, "t.ktf"), "42");
}

/// Positive 5: hygiene — the introduced identifier `tmp` inside the
/// `swap` template does not capture a user binding of the same name
/// (introduced-identifier renaming through the unchanged HygieneCtx);
/// the user's `tmp` keeps its value across the swap expansion.
#[test]
fn hygienic_swap_introduced_identifier() {
    let src = "macro swap {\n    (a, b) => {\n        let tmp = a;\n        a = b;\n        b = tmp;\n    }\n}\nlet p = 1;\nlet q = 2;\nlet tmp = 77;\nswap(p, q)\nlist(p, q, tmp)\n";
    assert_eq!(
        corpus_value(src, "t.ktf"),
        "(2 1 77)",
        "hygiene violation: template-introduced tmp captures the user binding"
    );
}

/// Positive 6: the pattern-name injection — the macro-name head element
/// is Reader-injected (the user never writes it; the resume-k injection
/// precedent) and a nested sub-pattern destructures in the pattern
/// position; the produced Stx is the exact S-expr-face pattern
/// isomorphism consumed by the unchanged match_clause.
#[test]
fn macro_pattern_name_injection_and_nested() {
    // A nested-sub-pattern macro: ((mk, a, b, c)) matches a one-argument
    // call whose argument is a four-element application node — the call
    // list(1, 2, 3) is the Stx (list 1 2 3); the sub-pattern (mk, a, b,
    // c) matches it element-wise (mk binds the list symbol, c binds 3)
    let src = "macro second_of {\n    ((mk, a, b, c)) => c,\n}\nsecond_of(list(1, 2, 3))\n";
    assert_eq!(corpus_value(src, "t.ktf"), "3");
}

/// Positive 7: the macro literal set — the identifiers in the literal
/// set must match by exact symbol in the pattern position (the
/// syntax-rules literal discipline); a pattern variable named the same
/// as a non-listed identifier stays a binder.
#[test]
fn macro_literal_set_semantics() {
    // `x` in the literal set: the pattern element `x` matches only the
    // literal symbol x; the arm (x, v) fires for pick(x, ...) calls but
    // a call pick(y, 42) falls to the next arm.
    let src =
        "macro pick (x) {\n    (x, v) => v,\n    (a, v) => 0,\n}\nlet x = 100;\npick(x, 42)\n";
    // The literal x matches the argument x (symbol equality) → v = 42
    assert_eq!(corpus_value(src, "t.ktf"), "42");
    let other = "macro pick (x) {\n    (x, v) => v,\n    (a, v) => 0,\n}\npick(y, 42)\n";
    // The literal x does not match the symbol y → the second arm (a
    // binder) → 0
    assert_eq!(corpus_value(other, "t.ktf"), "0");
}

/// Positive 8 / cross-stage: the corpus through the recovery check stays
/// diagnostic-clean with real instruction artifacts (the cross-stage
/// consumption gate — check_source_recover).
#[test]
fn corpus_macros_check_clean_cross_stage() {
    let report = check_source_recover(CORPUS_MACROS, "macros.ktf")
        .unwrap_or_else(|e| panic!("check stage failed:{}", e));
    assert!(
        report.diagnostics.is_empty(),
        "diagnostic non-empty: {:?}",
        report.diagnostics
    );
    assert!(
        report.proto_count + report.const_count > 0,
        "compile artifact is zero(check not produce real compile face)"
    );
}

// ---------------------------------------------------------------------------
// Negatives — fail-closed across the error classes (24)
// ---------------------------------------------------------------------------

/// Negative 1: `macro` inside a block body — the item-position-only
/// discipline (the ordinary "expected expression" fail-closed path).
#[test]
fn neg_macro_in_block_fail() {
    assert!(run_source(
        "fn f() {\n    macro m { (a) => a }\n    1\n}\nf()",
        "bad.ktf"
    )
    .is_err());
}

/// Negative 2: `macro` in expression position (let value) — same
/// item-position discipline.
#[test]
fn neg_macro_in_expression_position_fail() {
    assert!(
        run_source("let x = macro;\n1", "bad.ktf").is_err(),
        "expression position macro should fail-closed"
    );
}

/// Negative 3: missing macro name (a keyword head instead of ident).
#[test]
fn neg_macro_missing_name_fail() {
    assert!(
        run_source("macro { (a) => a }\n1", "bad.ktf").is_err(),
        "missing macro name should be a read error"
    );
}

/// Negative 4: the macro name position holds a keyword (match) — the
/// "expected macro-name identifier" diagnostic.
#[test]
fn neg_macro_name_keyword_fail() {
    assert!(
        run_source("macro match { (a) => a }\n1", "bad.ktf").is_err(),
        "keyword position macro name should be a read error"
    );
}

/// Negative 5: missing body brace.
#[test]
fn neg_macro_missing_brace_fail() {
    assert!(
        run_source("macro m (a) => a\n1", "bad.ktf").is_err(),
        "missing macro body braces should be a read error"
    );
}

/// Negative 6: empty body (zero clauses) — the syntax-rules at-least-one
/// contract, settled at read time.
#[test]
fn neg_macro_empty_body_fail() {
    assert!(
        run_source("macro m { }\n1", "bad.ktf").is_err(),
        "zero-arm macro body should be a read error(syntax-rules at least one clause contract)"
    );
}

/// Negative 7: missing `=>` between the pattern and the template.
#[test]
fn neg_arm_missing_arrow_fail() {
    assert!(
        run_source("macro m { (a) a }\n1", "bad.ktf").is_err(),
        "missing => should be a read error"
    );
}

/// Negative 8: the pattern is not a paren form (a bare identifier).
#[test]
fn neg_arm_pattern_not_paren_fail() {
    assert!(
        run_source("macro m { a => a }\n1", "bad.ktf").is_err(),
        "non-parenthesized pattern should be a read error"
    );
}

/// Negative 9: an operator in the pattern element position.
#[test]
fn neg_pattern_element_operator_fail() {
    assert!(
        run_source("macro m { (a + b) => a }\n1", "bad.ktf").is_err(),
        "pattern element operator should be a read error"
    );
}

/// Negative 10: unclosed pattern paren.
#[test]
fn neg_pattern_unclosed_fail() {
    assert!(
        run_source("macro m { (a, b => a }\n1", "bad.ktf").is_err(),
        "pattern unclosed should be a read error"
    );
}

/// Negative 11: unclosed nested sub-pattern.
#[test]
fn neg_pattern_nested_unclosed_fail() {
    assert!(
        run_source("macro m { ((a, b) => a }\n1", "bad.ktf").is_err(),
        "nested sub-pattern unclosed should be a read error"
    );
}

/// Negative 12: a digit in the literal set (identifiers only).
#[test]
fn neg_literal_set_digit_fail() {
    assert!(
        run_source("macro m (5) { (a) => a }\n1", "bad.ktf").is_err(),
        "literal-set digits should be a read error"
    );
}

/// Negative 13: unclosed literal set.
#[test]
fn neg_literal_set_unclosed_fail() {
    assert!(
        run_source("macro m (x { (a) => a }\n1", "bad.ktf").is_err(),
        "literal set unclosed should be a read error"
    );
}

/// Negative 14: missing template (the comma right after `=>`).
#[test]
fn neg_template_missing_fail() {
    assert!(
        run_source("macro m { (a) => , (b) => b }\n1", "bad.ktf").is_err(),
        "missing template should be a read error"
    );
}

/// Negative 15: a keyword head at the template position (`=> fn`).
#[test]
fn neg_template_keyword_start_fail() {
    assert!(
        run_source("macro m { (a) => fn }\n1", "bad.ktf").is_err(),
        "template position keyword start should be a read error"
    );
}

/// Negative 16: the block template with a statement missing its `;`.
#[test]
fn neg_template_stmt_missing_semi_fail() {
    assert!(
        run_source(
            "macro m {\n    (a, b) => {\n        let t = a;\n        a = b\n        b = t;\n    }\n}\n1",
            "bad.ktf"
        )
        .is_err(),
        "block template statement missing semicolon should be a read error"
    );
}

/// Negative 17: an ellipsis mid-sequence (`f(a ... b)`) — unabsorbed
/// (absorption requires the ')' | ',' | eof follower), the ordinary
/// "expected )" fail-closed path.
#[test]
fn neg_ellipsis_mid_sequence_fail() {
    assert!(
        run_source("macro m { (a, rest ...) => a }\nm(1, 2 ... 3)\n", "bad.ktf").is_err() || {
            // Reading may succeed on one face only by accident of the
            // stream position; both faces must fail overall (the
            // call itself never parses to a runnable program).
            let mut ok = false;
            let _ = run_source("macro m { (a, rest ...) => a }\nm(1, 2 ... 3)\n", "b.ktf")
                .map(|_| ok = true);
            !ok
        },
        "ellipsis middle position should fail-closed"
    );
}

/// Negative 18: a macro call matching no clause (a variadic macro without
/// the zero-arg base arm recursing to emptiness) — the expansion-time
/// "no clause matched" face.
#[test]
fn neg_macro_call_no_clause_match_fail() {
    assert!(
        run_source(
            "macro m { (a, rest ...) => m(rest ...) }\nm(1)\n",
            "bad.ktf"
        )
        .is_err(),
        "no matching clause should be an expansion-time error"
    );
}

/// Negative 19: the unbound-ellipsis call parity — `f(a ...)` outside a
/// template produces the same Stx `(f a ...)` the S-expr face reads; the
/// expansion-time error is face-isomorphic (both faces fail; the target
/// face's error mentions the unbound family).
#[test]
fn neg_unbound_ellipsis_call_fail() {
    let err = run_source("f(a ...)\n", "bad.ktf")
        .expect_err("non-template position ellipsis call should report an error");
    assert!(
        !err.to_string().is_empty(),
        "error message non-empty(unbound family expand phase error)"
    );
    // The S-expr face twin fails too (the face-isomorphic shape):
    assert!(run_source("(f a ...)\n", "bad.krf").is_err());
}

/// Negative 20: calling an undefined macro — the unbound family (the
/// expander's macro-registry miss falls to the ordinary unbound-global
/// path).
#[test]
fn neg_unbound_macro_call_fail() {
    assert!(
        run_source("no_such_macro(1)\n", "bad.ktf").is_err(),
        "not definition macro call should report an error"
    );
}

/// Negative 21-24 / grammar-error parity: the mirror's diagnostic face is
/// the seed's, message + Span byte-identical (the r129 core settlement's
/// error-parity gate — four representative structure errors).
#[test]
fn neg_grammar_err_parity_macro_structure() {
    assert_grammar_err_parity("macro { (a) => a }\n", "missing macro name");
    assert_grammar_err_parity("macro m { (a) a }\n", "missing =>");
    assert_grammar_err_parity("macro m { (a + b) => a }\n", "pattern element operator");
    assert_grammar_err_parity("macro m { }\n", "zero-arm macro body");
    assert_grammar_err_parity("macro m (5) { (a) => a }\n", "literal-set digits");
    assert_grammar_err_parity("macro m { (a, b => a }\n", "pattern unclosed");
    assert_grammar_err_parity("macro m (x,,) { (a) => a }\n", "literal set dual comma");
    assert_grammar_err_parity("macro m { (a,,) => a }\n", "pattern dual comma");
}

/// Negative 25: the empty-pattern arm is a Unit token — the lexical Unit
/// ambiguity is decided by the syntactic position (pattern position =
/// the empty paren form); a unit token in the element position is the
/// nil literal. The zero-arg call then matches the empty pattern.
/// (Positive-side anchor already covered; here the fail-closed face:
/// calling with an argument a macro that only has the empty arm.)
#[test]
fn neg_zero_arm_macro_with_arg_call_fail() {
    assert!(
        run_source("macro m { () => false }\nm(1)\n", "bad.ktf").is_err(),
        "zero-argument macro called with arguments should mismatch report an error"
    );
}

/// Negative 26: the literal-set double comma — an empty identifier
/// position (the trailing single comma is legal tolerance — the
/// match-arm family; a comma in the identifier position is not an
/// identifier → fail-closed).
#[test]
fn neg_literal_set_double_comma_fail() {
    assert!(
        run_source("macro m (x,,) { (a) => a }\n1", "bad.ktf").is_err(),
        "literal set double comma empty element position should be a read error"
    );
}

/// Negative 27: the pattern with a double comma — an empty element
/// position (the trailing single comma is legal tolerance — the
/// match-arm family; a comma in the element position is not an
/// element → fail-closed).
#[test]
fn neg_pattern_double_comma_fail() {
    assert!(
        run_source("macro m { (a,,) => a }\n1", "bad.ktf").is_err(),
        "pattern double comma empty element position should be a read error"
    );
}

/// Negative 28: the template referencing a pattern variable not bound by
/// the pattern — the hygiene/instantiation family (an unbound template
/// identifier survives expansion as an unbound global at runtime).
#[test]
fn neg_template_unbound_reference_fail() {
    assert!(
        run_source("macro m { (a) => zzz_missing }\nm(1)\n", "bad.ktf").is_err(),
        "template unbound reference should in run-time report unbound"
    );
}

/// Negative 29: the ellipsis dimension mismatch — a template ellipsis
/// without a matching pattern ellipsis binding (the macro_sys dimension
/// discipline, the established negative family).
#[test]
fn neg_ellipsis_dimension_mismatch_fail() {
    // The template `(a ...)` splices the variable `a` as a sequence, but
    // the pattern binds `a` as a single element — dimension mismatch.
    assert!(
        run_source("macro m { (a) => list(a ...) }\nm(1)\n", "bad.ktf").is_err(),
        "ellipsis dimension mismatch should be an expansion-time error"
    );
}

/// Negative 30: an unclosed string in the corpus (the lexical family).
#[test]
fn neg_unclosed_string_lexical_fail() {
    assert!(
        run_source("macro m { (\"s) => 1 }\n1", "bad.ktf").is_err(),
        "unclosed string should lexical wrong"
    );
}

/// Negative 31: the macro definition inside a module body — the
/// item-position discipline extends to the module surface (module items
/// dispatch through parse-item: legal placement; here the negative is
/// the *expression-position* macro inside a module body block).
#[test]
fn neg_macro_in_module_expr_position_fail() {
    assert!(
        run_source(
            "module m {\n    export x;\n    let x = macro;\n}\n1",
            "bad.ktf"
        )
        .is_err(),
        "module in body expression position macro should fail-closed"
    );
}

/// Negative 32: the arm-separator discipline — two arms without the
/// comma separator (the pattern of the second arm follows the first
/// template directly: fail-closed).
#[test]
fn neg_arm_missing_separator_fail() {
    assert!(
        run_source("macro m { (a) => a (b) => b }\n1", "bad.ktf").is_err(),
        "missing comma separator between arms should be a read error"
    );
}

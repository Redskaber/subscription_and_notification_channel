// E6 close-out (r154 / 224-c6): corpus converted to the target-syntax face.
//! T3+ optimization window r55 (77-b) — VM frame slot pool (P1 pooling +
//! P3 slot-clearing division-of-labor protocol) semantic zero-drift guard
//! tests (the third piece of the TD-028 optimization window — frame slot
//! pooling).
//!
//! **Contract terms** (td028-frame-pool-optimization.md §3.3 four arguments +
//! §4 contract): pooling must not change (a) captured-sharing semantics
//! (TD-023 — under the `strong_count == 1` guard rail, frame slots captured
//! or referenced by continuation snapshots are never reused); (b) defensive
//! semantics (a slot not written after acquire = nil); (c) GC survival
//! (cells in the pool hold zero heap references + reused slots maintain the
//! heap-rootness digest via `GcCell::set`); (d) frame semantics on all paths
//! (Ret/TailCall frame replacement / resume truncation / INSTALL_HANDLER
//! thunk frame pooling).
//!
//! Coverage (§9.4.3 positive:negative ratio — behavior anchors first +
//! error-face anchors):
//! - Capture guard rail: frame popped after closure capture → slot does not
//!   enter the pool (shared cells are not reused — later frames see no
//!   cross-talk of values);
//! - Defensive semantics: reading a pool-reused frame's Let slot before
//!   writing = nil (P3 slot-clearing division of labor — the acquire side
//!   normalizes);
//! - Pool depth cap: deep non-tail recursion 5000 levels (> CELL_POOL_CAP
//!   256 — capping goes the drop path, behavior identical);
//! - R4 self-loop: tail recursion 100k levels (release the old frame before
//!   acquiring the new one — pool depth 1 steady state, all hits) + mutual
//!   tail recursion;
//! - continuation frames: PERFORM snapshot sharing (truncated frame
//!   strong_count ≥ 2 → takes the drop guard rail) + slot values intact
//!   after resume;
//! - GC interaction: under allocation pressure + pooling, live objects stay
//!   correct (dangling safety);
//! - Determinism + fib 25 count anchor (r52-r55 performance evolution chain
//!   value anchor);
//! - Pool length mismatch resilience: alternating calls with different
//!   n_locals (truncate / pad paths).

use crate::common;

// ---------------------------------------------------------------------------
// Capture guard rail (TD-023 sharing semantics — pool abandonment path)
// ---------------------------------------------------------------------------

/// Frame popped after captured sharing: the pool guard rail must abandon
/// that frame's slots (cell count > 1); the slot value from the closure's
/// perspective is not corrupted by later frame reuse — the counter
/// propagates correctly through set!.
#[test]
fn p1_captured_cell_not_reused_counter() {
    // make-counter's n slot is captured by the closure (strong_count > 1 on pop → does not enter the pool)
    let src = "fn make_counter() { let n = 0; || { n = n + 1; n } }
let c1 = make_counter();
let c2 = make_counter();
c1(); c1(); c1();
c2();
list(c1(), c2())";
    let out = common::run_rendered(src);
    assert_eq!(
        out, "(4 2)",
        "capture slots do not enter the pool: two counters increment independently, \n{}",
        out
    );
}

/// Capture + pool alternation: when captured frames (take the drop path) and ordinary frames (take the pool) alternate, slot values stay isolated.
#[test]
fn p1_capture_and_pool_frames_alternate() {
    let src = "fn make_adder(k: i64) { || (x: i64) { x + k } }
let a3 = make_adder(3);
fn plain(x: i64) -> i64 { x * 10 }
list(a3(1), plain(1), a3(2), plain(2), a3(3))";
    let out = common::run_rendered(src);
    assert_eq!(
        out, "(4 10 5 20 6)",
        "capture frames and pooled frames alternate without value bleed: \n{}",
        out
    );
}

// ---------------------------------------------------------------------------
// Defensive semantics (P3 slot-clearing division of labor — acquire-side
// normalization)
// ---------------------------------------------------------------------------

/// Reading a pool-reused frame's Let slot before writing = nil (defensive
/// semantics unchanged — non-heap leftovers in the pool are always
/// overwritten with nil by the acquire side).
#[test]
fn p3_pool_reused_let_slot_reads_nil_before_write() {
    // Call f first to warm the pool (its frame slots carry non-nil leftovers — validates acquire-side clearing)
    let src = "fn warm(x: i64) -> i64 { let y = x; y + 1 }
warm(41);
fn f(x: i64) -> i64 { let y = 5; x + y }
fn g(x: i64) -> i64 { if (is_nil(quote(dummy))) { 0 } else { 0 } }
g(0);
f(1)";
    let _ = common::run_rendered(src);
    // is-nil(quote dummy) → #f → 0; main anchor: warm pops its frame into
    // the pool and f reuses the slots — f's let y is an explicit binding
    // (not a defensive read). The direct defensive-read anchor: an unwritten
    // slot reads out nil.
    let src2 = "fn warm(x: i64) -> i64 { let y = x; y + 1 }
warm(1);
fn h() -> i64 { let z = 0; z }
h()";
    assert_eq!(common::run_rendered(src2), "0");
}

/// Shallow call after deep recursion: reuse after pool depth caps and recedes (truncate path).
#[test]
fn p3_pool_truncate_path_after_deep_recursion() {
    let src =
        "fn count(n: i64, acc: i64) -> i64 { if (n == 0) { acc } else { count(n - 1, acc + 1) } }
count(300, 0);
fn two_arg(a: i64, b: i64) -> i64 { a + b }
two_arg(1, 2);
fn six_arg(a: i64, b: i64, c: i64, d: i64, e: i64, f: i64) -> i64 { a + (b + (c + (d + (e + f)))) }
six_arg(1, 2, 3, 4, 5, 6)";
    let out = common::run_rendered(src);
    assert_eq!(
        out, "21",
        "pool length mismatch elasticity(truncate/padding path): \n{}",
        out
    );
}

// ---------------------------------------------------------------------------
// Pool depth cap and deep recursion (beyond CELL_POOL_CAP takes the drop
// path — behavior identical)
// ---------------------------------------------------------------------------

/// Deep non-tail recursion 5000 levels (far beyond CELL_POOL_CAP=256 —
/// after capping there are several re-entry misses; value correctness is
/// unaffected by pool state).
#[test]
fn p1_deep_nontail_5000_value_correct() {
    let src = "fn sum(n: i64) -> i64 { if (n == 0) { 0 } else { n + sum(n - 1) } }
sum(5000)";
    let out = common::run_rendered(src);
    assert_eq!(
        out, "12502500",
        "deep non-tail recursion 5000 layer pool maximum path: \n{}",
        out
    );
}

// ---------------------------------------------------------------------------
// R4 self-loop (TailCall releases the old frame before acquiring the new
// one)
// ---------------------------------------------------------------------------

/// Tail recursion 100k levels (frame-replacement self-loop — pool depth 1 steady state, all hits + correct value).
#[test]
fn p1_tailcall_pool_self_cycle_100k() {
    let src =
        "fn loop(n: i64, acc: i64) -> i64 { if (n == 0) { acc } else { loop(n - 1, acc + 1) } }
loop(100000, 0)";
    let out = common::run_rendered(src);
    assert_eq!(
        out, "100000",
        "tail-recursive self-loop 10 100k levels: \n{}",
        out
    );
}

/// Mutual tail recursion (two functions alternating frame replacement — pool slots reused alternately).
#[test]
fn p1_mutual_tailcall_alternating_frames() {
    let src = "fn ping(n: i64) -> T { if (n == 0) { quote(done) } else { pong(n - 1) } }
fn pong(n: i64) -> T { if (n == 0) { quote(over) } else { ping(n - 1) } }
list(ping(101), ping(100))";
    let out = common::run_rendered(src);
    assert_eq!(
        out, "(over done)",
        "mutual tail-recursion alternating frames: \n{}",
        out
    );
}

// ---------------------------------------------------------------------------
// continuation / effects (PERFORM truncated frames take the drop guard
// rail + slot values intact after resume)
// ---------------------------------------------------------------------------

/// Effect resume round trip: after the suspended frame chain (snapshot
/// shared → truncated frames do not enter the pool) is restored, the
/// suspended frame's local slot values are intact (κ resume semantics have
/// no cross-talk with pooling).
#[test]
fn p1_effect_resume_frame_locals_preserved() {
    let src = "fn ask() { perform tick(1); }
fn gen() { let x = 10; x + ask() }
handle gen() { tick(p, k) => resume(p + 100) }";
    let out = common::run_rendered(src);
    assert_eq!(
        out, "111",
        "resume after suspended frame local slot x=10 intact: \n{}",
        out
    );
}

/// Deeply nested handle + perform truncation: multiple frames truncated (the snapshot holds them all → drop guard rail).
#[test]
fn p1_nested_perform_deep_truncation() {
    let src = "fn emit() { perform base(0); }
fn depth(n: i64) -> i64 { if (n == 0) { emit() } else { 1 + depth(n - 1) } }
handle depth(50) { base(p, k) => resume(p) }";
    let out = common::run_rendered(src);
    assert_eq!(
        out, "50",
        "deep nested perform truncation 50 layer recovery: \n{}",
        out
    );
}

// ---------------------------------------------------------------------------
// GC interaction (cells in the pool hold zero heap references + reused
// slots maintain the heap-rootness digest via set)
// ---------------------------------------------------------------------------

/// Allocation pressure + pooling + GC cycles: the live pair chain stays
/// correct under the storm of pooled-frame allocation/recycling (dangling
/// safety — after pool cells clear heap references, GC does not wrongly
/// reclaim live objects).
#[test]
fn p1_gc_survival_under_pool_storm() {
    let src = "fn churn(n: i64, keep: T) -> T { if (n == 0) { keep } else { churn(n - 1, cons(n, keep)) } }
let alive = churn(2000, ());
fn sum_list(lst: T, acc: i64) -> i64 { if (is_nil(lst)) { acc } else { sum_list(tail(lst), head(lst) + acc) } }
sum_list(alive, 0)";
    let out = common::run_rendered(src);
    // sum 1..2000 = 2000*2001/2 = 2001000
    assert_eq!(
        out, "2001000",
        "GC liveness anchor(pooling storm under pair chain intact): \n{}",
        out
    );
}

// ---------------------------------------------------------------------------
// Determinism and value anchors
// ---------------------------------------------------------------------------

/// Determinism: two runs of the same program are bit-identical (pool state introduces no nondeterminism).
#[test]
fn p1_determinism_double_run() {
    let src = "fn f(n: i64) -> i64 { if (n < 2) { n } else { f(n - 1) + f(n - 2) } }
f(15)";
    let a = common::run_rendered(src);
    let b = common::run_rendered(src);
    assert_eq!(a, b, "dual run determinism: \n{}\nvs\n{}", a, b);
    assert_eq!(a, "610");
}

/// fib 25 count anchor (value anchor of the r52-r55 performance evolution chain — pooling causes zero numeric drift).
#[test]
fn p1_fib25_value_anchor() {
    let src = "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }
fib(25)";
    let out = common::run_rendered(src);
    assert_eq!(out, "75025", "fib 25 value anchor: \n{}", out);
}

// ---------------------------------------------------------------------------
// Error-face anchors (error message preservation on pooled paths —
// cur_span! / guard-rail text)
// ---------------------------------------------------------------------------

/// Arity error message preservation on the pooling hot path (the arity check in the Call arm before acquire).
#[test]
fn p1_arity_error_on_pool_hot_path() {
    let err = common::run(
        "fn warm(x: i64) -> i64 { x }
warm(1);
fn f(x: i64) -> i64 { x }
f(1, 2)",
    )
    .unwrap_err();
    assert!(
        err.contains("argument count"),
        "pooled hot-path arity errors preserved: \n{}",
        err
    );
    assert!(
        err.contains("line 4") || err.contains("line 4") || err.contains("4:"),
        "error position points to the call line:\n{}",
        err
    );
}

/// Type-error span correctness after deep-recursion frame pops (the pool path).
#[test]
fn p1_error_span_after_pool_release_path() {
    let err = common::run(
        "fn g(n: i64) -> i64 { if (n == 0) { head(5) } else { g(n - 1) } }
g(100)",
    )
    .unwrap_err();
    assert!(
        err.contains("head") || err.contains("pair"),
        "pool path after error message preserved: \n{}",
        err
    );
}

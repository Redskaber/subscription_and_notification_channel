// E6 close-out (r154 / 224-c5): corpus converted to the target-syntax face.
//! r144 / 214-c — read-line signature-entry gate (32 case,
//! 8 positive : 24 negative = 1:3 — read-line-sig-design.md D8).
//!
//! The registered row (tc-sigs-parity-design §7 "read-line 签名条目")
//! was excluded by four consecutive walk-throughs (r140-r143) on the
//! premise "运行时执法缺位先行" — an R4 documentation debt in the audit
//! chain itself: the runtime has enforced exact 0-arity since the FS-4
//! fix (20 §4 B3 contract; the stale builtins.rs tail comment claimed
//! otherwise — corrected in this window). With the premise satisfied,
//! the entry is cleared on BOTH faces (oracle `BUILTIN_SIGS` +
//! check.ktf `TC-SIGS`, the read-int/read-num family form: gated,
//! fixed 0-arg, Unknown result — hit Str ∪ EOF Nil has no union
//! constructor under the 8-kind freeze, r142 member D3 precedent).
//!
//! **Verification surfaces**:
//! (1) **static face gains the rejection** — `read_line(1)` now reports
//!     E0005 "procedure argument count mismatch: expected 0..0, got N"
//!     (the layer-orthogonal twin of the runtime E0004 bottom —
//!     原则 42);
//! (2) **derivation tightening** — the r135 rename chain (`use
//!     kerf_io::{read_line as rl}` → TC-RENAME → TC-SIGS) and the
//!     oracle qualified derivation (`io/read-line`) resolve through to
//!     the new entry (the "underlying miss → Dynamic" honest-boundary
//!     instance is retired);
//! (3) **zero false positives** — the Unknown result flows constraint-free
//!     through every value-consuming position (r80 contract, r142 D4
//!     three-layer argument);
//! (4) **neighbor discipline** — E0006 capability gate precedence, the
//!     value-position A4 rule, the runtime E0004 face, and the existing
//!     61 rows are all untouched (append-only insert).
//!
//! E6 close-out (r154 / 224-c5): the S-expr seed face retired — the
//! former seed legs drive the same target chain through the alternate
//! program shape (fn-declaration / `define(x, v);` value-definition
//! forms; the target legs keep the statement shape — 224-c3/c4
//! precedent); filenames `.krf` → `.ktf`; the N24 corpus anchors judge
//! through the sole target face (counts re-calibrated by running —
//! identical 5/1/0/2/0/0/0).
//!
//! Basis: read-line-sig-design.md v1.0 (D1-D8) + tc-sigs-parity-design
//! §7 + builtins.rs BUILTIN_SIGS + check.ktf TC-SIGS + 09-stdlib §3 r8
//! note (FS-4) + 20 §4 B3. Ratio 8:24 (§9.4.3).

use kerf_driver::builtins::{builtin_sigs, builtin_sigs_with_renames};
use kerf_driver::{check_source_recover, compile_source, run_source};
use kerf_syntax::SymbolTable;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/// Alternate program-shape static check: zero diagnostics (the
/// zero-false-positive family — r80 contract first priority; E6
/// close-out r154 / 224-c5: the S-expr seed face retired — the former
/// seed legs drive the same target chain through the alternate program
/// shape, the target legs keep the statement shape).
fn alt_clean(src: &str) {
    let report = check_source_recover(src, "rls.ktf").expect("check must pass compile");
    assert!(
        report.diagnostics.is_empty(),
        "alternate shape must be diagnostic-free: {:?}\nsrc: {}",
        report.rendered,
        src
    );
}

/// Target-face static check: zero diagnostics.
fn target_clean(src: &str) {
    let report = check_source_recover(src, "rls.ktf").expect("check must pass compile");
    assert!(
        report.diagnostics.is_empty(),
        "target face must be diagnostic-free: {:?}\nsrc: {}",
        report.rendered,
        src
    );
}

/// Alternate program-shape static check: exactly `count` diagnostics,
/// one containing `needle` (exact-count discipline — the r142
/// contains-any masking-gap closure carries over).
fn alt_diag_exactly(src: &str, needle: &str, count: usize) {
    let report = check_source_recover(src, "rlsneg.ktf").expect("check must pass compile");
    assert_eq!(
        report.diagnostics.len(),
        count,
        "alternate shape must report exactly {} diagnostic(s): {:?}\nsrc: {}",
        count,
        report
            .diagnostics
            .iter()
            .map(|d| d.message.as_str())
            .collect::<Vec<_>>(),
        src
    );
    assert!(
        report
            .diagnostics
            .iter()
            .any(|d| d.message.contains(needle)),
        "alternate shape diagnostic must contain `{}`\nsrc: {}",
        needle,
        src
    );
}

/// Target-face static check: exactly `count` diagnostics, one containing
/// `needle`.
fn target_diag_exactly(src: &str, needle: &str, count: usize) {
    let report = check_source_recover(src, "rlsneg.ktf").expect("check must pass compile");
    assert_eq!(
        report.diagnostics.len(),
        count,
        "target face must report exactly {} diagnostic(s): {:?}\nsrc: {}",
        count,
        report
            .diagnostics
            .iter()
            .map(|d| d.message.as_str())
            .collect::<Vec<_>>(),
        src
    );
    assert!(
        report
            .diagnostics
            .iter()
            .any(|d| d.message.contains(needle)),
        "target face diagnostic must contain `{}`\nsrc: {}",
        needle,
        src
    );
}

/// Alternate program-shape run: expect a runtime error whose rendered
/// output contains `needle` (the E0004 fail-closed bottom — untouched
/// by this window).
fn alt_run_err(src: &str, needle: &str) {
    let e = run_source(src, "rlsrun.ktf").expect_err("runtime face must reject (E0004 family)");
    assert!(
        e.rendered.contains(needle),
        "runtime error must contain `{}`: actual {}\nsrc: {}",
        needle,
        e.rendered,
        src
    );
}

/// Rust-oracle judgment count (direct hm_check_program call — the
/// fallback face; check ⊆ oracle direction guard per r140 form #8).
fn oracle_diag_count(src: &str) -> usize {
    let out = compile_source(src, "rlsor.ktf").expect("pre-stage compile failed");
    let mut table = out.table;
    let sigs = builtin_sigs(&mut table);
    kerf_compiler::hm::hm_check_program(&out.core, &sigs, &table)
        .diags
        .len()
}

// ---------------------------------------------------------------------------
// P1-P8: positive family (8)
// ---------------------------------------------------------------------------

/// P1: zero-arg clean (alternate fn shape) — the entry insert is
/// append-only (the zero-arg authorized call stays diagnostic-free; FS-4
/// runtime contract and the new static contract agree on the legal form).
#[test]
fn p01_krf_zero_arg_clean() {
    alt_clean("require io, read;\nfn probe() -> T { read_line() }\nprobe()");
}

/// P2: zero-arg clean (target statement shape) — the sole-face legal
/// form (E6: the former dual-face pair is carried as the two program
/// shapes).
#[test]
fn p02_ktf_zero_arg_clean() {
    target_clean("require io, read;\nread_line()");
}

/// P3: result Unknown flows constraint-free through a value-consuming
/// chain (define + list + head — zero false positives, r80 contract;
/// the union domain Str ∪ Nil has no constructor so the honest result
/// is Unknown — D3).
#[test]
fn p03_result_unknown_value_flow_clean() {
    alt_clean("require io, read;\nlet s = read_line();\nhead(list(s))");
}

/// P4: if-condition consumption zero false positives (fresh unify bool —
/// the r142 D4 layer argument carries over verbatim for the Unknown
/// result).
#[test]
fn p04_if_condition_unknown_clean() {
    alt_clean("require io, read;\nif (read_line()) { 1 } else { 2 }");
}

/// P5: rename zero-arg clean — the r135 chain now resolves through to
/// the entry (the premise-flipped canonical form of
/// neg_r135_hm_read_family_a4_carryover).
#[test]
fn p05_rename_zero_arg_derived_clean() {
    alt_clean("require io, read;\nuse kerf_io::{read_line as rl};\nrl()");
}

/// P6: value-position A4 discipline unchanged — read_line passed as a
/// value (not an application head) stays Dynamic (signature entries are
/// consumed only at the apply-position lookup — r135 D12 rule).
#[test]
fn p06_value_position_a4_unchanged() {
    alt_clean("require io, read;\nlet f = read_line;\nf()");
}

/// P7: table-level parity — the oracle map holds the read-line entry
/// with the read-int/read-num family shape (fixed 0-arg, Unknown result)
/// and the flat-name face is exactly 58 (56 + read-line + % — the r140
/// single-source count anchor extended; r164/235-c: five self-built list
/// faces left the registered face).
#[test]
fn p07_oracle_table_shape_and_flat_count() {
    use kerf_compiler::{TcParams, TcType};
    let mut table = SymbolTable::new();
    let sigs = builtin_sigs(&mut table);
    let flat: Vec<String> = sigs
        .keys()
        .map(|s| table.name(*s).to_string())
        .filter(|n| n.len() <= 1 || !n.contains('/'))
        .collect();
    assert_eq!(
        flat.len(),
        58,
        "oracle flat-name face must be 58 (56 + read-line + % r159/229-c; r164/235-c: the five self-built list faces left the registered face — length/reverse/nth/drop/last-pair, their bindings = the injected kerf defines): {:?}",
        flat
    );
    let sym = table.intern("read-line");
    let sig = sigs
        .get(&sym)
        .expect("read-line must be in the oracle signature map");
    assert!(
        matches!(sig.params, TcParams::Fixed(p) if p.is_empty()),
        "read-line params must be fixed empty (exact 0-arity): {:?}",
        sig.params
    );
    assert_eq!(sig.min_args, 0, "read-line min_args must be 0");
    assert_eq!(sig.max_args, Some(0), "read-line max_args must be Some(0)");
    assert!(
        matches!(sig.result, TcType::Unknown),
        "read-line result must be Unknown (hit Str ∪ EOF Nil): {:?}",
        sig.result
    );
}

/// P8: derivation closure — the oracle qualified derivation covers
/// io/read-line and the rename derivation covers the renamed binding
/// (the r135 miss-skip path has zero live misses now — D5 closure).
#[test]
fn p08_derivation_closure_qualified_and_rename() {
    let mut table = SymbolTable::new();
    let sigs = builtin_sigs(&mut table);
    let q = table.intern("io/read-line");
    assert!(
        sigs.contains_key(&q),
        "qualified derivation must cover io/read-line"
    );
    let with_renames =
        builtin_sigs_with_renames(&mut table, &[("rl".to_string(), "read-line".to_string())]);
    let r = table.intern("rl");
    assert!(
        with_renames.contains_key(&r),
        "rename derivation must cover the read-line binding"
    );
    // Defensive miss-skip: an underlying that misses is skipped (zero
    // live misses today — the path stays as the deterministic boundary).
    let phantom = builtin_sigs_with_renames(
        &mut table,
        &[("px".to_string(), "no-such-underlying".to_string())],
    );
    let px = table.intern("px");
    assert!(
        !phantom.contains_key(&px),
        "a missing underlying must be skipped (defensive path)"
    );
}

// ---------------------------------------------------------------------------
// N1-N24: negative family (24)
// ---------------------------------------------------------------------------

/// N1: flat-name arity (alternate fn shape) — the static face gains the
/// E0005 rejection (the canonical new-capability form; previously
/// silent A4 pass vs the runtime E0004 bottom — the static-dynamic gap
/// this window closes).
#[test]
fn n01_krf_flat_arity_e0005() {
    alt_diag_exactly(
        "require io, read;\nfn probe() -> T { read_line(1) }\nprobe()",
        "procedure argument count mismatch: expected 0..0, got 1",
        1,
    );
}

/// N2: flat-name arity (target statement shape) — message parity (the
/// same violation, the same count and message family on the statement
/// shape; E6: the former dual-face pair is carried as the two program
/// shapes).
#[test]
fn n02_ktf_flat_arity_e0005() {
    target_diag_exactly(
        "require io, read;\nread_line(1)",
        "procedure argument count mismatch: expected 0..0, got 1",
        1,
    );
}

/// N3: multi-extra-arg form — the count threads through (got 3).
#[test]
fn n03_multi_extra_args_count_threading() {
    alt_diag_exactly(
        "require io, read;\nread_line(1, 2, 3)",
        "procedure argument count mismatch: expected 0..0, got 3",
        1,
    );
}

/// N4: oracle face rejects the same violation (check ⊆ oracle direction
/// — both faces gain the rejection together, the r140 form #8 guard).
#[test]
fn n04_oracle_face_rejects_same_violation() {
    let krf = check_source_recover(
        "require io, read;\nfn probe() -> T { read_line(1) }\nprobe()",
        "n04.ktf",
    )
    .expect("check must pass compile");
    let oracle = oracle_diag_count("require io, read;\nfn probe() -> T { read_line(1) }\nprobe()");
    assert!(
        !krf.diagnostics.is_empty(),
        "check face must reject the extra-arg call"
    );
    assert!(
        oracle >= krf.diagnostics.len(),
        "oracle face must reject at least as much (check ⊆ oracle): oracle {} vs check {}",
        oracle,
        krf.diagnostics.len()
    );
}

/// N5: rename-chain tightening — `rl(1)` now rejects through the r135
/// chain (the honest-boundary *tightened* side: the old A4 silent
/// position is gone; anchored as the premise flip of
/// neg_r135_hm_read_family_a4_carryover).
#[test]
fn n05_rename_chain_tightened() {
    alt_diag_exactly(
        "require io, read;\nuse kerf_io::{read_line as rl};\nrl(1)",
        "procedure argument count mismatch: expected 0..0, got 1",
        1,
    );
}

/// N6: rename-chain multi-arg form — the chain resolution threads the
/// count (got 2).
#[test]
fn n06_rename_chain_multi_arg() {
    alt_diag_exactly(
        "require io, read;\nuse kerf_io::{read_line as rl};\nrl(1, 2)",
        "procedure argument count mismatch: expected 0..0, got 2",
        1,
    );
}

/// N7: E0006 capability gate precedence — an unauthorized read_line
/// reference still reports E0006 on the front face (the gate precedes
/// the HM signature face).
#[test]
fn n07_e0006_gate_precedence() {
    let e = run_source("read_line()", "n07.ktf")
        .expect_err("unauthorized read_line must be E0006-rejected");
    assert!(
        e.rendered.contains("E0006") && e.rendered.contains("read"),
        "unauthorized face must stay E0006: {}",
        e.rendered
    );
}

/// N8: unauthorized + wrong arity still reports E0006 (not E0005) — the
/// capability gate is ordered before the signature gate on the front
/// face.
#[test]
fn n08_e0006_before_signature_gate() {
    let e = run_source("read_line(1)", "n08.ktf")
        .expect_err("unauthorized + wrong arity must stay E0006");
    assert!(
        e.rendered.contains("E0006"),
        "capability gate must precede the signature gate: {}",
        e.rendered
    );
}

/// N9: runtime face maintained — the E0004 fail-closed bottom is
/// byte-identical (FS-4 enforcement + r141 unified message form; this
/// window adds zero runtime changes).
#[test]
fn n09_runtime_e0004_maintained() {
    alt_run_err(
        "require io, read;\nfn probe() -> T { read_line(1) }\nprobe()",
        "read-line requires 0 arguments, got 1",
    );
}

/// N10: qualified-name dual verdict — the oracle face derives
/// io/read-line and rejects the extra-arg call; the check face keeps the
/// generic path for qualified heads (check.ktf's registered
/// qualified-not-in-table boundary — check ⊆ oracle direction legal).
#[test]
fn n10_qualified_name_dual_verdict() {
    let out = compile_source("require io, read;\nio::read_line(1)", "n10.ktf")
        .expect("pre-stage compile failed");
    let mut table = out.table;
    let sigs = builtin_sigs(&mut table);
    let oracle = kerf_compiler::hm::hm_check_program(&out.core, &sigs, &table)
        .diags
        .len();
    assert!(
        oracle >= 1,
        "oracle face must reject the qualified extra-arg call (derived entry)"
    );
    let krf = check_source_recover("require io, read;\nio::read_line(1)", "n10.ktf")
        .expect("check must pass compile");
    assert!(
        krf.diagnostics.is_empty(),
        "check face keeps the qualified generic path (check ⊆ oracle): {:?}",
        krf.rendered
    );
}

/// N11: zero-arg EOF runtime convention — a subprocess probe with null
/// stdin: `read_line()` ⇒ nil (the deterministic discipline anchor —
/// capability_tests' r8-era probe carried over as the cross-stage
/// consumption anchor).
#[test]
fn n11_zero_arg_eof_nil_subprocess() {
    use std::process::{Command, Stdio};
    // r153 / 223-c: the probe switched to the .ktf single face (the CLI
    // .krf entry retired — s-expr-removal-plan §4 Batch D).
    let tmp = std::env::temp_dir().join("kerf-rls-eof-probe.ktf");
    std::fs::write(&tmp, "require io, read;\nread_line()").expect("write input probe program");
    let out = Command::new(env!("CARGO_BIN_EXE_kerf"))
        .args(["run", tmp.to_str().unwrap()])
        .stdin(Stdio::null())
        .output()
        .expect("should can start kerf sub process");
    let stdout = String::from_utf8_lossy(&out.stdout);
    assert!(
        out.status.success(),
        "EOF read should succeed, stderr: {}",
        String::from_utf8_lossy(&out.stderr)
    );
    assert!(
        stdout.contains("nil"),
        "EOF read should yield nil, got: {}",
        stdout
    );
    let _ = std::fs::remove_file(&tmp);
}

/// N12: E0006 reverse-lookup dual-name form maintained — the renamed
/// read_line referenced without authorization still reports E0006 with
/// the `(io member read-line)` anchor (r135 D13-② face unchanged).
#[test]
fn n12_e0006_reverse_lookup_dual_name() {
    let e = run_source("use kerf_io::{read_line as rl};\nrl()", "n12.ktf")
        .expect_err("unauthorized rename must be E0006-rejected");
    assert!(
        e.rendered.contains("E0006") && e.rendered.contains("(io member read-line)"),
        "reverse-lookup dual-name anchor maintained: {}",
        e.rendered
    );
}

/// N13: static/runtime layer orthogonality — the static face reports
/// E0005 "…(static check)" while the runtime bottom reports E0004 with
/// the op+got message (原则 42: unified yet separated — the two layers
/// are not mirror obligations).
#[test]
fn n13_layer_orthogonality_e0005_vs_e0004() {
    let report = check_source_recover("require io, read;\nread_line(1)", "n13.ktf")
        .expect("check must pass compile");
    let static_msg = report
        .diagnostics
        .iter()
        .map(|d| d.message.as_str())
        .collect::<Vec<_>>();
    assert!(
        static_msg
            .iter()
            .any(|m| m.contains("expected 0..0, got 1")),
        "static layer form: {:?}",
        static_msg
    );
    let e =
        run_source("require io, read;\nread_line(1)", "n13r.ktf").expect_err("runtime must reject");
    assert!(
        e.rendered.contains("E0004") && e.rendered.contains("requires 0 arguments"),
        "runtime layer form: {}",
        e.rendered
    );
}

/// N14: read-family neighbors zero-regression — read_int / read_num
/// extra-arg rejections unchanged (the family rows this entry mirrors).
#[test]
fn n14_read_family_neighbors_zero_regression() {
    alt_diag_exactly(
        "require io, read;\nread_int(1)",
        "procedure argument count mismatch: expected 0..0, got 1",
        1,
    );
    alt_diag_exactly(
        "require io, read;\nread_num(1)",
        "procedure argument count mismatch: expected 0..0, got 1",
        1,
    );
}

/// N15: I/O-segment neighbor zero-regression — print (the write-gated
/// 1-arg neighbor) enforcement unchanged.
#[test]
fn n15_write_family_neighbor_zero_regression() {
    alt_diag_exactly(
        "require io, write;\nprint()",
        "procedure argument count mismatch: expected 1..1, got 0",
        1,
    );
}

/// N16: far-end row zero-regression — a distant table member keeps its
/// enforcement (append-only insert discipline).
#[test]
fn n16_far_end_row_zero_regression() {
    alt_diag_exactly(
        "import kerf_vector;\nvector_length(1, 2)",
        "procedure argument count mismatch: expected 1..1, got 2",
        1,
    );
}

/// N17: prelude combination zero false positives — the check+prelude
/// composite face stays clean on the legal zero-arg form (TD-030 family
/// combination anchor).
#[test]
fn n17_prelude_combination_clean() {
    alt_clean("import kerf_list;\nrequire io, read;\nread_line()");
}

/// N18: deep-nested Unknown consumption zero false positives — the
/// result flows through arithmetic and if layers without polluting the
/// chain (fresh no-pollution — the r142 'any-pollution lesson's
/// counterpart).
#[test]
fn n18_deep_nested_unknown_consumption_clean() {
    alt_clean("require io, read;\n1 + if (read_line()) { 2 } else { 3 }");
}

/// N19: check + run double-layer agreement — the same legal program
/// passes the static face and runs to the EOF-nil convention (each
/// layer legal on its own terms).
#[test]
fn n19_check_run_double_layer_agreement() {
    alt_clean("require io, read;\nfn probe() -> T { read_line() }\nprobe()");
    // run face: stdin is null-probed in N11; here the in-process run
    // reads the test-runner stdin shape — only the compile pipeline is
    // asserted (the value face is N11's subprocess anchor).
    let out = compile_source(
        "require io, read;\nfn probe() -> T { read_line() }\nprobe()",
        "n19.ktf",
    );
    assert!(out.is_ok(), "compile pipeline must accept the legal form");
}

/// N20: no-alias lexical face — read_line has no old-name alias (r42
/// removal-round): a probe name is an unbound global, not a signature
/// member (the E0022/removal face anchor).
#[test]
fn n20_no_alias_unbound_face() {
    let e = run_source("require io, read;\nread_line_legacy()", "n20.ktf")
        .expect_err("probe name must be unbound");
    assert!(
        e.rendered.contains("unbound") || e.rendered.contains("E0022"),
        "probe name must stay unbound (no alias face): {}",
        e.rendered
    );
}

/// N21: nested argument position enforcement — the extra-arg call
/// inside a nested consumer still reports (recursive inference chain).
#[test]
fn n21_nested_argument_position_enforced() {
    alt_diag_exactly(
        "require io, read;\nhead(list(read_line(1)))",
        "procedure argument count mismatch: expected 0..0, got 1",
        1,
    );
}

/// N22: recovery-mode multi-error collection — two violations collect
/// into two diagnostics (the TD-013 DiagCollector face).
#[test]
fn n22_recovery_multi_error_collected() {
    alt_diag_exactly(
        "require io, read;\nread_line(1);\nread_line(2)",
        "procedure argument count mismatch",
        2,
    );
}

/// N23: cross-shape diagnostic-count parity — the same violation reports
/// an equal count on both program shapes (r135 dual-face consistency
/// anchor; E6 close-out rework r154 / 224-c5: the S-expr face retired —
/// the parity slot is carried by the two target program shapes, the
/// fn-declaration form and the statement form).
#[test]
fn n23_cross_face_count_parity() {
    let krf = check_source_recover(
        "require io, read;\nfn probe() -> T { read_line(1) }\nprobe()",
        "n23.ktf",
    )
    .expect("check must pass compile");
    let ktf = check_source_recover("require io, read;\nread_line(1)", "n23.ktf")
        .expect("check must pass compile");
    assert_eq!(
        krf.diagnostics.len(),
        ktf.diagnostics.len(),
        "cross-shape diagnostic count must be equal: fn form {:?} vs statement form {:?}",
        krf.rendered,
        ktf.rendered
    );
}

/// N24: corpus-anchor zero-flip — the seven self-hosted corpora + fib
/// judgment anchors stay at their r80-pinned counts (the insert touches
/// no existing row's enforcement; expander 5 / compiler 1 / reader 0 /
/// check 2 / build 0 / cli 0 / fib 0 — the r142 re-anchored baseline;
/// E6 close-out r154 / 224-c5: the former .krf trio retired with the
/// S-expr face — every corpus judges through the sole target Reader,
/// counts re-calibrated identical 5/1/0/2/0/0/0).
#[test]
fn n24_corpus_anchor_zero_flip() {
    let anchors: [(&str, &str, usize); 7] = [
        (
            // r164 / 235-c: 5 → 0 — the five static-domain diagnostics
            // (nth/drop call-site family) retired with the self-built
            // migration's generic (T,T) inference (fail-closed moved wholly
            // to the runtime face — messages verbatim; list-self-built-
            // design.md D7).
            "crates/kerf-driver/src/bootstrap/expander.ktf",
            "exp.ktf",
            0,
        ),
        (
            "crates/kerf-driver/src/bootstrap/compiler.ktf",
            "comp.ktf",
            1,
        ),
        ("crates/kerf-driver/src/bootstrap/reader.ktf", "read.ktf", 0),
        ("crates/kerf-driver/src/bootstrap/check.ktf", "chk.ktf", 2),
        ("crates/kerf-driver/src/bootstrap/build.ktf", "bld.ktf", 0),
        ("crates/kerf-driver/src/bootstrap/cli.ktf", "cli.ktf", 0),
        // r153 / 223-c: the usage-corpus anchor switched to the .ktf single
        // face (the .krf corpus retired — s-expr-removal-plan §4 Batch D).
        ("examples/usage/fib.ktf", "fib.ktf", 0),
    ];
    for (path, fname, expect) in anchors {
        let src = std::fs::read_to_string(path)
            .unwrap_or_else(|e| panic!("corpus read failed for {}: {}", path, e));
        let report = check_source_recover(&src, fname)
            .unwrap_or_else(|e| panic!("corpus check failed for {}: {}", path, e.rendered));
        assert_eq!(
            report.diagnostics.len(),
            expect,
            "corpus anchor {} must stay at {} (zero-flip guard): {:?}",
            path,
            expect,
            report.rendered
        );
    }
}

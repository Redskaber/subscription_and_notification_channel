//! ktf_quality_door_tests — TD-040 Batch 1 quality regression door
//! (corpus-quality-batch-design.md D5).
//!
//! The door re-implements the audit metric in Rust (lexical scan with
//! string/comment stripping + fn-body brace-depth counting — the
//! `tools/audit/ktf_quality_audit.py` caliber) and asserts the Batch 1
//! boundary over the whole bootstrap corpus:
//!
//! 1. zero stacked-else sites (`else {` wrapping exactly one if — the
//!    flatten door; regression of the r166 mass rewrite),
//! 2. zero span>80 functions (the nine-split door),
//! 3. depth>4 count at or under the frozen Batch 1 ceiling (38 — the
//!    honest Batch 2 remainder; Batch 2 may lower it, never raise).
//!
//! Negative cases feed constructed samples to the detectors (stacked
//! else / deep nesting / long fn / non-single-statement else blocks /
//! braces inside strings and comments) and assert the detectors fire or
//! stay silent exactly as designed.

use std::fs;
use std::path::PathBuf;

/// One function entry discovered by the lexical scan.
#[derive(Debug)]
struct FnEntry {
    name: String,
    max_depth: i32,
    span: usize,
}

/// Same-length neutralized copy: string literals and comments blanked so
/// brace matching ignores them (the audit D1 metric caliber).
fn neutralize(src: &str) -> String {
    let bytes = src.as_bytes();
    let mut out: Vec<u8> = bytes.to_vec();
    let mut i = 0usize;
    let mut in_str = false;
    while i < bytes.len() {
        let ch = bytes[i];
        if in_str {
            if ch == b'\\' {
                if i + 1 < bytes.len() {
                    out[i + 1] = b' ';
                }
                out[i] = b' ';
                i += 2;
                continue;
            }
            if ch == b'"' {
                in_str = false;
            }
            out[i] = b' ';
            i += 1;
            continue;
        }
        if ch == b'"' {
            in_str = true;
            out[i] = b' ';
            i += 1;
            continue;
        }
        if ch == b';' && i + 1 < bytes.len() && bytes[i + 1] == b';' {
            let mut j = i;
            while j < bytes.len() && bytes[j] != b'\n' {
                out[j] = b' ';
                j += 1;
            }
            i = j;
            continue;
        }
        if ch == b'/' && i + 1 < bytes.len() && bytes[i + 1] == b'/' {
            let mut j = i;
            while j < bytes.len() && bytes[j] != b'\n' {
                out[j] = b' ';
                j += 1;
            }
            i = j;
            continue;
        }
        i += 1;
    }
    String::from_utf8(out).expect("ascii-neutralized copy")
}

/// Scan a corpus source: fn entries with max brace depth (fn body = 1)
/// and line span.
fn scan_fns(src: &str) -> Vec<FnEntry> {
    let neutral = neutralize(src);
    let raw_lines: Vec<&str> = src.lines().collect();
    let neu_lines: Vec<&str> = neutral.lines().collect();
    let mut entries: Vec<FnEntry> = Vec::new();
    let mut cur: Option<FnEntry> = None;
    let mut depth: i32 = 0;
    for (idx, neu) in neu_lines.iter().enumerate() {
        let raw = raw_lines.get(idx).copied().unwrap_or("");
        let trimmed = raw.trim_start();
        if cur.is_none() && trimmed.starts_with("fn ") && trimmed.contains('(') {
            let name = trimmed[3..]
                .split('(')
                .next()
                .unwrap_or("?")
                .trim()
                .to_string();
            let opens = neu.matches('{').count() as i32;
            let closes = neu.matches('}').count() as i32;
            depth = if neu.contains('{') { opens - closes } else { 0 };
            cur = Some(FnEntry {
                name,
                max_depth: depth.max(0),
                span: 1,
            });
            continue;
        }
        if let Some(entry) = cur.as_mut() {
            let opens = neu.matches('{').count() as i32;
            let closes = neu.matches('}').count() as i32;
            depth += opens - closes;
            entry.max_depth = entry.max_depth.max(depth);
            entry.span += 1;
            if depth <= 0 {
                entries.push(cur.take().expect("entry"));
            }
        }
    }
    if let Some(entry) = cur.take() {
        entries.push(entry);
    }
    entries
}

/// Count stacked-else sites: `else {` wrapping exactly one if statement
/// (the flatten_else_if.py detector caliber — fixpoint-zero door).
fn count_stacked_else(src: &str) -> usize {
    let neutral = neutralize(src);
    let bytes = neutral.as_bytes();
    let mut count = 0usize;
    let mut i = 0usize;
    while i < bytes.len() {
        if bytes[i] == b'e' && &neutral[i..i.saturating_add(4)] == "else" {
            let before_ok =
                i == 0 || !(bytes[i - 1].is_ascii_alphanumeric() || bytes[i - 1] == b'_');
            let mut j = i + 4;
            let after_word =
                j < bytes.len() && (bytes[j].is_ascii_alphanumeric() || bytes[j] == b'_');
            if before_ok && !after_word {
                // skip ws
                while j < bytes.len()
                    && (bytes[j] == b' '
                        || bytes[j] == b'\n'
                        || bytes[j] == b'\t'
                        || bytes[j] == b'\r')
                {
                    j += 1;
                }
                if j < bytes.len() && bytes[j] == b'{' {
                    // first significant token inside
                    let mut p = j + 1;
                    while p < bytes.len()
                        && (bytes[p] == b' '
                            || bytes[p] == b'\n'
                            || bytes[p] == b'\t'
                            || bytes[p] == b'\r')
                    {
                        p += 1;
                    }
                    if neutral[p..].starts_with("if")
                        && !(p + 2 < bytes.len()
                            && (bytes[p + 2].is_ascii_alphanumeric() || bytes[p + 2] == b'_'))
                    {
                        // single-if else block candidate: walk the if span,
                        // then expect only ws until the wrapper close.
                        if let Some(if_end) = if_span_end(&neutral, p) {
                            let mut q = if_end;
                            while q < bytes.len()
                                && (bytes[q] == b' '
                                    || bytes[q] == b'\n'
                                    || bytes[q] == b'\t'
                                    || bytes[q] == b'\r')
                            {
                                q += 1;
                            }
                            if q < bytes.len() && bytes[q] == b'}' {
                                count += 1;
                            }
                        }
                    }
                }
            }
        }
        i += 1;
    }
    count
}

/// End index (exclusive) of a complete if-expression starting at `start`
/// (the `if` keyword), including else / else-if tails. None on malformed.
fn if_span_end(neutral: &str, start: usize) -> Option<usize> {
    let bytes = neutral.as_bytes();
    if !neutral[start..].starts_with("if") {
        return None;
    }
    let mut j = start + 2;
    skip_ws(bytes, &mut j);
    if j >= bytes.len() || bytes[j] != b'(' {
        return None;
    }
    let mut depth = 0i32;
    while j < bytes.len() {
        match bytes[j] {
            b'(' => depth += 1,
            b')' => {
                depth -= 1;
                if depth == 0 {
                    j += 1;
                    break;
                }
            }
            _ => {}
        }
        j += 1;
    }
    skip_ws(bytes, &mut j);
    if j >= bytes.len() || bytes[j] != b'{' {
        return None;
    }
    match_brace(bytes, j)?;
    j = match_brace(bytes, j)? + 1;
    loop {
        let mut k = j;
        skip_ws(bytes, &mut k);
        if neutral[k..].starts_with("else") {
            let k2 = k + 4;
            let word_after =
                k2 < bytes.len() && (bytes[k2].is_ascii_alphanumeric() || bytes[k2] == b'_');
            if word_after {
                return Some(j);
            }
            let mut m = k2;
            skip_ws(bytes, &mut m);
            if neutral[m..].starts_with("if")
                && !(m + 2 < bytes.len()
                    && (bytes[m + 2].is_ascii_alphanumeric() || bytes[m + 2] == b'_'))
            {
                j = if_span_end(neutral, m)?;
                continue;
            }
            if m < bytes.len() && bytes[m] == b'{' {
                j = match_brace(bytes, m)? + 1;
                continue;
            }
            return Some(j);
        }
        return Some(j);
    }
}

fn skip_ws(bytes: &[u8], j: &mut usize) {
    while *j < bytes.len()
        && (bytes[*j] == b' ' || bytes[*j] == b'\n' || bytes[*j] == b'\t' || bytes[*j] == b'\r')
    {
        *j += 1;
    }
}

fn match_brace(bytes: &[u8], open: usize) -> Option<usize> {
    let mut depth = 0i32;
    let mut i = open;
    while i < bytes.len() {
        match bytes[i] {
            b'{' => depth += 1,
            b'}' => {
                depth -= 1;
                if depth == 0 {
                    return Some(i);
                }
            }
            _ => {}
        }
        i += 1;
    }
    None
}

fn bootstrap_dir() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("crates/kerf-driver/src/bootstrap")
}

fn corpus_sources() -> Vec<(String, String)> {
    let mut out = Vec::new();
    let dir = bootstrap_dir();
    let mut names: Vec<_> = fs::read_dir(&dir)
        .expect("bootstrap dir readable")
        .filter_map(|e| e.ok())
        .map(|e| e.file_name().to_string_lossy().to_string())
        .filter(|n| n.ends_with(".ktf"))
        .collect();
    names.sort();
    for name in names {
        let src = fs::read_to_string(dir.join(&name)).expect("seed readable");
        out.push((name, src));
    }
    out
}

// ===== Positive doors (the Batch 1 boundary over the real corpus) =====

/// P01: zero stacked-else sites across the whole bootstrap corpus (the
/// r166 mass-flatten fixpoint holds — any reintroduced `} else { if`
/// wrapper trips this door).
#[test]
fn p01_flatten_fixpoint_zero_sites() {
    for (name, src) in corpus_sources() {
        let sites = count_stacked_else(&src);
        assert_eq!(sites, 0, "stacked-else site in {name}: flatten regression");
    }
}

/// P02: zero span>80 functions across the whole bootstrap corpus (the
/// nine-split door — compile_expr / lex_op / expand_core_form / tc_unify /
/// parse_primary / postfix_loop / tc_infer_app_general /
/// parse_pattern_atom / tc_rule_one all live under the limit now).
#[test]
fn p02_span_door_zero_long_functions() {
    for (name, src) in corpus_sources() {
        for entry in scan_fns(src.as_str()) {
            assert!(
                entry.span <= 80,
                "{name}: fn {} spans {} lines (>80 — split door)",
                entry.name,
                entry.span
            );
        }
    }
}

/// P03: depth>4 count at or under the frozen Batch 1 ceiling (38 — the
/// genuine-nesting remainder registered for Batch 2; Batch 2 may lower
/// it, a regression may never raise it).
#[test]
fn p03_depth_ceiling_frozen() {
    let mut over = 0usize;
    for (_name, src) in corpus_sources() {
        for entry in scan_fns(src.as_str()) {
            if entry.max_depth > 4 {
                over += 1;
            }
        }
    }
    assert!(
        over <= 38,
        "depth>4 count {over} exceeds the frozen Batch 1 ceiling 38"
    );
}

// ===== Negative faces (the detectors fire / stay silent as designed) =====

/// N01: the stacked-else detector fires on a constructed wrapper.
#[test]
fn n01_detector_fires_on_stacked_else() {
    let src =
        "fn probe(x: T) {\n    if (x) { 1 } else {\n        if (x) { 2 } else { 3 }\n    }\n}\n";
    assert_eq!(count_stacked_else(src), 1);
}

/// N02: the detector does NOT fire on an already-flat `else if` chain.
#[test]
fn n02_flat_chain_not_flagged() {
    let src = "fn probe(x: T) {\n    if (x) { 1 } else if (x) { 2 } else { 3 }\n}\n";
    assert_eq!(count_stacked_else(src), 0);
}

/// N03: braces inside string literals never count (no false stacked-else,
/// no false depth).
#[test]
fn n03_string_braces_immune() {
    let src = "fn probe() {\n    let s = \"} else { if\";\n    s\n}\n";
    assert_eq!(count_stacked_else(src), 0);
    let entries = scan_fns(src);
    assert_eq!(entries.len(), 1);
    assert!(entries[0].max_depth <= 2);
}

/// N04: braces inside comments never count.
#[test]
fn n04_comment_braces_immune() {
    let src = "fn probe() {\n    // } else { if (x) { y }\n    1\n}\n";
    assert_eq!(count_stacked_else(src), 0);
}

/// N05: an else block containing the if PLUS another statement is NOT a
/// single-if wrapper (the flatten law's precondition — never flagged).
#[test]
fn n05_multi_statement_else_not_flagged() {
    let src = "fn probe(x: T) {\n    if (x) {\n        1\n    } else {\n        let y = 2;\n        if (y) { 3 } else { 4 }\n    }\n}\n";
    assert_eq!(count_stacked_else(src), 0);
}

/// N06: the depth detector fires on a constructed deep nest.
#[test]
fn n06_depth_detector_fires() {
    // line-separated nesting so the line-granular net counter sees every
    // level (same-line transient depth is invisible to the audit caliber —
    // both the python and Rust detectors share this by construction)
    let src = "fn probe(x: T) {\n    if (x) {\n        if (x) {\n            if (x) {\n                if (x) {\n                    if (x) {\n                        1\n                    }\n                }\n            }\n        }\n    }\n}\n";
    let entries = scan_fns(src);
    assert_eq!(entries.len(), 1);
    assert!(entries[0].max_depth >= 6, "depth {}", entries[0].max_depth);
}

/// N07: the span detector fires on a constructed 80+ line function.
#[test]
fn n07_span_detector_fires() {
    let mut src = String::from("fn probe() {\n    0\n");
    for _ in 0..90 {
        src.push_str("    ;\n");
    }
    src.push_str("}\n");
    let entries = scan_fns(&src);
    assert_eq!(entries.len(), 1);
    assert!(entries[0].span > 80, "span {}", entries[0].span);
}

/// N08: a comment line between `else` and `{` is still a wrapper site
/// (whitespace-only skip — comments are whitespace-class here, matching
/// the python detector's skip_ws over the neutralized text).
#[test]
fn n08_comment_between_else_and_brace() {
    let src = "fn probe(x: T) {\n    if (x) { 1 } else\n    // why\n    {\n        if (x) { 2 } else { 3 }\n    }\n}\n";
    assert_eq!(count_stacked_else(src), 1);
}

/// N09: the corpus scan finds the expected anchor functions (the
/// detector wiring is live — a broken corpus path fails here first).
#[test]
fn n09_corpus_scan_live() {
    let sources = corpus_sources();
    assert!(sources.len() >= 11, "corpus files: {}", sources.len());
    let reader = sources
        .iter()
        .find(|(n, _)| n == "reader.ktf")
        .expect("reader.ktf present");
    let entries = scan_fns(reader.1.as_str());
    let names: Vec<&str> = entries.iter().map(|e| e.name.as_str()).collect();
    assert!(names.contains(&"lex_op_multi_char"));
    assert!(names.contains(&"lex_op_single_char"));
    assert!(names.contains(&"parse_primary"));
}

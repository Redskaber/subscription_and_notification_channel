// E6 close-out (r154 / 224-c6): corpus converted to the target-syntax face.
//! T3+ optimization window r53 (75-b) — HM solver performance evolution
//! (O1 path compression + O4 structure sharing) semantic zero-drift guard
//! tests (t3-optimization-plan.md §3 five means, item five: a newly added
//! performance evolution test face).
//!
//! **Contract terms** (r53 plan §2 general principles): optimization must
//! not change (a) the diagnostic set and messages byte for byte (including
//! E0005 α numbering — unchanged fresh allocation order is a precondition);
//! (b) globals rendering output; (c) generalization/value-restriction/occurs
//! judgment results.
//!
//! Coverage (§9.4.3 positive:negative ratio — negative anchors first):
//! - O1 path compression semantics: after long-chain unification
//!   (consecutive variable-variable binds), occurs/unify/generalization
//!   behavior is unchanged (transitive-closure equivalence);
//! - occurs detection maintained: self-application/true occurs still E0005
//!   (including α-numbering rendering);
//! - O4 structure-sharing correctness: multiple instantiations of a generic
//!   function produce equivalent type structures (including letrec
//!   recursion + higher-order composition sharing paths);
//! - fresh allocation order anchor: two checks of the same source produce
//!   fully identical diagnostics (determinism);
//! - value-restriction/generalization boundaries maintained: set! targets
//!   weakly monomorphic / let-bind generalization unchanged.

use kerf_driver::builtins::builtin_sigs;
use kerf_driver::check_source_recover;

const FNAME: &str = "hm53.ktf";

/// Rust oracle direct-call assertion (r80 semantic re-anchor: the krf face
/// [production] after fixes ③ and ④ has conservative false-negative
/// boundaries — concrete errors under parameterized instantiation /
/// recursive arity / Pair generic constraints — whose detection capability
/// is guarded by this oracle direct-call reference face).
fn oracle_hm_diag(src: &str, msg: &str) {
    let out = kerf_driver::compile_source(src, FNAME).expect("pre-stage compile failed");
    let mut table = out.table;
    let sigs = builtin_sigs(&mut table);
    let diags = kerf_compiler::hm::hm_check_program(&out.core, &sigs, &table).diags;
    assert!(
        diags.iter().any(|d| d.message.contains(msg)),
        "oracle not detected `{}`: \n program: {}",
        msg,
        src
    );
}

/// HM checking entry (recovery mode — the production judging face, same source as CLI `kerf check`).
fn check(src: &str) -> kerf_driver::CheckReport {
    check_source_recover(src, FNAME).expect("well-formed source not should Reader short-circuit")
}

/// Semantic anchor: diagnostic set determinism (two checks of the same
/// source fully agree — a precondition guard that the fresh allocation
/// order is unchanged; neither O1 nor O4 may introduce nondeterminism).
#[test]
fn diagnostics_deterministic_across_runs() {
    let src = r#"
fn compose(f: T, g: T) -> T { || (x: T) { f(g(x)) } }
fn twice(f: T) -> T { compose(f, f) }
fn add1(n: i64) -> i64 { n + 1 }
twice(twice(add1), 0)
"#;
    let a = check(src);
    let b = check(src);
    let ra: Vec<String> = a.rendered.clone();
    let rb: Vec<String> = b.rendered.clone();
    assert_eq!(
        ra, rb,
        "twice check render output must bit-for-bit consistent(determinism anchor)"
    );
    assert_eq!(a.diagnostics.len(), b.diagnostics.len());
}

/// O1 path compression: after long-chain unification (consecutive α-chain
/// binds), occurs judgment is maintained — true self-application is still
/// detected (E0005); non-self-application always passes.
#[test]
fn occurs_detection_survives_path_compression() {
    // True occurs: ω-combinator self-application (α unified with (α → β))
    let self_app = r#"
fn omega(f: T) -> T { f(f) }
omega(omega)
"#;
    let r = check(self_app);
    assert!(
        r.rendered.iter().any(|l| l.contains("E0005")),
        "self-application occurs must detected(O1 push shrink not get swallows diagnostics): \n{:?}",
        r.rendered
    );

    // Not occurs: two-variable chain unification passes normally (chain-compression path correctness)
    let chain_ok = r#"
fn id(x: T) -> T { x }
fn apply2(f: T, a: T, b: T) -> T { f(a, b) }
fn pair_with(x: T) -> T { || (y: T) { cons(x, y) } }
apply2(|| (a: T, b: T) { cons(a, b) }, id(1), id(2))
"#;
    let r2 = check(chain_ok);
    assert!(
        !r2.rendered.iter().any(|l| l.contains("E0005")),
        "chain unification normal path must not false-positive(O1 transitive closure equivalence): \n{:?}",
        r2.rendered
    );
}

/// Self-application occurs message (r80 semantic re-anchor: after fix ⑤
/// self-application salvage, the krf face detects "cannot construct an
/// infinite type"; α variable ids render in the Rust-oracle-face message
/// shape — message-level parity honest boundary, guarded by the oracle
/// direct-call reference face).
#[test]
fn e0005_message_renders_alpha_ids() {
    let src = r#"
fn bad(f: T) -> T { f(f) }
bad(bad)
"#;
    let r = check(src);
    let hit = r
        .rendered
        .iter()
        .find(|l| l.contains("E0005"))
        .expect("E0005 should exists");
    assert!(
        hit.contains("cannot construct an infinite type"),
        "occurs self-application detected maintained(fix positive⑤ rescued): \n{}",
        hit
    );
}

/// O4 structure sharing: multiple references to a generic function
/// (instantiation ×3) yield equivalent type structures — the shared-node
/// path (ptr_eq short circuit) judges the same as the copy path.
#[test]
fn shared_instantiation_polymorphic_identity() {
    let src = r#"
fn id(x: T) -> T { x }
id(1)
id("s")
id(cons(1, 2))
"#;
    let r = check(src);
    assert!(
        !r.rendered.iter().any(|l| l.contains("E0005")),
        "generic multi-instantiation must not false-positive(O4 sharing correctness): \n{:?}",
        r.rendered
    );
}

/// O4 + letrec recursive generalization: mutual-recursion function group (shared body path) judgment unchanged.
#[test]
fn letrec_group_generalization_unchanged() {
    let src = r#"
fn is_even(n: i64) -> bool { if (n == 0) { true } else { is_odd(n - 1) } }
fn is_odd(n: i64) -> bool { if (n == 0) { false } else { is_even(n - 1) } }
is_even(10)
"#;
    let r = check(src);
    assert!(
        !r.rendered.iter().any(|l| l.contains("E0005")),
        "mutual-recursion generalization must not false-positive: \n{:?}",
        r.rendered
    );
}

/// Value restriction maintained: set! target weakly monomorphic (not generalized) — cross-type assignment is still detectable.
#[test]
fn value_restriction_set_target_monomorphic() {
    let src = r#"
let counter = 0;
counter = counter + 1;
counter = "str";
counter()
"#;
    let r = check(src);
    // set! across types: concrete lattice join → Dynamic (conservative
    // contract D3) — the zero-false-positive posture is maintained (no new
    // E0005)
    assert!(
        !r.rendered.iter().any(|l| l.contains("E0005")),
        "set! format join conservative contract maintained(does not generalize zero false positives): \n{:?}",
        r.rendered
    );
}

/// O1 deep-chain scenario: chained higher-order composition (multi-level compose) infers normally.
#[test]
fn deep_chain_higher_order_composition() {
    let src = r#"
fn compose(f: T, g: T) -> T { || (x: T) { f(g(x)) } }
fn c1(f: T) -> T { compose(f, f) }
fn c2(f: T) -> T { compose(c1(f), c1(f)) }
fn c3(f: T) -> T { compose(c2(f), c2(f)) }
fn add1(n: i64) -> i64 { n + 1 }
(c3(add1))(0)
"#;
    let r = check(src);
    assert!(
        !r.rendered.iter().any(|l| l.contains("E0005")),
        "deep-chain higher-order composition must not false-positive: \n{:?}",
        r.rendered
    );
}

/// Pair structure path: head/tail constraint chain (Pair construct-destructure round trip) judgment maintained.
#[test]
fn pair_destructure_constraint_chain_unchanged() {
    let ok_src = r#"
fn swap(p: T) -> T { cons(head(p), tail(p)) }
swap(cons(1, "b"))
"#;
    let r = check(ok_src);
    assert!(
        !r.rendered.iter().any(|l| l.contains("E0005")),
        "Pair round-trip constraint must not false-positive: \n{:?}",
        r.rendered
    );
    // Negative case: non-pair argument to head (r80 semantic re-anchor: the
    // krf face's parameterized path does not propagate concrete errors from
    // generalized instantiation — conservative false-negative boundary
    // [fix ④]; detection capability guarded by the oracle direct-call
    // reference face)
    let bad_src = r#"
fn first_of(p: T) -> T { head(p) }
first_of(42)
"#;
    oracle_hm_diag(bad_src, "type mismatch");
}

/// Generalization boundary maintained: let-bind generalization (SML canonical) + outer same-name exclusion semantics unchanged.
#[test]
fn let_binding_generalization_boundary() {
    let src = r#"
fn run(x: T) -> T { let f = || (y: T) { cons(x, y) }; cons(f(1), f("s")) }
run(0)
"#;
    let r = check(src);
    assert!(
        !r.rendered.iter().any(|l| l.contains("E0005")),
        "let generalization boundary maintained: \n{:?}",
        r.rendered
    );
}

/// Numeric tower lattice semantics: Int/Float/Num mutually match (union
/// domain) — lattice unification judgment unchanged after O1 compression.
#[test]
fn numeric_lattice_unification_unchanged() {
    let src = r#"
fn mean(a: T, b: T) { (a + b) / 2 }
mean(1, 2)
mean(1.5, 2.5)
mean(1, 2.5)
"#;
    let r = check(src);
    assert!(
        !r.rendered.iter().any(|l| l.contains("E0005")),
        "numeric tower unification maintained(Int/Float/Num mutually match): \n{:?}",
        r.rendered
    );
}

/// Recursive preset + generalization point: define recursion (D4 preset
/// variable unified with the RHS) judgment maintained — O1 write-back must
/// not pollute the preset chain.
#[test]
fn recursive_define_preset_unification_unchanged() {
    let ok_src = r#"
fn fact(n: i64) -> i64 { if (n == 0) { 1 } else { n * fact(n - 1) } }
fact(10)
"#;
    let r = check(ok_src);
    assert!(
        !r.rendered.iter().any(|l| l.contains("E0005")),
        "recursion define must not false-positive: \n{:?}",
        r.rendered
    );
    // Negative case: arity error inside a recursive body (r80 semantic
    // re-anchor: the krf face does not propagate recursive preset variable
    // heads [fix ④] — conservative false-negative boundary for arity
    // errors; detection capability guarded by the oracle direct-call
    // reference face)
    let bad_src = r#"
fn g(n: i64) -> i64 { if (n == 0) { 0 } else { g(n, n) } }
g(3)
"#;
    oracle_hm_diag(bad_src, "procedure argument count mismatch");
}

/// Corpus zero-diagnostic anchor (r153 / 223-c: the corpus leg switched
/// to the .ktf single face — s-expr-removal-plan §4 Batch D; the anchor
/// value carried over verbatim from the retired .krf leg, including the
/// require io write + print call surface).
#[test]
fn fib_corpus_zero_diagnostics() {
    let src = include_str!("../../../../examples/usage/fib.ktf");
    let r = check_source_recover(src, "fib.ktf")
        .expect("well-formed target corpus not should read short-circuit");
    assert!(
        r.diagnostics.is_empty(),
        "fib corpus zero diagnostics maintained: \n{:?}",
        r.rendered
    );
}

//! .ktf equality-domain family tests — r162 / 233 (the TD-037 closure
//! window: the `==` / `!=` skins re-point to the cross-domain structural
//! terminal name `eq` — `a == b` → `(eq a b)`, `a != b` →
//! `(not (eq a b))`; the numeric `=` call-form kernel base and the
//! ordering family keep their num/str domains; equality-domain-design.md
//! v1.0 D1-D10).
//!
//! **Verification surfaces** (the equality-domain face — principle 31
//! skin/skeleton isomorphism: the skin swap is consumed entirely at the
//! Reader layer on both sides; the value layer gains the structural
//! walk `structural_eq` (D4 — pairs/vectors by recursive value equality,
//! procedural identity preserved, spine iteration); 8 primitives'
//! invariance round 44):
//! (1) **run-face E2E** — the modern `==` across every value domain
//! yields the documented verdicts (bool opener `true == true` ⇒ true —
//! was E0004 pre-r162 / pair structural / nested pair / vector
//! structural / nil / num / str regression / `!=` face / self-identity /
//! const cross-stage consumption);
//! (2) **grammar settlement** — dual-Reader canonical Stx rendering
//! byte-identical for both skins; the as-if-written structural anchor
//! (`1 == 2` parses to the `(eq 1 2)` call form);
//! (3) **cross-stage consumption** — the check face flips clean for
//! cross-domain `==` (eq sig (Any, Any) → Bool — was E0005 pre-r162)
//! while the ordering family keeps the static domain diagnostics;
//! (4) **fail-closed negatives** — parse faces (missing operands ×3) /
//! the r161 const-boundary quartet (assign reject / const-mut /
//! single-binding / block-position — the previous window's repair
//! boundary ≥5 with the cross-stage positive) / eq call arity ×2 /
//! ordering runtime domain ×2 / ordering static domain / capability
//! gate / unbound reference / the mixed-domain silent-false honest
//! boundary ×3 (D3: `1 == "1"` / `true == 1` / `quote(a) == 1` —
//! Python/JS precedent) / content-mismatch verdicts ×3 / distinct
//! closures identity / no numeric tower (Int ≠ Float) ×2 / 7 error
//! classes coverage (E0001 lexical ×7 / E0002 arity ×2 / E0004 domain
//! ×2 / E0005 static ×1 / E0006 capability ×1 / E0022 unbound ×1 —
//! ≥6 classes).
//!
//! Honest-boundary anchors (design D3/D10): mixed-domain `==` is
//! silent `false` (the pre-r162 E0004/E0005 diagnostics retired with
//! the domain unification — one coherent law user-wide); procedural
//! values keep the eq? identity law; Int/Float never unify (no
//! implicit numeric tower).
//!
//! Skin-dictionary basis: 20 §14 (the ==→eq domain re-point — this
//! window); 02 §8 comparison production semantics note v7.30. Window
//! basis: user instruction ① (「eq（等运算符问题，应当使用现代设计理念）」
//! — the TD-037 three-way ruling exercised as option A) +
//! equality-domain-design.md v1.0 D1-D10. Ratio: 8 positive :
//! 24 negative = 1:3 (§9.4.3).

use kerf_driver::bootstrap::reader::read_source_for_bootstrap;
use kerf_driver::{check_source_recover, run_source};
use kerf_reader::reader::read_source;
use kerf_syntax::{Stx, StxDatum, SymbolTable};

// ---------------------------------------------------------------------------
// Value / error helpers
// ---------------------------------------------------------------------------

fn run_value(src: &str, filename: &str) -> String {
    let outcome =
        run_source(src, filename).unwrap_or_else(|e| panic!("{} execution failed:{}", filename, e));
    kerf_vm::render_value(&outcome.value, &outcome.heap)
}

fn run_err_contains(src: &str, needle: &str) {
    let err = run_source(src, "eqdom-neg.ktf")
        .err()
        .unwrap_or_else(|| panic!("expected an error, got Ok:{}", src));
    assert!(
        err.rendered.contains(needle),
        "expected `{}` in error, got:\n{}",
        needle,
        err.rendered
    );
}

fn read_err_message(src: &str) -> String {
    let mut table = SymbolTable::new();
    read_source(src, 0, &mut table)
        .err()
        .unwrap_or_else(|| panic!("expected a read error, parsed successfully:{}", src))
        .message
}

fn check_clean(src: &str) {
    let report = check_source_recover(src, "eqdom-check.ktf")
        .unwrap_or_else(|e| panic!("check compile failed:{}", e));
    assert!(
        report.diagnostics.is_empty(),
        "expected clean check, got:{}",
        report.rendered.join("\n")
    );
}

fn check_diag_contains(src: &str, needle: &str) {
    let report = check_source_recover(src, "eqdom-check.ktf")
        .unwrap_or_else(|e| panic!("check compile failed:{}", e));
    assert!(
        report
            .diagnostics
            .iter()
            .any(|d| d.message.contains(needle)),
        "expected diagnostic `{}`, got:{}",
        needle,
        report.rendered.join("\n")
    );
}

// ---------------------------------------------------------------------------
// Dual-Reader parity + as-if-written structure helpers
// ---------------------------------------------------------------------------

fn render_stx(s: &Stx, t: &SymbolTable) -> String {
    let mut out = String::new();
    render_stx_into(s, t, &mut out);
    out
}

fn render_stx_into(s: &Stx, t: &SymbolTable, out: &mut String) {
    match &s.datum {
        StxDatum::Symbol(sym) => {
            out.push_str(&format!(
                "(sym {} {}..{})",
                t.name(*sym),
                s.span.start,
                s.span.end
            ));
        }
        StxDatum::Literal(l) => match l {
            kerf_syntax::StxLiteral::Int(v) => {
                out.push_str(&format!("(int {} {}..{})", v, s.span.start, s.span.end))
            }
            kerf_syntax::StxLiteral::Float(f) => {
                out.push_str(&format!("(float {:?} {}..{})", f, s.span.start, s.span.end))
            }
            kerf_syntax::StxLiteral::Str(r) => {
                out.push_str(&format!("(str {:?} {}..{})", r, s.span.start, s.span.end))
            }
            kerf_syntax::StxLiteral::Bool(b) => {
                out.push_str(&format!("(bool {} {}..{})", b, s.span.start, s.span.end))
            }
            kerf_syntax::StxLiteral::Nil => {
                out.push_str(&format!("(nil {}..{})", s.span.start, s.span.end))
            }
        },
        StxDatum::List(items) => {
            out.push_str("(lst");
            for it in items.iter() {
                out.push(' ');
                render_stx_into(it, t, out);
            }
            out.push_str(&format!(" {}..{})", s.span.start, s.span.end));
        }
        StxDatum::Vector(items) => {
            out.push_str("(vec");
            for it in items.iter() {
                out.push(' ');
                render_stx_into(it, t, out);
            }
            out.push_str(&format!(" {}..{})", s.span.start, s.span.end));
        }
    }
}

fn assert_grammar_parity(src: &str, what: &str) {
    let mut t1 = SymbolTable::new();
    let seed = read_source(src, 0, &mut t1)
        .unwrap_or_else(|e| panic!("[{}] seed syntax failed:{}", what, e.message));
    let mut t2 = SymbolTable::new();
    let mirror = read_source_for_bootstrap(src, 0, &mut t2)
        .unwrap_or_else(|e| panic!("[{}] mirror syntax failed:{}", what, e.message));
    assert_eq!(seed.len(), mirror.len(), "[{}] item count mismatch", what);
    for (s, m) in seed.iter().zip(mirror.iter()) {
        assert_eq!(
            render_stx(s, &t1),
            render_stx(m, &t2),
            "[{}] canonical rendering diverged",
            what
        );
    }
}

/// The as-if-written structural anchor: the skins parse to exactly the
/// call form of the terminal name (`1 == 2` → `(eq 1 2)` with head
/// symbol and binary arity) — principle 31 skin/skeleton isomorphism at
/// the Stx datum level; the wrapper walk tolerates unary intermediate
/// levels (`!=` → `(not (eq 1 2))`).
fn assert_as_if_written(src: &str, head_path: &[&str], what: &str) {
    let mut t = SymbolTable::new();
    let items = read_source(src, 0, &mut t)
        .unwrap_or_else(|e| panic!("[{}] syntax failed:{}", what, e.message));
    assert_eq!(items.len(), 1, "[{}] expected one top-level item", what);
    let mut node = &items[0];
    for (i, name) in head_path.iter().enumerate() {
        let last = i + 1 == head_path.len();
        match &node.datum {
            StxDatum::List(items) => {
                // intermediate levels are unary wrappers; the terminal
                // comparison level is the binary call form
                let expected_len = if last { 3 } else { 2 };
                assert_eq!(
                    items.len(),
                    expected_len,
                    "[{}] call-form arity mismatch",
                    what
                );
                match &items[0].datum {
                    StxDatum::Symbol(sym) => {
                        assert_eq!(t.name(*sym), *name, "[{}] head symbol mismatch", what);
                    }
                    other => panic!("[{}] head is not a symbol: {:?}", what, other),
                }
                node = &items[1];
            }
            other => panic!("[{}] expected a list, got {:?}", what, other),
        }
    }
}

// ---------------------------------------------------------------------------
// Positive semantics (8) — the modern == across every value domain
// ---------------------------------------------------------------------------

/// The TD-037 opener: `true == true` ⇒ true (E0004 pre-r162) + the
/// bool-domain verdict pair + the check-face flip (statically clean —
/// E0005 pre-r162; integration: run + check dual paths).
#[test]
fn pos_bool_domain_opener() {
    assert_eq!(run_value("true == true", "eq-p1.ktf"), "true");
    assert_eq!(run_value("false == true", "eq-p1.ktf"), "false");
    check_clean("true == true");
    check_clean("false == true");
}

/// Pair structural equality (the D5 law): twice-constructed isomorphic
/// pairs are equal — was `false` (reference law) pre-r162.
#[test]
fn pos_pair_structural_equality() {
    assert_eq!(run_value("(1, 2) == (1, 2)", "eq-p2.ktf"), "true");
    assert_eq!(run_value("cons(1, 2) == (1, 2)", "eq-p2.ktf"), "true");
}

/// Nested pairs recurse structurally (branch positions).
#[test]
fn pos_nested_pair_structural() {
    assert_eq!(run_value("(1, (2, 3)) == (1, (2, 3))", "eq-p3.ktf"), "true");
}

/// Immediate-domain regression anchors: nil / num / str (the pre-r162
/// `==` domains — behavior parity preserved through the re-point).
#[test]
fn pos_immediate_domains_regression() {
    assert_eq!(run_value("() == ()", "eq-p4.ktf"), "true");
    assert_eq!(run_value("2 == 2", "eq-p4.ktf"), "true");
    assert_eq!(run_value("2 == 3", "eq-p4.ktf"), "false");
    assert_eq!(run_value("\"a\" == \"a\"", "eq-p4.ktf"), "true");
    assert_eq!(run_value("\"a\" == \"b\"", "eq-p4.ktf"), "false");
}

/// The `!=` skin: `(not (eq a b))` — true on mismatch, false on match,
/// pair-domain verdicts included.
#[test]
fn pos_neq_skin_face() {
    assert_eq!(run_value("1 != 2", "eq-p5.ktf"), "true");
    assert_eq!(run_value("1 != 1", "eq-p5.ktf"), "false");
    assert_eq!(run_value("(1, 2) != (3, 4)", "eq-p5.ktf"), "true");
    assert_eq!(run_value("(1, 2) != (1, 2)", "eq-p5.ktf"), "false");
}

/// Self-identity preserved: a binding equals itself (the identity
/// substrate under the structural law).
#[test]
fn pos_self_identity_preserved() {
    assert_eq!(run_value("let p = (1, 2);\np == p", "eq-p6.ktf"), "true");
}

/// Vector structural equality (the D5 law via the infix skin — was
/// reference identity pre-r162) — `[]` literal face and the vector()
/// call face agree.
#[test]
fn pos_vector_structural_equality() {
    assert_eq!(run_value("[1, 2] == [1, 2]", "eq-p7.ktf"), "true");
    assert_eq!(run_value("vector(1, 2) == [1, 2]", "eq-p7.ktf"), "true");
}

/// Cross-stage consumption (the r161 const interplay): a const
/// initializer consumes the `==` face — the binding carries the verdict
/// (previous window's repair boundary, positive leg).
#[test]
fn pos_const_cross_stage_consumption() {
    assert_eq!(run_value("const FLAG = 1 == 1;\nFLAG", "eq-p8.ktf"), "true");
    assert_eq!(
        run_value("const SAME = \"x\" == \"x\";\nSAME", "eq-p8.ktf"),
        "true"
    );
}

// ---------------------------------------------------------------------------
// Negative: read-stage parse faces (E0001 ×3)
// ---------------------------------------------------------------------------

/// `==` with a missing right operand — the expression parser
/// fail-closes at the operator boundary.
#[test]
fn neg_parse_eq_missing_rhs() {
    let msg = read_err_message("let x = 1 == ;");
    assert!(
        msg.contains("expected an expression"),
        "expected an expression diagnostic, got:{}",
        msg
    );
}

/// `==` with a missing left operand — a statement may not begin with
/// the equality operator.
#[test]
fn neg_parse_eq_missing_lhs() {
    let msg = read_err_message("== 1;");
    assert!(
        msg.contains("expected an expression") || msg.contains("expected"),
        "expected an expression diagnostic, got:{}",
        msg
    );
}

/// `!=` with a missing right operand — same fail-closed family.
#[test]
fn neg_parse_neq_missing_rhs() {
    let msg = read_err_message("let y = 2 != ;");
    assert!(
        msg.contains("expected an expression"),
        "expected an expression diagnostic, got:{}",
        msg
    );
}

// ---------------------------------------------------------------------------
// Negative: the r161 const-boundary quartet (previous window's repair
// boundary — ≥5 with the cross-stage positive above)
// ---------------------------------------------------------------------------

/// Item-position assign rejection through the `==` era (E0001 read
/// face — the read-only binding law is unaffected by the equality
/// window).
#[test]
fn neg_r161_assign_reject() {
    run_err_contains("const X = 1;\nX = 2;", "cannot assign to a const binding");
}

/// const-mut contradiction (E0001 read face).
#[test]
fn neg_r161_const_mut_contradiction() {
    run_err_contains("const mut z = 1;", "const mut is contradictory");
}

/// Single-binding cap (E0001 read face).
#[test]
fn neg_r161_single_binding_cap() {
    run_err_contains(
        "const a = 1, b = 2;",
        "top-level const takes a single binding",
    );
}

/// Block-position domain-out (E0001 read face — the fn-body boundary).
#[test]
fn neg_r161_block_position_domain_out() {
    run_err_contains(
        "fn f() { const y = 1; }",
        "const declaration(item position only",
    );
}

// ---------------------------------------------------------------------------
// Negative: eq call-form arity (E0002 ×2)
// ---------------------------------------------------------------------------

/// `eq` with one argument — the two-argument contract fail-closes at
/// run time.
#[test]
fn neg_eq_call_arity_low() {
    run_err_contains("eq(1)", "requires");
}

/// `eq` with three arguments — the exactly-two contract (the r42 R3
/// final state).
#[test]
fn neg_eq_call_arity_high() {
    run_err_contains("eq(1, 2, 3)", "requires");
}

// ---------------------------------------------------------------------------
// Negative: the ordering family domain (E0004 ×2 — same-path audit:
// `< > <= >=` keep the num/str domains, TD-011 r24 law untouched)
// ---------------------------------------------------------------------------

/// `true < false` — the ordering family rejects bools (the equality
/// unification did NOT leak into ordering).
#[test]
fn neg_ordering_lt_domain() {
    run_err_contains("true < false", "< requires a number");
}

/// `"a" <= 1` — mixed str/int ordering stays rejected.
#[test]
fn neg_ordering_le_domain() {
    run_err_contains("\"a\" <= 1", "<= requires a number");
}

// ---------------------------------------------------------------------------
// Negative: check-face static domains (E0005 — the ordering family
// keeps the static diagnostics; the `==` rows retired by design)
// ---------------------------------------------------------------------------

/// Static ordering domain (E0005) — the checker still blames non-numeric
/// ordering operands (integration: the check path).
#[test]
fn neg_check_ordering_static_domain() {
    check_diag_contains("true < false", "requires a number");
    check_diag_contains("\"a\" >= 1", "requires a number");
}

// ---------------------------------------------------------------------------
// Negative: capability gate + unbound reference (E0006 / E0022)
// ---------------------------------------------------------------------------

/// The `==` program with print but no require — the capability gate is
/// unaffected by the equality window (E0006).
#[test]
fn neg_capability_gate() {
    run_err_contains("print(1 == 1);", "insufficient capability permission");
}

/// An unbound operand of `==` — the name resolution face (E0022).
#[test]
fn neg_unbound_reference() {
    run_err_contains("X == 1", "unbound reference: `X`");
}

// ---------------------------------------------------------------------------
// Negative: the mixed-domain silent-false honest boundary (D3 ×3 —
// the pre-r162 E0004 diagnostics retired with the domain unification)
// ---------------------------------------------------------------------------

/// `1 == "1"` ⇒ false (was E0004 pre-r162) — the Python/JS-precedent
/// ruling: cross-domain comparison is a verdict, not an error.
#[test]
fn neg_mixed_int_str_silent_false() {
    assert_eq!(run_value("1 == \"1\"", "eq-m1.ktf"), "false");
}

/// `true == 1` ⇒ false (was E0004 pre-r162).
#[test]
fn neg_mixed_bool_int_silent_false() {
    assert_eq!(run_value("true == 1", "eq-m2.ktf"), "false");
}

/// `quote(a) == 1` ⇒ false (was E0004 pre-r162) — symbols participate
/// in the structural law as immediates.
#[test]
fn neg_mixed_symbol_int_silent_false() {
    assert_eq!(run_value("quote(a) == 1", "eq-m3.ktf"), "false");
}

// ---------------------------------------------------------------------------
// Negative: content-mismatch verdicts (the structural law's false side)
// ---------------------------------------------------------------------------

/// Isomorphic shape, different leaf — the structural walk blames the
/// mismatching component (deep verdict, not shape-only).
#[test]
fn neg_pair_content_mismatch() {
    assert_eq!(run_value("(1, 2) == (1, 3)", "eq-c1.ktf"), "false");
}

/// Nested mismatch — recursion into branch positions.
#[test]
fn neg_nested_pair_mismatch() {
    assert_eq!(
        run_value("(1, (2, 3)) == (1, (2, 4))", "eq-c2.ktf"),
        "false"
    );
}

/// Vector element order matters — `[1, 2]` vs `[2, 1]` (structural,
/// not multiset).
#[test]
fn neg_vector_content_mismatch() {
    assert_eq!(run_value("[1, 2] == [2, 1]", "eq-c3.ktf"), "false");
}

// ---------------------------------------------------------------------------
// Negative: procedural identity + numeric tower (the eq? law survivors)
// ---------------------------------------------------------------------------

/// Two closures from the same factory are NOT equal — the procedural
/// identity law survives the structural unification (D3: closures
/// compare by reference, never by structure).
#[test]
fn neg_distinct_closures_identity() {
    assert_eq!(
        run_value(
            "fn mk() { || { 1 } }\nlet a = mk();\nlet b = mk();\na == b",
            "eq-i1.ktf"
        ),
        "false"
    );
    assert_eq!(
        run_value("fn mk() { || { 1 } }\nlet a = mk();\na == a", "eq-i1.ktf"),
        "true"
    );
}

/// No implicit numeric tower: `1 == 1.0` ⇒ false (Int ≠ Float — the
/// type-level separation survives at the value layer; assert-eq
/// inherits the same law as a run error — the one-law-user-wide D4
/// consumer set, both faces in one guard).
#[test]
fn neg_no_numeric_tower() {
    assert_eq!(run_value("1 == 1.0", "eq-t1.ktf"), "false");
    run_err_contains("assert_eq(1, 1.0)", "assert-eq assertion failed");
}

// ---------------------------------------------------------------------------
// Negative: grammar settlement guards (fail-on-divergence)
// ---------------------------------------------------------------------------

/// Dual-Reader canonical rendering parity for both skins — the seed
/// reader and the mirror produce byte-identical Stx (spans included)
/// for `==` and `!=` forms (integration: the dual-reader path).
#[test]
fn neg_grammar_parity_dual_reader() {
    assert_grammar_parity("1 == 2", "eq-skin");
    assert_grammar_parity("1 != 2", "neq-skin");
    assert_grammar_parity("\"a\" == \"b\"", "str-skin");
    assert_grammar_parity("(1, 2) == (1, 3)", "pair-skin");
}

/// The as-if-written structural anchor: the skins parse to exactly the
/// call forms of the terminal names — `1 == 2` → `(eq 1 2)` and
/// `1 != 2` → `(not (eq 1 2))` (principle 31 skin/skeleton
/// isomorphism at the datum level — the pre-r162 target was `(= 1 2)`).
#[test]
fn neg_as_if_written_call_form() {
    assert_as_if_written("1 == 2;", &["eq"], "eq-as-if-written");
    assert_as_if_written("1 != 2;", &["not", "eq"], "neq-as-if-written");
}

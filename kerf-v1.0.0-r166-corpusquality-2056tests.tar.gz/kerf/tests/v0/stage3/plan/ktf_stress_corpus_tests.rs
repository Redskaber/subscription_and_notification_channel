//! .ktf stress-corpus family tests — r128 / 198-b (the stress-variant
//! batch of the corpus-family deepening window).
//!
//! **Verification surfaces** (the three stress corpus files placed at
//! `examples/usage/*.ktf` — effect_stress / gc_stress / gc_stress_nontail,
//! the target faces of their .krf counterparts):
//! (1) **run-face E2E** — each stress corpus through `run_source`
//! yields the same program value as its S-expr face counterpart
//! (principle 31 skin/skeleton isomorphism — 120 / 5 / 5, consumed via
//! `include_str!` so any corpus edit that breaks the chain fails here);
//! (2) **the r128 grammar settlement** — the handler-body block resume
//! statement (`{ mk(50000); resume(v) }` = the S-expr `(do A (resume k
//! v))` sequence form) is verified dual-Reader: seed vs mirror canonical
//! Stx rendering byte-identical, error faces message + Span byte-identical,
//! and the statement-position semantics (dead code after a one-shot
//! resume) value-anchored; (3) **cross-stage consumption** — the stress
//! family through `check_source_recover` stays diagnostic-clean
//! with real instruction artifacts; (4) **fail-closed negatives** —
//! corpus-shaped rejections across the error classes (the new form's
//! position/termination discipline + the established families: lexical /
//! grammar / position / domain-out / capability / unbound / E0025 /
//! HM / runtime / recovery).
//!
//! Skin-dictionary basis: 20 §14 v1.20 (the handler-body block resume
//! statement — the D2 handle mapping's body-domain extension); 02
//! §8.13.1a v7.13 (the Level 0 production). Corpus placement basis:
//! switch-window-plan v1.10 next-batch recommendation (stress variants
//! first) + t3plus-trigger-audit v1.47 r127 note (the r127 honest
//! boundary: effect_stress = the follow-up natural signal). Ratio:
//! 8 positive : 24 negative = 1:3 (§9.4.3).

use kerf_driver::bootstrap::reader::read_source_for_bootstrap;
use kerf_driver::{check_source_recover, run_source};
use kerf_reader::reader::read_source;
use kerf_syntax::{Stx, StxDatum, StxLiteral, SymbolTable};

// ---------------------------------------------------------------------------
// Corpus family (the artifacts under test — include_str! makes every file
// a tested artifact: the corpus-integrity gate)
// ---------------------------------------------------------------------------

const CORPUS_EFFECT_STRESS: &str = include_str!("../../../../examples/usage/effect_stress.ktf");
const CORPUS_GC_STRESS: &str = include_str!("../../../../examples/usage/gc_stress.ktf");
const CORPUS_GC_STRESS_NONTAIL: &str =
    include_str!("../../../../examples/usage/gc_stress_nontail.ktf");

fn corpus_value(src: &str, filename: &str) -> String {
    let outcome = run_source(src, filename)
        .unwrap_or_else(|e| panic!("corpus {} execution failed:{}", filename, e));
    kerf_vm::render_value(&outcome.value, &outcome.heap)
}

// ---------------------------------------------------------------------------
// Dual-Reader parity helpers (the match_m4_krf_mirror_tests.rs caliber —
// canonical rendering with Span bytes; error parity with message + Span
// byte equality)
// ---------------------------------------------------------------------------

fn render_stx(s: &Stx, t: &SymbolTable) -> String {
    let mut out = String::new();
    render_stx_into(s, t, &mut out);
    out
}

fn render_stx_into(s: &Stx, t: &SymbolTable, out: &mut String) {
    match &s.datum {
        StxDatum::Symbol(sym) => {
            out.push_str(&format!(
                "(sym {} {}..{})",
                t.name(*sym),
                s.span.start,
                s.span.end
            ));
        }
        StxDatum::Literal(l) => match l {
            StxLiteral::Int(v) => {
                out.push_str(&format!("(int {} {}..{})", v, s.span.start, s.span.end));
            }
            StxLiteral::Float(f) => {
                out.push_str(&format!("(float {:?} {}..{})", f, s.span.start, s.span.end));
            }
            StxLiteral::Str(r) => {
                out.push_str(&format!("(str {:?} {}..{})", r, s.span.start, s.span.end));
            }
            StxLiteral::Bool(b) => {
                out.push_str(&format!("(bool {} {}..{})", b, s.span.start, s.span.end));
            }
            StxLiteral::Nil => {
                out.push_str(&format!("(nil {}..{})", s.span.start, s.span.end));
            }
        },
        StxDatum::List(items) => {
            out.push_str(&format!("(lst {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
        // r138 / 208-c — TD-002: vectors now reach both Readers (the
        // fourteenth skin mapping) — full canonical rendering
        StxDatum::Vector(items) => {
            out.push_str(&format!("(vec {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
    }
}

/// Grammar parity assertion: both Readers' canonical renderings are
/// byte-identical (the r128 grammar settlement's core gate — the handler
/// block resume form is seed/mirror isomorphic by construction).
fn assert_grammar_parity(src: &str, what: &str) {
    let mut t1 = SymbolTable::new();
    let seed = read_source(src, 0, &mut t1)
        .unwrap_or_else(|e| panic!("[{}] seed syntax failed: {}", what, e.message));
    let mut t2 = SymbolTable::new();
    let mirror = read_source_for_bootstrap(src, 0, &mut t2)
        .unwrap_or_else(|e| panic!("[{}] mirror syntax failed:{}", what, e.message));
    assert_eq!(
        seed.len(),
        mirror.len(),
        "[{}] top-level item count mismatch (seed {} vs mirror {})",
        what,
        seed.len(),
        mirror.len()
    );
    for (i, (a, b)) in seed.iter().zip(mirror.iter()).enumerate() {
        assert_eq!(
            render_stx(a, &t1),
            render_stx(b, &t2),
            "[{}] top-level item #{} syntax tree mismatch (seed vs mirror canonical render)",
            what,
            i
        );
    }
}

/// Grammar-error parity assertion: message + Span byte-level equality
/// (the mirror's diagnostic face is the seed's, by construction).
fn assert_grammar_err_parity(src: &str, what: &str) {
    let mut t1 = SymbolTable::new();
    let seed_err = match read_source(src, 0, &mut t1) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] seed should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    let mut t2 = SymbolTable::new();
    let mirror_err = match read_source_for_bootstrap(src, 0, &mut t2) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] mirror should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    assert_eq!(
        seed_err.message, mirror_err.message,
        "[{}] syntax error message mismatch (seed {:?} vs mirror {:?})",
        what, seed_err.message, mirror_err.message
    );
    assert_eq!(
        seed_err.span.start, mirror_err.span.start,
        "[{}] syntax error Span start mismatch (seed {} vs mirror {})",
        what, seed_err.span.start, mirror_err.span.start
    );
    assert_eq!(
        seed_err.span.end, mirror_err.span.end,
        "[{}] syntax error Span end mismatch (seed {} vs mirror {})",
        what, seed_err.span.end, mirror_err.span.end
    );
}

// ---------------------------------------------------------------------------
// Positives — run-face E2E + grammar settlement + cross-stage consumption
// ---------------------------------------------------------------------------

/// Positive 1 / integration: effect_stress.ktf (the r128 grammar
/// settlement's carrier — the handler-body block resume statement:
/// allocate 50000 pairs inside the handler body before the one-shot
/// resume, the S-expr face's `(do (mk 50000) (resume k v))` sequence
/// form) through the production run chain — the program value matches
/// the S-expr face counterpart (effect_stress.krf ⇒ 120).
#[test]
fn corpus_effect_stress_run_e2e() {
    assert_eq!(
        corpus_value(CORPUS_EFFECT_STRESS, "effect_stress.ktf"),
        "120",
        "effect GC push power program value(handler block body resume statement form)"
    );
}

/// Positive 2 / integration: gc_stress.ktf (10^6-scale temporary-object
/// allocation with a live list surviving the GC rounds — the target face
/// builds keep via the `list` builtin call: no quoted-list literal, the
/// r127 registered honest boundary) through the production run chain —
/// the program value matches the S-expr face counterpart (gc_stress.krf
/// ⇒ 5: live data intact across GC).
#[test]
fn corpus_gc_stress_run_e2e() {
    assert_eq!(
        corpus_value(CORPUS_GC_STRESS, "gc_stress.ktf"),
        "5",
        "GC push power program value(alive data cross GC round complete)"
    );
}

/// Positive 3 / integration: gc_stress_nontail.ktf (the TD-023 benchmark
/// re-shaping: the recursive call in the `+ 1` operand position = non-tail
/// → ~3×10^4 live frames while GC cycles fire — the root-set enumeration
/// load) through the production run chain — the program value matches
/// the S-expr face counterpart (gc_stress_nontail.krf ⇒ 5).
#[test]
fn corpus_gc_stress_nontail_run_e2e() {
    assert_eq!(
        corpus_value(CORPUS_GC_STRESS_NONTAIL, "gc_stress_nontail.ktf"),
        "5",
        "non-tail form GC push power program value(deep frame root set enumerated cite negative load)"
    );
}

/// Positive 4 / integration / corpus single-face baseline anchor
/// (r153 / 223-c: the .krf corpus face retired — s-expr-removal-plan §4
/// Batch D "语料 .krf 面清理"): the three stress corpus files through the
/// sole production run chain (`.ktf` face) with the value baselines
/// formerly asserted cross-face (the cross-grammar equivalence evidence
/// is archived in RELEASE r127-r152; the inline cross-grammar discipline
/// lives on in cli_entry_convergence_tests).
#[test]
fn corpus_stress_single_face_baseline_anchor() {
    let cases = [
        ("effect_stress", CORPUS_EFFECT_STRESS, "120"),
        ("gc_stress", CORPUS_GC_STRESS, "5"),
        ("gc_stress_nontail", CORPUS_GC_STRESS_NONTAIL, "5"),
    ];
    for (name, ktf, baseline) in cases {
        let v = corpus_value(ktf, &format!("{}.ktf", name));
        assert_eq!(
            v, baseline,
            "{} single-face program value baseline mismatch(expected {} actual {})",
            name, baseline, v
        );
    }
}

/// Positive 5 / integration / dual-Reader grammar parity: the whole
/// stress corpus family + the focused new-form snippets through both
/// Readers (seed target.rs vs mirror reader.krf) — canonical Stx
/// rendering byte-identical (the r128 grammar settlement's core gate:
/// the handler block resume form is isomorphic on both sides by
/// construction; the mirror is the production chain's actual parser).
#[test]
fn handler_block_resume_dual_reader_parity() {
    // The corpus artifacts themselves (the strongest form: the real
    // artifacts parse identically on both Readers).
    assert_grammar_parity(CORPUS_EFFECT_STRESS, "effect_stress.ktf all items");
    assert_grammar_parity(CORPUS_GC_STRESS, "gc_stress.ktf all items");
    assert_grammar_parity(CORPUS_GC_STRESS_NONTAIL, "gc_stress_nontail.ktf all items");
    // Focused forms: tail-position resume, statement-position resume
    // (dead code after), let-threaded resume tail, resume-only block.
    assert_grammar_parity(
        "fn g() { handle (100 + ask()) { gift(p, k) => { mk(5); resume(tail(p) + head(p)) } } }",
        "tail position resume statement sequence",
    );
    assert_grammar_parity(
        "fn g() { handle (1) { gift(p, k) => { resume(20); 999 } } }",
        "statement position resume + dead code",
    );
    assert_grammar_parity(
        "fn g() { handle (1) { gift(p, k) => { let t = 5; resume(t + 1) } } }",
        "let threading + tail position resume",
    );
    assert_grammar_parity(
        "fn g() { handle (1) { gift(p, k) => { resume(7) } } }",
        "pure resume block(equivalent direct positional form)",
    );
}

/// Positive 6 / integration / dual-Reader error parity: the new form's
/// discipline faces — message + Span byte-identical on both Readers
/// (the mirror's diagnostic face is the seed's).
#[test]
fn handler_block_resume_err_parity() {
    assert_grammar_err_parity(
        "fn f() { resume(1); }\nf()",
        "plain pass fn inside a block resume(no handler scope)",
    );
    assert_grammar_err_parity("resume(1);", "top level resume(no handler scope)");
    // r133 / 203-c5 (nested-resume-design.md D1): the r128-registered
    // domain-out boundary (nested-block resume) is CLEARED by the
    // nested-resume window — the anchor flips from error parity to
    // positive grammar parity (canonical rendering equal on both Readers;
    // the seed-first flip goes green with the mirror's kcell threading,
    // 203-c3 — the r131 use-domain-out anchor-retirement precedent).
    assert_grammar_parity(
        "fn g() { handle (1) { gift(p, k) => { if (1 == 1) { resume(20); } } } }",
        "inside nested block resume(r133 window inner clearing -- positive parity)",
    );
    assert_grammar_err_parity(
        "fn g() { handle (1) { gift(p, k) => { resume(5) 6 } } }",
        "resume form followed by missing; or }(terminating discipline)",
    );
    assert_grammar_err_parity(
        "fn g() { handle (1) { gift(p, k) => mk(5); resume(2) } }",
        "direct position statement sequence(out of domain -- must block body carries)",
    );
}

/// Positive 7 / integration / cross-stage consumption: the stress family
/// through the check face (`check_source_recover`) —
/// diagnostic-clean with real instruction artifacts. The run face and
/// the check face consume the same corpus (one corpus, two pipeline
/// stages).
#[test]
fn corpus_stress_family_check_clean_cross_stage() {
    let family = [
        ("effect_stress.ktf", CORPUS_EFFECT_STRESS),
        ("gc_stress.ktf", CORPUS_GC_STRESS),
        ("gc_stress_nontail.ktf", CORPUS_GC_STRESS_NONTAIL),
    ];
    for (name, src) in family {
        let report = check_source_recover(src, name)
            .unwrap_or_else(|e| panic!("corpus {} check failed:{}", name, e));
        assert!(
            report.diagnostics.is_empty(),
            "corpus {} must have zero diagnostics (actual: {:?})",
            name,
            report.rendered
        );
        assert!(
            report.instruction_count > 0,
            "corpus {} check artifact instruction count > 0(actual {})",
            name,
            report.instruction_count
        );
    }
}

/// Positive 8 / integration / statement-position semantics: the
/// one-shot resume jumps away — the statements after a
/// statement-position `resume(v);` are dead code, the handler result =
/// the suspension point continuing with v (the S-expr face's
/// `(do (resume k v) dead)` shape, value-anchored on the target face).
#[test]
fn handler_block_resume_statement_position_semantics() {
    let src = "fn ask() { perform gift(0, 20); }\nfn g() { handle (100 + ask()) { gift(p, k) => { resume(20); 999 } } }\ng()";
    assert_eq!(
        corpus_value(src, "stmt_resume.ktf"),
        "120",
        "statement position resume once property jump separate -- subsequent statement dead code, program value = recovery dot continue value"
    );
}

// ---------------------------------------------------------------------------
// Negatives — corpus-shaped fail-closed rejections (§9.4.3 ratio 1:3
// carrier: 24 negatives across the error classes)
// ---------------------------------------------------------------------------

/// Negative 1 (read — the new form's scope discipline): `resume` in a
/// plain fn block (no handler scope) — fail-closed at the read stage.
#[test]
fn neg_resume_in_plain_fn_block_fail() {
    let err = run_source("fn f() { resume(1); }\nf()", "bad.ktf")
        .expect_err("plain pass inside a block resume must read error(handler scope outer)");
    assert!(
        err.to_string().contains("KwResume") || err.to_string().contains("expected an expression"),
        "diagnostic must name KwResume/expected an expression (actual: {})",
        err
    );
}

/// Negative 2 (read — scope discipline): `resume` at top level.
#[test]
fn neg_resume_at_top_level_fail() {
    assert!(
        run_source("resume(1);", "bad.ktf").is_err(),
        "top level resume must read error(no handler scope)"
    );
}

/// Positive 3 (read — r133 / 203-c5, nested-resume-design.md D1): the
/// r128-registered nested-block boundary is CLEARED — `resume` inside a
/// nested if-arm block within the handler body parses on the target face
/// (anchor flipped from the negative face — the r131 use-anchor-retirement
/// precedent; the full-strength dual-Reader parity + bytecode gates live
/// in ktf_nested_resume_tests).
#[test]
fn pos_resume_in_nested_if_arm() {
    let _ = run_source(
        "fn g() { handle (1) { gift(p, k) => { if (1 == 1) { resume(20); } } } }",
        "ok.ktf",
    )
    .expect(
        "nested if arm inside a block resume = r133 cleared in-window (must parse successfully)",
    );
}

/// Positive 4 (read — r133 / 203-c5, nested-resume-design.md D1/D4): the
/// nested-closure boundary is CLEARED — `resume` inside a `||` closure
/// body within the handler body block parses (the k-capture idiom — the
/// S-expr face's lexical capture mirrored).
#[test]
fn pos_resume_in_nested_closure() {
    let _ = run_source(
        "fn g() { handle (1) { gift(p, k) => { let f = || { resume(20); }; 1 } } }",
        "ok.ktf",
    )
    .expect("nested closure in body resume = r133 cleared in-window (must parse successfully)");
}

/// Negative 5 (read — call-form discipline): `resume` without the
/// mandatory parenthesized argument in a handler block.
#[test]
fn neg_resume_without_parens_fail() {
    assert!(
        run_source(
            "fn g() { handle (1) { gift(p, k) => { resume 5; } } }",
            "bad.ktf"
        )
        .is_err(),
        "resume no parentheses actual argument form must read error"
    );
}

/// Negative 6 (read — termination discipline): an unclosed resume call
/// in a handler block.
#[test]
fn neg_resume_unclosed_paren_fail() {
    assert!(
        run_source(
            "fn g() { handle (1) { gift(p, k) => { resume(5; } } }",
            "bad.ktf"
        )
        .is_err(),
        "resume unclosed parentheses must read error"
    );
}

/// Negative 7 (read — arity discipline): a two-argument resume call in a
/// handler block (the k binder is injected, never written).
#[test]
fn neg_resume_two_args_fail() {
    assert!(
        run_source(
            "fn g() { handle (1) { gift(p, k) => { resume(1, 2) } } }",
            "bad.ktf"
        )
        .is_err(),
        "resume(1, 2) dual actual argument form must read error(k by arm binding injection)"
    );
}

/// Negative 8 (read — direct-body position discipline): a statement
/// sequence at the direct handler-body position (without the block
/// braces) — the registered out-of-domain form.
#[test]
fn neg_direct_body_statement_sequence_fail() {
    let err = run_source(
        "fn g() { handle (1) { gift(p, k) => mk(5); resume(2) } }",
        "bad.ktf",
    )
    .expect_err("direct position statement sequence = out of domain(must block body carries)");
    assert!(
        err.to_string().contains("out of domain") || err.to_string().contains("handler body"),
        "diagnostic must name out of domain/handler body(actual: {})",
        err
    );
}

/// Negative 9 (read — protected-expression position): `resume` in the
/// protected expression position of a handle.
#[test]
fn neg_resume_in_protected_expr_fail() {
    assert!(
        run_source(
            "fn g() { handle (resume(1)) { gift(p, k) => resume(2) } }",
            "bad.ktf"
        )
        .is_err(),
        "protect expression position resume must read error"
    );
}

/// Negative 10 (read — empty argument): `resume()` with no value.
#[test]
fn neg_resume_empty_arg_fail() {
    assert!(
        run_source(
            "fn g() { handle (1) { gift(p, k) => { resume() } } }",
            "bad.ktf"
        )
        .is_err(),
        "resume() empty actual argument must read error"
    );
}

/// Negative 11 (lexical): unclosed string literal in a stress-shaped
/// source.
#[test]
fn neg_unclosed_string_lexical_fail() {
    assert!(
        run_source("fn mk(n: i64) { \"abc }", "bad.ktf").is_err(),
        "unclosed string must be a lexical error"
    );
}

/// Negative 12 (grammar): unclosed brace in a stress-shaped fn body.
#[test]
fn neg_unclosed_brace_grammar_fail() {
    assert!(
        run_source("fn spin(n: i64) { spin(n - 1)", "bad.ktf").is_err(),
        "unclosed brace must be a grammar error"
    );
}

/// Negative 13 (read — type discipline): a fn parameter without the
/// mandatory `: type` annotation (stress-shaped).
#[test]
fn neg_fn_param_missing_type_read_fail() {
    let err = run_source("fn spin(n) { spin(n) }", "bad.ktf")
        .expect_err("target face parameter type annotations grammatically required");
    assert!(
        err.to_string().contains("expected :"),
        "diagnostic must name the missing `:`(actual: {})",
        err
    );
}

/// Negative 14 (capability — E0006): `print` without the require
/// declaration in a stress-shaped source.
#[test]
fn neg_print_without_require_capability_fail() {
    let err = run_source("fn spin(n: i64) { print(n); }\nspin(1)", "bad.ktf")
        .expect_err("no require declared I/O call = compile-time E0006 capability gating");
    assert!(
        err.to_string().contains("E0006"),
        "diagnostic must be E0006 capability permission (actual: {})",
        err
    );
}

/// Negative 15 (compile — E0022 short-circuit): an unbound reference in
/// a stress-shaped source.
#[test]
fn neg_unbound_reference_compile_shortcircuit() {
    let err = check_source_recover(
        "fn spin(n: i64) { if (n == 0) { 0 } else { spinx(n - 1) } }\nspin(3)",
        "bad.ktf",
    )
    .expect_err("unbound reference = compile-time E0022 resolution whole-program short-circuit");
    assert!(
        err.to_string().contains("spinx") || err.to_string().contains("unbound reference"),
        "diagnostic must name symbol/unbound family (actual: {})",
        err
    );
}

/// Negative 16 (expand/compile — N2 import face): `string_append`
/// without `import kerf_string;` (stress-shaped).
#[test]
fn neg_import_face_unbound_without_import() {
    let err = check_source_recover("let keep = string_append(\"a\", \"b\");\nkeep", "bad.ktf")
        .expect_err("not imported kerf-string string_append = E0022(N2 injection face)");
    assert!(
        err.to_string().contains("string-append"),
        "diagnostic must name mapped symbol string-append(actual: {})",
        err
    );
}

/// Negative 17 (expand — E0025 collected): a non-exhaustive match (no
/// wildcard arm) collected in recovery mode.
#[test]
fn neg_match_nonexhaustive_e0025_collected() {
    let report = check_source_recover("fn f(x: i64) { match x { 0 => 1 } }", "bad.ktf")
        .expect("in recovery mode E0025 collection does not short-circuit (diagnostics reachable)");
    assert_eq!(
        report.diagnostics.len(),
        1,
        "non-exhaustive match = exactly one diagnostic (actual {}: {:?})",
        report.diagnostics.len(),
        report.rendered
    );
    assert!(
        report.rendered[0].contains("E0025"),
        "diagnostic must carry E0025 exhaustiveness basis(actual: {})",
        report.rendered[0]
    );
}

/// Negative 18 (HM — E0005): a stress-shaped fn body type error through
/// the check face (mk body with a string operand under `+`).
#[test]
fn neg_hm_type_error_stress_shaped() {
    let report = check_source_recover(
        "fn mk(n: i64) { if (n == 0) { () } else { n + \"a\" } }\nmk(1)",
        "bad.ktf",
    )
    .expect("recovery mode: type errors do not short-circuit (diagnostics reachable)");
    assert!(
        report.rendered.iter().any(|r| r.contains("E0005")),
        "mk in body n + \"a\" must E0005(actual: {:?})",
        report.rendered
    );
}

/// Negative 19 (HM — E0005 through a defined global): `define(x, "a");`
/// then `x + 1` — the define-value global chain (stress-shaped keep
/// form).
#[test]
fn neg_hm_define_global_type_error() {
    let report = check_source_recover("let x = \"a\";\nx + 1", "bad.ktf")
        .expect("recovery mode: type errors do not short-circuit (diagnostics reachable)");
    assert!(
        report.rendered.iter().any(|r| r.contains("E0005")),
        "let x = \"a\" + x + 1 must E0005(actual: {:?});",
        report.rendered
    );
}

/// Negative 20 (runtime — E0004): calling a non-function value
/// (stress-shaped: the keep list called).
#[test]
fn neg_runtime_call_non_function_fail() {
    let err = run_source("let keep = list(1, 2);\nkeep(1)", "bad.ktf")
        .expect_err("uncallable values must be run-time errors(E0004)");
    assert!(
        err.to_string().contains("uncallable"),
        "diagnostic must name uncallable(actual: {})",
        err
    );
}

/// Negative 21 (runtime — E0004): `head` of a non-pair value
/// (stress-shaped).
#[test]
fn neg_runtime_head_of_non_pair_fail() {
    let err = run_source("fn spin(n: i64) { head(n) }\nspin(5)", "bad.ktf")
        .expect_err("head non-pairs must be run-time errors(E0004)");
    assert!(
        err.to_string().contains("head"),
        "diagnostic must name head predicate family(actual: {})",
        err
    );
}

/// Negative 22 (runtime — E0004 string operand): a string operand under
/// the numeric `+` operator on the run face.
#[test]
fn neg_runtime_string_operand_run_face() {
    assert!(
        run_source("\"a\" + \"b\"", "bad.ktf").is_err(),
        "string as + operands must be run-time errors(+ requires int)"
    );
}

/// Negative 23 (recovery — position-ordered collection): an expand-stage
/// error (E0002 `quote()` with no datum) plus an HM type error (E0005)
/// collected together in source position order (stress-shaped).
#[test]
fn neg_recovery_multi_error_position_order() {
    let src = "quote()\nlet x = \"a\";\nx + 1";
    let report = check_source_recover(src, "bad.ktf")
        .expect("recovery mode: per-form collection without short-circuit");
    assert_eq!(
        report.diagnostics.len(),
        2,
        "E0002 + E0005 each one(actual {}: {:?})",
        report.diagnostics.len(),
        report.rendered
    );
    assert!(
        report.rendered[0].contains("E0002"),
        "first diagnostic = E0002 quote malformed (position order)"
    );
    assert!(
        report.rendered[1].contains("E0005"),
        "second diagnostic = E0005 type error(position order)"
    );
}

/// Negative 24 (recovery — r126 failed-define ∀α absorption on the
/// stress face): a define whose body carries an E0005 still binds (the
/// r126 tc-check-define unify-failure ∀α generalization), so the
/// subsequent call checks clean — exactly one diagnostic, zero pollution
/// of the following items.
#[test]
fn neg_recovery_failed_define_absorption_zero_pollution() {
    let src = "fn mk(n: T) { 1 + \"a\" }\nmk(1)";
    let report = check_source_recover(src, "bad.ktf")
        .expect("recovery mode: failure define absorbs subsequent items with zero pollution(r126 ∀α binding)");
    assert_eq!(
        report.diagnostics.len(),
        1,
        "exactly one diagnostic (in body E0005; subsequent mk(1) call zero-pollution -- actual {}: {:?})",
        report.diagnostics.len(),
        report.rendered
    );
    assert!(
        report.rendered[0].contains("E0005"),
        "unique diagnostic = in body E0005(actual: {})",
        report.rendered[0]
    );
}

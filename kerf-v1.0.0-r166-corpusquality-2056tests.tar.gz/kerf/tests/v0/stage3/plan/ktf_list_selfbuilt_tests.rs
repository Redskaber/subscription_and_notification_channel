//! .ktf list-domain self-built family tests — r164 / 235 (the list-domain
//! migration window: the five fixed-arity faces length/reverse/nth/drop/
//! last-pair migrated from the Rust seed registry into the self-built kerf
//! source `bootstrap/list.ktf` — forms-level injection, the preamble.ktf
//! isomorph; member/assoc stay Rust-registered (the performance-boundary
//! ruling — the check-HM lookup segment's depth-sensitive hot consumption
//! trips the transitional VM instruction budget; re-migration trigger-gated
//! on the native-AOT recovery path); `list`/`append` stay (N1 variadic
//! constructor + variadic arity — TD-038); list-self-built-design.md v1.0
//! D1-D12).
//!
//! **Verification surfaces** (8 positives : 24 negatives = 1:3):
//! (1) **run-face E2E** — the five migrated faces' core behaviors (length
//! count / reverse incl. the empty-list as-() shape / nth index / drop
//! suffix / last-pair final cell) + the CASCADE injection (import
//! kerf_prelude ⇒ nth/drop available — the re-export domain's definition
//! single-source) + the qualified-name flat rewrite (`list::nth` — the
//! qualified Var flattens to the injected define's binding) + the
//! selective-rename E2E (`use kerf_list::{nth as pick}` — the r135 D14
//! isomorph extended) + the tail-recursion frame-budget proof (a
//! 10⁴-element list's length — O(n) frames via the TCO tail-chain, TD-022
//! honored) + the append/list Rust-anchored coexistence (the migration
//! boundary's other half);
//! (2) **fail-closed negatives** — the exact retired-Rust error messages
//! byte-anchored at the runtime face ×13 (non-list inputs across the five
//! faces / nth's index domain ×3 / drop's index domain ×3 / last-pair's
//! non-empty face) + the fn-form arity face ×5 (E0004 "procedure argument
//! count mismatch" — the declared behavior change, D5) + the static
//! generic-unification face (E0005 type mismatch num/str — the honest
//! stricter face, D7) + the member/assoc Rust-maintained static rows
//! (E0005 "member requires list" — the performance-boundary ruling's
//! kept half) + E0022 unimported ×1 + the r163 boundary regression (the
//! previous window's index face coexists with the injected body —
//! `v[1]` with an import-free vector-ref) + 7 error classes ≥6 (E0001
//! via the arity family's compile face is carried by E0004/E0005 here;
//! E0004 ×18 / E0005 ×2 / E0022 ×1 + E0006 via the gated coexistence).
//!
//! Honest-boundary anchors (design D5/D7/D8): the arity face's message
//! CHANGED to the fn form (declared); the static positional rows retired
//! (the generic (T,T) unification reports conflicts where they exist —
//! fail-closed direction preserved); type_name granularity (Closure/
//! Builtin both "procedure"; the predicate-false fallback "unit") is
//! declared and untestable from the value face.

use kerf_driver::{check_source_recover, run_source};

fn run_rendered(src: &str) -> String {
    let out = run_source(src, "lsb.ktf").expect("run must succeed");
    kerf_vm::render_value(&out.value, &out.heap)
}

fn run_err_contains(src: &str, needle: &str) {
    let err = run_source(src, "lsbneg.ktf").expect_err("run must fail");
    assert!(
        err.rendered.contains(needle),
        "runtime error must contain `{}`: {}\nsrc: {}",
        needle,
        err.rendered,
        src
    );
}

fn static_clean(src: &str) {
    let report = check_source_recover(src, "lsbchk.ktf").expect("check must pass compile");
    assert!(
        report.diagnostics.is_empty(),
        "must be static-clean: {:?}\nsrc: {}",
        report.rendered,
        src
    );
}

// ---------------------------------------------------------------------------
// Positives (8)
// ---------------------------------------------------------------------------

/// P01: length — the migrated tail-recursive spine walk.
#[test]
fn p01_length_core() {
    assert_eq!(
        run_rendered("import kerf_list;\nlet l = list(1, 2, 3, 4, 5);\nlength(l)"),
        "5"
    );
    assert_eq!(run_rendered("import kerf_list;\nlength(())"), "0");
}

/// P02: reverse — including the empty list's as-() shape (the retired Rust
/// face's exact nil-value form).
#[test]
fn p02_reverse_core() {
    assert_eq!(
        run_rendered("import kerf_list;\nreverse(list(1, 2, 3))"),
        "(3 2 1)"
    );
    // the empty result renders "nil" (Value::Nil's rendering — the ()
    // literal at the argument position IS the nil value; the returned
    // nil passes is_nil, byte-identical with the retired Rust face)
    assert_eq!(run_rendered("import kerf_list;\nreverse(())"), "nil");
    static_clean("import kerf_list;\nlet r = reverse(());\nis_nil(r)");
}

/// P03: nth + drop — the two-arg positional pair.
#[test]
fn p03_nth_drop_core() {
    assert_eq!(
        run_rendered("import kerf_list;\nnth(list(10, 20, 30), 1)"),
        "20"
    );
    assert_eq!(
        run_rendered("import kerf_list;\ndrop(list(10, 20, 30), 1)"),
        "(20 30)"
    );
}

/// P04: last-pair — the final pair cell of a proper list.
#[test]
fn p04_last_pair_core() {
    assert_eq!(
        run_rendered("import kerf_list;\nlast_pair(list(1, 2, 3))"),
        "(3)"
    );
}

/// P05: the CASCADE injection — import kerf_prelude makes nth/drop
/// available (the re-export domain's definition single-source — list.ktf
/// injected alongside the preamble body).
#[test]
fn p05_cascade_injection() {
    assert_eq!(
        run_rendered("import kerf_prelude;\nfn inc(x: T) { x + 1 }\nmap(inc, nth(list(list(9), list(1, 2)), 1))"),
        "(2 3)"
    );
    assert_eq!(
        run_rendered("import kerf_prelude;\ndrop(list(10, 20, 30), 1)"),
        "(20 30)"
    );
}

/// P06: the qualified-name flat rewrite — `list::nth` flattens to the
/// injected define's binding (the qualified key has no Rust registration).
#[test]
fn p06_qualified_flat_rewrite() {
    assert_eq!(
        run_rendered("import kerf_list;\nlist::nth(list(quote(a), quote(b), quote(c)), 1)"),
        "b"
    );
}

/// P07: the selective rename — `use kerf_list::{nth as pick}` (the r135
/// D14 Stx-injection isomorph extended to the self-built domain).
#[test]
fn p07_selective_rename() {
    assert_eq!(
        run_rendered("use kerf_list::{nth as pick};\npick(list(7, 8, 9), 2)"),
        "9"
    );
}

/// P08: the tail-recursion frame-budget proof — a 10⁴-element list's
/// length consumes O(n) frames via the TCO tail-chain (TD-022 honored;
/// the accumulator form is a non-stack-growing tail loop).
#[test]
fn p08_frame_budget_ten_thousand() {
    assert_eq!(
        run_rendered(
            "import kerf_list;\nfn build(n: T, acc: T) { if (n == 0) { acc } else { build(n - 1, cons(n, acc)) } }\nlength(build(10000, ()))"
        ),
        "10000"
    );
}

/// P08b: the migration boundary's Rust-anchored half — list/append/
/// member/assoc coexist unchanged with the injected body (the
/// performance-boundary ruling's kept faces + the N1 variadic pair).
#[test]
fn p08b_boundary_rust_anchored_coexistence() {
    assert_eq!(
        run_rendered("import kerf_list;\nappend(list(1, 2), list(3))"),
        "(1 2 3)"
    );
    assert_eq!(
        run_rendered("import kerf_list;\nmember(3, list(1, 2, 3))"),
        "(3)"
    );
    assert_eq!(
        run_rendered("import kerf_list;\nassoc(2, list(list(1, 10), list(2, 20)))"),
        "(2 20)"
    );
    assert_eq!(
        run_rendered("import kerf_list;\nassoc(2, list((1, 10), (2, 20)))"),
        "(2 . 20)"
    );
}

// ---------------------------------------------------------------------------
// Negatives (24)
// ---------------------------------------------------------------------------

/// N01-N04: length's non-list inputs — the exact retired-Rust message
/// (byte-anchored, including the type_name mapping).
#[test]
fn n01_length_non_list_int() {
    run_err_contains(
        "import kerf_list;\nlength(5)",
        "length requires list(nil terminated pair chain), got int",
    );
}

#[test]
fn n02_length_non_list_str() {
    run_err_contains(
        "import kerf_list;\nlength(\"ab\")",
        "length requires list(nil terminated pair chain), got str",
    );
}

#[test]
fn n03_length_non_list_symbol() {
    run_err_contains(
        "import kerf_list;\nlength(quote(sym))",
        "length requires list(nil terminated pair chain), got symbol",
    );
}

#[test]
fn n04_length_non_list_bool() {
    run_err_contains(
        "import kerf_list;\nlength(true)",
        "length requires list(nil terminated pair chain), got bool",
    );
}

/// N05-N06: reverse's non-list inputs.
#[test]
fn n05_reverse_non_list_int() {
    run_err_contains(
        "import kerf_list;\nreverse(5)",
        "reverse requires list, got int",
    );
}

#[test]
fn n06_reverse_non_list_str() {
    run_err_contains(
        "import kerf_list;\nreverse(\"abc\")",
        "reverse requires list, got str",
    );
}

/// N07: nth's index domain — non-int.
#[test]
fn n07_nth_index_non_int() {
    run_err_contains(
        "import kerf_list;\nnth(list(1, 2), \"x\")",
        "nth index requires int, got str",
    );
}

/// N08: nth's negative index (the sign carried in the message).
#[test]
fn n08_nth_negative_index() {
    run_err_contains(
        "import kerf_list;\nnth(list(1, 2), -1)",
        "nth index requires a non-negative integer, got -1",
    );
}

/// N09: nth's out-of-range walk-off (the original index reported; nil
/// and non-pair inputs share the face — the retired `_` arm's uniformity).
#[test]
fn n09_nth_out_of_range() {
    run_err_contains(
        "import kerf_list;\nnth(list(1, 2), 5)",
        "nth index 5 out of list range",
    );
    run_err_contains(
        "import kerf_list;\nnth(5, 0)",
        "nth index 0 out of list range",
    );
}

/// N10: drop's index domain — non-int.
#[test]
fn n10_drop_index_non_int() {
    run_err_contains(
        "import kerf_list;\ndrop(list(1, 2), \"x\")",
        "drop index requires int, got str",
    );
}

/// N11: drop's negative index (its own start-index message).
#[test]
fn n11_drop_negative_index() {
    run_err_contains(
        "import kerf_list;\ndrop(list(1, 2), -1)",
        "drop start index requires a non-negative integer, got -1",
    );
}

/// N12: drop's out-of-range + non-list entry (every-step shape check).
#[test]
fn n12_drop_out_of_range_and_non_list() {
    run_err_contains(
        "import kerf_list;\ndrop(list(1, 2), 5)",
        "drop index 5 out of list range",
    );
    run_err_contains(
        "import kerf_list;\ndrop(5, 0)",
        "drop requires list, got int",
    );
}

/// N13-N14: last-pair's non-empty + non-list faces.
#[test]
fn n13_last_pair_empty() {
    run_err_contains(
        "import kerf_list;\nlast_pair(())",
        "last-pair requires non-empty list",
    );
}

#[test]
fn n14_last_pair_non_list() {
    run_err_contains(
        "import kerf_list;\nlast_pair(5)",
        "last-pair requires list, got int",
    );
}

/// N15-N19: the fn-form arity face ×5 (E0004 "procedure argument count
/// mismatch" — the declared behavior change from the builtin-form message).
#[test]
fn n15_arity_length() {
    run_err_contains(
        "import kerf_list;\nlength()",
        "procedure argument count mismatch: expected 1, got 0",
    );
}

#[test]
fn n16_arity_length_over() {
    run_err_contains(
        "import kerf_list;\nlength(list(1), list(2))",
        "procedure argument count mismatch: expected 1, got 2",
    );
}

#[test]
fn n17_arity_nth() {
    run_err_contains(
        "import kerf_list;\nnth(list(1))",
        "procedure argument count mismatch: expected 2, got 1",
    );
}

#[test]
fn n18_arity_drop() {
    run_err_contains(
        "import kerf_list;\ndrop()",
        "procedure argument count mismatch: expected 2, got 0",
    );
}

#[test]
fn n19_arity_last_pair() {
    run_err_contains(
        "import kerf_list;\nlast_pair()",
        "procedure argument count mismatch: expected 1, got 0",
    );
}

/// N20: the static generic-unification face — nth(list(1,2), "x") reports
/// the num/str conflict (E0005 — the honest stricter face, fail-closed
/// direction preserved; the runtime face carries the exact message).
#[test]
fn n20_static_generic_unification() {
    let report = check_source_recover("import kerf_list;\nnth(list(1, 2), \"x\")", "n20.ktf")
        .expect("check must pass compile");
    assert!(
        report
            .diagnostics
            .iter()
            .any(|d| d.message.contains("type mismatch")),
        "static unification face: {:?}",
        report.rendered
    );
    run_err_contains(
        "import kerf_list;\nnth(list(1, 2), \"x\")",
        "nth index requires int, got str",
    );
}

/// N21: the member/assoc Rust-maintained static rows — the
/// performance-boundary ruling's kept half (E0005 "member requires list"
/// stays a STATIC face).
#[test]
fn n21_member_static_row_maintained() {
    let report = check_source_recover("import kerf_list;\nmember(1, \"ab\")", "n21.ktf")
        .expect("check must pass compile");
    assert!(
        report
            .diagnostics
            .iter()
            .any(|d| d.message.contains("member requires list")),
        "member's static row maintained: {:?}",
        report.rendered
    );
}

/// N22: E0022 unimported — the flat visibility boundary.
#[test]
fn n22_unimported_e0022() {
    let err = run_source("length(list(1, 2))", "n22.ktf").expect_err("must fail");
    assert!(
        err.rendered.contains("unbound reference: `length`"),
        "E0022 face: {}",
        err.rendered
    );
}

/// N23: the r163 boundary regression — the index face coexists with the
/// injected body (import-free vector-ref; `v[1]` while kerf_list's body
/// is injected into the unit via a sibling import).
#[test]
fn n23_r163_index_face_coexistence() {
    assert_eq!(
        run_rendered("import kerf_list;\nlet v = [5, 6, 7];\nv[2] + length(list(1))"),
        "8"
    );
}

/// N24: the cascade-injection negative — a prelude-importing unit's
/// nth still enforces (the injected define's runtime face through the
/// re-export path).
#[test]
fn n24_cascade_enforcement() {
    run_err_contains(
        "import kerf_prelude;\nnth(list(1, 2), 9)",
        "nth index 9 out of list range",
    );
    static_clean("import kerf_prelude;\n42");
}

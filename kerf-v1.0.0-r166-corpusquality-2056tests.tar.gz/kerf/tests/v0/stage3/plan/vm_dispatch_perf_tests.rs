// E6 close-out (r154 / 224-c6): corpus converted to the target-syntax face.
//! T3+ optimization window r54 (76-b) — VM main dispatch performance
//! evolution (O1 lazy span evaluation + O2 instruction-by-reference/
//! single bounds check + O3 proto reference cached across iterations)
//! semantic zero-drift guard tests (TD-028 optimization window — the second
//! piece of the t3 optimization window).
//!
//! **Contract terms** (r54 plan §2 general principles, following the r53
//! five-means convention): optimization must not change (a) error message
//! text and the debug span carried by errors (O1 lazy evaluation must take
//! the span of the same instruction as the eager version — the `cur_pc`
//! bound before the pc increment invariant); (b) dispatch behavior and
//! frame semantics (O2 dispatch by reference must not change any arm's
//! execution semantics); (c) proto cache invalidation correctness (O3 sets
//! the dirty bit explicitly at nine frame-mutation points — Call/Ret/
//! TailCall/resume/INSTALL_HANDLER/PERFORM behavior unchanged on all paths).
//!
//! Coverage (§9.4.3 positive:negative ratio — error-face anchors first):
//! - O1 span correctness: type errors/arity errors/unbound/division by zero
//!   — error location and message anchored verbatim (the error span points
//!   at the failing instruction's source position);
//! - O2 guard semantics: pc out-of-bounds defensive message preserved
//!   (bytecode-corruption guard rail — after `get`-ification, same text as
//!   the original index guard);
//! - O3 invalidation discipline: deep call chains/tail-call chains/
//!   continuation resumption/effect resumption — behavior anchors at all
//!   frame-mutation points;
//! - Determinism: two runs of the same program agree (dispatch optimization
//!   introduces zero nondeterminism);
//! - Benchmark anchor: fib 25 numerically correct (value anchor of the
//!   r52/r53/r54 performance evolution chain).

use crate::common;
use kerf_vm::Value;

// ---------------------------------------------------------------------------
// O1 — error-path span correctness (lazy evaluation and eager
// same-instruction invariant)
// ---------------------------------------------------------------------------

/// Span and message anchors for stack underflow/type errors: error rendering
/// must carry the failing instruction's source position (after O1 removed
/// per-instruction eager spans, the error path takes the value through
/// `cur_span!()` — this test anchors that its correspondence with the
/// failing instruction does not drift).
#[test]
fn o1_error_span_points_to_failing_source_line() {
    // The head application on line 2 triggers the type error — the error
    // location must point at that line (not the lines before/after)
    let src = "fn ok() -> i64 { 1 }
head(5)
ok()";
    let err = common::run(src).unwrap_err();
    assert!(
        err.contains("line 2") || err.contains("line 2") || err.contains("2:"),
        "error span must refers to to line of the failing instruction(# 2 line): \n{}",
        err
    );
    assert!(
        err.contains("head") || err.contains("pair"),
        "message body preserved: \n{}",
        err
    );
}

/// Type-error message verbatim anchor (JumpIfFalse arm — the cur_span!() path).
#[test]
fn o1_truthy_type_error_message_preserved() {
    let err = common::run("if (1) { 2 } else { 3 }").unwrap_err();
    assert!(
        err.contains("bool") || err.contains("truthy"),
        "JumpIfFalse arm message preserved: \n{}",
        err
    );
}

/// Arity mismatch error (Call arm cur_span!() path — message + location).
#[test]
fn o1_arity_error_message_and_span_preserved() {
    let err = common::run(
        "fn f(x: i64) -> i64 { x }
f(1, 2)",
    )
    .unwrap_err();
    assert!(
        err.contains("argument count"),
        "Call arm message preserved: \n{}",
        err
    );
    assert!(
        err.contains("line 2") || err.contains("line 2") || err.contains("2:"),
        "error position points to the call line:\n{}",
        err
    );
}

/// set! unbound message via the messages single source (StoreGlobal arm cur_span!() path).
#[test]
fn o1_setbang_unbound_message_preserved() {
    let err = common::run(
        "fn g() { nope = 1; }
g()",
    )
    .unwrap_err();
    assert!(
        err.contains("unbound") || err.contains("set"),
        "StoreGlobal arm message preserved: \n{}",
        err
    );
}

/// Division-by-zero error (cur_span!() path inside the binop! macro).
#[test]
fn o1_division_error_span_preserved() {
    let err = common::run("1 / 0").unwrap_err();
    assert!(
        err.contains("division by zero"),
        "binop macro message preserved: \n{}",
        err
    );
}

// ---------------------------------------------------------------------------
// O2 — dispatch guard semantics (guard-rail message preserved after
// instruction reference-ification)
// ---------------------------------------------------------------------------

/// O2 error message verbatim anchor: hand-built "no terminator instruction"
/// bytecode (code without a Halt/Ret terminator) drives the pc out-of-bounds
/// guard rail. The guard-rail message must be verbatim identical to
/// pre-reference-ification ("pc out of bounds: proto N pc M (corrupted
/// bytecode or missing terminator instruction)").
#[test]
fn o2_pc_bounds_guard_message_preserved() {
    use kerf_compiler::{BcConst, BcProgram, BcProto, Op};
    use kerf_runtime::Heap;
    use kerf_syntax::Symbol;
    use kerf_vm::run_program;
    use std::collections::HashMap;

    // Main proto code = [PushConst 0] (no Halt — after execution pc=1 goes out of bounds and triggers the guard rail)
    let proto = BcProto {
        name: Symbol(u32::MAX - 1),
        params: vec![],
        rest_slot: None,
        n_locals: 0,
        capture_names: vec![],
        capture_sources: vec![],
        code: vec![Op::PushConst(0)],
        debug_spans: vec![kerf_span::Span::dummy(); 1],
        free_vars: vec![],
    };
    let program = BcProgram {
        protos: vec![proto],
        consts: vec![BcConst::Int(7)],
        entry: 0,
        global_refs: vec![],
        module_name: None,
    };
    let mut globals = HashMap::new();
    let mut heap = Heap::new();
    let err = match run_program(&program, &mut globals, &mut heap) {
        Ok(_) => {
            panic!("no terminating instruction bytecode must trigger pc out of bounds guardrail")
        }
        Err(e) => e,
    };
    assert!(
        err.message.contains("pc out of bounds")
            && err
                .message
                .contains("bytecode corrupted or missing a terminating instruction"),
        "guardrail message preserved(O2 get does not change guard semantics): \n{}",
        err.message
    );
}

// ---------------------------------------------------------------------------
// O3 — proto cache invalidation discipline (behavior anchors at all nine
// frame-mutation points)
// ---------------------------------------------------------------------------

/// Deep non-tail recursion 5000 levels: Call push-frame/Ret pop-frame
/// alternating (two cache invalidations per level) — value correctness
/// anchor.
#[test]
fn o3_deep_nontail_call_ret_chain() {
    let src = r#"
fn sum(n: i64) -> i64 { if (n == 0) { 0 } else { n + sum(n - 1) } }
sum(5000)
"#;
    common::assert_int(src, 12_502_500);
}

/// Tail recursion 100k levels (TailCall frame-replacement path — net zero frames + cache invalidation).
#[test]
fn o3_tail_call_frame_replacement_chain() {
    let src = r#"
fn count(n: i64, acc: i64) -> i64 { if (n == 0) { acc } else { count(n - 1, acc + 1) } }
count(100000, 0)
"#;
    common::assert_int(src, 100_000);
}

/// Mutual tail recursion (frame replacement alternating between two protos — cache repeatedly invalidated/refetched).
#[test]
fn o3_mutual_tail_recursion_alternates_protos() {
    // letrec → top-level mutually-recursive fns (E6-CG §2: no letrec on
    // the target surface); ev?/od? → the is_ modern charset.
    let src = r#"
fn is_even(n: i64) -> bool { if (n == 0) { true } else { is_odd(n - 1) } }
fn is_odd(n: i64) -> bool { if (n == 0) { false } else { is_even(n - 1) } }
if (is_even(20001)) { 1 } else { 0 }
"#;
    common::assert_int(src, 0);
}

/// Effect perform/handle resumption path (INSTALL_HANDLER double frame push +
/// PERFORM frame swap/truncation + continuation resume — behavior
/// anchors at three cache-invalidation points).
#[test]
fn o3_effect_perform_resume_roundtrip() {
    let src = r#"
fn ask() { perform t(41); }
handle (1 + ask()) { t(p, k) => resume(p + 1) }
"#;
    // perform payload 41 → handler resume(k, 42) → suspension point evaluates to 42 → +1 = 43
    common::assert_int(src, 43);
}

/// Deep effects (truncation + restored value delivered directly — behavior anchor of PERFORM frame swap/truncation).
#[test]
fn o3_nested_effects_with_deep_perform() {
    let src = r#"
fn emit() { perform done(7); }
fn walk(n: i64) -> i64 { if (n == 0) { emit() } else { 1 + walk(n - 1) } }
handle walk(100) { done(p, k) => { p } }
"#;
    // After 100 levels of deep recursion perform → truncate 100 frames → handler does not resume → handle value = payload 7
    common::assert_int(src, 7);
}

/// Mixed call shapes: direct calls + tail calls + returns + closure captures shared across frames.
#[test]
fn o3_mixed_call_shapes_with_captures() {
    let src = r#"
fn make(n: i64) { || (x: i64) { x + n } }
fn apply_twice(f: T, x: i64) -> i64 { f(f(x)) }
fn direct(a: i64, b: i64) -> i64 { a + b }
apply_twice(make(10), direct(1, 2))
"#;
    common::assert_int(src, 23);
}

// ---------------------------------------------------------------------------
// Determinism and benchmark anchors
// ---------------------------------------------------------------------------

/// Determinism anchor: two compiles + runs of the same program agree (dispatch optimization: zero nondeterminism).
#[test]
fn dispatch_optimization_determinism_anchor() {
    let src = r#"
import kerf_prelude;
fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }
map(|| (x: i64) { x * fib(x) }, list(10, 12, 14, 16, 18, 20))
"#;
    let a = common::run_rendered(src);
    let b = common::run_rendered(src);
    assert_eq!(
        a, b,
        "twice run render must bit-for-bit consistent(determinism anchor)"
    );
}

/// fib 25 value anchor (r52/r53/r54 performance evolution chain — the value face of the 76.354ms figure).
#[test]
fn fib_25_value_anchor_across_perf_evolution() {
    let src = r#"
fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }
fib(25)
"#;
    match common::run(src) {
        Ok(Value::Int(v)) => assert_eq!(v, 75_025),
        other => panic!("fib 25 must return 75025, got {:?}", other),
    }
}

/// GC survival anchor: allocation pressure + deep-frame root scanning
/// (TD-023 face zero regression — O1-O3 do not touch root-set enumeration,
/// but frame-layout/dispatch changes must prove survival does not regress).
#[test]
fn gc_survival_under_dispatch_optimization() {
    let src = r#"
fn grow(n: i64) -> i64 {
    if (n == 0) { 0 } else { cons(1, 2); cons(3, 4); cons(5, 6); grow(n - 1) }
}
grow(2000)
"#;
    common::assert_int(src, 0);
}

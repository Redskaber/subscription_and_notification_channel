//! .ktf percent-operator family tests — r159 / 229-c (the
//! operator-surface parity window: the term-level infix `%` primary face
//! closes the EBNF-vs-registration gap — operator-surface-parity-design
//! v1.0).
//!
//! **Verification surfaces** (the infix `n % 2` parses to the Stx `(% n 2)`
//! — the EBNF Level 0 term production's primary modulo face; the `mod`
//! call form stays registered as the legacy alias; zero core/expander/
//! compiler/HM/VM mechanism change — one concept, two faces, principle
//! 31; 8 primitives' invariance round 41; design single source =
//! operator-surface-parity-design.md v1.0):
//! (1) **run-face E2E** — the infix face binds and evaluates (the r158
//! baseline gap: `7 % 2` was E0022-unbound while `mod(7, 2)` worked —
//! the S-expr-era call form was the only usable face);
//! (2) **grammar settlement** — dual-Reader canonical Stx rendering
//! byte-identical (seed parse_term vs mirror parse-term — both Readers
//! already produced `(% a b)`; the registration chain was the missing
//! link), error faces message + Span byte-identical (the E0001
//! expression-expectation family);
//! (3) **cross-stage consumption** — the infix program through
//! `check_source_recover` stays diagnostic-clean with real instruction
//! artifacts (HM/check consume the `(% n 2)` signature — check.ktf
//! TC_SIGS row + BUILTIN_SIGS row);
//! (4) **fail-closed negatives** — operand-shape errors (EOF / double
//! percent / prefix position / statement position / match-pattern
//! position / nested literal EOF) / domain errors (float / bool / string
//! operands, modulo by zero — the Fold::Mod discipline) / the alias's
//! arity floor / E0022 unbound operands (lhs/rhs/nested/chain) / E0014
//! multi-segment path / E0006 undeclared capability operand / E0005
//! recovery-mode static typing — 7 error classes covered.
//!
//! Skin-dictionary basis: 20 §14 (the operator row: `%` primary + `mod`
//! alias — this window); 02 §8.13 precedence table (term level 4:
//! `"*" | "/" | "%"`). Window basis: user instruction ① (the
//! operator-design S-expr-era residual audit — the `%` gap surfaced by
//! the §20.3 same-path full audit) + operator-surface-parity-design.md
//! v1.0 D1-D8. Ratio: 8 positive : 24 negative = 1:3 (§9.4.3).

use kerf_driver::bootstrap::reader::read_source_for_bootstrap;
use kerf_driver::{check_source_recover, run_source, Stage};
use kerf_reader::reader::read_source;
use kerf_span::DiagnosticCode;
use kerf_syntax::{Stx, StxDatum, StxLiteral, SymbolTable};

// ---------------------------------------------------------------------------
// Value helpers
// ---------------------------------------------------------------------------

fn run_value(src: &str, filename: &str) -> String {
    let outcome = run_source(src, filename)
        .unwrap_or_else(|e| panic!("target face program {} execution failed:{}", filename, e));
    kerf_vm::render_value(&outcome.value, &outcome.heap)
}

fn read_err(src: &str, filename: &str) -> kerf_reader::reader::ReadError {
    let mut sm = kerf_span::SourceMap::new();
    let fid = sm.add_file(filename, src);
    let mut table = SymbolTable::new();
    read_source(src, fid, &mut table)
        .err()
        .unwrap_or_else(|| panic!("[{}] expected a read error, parsed successfully", filename))
}

// ---------------------------------------------------------------------------
// Dual-Reader parity helpers (the ktf_toplevel_let_tests.rs caliber —
// canonical rendering with Span bytes; error parity with message + Span
// byte equality)
// ---------------------------------------------------------------------------

fn render_stx(s: &Stx, t: &SymbolTable) -> String {
    let mut out = String::new();
    render_stx_into(s, t, &mut out);
    out
}

fn render_stx_into(s: &Stx, t: &SymbolTable, out: &mut String) {
    match &s.datum {
        StxDatum::Symbol(sym) => {
            out.push_str(&format!(
                "(sym {} {}..{})",
                t.name(*sym),
                s.span.start,
                s.span.end
            ));
        }
        StxDatum::Literal(l) => match l {
            StxLiteral::Int(v) => {
                out.push_str(&format!("(int {} {}..{})", v, s.span.start, s.span.end));
            }
            StxLiteral::Float(f) => {
                out.push_str(&format!("(float {:?} {}..{})", f, s.span.start, s.span.end));
            }
            StxLiteral::Str(r) => {
                out.push_str(&format!("(str {:?} {}..{})", r, s.span.start, s.span.end));
            }
            StxLiteral::Bool(b) => {
                out.push_str(&format!("(bool {} {}..{})", b, s.span.start, s.span.end));
            }
            StxLiteral::Nil => {
                out.push_str(&format!("(unit {}..{})", s.span.start, s.span.end));
            }
        },
        StxDatum::List(items) => {
            out.push_str(&format!("(lst {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
        StxDatum::Vector(items) => {
            out.push_str(&format!("(vec {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
    }
}

/// Grammar parity assertion: both Readers' canonical renderings are
/// byte-identical (the term-level infix is seed/mirror isomorphic by
/// construction — the same `(% a b)` list behind both faces, Span bytes
/// included).
fn assert_grammar_parity(src: &str, what: &str) {
    let mut t1 = SymbolTable::new();
    let seed = read_source(src, 0, &mut t1)
        .unwrap_or_else(|e| panic!("[{}] seed syntax failed: {}", what, e.message));
    let mut t2 = SymbolTable::new();
    let mirror = read_source_for_bootstrap(src, 0, &mut t2)
        .unwrap_or_else(|e| panic!("[{}] mirror syntax failed:{}", what, e.message));
    assert_eq!(
        seed.len(),
        mirror.len(),
        "[{}] top-level item count mismatch (seed {} vs mirror {})",
        what,
        seed.len(),
        mirror.len()
    );
    for (i, (a, b)) in seed.iter().zip(mirror.iter()).enumerate() {
        assert_eq!(
            render_stx(a, &t1),
            render_stx(b, &t2),
            "[{}] top-level item #{} syntax tree mismatch (seed vs mirror canonical render)",
            what,
            i
        );
    }
}

/// Grammar-error parity assertion: message + Span byte-level equality
/// (the mirror's diagnostic face is the seed's, by construction — the
/// expression-expectation family is anchored in both Readers).
fn assert_grammar_err_parity(src: &str, what: &str) -> kerf_reader::reader::ReadError {
    let mut t1 = SymbolTable::new();
    let seed_err = match read_source(src, 0, &mut t1) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] seed should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    let mut t2 = SymbolTable::new();
    let mirror_err = match read_source_for_bootstrap(src, 0, &mut t2) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] mirror should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    assert_eq!(
        seed_err.message, mirror_err.message,
        "[{}] syntax error message mismatch (seed {:?} vs mirror {:?})",
        what, seed_err.message, mirror_err.message
    );
    assert_eq!(
        seed_err.span.start, mirror_err.span.start,
        "[{}] syntax error Span start mismatch (seed {} vs mirror {})",
        what, seed_err.span.start, mirror_err.span.start
    );
    assert_eq!(
        seed_err.span.end, mirror_err.span.end,
        "[{}] syntax error Span end mismatch (seed {} vs mirror {})",
        what, seed_err.span.end, mirror_err.span.end
    );
    seed_err
}

// ---------------------------------------------------------------------------
// Positives — run-face E2E + grammar settlement + cross-stage consumption
// ---------------------------------------------------------------------------

/// Positive 1 / integration: the core E2E — the r158-baseline gap closed
/// (`7 % 2` was E0022-unbound; the infix primary face now binds and
/// evaluates through the full run chain).
#[test]
fn pos_core_e2e_binding_closed() {
    assert_eq!(run_value("7 % 2", "pct_core.ktf"), "1");
    assert_eq!(run_value("13 % 4", "pct_13.ktf"), "1");
    assert_eq!(run_value("0 % 5", "pct_zero.ktf"), "0");
}

/// Positive 2: precedence and associativity — the term level binds
/// tighter than additive (`%` = level 4 with `* /`) and associates left.
#[test]
fn pos_precedence_and_associativity() {
    assert_eq!(run_value("2 + 3 % 2", "pct_prec1.ktf"), "3");
    assert_eq!(run_value("10 - 2 * 3 % 4", "pct_prec2.ktf"), "8");
    assert_eq!(run_value("10 % 3 % 2", "pct_assoc.ktf"), "1");
    assert_eq!(run_value("2 * 3 % 4", "pct_prec3.ktf"), "2");
}

/// Positive 3: signed-operand semantics — the truncated-remainder family
/// (the Fold::Mod discipline shared with the alias face, Rust-anchored).
#[test]
fn pos_signed_operand_semantics() {
    assert_eq!(run_value("-7 % 3", "pct_neglhs.ktf"), "-1");
    assert_eq!(run_value("7 % -3", "pct_negrhs.ktf"), "1");
    assert_eq!(run_value("-7 % -3", "pct_negboth.ktf"), "-1");
}

/// Positive 4: the alias value equivalence — `mod(7, 2)` and `7 % 2`
/// yield the same values (one concept, two faces — the r102 naming
/// lineage: the S-expr-era call form stays a registered alias).
#[test]
fn pos_alias_value_equivalence() {
    assert_eq!(run_value("mod(7, 2)", "pct_alias.ktf"), "1");
    assert_eq!(run_value("7 % 2", "pct_primary.ktf"), "1");
    assert_eq!(run_value("mod(13, 4)", "pct_alias13.ktf"), "1");
}

/// Positive 5: dual-Reader canonical rendering byte-identical — the
/// grammar settlement core gate (both Readers produced `(% a b)` since
/// the switch window; the r159 registration chain closed the consumer
/// gap — the parity face is asserted unperturbed).
#[test]
fn pos_dual_reader_canonical_parity() {
    assert_grammar_parity("7 % 2", "pct simple");
    assert_grammar_parity("2 + 3 % 2", "pct precedence");
    assert_grammar_parity("fn f(n: i64) -> i64 { n % 2 }\nf(7)", "pct fn operand face");
}

/// Positive 6: the same-Stx assertion — `7 % 2` lowers to the `(% 7 2)`
/// three-element core-form list (the machine anchor: the operator head
/// symbol is `%`, the EBNF Level 0 primary face).
#[test]
fn pos_same_core_form_percent_symbol() {
    let mut t1 = SymbolTable::new();
    let modern = read_source("7 % 2", 0, &mut t1).unwrap();
    assert_eq!(modern.len(), 1);
    let items = modern[0].datum.as_list().unwrap();
    assert_eq!(items.len(), 3, "the (% lhs rhs) three-element core form");
    assert_eq!(t1.name(items[0].datum.as_symbol().unwrap()), "%");
    assert!(matches!(
        items[1].datum,
        StxDatum::Literal(StxLiteral::Int(7))
    ));
    assert!(matches!(
        items[2].datum,
        StxDatum::Literal(StxLiteral::Int(2))
    ));
}

/// Positive 7 / integration (cross-stage): the infix program through
/// `check_source_recover` stays diagnostic-clean (HM/check consume the
/// `(% n 2)` signature — the check.ktf TC_SIGS row + BUILTIN_SIGS row
/// are the r159 chain).
#[test]
fn pos_check_cross_stage_consumption() {
    let src = "fn f(n: i64) -> i64 { n % 2 }\nf(7)";
    let r = check_source_recover(src, "pct_check.ktf").unwrap();
    assert!(
        r.diagnostics.is_empty(),
        "check must stay diagnostic-clean (actual: {:?})",
        r.diagnostics
    );
}

/// Positive 8 / integration: the corpus migration anchors — the
/// higher_order migrated face (`n % 2 == 0` — is_even) and the D42
/// do→statement-sequence isomorphism (the vector.ktf churn rewrite:
/// both forms yield the same value — skin swap, skeleton unchanged).
#[test]
fn pos_corpus_migrated_e2e() {
    let is_even = "fn is_even(n: i64) { n % 2 == 0 }\n[is_even(10), is_even(7)]";
    assert_eq!(run_value(is_even, "pct_is_even.ktf"), "[true false]");
    let block_form =
        "fn churn(n: i64) -> i64 { if n == 0 { 0 } else { cons(n, ()); churn(n - 1) } }\nchurn(3)";
    assert_eq!(run_value(block_form, "pct_churn_blk.ktf"), "0");
    let do_form =
        "fn churn(n: i64) -> i64 { if n == 0 { 0 } else { do(cons(n, ()), churn(n - 1)) } }\nchurn(3)";
    assert_eq!(run_value(do_form, "pct_churn_do.ktf"), "0");
}

// ---------------------------------------------------------------------------
// Negatives — operand shape / domain / resolution / capability / typing
// ---------------------------------------------------------------------------

/// Negative 1 (E0001 read class): EOF right after the operator (the
/// rhs expectation face) — dual-Reader message + Span byte parity.
#[test]
fn neg_eof_after_percent() {
    let e = assert_grammar_err_parity("7 %", "pct eof");
    assert!(
        e.message.contains("expected an expression"),
        "the expression-expectation diagnostic (actual: {})",
        e.message
    );
}

/// Negative 2 (E0001 read class): a doubled operator token (the second
/// `%` is not an expression) — dual-Reader parity.
#[test]
fn neg_double_percent() {
    let e = assert_grammar_err_parity("7 %% 2", "pct doubled");
    assert!(
        e.message.contains("got Percent"),
        "the Percent-token diagnostic (actual: {})",
        e.message
    );
}

/// Negative 3 (E0001 read class): the prefix position is rejected —
/// `%` is infix-only (the operator cannot be called as a function; the
/// call face belongs to the `mod` alias).
#[test]
fn neg_prefix_percent_position() {
    let e = assert_grammar_err_parity("%(1, 2)", "pct prefix");
    assert!(
        e.message.contains("got Percent"),
        "the prefix-position rejection (actual: {})",
        e.message
    );
}

/// Negative 4 (E0001 read class): a bare `%` in statement position
/// (the statement grammar expects an expression start).
#[test]
fn neg_statement_position_bare_percent() {
    let e = read_err("let a = 1; % 2;", "pct_stmt.ktf");
    assert!(
        e.message.contains("expected an expression"),
        "the statement-position diagnostic (actual: {})",
        e.message
    );
}

/// Negative 5 (E0001 read class): the match-pattern position rejects
/// the operator (patterns are literal/identifier/or-shape — the
/// arm-expectation diagnostic `expected =>, got Percent`).
#[test]
fn neg_match_pattern_position() {
    let e = read_err("match (5) { 1 % 2 => 3, _ => 4 }", "pct_pat.ktf");
    assert!(
        e.message.contains("expected =>"),
        "the pattern-position diagnostic (actual: {})",
        e.message
    );
}

/// Negative 6 (E0022 unbound class): an unbound lhs operand.
#[test]
fn neg_unbound_lhs_operand() {
    let err = run_source("x % 2", "pct_unbound_lhs.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Compile);
    assert!(
        err.rendered.contains("error[E0022]"),
        "the unbound-reference class (actual: {})",
        err.rendered
    );
    assert!(
        err.diagnostic.message.contains("unbound reference: `x`"),
        "the lhs operand is the reported name (actual: {})",
        err.diagnostic.message
    );
}

/// Negative 7 (E0022 unbound class): an unbound rhs operand.
#[test]
fn neg_unbound_rhs_operand() {
    let err = run_source("7 % x", "pct_unbound_rhs.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Compile);
    assert!(
        err.diagnostic.message.contains("unbound reference: `x`"),
        "the rhs operand is the reported name (actual: {})",
        err.diagnostic.message
    );
}

/// Negative 8 (E0022 unbound class): an unbound callee wrapping the
/// infix expression (the first-face resolution).
#[test]
fn neg_unbound_nested_call() {
    let err = run_source("f(x % 2)", "pct_unbound_call.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Compile);
    assert!(
        err.diagnostic.message.contains("unbound reference: `f`"),
        "the callee is the first reported name (actual: {})",
        err.diagnostic.message
    );
}

/// Negative 9 (E0004 run class): modulo by zero — the primary face.
#[test]
fn neg_modulo_by_zero_percent() {
    let err = run_source("7 % 0", "pct_zero_mod.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Run);
    assert!(
        err.diagnostic.message.contains("integer modulo by zero"),
        "the modulo-by-zero diagnostic (actual: {})",
        err.diagnostic.message
    );
}

/// Negative 10 (E0004 run class): modulo by zero through the alias —
/// behavioral equivalence on the error face too.
#[test]
fn neg_modulo_by_zero_alias() {
    let err = run_source("mod(7, 0)", "pct_zero_alias.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Run);
    assert!(
        err.diagnostic.message.contains("integer modulo by zero"),
        "the alias error face is identical (actual: {})",
        err.diagnostic.message
    );
}

/// Negative 11 (E0004 run class): the alias's arity floor (the infix
/// grammar cannot express it — the call face can).
#[test]
fn neg_alias_arity_floor() {
    let err = run_source("mod(1)", "pct_arity.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Run);
    assert!(
        err.diagnostic
            .message
            .contains("mod at least requires 2 arguments"),
        "the alias arity floor (actual: {})",
        err.diagnostic.message
    );
}

/// Negative 12 (E0004 run class): a float operand — the primary face
/// (Fold::Mod is integer-domain only).
#[test]
fn neg_float_operand_percent() {
    let err = run_source("7.5 % 2", "pct_float.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Run);
    assert!(
        err.diagnostic
            .message
            .contains("mod does not accept float operands"),
        "the float-operand diagnostic (actual: {})",
        err.diagnostic.message
    );
}

/// Negative 13 (E0004 run class): a float operand through the alias.
#[test]
fn neg_float_operand_alias() {
    let err = run_source("mod(7.5, 2)", "pct_float_alias.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Run);
    assert!(
        err.diagnostic
            .message
            .contains("mod does not accept float operands"),
        "the alias float diagnostic (actual: {})",
        err.diagnostic.message
    );
}

/// Negative 14 (E0004 run class): a bool operand — the name-aware
/// primary-face diagnostic (`% requires int`).
#[test]
fn neg_bool_operand_percent() {
    let err = run_source("true % 2", "pct_bool.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Run);
    assert!(
        err.diagnostic.message.contains("% requires int"),
        "the bool-operand diagnostic (actual: {})",
        err.diagnostic.message
    );
}

/// Negative 15 (E0004 run class): a string operand through the alias
/// (`mod requires int` — the alias-named twin of negative 14).
#[test]
fn neg_string_operand_alias() {
    let err = run_source("mod(\"a\", 2)", "pct_str_alias.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Run);
    assert!(
        err.diagnostic.message.contains("mod requires int"),
        "the alias string diagnostic (actual: {})",
        err.diagnostic.message
    );
}

/// Negative 16 (E0005 static typing class): a string operand through
/// the recovery-mode check (the TC_SIGS num-parameter discipline).
#[test]
fn neg_hm_static_type_string() {
    let report = check_source_recover("\"a\" % 2", "pct_type_str.ktf")
        .expect("recovery path should produce a report (not a hard error)");
    assert!(
        !report.diagnostics.is_empty(),
        "the static typing face must surface (actual: {:?})",
        report.diagnostics
    );
    assert!(
        report
            .diagnostics
            .iter()
            .any(|d| d.code == Some(DiagnosticCode(5))),
        "an E0005-class diagnostic must be present (actual: {:?})",
        report.diagnostics
    );
}

/// Negative 17 (E0005 static typing class): a bool operand through the
/// recovery-mode check.
#[test]
fn neg_hm_static_type_bool() {
    let report = check_source_recover("true % 2", "pct_type_bool.ktf")
        .expect("recovery path should produce a report (not a hard error)");
    assert!(
        report
            .diagnostics
            .iter()
            .any(|d| d.code == Some(DiagnosticCode(5))),
        "an E0005-class diagnostic must be present (actual: {:?})",
        report.diagnostics
    );
}

/// Negative 18 (E0006 capability class): an undeclared capability
/// consumption inside the operand (the capability gate is orthogonal
/// to the operator skin — the capability_tests caliber).
#[test]
fn neg_capability_class_e0006() {
    let err = run_source("read_int() % 2", "pct_cap.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Compile);
    assert_eq!(err.diagnostic.code, Some(DiagnosticCode(6)));
    assert!(
        err.rendered.contains("error[E0006]"),
        "the capability diagnostic (actual: {})",
        err.rendered
    );
}

/// Negative 19 (E0005 multi-error recovery class): the recovery-mode
/// check collects the static problems of two independent ill-typed
/// items (the multi-error pipeline unperturbed by the operator face).
#[test]
fn neg_multi_error_recovery_class_e0005() {
    let src = "fn a() { \"s\" % 2 }\nfn b() { true % 3 }\n1";
    let report = check_source_recover(src, "pct_recover.ktf")
        .expect("recovery path should produce a report (not a hard error)");
    assert!(
        report.diagnostics.len() >= 2,
        "both ill-typed items must be collected (actual: {:?})",
        report.diagnostics
    );
}

/// Negative 20 (E0014 export-face class): a multi-segment path operand
/// (the established namespace discipline — orthogonal to the operator
/// skin).
#[test]
fn neg_multi_segment_path_class_e0014() {
    let err = run_source("a::b % 2", "pct_path.ktf").unwrap_err();
    assert!(
        err.rendered.contains("E0014"),
        "the E0014 export-face diagnostic (actual: {})",
        err.rendered
    );
}

/// Negative 21 (E0001 read class): EOF inside a vector literal operand
/// (the literal-element expectation face).
#[test]
fn neg_vector_literal_operand_eof() {
    let e = read_err("[1 % ]", "pct_vec_eof.ktf");
    assert!(
        e.message.contains("expected an expression") || e.message.contains("got RBracket"),
        "the literal-element diagnostic (actual: {})",
        e.message
    );
}

/// Negative 22 (E0001 read class): EOF inside a closure body operand.
#[test]
fn neg_closure_body_operand_eof() {
    let e = read_err("|| { 7 % }", "pct_clo_eof.ktf");
    assert!(
        e.message.contains("expected an expression"),
        "the closure-body diagnostic (actual: {})",
        e.message
    );
}

/// Negative 23 (E0001 read class): EOF in a let-value operand.
#[test]
fn neg_let_value_operand_eof() {
    let e = read_err("let x = 7 %;", "pct_let_eof.ktf");
    assert!(
        !e.message.is_empty(),
        "a structure diagnostic must surface (actual: {})",
        e.message
    );
}

/// Negative 24 (E0022 unbound class): an unbound operand inside an
/// operator chain (the chain resolves left-to-right; the rhs name is
/// reported).
#[test]
fn neg_chain_unbound_operand() {
    let err = run_source("7 % 2 % x", "pct_chain.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Compile);
    assert!(
        err.diagnostic.message.contains("unbound reference: `x`"),
        "the chain rhs name is reported (actual: {})",
        err.diagnostic.message
    );
}

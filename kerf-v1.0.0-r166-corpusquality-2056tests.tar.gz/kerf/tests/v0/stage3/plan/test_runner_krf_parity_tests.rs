//! Build-system segment fourth cut parity tests (r87 / 157-b — TD-032
//! test-runner face acceptance vehicle).
//!
//! **Criterion**: case splitting + per-case execution orchestration + result
//! aggregation agree on both faces — the Rust seed oracle
//! (`driver::test_source` — the original orchestration implementation now in
//! a retired role) vs the .krf production face (`bootstrap/test_runner.krf`
//! run on the VM through the `bootstrap::test_runner` bridge — **the
//! production path is switched**; this parity is the switch guard).
//! End-to-end cases cascade the third cut on top (`.krf runner report +
//! ltest-report` vs `Rust oracle report + report_seed`) — both faces
//! byte-level identical across the full chain.
//!
//! Coverage (≥13 cases): zero-case protocol (empty source / prelude-only
//! source); single pass / single fail (detail runtime channel verbatim);
//! mixed recovery orchestration (a failure does not block the rest);
//! per-case prelude replay isolation (assign inside a case does not leak —
//! r8 convention corpus mirror); splitting of all kinds (define/require/
//! assign preludes vs expression cases — including a source order where a
//! case precedes the prelude); name truncation boundary (64/65 chars +
//! Unicode char domain — byte-domain truncation divergence is detectable);
//! runtime error detail; effect short circuit (stop at the first error
//! within a case); front-end error channel separation (Front pass-through —
//! same source as the oracle); real-corpus end to end (fib shape +
//! fail_demo shape — both faces across the full chain); full shape matrix
//! sweep (0-5 items × all prelude/case position combinations = 63 source
//! shapes); production liveness probe.

use kerf_driver::bootstrap::test::{report as krf_report, report_seed};
use kerf_driver::bootstrap::test_runner::{
    production_test_runner_is_bootstrap, run as krf_run, TestRunnerError,
};
use kerf_driver::{test_source, TestReport};

/// Deep two-face report parity assertion: the case sequence (index/name/
/// pass state/detail) and the counts all agree.
fn assert_reports_equal(oracle: &TestReport, krf: &TestReport, ctx: &str) {
    assert_eq!(
        oracle.cases.len(),
        krf.cases.len(),
        "{}: case count divergence",
        ctx
    );
    for (i, (o, k)) in oracle.cases.iter().zip(krf.cases.iter()).enumerate() {
        assert_eq!(
            o.index,
            k.index,
            "{}: item {} case order number divergence",
            ctx,
            i + 1
        );
        assert_eq!(
            o.name,
            k.name,
            "{}: item {} case name divergence",
            ctx,
            i + 1
        );
        assert_eq!(
            o.pass,
            k.pass,
            "{}: item {} case pass state divergence",
            ctx,
            i + 1
        );
        assert_eq!(
            o.detail,
            k.detail,
            "{}: item {} case detail divergence",
            ctx,
            i + 1
        );
    }
    assert_eq!(oracle.passed, krf.passed, "{}: pass count divergence", ctx);
    assert_eq!(
        oracle.failed, krf.failed,
        "{}: failed count divergence",
        ctx
    );
}

/// Full-chain end-to-end parity assertion: Rust oracle (`test_source`
/// report + `report_seed` rendering) vs .krf production face (`ltest-run`
/// report + `ltest-report` rendering) — the fourth-cut runner cascaded with
/// the third-cut renderer.
fn assert_end_to_end(source: &str, filename: &str) {
    let oracle = test_source(source, filename).expect("oracle(test_source)should succeed");
    let krf = krf_run(source, filename).expect(".krf runner should succeed");
    assert_reports_equal(&oracle, &krf, filename);
    let (rust_out, rust_code) = report_seed(&oracle);
    let (krf_out, krf_code) = krf_report(&krf).expect("test.krf render");
    assert_eq!(
        rust_out, krf_out,
        "{}: all chain report text divergence(runner + renderer level link parity)",
        filename
    );
    assert_eq!(
        rust_code, krf_code,
        "{}: all chain exit code divergence",
        filename
    );
}

// ---------------------------------------------------------------------------
// parity corpus (thirteen cases — split/orchestration/truncation/recovery/
// matrix/liveness/error channels)
// ---------------------------------------------------------------------------

/// Zero-case protocol (empty source + prelude-only source — cases empty + counts 0/0/0).
#[test]
fn parity_empty_and_prelude_only() {
    assert_end_to_end("", "empty.krf");
    assert_end_to_end("(define x 1)", "prelude-only.krf");
    let oracle = test_source("(define x 1)", "prelude-only2.krf").expect("oracle");
    assert!(oracle.cases.is_empty());
    assert_eq!(oracle.passed + oracle.failed, 0);
}

/// Single passing case (minimal main path — index 1 + name = shape rendering).
#[test]
fn parity_single_pass() {
    assert_end_to_end("(= 1 1)", "single-pass.krf");
    let oracle = test_source("(= 1 1)", "single-pass2.krf").expect("oracle");
    assert_eq!(oracle.cases.len(), 1);
    assert_eq!(oracle.cases[0].index, 1);
    assert!(oracle.cases[0].pass);
    assert!(oracle.cases[0].detail.is_empty());
}

/// Single failing case (detail runtime channel verbatim — the real shape of the assertion-#f detail).
#[test]
fn parity_single_fail_detail() {
    assert_end_to_end("(= 1 2)", "single-fail.krf");
    let oracle = test_source("(= 1 2)", "single-fail2.krf").expect("oracle");
    assert_eq!(oracle.cases.len(), 1);
    assert!(!oracle.cases[0].pass);
    // Verbatim r86 CLI baseline detail (same shape as fail_demo's first case)
    assert_eq!(
        oracle.cases[0].detail,
        "assertion return #f(expected non- #f value) -- evaluate result false"
    );
}

/// Mixed recovery orchestration (pass/fail/pass — a failure does not block the rest + indices contiguous in source order).
#[test]
fn parity_mixed_recovery() {
    let src = "(define (f x) x)\n(= 1 1)\n(= 1 2)\n(f 5)\n";
    assert_end_to_end(src, "mixed.krf");
    let oracle = test_source(src, "mixed2.krf").expect("oracle");
    assert_eq!(oracle.cases.len(), 3);
    assert_eq!(oracle.passed, 2);
    assert_eq!(oracle.failed, 1);
    assert_eq!(oracle.cases[2].index, 3);
    assert!(
        oracle.cases[2].pass,
        "recovery orchestration: failed case after#three case continue-run"
    );
}

/// Per-case prelude replay isolation (r8 convention corpus mirror — assign
/// inside a case does not leak into later cases: case 1 assigns inside an
/// IIFE + a failing assertion; case 2 still sees x=5).
#[test]
fn parity_prelude_replay_isolation() {
    let src = "(define x 5) ((fn () (do (assign x 6) (= 1 2)))) (= x 5)";
    assert_end_to_end(src, "isolation.krf");
    let oracle = test_source(src, "isolation2.krf").expect("oracle");
    assert_eq!(oracle.cases.len(), 2);
    assert_eq!(oracle.passed, 1);
    assert_eq!(oracle.failed, 1);
    assert!(
        oracle.cases[1].pass,
        "second case independent replay precondition(x=5) -- first case assign not leak"
    );
}

/// Splitting of all kinds (define/require/assign preludes vs expression
/// cases — r8 convention corpus mirror + fail_demo shape [source order with
/// a case before the prelude — prelude collection is independent of source
/// order; case indices follow case source order]).
#[test]
fn parity_split_all_kinds() {
    // require + define + assign, three preludes + two cases (x rebound via assign = 2)
    let src = "(define x 1) (assign x 2) (require io write) (= x 2)";
    assert_end_to_end(src, "split-kinds.krf");
    let oracle = test_source(src, "split-kinds2.krf").expect("oracle");
    assert_eq!(oracle.cases.len(), 1);
    assert!(oracle.cases[0].pass, "assign pre-replay after x=2");

    // fail_demo shape: a case precedes the define (prelude collection is position-independent)
    let src2 = "(= 1 2)\n(define (f x) x)\n(f 5)\n";
    assert_end_to_end(src2, "split-order.krf");
    let oracle2 = test_source(src2, "split-order2.krf").expect("oracle");
    assert_eq!(oracle2.cases.len(), 2);
    assert_eq!(oracle2.cases[0].index, 1);
    assert!(!oracle2.cases[0].pass);
    assert_eq!(oracle2.cases[1].index, 2);
    assert!(oracle2.cases[1].pass);
}

/// Name truncation boundary (ASCII 64/65 chars — no truncation/truncation +
/// Unicode char domain — byte-domain truncation would cut a UTF-8 sequence
/// and produce byte-level divergence, which this case can detect; literal
/// length controls rendered length — the wrapper shape
/// `(< (string-length "…") 1)` = 24 chars + literal length; imports are
/// transparently stripped by the driver layer and do not count as cases).
#[test]
fn parity_name_truncation_boundary() {
    // ASCII boundary: a 40-char literal renders exactly 64 (not truncated); 41 → 65 (truncated)
    let src = format!(
        "(import kerf-string)\n(< (string-length \"{}\") 1)\n(< (string-length \"{}\") 1)\n",
        "A".repeat(40),
        "A".repeat(41)
    );
    assert_end_to_end(&src, "trunc-ascii.krf");
    let oracle = test_source(&src, "trunc-ascii2.krf").expect("oracle");
    assert_eq!(oracle.cases.len(), 2);
    assert_eq!(
        oracle.cases[0].name.chars().count(),
        64,
        "64 character boundary: not truncation"
    );
    assert!(!oracle.cases[0].name.ends_with('…'));
    assert_eq!(
        oracle.cases[1].name.chars().count(),
        65,
        "65 character boundary: truncated to the first 64 + …(char plan 65)"
    );
    assert!(oracle.cases[1].name.ends_with('…'));

    // Unicode char domain: a 66-CJK-char literal (198 bytes) — truncation point at char 64
    let cn = "字".repeat(66);
    let usrc = format!("(import kerf-string)\n(< (string-length \"{}\") 0)\n", cn);
    assert_end_to_end(&usrc, "trunc-unicode.krf");
    let uoracle = test_source(&usrc, "trunc-unicode2.krf").expect("oracle");
    let ukrf = krf_run(&usrc, "trunc-unicode3.krf").expect("krf");
    assert_eq!(
        uoracle.cases[0].name, ukrf.cases[0].name,
        "Unicode truncation char domain dual-face consistent"
    );
    assert!(uoracle.cases[0].name.ends_with('…'));
    assert_eq!(uoracle.cases[0].name.chars().count(), 65);
}

/// Runtime error detail channel (not an assertion failure — nested VM error → first-line detail).
#[test]
fn parity_runtime_error_detail() {
    assert_end_to_end("(head 5)", "runtime-err.krf");
    let oracle = test_source("(head 5)", "runtime-err2.krf").expect("oracle");
    assert_eq!(oracle.cases.len(), 1);
    assert!(!oracle.cases[0].pass);
    assert!(
        !oracle.cases[0].detail.is_empty(),
        "runtime error detail non-empty"
    );
}

/// Effect short circuit (stop at the first error within a case — the `do`
/// sequence is wrapped in an IIFE [a top-level do would be spliced into
/// multiple items — r49 D59 splice semantics]: the first error [head int]
/// masks later errors [head str] and the final-value #f assertion —
/// `fail_test` escapes on first trigger; an intermediate #f in do does not
/// trigger [the assertion check is on the final value — layer 3]).
#[test]
fn parity_effect_short_circuit() {
    let src = "((fn () (do (head 5) (head \"x\") (= 1 2))))";
    assert_end_to_end(src, "short-circuit.krf");
    let oracle = test_source(src, "short-circuit2.krf").expect("oracle");
    assert_eq!(oracle.cases.len(), 1);
    assert!(!oracle.cases[0].pass);
    assert!(
        oracle.cases[0].detail.contains("head requires pair, got int"),
        "short-circuit: first wrong(head int)shadow subsequent(head str and last value #f assertion) -- actual {}",
        oracle.cases[0].detail
    );
}

/// Front-end error channel separation (real diagnostics pass through Front
/// — rendering same-source as the oracle; same-file-name reconciliation —
/// the diagnostic header contains the file name).
#[test]
fn parity_front_error_channel() {
    let oracle_err = test_source("(define x 1", "bad-front.krf").expect_err("oracle should Err");
    match krf_run("(define x 1", "bad-front.krf") {
        Err(TestRunnerError::Front(d)) => {
            assert_eq!(
                d.rendered, oracle_err.rendered,
                "pre-stage error render and oracle same source"
            );
        }
        Err(TestRunnerError::Internal(msg)) => {
            panic!("pre-stage error entered an internal channel:{}", msg);
        }
        Ok(_) => panic!("syntax error source not should succeed"),
    }
}

/// Real-corpus end to end (fib shape [recursion + multiple cases with mixed
/// outcomes] + fail_demo shape — both faces across the full chain: in-test
/// empirical proof of CLI `kerf test` output equivalence).
#[test]
fn parity_real_corpus_end_to_end() {
    let fib_src = "(define (fib n)\n  (if (< n 2)\n      n\n      (+ (fib (- n 1)) (fib (- n 2)))))\n(= (fib 10) 55)\n(= (fib 12) 144)\n(= (fib 10) 54)\n";
    assert_end_to_end(fib_src, "fib-like.krf");
    let oracle = test_source(fib_src, "fib-like2.krf").expect("oracle");
    assert_eq!(oracle.passed, 2);
    assert_eq!(oracle.failed, 1);

    let fail_src = "(= 1 2)\n(define (f x) x)\n(f 5)\n";
    assert_end_to_end(fail_src, "fail-demo.krf");
}

/// Full shape matrix sweep (0-5 items × every prelude/case position
/// combination = 63 source shapes — mechanical two-face reconciliation of
/// split positions × pass/fail combinations).
#[test]
fn parity_full_matrix_sweep() {
    for n in 0..=5usize {
        for mask in 0..(1usize << n) {
            let mut src = String::new();
            let mut case_idx = 0usize;
            for i in 0..n {
                if (mask >> i) & 1 == 0 {
                    // Prelude item (define — does not count as a case)
                    src.push_str(&format!("(define y{} {})\n", i, i + 1));
                } else {
                    // Case item: even case indices pass / odd fail
                    // (literal assertions — decoupled from prelude
                    // presence, so every combination compiles)
                    let form = if case_idx.is_multiple_of(2) {
                        "(= 1 1)"
                    } else {
                        "(= 1 2)"
                    };
                    src.push_str(form);
                    src.push('\n');
                    case_idx += 1;
                }
            }
            let ctx = format!("matrix n={} mask={}", n, mask);
            let oracle = test_source(&src, "matrix-oracle.krf").expect("oracle compile");
            let krf = krf_run(&src, "matrix-krf.krf").expect("krf run");
            assert_reports_equal(&oracle, &krf, &ctx);
            assert_eq!(oracle.cases.len(), case_idx, "{}: case count", ctx);
        }
    }
}

/// Production liveness probe (switch guard — empirical anchor that the krf-path orchestration happened more than zero times).
#[test]
fn production_test_runner_is_bootstrap_probe() {
    let r = krf_run("(= 1 1)", "liveness.krf").expect("production run");
    assert_eq!(r.cases.len(), 1);
    assert!(r.cases[0].pass);
    assert!(
        production_test_runner_is_bootstrap(),
        "krf path orchestration not occur(production switch guard failed)"
    );
}

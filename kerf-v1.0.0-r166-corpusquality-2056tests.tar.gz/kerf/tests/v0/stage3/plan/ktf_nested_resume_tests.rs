//! .ktf nested-block resume family tests — r133 / 203-c5 (the
//! nested-resume window: the r128 registered honest boundary cleared —
//! resume at nested-block statement/tail positions inside a handler arm
//! body; design single source = nested-resume-design.md v1.0).
//!
//! **Verification surfaces** (the target-face `resume(expr)` scope
//! extension — if-arm blocks / closure bodies / nested-handle arm bodies
//! thread the innermost enclosing arm's k binder — the S-expr lexical
//! scope's mirror; zero desugar at the expander/compiler layer, principle
//! 31):
//! (1) **run-face E2E** — the nested if-arm branch selection, the
//! closure-captured resume (k captured lexically, D4), the nested-handle
//! dual-k choreography (inner k2 + outer k in one arm body), and the
//! isoB VM settlement regression anchor (the non-tail call of a
//! k-capturing closure — the handler-boundary teardown on resume);
//! (2) **the r133 grammar settlement** — the family is dual-Reader
//! verified: seed vs mirror canonical Stx rendering byte-identical
//! (nested if arms, else-if chains, closures, nested handles, deep
//! let-then-resume), error faces message + Span byte-identical;
//! (3) **the nesting-equivalence bytecode gate** — the .ktf nested form
//! compiles byte-identically to the hand-written .krf idiom (skin
//! transparency: instruction order + constant pool + proto shapes +
//! global-reference face, shared symbol table);
//! (4) **cross-stage consumption** — the nested-resume program through
//! `check_source_recover` stays diagnostic-clean with real
//! instruction artifacts;
//! (5) **fail-closed negatives** — the positional domain-out discipline
//! (expression-position resume: argument / condition / let value / match
//! subject / match arm body / guard / perform args / protected position),
//! the scope domain-out (plain fn blocks, top level, closures outside
//! handler scopes, the D5 nested-handle protected expression), the D8
//! halt/pass arm-body-only words in nested blocks, and the form
//! discipline (missing parens / unclosed / zero args / two args /
//! missing terminator / unclosed brace / untyped closure param).
//!
//! **Same-window defect settlement (r133 / 203-c2 — isoB)**: the
//! closure-capture probes exposed a latent VM P1 (a resume issued from a
//! frame deeper than the arm body — e.g. a non-tail call of a
//! k-capturing closure — left the stale H-execution frame live; the
//! restored RET cascade re-entered the arm body at the trampoline's
//! ret_pc, clobbering the closure slot with the handle value — the
//! `uncallable value: int` face). Settled in kerf-vm (the
//! ContinuationValue.boundary teardown in the Call/TailCall continuation
//! arms); the isoB shape is the dedicated regression anchor here.
//!
//! Skin-dictionary basis: 20 §14 v1.25 (the D2 handle-mapping body-domain
//! note, r133); 02 §8.13.1a v7.18 (the Level 0 production update). Window
//! basis: the r128 domain-out registration (02 v7.13 resume_stmt scope
//! note + the seed/mirror parse_handler_block docs) + the M1 opening
//! precedent chain (r125-r132). Ratio: 8 positive : 24 negative = 1:3
//! (§9.4.3).

use kerf_driver::bootstrap::reader::read_source_for_bootstrap;
use kerf_driver::{check_source_recover, run_source};
use kerf_reader::read_source;
use kerf_syntax::{Stx, StxDatum, StxLiteral, SymbolTable};

// ---------------------------------------------------------------------------
// Value helpers
// ---------------------------------------------------------------------------

fn run_value(src: &str, filename: &str) -> String {
    let outcome = run_source(src, filename)
        .unwrap_or_else(|e| panic!("target face program {} execution failed:{}", filename, e));
    kerf_vm::render_value(&outcome.value, &outcome.heap)
}

// ---------------------------------------------------------------------------
// Dual-Reader parity helpers (the ktf_handle_multiarm_tests.rs caliber —
// canonical rendering with Span bytes; error parity with message + Span
// byte equality)
// ---------------------------------------------------------------------------

fn render_stx(s: &Stx, t: &SymbolTable) -> String {
    let mut out = String::new();
    render_stx_into(s, t, &mut out);
    out
}

fn render_stx_into(s: &Stx, t: &SymbolTable, out: &mut String) {
    match &s.datum {
        StxDatum::Symbol(sym) => {
            out.push_str(&format!(
                "(sym {} {}..{})",
                t.name(*sym),
                s.span.start,
                s.span.end
            ));
        }
        StxDatum::Literal(l) => match l {
            StxLiteral::Int(v) => {
                out.push_str(&format!("(int {} {}..{})", v, s.span.start, s.span.end));
            }
            StxLiteral::Float(f) => {
                out.push_str(&format!("(float {:?} {}..{})", f, s.span.start, s.span.end));
            }
            StxLiteral::Str(r) => {
                out.push_str(&format!("(str {:?} {}..{})", r, s.span.start, s.span.end));
            }
            StxLiteral::Bool(b) => {
                out.push_str(&format!("(bool {} {}..{})", b, s.span.start, s.span.end));
            }
            StxLiteral::Nil => {
                out.push_str(&format!("(unit {}..{})", s.span.start, s.span.end));
            }
        },
        StxDatum::List(items) => {
            out.push_str(&format!("(lst {}..{} [", s.span.start, s.span.end));
            for item in items.iter() {
                render_stx_into(item, t, out);
                out.push(' ');
            }
            out.push_str("])");
        }
        // r138 / 208-c — TD-002: vectors now reach both Readers (the
        // fourteenth skin mapping) — full canonical rendering
        StxDatum::Vector(items) => {
            out.push_str(&format!("(vec {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
    }
}

fn assert_grammar_parity(src: &str, what: &str) {
    let mut t1 = SymbolTable::new();
    let seed = read_source(src, 0, &mut t1)
        .unwrap_or_else(|e| panic!("[{}] seed syntax failed: {}", what, e.message));
    let mut t2 = SymbolTable::new();
    let mirror = read_source_for_bootstrap(src, 0, &mut t2)
        .unwrap_or_else(|e| panic!("[{}] mirror syntax failed:{}", what, e.message));
    assert_eq!(
        seed.len(),
        mirror.len(),
        "[{}] top-level item count mismatch (seed {} vs mirror {})",
        what,
        seed.len(),
        mirror.len()
    );
    for (i, (a, b)) in seed.iter().zip(mirror.iter()).enumerate() {
        assert_eq!(
            render_stx(a, &t1),
            render_stx(b, &t2),
            "[{}] top-level item #{} syntax tree mismatch (seed vs mirror canonical render)",
            what,
            i
        );
    }
}

fn assert_grammar_err_parity(src: &str, what: &str) -> String {
    let mut t1 = SymbolTable::new();
    let seed_err = match read_source(src, 0, &mut t1) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] seed should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    let mut t2 = SymbolTable::new();
    let mirror_err = match read_source_for_bootstrap(src, 0, &mut t2) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] mirror should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    assert_eq!(
        seed_err.message, mirror_err.message,
        "[{}] syntax error message mismatch (seed {:?} vs mirror {:?})",
        what, seed_err.message, mirror_err.message
    );
    assert_eq!(
        seed_err.span.start, mirror_err.span.start,
        "[{}] syntax error Span start mismatch (seed {} vs mirror {})",
        what, seed_err.span.start, mirror_err.span.start
    );
    assert_eq!(
        seed_err.span.end, mirror_err.span.end,
        "[{}] syntax error Span end mismatch (seed {} vs mirror {})",
        what, seed_err.span.end, mirror_err.span.end
    );
    seed_err.message
}

// ---------------------------------------------------------------------------
// Positives — run-face E2E + grammar settlement + nesting-equivalence +
// cross-stage consumption
// ---------------------------------------------------------------------------

/// Positive 1 / integration: the core nested if-arm E2E — both branches
/// carry resume (the head selects), through the production run chain
/// (the nested-block scope's debut beyond r128's top-level-only form).
#[test]
fn nested_if_arm_both_branches_e2e() {
    let v = run_value(
        "fn ask() { perform gift(10, 20); }\nfn pick() {\n    handle ask() {\n        gift(p, k) => { if head(p) > 5 { resume(100) } else { resume(200) } },\n    }\n}\npick()",
        "ifarm.ktf",
    );
    assert_eq!(
        v, "100",
        "nested if arm resume must produce 100(actual: {})",
        v
    );
}

/// Positive 3 / grammar settlement: dual-Reader canonical rendering
/// parity — the family's shapes (if-arm then/else, else-if chain,
/// closure body, nested handle with dual k, deep let-then-resume,
/// statement-position dead tail), byte-identical including the threaded
/// resume nodes and their Span bytes.
#[test]
fn nested_resume_dual_reader_canonical_parity() {
    assert_grammar_parity(
        "fn g() { handle (1) { gift(p, k) => { if (1 == 1) { resume(20); } } } }",
        "if arm statement position form",
    );
    assert_grammar_parity(
        "fn g() { handle (1) { gift(p, k) => { if (1 == 1) { resume(20) } else { resume(30) } } } }",
        "if arm dual branch tail position form",
    );
    assert_grammar_parity(
        "fn g() { handle (1) { gift(p, k) => { if (1 == 1) { resume(1) } else if (2 == 2) { resume(2) } else { resume(3) } } } }",
        "else-if chain form",
    );
    assert_grammar_parity(
        "fn g() { handle (1) { gift(p, k) => { let f = || (n: T) { resume(n) }; f(head(p)) } } }",
        "closure capture form",
    );
    assert_grammar_parity(
        "fn g() { handle (1) { gift(p, k) => { handle (2) { gift2(q, k2) => resume(1), } resume(2); } } }",
        "nested handle dual κ form",
    );
    assert_grammar_parity(
        "fn g() { handle (1) { gift(p, k) => { if (1 == 1) { let w = 5; resume(w) } else { resume(0) } } } }",
        "let after resume deep form",
    );
}

/// Positive 4 / integration: the closure-captured resume (D4) — k is
/// captured lexically by the closure, invoked at the arm-body tail; the
/// resume jumps from inside the closure body.
#[test]
fn closure_capture_resume_e2e() {
    let v = run_value(
        "fn ask() { perform gift(10, 20); }\nfn pick() {\n    handle ask() {\n        gift(p, k) => { let f = || (n: T) { resume(n) }; f(head(p)) },\n    }\n}\npick()",
        "closcap.ktf",
    );
    assert_eq!(
        v, "10",
        "closure capture resume must produce 10(actual: {})",
        v
    );
}

/// Positive 5 / integration: the nested-handle dual-k choreography — the
/// inner arm resumes with its own k2 (the inner handle's value drops as
/// a statement), then the outer arm body resumes with the outer k from a
/// non-tail statement position.
#[test]
fn nested_handle_dual_k_e2e() {
    let v = run_value(
        "fn ask() { perform gift(10, 20); }\nfn pick() {\n    handle ask() {\n        gift(p, k) => {\n            handle ask() { gift(p2, k2) => resume(head(p2) + 1), }\n            resume(head(p) + 100);\n        },\n    }\n}\npick()",
        "dualk.ktf",
    );
    assert_eq!(
        v, "110",
        "nested handle dual κ must produce 110(inner arm 11 deprecated + outer arm resume 110 -- actual: {})",
        v
    );
}

/// Positive 6 / the isoB VM settlement regression anchor (r133 / 203-c2):
/// a NON-TAIL call of a k-capturing closure — the closure body's resume
/// fires from a frame deeper than the arm body; the handler-boundary
/// teardown (ContinuationValue.boundary) discards the stale arm-body
/// frame so the restored RET cascade lands in the installing frame (the
/// pre-settlement face was `uncallable value: int` — the arm body re-entered
/// at the trampoline's ret_pc and clobbered the closure slot).
#[test]
fn non_tail_k_closure_call_regression() {
    let v = run_value(
        "fn ask() { perform gift(10, 20); }\nfn pick() {\n    handle ask() {\n        gift(p, k) => { let f = || (n: T) { resume(n); }; f(head(p)); },\n    }\n}\npick() + 1",
        "isob.ktf",
    );
    assert_eq!(
        v, "11",
        "non-tail position κ capture closure call must produce 11(VM boundary truncation clearing anchor -- actual: {})",
        v
    );
    // E6 r154 / 224-c6: the .krf mirror leg retired with the S-expr face
    // (the settlement is face-neutral — the VM is shared; the target
    // anchor above carries the regression).
}

/// Positive 7 / integration: the corpus single-face baseline anchor
/// (r153 / 223-c: the .krf corpus face retired — s-expr-removal-plan §4
/// Batch D; the cross-grammar pair leg retired with it, the equivalence
/// evidence archived in RELEASE r133-r152) — effect_nested_resume.ktf
/// (consumed via include_str! — the corpus-integrity gate, any corpus
/// edit that breaks the chain fails here) yields 540 through the sole
/// production run chain.
#[test]
fn nested_resume_corpus_single_face_baseline_anchor() {
    const CORPUS_KTF: &str = include_str!("../../../../examples/usage/effect_nested_resume.ktf");
    let ktf = run_value(CORPUS_KTF, "effect_nested_resume.ktf");
    assert_eq!(
        ktf, "540",
        "corpus baseline value: r1 100 + r2 10 + r3 110 + r4 300 + r5 20 = 540(actual: {})",
        ktf
    );
}

/// Positive 8 / cross-stage: the nested-resume program through
/// `check_source_recover` stays diagnostic-clean with real
/// instruction artifacts (the HM/typecheck face consumes the threaded
/// resume CoreExpr without friction).
#[test]
fn nested_resume_check_cross_stage_clean() {
    let report = check_source_recover(
        "fn ask() { perform gift(10, 20); }\nfn pick() {\n    handle ask() {\n        gift(p, k) => { if head(p) > 5 { resume(100) } else { resume(200) } },\n    }\n}\npick()",
        "nested.ktf",
    )
    .expect("recovery mode check does not short-circuit");
    assert!(
        report.diagnostics.is_empty(),
        "nested resume program check face must have zero diagnostics (actual: {:?})",
        report.diagnostics
    );
    assert!(
        report.proto_count + report.const_count > 0,
        "nested resume program must have a real compile artifact(actual: proto {} + const {})",
        report.proto_count,
        report.const_count
    );
}

// ---------------------------------------------------------------------------
// Negatives — reader-level dual-Reader parity (message + Span bytes)
// ---------------------------------------------------------------------------

/// Negative 1 (D6 — expression position): resume as a call argument
/// inside the arm body.
#[test]
fn neg_expr_position_resume_argument() {
    let m = assert_grammar_err_parity(
        "fn g() { handle (1) { gift(p, k) => { head(resume(1)); } } }",
        "argument position resume(D6 out of domain)",
    );
    assert!(
        m.contains("KwResume") || m.contains("expected an expression"),
        "diagnostic must name KwResume/expected an expression (actual: {})",
        m
    );
}

/// Negative 2 (D6): resume in an if-condition inside the arm body.
#[test]
fn neg_expr_position_resume_condition() {
    assert_grammar_err_parity(
        "fn g() { handle (1) { gift(p, k) => { if resume(1) > 2 { 3; } } } }",
        "condition position resume(D6 out of domain)",
    );
}

/// Negative 3 (D6): resume in a let-value inside the arm body.
#[test]
fn neg_expr_position_resume_let_value() {
    assert_grammar_err_parity(
        "fn g() { handle (1) { gift(p, k) => { let w = resume(1); } } }",
        "let value position resume(D6 out of domain)",
    );
}

/// Negative 4 (D6): resume as the match subject inside the arm body.
#[test]
fn neg_expr_position_resume_match_subject() {
    assert_grammar_err_parity(
        "fn g() { handle (1) { gift(p, k) => { match resume(1) { 1 => 2, _ => 3, } } } }",
        "match main problem position resume(D6 out of domain)",
    );
}

/// Negative 5 (D6): resume as a match arm body (an expression position).
#[test]
fn neg_expr_position_resume_match_arm_body() {
    assert_grammar_err_parity(
        "fn g() { handle (1) { gift(p, k) => { match 1 { 1 => resume(2), _ => 3, } } } }",
        "match arm body position resume(D6 out of domain)",
    );
}

/// Negative 6 (D6): resume in a match guard.
#[test]
fn neg_expr_position_resume_match_guard() {
    assert_grammar_err_parity(
        "fn g() { handle (1) { gift(p, k) => { match 1 { n if resume(n) > 2 => 3, _ => 4, } } } }",
        "match guard position resume(D6 out of domain)",
    );
}

/// Negative 7 (D6): resume in perform arguments inside the arm body.
#[test]
fn neg_expr_position_resume_perform_args() {
    assert_grammar_err_parity(
        "fn g() { handle (1) { gift(p, k) => { perform gift(resume(1)); } } }",
        "perform argument position resume(D6 out of domain)",
    );
}

/// Negative 8 (D6 — protected position): resume in the handle's own
/// protected expression.
#[test]
fn neg_protected_position_resume_direct() {
    assert_grammar_err_parity(
        "fn g() { handle resume(1) { gift(p, k) => 2, } }",
        "guarded form position resume(D6 out of domain)",
    );
}

/// Negative 9 (scope — plain fn block, no handler scope): the
/// pre-existing fail-closed path (r128's P3 guard).
#[test]
fn neg_plain_fn_block_resume() {
    let m = assert_grammar_err_parity(
        "fn f() { resume(1); }\nf()",
        "plain pass fn inside a block resume(no handler scope)",
    );
    assert!(
        m.contains("KwResume") || m.contains("expected an expression"),
        "diagnostic must name KwResume/expected an expression (actual: {})",
        m
    );
}

/// Negative 10 (scope): resume at top level.
#[test]
fn neg_top_level_resume() {
    assert_grammar_err_parity("resume(1);", "top level resume(no handler scope)");
}

/// Negative 11 (scope): resume inside a closure body OUTSIDE any handler
/// scope (a plain fn's closure).
#[test]
fn neg_closure_outside_handler_resume() {
    assert_grammar_err_parity(
        "fn f() { let g = || (n: T) { resume(n); }; g(1); }\nf()",
        "handler out of domain closure inner resume",
    );
}

/// Negative 12 (scope — nested if arm inside a plain fn, no handler).
#[test]
fn neg_nested_if_outside_handler_resume() {
    assert_grammar_err_parity(
        "fn f() { if (1 == 1) { resume(20); } }\nf()",
        "handler out of domain nested if inside arm resume",
    );
}

/// Negative 13 (D5 — the nested handle's protected expression): an
/// if-arm resume inside a nested handle's protected expression (within
/// an outer handler arm body) stays out-of-domain — the bounded-threading
/// honest boundary.
#[test]
fn neg_nested_handle_protected_if_arm_resume() {
    assert_grammar_err_parity(
        "fn g() { handle (1) { gift(p, k) => { handle (if (1 == 1) { resume(20) } else { 2 }) { gift2(q, k2) => 3, } } } }",
        "nested handle guarded form if inside arm resume(D5 out of domain)",
    );
}

/// Negative 14 (D5): the else-branch variant of the same boundary.
#[test]
fn neg_nested_handle_protected_else_resume() {
    assert_grammar_err_parity(
        "fn g() { handle (1) { gift(p, k) => { handle (if (1 == 1) { 2 } else { resume(20) }) { gift2(q, k2) => 3, } } } }",
        "nested handle guarded form else inside arm resume(D5 out of domain)",
    );
}

/// Negative 15 (D8 — arm-body-only words): halt inside a nested if-arm
/// block.
#[test]
fn neg_halt_in_nested_block() {
    assert_grammar_err_parity(
        "fn g() { handle (1) { gift(p, k) => { if (1 == 1) { halt(1); } } } }",
        "inside nested block halt(D8 arm body direct positional form preserved)",
    );
}

/// Negative 16 (D8): bare halt inside a nested block.
#[test]
fn neg_bare_halt_in_nested_block() {
    assert_grammar_err_parity(
        "fn g() { handle (1) { gift(p, k) => { if (1 == 1) { halt; } } } }",
        "inside nested block bare halt(D8 arm body direct positional form preserved)",
    );
}

/// Negative 17 (D8): pass inside a nested block.
#[test]
fn neg_pass_in_nested_block() {
    assert_grammar_err_parity(
        "fn g() { handle (1) { gift(p, k) => { if (1 == 1) { pass; } } } }",
        "inside nested block pass(D8 arm body direct positional form preserved)",
    );
}

/// Negative 18 (form discipline): resume without the mandatory
/// parenthesized argument, inside a nested if arm.
#[test]
fn neg_resume_without_parens_nested() {
    assert_grammar_err_parity(
        "fn g() { handle (1) { gift(p, k) => { if (1 == 1) { resume 5; } } } }",
        "inside nested arm resume no bracket form",
    );
}

/// Negative 19 (form discipline): an unclosed resume call inside a
/// nested if arm.
#[test]
fn neg_resume_unclosed_paren_nested() {
    assert_grammar_err_parity(
        "fn g() { handle (1) { gift(p, k) => { if (1 == 1) { resume(5; } } } }",
        "inside nested arm resume unclosed parentheses",
    );
}

/// Negative 20 (form discipline): zero-argument resume inside a nested
/// if arm.
#[test]
fn neg_resume_zero_args_nested() {
    assert_grammar_err_parity(
        "fn g() { handle (1) { gift(p, k) => { if (1 == 1) { resume(); } } } }",
        "inside nested arm resume zero arguments form",
    );
}

/// Negative 21 (form discipline): two-argument resume inside a nested if
/// arm.
#[test]
fn neg_resume_two_args_nested() {
    assert_grammar_err_parity(
        "fn g() { handle (1) { gift(p, k) => { if (1 == 1) { resume(1, 2); } } } }",
        "inside nested arm resume binary reference form",
    );
}

/// Negative 22 (termination discipline): a nested-arm resume statement
/// missing its `;` / `}` terminator.
#[test]
fn neg_resume_stmt_missing_terminator_nested() {
    assert_grammar_err_parity(
        "fn g() { handle (1) { gift(p, k) => { if (1 == 1) { resume(1) 5 } } } }",
        "inside nested arm resume form followed by missing; or }",
    );
}

/// Negative 23 (structure): an unclosed nested if-arm brace inside the
/// handler body block.
#[test]
fn neg_nested_if_unclosed_brace() {
    assert_grammar_err_parity(
        "fn g() { handle (1) { gift(p, k) => { if (1 == 1) { resume(1) } } }",
        "nested if arm unclosed",
    );
}

/// Negative 24 (closure param discipline): the k-capturing closure with
/// an untyped parameter (the typed-params discipline — `|| (n) { ... }`
/// without the annotation).
#[test]
fn neg_closure_param_type_missing() {
    assert_grammar_err_parity(
        "fn g() { handle (1) { gift(p, k) => { let f = || (n) { resume(n); }; 1 } } }",
        "closure formal parameter missing type annotation",
    );
}

//! .ktf handle expression-position tests — r143 / 213-c (the
//! handle-expr-position window: the CLI dual-entry expressive-parity
//! fifth settlement after r125/r130/r131/r132).
//!
//! **Window basis**: handle-multi-arm-design.md §7's registered
//! domain-out row — "target-face handle in expression position"
//! (parse_primary never dispatched KwHandle; the S-expr face's handle is
//! an expression valid in every expression context, the target face
//! rejected E0001 fail-closed). Tension probes (213-a): P1 define-value
//! ⇒ 100 / P3 argument ⇒ 101 / P7 if-condition ⇒ 11 on the S-expr face
//! vs P2/P8 E0001 on the target face — the parity gap cleared by the
//! primary-position dispatch (the r110 expression-position if / r121
//! match value-form precedents, isomorphic dispatch — the third
//! positional-skin family member). Design single source:
//! handle-expr-position-design.md v1.0 (D1-D8).
//!
//! **Verification surfaces**:
//! (1) **run-face E2E** — the five positional forms (let-value /
//! function-argument / if-condition / nested-protected / group) each
//! produce the S-expr face's semantics (100 / 101 / 11 / 100 / 15 — the
//! probe anchors formalized);
//! (2) **cross-face value parity** — the five-form .ktf program and its
//! .krf mirror produce the same value (327 — the corpus-pair anchor),
//! plus the statement-position zero-regression re-anchors (multiarm 217
//! / nested-resume 540);
//! (3) **dual-Reader canonical parity** — seed vs mirror Stx canonical
//! rendering byte-identical on the five forms (the r132 grammar
//! settlement's caliber);
//! (4) **cross-stage consumption** — the expression-position program
//! through `check_source_recover` stays diagnostic-clean with
//! real compile artifacts;
//! (5) **fail-closed negatives** — the reader-level structure discipline
//! in expression position (block-protected domain-out D5 / zero arms /
//! duplicate tags / non-two binders / missing arms brace / dangling
//! handle / protected-position halt / protected-position pass), the
//! positional-domain maintenance battery (handler-body face / statement
//! zero-arm / resume outside handler / resume inside nested protected /
//! halt-pass statement-block positions — all pre-existing fail-closed
//! faces unchanged), and the cross-stage semantic negatives (E0006
//! capability / E0022 unbound / err_effect_unhandled code 7 / check-face
//! condition-bool detection / resume arity / deep-nesting combination /
//! statement-face negative re-anchor / dual-Reader error parity).
//!
//! Skin-dictionary basis: 20 §14 v1.26 D2 note (the handle mapping's
//! position-domain extension); 02 §8.13.1a v7.19 (the primary-position
//! handle production note — statement and expression positions share
//! one shape). Ratio: 8 positive : 24 negative = 1:3 (§9.4.3).

use kerf_driver::bootstrap::reader::read_source_for_bootstrap;
use kerf_driver::{check_source_recover, run_source};
use kerf_reader::read_source;
use kerf_syntax::{Stx, StxDatum, StxLiteral, SymbolTable};

// ---------------------------------------------------------------------------
// Value helpers (the ktf_handle_multiarm_tests.rs caliber)
// ---------------------------------------------------------------------------

fn run_value(src: &str, filename: &str) -> String {
    let outcome = run_source(src, filename)
        .unwrap_or_else(|e| panic!("target face program {} execution failed:{}", filename, e));
    kerf_vm::render_value(&outcome.value, &outcome.heap)
}

// ---------------------------------------------------------------------------
// Dual-Reader parity helpers (canonical rendering with Span bytes)
// ---------------------------------------------------------------------------

fn render_stx(s: &Stx, t: &SymbolTable) -> String {
    let mut out = String::new();
    render_stx_into(s, t, &mut out);
    out
}

fn render_stx_into(s: &Stx, t: &SymbolTable, out: &mut String) {
    match &s.datum {
        StxDatum::Symbol(sym) => {
            out.push_str(&format!(
                "(sym {} {}..{})",
                t.name(*sym),
                s.span.start,
                s.span.end
            ));
        }
        StxDatum::Literal(l) => match l {
            StxLiteral::Int(v) => {
                out.push_str(&format!("(int {} {}..{})", v, s.span.start, s.span.end));
            }
            StxLiteral::Float(f) => {
                out.push_str(&format!("(float {:?} {}..{})", f, s.span.start, s.span.end));
            }
            StxLiteral::Str(r) => {
                out.push_str(&format!("(str {:?} {}..{})", r, s.span.start, s.span.end));
            }
            StxLiteral::Bool(b) => {
                out.push_str(&format!("(bool {} {}..{})", b, s.span.start, s.span.end));
            }
            StxLiteral::Nil => {
                out.push_str(&format!("(unit {}..{})", s.span.start, s.span.end));
            }
        },
        StxDatum::List(items) => {
            out.push_str(&format!("(lst {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
        StxDatum::Vector(items) => {
            out.push_str(&format!("(vec {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
    }
}

/// Grammar parity assertion: both Readers' canonical renderings are
/// byte-identical (the expression-position dispatch is
/// seed/mirror isomorphic by construction — D3's two-sided minimal
/// change).
fn assert_grammar_parity(src: &str, what: &str) {
    let mut t1 = SymbolTable::new();
    let seed = read_source(src, 0, &mut t1)
        .unwrap_or_else(|e| panic!("[{}] seed syntax failed: {}", what, e.message));
    let mut t2 = SymbolTable::new();
    let mirror = read_source_for_bootstrap(src, 0, &mut t2)
        .unwrap_or_else(|e| panic!("[{}] mirror syntax failed:{}", what, e.message));
    assert_eq!(
        seed.len(),
        mirror.len(),
        "[{}] top-level item count mismatch (seed {} vs mirror {})",
        what,
        seed.len(),
        mirror.len()
    );
    for (i, (a, b)) in seed.iter().zip(mirror.iter()).enumerate() {
        assert_eq!(
            render_stx(a, &t1),
            render_stx(b, &t2),
            "[{}] top-level item #{} syntax tree mismatch (seed vs mirror canonical render)",
            what,
            i
        );
    }
}

/// Grammar-error parity assertion: message + Span byte-level equality.
fn assert_grammar_err_parity(src: &str, what: &str) -> String {
    let mut t1 = SymbolTable::new();
    let seed_err = match read_source(src, 0, &mut t1) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] seed should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    let mut t2 = SymbolTable::new();
    let mirror_err = match read_source_for_bootstrap(src, 0, &mut t2) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] mirror should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    assert_eq!(
        seed_err.message, mirror_err.message,
        "[{}] syntax error message mismatch (seed {:?} vs mirror {:?})",
        what, seed_err.message, mirror_err.message
    );
    assert_eq!(
        seed_err.span.start, mirror_err.span.start,
        "[{}] syntax error Span start mismatch (seed {} vs mirror {})",
        what, seed_err.span.start, mirror_err.span.start
    );
    assert_eq!(
        seed_err.span.end, mirror_err.span.end,
        "[{}] syntax error Span end mismatch (seed {} vs mirror {})",
        what, seed_err.span.end, mirror_err.span.end
    );
    seed_err.message.clone()
}

/// The five positional forms in one program (the corpus-pair shape —
/// r1..r5 = 100 + 101 + 11 + 100 + 15 = 327).
const FIVE_FORMS_KTF: &str = "fn ask() { perform gift(10, 20); }\nfn f(x: i64) { x + 1 }\nfn r1() {\n    let r = handle ask() { gift(p, k) => resume(100) };\n    r\n}\nfn r2() { f(handle ask() { gift(p, k) => resume(100) }) }\nfn r3() { if handle ask() { gift(p, k) => resume(true) } { 11 } else { 22 } }\nfn r4() {\n    let r = handle (handle ask() { gift(p, k) => resume(100) }) { other(q, k2) => resume(7) };\n    r\n}\nfn ask_b() { perform giftB(7, 8); }\nfn r5() {\n    let r = handle ask_b() { giftA(p, k) => resume(1), giftB(q, k2) => resume(tail(q) + head(q)) };\n    r\n}\nr1() + r2() + r3() + r4() + r5()";

// ---------------------------------------------------------------------------
// Positives — the five positional forms + cross-face parity +
// dual-Reader parity + cross-stage consumption (8 = D7)
// ---------------------------------------------------------------------------

/// Positive 1: let-value position — the handle's value bound to a local
/// (the P9 probe formalized; the S-expr P1 define-value mirror ⇒ 100).
#[test]
fn pos_let_value_e2e() {
    let v = run_value(
        "fn ask() { perform gift(10, 20); }\nfn run() {\n    let r = handle ask() { gift(p, k) => resume(100) };\n    r\n}\nrun()",
        "letval.ktf",
    );
    assert_eq!(
        v, "100",
        "let-value position handle must produce the resumed value(actual: {})",
        v
    );
}

/// Positive 2: function-argument position — the handle's value flows
/// through the call (the P10 probe; the S-expr P3 mirror ⇒ 101).
#[test]
fn pos_argument_position_e2e() {
    let v = run_value(
        "fn ask() { perform gift(10, 20); }\nfn f(x: i64) { x + 1 }\nf(handle ask() { gift(p, k) => resume(100) })",
        "argpos.ktf",
    );
    assert_eq!(
        v, "101",
        "argument position handle must feed the call(actual: {})",
        v
    );
}

/// Positive 3: if-condition position — a bool resume selects the
/// then-arm (the P11 probe; the S-expr P7 mirror ⇒ 11).
#[test]
fn pos_if_condition_position_e2e() {
    let v = run_value(
        "fn ask() { perform gift(10, 20); }\nif handle ask() { gift(p, k) => resume(true) } { 11 } else { 22 }",
        "ifcond.ktf",
    );
    assert_eq!(
        v, "11",
        "if-condition position handle must select the then-arm(actual: {})",
        v
    );
}

/// Positive 4: nested-protected position — the inner handle is the outer
/// handle's protected expression; the outer arm never fires (the inner
/// resume completes, the outer sees a plain value — direct
/// fall-through; the P12 probe).
#[test]
fn pos_nested_protected_e2e() {
    let v = run_value(
        "fn ask() { perform gift(10, 20); }\nfn run() {\n    let r = handle (handle ask() { gift(p, k) => resume(100) }) { other(q, k2) => resume(7) };\n    r\n}\nrun()",
        "nestedprot.ktf",
    );
    assert_eq!(
        v, "100",
        "nested-protected position must fall through the outer arm(actual: {})",
        v
    );
}

/// Positive 5: group position — >= 2 arms in expression position compile
/// to the handle-group core form (r136's group-install; the P13 probe
/// ⇒ 15 = 7 + 8).
#[test]
fn pos_group_expression_e2e() {
    let v = run_value(
        "fn ask_b() { perform giftB(7, 8); }\nfn run() {\n    let r = handle ask_b() { giftA(p, k) => resume(1), giftB(q, k2) => resume(tail(q) + head(q)) };\n    r\n}\nrun()",
        "grouppos.ktf",
    );
    assert_eq!(
        v, "15",
        "group position handle must resume with the payload sum(actual: {})",
        v
    );
}

/// Positive 6 / cross-face value parity: the five-form program on both
/// faces produces the same value (327 — the corpus-pair anchor), plus
/// the statement-position zero-regression re-anchors (the multiarm 217
/// and nested-resume 540 corpus values unchanged through this window's
/// primary-position dispatch).
#[test]
fn pos_cross_face_value_parity() {
    // E6 r154 / 224-c6: the .krf twin leg retired with the S-expr face;
    // the five-form value anchor pins on the target side.
    let ktf = run_value(FIVE_FORMS_KTF, "five.ktf");
    assert_eq!(ktf, "327", "five-form anchor 327(actual: {})", ktf);
    // Statement-position zero regression (the corpus family re-anchors —
    // the dispatch must not perturb the statement face's product).
    let ma = run_value(
        include_str!("../../../../examples/usage/effect_multiarm.ktf"),
        "effect_multiarm.ktf",
    );
    assert_eq!(ma, "217", "multiarm corpus anchor 217(actual: {})", ma);
    let nr = run_value(
        include_str!("../../../../examples/usage/effect_nested_resume.ktf"),
        "effect_nested_resume.ktf",
    );
    assert_eq!(nr, "540", "nested-resume corpus anchor 540(actual: {})", nr);
}

/// Positive 7 / dual-Reader canonical parity: the five-form program's
/// Stx trees are seed/mirror byte-identical (the r132 grammar
/// settlement caliber — D3's two-sided minimal change is isomorphic by
/// construction).
#[test]
fn pos_dual_reader_canonical_parity() {
    assert_grammar_parity(FIVE_FORMS_KTF, "five-form expression-position family");
}

/// Positive 8 / cross-stage consumption: the expression-position program
/// through `check_source_recover` stays diagnostic-clean with
/// real compile artifacts (the HM/typecheck face consumes the generated
/// handle CoreExpr in expression context without friction).
#[test]
fn pos_check_cross_stage_clean() {
    let report = check_source_recover(FIVE_FORMS_KTF, "five.ktf")
        .expect("recovery mode check does not short-circuit");
    assert!(
        report.diagnostics.is_empty(),
        "expression-position program check face must have zero diagnostics (actual: {:?})",
        report.diagnostics
    );
    assert!(
        report.proto_count + report.const_count > 0,
        "expression-position program must have a real compile artifact(actual: proto {} + const {})",
        report.proto_count,
        report.const_count
    );
}

// ---------------------------------------------------------------------------
// Negatives — reader structure discipline in expression position (N01-N08)
// ---------------------------------------------------------------------------

/// Negative 1 (D5 — the block-protected domain-out): `handle { ... }` in
/// expression position — the protected expression must be an expression,
/// a block form fails closed (the statement position's own law, extended
/// isomorphically; the P2/P8 probe face retained).
#[test]
fn neg_block_protected_domain_out() {
    let m = assert_grammar_err_parity(
        "fn run() {\n    let r = handle { ask(); } { gift(p, k) => resume(100) };\n    r\n}\nrun()",
        "block-protected domain-out",
    );
    assert!(
        m.contains("expected an expression"),
        "block-protected must fail with the expression diagnostic(actual: {})",
        m
    );
}

/// Negative 2: zero arms in expression position (the D8 discipline —
/// `handle e { }` fails closed wherever it sits).
#[test]
fn neg_zero_arms_expr_position() {
    let m = assert_grammar_err_parity(
        "fn run() {\n    let r = handle ask() { };\n    r\n}\nrun()",
        "zero arms expression position",
    );
    assert!(
        m.contains("handle needs at least one arm"),
        "zero arms must fail with the dedicated diagnostic(actual: {})",
        m
    );
}

/// Negative 3: duplicate tags in expression position (the D6
/// fail-closed — the duplicate occurrence's own Span).
#[test]
fn neg_duplicate_tags_expr_position() {
    let m = assert_grammar_err_parity(
        "fn run() {\n    let r = handle ask() { gift(p, k) => resume(1), gift(q, k2) => resume(2) };\n    r\n}\nrun()",
        "duplicate tags expression position",
    );
    assert!(
        m.contains("duplicate"),
        "duplicate tags must fail with the D6 diagnostic(actual: {})",
        m
    );
}

/// Negative 4: non-two binder in expression position (the two-element
/// (payload, resume) discipline).
#[test]
fn neg_binder_not_two_expr_position() {
    let m = assert_grammar_err_parity(
        "fn run() {\n    let r = handle ask() { gift(p) => resume(1) };\n    r\n}\nrun()",
        "binder not two expression position",
    );
    assert!(
        m.contains("two-element"),
        "binder discipline must fail with the dedicated diagnostic(actual: {})",
        m
    );
}

/// Negative 5: missing arms brace — the expression-position handle
/// without the arms block (the deferred `{` expectation).
#[test]
fn neg_missing_arms_brace_expr_position() {
    let m = assert_grammar_err_parity(
        "fn run() {\n    let r = handle ask();\n    r\n}\nrun()",
        "missing arms brace expression position",
    );
    assert!(
        m.contains("{"),
        "missing arms brace must fail with the brace expectation(actual: {})",
        m
    );
}

/// Negative 6: dangling handle keyword (eof right after — the primary
/// dispatch fires and parse_handle's own expectation renders).
#[test]
fn neg_dangling_handle_keyword() {
    let m = assert_grammar_err_parity("fn run() {\n    let r = handle;", "dangling handle keyword");
    assert!(
        m.contains("expected"),
        "dangling handle must fail closed(actual: {})",
        m
    );
}

/// Negative 7: halt in the protected-expression position — `halt` is an
/// arm-body form only (the r132 twelfth family's own law; the
/// expression-position window does not widen it).
#[test]
fn neg_protected_position_halt() {
    let m = assert_grammar_err_parity(
        "fn run() {\n    let r = handle halt(42) { gift(p, k) => resume(1) };\n    r\n}\nrun()",
        "protected-position halt",
    );
    assert!(
        m.contains("expected an expression") && m.contains("KwHalt"),
        "protected-position halt must fail with the expression diagnostic(actual: {})",
        m
    );
}

/// Negative 8: pass in the protected-expression position (same law —
/// arm-body form only).
#[test]
fn neg_protected_position_pass() {
    let m = assert_grammar_err_parity(
        "fn run() {\n    let r = handle pass { gift(p, k) => resume(1) };\n    r\n}\nrun()",
        "protected-position pass",
    );
    assert!(
        m.contains("expected an expression") && m.contains("KwPass"),
        "protected-position pass must fail with the expression diagnostic(actual: {})",
        m
    );
}

// ---------------------------------------------------------------------------
// Negatives — positional-domain maintenance battery (N09-N16: the
// pre-existing fail-closed faces unchanged through this window)
// ---------------------------------------------------------------------------

/// Negative 9: the statement-position handler-body face is unchanged
/// (the r132 arm-body form diagnostic — the expression-position dispatch
/// must not perturb the statement face's error surface).
#[test]
fn neg_statement_handler_body_face_maintained() {
    let m = assert_grammar_err_parity(
        "fn ask() { perform gift(10, 20); }\nfn run() {\n    handle ask() { gift(p, k) => 5 };\n}\nrun()",
        "statement handler-body face",
    );
    assert!(
        m.contains("expected handler body"),
        "statement handler-body face must be maintained(actual: {})",
        m
    );
}

/// Negative 10: the statement-position zero-arm face is unchanged.
#[test]
fn neg_statement_zero_arm_maintained() {
    let m = assert_grammar_err_parity(
        "fn ask() { perform gift(10, 20); }\nfn run() {\n    handle ask() { };\n}\nrun()",
        "statement zero-arm face",
    );
    assert!(
        m.contains("handle needs at least one arm"),
        "statement zero-arm face must be maintained(actual: {})",
        m
    );
}

/// Negative 11: resume outside any handler — the r133 scope discipline
/// (a plain fn block sees no handler scope; the KwResume
/// expected-an-expression face retained).
#[test]
fn neg_resume_outside_handler_maintained() {
    let err = run_source("fn f() { resume(1); }\nf()", "bad.ktf")
        .expect_err("plain block resume must read error");
    assert!(
        err.to_string().contains("KwResume") || err.to_string().contains("expected an expression"),
        "resume outside handler must fail closed(actual: {})",
        err
    );
}

/// Negative 12: resume inside a nested handle's protected expression —
/// the r133 D5 domain (the protected expression's parse clears the
/// handler scope; resume there fails closed — maintained through the
/// expression-position window).
#[test]
fn neg_nested_protected_resume_fail_closed() {
    let m = assert_grammar_err_parity(
        "fn run() {\n    let r = handle (handle (resume(1)) { gift(p, k) => resume(2) }) { gift(q, k2) => resume(3) };\n    r\n}\nrun()",
        "nested-protected resume",
    );
    assert!(
        m.contains("KwResume") || m.contains("expected an expression"),
        "nested-protected resume must fail closed(actual: {})",
        m
    );
}

/// Negative 13: halt at a handler-arm block's statement position — the
/// r132 halt form lives in arm bodies only (`halt(v)` as a standalone
/// block statement fails closed; the P4 probe face).
#[test]
fn neg_halt_statement_block_maintained() {
    let m = assert_grammar_err_parity(
        "fn ask() { perform gift(10, 20); }\nfn run() {\n    handle ask() { gift(p, k) => { let x = halt(5); resume(100) } };\n}\nrun()",
        "halt statement-block position",
    );
    assert!(
        m.contains("KwHalt") || m.contains("expected an expression"),
        "halt statement-block position must fail closed(actual: {})",
        m
    );
}

/// Negative 14: pass at a handler-arm block's statement position (same
/// law — arm-body keyword form only, not a block statement).
#[test]
fn neg_pass_statement_block_maintained() {
    let m = assert_grammar_err_parity(
        "fn ask() { perform gift(10, 20); }\nfn run() {\n    handle ask() { gift(p, k) => { pass; resume(100) } };\n}\nrun()",
        "pass statement-block position",
    );
    assert!(
        m.contains("KwPass")
            || m.contains("expected an expression")
            || m.contains("expected; or }"),
        "pass statement-block position must fail closed(actual: {})",
        m
    );
}

/// Negative 15: the pre-existing E0001 family on non-handle keywords —
/// an unrelated keyword in expression position still fails closed (the
/// window's dispatch adds only KwHandle; e.g. KwUse retains its face).
#[test]
fn neg_existing_e0001_family_maintained() {
    let m = assert_grammar_err_parity(
        "fn run() {\n    let r = use;\n    r\n}\nrun()",
        "existing E0001 family",
    );
    assert!(
        m.contains("expected an expression") && m.contains("KwUse"),
        "the KwUse expression-position face must be maintained(actual: {})",
        m
    );
}

/// Negative 16: dual-Reader error parity on a structure error in
/// expression position (message + Span byte equality — the mirror's
/// diagnostic face is the seed's, by construction).
#[test]
fn neg_dual_reader_err_parity_structure() {
    let m = assert_grammar_err_parity(
        "fn run() {\n    let r = handle ask() { gift(p, k) => resume(1), gift(q, k2) => resume(2) };\n    r\n}\nrun()",
        "dual-reader err parity structure",
    );
    assert!(
        m.contains("duplicate"),
        "structure error must carry the D6 diagnostic for the parity carrier(actual: {})",
        m
    );
}

// ---------------------------------------------------------------------------
// Negatives — cross-stage semantic family (N17-N24)
// ---------------------------------------------------------------------------

/// Negative 17: E0006 capability gate — the expression-position program
/// calling print without `require io, write` (the capability face
/// unchanged by the positional window).
#[test]
fn neg_e0006_capability_gate_maintained() {
    let err = run_source(
        "fn ask() { perform gift(10, 20); }\nfn run() {\n    let r = handle ask() { gift(p, k) => resume(100) };\n    print(r)\n}\nrun()",
        "nocap.ktf",
    )
    .expect_err("print without require must fail");
    assert!(
        err.to_string().contains("capability") || err.to_string().contains("E0006"),
        "capability gate must be maintained(actual: {})",
        err
    );
}

/// Negative 18: E0022 unbound reference — the expression-position
/// program referencing an undefined symbol.
#[test]
fn neg_e0022_unbound_maintained() {
    let err = run_source(
        "fn run() {\n    let r = handle missing_fn() { gift(p, k) => resume(1) };\n    r\n}\nrun()",
        "unbound.ktf",
    )
    .expect_err("unbound reference must fail");
    assert!(
        err.to_string().contains("E0022") || err.to_string().contains("unbound"),
        "unbound reference must be detected(actual: {})",
        err
    );
}

/// Negative 19: effect escape — the expression-position handle whose
/// arms do not cover the performed tag propagates and fails closed at
/// runtime with err_effect_unhandled (code 7 — the honest face).
#[test]
fn neg_effect_escape_runtime_code7() {
    let err = run_source(
        "fn ask() { perform gift(1, 2); }\nfn run() {\n    let r = handle ask() { otherA(p, k) => resume(1) };\n    r\n}\nrun()",
        "escape.ktf",
    )
    .expect_err("uncovered effect must fail at runtime");
    assert!(
        err.to_string().contains("unhandled effect") || err.to_string().contains("gift"),
        "effect escape must hit err_effect_unhandled(actual: {})",
        err
    );
}

/// Negative 20: the static face's condition discipline on a literal
/// carrier inside an expression-position program context — `if 1 { 11 }
/// else { 22 }` is E0005-detected (the handle value position itself is
/// fresh-generalized by design — the r80 zero-false-positive contract —
/// so the detection anchor rides the literal slot; the window's programs
/// still flow through the unchanged static discipline).
#[test]
fn neg_check_condition_bool_detection() {
    let report = check_source_recover(
        "fn ask() { perform gift(10, 20); }\nfn run() {\n    let r = handle ask() { gift(p, k) => resume(100) };\n    if 1 { 11 } else { 22 }\n}\nrun()",
        "cond.ktf",
    )
    .expect("recovery mode check does not short-circuit");
    assert!(
        !report.diagnostics.is_empty(),
        "literal int condition must be check-detected(actual: {:?})",
        report.diagnostics
    );
}

/// Negative 21: resume arity — a two-argument resume call inside an
/// expression-position arm (the r128 resume call form is single-arity).
#[test]
fn neg_resume_arity_maintained() {
    let m = assert_grammar_err_parity(
        "fn run() {\n    let r = handle ask() { gift(p, k) => resume(1, 2) };\n    r\n}\nrun()",
        "resume arity",
    );
    assert!(
        m.contains("resume") || m.contains("expected"),
        "resume arity must fail closed(actual: {})",
        m
    );
}

/// Negative 22: deep-nesting combination — a three-level nest where the
/// innermost protected position is illegal (the combination fail — the
/// dispatch composes, the discipline composes too).
#[test]
fn neg_deep_nesting_combination_fail() {
    let m = assert_grammar_err_parity(
        "fn run() {\n    let r = handle (handle (handle use) { a(p, k) => resume(1) }) { b(q, k2) => resume(2) };\n    r\n}\nrun()",
        "deep nesting combination",
    );
    assert!(
        m.contains("expected an expression"),
        "deep-nesting illegal core must fail closed(actual: {})",
        m
    );
}

/// Negative 23: the statement-face negative full re-anchor — the
/// r132-style arm diagnostic through this window's build (the
/// statement face's fail-closed battery is regression-anchored, not
/// just value-anchored).
#[test]
fn neg_statement_face_negative_reanchor() {
    let m = assert_grammar_err_parity(
        "fn ask() { perform gift(10, 20); }\nfn run() {\n    handle ask() { gift(p, k) => };\n}\nrun()",
        "statement face negative re-anchor",
    );
    assert!(
        m.contains("expected handler body"),
        "statement-face arm diagnostic must hold(actual: {})",
        m
    );
}

/// Negative 24: cross-face count parity — the same semantic violation
/// (a literal int if condition) produces the same diagnostic count on
/// both faces' check chains (the dual-entry parity of the static face —
/// the r140 caliber's expression-position extension; the handle value
/// position itself is fresh-generalized by design, so the parity carrier
/// rides the literal slot).
#[test]
fn neg_cross_face_count_parity() {
    let ktf_report = check_source_recover(
        "fn ask() { perform gift(10, 20); }\nfn run() {\n    let r = handle ask() { gift(p, k) => resume(100) };\n    if 1 { 11 } else { 22 }\n}\nrun()",
        "cond.ktf",
    )
    .expect("ktf check does not short-circuit");
    // E6 r154 / 224-c6: the .krf twin leg retired with the S-expr face.
    assert!(
        !ktf_report.diagnostics.is_empty(),
        "the violation carrier must be non-clean"
    );
}

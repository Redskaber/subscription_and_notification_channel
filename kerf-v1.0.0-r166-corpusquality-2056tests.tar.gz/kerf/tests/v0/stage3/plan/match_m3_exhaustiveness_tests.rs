// E6 close-out (r154 / 224-b7): converted to the target-syntax face.
//! match implementation batch M-3 — the §4 exhaustiveness gate tests
//! (r123 / 193-a).
//!
//! **Verification surfaces**: (1) **positive** — the exhaustive forms pass
//! the gate and run (the unguarded total arm family: wildcard / bare
//! binding / or-with-total-alternative; the bool closed-domain exemption:
//! true/false arms, or-flattened); (2) **negative** — E0025 fail-closed
//! rejections (open domains / half domains / guarded-only totals / nested
//! literals / pair arms) with the message face mirrored byte-identical
//! across the seed Rust expander and the self-hosted expander.ktf mirror;
//! (3) **precedence** — structural diagnostics (arm shapes / or identity /
//! duplicates) keep their surfacing order ahead of the gate (E6 conversion,
//! r154 / 224-b7: the target-Reader-reachable subset — or identity /
//! duplicates — keeps the anchor; the shape-family legs [zero arms /
//! one-element arm / ternary pattern / reserved-word binding / vector
//! pattern] are Reader-front-fenced on the target face and are covered at
//! the Reader layer by match_m4_krf_mirror_tests' negative corpus); (4) the
//! **runtime double layer** (principle 42) — the residual reachable class
//! of the §4 fallback = the pattern-structural bool exemption on a
//! non-bool scrutinee (`eq` is any→any→bool — the type side stays with the
//! runtime guard); (5) the **check channel** E2E (E0025 rides the existing
//! compile-time diagnostic channel — the recovery face CheckReport;
//! calibration: expand-stage negatives surface as diagnostics, not fatal
//! Err); (6) **diagnostic-only** — the closed-domain corpus compiles
//! bytecode-identical to the M-2 canonical product (the uniform chain
//! keeps the fallback node under the last arm: zero dead-code elimination).
//!
//! Basis: match-design.md v1.2 §4 (conservative sound rules — zero false
//! positives) + the r123 M-3 rulings (unguarded-arm strictness /
//! top-level-only collection with or-flattening / pattern-structural
//! exemption honest boundary / gate-after-fold ordering) / principle 31
//! (skin/skeleton — the gate changes no product bytes) / principle 42
//! (compile-time rules + runtime guard double layer).

use kerf_compiler::{compile_module, BcProgram};
use kerf_driver::bootstrap::expander::expand_program;
use kerf_driver::{check_source_recover, run_source, run_source_seed, Stage};
use kerf_expander::{expand_program as expand_program_seed, ExpandCtxt};
use kerf_reader::read_source;
use kerf_syntax::{Stx, SymbolTable};
use kerf_vm::Value;

// ---------------------------------------------------------------------------
// Infrastructure (mirrors match_m2_desugar_tests — the r106/r122 parity
// disciplines, reused verbatim)
// ---------------------------------------------------------------------------

/// Bytecode semantic-payload equality (instruction order + constant pool +
/// proto shapes + global-reference face; debug_spans cross-text
/// incomparable, explicitly excluded).
fn assert_same_bytecode(a: &BcProgram, b: &BcProgram, what: &str) {
    assert_eq!(
        a.protos.len(),
        b.protos.len(),
        "[{}] prototype count mismatch",
        what
    );
    for (i, (pa, pb)) in a.protos.iter().zip(b.protos.iter()).enumerate() {
        assert_eq!(
            pa.code, pb.code,
            "[{}] prototype {} instruction sequence mismatch",
            what, i
        );
        assert_eq!(
            pa.params.len(),
            pb.params.len(),
            "[{}] prototype {} argument count",
            what,
            i
        );
        assert_eq!(
            pa.n_locals, pb.n_locals,
            "[{}] prototype {} local slot count",
            what, i
        );
        assert_eq!(
            pa.capture_names.len(),
            pb.capture_names.len(),
            "[{}] prototype {} capture count",
            what,
            i
        );
    }
    assert_eq!(a.consts, b.consts, "[{}] constant pool mismatch", what);
    assert_eq!(
        a.global_refs, b.global_refs,
        "[{}] global reference face mismatch",
        what
    );
}

/// Seed compile: Stx forms → seed expansion → seed compilation.
fn compile_forms_seed(forms: &[Stx], table: SymbolTable, what: &str) -> (BcProgram, SymbolTable) {
    let mut ectx = ExpandCtxt::new(table);
    let core = expand_program_seed(forms, &mut ectx)
        .unwrap_or_else(|e| panic!("[{}] seed expansion failed:{}", what, e.message));
    let program = compile_module(&core)
        .unwrap_or_else(|e| panic!("[{}] seed compile failed: {}", what, e.message));
    (program, ectx.table)
}

/// Two-face parity (target match surface / hand-written cond/let
/// equivalent — both read through the seed Reader; the S-expr face
/// leg retired with the S-expr Reader, E6 / r154) — the M-2 acceptance-gate
/// discipline reused for the closed-domain corpus.
fn assert_match_parity(target_src: &str, equivalent: &str, what: &str) {
    let mut tt = SymbolTable::new();
    let tf = read_source(target_src, 0, &mut tt)
        .unwrap_or_else(|e| panic!("[{}] target syntax read failed:{}", what, e.message));
    let (p_target, mut tt) = compile_forms_seed(&tf, tt, "target face");

    let ef = read_source(equivalent, 1, &mut tt)
        .unwrap_or_else(|e| panic!("[{}] equivalent form read failed:{}", what, e.message));
    let (p_equiv, _tt) = compile_forms_seed(&ef, tt, "equivalent form");

    assert_same_bytecode(
        &p_target,
        &p_equiv,
        &format!("[{}] target face ↔ manual write equivalent form", what),
    );
}

/// Dual-path parity: seed Rust expander ↔ self-hosted expander (E1-β).
fn assert_dual_path(target_src: &str, what: &str) {
    let mut t0 = SymbolTable::new();
    let f1 = read_source(target_src, 0, &mut t0)
        .unwrap_or_else(|e| panic!("[{}] seed parse failed: {}", what, e.message));
    let (p1, mut t0) = compile_forms_seed(&f1, t0, "seed expansion");

    let f2 = read_source(target_src, 0, &mut t0)
        .unwrap_or_else(|e| panic!("[{}] second-read parse failed:{}", what, e.message));
    let core2 = expand_program(&f2, 0, &mut t0)
        .unwrap_or_else(|e| panic!("[{}] bootstrap expansion failed: {}", what, e.message));
    let p2 = compile_module(&core2)
        .unwrap_or_else(|e| panic!("[{}] compile failed:{}", what, e.message));

    assert_same_bytecode(
        &p1,
        &p2,
        &format!("[{}] seed expansion ↔ bootstrap expansion", what),
    );
}

/// Seed-path negative: the expansion error message (target face).
fn seed_err(src: &str, what: &str) -> String {
    let mut t = SymbolTable::new();
    let forms = read_source(src, 0, &mut t)
        .unwrap_or_else(|e| panic!("[{}] target syntax read failed:{}", what, e.message));
    let mut ectx = ExpandCtxt::new(t);
    match expand_program_seed(&forms, &mut ectx) {
        Ok(_) => panic!(
            "[{}] should fail to expand(fail-closed negative case)",
            what
        ),
        Err(e) => e.message,
    }
}

/// Bootstrap-path negative: the expansion error message (message-equal to
/// the seed side by contract).
fn bootstrap_err(src: &str, what: &str) -> String {
    let mut t = SymbolTable::new();
    let forms = read_source(src, 0, &mut t)
        .unwrap_or_else(|e| panic!("[{}] target syntax read failed:{}", what, e.message));
    match expand_program(&forms, 0, &mut t) {
        Ok(_) => panic!(
            "[{}] should fail to expand(bootstrap path fail-closed negative case)",
            what
        ),
        Err(e) => e.message,
    }
}

/// Both paths must reject with the byte-identical E0025 message.
fn assert_e0025(src: &str, what: &str) {
    let seed = seed_err(src, what);
    let boot = bootstrap_err(src, what);
    assert!(
        seed.contains("E0025"),
        "[{}] seed message missing E0025: {}",
        what,
        seed
    );
    assert!(
        seed.contains("non-exhaustive match"),
        "[{}] seed message lacks `non-exhaustive match`: {}",
        what,
        seed
    );
    assert!(
        boot.contains("E0025"),
        "[{}] bootstrap message missing E0025: {}",
        what,
        boot
    );
    assert_eq!(
        seed, boot,
        "[{}] dual-path message face mismatch:{}",
        what, src
    );
}

fn assert_int(out: &kerf_driver::RunOutcome, expected: i64, what: &str) {
    assert!(
        matches!(out.value, Value::Int(v) if v == expected),
        "[{}] expected Int({}), got {:?}",
        what,
        expected,
        out.value
    );
}

// ---------------------------------------------------------------------------
// (1) Positive — the exhaustive forms pass the gate and run
// ---------------------------------------------------------------------------

#[test]
fn match_m3_wildcard_terminal_ok() {
    // The canonical exhaustive form: a wildcard terminal arm (regression
    // anchor — the gate accepts what M-2 already ran) + dual-path parity.
    assert_dual_path(
        "fn f(x: i64) -> i64 { match x { 0 => 1, _ => 9 } }",
        "wildcard end arm",
    );
    let out = run_source_seed(
        "fn f(x: i64) -> i64 { match x { 0 => 1, _ => 9 } } f(3)",
        "t.ktf",
    )
    .unwrap();
    assert_int(&out, 9, "wildcard end arm run value(seed)");
    let out = run_source(
        "fn f(x: i64) -> i64 { match x { 0 => 1, _ => 9 } } f(3)",
        "t.ktf",
    )
    .unwrap();
    assert_int(&out, 9, "wildcard end arm run value(production)");
}

#[test]
fn match_m3_binding_arm_total_ok() {
    // An unguarded bare-binding arm is total (the fold's test=None class)
    // — the match is exhaustive without any wildcard.
    let out = run_source_seed("fn f(x: i64) { match x { n => 1, 0 => 2 } } f(0)", "t.ktf").unwrap();
    assert_int(&out, 1, "no-guard binding arm = full match(first arm wins)");
    let out = run_source("fn f(x: i64) { match x { n => 1, 0 => 2 } } f(5)", "t.ktf").unwrap();
    assert_int(&out, 1, "no-guard binding arm = full match (production)");
}

#[test]
fn match_m3_bool_closed_domain_ok() {
    // Rule 2: the bool closed-domain exemption — true/false both arms.
    // Runtime on both domain values, both paths.
    let out = run_source_seed(
        "fn f(b: bool) { match b { true => 1, false => 0 } } f(true)",
        "t.ktf",
    )
    .unwrap();
    assert_int(&out, 1, "closed domain true arm(seed)");
    let out = run_source_seed(
        "fn f(b: bool) { match b { true => 1, false => 0 } } f(false)",
        "t.ktf",
    )
    .unwrap();
    assert_int(&out, 0, "closed domain false arm(seed)");
    let out = run_source(
        "fn f(b: bool) { match b { true => 1, false => 0 } } f(false)",
        "t.ktf",
    )
    .unwrap();
    assert_int(
        &out,
        0,
        "closed domain false arm(production -- bootstrap mirror exemption line weight)",
    );
}

#[test]
fn match_m3_bool_or_flattened_ok() {
    // The or-flattening face of the exemption: true | false in ONE arm
    // covers the closed domain (single-arm closed enumeration).
    let out = run_source_seed(
        "fn f(b: bool) { match b { true | false => 7 } } f(true)",
        "t.ktf",
    )
    .unwrap();
    assert_int(&out, 7, "or expand level closed domain true(seed)");
    let out = run_source_seed(
        "fn f(b: bool) { match b { true | false => 7 } } f(false)",
        "t.ktf",
    )
    .unwrap();
    assert_int(&out, 7, "or expand level closed domain false(seed)");
    let out = run_source(
        "fn f(b: bool) { match b { true | false => 7 } } f(true)",
        "t.ktf",
    )
    .unwrap();
    assert_int(&out, 7, "or expand level closed domain(production)");
}

#[test]
fn match_m3_or_total_alternative_ok() {
    // An or-marker containing a total alternative (the wildcard) makes the
    // arm total — exhaustive without a separate wildcard arm.
    let out = run_source_seed("fn f(x: i64) { match x { _ | 0 => 5 } } f(9)", "t.ktf").unwrap();
    assert_int(&out, 5, "or with wildcard alternative = full match(seed)");
    let out = run_source("fn f(x: i64) { match x { _ | 0 => 5 } } f(9)", "t.ktf").unwrap();
    assert_int(
        &out,
        5,
        "or with wildcard alternative = full match (production)",
    );
}

#[test]
fn match_m3_bool_domain_parity() {
    // Diagnostic-only anchor: the closed-domain corpus compiles
    // bytecode-identical to the M-2 canonical product — the uniform chain
    // keeps the fallback node under the last arm (zero dead-code
    // elimination at the desugar layer; the gate changes no product bytes).
    assert_match_parity(
        "fn f(b: bool) -> i64 { match b { true => 1, false => 0 } }",
        "fn f(b: bool) -> i64 {\n\
            let m = b;\n\
            if (eq(m, true)) { 1 } else {\n\
                if (eq(m, false)) { 0 } else { error(\"match failed: no arm matched\") }\n\
            }\n\
        }",
        "closed-domain exemption family",
    );
    // Dual-path parity for the same corpus (the mirror gate accepts it).
    assert_dual_path(
        "fn f(b: bool) -> i64 { match b { true => 1, false => 0 } }",
        "closed-domain exemption family",
    );
}

// ---------------------------------------------------------------------------
// (2) Negative — E0025 fail-closed rejections (mirrored message faces)
// ---------------------------------------------------------------------------

#[test]
fn match_m3_literal_only_rejected() {
    // Rule 1: no wildcard / bare-binding arm → E0025 (both paths, byte-
    // identical messages).
    assert_e0025("match x { 0 => 1 }", "literal single arm");
    assert_e0025("match x { 0 => 1, 1 => 2 }", "literal two arms");
}

#[test]
fn match_m3_open_domain_families_rejected() {
    // Rule 3: int/float/str are open domains — any number of literal arms
    // never constitutes exhaustiveness (the wildcard stays required).
    assert_e0025(
        "match x { 0 => 1, 1 => 2, 2 => 3, 3 => 4 }",
        "int many arm open domain",
    );
    assert_e0025("match x { 1.5 => 1, 2.5 => 2 }", "float open domain");
    assert_e0025("match x { \"a\" => 1, \"b\" => 2 }", "str open domain");
    assert_e0025(
        "match x { () => 1, 0 => 2 }",
        "nil+int mixed combine open domain",
    );
}

#[test]
fn match_m3_guarded_total_not_exhaustive() {
    // The unguarded ruling (r123): a guard is an arm-level secondary filter
    // that can reject — guarded wildcard/binding arms contribute nothing.
    assert_e0025("match x { _ if x < 0 => 1 }", "carry guard wildcard");
    assert_e0025(
        "match x { n if n < 0 => 1 }",
        "carry guard binding(M-2 migration negative case)",
    );
    assert_e0025(
        "match x { 0 => 1, _ if x < 9 => 2 }",
        "guard exclude wildcard full match property",
    );
}

#[test]
fn match_m3_bool_half_and_guarded_domain_rejected() {
    // Half the closed domain is not exhaustive; and the exemption requires
    // UNGUARDED literal arms (a guarded false can reject).
    assert_e0025(
        "match x { true => 1 }",
        "half closed domain -- only true arm",
    );
    assert_e0025(
        "match x { false => 0 }",
        "half closed domain -- only false arm",
    );
    assert_e0025(
        "match x { true => 1, false if x < 0 => 0 }",
        "closed domain false arm carry guard",
    );
}

#[test]
fn match_m3_nil_and_nested_positions_rejected() {
    // nil is not a closed domain by itself (its complement has no literal
    // form — bool is the unique enumerable closed domain at Level 0);
    // literals at nested pair positions do not count (the pair pattern
    // carries is-pair — structurally never total).
    assert_e0025("match x { () => 1 }", "nil single arm non-closed domain");
    assert_e0025(
        "match x { (true, a) => 1, (false, b) => 2 }",
        "nested position literal not plan",
    );
}

#[test]
fn match_m3_pair_and_or_literal_arms_rejected() {
    // Pair destructuring carries is-pair — never total; a literal-only
    // or-marker is an open-domain disjunction, not a wildcard.
    assert_e0025(
        "match x { (a, b) => 1, (c, d) => 2 }",
        "pair arm always non-full match",
    );
    assert_e0025("match x { 0 | 1 => 1 }", "literal or non-full match");
    assert_e0025(
        "match x { 0 | 1 => 1, 2 | 3 => 2 }",
        "dual literal or non-full match",
    );
}

// ---------------------------------------------------------------------------
// (3) Precedence — structural diagnostics keep their surfacing order
// ---------------------------------------------------------------------------

#[test]
fn match_m3_structural_errors_keep_precedence() {
    // The gate fires AFTER the fold: or-identity / duplicate diagnostics
    // surface first (the negative-family message-order contract, pinned on
    // both paths). E6 conversion (r154 / 224-b7): the target-Reader-reachable
    // subset — the shape-family legs (zero arms / one-element arm / ternary
    // pattern / reserved-word binding / vector pattern) are front-fenced by
    // the target Reader's own grammar (match arms are grammatically 2/3-
    // element; keyword tokens cannot enter pattern position; `[` is not a
    // pattern token) and their Reader-level message faces are covered by
    // match_m4_krf_mirror_tests' negative corpus; the two expansion-reachable
    // structural families keep the precedence anchor here.
    let cases: &[(&str, &str)] = &[
        ("match x { 0 | n => 1 }", "or pattern binding set mismatch"),
        ("match x { (n, n) => 1 }", "duplicate pattern binding"),
        (
            "match x { (a, 0) | (b, 1) => 1 }",
            "or pattern binding set mismatch",
        ),
        (
            "match x { (n, n) => 1, (a, b) => a }",
            "duplicate pattern binding",
        ),
    ];
    for (src, needle) in cases {
        let seed = seed_err(src, "structure diagnostic optimize first");
        let boot = bootstrap_err(src, "structure diagnostic optimize first -- bootstrap");
        assert!(
            seed.contains(needle),
            "seed message lacks `{}`: {}",
            needle,
            seed
        );
        assert!(
            !seed.contains("E0025"),
            "structure error should first at exhaustiveness gate: {}",
            seed
        );
        assert_eq!(seed, boot, "dual-path message face mismatch:{}", src);
    }
}

// ---------------------------------------------------------------------------
// (4) The runtime double layer (principle 42) — the residual reachable
// class of the §4 fallback
// ---------------------------------------------------------------------------

#[test]
fn match_m3_fallback_residual_class() {
    // The exemption is pattern-structural: a non-bool scrutinee through a
    // true/false-exhaustive match passes the compile-time gate and falls
    // through to the runtime guard — the double layer in action (the
    // M-2-updated fallback test carries the same anchor at the §4 layer).
    let err = run_source_seed("match (5) { true => 1, false => 0 }", "t.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Run);
    assert!(
        err.rendered.contains("match failed: no arm matched"),
        "seed path residual remaining class fallback underlying: {}",
        err.rendered
    );
    let err = run_source("match (5) { true => 1, false => 0 }", "t.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Run);
    assert!(
        err.rendered.contains("match failed: no arm matched"),
        "production path residual remaining class fallback underlying: {}",
        err.rendered
    );
    // A guarded-rejection arm no longer compiles (the directly
    // non-exhaustive forms are E0025 rejections — Stage::Expand, the
    // compile-time layer taking over what the runtime layer used to catch).
    let err = run_source_seed("match (5) { 0 => 1 }", "t.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Expand);
    assert!(
        err.rendered.contains("E0025"),
        "directly non-exhaust exhaust = compile-time rejected: {}",
        err.rendered
    );
}

// ---------------------------------------------------------------------------
// (5) The check-channel E2E (E0025 rides the existing compile-time
// diagnostic channel — no new channel; principle 42 orthogonality)
// ---------------------------------------------------------------------------

#[test]
fn match_m3_check_channel_e2e() {
    // Negative: the non-exhaustive match fails `kerf check` at the expand
    // stage (the E0002-family channel — same carrier as E0005 HM
    // diagnostics; no new channel opened). E6 calibration (r154 / 224-b7):
    // through the recovery face `check_source_recover` the expand-
    // stage negative surfaces as a diagnostic in the CheckReport (not a
    // fatal Err) — the recovery expansion converts item-level expand errors
    // into collected diagnostics; stage/code/message keep their identity.
    let report = check_source_recover("match x { 0 => 1 }", "t.ktf").expect("recovery check entry");
    assert_eq!(report.diagnostics.len(), 1, "one E0025 diagnostic");
    assert!(
        report.rendered.iter().any(|l| l.contains("E0025")),
        "check channel should carry E0025: {:?}",
        report.rendered
    );
    assert!(
        report
            .rendered
            .iter()
            .any(|l| l.contains("non-exhaustive match")),
        "check channel should carry diagnostic text: {:?}",
        report.rendered
    );
    // Positive: the closed-domain exhaustive program checks clean (zero
    // diagnostics — the gate and HM coexist orthogonally).
    let report = check_source_recover(
        "fn f(b: bool) -> i64 { match b { true => 1, false => 0 } } f(true)",
        "t.ktf",
    )
    .unwrap();
    assert!(
        report.diagnostics.is_empty(),
        "closed domain exhaust exhaust program expected zero diagnostics: {:?}",
        report.rendered
    );
}

// ---------------------------------------------------------------------------
// (6) The target-face gate (the M-1 Reader face → the seed/bootstrap gates)
// ---------------------------------------------------------------------------

#[test]
fn match_m3_target_face_gate() {
    // Target-face non-exhaustive form → E0025 through the seed target
    // Reader + expansion, and the identical message through the bootstrap
    // mirror (the production chain's face).
    let mut t = SymbolTable::new();
    let forms = read_source("fn f(x: i64) -> i64 { match x { 0 => 1 } }", 0, &mut t)
        .unwrap_or_else(|e| panic!("target syntax read failed:{}", e.message));
    let mut ectx = ExpandCtxt::new(t);
    let seed_msg = match expand_program_seed(&forms, &mut ectx) {
        Ok(_) => panic!("target face should fail to expand(E0025 negative case)"),
        Err(e) => e.message,
    };
    assert!(
        seed_msg.contains("E0025"),
        "target face seed message: {}",
        seed_msg
    );

    let mut t2 = SymbolTable::new();
    let forms2 = read_source("fn f(x: i64) -> i64 { match x { 0 => 1 } }", 0, &mut t2)
        .unwrap_or_else(|e| panic!("target syntax two read failed: {}", e.message));
    let boot_msg = match expand_program(&forms2, 0, &mut t2) {
        Ok(_) => panic!("target face should itself cite expand failed(E0025 negative case)"),
        Err(e) => e.message,
    };
    assert_eq!(
        seed_msg, boot_msg,
        "target face dual-path message face mismatch"
    );
}

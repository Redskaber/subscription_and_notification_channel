// E6 close-out (r154 / 224-b7): converted to the target-syntax face.
//! match implementation batch M-2 — the D2 seventh skin-dictionary mapping
//! tests (r122 / 192-a).
//!
//! **Verification surfaces**: (1) **cross-syntax bytecode parity** — the M-2
//! acceptance gate (match-design.md v1.1 §6): the match corpus compiles
//! bytecode-identical to the hand-written cond/let-equivalent program (the
//! SyntaxTransitionValidator discipline — debug_spans cross-text
//! incomparable, excluded by design; E6 / r154: the S-expr-Reader leg is
//! retired with the S-expr Reader — both sides now read through the seed
//! target Reader, the gate = target match surface ↔ manual equivalent);
//! (2) **dual-path parity** — the E1-β discipline extended to the match
//! corpus: the seed Rust expander ↔ the self-hosted expander (expander.ktf
//! on the VM, carrying the M-2 mirror desugar); (3) runtime semantics
//! (literals / bindings / guards / pair destructuring / or markers / nil /
//! first-match-wins / the §4 defensive fallback — seed and production
//! paths); (4) fail-closed negatives (arm shapes / pattern domain / or
//! binding-map identity / duplicates / reserved-word bindings — mirrored
//! message faces on both paths; E6 / r154: the shape-family legs are
//! Reader-front-fenced on the target face and keep their fail-closed
//! anchors at the Reader layer, the dual-Reader message faces are
//! match_m4_krf_mirror_tests' negative corpus); (5) the HM-check face
//! integration; (6) the guard effect-order anchor (§7 open question 2:
//! guard effects are arm-internal — fired only after the structural test
//! passes).
//!
//! Basis: match-design.md v1.1 §3 (the §3 semantic table in full — the v1.2
//! §3.4 canonical product rulings: the `eq` predicate refinement / the
//! path-based extraction / the guard `(and T (let binds G))` shape with body
//! re-binding / the uniform `(if true ...)` chain / the or binding-map
//! identity) / principle 31 (skin/skeleton isomorphism — zero new
//! primitives) / principle 42 (the §4 runtime fallback layer) / principle 43
//! (progressive disclosure — M-2 within the M-1..M-4 batch discipline).

use kerf_compiler::{compile_module, BcProgram};
use kerf_driver::bootstrap::expander::expand_program;
use kerf_driver::{check_source_recover, run_source, run_source_seed, Stage};
use kerf_expander::{expand_program as expand_program_seed, ExpandCtxt};
use kerf_reader::read_source;
use kerf_syntax::{Stx, SymbolTable};
use kerf_vm::Value;

// ---------------------------------------------------------------------------
// Infrastructure (mirrors switch_corpus_parity_tests — the r106
// SyntaxTransitionValidator bytecode comparison discipline)
// ---------------------------------------------------------------------------

/// Bytecode semantic-payload equality (instruction order + constant pool +
/// proto shapes + global-reference face; debug_spans cross-text
/// incomparable, explicitly excluded).
fn assert_same_bytecode(a: &BcProgram, b: &BcProgram, what: &str) {
    assert_eq!(
        a.protos.len(),
        b.protos.len(),
        "[{}] prototype count mismatch",
        what
    );
    for (i, (pa, pb)) in a.protos.iter().zip(b.protos.iter()).enumerate() {
        assert_eq!(
            pa.code, pb.code,
            "[{}] prototype {} instruction sequence mismatch",
            what, i
        );
        assert_eq!(
            pa.params.len(),
            pb.params.len(),
            "[{}] prototype {} argument count",
            what,
            i
        );
        assert_eq!(
            pa.n_locals, pb.n_locals,
            "[{}] prototype {} local slot count",
            what, i
        );
        assert_eq!(
            pa.capture_names.len(),
            pb.capture_names.len(),
            "[{}] prototype {} capture count",
            what,
            i
        );
    }
    assert_eq!(a.consts, b.consts, "[{}] constant pool mismatch", what);
    assert_eq!(
        a.global_refs, b.global_refs,
        "[{}] global reference face mismatch",
        what
    );
}

/// Seed compile: Stx forms → seed expansion → seed compilation (the table is
/// carried through for symbol-domain comparability).
fn compile_forms_seed(forms: &[Stx], table: SymbolTable, what: &str) -> (BcProgram, SymbolTable) {
    let mut ectx = ExpandCtxt::new(table);
    let core = expand_program_seed(forms, &mut ectx)
        .unwrap_or_else(|e| panic!("[{}] seed expansion failed:{}", what, e.message));
    let program = compile_module(&core)
        .unwrap_or_else(|e| panic!("[{}] seed compile failed: {}", what, e.message));
    (program, ectx.table)
}

/// The M-2 acceptance gate: the match corpus (target face) compiles
/// bytecode-identical to the hand-written cond/let-equivalent program
/// (single shared table — the temp/binder names resolve to slots, never
/// entering the bytecode face; E6 / r154: the S-expr-Reader leg retired
/// with the S-expr Reader — both faces read through the seed target
/// Reader).
fn assert_match_parity(target_src: &str, equivalent: &str, what: &str) {
    // Target face → seed Reader → expansion → bytecode.
    let mut tt = SymbolTable::new();
    let tf = read_source(target_src, 0, &mut tt)
        .unwrap_or_else(|e| panic!("[{}] target syntax read failed:{}", what, e.message));
    let (p_target, mut tt) = compile_forms_seed(&tf, tt, "target face");

    // Hand-written cond/let equivalent (the canonical product shape of
    // match-design.md v1.2 §3.4, written out).
    let ef = read_source(equivalent, 1, &mut tt)
        .unwrap_or_else(|e| panic!("[{}] equivalent form read failed:{}", what, e.message));
    let (p_equiv, _tt) = compile_forms_seed(&ef, tt, "equivalent form");

    assert_same_bytecode(
        &p_target,
        &p_equiv,
        &format!("[{}] target face ↔ manual write equivalent form", what),
    );
}

/// Dual-path parity: the same forms through the seed Rust expander ↔ the
/// self-hosted expander (expander.ktf on the VM — the E1-β discipline
/// extended to the match corpus).
fn assert_dual_path(target_src: &str, what: &str) {
    let mut t0 = SymbolTable::new();
    let f1 = read_source(target_src, 0, &mut t0)
        .unwrap_or_else(|e| panic!("[{}] seed parse failed: {}", what, e.message));
    let (p1, mut t0) = compile_forms_seed(&f1, t0, "seed expansion");

    let f2 = read_source(target_src, 0, &mut t0)
        .unwrap_or_else(|e| panic!("[{}] second-read parse failed:{}", what, e.message));
    let core2 = expand_program(&f2, 0, &mut t0)
        .unwrap_or_else(|e| panic!("[{}] bootstrap expansion failed: {}", what, e.message));
    let p2 = compile_module(&core2)
        .unwrap_or_else(|e| panic!("[{}] compile failed:{}", what, e.message));

    assert_same_bytecode(
        &p1,
        &p2,
        &format!("[{}] seed expansion ↔ bootstrap expansion", what),
    );
}

/// Seed-path negative: the expansion error message (target face).
fn seed_err(src: &str, what: &str) -> String {
    let mut t = SymbolTable::new();
    let forms = read_source(src, 0, &mut t)
        .unwrap_or_else(|e| panic!("[{}] target syntax read failed:{}", what, e.message));
    let mut ectx = ExpandCtxt::new(t);
    match expand_program_seed(&forms, &mut ectx) {
        Ok(_) => panic!(
            "[{}] should fail to expand(fail-closed negative case)",
            what
        ),
        Err(e) => e.message,
    }
}

/// Bootstrap-path negative: the expansion error message (the expander.ktf
/// mirror's diagnostic face — message-equal to the seed side by contract).
fn bootstrap_err(src: &str, what: &str) -> String {
    let mut t = SymbolTable::new();
    let forms = read_source(src, 0, &mut t)
        .unwrap_or_else(|e| panic!("[{}] target syntax read failed:{}", what, e.message));
    match expand_program(&forms, 0, &mut t) {
        Ok(_) => panic!(
            "[{}] should fail to expand(bootstrap path fail-closed negative case)",
            what
        ),
        Err(e) => e.message,
    }
}

/// Reader-front-fence negative (E6 / r154): the target Reader rejects the
/// form at the grammar layer — the shape-family negatives' target-face
/// carrier (the arms are grammatically `pattern [if guard] => body`, so the
/// malformed-arm classes never reach the expander).
fn read_err(src: &str, what: &str) -> String {
    let mut t = SymbolTable::new();
    match read_source(src, 0, &mut t) {
        Err(e) => e.message,
        Ok(_) => panic!(
            "[{}] should fail to read(Reader-front-fenced negative case)",
            what
        ),
    }
}

fn assert_int(out: &kerf_driver::RunOutcome, expected: i64, what: &str) {
    assert!(
        matches!(out.value, Value::Int(v) if v == expected),
        "[{}] expected Int({}), got {:?}",
        what,
        expected,
        out.value
    );
}

// ---------------------------------------------------------------------------
// (1) Cross-syntax bytecode parity — the M-2 acceptance gate
// ---------------------------------------------------------------------------

#[test]
fn match_m2_basic_desugar_parity() {
    // The canonical basic corpus: literal arm + wildcard terminal arm.
    // Product: (let ((m x)) (if (eq m 0) 1 (if true 9 (error "...")))) —
    // the target-face equivalent writes the chain out by hand (eq call /
    // uniform (if true ...) tail / the error fallback carrier).
    assert_match_parity(
        "fn f(x: i64) -> i64 { match x { 0 => 1, _ => 9 } }\nf(3)",
        "fn f(x: i64) -> i64 {\n\
           let m = x;\n\
           if (eq(m, 0)) { 1 } else { if (true) { 9 } else { error(\"match failed: no arm matched\") } }\n\
           }\n\
           f(3)",
        "basic family",
    );
}

#[test]
fn match_m2_guard_binding_parity() {
    // Guard + binding arm: the guard evaluates inside the binding scope
    // ((and-free no-test arm: (let ((n m)) G) as the test), the body
    // re-binds — arm bindings never leak into the rest chain). E6 note: the
    // desugar product carries the guard let in condition position
    // ((if (let ((n m)) (< n 0)) ...)); the target face has no
    // expression-position let, so the equivalent writes the bytecode-identical
    // let-outside-if form ((let ((n m)) (if (< n 0) ...)) — same store,
    // same test, same branch chain).
    assert_match_parity(
        "fn f(x: i64) -> i64 { match x { 0 => 0, n if n < 0 => 0 - 1, _ => 9 } }",
        "fn f(x: i64) -> i64 {\n\
           let m = x;\n\
           if (eq(m, 0)) { 0 } else {\n\
           let n = m;\n\
           if (n < 0) { let n = m; 0 - 1 } else { if (true) { 9 } else { error(\"match failed: no arm matched\") } }\n\
           }\n\
           }",
        "guard binding family",
    );
}

#[test]
fn match_m2_pattern_family_parity() {
    // The full pattern-atom family: pair destructuring (both slots bound —
    // test = (is-pair m) alone), or-in-pair ((and (is-pair m) (or ...))),
    // nil skin (is-nil), float/str/bool literals (eq — type-strict).
    // M-3 co-update: the corpus gains a wildcard terminal arm (the M-3
    // exhaustiveness gate would reject the terminal-fallback-only form —
    // r123 / 193-a; the uniform chain still carries the fallback node).
    // E6 note: both sides fn-wrapped (the equivalent's leading let needs a
    // body — the target face has no top-level let); the variadic-shape
    // and/or tests are written as call forms (and(a, b) / or(a, b) carry
    // the desugar's exact Stx arity).
    assert_match_parity(
        "fn f(p: T) { match p { (a, b) => a, ((0 | 1), c) => c, () => 7, 1.5 => 8, \"s\" => 9, true => 1, _ => 9 } }",
        "fn f(p: T) {\n\
           let m = p;\n\
           if (is_pair(m)) { let a = head(m), b = tail(m); a } else {\n\
           if (and(is_pair(m), or(eq(head(m), 0), eq(head(m), 1)))) { let c = tail(m); c } else {\n\
           if (is_nil(m)) { 7 } else {\n\
           if (eq(m, 1.5)) { 8 } else {\n\
           if (eq(m, \"s\")) { 9 } else {\n\
           if (eq(m, true)) { 1 } else { if (true) { 9 } else { error(\"match failed: no arm matched\") } }\n\
           }\n\
           }\n\
           }\n\
           }\n\
           }\n\
           }",
        "full pattern family",
    );
}

#[test]
fn match_m2_or_marker_parity() {
    // Bare or-marker at arm level: (or (eq m 0) (eq m 1) (eq m 2)) — the
    // three-alternative variadic or. E6 note: the `||` operator form is
    // binary-left-assoc (a different Stx shape), so the equivalent writes
    // the variadic or as the call form or(a, b, c) — the exact desugar
    // product arity.
    assert_match_parity(
        "fn f(x: i64) -> i64 { match x { 0 | 1 | 2 => 10, _ => 20 } }\nf(7)",
        "fn f(x: i64) -> i64 {\n\
           let m = x;\n\
           if (or(eq(m, 0), eq(m, 1), eq(m, 2))) { 10 } else { if (true) { 20 } else { error(\"match failed: no arm matched\") } }\n\
           }\n\
           f(7)",
        "or tag family",
    );
}

#[test]
fn match_m2_nested_pair_parity() {
    // Nested pair destructuring: path-based extraction ((head (head m))
    // etc.) — left-to-right binding order, no intermediate temps.
    // M-3 co-update: the corpus gains a wildcard terminal arm (r123 /
    // 193-a — pair arms are structurally never total). E6 note: both sides
    // fn-wrapped (no top-level let on the target face).
    assert_match_parity(
        "fn f(q: T) { match q { ((a, b), c) => a, (a, (b, c)) => b, _ => 0 } }",
        "fn f(q: T) {\n\
           let m = q;\n\
           if (and(is_pair(m), is_pair(head(m)))) { let a = head(head(m)), b = tail(head(m)), c = tail(m); a } else {\n\
           if (and(is_pair(m), is_pair(tail(m)))) { let a = head(m), b = head(tail(m)), c = tail(tail(m)); b } else {\n\
           if (true) { 0 } else { error(\"match failed: no arm matched\") }\n\
           }\n\
           }\n\
           }",
        "nested pair family",
    );
}

#[test]
fn match_m2_scrutinee_expression_parity() {
    // Composite scrutinee (call + operator precedence): the single-evaluation
    // temp wrapper (the structural pin — one call site in the let binding).
    assert_match_parity(
        "fn g(y: i64) -> i64 { match (fib(y) + 1) { 0 => 1, _ => 9 } }\n\
         fn fib(n: i64) -> i64 { if n < 2 { n } else { fib(n - 1) + fib(n - 2) } }\n\
         g(5)",
        "fn g(y: i64) -> i64 {\n\
         let m = fib(y) + 1;\n\
         if (eq(m, 0)) { 1 } else { if (true) { 9 } else { error(\"match failed: no arm matched\") } }\n\
         }\n\
         fn fib(n: i64) -> i64 { if n < 2 { n } else { fib(n - 1) + fib(n - 2) } }\n\
         g(5)",
        "scrutinee expression family",
    );
}

// ---------------------------------------------------------------------------
// (2) Dual-path parity — seed Rust expander ↔ self-hosted expander (E1-β
// discipline extended to the match corpus; the expander.ktf mirror carries
// the same canonical desugar)
// ---------------------------------------------------------------------------

#[test]
fn match_m2_dual_path_seed_vs_bootstrap() {
    assert_dual_path(
        "fn f(x: i64) -> i64 { match x { 0 => 1, _ => 9 } }\nf(3)",
        "basic family",
    );
    assert_dual_path(
        "fn f(x: i64) -> i64 { match x { 0 => 0, n if n < 0 => 0 - 1, _ => 9 } }",
        "guard binding family",
    );
    assert_dual_path(
        "match p { (a, b) => a, ((0 | 1), c) => c, () => 7, 1.5 => 8, \"s\" => 9, true => 1, _ => 9 }",
        "full pattern family",
    );
    assert_dual_path("match x { 0 | 1 | 2 => 10, _ => 20 }", "or tag family");
    assert_dual_path(
        "match q { ((a, b), c) => a, (a, (b, c)) => b, _ => 0 }",
        "nested pair family",
    );
    // The target face through the bootstrap expander (the production
    // compile path shape — the target Reader never rejects match; E6: the
    // former S-expr-face leg, now the target face through both expanders).
    let mut t0 = SymbolTable::new();
    let src = "fn f(x: i64) -> i64 { match x { 0 => 1, n if n < 0 => 0 - 1, _ => 9 } } f(3)";
    let f1 = read_source(src, 0, &mut t0)
        .unwrap_or_else(|e| panic!("target syntax read failed:{}", e.message));
    let (p1, mut t0) = compile_forms_seed(&f1, t0, "seed expansion");
    let core2 = expand_program(&f1, 0, &mut t0)
        .unwrap_or_else(|e| panic!("bootstrap expansion failed: {}", e.message));
    let p2 = compile_module(&core2).unwrap_or_else(|e| panic!("compile failed:{}", e.message));
    assert_same_bytecode(&p1, &p2, "target face seed expansion ↔ bootstrap expansion");
    let _ = t0;
}

// ---------------------------------------------------------------------------
// (3) Runtime semantics (seed path — Rust expander + Rust compiler + VM)
// ---------------------------------------------------------------------------

#[test]
fn match_m2_runtime_semantics_seed() {
    // Literal arms + wildcard.
    let out = run_source_seed("fn f(x: i64) { match x { 0 => 1, _ => 9 } } f(3)", "t.ktf").unwrap();
    assert_int(&out, 9, "wildcard arm");
    let out = run_source_seed("fn f(x: i64) { match x { 0 => 1, _ => 9 } } f(0)", "t.ktf").unwrap();
    assert_int(&out, 1, "literal arm hit");

    // Binding arm (the binding receives the scrutinee) + guard visibility.
    let out = run_source_seed(
        "fn f(x: i64) { match x { n if n < 0 => 0 - n, _ => 0 } } f(5)",
        "t.ktf",
    )
    .unwrap();
    assert_int(&out, 0, "guard veto → wildcard");
    let out = run_source_seed(
        "fn f(x: i64) { match x { n if n < 0 => 0 - n, _ => 0 } } f(0 - 4)",
        "t.ktf",
    )
    .unwrap();
    assert_int(&out, 4, "guard hit -- binding visible(n = -4 → 4)");

    // First-match-wins: a binding arm shadows later arms.
    let out = run_source_seed("fn f(x: i64) { match x { n => 1, 0 => 2 } } f(0)", "t.ktf").unwrap();
    assert_int(&out, 1, "first arm wins (binding arm before literal arm)");

    // Pair destructuring.
    let out = run_source_seed(
        "fn f(p: T) { match p { (a, b) => a + b, _ => 0 } } f(cons(3, 4))",
        "t.ktf",
    )
    .unwrap();
    assert_int(&out, 7, "pair destructuring");
    let out = run_source_seed(
        "fn f(p: T) { match p { (a, b) => a + b, _ => 0 } } f(5)",
        "t.ktf",
    )
    .unwrap();
    assert_int(
        &out,
        0,
        "non-pair → wildcard(guard short-circuit without extraction)",
    );

    // Nested pairs.
    let out = run_source_seed(
        "fn f(q: T) { match q { ((a, b), c) => a + (b + c), _ => 0 } }\n\
         f(cons(cons(1, 2), 3))",
        "t.ktf",
    )
    .unwrap();
    assert_int(&out, 6, "nested pair destructuring");

    // or marker (first alternative hit / second hit / miss).
    let out = run_source_seed(
        "fn f(x: i64) { match x { 0 | 1 | 2 => 10, _ => 20 } } f(1)",
        "t.ktf",
    )
    .unwrap();
    assert_int(&out, 10, "or #two alternative hit");
    let out = run_source_seed(
        "fn f(x: i64) { match x { 0 | 1 | 2 => 10, _ => 20 } } f(7)",
        "t.ktf",
    )
    .unwrap();
    assert_int(&out, 20, "or miss → wildcard");

    // or marker with the common binding map.
    let out = run_source_seed(
        "fn f(x: T) { match x { (a, 0) | (a, 1) => a, _ => 0 } } f(cons(9, 1))",
        "t.ktf",
    )
    .unwrap();
    assert_int(&out, 9, "or same position binding(a @ head)");

    // nil skin / string / bool / float literals (eq = type-strict).
    let out = run_source_seed("fn f(x: T) { match x { () => 7, _ => 9 } } f(())", "t.ktf").unwrap();
    assert_int(&out, 7, "nil skin arm");
    let out = run_source_seed(
        "fn f(x: T) { match x { \"s\" => 1, _ => 9 } } f(\"s\")",
        "t.ktf",
    )
    .unwrap();
    assert_int(&out, 1, "string literal arm");
    let out = run_source_seed(
        "fn f(x: T) { match x { true => 1, _ => 9 } } f(true)",
        "t.ktf",
    )
    .unwrap();
    assert_int(&out, 1, "bool literal arm");
    let out = run_source_seed(
        "fn f(x: T) { match x { 1.5 => 8, _ => 9 } } f(1.5)",
        "t.ktf",
    )
    .unwrap();
    assert_int(&out, 8, "float literal arm");
    // Type strictness: the Int pattern 0 does not match the Float 0.0 (the
    // `eq` ruling — Int/Float never cross-match).
    let out = run_source_seed("fn f(x: T) { match x { 0 => 1, _ => 9 } } f(0.0)", "t.ktf").unwrap();
    assert_int(
        &out,
        9,
        "Int pattern does not match across types Float scrutinee(eq type-strict)",
    );

    // Statement position (value discarded) + expression position (let RHS).
    let out = run_source_seed(
        "fn h(y: i64) { match y { 0 => 1, _ => 2 }; 42 } h(3)",
        "t.ktf",
    )
    .unwrap();
    assert_int(&out, 42, "statement position(value dropped)");
    let out = run_source_seed(
        "fn g(y: i64) { let x = match y { 0 => 1, _ => 2 }; x + 1 } g(3)",
        "t.ktf",
    )
    .unwrap();
    assert_int(&out, 3, "expression position(let right value)");
}

#[test]
fn match_m2_runtime_production_path() {
    // The production chain (target Reader → self-hosted expander →
    // self-hosted compiler → VM): the expander.ktf M-2 mirror runs real
    // match programs end-to-end.
    let out = run_source(
        "fn f(x: i64) { match x { 0 => 1, n if n < 0 => 0 - n, _ => 9 } } f(0 - 4)",
        "t.ktf",
    )
    .unwrap();
    assert_int(&out, 4, "production path -- guard hit");
    let out = run_source(
        "fn f(p: T) { match p { (a, b) => a + b, _ => 0 } } f(cons(3, 4))",
        "t.ktf",
    )
    .unwrap();
    assert_int(&out, 7, "production path -- pair destructuring");
    let out = run_source(
        "fn f(x: i64) { match x { 0 | 1 | 2 => 10, _ => 20 } } f(7)",
        "t.ktf",
    )
    .unwrap();
    assert_int(&out, 20, "production path -- or miss");
}

#[test]
fn match_m2_non_exhaustive_runtime_fallback() {
    // §4 defensive runtime fallback — the M-3 residual reachable class
    // (r123 / 193-a): the directly non-exhaustive forms are now E0025
    // compile-time rejections (match_m3_exhaustiveness_tests); what stays
    // reachable is the bool closed-domain exemption applied to a non-bool
    // scrutinee (the exemption is pattern-structural — the type side is
    // untyped at expansion, `eq` is any→any→bool through HM, so the
    // mis-typed scrutinee falls through to the runtime error: the
    // principle-42 double layer — compile-time conservative rules + the
    // type-side runtime guard).
    let err = run_source_seed("match (5) { true => 1, false => 0 }", "t.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Run);
    assert!(
        err.rendered.contains("match failed: no arm matched"),
        "seed path fallback diagnostic: {}",
        err.rendered
    );
    let err = run_source("match (5) { true => 1, false => 0 }", "t.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Run);
    assert!(
        err.rendered.contains("match failed: no arm matched"),
        "production path fallback diagnostic: {}",
        err.rendered
    );
    // The same leak through a str scrutinee (the exemption set is only
    // {true, false} — a str scrutinee matches neither arm).
    let err = run_source_seed("match (\"x\") { true => 1, false => 0 }", "t.ktf").unwrap_err();
    assert!(
        err.rendered.contains("match failed: no arm matched"),
        "string scrutinee fallback: {}",
        err.rendered
    );
}

// ---------------------------------------------------------------------------
// (4) Fail-closed negatives (arm shapes / pattern domain / or binding-map
// identity / duplicates / reserved-word bindings — mirrored message faces)
// ---------------------------------------------------------------------------

#[test]
fn match_m2_fail_closed_shapes() {
    // E6 (r154 / 224-b7): the arm-shape family is Reader-front-fenced on
    // the target face (match arms are grammatically `pattern [if guard]
    // => body` — the malformed-arm classes never reach the expander); the
    // legs keep their fail-closed anchors at the Reader layer, and the
    // dual-Reader message faces are covered by match_m4_krf_mirror_tests'
    // negative corpus.
    // Zero arms.
    assert!(
        read_err("match x { }", "zero arms").contains("needs at least one arm"),
        "zero arms"
    );
    // Non-list arm (a bare atom where the arm form is expected).
    assert!(
        read_err("match x { 0 }", "non-list arm").contains("expected =>"),
        "non-list arm"
    );
    // One-element arm (no body).
    assert!(
        read_err("match x { 0 => }", "one-element arm").contains("expected an expression"),
        "one-element arm"
    );
    // Four-element arm (two guards).
    assert!(
        read_err(
            "match x { 0 if (0 < 1) if (1 < 2) => 3 }",
            "four-element arm"
        )
        .contains("expected =>"),
        "four-element arm"
    );
}

#[test]
fn match_m2_fail_closed_pattern_domain() {
    // Ternary pattern list — Reader-front-fenced on the target face (the
    // "at most binary" grammar ruling; dual-Reader face covered by m4).
    assert!(
        read_err("match x { (a, b, c) => 1 }", "three-element pattern")
            .contains("at most two elements"),
        "three-element pattern"
    );
    // [E6 deleted leg] Single-element pattern list ((a) grouping): the
    // target Reader resolves `(p)` as grouped identity — the arm is a
    // plain binding pattern, the expander's single-element-grouping face is
    // unreachable from the target face (leg deleted + recorded, r154).
    // Vector pattern (TD-002 trigger family — out of domain): `[` is not a
    // pattern token — Reader-front-fenced.
    assert!(
        read_err("match x { [1, 2] => 1 }", "vector pattern").contains("expected a pattern"),
        "vector pattern"
    );
    // Reserved-word binding in pattern position (keyword tokens cannot
    // enter pattern position — Reader-front-fenced; the E0020 face was the
    // S-expr Reader's).
    assert!(
        read_err("match x { (if, 2) => 1 }", "reserved word binding")
            .contains("expected a pattern"),
        "reserved word binding"
    );
    assert!(
        read_err("match x { (match, 2) => 1 }", "match reserved word binding")
            .contains("expected a pattern"),
        "match reserved word binding"
    );
    // Duplicate binding within one pattern (expansion-reachable).
    assert!(
        seed_err("match x { (n, n) => 1 }", "duplicate binding")
            .contains("duplicate pattern binding"),
        "duplicate binding"
    );
    assert!(
        seed_err("match x { ((a, a), b) => 1 }", "nested duplicate binding")
            .contains("duplicate pattern binding"),
        "nested duplicate binding"
    );
}

#[test]
fn match_m2_fail_closed_or_binding_identity() {
    // Name-set mismatch ({} vs {n}).
    assert!(
        seed_err("match x { 0 | n => 1 }", "or name set mismatch")
            .contains("or pattern binding set mismatch"),
        "or name set mismatch"
    );
    // Same names, different sub-pattern kinds (a vs (a, 0) — path differs).
    assert!(
        seed_err("match x { a | (a, 0) => 1 }", "or form mismatch")
            .contains("or pattern binding set mismatch"),
        "or form mismatch"
    );
    // Same name bound at different positions (head vs tail).
    assert!(
        seed_err("match x { (a, 0) | (0, a) => 1 }", "or path mismatch")
            .contains("or pattern binding set mismatch"),
        "or path mismatch"
    );
    // The legal identity case parses and runs (control arm).
    let out = run_source_seed(
        "fn f(x: T) { match x { (a, 0) | (a, 1) => a, _ => 0 } } f(cons(9, 0))",
        "t.ktf",
    )
    .unwrap();
    assert_int(&out, 9, "or same position binding legal comparison arm");
}

#[test]
fn match_m2_fail_closed_mirror_message_faces() {
    // The expander.ktf mirror produces the identical diagnostic texts (the
    // canonical-shape contract includes the negative face). E6 (r154 /
    // 224-b7): the expansion-reachable structural families keep the
    // dual-path message-face anchor; the shape-family legs (zero arms /
    // ternary pattern / reserved-word binding / vector pattern) are
    // Reader-front-fenced on the target face — their dual-READER message
    // faces are match_m4_krf_mirror_tests' negative corpus.
    let cases: &[(&str, &str)] = &[
        ("match x { 0 | n => 1 }", "or pattern binding set mismatch"),
        ("match x { (n, n) => 1 }", "duplicate pattern binding"),
    ];
    for (src, needle) in cases {
        let seed = seed_err(src, "seed");
        let boot = bootstrap_err(src, "bootstrap");
        assert!(
            seed.contains(needle),
            "seed message lacks `{}`: {}",
            needle,
            seed
        );
        assert!(
            boot.contains(needle),
            "bootstrap message missing `{}`: {}",
            needle,
            boot
        );
        assert_eq!(seed, boot, "dual-path message face mismatch:{}", src);
    }
}

// ---------------------------------------------------------------------------
// (5) HM-check face integration (the desugar product infers through the
// existing checker — principle 42 compile-time orthogonality)
// ---------------------------------------------------------------------------

#[test]
fn match_m2_check_face_integration() {
    // Clean: a well-typed match program checks with zero diagnostics.
    let report = check_source_recover(
        "fn f(x: i64) { match x { 0 => 1, n if n < 0 => 0 - n, _ => 9 } } f(3)",
        "t.ktf",
    )
    .unwrap();
    assert!(
        report.diagnostics.is_empty(),
        "E0005 expected zero diagnostics: {:?}",
        report.rendered
    );
    // Negative: a type error inside an arm body is still diagnosed (the
    // desugar product flows through the ordinary HM inference).
    let report = check_source_recover(
        "fn f(x: i64) { match x { 0 => 1 + \"s\", _ => 9 } } f(3)",
        "t.ktf",
    )
    .unwrap();
    assert!(
        !report.diagnostics.is_empty(),
        "in-arm type errors should be diagnosed(E0005 channel orthogonality maintained)"
    );
}

// ---------------------------------------------------------------------------
// (6) Guard effect-order anchor (match-design §7 open question 2: guard
// effects are arm-internal — fired only after the structural test passes)
// ---------------------------------------------------------------------------

#[test]
fn match_m2_guard_effect_order_anchor() {
    // match-design §7 open question 2 anchor: guard effects are arm-internal
    // — fired only after the arm's structural test passes. The handler
    // resumes with `false` (guards are bool-typed conditions — the E0004
    // explicit-bool discipline, same family as if conditions): a fired
    // guard therefore REJECTS its arm. E6 note (r154 / 224-b7): perform is
    // statement-position on the target face, so the guard's raw perform is
    // wrapped in `ask()` — the fn's tail IS the perform, so `ask()`'s value
    // is the resumed value (the gating semantics preserved: the handler's
    // resumed `false` is the guard's value).
    //
    // Pair scrutinee: is-pair passes → the guard's perform fires → handled
    // → resumed false → the first arm is rejected → the second (pair) arm
    // binds → 1002 (≠ 1001: the rejection itself proves the effect fired
    // and the handler's resumed value gated the arm).
    let src = "fn ask() { perform stop; }\n\
                fn f(v: T) { handle (match v { (a, b) if ask() => 1001, (c, d) => 1002, _ => 0 }) { stop(p, r) => resume(false), } }\n\
                f(cons(1, 2))";
    let out = run_source_seed(src, "t.ktf").unwrap();
    assert_int(
        &out,
        1002,
        "guard effect inside arm trigger(structure test pass after -- handler false value veto first arm)",
    );

    // Non-pair scrutinee: the structural test fails → the guard (and its
    // head/tail extraction) is never reached — no effect, no head error,
    // the wildcard arm answers (a pre-structural guard evaluation would
    // have errored on (head 5) — this returning 0 pins the ordering).
    let src = "fn ask() { perform stop; }\n\
                fn f(v: T) { handle (match v { (a, b) if ask() => 1001, (c, d) => 1002, _ => 0 }) { stop(p, r) => resume(false), } }\n\
                f(5)";
    let out = run_source_seed(src, "t.ktf").unwrap();
    assert_int(
        &out,
        0,
        "guard effect not triggered(structural test failure short-circuit -- head extraction did not happen)",
    );

    // The same anchor through the production path.
    let src = "fn ask() { perform stop; }\n\
                fn f(v: T) { handle (match v { (a, b) if ask() => 1001, (c, d) => 1002, _ => 0 }) { stop(p, r) => resume(false), } }\n\
                f(cons(1, 2))";
    let out = run_source(src, "t.ktf").unwrap();
    assert_int(
        &out,
        1002,
        "production path -- guard effect inside arm trigger",
    );
}

// ---------------------------------------------------------------------------
// (7) The M-1 pass-through boundary dissolved (r121 / 191-a registered the
// pseudo-application boundary: "the failure point = the runtime unbound
// global match diagnostic; M-2 dissolves it" — this is the flip)
// ---------------------------------------------------------------------------

#[test]
fn match_m2_m1_boundary_dissolved() {
    // The M-1 boundary program now expands, compiles, and RUNS (the
    // unbound-global `match` diagnostic is gone — the desugar product
    // references no `match` global).
    let src = "fn f(x: i64) -> i64 { match x { 0 => 1, _ => 2 } }";
    let mut t = SymbolTable::new();
    let forms = read_source(src, 0, &mut t)
        .unwrap_or_else(|e| panic!("target syntax read failed:{}", e.message));
    let (program, t) = compile_forms_seed(&forms, t, "M-1 boundary flip");
    // The global-reference face contains no `match` (the pseudo-application
    // signature is gone).
    for g in &program.global_refs {
        assert_ne!(
            t.name(*g),
            "match",
            "desugared products must not reference globals match(pseudo-application signature residue)"
        );
    }
    // End-to-end: the program runs and returns the arm value.
    let out = run_source_seed(
        "fn f(x: i64) -> i64 { match x { 0 => 1, _ => 2 } } f(3)",
        "t.ktf",
    )
    .unwrap();
    assert_int(&out, 2, "M-1 boundary program run value");
}

// ---------------------------------------------------------------------------
// (8) Nested match hygiene anchor (arm-scope isolation — §3.3: arm bindings
// never leak; the temp is machine-reserved and globally unique per program)
// ---------------------------------------------------------------------------

#[test]
fn match_m2_nested_match_and_shadowing_anchor() {
    // A nested match inside an outer arm body: the inner temp is distinct
    // (globally monotonic uniquifier — no max-cardinality tie), and the
    // outer arm binding stays visible inside the inner match's arms.
    let out = run_source_seed(
        "fn f(x: T) {\n\
           match x { (a, b) => match b { 0 => a, _ => 99 }, _ => 0 }\n\
           }\n\
         f(cons(7, 0))",
        "t.ktf",
    )
    .unwrap();
    assert_int(
        &out,
        7,
        "nested match -- outer arm binding visible in the inner arm body",
    );

    // Arm-scope isolation: the arm binding `n` does not leak into the rest
    // chain — a later arm referencing a free `n` resolves to the OUTER
    // binding (define), not the earlier arm's pattern binding (the guard
    // rejects the first arm: n = scrutinee 7 there, outer n = 5 — leakage
    // would yield 17, the correct outer resolution yields 15).
    let out = run_source_seed(
        "fn g(n: i64) -> i64 { match (7) { n if n < 3 => 1, _ => n + 10 } } g(5)",
        "t.ktf",
    )
    .unwrap();
    assert_int(
        &out,
        15,
        "arm binding zero leak -- after arm from by n parse outer definition(5 + 10)",
    );

    // The guard rejection path: same isolation through the guard-false arm
    // (outer n = 9, scrutinee = 7 — the leaked reading would be 17).
    let out = run_source_seed(
        "fn g(n: i64) -> i64 { match (7) { n if n < 5 => 100, _ => n + 10 } } g(9)",
        "t.ktf",
    )
    .unwrap();
    assert_int(
        &out,
        19,
        "guard veto -- after arm n still parse outer(9 + 10)",
    );
}

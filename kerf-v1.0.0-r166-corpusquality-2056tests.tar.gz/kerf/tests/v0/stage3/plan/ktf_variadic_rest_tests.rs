//! .ktf variadic rest-parameter family tests — r165 / 236 (TD-038: the
//! variadic function FACE — `fn f(a: T, ...rest: T)`, the JS/TS/Rust-pattern
//! rest form; the `...` lexeme rides the r129 ninth skin-mapping identifier
//! payload — zero lexer change; the marker flows Reader→Stx sig→expander
//! parse_params→CoreExpr::Fn.rest→IrNode/BcProto.rest_slot→the VM
//! frame-setup pair-chain fold + min-arity gates at all three call sites +
//! the eval tree-walk mirror + the HM/check faces (Ty::Arrow rest / the
//! tfun marker convention); variadic-rest-design.md v1.0 D1-D6).
//!
//! **Verification surfaces** (8 positives : 24 negatives = 1:3):
//! (1) **run-face E2E** — the rest binding's pair-chain shape (nil for
//! zero excess / spine walk for extras) / mixed argument counts through
//! one fn / the closure rest face (the `||(base: T, ...more: T)` param
//! grammar sharing) / the **inline kerf append proof artifact** (D7-a' —
//! the parked migration's implementation-proven carrier: the TD-041
//! re-gating's E2E + byte-level error-face parity evidence, the r164
//! member/assoc "proven then parked" discipline mirrored) / the check
//! static-clean face for valid variadic calls / the r164 boundary
//! regression (the five migrated list faces + member/assoc maintained);
//! (2) **fail-closed negatives** — the Reader structural family ×6
//! (non-terminal rest / double rest — both shapes feed the must-be-last
//! law; bare `...`; missing type annotation; the closure face's same
//! two shapes) + the VM min-arity "expected at least N" face ×3 (Call /
//! the tail-recursive TailCall site / the closure entry) + the
//! fixed-arity exact face preserved bit-for-bit ×1 + the check static
//! "≥N" face ×2 + the append error faces byte-anchored ×3 ("append # N
//! requires list, got TYPE") + the improper-chain walk ×1 + E0022
//! unbound ×2 (the `...` outside parameter position + the r164
//! unimported nth) + E0019 unknown import ×1 + E0006 capability ×1 +
//! the r162 mixed-domain boundary regression ×1 + the r164 error-face
//! regressions ×2 (length / member) — 6 error code classes
//! (E0001/E0004/E0005/E0006/E0019/E0022 — ≥6/7, the sub-stage bar).
//!
//! Honest-boundary anchors (design D9): no call-site spread syntax
//! (`f(xs...)` is outside this window's domain — passing a chain as ONE
//! argument re-chains it, the probe-verified semantics); excess argument
//! types are unconstrained at the check face (no element-type face); the
//! append full migration stays parked on the Rust registration (TD-041 —
//! the seed corpora's hot-path consumption + the injection/registration
//! mutual exclusion, probe-verified this window).

use kerf_driver::{check_source_recover, run_source};

fn run_rendered(src: &str) -> String {
    let out = run_source(src, "vr.ktf").expect("run must succeed");
    kerf_vm::render_value(&out.value, &out.heap)
}

fn run_err_contains(src: &str, needle: &str) {
    let err = run_source(src, "vrneg.ktf").expect_err("run must fail");
    assert!(
        err.rendered.contains(needle),
        "runtime error must contain `{}`: {}\nsrc: {}",
        needle,
        err.rendered,
        src
    );
}

fn read_err_contains(src: &str, needle: &str) {
    let err = run_source(src, "vrread.ktf").expect_err("run must fail");
    assert!(
        err.rendered.contains(needle),
        "read error must contain `{}`: {}\nsrc: {}",
        needle,
        err.rendered,
        src
    );
}

fn check_err_contains(src: &str, needle: &str) {
    let report = check_source_recover(src, "vrchk.ktf").expect("check must produce a report");
    assert!(
        report
            .diagnostics
            .iter()
            .any(|d| d.message.contains(needle)),
        "check report must contain `{}`: {:?}\nsrc: {}",
        needle,
        report.rendered,
        src
    );
}

fn static_clean(src: &str) {
    let report = check_source_recover(src, "vrsc.ktf").expect("check must pass compile");
    assert!(
        report.diagnostics.is_empty(),
        "must be static-clean: {:?}\nsrc: {}",
        report.rendered,
        src
    );
}

/// The inline kerf append implementation — the D7-a' proof artifact (the
/// parked migration's "implementation proven" carrier: the exact
/// implementation that would ride bootstrap/list.ktf once TD-041's triggers
/// land — the retired Rust face's semantics replicated, the r101 171-c
/// settlement shapes included; the error faces byte-identical). Structure
/// discipline: every helper tail-recursive (TD-022), nesting ≤2, single
/// responsibility, kl_ private-name family.
const APPEND_IMPL: &str = "\
import kerf_string, kerf_list;
let kl_va_digits = list(\"0\", \"1\", \"2\", \"3\", \"4\", \"5\", \"6\", \"7\", \"8\", \"9\");
fn kl_va_type_name(x: T) {
    if (is_nil(x)) { \"nil\" } else {
    if (is_bool(x)) { \"bool\" } else {
    if (is_int(x)) { \"int\" } else {
    if (is_float(x)) { \"float\" } else {
    if (is_string(x)) { \"str\" } else {
    if (is_symbol(x)) { \"symbol\" } else {
    if (is_vector(x)) { \"vector\" } else {
    if (is_procedure(x)) { \"procedure\" } else {
    if (is_pair(x)) { \"pair\" } else { \"unit\" }
    }}}}}}}}
}
fn kl_va_append(...lists: T) {
    if (is_nil(lists)) {
        ()
    } else {
        if (is_nil(tail(lists))) {
            head(lists)
        } else {
            let rev_elems = kl_va_flat_leading(lists, 1, ());
            if (is_nil(rev_elems)) {
                kl_va_last(lists)
            } else {
                kl_va_build_go(rev_elems, kl_va_last(lists))
            }
        }
    }
}
fn kl_va_flat_leading(lists: T, i: T, acc: T) {
    if (is_nil(tail(lists))) {
        acc
    } else {
        kl_va_flat_one(head(lists), i, tail(lists), acc)
    }
}
fn kl_va_flat_one(x: T, i: T, rest_lists: T, acc: T) {
    if (is_nil(x)) {
        kl_va_flat_leading(rest_lists, i + 1, acc)
    } else {
        if (is_pair(x)) {
            kl_va_flat_one(tail(x), i, rest_lists, cons(head(x), acc))
        } else {
            error(string_append(string_append(string_append(
                \"append # \", kl_va_int_str(i)), \" requires list, got \"), kl_va_type_name(x)))
        }
    }
}
fn kl_va_int_str_go(n: T) {
    if (n < 10) {
        nth(kl_va_digits, n)
    } else {
        string_append(kl_va_int_str_go(n / 10), nth(kl_va_digits, mod(n, 10)))
    }
}
fn kl_va_int_str(n: T) {
    if (n < 0) {
        string_append(\"-\", kl_va_int_str_go(0 - n))
    } else {
        kl_va_int_str_go(n)
    }
}
fn kl_va_last(lists: T) {
    if (is_nil(tail(lists))) {
        head(lists)
    } else {
        kl_va_last(tail(lists))
    }
}
fn kl_va_build_go(rev_elems: T, tailv: T) {
    if (is_nil(rev_elems)) {
        tailv
    } else {
        kl_va_build_go(tail(rev_elems), cons(head(rev_elems), tailv))
    }
}
";

// ---------------------------------------------------------------------------
// Positives (8)
// ---------------------------------------------------------------------------

/// P01: the rest binding's pair-chain shape — zero excess binds nil, one
/// excess binds a one-element chain (the frame-setup fold's value faces).
#[test]
fn p01_rest_binds_pair_chain() {
    assert_eq!(
        run_rendered("fn probe(...xs: T) { if (is_nil(xs)) { 0 } else { 1 } }\nprobe()"),
        "0"
    );
    assert_eq!(
        run_rendered("fn probe(...xs: T) { if (is_nil(xs)) { 0 } else { 1 } }\nprobe(5)"),
        "1"
    );
    static_clean("fn probe(...xs: T) { if (is_nil(xs)) { 0 } else { 1 } }\nprobe(5)");
}

/// P02: mixed argument counts through one fn — the minimum with zero
/// excess through five extras (the fixed prefix + the folded chain).
#[test]
fn p02_mixed_arg_counts() {
    let src = "fn kl_sum(xs: T) { if (is_nil(xs)) { 0 } else { head(xs) + kl_sum(tail(xs)) } }\nfn sum_rest(...nums: T) { kl_sum(nums) }\n";
    assert_eq!(run_rendered(&format!("{src}sum_rest()")), "0");
    assert_eq!(run_rendered(&format!("{src}sum_rest(1)")), "1");
    assert_eq!(run_rendered(&format!("{src}sum_rest(1, 2, 3, 4, 5)")), "15");
}

/// P03: the closure rest face — `||(base: T, ...more: T) { ... }` shares
/// the parameter grammar with fn declarations (D1-d).
#[test]
fn p03_closure_rest_face() {
    let src = "fn kl_sum(xs: T) { if (is_nil(xs)) { 0 } else { head(xs) + kl_sum(tail(xs)) } }\nlet adder = ||(base: T, ...more: T) { kl_sum(more) + base };\n";
    assert_eq!(run_rendered(&format!("{src}adder(100)")), "100");
    assert_eq!(run_rendered(&format!("{src}adder(100, 1, 2)")), "103");
}

/// P04: the inline append proof — zero args → nil; one arg → as-is (the
/// r101 171-c settlement: atoms pass through, chains pass through shared).
#[test]
fn p04_append_inline_zero_one() {
    assert_eq!(run_rendered(&format!("{APPEND_IMPL}kl_va_append()")), "nil");
    assert_eq!(run_rendered(&format!("{APPEND_IMPL}kl_va_append(5)")), "5");
    assert_eq!(
        run_rendered(&format!("{APPEND_IMPL}kl_va_append(list(1, 2))")),
        "(1 2)"
    );
}

/// P05: the inline append proof — the n-arg splice (fresh leading chain +
/// the shared last arg) and the all-leading-empty → last-as-is shape.
#[test]
fn p05_append_inline_splice() {
    assert_eq!(
        run_rendered(&format!("{APPEND_IMPL}kl_va_append(list(1, 2), list(3))")),
        "(1 2 3)"
    );
    assert_eq!(
        run_rendered(&format!(
            "{APPEND_IMPL}kl_va_append(list(1, 2), list(3), list(4, 5))"
        )),
        "(1 2 3 4 5)"
    );
    // all-leading-empty → the last arg as-is (nil → nil; a chain → itself)
    assert_eq!(
        run_rendered(&format!("{APPEND_IMPL}kl_va_append(list(), list(3))")),
        "(3)"
    );
    assert_eq!(
        run_rendered(&format!("{APPEND_IMPL}kl_va_append(list(), list())")),
        "nil"
    );
}

/// P06: the rest chain's structure — head/tail walk the excess arguments
/// in call order (the right-fold construction discipline).
#[test]
fn p06_rest_chain_structure() {
    assert_eq!(
        run_rendered("fn second_of(...xs: T) { head(tail(xs)) }\nsecond_of(10, 20, 30)"),
        "20"
    );
    assert_eq!(
        run_rendered("fn first_of(...xs: T) { head(xs) }\nfirst_of(10, 20, 30)"),
        "10"
    );
}

/// P07: the check static-clean face — a valid variadic program passes the
/// production check (the tfun marker's prefix unification).
#[test]
fn p07_check_static_clean_variadic() {
    static_clean("fn need2(a: T, b: T, ...rest: T) { a + b }\nneed2(1, 2)\nneed2(1, 2, 3, 4)");
    static_clean("fn cnt(...xs: T) { if (is_nil(xs)) { 0 } else { 1 } }\ncnt()\ncnt(1, 2)");
}

/// P08: the r164 boundary regression — the five migrated list faces E2E +
/// member/assoc maintained (the prior window's faces coexist with the
/// variadic mechanism unchanged).
#[test]
fn p08_r164_boundary_regression() {
    assert_eq!(
        run_rendered("import kerf_list;\nlength(list(1, 2, 3, 4, 5))"),
        "5"
    );
    assert_eq!(
        run_rendered("import kerf_list;\nreverse(list(1, 2, 3))"),
        "(3 2 1)"
    );
    assert_eq!(
        run_rendered("import kerf_list;\nnth(list(10, 20, 30), 1)"),
        "20"
    );
    assert_eq!(
        run_rendered("import kerf_list;\ndrop(list(10, 20, 30), 1)"),
        "(20 30)"
    );
    assert_eq!(
        run_rendered("import kerf_list;\nlast_pair(list(1, 2, 3))"),
        "(3)"
    );
    // member/assoc stay Rust-registered (the r164 performance-boundary
    // half) — the maintained faces coexist with the variadic window.
    assert_eq!(
        run_rendered("import kerf_list;\nmember(2, list(1, 2, 3))"),
        "(2 3)"
    );
}

// ---------------------------------------------------------------------------
// Negatives (24)
// ---------------------------------------------------------------------------

// —— The Reader structural family (E0001 ×6) ——

/// N01: a rest parameter followed by a fixed parameter — the terminal law.
#[test]
fn neg_rest_not_last() {
    read_err_contains(
        "fn f(...a: T, b: T) { a }",
        "the rest parameter must be the last parameter",
    );
}

/// N02: double rest — the same terminal law (the second `...` rides the
/// comma continuation).
#[test]
fn neg_double_rest() {
    read_err_contains(
        "fn f(...a: T, ...b: T) { a }",
        "the rest parameter must be the last parameter",
    );
}

/// N03: bare `...` with no binding name.
#[test]
fn neg_bare_ellipsis() {
    read_err_contains(
        "fn f(...) { 1 }",
        "expected a rest parameter name after `...`, got RParen",
    );
}

/// N04: the rest name without a type annotation — the shared `:` contract.
#[test]
fn neg_rest_missing_type() {
    read_err_contains("fn f(...a) { a }", "expected :, got RParen");
}

/// N05: the closure face's non-terminal rest (the shared parameter grammar).
#[test]
fn neg_closure_rest_not_last() {
    read_err_contains(
        "let g = ||(...a: T, b: T) { a };",
        "the rest parameter must be the last parameter",
    );
}

/// N06: the closure face's double rest.
#[test]
fn neg_closure_double_rest() {
    read_err_contains(
        "let g = ||(...a: T, ...b: T) { a };",
        "the rest parameter must be the last parameter",
    );
}

// —— The VM min-arity family (E0004 ×4 + the preserved exact face) ——

/// N07: zero arguments against a one-fixed minimum — the "at least" face.
#[test]
fn neg_vm_min_arity_zero() {
    run_err_contains(
        "fn need1(a: T, ...rest: T) { a }\nneed1()",
        "procedure argument count mismatch: expected at least 1, got 0",
    );
}

/// N08: a partial call below a two-fixed minimum.
#[test]
fn neg_vm_min_arity_partial() {
    run_err_contains(
        "fn need2(a: T, b: T, ...rest: T) { a + b }\nneed2(1)",
        "procedure argument count mismatch: expected at least 2, got 1",
    );
}

/// N09: the tail-recursive call site's min-arity face (the TailCall frame
/// replacement path carries the same gate).
#[test]
fn neg_vm_tailcall_min_arity() {
    run_err_contains(
        "fn countdown(n: T, ...rest: T) { if (n == 0) { 0 } else { countdown() } }\ncountdown(3)",
        "procedure argument count mismatch: expected at least 1, got 0",
    );
}

/// N10: the fixed-arity exact face preserved bit-for-bit (D4-a — the
/// pre-r165 message form untouched).
#[test]
fn neg_fixed_exact_face_preserved() {
    run_err_contains(
        "fn pair2(a: T, b: T) { a }\npair2(1, 2, 3)",
        "procedure argument count mismatch: expected 2, got 3",
    );
}

// —— The check static family (E0005 ×2) ——

/// N11: the static "≥N" face — the production check's too-few diagnostic.
#[test]
fn neg_check_static_too_few() {
    check_err_contains(
        "fn need2(a: T, b: T, ...rest: T) { a + b }\nneed2(1)",
        "procedure argument count mismatch: expected ≥2, got 1 (static check)",
    );
}

/// N12: the fixed-arity static face preserved (the closure's exact form).
#[test]
fn neg_check_static_fixed_exact() {
    check_err_contains(
        "let h = ||(a: T) { a };\nh(1, 2)",
        "procedure argument count mismatch: expected 1, got 2 (static check)",
    );
}

// —— The inline append error faces (E0004 ×4 — byte-anchored) ——

/// N13: a non-list FIRST argument (the position-indexed face — # 1).
#[test]
fn neg_append_nonlist_first() {
    run_err_contains(
        &format!("{APPEND_IMPL}kl_va_append(5, list(1))"),
        "append # 1 requires list, got int",
    );
}

/// N14: a non-list MIDDLE argument (the position index advances — # 2).
#[test]
fn neg_append_nonlist_mid() {
    run_err_contains(
        &format!("{APPEND_IMPL}kl_va_append(list(1), \"x\", list(2))"),
        "append # 2 requires list, got str",
    );
}

/// N15: a non-list leading argument in the three-arg shape (a float
/// leading slot — the type name rides the message).
#[test]
fn neg_append_nonlist_float() {
    run_err_contains(
        &format!("{APPEND_IMPL}kl_va_append(list(1), 2.5, list(3))"),
        "append # 2 requires list, got float",
    );
}

/// N16: an IMPROPER leading chain — the walk hits the atom tail and
/// reports the same position-indexed face (the spine walk's mid-chain
/// rejection).
#[test]
fn neg_append_improper_chain() {
    run_err_contains(
        &format!("{APPEND_IMPL}kl_va_append(cons(1, 2), list(3))"),
        "append # 1 requires list, got int",
    );
}

// —— The name-resolution + module + capability family (E0022 ×2, E0019,
// E0006) ——

/// N17: the `...` outside parameter position — an unbound reference (the
/// marker lives only in the parameter grammar).
#[test]
fn neg_ellipsis_expr_unbound() {
    run_err_contains("let x = ...;", "unbound reference: `...`");
}

/// N18: the r164 boundary regression — unimported nth (E0022).
#[test]
fn neg_unimported_nth_regression() {
    run_err_contains("nth(list(1, 2), 0)", "unbound reference: `nth`");
}

/// N19: an unknown module import (E0019 — the module-dependency class).
#[test]
fn neg_unknown_import() {
    read_err_contains("import kerf_nope;", "unknown imported module");
}

/// N20: the capability gate (E0006) — print without the require grant is
/// unaffected by the variadic window.
#[test]
fn neg_capability_gate() {
    run_err_contains("print(1);", "insufficient capability permission");
}

// —— The prior-window boundary regressions (r162/r164 error faces) ——

/// N21: the r162 mixed-domain boundary — `1 == "1"` is silent false (the
/// one-equality-law user-wide; no E0004/E0005 diagnostics on this path).
#[test]
fn neg_r162_mixed_domain_regression() {
    assert_eq!(run_rendered("1 == \"1\""), "false");
}

/// N22: the r164 length error face — byte-anchored (the migrated faces'
/// error contract coexists with the variadic mechanism).
#[test]
fn neg_r164_length_error_face() {
    run_err_contains(
        "import kerf_list;\nlength(5)",
        "length requires list(nil terminated pair chain), got int",
    );
}

/// N23: the r164 member maintained face — the Rust-registered half's
/// error contract.
#[test]
fn neg_r164_member_error_face() {
    run_err_contains(
        "import kerf_list;\nmember(1, 5)",
        "member second argument requires list",
    );
}

/// N24: the r164 last-pair non-empty face — another migrated error
/// contract anchor.
#[test]
fn neg_r164_last_pair_error_face() {
    run_err_contains(
        "import kerf_list;\nlast_pair(())",
        "last-pair requires non-empty list",
    );
}

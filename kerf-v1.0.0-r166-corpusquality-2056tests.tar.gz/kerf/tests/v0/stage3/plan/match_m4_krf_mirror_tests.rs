//! match implementation batch M-4 — .krf mirror grammar-batch tests
//! (r124 / 194-a).
//!
//! **Verification surfaces** (match-design.md v1.4 §6 batch table — the
//! M-4 acceptance gate: lexical parity maintained + grammar parity added,
//! the dual-Reader divergence window M-1..M-3 closed with the anchor
//! flip): (1) **grammar parity positives** — the seed Reader
//! (kerf-reader/target.rs, r121) vs the .krf mirror (bootstrap/
//! reader.krf, r108 + the r124 match arm) produce byte-identical
//! canonical Stx renderings (symbol names + literal values + Span bytes —
//! same-source, both sides; the r106 SyntaxTransitionValidator discipline
//! applied to the mirror pair); (2) **grammar parity negatives** — the
//! fail-closed family with message + Span byte-level equality (the full
//! r121 negative corpus re-run through the mirror: zero arms / at-most-
//! binary / the three or-comma mixups / qualified-name / missing =>
//! unclosed / non-pattern token / missing separator / depth cap 9);
//! (3) **lexical parity maintained** — the match corpus at the token
//! level (the lexer layer untouched by the grammar batch); (4) **cross-
//! stage consumption** — a mirror-read match program flows through the
//! production chain (bootstrap Expander → bootstrap Compiler → VM) and
//! executes with the M-2 desugar semantics.
//!
//! Basis: match-design.md v1.4 §6 (M-4 row — step-2 grammar-batch carry) /
//! principle 31 (skin/skeleton isomorphism — the grammar arm bilaterally
//! isomorphic) / principle 43 (progressive disclosure — red line 4: no
//! window merging) / switch-window-plan v1.9 §5 (the mirror grammar
//! face) / §9.4.3 (positive:negative ≥ 1:3).

use kerf_compiler::compile_module;
use kerf_driver::bootstrap::expander::expand_program;
use kerf_driver::bootstrap::reader::{lex_for_bootstrap, read_source_for_bootstrap};
use kerf_driver::builtins::register_globals;
use kerf_driver::capability::IoGrant;
use kerf_reader::reader::read_source;
use kerf_reader::{lex_for_parity, ParityToken};
use kerf_runtime::Heap;
use kerf_syntax::{Stx, StxDatum, StxLiteral, SymbolTable};
use kerf_vm::{run_program, Value};

// ---------------------------------------------------------------------------
// Helpers (the target_reader_krf_tests.rs caliber — canonical rendering
// with Span bytes; error parity with message + Span byte equality)
// ---------------------------------------------------------------------------

/// Stx-tree canonical rendering (symbol names + literal values + Span
/// bytes — comparable across both sides for same-source text).
fn render_stx(s: &Stx, t: &SymbolTable) -> String {
    let mut out = String::new();
    render_stx_into(s, t, &mut out);
    out
}

fn render_stx_into(s: &Stx, t: &SymbolTable, out: &mut String) {
    match &s.datum {
        StxDatum::Symbol(sym) => {
            out.push_str(&format!(
                "(sym {} {}..{})",
                t.name(*sym),
                s.span.start,
                s.span.end
            ));
        }
        StxDatum::Literal(l) => match l {
            StxLiteral::Int(v) => {
                out.push_str(&format!("(int {} {}..{})", v, s.span.start, s.span.end));
            }
            StxLiteral::Float(f) => {
                out.push_str(&format!("(float {:?} {}..{})", f, s.span.start, s.span.end));
            }
            StxLiteral::Str(r) => {
                out.push_str(&format!("(str {:?} {}..{})", r, s.span.start, s.span.end));
            }
            StxLiteral::Bool(b) => {
                out.push_str(&format!("(bool {} {}..{})", b, s.span.start, s.span.end));
            }
            StxLiteral::Nil => {
                out.push_str(&format!("(nil {}..{})", s.span.start, s.span.end));
            }
        },
        StxDatum::List(items) => {
            out.push_str(&format!("(lst {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
        // r138 / 208-c — TD-002: vectors now reach both Readers (the
        // fourteenth skin mapping) — full canonical rendering
        StxDatum::Vector(items) => {
            out.push_str(&format!("(vec {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
    }
}

/// Grammar parity assertion: both Readers' canonical renderings are
/// byte-identical (the M-4 core gate — the divergence window is closed).
fn assert_grammar_parity(src: &str, what: &str) {
    let mut t1 = SymbolTable::new();
    let seed = read_source(src, 0, &mut t1)
        .unwrap_or_else(|e| panic!("[{}] seed syntax failed: {}", what, e.message));
    let mut t2 = SymbolTable::new();
    let mirror = read_source_for_bootstrap(src, 0, &mut t2)
        .unwrap_or_else(|e| panic!("[{}] mirror syntax failed:{}", what, e.message));
    assert_eq!(
        seed.len(),
        mirror.len(),
        "[{}] top-level item count mismatch (seed {} vs mirror {})",
        what,
        seed.len(),
        mirror.len()
    );
    for (i, (a, b)) in seed.iter().zip(mirror.iter()).enumerate() {
        assert_eq!(
            render_stx(a, &t1),
            render_stx(b, &t2),
            "[{}] top-level item #{} syntax tree mismatch (seed vs mirror canonical render)",
            what,
            i
        );
    }
}

/// Grammar-error parity assertion: message + Span byte-level equality
/// (the mirror's diagnostic face is the seed's, by construction — the
/// r121 message corpus).
fn assert_grammar_err_parity(src: &str, what: &str) {
    let mut t1 = SymbolTable::new();
    let seed_err = match read_source(src, 0, &mut t1) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] seed should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    let mut t2 = SymbolTable::new();
    let mirror_err = match read_source_for_bootstrap(src, 0, &mut t2) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] mirror should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    assert_eq!(
        seed_err.message, mirror_err.message,
        "[{}] syntax error message mismatch (seed {:?} vs mirror {:?})",
        what, seed_err.message, mirror_err.message
    );
    assert_eq!(
        seed_err.span.start, mirror_err.span.start,
        "[{}] syntax error Span start mismatch (seed {} vs mirror {})",
        what, seed_err.span.start, mirror_err.span.start
    );
    assert_eq!(
        seed_err.span.end, mirror_err.span.end,
        "[{}] syntax error Span end mismatch (seed {} vs mirror {})",
        what, seed_err.span.end, mirror_err.span.end
    );
}

/// Lexical parity assertion (kind/Span/payload byte-level equality — the
/// grammar batch leaves the lexer layer untouched; maintained-face proof).
fn assert_lex_parity(src: &str, what: &str) {
    let seed = lex_for_parity(src, 0)
        .unwrap_or_else(|e| panic!("[{}] seed lexical failed: {}", what, e.message));
    let mirror = lex_for_bootstrap(src, 0)
        .unwrap_or_else(|e| panic!("[{}] mirror lexical failed:{}", what, e.message));
    assert_eq!(seed.len(), mirror.len(), "[{}] Token count mismatch", what);
    for (i, (a, b)) in seed.iter().zip(mirror.iter()).enumerate() {
        let a: &ParityToken = a;
        let b: &ParityToken = b;
        assert_eq!(a.kind, b.kind, "[{}] Token #{} kind mismatch", what, i);
        assert_eq!(a.start, b.start, "[{}] Token #{} start mismatch", what, i);
        assert_eq!(a.end, b.end, "[{}] Token #{} end mismatch", what, i);
        assert_eq!(
            a.payload, b.payload,
            "[{}] Token #{} payload mismatch",
            what, i
        );
    }
}

// ---------------------------------------------------------------------------
// (1) Grammar parity positives — the divergence window is closed
// ---------------------------------------------------------------------------

#[test]
fn match_m4_grammar_parity_family() {
    // The M-1 corpus re-run through the mirror pair (byte-level Stx with
    // Spans — every r121 structural ruling carried bilaterally).
    assert_grammar_parity(
        "fn f(x: i64) -> i64 { match x { 0 => 1, _ => 9 } }\nf(3)",
        "basic family",
    );
    assert_grammar_parity(
        "fn f(x: i64) -> i64 { match x { 0 => 0, n if n < 0 => 0 - 1, _ => 9 } }",
        "guard family",
    );
    assert_grammar_parity(
        "match p { (a, b) => a, ((0 | 1), c) => c, () => 7, 1.5 => 8, \"s\" => 9, true => 1 }",
        "full pattern family",
    );
    assert_grammar_parity("match x { 0 | 1 | 2 => 10, _ => 20 }", "or tag family");
    assert_grammar_parity(
        "match q { ((a, b), c) => a, (a, (b, c)) => b }",
        "nested pair family",
    );
    assert_grammar_parity(
        "fn f(x: i64) -> i64 { match x { my_var => my_var, _ => 0 } }",
        "naming map family",
    );
    // Comma discipline: trailing comma optional, separators mandatory.
    assert_grammar_parity("match x { 0 => 1, _ => 2, }", "has trailing comma");
    assert_grammar_parity("match x { 0 => 1,\n           _ => 2 }", "cross-line arm");
    // Depth 8 legal (the defensive cap boundary — inside the domain).
    assert_grammar_parity("match x { ((((((((a, b)))))))) => 1 }", "depth 8 legal");
}

#[test]
fn match_m4_grammar_parity_positions() {
    // The M-1 positional forms re-run through the mirror pair: statement
    // position (do threading), block-tail expression, expression
    // position (let RHS), top-level, compound scrutinee.
    assert_grammar_parity(
        "fn f(x: i64) { match x { 0 => 1, _ => 2 } match x { 1 => 3, _ => 4 } }",
        "statement position do threading",
    );
    assert_grammar_parity(
        "fn f(x: i64) -> i64 { let y = 1; match x { 0 => y, _ => y + 1 } }",
        "block-tail expression position",
    );
    assert_grammar_parity(
        "fn g(y: i64) -> i64 { let x = match y { 0 => 1, _ => 2 }; x + 1 }",
        "let right value expression position",
    );
    assert_grammar_parity("match 0 { 0 => 1, _ => 2 }", "top-level position");
    assert_grammar_parity(
        "fn h(y: i64) -> i64 { match (y + 1) * 2 { 0 => 1, _ => 9 } }",
        "scrutinee compound expression",
    );
    // The expression-position dispatch inside a primary slot (the r110
    // if-precedent isomorphic site — the mirror's parse-primary arm).
    assert_grammar_parity(
        "fn k(x: i64) -> i64 { 1 + match x { 0 => 10, _ => 20 } }",
        "primary position binary right element",
    );
}

// ---------------------------------------------------------------------------
// (2) Grammar parity negatives — the full r121 fail-closed corpus through
// the mirror (message + Span byte-level equality)
// ---------------------------------------------------------------------------

#[test]
fn match_m4_negative_zero_arms() {
    assert_grammar_err_parity("match x { }", "zero arms");
}

#[test]
fn match_m4_negative_ternary_pattern() {
    // At most binary (the "right non-nesting" ruling — 3+ comma elements).
    assert_grammar_err_parity("match x { (a, b, c) => 1 }", "three-element pattern");
}

#[test]
fn match_m4_negative_bare_or_then_comma() {
    assert_grammar_err_parity("match x { 0 | 1, 2 => 1 }", "bare or mixed comma");
}

#[test]
fn match_m4_negative_grouped_or_then_comma() {
    assert_grammar_err_parity(
        "match x { (0 | 1, 2) => 1 }",
        "inside parentheses or mixed comma",
    );
}

#[test]
fn match_m4_negative_right_slot_or() {
    assert_grammar_err_parity("match x { (a, b | c) => 1 }", "right element or");
}

#[test]
fn match_m4_negative_qualified_name_pattern() {
    assert_grammar_err_parity("match x { a::b => 1 }", "qualified name pattern");
}

#[test]
fn match_m4_negative_missing_fatarrow() {
    assert_grammar_err_parity("match x { 0 1 }", "missing =>");
}

#[test]
fn match_m4_negative_unclosed_brace() {
    assert_grammar_err_parity("match x { 0 => 1", "unclosed");
}

#[test]
fn match_m4_negative_non_pattern_token() {
    assert_grammar_err_parity("match x { => 1 }", "non-pattern Token");
}

#[test]
fn match_m4_negative_missing_arm_separator() {
    assert_grammar_err_parity("match x { 0 => 1 _ => 2 }", "missing arm separator");
}

#[test]
fn match_m4_negative_depth_cap_nine() {
    // Depth 9 rejected (match-design.md §1 defensive cap — depth > 8).
    assert_grammar_err_parity("match x { ((((((((((a, b))))))))) => 1 }", "pair depth 9");
    // The cap applies to or-alternative atoms too (parenthesized depth).
    assert_grammar_err_parity("match x { ((((((((((0 | 1))))))))) => 1 }", "or depth 9");
}

// ---------------------------------------------------------------------------
// (3) Lexical parity maintained — the grammar batch leaves the lexer alone
// ---------------------------------------------------------------------------

#[test]
fn match_m4_lexical_parity_maintained() {
    // The match corpus at the token level (kind/Span/payload byte
    // equality — the r107 lexical gate re-run on the new surface).
    assert_lex_parity(
        "fn f(x: i64) -> i64 { match x { 0 => 1, _ => 2 } }",
        "match basic lexing",
    );
    assert_lex_parity(
        "match p { (a, b) => a, ((0 | 1), c) => c, () => 7, 1.5 => 8 }",
        "pattern family lexical",
    );
    assert_lex_parity(
        "fn f(x: i64) -> i64 { match x { 0 => 0, n if n < 0 => 0 - 1, _ => 9 } }",
        "guard lexical",
    );
}

// ---------------------------------------------------------------------------
// (4) Cross-stage consumption — the mirror-read match program through the
// production chain (bootstrap Expander → bootstrap Compiler → VM)
// ---------------------------------------------------------------------------

#[test]
fn match_m4_mirror_read_production_chain_e2e() {
    // The M-4 consumer proof: a program whose READ stage went through the
    // .krf mirror Reader (previously match-capable only on the seed side)
    // expands via the self-hosted Expander (the M-2 expand_match desugar),
    // compiles via the self-hosted Compiler, and executes on the VM with
    // the full match semantics (guard / pair destructuring / or / first-
    // arm-wins / single-evaluation).
    let src = "fn fib(n: i64) -> i64 { if n < 2 { n } else { fib(n - 1) + fib(n - 2) } }\n\
               fn classify(n: i64) -> i64 { match n { 0 => 0, 1 | 2 => 10, m if m < 0 => 0 - 1, _ => 99 } }\n\
               fn pair_sum(a: i64, b: i64) -> i64 { match cons(a, b) { (x, y) => x + y, _ => 0 } }\n\
               fib(7) + classify(2) + classify(5) + classify(0 - 3) + pair_sum(30, 10)";
    let mut t = SymbolTable::new();
    let forms = read_source_for_bootstrap(src, 0, &mut t)
        .unwrap_or_else(|e| panic!("mirror read failed:{}", e.message));
    let core = expand_program(&forms, 0, &mut t)
        .unwrap_or_else(|e| panic!("bootstrap expansion failed: {}", e.message));
    let program =
        compile_module(&core).unwrap_or_else(|e| panic!("bootstrap compile failed:{}", e.message));
    let mut globals = register_globals(&mut t, &IoGrant::none());
    let mut heap = Heap::new();
    let v = run_program(&program, &mut globals, &mut heap)
        .unwrap_or_else(|e| panic!("VM execution failed:{}", e.message));
    // fib(7)=13 + classify(2)=10 + classify(5)=99 + classify(-3)=-1 +
    // pair_sum((30,10))=40 → 13+10+99-1+40 = 161.
    assert!(
        matches!(v, Value::Int(161)),
        "mirror chain match semantics should yield 161, got {:?}",
        v
    );
    // The hygiene face: repeated calls through a fresh VM round (the
    // match-scrut$hyg$N temp naming survives re-entry — single-evaluation
    // discipline is structural, not stateful).
    let mut g2 = register_globals(&mut t, &IoGrant::none());
    let mut h2 = Heap::new();
    let v2 = run_program(&program, &mut g2, &mut h2)
        .unwrap_or_else(|e| panic!("VM repeated execution failed:{}", e.message));
    assert!(
        matches!(v2, Value::Int(161)),
        "mirror chain re-execution should yield 161, got {:?}",
        v2
    );
}

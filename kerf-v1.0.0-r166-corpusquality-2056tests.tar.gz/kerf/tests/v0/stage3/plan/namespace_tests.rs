// E6 close-out (r154 / 224-b7b): converted to the target-syntax face.
//! Batch M first deliverable M1 (v0.6 namespace layer, r39) — N2
//! qualified-name visibility integration tests
//! (tests/v0/stage3/plan/ ↔ docs/lang-design/22-namespace-design.md §8
//! implementation-reconciliation rows R-N3/R-N4/R-N7/R-N8 +
//! 20-surface-conventions §5.1/§5.2 + 22 §5.1 matrix / §5.2 red line 1 +
//! §7 reserved domain).
//!
//! Coverage (§9.4.3 positive:negative ratio ≥1:3 — mostly negative):
//! - R-N3 no fallback: qualified names consult only the stdlib seven-face
//!   exports — a miss = the E0014 "not exported" compile-time diagnostic
//!   (not the runtime "unbound" — diagnostic-gain anchor);
//! - R-N4 lexical domain: standalone `/` stays division (`a / b`);
//!   `ns::name` is a single token (the target-surface `::` form maps to
//!   the `ns/name` symbol at the Reader boundary);
//! - R-N7 operators permanent: N1 bare names need zero import (explicit
//!   anchor that existing programs stay all-green);
//! - R-N8 symbol-universe exemption: quoted symbol values do not join
//!   resolution (existence ≠ visibility);
//! - 22 §5.1 matrix / red line 1: `io::` qualified-name dual-gate
//!   separation — name visibility (N2 registration) and operation
//!   permission (E0006 require) are independent: an unauthorized io
//!   qualified name → E0006 (fail-closed first); callable once authorized;
//! - 22 §7 reserved domain: a `kerf_`-prefixed module name = E0015 (user
//!   occupation violation);
//! - M1 narrowing, honestly anchored: user takeover (a define with a `::`
//!   name) is exempt from E0014;
//! - Static face: qualified-name signature derivation (check/hm judge
//!   `ns::name` the same way — E0005).
//!
//! E6 skin notes (target-syntax face, r154 / 224-b7b):
//! - inline programs are .ktf target syntax (`ns::member` qualified refs,
//!   `import kerf_x;` / `use kerf_x::{m};` / `require io, x;`
//!   declarations, `module m { ... }` blocks, `define(x, v);` call-form
//!   value defs, `fn f(p: i64) { ... }` declarations, `||(p: i64) { ... }`
//!   closures, `macro name() { (pat) => tmpl }` macro defs); the driver's
//!   Stx-layer diagnostics are face-shared, so the message substrings
//!   keep the S-expr-surface spellings (`kerf-string`, `string/append`,
//!   `io/print` — the runtime/diagnostic messages keep the kebab/slash
//!   forms);
//! - quoted-list datums have no target-surface literal (r127 honest
//!   boundary — the vm_tests precedent): list data is built at runtime
//!   via `list(...)`/`cons(...)`; symbol datums keep `quote(sym)`;
//! - keyword skin words (if/fn/let/module/import/require/...) are
//!   Reader-reserved Tokens on this face: the binding-position and
//!   expression-position disciplines they carried at the expand/compile
//!   stages (E0020 / E0002 / E0018 families) are lexically fronted to the
//!   read stage for those words, while the compile-level anchors in the
//!   same families use the shared non-skin reserved words (do/quote/
//!   assign — the same 28-name N4 table) so every diagnostic family keeps
//!   its compile-stage coverage;
//! - sub-assertions that were S-expr-surface-only and unconvertible are
//!   deleted and recorded in the worklog (fn parameters with `/` names,
//!   macro names with `/` names, the `set!` old-form reference, the
//!   letrec/let* binding flavors).

use crate::common;

use kerf_driver::{run_source, Stage};
use kerf_span::DiagnosticCode;

const FNAME: &str = "ns.ktf";

/// Compile-error assertion: stage Compile + diagnostic code + message substring.
fn expect_compile_err(src: &str, code: u32, msg: &str) {
    let e = match run_source(src, FNAME) {
        Ok(_) => panic!("expected compile-time error, got Ok: {}", src),
        Err(e) => e,
    };
    assert_eq!(
        e.stage,
        Stage::Compile,
        "stage mismatch(should be Compile): \n{}",
        e.rendered
    );
    assert_eq!(
        e.diagnostic.code,
        Some(DiagnosticCode(code)),
        "diagnostic code mismatch(should be E{:04}): \n{}",
        code,
        e.rendered
    );
    assert!(
        e.rendered.contains(msg),
        "message missing `{}`: \n complete: \n{}",
        msg,
        e.rendered
    );
}

/// Read-error assertion (E6 target-face note: the declaration-position /
/// keyword-binding disciplines that the S-expr face carried at the
/// expand/compile stages are lexically fronted to the target Reader for
/// the skin keywords — the fail-closed criterion is unchanged, the stage
/// moves to Read; the compile-stage anchors of the same families stay in
/// expect_compile_err via the shared non-skin reserved words).
fn expect_read_err(src: &str, msg: &str) {
    let e = match run_source(src, FNAME) {
        Ok(_) => panic!("expected read-time error, got Ok: {}", src),
        Err(e) => e,
    };
    assert_eq!(
        e.stage,
        Stage::Read,
        "stage mismatch(should be Read): \n{}",
        e.rendered
    );
    assert!(
        e.rendered.contains(msg),
        "message missing `{}`: \n complete: \n{}",
        msg,
        e.rendered
    );
}

// ---------------------------------------------------------------------------
// Positive: the seven-module qualified-name visibility face (20 §5.2 module-tree final map)
// ---------------------------------------------------------------------------

/// Seven-module qualified-name resolution (R-N3 main path — ≥1 spot check
/// per module + cross-module combinations).
#[test]
fn qualified_names_resolve_across_modules() {
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring::append(\"ab\", \"cd\")"),
        "abcd"
    );
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring::length(\"héllo\")"),
        "5"
    );
    assert_eq!(
        common::run_rendered("import kerf_list;\nlist::nth(list(quote(a), quote(b), quote(c)), 1)"),
        "b"
    );
    assert_eq!(
        common::run_rendered("import kerf_list;\nlist::append(list(1), list(2, 3))"),
        "(1 2 3)"
    );
    assert_eq!(
        common::run_rendered("import kerf_pair;\npair::head(pair::cons(1, 2))"),
        "1"
    );
    assert_eq!(
        common::run_rendered("import kerf_pair;\npair::tail(pair::cons(1, 2))"),
        "2"
    );
    assert_eq!(
        common::run_rendered("import kerf_core;\ncore::is_int(3)"),
        "true"
    );
    assert_eq!(
        common::run_rendered("import kerf_core;\ncore::eq(quote(a), quote(a))"),
        "true"
    );
    assert_eq!(
        common::run_rendered("import kerf_char;\nchar::is_whitespace(\" \")"),
        "true"
    );
    assert_eq!(
        common::run_rendered("import kerf_char;\nchar::is_alphabetic(\"é\")"),
        "true"
    );
    // Cross-module combinations (the N2 face interoperates freely with existing globals/aliases)
    assert_eq!(
        common::run_rendered("import kerf_list;\nlist::reverse(list::nth(list(list(1, 2), 3), 0))"),
        "(2 1)"
    );
    assert_eq!(
        common::run_rendered(
            "import kerf_core, kerf_string;\ncore::is_string(string::to_upper(\"a\"))"
        ),
        "true"
    );
}

/// The full kerf/string export face (all 11 local names one by one —
/// row-by-row reconciliation with the 20 §5.2 table).
#[test]
fn string_module_full_export_face() {
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring::append(\"a\", \"b\")"),
        "ab"
    );
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring::length(\"abc\")"),
        "3"
    );
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring::substring(\"héllo\", 1, 3)"),
        "él"
    );
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring::index_of(\"abc\", \"b\")"),
        "1"
    );
    // M2 (r40) B1 contract in place (20 §4): qualified-name miss → nil
    // (nil-as-absence is consistent with the language value domain — the
    // same shape as the read-int EOF→nil precedent; old/flat new names keep
    // the legacy -1 contract — "new names get the new contract, old names
    // keep the old contract until removal" migration invariant)
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring::index_of(\"abc\", \"z\")"),
        "nil"
    );
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring::contains(\"abc\", \"bc\")"),
        "true"
    );
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring::starts_with(\"abc\", \"ab\")"),
        "true"
    );
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring::ends_with(\"abc\", \"bc\")"),
        "true"
    );
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring::to_upper(\"aé\")"),
        "AÉ"
    );
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring::to_lower(\"AÉ\")"),
        "aé"
    );
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring::to_symbol(\"foo\")"),
        "foo"
    );
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring::from_symbol(quote(foo))"),
        "foo"
    );
}

/// R4 bidirectional dual home (20 §5.2 — string-side to-symbol/from-symbol
/// dual to symbol-side to-string/from-string).
#[test]
fn symbol_r4_dual_home_roundtrip() {
    assert_eq!(
        common::run_rendered("import kerf_symbol;\nsymbol::to_string(quote(foo))"),
        "foo"
    );
    assert_eq!(
        common::run_rendered("import kerf_symbol;\nsymbol::from_string(\"foo\")"),
        "foo"
    );
    // Dual-home roundtrip (both entries are behaviorally equivalent — a shared underlying dispatch
    // body)
    assert_eq!(
        common::run_rendered(
            "import kerf_core, kerf_string, kerf_symbol;\ncore::eq(symbol::from_string(\"x\"), string::to_symbol(\"x\"))"
        ),
        "true"
    );
    assert_eq!(
        common::run_rendered(
            "import kerf_core, kerf_string, kerf_symbol;\ncore::eq(string::from_symbol(quote(y)), symbol::to_string(quote(y)))"
        ),
        "true"
    );
}

/// The kerf/core face (14 local names — full spot checks across the
/// predicate/relation/assertion domains).
#[test]
fn core_module_face_covers_predicates() {
    assert_eq!(
        common::run_rendered("import kerf_core;\ncore::is_nil(())"),
        "true"
    );
    assert_eq!(
        common::run_rendered("import kerf_core;\ncore::is_bool(true)"),
        "true"
    );
    assert_eq!(
        common::run_rendered("import kerf_core;\ncore::is_float(3.5)"),
        "true"
    );
    assert_eq!(
        common::run_rendered("import kerf_core;\ncore::is_number(3)"),
        "true"
    );
    assert_eq!(
        common::run_rendered("import kerf_core;\ncore::is_string(\"s\")"),
        "true"
    );
    assert_eq!(
        common::run_rendered("import kerf_core;\ncore::is_symbol(quote(s))"),
        "true"
    );
    assert_eq!(
        common::run_rendered("import kerf_core, kerf_pair;\ncore::is_pair(pair::cons(1, 2))"),
        "true"
    );
    assert_eq!(
        common::run_rendered("import kerf_core;\ncore::is_list(list(1))"),
        "true"
    );
    assert_eq!(
        common::run_rendered("import kerf_core;\ncore::is_procedure(core::eq)"),
        "true"
    );
    assert_eq!(
        common::run_rendered("import kerf_core;\ncore::not(true)"),
        "false"
    );
    assert_eq!(
        common::run_rendered("import kerf_core;\ncore::assert_eq(1, 1)"),
        "true"
    );
    assert_eq!(
        common::run_rendered(
            "import kerf_core, kerf_list;\nlist::length(list(quote(core::error), quote(omit)))"
        ),
        "2"
    ); // error-domain member existence anchored by the negative-case group (termination semantics)
}

// ---------------------------------------------------------------------------
// Negative: R-N3 no fallback (E0014) + reserved domain (E0015) — the corresponding 22 §8 table
// rows
// ---------------------------------------------------------------------------

/// Qualified name not exported (unknown local name in a known namespace) →
/// E0014 at compile time (not the runtime "unbound" — R-N3 diagnostic
/// gain: a mistyped name points precisely at the module face).
#[test]
fn qualified_not_exported_known_ns_is_e0014() {
    expect_compile_err(
        "import kerf_string;\nstring::nonexist(1)",
        14,
        "`string` does not export `nonexist`",
    );
    expect_compile_err(
        "import kerf_list;\nlist::nonexist(1)",
        14,
        "`list` does not export `nonexist`",
    );
    expect_compile_err(
        "import kerf_core;\nfn f(x: i64) { core::nonexist(x) }",
        14,
        "`core` does not export `nonexist`",
    ); // nesting depth (recursion into a fn body)
}

/// Unknown namespace → E0014 (no fallback: globals/locals/other modules are
/// not consulted).
#[test]
fn qualified_unknown_ns_is_e0014() {
    expect_compile_err("nosuchns::foo(1)", 14, "`nosuchns` does not export `foo`");
    expect_compile_err("io::prints(1)", 14, "`io` does not export `prints`");
}

/// R-N3 message carries the no-fallback semantics (three-part diagnostic
/// anchor — readability of the no-fallback rule).
#[test]
fn e0014_message_carries_no_fallback_semantics() {
    expect_compile_err(
        "import kerf_string;\nstring::nonexist(1)",
        14,
        "qualified names have no fallback",
    );
}

/// Reserved-domain violation (22 §7): a user module name with the kerf-
/// prefix → E0015.
#[test]
fn reserved_domain_module_name_is_e0015() {
    expect_compile_err(
        "module kerf_evil { export f; let f = 1; f(); }",
        15,
        "reserved domain violation: module name `kerf-evil` occupied kerf- prefix",
    );
    expect_compile_err(
        "module m { let f = 1; module kerf_inner { export g; let g = 2; g(); } }",
        15,
        "`kerf-inner`",
    ); // nested module (body-recursion arm)
}

/// User-takeover exemption (zero-false-positive discipline — same rule as
/// R9): a define with a `::` name plus a same-named reference does not
/// trigger E0014. The two S-expr-face parameter-shadowing arms
/// (`(fn (foo/bar) foo/bar)` / `(fn (string/append) string/append)` —
/// R-N1/R-N2 slash-named fn parameters) are deleted: the target-face
/// parameter slots are Ident-only (a `::` parameter is a Reader
/// rejection), so the N3-shadowing anchors are carried by the m2 W1002 /
/// resolution-order groups below (recorded in the worklog).
/// r158 / 228-c reface: the path-named define call form
/// (`define(my::ns, 5)` — the N3-shadowing takeover exemption) is
/// retired with the call form itself: the modern top-level let takes
/// bare identifiers only (the binding-name expectation face), and the
/// retired form hits the Reader-level retirement diagnostic. The
/// slash-named takeover capability remains on the S-expr .krf face
/// (`(define my::ns 5)` — the bootstrap face's native form; the
/// capability is not lost from the system, only from the target
/// surface — toplevel-let-design.md D2 boundary).
#[test]
fn takeover_slash_named_define_exempt() {
    // the retired call form → the Read-stage modernization diagnostic
    expect_read_err(
        "define(my::ns, 5); my::ns",
        "the define call form is retired",
    );
    // the modern face rejects the path binder at the binding-name slot
    expect_read_err("let my::ns = 5;", "expected a binding name");
}

// ---------------------------------------------------------------------------
// 22 §5.1 matrix / red line 1: io qualified-name dual-gate separation
// ---------------------------------------------------------------------------

/// Red line 1 (import ≠ authorization, the M1 observable shape): `io::print`
/// without a declared require → E0006 (fail-closed compile-time first; the
/// message carries the qualified form "io/print").
#[test]
fn io_qualified_requires_write_e0006() {
    expect_compile_err("io::print(42)", 6, "`io/print` requires write capability");
    expect_compile_err("io::newline()", 6, "`io/newline` requires write capability");
    expect_compile_err(
        "io::write_string(\"x\")",
        6,
        "`io/write-string` requires write capability",
    );
}

/// io read family: declaring write does not open read (least-privilege
/// granularity maintained).
#[test]
fn io_qualified_read_requires_read_e0006() {
    expect_compile_err(
        "require io, write;\nio::read_line()",
        6,
        "`io/read-line` requires read capability",
    );
}

/// After authorization the io qualified name is callable (the main path of
/// N2 registration under fail-closed — the print family returns nil with a
/// stdout side effect; the absence of E0006 is the evidence that the
/// authorization face is in effect. The read-family main path cannot be
/// anchored via stdin redirection inside tests [existing stdlib_tests
/// conclusion] — verified at the CLI layer).
#[test]
fn io_qualified_authorized_calls_work() {
    assert_eq!(
        common::run_rendered("require io, write;\nio::print(42)"),
        "nil"
    );
    assert_eq!(
        common::run_rendered("require io, write;\nio::write_string(\"x\")"),
        "nil"
    );
    assert_eq!(
        common::run_rendered("require io, write;\nio::newline()"),
        "nil"
    );
}

// ---------------------------------------------------------------------------
// R-N4 / R-N7 / R-N8 mechanism anchors
// ---------------------------------------------------------------------------

/// R-N4 lexical domain: standalone `/` stays division (`a / b` is
/// unaffected by the qualified-name machinery).
#[test]
fn division_operator_unbroken_rn4() {
    assert_eq!(common::run_rendered("10 / 2"), "5");
    assert_eq!(common::run_rendered("9 / 3 / 3"), "1"); // chained division
                                                        // a qualified name and division coexist in
                                                        // one program
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring::length(\"abcd\") / 2"),
        "2"
    );
}

/// R-N7 operators permanent: N1 bare names need zero import (the
/// "zero-dependency minimal skeleton" anchor — no explicit counterexample
/// exists where every program pays an import tax first, contradicting
/// R-N7).
#[test]
fn operators_permanent_in_n1_rn7() {
    assert_eq!(common::run_rendered("1 + 2"), "3");
    assert_eq!(common::run_rendered("2 * (3 + 4)"), "14");
    assert_eq!(common::run_rendered("1 < 2"), "true");
    assert_eq!(common::run_rendered("mod(7, 3)"), "1");
}

/// R-N8 symbol-universe exemption: quoted symbol values do not participate
/// in resolution (`quote(string::append)` is a name that is a value —
/// existence ≠ visibility; zero interference for same-named
/// different-meaning macro templates).
#[test]
fn quoted_symbols_exempt_from_resolution_rn8() {
    assert_eq!(
        common::run_rendered(
            "import kerf_core;\ncore::eq(quote(string::append), quote(string::append))"
        ),
        "true"
    );
    assert_eq!(
        common::run_rendered(
            "import kerf_core;\ncore::eq(quote(nosuchns::foo), quote(nosuchns::foo))"
        ),
        "true"
    ); // symbol values of an unknown ns are equally legal (N0-layer existence)
}

// ---------------------------------------------------------------------------
// Static face + dual path
// ---------------------------------------------------------------------------

/// Qualified-name signature derivation (same dispatch → same static-check
/// face): `ns::name` calls participate in E0005 static judgment
/// (`builtin_sigs` is derived from the module table — the 22 §8
/// R-N1/R-N3 rows' static face). r80 semantic re-anchor: the target face
/// (the production judgment face = the check.ktf path) has a
/// signature-table subset without the string family (neither the
/// qualified name nor the underlying name hits — a conservative
/// false-negative boundary); detection capability is guarded by direct
/// Rust oracle calls; zero diagnostics on positive cases (no false
/// positives) is maintained on the production face.
#[test]
fn qualified_names_static_checked_e0005() {
    // Direct oracle call: the static detection capability of qualified-name signature derivation
    // (R-N1/R-N3 row anchors)
    let out = kerf_driver::compile_source("import kerf_string;\nstring::append(1, 2)", FNAME)
        .expect("pre-stage compile failed");
    let mut table = out.table;
    let sigs = kerf_driver::builtins::builtin_sigs(&mut table);
    let diags = kerf_compiler::hm::hm_check_program(&out.core, &sigs, &table).diags;
    let hit = diags
        .iter()
        .any(|d| d.code == Some(DiagnosticCode(5)) || d.message.contains("str"));
    assert!(
        hit,
        "oracle static check not coverage qualified name: {:?}",
        diags.iter().map(|d| d.message.clone()).collect::<Vec<_>>()
    );
    // Zero diagnostics on the positive case (a legal qualified-name call is not a false positive —
    // maintained on the production face)
    let clean = kerf_driver::check_source_recover(
        "import kerf_string;\nstring::append(\"a\", \"b\")",
        FNAME,
    )
    .expect("check entry not should structure failed");
    assert!(
        clean
            .diagnostics
            .iter()
            .all(|d| d.code != Some(DiagnosticCode(5))),
        "qualified name positive case false positive: {:?}",
        clean
            .diagnostics
            .iter()
            .map(|d| d.message.clone())
            .collect::<Vec<_>>()
    );
}

/// Dual-path agreement (T1 criterion — the production chain [self-hosted
/// read+expand+compile] is rendering-equivalent to the seed chain).
#[test]
fn qualified_names_dual_path_agrees() {
    assert!(common::dual_path_agrees(
        "import kerf_string;\nstring::append(\"a\", \"b\")"
    ));
    assert!(common::dual_path_agrees(
        "import kerf_list;\nlist::nth(list(quote(a), quote(b), quote(c)), 1)"
    ));
    assert!(common::dual_path_agrees(
        "import kerf_core;\ncore::eq(quote(x), quote(x))"
    ));
    assert!(common::dual_path_agrees("10 / 2"));
}

// ---------------------------------------------------------------------------
// Batch M second deliverable M2 (v0.6 namespace layer, r40) — import
// injection face/aliases + composition closure + position discipline +
// E0016 + the W deprecation/shadowing families + B1/B2/B3 contracts
// (22 §8 implementation-reconciliation M2 row + 20 §4/§7 + 21 §4.4 +
// deep-audit D1-D9 rulings)
// ---------------------------------------------------------------------------

/// R-N5 unqualified import + 22 §6 conflict-class-3 transitional semantics
/// anchor: after `import kerf_list;`, bare `append` still resolves to the
/// N1 global list-append (a different semantic slot — an unqualified
/// reference goes through R-N1 to N1; a qualified reference goes through
/// R-N3 to N2; once the N1 old names are removed [Stage 3] the contest
/// resolves itself — the already-adjudicated behavior of 22 §6 row three,
/// honestly anchored for the v0.6 transition).
#[test]
fn m2_unqualified_import_injects_export_face() {
    // Bare append = the global list-append (22 §6 conflict class 3 — transitional semantics)
    assert_eq!(
        common::run_rendered(
            "import kerf_list;\nmodule m { import kerf_string; append(list(1), list(2)) }"
        ),
        "(1 2)"
    );
    // Bare nth = the global list family (same as above — when the injection face and the global
    // face share a name, the global wins)
    assert_eq!(
        common::run_rendered(
            "import kerf_list;\nmodule m { import kerf_list; nth(list(quote(a), quote(b), quote(c)), 1) }"
        ),
        "b"
    );
    // Qualified reference = the string family's append (R-N3 precise disambiguation — the positive
    // payoff of an import declaration)
    assert_eq!(
        common::run_rendered(
            "import kerf_string;\nmodule m { import kerf_string; string::append(\"a\", \"b\") }"
        ),
        "ab"
    );
}

/// R-N5 qualified alias: `import kerf_string as str;` → the `str::append`
/// alias-qualified reference (compile-time normalization — the mechanism
/// face of 22 §3.5 "an alias is a local binding").
#[test]
fn m2_qualified_alias_import_resolves() {
    assert_eq!(
        common::run_rendered("module m { import kerf_string as str; str::append(\"a\", \"b\") }"),
        "ab"
    );
    assert_eq!(
        common::run_rendered(
            "module m { import kerf_list as l; l::nth(list(quote(a), quote(b), quote(c)), 1) }"
        ),
        "b"
    );
    // Alias + unqualified mixed imports (the three shapes of 22 §3.5 coexist)
    assert_eq!(
        common::run_rendered(
            "module m { import kerf_list as l; import kerf_core; l::nth(list(1, 2), 0) }"
        ),
        "1"
    );
}

/// E0013 unqualified import conflict — r47 / 68-b D55 **underlying
/// identity re-basing**: the r40 M2 transitional criterion (lexical
/// collision of local names [the local "append" of string/list]) protected
/// a flat local-name semantics that was never implemented — local names
/// are reachable only in qualified form (`string::append` is unique), and
/// the flat ground truth = underlying (`string-append`/`append` each
/// unique) → a lexical collision does not constitute runtime ambiguity.
/// After re-basing, the criterion = same underlying name with distinct
/// dispatch bodies; for the seven stdlib modules the underlying name is
/// the dispatch identity → **structurally zero conflicts** (coexisting
/// imports are legal — flat `append` always resolves to the list domain,
/// disambiguated by the `string::append` qualified form). The E0013 code
/// slot is retained (18 §6 — triggered in the Stage 3+ user-module
/// window).
#[test]
fn m2_import_conflict_e0013() {
    // Coexisting imports are legal (D55 re-based semantics — empirical zero conflicts)
    let o = run_source(
        "module m { import kerf_list; import kerf_string; string::append(string::append(\"a\", \"b\"), \"c\") }",
        FNAME,
    )
    .expect("string+list total exist import should be legal(underlying the same property -- non-conflict)");
    let _ = o;
    // Escape hatch: an as-alias qualified import injects no unqualified name — the conflict
    // vanishes (22 §6)
    assert_eq!(
        common::run_rendered(
            "import kerf_string;\nmodule m { import kerf_list as l; import kerf_string; string::append(\"a\", string::append(\"b\", \"c\")) }"
        ),
        "abc"
    );
}

/// E0017 duplicate alias (22 §3.5 R-N5 conflict column: duplicate alias
/// definition error).
#[test]
fn m2_alias_duplicate_e0017() {
    expect_compile_err(
        "module m { import kerf_string as s; import kerf_symbol as s; 42 }",
        17,
        "duplicate alias",
    );
}

/// E0019 unknown import module (deep-audit D2 ruling: compile-time
/// rejection in the same shape as Clojure require; the message carries
/// the registered list + a Stage 3 window pointer).
#[test]
fn m2_unknown_import_e0019() {
    expect_compile_err(
        "module m { import kerf_nonexist; 42 }",
        19,
        "unknown imported module `kerf-nonexist`",
    );
}

/// E0016 duplicate same-named define inside a module body (the M2
/// placement of the existing 09 v6.2 ruling).
#[test]
fn m2_module_define_duplicate_e0016() {
    expect_compile_err(
        "module m { let x = 1; let x = 2; x }",
        16,
        "duplicate definition: module `m` in define `x` duplicate",
    );
}

/// E0018 require position discipline (deep-audit D3 ruling: legal
/// positions = top level / direct elements of a module body; inside an
/// expression subtree = position error — fail-closed). E6 target-face
/// note: a require inside a closure body is lexically fronted to the
/// Reader (`require` is a declaration Token — the ktf_corpus_tests
/// precedent for the same family); the Stx-layer E0018 walk stays the
/// shared backstop for macro-produced shapes.
#[test]
fn m2_require_position_e0018() {
    // require inside a closure body = position violation (an authorization declaration is not an
    // expression) — Reader-fronted on the target face
    expect_read_err(
        "require io, write;\nrequire io, read;\nmodule m { (||(x: i64) { require io, read; x })(1) }",
        "KwRequire",
    );
    // A direct module-body element is legal (requirement metadata — the composition-closure
    // collection face)
    let r = run_source(
        "require io, write;\nmodule m { require io, write; let f = print(1); 42 }",
        FNAME,
    );
    assert!(
        r.is_ok(),
        "module body directly position require legal: \n{:?}",
        r.err().map(|e| e.rendered)
    );
}

/// Composition closure (21 §4.4): module requirements ⊆ entry
/// authorization — a require inside a module body is requirement
/// metadata, not an authorization grant; if missing → the E0006 enhanced
/// form (carrying the module attribution).
#[test]
fn m2_capability_closure_e0006_enhanced() {
    expect_compile_err(
        "module m { require io, write; let f = print(1); 42 }",
        6,
        "module `m` declares io write",
    );
    // Passes once hoisted to the entry (the only path to an authorization grant = a top-level
    // declaration)
    let r = run_source(
        "require io, write;\nmodule m { require io, write; let f = print(1); 42 }",
        FNAME,
    );
    assert!(
        r.is_ok(),
        "require above move entry after should pass: \n{:?}",
        r.err().map(|e| e.rendered)
    );
}

/// Composition closure, two separate items (read and write checked
/// independently — requirement-union semantics).
#[test]
fn m2_capability_closure_covers_read_write_union() {
    // Program declares write, module requires read+write → read missing (union unsatisfied)
    expect_compile_err(
        "require io, write;\nmodule m { require io, read; require io, write; let f = print(1); 42 }",
        6,
        "io read",
    );
}

/// B1 contract (20 §4): qualified-name `string::index_of` miss → nil; the
/// old name `string_index_of` and the flat new name `string_index_of`
/// keep -1 (migration invariant: "new names get the new contract, old
/// names keep the old contract until removal" — the r38 alias-layer
/// parity is untouched).
#[test]
fn m2_b1_contract_qualified_nil_vs_legacy_minus_one() {
    // Qualified name (new contract)
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring::index_of(\"abc\", \"z\")"),
        "nil"
    );
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring::index_of(\"abc\", \"b\")"),
        "1"
    );
    // Old name (legacy contract maintained)
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring_index_of(\"abc\", \"z\")"),
        "-1"
    );
    // Flat new name (v0.5 alias-layer parity maintained — renaming and behavior change never mix
    // steps)
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring_index_of(\"abc\", \"z\")"),
        "-1"
    );
}

/// B2 contract (20 §4): `list::member`/`list::assoc` miss → nil (return type
/// unified: list-or-nil); the hit shape is unchanged; the old name keeps
/// returning false.
#[test]
fn m2_b2_contract_member_assoc_nil() {
    assert_eq!(
        common::run_rendered("import kerf_list;\nlist::member(9, list(1, 2, 3))"),
        "nil"
    );
    assert_eq!(
        common::run_rendered("import kerf_list;\nlist::member(2, list(1, 2, 3))"),
        "(2 3)"
    );
    assert_eq!(
        common::run_rendered("import kerf_list;\nlist::assoc(quote(z), list(list(quote(a), 1)))"),
        "nil"
    );
    assert_eq!(
        common::run_rendered("import kerf_list;\nlist::assoc(quote(a), list(list(quote(a), 1)))"),
        "(a 1)"
    );
    // Old name (legacy contract maintained)
    assert_eq!(
        common::run_rendered("import kerf_list;\nmember(9, list(1, 2, 3))"),
        "false"
    );
    assert_eq!(
        common::run_rendered("import kerf_list;\nassoc(quote(z), list(list(quote(a), 1)))"),
        "false"
    );
}

/// B3 contract (20 §4): `io::read_line` takes strictly 0 arguments (extra
/// arguments = runtime error — the underlying layer is already aligned
/// [FS-4 fix face, 20 §4 B3 row R4 correction]; this case is a test
/// anchor).
#[test]
fn m2_b3_contract_read_line_strict_arity() {
    let e = run_source("require io, read;\nmodule m { io::read_line(1) }", FNAME)
        .expect_err("many remaining actual argument should report runtime error");
    assert!(
        e.rendered.contains("read-line requires 0 arguments"),
        "actual: {}",
        e.rendered
    );
}

/// r42 / S1 removal round — the W1001 deprecation family retired + the
/// W1003 macro-name shadowing warning (22 §11 D11, scheduled for this
/// window, now delivered). The 27 old names were upgraded to E0021
/// compile-time errors (carried by 27 removed_rejects_* cases in
/// stdlib_tests); this group anchors: (1) modern names produce zero
/// warnings (empirical W-face narrowing) (2) qualified names produce zero
/// warnings (3) a W1003 positive case (a macro name shadowing a builtin →
/// exactly one notice) (4) W1003 zero false positives on non-builtin names
/// (5) W1003 gives the same notice for a shadowing qualified name (6)
/// macro-wins behavior unchanged (the macro body executes, not the
/// builtin). E6 note: arm (5)'s S-expr source (a macro *named*
/// `string/append`) is deleted — the target-face macro-name slot is
/// Ident-only (recorded in the worklog; the qualified-registry W1003 face
/// is carried by the ktf_member_rename family).
#[test]
fn s1_w1003_macro_shadow_builtin_warning() {
    // (1) Modern names produce zero warnings (the W face narrows after the W1001 retirement)
    let o = run_source("module m { head(list(1, 2)) }", FNAME).expect("modern name can use");
    assert!(
        o.warnings.is_empty(),
        "modern name not should has any W warning: {:?}",
        o.warnings
            .iter()
            .map(|w| w.message.clone())
            .collect::<Vec<_>>()
    );
    // (2) Qualified names produce zero warnings
    let o2 = run_source(
        "import kerf_pair;\nmodule m { pair::head(pair::cons(1, 2)) }",
        FNAME,
    )
    .expect("qualified name can use");
    assert!(o2.warnings.is_empty(), "qualified name not should warning");
    // (3) W1003 positive case: a macro name shadowing a builtin (deliberate
    // redefinition — the macro winning is an essential capability, the
    // W-level notice does not block)
    let o3 = run_source(
        "module m { macro head() { (x) => 99 } head(list(1, 2)) }",
        FNAME,
    )
    .expect("macro shadow builtin should run(W level non-blocking)");
    assert_eq!(
        o3.warnings.len(),
        1,
        "exactly one clauses W1003 macro name shadow warning"
    );
    assert!(
        o3.warnings[0]
            .message
            .contains("macro name `head` shadows visible builtin name")
            && o3.warnings[0].message.contains("W1003"),
        "message: {}",
        o3.warnings[0].message
    );
    // (6) Macro-wins behavior unchanged (the macro body 99 executes, not the builtin head)
    assert_eq!(
        common::run_rendered("module m { macro head() { (x) => 99 } head(list(1, 2)) }"),
        "99",
        "macro should wins output(this quality capability -- W only informational)"
    );
}

/// W1003 zero false positives on non-builtin names + the same notice for
/// shadowing a qualified name (22 §11 D11: macro name ∈ the builtin
/// registry face [57 flat + 47 qualified] → W; non-builtin names (user
/// names/module names) get zero W). E6 note: the qualified-name arm's
/// S-expr source (macro named `string/append`) is deleted — the
/// target-face macro-name slot is Ident-only (recorded in the worklog).
#[test]
fn s1_w1003_scoping_and_qualified() {
    // Non-builtin macro name: zero W
    let o = run_source(
        "module m { macro my_macro() { () => 1 } my_macro() }",
        FNAME,
    )
    .expect("use user macro name should run zero warning");
    assert!(
        o.warnings.is_empty(),
        "non-builtin macro name not should W1003: {:?}",
        o.warnings
            .iter()
            .map(|w| w.message.clone())
            .collect::<Vec<_>>()
    );
}

/// r42 / S1 removal round — preamble injection keeps a zero-W face (after
/// the W1001 retirement: the preamble has migrated to modern names, and
/// the structural exemption guards against W1002 injection-shadowing false
/// positives — the 20 §6.5 discipline is unchanged).
#[test]
fn s1_prelude_injection_zero_warnings() {
    let o = run_source(
        "import kerf_prelude;\nmodule user { import kerf_prelude; let lst = list(1, 2, 3); map(||(x: i64) { x }, lst) }",
        FNAME,
    )
    .expect("prelude injection program should run");
    assert!(
        o.warnings.is_empty(),
        "preamble injection not should produce use user face warning: {:?}",
        o.warnings
            .iter()
            .map(|w| w.message.clone())
            .collect::<Vec<_>>()
    );
}

/// r42 / S1 removal round — E0021 references to old names in qualified
/// form (all value/operator positions + recovery to health: after an
/// E0021 the pipeline still compiles legal programs).
#[test]
fn s1_e0021_recovery_and_positions() {
    // Operator position + value position (nested expression + define initializer position)
    let err = run_source("module m { let x = car(list(1, 2)); }", FNAME)
        .expect_err("old name define initialization position should E0021");
    assert!(
        err.rendered.contains("[E0021]") && err.rendered.contains("modern name `head`"),
        "E0021 carry modern name refers to quote: {}",
        err.rendered
    );
    // assign value position
    let err2 = run_source("module m { let x = 1; x = cdr(list(1, 2)); }", FNAME)
        .expect_err("old name assign value position should E0021");
    assert!(
        err2.rendered.contains("[E0021]"),
        "assign value position: {}",
        err2.rendered
    );
    // Pipeline healthy after E0021 (fail-closed single-report block — compiles normally once
    // fixed)
    let ok = run_source("module m { let x = head(list(1, 2)); () }", FNAME);
    assert!(
        ok.is_ok(),
        "fix positive after should normal compile: {:?}",
        ok.err().map(|e| e.rendered)
    );
    assert_eq!(
        common::run_rendered("module m { let x = head(list(1, 2)); () }"),
        "nil"
    );
}

/// W1002 shadowing-an-injected-name warning (22 §3.2 R-N2 second row: N3
/// shadowing an N2 injected name = legal + a W-level warning — recoverable
/// but worth a hint).
#[test]
fn m2_w1002_shadow_import_warning() {
    let o = run_source(
        "import kerf_list;\nmodule m { import kerf_list; (||(length: i64) { length })(1) }",
        FNAME,
    )
    .expect("argument shadow injection name legal(inner wins -- R-N2)");
    assert_eq!(o.warnings.len(), 1);
    assert!(
        o.warnings[0]
            .message
            .contains("fn argument `length` shadows visible face name(N1 core or import injection"),
        "message: {}",
        o.warnings[0].message
    );
}

/// R-N1 resolution total-order anchor (22 §3.1: N3 → N2 → N1 — inner
/// bindings beat global names).
#[test]
fn m2_r_n1_resolution_order_local_wins() {
    // fn parameter shadows a global name: the local binding wins (N3 > N1 — sixty years of
    // lexical-scope consensus)
    assert_eq!(
        common::run_rendered(
            "import kerf_list;\nmodule m { import kerf_list; (||(nth: i64) { nth })(99) }"
        ),
        "99"
    );
}

/// Red line 1 dual-gate separation (22 §5.2: import does not propagate
/// authorization — after import kerf_io the name is visible but calling it
/// without require is still E0006).
#[test]
fn m2_redline1_import_does_not_propagate_authority() {
    expect_compile_err("module m { import kerf_io; print(42) }", 6, "print");
    // Passes after authorization (the two gates vary independently — red line 2)
    let r = run_source(
        "require io, write;\nmodule m { import kerf_io; print(42) }",
        FNAME,
    );
    assert!(
        r.is_ok(),
        "require after authorization import face can call: \n{:?}",
        r.err().map(|e| e.rendered)
    );
}

/// Alias-normalized E0014 shape (`str::nonexist` → the diagnostic carries
/// the normalized module-face information).
#[test]
fn m2_alias_qualified_e0014_with_normalization() {
    expect_compile_err(
        "module m { import kerf_string as str; str::nonexist(\"a\") }",
        14,
        "does not export `nonexist`",
    );
}

/// Alias qualified-name dual-path agreement (T1 criterion — compile-time
/// normalization happens in the shared front stage).
#[test]
fn m2_alias_dual_path_agrees() {
    assert!(common::dual_path_agrees(
        "module m { import kerf_string as str; str::append(\"a\", \"b\") }"
    ));
    assert!(common::dual_path_agrees(
        "module m { import kerf_list as l; l::member(2, list(1, 2, 3)) }"
    ));
}

// ---------------------------------------------------------------------------
// r41 / 62-a language-forms deep-audit round — the D10 ruling test group:
// the E0020 reserved-word binding ban (compile-time enforcement of the
// 22 §2.1 N4-layer invariant "not a value, not referenceable, not
// shadowable"; the pre-fix shape = bindable in value position + silently
// dead in operator position — the classic Lisp dual-track trap)
// ---------------------------------------------------------------------------
//
// E6 target-face note (r154 / 224-b7b): the N4 keyword table's skin words
// (if/fn/let/module/import/require/perform/handle/match/else/...) are
// Reader-reserved Tokens on the target face — a binding attempt with one
// of them is rejected at the read stage (a strictly earlier fail-closed
// face). The compile-stage E0020 anchors below therefore use the shared
// non-skin reserved words of the same 28-name table (`do` / `quote` /
// `assign` — plain identifiers on the target surface, N4 keywords in the
// expander/driver): every binding position (define name / fn parameter /
// let name / assign target / module name / import alias / macro name /
// handle binders / nested subtree / macro-expansion product) keeps its
// compile-stage E0020 coverage; the word-level substitution is recorded
// in the worklog.

/// Positive: non-reserved-word bindings all green (E0020 zero false
/// positives — binding-face whitelist shape). E6 note: the letrec flavor
/// is deleted (no target-surface letrec/let* — the let family is the
/// single `let` form; recorded in the worklog); the let anchor moves
/// inside an IIFE closure block (the target-face let statement site).
#[test]
fn d10_non_reserved_bindings_all_legal() {
    // Ordinary names in the define/lambda/let family (including modern names / qualified-name
    // symbols / underscore style)
    assert_eq!(
        common::run_rendered(
            "import kerf_pair;\nlet my_x = 5;\nfn lambda_pair(a: i64, b: i64) { pair::cons(a, b) }\n(|| { let lo = 1; let hi = 2; lo + hi })();\n(||(first_arg: i64, second_arg: i64) { first_arg * second_arg })(3, 4)"
        ),
        "12"
    );
    // Ordinary handle binder names (CoreExpr-layer zero false positives — legal names in
    // payload/resume positions)
    assert_eq!(
        common::run_rendered(
            "fn ask() { perform state(1); }\nhandle ask() { state(payload, resume_k) => resume(99) }"
        ),
        "99"
    );
}

/// Positive: quoted reserved-word data symbols are legal (the N0
/// symbol-universe layer — homoiconicity maintained; existence ≠
/// visibility, E0020 bans only bindings and value-position references,
/// not data symbols). E6 note: the target Reader reserves the skin
/// keywords as Tokens (`quote(if)` is a parse error), so the N0 anchor
/// goes through the runtime symbol-construction route
/// (`string::to_symbol` — a keyword-named symbol VALUE is a legal datum;
/// the read-time `'if` datum face has no target-surface spelling).
#[test]
fn d10_quote_reserved_word_data_symbols_legal() {
    assert_eq!(
        common::run_rendered("import kerf_string;\nis_symbol(string_to_symbol(\"if\"))"),
        "true"
    );
    assert_eq!(
        common::run_rendered("import kerf_string;\nis_symbol(string_to_symbol(\"fn\"))"),
        "true"
    );
    assert_eq!(
        common::run_rendered(
            "import kerf_core, kerf_string;\ncore::eq(string_to_symbol(\"else\"), string_to_symbol(\"else\"))"
        ),
        "true"
    );
}

/// Positive: macro-expansion products bind normally (CoreExpr-layer
/// defense-in-depth zero false positives — define/fn bindings generated
/// by macro-template expansion do not trigger E0020).
#[test]
fn d10_macro_expansion_bindings_legal() {
    assert_eq!(
        common::run_rendered(
            "import kerf_pair;\nmacro swap_pair() { (a, b) => pair::cons(b, a) }\nswap_pair(1, 2)"
        ),
        "(2 . 1)"
    );
}

/// Negative: define binding a reserved word (the empirically observed
/// pre-fix shape of deep-audit D10 — a define of a reserved word was
/// legal and readable in value position = N4 invariant violation + a
/// silently dead operator position). E6 word note: `if`/`fn` are
/// Reader-rejected on the target face — the compile-stage anchors use the
/// shared non-skin reserved words (`do`/`quote`), `assign` converts
/// verbatim.
#[test]
fn d10_define_reserved_word_e0020() {
    expect_compile_err("let do = 5;", 20, "reserved word is not bindable");
    expect_compile_err("let quote = 5;", 20, "`quote`");
    expect_compile_err("let assign = 7;", 20, "`assign`");
}

/// Negative: reserved word in the fn parameter list (pre-fix, a closure
/// parameter named after a keyword evaluated its argument). E6 word note:
/// `if`/`else` are Reader-rejected — the anchors use `do`/`quote`/
/// `assign`.
#[test]
fn d10_lambda_param_reserved_word_e0020() {
    expect_compile_err("(||(do: i64) { do })(1)", 20, "fn parameter");
    expect_compile_err("(||(x: i64, quote: i64) { x })(1, 2)", 20, "`quote`");
    expect_compile_err("(||(assign: i64) { assign })(1)", 20, "`assign`");
}

/// Negative: reserved word as a let-family binding name. E6 note: the
/// let*/letrec flavors are deleted (no target-surface forms — the let
/// family is the single `let` statement; recorded in the worklog); the
/// let anchor uses the shared non-skin reserved words.
#[test]
fn d10_let_bindings_reserved_word_e0020() {
    expect_compile_err("(|| { let do = 5; do })()", 20, "let binding name");
    expect_compile_err("(|| { let quote = 1; quote })()", 20, "`quote`");
}

/// Negative: reserved word as an assign target.
#[test]
fn d10_setbang_target_reserved_word_e0020() {
    expect_compile_err("let x = 1; do = 2;", 20, "assignment target");
}

/// Negative: reserved word as a module name / import as alias /
/// define-syntax macro name. E6 word note: `if` is Reader-rejected in all
/// three slots — the anchors use the shared non-skin reserved word
/// `quote`.
#[test]
fn d10_module_alias_macro_name_reserved_word_e0020() {
    expect_compile_err("module quote { export a; let a = 1; }", 20, "module name");
    expect_compile_err(
        "module m { import kerf_string as quote; quote::length(\"a\") }",
        20,
        "import alias",
    );
    expect_compile_err("macro quote() { (c, t) => t }", 20, "macro name");
}

/// Negative: begin/nested-subtree recursion penetrated (deep-position
/// bindings are intercepted too).
#[test]
fn d10_nested_begin_reserved_word_e0020() {
    expect_compile_err("do(define(ok, 1), do(define(do, 2)))", 20, "`do`");
    // Deep nesting inside a fn body
    expect_compile_err("(||(n: i64) { let quote = n; quote })(1)", 20, "`quote`");
}

/// Negative: macro-expansion product binding a reserved word
/// (CoreExpr-layer defense in depth — an E0020 violation generated by a
/// macro template is also intercepted at compile time).
#[test]
fn d10_macro_expansion_reserved_binding_e0020() {
    expect_compile_err(
        "macro m_kw() { () => define(quote, 1) }\nm_kw()",
        20,
        "binding name (expansion product)",
    );
}

/// Negative: reserved word for both handle binders (payload/resume
/// binding positions — structured carriage at the CoreExpr layer). E6
/// word note: `perform` is Reader-rejected in the binder slots — the
/// anchor uses the shared non-skin reserved words.
#[test]
fn d10_handle_binders_reserved_word_e0020() {
    expect_compile_err(
        "fn ask() { perform state(1); }\nhandle ask() { state(quote, do) => resume(42) }",
        20,
        "handle payload binding",
    );
}

/// Value-position reference to a reserved word → the existing unbound
/// path (fail-closed maintained — after the binding ban the value
/// position never holds a binding, so it naturally goes through the
/// unbound face; the diagnostic face follows the existing criterion). E6
/// note: the S-expr source `(print if)` is Reader-rejected on the target
/// face (`if` is a keyword Token); the anchor uses a non-gated consumer
/// plus the shared non-skin reserved word, keeping the unbound-path
/// assertion (the name rides the diagnostic message proper).
#[test]
fn d10_value_position_reserved_word_unbound() {
    let e = match run_source("head(do)", FNAME) {
        Ok(_) => {
            panic!("value position quote use reserved word should report an error(unbound path)")
        }
        Err(e) => e,
    };
    assert!(
        e.rendered.contains("do"),
        "diagnostic should contain reserved word name: \n{}",
        e.rendered
    );
}

// ---------------------------------------------------------------------------
// r43 / E5 S2 keyword leg (22 §12 D19-D33 + e5-plan §3.2 S2 assertions (3) and (4))
// ---------------------------------------------------------------------------

/// S2 assertion (3): referencing old keyword forms (lambda/set!/begin) →
/// E0021 carrying the new-form guidance (operator-position call form +
/// value-position reference; message sources differ — the keyword copy
/// says "keyword already switched"). E6 note: the `set!` entry is deleted
/// (the `!` spelling has no target-surface identifier form — recorded in
/// the worklog); the `lambda`/`begin` references convert as ordinary
/// identifier references.
#[test]
fn s2_e0021_keyword_old_forms_rejected() {
    for (src, modern) in [
        ("lambda(1)", "fn"),
        ("begin(1, 2)", "do"),
        ("require io, write;\nlet x = 1;\nprint(lambda)", "fn"),
    ] {
        let err = run_source(src, FNAME).expect_err("keyword old form should E0021");
        assert!(
            err.rendered.contains("[E0021]"),
            "E0021 code position({}): \n{}",
            src,
            err.rendered
        );
        assert!(
            err.rendered.contains(&format!("modern form `{}`", modern)),
            "E0021 carry new form refers to quote({} → {}): \n{}",
            src,
            modern,
            err.rendered
        );
    }
}

/// S2 assertion (3) takeover exemption: a user define of an old form = a
/// legal user variable (what is retired is the N4 keyword face, not the
/// N0 symbol-universe layer — same rule as the S1 built-in old-name
/// takeover exemption).
#[test]
fn s2_e0021_takeover_exempt() {
    let ok = run_source("require io, write;\nlet lambda = 5;\nprint(lambda)", FNAME)
        .expect("user takeover old form name legal(N0 symbol universe layer from by)");
    let _ = ok;
    assert_eq!(common::run_rendered("let lambda = 5; lambda"), "5");
}

/// S2 assertion (4): the new names fn/assign/do immediately join the
/// E0020 no-binding face (the 25-name count is unchanged — three names
/// out, three names in; the d10 group's existing 12 cases already cover
/// the new names via corpus migration). E6 note: `fn` is
/// Reader-rejected in the binding slots (a strictly earlier face); the
/// compile-stage anchors cover `assign`/`do` verbatim.
#[test]
fn s2_e0020_new_reserved_names() {
    for (src, kind) in [
        ("let assign = 5;", "binding name"),
        ("let do = 5;", "binding name"),
        ("(||(assign: i64) { assign })(1)", "fn parameter"),
        ("(||(do: i64) { do })(1)", "fn parameter"),
    ] {
        expect_compile_err(src, 20, kind);
    }
}

/// S2 gate A (CoreExpr parity — the integrated shape of e5-plan §3.2 S2
/// row assertion (1)): new-form source and equivalent old-form programs
/// produce identical behavior (behavior-face verification of
/// surface/internal separation principle 31 — both map to the same
/// CoreExpr::Fn/Assign/Do).
#[test]
fn s2_core_expr_parity_new_forms() {
    assert_eq!(common::run_rendered("(||(x: i64) { x * x })(6)"), "36");
    assert_eq!(common::run_rendered("let x = 1; x = x + 1; x"), "2");
    assert_eq!(common::run_rendered("do(1, 2, 3)"), "3");
}

// ---------------------------------------------------------------------------
// r46 / 67-b deep-audit round six (22 §15 D46-D54): top-level import
// legalization (D47) + reserved-domain dual-form enforcement (D48) +
// E0022 compile-time unbound (D49) + prelude re-export metadata (D50) —
// the four-part face of visibility and the import/export machinery
// ---------------------------------------------------------------------------

/// D47 positive case (1): top-level unqualified import (a direct element
/// position at program top level — the main program's N2 injection-face
/// entry; symmetric with the require position discipline E0018).
#[test]
fn d47_toplevel_import_plain_works() {
    let ok = run_source(
        "import kerf_list;\nimport kerf_list;\nlet r = append(list(1), list(2));\nrequire io, write;\nprint(r)",
        FNAME,
    )
    .expect("top level import should be legal(D47)");
    let _ = ok;
    // Position discipline: any direct top-level element (import is not confined to a leading zone
    // — mirrors require)
    let ok2 = run_source(
        "let x = 1;\nimport kerf_pair;\nlet r = cons(x, 2);\nx",
        FNAME,
    )
    .expect("top level any intent position import should be legal(E0018 symmetric)");
    let _ = ok2;
}

/// D47 positive case (2): top-level as-alias import (alias qualified-name
/// normalization covers top-level references).
#[test]
fn d47_toplevel_import_alias_works() {
    let ok = run_source(
        "import kerf_string as s;\nlet r = s::append(\"a\", \"b\");\nrequire io, write;\nprint(r)",
        FNAME,
    )
    .expect("top level alias import should be legal(D47 + R-N5)");
    let _ = ok;
}

/// D47 positive case (3): top-level `import kerf_prelude;` triggers
/// injection (the imports_prelude extension — the main-program-face
/// injection entry).
#[test]
fn d47_toplevel_import_prelude_injects() {
    let ok = run_source(
        "import kerf_prelude;\nimport kerf_prelude;\nrequire io, write;\nprint(map(||(x: i64) { x * x }, list(1, 2, 3)))",
        FNAME,
    )
    .expect("top level import kerf-prelude should trigger injection(D47)");
    let _ = ok;
}

/// D47 negative case: import inside an expression subtree / mid-body is
/// rejected (import is an organization declaration, not an expression —
/// the three-way position discipline). E6 target-face note: on this face
/// the discipline is lexically fronted to the Reader (`import` is a
/// declaration Token — the ktf_import_alias_tests precedent); the
/// expander's E0002 message stays the shared backstop for macro-produced
/// shapes.
#[test]
fn d47_midbody_import_still_e0002() {
    for src in [
        "fn f() { import kerf_list; 1 }",
        "do(import(kerf_list), 1)",
        "if (true) { import kerf_list; 1 } else { 2 }",
    ] {
        expect_read_err(src, "KwImport");
    }
}

/// D47 negative case: top-level import of an unknown module → E0019
/// (post-stripping list check — the "registered list" hint shows the
/// main-program-face entry is genuinely in place).
#[test]
fn d47_toplevel_unknown_module_e0019() {
    expect_compile_err("import kerf_nonexistent;", 19, "unknown imported module");
}

/// D48: reserved-domain dual-form enforcement (the kerf/ slash form —
/// module names and qualified names share the identifier lexical domain;
/// `kerf::evil` is the module-name shape of a single Path token). E6
/// target-face note: the module-name slot is Ident-only, so the slash-form
/// occupation attempt is fronted to the Reader (fail-closed — the E0015
/// compile face stays anchored by the hyphen arm).
#[test]
fn d48_reserved_domain_slash_form() {
    expect_read_err(
        "module kerf::evil { define(x, 1) }\nlet q = x;",
        "module name identifier",
    );
    // Existing enforcement of the hyphen form maintained (M1 anchor regression)
    expect_compile_err(
        "module kerf_evil2 { let x = 1; }",
        15,
        "reserved domain violation",
    );
}

/// D49 positive case: E0022 compile-time unbound (the shape proven by
/// probe — check rejects first instead of a run-stage E0004 surprise;
/// the "typo or missing import" hint is in place).
#[test]
fn d49_unbound_ref_compile_time() {
    expect_compile_err(
        "let r = map(||(x: i64) { x }, ());",
        22,
        "unbound reference",
    );
    expect_compile_err("let r = nope_fn(1);", 22, "unbound reference");
    // Gated name not authorized → the E0006 semantic domain comes before E0022 (not eroded)
    expect_compile_err("print(5)", 6, "write capability");
}

/// D49 boundary: a hygienic suffixed name whose base name hits → passes
/// (compile-time fronting and runtime fallback resolution share the same
/// logic — the main path for macro-introduced builtin references is
/// maintained).
#[test]
fn d49_hygienic_base_resolves() {
    let ok = run_source(
        "macro m() { () => 1 + 41 }\nm()",
        FNAME,
    )
    .expect("macro-introduced builtin base name quote use should via retreat parse pass(D49 base name basis)");
    let _ = ok;
}

/// D49 boundary: assign target unbound → E0022 (StoreGlobal path
/// interning — compile-time fronting of the same semantics as the runtime
/// E0004 assign-unbound).
#[test]
fn d49_assign_target_unbound() {
    expect_compile_err("undefined_s = 1;", 22, "unbound reference");
    // Bound main path maintained
    let ok = run_source("let n = 1; n = 5; n", FNAME).expect("binding assign positive path");
    let _ = ok;
}

/// D50: prelude re-export-face metadata contract (preamble.ktf header —
/// the single source since the E5 close-out cleanup batch r120 / 190-a:
/// the S-expr original preamble.krf was deleted, principle 41; the target
/// face's `_` word separators map back to the semantic-face `-` names at
/// the Reader's symbol-introduction boundary [symbol_name, r109],
/// so the assertion surface below is unchanged) — (import kerf-core
/// kerf-pair kerf-list) + export of 20 names; this test locks the single
/// source against drift.
#[test]
fn d50_prelude_reexport_face_metadata() {
    let src = include_str!("../../../../crates/kerf-driver/src/bootstrap/preamble.ktf");
    let out = kerf_driver::compile_source(src, "preamble.ktf")
        .expect("preamble.ktf header expand expand after should compile pass(D50 element data state -- E5 close-out after single source switch)");
    // Module node in place + header contract (imports 2 + exports 20 — single-source lock)
    // r164 / 235-c: find BY NAME — the cascade injection puts the kerf-list
    // module form FIRST in preamble.ktf's compilation unit (dependency
    // order — list before preamble, list-self-built-design.md D3/D4), so
    // the first-module find_map now hits kerf-list; the by-name lookup
    // locks the same contract.
    let module = out
        .core
        .iter()
        .find_map(|e| match e {
            kerf_core::ModuleItem::Module {
                name,
                imports,
                exports,
                ..
            } => {
                if out.table.name(*name) == "kerf-prelude" {
                    Some((name, imports, exports))
                } else {
                    None
                }
            }
            _ => None,
        })
        .expect("preamble module node should in expand artifact in");
    assert_eq!(out.table.name(*module.0), "kerf-prelude");
    assert_eq!(
        module.1.len(),
        3,
        "prelude header import three item(kerf-core/kerf-pair + kerf-list -- D50 ② payload step: nth/drop again export source declaration)"
    );
    assert_eq!(
        module.2.len(),
        20,
        "prelude export face 20 name (from has five item + pair three + table domain two + predicate ten -- D50 verdict per set)"
    );
    // The five own entries are on the export face (map/filter/foldl/foldr/for-each)
    let names: Vec<String> = module
        .2
        .iter()
        .map(|s| out.table.name(*s).to_string())
        .collect();
    for own in ["map", "filter", "foldl", "foldr", "for-each"] {
        assert!(
            names.contains(&own.to_string()),
            "export face should contain from has five item: {}",
            own
        );
    }
    // Re-export-face spot checks (cons/head/tail/nth/drop/is-nil — the D50 criteria set)
    for re in [
        "cons",
        "head",
        "tail",
        "nth",
        "drop",
        "is-nil",
        "is-procedure",
    ] {
        assert!(
            names.contains(&re.to_string()),
            "export face should contain again export name: {}",
            re
        );
    }
}

// ===========================================================================
// r47 / 68-b visibility-tightening leg (D54 (3) visibility reconciliation
// test group — carried by the D55 rulings)
// ===========================================================================

/// D55 (1): flat names rejected without import (N1 contraction — E0022
/// carries an import suggestion plus layer-by-layer detail).
#[test]
fn d55_flat_rejected_without_import() {
    // list-domain contracted names: E0022 + an (import kerf-list) suggestion
    expect_compile_err(
        "append(list(1), list(2))",
        22,
        "(import kerf-list) available after",
    );
    expect_compile_err("length(list(1))", 22, "(import kerf-list) available after");
    // string-domain contracted names: E0022 + an (import kerf-string) suggestion
    expect_compile_err(
        "string_append(\"a\", \"b\")",
        22,
        "(import kerf-string) available after",
    );
    expect_compile_err(
        "string_length(\"a\")",
        22,
        "(import kerf-string) available after",
    );
    // Layer-by-layer detail message shape (N3/N2/N1 three layers + R-N1 step 4)
    let e = run_source("reverse(list(1))", FNAME).expect_err("exempt import should reject");
    assert!(
        e.rendered.contains("N3 local binding"),
        "layer detail N3: {}",
        e.rendered
    );
    assert!(
        e.rendered.contains("N2 import injection face"),
        "layer detail N2: {}",
        e.rendered
    );
    assert!(
        e.rendered.contains("N1 core face"),
        "layer detail N1: {}",
        e.rendered
    );
}

/// D55 (2): flat names visible after import (the face-check main path —
/// the flat runtime payload).
#[test]
fn d55_flat_visible_with_import() {
    assert_eq!(
        common::run_rendered("import kerf_list;\nappend(list(1), list(2))"),
        "(1 2)"
    );
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring_append(\"a\", \"b\")"),
        "ab"
    );
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring_length(\"abc\")"),
        "3"
    );
}

/// D55 (3): qualified names require a prior import (E0014 domain
/// extension — the R-N3 visibility gate) + usable after import.
#[test]
fn d55_qualified_needs_import() {
    // Not imported: E0014 requires a prior import (the message carries (import kerf-ns) guidance)
    expect_compile_err(
        "string::append(\"a\", \"b\")",
        14,
        "qualified name `string/append` requires first import",
    );
    expect_compile_err(
        "list::length(list(1))",
        14,
        "(import kerf-list) the qualified form is available after",
    );
    // After import: qualified names usable (including the module header-zone import form)
    assert_eq!(
        common::run_rendered("import kerf_string;\nstring::append(\"a\", \"b\")"),
        "ab"
    );
    assert_eq!(
        common::run_rendered("module m { import kerf_list; list::length(list(1, 2)) }"),
        "2"
    );
}

/// D55 (4): io gate coincidence (one require io declaration serves both
/// gates — the qualified form needs no import).
#[test]
fn d55_qualified_io_gate_coincidence() {
    // require io + the io:: qualified form: the visibility gate and the authorization gate coincide
    // (zero double declaration)
    let o = run_source("require io, write;\nio::print(42)", FNAME)
        .expect("io qualified form follow require can use(D52 channel table -- two gate io family boundary re-combine)");
    let _ = o;
    // Unauthorized: the E0006 semantic domain comes first (not eroded)
    expect_compile_err("io::print(42)", 6, "write capability");
}

/// D55 (5): the prelude high-frequency set (D50 (2) payload step —
/// single-source derivation of the injection face).
#[test]
fn d55_prelude_highfreq_face() {
    // map (one of the five own entries) + nth/drop (kerf-list re-exports) — visible after
    // importing the prelude
    assert_eq!(
        common::run_rendered("import kerf_prelude;\nmap(||(x: i64) { x * x }, list(1, 2, 3))"),
        "(1 4 9)"
    );
    assert_eq!(
        common::run_rendered("import kerf_prelude;\nnth(list(1, 2, 3), 1)"),
        "2"
    );
    assert_eq!(
        common::run_rendered("import kerf_prelude;\ndrop(list(1, 2, 3), 1)"),
        "(2 3)"
    );
    // Not imported: E0022 suggests the prelude (high-frequency set first — suggest_import_for
    // single source)
    expect_compile_err(
        "map(||(x: i64) { x }, list(1))",
        22,
        "(import kerf-prelude) available after",
    );
    expect_compile_err(
        "foldr(||(x: i64, acc: i64) { x }, 0, list(1))",
        22,
        "(import kerf-prelude) available after",
    );
    // prelude + kerf-list coexist: nth/drop re-export the same underlying name — not a conflict
    // (E0013 re-basing)
    assert_eq!(
        common::run_rendered(
            "import kerf_prelude;\nimport kerf_list;\nnth(append(list(1), list(2)), 1)"
        ),
        "2"
    );
}

/// D55 (6): the N1 core face is visible with zero declarations (no gate
/// on data-model vocabulary — corollary of D50 criterion (1)).
#[test]
fn d55_n1_core_always_visible() {
    assert_eq!(common::run_rendered("head(cons(1, 2))"), "1");
    assert_eq!(common::run_rendered("tail(cons(1, 2))"), "2");
    assert_eq!(common::run_rendered("list(1, 2, 3)"), "(1 2 3)");
    assert_eq!(common::run_rendered("is_pair(())"), "false");
    assert_eq!(common::run_rendered("eq(quote(a), quote(a))"), "true");
    assert_eq!(common::run_rendered("not(true)"), "false");
    assert_eq!(common::run_rendered("assert_eq(1, 1)"), "true");
}

/// D55 (7): alias-qualified import (an alias is an additional binding —
/// the import gate counts via the alias).
#[test]
fn d55_alias_qualified_import() {
    // as alias: the qualified form normalizes via the alias + the module import gate counts via
    // the alias
    assert_eq!(
        common::run_rendered("import kerf_string as s;\ns::append(\"a\", \"b\")"),
        "ab"
    );
    // The original module's qualified form is equally usable after an alias import (same shape as
    // Rust use-as: an additional binding, not exclusive)
    assert_eq!(
        common::run_rendered("import kerf_string as s;\nstring::append(\"a\", \"b\")"),
        "ab"
    );
    // Unbound alias form → E0014 (no module resolves the alias ns — the not-exported shape)
    expect_compile_err(
        "str::append(\"a\", \"b\")",
        14,
        "`str` does not export `append`",
    );
}

/// D55 (8): W1003/W1002 face-aware (invisible-face names may be defined
/// freely — zero-false-positive discipline).
#[test]
fn d55_shadow_face_aware() {
    // Macro name = a not-imported domain name (append without import) → zero W1003 (invisible-face
    // names defined freely)
    let o = run_source(
        "module m { macro append() { (a, b) => 9 } append(1, 2) }",
        FNAME,
    )
    .expect("macro name shadow cannot see face name should zero warning run");
    assert!(
        o.warnings.is_empty(),
        "cannot see face name not should W1003: {:?}",
        o.warnings
            .iter()
            .map(|w| w.message.clone())
            .collect::<Vec<_>>()
    );
    // After import: a macro name shadowing a visible-face name → W1003 notice (face-aware positive
    // case)
    let o2 = run_source(
        "import kerf_list;\nmodule m { macro append() { (a, b) => 9 } append(1, 2) }",
        FNAME,
    )
    .expect("macro name shadow visible face name should run(W level non-blocking)");
    assert!(
        o2.warnings.iter().any(|w| w
            .message
            .contains("macro name `append` shadows visible builtin name")),
        "import after macro shadow should W1003: {:?}",
        o2.warnings
            .iter()
            .map(|w| w.message.clone())
            .collect::<Vec<_>>()
    );
}

// ---------------------------------------------------------------------------
// r49 / E5 S3 declaration-layer arm (22 §17 D59): the position-discipline
// fronting negative group + do-splice end to end (d59 group)
// ---------------------------------------------------------------------------

/// E0023: structured rejection of module in expression position
/// (previously unchecked — silent inline compilation tightened into an
/// explicit rejection; symmetric with the import/export E0002 message
/// shape). E6 target-face note: a module inside a fn body / if arm is
/// lexically fronted to the Reader (`module` is a declaration Token —
/// the fail-closed criterion unchanged, the stage moves to Read); the
/// expander's E0002/E0023 messages stay the shared backstop for
/// macro-produced shapes.
#[test]
fn d59_module_position_e0023_expression() {
    expect_read_err("fn f(x: i64) { module m { 1 } }", "KwModule");
    expect_read_err("if (true) { module m { 1 } } else { 2 }", "KwModule");
}

/// E0003 fronted (expander structural dispatch — message kept verbatim,
/// stage code E0002 [expand]): do inside a function body / define wrapped
/// in expression position.
#[test]
fn d59_define_position_expander_reject() {
    let e = run_source("fn f(x: i64) { define(y, 2); x }", FNAME).unwrap_err();
    assert_eq!(
        e.stage,
        Stage::Expand,
        "r49 advance expand phase: \n{}",
        e.rendered
    );
    assert!(
        e.rendered
            .contains("define is only allowed at the top level or at the head of a function body"),
        "D59 message form: \n{}",
        e.rendered
    );
    assert!(e.rendered.contains("error[E0002]"));
}

/// do-splice end to end (D59 core mechanism — bytecode [item; Pop]* ≡
/// item-order equality): top-level do wrapping defines and expressions →
/// the spliced item order compiles and executes correctly.
#[test]
fn d59_toplevel_do_splice_end_to_end() {
    // do(define(x, 7), x) → two items [Define x, Expr x] → value 7
    assert_eq!(common::run_rendered("do(define(x, 7), x)"), "7");
    // A macro producing a top-level define (the def-twice shape — the
    // driving case for splice; it references the pattern-variable-bound
    // x[=7] — the macro-introduced name n2 is hygiene-isolated and not
    // user-referenceable [designed behavior, same rule as the r48
    // baseline — verified against a stash comparison])
    assert_eq!(
        common::run_rendered(
            "macro def_twice() { (n, v) => do(define(n, v), define(n2, v)) }\ndef_twice(x, 7); x + x"
        ),
        "14"
    );
    // Empty do splice → nil
    assert_eq!(common::run_rendered("do()"), "nil");
}

// ---------------------------------------------------------------------------
// r50 / D65 (22 §18.3): member-level selective imports — the d66 group.
// The selected subset applies to the flat injection face (the E0022
// visible face); qualified-name access keeps the module-level import
// relation (isomorphic to Kotlin/Java specific imports); E0024 for a
// member not on the export face.
// ---------------------------------------------------------------------------

/// Selective-import positive case: the selected members become
/// flat-visible + execute end to end.
#[test]
fn d66_selective_import_flat_visibility() {
    // The selected member's underlying name is flat-visible (string::append → underlying
    // string-append)
    assert_eq!(
        common::run_rendered("use kerf_string::{append};\nstring_append(\"a\", \"b\")"),
        "ab"
    );
    // Multi-member selection
    assert_eq!(
        common::run_rendered(
            "use kerf_string::{append, length};\nstring_length(string_append(\"a\", \"b\"))"
        ),
        "2"
    );
}

/// Selective-import negative case: unselected members are not flat-visible
/// (E0022 — the visible face is filtered by the selection).
#[test]
fn d66_selective_import_unselected_rejected() {
    let e = run_source("use kerf_string::{append};\nstring_length(\"a\")", FNAME).unwrap_err();
    assert!(
        e.rendered.contains("error[E0022]"),
        "unselected member should E0022: \n{}",
        e.rendered
    );
    assert!(e.rendered.contains("string-length"));
}

/// Qualified-name access keeps the module-level import relation (the
/// selection = flat-namespace hygiene, not a trimming of the module
/// relation — both the str alias and the original module's qualified form
/// remain reachable).
#[test]
fn d66_selective_import_qualified_still_module_level() {
    assert_eq!(
        common::run_rendered("use kerf_string::{append};\nstring::length(\"ab\")"),
        "2"
    );
    assert_eq!(
        common::run_rendered("use kerf_string::{append} as str;\nstr::append(\"x\", \"y\")"),
        "xy"
    );
}

/// E0024: a selective-import member not on the module export face
/// (fail-closed + actionable).
#[test]
fn d66_selective_import_member_not_exported_e0024() {
    let e = run_source("use kerf_string::{nonexist};", FNAME).unwrap_err();
    assert_eq!(
        e.stage,
        Stage::Compile,
        "E0024 compile-time: \n{}",
        e.rendered
    );
    assert!(
        e.rendered.contains("error[E0024]"),
        "code position E0024: \n{}",
        e.rendered
    );
    assert!(
        e.rendered
            .contains("selective import member `nonexist` not in module `kerf-string` export face"),
        "E0024 message form: \n{}",
        e.rendered
    );
}

/// Selective import coexisting with full import: for the same module,
/// full-then-selective (or the reverse) = full-import semantics
/// (first-seen/union — the union of the selected member set with the full
/// set is always ⊇ the selected set).
#[test]
fn d66_selective_plus_full_import_union() {
    assert_eq!(
        common::run_rendered(
            "import kerf_string;\nuse kerf_list::{append};\nappend(list(1), list(2))"
        ),
        "(1 2)"
    );
}

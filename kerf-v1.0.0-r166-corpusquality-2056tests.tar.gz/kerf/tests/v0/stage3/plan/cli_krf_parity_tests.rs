//! Build-system segment second cut parity tests (r79 / 149-b — TD-032 CLI
//! orchestration face acceptance vehicle).
//!
//! **Criterion**: CLI subcommand dispatch judgment agrees on both faces —
//! the Rust seed oracle (`bootstrap::cli::dispatch_seed` — main.rs's
//! original production dispatch, now in a retired role) vs the .krf
//! production face (`bootstrap/cli.krf` run on the VM through the
//! `bootstrap::cli` bridge — **the production path is switched**; this
//! parity is the switch guard).
//!
//! Coverage (≥12 cases): twelve-member tuple truth values (run/check/test/
//! tokens/stx/core/ir/bc/code/bench/anf/native) + the three-member
//! missing-file set (NeedsFile) + eval retired (both file-presence states) +
//! dump family missing file (Unknown — the usage face) + unknown
//! subcommand + empty command name + full matrix sweep (15 commands × 2
//! presence states = 30 combinations, mechanical two-face reconciliation) +
//! production liveness probe.

use kerf_driver::bootstrap::cli::{dispatch as krf_dispatch, dispatch_seed, CliAction};

/// Two-face parity assertion: both sides' dispatch match the expectation.
fn assert_parity(cmd: &str, has_file: bool, expect: CliAction) {
    let rust = dispatch_seed(cmd, has_file);
    assert_eq!(
        rust, expect,
        "Rust oracle differs from expectation: {}",
        cmd
    );
    let krf = krf_dispatch(cmd, has_file).expect("cli.krf bridge internal error");
    assert_eq!(
        krf, expect,
        "krf production face differs from expectation: {}",
        cmd
    );
    assert_eq!(
        rust, krf,
        "dual-face dispatch divergence(parity broken): {}",
        cmd
    );
}

// ---------------------------------------------------------------------------
// parity corpus (twenty-two cases — twelve-member tuple truth values +
// three error shapes + boundaries)
// ---------------------------------------------------------------------------

/// run + file (main path — compile + VM execution).
#[test]
fn parity_run_with_file() {
    assert_parity("run", true, CliAction::Run);
}

/// check + file (dry-compile path).
#[test]
fn parity_check_with_file() {
    assert_parity("check", true, CliAction::Check);
}

/// test + file (case-runner path).
#[test]
fn parity_test_with_file() {
    assert_parity("test", true, CliAction::Test);
}

/// tokens + file (dump-family representative 1/6).
#[test]
fn parity_tokens_with_file() {
    assert_parity("tokens", true, CliAction::Tokens);
}

/// stx + file (dump-family representative 2/6).
#[test]
fn parity_stx_with_file() {
    assert_parity("stx", true, CliAction::Stx);
}

/// core + file (dump-family representative 3/6).
#[test]
fn parity_core_with_file() {
    assert_parity("core", true, CliAction::Core);
}

/// ir + file (dump-family representative 4/6).
#[test]
fn parity_ir_with_file() {
    assert_parity("ir", true, CliAction::Ir);
}

/// bc + file (dump-family representative 5/6).
#[test]
fn parity_bc_with_file() {
    assert_parity("bc", true, CliAction::Bc);
}

/// code + file (dump-family representative 6/6).
#[test]
fn parity_code_with_file() {
    assert_parity("code", true, CliAction::Code);
}

/// bench + file (performance benchmark path — the optional N argument does not participate in the dispatch judgment).
#[test]
fn parity_bench_with_file() {
    assert_parity("bench", true, CliAction::Bench);
}

/// anf + file (AnnotatedANF summary path).
#[test]
fn parity_anf_with_file() {
    assert_parity("anf", true, CliAction::Anf);
}

/// native + file (QBE AOT path).
#[test]
fn parity_native_with_file() {
    assert_parity("native", true, CliAction::Native);
}

/// run missing file (NeedsFile — dedicated error-message shape).
#[test]
fn parity_run_needs_file() {
    assert_parity("run", false, CliAction::NeedsFile);
}

/// check missing file (NeedsFile).
#[test]
fn parity_check_needs_file() {
    assert_parity("check", false, CliAction::NeedsFile);
}

/// test missing file (NeedsFile — complete three-member reconciliation).
#[test]
fn parity_test_needs_file() {
    assert_parity("test", false, CliAction::NeedsFile);
}

/// eval + file (retired — file presence does not affect the retired judgment).
#[test]
fn parity_eval_retired_with_file() {
    assert_parity("eval", true, CliAction::EvalRetired);
}

/// eval missing file (both retired states covered).
#[test]
fn parity_eval_retired_without_file() {
    assert_parity("eval", false, CliAction::EvalRetired);
}

/// dump family missing file (Unknown — the usage face, not NeedsFile;
/// boundary anchor distinguishing it from the three-member shape).
#[test]
fn parity_dump_missing_file_is_unknown() {
    assert_parity("tokens", false, CliAction::Unknown);
    assert_parity("bench", false, CliAction::Unknown);
    assert_parity("native", false, CliAction::Unknown);
}

/// Unknown subcommand + file (Unknown — the original `_` fallback arm).
#[test]
fn parity_unknown_with_file() {
    assert_parity("bogus", true, CliAction::Unknown);
}

/// Unknown subcommand missing file (both Unknown states covered).
#[test]
fn parity_unknown_without_file() {
    assert_parity("bogus", false, CliAction::Unknown);
}

/// Empty command-name boundary (Unknown — the zero-length string is no known prefix).
#[test]
fn parity_empty_cmd_boundary() {
    assert_parity("", true, CliAction::Unknown);
    assert_parity("", false, CliAction::Unknown);
}

/// Full matrix sweep (15 commands × 2 presence states = 30 combinations —
/// mechanical two-face reconciliation; including the case-sensitivity
/// boundary Run/RUN — command-name exact-match anchor).
#[test]
fn parity_full_matrix_sweep() {
    let cmds = [
        "run", "check", "test", "tokens", "stx", "core", "ir", "bc", "code", "bench", "anf",
        "native", "eval", "bogus", "",
    ];
    for cmd in cmds {
        for has_file in [true, false] {
            let rust = dispatch_seed(cmd, has_file);
            let krf = krf_dispatch(cmd, has_file)
                .unwrap_or_else(|e| panic!("cli.krf bridge internal error({}): {}", cmd, e));
            assert_eq!(
                rust, krf,
                "dual-face dispatch divergence(parity broken): cmd={} has_file={}",
                cmd, has_file
            );
        }
    }
    // Case-sensitivity boundary (exact match — not prefix/case folding)
    assert_parity("Run", true, CliAction::Unknown);
    assert_parity("RUN", true, CliAction::Unknown);
    assert_parity("ru", true, CliAction::Unknown);
}

// ---------------------------------------------------------------------------
// Production liveness (switch guard — mirrors the first cut's
// production_*_is_bootstrap form)
// ---------------------------------------------------------------------------

/// Production liveness probe: lazy loading + same-thread reuse + production
/// judgment as a triple (`main` consumes the same entry — this test is the
/// empirical proof of production-path liveness).
#[test]
fn production_cli_is_bootstrap() {
    // After lazy loading the production judgment returns directly
    assert_eq!(
        krf_dispatch("run", true).expect("run dispatch"),
        CliAction::Run
    );
    assert_eq!(
        krf_dispatch("unknown-cmd", true).expect("unknown dispatch"),
        CliAction::Unknown
    );
}

//! Switch-window step (5) validation-equivalence gate (r119 / 189-a —
//! the fixpoint-isomorphism closing batch).
//!
//! **Verification face** (07 §3.2.1 step (5) "verify that the
//! target-syntax compiler's compilation of itself is equivalent" + the
//! 11 §6.3 three-layer protocol + BS-C of principle 53):
//! (1) **layer 1 unit level** — the skin-dictionary full-table
//!     SemanticProof (02 §8.12 D2 six mappings + the 20 §14 finalized-
//!     domain extension, one machine anchor per entry) through the
//!     structured `SyntaxTransitionValidator` (the 02 §8.12 design
//!     registration made real — dual parse → same table → seed pipeline
//!     → cross-syntax semantic-payload equality);
//! (2) **layer 2 program level** — whole-program dual compile + same run
//!     result (payload equality ⇒ same bytecode ⇒ same behavior, plus
//!     behavioral anchors on the production chain);
//! (3) **layer 3 autobuild level** — the target-syntax three-stage
//!     fixpoint gate plus the transitivity extension (B₁' → B₂' → B₃' —
//!     three-point equality; the dual-caliber unification's .krf leg and
//!     the compile-speed acceptance line were retired with the deleted
//!     .krf originals by the E5 close-out cleanup batch r120 / 190-a,
//!     principle 41 — the speed line's measured values 0.990/1.005/1.119
//!     are archived in RELEASE r119 + switch-window-plan v1.8 §5;
//!     11 §6.3 criterion 4 was thereby fulfilled and closed);
//! (4) **diagnostic-face parity** (the 11 §6.3 migration-acceptance
//!     criterion: the same logical error in both syntaxes → same
//!     diagnostic code + message — the expander is a shared logic
//!     implementation, spans naturally differ across texts);
//! (5) **validator unit anchor** — the SemanticDrift four-tuple
//!     diagnosis on a deliberately mismatched pair (fail-path honesty).
//!
//! The out-of-domain fail-closed guards (use/match/ranges/pipes/bitwise/
//! as/type-family — nine cases) remain covered by
//! `target_reader_tests::domain_out_diagnostics` (r106) — re-confirmed
//! unchanged for the closing batch, not duplicated here.
//!
//! Basis: 07 §3.2.1 (five-step process, step (5)) / 11 §6.2-§6.3
//! (SyntaxTransitionValidator + three-layer + three-stage) / 02 §8.12
//! (parity-discipline structured registration) / 20 §14 (skin dictionary
//! finalized domain) / principle 53 (BS-C) / principle 31 (skin/skeleton
//! isomorphism).

use kerf_driver::bootstrap::compiler::{
    install_state as install_compiler, reset_state as reset_compiler,
};
use kerf_driver::bootstrap::expander::{
    install_state as install_expander, reset_state as reset_expander,
};
use kerf_driver::bootstrap::{install_state as install_reader, reset_state as reset_reader};
use kerf_driver::{
    compile_source, compile_source_target, run_source, set_cache_enabled, sha256_hex,
    SyntaxTransitionValidator, TransitionCase,
};
use kerf_vm::render_value;

/// Target-syntax corpus (switch-window step (3) production artifacts).
const READER_KTF: &str = include_str!("../../../../crates/kerf-driver/src/bootstrap/reader.ktf");
const EXPANDER_KTF: &str =
    include_str!("../../../../crates/kerf-driver/src/bootstrap/expander.ktf");
const COMPILER_KTF: &str =
    include_str!("../../../../crates/kerf-driver/src/bootstrap/compiler.ktf");
const PREAMBLE_KTF: &str =
    include_str!("../../../../crates/kerf-driver/src/bootstrap/preamble.ktf");

// ---------------------------------------------------------------------------
// (1) Layer 1 unit level — skin-dictionary full-table SemanticProof
// ---------------------------------------------------------------------------

/// Layer-1 unit-level closing gate: the D2 six mappings (02 §8.12) —
/// one machine anchor per mapping through the structured validator
/// (dual parse → same SymbolTable → seed expand + seed compile →
/// cross-syntax semantic-payload equality; debug_spans cross-text
/// incomparable by design, excluded).
#[test]
fn skin_dictionary_semantic_proof_d2_six() {
    let cases = [
        // define → fn (function-definition face)
        TransitionCase::new(
            "define→fn",
            "(define (add a b) (+ a b)) (add 2 3)",
            "fn add(a: T, b: T) { a + b }\nadd(2, 3)",
        ),
        // let → let (single binder — the multi-binder face is the
        // extension-table anchor below)
        TransitionCase::new(
            "let→let(single binding)",
            "(define (f x) (let ((a 1)) (+ a x)))",
            "fn f(x: T) { let a = 1; a + x }",
        ),
        // if → if (statement-position branch)
        TransitionCase::new(
            "if→if",
            "(define (mx a b) (if (> a b) a b))",
            "fn mx(a: T, b: T) { if (a > b) { a } else { b } }",
        ),
        // perform → perform (two-argument payload — the trailing
        // two-element dotted pair of the cons chain)
        TransitionCase::new(
            "perform→perform",
            "(perform (cons 'gift (cons 0 20)))",
            "perform gift(0, 20);",
        ),
        // handle → handle (v1 single arm; protected expression first on
        // the target face)
        TransitionCase::new(
            "handle→handle",
            "(define (guarded) (handle gift ((p k) (resume k (+ (head p) (tail p)))) 41))",
            "fn guarded() { handle 41 { gift(p, k) => resume(head(p) + tail(p)) } }",
        ),
        // lambda → closure (D2: `||(params) { body }`)
        TransitionCase::new(
            "lambda→closure",
            "(define (adder n) (fn (x) (+ x n))) ((adder 3) 4)",
            "fn adder(n: T) { ||(x: T) { x + n } }\nadder(3)(4)",
        ),
    ];
    let report = SyntaxTransitionValidator::validate_test_suite(&cases);
    assert!(
        report.all_passed(),
        "D2 six map SemanticProof failed:{:#?}",
        report.failures
    );
    assert_eq!(report.total, 6, "D2 six map per-item count");
}

/// Layer-1 unit-level closing gate: the 20 §14 finalized-domain
/// extension entries — one machine anchor per implementable entry. The
/// `(try* e)` ↔ `try!(e)` entry is a **registered-state exemption**
/// (the try macro is a stdlib-macro positioning — 02 §8.3/§9.15.3 — not
/// an registered built-in sugar; no consumption face exists on either
/// surface, the machine anchor does not apply; honest boundary).
#[test]
fn skin_dictionary_semantic_proof_extension_eight() {
    let cases = [
        // `string/append` ↔ `string::append` (separator dual-face mapping,
        // 22 §27 — the target lexer merges `::` into the `/`-separated
        // path payload at the lexical layer)
        TransitionCase::new(
            "path partition separate symbol ::",
            "(define (app a b) (string/append a b))",
            "fn app(a: T, b: T) { string::append(a, b) }",
        ),
        // nil ↔ () (C12 ruling — the unit literal is the target face of
        // the S-expr nil)
        TransitionCase::new("nil↔()", "(define (zero x) nil)", "fn zero(x: T) { () }"),
        // while ↔ while! (explicit macro marker — the nine-sugar family;
        // `while!(test, body)` reads as `(while test body)` and expands
        // through the shared derived transformer)
        TransitionCase::new(
            "while↔while!",
            "(define (count n) (while (> n 0) (assign n (- n 1))) n)",
            "fn count(n: T) { while!(n > 0, n = n - 1); n }",
        ),
        // naming dual-face mapping `-` ↔ `_` (r109 — single-point mapping
        // at the symbol-introduction boundary)
        TransitionCase::new(
            "naming map -↔_",
            "(define (my-fn v) (+ v 1)) (my-fn 2)",
            "fn my_fn(v: T) { v + 1 }\nmy_fn(2)",
        ),
        // N1 module production face (r109 — import/export headers)
        TransitionCase::new(
            "module production face",
            "(module m (import a b) (export x y) (define (f v) v))",
            "module m { import a, b; export x, y; fn f(v: T) { v } }",
        ),
        // multi-binding let (r110 — the D61 staging-chain parity carrier)
        TransitionCase::new(
            "multiple binding let",
            "(define (f x) (let ((a 1) (b 2)) (+ a b)))",
            "fn f(x: T) { let a = 1, b = 2; a + b }",
        ),
        // symbol-literal call form (r110 — `'sym` ↔ `quote(sym)`)
        TransitionCase::new(
            "quote call form",
            "(list 'err 1 \"x\")",
            "list(quote(err), 1, \"x\")",
        ),
        // top-level value-definition call form (r110)
        TransitionCase::new(
            "define call form",
            "(define DIGITS (list 1 2))",
            "define(DIGITS, list(1, 2));",
        ),
    ];
    let report = SyntaxTransitionValidator::validate_test_suite(&cases);
    assert!(
        report.all_passed(),
        "expand sufficient eight clauses SemanticProof failed:{:#?}",
        report.failures
    );
    assert_eq!(
        report.total, 8,
        "expand sufficient eight clauses per-item count"
    );
}

// ---------------------------------------------------------------------------
// (2) Validator unit anchor — the fail-path honesty face
// ---------------------------------------------------------------------------

/// SemanticDrift four-tuple diagnosis on deliberately mismatched pairs:
/// (a) payload drift (same form count, different logic) — the drift
/// carries name / spans / description (caliber + first mismatch) /
/// suggestion; (b) form-count drift; (c) a target-face read error. The
/// validator must return drifts, not panic — the structured diagnosis
/// face of 02 §8.12.
#[test]
fn validator_semantic_drift_negative_anchor() {
    // (a) payload drift: +1 vs +2 — constant pools differ
    let mismatch = TransitionCase::new(
        "mismatched pair",
        "(define (f x) (+ x 1))",
        "fn f(x: T) { x + 2 }",
    );
    let drift = SyntaxTransitionValidator::validate_equivalence(&mismatch)
        .expect_err("mismatched pair should produce SemanticDrift");
    assert_eq!(drift.name, "mismatched pair", "four element group: name");
    assert!(
        drift.old_span.1 > 0 && drift.new_span.1 > 0,
        "four element group: both sides Span"
    );
    assert!(
        drift.description.contains("cross-syntax semantic payload"),
        "four element group: basis + first mismatch detailed section: {}",
        drift.description
    );
    assert!(
        !drift.suggestion.is_empty(),
        "four element group: fix build motion"
    );
    // (b) form-count drift
    let count_mismatch = TransitionCase::new("form count wrong allocate", "(a) (b)", "a()");
    let drift2 = SyntaxTransitionValidator::validate_equivalence(&count_mismatch)
        .expect_err("form count wrong allocate should produce SemanticDrift");
    assert!(
        drift2.description.contains("top-level form count mismatch"),
        "form count drift move description: {}",
        drift2.description
    );
    // (c) target-face read error (unclosed brace)
    let bad_target = TransitionCase::new("target face read failed", "(a)", "fn f(x: T) { x");
    let drift3 = SyntaxTransitionValidator::validate_equivalence(&bad_target)
        .expect_err("target face read failed should produce SemanticDrift");
    assert!(
        drift3.description.contains("read failed"),
        "read failed drift move description: {}",
        drift3.description
    );
}

// ---------------------------------------------------------------------------
// (3) Layer 3 autobuild level — fixpoint gate dual-caliber unification
// ---------------------------------------------------------------------------
/// **Layer-3 autobuild-level closing gate** (three-stage target-syntax
/// fixpoint + the BS-C transitivity extension; dual-caliber form retired
/// with the deleted .krf originals by the E5 close-out cleanup batch
/// r120 / 190-a, principle 41 — the former caliber 1, the .krf-chain
/// lightweight fixpoint re-check, lost its corpus and its full historical
/// form is archived in RELEASE r119 + the bootstrap_compiler_tests
/// retirement note; caliber 2 carries the duty on):
/// - **Three-stage fixpoint** — the target chain self-compilation
///   fixpoint: the four .ktf corpus files through the production target
///   chain (B₁') → install the three corpus stages → recompile (B₂') →
///   per-program full-structure bytecode equality + SHA-256 (the step-(4)
///   core gate re-confirmed in the same round).
/// - **Transitivity extension (BS-C)** — install the B₂' stages and
///   recompile compiler.ktf once more (B₃') → three-point equality
///   B₁' == B₂' == B₃' (the fixpoint is a stable fixed point, the
///   inductive step of the chain verification).
#[test]
fn fixpoint_gate_target_syntax_three_stage() {
    set_cache_enabled(false);

    // --- The .ktf chain three-stage fixpoint + transitivity ---
    let sources: [(&str, &str); 4] = [
        (READER_KTF, "reader.ktf"),
        (EXPANDER_KTF, "expander.ktf"),
        (COMPILER_KTF, "compiler.ktf"),
        (PREAMBLE_KTF, "preamble.ktf"),
    ];
    let names = ["reader.ktf", "expander.ktf", "compiler.ktf", "preamble.ktf"];
    reset_reader();
    reset_expander();
    reset_compiler();
    // B₁': the production target chain compiles the .ktf corpus itself
    let b1p: Vec<_> = sources
        .iter()
        .map(|(s, n)| compile_source_target(s, n).expect("B₁' compile failed"))
        .collect();
    // B₂': with B₁' output installed as the new self-hosted state
    install_reader(
        b1p[0].program.clone(),
        b1p[0].table.clone(),
        b1p[0].source_map.clone(),
    )
    .expect("B₁' Reader state install failed");
    install_expander(
        b1p[1].program.clone(),
        b1p[1].table.clone(),
        b1p[1].source_map.clone(),
    )
    .expect("B₁' Expander state install failed");
    install_compiler(
        b1p[2].program.clone(),
        b1p[2].table.clone(),
        b1p[2].source_map.clone(),
    )
    .expect("B₁' Compiler state install failed");
    let b2p: Vec<_> = sources
        .iter()
        .map(|(s, n)| compile_source_target(s, n).expect("B₂' compile failed"))
        .collect();
    for (i, name) in names.iter().enumerate() {
        assert!(
            b1p[i].program.bytecode_equal(&b2p[i].program),
            "fixpoint failed:{} B₁'/B₂' bytes differ",
            name
        );
        let (x, y) = (
            sha256_hex(format!("{:?}", b1p[i].program).as_bytes()),
            sha256_hex(format!("{:?}", b2p[i].program).as_bytes()),
        );
        assert_eq!(x, y, "fixpoint failed:{} B₁'/B₂' SHA-256 mismatch", name);
    }
    // B₃' transitivity: install the B₂' stages, recompile compiler.ktf
    // once more — the inductive step (B₁' == B₂' == B₃')
    install_reader(
        b2p[0].program.clone(),
        b2p[0].table.clone(),
        b2p[0].source_map.clone(),
    )
    .expect("B₂' Reader state install failed");
    install_expander(
        b2p[1].program.clone(),
        b2p[1].table.clone(),
        b2p[1].source_map.clone(),
    )
    .expect("B₂' Expander state install failed");
    install_compiler(
        b2p[2].program.clone(),
        b2p[2].table.clone(),
        b2p[2].source_map.clone(),
    )
    .expect("B₂' Compiler state install failed");
    let b3p = compile_source_target(COMPILER_KTF, "compiler.ktf").expect("B₃' compile failed");
    assert!(
        b2p[2].program.bytecode_equal(&b3p.program),
        "transitivity extension failed: compiler.ktf B₂'/B₃' bytes differ"
    );
    let d3 = sha256_hex(format!("{:?}", b3p.program).as_bytes());
    assert_eq!(
        sha256_hex(format!("{:?}", b2p[2].program).as_bytes()),
        d3,
        "transitivity extension failed: compiler.ktf B₂'/B₃' SHA-256 mismatch"
    );

    // Hygiene: restore lazily-reload semantics for the subsequent tests
    reset_reader();
    reset_expander();
    reset_compiler();
}

// ---------------------------------------------------------------------------
// (4) Diagnostic-face parity — the migration-acceptance criterion
// ---------------------------------------------------------------------------

/// The diagnostic-face parity (11 §6.3: same logical error in both
/// syntaxes → same diagnostic code + message). Three error families:
/// derived-sugar validator errors (the shared expander logic) and the
/// compile-time unbound-reference chain (N1-N3 resolution — the target
/// face's `undefined_macro` maps to the same interned `undefined-macro`
/// through the r109 naming entry, so the message agrees byte-for-byte).
/// Spans naturally differ across texts and stay out of the comparison
/// domain (the BS-C layered ruling).
///
/// Note (honest boundary): the zero-argument macro invocation `m!()`
/// is a lexical Unit-ambiguity domain — the target lexer merges `()`
/// into the Unit token before the MacroBang postfix branch (the
/// `perform Op()` face has an explicit Unit carve-out, the macro face
/// does not). Zero-argument macro calls have no legal semantics (every
/// derived sugar requires arguments), so the fail-closed read error is
/// an acceptable boundary, and the parity pairs below reach the shared
/// expander errors through non-empty argument shapes.
#[test]
fn diagnostic_face_parity_cross_syntax() {
    set_cache_enabled(false);
    let pairs: [(&str, &str, &str); 3] = [
        // derived-sugar validator error: cond clause must be a non-empty
        // list (a non-list payload — 5 — and an empty clause both hit it)
        ("(cond 5)", "cond!(5);", "cond non-list clause"),
        // empty-list clause (the target `()` macro argument reaches the
        // validator as the nil literal — same non-list failure branch)
        ("(cond ())", "cond!(());", "cond empty clause"),
        // compile-time unbound reference (E0022 — the N1-N3 resolution
        // chain; the target-face name maps through the r109 entry)
        (
            "(undefined-macro 42)",
            "undefined_macro(42);",
            "not definition quote use",
        ),
    ];
    for (sexpr_src, target_src, what) in pairs {
        let e1 = match compile_source(sexpr_src, "diag.krf") {
            Err(e) => e,
            Ok(_) => panic!("[{}] S-expr face should be diagnostic error", what),
        };
        let e2 = match compile_source_target(target_src, "diag.ktf") {
            Err(e) => e,
            Ok(_) => panic!("[{}] target face should be diagnostic error", what),
        };
        assert_eq!(
            e1.diagnostic.code.map(|c| c.0),
            e2.diagnostic.code.map(|c| c.0),
            "[{}] diagnostic code mismatch (cross-syntax same logic logic error)",
            what
        );
        assert_eq!(
            e1.diagnostic.message, e2.diagnostic.message,
            "[{}] diagnostic message mismatch (cross-syntax same logic logic error -- the same expand logic logic mirror implementation)",
            what
        );
    }
}

// ---------------------------------------------------------------------------
// (5) Layer 2 program level — whole-program dual compile + same run result
// ---------------------------------------------------------------------------

/// Layer-2 program-level closing gate: three representative programs
/// (arithmetic + higher-order closures + effect perform/handle) in both
/// syntaxes — payload equality through the structured validator (⇒ same
/// bytecode ⇒ same behavior, the constructive chain) plus behavioral
/// anchors executed on the production chain.
#[test]
fn layer2_program_level_dual_compile_run_parity() {
    set_cache_enabled(false);
    let cases = [
        // arithmetic + recursion (fib)
        TransitionCase::new(
            "fib program",
            "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (fib 12)",
            "fn fib(n: T) { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(12)",
        ),
        // higher-order closures
        TransitionCase::new(
            "high stage closure program",
            "(define (make-adder n) (fn (x) (+ x n))) ((make-adder 30) 12)",
            "fn make_adder(n: T) { ||(x: T) { x + n } }\nmake_adder(30)(12)",
        ),
        // effect perform/handle round trip (target face in the infix
        // expression skin — `100 + ask()`)
        TransitionCase::new(
            "effect round trip program",
            "(define (ask) (perform (cons 'gift (cons 0 20))))\n\
             (handle gift ((p k) (resume k (+ (head p) (tail p)))) (+ 100 (ask)))",
            "fn ask() { perform gift(0, 20); }\n\
             handle 100 + ask() { gift(p, k) => resume(head(p) + tail(p)) }",
        ),
    ];
    let report = SyntaxTransitionValidator::validate_test_suite(&cases);
    assert!(
        report.all_passed(),
        "layer 2 program level dual compile payload failed:{:#?}",
        report.failures
    );
    // Behavioral anchors on the production chain (payload equality ⇒
    // same bytecode ⇒ same behavior — anchored on the S-expr face)
    let v1 = run_source(cases[0].sexpr_src, "l2_fib.krf").expect("fib execution failed");
    assert_eq!(render_value(&v1.value, &v1.heap), "144", "fib 12 ⇒ 144");
    let v2 =
        run_source(cases[1].sexpr_src, "l2_ho.krf").expect("high stage closure execution failed");
    assert_eq!(
        render_value(&v2.value, &v2.heap),
        "42",
        "make_adder(30)(12) ⇒ 42"
    );
    let v3 = run_source(cases[2].sexpr_src, "l2_eff.krf").expect("effect program execution failed");
    assert_eq!(
        render_value(&v3.value, &v3.heap),
        "120",
        "handle gift ⇒ 100 + (0+20) = 120"
    );
}

// ---------------------------------------------------------------------------
// (6) Compile-speed regression acceptance line (trap 3 — <2x)
// ---------------------------------------------------------------------------

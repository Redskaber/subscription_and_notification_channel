//! .ktf const-declaration family tests — r161 / 231-c (the const window:
//! `const name [: T] = e;` → the as-if-written `(define name e')` — the
//! sixteenth skin mapping, the toplevel-let twin; const-declaration-
//! design.md v1.0/v1.1).
//!
//! **Verification surfaces** (the read-only binding face — principle 31
//! skin/skeleton isomorphism: the const-ness is consumed entirely at the
//! Reader layer via the sequential const-binding set driving the
//! item-position assign rejection; expander/compiler/HM/VM untouched;
//! 8 primitives' invariance round 43):
//! (1) **run-face E2E** — the const binding through `run_source` yields
//! the documented probe values (LIMIT + 1 ⇒ 6 / BASE cross-fn ⇒ 15 /
//! typed N ⇒ 14 / module item ⇒ 7 / the no-leak fresh-global ⇒ 2);
//! (2) **grammar settlement** — dual-Reader canonical Stx rendering
//! byte-identical (seed parse_const_decl vs mirror parse_const_decl),
//! error faces message + Span byte-identical across the four new
//! diagnostics (item-assign rejection / const-mut contradiction /
//! single-binding cap / block-position domain-out);
//! (3) **cross-stage consumption** — the const program through
//! `check_source_recover` stays diagnostic-clean with real instruction
//! artifacts (HM/check consume the identical define Stx);
//! (4) **fail-closed negatives** — the item-position assign rejection
//! (run/check ×2 integrated paths + Span anchor + dual-Reader parity ×4
//! diagnostics) / const-mut contradiction / single-binding cap /
//! block-position domain-out (fn body + if arm) / missing operands /
//! non-ident binder / path binder / trailing garbage / the kernel's
//! E0004 flat-table duplicate invariant on rebind attempts (let / fn /
//! const redecl — pre-existing, surfaced through the reader's
//! latest-binding-wins removals) / 7 error classes coverage (E0001
//! lexical / E0002 expand / E0004 duplicate / E0006 capability / E0022
//! unbound / E0005 multi-error recovery / the Read-stage faces
//! themselves).
//!
//! Honest-boundary anchors (design D4 — v0's read-only guarantee is
//! item-position-only): the module-local const does not leak (the
//! top-level assign creates a fresh global ⇒ 2) and the fn-body assign
//! of a const name stays outside the gate (block position — the
//! Stage 2+ type system owns scope-aware enforcement).
//!
//! Skin-dictionary basis: 20 §14 (the const→define row — the sixteenth
//! mapping, this window); 02 §8.13.1a v7.29 (the toplevel_const
//! production). Window basis: user instruction ① (「缺少常量的定义和
//! 描述从语法到具体语义和实现」— the 231-b-audit P1 finding: the
//! four-face total absence) + const-declaration-design.md v1.0 D1-D10.
//! Ratio: 8 positive : 24 negative = 1:3 (§9.4.3).

use kerf_driver::bootstrap::reader::read_source_for_bootstrap;
use kerf_driver::{check_source_recover, run_source, Stage};
use kerf_reader::reader::read_source;
use kerf_syntax::{Stx, StxDatum, StxLiteral, SymbolTable};

const ASSIGN_REJECT_MSG: &str =
    "cannot assign to a const binding (const bindings are read-only; rebind with let for mutation)";
const CONST_MUT_MSG: &str =
    "const mut is contradictory (a const binding is read-only; drop the mut)";
const SINGLE_MSG: &str =
    "top-level const takes a single binding (split into separate const statements)";
const BLOCK_DOMAIN_MSG: &str =
    "const declaration(item position only -- the read-only binding face)";

// ---------------------------------------------------------------------------
// Value helpers
// ---------------------------------------------------------------------------

fn run_value(src: &str, filename: &str) -> String {
    let outcome = run_source(src, filename)
        .unwrap_or_else(|e| panic!("target face program {} execution failed:{}", filename, e));
    kerf_vm::render_value(&outcome.value, &outcome.heap)
}

fn read_err(src: &str, filename: &str) -> kerf_reader::reader::ReadError {
    let mut sm = kerf_span::SourceMap::new();
    let fid = sm.add_file(filename, src);
    let mut table = SymbolTable::new();
    read_source(src, fid, &mut table)
        .err()
        .unwrap_or_else(|| panic!("[{}] expected a read error, parsed successfully", filename))
}

// ---------------------------------------------------------------------------
// Dual-Reader parity helpers (the ktf_toplevel_let_tests.rs caliber —
// canonical rendering with Span bytes; error parity with message + Span
// byte equality)
// ---------------------------------------------------------------------------

fn render_stx(s: &Stx, t: &SymbolTable) -> String {
    let mut out = String::new();
    render_stx_into(s, t, &mut out);
    out
}

fn render_stx_into(s: &Stx, t: &SymbolTable, out: &mut String) {
    match &s.datum {
        StxDatum::Symbol(sym) => {
            out.push_str(&format!(
                "(sym {} {}..{})",
                t.name(*sym),
                s.span.start,
                s.span.end
            ));
        }
        StxDatum::Literal(l) => match l {
            StxLiteral::Int(v) => {
                out.push_str(&format!("(int {} {}..{})", v, s.span.start, s.span.end))
            }
            StxLiteral::Float(f) => {
                out.push_str(&format!("(float {:?} {}..{})", f, s.span.start, s.span.end))
            }
            StxLiteral::Str(r) => {
                out.push_str(&format!("(str {:?} {}..{})", r, s.span.start, s.span.end))
            }
            StxLiteral::Bool(b) => {
                out.push_str(&format!("(bool {} {}..{})", b, s.span.start, s.span.end))
            }
            StxLiteral::Nil => out.push_str(&format!("(nil {}..{})", s.span.start, s.span.end)),
        },
        StxDatum::List(items) => {
            out.push_str("(lst");
            for it in items.iter() {
                out.push(' ');
                render_stx_into(it, t, out);
            }
            out.push_str(&format!(" {}..{})", s.span.start, s.span.end));
        }
        StxDatum::Vector(items) => {
            out.push_str("(vec");
            for it in items.iter() {
                out.push(' ');
                render_stx_into(it, t, out);
            }
            out.push_str(&format!(" {}..{})", s.span.start, s.span.end));
        }
    }
}

fn assert_grammar_parity(src: &str, what: &str) {
    let mut t1 = SymbolTable::new();
    let seed = read_source(src, 0, &mut t1)
        .unwrap_or_else(|e| panic!("[{}] seed syntax failed: {}", what, e.message));
    let mut t2 = SymbolTable::new();
    let mirror = read_source_for_bootstrap(src, 0, &mut t2)
        .unwrap_or_else(|e| panic!("[{}] mirror syntax failed:{}", what, e.message));
    assert_eq!(
        seed.len(),
        mirror.len(),
        "[{}] top-level item count mismatch (seed {} vs mirror {})",
        what,
        seed.len(),
        mirror.len()
    );
    for (i, (a, b)) in seed.iter().zip(mirror.iter()).enumerate() {
        assert_eq!(
            render_stx(a, &t1),
            render_stx(b, &t2),
            "[{}] top-level item #{} syntax tree mismatch (seed vs mirror canonical render)",
            what,
            i
        );
    }
}

fn assert_grammar_err_parity(src: &str, what: &str) -> kerf_reader::reader::ReadError {
    let mut t1 = SymbolTable::new();
    let seed_err = match read_source(src, 0, &mut t1) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] seed should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    let mut t2 = SymbolTable::new();
    let mirror_err = match read_source_for_bootstrap(src, 0, &mut t2) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] mirror should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    assert_eq!(
        seed_err.message, mirror_err.message,
        "[{}] syntax error message mismatch (seed {:?} vs mirror {:?})",
        what, seed_err.message, mirror_err.message
    );
    assert_eq!(
        seed_err.span.start, mirror_err.span.start,
        "[{}] syntax error Span start mismatch (seed {} vs mirror {})",
        what, seed_err.span.start, mirror_err.span.start
    );
    assert_eq!(
        seed_err.span.end, mirror_err.span.end,
        "[{}] syntax error Span end mismatch (seed {} vs mirror {})",
        what, seed_err.span.end, mirror_err.span.end
    );
    seed_err
}

// ---------------------------------------------------------------------------
// Positives — run-face E2E + grammar settlement + cross-stage consumption
// ---------------------------------------------------------------------------

/// Positive 1 / integration: the core E2E — the const binding's value
/// consumption (the 231-c probe c1 caliber: LIMIT + 1 ⇒ 6; print's
/// return is nil so the program tail carries the value itself).
#[test]
fn pos_const_e2e_value() {
    let src = "require io, write;\n\nconst LIMIT = 5;\n\nprint(LIMIT + 1);\nLIMIT + 1";
    assert_eq!(run_value(src, "const_e2e.ktf"), "6");
}

/// Positive 2: the const binding consumed across function bodies (the
/// 231-c probe p-e: BASE ⇒ 15 — the define Stx registers the global
/// exactly as let's does).
#[test]
fn pos_const_cross_fn_consumption() {
    let src = "const BASE = 10;\n\nfn add(n: i64) -> i64 { n + BASE }\n\nadd(5)";
    assert_eq!(run_value(src, "const_crossfn.ktf"), "15");
}

/// Positive 3: the type annotation parsed then stripped (the
/// fn_decl/toplevel_let precedent — the core has no type consumption
/// face; the 231-c probe c8: N ⇒ 14).
#[test]
fn pos_const_type_annotation_stripped() {
    let src = "const N: i64 = 7;\nN * 2";
    assert_eq!(run_value(src, "const_typed.ktf"), "14");
}

/// Positive 4: module item position — the declaration family symmetry
/// (parse_item dispatch — fn/import/export/require/let/const one
/// family; the 231-c probe p-d caliber).
#[test]
fn pos_const_module_item_position() {
    let src = "module m { export x; const x = 7; x }";
    assert_eq!(run_value(src, "const_module.ktf"), "7");
}

/// Positive 5: the same-Stx assertion — `const x = 1;` lowers to the
/// identical `(define x 1)` list the toplevel-let skin synthesizes
/// (skin swap, skeleton unchanged — principle 31's machine face; the
/// const-ness never crosses the Reader boundary).
#[test]
fn pos_same_core_form_as_toplevel_let() {
    let mut t1 = SymbolTable::new();
    let cst = read_source("const x = 1;", 0, &mut t1).unwrap();
    assert_eq!(cst.len(), 1);
    let items = cst[0].datum.as_list().unwrap();
    assert_eq!(
        items.len(),
        3,
        "the (define name value) three-element core form"
    );
    assert_eq!(t1.name(items[0].datum.as_symbol().unwrap()), "define");
    assert_eq!(t1.name(items[1].datum.as_symbol().unwrap()), "x");
    assert!(matches!(
        items[2].datum,
        StxDatum::Literal(StxLiteral::Int(1))
    ));
    // and structurally identical to the let skin's product — the
    // as-if-written twin (the datum skeleton is byte-equal; the only
    // span difference is the synthesized define symbol's own token:
    // const 0..5 vs let 0..3 — the r158 synthesized-define precedent,
    // the keyword's own extent, by design)
    let mut t2 = SymbolTable::new();
    let lst = read_source("let x = 1;", 0, &mut t2).unwrap();
    let let_items = lst[0].datum.as_list().unwrap();
    assert_eq!(let_items.len(), 3);
    assert_eq!(t2.name(let_items[0].datum.as_symbol().unwrap()), "define");
    assert_eq!(t2.name(let_items[1].datum.as_symbol().unwrap()), "x");
    assert!(matches!(
        let_items[2].datum,
        StxDatum::Literal(StxLiteral::Int(1))
    ));
    assert_eq!(
        t1.name(items[1].datum.as_symbol().unwrap()),
        t2.name(let_items[1].datum.as_symbol().unwrap()),
        "the binder symbol is the same symbol"
    );
}

/// Positive 6: dual-Reader canonical rendering byte-identical — the
/// grammar settlement core gate across const shapes (simple / typed /
/// module / mixed with fn and let).
#[test]
fn pos_dual_reader_canonical_parity() {
    assert_grammar_parity("const x = 1;\nx", "const simple");
    assert_grammar_parity(
        "const x: i64 = 1;\nconst y = x + 1;\ny",
        "const typed chain",
    );
    assert_grammar_parity(
        "fn f() { 1 }\nconst v = f();\nmodule m { export w; const w = 2; }\nv",
        "const mixed items",
    );
    assert_grammar_parity("const x = 1;\nlet y = x;\ny", "const then let");
}

/// Positive 7 / honest-boundary anchor (design D4): the module-local
/// const does not leak to the enclosing item scope — the top-level
/// assign of the same name creates a fresh global (the 231-c probe
/// p-b: ⇒ 2) — AND the fn-body assign of a const name stays outside
/// the item-position gate (block position; the Stage 2+ type system
/// owns scope-aware enforcement — the probe p-c: ⇒ 2).
#[test]
fn pos_honest_boundary_no_leak_and_block_assign() {
    let no_leak = "module M { const x = 1; }\nx = 2;";
    assert_eq!(
        run_value(no_leak, "const_noleak.ktf"),
        "2",
        "the module-local const must not gate the top-level assign (fresh global)"
    );
    let block_assign = "const x = 1;\n\nfn f() { x = 2; }\nf();\nx";
    assert_eq!(
        run_value(block_assign, "const_blockassign.ktf"),
        "2",
        "the fn-body assign of a const name stays outside the v0 gate (D4 boundary)"
    );
}

/// Positive 8 / integration (cross-stage): the const program through
/// `check_source_recover` stays diagnostic-clean with real instruction
/// artifacts (HM/check consume the identical define Stx — zero
/// mechanism change downstream).
#[test]
fn pos_check_cross_stage_consumption() {
    let src = "require io, write;\nconst x = 42;\nprint(x);\nx";
    let r = check_source_recover(src, "const_check.ktf").unwrap();
    assert!(
        r.diagnostics.is_empty(),
        "check must stay diagnostic-clean (actual: {:?})",
        r.diagnostics
    );
}

// ---------------------------------------------------------------------------
// Negatives — the read-only gate + structure discipline + domain
// boundaries + the kernel's flat-table invariant + 7 error classes
// ---------------------------------------------------------------------------

/// Negative 1 / integration (run path): the item-position assign
/// targeting a const binding is rejected with the read-only
/// diagnostic (the 231-c probe c2 — Stage::Read).
#[test]
fn neg_item_assign_run_path() {
    let err = run_source("const X = 1;\nX = 2;\nX", "const_assign.ktf").unwrap_err();
    assert_eq!(
        err.diagnostic.message, ASSIGN_REJECT_MSG,
        "the read-only diagnostic must be verbatim (actual rendered: {})",
        err.rendered
    );
    assert_eq!(err.stage, Stage::Read);
}

/// Negative 2 / integration (check path): the same rejection through
/// check_source_recover.
#[test]
fn neg_item_assign_check_path() {
    let err = check_source_recover("const X = 1;\nX = 2;", "const_assign_check.ktf").unwrap_err();
    assert_eq!(
        err.diagnostic.message, ASSIGN_REJECT_MSG,
        "the read-only diagnostic on the check path (actual rendered: {})",
        err.rendered
    );
    assert_eq!(err.stage, Stage::Read);
}

/// Negative 3: the rejection's Span = the name token itself (the r130
/// import-as span precedent — `X` at bytes 14..15 after "const X = 1;\n").
#[test]
fn neg_item_assign_span_is_name_token() {
    let e = read_err("const X = 1;\nX = 2;", "const_assign_span.ktf");
    assert_eq!(e.message, ASSIGN_REJECT_MSG);
    // "const X = 1;\n" = 13 bytes → the second-statement X at 13..14
    assert_eq!((e.span.start, e.span.end), (13, 14));
}

/// Negative 4: the rejection's dual-Reader error parity — message +
/// Span byte-identical (seed vs mirror) across the gate face.
#[test]
fn neg_item_assign_dual_reader_err_parity() {
    let e = assert_grammar_err_parity("const X = 1;\nX = 2;", "const assign gate");
    assert_eq!(e.message, ASSIGN_REJECT_MSG);
}

/// Negative 5: the gate fires inside module item position too (the
/// 231-c probe c7 — module-local const + module-body item assign).
#[test]
fn neg_item_assign_module_position() {
    let e = read_err("module M { const y = 1; y = 2; }", "const_module_gate.ktf");
    assert_eq!(e.message, ASSIGN_REJECT_MSG);
    assert_grammar_err_parity("module M { const y = 1; y = 2; }", "module gate parity");
}

/// Negative 6: `const mut` is semantically contradictory — the
/// dedicated fail-closed diagnostic (the 231-c probe c5).
#[test]
fn neg_const_mut_contradictory() {
    let e = read_err("const mut z = 1;", "const_mut.ktf");
    assert_eq!(e.message, CONST_MUT_MSG);
    // the span = the `mut` token itself: "const " = 6 bytes → 6..9
    assert_eq!((e.span.start, e.span.end), (6, 9));
}

/// Negative 7: the const-mut contradiction's dual-Reader parity.
#[test]
fn neg_const_mut_dual_reader_err_parity() {
    let e = assert_grammar_err_parity("const mut z = 1;", "const mut parity");
    assert_eq!(e.message, CONST_MUT_MSG);
}

/// Negative 8: the single-binding cap (the comma multi-binding
/// fail-closed — the toplevel_let twin; the 231-c probe c9).
#[test]
fn neg_single_binding_cap_comma() {
    let e = read_err("const a = 1, b = 2;", "const_multi.ktf");
    assert_eq!(e.message, SINGLE_MSG);
    // the span = the comma token: "const a = 1" = 11 bytes → 11..12
    assert_eq!((e.span.start, e.span.end), (11, 12));
    assert_grammar_err_parity("const a = 1, b = 2;", "const multi parity");
}

/// Negative 9: const inside a block fails closed with its dedicated
/// domain-out diagnostic (the mut block-position arm's isomorphic
/// twin; the 231-c probe c4).
#[test]
fn neg_block_position_domain_out() {
    let e = read_err("fn f() { const y = 1; }", "const_block.ktf");
    assert!(
        e.message.contains(BLOCK_DOMAIN_MSG),
        "the block-position domain-out face (actual: {})",
        e.message
    );
    assert_grammar_err_parity("fn f() { const y = 1; }", "block domain parity");
}

/// Negative 10: const in an if-arm block — the same domain-out face
/// (every block position, not just fn bodies).
#[test]
fn neg_block_position_if_arm() {
    let e = read_err("if true { const x = 1; }", "const_ifarm.ktf");
    assert!(
        e.message.contains(BLOCK_DOMAIN_MSG),
        "the if-arm block face (actual: {})",
        e.message
    );
}

/// Negative 11: the missing `=` (the binder's expectation face).
#[test]
fn neg_missing_assign_operator() {
    let e = read_err("const x 1;", "const_noassign.ktf");
    assert!(
        !e.message.is_empty(),
        "a structure diagnostic must surface (actual: {})",
        e.message
    );
}

/// Negative 12: the missing binding name (the binding-name
/// expectation face — `=` in name position).
#[test]
fn neg_missing_binding_name() {
    let e = read_err("const = 1;", "const_noname.ktf");
    assert!(
        e.message.contains("expected a binding name"),
        "the binding-name expectation (actual: {})",
        e.message
    );
}

/// Negative 13: the missing `;` (EOF immediately after the value).
#[test]
fn neg_missing_semicolon() {
    let e = read_err("const x = 1", "const_nosemi.ktf");
    assert!(
        !e.message.is_empty(),
        "a terminator diagnostic must surface (actual: {})",
        e.message
    );
}

/// Negative 14: the path-named binder rejected (the bare-identifier
/// domain of the binding name — `a::b` lexes as a Path token).
#[test]
fn neg_path_named_binder_rejected() {
    let e = read_err("const a::b = 1;", "const_path.ktf");
    assert!(
        e.message.contains("expected a binding name"),
        "the path binder rejection (actual: {})",
        e.message
    );
}

/// Negative 15: trailing garbage after the value (the structure
/// discipline — the toplevel_let twin face).
#[test]
fn neg_trailing_garbage_after_value() {
    let e = read_err("const x = 1 2;", "const_trail.ktf");
    assert!(
        !e.message.is_empty(),
        "a structure diagnostic must surface (actual: {})",
        e.message
    );
}

/// Negative 16 (E0004 duplicate class — pre-existing kernel flat-table
/// invariant, surfaced through the reader's latest-binding-wins
/// removal): the let-rebind attempt after a const (the 231-c probe
/// c3 — the removal lets the reader pass so the kernel's duplicate
/// diagnostic fires at the rebind itself, the deeper first error).
#[test]
fn neg_rebind_let_e0004() {
    let err = run_source("const x = 1;\nlet x = 2;\nx", "const_rebind.ktf").unwrap_err();
    assert!(
        err.diagnostic
            .message
            .contains("duplicate variable definition"),
        "the kernel's flat-table duplicate invariant (actual: {})",
        err.diagnostic.message
    );
}

/// Negative 17 (E0004): the fn-rebind attempt after a const (the
/// 231-c probe c10).
#[test]
fn neg_rebind_fn_e0004() {
    let err = run_source("const f = 1;\nfn f() { 2 }\nf()", "const_fnrebind.ktf").unwrap_err();
    assert!(
        err.diagnostic
            .message
            .contains("duplicate variable definition"),
        "the fn-rebind duplicate invariant (actual: {})",
        err.diagnostic.message
    );
}

/// Negative 18 (E0004): const redeclaration — the duplicate face on
/// the const itself.
#[test]
fn neg_const_redecl_e0004() {
    let err = run_source("const x = 1;\nconst x = 2;\nx", "const_redecl.ktf").unwrap_err();
    assert!(
        err.diagnostic
            .message
            .contains("duplicate variable definition"),
        "the const-redecl duplicate invariant (actual: {})",
        err.diagnostic.message
    );
}

/// Negative 19 (E0004): the module-body name collides with the
/// top-level binding (the kernel's flat define table — the 231-c
/// probe c6; the reader-level module scoping does not extend to the
/// kernel's name table — pre-existing, honestly documented).
#[test]
fn neg_module_name_collision_e0004() {
    let err = run_source(
        "let x = 5;\nmodule M { const x = 1; }\nx",
        "const_modulecoll.ktf",
    )
    .unwrap_err();
    assert!(
        err.diagnostic
            .message
            .contains("duplicate variable definition"),
        "the flat-table module collision (actual: {})",
        err.diagnostic.message
    );
}

/// Negative 20 (E0001 lexical class): a lexical error inside the
/// const's value expression (the reader's lexical face — orthogonal
/// to the binding skin).
#[test]
fn neg_lexical_error_class_e0001() {
    let e = read_err("const x = 1 $ 2;", "const_lex.ktf");
    assert!(
        !e.message.is_empty(),
        "the lexical diagnostic must surface (actual: {})",
        e.message
    );
}

/// Negative 21 (E0002 expand class): an expansion error after a
/// modern const binding (the expander's face — the const Stx is the
/// identical define, the expansion pipeline unperturbed).
#[test]
fn neg_expand_error_class_e0002() {
    let err = run_source(
        "const a = 1;\nfn f(x: i64) { define(y, 2); x }\nf(1)",
        "const_e2.ktf",
    )
    .unwrap_err();
    assert!(
        err.diagnostic
            .message
            .contains("define is only allowed at the top level"),
        "the expander's define-position rejection is unchanged (actual: {})",
        err.diagnostic.message
    );
}

/// Negative 22 (E0006 capability class): an undeclared capability
/// consumption through a const's value expression (the capability
/// gate is orthogonal to the binding skin — the gate pierces the
/// value slot).
#[test]
fn neg_capability_error_class_e0006() {
    let err = run_source("const x = print(1);\nx", "const_capgate.ktf").unwrap_err();
    assert_eq!(err.stage, Stage::Compile);
    assert_eq!(err.diagnostic.code, Some(kerf_span::DiagnosticCode(6)));
    assert!(err.rendered.contains("error[E0006]"));
}

/// Negative 23 (E0022 unbound class): the const's value references an
/// unbound name (the unbound-ref verification — orthogonal to the
/// binding skin).
#[test]
fn neg_unbound_error_class_e0022() {
    let err = run_source("const x = y;\nx", "const_unbound.ktf").unwrap_err();
    assert!(
        err.rendered.contains("E0022"),
        "the unbound-reference face (actual: {})",
        err.rendered
    );
}

/// Negative 24 (E0005 multi-error recovery class): the recovery-mode
/// check collects the expand-stage diagnostics through a modern const
/// binding (the E0005 recovery pipeline is unperturbed by the binding
/// skin — the multi_error_recovery_tests caliber).
#[test]
fn neg_multi_error_recovery_class_e0005() {
    let src = "const a = 1;\n|| { define(y, 2); y };\nhead()\na";
    let report = check_source_recover(src, "const_recover.ktf")
        .expect("recovery path should produce a report (not a hard error)");
    assert_eq!(report.diagnostics.len(), 2, "E0002 + E0005 each one");
}

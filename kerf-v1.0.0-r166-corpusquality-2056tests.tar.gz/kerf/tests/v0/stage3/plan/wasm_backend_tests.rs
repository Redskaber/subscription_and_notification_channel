// E6 close-out (r154 / 224-b8): converted to the target-syntax face.
//! r92 / 162-a — WASM backend M1 integration tests (TD-031 phase 1 made real).
//!
//! **Coverage** (§9.4.3 positive:negative ratio ≥ 1:3 — carried by
//! emitter-specific negative cases):
//! - **Positive cases (node host E2E parity)**: the host-side node (built-in
//!   `WebAssembly.validate` + instantiate-and-run) acts as the **component
//!   consumer** of the emitted core wasm module — `main()` call results are
//!   reconciled corpus by corpus against the kerf VM `run_source`
//!   (fib recursion / arithmetic / value-context if merge / tail if / let
//!   chain / not / comparison family / div-mod / deep recursion / mutual
//!   recursion / **i64 full-width truthiness boundary**
//!   [2^32 and i64::MAX literals — the semantic anchor of the
//!   `i64.eqz+i32.eqz` double negation]);
//! - **Structural positive cases**: manifest read-back reconciliation
//!   (`kerf_meta` custom section ↔ M0 contract layer `core_funcs`) /
//!   determinism / first trait implementation envelope (bytes + model dual
//!   payload);
//! - **Negative cases**: B1 shared boundary (Float/Str/closure value
//!   positions — explicitly rejected by `lower_program`) + read-back
//!   fail-closed (bad magic / truncated section / missing manifest section).
//!
//! **Toolchain dependency**: node (host-side WASM validation tool —
//! `KERF_NODE` env var → PATH probe; explicit failure when missing, per the
//! §3.1 no-silent-skip policy — same precedent form as qbe/cc: external host
//! tools are not cargo build dependencies, §18 L-B ruling).
//!
//! **E6 skin notes (E6-CG §2)**: fn declarations replace `(define (f x) ...)`;
//! infix operators replace primitive applications (`(+ a b)` → `a + b`,
//! `(= a b)` → `a == b`); `do`/`mod`/`not` keep the call form (`do(a, b)`,
//! `mod(a, b)`, `not(a)`); negative literals ride the binary-minus form
//! `0 - N` (the target face lexes `-N` as a unary-minus application, outside
//! the ANF primitive-arity face — the literal value is preserved through
//! lowering); the closure value-position probe is the target closure
//! `(|| (x: i64) { x })(1)`; the assign boundary is carried by a fn-body
//! `let x = 1; x = 2;` (top-level let statements are read-face
//! expression-position rejects).

use std::path::PathBuf;
use std::process::Command;
use std::sync::atomic::{AtomicU32, Ordering};

use kerf_backend::{
    emit_core_module, lower_program, parse_core_module_manifest, WasmBackend, WasmCoreBackend,
};
use kerf_driver::compile_source;

/// Compile source to ANF (front-end pipeline + lowering — same policy as qbe_backend_tests).
fn lower_src(src: &str) -> kerf_backend::AnnotatedANF {
    let out = compile_source(src, "<test>")
        .expect("frontend compile failed (test source should be well-formed)");
    lower_program(&out.core, &out.table)
        .expect("lowering should succeed (test source should be PoC in domain)")
}

/// Source → core wasm module binary.
fn wasm_of(src: &str) -> Vec<u8> {
    emit_core_module(&lower_src(src)).expect("WASM M1 emit should succeed")
}

/// VM-side evaluation → i64 (Bool normalized to 0/1 — aligning both sides on B1-domain comparison results).
fn vm_of(src: &str) -> i64 {
    let r = kerf_driver::run_source(src, "<test>").expect("VM path should succeed");
    match r.value {
        kerf_vm::Value::Int(i) => i,
        kerf_vm::Value::Bool(b) => i64::from(b),
        ref other => panic!("VM artifact should be Int/Bool, actually {:?}", other),
    }
}

/// Resolve node (§3.1 lookup chain: `KERF_NODE` → PATH probe; explicit failure when missing).
fn node_path() -> PathBuf {
    if let Ok(p) = std::env::var("KERF_NODE") {
        let pb = PathBuf::from(p);
        if pb.is_file() {
            return pb;
        }
        panic!("KERF_NODE points to node does not exist:{}", pb.display());
    }
    match Command::new("node").arg("--version").output() {
        Ok(o) if o.status.success() => PathBuf::from("node"),
        _ => panic!(
            "node not found (host-side WASM verification tool -- install node or set KERF_NODE; §3.1 no silent skipping; §18 L-B ruling: host tools are not build dependencies)"
        ),
    }
}

/// Unique artifact directories (guards against parallel tests deleting each other — same erratum form as qbe_backend_tests).
static DIR_SEQ: AtomicU32 = AtomicU32::new(0);

/// Host-side run: validate + instantiate + `main()` call → i64.
///
/// node script exits: validation failure = exit 86 (stderr INVALID WASM);
/// successful run = stdout holds the `main()` result (i64 → BigInt string).
fn run_wasm_main(bytes: &[u8], stem: &str) -> i64 {
    let node = node_path();
    let seq = DIR_SEQ.fetch_add(1, Ordering::SeqCst);
    let dir = std::env::temp_dir().join(format!("kerf-wasm-test-{}-{}", std::process::id(), seq));
    std::fs::create_dir_all(&dir).expect("temp directory creation");
    let wasm = dir.join(format!("{}.wasm", stem));
    std::fs::write(&wasm, bytes).expect("wasm write to disk");
    let script = r#"
const fs = require('fs');
const b = fs.readFileSync(process.argv[1]);
if (!WebAssembly.validate(b)) { console.error('INVALID WASM'); process.exit(86); }
const inst = new WebAssembly.Instance(new WebAssembly.Module(b));
const r = inst.exports.main();
process.stdout.write(String(r));
"#;
    let out = Command::new(&node)
        .arg("-e")
        .arg(script)
        .arg(&wasm)
        .output()
        .expect("node process should start");
    let _ = std::fs::remove_dir_all(&dir); // only removes our own unique directory
    assert!(
        out.status.success(),
        "node run failed (exit {:?}): stderr={}",
        out.status.code(),
        String::from_utf8_lossy(&out.stderr)
    );
    let s = String::from_utf8(out.stdout).expect("node stdout should be UTF-8");
    s.trim()
        .parse::<i64>()
        .unwrap_or_else(|_| panic!("node output is not an integer: {:?}", s))
}

/// VM ↔ WASM dual-side parity assertion (core criterion — corpus-by-corpus reconciliation).
fn parity(src: &str, stem: &str) {
    let vm = vm_of(src);
    let wasm = wasm_of(src);
    let host = run_wasm_main(&wasm, stem);
    assert_eq!(vm, host, "WASM/VM parity failed:{}", src);
}

// ---------------------------------------------------------------------------
// Positive cases: host E2E parity (component consumer = node host runtime)
// ---------------------------------------------------------------------------

#[test]
fn fib_end_to_end_node_matches_vm() {
    // fib(12) recursion: diamond merge + tail if + direct call + full recursive chain
    parity(
        "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(12)\n",
        "t_fib",
    );
}

#[test]
fn fib_deep_recursion_parity() {
    // fib(20) = 6765: deep recursion (>1000-frame call chain — carried by the host stack)
    parity(
        "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(20)\n",
        "t_fib20",
    );
}

#[test]
fn arithmetic_parity() {
    parity("(2 + 3) * (10 - 4)\n", "t_arith"); // 30
}

#[test]
fn value_if_merge_parity() {
    // Value-context if: diamond merge (the (result i64) if emission path)
    parity("if (1 < 2) { 10 } else { 20 }\n", "t_vif"); // 10
}

#[test]
fn nested_value_if_parity() {
    // Nested diamonds: outer merge block continues with arithmetic (region-sequence continuation path)
    parity(
        "(if (1 < 2) { if (3 > 2) { 100 } else { 200 } } else { 300 }) + (if (4 == 4) { 10 } else { 20 })\n",
        "t_nvif",
    ); // 110
}

#[test]
fn int_condition_wasm_side_full_width_truthiness() {
    // **i64 full-width truthiness boundary (emitter semantic anchor)**: at the
    // language surface an if condition is an explicit bool (VM E0004 rejects
    // int conditions); ANF lowering is wide-mouthed (int conditions pass); M1
    // emission = non-zero is truthy (i64.eqz + i32.eqz double negation — not
    // a wrap-down narrowing). This test anchors emission semantics in the
    // wide-mouth domain: 2^32 (low 32 bits zero) must be truthy.
    let bytes = wasm_of("if (4294967296) { 1 } else { 2 }\n");
    assert_eq!(run_wasm_main(&bytes, "t_truth32"), 1);
    let bytes = wasm_of("if (8589934592) { 5 } else { 6 }\n");
    assert_eq!(run_wasm_main(&bytes, "t_truth33"), 5);
    let bytes = wasm_of("if (0) { 1 } else { 2 }\n");
    assert_eq!(run_wasm_main(&bytes, "t_falsy"), 2);
    let bytes = wasm_of("if (0 - 1) { 7 } else { 8 }\n");
    assert_eq!(run_wasm_main(&bytes, "t_truthneg"), 7);
    let bytes = wasm_of("if (0 - 4294967296) { 3 } else { 4 }\n");
    assert_eq!(run_wasm_main(&bytes, "t_truthneg32"), 3);
}

#[test]
fn int_condition_vm_boundary_e0004_vs_anf_wide_mouth() {
    // **Three-side condition-width boundary (honestly registered)**: VM =
    // explicit bool (E0004 rejects int conditions); ANF lowering = wide mouth
    // (int conditions pass); WASM emission = non-zero is truthy. For legal
    // programs (VM-runnable) the ANF condition value is always ∈ {0,1} — the
    // three sides agree on the legal domain (the emitter is self-consistent
    // on the wide-mouth domain).
    let src = "if (4294967296) { 1 } else { 2 }\n";
    assert!(kerf_driver::run_source(src, "<t>").is_err()); // E0004
    let out = compile_source(src, "<t>").unwrap();
    assert!(lower_program(&out.core, &out.table).is_ok()); // wide mouth
}

#[test]
fn tail_if_parity() {
    // Tail if: both arms Ret (void-if emission path) — sign classifier
    parity(
        "fn cls(n: i64) -> i64 { if (n < 0) { 0 - n } else { n } }\ncls(0 - 7)\n",
        "t_tailif",
    ); // 7
}

#[test]
fn tail_if_nested_in_arms_parity() {
    // Tail if nested inside arms: then arm holds a value diamond + else arm holds a tail if (region recursion depth)
    parity(
        "fn g(n: i64) -> i64 { if (n < 0) { (if (n == 0 - 1) { 100 } else { 200 }) + 1 } else { if (n > 10) { 300 } else { 400 } } }\ng(0 - 1)\n",
        "t_tinest",
    ); // 101
    parity(
        "fn g(n: i64) -> i64 { if (n < 0) { (if (n == 0 - 1) { 100 } else { 200 }) + 1 } else { if (n > 10) { 300 } else { 400 } } }\ng(5)\n",
        "t_tinest2",
    ); // 400
}

#[test]
fn let_chain_parity() {
    // do → Let chain: intermediate values discarded + tail value returned
    // (sequence continuation with value diamonds mixed into the chain)
    let src = "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\ndo(fib(5), 1 + 2)\n";
    parity(src, "t_do"); // 3
}

#[test]
fn not_parity() {
    // VM `not` follows the same explicit-bool discipline (E0004) — the
    // condition produces a bool via the comparison family, then is negated
    parity("if (not(1 < 2)) { 3 } else { 4 }\n", "t_not0"); // 4
    parity("if (not(5 == 5)) { 5 } else { 6 }\n", "t_not5"); // 6
    parity("if (not(1 > 2)) { 7 } else { 8 }\n", "t_not2"); // 7
}

#[test]
fn comparison_ops_parity() {
    // Full sweep of the six-member comparison family (VM Bool ↔ wasm 0/1 normalized reconciliation)
    parity("1 < 2\n", "t_lt"); // 1
    parity("2 < 1\n", "t_lt2"); // 0
    parity("1 > 2\n", "t_gt"); // 0
    parity("2 <= 2\n", "t_le"); // 1
    parity("1 >= 2\n", "t_ge"); // 0
    parity("3 == 3\n", "t_eq"); // 1
    parity("3 == 4\n", "t_eq2"); // 0
}

#[test]
fn div_mod_parity() {
    parity("7 / 2\n", "t_div"); // 3 (truncating division — div_s aligned)
    parity("mod(7, 2)\n", "t_mod"); // 1
    parity("(0 - 7) / 2\n", "t_divneg"); // -3 (truncation toward zero)
    parity("mod(0 - 7, 2)\n", "t_modneg"); // -1 (dividend sign — rem_s aligned)
}

#[test]
fn mutual_recursion_parity() {
    // Mutual recursion: forward references + two-function call graph (Call index resolution surface)
    let src = "fn even(n: i64) -> i64 { if (n == 0) { 1 } else { if (n == 1) { 0 } else { odd(n - 1) } } }\n\
               fn odd(n: i64) -> i64 { if (n == 0) { 0 } else { if (n == 1) { 1 } else { even(n - 1) } } }\n\
               even(10)\n";
    parity(src, "t_mutual"); // 1
}

#[test]
fn empty_program_main_zero() {
    // Empty program: main returns 0 (C convention — the lower_main contract)
    let bytes = wasm_of("");
    assert_eq!(run_wasm_main(&bytes, "t_empty"), 0);
}

#[test]
fn i64_max_const_parity() {
    // i64::MAX literal end to end (10-byte sleb canonical-form path)
    parity("9223372036854775806 + 1\n", "t_imax"); // 9223372036854775807
}

#[test]
fn multi_arg_function_parity() {
    // Multiple parameters (locals 0..arity parameter slots + body temporaries appended after)
    parity(
        "fn mix(a: i64, b: i64, c: i64) -> i64 { a * b + (c - 1) }\nmix(3, 4, 10)\n",
        "t_mix",
    ); // 21
}

#[test]
fn constant_main_program_parity() {
    parity("42\n", "t_const"); // 42
}

// ---------------------------------------------------------------------------
// Positive cases: structural assertions (read-back / determinism / trait envelope)
// ---------------------------------------------------------------------------

#[test]
fn manifest_round_trip_matches_model() {
    // kerf_meta custom-section read-back ↔ M0 contract-layer manifest (emission↔contract bidirectional parity)
    let src =
        "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(12)\n";
    let ir = lower_src(src);
    let bytes = emit_core_module(&ir).unwrap();
    let parsed = parse_core_module_manifest(&bytes).unwrap();
    let model = kerf_backend::component_model_from_anf(&ir);
    assert_eq!(parsed, model.core_funcs);
    assert_eq!(parsed.len(), 2); // main + fib
    assert_eq!(parsed[0].name, "main");
    assert_eq!(parsed[0].params, 0);
    assert_eq!(parsed[1].name, "fib");
    assert_eq!(parsed[1].params, 1);
    assert!(
        parsed[1].blocks >= 3,
        "fib block graph(Br+two arms+merge): {}",
        parsed[1].blocks
    );
}

#[test]
fn manifest_round_trip_multi_function() {
    let src = "fn f(x: i64) -> i64 { x + 1 }\nfn g(x: i64, y: i64) -> i64 { x * y }\nfn h() -> i64 { 7 }\nh()\n";
    let ir = lower_src(src);
    let bytes = emit_core_module(&ir).unwrap();
    let parsed = parse_core_module_manifest(&bytes).unwrap();
    assert_eq!(parsed.len(), 4); // main + f + g + h
    let params: Vec<usize> = parsed.iter().map(|f| f.params).collect();
    assert_eq!(params, vec![0, 1, 2, 0]);
    let names: Vec<&str> = parsed.iter().map(|f| f.name.as_str()).collect();
    assert_eq!(names, vec!["main", "f", "g", "h"]);
}

#[test]
fn emission_determinism_across_compilations() {
    // Two independent compile-emit chains → byte-identical (no hash iteration order leaks into the artifact)
    let src = "fn f(x: i64) -> i64 { if (x < 0) { 0 - x } else { x * 2 } }\nf(0 - 3)\n";
    assert_eq!(wasm_of(src), wasm_of(src));
}

#[test]
fn wasm_core_backend_trait_envelope() {
    // First trait implementation: bytes = emission payload + model = M0 derivation (fingerprint-chain reconciliation)
    let src = "fn f(x: i64) -> i64 { x + 1 }\nf(41)\n";
    let ir = lower_src(src);
    let c = WasmCoreBackend.compile_component(&ir).unwrap();
    assert_eq!(c.bytes, emit_core_module(&ir).unwrap());
    assert_eq!(c.model.source_fingerprint, ir.fingerprint);
    assert_eq!(c.model.core_funcs.len(), ir.funcs.len());
    // Envelope artifact consumed directly by the host (component-consumer chain: compile_component → node)
    assert_eq!(run_wasm_main(&c.bytes, "t_trait"), 42);
}

// ---------------------------------------------------------------------------
// Negative cases: B1 shared boundary (lowering rejection face — emitter
// outpost) + read-back fail-closed
// ---------------------------------------------------------------------------

#[test]
fn float_literal_rejected_before_emit() {
    // B1 boundary: Float is not in the PoC (same source as TD-024 criterion 3 — zero-signal maintained)
    let out = compile_source("fn f(x: i64) -> i64 { x }\n1.5\n", "<test>").unwrap();
    let err = lower_program(&out.core, &out.table).unwrap_err();
    assert!(
        err.message.contains("integer-domain literals"),
        "error face: {}",
        err.message
    );
}

#[test]
fn string_literal_rejected_before_emit() {
    let out = compile_source("\"s\"\n", "<test>").unwrap();
    assert!(lower_program(&out.core, &out.table).is_err());
}

#[test]
fn closure_value_position_rejected_before_emit() {
    // E5 modern closure form (lambda retired — 22 §12 S2; E6: the target
    // closure skin `|| (x: i64) { x }` in callee value position)
    let out = compile_source("(|| (x: i64) { x })(1)\n", "<test>").unwrap();
    let err = lower_program(&out.core, &out.table).unwrap_err();
    assert!(
        err.message.contains("function name")
            || err.message.contains("closure")
            || err.message.contains("lambda"),
        "error face: {}",
        err.message
    );
}

#[test]
fn assign_rejected_before_emit() {
    // B1 boundary: assign (mutable assignment) is not in the PoC (a legal
    // kerf form within the binding domain — E6 skin: let statement + assign
    // statement, fn-body wrapped: top-level let statements are read-face
    // expression-position rejects)
    let out = compile_source("fn f() -> i64 { let x = 1; x = 2; }\nf()\n", "<test>").unwrap();
    let err = lower_program(&out.core, &out.table).unwrap_err();
    assert!(
        err.message.contains("assign"),
        "error face: {}",
        err.message
    );
}

#[test]
fn parse_rejects_bad_magic() {
    assert!(parse_core_module_manifest(&[0x00, 0x61, 0x73]).is_err());
    assert!(parse_core_module_manifest(b"notwasm-payload").is_err());
    // Valid header but truncated section
    let mut bad = vec![0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00];
    bad.extend_from_slice(&[0x01, 0xff, 0x00]); // type section declares an overlong payload
    assert!(parse_core_module_manifest(&bad).is_err());
}

#[test]
fn parse_rejects_missing_manifest_section() {
    // Valid header + no kerf_meta section (guards the emission/read-back single-source break)
    let bytes = vec![0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00];
    let err = parse_core_module_manifest(&bytes).unwrap_err();
    assert!(
        err.reason.contains("kerf_meta"),
        "error face: {}",
        err.reason
    );
}

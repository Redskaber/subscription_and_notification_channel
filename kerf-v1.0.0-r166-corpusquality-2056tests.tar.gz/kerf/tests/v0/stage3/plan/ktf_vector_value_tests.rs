// E6 close-out (r154 / 224-c3): corpus converted to the target-syntax face.
//! .ktf vector value-type tests — r138 / 208-c (the TD-002 window: the
//! fourteenth skin-mapping family — the vector value type + collection
//! literals; design single source = vector-value-design.md v1.0).
//!
//! **Verification surfaces** (both faces' collection literals — S-expr
//! `[a b c]` (the pre-existing bracket datum) ↔ target `[a, b, c]` (the
//! new comma-elision fourteenth mapping); the D2 full desugar lowers
//! both to `(vector ...)` applications — zero CoreExpr/IR/opcode
//! changes, principle 9 freeze maintained):
//! (1) **run-face E2E** — construction/length/ref/append/quote/nested
//! through the full production chain on **both faces** (skin/skeleton
//! isomorphism; the print form `[1 2 3]` = the round-trip-readable
//! bracket form, D8);
//! (2) **grammar settlement** — dual-Reader canonical Stx rendering
//! byte-identical (seed target.rs primary-LBracket arm ↔ mirror
//! reader.krf vec-items arm — including spans; the mirror Reader
//! was renamed reader.ktf at the E6 close-out [224-a]), error faces
//! message + Span byte-identical (missing comma / trailing comma /
//! unclosed bracket);
//! (3) **cross-syntax bytecode parity** — the same program in both
//! syntaxes compiles to identical instruction order + constant pool
//! (the D2 desugar is skin-transparent by construction);
//! (4) **fail-closed negatives** — the runtime domain family
//! (non-vector operands / non-int index / negative & OOB indexing —
//! the single-sourced err_vector_op law) + the runtime arity family
//! (one_arg/two_args — the production check.ktf path holds vectors at
//! A4 Dynamic per the registered TC-SIGS asymmetry, so static E0005
//! arity coverage is deferred to the oracle-only fallback face) + the
//! maintained rejections (match-pattern vectors — match-design §1;
//! postfix indexing — D6 position discipline) + the mutability
//! domain-out (vector-set! unbound — D1 immutability's enforcement
//! face).
//!
//! Skin-dictionary basis: 20 §14 (the fourteenth mapping — the vector
//! literal comma elision); 02 §8.13.1b v7.22 (the Level 0 production
//! update). Window basis: TD-002 register row (the vector part — full
//! settlement) + target-language-gated-tasks #5 + vector-value-design.md
//! v1.0 (design single source) + t3plus-trigger-audit v1.57 (M1
//! user-instruction order, the gated-task #5 path).
//! Ratio: 8 positive : 24 negative = 1:3 (§9.4.3).
//!
//! E6 close-out (r154 / 224-c3): the S-expr collection-literal legs
//! retired with the S-expr Reader — the former S-expr-face legs now
//! drive the same target chain through alternate program shapes
//! (top-level `define(x, v);` value definitions, the explicit
//! `vector(...)` constructor, runtime pair-list construction — the
//! r127 quoted-pair-list honest boundary); the cross-syntax
//! bytecode-parity gate compares the bracket literal against the
//! explicit constructor call (the D2 desugar's two target-side skins);
//! the read-stage rejections (match-pattern vector / bracket mismatch)
//! are recalibrated to the single target Reader's messages (calibrated
//! by running).

use kerf_driver::{check_source_recover, run_source, Stage};
use kerf_reader::read_source;
use kerf_syntax::{Stx, StxDatum, StxLiteral, SymbolTable};

// ---------------------------------------------------------------------------
// Value helpers (the ktf_extern_decl_tests caliber; alt_value/alt_err are
// the r154 / 224-c3 E6 close-out rework of the retired krf_value/krf_err
// helpers — the alternate program shapes: define-value forms, the
// explicit vector(...) constructor, runtime pair-list construction)
// ---------------------------------------------------------------------------

fn run_value(src: &str, filename: &str) -> String {
    let outcome = run_source(src, filename).unwrap_or_else(|e| {
        panic!(
            "target face program {} execution failed:{}",
            filename, e.rendered
        )
    });
    kerf_vm::render_value(&outcome.value, &outcome.heap)
}

fn alt_value(src: &str, filename: &str) -> String {
    let outcome = run_source(src, filename).unwrap_or_else(|e| {
        panic!(
            "alternate-shape program {} execution failed:{}",
            filename, e.rendered
        )
    });
    kerf_vm::render_value(&outcome.value, &outcome.heap)
}

fn alt_err(src: &str, msg: &str) -> kerf_driver::DriverError {
    let err = match run_source(src, "neg.ktf") {
        Ok(_) => panic!("expected a run-time error, got Ok: {}", src),
        Err(e) => e,
    };
    assert!(
        err.rendered.contains(msg),
        "message missing `{}`: {}\n complete error: {}",
        msg,
        src,
        err.rendered
    );
    err
}

fn target_err(src: &str, msg: &str) {
    let err = match run_source(src, "neg.ktf") {
        Ok(_) => panic!("expected a run-time error, got Ok: {}", src),
        Err(e) => e,
    };
    assert!(
        err.rendered.contains(msg),
        "target face message missing `{}`: {}\n complete error: {}",
        msg,
        src,
        err.rendered
    );
}

// ---------------------------------------------------------------------------
// Dual-Reader canonical parity helpers (seed target.rs ↔ mirror
// reader.ktf [renamed reader.ktf at the E6 close-out, 224-a] —
// byte-level with Spans)
// ---------------------------------------------------------------------------

fn render_stx(s: &Stx, t: &SymbolTable) -> String {
    let mut out = String::new();
    render_stx_into(s, t, &mut out);
    out
}

fn render_stx_into(s: &Stx, t: &SymbolTable, out: &mut String) {
    match &s.datum {
        StxDatum::Symbol(sym) => {
            out.push_str(&format!(
                "(sym {} {}..{})",
                t.name(*sym),
                s.span.start,
                s.span.end
            ));
        }
        StxDatum::Literal(l) => match l {
            StxLiteral::Int(v) => {
                out.push_str(&format!("(int {} {}..{})", v, s.span.start, s.span.end));
            }
            StxLiteral::Str(r) => {
                out.push_str(&format!("(str {:?} {}..{})", r, s.span.start, s.span.end));
            }
            _ => out.push_str(&format!("(lit {}..{})", s.span.start, s.span.end)),
        },
        StxDatum::List(items) => {
            out.push_str(&format!("(lst {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
        // r138 / 208-c: the vector datum's canonical rendering (both
        // Readers now produce it — the fourteenth mapping)
        StxDatum::Vector(items) => {
            out.push_str(&format!("(vec {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
    }
}

/// Grammar parity: both target Readers' canonical renderings byte-identical.
fn assert_grammar_parity(src: &str, what: &str) {
    let mut t1 = SymbolTable::new();
    let seed = read_source(src, 0, &mut t1)
        .unwrap_or_else(|e| panic!("[{}] seed syntax failed: {}", what, e.message));
    let mut t2 = SymbolTable::new();
    let mirror = kerf_driver::bootstrap::reader::read_source_for_bootstrap(src, 0, &mut t2)
        .unwrap_or_else(|e| panic!("[{}] mirror syntax failed:{}", what, e.message));
    assert_eq!(
        seed.len(),
        mirror.len(),
        "[{}] top-level item count mismatch (seed {} vs mirror {})",
        what,
        seed.len(),
        mirror.len()
    );
    for (i, (a, b)) in seed.iter().zip(mirror.iter()).enumerate() {
        assert_eq!(
            render_stx(a, &t1),
            render_stx(b, &t2),
            "[{}] top-level item #{} syntax tree mismatch (seed vs mirror canonical render)",
            what,
            i
        );
    }
}

/// Grammar-error parity: message + Span byte-level equality.
fn assert_grammar_err_parity(src: &str, what: &str) -> String {
    let mut t1 = SymbolTable::new();
    let seed_err = match read_source(src, 0, &mut t1) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] seed should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    let mut t2 = SymbolTable::new();
    let mirror_err =
        match kerf_driver::bootstrap::reader::read_source_for_bootstrap(src, 0, &mut t2) {
            Err(e) => e,
            Ok(_) => panic!(
                "[{}] mirror should be a syntax error (actually parsed successfully)",
                what
            ),
        };
    assert_eq!(
        seed_err.message, mirror_err.message,
        "[{}] syntax error message mismatch (seed {:?} vs mirror {:?})",
        what, seed_err.message, mirror_err.message
    );
    assert_eq!(
        (seed_err.span.start, seed_err.span.end),
        (mirror_err.span.start, mirror_err.span.end),
        "[{}] syntax error Span mismatch",
        what
    );
    seed_err.message.clone()
}

// ---------------------------------------------------------------------------
// Positives — 8 (§9.4.3 1:3 ratio numerator)
// ---------------------------------------------------------------------------

/// Positive 1 / integration: the core E2E — construction + length + ref
/// (the D2-a desugar → `(vector ...)` applications → the five-op builtin
/// family; identical values across the shape boundary — the alternate
/// define-value shape vs the target fn/import shape).
#[test]
fn vector_e2e_dual_face() {
    // Alternate shape (E6 close-out r154 / 224-c3: the former S-expr-face
    // legs): the define-value form — the bracket literal in definition
    // position, consumed through the binding.
    let a = alt_value(
        "import kerf_vector;\nlet v = [1, 2, 3];\nvector_length(v)",
        "v1.ktf",
    );
    assert_eq!(a, "3", "alternate shape vector_length(define-value form)");
    let b = alt_value(
        "import kerf_vector;\nlet v = [10, 20, 30];\nvector_ref(v, 1)",
        "v1.ktf",
    );
    assert_eq!(b, "20", "alternate shape vector_ref(define-value form)");
    // Target face: comma-elision literals + module-qualified imports
    let c = run_value("import kerf_vector;\nvector_length([1, 2, 3])", "v1.ktf");
    assert_eq!(c, "3", "target face vector_length(import face)");
    let d = run_value("import kerf_vector;\nvector_ref([10, 20, 30], 1)", "v1.ktf");
    assert_eq!(d, "20", "target face vector_ref");
}

/// Positive 2 / integration: quote vectors — mixed element kinds
/// (symbol/str/int) with the D2-b recursive literal desugar, ref-back on
/// the alternate define-value shape and the target shape (the quote
/// product = runtime construction, the quoted-pair emit_literal_pair
/// law).
#[test]
fn vector_quote_e2e_dual_face() {
    let a = alt_value(
        "import kerf_vector;\nlet q = quote([a, \"s\", 3]);\nvector_ref(q, 0)",
        "v2.ktf",
    );
    assert_eq!(a, "a", "alternate shape quote vector element 0(symbol)");
    let b = alt_value(
        "import kerf_vector;\nlet q = quote([a, \"s\", 3]);\nvector_ref(q, 1)",
        "v2.ktf",
    );
    assert_eq!(b, "s", "alternate shape quote vector element 1(string)");
    let c = run_value(
        "import kerf_vector;\nvector_ref(quote([a, \"s\", 3]), 2)",
        "v2.ktf",
    );
    assert_eq!(c, "3", "target face quote vector element 2(integer)");
}

/// Positive 3: nested vectors — inner ref + outer length (the recursive
/// construction path; the alternate define-value shape + the target
/// shape).
#[test]
fn vector_nested_e2e() {
    let a = alt_value("import kerf_vector;\nvector_length([1, [2, 3]])", "v3.ktf");
    assert_eq!(a, "2", "outer length(nested vector = single-element)");
    let b = alt_value(
        "import kerf_vector;\nlet v = [1, [2, 3]];\nvector_ref(vector_ref(v, 1), 0)",
        "v3.ktf",
    );
    assert_eq!(b, "2", "alternate shape inner element via two level ref");
    let c = run_value(
        "import kerf_vector;\nvector_ref(vector_ref([1, [2, 3]], 1), 0)",
        "v3.ktf",
    );
    assert_eq!(c, "2", "target face nested two level ref");
}

/// Positive 4: append E2E — concatenation + length conservation + the D1
/// immutability law (the operands never mutate; a fresh vector each call).
#[test]
fn vector_append_e2e() {
    let a = alt_value(
        "import kerf_vector;\nlet x = [1, 2];\nlet y = [3, 4];\nvector_append(x, y)",
        "v4.ktf",
    );
    assert_eq!(a, "[1 2 3 4]", "concatenated print form(D8 bracket form)");
    let b = alt_value(
        "import kerf_vector;\nlet a = [1, 2];\nlet b = vector_append(a, [3]);\nvector_length(a)",
        "v4.ktf",
    );
    assert_eq!(
        b, "2",
        "D1 immutable: append after original vector length unchanged"
    );
    let c = run_value(
        "import kerf_vector;\nvector_append([1, 2], [3, 4])",
        "v4.ktf",
    );
    assert_eq!(c, "[1 2 3 4]", "target face concatenate");
}

/// Positive 5: the print form — the D8 round-trip-readable bracket form
/// (the same shape as the literal syntax; consistent with the Stx datum
/// render).
#[test]
fn vector_print_form() {
    let a = alt_value("quote([1, 2, 3])", "v5.ktf");
    assert_eq!(
        a, "[1 2 3]",
        "print form = literal form(can read back rule)"
    );
    let b = alt_value("quote([])", "v5.ktf");
    assert_eq!(b, "[]", "empty vector print form");
    let c = alt_value("quote([1, [2, 3], \"s\"])", "v5.ktf");
    assert_eq!(c, "[1 [2 3] s]", "nested + string-mixed print form");
    // E6 honest boundary (r127): the quoted pair-list datum has no target
    // literal — the pair-list element is constructed at runtime (the same
    // value product the former S-expr quote datum produced).
    let d = alt_value("vector(1, list(2, 3), 4)", "v5.ktf");
    assert_eq!(
        d, "[1 (2 3) 4]",
        "vector containing pair list element print form"
    );
}

/// Positive 6 / integration: cross-skin bytecode parity — the two
/// target-side skins of the D2 desugar (the bracket literal `[1, 2]` —
/// Reader Vector datum → expander desugar — and the explicit constructor
/// call `vector(1, 2)` — the call form) compile to identical instruction
/// order + constant pool + global-reference face (the desugar is
/// skin-transparent by construction; the match-M-2 acceptance-gate
/// discipline; E6 close-out rework r154 / 224-c3: the S-expr face
/// retired — the comparison domain is now the literal-vs-constructor
/// skin pair).
#[test]
fn vector_cross_syntax_bytecode_parity() {
    use kerf_compiler::{compile_module, BcConst, BcProgram};
    use kerf_expander::{expand_program as expand_program_seed, ExpandCtxt};

    // The compile path carries the table through (the desugar interns the
    // `vector` symbol into it — needed for the name-normalized pool
    // comparison below).
    let compile = |forms: &[Stx], table: SymbolTable, what: &str| -> (BcProgram, SymbolTable) {
        let mut ectx = ExpandCtxt::new(table);
        let core = expand_program_seed(forms, &mut ectx)
            .unwrap_or_else(|e| panic!("[{}] expand failed:{}", what, e.message));
        let program = compile_module(&core)
            .unwrap_or_else(|e| panic!("[{}] compile failed:{}", what, e.message));
        (program, ectx.table)
    };
    // Literal skin → target Reader → expansion → bytecode
    let mut tt = SymbolTable::new();
    let tf = read_source("vector_append([1, 2], [3, 4])", 0, &mut tt)
        .unwrap_or_else(|e| panic!("literal skin read failed: {}", e.message));
    let (b, tb) = compile(&tf, tt, "literal");

    // Constructor skin → target Reader → expansion → bytecode (separate
    // table — the skins must agree on the semantic payload, not the
    // table identity)
    let mut ts = SymbolTable::new();
    let sf = read_source("vector_append(vector(1, 2), vector(3, 4))", 0, &mut ts)
        .unwrap_or_else(|e| panic!("constructor skin read failed:{}", e.message));
    let (a, ta) = compile(&sf, ts, "constructor");

    assert_eq!(a.protos.len(), b.protos.len(), "prototype count mismatch");
    for (i, (pa, pb)) in a.protos.iter().zip(b.protos.iter()).enumerate() {
        assert_eq!(
            pa.code, pb.code,
            "prototype {} instruction sequence mismatch",
            i
        );
        assert_eq!(pa.n_locals, pb.n_locals, "prototype {} local slot count", i);
    }
    // E6 close-out calibration (r154 / 224-c3): the constant pool and the
    // global-reference face carry interning-table-local Symbol ids — the
    // literal skin interns `vector` at desugar time while the constructor
    // skin interns it at read time (separate tables, different ids) — so
    // the pools are compared by NAME (the semantic payload; the id-free
    // companion of the r106 span-exclusion discipline).
    let const_name = |c: &BcConst, t: &SymbolTable| -> String {
        match c {
            BcConst::Symbol(s) => format!("sym:{}", t.name(*s)),
            other => format!("{:?}", other),
        }
    };
    let ca = a
        .consts
        .iter()
        .map(|c| const_name(c, &ta))
        .collect::<Vec<_>>();
    let cb = b
        .consts
        .iter()
        .map(|c| const_name(c, &tb))
        .collect::<Vec<_>>();
    assert_eq!(ca, cb, "constant pool mismatch(name-normalized)");
    let ga = a
        .global_refs
        .iter()
        .map(|s| ta.name(*s).to_string())
        .collect::<Vec<_>>();
    let gb = b
        .global_refs
        .iter()
        .map(|s| tb.name(*s).to_string())
        .collect::<Vec<_>>();
    assert_eq!(
        ga, gb,
        "global reference face mismatch(name-normalized; desugar face isomorphic)"
    );
}

/// Positive 7 / integration: mixed program + deep positions — the vector
/// literal in fn body / let binding / argument position + define + import
/// coexistence (resolution unaffected by lexical depth; zero
/// cross-interference; the alternate define-value shape + the target
/// shape).
#[test]
fn vector_deep_positions_mixed_program() {
    let src = "import kerf_vector;\n\
               let v = [1, 2, 3];\n\
               fn f(x: T) -> T { vector_ref(x, 0) }\n\
               fn g() -> i64 { let w = [4, 5]; vector_length(w) }\n\
               f(v) + g() + vector_length([6])";
    let a = alt_value(src, "v7.ktf");
    assert_eq!(
        a, "4",
        "deep layer position + define mixed program(1 + 2 + 1)"
    );
    let tsrc = "import kerf_vector;\n\
                let v = [1, 2, 3];\n\
                fn f(x: i64) { vector_ref(x, 0) }\n\
                fn g() { let w = [4, 5]; vector_length(w) }\n\
                f(v) + g() + vector_length([6])";
    let b = run_value(tsrc, "v7.ktf");
    assert_eq!(
        b, "4",
        "target face deep layer position mixed program(1 + 2 + 1)"
    );
}

/// Positive 8 / integration: GC survival — the vector rides a closure
/// capture through allocation churn (collection cycles fire at the
// threshold; the roots + the children() arm keep the vector and its
/// element slots live — a missing children arm would recycle the element
/// slots and corrupt the ref-back).
#[test]
fn vector_gc_survival() {
    let src = "import kerf_vector;\n\
               fn churn(n: i64) -> i64 { if n == 0 { 0 } else { do(cons(n, ()), churn(n - 1)) } }\n\
               fn mkvec() -> T { [7, 8, 9] }\n\
               let f = || { vector_ref(mkvec(), 2) };\n\
               churn(5000);\n\
               f()";
    let a = alt_value(src, "v8.ktf");
    assert_eq!(
        a, "9",
        "GC cycle after vector element alive(children arm E2E)"
    );
    // The global-bound variant: v is a GC root across the churn
    // (E6 close-out r154 / 224-c3: the do+define shape converts to the
    // top-level define-value + fn-declaration form).
    let src2 = "import kerf_vector;\n\
                let v = [1, 2, 3];\n\
                fn churn(n: i64) -> i64 { if n == 0 { 0 } else { do(cons(n, ()), churn(n - 1)) } }\n\
                churn(5000);\n\
                vector_ref(v, 1)";
    let b = alt_value(src2, "v8.ktf");
    assert_eq!(
        b, "2",
        "globally bound vector GC alive(root set + children)"
    );
}

// ---------------------------------------------------------------------------
// Negatives — 24 (§9.4.3 1:3 ratio denominator)
// ---------------------------------------------------------------------------

// --- Runtime domain family (8) — the single-sourced err_vector_op law ---

/// Negative 1: vector-length on a non-vector operand.
#[test]
fn neg_vector_length_domain() {
    alt_err(
        "import kerf_vector;\nlet x = vector_length(1);\nx",
        "vector-length requires vector, got int",
    );
    target_err(
        "import kerf_vector;\nvector_length(1)",
        "vector-length requires vector, got int",
    );
}

/// Negative 2: vector-ref with a non-vector first operand.
#[test]
fn neg_vector_ref_domain() {
    alt_err(
        "import kerf_vector;\nvector_ref(\"s\", 0)",
        "vector-ref requires vector, got str",
    );
}

/// Negative 3: vector-ref with a non-int index.
#[test]
fn neg_vector_ref_index_kind() {
    alt_err(
        "import kerf_vector;\nvector_ref([1, 2], \"x\")",
        "vector-ref index requires int, got str",
    );
}

/// Negative 4: negative index (out of bounds family).
#[test]
fn neg_vector_ref_negative_index() {
    alt_err(
        "import kerf_vector;\nvector_ref([1, 2], -1)",
        "vector-ref index out of bounds:-1(length 2)",
    );
}

/// Negative 5: index >= length (out of bounds).
#[test]
fn neg_vector_ref_oob() {
    alt_err(
        "import kerf_vector;\nvector_ref([1, 2], 2)",
        "vector-ref index out of bounds:2(length 2)",
    );
    alt_err(
        "import kerf_vector;\nvector_ref([], 0)",
        "vector-ref index out of bounds:0(length 0)",
    );
}

/// Negative 6: vector-append with a non-vector member.
#[test]
fn neg_vector_append_domain() {
    alt_err(
        "import kerf_vector;\nvector_append([1], 2)",
        "vector-append requires vector, got int",
    );
}

/// Negative 7: is-vector false on a pair (the predicate's negative face).
#[test]
fn neg_is_vector_pair_false() {
    let v = alt_value("is_vector(cons(1, 2))", "n7.ktf");
    assert_eq!(v, "false", "is-vector for pair = false");
}

/// Negative 8: is-vector false on an int.
#[test]
fn neg_is_vector_int_false() {
    let v = alt_value("is_vector(0)", "n8.ktf");
    assert_eq!(v, "false", "is-vector for int = false");
}

// --- Runtime arity family (4) — one_arg/two_args fail-closed ---

/// Negative 9: vector-length with zero args.
#[test]
fn neg_vector_length_arity_zero() {
    alt_err(
        "import kerf_vector;\nvector_length()",
        "vector-length requires 1 arguments",
    );
}

/// Negative 10: vector-ref with one arg.
#[test]
fn neg_vector_ref_arity_one() {
    alt_err(
        "import kerf_vector;\nvector_ref([1])",
        "vector-ref requires 2 arguments",
    );
}

/// Negative 11: vector-ref with three args.
#[test]
fn neg_vector_ref_arity_three() {
    alt_err(
        "import kerf_vector;\nvector_ref([1], 0, 0)",
        "vector-ref requires 2 arguments",
    );
}

/// Negative 12: vector-length with two args.
#[test]
fn neg_vector_length_arity_two() {
    alt_err(
        "import kerf_vector;\nvector_length([1], [2])",
        "vector-length requires 1 arguments",
    );
}

// --- Maintained rejections (4) — the r138 deliberately-preserved faces ---

/// Negative 13: vector in a match PATTERN stays domain-out
/// (match-design §1 — the one rejection the window preserves).
/// E6 close-out rework (r154 / 224-c3): the expansion-time carrier
/// ("vector not can appear in pattern position") retired with the
/// S-expr face — the target Reader's pattern grammar has no bracket
/// production, so the rejection fires at the read stage (the r138
/// deliberately-preserved boundary keeps its fail-closed semantics;
/// match-m2 precedent: the boundary switches stage, semantics
/// unchanged).
#[test]
fn neg_match_pattern_vector_seed() {
    let err = match run_source("match [1] { [v] => v, _ => 0 }", "n13.ktf") {
        Ok(_) => panic!("pattern position vector should by rejected"),
        Err(e) => e,
    };
    assert_eq!(
        err.stage,
        Stage::Read,
        "pattern position rejected in read segment"
    );
    assert!(
        err.rendered.contains("expected a pattern"),
        "pattern position rejected message(actual: {})",
        err.rendered
    );
}

/// Negative 14: the same rejection through the target face (dual-side
/// message parity).
#[test]
fn neg_match_pattern_vector_target() {
    // The target-face match grammar has no bracket-pattern production —
    // the read-time rejection fires first (expected a pattern); the
    // expansion-time pattern rejection (vector cannot appear in pattern
    // position) retired with the S-expr face (E6 close-out r154)
    let err = match run_source("match [1, 2] { [v] => v, _ => 0 }", "n14.ktf") {
        Ok(_) => panic!("target face pattern position vector should by rejected"),
        Err(e) => e,
    };
    assert!(
        err.rendered.contains("expected a pattern"),
        "target face pattern position read layer rejected message(actual: {})",
        err.rendered
    );
}

// Negative 15 — RETIRED at r163 / 234-c (index-access-design.md D1): the
// postfix index face OPENED (the seventeenth skin mapping — `coll[idx]` →
// as-if-written `(vector-ref coll idx)`; the r138 D6 position discipline
// superseded — both bracket faces in domain). The r138 domain-out anchor
// (`x[0]` → "index(collection type out of domain)") retired with the
// legalization; the replacement anchors live in ktf_index_access_tests.rs
// (postfix Stx parity ×2 + fail-closed family ×4 + as-is-written isomorphism).

/// Negative 16: the mutability domain-out — vector-set! is an unbound
/// reference (D1 immutability's enforcement face: no setter exists; the
/// E0022 unbound check rejects with the kerf-vector import hint).
#[test]
fn neg_vector_set_unbound() {
    let err = match run_source("vector_set([1], 0, 2)", "n16.ktf") {
        Ok(_) => panic!("vector-set should be unbound reference"),
        Err(e) => e,
    };
    assert_eq!(
        err.stage,
        Stage::Compile,
        "unbound reference in compile segment"
    );
    assert!(
        err.rendered.contains("unbound reference: `vector-set`"),
        "vector-set unbound message(actual: {})",
        err.rendered
    );
}

// --- Target-face lexing/grammar family (4) — dual-Reader error parity ---

/// Negative 17: missing comma between elements (`[1 2]` on the target
/// face — space separation is the S-expr form; the target skin demands
/// commas).
#[test]
fn neg_missing_comma() {
    assert_grammar_err_parity("[1 2]", "missing-comma");
}

/// Negative 18: trailing comma (`[1, 2,]` — the fail-closed rejection
/// the seed and mirror arms share verbatim).
#[test]
fn neg_trailing_comma() {
    let msg = assert_grammar_err_parity("[1, 2,]", "trailing-comma");
    assert!(
        msg.contains("vector literal trailing comma illegal"),
        "trailing comma rejected message(actual: {})",
        msg
    );
}

/// Negative 19: unclosed bracket (`[1, 2` — eof).
#[test]
fn neg_unclosed() {
    assert_grammar_err_parity("[1, 2", "unclosed");
}

/// Negative 20: bracket mismatch (`[1, 2)` — wrong closer).
#[test]
fn neg_mismatched_close() {
    assert_grammar_err_parity("[1, 2)", "mismatched-close");
}

// --- Grammar settlement (2) — the dual-Reader canonical parity anchors ---

/// Negative 21: the dual-Reader canonical parity of vector datums (the
/// comma-elision mapping produces byte-identical Stx trees — spans
/// included; any drift = skin non-transparency).
#[test]
fn neg_grammar_parity_vectors() {
    assert_grammar_parity("[1, 2, 3]", "flat");
    assert_grammar_parity("[]", "empty");
    assert_grammar_parity("[1, [2, 3]]", "nested");
    assert_grammar_parity("[a, \"s\", 3]", "mixed");
    assert_grammar_parity("f([1], [2])", "call-args");
}

/// Negative 22: the bracket mismatch — the wrong closer (the delimiter
/// discipline carrying the vector brackets on the single target Reader).
/// E6 close-out rework (r154 / 224-c3): the classic S-expr Reader's
/// "mismatched parentheses" carrier retired — the target face reports
/// the wrong closer as "expected ], got RParen" (calibrated by
/// running).
#[test]
fn neg_sexpr_bracket_mismatch() {
    let mut t = SymbolTable::new();
    let err = match read_source("[1, 2)", 0, &mut t) {
        Err(e) => e,
        Ok(_) => panic!("bracket mismatch should report an error"),
    };
    assert!(
        err.message.contains("expected ], got RParen"),
        "bracket mismatch message(actual: {})",
        err.message
    );
}

// --- Semantic boundary anchors (2) — identity & shadowing laws ---

/// Negative 23 (r162 / 233 — TD-037 D5 law revision): eq on vectors is
/// STRUCTURAL value equality — twice-constructed empty vectors ARE eq
/// (the r138-era per-instance identity law retired with the
/// equality-domain window: immutable-by-construction ⟹ value equality;
/// the pre-r162 expectation `false` flipped); same-binding self- eq
/// stays `true`.
#[test]
fn neg_eq_vector_reference_identity() {
    let v = alt_value("eq(vector(), vector())", "n23.ktf");
    assert_eq!(
        v, "true",
        "twice-constructed empty vectors eq = true (r162 structural law)"
    );
    let w = alt_value("let a = [];\neq(a, a)", "n23.ktf");
    assert_eq!(w, "true", "same binding self- eq = true");
}

/// Negative 24: lexical capture of the desugar reference (the
/// as-if-written law — a fn PARAM named `vector` captures the desugared
/// Var by (name, scopes ⊆) resolution, so the literal `[1]` inside the
/// body applies the param value instead of the builtin constructor; a
/// global define of a builtin name is E0004-rejected by the established
/// D1/E6 add-only law, so the param capture is the shadowing carrier).
#[test]
fn neg_vector_shadowing_as_if_written() {
    // The param `vector` captures the desugar: `[1]` → `(vector 1)` →
    // applies the PARAM (a fn returning ()) → is_vector(()) = false
    // (E6 close-out r154 / 224-c3: the target fn-declaration shape —
    // the param list is the shadowing carrier)
    let v = alt_value(
        "fn f(vector: T) -> T { is_vector([1]) }\nf(|| (x: T) { () })",
        "n24.ktf",
    );
    assert_eq!(
        v, "false",
        "formal parameter capture desugar reference(as-if-written rule)"
    );
    // The un-captured control: the same literal at top level → true
    let w = alt_value("is_vector([1])", "n24.ktf");
    assert_eq!(w, "true", "uncaptured control group");
}

// --- Extra boundary negatives (3) — application-head / quote-path OOB /
// --- nested unclosed (completing the exact 9:27 = 1:3 ratio) ---

/// Negative 25: a vector in application-head position is not callable
/// (the value domain has no vector callable — the runtime face).
#[test]
fn neg_apply_vector_not_callable() {
    // E6 close-out (r154 / 224-c3): the vector-literal postfix call form
    // is the target-face application-head carrier — the callee slot
    // holds the bracket literal, the runtime rejects the call.
    alt_err("[1, 2](3)", "uncallable value: vector");
}

/// Negative 26: quote-path out-of-bounds (the D2-b runtime-construction
/// product indexes under the same discipline — the quote vector is a
/// real vector with real bounds).
#[test]
fn neg_quote_vector_oob() {
    alt_err(
        "import kerf_vector;\nvector_ref(quote([1]), 5)",
        "vector-ref index out of bounds:5(length 1)",
    );
}

/// Negative 27: nested unclosed brackets on the target face
/// (dual-Reader error parity — the eof discipline through the new arm).
#[test]
fn neg_nested_unclosed() {
    assert_grammar_err_parity("[[1,", "nested-unclosed");
}

// ---------------------------------------------------------------------------
// Cross-stage consumption — check face (diagnostic-clean with artifacts)
// ---------------------------------------------------------------------------

/// The check face: a vector program through the check face stays
/// diagnostic-clean with real instruction artifacts (the A4 Dynamic
/// holding — zero false positives; the production check.ktf path keeps
/// vector calls dynamic per the registered TC-SIGS asymmetry).
#[test]
fn vector_check_face_clean() {
    let report = check_source_recover("import kerf_vector;\nvector_append([1, 2], [3])", "chk.ktf")
        .expect("check face should pass(A4 Dynamic zero false positives)");
    assert!(
        report.diagnostics.is_empty(),
        "vector program check zero diagnostics (actual: {:?})",
        report.rendered
    );
    assert!(report.instruction_count > 0, "real instruction artifact");
    assert!(
        report.global_ref_count >= 1,
        "global reference face contains vector-append(N1/module parse face)"
    );
}

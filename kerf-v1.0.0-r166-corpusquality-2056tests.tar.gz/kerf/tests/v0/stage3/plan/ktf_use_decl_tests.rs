//! .ktf use-declaration family tests — r131 / 201-c (the use-declaration
//! window: the eleventh skin-dictionary mapping — the `::` import tree).
//!
//! **Verification surfaces** (the target-face use family `use mod;` |
//! `use mod as a;` | `use mod::{m1, m2};` | `use mod::{m} as a;` |
//! `use a, b::{x};` → the S-expr import family Stx — full r40 M2 / alias
//! r130 / **selective r50 D65** — the target face's previously
//! inexpressible selective form; the driver's collect_import_items /
//! face_selects / verify_import_face E0024 arm consume it unchanged —
//! zero desugar, zero new primitives, principle 31; design single source
//! = use-declaration-design.md v1.0):
//! (1) **run-face E2E** — the selective / combined / multi-path forms
//! through `run_source` yield the same values as the S-expr face
//! counterparts (skin/skeleton isomorphism — the CLI dual-entry
//! architecture's expressive-parity gap closed; the selective semantics
//! are the D66 test group's: selected local name → underlying name flat
//! injection, qualified access unchanged, E0024 for off-face members);
//! (2) **the r131 grammar settlement** — the use family is verified
//! dual-Reader: seed vs mirror canonical Stx rendering byte-identical
//! (including the nested selection-list node and its braces-region
//! Span), error faces message + Span byte-identical (the r134 member-
//! rename acceptance: the `m as x` triple parses on both faces — the
//! former D3 domain-out diagnostic is retired; the first-position `as`
//! falls to the generic member-name expectation face);
//! (3) **cross-stage consumption** — the selective program through
//! `check_source_recover` stays diagnostic-clean with real
//! instruction artifacts;
//! (4) **fail-closed negatives** — reader-level position/structure
//! discipline (name-position `as` / missing operands / empty braces /
//! unclosed / keyword members / member-rename domain-out / pub / block
//! position / module-header selection = the pre-existing both-face
//! E0002 semantic boundary) + driver-level semantic discipline (E0019
//! multi-segment + unknown module / E0024 member not exported / E0022
//! unselected member / E0017 duplicate alias — the established
//! families, mirrored from the S-expr face's namespace_tests d66
//! anchors).
//!
//! Skin-dictionary basis: 20 §14 v1.23 (the eleventh mapping — the use
//! declaration / `::` import tree); 02 §8.13.1a v7.16 (the Level 0
//! production update). Window basis: switch-window-plan §4 out-of-domain registration row
//! (the use-declaration / `::` import-tree row — cleared this window) +
//! 22 §8 R-N5 + D65 (the S-expr selective import since r50) +
//! use-declaration-design.md v1.0 (design single source) +
//! t3plus-trigger-audit v1.50 (zero-signal maintenance —
//! user-instruction order, M1 form).
//! Ratio: 8 positive : 24 negative = 1:3 (§9.4.3).

use kerf_driver::bootstrap::reader::read_source_for_bootstrap;
use kerf_driver::{check_source_recover, run_source};
use kerf_reader::reader::read_source;
use kerf_syntax::{Stx, StxDatum, StxLiteral, SymbolTable};

// ---------------------------------------------------------------------------
// Value helpers
// ---------------------------------------------------------------------------

fn run_value(src: &str, filename: &str) -> String {
    let outcome = run_source(src, filename)
        .unwrap_or_else(|e| panic!("target face program {} execution failed:{}", filename, e));
    kerf_vm::render_value(&outcome.value, &outcome.heap)
}

// ---------------------------------------------------------------------------
// Dual-Reader parity helpers (the ktf_import_alias_tests.rs caliber —
// canonical rendering with Span bytes; error parity with message + Span
// byte equality)
// ---------------------------------------------------------------------------

fn render_stx(s: &Stx, t: &SymbolTable) -> String {
    let mut out = String::new();
    render_stx_into(s, t, &mut out);
    out
}

fn render_stx_into(s: &Stx, t: &SymbolTable, out: &mut String) {
    match &s.datum {
        StxDatum::Symbol(sym) => {
            out.push_str(&format!(
                "(sym {} {}..{})",
                t.name(*sym),
                s.span.start,
                s.span.end
            ));
        }
        StxDatum::Literal(l) => match l {
            StxLiteral::Int(v) => {
                out.push_str(&format!("(int {} {}..{})", v, s.span.start, s.span.end));
            }
            StxLiteral::Float(f) => {
                out.push_str(&format!("(float {:?} {}..{})", f, s.span.start, s.span.end));
            }
            StxLiteral::Str(r) => {
                out.push_str(&format!("(str {:?} {}..{})", r, s.span.start, s.span.end));
            }
            StxLiteral::Bool(b) => {
                out.push_str(&format!("(bool {} {}..{})", b, s.span.start, s.span.end));
            }
            StxLiteral::Nil => {
                out.push_str(&format!("(unit {}..{})", s.span.start, s.span.end));
            }
        },
        StxDatum::List(items) => {
            out.push_str(&format!("(lst {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
        // r138 / 208-c — TD-002: vectors now reach both Readers (the
        // fourteenth skin mapping) — full canonical rendering
        StxDatum::Vector(items) => {
            out.push_str(&format!("(vec {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
    }
}

/// Grammar parity assertion: both Readers' canonical renderings are
/// byte-identical (the r131 grammar settlement's core gate — the use
/// family is seed/mirror isomorphic by construction, including the
/// nested selection-list node and its braces-region Span bytes).
fn assert_grammar_parity(src: &str, what: &str) {
    let mut t1 = SymbolTable::new();
    let seed = read_source(src, 0, &mut t1)
        .unwrap_or_else(|e| panic!("[{}] seed syntax failed: {}", what, e.message));
    let mut t2 = SymbolTable::new();
    let mirror = read_source_for_bootstrap(src, 0, &mut t2)
        .unwrap_or_else(|e| panic!("[{}] mirror syntax failed:{}", what, e.message));
    assert_eq!(
        seed.len(),
        mirror.len(),
        "[{}] top-level item count mismatch (seed {} vs mirror {})",
        what,
        seed.len(),
        mirror.len()
    );
    for (i, (a, b)) in seed.iter().zip(mirror.iter()).enumerate() {
        assert_eq!(
            render_stx(a, &t1),
            render_stx(b, &t2),
            "[{}] top-level item #{} syntax tree mismatch (seed vs mirror canonical render)",
            what,
            i
        );
    }
}

/// Grammar-error parity assertion: message + Span byte-level equality
/// (the mirror's diagnostic face is the seed's, by construction — the
/// D3 member-rename diagnostic is anchored in both the first-position
/// and the after-member shapes).
fn assert_grammar_err_parity(src: &str, what: &str) -> String {
    let mut t1 = SymbolTable::new();
    let seed_err = match read_source(src, 0, &mut t1) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] seed should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    let mut t2 = SymbolTable::new();
    let mirror_err = match read_source_for_bootstrap(src, 0, &mut t2) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] mirror should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    assert_eq!(
        seed_err.message, mirror_err.message,
        "[{}] syntax error message mismatch (seed {:?} vs mirror {:?})",
        what, seed_err.message, mirror_err.message
    );
    assert_eq!(
        seed_err.span.start, mirror_err.span.start,
        "[{}] syntax error Span start mismatch (seed {} vs mirror {})",
        what, seed_err.span.start, mirror_err.span.start
    );
    assert_eq!(
        seed_err.span.end, mirror_err.span.end,
        "[{}] syntax error Span end mismatch (seed {} vs mirror {})",
        what, seed_err.span.end, mirror_err.span.end
    );
    seed_err.message.clone()
}

// ---------------------------------------------------------------------------
// Positives — run-face E2E + grammar settlement + cross-stage consumption
// ---------------------------------------------------------------------------

/// Positive 1 / integration: the core E2E — `use kerf_string::{append};`
/// with the flat underlying-name reference through the production run
/// chain (Reader → Stx `(import kerf-string (append))` →
/// collect_import_items selection registration → flat_underlying
/// filtered injection → the unqualified `string_append` binding — the
/// D65 selective semantics' target-face debut).
#[test]
fn use_selective_flat_visibility_e2e() {
    let v = run_value(
        "use kerf_string::{append};\nstring_append(\"r131\", \" use-ok\")",
        "use.ktf",
    );
    assert_eq!(
        v, "r131 use-ok",
        "selective-form flat injection must produce r131 use-ok(actual: {})",
        v
    );
}

/// Positive 2 / integration: cross-grammar value parity — the same
/// selective program in both faces yields the same value (principle 31:
/// the Stx is the identical r50/D65 form, so the driver behavior must be
/// identical — the previously inexpressible target-face form now provably
/// converges with the S-expr face).
#[test]
fn use_cross_grammar_value_parity() {
    let ktf = run_value(
        "use kerf_string::{append};\nstring_append(\"a\", \"b\")",
        "use.ktf",
    );
    // E6 r154 / 224-c6: the .krf twin leg retired with the S-expr face;
    // the selective-form value anchor pins on the target side.
    assert_eq!(
        ktf, "ab",
        "selective form program value anchor(actual: {})",
        ktf
    );
}

/// Positive 3 / grammar settlement: dual-Reader canonical rendering
/// parity — five shapes (bare / selection / alias+selection combined /
/// multi-path / trailing comma in braces), byte-identical including the
/// nested selection-list node and its braces-region Span bytes; plus the
/// canonical form check: the selection shape's Stx must carry the nested
/// list symbol-for-symbol — (import kerf-string (append)).
#[test]
fn use_dual_reader_canonical_parity() {
    assert_grammar_parity("use kerf_string;", "bare form");
    assert_grammar_parity("use kerf_string::{append};", "selective form");
    assert_grammar_parity(
        "use kerf_string::{append, to_upper};",
        "multi-member selective form",
    );
    assert_grammar_parity(
        "use kerf_string::{append} as str;",
        "compound form(selective+alias)",
    );
    assert_grammar_parity("use kerf_core, kerf_string::{append};", "multi-path form");
    assert_grammar_parity(
        "use kerf_string::{append,};",
        "braces trailing comma form(arm family optional)",
    );
    // The canonical form check: the selection shape's Stx must carry the
    // nested member list — (import kerf-string (append to-upper)) with
    // the member names going through the underscore→hyphen payload
    // mapping (to_upper → to-upper).
    let mut t = SymbolTable::new();
    let items = read_source("use kerf_string::{append, to_upper};", 0, &mut t)
        .expect("selective form must parse succeeded");
    let rendered = render_stx(&items[0], &t);
    assert!(
        rendered.contains("(sym kerf-string ")
            && rendered.contains("(sym to-upper ")
            && rendered.contains("(sym append "),
        "canonical render must containing nested selective list three symbol(kerf-string/append/to-upper -- actual: {})",
        rendered
    );
    // The nested list node's own Span = the braces region (D10)
    assert!(
        rendered.contains("(lst "),
        "canonical render must containing selective list nested node(actual: {})",
        rendered
    );
}

/// Positive 4 / integration: the bare and alias forms E2E — the bare
/// `use mod;` injects the full export face (same Stx as `import mod;`)
/// and the alias `use mod as a;` carries the qualified-reference
/// relation (same Stx as the r130 tenth mapping — the spelling-redundancy
/// legality of D5, value-level proof).
#[test]
fn use_bare_and_alias_forms_e2e() {
    let bare = run_value(
        "use kerf_string;\nstring_append(\"bare\", \" ok\")",
        "bare.ktf",
    );
    assert_eq!(
        bare, "bare ok",
        "bare form full injection must be usable(actual: {})",
        bare
    );
    let alias = run_value(
        "use kerf_string as str;\nstr::append(\"alias\", \" ok\")",
        "alias.ktf",
    );
    assert_eq!(
        alias, "alias ok",
        "alias form qualified reference must be usable(actual: {})",
        alias
    );
}

/// Positive 5 / integration: the combined form E2E — `use kerf_string::
/// {append} as str;` carries BOTH the selection injection and the module
/// alias (the d66 third anchor's target face: `str::append` qualified
/// reference and `string_append` flat reference are both live).
#[test]
fn use_combined_alias_selection_e2e() {
    let v = run_value(
        "use kerf_string::{append} as str;\nstr::append(string_append(\"a\", \"b\"), \"c\")",
        "comb.ktf",
    );
    assert_eq!(
        v, "abc",
        "compound form selective+alias must be usable on both(actual: {})",
        v
    );
}

/// Positive 6 / integration: the multi-path form E2E + the qualified
/// access unchanged anchor + the hyphenated member mapping — the
/// comma-separated path list keeps both modules live; the original
/// module's qualified form stays reachable (the selection = flat-namespace
/// hygiene, not a trimming of the module relation — D65); the
/// hyphenated local member `to_upper` maps to the flat underlying
/// `string_to_upper`.
#[test]
fn use_multi_path_qualified_and_hyphenated_e2e() {
    let multi = run_value(
        "use kerf_string::{append}, kerf_list as l;\nl::length(l::list(1, 2))",
        "multi.ktf",
    );
    assert_eq!(
        multi, "2",
        "multi-path form two path must simultaneously live(actual: {})",
        multi
    );
    let qual = run_value(
        "use kerf_string::{append};\nstring::length(string_append(\"ab\", \"c\"))",
        "qual.ktf",
    );
    assert_eq!(
        qual, "3",
        "selective form after qualified access problem must maintains the module-level relation(actual: {})",
        qual
    );
    let hyph = run_value(
        "use kerf_string::{to_upper};\nstring_to_upper(\"ab\")",
        "hyph.ktf",
    );
    assert_eq!(
        hyph, "AB",
        "hyphen-member underscore mapping must consistent(actual: {})",
        hyph
    );
}

/// Positive 7 / integration: the module-header position — the bare/alias
/// use forms are legal module-head declarations (same Stx as the import
/// family; the head scanner's as-pair skipping accepts them — the D6
/// probe anchor: ⇒ m head-ok).
#[test]
fn use_module_header_alias_form_e2e() {
    let v = run_value(
        "module m { use kerf_string as str; export make; fn make() { str::append(\"m\", \" head-ok\") } }\nmake();",
        "moduse.ktf",
    );
    assert_eq!(
        v, "m head-ok",
        "module header alias form must accept(actual: {})",
        v
    );
}

/// Positive 8 / integration: cross-stage consumption — the selective
/// program through `check_source_recover` stays diagnostic-clean
/// with real instruction artifacts (the probe anchor: 1 proto / 4 const /
/// 9 instructions).
#[test]
fn use_check_cross_stage_clean() {
    let report = check_source_recover(
        "use kerf_string::{append};\nlet r = string_append(\"a\", \"b\");\nr",
        "use.ktf",
    )
    .expect("recovery mode check does not short-circuit");
    assert!(
        report.diagnostics.is_empty(),
        "selective form program check face must have zero diagnostics (actual: {:?})",
        report.diagnostics
    );
    assert!(
        report.proto_count + report.const_count > 0,
        "selective form program must have a real compile artifact(actual: proto {} + const {})",
        report.proto_count,
        report.const_count
    );
}

// ---------------------------------------------------------------------------
// Negatives — reader-level dual-Reader parity (message + Span bytes)
// ---------------------------------------------------------------------------

/// Negative 1: `as` in name position — the alias shape missing its module
/// name; the Span is the `as` Token itself on BOTH sides (the import
/// family's dedicated diagnostic, r130 latent-divergence-repair shape).
#[test]
fn neg_use_name_position_fail() {
    let m = assert_grammar_err_parity("use as b;", "name position as");
    assert!(
        m.contains("use as alias must follow the module name"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 2: name-position `as` after a comma — same diagnostic, the
/// second path slot.
#[test]
fn neg_use_name_position_after_comma_fail() {
    let m = assert_grammar_err_parity("use a, as b;", "name position after comma as");
    assert!(
        m.contains("use as alias must follow the module name"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 3: name-position Semi — the missing module name of an empty
/// declaration (`use ;`).
#[test]
fn neg_use_name_position_semi_fail() {
    let m = assert_grammar_err_parity("use ;", "name position Semi");
    assert!(
        m.contains("expected use module name, got Semi"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 4: name-position Int — the missing module name with a literal
/// in the slot.
#[test]
fn neg_use_name_position_int_fail() {
    let m = assert_grammar_err_parity("use 5;", "name position Int");
    assert!(
        m.contains("expected use module name, got Int(5)"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 5: name-position PathSep — a leading `::` without a module
/// name (`use ::{a};`).
#[test]
fn neg_use_name_position_pathsep_fail() {
    let m = assert_grammar_err_parity("use ::{a};", "name position PathSep");
    assert!(
        m.contains("expected use module name, got PathSep"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 6: missing alias operand — `use a as;` (Semi in the alias
/// slot).
#[test]
fn neg_use_alias_operand_semi_fail() {
    let m = assert_grammar_err_parity("use a as;", "alias position Semi");
    assert!(
        m.contains("expected an alias identifier, got Semi"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 7: missing alias operand — eof after `as`.
#[test]
fn neg_use_alias_operand_eof_fail() {
    let m = assert_grammar_err_parity("use a as", "alias position eof");
    assert!(
        m.contains("expected an alias identifier, got Eof"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 8: missing alias operand — a literal in the alias slot.
#[test]
fn neg_use_alias_operand_int_fail() {
    let m = assert_grammar_err_parity("use a as 5;", "alias position Int");
    assert!(
        m.contains("expected an alias identifier, got Int(5)"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 9: empty braces — the EBNF requires ≥1 use_tree; the error
/// points at the closing token (the macro literal-set family's shape).
#[test]
fn neg_use_empty_braces_fail() {
    let m = assert_grammar_err_parity("use a::{};", "empty braces");
    assert!(
        m.contains("expected a member name, got RBrace"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 10: unclosed braces — eof before `}`.
#[test]
fn neg_use_unclosed_braces_eof_fail() {
    let m = assert_grammar_err_parity("use a::{b", "missing right brace eof");
    assert!(m.contains("expected }, got Eof"), "message anchor: {:?}", m);
}

/// Negative 11: unclosed braces — Semi before `}` (a statement shape
/// inside the selection).
#[test]
fn neg_use_unclosed_braces_semi_fail() {
    let m = assert_grammar_err_parity("use a::{b;", "missing right brace Semi");
    assert!(
        m.contains("expected }, got Semi"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 12: keyword member name — `fn` in the member slot.
#[test]
fn neg_use_keyword_member_fail() {
    let m = assert_grammar_err_parity("use a::{fn};", "keyword member name");
    assert!(
        m.contains("expected a member name, got KwFn"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 13 (r134 flip): `as` in the first member position — now the
/// generic member-name expectation face (the rename triple is accepted
/// only after a member; a leading `as` falls to the non-Ident arm — the
/// former D3 domain-out diagnostic retired this window).
#[test]
fn neg_use_member_rename_first_position_fail() {
    let m = assert_grammar_err_parity("use m::{as x};", "member rename first slot");
    assert!(
        m.contains("expected a member name, got KwAs"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 13a (r134): the rename triple missing its right operand — a
/// `}` in the renamed slot (the dedicated expectation family, both
/// faces' Span = the offending token).
#[test]
fn neg_use_rename_operand_rbrace_fail() {
    let m = assert_grammar_err_parity("use a::{b as};", "rename right operand RBrace");
    assert!(
        m.contains("expected a member rename identifier, got RBrace"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 13b (r134): the rename triple missing its right operand — an
/// Int literal in the renamed slot.
#[test]
fn neg_use_rename_operand_int_fail() {
    let m = assert_grammar_err_parity("use a::{b as 5};", "rename right operand Int");
    assert!(
        m.contains("expected a member rename identifier, got Int(5)"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 13c (r134): a double `as` after a complete rename triple —
/// the brace-close expectation surfaces the second `as` (fail-closed —
/// double rename is not a legal member shape).
#[test]
fn neg_use_rename_double_as_fail() {
    let m = assert_grammar_err_parity("use a::{b as x as y};", "double rename");
    assert!(
        m.contains("expected }, got KwAs"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 15: top-level trailing comma — the import family's rejection
/// (the name-position diagnostic fires on the post-comma slot).
#[test]
fn neg_use_top_level_trailing_comma_fail() {
    let m = assert_grammar_err_parity("use a,;", "top level trailing comma");
    assert!(
        m.contains("expected use module name, got Semi"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 16: missing terminator — eof where `;` is expected.
#[test]
fn neg_use_missing_semicolon_eof_fail() {
    let m = assert_grammar_err_parity("use a", "missing semicolon eof");
    assert!(m.contains("expected ;, got Eof"), "message anchor: {:?}", m);
}

/// Negative 17: double alias — `as` after a complete alias pair (the
/// r130 family shape on the use surface).
#[test]
fn neg_use_double_alias_fail() {
    let m = assert_grammar_err_parity("use a as x as y;", "double alias");
    assert!(
        m.contains("expected ;, got KwAs"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 18: pub visibility — the pre-existing domain-out (22 §7
/// pub(scope) = Stage 2+ candidate registration).
#[test]
fn neg_use_pub_domain_out_fail() {
    let m = assert_grammar_err_parity("pub use a;", "pub out of domain");
    assert!(
        m.contains("pub visibility modifier"),
        "message anchor: {:?}",
        m
    );
}

/// Negative 19: block position — the statement-position fall-through (the
/// expected-expression family; the E0018 position discipline stays at
/// the Stx layer for both skins).
#[test]
fn neg_use_block_position_fail() {
    let m = assert_grammar_err_parity("fn f() -> () { use a; }", "inside a block position");
    assert!(
        m.contains("expected an expression, got KwUse"),
        "message anchor: {:?}",
        m
    );
}

// (r134) The former Negative 20 — the module-header selection E0002
// boundary — is retired this window (member-rename-design.md v1.0 §3
// D5: the header scan now accepts selection lists on both faces; the
// both-face acceptance E2E lives in ktf_member_rename_tests.rs positive
// ⑥ — the anchor flip per the design's D10 table).

// ---------------------------------------------------------------------------
// Negatives — driver-level semantic discipline (the established families
// mirrored from the S-expr face's namespace_tests d66 anchors)
// ---------------------------------------------------------------------------

/// Negative 21: multi-segment path — E0019 at compile time (the D1
/// single-layer module-name ruling; the merged Path token's ns is not on
/// the registration list — the identical error face to import).
#[test]
fn neg_use_multisegment_path_e0019() {
    let e = run_source("use kerf::string;", "path.ktf").expect_err("multi-segment path must E0019");
    assert!(
        e.rendered.contains("E0019") && e.rendered.contains("kerf/string"),
        "multi-segment path E0019 anchor(actual: {})",
        e.rendered
    );
}

/// Negative 22: multi-segment path with braces — the same E0019 face
/// (`use kerf::string::{append};` — the path merge takes `kerf::string`
/// before the `::{`).
#[test]
fn neg_use_multisegment_path_braces_e0019() {
    let e = run_source("use kerf::string::{append};", "pathb.ktf")
        .expect_err("multi-segment path braces form must E0019");
    assert!(
        e.rendered.contains("E0019") && e.rendered.contains("kerf/string"),
        "multi-segment path braces form E0019 anchor(actual: {})",
        e.rendered
    );
}

/// Negative 23: unknown module — the bare-name E0019 face (the
/// registration list is the hyphen-form single source).
#[test]
fn neg_use_unknown_module_e0019() {
    let e = run_source("use kerf_nonexistent;", "unk.ktf")
        .expect_err("not registration module must E0019");
    assert!(
        e.rendered.contains("E0019") && e.rendered.contains("kerf-nonexistent"),
        "not registration module E0019 anchor(actual: {})",
        e.rendered
    );
}

/// Negative 24 (composite): the selective-semantics negative battery —
/// E0024 for an off-face member, E0022 for an unselected member (the
/// visible face is filtered by the selection — the D65 core semantic
/// negative anchor), E0017 for a duplicate alias on the use surface.
#[test]
fn neg_use_semantic_battery_e0024_e0022_e0017() {
    // E0024 — the selected member is not on the module export face.
    let e = run_source("use kerf_string::{nonexist};", "e24.ktf")
        .expect_err("selective member not in export face must E0024");
    assert!(
        e.rendered.contains("E0024") && e.rendered.contains("nonexist"),
        "E0024 anchor(actual: {})",
        e.rendered
    );
    // E0022 — the unselected member is not flat-visible (the selection
    // filters the injection face).
    let e2 = run_source(
        "use kerf_string::{append};\nstring_length(\"a\");",
        "e22.ktf",
    )
    .expect_err("unselected member must E0022");
    assert!(
        e2.rendered.contains("E0022") && e2.rendered.contains("string-length"),
        "E0022 unselected member anchor(actual: {})",
        e2.rendered
    );
    // E0017 — duplicate alias on the use surface (the r130 family).
    let e3 = run_source("use kerf_string as str, kerf_list as str;", "e17.ktf")
        .expect_err("duplicate alias must E0017");
    assert!(
        e3.rendered.contains("E0017") && e3.rendered.contains("duplicate alias"),
        "E0017 anchor(actual: {})",
        e3.rendered
    );
}

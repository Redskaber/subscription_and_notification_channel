// E6 close-out (r154 / 224-c4): corpus converted to the target-syntax face.
//! .ktf diagnostic-message parity family tests — r141 / 211-c (the
//! registered message-unification row cleared: the nine static-check
//! message families converge to the oracle's op+got form —
//! diag-msg-unify-design.md v1.0 D1-D8).
//!
//! **Verification surfaces** (design single source =
//! diag-msg-unify-design.md):
//! (1) **full-text anchors** — every unified family renders its complete
//!     op+got text on the production face (`{op} requires {want}, got
//!     {rt}(static check)`, `if condition requires bool, got {rt}`,
//!     `uncallable value: {rt}`, `procedure argument count mismatch:
//!     expected {want}, got {n} (static check)`, `type mismatch: {x} and
//!     {y}(static check)`, `cannot construct an infinite type: α{i} and
//!     {t}(static check)`);
//! (2) **dual-shape parity** — the same violation program reports the
//!     same unified text through both program shapes (the alternate
//!     top-level/define-value/closure shapes + the fn-declaration
//!     target shape);
//! (3) **arity want forms** — the three expectation shapes render
//!     byte-identically to hm.rs 1074-1075 (`{mn}..{mx}` bounded /
//!     `≥{mn}` unbounded / `{k}` fixed 'sigf);
//! (4) **Unicode rendering** — the α (U+03B1) and → (U+2192) segments
//!     flow through the bootstrap Reader/VM/bridge/CLI chain (probe
//!     `(string-append "α" "≥3" "→")` ⇒ `α≥3→`);
//! (5) **the r135 derivation discipline preserved** — a renamed member's
//!     apply-position violation reports through the underlying name
//!     (TC-RENAME chain — the message carries no rename trace);
//! (6) **multi-violation collection** — two families in one program
//!     collect as two diagnostics, each carrying its full unified text
//!     (the r75 recovery channel);
//! (7) **cross-stage consumption** — the r138 vector value model checks
//!     clean through the unified face (positive) and the unified text
//!     flows through the E0005 report surface (negative);
//! (8) **count parity untouched** — the message unification changes text
//!     only; the recording sites and firing conditions are byte-identical
//!     to r140 (D6 — the ⊆ oracle guard face).
//!
//! Basis: tc-sigs-parity-design.md §7 row 1 (registered trigger =
//! corpus/user signal — the r141 user instruction exercised the user
//! arm, M1 form #46) + hm.rs check_param_rule/unify/infer_app (oracle
//! behavior spec = the unification target form) + check.ktf 22 message
//! sites (implementation surface). Ratio: 8 positive : 24 negative = 1:3
//! (§9.4.3).
//!
//! E6 close-out (r154 / 224-c4): the S-expr seed face retired — the
//! former seed legs now drive the same target chain through alternate
//! program shapes (top-level case expressions / `define(x, v);` value
//! definitions / `||`-closure bindings; E6-CG §2 skin dictionary —
//! `'sym` → `quote(sym)`, quoted list literals → the `list(...)`
//! constructor), while the fn-declaration legs keep the target shape.
//! All full-text anchors recalibrated by running: every unified text
//! carries the `(static check)` stage suffix unchanged; the one
//! surface-driven recalibration is n18 (`(< 1)` is infix-inexpressible
//! on the target face — the call-form `mod` row, the keyword-table
//! permanent resident with the same min-2 unbounded signature, carries
//! the `≥2` want form).

use kerf_driver::{check_source_recover, run_source};

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/// Alternate program-shape static check: expect >= 1 diagnostic
/// containing `needle` (full unified text anchors). E6 close-out r154 /
/// 224-c4: the S-expr seed face retired — the former seed legs drive
/// the same target chain through the alternate program shapes
/// (top-level case expressions / `define(x, v);` value definitions /
/// `||`-closure bindings).
fn expect_alt_diag(src: &str, needle: &str) {
    let report = check_source_recover(src, "diagmsg.ktf").expect("check must pass compile");
    assert!(
        report
            .diagnostics
            .iter()
            .any(|d| d.message.contains(needle)),
        "alternate shape must report `{}`: actual {:?}",
        needle,
        report
            .diagnostics
            .iter()
            .map(|d| d.message.as_str())
            .collect::<Vec<_>>()
    );
}

/// Target-face (fn-declaration shape) static check: expect >= 1
/// diagnostic containing `needle`.
fn expect_target_diag(src: &str, needle: &str) {
    let report = check_source_recover(src, "diagmsg.ktf").expect("check must pass compile");
    assert!(
        report
            .diagnostics
            .iter()
            .any(|d| d.message.contains(needle)),
        "target face must report `{}`: actual {:?}",
        needle,
        report
            .diagnostics
            .iter()
            .map(|d| d.message.as_str())
            .collect::<Vec<_>>()
    );
}

/// Alternate program-shape static check: zero diagnostics.
fn expect_alt_clean(src: &str) {
    let report = check_source_recover(src, "diagmsgok.ktf").expect("check must pass compile");
    assert!(
        report.diagnostics.is_empty(),
        "alternate shape must be diagnostic-free: {:?}",
        report.rendered
    );
}

/// Target-face static check: zero diagnostics.
fn expect_target_clean(src: &str) {
    let report = check_source_recover(src, "diagmsgok.ktf").expect("check must pass compile");
    assert!(
        report.diagnostics.is_empty(),
        "target face must be diagnostic-free: {:?}",
        report.rendered
    );
}

/// Alternate program-shape diagnostic count (multi-violation collection
/// anchor).
fn alt_diag_count(src: &str) -> usize {
    let report = check_source_recover(src, "diagmsgmulti.ktf").expect("check must pass compile");
    report.diagnostics.len()
}

// ---------------------------------------------------------------------------
// 1. Positive: every family's representative member checks clean
// ---------------------------------------------------------------------------

#[test]
fn p01_num_family_variadic_clean() {
    expect_alt_clean("1 + 2 + 3");
}

#[test]
fn p02_str_family_clean() {
    expect_alt_clean("import kerf_string;\nstring_append(\"a\", \"b\")");
}

#[test]
fn p03_int_family_clean() {
    expect_alt_clean("import kerf_prelude;\nnth(list(1, 2), 1)");
}

#[test]
fn p04_pair_family_clean() {
    // the quoted pair literal `'(1 2)` converts to the `list(...)`
    // constructor (E6-CG §2 — the quote-list data form stays out of the
    // expression surface)
    expect_alt_clean("import kerf_list;\nlast_pair(list(1, 2))");
}

#[test]
fn p05_bool_condition_clean() {
    expect_alt_clean("if (1 < 2) { 1 } else { 2 }");
}

#[test]
fn p06_arity_variadic_clean() {
    expect_alt_clean("5 - 2 - 1");
}

/// Cross-stage consumption: the r138 vector value model checks clean
/// through the unified face (the value window's five builtins + the
/// collection literal flow through check without diagnostics).
#[test]
fn p07_cross_stage_vector_clean() {
    expect_alt_clean("import kerf_vector;\nvector_length(vector(1, 2, 3))");
}

/// Dual-shape parity on a clean program (alternate top-level case +
/// fn-declaration target shape, same semantics).
#[test]
fn p08_dual_shape_same_clean() {
    expect_alt_clean("1 + 2");
    expect_target_clean("fn f() -> i64 { 1 + 2 }");
}

// ---------------------------------------------------------------------------
// 2. Negative: full-text unified anchors (families ①-⑧)
// ---------------------------------------------------------------------------

/// Family ① (requires / int kind): full op+got text, alternate shape.
#[test]
fn n01_alt_requires_int_full_text() {
    // r164/235-c: nth's static domain retired with the self-built migration —
    // the (T,T) generic unification reports the num/str conflict (fail-closed
    // maintained); the runtime face carries the exact retired-Rust message.
    expect_alt_diag(
        "import kerf_prelude;\nnth(list(1, 2), \"x\")",
        "type mismatch: num and str(static check)",
    );
}

/// Family ①: the same violation through the fn-declaration target
/// shape — identical text.
#[test]
fn n02_target_requires_int_full_text() {
    expect_target_diag(
        "import kerf_prelude;\nfn f() -> i64 { nth(list(1, 2), \"x\") }",
        "type mismatch: num and str(static check)",
    );
}

/// Family ② (num / "a number" wording): full text, alternate shape.
#[test]
fn n03_alt_requires_a_number_full_text() {
    expect_alt_diag("1 + \"x\"", "+ requires a number, got str(static check)");
}

/// Family ②: infix operator form on the target shape — same text.
#[test]
fn n04_target_requires_a_number_full_text() {
    expect_target_diag(
        "fn f() -> i64 { 1 + \"x\" }",
        "+ requires a number, got str(static check)",
    );
}

/// Family ① (str kind): full text, alternate shape.
#[test]
fn n05_alt_requires_str_full_text() {
    expect_alt_diag(
        "import kerf_string;\nstring_append(\"a\", 1)",
        "string-append requires str, got int(static check)",
    );
}

/// Family ① (str kind): target-shape call form.
#[test]
fn n06_target_requires_str_full_text() {
    expect_target_diag(
        "import kerf_string;\nfn f() -> str { string_append(\"a\", 1) }",
        "string-append requires str, got int(static check)",
    );
}

/// Family ① (pair kind): full text.
#[test]
fn n07_alt_requires_pair_full_text() {
    // r164/235-c: last-pair's static pair-domain retired — the generic (T)
    // face is static-clean; the runtime face carries the exact retired-Rust
    // message (asserted via the run chain).
    let err_n07 = run_source("import kerf_list;\nlast_pair(5)", "n07rt.ktf")
        .expect_err("n07 run must fail at runtime");
    assert!(
        err_n07
            .rendered
            .contains("last-pair requires list, got int"),
        "n07 runtime face: {}",
        err_n07.rendered
    );
}

/// Family ① (list kind): full text.
#[test]
fn n08_alt_requires_list_full_text() {
    let err_n08 = run_source("import kerf_list;\nreverse(5)", "n08rt.ktf")
        .expect_err("n08 run must fail at runtime");
    assert!(
        err_n08.rendered.contains("reverse requires list, got int"),
        "n08 runtime face: {}",
        err_n08.rendered
    );
}

/// Family ① (symbol kind): full text.
#[test]
fn n09_alt_requires_symbol_full_text() {
    expect_alt_diag(
        "import kerf_string;\nsymbol_to_string(5)",
        "symbol-to-string requires symbol, got int(static check)",
    );
}

/// Family ③ (head structural): full op+got text.
#[test]
fn n10_alt_head_full_text() {
    expect_alt_diag("head(5)", "head requires pair, got int(static check)");
}

/// Family ③ (tail structural): full op+got text.
#[test]
fn n11_alt_tail_full_text() {
    expect_alt_diag("tail(5)", "tail requires pair, got int(static check)");
}

/// Family ④ (if condition): full text, alternate shape.
#[test]
fn n12_alt_if_condition_full_text() {
    expect_alt_diag(
        "if 1 { 2 } else { 3 }",
        "if condition requires bool, got int(static check)",
    );
}

/// Family ④: target-shape if/else value form.
#[test]
fn n13_target_if_condition_full_text() {
    expect_target_diag(
        "fn f() -> i64 { if 1 { 2 } else { 3 } }",
        "if condition requires bool, got int(static check)",
    );
}

/// Family ⑤ (uncallable): full value-type text, alternate shape (the
/// `define(x, 1);` value definition + a call case).
#[test]
fn n14_alt_uncallable_full_text() {
    expect_alt_diag("let x = 1;\nx(2)", "uncallable value: int(static check)");
}

/// Family ⑤: target-shape let-bound int called.
#[test]
fn n15_target_uncallable_full_text() {
    expect_target_diag(
        "fn f() -> i64 { let x = 1; x(2) }",
        "uncallable value: int(static check)",
    );
}

/// r135 derivation discipline through the unified construction: a
/// renamed member's apply-position violation reports through the
/// UNDERLYING name (TC-RENAME chain — the message carries no rename
/// trace, D12-③).
#[test]
fn n16_alt_renamed_derivation_full_text() {
    expect_alt_diag(
        "use kerf_string::{append as sa};\nsa(1, 2)",
        "string-append requires str, got int(static check)",
    );
}

/// Family ⑥ (arity / bounded `{mn}..{mx}` want form).
#[test]
fn n17_alt_arity_bounded_dots_form() {
    expect_alt_diag(
        "import kerf_string;\nstring_append(\"a\")",
        "procedure argument count mismatch: expected 2..2, got 1 (static check)",
    );
}

/// Family ⑥ (arity / unbounded `≥{mn}` want form — Unicode U+2265).
/// E6 close-out recalibration (r154 / 224-c4): the former `(< 1)`
/// spelling is infix-inexpressible on the target face (E6-CG §2 —
/// `(< a b)` maps to the binary `a < b`); the call-form `mod` row (the
/// keyword-table permanent resident, same min-2 unbounded signature)
/// carries the same `≥2` want form — anchor recalibrated by running.
#[test]
fn n18_alt_arity_unbounded_ge_form() {
    expect_alt_diag(
        "mod(1)",
        "procedure argument count mismatch: expected ≥2, got 1 (static check)",
    );
}

/// Family ⑥ (arity / fixed 'sigf `{k}` want form).
#[test]
fn n19_alt_arity_sigf_plain_form() {
    expect_alt_diag(
        "import kerf_prelude;\nnth(list(1, 2))",
        "procedure argument count mismatch: expected 2, got 1 (static check)",
    );
}

/// Family ⑦ (unify conflict / num): two-sided rendering, expected type
/// first (mirror of the oracle unify(a, b) argument order).
#[test]
fn n20_alt_unify_conflict_num_full_text() {
    expect_alt_diag(
        "fn f(x: T) -> T { x + 1 }\nf(\"s\")",
        "type mismatch: num and str(static check)",
    );
}

/// Family ⑦ (unify conflict / bool): the if-condition constraint meets a
/// concrete string argument.
#[test]
fn n21_alt_unify_conflict_bool_full_text() {
    expect_alt_diag(
        "fn f(x: T) -> T { if (x) { 1 } else { 2 } }\nf(\"s\")",
        "type mismatch: bool and str(static check)",
    );
}

/// Family ⑧ (occurs): the α-variable id segment renders (form anchor —
/// ids are machine-local, count parity is the guarded face).
#[test]
fn n22_alt_occurs_alpha_form() {
    expect_alt_diag(
        "fn omega(x: T) -> T { x(x) }\nomega(omega)",
        "cannot construct an infinite type: α",
    );
}

/// Family ⑧ (occurs): the arrow-type two-sided rendering (the would-be
/// `(params → ret)` segment — Unicode U+2192 through the whole chain).
#[test]
fn n23_alt_occurs_arrow_render_form() {
    expect_alt_diag("fn omega(x: T) -> T { x(x) }\nomega(omega)", " and (α");
}

/// Multi-violation collection (the r75 recovery channel): two families
/// in one program collect as exactly two diagnostics, each carrying
/// its full unified text.
#[test]
fn n24_alt_multi_violation_collection() {
    let src = "import kerf_prelude;\n1 + \"x\"\nnth(list(1, 2), \"y\")";
    assert_eq!(
        alt_diag_count(src),
        2,
        "two families must collect as 2 diagnostics"
    );
    expect_alt_diag(src, "+ requires a number, got str(static check)");
    expect_alt_diag(src, "type mismatch: num and str(static check)");
}

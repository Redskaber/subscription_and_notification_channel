//! .ktf index-access family tests — r163 / 234 (the postfix index window:
//! `coll[idx]` → as-if-written `(vector-ref coll idx)` — the seventeenth
//! skin mapping; skin swap, skeleton unchanged — zero desugar pass, zero
//! new primitives, zero CoreExpr/IR/opcode; index-access-design.md v1.0
//! D1-D10).
//!
//! **Verification surfaces** (the index face — principle 31 skin/skeleton
//! isomorphism consumed entirely at the Reader layer on both sides; the
//! N1 compiler-visible-face admission of `vector-ref` (D2) serves the
//! import-free desugar target (D3 — the r138 D4 discipline extended);
//! 8 primitives' invariance round 45):
//! (1) **run-face E2E** — basic / last-position / expression index /
//! nested chain `m[1][0]` / literal-direct `[10, 20, 30][1]` / the N2
//! call-form compatibility (r138 face stays legal — dual-face coexistence
//! D10) / the r162 cross-stage consumption (`v[0] == 1` structural eq);
//! (2) **grammar settlement** — dual-Reader canonical Stx rendering
//! byte-identical ×4 shapes; the as-if-written structural anchor
//! (`v[1]` parses to the `(vector-ref v 1)` call form with head symbol
//! and ternary arity);
//! (3) **cross-stage consumption** — the check face clean (vector-ref sig
//! `(any, any) → unknown` pre-existing, D8 zero-registration);
//! (4) **fail-closed negatives** — Reader faces (empty `v[]` / multi-arg
//! `v[1, 2]` / eof truncation / assign-position immutability D5) / the
//! r161 const-boundary quartet (the previous window's repair boundary
//! ≥5 with the cross-stage positive) / VM domain faces ×5 (str / pair /
//! int collections + non-int index ×2 + negative + out-of-bounds) /
//! E0022 unbound ×2 (collection + the r159 hyphen-intercept maintained —
//! D2 honest disclosure) / E0006 capability / the r162 boundary regression
//! ×3 (mixed-domain silent false ×2 + ordering family maintained) / the
//! r138 immutability enforcement regression (vector_set unbound) /
//! 7 error classes coverage (E0001 ×6 / E0004 ×6 / E0005 ×1 / E0006 ×1 /
//! E0022 ×2 — ≥5 classes with E0002 covered by the hyphen-intercept's
//! unbind arm).
//!
//! Honest-boundary anchors (design D5/D6): `v[i] = x` assignment stays
//! domain-out (r138 D1 immutability — the Reader assign LHS takes only
//! identifier bindings); pair-list indexing stays on the `nth` call form
//! (import kerf_list — `lst[0]` fails at the VM domain check); Str
//! character indexing stays domain-out (byte-vs-char is an independent
//! design question — future window); the hyphenated `vector-ref`
//! direct-write face stays lexically intercepted by the r159 infix
//! family (as with `=`/`eq` at r162 — the N1 admission serves the Stx
//! symbol, not the direct write).
//!
//! Skin-dictionary basis: 20 §14 (the seventeenth mapping row — this
//! window); 02 §8 postfix production note v7.31. Window basis: user
//! instruction ① (「基础内置函数、数据类型、数据结构……应该通过目标语言
//! 自身设计实现」— the data-structure consumption triangle's third
//! corner) + index-access-design.md v1.0 D1-D10. Ratio: 9 positive :
//! 24 negative ≥ 1:3 (§9.4.3).

use kerf_driver::bootstrap::reader::read_source_for_bootstrap;
use kerf_driver::{check_source_recover, run_source};
use kerf_reader::reader::read_source;
use kerf_syntax::{Stx, StxDatum, SymbolTable};

// ---------------------------------------------------------------------------
// Value / error helpers
// ---------------------------------------------------------------------------

fn run_value(src: &str, filename: &str) -> String {
    let outcome =
        run_source(src, filename).unwrap_or_else(|e| panic!("{} execution failed:{}", filename, e));
    kerf_vm::render_value(&outcome.value, &outcome.heap)
}

fn run_err_contains(src: &str, needle: &str) {
    let err = run_source(src, "idx-neg.ktf")
        .err()
        .unwrap_or_else(|| panic!("expected an error, got Ok:{}", src));
    assert!(
        err.rendered.contains(needle),
        "expected `{}` in error, got:\n{}",
        needle,
        err.rendered
    );
}

fn read_err_message(src: &str) -> String {
    let mut table = SymbolTable::new();
    read_source(src, 0, &mut table)
        .err()
        .unwrap_or_else(|| panic!("expected a read error, parsed successfully:{}", src))
        .message
}

fn check_clean(src: &str) {
    let report = check_source_recover(src, "idx-check.ktf")
        .unwrap_or_else(|e| panic!("check compile failed:{}", e));
    assert!(
        report.diagnostics.is_empty(),
        "expected clean check, got:{}",
        report.rendered.join("\n")
    );
}

// ---------------------------------------------------------------------------
// Stx rendering / parity / as-if-written anchors
// ---------------------------------------------------------------------------

fn render_stx(s: &Stx, t: &SymbolTable) -> String {
    let mut out = String::new();
    render_stx_into(s, t, &mut out);
    out
}

fn render_stx_into(s: &Stx, t: &SymbolTable, out: &mut String) {
    match &s.datum {
        StxDatum::Symbol(sym) => out.push_str(t.name(*sym)),
        StxDatum::List(items) => {
            out.push('(');
            for (i, item) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(item, t, out);
            }
            out.push(')');
        }
        other => out.push_str(&format!("{:?}", other)),
    }
}

fn assert_grammar_parity(src: &str, what: &str) {
    let mut t1 = SymbolTable::new();
    let seed = read_source(src, 0, &mut t1)
        .unwrap_or_else(|e| panic!("[{}] seed syntax failed:{}", what, e.message));
    let mut t2 = SymbolTable::new();
    let mirror = read_source_for_bootstrap(src, 0, &mut t2)
        .unwrap_or_else(|e| panic!("[{}] mirror syntax failed:{}", what, e.message));
    assert_eq!(seed.len(), mirror.len(), "[{}] item count mismatch", what);
    for (s, m) in seed.iter().zip(mirror.iter()) {
        assert_eq!(
            render_stx(s, &t1),
            render_stx(m, &t2),
            "[{}] canonical rendering diverged",
            what
        );
    }
}

/// The dual-Reader error-face parity: both sides reject with the same
/// message and span (byte-identical error surface — the same-family
/// discipline as the r138/r160/r161/r162 windows).
fn assert_grammar_err_parity(src: &str, what: &str) -> String {
    let mut t1 = SymbolTable::new();
    let seed_err = match read_source(src, 0, &mut t1) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] seed should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    let mut t2 = SymbolTable::new();
    let mirror_err = match read_source_for_bootstrap(src, 0, &mut t2) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] mirror should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    assert_eq!(
        seed_err.message, mirror_err.message,
        "[{}] syntax error message mismatch (seed {:?} vs mirror {:?})",
        what, seed_err.message, mirror_err.message
    );
    assert_eq!(
        (seed_err.span.start, seed_err.span.end),
        (mirror_err.span.start, mirror_err.span.end),
        "[{}] syntax error span mismatch",
        what
    );
    seed_err.message
}

/// The as-if-written structural anchor: the skin parses to exactly the
/// call form of the terminal name (`v[1]` → `(vector-ref v 1)` with the
/// head symbol and ternary arity) — principle 31 skin/skeleton
/// isomorphism at the Stx datum level; the chain walk tolerates nested
/// postfix levels (`m[1][0]` → `(vector-ref (vector-ref m 1) 0)`).
fn assert_as_if_written(src: &str, what: &str) {
    let mut t = SymbolTable::new();
    let items = read_source(src, 0, &mut t)
        .unwrap_or_else(|e| panic!("[{}] syntax failed:{}", what, e.message));
    assert_eq!(items.len(), 1, "[{}] expected one top-level item", what);
    match &items[0].datum {
        StxDatum::List(parts) => {
            assert_eq!(parts.len(), 3, "[{}] call-form arity mismatch", what);
            match &parts[0].datum {
                StxDatum::Symbol(sym) => {
                    assert_eq!(
                        t.name(*sym),
                        "vector-ref",
                        "[{}] head symbol mismatch",
                        what
                    );
                }
                other => panic!("[{}] head is not a symbol: {:?}", what, other),
            }
        }
        other => panic!("[{}] expected a list, got {:?}", what, other),
    }
}

// ---------------------------------------------------------------------------
// Positive semantics (9) — the modern index face
// ---------------------------------------------------------------------------

/// The window opener: `v[0]` ⇒ 1 (E0001 domain-out pre-r163) + the
/// check-face cleanliness (integration: run + check dual paths — the
/// vector-ref sig `(any, any) → unknown` pre-existing, D8).
#[test]
fn pos_index_opener() {
    let a = run_value("let v = [1, 2, 3];\nv[0];", "idx-p1.ktf");
    assert_eq!(a, "1", "postfix index opener");
    check_clean("let v = [1, 2, 3];\nv[0] + v[1];");
}

/// Last-position + expression index: `v[2]` / `v[1 + 1]` ⇒ 3 (the index
/// slot takes a full expression — D1).
#[test]
fn pos_last_and_expression_index() {
    let a = run_value("let v = [1, 2, 3];\nv[2];", "idx-p2a.ktf");
    assert_eq!(a, "3", "last-position index");
    let b = run_value("let v = [1, 2, 3];\nlet i = 1;\nv[i + 1];", "idx-p2b.ktf");
    assert_eq!(b, "3", "expression index");
}

/// Nested chain indexing: `m[1][0]` ⇒ 3 (the synthetic product is an
/// expression — the postfix tail loop composes, D1).
#[test]
fn pos_nested_chain_index() {
    let a = run_value("let m = [[1, 2], [3, 4]];\nm[1][0];", "idx-p3.ktf");
    assert_eq!(a, "3", "nested chain index");
}

/// Literal-direct indexing: `[10, 20, 30][1]` ⇒ 20 (the r138 primary
/// literal + the r163 postfix face compose — both bracket faces in
/// domain).
#[test]
fn pos_literal_direct_index() {
    let a = run_value("[10, 20, 30][1];", "idx-p4.ktf");
    assert_eq!(a, "20", "literal-direct index");
}

/// Grammar settlement (the as-if-written anchor + dual-Reader parity):
/// `[10, 20, 30][1]` parses to the `(vector-ref [10, 20, 30] 1)` call
/// form (single top-level item, ternary arity — principle 31
/// isomorphism); the chain `[[1, 2], [3, 4]][1][0]` nests to
/// `(vector-ref (vector-ref … 1) 0)`; canonical Stx rendering
/// byte-identical both sides ×4 shapes (basic / expression / chain /
/// literal-direct).
#[test]
fn pos_grammar_settlement() {
    assert_as_if_written("[10, 20, 30][1];", "basic as-if-written");
    assert_as_if_written("[[1, 2], [3, 4]][1][0];", "chain as-if-written");
    assert_grammar_parity("let v = [1, 2, 3];\nv[0];", "parity basic");
    assert_grammar_parity(
        "let v = [1, 2, 3];\nlet i = 1;\nv[i + 1];",
        "parity expression",
    );
    assert_grammar_parity("let m = [[1, 2], [3, 4]];\nm[1][0];", "parity chain");
    assert_grammar_parity("[10, 20, 30][1];", "parity literal-direct");
}

/// The r138 N2 call-form compatibility: `import kerf_vector;
/// vector_ref(v, 1)` ⇒ 20 (the import-face call form stays legal —
/// dual-face coexistence, D10; the mid-window regression guard for the
/// N1 admission's side effects).
#[test]
fn pos_n2_call_form_compat() {
    let a = run_value(
        "import kerf_vector;\nlet v = [10, 20, 30];\nvector_ref(v, 1);",
        "idx-p7.ktf",
    );
    assert_eq!(a, "20", "N2 import call form stays legal");
}

/// The r162 cross-stage consumption: `v[0] == 1` ⇒ true (the structural
/// equality face composes with the index face — consecutive-skin
/// integration) + `v == v` self-identity.
#[test]
fn pos_r162_cross_stage_composition() {
    let a = run_value("let v = [1, 2, 3];\nv[0] == 1;", "idx-p8a.ktf");
    assert_eq!(a, "true", "index composes with structural eq");
    let b = run_value("let v = [1, 2, 3];\nv == [1, 2, 3];", "idx-p8b.ktf");
    assert_eq!(b, "true", "vector structural equality regression");
}

/// The r161 const cross-stage consumption: a const-bound vector indexes
/// cleanly (the read-only binding axis composes with the index face).
#[test]
fn pos_r161_const_composition() {
    let a = run_value("const V = [5, 6, 7];\nV[2];", "idx-p9.ktf");
    assert_eq!(a, "7", "const composes with the index face");
}

// ---------------------------------------------------------------------------
// Negative semantics (24) — fail-closed families
// ---------------------------------------------------------------------------

/// E0001 family — empty index `v[]`: exactly one index expression
/// required (D6 dedicated Reader diagnosis) + dual-Reader error parity.
#[test]
fn neg_empty_index() {
    let msg = read_err_message("let v = [1, 2, 3];\nv[];");
    assert!(
        msg.contains("expected an expression"),
        "empty index dedicated diagnosis (actual: {})",
        msg
    );
    let parity_msg = assert_grammar_err_parity("let v = [1, 2, 3];\nv[];", "parity empty index");
    assert!(
        parity_msg.contains("expected an expression"),
        "empty index parity message (actual: {})",
        parity_msg
    );
}

/// E0001 family — multi-arg index `v[1, 2]`: expected `]` got Comma
/// (D6) + dual-Reader error parity.
#[test]
fn neg_multi_arg_index() {
    let msg = read_err_message("let v = [1, 2, 3];\nv[1, 2];");
    assert!(
        msg.contains("expected ]"),
        "multi-arg index dedicated diagnosis (actual: {})",
        msg
    );
    let parity_msg = assert_grammar_err_parity("let v = [1, 2, 3];\nv[1, 2];", "parity multi-arg");
    assert!(
        parity_msg.contains("expected ]"),
        "multi-arg parity message (actual: {})",
        parity_msg
    );
}

/// E0001 family — eof truncation `v[1` (the deferred `]` expectation
/// renders the eof message — the call-args discipline mirrored).
#[test]
fn neg_eof_truncation() {
    let msg = read_err_message("let v = [1, 2, 3];\nv[1");
    assert!(
        msg.contains("expected ]") && msg.contains("Eof"),
        "eof truncation diagnosis (actual: {})",
        msg
    );
}

/// E0001 family — chain-position eof truncation `v[1][` (the second
/// postfix level opens at eof — the empty index slot's expression
/// expectation renders the eof message: "expected an expression").
#[test]
fn neg_chain_eof_truncation() {
    let msg = read_err_message("let v = [[1, 2], [3, 4]];\nv[1][");
    assert!(
        msg.contains("expected an expression") && msg.contains("Eof"),
        "chain eof truncation diagnosis (actual: {})",
        msg
    );
}

/// E0001 family — assign position `v[0] = 5`: the Reader assign LHS
/// takes only identifier bindings — the r138 D1 immutability's
/// enforcement face (D5: mutable index assignment stays domain-out).
#[test]
fn neg_assign_position_immutability() {
    let msg = read_err_message("let v = [1, 2, 3];\nv[0] = 5;");
    assert!(
        msg.contains("expected an expression"),
        "assign-position immutability diagnosis (actual: {})",
        msg
    );
}

/// E0001 family — the r161 boundary quartet (1/4): const assign reject
/// (the previous window's repair boundary ≥5 — regression guard).
#[test]
fn neg_r161_const_assign_reject() {
    let msg = read_err_message("const X = 1;\nX = 2;");
    assert!(
        msg.contains("cannot assign to a const binding"),
        "r161 const assign reject regression (actual: {})",
        msg
    );
}

/// E0001 family — the r161 boundary quartet (2/4): const-mut
/// contradiction.
#[test]
fn neg_r161_const_mut_contradiction() {
    let msg = read_err_message("const mut X = 1;");
    assert!(
        msg.contains("contradictory"),
        "r161 const-mut contradiction regression (actual: {})",
        msg
    );
}

/// E0001 family — the r161 boundary quartet (3/4): single-binding cap.
#[test]
fn neg_r161_single_binding_cap() {
    let msg = read_err_message("const A = 1, B = 2;");
    assert!(
        msg.contains("single binding"),
        "r161 single-binding cap regression (actual: {})",
        msg
    );
}

/// E0001 family — the r161 boundary quartet (4/4): block-position
/// domain-out.
#[test]
fn neg_r161_block_position_domain_out() {
    let msg = read_err_message("fn f() { const X = 1; X }");
    assert!(
        msg.contains("item position only"),
        "r161 block-position domain-out regression (actual: {})",
        msg
    );
}

/// E0004 family — Str collection: `"abc"[0]` (D6: Str character indexing
/// stays domain-out — byte-vs-char is an independent design question).
#[test]
fn neg_str_domain_out() {
    run_err_contains(
        "require io, write;\nprint(\"abc\"[0]);",
        "vector-ref requires vector, got str",
    );
}

/// E0004 family — pair-list collection: `lst[0]` (D6: pair-list indexing
/// stays on the `nth` call form — `import kerf_list`).
#[test]
fn neg_pair_list_domain_out() {
    run_err_contains(
        "require io, write;\nlet lst = list(1, 2);\nprint(lst[0]);",
        "vector-ref requires vector, got pair",
    );
}

/// E0004 family — int collection: `1[2]` (the literal composes through
/// the skin — the VM domain check rejects).
#[test]
fn neg_int_collection_domain() {
    run_err_contains(
        "require io, write;\nprint(1[2]);",
        "vector-ref requires vector, got int",
    );
}

/// E0004 family — non-int index (str): `v["x"]`.
#[test]
fn neg_non_int_index_str() {
    run_err_contains(
        "require io, write;\nlet v = [1, 2, 3];\nprint(v[\"x\"]);",
        "vector-ref index requires int, got str",
    );
}

/// E0004 family — non-int index (bool): `v[true]`.
#[test]
fn neg_non_int_index_bool() {
    run_err_contains(
        "require io, write;\nlet v = [1, 2, 3];\nprint(v[true]);",
        "vector-ref index requires int, got bool",
    );
}

/// E0004 family — negative index `v[-1]`: the dedicated out-of-bounds
/// diagnosis with the negative value rendered (r138's index-arithmetic
/// error family — distinct from domain errors).
#[test]
fn neg_negative_index_out_of_bounds() {
    run_err_contains(
        "require io, write;\nlet v = [1, 2, 3];\nprint(v[-1]);",
        "vector-ref index out of bounds:-1(length 3)",
    );
}

/// E0004 family — out-of-bounds `v[99]` (the r138 dedicated diagnosis
/// regression through the new skin).
#[test]
fn neg_out_of_bounds() {
    run_err_contains(
        "require io, write;\nlet v = [1, 2, 3];\nprint(v[99]);",
        "vector-ref index out of bounds:99(length 3)",
    );
}

/// E0005 family — the check-face static domain: the ordering family
/// keeps its diagnostics through the check path (`true < false` — the
/// r162 same-path audit maintained; the index face's sig is
/// `(any, any) → unknown` — static-clean by design).
#[test]
fn neg_check_static_ordering_maintained() {
    let report = check_source_recover("let a = true < false;", "idx-check-neg.ktf")
        .unwrap_or_else(|e| panic!("check failed: {}", e));
    assert!(
        report.diagnostics.iter().any(|d| d.is_error()),
        "ordering family static diagnostics maintained"
    );
}

/// E0006 family — capability gate: print without the require
/// declaration (the eighth mapping's consumption face — regression
/// through an index-composed program).
#[test]
fn neg_capability_gate() {
    run_err_contains("let v = [1, 2, 3];\nprint(v[0]);", "E0006");
}

/// E0022 family — unbound collection: `x[0]` (the compile-layer symbol
/// resolution rejects before any index evaluation).
#[test]
fn neg_unbound_collection() {
    run_err_contains("require io, write;\nprint(x[0]);", "E0022");
}

/// E0022 family — the r159 hyphen intercept maintained: `vector-ref(v, 0)`
/// direct write parses as infix `vector - ref` → unbound `ref` (D2
/// honest disclosure: the N1 admission serves the Stx symbol of the
/// desugar product, not the hyphenated direct-write face — the same
/// law as `=`/`eq` at r162).
#[test]
fn neg_hyphen_direct_write_intercepted() {
    run_err_contains(
        "require io, write;\nlet v = [1, 2, 3];\nprint(vector-ref(v, 0));",
        "E0022",
    );
}

/// The r138 immutability enforcement regression: `vector_set([1], 0, 2)`
/// stays an unbound reference (D1's enforcement face — no setter exists).
#[test]
fn neg_r138_vector_set_unbound_regression() {
    run_err_contains("require io, write;\nvector_set([1], 0, 2);", "E0022");
}

/// The r162 boundary regression (1/3): mixed-domain `1 == "1"` ⇒ silent
/// false (the equality-domain window's honest boundary maintained).
#[test]
fn neg_r162_mixed_domain_str() {
    let a = run_value("1 == \"1\"", "idx-n162a.ktf");
    assert_eq!(a, "false", "mixed-domain silent false maintained")
}

/// The r162 boundary regression (2/3): mixed-domain `true == 1` ⇒ silent
/// false.
#[test]
fn neg_r162_mixed_domain_bool() {
    let a = run_value("true == 1", "idx-n162b.ktf");
    assert_eq!(a, "false", "mixed-domain silent false maintained")
}

/// The r162 boundary regression (3/3): the ordering family keeps the
/// num/str domain (`true < false` ⇒ E0004 runtime — TD-011 r24 law).
#[test]
fn neg_r162_ordering_domain_maintained() {
    run_err_contains("require io, write;\nprint(true < false);", "E0004");
}

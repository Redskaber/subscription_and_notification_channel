// E6 close-out (r154 / 224-b7): converted to the target-syntax face.
//! HM/typecheck .krf-path verification PoC integration tests (r74 /
//! 144-b — the [r74-window-opening §2] parity acceptance face).
//!
//! **Criterion**: the same-source program is judged identically on both
//! faces — the Rust oracle face (`hm_check_program` called directly — the
//! r80 / 150-b semantic re-anchor: the production judgment face has switched
//! to the check.krf path, so `check_source` no longer represents the Rust
//! face) vs the krf mini-inference face (`bootstrap/check.krf` run on the
//! VM through the `bootstrap::check` bridge). Parity granularity =
//! **accept/reject** (not message-verbatim — message-level parity is the
//! honest boundary of the production switch; the r74-window-opening §2
//! "not doing" registry criterion is maintained).
//!
//! Coverage (§9.4.3 positive:negative ratio ≥1:3):
//! - 4 positive: recursion (fib — recursion setup + if-branch join + the
//!   comparison family), let polymorphism (id doubly instantiated — value
//!   restriction generalized), a closure factory (make-adder — nested fn +
//!   a fresh instantiation chain), string total-order comparison (TD-011
//!   num-or-str letting an all-string chain through);
//! - 12 negative: an arithmetic string argument, a non-bool if condition,
//!   excess arity (user fn), a non-callable value (int application), a let
//!   binding type conflict, an assign unification conflict, not on a
//!   non-bool, head on a non-pair, mixed comparison (string + number), an
//!   error inside a module body, the eq arity upper bound, a string
//!   argument injected into a user fn;
//! - 2 protocol-face: perform/handle outside the subset → `Unsupported`
//!   (a structured skip — the honest-boundary carrier); diagnostic Spans
//!   land within the source bounds.
//!
//! Multi-error collection (r75/145-e — item-level recovery):
//! - 4 count-parity cases: two independent errors across items / three
//!   errors / two errors across module-body items / two errors in a
//!   top-level do splice (r49 D59: top-level do = module-level splice →
//!   independent errors between the two items — an empirically discovered
//!   prediction-failure-turned-parity-case) — equal counts on both faces +
//!   the `Diags` multi-error shape + source-order verification;
//! - 2 honest-boundary guards: multiple errors inside a nested application
//!   item (Rust constraint-level 3 vs local item-level 1) / a failed
//!   define absorbing subsequent calls (Rust two-phase 2 vs local
//!   single-pass 1) — the boundary is recorded as a guarded fact (the same
//!   pattern as r74 Unsupported).

use kerf_driver::bootstrap::check::{krf_check_program, KrfCheckOutcome};
use kerf_driver::builtins::builtin_sigs;
use kerf_driver::compile_source;

const FNAME: &str = "hm_krf_parity.ktf";

/// The krf mini judgment face: source → front-end artifacts → VM check.krf
/// judgment.
fn krf_check(src: &str) -> KrfCheckOutcome {
    let out = compile_source(src, FNAME).expect("pre-stage compile failed (case must be HM level)");
    krf_check_program(&out.core, &[], &out.table).expect("check.krf bridge internal error")
}

/// The Rust oracle judgment face (r80 semantic re-anchor:
/// `hm_check_program` called directly — after the production switch the
/// oracle no longer goes through `check_source`; diagnostic count =
/// constraint-level full drain).
fn oracle_hm_clean(src: &str) -> bool {
    let out = compile_source(src, FNAME).expect("pre-stage compile failed (case must be HM level)");
    let mut table = out.table;
    let sigs = builtin_sigs(&mut table);
    kerf_compiler::hm::hm_check_program(&out.core, &sigs, &table)
        .diags
        .is_empty()
}

/// Dual-face parity assertion: both faces agree with the expectation
/// (accept/reject judged alike).
fn assert_parity(src: &str, expect_clean: bool) {
    let rust_clean = oracle_hm_clean(src);
    assert_eq!(
        rust_clean, expect_clean,
        "Rust HM verdict differs from expectation(case classification error or production face regression): \n{}",
        src
    );
    let krf = krf_check(src);
    let krf_clean = krf == KrfCheckOutcome::Clean;
    assert_eq!(
        krf_clean, expect_clean,
        "krf mini verdict face and Rust verdict face divergence(parity broken): \n{}\nkrf result: {:?}",
        src, krf
    );
}

// ---------------------------------------------------------------------------
// Positive: both faces accept (4 cases)
// ---------------------------------------------------------------------------

/// Recursion setup + if-branch join + the comparison family + arithmetic
/// (the full fib shape).
#[test]
fn parity_fib_recursive_clean() {
    assert_parity(
        "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(10)",
        true,
    );
}

/// let/define value-restriction generalization: id doubly instantiated
/// polymorphically (int + str once each).
#[test]
fn parity_let_polymorphism_clean() {
    assert_parity("let id = || (x: T) { x };\ndo(id(1), id(\"s\"))", true);
}

/// Closure factory: nested fn + a fresh instantiation chain (the
/// make-adder shape).
#[test]
fn parity_closure_factory_clean() {
    assert_parity(
        "fn make_adder(n: i64) { || (x: i64) { x + n } }\nmake_adder(3)(4)",
        true,
    );
}

/// String total-order comparison (TD-011: an all-string chain joins the
/// comparison family — num-or-str lets it through).
#[test]
fn parity_string_ordering_clean() {
    assert_parity("let a = \"apple\";\na < \"banana\"", true);
}

// ---------------------------------------------------------------------------
// Negative: both faces reject (12 cases)
// ---------------------------------------------------------------------------

/// Arithmetic string argument (the num rule concretely fails on str).
#[test]
fn parity_arith_string_arg_reject() {
    assert_parity("1 + \"s\"", false);
}

/// Non-bool if condition (concrete int, immediate diagnostic).
#[test]
fn parity_if_cond_non_bool_reject() {
    assert_parity("if (1) { 2 } else { 3 }", false);
}

/// Excess arity on a user fn (arrow parameter-count mismatch).
#[test]
fn parity_user_fn_arity_reject() {
    assert_parity("fn f(x: T) { x }\nf(1, 2)", false);
}

/// Non-callable value (application of an int binding — the R6 face).
#[test]
fn parity_non_callable_reject() {
    assert_parity("let x = 5;\nx(1)", false);
}

/// let binding type conflict (bind-pattern RHS str flows into arithmetic).
#[test]
fn parity_let_type_conflict_reject() {
    assert_parity("(|| { let x = \"s\"; x + 1 })()", false);
}

/// assign unification conflict (D3: after the set! target's variable is
/// unified := str, arithmetic fails).
#[test]
fn parity_assign_unify_conflict_reject() {
    assert_parity("fn f(x: T) { x = \"s\"; x + 1 }\nf(1)", false);
}

/// not on a non-bool argument.
#[test]
fn parity_not_non_bool_reject() {
    assert_parity("not(5)", false);
}

/// head on a non-pair (the special re-interpretation face).
#[test]
fn parity_head_non_pair_reject() {
    assert_parity("head(5)", false);
}

/// Mixed comparison (string + number — not an all-string chain and the
/// string does not enter the numeric cell).
#[test]
fn parity_mixed_comparison_reject() {
    assert_parity("\"a\" < 1", false);
}

/// Type error inside a module body (item-level recursive propagation).
#[test]
fn parity_module_inner_error_reject() {
    assert_parity(
        "module m { import kerf_list; export f;\n    fn f(x: T) { x + \"s\" } }",
        false,
    );
}

/// eq arity upper bound (fixed 2 — a max_args violation).
#[test]
fn parity_eq_arity_upper_reject() {
    assert_parity("eq(1, 2, 3)", false);
}

/// A string argument injected into a user fn (arrow parameter
/// unification failure).
#[test]
fn parity_user_fn_arg_conflict_reject() {
    assert_parity("fn add(a: T, b: T) { a + b }\nadd(1, \"x\")", false);
}

// ---------------------------------------------------------------------------
// Protocol face: honest-boundary carriers (2 cases)
// ---------------------------------------------------------------------------

/// perform outside the subset → Unsupported (the effect face is outside
/// the PoC subset — a structured skip signal, not a failure). E6 conversion
/// note (r154 / 224-b7): the S-expr value-position perform
/// `(define x (perform 1))` converts to the target-face top-level perform
/// statement — the effect node reaches the judgment face identically (the
/// payload shape is irrelevant to the Unsupported outcome; perform is
/// statement-position-only on the target surface).
#[test]
fn protocol_perform_is_unsupported() {
    let krf = krf_check("perform stop(1);");
    assert_eq!(krf, KrfCheckOutcome::Unsupported("perform".into()));
}

/// handle outside the subset → Unsupported (same as above — the target
/// handle value form `handle e { A(p, k) => body }` in define-value
/// position; the binder names are target-legal idents — `resume` is a
/// target keyword and cannot be a binder name, so the arm binds `k`).
#[test]
fn protocol_handle_is_unsupported() {
    let krf = krf_check("let r = handle (42) { probe(payload, k) => { payload } };");
    assert_eq!(krf, KrfCheckOutcome::Unsupported("handle".into()));
}

/// Diagnostic Span lands within the source bounds (field integrity of the
/// bridge protocol — anchored by the first negative case).
#[test]
fn protocol_diag_span_within_source() {
    let src = "1 + \"s\"";
    let krf = krf_check(src);
    match krf {
        KrfCheckOutcome::Diag { start, end, .. } => {
            assert!(end > start, "Span empty range: {}..{}", start, end);
            assert!(
                (end as usize) <= src.len(),
                "Span out of bounds:{}..{}(source long {})",
                start,
                end,
                src.len()
            );
        }
        other => panic!("expected Diag, got {:?}", other),
    }
}

// ---------------------------------------------------------------------------
// Multi-error collection (r75/145-e — item-level recovery: count parity +
// honest-boundary guards)
// ---------------------------------------------------------------------------

/// Rust oracle diagnostic count (r80 semantic re-anchor: the multi-error
/// drain face — called directly).
fn oracle_hm_diag_count(src: &str) -> usize {
    let out = compile_source(src, FNAME).expect("pre-stage compile failed (case must be HM level)");
    let mut table = out.table;
    let sigs = builtin_sigs(&mut table);
    kerf_compiler::hm::hm_check_program(&out.core, &sigs, &table)
        .diags
        .len()
}

/// krf mini-face diagnostic count (Clean = 0 / Diag = 1 / Diags = len).
fn krf_diag_count(src: &str) -> usize {
    match krf_check(src) {
        KrfCheckOutcome::Clean => 0,
        KrfCheckOutcome::Diag { .. } => 1,
        KrfCheckOutcome::Diags { items } => items.len(),
        KrfCheckOutcome::Unsupported(_) => panic!("subset out of bounds non-multiple errors case"),
    }
}

/// Independent-error-count-across-items parity assertion (equal counts on
/// both faces — the achieved item-level-recovery face).
fn assert_multi_parity(src: &str, expect: usize) {
    let rust = oracle_hm_diag_count(src);
    assert_eq!(
        rust, expect,
        "Rust HM diagnostic count differs from expectation: \n{}",
        src
    );
    let krf = krf_diag_count(src);
    assert_eq!(
        krf, expect,
        "krf multiple errors count differs from expectation(item level recovery parity broken): \n{}\nkrf count: {}",
        src, krf
    );
}

/// Two independent errors across items: both faces count 2 + the Diags
/// multi-error shape + source order (reverse correctness).
#[test]
fn multi_parity_two_independent_items() {
    let src = "1 + \"s\"\nnot(5)";
    assert_multi_parity(src, 2);
    match krf_check(src) {
        KrfCheckOutcome::Diags { items } => {
            assert_eq!(items.len(), 2, "Diags payload count");
            assert!(
                items[0].start < items[1].start,
                "diagnostic non-source order(reverse missing): {}..{} should first at {}..{}",
                items[0].start,
                items[0].end,
                items[1].start,
                items[1].end
            );
            for it in &items {
                assert!(
                    it.end > it.start,
                    "Span empty range: {}..{}",
                    it.start,
                    it.end
                );
            }
        }
        other => panic!("expected Diags(multiple-error form), got {:?}", other),
    }
}

/// Three independent errors across items: both faces count 3 (accumulated
/// across three items in order — multi-level recovery-chain verification).
#[test]
fn multi_parity_three_independent_items() {
    assert_multi_parity("1 + \"s\"\nnot(5)\n\"a\" < 1", 3);
}

/// Two errors across module-body items: both faces count 2 (the module arm
/// shares tc-check-items — recovery semantics inherited and verified).
#[test]
fn multi_parity_module_inner_two_items() {
    // r164 / 235-c: import face switched kerf_list → kerf_string — the
    // kerf-list injection body's recursive definitions add oracle-face
    // conservative rows (occurs family, production-exempt) that break the
    // two-face COUNT parity this helper asserts; the test's intent (two
    // independent errors in a module's inner items, count parity) is
    // preserved on an injection-free import face.
    assert_multi_parity(
        "module m { import kerf_string; export f;\n    fn f(x: T) { x + \"s\" }\n    not(5) }",
        2,
    );
}

/// Two errors in a top-level do splice: both faces count 2 (r49 D59 —
/// top-level do = module-level splice, independent errors between the two
/// items; empirically discovered: a single do form with two errors was
/// predicted to be an intra-item boundary, but it is in fact two
/// independent errors between items — count parity achieved, the failed
/// prediction converted into a parity case).
#[test]
fn multi_parity_toplevel_do_splice() {
    assert_multi_parity("do(1 + \"s\", not(5))", 2);
}

/// r75 §5.3 axis-① boundary — **absorbed r126** (HM deepening window):
/// two failing sub-expressions inside one expression item — Rust
/// constraint-level full drain = 3; the within-item recovery (per-argument
/// rule continuation + Dynamic recovery + failed-subexpression arg
/// re-checking) now reaches the same 3 on the local face (oracle parity;
/// the r75-era guarded fact [local item-level first = 1] retired).
#[test]
fn boundary_intra_item_multi_diag_parity() {
    let src = "not(5) + (1 + \"s\")";
    assert_eq!(
        oracle_hm_diag_count(src),
        3,
        "Rust constraint level drain anchor (measured 3)"
    );
    assert_eq!(
        krf_diag_count(src),
        3,
        "r126 in-item recovery parity(3 = 3)"
    );
    assert!(
        matches!(krf_check(src), KrfCheckOutcome::Diags { .. }),
        "multi-item in-item errors → Diags multiple-error form(r75 add property wire protocol)"
    );
}

/// r75 §5.3 axis-② boundary — **absorbed r126** (HM deepening window):
/// a failed define no longer absorbs subsequent calls — the define still
/// binds (unresolved pre-bound variable → ∀α generalization, the oracle's
/// Poly observable), so the later (f 1 2) call site gets its own arity
/// diagnostic: Rust two-phase semantics = 2, the local face now = 2
/// (oracle parity; the r75-era guarded fact [single-pass absorption = 1]
/// retired).
#[test]
fn boundary_failed_define_call_absorption_parity() {
    let src = "fn f(x: T) { x + \"s\" }\nf(1, 2)";
    assert_eq!(
        oracle_hm_diag_count(src),
        2,
        "Rust two-stage semantics anchor(definition error + call-site arity error, measured 2)"
    );
    assert_eq!(
        krf_diag_count(src),
        2,
        "r126 failed define binding parity(2 = 2)"
    );
}

// ---------------------------------------------------------------------------
// r126 HM deepening window: within-item recovery family (the r75 §5.3
// dual-axis absorption acceptance face — per-argument rule continuation +
// Dynamic recovery + failed-define binding; positive:negative ≥1:3 within
// the family, count-parity caliber on both faces)
// ---------------------------------------------------------------------------

/// r126 positive: all violating arguments of one call collected (three
/// str arguments against the num rule — the continuation scans every
/// argument; both faces 3). E6 conversion note (r154 / 224-b7): the S-expr
/// 3-ary `(+ "a" "b" "c")` has no direct target-surface twin (`+` is the
/// binary operator token, not an identifier) — the chained binary form
/// compiles to the nested application `(+ (+ "a" "b") "c")` and the
/// recovery counts stay 3 on both faces (measured re-pin; the
/// all-violating-arguments anchor is preserved).
#[test]
fn r126_recovery_all_args_collected_parity() {
    assert_multi_parity("\"a\" + \"b\" + \"c\"", 3);
}

/// r126 positive: deep nesting — a failing sub-expression's recovery type
/// participates in the outer rule checks ((not 5) recovers as bool → the
/// enclosing + flags it too; both faces 4).
#[test]
fn r126_recovery_nested_deep_parity() {
    assert_multi_parity("(not(5) + \"x\") + \"y\"", 4);
}

/// r126 negative guard: a recorded cond violation does not cascade — the
/// branches are still inferred and clean branches add nothing (both faces
/// 1; over-reporting would break the krf ⊆ oracle contract).
#[test]
fn r126_recovery_no_cascade_if_cond() {
    assert_multi_parity("if (5) { 1 } else { 2 }", 1);
}

/// r126 negative guard: a failed define's subsequent clean reference does
/// not cascade — the ∀α unconstrained binding mirrors the oracle's Poly
/// observable ((f 1) instantiates fresh, no extra diagnostic; both faces
/// 1 = the define error only).
#[test]
fn r126_recovery_failed_define_reference_clean() {
    assert_multi_parity("fn f(x: T) { x + \"s\" }\nf(1)", 1);
}

/// r126 negative guard: clean items after an error item add nothing (the
/// recovery scope is within-item — no cross-item pollution; both faces 1).
#[test]
fn r126_recovery_clean_after_error_item() {
    assert_multi_parity("1 + \"s\"\n1 + 2", 1);
}

/// r126 protocol guard: a single within-item error keeps the r74
/// single-diagnostic wire shape ('diag — principle 27 additive protocol:
/// the multi-error 'diags shape only appears at ≥2).
#[test]
fn r126_recovery_single_error_shape_retained() {
    assert!(matches!(
        krf_check("1 + \"s\""),
        KrfCheckOutcome::Diag { .. }
    ));
}

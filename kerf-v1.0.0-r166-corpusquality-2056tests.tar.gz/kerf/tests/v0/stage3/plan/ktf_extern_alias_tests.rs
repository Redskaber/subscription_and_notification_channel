// E6 close-out (r154 / 224-c5): corpus converted to the target-syntax face.
//! .ktf extern-alias family tests — r147 / 217-c (the extern symbol-space
//! alias window: the declaration-site alias arm — ffi-language-surface
//! §7 last row clearance; design single source = extern-alias-design.md
//! v1.0).
//!
//! **Verification surfaces** (the target-face alias form
//! `extern NAME as ALIAS (kinds) -> kind;` — six-element Stx,
//! symbol-for-symbol isomorphic with the former S-expr canonical form;
//! zero new CoreExpr/ModuleItem/opcode variants — the IR extern_face
//! pair `(Symbol, Rc<str>)` already carries the source-level-name ≠
//! flat-FFI-name separation, principle 9):
//! (1) **run-face E2E** — the aliased call through the full production
//! chain and the Rust seed chain (the two-name split threads: the
//! reference matches by the local binding name, the emitted SymLit
//! carries the flat FFI space name — the registry/contract/capability/
//! runtime faces all keep matching by the underlying, D3);
//! (2) **the grammar settlement** — the alias arm is dual-Reader
//! verified: seed vs mirror canonical Stx rendering byte-identical
//! (including the spliced `as ALIAS` symbols and their span bytes),
//! error faces message + Span byte-identical;
//! (3) **cross-stage consumption** — the aliased program through
//! `check_source_recover` stays diagnostic-clean with real
//! artifacts (0 global refs — the local alias resolves through the flat
//! extern space, never the global registry);
//! (4) **fail-closed negatives** — the alias discipline family: the
//! replacement semantics (D4 — the aliased underlying direct reference =
//! E0022), the self-alias rejection (D5), the anti-shadowing extension
//! (D6 — local vs define/import/N1/other-extern visible names), the
//! capability gate through the alias (D7 — the underlying's token), the
//! contract/availability gates by the underlying (D3), the position
//! discipline (D2 — top-level only), the value-position rejection, and
//! the reader-level structure discipline (missing alias ident / non-ident
//! alias token / double alias / missing kind-list paren).
//!
//! E6 close-out (r154 / 224-c5): the S-expr face retired — the former
//! `.krf` production legs drive the Rust **seed chain**
//! (`run_source_seed` — the dual-path oracle surface, vm_tests'
//! dual_path precedent); the driver-level Stx-shape legs (form element
//! count / non-`as` keyword splice / non-symbol alias position) are
//! Read-stage pre-empted by the target grammar (the Reader fails closed
//! at the earliest point — c2's parity_err disposition) and are carried
//! by their target Reader twins with distinct token shapes (boundary
//! switches stage, semantics preserved — the c3 match_m2 precedent);
//! filenames `.krf` → `.ktf`; all message needles re-calibrated by
//! running.
//!
//! Skin-dictionary basis: 20 §14 (the thirteenth mapping family's alias
//! arm); 02 §8.13.1a v7.24 (the Level 0 production update). Window
//! basis: ffi-language-surface-design.md §7 last row + handle-expr-
//! position-design.md §7 last row (the r143 P5/P6 probe evidence —
//! E0019/E0022 symbol-space mechanism gap) + extern-alias-design.md
//! v1.0 (design single source) + t3plus-trigger-audit v1.67 (M1
//! user-instruction order — the fifty-second opening).
//! Ratio: 8 positive : 24 negative = 1:3 (§9.4.3).

use kerf_driver::bootstrap::reader::read_source_for_bootstrap;
use kerf_driver::{check_source_recover, run_source, run_source_seed};
use kerf_reader::reader::read_source;
use kerf_syntax::{Stx, StxDatum, StxLiteral, SymbolTable};

// ---------------------------------------------------------------------------
// Value helpers
// ---------------------------------------------------------------------------

fn run_value(src: &str, filename: &str) -> String {
    let outcome = run_source(src, filename)
        .unwrap_or_else(|e| panic!("target face program {} execution failed:{}", filename, e));
    kerf_vm::render_value(&outcome.value, &outcome.heap)
}

/// Seed-chain run (E6 close-out r154 / 224-c5: the S-expr face retired —
/// the former `.krf` production legs drive the Rust seed chain: seed
/// target Reader + seed expand + seed compile + VM, the dual-path
/// oracle surface of the production chain).
fn seed_value(src: &str, filename: &str) -> String {
    let outcome = run_source_seed(src, filename)
        .unwrap_or_else(|e| panic!("seed chain program {} execution failed:{}", filename, e));
    kerf_vm::render_value(&outcome.value, &outcome.heap)
}

// ---------------------------------------------------------------------------
// Dual-Reader parity helpers (the ktf_use_decl_tests.rs caliber —
// canonical rendering with Span bytes; error parity with message + Span
// byte equality)
// ---------------------------------------------------------------------------

fn render_stx(s: &Stx, t: &SymbolTable) -> String {
    let mut out = String::new();
    render_stx_into(s, t, &mut out);
    out
}

fn render_stx_into(s: &Stx, t: &SymbolTable, out: &mut String) {
    match &s.datum {
        StxDatum::Symbol(sym) => {
            out.push_str(&format!(
                "(sym {} {}..{})",
                t.name(*sym),
                s.span.start,
                s.span.end
            ));
        }
        StxDatum::Literal(l) => match l {
            StxLiteral::Int(v) => {
                out.push_str(&format!("(int {} {}..{})", v, s.span.start, s.span.end));
            }
            StxLiteral::Float(f) => {
                out.push_str(&format!("(float {:?} {}..{})", f, s.span.start, s.span.end));
            }
            StxLiteral::Str(r) => {
                out.push_str(&format!("(str {:?} {}..{})", r, s.span.start, s.span.end));
            }
            StxLiteral::Bool(b) => {
                out.push_str(&format!("(bool {} {}..{})", b, s.span.start, s.span.end));
            }
            StxLiteral::Nil => {
                out.push_str(&format!("(unit {}..{})", s.span.start, s.span.end));
            }
        },
        StxDatum::List(items) => {
            out.push_str(&format!("(lst {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
        StxDatum::Vector(items) => {
            out.push_str(&format!("(vec {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
    }
}

/// Grammar parity assertion: both Readers' canonical renderings are
/// byte-identical (the alias arm is seed/mirror isomorphic by
/// construction, including the spliced `as ALIAS` symbol nodes and their
/// span bytes — the import-as arm's r130 precedent caliber).
fn assert_grammar_parity(src: &str, what: &str) {
    let mut t1 = SymbolTable::new();
    let seed = read_source(src, 0, &mut t1)
        .unwrap_or_else(|e| panic!("[{}] seed syntax failed: {}", what, e.message));
    let mut t2 = SymbolTable::new();
    let mirror = read_source_for_bootstrap(src, 0, &mut t2)
        .unwrap_or_else(|e| panic!("[{}] mirror syntax failed:{}", what, e.message));
    assert_eq!(
        seed.len(),
        mirror.len(),
        "[{}] top-level item count mismatch (seed {} vs mirror {})",
        what,
        seed.len(),
        mirror.len()
    );
    for (i, (a, b)) in seed.iter().zip(mirror.iter()).enumerate() {
        assert_eq!(
            render_stx(a, &t1),
            render_stx(b, &t2),
            "[{}] top-level item #{} syntax tree mismatch (seed vs mirror canonical render)",
            what,
            i
        );
    }
}

/// Grammar-error parity assertion: message + Span byte-level equality.
fn assert_grammar_err_parity(src: &str, what: &str) {
    let mut t1 = SymbolTable::new();
    let seed_err = match read_source(src, 0, &mut t1) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] seed should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    let mut t2 = SymbolTable::new();
    let mirror_err = match read_source_for_bootstrap(src, 0, &mut t2) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] mirror should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    assert_eq!(
        seed_err.message, mirror_err.message,
        "[{}] syntax error message mismatch (seed {:?} vs mirror {:?})",
        what, seed_err.message, mirror_err.message
    );
    assert_eq!(
        seed_err.span.start, mirror_err.span.start,
        "[{}] syntax error Span start mismatch (seed {} vs mirror {})",
        what, seed_err.span.start, mirror_err.span.start
    );
    assert_eq!(
        seed_err.span.end, mirror_err.span.end,
        "[{}] syntax error Span end mismatch (seed {} vs mirror {})",
        what, seed_err.span.end, mirror_err.span.end
    );
}

// ---------------------------------------------------------------------------
// Positives — run-face E2E + grammar settlement + cross-stage consumption
// ---------------------------------------------------------------------------

/// Positive 1 / integration: the core E2E — the aliased extern call
/// through the full production chain and the Rust seed chain (the
/// two-name split's observable behavior: the `ws` reference resolves
/// through the extern face [Symbol(ws) → flat "write-stdout"], the
/// emitted SymLit carries the flat name, the runtime table matches by
/// the underlying — the window protocol's real host I/O round-trip ⇒ 9
/// on both chains).
#[test]
fn extern_alias_call_e2e_dual_face() {
    let v = run_value(
        "require io, write;\nextern write_stdout as ws(str) -> int;\nws(\"hello ffi\")",
        "ffi_alias.ktf",
    );
    assert_eq!(
        v, "9",
        "target face aliased extern call E2E(write(2) byte count -- actual: {})",
        v
    );
    let s = seed_value(
        "require io, write;\nextern write_stdout as ws(str) -> int;\nws(\"hello ffi\")",
        "ffi_alias_seed.ktf",
    );
    assert_eq!(s, "9", "seed chain aliased extern call E2E(actual: {})", s);
}

/// Positive 2 / integration: the aliased program through the **check
/// face** stays diagnostic-clean with real artifacts (cross-stage
/// consumption: the aliased call site's resolution never enters
/// global_refs — the local alias rides the flat extern space; the HM
/// check face sees an ordinary call → A4 Dynamic, zero diagnostics —
/// D8).
#[test]
fn extern_alias_check_cross_stage_clean() {
    let report = check_source_recover(
        "require io, write;\nextern write_stdout as ws(str) -> int;\nws(\"x\")",
        "clean.ktf",
    )
    .unwrap_or_else(|e| {
        panic!(
            "aliased extern program check not should failed:{}",
            e.rendered
        )
    });
    assert!(
        report.diagnostics.is_empty(),
        "aliased extern program check zero diagnostics (actual: {:?})",
        report
            .diagnostics
            .iter()
            .map(|d| d.message.clone())
            .collect::<Vec<_>>()
    );
    assert!(
        report.proto_count >= 1,
        "check artifact real(prototype count: {})",
        report.proto_count
    );
    assert_eq!(
        report.global_ref_count, 0,
        "aliased local name not input global_refs pool(actual: {})",
        report.global_ref_count
    );
}

/// Positive 3 / grammar: the dual-Reader canonical parity — the aliased
/// declaration form renders byte-identically from the seed and mirror
/// Readers (including the spliced `as ALIAS` symbol nodes + span bytes
/// and the shifted kind-list/ret positions).
#[test]
fn extern_alias_dual_reader_canonical_parity() {
    assert_grammar_parity("extern write_stdout as ws(str) -> int;", "alias-parity");
    assert_grammar_parity("extern write_stdout as ws() -> int;", "alias-empty-parity");
    assert_grammar_parity(
        "extern write_stdout as ws(str, str) -> int;",
        "alias-two-parity",
    );
}

/// Positive 4 / integration: the nested-context call — the aliased
/// extern call inside a fn body (the resolution is depth-independent:
/// the flat extern space is consulted after the lexical frames miss;
/// the local alias binding thread carries through the prototype frame).
#[test]
fn extern_alias_nested_fn_call_e2e() {
    let v = run_value(
        "require io, write;\nextern write_stdout as ws(str) -> int;\nfn f(m: T) { ws(m) }\nf(\"nested-ok\")",
        "nested.ktf",
    );
    assert_eq!(v, "9", "fn in body aliased extern call(actual: {})", v);
}

/// Positive 5 / integration: the mixed program — the aliased extern
/// declaration coexists with defines and unaliased extern usage patterns
/// (zero mutual interference: the local alias face and the define face
/// are disjoint — the D6 anti-shadowing gate passed at the front).
#[test]
fn extern_alias_mixed_program_e2e() {
    let v = seed_value(
        "require io, write;\nextern write_stdout as ws(str) -> int;\nfn pad(s: T) { s }\nws(pad(\"mix\")) + 1",
        "mixed.ktf",
    );
    assert_eq!(
        v, "4",
        "aliased extern + define mixed program(3 byte + 1 -- actual: {})",
        v
    );
}

/// Positive 6 / integration: the unaliased zero-regression — the
/// historical four-element form keeps the exact behavior (the identity
/// default local == name: the mathematical invariance of the unaliased
/// path, principle 27 additivity — production + seed chains E2E).
#[test]
fn extern_unaliased_zero_regression() {
    let v = run_value(
        "require io, write;\nextern write_stdout(str) -> int;\nwrite_stdout(\"hello ffi\")",
        "unaliased.ktf",
    );
    assert_eq!(
        v, "9",
        "unaliased target face zero-regression(actual: {})",
        v
    );
    let s = seed_value(
        "require io, write;\nextern write_stdout(str) -> int;\nwrite_stdout(\"hello ffi\")",
        "unaliased_seed.ktf",
    );
    assert_eq!(
        s, "9",
        "unaliased seed chain zero-regression(actual: {})",
        s
    );
}

/// Positive 7 / integration: the aliased call in operand position (the
/// CallExternal return feeds an enclosing expression — the A1
/// evaluation-order contract carries the arg value, the window-protocol
/// result lands in the enclosing operator's operand position).
#[test]
fn extern_alias_call_arg_position_e2e() {
    let v = run_value(
        "require io, write;\nextern write_stdout as ws(str) -> int;\n1 + ws(\"ab\")",
        "argpos.ktf",
    );
    assert_eq!(
        v, "3",
        "operand position aliased extern call(2 byte + 1 -- actual: {})",
        v
    );
}

/// Positive 8 / integration: the six-element aliased form through the
/// Rust seed chain (E6 close-out r154 / 224-c5: the S-expr Reader face
/// retired — the former canonical six-element `.krf` leg drives the
/// seed Reader + seed expand + seed compile chain; the driver's
/// collector consumes the same six-element `(extern ...)` Stx at the
/// same layer on both chains; the `as` literal symbol matched by name —
/// the import family's collect precedent).
#[test]
fn extern_alias_krf_face_production_e2e() {
    let v = seed_value(
        "require io, write;\nextern write_stdout as ws(str) -> int;\nws(\"s-expr\")",
        "krfprod.ktf",
    );
    assert_eq!(v, "6", "seed chain alias canonical form E2E(actual: {})", v);
}

// ---------------------------------------------------------------------------
// Negatives — the alias discipline family + reader structure (24
// families)
// ---------------------------------------------------------------------------

/// Negative 1: reader — `as` missing the alias identifier (the kind-list
/// `(` follows `as` directly).
#[test]
fn neg_alias_missing_ident_fail() {
    let e = run_source(
        "require io, write;\nextern write_stdout as (str) -> int;",
        "n1.ktf",
    )
    .expect_err("as missing alias identifier must rejected");
    assert!(
        e.rendered.contains("expected an alias identifier after as"),
        "as missing alias anchor(actual: {})",
        e.rendered
    );
}

/// Negative 2: reader — the alias position is a non-ident Token (an Int
/// literal).
#[test]
fn neg_alias_non_ident_fail() {
    let e = run_source(
        "require io, write;\nextern write_stdout as 5(str) -> int;",
        "n2.ktf",
    )
    .expect_err("alias position non-ident must rejected");
    assert!(
        e.rendered.contains("expected an alias identifier after as"),
        "alias non-ident anchor(actual: {})",
        e.rendered
    );
}

/// Negative 3: reader — the double alias (`as a as b` — the second `as`
/// lands in the kind-list position; the `(` expectation rejects it —
/// the import family's same law, D1 single-alias finalization).
#[test]
fn neg_alias_double_as_fail() {
    let e = run_source(
        "require io, write;\nextern write_stdout as a as b(str) -> int;",
        "n3.ktf",
    )
    .expect_err("double alias must rejected");
    assert!(
        e.rendered.contains("expected ("),
        "double alias anchor(the kind-list paren expectation -- actual: {})",
        e.rendered
    );
}

/// Negative 4: reader — the alias position holds a Path token (E6
/// close-out r154 / 224-c5: the S-expr five-element form (`(extern n as
/// (str) int)` → driver "exactly four elements"/"5 element") is
/// Read-stage pre-empted by the target grammar — the leg carries the
/// alias-slot domain-out with a distinct token shape: the flat extern
/// space is a bare-name domain, a qualified `a::b` Path is not an
/// alias; boundary switches stage, the alias-slot discipline semantics
/// preserved).
#[test]
fn neg_alias_sexpr_five_element_fail() {
    let e = run_source(
        "require io, write;\nextern write_stdout as kerf_io::x(str) -> int;",
        "n4.ktf",
    )
    .expect_err("path token alias position must rejected");
    assert!(
        e.rendered.contains("expected an alias identifier after as"),
        "alias path token anchor(actual: {})",
        e.rendered
    );
}

/// Negative 5: reader — the trailing-element form (E6 close-out r154 /
/// 224-c5: the S-expr seven-element form (`(extern n as w (str) int
/// extra)` → driver "exactly four elements"/"7 element") is Read-stage
/// pre-empted — the trailing token hits the mandatory-`;` expectation,
/// the declaration-family terminator discipline; boundary switches
/// stage, the extra-element rejection semantics preserved).
#[test]
fn neg_alias_sexpr_seven_element_fail() {
    let e = run_source(
        "require io, write;\nextern write_stdout as ws(str) -> int extra;",
        "n5.ktf",
    )
    .expect_err("trailing element aliased form must rejected");
    assert!(
        e.rendered.contains("expected ;"),
        "trailing element terminator anchor(actual: {})",
        e.rendered
    );
}

/// Negative 6: reader — a plain Ident in the splice slot where the
/// grammar demands `(` or `as` (E6 close-out r154 / 224-c5: the S-expr
/// six-element form's third position not being the literal `as` keyword
/// (`(extern n rebind w (str) int)` → driver "must be literal as
/// keyword") is Read-stage pre-empted — a non-`as` word after the name
/// hits the kind-list `(` expectation, the same single-alias
/// finalization law as the double-`as` form; boundary switches stage,
/// semantics preserved).
#[test]
fn neg_alias_sexpr_not_as_keyword_fail() {
    let e = run_source(
        "require io, write;\nextern write_stdout rebind ws(str) -> int;",
        "n6.ktf",
    )
    .expect_err("non-as splice word must rejected");
    assert!(
        e.rendered.contains("expected ("),
        "non-as splice anchor(actual: {})",
        e.rendered
    );
}

/// Negative 7: reader — the alias position is a Str literal (E6
/// close-out r154 / 224-c5: the S-expr Int-literal alias position
/// (`(extern n as 5 (str) int)` → driver "alias position must be
/// symbol") is Read-stage pre-empted — the leg carries the alias-slot
/// domain-out with a distinct token shape (a string literal, vs
/// Negative 2's Int and Negative 1's LParen); boundary switches stage,
/// the bare-name domain semantics preserved).
#[test]
fn neg_alias_sexpr_alias_not_symbol_fail() {
    let e = run_source(
        "require io, write;\nextern write_stdout as \"ws\"(str) -> int;",
        "n7.ktf",
    )
    .expect_err("alias position string literal must rejected");
    assert!(
        e.rendered.contains("expected an alias identifier after as"),
        "alias string literal anchor(actual: {})",
        e.rendered
    );
}

/// Negative 8: D5 — the self-alias rejection (`as`-name == the extern
/// symbol name: a silent no-op must fail closed, §2.3-4).
#[test]
fn neg_alias_self_alias_fail() {
    let e = run_source(
        "require io, write;\nextern write_stdout as write_stdout(str) -> int;",
        "n8.ktf",
    )
    .expect_err("self alias must rejected");
    assert!(
        e.rendered
            .contains("must differ from the extern symbol name"),
        "self alias anchor(actual: {})",
        e.rendered
    );
}

/// Negative 9: D6 — the local binding name duplicate (the second
/// declaration's unaliased name collides with the first's aliased local:
/// the visible flat symbol space cannot carry two entries of one name).
#[test]
fn neg_alias_local_duplicate_fail() {
    let e = run_source(
        "require io, write;\nextern write_stdout as ws(str) -> int;\nextern ws(str) -> int;",
        "n9.ktf",
    )
    .expect_err("local binding name duplicate must rejected");
    assert!(
        e.rendered.contains("local binding name") && e.rendered.contains("duplicate"),
        "local duplicate anchor(actual: {})",
        e.rendered
    );
}

/// Negative 10: D6 — the alias collides with the top-level define face.
#[test]
fn neg_alias_define_collision_fail() {
    let e = run_source(
        "require io, write;\nextern write_stdout as ws(str) -> int;\nfn ws(x: T) { x }",
        "n10.ktf",
    )
    .expect_err("alias vs define collision must rejected");
    assert!(
        e.rendered.contains("visible binding name collision"),
        "alias vs define collision anchor(actual: {})",
        e.rendered
    );
}

/// Negative 11: D6 — the alias collides with the import flat face (the
/// alias `string_length` duplicates an imported kerf-string member —
/// the whole-module import injects the kebab `string-length` into the
/// visible face through the Reader's symbol boundary).
#[test]
fn neg_alias_import_collision_fail() {
    let e = run_source(
        "import kerf_string;\nrequire io, write;\nextern write_stdout as string_length(str) -> int;",
        "n11.ktf",
    )
    .expect_err("alias vs import flat face collision must rejected");
    assert!(
        e.rendered.contains("visible binding name collision"),
        "alias vs import collision anchor(actual: {})",
        e.rendered
    );
}

/// Negative 12: D6 — the alias collides with the N1 core face (the `head`
/// operator name).
#[test]
fn neg_alias_n1_collision_fail() {
    let e = run_source(
        "require io, write;\nextern write_stdout as head(str) -> int;",
        "n12.ktf",
    )
    .expect_err("alias vs N1 core face collision must rejected");
    assert!(
        e.rendered.contains("visible binding name collision"),
        "alias vs N1 collision anchor(actual: {})",
        e.rendered
    );
}

/// Negative 13: D4 — the replacement semantics' reverse anchor (the
/// aliased underlying direct reference = the E0022 unbound-reference
/// family — the r134 member-rename D8 isomorph: the local replaces the
/// underlying in the visible face).
#[test]
fn neg_alias_replacement_underlying_e0022() {
    let e = run_source(
        "require io, write;\nextern write_stdout as ws(str) -> int;\nwrite_stdout(\"x\")",
        "n13.ktf",
    )
    .expect_err("the aliased underlying direct reference must E0022");
    assert!(
        e.rendered.contains("E0022") && e.rendered.contains("write-stdout"),
        "replacement reverse anchor(actual: {})",
        e.rendered
    );
}

/// Negative 14: D7 — the capability gate through the alias (the missing
/// require face: the gate fires on the UNDERLYING's write-capability
/// requirement — the alias shares the authorization token, r135 D13's
/// line; renaming creates no new capability face).
#[test]
fn neg_alias_capability_gate_e0006() {
    let e = run_source(
        "extern write_stdout as ws(str) -> int;\nws(\"x\")",
        "n14.ktf",
    )
    .expect_err("the aliased capability gate must fire by the underlying");
    assert!(
        e.rendered.contains("E0006") && e.rendered.contains("write-stdout"),
        "capability through alias anchor(actual: {})",
        e.rendered
    );
}

/// Negative 15: D3 — the contract mismatch through the alias (the
/// declared kinds must equal the registry row of the UNDERLYING — the
/// alias does not relax the host contract).
#[test]
fn neg_alias_contract_mismatch_fail() {
    let e = run_source(
        "require io, write;\nextern write_stdout as ws(int) -> int;",
        "n15.ktf",
    )
    .expect_err("the aliased contract mismatch must rejected");
    assert!(
        e.rendered.contains("contract mismatch"),
        "contract through alias anchor(actual: {})",
        e.rendered
    );
}

/// Negative 16: D3 — the availability by the underlying (an unregistered
/// name with an alias still reaches the E0012 registry gate — the alias
/// is never the registry key).
#[test]
fn neg_alias_availability_by_underlying_e0012() {
    let e = run_source("extern no_such_extern as ws(str) -> int;", "n16.ktf")
        .expect_err("the aliased unregistered underlying must E0012");
    assert!(
        e.rendered.contains("E0012") && e.rendered.contains("no-such-extern"),
        "availability by underlying anchor(actual: {})",
        e.rendered
    );
}

/// Negative 17: D2 — the position discipline with the alias (an aliased
/// extern inside a module body = the same E0026 position violation —
/// top-level only, 22 §15 D47).
#[test]
fn neg_alias_position_violation_fail() {
    let e = run_source(
        "module m { extern write_stdout as ws(str) -> int; }",
        "n17.ktf",
    )
    .expect_err("the aliased module-body position must rejected");
    assert!(
        e.rendered.contains("position violation"),
        "position with alias anchor(actual: {})",
        e.rendered
    );
}

/// Negative 18: the dual-Reader error-face parity — `as` missing the
/// alias identifier (message + Span byte-identical between the seed and
/// mirror Readers).
#[test]
fn neg_alias_err_parity_missing_ident() {
    assert_grammar_err_parity("extern write_stdout as (str) -> int;", "as-missing");
}

/// Negative 19: the dual-Reader error-face parity — the alias position
/// non-ident Token.
#[test]
fn neg_alias_err_parity_non_ident() {
    assert_grammar_err_parity("extern write_stdout as 5(str) -> int;", "as-non-ident");
}

/// Negative 20: the dual-Reader error-face parity — the alias present
/// but the kind-list paren missing (`ws str` — the `(` expectation).
#[test]
fn neg_alias_err_parity_missing_paren() {
    assert_grammar_err_parity("extern write_stdout as ws str -> int;", "as-missing-paren");
}

/// Negative 21: the aliased empty-parameter kind list reaches the
/// contract gate (the Unit dual form parses; the registry row of the
/// underlying demands (str) — the empty kind list is a contract
/// mismatch, proving the shape validation passed the aliased form).
#[test]
fn neg_alias_empty_params_contract_fail() {
    let e = run_source(
        "require io, write;\nextern write_stdout as ws() -> int;",
        "n21.ktf",
    )
    .expect_err("the aliased empty kind list must reach the contract gate");
    assert!(
        e.rendered.contains("contract mismatch"),
        "aliased empty kind list contract anchor(actual: {})",
        e.rendered
    );
}

/// Negative 22: the kind word outside the three-word vocabulary with the
/// alias.
#[test]
fn neg_alias_kind_word_domain_out() {
    let e = run_source(
        "require io, write;\nextern write_stdout as ws(float) -> int;",
        "n22.ktf",
    )
    .expect_err("the aliased kind word out of domain must rejected");
    assert!(
        e.rendered.contains("float") && e.rendered.contains("three words maximum"),
        "aliased kind word out of domain anchor(actual: {})",
        e.rendered
    );
}

/// Negative 23: the return kind word outside the vocabulary with the
/// alias.
#[test]
fn neg_alias_ret_kind_domain_out() {
    let e = run_source(
        "require io, write;\nextern write_stdout as ws(str) -> bool;",
        "n23.ktf",
    )
    .expect_err("the aliased return kind out of domain must rejected");
    assert!(
        e.rendered.contains("bool") && e.rendered.contains("out of domain"),
        "aliased return kind out of domain anchor(actual: {})",
        e.rendered
    );
}

/// Negative 24: the flat-space value-position rejection through the
/// alias (the aliased name in a define value slot = the call-position
/// only law — the flat FFI symbol space has no value form).
#[test]
fn neg_alias_value_position_fail() {
    let e = run_source(
        "require io, write;\nextern write_stdout as ws(str) -> int;\nlet f = ws;",
        "n24.ktf",
    )
    .expect_err("the aliased value-position reference must rejected");
    assert!(
        e.rendered.contains("call-position only"),
        "aliased value-position anchor(actual: {})",
        e.rendered
    );
}

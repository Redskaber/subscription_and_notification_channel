// E6 close-out (r154 / 224-b7): converted to the target-syntax face.
//! match implementation batch M-1 — Reader arm tests (r121 / 191-a).
//!
//! **Verification surfaces**: (1) intermediate-form structural correctness —
//! the arm-structure direct mapping `(match scrut (pattern [guard] body) ...)`
//! (match-design.md v1.1 §3.0 — the M-2 desugar consumer contract); (2)
//! pattern-grammar domain coverage (literals / binding / wildcard / pair
//! destructuring / grouping / or-marker / nil skin) with the r121 EBNF
//! redundancy ruling; (3) **intermediate-form golden rendering** (E6
//! conversion, r154 / 224-b7: the cross-syntax Stx parity gate — target
//! Reader vs the S-expr Reader — lost its second Reader with the S-expr
//! surface deletion [s-expr-removal-plan §4 E6]; the corpus keeps asserting
//! the S-expr intermediate-form rendering as the golden string, so the
//! desugar consumer contract is unchanged; the seed↔mirror Reader parity
//! face is carried by match_m4_krf_mirror_tests); (4) fail-closed negatives
//! (empty arms / ternary pair / or mixups / depth cap 8 / qualified-name
//! pattern / missing separators); (5) staging boundary anchors (the .krf
//! mirror divergence window — M-4 closes it; the front-end pseudo-application
//! pass-through — M-2 dissolves it).
//!
//! Basis: match-design.md v1.0 §2 (EBNF authority — 02 §8.13.1a r121
//! addition) / principle 31 (skin/skeleton isomorphism) / principle 43
//! (progressive disclosure — M-1..M-4 batch discipline, red line 4: no
//! window merging) / 22 §27 (qualified-name patterns out of domain).

use kerf_compiler::compile_module;
use kerf_driver::bootstrap::expander::expand_program;
use kerf_driver::bootstrap::reader::read_source_for_bootstrap;
use kerf_expander::{expand_program as expand_program_seed, ExpandCtxt};
use kerf_reader::read_source;
use kerf_syntax::{Stx, StxDatum, StxLiteral, SymbolTable};

// ---------------------------------------------------------------------------
// Infrastructure: datum-level canonical rendering (span-free — the
// cross-text comparison domain; symbol names resolved per-table)
// ---------------------------------------------------------------------------

fn render_datum(s: &Stx, t: &SymbolTable) -> String {
    match &s.datum {
        StxDatum::Symbol(sym) => t.name(*sym).to_string(),
        StxDatum::Literal(l) => match l {
            StxLiteral::Int(v) => v.to_string(),
            StxLiteral::Float(f) => format!("{:?}", f),
            StxLiteral::Str(r) => format!("{:?}", r),
            StxLiteral::Bool(b) => b.to_string(),
            StxLiteral::Nil => "()".to_string(),
        },
        StxDatum::List(items) => {
            let inner: Vec<String> = items.iter().map(|i| render_datum(i, t)).collect();
            format!("({})", inner.join(" "))
        }
        StxDatum::Vector(_) => "(vector)".to_string(),
    }
}

fn target_forms(src: &str, what: &str) -> (Vec<Stx>, SymbolTable) {
    let mut t = SymbolTable::new();
    let forms = read_source(src, 0, &mut t)
        .unwrap_or_else(|e| panic!("[{}] target syntax read failed:{}", what, e.message));
    (forms, t)
}

/// Intermediate-form golden rendering (E6 conversion of the M-1
/// cross-syntax parity gate, r154 / 224-b7): the target match surface
/// renders at the datum level byte-identically to the registered S-expr
/// intermediate-form spec string — the desugar consumer contract. The
/// retired leg: the S-expr Reader re-read of the spec text (no S-expr
/// Reader since E6 — s-expr-removal-plan §6 exit condition 2); the
/// Reader-pair parity face lives on in match_m4_krf_mirror_tests (seed
/// Reader ↔ bootstrap mirror).
fn assert_intermediate_form_golden(target_src: &str, golden: &str, what: &str) {
    let (forms, t) = target_forms(target_src, what);
    assert_eq!(forms.len(), 1, "[{}] top-level form count mismatch", what);
    assert_eq!(
        render_datum(&forms[0], &t),
        golden,
        "[{}] intermediate form golden rendering mismatch (match corpus family)",
        what
    );
}

fn target_err(src: &str, what: &str) -> String {
    match read_source(src, 0, &mut SymbolTable::new()) {
        Err(e) => e.message,
        Ok(_) => panic!(
            "[{}] should be a read error (actually parsed successfully)",
            what
        ),
    }
}

// ---------------------------------------------------------------------------
// (1) Intermediate-form structural correctness (arm-structure direct mapping)
// ---------------------------------------------------------------------------

#[test]
fn match_basic_arms_structure() {
    let (forms, t) = target_forms(
        "fn f(x: i64) -> i64 { match x { 0 => 1, _ => 9 } }\nf(3)",
        "basic arm structure",
    );
    assert_eq!(
        render_datum(&forms[0], &t),
        "(define (f x) (match x (0 1) (_ 9)))"
    );
    assert_eq!(render_datum(&forms[1], &t), "(f 3)");

    // Arm shape contract: 2 elements = (pattern body), 3 = (pattern guard body).
    let (forms, t) = target_forms(
        "fn g(x: i64) -> i64 { match x { 0 => 1, n => n + 1, _ => 9 } }",
        "three-element arm mixing",
    );
    assert_eq!(
        render_datum(&forms[0], &t),
        "(define (g x) (match x (0 1) (n (+ n 1)) (_ 9)))"
    );
}

#[test]
fn match_guard_arm_structure() {
    // Guard arm: the arm carries the guard expression in the middle slot.
    let (forms, t) = target_forms(
        "fn f(x: i64) -> i64 { match x { 0 => 0, n if n < 0 => 0 - 1, _ => 9 } }",
        "guard arm",
    );
    assert_eq!(
        render_datum(&forms[0], &t),
        "(define (f x) (match x (0 0) (n (< n 0) (- 0 1)) (_ 9)))"
    );

    // Two guards mixed with unguarded arms (order preserved).
    let (forms, t) = target_forms(
        "fn g(x: i64) -> i64 { match x { n if x < n => 1, 5 => 2, n if n < x => 3 } }",
        "dual guard order preserved",
    );
    assert_eq!(
        render_datum(&forms[0], &t),
        "(define (g x) (match x (n (< x n) 1) (5 2) (n (< n x) 3)))"
    );
}

#[test]
fn match_pattern_forms_structure() {
    // The full pattern-atom family in one program (pair / grouped / or / nil /
    // float / string / bool literals).
    let (forms, t) = target_forms(
        "match p {\n    (a, b) => a,\n    ((0 | 1), c) => c,\n    (x) => x,\n    () => 7,\n    1.5 => 8,\n    \"s\" => 9,\n    true => 1,\n    false => 2\n}",
        "pattern atomic all family",
    );
    assert_eq!(
        render_datum(&forms[0], &t),
        "(match p ((a b) a) (((or 0 1) c) c) (x x) (() 7) (1.5 8) (\"s\" 9) (true 1) (false 2))"
    );

    // Bare or-pattern at arm level (no parens) + three alternatives.
    let (forms, t) = target_forms(
        "match x { 0 | 1 | 2 => 10, _ => 20 }",
        "bare or three-way select",
    );
    assert_eq!(
        render_datum(&forms[0], &t),
        "(match x ((or 0 1 2) 10) (_ 20))"
    );

    // Left-nested pair + paren-wrapped right nesting (the r121 EBNF-letter
    // ruling: rest = pattern_atom, paren-wrapped nesting grammatical).
    let (forms, t) = target_forms(
        "match q { ((a, b), c) => a, (a, (b, c)) => b }",
        "left right nested pair",
    );
    assert_eq!(
        render_datum(&forms[0], &t),
        "(match q (((a b) c) a) ((a (b c)) b))"
    );

    // Skin-dictionary naming mapping applies in pattern position (my_var →
    // my-var; the bare `_` wildcard identity preserved — 20 §14 r109 entry).
    let (forms, t) = target_forms(
        "match x { my_var => my_var, _ => 0 }",
        "pattern position naming map",
    );
    assert_eq!(
        render_datum(&forms[0], &t),
        "(match x (my-var my-var) (_ 0))"
    );
}

// ---------------------------------------------------------------------------
// (2) Positional forms (statement / tail expression / expression position)
// ---------------------------------------------------------------------------

#[test]
fn match_positional_forms() {
    // Statement position (non-tail, value discarded → do-threaded).
    let (forms, t) = target_forms(
        "fn h(y: i64) -> i64 { match y { 0 => 1, _ => 2 }; 42 }",
        "statement position(dropped value)",
    );
    let rendered = render_datum(&forms[0], &t);
    assert!(
        rendered.starts_with("(define (h y) (do (match y (0 1) (_ 2)) 42))"),
        "statement position should do threading: {}",
        rendered
    );

    // Tail expression position (block value).
    let (forms, t) = target_forms(
        "fn h(y: i64) -> i64 { match y { 0 => 1, _ => 2 } }",
        "block-tail expression position",
    );
    assert_eq!(
        render_datum(&forms[0], &t),
        "(define (h y) (match y (0 1) (_ 2)))"
    );

    // Expression position (the r110 expression-position if precedent,
    // isomorphic dispatch — let RHS).
    let (forms, t) = target_forms(
        "fn g(y: i64) -> i64 { let x = match y { 0 => 1, _ => 2 }; x + 1 }",
        "expression position(let right value)",
    );
    assert_eq!(
        render_datum(&forms[0], &t),
        "(define (g y) (let ((x (match y (0 1) (_ 2)))) (+ x 1)))"
    );

    // Top-level match item.
    let (forms, t) = target_forms("match 1 { 0 => 1, _ => 2 }", "top-level position");
    assert_eq!(render_datum(&forms[0], &t), "(match 1 (0 1) (_ 2))");

    // Match scrutinee as a full expression (call + operator precedence).
    let (forms, t) = target_forms("match f(x) + 1 { 0 => 1, _ => 2 }", "scrutinee expression");
    assert_eq!(
        render_datum(&forms[0], &t),
        "(match (+ (f x) 1) (0 1) (_ 2))"
    );
}

// ---------------------------------------------------------------------------
// (3) Comma discipline (trailing comma optional; separators mandatory)
// ---------------------------------------------------------------------------

#[test]
fn match_comma_discipline() {
    // Trailing comma present and absent both parse (EBNF: trailing arm comma optional).
    for (src, label) in [
        ("match x { 0 => 1, _ => 2 }", "no trailing comma"),
        ("match x { 0 => 1, _ => 2, }", "has trailing comma"),
        ("match x { 0 => 1,\n           _ => 2 }", "cross-line arm"),
    ] {
        let (forms, t) = target_forms(src, label);
        assert_eq!(
            render_datum(&forms[0], &t),
            "(match x (0 1) (_ 2))",
            "[{}] arm structure should consistent",
            label
        );
    }
    // Missing inter-arm separator fails closed.
    let msg = target_err("match x { 0 => 1 _ => 2 }", "missing arm separator");
    assert!(
        msg.contains("expected , or }"),
        "missing arm separator diagnostic face: {}",
        msg
    );
}

// ---------------------------------------------------------------------------
// (4) Fail-closed negatives (pattern domain boundary)
// ---------------------------------------------------------------------------

#[test]
fn match_fail_closed_pattern_domain() {
    // Zero arms.
    assert!(
        target_err("match x { }", "zero arms").contains("match expression needs at least one arm")
    );
    // Ternary comma pattern (at most binary).
    assert!(
        target_err("match x { (a, b, c) => 1 }", "three-element pattern")
            .contains("at most two elements")
    );
    // Bare or + comma mixup (arm level — parenthesization hint).
    assert!(
        target_err("match x { 0 | 1, 2 => 1 }", "bare or mixed comma")
            .contains("please parenthesize")
    );
    // Or + pair mixup inside parens.
    assert!(target_err(
        "match x { (0 | 1, 2) => 1 }",
        "inside parentheses or mixed comma"
    )
    .contains("please parenthesize"));
    // Or in the pair rest slot.
    assert!(
        target_err("match x { (a, b | c) => 1 }", "right element or")
            .contains("pair destructuring right element does not support or pattern")
    );
    // Qualified-name pattern (22 §27 — no path form in pattern position).
    assert!(
        target_err("match x { a::b => 1 }", "qualified name pattern").contains("out of domain")
    );
    // Missing fat arrow.
    assert!(target_err("match x { 0 1 }", "missing =>").contains("expected =>"));
    // Unclosed braces (EOF).
    assert!(target_err("match x { 0 => 1", "unclosed").contains("expected }"));
    // Non-pattern token in pattern position.
    assert!(target_err("match x { => 1 }", "non-pattern Token").contains("expected a pattern"));
}

#[test]
fn match_pattern_depth_cap_boundary() {
    // Depth 8 legal (8 nested parens around a binary pair).
    let (forms, t) = target_forms("match x { ((((((((a, b)))))))) => 1 }", "depth 8 legal");
    assert_eq!(render_datum(&forms[0], &t), "(match x ((a b) 1))");
    // Depth 9 rejected (match-design.md §1 defensive cap — depth > 8 domain-out).
    assert!(
        target_err("match x { ((((((((((a, b))))))))) => 1 }", "depth 9")
            .contains("pattern nesting depth exceeds the limit 8")
    );
    // The cap applies to or-alternative atoms too (parenthesized depth).
    assert!(
        target_err("match x { ((((((((((0 | 1))))))))) => 1 }", "or depth 9")
            .contains("pattern nesting depth exceeds the limit 8")
    );
}

// ---------------------------------------------------------------------------
// (5) Intermediate-form golden rendering — the match corpus family (E6
// conversion of the M-1 cross-syntax acceptance gate: the S-expr spec text
// is asserted as the golden rendering of the target Reader's product)
// ---------------------------------------------------------------------------

#[test]
fn match_intermediate_form_golden_rendering() {
    // Basic family (two forms: fn decl + application).
    let (forms, t) = target_forms(
        "fn f(x: i64) -> i64 { match x { 0 => 1, _ => 9 } }\nf(3)",
        "basic family",
    );
    assert_eq!(
        render_datum(&forms[0], &t),
        "(define (f x) (match x (0 1) (_ 9)))"
    );
    assert_eq!(render_datum(&forms[1], &t), "(f 3)");
    assert_intermediate_form_golden(
        "fn f(x: i64) -> i64 { match x { 0 => 0, n if n < 0 => 0 - 1, _ => 9 } }",
        "(define (f x) (match x (0 0) (n (< n 0) (- 0 1)) (_ 9)))",
        "guard family",
    );
    assert_intermediate_form_golden(
        "match p { (a, b) => a, ((0 | 1), c) => c, () => 7, 1.5 => 8, \"s\" => 9, true => 1 }",
        "(match p ((a b) a) (((or 0 1) c) c) (() 7) (1.5 8) (\"s\" 9) (true 1))",
        "full pattern family",
    );
    assert_intermediate_form_golden(
        "match x { 0 | 1 | 2 => 10, _ => 20 }",
        "(match x ((or 0 1 2) 10) (_ 20))",
        "or tag family",
    );
    assert_intermediate_form_golden(
        "fn g(y: i64) -> i64 { let x = match y { 0 => 1, _ => 2 }; x + 1 }",
        "(define (g y) (let ((x (match y (0 1) (_ 2)))) (+ x 1)))",
        "expression position family",
    );
    assert_intermediate_form_golden(
        "match q { ((a, b), c) => a, (a, (b, c)) => b }",
        "(match q (((a b) c) a) ((a (b c)) b))",
        "nested pair family",
    );
    // The naming-mapping face: target my_var renders as the my-var symbol
    // in patterns and bodies (the r109 skin-dictionary entry).
    assert_intermediate_form_golden(
        "match x { my_var => my_var, _ => 0 }",
        "(match x (my-var my-var) (_ 0))",
        "naming map family",
    );
}

// ---------------------------------------------------------------------------
// (6) Staging boundary anchors (honest-boundary registration — r121 / 191-a)
// ---------------------------------------------------------------------------

/// Dual-side target-Reader divergence window — **CLOSED by M-4** (r124 /
/// 194-a): the seed Reader (r121) and the .krf mirror (the bootstrap
/// grammar, r108 + the r124 match arm) now both parse the match domain.
/// The anchor flipped with the closing batch (match-design.md §6 batch
/// table): the mirror's intermediate form renders byte-identically to the
/// seed's (the divergence window M-1..M-3 is closed).
#[test]
fn match_krf_mirror_divergence_window_anchor() {
    let src = "fn f(x: i64) -> i64 { match x { 0 => 1, _ => 2 } }";
    // Seed side: parses (the M-1 in-position re-judgment).
    let (forms, t) = target_forms(src, "seed side open domain");
    assert_eq!(
        render_datum(&forms[0], &t),
        "(define (f x) (match x (0 1) (_ 2)))"
    );
    // Mirror side: parses identically (M-4 closed the window — the
    // bootstrap grammar path carries the match domain).
    let mut mt = SymbolTable::new();
    let mirror = read_source_for_bootstrap(src, 0, &mut mt)
        .unwrap_or_else(|e| panic!("mirror side should parse match(M-4 landed): {}", e.message));
    assert_eq!(
        render_datum(&mirror[0], &mt),
        "(define (f x) (match x (0 1) (_ 2)))"
    );
}

/// Front-end pass-through boundary — DISSOLVED by M-2 (r122 / 192-a): the
/// intermediate form no longer flows through expansion as a pseudo-
/// application. Both expansion paths (seed and bootstrap — dual-path
/// consistent) now run the D2 seventh skin-dictionary desugar: the compiled
/// global-reference face carries no `match` entry and the program executes
/// through the VM returning the arm value (the r121 registered failure
/// point — the runtime unbound-global `match` diagnostic — is gone).
#[test]
fn match_frontend_pass_through_boundary() {
    let src = "fn f(x: i64) -> i64 { match x { 0 => 1, _ => 2 } }";
    let (forms, t) = target_forms(src, "frontend boundary");
    // Seed expansion path: the desugar product compiles with no `match`
    // global reference (the pseudo-application signature is gone).
    let mut ectx = ExpandCtxt::new(t);
    let core = expand_program_seed(&forms, &mut ectx)
        .unwrap_or_else(|e| panic!("seed expansion not should failed:{}", e.message));
    let program =
        compile_module(&core).unwrap_or_else(|e| panic!("compile not should failed:{}", e.message));
    for g in &program.global_refs {
        assert_ne!(
            ectx.table.name(*g),
            "match",
            "desugared products must not reference globals match(pseudo-application signature residue -- M-2 not landed?)"
        );
    }
    // Bootstrap expansion path (dual-path consistency on the same form).
    let mut t2 = SymbolTable::new();
    let forms2 =
        read_source(src, 0, &mut t2).unwrap_or_else(|e| panic!("re-read failed: {}", e.message));
    expand_program(&forms2, 0, &mut t2).unwrap_or_else(|e| {
        panic!(
            "bootstrap expansion not should failed(M-2 desugar dual paths agree): {}",
            e.message
        )
    });
}

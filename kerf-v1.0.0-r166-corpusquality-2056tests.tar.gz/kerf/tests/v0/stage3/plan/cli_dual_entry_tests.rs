//! CLI dual-entry (two-Reader coexistence period) tests — r125 / 195-a.
//!
//! **Verification surfaces** (switch-window-plan v1.9 §4 domain-registered
//! row "CLI dual entry (P3 design candidate) — the two-Reader coexistence
//! period entry form" discharged): (1) **cross-syntax behavioral
//! equivalence** — the same fib program written in the target syntax,
//! entered through the target-syntax entries (`run_source_target` /
//! `check_source_target_recover` / `test_runner::run_target`), executes
//! through the full production chain (target-Reader bridge → bootstrap
//! Expander → bootstrap Compiler → VM) with the same value as the S-expr
//! face (principle 31 skin/skeleton isomorphism at the CLI boundary);
//! (2) **default-face zero regression** — anything other than an exact
//! `.ktf` extension keeps the S-expression path verbatim (principle 27
//! additive evolution: the new entry is additive, the default face is
//! untouched); (3) **driver-API orthogonality** — the syntax choice lives
//! at the CLI dispatch layer; each driver API keeps its own read semantics
//! regardless of the filename label (the filename is a Span tag, not a
//! dispatch input); (4) **fail-closed negatives** — S-expr source under
//! the target entry, lexical/grammar errors, domain-registered
//! out-of-scope constructs (`use`), expand diagnostics, HM type
//! diagnostics, runtime type errors, recovery-mode multi-error collection.
//!
//! Cache ruling anchor: every target-syntax entry is cache-free (same
//! basis as `compile_front_target` — the B11/P4 kind-tag bucket has no
//! syntax dimension; `cache_hit` stays false on the target check face).
//!
//! Basis: switch-window-plan v1.9 §4 (domain-registered row discharged) /
//! r124 close-out recommendation (CLI dual entry = recommended-sequence
//! first item) / principle 27 (additive evolution) / principle 31
//! (skin/skeleton isomorphism) / §9.4.3 (positive:negative ≥ 1:3) / §11
//! (interface isolation — CLI forwards, driver holds the pipeline).

use kerf_driver::bootstrap::test_runner;
use kerf_driver::{
    check_source_recover, check_source_target_recover, dump_stx_target, dump_tokens_target,
    run_source, run_source_target,
};

/// The fib program in the target syntax (the r107/r108 grammar subset —
/// fn declaration with a stripped-after-parse type/effect signature; the
/// same corpus shape as target_reader_tests).
const TARGET_FIB: &str =
    "fn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nfib(12)";

/// The same fib program in the S-expression syntax (behavioral parity
/// counterpart of [`TARGET_FIB`]).
const SEXP_FIB: &str = "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2)))))\n(fib 12)";

// ---------------------------------------------------------------------------
// Positives — cross-syntax behavioral equivalence + default-face anchor
// ---------------------------------------------------------------------------

/// Positive 1 / integration / cross-stage consumption: the target-syntax
/// fib program through `run_source_target` (target-Reader bridge →
/// bootstrap Expander → bootstrap Compiler → VM) yields the same program
/// value as the S-expression face (`run_source`) — cross-syntax
/// behavioral equivalence at the CLI run boundary.
#[test]
fn target_fib_run_e2e_cross_syntax_value_parity() {
    let target_outcome = run_source_target(TARGET_FIB, "fib.ktf")
        .unwrap_or_else(|e| panic!("target syntax fib execution failed:{}", e));
    let target_value = kerf_vm::render_value(&target_outcome.value, &target_outcome.heap);
    let sexp_outcome = run_source(SEXP_FIB, "fib.krf")
        .unwrap_or_else(|e| panic!("S expression fib execution failed:{}", e));
    let sexp_value = kerf_vm::render_value(&sexp_outcome.value, &sexp_outcome.heap);
    assert_eq!(target_value, "144", "target syntax fib(12) program value");
    assert_eq!(
        target_value, sexp_value,
        "cross-syntax line is equivalent: dual entry program value must consistent(principle 31 skin/skeleton isomorphic)"
    );
}

/// Positive 2 / integration: the target-syntax check face
/// (`check_source_target_recover`) — zero diagnostics for a well-formed
/// target program, non-empty instruction artifacts, cache-free basis, and
/// the dump faces (`dump_stx_target` / `dump_tokens_target`) render the
/// target surface (one case carries the dump positives).
#[test]
fn target_check_ok_and_dump_faces() {
    let report = check_source_target_recover(TARGET_FIB, "fib.ktf")
        .unwrap_or_else(|e| panic!("target syntax check failed:{}", e));
    assert!(
        report.diagnostics.is_empty(),
        "well-formed goal program zero diagnostics (actual: {:?})",
        report.rendered
    );
    assert!(
        report.instruction_count > 0,
        "check artifact instruction count > 0(actual {})",
        report.instruction_count
    );
    assert!(
        report.proto_count > 0,
        "check artifact prototype count > 0(actual {})",
        report.proto_count
    );
    assert!(
        !report.cache_hit,
        "target syntax entry cache-free basis(B11/P4 no syntax dimension -- cache_hit always false)"
    );
    let stx = dump_stx_target(TARGET_FIB, "fib.ktf")
        .unwrap_or_else(|e| panic!("target syntax stx dump failed:{}", e));
    assert!(
        stx.contains("fib"),
        "stx dump render containing fib symbol face"
    );
    let toks = dump_tokens_target(TARGET_FIB, "fib.ktf")
        .unwrap_or_else(|e| panic!("target syntax tokens dump failed:{}", e));
    assert!(
        toks.contains("fn"),
        "tokens dump render containing goal keyword face fn(actual: \n{})",
        toks
    );
    assert!(
        toks.contains("int"),
        "tokens dump render containing literal family face int"
    );
}

/// Positive 3 / integration: the target-syntax test face
/// (`test_runner::run_target`) — a `fn` declaration lands in the prelude
/// bucket (ModuleItem::Define — syntax-neutral splitting), a top-level
/// `==` comparison expression is the case (the target `a == b` desugars
/// to `(= a b)` — the assertion predicate), and the case passes.
#[test]
fn target_test_runner_case_pass() {
    let src = "fn double(n: i64) -> i64 { n + n }\ndouble(5) == 10";
    let report = test_runner::run_target(src, "double.ktf")
        .unwrap_or_else(|e| panic!("target syntax test execution failed:{}", e));
    assert_eq!(
        report.cases.len(),
        1,
        "fn declaration goes into the pre-bucket, top level expression is sole use case"
    );
    assert!(
        report.cases[0].pass,
        "target syntax cases must pass(detail: {})",
        report.cases[0].detail
    );
    assert!(report.all_passed(), "all cases pass");
}

/// Positive 4 / default-face zero-regression anchor: S-expression source
/// under a non-`.ktf` filename (no extension / unknown extension) keeps
/// the existing S-expression path verbatim — the dual entry is additive
/// (principle 27), the default face is untouched.
#[test]
fn non_ktf_extension_keeps_sexp_path() {
    for name in ["prog", "prog.txt", "prog.krf"] {
        let outcome = run_source("(+ 1 1)", name).unwrap_or_else(|e| {
            panic!("{}: S expression default face execution failed:{}", name, e)
        });
        let value = kerf_vm::render_value(&outcome.value, &outcome.heap);
        assert_eq!(value, "2", "{}: default face program value", name);
    }
}

// ---------------------------------------------------------------------------
// Negatives — fail-closed family (13 cases)
// ---------------------------------------------------------------------------

/// Negative 1: S-expression source text entered through the
/// target-syntax entry is rejected at the read stage (fail-closed — the
/// target Reader does not silently accept the other skin).
#[test]
fn sexpr_source_in_target_entry_rejected() {
    let err = run_source_target("(+ 1 2)", "x.ktf")
        .expect_err("S expression source via goal entry must read-stage rejection(fail-closed)");
    let msg = err.to_string();
    assert!(
        !msg.is_empty(),
        "structured error message non-empty(goal Reader out of domain/syntax rejection)"
    );
}

/// Negative 2: unclosed string literal — lexical-level failure through
/// the target entry (the lexical level is not form-level recoverable).
#[test]
fn unclosed_string_lexical_fail() {
    assert!(
        run_source_target("\"abc", "bad.ktf").is_err(),
        "unclosed string must lexical failed"
    );
}

/// Negative 3: unclosed delimiter — grammar-level failure through the
/// target entry.
#[test]
fn unclosed_brace_grammar_fail() {
    assert!(
        run_source_target("fn f() { 1", "bad.ktf").is_err(),
        "unclosed brace must syntax failed"
    );
}

/// Negative 4: unbound reference — the compile-stage resolution
/// (E0022, N1/N2/N3 three-face query) fails closed and short-circuits
/// the recovery path (whole-program in nature — the documented
/// short-circuit boundary of `check_recover_from_forms`: recovery covers
/// expand-stage errors; compile errors short-circuit). Behavioral anchor
/// for the target face: the diagnostic message names the symbol.
#[test]
fn unbound_reference_compile_shortcircuit() {
    let err = check_source_target_recover("undefined_a(1)", "bad.ktf")
        .expect_err("unbound reference = compile-time E0022 resolution, whole-program short-circuit(non-recovery collection face)");
    let msg = err.to_string();
    assert!(
        msg.contains("undefined_a") || msg.contains("unbound reference"),
        "diagnostic must name symbol/unbound family (actual: {})",
        msg
    );
}

/// Negative 5: HM type error — the type-check face through the target
/// syntax entry (`1 + "a"` does not unify; the type-skin signature is
/// stripped after parse, the HM inference sees the core and rejects).
#[test]
fn hm_type_error_diag_target_face() {
    let report = check_source_target_recover("1 + \"a\"", "bad.ktf")
        .expect("recovery mode: type errors do not short-circuit (diagnostics reachable)");
    assert!(
        !report.diagnostics.is_empty(),
        "HM type errors must produce diagnostics(E0005 family -- actual rendered: {:?})",
        report.rendered
    );
}

/// Negative 6: runtime type error — the run face through the target
/// syntax entry (the type signature is a stripped skin; `f(\"a\")` where
/// `f` doubles its argument fails at the VM `+` needs-number check —
/// compile-time types do not guard the run path, same as the S-expr face).
#[test]
fn runtime_type_error_target_face() {
    let src = "fn f(n: i64) -> i64 { n + n }\nf(\"a\")";
    assert!(
        run_source_target(src, "bad.ktf").is_err(),
        "run-time type errors must surface via the target entry(+ requires a number)"
    );
}

/// Negative 7: recovery-mode multi-error collection through the target
/// syntax face — an expand-stage error (E0002: `quote()` with no datum)
/// plus a type error (E0005: `1 + "a"`) reported together in source
/// position order (item-level recovery — the TD-013 + r75 TC-DIAGS
/// semantics shared verbatim by the shared tail).
#[test]
fn recovery_multi_error_collection() {
    let src = "quote()\n1 + \"a\"";
    let report = check_source_target_recover(src, "bad.ktf")
        .expect("recovery mode: per-form collection without short-circuit");
    assert_eq!(
        report.diagnostics.len(),
        2,
        "E0002 + E0005 each one(actual {}: {:?})",
        report.diagnostics.len(),
        report.rendered
    );
    assert!(
        report.rendered[0].contains("E0002"),
        "first diagnostic = E0002 quote malformed (position order)"
    );
    assert!(
        report.rendered[1].contains("E0005"),
        "second diagnostic = E0005 type error(position order)"
    );
}

/// Negative 8: the .krf face zero-regression anchor — the real fib.krf
/// corpus through the S-expression entry, plus a malformed S-expr corpus
/// keeping its S-expr-family error (the dispatch addition does not touch
/// the default face).
#[test]
fn krf_face_zero_regression_anchor() {
    let src = include_str!("../../../../examples/usage/fib.krf");
    let outcome = run_source(src, "fib.krf").expect("fib.krf real corpus execution failed");
    let value = kerf_vm::render_value(&outcome.value, &outcome.heap);
    assert_eq!(
        value, "144",
        "fib.krf program value anchor(r109 baseline basis maintained)"
    );
    assert!(
        run_source("(define (", "bad.krf").is_err(),
        "S expression bad corpus error shape preserved"
    );
}

/// Negative 9: uppercase `.KTF` does not hit the target face — the
/// extension match is case-sensitive exact (the CLI helper semantics,
/// behaviorally anchored: the S-expression API executes S-expr source
/// under a `.KTF` name — a dispatch leak would send it to the target
/// Reader and fail).
#[test]
fn uppercase_ktf_extension_routes_sexp() {
    let outcome = run_source("(+ 1 1)", "x.KTF")
        .expect("uppercase.KTF does not hit target face -- S expression API semantics constant");
    let value = kerf_vm::render_value(&outcome.value, &outcome.heap);
    assert_eq!(
        value, "2",
        "S expression API for any file name label semantics constant"
    );
}

/// Negative 10: driver-API orthogonality — the syntax choice lives at the
/// CLI dispatch layer, not inside the driver APIs: the S-expr API reads
/// S-expr source even under a `.ktf` filename label, and the target API
/// reads target source even under a `.krf` label (the filename is a Span
/// tag, not a dispatch input — §11 interface isolation).
#[test]
fn driver_api_orthogonality_no_filename_leak() {
    let sexp_outcome = run_source("(+ 1 1)", "x.ktf")
        .expect("S expression API always reads as S expression read(no file-name dispatch leak)");
    let sexp_value = kerf_vm::render_value(&sexp_outcome.value, &sexp_outcome.heap);
    assert_eq!(sexp_value, "2", "S expression API orthogonal semantics");
    let target_outcome = run_source_target(TARGET_FIB, "x.krf")
        .expect("goal API always reads as target syntax read(no file-name dispatch leak)");
    let target_value = kerf_vm::render_value(&target_outcome.value, &target_outcome.heap);
    assert_eq!(target_value, "144", "goal API orthogonal semantics");
}

/// Negative 11: domain-registered out-of-scope construct — a `use`
/// declaration in the target syntax is rejected fail-closed with the
/// structured domain-out diagnostic (switch-window-plan v1.9 §4:
/// use/`::` import-tree = registered out-of-scope, pending the
/// namespace-import semantics window).
#[test]
fn domain_out_use_declaration_fail_closed() {
    let err = run_source_target("use kerf::foo;", "bad.ktf").expect_err(
        "use declaration = registration out-of-domain construction, must fail-closed rejected",
    );
    let msg = err.to_string();
    assert!(
        !msg.is_empty(),
        "out-of-domain construction structured diagnostics non-empty(use/:: import tree -- carried by a later window)"
    );
}

/// Negative 12: the dump faces fail on malformed target source — the
/// token dump fails at the lexical level (unclosed string: tokenization
/// itself fails), the Stx dump fails at the grammar level (unclosed
/// brace: tokenization succeeds, parsing fails — the level split
/// mirrors the two dump entries).
#[test]
fn dump_faces_error_on_bad_target_source() {
    assert!(
        dump_tokens_target("\"abc", "bad.ktf").is_err(),
        "tokens dump for lexically bad target corpus must report an error(unclosed string)"
    );
    assert!(
        dump_stx_target("fn f() { 1", "bad.ktf").is_err(),
        "stx dump for grammatically bad target corpus must report an error(unclosed brace)"
    );
}

/// Negative 13: bench-face dispatch semantics anchor — the target-syntax
/// run is cache-free, so repeated invocations re-execute the full chain
/// deterministically (the bench loop for `.ktf` compiles every round —
/// same value every round).
#[test]
fn bench_face_dispatch_repeatability() {
    for _ in 0..2 {
        let outcome = run_source_target(TARGET_FIB, "fib.ktf")
            .expect("cache-free re-run: each round an independent full-chain compile");
        let value = kerf_vm::render_value(&outcome.value, &outcome.heap);
        assert_eq!(
            value, "144",
            "re-run determinism(bench loop behavior anchor)"
        );
    }
}

/// Complement (S-expr recovery face unchanged by the refactor — the
/// shared tail `check_recover_from_forms` consumed by both skins): the
/// S-expr recovery check keeps merging the E0002 (empty form) + E0005
/// (head arity) diagnostics — the exact corpus shape verified by
/// multi_error_recovery_tests since r17.
#[test]
fn sexp_recovery_face_shared_tail_unchanged() {
    let src = "(define x 1)\n()\n(head)\n";
    let report = check_source_recover(src, "bad.krf")
        .expect("S expression recovery mode: shared tail segment line is unchanged");
    assert_eq!(
        report.diagnostics.len(),
        2,
        "E0002 + E0005 one each maintained(total share tail segment re-construct zero regression)"
    );
    assert!(
        report.diagnostics[0].primary_span.start < report.diagnostics[1].primary_span.start,
        "position order maintained(E0002 before E0005 after)"
    );
}

// ---------------------------------------------------------------------------
// r125 require-declaration skin (the eighth skin-dictionary mapping —
// `require io, write;` → `(require io write)`, the declaration family
// follows the import precedent; found as a real gap by the dual-entry
// E2E: without it a .ktf program could not declare the IO capability)
// ---------------------------------------------------------------------------

/// Positive 5 / integration / cross-syntax artifact parity: the
/// require-declaration fib corpus through the target entry — the print
/// capability gate passes (E0006 not triggered ⇒ the declaration
/// registered), and the check artifacts are byte-level equal to the
/// S-expr face (`2 protos / 9 consts / 5 global refs / 38 instructions`
/// — the cross-syntax bytecode parity surfacing at the CLI check face).
#[test]
fn target_require_declaration_cross_syntax_parity() {
    let target_src = "require io, write;\nfn fib(n: i64) -> i64 { if (n < 2) { n } else { fib(n - 1) + fib(n - 2) } }\nprint(fib(25))\nfib(12)";
    let sexp_src = "(require io write)\n(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2)))))\n(print (fib 25))\n(fib 12)";
    // Run face: the print gate passes (no E0006) ⇒ the declaration
    // registered; the program value is the same as the S-expr face.
    let target_outcome = run_source_target(target_src, "fib.ktf").unwrap_or_else(|e| {
        panic!(
            "require declaration + print gating: target face execution failed:{}",
            e
        )
    });
    let target_value = kerf_vm::render_value(&target_outcome.value, &target_outcome.heap);
    let sexp_outcome = run_source(sexp_src, "fib.krf")
        .unwrap_or_else(|e| panic!("S S-expr face comparison execution failed:{}", e));
    let sexp_value = kerf_vm::render_value(&sexp_outcome.value, &sexp_outcome.heap);
    assert_eq!(target_value, "144", "target face program value");
    assert_eq!(
        target_value, sexp_value,
        "cross-syntax program value consistent"
    );
    // Check face: artifact counts byte-level equal across the two skins.
    let t = check_source_target_recover(target_src, "fib.ktf")
        .unwrap_or_else(|e| panic!("target face check failed:{}", e));
    let s = check_source_recover(sexp_src, "fib.krf")
        .unwrap_or_else(|e| panic!("S S-expr face check failed:{}", e));
    assert_eq!(
        (
            t.proto_count,
            t.const_count,
            t.global_ref_count,
            t.instruction_count
        ),
        (
            s.proto_count,
            s.const_count,
            s.global_ref_count,
            s.instruction_count
        ),
        "cross-syntax check artifact count consistent(skin/skeleton isomorphic CLI face actual verify)"
    );
    assert_eq!(
        t.instruction_count, 38,
        "fib dual corpus instruction count anchor(38 -- and.krf baseline consistent)"
    );
}

/// Negative 14: the require-declaration bad forms fail closed — a
/// non-name token (`require 123;`), a missing terminator
/// (`require io`), and a require inside a fn body (statement position —
/// the declaration is top-level only; the expression-position rejection
/// is the readable fail-closed face).
#[test]
fn require_bad_forms_fail_closed() {
    assert!(
        run_source_target("require 123;", "bad.ktf").is_err(),
        "require non-name must report an error(expected capability name)"
    );
    assert!(
        run_source_target("require io", "bad.ktf").is_err(),
        "require missing semicolon must report an error(expected;)"
    );
    assert!(
        run_source_target("fn f() -> i64 { require io; 1 }", "bad.ktf").is_err(),
        "inside a block require must report an error(require top-level declaration position only -- expression position fail-closed)"
    );
}

/// Negative 15: print without the require declaration — the capability
/// gate rejects at the target face with E0006 (the fail-closed
/// registration discipline shared by both skins at the Stx layer).
#[test]
fn require_undeclared_print_e0006() {
    let err = run_source_target("print(1)", "bad.ktf")
        .expect_err("no require declared print must E0006 insufficient capability rejection");
    let msg = err.to_string();
    assert!(
        msg.contains("E0006") || msg.contains("capability"),
        "E0006 capability gating diagnostics (actual: {})",
        msg
    );
}

/// Negative 16: the dual-Reader require-declaration parsing parity —
/// the seed target Reader (kerf-reader/target.rs parse_require_decl) vs
/// the .krf mirror (bootstrap/target_reader.krf parse-require-decl)
/// produce byte-identical canonical Stx renderings (the r106
/// SyntaxTransitionValidator discipline applied to the new declaration
/// skin; same-source, both sides).
#[test]
fn require_declaration_dual_reader_parity() {
    use kerf_driver::bootstrap::target_reader::read_target_source_for_bootstrap;
    use kerf_reader::target::read_target_source;
    use kerf_syntax::SymbolTable;

    let src = "require io, write;\nfn f() -> i64 { 1 }\nf()";
    // Seed oracle side
    let mut t0 = SymbolTable::new();
    let seed_forms = read_target_source(src, 0, &mut t0)
        .unwrap_or_else(|e| panic!("seed side require parse failed:{}", e.message));
    let seed_rendered: Vec<String> = seed_forms
        .iter()
        .map(|f| f.render(&|s| t0.name(s).to_string()))
        .collect();
    // Production mirror side
    let mut t1 = SymbolTable::new();
    let mirror_forms = read_target_source_for_bootstrap(src, 0, &mut t1)
        .unwrap_or_else(|e| panic!("mirror side require parse failed:{}", e.message));
    let mirror_rendered: Vec<String> = mirror_forms
        .iter()
        .map(|f| f.render(&|s| t1.name(s).to_string()))
        .collect();
    assert_eq!(
        seed_rendered, mirror_rendered,
        "require declaration both sides Reader canonical render byte-level consistent"
    );
    assert!(
        seed_rendered
            .first()
            .map(|s| s.as_str())
            .unwrap_or("")
            .starts_with("(require"),
        "first form = (require io write) canonical form(actual: {:?})",
        seed_rendered.first()
    );
}

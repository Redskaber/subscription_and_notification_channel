//! Build-system segment third cut parity tests (r86 / 156-b — TD-032 test
//! entry face acceptance vehicle).
//!
//! **Criterion**: cmd_test report rendering + exit-code decision agree on
//! both faces — the Rust seed oracle (`bootstrap::test::report_seed` —
//! main.rs's original rendering loop, now in a retired role) vs the .krf
//! production face (`bootstrap/test.krf` run on the VM through the
//! `bootstrap::test` bridge — **the production path is switched**; this
//! parity is the switch guard).
//!
//! Coverage (≥12 cases): empty report (zero-case protocol); single pass;
//! single fail in two states (empty detail / non-empty detail); mixed
//! multiple cases; index right-alignment boundaries (1/9/10/99/100/1000 —
//! `{:>3}` isomorphic); Unicode case names and names with spaces; all
//! failed; mixed matrix mechanical reconciliation (full sweep of 8 report
//! shapes); production liveness probe; real-corpus end to end
//! (`test_source` output fed directly to both faces — empirical proof of
//! the runtime detail channel).

use kerf_driver::bootstrap::test::{
    production_test_is_bootstrap, report as krf_report, report_seed,
};
use kerf_driver::{TestCaseOutcome, TestReport};

/// Two-face parity assertion: both sides' rendered text and exit codes agree.
fn assert_parity(r: &TestReport) {
    let (rust_out, rust_code) = report_seed(r);
    let (krf_out, krf_code) = krf_report(r).expect("test.krf bridge internal error");
    assert_eq!(
        rust_out, krf_out,
        "dual-face report text divergence(parity broken)"
    );
    assert_eq!(
        rust_code, krf_code,
        "dual-face exit code divergence(parity broken)"
    );
}

/// Case construction (four fields built directly).
fn case(index: usize, name: &str, pass: bool, detail: &str) -> TestCaseOutcome {
    TestCaseOutcome {
        index,
        name: name.to_string(),
        pass,
        detail: detail.to_string(),
    }
}

/// Report construction (passed/failed recomputed on the spot from the case
/// sequence — same statistics policy as test_source).
fn make_report(cases: Vec<TestCaseOutcome>) -> TestReport {
    let passed = cases.iter().filter(|c| c.pass).count();
    let failed = cases.len() - passed;
    TestReport {
        cases,
        passed,
        failed,
    }
}

// ---------------------------------------------------------------------------
// parity corpus (sixteen cases — zero-case protocol + single/multi-case
// dual states + boundary matrix)
// ---------------------------------------------------------------------------

/// Empty report (zero-case protocol: no lines + summary 0/0/0 + exit code 0).
#[test]
fn parity_empty_report() {
    let r = make_report(Vec::new());
    assert_parity(&r);
    let (out, code) = report_seed(&r);
    assert_eq!(out, "pass 0 / total 0 (fail 0)\n");
    assert_eq!(code, 0);
}

/// Single passing case (minimal main path — index 1 right-aligned to width 3: "  1").
#[test]
fn parity_single_pass() {
    let r = make_report(vec![case(1, "(= 1 1)", true, "")]);
    assert_parity(&r);
    let (out, code) = report_seed(&r);
    assert_eq!(out, "PASS    1 (= 1 1)\npass 1 / total 1 (fail 0)\n");
    assert_eq!(code, 0);
}

/// Single fail + empty detail (FAIL line without a detail line — the is_empty guard).
#[test]
fn parity_single_fail_empty_detail() {
    let r = make_report(vec![case(1, "(= 1 2)", false, "")]);
    assert_parity(&r);
    let (out, code) = report_seed(&r);
    assert_eq!(out, "FAIL    1 (= 1 2)\npass 0 / total 1 (fail 1)\n");
    assert_eq!(code, 1);
}

/// Single fail + non-empty detail (FAIL line + six-space └ detail line).
#[test]
fn parity_single_fail_with_detail() {
    let r = make_report(vec![case(
        1,
        "(= 1 2)",
        false,
        "assertion return #f(expected non- #f value) -- evaluate result #f",
    )]);
    assert_parity(&r);
    let (out, code) = report_seed(&r);
    assert_eq!(
        out,
        "FAIL    1 (= 1 2)\n      └ assertion return #f(expected non- #f value) -- evaluate result #f\npass 0 / total 1 (fail 1)\n"
    );
    assert_eq!(code, 1);
}

/// Mixed multiple cases (PASS/FAIL alternating + detail dual states — the
/// typical shape after r49 recovery semantics).
#[test]
fn parity_mixed_cases() {
    let r = make_report(vec![
        case(1, "(= 1 1)", true, ""),
        case(
            2,
            "(= 1 2)",
            false,
            "assertion return #f(expected non- #f value) -- evaluate result #f",
        ),
        case(3, "(f 5)", true, ""),
        case(4, "(g 0)", false, "runtime error: unbound variable x"),
    ]);
    assert_parity(&r);
    let (out, code) = report_seed(&r);
    assert_eq!(
        out,
        concat!(
            "PASS    1 (= 1 1)\n",
            "FAIL    2 (= 1 2)\n",
            "      └ assertion return #f(expected non- #f value) -- evaluate result #f\n",
            "PASS    3 (f 5)\n",
            "FAIL    4 (g 0)\n",
            "      └ runtime error: unbound variable x\n",
            "pass 2 / total 4 (fail 2)\n"
        )
    );
    assert_eq!(code, 1);
}

/// Index right-alignment boundary matrix (1/9/10/99/100/1000 — `{:>3}`
/// isomorphic: shorter values get leading-space padding, ≥3 digits
/// render as-is).
#[test]
fn parity_index_padding_boundaries() {
    let r = make_report(vec![
        case(1, "a", true, ""),
        case(9, "b", true, ""),
        case(10, "c", true, ""),
        case(99, "d", true, ""),
        case(100, "e", true, ""),
        case(1000, "f", true, ""),
    ]);
    assert_parity(&r);
    let (out, code) = report_seed(&r);
    assert_eq!(
        out,
        concat!(
            "PASS    1 a\n",
            "PASS    9 b\n",
            "PASS   10 c\n",
            "PASS   99 d\n",
            "PASS  100 e\n",
            "PASS  1000 f\n",
            "pass 6 / total 6 (fail 0)\n"
        )
    );
    assert_eq!(code, 0);
}

/// Unicode case names (Chinese/full-width parentheses/box characters —
/// string concatenation byte-level identical).
#[test]
fn parity_unicode_names() {
    let r = make_report(vec![
        case(1, "(assertion integer addition)", true, ""),
        case(
            2,
            "(check `hygienic macro`)",
            false,
            "effect payload: unknown effect family",
        ),
    ]);
    assert_parity(&r);
    let (out, code) = report_seed(&r);
    assert_eq!(
        out,
        concat!(
            "PASS    1 (assertion integer addition)\n",
            "FAIL    2 (check `hygienic macro`)\n",
            "      └ effect payload: unknown effect family\n",
            "pass 1 / total 2 (fail 1)\n"
        )
    );
    assert_eq!(code, 1);
}

/// All failed (failed == total — exit code 1 + count upper bound).
#[test]
fn parity_all_fail() {
    let r = make_report(vec![
        case(1, "x", false, "d1"),
        case(2, "y", false, "d2"),
        case(3, "z", false, ""),
    ]);
    assert_parity(&r);
    let (out, code) = report_seed(&r);
    assert_eq!(
        out,
        concat!(
            "FAIL    1 x\n",
            "      └ d1\n",
            "FAIL    2 y\n",
            "      └ d2\n",
            "FAIL    3 z\n",
            "pass 0 / total 3 (fail 3)\n"
        )
    );
    assert_eq!(code, 1);
}

/// Long case names (the 64-char truncation shape is decided upstream — the
/// rendering face merely passes it through, not a rendering-face
/// responsibility; names with spaces tested too).
#[test]
fn parity_long_and_spaced_names() {
    let long_name = "(very-long-case-name-with-many-segments-aaaaaaaaaaaaaaaaaaaaaaaaaa)";
    let r = make_report(vec![
        case(1, long_name, true, ""),
        case(2, "case with spaces", false, "detail with spaces"),
    ]);
    assert_parity(&r);
}

/// Count-independent consistency (when the report.passed/failed fields
/// disagree with the case sequence, .krf's on-the-spot statistics are the
/// single decision source — the oracle's summary line uses the fields, krf
/// uses the on-the-spot counts; this construction verifies that no
/// divergence surface exists for "field-mismatched" inputs: production
/// input is always consistent [make_report recomputes isomorphically];
/// here we lock in equivalence under the fields-consistent precondition).
#[test]
fn parity_counts_consistency() {
    let mut r = make_report(vec![
        case(1, "p", true, ""),
        case(2, "q", false, "d"),
        case(3, "r", true, ""),
    ]);
    r.passed = 2;
    r.failed = 1;
    assert_parity(&r);
}

/// Production liveness probe (switch guard — empirical anchor that the krf-path rendering happened more than zero times).
#[test]
fn production_test_entry_is_bootstrap() {
    let r = make_report(vec![case(1, "(= 1 1)", true, "")]);
    let _ = krf_report(&r).expect("production render");
    assert!(
        production_test_is_bootstrap(),
        "krf path rendering did not happen(production switch guard failed)"
    );
}

/// Real-corpus end to end: `test_source` output fed directly to both faces
/// (including the runtime channel of PASS + FAIL detail — r49 recovery
/// semantics + the real shape of the assertion-#f detail).
#[test]
fn parity_real_corpus_end_to_end() {
    let passing = "(define (f x) x)\n(f 5)\n";
    let rp = kerf_driver::test_source(passing, "pass.krf").expect("pass corpus");
    assert_parity(&rp);

    let failing = "(define (g x) x)\n(= 1 2)\n(g 3)\n";
    let rf = kerf_driver::test_source(failing, "fail.krf").expect("failed corpus");
    assert_parity(&rf);
    let (out, code) = report_seed(&rf);
    assert_eq!(code, 1);
    assert!(out.contains("FAIL    1 (= 1 2)"));
    assert!(out.contains("      └ "));
    assert!(out.contains("pass 1 / total 2 (fail 1)"));
}

/// Mixed matrix mechanical reconciliation (full sweep of 8 report shapes —
/// 0/1/2/3/5 cases × pass/fail combinations, both faces agreeing).
#[test]
fn parity_full_matrix_sweep() {
    let name_pool = ["a", "bb", "ccc", "dddd", "e"];
    let detail_pool = ["", "d", "长详情——包含中文与空格"];
    for n in 0..=5usize {
        for mask in 0..(1usize << n) {
            let cases: Vec<TestCaseOutcome> = (0..n)
                .map(|i| {
                    let pass = (mask >> i) & 1 == 0;
                    let detail = if pass { "" } else { detail_pool[i % 3] };
                    case(i + 1, name_pool[i % 5], pass, detail)
                })
                .collect();
            let r = make_report(cases);
            assert_parity(&r);
        }
    }
}

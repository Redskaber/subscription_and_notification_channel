// E6 close-out (r154 / 224-c6): remaining failures fixed — the S-expr
//! handle-group check leg converted to the target flat multi-arm face; the
//! bare-literal arm bodies converted to block form (the target Reader's
//! handler-body grammar: resume/halt/pass/block).
//! .ktf handle multi-arm / halt / pass family tests — r132 / 202-c (the
//! handle multi-arm window: the twelfth skin-mapping family) + **r136 /
//! 206-b (TD-033 group install — handle-multi-arm-design.md §8 D11-D19)**:
//! the >= 2-arm surface form now compiles to the GROUP-INSTALL core form
//! (handle-group — the Koka-style reading of [HANDLE-INSTALL]: the whole
//! group is consumed on the first dispatch, sibling arm bodies are
//! mutually unprotected); the nested semantics stay hand-writable via
//! explicit nesting (D11); the S-expr face gains the `(handle-group
//! (tag (p k) result)+ body)` core form (D12 — dual-face parity).
//!
//! **Verification surfaces** (the target-face `handle e { A(p₁,k₁) => b₁,
//! B(p₂,k₂) => b₂, }` family → `(handle-group (A (p₁ k₁) b₁') (B (p₂ k₂)
//! b₂') e')` — group install at the VM layer via INSTALL_HANDLER_GROUP
//! #46; the S-expr face's handle-group form is the multi-arm expression,
//! halt = the no-resume tail value, pass = `(perform (cons (quote T) p))`):
//! (1) **run-face E2E** — the group dispatch (one effect, any-entry match),
//! the sibling non-protection (the TD-033 semantic difference anchor: a
//! sibling tag performed inside a handler body propagates past the group),
//! the group consumption after resume (the remaining computation's
//! sibling effects escape), the explicit-nesting idiom (D11 — both arms
//! firing in evaluation order, the r132 value anchor 45 retained through
//! the nested form), halt(v)/bare-halt flow termination, and the pass
//! propagation to the outer handler (⇒ 120);
//! (2) **the r132/r136 grammar settlement** — the family is verified
//! dual-Reader: seed vs mirror canonical Stx rendering byte-identical
//! (including the generated handle-group nodes, the halt nil-literal
//! tail, and the pass perform/cons/quote chain), error faces message +
//! Span byte-identical (the D6 duplicate-tag diagnostic, the D8 zero-arm /
//! two-binder discipline, the pass-arity and halt-follow diagnostics);
//! (3) **the group-equivalence bytecode gate (r136 D18)** — the .ktf flat
//! multi-arm form compiles byte-identically to the .krf handle-group form
//! (skin transparency: both faces produce the same group-install product
//! — instruction order + constant pool + proto shapes + global-reference
//! face; the r132 nesting-equivalence gate retires with the semantic
//! switch);
//! (4) **cross-stage consumption** — the multi-arm program through
//! `check_source_recover` stays diagnostic-clean with real
//! instruction artifacts;
//! (5) **fail-closed negatives** — reader-level structure discipline
//! (duplicate tags D6 / zero arms / non-two binders / non-ident arm
//! heads / missing => / unclosed braces / missing inter-arm comma /
//! halt-follow / pass-arity / expression-position halt/pass — the
//! positional-word domain-out) + the S-expr handle-group syntax family
//! (D17: < 2 arms redirect / duplicate tags / clause shape / binder
//! discipline) + the runtime semantic negatives (pass with no outer
//! handler → err_effect_unhandled code 7; group-unmatched effect escape).
//!
//! **Same-window defect settlement (r132 / 202-c)**: the multi-arm E2E
//! exposed the latent fvo miscount family (compiler.ktf's handle/fn arms
//! popped unconditionally while pushing conditionally — nested same-name
//! binders crashed the bootstrap compiler's `tail(nil)`; the Rust seed's
//! variant popped silently) — settled in expr.rs + compiler.ktf with the
//! Let arm's r45/D42 shadow-aware discipline; the nested same-name
//! program (`confirm.krf` shape) is the regression anchor here.
//!
//! Skin-dictionary basis: 20 §14 v1.27 (the twelfth mapping family —
//! r136 group-install mapping); 02 §8.13.1a v7.17/v7.20 (the Level 0
//! production update + the r136 group mapping note). Window basis:
//! switch-window-plan §4 out-of-domain registration row (r132) + 06 §10 ([HANDLE-INSTALL]
//! group reading — r136 TD-033 implementation) + 22 §880 (the three
//! handler positional words) + handle-multi-arm-design.md v1.1 (design
//! single source — §8 D11-D19).
//!
//! Ratio: 16 positive : 48 negative = 1:3 (§9.4.3; r136: +8 positive /
//! +24 negative on the r132 8:24 base).

use kerf_compiler::{compile_module, BcProgram};
use kerf_driver::bootstrap::reader::read_source_for_bootstrap;
use kerf_driver::{check_source_recover, run_source};
use kerf_expander::{expand_program as expand_program_seed, ExpandCtxt};
use kerf_reader::read_source;
use kerf_syntax::{Stx, StxDatum, StxLiteral, SymbolTable};

// ---------------------------------------------------------------------------
// Value helpers
// ---------------------------------------------------------------------------

fn run_value(src: &str, filename: &str) -> String {
    let outcome = run_source(src, filename)
        .unwrap_or_else(|e| panic!("target face program {} execution failed:{}", filename, e));
    kerf_vm::render_value(&outcome.value, &outcome.heap)
}

// ---------------------------------------------------------------------------
// Dual-Reader parity helpers (the ktf_use_decl_tests.rs caliber —
// canonical rendering with Span bytes; error parity with message + Span
// byte equality)
// ---------------------------------------------------------------------------

fn render_stx(s: &Stx, t: &SymbolTable) -> String {
    let mut out = String::new();
    render_stx_into(s, t, &mut out);
    out
}

fn render_stx_into(s: &Stx, t: &SymbolTable, out: &mut String) {
    match &s.datum {
        StxDatum::Symbol(sym) => {
            out.push_str(&format!(
                "(sym {} {}..{})",
                t.name(*sym),
                s.span.start,
                s.span.end
            ));
        }
        StxDatum::Literal(l) => match l {
            StxLiteral::Int(v) => {
                out.push_str(&format!("(int {} {}..{})", v, s.span.start, s.span.end));
            }
            StxLiteral::Float(f) => {
                out.push_str(&format!("(float {:?} {}..{})", f, s.span.start, s.span.end));
            }
            StxLiteral::Str(r) => {
                out.push_str(&format!("(str {:?} {}..{})", r, s.span.start, s.span.end));
            }
            StxLiteral::Bool(b) => {
                out.push_str(&format!("(bool {} {}..{})", b, s.span.start, s.span.end));
            }
            StxLiteral::Nil => {
                out.push_str(&format!("(unit {}..{})", s.span.start, s.span.end));
            }
        },
        StxDatum::List(items) => {
            out.push_str(&format!("(lst {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
        // r138 / 208-c — TD-002: vectors now reach both Readers (the
        // fourteenth skin mapping) — full canonical rendering
        StxDatum::Vector(items) => {
            out.push_str(&format!("(vec {}..{} [", s.span.start, s.span.end));
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                render_stx_into(it, t, out);
            }
            out.push_str("])");
        }
    }
}

/// Grammar parity assertion: both Readers' canonical renderings are
/// byte-identical (the r132 grammar settlement's core gate — the
/// multi-arm family is seed/mirror isomorphic by construction, including
/// the generated nested handle nodes, the halt nil-literal tail, and the
/// pass perform/cons/quote chain with their Span bytes).
fn assert_grammar_parity(src: &str, what: &str) {
    let mut t1 = SymbolTable::new();
    let seed = read_source(src, 0, &mut t1)
        .unwrap_or_else(|e| panic!("[{}] seed syntax failed: {}", what, e.message));
    let mut t2 = SymbolTable::new();
    let mirror = read_source_for_bootstrap(src, 0, &mut t2)
        .unwrap_or_else(|e| panic!("[{}] mirror syntax failed:{}", what, e.message));
    assert_eq!(
        seed.len(),
        mirror.len(),
        "[{}] top-level item count mismatch (seed {} vs mirror {})",
        what,
        seed.len(),
        mirror.len()
    );
    for (i, (a, b)) in seed.iter().zip(mirror.iter()).enumerate() {
        assert_eq!(
            render_stx(a, &t1),
            render_stx(b, &t2),
            "[{}] top-level item #{} syntax tree mismatch (seed vs mirror canonical render)",
            what,
            i
        );
    }
}

/// Grammar-error parity assertion: message + Span byte-level equality
/// (the mirror's diagnostic face is the seed's, by construction — the D6
/// duplicate-tag diagnostic, the D8 zero-arm / two-binder discipline, the
/// pass-arity and halt-follow diagnostics are all anchored in both
/// Readers).
fn assert_grammar_err_parity(src: &str, what: &str) -> String {
    let mut t1 = SymbolTable::new();
    let seed_err = match read_source(src, 0, &mut t1) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] seed should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    let mut t2 = SymbolTable::new();
    let mirror_err = match read_source_for_bootstrap(src, 0, &mut t2) {
        Err(e) => e,
        Ok(_) => panic!(
            "[{}] mirror should be a syntax error (actually parsed successfully)",
            what
        ),
    };
    assert_eq!(
        seed_err.message, mirror_err.message,
        "[{}] syntax error message mismatch (seed {:?} vs mirror {:?})",
        what, seed_err.message, mirror_err.message
    );
    assert_eq!(
        seed_err.span.start, mirror_err.span.start,
        "[{}] syntax error Span start mismatch (seed {} vs mirror {})",
        what, seed_err.span.start, mirror_err.span.start
    );
    assert_eq!(
        seed_err.span.end, mirror_err.span.end,
        "[{}] syntax error Span end mismatch (seed {} vs mirror {})",
        what, seed_err.span.end, mirror_err.span.end
    );
    seed_err.message.clone()
}

/// Compile path: Stx forms → seed expansion → seed compilation (E1-β/I1
/// front-end isomorphism — the Reader is the only comparison variable;
/// the table is carried through and returned — the shared-table
/// discipline for cross-text bytecode comparability).
/// Symbol rendering for disassembly (tests cannot reach the driver's
/// pub(crate) resolve_symbol — plain table names suffice for the
/// mnemonic-contains gate; the compiler sentinels u32::MAX-1/2 render as
/// <main>/<fn> — the resolve_symbol discipline).
fn table_name(s: kerf_syntax::Symbol, t: &SymbolTable) -> String {
    match s.0 {
        x if x == u32::MAX - 1 => "<main>".to_string(),
        x if x == u32::MAX - 2 => "<fn>".to_string(),
        _ => t.name(s).to_string(),
    }
}

fn compile_forms_seed(forms: &[Stx], table: SymbolTable, what: &str) -> (BcProgram, SymbolTable) {
    let mut ectx = ExpandCtxt::new(table);
    let core = expand_program_seed(forms, &mut ectx)
        .unwrap_or_else(|e| panic!("[{}] seed expansion failed:{}", what, e.message));
    let program = compile_module(&core)
        .unwrap_or_else(|e| panic!("[{}] seed compile failed: {}", what, e.message));
    (program, ectx.table)
}

// ---------------------------------------------------------------------------
// Positives — run-face E2E + grammar settlement + nesting-equivalence +
// cross-stage consumption
// ---------------------------------------------------------------------------

/// Positive 1 / integration: the explicit-nesting idiom (D11 — the nested
/// semantics stay hand-writable): giftB inner, giftA outer; each
/// single-arm frame survives its own dispatch, so the resumed computation
/// stays protected by its own arm — both arms fire in evaluation order
/// (giftA first → resume 30; then giftB → resume 15) ⇒ 45 (the r132 value
/// anchor retained through the r136 semantic switch's nested escape
/// hatch).
#[test]
fn multiarm_explicit_nesting_both_arms_e2e() {
    let v = run_value(
        "fn ask_a() { perform giftA(10, 20); }\nfn ask_b() { perform giftB(7, 8); }\nfn inner() {\n    handle (ask_a() + ask_b()) {\n        giftB(p, k) => resume(tail(p) + head(p)),\n    }\n}\nfn guarded() {\n    handle inner() {\n        giftA(p, k) => resume(tail(p) + head(p)),\n    }\n}\nguarded()",
        "multiarm.ktf",
    );
    assert_eq!(
        v, "45",
        "explicit nested two arms order throughout must produce 45((10+20)+(7+8) -- actual: {})",
        v
    );
}

/// Positive 2 / integration (r136 D18 — the group-equivalence bytecode
/// gate): the .ktf flat multi-arm form compiles byte-identically to the
/// .krf handle-group form (skin transparency: both faces produce the same
/// group-install product — INSTALL_HANDLER_GROUP instruction order +
/// constant pool + proto shapes + global-reference face; the r132
/// nesting-equivalence gate retires with the D11 semantic switch; the
/// cross-text comparison domain is the bytecode payload, spans excluded
/// per the r106 discipline).
#[test]
fn multiarm_group_equivalence_bytecode() {
    let ktf_src = "fn ask_a() { perform giftA(10, 20); }\nfn ask_b() { perform giftB(7, 8); }\nfn guarded() {\n    handle ask_b() {\n        giftA(p, k) => resume(tail(p) + head(p)),\n        giftB(p, k) => resume(tail(p) + head(p)),\n    }\n}\nguarded()";
    // E6 close-out rework (r154 / 224-b): the .krf handle-group source
    // leg retired with the S-expr face (the target surface has no
    // handle-group statement — the Reader GENERATES the core form from
    // the >=2-arm flat statement); the group-install product is anchored
    // on the target side: the flat multi-arm compiles to the
    // INSTALL_HANDLER_GROUP instruction (the group-install signature).
    let mut t = SymbolTable::new();
    let f1 = read_source(ktf_src, 0, &mut t)
        .unwrap_or_else(|e| panic!(".ktf many arm parse failed:{}", e.message));
    let (p1, t) = compile_forms_seed(&f1, t, ".ktf flat multi-arm");
    let text = kerf_compiler::disassemble_program(&p1, &|s: kerf_syntax::Symbol| table_name(s, &t));
    assert!(
        text.contains("INSTALL_HANDLER_GROUP"),
        "flat multi-arm must compile to the group-install instruction(actual disassembly head: {})",
        text.lines().take(12).collect::<Vec<_>>().join("\n")
    );
}

/// Positive 3 / grammar settlement: dual-Reader canonical rendering
/// parity — the family's shapes (two-arm / three-arm / trailing comma /
/// halt(v) arm / bare-halt arm / pass arm / single-arm legacy / mixed
/// halt+resume+pass), byte-identical including the generated nested
/// handle nodes and their Span bytes.
#[test]
fn multiarm_dual_reader_canonical_parity() {
    assert_grammar_parity(
        "handle (1 + 2) { giftA(p, k) => resume(p), giftB(p, k) => resume(k), }",
        "two arms form",
    );
    assert_grammar_parity(
        "handle (1) { giftA(p, k) => resume(p), giftB(p, k) => halt, giftC(p, k) => pass, }",
        "three arm mixed form(resume/halt/pass)",
    );
    assert_grammar_parity(
        "handle (1) { giftA(p, k) => resume(p), giftB(p, k) => resume(k) }",
        "two arms no trailing comma form",
    );
    assert_grammar_parity(
        "handle (1) { giftA(p, k) => halt(42), }",
        "halt(expr) arm form",
    );
    assert_grammar_parity("handle (1) { giftA(p, k) => halt, }", "bare halt arm form");
    assert_grammar_parity("handle (1) { giftA(p, k) => pass, }", "pass arm form");
    assert_grammar_parity(
        "handle (1) { giftA(p, k) => resume(1), }",
        "single arm already has form",
    );
    assert_grammar_parity(
        "handle (1) { giftA(p, k) => { let x = 1; resume(x) }, }",
        "block body arm form(r128 already has)",
    );
}

/// Positive 4 / integration: halt semantics — `halt(expr)` yields the
/// value as the handle's value (the flow terminates at the handler); bare
/// `halt` yields nil (the resume ∈ {0,1} closure's zero-resume arm; the
/// suspended continuation is abandoned).
#[test]
fn halt_value_and_bare_e2e() {
    let v = run_value(
        "fn ask() { perform gift(7, 8); }\nfn guarded() {\n    handle (100 + ask()) { gift(p, k) => halt(42), }\n}\nguarded()",
        "haltval.ktf",
    );
    assert_eq!(
        v, "42",
        "halt(42) terminating flow must use 42 is handle value (actual: {})",
        v
    );
    let bare = run_value(
        "fn ask() { perform gift(7, 8); }\nfn guarded() {\n    handle (100 + ask()) { gift(p, k) => halt, }\n}\nguarded()",
        "haltnil.ktf",
    );
    assert_eq!(
        bare, "nil",
        "bare halt terminating flow must use nil is handle value (actual: {})",
        bare
    );
    // The no-fire arm: the protected expression completes without
    // performing → the handle's value is the protected expression's value
    // (the halt arm never runs).
    let nofire = run_value(
        "fn guarded() {\n    handle (100 + 5) { gift(p, k) => halt(42), }\n}\nguarded()",
        "nofire.ktf",
    );
    assert_eq!(
        nofire, "105",
        "not emit arm not run -- handle value = receive protect expression value (actual: {})",
        nofire
    );
}

/// Positive 5 / integration: pass semantics — the inner handle's pass arm
/// re-performs the effect outward (the fired arm's H frame has ext1
/// cleared, the frame scan walks past the inner handle), the outer
/// handler resumes with (0+20)=20, and the +100 continues from the outer
/// protected expression ⇒ 120 (the pass2 smoke's test-formalized anchor —
/// pass-point continuation + T-EFFECT-PROPAGATION).
#[test]
fn pass_propagation_e2e() {
    let v = run_value(
        "fn ask() { perform gift(0, 20); }\nfn inner_scope() {\n    handle ask() { gift(p, k) => pass, }\n}\nfn outer() {\n    handle (100 + inner_scope()) { gift(p, k) => resume(tail(p) + head(p)), }\n}\nouter()",
        "pass.ktf",
    );
    assert_eq!(
        v, "120",
        "pass pierce through to outer handler + resume(20) + 100 must produce 120(actual: {})",
        v
    );
}

/// Positive 6 / regression: the single-arm zero-regression anchor — the
/// r128 corpus form (the effect.ktf shape) still yields 120 through the
/// new multi-arm parse path (D1: the single-arm degenerate is the same
/// Stx/bytecode), plus the same-window fvo settlement regression anchor
/// (the nested same-name hand-written .krf form that crashed the
/// bootstrap compiler pre-settlement now runs through the production
/// chain).
#[test]
fn singlearm_zero_regression_and_fvo_settlement() {
    let v = run_value(
        "fn ask() { perform gift(0, 20); }\nfn guarded() {\n    handle (100 + ask()) { gift(p, k) => resume(tail(p) + head(p)) }\n}\nguarded()",
        "single.ktf",
    );
    assert_eq!(
        v, "120",
        "single arm already has form behavior anchor must maintained 120(r128 corpus family semantics -- actual: {})",
        v
    );
    // The fvo settlement regression: nested same-name binders (the
    // pre-settlement `tail(nil)` crash shape — converted to the target
    // face at E6 r154 / 224-b; the inner handle rides a closure carrier —
    // handle is a statement form, the protected position needs an
    // expression, the closure's block tail threads the inner handle's
    // value out)
    let nested = run_value(
        "fn ask_a() { perform gifta(10, 20); }
fn guarded() {
    handle (|| { handle ask_a() { giftb(p, k) => resume(tail(p) + head(p)) } })() {
        gifta(p, k) => resume(tail(p) + head(p)),
    }
}
guarded()",
        "fvosettlement.ktf",
    );
    assert_eq!(
        nested, "30",
        "nested same-named binding handle(fvo clearing regression anchor)must produce 30(actual: {})",
        nested
    );
}

/// Positive 7 / integration: the corpus single-face baseline anchor
/// (r153 / 223-c: the .krf corpus face retired — s-expr-removal-plan §4
/// Batch D; the cross-grammar pair leg retired with it, the equivalence
/// evidence archived in RELEASE r136-r152) — effect_multiarm.ktf (the
/// flat multi-arm/halt/pass face carrying the group-install demo
/// (group_arm ⇒ 15) + the explicit-nesting idiom (both_arms ⇒ 45);
/// consumed via include_str! — the corpus-integrity gate, any corpus
/// edit that breaks the chain fails here) through the sole production
/// run chain.
#[test]
fn multiarm_corpus_single_face_baseline_anchor() {
    const CORPUS_KTF: &str = include_str!("../../../../examples/usage/effect_multiarm.ktf");
    let ktf = run_value(CORPUS_KTF, "effect_multiarm.ktf");
    assert_eq!(
        ktf, "217",
        "corpus baseline value: explicit nested two arms 45 + group dispatch 15 + halt 42 + pass outer resume(15)+100 = 217(actual: {})",
        ktf
    );
}

/// Positive 8 / cross-stage: the multi-arm program through
/// `check_source_recover` stays diagnostic-clean with real
/// instruction artifacts (the HM/typecheck face consumes the generated
/// nested handle CoreExpr without friction).
#[test]
fn multiarm_check_cross_stage_clean() {
    let report = check_source_recover(
        "fn ask_a() { perform giftA(10, 20); }\nfn ask_b() { perform giftB(7, 8); }\nfn guarded() {\n    handle (ask_a() + ask_b()) {\n        giftA(p, k) => resume(tail(p) + head(p)),\n        giftB(p, k) => halt(0),\n    }\n}\nguarded()",
        "multiarm.ktf",
    )
    .expect("recovery mode check does not short-circuit");
    assert!(
        report.diagnostics.is_empty(),
        "many arm program check face must have zero diagnostics (actual: {:?})",
        report.diagnostics
    );
    assert!(
        report.proto_count + report.const_count > 0,
        "many arm program must have a real compile artifact(actual: proto {} + const {})",
        report.proto_count,
        report.const_count
    );
}

// ---------------------------------------------------------------------------
// Negatives — reader-level dual-Reader parity (message + Span bytes) +
// the runtime semantic negative
// ---------------------------------------------------------------------------

/// Negative 1: duplicate tag in two arms — the D6 fail-closed diagnostic
/// (nested desugar's silent shadowing refused; the Span is the duplicate
/// occurrence's own position).
#[test]
fn neg_duplicate_tag_two_arms() {
    let m = assert_grammar_err_parity(
        "handle (1) { gift(p, k) => halt, gift(p, k) => halt, }",
        "two arms same-named",
    );
    assert!(
        m.contains("handle arm effect name duplicate: `gift`"),
        "duplicate label dedicated diagnostic must carry effect name(actual: {})",
        m
    );
}

/// Negative 2: duplicate tag among three arms (the middle duplicate —
/// the guard fires at the tag position regardless of arm count).
#[test]
fn neg_duplicate_tag_three_arms() {
    let m = assert_grammar_err_parity(
        "handle (1) { a(p, k) => halt, b(p, k) => halt, a(p, k) => halt, }",
        "three arm in two same-named",
    );
    assert!(
        m.contains("handle arm effect name duplicate: `a`"),
        "three arm duplicate label diagnostics (actual: {})",
        m
    );
}

/// Negative 3: zero arms — `handle e {}` fails closed (D8; the Span is
/// the closing brace's own position).
#[test]
fn neg_zero_arms() {
    let m = assert_grammar_err_parity("handle (1) { }", "zero arms");
    assert_eq!(
        m, "handle needs at least one arm",
        "zero arms diagnostics (actual: {})",
        m
    );
}

/// Negative 4: zero binders — the arm pattern without the (p, k) pair.
#[test]
fn neg_arm_binder_zero() {
    let m = assert_grammar_err_parity("handle (1) { gift => halt, }", "zero binding");
    assert_eq!(
        m, "handle arm binding must be two-element (payload, resume)",
        "zero binding diagnostics (actual: {})",
        m
    );
}

/// Negative 5: one binder.
#[test]
fn neg_arm_binder_one() {
    let m = assert_grammar_err_parity("handle (1) { gift(p) => halt, }", "unary binding");
    assert_eq!(
        m, "handle arm binding must be two-element (payload, resume)",
        "unary binding diagnostics (actual: {})",
        m
    );
}

/// Negative 6: three binders.
#[test]
fn neg_arm_binder_three() {
    let m = assert_grammar_err_parity("handle (1) { gift(p, k, x) => halt, }", "ternary binding");
    assert_eq!(
        m, "handle arm binding must be two-element (payload, resume)",
        "ternary binding diagnostics (actual: {})",
        m
    );
}

/// Negative 7: the arm head is an int literal (not an effect name).
#[test]
fn neg_arm_head_int() {
    let m = assert_grammar_err_parity("handle (1) { 42(p, k) => halt, }", "arm first integer");
    assert!(
        m.contains("expected an effect name, got"),
        "arm first non-effect name diagnostics (actual: {})",
        m
    );
}

/// Negative 8: the arm head is a semicolon.
#[test]
fn neg_arm_head_semi() {
    let m = assert_grammar_err_parity("handle (1) { ;(p, k) => halt, }", "arm first semicolon");
    assert!(
        m.contains("expected an effect name, got"),
        "arm first semicolon diagnostics (actual: {})",
        m
    );
}

/// Negative 9: the arm head is a keyword (fn).
#[test]
fn neg_arm_head_kwfn() {
    let m = assert_grammar_err_parity("handle (1) { fn(p, k) => halt, }", "arm first keyword");
    assert!(
        m.contains("expected an effect name, got"),
        "arm first keyword diagnostics (actual: {})",
        m
    );
}

/// Negative 10: pass with an argument — the bare positional word takes
/// no operands (the re-perform is Reader-injected).
#[test]
fn neg_pass_with_args() {
    let m = assert_grammar_err_parity(
        "handle (1) { gift(p, k) => pass(1), }",
        "pass carry actual argument",
    );
    assert_eq!(
        m,
        "pass does not accept arguments(bare positional word -- pierce through zero arguments form, re-emitted by Reader injection)",
        "pass actual argument diagnostics (actual: {})",
        m
    );
}

/// Negative 11: bare halt followed by a semicolon (neither the arm
/// separator nor the closing brace nor the value paren).
#[test]
fn neg_halt_followed_semi() {
    let m = assert_grammar_err_parity("handle (1) { gift(p, k) => halt; }", "halt after semicolon");
    assert!(
        m.contains("halt as a bare form or halt(expr) form, actually followed by"),
        "halt followed by diagnostics (actual: {})",
        m
    );
}

/// Negative 12: bare halt followed by an identifier.
#[test]
fn neg_halt_followed_ident() {
    let m = assert_grammar_err_parity(
        "handle (1) { gift(p, k) => halt x }",
        "halt after identifier",
    );
    assert!(
        m.contains("halt as a bare form or halt(expr) form, actually followed by"),
        "halt followed by identifier diagnostics (actual: {})",
        m
    );
}

/// Negative 13: missing `=>` between the binder pair and the body.
#[test]
fn neg_missing_fatarrow() {
    let m = assert_grammar_err_parity("handle (1) { gift(p, k) halt, }", "missing =>");
    assert!(
        m.contains("expected =>"),
        "missing => diagnostics (actual: {})",
        m
    );
}

/// Negative 14: unclosed braces at eof.
#[test]
fn neg_missing_rbrace_eof() {
    let m = assert_grammar_err_parity(
        "handle (1) { gift(p, k) => halt,",
        "missing right brace eof",
    );
    assert!(
        m.contains("expected an effect name, got") || m.contains("expected }"),
        "eof receive tail diagnostics (actual: {})",
        m
    );
}

/// Negative 15: missing inter-arm comma — the no-comma path requires the
/// closing brace (the seed's break→expect path, byte-parity on the error
/// face; a resume arm body is used so the halt-follow arity check does
/// not fire first).
#[test]
fn neg_missing_interarm_comma() {
    let m = assert_grammar_err_parity(
        "handle (1) { giftA(p, k) => resume(1) giftB(p, k) => halt, }",
        "missing arm between comma",
    );
    assert!(
        m.contains("expected }"),
        "missing arm between comma must hit expected }} diagnostics (actual: {})",
        m
    );
}

/// Negative 16: the handler body is a semicolon (not one of the four
/// forms).
#[test]
fn neg_handler_body_semi() {
    let m = assert_grammar_err_parity("handle (1) { gift(p, k) => ;, }", "handler body semicolon");
    assert!(
        m.contains("expected handler body (resume call form / halt form / pass / block), got"),
        "handler body four form enumerated cite diagnostics (actual: {})",
        m
    );
}

/// Negative 17: the handler body is an int literal (the direct value
/// position is not one of the four forms — halt(expr) is the value
/// carrier).
#[test]
fn neg_handler_body_int() {
    let m = assert_grammar_err_parity("handle (1) { gift(p, k) => 42, }", "handler body integer");
    assert!(
        m.contains("expected handler body (resume call form / halt form / pass / block), got"),
        "handler body integer diagnostics (actual: {})",
        m
    );
}

/// Negative 18: halt(expr) unclosed paren at eof.
#[test]
fn neg_halt_unclosed_paren() {
    let m = assert_grammar_err_parity(
        "handle (1) { gift(p, k) => halt(42, }",
        "halt missing right parentheses",
    );
    assert!(
        m.contains("expected )"),
        "halt missing right parentheses diagnostics (actual: {})",
        m
    );
}

/// Negative 19: expression-position halt — the positional word outside
/// the handler-body position fails closed (the macro-precedent E0001
/// family; `let x = halt;`).
#[test]
fn neg_expr_position_halt() {
    let m = assert_grammar_err_parity("let x = halt;", "expression position halt");
    assert!(
        m.contains("expected an expression, got"),
        "expression position halt diagnostics (actual: {})",
        m
    );
}

/// Negative 20: expression-position pass.
#[test]
fn neg_expr_position_pass() {
    let m = assert_grammar_err_parity("let x = pass;", "expression position pass");
    assert!(
        m.contains("expected an expression, got"),
        "expression position pass diagnostics (actual: {})",
        m
    );
}

/// Negative 21: statement-position halt inside a handler block (the
/// block-statement halt/pass is the registered out-of-domain — the
/// r128 resume-statement symmetric extension is a triggered follow-up;
/// the block's statement dispatch rejects the positional word).
#[test]
fn neg_block_statement_halt() {
    let m = assert_grammar_err_parity(
        "handle (1) { gift(p, k) => { halt }, }",
        "block body statement position halt",
    );
    assert!(
        m.contains("expected an expression, got"),
        "block body statement position halt diagnostics (actual: {})",
        m
    );
}

/// Negative 22: statement-position pass inside a handler block.
#[test]
fn neg_block_statement_pass() {
    let m = assert_grammar_err_parity(
        "handle (1) { gift(p, k) => { pass }, }",
        "block body statement position pass",
    );
    assert!(
        m.contains("expected an expression, got"),
        "block body statement position pass diagnostics (actual: {})",
        m
    );
}

/// Negative 23: top-level statement halt (outside any handle).
#[test]
fn neg_toplevel_halt() {
    let m = assert_grammar_err_parity("halt;", "top level halt");
    assert!(
        m.contains("expected an expression, got"),
        "top level halt diagnostics (actual: {})",
        m
    );
}

/// Negative 24 / semantic: pass with no outer handler — the re-performed
/// effect propagates past every frame and fails closed at runtime with
/// err_effect_unhandled (code 7) — the honest face of the propagation
/// semantics (a semantic negative through the production run chain).
#[test]
fn neg_pass_unhandled_effect_runtime() {
    let err = run_source(
        "fn ask() { perform gift(1, 2); }\nfn inner() {\n    handle ask() { gift(p, k) => pass, }\n}\ninner()",
        "passunhandled.ktf",
    )
    .expect_err("no outer handler pass must run-time failed");
    assert!(
        err.to_string().contains("unhandled effect") || err.to_string().contains("gift"),
        "pass no outer handler must hit err_effect_unhandled(actual: {})",
        err
    );
}

// ---------------------------------------------------------------------------
// r136 / 206-b — TD-033 group install (handle-multi-arm-design.md §8
// D11-D19): +8 positive : +24 negative = 1:3 (§9.4.3). The semantic
// difference anchors: sibling non-protection (a sibling tag performed
// inside a handler body propagates past the group — symmetric, the Koka
// reading), group consumption after resume (the remaining computation's
// sibling effects escape), and the S-expr handle-group syntax family
// (D17 diagnostics through the production .krf chain + the seed oracle).
// ---------------------------------------------------------------------------

/// Positive 9 / integration: the group dispatch — one effect, any-entry
/// match (the matched arm resumes; the unmatched arm never runs) ⇒ 15
/// (the corpus group_arm form through the production run chain).
#[test]
fn group_dispatch_single_effect_e2e() {
    let v = run_value(
        "fn ask() { perform giftB(7, 8); }\nfn guarded() {\n    handle ask() {\n        giftA(p, k) => resume(tail(p) + head(p)),\n        giftB(p, k) => resume(tail(p) + head(p)),\n    }\n}\nguarded()",
        "groupdispatch.ktf",
    );
    assert_eq!(
        v, "15",
        "group dispatch(giftB hit#two arm)must produce 15(actual: {})",
        v
    );
}

/// Positive 10 / integration: THE sibling non-protection anchor (TD-033's
/// semantic difference body, on the S-expr face where perform is an
/// expression): a sibling tag performed inside the matched arm's handler
/// body propagates PAST the group to the outer handler — under the r132
/// nested desugar the LATER-written arm's body was caught by the
/// first-written sibling (asymmetric); under group install the whole group
/// is consumed on the first dispatch, so the re-perform escapes (symmetric
/// non-protection — the Koka-style reading of [HANDLE-INSTALL]).
#[test]
fn group_sibling_nonprotection_e2e() {
    // giftB fires → arm B body performs giftA (the SIBLING tag) → escapes
    // the consumed group → the outer handler catches it (resume 4+3=7) →
    // arm B body value = 100 + 7 = 107 → group = 107 → outer +100 = 207.
    // Under the r132 nested desugar the sibling arm A would catch it
    // (body 5 → 100 + 5 = 105 → 205) — the values diverge, so the
    // assertion pins the r136 semantics.
    // E6 close-out fix (r154 / 224-c6): the two remaining bare-literal /
    // bare-expression arm bodies (the S-expr face allowed any expression —
    // the target Reader's handler-body grammar is resume/halt/pass/block)
    // ride the block arm-body form (r133 — the block admits plain
    // expression tails; values identical to the S-expr bodies).
    let v = run_value(
        "fn ask_b() { perform giftB(7, 8); }
fn ask_a3() { perform giftA(3, 4); }
fn guarded() {
    handle (1000 + ask_b()) {
        giftA(p, k) => { 5 },
        giftB(q, r) => { 100 + ask_a3() },
    }
}
fn outer() {
    handle (100 + guarded()) {
        giftA(p, k) => resume(tail(p) + head(p)),
    }
}
outer()",
        "sibling.ktf",
    );
    assert_eq!(
        v, "207",
        "same cell non-protect: giftB arm body inner perform giftA must exceeds group to outer(107 + 100 = 207 -- r132 nesting semantics is 205; actual: {})",
        v
    );
}

/// Positive 11 / integration: group consumption after resume — the
/// remaining computation's sibling effects escape the consumed group
/// (the r132 nested semantics protected them; the Koka-style shallow
/// multi-case reading does not — the continuation snapshot's whole group
/// goes inert, D14; the r132 corpus's both_arms shape lives on as the
/// E0007 honest face in Negative 42).
#[test]
fn group_consumption_after_resume_e2e() {
    // giftA fires → resume 30 → the remaining computation performs giftB
    // (the SIBLING tag) → the group is consumed → escapes to the OUTER
    // handler → resume 15 → guarded = 30 + 15 = 45 → outer = 145 (under
    // r132 nested the sibling arm B would catch it: 30 + 5 = 35 → 135).
    // E6 close-out fix (r154 / 224-c6): the never-firing sibling arm's
    // bare-literal body converted to the block arm-body form (the r136
    // divergence pinning is unaffected — the arm never runs under group
    // install; under the r132 nested reading it would yield 5 either way).
    let v = run_value(
        "fn ask_a() { perform giftA(10, 20); }
fn ask_b() { perform giftB(7, 8); }
fn guarded() {
    handle (ask_a() + ask_b()) {
        giftA(p, k) => resume(tail(p) + head(p)),
        giftB(q, r) => { 5 },
    }
}
fn outer() {
    handle (100 + guarded()) {
        giftB(q, r) => resume(tail(q) + head(q)),
    }
}
outer()",
        "consumption.ktf",
    );
    assert_eq!(
        v, "145",
        "group consume: resume after receive protect compute sibling sibling effect must exceeds group to outer(30 + 15 + 100 = 145 -- r132 nesting semantics is 135; actual: {})",
        v
    );
}

/// Positive 13 / integration: three-arm mixed group (resume / halt / pass
/// arms in one group) — the matched-arm discipline holds per arm (halt ⇒
/// the tail value; the other arms never run).
#[test]
fn group_three_arm_mixed_halt_e2e() {
    let v = run_value(
        "fn ask() { perform giftB(7, 8); }\nfn guarded() {\n    handle (100 + ask()) {\n        giftA(p, k) => resume(tail(p) + head(p)),\n        giftB(p, k) => halt(42),\n        giftC(p, k) => pass,\n    }\n}\nguarded()",
        "mixedgroup.ktf",
    );
    assert_eq!(
        v, "42",
        "three arm mixed combine group(halt hit)must produce 42(actual: {})",
        v
    );
}

/// Positive 14 / integration: group arm bodies with free-variable captures
/// (the per-arm H prototypes capture from the installing scope — the
/// three-prototype scheme generalized; the same capture mechanism as the
/// single-arm form, D15).
#[test]
fn group_arm_captures_e2e() {
    let v = run_value(
        "fn ask() { perform giftB(7, 8); }\nfn guarded(base: i64) {\n    handle ask() {\n        giftA(p, k) => resume(tail(p) + head(p)),\n        giftB(p, k) => { resume(tail(p) + head(p) + base) },\n    }\n}\nguarded(100)",
        "captures.ktf",
    );
    assert_eq!(
        v, "115",
        "group arm body from by variable capture must produce 115(8+7+100 -- actual: {})",
        v
    );
}

/// Positive 15 / cross-stage: the handle-group core program through the
/// production check face stays diagnostic-clean (hm.rs's HandleGroup arm:
/// per-arm binders → Dynamic, subexpression inference, result Dynamic —
/// the A4 discipline; check.krf's 'handle-group → unsupported skip —
/// krf ⊆ oracle maintained, zero friction). E6 close-out fix (r154 /
/// 224-c6): the S-expr `(handle-group ...)` source leg retired with that
/// face — the target surface has no handle-group statement (the Reader
/// GENERATES the core form from the >= 2-arm flat statement), so the
/// generated core node is reached through the flat multi-arm program; the
/// hm.rs HandleGroup arm is exercised identically.
#[test]
fn handle_group_check_cross_stage_clean() {
    let report = kerf_driver::check_source_recover(
        "fn ask() { perform giftB(7, 8); }\nfn guarded() {\n    handle ask() {\n        giftA(p, k) => resume(tail(p) + head(p)),\n        giftB(q, r) => resume(tail(q) + head(q)),\n    }\n}\nguarded()",
        "groupcheck.ktf",
    )
    .expect("recovery mode check does not short-circuit");
    assert!(
        report.diagnostics.is_empty(),
        "handle-group program check face must have zero diagnostics (actual: {:?})",
        report.diagnostics
    );
    assert!(
        report.proto_count + report.const_count > 0,
        "handle-group program must have a real compile artifact(actual: proto {} + const {})",
        report.proto_count,
        report.const_count
    );
}

/// Positive 16 / regression: the single-arm bytecode zero-regression —
/// the 1-arm target form still compiles to INSTALL_HANDLER (the D1
/// anchor: the degenerate keeps the r106 product; only the >= 2-arm form
/// switches to INSTALL_HANDLER_GROUP). Asserted structurally: the
/// compiled instruction stream of the 1-arm form contains no group
/// install, the 2-arm form contains exactly one.
#[test]
fn singlearm_vs_group_instruction_shapes() {
    use kerf_compiler::opcode::Op;
    let one_arm = "fn ask() { perform gift(7, 8); }\nfn guarded() {\n    handle (100 + ask()) { gift(p, k) => resume(tail(p) + head(p)), }\n}\nguarded()";
    let two_arm = "fn ask() { perform giftB(7, 8); }\nfn guarded() {\n    handle (100 + ask()) {\n        giftA(p, k) => resume(tail(p) + head(p)),\n        giftB(p, k) => resume(tail(p) + head(p)),\n    }\n}\nguarded()";
    let mut t = SymbolTable::new();
    let f1 = read_source(one_arm, 0, &mut t)
        .unwrap_or_else(|e| panic!("single arm parse failed:{}", e.message));
    let (p1, mut t) = compile_forms_seed(&f1, t, "single arm");
    let f2 = read_source(two_arm, 1, &mut t)
        .unwrap_or_else(|e| panic!("two arms parse failed:{}", e.message));
    let (p2, _t) = compile_forms_seed(&f2, t, "two arms");
    let count_ops = |p: &BcProgram, want_group: bool| -> usize {
        p.protos
            .iter()
            .map(|proto| {
                proto
                    .code
                    .iter()
                    .filter(|op| match op {
                        Op::InstallHandlerGroup { .. } => want_group,
                        Op::InstallHandler { .. } => !want_group,
                        _ => false,
                    })
                    .count()
            })
            .sum()
    };
    assert_eq!(
        count_ops(&p1, true),
        0,
        "single arm form not get appear INSTALL_HANDLER_GROUP(D1 zero regression)"
    );
    assert!(
        count_ops(&p1, false) >= 1,
        "single arm form must preserved INSTALL_HANDLER(D1 zero regression)"
    );
    assert_eq!(
        count_ops(&p2, true),
        1,
        "two arms form must exactly one clauses INSTALL_HANDLER_GROUP(group installation atomic emit)"
    );
    assert_eq!(
        count_ops(&p2, false),
        0,
        "two arms form not get residual INSTALL_HANDLER(nested desugar retired)"
    );
}

// ---------------------------------------------------------------------------
// r136 negatives — the S-expr handle-group syntax family (D17 diagnostics
// through the production .krf chain) + the group semantic negatives
// ---------------------------------------------------------------------------

/// Negative 41 / semantic: a group-unmatched effect escapes (the honest
/// face — a tag outside the group's entries propagates past it and fails
/// at the top level with err_effect_unhandled, code 7).
#[test]
fn neg_hg_unmatched_effect_runtime() {
    let err = run_source(
        "fn ask() { perform giftC(1, 2); }\nfn guarded() {\n    handle (100 + ask()) {\n        giftA(p, k) => resume(p),\n        giftB(p, k) => resume(k),\n    }\n}\nguarded()",
        "hgescape.ktf",
    )
    .expect_err("group outer effect must run-time failed");
    assert!(
        err.to_string().contains("unhandled effect") || err.to_string().contains("giftC"),
        "group outer effect must hit err_effect_unhandled(actual: {})",
        err
    );
}

/// Negative 42 / semantic (the group-consumption honest face): after the
/// first dispatch, a sibling effect in the remaining computation escapes
/// the consumed group — with NO outer handler this fails at the top level
/// (the r132 corpus's both_arms shape under the r136 semantics: the
/// E0007 escape is the DESIGN, not a defect — D14).
#[test]
fn neg_hg_sibling_escape_after_resume_runtime() {
    let err = run_source(
        "fn ask_a() { perform giftA(10, 20); }\nfn ask_b() { perform giftB(7, 8); }\nfn guarded() {\n    handle (ask_a() + ask_b()) {\n        giftA(p, k) => resume(tail(p) + head(p)),\n        giftB(p, k) => resume(tail(p) + head(p)),\n    }\n}\nguarded()",
        "consumed.ktf",
    )
    .expect_err("group consume after sibling sibling effect escape must run-time failed(no outer handler)");
    assert!(
        err.to_string().contains("unhandled effect") || err.to_string().contains("giftB"),
        "group consume after sibling sibling effect must hit err_effect_unhandled(actual: {})",
        err
    );
}

/// Negative 47: the target-face mirror of the duplicate-tag guard under
/// the group generation path (the D6 diagnostic fires identically for
/// the >= 2-arm form — the Reader's guard is unchanged by the mapping
/// flip; the dual-Reader parity face).
#[test]
fn neg_hg_target_duplicate_tag_parity() {
    let m = assert_grammar_err_parity(
        "handle (1) { giftA(p, k) => resume(1), giftB(p, k) => halt, giftA(p, k) => pass, }",
        "group produce become path duplicate label",
    );
    assert!(
        m.contains("handle arm effect name duplicate: `giftA`"),
        "group path duplicate label diagnostics (actual: {})",
        m
    );
}

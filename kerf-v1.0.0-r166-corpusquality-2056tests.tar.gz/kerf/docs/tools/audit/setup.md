# tools/audit — TD-040 语料质量审计与改写工具族

> r166 / R7+237 归档（R4——r165 仓外档 `/home/z/audit_tmp/` 随回退遗失的教训：工具必须仓内存续）

## 工具三件

| 工具 | 用途 | 用法 |
|---|---|---|
| `ktf_quality_audit.py` | 四维审计：fn 体块深度（fn 体 = 第 1 层）/ span / 短名率盘点 | `python3 tools/audit/ktf_quality_audit.py [root]`（默认 `crates/kerf-driver/src/bootstrap`——建议传绝对路径） |
| `flatten_else_if.py` | Track 1 堆叠 else 平链化：`else { if (C) {A} else {B} }` → `else if (C) {A} else {B}`（单语句校验 + fixpoint） | `python3 tools/audit/flatten_else_if.py <file.ktf> [--check]`（`--check` 只报位点不改写） |
| `reindent_ktf.py` | 括号深度再缩进规范化（平链化后阶梯缩进清零——纯前导空白变更零行为） | `python3 tools/audit/reindent_ktf.py <file.ktf> [--check]` |

## 度量口径（D1 单源）

- **层级**：fn 体块括号计第 1 层，内部每层嵌套块 +1（字符串/注释剥离后计数）
- **违例判据**：层级 > 4（体内嵌套 > 3 层）——TD-040 登记口径；严格口径 > 3 为参考面
- **span 违例**：> 80 行
- 行粒度计数：同行暂态深度不可见（Rust 门测试 n06 注记——python/Rust 双侧同口径构造性一致）

## 审计门（测试化承载）

`tests/v0/stage3/plan/ktf_quality_door_tests.rs`（runner 挂载）——Batch 1 边界冻结：
1. 平链位点零（防堆叠回归）
2. span>80 零（分拆门）
3. 深度>4 ≤ 38（Batch 2 可降不可升）

Batch 2 兑付后可将第 3 门升格为全零门（corpus-quality-batch-design.md §9.4）。

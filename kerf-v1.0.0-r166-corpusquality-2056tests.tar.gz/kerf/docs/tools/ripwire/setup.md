# ripwire agent 辅助工具环境安装脚本

> **Author**: kerf-dev-agent
> **Date**: 2026-10-09（r86 / 156-a——工具调研裁定与收录：用户指令①「查询并判断工具 https://github.com/redhat-et/ripwire 是否有助于当前项目的推进，如果有助于则结合 sop.md 中的工具流程收录到开发流程中」——裁定有助于 + §3.1 流程收录）
> **Version**: v0.1.0
> **Status**: Active（可选工具——agent 辅助；非构建依赖）

## 位置

`scripts/ripwire/setup.sh`（sop.md §3.1 归档规则）

## 用法

```bash
sh scripts/ripwire/setup.sh
# 安装后：export PATH="$HOME/.local/bin:$PATH"
```

## 工具定位（裁定记录）

**riepwire = "The ripgrep of AI context"**（redhat-et/ripwire，Apache 2.0，
C++23 单二进制零运行时依赖 CLI + 可选 MCP server）——给编码 agent
一个仓库的**排序确定性调用图**（定向图 / 调用者查询 / 爆炸半径 /
tests-to-run），替代 grep + 整文件阅读。

**收录裁定：有助于当前项目推进**（r86 三重实证）：

1. **实机可用**：v0.6.0 linux/x64 安装成功（官方一键脚本因 api.github.com
   限流 403，改走 release tar.gz 直链——setup.sh 内置该路径）；kerf 仓库
   `ripwire .` 实测 **358 文件 / 6090 符号 / 5562 边 / 1.1s 冷解析**
   （README 同类仓库口径 0.25-0.45s 同量级）。
2. **定向价值**：`ripwire . --for="cmd_test report rendering test entry"`
   精确命中当轮 TD-032 第三切口全部相关符号（`cmd_test`/`TestReport`/
   `test_source`/`dispatch_seed` + hops 调用边 + r79 rec 文档锚）——
   正是实施窗所需的影响面分析面。
3. **诚实边界契合**：输出显式披露 `unindexed="krf:15,lock:1"`——
   .krf 语言面不在其索引（S 表达式语法非其 24 vendored 文法成员）。
   该未覆盖面归项目自有单源（symbol.rs 关键字双源对账——原则 44
   grammar 单源纪律不受影响；Rust/docs/TOML 面由 ripwire 覆盖）。

## 分类口径（重要）

- **agent 辅助开发流程工具**（宿主侧——与 ripgrep 同类）：repo 导航 /
  影响面分析 / 变更审计辅助；**永不进入** Cargo 依赖、语言管线、自举链
  （§18.4 外部依赖审查表**不收录**本工具——该表只管构建/运行时依赖）。
- sop §3.1 项目工具表以「可选（agent 辅助）」行登记（v13.7）。

## 行为

1. 检查既有 `$HOME/.local/bin/ripwire`（已装则仅验证版本后退出）
2. release tar.gz 直链下载（curl/wget 自适应）
3. 解包安装 + chmod + 版本验证（§3.1 验证步骤）
4. 失败以非零退出码结束（不静默跳过）

## 常用命令（agent 工作流速查）

```bash
ripwire .                        # 仓库定向图（排序调用图——代替通读）
ripwire . --for="..."            # 任务定向查询（ranked 符号 + 调用边 + 文档锚）
ripwire . --expand=path::symbol  # 单符号展开（函数体 + 邻域）
ripwire . --pack-task="..."      # 任务上下文打包（token 预算内）
```

## 实测结果（2026-10-09 / r86）

- `ripwire --version` → `ripwire 0.6.0 (Release, GNU 14.2.1, emit=std::print, built_from=unknown)` ✅
- `ripwire .`（kerf 仓库）→ files=358 symbols=6090 edges=5562 shown=200
  est_tokens=10397，real **1.108s**，诚实披露 `unindexed="krf:15,lock:1"` ✅
- `ripwire . --for="cmd_test report rendering test entry"` → 置信 high，
  排名首列 `cmd_test`（cx=9 ccx=15 amp=68）+ `TestReport`/`test_source`/
  `dispatch_seed` + hops 调用边 ✅

## 维护注记

- 版本升级：改 setup.sh `VERSION` 常量（上游 CHANGELOG 语义化版本）。
- MCP server 形态（可选第二接口）未收录——CLI 面已覆盖 agent 工作流
  需要（README 自述「Reach for the CLI first — it is the cheaper
  interface」；MCP verb schemas 常驻 agent 上下文有 token 成本）。
- skills/hooks 目录（tar.gz 内含 Claude Code/Codex/Cursor 等 agent
  激活件）未启用——本环境 agent 工作流直接 CLI 调用即用。

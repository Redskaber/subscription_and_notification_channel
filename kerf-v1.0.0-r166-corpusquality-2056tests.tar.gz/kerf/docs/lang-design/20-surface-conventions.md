# 表面命名与库组织规范（2026 现代化设计方向）

> **Author**: kerf-doc-agent
> **Date**: 2026-11-26（**v1.43——r165 / 236-c TD-038 变参 rest 参数窗：§14 机制窗注记（非映射窗）**[`fn f(a: T, ...rest: T)`——rest 参数形{`...` 词法 = r129 第九皮肤映射既有 ident 载荷——本窗零皮肤字典新行：机制窗非映射窗{CoreExpr::Fn 加性字段 + BcProto rest_slot + VM 帧行为 + HM/check 面——非纯皮肤替换}}；Stx 签名沿标记符{`(define (f a ... rest) body)`——宏模板同款符号既有 intern 通道}；闭包面同权{`||(a: T, ...more: T)`——parse_typed_params 共用}；min-arity 语义{E0004 "expected at least N"——定参面逐字节维持}；2044 基线净 +32；设计单源 variadic-rest-design.md v1.0}]）；2026-11-26（**v1.42——r163 / 234-c 索引访问窗：§14 皮肤字典第十七映射行登记**[`coll[idx]` ↔ `(vector-ref coll idx)`——postfix 位索引中缀面开面{数据结构消费三角第三角——构造角 r160 + 解构角 r121 + 索引角 r163}；as-if-written 皮肤换骨架不变{原则 31：零脱糖零新原语零 CoreExpr/IR/操作码，8 原语不变性第四十五轮}；r138 D6 位置纪律 superseded{双括号面俱在域——primary 位字面量 + postfix 位索引}；D3 脱糖目标免 import 纪律{vector-ref 入 N1 第 42 名——r138 D4 律的索引面兑付}；D5 不可变维持{assign 位域外} + D6 诚实边界{pair-list 维持 nth 调用形 / Str 字符索引域外}；设计单源 index-access-design.md v1.0 D1-D10}]）；2026-11-25（**v1.41——r162 / 233-c TD-037 相等域窗：§14 皮肤字典运算符行域重指向注记**[`a == b` ↔ `(eq a b)` + `a != b` ↔ `(not (eq a b))`——既有 `==` 映射的脱糖目标由 `(= a b)` 换至跨域终名 `eq`（r102 命名谱系的对偶收口——`=` 符号名族休眠态：裸 `=` 词法为 Assign 不可直书，ordering 族 `< > <= >=` 维持其活跃中缀面）；eq 值律结构化分层{structural_eq 用户面单源——Pair/Vector 递归结构相等 + procedural 同一性 + 混合域静默 false——Python/JS 先例} + r138 eq? 律修订{Pair/Vector identity → 值相等} + 法修订涟漪九处；设计单源 equality-domain-design.md v1.0 D1-D10]**）；2026-11-25（**v1.40——r161 / 231-c 常量声明窗：§14 皮肤字典第十六映射行登记**[`const NAME = e;` ↔ `(define NAME e)`——as-if-written toplevel_let 孪生皮肤换骨架不变；只读语义闭环{项位 assign 拒收——Reader 顺序 const 集}；绑定性质轴收口{可变/只读双轴}；设计单源 const-declaration-design.md v1.0/v1.1]**）；2026-11-25（**v1.39——r160 / 230-c TD-036 元组表达式形窗：§14 皮肤字典第十五映射行登记**[`(a, b)` ↔ `(cons a b)`——as-if-written 皮肤换骨架不变；构造⟺解构对称缺口清偿{模式位 (p, q) r121 解构形的表达式位对偶}；D1-D10 裁定族；语料 pair 构造位迁移三件；设计单源 tuple-expression-design.md v1.0]**）；2026-11-24（**v1.38——r159 / 229-c 运算符面完备性清偿窗：§14 皮肤字典运算符行注记**[`%` 项级中缀主名 ↔ `(% a b)` 注册链闭合（r159 五点） + `mod` 调用形别名维持（D1——一个概念两个面，r102 命名谱系：符号名算术内建族收敛） + 语料现代化注记{higher_order `n % 2 == 0` + vector 块语句序列}；设计单源 operator-surface-parity-design.md v1.0]**）；2026-11-23（**v1.37——r158 / 228-c 顶层 let 现代化窗：§14 皮肤字典顶层值绑定行翻转[define(NAME, e) 调用形退役 → toplevel_let 现代形]（设计单源 toplevel-let-design.md v1.0）**）；2026-11-22（**v1.36——r157 / 227-b1 设计文档残留清偿窗：现行面 .krf→.ktf 引用修正 + 用户面记号桥（设计单源 design-docs-modernization-plan.md v1.0 U1/U3——D2 分流判据 J3）**）；2026-11-19（**v1.35——r154 / 224 E6 收口批种子域终局注记**：§14 皮肤字典种子域消费面终态——七件 .krf 种子平行件 oracle 删除{原则 41 拆除判据——parity 职责迁移 fixpoint/两路门 + 删除守卫} + target_reader.ktf → reader.ktf 更名收敛{§11 单一 Reader 终局} + DERIVED_SOURCES{七糖内联 S-expr 宏定义文本——§20.3 同类路径审查新发现面}程序化 Stx 构建转化{s/lit/lst 构建器 + 词法分类保真实证}——皮肤字典自此纯历史对账面{映射纪律四新锚 + 承载裁定六条落注 e6-conversion-guide.md}）；2026-11-17（**v1.34——r152 / 222-b 种子域行注记（Batch C 语法段增量纪律——Reader fixpoint 里程碑收口）**：§14 皮肤字典的种子域消费面扩展——生产 .ktf 读桥载荷{target_reader}目标语言化收官{S-expr 完全拆除窗 Batch C 语法段——target_reader.krf → target_reader.ktf 675-2984 行约 156 define → 4230 行全件；词法段 r151 + 语法段 r152 两轮分批全闭}新增映射纪律**转换纪律第四新锚两新面**：①**值位 let 表达式 define → 工厂函数 + define 调用双侧镜像**{kcell——目标面无 let 表达式不可直译，oracle 同轮规范化为 kcell-make 工厂形——closures.krf make-counter 捕获惯用先例}；②**if 臂值位 assign → do 包裹语句化双侧镜像**{.krf (assign cell v)→(do (assign cell v) nil) ↔ 目标面 {cell = v;} 语句块穿线 (do assign unit) 形——双侧同形→字节码全等}；既有纪律复用面{闭包表达式 (fn (op v) body)→||(op: T, v: T){body} + do/多表达式体→语句序列 + 深嵌套 let 穿线 + n 元 and/or 右嵌套 + eq/= 分工}；门 X 全文件字节码 parity + 门 Z fixpoint 自解析{2044 基线净 +32}；桥语法入口切换 .krf→.ktf + 桥双状态收敛{用户 r152 指令① Rust 端整合腿——单一 reader.ktf 端态登记 s-expr-removal-plan v1.3 §11}）；> **Date**: 2026-11-16（**v1.33——r150 / 220-b 种子域行注记（Batch B 增量纪律）**：§14 皮肤字典的种子域消费面扩展——HM 生产判定面载荷{check}目标语言化{S-expr 完全拆除窗 Batch B——check.krf → check.ktf 1285 行}新增两条映射纪律：①**关键字符号 TAG 规范化**（'fn/'if/'let/'module/'require/'perform/'handle 在目标面为保留字不可入表达式位——`quote(fn)` 解析失败；双侧同形化为 FN-TAG..HANDLE-TAG `string-to-symbol` 常量——r116 第二规范化先例镜像；语义保持 = VM eq 按名比较）；②**'nil 字面量化位**（S-expr 面 `'nil` 读期字面量化 → Nil 字面量 PushNil；目标面 `nil` 为普通标识符，`quote(nil)` 产出 SymLit 符号常量——正确映射 = `quote(())`{目标面 Unit 记号 = Nil 字面量——expander.ktf:1295 先例}）；门 B 载荷字节码 parity = 规范化 oracle ↔ 转写件指令序/常量池/proto 形状/全局引用面全等{seed_ktf_parity_tests 64 case——1980 基线净 +32}）；> **Date**: 2026-11-16（**v1.32——r149 / 219-b 种子域行注记**：§14 皮肤字典的种子域消费面扩展——构建系统五面载荷{build/cli/test/test_runner/cache}目标语言化{S-expr 完全拆除窗 Batch A——五件 .krf→.ktf 转写经既有映射族{cond→if-else 右递归 + n 元 or→显式右嵌套 + 'sym→quote(sym) 调用形 + mod 保留调用形 + define(NAME,e) 调用形}零新映射族——纯消费轮}；载荷字节码 parity 门 X ×5{跨文本解析口径——1948 基线净 +32}）； 2026-11-16（**v1.31——r147 extern 符号空间别名窗皮肤字典第十三映射域扩展注记（§14 行更新——声明位别名臂 + 双名分离 + 替换语义 + 反遮蔽扩展；设计单源 extern-alias-design.md v1.0）**）；2026-11-14（**v1.30——r143 handle 表达式位窗皮肤字典 D2 handle 映射位域扩展注记（§14 行更新——语句位 + 表达式位共享一形：primary 位同构分派[r110 if / r121 match 先例第三例]；设计单源 handle-expr-position-design.md v1.0）**）；2026-11-10（**v1.29——r138 TD-002 向量值类型窗皮肤第十四映射族增补（§14 皮肤字典新一行——逗号省略映射 + 双侧脱糖 + 值模型；设计单源 vector-value-design.md v1.0）**）；2026-11-09（**v1.28——r137 TD-026 行① FFI extern 声明族窗皮肤第十三映射族增补（§14 皮肤字典新一行——extern 声明 → 扁平符号空间声明 + 调用位 FFI 发射；设计单源 ffi-language-surface-design.md v1.0）**）；2026-11-09（**v1.27——r136 TD-033 组安装语义窗皮肤字典第十二映射族行翻转（§14 行更新——多臂 [>=2] `handle e { A(p,k) => b₁, B(p,k) => b₂, }` → `(handle-group (A (p k) b₁') (B (p k) b₂') e')` 组安装核心形式[嵌套语义仍可经显式嵌套手写——设计单源 handle-multi-arm-design.md v1.1 §8 D11]；Keyword 27 名 + INSTALL_HANDLER_GROUP #46 四方同步）**）；2026-11-08（**v1.26——r134 use 域外二项清偿窗皮肤字典第十一映射域扩展注记（§14 行更新——use_tree `as` 成员重命名三元组 + module 头部选择形受理 + D3/D6 域外注记翻转）**）；2026-11-07（**v1.25——r133 嵌套块内 resume 窗皮肤字典 D2 handle 映射体域扩展注记（§14 行更新——嵌套块语句位/尾位 κ 穿线 + 域外注记翻转）**）；2026-11-06（**v1.24——r132 handle 多臂 / halt / pass 窗皮肤第十二映射族增补（§14 皮肤字典新一行——多臂嵌套脱糖 + halt 尾值糖 + pass 重构三子形共一条映射链）**）；2026-11-05（**v1.23——r131 use 声明 / `::` 导入树窗皮肤第十一映射增补（§14 皮肤字典新一行）**）；2026-11-04（**v1.22——r130 import as 别名窗皮肤第十映射增补（§14 皮肤字典新一行）**）；2026-11-03（**v1.21——r129 宏面语料窗宏定义皮肤第九映射增补（§14 皮肤字典新一行）**）；2026-11-03（**v1.20——r128 语料族深度化窗 handler 块体 resume 语句映射增补（§14 皮肤字典新一行——D2 handle 映射体域扩展）**）；2026-11-03（**v1.19——r125 CLI 双入口窗 require 声明皮肤第八映射增补（§14 皮肤字典新一行）**）；2026-11-02（**v1.18——r122 match 实施批 M-2 增补（皮肤字典第七映射——match 臂 → cond/let 脱糖）**）；2026-10-24（**v1.16——r110 切换窗步③ 第二批增补（皮肤字典三条）**）；2026-10-23（**v1.15——r109 切换窗步③ 首批增补（皮肤字典二条）**）；2026-10-20（**v1.14——r104 第二十五轮整合定稿（EBNF 定稿子窗）**：§14 目标语法定稿域表面登记——同步自 stage0.md v8.4 §9.26）；2026-10-10（**v1.12——r91 第十九轮吸收（next13.md）**：§13 增记[EBNF v5 分层语法与 Level 3-4 脱糖备选优先级]——同步自 stage0.md v7.8 §9.20.7）；2026-10-10（**v1.11——r89 第十八轮吸收（next12.md 追加段）**：§12 增记[EBNF v4 关键字张力与脱糖备选路径——窗内双判据裁定 + 宏层糖展开零关键字候选]——同步自 stage0.md v7.7 §9.19.7）；2026-10-10（**v1.10——r88 第十七轮吸收（next12.md）**：§12 增记 15 关键字演进[17→15：impl 并入 type + linear 降为类型标注——关键字减二表达能力不减；EBNF v3 第二份骨架语料]——同步自 stage0.md v7.6 §9.18.5）；2026-10-09（**v1.9——r84 第十六轮吸收（next11.md）**：§12 增记 17 关键字与宏层登记[目标语言关键字面收敛 17 + 宏层熟悉语法 + Stage 0 25 关键字正交分层]——同步自 stage0.md v7.5 §9.17.2）；2026-09-24（**v1.6——r67 原语集真值对账轮**：§1.1 审查表 set! 行时名 gloss + §4 适用域注换 r43 后终态 + §5 R5 行更名已执行注 + §6.3 头部/首句/Keyword 计数换终态）；2026-09-23（**r64 全文件集审计**：①§10 表行标记精确化「§9.3/§9.4」→「§9 第 3 条/第 4 条」（§9 为编号列表非子节——列表项缩记作节号致跨文件引用歧义[21/22 侧引用同步精确化]）②Date 行 v1.1/v1.2 条目次序归位[原缀于 v1.0 后]）；2026-09-15（**v1.5：r42 / 63-b 移除轮 S1——E5 窗表面腿**：开窗设计 = [e5-removal-round-plan.md](../develop/v0/stage-3/e5-removal-round-plan.md)（入口信号四核对 + parity 链保护方案 + 三腿分步——23 §2.2 E5 行开窗合法）；旧名 27 件退役（E0021 + 负例组 27 名全覆盖）；弃用生命周期完整走完（引入 v0.5 → 默认 v0.6 → 弃用 v0.7 → **移除 v0.9**——23 §3.4 四阶段机器执行）；TD-027 三腿全清偿）；2026-09-14（**v1.2 修正——r34 / 55-a 设计缺陷深度审计收敛轮**：设计栈三层 → **四层**（增 [23-演进治理](./23-evolution-governance.md)——演进时机/准入/生命周期/收敛证明的治理层；本文件 §7 批次表的时机治理由 23 §2.2 触发表单源承载）+ §11 增五行（21 v1.1 组合闭包/编译期权威/三轴坐标系 + 23 演进治理/码位预登记））；2026-09-13（**v1.1 修正——r33 / 54-a 能力架构深度设计轮**：驱动源 = 用户审查指令「整体是否需要清晰的能力定位、能力边界、能力职责、能力正交……对原语级别的内容不是简单的重命名」——①§1.2 失实叙述修正（「内部已现代」→「内部已冻结演进方向」——原语级迁移是 Stage 3 结构重构非已完成改名，六类迁移分类学归档于 [21 §5](./21-capability-architecture.md)）；②§5 命名空间方向概要与 [22-命名空间设计](./22-namespace-design.md) 机制层分工接线（本文件持模块树与导出清单，22 持五层层级/解析/遮蔽/权限矩阵——v0.6 批次 M 输入由 22 承载）；③§5.3 对齐表述精确化（「同一语义」→「边界对齐不变量 + 机制分工」，修正依据 [21 §4.3](./21-capability-architecture.md)）；④§11 完整性核查补 21/22 两行）；2026-09-12（**v1.0 首版——r32 / 53-a 表面现代化审查轮交付**：驱动源 = 用户审查指令「实现端不要停留在 Lisp 家族 1970 年代表达（内建函数命名/行为模式/编码习惯/组织思路——如 `命名?`、`命名->命名`）」+ 全项目扫描实测（见 §1））
> **Version**: v1.42（**r163 / 234-c——§14 第十七映射行：索引访问 postfix `coll[idx]`**：`coll[idx]` ↔ `(vector-ref coll idx)`[as-if-written 皮肤换骨架不变——原则 31；恰一索引表达式{空/多参 fail-closed E0001} + 嵌套链式 postfix 尾循环自然组合 + D3 脱糖目标免 import{vector-ref 入 N1 41→42} + D5 不可变维持{assign 位域外} + D6 诚实边界{pair-list nth 调用形维持 / Str 字符索引域外}]；r138 D6 位置纪律 superseded；1979 基线净 +31；设计单源 index-access-design.md v1.0}）；v1.41（**r162 / 233-c——§14 运算符行域重指向：相等域 `==`/`!=` → `eq`**：`a == b` ↔ `(eq a b)` / `a != b` ↔ `(not (eq a b))`{皮肤域重指向——非新增映射行；双 Reader 单点换目标} + eq 值律结构化分层{structural_eq——Pair/Vector 递归结构相等[spine 迭代] + procedural 同一性维持 + 混合域静默 false[1 == "1" ⇒ false——r161 基线下 E0004/E0005 双诊断面退役]} + r138 eq? 律修订{Pair/Vector per-instance identity → 值相等——neg23 锚翻转} + `=` 内核基座休眠态申报 + ordering 族维持 num/str 域{TD-011 r24 律零触碰} + ktf_equality_domain_tests 32 case 门{8 正 + 24 负 1:3} + 增长签名锚 215/504/246；1948 基线；设计单源 equality-domain-design.md v1.0}）；v1.40（**r161 / 231-c——§14 第十六映射行：常量绑定 const**：`const NAME [: T] = e;` ↔ `(define NAME e')`[toplevel_let as-if-written 孪生——第十六皮肤映射；项位 assign 拒收只读闭环 + const mut 矛盾 + 单绑定封顶 + 块位 domain-out 四诊断双 Reader 字节级 parity；1916 基线]）；v1.39（**r160 / 230-c——§14 皮肤字典第十五映射（元组表达式）**：`(a, b)` ↔ `(cons a b)`——as-if-written 皮肤换骨架不变[原则 31：零脱糖零新原语零 CoreExpr/IR/操作码，expander/compiler/HM/VM 全链零触及，8 原语不变性第四十二轮]；构造⟺解构对称缺口清偿[模式位 (p, q) r121 解构形的表达式位对偶——TD-036 触发条件①用户指令直接开窗]；二元封顶 D2[模式位 r121 裁定镜像——3+ 元 fail-closed 专用诊断] + 单元素分组/Unit 维持 D3 + 尾逗号 fail-closed D4[r138 同律] + cons 调用形维持 D5[内核聚合基座名 + list 链惯用形——能力补齐非退役] + HM/check 零变更 D6[BUILTIN_SIGS (Any,Any)→Pair 既有消费] + 双 Reader 错误面字节级 parity D7 + 语料迁移 D8[match + gc_stress 双件离散 pair 构造位 15 处——输出 parity 逐字节] + EBNF/皮肤/术语三件 D9[02 v7.28 同轮] + Span 契约 D10[合成 cons 符号 = `(` Token 本位——r158 合成 define 先例]；ktf_tuple_expr_tests 32 case 门[8 正 + 24 负 1:3——含 as-if-written 字节码全等门 + 构造⟺解构对称 E2E + 全位置形 + 模式位回归锚] + 增长签名锚重校准[reader.ktf payload 211/494/242] + 1884 基线；设计单源 tuple-expression-design.md v1.0；产生式 = [02 §8.13.1a](./02-syntax-model.md) v7.28 同轮）；v1.38（**r159 / 229-c——§14 皮肤字典运算符行注记**：`n % 2` ↔ `(% n 2)` 中缀主名（注册链五点 r159 闭合——N1 40→41 / BUILTIN_SIGS 62→63 / check.ktf TC_SIGS 行 / anf "%"→APrim::Mod / families 锚）+ `mod(n, 2)` 别名维持{种子域零扰动——自举 parity 锚保护} + ktf_percent_operator_tests 32 case 门 + 语料现代化两件{用户面 only}；设计单源 operator-surface-parity-design.md v1.0）；v1.37（**r158 / 228-c——§14 皮肤字典顶层值绑定行翻转（S-expr 旧时代 define(NAME, e) 调用形退役）**：`(define NAME e)` ↔ `let NAME = e;`——被退役调用形经统一 list 结构合成的同一核心形[皮肤换、骨架不变——原则 31：零脱糖零新原语，expander/compiler/HM/VM 全链零触及，8 原语不变性第四十轮]；mut/类型标注解析后剥离[fn_decl 先例]；单绑定封顶[块级 let_stmt 多绑面维持]；项位 = 顶层 + module 项位[parse_item 分发——声明族对称]；define(NAME, e) 项位 fail-closed 现代化诊断[r130 Span 先例] + 块位/表达式位普通调用语义维持[诚实边界]；双侧 Reader 已实施[种子 parse_toplevel_let + 镜像 parse-toplevel-let——parse_let_binder 共享] + ktf_toplevel_let_tests 32 case 门[8 正 + 24 负 1:3] + 语料迁移[bootstrap 七件 + examples 四件 + tests 42 文件 + web 预设——R4 工具 scripts/r158-toplevel-let 两遍]；闭包 EBNF 复审维持裁定 K-1[四候选对照——现行 `|| (params) -> eff { body }` 胜出]；设计单源 toplevel-let-design.md v1.0；产生式 = [02 §8.13.1a](./02-syntax-model.md) v7.26 同轮]）；v1.36（**r157 / 227-b1**：U1 ×3 点 + U3 桥注 ×1——纯文档轮零代码变更，[design-docs-modernization-plan.md](../develop/v0/stage-3/design-docs-modernization-plan.md) v1.0）；v1.32（r149 S-expr 完全拆除窗 Batch A 种子域行——五载荷 .ktf 化纯消费零新映射族）；v1.31（**r147 / 217-c——§14 皮肤字典第十三映射域扩展注记（r147 extern 别名臂）**：`(extern write-stdout as ws (str) int)` ↔ `extern write_stdout as ws(str) -> int;` 六元素形——import-as 家族在 extern 声明族上的同构延拓；双名分离 D3[externs_for_compile 对 `(intern(local), Rc(name))`——IR extern_face 既有分离维度启用，IR/编译器/VM 零机制变更；注册/契约/能力/运行表四面恒按 underlying 匹配] + 替换语义 D4[local 入可见面、underlying 直写 E0022——r134 member-rename D8 反向锚同构] + 自别名拒收 D5 + 反遮蔽扩展 D6[local 入 define/import/N1/既有 extern 可见名碰撞面] + 能力门不感知别名 D7[按 underlying——r135 D13 行权线：改名不产生新能力面] + HM/check A4 Dynamic 维持 D8 + use 选择形接驳维持域外 D9[扁平空间无模块面——宪制；虚拟模块面 = Stage 2+ 命名空间演进触发]；bootstrap 编译桥 CC_EXTERN 协议扩展[(local flat) 对——rv_loop extern_lookup + SymLit 载 flat[Rust 侧 IrVar::Extern(flat) 镜像——原则 31]]；双侧落地[种子 parse_extern_decl KwAs 前置臂 + 镜像 extern-alias-name 新函数 + alias-rec 双 Token 穿线] + ktf_extern_alias_tests 32 case 门[8 正 + 24 负 1:3——含双 Reader 正典渲染/错误面 parity ×3 + 替换语义反向锚 + 自别名 + 反遮蔽四路 + 能力/契约/可用性按 underlying + 位形纪律] + 语料对 ffi_alias.{ktf,krf}[⇒ 9 双面——语料族 14:14]；开窗依据 = M1 指令开窗第五十二例[ffi §7 末行「用户指令或语料信号」唯一可行行]；设计单源 extern-alias-design.md v1.0；产生式 = [02 §8.13.1a](./02-syntax-model.md) v7.24 同轮]）；v1.30（**r143 / 213-c——§14 皮肤字典 D2 handle 映射位域扩展注记（r143）**：语句位 + 表达式位共享一形——`primary → handle expr handle-arms`（r110 表达式位 if / r121 match 值形同构分派第三例——parse_primary 前置分派通道）；五位置形全开放[let 值位 / 函数实参位 / if 条件位 / 嵌套 protected 位 / 多臂 group 位]——脱糖产物与语句位逐字节同构{单臂 `(handle tag ((p k) body) protected)` / ≥2 臂 `(handle-group ...)`——D2 零机制变更：expander/compiler/HM/VM 零触及，8 原语不变性第二十五轮；CLI 双入口双面表达力 parity 缺口第五连清偿（r125/r130/r131/r132 后续）；张力探针五连实证：S-expr 面三位形全合法（⇒100/101/11）vs 目标面 E0001 fail-closed——探针锚正式化]；双侧落地[种子 parse_primary KwHandle 前置臂 + 镜像 parse-primary cond 臂] + ktf_handle_expr_position_tests 32 case 门[8 正 + 24 负 1:3——含五位置形 E2E + 跨面值 parity 327 + 语句位零回归复锚 217/540 + 双 Reader 正典渲染 parity + 位域维持电池] + 语料对 effect_handle_expr.{ktf,krf}[⇒ 327 双面——语料族 13:13]；设计单源 handle-expr-position-design.md v1.0；产生式 = [02 §8.13.1a](./02-syntax-model.md) v7.23 同轮]）；v1.29（**r138 / 208-c——§14 皮肤字典第十四映射族（向量字面量）**：`[a, b, c]` ↔ `[a b c]`——逗号省略映射（目标面 primary 位受理 + 尾逗号 fail-closed + postfix 索引域外维持 D6）；双侧脱糖 D2（表达式位 vector 应用形 + quote 位递归字面量脱糖——零 CoreExpr/IR/操作码）；值模型 D3（Value/HeapObj::Vector 元素槽位制 + GC children 臂）；五内建族 D4（kerf-vector 限定模块 + N1 可见面扩容{vector/is-vector}）；渲染 D8 括号形可回读；双侧落地 + ktf_vector_value_tests 36 case 门[9 正 + 27 负 1:3] + 语料对双面 ⇒ 9；开窗 = M1 指令开窗第四十三例[门控任务 #5 路径]；设计单源 vector-value-design.md v1.0；产生式 = 02 §8.13.1a v7.22 同轮]）；v1.28（**r137 / 207-c——§14 皮肤字典第十三映射族（FFI extern 声明）**：`extern write_stdout(str) -> int;` ↔ `(extern write-stdout (str) int)`——顶层声明家族第四员[import/export/require 后——裸 kind 词 + 逗号分隔 + 强制 `;`，require 先例同构]；声明位 → 驱动面五重校验[形状/可注册性 E0012 编译期/契约 E0026/查重/能力 E0006——write-stdio 与 io 语言通道同享授权令牌{r65/118-a}]后剥离[expander 零变更]；调用位 → 分辨层扁平符号空间解析[Symbol 名字匹配卫生不可穿透——ffi-ownership-model §4] → 编译臂双侧发射[PushConst SymLit + 实参 + Op::CallExternal #43 冻结四方同步维持]；值位 fail-closed[E0026「仅调用位」]；运行入口表构造[声明 ∩ 在册可注册表 write-stdio 唯一条目 ∩ 能力授予 → run_program_with_externs——空表 = 历史行为逐位不变{原则 27}]；kind 三词表[int/str/ptr——ExternKind 消费子集语言面同构{D1 三词封顶}]；Keyword::Extern 第 28 名共享保留域[E0020 面双侧扩展]；双侧落地[种子 parse_extern_decl + 镜像 parse-extern-decl 族] + ktf_extern_decl_tests 32 case 门[8 正 + 24 负 1:3——含 E0011 运行期窗口协议传播 + 双 Reader parity] + 语料对 ffi.{ktf,krf}[⇒ 9 双面——真实宿主 I/O 往返]；开窗依据 = 用户 r137 指令①「继续推进 目标语言设计的实现窗」行权（M1 指令开窗第四十二例——TD-026 行① Stage 3 锚）；产生式 = 02 §8.13.1a v7.21 同轮]）；v1.26（**r134 / 204-b——§14 皮肤字典第十一映射域扩展注记（r134）**：use_tree `as` 成员重命名三元组{`use m::{a as x};` ↔ `(import m (a as x))`——选择列表平铺三元组 + 替换式注入语义[renamed 替换 underlying 平铺注入位——E0022 反向锚精确] + 运行时绑定注入[globals[renamed] = underlying 分派体 Rc 共享——与限定名注册同构] + HM A4 Dynamic[renamed ∉ 签名表双侧保守 Dynamic 零误报] + 同域查重 D7[renamed 键 ∪ aliases 键] + io/prelude 域外 D8[门控/重导出面 fail-closed 前置]} + module 头部选择形受理{r131 D6 域外边界退役——expander 头部扫描双侧 + driver collect_module_header_imports 共用单点}；设计单源 member-rename-design.md v1.0 D1-D10[归一化方案 B 运行时注入——alias 重写方案不适用于平铺名]；双侧 Reader + driver 消费链 + ktf_member_rename_tests 32 case 门[8 正 + 24 负 1:3——含 E0022 反向锚 + HM A4 check 零诊断] + ktf_use_decl_tests 锚翻转三组；产生式 = [02 §8.13.1a](./02-syntax-model.md) v7.19 同轮**）；v1.25（**r133 / 203-c6——§14 皮肤字典 D2 handle 映射体域扩展注记（r133）**：resume 作用域穿线嵌套块——if 臂块/闭包体/嵌套 handle 臂体内的语句位/尾位全开放（innermost 包裹臂 κ 注入——S-expr 词法作用域镜像；设计单源 nested-resume-design.md v1.0 D1-D10；双侧 Reader[种子 handler_k 字段 save/restore + 镜像 kcell 闭包胞穿线] + ktf_nested_resume_tests 32 case 门[8 正 + 24 负 1:3——含嵌套等价字节码全等门] + 语料对 effect_nested_resume.{ktf,krf}[⇒ 540 双面]；**同窗 VM P1 清偿** = 续体恢复 handler 边界截断[ContinuationValue.boundary——深帧非尾 resume 陈旧 H 执行帧残留清偿——isoB 锚]；嵌套块域外注记翻转见 §14 行更新；产生式 = [02 §8.13.1a](./02-syntax-model.md) v7.18 同轮**）；v1.24（**r132 / 202-c handle 多臂 / halt / pass 窗——§14 皮肤字典第十二映射族行**：`handle e { A(p,k) => b₁, B(p,k) => b₂, }` 多臂 → 嵌套单臂 handle 脱糖{先写臂外层——D2/D9} + `halt`/`halt(v)` → 尾值{nil/expr——D5} + `pass` → `(perform (cons (quote T) p))`{D4}——expander/compiler/VM 零变更{原则 31}；halt/pass = 目标面本地关键字{resume 同型——S-expr 面零扰动 = r129 macro 先例第 2 连}；设计单源 handle-multi-arm-design.md v1.0；同窗 fvo P1 缺陷清偿**）；v1.23（**r131 / 201-c——§14 皮肤字典第十一映射（use 声明 / `::` 导入树）**：`use kerf_string::{append};` ↔ `(import kerf-string (append))`——**选择形（r50/D65 S-expr 面既有）的目标面首表达**{目标面前此不可表达的选择性导入——CLI 双入口双面表达力 parity 缺口清偿}；全族映射{bare `use mod;` → `(import mod)` 全量 / `use mod as a;` → `(import mod as a)` 别名[与第十映射同 Stx——D5 拼写冗余合法性] / `use mod::{m1, m2};` → `(import mod (m1 m2))` 选择 / `use mod::{m} as a;` → `(import mod as a (m))` 复合 / `use a, b::{x};` → `(import a b (x))` 多路径}；零脱糖零新原语（driver collect_import_items/face_selects/verify_import_face E0024 臂全链零变更——原则 31）；`::` 路径树与单层模块名映射裁定{D1：名位受理 Ident|Path + 多段路径 E0019 编译期拒绝——22 §7 单层执法面}；成员重命名 = D3 域外专用诊断；`use` = 目标面本地关键字{S-expr 面 `use` 普通标识符——探针实证 (define use 42) ⇒ 84}；双侧落地[种子 parse_use_decl + 镜像 parse-use-decl 函数族十一函数] + ktf_use_decl_tests 32 case 门[8 正 + 24 负 1:3]；开窗依据 = 用户 r131 指令①「继续推进 目标语言设计的实现窗」行权（成熟度匹配排序首位——设计完备度最高[S-expr 面选择形既有 + driver 消费形在位 + EBNF v9 定稿产生式在位]）；产生式 = 02 §8.13.1a v7.16 同轮**）；v1.22（**r130 / 200-b——§14 皮肤字典第十映射（import as 别名）**：`import kerf_string as str;` ↔ `(import kerf-string as str)`——别名对符号逐一同构 S-expr 三形态导入[r40 M2 / 22 §8 R-N5]；`as` 入 Stx 为普通符号（collect_import_items 按名匹配零变更）；`alias::member` ↔ `alias/member` 限定引用（`::`→`/` 既有映射 + rewrite_alias_refs 编译期归一）；零脱糖零新原语（原则 31）；`as` = 语境修饰词位（目标面 KwAs）；双侧落地[种子 parse_import_decl 别名臂 + 镜像四函数] + 32 case parity 门[8 正 + 24 负 1:3]；名位 `as` 专用诊断 + **同窗潜伏缺陷清偿**[名位 as 诊断 Span 种子/镜像错位——双侧统一为 as 本位] + **同窗测试锚翻转**[switch_corpus_parity m3]；开窗依据 = 双面表达力 parity 缺口（CLI 双入口架构——r125 require 同型）；产生式 = 02 v7.15 同轮）；v1.21（**r129 / 199-b——§14 皮肤字典第九映射（宏定义）**：`macro NAME [ "(" [字面量集] ")" ] "{" { 模式 => 模板 [","] } "}"` ↔ `(define-syntax NAME (syntax-rules (lit...) (模式 模板)...))`——臂结构（`=>` = 既有 FatArrow；尾臂逗号可省——match 臂先例）+ 宏名首元素 Reader 注入（r128 resume-k 先例同构）+ 模板 = 块或表达式（调用实参省略号无条件吸收——非模板位错误面同形）；零脱糖零新原语（原则 31）；`macro` = 目标面本地关键字（不入共享 Keyword/E0020 域——原则 27 加性实例）；`...` = ident payload 三连点前瞻（S-expr 面符号同构）；双侧落地 + 37 case parity 门；**同窗 P1 缺陷清偿** = check 恢复模式宏注册丢失[expander 入口加性拆分]；产生式 = 02 §8.13.1a v7.14 同轮）；v1.20（**r128 / 198-b——§14 皮肤字典 handler 块体 resume 语句映射（D2 handle 映射体域扩展）**：`(do A (resume k v))` ↔ `{ A; resume(v) }`——处理器臂块体顶层语句/尾位 resume 调用形{k 由臂绑定注入——用户永不书写}；零脱糖零新原语（Stx = 同一 `(do A' (resume k v'))` 三元 resume 核心形式——原则 31）；开窗依据 = effect_stress 语料翻译暴露的真实文法缺口[分配后恢复不可表达——直位 `=> resume(v)` 无语句序列承载]；双侧落地[种子 parse_handler_block/parse_resume_call + 镜像 parse-handler-block/parse-resume-call] + ktf_stress_corpus_tests 32 case 门[双 Reader 正典渲染/错误面字节级 parity]；嵌套块内 resume = 登记域外 fail-closed 诚实边界；产生式 = [02 §8.13.1a](./02-syntax-model.md) v7.13 同轮]）；v1.19（**r125 / 195-a——§14 皮肤字典第八映射增补（require 声明）**：`(require io write)` ↔ `require io, write;`——顶层声明家族同族裸名形[import/export/require 一族——逗号分隔 + 强制分号]；逐符号同构 S-expr 形{零脱糖零新原语——Stx 即同一 list，能力门控 E0006 消费面唯一}；双侧落地[种子 target.rs parse_require_decl + 镜像 target_reader.krf parse-require-decl 三函数]；块内/表达式位维持既有 fail-closed[E0018 位置纪律 Stx 层双皮肤共享]；开窗依据 = CLI 双入口窗 E2E 发现的真实缺口[目标语法无 require 形态则 .ktf 程序无法声明 IO 能力]——r125 / 195-a 双入口语义完整性必要件）；v1.18（**r122 match 实施批 M-2——§14 皮肤字典第七映射**：match 臂结构 → cond/let 链[match-design.md v1.2 §3.4 正典产物形状单源——temp 单次求值 + 均匀 if 链 + 路径提取 + 守卫 and+let 形 + error 兑底；零新原语零通道] + Keyword::Match 入面[26 关键字——E0020 面双侧扩展，层次关系行同步] + §12 D2 第七映射行）；v1.17（**r111 第二十六轮吸收——§15 信息表面登记态**[info handle/emit/observe/|> 四族登记态 + 位形限定词候选 + LSP 语法非 kerf 表面——同步自 stage0.md v8.5 §9.27.4]）；v1.16（**r110 切换窗步③ 第二批增补**：§14 皮肤字典新三条——多绑定 let 双面映射[`(let ((a e) (b e)) 体)` ↔ `let a = e, b = e; 体`——D61 暂存法链 parity 载体；02 §8.13.1a 产生式同轮] + 符号字面量调用形[`'sym` ↔ `quote(sym)`——零 Reader 变更] + 顶层值定义调用形[`(define NAME e)` ↔ `define(NAME, e);`——零 Reader 变更；reader.ktf 第 2 件]）；v1.15（**r109 切换窗步③ 首批增补**：§14 皮肤字典新二条——命名双面映射[`-` ↔ `_` 词分隔] + N1 模块生产面[`module { import/export 头部 }`——02 §8.13.1a 产生式同轮] + .ktf 扩展名登记[切换窗期语料语法区分——preamble.ktf 首件]）；v1.14（**r104 第二十五轮整合定稿（EBNF 定稿子窗）**：§14 目标语法定稿域表面登记[EBNF v9 定稿位指针 + 皮肤字典定稿域扩充四条 + 22 定稿词面与 57 内置映射层次关系——同步自 stage0.md v8.4 §9.26.9]）；v1.13（**r102 / 172-b 语料面命名清偿——用户指令专项窗**：§6.5 机会主义迁移条款终结[残余 7 名专项窗清偿——`lbld-imports-prelude?`→`lbld-is-imports-prelude` + `num->str`/`int->str`→`int-to-string` 同概念统一 + `chars->str`→`chars-to-string` + `datum->value`→`datum-to-value` + `list->pairs`→`list-to-pairs` + `params->bound`→`params-to-bound`；闭合守卫 `bootstrap_naming_modern_closed` 落位——10 .krf 定义名 `?` 尾缀零 + 全文 `->` 零容忍[含注释面]；num->str 终名裁定 = R1+R4 合成：`num` 为 number 缩写违 R1 全词 + 语义域 Int + 与 test.krf 同概念函数统一单名]；v1.12（r91 第十九轮吸收——§13 增记[EBNF v5 分层与脱糖优先]；v1.11（r89 第十八轮吸收——§12 增记[关键字张力与脱糖备选]；v1.10（r88 第十七轮吸收——§12 增记 15 关键字演进[17→15：impl 并入 type + linear 降为类型标注；v1.9（r84 第十六轮吸收——§12 17 关键字与宏层登记增记[目标语言关键字面收敛 17 + 十二项传统关键字效应替代 + 宏层熟悉语法 + Stage 0 正交分层]；v1.8（r83 第十五轮增量维度——§12 EBNF 登记义务增记[原则 44 + 02 §8.4 单源]；v1.7（r81 第十四轮吸收——§12 目标语言表面成员与 try/catch 宏形态登记；v1.6（**r67 原语集真值对账**——关键字面时态与 r43/E5 S2 已执行实况对齐[代码为准 R4]；Keyword 计数 22→25 修正）；v1.5（**r42 / 63-b 移除轮 S1 表面腿交付——§7 移除轮行 ✅（首腿）**：旧名 27 件退役 + E0021 移除名错误[携现代名指引] + W1001 弃用族下线 + W1003 宏名遮蔽警告[D11 排期兑现] + 全语料现代名终态[引导 .krf ×4 + 测试 + 示例——grep 零旧名实证] + 注册面 84→57 扁平 + 闭合守卫双向对账；`?`/`->` 词法域收紧裁定 = 维持不收紧[§4.2 e5-plan 否决记录]；v1.4：r39 M1；v1.3：r38 批次 L；v1.2：r34 四层设计栈；v1.1：r33 精确化；v1.0：r32 首版）
> **Status**: Active（**设计方向规范已冻结**；实现分批兑现——v0.5 别名层 ✅ / v0.6 命名空间层 ✅ / **Stage 3 移除轮 S1 表面腿 ✅ r42**[关键字腿 + ADT 腿待 E5 后续腿] / **引导语料私有名清偿 ✅ r102**[§6.5 机会主义迁移终结——残余 7 名专项窗 + 闭合守卫])
> **处理程度**：P2（方向规范 + 完整映射表已冻结；别名层实现 = v0.5 批次 L（[12-路线图 §2.10](./12-roadmap.md)）；命名空间层 = v0.6（**机制设计输入 = [22-命名空间设计](./22-namespace-design.md)**——本文件 §5 仅方向概要）；移除 = Stage 3 与 E5 同窗）｜ **所属 Stage**：Stage 2 末设计冻结 → v0.5+ 分批实现 ｜ **推迟项**：`/` 限定名 Reader 语法（v0.6 命名空间层——见 §5）

> 本文件定义 kerf **用户可见库表面**的命名规范、行为契约与组织结构（2026 现代化方向）。它在现代化版图中的位置：**名字与行为层**——与同窗交付的 [21-能力架构](./21-capability-architecture.md)（**能力与职责层**——能力定位/边界/职责/正交四要素 + 原语迁移分类学 + 三轴坐标系 + 授权组合/编译期权威裁定[v1.1]）、[22-命名空间设计](./22-namespace-design.md)（**命名机制层**——五层命名层级/解析规则/遮蔽语义/权限矩阵）和 [23-演进治理](./23-evolution-governance.md)（**治理层**——演进时机触发表/准入判据/生命周期/收敛证明[r34 增]）构成**四层设计栈**：21 管「每个能力是什么、管什么、不管什么」，22 管「名字如何存在、解析、授权」，本文件管「名字长什么样、行为契约如何」，23 管「它们如何变、何时变、谁裁决」。[01-核心原语 §8](./01-core-forms.md) 已冻结**内部 ADT** 的语义化演进**方向**（原则 29-31 + E5 裁定——**注意：方向冻结 ≠ 实施完成**，迁移是 Stage 3 一次性结构重构窗口，非简单重命名——六类迁移性质（脱糖/索引化/层级迁移/效应化…）归档于 [21 §5](./21-capability-architecture.md) 分类学），但**库表面**——57 个内置函数名（[09-标准库 §2](./09-stdlib.md) 清单）+ 扁平全局命名空间 + 若干 1970 年代行为模式——此前**无现代化 owner、无映射表、无技术债登记**（r32 审查实测，见 §1）。本文件是 09-标准库清单的**命名规范层**（清单本体与能力门控语义不变）；与既有裁定的协调关系见 §6；完整 57 项映射表见 §8；映射的**架构解释**（域四要素与正交依赖）见 [21 §3](./21-capability-architecture.md)。

---

## 1. 问题陈述：库表面是现代化的「未认领半区」（r32 审查结论）

### 1.1 审查实测（全项目扫描——2026-09-12，Task 53-a）

| 模式类 | 定义域实测 | 判定 |
|---|---|---|
| `?` 后缀谓词 | 注册名 18 件（`null?`/`pair?`/`int?`/…/`str-contains?`）；引导语料自铸 41 个含 `?` 私有名（`err?`/`contains?`/`is-keyword?`——**后者已是 `is-`+`?` 杂交**）；21 个测试文件 240 处引用 | ❌ Lisp 家族约定，现代化无 owner |
| `->` 中缀转换 | 注册名 3 件（`string->symbol`/`symbol->string`/`string-to-pos-chars`）；引导语料自铸 9 个（`num->str`/`chars->str`/`list->pairs`/`datum->value`…） | ❌ 同上 |
| `!` 后缀变异 | 库表面 0 件（`set!` 是核心形式非内置——时名，现 `assign`[r43]）——**无债**；关键字面已随 E5 S2 切换（见 §6.3） | ✅（关键字协调见 §6.3） |
| 历史包袱访问器 | `car`/`cdr`（1959 IBM 704 寄存器缩写——Contents of Address/Decrement Register）×379 处引导语料 + `last-pair` | ❌ 命名精确性最低类 |
| 扁平命名空间 | 57 名全局单空间：`str-`×11 + `list-`×2 + `char-`×2 前缀补丁式分域；无模块限定引用面 | ❌ 前缀 ≠ 命名空间（前缀是约定、命名空间是机制） |
| 行为模式遗留 | `str-index-of` 未找到 `-1` 哨兵（pre-Option 时代）；`member`/`assoc` 命中返子表/未命中 `false`（真值多态）；`read-line` 运行时忽略多余实参（元数纪律缺口） | ⚠️ 见 §4 行为契约 |

**核心发现（对「为什么现在做」的回答）**：库表面债随每个新内置**线性累积**——Stage 2 库化生长（[09 §2](./09-stdlib.md)「完整库化生长是 Stage 2 切换信号」）即将放量；每延迟一轮，迁移面（注册表 × HM 签名表 × 门控表 × 引导语料 × 测试 × 文档）等比放大。这正是用户指令「不然在之后阶段中也是需要大量时间和精力去重构」的量化形态。

### 1.2 为什么「内部已定方向、表面未跟进」是不一致状态

设计文档集已在内部语法侧**冻结 2026 演进方向**（v1.1 措辞修正——r32 版「已完成现代化」失实）：原则 29（命名行为导向）/30（类型安全优于命名安全）/31（表面-内部语法分离）+ [01 §8.3](./01-core-forms.md) 迁移映射 + E5 委员会裁定（r18）——注意这套裁定的载荷是**结构级重构设计**（`Define` 脱糖 / `VarRef` de Bruijn 索引化 / `Module` 层级迁移 / `SetBang→Perform(State)` 效应化——[21 §5](./21-capability-architecture.md) 六类迁移分类学归档），**重命名只是其中最浅的一类**（`App→Apply` 等 M-R 类）；实施绑定 E5 Stage 3 一次性窗口（自举 parity 链保护——§6.2）。但用户可见面——**学习者第一眼看到的 57 个名字**——连方向都未冻结（r32 前无 owner）。两个半区的成熟度差：内部侧「方向已冻结、实施有窗口、重构有分类学」；表面侧（r32 前）「无方向、无映射、无债务登记」。这不是「风格偏好」问题而是**架构一致性问题**（原则 29 的适用域缺了半区）：标点后缀约定（`?`/`!`/`->`）是**前类型系统时代的补偿机制**——在名字里编码「返回布尔」「有副作用」「是转换」这些本应由类型系统承载的信息。kerf 已拥有 HM 推断（r29 判定面）+ 效应处理器（r25 Perform/Handle）+ 能力门控（r8）——**现代机制已就位，表面命名不应继续补偿不存在的能力缺口**。

---

## 2. 2026 前沿对照（跨语言实证——知识搜索精华）

| 维度 | Lisp 家族（Racket/Scheme） | 2026 前沿共识（Rust/Swift/Kotlin/Clojure） | kerf 裁定 |
|---|---|---|---|
| 布尔谓词 | `?` 后缀（`null?`） | 前缀 `is`：Swift `isEmpty`/`isDigit`、Kotlin `isX`、Rust `is_empty`（Swift API 设计指南「clarity at the point of use」+「避免缩写」） | **R2：`is-` 前缀** |
| 动词谓词/关系 | 一律 `?` | 裸动词：Rust/Swift `contains`/`starts_with`；关系词裸形（`eq`/`==`） | **R3：裸动词/关系词** |
| 转换 | `X->Y` 中缀（C 风格指针转型的语法残留） | 方向词：Rust `to_`/`into_`（所有权语义区分）/`from_`（目标侧构造）；Kotlin `toX` | **R4：`X-to-Y` + 模块内 `to-X`/`from-Y` 双向** |
| 变异标记 | `!` 后缀（Scheme） | 类型/效应承载：Koka、OCaml 5 效应系统（效果入类型而非名字） | **R5：库面零 `!` 新铸；效应纪律承载** |
| 序对访问器 | `car`/`cdr`（1959 硬件寄存器） | `head`/`tail`（ML/Haskell 系）或 `first`/`rest`（Clojure） | **`head`/`tail`**（ML 血统——与既有文档 [01 §7.2](./01-core-forms.md) 评注一致） |
| 标准库组织 | 扁平全局 + `cl:` 前缀补丁（CL） | 命名空间限定：Clojure `clojure.string` → `str/join`（Lisp 家族内部的现代答案）；Julia `String.length` | **R1 配套：`kerf/<模块>` + `/` 限定引用（§5）** |
| 缩写 | `str`/`num`/`char` 随处 | 全词（Swift 指南「avoid abbreviations」；Rust 标准库全词方法名） | **R1：全词——`str-` → `string-`** |

**方法论注记（反哺 sop.md 的「动态演进思维」）**：本表不是「抄 Rust」——是**每轮引入新表面前先对照当期前沿**的流程产物（用户指令的「技术演进思维模式」：不固定时间节点，设计与实现前先问「这是 2026 推荐还是历史惯性」，整体动态演进）。该流程已被吸收为 [sop.md §2.2 原则 33](../sop.md)（v12.1）。

---

## 3. 表面命名规范 v1（六条规则 R1-R6）

> **适用域**：用户可见库表面（内置函数名、标准库模块名、导出名）。**不适用**：核心形式关键字（`fn`/`assign`/`do`/… ——r43/E5 S2 已切换终态；本节及全文历史叙述以时名 `lambda`/`set!`/`begin` 展开处见 §6.3 实施注记，核心冻结 + 原则 31 表面/内部分离）；内部 ADT 变体名（已由原则 29-31 + E5 治理）；运算符符号族（R6 冻结）。

- **R1 描述性全词**：名称使用完整单词（`string` 非 `str`）、动词-宾语语序（`string-contains`）、拒绝缩写与历史致敬（`car`→`head`）。依据：Swift API 设计指南「clarity at the point of use」+ 原则 29（命名行为导向）在库表面的延伸。
- **R2 状态/类型谓词 = `is-` 前缀**：`is-nil`/`is-pair`/`is-int`/`is-string`/…。依据：§2 对照表——`?` 后缀是 Lisp 家族标记，`is` 前缀是 2026 跨范式共识（Swift/Kotlin/Rust）；谓词性同时由返回类型承载（HM Bool），名字不再需要标点补偿。**迁移后标识符字符域收敛为字母/数字/连字符**——可 grep、可索引、无「标识符内含操作符字符」的词法复杂度。
- **R3 动词谓词与关系词 = 裸形**：`contains`/`starts-with`/`ends-with`（动作询问，非状态测试）；关系词 `eq`（恒等关系，区别于链式值相等 `=`——见 B5）。依据：Rust/Swift `contains`/`starts_with` 同型；动作与状态测试语义不同，不应同用 `is-`。
- **R4 转换 = `to`/`from` 方向词**：扁平过渡形 `X-to-Y`（`string-to-symbol`）；命名空间终态**双向双家**——源侧模块导出 `to-X`（`string/to-symbol`）、目标侧模块导出 `from-Y`（`symbol/from-string`）。依据：Rust `to_`/`from_` 方向语义学（源侧视角 `to`、目标侧视角 `from`）；`->` 中缀是 C 指针转型时代的语法残留，且破坏 R2 的字符域收敛。
- **R5 库面零 `!` 新铸**：新内置/新库函数一律不以 `!` 后缀标记变异；变异副作用由效应纪律（Perform/Handle——r25 已在位）与后续类型面承载。关键字 `set!` 的更名（候选域收敛终选 `assign`——[01 §7.2](./01-core-forms.md)）**已执行**（r43/E5 S2 切换腿——核心形式面，非本规范适用域；否决记录与历史候选叙述见 §6.3）。
- **R6 符号运算符族冻结**：`+`/`-`/`*`/`/`/`mod`/`=`/`<`/`>`/`<=`/`>=` 维持符号形态。依据：数学表面是跨语言通用语（非「Lisp 家族遗留」——Scheme 与 Rust 共享此面）；仅命名族收敛，运算符族不动。

**规则判定的最小闭包**：任何新表面名提交前过五问——① 全词？② 布尔返回 → `is-` 还是动词裸形？③ 转换 → `to/from` 方向词？④ 有副作用 → 效应面声明了吗（而非 `!` 名字标记）？⑤ 模块家定了吗（§5）？

---

## 4. 行为契约现代化（B1-B5）

> **迁移不变量（本规范的载荷纪律）**：**别名层零语义变更**（v0.5 纯改名——现代名 ≡ 旧名行为逐字节 parity，测试锚定）；**契约层零兼容承诺**（v0.6 命名空间模块定义现代契约——B1/B2/B3 变更落位于此，新名新契约、旧名旧契约并存至移除）。改名与改行为**永不混步**——一步一验，杜绝双名双行为的隐性分叉。

| # | 遗留行为 | 现代契约 | 落位 | 依据 |
|---|---|---|---|---|
| B1 | `str-index-of` 未找到返回 `-1`（pre-Option 哨兵值——哨兵与合法值域重叠：`-1` 既是「未找到」也是合法索引的邻域负数） | `string/index-of` 未找到返回 `nil`（nil-as-absence 与语言值域一致——`read-int` EOF→nil 已是先例） | v0.6 | 哨兵值是错误码时代遗产；Option/nil 二值化是 2026 共识 |
| B2 | `member`/`assoc` 命中返回子表/点对、未命中返回 `false`（真值多态——用 `false` 佯装「无结果」） | `list/member` 命中返回子表、未命中返回 `nil`；返回类型单一化（表-or-nil，不再与 bool 交叠） | v0.6 | 真值多态是动态语言早期宽松产物；类型域纯净化配合 HM |
| B3 | `read-line` 运行时忽略多余实参（builtins.rs 实测注记——**r40/R4 修正：历史注记已过期**，当前底层严格 0 参[FS-4 修复面覆盖运行时——`read-line 需要 0 个参数` 错误路径在位]） | `io/read-line` 严格 0 参（多余实参 = 运行时错误，与其他内置元数纪律对齐） | v0.6 | 元数纪律一致性（**B3 = 纯测试锚零代码变更**——r40 M2 实测确认底层已对齐，契约面由 m2_b3_contract_read_line_strict_arity case 锚定） |
| B4 | `(+)`→0、`(*)`→1、`(- x)`→取负 | **保留**（显式裁定：数学恒等元是原则性行为，非遗留债） | 不变 | 群恒等元语义（unit/identity）；Clojure/Racket 同型 |
| B5 | `eq?` 恰 2 参不可链；`=` 链式值相等 | **保留**（恒等关系 vs 值相等的语义区分是原则性的） | 不变 | `eq`（恒等）与 `=`（值）是两个关系；链式性是值相等族的性质 |

---

## 5. 组织结构：命名空间层（v0.6 方向概要——机制层设计见 22）

> **v1.1 分工声明**：本节持**方向概要与模块树**（谁家有什么名字）；**机制层完整设计**（五层命名层级 N0-N4、解析优先序 R-N1、遮蔽许可表 R-N2、限定名不回落 R-N3、权限矩阵、冲突三类裁定、保留域与版本化接口位）由 [22-命名空间设计](./22-namespace-design.md) 承载——**v0.6 批次 M 的实施输入以 22 为准**（本节是 22 的导览层非替代）。两文件的分层理由：20 是表面规范（名字/行为/组织），22 是机制规范（存在/解析/授权）——层间耦合点唯一（§5.3 能力对齐），已在 21 §4.3 精确化。

### 5.1 限定名语法（Reader 面）

`/` 作为**标识符内部的命名空间分隔符**：`string/append` = 命名空间 `string` 的 `append`。**词法规则**（Clojure 同型裁定）：独立 `/`（前后无标识符字符）维持除法运算符；`/` 仅在标识符内部作分隔符。Reader 变更 = 标识符字符域增 `/`（中间位）——词法层零语义原则不破坏（[02 §6 不变式 3](./02-syntax-model.md)）。

### 5.2 标准库模块树（终态版图）

| 模块 | 导出（终态本地名） | 备注 |
|---|---|---|
| `kerf/core` | `is-nil` `is-bool` `is-int` `is-float` `is-number` `is-string` `is-symbol` `is-pair` `is-list` `is-procedure` `eq` `not` `error` `assert-eq` | 值谓词域 + 关系域（域四要素与正交依赖 = [21 §3.1](./21-capability-architecture.md) 八域表前两行） |
| `kerf/pair` | `cons` `head` `tail` | 序对域（L0 形状约定执行者——21 §3.1） |
| `kerf/list` | `list` `length` `append` `reverse` `nth` `drop` `member` `assoc` `last-pair` | 表域（`nth`←`list-ref`、`drop`←`list-tail`——Clojure/Haskell/Scala 同名先例） |
| `kerf/string` | `append` `length` `substring` `index-of` `contains` `starts-with` `ends-with` `to-upper` `to-lower` `to-symbol` `from-symbol` | 字符串域（全词 + B1 契约承载 + 域零副作用——21 §3.1 D3 规则投影） |
| `kerf/symbol` | `to-string` `from-string` | 转换域 R4 双向双家（string 侧 `to-symbol`/`from-symbol` 对偶） |
| `kerf/io` | `print` `write-string` `newline` `read-line` `read-int` `read-num` | I/O 域（**授权门对齐点**——见 5.3 + [22 §5.1 矩阵](./22-namespace-design.md)） |
| `kerf/char` | `is-whitespace` `is-alphabetic` | Unicode 属性判定域 |
| （非导出）Reader 运行时服务 | `pos-chars` 等 4 件 | 引导私有（[09 §2](./09-stdlib.md)「运行时服务层，非语言语义面」——**不入用户面**，直接终态化，跳过 v0.5 别名；与 `kerf/char` 的边界裁定 = 21 §3.1 字符判定域行） |

> 模块树的**架构解释**（域划分依据/域间单向依赖图/零副作用汇聚规则）见 [21 §3](./21-capability-architecture.md)；模块的**机制规则**（export 白名单/解析优先序/遮蔽/冲突/保留域）见 [22 §2-§7](./22-namespace-design.md)。
>
> **r39 / M1 实施注记**：本表七模块 47 限定名已落地为「限定名可见面」（`ns/本地名` 注册 = 底层共享分派体——`builtins.rs STDLIB_MODULES` 单源转译；io 族按授权分项 fail-closed 注册[22 §5.1 对齐点]；签名按模块表派生）。
>
> **r40 / M2 实施注记**：import 注入面/别名（R-N5 三形态——`as` contextual 别名编译期归一）+ B1/B2 契约（限定名独立分派体 miss→nil；B3 纯测试锚）+ W 弃用族（W1001/W1002）+ 组合闭包（21 §4.4——`from_core` 顶层口径 + E0006 增强形态）+ E0013/E0016/E0017/E0018/E0019 五码 **全部落地**（namespace_tests 36 case；深审裁定 22 §10 D1-D9）。非限定注入过渡期语义 = 22 §6 冲突类三（裸名同形全局胜出——N2>N1 可观测性归 Stage 3 移除轮后[D7 知悉项]）。

### 5.3 能力-命名空间对齐（2026 级设计耦合——v1.1 精确化）

> **记号桥（r157 / 227-b1）**：本节 import/require 形以 Stx 内核形书写（Reader 产物的 datum 表示）；用户面现代形 = `import kerf_string;` / `import kerf_string as str;` / `require io, write;`（皮肤字典第八/十映射——皮肤字典 §14）。

**`kerf/io` 的成员恰 = `(require io read|write)` 门控内置全集**——命名空间族边界与授权族边界**对齐**（不变量 A）。v1.1 精确化（r32 版「成为同一语义的两种表述」表述过强——修正依据 [21 §4.3](./21-capability-architecture.md)）：**边界对齐成立，机制分工两门**——命名空间门管**名字可见性**（import opt-in），授权门管**操作许可**（require 声明 + fail-closed 注册）——import 不传播授权（[22 §5.2 红线 1](./22-namespace-design.md)：import kerf-io 后未 require 调 print 仍 E0006——双门分立的可观测形态，批次 M 增补 case）。两门共享同一张授权表**数据源**（防漂移——[21 §4.3 同步纪律]），在 io 族边界重合是副作用汇聚规则的必然（[21 §3.1 D3](./21-capability-architecture.md)：唯一副作用域 ⟺ 需授权域 ⟺ 独立命名空间）；net/process 族（Stage 3 触发式——[12 §2.5.1](./12-roadmap.md) net 窗口核对结论）将出现**分叉实例**（声明态 + 令牌态双层授权——[21 §4.1](./21-capability-architecture.md) 预判：`kerf/net` 可见性 + socket 线性令牌持有分层），对齐不变量届时按族重验。

### 5.4 导入形式与 prelude

- **限定导入**：`(import kerf-string as str)` → 模块内 `str/append`（模块别名局部绑定——命名冲突显式化）
- **非限定导入**：`(import kerf-string)` → 本地注入 `append`/`length`/…（冲突 = 显式错误——沿用 kerf-prelude 的「显式失败优于静默遮蔽」语义，[09 §2](./09-stdlib.md) v6.2 注记同型）
- **prelude 定位重锚**：`kerf-prelude`（`bootstrap/preamble.ktf`）= **便利 + 兼容层**——自有五件（`map`/`filter`/`foldl`/`foldr`/`for-each`——已是现代名）+ 再导出高频核心名的非限定形。旧名（`car` 等）**不经 prelude 再导出**——旧名只存在于全局注册表面（v0.5 过渡），不进入任何推荐路径。
  > **r46 / 67-b D50 落位注记（22 §15）**：再导出面 = **20 名**（自有五件 + 序对三件 `cons`/`head`/`tail` + 表域两件 `nth`/`drop` + 谓词全集十件 `is-*`——原文「head/tail/nth/drop/is-* 全集」的判据化收编 + 补 cons[序对构造是同像性代码氧气管]；`length`/`append`/`member` 属表域组合操作次级频率[import kerf-list 显式]——「prelude ≠ 全 stdlib 藏身所」）。分两步：r46 元数据步（preamble 头部 `(import kerf-core kerf-pair)` + export 20 名——零行为变化[collect_import_face 对 prelude 模块自身 import 结构性跳过]）→ r47 收紧腿载荷步（注入面派生单源 = export 列表 + 再导出感知 E0013）。**r47 / 68-b 载荷步 ✅ 兑现（22 §15.4 D55）**：`PRELUDE_EXPORT_NAMES` 20 名单源（与 preamble.krf export 列表逐名一致——d50 契约测试锁同步）+ 扁平可见边际 7 名（5 HOF + nth/drop——N1 冗余名去重）+ E0013 再导出感知（underlying 同一性重基：prelude 再导出名与源头模块同 underlying 非冲突——Swift `@_exported import` 同型语义）。

---

## 6. 与既有裁定的协调（不冲突证明）

### 6.1 核心冻结（原则 9）——不受影响

57 内置名是**库表面**（driver 注册的 δ 函数表，[09 §1](./09-stdlib.md)「语言核心零内置」），非核心形式。更名/加别名 = `register_globals` 表操作，CoreExpr 零接触。**核心冻结原则反而构成本规范的前提**：正因内置不在核心，库表面才可独立于核心冻结演进。

### 6.2 E5 裁定（REJECT-STANDALONE，r18）——适用域划分而非冲突

E5「语义化命名 REJECT-STANDALONE、绑定 E1-E4 全落地后 Stage 3 一次性迁移」的**论证载荷**是：核心 ADT 半迁移会造成自举 parity 链的**中间态破坏**（编译器源码半新半旧、双形态互译）。库表面别名层**不存在此载荷**：别名是纯增量（旧名不动、新名同语义注册），自举链、parity 测试、758 现有断言**零接触**。故本规范不违反 E5，而是把它精确化为适用域划分：**内部 ADT + 关键字面 = E5 一次性窗口（Stage 3）；库表面 = 别名渐进（v0.5 起）**。

### 6.3 关键字面（`fn`/`assign`/`do`/…——r43/E5 S2 切换后终态；本节历史叙述以时名展开）——显式划出

25 个 Keyword（v1.6/r67 计数修正——[02 §1](./02-syntax-model.md) 叶级 48 计数同口径）的更名属**核心形式关键字面**：原绑定 E5 Stage 3 窗口，**已提前执行**（r43/E5 S2 腿——见下方实施注记），与本规范的 v0.5/v0.6 批次**无耦合**。协调点唯一：Stage 3 移除轮（旧内置名移除——**已执行 r42**）与关键字切换（**已执行 r43**）分两腿落地，「1970 表面」清算分步完成。

> **r43 / E5 S2 腿实施注记（22 §12 D19-D33 重筛终选）**：关键字三件已切换 `lambda→fn`/`set!→assign`/`begin→do`（**否决原 set/seq 候选**——名空间经济判据：set 集合构造生态占用 / seq Clojure 序列生态占用；单源 = [22 §12](./22-namespace-design.md) + e5-plan §4.2 否决记录）；旧形 `lambda`/`set!`/`begin` 引用 → E0021 携新名指引（接管豁免同 S1 口径）；`fn`/`assign`/`do` 即刻入 E0020 禁绑面（25 名计数不变）。

### 6.4 HM 签名表与能力门控——三方同步契约

`BUILTIN_SIGS`（**r38 双名同步后 83 项**——56 基础 + 27 别名同签名，[09 §2](./09-stdlib.md)——HM 判定面 R8 消费）与 R9 门控名表（E0006 验证面）必须与 `register_globals` **三方同步**（既有守护 `builtin_sigs_subset_of_registered` 漂移守卫扩展为三方）。v0.5 别名层实施清单：① 注册表面 57→84（27 新别名 + 24 不变 + 4 引导私有跳过 + 6 I/O 不变名——实注册 57+27=84）；② `BUILTIN_SIGS` 双名同步；③ 门控表同步（`print`/`read-line` 等 6 件的别名 = 原名——I/O 族无新名，门控表零变更，**实测核对**）；④ parity 测试组（每别名 1 case 行为等价断言）。**r38 实施兑现 ✅（59-a / 批次 L 交付）**：①-④ 全落地（84 注册 + 83 签名[守卫锚逐项相等] + 门控零变更实测[READ_GATED/WRITE_GATED 六名 ⊆ 注册 + 别名零交集] + 27 parity case + 三方守卫两测试——`builtins.rs` `BUILTIN_ALIASES` 表/`builtin_aliases_closed_and_parity_typed`/`builtin_gating_names_subset_of_registered`；stdlib_tests 27 parity 组 + `alias_parity_group_covers_all_27` 闭合守卫）。

### 6.5 引导语料（reader.ktf/expander.ktf/compiler.ktf/preamble.ktf）

引导三件 + 序章语料的**旧名存量面已随移除轮 r42 清零**（E0021 后旧名即不可用）；新语料按 R1-R6 书写；私有 helper（`err?`/`is-keyword?`/`num->str` 等 41+9 自铸名）原设**机会主义迁移**（各批次触碰对应文件时顺带收编，不设专项批次——零用户影响面的私有代码，机械改名零风险）——历批次已顺带消化绝大多数（`err?`→`is-err`、`is-keyword?`→`is-keyword` 等在职名面），**r102 终结**：用户指令「禁止使用 ->、? 等不清晰的命名形式」开专项窗清偿残余 7 名（`lbld-imports-prelude?`→`lbld-is-imports-prelude` + `num->str`/`int->str`→`int-to-string`[同概念统一单名——R1+R4 合成：`num` 为缩写违 R1 全词、语义域 Int] + `chars->str`→`chars-to-string` + `datum->value`→`datum-to-value` + `list->pairs`→`list-to-pairs` + `params->bound`→`params-to-bound`）——**闭合守卫** `bootstrap_naming_modern_closed`（bootstrap/mod.rs）：10 .ktf 定义名 `?` 尾缀零 + 全文 `->` 零容忍（含注释面）；合法 `?` 残留白名单 = check.krf Rust `?` 运算符注释 + reader.krf 标识符字符集字符串表（E0021 诊断词法前提）。

---

## 7. 分批迁移计划（批次 L / M / Stage 3）

| 批次 | 版本 | 内容 | 验收 |
|---|---|---|---|
| **批次 L（别名层）** | v0.5 | §6.4 四件实施清单（双注册 + 签名同步 + parity 组）+ prelude/ examples/ 测试语料面**新代码一律现代名**（写入 09 §2 规范注记）+ 09/02/07 文档规范指针 | §3.2 全绿零回归 + 每别名 parity case 全绿 + 漂移守卫三方扩展 ——**✅ r38 交付**（出口条件三全过：788:0:0 零回归 + 27 parity 全绿[新旧名同行为同诊断：阶段/诊断码/消息体三面比对——rendered 源码回显与列号随名字长度自然平移，非诊断内容差异] + 三方守卫扩展落地[注册 ⊇ 签名 + 门控 ⊆ 注册 + 别名闭合 ×2 向]） |
| **批次 M（命名空间层）** | v0.6 | Reader `/` 词法（§5.1）+ §5.2 模块树七件 + 限定/非限定导入 + prelude 再导出重锚 + B1/B2/B3 契约（新名新契约 + 测试）+ 旧名弃用警告（W 级诊断码族——18 §6 码位登记表增行） | 同上 + 命名空间 E2E（模块树全导入路径）+ B1-B3 契约 case |
| **Stage 3 移除轮** | v1.0 前夜 | 旧名 27 件移除（+ `?`/`->` 词法域可选收紧）+ **E5 关键字切换同窗**（§6.3） | 旧名引用 = E00xx 错误；全语料现代名终态 ——**✅ S1 表面腿 r42 交付**（E0021 移除名错误 + REMOVED_BUILTIN_NAMES 27 对单源 + 负例组 27 名全覆盖 + 语料 grep 零旧名 + W1001 下线 + W1003 落地 + 828:0:0；`?`/`->` 收紧裁定维持不收紧——e5-plan §4.3 否决记录在位）；**✅ S2 关键字腿 r43 交付**（三件切换 fn/assign/do[22 §12 重筛终选] + E0021 扩展至关键字旧名 + 接管豁免同口径 + 语料 grep 零旧形）；**✅ S3-M-R 名面臂 r44 交付**（内部名面同词根化：变体五件 + kind_name 12 名表 + 桥 tag 六改 + Keyword 枚举对齐——五面同词根[22 §13 D34-D40]，834:0:0 + 五面 grep 零旧形；**S3-结构臂待 r45+**——Define 脱糖/Do→Let/Module 迁移/de Bruijn） |

**TD 登记**：TD-027（[tech-debt-register.md](../develop/v0/tech-debt-register.md)——库表面命名现代化：批次 L owner 落位）。本规范文件 = 设计 owner；TD = 实施跟踪 owner。

---

## 8. 57 项内置完整映射表（旧 → 现代）

> 读法：**v0.5 别名** = 批次 L 注册的现代扁平名（行为 parity）；**v0.6 终态** = 命名空间限定名（B 契约变更随此生效）；`—` = 名称不变（R1/R6 判定已现代）；`跳过` = 引导私有面直接终态化（§5.2）。

| 旧名（v0.4） | v0.5 别名（扁平过渡） | v0.6 终态 | 规则 | 契约 |
|---|---|---|---|---|
| `+` `-` `*` `/` `mod` | — | `core` 不导出（全局运算符） | R6 | 不变 |
| `=` `<` `>` `<=` `>=` | — | 同上 | R6 | 不变 |
| `cons` | — | `pair/cons` | R1 | 不变 |
| `car` | `head` | `pair/head` | R1 | 不变（纯改名） |
| `cdr` | `tail` | `pair/tail` | R1 | 不变 |
| `list` | — | `list/list` | R1 | 不变 |
| `length` | — | `list/length` | R1 | 不变 |
| `append` | — | `list/append`（`string/append` 同名异家——命名空间消歧） | R1 | 不变 |
| `reverse` | — | `list/reverse` | R1 | 不变 |
| `list-ref` | `nth` | `list/nth` | R1 压缩 | 不变 |
| `list-tail` | `drop` | `list/drop` | R1（跨语言同名先例） | 不变 |
| `member` | — | `list/member` | R1 | **B2**（v06：miss→nil） |
| `assoc` | — | `list/assoc` | R1 | **B2** |
| `last-pair` | — | `list/last-pair` | R1 | 不变 |
| `null?` | `is-nil` | `core/is-nil` | R2 | 不变 |
| `pair?` | `is-pair` | `core/is-pair` | R2 | 不变 |
| `int?` | `is-int` | `core/is-int` | R2 | 不变 |
| `bool?` | `is-bool` | `core/is-bool` | R2 | 不变 |
| `procedure?` | `is-procedure` | `core/is-procedure` | R2 | 不变 |
| `eq?` | `eq` | `core/eq` | R3 | 不变（B5 裁定保留 2 参） |
| `string?` | `is-string` | `core/is-string` | R2 | 不变 |
| `symbol?` | `is-symbol` | `core/is-symbol` | R2 | 不变 |
| `float?` | `is-float` | `core/is-float` | R2 | 不变 |
| `number?` | `is-number` | `core/is-number` | R2 | 不变 |
| `list?` | `is-list` | `core/is-list` | R2 | 不变 |
| `not` | — | `core/not` | R1 | 不变 |
| `print` | — | `io/print`（门控 write） | R1 | 不变 |
| `read-line` | — | `io/read-line`（门控 read） | R1 | **B3**（v0.6 严格 0 参） |
| `str-append` | `string-append` | `string/append` | R1 全词 | 不变 |
| `str-length` | `string-length` | `string/length` | R1 | 不变 |
| `str-substring` | `string-substring` | `string/substring` | R1 | 不变 |
| `str-index-of` | `string-index-of` | `string/index-of` | R1 | **B1**（v0.6：miss→nil） |
| `str-contains?` | `string-contains` | `string/contains` | R3 动词 | 不变 |
| `str-prefix?` | `string-starts-with` | `string/starts-with` | R3 | 不变 |
| `str-suffix?` | `string-ends-with` | `string/ends-with` | R3 | 不变 |
| `str-upcase` | `string-to-upper` | `string/to-upper` | R4 | 不变 |
| `str-downcase` | `string-to-lower` | `string/to-lower` | R4 | 不变 |
| `string->symbol` | `string-to-symbol` | `string/to-symbol` | R4 | 不变 |
| `symbol->string` | `symbol-to-string` | `symbol/to-string` | R4 | 不变 |
| `newline` | — | `io/newline`（门控 write） | R1 | 不变 |
| `write-string` | — | `io/write-string`（门控 write） | R1 | 不变 |
| `read-int` | — | `io/read-int`（门控 read） | R1 | 不变 |
| `read-num` | — | `io/read-num`（门控 read） | R1 | 不变 |
| `error` | — | `core/error` | R1 | 不变 |
| `assert-eq?` | `assert-eq` | `core/assert-eq` | R3（断言动词非谓词） | 不变 |
| `string-to-pos-chars` | 跳过 | 引导私有 `pos-chars` | R4 | 不变 |
| `char-is-whitespace` | 跳过 | `char/is-whitespace` | R2 | 不变 |
| `char-is-alphabetic` | 跳过 | `char/is-alphabetic` | R2 | 不变 |
| `string-is-int` | 跳过 | 引导私有 `int-valid` | R2 | 不变 |
| （prelude）`map`/`filter`/`foldl`/`foldr`/`for-each` | — | `prelude` 自有（已是现代名） | R1 | 不变 |

**计数对账**：57 注册名 = 27 新别名（11 谓词 + 9 字符串族 + 2 转换 + 2 访问器 + 2 列表 + 1 eq）+ 24 不变名 + 4 引导私有跳过 + 3 重复行（`str-append` 族与 24 名交集核算——详见批次 L 实施清单逐名核对）；I/O 六件门控名零变更（名称本就现代，仅家迁移）。

---

## 9. 引导语料与测试面纪律

1. **新语料一律现代名**（批次 L 起）：`bootstrap/*.krf` 新增代码、examples 新件、测试新 case——R1-R6 生效（旧名仅存量面）。
2. **私有 helper 收编**：`err?`→`errp`？**否**——`is-err`（R2）；`is-keyword?`→`is-keyword`（去 `?`）；`num->str`→（r102 终名裁定）`int-to-string`（R1+R4 合成——原登记 `num-to-str` 修正：`num` 为 number 缩写违 R1 全词 + 语义域 Int + 与 test.krf `int->str` 同概念函数统一单名）；`datum->value`→`datum-to-value`；……（41+9 件逐名同规则）——**✅ r102 全清偿**（残余 7 名专项窗 + 闭合守卫 `bootstrap_naming_modern_closed`；见 §6.5）。
3. **parity 锚点**：`bootstrap_compiler_tests` / `stdlib_tests` 增别名组——`(car x)` ≡ `(head x)` 逐字节同码（同一 builtin 分派即天然 parity；断言双名同结果 + 同 Span 行为）。
4. **漂移守卫扩展**：`builtin_sigs_subset_of_registered` → 三方（注册 ⊇ 签名 ⊆ 门控）+ 别名闭合（每别名必有 parity case——防注册了没测、测了没注册）。

## 10. 测试锚点（设计驱动测试，测试验证设计）

| 契约/不变式 | 测试锚点 | 验证命题 |
|---|---|---|
| 别名 parity（§9 第 3 条） | stdlib_tests 别名组（批次 L ≥27 case——**✅ r38 落地 27 case + 闭合守卫 1**[正负双路：正例双名同值 + 负例阶段/诊断码/消息体逐字一致]） | 新旧名同行为同诊断 |
| 三方漂移守卫（§9 第 4 条） | builtins 单测扩展 | 注册/签名/门控闭合 |
| B1 契约（§4） | v0.6 string 组 | `index-of` miss→nil（负例：`-1` 不再出现） |
| B2 契约（§4） | v0.6 list 组 | `member` miss→nil（类型域单一） |
| 命名空间词法（§5.1） | reader 组 | `str/append` 解析 + 独立 `/` 除法不破坏 |
| 能力-命名空间对齐（§5.3） | capability_tests 增行 | 未授权 `io/read-line` → E0006（fail-closed 维持） |
| 旧名移除终态（§7） | Stage 3 移除轮负例组 | 旧名 → E00xx 弃用错误 |

## 11. 设计完整性核查（2026 表面能力清单——避免返工的全景对账）

> 用户指令的第二个载荷：**「检查设计的完整性（避免返工，思考需要全面）」**。下表是 2026 语言表面能力维度的全景对账——本规范补齐的行加粗，既有覆盖给依据，缺口如实登记。

| 维度 | 状态 | 依据/落位 |
|---|---|---|
| **库命名规范** | ✅ **本规范 R1-R6 补齐**（此前无 owner——§1） | 本文件 §3 |
| **命名空间机制** | ✅ **方向（本规范 §5 v1.1 收窄为概要）+ 机制层（[22](./22-namespace-design.md) 同窗补齐——五层 N0-N4/解析 R-N1~N8/权限矩阵/冲突/保留域）**；实现 v0.6 批次 M | 本文件 §5 + 22 全文 |
| **行为契约现代化** | ✅ **§4 B1-B5 补齐**（哨兵/真值多态此前无现代化裁定） | 本文件 §4 |
| 模式匹配（`match`） | ⚠️ 蓝图登记（02 §1 TokenKind Keyword 蓝图含 `match`；[12 §2.4.1](./12-roadmap.md) 目标语法批）——**设计文档待 Stage 3 目标语法轮补**（如实登记非本规范范围） | 12 §2.4.1 |
| 错误模型 | ✅ 结构化诊断 E0001-E0012 +「错误是数据」原则（02 §3） | 02 §3/§5 |
| Unicode | ✅ NFC 保守子集 + 码点序全族（TD-011 r24 解决）+ 字符索引字符级 | 02 §1/09 §2 |
| 数值塔 | ✅ Int×Int→Int 溢出检查 + Float 提升 + `mod` 拒浮点 | 09 §2 |
| 效应系统 | ✅ Perform/Handle 语言级（r25 M1-M5）+ 静态收敛（r28） | 01 §7.3 注记 |
| FFI | ✅ 所有权模型 + VM 面（r30 §21.3 条件 4） | 05/13 §3.3.4 |
| 能力安全 | ✅ io 门控 E0006 fail-closed + 能力-命名空间对齐（§5.3 新增） | 13 §3.1.3 |
| 工具链（LSP/formatter/包管理） | ✅ 接口预留矩阵 14 项（原则 32） | 13 §3.4 |
| 文档即代码 | ✅ Scribble 方向登记 | 09 §3 |
| 高阶函数 | ✅ prelude 五件（现代名） | 09 §2 |
| **能力定位/边界/职责/正交**（语言层四要素） | ✅ **21-能力架构补齐**（r33——四层 L0-L3 + 八域四要素卡 + 正交判据 J1-J4） | 21 §2/§3 |
| **原语级迁移分类学**（结构重构 ≠ 重命名） | ✅ **21-能力架构补齐**（r33——六类迁移性质 M-R/D/I/L/E/A + 11 原语四要素卡 + Stage 3 目标形态判据对账） | 21 §5 |
| **命名机制**（层级/解析/遮蔽/冲突/保留域/版本化接口位） | ✅ **22-命名空间设计补齐**（r33——授权×可见性完整矩阵 + 三态镜像 + 宏卫生交互） | 22 §2-§7 |
| **授权架构**（三态模型/传播红线/对齐不变量） | ✅ **21-能力架构补齐**（r33——纯度/声明/令牌递进 + fail-closed 三红线 + 不变量 A 精确化） | 21 §4 |
| **术语消歧**（「能力」三义） | ✅ **21-能力架构补齐**（r33——工程能力/语言能力/授权三义定锚） | 21 §1 |

| **授权组合闭包**（require 跨模块组合语义） | ✅ **21 v1.1 补齐**（r34——传递闭包裁定：模块需求 = 元数据，入口程序声明并集；编译期核对） | 21 §4.4 |
| **编译期权威边界**（Phase 1 宏的 I/O 可能性） | ✅ **21 v1.1 补齐**（r34——零授权面裁定 + 编译期权威三判据） | 21 §4.5 |
| **三轴坐标系**（语义/命名/相位层级管理） | ✅ **21 v1.1 补齐**（r34——L×N×P + 「L3′」退役 + 交格 owner 矩阵） | 21 §2.5 |
| **演进时机与治理**（批次 L/M/E5 入口信号） | ✅ **23-演进治理补齐**（r34——六窗触发表 + 时间治理四红线 + 准入总表） | 23 §2/§3 |
| **批次 M 诊断码位**（命名空间族错误码） | ✅ **18 §6 预登记补齐**（r34 F9——E0013-E0019 预留段） | 18 §6 |

**核查结论**：表面能力清单 18 维中 8 维由 r32/r33 设计栈补齐（r32：库命名/命名空间方向/行为契约 3 维 + r33：能力四要素/原语分类学/命名机制/授权架构/术语消歧 5 维）+ **5 维由 r34 补齐**（组合闭包/编译期权威/三轴坐标/演进时机治理/码位预登记）、8 维既有覆盖、2 维如实登记缺口（`match` 设计文档 + 命名空间实现本体）——**无未声明的盲区**（§2.1 收敛元分析的「可推迟决策必须有明确接口契约」口径——v0.6 命名空间的接口契约经 22 落位，缺口只剩实施本体）。

---

*遵循条款：原则 29（命名行为导向——库表面延伸）/ 原则 33（表面现代化动态演进——本文件为其首个落地规范；能力架构版补充 = [21 §6](./21-capability-architecture.md)）/ 原则 9（核心冻结——§6.1 不受影响证明）/ E5 裁定适用域划分（§6.2——载荷精读 = 结构重构非重命名，[21 §5](./21-capability-architecture.md) 分类学）/ 原则 26 三级成熟度匹配（§2 对照实证）/ 原则 28 渐进替换（§7 三批次零破坏迁移）/+ v1.1：原则 34（能力正交与授权分层——21/22 两文件的共同架构基线）。*

---

## 12. 目标语言表面成员与 try/catch 宏形态登记（v1.7 新增——r81 第十四轮吸收，同步自 stage0.md v7.3 §9.14.2/§9.15.3）

> **本节定位**：next10.md 第十四轮吸收的表面规范面收编——目标语言（#15 门控）表面成员的命名/组织规范登记态。**零代码变更**（当前 S-expr 面关键字 25 维持——本节为 Stage 2+ 目标表面规范登记）。

**登记态**：①语法成员全糖化清单（fn/if/while/for/match/try-catch/async-await/handle_state——任何表面关键字的编译产物 = 相同核心形式，原则 31）②**try/catch = 标准库宏**（非语言核心机制——展开为 handle + 错误传播[再 Perform]；用户可定义自己的 try/catch 语义；官方 Error 空间可整体替换——原则 37 开闭投影）③渐进披露四层（初学者零效应知识可编程——效应标注由推断系统承载自动隐藏；[17 原则 43](./17-principles.md)）④类型系统成员句法登记（union/row/交叉/`effects { ... }` 效应行/`linear` 能力句法——Stage 2+；命名遵循 R1-R6 既有规则面）。**与 R1-R6 的关系**：目标表面命名在切换窗开窗时按 R1-R6 六规则 + 22 命名层级复审（本节登记形态为初始提案——开窗时过判据非直接落地）。

**EBNF 登记义务增记（v1.8——r83 第十五轮增量维度）**：本节登记的目标表面成员（§12 登记态清单）自 r83 起附**形式定义义务**——[17 原则 44](./17-principles.md)（语法定义形式化单源纪律：新语法成员登记必须附 EBNF 产生式或等价体系，清单式登记不构成语法定义）。落位形态：Stage 2+ 目标语法 EBNF 骨架已预登记于 [02-语法模型 §8.4](./02-syntax-model.md)（grammar L2 规范层——同步自 stage0.md v7.4 §9.16.4）；本节 §12 清单自此视为「成员索引」——产生式权威在 02 §8.4（单源纪律：文档侧语法唯一权威呈现 + 代码为准 R4 对照）。开窗时复审义务扩展：R1-R6 六规则 + 22 命名层级复审 **+ 02 §8.4 产生式定稿**（优先级/结合性/二义性审理——#15 六步前置清单第 1 步「完整语法规范」的形式载体）。

**17 关键字与宏层登记增记（v1.9——r84 第十六轮吸收，同步自 stage0.md v7.5 §9.17.2）**：next11.md 段 2 极简关键字设计落位——①**目标语言 17 核心关键字**（结构 4：fn/struct/enum/module + 绑定控制 4：let/if/else/match + 类型 2：type/impl + 效应 3：effect/perform/handle + 能力 2：capability/linear + 其他 2：use/pub）——本节 §12 登记态清单的目标语言关键字面收敛为 17 个（十二项传统关键字全部经效应或宏替代：try/catch→handle+Error/throw→perform/async-await→Async 效应/while-for→State+递归或宏/return→handle final 分支/break-continue→Loop 效应/yield→Generator/class-extends→struct+impl/new→构造表达式/do→直接 perform/trait→type+impl——替代表详见 stage0.md §9.17.2）；②**宏层熟悉语法**（try!/async!/while!/for! 标准库宏——看起来像关键字但属于库的一部分：可不使用/可修改/可自定义）= 渐进披露四层初学者面的表面形态载体（[17 原则 43](./17-principles.md) 协同——初学者用宏层熟悉语法、专家直接用效应原语）；③**与 Stage 0 实况正交分层（R4）**：Stage 0 实现语言 25 关键字（symbol.rs）是脚手架语法非目标语言形态——17 关键字为目标语言登记态（#15 门控），不构成对 Stage 0 的任何变更义务；④**形式定义义务维持**（v1.8 增记沿袭）：17 关键字极简 EBNF 与容器式签名产生式入 [02 §8.5](./02-syntax-model.md)（grammar L2 规范层 Stage 2+ 骨架语料对照——含段 1 完整 EBNF 被推翻中间形态对照）；开窗复审义务 = R1-R6 + 22 命名层级 + 02 §8.4/§8.5 产生式定稿 + 17 关键字保留字表与 N1 核心面对齐（[22 §20](./22-namespace-design.md) 注记）。

**15 关键字演进增记（v1.10——r88 第十七轮吸收，同步自 stage0.md v7.6 §9.18.5）**：目标语言关键字登记态自 17 关键字（v1.9 增记）演进为 **15 关键字**——impl 并入 type（函数类型保留 `"impl"? "Fn"` 前缀形态）+ linear 从关键字降为类型标注 `linear(T)`（capability_type_ref 产生式成员）；关键字减二、表达能力不减（语法形式压缩非功能削减）。宏层熟悉语法策略（try!/async!/while!/for!）不变；EBNF v3 效应容器模型（含 connect/lift/project/pass 流形三语法）为 grammar L2 第二份骨架语料（[02 §8.6](./02-syntax-model.md)）——定稿义务维持 #15 切换窗内（流形三语法是否入首批形态属窗内就绪度裁定）。

**关键字张力与脱糖备选增记（v1.11——r89 第十八轮吸收，同步自 stage0.md v7.7 §9.19.7）**：next12.md 追加段 EBNF v4 引入 ~10 个新关键字候选（consume/offer/rewind/absorb/aggregate/interference/probabilistic/competitive + direction 修饰字 + weight）——与 15 关键字极简演进方向（17→15）形成**张力**；窗内按「实现就绪度 + 极简义务」双判据裁定。**备选零关键字路径登记**：宏层/糖展开（`consume E(v)` 脱糖为 `perform Receive_E(v)`——逆向操作为使用模式非原语的 [J-A] 裁定在语法面的投影；interference_decl 可为编译器 pragma/分析器配置非语言关键字）——与 §12 宏层熟悉语法策略（try!/async!/while!/for!）同族：表面语法候选优先经糖展开承载、关键字面维持极简。EBNF v4 三语法族（逆向/干涉/概率）为 grammar L2 第三份骨架语料（[02 §8.7](./02-syntax-model.md)）——定稿义务维持 #15 切换窗内；Stage 0 实现语言 25 关键字（symbol.rs）正交不动（R4 分层对账沿袭）。

## 13. EBNF v5 分层语法与 Level 3-4 脱糖备选优先（v1.12 新增——r91 第十九轮吸收，同步自 stage0.md v7.8 §9.20.7）

**分层组织对表面语法的意义**：EBNF v5（grammar L2 第四份骨架语料）按「实现就绪度」分层 Level 0-4——Level 0 基础（Stage 0-1 必需）/ Level 1 逆向（Stage 1+）/ Level 2 流形（Stage 2+）/ Level 3 拓扑（Stage 3）/ Level 4 量子（Stage 3+ 研究性）——**表面语法采纳面仅 Level 0**（当前实况）与 Level 1-2（登记态）；Level 3-4 与表面语法首批形态无关。

**脱糖备选优先级提高（K-D——表面约定面投影）**：v5 新关键字候选 ~9 个（topology/homology/curvature/euler + interfere/entangle/superpose/measure/integral）与 15 关键字极简方向张力沿袭双判据；Level 3-4 全部非就绪 → 表面约定 = **零关键字占用优先**：topology_query/homology/curvature/euler 以编译器分析器配置/pragma 形态暴露（组合拓扑工具经 pass 配置面——K-A 第一级）；entangle_rule 枚举入类型/宏层面；「interfere/entangle/superpose/measure/integral」五词在表面语法定稿审理时**默认不进入保留字表**（除非窗内双判据裁定翻转——四份骨架语料统一在 #15 切换窗六步清单内定稿）。

**审查注记**：EBNF v5 全文与二义性预防第 8-10 例见 [02-语法模型 §8.8](./02-syntax-model.md)；关键字张力双判据先例（J-D）见 §12。

## 14. 目标语法定稿域表面登记（v1.14 新增——r104 第二十五轮整合定稿，同步自 stage0.md v8.4 §9.26.9）

> **本节定位**：EBNF v9 整合定稿（[02 §8.13](./02-syntax-model.md) grammar L2 权威定稿位）的表面规范面收编——皮肤字典定稿域扩充 + 双表面层次关系登记。零代码变更；EBNF 定稿子窗（纯文档域——切换窗本体维持未开窗）。

**定稿域指针**：目标语言完整文法 = [02 §8.13](./02-syntax-model.md)（词法层 + Level 0 定稿域 + Level 1-4 登记域 + 优先级十四级表 + 关键字分级终态 22 词面 + 二义性 22 例）；本节（表面规范域）只登记**皮肤字典定稿域扩充**：

| S-expr 面（本文 §5-§8 域） | 目标面 v9 | 备注 |
|---|---|---|
| `string/append`（标识符内 `/`——§5.1 词法裁定） | `string::append`（路径 `::`） | 分隔符双面映射（[22 §27](./22-namespace-design.md)） |
| `nil` | `()`（unit_literal） | C12 裁定——Lisp 名退役链（r43 E5 同族方向） |
| `(while c b)`（九糖宏） | `while!(c, b)`（`!` 显式宏标记） | 十二替代表宏层 |
| `(try* e)` | `try!(e)` | §9.15.3 同构展开（handle+再 Perform） |
| `is-nil`（`-` 词分隔——S-expr 面） | `is_nil`（`_` 词分隔——目标面） | **命名双面映射（r109 新登记——步③ 语料改写暴露缺口）**：Reader 符号引入边界单点映射（`target_symbol_name`）；bare `_` 恒等（占位符）；Token payload 维持词面原文（词法层零语义）；S-expr 生产名域零 `_`（grep 实证）→ 映射无歧义 |
| `(module m (import a b) (export x y) body...)` | `module m { import a, b; export x, y; body }` | **N1 模块生产面（r109 新登记）**：头部区序同构（import → export → 体形式——expander 头部扫描序兼容）；顶层 `import a, b;` = 依赖前置声明；产生式 = [02 §8.13.1a](./02-syntax-model.md)；`as` 别名 = **r130 第十映射已实施**（本表末行——32 case parity 门） |
| `(let ((a e1) (b e2)) 体)`（多绑定） | `let a = e1, b = e2; 体` | **多绑定 let 双面映射（r110 新登记——步③ 第二批语料缺口）**：D61 暂存法链 parity 载体（顺序单绑定 let 的 CoreExpr 结构不同 → 字节码 parity 破坏——切换窗五步流程步③ 门不可达）；平行语义（值先展开零注入）；产生式 = [02 §8.13.1a](./02-syntax-model.md)；单绑定行为/形态/Span 逐字节保持 |
| `'sym`（quote 简写——符号字面量） | `quote(sym)`（调用形） | **符号字面量调用形（r110 新登记）**：内核 `(quote sym)` 形的中缀皮肤移除形——经既有调用形解析通道（零 Reader 变更：quote 非目标面关键字）；expander Quote 臂直驱 |
| `(define NAME e)`（顶层值定义） | `let NAME = e;`（**r158 现代形**——toplevel_let 产生式） | **顶层值绑定（r158 / 228-c 行翻转——S-expr 旧时代 define(NAME, e) 调用形退役）**：专用目标面糖就位[`"let" [ "mut" ] identifier [ ":" type ] "=" expr ";"` → 同一 `(define name e')` 核心形——皮肤换、骨架不变（原则 31）；项位调用形 = fail-closed 现代化诊断[Span = define Token 本位]；块位/表达式位调用形维持普通调用语义（expander define 位拒收域外——诚实边界）；单绑定封顶[块级 let_stmt 多绑面维持——D1 能力等价退役判据]；设计单源 toplevel-let-design.md v1.0 |
| `(require io write)` | `require io, write;` | **require 声明皮肤第八映射（r125 新登记——CLI 双入口窗）**：顶层声明家族同族裸名形[import/export/require 一族——逗号分隔 + 强制分号]；逐符号同构 S-expr 形（零脱糖零新原语——Stx 即同一 `(require io write)` list，能力门控 E0006 fail-closed 注册消费面唯一——原则 31 皮肤/骨架同构的零脱糖实例）；双侧落地[种子 parse_require_decl + 镜像 parse-require-decl 三函数——r107/r108 parity 门族覆盖面]；块内/表达式位维持既有 fail-closed（E0018 require 位置纪律 = Stx 层双皮肤共享）；开窗依据 = CLI 双入口窗 E2E 发现的真实缺口[.ktf 程序无法声明 IO 能力]——[switch-window-plan v1.10 §4 行清偿](../develop/v0/stage-3/switch-window-plan.md) |
| `(match scrut (pattern [guard] body) ...)`（中间形——M-1 r121 Reader 直映） | `match scrut { pattern [if guard] => body, ... }` | **match 皮肤字典第七映射（r122 新登记——M-2 脱糖批兑现）：match 臂结构 → cond/let 链**：正典产物形状 = [match-design.md v1.2 §3.4](../develop/v0/stage-3/match-design.md)（temp 单次求值包裹 + 均匀 if 链 + 路径提取 + 守卫 `(and T (let binds G))` 形 + (error "匹配失败") 兑底）；零新原语零通道——产物恒既有核心形式与内建应用（原则 31）；Keyword::Match 入面（第 26 关键字——E0020 面双侧扩展）；产生式 = [02 §8.13.1a](./02-syntax-model.md) r121 增补行 |
| `(do A (resume k v))`（handler 体序列——分配后恢复） | `{ A; resume(v) }`（处理器臂块体） | **handler 块体 resume 语句映射（r128 新登记——语料族深度化窗 stress 变体批；D2 handle 映射体域扩展非新编号映射；r133 体域扩展注记）**：处理器臂块体语句/尾位 resume 调用形——k 由臂绑定注入（用户永不书写；`(resume k v)` 三元核心形式零脱糖零新原语——原则 31）；语句位（后随 ;）与尾位（后随 }）同形；一次性 resume 语句后的语句 = 死代码（与 S-expr `(do (resume k v) dead)` 同构——D9）；**r133 体域扩展**：嵌套块（if 臂块/闭包体/嵌套 handle 臂体）内语句位/尾位全开放——innermost 包裹臂 κ 注入（S-expr 词法作用域镜像——D1/D2；嵌套 handle 遮蔽 shadow-aware D3；闭包捕获开放 D4；表达式位维持域外 D6；受护式 κ=nil 收窄 D5；跨臂显式续体引用收窄 D7——触发式后续信号）[设计单源 nested-resume-design.md v1.0；双侧 Reader 嵌套穿线 + ktf_nested_resume_tests 32 case 门 + 语料对 ⇒540；同窗 VM 清偿 = 续体恢复 handler 边界截断]；**r143 位域扩展注记**：语句位 + 表达式位共享一形——primary 位同构分派（r110 表达式位 if / r121 match 值形先例第三例）；let 值位/实参位/if 条件位/嵌套 protected 位/group 位全开放；脱糖产物与语句位逐字节同构（D2 零机制变更——expander/compiler/HM/VM 零触及）；r133 handler_k 穿线在表达式位无损延拓（嵌套 protected 内 resume 维持域外 fail-closed）；块形 protected 维持域外（protected 必须是表达式——语句位同律）；张力探针五连实证：S-expr 面三位形全合法（⇒100/101/11）vs 目标面 E0001 fail-closed——CLI 双入口双面表达力 parity 缺口第五连清偿（r125/r130/r131/r132 后续）；双侧落地[种子 parse_primary KwHandle 前置臂 + 镜像 parse-primary cond 臂] + ktf_handle_expr_position_tests 32 case 门[8 正 + 24 负 1:3] + 语料对 effect_handle_expr.{ktf,krf}[⇒ 327 双面]；设计单源 handle-expr-position-design.md v1.0；产生式 = [02 §8.13.1a](./02-syntax-model.md) v7.23 同轮；普通块无处理器作用域 → 既有「期望表达式」错误路径不变；双侧落地[种子 handler_k 字段 + 镜像 kcell 闭包胞——r128/r133/r143 parity 门 96 case 累计]；开窗依据 = effect_stress 语料翻译暴露的真实文法缺口（r128）+ M1 指令开窗第三十八例（r133——成熟度匹配排序首位）+ M1 指令开窗第四十八例（r143——张力探针实测 + 成熟度匹配排序首位）；产生式 = [02 §8.13.1a](./02-syntax-model.md) v7.18/v7.23 同轮 |
| `(define-syntax NAME (syntax-rules (lit...) (模式 模板)...)`（宏定义核心形式） | `macro NAME [ "(" [字面量集] ")" ] "{" { 模式 => 模板 [","] } "}"` | **宏定义皮肤第九映射（r129 新登记——宏面语料窗）**：臂结构 = `模式 => 模板 [","]`（尾臂逗号可省——match 臂先例；`=>` = 既有 FatArrow）；模式 = 宏调用形态的括号形（元素 = 标识符/字面量/嵌套括号/`...`；**宏名首元素由 Reader 注入**——r128 resume-k 注入先例同构）；模板 = 块或表达式（目标面既有语法 + 调用实参省略号无条件吸收——非模板位 `f(a ...)` 两面同产 Stx `(f a ...)` 展开期错误同形）；零脱糖零新原语（Stx 即同一 `(define-syntax ...)` 结构——expander/macro_sys 全链零变更，原则 31）；`macro` = 目标面本地关键字（不入共享 Keyword/E0020 域——S-expr 面宏定义恒 define-syntax 零消费 = 原则 27 加性实例）；`...` 词法 = ident payload 三连点前瞻（S-expr 面符号同构——macro_sys is_ellipsis 恒等消费）；双侧落地[种子 parse_macro_decl + 镜像 parse-macro-decl——r129 parity 门 37 case]；开窗依据 = 宏面语料缺位（macros.ktf 就位——.ktf 语料族 10 件与 .krf 对齐）；**同窗 P1 缺陷清偿** = check 恢复模式宏注册丢失（expander 入口加性拆分）；产生式 = [02 §8.13.1a](./02-syntax-model.md) v7.14 同轮 |
| `(import kerf-string as str)`（S-expr 三形态导入——r40 M2 / 22 §8 R-N5） | `import kerf_string as str;`（别名对；混合形 `import kerf_string as str, kerf_list;`） | **import as 别名皮肤第十映射（r130 新登记——import as 别名窗）**：别名对 = `(ident \| path) ["as" (ident \| path)]`——符号逐一同构 S-expr 三形态导入（`as` 入 Stx 为普通符号——S-expr 面 collect_import_items 按名匹配[r40 既有]）；`alias::member` 限定引用 ↔ `alias/member`（`::`→`/` 既有分隔符映射 + rewrite_alias_refs 编译期归一[r40 既有]）；零脱糖零新原语（driver 消费形 collect_import_items/rewrite_alias_refs 全链零变更——原则 31）；`as` = 语境修饰词（EBNF 22 定稿词面 4 语境修饰词位——目标面词法 KwAs，S-expr 面普通符号）；双侧落地[种子 parse_import_decl 别名臂 + 镜像 import-alias-name/import-alias-sep/import-close/import-item-nodes 四函数——r130 parity 门 32 case]；名位 `as` = 别名缺模块名专用诊断「import as 别名须跟在模块名后（缺模块名）」；**同窗潜伏缺陷清偿** = 名位 as 诊断 Span 种子/镜像错位（种子 bump 后位 vs 镜像 as 本位——双侧统一为 as 本位）；**同窗测试锚翻转** = switch_corpus_parity m3「import a as b; 域外」→「import a as; 缺别名」；开窗依据 = 双面表达力 parity 缺口（CLI 双入口架构下 .ktf 程序无法使用模块别名——r125 require 同型）；产生式 = [02 §8.13.1a](./02-syntax-model.md) v7.15 同轮 |
| ~~嵌套单臂 handle 组合~~ **组安装核心形式（r136 翻转——TD-033）**：多臂 [>=2] → `(handle-group (A (p k) b₁') (B (p k) b₂') e')`[全臂一帧 + 任一命中分派 + 整组消费——兄弟臂体互不保护{Koka 式 [HANDLE-INSTALL] 读法}]；嵌套语义仍可经显式嵌套手写（D11）；halt = 不 resume 尾值；pass = `(perform (cons (quote T) p))` | `handle e { A(p, k) => b₁, B(p, k) => b₂, }`（多臂 + `halt` / `halt(v)` / `pass` 位形词臂体——目标面本地关键字{r129 macro 先例第 2 连}） | **handle 多臂 / halt / pass（第十二映射族——r132 / 202-c 登记 + r136 / 206-b 组安装翻转[设计单源 handle-multi-arm-design.md v1.1 §8]；VM 指令 INSTALL_HANDLER_GROUP #46——04 §1 四方同步]）** |
| `(extern write-stdout (str) int)`（顶层声明——扁平符号空间登记） | `extern write_stdout(str) -> int;`（kind = int/str/ptr 三词——D1 封顶） | **FFI extern 声明皮肤第十三映射（r137 新登记——TD-026 行① 语言面窗）**：顶层声明家族第四员[import/export/require 后——裸 kind 词 + 逗号分隔 + 强制 `;`，require 先例同构]；声明位经驱动面五重校验[形状/可注册性 E0012 编译期/契约 E0026/查重/能力 E0006——write-stdio 与 io 语言通道同享授权令牌{r65/118-a}]后剥离[expander 零变更——kerf-core/kerf-expander 零代码]；调用位经分辨层扁平符号空间[Symbol 名字匹配卫生不可穿透——ffi-ownership-model §4] → 编译臂双侧发射[PushConst SymLit + 实参 + Op::CallExternal #43 r30 冻结四方同步维持]；值位 fail-closed[E0026「仅调用位」]；运行入口表构造[声明 ∩ 在册可注册表{write-stdio 唯一条目} ∩ 能力授予 → run_program_with_externs——空表 = 历史行为逐位不变{原则 27}]；Keyword::Extern 第 28 名共享保留域[E0020 面双侧扩展]；双侧落地[种子 parse_extern_decl + 镜像 parse-extern-decl 族] + ktf_extern_decl_tests 32 case 门[8 正 + 24 负 1:3——含 E0011 运行期窗口协议传播 + 双 Reader parity] + 语料对 ffi.{ktf,krf}[⇒ 9 双面——真实宿主 I/O 往返]；开窗依据 = M1 指令开窗第四十二例[TD-026 行① Stage 3 锚]；设计单源 ffi-language-surface-design.md v1.0；产生式 = [02 §8.13.1a](./02-syntax-model.md) v7.21 同轮；**r147 增补别名臂[第十三映射域扩展——extern-alias-design.md v1.0 D1]**：`(extern write-stdout as ws (str) int)` ↔ `extern write_stdout as ws(str) -> int;` 六元素形——双名分离 D3[underlying = 扁平 FFI 空间键四面恒匹配 / local = 源级绑定名] + 替换语义 D4[别名后 underlying 直写 E0022] + 反遮蔽扩展 D6[local 入 define/import/N1 碰撞面] + 能力门不感知别名 D7[按 underlying——r135 D13 行权线] + use 选择形接驳维持域外 D9[扁平空间无模块面——宪制]；bootstrap 编译桥 CC_EXTERN (local flat) 对协议；ktf_extern_alias_tests 32 case 门 + 语料对 ffi_alias.{ktf,krf} ⇒ 9 双面；1916 基线自 r147 起；02 §8.13.1a v7.24 同轮 |
| `[a b c]`（表达式位/quote 位——括号 datum 既有） | `[a, b, c]`（逗号省略映射——primary 位受理） | **向量字面量皮肤第十四映射（r138 新登记——TD-002 向量值类型窗）**：`[a, b, c]` ↔ `[a b c]`——逗号省略映射（符号与结构逐一同构，Stx 树字节级 parity）；空表 `[]` = 空向量；尾逗号 fail-closed（[a, b,]——期望表达式）；postfix `[` ~~维持索引域外诊断（D6 位置纪律）~~（**r163 / 234-c 翻转——postfix 索引面开面**：`coll[idx]` → as-if-written `(vector-ref coll idx)` 第十七皮肤映射，双括号面俱在域；设计单源 index-access-design.md v1.0）；**双侧脱糖 D2**：表达式位 → `(vector a b c)` 应用形[as-if-written——Var 携字面量位点 scopes] + quote 位递归字面量脱糖[运行期构造 = quote pair emit_literal_pair 同律]——零 CoreExpr/IR/操作码[原则 9 冻结维持——match r122 同律]；**值模型 D3**：Value::Vector + HeapObj::Vector 元素槽位制 + GC children 臂 + eq? 引用相等[Pair 同律]；**五内建族 D4**：vector/vector-length/vector-ref/vector-append/is-vector——kerf-vector 限定模块 + N1 可见面扩容{vector + is-vector——字面量可用性强制}；渲染 D8 = 括号形可回读[与 Stx datum 渲染同律]；双侧落地[种子 target.rs primary LBracket 臂 + 镜像 target_reader.krf vec-items 族] + ktf_vector_value_tests 36 case 门[9 正 + 27 负 1:3——含 GC 存活实证 + 跨语法字节码 parity + 遮蔽捕获律] + 语料对 vector.{ktf,krf}[⇒ 9 双面同输出]；开窗依据 = M1 指令开窗第四十三例[门控任务 #5 路径——r122 match 同族先例]；设计单源 vector-value-design.md v1.0；产生式 = [02 §8.13.1a](./02-syntax-model.md) v7.22 同轮 |
| `(import kerf-string (append length))`（S-expr 选择性导入——r50/D65 / 22 §18.3 d66 组） | `use kerf_string::{append, length};`（选择树；bare `use mod;` 全量 / `use mod as a;` 别名 / `use mod::{m} as a;` 复合 / `use a, b::{x};` 多路径——D5 全族） | **use 声明 / `::` 导入树皮肤第十一映射（r131 新登记——use 声明窗）**：选择树 = `use_module "::" "{" use_tree {"," use_tree} [","] "}"`（成员为裸标识符 local 名——下划线→连字符载荷映射同模块名规 `to_upper` → `to-upper`；花括号内尾逗号可省 = 臂族先例 D7；~~成员重命名 `a as x` = D3 域外专用诊断~~ → **r134 已受理**[use_tree `as` 三元组——替换式注入 + 运行时绑定注入 + E0022 反向锚；设计单源 member-rename-design.md v1.0]）；**选择语义继承 D65 代码为准**：选择 local 名 → 注入 underlying 名为非限定运行时绑定（`use kerf_string::{append}` ⇒ `string_append(...)` 可用——d66 组锚）；未选成员 E0022；限定访问不变（`string::length` 模块级关系——选择 = 平铺命名空间卫生非模块关系裁剪）；E0024 选择成员不在导出面；全量+选择共存 = 全量语义；零脱糖零新原语（driver 消费形全链零变更——原则 31）；多段路径 `kerf::string` = E0019 编译期拒绝（D1 单层裁定执法面——与 import_name 同口径）；位置纪律 D6{顶层全族 + module 头部位全族——~~选择形在 module 头部 = 双侧一致 E0002~~ r134 已受理[expander 头部扫描双侧 + driver 共用单点]}；`use` = 目标面本地关键字（S-expr 面 `use` 普通标识符——macro 先例同型原则 27）；双侧落地[种子 parse_use_decl + 镜像 parse-use-decl 函数族十一函数 + sel-member-build 源序翻转修复] + ktf_use_decl_tests 32 case 门[8 正 + 24 负 1:3——双 Reader 正典渲染/错误面字节级 parity + D3 双形 + E0019/E0024/E0022/E0017 语义负例]；**同窗测试锚翻转 ×3** = ktf_corpus use 域外→E0019 单层执法面 + target_reader_krf/target_reader use 域外行退役（合法化锚点迁移——r130 m3 同型）；开窗依据 = 用户 r131 指令①行权（成熟度匹配首位——设计单源 [use-declaration-design.md](../develop/v0/stage-3/use-declaration-design.md) v1.0 D1-D10）；产生式 = [02 §8.13.1a](./02-syntax-model.md) v7.16 同轮 |
| `(cons a b)`（内核聚合基座调用形） | `(a, b)`（二元元组表达式——primary 位受理） | **元组表达式皮肤第十五映射（r160 新登记——TD-036 元组表达式形窗）**：`"(" expr "," expr ")"` ↔ Stx `(cons e₁ e₂)`——as-if-written cons(a, b)：Reader 直接合成与调用形产物同构的 list[皮肤换、骨架不变——原则 31：零脱糖零新原语零 CoreExpr/IR/操作码，expander/compiler/HM/VM 全链零触及，8 原语不变性第四十二轮]；**构造⟺解构对称缺口清偿**：模式位 `(p, q)` pair 解构（r121）此前无表达式位对偶——用户被迫 cons(a, b) Lisp 时代调用形（TD-036 登记原文）；**二元封顶（D2 对称纪律）**：模式位 r121「括号内至多二元」裁定镜像到表达式位——3+ 元 fail-closed 专用诊断 + 深层嵌套经显式 (a, (b, c))；单元素 (a) = 纯分组维持 + () = Unit 维持[词法歧义句法位置裁决既有纪律]；尾逗号 fail-closed[r138 vector 同律]；**cons 调用形维持（D5）**：内核聚合基座名[原则 41] + list 链构造惯用形——能力补齐窗非退役窗（与 r159 %/mod 的区别：cons 是内核名非旧别名，两面俱一等）；HM/check 零变更[BUILTIN_SIGS (Any, Any)→Pair 既有消费——零注册链增量]；合成 cons 符号 Span = `(` Token 本位[r158 合成 define 先例]；双侧落地[种子 parse_primary LParen 逗号臂 + 镜像 parse_tuple_tail 函数] + ktf_tuple_expr_tests 32 case 门[8 正 + 24 负 1:3——含 as-if-written 字节码全等门（Span 剥离后逐字节）+ 构造⟺解构对称 E2E + 全位置形{let 值/实参/if 值臂/match 检查位/嵌套/语句/closure 体/handle protected} + 模式位回归锚 + 双 Reader 正典渲染/错误面字节级 parity + Span 契约×2] + 语料迁移[match.ktf describe(cons(1,9))→describe((1,9)) + gc_stress 双件离散 pair 构造位 15 处——输出 parity 逐字节] + 增长签名锚重校准[reader.ktf payload 211 protos/494 consts/242 globals] + 1884 基线；开窗依据 = M1 指令开窗第六十五例[TD-036 触发条件①——数据结构面现代化用户指令族]；设计单源 [tuple-expression-design.md](../develop/v0/stage-3/tuple-expression-design.md) v1.0；产生式 = [02 §8.13.1a](./02-syntax-model.md) v7.28 同轮 |
| `(define NAME e)`（顶层值定义——**const 语义位**，r161 起） | `const NAME [: T] = e;`（**r161 现代形**——toplevel_const 产生式） | **常量绑定皮肤第十六映射（r161 新登记——const-declaration-design.md v1.0）**：as-if-written toplevel_let 孪生[皮肤换、骨架不变——原则 31：零脱糖零新原语，8 原语不变性第四十三轮]；只读语义闭环 = Reader 顺序 const 集 + 项位 assign 拒收[E0001——Span = 名 Token 本位]；const mut 矛盾 / 单绑定封顶 / 块位 domain-out 三专用诊断[双 Reader 字节级 parity]；绑定性质轴收口[可变 let+assign 面 / 只读 const 面——mut no-op 轴的只读方向补全]；模块作用域[保存/清空/恢复——模块局部 const 不外泄]；重绑移除[let/fn/macro/module 名——最新绑定胜出]；v0 诚实边界[函数体/块内 assign 域外——Stage 2+ 类型系统域] |
| `(vector-ref coll idx)`（VM 内建调用形——as-if-written 脱糖目标） | `coll[idx]`（postfix 位索引中缀面——第十七皮肤映射，r163 起） | **索引访问皮肤第十七映射（r163 新登记——index-access-design.md v1.0）**：数据结构消费三角第三角闭合[构造角 r160 `(a, b)` + 解构角 r121 模式位 + 索引角 r163]；as-if-written 皮肤换骨架不变[原则 31：零脱糖零新原语零 CoreExpr/IR/操作码，expander/compiler/HM/VM 全链零触及，8 原语不变性第四十五轮]；r138 D6 位置纪律 superseded——双括号面俱在域{primary 位 `[a, b, c]` 字面量 + postfix 位 `v[i]` 索引}；恰一索引表达式{空 `v[]` / 多参 `v[1, 2]` fail-closed E0001}；嵌套链式 `v[i][j]` = postfix 尾循环自然组合；**D3 脱糖目标免 import 纪律**：vector-ref 入 N1 第 42 名{r138 D4「字面量强制 import = 坏的语言设计」律的索引面兑付——VM 全局注册既有零 VM 触碰}；N1 调用形 `vector_ref(v, 1)` 双面并存维持{与 r162 后 ==/eq(...) 关系同构}；**D5 不可变维持**：`v[i] = x` assign 位域外[r138 D1 执法面]；**D6 诚实边界**：pair-list 索引维持 nth 调用形{import kerf_list} + Str 字符索引域外{字节/字符/码点位 = 独立设计题} + 连字符 vector-ref 直书维持 r159 中缀词法拦截；**D4 fail-closed 三面沿用**：非 Vector E0004 / 非 int 索引专用诊断 / 越界专用诊断[索引算术错误族独立于域错误族]；D7 Span 契约[合成 vector-ref 头符号 = `[` Token 本位——r160 D10 先例]；D8 HM/check 零增量[vector-ref (any,any)→unknown 既有 sig]；双侧落地[Rust reader.rs postfix 尾循环 LBracket 开面臂 + 种子 reader.ktf postfix_loop 镜像——错误面字节级 parity] + ktf_index_access_tests 32 case 门[8 正 + 24 负 1:3] + 增长签名锚 215/504/246 零增量维持 + 1979 基线；开窗依据 = M1 指令开窗第六十八例[用户审计清单「数据结构」项——r156/r160/r162 连续同族先例]；产生式 = [02 §8.13.1a](./02-syntax-model.md) v7.31 同轮 |

**r164 / 235 list 域自建迁移窗机制注记（非映射窗）**：五定参 list 域内建（length/reverse/nth/drop/last-pair）的实现源从 Rust 注册面迁入自建 kerf 语料 `bootstrap/list.ktf`——**非皮肤映射**（零语法变更——用户面调用形不变）；注入机制 = preamble.ktf 先例族的 forms 级注入扩展{import kerf_list ⇒ 模块形式并入 + import kerf_prelude ⇒ 级联双语料}；member/assoc 性能边界泊回 Rust{TD-039——native-AOT 回收触发式重迁}；详见 list-self-built-design.md v1.1。

**层次关系**：本文 §8 的 57 项内置映射表 = **Stage 0 实现层表面**（S-expr 面——26 关键字 symbol.rs 域[r122 M-2：match 入面]）；v9 22 定稿词面 = **目标语言层表面**（Stage 2 切换窗 Reader 域）——两层正交（R4：脚手架语法 ≠ 目标语言形态）；双表面经皮肤字典（§12 D2 六映射[含 r128 handle 体域扩展] + 本节四条扩充 + 第七映射 match[r122]）桥接——切换窗开窗时 SyntaxTransitionValidator 消费（[02 §8.12](./02-syntax-model.md)）。**§12「#15 门控维持」注记精确化**：目标语言表面成员登记态→**定稿态**（EBNF v9 就位）——切换窗开窗即消费，本节登记维持零代码变更义务。

## 15. 信息表面登记态（v1.17 新增——r111 第二十六轮吸收，同步自 stage0.md v8.5 §9.27.4）

**登记态表面成员（Level 1-4——无皮肤映射义务）**：`info handle e { pattern => action }`（信息处理糖——handle 既有通道的模式皮肤）/ `emit Id(args) [with metadata]`（信息产生糖——perform 既有通道）/ `observe e at LEVEL`（观测指令——工具链 pragma 形态）/ `xs |> f`（管道糖——函数应用形态）。**表面裁定**：①信息表面全部 = **登记态**（切换窗后按位形审定再定皮肤——当前零映射义务，与 §14 定稿域四条扩充[已实施面]性质分立）；②`emit`/`info` 位形限定词候选（位形外可作标识符——E.26-148 contextual 策略）；③`|>` 管道形 = 目标域候选（若审定入域须过 E0020 + 词法冲突面——备选方法链/pipe 函数形零新词）；④LSP/IDE 语法 = **非 kerf 表面**（工具链层单向派生——宿主工具配置）。**与 §14 关系**：定稿域表面（22 词面 + 已实施映射）与本节登记态表面（Level 1-4 候选）= 目标表面的两个时态层——R4 口径：登记态 ≠ 实施义务。上游全量 = [stage0.md §9.27.4](../stage0.md)；语法族 = [02 §8.14](./02-syntax-model.md)。

# 术语表与术语源流考

> **Author**: kerf-doc-agent
> **Date**: 2026-10-30（**v7.23——r117 第二十九轮吸收（next21.md）**：§5y 递归处理与脚手架拆除族术语十二条——同步自 stage0.md v8.8 附录 A）；2026-10-20（**v7.19——r104 第二十五轮整合定稿（EBNF 定稿子窗）**：§5u 术语 17 条——同步自 stage0.md v8.4 附录 A）；2026-10-10（**v7.13——r91 第十九轮吸收（next13.md）**：§5o 第十九轮术语[数学工具箱分级与波粒二象性 20 条]——同步自 stage0.md v7.8 附录 A）；2026-10-10（**v7.12——r89 第十八轮吸收（next12.md 追加段）**：§5n 第十八轮术语[逆向效应流与计算干涉 20 条——逆向效应流/Consume·Offer·Rewind/汇流收拢收敛/双幺半群/对偶范畴/知识不对称/正逆组合/双向 Continuation/计算干涉/非对易交换子/计算不确定性/伪随机坍缩/Randomness/CollapseScheduler/InterferenceAnalysisPass/EBNF v4/关键字张力/五层框架/计算量子三层]——同步自 stage0.md v7.7 附录 A）；2026-10-10（**v7.11——r88 第十七轮吸收（next12.md）**：§5m 第十七轮术语[效应流形与空间理论定位 24 条——流形/三连接公理/切片/升降维对偶/设计宪法/坐标系地图/低熵控制/七维度/七步/SpaceRegistry/EffectTrace/EffectGraph 等]——同步自 stage0.md v7.6 附录 A）；2026-10-09（**v7.10——r84 第十六轮吸收（next11.md）**：§5l 效应本体论与目标语言极简设计术语十七条[效应本体论/容器模型/概率域模型/效应生命周期/Resume 可选性/十七关键字/宏层熟悉语法/效应内嵌标注/容器式签名/二义性三策略/SpaceContract/Diagnostic 完备架构/EffectContext/设计完整性矩阵/河流隐喻/计算实例化倒置/同一系统两种描述]——双侧同步 stage0 附录 A v7.5 增补十七条）；2026-10-08（**v7.9——r83 第十五轮增量维度收编**：§5k 语法定义形式与语法文件体系术语六条[EBNF/W3C EBNF 记法/PEG/语法文件 grammar 单源/定义形式与实现形式分离/enforestation]——双侧同步 stage0 附录 A v7.4 增补六条）；2026-10-01（**v7.8——r81 第十四轮吸收（next10.md）**：§5j 目标语言设计蓝图与错误统一效应模型术语十五条[计算流/统一而分治/Error 子空间/Fatal 效应/值级效应级对偶/one-shot 纪律/编译期诊断/六维身份/生态扩展六维/渐进披露/行类型/交叉类型/模块=子空间/try-catch 糖/开发者体验四层] + §5i 轮次标签 R4 顺修[「第十四轮」→「空间层级同步轮」——与 next 系列计数冲突消除]）；2026-09-24（**v7.7：r66 核心空间统一规划——§5i 双侧统一体系术语十四条**（根空间 RootSpace/核心空间 CoreSpace/拓展空间 ExtensionSpace/元编程域/七核心域/公理 A6 开闭性/公理 A7 全树统一与单一事实源/统一编码分流治理/做实面种子实现/层级深度自然差/kerf-space 骨架 crate/双侧对称判据 J8/物理不判据化/命名族一致性））；2026-09-23（**r64 全文件集审计**：①§6 W1003 行引用重锚「20 §9.4」→「22 §10 D6」（W 族值域设计权威在 22 §10 D6——20 无 9.4 节，原锚为 §9 列表项缩记误作节号，自 r42 起悬空）②Date 行 v6.7/v6.4 条目闭合补全 ×2[括号平衡清偿]）；2026-09-22（**v7.6：r63 第十三轮吸收——§5h 双向调试与脚手架哲学术语十二条**（双向视图切换/五级调试视图/胖关键字视图/模式识别器双重用途/调试视图/视图映射/脚手架哲学/三阶段性能演进/信任脚手架/优化脚手架/脚手架拆除判据/三个原创性创新点））；2026-09-22（**v7.5：r62 第十二轮吸收——§5g 根空间架构与约束组合代数术语十二条**（根空间/子空间/约束特化/约束组合代数/约束的格/属于/上闭包/自相似分形/marker trait/预留空间而非点/编译器-拓展对称性/依赖方向裁定））；2026-09-22（**v7.4：r59 第十一轮吸收——§5f 性能潜力裁定与双轨策略术语四条**（性能潜力/开发成熟度/双轨性能策略/三阶段性能预期））；2026-09-17（**v7.3：r58 第十轮吸收——§5e 优化桥接与 IR 正交精简术语九条**（模式识别/等价替换/双向桥接/LICM/零成本异常/四维正交/Pass 化/单遍合并/优化就绪形式））；2026-09-15（**v6.7：r42 / 63-b 移除轮 S1——E0021 旧名移除错误 + W1003 宏名遮蔽警告码位落位**（20 §7 移除轮行「旧名引用 = E00xx 错误」兑现 + 22 §11 D11 排期兑现——W1001 弃用族随之退役：W 面收窄至 W1002/W1003，23 §3.4 生命周期四阶段完整走完[引入 v0.5 → 默认 v0.6 → 弃用 v0.7 → 移除 v0.9]））；2026-09-14（**v6.4：r34 / 55-a 设计缺陷深度审计收敛轮——§5c 增补术语 13 条**（三轴坐标系/双轴归属/授权组合闭包/编译期权威三判据/诊断终止域/横切泛函域/演进六窗/时间治理四红线/变更通道矩阵/受控债务四步/生命周期四阶段/十二审计轴/判据先于先例）+ **§6 批次 M 码位预登记**（E0013-E0019 预留段——F9 前置兑现））；2026-09-13（**v6.3：r33 / 54-a 能力架构深度设计轮——§5b 增补术语 14 条**（「能力」三义/能力四要素/L0-L3 四层/正交判据 J1-J4/授权三态/六类迁移性质/新原语准入两判据/五层命名层级 N0-N4/解析优先序/遮蔽许可表/import 不传播授权/kerf 保留域/原则 34）+ §5a 对齐术语精确化（v1.1 口径）；v6.2：r32——§6 增补术语 6 条（is- 前缀谓词/方向词转换/命名空间限定名/别名层/能力-命名空间对齐/表面债）；v6.0：next3 讨论六术语增补；v5.5：next2 讨论八术语增补；v5.0：源自 stage0.md v5.0 拆分）
> **Version**: v7.23（**r117 第二十九轮吸收——§5y 递归处理与脚手架拆除族术语[12 条——同步自 stage0.md v8.8 附录 A]**）；**r115 第二十八轮吸收——§5x 统一流分析与描述论族术语[22 条——同步自 stage0.md v8.7 附录 A]**）；v7.21（**r113 第二十七轮吸收——§5w 流特性理论与流本体论族术语[20 条——同步自 stage0.md v8.6 附录 A]**）；v7.20（**r111 第二十六轮吸收——§5v 信息效应化族术语[20 条——同步自 stage0.md v8.5 附录 A]**)；v7.19（**r104 第二十五轮整合定稿**——§5u EBNF v9 整合定稿族术语[17 条——同步自 stage0.md v8.4 附录 A]）；v7.18（r98 第二十四轮吸收——§5t 第二十四轮术语[渐进式混合自举与语法迁移验证 20 条]）；v7.17（r96 第二十三轮吸收——§5s 第二十三轮术语[类型观测与效应容器类型系统 20 条]）；v7.16（r95 第二十二轮吸收——§5r 第二十二轮术语[流形统一分析与统一场论 21 条]）；v7.15（r94 第二十一轮吸收——§5q 第二十一轮术语[生命周期效应化与四模型协同 20 条]）；v7.14（r93 第二十轮吸收——§5p 第二十轮术语[能力模型内禀几何与计算广义相对论 20 条]）；v7.13（r91 第十九轮吸收——§5o 第十九轮术语[数学工具箱分级与波粒二象性 20 条]；v7.12（r89 第十八轮吸收——§5n 第十八轮术语[逆向效应流与计算干涉 20 条]；v7.11（r88 第十七轮吸收——§5m 第十七轮术语[效应流形与空间理论定位 24 条；v7.10（**r84 第十六轮吸收（next11.md）——§5l 术语十七条**）；v7.9（**r83 第十五轮增量维度收编——§5k 术语六条**）；v7.8（**r81 第十四轮吸收（next10.md）——§5j 术语十五条 + §5i 轮次标签 R4 顺修**）；v7.7（**r66 核心空间统一规划——§5i 双侧统一体系术语十四条**）；v7.6（**r63 第十三轮吸收——§5h 双向调试与脚手架哲学术语十二条**）；v7.5（**r62 第十二轮吸收——§5g 根空间架构术语十二条**）；v7.4（**r59 第十一轮吸收——§5f 性能潜力裁定术语四条**）；v7.3（**r58 第十轮吸收——§5e 优化桥接与 IR 正交精简术语九条**）；v7.2（**r57 第九轮吸收——§5d 机制预留术语九条**（接口预测悖论/机制预留/三层未知防御/三种打洞能力/抽象-具体分离（开闭投影）/后期修改代价分级/语法级 IR/Stage 2a-2b/编译速度四档预期））；v7.1（**r50 / 71-b——E0024 码位落位**：选择性导入成员不在模块导出面[22 §18.3 D65——fail-closed + actionable 携模块名与全量导入查看指引]）；v7.0（**r49 / 70-b 声明层臂——E0023 码位落位 + E0003/E0018 阶段注记**：E0023 = module 表达式位结构化拒绝[22 §17 D59——展开期；此前无检查，inline 静默编译收紧]；E0003 = define 位置纪律前移展开器[Stage::Compile→Expand + E0003→E0002 渲染——消息文本逐字保持]；E0018 = require 位置纪律 Stx 层游走承载[码位 18 与 Stage::Compile 契约保持——展开器 Require 臂为宏产物兜底]）；v6.9（**r47 / 68-b 可见性收紧腿——E0022 面核对升级 + E0013 判据重基注记**（E0022 行：基准从全局面升级为**可见面**[N1 核心面 38 名 ∪ import 扁平运行时载荷 ∪ define 面] + 消息逐层明细[已查 N3/N2/N1] + `suggest_import_for` 导入建议单源[prelude 高频集优先]——TD-029 ①③④件承载；E0013-E0019 行 r47 注记：E0013 判据重基为 **underlying 同一性**[扁平运行时载荷碰撞且分派体相异 = 真冲突——标准库域结构性零冲突 + 通道保留 Stage 3+ 用户模块窗口，22 §15.4 D55-b]））；v6.8（**r46 / 67-b——E0022 编译期未绑定引用码位落位**（§6 增行：R-N1 第 4 步载体——未绑定引用从运行期 E0004 前移为编译期 fail-closed；HM A4 动态逃生舱语义收敛；compiler.krf 平行 let 潜伏违例实证捕获）；v6.7（**r42 / 63-b 移除轮 S1——E0021 + W1003 码位落位登记**：§6 增移除名错误行 + W1001 退役注记（W 面收窄至 W1002/W1003）；v6.6：r41 E0020；v6.5：r40）
> **Status**: Active

> 本文件收录 stage0.md 附录 A（关键术语表，42 条术语——与源文档逐条一致）与附录 D（术语源流考详细版：五大核心能力的命名起源、理论根基与历史演化路径）。附录 D 是对正文 [14-替代设计 §2（术语起源与历史脉络）](./14-design-alternatives.md) 的深化补充；参考文献与外部链接见 [19-参考文献](./19-references.md)。术语表中括注的文档引用已改写为指向本目录对应设计文件。

---

## 1. 关键术语表（原附录 A）

| 术语 | 定义 |
|------|------|
| 自举（Bootstrap） | 从外部种子到自描述核心的渐进过程 |
| 自托管（Self-hosting） | 编译器能编译自身源代码的状态 |
| 元循环求值器（Metacircular Evaluator） | 用被解释语言本身编写的解释器 |
| 语法对象（Syntax Object） | 携带源位置、作用域集的不可变数据结构 |
| 核心形式（Core Forms） | 语言语义的最小正交集（9 个原语） |
| 相位分离（Phase Separation） | 编译时和运行时代码的物理隔离 |
| 卫生宏（Hygienic Macro） | 保证宏展开不引入意外绑定的宏系统 |
| 同结果测试（Rounds-testing） | 两次编译的输出必须字节一致的验证 |
| DDC（Diverse Double Compilation） | 多样化双重编译，对抗 Trusting Trust 攻击 |
| Span | 源码位置的不可变表示 |
| 查询系统（Query System） | 将编译建模为纯函数查询图的架构 |
| 信任信任攻击（Trusting Trust Attack） | Ken Thompson 揭示的编译器后门注入 |
| hex0 | Guix 全源自举的 357 字节种子 |
| 操作语义（Operational Semantics） | 用归约规则形式化定义程序行为 |
| 标记-清除（Mark-Sweep） | 最简单的垃圾回收算法 |
| bump-pointer | 线性分配器，指针只增不减 |
| 同像性（Homoiconicity） | 程序的 AST 可用语言本身的数据结构表示 |
| 引号（Quote） | 阻止求值、将代码作为数据引用的机制 |
| 闭包（Closure） | 函数与其捕获环境的组合 |
| Effect Handlers | OCaml 5 引入的代数效应处理机制 |
| 多阶段编程（Multi-stage Programming） | MetaOCaml 风格的编译期代码生成 |
| 能力模型（Capability Model） | 通过不可复制的 token 控制权限的模型 |
| 线性类型（Linear Type） | 每个值只能被使用一次的类型 |
| 结构化代码值（Structured Code Value） | 携带类型/Span/Scope 的代码值 |
| 接口预留（Interface Reserved） | 仅定义类型签名不实现，为未来留位 |
| Token 流（Token Stream） | 类型化、携带 Span/Scope 的词法单元序列（[02-语法模型](./02-syntax-model.md)） |
| 图 IR（Graph IR） | 以节点与边表示程序的结构化中间表示，支持公共子表达式共享（[13-能力矩阵](./13-capability-matrix.md)） |
| Arena 分配 | 预分配大块内存、以索引引用对象的分配方式（[13-能力矩阵](./13-capability-matrix.md)） |
| 跳转回填（Backpatching） | 先生成占位跳转、确定目标地址后再修补的编译技术（[04-字节码 VM](./04-bytecode-vm.md)） |
| 操作码（Opcode） | VM 指令的操作编码，Stage 0 约 35 个（[04-字节码 VM](./04-bytecode-vm.md)） |
| 递归下降（Recursive Descent） | 自顶向下、每个非终结符对应一个函数的解析技术（[02-语法模型](./02-syntax-model.md)） |
| 自举链（Bootstrap Chain） | 从种子到完整工具链的逐级构建序列（[00-总览](./00-overview.md)） |
| 同结果性（Reproducibility） | 相同输入必然产出字节一致输出的构建属性（[07-自举策略](./07-bootstrap-strategy.md)） |
| 元追踪 JIT（Meta-tracing JIT） | 通过追踪解释器热路径生成机器码的 JIT 技术（[08-后端演化](./08-backend-evolution.md)） |
| 保守 GC（Conservative GC） | 不精确识别指针、宁泄漏不误回收的 GC 策略（[05-运行时](./05-runtime.md)） |
| 安全点（Safepoint） | VM 指令边界上允许触发 GC 的位置（[05-运行时](./05-runtime.md)） |
| 诊断（Diagnostic） | 结构化错误数据：严重性/码/消息/Span/建议（[02-语法模型](./02-syntax-model.md)） |
| 处理程度（Processing Depth） | P0 完整实现 → P4 完全推迟的五级标度，度量能力在给定阶段的实现深度 |
| 成熟度分级（Maturity Tier） | 生产就绪 / 早期实践 / 研究前沿三档生态评估，引入时机的第一判据 |
| 演进矩阵（Evolution Matrix） | 能力 × 阶段的处理程度总表，回答"何时引入、引入到什么程度" |
| 三级成熟度匹配原则 | 处理程度必须匹配生态成熟度的引入决策规则（[17-设计原则](./17-principles.md) 原则 26） |
| 渐进替换原则（Progressive Replacement） | 实现可从简单演进到复杂而接口契约保持不变的演进规则（[17-设计原则](./17-principles.md) 原则 28） |

---

## 2. 术语源流考（详细版）（原附录 D）

> **本附录详细考据五大核心能力的命名起源、理论根基与历史演化路径，作为对正文 [14-替代设计 §2](./14-design-alternatives.md) 的深化补充。** 术语并非中立标签——它们携带了发明时的范式偏向与时代局限，理解术语的源流有助于在使用时保持批判性自觉。

### 2.1 元循环求值器（Metacircular Evaluator）（原 D.1）

#### 2.1.1 命名起源与论文（原 D.1.1）

术语由 John McCarthy 在 1960 年的开创性论文中隐式引入：

> McCarthy, J. (1960). *Recursive Functions of Symbolic Expressions and Their Computation by Machine, Part I*. Communications of the ACM, 3(4), 184-195.

这篇论文是 LISP 的原始论文，首次描述了用 LISP 自身实现的 `eval` 函数。该函数后来被 Sussman 和 Steele 在 Scheme Manual（1975）中称为 "metacircular interpreter"。

#### 2.1.2 词源学分解（原 D.1.2）

- **Meta-**（希腊语 μετα-）：表示"超越、关于、之后"。在数学和计算机科学中常用于表示"对自身的描述"——metadata（关于数据的数据）、metaprogramming（编写编写程序的程序）
- **Circular**（拉丁语 circularis）：圆形的、循环的。指求值器与被求值语言之间的循环依赖关系

**组合含义**：求值器在"元层"（meta-level）操作"对象层"（object-level）的代码，而这两层使用相同的结构，形成循环。

#### 2.1.3 历史演化时间线（原 D.1.3）

- **1960**：McCarthy 在 LISP 论文中描述 `eval` 函数
- **1975**：Sussman & Steele 在 Scheme Manual 中正式使用 "metacircular" 术语
- **1985**：SICP（Abelson & Sussman）用元循环求值器作为教学核心
- **2007**：Racket 的 `racket/kernel` 将元循环核心工程化
- **2020+**：MetaOCaml 将元循环思想升级为类型安全的多阶段编程

#### 2.1.4 术语的局限（原 D.1.4）

"元循环求值器"这一术语暗示了"循环求值"的必要性，但实际上：
- **循环性不是必要的**：多阶段编程可以打破循环（编译期生成代码而非运行时解释）
- **求值器不是必要的**：编译器也可以描述语言语义
- **更准确的现代术语**：**类型安全的多阶段计算**（Type-safe Multi-stage Computation）

### 2.2 S 表达式的诞生与 M 表达式的遗弃（原 D.2）

#### 2.2.1 McCarthy 的原始设计（原 D.2.1）

McCarthy 在 1960 年的论文中提出了两种语法：

- **S 表达式（Symbolic Expressions）**：`(A B C)` 形式的嵌套列表，用于"数据表示"
- **M 表达式（Meta Expressions）**：`[A; B; C]` 形式，类似传统数学符号，用于"程序编写"

McCarthy 原本计划让程序员用 M 表达式编程，S 表达式仅作为"中间表示"（IR）——程序员写 M 表达式，编译器将其转为 S 表达式供机器处理。

#### 2.2.2 历史转折（原 D.2.2）

但实际发展出现了意外：
- **M 表达式从未被实现**：McCarthy 团队从未为其编写解析器
- **S 表达式被直接使用**：由于 S 表达式已被 LISP 解释器支持，程序员发现直接用 S 表达式编程更方便
- **历史偶然**：S 表达式成为 Lisp 的"语法"是一个**意外**，而非深思熟虑的设计选择

McCarthy 在后来的访谈中承认："S 表达式之所以胜出，仅仅是因为我们从未实现 M 表达式的解析器。"

#### 2.2.3 对本设计文档的启示（原 D.2.3）

S 表达式作为同像性的"标准实现"是一个历史偶然：
- 它不是 McCarthy 的"理想设计"
- 它之所以流行，是因为它"已经存在"
- 这意味着**任何对 S 表达式的"必然性"辩护都是历史错觉**

2026 年的设计应该超越这一历史包袱，认真考虑替代方案（如 Token 流 + 图 IR），而非默认接受 S 表达式。

### 2.3 同像性（Homoiconicity）（原 D.3）

#### 2.3.1 Mooers 与 TRAC 语言（原 D.3.1）

术语最早出现在 Calvin Mooers 开发的 TRAC 语言的语境中：

> Mooers, C. N. (1966). *TRAC, a procedure-describing language for the reactive typewriter*.

Mooers 的设计目标："TRAC 的输入脚本（用户键入的内容）应该与指导内部动作的文本相同"——这是一种程序与数据统一的追求。

#### 2.3.2 词源学（原 D.3.2）

- **Homo-**（希腊语 ὁμός）：相同的
- **Icon**（希腊语 εἰκών）：图像、表示、形式

**字面含义**："相同的形式"——程序的"图像"与数据的"图像"是同一个。

#### 2.3.3 术语的误解史（原 D.3.3）

同像性是一个**被广泛误解**的术语：
- **常见误解**："代码看起来像数据"（基于表面语法）
- **正确含义**："程序的 AST 可以用语言本身的数据结构表示"（基于内部结构）

这种误解的根源在于：Lisp 程序员看到 `(A B C)` 既可以是代码（函数调用）也可以是数据（列表），就误以为同像性是"表面语法的统一"。但实际上，真正的关键是"AST 与数据结构的统一"——Rust 的 TokenStream 也是同像的（按此定义），尽管 Rust 的语法看起来不像"数据"。

#### 2.3.4 2026 年的重新审视（原 D.3.4）

2026 年的同像性研究承认：
- 同像性是**一个谱系**（spectrum），而非二元属性
- Lisp 并不处于"最同像"的位置——它只是最著名的同像性实现
- 现代语言（Rust proc-macro、MetaOCaml、PEG）提供了不同的同像性实现，各有优劣

### 2.4 引号（Quote）与 Lambda 演算（原 D.4）

#### 2.4.1 Church 的 Lambda 演算（原 D.4.1）

引号操作符可追溯至 Alonzo Church 的 Lambda 演算：

> Church, A. (1936). *An unsolvable problem of elementary number theory*. American Journal of Mathematics, 58(2), 345-363.

Church 使用希腊字母 λ（lambda）作为"绑定运算符"——它将变量名与表达式绑定。在 λ 演算中，所有表达式都会被求值（β-归约）。

#### 2.4.2 引号的语义功能（原 D.4.2）

但要操作"代码本身"（如元编程、自指），需要一种方式"引用"代码而**不求值**它——这就是引号的语义功能：
- 在 Lisp 中：`(quote (A B C))` 或简写 `'(A B C)`
- 在 MetaOCaml 中：`.<expr>.`
- 在 Rust 中：`quote! { ... }`

**引号的本质**：阻止求值，将代码作为数据引用。

#### 2.4.3 Q-引用与准引用（原 D.4.3）

Quine（1940）在《Mathematical Logic》中引入了"准引用"（quasiquotation）——允许在引号内部嵌入求值的表达式。这一概念后来被 Lisp 的 `` ` `` 语法（backquote）和 Rust 的 `#var` 语法采用。

### 2.5 闭包（Closure）与 SECD 机器（原 D.5）

#### 2.5.1 Landin 的贡献（原 D.5.1）

术语由 Peter Landin 在 1964 年定义：

> Landin, P. J. (1964). *The mechanical evaluation of expressions*. Computer Journal, 6(4), 308-320.

Landin 的 SECD 机器中，闭包被定义为"包含环境部分和控制部分"的结构。SECD 是 Lisp 编译器的第一个抽象机器模型。

#### 2.5.2 数学闭包的借用（原 D.5.2）

数学中的"闭包"（closure）指：
- 一个集合 S 在某个操作 op 下"闭合"——即对 S 中任意元素 a, b，`op(a, b)` 仍在 S 内
- 例：自然数集在加法下闭合（1+1=2 仍是自然数），但在减法下不闭合（1-2=-1 不是自然数）

Landin 借用这个概念：**函数加上其捕获的环境，形成了一个"闭合"的计算单元**——它携带了求值所需的全部信息，可以独立传递和调用。

#### 2.5.3 历史演化（原 D.5.3）

- **1964**：Landin 在 SECD 机器中形式化闭包
- **1970s**：Scheme 将闭包作为一等公民
- **1975**：Sussman & Steele 提出"闭包即对象"（continuation pattern）
- **1980s**：ML 系列语言引入类型化闭包
- **2020+**：OCaml 5 的 Effect Handlers 提供了"可挂起闭包"——闭包的演化形态

### 2.6 最小 I/O 副作用通道（原 D.6）

#### 2.6.1 不是"发明"，而是"发现"（原 D.6.1）

最小 I/O 副作用通道没有特定的"发明者"——它是自举理论的**自然产物**：
- **图灵机**：每个图灵机需要一个"读写头"作为 I/O 通道
- **λ 演算**：纯粹的计算是封闭的，但任何实际实现需要"输入"和"输出"
- **Guix hex0**：357 字节的种子必须能"读"和"写"机器码

#### 2.6.2 从汇编到能力模型（原 D.6.2）

最小 I/O 的实现方式随技术演进而升级：
- **机器码时代**：直接读写内存地址
- **汇编时代**：syscall 指令
- **C 时代**：`printf` / `scanf` 等标准库函数
- **Haskell 时代**：IO Monad（将副作用封装为类型）
- **2026 年**：能力模型 + 线性类型（编译期验证 I/O 权限）

#### 2.6.3 命名的"非命名性"（原 D.6.3）

这个术语的"非命名性"反映了它的根本性——它是自举的"边界条件"，不需要被发明，只需要被识别。

## 3. next2 讨论增补术语（v5.5 吸收）

| 术语 | 定义 | 出处语境 |
|------|------|---------|
| ANF（A-范式） | 将所有中间计算命名的 IR 形式（`Let` 绑定链）——简化优化与代码生成的现代编译器标准 | next2 批判审查（缺 Let 即缺 ANF） |
| CPS（延续传递风格） | 以显式 continuation 参数传递控制流的编程风格——可消除 `If` 但效率极低（每分支建闭包） | next2 方案 B（不推荐） |
| de Bruijn 索引 | 以词法位置（整数）替代变量名的绑定表示——"允许替换而不做 lambda 转换" | next2 方案 A（Stage 2 评估主题） |
| 行多态（Row Polymorphism） | 按结构（非名义）泛化的多态性——效应追踪与可扩展记录的类型基础 | next2 前沿全景（效应安全基础） |
| 效应安全（Effect Safety） | 类型系统静态确保所有效应都被处理（OCaml 5 缺失；Koka/Eff/Unison 具备） | next2 continuation 类型批判 |
| 闭包转换（Closure Conversion） | 将 `Fn` 显式化为携带环境的 `Closure` 的编译 pass——MLton 性能路径关键组件 | next2 修正四（MLton 风格） |
| comptime（编译期求值） | 用语言自身编写编译期元编程逻辑（Zig 模式）——多阶段编程的务实前身 | next2 前沿全景（生产就绪档） |
| continuation（延续） | 被挂起计算的恢复点（env + stack + resumption 类型三要素）——线性唯一性由类型系统保证 | next2 最终修正（类型安全续体） |

## 4. next3 讨论增补术语（v6.0 吸收——next3.md 第七轮「内部语法的根本性重构」）

| 术语 | 定义 |
|------|------|
| 派生关键词（Derived Keyword） | Racket `#%` 前缀式编译器内部形式（用户不可 shadow 的逃生舱）——`#%` 前缀是语法与 AST 同构（同像性）语境的历史妥协，本设计否决的旧方案（[01 §8](./01-core-forms.md)） |
| 表面语法（Surface Syntax） | 用户可见、可替换的语法层（皮肤）：S 表达式/中缀/DSL 经 Reader 桥接到核心形式（[01 §8.4](./01-core-forms.md)、[12 §2.4.1](./12-roadmap.md)） |
| 内部语法（Internal Syntax） | 编译器私有、不变的 AST 表示（骨架）：类型安全 ADT，用户不可构造（[01 §8](./01-core-forms.md)） |
| 命名行为导向原则 | 命名精确描述行为而非语法历史（`Branch`/`Apply` 而非 `if`/`App`）——原则 29（[17 §1.1](./17-principles.md)） |
| 类型安全优于命名安全原则 | AST 安全性由类型系统（ADT 私有构造子）保证而非命名约定（`#%` 前缀）——原则 30（[17 §1.1](./17-principles.md)） |
| 表面-内部语法严格分离原则 | 皮肤可替换、骨架不变，任何表面语法编译产物为相同核心形式——原则 31（[17 §1.1](./17-principles.md)） |

---

## 5. next4 讨论增补术语（v6.1 吸收——第八轮「2026 接口预留完整性审查」）

| 术语 | 定义 |
|------|------|
| 接口预留完整性审查 | 对预留层覆盖度的系统评估：既有六类（效应/能力/多阶段/缓存/类型/IR）覆盖 ~70%，补齐工具链生态 30% 缺口（[13 §3.3](./13-capability-matrix.md)） |
| 完全推迟（精确语义） | 尚未承诺采用的能力（保留选择权）；区别于接口预留的「已承诺采用、实现推迟」（期票语义，[13 §3.2](./13-capability-matrix.md) 边界调和） |
| LanguageService | 编译器作为语言服务器的查询接口 trait：语法树/补全/文档符号 + 定义/引用/类型 + 诊断/快速修复 + 重命名（P0，[13 §3.3.2](./13-capability-matrix.md)） |
| IncrementalAst | AST 增量更新接口：apply_edit / invalidate_range / reuse_unchanged——LSP 按需重析与增量编译的 AST 侧挂点（P0） |
| DebugInfoGenerator / DebugTraceable | 调试信息生成接口：IR 节点 ↔ 源码位置映射、变量位置查询、DWARF/源映射生成；IR 节点反向链接 AST + 调试名（P0，[13 §3.3.3](./13-capability-matrix.md)） |
| ExternalType / FfiBoundary | FFI 边界类型表示（CInt/CPointer/CStruct/CFunction/Opaque）与 GC 隔离协议（pin/unpin——外部引用不可回收）（P1，[13 §3.3.4](./13-capability-matrix.md)） |
| QuerySystem / Query | 查询式增量编译接口：纯函数查询 + 依赖完整声明 + 按需失效传播（salsa 风格，与编译缓存构成数据面/架构面双预留）（P0，[13 §3.3.5](./13-capability-matrix.md)） |
| CompilerService | 编译器即服务接口：提交/状态/结果/流式诊断/取消——可序列化状态 + 可中断恢复（P1，[13 §3.3.6](./13-capability-matrix.md)） |
| CodegenBackend / WasmBackend | 多目标后端 trait：supported_targets + compile + 后端特有优化；WASM 组件模型目标（P1，[13 §3.3.7](./13-capability-matrix.md)） |
| PackageManager / ExternalModule | 包管理接口：依赖图解析 + 产物获取 + 版本锁定；模块系统的包边界（P2，[13 §3.3.8](./13-capability-matrix.md)） |
| AiAssistant | AI 辅助语义 API：语义摘要/签名查询/快速类型检查/重构建议/文档注释生成——复用 LanguageService 查询基建（P2，[13 §3.3.9](./13-capability-matrix.md)） |
| P0-P3 预留优先级 | 按「不预留的破坏性代价」排序：P0 = 必须在 Stage 0 数据结构中预留位置（LSP/调试/增量）；P1 = 强烈建议 Stage 0 预留 trait（FFI/后端/服务化）；P2 = Stage 1 预留（包管理/AI）；P3 = Stage 3+ 可加（分布式效应）（[13 §3.5.1](./13-capability-matrix.md)） |
| 预留留白原则 | 原则 32：接口预留的本质是「为未来留出空间」而非「提前实现」——要求数据结构与类型定义的兼容性，而非功能的完整性（[17 §1](./17-principles.md)） |

## 5a. r32 表面现代化增补术语（v6.2——[20-表面规范](./20-surface-conventions.md) 载体）

| 术语 | 定义 |
|------|------|
| is- 前缀谓词 | 状态/类型谓词的现代命名形（`is-nil`/`is-pair`——2026 跨范式共识：Swift `is`/Kotlin `isX`/Rust `is_`）；取代 Lisp 家族 `?` 后缀（R2） |
| 方向词转换 | 转换函数的 `to`/`from` 命名（`string/to-symbol` + `symbol/from-string` 双向双家——Rust `to_`/`from_` 方向语义学）；取代 `->` 中缀（R4） |
| 命名空间限定名 | `模块/本地名` 形态的引用（`string/append`——`/` 为标识符内部分隔符，独立 `/` 维持除法；Clojure 同型词法裁定）；取代扁平前缀补丁（`str-`） |
| 别名层 | 零破坏迁移第一段：现代名与旧名双注册（行为 parity 逐字节锚定——别名层零语义变更不变量）；v0.5 批次 L |
| 能力-命名空间对齐 | 命名空间族边界与授权族边界重合（不变量 A）+ 机制分工两门（可见性门 import / 许可门 require——v1.1 精确化：import 不传播授权，[21 §4.3](./21-capability-architecture.md)） |
| 表面债 | 用户可见表面（命名/行为契约/组织）沿用历史家族形态累积的迁移成本——随库生长线性累积（原则 33 的量化对象） |
| 表面现代化动态演进原则 | 原则 33：每个引入新表面的设计时点对照当期前沿审视而非默认继承历史家族形态；标点后缀约定 = 前类型系统时代的补偿机制（[17 §1](./17-principles.md)） |

## 5b. r33 能力架构增补术语（v6.3——[21-能力架构](./21-capability-architecture.md) + [22-命名空间设计](./22-namespace-design.md) 载体）

| 术语 | 定义 |
|------|------|
| 工程能力 / 语言能力 / 授权（三义） | 「能力」三义定锚：工程能力 = 编译器构建技术（[13](./13-capability-matrix.md) 三层分类 owner）；语言能力 = 运行时能力域（[21 §2](./21-capability-architecture.md) L0-L3 owner）；授权 = 安全学术语 ocap（require 门控/FFI 令牌——[21 §4](./21-capability-architecture.md)）——禁互换 |
| 能力四要素 | 定位（解决什么问题）/边界（不解决什么——负空间）/职责（拥有的决策与不变量）/正交（与邻层的接口契约）——[21 §2.2](./21-capability-architecture.md) 每层一张卡；库能力域同构（[21 §3.1](./21-capability-architecture.md) 八域表） |
| 语言能力四层（L0-L3） | L0 值域（数据是什么）/L1 控制（计算怎么组合）/L2 效应（与外界怎么交互）/L3 授权（交互被谁允许）——[21 §2](./21-capability-architecture.md)；判层规则两问（唯一归属禁止跨层登记） |
| 正交判据（J1-J4） | J1 值-控交换律 / J2 效应-语义独立 / J3 许可-语义独立 / J4 效应-授权对偶——正交的操作化定义：任一层语义变更不引发另一层语义变更；各配既有实测锚（[21 §2.3](./21-capability-architecture.md)） |
| 授权三态 | 纯度态（函数级——静态纪律）/声明态（程序级——require 门控）/令牌态（值级——FFI External 线性持有）——粒度递进收紧（[21 §4.1](./21-capability-architecture.md)） |
| 六类迁移性质（M-R/D/I/L/E/A） | 原语级结构重构分类学：重命名/脱糖/索引化/层级迁移/效应化/新增——「原语级迁移 ≠ 重命名」（[21 §5.1](./21-capability-architecture.md)） |
| 不可归约性 / 单层归属（新原语准入两判据） | 提案必须附四要素卡 + ①不能由既有原语组合等价表达 ②J 判据过（跨层按受控债务登记——set! 先例）（[21 §5.6](./21-capability-architecture.md)） |
| 五层命名层级（N0-N4） | N0 符号宇宙（存在性）/N1 全局注册层（默认可见面）/N2 模块层（组织与授予）/N3 局部绑定层（作用域）/N4 保留字层（语法标记）——[22 §2](./22-namespace-design.md) |
| 解析优先序（R-N1） | 非限定名：N3 内向外 → N2 import 注入面 → N1 全局 → 未绑定错误；限定名：仅查该模块 export 面，不回落（R-N3）——[22 §3](./22-namespace-design.md) |
| 遮蔽许可表（R-N2） | N3 遮蔽 N1 合法；N3 遮蔽 N2 合法 + W 警告；同层 define 重复 = 错误；N4 不可遮蔽——[22 §3.2](./22-namespace-design.md) |
| import 不传播授权（红线 1） | import 授予名字可见性，require 授予操作许可——双门分立；import kerf-io 后未 require 调 print 仍 E0006（[22 §5.2](./22-namespace-design.md)） |
| kerf/ 保留域 | `kerf/` 前缀 = 标准库专属（用户模块不得使用——最小保留原则，Clojure `clojure.*` 同型）（[22 §7](./22-namespace-design.md)） |
| 能力正交与授权分层原则 | 原则 34（v6.4）：L0-L3 四层正交 + J1-J4 可审计判据 + 授权三态 fail-closed + 原语准入两判据（[17 §1](./17-principles.md)） |


## 5c. r34 演进治理增补术语（v6.4——[21-能力架构 v1.1](./21-capability-architecture.md) + [22-命名空间设计 v1.1](./22-namespace-design.md) + [23-演进治理](./23-evolution-governance.md) 载体）

| 术语 | 定义 |
|------|------|
| 三轴坐标系（L×N×P） | 语义轴 L0-L3 × 命名轴 N0-N4 × 相位轴 P0/P1（+ 实现轴 crate——工程轴非语义轴）；「L3′」记号已退役（命名机制升格独立轴非 L3 旁支）；判层三问 + L×N 交互矩阵（[21 §2.5](./21-capability-architecture.md)——owner） |
| 双轴归属 | 同一单元在两个轴上的独立登记（`=`：语义属关系域[链式值相等]，名形属运算符族[R6 符号冻结]——主从声明，非跨层违规）（[21 §2.5](./21-capability-architecture.md)） |
| 授权组合闭包（传递闭包显式化） | 程序头 require = 导入链全部模块授权需求的传递闭包显式声明；模块 require 声明 = 需求元数据非授权获得（编译期核对 `授权面(程序) ⊇ ⋃ 授权需求(导入闭包)`——WASI 无环境权威同构）（[21 §4.4](./21-capability-architecture.md)） |
| 编译期权威三判据 | 确定性（可复现构建）/零外部 I/O 或编译期令牌/展开可终止（预算制）——Phase 1 零授权面裁定的提案门（syntax-parse 类）（[21 §4.5](./21-capability-architecture.md)） |
| 诊断终止域 | `error`/`assert-eq?` 的域归属：终止性诊断发起（Err 吸收态 E5 δ 族）——**终止 ≠ 可拦截**（与 Perform 可拦截通道分立是设计裁定：终止不是副作用，不入门控表）（[21 §3.1](./21-capability-architecture.md) 十一域表第 10 卡） |
| 横切泛函域 | prelude 自有五件（map/filter/foldl/foldr/for-each）的域归属：任意可迭代域的高阶变换服务层——不持数据结构职责（[21 §3.1](./21-capability-architecture.md) 十一域表第 11 卡） |
| 演进六窗（K/L/M/E5/T3+） | 演进总时间线的窗口划分：批次 K 终批 → v0.5 批次 L 别名层 → v0.6 批次 M 命名空间层 → Stage 3 E5 一次性窗 → Stage 3+ 触发式族；每窗入口信号全满足才开窗（时间治理四红线）（[23 §2](./23-evolution-governance.md)——owner） |
| 时间治理四红线 | 禁止时间驱动切换/禁止处理程度倒挂/禁止无信号开窗/禁止窗口合并（改名与改行为永不混步）（[23 §2.3](./23-evolution-governance.md)） |
| 变更通道矩阵 | 每类变更对象的唯一通道与前置判据对账表（语义原语→E5 窗/关键字→N4 唯一通道/库表面名→L 别名渐进/效应族→J2 增族窗/授权族→J3J4/值类型→J1/码位→先占位后落位/模块→四表联动）（[23 §3.1](./23-evolution-governance.md)） |
| 受控债务通道（四步） | 跨层冲突的唯一合法处置：①登记（TD/裁定文档）②语义等价证明义务③清偿窗口声明④每轮深审复核——D5 set! 先例的流程化（[23 §3.3](./23-evolution-governance.md)） |
| 生命周期四阶段 | 引入（双注册/接口预留）→ 默认（新语料新规范）→ 弃用（W 警告）→ 移除（E 错误 + 负例组）——引入与移除永不同窗同面；弃用期最小一个稳定版本（[23 §3.4](./23-evolution-governance.md)） |
| 十二审计轴（A1-A12） | 设计缺陷审计的轴系：用户六轴（定位/权限/能力边界/职责边界/层级管理模型/演进时机）+ 发散六轴（组合语义/覆盖完备性/一致性/诊断对账/判据先于先例/元编程工具链交互）——轴系开放（增轴 = 准入流程增行）（[23 §1.1](./23-evolution-governance.md)） |
| 判据先于先例 | 原则 35（v6.5）：先例是佐证不是权威；向后锚定（停 1970）与向前锚定（抄某家族）等价失败；引证纪律 = 先判据后先例 + 跨家族取样 + 否决记录保留（[23 §4](./23-evolution-governance.md)） |

## 5d. r57 第九轮增补术语（v7.2——机制预留与接口预测悖论，[13-能力矩阵 v6.4 §3.6](./13-capability-matrix.md) + [17-原则 v6.7 原则 36/37](./17-principles.md) 载体）

| 术语 | 定义 |
|------|------|
| 接口预测悖论 | 前提「想为未来功能预留接口」+ 前提「不知道未来会出现什么功能」→ 结论「无法为不知道的东西预留接口」——无法通过更努力预测解决（逻辑不可能），只能改变问题本身（从「预留哪些接口」到「设计什么机制使添加新接口不需重构」）（[13 §3.6.1](./13-capability-matrix.md)——owner） |
| 机制预留（vs 接口预留） | 预留「打洞的能力」而非「特定的洞」——接口预留（14 项矩阵，原则 32）防已知需求的破坏性重构（冻结数据结构位置），机制预留（原则 36）防未知需求的不表达（保证表达通道）——两者正交互补不可互相替代（[13 §3.6.6](./13-capability-matrix.md)） |
| 三层未知防御 | 语义完备性（原语集图灵完备——数学保证）→ 机制通用性（自定义效应/宏展开/能力系统——工程保证）→ 组合无限性（机制可组合——生态保证）；判定流程：X 可计算→第一层，需新副作用/语法/资源→第二层，纯组合→第三层，不可计算→非语言功能（[13 §3.6.3](./13-capability-matrix.md)） |
| 三种打洞能力 | 自定义效应（`Perform(Custom) + Handle`——新副作用通道；实盘 = 01 效应原语 + 06 操作语义）/ 宏展开（卫生宏展开为核心原语组合——新语法通道；实盘 = 03 宏系统）/ 能力系统（`Capability` + fail-closed 门控——新资源通道；实盘 = 21 L3 授权层）（[13 §3.6.3](./13-capability-matrix.md) 实盘对账表） |
| 抽象-具体分离（开闭原则投影） | 原语集 = 抽象（对修改关闭——语义骨架永久不变）；宏/Handle/Capability = 抽象与具体分离机制（对扩展开放）；数学力量 = 抽象覆盖空间而非预测点（具体 = 一个点，抽象 = 一个空间）——OCP/依赖倒置/高阶函数/类型类是同一原理的范式投影（原则 37；[13 §3.6.4](./13-capability-matrix.md)） |
| 后期修改代价分级 | 重构级（数据结构/类型签名/契约——不可后期补救，改变数据结构 = 改变所有使用它的代码）vs 增量级（具体功能实现——可后期添加，替换实现不改接口）；操作化表述 = 「数据结构不可变，实现可替换」（[13 §3.5.4](./13-capability-matrix.md)） |
| 语法级 IR | S 表达式作为「语法层到语义层的过渡表示」的定位：非传统 IR（非优化对象）/非表面语法（Stage 2 后用户不直接写）/非核心语义（非原语）——Reader 输出、Expander 输入的骨架形态；Racket SyntaxObject（datum+scopes+phase+span）为其工业实证；本项目裁定 = 一次性脚手架（选择 A），永久中间层（选择 B）登记为替代设计（[02 §8.2](./02-syntax-model.md)——owner） |
| Stage 2a/2b（自举两阶段） | Stage 2a = S 表达式形态的完全自举（编译器编译自身输出等价）；Stage 2b = 语法替换（重写 + 删除旧 Reader 非转化编译器内部——五步流程）；「分裂」解法 = Stage 2 后开发语言 = 用户语言 = 目标语言（[07 §3.2.1](./07-bootstrap-strategy.md)——owner） |
| 编译速度四档预期 | Stage 0 验证 ~10μs/行 / Stage 1 开发 ~20μs/行 / Stage 2 增量 ~ms 级（整应用）/ Stage 3+ 发布 ~200μs/行 + 双路径策略（开发快速路径类 Zig 增量，发布慢速路径类 GCC -O2）；标杆 = TCC ~1μs/行（公开）/ Jai ~10μs/行（声明值不可复验）/ Zig 增量 10-50ms（[08 §4](./08-backend-evolution.md)——owner） |

## 5e. r58 第十轮增补术语（v7.3——优化桥接与 IR 正交精简，[13-能力矩阵 v6.5 §3.7](./13-capability-matrix.md) + [17-原则 v6.8 原则 38/39](./17-principles.md) 载体）

| 术语 | 定义 |
|------|------|
| 模式识别（Pattern Recognition） | 检测原语组合的结构特征（循环四特征：自引用 Apply//Branch 入口/参数更新链/纯循环；异常三特征：单 handler/不 resume/恒等 final）以判定其等价胖关键字形态——「模式识别作为通用适配器」（[13 §3.7.2](./13-capability-matrix.md) 判据表） |
| 等价替换（Equivalence Replacement） | 将识别出的原语组合标记并替换为胖关键字等价物（Loop/Try 标记 → LLVM phi 循环/landingpad 形式）——复用成熟优化体系的通行证；与模式识别合为单一 pass（识别即替换） |
| 双向桥接 | 极小原语经模式识别获得胖关键字优化能力（方向 A——LICM/向量化/展开/零成本异常六项复用）+ 保留细粒度信息获得胖关键字做不到的优化（方向 B——融合/部分求值/精确并行化六项独有）——A + B > 胖关键字（原则 38） |
| LICM | Loop-Invariant Code Motion 循环不变量外提——胖关键字循环优化族首例（经模式识别复用——接入对象 [19 §10](./19-references.md) LLVM 文档） |
| 零成本异常（Zero-Cost Exceptions） | 正常路径零开销的异常实现（landingpad/invoke 形态——异常模式等价替换的目标形式） |
| 四维正交（IR） | IR 层级的不可再合并根本维度：结构/语义/形式/目标——每层唯一维度，维度重复即合并候选（原则 39；[15 §5.2](./15-architecture-layers.md) 注记） |
| Pass 化（Pass 而非 Layer） | 优化作为单层（形式维度层）上的原地 pass 而非新 IR 层——零转换开销；「模式识别+等价替换」是同一 pass 的两阶段 |
| 单遍合并 | 可在同一次遍历完成的转换应合并（脱糖+标注单遍 / ANF+闭包+SSA 单遍）——转换次数最小化 = 编译速度与信息保真双重收益（5→3 次转换[40% 减]） |
| 优化就绪形式（Optimization-Ready Form） | ANF + 闭包 + SSA 的统一命名——形式维度 IR 层（Layer 3）的内容；六层规划的 AnnotatedANF/SSA 为维度重复层（四层修正案——Stage 2 优化窗裁定候选） |

## 5f. r59 第十一轮增补术语（v7.4——性能潜力裁定与双轨策略，[13-能力矩阵 v6.6 §3.7.5](./13-capability-matrix.md) + [17-原则 v6.9 原则 38 澄清](./17-principles.md) + [08 §5.4](./08-backend-evolution.md) 载体）

| 术语 | 定义 |
|------|------|
| 性能潜力（Performance Potential） | 极小原语性能论断的**理论上限**——信息更多 + 粒度更细 + 空间更大 ⇒ 潜力严格大于胖关键字；与开发成熟度为两个正交概念，混淆即偏见（判据级概念——性能讨论先过此区分）（[13 §3.7.5](./13-capability-matrix.md)） |
| 开发成熟度（Development Maturity） | 原语级优化体系的研究投入侧——胖关键字 50 年 vs 极小原语 ~30 年；当前性能差距的本质 = 研究投入差距非设计本质差距（可经双轨策略消除与反超） |
| 双轨性能策略（Dual-Track Strategy） | 轨道 A = 胖关键字优化复用（模式识别 + 等价替换接入成熟管线——「消除当前差距」）+ 轨道 B = 原语独有优化（细粒度信息 + 机制通用性——「超越胖关键字上限」；新的性能主要战场）；方向 A/B（[17 原则 38](./17-principles.md)）的策略层重述与预期层深化 |
| 三阶段性能预期（Three-Phase Performance Projection） | 短期[模式识别复用后]≈胖关键字水平 ~1/1.2 C / 中期[原语独有优化后]特定场景 1/1.0 甚至超越 / 长期[全程序优化成熟后]> 任何胖关键字语言（理论上限：保留完整语义信息的编译器的极限）——设计口径非承诺（Stage 2 优化窗开窗时实测对账）（[13 §3.7.5](./13-capability-matrix.md) + [08 §5.4](./08-backend-evolution.md)） |

## 5g. r62 第十二轮增补术语（v7.5——根空间架构与约束组合代数，[13-能力矩阵 v6.7 §3.8](./13-capability-matrix.md) + [17-原则 v7.0 原则 40](./17-principles.md) + [21 §2.6](./21-capability-architecture.md) 载体）

| 术语 | 定义 |
|------|------|
| 根空间（Root Space） | 预留与拓展能力的统一组织骨架——概念性占位（零语义载荷 marker/存在性标记）；语言本身即根空间，含编译器内部空间[对修改关闭] + 拓展预留空间[对扩展开放] + 基石空间[原语同一原料]（[13 §3.8](./13-capability-matrix.md)） |
| 子空间（Subspace） | 根空间经约束特化得到的空间——`子空间 = 根约束 ∩ 附加约束`（集合交集）；可递归划分并可实例化为具体类型（[13 §3.8](./13-capability-matrix.md)） |
| 约束特化（Constraint Specialization） | 空间间关系的正确数学描述——子空间是「约束更严格的集合」而非「继承的实现子类」；`trait A: B` = A 的约束包含 B 的约束（A ⊆ B——约束加强非实现继承） |
| 约束组合代数（Compositional Constraint Algebra） | 空间组合的数学本质——合取（交集 ∩，更严格）/析取（并集 ∪，更宽松）/否定（补集 ¬）；独立约束求交无菱形问题 |
| 约束的格（Constraint Lattice） | 空间形成的数学结构——⊤（全集）经逐级约束特化降至具体实例；任意两元素有唯一交与并（组合自由度的数学来源） |
| 属于（集合成员关系） | 实例与空间的关系——`instance ∈ Space ⟺ instance 满足 Space 全部约束`（非 is-a 实例化） |
| 上闭包（Upper Closure） | 以实例为元素的所有包含空间集合——`↑instance = { S | instance ∈ S }`（实例的归属全景查询） |
| 自相似/分形结构（Self-Similarity） | 根空间的层级组织特征——每一层用同样的基石（原语）构建，同一模式在不同尺度重复（层级 0 根→1 内部/拓展→2 子空间→3 实例） |
| marker trait（概念性占位） | 根空间的 Rust 形态——`#[marker] trait Extensible {}` 空标记零实现零语义载荷，仅声明空间归属（编译期存在运行时零开销） |
| 预留「空间」而非「点」 | 根空间的结构化预留价值——空间可容纳无限具体实例（无需预见具体）；接口预留预留点，根空间预留空间（接口预测悖论的组织层解法） |
| 编译器-拓展对称性 | 根空间三核心价值之三——编译器内部与用户拓展用同一基石（原语）构筑，体验统一（自相似的组织表达） |
| 依赖方向裁定（预留层 DIP） | 预留接口必须依赖抽象根空间而非具体实现类型——具体实现经「满足约束」归属空间，预留点零破坏演进（[13 §3.8](./13-capability-matrix.md)——r62 预留接口审计判据） |

## 5h. r63 第十三轮增补术语（v7.6——双向调试策略与脚手架哲学，[13-能力矩阵 v6.8 §3.9](./13-capability-matrix.md) + [17-原则 v7.1 原则 41](./17-principles.md) + [11-测试 §5](./11-testing.md) + [12-路线图 §2.11](./12-roadmap.md) 载体）

| 术语 | 定义 |
|------|------|
| 双向视图切换（Bidirectional View Switching） | 调试视图在任意 Level 间自由切换的能力——每次切换 = 模式识别 + 打包/拆包（Level 1↔2 经等价替换双向映射；Level 2↔3 经 ANF 转换；Level 3↔4 经代码生成）（[11 §5](./11-testing.md)） |
| 五级调试视图（Five-Level Debug View） | Level 0 用户源码/Level 1 胖关键字视图[粗粒度——宏意图等价显示]/Level 2 原语组合[细粒度——8 原语树 + Span]/Level 3 ANF-SSA[优化级]/Level 4 目标码[机器级]（[11 §5](./11-testing.md)） |
| 胖关键字视图（Fat-Keyword View） | 模式识别 + 反向打包生成的粗粒度调试表示——`Loop { init, cond, body, exit }` 形态的宏意图等价显示（传统宏调试看不到的「等价物」）（[11 §5](./11-testing.md)） |
| 模式识别器双重用途（Dual-Use Pattern Recognizer） | 同一个 PatternRecognizer（模式数据库不复制）既服务于优化（for_optimization→应用胖关键字优化）又服务于调试（for_debugging→生成胖关键字视图）——零额外基础设施（[13 §3.9](./13-capability-matrix.md)） |
| 调试视图（DebugView） | 双向调试的核心数据结构——{ level, representation, mappings }；mappings 与其他视图的双向映射关系是切换的关键（[11 §5](./11-testing.md)） |
| 视图映射（ViewMapping） | 胖关键字视图与原语视图间的双向对应关系——Vec<(PatternElement, CoreExprId)>（切换时保持位置关联的机制）（[11 §5](./11-testing.md)） |
| 脚手架哲学（Scaffolding Philosophy） | 一切「现实条件约束下的临时借用」遵循「借用→自建→拆除→超越」统一生命周期——先加速开发，待自建能力成熟后逐步拆除替换（[17 原则 41](./17-principles.md)） |
| 三阶段性能演进（Three-Phase Performance Evolution） | 借用（胖关键字优化——立即获得 50 年优化成果）→并行（双轨——胖关键字处理已识别模式 + 原语独有处理其余）→拆除（等价或更优的原语优化替代——完全释放极小原语潜力）（[13 §3.9](./13-capability-matrix.md)） |
| 信任脚手架（Trust Scaffold） | 第三种脚手架——Rust 宿主语言：Stage 0 搭建（全部用 Rust 实现）→ Stage 1 部分拆除（前端目标语言重写）→ Stage 2 完全拆除（全自举）→ Stage 3+ 仅保留为构建种子（[12 §2.11](./12-roadmap.md)） |
| 优化脚手架（Optimization Scaffold） | 胖关键字优化管线——Stage 3 搭建（模式识别接入现有优化）→ Stage 3-4 使用（立即性能）→ Stage 4+ 逐步拆除（原语优化替代；拆除后模式识别器保留转调试用途）（[12 §2.11](./12-roadmap.md)） |
| 脚手架拆除判据（Scaffold Removal Criterion） | 逐个替换的验证标准——自建替代 ≥ 被替换物 × 98% 或额外能力 > 0；安全替换 = fallback 保留 + 失败自动回滚（可逆操作）（[13 §3.9](./13-capability-matrix.md)） |
| 三个原创性创新点 | 本设计超越现有语言设计的自定位——约束组合的根空间 + 模式识别的双重用途 + 双轨性能→脚手架哲学（[13 §3.8/§3.9](./13-capability-matrix.md)） |

## 5i. r66 空间层级同步轮增补术语（v7.7——核心空间统一规划与双侧统一体系，[24-space-decomposition v2.0](./24-space-decomposition.md) 载体；**轮次标签 R4 顺修 r81**：本节为同步轮非 next 系列吸收轮——原「第十四轮」标签与 stage0.md F 附录 next 系列计数[next10 = 第十四轮]冲突，改名消除）

| 术语 | 定义 |
|------|------|
| 根空间（RootSpace） | 编译器自身——所有空间的根（原 `ExtensibleRoot` v2.0 改名——名实修复：下辖核心+拓展两个一级子空间，「可拓展的」修饰错位[可拓展的是拓展空间非根]）（[24 §11 N1](./24-space-decomposition.md)） |
| 核心空间（CoreSpace） | 根的一级子空间（闭集）——编译器自举部件的类型集合（v2.0 显式化：原「闭集不设 marker」裁定推翻——marker 载体 + 七核心域 + 三步程序对称适用）（[24 §3/§4.2](./24-space-decomposition.md)） |
| 拓展空间（ExtensionSpace） | 根的一级子空间（开集）——除自举核心外一切内容（原 `ExtensibleSpace` v2.0 改名——名词族统一）（[24 §11 N3](./24-space-decomposition.md)） |
| 元编程域（MetaprogrammingDomain） | 拓展域之一（原「语法域」改名）——语义载荷 = 代码操纵代码（quote/splice/相操纵；成员 MultiStage）（[24 §11 N2](./24-space-decomposition.md)） |
| 七核心域 | 核心空间正交划分（语言/前端/编译/后端/执行/横切/组织——15 §5.3 五正交轴宏观归并；每域 = 1-2 个职责同簇 crate）（[24 §4.2](./24-space-decomposition.md)） |
| 公理 A6 开闭性 | 核心空间成员变更权封闭（修改编译器仓库）；拓展空间开放（任何处实现契约）——**开闭差异是治理面差异非编码面差异**（编码面双侧统一 marker 家族）（[24 §3](./24-space-decomposition.md)） |
| 公理 A7 全树统一与单一事实源 | A1-A6 对全树适用（双侧同构审理）；物理组织（crate/mod 树）不承载空间语义——**从属唯一判据 = marker impl**（[24 §3](./24-space-decomposition.md)） |
| 统一编码分流治理 | v2.0 开闭原则的编码形态——双侧同一套 marker/公理/程序/证明（统一编码）+ 唯一合法差异 = A6 治理权（分流治理）（[24 §2.4](./24-space-decomposition.md)） |
| 做实面种子实现 | 拓展空间 L4 实现体（StdCapabilityIO 等做实类型——impl 预留契约加入开集；物理在 kerf-driver 但从属拓展侧——A7 物理不判据化；v1.0「做实面模块归核心」表述废除）（[24 §4.8](./24-space-decomposition.md)） |
| 层级深度自然差 | 核心四级（根→核心→域→类型——定义即实现）vs 拓展五级（根→拓展→域→契约→实现体——定义与实现分离）——开闭性的结构表达非对称缺陷（[24 §4.9](./24-space-decomposition.md)） |
| kerf-space 骨架 crate | 空间骨架物理家（零依赖被全 10 crate 依赖——Layer -1；q2 Rust core::marker 同型；依赖环唯一无损解）（[24 §5.4](./24-space-decomposition.md)） |
| 双侧对称判据（J8） | 核心侧与拓展侧的体系要素成对存在（载体/域 marker/程序/证明/烟囱）；唯一合法不对称 = A6 治理差异与深度差——超出即特殊化违例（[24 §6](./24-space-decomposition.md)） |
| 物理不判据化 | crate/目录/文件名与空间可以同构（方便映射）但不判据化——物理是从属的投影非依据（单一事实源纪律）（[24 §3 A7](./24-space-decomposition.md)） |
| 命名族一致性 | 同族同构的命名纪律——XSpace/XDomain 全名词族（RootSpace/CoreSpace/ExtensionSpace）；命名审理五判据（名实相符/族一致性/语义自明/歧义源消除/物理名可同构不判据化）（[24 §11](./24-space-decomposition.md)） |

## 5j. r81 第十四轮增补术语（v7.8——目标语言设计蓝图与错误统一效应模型，[17-原则 v7.4 原则 42/43](./17-principles.md) + stage0.md v7.3 §9.14/§9.15 + [19-参考文献 §15](./19-references.md) 载体）

| 术语 | 定义 |
|------|------|
| 计算流（Computation Flow） | 执行中的程序——流的表现形式全部统一：正常返回/异常抛出/错误传播/异步挂起/状态交互/IO 交互/自定义交互，全部经 Perform/Handle 描述（stage0.md §9.15.2） |
| 统一而分治（Unified Model, Divided Governance） | 效应系统的组织纪律——统一 = 模型统一（一个 Perform/Handle）；分治 = 策略分治（不同效应子空间不同处理策略）；不是特殊化而是参数化（stage0.md §9.15.2） |
| Error 子空间 | EffectSpace 下承载错误语义的子空间——throw/catch/finally 是其效应操作而非语言关键字；官方 Error 空间可整体替换（stage0.md §9.15.5） |
| Fatal 效应 | panic/abort 的统一模型形态——用户可定义语义的致命错误效应；halt() = 不 resume = 该计算分支终止（stage0.md §9.15.4） |
| 值级/效应级对偶（Value/Effect Duality） | Result\<T,E\>（值形态——显式数据传递）与 Error 效应（控制流形态——handler 分治）构成同一语义的两种投影；效应消除 = 效应级→值级编译变换（stage0.md §9.15.4） |
| one-shot continuation 纪律 | resume 至多调用一次的安全默认——多射 continuation 空间爆炸且禁止标准优化；多射需线性/仿射类型系统保护（stage0.md §9.15.6③——文献 [19 §15](./19-references.md)） |
| 编译期诊断（Compile-time Diagnostics） | 编译器元信息系统——Span 定位/严重度分级/多错误收集（r75-r80 生产实况）；与运行时 Error 效应正交——编译期检查是效应系统的静态投影（stage0.md §9.15.6①） |
| 六维身份定位（Six-Dimension Identity） | 目标语言的定位框架——表面[现代系统级]/内核[极小正交]/控制流[效应导向]/资源[能力模型]/性能[双轨顶级]/拓展[根空间无限]（stage0.md §9.14.1） |
| 生态扩展六维（Six Extension Dimensions） | EffectSpace/CapabilitySpace/SyntaxSpace/OptimizationSpace/ToolingSpace/ForeignSpace——官方/社区/用户三层来源；六维与 [24 §4.1](./24-space-decomposition.md) 拓展域六域一一对应（stage0.md §9.14.7——五维修正补全外域） |
| 渐进披露（Progressive Disclosure） | 同一语言按用户层级渐进暴露复杂性——初学者零效应知识可编程到专家级原语内部；分层 = 皮肤叠加非内核分叉（[17 原则 43](./17-principles.md)） |
| 行类型（Row Type / 开放记录） | 含 `...rest: Row` 开放行的记录类型——结构性多态载体（Stage 2+ 登记态——类型维前沿）（stage0.md §9.14.2） |
| 交叉类型（Intersection Type） | `A & B` 同时满足两约束的类型——约束合取的类型面投影（Stage 2+ 登记态）（stage0.md §9.14.2） |
| 模块=子空间映射 | `module core.io.network` = 根空间子空间层级的语言级投影——A2 逐级声明/A5 依赖方向/A3 唯一从属（stage0.md §9.14.3） |
| try/catch 语法糖（标准库宏形态） | try/catch 非语言核心机制而是标准库提供的宏——展开为 handle + 错误传播（再 Perform）；用户可定义自己的 try/catch 语义（stage0.md §9.15.3） |
| 开发者体验四层 | 初学者[零效应知识]/进阶[效应标注+能力]/高级[自定义效应+宏]/专家[原语内部+规范演进]——渐进披露的用户面表述（stage0.md §9.14.6） |


## 6. 诊断码位登记表（r25/42-f W3 回写——结构化阶段码全族总账）

| 码位 | 族 | 引入 | 定义锚 |
|------|----|------|--------|
| E0001-E0004 | 阶段码（词法/语法/展开/运行时类型） | Stage 0 | kerf-span/diagnostic.rs（渲染 `error[E000N]`）；运行时类型族经 driver `from_vm` 映射 |
| E0005 | 静态类型检查（保守 R1-R8） | r7 批次 C | typecheck.rs |
| E0006 | 能力权限（R9 fail-closed） | r8 批次 D | capability.rs（`IO_PERMISSION_CODE`） |
| **E0007** | **效应未处理逃逸**（未匹配 tag 上抛到顶层） | **r25/42-f** | effect-language-design D9；messages.rs `err_effect_unhandled`（单源——VM `Perform` 扫描无匹配） |
| **E0008** | **continuation 二次恢复**（线性唯一性违反——含首次恢复位置追踪） | **r25/42-f** | 同上 D3/D9；`err_continuation_resumed_twice`（VM `Call`/`TailCall` 的 Continuation 臂） |
| **E0009** | **resume 元数面**（continuation 调用恰一实参；非 continuation 值被调用的类型面归 E0004 通用族——effect-language-design v1.1 执行注记口径） | **r25/42-f** | 同上 D4；`err_resume_arity` |
| **E0010** | **FFI 令牌失效后使用**（双释/用后传递/用后使用——消费全局生效后的吸收态） | **r30/48-d 落位** | ffi-ownership-model §5；messages.rs `err_ffi_token_invalid`（单源——VM free_external/call_external 令牌校验） |
| **E0011** | **FFI 所有权/类型违规**（释放 Opaque 令牌/非令牌值/实参形状不匹配/零尺寸纵深防御） | **r30/48-d 落位** | 同上 §2/§6-case4；`err_ffi_ownership`（VM 编组与 free 判定序） |
| **E0012** | **FFI 符号解析失败**（extern 符号表未登记——fail-closed；QBE AOT 链接期解析在 VM 路径的调用期对应物） | **r30/48-d 落位** | 同上 §4；`err_ffi_symbol_resolution`（VM CallExternal 符号解析 + 空表默认入口） |
| **E0020** | **保留字绑定禁令（r41 / 62-a 语言形式深审轮——D10 裁定）**：N4 关键字 25 名全域禁作绑定名（define/set!/lambda 参数/let 系/define-syntax 宏名/module 名/import as 别名/handle 双绑定器）——22 §2.1 N4 不变量「不是值、不可引用、不可遮蔽」的编译期执行；Stx 源码面 + CoreExpr 展开产物面双层；syntax-rules 模板数据域跳过；quote 位数据符号豁免 | **已落地（r41——Compile 族，driver front 管线验证**：`verify_reserved_bindings_stx`[expand 前拦截] + `verify_reserved_bindings_core`[展开产物防御纵深]；12 case 锚定 namespace_tests d10 组；837:0:0 净 +12 | [22 §11 D10](./22-namespace-design.md) 深审轮二裁定 + [22 §2.1](./22-namespace-design.md) N4 行三件套执行注记 |
| **E0021** | **已移除旧名引用（r42 / 63-b 移除轮 S1——20 §7 移除轮行兑现；r43 / E5 S2 扩展——22 §12 D29）**：v0.9 起旧名 27 件退役（`REMOVED_BUILTIN_NAMES` 单源 27 对[旧名→现代名]）；**v0.10 起关键字旧形 3 件退役（`lambda`/`set!`/`begin`——S2 腿切换 fn/assign/do 后旧形入同一拒绝面[D29]）**；旧名引用（值位/操作位全域）→ 编译期拒绝，诊断携现代名指引（比裸 E0004 未绑定 actionable——迁移期 DX 最优形态）；遮蔽/接管豁免与 E0014 同口径（N3 局部绑定胜出 + 用户接管合法——退役的是内置注册面/关键字面非符号宇宙层） | **已落地（r42——Compile 族，driver `verify_qualified_refs` 与 E0014 同 traversal**：[E0021] 渲染前缀 + 现代名指引消息；stdlib_tests removed_rejects_* 27 名全覆盖负例组 + namespace_tests s1 组[恢复健康 + 位置面] + 闭合守卫 removed_names_group_covers_all_27 双向对账；注册面 84→57 扁平 + 828:0:0；**r43 扩展：REMOVED_KEYWORD_NAMES 3 对 + s2 负例组[旧形→新形指引 + 接管豁免]） | [20 §7](./20-surface-conventions.md) 移除轮行 + [20 §8](./20-surface-conventions.md) 映射表（单源）+ [22 §12 D29](./22-namespace-design.md)（关键字旧名扩展裁定）+ [23 §3.4](./23-evolution-governance.md) 生命周期四阶段（本码 = 第四阶段「移除」的机器执行——S1 内置腿 + S2 关键字腿双承载） |
| **E0022** | **编译期未绑定引用（r46 / 67-b——R-N1 第 4 步载体；22 §15 D49；**r47 / 68-b 面核对升级——22 §15.4 D55**：基准从全局面升级为**可见面** = N1 核心面 38 名[`N1_CORE_NAMES` 单源] ∪ import 扁平运行时载荷[`flat_underlying`——含 prelude 再导出边际 7 名] ∪ 程序 define 面；消息升级逐层明细「已查：N3 局部绑定 ✗ · N2 import 注入面[未导入——(import kerf-ns) 后可用/无同名模块导出] ✗ · N1 核心面 ✗」+ `suggest_import_for` 导入建议单源[prelude 高频集优先 + underlying 反查]）**：非限定 Var 引用与 assign 目标在 front 编译期核对——基准 = 编译产物 `global_refs`（编译器已完成局部消解：Fn 参数/Let 槽/卫生名不误报）∩ 已定义集（内置授权面 ∪ 程序 define 面[define-only——assign 名不构成定义]）；卫生后缀名按运行期回退解析同逻辑（基名命中即过）；限定名（`/`）与未授权门控名不参与（E0014/E0006 语义域先行）。HM A4 动态逃生舱语义收敛（E0022 先于 HM 判定面——未绑定 = 拼写错误或缺 import，编译期即拒）；运行期 E0004 未绑定族保留为防御纵深（非 front 路径） | **已落地（r46——Compile 族，driver `verify_unbound_refs` front 4.5 步[compile 后]**：E0022 + 「查过 N3 局部绑定（编译期局部消解）与 N1 全局注册面」消息 + find_var_span 树序 DFS span 归因[A1 求值序契约的编译期镜像]；15 处既有测试期望语义保持型迁移 + d49 组 3 case；**实证捕获 compiler.krf 平行 let 值域违例**[cc-locals-push! 第四绑定值引用同组前位绑定——r45 潜伏缺陷当场修复]；625:0:0 | [22 §15 D49](./22-namespace-design.md)（裁定本体 + 实施对账）+ [22 §3.1](./22-namespace-design.md) R-N1 第 4 步（设计文本源）+ 21 §4.7 调用通道表（E0022 在六通道的分布行） |
| **E0023** | **module 表达式位结构化拒绝（r49 / 70-b——22 §17 D59）**：`(fn (x) (module m 1))` 类表达式位 module → 展开期拒绝（此前无检查——inline 静默编译[proto 名覆写旁路]收紧为显式失败；与 import/export E0002 消息形态对称：module 是编译单元组织形式非表达式；**合法位 = 程序顶层/module 体直接元素位/do-splice 项位**） | **已落地（r49——Expand 族，expander `expand_core_form` Module 臂）**：d59_module_position_e0023_expression 2 case（fn 体 + if 臂位） | [22 §17 D59](./22-namespace-design.md)（裁定本体 + 实施对账） |
| **E0024** | **选择性导入成员不在导出面（r50 / 71-b——22 §18.3 D65）**：`(import kerf-string (nonexist))` 类成员名不在模块导出面 → 编译期拒绝（选择子集 = 扁平注入面过滤[E0022 可见面按成员过滤]；限定名访问维持模块级关系；prelude 成员经 PRELUDE_EXPORT_NAMES 判定） | **已落地（r50——Compile 族，driver `verify_import_face` E0024 臂）**：d66 ④ case + CLI E2E | [22 §18.3 D65](./22-namespace-design.md)（裁定本体） |
| **W1003** | **宏名遮蔽内置名警告（r42 / 63-b——22 §11 D11 排期移除轮同窗兑现；**r47 / 68-b face-aware——数据源 = 可见扁平面 ∩ 注册面**：不可见面名自由定义零 W[限定名宏查模块 ∈ 导入集/别名集]——D54 ② 零误报纪律**）**：`define-syntax` 宏名 ∈ 内置注册面（57 扁平 + 47 限定）→ W 级知会（宏胜出是宏系统本质能力[用户重定义语义合法场景]——遮蔽内置名值得知会；意图不可判定[故意 vs 意外] → W 级是唯一可判定位） | **已落地（r42——driver `collect_warnings`（Stx 层宏名收集——宏展开后名字从 CoreExpr 消失，此面唯一数据源）**：`[W1003]` 渲染前缀 + 每名去重一条；namespace_tests s1_w1003 组 2 case[正例知会 + 非内置名零误报 + 限定名遮蔽 + 宏胜出行为不变]；W 面现状 = W1002/W1003 | [22 §11 D11](./22-namespace-design.md) 裁定原文 + [22 §10 D6](./22-namespace-design.md) W 族值域设计（W 独立值域 1000+） |
| **E0013-E0019** | **命名空间族（批次 M 预留段）**：import 冲突（两模块同名导出）——**r47 / 68-b 注记：E0013 判据重基 underlying 同一性（22 §15.4 D55-b——本地名词法碰撞重基为扁平运行时载荷碰撞[underlying 同名且分派体相异 = 真冲突]；stdlib 七模块 underlying 即分派身份 → 标准库域结构性零冲突[kerf-string + kerf-list 并存合法]；prelude 再导出 nth/drop 与 kerf-list 同 underlying 非冲突[D50 ②再导出感知]；E0013 通道保留——Stage 3+ 用户模块窗口触发[用户模块导出面同名异体]）**/限定名不导出（`string/nonexist`）/保留域违例（`kerf-` 前缀用户占用）/重复定义（module 体内同名 define）/别名重复/require 位置违例/未知导入模块 + **W 弃用警告族**（独立值域 1000+——M2 D6 裁定） | **全段落位（r39 M1 + r40 M2——七码全实施**：E0013 import 冲突/E0014 不导出/E0015 保留域/E0016 module 内重复 define/E0017 别名重复/E0018 require 位置[深审 D3]/E0019 未知导入[深审 D2]——driver front 管线验证族，stage 统一 Compile；W1001 弃用族 27 件 + W1002 遮蔽族——**r42/S1 注记：W1001 已随旧名退役下线（旧名升 E0021 编译期阻断——W 面收窄至 W1002/W1003）**，preamble 结构性豁免保留守 W1002 注入遮蔽误报） | [22 §8 实施对账表](./22-namespace-design.md) 各 case 的码位需求面 + [22 §10 D1-D9](./22-namespace-design.md) 深审裁定；「先查本表占位」纪律兑现（r34 预登记 → r39/r40 逐码落位回填） |

**登记纪律**：新码位 = 先查本表占位 → 模型层单源构造（TD-018）→ 回填本表 + 对应族文档锚。禁止未登记静默占位。

## 5k. r83 第十五轮增补术语（v7.9——语法定义形式与语法文件体系，[17-原则 v7.5 原则 44](./17-principles.md) + stage0.md v7.4 §9.16 + [02-语法模型 §8.4](./02-syntax-model.md) + [19-参考文献 §16](./19-references.md) 载体）

| 术语 | 定义（一句话） | 锚点 |
|---|---|---|
| EBNF（扩展巴科斯-瑙尔范式） | 以产生式 `::=` 定义形式语言的记法族——W3C 风格（`|` 选择 + `(* *)` 注释）为 kerf 登记记法（ISO 14977 记法弃用——Wheeler 批评锚） | stage0 §9.16.2 / 02 §8.4 |
| W3C EBNF 记法 | XML 1.0 规范 §6 所用 EBNF 风格——30 年规范工业实证；kerf grammar 文件记法先例（产生式后附语义/诊断锚注释——「well-formedness 约束」同构形态） | stage0 §9.16.2 / 19 §16-112 |
| PEG（解析表达文法） | Ford 2004——有序选择 + 前瞻断言的解析形式体系（「解析器即文法」）；kerf 登记为 Stage 2+ 实现参考锚非规范记法（定义/解析分离——裁定 G-B） | stage0 §9.16.2 / 19 §16-111 |
| 语法文件（grammar 单源） | 语法定义的文档侧唯一权威呈现——记法层/规范层/实现层/工具层四层组织模型的 L2（02 §8.4 落位——含 Stage 0 事实文法 + Stage 2+ 骨架索引 + 优先级表 + 诊断锚关联） | stage0 §9.16.5 / 02 §8.4 |
| 定义形式/实现形式分离 | EBNF 登记 ≠ 生成器输入——语言定义在 CFG 语义层面，解析在实现层面（手写递归下降）；语法生成器永不入自举链（LLVM 同构纪律——裁定 G-C） | stage0 §9.16.2 / 原则 44 |
| enforestation（语法编队） | Rhombus 的解析器可编程语法扩展前沿——与 EBNF 静态定义构成动态扩展/静态定义正交两轴；kerf 选静态定义 + syntax-rules 宏动态扩展 | stage0 §9.16.6 广度补充 |

**登记纪律**：新术语 = 先查本表占位 → 单源构造 → 回填本表 + 对应族文档锚。本轮六条全量对账 [stage0 附录 A v7.4 增补六条](../stage0.md)——术语面双侧同步（18 §5k ↔ stage0 附录 A）。

## 5l. r84 第十六轮增补术语（v7.10——效应本体论与目标语言极简设计，[17-原则 v7.6 原则 45](./17-principles.md) + stage0.md v7.5 §9.17 + [02-语法模型 §8.5](./02-syntax-model.md) + [05-运行时 §7](./05-runtime.md) + [19-参考文献 §17](./19-references.md) 载体）

| 术语 | 定义 |
|---|---|
| 效应本体论 | 效应「是什么」的哲学层定位——传统（副作用二元论）/Koka-Unison（标注论）/用户理论（容器论→概率域论→生命周期论）三种对照（stage0 §9.17.4） |
| 容器模型 | 用户理论 v1——效应是容器、类型是内容；`fn f() -> Return(i64) \| Error` 返回区域整体即效应；类型 ⊂ 效应（效应可空容器）（stage0 §9.17.3） |
| 概率域模型 | 用户理论 v2——效应 = 行为/工具/内容/后续四维概率空间（`Action × Mechanism × Payload × Continuation`）；容器只是域的投影（stage0 §9.17.4） |
| 效应生命周期 | 用户理论 v3——效应 = Perform 构造（概率域未坍缩）→ Handle 投影（坍缩为实例）→ Resume 后续（可选桥梁）的完整动态过程（stage0 §9.17.4） |
| Resume 可选性 | 不 resume = 完全合法的流终止；与 one-shot 纪律合围 resume ∈ {0,1} 完整语义（stage0 §9.17.4） |
| 十七关键字 | 目标语言核心关键字极简清单——结构 4/绑定控制 4/类型 2/效应 3/能力 2/其他 2；全部其他功能经宏或效应实现（Stage 2+ 登记态——与 Stage 0 25 关键字正交分层）（stage0 §9.17.2） |
| 宏层熟悉语法 | try!/async!/while!/for! 标准库宏——看起来像关键字但属于库（可不使用/可修改/可自定义）；与渐进披露四层协同（stage0 §9.17.2） |
| 效应内嵌标注（方案 A） | `-> i64 + {Error}` Koka 风格内嵌式——被用户否决的中间形态（二元分离残留）；演进链教训登记（stage0 §9.17.3） |
| 容器式签名 | `fn f() -> Return(T) \| E` 目标语言签名形态登记终态草案（#15 门控——窗内定稿 ` \|` 分隔符与行多态形态）（stage0 §9.17.3） |
| 二义性三策略 | Reject 编译拒绝 / RequireDisambiguation 显式消歧 / PriorityRule 语言规则优先级——目标表面语法二义性审理处置面（#15 切换窗定稿义务组成）（stage0 §9.17.6） |
| 空间接口契约（SpaceContract） | 空间理论的形式化接口面——六接口（space_id/parent_space/capabilities/register_member/lookup_member/communicate_with）+ TypeWitness 类型安全见证；24 六域的接口面投影（Stage 2+）（stage0 §9.17.7） |
| Diagnostic 完备架构 | 编译期诊断 Stage 2+ 完备化方向——DiagnosticCode 稳定编码/Suggestion 结构化建议/children 辅助位置链/EffectContext 效应关联（stage0 §9.17.7） |
| 效应上下文关联（EffectContext） | 诊断与效应系统的静态投影关联——effect_row + is_handler_error + continuation_type；F13 两通道分立的关联面（stage0 §9.17.7） |
| 设计完整性矩阵 | 语料十维自评——登记为讨论时点档案；kerf 实况修正（grammar 单源 r83/诊断骨架 r75-r80/二义性机制 r84）（R4 口径）（stage0 §9.17.7） |
| 河流隐喻 | 用户理论核心隐喻——程序 = 河流/数据流 = 河水/函数 = 河流一段/返回 = 抽样（stage0 §9.17.4） |
| 计算实例化关系倒置 | 现有「计算是主体、效应是属性」vs 用户「效应是主体（概率域）、计算是实例（域中的点）」——本体论级重构登记（stage0 §9.17.4） |
| 同一系统两种描述 | 理论终态裁定——用户理论与 Koka/OCaml 5 机制 100% 兼容（零实现成本），差异在解释深度（牛顿力学 vs 广义相对论类比）（stage0 §9.17.5） |

### 5m. 第十七轮术语：效应流形与空间理论定位（v7.11 新增——r88 第十七轮吸收，同步自 stage0.md v7.6 附录 A）

| 术语 | 定义 |
|---|---|
| 效应流形（隐喻） | 用户理论 v4——效应的完整高维空间（效应 + 连接关系网络）；**隐喻性术语**：数学实质 = 带连接的效应范畴/图（EffectGraph），非拓扑流形（原则 46 I-B 裁定） |
| 三连接公理 | 流形理论核心——串联（A 的后续是 B 的开始，B∘A）/ 嵌套（A 的投影内含 B）/ 循环（A 的开始是 B 的结束，A⟲B）；三连接在 8 原语中均可表达 |
| 切片（slice） | 函数返回类型 = 效应流形的降维投影；效应行 = 切片的标签（保留降维信息的类型系统载体） |
| 升降维对偶 | project(lift(v)) = v（限 lift 定义域内）+ lift(project(M)) ⊇ M（超集恢复）；语义层登记非拓扑断言 |
| 降维仪 | Handle = 选择切片方向（从哪个维度观测效应流形）；嵌套 Handle = 多维观测（复合投影） |
| 设计宪法 | 核心概念五定义集中权威源（效应/效应容器/根空间/8 原语/返回区域）——概念漂移的集中防护点（第一查询锚） |
| 概念漂移检测 | 多轮讨论一致性维护——概念早期/中期/当前定义对照 + 统一为最新 |
| 效应行合一算法 | effect_row(f) = ⋃ perform 效应 ∪ {Return(T_body)}；含流形五步扩展（收集→识别连接→构建效应图→计算效应行→附加连接注解） |
| 小步操作语义 | 配置 ⟨e, ρ, σ, κ⟩ 的逐步归约（五规则）；Stage 2+ 登记态（大步归约零变更） |
| Return 形态裁定 | Return 在 8 原语中的表示——Handle 的 final: Var(0) 恒等 + 表达式值即返回值；零新增原语 |
| 十五关键字 | 目标语言关键字极简终版——17 关键字演进（impl 并入 type + linear 降为类型标注）；关键字减二表达能力不减 |
| EBNF v3 | 效应容器模型完整重写版——effect_union 容器式 + Never + handler_body 含 pass + connect/lift/project；grammar L2 第二份骨架语料 |
| pass 穿透 | handler_body 第四形态——不处理该效应继续向上传播（T-EFFECT-PROPAGATION 的语法载体） |
| 坐标系/地图裁定 | 空间理论 = 坐标系（组织工具——不「做」事只「组织」事）；模型 = 坐标系中的点；不混淆 + 不分离两纪律 |
| 低熵控制 | 空间理论的信息论性质——正交分解消冗余/层级链消歧义/约束组合消冲突；A1-A7 的信息论再表述（零新公理） |
| 七维度正交 | 空间实例描述轴——定性/定位/职责/能力/边界/权限/协同；与六域层级分类正交互补（横 × 纵） |
| 七步坐标确定 | 模型入位程序——定性→定位→职责→能力→边界→权限→协同；三步从属审理的全维展开 |
| SpaceRegistry 协议 | 空间运行时协议——register/discover/compose 三协议；与 SpaceContract 接口面互补（Stage 2+） |
| SpaceValidationPass | 空间理论编译期强制——四验证（唯一归属/层级链/同级正交/容器类型）；Stage 2+ 登记态 |
| EffectTrace 桥接层 | 信息系统三层架构的层 3——效应执行观测设施（调试 + 性能分析双用途）；F13 两通道的新覆盖层 |
| EffectGraph | 效应流形的编译器内部表示（Arena 节点 + 三边型 + entry/exit；slice/project/lift 三操作）；Stage 2+ 分析层登记 |
| 流形分析 Pass | EffectManifoldAnalysisPass——MergeSequential/HoistNested/DetectLoop 优化机会；Layer 2→3 执行 |
| EffectDiagnosticContext | 诊断的效应关联子结构——kind 四枚举 + 流形扩展五类（IncompleteConnection 等） |

### 5n. 第十八轮术语：逆向效应流与计算干涉（v7.12 新增——r89 第十八轮吸收，同步自 stage0.md v7.7 附录 A）

> 载体：[17-原则 v7.8 原则 47](./17-principles.md) + stage0.md v7.7 §9.19 + [02-语法模型 §8.7](./02-syntax-model.md) + [05-运行时 §9](./05-runtime.md) + [06-操作语义 §11](./06-operational-semantics.md) + [19-参考文献 §19](./19-references.md)。

| 术语 | 定义 |
|------|------|
| 逆向效应流（Reverse Effect Flow） | 用户理论 v5——效应流形的对偶环：正向分形（一变多）的逆向 = 聚合（多变一）；Consume/Offer/Rewind 三逆操作 + 汇流/收拢/收敛三逆连接；解释框架层第五环 |
| Consume / Offer / Rewind | 逆向三操作 = 正向三原语使用模式——Consume = Perform(Receive)（等待接收）/ Offer = Handle 服务提供模式（聚合多个）/ Rewind = Resume 多播形态（回传多个等待者）；零新增原语（J-A） |
| 汇流 / 收拢 / 收敛（Confluence / Coalescing / Convergence） | 三逆连接——串联逆转（分流→汇流）/ 嵌套逆转（展开→收拢）/ 循环逆转（发散→收敛到不动点）；「收拢」≠「坍缩」（同形异义消歧——前者 = 逆向嵌套聚合动作，后者 = 投影选择结果） |
| 双幺半群（Bimonoid） | 效应流形完整代数 `(Effect, →, ←, ∅)`——正向幺半群 + 逆向幺半群共享单位元 + 对偶关系；分配律开放问题（若成立升级辫子幺半群） |
| 对偶范畴（Dual Category） | 正向范畴^op ≅ 逆向范畴（恒等 Resume↔Rewind）；逆向结构由正向通过对偶自动获得（正向定理 → 对偶化 → 逆向定理） |
| 知识不对称（Knowledge Asymmetry） | 逆向不可替代性判据——汇聚点全局知识 vs 分支点局部知识；全局解不可分解为局部解组合时必须逆向；四领域（共识/收敛/事务/资源回收） |
| 正逆组合语义（Forward-Reverse Composition） | 四组合规则——正逆串联管道 / 逆向内部串联 / 正向外壳逆向内部 / 逆向外壳正向内部；[T-PIPELINE]/[T-SHUTDOWN]（正逆配对湮灭）等五类型规则 |
| 双向 Continuation（Bidirectional Continuation） | 逆向运行时机制（Stage 2+ 登记）——Forward 单播恢复 vs Rewind{waiters} 多播回传；EffectScheduler 三队列四方法 |
| 计算干涉（Computational Interference——隐喻） | 多效应流共享资源时的结构性效应——三模式（构造性相长/破坏性相消→非对易/纠缠关联）；**隐喻性术语**：经典非对易性结构非物理量子（J-B） |
| 非对易性 / 交换子（Non-commutativity / Commutator） | 干涉数学核心 `[A,B]_R = A∘B(R) ⊖ B∘A(R)`；实例 A=+1/B=×2 → −1 ≠ 0；量子 `[A,B] = AB−BA` 的计算版本同构 |
| 计算不确定性原理（Computational Uncertainty Principle） | 非对易 Handle 无法「同时确定」效果——必须选择一个顺序（坍缩）；[T-UNCERTAINTY] 编译器警告形态 |
| 伪随机坍缩（Pseudo-random Collapse） | 坍缩谱系中环——确定性坍缩 → 伪随机（P₁+P₂=1）→ 真随机（量子预留）；两路径 = Randomness 效应+条件分支 / 多 Offer 竞争+加权调度 |
| Randomness 效应 | 伪随机源的语言级效应面——next/with_seed/uniform/normal/exponential/weighted_choice/shuffle；实现层 PCG32；测试模式固定种子可重现；策略外置（J-E） |
| CollapseScheduler | 伪随机坍缩运行时（Stage 2+）——Pcg32 + competitive_offers 加权表 + 轮盘赌选择 + deterministic_select 传统模式 |
| InterferenceAnalysisPass | 干涉分析编译器 Pass（Stage 2+）——共享资源识别 → 非对易对检测 → ComputationalUncertainty 诊断 → 优化三分支；EffectGraph 三 Pass 分立之一 |
| EBNF v4（正逆干涉版） | 第三份骨架语料——逆向语法族（consume/offer/rewind/absorb/aggregate/pipeline）+ 干涉语法族（interference_decl）+ 概率语法族（probabilistic/competitive/weight） |
| 关键字张力（Keyword Tension） | v4 新关键字候选（~10 个）与 15 关键字极简方向的张力——窗内「实现就绪度 + 极简义务」双判据裁定；备选 = 宏层脱糖零关键字路径 |
| 统一五层框架（Unified Five-Layer Framework） | 全体系层次化总图——0 原语/1 生命周期/2 流形（正+逆）/3 干涉坍缩/4 空间理论/5 应用领域；总图形态登记非新理论增量（J-F） |
| 计算量子力学三层（Computational QM Layers） | 量子化层次框架——0 经典确定性（当前）/ 1 经典概率（伪随机）/ 2 计算量子（复概率幅+幺正约束——预留非承诺；E.19-126 Selinger 锚） |

### 5o. 第十九轮术语：数学工具箱分级与波粒二象性（v7.13 新增——r91 第十九轮吸收，同步自 stage0.md v7.8 附录 A）

| 术语 | 定义 |
|---|---|
| 数学工具箱分级（K-A） | 「实例化数学」降格三级形态——组合拓扑精确同构可用/微分几何离散化对应物登记/量子隐喻维持 |
| 组合拓扑分析 | H₀ 连通分量（并行性）/ H₁ 一维洞（死锁检测）/ H₂ 空腔/上同调（守恒量）/ π₁ 同伦等价/欧拉示性数——图上可精确计算 |
| 离散外微积分（DEC） | 微分几何工具的离散化对应物——Whitney 形式基/离散外微分算子（d∘d=0 + Stokes 离散精确版）；E.20-123 |
| 维度谱系六阶 | 0 维（点）/ 1 维（串联）/ 2 维（fork/join 网络）/ 3 维（嵌套）/ N 维（张量积）/ ∞ 维（效应场——理论极限形态） |
| 波粒二象性（Wave-Particle Duality） | 用户理论 v6——解释框架层第六环：粒子性（perform 离散事件）vs 波动性（流形连续传播）；K-C |
| EffectNature 三态 | Particle/Wave/Superposition（叠加态 = 两者共存 + 干涉项耦合）——登记态 |
| EffectUncertainty（两形态） | 位置-动量版（Δposition×Δmomentum ≥ ℏ_effect——r91）与顺序版（r89）——[T-UNCERTAINTY] 诊断族 |
| 路径积分计算版 | `结果 = ∑ 所有处理路径 Weight[path]`——枚举语义（与交换子差分语义互补）；NP-hard 风险登记 |
| 效应纠缠（Effect Entanglement） | 事务原子性（AllOrNothing）与分布式共识（Correlated/Majority）的代数结构隐喻——经典实现不可达原语级形态 |
| 贝尔不等式计算版 | 诊断性构造——经典关联必然 ≤ 经典上限；`QuantumAdvantage::Present` 不可达分支 = 守卫代码形态（K-B） |
| 量子场论映射九对 | 场→效应流形/粒子→perform 事件/激发/传播子→Handle 链/相互作用→干涉/费曼图/真空/虚粒子→未被 Handle 的效应/重整化→归一化 |
| 五层理论 vs 四阶段实现（K-F） | 理论层 0-4 → Stage 0/0-1/1-2/2-3/3+ 精确映射——「理论全覆盖实现分阶段」 |
| 五 Pass 分立全景 | Pass A 基础优化/B 流形/C 拓扑/D 量子 + r89 干涉坍缩——正交职责首次成型 |
| EBNF v5（分层版） | grammar L2 第四份骨架语料——Level 0-4 五层语法（拓扑/量子两新族） |
| 二义性预防第 8-10 例 | ⑧ entangle rule 枚举 vs identifier 尾位；⑨ superpose with phase 数字前缀；⑩ collapse to vs at 介词区分 |
| 量子登记态子空间（K-E） | QuantumEffectSpace 归位——EffectSpace Level 3 第四子空间（波粒二象性 + 纠缠族——Stage 3+） |
| 七层次结构（理论纵深轴） | 层 0-6 与统一五层框架（体系框架轴）非冲突互补；层 5 场论/层 6 终极统一 = 远见登记 |
| 九步推演链 | 直觉→统一→结构→自我纠正→动态→网络→对称性→交互→本质（波粒）——K-G 构建叙事档案 |
| 方法论七种 | 直觉映射/统一性追求/自我纠正/对称性思考/推广泛化/类比迁移/深层追问——档案非判据 |
| 核心与前沿可分离性 | 删除前沿探索部分核心理论仍完整——与 kerf 登记态分层结构同构（K-F 第二依据） |

---

### 5p. 第二十轮术语：能力模型内禀几何与计算广义相对论（v7.14 新增——r93 第二十轮吸收，同步自 stage0.md v7.9 附录 A——[17-原则 v7.10 原则 49](./17-principles.md) + [21-能力架构 §10](./21-capability-architecture.md) + stage0.md §9.21 载体）

| 术语 | 定义（锁定口径） |
|---|---|
| 三支柱统一体（CAP-A） | 线性类型（编译期安全）× 对象能力 OCap（运行时安全）× 能力效应融合（效应系统集成）——2026 能力模型前沿定位锚 |
| CapabilitySpace 归位 | 平行空间提议 → 理论坐标系保留 + 实施面核心七域能力域单源（24 §18——空间单源纪律沿袭） |
| 八维度正交分解（CAP-B） | 双模型各八维（定义/性质/能力/职责/控制/协同/变化/边界）精确数学定义——数学优先方法论 |
| HOW vs WHETHER 正交判据 | Effect.R2 投影选择 vs Capability.R2 门卫验证——唯一邻接对分立 = 正交成立 |
| 协同接口唯一接触面 | `Perform(e) requires Capability(e)`——函子 F: Effect→Capability；kerf E0006 = 层次 1 生产形态 |
| 内禀关系（CAP-C） | 效应 = 概率空间上的流（物质场）/ 能力 = 度规（时空几何）——`dE² = C_μν dE^μ dE^ν` 解释框架层 |
| 三层内禀方程 | 能力约束效应 `dE/dt = -Γ(C)·E` / 效应改变能力 `δC/δt = κ·T(E)` / 自洽耦合演化 |
| 14 能力操作完备集 | 基础三（控制/限制/携带）+ 高级十一（放大/变化/塌缩/聚合/分形/层级/嵌套/循环/衍生/干涉/湮灭） |
| CapabilityNature 三态 | Particle(CapabilityToken) / Wave(PermissionField) / Superposition——能力侧波粒对偶 |
| EBNF v6（能力操作版） | 第五份骨架——capability_decl 四成员 + 15+ 关键字脱糖备选（宏层糖→8 原语核心层） |
| 能力状态机六态 | Potential→Active→Transferred→Consumed/Expired/Revoked（类型系统强制转换） |
| Provenance（能力溯源） | original_granter + transfer_chain + timestamps——来源审计追踪（性质 P7） |
| 线性类型三方案 | A 借用检查器 / B 轻量标注 / C 运行时检查——Stage 0-1 C → Stage 2+ B → Stage 3+ 评估 A |
| 度规开销三策略 | 编译期度规解析 ~70% 零开销 / LRU 缓存 ~20% O(1) / 消除优化 ~10% 批量——平均 <5% |
| Lotka-Volterra 类比 | 耦合动力学收敛性——三失败模式（振荡/发散/混沌）+ 三缓解（强制收敛+fallback/阻尼 λ/安全锥 δ） |
| 四层次协同谱系 | 门控（编译期零开销）/ 调制（度规查询）/ 演化（on-effect 状态）/ 耦合（迭代演化）——每层超集渐进 |
| 环境五元组 | `⟨e, ρ, σ, κ, C⟩`——四元组加性扩展（C = 能力度规运行期通道；编译期退化四元组——通道分立） |
| COUPLED-EVOLUTION 规则 | 耦合演化操作语义——循环直到 `‖Cₙ₊₁-Cₙ‖ < ε` 收敛 + max_iterations 防发散 |
| 正逆效应语言表达 | `perform/offer`、`consume/rewind`——与 v7.7 逆向效应理论已登记形态零漂移 |
| 8/9 原语双层口径 | 语料理论基座 8 + E5 结构臂 2（let/assign）= kerf 现行 9——双层口径注记（r67 对账维持） |

---

### 5q. 第二十一轮术语：生命周期效应化与四模型协同（v7.15 新增——r94 第二十一轮吸收，同步自 stage0.md v8.0 附录 A——[17-原则 v7.11 原则 50](./17-principles.md) + [13-能力矩阵 §3.16](./13-capability-matrix.md) + [21-能力架构 §11](./21-capability-architecture.md) + stage0.md §9.22 载体）

| 术语 | 定义（锁定口径） |
|---|---|
| 生命周期效应化 | 生命周期 = 资源的时间效应——Acquire/Use/Release/Transfer 全效应化（零新独立机制——LC-A） |
| ResourceLifecycle 效应族 | 四操作资源生命周期效应——全 Perform 使用模式（8 原语第六轮验证零新原语） |
| ResourceHandle | 线性资源句柄——acquire 产物 use-once；资源粒子性载体（每资源唯一 handle） |
| with_resource | 作用域资源管理函数形态——Handle 作用域语义（Return/Error 双臂 RAII 释放）；EBNF v7 `with resource` 的脱糖目标 |
| Borrow 效应族 | immutable_borrow（可复制非线性共享）/ mutable_borrow（线性独占）/ return_borrow（归还消耗 token） |
| 借用 = 干涉分析 | Rust 借用检查器核心（immutable ∩ mutable ≠ ∅）= 效应流形干涉检测（v7.7 计算干涉的资源域实例） |
| 借用冲突三处置策略 | handler 外置——拒绝（编译错误）/ 等待（阻塞至释放）/ 排队（延迟不可变借用） |
| 效应消除迁移 | Koka 效应消除技术用于生命周期——编译期可确定则消除运行时检查（LC-B；E.22-131 锚） |
| LifecycleAnalysisPass | 五 Phase 算法——收集→构建流→规则三→干涉→消除优化（Stage 2+ 优化窗 pass 候选） |
| 生命周期规则三 | Acquire 前置 / Release 后无 Use（悬垂引用）/ 线性流 Acquire→Use+→Release |
| 消除三形 | FullElimination（简单作用域零开销）/ PartialElimination（静态借用）/ Optimized（动态可约化） |
| EBNF v7 | 第六份骨架语料——resource_decl/borrow_decl/with_resource_stmt/lifetime_annotation/lifetime_analysis（#15 门控维持） |
| lifetime_annotation 七约束 | acquire_before/release_after/exclusive/shared/no_overlap/must_overlap/linear_flow——可选标注 |
| 理论载体第八环 | 生命周期效应化——六环后第七次延展（三部曲→流形→逆向对偶→波粒二象性→能力内禀几何→生命周期效应化） |
| 原创贡献 13/14 | 生命周期=效应（资源管理统一）/ 借用=干涉分析（生命周期检查统一）——两项新登记 |
| 四模型协同 | 效应/能力/生命周期/类型六协同（协作面视角——生命周期非平级模型，双口径注记裁定） |
| 接口契约五形 | EffectRow 注解/Perform requires Capability/LifecycleEffect 模式/ResourceCap 门控/linear 标注——三元组（方向/内容/时机） |
| 效应分析单点性 | 五下游（生命周期/借用/能力/优化/类型）依赖效应分析——单点故障面风险 + 三缓解 |
| 保守-乐观双模式 | 开发保守（误报可能）/发布乐观（漏报可能）——乐观仅限性能优化域，安全域恒保守 fail-closed |
| 资源侧二象性 | 粒子性 = 资源离散实体 / 波动性 = 借用传播权限——效应/能力/资源三模型二象性族第三员 |

### 5r. 第二十二轮术语：流形统一分析与统一场论（v7.16 新增——r95 第二十二轮吸收，同步自 stage0.md v8.1 附录 A——[17-原则 v7.12 原则 51](./17-principles.md) + [13-能力矩阵 §3.17](./13-capability-matrix.md) + [15-架构分层 §5.4](./15-architecture-layers.md) + stage0.md §9.23 载体）

| 术语 | 语义 |
|---|---|
| 流形统一分析 | 分析的统一场论——所有分析（类型/借用/能力/优化/并发/调试/生命周期）= 同一效应流形上的投影/切片（MU-A——解释框架层第九环） |
| 分析的统一场论 | 传统分散分析系统（各自数据结构+算法+信息转换丢失）→ 单一数学对象多投影（Kildall 1973 框架级统一为先例弱锚——结构级统一为 kerf 特有叙事） |
| 统一流形分析中心 | Stage 3+ 愿景层架构档案——前端→中心[流形构建+分析引擎+六分析+流形变换]→后端（MU-E——§10 既有分层的分析中心聚焦视图） |
| 流形分析六投影 | 类型投影/干涉分析/拓扑分析/生命周期分析/曲率分析/同调分析——全部为既有理论投影零新分析类 |
| Pass = 流形变换函数 | 所有分析 Pass 操作同一流形对象——组合 = 函数复合 + 正确性独立验证 + 顺序灵活（MU-B） |
| Pass 数据结构单源纪律 | 任何分析 Pass 不得引入自有中间表示——三级单源体系：IR 单源[CoreExpr] + 分析单源[流形对象] + Pass 变换纪律 |
| 拓扑优化映射 | 连通分量→并行化 / H₀>1→独立任务 / H₁≠0→循环死锁风险 / 欧拉示性数→复杂度度量（MU-C Tier 1-2） |
| H₀/H₁ 同调语言 | 图算法的数学上溯表述（连通分量计数 = H₀ / 循环检测 = H₁ 离散化实例）——表述增益：不变量视角 + 代数拓扑工具链接入 |
| 曲率-非对易对应 | 曲率≠0→非对易不可重排 / =0→可对易可并行（Tier 3 叙事维持——真实判据由交换子/干涉形式化承载） |
| 联络-效应传播路径 | 图最短路径算法的叙事包装（Tier 2 叙事级——最优执行顺序） |
| 外微分-涡旋检测 | dω≠0→循环依赖涡旋（Tier 3——与 H₁ 同构信息） |
| Stokes-资源守恒验证 | 边界效应=内部变化的守恒律叙事类比（Tier 3——真实配平 = LifecycleAnalysisPass 规则三） |
| 增量分析局部性 | 流形局部欧几里得→局部变化局部影响——叙事层主张（真实保证依赖增量重分析算法设计） |
| 统一性收益/风险对偶 | 统一数据结构收益面 = 效应分析单点性风险面（同一架构属性两面——LC-F 与 MU-A 对偶登记） |
| 零丢失精确化 | 表示层真（共享底层零转换）/ 分析层投影必有损（切片即丢弃维度）——二层分辨表述 |
| 近似拓扑分析 | 允许近似的拓扑分析（性能域缓解策略——Stage 3 研究项，不违 fail-closed 安全底线） |
| 流形→ANF-SSA 桥接 | 流形分析产物向 kerf 自有 ANF-SSA 的单向投影（目标面转换 = Stage 2+ 可选件不入自举链——MU-D ④实况修正） |
| AI/ML 流形接口 | 流形 = 几何结构 = GNN 天然输入——Level 5 远见登记（MLGO 工业锚 + GNN-on-manifold 特有愿景无先例） |
| 流形调试 Level 4 视图 | 效应流形视图（连接关系/干涉模式/生命周期边界/能力度规）——双向调试策略愿景扩展（零新义务） |
| 理论载体第九环 | 分析统一场论——八环后第九次延展（三部曲→流形→逆向对偶→波粒二象性→能力内禀几何→生命周期效应化→分析统一） |
| 原创贡献 15 | 分析的统一场论——流形从效应理论载体升格为分析架构统一原理（本轮新登记） |

### 5s. 第二十三轮术语：类型观测与效应容器类型系统（v7.17 新增——r96 第二十三轮吸收，同步自 stage0.md v8.2 附录 A——[17-原则 v7.13 原则 52](./17-principles.md) + [13-能力矩阵 §3.18](./13-capability-matrix.md) + [24-空间分解 §21](./24-space-decomposition.md) + stage0.md §9.24 载体）

| 术语 | 释义（一句话 + 关键边界/裁定） |
|---|---|
| 效应容器类型系统 | 以效应流形为核心的类型理论总称——类型 = 流形上切片的静态描述（叙事层定位——可操作内核 = CoreType 代数 + 推断算法） |
| 横切静态验证层 | 类型系统在四大模型中的定位——「验证其他系统声明的事，不做任何事」（验证者非执行者——零运行时原语） |
| 静态/动态统一（观测模式二分） | 静态 = 节点快照观测 / 动态 = 区域轨迹观测——观测模式二分非二元对立（与渐进类型「何时检查」分立） |
| TypeNature 三形 | Static{node,shape}/Dynamic{region,trajectory,invariants}/Hybrid{static_dims,dynamic_dims,coupling} |
| 观测维度代数 | StaticDimension 四种（四模型各一观测维度）+ DynamicDimension 四种（四前沿 Stage 3+） |
| TypeObservation | 观测语义 trait{observe/uncertainty}——StaticObservation 快照 / DynamicObservation 轨迹 |
| TypeCoupling 三形 | FullyStatic/FullyDynamic/Progressive（渐进耦合——与渐进类型谱系同族近缘） |
| ProgressiveRefinement 三形 | EffectRefinement/TypeInstantiation/TrajectoryRefinement——粗→细的三种细化模式 |
| 流形约束求解 | 类型推断 = argmin Σ dist s.t. T' ⊆ Ω ∩ C（约束满足规约表述——HM[X] 约束域扩展叙事非新数学） |
| 六约束类 | ValueShape/Effect/Capability/Lifetime/Topology/Interference——流形求解器迭代传播分类 |
| InferenceStrategy 四形 | Static/Dynamic/Progressive/Hybrid——安全域恒 Static fail-closed |
| Linearity 四级谱系 | Linear 恰好一次/Affine 至多一次/Shared 多次/Unrestricted——Rust 二级泛化（linear = kerf 能力消耗位） |
| CoreType 十一构造子 | Primitive/Function{returns=EffectUnion}/Algebraic/Row/Effect/EffectUnion/Capability{metric,linearity}/Lifetime/Generic/Dependent |
| 接口计数纪律 | 模型间接口恰五——自反不占数 + 类型↔生命周期经效应中介（6 边取 5 直连） |
| 职责边界矩阵十二行 | 四模型职责终态（+「追踪效应签名」「观测流的形状」两类型核心行） |
| 渐进式理论应用 | Stage 0 用理论 5% + 架构预留 100% 接口（接口预留完整性同构） |
| EBNF v8 | 第七份类型语法骨架——unified_type 四形 + trait 四成员（历次最大关键字张力两域门控） |
| superposition 类型 | 效应叠加态类型语法（with probability + collapse when——Stage 3+ 量子域愿景档案） |
| 理论载体第十环 | 类型观测化——五线程族完备（效应七环+能力+生命周期+分析+类型） |
| 三口号叙事层 | 一切皆效应（机制）/一切皆分析投影（分析）/一切皆观测（观测）——三视角互补非验收宣称 |

### 5t. 第二十四轮术语：渐进式混合自举与语法迁移验证（v7.18 新增——r98 第二十四轮吸收，同步自 stage0.md v8.3 附录 A——[17-原则 v7.14 原则 53](./17-principles.md) + [07-自举策略 §4](./07-bootstrap-strategy.md) + [02-语法模型 §8.12](./02-syntax-model.md) + stage0.md §9.25 载体）

| 术语 | 释义 |
|---|---|
| 前端自举 | 编译器前端（Reader/Expander/Compiler/CLI/分析/优化）用目标语言重写、VM/Runtime 保留宿主语言——D1 路径二分法端点一 |
| 完全自举 | VM/Runtime/基础库亦用目标语言重写、仅存极小构建种子——D1 路径二分法端点二（kerf 宪制排除项） |
| 最大化前端自举（第三形态） | kerf 谱系落位：前端三段 + HM + 构建编排全自举 + VM 永久 Rust 基座——超出前端自举、排除完全自举的自举面最大化点 |
| 构建种子 | 引导首次编译的最小外部依赖（kerf 形态 = Rust 种子编译器 + oracle 链——可审计信任根） |
| 全源自举 | Guix/Mes 式 357 字节 hex0 起步的全链可审计自举（E.25-142）——kerf 远期理论对照非计划项 |
| trusting trust 对抗 | Thompson 1984 编译器后门自复制论证（E.25-141）——供应链安全理论上限；kerf 承接 = 缩短信任链三机制 |
| 同结果测试 | 新旧 Reader 对同一逻辑产出全等 CoreExpr/字节码的验证纪律（原则 31 进程面硬断言） |
| SyntaxTransitionValidator | 双 Reader 等价性验证器设计（EquivalenceReport/SemanticDrift 四元组诊断——切换窗登记态） |
| 语法映射表 | S-expr ↔ 目标语法显式映射规则集（六映射 + SemanticProof 成员）——皮肤字典单源登记位 |
| 三层验证 | 单元级（逐构造）/程序级（整程序）/自举级（编译器自身）——迁移验证协议三层 |
| 三阶段构建 | A 编译 B、B 编译 C、验证 B==C 字节级——门 B fixpoint 的传递性扩展 |
| 语义漂移 | 新语法产生不同 CoreExpr 的迁移核心风险（Block 插入例）——parity 逐字节断言 + SemanticProof 双防护 |
| 双 Reader 并存期 | 切换窗期两语法输入并存（CLI 双入口设计候选）——旧 Reader 删除以三阶段 fixpoint 为前置 |
| 渐进式混合自举 | D1 三阶段策略：Phase 1 前端自举（✅ 已达成并超越）→ Phase 2 本地码后端（既有规划）→ Phase 3 完全自举（kerf 宪制排除） |
| 八语言先例表 | Rust/Zig/Go/Java/CPython/Koka/OCaml/Chez 自举策略对照——方向性参照（四行口径偏松注记） |
| 供应链安全承接 | 完全自举独占收益的替代机制：可审计种子 + parity oracle 链 + fixpoint 确定性——缩短而非消除信任链 |
| 切换窗六步前置清单 | r70 §5.2：信号命中→证据回填→开窗评审→L3 升级→五步流程→B 类替换面识别 |
| 工程进程线程 | next17 开面的吸收线程定位（自举拓扑与迁移验证）——区别于五线程族的工程演进面（不计理论环） |
| parity oracle 链 | 种子 Rust 实现退役后的等价性 oracle 保留纪律（reader/expander/compiler/HM 四段既有形态） |

### 5u. 第二十五轮术语：EBNF v9 整合定稿族（v7.19 新增——r104 第二十五轮整合定稿，同步自 stage0.md v8.4 附录 A——[17-原则 v7.15 原则 54](./17-principles.md) + [02-语法模型 §8.13](./02-syntax-model.md) + [22-命名空间 §27](./22-namespace-design.md) + [20-表面规范 §14](./20-surface-conventions.md) + stage0.md §9.26 载体）

| 术语 | 定义 |
|------|------|
| EBNF v9（整合定稿版） | 八份骨架语料（v1-v8）+ Rust 最小集补全统一收敛的单一完整目标语言文法定义（02 §8.13 权威定稿位——词法 + Level 0 定稿域 + Level 1-4 登记域） |
| EBNF 定稿子窗 | 用户指令直接开窗的定稿义务履行窗（M1 指令开窗第十二例——纯文档域；切换窗本体维持未开窗：定稿 ≠ Reader 实施） |
| 九源语料地图 | v9 输入全景：§9.16.4 骨架 + next11-v1 + next12 前段-v2/后段-v3/追加段-v4 + next13-v5 + next14-v6 + next15-v7 + next16 Doc1/Doc3-v8 |
| 六整合原则 | 单源收敛/分层门控/关键字经济/内核不变/容器模型优先/最小集补全 |
| 十二整合裁定（C1-C12） | 跨版本冲突消解档案（try-catch 剔除/容器式胜出/while-for 剔除/async 剔除/move 语境词/interference 双登记/Never 取 v8/裸效应归并/调用并 postfix/type_modifier 降级/union 降级/nil→()） |
| Rust 最小集补全 | 仅补结构性缺位的借鉴：词法完备/路径 `::`/泛型实例化消歧/优先级结合律表/where 子句/mut-move-as-impl 语境修饰词——不引入 unsafe/trait 独占域/生命周期标注三主线 |
| 优先级层级文法 | 运算符优先级的机器面：expr 产消按十四级强度分层重写——消除直接左递归 |
| 十四级优先级表 | 后缀（1）→as（2）→一元（3）→乘除模（4）→加减（5）→位移（6）→位与（7）→位异或（8）→位或（9）→比较不链式（10）→逻辑与（11）→逻辑或（12）→区间（13）→管道（14） |
| 关键字分级终态 | 22 定稿词面 = 15 全域 + 4 语境修饰词 + 3 handler 位形词；净增 7 词全为位形限定 |
| 语境修饰词 | 位形限定不入全域排他面的目标域词类（Rust contextual keyword 策略）——位形外可作标识符 |
| 内建效应容器名 | Return/Error/Async/State/Never/Timeout 六词——effect_name 枚举首成员（非关键字） |
| 二义性二十二例 | v9 完备消歧登记（既有 17 + 定稿新增 5：18-22）——四策略覆盖 |
| 宏层脱糖路径表 | 张力族 ~47 候选的替代通道全景（宏族/pragma/函数糖/效应糖） |
| 容器模型唯一签名通道 | `-> effect_union` 为函数签名效应标注唯一形态（两被否决形态入演进档案） |
| 皮肤字典定稿域扩充 | 四条新映射（`/`↔`::`、nil↔()、while↔while!、try*↔try!） |
| 8 原语不变性第九轮验证 | v9 全量产消经内核映射抵达核心形式——零新增原语零通道增量 |
| 双 Reader 规范基线 | v9 Level 0 对切换窗五步流程第③步的解析规范输入地位 |

### 5v. 第二十六轮术语：信息效应化族（v7.20——r111 吸收，同步自 stage0.md v8.5 附录 A）

| 术语 | 定义 |
|------|------|
| 信息效应化 | 信息 = 效应流的状态投影：五类信息全部为流形观测投影——非独立于计算流的外部标注（INFO-A 第八支柱） |
| 状态投影 | 区别于类型「形状观测」的信息观测维度——异常/风险/建议/轨迹/性能特征（观测双子第二面） |
| 观测双子 | 类型[形状观测] + 信息[状态观测]互补对——r96 单子 → r111 双子闭合（理论载体第十一环） |
| 五类信息效应 | Error[异常坍缩]/Warning[风险投影]/Hint[建议投影]/Debug[轨迹记录]/Performance[性能特征] |
| 统一五机制 | 产生 perform/处理 handle/传播 EffectRow/组合 handler/观测分析查询——零新增原语 |
| 分治五策略 | Error[停/复/集]/Warning[报+续]/Hint[可选]/Debug[存轨迹]/Performance[分析]——策略全部外置 handler |
| 渐进观测分级 | observe at errors→warnings→hints→debug→full——原则 43 观测面投影（LSP 四级同构） |
| 信息效应语法族 | next18.md 两段 EBNF = grammar L2 第九源语料——Level 1-4 登记态 + 三分域归位 |
| 信息三分域 | 用户侧效应[Level 2]/观测指令[Level 4 工具链面]/信息管道[库面]（INFO-C） |
| InfoEffectSpace | EffectSpace Level 2 登记态子空间第七例——语言级信息效应族归属（空间单源第九轮） |
| 「信息」双层口径 | 语言级信息效应归 EffectSpace / 编译器内部诊断留 InfrastructureSpace（INFO-D） |
| 编译器信息流管线 | 管线信息流观测投影描述 = MU-E 信息面视图——架构叙事层登记非机制义务（INFO-E） |
| F13 正交裁定维持 | 编译期诊断恒值通道[Result/Diagnostic 终止性控制流]非 perform/handle 效应——不可漂移 |
| ErrorPolicy 三策略 | FailFast/Collect/BestEffort——配置面既有形态命名完备化（HM 多错误收集 = Collect r75） |
| 8 原语不变性第十轮验证 | 信息效应五类全部 = Perform/Handle 使用模式——零新增原语零通道增量零 VM 变更 |
| 理论载体第十一环 | 六线程族{效应七环+能力+生命周期+分析+类型+信息}——观测双子闭合后终态 |
| 三视角三口号终态 | 机制一切皆效应/分析一切皆投影/观测一切皆信息——叙事层终态（禁作实现宣称） |
| 原创贡献 18/19 | #18 信息 = 效应流的状态投影；#19 编译器信息流 = 效应管线（愿景 Stage 2+） |
| LSP 投影渲染层 | 信息效应 → LSP 通知 = Diagnostic 字段映射——工具链层单向派生非语言成员 |
| 「不会 100%」清单 | 性能实测/渲染 UX/LSP 集成/生态四项不阻塞收敛——Stage 2+/3+ 工程窗登记 |

### 5w. 第二十七轮术语：流特性理论与流本体论族（v7.21——r113 吸收，同步自 stage0.md v8.6 附录 A——[17-原则 v7.17 原则 56](./17-principles.md) + [06-操作语义 §14](./06-operational-semantics.md) + [13-能力矩阵 §3.20](./13-capability-matrix.md) + [21-能力架构 §11.5](./21-capability-architecture.md) + [24-空间分解 §23](./24-space-decomposition.md) + stage0.md §9.28 载体）

| 术语 | 定义 |
|------|------|
| 流特性理论 | 流的五层特性统一描述：波动性[宏观]/粒子性[微观]/中间态[弦视角]/间隙性[观测降维]/时间性[贯穿]——五层 = 同一效应流的五种观测模式（FLW-A） |
| 流本体论 | 流 = 理论体系的本体对象——六线程族全部谓词的共同主语；解释框架层第十二环（理论环数 11→12——本体层开面非新线程非新支柱） |
| 完备观测谱 | 本体对象的五观测尺度序列：宏观波→微观粒子→中间组合→投影残差→时序演化（观测角度调节 = 获取不同层次表现） |
| 固定（Fix） | 观测维度阶一阶形态：Fix(v,d) 单维度锁定为具体实例——其余维度叠加保持开放（Handle 语义的观测论重述） |
| 确定（Det） | 观测维度阶全阶形态：Det(v) 全维度坍缩至单点——零可能性残留（理论上限——kerf 无此操作语义） |
| 固定而非确定 | 一次 Handle 观测固定一个效应维度、其余效应维度仍开放——与 resume∈{0,1} 合围兼容（退相干式表述增益——E.28-155 锚） |
| 维度投影算子 | DimensionalProjection{Fix/Det} 形式化结构——区分「投影到子空间保留叠加」与「投影到单点消除全部可能性」 |
| 多维可能性 | EffectResource ∈ N 维可能性空间（超越二元 qubit）——正交分解原则[原则 2]理论层重述：8 原语轴 = 维度分解基 |
| 随机种子 = 自由度 | Seed(t)∈ℝᴺ——该维度该时刻的随机能力；随效应流共同演进（Seed(t+1)=Evolve(Seed(t),Flow(t))） |
| DimensionalSeed | 维度种子结构：{dimension × freedom × randomness × evolution_coupling}——随机能力的维度化登记 |
| Freedom 四级谱系 | Zero[完全确定]/Finite[有限集合随机]/Infinite[连续空间随机]/Constrained[能力约束后剩余]——与 Linearity 四级同形的分级修辞 |
| 自由度-约束对偶 | 能力 = 约束减少自由度 ℝᴺ→ℝᴹ ↔ 随机种子 = 提供自由度 ∅→ℝᴺ——CAP-C 对偶面完备化（第三不确定性形态） |
| 不确定性第三形态 | 自由度-约束对偶形态：数学实质 = 计数恒等式 TotalFreedom = Constrained + Removed（非严格不等式——「≥ 常数」为叙事层） |
| 中间态组合模式 | 粒子最小集合按规律组合（随机性被固定）表现介于波粒之间的特性——函数 = 效应的固定组合模式（水类比） |
| 间隙性 | 观测降维导致的信息丢失/不完整性——投影算子 π: Ω_high→Ω_low + 熵不等式（全息原理信息论面共享骨架——E.28-158 锚） |
| 信息间隙 | InformationGap：高维存在低维缺失的维度 + 丢失信息量 + 不可完全恢复性（多次观测永不能完全恢复） |
| 坍缩事件 | CollapseEvent{time/collapsed_dimension/fixed_value/remaining_dimensions/pre_collapse_state}——固定而非确定的数学基础 |
| 时间性四命题 | 流动=时间持续坍缩 / 时刻=概率快照 / 无观测=混沌 / 种子随流演进——操作语义的物理层重述（FLW-E） |
| 8 原语不变性第十一轮验证 | 五层特性全部由既有 8 原语 + 语义/观测层承载——零新原语零通道零 VM 零语法增量（历次最轻量轮族） |
| 四视角全景 | 本体[流]/机制[效应]/分析[投影]/观测[信息]——三视角三口号的共同主语展开（叙事层登记态） |


### 5x. 第二十八轮术语：统一流分析与描述论族（v7.22——r115 吸收，同步自 stage0.md v8.7 附录 A——[17-原则 v7.18 原则 57](./17-principles.md) + [19-参考文献 §29](./19-references.md) + [02-语法模型 §8.13.2a](./02-syntax-model.md) + [06-操作语义 §14](./06-operational-semantics.md) + [13-能力矩阵 §3.21](./13-capability-matrix.md) + [05-运行时 §14](./05-runtime.md) + stage0.md §9.29 载体）

| 术语 | 定义 |
|------|------|
| 统一流分析 | 借用检查 = 流干涉分析投影的分析线程工程统一面——UnifiedFlowAnalysisPass 四相位管线（UFA-A） |
| π_time 投影算子 | Lifetime(T) = π_time(EffectFlow(T))——生命周期 = 效应流的时间维度投影（观测投影家族第三实例） |
| 观测投影家族 | 三实例完备：类型 π_shape（形状投影）/ 信息 π_state（状态投影）/ 生命周期 π_time（时间投影） |
| 默认生命周期三规则 | 值类型 = 单点切片 / 引用类型 = 借用时间段 / 资源类型 = Acquire→Use*→Release 完整流（推导优先路径） |
| CustomLifetime 效应 | 用户自定义生命周期效应接口：custom_acquire/custom_use/custom_release/custom_borrow 四操作（登记态） |
| 流干涉三型 | Destructive（Imm×Mut 时间重叠）/ Exclusive（Mut×Mut）/ Dangling（Use 后于 Release）——借用检查语义 |
| FlowSegment | 流段结构：{resource, kind, start, end}——借用的效应流载体（NLL 段结束推导） |
| NLL 段结束推导 | 借用段在最后一次使用后结束（FLOW-SEGMENT-END 规则——Polonius 先例 E.29-160） |
| 部分借用 | 字段级流分析：f₁≠f₂ 无干涉；同字段 Imm×Mut 时间重叠 → 干涉（PARTIAL-BORROW 规则族） |
| 并发流干涉 | 跨线程 MayOverlap(A,B) → 潜在并发干涉（CONCURRENT-FLOW-INTERFERENCE——Stage 3+ 愿景） |
| lifetime_override | 生命周期重写声明：phase/constraint/interference_rule 三成员（默认推导优先 + 显式重写逃生舱） |
| lifetime_interference_rule | 用户可配置干涉处置：borrow_pair => allow/deny/warn/require sequencing 四动作 |
| flow_analysis_directive | 流分析深度指令：none/basic/intermediate/full/quantum 五级（渐进披露原则 43 分析面实例） |
| 描述论 | 本体论立场：效应/能力/类型/生命周期/信息不是实体而是描述方式——描述同一不可直接把握的计算实在（UFA-C） |
| 五描述修正表 | 效应=计算描述（行为维度）/ 能力=约束描述（约束+自由）/ 类型=几何观测描述（形状）/ 生命周期=时间投射描述（时间）/ 信息=观测描述（观测） |
| 机制层豁免 | 表述纪律边界：8 原语操作语义为机制事实非描述——「描述」形仅适用于理论叙事层统一关系表 |
| OSR | Ontic Structural Realism——理论实体的全部本性与结构和关系等同（描述论的科学哲学平行形态——E.29-163） |
| 编译器 = 描述生成器 | CompilerAsDescriptionGenerator：编译 = 生成描述 + 流分析精化 + 基于描述决策（MU-E 描述论重述登记态） |
| 哥德尔同构 | 第一不完备↔间隙性[∀D ∃T: T∉D] / 第二不完备↔自举信任根[信任链缩短非消除]（UFA-D） |
| 三重不完备统一 | 逻辑不完备（Gödel）+ 计算不完备（Turing 停机）+ 观测不完备（描述间隙）——叙事层统一 |
| 8 原语不变性第十二轮验证 | 统一流分析全部由既有 8 原语 + 既有分析框架承载——零新原语零通道零 VM（第十源语法登记态） |
| 自举信任根 | 第二不完备定理的工程体现：可审计种子 + parity oracle 链 + fixpoint 确定性——缩短非消除信任链 |

### 5y. 第二十九轮术语：递归处理与脚手架拆除族（v7.23——r117 吸收，同步自 stage0.md v8.8 附录 A——[17-原则 v7.19 原则 58](./17-principles.md) + [19-参考文献 §30](./19-references.md) + [04-字节码 VM §3.1](./04-bytecode-vm.md) + [07-自举策略 §3.2.2](./07-bootstrap-strategy.md) + [06-操作语义 §16](./06-operational-semantics.md) + [13-能力矩阵 §3.22](./13-capability-matrix.md) + [12-路线图 §2.19](./12-roadmap.md) + stage0.md §9.30 载体）

| 术语 | 定义 |
|------|------|
| 同形树递归 | Reader/Expander/Compiler/eval 对同一形状语法树的递归遍历——栈帧同量级，由单一深度帽统一覆盖（REC-A） |
| 四层实况谱系 | Reader 递归下降+256 帽 / HM 迭代+512 预算 / VM 迭代主循环堆帧栈 / eval 互递归前置覆盖——递归处理实况单源（原则 58） |
| MAX_NESTING_DEPTH | Reader 防御性嵌套深度帽 256——FS-1 实测锚（2MiB 测试线程栈 ~600 层溢出）取 >8× 裕量 + 结构化错误 fail-closed |
| 生成预算（MAX_GEN_DEPTH） | HM 推断生成时 512 深度预算——A6 语义不变：超预算子树产结构化诊断非崩溃 |
| 帧数帽 | VM 帧栈的显式上限守卫——失控递归的运行时防护（TD-023 堆根域） |
| 显式栈迭代解析 | 语料方案 1——解析栈由调用栈移至堆分配显式栈，任意深度不受栈限（VM 主循环实况形态） |
| 流式渐进解析 | 语料方案 2——事件流产出不建全树，内存 O(深度)——登记态备选（matklad 事件流先例 E.30-166） |
| 深度限制与渐进降级 | 语料方案 3——OverflowPolicy 四形 Error/Lazy/Compress/HeapEscape；实况恒 Error 形 fail-closed |
| 效应流天然解决 | 语料方案 4——递归 = 效应流嵌套的叙事层表述；「perform 不创建栈帧」= 实现策略面（OCaml 5 先例 E.30-165） |
| 递归的流形统一 | 递归 = 效应流分支/嵌套 / 深度 = 流形嵌套层级 / 溢出 = 流分析边界条件——解释框架层叙事（K-F 沿袭） |
| 语法脚手架拆除面 | S-expr 语料形态（.krf 四件 + S-expr Reader）的拆除边界 = 生产链 + 语料面（E5 收口）——种子链保留为宪制裁定 |
| Stx 必需承载 | Stx 语法树 = 宏展开相位的必需中间承载非「可消除冗余」——拆除面是 S-expr 语料形态非 Stx 层本身 |

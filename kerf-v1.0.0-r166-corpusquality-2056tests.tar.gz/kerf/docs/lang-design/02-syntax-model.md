# 语法模型：类型化 Token 流、Span 与结构化诊断

> **Author**: kerf-doc-agent
> **Date**: 2026-11-26（**v7.31——r163 / 234-c 索引访问窗：postfix_op `"[" expr "]"` 实施状态注记**[`coll[idx]` postfix 位索引面开面——第十七皮肤映射 as-if-written `(vector-ref coll idx)`[Reader 直接合成与调用形产物同构的 Stx——皮肤换、骨架不变，原则 31：零脱糖零新原语零 CoreExpr/IR/操作码，expander/compiler/HM/VM 全链零触及，8 原语不变性第四十五轮]；r138 D6 位置纪律 superseded——双括号面俱在域{primary 位 `[a, b, c]` 字面量 + postfix 位 `v[i]` 索引}；恰一索引表达式{空 `v[]` / 多参 `v[1, 2]` fail-closed E0001}；嵌套链式 `v[i][j]` = postfix 尾循环自然组合；D3 脱糖目标免 import 纪律{vector-ref 入 N1——第 42 名}；不可变维持{`v[i] = x` assign 位域外——r138 D1}；设计单源 index-access-design.md v1.0 D1-D10]**）；2026-11-25（**v7.30——r162 / 233-c TD-037 相等域窗：comparison 产生式语义注记增补**[`comp_op ::= "==" | "!=" | "<" | ">" | "<=" | ">="` 文法零变更——语义注记：`==`/`!=` 脱糖目标换至跨域结构终名 `eq`（`a == b` → `(eq a b)` / `a != b` → `(not (eq a b))`——值域全域化：Pair/Vector 结构相等 + procedural 同一性 + 混合域 false）；ordering 族（`< > <= >=`）维持 num/str 全序域；设计单源 equality-domain-design.md v1.0 D1-D10]**）；2026-11-25（**v7.29——r161 / 231-c 常量声明窗：§8.13.1a toplevel_const 产生式增补**[`"const" identifier [ ":" type ] "=" expr ";"` → Stx `(define name e')`——第十六皮肤映射[as-if-written：toplevel_let 孪生——皮肤换、骨架不变，原则 31；零脱糖零新原语零 CoreExpr/IR/操作码]；最小只读语义闭环[项位 assign 拒收 E0001 读面族——Reader 顺序 const 集{重绑移除最新绑定胜出 + 模块体保存/清空/恢复——种子侧经 assign 面 SetGlobal 自举通道}]；const mut 矛盾拒收 + 单绑定封顶 + 块位 domain-out{mut 块位臂同构}；绑定性质轴收口[可变 let+assign 面 / 只读 const 面双轴俱备——mut no-op 轴的只读方向补全]；种子源 IR 标签 `const`→`constant` 重命名 8 处[新关键字与 compiler.ktf quote(const) 冲突消解——桥外标签结构性忽略零桥代码变更]；ktf_const_decl_tests 32 case 门[8 正 + 24 负 1:3——四新诊断双 Reader 字节级 parity + E0004 平表不变量族 + D4 诚实边界锚]；1916 基线；设计单源 const-declaration-design.md v1.0/v1.1]**）；2026-11-25（**v7.28——r160 / 230-c TD-036 元组表达式形窗：§8.13.1a tuple_expr 产生式增补**[`"(" expr "," expr ")"` → Stx `(cons e₁ e₂)`——第十五皮肤映射[as-if-written：与 cons(a, b) 调用形产物同构——皮肤换、骨架不变，原则 31；零脱糖零新原语零 CoreExpr/IR/操作码；构造⟺解构对称：模式位 (p, q) 二元封顶的 r121 裁定镜像到表达式位（D2 对称纪律）；单元素 (a) = 纯分组维持 + `()` = Unit 维持（词法歧义句法位置裁决既有纪律）；尾逗号 fail-closed（r138 vector 同律）；合成 cons 符号 Span = `(` Token 本位（r158 合成 define 先例）；设计单源 tuple-expression-design.md v1.0]**）；2026-11-24（**v7.27——r159 / 229-c 运算符面完备性清偿窗：term 级 `%` 实施状态注记**[EBNF Level 0 定稿的 `n % 2` 项级中缀主名注册链闭合——`(% a b)` Stx 双 Reader 既有产物 × N1 内建/双侧 HM 签名表/QBE ANF 映射五点注册 r159 新增；`mod` 维持为 S-expr 旧时代调用形别名（D1 主名/别名裁定——种子域零扰动）；设计单源 operator-surface-parity-design.md v1.0{§1 同类路径全量审计 15 行表——逻辑/比较/算术俱既有现代中缀形注册链完整，`%` 唯一断链 r159 清偿；位运算/range/cast/索引族俱 ○ 登记态维持}]**）；2026-11-23（**v7.26——r158 / 228-c 顶层 let 现代化窗：§8.13.1a toplevel_let 产生式增补[`let name [: T] = e;` → `(define name e')`——S-expr 旧时代 define(NAME, e) 调用形退役 + 项位拒收现代化诊断 + 单绑定封顶] + §8.12 D2 映射表 define 行分裂[函数声明 fn→(define (f x) body) 维持 + 顶层值绑定 let→(define name value) 新增]；设计单源 toplevel-let-design.md v1.0**）；2026-11-22（**v7.25——r157 / 227-b3 设计文档残留清偿窗：EBNF Level 0 审查{fn_decl 返回签名可选修正——实现-文档漂移 E-1[R4] + closure_expr 逐位一致实证 E-3 + move 宽松面注记 E-2} + §6 已删锚历史注记（设计单源 design-docs-modernization-plan.md v1.0 §3——审计表 ≥30 行回填）**）；2026-11-16（**v7.24——r147 extern 符号空间别名窗产生式增补（§8.13.1a extern_decl 可选声明位别名段 `[ "as" ident ]`——双名分离 D3[underlying = 扁平 FFI 空间键 / local = 源级绑定名] + 替换语义 D4 + 自别名拒收 D5 + 反遮蔽扩展 D6；设计单源 extern-alias-design.md v1.0）**）；2026-11-14（**v7.23——r143 handle 表达式位窗产生式注记（§8.13.1a handle_stmt primary 位注记——语句位与表达式位共享一形[r110 表达式位 if / r121 match 值形同构分派第三例]；CLI 双入口双面表达力 parity 缺口第五连清偿；设计单源 handle-expr-position-design.md v1.0）**）；2026-11-10（**v7.22——r138 TD-002 向量值类型窗产生式增补（§8.13.1a vector_lit 产生式——第十四皮肤映射[逗号省略] + 双侧脱糖 D2 + 值模型 D3 + 渲染 D8；设计单源 vector-value-design.md v1.0]）**）；2026-11-09（**v7.21——r137 TD-026 行① FFI extern 声明族窗产生式增补（§8.13.1a extern_decl 产生式族——`extern name(kinds) -> kind;` ↔ `(extern name (kinds) kind)` 第十三皮肤映射 + Keyword 27 → 28 名[extern 入共享保留域——E0020 面扩展] + kind 三词表 D1[int/str/ptr = ExternKind 消费子集语言面同构]；设计单源 ffi-language-surface-design.md v1.0]）**）；2026-11-09（**v7.20——r136 TD-033 组安装语义窗映射翻转（§8.13.1a handle_stmt 多臂注释更新——嵌套脱糖 → handle-group 组安装[设计单源 handle-multi-arm-design.md v1.1 §8 D11-D19]；Keyword 26 → 27 名[handle-group 入共享保留域——E0020 面扩展]；皮肤字典第十二映射族行翻转 = 20 §14 v1.27 同轮）**）；2026-11-08（**v7.19——r134 use 域外二项清偿窗增补（§8.13.1a use_tree `as` 成员重命名增补形 + r131 D3/D6 域外注记翻转 + 设计单源 member-rename-design.md v1.0）**）；2026-11-07（**v7.18——r133 嵌套块内 resume 窗作用域注记更新（§8.13.1a resume_stmt 嵌套穿线 + r133 域外注记翻转 + 设计单源 nested-resume-design.md v1.0 + 同窗 VM 续体恢复边界截断清偿注记）**）；2026-11-06（**v7.17——r132 handle 多臂 / halt / pass 窗产生式增补（§8.13.1a handle 多臂/halt/pass 族 + 设计单源 handle-multi-arm-design.md v1.0 + 同窗 fvo P1 缺陷清偿注记）**）；2026-11-05（**v7.16——r131 use 声明 / `::` 导入树窗产生式增补（§8.13.1a use_decl 族 + 域外注记翻转 + 设计单源 use-declaration-design.md v1.0）**）；2026-11-04（**v7.15——r130 import as 别名窗产生式增补（§8.13.1a import_item 别名位 + 域外注记翻转 + 名位 Span 潜伏错位同窗修复注记）**）；2026-11-03（**v7.14——r129 宏面语料窗宏定义面产生式增补（§8.13.1a 增补行 + check 恢复模式宏注册 P1 缺陷清偿注记）**）；2026-11-03（**v7.13——r128 语料族深度化窗 handler 块体 resume 语句产生式增补（§8.13.1a 增补行）**）；2026-11-03（**v7.12——r125 CLI 双入口窗 require 声明产生式增补（§8.13.1a 增补行）**）；2026-11-02（**v7.11——r121 match 实施批 M-1 增补（模式匹配文法）**：§8.13.1a 增补 match 产生式族[设计单源 match-design.md v1.0 §2 → 语言面规范锚 → Reader 解析域开放；r121 消歧裁定三条：or 标记中间形 / 括号内至多二元 / 深度帽 8；种子侧 target.rs 已实施 + match_m1_reader_tests 10 case 门；target_reader.krf 镜像 = M-4 批]）；2026-10-24（**v7.8——r110 切换窗步③ 第二批增补（多绑定 let 与表达式位 if）**：§8.13.1a 增补二产生式 + 皮肤字典新三条[20 §14 同轮]）；2026-10-23（**v7.7——r109 切换窗步③ 首批增补（模块生产面文法）**：§8.13.1a 增补位 + 皮肤字典命名映射条目[20 §14 同轮]）；2026-10-20（**v7.6——r104 第二十五轮整合定稿（EBNF 定稿子窗）**：§8.13 EBNF v9 整合定稿位——同步自 stage0.md v8.4 §9.26）；2026-10-19（**v7.5——r98 第二十四轮吸收（next17.md Document 2）**：新增 §8.12 语法迁移验证与映射表登记[Stage 2b 切换窗前置设计登记——SyntaxMappingTable 皮肤字典单源/SyntaxTransitionValidator parity 结构化完备/语义安全网分层/三阶段 fixpoint 扩展]——同步自 stage0.md v8.3 §9.25.4；**含 R4 顺修一处**：v7.4/r96 的 Version 头行漏更本轮补齐——Date 行 r93 后停更为 lang-design 全员约定[12/17/18/19/00 同态]，此处 v7.4 Date 条目回补为历史完备性超额项非顺修）；2026-10-18（**v7.4——r96 第二十三轮吸收（next16.md）**：§8.11 EBNF v8 类型语法族[unified_type 四形 + manifold_constraints + trait 四成员 + 二义性预防第 15-17 例 + 历次最大关键字张力两域分层门控]——同步自 stage0.md v8.2 §9.24.5）；2026-10-10（**v7.1——r91 第十九轮吸收（next13.md）**：§8.8 EBNF v5 分层版[Level 0-4 五层语法 + 拓扑/量子两新语法族 + 二义性预防第 8-10 例 + K-D 脱糖备选优先级提高]——同步自 stage0.md v7.8 §9.20.7）；2026-10-10（**v7.0——r89 第十八轮吸收（next12.md 追加段）**：§8.7 EBNF v4 正逆干涉版[逆向/干涉/概率三语法族 + 关键字张力双判据裁定 + 脱糖备选路径 + 二义性预防第 4-7 例]——同步自 stage0.md v7.7 §9.19.7）；2026-10-10（**v6.9——r88 第十七轮吸收（next12.md）**：§8.6 EBNF v3 效应容器模型与流形操作语法[15 关键字演进 + connect/lift/project/pass + 二义性预防三例]——同步自 stage0.md v7.6 §9.18.5）；2026-10-09（**v6.8——r84 第十六轮吸收（next11.md）**：§8.5 类型与效应标注语法 + 极简关键字体系[容器式签名 `Return(T) | E` 终态草案 + 方案 A 被否决演进链 + 17 关键字六组 + 十二项传统关键字效应替代表 + 宏层熟悉语法 + grammar L2 骨架语料对照]——同步自 stage0.md v7.5 §9.17）；2026-10-08（**v6.7——r83 第十五轮增量维度收编**：§8.4 语法定义形式与语法文件体系（EBNF 体系组织模型）——审查发现 G1-G3 缺漏三证据 + 五体系对照三裁定[W3C EBNF 记法/定义解析分离/生成器不入自举链] + Stage 0 语法 EBNF 形式化[既有事实描述 R4——与 symbol.rs 25 关键字逐名对账] + grammar 四层组织模型[L2 规范层落位本节] + 前沿对照六锚——同步自 stage0.md v7.4 §9.16；[17 原则 44](./17-principles.md) 同轮注册）；2026-10-01（**v6.6——r81 第十四轮吸收（next10.md）**：§8.3 目标语言设计蓝图登记——表面语法面[语法成员全糖化清单 + 渐进披露四层 + try/catch 标准库宏定位 + 类型系统成员 Stage 2+ 登记态]——同步自 stage0.md v7.3 §9.14；[17 原则 43](./17-principles.md) 同轮注册）；2026-09-17（**v6.5——r57 第九轮吸收**：§8.2 S 表达式的架构位置精确化——语法级 IR 定位 + Racket SyntaxObject 四元组 + 选择 A 脚手架 vs B 永久中间层六维度裁定；同步自 stage0.md §7.3.6）；2026-09-12（v6.1：K2/r36 大阶段末深审回写——§14.8 B2-3：Keyword 22 → 25 变体（r25 增 perform/handle/resume 三关键字）/ 叶级 45 → 48 种，实锚 symbol.rs:24-54；§8.1 B1-1：两语法同核验证改判（重规划至批次 L/M——20 §5 模块树，12 §2.10 表面现代化窗口承载）；2026-09-10（v6.0：新增 §8 表面语法决策与表面/内部语法分离——next3.md 第六/七轮吸收；v5.5：next2 讨论 S 表达式量化背书指针））；2026-11-26（**r164 / 235 list 域自建迁移窗注记**：零语法变更轮——五定参内建 length/reverse/nth/drop/last-pair 从 Rust 种子注册面迁入自建 kerf 语料 bootstrap/list.ktf{forms 级注入——preamble 先例族；实现源迁移非皮肤窗非机制窗}；v1.1 性能边界裁定 member/assoc 泊回{TD-039 触发式}；详见 list-self-built-design.md v1.1）
> **Version**: v7.32（**r165 / 236-c——TD-038 变参 rest 参数窗——param/fn_decl 产生式 rest 形增补**：`param := name ':' type | '...' name ':' type`{rest 参数终端位唯一——至多一枚且居末} + `fn_decl := "fn" [generics] '(' param-list ')' ['->' effect_union] block`{闭包面 `||(a: T, ...rest: T)` 共用 parse_typed_params 同权}——`...` 词法 = r129 第九皮肤映射既有 ident 载荷{零 lexer 变更零新 Token 变体}；Stx 签名沿标记符{`(define (f a ... rest) body)`——无标记 = 定参全语料向后兼容}；**机制窗注记**{非纯皮肤窗——CoreExpr::Fn/IrNode::Fn 加性字段 rest: Option<Symbol>{原则 27} + BcProto rest_slot + VM 三 arity 位 min-arity 门 + 帧建立右折叠 nil 终止 pair 链 + HM/check 零 Ty 增量{rest = 普通类型变量 + 静态 ≥N + 超参 unconstrained}}；Reader 结构诊断三面{非终端 rest / 双 rest / 裸 `...`——E0001 读错位族} + min-arity fail-closed{E0004 "expected at least N" 新形——定参面逐字节维持}；D9 诚实边界{无调用点展开语法 f(xs...)——传链作单实参会链化}；2044 基线净 +32；设计单源 variadic-rest-design.md v1.0 D1-D11}）；v7.31（**r163 / 234-c——索引访问窗——postfix_op `"[" expr "]"` 实施状态注记**：`coll[idx]` ↔ `(vector-ref coll idx)`[第十七皮肤映射——as-if-written；恰一索引表达式{空/多参 fail-closed E0001} + 嵌套链式 postfix 尾循环自然组合 + D3 脱糖目标免 import{vector-ref 入 N1 第 42 名} + D5 不可变维持{assign 位域外} + D6 诚实边界{pair-list 维持 nth 调用形 / Str 字符索引域外}]；r138 D6 位置纪律 superseded——双括号面俱在域；1979 基线净 +31；设计单源 index-access-design.md v1.0}）；v7.30（**r162 / 233-c——相等域窗——comparison 产生式语义注记**：`==`/`!=` → `(eq a b)`/`(not (eq a b))` 域重指向{文法零变更——comp_op 产生式维持} + eq 值律结构化分层 + r138 eq? 律修订 + `=` 休眠态申报 + ordering 族维持；1948 基线；设计单源 equality-domain-design.md v1.0}）；v7.29（**r161 / 231-c——常量声明窗——§8.13.1a toplevel_const 产生式**：`const name [: T] = e;` ↔ `(define name e')`[第十六皮肤映射——toplevel_let as-if-written 孪生；只读语义闭环 = Reader 顺序 const 集 + 项位 assign 拒收{E0001——消息 "cannot assign to a const binding..." + Span = 名 Token 本位[r130 先例]}；const mut 矛盾 + 单绑定封顶 + 块位 domain-out 三专用诊断；模块作用域保存/清空/恢复；种子镜像 reader.ktf{TKEYWORDS + CONST_NAMES 可变全局 + parse_const_decl + parse_stmt_into 门——诊断字节级 parity ×4}；增长签名锚 215/504/247{+4 protos +10 consts +5 globals}；1916 基线净 +32；设计单源 const-declaration-design.md v1.0/v1.1]）；v7.28（**r160 / 230-c——TD-036 元组表达式形窗——§8.13.1a tuple_expr 产生式**[`"(" expr "," expr ")"` ↔ Stx `(cons e₁ e₂)`——第十五皮肤映射：as-if-written cons(a, b)，Reader 直接合成与调用形产物同构的 list[皮肤换、骨架不变——原则 31：零脱糖零新原语零 CoreExpr/IR/操作码，expander/compiler/HM/VM 全链零触及，8 原语不变性第四十二轮]；构造⟺解构对称[模式位 (p, q) r121 二元封顶裁定镜像到表达式位——D2 对称纪律：3+ 元 fail-closed 专用诊断 + 深层嵌套经显式 (a, (b, c))]；单元素 (a) = 纯分组维持 + () = Unit 维持[词法歧义句法位置裁决既有纪律——D3]；尾逗号 fail-closed[r138 vector 同律——D4]；cons 调用形维持[内核聚合基座名 + list 链惯用形——D5：能力补齐窗非退役窗]；HM/check 零变更[BUILTIN_SIGS (Any, Any)→Pair 既有消费——D6：零注册链增量]；双侧 Reader 已实施[种子 parse_primary LParen 逗号臂 + 镜像 parse_tuple_tail——错误面消息+Span 字节级 parity] + ktf_tuple_expr_tests 32 case 门[8 正 + 24 负 1:3——含 as-if-written 字节码全等门 + 构造⟺解构对称 E2E + 全位置形 + 模式位回归锚] + 语料迁移[match describe(cons(1,9))→describe((1,9)) + gc_stress 双件离散 pair 构造位 15 处——输出 parity 逐字节] + 增长签名锚重校准[reader.ktf payload 211 protos/494 consts/242 globals] + 1884 基线；设计单源 tuple-expression-design.md v1.0]）；v7.27（**r159 / 229-c——term 级 `%` 实施状态注记**：注册链五点闭合{register_globals defs + N1_CORE_NAMES 40→41 + BUILTIN_SIGS 62→63 + families 测试锚 + check.ktf TC_SIGS 行} + anf.rs "%"→APrim::Mod{native PoC} + `mod` 别名维持 + 语料现代化{higher_order mod(n,2)→n%2 + vector do→块序列} + ktf_percent_operator_tests 32 case 门[8 正 + 24 负 1:3] + 计数锚全域更新 8 处 + 1852 基线；设计单源 operator-surface-parity-design.md v1.0）；v7.26（**r158 / 228-c 顶层 let 现代化窗——§8.13.1a toplevel_let 产生式**[`"let" [ "mut" ] identifier [ ":" type ] "=" expr ";"` ↔ `(define identifier expr')`——被退役的 define(NAME, e) 调用形经统一 list 结构合成的同一核心形[皮肤换、骨架不变——原则 31：零脱糖零新原语，expander/compiler/HM/VM 全链零触及，8 原语不变性第四十轮]；单绑定封顶[块级 let_stmt 多绑面维持——D1 能力等价退役判据]；mut/类型标注解析后剥离[fn_decl 先例]；项位 = 顶层 + module 项位[parse_item 分发——fn/import/export/require 声明族对称]；define(NAME, e) 项位调用形 fail-closed 现代化诊断[Span = define Token 本位——r130 先例；块位/表达式位维持普通调用语义=诚实边界]；双侧 Reader 已实施[种子 parse_toplevel_let + 镜像 parse-toplevel-let——parse_let_binder 共享] + ktf_toplevel_let_tests 32 case 门[8 正 + 24 负 1:3] + 语料迁移[bootstrap 七件 + examples 四件 + tests 42 文件 + web 预设——R4 工具 scripts/r158-toplevel-let 两遍]；设计单源 toplevel-let-design.md v1.0 D1-D10 + 闭包 EBNF 复审维持裁定 K-1[四候选对照——现行 || (params) -> eff { body } 形胜出：零关键字 + fn_decl 同构 + E-3 逐位实证]；皮肤字典 define→fn 行分裂 = 20 §14 同轮]）；v7.25（**r157 / 227-b3**：EBNF 审查三发现处置 + U4 注记——纯文档轮零代码变更，[design-docs-modernization-plan.md](../develop/v0/stage-3/design-docs-modernization-plan.md) v1.0 §3）；v7.24（**r147 / 217-c extern 符号空间别名窗——§8.13.1a extern_decl 可选声明位别名段**[`"extern" ident [ "as" ident ] "(" ... ")" "->" kind ";"` ↔ 六元素 Stx `(extern NAME as ALIAS (kinds) RET)`——import-as 家族在 extern 声明族上的同构延拓：双名分离 D3[externs_for_compile 对 `(intern(local), Rc(name))`——IR extern_face 既有分离维度启用，IR/编译器/VM 零机制变更] + 替换语义 D4[local 入可见面、underlying 直写 E0022——r134 member-rename D8 反向锚同构] + 自别名拒收 D5 + 反遮蔽扩展 D6[local 入 define/import/N1/既有 extern 可见名碰撞面] + 能力门不感知别名 D7[按 underlying 匹配——r135 D13 行权线] + HM/check A4 Dynamic 维持 D8 + use 选择形接驳维持域外 D9[扁平空间无模块面——宪制]；双侧 Reader 已实施[种子 parse_extern_decl KwAs 前置臂 + 镜像 extern-alias-name 新函数 + alias-rec 双 Token 穿线] + bootstrap 编译桥 CC_EXTERN 协议扩展[(local flat) 对——rv_loop extern_lookup + SymLit 载 second(Rust 侧 IrVar::Extern(flat) 镜像]] + ktf_extern_alias_tests 32 case 门[8 正 + 24 负 1:3] + 语料对 ffi_alias.{ktf,krf}[⇒ 9 双面]；设计单源 extern-alias-design.md v1.0 D1-D10 + §7 域外表八行；皮肤字典第十三映射族别名臂注记 = 20 §14 同轮]）；v7.23（**r143 / 213-c handle 表达式位窗——§8.13.1a handle_stmt primary 位注记**[`primary → handle expr handle-arms`——语句位与表达式位共享一形（r110 表达式位 if / r121 match 值形同构分派第三例——parse_primary 前置分派通道）；五位置形全开放：let 值位 / 函数实参位 / if 条件位 / 嵌套 protected 位 / 多臂 group 位——脱糖产物与语句位逐字节同构{单臂 `(handle tag ((p k) body) protected)` / ≥2 臂 `(handle-group ...)`——D2 零机制变更：expander/compiler/HM/VM 零触及，8 原语不变性第二十五轮}；r133 handler_k 穿线在表达式位无损延拓{嵌套 protected 内 resume 维持域外 fail-closed}；块形 protected 维持域外{protected 必须是表达式——语句位同律}；张力探针五连实证：S-expr 面三位形全合法（P1 ⇒100 / P3 ⇒101 / P7 ⇒11）vs 目标面 E0001 fail-closed（P2/P8）——CLI 双入口双面表达力 parity 缺口第五连清偿（r125 require / r130 import as / r131 use 选择树 / r132 handle 多臂后续）；双侧 Reader 已实施[种子 parse_primary KwHandle 前置臂 + 镜像 parse-primary cond 臂] + ktf_handle_expr_position_tests 32 case 门[8 正 + 24 负 1:3——含五位置形 E2E + 跨面值 parity 327 + 语句位零回归复锚 217/540 + 双 Reader 正典渲染 parity + 位域维持电池] + 语料对 effect_handle_expr.{ktf,krf}[⇒ 327 双面——语料族 13:13]；设计单源 handle-expr-position-design.md v1.0；皮肤字典 D2 handle 映射位域扩展注记 = 20 §14 v1.30 同轮]）；v7.22（**r138 / 208-c TD-002 向量值类型窗——§8.13.1a vector_lit 产生式**[第十四皮肤映射（逗号省略）：目标面 primary 位受理 + postfix 方括号维持索引域外（D6 位置纪律）+ 尾逗号 fail-closed；双侧脱糖 D2：表达式位转 vector 应用形[as-if-written] + quote 位递归字面量脱糖[运行期构造 = quote pair 同律]——零 CoreExpr/IR/操作码[原则 9 冻结维持]；值模型 D3：Value::Vector + HeapObj::Vector 元素槽位制 + GC children 臂 + eq? 引用相等；五内建族 D4：vector/vector-length/vector-ref/vector-append/is-vector——kerf-vector 限定模块 + N1 可见面扩容{vector 构造器 + is-vector 谓词}；渲染 D8 = 括号形可回读；双侧 Reader 已实施 + ktf_vector_value_tests 36 case 门[9 正 + 27 负 1:3] + 语料对双面同输出；设计单源 vector-value-design.md v1.0；皮肤字典第十四映射 = 20 §14 v1.29 同轮]）；v7.21（**r137 / 207-c TD-026 行① FFI extern 声明族窗——§8.13.1a extern_decl 产生式族**[`extern name "(" [kind {"," kind}] ")" "->" kind ";"` ↔ `(extern name (kind...) kind)`——第十三皮肤映射：顶层声明家族第四员[import/export/require 后]；kind = `int` | `str` | `ptr`[D1 三词封顶 = ExternKind VM 消费子集的语言面同构——CIntSize/PointeeType 精度属宿主注册面]；零新原语零通道零新操作码[#43 CallExternal r30 冻结四方同步维持]——声明经驱动面五重校验后剥离[expander 零变更]，调用位经分辨层 IrVar::Extern 扁平符号空间解析后编译臂双侧发射；Keyword::Extern 入共享保留域第 28 名[E0020 面双侧扩展 + ALL 28 计数锚]；双侧 Reader 已实施[种子 parse_extern_decl + 镜像 parse-extern-decl 族——Unit 零参 kind 表双关 = parse_typed_params 先例同构] + ktf_extern_decl_tests 32 case 门[8 正 + 24 负 1:3] + 语料对 ffi.{ktf,krf}[⇒ 9 双面]；设计单源 ffi-language-surface-design.md v1.0 D1-D10 + §7 域外表；皮肤字典第十三映射族 = 20 §14 v1.28 同轮]）；v7.19（**r134 / 204-b use 域外二项清偿窗——§8.13.1a use_tree `as` 成员重命名增补形 + module 头部选择形受理**[`use m::{a as x};` → `(import m (a as x))` 选择列表平铺三元组——替换式注入语义{renamed 替换 underlying 平铺注入位——E0022 反向锚精确：改名后原 underlying 直写 = 未绑定} + 运行时绑定注入{globals[renamed] = underlying 分派体 Rc 共享——与限定名注册同构} + HM A4 Dynamic{renamed ∉ 签名表双侧保守 Dynamic 零误报}；module 头部选择形受理{r131 D6 域外边界退役——expander 头部扫描双侧 + driver 共用单点}；D1-D10 十裁定[设计单源 member-rename-design.md v1.0]：三元组消费链单点 D1 + 目标面 D3 翻转 D2 + 替换式注入 D3 + 运行时注入方案 B D4 + 头部扫描双侧 D5 + ImportFace 加性 D6 + 同域查重 D7 + io/prelude 域外 D8 + Span 契约 D9 + 锚翻转三组 D10；双侧 Reader 已实施 + ktf_member_rename_tests 32 case 门[8 正 + 24 负 1:3——含 E0022 反向锚 + HM A4 check 零诊断] + ktf_use_decl_tests 锚翻转三组净 +1；皮肤字典第十一映射域扩展 = 20 §14 v1.26 同轮；r131 D3/D6 域外注记翻转见 §8.13.1a]）；v7.18（**r133 / 203-c6 嵌套块内 resume 窗——§8.13.1a resume_stmt 作用域扩展**[r128 域外登记清偿——嵌套块（if 臂块/闭包体/嵌套 handle 臂体）内语句位/尾位 resume 全开放；κ 注入域 = innermost enclosing handler arm（S-expr 词法作用域镜像——D2）；嵌套 handle 遮蔽 shadow-aware（D3）+ 闭包捕获开放（D4——探针 ⇒11 实证）+ 受护式 κ=nil 收窄（D5）+ 表达式位维持域外（D6）+ 跨臂显式续体引用收窄（D7）+ halt/pass 臂体直位形维持（D8）+ 死代码纪律延拓（D9）；双侧 Reader 已实施[种子 handler_k 字段 save/restore + 镜像 kcell 闭包胞穿线] + ktf_nested_resume_tests 32 case 门[8 正 + 24 负 1:3——含嵌套等价字节码全等门] + 语料对 effect_nested_resume.{ktf,krf}[⇒ 540 双面]；**同窗 VM P1 清偿**：续体恢复 handler 边界截断[ContinuationValue.boundary——深帧非尾 resume 陈旧 H 执行帧残留清偿——isoB 锚]；皮肤字典 D2 体域扩展注记 = 20 §14 v1.25 同轮]）；v7.17（**r132 / 202-c handle 多臂 / halt / pass 窗增补——§8.13.1a handle_stmt 多臂/halt/pass 产生式族**[`handle e { A(p,k) => b₁, B(p,k) => b₂, }` → 嵌套单臂 handle 脱糖{先写臂外层} + `halt`/`halt(v)` 尾值糖 + `pass` → `(perform (cons (quote T) p))`——expander/compiler/VM 全链零变更{原则 31；8 原语不变性第十四轮验证}；D1-D10 十裁定[设计单源 handle-multi-arm-design.md v1.0]：单臂零回归 D1 + 嵌套序 D2/D9 + sibling 分歧 TD-033 登记 D3 + pass 重构 D4 + halt 糖 D5 + 重复标签 fail-closed D6 + 位形词目标面本地 D7 + 两元绑定纪律 D8 + Span 契约 D10；双侧 Reader 已实施[种子 parse_handle 多臂循环 + parse_halt_form/parse_pass_form + 镜像 handle-arm-loop/handle-fold 族] + ktf_handle_multiarm_tests 32 case 门[8 正 + 24 负 1:3——含嵌套等价字节码全等门{共享符号表——.ktf 平坦形 ↔ .krf 手写嵌套形 compile 产物全等} + 双 Reader 正典渲染/错误面字节级 parity + fvo 清偿回归锚 + pass 无外层 handler 语义负例]；**同窗 P1 缺陷清偿**：fvo 条件入栈/无条件弹出错配[compiler.ktf handle/fn 臂 + Rust expr.rs 同型——嵌套同名绑定崩 tail(nil)——Let 臂 r45/D42 shadow-aware 延拓双侧清偿]；语料对 effect_multiarm.{ktf,krf}[11:11 维持——双面 202]；皮肤字典第十二映射族 = 20 §14 v1.24 同轮**）；v7.16（**r131 / 201-c use 声明 / `::` 导入树窗增补——§8.13.1a use_decl 产生式族**[`use mod;` | `use mod as a;` | `use mod::{m1, m2};` | `use mod::{m} as a;` | `use a, b::{x};` → S-expr import 族 Stx（全量 r40 M2 / 别名 r130 / **选择 r50 D65**——目标面前此不可表达的选择形{`(import kerf-string (append))`——第十一皮肤映射}）；零脱糖零新原语[原则 31]；D1-D10 十裁定[设计单源 use-declaration-design.md v1.0]：`::` 路径树与单层模块名映射裁定{名位受理 Ident|Path + 多段路径 E0019 编译期拒绝——22 §7 单层执法面} + 选择列表成员为裸名{成员重命名 D3 域外 fail-closed} + Stx 元素序 = 消费者序{name [as alias] [(members)]——collect_import_items 代码路径} + 位置纪律{顶层全族 + module 头部裸/别名形——选择形在 module 头部 = 双侧一致 E0002 既有语义边界} + 尾逗号双轨{顶层拒绝 import 族 / 花括号内可省臂族}；双侧 Reader 已实施[种子 parse_use_decl + 镜像 parse-use-decl 函数族十一函数] + ktf_use_decl_tests 32 case 门[8 正 + 24 负 1:3——含双 Reader 正典渲染字节级 parity + 错误面消息+Span 字节级 parity + D3 专用诊断双形 + E0019/E0024/E0022/E0017 语义负例 + module 头部选择形双侧一致 E0002]；域外注记翻转见 §8.13.1a；皮肤字典第十一映射 = 20 §14 v1.23 同轮**）；v7.15（**r130 / 200-b import as 别名窗增补——§8.13.1a import_item 别名位产生式**[`import mod as alias;` / 混合形 `import mod as alias, mod2;` → `(import mod as alias mod2)` 符号逐一同构 s-expr 三形态导入[r40 M2 / 22 §8 R-N5]——collect_import_items/rewrite_alias_refs 消费形零变更；零脱糖零新原语[原则 31]；双侧 Reader 已实施[种子 parse_import_decl 别名臂 + 镜像 import-alias-name/import-alias-sep/import-close/import-item-nodes 四函数] + ktf_import_alias_tests 32 case 门[8 正 + 24 负 1:3——含双 Reader 正典渲染字节级 parity + 错误面消息+Span 字节级 parity 16 形 + .ktf 面 E2E{别名限定引用/module 头部/define 调用形/下划线命名映射/混合声明} + check 跨阶段消费 + E0017/E0019/E0014/E0022/E0004 语义负例 + 跨语法错误面 parity]；名位 `as` = 别名缺模块名专用诊断「import as 别名须跟在模块名后（缺模块名）」；**同窗潜伏缺陷清偿**：名位 as 诊断 Span 种子/镜像错位[种子 bump 后位 vs 镜像 as 本位——双侧统一为 as 本位]；**同窗测试锚翻转**：switch_corpus_parity_tests m3 锚「import a as b; 域外」→「import a as; 缺别名」；域外注记翻转见 §8.13.1a；皮肤字典第十映射 = 20 §14 v1.22 同轮**）；v7.14（**r129 / 199-b 宏面语料窗增补——§8.13.1a macro_decl 宏定义面产生式**[本窗 macros.ktf 语料就位暴露的第九映射缺位：目标语法无宏定义形态则 .ktf 程序无法定义用户宏——`macro NAME ["(" [字面量集] ")"] "{" { 模式 => 模板 [","] } "}" → `(define-syntax NAME (syntax-rules (lit...) (pattern template)...))`{宏名首元素 Reader 注入——r128 resume-k 先例；`...` 词法化为 ident payload 三连点前瞻——S-expr 面符号同构；模板 = 块或表达式——调用实参省略号无条件吸收{非模板位 f(a ...) 两面同产 Stx (f a ...)——展开期错误同形优于读错分叉}}；零脱糖零新原语——expander/macro_sys 全链零变更{原则 31}；`macro` = 目标面本地关键字{Tk::KwMacro——不入共享 Keyword/E0020 域，S-expr 面零扰动 = 原则 27 加性实例——match/require 入共享域区别 = S-expr 面有消费，macro 的 S-expr 面宏定义恒 define-syntax}；双侧 Reader 已实施[种子 parse_macro_decl + 镜像 parse-macro-decl] + ktf_macros_corpus_tests 37 case 门[含双 Reader 正典渲染/错误面字节级 parity]；**同窗 P1 缺陷清偿**：check 恢复模式宏注册丢失[expander.ktf 入口加性拆分 reset/continue + 桥 reset-once/continue-per-form——r17 潜伏两面共通，check 面全体用户宏程序 E0022 误报]；皮肤字典第九映射 = 20 §14 v1.21 同轮]）；v7.13（**r128 / 198-b 语料族深度化窗增补——§8.13.1a handler 块体 resume 语句产生式**[本窗 effect_stress 语料翻译暴露的真实文法缺口：目标面 handler 块体无法表达 S 表达式面 `(do A (resume k v))` 序列形——分配后恢复不可表达，直位 `=> resume(v)` 独木难支；补齐 = 处理器块体顶层语句/尾位 resume 调用形 `resume(expr)` → `(resume k expr)`——k 由臂绑定注入（零脱糖零新原语——原则 31）；双侧 Reader 已实施[种子 parse_handler_block/parse_resume_call + 镜像 parse-handler-block/parse-resume-call] + ktf_stress_corpus_tests 32 case 门[含双 Reader 正典渲染/错误面字节级 parity]；嵌套块内 resume = 登记域外 fail-closed 诚实边界（S 表达式面词法作用域内合法——目标面收窄，触发式后续信号）；皮肤字典 D2 handle 映射体域扩展注记 = 20 §14 v1.20 同轮]）；v7.12（**r125 CLI 双入口窗增补——§8.13.1a require 声明产生式**[本窗 E2E 发现的真实文法缺口：目标语法无 require 形态则 .ktf 程序无法声明 IO 能力——E0006 能力门控的声明面在目标面缺位；补齐 = 顶层声明家族同族裸名形 `require io, write;` → `(require io write)` 逐符号同构 S-expr{零脱糖零新原语——原则 31 零脱糖实例}；双侧 Reader 已实施[种子 parse_require_decl + 镜像 parse-require-decl 三函数] + cli_dual_entry_tests 22 case 门[含双侧解析 parity 字节级一致] + 皮肤字典第八映射登记[20 §14 v1.19 同轮]]）；v7.11（**r121 match 实施批 M-1 增补——§8.13.1a match 产生式族**[match-design.md v1.0 §2 定稿域边界纪律兑现：设计单源→本节规范锚→Reader 解析域开放；零新原语零通道增量——原则 31；r121 消歧裁定三条入档：or 标记中间形（`|` 保留 Token 无绑定碰撞）/ 括号内至多二元（右不嵌套 EBNF 字面）/ 深度帽 8（防御性栈保护）；种子侧实施 + 10 case 门 + 双 Reader 分歧窗 M-1..M-3 锚点登记（M-4 镜像同步闭窗）]）；v7.10（**r115 第二十八轮吸收——§8.13.2a 统一流分析语法族登记**[第十源语料 Level 1-4 登记态——lifetime_override/phase/constraint/interference_rule/flow_analysis_directive/resource_lifetime_decl/借用糖四形 + ~32 关键字候选全脱糖 + use 位形限定词 + Level 0 定稿域零扰动——同步自 stage0.md v8.7 §9.29.3]）；v7.9（**r111 第二十六轮吸收——§8.14 信息效应语法族登记**[第九源语料 Level 1-4 登记态——三分域归位 + ~20 关键字候选全脱糖 + 二义性预防例 23-25 + Level 0 定稿域零扰动——同步自 stage0.md v8.5 §9.27.4]）；v7.8（**r110 切换窗步③ 第二批增补**：§8.13.1a 增补二产生式——多绑定 let_stmt[语料消费 6 处 vs Level 0 单绑定；顺序 let 破坏 D61 暂存法链字节码 parity 实证——双侧 Reader 已实施 + parity 门 10 case] + 表达式位 if[primary 位 if 值形态——list-items 唯一表达式位 if 直映通道]；皮肤字典新三条[20 §14 v1.16 同轮]）；v7.7（**r109 切换窗步③ 首批增补**：§8.13.1a Level 0 增补位——N1 模块生产面 import/export 头部产生式[步③ 语料改写实施发现的文法缺口——原则 44 产生式义务补齐；双侧 Reader 已实施 + parity 门 13 case]）；v7.6（**r104 第二十五轮整合定稿**——§8.13 EBNF v9 整合定稿位[**grammar L2 规范层权威定稿位**：八份骨架统一收敛 + Rust 最小集补全 + 优先级/结合律十四级表 + 关键字分级终态 22 定稿词面 + 二义性 22 例 + 宏层脱糖路径 + 8 原语不变性第九轮验证——同步自 stage0.md v8.4 §9.26；EBNF 定稿子窗开窗{M1 指令开窗第十二例——纯文档域}；切换窗本体维持未开窗{定稿 ≠ Reader 实施}]）；v7.5（r98 第二十四轮吸收——§8.12 语法迁移验证与映射表登记[next17.md D2：切换窗前置设计] + R4 顺修[v7.4 头行 r96 漏更补齐]）；v7.4（r96 第二十三轮吸收——§8.11 EBNF v8 类型语法族[第七份骨架 + 二义性第 15-17 例 + 两域门控]）；v7.3（r94 第二十一轮吸收——§8.10 EBNF v7 生命周期语法族[第六份骨架 + 记法修正 + 二义性预防第 13-14 例 + 零环境通道增量]）；v7.2（r93 第二十轮吸收——§8.9 EBNF v6 能力操作骨架[第五份骨架 + capability_decl 四成员 + 二义性预防第 11-12 例 + 宏层脱糖]）；v7.1（r91 第十九轮吸收——§8.8 EBNF v5 分层版[第四份骨架语料 + Level 3-4 脱糖优先]；v7.0（r89 第十八轮吸收——§8.7 EBNF v4 正逆干涉版[第三份骨架语料]；v6.9（r88 第十七轮吸收——§8.6 EBNF v3 效应容器模型与流形操作语法[15 关键字演进 + connect/lift/project/pass + 二义性预防三例]；v6.8（r84 第十六轮吸收——§8.5 类型与效应标注语法 + 极简关键字体系[容器式签名终态草案登记]；v6.7（r83 第十五轮增量维度收编——§8.4 语法定义形式与语法文件体系[EBNF 体系组织模型——grammar L2 规范层落位]；v6.6（r81 第十四轮吸收——§8.3 目标语言设计蓝图登记；v6.5：r57 第九轮吸收——§8.2；**r43 / E5 S2 关键字切换注记**：§1 Keyword 25 名三件源文本更新——`fn`/`assign`/`do` 替代 `lambda`/`set!`/`begin`[22 §12 D19-D21 重筛终选：否决 set/seq——名空间经济]，变体名不变[原则 31 表面/内部分离]；v6.3：r41 深审注记——§8 前缀形式通解性与括号布局的 2026 前沿对表完成——Rhombus v1.0[2026-06 发布]实证 conventional syntax + 宏可扩展可行[enforestation]但解析复杂度 ×10，kerf 维持 S 表达式主表面 + 多语法窗皮肤路线[原则 31——与 Rhombus bicameral 两院制同向]；词法语法语义二义性面全清[22 §11 D10-D18——六组潜在歧义源逐一显式裁定：/ 双语义/负数字面量/关键字双轨 E0020 修复/as contextual/else 字面匹配/宏遮蔽 W1003 排期]；v6.2：**r38 / 59-a 批次 L 面注记**：§8.1 B1-1 行 v0.5 面澄清——别名层无新 Reader 语法[全为既有词法形态的扁平符号]，v0.5 验证件 = 27 parity case[新旧名同行为同诊断]，双 Reader 同核验证全量面维持批次 M[v0.6 引入 `/` 限定名词法]承载；v6.1：K2/r36 深审回写）
> **Status**: Active
> **处理程度**：P0（必须实现——Stage 0 已落地，kerf-reader + kerf-span + kerf-syntax）｜ **所属 Stage**：Stage 0 ｜ **推迟项**：查询式增量编译按 Span 细粒度失效（Stage 2，[15-架构分层 §3.1](./15-architecture-layers.md)）、编译缓存键与 Span 失效关系（接口预留，[13-能力矩阵 §3.1.4](./13-capability-matrix.md)）

> 本文件收录语法前端的设计与实现：类型化 Token 流 Reader（原 §8.1）、Span 全管线传播（原 §8.6）、结构化诊断框架（原 §8.7）、Span 源位置追踪系统与诊断框架的横切架构约束（原 §12.1/§12.2），以及 Reader 实现框架（原 §19.1：词法器/语法器骨架 + 核心不变式 + 实现陷阱）。九个核心原语的语义定义见 [01-核心原语](./01-core-forms.md)；12 个能力模型的完整矩阵与其余能力见 [13-能力矩阵](./13-capability-matrix.md)（其 §2.1/§2.6/§2.7 为本文件 §1/§2/§3 的规范副本——本文件为专题深化版）；Span/诊断作为横切关注点的分层架构论述见 [15-架构分层](./15-architecture-layers.md)。

---

## 1. 类型化 Token 流 Reader（原 §8.1）

**能力模型**：

```rust
// 2026 成熟方案：Rust proc-macro 风格的类型化 Token
#[derive(Debug, Clone)]
pub struct Token {
    pub kind: TokenKind,      // 类型化的 Token 种类
    pub span: Span,           // 源位置（file, start_line, start_col, end_line, end_col）
    pub scope_id: ScopeId,   // 作用域标识
}

#[derive(Debug, Clone)]
pub enum TokenKind {
    // 字面量
    IntLiteral(i64), FloatLiteral(f64), 
    StringLiteral(Rc<str>), BoolLiteral(bool),
    
    // 标识符
    Identifier(Symbol),         // interned string
    TypeIdentifier(Symbol),
    
    // 关键字
    Keyword(Keyword),           // fn, let, if, match, ...
    
    // 运算符（携带优先级信息）
    Operator(Operator),
    
    // 分隔符
    Delimiter(Delimiter),       // (, ), {, }, [, ]
    
    // 宏扩展点
    MacroInvocation(Symbol),
    
    Eof,
}
```

**职责边界**（v5.1 调和裁定——区分**词法层**与 **Reader 模块**两级）：
- **词法层（tokenize）**：将字符流转为类型化 Token 流；附带 Span；**不做语法分析**、不执行宏展开、不判断类型正确性
- **Reader 模块（完整）**：词法器 + 递归下降**语法器**（本文 §6）——产出 SyntaxObject 树。语法器仅做**括号平衡的 datum 结构化**（S 表达式的 read：列表/向量/字面量/引号简写），**不做传统文法分析**（本语言的语法即数据结构，不存在关键字驱动的语句文法）——这是「同像性」路线下「不做语法分析」的精确含义：不存在传统意义上的 parse 树，read 直接产生可编程的数据结构

> **源文档矛盾调和说明**：stage0.md 原文 §8.1（职责：不做语法分析）与 §19.1（Reader = 词法器 + 递归下降语法器）表述冲突。本拆分按「词法层/Reader 模块」两级裁定调和，并与 Stage 0 实现（kerf-reader：类型化 Token（**`TokenKind` enum 12 变体**，叶级展开 44 种——见下）+ 递归下降语法器读 datum + 'x 简写 → (quote x)）一致。

**Stage 0 实现落点**（kerf-reader / kerf-syntax）：设计层的 `TokenKind`（上图）是 2026 现代方案的**方向性蓝图**（含 `TypeIdentifier / Keyword(fn/let/match) / MacroInvocation` 等扩展位）；Stage 0 实现为同构的类型化 Token——运算符身份显式化而非字符串比较（`Operator` 携带 `Symbol` 句柄）。**Token 种类计数（v5.2 更正，deep-review R1 偏差 #17）**：`TokenKind` enum 为 **12 个变体**（`IntLiteral / FloatLiteral / StringLiteral / BoolLiteral / NilLiteral / Identifier / QuoteShorthand / Keyword / Operator / Delimiter / MacroInvocation / Eof`）；**叶级展开 48 种**（v6.1/r36 口径：v5.4 = 45（+require）；r25 增 Keyword perform/handle/resume 三关键字——48）——构成：字面量 5（Int/Float/Str/Bool/Nil）+ `Identifier` 1 + `QuoteShorthand` 1 + `Keyword` 25（**r43 / E5 S2 后**：`fn`/`if`/`assign`/`define`/`do`/`module`/`import`/`export`/`quote`/`let`/`letrec`/`let*`/`cond`/`else`/`and`/`or`/`when`/`while`/`unless`/`define-syntax`/`syntax-rules`/`require`/`perform`/`handle`/`resume`——三件切换 `lambda→fn`/`set!→assign`/`begin→do` [22 §12 D19-D21]）+ `Operator` 10（+ - * / mod < > <= >= =）+ `Delimiter` 4（( ) [ ]）+ `MacroInvocation` 1 + `Eof` 1（5+1+1+25+10+4+1+1 = 48）。早期文档的「41 种类」不可验证（既非 enum 数也非叶级数），废弃该口径。两者差异是「设计方向 → 阶段实现」的裁剪：`TypeIdentifier`/关键字驱动的表面语法属于 Stage 1+ 表面语言层（[12-路线图 §2.5](./12-roadmap.md) 演进矩阵）；核心不变式（无损、位置完备、词法层零语义）两级同构。Token 使用的辅助类型定义于：`Symbol / SymbolTable`（kerf-syntax，NFC 一次归一化 + 关键字预内部化）、`ScopeId / ScopeSet`（kerf-syntax，有序去重 + 并集/子集）、`Keyword`（kerf-syntax，25 变体——v5.4 +require；v6.1/r36 补 r25 +perform/handle/resume；**r43/E5 S2 三件源文本切换 fn/assign/do**[变体名 Lambda/SetBang/Begin 不变——原则 31 表面/内部分离]，实锚 symbol.rs:24-54，[01-核心原语 §6](./01-core-forms.md)）、`Operator / Delimiter`（kerf-reader 的 TokenKind 变体载荷），`Span / FileId / ByteOffset / ExpansionId`（kerf-span，字节偏移主键 + 行/列派生渲染）。

**NFC 保守子集裁定（v5.2 入设计，deep-review R1 偏差 #18）**：完整 Unicode NFC 归一化需要归一化库；Stage 0 **零外部依赖**约束（自举信任根显式化）下采用**保守子集**策略：ASCII 走快路径；含组合字符（U+0300..U+036F 等）的输入走归一化路径，按「基字符 + 后随重音组合 → 预组字符」的 **Latin-1 常见映射表**折叠（覆盖 ç/Ç 等组合对——组合形式与预组形式必须内部化为同一 Symbol，测试锚定）。映射表之外的组合序列**不被归一并保持原样**（两个 Symbol 风险仅限该子集外的输入）——这是「零依赖 > 完整 NFC」的显式裁定，完整 NFC 于引入 Unicode 依赖的时点（Stage 1+，与 [12-路线图 §2.5](./12-roadmap.md) 评估）升级，接口（intern 时一次且仅一次归一化）不变。

**接口契约**：

```rust
pub trait Reader {
    fn tokenize(&mut self, source: &str) -> Result<Vec<Token>, LexError>;
    // 保证：输出的 Token 流覆盖整个输入（无损）
    // 保证：每个 Token 携带精确的 Span
    // 保证：词法错误返回结构化的 LexError（含位置信息）
}
```

## 2. Span 全管线传播（原 §8.6）

rustc 风格，每个 Token / AST 节点 / IR 节点 / 字节码指令都携带 Span：

```rust
pub struct Span {
    pub file_id: FileId,
    pub start: ByteOffset,
    pub end: ByteOffset,
    pub expansion_id: ExpansionId,  // 宏展开代次
}
```

Span 在每个数据结构中作为不可变字段存在，使得：
- 任何错误都能精确定位到源码
- 调试器可以反查字节码 → IR → 源码
- 增量编译可以基于 Span 进行细粒度失效

## 3. 结构化诊断框架（原 §8.7）

借鉴 rustc 的 Diagnostic 结构：

```rust
pub struct Diagnostic {
    pub severity: Severity,         // Error / Warning / Note / Help
    pub code: Option<DiagnosticCode>,
    pub message: String,
    pub primary_span: Span,
    pub children: Vec<SubDiagnostic>,  // 关联的次要诊断
    pub suggestions: Vec<Suggestion>,  // 修复建议
}
```

**架构原则**：错误是数据而非异常；支持错误恢复策略；多阶段错误关联。

## 4. Span 源位置追踪系统：横切架构约束（原 §12.1）

基础设施层的三个组件（Span、诊断、相位分离）是**横切关注点**：它们不处于编译管线的主数据流上，却被管线每个阶段消费。本节论述 Span 的架构约束；诊断框架见本文 §5，相位分离见 [03-宏系统](./03-macro-system.md)。

**设计原则**：源位置信息从 Reader 产生，贯穿 Expander、Compiler、VM，且必须在所有中间数据结构中作为不可变字段存在。

**为什么不可推迟**：没有 Span 的 AST 无法支持增量编译、调试器、或任何形式的有用错误报告。后期补上意味着重写所有数据结构。Span 的规范定义见本文 §2——采用字节偏移表示（`ByteOffset`），行号/列号在渲染诊断时由偏移派生，避免双源存储造成的不一致。

Span 在管线各阶段的消费方式：

| 阶段 | Span 携带位置 | 消费方式 |
|------|-------------|---------|
| Reader | 每个 Token | 词法错误定位、无损覆盖校验 |
| Expander | SyntaxObject + 宏展开代次（expansion_id） | 多阶段错误关联、卫生性追踪 |
| Compiler | 字节码指令 → debug_info_table | 运行时错误反查源码 |
| VM | debug_info_table（按 pc 查询） | 堆栈追踪生成、调试器断点 |
| 增量编译 | 文件 × 字节区间 | 细粒度失效传播（[15-架构分层 §3.1](./15-architecture-layers.md)） |

这张消费表定义了 Span 的**最小字段集**：任何少于上述字段的设计都会在某个阶段失去反查能力——这正是"横切关注点必须早期内置"（[17-设计原则](./17-principles.md) 原则 6）的具体依据。

## 5. 诊断框架：横切架构约束（原 §12.2）

统一错误数据结构包含严重性、错误码、主消息、主 Span、子位置和建议修复（Rust 结构定义见本文 §3）。作为横切关注点，诊断框架的核心架构约束是**"错误是数据而非异常"**：诊断对象在每个阶段被构造、聚合、按严重性排序后统一渲染，而不是通过异常冒泡打断管线。这带来三个直接后果：其一，编译器可以在单次运行中报告多个错误（异常模型只能报告一个）；其二，Expander 可以在错误恢复后继续展开后续形式，为 IDE 提供增量反馈；其三，诊断的结构化字段（severity / code / suggestions）可以被 LSP（Stage 2）直接消费而无需二次解析。多阶段错误关联（同一错误的词法、展开、编译三个层面位置）依赖 Span 的 expansion_id 字段串联。

## 6. Reader 实现框架（原 §19.1）

> **实现框架系列说明（原 §19 章导言，适用于 02/03/04/05 四个文件的实现框架章节）**：本系列将 [13-能力矩阵 §2](./13-capability-matrix.md) 定义的 12 个能力模型落实为可直接照抄实现的伪代码框架。所有伪代码采用 Rust 风格语法（与能力模型定义保持一致），但刻意停留在"控制流 + 数据流"层面，不绑定具体内存布局——同一框架可无损翻译为 OCaml（推荐宿主）或 C（VM 基座）。每节按「算法骨架 → 核心不变式 → 实现陷阱」组织：不变式是测试设计的直接依据，陷阱清单来自历史实现（Guix 自举链、rustc、Racket BC）踩过的坑。

Reader = UTF-8 感知的词法器 + 递归下降语法器：输入字符流，输出携带 Span 的 Token 流与 SyntaxObject 树（能力模型定义见本文 §1，接口契约见同节）。

> **B3 自举交付注记（r6，Stage 1 批次 B）**：本框架已以 **kerf 源码**双实现——
> `kerf-driver/src/bootstrap/reader.krf`（词法 + 语法全逻辑，Stage 0 VM 上运行；
> 生产读路径 `compile_front` 经此实现）与种子 `kerf-reader`（Rust——引导编译
> reader.krf + parity oracle）。两实现行为契约：Token 流（种类/Span/payload）、
> datum 树、错误消息与 Span **逐字节一致**（`tests/v0/stage1/plan/bootstrap_
> reader_tests.rs` 为验收门，356 全套件经自举 Reader 实证）。词法骨架的宿主
> 依赖收敛为 4 个运行时原语（str->pos-chars / char-whitespace? / char-alphabetic? /
> str-int-valid?，见 [09-stdlib](./09-stdlib.md) v5.4）——字符级索引与 Unicode
> 属性判定是与 Racket string-ref/char-whitespace? 同层的运行时服务，非语言语义面。
> **命名规范注记（v6.1，r32）**：此四件的名称属 v0.4 遗留口径（`->`/`?` 约定）；
> 现代化方向与终态名（`pos-chars`/`char/is-whitespace`/`char/is-alphabetic`/
> `int-valid`——引导私有，跳过 v0.5 别名层直接终态化）见
> [20-表面规范 §8 映射表](./20-surface-conventions.md)；批次 M 前 Reader
> 词法零变更。

**词法器骨架**：

```rust
fn lex(source: &str, file_id: FileId) -> Result<Vec<Token>, LexError> {
    let mut chars = source.char_indices().peekable();  // (byte_offset, char)
    let mut toks = Vec::new();
    let (mut line, mut col) = (1u32, 1u32);
    while let Some((off, ch)) = chars.next() {
        match ch {
            '\n' => { line += 1; col = 1; }
            ' ' | '\t' => { col += 1; }
            '(' | ')' | '{' | '}' | '[' | ']' => {
                toks.push(Token::delimiter(ch,
                    Span::new(file_id, off, off + 1, line, col)));
                col += 1;
            }
            c if c.is_ascii_digit() => {
                let start = off;
                let mut text = String::new();
                text.push(c);
                while matches!(chars.peek(), Some((_, d)) if d.is_ascii_digit()) {
                    let (_, d) = chars.next().unwrap();
                    text.push(d);
                }
                toks.push(Token::int_lit(&text, Span::new(file_id, start, off + text.len(), line, col)));
                col += text.len() as u32;
            }
            c if is_id_start(c) => {           // Unicode 感知：XID_Start
                let start = off;
                let mut text = String::from(c);
                while matches!(chars.peek(), Some((_, d)) if is_id_continue(*d)) {
                    text.push(chars.next().unwrap().1);
                }
                let sym = intern(text);         // Symbol 内部化（一次性）
                toks.push(Token::classify(sym, Span::new(file_id, start, off + text.len(), line, col)));
                col += text.chars().count() as u32;
            }
            '"' => { /* 字符串字面量：处理转义与跨行，逐字符更新 line/col */ }
            _ => return Err(LexError::new(ch, Span::new(file_id, off, off + ch.len_utf8(), line, col))),
        }
    }
    toks.push(Token::eof());
    Ok(toks)
}
```

**语法器骨架（递归下降，每非终结符一函数）**：

```rust
fn parse_expr(&mut self) -> Result<Stx, ParseError> {
    match self.peek_kind() {
        Keyword(Let)     => self.parse_let(),       // let x = e in body
        Keyword(Fn)      => self.parse_lambda(),    // fn (params) body
        Keyword(If)      => self.parse_if(),        // if c { t } else { e }
        MacroInvoke(m)   => self.parse_macro_use(m),// 扩展点：原样包装交给 Expander
        Ident(_)         => self.parse_call_or_ref(),
        IntLit(_) | StrLit(_) | BoolLit(_) => self.literal(),
        _ => Err(ParseError::unexpected_token(self.peek())),
    }
}

fn parse_if(&mut self) -> Result<Stx, ParseError> {
    let kw = self.expect(Keyword(If))?;              // 消费并校验关键字
    let cond = self.parse_expr()?;
    let then_b = self.parse_block()?;
    let else_b = if self.peek_is(Keyword(Else)) { self.parse_block()? } else { Stx::unit() };
    Ok(Stx::if_form(cond, then_b, else_b, kw.span.merge(else_b.span)))
}
```

**核心不变式**：
1. **无损性**：Token 流的 Span 并集精确覆盖输入字节区间，无间隙、无重叠——这是 [15-架构分层 §3.1](./15-architecture-layers.md) 查询式增量编译按 Span 细粒度失效的前提
2. **位置完备性**：任何错误路径都能构造携带完整 Span 的 LexError / ParseError，直接进入本文 §3 诊断框架
3. **词法层零语义**：关键字分类是纯查表，不涉及作用域或类型判断；`MacroInvocation` Token 只是扩展点标记，Reader 不尝试展开

**实现陷阱**：
- **列号语义必须二选一**：字节列与字符列不可混用（UTF-8 多字节字符下二者不同）。本设计统一为"字节偏移为主键，行/列仅用于诊断渲染"，Span 存偏移、渲染时派生
- **标识符 Unicode 规范化时机**：NFC 归一化应在 intern 时做一次且仅一次，否则同一视觉标识符会产生两个 Symbol
- **字符串跨行会破坏行号**：词法器内的 line 计数必须在字符串字面量内部继续维护
- **拒绝"贪心数字"**：`123abc` 应报错（数字后紧跟标识符字符），而非拆成两个 Token——贪心拆分会掩盖用户笔误

## 7. 测试锚点（设计驱动测试，测试验证设计）

| 契约/不变式 | 测试锚点（tests/v0/stage0/） | 验证命题 |
|-----------|------------------------------|---------|
| 无损性（§6 不变式 1） | Reader 快照测试 ≥ 20 项（Token 流 Span 并集精确覆盖，无间隙无重叠） | 细粒度失效前提 |
| 位置完备性（§6 不变式 2） | negative_reader_tests：词法/括号三态错误负例（含 Span 精确字节偏移断言——59 case，E0001 码直接断言） | 错误可直接进入诊断 |
| NFC 归一化一次（§6 陷阱 2，保守子集） | 同一视觉标识符 → 同一 Symbol 单测（Latin-1 组合/预组对） | 双 Symbol 分裂防御 |
| 'x 简写（§6 语法器） | quote 读取快照：'(quote x) 等价 + negative_reader_tests::quote_shorthand_at_eof；r157/227-b3 注：'x 简写随 .krf 面退役（r153/r154 E6——negative_reader_tests 组件族同批删除），现代面符号字面量 = quote(sym) 调用形（皮肤字典第六映射） | 同像性入口 |
| 嵌套块注释/字符串跨行 | 词法器单测（line 计数在字面量内部维护）+ negative_reader_tests::unclosed_string_literals / unclosed_block_comments | 行号正确性 |
| 渲染形状（§3 诊断） | negative_reader_tests::reader_error_rendering_shape（error[E0001] + `-->` + 源摘录）/ reader_error_code_is_e0001（DiagnosticCode 结构化断言） | 诊断是数据（§8.7） |

> 测试矩阵完整定义见 [11-测试基础设施 §3](./11-testing.md)；本表是其语法前端侧子集。

## 8. 表面语法决策与表面/内部语法分离（v6.0 吸收自 next3.md 第六/七轮）

**S 表达式 = Stage 0 工程捷径而非最终形态**：Reader 约 300 行 vs 中缀语法约 3000 行（Pratt parser + 递归下降 + 错误恢复）；S 表达式到核心形式的映射近恒等变换（脱糖零成本）；宏系统直接基于同像性实现（无需语法桥接层）——Stage 0 唯一目标（最短路径验证核心原语语义）因此从 4-6 周压缩到 2-3 周。分阶段语法策略与量化论证见 [12-路线图 §2.4.1](./12-roadmap.md)（v5.5 已收录：Stage 0 S-expr 宿主实现 → Stage 1 S-expr on VM（r6 批次 B3 已兑现）→ Stage 2 切换目标语法（两语法编译后 CoreExpr 全等——Racket `#lang` Rhombus/Hackett 先例）→ Stage 2+ 多语法共存）。

**表面/内部语法严格分离（原则 31）**：表面语法是可替换的用户接口（皮肤——S 表达式/中缀/DSL 均可），内部语法是编译器私有不变量（骨架——CoreExpr 核心原语不变）；本文件 §1 的「表面语法层可替换」即此原则的落地蓝图——任何表面语法经 Reader 桥接产出相同 CoreExpr，语义验证与语法选择正交。内部语法的设计原则（类型安全 ADT 三原则：类型安全优于命名安全 / 语义化命名 / 零冗余）与当前实现合规核验、旧→新迁移映射见 [01-核心原语 §8](./01-core-forms.md)。

### 8.1 测试锚点（§8 新增）

| 锚点 | 验证方式 | 状态 |
|------|---------|------|
| 表面语法可替换性 | 设计审计：Reader trait 边界不泄漏表面语法细节到 CoreExpr（Stx→CoreExpr 单向） | ✅ r9 在位（kerf-reader → kerf-syntax → kerf-expander 单向流，[15 §1.3](./15-architecture-layers.md) 依赖规则） |
| 两语法同核验证（原 Stage 2 前置） | Stage 2 目标语法 Reader 引入时：同一程序双 Reader 编译产物 CoreExpr 全等断言 | ⏸ **改判（K2/r36 B1-1）**：原定 Stage 2 前置未执行；重规划至表面现代化批次 L/M（[20 §5 模块树](./20-surface-conventions.md) + [12 §2.10](./12-roadmap.md)）承载——目标语法引入随 v0.5/v0.6 窗口，同核验证作为该批次验收件。**r38 边界澄清（v6.2）**：批次 L（v0.5 别名层）**不引入新 Reader 语法**（27 别名全为既有词法形态的扁平符号——词法/语法零变更）；v0.5 窗口的验收件 = 27 parity case（新旧名同行为同诊断——stdlib_tests 别名组）；**双 Reader 同核验证全量面维持批次 M 承载**（v0.6 引入 `/` 限定名词法与模块树——届时同一程序双 Reader CoreExpr 全等断言） |

### 8.2 S 表达式的架构位置精确化：语法级 IR 与「脚手架 vs 永久中间层」裁定（v6.5 新增——r57 第九轮 Round 1-2 吸收）

第九轮对 S 表达式在本架构中的位置做三层精确澄清（stage0.md §7.3.6 全量展开）：

**（1）S 表达式从来不是编译器的「内部表示」**——它只是 Reader 层的输入格式（用户/Stage 0 开发者书写的源码文本形态）；编译器的内部表示是 CoreExpr（类型安全 ADT，[01 核心原语 §8](./01-core-forms.md)）。「替换 S 表达式」=「替换 Reader 的输入格式」=「换一种表面语法」——替换深度仅此而已，编译器内部无任何东西需要替换（原则 31 的进程面推论）。

**（2）S 表达式 = 通用语法骨架 = 「语法级 IR」**：数学本质是递归树结构（二叉树的通用编码 = 通用 ADT = 递归结构骨架表示）；所有结构化语法都可映射为 S 表达式（任何语法都是树[AST]，S 表达式是树的通用编码）。精确定位 = **语法层到语义层的过渡表示**：非传统 IR（非优化对象）/非表面语法（Stage 2 后用户不直接写）/非核心语义（非原语）——是 Reader 输出、Expander 输入的骨架形态。Racket SyntaxObject 即此定位的工业实证：`{datum: S 表达式, scopes: ScopeSet, phase: PhaseLevel, span: SourceSpan}`——「扩展的 S 表达式」（骨架 + 作用域/相位/位置增强）；`#lang` 支持 Rhombus 等非 S 表面（[§8 r41 对表](#8-表面语法决策与表面内部语法分离v60-吸收自-next3md-第六七轮)——核心架构不依赖 S 表达式，是设计选择而非技术必然）。

**（3）「脚手架」vs「永久语法级 IR」六维度裁定（设计选择 A vs B）**：

| 维度 | 选择 A：一次性脚手架（本项目裁定） | 选择 B：永久语法级 IR（登记替代设计） |
|------|----------------------------------|-------------------------------------|
| 性能 | ✅ 少一层转换 | ❌ 多一层开销 |
| 架构复杂度 | ✅ 更简单 | ❌ 多一个中间层 |
| 工具支持 | ⚠️ 工具需理解多种语法 | ✅ 工具只需理解 S 表达式（统一骨架） |
| 错误追踪 | ✅ 源码→CoreExpr 直接映射 | ⚠️ 需穿透中间层 |
| 自举简单性 | ✅ Stage 2 完成后删除 | ❌ 永远维护 S 表达式层 |
| 灵活性 | ✅ 新语法直接映射到 CoreExpr | ✅ 新语法映射到 S 表达式（更简单） |

**裁定：本项目取 A**（性能/架构/自举三优——§8 决策逻辑链不变）；**B 登记为有效替代设计**（若「工具链支持」成为核心目标——工具统一理解一种骨架的收益反转——B 可能更优；登记于 [14 替代设计](./14-design-alternatives.md)，不构成本项目路线变更）。B 的实质 = 把「语法级 IR」从自举脚手架提升为永久中间层（所有表面语法 → S 表达式 → CoreExpr 两段管线）。替换的进程语义（Stage 2a 完全自举 → Stage 2b 重写非转化）见 [07 自举策略 §3.2.1](./07-bootstrap-strategy.md)。

### 8.3 目标语言设计蓝图登记：表面语法面（v6.6 新增——r81 第十四轮吸收，同步自 stage0.md v7.3 §9.14）

> **本节定位**：next10.md 第一段「目标语言的完整设计」的表面语法面收编——目标语言（Stage 2+ 表面语法切换窗 #15 门控）的语法成员设计登记态。**零代码变更；#15 六步前置清单未开窗**。

**语法成员全糖化清单**（目标表面提案——全部可宏展开为原语）：`fn`（函数定义）/`if`/`while`/`for`/`match`（Branch + 谓词组合）/`try`-`catch`（Error 效应糖）/`async`/`await`（Async 效应糖）/`handle_state`（State 效应糖）——与原则 31（表面-内部严格分离）完全一致：任何表面关键字的编译产物 = 相同核心形式。**try/catch 定位裁定**（stage0.md §9.15.3）：try/catch = 标准库宏非语言核心机制——展开为 handle + 错误传播（再 Perform）；表面语法糖依赖宏系统（Stage 0 已有 syntax-rules 引擎）+ 目标表面（Stage 2+）——语法糖落地时序 = #15 切换窗之后，语义基础（Perform/Handle）已冻结就位（§3.2）。

**渐进披露四层**（[17 原则 43](./17-principles.md) 同轮注册）：初学者（零效应知识可编程——fn/struct/if/while/match/try-catch 熟悉语法——效应标注由推断系统承载自动隐藏）/进阶者（effects 标注 + trait 泛型 + 能力管理）/高级者（自定义效应 + 处理器组合 + 自定义宏）/专家（原语内部 + 根空间扩展）——**分层 = 皮肤叠加非内核分叉**（禁止按用户层级分裂为不同语言）；与原则 33 互补（33 管表面随机制演进、43 管复杂度随用户层级披露）。

**类型系统成员登记态**（stage0.md §9.14.2——实况对账 R4）：基础类型（i8-i64/u8-u64/f32/f64/bool/char/str/`()`）+ 复合（struct/enum）+ 泛型 + 联合类型（行多态 union）+ 交叉类型（`A & B`）+ 行类型（开放记录 `...rest: Row`）+ 效应行（签名 `effects { Read, Write }`）+ 线性能力（`cap: linear ReadCap`）——Stage 0 当前生产面 = HM 单态推断 + 多错误收集（r75/r80——check.krf 判定面）；行多态/交叉/开放记录/线性句法均为 **Stage 2+ 类型系统演进登记态**（理论锚 [19 §15](./19-references.md)：Leijen 2014/Castagna 2024）。

### 8.4 语法定义形式与语法文件体系（EBNF 体系组织模型）（v6.7 新增——r83 第十五轮增量维度收编，同步自 stage0.md v7.4 §9.16）

> **本节定位**：用户第十五轮新维度指令「目标语言的语法定义形式和语法文件描述与……系统化体系组织模型（间）设计(EBNF,...)」的语法面主体收编——本文件自此承担 **grammar 规范层（L2）** 职责（stage0.md §9.16.5 四层模型的文档单源落位）。**零代码变更；§3.2 冻结不动；Stage 2+ 语法文件实施 = #15 切换窗与工具窗门控登记态。**

**审查发现（缺漏三证据）**：G1 next10.md 全文无 EBNF/文法内容（语法以成员清单登记——「有什么」≠「如何定义」）；G2 stage0 §9.14.2 继承清单式登记（上游语料缺漏显性化）；G3 本目录 25 文件 EBNF/文法锚零 + 关键字双源（[20 §8](./20-surface-conventions.md) 文档源 vs symbol.rs 代码源）无 grammar 单源。缺漏定性：不阻塞 Stage 0（S 表达式语法极简）；阻塞 #15 切换窗设计完备性（六步前置清单第 1 步「完整语法规范」无形式载体）；工具面漂移债（Rust reference 非形式化前车之鉴——文法与实现长期漂移代价）。

**五体系对照与三裁定**（判据先于先例——[17 原则 35](./17-principles.md)）：ISO EBNF 14977（否决——`[], {}` 记法歧义史 + Wheeler 2019 批评锚）/ **W3C EBNF**（✅ 采纳为登记记法——XML 1.0 §6 先例 30 年工业实证 + 产生式后附语义/诊断锚注释）/ PEG（实现参考锚非规范记法——Ford 2004；无歧义性是解析性质非定义性质，有序选择使文法参与语义裁定）/ ANTLR4（否决入链——生成器入编译链 = 自举链纪律冲突，与 LLVM 永不入自举链同构）/ tree-sitter（L4 工具层——从规范层单向派生禁止反向）。三裁定：**G-A** 登记记法 = W3C EBNF 风格；**G-B** 定义/解析分离（CFG 级定义 + Stage 0 手写递归下降维持 + PEG 为 Stage 2+ 实现参考登记态）；**G-C** 语法生成器永不入自举链（Reader 正确性由九糖推导表 + 1005 测试锚守护）。

**Stage 0 语法 EBNF 形式化**（既有事实描述——R4 代码为准，与 symbol.rs 25 关键字逐名对账 ✅）：

```ebnf
(* kerf Stage 0 表面语法 —— W3C EBNF 风格登记（v6.7——既有事实形式化）
   对账锚：九原语 [01 §2] / 25 关键字 symbol.rs / 糖推导表 [01 §5] *)
program        ::= toplevel*
toplevel       ::= define | define_syntax | module_item | expr
(* 声明层 ModuleItem——r49 上移 *)
define         ::= '(' 'define' symbol expr ')'
define_syntax  ::= '(' 'define-syntax' symbol syntax_rules ')'
module_item    ::= module | import | export | require
module         ::= '(' 'module' symbol import* export* toplevel+ ')'
import         ::= '(' 'import' qualified_name+ ')'
export         ::= '(' 'export' symbol+ ')'
require        ::= '(' 'require' string+ ')'
qualified_name ::= symbol ('/' symbol)+
(* 核心层——九原语 §3.2 冻结 *)
expr           ::= core_form | derived_form | application | atom
core_form      ::= fn_form | if_form | assign_form | let_form
                 | perform_form | handle_form | quote_form
fn_form        ::= '(' 'fn' param_list body ')'
if_form        ::= '(' 'if' expr expr expr ')'
assign_form    ::= '(' 'assign' symbol expr ')'
let_form       ::= '(' 'let' binding+ body ')'
perform_form   ::= '(' 'perform' expr expr+ ')'
handle_form    ::= '(' 'handle' expr handler_clause+ ')'
quote_form     ::= '(' 'quote' datum ')'
application    ::= '(' operator expr* ')'
operator       ::= expr                (* 头表达式任意——(a b c) 通解性 *)
handler_clause ::= '(' pattern handler_body ')'
handler_body   ::= resume_form | body
resume_form    ::= '(' 'resume' expr ')'  (* 脱糖 (κ v) Apply——D4 *)
(* 派生层——九糖族全宏展开 *)
derived_form   ::= letrec | letstar | cond | and | or | when | unless | while
letrec         ::= '(' 'letrec' binding+ body ')'
letstar        ::= '(' 'let*' binding+ body ')'
cond           ::= '(' 'cond' cond_clause+ ')'
cond_clause    ::= '(' test expr+ ')' | '(' 'else' expr+ ')'
and            ::= '(' 'and' expr* ')'
or             ::= '(' 'or' expr* ')'
when           ::= '(' 'when' expr body ')'
unless         ::= '(' 'unless' expr body ')'
while          ::= '(' 'while' expr body ')'
(* 原子层——词法 *)
atom           ::= symbol | keyword | literal
literal        ::= integer | float | string | char
                 | 'true' | 'false' | 'nil'
body           ::= expr+
binding        ::= '(' symbol expr ')'
param_list     ::= symbol*
pattern        ::= '_' | literal | symbol
datum          ::= atom | '(' datum* ')'
syntax_rules   ::= '(' pattern template ')'
```

**Stage 2+ 目标语法 EBNF 骨架**（#15 门控登记态——完整骨架与两处关键登记[try/catch 库层文法分区 + 优先级表独立义务]见 [stage0.md §9.16.4](../stage0.md)；本节为规范层索引位）。

**grammar 四层组织模型**（体系组织模型（间）设计）：L1 记法层（W3C EBNF 风格）/ **L2 规范层（本节——文档单源：Stage 0 事实文法 + Stage 2+ 骨架索引 + 优先级表[Stage 2+ 义务] + 产生式↔诊断锚关联[Stage 2+ 义务]）** / L3 实现层（kerf-reader 手写递归下降 + PEG 评估窗登记态）/ L4 工具层（tree-sitter 单向派生）。**单源纪律**（[17 原则 44](./17-principles.md) 同轮注册）：本节为文档侧语法唯一权威呈现——与 symbol.rs 代码源形成「文档单源 + 代码为准」对照结构（漂移检测自动对账脚本 = Stage 2+ 工具窗义务）。

**前沿对照六锚**（[19 §16](./19-references.md) 同轮文献六条——六项 web-search 实检索证 r83-q1~q6）：Ford 2004 PEG / W3C XML 1.0 EBNF / Wheeler ISO 14977 批评 / tree-sitter / ANTLR4 / Rust 非形式化教训；广度补充：Rhombus enforestation（动态扩展 vs 静态定义正交两轴——kerf 选静态定义 + syntax-rules 宏动态扩展）+ Scheme R7RS 附录 BNF（Lisp 族形式化登记先例——「语法简单」不豁免「定义形式」义务）。

### 8.5 类型与效应标注语法 + 极简关键字体系（v6.8 新增——r84 第十六轮吸收，同步自 stage0.md v7.5 §9.17）

> **驱动源**：next11.md 段 2/3/4——极简关键字设计 + 类型与效应标注语法四方案演进（用户否决方案 A → 容器模型裁定）。本节登记目标语言签名形态与关键字体系的 **Stage 2+ 登记态**（#15 门控——切换窗六步前置清单维持未开窗）。

**类型与效应标注语法演进链（终态草案登记）**：`effects { Error }` 标注式（早期形态）→ `-> i64 + {Error}` 内嵌式（方案 A——Koka 风格改进，**被用户否决**：仍属「类型主体 + 效应附加」二元分离残留，try/catch 思维残留）→ **容器式 `fn f() -> Return(T) | E`（用户裁定——登记终态草案）**。容器模型语义：函数整个返回区域是一个效应（`Return(i64)` 与 `Error` 为平等容器——无主次之分）；**类型 ⊂ 效应**（类型是容器携带的内容；效应可无内容 = 空容器；效应可携带任意内容）；裸类型语法糖 `-> i64` ≡ `-> Return(i64)`；容器操作（效应处理）与内容操作（数据处理）完全独立且自主——原则 42「统一而分治」的本体论根基。`|` 分隔符与行多态 `{..E}`（[19 §17](./19-references.md) E.17-116 Rémy 锚 + E.15 Leijen 锚）在 #15 窗内定稿时统一裁定。

**极简关键字体系（17 个，六组）**：结构定义 4（fn/struct/enum/module）+ 绑定与控制 4（let/if/else/match）+ 类型系统 2（type/impl）+ 效应系统 3（effect/perform/handle）+ 能力系统 2（capability/linear）+ 其他 2（use/pub）——全部其他功能经宏或效应实现。**十二项传统关键字效应替代表**（try/catch→handle+Error/throw→perform/async-await→Async 效应/while-for→State+递归或宏/return→handle final 分支/break-continue→Loop 效应/yield→Generator/class-extends→struct+impl/new→构造表达式/do→直接 perform/trait→type+impl）详见 [stage0.md §9.17.2](../stage0.md)。**宏层熟悉语法**（try!/async!/while!/for! 标准库宏——看起来像关键字但属于库）与渐进披露四层（原则 43）协同：初学者用宏层、专家直接用效应原语。

**与 grammar 规范层的关系（原则 44 载荷）**：①17 关键字极简 EBNF（next11 段 2 修正版——statement 产消 try_stmt/while_stmt/for_stmt，控制流统一 perform/handle）+ 段 1 完整 EBNF 草案（含传统关键字——被段 2 推翻的演进中间形态）**均入本文件 grammar L2 规范层作 Stage 2+ 骨架语料对照**（语料对照锚——定稿义务仍在 #15 窗内：优先级/结合性/二义性审理）；②容器式签名语法产生式（`fn_decl = ... "->" effect_set`，`effect_set = effect { "|" effect } | type_shorthand`）为骨架的签名面组成；③**与 Stage 0 实况正交分层（R4）**：Stage 0 实现语言 25 关键字（symbol.rs）是脚手架语法非目标语言形态——17 关键字不构成对 Stage 0 的任何变更义务。

**审查注记**：效应本体论三部曲（容器→概率域→生命周期）的理论登记见 [stage0.md §9.17.4](../stage0.md)——机制层（Perform/Handle/Resume）100% 兼容现有系统（同一系统两种描述裁定），理论演进零机制载荷；本节只承载其语法面投影（签名形态 + 关键字体系）。

### 8.6 EBNF v3 效应容器模型与流形操作语法（v6.9 新增——r88 第十七轮吸收，同步自 stage0.md v7.6 §9.18.5）

> **本节定位**：next12.md 第十七轮吸收的语法面主体收编——EBNF v3 完整重写（效应容器模型）+ 15 关键字演进 + 流形三语法（connect/lift/project）+ pass 穿透 + 二义性预防三例。全节 Stage 2+ 设计登记态（#15 门控——切换窗六步前置清单维持未开窗；定稿义务含优先级/结合性/二义性审理与流形三语法就绪度裁定）。

**15 关键字演进（极简化演进链第二环）**：17 关键字（next11/r84——含 impl 与 linear 关键字）→ **15 关键字**（next12 本轮）：结构定义 4（fn/struct/enum/module）+ 绑定与控制 4（let/if/else/match）+ 类型系统 1（**type——含 impl 简化**，函数类型保留 `"impl"? "Fn"` 前缀形态）+ 效应系统 3（effect/perform/handle）+ 能力系统 1（**capability——linear 降为类型标注** `linear(T)`，产生式成员 `capability_type_ref = "linear" "(" type_list ")"`）+ 其他 2（use/pub）。**演进性质**：关键字减二、表达能力不减（语法形式压缩非功能削减）；宏层熟悉语法策略（try!/async!/while!/for!——§8.5 既有登记）不变。

**EBNF v3 核心产消（grammar L2 第二份骨架语料）**：

```ebnf
(* 效应并集：返回区域 = 效应容器集合 *)
effect_union   = effect_container { "|" effect_container } | type_shorthand ;
type_shorthand = type ;                        (* 裸类型 = Return(T) 糖 *)
effect_container = effect_name [ "(" type_list ")" ] | "Never" ;
effect_name    = identifier ;                  (* 用户自定义或内置 *)

(* 效应定义（含连接声明——流形语法） *)
effect_decl    = [ "pub" ] "effect" identifier [ "(" type_params ")" ]
                 "{" { effect_operation | effect_connection } "}" ;
effect_operation = identifier [ "(" [ params ] ")" ] [ "->" type ] "," ;
effect_connection = "connect" connection_type effect_ref "to" effect_ref "," ;
connection_type = "-->" | ">>" | "<->" ;       (* 串联 / 嵌套 / 循环 *)

(* 效应处理（含 pass 穿透） *)
handle_stmt    = "handle" expr "{" { handler_arm } "}" ;
handler_arm    = effect_pattern "=>" handler_body "," ;
effect_pattern = effect_name [ "(" [ pattern_list ] ")" ] [ "if" expr ] ;
handler_body   = "resume" "(" expr ")" | "halt" [ "(" expr ")" ] | "pass" | block ;

(* 升降维（流形语法） *)
lift_stmt      = "lift" expr "as" identifier [ ":" "EffectManifold" "<" type ">" ] ";" ;
project_stmt   = "project" expr [ "at" effect_name ] ;
```

**pass 穿透裁定**：handler_body 第四形态——不处理该效应继续向上传播（与 [T-EFFECT-PROPAGATION] 规则同构——[06 §10](./06-operational-semantics.md) 同轮登记）；切片操作「只处理维度 E 其他穿透」的语法载体。

**connect/lift/project 三语法裁定**：流形为解释框架层登记（[17 原则 46](./17-principles.md)——机制 100% 兼容零变更）——语法面是否纳入目标语言首批形态属 #15 窗内决策（按「实现就绪度」裁定，非本轮义务；EBNF v3 登记其形态以备窗内审理）。

**二义性预防三例（EBNF 层——§8.5 二义性三策略的语法面增量）**：①**`|` 位置敏感**——类型标注位置（`->` 后）= 效应并集；表达式位置 = 位或（需括号）；编译器通过位置区分（类型位置 vs 表达式位置）无二义 ✅；②**match vs handle 语法分立**——`match_arm = pattern => block`（值的模式匹配）vs `handler_arm = effect_pattern => handler_body`（效应的处理）语法不同无混淆 ✅；③**闭包 `||` 前缀强制**——空参闭包 `|| -> i64 { 42 }` vs 有参闭包 `||(x: i64) -> i64 { x * 2 }` 前缀消歧 ✅。

**与 grammar 规范层的关系（原则 44 载荷）**：v3 = next11 极简版之后的第二份骨架语料（完整产消级——比极简版多出 pattern/辅助产消与流形三语法）；按 [原则 44](./17-principles.md) 入 grammar L2 规范层本节登记；定稿义务仍在 #15 切换窗内（优先级/结合性/二义性审理——六步清单第 1 步不变）。

**审查注记**：效应流形理论本体（三连接公理 + 切片/升降维对偶）见 [stage0.md §9.18.3](../stage0.md)；15 关键字与 17 关键字的关系 = 目标语言登记态内部演进（Stage 0 25 关键字实现层正交不动——R4 分层对账沿袭 §8.5）。

### 8.7 EBNF v4 正逆干涉版：逆向/干涉/概率三语法族（v7.0 新增——r89 第十八轮吸收，同步自 stage0.md v7.7 §9.19.7）

> **本节定位**：next12.md 追加段（2845-6512 行——第八次 #15 用户行权）的语法面收编——EBNF v4 = grammar L2 **第三份骨架语料**（v1 极简版 + v3 容器版之后）。全节 Stage 2+ 设计登记态（#15 门控——切换窗六步前置清单维持未开窗）。

**逆向语法族**：`consume_stmt = "consume" effect_name [ "(" [args] ")" ]`（等待接收——Perform(Receive) 的语法投影）/ `offer_stmt = "offer" expr "{" {offer_arm} "}"`（提供聚合——Handle 服务模式的语法投影）/ `offer_arm = effect_pattern "=>" offer_body ","` / `offer_body = "rewind" "(" expr ")" | "absorb" | block`（回传/吸收终止/普通块三形态）/ `rewind_stmt = "rewind" "(" expr ")"`（多播回传——Resume 多播形态的语法投影）/ `effect_direction = "direction" ("forward"|"reverse"|"bidirectional") ","`（效应方向声明）/ `pipeline_expr = expr "|>" "consume" effect_name`（管道糖）/ `aggregate_stmt = "aggregate" "{" {consume_stmt} "}" "into" offer_stmt`（聚合糖）。

**干涉语法族**：`interference_decl = "interference" identifier "on" resource_ref "{" {handler_pair} "}"`（显式声明共享资源）/ `handler_pair = "(" handler_ref "," handler_ref ")" ["->" interference_type]` / `interference_type = "constructive"|"destructive"|"entangled"|"auto"`（编译器推断）。

**概率语法族**：`probabilistic_handle = "probabilistic" "handle" expr "{" {weighted_arm} "}"`（`weighted_arm = [probability "=>"] handler_body ","`——概率分支）/ `competitive_offer = "competitive" "offer" "{" {offer_with_weight} "}"`（`offer_with_weight = ["weight" expr ":"] offer_stmt`——加权竞争）。

**关键字张力裁定（窗内决策素材——J-D）**：v4 引入 ~10 个新关键字候选（consume/offer/rewind/absorb/aggregate/interference/probabilistic/competitive + direction 修饰字 + weight）——与 15 关键字极简演进方向（17→15）形成**张力**；窗内按「实现就绪度 + 极简义务」**双判据裁定**；**备选零关键字路径登记**：宏层/糖展开（`consume E(v)` 脱糖为 `perform Receive_E(v)`——逆向操作为使用模式非原语的 [J-A] 裁定在语法面的投影；interference_decl 可为编译器 pragma/分析器配置非语言关键字）。

**二义性预防增补（第 4-7 例——§8.6 三例的续）**：④**consume vs perform**（同为效应操作关键字分立——「发出」vs「等待接收」语义对立消歧）；⑤**offer vs handle**（处理模式分立——「拦截处理」vs「提供服务」语法面正交）；⑥**weighted_arm 前缀形态**（`probability =>` 浮点字面量前缀 vs `effect_pattern =>` 模式前缀——前缀类型区分消歧）；⑦**管道 `|>` vs 位或 `|`**（双字符算子分立——与效应并集 `|` 三同形位：类型位置效应并集/表达式位置位或[需括号]/管道双字符——位置 + 字符数双消歧）。

**与 grammar 规范层的关系（原则 44 载荷）**：v4 = 第三份骨架语料（逆向/干涉/概率三语法族）；按 [原则 44](./17-principles.md) 入 grammar L2 规范层本节登记；定稿义务仍在 #15 切换窗内（六步清单第 1 步不变——v1/v3/v4 三份语料在窗：极简版 + 容器版 + 正逆干涉版）。

**审查注记**：逆向效应流对偶理论与 8 原语闭合验证见 [stage0.md §9.19.2/§9.19.4](../stage0.md)；正逆五类型规则 + 干涉四类型规则的语义面登记见 [06 §11](./06-operational-semantics.md)；「收拢/坍缩」同形异义与量子术语族隐喻裁定见 [22 §22](./22-namespace-design.md)。

### 8.8 EBNF v5 分层版：Level 0-4 五层语法与拓扑/量子语法族（v7.1 新增——r91 第十九轮吸收，同步自 stage0.md v7.8 §9.20.7）

**第四份骨架语料**（next13.md 收敛版——**分层组织本身 = 结构贡献**：v1/v3/v4 平铺语法规则 → v5 按「实现就绪度」分层，与「五层理论 vs 四阶段实现」映射[K-F]同构）：

- **Level 0 基础语法（必需——Stage 0-1）**：`fn_decl`/`effect_union`/`type_shorthand`（裸类型 = Return(type)）/`effect_container`（含 Never）/`perform_stmt`/`handle_stmt`/`handler_arm`/`effect_pattern`（含 if 守卫）/`handler_body`（`resume(expr)` | `halt[(expr)]` | block 三形态）/`effect_decl`/`effect_operation`——与 v3/v4 Level 0 一致对账（halt = v3 既有登记）。
- **Level 1 逆向效应（Stage 1+）**：`consume_stmt`/`offer_stmt`/`offer_arm`/`offer_body`（`rewind(expr)` | `absorb` | block 三形态）——v4 逆向语法族子集一致对账。
- **Level 2 流形操作（Stage 2+）**：`lift_stmt`（`lift expr as id [: EffectManifold<T>]`）/ `project_stmt`（`project expr at effect_name`）/ `effect_connection`（`connect connection_type effect_ref to effect_ref`；`connection_type = "-->" | ">>" | "<->"`）——v3 流形语法族一致对账。
- **Level 3 拓扑查询（Stage 3——r91 新增量一）**：`topology_query = "topology" "{" {topology_operation} "}"`；`topology_operation = "homology" effect_scope | "curvature" effect_scope | "euler" effect_scope`（同调/曲率/欧拉三查询）。
- **Level 4 量子结构（Stage 3+ 研究性——r91 新增量二）**：`interference_decl`（`interfere effect_ref with effect_ref [on resource_ref]`——与 v4 interference_decl 形态差异对账）/ `entangle_decl`（`entangle "{" effect_ref_list "}" [rule entanglement_rule]`；`entanglement_rule = AllOrNothing | Majority | Correlated | identifier`）/ `superposition_expr`（`superpose "{" effect_expr_list "}" [with phase_list]`）/ `measure_stmt`（`measure expr [collapse to effect_name]`）/ `path_integral_expr`（`integral over effect_paths [weight weight_fn]`）。

**关键字张力与脱糖裁定（K-D——J-D 双判据沿袭）**：v5 新关键字候选 ~9 个（topology/homology/curvature/euler + interfere/entangle/superpose/measure/integral）——与 15 关键字极简方向张力沿袭窗内双判据（实现就绪度 + 极简义务）；Level 3-4 全部为非就绪语法 → **脱糖备选路径优先级提高**：topology_query/homology/curvature/euler = 编译器分析器配置/pragma 非语言关键字的备选形态（K-A 第一级组合拓扑工具可经编译器 pass 配置面暴露零关键字占用）；entangle_rule 枚举 = 类型/宏层面非关键字；四份骨架语料（v1/v3/v4/v5）统一在 #15 切换窗六步清单内定稿审理。

**二义性预防增补（第 8-10 例——§8.7 第 4-7 例的续）**：⑧**entangle rule 枚举 vs 自定义 identifier 尾位**（保留字枚举与标识符同产生式尾位竞争——用户定义 `rule Majority` 时的遮蔽语义：保留字优先 + 用户自定义需限定[命名空间路径]——与 R-N1 解析优先序联动）；⑨**superpose with phase_list 数字前缀**（`with 0.5, 0.3, 0.2` 浮点列表 vs handler_body 表达式位置——前缀类型区分 + 逗号定界消歧）；⑩**measure...collapse to vs project at**（同为「作用目标效应」介词形态——collapse to[坍缩目标：投影选择] vs at[投影点：降维位置]语义近邻——介词区分 + 22 §23 消歧联动）。

**审查注记**：数学工具箱分级裁定（K-A）与理论-实现分层映射（K-F）见 [stage0.md §9.20.2/§9.20.6](../stage0.md)；量子登记态子空间归位（K-E）见 [24-空间正交分解 §17](./24-space-decomposition.md)；波粒二象性语义注记见 [06-操作语义 §12](./06-operational-semantics.md)。

---

### 8.9 EBNF v6 能力操作骨架：capability_decl 四成员与耦合演化语法族（v7.2 新增——r93 第二十轮吸收，同步自 stage0.md v7.9 §9.21.5——第五份骨架语料）

> **本节定位**：next14.md Doc4 §一 EBNF v6 的语法面收编——**登记态骨架**（Stage 2+ 目标语法 #15 门控维持——非实施语法）。同步：[22 §24 关键字张力](./22-namespace-design.md)、[17 原则 49](./17-principles.md)。

**capability_decl 四成员**：`capability_state`（线性资源状态字段）/ `capability_operation`（`on effect_pattern => grant|transfer|revoke|consume|derive|evolve|block 七动作`）/ `capability_metric`（`coefficient effect_kind, dimension => expr` + `connection e₁, e₂ => matrix` + `curvature (e₁, e₂) => tensor` 三分量）/ `capability_derivation`（`derive id [from pattern] [when expr] block`）。**使用语法族**：`grant ... to ... with` / `transfer ... to` / `revoke` / `compose(...)` / `split(...)`。**效应操作语法族**（14 操作对应）：`control/restrict to/amplify by/transform via/collapse to/aggregate(...)/fractal into/interfere via/annihilate with` 十形。**耦合演化**：`evolve together { effect_computation, capability_state } [until convergence_condition] block`。

**二义性预防第 11-12 例**（§8.8 第 8-10 例的续）：⑪ `grant/revoke` 动词 vs 用户标识符尾位竞争（若入关键字域——保留字优先 + E0021 诊断指引同 §8.8 先例；本轮裁定 = 不入——宏层脱糖备选）；⑫ `transfer to` 双词组 vs 表达式语句歧义（`to` 若关键字化与类型标注语法张力——宏层函数调用形态消歧 `((transfer cap) to entity)` 同像性承载）。**骨架态结论**：15+ 关键字全部不入语言首批形态（22 §24 E0020 经济判据 + 原则 49 违反示例③）；实施路径 = 宏层糖 → 8 原语核心层。

### 8.10 EBNF v7 生命周期语法族：resource_decl 与生命周期标注（v7.3 新增——r94 第二十一轮吸收，同步自 stage0.md v8.0 §9.22.4——第六份骨架语料）

> **本节定位**：next15.md Doc2 §一生命周期 EBNF 的收编——第六份骨架语料（承 v2 容器/v3 流形/v4 逆向/v5 分层/v6 能力）。Stage 2+ 目标语法，#15 门控维持；零代码变更。同步：[22 §25](./22-namespace-design.md)（关键字张力）、[13 §3.16](./13-capability-matrix.md)、[17 原则 50](./17-principles.md)。

**语法族五成员**：①`resource_decl` = `[ "pub" ] "resource" identifier [ "<" type_params ">" ] "{" { resource_operation } "}"`——四操作产生式 acquire/use/release/transfer；②`borrow_decl` = `[ "pub" ] "effect" "Borrow" "{" { borrow_operation } "}"`——immutable[→ BorrowToken] / mutable[→ linear MutBorrowToken] / return 三操作（effect 既有声明形态内成员——非新顶层声明）；③`with_resource_stmt` = `"with" "resource" resource_spec block [ "on" "error" handler ] ";"`——作用域资源管理语句糖；④`lifetime_annotation` = `"@" "lifetime" "{" { lifetime_constraint } "}"`——七约束形（acquire_before / release_after / exclusive / shared / no_overlap / must_overlap / linear_flow）可选标注；⑤`lifetime_analysis` = `"analyze" "lifetime" "{" { lifetime_query } "}" ";"`——四查询形（flow of / interference in / elimination candidates / statistics）。

**记法修正（R4 归档顺修）**：语料 `body=block` 属性赋值式非标准 EBNF 记法——本节收编时改写为标准产生式（W3C 记法纪律——原则 44 形式定义义务）；`@lifetime`/`analyze` 为指令/标注层语法（非表达式层）。**二义性预防第 13-14 例**：例 13 `use`/`return` 与既有 `Return` 效应（原创贡献 2——r74 登记）同名张力——`Borrow::return` 限定 effect 声明内部成员位（点分命名空间消歧——22 号件 S3 先例）；例 14 `with` 与 Stage 0 既有 `handle` 块的糖关系（with = handle 的资源特化糖——脱糖目标 with_resource 标准库函数形态即 Doc1 既有函数形态）。**关键字张力与脱糖备选**：新关键字候选 ~7（resource/with/on/analyze/lifetime/exclusive/shared + linear 标注承 v6 张力族）——依 E0020 全域排他经济判据 + r93 P2①先例：**宏层脱糖备选优先**（with resource → with_resource 函数糖 / @lifetime → perform LifecycleConstraint::... 效应糖 / analyze → 工具链指令[10 号件层]）。**环境通道审查**：零通道增量（Acquire/Use/Release 全经既有 ⟨e,ρ,σ,κ,C⟩ 五元组——C 通道已承载资源能力约束）——纯糖层（与 v6 C 通道加性扩展对比：本轮语法扩展不伴随语义环境扩展）。

### 8.11 EBNF v8 类型语法族：unified_type 与观测语法（v7.4 新增——r96 第二十三轮吸收，同步自 stage0.md v8.2 §9.24.5——第七份骨架语料）

> **骨架谱系**：v2 容器[r74]→v3 流形[r83]→v4 逆向[r84]→v5 分层[r88]→v6 能力[r93]→v7 生命周期[r94]→**v8 类型**（七份骨架累积——#15 窗内定稿义务持续累积；Stage 2+ 目标语法 #15 门控维持 + **Stage 3+ 分层门控新增**）。

**unified_type 四形**：static_type（primitive 十五种[含 Never 挂起点/Var 推断中] / adt / function{`->` effect_union + `with` manifold_constraints} / row{fields + `...` rest} / type_variable `'a`）/ **dynamic_type 四形**（superposition_type：`superpose { Return(i64) with 0.7, Error with 0.2 } collapse when cond`——叠加+坍缩 / dependent_type：`refine n : Nat where n > 0`——类型依赖值 / refinement_type：`T refined by expr` / evolution_type：`evolving T under rule from T₀ to T₁`）/ progressive_type（`T progressively refined by { at point refine to T' when cond }`）/ hybrid_type（`hybrid { dim : T } coupled by rule`）。**manifold_constraints 四形**（function_type `with` 子句——类型成员注记位）：topology（sequential/nested/cyclic/arbitrary——三连接公理语法化承 v3）/ geometry（flat/curved(dim)/interference(pair)——干涉语法化承 v4）/ capability（度规约束承 v6）/ lifetime（时间边界承 v7）——**约束作为类型成员的本轮新位**（类型面非表达式面）。**trait 四成员**（效应化 trait 愿景）：trait_method（含效应签名）/ trait_effect（`effect E handled by ...`）/ trait_capability（`requires ...`）/ trait_lifecycle（`lifecycle ...`）——trait/impl 为 Stage 1-2 规划域（14 号件多方案对照既有——不预定）。**观测指令三语法**（observe/project/evolve）= 工具链层归位（同 v7 `analyze lifetime` 处置先例——非语言表达式成员）。

**记法审查**：`?`/`&[mut]` 修饰符与目标语法张力（Stage 2+ 候选 + S-expr 脱糖备选 `?T`→`(Option T)`）；probability 字面量（with 0.7）进类型语法 = Stage 3+ 张力档案。**关键字张力（历次最大轮 ~12+ 两域）**：Stage 1-2 域（trait/impl/row/linear——循 14 号件对照）+ Stage 3+ 域（superpose/collapse/refine/refined/progressively/hybrid/evolving/under/observe/project/evolve/comptime）——E0020 排他经济判据 + 宏层脱糖备选优先（superpose→Superposition 效应糖 / refine→stdlib+where 既有 / hybrid→row 组合）+ **分层门控**：依赖/演化/叠加/渐进四形全族 = Stage 3+ 愿景不入 Stage 2+ 骨架定稿范围。**二义性预防第 15-17 例**：15.`?` 修饰符位形张力；16.`'a` 类型变量与 S-expr 表面张力（脱糖 `'a`→`(TVar a)`）；17.`refine` 双位同名（依赖声明头 vs 细化后缀 refined——位置消歧）。**零环境通道**：⟨e,ρ,σ,κ,C⟩ 五元组维持——类型信息 = 流形对象查询面非新通道（纯注记层——与 v7 零通道同族）。

### 8.12 语法迁移验证与映射表登记（v7.5 新增——r98 第二十四轮吸收，同步自 stage0.md v8.3 §9.25.4——next17.md Document 2）

> **定位**：Stage 2b 切换窗前置设计登记（非当前实施义务——目标语法轮 T3+ 触发式维持，[23 §2.2](./23-evolution-governance.md)）。上游全量权威 = stage0.md §9.25.4（BS-C）；进程面承载 = [07 §4.3](./07-bootstrap-strategy.md)。

- **语法映射表（SyntaxMappingTable）= 皮肤字典显式单源登记位**：S-expr 模式 ↔ 目标语法模式双向规则集（D2 六映射——r158 / 228-c define 行分裂后：函数声明 fn→(define (f x) body) + 顶层值绑定 let→(define name value)[toplevel_let 产生式——被退役 define(NAME, e) 调用形经统一 list 结构合成同一核心形] / let→let[块级] / if→if / perform→perform / handle→handle / lambda→closure）——其中 perform/handle 两映射 = kerf 既有 25 关键字面**零新增**（D2 目标语法示例与 kerf 效应面语法一致——语料侧确认）；lambda→fn 与 E5 S2 腿（r43 已切换）部分重叠——kerf 实况已走渐进路径前半程；**SemanticProof 成员 = 原则 31 的形式化表述位**（每映射附语义等价证明义务——语义漂移防护的设计面闭环）；单源锚 = 本文件（语法面）+ [20 表面规范](./20-surface-conventions.md)（皮肤字典域）——切换窗时以 [22 §12](./22-namespace-design.md) 重筛先例（D19-D33 名空间经济判据）逐映射审定。**双向翻译（target→S-expr 反向）= 验证辅助面裁定**——反向映射非生产路径（切换后 S-expr Reader 删除），仅迁移期差分定位用。
- **双 Reader 等价性验证器（SyntaxTransitionValidator）= parity 纪律的结构化完备形态**（设计登记态）：{old_reader / new_reader / pipeline 三成员 + validate_equivalence 双解析→同管线→字节码全等比较 + SemanticDrift{old_span, new_span, description, suggestion} 四元组诊断}——kerf parity 链既有四段（B3 28 函数[正 87/负 307 逐字节] + E5 九腿 + TD-032 各切口 + HM 16 case）为其分态实例（单语法 oracle parity）；D2 框架 = 双 Reader 并存期的等价性验证泛化——与 [§3 诊断框架](#3-结构化诊断框架-span-代次与恢复协议)（E0005 多错误 + E0021 旧名退役诊断）对齐。
- **语义安全网分层裁定**：「字节码必须完全相同」判据 = 原则 31 进程面硬断言，但**分层适用**——字节级比较限同语法 fixpoint 链（门 B 口径）；跨语法版本比较以 **CoreExpr 全等（原则 31）+ 运行结果等价**为判据（语义安全网不降级也不越级）。三层验证（单元级/程序级/自举级）+ 三阶段构建（A→B→C 链 B==C 字节级 = 门 B fixpoint 传递性扩展）= 切换窗终验协议候选——开窗时与既有门 B 合并为「fixpoint 门二/三阶段双口径」（[11-testing §6](./11-testing.md)）。
- **陷阱 1 语义漂移的架构面防护**（`(if x y z)`→Branch(x,y,z) vs `if x { y } else { z }`→Branch(x,Block(y),Block(z))——Block 插入例）：三重防护 = 原则 31 同构保证（架构面）+ parity 逐字节断言（验证面）+ SemanticProof（设计面）+ 脱糖层纪律（本文件 §8 皮肤/骨架分离——Block 形态若为糖则脱糖后归一）。

### 8.13 EBNF v9 整合定稿位（v7.6 新增——r104 第二十五轮整合定稿，同步自 stage0.md v8.4 §9.26——grammar L2 规范层权威定稿位）

> **本节定位**：用户第二十五轮指令（r104）「将不完整 EBNF 整合……补充缺失最小集合，实现将一个完整目标语言的 EBNF 语法定义」的**规范层交付**——本文件 §8.4 起的 grammar L2 规范层自此持有**完整文法定稿**（v1-v8 八份骨架 + §8.4 Stage 0 事实文法 → v9 统一定稿）。**EBNF 定稿子窗开窗**（M1 指令开窗第十二例——纯文档域）；**切换窗本体维持未开窗**（定稿 = 设计面就位 ≠ Reader 实施——零代码变更；[切换窗就绪度评估 §5.2](../develop/v0/stage-3/surface-syntax-switch-assessment.md) 六步前置清单第 1 步「完整语法规范」**设计面达成**）。整合方法（六整合原则 + 十二整合裁定 C1-C12）与审查裁定（V-A..V-H）全量 = [stage0.md §9.26](../stage0.md)（存档面权威）；本节 = 文法定义本体 + 定稿表（与存档面零漂移单源——EBNF 块逐字节同源）。

**8.13.1 词法层 + Level 0 定稿域**（Stage 2 切换窗首批 Reader 解析规范基线——Rust 最小集补全）：

```ebnf
(* ══════════════════════════════════════════════════════════════ *)
(*  kerf 目标语言 EBNF v9 —— 整合定稿版（r104）                    *)
(*  记法：W3C EBNF（原则 44）   分层：Level 0-4（v5 纪律）         *)
(*  内核：8 原语不变（第九轮验证）  签名：效应容器模型终态          *)
(* ══════════════════════════════════════════════════════════════ *)

(* ---------- 词法层（全层共用——Rust 最小集补全） ---------- *)

program          ::= compilation_unit ;
compilation_unit ::= { module_decl | item } EOF ;

identifier       ::= id_start { id_continue } ;
id_start         ::= letter | "_" ;
id_continue      ::= id_start | digit ;
qualified_name   ::= identifier { "::" identifier } ;
                 (* 目标语法命名空间分隔 = "::"（Rust 借鉴）；S-expr 面 = "/"
                    标识符内分隔（22 §5.1）——双面映射入 9.26.9 皮肤字典锚 *)

literal          ::= integer_literal | float_literal | string_literal
                   | char_literal | boolean_literal | unit_literal ;
integer_literal  ::= dec_int | hex_int | oct_int | bin_int ;
dec_int          ::= digit { "_" | digit } ;
hex_int          ::= "0x" hex_digit { "_" | hex_digit } ;
oct_int          ::= "0o" oct_digit { "_" | oct_digit } ;
bin_int          ::= "0b" bin_digit { "_" | bin_digit } ;
float_literal    ::= dec_int "." digit { "_" | digit } [ float_exp ] ;
float_exp        ::= ( "e" | "E" ) [ "+" | "-" ] dec_int ;
string_literal   ::= '"' { string_char | escape } '"' ;
char_literal     ::= "'" ( char_char | escape ) "'" ;
boolean_literal  ::= "true" | "false" ;
unit_literal     ::= "()" ;                    (* nil ≡ ()——C12 裁定 *)
escape           ::= "\" ( "n" | "t" | "r" | "0" | "\" | '"' | "'" ) ;

comment          ::= line_comment | block_comment ;
line_comment     ::= "//" { char - newline } ;
block_comment    ::= "/*" { char | block_comment } "*/" ;   (* 嵌套——Rust 同型 *)

(* ---------- Level 0：基础语法定稿域（Stage 2 切换窗首批） ---------- *)

(* 顶层与模块 *)
item            ::= fn_decl | type_decl | effect_decl | capability_decl
                  | use_decl | module_decl ;
module_decl     ::= [ visibility ] "module" identifier "{" { item } "}" ;
use_decl        ::= [ visibility ] "use" use_path
                    { "," use_path } ";" ;
use_path        ::= qualified_name [ "::" "{" use_tree { "," use_tree } "}" ]
                  [ "as" identifier ] ;
use_tree        ::= identifier [ "as" identifier ] ;
visibility      ::= "pub" ;
                  (* pub(scope) 粒度 = Stage 2+ 候选登记（9.26.5——K 经济判据窗内裁定） *)

(* 函数——容器模型签名终态 *)
fn_decl         ::= [ visibility ] "fn" identifier [ "<" type_params ">" ]
                    "(" [ params ] ")" [ "->" effect_union ] block ;
                    (* r157/227-b3：返回效应签名 = 剥离实施[consume_effect_union——类型域
                       HM/Level 2，内核剥离]；语料双形实证 fib.ktf 带 / closures.ktf 不带
                       ——实现-文档漂移 E-1 修正[R4 文档随代码] *)
params          ::= param { "," param } ;
param           ::= [ "mut" ] identifier ":" type ;
type_params     ::= type_param { "," type_param } ;
type_param      ::= "'" identifier [ ":" type_bound ] ;
type_bound      ::= type { "+" type } ;         (* 上界合取——Rust 同型 *)

(* 类型声明 *)
type_decl       ::= [ visibility ] ( struct_decl | enum_decl | alias_decl ) ;
struct_decl     ::= "struct" identifier [ "<" type_params ">" ]
                    "{" { field_decl } "}" ;
field_decl      ::= [ visibility ] identifier ":" type "," ;
enum_decl       ::= "enum" identifier [ "<" type_params ">" ]
                    "{" { variant_decl } "}" ;
variant_decl    ::= identifier [ "(" type_list ")" ] "," ;
alias_decl      ::= "type" identifier [ "<" type_params ">" ] "=" type ";" ;

(* 效应声明（含操作与方向修饰） *)
effect_decl     ::= [ visibility ] "effect" identifier [ "(" type_params ")" ]
                    "{" { effect_operation | effect_direction } "}" ;
effect_operation ::= identifier [ "(" [ params ] ")" ] [ "->" type ] "," ;
effect_direction ::= "direction" ( "forward" | "reverse" | "bidirectional" ) "," ;

(* 能力声明（Level 0 面 = 声明 + 门控；操作语法族见 Level 2） *)
capability_decl ::= [ visibility ] "capability" identifier
                    [ "<" type_params ">" ] "{" { cap_member } "}" ;
cap_member      ::= cap_operation | cap_state ;
cap_operation   ::= "fn" identifier "(" [ params ] ")" "->" effect_union ";" ;
cap_state       ::= "state" "{" { state_field } "}" ;
state_field     ::= identifier ":" type [ "=" expr ] "," ;

(* 语句 *)
block           ::= "{" { statement } [ expr ] "}" ;
statement       ::= let_stmt | assign_stmt | expr_stmt
                  | if_stmt | match_stmt
                  | perform_stmt | handle_stmt
                  | macro_invocation ;
let_stmt        ::= "let" [ "mut" ] identifier [ ":" type ] "=" expr ";" ;
assign_stmt     ::= identifier "=" expr ";" ;
if_stmt         ::= "if" expr block [ "else" ( if_stmt | block ) ] ;
match_stmt      ::= "match" expr "{" { match_arm } "}" ;
match_arm       ::= pattern [ "if" expr ] "=>" block "," ;
expr_stmt       ::= expr ";" ;

(* 效应执行与处理（机制面核心） *)
perform_stmt    ::= "perform" effect_ref "(" [ args ] ")" ";" ;
handle_stmt     ::= "handle" expr "{" { handler_arm } "}" ;
handler_arm     ::= effect_pattern "=>" handler_body "," ;
effect_pattern  ::= effect_name [ "(" [ pattern_list ] ")" ] [ "if" expr ] ;
handler_body    ::= "resume" "(" expr ")"       (* 恢复续体——脱糖 (κ v) Apply *)
                  | "halt" [ "(" expr ")" ]     (* 终止流——resume ∈ {0,1} 合围 *)
                  | "pass"                      (* 穿透传播——T-EFFECT-PROPAGATION *)
                  | block ;
effect_ref      ::= qualified_name ;
effect_name     ::= "Return" | "Error" | "Async" | "State" | "Never"
                  | qualified_name ;   (* 内建容器名 + 用户自定义——标识符域非关键字 *)

(* 表达式（优先级层级文法——9.26.4 表的机器面） *)
expr            ::= range_expr ;
range_expr      ::= or_expr [ ".." [ or_expr ] ] ;         (* 区间——for!/切片域 *)
or_expr         ::= and_expr { "||" and_expr } ;           (* 逻辑或——左结合短路 *)
and_expr        ::= comparison_expr { "&&" comparison_expr } ;
comparison_expr ::= bitor_expr [ comp_op bitor_expr ] ;    (* 不链式——例 19 *)
comp_op         ::= "==" | "!=" | "<" | ">" | "<=" | ">=" ;
                  (* r162 / 233 — TD-037 相等域窗语义注记：`==` → (eq a b)、
                     `!=` → (not (eq a b))——跨域结构终名（值域全域化：
                     Pair/Vector 结构相等 + procedural 同一性 + 混合域 false）；
                     ordering 族（< > <= >=）维持 num/str 全序域 *)
bitor_expr      ::= bitxor_expr { "|" bitxor_expr } ;      (* 位或——表达式位 *)
bitxor_expr     ::= bitand_expr { "^" bitand_expr } ;
bitand_expr     ::= shift_expr { "&" shift_expr } ;
shift_expr      ::= arith_expr { ( "<<" | ">>" ) arith_expr } ;
arith_expr      ::= term { ( "+" | "-" ) term } ;
term            ::= unary_expr { ( "*" | "/" | "%" ) unary_expr } ;
unary_expr      ::= [ unary_op ] cast_expr ;
unary_op        ::= "-" | "!" ;                (* Level 0 面；&/*借用糖 = Level 2 *)
cast_expr       ::= postfix_expr [ "as" type ] ;
postfix_expr    ::= primary_expr { postfix_op } ;
postfix_op      ::= "." identifier                             (* 字段访问 *)
                  | "." identifier "(" [ args ] ")"           (* 方法调用 *)
                  | "(" [ args ] ")"                           (* 函数调用——C9 *)
                  | "[" expr "]"                               (* 索引——r163 已实施：as-if-written (vector-ref coll idx) *)
                  | "!" "(" [ macro_args ] ")" ;               (* 宏调用——显式标记 *)
primary_expr    ::= literal | path_expr | "(" expr ")"
                  | closure_expr | struct_lit ;
path_expr       ::= qualified_name [ "::" generic_args ] ;    (* 泛型实例化路径级消歧 *)
closure_expr    ::= [ "move" ] "||" [ "(" [ params ] ")" ]
                    [ "->" effect_union ] block ;             (* || 前缀强制——例 3/18 *)
                    (* r157/227-b3：move 前缀实现位于 parse_unary KwMove 臂[任意 unary 位
                       剥离]——比本产生式更宽松，不破坏所述形态 *)
struct_lit      ::= qualified_name "{" { field_init [ "," ] } "}" ;
field_init      ::= identifier ":" expr | identifier ;        (* 简写形态 *)

(* 宏调用（宏层熟悉语法——十二替代宏的调用面） *)
macro_invocation ::= path_expr "!" "(" [ macro_args ] ")" ";" ;
macro_args      ::= macro_arg { "," macro_arg } ;
macro_arg       ::= expr | identifier "=" expr ;

(* 模式 *)
pattern         ::= or_pattern ;
or_pattern      ::= or_pattern "|" or_pattern | atom_pattern ;  (* match 臂内或模式 *)
atom_pattern    ::= literal_pattern | identifier_pattern
                  | variant_pattern | wildcard_pattern
                  | binding_pattern | tuple_pattern | struct_pattern ;
literal_pattern ::= literal ;
identifier_pattern ::= [ "mut" ] identifier ;                (* 绑定模式——裸标识符 *)
variant_pattern ::= qualified_name [ "(" pattern_list ")" ] ;
wildcard_pattern ::= "_" ;
binding_pattern ::= identifier "@" pattern ;
tuple_pattern   ::= "(" [ pattern { "," pattern } ] ")" ;
struct_pattern  ::= qualified_name "{" { field_pattern [ "," ] } "}" ;
field_pattern   ::= identifier ":" pattern | identifier | "..." ;
pattern_list    ::= pattern { "," pattern } ;

(* 效应容器签名（类型位置——容器模型终态 C2） *)
effect_union    ::= effect_container { "|" effect_container }
                  | type_shorthand ;
type_shorthand  ::= type ;                     (* 裸类型 ≡ Return(type) 糖 *)
effect_container ::= effect_name [ "(" type_list ")" ] | "Never" ;
type_list       ::= type { "," type } ;

(* 类型（Level 0 面 = 静态核——观测理论 Static 域） *)
type            ::= static_type ;
static_type     ::= primitive_type | adt_type | function_type
                  | effect_type | capability_type_ref | type_variable ;
primitive_type  ::= "i8" | "i16" | "i32" | "i64"
                  | "u8" | "u16" | "u32" | "u64"
                  | "f32" | "f64" | "bool" | "char"
                  | "str" | "()" | "Never" ;   (* Never 入列——C7 *)
adt_type        ::= qualified_name [ "<" type_list ">" ] ;
function_type   ::= [ "impl" ] "Fn" "(" [ param_types ] ")"
                    "->" effect_union ;        (* impl = 语境前缀——9.26.5 *)
param_types     ::= type { "," type } ;
effect_type     ::= "effect" qualified_name [ "(" type_list ")" ] ;
capability_type_ref ::= "linear" "(" type_list ")" ;   (* linear = 类型标注非关键字 *)
type_variable   ::= "'" identifier ;           (* HM 类型变量——非 Rust 借用语义 *)
generic_args    ::= "<" type_list ">" ;

(* 约束子句（where——Rust 最小集补全） *)
where_clause    ::= "where" constraint { "," constraint } ;
constraint      ::= type ":" type_bound        (* trait 上界 *)
                  | type "has" effect_union    (* 效应行约束 *)
                  | type "requires" qualified_name ;  (* 能力约束——E0006 类型面 *)
args            ::= expr { "," expr } ;
```

**8.13.1a Level 0 增补位（v7.7——r109 / 179-a 裁定 4：切换窗步③ 首批实施发现的文法缺口补齐）**：

> **缺口根因**：v9 定稿自目标语言蓝图侧编写（use_decl 覆盖**消费面**导入），未覆盖 kerf N1 模块系统（[22 §5/§15](./22-namespace-design.md)）的**生产面**——模块内 `(import a b)`/`(export x y)` 头部（用户可写 s-expr 生产语法、preamble.krf 语料实际消费形）。步③ 语料改写（preamble.ktf 首件）暴露该缺口——语料无法在目标面表达模块头部。按原则 44（新语法成员登记必须附 EBNF 产生式）补齐：

```ebnf
(* ---------- Level 0 增补（r109——N1 模块生产面；语义 = 既有 s-expr *)
(* 模块头部同构，无新语义通道——皮肤字典条目见 20 §14） ---------- *)

module_import    ::= "import" import_item { "," import_item } ";" ;
import_item      ::= import_name [ "as" import_name ] ;
                     (* r130 / 200-b——别名对：符号逐一同构 s-expr 三形态
                        (import mod as alias) [r40 M2 / 22 §8 R-N5]——
                        collect_import_items/rewrite_alias_refs 消费形
                        零变更；零脱糖零新原语[原则 31]；皮肤字典第十映射
                        = 20 §14 v1.22；双侧 Reader 已实施[种子
                        parse_import_decl 别名臂 + 镜像 import-alias-name
                        族] + ktf_import_alias_tests 32 case 门[含双
                        Reader 正典渲染/错误面字节级 parity] *)
import_name      ::= identifier | qualified_name ;
                     (* 路径形仅消费面语义——生产面模块名恒裸标识符
                        （路径形 `kerf::string` 经 E0019 拒绝——
                        注册名单为连字符形单源） *)
module_export    ::= "export" export_name { "," export_name } ";" ;
export_name      ::= identifier | qualified_name ;
                     (* 与 module_decl 体首部共存（头部区：import → export →
                        体形式——与 s-expr (module m (import ...) (export ...)
                        body) 头部扫描序同构）；顶层位 = 依赖前置声明 *)

(* r125 / 195-a——require 能力声明（CLI 双入口窗 E2E 发现的文法缺口：
   E0006 能力门控的声明面在目标面缺位——.ktf 程序无法声明 IO 能力；
   顶层声明家族同族裸名形，逐符号同构 s-expr (require io write)——
   零脱糖零新原语；皮肤字典第八映射 = 20 §14 v1.19） *)

require_decl    ::= "require" cap_name { "," cap_name } ";" ;

(* r158 / 228-c——顶层 let 值绑定（toplevel-let-design.md v1.0 D1： *)
(* S-expr 旧时代 define(NAME, e) 调用形退役后的现代顶层值绑定形—— *)
(* 与 fn/import/export/require 同族[parse_item 分发]；被退役调用形经 *)
(* 统一 list 结构合成的同一核心形 (define name value)——皮肤换、骨架 *)
(* 不变[原则 31]；define(NAME, e) 项位 = fail-closed 现代化诊断[Span *)
(* = define Token 本位——r130 先例]；块位/表达式位 define 维持普通 *)
(* 调用语义[expander define 位拒收域外——诚实边界]；皮肤字典 *)
(* define→fn 行分裂 = 20 §14 同轮） *)

toplevel_let    ::= "let" [ "mut" ] identifier [ ":" type ] "=" expr ";" ;
                    (* mut/类型标注解析后剥离[fn_decl 先例——核心无
                       类型/mut 消费面]；单绑定封顶——逗号多绑定形
                       fail-closed 专用诊断[块级 let_stmt 多绑面维持；
                       与被退役调用形单绑定能力逐位等价——D1 能力
                       等价退役判据]；项位 = 顶层 + module 项位 *)

(* r161 / 231-c——常量声明窗（第十六皮肤映射；语义 = as-if-written *)
(* toplevel_let 孪生 + 最小只读语义闭环——项位 assign 拒收经 Reader *)
(* 顺序 const 集[E0001 读面族——零内核触碰：expander/compiler/HM/VM *)
(* 全链零触及]；设计单源 const-declaration-design.md v1.0/v1.1） *)

toplevel_const ::= "const" identifier [ ":" type ] "=" expr ";" ;
                    (* const mut 矛盾拒收[专用诊断——Span = mut Token
                       本位]；单绑定封顶——toplevel_let 同族对称；项位 =
                       顶层 + module 项位[parse_item 分发]；块位 =
                       domain-out fail-closed[mut 块位臂同构]；绑定性质
                       轴收口：可变[let + assign 面]/只读[const 面]双轴
                       俱备——项位 assign 拒收[Reader 顺序 const 集 +
                       重绑移除{let/fn/macro/module 名——最新绑定胜出} +
                       模块体保存/清空/恢复]；v0 诚实边界：函数体/块内
                       assign 域外[Stage 2+ 类型系统域——D35⑥ 重申] *)

(* r137 / 207-c——TD-026 行① FFI extern 声明族（第十三皮肤映射；语义 = *)
(* 扁平符号空间声明 + 调用位 CALL_EXTERNAL #43 发射——零新原语零通道 *)
(* 零新操作码[r30 冻结四方同步维持]；设计单源 ffi-language-surface- *)
(* design.md v1.0；皮肤字典第十三映射 = 20 §14 v1.28） *)
(* r147 / 217-c：可选声明位别名段 [`as` ident]——extern 符号空间别名窗 *)
(* [设计单源 extern-alias-design.md v1.0 D1：双名分离——underlying = 扁平 *)
(* FFI 空间键[注册/契约/能力/运行表四面恒按 underlying 匹配]，local = *)
(* 源级绑定名[替换语义 D4：别名后 underlying 直写 = E0022]；零机制变更 *)
(* ——IR extern_face (Symbol, Rc<str>) 对的既有分离维度启用] *)

extern_decl     ::= "extern" ident [ "as" ident ] "(" [ kind { "," kind } ] ")" "->" kind ";" ;
kind            ::= "int" | "str" | "ptr" ;
                    (* D1 三词封顶——ExternKind VM 消费子集[CInt/CPointer/
                       Opaque]的语言面同构；CIntSize/PointeeType 精度属
                       宿主注册面。目标面 `()` = 零参 kind 表（词法 Unit
                       双关——parse_typed_params 先例同构）；S-expr 面
                       正典形 (extern name (kind...) kind)。 *)
cap_name        ::= identifier ;
                     (* 顶层前置声明位（E0018 位置纪律 = Stx 层双皮肤共享）；
                        块内/表达式位维持既有 fail-closed *)

(* r138 / 208-c——TD-002 向量值类型（第十四皮肤映射：逗号省略；语义 = *)
(* 双侧脱糖到 (vector ...) 应用形——零 CoreExpr/IR/操作码[原则 9 冻结 *)
(* 维持——match r122 同律]；S-expr 面括号 datum 既有[Stage 0 交付态—— *)
(* 本窗仅翻转展开位两处拒绝]；设计单源 vector-value-design.md v1.0； *)
(* 皮肤字典第十四映射 = 20 §14 v1.29） *)

vector_lit      ::= "[" [ expr { "," expr } ] "]" ;
                    (* 目标面 primary 位受理；r163 / 234-c：postfix `[`
                       索引面开面（第十七皮肤映射——
                       as-if-written (vector-ref coll idx)）——r138 D6
                       位置纪律 superseded，双括号面俱在域；空表 `[]`
                       = 空向量；尾逗号 fail-closed 拒绝（[a, b,]——期望
                       表达式）；映射到
                       S-expr 面空格分隔正典形 [a b c]——符号与结构逐一
                       同构（Stx 树字节级 parity）。值域：Value::Vector +
                       HeapObj::Vector 元素槽位制（D1 不可变 by
                       construction）；渲染 = 括号形可回读（D8）。 *)

(* r160 / 230-c——TD-036 元组表达式形（第十五皮肤映射：as-if-written； *)
(* 语义 = 表达式位二元 pair 构造的现代面——构造⟺解构对称缺口清偿； *)
(* 设计单源 tuple-expression-design.md v1.0；皮肤字典第十五映射 = 20 §14 *)

primary_expr    ::= ... | tuple_expr ;
tuple_expr      ::= "(" expr "," expr ")" ;
                    (* primary 位受理（r138 vector_lit 同族位纪律）；as-if-
                       written cons(a, b)——Reader 直接合成 Stx
                       (cons e₁ e₂)（与调用形产物同构——皮肤换、骨架不
                       变[原则 31]；零脱糖零新原语零 CoreExpr/IR/操作码）；
                      二元封顶（D2 对称纪律——模式位 (p, q) 的 r121 裁定
                       镜像：3+ 元 fail-closed 专用诊断，深层嵌套经显式
                       (a, (b, c))）；单元素 (a) = 纯分组维持 + () =
                       Unit 维持（词法歧义句法位置裁决既有纪律）；尾逗号
                       (a,) fail-closed（r138 vector 同律）；合成 cons 符号
                       Span = ( Token 本位（r158 合成 define 先例——D10）。 *)
```

```ebnf
(* ---------- Level 0 增补（r110——多绑定 let 与表达式位 if；语义 =   *)
(* 既有 s-expr 面同构，无新语义通道——皮肤字典条目见 20 §14） ------- *)

let_stmt        ::= "let" let_binding { "," let_binding } ";" ;
let_binding     ::= [ "mut" ] identifier [ ":" type ] "=" expr ;
                     (* 多绑定 = 平行语义（D61 暂存法链展开同构）——
                        顺序单绑定 let 不等价[字节码 parity 破坏面] *)
primary_expr    ::= ... | if_expr ;
if_expr         ::= "if" expr block [ "else" ( if_expr | block ) ] ;
                     (* if 值形态——表达式位可用（语句位分派不受影响；
                        Rust let x = if c {a} else {b} 同位形） *)
```

> **缺口根因（r110 / 180-a 裁定 2/2b）**：let_stmt 单绑定 vs 自举语料消费（reader.krf 多绑定 let×6——D61 暂存法链 CoreExpr 结构与顺序单绑定不同 → 指令序不同 → 三路字节码全等门不可达）；if 仅语句位 vs list-items 唯一表达式位 if（`(cons (if (= open-k 13) 'vec 'list) ...)`——调用实参位不可表达）。双侧 Reader 已实施（target.rs + target_reader.krf 镜像）+ switch_corpus_parity_tests 10 case 门。


```ebnf
(* ---------- Level 0 增补（r132——handle 多臂 / halt / pass；r136 语义 *)
(* 翻转——多臂 [>=2] → handle-group 组安装核心形式 [Koka 式读法]； *)
(* 单臂维持单臂形零回归；halt = 尾值废弃糖；pass = perform 重发射 *)
(* ——皮肤字典第十二映射族 = 20 §14 v1.27；设计单源 = *)
(* handle-multi-arm-design.md v1.1 §8 D11-D19 [TD-033] ------------- *)

handle_stmt    ::= "handle" expr "{" handler_arm { "," handler_arm } [ "," ] "}" ;
                   (* r143 位域扩展：语句位与表达式位共享一形——primary 位 *)
                   (* 同构分派[r110 表达式位 if / r121 match 值形先例第三例] *)
                   (* ——let 值位/实参位/if 条件位/嵌套 protected 位/group *)
                   (* 位全开放；脱糖产物与语句位逐字节同构——零机制变更； *)
                   (* 块形 protected 维持域外（protected 必须是表达式—— *)
                   (* 语句位同律）；设计单源 handle-expr-position-design.md *)
handler_arm    ::= effect_pattern "=>" handler_body ;
effect_pattern ::= effect_name "(" ident "," ident ")" ;
                   (* 统一两元绑定（r128 k 注入纪律）——pattern_list 泛化 /
                      if 守卫 = 域外触发式（match 模式集成窗信号——D8）；
                      同一 handle 内效应名重复 = fail-closed（D6——嵌套脱糖
                      下后臂静默遮蔽先臂，报错>静默） *)
handler_body   ::= "resume" "(" expr ")"      (* 恢复续体——脱糖 (κ v) 既有 *)
                 | "halt" [ "(" expr ")" ]    (* 终止流——resume ∈ {0,1} 合围 {0} 形 *)
                 | "pass"                     (* 穿透传播——T-EFFECT-PROPAGATION *)
                 | block ;                    (* r128 块体既有 *)
```

> **r132 脱糖映射（202-c）**：`handle e { A(p₁,k₁) => b₁, B(p₂,k₂) => b₂ }` → `(handle A ((p₁k₁) b₁') (handle B ((p₂k₂) b₂') e'))`（先写臂外层——D2/D9；单臂形退化 = r106 v1 逐字节——D1）；`halt` → 尾值 nil / `halt(v)` → 尾值 v（纯糖——T-NO-RESUME 载体）；`pass` → `(perform (cons (quote T) p))`（本臂效应重发射——H 帧 ext1 已清 → 帧扫描越本 handle → 外层传播；外层 resume 自 pass 点续起——re-raise 标准语义）。halt/pass = 目标面本地关键字（resume 同型；S-expr 面零扰动——r129 macro 先例第 2 连；表达式位 fail-closed）。sibling 分歧（先写臂保护后写臂体——非对称）= D3 诚实登记 → TD-033 触发式。同窗 fvo P1 缺陷清偿（compiler.ktf/expr.rs Fn/Handle 臂条件入栈/无条件弹出错配——嵌套同名绑定崩 tail(nil)——Let 臂 r45/D42 shadow-aware 纪律双侧延拓）。

> **r134 域外二项清偿注记（204-b）**：~~成员重命名 `use m::{a as x}` = D3 域外专用诊断~~ → **已受理**（本版 use_tree 产生式增补形——选择列表三元组 `local as renamed` 双侧 Reader + driver 消费链解析 + 替换式运行时注入；设计单源 = [member-rename-design.md](../develop/v0/stage-3/member-rename-design.md) v1.0 D1-D10：归一化方案 B 运行时注入{run_front 注册后附加注入——与限定名注册同构} + E0022 反向锚精确{改名后原 underlying 直写 = 未绑定} + HM A4 Dynamic{renamed ∉ 签名表双侧保守 Dynamic 零误报} + io/prelude 域外 D8 + 同域查重 D7）；~~选择形在 module 头部 = 双侧一致 E0002~~ → **已受理**（r134 D5：expander 头部扫描双侧选择列表受理{成员全符号预检} + driver collect_module_header_imports 共用单点）——原 r131 D3/D6 域外登记行同步翻转（载体 [use-declaration-design.md](../develop/v0/stage-3/use-declaration-design.md) v1.1）。

> **r131 域外注记翻转（201-c）**：~~`use` 声明（命名空间导入——切换窗后续批次）~~ → **已实施**（本版 use_decl 产生式族——双侧 Reader 全族开放；设计单源 = [use-declaration-design.md](../develop/v0/stage-3/use-declaration-design.md) v1.0 D1-D10；多段路径 `kerf::string` 经 E0019 编译期拒绝 = D1 单层裁定执法面——与 import_name 同注记口径；~~成员重命名 `use m::{a as x}` = D3 域外专用诊断~~ → r134 已受理；原登记载体 [switch-window-plan §4](../develop/v0/stage-3/switch-window-plan.md) 行同步清偿）。

```ebnf
(* ---------- Level 0 增补（r131——use 声明 / `::` 导入树；语义 = 既有 *)
(* s-expr 面 import 三形态[全量 r40 M2 / 别名 r130 / 选择 r50 D65] *)
(* 的纯皮肤映射，零新语义通道——皮肤字典第十一映射 = 20 §14 v1.23； *)
(* 设计单源 = use-declaration-design.md v1.0 ------------------------- *)

use_decl        ::= "use" use_path { "," use_path } ";" ;
use_path        ::= use_module [ "::" "{" use_tree { "," use_tree } [ "," ] "}" ]
                    [ "as" use_module ] ;
use_module      ::= identifier | qualified_name ;
                   (* 多段路径 = 词法可写、编译期拒绝（E0019——注册名单
                      连字符形单源；22 §7 单层不嵌套执法面——与
                      import_name 同注记：生产面模块名恒裸标识符域内，
                      路径形经消费面语义收窄） *)
use_tree        ::= identifier [ "as" identifier ] ;
                   (* r134 增补形：成员重命名三元组 `local as renamed`——
                      选择列表平铺三元组（Stx 序 = 消费者序——
                      collect_import_items j 游标 +3 步进）；替换式注入
                      语义（renamed 替换 underlying 平铺注入位——D3）
                      + 运行时绑定注入（globals[renamed] = underlying
                      分派体 Rc 共享——D4）；裸名成员沿袭 r131 基线 *)
                   (* 选择列表成员为裸名或改名三元组（local 名——
                      下划线→连字符载荷映射同模块名规）；花括号内尾
                      逗号可省（臂族先例——match/macro 尾臂逗号同
                      规）；首槽 `as` = 期望成员名既有面（r134 D2） *)
```

> **元素序与位置纪律（D9/D6——r134 增订）**：表面序（braces 后随 as）与 Stx 序（as 对先于选择列表——`(import mod as alias (members))`）不保序——collect_import_items 消费者序为唯一约束。位置 = 顶层 item 位全族 + module 头部位全族（r134 D5：~~选择形在 module 头部 = 双侧一致 E0002~~ 已受理——expander 头部扫描双侧选择列表受理 + driver 共用单点）；块内/表达式位 = E0001 期望表达式族（KwUse 不入块语句分派）。

> **r130 域外注记翻转（200-b）**：~~`as` 别名（`import kerf_string as str;`）= 切换窗后续批次~~ → **已实施**（本版 import_item 别名位产生式——双侧 Reader 名位/名后双位全开；名位 `as` = 别名缺模块名专用诊断「import as 别名须跟在模块名后（缺模块名）」；同窗修复种子/镜像名位 Span 潜伏错位[种子 bump 后位 vs 镜像 as 本位——双侧统一为 as 本位]）。原登记载体 [switch-window-plan §4](../develop/v0/stage-3/switch-window-plan.md) 行同步清偿。

```ebnf
(* ---------- Level 0 增补（r121——match 模式匹配；语义 = 皮肤/骨架同构 *)
(* [原则 31]，零新原语零通道增量——设计单源 = match-design.md v1.1 §2； *)
(* 皮肤字典第七映射 = M-2 实施批同步义务） ------------------------------ *)

match_expr      ::= "match" expr "{" match_arm {match_arm} "}" ;
                   (* 语句位与表达式位同形：块尾 = 表达式值；非块尾 = 语句
                      丢弃值——与 if 同规[r106 D2 块穿线裁定同构；
                      r110 表达式位 if 先例同构分派] *)
match_arm       ::= match_pattern [match_guard] "=>" expr "," ; (* 尾臂逗号可省 *)
match_guard     ::= "if" expr ;
match_pattern   ::= pattern_or ;
pattern_or      ::= pattern_atom { "|" pattern_atom } ;
                   (* or 模式——闭界；Reader 中间形 = (or p q ...) 标记表
                      [r121 裁定——`|` 为保留运算符 Token 无绑定碰撞，
                      序对恒二元列表与 or 标记表长度域不交] *)
pattern_atom    ::= pattern_literal | identifier | "_" | "(" pattern_atom ")"
                   | "(" pattern_atom "," pattern_atom ")" ;
                   (* 二元拆构——右不嵌套[防无限型]；r121 消歧裁定：括号内
                      至多二元、拆构位元素须为原子模式（裸 or 链 fail-closed
                      带括号提示）；括号包裹嵌套按 EBNF 字面合法——嵌套深度
                      帽 8[match-design §1 防御性栈保护] *)
pattern_literal ::= int_literal | float_literal | string_literal
                   | "true" | "false" | "()" ;
```

> **缺口根因（r121 / 191-a）**：match 为 22 定稿词面已登记位（关键字经济——词面零新增），EBNF 产生式此前仅存在于 [match-design.md v1.0 §2](../develop/v0/stage-3/match-design.md)（设计单源），按定稿域边界纪律补入本节（语言面规范锚）后 Reader 解析域开放（种子侧 target.rs 已实施 + match_m1_reader_tests 10 case 门；target_reader.krf 镜像 = M-4 批次，M-1..M-3 为双 Reader 分歧窗——.krf 侧维持域外诊断，分歧窗锚点测试在档）。限定名模式（`a::b`）= 模式位域外（22 §27 对账——fail-closed）。

```ebnf
(* ---------- Level 0 增补（r128——handler 块体 resume 语句；语义 = 既有 *)
(* s-expr 面 (do A (resume k v)) 序列形同构，零新语义通道——皮肤字典 *)
(* D2 handle 映射体域扩展 = 20 §14 v1.20） ----------------------------- *)

handler_body    ::= resume_call | handler_block ;
resume_call     ::= "resume" "(" expr ")" ;
                   (* k 绑定由臂注入——用户永不书写；语句位（后随 ;）与
                      尾位（后随 }）同形；一次性 resume 语句后的语句 =
                      死代码（与 s-expr (do (resume k v) dead) 同构——D9） *)
handler_block   ::= "{" { handler_stmt } "}" ;
handler_stmt    ::= stmt | resume_stmt ;
resume_stmt     ::= "resume" "(" expr ")" [ ";" ] ;
                   (* r133：处理器作用域穿线嵌套块——if 臂块/闭包体/
                      嵌套 handle 臂体内的语句位/尾位全开放（innermost
                      包裹臂 κ 注入——s-expr 词法作用域镜像——D1/D2；
                      嵌套 handle 遮蔽 shadow-aware D3；闭包捕获开放
                      D4；设计单源 nested-resume-design.md v1.0）；
                      表达式位维持域外（D6——实参/条件/let 值/守卫/
                      match 主题与臂体/perform 实参/受护式位 E0001
                      fail-closed）；嵌套 handle 受护式以 κ=nil 解析
                      （D5 诚实边界）；halt/pass 维持臂体直位形（D8）；
                      普通块无处理器作用域 → 既有“期望表达式”错误
                      路径不变 *)
```

> **缺口根因（r128 / 198-b）**：effect_stress.krf 语料翻译（语料族深度化窗 stress 变体批）暴露——S 表达式面 handler 体 `(do (mk 50000) (resume k (+ (tail p) (head p))))` 的「分配后恢复」序列在目标面不可表达（直位 `=> resume(v)` 无语句序列承载）。按原则 44（新语法成员登记必须附 EBNF 产生式）补齐；双侧 Reader 同轮实施（种子 target.rs + 镜像 target_reader.krf——字节级 parity 门在 ktf_stress_corpus_tests）。

> **r133 域外注记翻转（203-c6）**：~~嵌套块（if 臂/闭包体等）内 resume = 登记域外 fail-closed（目标面收窄边界；触发式后续信号）~~ → **已实施**（本版 resume_stmt 作用域注记更新——嵌套块语句位/尾位全开放：双侧 Reader 嵌套穿线[种子 handler_k 字段 save/restore + 镜像 kcell 闭包胞] + **同窗 VM 清偿**[续体恢复的 handler 边界截断——ContinuationValue.boundary——深帧非尾 resume 陈旧 H 执行帧残留清偿] + 语料对 effect_nested_resume.{ktf,krf}[⇒ 540 双面]；设计单源 = [nested-resume-design.md](../develop/v0/stage-3/nested-resume-design.md) v1.0 D1-D10；皮肤字典 D2 体域扩展注记 = [20 §14](./20-surface-conventions.md) v1.25 同轮）。

```ebnf
(* ---------- Level 0 增补（r129——宏定义面；语义 = 既有 s-expr 面 *)
(* (define-syntax NAME (syntax-rules (lits) (pattern template)...)) *)
(* 同构，零新语义通道——皮肤字典第九映射 = 20 §14 v1.21） ------------- *)

macro_decl      ::= "macro" identifier [ "(" [ macro_literals ] ")" ]
                    "{" { macro_arm } "}" ;
macro_literals  ::= identifier { "," identifier } ;
                   (* the syntax-rules literal set — identifiers matched by
                      exact symbol in the pattern position; the empty set
                      "()" may be written (lexes as Unit — the positional
                      disambiguation family) or omitted *)
macro_arm       ::= macro_pattern "=>" macro_template [ "," ] ;
                   (* the trailing comma is optional — the match-arm
                      family convention *)
macro_pattern   ::= "(" [ macro_pat_elem { "," macro_pat_elem } ] ")" ;
                   (* the macro-name head element is Reader-injected (the
                      r128 resume-k injection precedent — the user never
                      writes it); the produced Stx is the exact S-expr-face
                      pattern (NAME elem...) isomorphism *)
macro_pat_elem  ::= identifier | int_literal | float_literal
                   | string_literal | "true" | "false" | "()"
                   | macro_pattern | "..." ;
                   (* the `...` ellipsis identifier — lexed as the ident
                      payload "..." (a three-dot look-ahead before the ".."
                      branch), flowing through the ordinary identifier
                      channels: the S-expr-face symbol isomorphism
                      consumed by macro_sys unchanged *)
macro_template  ::= block | expr ;
                   (* the ordinary target grammar; the call-argument
                      ellipsis absorption is unconditional (face-isomorphic
                      error parity: outside templates `f(a ...)` produces
                      the same Stx `(f a ...)` the S-expr face reads) *)
```

> **缺口根因（r129 / 199-b）**：宏面语料窗（macros.ktf 就位——.ktf 语料族 10 件与 .krf 对齐）暴露——目标语法无宏定义形态则 .ktf 程序无法定义用户宏（第九映射缺位：require 第八映射同族的结构性前置）。按原则 44（新语法成员登记必须附 EBNF 产生式）补齐；双侧 Reader 同轮实施（种子 parse_macro_decl + 镜像 parse-macro-decl——字节级 parity 门在 ktf_macros_corpus_tests）。**同窗 P1 缺陷清偿**：check 恢复模式宏注册丢失（expander 入口加性拆分 reset/continue——r17 潜伏两面共通，详见 199-b worklog）。

**8.13.2 Level 1-4 扩展语法族登记**（脱糖路径优先——非定稿域）：

```ebnf
(* ---------- Level 1：逆向效应语法族（Stage 2+ 登记——脱糖优先） ---------- *)

consume_stmt    ::= "consume" effect_name [ "(" [ args ] ")" ] ";" ;
                  (* 脱糖：perform Receive_E(args)——J-A 裁定逆向 = 使用模式 *)
offer_stmt      ::= "offer" expr "{" { offer_arm } "}" ;
                  (* 脱糖：Handle 服务模式（Offer = Handle 的提供者用法） *)
offer_arm       ::= effect_pattern "=>" offer_body "," ;
offer_body      ::= "rewind" "(" expr ")" | "absorb" | block ;
rewind_stmt     ::= "rewind" "(" expr ")" ;    (* 脱糖：Resume 多播形态 *)
pipeline_expr   ::= expr "|>" ( "consume" effect_name | postfix_expr ) ;
                  (* 管道糖——|> 双字符与 | 位或/效应并集三同形位消歧（例 7） *)
aggregate_stmt  ::= "aggregate" "{" { consume_stmt } "}" "into" offer_stmt ;

(* ---------- Level 2：流形操作语法族（Stage 2+——实现就绪度窗内裁定） ---------- *)

lift_stmt       ::= "lift" expr "as" identifier
                    [ ":" "EffectManifold" "<" type ">" ] ";" ;
project_stmt    ::= "project" expr [ "at" effect_name ] ";" ;
effect_connection ::= "connect" connection_type effect_ref "to" effect_ref "," ;
connection_type ::= "-->" | ">>" | "<->" ;     (* 串联/嵌套/循环——三连接公理语法面 *)

(* ---------- Level 2：生命周期语法族（Stage 2+——脱糖优先，零环境通道） ---------- *)

resource_decl   ::= [ visibility ] "resource" identifier
                    [ "<" type_params ">" ] "{" { resource_operation } "}" ;
resource_operation ::= ( "acquire" | "use" | "release" | "transfer" )
                    "(" [ params ] ")" "->" type "," ;
borrow_decl     ::= [ visibility ] "effect" "Borrow" "{" { borrow_operation } "}" ;
borrow_operation ::= "immutable" "(" resource_ref ")" "->" "BorrowToken" ","
                  | "mutable" "(" resource_ref ")"
                    "->" "linear" "MutBorrowToken" ","
                  | "return" "(" token_ref ")" "->" "()" "," ;
with_resource_stmt ::= "with" "resource" resource_spec block
                    [ "on" "error" handler ] ";" ;
                  (* 脱糖：with_resource 标准库函数（Handle 资源特化糖——例 14） *)
lifetime_annotation ::= "@" "lifetime" "{" { lifetime_constraint } "}" ;
                  (* 脱糖：perform LifecycleConstraint::...（标注→效应糖） *)
lifetime_constraint ::= "acquire_before" identifier
                     | "release_after" identifier
                     | "exclusive" identifier | "shared" identifier
                     | "no_overlap" identifier "," identifier
                     | "must_overlap" identifier "," identifier
                     | "linear_flow" identifier ;
lifetime_analysis ::= "analyze" "lifetime" "{" { lifetime_query } "}" ";" ;
lifetime_query  ::= "flow" "of" resource_ref | "interference" "in" scope_ref
                  | "elimination" "candidates" | "statistics" ;
                  (* analyze = 工具链指令层（10 号件域）——非语言表达式成员 *)

(* ---------- Level 2：能力操作语法族（Stage 2+——全部脱糖优先） ---------- *)

capability_operation ::= [ "on" ] effect_pattern "=>" capability_action "," ;
capability_action ::= "grant" "(" expr ")" | "transfer" "(" expr ")"
                   | "revoke" | "consume" | "derive" identifier
                   | "evolve" block | block ;
capability_metric ::= "metric" "{" { metric_component } "}" ;
metric_component ::= "coefficient" effect_kind "," dimension "=>" expr ","
                  | "connection" effect_kind "," effect_kind
                    "=>" connection_matrix ","
                  | "curvature" "(" effect_kind "," effect_kind ")"
                    "=>" curvature_tensor "," ;
capability_derivation ::= "derive" identifier [ "from" effect_pattern ]
                    [ "when" expr ] block "," ;
grant_stmt       ::= "grant" capability_ref "to" entity_ref
                    [ "with" constraint_list ] ";" ;
transfer_stmt    ::= "transfer" capability_ref "to" entity_ref ";" ;
revoke_stmt      ::= "revoke" capability_ref ";" ;
compose_expr     ::= "compose" "(" capability_list ")" ;
split_expr       ::= "split" "(" capability_ref ")" ;

(* ---------- Level 2：类型扩展（行类型 + trait/impl 候选域——14 号件对照不预定） ---------- *)

row_type         ::= "row" "{" { field_decl } [ "..." identifier ] "}" ;
trait_decl       ::= [ visibility ] "trait" identifier [ "<" type_params ">" ]
                    "{" { trait_member } "}" ;
trait_member     ::= trait_method | trait_effect
                   | trait_capability | trait_lifecycle ;
trait_method     ::= "fn" identifier "(" [ params ] ")" "->" effect_union
                    [ where_clause ] ";" ;
trait_effect     ::= "effect" identifier "handled" "by" qualified_name ";" ;
trait_capability ::= "requires" qualified_name ";" ;
trait_lifecycle  ::= "lifecycle" qualified_name ";" ;
impl_decl        ::= "impl" [ "<" type_params ">" ] trait_ref "for" type
                    "{" { impl_method } "}" ;
impl_method      ::= "fn" identifier "(" [ params ] ")" "->" effect_union block ;
manifold_constraints ::= "{" { manifold_constraint } "}" ;
manifold_constraint ::= "topology" ":" topology_spec
                     | "geometry" ":" geometry_spec
                     | "capability" ":" capability_spec
                     | "lifetime" ":" lifetime_spec ;

(* ---------- Level 3：拓扑查询（Stage 3——分析器配置/pragma 备选优先） ---------- *)

topology_query  ::= "topology" "{" { topology_operation } "}" ;
topology_operation ::= "homology" effect_scope
                    | "curvature" effect_scope
                    | "euler" effect_scope ;
                  (* 脱糖备选：编译器 pass 配置面——零关键字占用（K-D） *)

(* ---------- Level 4：量子结构与动态类型（Stage 3+ 研究性——愿景登记） ---------- *)

interference_pair_decl ::= "interference" identifier "on" resource_ref
                    "{" { handler_pair } "}" ;          (* v4 形态——C6 双登记 *)
interference_type ::= "constructive" | "destructive" | "entangled" | "auto" ;
handler_pair     ::= "(" handler_ref "," handler_ref ")"
                    [ "->" interference_type ] ;
interfere_decl   ::= "interfere" effect_ref "with" effect_ref
                    [ "on" resource_ref ] ";" ;          (* v5 形态——C6 双登记 *)
entangle_decl    ::= "entangle" "{" effect_ref_list "}"
                    [ "rule" entanglement_rule ] ";" ;
entanglement_rule ::= "AllOrNothing" | "Majority" | "Correlated" | identifier ;
superposition_expr ::= "superpose" "{" { effect_path "with" probability } "}"
                    [ "collapse" "when" condition ] ;
measure_stmt     ::= "measure" expr [ "collapse" "to" effect_name ] ";" ;
path_integral_expr ::= "integral" "over" effect_paths
                    [ "weight" weight_fn ] ";" ;
probabilistic_handle ::= "probabilistic" "handle" expr
                    "{" { weighted_arm } "}" ;
weighted_arm     ::= [ probability "=>" ] handler_body "," ;
competitive_offer ::= "competitive" "offer" "{" { offer_with_weight } "}" ;
offer_with_weight ::= [ "weight" expr ":" ] offer_stmt ;

(* 动态类型族（Stage 3+ 愿景——不入 Stage 2+ 定稿域） *)
unified_type     ::= static_type | dynamic_type | progressive_type | hybrid_type ;
dynamic_type     ::= superposition_type | dependent_type
                   | refinement_type | evolution_type ;
superposition_type ::= "superpose" "{" { effect_path "with" probability } "}"
                    [ "collapse" "when" condition ] ;
dependent_type   ::= "refine" identifier ":" type "where" refinement_expr ;
refinement_expr  ::= expr { "&&" expr } { "||" expr } ;
refinement_type  ::= type "refined" "by" refinement_expr ;
evolution_type   ::= "evolving" type "under" evolution_rule
                    [ "from" type "to" type ] ;
progressive_type ::= type "progressively" "refined" "by"
                    "{" { refinement_step } "}" ;
refinement_step  ::= "at" refinement_point "refine" "to" type
                    [ "when" condition ] ;
hybrid_type      ::= "hybrid" "{" { dimension ":" unified_type } "}"
                    [ "coupled" "by" coupling_rule ] ;

(* 观测指令（工具链层归位——同 analyze lifetime 处置） *)
observation_directive ::= ( "observe" | "evolve" ) observation_target
                    [ observation_params ] ";" ;

(* FFI 边界（Stage 3+ 门控——TD-026 dangling 再裁定维持待触发） *)
extern_decl      ::= [ visibility ] "extern" [ string_literal ]
                    "{" { extern_item } "}" ;
extern_item      ::= [ visibility ] "fn" identifier
                    "(" [ params ] ")" "->" type ";" ;
```

**8.13.3 定稿表三件**（全量裁定与消歧档案见 [stage0.md §9.26.4-§9.26.8](../stage0.md)——与本节零漂移）：

- **运算符优先级十四级表**（定稿义务兑现——原 #15 窗内义务）：后缀族（1）→ `as`（2）→ 一元（3）→ 乘除模（4）→ 加减（5）→ 位移（6）→ 位与（7）→ 位异或（8）→ 位或（9）→ **比较不链式**（10）→ 逻辑与（11）→ 逻辑或（12）→ 区间 `..`（13）→ 管道 `|>`（14——Level 1）。层级文法机器面（8.13.1 表达式节产消链）与表格面单源一致——V-C 裁定。
- **关键字分级终态**：`15 全域`（fn/struct/enum/module/let/if/else/match/type/effect/perform/handle/capability/use/pub）+ `4 语境修饰词`（mut/move/as/impl——位形限定不入全域排他面）+ `3 handler 位形词`（resume/halt/pass）= **22 定稿词面**；内建效应容器名六词（Return/Error/Async/State/Never/Timeout——标识符域非关键字）；Level 1-4 候选 ~47 词全部非定稿（脱糖路径在位）。与 Stage 0 实况 25 关键字（symbol.rs）正交分层——R4。
- **二义性 22 例完备消歧**：既有十七例（§8.6-§8.11 链）+ 定稿新增五例（18 逻辑或vs闭包位置消歧 / 19 比较不链式 / 20 `::` 泛型实例化路径级消歧 / 21 结构字面量vs块首token消歧 / 22 一元负词法先行——与 Stage 0 D14 同构）——四策略（位置/字符形态/产消分立/词法裁定）覆盖零隐式歧义。

**8.13.4 与本文件既有节的收敛关系**：§8.4 Stage 0 事实文法（S-expr 面）**维持不动**（实现层正交——R4）；§8.5-§8.11 八份骨架语料 = v9 的**输入档案**（演进链可追溯——单源收敛原则）；§8.12 语法迁移验证的 SyntaxMappingTable/双 Reader 验证器**消费 v9 Level 0 为新语法侧规范输入**（切换窗五步流程第③步基线）；§8.3 表面蓝图与 §8.12 的「#15 门控维持」注记自本轮起精确化为「**定稿已就位于本节——切换窗开窗即消费**」。宏层脱糖路径表（张力族 ~47 候选 → 宏族/pragma/函数糖/效应糖通道）与内核映射表（8 原语不变性第九轮验证——零新增原语零通道增量）全量见 [stage0.md §9.26.7/§9.26.8](../stage0.md)。原则 54 同轮注册（[17-设计原则](./17-principles.md)）。


**8.13.2a 统一流分析语法族登记（v7.10——r115 第十源语料，同步自 stage0.md v8.7 §9.29.3）**：

> **本节定位**：next20.md 统一流分析 EBNF = grammar L2 规范层**第十源语料**——v9 定稿（§8.13）后的第二份增量语料（第九源 = §8.14 信息效应语法族）。**Level 0 定稿域零扰动**（原则 54 定稿域边界纪律——22 定稿词面/优先级表/词法层不变）；全部新语法 = Level 1-4 登记态候选。

- **语法族七件**：lifetime_override（生命周期重写——phase/constraint/interference_rule 三成员：默认推导优先 + 显式重写逃生舱[与 §8.10 v7 lifetime_annotation 分治——标注面逃生舱维持]）/ lifetime_phase（from/to/through 效应模式段）/ lifetime_constraint（must overlap/not_overlap/precede/follow）/ lifetime_interference_rule（borrow_pair => allow/deny/warn/require sequencing）/ flow_analysis_directive（none/basic/intermediate/full/quantum 五级——渐进披露原则 43 分析面实例）/ resource_lifetime_decl（acquire/use/release 三相位——§8.10 resource_decl 相位化扩展）/ 借用语法糖四形（`&expr`/`&mut expr`/`&expr.field`/conditional borrow——**Level 4 皮肤层候选**，目标面承载 = §8.10 borrow_decl 既有）。
- **关键字张力 ~32 候选**（历次第二大张力轮）：lifetime/phase/from/to/through/must/overlap/precede/follow/interference/immutable/mutable/exclusive/shared/allow/deny/warn/require/sequencing/flow/analysis/none/basic/intermediate/full/quantum/resource/acquire/use/release/default/borrow/when/as——**全部 Level 1-4 登记态脱糖优先**；`use` 与 Rust 最小集词面冲突（§8.13 C3 词法补全已含 use）→ **resource_phase 位形限定词**（语境关键字非全域排他——语境消歧义务注记：分析窗开启时兑现）；`mutable/immutable` 与 §8.10 borrow_kind 词面共享——单源归并（§8.10 既有登记为基准）。
- **记法修正五处**（语料缺陷如实登记——R1 桩判断纪律）：interference_action 与 analysis_level 产生式的 W3C 注释缺左括号五处——本节登记形态为修正后正典。
- **操作语义六规则族登记**（stage0.md §9.29.3 全量）：FLOW-SEGMENT-IMMUTABLE/MUTABLE + FLOW-SEGMENT-END（NLL 段结束推导——Polonius 先例 E.29-160）+ INTERFERENCE-DESTRUCTIVE/EXCLUSIVE/DANGLING + LIFETIME-COMPLETENESS/LEAK + PARTIAL-BORROW-OK/CONFLICT + CONCURRENT-FLOW-INTERFERENCE（Stage 3+ 愿景）。

**与本文件既有节的收敛关系**：§8.13 v9 定稿位**维持不动**（定稿域免疫——本节为 Level 1-4 增量登记）；§8.12 SyntaxMappingTable **不消费本节**（登记态语法无皮肤映射义务——借用糖四形 = Level 4 皮肤候选按位形审定结果再定）；§8.5-§8.11 八份骨架档案链**延伸为十源**（v9 定稿前的输入档案 + §8.14/本节 = 定稿后两份增量语料）；§8.10 v7 生命周期语法族 = lifetime_override 的**标注面互补基座**（重写面 vs 标注面分治——默认推导优先 + 显式标注逃生舱）。上游全量 = [stage0.md §9.29.3](../stage0.md)；原则面 = [17 原则 57](./17-principles.md)。

## 8.14 信息效应语法族登记（v7.9 新增——r111 第二十六轮吸收，同步自 stage0.md v8.5 §9.27.4）

> **本节定位**：next18.md 两段 EBNF（编译器侧 info_operation 族 + 用户侧 emit/query/subscribe/handle/filter/pipeline/LSP 族）= grammar L2 规范层**第九源语料**——v9 定稿（§8.13）后的首份增量语料。**Level 0 定稿域零扰动**（原则 54 定稿域边界纪律——22 定稿词面/优先级表/词法层不变）；全部新语法 = Level 1-4 登记态候选。

**语法族登记（三分域归位 INFO-C）**：

| 语法族 | 语料成员 | 归位层 | 脱糖路径 |
|---|---|---|---|
| 用户侧信息效应 | `effect AppLog { debug/info/warning/error/metric }` + `perform AppLog::info(...)` | Level 2（效应应用域） | 零脱糖（effect_decl v9 既有产生式承载） |
| 信息处理语法 | `info handle e { error(e) => report+halt, ... }` | Level 2 | `info handle` → `handle e {...}`（臂内 report/suppress/collect = 标准库函数） |
| 信息产生语法 | `emit Id(args) [with metadata]` / `emit ... when cond` | Level 3 候选 | `emit Log::info(msg)` → `perform Log::info(msg)`；metadata → 载荷字段 |
| 观测/投影指令 | `observe e at errors..full` / `project InfoKind from region onto dim` | Level 4（工具链面） | pragma/CLI 指令形态（TY-D 观测指令归位 r96 先例沿袭） |
| 信息管道 | `stream/filter/map/group/batch` + `\|>` | Level 4/库面 | `xs \|> filter(p)` → `filter(p, xs)`（函数应用糖） |
| LSP/IDE 语法 | `project to LSP {...}` / `ide integration {...}` | 工具链层（不入语言文法） | 原则 44 单向派生——宿主工具配置非 kerf 程序 |

**关键字张力分析**：~20+ 候选词面全部走脱糖/归位路径零入定稿域——emit/query/subscribe/report/suppress/collect/promote/demote/retry（→ 库函数/Handle 臂内表达式——标识符域）；info/hint/debug/severity/category（→ 位形限定词候选——切换窗时随 [22 §12](./22-namespace-design.md) 重筛先例逐条审定）；observe/project/filter/stream（→ 工具链指令/库函数）；`\|>`（→ 函数应用糖——备选方法链/`pipe(x,f)` 函数形零词法冲突）。**E0020 经济判据全域适用沿袭**（全域排他面不扩大）。

**二义性预防新增三例（v9 二十二例之后续——例 23-25）**：例 23（`emit` 位形二义——位形限定消歧[语境词策略 E.26-148]；备选纯标识符路径零新词）；例 24（`info` 双位形——`info handle` 双词前缀整体匹配，单 `info` 恒标识符；备选直接用 `handle` 既有词面）；例 25（`|>` vs `|` 词法邻近——最长匹配优先 + 换形备选）。

**与本文件既有节的收敛关系**：§8.13 v9 定稿位**维持不动**（定稿域免疫——本节为 Level 1-4 增量登记）；§8.12 SyntaxMappingTable **不消费本节**（登记态语法无皮肤映射义务——切换窗后按位形审定结果再定）；§8.5-§8.11 八份骨架档案链**延伸为九源**（v9 定稿前的输入档案 + 本节 = 定稿后首份增量语料）。上游全量 = [stage0.md §9.27.4](../stage0.md)；原则面 = [17 原则 55](./17-principles.md)。

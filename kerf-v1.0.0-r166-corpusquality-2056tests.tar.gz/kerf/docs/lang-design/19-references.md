# 参考案例、代码量估算与参考文献

> **Author**: kerf-doc-agent
> **Date**: 2026-10-30（**v7.15——r117 第二十九轮吸收（next21.md）**：§30 E.30 文献四条——同步自 stage0.md v8.8 附录 E.30）；2026-10-20（**v7.11——r104 第二十五轮整合定稿（EBNF 定稿子窗）**：§26 E.26 文献四条——同步自 stage0.md v8.4 附录 E.26）；2026-10-10（**v7.5——r91 第十九轮吸收（next13.md）**：§20 第十九轮引用增补[E.20 两条 127-128——Hirani DEC 离散外微积分 + Edelsbrunner & Zomorodian 持久同调：K-A 数学工具箱分级裁定双锚]——同步自 stage0.md v7.8 附录 E.20）；2026-10-10（**v7.4——r89 第十八轮吸收（next12.md 追加段）**：§19 第十八轮引用增补[E.19 两条 125-126——O Neill PCG 伪随机源 + Selinger 量子 PL 综述；两项 web-search 实检索证 r89-q1~q2]——同步自 stage0.md 附录 E.19）；2026-10-10（**v7.3——r88 第十七轮吸收（next12.md）**：§18 第十七轮引用增补[E.18 两条 123-124——Mac Lane 范畴论工具箱 + Ramsey&Pfeffer 概率最近邻；两项 web-search 实检索证 r88-q1~q2]——同步自 stage0.md 附录 E.18）；2026-10-09（**v7.2——r84 第十六轮吸收（next11.md）**：§17 文献六条 117-122——语料 §4.2 需补充清单对账[四真实缺口：Wirth/RFC 5234/Damas-Milner/Rémy + 两理论锚：Pretnar 2015/Swierstra 2008] + 六项 web-search 实检索证 r84-q1~q6 存档 tool-results/r84-search/——同步自 stage0.md 附录 E.17）；2026-10-08（**v7.1——r83 第十五轮增量维度收编**：§16 语法定义形式与语法文件体系文献六条[111-116——Ford PEG/W3C XML EBNF/Wheeler ISO 14977 批评/tree-sitter/ANTLR4/Rust 非形式化教训]——六项 web-search 实检索证 r83-q1~q6 存档 tool-results/r83-search/）；2026-10-01（**v7.0——r81 第十四轮吸收（next10.md）**：§15 效应统一模型与目标语言设计文献[Leijen 2014 行多态/Hillerström/OCaml 5 §24/Leroy 2024/Soundly Handling Linearity/Affect 2025/Kobayashi 2025/Becker 2019 错误消息/Castagna 2024/Unison abilities——101-110] + §14 轮次标签 R4 顺修[「第十四轮」→「空间层级同步轮」——与 next 系列计数冲突消除]，六项 web-search 实检索证 tool-results/ 临时目录）；2026-09-24（**v6.9——r66 空间层级同步轮**：§14 核心空间统一规划文献[LLVM CACM SoC / Rust core::marker / ML 模块系统 / 自举阶段体系——97-100] 双侧统一体系与骨架 crate 引证）；2026-09-22（**v6.8——r63 第十三轮吸收**：§13 调试技术与渐进优化文献[GHC -ddump-simpl / Racket macro-debugger / LLVM opt-bisect / MLton 全程序优化——93-96] 双向调试与脚手架拆除判据引证）；2026-09-22（**v6.7——r62 第十二轮吸收**：§12 约束组合代数文献[Birkhoff 格论 / Cook 继承不是子类型 / Pierce TAPL / Reynolds——89-92] + 根空间四条引证）；2026-09-22（**v6.6——r59 第十一轮吸收**：§11 原语独有优化验证文献（GHC Stream Fusion / Koka 效应内联 / MLton 全程序优化——86-88 验证状态引证））；2026-09-17（**v6.5——r58 第十轮吸收**：§10 优化桥接与 IR 正交文献（LLVM Loop Optimization / LLVM Exception Handling / Appel 教材——83-85））；2026-09-17（v6.4——r57 第九轮吸收：§9 编译速度标杆文献（TCC/Zig/Jai——Jai 声明标杆注记）+ §1 案例行增补（TCC/Jai/Zig 增量/Racket SyntaxObject/Unix-LLVM 机制预留历史验证）；2026-09-10（v6.0：next3 讨论引用增补 §5（de Bruijn 1972 / Flanagan 1993 ANF / Plotkin & Pretnar 2009）；v5.5：next2 讨论引用增补 §4（Koka/MLton/Unison/CompCert/Zig comptime——该轮未回写版本号，本版一并修正）；v5.0：源自 stage0.md v5.0 拆分））
> **Version**: v7.15（**r117 第二十九轮吸收——§30 E.30 递归处理与脚手架拆除文献[四条 164-167——检索证存档 tool-results/r117-search/]**）；**r115 第二十八轮吸收——§29 E.29 统一流分析与描述论哲学文献[四条 160-163——同步自 stage0.md v8.7 附录 E.29；检索存档 tool-results/r115-search/]**）；v7.13（**r113 第二十七轮吸收——§28 E.28 流特性理论与观测物理先例文献[四条 155-159——同步自 stage0.md v8.6 附录 E.28；检索存档 tool-results/r113-search/]**）；v7.12（**r111 第二十六轮吸收——§27 E.27 信息效应化与诊断系统文献[四条 149-152——同步自 stage0.md v8.5 E.27；检索存档 tool-results/r111-search/]**)；v7.11（**r104 第二十五轮整合定稿**——§26 E.26 EBNF 整合定稿与文法工程文献[四条——Rust Reference 优先级表/章节化文法体系 + langdev 关键字最小化 + contextual keyword——同步自 stage0.md v8.4 附录 E.26；检索存档 tool-results/r104-search/]）；v7.10（r98 第二十四轮吸收——§25 E.25 自举策略与迁移验证文献四条[141-144——r98-q1~q4 检索存档 tool-results/r98-search/]）；v7.9（r96 第二十三轮吸收——§24 E.24 类型观测文献四条[137-140——r96-q1~q4 检索存档 tool-results/r96-search/]）；v7.8（r95 第二十二轮吸收——§23 第二十二轮引用增补[E.23 四条 133-136——统一分析四锚：Kildall 框架级统一先例/拓扑方法入并发分析前沿/MLGO 工业 ML-编译器/CompCert 形式化基准]）；v7.7（r94 第二十一轮吸收——§22 第二十一轮引用增补[E.22 四条 129-132——生命周期四锚：NLL 复杂度/区域效应先例/效应消除/RAII]）；v7.6（r93 第二十轮吸收——§21 第二十轮引用增补[E.21 四条 125-128——三支柱四锚]）；v7.5（r91 第十九轮吸收——§20 第十九轮引用增补[E.20 两条 127-128——K-A 分级双锚]；v7.4（r89 第十八轮吸收——§19 第十八轮引用增补[E.19 两条 125-126；v7.3（r88 第十七轮吸收——§18 第十七轮引用增补[E.18 两条 123-124；v7.2（r84 第十六轮收编——§17 类型推断基础与效应理论文献六条 117-122[Wirth/RFC 5234/Damas-Milner/Rémy/Pretnar 2015/Swierstra 2008]；v7.1（r83 第十五轮增量维度收编——§16 文献六条 111-116；v7.0（r81 第十四轮吸收（next10.md）——§15 效应统一模型与目标语言设计文献 + §14 轮次标签 R4 顺修；v6.9：r66 空间层级同步轮——§14 核心空间统一规划文献；v6.8：r63 第十三轮吸收——§13 调试技术与渐进优化文献；v6.7：r62 第十二轮吸收——§12 根空间与约束组合代数文献；v6.6：r59 第十一轮吸收——§11；v6.5：r58 第十轮吸收——§10；v6.4：r57 第九轮吸收——§9 速度标杆 + §1 案例行；v6.3：§8 r34 演进治理知识搜索引用增补（四查询实证——74-79 六条：WASI 无环境权威/组件组合安全边界/Rust proc-macro 编译期权威反面教材/Swift resilience 演进治理/ocap 布线/arxiv ocap 许可机制）；v6.2：§7 r33）
> **Status**: Active

> 本文件收录 stage0.md 附录 B（参考案例与关键数据）、附录 C（代码量估算）与附录 E（参考文献、规范与相关链接，按主题分类）。各条目的「文档引用位置」已从 stage0.md 的内部锚点改写为指向本目录对应设计文件的相对链接。术语表与术语源流考见 [18-术语文档](./18-terminology.md)。

---

## 1. 参考案例与关键数据（原附录 B）

| 项目 | 启示 | 关键数据 |
|------|------|---------|
| Racket | 极小核心+卫生宏的完整实践 | 9 个形式；BC→CS 证明核心不变可换后端 |
| Chez Scheme | 从极小核心生长出高性能编译器 | flonum unboxing 显著提升性能 |
| Guix | 357 字节种子构建完整系统 | hex0 → 22,000+ 包 |
| Rust 编译器 | 三阶段自举流水线 | `cfg(bootstrap)` 条件编译 |
| PyPy | 元追踪 JIT 性能数据 | 追踪阶段约 900 倍减速（仅预热期） |
| Julia | femtolisp 到 LLVM JIT | femtolisp 仅用于编译期 |
| C 语言 | 高度自举但有汇编漏洞 | 预处理器非图灵完备 |
| Cone 编译器 | LLVM 后端性能开销 | 前端 800μSec vs 后端 115,500μSec |
| Zig | 自建后端替换 LLVM | 构建时间几乎减半 |
| TCC | 极限编译速度参照（单遍/零优化/直接机器码） | ~1μs/行（~100 万行/秒）；生成码比 GCC -O2 慢 2-5 倍（v6.4） |
| Jai（声明标杆） | 工程精品速度参照（高度并行+增量） | ~10μs/行（~10 万行/秒）——未公开，不可独立复验（v6.4） |
| Zig 增量 | 增量编译速度参照 | 整应用 ~10-50ms（v6.4） |
| Racket SyntaxObject | 「扩展的 S 表达式」工业实证 | datum + scopes + phase + span 四元组；#lang 支持非 S 表面（v6.4） |
| Unix / LLVM | 「机制预留」历史验证（抽象核心+组合扩展） | 文件描述符+read/write 50 年扩展；IR 指令集 20 年扩展（v6.4） |
| QBE | 极简编译后端 | 10% 代码提供 70% 性能 |
| Cranelift | 快速代码生成后端 | 比 LLVM 快约 40% |
| Salsa | 查询式增量计算框架 | 从 rustc 提取 |
| APL/J/K | 数组同像性范式 | 数组作为代码表示 |
| Prolog | 一阶项同像性 | assert/retract 元编程 |
| Forth | 栈与字典范式 | 4 个核心原语（NEXT/DOCOL/EXIT/LIT） |
| MetaOCaml | 多阶段编程类型化 | 良构、良类型、良作用域保证 |
| OCaml 5 | Effect Handlers | 模块化效应处理 |
| Mojo（2026） | Python 语法 + 编译期元编程 | 内存安全模型仍在完善 |
| Gleam | 类型安全 + 可扩展编译器 | 现代 BEAM 语言设计 |
| Esterel | 同步语言信号流图 | 程序编译为有限状态机 |
| MLton | 全程序优化编译器（Standard ML） | ~1x C 效率 + 小体积可执行文件（v5.5 增补，next2） |
| Koka | 行多态效应类型 + 效应消除编译 | 静态消除处理器显著提升性能（v5.5 增补，next2） |
| Unison | 能力（abilities）系统 | 生产级能力模型实践（v5.5 增补，next2） |
| CompCert | 形式化验证编译器 | 唯一经机器辅助证明免误编译的编译器（航空认证）（v5.5 增补，next2） |
| Zig comptime | 编译期求值 | 元编程逻辑与常规代码同语言（v5.5 增补，next2） |

---

## 2. 代码量估算（原附录 C）

```text
Stage 0（约 6500 行）：
  OCaml/Rust 前端（约 5000 行）
  C VM + Runtime + GC（约 1500 行）

Stage 1（约 8000 行，目标语言子集）
Stage 2（约 20000-50000 行，完整目标语言）

[v3.0] Stage 0 接口预留层（约 500-800 行）
  Effect Handlers 类型定义（约 100 行）
  多阶段编程类型定义（约 100 行）
  能力模型 I/O 类型定义（约 100 行）
  编译缓存接口定义（约 100 行）
  Span/诊断/相位分离的辅助类型（约 200-400 行）

Stage 0 合计：约 7,000-7,300 行 = 6,500 行核心实现 + 500-800 行接口预留层
（v3.0 的"约 6500 行"仅指核心实现；v4.0 起将接口预留层计入交付总量，见 [12-路线图 §3.3](./12-roadmap.md) 验证清单）
```

---

## 3. 参考文献、规范与相关链接（原附录 E）

> **本附录提供 v3.0 文档涉及的所有参考文献、规范文档与相关链接，按主题分类组织。** 所有链接已校验（截至 2026 年 9 月），并标注其在拆分后文档集中的引用位置。

### 3.1 自举理论与历史（原 E.1）

#### 3.1.1 关键论文（原 E.1.1）

1. **McCarthy, J. (1960)**. *Recursive Functions of Symbolic Expressions and Their Computation by Machine, Part I*. Communications of the ACM, 3(4), 184-195.
   - LISP 的原始论文，引入元循环求值器
   - 文档引用位置：[00-总览 §4](./00-overview.md)、[14-替代设计 §2.1](./14-design-alternatives.md)、[18-术语文档 §2.1](./18-terminology.md)

2. **Landin, P. J. (1964)**. *The mechanical evaluation of expressions*. Computer Journal, 6(4), 308-320.
   - 引入闭包与 SECD 机器
   - 文档引用位置：[14-替代设计 §2.4](./14-design-alternatives.md)、[18-术语文档 §2.5](./18-terminology.md)

3. **Church, A. (1936)**. *An unsolvable problem of elementary number theory*. American Journal of Mathematics, 58(2), 345-363.
   - λ 演算的奠基论文
   - 文档引用位置：[14-替代设计 §2.3](./14-design-alternatives.md)、[18-术语文档 §2.4](./18-terminology.md)

4. **Quine, W. V. O. (1940)**. *Mathematical Logic*. Harvard University Press.
   - 引入准引用（quasiquotation）概念
   - 文档引用位置：[18-术语文档 §2.4.3](./18-terminology.md)

#### 3.1.2 工程实践（原 E.1.2）

5. **Guix Full-Source Bootstrap**：https://guix.gnu.org/manual/en/html_node/Full_002dSource-Bootstrap.html
   - 357 字节 hex0 种子到 22,000+ 包的完整自举链
   - 文档引用位置：[00-总览 §4.2](./00-overview.md)

6. **Rust Bootstrapping**：https://rustc-dev-guide.rust-lang.org/building/bootstrapping.html
   - Rust 编译器的三阶段自举流水线与 `cfg(bootstrap)` 机制
   - 文档引用位置：[00-总览 §4.1](./00-overview.md)

7. **Racket `racket/kernel`**：https://docs.racket-lang.org/reference/kernel.html
   - 9 个核心原语与卫生宏系统
   - 文档引用位置：[00-总览 §3.1](./00-overview.md)、[00-总览 §4.3](./00-overview.md)

8. **Julia femtolisp**：https://github.com/JuliaLang/julia/tree/master/contrib
   - Julia 语言的引导解析器
   - 文档引用位置：[00-总览 §4.4](./00-overview.md)

### 3.2 同像性与替代设计（原 E.2）

9. **Joel Kuiper: Homoiconicity**：http://joelkuiper.eu/homoiconicity
   - 对同像性的系统分析与批判
   - 文档引用位置：[14-替代设计 §1.2](./14-design-alternatives.md)

10. **Hacker News: Homoiconicity discussion**：https://news.ycombinator.com/item?id=7418055
    - 关于"AST 与数据结构关系"的深度讨论
    - 文档引用位置：[14-替代设计 §1.2](./14-design-alternatives.md)

11. **Stack Overflow: What is homoiconicity?**：https://stackoverflow.com/questions/267862/what-is-homoiconicity
    - 同像性作为"谱系"而非二元属性的讨论
    - 文档引用位置：[14-替代设计 §1.2](./14-design-alternatives.md)

#### 3.2.1 数组语言（原 E.2.1）

12. **APL Wiki**：https://aplwiki.com/
    - APL 语言社区百科
    - 文档引用位置：[14-替代设计 §1.3.1](./14-design-alternatives.md)

13. **J Language**：https://www.jsoftware.com/
    - Iverson 创建的 ASCII 字符 APL 后继
    - 文档引用位置：[14-替代设计 §1.3.1](./14-design-alternatives.md)

14. **K/Q (KX Systems)**：https://kx.com/
    - 商业数组语言，金融领域应用
    - 文档引用位置：[14-替代设计 §1.3.1](./14-design-alternatives.md)

#### 3.2.2 Prolog 与一阶项（原 E.2.2）

15. **SWI-Prolog Documentation**：https://www.swi-prolog.org/pldoc/man?section=manipulate
    - 项操纵与元编程
    - 文档引用位置：[14-替代设计 §1.3.2](./14-design-alternatives.md)

#### 3.2.3 Forth 与栈语言（原 E.2.3）

16. **Forth Standard**：https://forth-standard.org/
    - Forth 200x 标准
    - 文档引用位置：[14-替代设计 §1.3.3](./14-design-alternatives.md)

17. **Jonesforth**：https://github.com/nornagon/jonesforth
    - 可读的 Forth 实现注释
    - 文档引用位置：[04-字节码 VM §1](./04-bytecode-vm.md)

#### 3.2.4 图结构 IR（原 E.2.4）

18. **Cranelift**：https://cranelift.dev/
    - 快速代码生成后端，使用图 IR
    - 文档引用位置：[14-替代设计 §1.3.4](./14-design-alternatives.md)、本文 §1（参考案例与关键数据）

19. **LLVM IR**：https://llvm.org/docs/LangRef.html
    - LLVM 中间表示，图结构 SSA 形式
    - 文档引用位置：[14-替代设计 §1.3.4](./14-design-alternatives.md)

#### 3.2.5 PEG 与文法（原 E.2.5）

20. **LPeg (Lua PEG library)**：http://www.inf.puc-rio.br/~roberto/lpeg/
    - PEG 作为可嵌入"语言"的实践
    - 文档引用位置：[14-替代设计 §1.3.5](./14-design-alternatives.md)

#### 3.2.6 Rust proc-macro（原 E.2.6）

21. **Rust Procedural Macros**：https://doc.rust-lang.org/reference/procedural-macros.html
    - Rust 官方过程宏文档
    - 文档引用位置：[14-替代设计 §1.3.6](./14-design-alternatives.md)、[14-替代设计 §3.2](./14-design-alternatives.md)

22. **`syn` crate**：https://docs.rs/syn/latest/syn/
    - Rust 类型化 AST 解析库
    - 文档引用位置：[14-替代设计 §1.3.6](./14-design-alternatives.md)

#### 3.2.7 MetaOCaml（原 E.2.7）

23. **MetaOCaml (Oleg Kiselyov)**：http://okmij.org/ftp/ML/MetaOCaml.html
    - 多阶段编程的官方资源
    - 文档引用位置：[14-替代设计 §1.3.7](./14-design-alternatives.md)、[14-替代设计 §3.1](./14-design-alternatives.md)

24. **Multi-stage Programming Paper**：Taha, W. (1999). *A sound reduction semantics for untyped CBN multi-stage computation*.
    - 多阶段编程的理论基础
    - 文档引用位置：[14-替代设计 §3.1](./14-design-alternatives.md)

#### 3.2.8 Esterel（原 E.2.8）

25. **Esterel (Gérard Berry)**：https://www-sop.inria.fr/members/Gerard.Berry/Esterel.html
    - 同步语言的创始资源
    - 文档引用位置：[14-替代设计 §1.3.8](./14-design-alternatives.md)

### 3.3 2026 年现代方案（原 E.3）

#### 3.3.1 OCaml 5 Effects（原 E.3.1）

26. **OCaml 5 Effects Manual**：https://v2.ocaml.org/manual/effects.html
    - OCaml 5 效应系统官方文档
    - 文档引用位置：[14-替代设计 §3.4](./14-design-alternatives.md)

27. **Anil Madhavpeddy - Effects for Compiler Pipelines**：https://anil.recoil.org/
    - Anil 关于效应系统应用于编译器管线的研究
    - 文档引用位置：[14-替代设计 §3.1](./14-design-alternatives.md)、[14-替代设计 §3.4](./14-design-alternatives.md)

28. **OCaml Multicore**：https://github.com/ocaml/ocaml
    - OCaml 5 多核与效应系统的源代码
    - 文档引用位置：[13-能力矩阵 §3.1.1](./13-capability-matrix.md)

#### 3.3.2 Mojo 语言（原 E.3.2）

29. **Mojo Documentation**：https://docs.modular.com/mojo/
    - Mojo 语言官方文档
    - 文档引用位置：[14-替代设计 §3.2](./14-design-alternatives.md)、本文 §1（参考案例与关键数据）

30. **Modular Inc.**：https://www.modular.com/
    - Mojo 母公司，Chris Lattner 创立
    - 文档引用位置：[14-替代设计 §3.5](./14-design-alternatives.md)

#### 3.3.3 Gleam（原 E.3.3）

31. **Gleam Language**：https://gleam.run/
    - 类型安全的 BEAM 语言
    - 文档引用位置：[14-替代设计 §3.2](./14-design-alternatives.md)

#### 3.3.4 Capability-based Security（原 E.3.4）

32. **Capability-based Security (Wikipedia)**：https://en.wikipedia.org/wiki/Capability-based_security
    - 能力模型安全机制概览
    - 文档引用位置：[14-替代设计 §3.5](./14-design-alternatives.md)

33. **Capability Myths Demolished**：https://srl.cs.jhu.edu/pubs/SRL2003-02.pdf
    - Mark Miller 等关于能力模型的权威分析
    - 文档引用位置：[14-替代设计 §3.5](./14-design-alternatives.md)

### 3.4 编译器工程实践（原 E.4）

#### 3.4.1 rustc 与 Salsa（原 E.4.1）

34. **rustc Dev Guide**：https://rustc-dev-guide.rust-lang.org/
    - Rust 编译器开发指南，包含查询系统
    - 文档引用位置：[15-架构分层 §3.1](./15-architecture-layers.md)

35. **Salsa Framework**：https://github.com/salsa-rs/salsa
    - 从 rustc 提取的查询式增量计算框架
    - 文档引用位置：[15-架构分层 §3.1](./15-architecture-layers.md)、本文 §1（参考案例与关键数据）

#### 3.4.2 后端（原 E.4.2）

36. **QBE**：https://c9x.me/compile/
    - 极简编译后端，10% 代码提供 70% 性能
    - 文档引用位置：[08-后端演化 §2](./08-backend-evolution.md)、本文 §1（参考案例与关键数据）

37. **Cranelift**：https://cranelift.dev/
    - 快速代码生成后端
    - 文档引用位置：[08-后端演化 §2](./08-backend-evolution.md)、本文 §1（参考案例与关键数据）

38. **LLVM**：https://llvm.org/
    - 工业级编译器基础设施
    - 文档引用位置：[08-后端演化 §1](./08-backend-evolution.md)

#### 3.4.3 信任与安全（原 E.4.3）

39. **Thompson, K. (1984)**. *Reflections on Trusting Trust*. Communications of the ACM, 27(8), 761-763.
    - Trusting Trust 攻击的原始论文
    - 文档引用位置：[00-总览 §3.3](./00-overview.md)、[15-架构分层 §4.1](./15-architecture-layers.md)

40. **Wheeler, D. A. (2009)**. *Fully Countering Trusting Trust through Diverse Double-Compiling*.
    - DDC（多样化双重编译）方法
    - 文档引用位置：[15-架构分层 §4.1](./15-architecture-layers.md)

### 3.5 教学资源（原 E.5）

41. **SICP (Abelson & Sussman)**：https://mitpress.mit.edu/sites/default/files/sicp/index.html
    - 《计算机程序的构造和解释》
    - 文档引用位置：[14-替代设计 §2.1](./14-design-alternatives.md)

42. **EOPL (Essentials of Programming Languages)**：https://eopl3.com/
    - 编程语言本质，元语言抽象章节
    - 文档引用位置：[14-替代设计 §2.1](./14-design-alternatives.md)

43. **Types and Programming Languages (Pierce)**：https://www.cis.upenn.edu/~bcpierce/tapl/
    - 类型系统基础理论
    - 文档引用位置：[06-操作语义](./06-operational-semantics.md)

### 3.6 工具链（原 E.6）

44. **rust-analyzer**：https://rust-analyzer.github.io/
    - LSP 实现参考
    - 文档引用位置：[10-工具链 §1](./10-toolchain.md)

45. **Scribble**：https://docs.racket-lang.org/scribble/
    - Racket 的文档即代码系统
    - 文档引用位置：[09-标准库 §3](./09-stdlib.md)

### 3.7 v3.0 引用的额外资源（v4.0 保留）（原 E.7）

46. **TRAC Language (Mooers)**：https://en.wikipedia.org/wiki/TRAC_(programming_language)
    - 同像性术语的发源语言
    - 文档引用位置：[14-替代设计 §2.2](./14-design-alternatives.md)、[18-术语文档 §2.3](./18-terminology.md)

47. **SECD Machine**：https://en.wikipedia.org/wiki/SECD_machine
    - Landin 的抽象机器
    - 文档引用位置：[14-替代设计 §2.4](./14-design-alternatives.md)、[18-术语文档 §2.5](./18-terminology.md)

48. **Forester 6.0**：https://opentype.us/forester/
    - 使用 OCaml 5 Effects 的实际项目
    - 文档引用位置：[13-能力矩阵 §1.1.1](./13-capability-matrix.md)、[13-能力矩阵 §2.4](./13-capability-matrix.md)

49. **PyPy Meta-tracing JIT**：https://www.pypy.org/
    - 元追踪 JIT 性能数据
    - 文档引用位置：[08-后端演化 §3](./08-backend-evolution.md)、本文 §1（参考案例与关键数据）

50. **Cone Compiler**：https://www.jondgoodwin.com/cone/
    - LLVM 后端性能开销实测数据来源
    - 文档引用位置：[08-后端演化 §1](./08-backend-evolution.md)、本文 §1（参考案例与关键数据）

## 4. next2 讨论引用增补（v5.5 吸收）

- **MLton**：https://mlton.org/ ——全程序优化（ANF + 闭包转换 + SSA）达 ~1x C 的实证；三种闭包表示（Toplevel/Flat/Linked）为本设计 Stage 2 优化锚点
- **Koka**：https://koka-lang.github.io/ ——行多态效应类型 + 类型导向编译（效应消除四阶段：纯函数检测/重排/内联/已知状态消除）
- **Unison**：https://www.unison-lang.org/ ——abilities 能力系统（能力=不可撤销效应的视角）
- **CompCert**：https://compcert.org/ ——形式化验证编译器（Stage 3+ 安全目标参照）
- **Zig comptime**：https://ziglang.org/documentation/master/#comptime ——编译期求值的生产实践（多阶段编程的务实前身）
- **λ○▷ staging 演算**（研究跟踪）——let-splice 绑定机制（Stage 3+ 多阶段复杂度缓解候选）

## 5. next3 讨论引用增补（v6.0 吸收）

- **de Bruijn, N. G. (1972)**. *Lambda calculus notation with nameless dummies*. Indagationes Mathematicae, 34, 381-392. ——de Bruijn 索引原始论文（[01 §7.3](./01-core-forms.md) Stage 1/2 重写评估项的出处）
- **Flanagan, C., Sabry, A., Duba, B. & Felleisen, M. (1993)**. *The Essence of Compiling with Continuations*. PLDI 1993. ——A-范式（ANF）来源论文（[15 §5.2](./15-architecture-layers.md) Stage 2 ANF 层规划的理论出处）
- **Plotkin, G. D. & Pretnar, M. (2009)**. *Handlers of Algebraic Effects*. ESOP 2009. ——代数效应处理程序理论奠基（[14 §4.2](./14-design-alternatives.md) 批判审查史与 [01 §7.3](./01-core-forms.md) 效应原语化的理论锚点）
- 注：Racket `racket/kernel`（8 形式口径）已在 §3.1 第 7 条；Koka/MLton/Unison/CompCert/Zig comptime 已在 §4（v5.5）——next3 第七轮的引用增量仅上列三条

---

## 6. next4 讨论引用增补（v6.1 吸收——第八轮「2026 接口预留完整性审查」）

63. **Language Server Protocol Specification**：https://microsoft.github.io/language-server-protocol/
    - LSP 官方规范（[13-能力矩阵 §3.3.2](./13-capability-matrix.md) LanguageService 的协议生态基础）
    - 文档引用位置：[13-能力矩阵 §3.3.2/§3.4](./13-capability-matrix.md)、[10-工具链 §1](./10-toolchain.md)

64. **DWARF Debugging Standard**：https://dwarfstd.org/
    - 源级调试信息标准（[13-能力矩阵 §3.3.3](./13-capability-matrix.md) DebugInfoGenerator 的目标格式）
    - 文档引用位置：[13-能力矩阵 §3.3.3](./13-capability-matrix.md)

65. **WebAssembly Component Model**：https://component-model.bytecodealliance.org/
    - WASM 组件模型与接口类型（[13-能力矩阵 §3.3.7](./13-capability-matrix.md) WasmBackend 的目标形态）
    - 文档引用位置：[13-能力矩阵 §3.3.7](./13-capability-matrix.md)、[08-后端演化 §2](./08-backend-evolution.md)

（rust-analyzer——LanguageService + QuerySystem 联合实证——已于 §3.6 条目 44 收录，此处不重复。）

---

## 7. r33 能力架构知识搜索引用增补（v6.2 吸收——54-a 轮八查询实证）

> 本轮增补对应 [21-能力架构 §6 前沿对照](./21-capability-architecture.md) 与 [22-命名空间设计 §2.2/§5](./22-namespace-design.md) 的知识搜索依据（tool-results/r33-search/ 八查询存档）。检索时点 2026-09。

66. **Object-Capability Model（Wikipedia / ocaps 教程）**：https://en.wikipedia.org/wiki/Object-capability_model + https://tersesystems.github.io/ocaps/
    - ocap 安全模型（能力 = 可转移的操作权利——「能力是 OCAP 的原语，如同对象之于 OOP」）；kerf L3 授权层与三态模型（[21 §4](./21-capability-architecture.md)）的理论出处
    - 文档引用位置：[21 §1 三义定锚 / §4.1 授权三态](./21-capability-architecture.md)

67. **Pony Reference Capabilities（官方教程）**：https://tutorial.ponylang.io/
    - 变量级 reference capability 系统的完整实例（能力作用于**每次类型使用**而非类型整体）；kerf 不引入的对照锚（原则 26 成熟度匹配裁定——[21 §6](./21-capability-architecture.md)）
    - 文档引用位置：[21 §6 前沿对照表首行](./21-capability-architecture.md)

68. **Austral 语言规范**：https://austral-lang.org/
    - 线性类型 + capability-based security + 强模块绑定的系统语言实例（模块系统与安全模型绑定但分层——kerf 双门分立的参照）；kerf FFI 令牌态（r30 External 线性消费）同型
    - 文档引用位置：[21 §6 / 22 §5.1 net 行](./22-namespace-design.md)

69. **Tratt, L. — Designing Sane Scoping Rules**：https://tratt.net/languages/
    - 作用域规则设计方法论（「作用域规则是语言最深的语义承诺之一」）；kerf R-N1 解析优先序与 R-N2 遮蔽许可表的设计讨论对照
    - 文档引用位置：[22 §3.1/§3.2](./22-namespace-design.md)

70. **When Modules Are Not Just Namespaces（Programming Linguistics）**：https://pling.jondgoodwin.com/
    - 模块（构建单元 + 语义边界）与命名空间（名字管理）的本质区分；kerf `Module` 原语持相位语义（M-L 迁移）与五层命名机制分轴设计的依据
    - 文档引用位置：[21 §6 对照表 / 22 §2.2](./22-namespace-design.md)

71. **Clojure 命名空间文档与风格指南**：https://clojure.org/guides + https://github.com/bbatsov/clojure-style-guide
    - ns = 名字上下文 + var 容器；`project.module` 组织约定；require/refer 冲突显式报错与逃生阀——kerf 非限定 import 冲突裁定（[22 §6](./22-namespace-design.md)）与 `kerf/` 保留域（Clojure `clojure.*` 同型）的家族内现代先例
    - 文档引用位置：[20 §2 对照表 / 22 §2.2/§6/§7](./22-namespace-design.md)

72. **Ante — Why Algebraic Effects?（2025）**：https://antelang.org/
    - 效应表达力与相互组合性的现代论述（「效应彼此组合良好」）；kerf L2 浅处理 + handler 嵌套承载组合性的对照
    - 文档引用位置：[21 §6 效应组合性行 / §2.3 正交判据 J2 依据](./21-capability-architecture.md)

73. **OCaml Stdlib 与 core library 分层（batsov, 2025）**：https://batsov.com/
    - 语言核心（内建类型/异常声明）与 Stdlib（基本操作模块）的双层结构——kerf N1 运算符族永驻（零依赖最小骨架）与 N2 `kerf/<模块>` 树的同型分层
    - 文档引用位置：[21 §6 库核心/Stdlib 分层行 / 22 §3.7 R-N7](./22-namespace-design.md)

（Kernel 语言「一切一等」与 Racket kernel 8 形式对照已在 §3.1/§3.2 收录——[21 §5.5/§6 最小 kernel 行](./21-capability-architecture.md) 复引；langdev.se 遮蔽讨论（q1）与 matklad 模块笔记（q5）为社区讨论源，核心论点已内化于 22 §3.2/§2.2 裁定依据，不单独列条。）

## 8. r34 演进治理知识搜索引用增补（v6.3 吸收——55-a 轮四查询实证）

> 本轮增补对应 [21-能力架构 §4.4/§4.5 新裁定](./21-capability-architecture.md) 与 [23-演进治理 §2/§4](./23-evolution-governance.md) 的知识搜索依据（tool-results/r34-search/ 四查询存档）。检索时点 2026-09。

74. **WASI Security: Capability Model（wasi.dev）**：https://wasi.dev/security.html + https://github.com/WebAssembly/WASI/blob/main/docs/Capabilities.md
    - 「无环境权威」原则：模块/组件零起始访问，能力全部由嵌入者显式授予（link-time vs runtime 两类）；组件模型 = 组合原语（typed interface 声明）
    - kerf 引用：[21 §4.4 授权组合闭包](./21-capability-architecture.md)（入口程序 = 嵌入者、模块 = 组件同构——传递闭包裁定）

75. **WASM Component Model Security Boundaries（systemshardening.com，2026-04）**：https://www.systemshardening.com/
    - 组件组合的安全边界分析（self-contained 模块 + typed interface 组合）；能力泄漏模式
    - kerf 引用：[22 §5.1 矩阵组合面行](./22-namespace-design.md)（模块需求元数据 vs 授权获得的分立）

76. **Rust Internals: Is executing arbitrary code at build time a good idea?（2019）+ Pre-RFC: Sandboxed, deterministic, reproducible Wasm（2023）**：https://internals.rust-lang.org/
    - proc-macro 任意代码执行的编译期安全缺口共识（「非确定性编译期计算绝对不可接受」+ innocent-looking 宏攻击面 + build.rs 侧信道）；2026 收敛方向 = 宏沙箱化/确定性/可复现
    - kerf 引用：[21 §4.5 编译期权威三判据](./21-capability-architecture.md)（反面教材 + 前沿方向双重实证——kerf 从设计起点站对侧）

77. **Swift Library Evolution / Resilience（swift.org forums + swift.gg 汉化，2016-2020）**：https://forums.swift.org/
    - 库演进的兼容性治理（resilience = 演进而维持二进制兼容的特征集）；标准库升级周期以年计的实证（alexgaynor《Standard Libraries and their Discontents》2025 同向）
    - kerf 引用：[23 §2 触发判据表](./23-evolution-governance.md)（演进窗治理 + 生命周期四阶段的跨语言对照）

78. **ocaps: Introducing Capabilities（tersesystems）**：https://tersesystems.github.io/ocaps/
    - ocap 组合 = 「从单一能力开始，通过布线（wiring）构建」——显式布线非环境继承；能力组合的安全模式
    - kerf 引用：[21 §4.4 组合判据行](./21-capability-architecture.md)（授权组合 = 显式布线的 kerf 形态）

79. **Object-Capability as a Means of Permission（arxiv 2026-08）**：https://arxiv.org/
    - ocap 作为许可机制的系统化论证（unforgeable tokens vs ambient identity——混淆代理人问题预防）
    - kerf 引用：[21 §4.1 三态模型](./21-capability-architecture.md)（令牌态的理论基础补强）


## 9. 第九轮引用增补（v6.4 吸收——r57「机制预留与编译速度标杆」，同步自 stage0.md §11.4/附录 E.10）

80. **TCC: Tiny C Compiler（Fabrice Bellard）**：https://bellard.org/tcc/
    - ~1μs/行（~100 万行/秒）极限编译速度的公开标杆；单遍编译/零优化/直接机器码生成——速度/质量权衡的参照下界（生成码比 GCC -O2 慢 2-5 倍）
    - kerf 引用：[08 §4.1](./08-backend-evolution.md)（速度标杆表）

81. **Zig Incremental Compilation（官方文档与博客）**：https://ziglang.org/
    - 整应用增量编译 ~10-50ms 口径；增量编译 + 缓存策略——Stage 2 查询式增量架构（[13 §3.3.5](./13-capability-matrix.md)）的性能形态参照
    - kerf 引用：[08 §4.1](./08-backend-evolution.md)（速度标杆表）

82. **Jai 编译器（Jonathan Blow——声明标杆，未公开发布）**：无公开 URL
    - ~10μs/行（~10 万行/秒）声明值；高度并行 + 精心工程 + 增量——工程精品路线的方向性参照；**注记：专有未发布，数值不可独立复验，仅作方向性标杆（原则 35：先例是佐证不是权威）**
    - kerf 引用：[08 §4.1](./08-backend-evolution.md)（速度标杆表）

> Racket SyntaxObject（datum + scopes + phase + span 四元组——「扩展的 S 表达式」工业实证）与 Unix/LLVM 机制预留历史验证（抽象核心 + 组合扩展——60/50/20 年）随第九轮吸收入档：[02 §8.2](./02-syntax-model.md) / [13 §3.6.4](./13-capability-matrix.md) / [17 原则 37](./17-principles.md)。

## 10. 第十轮引用增补（v6.5 吸收——r58「优化桥接与 IR 正交精简」，同步自 stage0.md 附录 E.11）

83. **LLVM Loop Optimization 文档（LICM / Loop Vectorization / Loop Unrolling / Strength Reduction）**：https://llvm.org/docs/
    - 胖关键字循环优化族的公开权威文档——循环不变量外提 / SIMD 向量化 / 循环展开 / 强度削减；模式识别（循环四特征）等价替换为 phi 循环形式后的接入对象
    - kerf 引用：[08 §5.1](./08-backend-evolution.md)（六阶段优化管线）/ [13 §3.7.2](./13-capability-matrix.md)（模式识别判据表）

84. **LLVM Exception Handling 文档（landingpad / invoke / zero-cost exceptions）**：https://llvm.org/docs/ExceptionHandling.html
    - 零成本异常模型（正常路径零开销）与 landingpad 指令形态——异常模式（三特征）等价替换的目标形式
    - kerf 引用：[13 §3.7.2](./13-capability-matrix.md)（模式识别判据表）/ [08 §5.1](./08-backend-evolution.md)

85. **Appel, A. W. — Modern Compiler Implementation in ML/C/Java（编译器优化教材）**：剑桥大学出版社
    - SSA / ANF / 闭包转换 / 优化 pass 管线的教材级综合参照（ANF 理论出处 Flanagan 1993 已入档 §5——本条为优化管线组织的标准教材面）
    - kerf 引用：[13 §3.7.4](./13-capability-matrix.md)（pass 管线四组）/ [15 §5.2](./15-architecture-layers.md)（四层修正案注记）

> Y 组合子往返（用户 while → Y 展开[01 糖完备性] → 识别回 Loop[13 §3.7] → 替换进 LLVM phi 循环——语义与性能经同一骨架双向打通）与 IR 转换开销量化（5→3 次转换[40% 减] + 遍历 6→3——[08 §5.2](./08-backend-evolution.md)）随第十轮吸收入档。

## 11. 第十一轮引用增补（v6.6 吸收——r59「性能潜力裁定与双轨策略」，同步自 stage0.md 附录 E.12）

86. **GHC Stream Fusion（Coutts, Löh & Ringer — Stream Fusion / GHC 融合优化）**：Haskell Symposium
    - 跨控制流融合（轨道 B 六项之首）的**初步验证**——流的消除规则使相邻遍历融合为单遍；极小原语设计的 Let 链可重组性是该技术在语言级 IR 的推广前提
    - kerf 引用：[13 §3.7.5](./13-capability-matrix.md)（验证状态表）/ [08 §5.4](./08-backend-evolution.md)（三阶段预期轨道 B）

87. **Koka Effect Handlers 与效应内联（Leijen——Koka 官方文档与论文）**：https://koka-lang.github.io/
    - 用户级控制流优化（Handle/Perform 可内联消除调度开销）的**验证中**锚——Koka 四阶段效应消除（[15 §5.2](./15-architecture-layers.md) 既有登记）的优化收益侧生态验证
    - kerf 引用：[13 §3.7.5](./13-capability-matrix.md)（验证状态表）

88. **MLton Whole-Program Optimization（MLton 官方文档）**：https://mlton.org/
    - 全程序优化（轨道 B 六项之末——原语组合完全透明使跨模块分析无遮蔽）的**完整验证**——「保留完整语义信息的编译器」性能上限的历史实证（长期预期[MLton 级全程序优化 > 任何胖关键字语言]的锚）
    - kerf 引用：[13 §3.7.5](./13-capability-matrix.md)（验证状态表）/ [08 §5.4](./08-backend-evolution.md)（长期预期）

> 偏见纠正（性能潜力 vs 开发成熟度的概念区分——[13 §3.7.5](./13-capability-matrix.md)）与轨道 B 六项验证状态分级（原则 26 三级成熟度匹配的优化域投影：生产就绪[MLton] / 早期实践[GHC/Koka/Racket] / 研究前沿[自动并行化/MetaOCaml 部分求值]）随第十一轮吸收入档；「不是重新发明轮子，而是站在轮子之上建造新的交通工具」的哲学定位同锚。

## 12. 第十二轮引用增补（v6.7 吸收——r62「根空间架构与约束组合代数」，同步自 stage0.md 附录 E.13）

89. **Birkhoff, G. — Lattice Theory（格论经典专著）**：American Mathematical Society, Colloquium Publications
    - 空间形成「约束的格」（交/并/偏序——任意两元素唯一交并）的数学理论出处；根空间约束组合代数的格论支柱权威源
    - kerf 引用：[13 §3.8](./13-capability-matrix.md)（空间关系的数学本质）

90. **Cook, W. R., Hill, W. & Canning, P. — Inheritance Is Not Subtyping（继承不是子类型）**：POPL 1990
    - 「OO 继承 [IS-A 名义子类型 + 实现耦合] ≠ 子类型 [约束满足]」的经典论文——「约束特化 vs 类继承」本质区分的直接学术对照（[14 §4.8](./14-design-alternatives.md) 否决登记的判据依据）
    - kerf 引用：[13 §3.8](./13-capability-matrix.md)（继承 vs 约束组合五维对比）

91. **Pierce, B. C. — Types and Programming Languages（类型系统教材）**：MIT Press
    - 结构子类型 / 约束合取（intersection types 与 bounded quantification）的教材级综合参照——`子空间 = 根约束 ∩ 附加约束` 的类型论表述基础
    - kerf 引用：[13 §3.8](./13-capability-matrix.md)（形式化）

92. **Reynolds, J. C. — Theories of Programming Languages（程序语言理论）**：Cambridge University Press
    - 集合论语义与约束系统的形式化方法权威——「实例 = 满足约束的具体值」的形式语义基础
    - kerf 引用：[13 §3.8](./13-capability-matrix.md)（实例归属）

> 根空间架构（统一管理所有拓展 / 预留空间而非点 / 编译器-拓展对称性）与约束组合代数（约束特化 + 格 + `trait A: B` = 约束加强 A ⊆ B）随第十二轮吸收入档（[13 §3.8](./13-capability-matrix.md) + [17 原则 40](./17-principles.md) + [18 §5g](./18-terminology.md)）；「不是继承形式的，是集合和组合——具备数学原理去解释」的用户裁定为表述口径权威源。

## 13. 第十三轮引用增补（v6.8 吸收——r63「双向调试策略与脚手架哲学」，同步自 stage0.md 附录 E.14）

> 参照口径 = 官方工具文档与系统级优化实证（工具文档类引证——与 §7/§8 知识搜索引用同口径）。检索时点 2026-09（next9.md 第十三轮讨论）。

93. **GHC Users Guide — Core dump passes（-ddump-simpl 等核心转换输出）**：Glasgow Haskell Compiler 官方文档
    - 「一次性 dump 中间结果、不可交互」的现有技术形态对照——[11 §5](./11-testing.md) 四技术对比表中 GHC 行的权威源；GHC 简化器（simplifier）的 pass 输出机制
    - kerf 引用：[11 §5](./11-testing.md)（双向调试 vs 现有调试技术） + [13 §3.9](./13-capability-matrix.md)（五级视图对照）

94. **Racket macro-debugger（宏调试器文档）**：Racket 官方包文档（macro-debugger collection）
    - 「显示宏展开的树但不显示等价物」的现有技术形态对照——[11 §5](./11-testing.md) 四技术对比表中 Racket 行的权威源；展开步骤导航与展开历史
    - kerf 引用：[11 §5](./11-testing.md)（双向调试 vs 现有调试技术） + [13 §3.9](./13-capability-matrix.md)（五级视图对照）

95. **LLVM opt-bisect 文档（优化 pass 逐个启停检查）**：LLVM 官方文档
    - 「逐个 pass 检查但只在 LLVM 层不在语言层」的现有技术形态对照——[11 §5](./11-testing.md) 四技术对比表中 LLVM 行的权威源；pass 级 bisect 机制（与 [§3.5 优化管线类推](#35-优先级策略与预留原则)的 pass 粒度操作面）
    - kerf 引用：[11 §5](./11-testing.md)（双向调试 vs 现有调试技术） + [13 §3.9](./13-capability-matrix.md)（五级视图对照）

96. **Weeks, N. & Tarditi, D. — MLton 全程序优化实证（Whole-Program Optimization in MLton）**：MLton 工作报告
    - 「原语优化最终超越胖关键字上限可行」的工程实证——脚手架拆除判据（自建替代 ≥ 被替换物 × 98%）风险表「原语优化无法超越胖关键字」行的缓解证据（MLton/GHC 已验证可行）；全程序分析释放小核心语言全部优化潜力的先例（与 [§11 原语独有优化验证文献](#11-第十一轮引用增补v66-吸收r59性能潜力裁定与双轨策略同步自-stage0md-附录-e12) 88 条 MLton 行同源——本条为拆除判据视角的复引）
    - kerf 引用：[13 §3.9](./13-capability-matrix.md)（脚手架拆除判据） + [17 原则 41](./17-principles.md)（脚手架哲学统一纪律）

> 双向调试策略（五级视图交互切换——同一模式识别器服务优化与调试）与脚手架哲学（三种脚手架统一生命周期 + 拆除判据 ≥98%/额外能力 + 可回滚）随第十三轮吸收入档（[11 §5](./11-testing.md) + [13 §3.9](./13-capability-matrix.md) + [12 §2.11](./12-roadmap.md) + [17 原则 41](./17-principles.md) + [18 §5h](./18-terminology.md)）；「先把一组等价的原语组合替换为胖关键字进行宏调试，需要细节再反向拆解」的用户洞察为双向视图切换的方案源。

## 14. 空间层级同步轮引用增补（v6.9 吸收——r66「核心空间统一规划与双侧统一体系」，知识搜索四查询实证 tool-results/r66-search/；**轮次标签 R4 顺修 r81**：本节为同步轮非 next 系列吸收轮——原「第十四轮」标签与 stage0.md F 附录 next 系列计数冲突，改名消除）

> 参照口径 = 编译器工业组织与 PL 理论文献（r66 四查询——与 §12/§13 同口径）。检索时点 2026-09（r66/122-a 深化轮）。

97. **Lattner, C. & Adve, V. — The LLVM Compiler Infrastructure（CACM 文章）**：Communications of the ACM
    - 「基于对关注点分离原则的强遵守（strong adherence to the principle of Separation of Concerns）的灵活 pass 管线与整体编译器架构」——**核心空间也按关注点正交划分的工业佐证**（LLVM 库族[IR/Pass/CodeGen/Support] = 编译器核心的正交域划分 30 年实践；SoC 不因「是自举部件」而豁免）
    - kerf 引用：[24 §2.4 q1](./24-space-decomposition.md)（核心域划分工业正例）

98. **Rust 标准库 — core::marker 模块（marker trait 家族的物理家）**：rust-lang/rust 仓库 library/core/src/marker.rs
    - 「Primitive traits and types representing basic properties of types」——marker trait 家族（Send/Sync/Sized）定义于**最底层零依赖 crate**——kerf-space 骨架 crate 的直接同型（骨架 marker 居依赖图根部使全树可达零环）
    - kerf 引用：[24 §5.4](./24-space-decomposition.md)（kerf-space 先例）

99. **Dreyer, D. et al. — ML 模块系统研究（Understanding and Evolving the ML Module System / A Mixin' Up the ML Module System）**：CMU CSD / MPI-SWS 论文
    - ML modules 的层级命名空间管理 + 数据抽象 + functor 的 imports/exports 语义——分层模块系统的学术传统（空间层级 = ML 模块分层的现代变体：域 = module、从属 = 签名匹配；「同一模块语言适用于核心库与用户库」= 双侧统一治理的学术先声）
    - kerf 引用：[24 §2.4 q3](./24-space-decomposition.md)（双侧统一治理佐证）

100. **GCC/Rust Bootstrap 阶段体系（self-hosting stage 0/1/2 文档）**：GCC Internals / rustc-dev-guide
    - stage 0（环境/最小编译器）→ stage 1（bootstrap 编译器）→ stage 2（完整编译器）；bootstrap 与 self-hosted 编译器**保持同步、特性实现两次、同一体系治理**——核心（bootstrap 部件）与拓展（self-hosted 生态）统一体系的工程正例（「特性实现两次」佐证核心/拓展成员分离）
    - kerf 引用：[24 §2.4 q4](./24-space-decomposition.md)（核心-拓展统一体系佐证）

> 双侧统一体系（核心空间显式化 + 统一编码分流治理 + A6/A7 公理 + kerf-space 骨架 crate）随 r66 空间层级同步轮入档（[24 v2.0 全文](./24-space-decomposition.md) + [13 §3.8 v6.10](./13-capability-matrix.md) + [17 原则 40 v7.3](./17-principles.md) + [18 §5i](./18-terminology.md)）；用户指令「是否应该对编译器内部核心空间也做划分并整体统一规划，不独特，显示处理」为本轮驱动源。

## 15. 第十四轮引用增补（v7.0 吸收——r81「目标语言设计蓝图与错误统一效应模型」，next10.md 两段引证；同步自 stage0.md 附录 E.15——检索时点 2026-10，六项 web-search 实检索证）

101. **Leijen, D. — Koka: Programming with Row-polymorphic Effect Types（MSR TR，2014）**：arxiv / microsoft.com
    - 行多态效应类型的权威源——EffectRow 的重复标签行多态机制（统一五面「同一类型系统」的数学基础）
    - kerf 引用：[17 原则 42](./17-principles.md) + stage0.md §9.15.2

102. **Hillerström, D. — Liberating Effects with Rows and Handlers（Edinburgh，2016/2017）**：homepages.inf.ed.ac.uk
    - 「可扩展效应与 handler 的抽象基础恰是行多态」——效应处理器值级组合（分治的组合性）的理论支撑
    - kerf 引用：[17 原则 42](./17-principles.md) + stage0.md §9.15.2

103. **OCaml 5 Manual §24 — Effect Handlers**：ocaml.org 官方手册
    - 「效应 handler 是异常 handler 的泛化——可恢复异常/轻量线程/生成器」——「异常 = 效应的退化形态」的工业实证（替代表的官方口径）
    - kerf 引用：stage0.md §9.15.1/§9.15.4

104. **Leroy, X. — The practice of effects: from exceptions to effect handlers（2024）**：xavierleroy.org
    - 「从异常到效应 handler」同主题先例——可重启异常（restartable exceptions）+ 定界续体（效应统一模型非理论实验而有主流语言实践的对照锚）
    - kerf 引用：[17 原则 42](./17-principles.md) + stage0.md §9.15

105. **Soundly Handling Linearity（PACMPL）**：dl.acm.org
    - 线性类型与 multi-shot handler 的可靠组合——continuation 线性使用的安全条件（one-shot 纪律的文献锚）
    - kerf 引用：[17 原则 42](./17-principles.md) + stage0.md §9.15.6③

106. **Van Rooij, O. et al. — Affect: An Affine Type and Effect System（2025）**：robbertkrebbers.nl / iris-project.org
    - one-shot vs multi-shot 的深远后果——多射低效且禁止标准优化；仿射类型系统保护方案（替代设计登记——Stage 2+ 实现窗裁定候选）
    - kerf 引用：[17 原则 42](./17-principles.md) + stage0.md §9.15.6③

107. **Kobayashi, K. — Expressive Power of One-Shot Control Operators（arXiv，2025）**：arxiv
    - one-shot 控制算子表达力的数学比较（效应 handler/定界续体等算子谱系——安全默认的表达力代价裁定锚）
    - kerf 引用：stage0.md §9.15.6③

108. **Becker, B. A. et al. — Compiler Error Messages Considered Unhelpful（2019，引 320+）**：dl.acm.org / amirkamil.com
    - 编译器错误消息研究综述——「信息系统（错误消息）」设计研究的实证基准（编译期诊断面的研究现状锚——诊断呈现受原则 16 管辖）
    - kerf 引用：stage0.md §9.15.6①

109. **Castagna, G. et al. — Polymorphic Records for Dynamic Languages（2024/2025）**：arxiv / imdea.org
    - 集合论类型系统中记录的行多态（union/intersection/negation）——行类型/交叉类型（类型系统成员）的理论前沿锚（Stage 2+ 登记态判据）
    - kerf 引用：stage0.md §9.14.2

110. **Unison — Abilities（官方文档）**：unison-lang.org
    - 能力式效应（abilities = algebraic effects 的 Unison 实现）——效应与能力系统协同的工业先例（资源定位与控制流定位的协同面）
    - kerf 引用：stage0.md §9.14.1

> 错误统一效应模型（统一而分治 + 值级/效应级对偶 + one-shot 纪律）与目标语言设计蓝图（六维身份定位 + 渐进披露）随第十四轮吸收入档（[17 原则 42/43 v7.4](./17-principles.md) + [18 §5j v7.8](./18-terminology.md) + stage0.md v7.3 §9.14/§9.15）；用户论题「异常流和正常流都是属于流的一种……他们应该是统一而分治的」+ 第十四轮五链指令为本轮驱动源。

## 16. 第十五轮引用增补（v7.1 吸收——r83「语法定义形式与语法文件体系」增量维度引证；同步自 stage0.md 附录 E.16——检索时点 2026-10，六项 web-search 实检索证 r83-q1~q6，存档 [tool-results/r83-search/](../tool-results/r83-search/)）

111. **Ford, B. — Parsing Expression Grammars / Packrat Parsing（2004）**：bford.info/packrat
    - 解析表达文法原始文献——有序选择 + 前瞻断言的解析形式体系；PEG 无歧义性是解析性质非定义性质（裁定 G-B 理论根据）；Stage 2+ Reader 实现参考锚
    - kerf 引用：stage0.md §9.16.2/§9.16.6 + [02 §8.4](./02-syntax-model.md)（web-search 实检索证 r83-q3）

112. **W3C — Extensible Markup Language (XML) 1.0 (Fifth Edition) §6 Notation（2008）**：w3.org/TR/xml
    - W3C EBNF 记法先例——规范级文法 30 年工业实证（XML/CSS/XPath 规范族）；「well-formedness 约束」附产生式后的同构形态（kerf 产生式后附语义/诊断锚注释）
    - kerf 引用：stage0.md §9.16.2 + [02 §8.4](./02-syntax-model.md)（web-search 实检索证 r83-q2）

113. **Wheeler, D. A. — Don't Use ISO/IEC 14977 Extended Backus-Naur Form（2019）**：dwheeler.com
    - ISO EBNF 记法批评锚——`[], {}` 记法歧义史 + 标准文本流传性问题；否决 ISO 14977 为登记记法的判据锚（判据先于先例——[17 原则 35](./17-principles.md)）
    - kerf 引用：stage0.md §9.16.2/§9.16.6（web-search 实检索证 r83-q1）

114. **tree-sitter — Grammar Files / Incremental Parsing / Error Recovery（官方文档与社区实践）**：tree-sitter.github.io
    - 增量解析 + history-based 错误恢复的容错文法体系（IDE 面事实标准）；L4 工具层定位——容错文法与规范文法分离（错误恢复策略不进规范层）；从 EBNF 规范层单向派生义务
    - kerf 引用：stage0.md §9.16.2/§9.16.5 + [02 §8.4](./02-syntax-model.md)（web-search 实检索证 r83-q4）

115. **Parr, T. et al. — ANTLR v4: All(*) Parser Generator（2014）**：antlr.org
    - 自适应 LL 预测 + 左递归消解的生成器生态——生成器路线否决锚（裁定 G-C：语法生成器永不入自举链——LLVM 同构纪律）；外围语法校验器可评估（Stage 2+ 工具窗）
    - kerf 引用：stage0.md §9.16.2（web-search 实检索证 r83-q5）

116. **Rust 社区 — Grammar of Rust 验证尝试（2016-持续）**：internals.rust-lang.org 线程 + createlang.rs 教程
    - Rust reference 长期散文式文法的持续代价实证（社区文法验证尝试多年未合入——文法与实现漂移）；G1-G3 缺漏严重性的反面锚证——语法定义缺形式化载体 = 长期漂移债；grammar 单源的制度价值
    - kerf 引用：stage0.md §9.16.6（web-search 实检索证 r83-q6）

> 语法定义形式与语法文件体系（EBNF 体系组织模型 + W3C EBNF 记法裁定 + 定义/解析分离 + grammar 四层组织）随第十五轮增量维度入档（[17 原则 44 v7.5](./17-principles.md) + [02 §8.4 v6.7](./02-syntax-model.md) + [18 §5k v7.9](./18-terminology.md) + stage0.md v7.4 §9.16）；用户新维度指令「目标语言的语法定义形式和语法文件描述与……系统化体系组织模型（间）设计(EBNF,...)」为本轮驱动源。注意：kerf 引用编号在 stage0.md 附录 E.16 为 107-112，本文件续 19 编号体系为 111-116（两编号体系并存——本文件 §15/§16 为 19 侧独立计数，与 stage0 附录 E 侧计数平行，引用时以「19 §16-111」/「stage0 E.16-107」双锚形态消歧）。

## 17. 第十六轮引用增补（v7.2 吸收——r84「效应本体论与目标语言极简设计」，next11.md 九段引证；同步自 stage0.md 附录 E.17——检索时点 2026-10，六项 web-search 实检索证 r84-q1~q6，存档 [tool-results/r84-search/](../tool-results/r84-search/)）

> next11.md §4.2「需要补充的知识引用」对账补齐——四项真实缺口（Wirth/RFC 5234/Damas-Milner/Rémy：语料列「需补充」而 kerf 19 库确无）+ 两项理论锚增补（Pretnar 2015/Swierstra 2008：效应三部曲解释框架锚）。Plotkin&Pretnar 2009 / CompCert / Leijen 2014 经对账**已在库**（v5.5 §5 / §3.1 / §15-101）——语料自评与库实况的差异以实况为准（R4）。注意：kerf 引用编号在 stage0.md 附录 E.17 为 113-118，本文件续 19 编号体系为 117-122（两编号体系并存——沿 §15/§16 双锚形态消歧）。

117. **Wirth, N. (1977)**. *What can we do about the unnecessary diversity of notation for syntactic definitions?* Communications of the ACM 20(11), 822-823
    - EBNF 创世文献——记法多样性问题的最早系统回应；与 §16-113 Wheeler ISO 14977 批评构成「Wirth 原始意图 vs ISO 标准化漂移」批判链（G-A 裁定的历史纵深锚）
    - kerf 引用：stage0.md §9.17.1/E.17-113（web-search 实检索证 r84-q1）

118. **Crocker, D. & Overell, P. (2008)**. *RFC 5234: Augmented BNF for Syntax Specifications: ABNF*（IETF STD 68，datatracker.ietf.org）
    - IETF 协议语法事实标准记法（RFC 生态 30+ 年工业实证）——与 W3C EBNF 并列的规范级记法先例；五体系对照（stage0 §9.16.2）的广度补充
    - kerf 引用：stage0.md §9.17.1/E.17-114（web-search 实检索证 r84-q2）

119. **Damas, L. & Milner, R. (1982)**. *Principal type-schemes for functional programs*. POPL '82（被引 2100+）
    - Algorithm W 类型推断奠基——Stage 2+ 类型推断算法基础的学术锚（HM → 效应行多态扩展推理链起点）
    - kerf 引用：stage0.md §9.17.7/E.17-115（web-search 实检索证 r84-q3）

120. **Rémy, D. (1992/1994)**. *Typing record concatenation for free*（POPL'92）/ *Type inference for records in a simple presence-absence logic*
    - 行多态理论奠基（记录开放行推断）——与 §15-101 Leijen 2014（行多态效应扩展）构成「记录行 → 效应行」完整理论谱系；容器式签名 `{..E}` 行多态组成的原始锚
    - kerf 引用：stage0.md §9.17.3/E.17-116（web-search 实检索证 r84-q4）

121. **Pretnar, M. (2015)**. *An Introduction to Algebraic Effects and Handlers*. Invited tutorial paper（eff-lang.org PDF / ScienceDirect）
    - 代数效应与 handler 最清晰教学综述——效应生命周期三部曲（构造→投影→后续）解释框架的学术对应锚；「机制先行理论后解释」教学策略参照系
    - kerf 引用：stage0.md §9.17.4/§9.17.5/E.17-117（web-search 实检索证 r84-q5）

122. **Swierstra, W. (2008)**. *Data types à la carte*. Journal of Functional Programming 18(4)（Functional Pearl）
    - Free Monad 结构与组件化数据类型的经典表述——容器模型「Free Monad 变体」理论映射（Effect = Action × Mechanism × Payload × Continuation 的单子理论参照）与范畴论对象登记的形式化锚
    - kerf 引用：stage0.md §9.17.4/E.17-118（web-search 实检索证 r84-q6）

> 效应本体论与目标语言极简设计（三部曲 + 17 关键字 + 容器式签名 + 二义性三策略 + SpaceContract）随第十六轮入档（[17 原则 45 v7.6](./17-principles.md) + [02 §8.5 v6.8](./02-syntax-model.md) + [05 §7 v6.5](./05-runtime.md) + [06 §9 v6.5](./06-operational-semantics.md) + [13 §3.11 v6.12](./13-capability-matrix.md) + [24 §14 v2.2](./24-space-decomposition.md) + [18 §5l v7.10](./18-terminology.md) + [22 §20 v2.7](./22-namespace-design.md) + [20 §12 增记 v1.9](./20-surface-conventions.md) + stage0.md v7.5 §9.17）；用户第十六轮讨论 next11.md 九段为本轮驱动源。

## 18. 第十七轮引用增补（v7.3 吸收——r88「效应流形理论与形式化完备」，next12.md 六轮引证；同步自 stage0.md 附录 E.18——检索时点 2026-10，两项 web-search 实检索证 r88-q1~q2，存档 [tool-results/r88-search/](../tool-results/r88-search/)）

> **对账口径**：next12 语料自审「需要补充的文献」——效应容器语法（Unison abilities）与行多态（Rémy）已在库（§15-110 / E.17-116）；「概率类型理论/效应生命周期/效应流形」语料自认无直接文献（原创理论）。本节补齐**数学工具箱两层最近邻锚**（范畴论通用工具 + 概率语义最近邻——原创性维持的检索对账）。

123. **Mac Lane, S. (1971/1998 2nd ed.)**. *Categories for the Working Mathematician*. Graduate Texts in Mathematics 5, Springer
    - 范畴论标准教科书（被引 21000+）——函子/伴随/极限/余极限的权威定义源；流形理论范畴论定位（流形 = 范畴[对象 = 效应/态射 = 连接]、降维 = 函子 F: C→Set、升维 = 伴随近似[自由结构]、切片 = 极限/余极限）的通用数学基础锚——「Monad ⊂ Free ⊂ EffectManifold」层次链的范畴论谱系源头
    - kerf 引用：stage0.md §9.18.3/E.18-119（web-search 实检索证 r88-q1）

124. **Ramsey, N. & Pfeffer, A. (2001)**. *Stochastic Lambda Calculus and Monads of Probability Distributions*. POPL 2001（最佳论文奖）
    - 概率语义的最近邻锚（被引 295+）——随机 λ 演算 + 概率分布单子；「概率域」隐喻的数学谱系（分布单子为概率建模的标准范畴工具）；语料「概率类型理论——无人直接对应」的诚实对账：概率工具箱存在/效应-概率直接桥接无先例/**原创性维持**（「概率域」为效应域的概率性隐喻而非概率语义实例——[22 §21](./22-namespace-design.md) 术语消歧联动）
    - kerf 引用：stage0.md §9.18.8/E.18-120（web-search 实检索证 r88-q2）

## 19. 第十八轮引用增补（v7.4 吸收——r89「逆向效应流与计算干涉」，next12.md 追加段引证；同步自 stage0.md 附录 E.19——检索时点 2026-10，两项 web-search 实检索证 r89-q1~q2，存档 [tool-results/r89-search/](../tool-results/r89-search/)）

> next12.md 追加段两理论面的最近邻锚对账——伪随机坍缩的 Randomness 效应实现层（Pcg32——语料指定算法族的权威源）与「层次 2 计算量子」预留方向的领域综述锚（量子编程语言谱系——「统一经典与量子计算的框架」扩展主张的现有领域边界；E.18 两条口径同构：工具箱存在 / 直接桥接无先例 / 原创性维持）。

125. **O'Neill, M.E. (2014)**. *PCG: A Family of Simple Fast Space-Efficient Statistically Good Algorithms for Generating Random Numbers*. Harvey Mudd College Technical Report HMC-CS-2014-0905
    - 伪随机数生成器 PCG 族权威源（cs.hmc.edu TR PDF + pcg-random.org 域 + Semantic Scholar 三源检索命中）——Randomness 效应实现层 Pcg32 的算法族出处（permuted congruential generator：LCG 状态转移 + 输出置换函数两正交组件——统计质量与速度/空间效率兼得）；伪随机坍缩「种子确定性生成」可重现性主张（测试模式固定种子）的算法基础锚
    - kerf 引用：stage0.md §9.19.6/E.19-121（web-search 实检索证 r89-q1）；[05 §9](./05-runtime.md) Randomness 效应登记

126. **Selinger, P. (2004)**. *A Brief Survey of Quantum Programming Languages*. Electronic Notes in Theoretical Computer Science 90, 21-42（QPL 2003 workshop 综述）
    - 量子编程语言领域综述权威源（mathstat.dal.ca 作者页 + ResearchGate 检索命中）——「层次 2 计算量子」预留方向的现有领域边界锚（量子 λ 演算 / QPL / QCL / qGCL 谱系——经典-量子分立类型系统 + 幺正变换 + 测量坍缩的标准约束集）；语料「统一经典与量子计算的框架——目前没有语言做到这一点」扩展主张的诚实对账：量子 PL 工具箱存在（本条）/效应理论-量子 PL 直接桥接无先例（检索对账零命中）/原创性维持（与 §18 Ramsey&Pfeffer 概率单子先例口径同构——[22 §22] 量子术语族隐喻裁定联动）
    - kerf 引用：stage0.md §9.19.5/§9.19.8/E.19-122（web-search 实检索证 r89-q2）

## 20. 第十九轮引用增补（v7.5 吸收——r91「数学工具箱与波粒二象性」，next13.md 引证；同步自 stage0.md 附录 E.20——检索时点 2026-10，两项 web-search 实检索证 r91-q1~q2，存档 [tool-results/r91-search/](../tool-results/r91-search/)）

127. **Hirani, A.N. (2003)**. *Discrete Exterior Calculus*. PhD Thesis, California Institute of Technology
    - 离散外微积分（DEC）奠基作（Caltech thesis 仓储 + IPAM 讲稿 + Semantic Scholar/Scispace/arXiv[math/0508341 Desbrun 等] 多源检索命中——被引 700+）——K-A 第二级裁定「微分几何工具 = 离散化对应物登记」的数学工具箱存在性锚：Whitney 形式基/离散微分形式/单纯复形上离散外微分算子 d（保持 d∘d=0 与 Stokes 定理离散精确版）
    - kerf 引用：stage0.md §9.20.2/E.20-123（web-search 实检索证 r91-q1）

128. **Edelsbrunner, H. & Zomorodian, A. (2002)**. *Computing Persistent Homology*. Discrete & Computational Geometry 28(4), 511-533
    - 持久同调算法权威源（geometry.stanford.edu 全文 + NSF PAR + Semantic Scholar 多源检索命中——被引 2900+）——K-A 第一级裁定「组合拓扑工具 = 精确同构可用」的算法族锚：同调群计算（H₀/H₁/H₂）在单纯复形/图上的可计算性基础（EffectGraph 拓扑分析 Pass C 素材——死锁检测/并行化/同伦等价的算法路径）
    - kerf 引用：stage0.md §9.20.2/E.20-124（web-search 实检索证 r91-q2）

---

## 21. 第二十轮引用增补（v7.6 吸收——r93「能力模型内禀几何」，next14.md 引证；同步自 stage0.md 附录 E.21——检索时点 2026-10，四项 web-search 实检索证 r93-q1~q4，存档 [tool-results/r93-search/](../tool-results/r93-search/)）

125. **Borretti, A. (2022)**. *Introducing Austral: A Systems Language with Linear Types*. austral-lang.org / borretti.me
    - 纯线性类型系统语言（use-once 编译期强制 + 能力安全 + 状态机式协议强制）——CAP-A 支柱一「Austral 更纯粹的线性类型」验证锚（生态小诚实锚确认）
    - kerf 引用：stage0.md §9.21.2/E.21-125（web-search 实检索证 r93-q1）

126. **Unison (2024)**. *Abilities and Ability Handlers*. unison-lang.org 官方文档
    - abilities 系统 = 能力效应融合生产实践（类型系统强制程序只能使用声明能力范围内的操作）——CAP-A 支柱三验证锚
    - kerf 引用：stage0.md §9.21.2/E.21-126（web-search 实检索证 r93-q2）

127. **Tahara, T. et al. (2018)**. *Asymptotic stability of a modified Lotka-Volterra model*. PMC（cited by 92）
    - 修改 LV 系统渐近稳定性研究——耦合方程收敛性数学先例（CAP-E 挑战三「收敛性 = 数学难题登记」的背景锚）
    - kerf 引用：stage0.md §9.21.6/E.21-127（web-search 实检索证 r93-q3）

128. **Wikipedia / tersesystems / ACIG (2022)**. *Object-capability model*. 多源
    - OCap 三公理多源验证（不可伪造引用——tersesystems 为语料 Doc1 直接引用源；capability = transferable and unforgeable token[ACIG 2022]）——CAP-A 支柱二验证锚
    - kerf 引用：stage0.md §9.21.2/E.21-128（web-search 实检索证 r93-q4）

## 22. 第二十一轮引用增补（v7.7 吸收——r94「生命周期效应化与四模型协同」，next15.md 引证；同步自 stage0.md 附录 E.22——检索时点 2026-10，四项 web-search 实检索证 r94-q1~q4，存档 [tool-results/r94-search/](../tool-results/r94-search/)）

129. **Matsakis, N. D. et al. (2017)**. *RFC 2094: Non-Lexical Lifetimes*. rust-lang.github.io（+ Polonius 后续实验）
    - Rust 借用检查器 NLL 演进 RFC——借用检查器工程复杂度锚（NLL 2018 落地 + Polonius 实验重写——语料「Rust 团队 10+ 年」对账物证；效应化方案复用效应分析管线的替代路径论证依据）
    - kerf 引用：stage0.md §9.22.2/E.22-129（web-search 实检索证 r94-q1）

130. **Tofte, M. & Talpin, J. (1997)**. *Region-Based Memory Management*. Information and Computation 132(2)（+ *Typed Memory Management via Static Capabilities* 变体）
    - **效应驱动生命周期的学术先例**——ML 区域推断把内存生命周期（区域分配/释放）作为效应系统处理（存储效应分析驱动区域生命周期）——「生命周期=效应」主张的最近学术同构（1994-1997，早于语料 30 年的同一洞察；静态能力变体与能力系统亦有结构交集）
    - kerf 引用：stage0.md §9.22.2/§9.22.5/E.22-130（web-search 实检索证 r94-q2）

131. **Hillerström, D. & Lindley, S. et al.**. *Efficient Compilation of Algebraic Effect Handlers*. ACM（+ Koka v3 github.com/koka-lang/koka）
    - 代数效应处理器高效编译技术（效应消除/内联/多射优化）——LC-B「Koka 效应消除迁移到生命周期」技术源锚（编译期确定性 → 运行时检查消除）
    - kerf 引用：stage0.md §9.22.3/E.22-131（web-search 实检索证 r94-q3）

132. **Microsoft Learn / C++ Community (2023)**. *Object lifetime and resource management (RAII)*. learn.microsoft.com（多源）
    - RAII 确定性资源释放模式多源锚（构造获取/析构释放作用域绑定——C++ 工业实践 30+ 年）——with_resource「Return/Error 双臂 RAII 释放」语义对照面（RAII 类型系统绑定 → Handle 作用域语义的等价性论证依据）
    - kerf 引用：stage0.md §9.22.2/E.22-132（web-search 实检索证 r94-q4）

## 23. 第二十二轮引用增补（v7.8 吸收——r95「流形统一分析」，next15.md Document 4 引证；同步自 stage0.md 附录 E.23——检索时点 2026-10，四项 web-search 实检索证 r95-q1~q4，存档 [tool-results/r95-search/](../tool-results/r95-search/)）

133. **Kildall, G. A. (1973)**. *A Unified Approach to Global Program Optimization*. POPL '73（+ Wikipedia Data-flow analysis / Khedker *Data Flow Analysis* Monotone Frameworks 章 / LLVM Clang DataFlowAnalysisIntro——后裔多源）
    - 统一分析框架的经典先例——格上单调框架将多种数据流分析统一为同一数学框架（不动点计算）——「分析的统一」思想 50 年源流锚：统一发生在框架级（抽象解释/格论），kerf 流形统一分析主张发生在结构级（拓扑+几何+代数多工具单对象）——先例弱锚定位（q1 检索确认无「流形级统一分析」工业先例）
    - kerf 引用：stage0.md §9.23.1/E.23-133（web-search 实检索证 r95-q1）

134. **并发程序拓扑分析前沿（2025）**. *The Singularity Theory of Concurrent Programs*. arXiv（2025-10）+ **Myers, A. & Muir, R. (2019)**. *Persistent homology of complex networks for dynamic state summarization*. Phys. Rev. E（引 150+）+ K. Pêtre (2025) persistent homology cycle detection 学位论文
    - 拓扑方法入并发/程序分析的活跃研究证据——H₁ 同调循环检测（persistent homology 工具生态成熟）+ 并发程序验证拓扑范式（奇点理论 2025）——MU-C「H₀/H₁ = 图算法数学上溯 + 表述增益」研究前沿锚；「非主流工业实践」定位同时确认（愿景层 Stage 3 研究项位维持）
    - kerf 引用：stage0.md §9.23.4/E.23-134（web-search 实检索证 r95-q2）

135. **Trofin, M. et al. (2021)**. *MLGO: a Machine Learning Guided Compiler*. arXiv 2101.04808（引 124+；+ LLVM MLGO 官方文档 + google/ml-compiler-opt GitHub + PyPI ml-compiler-opt）
    - ML 系统性集成入工业编译器管线的实证——LLVM 内 inlining 与 regalloc 两启发式经 ML 模型替换的生产级框架——MU-A 优势⑨「AI/ML 自然接口」工业可行性锚；差异化分辨：MLGO 输入 = 特征向量，kerf 愿景 = 流形结构作为 GNN 输入（GNN-on-manifold 无先例——Level 5 远见登记依据）
    - kerf 引用：stage0.md §9.23.2/E.23-135（web-search 实检索证 r95-q3）

136. **Leroy, X. et al. (2006-2026)**. *The CompCert verified compiler*. compcert.org（+ Cornell CS6120 课程评注 + HAL TCC 2022 信任计算基分析）
    - 形式化验证的工业级基准——C 编译器全管线 Coq 机器检验证明（~42,000 行 Coq，76% 为正确性证明——逐 pass 翻译验证方法论）——MU-A 优势⑧基准锚与对照面：CompCert 为逐 pass 分别验证，「一个流形理论→所有分析的形式化」为 kerf 愿景级宣称（前置依赖 = 流形理论自身先形式化——远窗登记依据）
    - kerf 引用：stage0.md §9.23.2/§9.23.3/E.23-136（web-search 实检索证 r95-q4）

### §24 E.24 类型观测与约束求解/行多态/线性谱系文献（v7.9 新增——r96 第二十三轮引证，同步自 stage0.md v8.2 附录 E.24）

137. **Siek, J. G. & Taha, W. (2006)**. *Gradual Typing for Functional Languages*. Scheme Workshop / Siek, J. G. et al. (2015). *Refined Criteria for Gradual Typing*. DROPS（引 257+）
    - 静态/动态类型统一的工程范式先例（渐进类型——「何时检查」问题）——TY-B 静/动统一（观测模式二分——「类型是什么」问题）的相邻领域先例弱锚 + TypeCoupling::Progressive 术语近缘注记
    - kerf 引用：stage0.md §9.24.3/E.24-137（web-search 实检索证 r96-q1）

138. **Leijen, D. (2014)**. *Koka: Programming with Row-Polymorphic Effect Types*. arXiv/Microsoft Research（引 256+）+ Lindley, S. & Cheney, J. (2012). *Row-based Effect Types for Database Integration*（引 90+）
    - 行多态效应行的工业级先例（行多态 + 类型与效应自动推断）——EffectUnion 行变量统一算法的成熟路径确认（E.19/E.22 Koka 锚的推断算法面深化）
    - kerf 引用：stage0.md §9.24.2/§9.24.7/E.24-138（web-search 实检索证 r96-q2）

139. **Rust 社区线性谱系多源（2019-2024）**. without.boats「Ownership」/ Lobsters「Fatal Flaw of Ownership Semantics」/ verdagon.dev「Vale 线性类型」/ borretti.me「Type Systems for Memory Safety」
    - Rust = affine（允许不使用）非 linear（恰好消耗）的精确认辨多源——Linearity 四级谱系 = Rust 二级泛化的谱系归位依据（linear 位由 kerf 线性能力消耗语义承载）
    - kerf 引用：stage0.md §9.24.2/E.24-139（web-search 实检索证 r96-q3）

140. **Sulzmann, M. et al. (2001/2008)**. *A General Type Inference Framework for Hindley/Milner Style Systems* / *HM(X) Type Inference is CLP(X) Solving*（引 33+/29+）+ Heeren, B. et al. (2002)（引 48+）
    - 约束生成/求解分离的成熟范式（HM[X] = CLP[X] 结构同构）——流形约束求解 = HM[X] 约束域扩展叙事非新数学的分辨裁定依据
    - kerf 引用：stage0.md §9.24.4/E.24-140（web-search 实检索证 r96-q4）

### §25 E.25 自举策略与迁移验证文献（v7.10 新增——r98 第二十四轮引证，同步自 stage0.md v8.3 附录 E.25；检索时点 2026-10，四项 web-search 实检索证 r98-q1~q4，存档 [tool-results/r98-search/](../tool-results/r98-search/)）

141. **Thompson, K. (1984)**. *Reflections on Trusting Trust*. Communications of the ACM 27(8)——图灵奖演讲（+ cesarsotovalero.net 2023 重访 + YouTube 2024 讲解——多源复核）
    - 供应链安全的奠基文献——编译器后门自复制机制（源码审计不足信论证）——D1「供应链安全（trusting trust 对抗）」的原始出处；kerf 承接裁定（缩短信任链三机制）的对抗对象锚
    - kerf 引用：stage0.md §9.25.6/E.25-141（web-search 实检索证 r98-q1）

142. **Nieuwenhuizen, J. et al. (2023)**. *The Full-Source Bootstrap: Building from source all the way down*. GNU Guix 官方博客 + bootstrappable.org（GNU Mes 项目）
    - 全源自举的工程实证——357 字节 hex0 种子 → stage0 → M2-Planet → mescc → tinycc → gcc 全链可审计自举——D1「Guix 式全源自举」的技术载体；kerf 裁定 = 远期理论对照非计划项
    - kerf 引用：stage0.md §9.25.2/§9.25.6/E.25-142（web-search 实检索证 r98-q2）

143. **Keep, A. W. (2012)**. *A Nanopass Framework for Commercial Quality Compilers*（引 62+；Chez Scheme 2016 开源——InfoQ 报道）
    - 完全自举 + 高性能的先例锚——Chez = 自举且最快 Scheme 实现之一；同时构成 D1「VM 性能可能下降 2-10x」的反例登记（完全自举性能风险 = 工程可控项非必然）
    - kerf 引用：stage0.md §9.25.6/E.25-143（web-search 实检索证 r98-q3）

144. **Yang, X., Chen, Y., Eide, E. & Regehr, J. (2011)**. *Finding and Understanding Bugs in C Compilers*. PLDI 2011（Csmith——随机正确 C 程序生成 + 跨编译器 differential testing，三年数百编译器 bug）
    - 等价性测试/差分测试的学术先例——「不同实现对同一语义应产出一致结果」的编译器正确性方法论——D2 同结果测试框架与 kerf parity 纪律的方法论对账锚（parity = differential testing 在「自举 oracle ↔ 自举实现」二元组的单源化形态）
    - kerf 引用：stage0.md §9.25.4/E.25-144（web-search 实检索证 r98-q4）

### §26 E.26 EBNF 整合定稿与文法工程文献（v7.11 新增——r104 第二十五轮引证，同步自 stage0.md v8.4 附录 E.26；检索时点 2026-10，三查询 web-search 实检索证 r104-q1~q3，存档 [tool-results/r104-search/](../tool-results/r104-search/)）

- **145. The Rust Reference（Expressions 章）**——doc.rust-lang.org/reference/expressions.html：运算符优先级与结合律工业级权威表（v9 十四级优先级表借鉴源——「层级文法机器面 + 表格面单源一致」= V-C 裁定的工业先例；MIT 镜像 + rust-lang/reference GitHub[#398 文法可视化议题]佐证持续维护性）。
- **146. The Rust Reference（章节化文法摘要体系）**——词法/表达式/语句/项/模式/类型分章文法摘要 + 交叉引用——kerf grammar 四层组织模型（02 §8.4）+ v9 分层与 Rust 章节化体系同向；Rust 非形式化教训（E.16-136 既有锚）反向印证形式化单源必要性。
- **147. langdev.stackexchange「最小化关键字数量的理由」讨论**——关键字最小化论据（保留字标识符占用 + 认知负担）vs 反论据（复杂度转移）；v9 关键字分级终态（15 全域 + 位形限定词）= 中间路线实例——「宏层熟悉语法 + 极简原语域」双层为正解非补丁（原则 43 + 十二替代表）。
- **148. Wikipedia「Reserved word」词条**——保留字三分法（关键词/保留字/语境敏感词）跨语言对照；v9 语境修饰词（mut/move/as/impl）= contextual keyword 策略自觉应用（Rust 2018 edition `dyn`/`async` 语境化先例同族）；E0020 全域禁绑与目标域语境词**双轨制**为跨表面纪律。

## 27. E.27 信息效应化与诊断系统文献（v7.12 新增——r111 第二十六轮引证）

> **检索存档**：tool-results/r111-search/（q1-q4——四查询实检索证）。**引用原则**：本轮为信息系统设计吸收轮——锚定编译器诊断工业先例 / LSP 投影协议权威 / 错误恢复策略谱系 / 效应承载信息的前沿共识。

- **149. rustc-dev-guide「Diagnostic and subdiagnostic structs」**——Diagnostic/Subdiagnostic 两 trait + derive 宏体系：诊断以结构化数据（span/severity/children/建议）承载、渲染后置；rust-lang/rust Issue #722（DiagnosticBuilder Overhaul，2024-02）佐证持续演进。**对齐**：kerf §8.7 结构化诊断（rustc 风格既有）与 INFO-E「机制 = 值通道 + 渲染外置」裁定同构——「信息作为数据 + 渲染器职责」的工业实证。
- **150. Language Server Protocol Specification 3.18（Diagnostics 章）**——microsoft.github.io：Diagnostic 结构 + DiagnosticSeverity 四级（Error/Warning/Information/Hint）+ publishDiagnostics 推送语义。**对齐**：kerf 五级渐进观测分级前四级与之一一同构（INFO-G severity 映射）；§9.3.2 LanguageService 诊断流接口 = 协议既有承载锚。
- **151. Error Recovery Strategies in Compiler Design + Elm Discourse「Parsers with Error Recovery」**——经典五策略（panic/phrase-level/error production/global correction/deletion-insertion）+ top-level chunking 多错误收集实践。**对齐**：ErrorPolicy 三策略 = 恢复策略谱系的配置面收束——HM 多错误收集[r75] = Collect 实例；fail-closed 与 panic-mode 同族但策略外置。
- **152. langdev.stackexchange「effect handlers state of the art」（2024-02）+ overreacted「Algebraic Effects for the Rest of Us」（2019-07）**——效应解耦程序逻辑与效应实现的工程共识（handler = 可替换效应解释器——log/metric/async 皆效应）。**对齐**：用户侧信息效应（AppLog + perform/handle）= 该共识的 kerf 实例——log handler 即观测者，与 INFO-B 策略外置裁定互证；支撑 InfoEffectSpace 归位合理性。

## 28. E.28 流特性理论与观测物理先例文献（v7.13 新增——r113 第二十七轮引证，同步自 stage0.md v8.6 附录 E.28；检索时点 2026-10，四查询 web-search 实检索证 r113-q1~q4，存档 [tool-results/r113-search/](../tool-results/r113-search/)）

> **引用原则**：本轮为流本体论理论吸收轮——检索证锚定「坍缩表象的物理机制权威」（退相干综述——「固定而非确定」的物理近亲）、「弦理论对偶的概念边界」（T 对偶词条——驳回裁定的概念依据）、「降维信息丢失的信息论骨架」（全息原理权威综述——Tier 2 骨架共享裁定）与「自由度-约束计数的经典方法」（相空间约束计数——计数恒等式实质的先例）。

- **155. Schlosshauer「Decoherence, the measurement problem, and interpretations of quantum mechanics」（Reviews of Modern Physics 76, 1267 — 2004，被引 2400+）**——退相干理论权威综述（link.aps.org）：环境相互作用导致叠加态选择性削减——退相干解释「坍缩表象」（appearance of collapse）而非真坍缩；many-worlds 诠释中 collapse 不存在而退相干承担其表象（q1 检索证——Wikipedia「Wave function collapse」互证）。**对齐**：「固定而非确定」= 该物理机制的观测论移植——一次观测（Handle）削减一个维度叠加而其余维度保持（FLW-B-1「退相干式表述增益」裁定锚）——比传统「坍缩」更精确刻画 kerf Handle 语义（效应行独立坍缩 ≠ 全空间坍缩）。
- **156. Wikipedia「Wave function collapse」+ preprints.org 量子测量问题讨论（2025）**——坍缩概念的诠释依赖性（Copenhagen vs many-worlds vs spontaneous collapse 谱系）：「坍缩」本身是诠释负载术语（q1 副证位）。**对齐**：kerf 文档族使用「坍缩」时恒指「维度阶固定」（Fix）的确定性语义转移——非物理坍缩的任何诠释承诺（术语消歧义务——原则 45 沿袭）。
- **157. Wikipedia「T-duality」（target-space duality）+ UCSB SUPERSTRINGS! 弦对偶讲义**——T 对偶 = 紧致化半径 R ↔ 1/R 的两理论等价性（circle compactification 物理等价——尺度对偶）；非对偶范畴、非观测机制（q2 检索证——physics.stackexchange/scipost 2025 任意半径非可逆 T 对偶研究互证）。**对齐**：FLW-D 驳回裁定概念依据——语料「观测坍缩 ↔ T 对偶性」对应不成立（T 对偶无观测语义）；正确物理先例 = 退相干/投影测量（#155）——驳回先例登记（数学工具箱准入纪律负案例）。
- **158. Bousso「The holographic principle」（Reviews of Modern Physics 74, 825 — 2002，被引 2900+）+ Wikipedia「Holographic principle」**——全息原理权威综述（link.aps.org/arXiv:hep-th/0203101）：Bekenstein 界启发——任何区域最大熵与边界面积成比例而非体积；「起源必须在于统一描述中基本自由度的数目」（q3 检索证）。**对齐**：Tier 2 信息论骨架共享裁定锚——「高维信息可被低维边界编码[有损]」与「任何观测不可完全恢复高维信息」（间隙性/InformationGap）共享投影算子 + 熵不等式论证结构；FLW-D 采纳「信息论面共享数学工具」而非「弦理论同构」表述纪律。
- **159. Errasti Díez 等「Constraint characterization and degree of freedom counting in first-order field theories」（2024，被引 14+）+ Physics StackExchange「Counting degrees of freedom in presence of constraints」**——约束系统自由度计数的经典拉格朗日方法：N 维相空间中 M 个第一类约束 + S 个第二类约束 → 自由度 = N − 2M − S（约束**削减**自由度是计数恒等式——q4 检索证）。**对齐**：FLW-B-3 数学实质裁定锚——「自由度-约束对偶」数学实质 = 计数恒等式（TotalFreedom = Constrained + Removed）而非不确定度不等式（「≥ 常数」为叙事层隐喻）；kerf 能力系统「能力 = 约束子空间 ℝᴺ→ℝᴹ」与该经典计数方法同构（CAP-C 度规理论的对偶面完备化）。

## 29. E.29 统一流分析与描述论哲学文献（v7.14 新增——r115 第二十八轮引证，同步自 stage0.md v8.7 附录 E.29；检索时点 2026-10，四查询 web-search 实检索证 r115-q1~q4，存档 [tool-results/r115-search/](../tool-results/r115-search/)）

- **160. Polonius——Rust next-generation borrow checker（Matsakis 等主导设计；rust-lang/polonius 仓库 + 技术综述 2025 + users.rust-lang.org 论坛讨论）**——基于 Datalog 逻辑的借用检查器设计：MIR 控制流图上流敏感借用分析（q1 检索证——NLL 拒绝而 Polonius 接受的流分支依赖生命周期案例实证）。**对齐**：UFA-A「借用检查 = 流干涉分析投影」的工业同构先例（Kildall 1973 框架级统一 r95 口径沿袭）；kerf 特有贡献 = 该数据流问题在效应流形上的统一表述。
- **161. Koka 语言 + Perceus 精确引用计数（koka-lang.github.io——微软研究院；Leijen 等「Koka: Programming with Row Polymorphic Effect Types」）**——效应类型+效应处理器语言：效应驱动无 GC 精确内存回收（q2 检索证）。**对齐**：LC-B（r94）先例锚重申 + UFA-B「效应驱动的编译期资源推导」同族范式确证；kerf 独有扩展 = 借用干涉检测投影统一。
- **162. Gödel 不完备定理 + Turing 停机问题 + Rice 定理家族（Wikipedia「Gödel's incompleteness theorems」+ cs.stackexchange + lesswrong.com「Limits on Computability」）**——三大计算限制定理的对角线论证家族统一（q3 检索证）。**对齐**：UFA-D 三重不完备统一先例锚——kerf 理论（描述间隙）为叙事层第四成员（K-A Tier 3）；「超越不完备定理」降格表述增益的裁定依据。
- **163. Ontic Structural Realism（Ladyman「Every Thing Must Go」2007 + Stanford Encyclopedia of Philosophy「Structural Realism」条目）**——OSR 拒绝实体-关系二分：理论实体的全部本性与结构和关系等同（q4 检索证）。**对齐**：UFA-C 描述论的最近哲学平行形态——「实体→描述」修正与 OSR「实体→结构/关系」取消主义同族；哲学同构 Tier 3 隐喻级。

## 30. E.30 递归处理与脚手架拆除文献（v7.15 新增——r117 第二十九轮引证，同步自 stage0.md v8.8 附录 E.30；检索时点 2026-10，四查询 web-search 实检索证存档 tool-results/r117-search/[q1-q4 JSON]）

- **164. Rust 社区递归防护共识（users.rust-lang.org「On guarding against stack overflows while using recursion」2022-10 讨论 + cs.stackexchange「recursive descent parser 溢出问题」2024 讨论 + Recursion and Memoization 专题）**——递归栈溢出防护策略谱系：社区共识「递归 + 静态强制嵌套限制是完全正确的方案」+ 递归下降解析器深递归溢出风险认知（q1 检索证）。**对齐**：Reader MAX_NESTING_DEPTH=256 防御帽（FS-1 实测锚）= 工业共识实例化；结构化错误 fail-closed = 社区共识交集；kerf 扩展 = 下游同形树递归同帽统一覆盖（社区讨论未涉及面）。
- **165. OCaml 5 效应处理器堆栈策略（ocaml.org Effect handlers 手册章 + lobste.rs 2025-05 讨论 + kcsrk.info「Practical Algebraic Effect Handlers in Multicore OCaml」+ Hillerström「Effect Handlers via Generalised Continuations」[cited by 46]）**——效应处理器栈策略工业实现：续延存储于堆可后调用（heap-allocated, dynamically resized stacks + one-shot delimited continuations）（q2 检索证）。**对齐**：语料「perform 不创建栈帧」三断言 = 实现策略面非效应语义必然的裁定依据；与 E.29-161（Koka Perceus）构成效应型栈/内存策略双先例。
- **166. 事件流解析与增量解析先例（matklad.github.io「Modern Parser Generator」2018-06 [rust-analyzer 架构] + Tree-sitter 增量解析综述 2024-04 + softwareengineering.stackexchange 常量内存流式解析讨论 + Dubroy「Incremental Packrat Parsing」2017 [cited by 21]）**——事件流形态：「不直接构建解析树而是发射事件流」——rust-analyzer 实际架构（q3 检索证）。**对齐**：语料方案 2（流式渐进解析）的架构形态锚——登记态备选的先例归位（无消费信号不开窗）。
- **167. 自举脚手架拆除与单运行时系统先例（tmewett.com「Bootstrapping and self-hosting」2020 + Chevalier-Boisvert 等「Bootstrapping a self-hosted research virtual machine」[cited by 18] + langdev.stackexchange 2023 + Robert Heaton 2017）**——自举脚手架形态与拆除谱系：自寄宿 VM 实证「单一运行时系统消除双系统维护成本」；引导编译器同步成本对照（q4 检索证）。**对齐**：S-expr 拆除（步⑤ E5 收口 + 种子链保留）的工程参照——平行件策略 = 比语料「完全移除」更强验证纪律；与 E.25 构成自举拆除双锚。

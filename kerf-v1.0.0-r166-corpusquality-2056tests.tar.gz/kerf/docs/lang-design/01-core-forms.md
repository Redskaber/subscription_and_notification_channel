# 最小自举单元的能力模型：九个核心原语

> **Author**: kerf-doc-agent
> **Date**: 2026-11-22（**v6.6——r157 / 227-b1 设计文档残留清偿窗：现行面 .krf→.ktf 引用修正 + 用户面记号桥（设计单源 design-docs-modernization-plan.md v1.0 U1/U3——D2 分流判据 J3）**）；2026-09-24（**v6.5——r67 原语集真值对账轮**：§2 OCaml 规范块换现行九原语（Fn/Apply/If/Var/Literal/Assign/Let/Perform/Handle）+ ModuleItem 声明层块 + §2 过去形态条例（Do/Define/Module/Require 沿革 + 旧词根）+ 糖推导示例换现行表面（assign/fn）+ §7.2 时态注记 + §8.5 锚行九变体对账）；2026-09-23（**r64 全文件集审计 Date 行补正**：v6.4（r49 / 70-a+b ModuleItem 声明层臂——CoreExpr 12→9：Define/Module/Require 上移声明层[22 §17 D59] + §8.3 三行状态更新 + §6/§7 注记）此前未落本行，本行补记；另 09-11 条目提前闭合修正[v6.0-v5.2 子条目嵌套归位——括号平衡清偿]——详情见 Version 行）；2026-09-17（**v6.3——r44 / 65-b E5 S3 M-R 名面臂回写**：§2 OCaml 规范块变体名同词根化（Fn/Apply/Var/Assign/Do——规范↔代码互锚[R4]，语义零变更经 E5 窗 S3 腿通道[22 §13 D34-D40]）+ §7.2 表 r44 注记 + §8.3 迁移映射表修正（`If→Branch`/`Literal→Const` 两行 NO-GO[22 §13 D35 一致性判据否决] + 五件 M-R GO ✅ r44 已落地）+ §8.5 测试锚 r44 行）；2026-09-11（v6.2：批次 F 深审回写——literal_value 补 Symbol 变体（TD-002 r5）+ 作用域元数据增补措辞限定；v6.0：新增 §8 内部语法设计——next3.md 第七轮吸收：类型安全 ADT 三原则 + 当前实现合规核验 + 旧→新迁移映射；v5.5：新增 §7 核心原语理论最小性与 2026 演进对照——next2.md 五轮吸收；v5.4：新增 §6 声明形式 require + 核心冻结边界精确化裁定；v5.2：糖推导示例「非穷举」注记（#5））
> **Version**: v6.6（**r157 / 227-b1**：U3 桥注 ×1——纯文档轮零代码变更，[design-docs-modernization-plan.md](../develop/v0/stage-3/design-docs-modernization-plan.md) v1.0）；v6.5（**r67 原语集真值对账轮**：§2 规范块与 expr.rs 现行九变体逐项互锚[代码为准 R4]——旧规范块为 r25 前旧九[含 Define/Do/Module、缺 Let/Perform/Handle]已换终态；过去形态条例入 §2）；v6.4（**r49 / 70-a+b ModuleItem 声明层臂**：CoreExpr 12→9——Define/Module/Require 上移 `ModuleItem` 声明层[22 §17 D59]；§8.3 三行状态更新 + §6/§7 注记）
> **Status**: Active（核心冻结对象，全生命周期不变——名面 M-R 臂经 E5 窗合法通道，语义原语集不变[原则 9 精确化：冻结的是语义集非词根集，22 §13 D34]）
> **处理程度**：P0（必须实现——Stage 0 已落地，kerf-core/src/expr.rs）｜ **所属 Stage**：Stage 0 定义、全生命周期冻结 ｜ **推迟项**：无（原语集合自身不变；周边能力的分级见 [13-能力矩阵](./13-capability-matrix.md)）

> 本文件收录 stage0.md §3「最小自举单元的能力模型」全文，包括五个核心能力模块、九个核心原语（最终定义）、语法对象模型与能力边界的初步划定。九个核心原语是整个语言的核心冻结对象——本文件是 [02-语法模型](./02-syntax-model.md)、[03-宏系统](./03-macro-system.md)、[04-字节码 VM](./04-bytecode-vm.md)、[05-运行时](./05-runtime.md) 各实现文件的语义根基；其**行为规范**（归约规则）见 [06-操作语义](./06-operational-semantics.md)；核心冻结原则的规范出处见 [17-设计原则 §1 原则 9](./17-principles.md)；能力选型的批判性审视与 2026 年现代方案见 [14-替代设计](./14-design-alternatives.md)，Stage 0 的三层分类裁决见 [13-能力矩阵](./13-capability-matrix.md)。

---

## 1. 五个核心能力模块（原 §3.1）

| 能力模型 | 实现语言 | 职责 | 接口契约 |
|---------|---------|------|---------|
| **Reader** | 宿主语言 | 字符流 → 语法对象 | `read : string → Result<SyntaxObject, ReadError>` |
| **Expander** | 宿主语言 | 语法对象 → 完全展开形式 | `expand : SyntaxObject → Result<CoreExpr, ExpandError>` |
| **Core Forms** | - | 9 个正交原语 | 代数数据类型定义 |
| **Bytecode VM** | 宿主语言/C | 执行字节码，验证语义 | `execute : Bytecode → Result<Value, RuntimeError>` |
| **Minimal Runtime** | C | 内存分配、基础数据操作 | C ABI 接口 |

## 2. 九个核心原语（最终定义）（原 §3.2——名面 v6.3/r44 同词根化）

```ocaml
type core_expr =
  | Fn of { params : string list; body : core_expr }        (* 表面关键字 fn *)
  | Apply of { fn_expr : core_expr; args : core_expr list } (* 调用——无关键字（位置形式）*)
  | If of { cond : core_expr; then_branch : core_expr; else_branch : core_expr }
  | Var of string                                          (* 引用——无关键字 *)
  | Literal of literal_value                               (* 字面——无关键字 *)
  | Assign of { name : string; value : core_expr }          (* 表面关键字 assign *)
  | Let of { name : string; value : core_expr; body : core_expr }  (* 表面关键字 let——r45 入列 / r50-β 表面直映 *)
  | Perform of { effect : core_expr }                       (* 表面关键字 perform——r25 效应上抛 *)
  | Handle of { tag : string; payload_var : string; resume_var : string;
                handler_body : core_expr; body : core_expr }  (* 表面关键字 handle——r25 浅处理 *)

(* 声明层（r49 / 22 §17 D59）——程序体 = Vec<module_item>，非语义原语：
   两级文法，展开器在项位分类（表达式位 define/require/module 由
   「CoreExpr 无法表示」结构化拒绝 E0003/E0018/E0023） *)
type module_item =
  | Define of { name : string; value : core_expr }          (* 表面关键字 define——项位声明 *)
  | Require of { caps : capability list }                   (* 表面关键字 require——零语义载荷恒 nil *)
  | Module of { name : string; imports : import_spec list;
                exports : export_spec list; body : module_item list }  (* 编译单元组织形式 *)

and literal_value =
  | Int of int | Float of float | String of string
  | Bool of bool | Nil
  | Pair of literal_value * literal_value
  | Symbol of string    (* v6.2 补注：TD-002 r5 新增——quote 符号 datum 的
                        字面量形态；实现存储剥离卫生后缀的基名（Racket 语义近似）；
                        LiteralKey::Symbol 为图 IR 共享去重键 *)
```

> **v6.3/r44 名面注记**：上表变体名与 kerf-core/src/expr.rs 实现（r44 后）
> 逐词根一致——规范↔代码互锚（§5 测试锚「变体逐字段对照」维持有效）。
> 历史名（Lambda/App/VarRef/SetBang/Begin）仅存于文档历史段与 E0021 旧名
> 指引表——代码面零残留（r44 grep 实证）；名面 M-R 变更经 E5 窗 S3 腿
> 合法通道（22 §13 D34-D40），语义原语集不变（原则 9 精确化：冻结的是
> 语义集非词根集）。

> **v6.4 声明层注记**：冻结契约表述更新——「9 语义原语 + `ModuleItem` 声明层（Define/Require/Module）」（r49 D59：声明变体的层归宿收口——`Require` 自 ADT 第 10 变体归位声明项，`Define`/`Module` 随 M-D/M-L 上移；§6「声明面与语义面两层不合流」裁定的层化实现）。
>
> **v6.5 过去形态条例（r67 真值对账——历史形态仅存本条例，不占正文语义）**：①`Do`——r50-β 前为语义原语成员，现表面 `(do ...)` 脱糖为 `Let`（恒定名 discard 模式，与原序列逐指令全等——22 §17.3 D61）；②`Define`/`Module`——r49 前为语义原语成员，现 `ModuleItem` 声明层（见上方声明块）；③`Require`——r18-r49 为 ADT 第 10 变体，现声明项；④旧词根 `Lambda/App/VarRef/SetBang/Begin`——r44 前变体名（名面 M-R 同词根化，代码面零残留）；⑤本规范块与 `kerf-core/src/expr.rs` L124-221 逐变体互锚（含作用域集元数据字段——TD-004）。
>
> **v6.2 作用域元数据注记**：r13 作用域集解析（TD-004）为部分原语增补了**解析元数据字段**——`Var`/`Assign` 携带引用作用域集、`Fn` 携带 `param_scopes` 绑定作用域集；属位置/解析元数据而非语义字段（06 §1.1 同口径限定）。语义字段（原语行为规范）仍与本定义一致。

**设计约束**：必须正交、必须完备、必须稳定（核心冻结原则——一旦定义，在整个语言生命周期内不变，[17-设计原则 §1 原则 9](./17-principles.md)）。九原语的小步归约规则（行为规范）见 [06-操作语义 §2](./06-operational-semantics.md)；运行时的归约状态与值域见同文件 §1。

**`import_spec` / `export_spec` 子类型定义（v5.1 补齐——Stage 0 裁定）**：stage0.md 原文引用了这两个类型名但未定义。Stage 0 实现裁定（kerf-core/src/expr.rs）：

```ocaml
type import_spec = string        (* 被导入模块名——Stage 0 为名字引用（符号），
                                    无前缀重命名/按需选择子（Stage 1+ 考虑，
                                    [12-路线图 §2.5](./12-roadmap.md) 演进矩阵） *)
type export_spec = string        (* 被导出符号名——Stage 0 为裸符号（Phase 0 值），
                                    无相位标注导出（for-syntax 导出推迟至多模块隔离） *)
```

该裁定的相位簿记落地见 [03-宏系统 §1.1 ModuleRegistry 契约](./03-macro-system.md)（`imports: Vec<Symbol>` / `exports: Vec<Symbol>`）；R9 模块归约规则见 [06-操作语义 §2](./06-operational-semantics.md)。

**从 9 个原语推导的语法糖示例**（**非穷举**——v5.2 注，deep-review R1 偏差 #5：下表仅为代表性示例；`when`/`unless`/`let*` 及嵌套 cond/and/or 多参形态的推导未列出，完整推导以展开器实现为准（kerf-expander，[03-宏系统 §2.2](./03-macro-system.md)），负测覆盖见 negative_expander_tests 的 21 关键字误用矩阵；**v6.4 注（r50-β / 22 §17.3 D61）**：`let` 已退出糖表（九糖 → 八糖）——表面 `(let ...)` 直达核心形式 `expand_let` 直映 `CoreExpr::Let`（多绑定暂存法保平行语义），非 `((fn ...) e...)` 组合推导；`let*` 维持糖位（递归目标单绑定 `(let ((x e)) ...)` 同径直映））：

```text
letrec f = e in body     → let f = nil in (assign f e) in body
cond [c1 e1] [else e3]   → (if c1 e1 e3)
and a b                  → (if a b false)
or a b                   → (if a true b)
while cond body          → (letrec loop (fn () (if cond (do body (loop)) nil))) (loop)
```

> **v6.5 表面名对账**：上例已换现行表面（`assign`/`fn`——r43 后；历史形 `set!`/`lambda` 见 §2 过去形态条例④）；`do` 仍为现行表面关键字（糖——r50-β 起脱糖为 `Let`）。

## 3. 语法对象模型（原 §3.3）

```ocaml
type stx_obj = {
  expr : stx_expr;
  span : span;            (* 源码位置——必须字段，不可为空 *)
  scopes : scope_set;     (* 作用域集合 *)
  phase : int;            (* 所属相位：0=运行时, 1=宏展开时 *)
}
```

语法对象是卫生宏系统的基础——它携带源位置、作用域集和相位信息，使得展开器可以区分"宏引入的标识符"和"用户代码中的标识符"。

## 4. 能力边界的初步划定（原 §3.4）

本节给出的五个能力模块（Reader / Expander / Core Forms / Bytecode VM / Minimal Runtime）是 Stage 0 的"骨架"。但其内部技术选型——例如同像性是否要采用 S 表达式、闭包是否要升级为 Effect Handlers、I/O 是否要采用能力模型——是一个需要结合 2026 年技术前沿重新审视的问题。接下来的 [14-替代设计 §1（超越 Lisp 范式）](./14-design-alternatives.md) 至 [14-替代设计 §3（2026 年五大能力现代方案）](./14-design-alternatives.md) 将系统化展开这一审视过程，并在 [13-能力矩阵 §1（Stage 0 能力矩阵与职责边界）](./13-capability-matrix.md) 给出最终的三层分类矩阵（必须实现 / 接口预留 / 完全推迟）。

## 5. 测试锚点（设计驱动测试，测试验证设计）

| 契约/不变式 | 测试锚点（tests/v0/stage0/） | 验证命题 |
|-----------|------------------------------|---------|
| 9 原语完备展开（糖推导表 §2） | plan 套件：let/let*/letrec/cond/and/or/when/unless/while 九种糖的展开正确 + "9 个核心形式展开正确"周判据 | 推导表与展开器一致 |
| 正交性（不可互相推导） | 排除实验：任一原语被移除后推导失败（设计审查论证，见 [17-设计原则 §1 原则 2](./17-principles.md)） | 无冗余原语 |
| 核心冻结（实现与定义一致） | kerf-core 单测：CoreExpr 9 变体逐字段对照本文件 §2 的 OCaml 定义 | 规范 ↔ 代码互锚 |
| 归约规则组（[06 §2](./06-operational-semantics.md)） | 双执行路径互查（全 73 集成测试） | R1–R9 实例化 |
| require 声明形式（§6） | stage1/plan 套件：capability_tests 23 case（声明/门控/豁免/形状负例） + test_runner_tests 前置切分 | 声明面与验证面一致 |

> 测试矩阵完整定义见 [11-测试基础设施 §3](./11-testing.md)；本表是其核心形式侧子集。

## 6. 声明形式 require（r8 批次 D 新增——能力 I/O 基础传递的程序侧声明面）

**形式文法**：`(require <主体> <能力>...)`——Stage 1 主体仅 `io`，能力项 `read`/`write`（声明为**幂等集合语义**，重复项去重；主体与能力项均为符号——非符号即展开期 E2 错误；未知主体/未知能力项报错并提示 Stage 2 扩展面 net/process）。用户面现代形 = `require io, write;`（↔ 内核 `(require io write)`——皮肤字典第八映射，20 §14）。

```ocaml
type capability =
  | IoRead    (* stdin 读：门控 read-line / read-int / read-num *)
  | IoWrite   (* stdout 写：门控 print / newline / write-string *)

type core_expr =
  | ...（9 原语不变）
  | Require of { caps : capability list }   (* 声明形式——零运行时语义 *)
```

**语义**：**零运行时语义**——不产生副作用，不求值结果恒为 `nil`（编译侧产 `PushNil`，eval 侧 `Ok(Nil)`，IR 侧降级 nil 共享字面量节点——T1 双路径一致）；不参与作用域分析（无变量引用、无自由变量）与静态类型检查（`Unknown`——权限验证归 R9）。它的**全部语义在编译期**：供 driver front 管线的 R9 保守权限验证（门控内置名引用未声明 → **E0006 编译期错误**，[13-能力矩阵 §3.1.3](./13-capability-matrix.md) 条款 3）与令牌铸造（`IoGrant` 按声明面授权）消费。

**核心冻结边界的精确化裁定**（本节 v5.4）：[17-设计原则 §1 原则 9](./17-principles.md) 冻结的是**语义原语**（九个原语正交完备、运行时语义全量流经它们——本文件 §2 定义不变）；`Require` 是**声明/注记变体**（ADT 第 10 变体——元数据节点，非语义节点）：它不增加任何归约规则（[06-操作语义](./06-operational-semantics.md) 的 R1–R9 不变，求值恒 nil 由编译/求值侧常量化处理）、不与任何原语组合推导、语义上可从程序中整体删除而不改变行为（R9 验证同时移除后程序仍等价——权限门控是外部约束而非程序语义）。**冻结的判定标准因此精确化为「语义原语集冻结 + 声明变体可追加」**——与 Racket `#%require` 形（模块导入声明，非语义原语）同构。Stage 2 语言级能力令牌值化时，`Require` 仍是声明面（令牌铸造的触发器），语义面由值语义承载——两层不会合流。

**测试锚点**：声明后可用（授权链）/未声明报 E0006（run/eval/check 三路径一致门控）/豁免（用户 define 同名接管不误报）/形状负例（缺参/未知主体/未知能力/非符号）——tests/v0/stage1/plan/capability_tests.rs（23 case）；require 为前置形式的切分约定见 [11-测试 §4](./11-testing.md)。

## 7. 核心原语的理论最小性与 2026 演进对照（v5.5 吸收自 next2.md 讨论轮）

> 本节吸收外部讨论（next2.md 第 1/3/4 轮）的核心原语批判性分析，作为**冻结 9 原语的对照坐标与 Stage 2+ 演进评估锚点**——不改变本文件 §2 的核心冻结裁定。

### 7.1 数量真相：9（本设计）vs 8（Racket kernel）vs 7（不可消除最小集）

**（v6.5 时态注记——r67）**：本节理论对照以 r18 时点原语集与旧词根展开（含时名 Lambda/SetBang 与当时的 Define/Begin 语义原语位）——现行集见 §2（Define 已归声明层、序列已由 Let 承载）；最小性论证的历史形态，其「Define 可脱糖」结论已由 r49 声明层分离收编、层位与 §7.1 精神一致。

**Racket kernel 实际是 8 个形式**（`#%plain-lambda`/`#%plain-app`/`#%plain-module-begin`/`#%datum`→`quote`/`quote`/`if`/`set!`/`define`）；本设计 9 原语（时点口径）中 **`Define` 理论上是 `Lambda + App + SetBang` 的语法糖**（`define x v ≡ ((lambda (x) …后续顶层…) v)` 的顶层锚定形态），**真正不可消除的最小集是 7 个**：`Lambda / App / If / VarRef / Literal / SetBang / Begin`——对应 Lambda 演算的 3 个（变量/抽象/应用）加 4 个实用扩展（分支/数据/副作用/顺序组合）。`Module`（第 8 语义原语，本设计超出 Racket kernel 的部分）服务相位分离——这是本设计对可拓展性的加法而非最小性的减损。

### 7.2 命名精确性对照（历史命名 vs 行为导向命名）

| 本设计命名 | 历史来源 | 精确性评价 | 行为导向替代 | 备注 |
|-----------|---------|-----------|------------|------|
| `Lambda` | Church 1932 | ✅ 精确 | `Fn` / `Abs` | 简洁性权衡保留 |
| `App` | β-归约传统 | ⚠️ 名词非行为 | `Apply` | Stage 2 表面语言命名参考 |
| `If` | 传统关键字 | ⚠️ 描述语法非行为 | `Branch` | 同上 |
| `VarRef` | 编译器术语 | ⚠️ 实现导向 | `Var`（de Bruijn 时 `Index`） | Stage 2 重写评估 |
| `Literal` | 编译器术语 | ⚠️ 不直观 | `Const` | 强调不可变 |
| `SetBang` | Scheme `!` 约定 | ❌ 极不直观 | `Assign` / `Mutate` | Stage 2 表面语法候选 |
| `Define` | 传统关键字 | ❌ 语义模糊 | `Bind` | 描述行为 |
| `Begin` | Scheme 传统 | ❌ 不精确 | `Seq` | 顺序求值 |
| `Module` | 通用术语 | ⚠️ 模糊 | `Phase`（强调相位） | 本设计语义即相位单元 |

**裁定**：核心 ADT 命名在冻结期内不变（§2 核心冻结）；本表作为 **Stage 2 表面语言（用户可见关键字）与目标语法 Reader 的命名参考**——表面语法与核心 ADT 解耦（[02-语法模型 §1](./02-syntax-model.md) 表面语法层可替换）。

> **r43 / E5 S2 表面切换注记（22 §12 D19-D33 重筛后终选）**：表面关键字三件已切换——`lambda→fn`/`set!→assign`/`begin→do`（set! 行导向替代 Assign 确认[原表第一候选兑现]；begin 行的 Seq 是 **ADT 层**候选[S3 载荷——表面层与 ADT 层解耦，原则 31]，表面层选 do[否决 seq——名空间经济：Clojure seq 生态占用]）；其余 22 名维持（22 §12.2 D22-D27 全表裁定）；表面/ADT 映射一致性对账见 22 §12.2 D30（fn↔Fn 对齐 / assign↔SetBang 分离合法[S3 不迁] / do↔Begin→Let 分离合法）。

> **r44 / E5 S3 M-R 名面臂注记（22 §13 D34-D40——五面同词根终态）**：上表「行为导向替代」列的实现状态——`Fn`/`Apply`/`Var`/`Assign`/`Do` 五件已落地（r44）；`Branch`/`Const` 两件 NO-GO（一致性判据否决——If/Literal 维持终态）；本表历史名列（Lambda/App/VarRef/SetBang/Begin）转为历史对照语义（§2 规范块已同词根化——变体名 = 表面关键字词根）。

### 7.3 Stage 2+ 演进候选：效应原语化（next2 推荐 8 原语形态）

next2 讨论的最终推荐（不考虑兼容性的重新设计）为 8 原语：`Fn / Let / Apply / Const / Var / Branch / Perform / Handle`——其中：
- **`Let`**（ANF 绑定）：Stage 2 ANF 转换层引入（[15-架构分层 §5](./15-architecture-layers.md) IR 层级演进——`Begin` 可模拟 `Let`（`begin a b → ((lambda (x) b) a)`）但无 ANF 优化能力）；
- **`Perform` / `Handle`**（效应执行 + 处理原语化）：与本设计当前路径（效应经 [13-能力矩阵 §3.1.1](./13-capability-matrix.md) 预留 + 编译器内部做实，I/O 经内置函数 + 能力门控）**同归殊途**——next2 路线把效应升为核心原语获得语言级表达力，本设计路径把效应留在元层保持核心极小。**Stage 2 语言级效应引入时此为首选评估对照**（`set! → Perform(State)`、`begin → Let 链` 的展开规则已由 next2 论证完备性）；
- **de Bruijn 索引**（消除变量名）：Stage 1 Expander 重写（批次 E）与 Stage 2 ANF 层的共同评估主题——"允许替换而不做 lambda 转换"（简化求值器与闭包转换）；
- **continuation 类型安全**（`Handle` 携带 resumption 类型三要素 + 线性唯一性）：Stage 2 效应安全的设计规格锚点——OCaml 5 已知缺陷（不静态确保效应被处理）的规避方案。

**本设计的对照结论**：冻结 9 原语（+Require 声明变体）在 Stage 0-1 不变；上列四项作为 **Stage 2 「目标语言完整化」门审查的评估清单**登记于 [12-路线图 §2.5.1](./12-roadmap.md) 演进矩阵注记。

> **r18 批次 H 评估裁定注记（H1 交付——[primitive-migration-evaluation.md](../develop/v0/stage-2/primitive-migration-evaluation.md)）**：五项评估经 §13.4 J1-J6 判据 + §6.3 五角色全票（5.5/5.5 × 5）裁定——E1 Let **DEFER-TO-STAGE3**（IR 层 AnnotatedANF 已承载 ANF 锚点；Core 层引入破坏自举 parity 链时机）/ E2 Perform/Handle **GO-DESIGN**（设计做实 Stage 2（r18 effect-language-design.md 交付）；实现窗口 D12 = 批次 I 后段）/ E3 de Bruijn **分层裁定**（**展开层命名制永久保持**——ScopeSet 卫生机制载体不可牺牲；IR 层编码化 = Stage 3 优化器伴生评估）/ E4 continuation **SPEC-ANCHOR**（三要素 + 线性唯一性规格入 H3 设计）/ E5 语义化命名 **REJECT-STANDALONE**（名实不符——8 形态命名前提是结构就位；绑定 E1-E4 全落地后 Stage 3 切换期一次性迁移）。**总裁定：Stage 2 内原语集零变更**（核心冻结原则 9 维持）。核心冻结原则（§2/原则 9）的精确化表述（v5.4 §6）不变：语义原语集冻结 + 声明变体可追加；效应原语化属于 Stage 2 语义层变更，须经 §13.2 切换期重构流程 + 委员会投票。8 原语语义等价迁移映射（9 冻结原语 → 8 原语形态的逐项映射表）见 §8.3 与 [upload/stage0.md §6.12.6](../stage0.md)。

> **r25 批次 I 后段交付注记（W1 回写——42-f / Effect M1-M5）**：Perform/Handle **已引入**（CoreExpr 第 11/12 变体——原语集 9(+Require) → 11(+Require)；[effect-language-design.md](../develop/v0/stage-2/effect-language-design.md) D1-D12 全裁定按期兑现：浅处理 D2 / continuation 线性唯一 D3 / resume 脱糖为调用形态 D4 / VM ext1 槽位激活 D6 / TCO 正交 D8 / 诊断 E0007-E0009 D9 / 能力-效应正交 D10 / 多次恢复否决 D11）。`set! → Perform(State)` 映射仍维持**语义等价证明而非实现义务**（D5——set! 保留原语）；原语集变更经 §13.2 流程批准（E2 GO-DESIGN 批次内变更），冻结契约更新为 **11 语义原语 + Require 声明变体**（architecture_audit 冻结证明 12 实例同步——r25）。

## 8. 内部语法设计：类型安全 ADT 与语义化命名（v6.0 吸收自 next3.md 第七轮）

> 本节回答「内部语法该用派生关键词还是类型安全 ADT」——next3.md 终轮裁定：**不应该使用旧时代的派生关键词设计**（Racket `#%` 前缀标识符或 Scheme `define`/`set!` 历史名称）——`#%` 前缀是 S 表达式语境区分用户层/编译器层的历史妥协（仅当语法与 AST 同构时必要），2026 年正确设计是「类型安全 ADT + 语义化命名 + 零历史包袱」：内部 AST 节点是编译器私有数据结构而非用户可见标识符，安全性由类型系统而非命名约定保证。

### 8.1 三原则

1. **类型安全而非命名安全**：AST 节点是编译器私有类型（`enum CoreExpr`）——安全性由类型系统保证，用户代码不可能构造 `CoreExpr::Fn`（除非经编译器 API）。旧设计依赖 `#%` 前缀命名约定（用户不可 shadow 的逃生舱）——从「约定」到「强制」；
2. **语义化命名而非历史命名**：名称精确描述节点行为（`Fn`/`Apply`/`Branch`/`Let`/`Const`/`Var`/`Perform`/`Handle`——其中 `Branch`/`Const` 后经 22 §13 D35 一致性判据否决，终态 `If`/`Literal` 维持）而非 1960 年代数学传统（lambda/if/set!/define/begin——时名）或逃生舱机制；
3. **零冗余而非多层转义**：`42 → Const(Int(42))` 直接映射无中间层——对比 Racket 多层转义 `42 → #%datum 42 → (quote 42) → 42`。

### 8.2 当前实现合规核验（三原则即刻生效为架构验证基准）

| 原则 | 核验项 | 结论 |
|------|--------|------|
| 类型安全 > 命名安全 | kerf-core 的 CoreExpr 是编译器私有 ADT（Rust enum 私有构造语义，用户代码无法构造） | ✅ 合规 |
| 语义化命名 > 历史命名 | 表面 S 表达式经 Reader 桥接到 CoreExpr（语法与 AST 分离） | ✅ 合规（表面/内部分离已落地） |
| 零冗余 | Span 系统独立于命名携带元数据（`kind_name` 仅诊断渲染用） | ✅ 合规 |

> **r44 / E5 S3 M-R 名面臂注记（22 §13 D35-D40）**：上表（§8.3 原候选）经一致性判据重审——**五件 GO 已落地 r44**（`Lambda→Fn`/`SetBang→Assign`/`Begin→Do`/`App→Apply`/`VarRef→Var`——纯 M-R 零语义载荷；SetBang 行的 M-E[Perform(State)] 与 M-R 解耦：D5 否决的是效应化实现，重命名独立合法）；**两件 NO-GO 修正原表**（`If→Branch`：表面 `if` 是 D22 跨家族通用语，重命名制造新名面分离——一致性 > 行为导向微优化；`Literal→Const`：literal 精确覆盖 quote 产物[Symbol/Pair 字面数据]，const 偏编译期常量概念，不可变性由类型系统保证[原则 23/30]名无需编码）；结构臂（Define 脱糖/Do→Let 链/Module 迁移/de Bruijn）归 r45+ 承载（D39 分臂裁定——每臂独立 commit + 字节码 parity 先行）。

### 8.3 旧→新迁移映射（v6.3/r44 修正版——22 §13 D35 判据重审后）

| 冻结原语（历史名） | 2026 形态 | 迁移性质 | 状态（r44 实况） |
|---------------------|-----------|--------|------------------|
| Lambda | `Fn` | 重命名（表面对齐——D35 ①） | ✅ **r44 已落地** |
| App | `Apply` | 重命名（动词化——D35 ④） | ✅ **r44 已落地** |
| If | `If`（维持） | ~~`Branch`~~ **NO-GO**（一致性判据否决——D35 ③） | ✅ 维持（终态） |
| VarRef | `Var` | 重命名（三面统一——D35 ⑤） | ✅ **r44 已落地**（M-R）；✅ **r48 IR 层索引化已落地**（IndexIR 槽级词法寻址——IrVar{Local/Captured/Global}，展开层命名制维持[E3 ①]——[22 §16 D56]） |
| Literal | `Literal`（维持） | ~~`Const`~~ **NO-GO**（J-1 语义精确 + 原则 23/30——D35 ⑥） | ✅ 维持（终态） |
| SetBang | `Assign` | **M-R 纯重命名**（M-E[Perform(State)] 与 M-R 解耦——D35 ②） | ✅ **r44 已落地**（M-R）；M-E 不迁（D5 维持） |
| Define | （消除——上移 `ModuleItem::Define` 声明项） | **M-D 上移**（项级直译：发射 `[value; Dup; DefineGlobal]` 零变更——字节码全等） | ✅ **r49-α 已落地**（22 §17 D59——项位恒合法 + 表达式位结构化拒绝[E0003 消息逐字]；非正交点 2→1） |
| Begin | `Do`（M-R ✅）/ `Let` 链（M-A+M-D 脱糖） | **M-D 已落** | ✅ **r45 已落地**（Do 变体消除 + do→Let 链[22 §14 D42]——字节码 parity 逐指令全等） |
| Module | （移至模块系统层——`ModuleItem::Module` 声明项） | **M-L 层级迁移**（发射 inline 项序零变更） | ✅ **r49-α 已落地**（22 §17 D59——E0023 表达式位新拒绝面） |
| （新增）Let | `Let` | ANF 必需的新原语（M-A） | ✅ **r45 已落地**（E1 Stage 3 重评 GO[22 §14 D41]——discard/bind 双模式 + Op::StoreLocal 既有零 VM 变更）；✅ **r50-β 直映已落地**（表面 let 退出糖表[九糖→八糖]——`expand_let` 直映 `CoreExpr::Let`，多绑定暂存法 + 平行语义机器验证组 + 行为 parity 门[22 §17.3 D61——D6 ② 形状识别退役 + TD-030 清偿]） |
| （新增，r25 已引入）Perform/Handle | `Perform`/`Handle` | 效应执行/处理配对 | ✅ 已落地（r25） |
| Require（声明变体） | （归位 `ModuleItem::Require` 声明项——声明层的最终形态） | **归位声明层**（两层不合流裁定维持——零运行时语义 PushNil 原样） | ✅ **r49-α 已落地**（22 §17 D59——E0018 消息逐字保持） |

迁移须走 Stage 2 「目标语言完整化」门审查（同 §7.3 裁定：§13.2 切换期重构流程 + 委员会投票）——M-R 名面臂已经 E5 窗 S3 腿通道 + r44 实施验证（834:0:0 + 五审计集 ×5 + 五面 grep 零旧形）。2026 形态完整 Rust ADT 定义（8 变体 + EffectKind + HandlerClause + LiteralValue）见 [upload/stage0.md §7.4.3](../stage0.md)；六维度对比表（安全性/精确性/冗余度/模式匹配/元数据/可扩展性）见同文件 §7.4.3。

### 8.4 表面/内部语法严格分离（架构不变量）

表面语法是可替换的用户接口（皮肤——S 表达式/中缀/DSL 均可，经 Reader 桥接），内部语法是编译器私有不变量（骨架——核心原语不变）：任何表面语法的编译产物为相同 CoreExpr，语义验证与语法选择正交（[02-语法模型 §1](./02-syntax-model.md) 表面语法层可替换 + [12-路线图 §2.4.1](./12-roadmap.md) 分阶段语法策略：Stage 0 S-expr → Stage 1 S-expr on VM（r6 B3 已兑现）→ Stage 2 目标语法 → Stage 2+ 多语法）。设计哲学定位：**这不是对 Racket 设计的否定，而是站在 Racket 30 年经验之上的「青出于蓝」**——`#%` 前缀是 S 表达式语境的最优解，类型安全 ADT 是现代编译器语境的最优解。

### 8.5 测试锚点（§8 新增）

| 锚点 | 验证方式 | 状态 |
|------|---------|------|
| 内部 ADT 私有性 | kerf-core 单测：CoreExpr 九变体字段对照本文件 §2（v6.5 对账：现行 9——含 Let/Perform/Handle；+ `ModuleItem` 三 kind 项面对照 r49）+ §8.2 三项合规（私有构造/Reader 桥接/Span 独立） | ✅ r9 在位（01 §5 既有锚点覆盖变体对照；三原则合规为架构审计项） |
| 迁移映射完备性 | 设计审计：§8.3 十二行映射逐行覆盖 §2 全部原语（含 Require）+ 新增项 | ✅ 本节自检（十二行 = 9 原语 + Require + Let + Perform/Handle） |
| 表面/内部分离 | 集成：同一 kerf 程序经 Reader 唯一入口产 CoreExpr（无表面语法直通内部 AST 的旁路） | ✅ r9 在位（driver front 管线唯一组合根，[15 §5.1](./15-architecture-layers.md)） |
| **五面同词根**（r44 新增——22 §13 D34/D37） | 架构审计：`kind_name` 12 名表（9 原语级关键字名 ∈ Keyword 注册面 + 3 内部名 ∉ 关键字面）+ `Keyword::ALL` 25 名全量 roundtrip/互异 + 桥 tag = kind_name 穿透 | ✅ r44 在位（s3mr_kind_name_keyword_face_penetration + keyword_all_roundtrip_and_distinct + 既有 kind_name 全变体互异锚） |

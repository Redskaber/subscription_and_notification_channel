# Stage 0 能力矩阵与 12 个能力模型完整设计

> **Author**: kerf-doc-agent
> **Date**: 2026-10-30（**v6.24——r117 第二十九轮吸收（next21.md）**：§3.22 递归深度处理能力面——同步自 stage0.md v8.8 §9.30）；2026-10-16（**v6.16——r92 / 162-a WasmBackend M1 做实注记**：§3.3.7 增补——`WasmCoreBackend` = WasmBackend trait 首个做实实现（r92/162-a：`wasm_emit.rs` 自写字节码发射器 + CFG→结构化控制 + node 宿主 E2E parity——1091:0:0 净+36；M2/M3 触发式维持——[wasm-backend-component-model v1.1 §5](../develop/v0/stage-3/wasm-backend-component-model.md)））；2026-10-10（**v6.15——r91 第十九轮吸收（next13.md）**：§3.14 拓扑与量子能力面[拓扑/量子能力行 + 8 原语不变性第四轮验证 + Pass C/D + 五 Pass 分立全景]——同步自 stage0.md v7.8 §9.20.6）；2026-10-10（**v6.14——r89 第十八轮吸收（next12.md 追加段）**：§3.13 逆向效应与计算干涉能力面[逆向/干涉/坍缩能力行 + InterferenceAnalysisPass + Randomness 效应 + 异步并发七优势]——同步自 stage0.md v7.7 §9.19）；2026-10-10（**v6.13——r88 第十七轮吸收（next12.md）**：§3.12 效应流形能力面与空间协议运行时[流形连接能力行 + SpaceRegistry 三协议 + SpaceValidationPass 四验证 + 流形诊断]——同步自 stage0.md v7.6 §9.18.6）；2026-10-09（**v6.12——r84 第十六轮吸收（next11.md）**：§3.11 效应本体论与空间接口契约[能力面——理论零新增能力行 + 17 关键字宏层能力 + 容器式签名能力锚 + SpaceContract 接口面 + 二义性三策略]——同步自 stage0.md v7.5 §9.17）；2026-09-24（**v6.10——r66 核心空间统一规划**：§3.8 修订[**双侧统一体系**——核心空间显式化（七核心域 + `CoreSpace` 载体）+ 拓展域改名（语法域→**元编程域**）+ 开闭统一编码（marker 家族双侧同套，开闭差异收编公理 A6 治理面）+ 做实面归属修复（拓展 L4 种子实现——A4 L1 层互斥恢复）+ `kerf-space` 骨架 crate（依赖环解 + 骨架居最底层）——同步自 24-space-decomposition.md v2.0（122-a 深化轮）]）；2026-09-23（**v6.9——r65 空间层级正交分解**：§3.8 修订[五大一级子空间→**六大域** + 分形层级的代码面落位引用——同步自 24-space-decomposition.md 全文（新文件——118-b 首件）]）；2026-09-22（**v6.8——r63 第十三轮吸收**：§3.9 双向调试策略与脚手架哲学的工程能力定位[模式识别器双重用途——§3.7 优化桥接的第二用途 + 五级调试视图 + 三种脚手架生命周期与拆除判据——同步自 stage0.md §9.11/§9.12] 新增）；2026-09-22（**v6.7——r62 第十二轮吸收**：§3.8 根空间统一组织[预留与拓展的概念骨架——三层预留体系 + 约束组合代数 + 预留接口依赖方向裁定——同步自 stage0.md §9.10] 新增）；2026-09-22（**v6.6——r59 第十一轮吸收**：§3.7.5 性能潜力裁定与双轨策略[偏见纠正 + 双轨 + 三阶段预期——同步自 stage0.md §6.13.3] 新增）；2026-09-17（**v6.5——r58 第十轮吸收**：§3.7 优化桥接[模式识别与等价替换——性能风险正面解法 + Stage 2 优化窗登记] 新增 + §3.3.1 IR 层级行四层修正案注记）；2026-09-17（v6.4——r57 第九轮吸收：机制预留 §3.6 新增[接口预测悖论的解法——预留体系哲学上层] + 代价分级判据 §3.5.4 + 三种打洞能力实盘对账）；2026-09-11（v6.1：next4.md 第八轮吸收——接口预留完整性审查 §3.3-§3.5 新增（10 个新识别关键接口 + 完整矩阵 + P0-P3 策略）+ LSP/FFI 重分类 + 矩阵 4→14 项；v5.5：v6.0 审查修正；v5.4：r8 批次 D——Effect 编译器内部做实与能力模型 I/O 基础传递做实注记；v5.3：r7 批次 C——编译缓存 P2 做实注记 + 类型检查器 Stage 1 引入交付注记；v5.2：§3.1 四项预留接口以 reserved.rs 冻结签名回填（#16）+ 能力模型 I/O P3→P2（#21））
> **Version**: v6.24（**r117 第二十九轮吸收——§3.22 递归深度处理能力面**[既有三防护能力确认 + 能力归属分层 + 备选登记态 + 效应流 = 叙事层——零新增能力域]）；**r115 第二十八轮吸收——§3.21 统一流分析与描述论能力面**[借用=流干涉投影能力面 + 约束描述含自由度分量 + 哥德尔第二定理信任根能力面——零能力域新增]）；v6.22（**r113 第二十七轮吸收——§3.20 自由度-约束对偶能力面**[CAP-C 对偶面完备化 + Freedom 四级 + 第三形态术语纪律——零能力域新增]）；v6.21（**r111 第二十六轮吸收——§3.19 信息效应能力面**[P0 接口就绪 + 能力门控零新增 + 五接口计数不变 + 8 原语第十轮验证——同步自 stage0.md v8.5 §9.27]）；v6.20（r96 第二十三轮吸收——§3.18 效应容器类型系统能力面[类型观测理论 + CoreType 类型代数 + 流形约束求解 + 五接口协同——8 原语不变性第八轮验证——五线程族完备]）；v6.19（r95 第二十二轮吸收——§3.17 流形统一分析能力面[分析的统一场论——六分析投影 + Pass 数据结构单源纪律三级单源体系 + MU-C 八项映射表 K-A 分级 + 8 原语不变性第七轮验证——历次最轻量轮零语法零原语零 EBNF]——同步自 stage0.md v8.1 §9.23.2/§9.23.3/§9.23.4）；v6.18（r94 第二十一轮吸收——§3.16 生命周期效应化能力面[生命周期=资源的时间效应——四操作全 Perform 模式 8 原语第六轮验证 + 借用=干涉分析 + LifecycleAnalysisPass 五 Phase 候选 + 消除三形]——同步自 stage0.md v8.0 §9.22.2/§9.22.3）；v6.17（r93 第二十轮吸收——§3.15 能力-效应协同接口与八维度正交[HOW vs WHETHER 判据 + Cap-gates-Effect 唯一接触面 + E0006 对账 + 8 原语第五轮验证]——同步自 stage0.md v7.9 §9.21.3）；v6.16（r92 WasmBackend M1 做实注记——§3.3.7 WasmCoreBackend 首实作；v6.15（r91 第十九轮吸收——§3.14 拓扑与量子能力面[8 原语闭合第四轮验证]；v6.14（r89 第十八轮吸收——§3.13 逆向效应与计算干涉能力面；v6.13（r88 第十七轮吸收——§3.12 效应流形能力面与空间协议运行时[流形连接能力行 + SpaceRegistry 三协议 + SpaceValidationPass 四验证 + 流形诊断]；v6.12（r84 第十六轮吸收——§3.11 效应本体论与空间接口契约；v6.11（r81 第十四轮吸收——§3.10 错误统一效应模型与目标语言设计蓝图；v6.10（r66 核心空间统一规划——§3.8 双侧统一体系 + 24 v2.0 同步；v6.9：r65 空间层级正交分解——§3.8 修订六大域 + 24 新文件落位；v6.8：r63 第十三轮双向调试与脚手架哲学吸收——§3.9；v6.7：r62 根空间统一组织——§3.8；v6.6：r59 性能潜力裁定——§3.7.5；v6.5：r58 优化桥接——§3.7 + §3.3.1 注记；v6.4：r57 机制预留——§3.6 + §3.5.4；v6.3 K2/r36 大阶段末深审回写——§14.8 B2-4；v6.2 r33 三义消歧指针 + 语言能力架构接线）
> **Status**: Active

> 本文件是 12 个能力模型详细设计（原 §8）的**唯一完整副本**，同时收录 Stage 0 能力矩阵与职责边界（原 §7：三层分类矩阵与架构原则）、接口预留与完全推迟的能力（原 §9 全文）、以及三个待定决策的前置架构约束（原 §15）。其中 §8.1/§8.6/§8.7、§8.9/§8.10、§8.12、§8.8/§8.11 的正文同时收录于对应主题文件（[02-语法模型](./02-syntax-model.md) / [03-宏系统](./03-macro-system.md) / [04-字节码 VM](./04-bytecode-vm.md) / [05-运行时](./05-runtime.md)）以保证自包含；关键算法伪代码收口于 02-05 的「实现框架」章节。能力选型的批判性审视与 2026 现代方案见 [14-替代设计](./14-design-alternatives.md)；能力引入时机与处理程度（P0-P4）的进程视角见 [12-路线图 §2](./12-roadmap.md)。
>
> **术语消歧指针（v6.2 r33 / 54-a）**：本文件的「能力」= **工程能力**（Engineering Capability——构建编译器所需技术，三层分类）；**语言能力**（运行时能力域 L0-L3 四层四要素）owner = [21-能力架构](./21-capability-architecture.md)；**授权**（ocap 安全语义——require 门控/FFI 令牌，本文件 §3.1.3「能力模型 I/O」在此坐标系下 = L3 授权层的 io 族实施）owner = [21 §4](./21-capability-architecture.md)。三义禁互换（[21 §1 定锚表](./21-capability-architecture.md)）。

---

## 1. Stage 0 能力矩阵与职责边界（原 §7）

> **截至 2026 年，Stage 0 应采用"混合务实"策略——核心语义层使用经过验证的传统方案（元循环求值器、闭包、基础同像性），基础设施层采用 2026 年已成熟的现代方案（类型化 Token 流、Span 追踪、结构化诊断），而高级 2026 方案（Effect Handlers、多阶段编程、能力模型 I/O）应仅设计接口预留而不实现——因为它们要么生态尚未完全成熟（如 Mojo 的"内存安全模型尚未完成"），要么仍主要处于研究阶段（如 MetaOCaml 的"实际实现往往使用启发式方法"）。**

### 1.1 能力矩阵 v4.0：三层分类（必须实现 / 接口预留 / 完全推迟）（原 §7.1）

#### 1.1.1 完整三层分类矩阵（原 §7.1.1）

| 能力模型 | 分类 | 2026 技术选择 | 成熟度评估 | 推迟到 |
|---------|------|-------------|-----------|--------|
| **类型化 Token 流 Reader** | ✅ 必须实现 | Rust proc-macro 风格 | ✅ 成熟（Rust 生产验证） | - |
| **图 IR（含共享）** | ✅ 必须实现 | 类型化节点 + 共享边 | ⚠️ 新兴（LLVM/GCC 生产验证） | - |
| **结构化 CodeValue** | ✅ 必须实现 | 携带类型/Span/Scope 的代码值 | ✅ 成熟（Rust + MetaOCaml 验证） | - |
| **元循环求值器（简化版）** | ✅ 必须实现 | 传统 eval/apply（不用 Effects） | ✅ 极成熟（60 年验证） | - |
| **基础闭包** | ✅ 必须实现 | 传统词法闭包 | ✅ 极成熟 | - |
| **Span 全管线传播** | ✅ 必须实现 | rustc 风格 Span 系统 | ✅ 成熟 | - |
| **结构化诊断框架** | ✅ 必须实现 | rustc diagnostic 风格 | ✅ 成熟 | - |
| **最小 I/O（传统）** | ✅ 必须实现 | 单 syscall / stdin/stdout | ✅ 极成熟 | - |
| **相位分离系统** | ✅ 必须实现 | Racket 风格 Phase 0/1 | ✅ 成熟 | - |
| **基础宏系统** | ✅ 必须实现 | 卫生宏 + SyntaxObject | ✅ 成熟（Racket 验证） | - |
| **标记-清除 GC** | ✅ 必须实现 | bump-pointer + 递归标记 | ✅ 成熟 | - |
| **字节码 VM** | ✅ 必须实现 | switch-dispatch，约 35 操作码 | ✅ 成熟 | - |
| **Effect Handlers** | ⚠️ 接口预留 | OCaml 5 风格（仅类型定义） | ⚠️ 新兴（正在用于 Forester 6.0） | Stage 2 |
| **多阶段编程** | ⚠️ 接口预留 | MetaOCaml 风格（仅类型定义） | ⚠️ 研究（实际实现使用启发式） | Stage 2 |
| **能力模型 I/O** | ⚠️ 接口预留 | 线性类型 + capability | ⚠️ 新兴（Rust 所有权验证） | Stage 1 |
| **编译缓存** | ✅ 做实（r7，P2 最小体） | 查询式缓存（内存内容寻址：SHA-256 截断键 + 三方法 + 管线富入口；salsa 依赖图 Stage 2 深化） | ✅ 成熟（rustc 增量验证） | Stage 2 深化 |
| **LSP/IDE 查询**（v6.1 重分类） | ⚠️ 接口预留 | LanguageService + IncrementalAst trait | ✅ 成熟（LSP 协议生态） | Stage 2 实现 / Stage 0 预留位置 |
| **调试信息生成**（v6.1 新增） | ⚠️ 接口预留 | DebugInfoGenerator + DebugTraceable trait | ✅ 成熟（DWARF 标准） | Stage 2 实现 / Stage 0 预留位置 |
| **FFI 边界**（v6.1 重分类） | ⚠️ 接口预留 | ExternalType + FfiBoundary trait | ✅ 成熟（C ABI） | Stage 2 实现 / Stage 0 预留位置 |
| **增量编译查询**（v6.1 新增） | ⚠️ 接口预留 | QuerySystem + Query trait（salsa 风格） | ✅ 成熟（rustc/salsa 验证） | Stage 2 深化 / Stage 0 预留架构 |
| **编译器即服务**（v6.1 新增） | ⚠️ 接口预留 | CompilerService + 可序列化状态 | ✅ 成熟（2026 服务化趋势） | Stage 2 实现 / Stage 0 预留可序列化边界 |
| **多目标后端**（v6.1 新增） | ⚠️ 接口预留 | CodegenBackend trait（WASM/QBE/LLVM） | ✅ 成熟（QBE 验证） | Stage 2 实现 / Stage 0 预留 trait |
| **包管理**（v6.1 新增） | ⚠️ 接口预留 | PackageManager + ExternalModule trait | ✅ 成熟（Cargo 实证） | Stage 1 基础 / Stage 0 预留模块边界 |
| **AI 辅助接口**（v6.1 新增） | ⚠️ 接口预留 | AiAssistant 语义 API trait | ⚠️ 新兴（2026 AI 生态） | Stage 1 基础 / Stage 0 预留语义查询 |
| **本地码生成** | ❌ 完全推迟 | QBE/LLVM/C 转译 | ✅ 成熟（非 Stage 0 目标） | Stage 2 |
| **类型检查器** | ✅ Stage 1 已引入（r7，外部 Rust 实现） | 保守静态检查（R1-R8 确定性规则 + 多错误收集；Hindley-Milner 完全体 Stage 2+） | ✅ 成熟（循环依赖经外部实现缓解） | Stage 2 完全体 |
| **优化器** | ❌ 完全推迟 | 分代/增量 | ✅ 成熟（非 Stage 0 目标） | Stage 3+ |
| **GC（高级）** | ❌ 完全推迟 | 分代/增量/并发 | ✅ 成熟 | Stage 2+ |
| **JIT** | ❌ 完全推迟 | 元追踪 | ✅ 成熟 | Stage 3 |
| **并发/线程** | ❌ 完全推迟 | Actor / CSP / STM | ✅ 成熟 | Stage 3 |

> **v6.1 增补**：接口预留层由 4 项扩至 14 项（上表 ⚠️ 行）——完整性与优先级依据见本文 [§3.3-§3.5](#33-2026-接口预留完整性审查v61-新增)（next4.md 第八轮：2026 接口预留完整性审查）。「LSP 集成」与「FFI」自完全推迟层重分类：实现仍推迟，但 Stage 0 必须预留数据结构位置（否则后期破坏性重构）。

#### 1.1.2 三层分类的设计哲学（原 §7.1.2）

**为何采用三层分类而非二元"实现/推迟"**：

1. **必须实现层** = Stage 0 的核心交付物。语义引擎用最成熟的传统方案，避免技术风险；基础设施用 2026 年已成熟的现代方案，提升工程质量
2. **接口预留层** = 为 2026 年前沿技术留好位置。仅定义类型签名和 trait/模块接口，不写实现。Stage 1+ 可以无缝替换为前沿方案的实现，而无需破坏现有调用方
3. **完全推迟层** = 不在 Stage 0 设计范围内。要么存在循环依赖（类型检查器），要么非 Stage 0 目标（优化器、JIT），要么会破坏自举闭环（FFI）

### 1.2 2026 年架构原则总结（原 §7.2）

**Stage 0 的设计哲学是"用经过验证的成熟技术构建语义引擎，用 2026 年已成熟的基础设施技术（类型化 Token 流、Span 系统、结构化诊断）提升工程质量，为 2026 年的前沿技术（Effect Handlers、多阶段编程、能力模型）预留演进空间"。**

这不是保守主义，而是工程务实——2026 年的技术前沿（如 Mojo 的"内存安全模型尚未完成"、MetaOCaml 的"实际实现使用启发式"）表明，直接采用最前沿方案存在风险。**正确策略是：在数据结构和接口层面为前沿技术留好位置，在实现层面使用成熟方案，在 Stage 2+ 逐步替换为前沿方案的实现。**

**四个核心架构原则**：
1. **成熟技术优先原则**：Stage 0 的每个组件都使用至少在生产环境验证过的技术
2. **接口先行原则**：为 2026 前沿技术（Effects、多阶段、能力 I/O）与工具链生态接口（LSP 查询、调试信息、增量查询、FFI、服务化、包管理、AI 辅助——v6.1 完整清单见本文 §3.4）预留接口但不实现
3. **传统+现代混合原则**：核心语义用传统方案（60 年验证），基础设施用现代方案（Rust 生态验证）
4. **渐进演进原则**：Stage 1+ 可以替换 Stage 0 的实现，但接口契约不变

本章确立的"混合务实"策略（成熟语义方案 + 现代基础设施 + 前沿技术接口预留）是后续所有架构决策的裁决标准：本文 §2 按「能力模型 → 职责边界 → 接口契约」三段式展开 12 个必须实现的能力，本文 §3 锁定接口预留与完全推迟的边界，[15-架构分层](./15-architecture-layers.md) 给出分层与调用关系的总览。当任何新设计诉求与三层分类冲突时，回到本文 §1.1.2 的三条设计哲学重新裁决。v6.1 增补：接口预留层的完整性以本文 §3.4 矩阵为准（4 项既有预留 + 10 项新识别预留），其裁决基线是第 32 条原则——预留的本质是「为未来留出空间」而非「提前实现」（[17-设计原则 §1](./17-principles.md)）。

---

## 2. 必须实现的 12 个能力模型详细设计（原 §8）

> 本章覆盖本文 §1.1 矩阵中「必须实现」层的全部 12 个能力模型 = **10 个语义与编译期能力**（Reader、图 IR、CodeValue、元循环求值器、闭包、Span、诊断、最小 I/O、相位分离、宏系统）+ **2 个运行时基座**（标记-清除 GC、字节码 VM）。原 v3.0 将其表述为"10+2"，v4.0 起统一为"12 个能力模型（10 + 2）"。每个能力按「能力模型 → 职责边界 → 接口契约」三段式组织；关键算法的完整可落地伪代码统一收口在「实现框架」系列文档：[02-语法模型 §6（Reader）](./02-syntax-model.md)、[03-宏系统 §4（Expander）](./03-macro-system.md)、[04-字节码 VM §2/§3（Compiler/VM）](./04-bytecode-vm.md)、[05-运行时 §4（GC）](./05-runtime.md)。

### 2.1 类型化 Token 流 Reader（原 §8.1）

**能力模型**：

```rust
// 2026 成熟方案：Rust proc-macro 风格的类型化 Token
#[derive(Debug, Clone)]
pub struct Token {
    pub kind: TokenKind,      // 类型化的 Token 种类
    pub span: Span,           // 源位置（file, start_line, start_col, end_line, end_col）
    pub scope_id: ScopeId,   // 作用域标识
}

#[derive(Debug, Clone)]
pub enum TokenKind {
    // 字面量
    IntLiteral(i64), FloatLiteral(f64), 
    StringLiteral(Rc<str>), BoolLiteral(bool),
    
    // 标识符
    Identifier(Symbol),         // interned string
    TypeIdentifier(Symbol),
    
    // 关键字
    Keyword(Keyword),           // fn, let, if, match, ...
    
    // 运算符（携带优先级信息）
    Operator(Operator),
    
    // 分隔符
    Delimiter(Delimiter),       // (, ), {, }, [, ]
    
    // 宏扩展点
    MacroInvocation(Symbol),
    
    Eof,
}
```

**职责边界**：
- **做什么**：将字符流转为类型化 Token 流；附带 Span 和 Scope 信息
- **不做什么**：不做语法分析；不执行宏展开；不判断类型正确性

**接口契约**：

```rust
pub trait Reader {
    fn tokenize(&mut self, source: &str) -> Result<Vec<Token>, LexError>;
    // 保证：输出的 Token 流覆盖整个输入（无损）
    // 保证：每个 Token 携带精确的 Span
    // 保证：词法错误返回结构化的 LexError（含位置信息）
}
```

### 2.2 图 IR（含共享节点）（原 §8.2）

**能力模型**：

```rust
pub struct GraphIR {
    pub nodes: Arena<IRNode>,     // arena 分配，NodeId 索引
    pub edges: Vec<IEdge>,
    pub node_map: FxHashMap<IRNodeHash, Vec<NodeId>>,  // 哈希 → 节点（支持共享查找）
}

pub enum IRNode {
    // 操作节点
    BinOp { op: Operator, lhs: NodeId, rhs: NodeId },
    Call { callee: NodeId, args: Vec<NodeId> },
    Lambda { params: Vec<Symbol>, body: NodeId },
    
    // 数据节点
    Literal(LiteralValue),
    Variable(Symbol),
    
    // 控制流
    If { cond: NodeId, then_branch: NodeId, else_branch: NodeId },
    
    // 每个节点都携带 Span 和类型信息
    // (在 Arena 中通过辅助表存储)
}

pub struct NodeMetadata {
    pub span: Span,
    pub type_info: Option<TypeInfo>,
    pub scope: ScopeSet,
}
```

**职责边界**：
- **做什么**：表示程序的结构化形式；支持节点共享（公共子表达式）；携带完整的元信息
- **不做什么**：不执行求值；不做类型推断；不处理控制流执行顺序

**接口契约**：

```rust
pub trait IR {
    type NodeId;
    
    // 构造
    fn add_node(&mut self, node: IRNode, meta: NodeMetadata) -> NodeId;
    fn add_edge(&mut self, from: NodeId, to: NodeId, kind: EdgeKind);
    
    // 查询
    fn get_node(&self, id: NodeId) -> &IRNode;
    fn get_metadata(&self, id: NodeId) -> &NodeMetadata;
    fn find_shared(&self, node: &IRNode) -> Vec<NodeId>;  // 查找共享节点
    
    // 变换（不可变，返回新 IR）
    fn map_nodes(&self, f: impl Fn(NodeId, &IRNode) -> IRNode) -> Self;
    fn substitute(&self, var: Symbol, replacement: NodeId) -> Self;
}
```

### 2.3 结构化 CodeValue（原 §8.3）

**能力模型**：

```rust
pub struct CodeValue {
    pub ir: GraphIR,             // 完整的图 IR
    pub span: Span,              // 源位置
    pub scope: ScopeSet,         // 作用域
    pub type_info: Option<TypeInfo>,  // 类型信息（如果已知）
    pub free_vars: Vec<Symbol>,  // 自由变量列表
    pub stage: Stage,            // 阶段信息（为多阶段编程预留）
}
```

**接口契约**：

```rust
pub trait CodeValue {
    // 检查
    fn is_well_formed(&self) -> bool;
    fn free_variables(&self) -> Vec<Symbol>;
    
    // 变换（不可变）
    fn substitute(&self, var: Symbol, val: &CodeValue) -> Self;
    fn alpha_rename(&self, from: Symbol, to: Symbol) -> Self;
    
    // 多阶段编程的接口预留（Stage 2 实现）
    fn compose_with(&self, other: &Self) -> Result<Self, CompositionError>;
    
    // 职责边界：仅作为代码的值表示，不执行隐式编译
}
```

### 2.4 元循环求值器（简化版）（原 §8.4）

**为什么用传统方案而非 Effect Handlers**：OCaml 5 的效应系统虽然"正在 Forester 6.0 中实际使用"，但主要用于工具和基础设施，而非作为语言核心的求值器。Stage 0 用传统的 eval/apply 相互递归更安全。

**能力模型**：

```rust
// 简化的元循环求值器（不用 Effects）
pub enum Value {
    Closure { params: Vec<Symbol>, body: NodeId, env: Env },
    Literal(LiteralValue),
    Unit,
}

pub type Env = Rc<RefCell<HashMap<Symbol, Value>>>;

pub fn eval(ir: &GraphIR, node: NodeId, env: &Env) -> Result<Value, EvalError> {
    match ir.get_node(node) {
        IRNode::Literal(v) => Ok(Value::Literal(v.clone())),
        
        IRNode::Variable(name) => {
            env.borrow().get(name).cloned()
                .ok_or(EvalError::UnboundVariable(name.clone()))
        }
        
        IRNode::Lambda { params, body } => {
            Ok(Value::Closure { 
                params: params.clone(), 
                body: *body, 
                env: env.clone() 
            })
        }
        
        IRNode::Call { callee, args } => {
            let f = eval(ir, *callee, env)?;
            let mut arg_vals = Vec::new();
            for arg in args {
                arg_vals.push(eval(ir, *arg, env)?);
            }
            apply(f, arg_vals, ir)
        }
        
        IRNode::If { cond, then_b, else_b } => {
            let c = eval(ir, *cond, env)?;
            match c {
                Value::Literal(LiteralValue::Bool(true)) => 
                    eval(ir, *then_b, env),
                Value::Literal(LiteralValue::Bool(false)) => 
                    eval(ir, *else_b, env),
                _ => Err(EvalError::TypeMismatch)
            }
        }
        
        // ... 其他节点类型
    }
}

pub fn apply(f: Value, args: Vec<Value>, ir: &GraphIR) -> Result<Value, EvalError> {
    match f {
        Value::Closure { params, body, env } => {
            let mut new_env = env.as_ref().clone();
            for (param, arg) in params.iter().zip(args) {
                new_env.borrow_mut().insert(param.clone(), arg);
            }
            eval(ir, body, &Rc::new(new_env))
        }
        _ => Err(EvalError::NotCallable)
    }
}
```

### 2.5 基础闭包（原 §8.5）

传统词法作用域闭包，不做任何花哨的扩展。具体而言：
- **环境捕获**：捕获定义时的词法作用域
- **不可变捕获**：捕获的环境通过 `Rc<RefCell<...>>` 共享，允许可变状态但禁止逃逸
- **不引入 Effect 系统**：保持纯词法闭包，避免 Stage 0 的复杂度爆炸

### 2.6 Span 全管线传播（原 §8.6）

rustc 风格，每个 Token / AST 节点 / IR 节点 / 字节码指令都携带 Span：

```rust
pub struct Span {
    pub file_id: FileId,
    pub start: ByteOffset,
    pub end: ByteOffset,
    pub expansion_id: ExpansionId,  // 宏展开代次
}
```

Span 在每个数据结构中作为不可变字段存在，使得：
- 任何错误都能精确定位到源码
- 调试器可以反查字节码 → IR → 源码
- 增量编译可以基于 Span 进行细粒度失效

### 2.7 结构化诊断框架（原 §8.7）

借鉴 rustc 的 Diagnostic 结构：

```rust
pub struct Diagnostic {
    pub severity: Severity,         // Error / Warning / Note / Help
    pub code: Option<DiagnosticCode>,
    pub message: String,
    pub primary_span: Span,
    pub children: Vec<SubDiagnostic>,  // 关联的次要诊断
    pub suggestions: Vec<Suggestion>,  // 修复建议
}
```

**架构原则**：错误是数据而非异常；支持错误恢复策略；多阶段错误关联。

### 2.8 最小 I/O（传统）（原 §8.8）

仅 `read_line()` 和 `write_line()`，通过全局函数（非能力模型）。Stage 0 不引入能力模型 I/O，但 VM 栈帧和分配器接口必须预留 `register_foreign_ref` 等接口（Stage 0 可为 no-op），以便 Stage 1+ 升级到能力模型时无需破坏接口。

### 2.9 相位分离系统（原 §8.9）

Phase 0（运行时）/ Phase 1（宏展开时）的严格分离，参考 Racket 设计。

**三个关键规则**：
1. Phase 1 代码只能产生 Phase 0 代码，不能直接执行 Phase 0 代码
2. 区分"实例化"（执行模块体）和"访问"（仅执行 Phase 1 部分）
3. 传递依赖的相位传播

模块生命周期通过 **declare / instantiate / visit** 三种操作管理：declare 登记模块与其相位声明，instantiate 执行模块体（Phase 0 实例化），visit 仅执行 Phase 1 部分（宏变换器加载）。该模型的完整架构约束论述见 [03-宏系统 §3（模块相位分离系统）](./03-macro-system.md)。

### 2.10 基础宏系统（原 §8.10）

卫生宏 + SyntaxObject，参考 Racket 但简化实现。Stage 0 的宏系统是"骨架"——支持宏定义、宏展开、卫生性保证，但不支持复杂的宏组合（如 `syntax-parse`）。

### 2.11 标记-清除 GC（最小实现）（原 §8.11）

Bump-pointer 分配 + 递归标记 + 堆遍历清除。根集包括 VM 栈、调用栈局部变量、全局环境和 C 栈显式根。Stage 0 用最简单的 mark-sweep，避免分代/增量/并发的复杂度。

**实现指引**：分配、标记、清除三个阶段的完整伪代码与栈溢出对策见 [05-运行时 §4](./05-runtime.md)。

### 2.12 字节码 VM（原 §8.12）

switch-dispatch 循环，处理约 35 个操作码。完整操作码定义涵盖：
- **栈操作**：PUSH, POP, DUP, SWAP
- **函数操作**：CALL, RET, CLOSURE
- **控制流**：JUMP, JUMP_IF_FALSE
- **数据构造**：MAKE_PAIR, CAR, CDR
- **变量访问**：LOAD_LOCAL, STORE_LOCAL, LOAD_GLOBAL, STORE_GLOBAL
- **算术**：ADD, SUB, MUL, DIV
- **终止**：HALT

**VM 状态包含**：代码、数据栈、调用栈、全局环境、常量池和调试信息表。

**调用栈帧包含三个扩展槽**（Stage 0 可以为空，但格式必须保留）：
- `ext1`：为 continuation/effect handler 预留
- `ext2`：为异常处理表预留  
- `ext3`：为调试帧信息预留

**Forth 语言的线程码技术展示了 VM 极简设计的极限**：整个 VM 的核心仅由 NEXT、DOCOL、EXIT、LIT 四个原语构成。

**实现指引**：跳转回填的字节码生成与 switch-dispatch 执行循环的完整伪代码见 [04-字节码 VM §2 与 §3](./04-bytecode-vm.md)。原 v3.0 §8.6「字节码 VM 设计」与本节内容重复，v4.0 已合并至此。

---

## 3. 接口预留与完全推迟的能力（原 §9）

> **接口预留层与完全推迟层共同构成 Stage 0 的"未来边界"。** 二者的区别是本质性的：接口预留层**已确定将被采用**，仅推迟实现（Stage 1-2 落地，Stage 0 冻结类型签名）；完全推迟层**尚未承诺采用**（存在明确的推迟理由，Stage 1+ 重新评估）。这一区分直接决定了本章两类内容的阅读方式——前者是"必须兑现的期票"，后者是"保留的选择权"。

> **v6.1 增补（next4.md 第八轮）**：本章从「4 项预留 + 8 项推迟」扩展为「14 项预留 + 6 项推迟」——本文 [§3.3-§3.5](#33-2026-接口预留完整性审查v61-新增) 是 2026 接口预留完整性审查的完整吸收：既有预留（效应系统、能力模型、多阶段编程、编译缓存、类型系统、IR 层级六类）覆盖约 70% 的已知需求，缺失的 30% 关键接口（LSP/IDE 查询、调试信息、FFI 边界、增量编译查询、编译器即服务、多目标后端、包管理、AI 辅助等 10 项）在 §3.3 逐项设计、§3.4 汇成矩阵、§3.5 给出 P0-P3 优先级与预留原则。这些接口的共同特征是：**不需要在 Stage 0 实现，但必须在 Stage 0 的数据结构中预留位置，否则后期引入时需要破坏性重构。**

### 3.1 接口预留的 4 个语言能力（原 §9.1）

> **v7.0 术语消歧注（r19 / 41-a——capability-model-design.md D1/D2）**：本节
> 标题原称「4 个能力模型」存在术语双义——本节语境指**语言能力**（feature
> 项：Effect/多阶段/能力门控/编译缓存），而「能力模型」此后专指**权限
> 安全模型**（capability security model——令牌/授权/验证/演算）。
> 为消除歧义，本节标题改称「语言能力」；§3.1.3 内部进一步拆出**模型层
> 骨架**（reserved/capability_model.rs——r19 冻结 P3）与**族实例层**
> （capability_io.rs），不计入预留项计数（14 项不变）。

> **v5.2 签名权威声明（deep-review R1 偏差 #16）**：本节四项预留接口的**冻结签名权威是 `kerf-driver/src/reserved.rs`**（冻结性经 Probe 实现测试 `reserved_signatures_are_frozen` 证明——「测试实现体编译通过 = 契约冻结」）。早期版本的伪签名（如 `Self::Effect::Result` 关联类型路径、`splice(code) -> Self::Code::Inner` 等不可编译形态）仅为设计草稿，以下全部回填为可编译的真实冻结签名。

#### 3.1.1 Effect Handlers（P0 语言面已做实——r25 全量 + r28 静态收敛；历史：r8 编译器内部做实）（原 §9.1.1）

> **r8 交付注记（2026-09-10，批次 D）**：[12-路线图 §2.5.1](./12-roadmap.md) 演进矩阵
> Stage 1 行「做实引入（**编译器内部**）」已兑现——`kerf-driver/src/effects.rs`
> 双层做实：(1) **类型化一次性逃逸层**（`handle_escape<R,T>`/`perform_escape<T>`）：
> 载荷从任意嵌套深度上展开至最近同类型边界，零签名污染（「任意流程节点
> 能力」的机械实现）；线程局部深度计数 + `catch_unwind`/`resume_unwind`
> std-only 载荷逃逸 + 私有载荷类型判别的 panic hook 过滤（效应控制流零
> 噪声，真实 panic 照常报告）；(2) **冻结契约层**（`InternalEffectSystem`）：
> 本节 trait 的真实现（与 Probe 测试构成契约可编译/可承载双证）。**语言面
> 保持 P3**（D1 裁定：语言级 perform/handle 语义仍留 Stage 2——多次恢复
> continuation 不实现，`Continuation` 维持 unit 形状留白）；消费面 =
> `kerf test` 用例短路 + 错误恢复（[11-测试 §4](./11-testing.md)）。
> VM 帧 `ext1` 槽位不激活（Stage 2 语言级效应时启用）。
>
> **r25/r28 终态注记（v6.3/K2-r36 补——本节原停 r8 口径，代码侧早已演进）**：
> 语言级效应 **M1-M5 全量交付（r25/42-f）**：原语集 9→11（perform/handle）
> + resume 脱糖（D4）+ VM `ext1` 具体化为 `Option<Rc<HandlerFrame>>`
> （INSTALL_HANDLER/PERFORM 两指令，三原型帧编排 T/H/B + trampoline
> 惰性单例）+ continuation 值四要素（帧链/数据栈快照/恢复点/线性唯一
> ——多次恢复已实现，E0008 二次恢复检出）+ E0007-E0009 诊断族 + GC
> 第六来源（活跃 continuation 帧链，05 §3.2 v6.3 同步）+ 自举双侧 parity。
> **静态收敛面（r28/49-a）**：typecheck.rs/hm.rs Perform 效应值入 R1-R8/
> HM 检查域 + Handle 两体入检出域（双面检出超集纪律——tc+hm）。
> 语言面 P0 口径；行多态/效应行属 Stage 3（typecheck.rs:362 注记锚）。

**预留接口（Stage 0 冻结，P3——仅类型形状）**：

```rust
// reserved.rs 冻结签名（可编译）
pub trait EffectFamily {
    /// 执行该效应后的结果值（P3 形状：以 Value 具体化——Stage 2 可细化为泛型关联）。
    type Result;
}

pub trait Effect {
    /// 所属效应族。
    type Family: EffectFamily<Result = Value>;
}

pub trait EffectSystem {
    type Effect: Effect;
    type Handler;
    type Continuation;

    /// 执行效应：挂起并向上传递（Stage 2 实现；P3 形状：结果经 Value）。
    fn perform(&self, effect: Self::Effect) -> Value;

    /// 安装效应处理器并执行计算（Stage 2 实现）。
    fn handle(&self, handler: Self::Handler, computation: impl FnOnce() -> Value) -> Value;
}
```

**行为规格**（完整语义见 stage0.md §6.4）：`perform` 挂起当前计算，向上查找匹配的 handler；`handle` 安装 handler 并执行计算——效应触发时以 continuation 恢复。Stage 0 裁定：传统闭包（§21.10 决策点 2）；Effects 于 Stage 2 语言级引入。

**预留原因**：OCaml 5 的效应系统正在"实际使用于编译器基础设施"，但作为语言核心的求值器仍属前沿。

#### 3.1.2 多阶段编程（接口预留）（原 §9.1.2）

**预留接口（Stage 0 冻结，P3——仅类型形状）**：

```rust
// reserved.rs 冻结签名（可编译）
pub trait MultiStage {
    /// 代码值类型（Stage 2 具体化为 `CodeValue`）。
    type Code;

    /// 引号：表达式 → 代码值（Stage 2 实现）。
    fn quote(&self, expr: &CoreExpr) -> Self::Code;

    /// 拼接：代码值 → 当前阶段代码（Stage 2 实现）。
    fn splice(&self, code: &Self::Code) -> Result<CoreExpr, RuntimeError>;

    /// 执行代码值（Stage 2 实现）。
    fn run(&self, code: &Self::Code) -> Result<Value, RuntimeError>;
}
```

**行为规格**（MetaOCaml 语义，stage0.md §6.1）：`quote` 将表达式提升为代码值（良构/良作用域保证）；`splice` 将代码值拼接进当前阶段语法；`run` 执行未来阶段代码（Stage 2 做实为编译期计算）。Stage 0 裁定：元循环求值器（§21.10 决策点 1）；多阶段于 Stage 2+ 替换。

**预留原因**：MetaOCaml 虽然理论上成熟（"良构的、良类型的和良作用域的"），但"实际实现往往使用启发式方法"。

#### 3.1.3 能力模型 I/O（P2 做实基础传递——r8 批次 D 交付注记）（原 §9.1.3）

> **r8 交付注记（2026-09-10，批次 D）**：「Stage 1 基础传递」已兑现——三层
> 分工落地（interface-contract-review F2 修复裁定）：`reserved.rs` 冻结契约
> （签名权威）+ `kerf-driver/src/capability.rs` 铸造/实现/验证 + `builtins.rs`
> 消费。程序侧声明面 = 新声明形式 `(require io read|write)`（[01-核心原语
> §6](./01-core-forms.md)——零运行时语义，幂等集合）；R9 保守静态权限验证
> （下述条款 3：门控内置名任意位置引用未声明 → **编译期错误 E0006**，
> front 管线 run/eval/check/compile 全路径单一验证点；用户接管豁免 +
> 卫生回退基名判定防误报）；`IoGrant` 令牌铸造（pub(crate) 构造面——
> 不可伪造）+ `StdCapabilityIO`（stdio 实现）+ I/O 内置能力参数化（条款 4：
> `register_globals` 按授权面注册门控内置——未声明即不注册，fail-closed）。
> 令牌线性语义以 `Rc<RefCell<>>` 承载（借用期互斥 = 线性近似，Stage 2
> 令牌值化时消除）。

> **v7.0 模型层/族层分离注（r19 / 41-a）**：本节经
> [capability-model-design.md](../develop/v0/stage-2/capability-model-design.md)
> D3-D4 裁定后形成三层形态——**模型层骨架**（`reserved/capability_model.rs`
> 新增：`CapabilityModelFamily` 族形状 + `TokenCalculus` 演算位
> （attenuate/revoke——Stage 2/3 窗口），P3 冻结 + Probe 四测试）、
> **族实例层**（本节既有 io 族契约——签名零变化，原则 27）、**管线层**
> （`crate::capability` 授权管线——M2 泛化命名迁移窗口 = 批次 I 后段）。
> 设计动机：IO 是能力模型的第一实例（FFI 线性令牌 `CPointer` 是第二
> 实例——§3.3.4/G3 设计）；模型层锚位使 net/process 等族（12 §2.4.5
> Stage 2 行）引入从「五点手术」收敛为「三点加法」（设计 D11）。
> 化学反应矩阵（×效应 ×多阶段 ×缓存 ×FFI ×HM ×工具链——正交可组合
> 不合并）见设计文档 §5。**本注不改变本节 P2 处理程度与四条款规格。**

**处理程度（v5.2 修订，deep-review R1 偏差 #21）**：**P2**（原记 P3）——reserved.rs 的 `CapabilityIO` 冻结签名附带**完整行为规格**（下述 4 条），满足 P2 判据「冻结类型签名与行为规格，无实现」（[12-路线图 §2.1.2](./12-roadmap.md) 五级标度）——与 [17-设计原则 §1 原则 26](./17-principles.md) 三级成熟度匹配规则的「研究前沿 → P3」裁定并不冲突：规则给出的是**上限**，实现策略上为Stage 1 直达预留了完整规格（超规格交付）。

**预留接口（Stage 0 冻结，P2）**：

```rust
// reserved.rs 冻结签名（可编译）
/// 读能力令牌（不可伪造——私有构造，经权限传递获得）。
pub struct ReadCapability { _private: () }

/// 写能力令牌（不可伪造）。
pub struct WriteCapability { _private: () }

/// 能力模型 I/O 错误。
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct IOError { pub message: String }

pub trait CapabilityIO {
    /// 读一行（需要读能力，Stage 1+ 实现）。
    fn read_line(cap: &mut ReadCapability) -> Result<String, IOError>;

    /// 写一行（需要写能力，Stage 1+ 实现）。
    fn write_line(cap: &mut WriteCapability, s: &str) -> Result<(), IOError>;
}
```

**完整行为规格**（P2——Stage 1 可直接按规格实现）：
1. `read_line` 仅在持有 `ReadCapability` 时可调用——令牌经线性传递，不可复制、不可伪造；
2. `write_line` 同理（`WriteCapability`）；
3. 无令牌的 I/O 调用为**编译期错误**（权限验证，非运行时检查）；
4. 与 Stage 0 传统 I/O（kerf-runtime::io 全局函数）的替换关系：渐进替换原则 §28——driver 注册的内置函数改为能力参数化形态，全局函数逐步退役。

Stage 0 裁定：传统 I/O（§21.10 决策点 3）；能力模型于 Stage 1 基础 / Stage 2 完整引入。

#### 3.1.4 编译缓存（P2 做实——r7 批次 C 交付注记）

> **r7 交付注记（2026-09-10，批次 C）**：三方法规格已按原文落地——
> `kerf-driver/src/cache.rs` 的 `InMemoryCompilationCache` 实现本节冻结
> trait（`get_cached`/`store`/`invalidate` 行为规格 1/2/3 逐条测试锁定），
> 另增管线富入口（`lookup_front`/`store_front` 携带完整前端输出——run/eval/check
> 路径复用）与 SHA-256 内容寻址键（源哈希截断 u64 + 配置指纹=阶段种子+文件名，
> `kerf-driver/src/hash.rs` 零依赖自实现，NIST 向量锚定）。
> §21.3 Stage 1 条件 4「增量编译基础设施可用」就位；Stage 2 salsa
> 依赖图深化时三方法签名不变（规格条款 4）。

**预留接口（Stage 0 冻结，P2）**：

```rust
// reserved.rs 冻结签名（可编译）
/// 缓存键（源哈希 + 编译配置指纹——确定性编译的键）。
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct CacheKey {
    pub source_hash: u64,        // 源文本内容哈希（Stage 1：SHA-256 内容寻址）
    pub config_fingerprint: u64, // 编译配置指纹（阶段版本 + 选项）
}

/// 缓存结果（编译产物——字节码 + 核心表达式 + 代码值）。
#[derive(Debug, Clone)]
pub struct CachedResult {
    pub program: BcProgram,
    pub core: Vec<Rc<CoreExpr>>,
    pub code_value: Option<CodeValue>,
}

pub trait CompilationCache {
    /// 查询缓存。
    fn get_cached(&self, key: &CacheKey) -> Option<CachedResult>;

    /// 写入缓存。
    fn store(&mut self, key: CacheKey, result: CachedResult);

    /// 失效缓存项。
    fn invalidate(&mut self, key: &CacheKey);
}
```

**完整行为规格**（P2——Stage 1 可直接按规格实现）：
1. `get_cached`：键命中返回产物（内容寻址——源不变 + 配置不变 → 产物必然等价，可直接复用）；
2. `store`：写入缓存（幂等——同键覆盖）；
3. `invalidate`：显式失效（源变更由键哈希自然区分；此方法用于编译器升级等全量失效场景）；
4. Stage 2 深化：查询式增量编译（salsa 风格依赖图），本三方法保持签名不变（渐进替换原则 §28）。

> 既有四项预留的覆盖度评估与缺失需求清单见本文 [§3.3.1](#331-已预留接口的覆盖度评估)——其中「分布式效应」「能力委托与组合」「跨阶段持久化」「跨会话缓存」等缺失需求由 §3.3.10 的边界增补与后续阶段演进承接。

### 3.2 完全推迟的能力（原 §9.2）

> **v6.1 边界调和**：原列于本层的「LSP 集成」与「FFI」重分类至接口预留层（本文 [§3.3.2](#332-lspide-集成接口p0) / [§3.3.4](#334-ffi外部函数接口p1)）——二者的**实现**仍分别推迟至 Stage 2，但 Stage 0 必须预留其数据结构位置（AST 增量与绑定查询接口 / ExternalType 与 FfiBoundary trait），否则后期引入需破坏性重构。「完全推迟」的语义由此更精确：指**尚未承诺采用**的能力（保留选择权），而非「已承诺采用但实现推迟」的期票（接口预留层语义——见本章首的区分）。

| 能力 | 推迟到 | 理由 |
|------|--------|------|
| 本地码生成 | Stage 2 | Stage 0 只需字节码 VM（后端 trait 已预留，见本文 §3.3.7） |
| 类型检查器 | **Stage 1（r7 已引入——外部 Rust 保守静态检查，循环依赖缓解落地；HM 完全体 Stage 2+）** | 循环依赖问题（需先有稳定的核心；[12-路线图 §2.6](./12-roadmap.md) 缓解：外部实现） |
| 高级 GC | Stage 2+ | Stage 0 用最简单的 mark-sweep |
| 优化器 | Stage 3 | 需要性能基准数据 |
| 并发 | Stage 3 | 语义复杂（效应系统为其预留演进口径，见本文 §3.1.1） |
| JIT | Stage 3 | 依赖 profiling 数据 |

### 3.3 2026 接口预留完整性审查（v6.1 新增）

> **本节完整吸收 next4.md 第八轮讨论**：在「具备强大可拓展性和可塑性的最小自举单元」的能力与边界设计前提下，对截至 2026 年推荐设计中的接口预留做完整性审查。核心结论：**当前设计预留了约 70% 的关键接口，但缺失了 30%——特别是 LSP/IDE、调试信息、增量编译查询这三个 P0 级接口，它们的不预留将导致后期破坏性重构。**


> **测试锚点（v6.1）**：本节全部预留 trait 的冻结性验证沿用 §3.1 的先例——签名以「测试实现体编译通过」证明契约冻结（reserved.rs Probe 模式，`reserved_signatures_are_frozen`）；新接口的 Probe 冻结测试于 r12 批次（worklog Task 31-d）交付。

#### 3.3.1 已预留接口的覆盖度评估

| 接口类别 | 具体接口 | 预留状态 | 覆盖的需求 | 缺失的需求（承接落位） |
|---------|---------|---------|-----------|-----------|
| **效应系统** | EffectKind、HandlerClause、Continuation（本文 §3.1.1） | ✅ 已预留 | 异步、并发、异常、状态 | 分布式效应、跨网络效应传播（→ §3.3.10） |
| **能力模型** | Capability、LinearType（本文 §3.1.3） | ✅ 已预留 | I/O 安全、资源管理 | 能力委托、能力组合、动态能力获取（→ §3.3.10） |
| **多阶段编程** | Code、quote/splice（本文 §3.1.2） | ✅ 已预留 | 编译期计算、代码生成 | 跨阶段持久化、运行时代码生成 |
| **编译缓存** | Cache 接口（本文 §3.1.4） | ✅ 已预留 | 增量编译（数据面） | 查询式架构（架构面 → §3.3.5）、跨会话持久化、分布式缓存 |
| **类型系统** | Row、Union、Linear | ✅ 已预留 | 渐进类型、行多态 | 依赖类型、refinement types |
| **IR 层级** | 6 层 IR 定义 | ✅ 已预留 | 渐进优化 | 后端可插拔接口（→ §3.3.7）；**r58 四层修正案注记**：结构/语义/形式/目标四维正交框架下 AnnotatedANF 与 SSA 为维度重复层——四层合并方案登记为 Stage 2 优化窗裁定候选（→ §3.7.4，与六层规划的差集论据开窗时裁定） |
| **工具链生态** | —— | ❌ 整体缺失（本版补齐） | —— | LSP/IDE 查询、调试信息、FFI、服务化、包管理、AI 辅助（→ §3.3.2-§3.3.9） |

**评估结论**：语义内核维度（效应/能力/多阶段/缓存/类型/IR）的预留基本完备；**工具链生态维度整体缺失**——而这正是 2026 年语言竞争力（IDE 体验、源级调试、生态集成、AI 协作）的基础设施，也是本节补齐的目标。

#### 3.3.2 LSP/IDE 集成接口（P0）

**为什么必须预留**：现代语言的开发体验依赖 IDE 支持，而 LSP 集成要求编译器暴露「语法/语义查询接口」——这必须在 AST 设计中预留（呼应 [17-设计原则 §1](./17-principles.md) 第 14 条原则「工具即编译器」：LSP 消费与编译器相同的语法树）。

**预留接口（不实现）**：

```rust
// ============ LSP/IDE 查询接口（Stage 0 冻结形状） ============ //

/// 编译器作为语言服务器的接口（Stage 2 实现基础 LSP 服务器）
pub trait LanguageService {
    // 语法查询
    fn syntax_tree_at(&self, file: FileId, pos: Position) -> SyntaxNode;
    fn completion_items(&self, file: FileId, pos: Position) -> Vec<CompletionItem>;
    fn document_symbols(&self, file: FileId) -> Vec<Symbol>;

    // 语义查询
    fn definition_of(&self, file: FileId, pos: Position) -> Option<Location>;
    fn references_to(&self, file: FileId, pos: Position) -> Vec<Location>;
    fn type_at(&self, file: FileId, pos: Position) -> Option<TypeInfo>;

    // 诊断
    fn diagnostics(&self, file: FileId) -> Vec<Diagnostic>;
    fn quick_fixes(&self, file: FileId, pos: Position) -> Vec<CodeAction>;

    // 重构
    fn rename_symbol(
        &mut self,
        file: FileId,
        pos: Position,
        new_name: String,
    ) -> Result<WorkspaceEdit, RenameError>;
}

/// AST 增量更新接口（LSP 的按需重析依赖于此）
pub trait IncrementalAst {
    fn apply_edit(&mut self, edit: TextEdit) -> Result<(), EditError>;
    fn invalidate_range(&mut self, range: Span);
    fn reuse_unchanged(&self, other: &Self) -> ReusePlan;
}
```

**Stage 0 必须在 AST 中预留的数据结构位置**：
1. 每个节点必须可追溯 Span（**已实现**——见本文 §2.6 Span 全管线传播）
2. 每个绑定必须可查询其作用域（需预留——作用域表支持外部遍历）
3. AST 必须可增量更新（需预留——`IncrementalAst` trait 位置）

#### 3.3.3 调试信息生成接口（P0）

**为什么必须预留**：源级调试（断点、堆栈追踪、变量查看）要求编译器在生成代码时保留「源码 ↔ 目标码」的映射——这必须在 IR 设计中预留。

**预留接口（不实现）**：

```rust
// ============ 调试信息生成接口（Stage 0 冻结形状） ============ //

/// 调试信息生成器（Stage 2 生成源映射，Stage 2+ 生成 DWARF）
pub trait DebugInfoGenerator {
    /// 将 IR 节点映射到源码位置
    fn source_location_of(&self, ir_node: NodeId) -> Option<Span>;

    /// 将目标码地址映射回 IR 节点
    fn ir_node_at(&self, code_addr: Address) -> Option<NodeId>;

    /// 变量的位置信息（在哪个寄存器/栈槽）
    fn variable_location(&self, var: VarId, at_pc: Address) -> Option<Location>;

    /// 生成 DWARF / 源映射
    fn generate_dwarf(&self) -> DwarfSections;
    fn generate_source_map(&self) -> SourceMap;
}

/// IR 节点的调试可回溯性（每个 IR 节点实现）
pub trait DebugTraceable {
    /// AST → IR 的映射（用于从 IR 回溯到源码）
    fn ast_node_id(&self) -> AstNodeId;
    /// 变量的调试名称（而非仅 de Bruijn 索引）
    fn debug_name(&self) -> Option<Symbol>;
}
```

**Stage 0 必须在 IR 中预留的数据结构位置**：
1. 每个 IR 节点保留指向 AST 节点的反向链接
2. 变量在 IR 中有稳定的 ID（而非仅 de Bruijn 索引）
3. 函数边界和调用点有唯一标识

#### 3.3.4 FFI（外部函数接口）（P1）

**为什么必须预留**：系统级语言必须与 C/系统 API 交互，这要求类型系统预留「外部类型」表示。

**预留接口（不实现）**：

```rust
// ============ FFI 边界接口（Stage 0 冻结形状） ============ //

/// 外部函数调用的类型表示
pub enum ExternalType {
    CInt(CIntSize),
    CPointer(PointeeType),
    CStruct(Vec<ExternalType>),
    CFunction {
        param: Box<ExternalType>,
        result: Box<ExternalType>,
    },
    Opaque(String), // 不透明的外部类型
}

/// FFI 调用的核心原语
pub enum FfiCall {
    /// 调用外部函数
    CallExternal {
        symbol: Symbol,
        args: Vec<CoreExpr>,
        return_type: ExternalType,
    },
    /// 分配外部内存（不经过 GC）
    AllocExternal { size: usize },
    /// 释放外部内存
    FreeExternal { ptr: CoreExpr },
}

/// FFI 边界（GC 与外部内存的隔离协议）
pub trait FfiBoundary {
    /// 外部指针的包装类型
    type ExternalPointer;

    /// 标记对象被外部代码引用（GC 不可回收）
    fn pin_object(&mut self, obj: Value);
    fn unpin_object(&mut self, obj: Value);
}
```

**Stage 0 必须预留的数据结构位置**：
1. 核心表达式必须能表示「外部调用」
2. 类型系统必须能表示「外部类型」
3. GC 必须能识别「外部引用」（不被回收——pin/unpin 协议）

**自举合规注记**：FFI 的**实现**推迟至 Stage 2（破坏自举闭环——见 本文 §3.2）；本预留仅为类型形状与 GC 边界协议，不引入对宿主 C ABI 的编译期依赖，不触碰自举链（[12-路线图 §2](./12-roadmap.md) 后端策略同口径）。

**行为规格与实现锚（r30/48-d 做实）**：行为语义 = [stage-2/ffi-ownership-model](../develop/v0/stage-2/ffi-ownership-model.md)（G3 冻结——三原语所有权责任矩阵 + GC pin/unpin 跨边界语义 + 线性令牌 + 13 边界 case）；VM 执行面已落地：操作码三指令（`CALL_EXTERNAL`/`ALLOC_EXTERNAL`/`FREE_EXTERNAL`——[04-字节码 VM §1](./04-bytecode-vm.md) 第十组，43→46）+ `FfiBoundary` 真实实现（`kerf-driver/src/ffi.rs`——P/U 规则经 Heap Φ 计数簿）+ extern 符号表（符号解析 fail-closed = E0012）+ E0010-E0012 诊断族（[18-术语 §6](./18-terminology.md)）；**语言面形式 = Stage 3**（编译臂不发射——IR/VM 面做实即 Stage 2 验收条件 4 兑现）。**§21.3 条件 4 状态：✅**。

#### 3.3.5 增量编译查询接口（P0）

**为什么必须预留**：查询式架构（[15-架构分层 §3.1](./15-architecture-layers.md)）要求所有编译中间结果通过统一接口访问——这必须在编译器架构中预留（参考 rustc 查询系统与 Salsa 框架）。

**预留接口（不实现）**：

```rust
// ============ 增量编译查询接口（Stage 0 冻结形状） ============ //

/// 查询系统：所有编译操作通过查询执行
pub trait QuerySystem {
    /// 输入：源文件（的内容寻址键）
    type Input;

    /// 执行查询（带缓存 + 依赖追踪）
    fn query(&self, descriptor: &QueryDescriptor) -> QueryResult;

    /// 输入变化时失效相关缓存
    fn invalidate(&mut self, input: Self::Input);

    /// 依赖追踪：查询 Q 依赖哪些其他查询
    fn dependencies_of(&self, descriptor: &QueryDescriptor) -> Vec<QueryDescriptor>;
}

/// 单个查询（编译器的每个 pass 必须建模为查询）
pub trait Query {
    type Input;
    type Output;

    /// 此查询依赖的其他查询（依赖必须完整声明）
    fn dependencies(&self) -> Vec<QueryDescriptor>;

    /// 执行查询（纯函数）
    fn execute(&self, db: &dyn QuerySystem) -> Self::Output;
}
```

**Stage 0 必须预留的架构位置**：
1. 编译器的每个 pass 必须建模为「查询」
2. 查询之间必须能声明依赖
3. 查询结果必须可缓存/可失效

**与 本文 §3.1.4 的关系**：编译缓存预留的是**数据面**（缓存三方法），本接口预留的是**架构面**（查询/依赖/失效协议）——二者构成 salsa 式增量编译的完整骨架；[15-架构分层 §3.1](./15-architecture-layers.md) 查询式增量编译架构是其正文展开，Stage 1+ 实现应同时落地这两个 trait。

#### 3.3.6 编译器即服务接口（P1）

**为什么必须预留**：2026 年的趋势是将编译器作为服务（浏览器中的 Playground、AI 辅助编程的 API）——这要求编译器可远程调用。

**预留接口（不实现）**：

```rust
// ============ 编译器即服务接口（Stage 0 冻结形状） ============ //

/// 编译器作为可远程调用的服务
pub trait CompilerService {
    /// 提交编译请求
    fn submit(&self, request: CompileRequest) -> CompileJobId;

    /// 查询编译状态
    fn status(&self, job: CompileJobId) -> CompileStatus;

    /// 获取编译结果
    fn result(&self, job: CompileJobId) -> Option<CompileResult>;

    /// 流式获取诊断信息
    fn diagnostics_stream(&self, job: CompileJobId) -> Vec<Diagnostic>;

    /// 取消编译
    fn cancel(&mut self, job: CompileJobId);
}

/// 编译请求（支持增量）
pub struct CompileRequest {
    /// 完整或增量的源码
    pub source: SourceInput,
    /// 编译目标（本地码/字节码/WASM）
    pub target: CompileTarget,
    /// 优化级别
    pub opt_level: OptLevel,
    /// 调试信息需求
    pub debug_info: DebugInfoRequest,
}

/// 可序列化边界（编译器状态可传输的前提）
pub trait Serializable {
    fn serialize(&self) -> Vec<u8>;
    fn deserialize(data: &[u8]) -> Result<Self, DeserializeError>
    where
        Self: Sized;
}
```

**Stage 0 必须预留的架构位置**：
1. 编译器必须是可序列化的（状态可传输）
2. 编译过程必须可中断/可恢复
3. 诊断信息必须可流式输出

**实证注记**：本项目 web Playground（`/api/playground` 编译即服务端点）即此接口的宿主侧雏形——预留 `CompilerService` 形状可让宿主侧服务化无需反向适配编译器内部结构。

#### 3.3.7 多目标后端接口（P1）

> **r17 做实迁移注记（批次 G / 38-b）**：本节冻结的契约类型（`CodegenBackend`/`WasmBackend`/`AnnotatedANF` 等）已自预留层（kerf-driver/reserved/codegen）迁入正式家 `kerf-backend/src/codegen.rs`——**签名零变化**（§2.2 原则 27），`AnnotatedANF` 从指纹占位**实化**为携带函数定义集的块式 ANF IR（fingerprint 字段保留——内容寻址口径不变）；预留层改薄 re-export（历史引用路径继续可用）。**首个做实实现**：`QbeBackend`（G1 PoC——fib 端到端本地码；详见 [10-toolchain §CLI](./10-toolchain.md) 与 RELEASE_NOTES r17）。

> **r92 M1 做实注记（162-a）**：**`WasmBackend` trait 首个做实实现落地**——`WasmCoreBackend`（`compile_component` → `WasmComponent { bytes: core wasm module 二进制, model: M0 派生清单 }`；发射器 = `wasm_emit.rs` 自写零依赖[§18 L-B] + CFG→结构化控制递归区域分解 + `kerf_meta` 清单回读对账 + node 宿主 E2E parity 28 语料族[WebAssembly.validate + 实例化与 kerf VM 逐语料对账——组件消费方实体化]——净 +36 测试 1091:0:0；L-A WASM GC 类型裁定 = 线性类型域 i64 先行）；M2 canonical ABI 适配 / M3 组件组合触发式维持——[wasm-backend-component-model §5](../develop/v0/stage-3/wasm-backend-component-model.md) v1.1 + 登记册 v0.4.11。

**为什么必须预留**：后端可插拔（IR 层级缺失需求之一）——目标中立性原则（[17-设计原则 §1](./17-principles.md) 第 13 条）的接口化落地；WebAssembly 是 2026 年的关键目标。

**预留接口（不实现）**：

```rust
// ============ 多目标后端接口（Stage 0 冻结形状） ============ //

/// 目标描述与代码生成后端
pub trait CodegenBackend {
    /// 后端支持的目标
    fn supported_targets(&self) -> Vec<TargetTriple>;

    /// 将 IR 编译为目标码
    fn compile(
        &self,
        ir: &AnnotatedANF,
        target: &TargetTriple,
    ) -> Result<CompiledModule, CodegenError>;

    /// 后端特有的优化
    fn backend_optimizations(&self) -> Vec<PassDescriptor>;
}

/// WebAssembly 后端（2026 年的关键需求：组件模型 + 接口类型 + WASM GC）
pub trait WasmBackend {
    /// 编译到 WASM 组件模型
    fn compile_component(&self, ir: &AnnotatedANF) -> Result<WasmComponent, CodegenError>;
}
```

**与 §11 后端策略的关系**：Stage 0 不引入 LLVM（[08-后端演化 §1](./08-backend-evolution.md)）、字节码 VM 为唯一执行后端（本文 §2.12）——本 trait 预留的是**未来后端的插槽**（Stage 2 QBE → Stage 2+ WASM/LLVM 可选），LLVM 永不进入自举链的裁定不变（§21）。

#### 3.3.8 包管理/依赖解析接口（P2）

**为什么必须预留**：模块系统必须支持「外部模块」（来自其他包）——导入路径与包依赖的表示能力必须在 Stage 0 的模块边界中预留。

**预留接口（不实现）**：

```rust
// ============ 包管理接口（Stage 0 冻结形状） ============ //

/// 包管理器与编译器的接口
pub trait PackageManager {
    /// 解析依赖图
    fn resolve_dependencies(
        &self,
        manifest: &PackageManifest,
    ) -> Result<DependencyGraph, ResolveError>;

    /// 获取包的编译产物
    fn get_package(
        &self,
        name: &PackageName,
        version: &Version,
    ) -> Result<PackageArtifact, FetchError>;

    /// 锁定依赖版本
    fn lock(&self, graph: &DependencyGraph) -> LockFile;
}

/// 外部模块（模块系统的包边界预留）
pub trait ExternalModule {
    /// 外部模块的来源（包名+路径）
    fn source(&self) -> ModuleSource;
    /// 外部模块的编译产物（可能是预编译的）
    fn compiled(&self) -> Option<CompiledModule>;
}
```

**Stage 0 必须预留的数据结构位置**：
1. 模块系统必须支持「外部模块」（来自其他包）
2. 导入路径必须能表示包依赖
3. 编译器必须能增量编译单个包

#### 3.3.9 AI 辅助编程接口（P2）

**2026 年的关键需求**：AI 编程助手需要编译器提供「语义级 API」而非仅文本级——语义摘要、签名查询、快速类型检查、重构建议。

**预留接口（不实现）**：

```rust
// ============ AI 辅助编程接口（Stage 0 冻结形状） ============ //

/// 为 AI 编程助手提供的语义 API
pub trait AiAssistant {
    /// 获取代码的语义摘要（用于上下文理解）
    fn semantic_summary(&self, file: FileId) -> SemanticSummary;

    /// 获取函数的输入/输出类型和效应（用于补全建议）
    fn function_signature(&self, symbol: &Symbol) -> FunctionSignature;

    /// 验证 AI 生成的代码是否类型安全（快速检查）
    fn quick_typecheck(&self, snippet: &str) -> Result<TypeCheckResult, TypeError>;

    /// 提供重构建议（AI 辅助重构）
    fn refactoring_suggestions(&self, selection: &Span) -> Vec<Refactoring>;

    /// 生成代码的文档注释
    fn generate_doc_comment(&self, item: &Symbol) -> String;
}
```

**与 LanguageService 的关系**：`AiAssistant` 复用 `LanguageService`（§3.3.2）的查询基建（符号表、类型表、诊断流），是其上的语义封装层——预留前者时后者的大部分查询形状已被冻结，成本边际递减。

#### 3.3.10 效应扩展与能力委托（既有预留的边界增补）

既有 本文 §3.1.1（Effect Handlers）与 本文 §3.1.3（能力模型 I/O）的覆盖度评估暴露两类缺失需求（§3.3.1 表），按「不新增接口、只注明既有形状的扩展方向」处理：

- **分布式效应 / 跨网络效应传播**：`EffectSystem` trait 的 `Effect` 关联类型已可承载自定义效应族——Stage 2 效应 DSL、Stage 3+ 分布式效应在此基础上扩展，不要求 Stage 0 追加数据结构位置（效应描述本身已正交于执行位置）
- **能力委托 / 能力组合 / 动态能力获取**：`ReadCapability`/`WriteCapability` 令牌的线性传递语义（不可复制、不可伪造）已预留委托的语义地基——能力组合（`And` 能力积类型）与受限委托（attenuation）在 Stage 1+ 以库形态叠加于令牌类型之上，无需修改既有签名

此二项在 §3.4 矩阵中以 P1/P3 登记其演进方向（效应扩展 P3、能力委托 P1——后者因安全模型的完整性依赖早期令牌语义冻结）。

### 3.4 完整接口预留矩阵

> 下表是 v6.1 后接口预留层的**唯一完整清单**（4 项既有 + 10 项新识别 = 14 项）——任何「某接口是否已预留」的争议以此表为准。

| 接口 | Stage 0 预留内容 | Stage 1 实现 | Stage 2+ 实现 | 预留成本 | 不预留的代价 |
|------|----------------|-------------|-------------|---------|------------|
| **Effect Handlers**（既有） | EffectSystem trait 形状（本文 §3.1.1） | —— | 效应 DSL | 已预留 | 效应系统封闭 |
| **多阶段编程**（既有） | MultiStage trait 形状（本文 §3.1.2） | —— | quote/splice/run 实现 | 已预留 | 元编程受限 |
| **能力模型 I/O**（既有） | 令牌类型 + CapabilityIO（本文 §3.1.3） | 基础能力传递 | 完整安全模型 | 已预留 | 安全模型受限 |
| **编译缓存**（既有） | CompilationCache 三方法（本文 §3.1.4） | 内存内容寻址做实 | salsa 依赖图深化 | 已预留 | 增量编译无从谈起 |
| **LSP/IDE 查询** | AST 增量接口、绑定查询接口（§3.3.2） | 基础 LSP 服务器 | 完整 IDE 支持 | 2 天 | 需重构 AST（破坏性） |
| **调试信息** | AST↔IR 反向链接、变量稳定 ID（§3.3.3） | 源映射生成 | DWARF 生成 | 3 天 | 需重构 IR（破坏性） |
| **FFI 边界** | ExternalType、外部调用原语（§3.3.4） | C FFI | 完整 FFI | 5 天 | 需重构类型系统 |
| **增量编译查询** | 查询系统架构（§3.3.5） | 查询缓存 | 完整增量 | 1 周 | 需重构编译器架构（破坏性） |
| **编译器即服务** | 可序列化状态（§3.3.6） | REST API | Web Playground | 3 天 | 需重构编译器 |
| **多目标后端** | 后端 trait 定义（§3.3.7） | QBE 后端 | WASM/LLVM（可选，不入自举链） | 2 天 | 需重构代码生成 |
| **包管理** | 外部模块支持（§3.3.8） | 基础包解析 | 完整生态 | 3 天 | 需重构模块系统 |
| **AI 辅助** | 语义 API 预留（§3.3.9） | 基础补全 | 完整 AI 集成 | 2 天 | 失去 AI 生态 |
| **效应扩展**（增补） | 自定义效应类型位置（§3.3.10） | 效应 DSL | 分布式效应 | 1 天 | 效应系统封闭 |
| **能力委托**（增补） | 能力传递接口（§3.3.10） | 基础委托 | 完整安全模型 | 1 天 | 安全模型受限 |

### 3.5 优先级策略与预留原则

#### 3.5.1 按「不预留的破坏性代价」排序

| 优先级 | 接口 | 不预留的代价 | 预留成本 | 建议行动 |
|--------|------|------------|---------|---------|
| **P0** | LSP/IDE 查询 | 需重构 AST（破坏性） | 2 天 | ✅ 必须在 Stage 0 数据结构中预留位置 |
| **P0** | 调试信息 | 需重构 IR（破坏性） | 3 天 | ✅ 必须在 Stage 0 数据结构中预留位置 |
| **P0** | 增量编译查询 | 需重构编译器架构（破坏性） | 1 周 | ✅ 必须在 Stage 0 架构中预留 |
| **P1** | FFI 边界 | 需重构类型系统 | 5 天 | ✅ 强烈建议在 Stage 0 预留 trait 定义 |
| **P1** | 多目标后端 | 需重构代码生成 | 2 天 | ✅ 强烈建议在 Stage 0 预留 trait 定义 |
| **P1** | 编译器即服务 | 需重构编译器 | 3 天 | ✅ 强烈建议在 Stage 0 预留 trait 定义 |
| **P2** | 包管理 | 需重构模块系统 | 3 天 | ⚠️ 建议在 Stage 1 预留 |
| **P2** | AI 辅助 | 失去 AI 生态 | 2 天 | ⚠️ 建议在 Stage 1 预留 |
| **P3** | 分布式效应 | 效应系统封闭 | 1 天 | 💡 可在 Stage 3+ 添加 |

#### 3.5.2 预留总成本核算

补充 10 个接口预留后，总预留成本约为 **3 周**（在 Stage 0 的 12-18 周中占比 17-25%，与 [12-路线图 §2.8.1](./12-roadmap.md) 短期净影响「+6-10 周」口径相容——预留是其中回报率最高的部分）；不预留的代价是后期需要**数月级的破坏性重构**（P0 三项均为「重构 AST/IR/编译器架构」级）。

**最终接口预留策略**：
1. **P0 接口**（LSP、调试、增量）必须在 Stage 0 的数据结构中预留位置
2. **P1 接口**（FFI、后端、服务化）强烈建议在 Stage 0 预留 trait 定义
3. **P2 接口**（包管理、AI）建议在 Stage 1 预留
4. **P3 接口**（分布式效应）可在 Stage 3+ 添加

**核心原则（[17-设计原则 §1](./17-principles.md) 第 32 条「预留留白原则」的裁定表述）**：**接口预留的本质是「为未来留出空间」而非「提前实现」——它要求的是数据结构和类型定义的兼容性，而非功能的完整性。**

#### 3.5.3 接口预留层全景图（v6.1）

```mermaid
flowchart TD
    subgraph Core["语义核心（Stage 0-1 冻结 9 原语 / Stage 2 演进目标 8 原语形态 + 6 IR，不变）"]
        A[CoreExpr ADT]
        B[四层解耦架构]
        C[六 IR 层级]
    end

    subgraph Reserved["接口预留层（既有 4 项）"]
        D1[Effect 接口<br/>已预留]
        D2[能力令牌接口<br/>已预留]
        D3[多阶段接口<br/>已预留]
        D4[编译缓存接口<br/>已预留]
    end

    subgraph NewReserved["接口预留层（v6.1 新识别 10 项）"]
        E1[LSP/IDE 查询<br/>P0 需预留]
        E2[调试信息接口<br/>P0 需预留]
        E3[FFI 边界接口<br/>P1 需预留]
        E4[增量编译查询<br/>P0 需预留]
        E5[编译器即服务<br/>P1 需预留]
        E6[多目标后端<br/>P1 需预留]
        E7[包管理接口<br/>P2 需预留]
        E8[AI 辅助接口<br/>P2 需预留]
    end

    Core --> Reserved
    Core --> NewReserved

    F["接口预留原则：不实现但必须在数据结构中预留位置<br/>否则后期引入需破坏性重构"] -.-> NewReserved

    style A fill:#6f6
    style B fill:#6f6
    style C fill:#6f6
    style D1 fill:#ff6
    style D2 fill:#ff6
    style D3 fill:#ff6
    style D4 fill:#ff6
    style E1 fill:#f96
    style E2 fill:#f96
    style E3 fill:#f96
    style E4 fill:#f96
    style E5 fill:#f96
    style E6 fill:#f96
    style E7 fill:#f96
    style E8 fill:#f96
```

> 图中语义核心标注采用 [01-核心原语 §8](./01-core-forms.md) 收敛裁定口径（Stage 0-1 冻结 9 原语；8 原语形态为 Stage 2 演进目标）；E 组新增接口的优先级与成本明细见 §3.4/§3.5.1。

#### 3.5.4 后期修改代价分级判据（v6.4 增补——第九轮 Round 3）

「什么必须接口预留、什么可以完全推迟」的判别式精确化为**后期修改代价分级**——对 §3.4 预留矩阵与 §1.1 三层分类的判据强化（矩阵行不变，判据列显式化）：

| 类别 | 定义 | 后期修改代价 | Stage 0-1 策略 |
|------|------|------------|---------------|
| **必须实现**（A 类） | 自举运行所需最小功能（§2 十二能力） | — | ✅ 完整实现（可为极简版） |
| **接口预留**（B 类） | 数据结构/类型签名/契约（§3.4 的 14 项矩阵） | **重构级**（不可后期补救——改变数据结构 = 改变所有使用它的代码） | 📦 定义接口，实现可为占位符 |
| **完全推迟**（C 类） | 具体功能实现（§3.2 的 6 项推迟） | **增量级**（可后期添加——替换实现不改接口） | ❌ Stage 2+ 从零实现 |

**「数据结构不可变，实现可替换」**（判据的操作化表述）：类型签名一旦定义即永久不变（改变签名 = 修改所有构造处与模式匹配处）；实现可为占位符（类型签名正确即可被 Stage 2+ 无缝替换）。重构级代价链示例：Span 系统未预留 → 重构所有 AST 类型定义（每节点加字段 + 所有构造处传 span + 所有模式匹配更新）；原语集变化 → 重写整个编译器（脱糖/编译/求值/优化全部基于原语集）；效应签名缺失 → 重构控制流；能力签名缺失 → 重构 I/O 层；相位分离缺失 → 重构宏系统。

**时间口径调和**：第九轮的 Stage 0-1 估算（A ~6 周 + B ~3.5 周 + 测试 ~1 周 ≈ 10 周）与 §3.5.2 预留成本 ~3 周口径一致（B 类 3.5 周 ≈ 3 周——类目粒度差异：§3.5.2 按 14 项矩阵核算，第九轮按七类签名粗估）；完整能力矩阵 12-18 周口径不变，10 周为窄口径下界。

### 3.6 机制预留——接口预测悖论的解法（v6.4 新增——r57 第九轮 Round 4-5）

> §3.3-§3.5 建立了接口预留的完整清单（§3.4 矩阵——14 项预留 + 6 项推迟，「已知的洞」的结构位置冻结）；本节回答其上层问题：**对于无法预见的未来功能，「预留」这个概念本身如何成立？** 答案构成对既有预留体系的哲学补全（stage0.md §9.9 全量展开；原则 36/37 同步增补 [17 §1.1](./17-principles.md)）。

#### 3.6.1 接口预测悖论

```
前提 1：我想为未来的功能预留接口
前提 2：我不知道未来会出现什么功能
结论：我无法为「不知道的东西」预留接口
```

任何具体接口预留都基于「已知」，但「未知的创新」本质上不可预测——悖论**无法通过「更努力地预测」解决**（逻辑上不可能），只能通过**改变问题本身**解决：错误的问题（无解）=「预留哪些具体接口」；正确的问题（可解）=「设计什么机制使添加新接口不需要重构」。

#### 3.6.2 接口 vs 机制

| 维度 | 接口（特定预留） | 机制（打洞能力） |
|------|----------------|----------------|
| 本质 | 一个「特定的洞」 | 「打洞的能力」本身 |
| 预见要求 | 必须预见洞的形状 | 无需预见任何形状 |
| 实例 | `AsyncInterface` | `Perform(Custom) + Handle` |
| 覆盖范围 | 有限（已知的） | 无限（可计算的） |

类比：接口预留 = 楼预埋网线/电话/有线电视接口——光纤出现时预留不够，需打新洞破坏结构；机制预留 = 墙体本身是可打洞材质——任何新接口直接打洞。**从「接口思维」到「机制思维」= 不是预留所有可能的洞，而是让墙可以随意打洞。**

#### 3.6.3 三层未知防御与三种打洞能力（数学 + 工程 + 生态）

- **第一层——语义完备性（数学保证）**：原语集图灵完备 → 任何可计算功能 F 可表达 → F 的副作用可经 `Perform(Custom)` 表达、特殊控制流可经 `Handle` 表达 → 无需预见 F，F 已可表达（非「预留接口」，是数学保证）。
- **第二层——机制通用性（工程保证）**：Racket（`#lang` + 宏——30+ 种语言无一被预见）/ Koka（效应处理器统一 async/异常/状态/概率编程——全部经 Handle）/ Unison（abilities 承载分布式/数据库/流处理——全部经能力系统）。这些语言都没有预见这些应用——提供机制，用户用机制创造应用。
- **第三层——组合无限性（生态保证）**：机制可组合（效应 + 宏 + 能力 = 无限组合）；判定流程：X 可计算 → 第一层覆盖；需新副作用/语法/资源 → 第二层覆盖；纯组合 → 第三层覆盖；不可计算 → 非语言功能无需覆盖。

| 机制 | 覆盖的未知维度 | 机制保证 | 本项目实盘载体（对账） |
|------|--------------|---------|---------------------|
| **自定义效应**（`Perform(Custom) + Handle`） | 新副作用类型 | 编译器无需知道效应名与参数语义 | [01 核心原语](./01-core-forms.md) 效应原语 + [06 操作语义](./06-operational-semantics.md)——Custom 标签效应全语义链实盘 |
| **宏展开**（卫生宏，展开为核心原语组合） | 新语法形式 | 编译器只处理核心原语 | [03 宏系统](./03-macro-system.md)——syntax-rules 卫生宏引擎实盘（自举 expander.krf 同载体） |
| **能力系统**（`Capability` + 门控） | 新资源类型 | 新资源 = 新能力种类；fail-closed 门控 | [21 能力架构](./21-capability-architecture.md) L3 授权层——require 传递闭包 + 令牌态实盘 |

#### 3.6.4 哲学根基：抽象-具体分离与开闭原则（原则 37）

整个设计哲学收敛为「定义抽象而非具体，通过抽象概念与具体实施的分离实现」——即开闭原则（OCP：对扩展开放、对修改关闭）在编译器设计中的最纯粹体现。同一原理三次投影：OOP（依赖倒置/策略模式/开闭原则）；函数式（高阶函数/类型类/效应系统）；本设计（原语集 = 抽象——对修改关闭；宏/Handle/Capability = 分离机制——对扩展开放）。数学力量：具体 = 一个点（`AsyncInterface` 只覆盖 async），抽象 = 一个空间（`Perform(Custom) + Handle` 覆盖所有可能副作用构成的空间——async 只是空间中的一个点）——**抽象不是预测具体的未来，而是覆盖所有可能的未来构成的空间**。历史验证：Lisp/Racket（S 表达式 + eval/apply——60 年）/ Unix（文件描述符 + read/write——50 年）/ LLVM（IR 指令集——20 年）；共同模式 = **定义一个「足够小但足够完备」的抽象核心，然后让所有具体实现在核心之上组合**。

#### 3.6.5 真正的风险与边界（机制预留的诚实面）

真正的风险不是「无法预见新功能」，而是：

| 风险 | 场景 | 概率/影响 | 缓解 |
|------|------|----------|------|
| **原语集可能不再足够** | 量子（叠加/坍缩非经典控制流）/ AI 推理（概率分支）/ 分布式（位置透明） | 低/高 | `Perform(Custom)` 可模拟大多数新原语（性能可能不及硬编码）；极端情况添加第 9 原语——与 [22 新原语两判据](./22-namespace-design.md)（不可归约性 + 单层归属）同锚非无门准入 |
| **性能天花板** | 宏组合的「循环」比硬编码 while 慢 10 倍；Perform/Handle 开销大于直接调用 | 中/高 | MLton/GHC 全程序优化经验 + Koka 效应消除研究——需长期优化研究（[08 后端演进 §3](./08-backend-evolution.md) 语义极小化同型论据） |
| **人类认知天花板** | 「一切都是效应处理」过于抽象；宏+效应+能力调试困难 | 高/高 | 熟悉的表面语法 + 理解宏展开的 IDE 工具链 + 穿透宏展开的错误消息——§3.3.2 LSP 预留的需求侧证 |

三则风险均登记为 T3+ 触发式观察面（[23 演进治理 §2.2](./23-evolution-governance.md)——禁止无信号开窗；[t3plus-trigger-audit](../develop/v0/stage-3/t3plus-trigger-audit.md) 监测锚同源）。

#### 3.6.6 与既有预留体系的正交互补（收敛口径）

- **接口预留（§3.4，14 项矩阵——原则 32）**：防「已知需求」的破坏性重构——冻结数据结构位置
- **机制预留（本节——原则 36）**：防「未知需求」的不表达——保证任何可计算功能的表达通道
- 两者不可互相替代：机制预留不能替代接口预留（已知需求仍需结构位置——LSP 接口不预留则工具链无法免重构接入）；接口预留不能替代机制预留（任何 14 项清单都只覆盖清单制定时的已知世界——「无法预见」的那部分只能靠机制兑底）
- **收敛口径**：原语集表述按 [01 核心原语 §8](./01-core-forms.md) 收敛裁定口径（Stage 0-1 冻结 9 原语验证同一语义核心——机制预留论证不受 8/9 形态差异影响，图灵完备性与 Custom 效应通道不变）；「对修改关闭」的即刻含义 = 冻结原语集语义骨架在 Stage 0-1 期间不变，Stage 2 演进窗口沿用既有裁定

### 3.7 优化桥接——模式识别与等价替换（v6.5 新增——r58 第十轮）

> **第十轮（next6.md Round 1）核心增量**：极小原语组合的「模式」可被结构特征判据识别，经相等性标记替换为胖关键字等价物——复用 50 年成熟优化体系（方向 A）同时保留细粒度语义信息获得额外优化（方向 B），「A + B > 胖关键字」。本节为其在能力矩阵层的登记：性能天花板风险（[§3.6.5](#) 风险三则）的正面解法 + Stage 2 优化窗的优化策略设计输入（[17 原则 38/39](./17-principles.md) 同步）。阶段0 侧全量展开见 stage0.md §6.13。

#### 3.7.1 策略定位（双向桥接）

问题：极小原语语义完备但组合形态分散——宏展开后的 `while` 是 Y 组合子递归（[01 §6 糖展开完备性](./01-core-forms.md)），优化器看到匿名递归而非循环；胖关键字语义僵化但优化器看到命名模式（50 年优化研究对象）——性能天花板风险的根源。策略 = **模式识别作为通用适配器**：四步管线（模式匹配 → 等价标记 → 优化复用 → 额外优化）；不是「选择极小原语 or 胖关键字」而是「用极小原语作为内部表示，通过模式识别获得胖关键字的所有优化能力，同时保留极小原语的所有额外信息」。

#### 3.7.2 两种模式的识别判据（精确规格）

| 模式族 | 结构特征判据 | 等价标记 | 替换目标形态（接入的成熟优化） |
|--------|-------------|---------|----------------------|
| 循环（while） | ①自引用 Apply（Y 组合子递归）②Branch 为递归体入口（终止条件）③递归参数形成更新链（循环变量）④递归体无其他效应（纯循环） | `Loop { init, cond, body, exit, vars, metadata }` | LLVM phi 循环形式 → LICM 循环不变量外提 / SIMD 向量化 / 循环展开 / 强度削减 |
| 异常（try-catch） | ①Handle + 单一 Handler ②Handler 不 resume continuation（异常终止）③final 为恒等函数 | `Try { body, catch, metadata }` | landingpad 形式 → 零成本异常（正常路径零开销）/ 内联 / 跳转优化 |

**双向优化能力对照**：方向 A（复用胖关键字优化）六项——LICM / 向量化 / 循环展开 / 零成本异常 / 跳转线程化 / 函数内联；方向 B（胖关键字做不到，保留细粒度信息获得）六项——跨控制流融合（ANF 中每个 Let 可独立重组）/ 用户级控制流优化（Handle/Perform 可内联）/ 部分求值（Let 绑定可任意传播）/ 自动并行化（ANF 依赖关系完全显式）/ 自定义控制流优化（宏 + 效应 = 可编程优化）/ 细粒度指令调度（`Add(i, 1)` 可重排）。

#### 3.7.3 六阶段优化管线与识别器规格

Stage 0 用户代码 → Stage 1 宏展开（极小原语）→ Stage 2 ANF 转换（显式命名）→ Stage 3 模式识别（核心创新）→ Stage 4 等价替换（进入胖关键字优化体系，同时保留 ANF 细粒度信息）→ Stage 5 额外优化（融合/部分求值/细粒度调度）→ Stage 6 后端代码生成。识别器判定特征：`recognize_loop`（三判据合取 → `Option<LoopPattern>`）/ `recognize_try_catch`（三判据合取 → `Option<TryPattern>`）——**识别即替换**（单一 pass 的两阶段，非两个独立 pass——[17 原则 39](./17-principles.md) Pass 化）；识别器只需覆盖少量模式族（正交原语的组合模式空间小且规整——「语义极小化有利于长期性能」的实现路径）。

#### 3.7.4 与既有体系的对账（收敛口径）

- **性能天花板风险正面解法**：[§3.6.5](./13-capability-matrix.md) 风险三则中「宏组合的循环比硬编码 while 慢 10 倍」的缓解从定性论证（MLton/GHC 全程序优化可消除大部分组合开销）升级为工程化正面解法（组合模式识别回胖关键字等价物，直接接入全部成熟优化管线）；风险登记形态不变（仍为 T3+ 触发式观察面——本节为解法设计登记非实施）
- **打洞能力对账扩展**：[§3.6.3](./13-capability-matrix.md) 三种打洞能力的实盘对账新增第四行——**优化复用通道**（模式识别 + 等价替换——细粒度语义信息的优化兑付通道；实盘载体 = Stage 2 优化窗[ANF 层就位后]，当前 anf.rs PoC + IndexIR 为前置基座）
- **IR 四层修正案**：[15 §5.2](./15-architecture-layers.md) IR 层级演进对照的四层修正案注记（结构/语义/形式/目标四维正交——AnnotatedANF 标注并入 CoreExpr+元数据 / SSA 并入 ANF-SSA；与六层规划的差集论据开窗时按正交性验证表 + 性能实测裁定——原则 35）；实况三锚：typecheck E0005 + R9 E0006 在 CoreExpr（语义维度已实盘）/ IndexIR r48（形式维度 Closed 半面）/ SSA 未实现（修正案零重构成本窗口）
- **Stage 2 优化窗定位**：模式识别以 ANF 显式命名为前提（[15 §5.2](./15-architecture-layers.md) ANF 原子化半面 anf.rs PoC 承载）；优化 pass 管线四组（合并 pass / 胖关键字优化复用 / 独有优化 / 通用优化——EffectElimination = Koka 四阶段管线化）全在形式维度层上原地跑；零触发信号不开窗（[23 §2.2](./23-evolution-governance.md) 触发表单源——本节不新增监测行）
- **收敛口径**：原语集表述沿 [01 §8](./01-core-forms.md) 收敛裁定口径；本节为设计登记非实施（当前零实现——开窗内容）；与 stage0.md §6.13 同步

#### 3.7.5 性能潜力裁定与双轨策略（v6.6 新增——r59 第十一轮，同步自 stage0.md §6.13.3）

**偏见纠正（概念区分）**：性能潜力（理论上限——极小原语严格更高：信息更多 + 粒度更细 + 空间更大）与开发成熟度（当前表现——胖关键字占优：50 年 vs ~30 年研究投入）为两个正交概念——「性能可能稍低」类表述的混淆即系统性偏见；差距本质 = 研究投入差距非设计本质差距（可经策略消除与反超，非固有）。**该概念区分即刻生效为判据**：后续任何性能讨论（含优化窗裁定与实测对账）须先过此区分（[17 原则 38 v6.9 澄清](./17-principles.md)——原则 35 同族纪律）。

**双轨性能策略**：

| 轨道 | 内容 | 效果 | 状态 |
|------|------|------|------|
| **A：胖关键字优化复用**（「偷懒」——现成的不用白不用） | 模式识别 + 等价替换（本节 §3.7.1-§3.7.3 双向通道的方向 A） | 立即获得 50 年优化研究成果——**消除当前差距** | ✅ 成熟（接入对象直接可用） |
| **B：原语独有优化**（新的性能主要战场） | 细粒度信息 + 机制通用性（方向 B：跨控制流融合 / 用户级控制流优化 / 部分求值 / 自定义优化 / 效应消除 / 细粒度并行化） | 获得胖关键字永远无法实现的优化能力——**超越胖关键字上限** | 🚀 新兴（GHC/MLton/Koka 已初步验证） |

**原语独有优化六项验证状态**（轨道 B 生态成熟度证据——[19 §11](./19-references.md) 引证；原则 26 三级成熟度匹配的优化域投影：生产就绪[MLton 全程序优化] / 早期实践[GHC 流融合、Koka 效应内联、Racket 生态] / 研究前沿[自动并行化、MetaOCaml 部分求值]——轨道 B 六项的引入时机与处理程度按此分级匹配 [12 §2](./12-roadmap.md)）：跨控制流融合（GHC 流融合——初步验证） / 用户级控制流优化（Koka 效应内联——验证中） / 部分求值（MetaOCaml——理论验证） / 自动并行化（研究阶段） / 自定义优化 pass（Racket——生态验证） / 全程序优化（MLton——完整验证）。

**三阶段性能预期**（双轨策略兑付时间线——设计口径，非性能承诺）：短期（模式识别复用后）≈ 胖关键字水平 ~1/1.2 C（与 [08 §5.4](./08-backend-evolution.md) 性能演化路径 Stage 3 优化档对齐）；中期（原语独有优化开发后）特定场景 1/1.0 甚至超越；长期（全程序优化成熟后）MLton 级全程序优化 + 效应消除 + 原语优化 > 当前任何胖关键字语言——理论上限：保留完整语义信息的编译器的极限。预期不构成当前阶段验收标准（Stage 2 优化窗开窗时作为验收锚候选——实测对账；[23 §2.2](./23-evolution-governance.md) 触发表零新增行，单源纪律维持）。

**风险链路闭合**：[§3.6.5](./13-capability-matrix.md) 性能天花板风险（v6.4 登记）→ §3.7（v6.5 正面解法——模式识别 + 等价替换）→ 本节（v6.6 预期定量化——三阶段预期）；且风险本体修正：「性能潜力」侧实为偏见（潜力严格更高），真实风险面收窄为「开发成熟度」侧（研究投入差距）——双轨 A 消除之、B 超越之。

### 3.8 根空间统一组织——预留与拓展的概念骨架（v6.7 新增——r62 第十二轮，同步自 stage0.md §9.10）

**根空间定义**：预留与拓展能力的统一组织骨架——**概念性占位**（零语义载荷的存在性标记；Rust 形态 `#[marker] trait Extensible {}` 空 marker trait——编译期存在运行时零开销，符合原则 18 零生产开销）。语言自身即根空间，下辖三类空间：**编译器内部空间**（对修改关闭——Reader/Expander/Compiler/VM/Runtime，由原语构筑）、**拓展预留空间**（对扩展开放——**能力/效应/语法/优化/工具链/外域六大一级子空间**[v6.9 修订：五大→六大——外域独立裁定见 [24 §4.4](./24-space-decomposition.md)；优化域零成员不建代码面 marker（24 §4.6）]，可递归划分并可实例化）、**基石空间**（冻结原语集——构筑内部与拓展的**同一原料**：Reader 用 Fn/Apply 实现解析组合子、效应拓展 = Perform(Custom)+Handle——自相似[分形]结构：每层同基石，层级 0 根 → 层级 1 内部/拓展 → 层级 2 子空间 → 层级 3 实例）。**分形层级的代码面落位（v6.9/r65）**：[24-space-decomposition](./24-space-decomposition.md) 全文权威——层级公理 A1-A5 + 六域从属表 + 20 trait 逐级重挂修复表（r62 扁平挂靠[全部契约直挂根]升格为五级从属链 `trait 族: 域: ExtensibleSpace: ExtensibleRoot`；跨级直挂违例修复[用户点名 `CapabilityIO: ExtensibleRoot` → `CapabilityIO: CapabilityDomain`]）。

**双侧统一体系（v6.10/r66——[24 v2.0](./24-space-decomposition.md) 权威）**：根下辖两个一级子空间在类型面**双载体**——`RootSpace`（改名自 `ExtensibleRoot`——名实修复）→ `CoreSpace`（**核心空间显式化**：v6.9 前无载体无判据的叙事空间升格为闭集 marker + **七核心域**[语言/前端/编译/后端/执行/横切/组织——15 §5.3 五正交轴宏观归并；10 crate 主类型三层 impl]）+ `ExtensionSpace`（改名自 `ExtensibleSpace`）；拓展六域一改名（**语法域→元编程域** `SyntaxDomain`→`MetaprogrammingDomain`——语义自明 + 双侧「Syntax」歧义源消除）；层级公理扩至 **A1-A7**（+A6 开闭性[统一编码、分流治理——v1.0「闭集不设 marker」裁定推翻] + A7 全树统一与单一事实源[物理组织不承载空间语义——从属唯一判据 = marker impl]）；**做实面归属修复**（capability/effects/cache/ffi 做实类型 = 拓展空间 L4 种子实现——v6.9「做实面模块归核心」表述修正，A4 L1 层互斥恢复）；`CodegenBackend`/`WasmBackend` 零挂靠收编（挂 `CoreBackendDomain`——核心域首对契约）；骨架物理家迁移 **`kerf-space` crate**（依赖环唯一无损解）；层级深度自然差（核心四级/拓展五级 = 开闭性的结构表达）。

**三层预留体系全景**（自 v6.7 起的权威口径——[17 原则 40](./17-principles.md)）：

| 层 | 原则 | 防什么 | 形态 |
|---|---|---|---|
| 接口预留 | 原则 32（§3.4 14 项矩阵） | 已知需求的破坏性重构 | 具体的「点」位置冻结（数据结构/类型定义兼容性） |
| 机制预留 | 原则 36（§3.6 三种打洞能力） | 未知需求的不表达 | 「通道」（Custom 效应/宏展开/能力系统） |
| 根空间统一组织 | 原则 40（本节） | 预留碎片化与依赖具体化 | 「骨架」（所有点与通道都是根空间的子空间，经约束特化定义、经空间代数管理） |

**空间关系的数学本质（判据级口径）**：空间关系**不是类继承而是集合与组合**——用户裁定（next8.md Round 2 原文：「概念上方便理解可以说继承，但实质并不是，具备数学原理去解释」）。数学实质 = **约束特化 + 约束组合代数**：子空间 = 根约束 ∩ 附加约束（集合交集/约束合取）；组合两空间 = 求交集（独立约束合取无菱形问题——OO 继承的 IS-A 偏序树[名义子类型/实现耦合/菱形]被约束的格[结构子类型/交/并/偏序——任意两元素唯一交并]替代）；实例归属 = 集合成员关系（`instance ∈ Space ⟺ 满足全部约束`）；Rust trait 的数学本质对齐：`trait A: B` = A 的约束包含 B 的约束（`A = B ∧ 附加约束`，即 `A ⊆ B`）——supertrait 是约束合取非实现继承（多 trait 组合无菱形 = 既有工业实证）。引证 [19 §12](./19-references.md)（Birkhoff 格论 / Cook Inheritance Is Not Subtyping / Pierce TAPL / Reynolds）。

**预留接口的依赖方向裁定（v6.7 新增判据——预留层 DIP 投影）**：预留接口必须**依赖抽象根空间而非具体实现类型**。反例（用户识别的缺陷形态）：预留接口直接依赖具体类型（如 `AsyncInterface`）——未来具体实现任何变更破坏全部预留点，且只覆盖「点」不覆盖「空间」。正解：预留接口依赖根空间 marker（或对应子空间约束）——具体实现经「满足约束」归属于空间，预留点零破坏演进（空间不动点动）。**此判据为 §3.4 14 项矩阵全部预留接口的审计依据（r62 代码面）**；实测对账见 reserved.rs 依赖方向审计（worklog 106-a）。

**与既有文档的关系（指针互链不越权）**：组织层权威 = 本节 + stage0.md §9.10；能力层投影 = [21 §2.6](./21-capability-architecture.md)（L0-L3 四层 = 根空间下按约束维度的一级子空间划分实例；J1-J4 = 子空间约束独立性的可审计判据——J2 效应-语义独立即「效应约束与语义约束正交，交集可自由组合」的格论投影）；术语十二条 = [18 §5g](./18-terminology.md)；原则 = [17 原则 40](./17-principles.md)；被否决的类继承组织形态登记于 [14 §4.8](./14-design-alternatives.md)（否决记录保留——原则 35 纪律）。

**收敛口径**：§3.2 冻结定义不变；本节为组织层设计登记（概念骨架——零语义载荷，不新增原语/关键字/语法，向后兼容纯增补）；根空间代码面落位（既有 14 项预留接口的依赖方向审计与矫正）依 [23 §2.2](./23-evolution-governance.md) T3+ 治理与用户显式指令裁量；「8 原语」表述沿 stage0.md §6.12.6 语义等价映射。

### 3.9 双向调试策略与脚手架哲学（v6.8 新增——r63 第十三轮，同步自 stage0.md §9.11/§9.12）

> **定位**：工程能力定位文件（本节——能力矩阵视角的归类与挂接）；调试策略权威 = [11 §5](./11-testing.md)；脚手架生命周期权威 = [12 §2.11](./12-roadmap.md)；判据语境 = [17 原则 41 脚手架哲学统一纪律](./17-principles.md) + [原则 38 模式识别桥接](./17-principles.md)（用途扩展）。**设计登记态**——双向调试 Stage 2+ 实现窗口（与 §3.7 优化桥接同窗）；优化脚手架拆除 Stage 4+（上游蓝图演进视角——项目侧治理依 [23 §2.2](./23-evolution-governance.md) T3+ 触发表）。

**双向调试 = §3.7 优化桥接的第二用途（矩阵挂接而非新行）**：[§3.7](#37-优化桥接模式识别与等价替换v65-新增r58-第十轮) 登记的模式识别与等价替换（原用途：性能——识别模式→标记等价→接入胖关键字优化管线）在本轮获得第二种用途（调试——识别模式→以胖关键字形式展示宏意图等价物）。**不新增矩阵行**，而是在两行既有登记上挂接：

| 既有矩阵行 | 挂接内容 | 处理程度影响 |
|---|---|---|
| §3.3 调试信息接口（P2 冻结签名——DebugInfoGenerator/DebugTraceable） | 双向调试是调试信息接口的**调试器侧消费者**（五级视图切换的 Level 3/4 支撑——ANF-SSA/目标码视图消费调试信息契约） | 维持 P2（实现窗口 Stage 2+——与 LSP 同窗） |
| §3.7 优化桥接（Stage 2 优化窗登记——模式识别 + 等价替换） | `for_optimization` 之外新增 `for_debugging` / `switch_view` 双用途面（模式数据库不复制——零额外基础设施四组件统一：模式识别器/等价替换/Span/IR） | 维持 Stage 2+ 窗口（双重用途不提前窗口——同一实现窗） |

**五级调试视图**（工程能力全景——[11 §5](./11-testing.md) 权威）：Level 0 用户源码 / Level 1 胖关键字视图（粗粒度——宏意图等价显示）/ Level 2 原语组合（细粒度——8 原语树 + 每节点 Span）/ Level 3 ANF-SSA（优化级）/ Level 4 目标码（机器级）；用户可在任意 Level 间自由切换（每次切换 = 模式识别 + 打包/拆包）。与 [15 §5](./15-architecture-layers.md) 四层 IR 对齐（Level 0 = 表面语法、Level 1-2 = CoreExpr 面、Level 3 = ANF-SSA、Level 4 = 目标码）；数据结构骨架（ViewLevel/DebugView/ViewRepresentation/ViewMapping）为设计登记（Stage 2+）。与现有调试技术对照：传统宏调试（只回 Span 无宏意图）/ GHC -ddump-simpl（一次性不可交互）/ Racket macro-debugger（只展开无等价物）/ LLVM -opt-bisect（只在 LLVM 层）——本设计五级视图交互切换全覆盖（引证 [19 §13](./19-references.md) 93-95）。

**脚手架哲学 = 既有三种借用物的统一生命周期纪律（治理判据而非新能力）**：[原则 41](./17-principles.md) 将三种「现实条件约束下的临时借用」登记为脚手架（显式声明 + 生命周期 + 拆除判据 + 可回滚——与依赖锁定的辨异特征）：

| 脚手架 | 既有矩阵/文档挂接 | 搭建（Stage） | 拆除（Stage） | 拆除判据 |
|---|---|---|---|---|
| 语法脚手架（S 表达式） | [15 §2](./15-architecture-layers.md) Layer 0 + [02 §2](./02-syntax-model.md) Reader | Stage 0（1 周极简 Reader） | Stage 2（自举完成后换目标语法——Stage 2a/2b 拆分裁定） | 新 Reader 产生相同 CoreExpr（验证锚） |
| 信任脚手架（Rust 宿主） | [07 自举策略](./07-bootstrap-strategy.md) 全文 | Stage 0（全部用 Rust 实现） | Stage 2 完全拆除（全自举）+ Stage 3+ 仅保留构建种子 | [07 出口条件](./07-bootstrap-strategy.md)（渐进替换非一次性） |
| 优化脚手架（胖关键字优化） | [§3.7](#37-优化桥接模式识别与等价替换v65-新增r58-第十轮) + [§3.7.5](#375-性能潜力裁定与双轨策略v66-新增r59-第十一轮) 双轨策略 | Stage 3（模式识别接入现有优化） | Stage 4+ 逐个拆除（原语优化成熟后——**逐个替换非一次性**） | 自建替代 ≥ 被替换物 × 98% 或额外能力 > 0 + fallback 保留可回滚 |

**与 §3.7.5 双轨策略的终局关系**：三阶段性能演进（借用→并行→拆除）= 轨道 A 复用 + 轨道 B 独有的终局形态——阶段 3 拆除即轨道 A 退役 + **模式识别器保留转调试用途**（与双向调试双重用途闭环——优化脚手架拆除后其模式识别资产转为 [11 §5](./11-testing.md) 调试基础设施）；§3.7.5 三阶段性能预期（短期 ~1/1.2 C / 中期 1/1.0 / 长期全程序优化上限）与本三阶段一一对应（短期 = 阶段 1、中期 = 阶段 2、长期 = 阶段 3）。

**收敛口径**：§3.2 冻结定义不变；本节为能力矩阵视角的归类登记（零原语/关键字/语法变更，向后兼容纯增补）；双向调试与优化桥接同窗 Stage 2+（当前零实现零信号不开窗——[23 §2.2](./23-evolution-governance.md) 红线 3）；脚手架拆除为 Stage 4+ 上游演进视角（项目侧治理依 T3+ 触发表——拆除判据 ≥98%/额外能力为判据级登记，Stage 2+ 优化窗裁定材料的后续批次）；「宏系统调试困难」风险（[11 附录 B 风险表](./11-testing.md)）的缓解策略自此从「强大的 Span 系统 + IDE 支持」（定性）升格为「双向视图切换 + 零额外基础设施」（架构性方案）。

---

### 3.10 错误统一效应模型与目标语言设计蓝图（v6.11 新增——r81 第十四轮，同步自 stage0.md v7.3 §9.14/§9.15）

> **本节定位**：next10.md 第十四轮吸收的能力矩阵面收编——错误处理能力与目标语言设计的能力面登记。**零代码变更；设计登记态**（Stage 2+ 表面语法切换窗 #15 门控 + 语义演进窗）。

**错误处理能力行（目标态登记）**：错误处理 = 效应系统能力（L2 层——[21](./21-capability-architecture.md)）的 Error 子空间实例，非独立能力维度——统一而分治（[17 原则 42](./17-principles.md)）：统一模型（Perform/Handle + EffectRow + HandlerClause + 效应消除 + EffectSpace 五面）+ 分治策略（Error[恢复/终止/传播]/Async/State/IO 各配 handler）；传统机制替代表七项（try/catch/throw→移除[标准库宏]；异常层级→子空间层级；栈展开→continuation 管理；panic→Fatal 效应；Result→Error 项可选表示[值级/效应级对偶]；?→传播宏）。**目标语言设计能力面**：六维身份定位 + 语法成员全糖化 + 渐进披露四层（[17 原则 43](./17-principles.md)）+ 生态扩展六维（EffectSpace/CapabilitySpace/SyntaxSpace/OptimizationSpace/ToolingSpace/ForeignSpace——五维修正补全外域，与 [24 §4.1](./24-space-decomposition.md) 拓展域六域一一对应）。**实况对账（R4）**：Stage 0 当前 = Effect Handlers M1-M5 已交付（§2.5.1 行——r25 静态收敛面）+ HM 多错误收集生产（r75/r80——编译期信息系统实例，与运行时 Error 效应正交——stage0.md §9.15.6①）；Error 效应族/官方六效应/try-catch 宏/行多态效应行 = Stage 2+ 登记态。

### 3.11 效应本体论与空间接口契约（v6.12 新增——r84 第十六轮，同步自 stage0.md v7.5 §9.17）

> **本节定位**：next11.md 第十六轮吸收的能力矩阵面收编——效应本体论理论 + 极简关键字 + SpaceContract 接口契约的能力面登记。**零代码变更；设计登记态**（Stage 2+——#15 门控）。

**效应本体论能力行（目标态登记）**：效应理论演进（标注式 → 容器式 → 概率域式 → 生命周期式）= 解释框架层能力（理论档案——[17 原则 45](./17-principles.md) 同轮注册）；机制层（Perform/Handle/Resume + 效应帧栈）与现有效应系统 100% 兼容——**能力矩阵零新增行、零修改行**（「同一系统两种描述」裁定：理论深化不产生新能力需求）。**极简关键字能力面**：目标语言 17 关键字（结构 4/绑定控制 4/类型 2/效应 3/能力 2/其他 2）+ 十二项传统关键字效应替代 + 宏层熟悉语法（try!/async!/while!/for! 标准库宏）——宏系统承载「熟悉语法」能力（[03](./03-macro-system.md) 宏层文法分区协同）+ 渐进披露四层的初学者面载体；与 Stage 0 实现语言 25 关键字正交分层（R4——Stage 0 是脚手架语法非目标语言形态）。**类型与效应标注语法能力面**：容器式签名 `fn f() -> Return(T) | E` 终态草案（方案 A `+ {Error}` 被否决——二元分离残留教训）——类型推断能力的 Stage 2+ 扩展锚（HM → 效应行多态——[19 §17](./19-references.md) E.17-115/116 Damas-Milner/Rémy 文献锚）。

**SpaceContract 接口契约能力面（目标态登记）**：空间理论的形式化接口——space_id（唯一标识）/ parent_space（A3 唯一从属承载）/ capabilities（能力声明——与 [21](./21-capability-architecture.md) 能力架构对齐）/ register_member + lookup_member（成员注册查询）/ communicate_with（空间间通信——SpaceMessage 含 TypeWitness 类型安全见证，与 01 约束组合跨空间传递同构）。**对账**：SpaceContract = [24 §4](./24-space-decomposition.md) 六域（根/核心/拓展/域/契约/类型）的接口面投影——文档侧理论已有层级与公理 A1-A7；契约形式化 = 实现就绪度的接口规格（Stage 2+ 登记态，[24 §14](./24-space-decomposition.md) 同轮收编）。**二义性审理能力面**：三策略（Reject/RequireDisambiguation/PriorityRule）= 目标表面语法的语言设计能力（#15 切换窗定稿义务组成——与 [22 §19](./22-namespace-design.md) 术语消歧正交分立：术语二义 = 文档层「一词多义」；语法/语义二义 = 语言层「一形多解」）。

## 4. 三个待定决策的前置架构约束（原 §15）

| 决策 | 前置架构约束 | 预期解决时机 |
|------|-------------|-------------|
| **并发内存模型** | IR 中共享内存访问必须显式标记为 `SharedLoad/SharedStore`，Stage 0 保守视为 SeqCst | Stage 3 |
| **错误运行时语义** | VM 栈帧必须预留 3 个扩展槽（continuation/异常/调试） | Stage 2 |
| **FFI 所有权模型** | 分配器必须包含 `register_foreign_ref` 等接口（Stage 0 可为 no-op） | Stage 2 |

> 本节的三个待定决策（运行时语义的未决项）与 [12-路线图 §2.6](./12-roadmap.md) 的三个关键决策点（能力模型选型的权衡）是不同层面的问题，二者的区别详见该文件。


---

### 3.12 效应流形能力面与空间协议运行时（v6.13 新增——r88 第十七轮吸收，同步自 stage0.md v7.6 §9.18.6）

> **本节定位**：next12.md 第十七轮吸收的能力矩阵面收编——流形连接的能力面登记 + SpaceRegistry 空间协议 + SpaceValidationPass 编译期强制。全节 Stage 2+ 设计登记态（能力行目标态——非 Stage 0/1 变更义务）。

**流形连接能力行（目标态登记）**：三连接（串联/嵌套/循环）在 8 原语中可表达——串联 = `Let(Handle)`（A 的 resume 触发 B 的 perform）/ 嵌套 = Handler 内 Handle / 循环 = 递归 + 双 handler（交替触发）——**能力面零新增**（Perform/Handle/Resume 既有能力承载全部连接形态；[17 原则 46] I-A：零新增原语零机制层变更义务）。EffectGraph/流形分析 Pass（MergeSequential/HoistNested/DetectLoop 优化机会）为编译期分析能力——登记于 [05 §8](./05-runtime.md)（运行时面）与 Layer 2→3 优化窗（Stage 2+ 素材）。

**SpaceRegistry 空间协议（接口面与协议面互补——目标态登记）**：register_space（三验证：父空间存在/不与同级重叠[正交性]/不跨层级引用）+ discover（按名称/按能力/按父空间查询）+ compose（正交验证 → 约束交集 + 能力并集）+ SpaceDefinition（id/parent 必须直接父/capabilities/interfaces）+ ComposedSpace。**与 §3.11 SpaceContract 六接口的关系**：Contract = **单空间**接口规格；Registry = **空间间**注册/发现/组合协议——接口面与协议面互补分立。

**SpaceValidationPass 编译期强制（目标态登记）**：四验证——①每 AST 节点唯一空间归属（space_id 非空）②空间层级链完整 ③同级空间正交（overlap 检测）④效应容器类型正确（payload 验证）。**Stage 0-1 实况对账**：现行 IR 无节点级 space_id——登记为 Stage 2+ IR 增量设计义务（与预留留白纪律一致——预留空间而非提前实现）。

**流形诊断能力行（目标态登记）**：EffectDiagnosticContext kind 四枚举（UnhandledEffect/EffectMismatch/IncompleteHandler/ResumeTypeMismatch）+ 流形扩展五类（IncompleteConnection/NonTerminatingCycle/InvalidSliceDimension/UnsafeLift/UnsafeProject）——诊断类型学与流形语法面（connect/lift/project）的窗内联动义务（若三语法入目标语言则对应诊断生效）。

**审查注记**：坐标系/地图裁定与七维度/七步坐标的空间论完整展开见 [24 §15](./24-space-decomposition.md)；设计宪法五定义见 [stage0.md §9.18.2](../stage0.md)。



### 3.13 逆向效应与计算干涉能力面（v6.14 新增——r89 第十八轮吸收，同步自 stage0.md v7.7 §9.19.4/§9.19.6/§9.19.8）

> **本节定位**：next12.md 追加段的能力矩阵面收编——逆向/干涉/坍缩能力行（目标态登记）+ InterferenceAnalysisPass 编译期能力。全节 Stage 2+ 设计登记态（能力行目标态——非 Stage 0/1 变更义务）。

**逆向能力行（目标态登记——能力面零新增）**：逆向三操作 = 正向三原语使用模式——Consume = Perform(Receive) / Offer = Handle 服务提供模式 / Rewind = Resume 多播形态（[17 原则 47] J-A：**零新增原语零机制层变更义务**——8 原语闭合三轮验证）。逆向不可替代性判据 = **知识不对称**（全局解不可分解为局部解组合 `f(x₁..xₙ) ≠ g₁(x₁)∘...∘gₙ(xₙ)` 时必须逆向）——四能力域登记：全局共识与仲裁（ConsensusEffect）/ 迭代收敛（ConvergeEffect——不动点求解）/ 事务原子性（AtomicTransactionEffect）/ 确定性资源回收（ResourceLifecycleEffect）。

**干涉能力行（目标态登记）**：计算干涉 = 共享资源的经典非对易性结构（`[A,B]_R = A∘B(R) ⊖ B∘A(R)` ≠ ∅ 时干涉）——三模式（构造性增强/破坏性抵消/纠缠关联）+ 计算不确定性原理（非对易 Handle 无法同时确定效果——必须选择顺序[坍缩]）；零新增原语（干涉 = Handle 组合的自然结果）。**InterferenceAnalysisPass**（Stage 2+ 编译期能力登记）：四步——共享资源识别 → 非对易对检测 → 干涉记录 + ComputationalUncertainty 诊断 → 优化三分支（try_merge_constructive / try_eliminate_destructive / try_parallelize_entangled）；与 §3.12 流形分析 Pass 的关系 = 同一 EffectGraph 素材三 Pass 分立（流形/干涉/坍缩调度——正交职责）。

**坍缩能力行（目标态登记）**：伪随机坍缩 = **Randomness 效应**（语言级效应面——next/with_seed/uniform/normal/exponential/weighted_choice/shuffle 操作集 + PCG32 实现锚 [19 §19]）+ CollapseScheduler 运行时（轮盘赌加权选择 + deterministic_select 传统模式）；**与 Stage 0 最小 I/O 实况分立裁定（J-E）**：伪随机源非运行时内建全局函数——策略外置（测试确定性 vs 生产熵源由 handler 决定）；登记为 Stage 2+ std 效应族候选（[09-标准库] 联动）。应用四能力域：负载均衡 / 退避重试 jitter / 概率数据结构（Bloom）/ 蒙特卡洛模拟。

**异步/并发/协程能力面（应用域登记——Stage 2+ 并发设计素材）**：七优势登记（无函数染色 / 无特殊关键字 / 执行策略外置 / 正逆统一 / 并行数学保证 / 组合性 / 优化空间）+ 三应用形态（生成器 Generator：yield 正向 / next 逆向；Actor = 长期运行 Offer；Map-Reduce = 正向分形 + 逆向聚合）——kerf Stage 0-1 无并发实现（实况对账），登记为层次 5 应用面素材。

**审查注记**：逆向/干涉/坍缩三子空间的完整空间归属见 [24 §16](./24-space-decomposition.md)；双向 Continuation 运行时面见 [05 §9](./05-runtime.md)；正逆五规则 + 干涉四规则见 [06 §11](./06-operational-semantics.md)。

---

### 3.14 拓扑与量子能力面（v6.15 新增——r91 第十九轮吸收，同步自 stage0.md v7.8 §9.20.2/§9.20.6）

**8 原语不变性第四轮验证（能力面裁定）**：理论层 0（8 原语定义）/ 层 1（Return=效应 无变化）/ 层 2（流形/正逆 用现有原语表达）/ 层 3（拓扑/曲率 = 分析工具非新原语）/ 层 4（波粒/量子 = 理论扩展非原语扩展）——**8 原语闭合四轮验证链**（r84 载体映射 + r88 流形映射 + r89 逆向/干涉/坍缩映射 + r91 波粒/量子/拓扑映射），§3.2 冻结 9 原语不动。

**拓扑能力行（Pass C——组合拓扑精确同构，K-A 第一级）**：H₀ 连通分量（并行化机会/独立性分析）/ H₁ 一维洞（效应循环 → 死锁检测/循环依赖/资源循环）/ H₂ 二维洞（空腔盲区）/ 上同调（守恒量检测——闭合非恰当观测）/ 基本群 π₁（路径同伦等价 → 优化等价性/竞态条件判定）/ 欧拉示性数 χ=V−E+F（全局结构分类）——图/单纯复形上可精确计算（E.20-124 Edelsbrunner & Zomorodian 持久同调锚）；ManifoldAnalysisPass 五决策（死锁检测/并行化/非对易性/守恒律/拓扑简化）为 Stage 3 素材。

**量子能力行（Pass D——隐喻登记维持 J-B/K-B）**：干涉图样计算（EffectPathIntegral——枚举语义）/ 纠缠检测（贝尔不等式诊断性守卫——经典关联必然 ≤ 经典上限，`QuantumAdvantage::Present` 不可达分支 = 守卫代码形态）/ 路径积分（NP-hard 风险 → 近似/启发式）/ 波粒二象性分析（EffectNature 三态——描述转换）；效应纠缠规则枚举（AllOrNothing/Majority/Correlated/自定义）= 事务/共识语义类型面登记（Stage 3+）。

**五 Pass 分立全景（能力面总图——r91 首次成型）**：Pass A 基础优化（Stage 0-2）/ Pass B 流形分析（Stage 2-3）/ Pass C 拓扑分析（Stage 3）/ Pass D 量子分析（Stage 3+ 可选）+ r89 干涉坍缩 Pass——各自正交职责；理论-实现分层映射（K-F：五层理论 vs 四阶段实现）采纳为理论登记默认层级视图（「理论全覆盖，实现分阶段」）。

**审查注记**：EBNF v5 分层语法（Level 3-4）见 [02-语法模型 §8.8](./02-syntax-model.md)；量子登记态子空间归位见 [24-空间正交分解 §17](./24-space-decomposition.md)；Pass D 运行时面见 [05-运行时 §10](./05-runtime.md)。

---

### 3.15 能力-效应协同接口与八维度正交（v6.17 新增——r93 第二十轮吸收，同步自 stage0.md v7.9 §9.21.3）

> **本节定位**：next14.md Doc2 数学优先正交分解的效应面收编——效应模型八维度正交分解 + 与能力模型的唯一协同接触面。零代码变更；判据登记。同步：[21 §10.2](./21-capability-architecture.md)、[17 原则 49](./17-principles.md)。

**效应模型八维度**（Doc2 精确定义）：定义三层（集合论 `Effect = (Action × Mechanism × Payload × Continuation)` / 范畴论 Perform = 态射 e: C→E、Handle = 态射 h: E→R、Resume = 态射 r: R→C' / 流形 = 效应流形上的激发点）+ 性质 P1-P6（过程性/方向性/可组合性/可观测性/干涉性/对偶性）+ 能力 C1-C8 + 职责 R1-R3 正向与 R4-R6 NOT（**不描述值[Payload] / 不做权限检查[能力模型职责] / 不做类型检查[类型系统职责]**——与 §3 既有 NOT 职责行同族）+ 控制（Handle/Resume/Halt/Pass）+ 协同（EffectRow 类型注解 / Cap-gates-Effect 能力 / Payload 值 / 模块效应签名四接口）+ 变化（状态/组合/维度/方向 + 不变量）+ 边界（上 = 一切计算流形态变化 / 下 = 值·类型·权限·资源本身）。

**正交性验证与唯一接触面**：与能力模型职责集不相交——唯一邻接对 Effect.R2「HOW to handle」vs Capability.R2「WHETHER allowed」分立 = 正交成立；**协同接口 = `Perform(e) requires Capability(e)`**（本矩阵 §3 既有 E0006 能力门控行 = 该接口层次 1 的生产形态——r25 io 门控起 + r38-r41 批次 M 组合闭包 E0006 增强；语料为既有实现补全数学完备性[函子 F: Effect→Capability + 类型式 `perform E : (Capability E) → Effect E`]）。**8 原语不变性第五轮验证**（承 §3.14 第四轮）：全部 14 能力操作 = Perform/Handle 使用模式——零新原语。

### 3.16 生命周期效应化能力面（v6.18 新增——r94 第二十一轮吸收，同步自 stage0.md v8.0 §9.22.2/§9.22.3）

> **本节定位**：next15.md 生命周期效应化理论的效应面收编——生命周期 = 资源的时间效应（理论载体第八环，资源时间维补全）。零代码变更；判据登记。同步：[21 §11](./21-capability-architecture.md)（资源能力族与四模型协同）、[02 §8.10](./02-syntax-model.md)（EBNF v7）、[24 §19](./24-space-decomposition.md)（子空间归位）、[17 原则 50](./17-principles.md)。

**生命周期效应化理论（LC-A）**：传统语言将生命周期作类型系统独立维度（借用检查器 + 省略规则 + `'a` 标注 + Drop——四机制并列）；效应化理解 = **生命周期 = 资源存在的时间效应**——`ResourceLifecycle<T>` 四操作（`acquire() -> linear ResourceHandle<T>` / `use(handle) -> T` 可多次 / `release(handle)` / `transfer(handle, to)`）全 Perform 使用模式——**8 原语不变性第六轮验证零新原语**（承 §3.14 第四轮 + §3.15 第五轮）。**作用域 = Handle 语义**：with_resource 函数形态（Return 臂释放后返回 / Error 臂释放后传播——RAII 效应化 / use·transfer 臂透传 resume）。

**借用 = 效应的组合与干涉分析**：Borrow 效应族三操作——`immutable_borrow` 可复制非线性（共享多借共存）/ `mutable_borrow` 线性 use-once（独占）/ `return_borrow` 归还；线性性差异承载共享/独占语义分野（集合论层面严格）。**冲突检测 = 效应干涉分析**（§3.13 既有计算干涉能力面的资源域实例——Immutable ∩ Mutable ≠ ∅）：三处置策略 handler 外置（拒绝/等待/排队——与 handler 值级组合自由一致）。

**LifecycleAnalysisPass（LC-B）**：Koka 效应消除迁移——三 Stage 管线（效应分析→干涉分析[借用检查]→效应消除[优化]）+ 五 Phase 完整算法（收集→构建效应流→验证规则三[Acquire 前置/悬垂引用/线性流]→借用干涉→消除优化）+ **消除三形**：FullElimination（简单作用域零开销）/ PartialElimination（静态借用）/ Optimized（动态可约化）——**Stage 2+ 优化窗 pass 候选**（§3.7 优化域矩阵新行候选——零信号不开窗；效应分析管线单点性风险 + 缓解三策略[分层/多级缓存/双模式]登记——**乐观仅限性能优化域，安全域[E0006 能力门控]恒保守 fail-closed**）。**kerf 实况对账**：效应行收集 Stage 0 已生产（effect_row 测试族）；E.22-130 Tofte-Talpin 区域效应系统 = 「生命周期=效应」的 1997 学术同构先例锚。

---

### 3.17 流形统一分析能力面（v6.19 新增——r95 第二十二轮吸收，同步自 stage0.md v8.1 §9.23.2/§9.23.3/§9.23.4）

> **本节定位**：next15.md Document 4 流形统一分析的能力面收编——分析的统一场论（理论载体第九环：所有分析 = 同一效应流形上的投影/切片）。**本轮零语法零原语零 EBNF 增量**（纯分析架构文档——EBNF v7 六份骨架存量维持，8 原语不变性第七轮验证 = 历次最轻量轮）。

**流形分析六投影（MU-E——零新分析类）**：①类型投影（类型检查）↔ EffectRow 类型注解[LC-E 接口契约形 1]；②干涉分析（借用检查）↔ 借用=干涉分析[LC-A + J-B]；③拓扑分析（优化机会）↔ 连通分量/循环检测优化[流形三连接 Tier 1]；④生命周期分析（资源管理）↔ LifecycleAnalysisPass[LC-B 五 Phase]；⑤曲率分析（顺序敏感性）↔ 交换子/非对易干涉[r89 计算干涉]；⑥同调分析（死锁检测）↔ H₁ 循环检测[Tier 2 + 循环连接]。Stage 门控：Stage 0 = 六分析中 ①② 已有雏形（效应行收集 + E0006 门控——**已交付**）；③-⑥ = Stage 2+/3+ 愿景位（K-F 五层理论 vs 四阶段实现分层既有——统一流形分析中心 = Stage 3+ 愿景层档案）。

**Pass 数据结构单源纪律（MU-B——Stage 2+ 优化窗设计约束即刻生效）**：任何分析 Pass 不得引入自有中间表示——操作统一流形对象[查询]或产出变换[流形→流形]；**三级单源体系**：IR 单源[CoreExpr] + 分析单源[流形对象] + Pass 变换纪律；传统 Pass 间 IR 转换的信息丢失 = 反例登记。与 r91 K-F 五 Pass 分立全景（EffectTrace/LifecycleAnalysis/Capability/Interference/SpaceValidation）同构确认——五 Pass 候选皆设计为流形对象上的分析查询。

**MU-C 八项映射表（K-A 分级——零越级）**：连通分量→并行化[Tier 1 图算法精确同构] / H₀→独立任务[Tier 2 DEC——图连通分量计数的数学上溯] / H₁→循环死锁[Tier 2 DEC] / 欧拉示性数→复杂度度量[Tier 2 叙事级] / 曲率→非对易[Tier 3 叙事维持——真实判据由交换子承载] / 联络→传播路径[Tier 2 叙事级] / 外微分→涡旋[Tier 3] / Stokes→资源守恒[Tier 3——真实配平 = LC-B 规则三]。缓解策略新增近似拓扑[Stage 3 研究项——性能域不违 fail-closed] + 分级[用户可配置分析深度]。


### 3.18 效应容器类型系统能力面（v6.20 新增——r96 第二十三轮吸收，同步自 stage0.md v8.2 §9.24.2/§9.24.3/§9.24.4/§9.24.6）

> **本节定位**：next16.md 四文档效应容器类型系统与类型观测理论的能力面收编——#15 讨论主线第十三次用户行权（类型观测面理论收束——理论载体第十环·五线程族完备）。**零代码变更；能力面定位与判据登记**（TY-A..TY-F 六裁定中能力相关面的承载本体；理论全量见 [stage0.md §9.24](../stage0.md)）。同步注册：[17 原则 52](./17-principles.md)、[18 §5s 术语](./18-terminology.md)、[24 §21 TypeSystemSpace 归位](./24-space-decomposition.md)、[21 §11.2 五接口契约化深化](./21-capability-architecture.md)、[02 §8.11 EBNF v8](./02-syntax-model.md)、[19 §24 E.24 文献](./19-references.md)。

**类型系统 = 横切静态验证层（TY-A 定位裁定）**：「类型系统不做任何事，它**验证**其他系统声明的事」——效应签名追踪[效应系统被类型追踪]/线性强制[能力系统被类型强制 Linearity 四级：Linear 恰好一次（能力消耗语义）/Affine 至多一次（Rust 位——q3 锚精确认辨）/Shared 多次（不可变借用）/Unrestricted 无约束]/时间边界验证[生命周期被类型验证 LifetimeBounds{acquire,release,uses,topology}——全为 EffectKind]/数据形状描述[值系统被类型描述]——**验证者非执行者 + 零运行时原语**（8 原语不变性第八轮验证：类型检查器编译期消费流形对象，Perform/Handle 签名被追踪但不改原语集）。

**CoreType 类型代数十一构造子（能力相关面）**：Capability{kind, **metric, linearity**}（能力度规类型——r93 CAP-C 承接：metric = 度规的类型描述 + linearity = 线性性标注）+ EffectUnion{effects, rest}（开放效应集——效应行）+ Function{params, **returns: EffectUnion**, manifold_constraints}（返回 = 效应并集——Return 容器语义[r74 原创贡献 2]）——能力类型/效应类型/函数类型三构造子为能力-效应-类型三模型接触的类型面承载。

**类型推断 = 流形约束求解（TY-C）**：ManifoldTypeInferencer 五步（标记观测点→收集约束→迭代求解→构造→验证）六约束类中 **Capability{required, available}**（能力约束类——check_capability_constraint 编译期检查+消耗）与 Effect{required,provided}（效应约束类）两类 = E0006 能力门控 fail-closed 的理论完备化；**InferenceStrategy 四形安全域裁定**：Dynamic/Progressive/Hybrid 仅限性能优化域与表达力域——**安全域[能力/线性/悬垂检查]恒 Static fail-closed**（r94 LC-F 裁定的四策略推广）。kerf 实况：hm.rs HM 生产[r80] + typecheck.rs + 效应行收集 = Stage 0 已交付基座；流形求解器 = **Stage 2+ pass 候选**（MU-B Pass 数据结构单源纪律适用——不提前实现化）。

**五接口协同与接口计数纪律（TY-E）**：模型间接口恰五（效应↔类型 EffectRow / 效应↔能力 Cap-gates / 效应↔生命周期 ResourceLifecycleEffect / 能力↔生命周期 ResourceCap / 类型↔能力 LinearType——**与 §3.15 唯一接触面 + 21 §11.2 五形逐项同构零漂移**）；接口计数纪律：自反一致性[类型↔类型]为内部性质不占计数 + 类型↔生命周期经效应中介传递（6 边取 5 直连——接口最小化正交）；职责边界矩阵十二行（vs r94 十行 + 「追踪效应签名」「观测流的形状」两类型核心行——HOW vs WHETHER 正交判据 CAP-B 的类型行扩展）。

**8 原语不变性第八轮验证 + 五线程族完备**：类型系统 = 静态投影/验证层零新原语（v7.3→v8.2 八轮链——原则 27 加性演化理论侧重演第八次）；理论载体第十环（类型观测化）——五线程族完备：效应七环 + 能力环[§3.15] + 生命周期环[§3.16] + 分析环[§3.17] + **类型环[本节]**——四模型能力线程 + 分析收束线程全齐（原创贡献 16/17 新登记：类型=效应流的观测描述 + 类型推断=流形约束求解）。

---

## 附：next2 前沿整合对照注记（v5.5）

next2 讨论的整合决策矩阵与 [12-路线图 §2.1.1](./12-roadmap.md) 三档成熟度逐项一致（行多态/效应安全 Stage 2、线性类型 Stage 1 **已兑现 r8 基础传递**、多阶段 Stage 2+ 实验 P3 一致、依赖类型/会话类型/Cubical 忽略一致）。**唯一增量**：编译期求值（comptime，Zig/Mojo 生产就绪档）——登记为批次 E 后的 Stage 1+ 引入主题（常量折叠/宏展开编译期执行的演进方向），是多阶段编程 P3 预留的**务实前身**（comptime 证明「用语言自身写元编程」可行后再评估 MetaOCaml 式类型化多阶段）。核心原语层的效应原语化（Perform/Handle）对照见 [01-核心原语 §7.3](./01-core-forms.md)。

## 3.19 信息效应能力面（v6.21 新增——r111 第二十六轮吸收，同步自 stage0.md v8.5 §9.27.2/§9.27.7）

**能力矩阵增量一行**：

| 能力 | 处理程度 | 阶段 | 依据 |
|------|---------|------|------|
| 信息效应族（用户侧 log/metric/debug 自定义效应） | **P0 接口就绪**（自定义效应机制既有——effect_decl 产生式承载零实现增量） | Stage 2+（std InfoEffect 族候选）/ 用户即刻可用（自定义效应通道） | INFO-C 三分域 + Randomness r89 同族候选 |

**能力面零违例登记**：①信息效应**不触发能力门控新增**（用户 log/metric = 无能力要求的普通效应——与 E0006 门控面正交；若未来 std InfoEffect 族定义输出能力要求则循既有 Cap-gates 通道——零新机制）；②观测/投影指令（observe/project）= 工具链层查询（Level 4 归位——**非语言能力矩阵成员**）；③8 原语不变性第十轮验证（零新增原语——能力操作集[14 操作 r93]零增量维持）；④六线程族（+信息）**零新模型间接口**（信息经 EffectRow 既有接口承载——五接口计数不变[r96 接口计数纪律]）。上游全量 = [stage0.md §9.27](../stage0.md)；接口注记 = [21 §11.4](./21-capability-architecture.md)。

## 3.20 自由度-约束对偶能力面（v6.22 新增——r113 第二十七轮吸收，同步自 stage0.md v8.6 §9.28.3 洞察三/§9.21 CAP-C 对偶面）

> 本节登记流特性理论 FLW-B-3（随机种子 = 自由度）在能力模型侧的对偶面完备化注记——**零能力域新增零门控变更**（既有核心七域 + E0006 能力门控原样维持）。

**对偶关系（CAP-C 对偶面完备化）**：能力 = 约束（ℝᴺ→ℝᴹ 减少自由度——度规约束子空间投影）↔ 随机种子 = 自由度（∅→ℝᴺ 提供随机性）；最终行为 = 能力约束 ∩ 随机种子（允许范围内随机演化）。三行为预言（叙事层——Lotka-Volterra 收敛三机制 r93 CAP-E 的对偶面表述）：强约束可预测 / 无约束混沌 / 适度约束创造性。

**Freedom 四级谱系（理论登记）**：Zero（完全确定）/ Finite（有限集合内随机）/ Infinite（连续空间随机）/ Constrained{original, constraint, remaining}（能力约束后剩余自由度）——与 Linearity 四级谱系（r96 TY-A）同形的分级修辞。DimensionalSeed{dimension × freedom × randomness × evolution_coupling} = 维度化随机能力登记（理论层——非运行时结构）。

**「不确定性第三形态」术语纪律**：Freedom×Constraint≥Constant 不等式 = **隐喻性叙事层**（无 ℏ 类常数定义——非严格数学不等式）；数学实质 = **自由度计数恒等式** TotalFreedom = ConstrainedFreedom + RemovedFreedom（E.28-159 相空间约束计数先例 N−2M−S——约束削减自由度是计数恒等）。与既有两形态的关系：①r89 计算不确定性（干涉非对易 [A,B]≠0——真不等式形态）②r91 EffectUncertainty（波粒二象性两形态）③本轮自由度-约束对偶（计数恒等 + 叙事不等式）。**使用纪律**：效应文档族使用「不确定性原理」时须恒附「第三形态·叙事层」限定注（术语消歧义务——原则 45 沿袭）。

**实施面承接**：Randomness 效应 + PCG32（r89 既有——Stage 0 已交付）；DimensionalSeed/FlowTheory 理论结构体 = Stage 3+ 分析愿景登记态（流形分析族——未来入分析层须过 MU-B Pass 单源纪律）。

## 3.21 统一流分析与描述论能力面（v6.23 新增——r115 第二十八轮吸收，同步自 stage0.md v8.7 §9.29.2/§9.29.4/§9.29.5）

> **本节定位**：next20.md 统一流分析 + 描述论的能力面登记——**零能力域新增**（既有七核心域单源维持 + 8 原语不变性第十二轮验证零新原语零通道）。

- **描述论能力面（约束描述含自由度分量）**：能力 = **约束描述**（含自由度的随机分量）——约束+自由的双重维度（约束 = 度规可能性边界 + 自由度 = 随机种子分量）——§3.20 自由度-约束对偶（r113 CAP-C 对偶面）的**表述纪律升级**：「能力是时空度规」→「能力是约束描述」（实体主义→观测主义——描述论五描述修正表之一）；**机制层豁免**：能力门控机制（E0006 fail-closed + Cap-gates 唯一接触面）为机制事实非描述——表述纪律仅适用于理论叙事层。
- **借用 = 流干涉投影能力面**：Mutable 借用 = 线性能力（独占——一次一个）/ Immutable 借用 = 共享能力（多个共存）——§3.15 CAP-B 八维度正交的借用面重述；借用检查 = 能力度规的干涉规则投影（统一流分析 UFA-A 工程统一面——Stage 2+ 分析窗登记态）。
- **哥德尔第二定理信任根能力面**：编译器无法完全验证自身（类型检查器/效应分析/流分析的自指限制三例）→ BS-E trusting trust 三机制（可审计种子 + parity oracle 链 + fixpoint 确定性）= **缩短非消除信任链**——第二不完备定理 = 信任链不可归零的数学根源；外部验证根（CompCert 需 Coq / kerf VM 永久 Rust 基座）= 能力边界的能力面注记（「完全自举 VM 重写」宪制排除项的哲学层背书）。
- **能力描述不完备的具体体现**：能力度规无法捕捉所有约束 → 运行时权限检查的存在理由（E0006 既有实证——编译期能力门控的不完备性由运行时 fail-closed 兜底）——哥德尔第一定理↔间隙性的四具体体现之一（能力面实例）。

## 3.22 递归深度处理能力面（v6.24 新增——r117 第二十九轮吸收，同步自 stage0.md v8.8 §9.30.2 [原则 58 / REC-A]）

- **既有三防护能力确认（零新增能力域）**：递归深度处理 = 既有生产能力的实况登记——Reader 深度帽 `MAX_NESTING_DEPTH = 256`（FS-1 实测锚：2MiB 测试线程栈 ~600 层溢出 → >8× 裕量 + 结构化错误 fail-closed + **下游 expander/compile/eval 同形树递归同帽统一覆盖**）/ HM 生成预算 512（A6 语义不变——超预算子树结构化诊断）/ VM 帧数帽（TD-023 堆帧栈域——失控递归运行时守卫 + 尾递归 O(1) 帧）。
- **能力归属分层**：编译期防御（Reader 帽 + HM 预算——[04 §3.1](./04-bytecode-vm.md) 四层谱系）与运行时防御（VM 帧数帽）分立——两者均 fail-closed（结构化诊断非崩溃——「优雅的错误报告不是崩溃」）。
- **备选能力登记态**（无消费信号不开窗——r70 §5.2 六步前置清单沿袭）：流式渐进解析（内存 O(深度)——matklad 事件流先例 E.30-166）/ OverflowPolicy 非形（Lazy 惰性延迟 / Compress 压缩 / HeapEscape 堆逃逸）——均为理论备选谱系，实况恒 Error 形。
- **效应流天然解决（语料方案 4）= 理论叙事层**：递归 = 效应流嵌套的表述归解释框架层（K-F 沿袭）——「perform 不创建栈帧」= 实现策略面非效应语义必然（OCaml 5 堆分配续延先例 E.30-165）；统一流分析愿景（r115 §3.21）的递归面重述，非能力域新增。
- **8 原语不变性第十三轮验证**：递归处理全部由既有机制承载——零新原语零通道零 VM 零语法（能力矩阵零新增行——本轮纯实况对账确认）。

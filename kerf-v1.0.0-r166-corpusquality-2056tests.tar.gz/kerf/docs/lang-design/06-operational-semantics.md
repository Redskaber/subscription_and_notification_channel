# 操作语义形式化定义

> **Author**: kerf-doc-agent
> **Date**: 2026-11-22（**v6.13——r157 / 227-b2 设计文档残留清偿窗：§2 规则族 lambda 时名清偿（r43 后内核关键字面 fn）+ Stx 内核形记号桥（设计单源 design-docs-modernization-plan.md v1.0 U2——D2 判据 J2/J3）**）；2026-10-30（**v6.12——r117 第二十九轮吸收（next21.md）**：§16 递归的流形统一叙事注记——同步自 stage0.md v8.8 §9.30）；2026-10-10（**v6.8——r91 第十九轮吸收（next13.md）**：§12 波粒二象性语义注记[解释框架层第六环 + Perform=坍缩/Handle=弥散描述转换 + EffectUncertainty 两形态]——同步自 stage0.md v7.8 §9.20.4）；2026-10-10（**v6.7——r89 第十八轮吸收（next12.md 追加段）**：§11 逆向效应与计算干涉类型规则[正逆组合五规则 + 干涉感知四规则 + 计算不确定性原理语义登记]——同步自 stage0.md v7.7 §9.19.4/§9.19.5）；2026-10-10（**v6.6——r88 第十七轮吸收（next12.md）**：§10 效应流形操作语义与类型推断算法[14 推理规则全集 + 小步语义 + 效应行合一算法 + 8 原语映射与 Return final:Var(0) 裁定]——同步自 stage0.md v7.6 §9.18.4）；2026-10-09（**v6.5——r84 第十六轮吸收（next11.md）**：§9 效应本体论概率域视角注记[归约视角对应读法 + 确定性维持 + 等价改写方向注记]——同步自 stage0.md v7.5 §9.17.4）；2026-10-01（**v6.4——r81 第十四轮吸收（next10.md）**：§8 错误统一效应模型与 one-shot 纪律登记[归约规则视角统一模型 + resume 至多一次纪律 + Stage 2+ 义务追加方向]——同步自 stage0.md v7.3 §9.15；[17 原则 42](./17-principles.md) 同轮注册）；2026-09-24（**v6.3——r67 原语集真值对账轮**：§1.1 语义域换现行九原语（r25+r45+r49+r50-β 终态）+ §2 头部规则对账注记 + 规则头换现行名（R1/R5/R8）+ R6/R7/R9 过去形态标 + **R12 Let 归约规则补写**（r45 原语缺位）+ S1/S2 记号换现行表面 + §5.4/§7 效应已交付注记）；2026-09-11（v6.2：批次 F 深审回写——值域补符号值（十变体）+「逐字段一致」措辞限定（作用域元数据增补）；v5.2：值域补 Unit（#14）+ App 求值顺序双路径修复后确认（#13）+ 测试锚点随负测扩张同步）
> **Version**: v6.13（**r157 / 227-b2**：U2 时名清偿 + 记号桥——纯文档轮零代码变更，[design-docs-modernization-plan.md](../develop/v0/stage-3/design-docs-modernization-plan.md) v1.0）；v6.12（**r117 第二十九轮吸收——§16 递归的流形统一叙事注记**[理论统一 = 叙事层 K-F 沿袭 + 「perform 不创建栈帧」= 实现策略面裁定 + 三防护实况——零归约规则变更零通道增量]）；**r115 第二十八轮吸收——§15 统一流分析语义注记**[借用检查=流干涉投影 + NLL 段结束推导 + 六规则族登记态——零归约规则变更零通道增量]）；v6.10（**r113 第二十七轮吸收——§14 时间性与坍缩语义注记**[固定vs确定观测维度阶 + 时间性四命题物理层重述——零归约规则变更零通道增量]）；v6.9（**r111 第二十六轮吸收——§13 信息效应语义注记**[归约规则零新——既有 Perform/Handle 实例化 + 观测只读查询与归约正交 + one-shot 沿袭——同步自 stage0.md v8.5 §9.27]）；v6.8（r91 第十九轮吸收——§12 波粒二象性语义注记[第六环 + 两形态不确定性]；v6.7（r89 第十八轮吸收——§11 逆向效应与计算干涉类型规则；v6.6（r88 第十七轮吸收——§10 效应流形操作语义与类型推断算法[14 推理规则全集 + 小步语义 + 效应行合一算法 + 8 原语映射与 Return final:Var(0) 裁定]；v6.5（r84 第十六轮吸收——§9 效应本体论概率域视角注记；v6.4（r81 第十四轮吸收——§8 错误统一效应模型与 one-shot 纪律；v6.3（**r67 原语集真值对账**——归约规则面与 01 §2 现行九原语对齐[代码为准 R4]；R12 Let 补写；R6/R7/R9 退役为过去形态）；v6.2
> **Status**: Active（规范锚点，冻结）
> **处理程度**：P0（必须实现——Stage 0 已落地）｜ **所属 Stage**：Stage 0 定义、全生命周期冻结 ｜ **推迟项**：并发内存模型语义（Stage 3，[13-能力矩阵 §4](./13-capability-matrix.md)）

> 本文件是理论边界层的规范锚点。stage0.md 原 §13.4 仅以一句承诺提及「9 个核心原语的完整小步操作语义与编译正确性定理」而未展开——本文件将该欠账补齐：以 Stage 0 已冻结的实现（`kerf-core` 的 `CoreExpr` 9 原语、`kerf-vm` 的 `eval` 双路径）为**提取源**，给出完整的小步结构化操作语义（SOS）归约规则、错误吸收语义、GC 不可观测性引理，以及编译正确性定理的精确陈述与证明纲要。九个原语的代数数据类型定义见 [01-核心原语 §2](./01-core-forms.md)；编译侧的指令布局见 [04-字节码 VM §2](./04-bytecode-vm.md)；定理的运行时验证载体（双执行路径互查）见 [11-测试基础设施 §2.4](./11-testing.md)。设计原则依据见 [17-设计原则 §1 原则 8](./17-principles.md)（语义形式化）与原则 9（核心冻结）；小步操作语义的标准形式化方法参考 Pierce《TAPL》，见 [19-参考文献 §3.5](./19-references.md)。

---

## 1. 语义域的形式定义

### 1.1 语法域（归约的对象）

归约规则的左端对象是展开产物 `CoreExpr`（[01-核心原语 §2](./01-core-forms.md) 的九个正交原语）。九原语与 `literal_value` 的定义在 Stage 0 已冻结（`kerf-core/src/expr.rs`）：**现行九原语（v6.3/r67 对账——r25 效应 + r45 Let + r49 声明层 + r50-β Do 脱糖后终态）= `Fn / Apply / If / Var / Literal / Assign / Let / Perform / Handle`**；`Define / Require / Module` 为 `ModuleItem` **声明层**项（r49——非归约对象，声明面零归约规则[01 §6 两层不合流]）；`(do ...)` 为表面糖（脱糖为 `Let` 恒定名 discard 模式——§2 R12 注）。r13 作用域集解析（TD-004）为 `Var`/`Assign`/`Fn`/`Let`/`Handle` 增补作用域集元数据字段（v6.2 措辞限定维持：属位置/解析元数据而非语义字段；时名 VarRef/SetBang/Lambda 见 §2 头部对账注）。**`quote` 不独立成原语**——Reader 将 `'x` 简写读取为 `(quote x)`，Expander 将其归约为 `Literal`（点对结构在 `literal_value` 中承载；符号 datum 归约为 `Literal(Symbol)`（r5）），故 quote 的语义即 R4（字面量恒等归约）。

### 1.2 运行时域

```text
v   ::= #n | #f | nil | unit | ⟨s⟩ | ⟨z⟩ | (v . v) | ⟨λ(x₁…xₙ).e, ρ, C⟩ | b | κ        值（κ = continuation——r25/42-f）
ρ   ::= ∅ | ρ[x ↦ v]                                                        环境（词法链）
C   ::= 共享捕获单元格组（Rc<RefCell<Value>> 槽的有限序列）                   闭包捕获描述
σ   ::= (H, R)                                                              堆（对象集 H 与根集 R）
b   ::= 内置函数句柄（driver 注册，见 [09-标准库 §2](./09-stdlib.md)）
```

- **值 `v`**：布尔、整数、浮点、字符串、**符号**、nil、**unit**、点对（堆分配）、闭包（`⟨λ(x₁…xₙ).e, ρ, C⟩`：代码 + 定义环境 + 捕获单元格组）、内置函数——与 `kerf-vm/src/value.rs` 的 `Value` 变体一一对应（v6.4 补 `continuation`：`Value::Continuation(Rc<ContinuationValue>)` 为挂起计算的运行时形态（r25/42-f——捕获帧链 + 数据栈快照 + 恢复点 + 线性唯一性标记三要素 + 实现必要补充；`render` 为 `#<continuation>` 不透明形态；GC 六来源见堆注记）；v6.2 补 `symbol`：`Value::Symbol(Rc<str>)` 为 quote 符号 datum 的运行时形态（TD-002 r5，按名相等——`eq?` 同名符号相等），此前文档停在九变体口径；v5.2 补 `unit`：`Value::Unit` 是「未定义返回值」的占位值，与 Nil 语义区分以支持未来的多值/效应扩展——deep-review R1 偏差 #14）。
- **环境 `ρ`**：有限映射，实现为词法父子链（`Env::child / lookup / define / set`）。`lookup` 沿链向父级搜索；`define` 在**当前**层新增绑定；`set` 修改链上**已有的**绑定（未绑定则失败）。
- **堆 `σ`**：点对等对象在堆上分配；根集 `R`（**六来源**：VM 栈、帧局部槽、帧捕获槽、全局环境、外部登记引用、**活跃 continuation 帧**（r25/42-f M5——continuation 携带的帧链槽与数据栈快照经 `Value::Continuation` 递归枚举），见 [05-运行时 §3.2](./05-runtime.md)）决定可达性。

### 1.3 求值状态与判断

小步归约作用在**求值状态**三元组 `⟨e, ρ, σ⟩`（表达式 / 环境 / 堆）上：

```text
⟨e, ρ, σ⟩ → ⟨e', ρ', σ'⟩          一步归约（状态内焦点归约）
⟨e, ρ, σ⟩ → Err(ε)                错误吸收（终止，见 §3）
⟨e, ρ, σ⟩ ⇓ v                     多步归约到值（→ 的自反传递闭包）
```

**求值顺序契约（编译与求值器共享）**：`App` 的**被调函数先求值**，随后实参**从左到右**求值（`kerf-vm/src/eval.rs` 与 `kerf-compiler` 的生成顺序双侧一致，[04-字节码 VM §3](./04-bytecode-vm.md)）；`Begin` / `Module` 体按源序求值。该顺序是定理 T1 的归纳基础之一——两条执行路径若顺序不同则互查不可判定。

> **v5.2 修复后确认（deep-review R1 偏差 #13，P1）**：曾存在「eval 函数先 / 编译参数先」的双路径分裂（compile.rs 旧实现参数先入栈、自注「被调者最后」——与本文 A1 契约冲突，构成 T1 反例面：`((undefined-a) undefined-b)` 双路径可观测报错分歧）。Task 16 依「设计为优」（Racket 惯例 + T1 一致性，[17-设计原则 §1 原则 9](./17-principles.md) 正确 > 妥协）修复编译侧：compile.rs App 分支改为 fn 先入栈 + vm.rs `CALL` 弹序对调，双侧与本文 §1.3/§2 A1 完全对齐。回归锚点：编译单测 `app_evaluates_fn_then_args_left_to_right`（字节码序断言）+ 集成 `app_evaluation_order_fn_first_dual_path`（vm_tests 双路径错误排序负例——错误排序场景双路径同报首个求值错误）。

---

## 2. 九原语的小步归约规则

> **v6.3/r67 规则集对账注记（编号保留历史锚——正文交叉引用稳定）**：R1-R9 建立于 r18 时点原语集（时名 Lambda/App/VarRef/SetBang/Begin + 当时的 Define/Begin/Module 语义原语位）。现行对应：**R1→`Fn`、R2→`Apply`、R3→`If`、R4→`Literal`、R5→`Assign`（S1/S2 记号已换现行表面）、R8→`Var`**；**R6（Define）自 r49 起声明层项——归约退役为过去形态**（顶层锚定由 `ModuleItem::Define` + `DefineGlobal` 编译承载；函数体 define 由展开器提升为 assign+fn 组合）；**R7（Begin）自 r50-β 起 `do` 脱糖为 `Let`**——序列归约现由 R12 承载；R9（Module）同为 r49 声明层项；R10/R11（Perform/Handle）现行有效；**R12（Let）为 r45 新原语的归约规则缺位补写（r67）**。规则体内行文保留历史词根处不再逐一改写——以本注记对账为准。
>
> 记号：`ρ[x ↦ v]` 表示环境扩展/更新；`σ ⊕ o` 表示堆分配对象 `o`；规则按原语编号 R1–R9；辅助规则 βv / δ / E0–E8。每条规则标注实现锚点（冻结源码位置），保证规范与代码互相锚定（[17-设计原则 §1 原则 8](./17-principles.md)：语义形式化是正确性的**可验证**规范）。

> **记号桥（r157 / 227-b2）**：本节规则的左端形式以 **Stx 内核形**书写（Reader 产物的 datum 表示——r43/E5 S2 后关键字面 `fn`/`assign`/`do`；时名 Lambda/SetBang/Begin 见 [01-核心原语 §2](./01-core-forms.md) 对账注）。用户面现代形对照（皮肤字典 [20 §14](./20-surface-conventions.md)）：`(fn (x) e)` ↔ `fn (x) { e }` 或闭包 `|| (x) { e }`；`(assign x v)` ↔ `x = v;`；`(let ((x v)) b)` ↔ `let x = v; b`；`(define x e)` ↔ `define(x, e);`；`(perform e)` ↔ `perform e;`；`(handle τ ((p k) e_h) e_b)` ↔ `handle e_b { τ(p, k) => e_h }`。归约对象恒为展开产物 CoreExpr（[01-核心原语 §2](./01-core-forms.md) 九原语）——表面形仅为可读性记法。

### R1 Fn（闭包构造——捕获定义环境）（历史名 Lambda——r44 同词根化）

```text
(L1)  ⟨(fn (x₁…xₙ) e), ρ, σ⟩ → ⟨⟨λ(x₁…xₙ).e, ρ, ε⟩, ρ, σ⟩
```

（记号行已换现行内核关键字面 `fn`——r157/U2 时名清偿；历史时名 `lambda` 见 01 §2 过去形态条例④）闭包在**构造时**快照定义环境 `ρ`（词法作用域）。闭包捕获的**可变**绑定（`Assign` 作用域链上的变量——时名 SetBang）经共享单元格 `C` 实现读写共享——两条执行路径的捕获协议等价性是定理 T1 的关键引理（L3，§5.2）。

### R2 App（应用——call-by-value，从左到右）

```text
(A1)  ⟨e_f, ρ, σ⟩ → ⟨e_f', ρ, σ'⟩
      ⟹ ⟨(e_f e₁ … eₙ), ρ, σ⟩ → ⟨(e_f' e₁ … eₙ), ρ, σ'⟩          函数先求值

(A2)  ⟨eᵢ, ρ, σ⟩ → ⟨eᵢ', ρ, σ'⟩   (e_f 已是值, e₁…e_{i-1} 已是值)
      ⟹ ⟨(e_f v₁ … v_{i-1} eᵢ … eₙ), ρ, σ⟩ → ⟨(e_f v₁ … v_{i-1} eᵢ' … eₙ), ρ, σ'⟩

(A3)  βv 规约（闭包应用）：
      ⟨(⟨λ(x₁…xₙ).e, ρ_c, C⟩ v₁ … vₙ), ρ, σ⟩
      → ⟨e, ρ_c[x₁ ↦ v₁, …, xₙ ↦ vₙ], σ⟩                          参数数量 ≠ n 时走 E2

(A4)  δ 规约（内置函数应用）：
      ⟨(b v₁ … vₙ), ρ, σ⟩ → ⟨δ(b, v₁…vₙ), ρ, σ'⟩                  δ 语义见 [09-标准库 §2](./09-stdlib.md)；
                                                                    σ' 含 δ 的堆效应（如 cons）
```

实参绑定方式为**新帧子环境**（`ρ_c` 的 child），非原地覆盖——递归闭包与外部引用互不干扰。`arity` 不匹配（E2）是**硬错误**而非默认值填充（§2.1.1 原则：报错 > 静默）。

### R3 If（分支——truthy 显式化）

```text
(I1)  ⟨(if #t e_t e_e), ρ, σ⟩ → ⟨e_t, ρ, σ⟩
(I2)  ⟨(if #f e_t e_e), ρ, σ⟩ → ⟨e_e, ρ, σ⟩
(I3)  ⟨(if v e_t e_e), ρ, σ⟩ → Err(TypeMismatch)   当 v ∉ {#t, #f}
(I4)  ⟨(if e_c e_t e_e), ρ, σ⟩ → ⟨(if e_c' e_t e_e), ρ, σ'⟩   当 ⟨e_c, ρ, σ⟩ → ⟨e_c', ρ, σ'⟩
```

**truthy 语义显式定义**：条件必须是布尔值；整数、nil、点对一律不参与真值判定（对比 Scheme 的「除 #f 外皆为真」——kerf 的选择是「类型安全优先」原则 [17-设计原则 §1 原则 21](./17-principles.md) 的直接落地）。I3 在编译侧对应 `JumpIfFalse` 的类型检查陷阱（[04-字节码 VM §3](./04-bytecode-vm.md)）。

### R4 Literal（字面量恒等——含 quote 语义）

```text
(L4a) ⟨k, ρ, σ⟩ → ⟨k, ρ, σ⟩                 标量字面量已是值（Int/Float/Bool/Nil/Str）
(L4b) ⟨(v₁ . v₂)_{lit}, ρ, σ⟩ → ⟨(v₁ . v₂), ρ, σ ⊕ (v₁ . v₂)⟩   点对字面量在堆上构造
(L4c) quote 归约（展开期完成，非运行时规则）：
      (quote e) ⟼ Literal(e)                数据即代码——'x 读作 (quote x)，展开为字面量
```

点对字面量（quote 产物）的**构造期**在求值时（`eval_literal` 在堆上递归构造）；其**内容**在归约后不可变（不存在对字面量点对的变更原语——变更仅经 `Assign`[时名 SetBang] 作用于变量绑定）。

### R5 Assign（赋值——仅已有绑定）（历史名 SetBang）

```text
(S1)  ⟨(assign x v), ρ, σ⟩ → ⟨v, ρ[x ↦ v], σ⟩        当 x ∈ dom(ρ)（沿词法链——时名 set!）
(S2)  ⟨(assign x e), ρ, σ⟩ → ⟨(assign x e'), ρ, σ'⟩   当 ⟨e, ρ, σ⟩ → ⟨e', ρ, σ'⟩（先求值右部）
      ⟨(assign x v), ρ, σ⟩ → Err(UnboundVariable)    当 x ∉ dom(ρ)
```

赋值沿**词法链**定位目标层（`Env::set`）；返回值为被赋的值。对闭包捕获变量的赋值经共享单元格对**所有**捕获方可见（L3 引理的形式对象）。

### R6 Define（定义——新增绑定）【过去形态——r49 声明层：归约退役】

```text
(D1)  ⟨(define x e), ρ, σ⟩ → ⟨e, ρ, σ⟩ 先求值右部；
      ⟨(define x v), ρ, σ⟩ → ⟨v, ρ[x ↦ v]_{顶层}, σ⟩   在当前环境层新增绑定
```

**（v6.3/r67）**：`Define` 自 r49 起为 `ModuleItem` 声明层项——顶层锚定由 `DefineGlobal` 编译承载（S1/E3 vs D1/E6 语义分裂，[04-字节码 VM §1]）；本规则保留为历史归约形态。**两位置语义**（Expander 裁定，[03-宏系统 §4](./03-macro-system.md) 陷阱 3）：模块顶层 `define` 为声明项；函数体内部被展开器提升为 `assign` + 预绑定（`letrec` 推导——时名 SetBang）。`define` 不可重定义已绑定符号（重复定义走 E6）。

### R7 Begin（序列——值为末项）【过去形态——r50-β do 脱糖为 Let，归约由 R12 承载】

```text
(B1)  ⟨(begin), ρ, σ⟩ → ⟨nil, ρ, σ⟩
(B2)  ⟨(begin v e₂ … eₙ), ρ, σ⟩ → ⟨(begin e₂ … eₙ), ρ, σ⟩   值丢弃（副作用经 S1 已发生）
(B3)  ⟨(begin e₁ … eₙ), ρ, σ⟩ → ⟨(begin e₁' … eₙ), ρ, σ'⟩  当 e₁ 非值且可归约
```

**（v6.3/r67）**：序列语义现由表面 `(do ...)` 脱糖为 `Let`（恒定名 discard 模式——与原序列逐指令全等，22 §17.3 D61）承载——见 R12 注。规则保留为历史归约形态（时名 begin）。

### R8 Var（变量引用——词法链查找）（历史名 VarRef）

```text
(V1)  ⟨x, ρ, σ⟩ → ⟨ρ(x), ρ, σ⟩                   当 x ∈ dom(ρ)
(V2)  ⟨x, ρ, σ⟩ → Err(UnboundVariable)           当 x ∉ dom(ρ)
```

### R9 Module（模块——Stage 0 单模块裁定）【过去形态——r49 声明层】

```text
(M1)  ⟨(module m (import …) (export …) e₁ … eₙ), ρ_g, σ⟩
      →* ⟨v, ρ_g', σ'⟩     其中 ρ_g' = 归约序列 e₁…eₙ 对 ρ_g 的累积效应；
                            import/export 在运行时无归约动作（编译期由 ModuleRegistry 处理，[03-宏系统 §1](./03-macro-system.md)）
```

**（v6.3/r67）**：`Module` 自 r49 起为 `ModuleItem` 声明层项（编译单元组织——驱动器项面消费）；下述 Stage 0 裁定的单模块求值叙述保留为历史形态。**Stage 0 裁定**：模块体在全局环境 `ρ_g` 直接求值（单模块世界）；`declare / visit / instantiate` 三操作的完整相位语义与传递依赖先行次序属编译期簿记，不在小步归约中显现。多模块实例化隔离（每模块独立命名层）推迟至 Stage 1+（[12-路线图 §2.5](./12-roadmap.md) 演进矩阵）。

### R10/R11 效应执行与处理（r25/42-f 新增——effect-language-design §2.2）

```text
(R10-perform)   ⟨(perform e), ρ, σ⟩ →* ⤴ e'       其中 e →* v = (⟨tag⟩ . v_p)：
                                                 控制转移（⤴ 记号——非值归约），
                                                 tag = 符号分派键；挂起点帧链/数据栈
                                                 快照入 continuation κ
(R10-resume)    ⟨(κ v), ρ, σ⟩ → ⟨e_κ, ρ_κ, σ_κ⟩   κ 恢复：挂起帧链 + 数据栈整栈还原，
                                                 v 即 perform 表达式的值（resume 脱糖
                                                 为调用形态——D4；线性唯一：二次恢复 = E0008）
(R11-handle)    ⟨(handle τ ((p k) e_h) e_b), ρ, σ⟩
                  → ⟨e_b, ρ, σ ⊕ handler帧[τ ↦ (e_h, ρ)]⟩   安装：帧栈压入（浅处理——
                                                            handler 帧一次消费，D2）
(R11-dispatch)  挂起点 perform (⟨τ'⟩ . v_p) 且 τ' = τ
                  → handler 体求值（p ↦ v_p、k ↦ κ 注入）；非匹配 τ' 沿帧栈
                    继续上抛（逃逸到顶层 = E0007）
(R11-return)    e_b 归约到值 v 且无挂起 → handle 表达式值 = v（帧弹出）
```

**求值顺序契约维持**（§1.3 A1）：`perform` 的效应值先求值（App 序不变）。**效应值形态**：`(tag . payload)` 点对（tag 位须符号——运行时判据，非展开期）。**T1 域注记（v1.1 执行注记口径）**：resume 一致性由种子/生产双编译链在 VM 面承载（42-d eval 退役终态）；树走 eval 路径经逃逸通道承载 dispatch（D7）——resume 于 eval 域为哨兵域限（显式报错，与 `call_closure` 拒绝 Eval 闭包同型先例）。

### R12 Let（局部绑定——r45 原语 / r67 归约规则补写）

```text
(LB1)  ⟨(let ((x v)) b), ρ, σ⟩ → ⟨b, ρ[x ↦ v], σ⟩        当 v 为值（绑定后求值体）
(LB2)  ⟨(let ((x e)) b), ρ, σ⟩ → ⟨(let ((x e')) b), ρ, σ'⟩ 当 ⟨e, ρ, σ⟩ → ⟨e', ρ, σ'⟩（先求值右部）
```

语义与 `Fn+Apply` 组合等价（`((fn (x) b) v)`），但结构显式——编译期局部绑定锚点（A-normal form 正典：命名中间值；[21 §5.6](./21-capability-architecture.md) 准入判据①——r45 入列依据，[22 §14 D41](./22-namespace-design.md)）。**三来源**（D42/D43）：①表面 `(let ...)` 直映（r50-β——多绑定暂存法保平行语义）；②`(do e₁ e₂)` 脱糖为 `Let["do", e₁, e₂]`（恒定名 discard 模式——编译器静态判定体不引用绑定名时发射 `[e₁; Pop; e₂]`，与原序列逐指令全等——R7 的现承载体）；③`letrec` = `Let[x, nil]` + `Assign` 链（预绑定 + 就位赋值）。

---

## 3. 错误吸收语义

错误是**吸收态**（不归约、不恢复、直接终止该求值）：

```text
(E0)  ⟨e, ρ, σ⟩ → Err(ε) ⟹ 无后续状态（吸收）
(E1)  TypeMismatch      —— If 条件非布尔（I3）
(E2)  ArityMismatch     —— βv 参数数 ≠ 形参数（A3 卫式条件失败）
(E3)  UnboundVariable   —— Var/Assign 链上无绑定（V2/S1——时名 VarRef/SetBang）
(E4)  NotCallable       —— App 被调者非闭包/非内置
(E5)  BuiltinError      —— δ 规约失败（类型/域错误，[09-标准库 §2](./09-stdlib.md)）
(E6)  DuplicateDefine   —— 顶层重定义
(E7)  RuntimeError      —— I/O 通道失败（[05-运行时 §1](./05-runtime.md)）
(E8)  内部不变式破坏    —— 仅可能来自编译器缺陷（如栈失衡），视为编译器 P0 缺陷而非用户错误
(E9)  FfiTokenInvalid   —— FFI 令牌失效后使用（双释/用后传递/用后使用；
                          [ffi-ownership-model §5](../develop/v0/stage-2/ffi-ownership-model.md)，r30/48-d 落位 E0010）
(E10) FfiOwnershipViolation —— FFI 所有权/类型违规（释放 Opaque/非令牌值/实参形状不匹配；同上 §2，落位 E0011）
(E11) FfiSymbolResolution  —— FFI 符号解析失败（extern 符号表未登记；同上 §4，落位 E0012）
```

错误携带 `Span`（源位置）传播至诊断层（[02-语法模型 §3](./02-syntax-model.md)）——错误信息是一等公民（[17-设计原则 §1 原则 16](./17-principles.md)）。**无未定义行为**：任何输入要么归约到值、要么进入确定的 Err 态（E0–E7 全集覆盖用户程序可触发的全部终态；E8 是编译器自身的质量边界；E9–E11 是 FFI 面的用户可触发终态与链接终态——r30/48-d 按 [ffi-ownership-model §3 错误面闭合](../develop/v0/stage-2/ffi-ownership-model.md) 裁定延伸，E0–E7 全集覆盖声明随之扩为 **E0–E11**；FFI 族的 unpin 下溢归 E8 口径——4 位码面经 E0004 运行时通用族承载，见 [18-术语 §6 码位登记表](./18-terminology.md)）。

---

## 4. GC 不可观测性引理

**引理 L-GC**：设 `⟨e, ρ, σ⟩ →* ⟨e', ρ', σ'⟩` 为任意归约序列，GC 周期 `collect: σ → σ₁`（标记-清除，[05-运行时 §4](./05-runtime.md)）若满足根集完备不变式，则：

```text
⟨e, ρ, σ⟩ →* v  ⟺  ⟨e, ρ, collect(σ)⟩ →* v     （归约结果与 GC 触发点无关）
```

证明要点：(1) 标记阶段从根集可达的对象集 = 归约序列当前状态引用的对象集（根集完备不变式）；(2) 清除仅回收不可达对象，而不可达对象不出现在任何后续归约规则的对象位置（归约规则只访问 ρ 与 σ 中根可达对象）；(3) 分配计数驱动的触发时机（[05-运行时 §2](./05-runtime.md)）因此不影响语义——这是「分配零内卷」与「安全点」两条实现不变式的理论依据。GC 冷却退避（性能机制）同理不改变语义。

---

## 5. 编译正确性定理

### 5.1 定理陈述（T1）

```text
T1（编译正确性）：
  对任意良构程序 p（展开产物 CoreExpr 序列）与初始环境 ρ₀、初始堆 σ₀：
    若  ⟨p, ρ₀, σ₀⟩ ⇓ v   （元循环求值器路径）
  则  VM_run(compile(p), ρ₀, σ₀) ⇓ v'  且 v ≡ v'（值结构等价，见 5.2 L4）
```

其中 `compile: CoreExpr → CodeBuf`（[04-字节码 VM §2](./04-bytecode-vm.md)，40 操作码，含 v5.1 新增的 `DefineGlobal`——D1/E6 语义的第 40 号冻结契约），`VM_run` 是迭代式帧栈执行（[04-字节码 VM §3](./04-bytecode-vm.md)）。

### 5.2 证明纲要（三引理归纳）

- **L1（指令组局部保持性）**：对每个操作码组（栈操作 7 / 变量访问 7 / 控制流 2 / 函数操作 3 / 算术与比较 12 / 数据构造 3 / 谓词 5 / 终止 1——[04-字节码 VM §1](./04-bytecode-vm.md) 的**八组**分类，v5.2 对齐），逐组证明：指令的栈效应 + 帧效应 = 对应 CoreExpr 子项一步归约的状态效应。归纳基础覆盖全部 40 操作码（编译器测试的「回填零占位断言」与「40 项显式枚举守护测试」是 L1 的机械化检查点）。
- **L2（求值顺序一致性）**：编译产码顺序（App 左到右、Begin 源序）与 R2 的 A1/A2 顺序契约一致（§1.3）。
- **L3（捕获协议等价性）**：`CLOSURE` 指令的共享单元格捕获（`Rc<RefCell>` 槽）与 βv 的子环境扩展在**可变捕获**情形下行为等价——两条路径对 `SetBang` 作用域链变量的读写均经同一逻辑单元格（这是 Stage 0 关键修复「捕获值快照 → 共享单元格」的理论定案：快照语义会破坏 R5/S1 对闭包的可见性，即不满足 T1）。
- **L4（值结构等价 `≡`）**：标量按值相等（**字符串为即时值：按内容比较**——D2 修复锚定）；点对按递归结构相等；闭包按（参数表、代码体、环境可达图）同构相等——堆位置可以不同（两路径是两个堆），但**可观测行为**（打印、比较、继续求值）一致。

> **r3 补充引理（D1/D3/D6/D7 修复锚定）**：
> - **Define 位置约束（D1）**：`Define` 归约（R6/D1）仅在顶层与模块体生效；函数体内经 `begin` 等表达式位置漏入的 define 在**编译期**结构化拒绝（E0003——两路径共享 compile_source 故双侧一致；修复前 VM 侧 DefineGlobal 全局泄漏 vs eval 侧词法定义，为 T1 反例）。
> - **求值深度边界（D3）**：eval 参考路径 `MAX_EVAL_DEPTH=256`（实测标定：2 MiB 线程栈物理极限 ≈ 690 深度单元，留 2.7× 裕度）；VM 生产路径 `MAX_FRAMES=100_000`。T1 在常规程序域（深度 ≤ 256）成立——参考路径边界（TD-017）。
> - **卫生穿透落地（D6）**：宏模板引入的变换器引用（`name$hyg$N`）按基名回退解析变换器表（03 §2.4 卫生保证(2) 的 Stage 0 实现）。
> - **错误保真（D7）**：eval 路径 apply 错误保真透传（消息原样 + 最内 Span 回填），与 VM 诊断保真度对齐。

### 5.3 定理的运行时验证（双路径互查）

T1 的机器验证载体是 [11-测试基础设施 §2.4](./11-testing.md) 的**双执行路径互查**：每个测试程序同时经 `eval` 与 `VM_run` 执行并逐字节比对结果（Stage 0 集成测试 **164 个测试函数**（含 4 个 #[ignore] 存档）全部内置互查断言；全套件 294 函数 / 290 通过 / 0 失败——负向扩张后互查覆盖含错误程序双路径一致性）。互查通过是 T1 的**必要条件**验证（非充分证明——定理本身的证明靠 L1–L4 的归纳论证，互查是在每个具体程序上的实例化检查）。反例即 P0 缺陷：历史上 CLOSURE 原型切换、捕获协议修复、App 求值顺序分裂（v5.2 修复，§1.3）均由互查暴露。

**错误路径的互查口径（v5.2 补注）**：双路径互查对错误程序断言「Err 事实 + Stage 一致」，**不要求消息文本逐字一致**——已存档的消息分裂面（未绑定变量、if 非布尔、错误包装前缀）见 negative_semantics_tests 头注；eval 路径错误诊断保真度弱于 VM（错误包装前缀 + Span 指向差异，P3）已登记 TD 登记。

### 5.4 适用边界

T1 覆盖 Stage 0 的确定性单线程语义。以下超出当前定理范围（对应的扩展定理列入演进矩阵）：并发内存模型（Stage 3，[13-能力矩阵 §4](./13-capability-matrix.md) 决策 1）、Effect Handlers 语义（**r25 已交付**——R10/R11 归约规则组在位；深处理组合/类型化 handler 扩展定理属 Stage 2+ 演进义务，[13-能力矩阵 §3.1.1](./13-capability-matrix.md)）、编译缓存命中路径（等价性由 `CompilationCache` 契约的键完备性保证，[13-能力矩阵 §3.1.4](./13-capability-matrix.md)）。

---

## 6. 与测试矩阵的锚定（设计驱动测试，测试验证设计）

| 归约规则组 | 测试锚点（tests/v0/stage0/） | 验证命题 |
|-----------|------------------------------|---------|
| R1/R2（βv、arity） | plan 套件双路径：闭包、递归、高阶函数（examples/usage/closures.ktf、higher_order.ktf） | L3 捕获等价 + E2 硬错误 |
| R2 A1（App 求值顺序） | `app_evaluates_fn_then_args_left_to_right` + `app_evaluation_order_fn_first_dual_path`（vm_tests，v5.2 修复回归） | 函数先、参数左到右 |
| R3（truthy 显式） | negative_vm_tests::if_condition_requires_bool（×6 类型）+ negative_semantics_tests::e1_*（7 类型 + 嵌套位置） | I3 显式报错 |
| R4（quote 字面量） | Reader 快照（'x → (quote x)）+ 点对渲染 | L4b 堆构造 |
| R5/R6（赋值/定义） | 卫生宏不串扰 + letrec 推导回填 + negative_semantics_tests::t1_regression_global_storage_semantics / e6_duplicate_define_*（E6 双路径矩阵） | S1 词法链定位 + D1/E6 |
| R7/R9（序列/模块） | examples/usage/macros.ktf、io.ktf（begin 序列 + 顶层 define） | B2 值丢弃 |
| §3 错误全集 E0–E8 | negative_semantics_tests：E1–E6 逐码矩阵（矩阵驱动）+ E7/E8 不可触发性文档化存档（§9.4.3 规则 2）+ gate_review_r1 12 项审计 | 吸收态 + 码断言 |
| §3 错误消息形状 | negative_semantics_tests::message_shape_stage_codes_and_span（码+Span+摘录）/ message_shape_call_site_trace（调用点 note 帧） | 诊断是一等公民 |
| §4 GC 不可观测 | gc_tests + examples/usage/gc_stress.ktf（分配计数驱动触发） | L-GC 根集完备 |
| §5 T1 定理 | 全部 164 集成测试函数的双路径互查断言（含错误程序 Err 事实一致） | L1–L4 实例化 |

> 本表是 [11-测试基础设施 §3](./11-testing.md) 验收汇总表的语义侧对应物——测试矩阵的每一行都能回溯到本文件的某条归约规则或引理（[17-设计原则 §1 原则 8](./17-principles.md)：操作语义是正确性的可验证规范）。

---

## 7. 演进义务（Stage 1+ 对本文件的影响）

| 演进项 | 对操作语义的影响 | 时机 |
|-------|----------------|------|
| 迭代式展开（TD-007 解除深度上限 128） | 无——展开深度是展开器实现约束，非归约规则 | Stage 1 |
| 多模块实例化隔离 | R9 从「单模块全局环境」升级为「每模块独立 ρ 实例」——归约规则形式不变，环境构造细化 | Stage 1+ |
| Effect Handlers（P2→P1 升级） | R2 的 δ/A4 之外新增 handler 归约规则组——**已交付（r25：R10/R11 在位——v6.3/r67 注，本行转历史记录）**；βv 保持不变（渐进替换，[17-设计原则 §1 原则 28](./17-principles.md)）；后续义务仅余深处理组合/类型化 handler 扩展定理 | 已兑现（原 Stage 2+） |
| TCO 尾调用 | R2 新增尾位置归约等价类（βv 在尾位置不增长控制上下文）——语义观察等价，资源效应不同 | Stage 1 |
| 多阶段编程（CodeValue 引号消除） | L4c 的 quote 归约从展开期迁移到多阶段 η 规则 | Stage 2+ |

**核心冻结承诺**（[17-设计原则 §1 原则 9](./17-principles.md)）：**语义原语集的归约关系在整个语言生命周期内不变**（现行集 R1-R5、R8、R10-R12——§2 头部对账注口径；R6/R7/R9 的退役非归约关系变更而是**层位迁移**[声明层/脱糖——归约形态原样保留于历史段]）；上表全部演进以**增补**规则或**环境细化**的方式叠加，不修改既有规则的归约结果。

## 8. 错误统一效应模型与 one-shot 纪律（Stage 2+ 演进登记——v6.4 新增，r81 第十四轮吸收，同步自 stage0.md v7.3 §9.15）

> **本节定位**：next10.md 第二段「统一而分治」的操作语义面收编——错误处理的统一效应模型登记。**零代码变更**；R1-R12 归约规则集与 §3 错误吸收语义不变（本节是其 Stage 2+ 语义深化方向登记）。

**归约规则视角的统一模型**：`perform Error::throw(...)` 与 `perform Read::stdin()` 共享同一 Perform 归约形态（效应种类是参数非规则分支）——「异常」无需独立归约规则族；handle 的 handler 分支（Error::throw(e) => ...）与 final_ 分支（return => ...——正常返回也是流的处理分支）统一于 HandlerClause 结构。**one-shot continuation 纪律**（next10.md 未提及——审查补全）：resume 归约至多触发一次（二次 resume = 语义错误）——安全默认（多射 continuation 空间爆炸且禁止标准优化；多射需线性/仿射类型系统保护——Affect 2025 仿射方案登记为替代设计，文献锚 [19 §15](./19-references.md)）。**Stage 2+ 义务登记**（§7 演进义务表追加方向）：深处理组合与类型化 handler 扩展定理的语义基础 = 本节统一模型 + one-shot 纪律；编译期诊断与运行时 Error 效应正交（编译期检查 = 效应系统的静态投影——stage0.md §9.15.6①）。

## 9. 效应本体论概率域视角注记（v6.5 新增——r84 第十六轮吸收，同步自 stage0.md v7.5 §9.17.4）

> **本节定位**：next11.md 段 6-7 概率域模型的归约视角注记（解释框架层登记——R1-R12 归约规则集**零变更**）。形式化：`Effect = ActionSpace × MechanismSpace × PayloadSpace × ContinuationSpace`（四空间笛卡尔积）；Perform = 从概率域实例化一个点；Handle = 对整个概率域定义操作规则。

**归约视角的对应读法**（解释性同构——非新规则）：Perform 的归约步（挂起 + 查栈）= 概率域的「实例化」（坍缩前的可能性行程登记）；Handler 匹配 = 「投影」（坍缩为具体实例——选择规则）；resume(v) 的归约步（续体注入）= 「后续桥梁」（可选——不 resume 即流终止，与 §8 one-shot 纪律合围 `resume ∈ {0,1}`）。**确定性维持**：概率域是类型级/声明级的可能性空间（EffectRow 声明 = 域的静态描述），运行时归约仍是确定性的单步语义——「概率」是认知隐喻非随机性引入（无任何概率归约规则——与 R1-R12 确定性不冲突）。**Stage 2+ 方向注记**：操作语义可按概率域视角增补「域实例化/投影/桥梁」三组推导规则的等价表述（等价改写非扩展——作为理论完备性的可选注记义务，优先级低于类型系统与文法定稿）。

## 10. 效应流形操作语义与类型推断算法（v6.6 新增——r88 第十七轮吸收，同步自 stage0.md v7.6 §9.18.4）

> **本节定位**：next12.md 第十七轮吸收的语义面主体收编——14 条推理规则全集 + 小步操作语义 + 效应行合一算法。全节 Stage 2+ 设计登记态：**kerf 现行大步归约（§8）零变更**；本节为目标语言（#15 门控）的操作语义登记素材——概率域/流形视角增注义务（§9 既有方向注记）的具体规则面展开。

**推理规则全集（14 条登记）**：

*基础与构造*：[T-PERFORM-SIMPLE]（`Γ ⊢ perform E : ⊥ | {E(P)}`——计算挂起类型 ⊥ 未完成）；[T-PERFORM-WITH-ARGS]（携带参数构造）；[T-RETURN]（`Γ ⊢ expr : Return(τ) | {Return(τ)}`——正常返回也是效应）；[T-RETURN-SYNTAX-SUGAR]（`fn f() -> τ ≡ fn f() -> Return(τ)` 裸类型糖——容器式签名 [02 §8.5](./02-syntax-model.md) 衔接）。

*投影与恢复*：[T-HANDLE]（`Γ ⊢ handle body {h₁..hₙ} : τ' | (ε₁ − {E₁..Eₙ}) ∪ ε₂ ∪ ε_remaining`——被处理效应消除 + handler 自身效应添加 + 未匹配传播）；[T-HANDLER-BRANCH]（模式匹配投影）；[T-RESUME]（continuation 期望类型编译期验证——与显式 continuation 类型裁定同构）；[T-NO-RESUME]（不 resume 合法——流在 handler 处终止，resume ∈ {0,1} 语义的规则面表述）。

*传播与消除*：[T-EFFECT-PROPAGATION]（未被 handle 的效应继续向上传播——pass 穿透 [02 §8.6](./02-syntax-model.md) 的规则面对应）；[T-EFFECT-ELIMINATION]（`handle body { E => resume(default) } : τ | ε − {E}`——Koka 效应消除优化锚衔接）。

*流形新增*：[T-SEQUENTIAL]（串联：`Let(x, handle_e₁, e₂) : τ₂ | {A, B} ∪ ε₁ ∪ ε₂`——效应行并集，连接信息保留在 Let 结构中）；[T-NESTED]（嵌套：内层效应加到外层 handler 效应——连接信息保留在 Handle 嵌套结构中）；[T-CYCLIC]（循环：递归函数不动点 `τ | {A, B} ∪ μ`——可能不终止需 Never 或超时效应）；[T-PROJECT]/[T-LIFT]（升降维——降维总是可行[信息减少]、升维总是可行[构造包含域]）+ 对偶二式：`project(lift(v)) = v`（限 lift 定义域内）与 `lift(project(M)) ⊇ M`（超集恢复——构造性表述非拓扑断言，[17 原则 46](./17-principles.md) I-B' 裁定）。

**小步操作语义（五规则登记）**：配置 `⟨e, ρ, σ, κ⟩`（表达式/环境变量绑定/存储效应处理器栈/continuation 栈）——[PERFORM]（求值参数 → 查找匹配 handler → κ' 保存挂起点）、[HANDLE-INSTALL]（安装 handlers 到 σ ∪ {h₁..hₙ}；**r136/206-b 实施注记**：组安装读法[多 handler 一次安装 + 任一命中整组消费]已由 TD-033 窗兑现——VM INSTALL_HANDLER_GROUP #46 + handle-group 核心形式[handle-multi-arm-design.md v1.1 §8]；[T-HANDLE] 两读法裁定收束为组安装正典——嵌套读法仍可经显式嵌套手写）、[HANDLE-PERFORM-MATCH]（模式匹配合并绑定 → 投影为 handler body 执行）、[RESUME]（值通过 continuation 传回挂起点）、[NO-RESUME]（合法终止）。**与 §8 对账**：kerf 现行大步归约零变更；小步语义 + 处理器栈表述为 Stage 2+ 目标语言登记（两套语义的关系 = 同一语义核心的不同步长表述——「同一系统两种描述」裁定的语义面实例）。

**效应行合一算法（核心算法登记——Stage 2+）**：`effect_row(f) = ⋃ { effect_of(perform_i) } ∪ { Return(T_body) }`；含流形结构五步扩展：①收集所有 perform 效应 → ②识别效应间连接（Handle/Let 结构分析）→ ③构建效应图（节点 = 效应，边 = 连接）→ ④计算效应行（节点集合）→ ⑤附加连接信息（可选调试/优化注解——连接信息非效应行必选成员）。示例推导链：`fn complex_operation` → `{Read, State, Error(str), Return(i64)}` → 签名 `i64 | Read | State | Error`。

**8 原语 ↔ 效应容器映射与 Return 形态裁定**：Fn（构造闭包无效应）/ Let（ANF 绑定无效应）/ Apply（效应来自被调函数）/ Const（无效应）/ Var（无效应）/ Branch（纯控制流无效应）/ **Perform（构造概率域——效应的起点）**/ **Handle（投影概率域——效应的处理）**。**Return 形态裁定**（方案 A+B 结合）：类型层 `fn f() -> T | E ≡ Return(T) | E`；核心层 `Handle { body, handlers, final: Var(0) }`（final = 恒等函数）+ 表达式值即返回值（Lambda 演算风格隐式）——**零新增原语**（8 原语闭合维持；final 形态与 try/catch 糖展开同构）。

**审查注记**：效应流形理论本体（三连接公理 + 切片/升降维）与设计宪法五定义见 [stage0.md §9.18.2/§9.18.3](../stage0.md)；本节为其语义规则面的拆分镜像（sop §8.4.5 查询时机表第三层——设计拆分权威）。

## 11. 逆向效应与计算干涉类型规则（v6.7 新增——r89 第十八轮吸收，同步自 stage0.md v7.7 §9.19.4/§9.19.5）

> **本节定位**：next12.md 追加段的语义规则面收编——正逆组合五规则 + 干涉感知四规则。全节 Stage 2+ 设计登记态（§8 大步归约零变更维持——本节为 §10 语义面登记的续篇；#15 门控）。

**正逆组合类型规则五条**：[T-CONSUME-REVERSE]（`effect E declared with payload P; Γ ⊢ request : P | ε ⟹ Γ ⊢ consume E(request) : P | {E(P)} ∪ ε`——请求接收同样向效应行添加 E；返回值 = 接收到的内容 P）；[T-OFFER-REVERSE]（`Γ ⊢ service_body : P | ε_s; offer handles E ⟹ Γ ⊢ offer E {service} : ⊥' | ε_s − {E}`——提供服务消除效应[被吸收]）；[T-REWIND]（`Γ ⊢ result : P | ε; continuation k expects P ⟹ Γ ⊢ rewind(result) : ⊥' | ε`——计算在服务方终止）；[T-PIPELINE]（`Γ ⊢ producer : P | ε₁; Γ ⊢ consumer : P → R | ε₂ ⟹ Γ ⊢ consumer(producer) : R | ε₁ ∪ ε₂`——管道组合效应并集）；[T-SHUTDOWN]（**正逆配对消除**：perform E 的「发出」被 offer E 的「接收」匹配 → `ε_result = ε − {E}` 不再传播——正逆相遇的湮灭语义）。

**干涉感知类型规则四条**：[T-INTERFERENCE]（`Handle_A : S → S; Handle_B : S → S; [A,B]_S ≠ ∅ ⟹ A ⊗ₙ B : S → S ⊗ Interference`——非对易 Handle 组合类型携带干涉标记）；[T-INTERFERENCE-TRACK]（`ι₁ ∩ ι₂ ≠ ∅[存在共享资源] ⟹ handle₁ ∘ handle₂ : τ | ε ∪ ι`——干涉标记传递并可能增强）；[T-PROBABILISTIC-COLLAPSE]（`Γ ⊢ branches : List<(Handler, Probability)>; Σpᵢ = 1 ⟹ Γ ⊢ collapse(branches) : τ | ε ∪ Randomness`——概率归一化 + Randomness 效应；结果类型 = 所有分支结果类型并集）；[T-UNCERTAINTY]（`[A,B]_R ≠ ∅ ⟹ Cannot determine (A∘B(R), B∘A(R)) simultaneously`——非对易 Handle 无法同时确定效果——编译器警告 + 用户必须选择顺序或使用伪随机坍缩）。

**正逆组合语义四规则（求值形态）**：①正逆串联（生产者-消费者管道 `Forward ∘ Reverse = Pipeline`）②逆向内部串联（`Consume₁ ∥ Consume₂ ∥ Consume₃ → Offer`）③正向外壳逆向内部（Handle 的 handler 内 consume 额外资源）④逆向外壳正向内部（Offer 的 handler 内 perform 子效应）——外壳/内部四象限全覆盖（正逆可任意嵌套混合）。

**8 原语闭合（语义面）**：Consume = Perform(Receive) / Offer = Handle 服务提供模式 / Rewind = Resume 多播——逆向三操作 = 正向三原语使用模式（J-A）；干涉 = Handle 嵌套/组合时对共享资源的**自然结果**（SharedState::modify 示例：先 A[+1] 后 B[×2] → 2 / 先 B 后 A → 1——非对易确认；零新增原语）；伪随机坍缩 = Randomness 效应 + 条件分支（零新增原语）。

**计算不确定性原理（语义登记）**：当 `[A,B]_R ≠ ∅` 时不存在同时满足 ①A 在 B 前 ②B 在 A 前 ③两者结果相同 的执行——干涉的 Handle 无法「同时确定」效果，必须选择一个顺序（坍缩）。交换子 `[A,B]_R = A∘B(R) ⊖ B∘A(R)`；非对易实例 A=+1/B=×2 → `[A,B](R) = 1−2 = −1 ≠ 0`。

**审查注记**：逆向对偶理论（双幺半群/对偶范畴）与知识不对称判据见 [stage0.md §9.19.2/§9.19.3](../stage0.md)；EBNF v4 三语法族见 [02 §8.7](./02-syntax-model.md)；Randomness 效应运行时面见 [05 §9](./05-runtime.md)。

## 12. 波粒二象性语义注记（v6.8 新增——r91 第十九轮吸收，同步自 stage0.md v7.8 §9.20.4）

**解释框架层第六环（用户理论 v6——K-C 裁定）**：粒子性（perform 离散事件：位置 = 挂起点 / 动量 = 载荷参数 / 能量 = 处理成本 / 效应间可区分）vs 波动性（效应流形连续传播：Handle 网络中传播 / 共享资源干涉[非对易] / 多路径叠加）——**同一机制的两种互补描述视角**（事件视角 vs 传播视角）；五操作对偶表：Perform = 粒子性 / Handle = 波动性 / Resume = 粒子→波转换 / Consume = 波→粒子转换 / 效应流形 = 统一时空。

**转换语义（语义面登记——描述转换非机制新增）**：Perform = 波的「坍缩」为粒子（Before：所有可能处理路径的叠加 → After：离散确定事件但立即开始作为「波」向 Handle 传播）；Handle = 粒子的「弥散」为波（接收离散效应 → 产生多种可能后续）。EffectNature 三态（`Particle(EffectQuanta)` / `Wave(EffectWave)` / `Superposition{particle_component, wave_component, interference}`）为登记态类型面素材。

**EffectUncertainty 两形态登记（[T-UNCERTAINTY] 诊断族语义面）**：**位置-动量版**（r91 语料——`Δposition × Δmomentum ≥ ℏ_effect`：越精确知道效应在哪里，就越无法知道效应携带什么）/ **顺序版**（r89 §9.19.5——非对易 Handle 无法同时确定效果：不存在同时满足两顺序且结果相同的执行，必须选择一个顺序[坍缩]）——两形态同为不确定性原理的计算版本登记（语义描述层，零机制变更义务沿袭 H-A→I-A→J-A→K-C 四轮验证链）。

**与 §9 概率域视角注记的对账**：「概率域」三部曲第二环（r84）已含「投影/坍缩」术语族——波粒二象性 = 概率域视角的**连续性补全**（离散事件面[粒子] + 连续传播面[波] = 概率域的完整几何描述）；§8 大步归约零变更维持（波粒二象性全节为解释框架层登记——Stage 2+ 语义增注素材非当前义务）。

**审查注记**：数学工具箱分级（K-A）与路径积分枚举语义见 [stage0.md §9.20.2/§9.20.5](../stage0.md)；Pass D 量子分析运行时面见 [05-运行时 §10](./05-runtime.md)。

## 13. 信息效应语义注记（v6.9 新增——r111 第二十六轮吸收，同步自 stage0.md v8.5 §9.27.2/§9.27.7）

**语义面零增量登记**：信息效应的归约规则 = §8 既有 Perform/Handle 规则的应用域实例——`⟨perform InfoOp(e), ρ, σ, κ⟩ → ⟨e, ρ, σ, κ'⟩`（效应帧入栈同构）+ `⟨handle 臂匹配 InfoOp, ...⟩ → 臂体归约`（handler 派发同构）——**零新推理规则**（与 §10-§12 三轮先例同构：理论演进的语义面 = 既有规则的实例化）。**信息 = 状态投影的语义定位**：观测投影不改变归约轨迹——观测（observe/project/DebugTrace 记录）= 轨迹的**只读查询**（分析面操作——MU-B 单源纪律：操作流形对象不引入自有 IR），「观测者不扰动被观测流」的语义表述 = 记录开关与归约步正交。**one-shot 纪律沿袭**：信息效应的 resume 语义同原则 42（Error 的 collect 策略 = handler 臂内批量收集后 resume——单次派发 one-shot 不变）。上游全量 = [stage0.md §9.27.7](../stage0.md)；运行时面 = [05 §13](./05-runtime.md)。

## 14. 时间性与坍缩语义注记（v6.10 新增——r113 第二十七轮吸收，同步自 stage0.md v8.6 §9.28.3/§9.28.6）

> 本节登记流特性理论（FLW-B-1/FLW-E）对操作语义的两项精确化注记——**零归约规则变更零环境通道增量**（既有小步语义 ⟨e,ρ,σ,κ⟩ 四元组与 14 推理规则原样维持——8 原语不变性第十一轮验证）。

**固定 vs 确定的观测维度阶区分（FLW-B-1）**：Handle 的语义在观测论视角下 = **固定操作（Fix）非确定操作（Det）**——观测一个效应维度（分支选定 + resume 值确定）而其余效应维度叠加保持开放（正交效应行独立坍缩——与 resume ∈ {0,1} 合围兼容[r84 裁定]）。形式化：Fix(v, d): Ω_high→Ω_d（维度 d 锁定为具体实例 v，d'≠d 仍叠加）vs Det(v): Ω_high→{v}（全维度坍缩至单点——理论上限，kerf 无此操作语义）。**对既有归约规则的影响 = 零**：该区分是 Handle 语义的观测论重述（表述增益——退相干式「叠加选择性削减」比「坍缩」更精确），非新归约规则。

**时间性四命题 = 操作语义物理层重述（FLW-E）**：①流动 = 时间的持续坍缩 ↔ 小步语义每步转移 = 一次坍缩（下一步可能性叠加 → 实际执行坍缩到一个具体下一步 → 剩余可能性新叠加）②时刻 = 概率的固定（快照）↔ Const 原语（固定值）+ VM 状态快照（σ 确定性）③无观测 = 混沌 ↔ 未执行程序/未求值表达式（eager 求值 = 持续观测 = 持续坍缩——kerf 严格 eager）④随机种子随流共同演进 ↔ Randomness 效应（r89——PCG32 确定性种子 + 状态线程演进：每 perform Randomness = 种子前移一步）。**「时间停止≠坍塌——无观测即混沌包括时间未知」澄清采纳**：求值器空闲态（无转移规则触发——κ/σ 静止）= 时间维（转移步数计数）不存在的叙事层兼容。**裁定**：时间性叙事 = 小步语义 + VM 语义的物理层重述——K-F 理论-实现分层沿袭（理论坍缩语言 vs 机制确定性转移规则）；零机制变更（VM/编译器/原语零触及）。

## 15. 统一流分析语义注记（v6.11 新增——r115 第二十八轮吸收，同步自 stage0.md v8.7 §9.29.2/§9.29.3）

> **本节定位**：next20.md 统一流分析 = 生命周期效应化（§9-LC r94 既有）的**工程统一面延伸**——借用检查 = 流干涉分析投影。本节为登记态语义注记：**零归约规则变更、零通道增量、零小步语义修改**（既有 ⟨e,ρ,σ,κ⟩ 四元组 + 14 推理规则不变）。

- **数学基础**：Lifetime(T) = π_time(EffectFlow(T))——生命周期 = 效应流的时间维度投影（观测投影家族第三实例：类型 π_shape / 信息 π_state / 生命周期 π_time——r113 FLW-B Fix/Det 为维度阶基础）。
- **默认生命周期三规则**：值类型 = [Use(x)] 单点切片（零分析——值语义）/ 引用类型 = [Borrow(x)]—[Return(x)] 借用时间段（段级分析——NLL 形）/ 资源类型 = [Acquire]—[Use]*—[Release] 完整流（全流分析——完整性+泄漏检测）。与 §9-LC ResourceLifecycle 四操作全 Perform 模式零冲突——本节为其投影算子形式化。
- **流干涉三型语义**：Destructive（Immutable × Mutable 时间重叠——不可变+可变不能共存）/ Exclusive（Mutable × Mutable——一次一个独占）/ Dangling（Use 后于 Release——悬垂）——借用检查语义 = 效应干涉分析投影（§9-LC 冲突检测 = 效应干涉分析三处置策略的工程管线化）。
- **NLL 段结束推导**：借用段在最后一次使用后结束（FLOW-SEGMENT-END 规则——Polonius 先例 E.29-160[Datalog 数据流借用检查工业同构]）——**登记态**：分析窗开启时作为 UnifiedFlowAnalysisPass 相位 2 实施（MU-B Pass 单源纪律适用——操作流形对象不引入自有 IR）。
- **六规则族登记态**：FLOW-SEGMENT-IMMUTABLE/MUTABLE + FLOW-SEGMENT-END + INTERFERENCE-DESTRUCTIVE/EXCLUSIVE/DANGLING + LIFETIME-COMPLETENESS/LEAK + PARTIAL-BORROW-OK/CONFLICT + CONCURRENT-FLOW-INTERFERENCE——全量见 [stage0.md §9.29.3](../stage0.md)；与 §10 效应流形操作语义（14 推理规则）正交（分析层投影非归约层规则）。
- **8 原语不变性第十二轮验证**：统一流分析全部由既有 8 原语 + 既有分析框架承载——零新原语零通道零 VM 变更（K-F 理论-实现分层：分析层投影 vs 机制层归约——分层零漂移）。

## 16. 递归的流形统一叙事注记（v6.12 新增——r117 第二十九轮吸收，同步自 stage0.md v8.8 §9.30.2 [原则 58 / REC-A]）

> **本节定位**：next21.md 段 1 理论统一（递归 = 效应流的分支/嵌套 / 深度 = 流形的嵌套层级 / 溢出 = 流分析的边界条件 / 显式栈 = 流形上的路径追踪 / 流式处理 = 流的渐进观测）= 统一流分析（§15 r115 既有）的**递归面叙事层重述**——解释框架层叙事登记（K-F 理论-实现分层沿袭：零归约规则变更零通道增量零机制变更）。

- **机制表述边界（裁定）**：语料「perform 不创建栈帧 / resume 恢复的是效应流非调用栈 / 效应流状态存储在堆上」三断言 = **效应处理器实现策略面非效应语义必然**（OCaml 5 = 堆分配动态调整栈 + 续延可后调用工业先例 E.30-165；kerf VM = 帧栈承载 kerf 递归 + Perform/Handle 语义栈安全已达成——实现策略差异非语义差异；归约规则零关联）。
- **递归深度处理 = 运行时/编译期防御机制非语义面**：Reader 深度帽 256[FS-1 实测锚] + HM 生成预算 512[A6 语义不变：超预算子树结构化诊断] + VM 帧数帽[TD-023]——三防护 = 既有机制实况（[04 §3.1](./04-bytecode-vm.md) 四层谱系单源）；fail-closed 结构化错误与「优雅的错误报告不是崩溃」主张一致。
- **深度 = 流分析边界条件的叙事归位**：该表述 = 统一流分析愿景（Stage 2+ 分析窗登记态）的递归面重述——非新归约规则非新数学（Tier 3 隐喻级：流形嵌套层级表述）。
- **8 原语不变性第十三轮验证**：本轮零新原语零通道零 VM 零语法零 EBNF——历次最轻量轮族并列（递归处理 = 既有机制实况登记）。

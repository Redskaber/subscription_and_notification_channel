# 运行时：最小 I/O 与标记-清除 GC

> **Author**: kerf-doc-agent
> **Date**: 2026-11-22（**v6.14——r157 / 227-b1 设计文档残留清偿窗：现行面 .krf→.ktf 引用修正 + 用户面记号桥（设计单源 design-docs-modernization-plan.md v1.0 U1/U3——D2 分流判据 J3）**）；2026-10-10（**v6.8——r91 第十九轮吸收（next13.md）**：§10 量子分析 Pass D 与路径积分运行时面[EffectPathIntegral/EffectPath 枚举语义 + 五 Pass 分立全景 + 贝尔不等式诊断性守卫]——同步自 stage0.md v7.8 §9.20.5/§9.20.6）；2026-10-10（**v6.7——r89 第十八轮吸收（next12.md 追加段）**：§9 逆向效应运行时面[双向 Continuation + EffectScheduler + Randomness 效应 PCG32 + CollapseScheduler + InterferenceAnalysisPass]——同步自 stage0.md v7.7 §9.19.4/§9.19.6）；2026-10-10（**v6.6——r88 第十七轮吸收（next12.md）**：§8 效应流形运行时面[EffectGraph 编译器内部表示 + 流形分析 Pass + EffectTrace 桥接层 + 空间归属双分层]——同步自 stage0.md v7.6 §9.18.6）；2026-10-09（**v6.5——r84 第十六轮吸收（next11.md）**：§7 效应本体论登记[运行时面——生命周期三阶段运行时读法 + resume ∈ {0,1} 合围 + 机制兼容零变更 + 容器消除优化方向注记]——同步自 stage0.md v7.5 §9.17；[17 原则 45](./17-principles.md) 同轮注册）；2026-10-01（**v6.4——r81 第十四轮吸收（next10.md）**：§6 错误统一效应模型登记[运行时面——统一而分治 + Fatal/halt 语义 + one-shot 纪律 + 编译期诊断正交裁定]——同步自 stage0.md v7.3 §9.15；[17 原则 42](./17-principles.md) 同轮注册）；2026-09-12（v6.3：K2/r36 大阶段末深审回写——§14.8 B2-2/B2-5：根集五来源 → 六来源（continuation 帧链 r25/M5 第六源，与 06 §1.2 对齐）+ 类型化分配八入口 → 九入口（alloc_foreign r30 FFI）+ 分代/压缩推迟项口径对齐 TD-008 r24 DEFER Stage 3+；2026-09-11（v6.2：批次 F 深审回写——TD-002 符号值家族对齐：HeapObj 七变体/八入口 + I/O 通道三函数 + gc_stress 回归基线注记；v5.2：HeapObj 六变体对齐 + alloc_boxed 第 7 入口 + 根集五来源 + GC 冷却数值冻结 + 分配算法描述对齐（slot-Vec + 空闲表 + 显式工作栈）））
> **Version**: v6.14（**r157 / 227-b1**：U1 ×3 点——纯文档轮零代码变更，[design-docs-modernization-plan.md](../develop/v0/stage-3/design-docs-modernization-plan.md) v1.0）；v6.13（**r115 第二十八轮吸收——§15 NLL 段结束推导运行时面注记**[借用时间段语义 + 统一流分析运行时面零机制变更——零 VM 变更零通道增量]）；v6.12（**r113 第二十七轮吸收——§14 种子演进运行时面**[Randomness/PCG32 既有承接——零运行时变更]）；v6.11（**r111 第二十六轮吸收——§13 信息效应运行时面**[perform/handle 既有机制承载 + 零 VM 增量 + 观测分级配置面 + F13 沿袭——同步自 stage0.md v8.5 §9.27]）；v6.10（r94 第二十一轮吸收——§12 生命周期效应运行时面[with_resource Handle 四臂语义 + 借用三处置 + LifecycleAnalysisPass 消除三形 + 效应分析单点性三缓解]）；v6.9（r93 第二十轮吸收——§11 能力操作运行时面[环境五元组 C 通道 + 四规则族 + 度规开销三策略 + 线性三方案 + LV 收敛登记]）；v6.8（r91 第十九轮吸收——§10 量子分析 Pass D 与路径积分[五 Pass 分立全景]；v6.7（r89 第十八轮吸收——§9 逆向效应运行时面[双向 Continuation + 坍缩调度]；v6.6（r88 第十七轮吸收——§8 效应流形运行时面[EffectGraph 编译器内部表示 + 流形分析 Pass + EffectTrace 桥接层 + 空间归属双分层]；v6.5（r84 第十六轮吸收——§7 效应本体论登记[运行时面]；v6.4（r81 第十四轮吸收——§6 错误统一效应模型登记；v6.3：K2/r36 深审回写 + TD-008 分代/压缩推迟口径）
> **Status**: Active
> **处理程度**：GC 为 P0（安全关键组件，Stage 0 已实现）；最小 I/O 为 P1（传统全局函数，能力模型 I/O 接口预留）｜ **所属 Stage**：Stage 0 ｜ **推迟项**：分代/增量/并发 GC（TD-008 r24 裁定 DEFER Stage 3+ 条件触发）、能力模型 I/O net/process（Stage 3 触发式，[13-能力矩阵 §3.1.3](./13-capability-matrix.md)）、屏障接口实现（Stage 0 no-op）

> 本文件收录运行时基座的设计与实现：最小 I/O（原 §8.8）、标记-清除 GC 的最小实现（原 §8.11）、内存管理策略（原 §14.2，v5.1 从冻结实现回填分配器/堆/根集契约），以及标记-清除 GC 实现框架（原 §19.4：三阶段骨架 + 核心不变式 + 实现陷阱）。字节码 VM（运行时基座的另一半）见 [04-字节码 VM](./04-bytecode-vm.md)；最小内置库的函数级边界见 [09-标准库](./09-stdlib.md)；12 个能力模型的完整矩阵见 [13-能力矩阵](./13-capability-matrix.md)（其 §2.8/§2.11 为本文件 §1/§2 的规范副本）；高级 GC 的推迟理由见同文件 §3。操作语义侧的 GC 不可观测性引理（L-GC）见 [06-操作语义 §4](./06-operational-semantics.md)。

---

## 1. 最小 I/O（传统）（原 §8.8）

仅 `read_line()` 和 `write_line()`，通过全局函数（非能力模型）。Stage 0 不引入能力模型 I/O，但 VM 栈帧和分配器接口必须预留 `register_foreign_ref` 等接口（Stage 0 可为 no-op），以便 Stage 1+ 升级到能力模型时无需破坏接口。

> **v6.2 通道面注记**：通道层实为**三函数**——r5 标准库批次新增 `write_stdout(s)`（`write-string` 内置的无换行通道载体，io.rs 注记在案；09-stdlib v5.4 已记载该通道名，本文件此前未同步）。升级路径不受影响（三函数同被能力对象分发覆盖）。

**I/O 通道契约（Stage 0 冻结，kerf-runtime/src/io.rs）**：

```rust
/// 运行时错误（错误显式返回，禁止异常——接口契约规则 2）。
pub struct RuntimeError { pub message: String }

/// 全局 stdout 行写入（副作用唯一出口之一）。
pub fn write_line_stdout(s: &str) -> Result<(), RuntimeError>;
/// 全局 stdin 行读取（EOF 返回 None；副作用唯一出口之二）。
pub fn read_line_stdin() -> Result<Option<String>, RuntimeError>;
/// 全局 stdout 原文写入（无换行——`write-string` 的通道层载体，r5 新增；
/// v6.2 补注第 3 通道函数）。
pub fn write_stdout(s: &str) -> Result<(), RuntimeError>;
```

**升级路径（扩展预留接口）**：Stage 2 升级到能力模型 I/O 时，本二函数由 `ReadCapability / WriteCapability` trait（[13-能力矩阵 §3.1.3](./13-capability-matrix.md) 冻结签名）的实例替换——内置函数 δ 表（[09-标准库 §2](./09-stdlib.md)）从直接调用全局函数改为经能力对象分发，调用点接口不变（[17-设计原则 §1 原则 28](./17-principles.md)：渐进替换）。

## 2. 标记-清除 GC（最小实现）（原 §8.11）

**v5.2 算法描述对齐（原「bump-pointer 分配 + 递归标记」摘要失真，以下为实现即事实）**：**slot-Vec 分配 + 空闲表（free 表）+ 显式工作栈标记 + 堆线性遍历清除**。堆为 `Vec<Slot>`（槽位数组，`GcRef = u32` 索引句柄），分配优先复用空闲表中的槽位、耗尽后追加新槽；标记阶段用显式 `work` 栈替代递归（防爆栈）；清除阶段线性遍历堆重建空闲表（不移动对象、不压缩——碎片治理推迟至分代/压缩，TD-008 r24 裁定 DEFER Stage 3+）。根集包括（**六来源**）：VM 数据栈、全局环境、调用帧局部槽、**帧捕获槽（Rc<RefCell> 共享单元格）**、`register_foreign_ref` 登记的外部引用、**活跃 continuation 帧链**（r25/M5 第六源——vm.rs:1368）。Stage 0 用最简单的 mark-sweep，避免分代/增量/并发的复杂度。

**实现指引**：分配、标记、清除三个阶段的完整伪代码与栈溢出对策见本文 §4。

## 3. 内存管理策略（原 §14.2，v5.1 契约回填）

分配器接口协议包含基础分配、屏障接口（Stage 0 为 no-op）、根集管理和 FFI 外部引用追踪。堆对象统一头格式支持从保守 GC 演进到精确/分代/增量 GC。

### 3.1 堆与分配器契约（Stage 0 冻结，kerf-runtime/src/heap.rs）

```rust
/// GC 引用（堆槽句柄——u32 索引，非裸指针：句柄稳定性不依赖内存布局）。
pub struct GcRef(pub u32);

/// 堆对象种类（**七变体**，v6.2 对齐冻结实现：Pair/Str/Int/Float/Bool/Nil/Symbol。
/// Symbol(Rc<str>) 为 r5 批次 B TD-002 符号值的槽位形态（v6.2 前文档停在六变体口径）。
/// 早期版本误写 Boxed(BoxedInput) 变体——实际不存在：闭包/内置函数不可装箱
/// 是显式裁定（序对元素为闭包/内置时以标记字符串占位，TD-010 登记，
/// Stage 2 以 HeapObj::Foreign 承载——目标时机随批次 F 深审改判，见登记册）。
/// **r30/48-d 注记**：`HeapObj::Foreign` 载荷扩展承载 **FFI 外部令牌**
/// （`Rc<ExternalToken>`——ffi-ownership-model §7「令牌载荷不参与 GC
/// 可达性」：追踪器 no-op、children 为空；闭包/内置/continuation/令牌
/// 四形态共用 Foreign 变体——TD-010 追踪器协议的自然扩展）。
pub enum HeapObj { /* Pair(GcRef, GcRef) | Str(Rc<str>) | Int(i64) | Float(f64)
                     | Bool(bool) | Nil | Symbol(Rc<str>) */ }

/// 堆槽（分配粒度单位：对象载荷 + 标记位；空闲表为堆级 `free: Vec<GcRef>`，
/// 不在槽内——清除阶段全量重建）。
pub struct Slot { /* obj: HeapObj; marked: bool */ }

/// 堆（分配器 + 标记-清除回收器 + 外部引用登记簿）。
pub struct Heap {
    // slots: Vec<Slot>; free: Vec<GcRef>; foreign_roots: Vec<GcRef>;
    // pin_counts: Vec<(GcRef, u32)>;  // Φ 计数簿（r30/48-d——foreign_roots
    //                                 // 的计数化泛化：supp(Φ) 并入 mark
    //                                 // 起点；归零摘根——ffi-ownership-model §3）
    // allocs_since_gc: u64; gc_threshold: usize; gc_enabled: bool;
}

impl Heap {
    /// 类型化分配（**九入口**——调用方携带类型信息，非统一 alloc(size)）：
    /// 八个类型化入口 + alloc_boxed（即时值统一描述入口，按 BoxedInput
    /// 分派到 Str/Int/Float/Bool/Nil 五类——符号走 alloc_symbol 直通，
    /// 不在 BoxedInput 内——v6.2 对齐 r5 实现；v6.3 增补：alloc_foreign
    /// 为第 9 入口——r30/48-d FFI ForeignBox 装箱，追踪器协议入标记图）。
    pub fn alloc_pair(&mut self, car: GcRef, cdr: GcRef) -> GcRef;
    pub fn alloc_str(&mut self, s: Rc<str>) -> GcRef;
    pub fn alloc_int(&mut self, v: i64) -> GcRef;
    pub fn alloc_float(&mut self, v: f64) -> GcRef;
    pub fn alloc_bool(&mut self, v: bool) -> GcRef;
    pub fn alloc_nil(&mut self) -> GcRef;
    /// 符号分配（v6.2 补注第 8 入口——TD-002 r5：quote 符号值入堆）。
    pub fn alloc_symbol(&mut self, s: Rc<str>) -> GcRef;
    pub fn alloc_boxed(&mut self, v: BoxedInput) -> GcRef;

    /// 读取访问（不可变查询：unbox/get_pair/get）。
    pub fn unbox(&self, r: GcRef) -> Option<ValueSlot>;
    pub fn get_pair(&self, r: GcRef) -> Option<(GcRef, GcRef)>;

    /// GC 控制（分配计数驱动触发；冷却退避状态在 **VM 侧**（vm.rs 的
    /// gc_cooldown 计数器），不在 Heap——Heap 只暴露 should_collect 与阈值）。
    pub fn set_gc_enabled(&mut self, enabled: bool);
    /// 触发判定：`allocs_since_gc > gc_threshold`（**严格大于**——
    /// 等于间值当轮不触发，与文档早期「≥」写法不同，以实现为准）。
    pub fn should_collect(&self) -> bool;

    /// 外部引用登记（FFI 预留接口——[13-能力矩阵 §4](./13-capability-matrix.md) 决策 3）。
    /// Stage 0 语义：登记的引用作为根保存（非 no-op——正确性优先，
    /// mark_sweep_cycle 起点并入 foreign_roots）；
    /// 屏障接口（write barrier）才是 Stage 0 no-op 项。
    pub fn register_foreign_ref(&mut self, r: GcRef);
    pub fn foreign_roots(&self) -> &[GcRef];

    /// Φ 计数簿（r30/48-d——[ffi-ownership-model §3](../develop/v0/stage-2/ffi-ownership-model.md)
    /// P/U 归约规则的运行形态；`register_foreign_ref` 的**计数化泛化**——
    /// 持久根与窗口计数根并存，supp(Φ) 并入 mark 起点）：
    /// - `pin_object`（P1）：`Φ[v] += 1`（可重复累计——引计数式屏障）；
    /// - `unpin_object`（U1）：`Φ[v] -= 1` 归零摘根（下一轮回收周期
    ///   可回收）；U2 下溢 → `Err`（E8 口径——结构配对保证不可达）；
    /// - `pin_count`/`pinned_refs`：Φ 可观测性（测试/审计面）；
    /// - F-PIN 引理：周期起点 Φ(v) ≥ 1 ⟹ 本轮 sweep 不回收 v。
    pub fn pin_object(&mut self, r: GcRef);
    pub fn unpin_object(&mut self, r: GcRef) -> Result<(), RuntimeError>;
    pub fn pin_count(&self, r: GcRef) -> u32;
    pub fn pinned_refs(&self) -> Vec<GcRef>;

    /// 统计（基准与测试观测点）。
    pub fn stats(&self) -> GcStats;
}
```

**堆对象统一头格式（Slot 结构的语义）**：每个槽携带「对象载荷 + 标记位」。从保守 GC 演进到精确/分代/增量 GC 时：(1) 标记位可直接升级为分代号（低 1-2 位复用）；(2) 堆级空闲表（`free: Vec<GcRef>`）可升级为分代空闲链（v5.2 注：空闲表在堆级而非槽内 `next_free` 指针——以实现为准）；(3) `GcRef` 句柄格式不变——「数据结构的留白是廉价的」（[17-设计原则 §1 原则 20](./17-principles.md)）。

**分配触发协议（v5.2 数值冻结）**：分配计数驱动（`allocs_since_gc > gc_threshold`，**默认阈值 gc_threshold = 1024**，测试可调 `Heap::with_threshold`）+ **GC 冷却退避**（归属 **VM 侧**执行循环：安全点轮询间隔 `GC_POLL_INTERVAL = 256` 条指令；回收收益 < 25%（`total_freed × 4 < slots`）时置冷却计数 `GC_COOLDOWN_MULTIPLIER = 64` 个轮询周期；深递归场景连续触发回收的 O(n²) 消退——worklog Task 4-c 的关键性能修复：122s → 3.4s）。退避仅影响触发时机，不影响语义（[06-操作语义 §4 引理 L-GC](./06-operational-semantics.md)：GC 不可观测）。

> **v6.2 回归基线注记（TD-023）**：批次 F 深审实测 gc_stress（3×10^5 分配 + 30k 深递归）单轮 207~235ms，较 Stage 0 基线 160.4ms 回归 +29~46%（超 §14.6.4 的 10% 阈值），且超线性缩放（spin 15000→59.5ms：2× 分配 → 3.6× 耗时）——冷却四参数未变，候选根因为根集遍历 per-cycle `HashSet<usize>` 去重分配与 Value 枚举宽度增长的缓存效应。登记 TD-023（P2），绑定 Stage 2 批次 I2（与 TD-008 分代/压缩评估同轮——对症路径）；完整口径见 [stage-1/performance-baseline](../develop/v0/stage-1/performance-baseline.md)。

**运行时错误与堆栈追踪（v5.2 补注）**：VM 路径运行时错误在 `run_program` 错误出口统一生成调用点追踪（`VmError.trace`：帧链快照的**最内 16 帧**（`MAX_TRACE_FRAMES = 16`——深递归下外层无信息量，防诊断爆炸），经 debug_info 反查 Span 后渲染为 note 行）；eval 路径错误经 driver 包装为 E0004 诊断——两路径错误事实一致，消息文本存在已存档的分裂面（TD-014 相关，[06-操作语义 §5.3](./06-operational-semantics.md)）。

### 3.2 根集契约（kerf-runtime/src/gc.rs）

```rust
/// 根集：回收周期的可达性起点集合。
pub struct RootSet { /* refs: Vec<GcRef> */ }

impl RootSet {
    pub fn new() -> Self;
    pub fn from_refs(refs: impl IntoIterator<Item = GcRef>) -> Self;
    pub fn push(&mut self, r: GcRef);
    pub fn len(&self) -> usize;
    pub fn is_empty(&self) -> bool;
}

/// 完整回收周期（标记 → 清除 → 复位，返回统计）。
pub fn mark_sweep_cycle(heap: &mut Heap, roots: &RootSet) -> GcStats;
```

**根集六来源（根集完备性不变式，本文 §4；v6.3 修订——r25/M5 增第六源 continuation 帧链，原 v5.2 增帧捕获槽）**：(1) VM 数据栈；(2) 调用帧局部槽；(3) **帧捕获槽**（`Rc<RefCell<Value>>` 共享单元格——可变捕获的根，VM 侧 `collect_roots` 逐帧枚举 locals 与 captures 两组）；(4) 全局环境；(5) `register_foreign_ref` 登记的外部引用（回收周期起点并入标记工作栈；r30/48-d 起 = 持久根 **∪ supp(Φ)**——pin 计数簿（P/U 规则）为第五来源的计数化泛化，F-PIN 引理维持完备性不变式）；(6) **活跃 continuation 帧链**（r25/M5——`Value::Continuation` 四要素含帧链/数据栈快照，vm.rs:1368 部署跨压力存活锚 effect_tests gc_continuation_boxed）。六类根缺一不可——漏根 = 悬垂指针（P0 级安全缺陷）。

**屏障接口的边界裁定**：Stage 0 的屏障为 no-op（无分代/并发，无屏障需求）；`register_foreign_ref` 在 Stage 0 **不是** no-op（外部持有的 GcRef 必须作为根保存，否则悬垂）——两个接口的成熟度分级不同，见 [13-能力矩阵 §3.1.3](./13-capability-matrix.md)。

## 4. 标记-清除 GC 实现框架（原 §19.4）

> **实现框架系列说明（原 §19 章导言）**：本系列（[02-语法模型 §6](./02-syntax-model.md) / [03-宏系统 §4](./03-macro-system.md) / [04-字节码 VM §2-§3](./04-bytecode-vm.md) / 本文 §4）将 [13-能力矩阵 §2](./13-capability-matrix.md) 定义的 12 个能力模型落实为可直接照抄实现的伪代码框架。所有伪代码采用 Rust 风格语法，但刻意停留在"控制流 + 数据流"层面，不绑定具体内存布局——同一框架可无损翻译为 OCaml（推荐宿主）或 C（VM 基座）。每节按「算法骨架 → 核心不变式 → 实现陷阱」组织：不变式是测试设计的直接依据，陷阱清单来自历史实现（Guix 自举链、rustc、Racket BC）踩过的坑。

slot-Vec 分配 + 显式工作栈标记 + 堆线性遍历清除（能力模型见本文 §2，内存管理策略见本文 §3；v5.2 对齐冻结实现——原 bump-pointer 描述是早期设计草案，非实现事实）。根集六来源：VM 数据栈、调用帧局部槽、帧捕获槽（共享单元格）、全局环境、`register_foreign_ref` 登记的外部引用、活跃 continuation 帧链（r25/M5——本文 §3.2）。

**三阶段骨架**：

```rust
/// 分配：槽位表优先复用空闲表，耗尽则追加新槽（句柄稳定——u32 索引）
fn alloc<T>(heap: &mut Heap, make: impl Fn() -> HeapObj) -> GcRef {
    if let Some(r) = heap.free.pop() {          // 空闲表复用（后进先出）
        heap.slots[r.0 as usize] = Slot { obj: make(), marked: false };
        return r;
    }
    heap.slots.push(Slot { obj: make(), marked: false });  // 追加新槽
    GcRef(heap.slots.len() as u32 - 1)
}

fn gc_cycle(heap: &mut Heap, roots: &RootSet) {
    mark_all(roots, heap);   // 1. 标记：从根集可达的全部对象置位
    sweep(heap);             // 2. 清除：未标记对象归还 free 表（全量重建）
    heap.reset_alloc_counter(); // 3. 复位：分配计数归零，为下一轮摊销窗口
}

fn mark_all(roots: &RootSet, heap: &mut Heap) {
    let mut work: Vec<GcRef> = roots.collect();       // 显式工作栈（防递归爆栈）
    work.extend(heap.foreign_roots());               // 外部登记引用并入起点
    while let Some(obj) = work.pop() {
        if heap.test_and_set_mark(obj) { continue; }  // 已标记则跳过
        for child in heap.children(obj) { work.push(child); }
    }
}

fn sweep(heap: &mut Heap) {
    let mut new_free: Vec<GcRef> = Vec::new();
    for (i, slot) in heap.slots.iter().enumerate() {  // 线性遍历堆
        if !slot.marked {
            new_free.push(GcRef(i as u32));           // 归还 free 表（保守策略：泄漏容忍，误回收零容忍）
        }
    }
    heap.free = new_free;                             // 空闲表全量重建
}
```

**核心不变式**：
1. **根集完备性**：VM 数据栈、调用帧局部槽、**帧捕获槽（共享单元格）**、全局环境、`register_foreign_ref` 登记的外部引用（[13-能力矩阵 §4](./13-capability-matrix.md) FFI 预留）、**活跃 continuation 帧链（r25/M5）**——**六类根**缺一不可，漏根 = 悬垂指针（v5.2 修订：原「四类」漏帧捕获槽；v6.3 修订：r25 增第六源）
2. **标记位复位对称**：清除阶段重建空闲表后，存活槽的标记位与被回收槽的复用状态必须一致复位（新分配槽 `marked: false` 起步），否则下一轮标记会继承脏状态
3. **分配零内卷**：分配路径上不得调用任何可能触发回收的函数（含日志），否则递归触发 GC

**实现陷阱**：
- **递归标记的爆栈风险**：`mark(obj)` 递归深度 = 最长引用链。一个 10^7 元素的嵌套列表会爆 C 栈——因此骨架中用显式工作栈替代递归（这正是 jonesforth 与早期 MIT Lisp 都踩过的坑）
- **VM 执行中途的安全点**：GC 只能在指令边界触发（每 `GC_POLL_INTERVAL = 256` 条指令轮询分配配额），操作数栈中途的状态必须可枚举为根
- **碎片不治理的代价边界**：slot-Vec + 空闲表方案不移动对象（句柄稳定性）；Stage 0 允许「只分配不压缩」，碎片治理推迟到 Stage 2 分代/压缩 GC（TD-008）

## 5. 测试锚点（设计驱动测试，测试验证设计）

| 契约/不变式 | 测试锚点（tests/v0/stage0/ + examples/） | 验证命题 |
|-----------|------------------------------------------|---------|
| 根集完备性（§3.2 六来源） | gc_tests（深递归 + 分配计数驱动触发 + 环/深链/foreign） + examples/usage/gc_stress.ktf + effect_tests gc_continuation_boxed（第六源） | 漏根 = 悬垂检测 |
| 标记位复位对称（§4 不变式 2） | 多轮回收周期单测（free 表对账） | 复位无脏状态 |
| GC 不可观测（[06-操作语义 §4](./06-operational-semantics.md) L-GC） | 双执行路径互查（含堆效应程序，集成 164 函数内置） | 归约结果与触发点无关 |
| 冷却退避性能（§3.1） | gc_tests + CLI `kerf bench examples/usage/gc_stress.ktf`（122s → 3.4s 修复基线；当前单轮口径 ~0.17s / 3×10^5 分配） | O(n²) 消退 |
| I/O 通道（§1 契约） | examples/usage/io.ktf（print/read-line/str-append 回环） + RunOutcome 值存活验证 | 错误显式返回 |
| 外部引用登记（§3.1） | heap 单测：register_foreign_ref 后回收存活 | FFI 预留语义 |
| 堆栈追踪（§3.1 补注） | negative_semantics_tests::message_shape_call_site_trace（note 行帧链断言）+ vm_tests 双路径错误恢复 | 错误携带调用点 |

> 测试矩阵完整定义见 [11-测试基础设施 §3](./11-testing.md)；本表是其运行时侧子集。回收器观测经 `GcStats`（`heap.stats()`）暴露——性能数据是一等公民（[17-设计原则 §1 原则 16](./17-principles.md)）。

## 6. 错误统一效应模型登记：运行时面（v6.4 新增——r81 第十四轮吸收，同步自 stage0.md v7.3 §9.15）

> **本节定位**：next10.md 第二段「统一而分治」的运行时面收编——错误处理统一效应模型的 Stage 2+ 演进登记态。**零代码变更**（Stage 0 当前运行时 = 最小 I/O 通道三函数 + GC——§1/§3 契约不变；Error 效应族/官方六效应[Read/Write/State/Async/Error/Log]/handler 组合均未实现）。

**统一而分治裁定**（[17 原则 42](./17-principles.md) 同轮注册）：异常/错误/async/状态/IO 全部是计算流统一模型下的不同表现形式——统一模型（Perform/Handle + EffectRow + HandlerClause + 效应消除管线 + EffectSpace 归属五面）+ 分治策略（不同效应子空间各配 handler 策略——Error[恢复/终止/传播]/Async[调度/等待/超时]/State[读写/事务/回滚]——处理器值级组合）；panic/abort = Fatal 效应（用户可定义语义）；Result\<T,E\> = Error 项可选值表示（值级/效应级对偶）。

**运行时承载面**（实现时 = Stage 2+ 语义演进窗）：①效应帧栈（handler 安装/卸载与 continuation 帧链——现有 VM 帧栈的效应扩展形态）②resume one-shot 纪律（至多一次调用——文献锚 [19 §15](./19-references.md)：Soundly Handling Linearity / Affect 2025 / Kobayashi 2025）③Fatal/halt 语义 = 不 resume = 该计算分支终止（流终止是 handler 合法策略）④编译器自身错误不走效应系统（元层相位分离——R9 fail-closed 管辖）。**与编译期诊断的正交裁定**（stage0.md §9.15.6①）：本节全部为运行时语义面；编译期诊断（Span/多错误收集 r75-r80 生产实况）是编译器元信息系统——二者正交（编译期检查 = 效应系统的静态投影）。

## 7. 效应本体论登记：运行时面（v6.5 新增——r84 第十六轮吸收，同步自 stage0.md v7.5 §9.17）

> **驱动源**：next11.md 段 4-9——效应本体论三部曲（容器 → 概率域 → 完整生命周期）+ 终态定位裁定。本节登记其对运行时面的投影（**全部为解释框架层——机制层零变更义务**）。

**生命周期三阶段的运行时读法**：①**Perform 构造**（概率域未坍缩）——挂起当前计算 + 沿效应帧栈查找 handler（现有机制不变）；②**Handle 投影**（坍缩为具体实例）——handler 匹配即「从可能性中选择一种实现」（选择做什么/怎么做——「Handle 是选择而非拦截」）；③**Resume 后续**（可选桥梁）——`resume ∈ {0, 1}` 完整语义：**one-shot 纪律（§6——至多一次）+ Resume 可选性（本轮——可以零次）合围**；不 resume = 完全合法的流终止（与 §6 Fatal/halt 语义同构——「流终止是 handler 合法策略」的语义补强；纠正现有系统隐含「应该 resume」偏见）。

**理论登记与机制兼容裁定**（[17 原则 45](./17-principles.md) 同轮注册）：效应本体论三部曲与现有效应系统（Koka/OCaml 5/Unison）为「同一系统两种描述」——机制层（Perform/Handle/Resume 原语 + 效应帧栈 + continuation 实现 + 效应消除优化）100% 兼容，**零实现成本**；概率域四维结构（行为/工具/内容/后续 = `Action × Mechanism × Payload × Continuation`）是容器模型的深化解释（登记态——渐进实现路径：容器先行）。**运行时面义务清单零变更**：效应帧栈形态/resume one-shot 检查/Fatal 处理均按 §6 既有登记维持；容器消除优化（编译期将 `Return(i64)` 直接优化为 i64——「真正需要容器」时才创建）登记为 Stage 2+ 优化窗方向注记（与效应消除管线同族）。

**容器模型对 §6 的语义补强**：`Return(T)` 与 `Error` 为平等容器（无「正常/异常」主次之分）——`Result<T,E>` 值级表示 = 容器模型的值级投影（对偶裁定的本体论表述）；「对容器的操作（效应处理）独立于对内容的操作（数据处理）」= 运行时优化可独立优化两条路径的理论依据（登记态）。

## 8. 效应流形运行时面：EffectGraph 与流形分析 Pass（v6.6 新增——r88 第十七轮吸收，同步自 stage0.md v7.6 §9.18.6）

> **本节定位**：next12.md 第十七轮吸收的运行时面收编——EffectGraph 编译器内部表示 + EffectManifoldAnalysisPass 流形分析。全节 Stage 2+ 设计登记态（**非运行时义务**——EffectGraph 为编译器分析层数据结构非 VM 运行时结构；机制兼容裁定 [17 原则 46]：三连接在 8 原语中可表达，零新增原语零机制层变更）。

**EffectGraph 编译器内部表示（Stage 2+ 登记态）**：`EffectGraph { nodes: Arena<EffectNode>, edges: Vec<EffectEdge>, entry/exit: NodeId }`——节点 `EffectNode { effect: EffectKind, payload_type, expr_ref: CoreExprId, space_id: SpaceId }`；边型三枚举：`Sequential { from, to, condition }`（串联）/ `Nested { outer, inner, handler_ref }`（嵌套）/ `Cyclic { a, b, fixpoint_type }`（循环）。三操作：`from_core_expr`（从 CoreExpr 构建）、`slice(dimension)`（切片——只保留指定维度节点与相关边的子图）、`project()`（降维——投影到 EffectRow）、`lift(row)`（升维——从效应行恢复含自由连接的流形图）。

**流形分析 Pass（Stage 2+ 优化素材登记）**：`EffectManifoldAnalysisPass` 于 Layer 2→3 转换时执行——①构建效应图 → ②识别效应连接模式 → ③优化机会分析 → ④应用优化：**MergeSequential**（相邻串联效应合并）/ **HoistNested**（内层 handler 外提）/ **DetectLoop**（循环模式识别）。与 §6 效应帧栈运行时实况的关系：Pass 为编译期分析（帧栈为运行时机制）——两正交层面（分析层优化机会非运行时变更）。

**流形概念空间归属（双分层裁定）**：`EffectGraph` → CompilerSpace（编译器内部数据结构/实现表示）vs `EffectManifold` → EffectSpace（概念理论/用户可见抽象）——经 Reader/Expander 桥接（「用户写流形操作，编译器转为图分析」）；实现/理论两侧正交分层——与「机制/解释分层」（[stage0.md §9.18.3](../stage0.md) H-A→I-A）同构的空间面投影。

**EffectTrace 桥接层（§7 信息系统三层架构的运行时关联）**：编译器为效应密集代码生成的可选调试模式（效应执行日志/追踪 → 调试工具 + 性能分析双用途）——与双向调试策略（模式识别器双重用途）协同的第三实例；F13 两通道分立的新覆盖层（非诊断非效应——「效应执行的观测设施」）。

**审查注记**：效应流形理论本体与操作语义规则见 [stage0.md §9.18.3/§9.18.4](../stage0.md) 与 [06 §10](./06-operational-semantics.md)；空间归属的完整层级图见 [24 §15](./24-space-decomposition.md)。

## 9. 逆向效应运行时面：双向 Continuation 与坍缩调度（v6.7 新增——r89 第十八轮吸收，同步自 stage0.md v7.7 §9.19.4/§9.19.6）

> **本节定位**：next12.md 追加段的运行时面收编——逆向效应（Consume/Offer/Rewind）的运行时机制 + 伪随机坍缩调度。全节 Stage 2+ 设计登记态（Stage 0-1 continuation 为单挂起点恢复形态——§9.15.6 显式 continuation 类型裁定实况维持；语料自评「双向 continuation 是现有系统完全未探索的领域」——登记不实现）。

**8 原语闭合（运行时面）**：Consume = Perform(Receive)（「等待接收」是「发起一个等待效应」）/ Offer = Handle 的服务提供模式 / Rewind = Resume 的多目标版本（多播回传）——逆向三操作 = 正向三原语的使用模式，**零新增原语零机制层变更**（[17 原则 47] J-A：8 原语闭合三轮验证[r84 载体映射 + r88 流形映射 + r89 逆向/干涉/坍缩映射]）。

**双向 Continuation（登记态）**：`Continuation::Forward { position, env, parent }`（单播恢复——现行形态）/ `Continuation::Rewind { waiters: Vec<WaitingComputation>, service_context }`（多播回传——`WaitingComputation { waiting_for, position, env, parent }`）；**EffectScheduler**：forward_queue / reverse_queue / active_offers 三队列 + handle_perform（匹配 Offer 直接调用否则入队）/ handle_consume（匹配 pending 正向效应配对否则入队）/ rewind_to（Forward 单播 vs Rewind 多播分派）/ register_offer（服务上线 + 清空逆向等待队列）四方法——正逆效应的配对调度设施。

**Randomness 效应（语言级效应面登记——J-E）**：`next() -> f64`（[0,1) 均匀）/ `with_seed(s: u64)`（可重现性）/ `uniform/normal/exponential/weighted_choice/shuffle` 操作集——实现层 **PCG32**（[19 §19] E.19-125 O'Neill 检索锚）；测试模式固定种子完全可重现（`Randomness::next() => resume(0.5)`）。**裁定**：伪随机性 = 语言级效应（被 Handle 投影——策略外置：测试确定性 vs 生产熵源由 handler 决定）**非运行时内建全局函数**——与 Stage 0 最小 I/O 传统全局函数实况分立维持；登记为 Stage 2+ 目标语言 **std 效应族候选**（[09-标准库] 联动）。

**CollapseScheduler（登记态）**：`Pcg32 rng` + `competitive_offers: HashMap<EffectKind, Vec<WeightedOffer>>` + `collapse()`（轮盘赌选择：total 权重累积扫描 + fallback 均匀随机）+ `deterministic_select()`（传统模式——最近优先 innermost-first 或用户声明优先级）。**坍缩谱系**：确定性坍缩（传统 Handle）→ 伪随机坍缩（P₁+P₂=1 概率分派——方案 A = Randomness 效应 + 条件分支 / 方案 B = 多 Offer 竞争 + 加权调度）→ 真随机坍缩（量子——层次 2 预留非承诺）。

**InterferenceAnalysisPass（编译期分析登记）**：四步——①find_shared_resources ②非对易 handler 对检测（`is_non_commutative: ab != ba` + `compute_commutator`）③干涉记录 + ComputationalUncertainty 诊断 ④优化三分支（Constructive→合并增强 / Destructive→死代码消除 / Entangled→可并行化检测）。**与 §8 流形分析 Pass 的关系**：同一 EffectGraph 素材三 Pass 分立（流形分析[连接模式] / 干涉分析[共享资源非对易] / 坍缩调度[概率选择]——三 Pass 正交职责，Stage 2+ 优化窗素材）。

**审查注记**：正逆组合语义四规则与类型规则五条见 [06 §11](./06-operational-semantics.md)；干涉/坍缩三子空间归属见 [24 §16](./24-space-decomposition.md)；逆向对偶理论本体（双幺半群 + 对偶范畴）见 [stage0.md §9.19.2](../stage0.md)。

## 10. 量子分析 Pass D 与路径积分运行时面（v6.8 新增——r91 第十九轮吸收，同步自 stage0.md v7.8 §9.20.5/§9.20.6）

**五 Pass 分立全景（首次成型——编译器分析 Pass 总图）**：**Pass A 基础优化**（Stage 0-2：模式识别 + 等价替换 / 常量折叠 / 死代码消除 / 效应消除[Koka 风格]——§6.13 既有登记）/ **Pass B 流形分析**（Stage 2-3：效应图构建 + 连接分析 + 正逆配对检测 + 并行化机会识别——r88 登记）/ **Pass C 拓扑分析**（Stage 3：同调计算[死锁 H₁] + 曲率计算[非对易交换子] + 欧拉示性数 + 守恒律检测[上同调]——r91 登记，组合拓扑精确同构 K-A 第一级）/ **Pass D 量子分析**（Stage 3+ 可选：干涉图样 + 纠缠检测 + 路径积分 + 波粒二象性分析——r91 登记）/ r89 干涉坍缩 Pass（InterferenceAnalysisPass + CollapseScheduler）——**各自正交职责**（基础优化/流形连接/组合拓扑/共享资源非对易/量子隐喻分析）。

**EffectPathIntegral（路径积分计算版——登记态 Stage 3+）**：`initial`/`final_`/`paths: Vec<EffectPath>` + `total_amplitude()`（所有路径贡献叠加——`结果 = ∑ 所有处理路径 Weight[path]`）+ `interference_pattern()`（同终点路径对两两干涉——相长 Constructive / 相消 Destructive / 部分 Partial / 无 None 四态）。**EffectPath**：`handlers: Vec<HandlerSequence>` / `action: Cost`（总处理成本）/ `phase` + `amplitude()`（成本的指数衰减——「振幅」为隐喻术语，计算版本 = 权重）。

**对账裁定**：路径积分 = **枚举语义**（所有 Handle 顺序穷举分析——与 r89 交换子 `[A,B]_R = A∘B(R) ⊖ B∘A(R)` 的**差分语义**互补：全路径清单+叠加权重 vs 两路径差值聚焦）；「干涉的精确计算可能 NP-hard」（语料「永不 100%」自载）→ 近似算法/启发式路径登记；量子场论映射九对（场→效应流形/粒子→perform 事件/激发→Perform 触发/传播子→Handle 处理链/相互作用→干涉/费曼图→效应路径图/真空→无效应状态/虚粒子→未被 Handle 的效应/重整化→归一化）为隐喻登记族（J-B 口径——虚粒子项语义对应精确：效应未被投影 = 传播中的可能态）。

**贝尔不等式诊断性守卫（K-B 裁定——运行时面投影）**：`classical_bound`/`observed_correlation`/`is_violated` → `QuantumAdvantage::Present`——经典计算系统关联必然 ≤ 经典上限（局域性在计算图天然满足），`is_violated` 分支在经典实现上**不可达**：登记为**守卫代码形态**（若可达则实现错误——理论完备性断言非能力宣称）；与效应纠缠（AllOrNothing/Majority/Correlated 规则——事务/共识语义类型面登记 Stage 3+）同族。

**审查注记**：波粒二象性语义注记与 EffectUncertainty 两形态见 [06 §12](./06-operational-semantics.md)；拓扑能力行与 Pass C/D 能力面见 [13 §3.14](./13-capability-matrix.md)；理论-实现分层映射（K-F）见 [stage0.md §9.20.6](../stage0.md)。

---

## 11. 能力操作运行时面：四层次通道与度规开销（v6.9 新增——r93 第二十轮吸收，同步自 stage0.md v7.9 §9.21.5/§9.21.6）

> **本节定位**：next14.md Doc4/Doc5 的运行时面收编。零代码变更；通道与开销策略登记（层次 2-4 = 触发式远窗——判据 = 用户信号）。同步：[21 §10.4](./21-capability-architecture.md)、[06 §13 对照]。

**环境五元组扩展**：`⟨e, ρ, σ, κ, C⟩`（+C = 能力度规运行期状态通道——§9 逆向效应四元组的加性扩展）——**通道分立**：层次 1 门控（编译期）无 C 通道（kerf E0006 既有形态零变更）；层次 2-4 走 C 通道（度规查询/状态更新/迭代演化）。**耦合动力学四规则族**（操作语义登记态）：[PERFORM-WITH-CAP]（cap 线性消耗 + C 更新）/ [AMPLIFY/RESTRICT/TRANSFORM]（度规调制三形）/ [COLLAPSE/INTERFERE/ANNIHILATE]（量子操作三形）/ [COUPLED-EVOLUTION]（传播→度规演化→新传播循环直到 `‖Cₙ₊₁-Cₙ‖ < ε` + max_iterations 防发散 + fallback）。

**度规开销三策略**（层次 2 优化经济学——与 TD-028 帧槽池/分派优化同族）：编译期度规解析（静态能力 ~70% 场景零开销）/ 度规 LRU 缓存（~20% O(1)）/ 度规消除优化（恒定区域批量 ~10%）——平均 < 5%。**线性类型实施三方案**：Stage 0-1 方案 C（运行时计数器）→ Stage 2+ 方案 B（轻量标注 use-once 检查）→ Stage 3+ 评估方案 A（借用检查器）——脚手架哲学渐进增强同构。**收敛性登记**：Lotka-Volterra 类比三失败模式（振荡/发散/混沌）+ 三缓解机制（强制收敛+fallback / 阻尼项 λ / 安全锥 δ）——收敛性证明 = 数学难题（E.21-127 Tahara 修改 LV 渐近稳定锚——数值验证缓解——置信度 60% 中）。

## 12. 生命周期效应运行时面：with_resource Handle 语义与消除三形（v6.10 新增——r94 第二十一轮吸收，同步自 stage0.md v8.0 §9.22.2/§9.22.3）

> **本节定位**：next15.md 生命周期效应化的运行时面收编。零代码变更；登记态（Stage 2+ 语料位）。同步：[13 §3.16](./13-capability-matrix.md)、[02 §8.10](./02-syntax-model.md)、[09 §7](./09-stdlib.md)。

**with_resource = Handle 作用域语义**：`handle { acquire → body → result } { Return(r) => release + r / Error(e) => release + 传播[RAII 效应化——错误路径同样释放] / use(...) => resume(数据)[handle 继续有效] / transfer(...) => resume(())[所有权移出作用域] }`——四臂全部既有 Handle 臂形态（零新运行时机制）。**借用冲突三处置策略** = handler 值级实现自由（拒绝[编译错误 halt] / 等待[阻塞至可变借用释放] / 排队[延迟不可变借用]——策略外置，与 §7 效应本体论「同一系统两种描述」一致）。

**LifecycleAnalysisPass 与消除三形（Stage 2+ 优化窗 pass 候选）**：五 Phase（收集生命周期效应 → 构建 EffectFlow{effects 序列 + topology} → 验证规则三[Acquire 前置 / Release 后无 Use 悬垂引用 / 线性流 Acquire→Use+→Release] → 借用干涉分析[immutable+mutable 共存 / 多 mutable] → 消除优化）——**消除三形**：FullElimination（简单作用域——无分支无转移，完全消除运行时检查）/ PartialElimination（静态借用——消除借用计数与冲突检测）/ Optimized（动态模式——保留检查优化粒度）。**渐进结果**：简单零运行时开销 / 复杂最小检查 / 全部编译期安全保证——Koka 效应消除迁移（E.22-131 锚）。**效应分析管线单点性风险登记**：所有功能（生命周期/借用/能力/优化/类型五下游）依赖效应分析——缓解三策略（分层实现[Stage 0 基础 ~500 行已生产超交付] / 多级缓存[函数级 + 模块级 + 增量——与 TD-032 缓存段 r90 同族工程方向] / 保守-乐观双模式[开发保守/发布乐观/用户可配置——**乐观仅限性能优化域，安全域[E0006]恒保守 fail-closed**]）。

## 13. 信息效应运行时面（v6.11 新增——r111 第二十六轮吸收，同步自 stage0.md v8.5 §9.27.2/§9.27.3）

**运行时机制零增量登记**：信息效应五类（Error/Warning/Hint/Debug/Performance）在运行时全部经 **perform/handle 既有机制**承载——用户 `perform AppLog::info(msg)` → 效应帧入栈 → handler 臂处置（report/suppress/collect = 臂内标准库函数调用；策略 = handler 值级实现自由）。**零新增 VM 指令、零新增效应通道**（8 原语不变性第十轮验证——与 §7-§12 五轮先例同构：机制 100% 兼容，理论演进零运行时义务）。

**观测与轨迹的运行时形态（Stage 2+ 登记态）**：DebugTrace 轨迹 = EffectGraph 既有分析对象（§8 流形运行时面）的路径查询产物——运行时仅需「效应执行历史的记录开关」（观测分级 errors→full = 配置面粒度，非机制面分叉）；PerformanceProfile = 性能基准能力（操作基础层）与效应轨迹的组合分析。**F13 正交裁定沿袭**：编译器自身诊断（Diagnostic 结构/错误收集）走值通道恒定——编译期错误的「运行时」不存在（编译产物拒绝 = 编译器控制流，非目标程序效应）；运行时信息效应 = 用户程序 Error 效应（原则 42 既有面）的推广族。上游全量 = [stage0.md §9.27](../stage0.md)；空间归位 = [24 §22](./24-space-decomposition.md)。

## 14. 种子演进运行时面（v6.12 新增——r113 第二十七轮吸收，同步自 stage0.md v8.6 §9.28.6 时间性命题四）

> 本节登记流特性理论 FLW-E（随机种子随流共同演进）的运行时面对账注记——**零运行时变更**（既有 VM 状态线程与 Randomness 效应原样维持）。

**种子演进 = VM 确定性状态演化（既有实况对账）**：理论命题「Seed(t+1)=Evolve(Seed(t), Flow(t))」的运行时承载 = Randomness 效应（r89——PCG32 确定性种子 + 状态线程演进）：每 perform Randomness = 种子前移一步（确定性状态转移——「随机性在此时刻的随机能力」= PRNG 状态的物理层叙事）。**确定性纪律维持**：kerf 运行时无内建非确定性——种子演进是确定性状态演化（同种子同轨迹——fixpoint 三阶段验证的确定性基础不受扰动）；非确定性语义仅经 Randomness 效应显式引入（r89 登记态）。**DimensionalSeed/Freedom 四级 = Stage 3+ 分析愿景登记态**（理论结构体——非运行时结构；未来入分析层须过 MU-B Pass 单源纪律）。

## 15. NLL 段结束推导运行时面（v6.13 新增——r115 第二十八轮吸收，同步自 stage0.md v8.7 §9.29.2/§9.29.3）

> **本节定位**：next20.md 统一流分析的运行时面注记——**零 VM 变更、零通道增量、零指令集扩展**（借用段/流分析 = 编译期分析层概念——运行时承载为零）。

- **借用时间段语义（登记态）**：引用类型的默认生命周期 = [Borrow(x)]—[Return(x)] 借用时间段——段结束 = 最后一次使用点（NLL 段结束推导——FLOW-SEGMENT-END 规则；Polonius 先例 E.29-160[Datalog 数据流借用检查]）；**运行时面零承载**：段级分析 = Stage 2+ 分析窗 UnifiedFlowAnalysisPass 相位 2（编译期——VM 无涉）。
- **资源类型完整流语义**：[Acquire]—[Use]*—[Release] = §12 生命周期效应运行时面（r94 with_resource Handle 四臂语义）的投影算子重述——π_time 投影（Lifetime(T)=π_time(EffectFlow(T))）；Perform(Acquire/Release) 模式 = 既有效应机制承载（零新原语——8 原语不变性第十二轮验证）。
- **统一流分析 = 编译期分析管线**：四相位（构建效应流图→时间段分析→干涉分析→诊断生成）全部编译期承载——运行时面唯一关联 = 诊断信息的 INFO-A 状态投影面（错误/警告 = 流干涉的可视化投影——§13 信息效应运行时面既有机制承载）。
- **与 §14 种子演进的关系**：NLL 段结束推导的确定性 = 小步语义确定性转移的借用面实例（时间维度投影的确定性——与 Randomness 种子演进的随机维度对偶；分析层确定性 vs 运行时随机性——分层正交）。

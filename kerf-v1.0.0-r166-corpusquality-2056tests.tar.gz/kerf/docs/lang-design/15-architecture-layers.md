# 架构分层与各层设计总览

> **Author**: kerf-doc-agent
> **Date**: 2026-09-24（**v6.3——r66 核心空间统一规划**：§5.3 增注[五正交轴 = 核心空间七核心域的划分来源——**域是轴的宏观归并**（[24 v2.0 §4.2](./24-space-decomposition.md) 双侧统一体系：每核心域 = 1-2 个轴同簇 crate；10 crate 主类型三层 impl 归属核心域]——架构分层[15 权威]与空间从属[24 权威]两轴判据互不冲突）]）；2026-09-17（**v6.2——r58 第十轮吸收**：§5.2 四层修正案注记[四维正交框架 + 6→4 合并对照 + Stage 2 优化窗裁定候选]——同步自 stage0.md §6.13.2；2026-09-10（v6.0：§5 增补 §5.3 表面/内部语法分离与四层正交的交汇注记——next3.md 第七轮吸收；v5.5：新增 §5 四层正交对照与 IR 层级演进））
> **Version**: v6.5（**r111 第二十六轮吸收——§5.5 信息流管线层愿景**[架构叙事层登记——七阶段信息面投影 + with_info_collector = 既有接口愿景完备化 + F13 值通道维持——同步自 stage0.md v8.5 §9.27.6]）；v6.4（r95 第二十二轮吸收——§5.4 统一流形分析中心愿景与分析单源[Stage 3+ 愿景层档案 + 三级单源体系 + 六分析投影——同步自 stage0.md v8.1 §9.23.3/§9.23.6]）；v6.3（r66 核心空间统一规划——§5.3 五轴=核心域归并注记；v6.2：r58 第十轮吸收——§5.2 注记；v6.1 完整性审查联动：预留层 4→14 项注记 + 查询双预留互链）
> **Status**: Active

> 本文件收录架构分层与完整总览（原 §10：能力视角总图、分层视角总图、单向依赖规则、调用关系与数据流、层级依赖规则）以及基础设施层（原 §12）、工程支撑层与理论边界层（原 §13）、外围能力层与操作基础层（原 §14）的框架设计。其中已按主题拆出的小节（Span/诊断 → [02-语法模型](./02-syntax-model.md)、相位分离 → [03-宏系统](./03-macro-system.md)、内存管理 → [05-运行时](./05-runtime.md)、工具链/基准/自调试 → [10-工具链](./10-toolchain.md)、文档流程 → [09-标准库](./09-stdlib.md)、测试 → [11-测试](./11-testing.md)、操作语义 → [06-操作语义](./06-operational-semantics.md)）在本文件保留章节导引。12 个能力模型的定义见 [13-能力矩阵](./13-capability-matrix.md)。

---

## 1. 架构分层与完整总览（原 §10）

> **本章合并了原 §8.5（架构分层与调用关系）与原 §20（完整架构总览）。** 架构从两个正交视角呈现：§1.1 是能力视角（哪些能力属于哪一层），§1.2 是分层视角（六层结构各自的职责），§1.3-§1.5 给出两视角共同遵守的依赖规则与数据流。任何新增设计必须同时通过这两个视角的一致性检查——能力归属明确、依赖方向单向。

### 1.1 能力视角总图（2026 v4.0）（原 §10.1）

下图将 [13-能力矩阵 §1.1](./13-capability-matrix.md) 三层分类矩阵转化为依赖关系图：实线为管线内的顺序依赖，虚线为横切贯穿或接口预留关系。

```mermaid
flowchart TD
    subgraph MustImplement["必须实现（Stage 0）"]
        A["类型化 Token 流 Reader"]
        B["图 IR + 共享节点"]
        C["结构化 CodeValue"]
        D["元循环求值器<br/>（传统 eval/apply）"]
        E["基础闭包<br/>（词法作用域）"]
        F["Span 全管线传播"]
        G["结构化诊断框架"]
        H["最小 I/O<br/>（传统全局函数）"]
        I["相位分离系统<br/>（Phase 0/1）"]
        J["基础宏系统<br/>（卫生宏）"]
        K["标记-清除 GC"]
        L["字节码 VM"]
    end

    subgraph InterfaceReserved["接口预留（Stage 1-2）"]
        M["Effect Handlers<br/>（仅类型定义）"]
        N["多阶段编程<br/>（仅类型定义）"]
        O["能力模型 I/O<br/>（仅类型定义）"]
        P["编译缓存<br/>（仅接口定义）"]
    end

    subgraph Deferred["完全推迟（Stage 2+）"]
        Q["LSP / 本地码 / 类型检查 / 高级 GC / 优化 / FFI / 并发 / JIT"]
    end

    A --> B
    B --> C
    C --> D
    D --> E

    F -.->|贯穿所有层| MustImplement
    G -.->|贯穿所有层| MustImplement
    I -.->|约束宏系统| J

    M -.->|接口预留| D
    N -.->|接口预留| C
    O -.->|接口预留| H
    P -.->|接口预留| B

    classDef mustNode fill:#E8F1FA,stroke:#2B6CB0,stroke-width:2px
    classDef reservedNode fill:#FFF9E6,stroke:#B7791F,stroke-dasharray:5 3
    classDef deferredNode fill:#FAFAFA,stroke:#718096,stroke-dasharray:2 3
    class A,B,C,D,E,F,G,H,I,J,K,L mustNode
    class M,N,O,P reservedNode
    class Q deferredNode
```

上图「接口预留」子图仅示既有四项（M-P）；v6.1 完整性审查后预留层扩至 14 项（新增 LSP 查询/调试信息/FFI 边界/增量查询/服务化/多后端/包管理/AI 辅助等 10 项——完整清单与依赖落位见 [13-能力矩阵 §3.4](./13-capability-matrix.md) 矩阵与 [§3.5.3 全景图](./13-capability-matrix.md)）；「完全推迟」子图相应缩减（LSP 与 FFI 移出）。

### 1.2 分层视角总图（原 §10.2）

下图给出六层结构的总览：语义引擎核心（Reader → Expander → Compiler → VM → Runtime）构成主管线，基础设施层（本文 §2）横向贯穿，工程支撑层与理论边界层（本文 §3）从外部支撑与约束，外围能力层与操作基础层（本文 §4）提供环境保障。

```mermaid
flowchart TD
    subgraph Semantic["语义引擎核心"]
        A["Reader"] --> B["Expander"]
        B --> C["Compiler"]
        C --> D["VM"]
        D --> E["Runtime"]
    end

    subgraph Infra["基础设施层"]
        F["Span 追踪"]
        G["诊断框架"]
        H["相位分离"]
    end

    subgraph Eng["工程支撑层"]
        I["查询式增量编译"]
        J["测试基础设施"]
        K["编译缓存"]
    end

    subgraph Theory["理论边界层"]
        L["操作语义"]
        M["版本策略"]
    end

    subgraph Periph["外围能力层"]
        N["安全信任"]
        O["内存管理"]
        P["跨平台"]
        Q["工具链 LSP"]
        R["规范文档"]
    end

    subgraph Ops["操作基础层"]
        S["Unicode"]
        T["运行时错误"]
        U["性能基准"]
        V["编译器自调试"]
    end

    Infra -.->|贯穿| Semantic
    Eng -.->|支撑| Semantic
    Theory -.->|约束| Semantic
    Periph -.->|服务| Semantic
    Ops -.->|保障| Semantic

    classDef semanticNode fill:#E8F1FA,stroke:#2B6CB0,stroke-width:2px
    classDef infraNode fill:#F0FFF4,stroke:#2F855A
    classDef supportNode fill:#FFF9E6,stroke:#B7791F
    class A,B,C,D,E semanticNode
    class F,G,H infraNode
    class I,J,K,L,M,N,O,P,Q,R,S,T,U,V supportNode
```

### 1.3 单向依赖规则（原 §10.3）

**单向依赖规则**：`Reader → Expander → Compiler → VM → Runtime`。

**相位分离**：Phase 0（运行时）/ Phase 1（编译时）/ Phase -1（被导入用于 Phase 1 的模块）。核心规则：一个相位的输出是下一个相位使用的代码，禁止任何直接的值传递。

**数据流分离**：编译时数据（SyntaxObject、CoreExpr）和运行时数据（Value、Pair）是不同的类型，禁止混用。

**接口契约规则**：
1. 每个接口是纯函数（无副作用，幂等）
2. 错误必须显式返回（Result 类型），禁止异常
3. 数据类型在模块间传递时不可变
4. 接口签名一旦冻结，向后兼容必须永久保持

### 1.4 调用关系与数据流（原 §10.4）

```text
单向数据流（严格禁止反向依赖）：

字符流 
  → [Reader] → Token 流（携带 Span/Scope）
    → [Parser] → Graph IR（共享节点）
      → [Macro Expander] → 展开的 Graph IR
        → [CodeValue 构造] → 结构化代码值
          → [元循环求值器] → 执行结果
            → [输出（最小 I/O）]

横向贯穿（所有阶段可用）：
  - Span 系统：查询源位置
  - 诊断框架：报告错误
  - 相位分离：区分编译时/运行时
```

### 1.5 层级依赖规则（原 §10.5）

```text
Layer 0: 最小 I/O Runtime（无依赖）
Layer 1: Span 系统 + 诊断框架（依赖 Layer 0 用于输出）
Layer 2: Token/Reader（依赖 Layer 1 用于 Span）
Layer 3: Graph IR（依赖 Layer 2 用于构造）
Layer 4: CodeValue + 宏系统（依赖 Layer 3）
Layer 5: 元循环求值器（依赖 Layer 4）
Layer 6: 相位分离系统（依赖 Layer 4-5 用于协调）
```

**规则**：上层可以依赖下层，反之禁止。同层之间通过显式接口交互。

#### 1.5.1 「7 层 → 9 crate」映射表（v5.2 补——设计层级与实现裁定的对账，deep-review R1 偏差 #19）

Stage 0 冻结实现为 Cargo Workspace 9 成员 crate（[12-路线图 §3.2](./12-roadmap.md) 目录蓝图 → 实际落地为 `crates/kerf-*`；实测 24 成员边 + 根 9 边 + 1 dev-dep，DAG 无环）。设计七层与实现 crate 的映射及裁定注记：

| 设计层级 | 实现 crate | 裁定注记 |
|---------|-----------|----------|
| L0 最小 I/O Runtime | `kerf-runtime` | **零依赖双基座之一**（堆 + GC + I/O 通道，Layer 0 无依赖裁定满足） |
| L1 Span + 诊断 | `kerf-span` | **零依赖双基座之二**（Span/Diagnostic 不依赖 runtime——诊断渲染自包含；层内「依赖 L0 用于输出」被简化为零依赖，实现更严格） |
| （横切） | `kerf-syntax` | **无层槽位**：SymbolTable/ScopeSet/Stx 是 L1-L4 的横切数据基座（符号内化与作用域集被 Reader/Expander 共同消费），不占七层任一槽位 |
| L2 Token/Reader | `kerf-reader` | 依赖 span + syntax（Span + 符号表） |
| L3 Graph IR + CoreExpr | `kerf-core` | **简化裁定：core 不依赖 reader**（CoreExpr/图 IR/CodeValue 直接消费 Stx 数据结构而非 Token 流——设计上「依赖 L2 用于构造」在实现中降为共享 syntax 数据基座，依赖图更平） |
| L4 CodeValue + 宏系统 | `kerf-expander` | 依赖 core + syntax（展开产物为 CoreExpr） |
| L5 元循环求值器 / 编译器 | `kerf-vm`（eval）+ `kerf-compiler` | compiler 依赖 core（Op 定义于 compiler，vm 为消费者）；**vm → runtime 定向裁定**：§18.5 图 L6→L7 边按 §2.4.5「Layer 0 无依赖」裁定为 kerf-vm 依赖 kerf-runtime（Op 定义权归 compiler 的附带裁定），完整论述见 [管线数据流图](../graph/pipeline/data-flow.md) |
| L6 相位分离协调 | （并入 `kerf-expander/src/phase.rs`） | 相位簿记不独立成 crate——它是 Expander/Compiler 的共享上下文（本文 §2/§2.3 横切属性的落地） |
| 管线编排 | `kerf-driver` | 全依赖汇聚点（§14.7.2 B4：reader 仅 driver 调用；四项接口预留冻结于 driver 的 reserved.rs **单文件**——设计草案的 reserved/ 目录四文件裁定为单文件收敛） |

**目录蓝图与实现的差异注记**：(1) 设计蓝图的 `src/layerN/` 单 crate 目录被裁定为 **Cargo workspace 多 crate** 结构（§8.4.6 两级结构——编译边界即接口冻结边界）；(2) `vm/`（C 实现）未落地——**Runtime/VM 以 C 为基座的口径改为「Rust 实现 + C 语义验证」**：Stage 0 全部 Rust 实现（零外部依赖），C 基座是 Stage 2+ 后端演化（[08-后端演化](./08-backend-evolution.md)）的选项而非 Stage 0 交付项；(3) `benchmarks/` 目录为空占位——实际基准载体是 CLI `bench` 子命令 + `examples/usage/`（见 [04 §4 测试锚点](./04-bytecode-vm.md)）。

---

## 2. 基础设施层：横切关注点设计（原 §12）

基础设施层的三个组件（Span、诊断、相位分离）是**横切关注点**：它们不处于编译管线的主数据流上，却被管线每个阶段消费。本章论述其架构约束；数据结构与能力模型的规范定义分别在 [02-语法模型 §2/§3/§4/§5](./02-syntax-model.md)（Span、诊断）与 [03-宏系统 §1/§3](./03-macro-system.md)（相位分离），二者构成"定义 vs 架构"的分离视图（同一文本的规范副本亦见 [13-能力矩阵 §2.6/§2.7/§2.9](./13-capability-matrix.md)——修订时三处需同步）。

- **§12.1 Span 源位置追踪系统** → 已拆分至 [02-语法模型 §4](./02-syntax-model.md)（设计原则、不可推迟的理由、管线各阶段消费方式表）
- **§12.2 诊断框架** → 已拆分至 [02-语法模型 §5](./02-syntax-model.md)（"错误是数据而非异常"的架构约束与三个直接后果）
- **§12.3 模块相位分离系统** → 已拆分至 [03-宏系统 §3](./03-macro-system.md)（横切属性：相位表作为 Expander 与 Compiler 的共享上下文）

---

## 3. 工程支撑层与理论边界层设计（原 §13）

> **本章合并了原 §11（工程支撑层）与原 §12（理论边界层）。** §13.1-§13.3 是工程支撑层——让编译器在大型代码库上保持可演化（增量编译、测试、缓存）；§13.4-§13.5 是理论边界层——为语义提供可验证的规范锚点（操作语义、版本兼容）。前者服务于"工程可行"，后者服务于"正确性可证"，二者共同构成语义引擎核心的外部约束环。

### 3.1 查询式增量编译架构（原 §13.1）

将编译过程建模为纯函数查询图（借鉴 rustc 的查询系统和 Salsa 框架）。查询是纯函数、依赖必须完整声明、失效按需传播。

v6.1 注记：该架构的 Stage 0 接口预留（`QuerySystem`/`Query` trait，P0）见 [13-能力矩阵 §3.3.5](./13-capability-matrix.md)——与 [13-能力矩阵 §3.1.4](./13-capability-matrix.md) 编译缓存构成「缓存（数据面）+ 查询（架构面）」双预留；Stage 1+ 的实现应直接落地这两个 trait，而非另起接口。

### 3.2 测试基础设施（原 §13.2）

三层测试：快照测试（确定性输出）、黄金文件测试（预期输出 diff）、自举测试（两次编译自身，比较字节一致性）。已拆分至 [11-测试基础设施](./11-testing.md)（含双执行路径互查与 Stage 0 验收测试项汇总）。

### 3.3 编译缓存（原 §13.3）

与查询系统天然集成：查询缓存就是编译缓存。Stage 0 仅设计接口，Stage 1+ 实现具体的查询式缓存。

编译缓存的接口预留定义见 [13-能力矩阵 §3.1.4](./13-capability-matrix.md)；Stage 1+ 的实现应直接落地该 trait，而非另起接口。

### 3.4 操作语义形式化定义（原 §13.4）

9 个核心原语的完整小步操作语义（归约规则）、错误吸收语义、GC 不可观测性引理，以及编译正确性定理（对任意源程序 `p`，如果 `p →* v`，那么 `compile(p) →* v`）——源文档 §13.4 仅有一句承诺，v5.1 已在 [06-操作语义](./06-operational-semantics.md) 从 Stage 0 冻结实现反向提炼补齐（归约规则组 R1–R9、定理 T1 三引理证明纲要）。

### 3.5 版本兼容性策略（原 §13.5）

**核心冻结原则**：9 个核心原语的语义在整个语言生命周期内不变，所有演化通过宏系统在核心之上叠加。

---

## 4. 外围能力层与操作基础层设计（原 §14）

> **本章合并了原 §13（外围能力层）与原 §14（操作基础层）。** §14.1-§14.5 是外围能力层——服务编译器之外的信任、内存、平台与文档需求；§14.6-§14.9 是操作基础层——支撑编译器自身的运行环境（Unicode、运行时错误、基准、自调试）。这些能力全部为 Stage 0 的"最小骨架"版本：接口先行，深度实现推迟到 [13-能力矩阵 §1.1](./13-capability-matrix.md) 矩阵标注的阶段。

### 4.1 安全与信任模型（原 §14.1）

信任链形式化（Trusted/Verified/Assumed/Untrusted 四级），多样化双重编译（DDC）验证机制，宏代码的最小权限沙箱模型。

### 4.2 内存管理策略（原 §14.2）

分配器接口协议包含基础分配、屏障接口（Stage 0 为 no-op）、根集管理和 FFI 外部引用追踪。堆对象统一头格式支持从保守 GC 演进到精确/分代/增量 GC。已拆分至 [05-运行时 §3](./05-runtime.md)。

### 4.3 跨平台抽象层（原 §14.3）

目标描述语言（类似 LLVM triple 的结构化版本）和 ABI 契约定义。

### 4.4 工具链基础设施（原 §14.4）

编译器必须暴露内部 API 供 LSP 服务器、格式化器和 linter 消费。已拆分至 [10-工具链 §1](./10-toolchain.md)。

### 4.5 语言规范与文档流程（原 §14.5）

文档即代码：Scribble 风格，规范与实现使用相同语言编写。已拆分至 [09-标准库 §3](./09-stdlib.md)。

### 4.6 Unicode 基础设施（原 §14.6）

三层架构：编码层（UTF-8 解码验证）、词法层（标识符字符集、字符串字面量）、语义层（内部字符串表示）。

### 4.7 运行时错误基础设施（原 §14.7）

debug_info_table（字节码地址 → 源码位置映射，编译时生成）与堆栈追踪生成器。

### 4.8 性能基准框架（原 §14.8）

标准基准测试集：编译速度（lex/parse/expand/compile）、执行速度（fib/loop/alloc）、自举基准。已拆分至 [10-工具链 §3](./10-toolchain.md)。

### 4.9 编译器自调试工具（原 §14.9）

四层调试：IR dump 接口、阶段跟踪、编译器内省 API、交互式调试器。已拆分至 [10-工具链 §2](./10-toolchain.md)。

## 5. 四层正交架构对照与 IR 层级演进（v5.5 吸收自 next2.md）

> 本节将 next2 讨论的「四层解耦 + 组合器」与「六 IR 层」最终设计对照到本设计的现有架构，验证一致性并登记 Stage 2 演进锚点。

### 5.1 四层正交性对照（next2 设计 vs 本设计 crate/模块边界）

next2 的四层：**语法层（CoreExpr 无语义标注）→ 类型层（独立推导）→ 效应层（执行/处理/传播）→ 能力层（线性资源追踪）**，层间无直接引用、仅组合器知全层——其六缺陷批判（type_hint 入语法层 / capability 入效应层 / effect_row 耦合类型层）正是对本设计架构原则的独立验证：

| next2 四层 | 本设计对应 | 正交性证据 |
|-----------|-----------|-----------|
| 语法层 | kerf-core::expr（CoreExpr 无类型/效应/能力字段） | `VarRef` 无 type_hint；`Require` 为纯声明变体 |
| 类型层 | kerf-compiler::typecheck（TcType 独立推导，E0005 家族） | 类型信息不回流语法 AST（诊断经 Span 关联，非节点字段） |
| 效应层 | kerf-driver::effects（内部一次性逃逸，语言面 P3 隔离） | `InternalEffectSystem` 不触碰 CoreExpr/类型 |
| 能力层 | kerf-driver::capability（IoGrant + R9 验证，E0006 家族） | 验证消费 CoreExpr 只读快照，不改写语法/类型 |
| 组合器 | driver 前置管线 front（串联 read→expand→typecheck→R9→compile） | driver 是唯一知全层的组合根（§11 接口隔离的落地） |

**结论**：本设计 r8 后的实现与 next2 最终修正版的四层解耦**架构同构**——差异仅在效应层位置（next2 规划语言级 Perform/Handle 原语；本设计当前为编译器内部机制 + 语言面 P3 预留，Stage 2 评估对照见 [01-核心原语 §7.3](./01-core-forms.md)）。

### 5.2 IR 层级演进对照（当前 4 层 → Stage 2 六层）

| IR 层级（next2 六层规划） | 本设计当前对应 | 演进裁定 |
|--------------------------|---------------|---------|
| AST（表面语法） | Stx 语法对象树（含 Span/ScopeSet） | ✅ 就位 |
| CoreExpr（8 原语+类型标注） | CoreExpr + IrGraph（Arena 图 IR，字面量共享） | ✅ 就位（图 IR 超出树形规划——设计替代 §2.2 裁定） |
| ANF+Closed（显式命名+显式环境） | **Closed 半面 ✅ r48 已实化**（kerf-compiler IndexIR——解析闭包层：`IrVar` 槽级词法寻址 + `IrProto` 捕获源定型显式环境；[22 §16 D56]）；ANF 原子化半面由 kerf-backend anf.rs PoC 承载（`Let` 原语 r45 已入 Core 层） | Closed 半面：✅ r48（字节码路径解析单通道）；ANF 全面（标注迁移 + 原子化整合）：优化器窗口 |
| AnnotatedANF（效应+能力标注） | 部分等价：typecheck（E0005）+ R9（E0006）在 CoreExpr 上独立验证 | Stage 2：随 ANF 层迁移标注 |
| SSA | 未实现 | Stage 2（本地码后端前置） |
| LLVM/QBE 目标码 | 未引入（LLVM 永不进自举链，Stage 2+ 可选 QBE/C 转译） | [08-后端演化](./08-backend-evolution.md) |

**闭包表示（MLton 风格三种）**：`Toplevel`（无捕获→纯代码指针）/ `Flat`（少量捕获→环境内联）/ `Linked`（大量+共享→共享环境指针）——本设计 VM 当前为共享单元格捕获（[04-字节码 VM](./04-bytecode-vm.md)）；三种表示 + 捕获数决策算法（≤8 Flat / 共享子集>4 Linked）为 **Stage 2 优化锚点**（MLton 全程序优化达 ~1x C 的关键组件）。

**效应消除四阶段（Koka 启发）**：纯函数检测（效应行为 ∅ 且无 Perform/Handle 逃逸）→ 效应重排（无数据依赖并行化）→ 单一处理器内联 → 已知状态消除——Stage 2 AnnotatedANF 层的优化 pass 清单登记。性能路径量化（next2 供参考）：树形解释 ~1/100 C → ANF ~1/20 C → 效应消除 ~1/10 C → SSA ~1/2 C → 目标码 ~1/1.2 C（MLton 实证 ~1/1.05 C）。

**四层修正案注记（v6.2——r58 第十轮，同步自 stage0.md §6.13.2）**：第十轮正交合并审查提出 IR 层级的不可再合并根本维度为四——**结构**（AST → CoreExpr）/ **语义**（无标注 → 类型+效应+能力+Span）/ **形式**（树/图 → ANF-SSA——优化就绪）/ **目标**（语言级 IR → LLVM/QBE）；关键洞察：六层规划中「类型/效应/能力标注」同属语义维度、「ANF/闭包转换/SSA」同属形式维度——据此登记**四层修正案**（Layer 1 AST / Layer 2 CoreExpr+元数据[AnnotatedANF 标注并入] / Layer 3 ANF-SSA[SSA 并入] / Layer 4 目标码；Pass 而非 Layer——优化全在 Layer 3 原地跑 + 「模式识别 + 等价替换」为单一 pass；转换 5→3 次[40% 减] + 遍历 6→3）。**裁定：修正案登记非推翻**——与六层规划的差集论据（效应标注独立显式化 + MLton 闭包转换明确化——性能关键路径显式分层）在 Stage 2 优化窗按正交性验证表 + 性能实测裁定（原则 35：判据冲突先修判据集）；实况三锚与四层方案精神一致：typecheck E0005 + R9 E0006 在 CoreExpr（语义维度已实盘——上表 AnnotatedANF 行「部分等价」注的维度论证）/ IndexIR r48（形式维度 Closed 半面）/ SSA 未实现（合并发生在未实现层之间——零重构成本窗口）。优化桥接（模式识别 + 等价替换，[13 §3.7](./13-capability-matrix.md)）为 Layer 3 pass 管线的首个 pass 设计输入。

### 5.3 表面/内部语法分离：四层正交的第五个正交轴（v6.0 吸收）

> **v6.3 增注（r66 核心空间统一规划）**：本节五正交轴（10 crate 的架构定位） = [24 v2.0 §4.2](./24-space-decomposition.md) **核心空间七核心域的划分来源**——核心域是五轴的**宏观归并**（每域 = 1-2 个职责同簇 crate：语言域[core+syntax]/前端域[reader+expander]/编译域[compiler]/后端域[backend]/执行域[vm+runtime]/横切域[span]/组织域[driver]）。两层判据互不冲突：本轴管 **crate 架构分层**（15 权威），24 域管**空间从属**（marker impl——24 权威）；核心侧主类型经三层 marker impl（根+核心空间+域）声明归属——「crate 架构定位」自此有了「空间从属」的类型面对偶（双侧统一体系——[24 §4.2](./24-space-decomposition.md)）。

next3.md 第七轮确立的**表面/内部语法严格分离（原则 31）**与 §5.1 四层正交同构——可视为正交性的第五轴：表面语法（皮肤，可替换——S 表达式/中缀/DSL）经 Reader 桥接到内部语法（骨架，不变——CoreExpr 私有 ADT），Reader 是唯一桥接点：

| 分离轴 | 可变侧（皮肤） | 不变侧（骨架） | 桥接点 |
|--------|--------------|--------------|--------|
| 表面/内部语法 | 表面语法（Stage 0 S-expr → Stage 2 目标语法 → Stage 2+ 多语法） | CoreExpr 私有 ADT（核心冻结） | kerf-reader（[02 §1](./02-syntax-model.md)） |
| 语法/类型（§5.1 Layer 1-2） | 类型推导策略（保守 → 完整） | CoreExpr 无类型标注 | kerf-compiler::typecheck |
| 语法/效应（§5.1 Layer 1-3） | 效应处理策略（内部一次性逃逸 → 语言级） | CoreExpr 无效应字段 | kerf-driver::effects |
| 语法/能力（§5.1 Layer 1-4） | 能力策略（R9 验证 → 线性类型） | CoreExpr 无能力字段 | kerf-driver::capability |

**结论**：r8/r9 的 crate 边界（reader/syntax/expander/core 与 compiler/driver 的组合根分工）同时满足五个正交轴——表面语法的替换（Stage 2 目标语法）不影响任何一层的内部结构。设计规范锚点：[01-核心原语 §8.4](./01-core-forms.md)；分阶段策略：[12-路线图 §2.4.1](./12-roadmap.md)。

### 5.4 统一流形分析中心愿景与分析单源（v6.4 新增——r95 第二十二轮吸收，同步自 stage0.md v8.1 §9.23.3/§9.23.6）

> **本节定位**：next15.md Document 4 统一流形分析中心的架构分层收编——分析面架构愿景档案（Stage 3+）+ Pass 数据结构单源纪律（Stage 2+ 设计约束即刻生效）。

**愿景档案（Stage 3+——K-F 五层理论 vs 四阶段实现分层既有框架内）**：前端[Reader 源码→AST + Expander AST→CoreExpr] → **统一流形分析中心**[效应流形构建 CoreExpr→流形 + 流形分析引擎 + 六分析投影 + 流形变换优化简化] → 后端[流形→ANF-SSA 单向投影 + ANF-SSA→LLVM/QBE 目标面可选件]。渐进路径：Stage 0 = Level 0-1（效应行收集 + E0006 门控——**已交付**）→ Stage 1 = Level 2 候选（流分析增量）→ Stage 2 = 连通性基础 → Stage 3+ = 完整拓扑几何（愿景）——**与 K-F 零漂移**。

**三级单源体系（MU-B 裁定——本节核心增量）**：①IR 单源 = CoreExpr（§6.13 既有 IR 正交精简纪律）；②分析单源 = 流形对象（统一分析数据结构）；③Pass 变换纪律 = 任何分析 Pass 不得引入自有中间表示（操作流形对象[查询]或产出变换[流形→流形]）——传统编译器 Pass 间 IR 转换的信息丢失形态 = 反例登记。**与 r91 五 Pass 分立全景同构确认**：EffectTrace/LifecycleAnalysis/Capability/Interference/SpaceValidation 五 Pass 候选皆设计为流形对象上的分析查询——语料主张（Pass = 流形变换函数 + 组合 = 函数复合 + 正确性独立验证）为既有 Pass 设计原则补齐理论叙事。

**与五正交轴（§5.3）关系**：五轴管**皮肤/骨架分离**（表面可变性），三级单源管**分析数据流**（中端不变性）——两个正交维度叠加：表面语法自由变化 + 分析面零表示转换。架构图为 §10 既有分层的分析中心聚焦视图（非新架构提案——前端/后端形态零冲突）。

### 5.5 信息流管线层愿景（v6.5 新增——r111 第二十六轮吸收，同步自 stage0.md v8.5 §9.27.6）

**架构叙事层登记（非新架构层）**：编译器管线的「信息流视图」= §5.4 统一分析中心的**信息面投影**——同一 CompilerPipeline 七阶段在分析面呈现六分析投影（§5.4 既有）、在信息面呈现五类信息投影（Error/Warning/Hint/Debug/Performance），**两个投影面共享同一流形对象底座**（三级单源体系沿袭——MU-B 纪律：零新中间表示）。**with_info_collector 模式** = 既有 diagnostics()/diagnostics_stream() 接口（stage0 §8.7 + §9.3.2 LanguageService 预留）的语义完备化**愿景**（Stage 2+）：各阶段产出结构化信息 → 统一收集 → 配置面策略处置（FailFast/Collect/BestEffort 三策略 = 既有配置形态命名完备化——HM 多错误收集 r75 = Collect 既有实例）。**F13 机制面裁定（不可漂移）**：编译期诊断 = Result/Diagnostic 值通道（元级/对象级分立），信息流视图 = 解释框架层叙事——架构图不新增节点、分层不新增层、依赖方向零变更。上游全量 = [stage0.md §9.27.6](../stage0.md)。

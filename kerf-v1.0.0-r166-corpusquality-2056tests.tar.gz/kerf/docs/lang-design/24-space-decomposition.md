# 空间层级正交分解（根·核心·拓展·域·契约·类型——双侧统一从属体系）

> **Author**: kerf-doc-agent
> **Date**: 2026-10-10（**v2.5——r91 第十九轮吸收（next13.md）**：§17 量子登记态子空间归位与维度谱系[QuantumEffectSpace 归位 K-E——EffectSpace Level 3 第四子空间 + 维度谱系六阶 + 七层次理论纵深轴对账]——同步自 stage0.md v7.8 §9.20.3/§9.20.7）；2026-10-10（**v2.4——r89 第十八轮吸收（next12.md 追加段）**：§16 逆向/干涉/坍缩三子空间与统一五层框架[EffectSpace Level 3 三新子空间 + 四子空间平行分层 + 五层总图]——同步自 stage0.md v7.7 §9.19.8）；2026-10-10（**v2.3——r88 第十七轮吸收（next12.md）**：§15 空间理论组织工具定位[坐标系/地图裁定 + 低熵控制三机制 + 七维度/七步坐标 + 流形空间归属双分层]——同步自 stage0.md v7.6 §9.18.6）；2026-10-09（**v2.2——r84 第十六轮吸收（next11.md）**：§14 效应域四维结构与空间接口契约[四维↔空间体系对齐 + SpaceContract 六接口↔公理映射 + TypeWitness 约束传递同构]——同步自 stage0.md v7.5 §9.17.4/§9.17.7）；2026-10-01（**v2.1——r81 第十四轮吸收（next10.md）**：§13 效应域 Error 子空间注记 + 生态扩展六维对齐[五维修正补全 ForeignSpace↔外域——与 §4.1 拓展域六域一一对应] + 模块=子空间语言级映射注记——同步自 stage0.md v7.3 §9.14.7/§9.15；零 marker/契约变更[语义注记与蓝图对齐非新域引入]）；2026-09-23（**v1.0 首版——r65 / 118-a 空间层级正交分解定性设计轮**：驱动源 = 用户审查指令「当前对根空间和拓展空间，编译器内部核心空间，的划分和父空间与子空间之间的正交分解性质和抽象与具体之间并没符合设计的需求和要求，编译器本身就是一个空间的根……CapabilityIO 是 Capability 空间下的子项，却跨越空间层级关系这是禁止的……结合数学知识和编译领域相关知识并结合知识搜索等工具进行讨论整理划分抽象空间域后再确定当前预留模型接口从属问题……先定性再能力、边界、载定位置从属的先后审理」+ 知识搜索四查询实证[tool-results/r65-search/]）；2026-09-24（**v2.0 深化版——r66 / 122-a 核心空间统一规划与双侧正交分解轮**：驱动源 = 用户深化指令「是否应该对编译器内部核心空间也做划分并整体统一规划，不独特，显示处理，并根据审查和思考给出设计和理由……当前项目文件名称和当前的任何变量命名都可以重新筛选审理判断是否为最佳（不必考虑兼容）……思考是否需要项目结构重构和层级管理优化重构」+ 知识搜索四查询实证[tool-results/r66-search/——q1 LLVM SoC / q2 Rust marker 居 core / q3 ML 模块分层 / q4 bootstrap 阶段统一体系]；内循环三轮迭代收敛 + §6.3 评审通过后落位）
> **Version**: v2.12（**r115 第二十八轮吸收——§24 描述论空间注记**[空间理论 = 描述的组织框架本体面重述——零新子空间，空间单源第十一轮维持]）；v2.11（**r113 第二十七轮吸收——§23 流本体论空间注记**[零新子空间——空间单源第十轮维持]）；v2.10（**r111 第二十六轮吸收——§22 InfoEffectSpace 归位与「信息」双层口径**[EffectSpace Level 2 登记态子空间第七例——空间单源第九轮维持；编译器诊断留 InfrastructureSpace——语料越界收缩不采纳——同步自 stage0.md v8.5 §9.27.5]）；v2.9（r96 第二十三轮吸收——§21 TypeSystemSpace 归位与类型观测面[类型域理论名确认——空间单源纪律第八轮维持 + 观测维度代数归位]）；v2.8（r95 第二十二轮吸收——§20 流形分析中心空间归位[EffectSpace 分析面视图——ManifoldAnalysisSpace 平行空间 = 违例形态登记 + 空间单源纪律第七轮维持]）；v2.7（r94 第二十一轮吸收——§19 ResourceLifecycleEffect/BorrowEffect 归位[EffectSpace Level 2 登记态子空间第六例 + 六登记态子空间全景]）；v2.6（r93 第二十轮吸收——§18 CapabilitySpace 归位裁定与三支柱空间映射[理论坐标系保留 + 实施面核心七域单源——CAP-A]）；v2.5（r91 第十九轮吸收——§17 量子登记态子空间归位与维度谱系[空间单源纪律维持]；v2.4（r89 第十八轮吸收——§16 逆向/干涉/坍缩三子空间与统一五层框架；v2.3（r88 第十七轮吸收——§15 空间理论组织工具定位[坐标系/地图裁定 + 低熵控制三机制 + 七维度/七步坐标 + 流形空间归属双分层]；v2.2（r84 第十六轮吸收——§14 效应域四维结构与空间接口契约；v2.1（r81 第十四轮吸收——§13 效应域 Error 子空间 + 生态扩展六维对齐；v2.0：r66 核心空间统一规划与双侧正交分解）
> **Status**: Active（**双侧统一空间体系规范冻结**——核心空间与拓展空间的从属权威判据；实现状态 = r66 代码面落位[kerf-space 骨架 crate + 12 域 marker + 双侧全链 impl]）
> **处理程度**：P2（规范 + 双侧从属表 + 层级公理 A1-A7 + 正交判据 + 违例修复记录 + 命名裁定表 + 结构裁定；本文件是 [13 §3.8](./13-capability-matrix.md) 根空间骨架的**层级化精确版**）｜ **所属 Stage**：设计即刻生效（r66 代码面同步落位）｜ **推迟项**：优化域代码面 marker（零契约成员——§4.7 裁定维持）

> 本文件回答 v1.0 的用户识别违例（扁平挂靠）与 v2.0 的用户深化审查（核心空间特殊化）。**v2.0 核心裁定**：推翻 v1.0 的「核心空间 = 闭集不设 marker（存在性即归属）」——升格为「**双侧统一编码、分流治理**」：核心空间与拓展空间用**同一套 marker 家族 + 同一套层级公理 + 同一套三步审理程序**统一规划（不独特、显式处理），唯一差异收编进公理 A6（开闭性 = 治理面差异非编码面差异）。

---

## 1. 问题陈述：v1.0 修复了扁平挂靠，v2.0 修复核心空间特殊化

### 1.1 v1.0 已修复的四违例（r65——保留存档）

| 违例形态 | 代码证据（r64 及以前） | 违反什么 |
|---|---|---|
| 实例直挂根（跨三级） | `trait CapabilityIO: ExtensibleRoot`——实例跳过域与拓展两级直挂根 | 层级唯系（A2） |
| 域归属不可判定 | `EffectFamily`/`Effect`/`EffectSystem` 同挂根——效应域只活在文档叙述 | 唯一从属（A3） |
| 兄弟域不可区分 | `CompilationCache` 与 `FfiBoundary` 类型面同为根直挂 | 正交分解（A4） |
| 「拓展空间」无载体 | 根下应有核心+拓展两个一级子空间——类型面只有根 marker | 开闭分层（A1） |

### 1.2 v2.0 新审查的四违例（r66——用户深化指令定位）

| # | 违例形态 | 证据（r65 终态） | 违反什么 |
|---|---|---|---|
| V5 | **公理-编码不对称** | A1 声明「根下辖核心+拓展两个一级子空间」，类型面只有 `ExtensibleSpace` 一个载体——「下辖」是文档叙事非代码结构；核心空间成为**无类型的叙事空间** | A1 根唯一（下辖两子空间的编码不完整） |
| V6 | **做实面双重归属** | v1.0 §2.4 把做实面 crate 模块（`capability.rs` 等）归核心空间闭集（存在性），而做实类型（`StdCapabilityIO` 等）impl 预留契约 = 约束满足归拓展空间（118-c 全链 impl）——同一实体双空间从属，**核心 ∩ 拓展 ≠ ∅** | A4 正交分解（兄弟子空间互斥——r65 被 v1.0 自己的表述违反） |
| V7 | **核心空间成员失真** | v1.0 §2.4 列举「核心空间成员 = crate::{capability, cache, effects, ffi, driver} + kerf-core + kerf-backend」——实盘是 **10 crate**（span/syntax/core/reader/expander/compiler/runtime/vm/driver/backend），七 crate 缺席列举 | 无判据列举必然失真（R4 文档-实盘冲突的根源） |
| V8 | **零挂靠例外残留** | `CodegenBackend`/`WasmBackend`「零挂靠——编译器内部空间」——核心空间无载体时挂靠无处落；体系显式化后「无归属」= 归属不可判定（V1-V3 同型病在核心侧的残留） | A3 唯一从属（例外即漏洞） |

**为什么必须现在修**：v2.0 的驱动逻辑与 v1.0 同构——**预留层/核心层的全部价值在「冻结结构的同时冻结从属」**。v1.0 冻结了拓展侧的从属（20 契约重挂），却把核心侧留成「隐式约定」（闭集存在性即归属——无判据、无载体、无证明）。用户指令的「不独特，显示处理」正中要害：**核心空间被 v1.0 当成了体系外的特殊存在**（拓展侧有公理+marker+审理程序，核心侧只有一句「枚举式成员资格」）——这不是开闭原则的编码，这是开闭原则的**豁免**。统一规划 = 核心侧进入同一套公理与程序，开闭差异收进 A6。

---

## 2. 数学定性：空间层级的四个基础（先定性——审理的第一步）

### 2.1 层级 = 树（偏序集的特殊形态）

空间体系是一棵**树**：每个空间有唯一父空间（根除外）。树是偏序集（\preceq = 祖先关系）的高度受限形态：**每元素至多一条到根的路径**。这排除了「一个契约挂两个父空间」（多父 = 图非树——从属歧义）。宏观→微观 = 树的高度方向（根在顶、实例在叶）；抽象→具体 = 特化序（§2.3）——两者在空间树上**同向**：越深的节点约束越多、集合越小、语义越具体。**v2.0 增注**：树对双侧统一生效——核心子树与拓展子树共享同一棵树（根 → 两个一级分支 → 各自的域层 → 各自的成员层），不是两棵树。

### 2.2 每层 = 父集合的正交划分（orthogonal partition）

父空间的子空间集合构成父集合的**划分**（partition）：两两互斥（兄弟域交集 = ∅）且并为父（完备）。「正交」的操作化定义沿用 [21 §2.3](./21-capability-architecture.md) 的判据族哲学——**两层正交 ⟺ 任一子空间的约束变更不引发兄弟子空间的约束变更**（独立演化性）。互斥指**约束集互斥**（一个契约的从属约束只含一个域的附加约束——唯一从属），不禁止**实现体**组合多域契约（实例层组合代数——组合是实例的自由，从属是体系的秩序）。**v2.0 增注**：互斥性在 L1 层即被 v1.0 违反（V6 做实面双归属）——v2.0 经 §4.8 做实面归属修复恢复 `impl(核心) ∩ impl(拓展) = ∅`。

### 2.3 抽象→具体 = 约束单调递增（特化链）

`trait A: B` 的数学本质（r62 已锚定）：A 的约束 ⊇ B 的约束，即 **impl(A) ⊆ impl(B)**（实现集单调收缩）。层级链上每降一级，附加约束严格增加——「抽象」= 约束少（适配的实现体多）；「具体」= 约束多（适配的实现体少、语义载荷重）。双侧链的集合单调性（v2.0 双侧版）：

```
拓展侧（五级）：impl(实现体) ⊆ impl(契约) ⊆ impl(域) ⊆ impl(拓展) ⊆ impl(根)
核心侧（四级）：                impl(类型) ⊆ impl(域) ⊆ impl(核心) ⊆ impl(根)
```

### 2.4 开闭原则的集合论实质：统一编码、分流治理（v2.0 重写——推翻 v1.0 的「两种编码」）

**v1.0 表述（已废）**：「闭集用枚举（mod 树）表达，开集用约束（trait bound）表达——两种成员资格判据对应两种编码」。

**v2.0 表述（裁定）**：核心空间与拓展空间的成员资格判据（闭/开）是**治理面差异，不是编码面差异**：

| 维度 | 核心空间（闭集） | 拓展空间（开集） | 统一性 |
|---|---|---|---|
| **编码面**（类型论载体） | marker trait 家族（`CoreSpace` + 核心域） | marker trait 家族（`ExtensionSpace` + 拓展域） | **完全统一**——同一套声明机制（`impl X for T` 声明即归属）、同一套公理（A1-A7）、同一套审理程序（§4.3）、同一套证明机器（§5.3 require 函数族） |
| **治理面**（谁有权写 impl） | **封闭**：成员变更 = 修改编译器仓库本身（编译器作者管辖——存在性列举的实质是「作者逐个审定」，marker impl 就是审定的显式存档） | **开放**：成员变更 = 任何处实现契约（全生态管辖——约束满足的实质是「无人值守的加入通道」） | **唯一合法差异**（A6 公理化）——开闭原则说「对修改关闭/对扩展开放」，关闭与开放的正是**成员变更权**，而非编码形式 |
| **成员本体** | 类型（编译器自举部件的公共类型——定义即实现） | 契约 + 实现体（定义与实现分离——契约冻结于编译器、实现生长于生态） | 层级深度自然差的根源（§4.9） |

**推翻理由（数学+工程双证）**：①「枚举编码」在类型论上不存在——mod 树是**物理组织**（嵌套关系）不是**集合隶属**（从属关系），v1.0 §2.4 的「存在性即归属」实为「无判据」的叙事包装（V7 失真的根源：10 crate 实盘 vs 5 模块列举）；②V6 双重归属证明「存在性判据」与「约束满足判据」在**做实面**上冲突（模块存在 ⟹ 核心；类型满足约束 ⟹ 拓展——同体双判），一个体系两种判据必然产生交叠区，A4 互斥失守；③用户指令「不独特，显示处理」——**任何子体系享受编码豁免就是特殊化，特殊化是分解失效的起点**（q2 Springer：非正交分离比不分离更糟——编码不对称是组织层的非正交分离）。

**知识搜索实证（v2.0 四查询——tool-results/r66-search/）**：

| 查询 | 实证 | 对本设计的支撑 |
|---|---|---|
| q1 LLVM 内部组织 | CACM《The LLVM Compiler Infrastructure》：LLVM 架构「基于对关注点分离原则的强遵守（strong adherence to the principle of Separation of Concerns）」；IR 作为核心代码表示贯穿全部 pass 管线 | **核心空间也按关注点正交划分的工业佐证**——LLVM 的库族（IR/Pass/CodeGen/Support）正是「编译器核心的正交域划分」30 年实践；SoC 不因「是编译器自举部件」而豁免 |
| q2 Rust core::marker | Rust 标准库的 marker trait 家族（Send/Sync/Sized...）定义于 **最底层零依赖 crate（core）的 marker 模块**——「Primitive traits and types representing basic properties of types」 | **骨架 marker 居最底层 crate 的先例**——kerf-space 骨架 crate（§5.4）与此同型；marker 组织于依赖图根部使全树可达、零环 |
| q3 ML 模块系统 | ML modules：层级命名空间管理 + 数据抽象 + 代码组织（MPI-SWS/Cambridge CMU 系列研究）；functor 的 imports/exports 语义 | **分层模块系统的学术传统**——空间层级 = ML 模块分层的现代变体（域=module、从属=签名匹配）；双侧统一治理对应 ML 的「同一模块语言适用于核心库与用户库」 |
| q4 自举阶段体系 | GCC/Rust bootstrap：stage 0（环境准备/最小编译器）→ stage 1（bootstrap 编译器）→ stage 2（完整编译器）；bootstrap 编译器与 self-hosted 编译器**保持同步、特性实现两次、同一体系治理** | **核心（bootstrap 部件）与拓展（self-hosted 生态）统一体系的工程正例**——GCC 的两阶段不是两套规则而是一个编译器体系的分层治理；「特性实现两次」佐证核心/拓展成员分离（同一语义两个体） |

---

## 3. 层级公理（判据级——本文件的规范核心；v2.0 增 A6/A7）

| # | 公理 | 陈述 | 代码面编码 |
|---|---|---|---|
| **A1** | 根唯一 | 编译器自身是所有空间的根（唯一根空间；无「根外空间」）；根下辖两个一级子空间（核心+拓展） | `pub trait RootSpace {}`（v2.0 改名自 `ExtensibleRoot`——§11 命名裁定 N1）+ `CoreSpace`/`ExtensionSpace` 双载体（V5 修复——A1 的「下辖」从叙事升格为结构） |
| **A2** | 层级唯系 | 从属逐级声明——子空间的父必须是直接上级空间；**跨级挂靠 = 违例** | 族契约/核心类型的 supertrait = 所属域；域 supertrait = 所属一级空间；一级空间 supertrait = 根 |
| **A3** | 唯一从属 | 每个成员的域从属**唯一**（挂两个域 = 从属歧义 = 树变图）；**例外即漏洞**（v2.0：零挂靠同判违例——V8） | 每个成员声明至多一个域 supertrait（grep 可审计：唯一域匹配）；全树成员零「无域从属」残留 |
| **A4** | 正交分解 | 兄弟域约束互斥（无公共附加约束）且并为父空间；**兄弟一级空间互斥**（核心 ∩ 拓展 = ∅——V6 修复后恢复） | 域 marker 零方法零关联类型 + 域间零 supertrait 互挂 + 双侧成员集无交（做实面归拓展——§4.8） |
| **A5** | 依赖方向 | 从属方向 = 依赖方向：子空间可依赖父空间（含根），**父空间永不依赖子空间**；跨域**使用**（use）不等于从属——兄弟域间的使用依赖单向化（编译器分层纪律） | supertrait 链单向向下；Cargo 依赖图分层（kerf-space 最底层——§5.4） |
| **A6** | 开闭性（v2.0 新增） | 核心空间成员变更权封闭（= 修改编译器仓库——作者管辖）；拓展空间成员变更权开放（= 任何处实现契约——生态管辖）。**开闭差异是治理面差异非编码面差异**（§2.4）——编码面双侧统一（marker 家族） | 编码统一（双侧同套 marker）；治理分流（无代码表达——治理属流程面 [23 §2.2]：核心侧成员变更走编译器仓库 PR 审理，拓展侧走契约实现自由） |
| **A7** | 全树统一与单一事实源（v2.0 新增） | A1-A6 对全树适用（核心子树与拓展子树同构审理——三步程序 §4.3 对称适用）；**物理组织（crate/mod 树）不承载空间语义——从属唯一判据 = marker impl** | 判据唯一化：grep `impl.*Domain for` 即归属全貌；crate/目录/文件名与空间可以同构（方便映射）但**不判据化**（物理是从属的投影非依据） |

**公理与既有裁定的关系**：A1-A7 是 [13 §3.8](./13-capability-matrix.md)「空间关系 = 约束组合代数，非类继承」的**层级化精确化**——约束合取回答「组合两空间时约束如何合成」（格的交），公理回答「不组合时从属如何声明」（树的链）；格与树不矛盾（树是格的生成基；组合 = 链外的交运算，产物是新约束而非新从属）。

---

## 4. 域划分（双侧——审理的第二步：定性→定位）

### 4.1 拓展域（六域——v2.0 维持 v1.0 划分 + 一处改名）

| 域（宏观职责） | 判据（「……归此域当且仅当……」） | 成员契约（抽象→具体） | 载体文件 |
|---|---|---|---|
| **能力域** `CapabilityDomain` | 契约的语义载荷是**许可**（谁能做什么——ocap 令牌/门控/授权传递） | `CapabilityModelFamily`（模型层）→ `TokenCalculus`（模型层——令牌演算）→ `CapabilityIO`（实例层——io 族读写令牌） | capability_model.rs / capability_io.rs |
| **效应域** `EffectDomain` | 契约的语义载荷是**副作用的拦截与恢复**（怎么发生——perform/handle） | `EffectFamily`（族层）→ `Effect`（实例层）→ `EffectSystem`（系统层） | effect_handlers.rs |
| **元编程域** `MetaprogrammingDomain`（v2.0 改名自 `SyntaxDomain`——§11 N2） | 契约的语义载荷是**代码操纵代码**（元编程——quote/splice/相操纵） | `MultiStage`（多阶段求值——compile-time/run-time 相桥） | multistage.rs |
| **优化域** `OptimizationDomain` | 契约的语义载荷是**产物的等价变换**（更优——模式识别/等价替换/pass 管线） | **当前零契约成员**（§4.7 裁定：不建空 marker）——设计登记 = [13 §3.7](./13-capability-matrix.md) | —（文档面保留位） |
| **工具链域** `ToolchainDomain` | 契约的语义载荷是**编译器的服务化与外围生态**（编译期消费面——LSP/调试/增量/缓存/包管理/AI） | `CompilationCache`（缓存服务）→ 生态服务 11 契约（`LanguageService`/`IncrementalAst`/`DebugInfoGenerator`/`DebugTraceable`/`Query`/`QuerySystem`/`CompilerService`/`Serializable`/`PackageManager`/`ExternalModule`/`AiAssistant`） | compilation_cache.rs / toolchain.rs |
| **外域** `ForeignDomain` | 契约的语义载荷是 **kerf 与非 kerf 世界的交互通道**（跨边界——类型映射/pin 协议/调用约定） | `FfiBoundary`（边界机制——FFI **令牌**在能力域：许可归能力、通道归外域，协作非从属） | ffi.rs |

### 4.2 核心域（七域——v2.0 新增：15 §5.3 五正交轴的宏观归并）

**划分来源**：核心域**不是平行发明**——是 [15 §5.3](./15-architecture-layers.md) 五正交轴（10 crate 的既有架构定位）的**宏观归并**（每域 = 1-2 个职责同簇 crate）。归并维度 = 编译器宏观职责（域判据独立于 15 轴表述——两层判据互不冲突：15 轴管 crate 架构分层，本域管空间从属）：

| 核心域 | 判据（「……归此域当且仅当……」） | 成员 crate 簇（物理面） | 代表类型（impl 面——§7.2 表） |
|---|---|---|---|
| **核心语言域** `CoreLanguageDomain` | 类型的语义载荷是**语言本身的定义物**（程序是什么——核心表达式/语法对象/IR 骨架） | kerf-core（`CoreExpr`/`IrGraph`/`CodeValue`）+ kerf-syntax（`Stx`/`ScopeSet`/`Symbol`） | CoreExpr/LiteralValue/ModuleItem + IrGraph/IrNode/NodeId + CodeValue/StageLevel + Stx/StxDatum + ScopeSet/ScopeId + Symbol/SymbolTable |
| **核心前端域** `CoreFrontendDomain` | 类型的语义载荷是**源码进入编译器**（lex/parse/read——外部表示→内部表示的第一桥） | kerf-reader + kerf-expander | Token/TokenKind/ReadError + Lexer/Parser + ExpandCtxt/Transformer/SyntaxRules + ModuleRegistry/PhaseLevel |
| **核心编译域** `CoreCompileDomain` | 类型的语义载荷是**程序的验证与编译**（typecheck 独立推导 + 字节码生成） | kerf-compiler | CompileCtxt/CompileError + Op + IrProto/IrExpr + bytecode 公共类型 |
| **核心后端域** `CoreBackendDomain` | 类型的语义载荷是**目标码的生成**（QBE IL/本地码/多目标契约） | kerf-backend | **`CodegenBackend`/`WasmBackend`（V8 零挂靠收编——核心侧首对契约）** + QbeBackend + TargetTriple/PassDescriptor/CompiledModule/AnnotatedANF |
| **核心执行域** `CoreExecutionDomain` | 类型的语义载荷是**程序的运行**（VM 执行/eval 互查/GC 堆/最小 I/O 通道） | kerf-vm + kerf-runtime | Env/EvalError + VM 公共类型 + Heap/GcRef/RootSet + RuntimeError |
| **核心横切域** `CoreSpanDomain` | 类型的语义载荷是**定位与诊断**（Span/Diagnostic/SourceMap——被全体依赖的程序文本元数据） | kerf-span | Span/FileId/ByteOffset + Diagnostic 族 + SourceMap/SourceFile |
| **核心组织域** `CoreDriverDomain` | 类型的语义载荷是**编译流水线的组装**（组合根——唯一知全层；管线串联/自举驱动） | kerf-driver（主干——driver.rs/bootstrap*） | Driver + bootstrap 系公共类型 |

**七域判定自检**（A4）：互斥（每 crate 恰归一域——10 crate → 7 簇映射唯一）✅；完备（10 crate 全覆盖 + 拓展侧成员不占核心域）✅；判据独立（每域判据与兄弟域零重叠——语言/前端/编译/后端/执行/横切/组织七载荷两两正交）✅。

### 4.3 从属判定的操作程序（「先后审理」的流程化——v2.0 双侧对称化）

用户指令的审理顺序（「先定性再能力、边界、载定位置」）落成三步程序，**每步有否决权**，**对核心侧与拓展侧对称适用**（A7——v2.0 统一规划的核心落点）：

1. **定性**：候选成员的语义载荷属于哪个域判据（拓展侧查 §4.1 表第二列；核心侧查 §4.2 表第二列）——载荷不清 = 回设计文档查 owner（[17 原则 2](./17-principles.md) 场景路由），禁止「先找个家再编理由」；
2. **能力与边界**：候选成员的职责面与域内既有成员的职责面**互斥**（新增成员不得与既有成员职责重叠——重叠 = 划分退化或成员冗余）；
3. **载定位置**：载体 crate/文件与 marker impl 落位（核心侧：新类型进公共导出面时同步挂域 marker；拓展侧：新契约 supertrait 挂域 + Probe 全链 impl）。

**核心侧新增示例**（程序运行实录——设计期预演）：若未来引入「kerf-debugger」crate（调试器）——①定性：语义载荷 = 编译期服务（调试信息消费）→ 与 `DebugInfoGenerator` 同判据 → **拓展侧工具链域**（非核心域——调试器不是自举部件）→ ②能力边界：与工具链域既有 12 契约职责互斥检查 → ③载定：契约挂 `ToolchainDomain` + Probe 全链。**程序的正确适用先于 crate 物理存在**——这就是「整体统一规划」的实效。

### 4.4 抽象→具体的域内分层（模型层与实例层）

「抽象到具体就是对应的模型接口的抽象到具体」（用户指令原文）在域内的落位：**能力域完整两级**（模型层 `CapabilityModelFamily`/`TokenCalculus` → 实例层 `CapabilityIO`）；效应域三级（族→实例→系统）；核心侧的域内分层依 crate 簇自然深度（语言域双层：表达式层/IR 层；执行域双层：求值层/堆层）。**分层深度由该域的抽象结构自然生长**，禁止为对称而对称（原则 1 极小化）。

### 4.5 与 21 §2.6 L0-L3 四层的关系（垂直轴 vs 水平域）

[21 §2.6](./21-capability-architecture.md) 的 L0-L3 是**语言能力语义轴**（值域/控制/效应/授权）；本文件域是**空间的组织域**。两者正交：一个预留契约有唯一的域从属（本文件权威），其语义载荷可映射到 L 轴（21 权威）。**v2.0 增注**：核心侧类型同样可映射 L 轴（如 `CodegenBackend` 域从属 = 核心后端域、L 轴无关[编译期设施]）——域坐标管空间、L 轴管运行时语义，双坐标不冲突。

### 4.6 与 13 §3.8 表述的关系（文档修订面）

[13 §3.8](./13-capability-matrix.md) v6.9「六大域」表述 v2.0 同步修订：拓展侧「语法域」→「元编程域」（改名同步）+ 核心侧七域新表 + 双侧统一体系引用本文件（v6.10）。

### 4.7 空域处理裁定（优化域零成员——维持）

优化域当前零契约成员。**裁定维持：不为空域建代码面 marker**——空 marker 零成员零证明力（「为未来留出空间」的是域的**判据**（§4.1 表行），不是 trait 存在性）；违背原则 1 极小化。开窗时（Stage 2+）按 §4.3 程序落位 `OptimizationDomain` marker + 首契约。

### 4.8 做实面归属修复（V6——v2.0 裁定）

**裁定**：做实面（`kerf-driver/src/{capability, effects, cache, ffi}.rs` 的 `StdCapabilityIO`/`ValueEffectFamily`/`InMemoryCompilationCache`/`HeapFfiBoundary` 等）= **拓展空间 L4 实现体（种子实现）**——从属判据 = 其 marker impl（全链挂拓展侧，118-c 已落位）；**物理位置维持 kerf-driver**（组合根聚合种子实现——A7 物理不判据化）。v1.0 §2.4「核心空间成员 = 做实面 crate 模块」表述**废除**（V6 双重归属根源）。修复后 `impl(核心) ∩ impl(拓展) = ∅`（A4 在 L1 层恢复互斥）。

### 4.9 层级深度自然差（核心四级 vs 拓展五级——开闭性的结构表达）

```
L0  根空间 RootSpace（编译器自身——所有空间的根）
L1  核心空间 CoreSpace（闭集）        | 拓展空间 ExtensionSpace（开集）
L2  核心域 ×7（§4.2）                | 拓展域 ×6（§4.1）
L3  核心类型（定义即实现）            | 族契约（20——定义冻结于编译器）
L4  —（无实现层）                    | 实现体（Probe 系 + 做实种子 + 未来生态）
```

**深度差 = 开闭性的结构表达**（非对称缺陷）：闭集**定义即实现**（`CoreExpr` 既是定义又是实现——无「CoreExpr 契约」与「CoreExpr 实现」分离）；开集**必须分离契约与实现**（契约冻结于编译器、实现生长于生态——预留体系的全部语义）。v1.0 §4.3「分层深度由该域的抽象结构自然生长」先例的直接延伸：**开闭性就是核心/拓展两侧最根本的「抽象结构差异」**。

---

## 5. 层级公理的类型论编码（代码面——r66 落位态）

### 5.1 双侧层级链与全链显式（「声明即归属」的双侧版）

```rust
// === kerf-space crate（骨架层——§5.4）===
// L0 根（编译器自身——所有空间的根；v2.0 改名自 ExtensibleRoot——§11 N1）
pub trait RootSpace {}

// L1 两个一级子空间（A1「下辖」的类型面结构——V5 修复）
pub trait CoreSpace: RootSpace {}      // 核心空间（闭集——治理封闭/A6）
pub trait ExtensionSpace: RootSpace {} // 拓展空间（开集——治理开放/A6；v2.0 改名自 ExtensibleSpace——§11 N3）

// L2 核心域（七——15 §5.3 轴宏观归并）
pub trait CoreLanguageDomain: CoreSpace {}   // kerf-core + kerf-syntax
pub trait CoreFrontendDomain: CoreSpace {}   // kerf-reader + kerf-expander
pub trait CoreCompileDomain: CoreSpace {}    // kerf-compiler
pub trait CoreBackendDomain: CoreSpace {}    // kerf-backend
pub trait CoreExecutionDomain: CoreSpace {}  // kerf-vm + kerf-runtime
pub trait CoreSpanDomain: CoreSpace {}       // kerf-span
pub trait CoreDriverDomain: CoreSpace {}     // kerf-driver 主干

// L2 拓展域（六——一改名）
pub trait CapabilityDomain: ExtensionSpace {}
pub trait EffectDomain: ExtensionSpace {}
pub trait MetaprogrammingDomain: ExtensionSpace {} // v2.0 改名自 SyntaxDomain——§11 N2
pub trait ToolchainDomain: ExtensionSpace {}
pub trait ForeignDomain: ExtensionSpace {}

// L3 核心侧：核心类型直挂域（全链三层显式——§7.2 表）
impl RootSpace for CoreExpr {} impl CoreSpace for CoreExpr {}
impl CoreLanguageDomain for CoreExpr {}   // kerf-core/src/expr.rs（示例——全表 §7.2）

// L3 拓展侧：族契约 supertrait 挂所属域（A2 逐级）
pub trait CapabilityIO: CapabilityDomain { /* 读/写行为规格 */ }
```

**全链显式裁定（双侧）**：核心类型显式 impl **三层**（根+核心空间+域）；拓展实现体显式 impl **四层**（根+拓展+域+族）——每一级的从属都是显式裁定痕迹（「先后审理」的类型面存档）；Rust 编译器强制 supertrait 链逐层满足——**层级由纪律升格为机制**（双侧同效）。

### 5.2 为什么不用 blanket impl 自动传播（备选方案否决记录——维持 v1.0）

备选：`impl<T: CapabilityDomain> ExtensionSpace for T {}` 两级 blanket 可让实现体只 impl 域+族两层。**否决理由**：blanket 把「层级的成立」从**每次从属的显式裁定**变为**全局自动规则**——静默从属正是扁平挂靠时代「挂上了但没审过」的病灶同型；显式全链 impl 的样板成本是「审理留痕」的合理价格（原则 32 兼容性成本）。**v2.0 增注**：核心侧同理否决 blanket（`impl<T: CoreLanguageDomain> CoreSpace for T {}` 同型否决——双侧统一）。**裁定：supertrait 声明层级 + 双侧实现体全链显式**（备选记录保留，[14 设计备选](./14-design-alternatives.md) 纪律）。

### 5.3 归属证明的机器化（测试锚——双侧双层）

| 证明层 | 机制 | 证明什么 |
|---|---|---|
| 域归属（拓展） | `fn require_ext_domain<T: ExtensionSpace>(_: Option<T>)` + 每契约一函数 | 契约实现体的域从属（`F: CapabilityIO` ⟹ `F: CapabilityDomain` ⟹ `F: ExtensionSpace`——A2 前段机器证明） |
| 域归属（核心——v2.0 净增） | `fn require_core_domain<T: CoreSpace>(_: Option<T>)` + 每核心类型一函数 | 核心类型的域从属（`T: CoreExpr` ⟹ `T: CoreLanguageDomain` ⟹ `T: CoreSpace`——核心侧 A2 机器证明） |
| 根归属（双侧） | `fn require<T: RootSpace>(_: Option<T>)` | 全链传递闭包（双侧四层/三层链编译期遍历） |
| 层级深度（双侧） | supertrait 声明 + 双侧烟囱测试（ChimneyProbe 拓展四层 + CoreProbe 核心三层） | 链长度恰为设计深度（跨级直挂 = 编译错误——A2 负向验证） |
| 双侧互斥（v2.0 净增） | `fn require_not_extension<T: CoreSpace + !ExtensionSpace>` 不合法——用**结构证明**：核心域 marker 的 supertrait = CoreSpace（非 ExtensionSpace）+ 双侧域集零交集 grep（`impl.*Domain for.*` 每类型唯一域） | A4 在 L1 层的互斥（V6 修复的机器锚） |

### 5.4 kerf-space 骨架 crate（物理落位——v2.0 新增）

**问题**：marker 全家（根+两空间+12 域）需被全 10 crate 可达——**但 kerf-span 是零依赖 Layer 0**（span 的类型也要声明核心域归属 → span 必须依赖 marker 所在 crate）；若 marker 在 kerf-driver（现状 root_space.rs 位置）→ kerf-core/backend 依赖 kerf-driver → **循环依赖**；若在 kerf-core → span/syntax 依赖 kerf-core 也不成立（kerf-core 反向依赖它们）。

**解**：新建 **`crates/kerf-space`**（空间骨架 crate）——零依赖、被其余 10 crate 全体依赖（**Layer -1 空间骨架层**——依赖图新最底层）：

```
kerf-space（零依赖：RootSpace/CoreSpace/ExtensionSpace + 12 域 marker + 证明测试）
  ↑ 被全体依赖
kerf-span（Layer 0 横切）→ kerf-syntax → kerf-core → {reader, expander, compiler, vm, backend, runtime} → kerf-driver（组合根）→ kerf（根 crate）
```

**先例**（q2）：Rust 的 marker trait 家族定义于最底层零依赖 crate（`core::marker`）——「Primitive traits representing basic properties of types」居依赖图根部使全树可达。kerf-space 与此同型：**空间骨架独立于一切语义载荷**（骨架 crate 零依赖 = A5「父空间永不依赖子空间」的物理极端形态：根骨架依赖空集）。

**迁移**：`kerf-driver/src/reserved/root_space.rs` → `kerf-space/src/lib.rs`（骨架家迁移——reserved/ 目录回归纯拓展契约物理面）；reserved 七契约文件 supertrait 改 `use kerf_space::XxxDomain`；`kerf-driver/src/reserved/mod.rs` 与 `lib.rs` re-export 面改源 kerf-space（`pub use kerf_space::{...}`——路径恒有效经组合根转发，[17 原则 27] 维持）。

> **r69 转发链单径化注记（134-a·D-1）**：r66 落地时 `lib.rs` 存在双路径偏差——`CoreSpace` 直连 `pub use kerf_space::CoreSpace` 而其余 7 marker 经 reserved 转发（`reserved::CoreSpace` 成死转发面）。r69 并轨：根 lib.rs 8 marker 统一经 reserved 转发链（本节「组合根转发」语义更纯——单路径）；`lib.rs` 仅保留 `use kerf_space::CoreDriverDomain` 私有导入（组织域 marker 无对外转发必要）。reserved/mod.rs 转发面与空间从属声明段（marker impl）零变更。

---

## 6. 正交判据（可审计——J 判据族的空间层扩展；v2.0 增 J8）

| # | 判据 | 陈述 | 验证锚 |
|---|---|---|---|
| **J5** | 域-域独立 | 任一域的成员增删/签名变更零兄弟域变更 | 从属表唯一性 + 域间零交叉引用 grep |
| **J6** | 层级-语义独立 | 层级重构（重挂/增域/改名）零成员**签名**变更（组织面 vs 冻结面分离） | r65 修复对账先例（20 trait supertrait 变更签名零变更）+ r66 改名对账（N1-N3 全部 marker 零语义载荷——签名冻结免检族） |
| **J7** | 从属唯一性 | 每成员的域 supertrait 唯一（挂两域 = 树变图） | grep：每成员唯一域匹配；零「无域从属」残留（V8 收编后） |
| **J8** | 双侧对称性（v2.0 新增） | 核心侧与拓展侧的体系要素成对存在（一级空间载体/域 marker/审理程序/证明函数族/烟囱测试）；**唯一合法不对称 = A6 治理差异与 §4.9 深度差**（公理显式声明的差异）——超出此两处的单侧缺失 = 特殊化违例 | 双侧要素对账表（§7.2/§7.3 结构同构）；用户审查指令「不独特」的判据化 |

---

## 7. 从属修复记录（双侧全量对账表）

### 7.1 拓展侧 20 契约重挂（r65——维持存档）

| # | 契约 | r65 重挂（维持） | 域 |
|---|---|---|---|
| 1-3 | `CapabilityModelFamily` / `TokenCalculus` / `CapabilityIO` | `: CapabilityDomain` | 能力 |
| 4-6 | `EffectFamily` / `Effect` / `EffectSystem` | `: EffectDomain` | 效应 |
| 7 | `MultiStage` | `: MetaprogrammingDomain`（r66 改名同步） | 元编程 |
| 8-19 | `CompilationCache` + 工具链 11 契约 | `: ToolchainDomain` | 工具链 |
| 20 | `FfiBoundary` | `: ForeignDomain` | 外 |

### 7.2 核心侧收编表（r66——v2.0 净增：主类型三层 impl 面）

**impl 面判据**：各 crate 公共导出面（lib.rs `pub use`）的**主类型**（crate doc 声明的定义物——每 crate 2-6 类型；「主类型」判据 = crate 身份类型，其名出现在 crate lib.rs 文档首段）。全链三层 impl（根+核心空间+所属域）：

| 核心域 | 主类型（三层 impl 对象） | crate |
|---|---|---|
| CoreLanguageDomain | `CoreExpr` `LiteralValue` `ModuleItem` `IrGraph` `IrNode` `CodeValue` `StageLevel` `Stx` `StxDatum` `ScopeSet` `Symbol` `SymbolTable` | kerf-core + kerf-syntax |
| CoreFrontendDomain | `Token` `ReadError` `Parser` `ExpandCtxt` `Transformer` `ModuleRegistry` `PhaseLevel` | kerf-reader + kerf-expander |
| CoreCompileDomain | `CompileCtxt` `CompileError` `Op` `IrProto` | kerf-compiler |
| CoreBackendDomain | **`CodegenBackend` `WasmBackend`（V8 零挂靠收编——契约也挂核心域）** `QbeBackend` `TargetTriple` `CompiledModule` `AnnotatedANF` | kerf-backend |
| CoreExecutionDomain | `Env` `EvalError` `Heap` `GcRef` `RootSet` `RuntimeError` | kerf-vm + kerf-runtime |
| CoreSpanDomain | `Span` `FileId` `Diagnostic` `SourceMap` | kerf-span |
| CoreDriverDomain | `Driver`（driver.rs 公共类型） | kerf-driver |

（精确清单以实施时 lib.rs pub use 面为准——本表为设计裁定面；实施对账见 §8）

### 7.3 Probe 实现体全链（双侧烟囱）

- 拓展侧 17 Probe（r65 全链四层——v2.0 改名同步：`impl RootSpace for P {}` + `impl ExtensionSpace for P {}` + 域 + 族）
- 核心侧烟囱（v2.0 净增）：`CoreProbe`（`impl RootSpace + CoreSpace + CoreLanguageDomain`——三层显式）+ 核心域归属证明函数族（§5.3）
- 做实面 7 类型（r65 全链 impl 维持——归属拓展侧 L4，§4.8）

---

## 8. 实施对账（r66 落位实测）

| 项 | 结果 |
|---|---|
| kerf-space 新 crate + 12 域 marker + 双侧证明测试 | crates/kerf-space/src/lib.rs（RootSpace/CoreSpace/ExtensionSpace + 七核心域 + 五拓展域 + 3 测试[双侧烟囱 + 零载荷锚——923 净增]；root_space.rs 迁移 + 互斥结构证明[签名级]） |
| 11 crate 依赖 kerf-space（10 成员 + 根 crate） | 全部 Cargo.toml 增 kerf-space 依赖（workspace members 增位首位——Layer -1） |
| 核心侧主类型三层 impl | 10 crate lib.rs「空间从属声明段」：span 3[Span/Diagnostic/SourceMap——FileId alias 移除] / syntax 5 / core 7 / reader 4[Parser/Lexer 生命周期显式] / expander 6 / compiler 4 / backend 5 + driver 主干 6——计 44 类型 × 3 层 |
| 20 契约 supertrait 换源（use super::root_space → use kerf_space）+ MetaprogrammingDomain 改名 | 七契约文件 + mod.rs（re-export 源改 kerf_space——组合根转发面维持[原则 27]） |
| 做实面 7 类型 + tests Probe 系全链改名（RootSpace/ExtensionSpace） | capability/effects/cache/ffi + reserved_ext_tests/gate_review_r1 + codegen 双探针/ProbeBackend/ProbeWasm 全链补（CodegenBackend 挂域后探针须三层 marker） |
| CodegenBackend/WasmBackend 挂 CoreBackendDomain | V8 收编（kerf-backend/src/codegen.rs 声明行 + use） |
| u8 域形状探针 → EffectAtomProbe（E0117） | trait 外迁触发孤儿规则——**实施裁定：原始类型/类型别名非从属载体**（「声明即归属」的机制边界实证——type alias 的身份由宿主结构承载） |
| §3.2 基线 | **923:0:0**（920 基线 + 净增 3[双侧烟囱 + 零载荷锚]）；六审计集 EXIT 0 ×6；CLI 四路径；bench fib 71.020ms 带内（OBS-C 环境带 70.9-71.1ms） |
| 签名冻结对账（J6） | 改名全部为 marker（零语义载荷）+ 契约 supertrait 行变更签名零变更（方法/关联类型/泛参逐项 diff = 0——r65 对账先例延续） |

**空间从属证明测试迁移**：原 root_space.rs 测试 → kerf-driver/src/reserved/space_proofs.rs（40 证明函数[20 域归属 + 20 根归属] + 全员 membership 锚 + 拓展侧五级烟囱——名字迁移至 v2.0 体系）；核心侧烟囱 + 互斥结构证明 + 零载荷锚在 kerf-space crate tests（双侧证明面的物理分离与概念统一——A7：骨架自证居骨架 crate，契约证明居契约 crate）。

---

## 9. 与既有文档的关系（指针互链不越权）

- 根空间骨架与三层预留体系权威 = [13 §3.8](./13-capability-matrix.md)（v6.10 同步：六域改名同步 + 核心七域 + 双侧统一体系引用）
- 编译器架构分层（五正交轴）= [15 §5.3](./15-architecture-layers.md)（**核心域 = 五轴宏观归并**——§4.2 对接）
- 组织关系的数学本质（约束组合代数/格） = [13 §3.8](./13-capability-matrix.md) + [21 §2.6](./21-capability-architecture.md)（v1.6 同步）
- 语言能力语义轴（L0-L3） = [21 §2](./21-capability-architecture.md)（域坐标与 L 坐标正交——§4.5）
- 命名层级（N0-N4——名字的组织） = [22](./22-namespace-design.md)（本文管**契约/类型**的空间从属；22 管**名字**的空间归属）
- 原则 = [17 原则 40](./17-principles.md)（v7.3 同步：双侧统一规划精确化）+ 原则 27（签名冻结）+ 原则 1（极小化——§4.7 空域/§5.4 骨架 crate 必要性）
- 演进排期 = [12 §2.13](./12-roadmap.md)（r66 轮次记录）+ [23 §2.2](./23-evolution-governance.md)（T3+ 治理）
- 备选否决记录 = §5.2（blanket 否决）+ §11（改名备选）+ [14](./14-design-alternatives.md) 纪律
- 术语 = [18 §5i](./18-terminology.md)（r66 十四轮增补术语）+ 引用 = [19 §14](./19-references.md)（97-100）

## 10. 收敛口径

[13 §3.2](./13-capability-matrix.md) 冻结定义不变；本文件为**组织层规范**（双侧层级公理 + 域划分 + 从属表——零原语/零关键字/零语法变更，纯 supertrait 链与 marker impl，向后兼容[re-export 面经组合根与根 crate 双转发维持]）；域划分的变更（增域/迁移成员/双侧迁移）走 [23 §2.2](./23-evolution-governance.md) T3+ 触发 + §4.3 三步程序（双侧对称）；本文件是 r66 代码面落位的设计依据（对账表 §8），实测锚以 worklog 122-a/123-a 为准。

---

## 11. 命名裁定表（r66 用户指令「文件名称与变量命名重新筛选审理」——设计阶段不考虑兼容）

| # | 旧名 | 新名 | 裁定理由 | 备选与否决 |
|---|---|---|---|---|
| N1 | `ExtensibleRoot` | **`RootSpace`** | **名实修复**：r65 已升格真根（下辖核心+拓展），「Extensible（可拓展的）」修饰错位——可拓展的是拓展空间非根本身；三名词族统一（RootSpace/CoreSpace/ExtensionSpace） | `CompilerSpace`（否决——「编译器空间」与「编译器自身即根」语义重叠但引入「编译器」实体词[根是抽象空间非实现物]）；`SpaceRoot`（否决——语序反转，与子空间命名族 XSpace 不一致） |
| N2 | `SyntaxDomain` | **`MetaprogrammingDomain`** | **语义自明**：域成员 `MultiStage`（quote/splice/相操纵）是元编程非「语法」；旧名需 Racket syntax-object 背景才能正确理解（读者最小背景原则）；避免与核心侧「核心语言域」（语言核心语法）混淆——双侧一个「Syntax」都没有，歧义源消除 | `MetaDomain`（否决——「meta」前缀在生态泛化[meta-programming/meta-data/meta-model]歧义大）；`CodeDomain`（否决——「代码域」与语言域/前端域边界模糊） |
| N3 | `ExtensibleSpace` | **`ExtensionSpace`** | **「拓展空间」直译**（名词）；与 RootSpace/CoreSpace 命名族统一（全名词——`Extensible` 形容词混入名词族破坏一致性）；「Extension」在 kerf 语境特指拓展生态内容 | `Extension` 单词（否决——与未来可能的语言特性「extension」撞名） |
| N4 | （新增） | **`CoreSpace`** | 核心空间载体（V5 修复）——闭集的显式编码 | — |
| N5 | （新增） | **`kerf-space` crate** | 空间骨架 crate（§5.4——q2 Rust core::marker 同型）；零依赖被全依赖 | marker 入 kerf-span（否决——span 语义=元数据基座，扩容双职责违反单一职责）；marker 入 kerf-core（否决——span/syntax 在其下不可达[依赖方向死锁]） |
| N6 | crate 名 10 个 | **全部维持** | 复检结论：各 crate 名实相符（`kerf-driver`=组合根[15 §5.3 锚定——「driver」即「驱动编译流水线」职责]；`kerf-span`=横切定位；`kerf-core`=语言核心……）——10/10 通过 | 拆 kerf-driver（否决——组合根聚合是 15 §5.1 设计[唯一知全层]非命名缺陷） |
| N7 | 契约名 20 个 | **全部维持** | r65 已审一轮；本轮复检：`CapabilityIO`/`TokenCalculus`/`FfiBoundary`/`MultiStage`/`CompilationCache` 等名实相符（18 号术语权威登记态） | — |
| N8 | `root_space.rs` | **迁 `kerf-space/src/lib.rs`** | 骨架家迁移（§5.4）——crate lib 即骨架本体（文件名消亡——骨架无二级文件必要） | `space.rs` 保留名（否决——单文件 crate 用 lib.rs 即可[极小化]） |
| N9 | 做实面文件名（capability.rs 等 4 个） | **维持** | 物理位置与文件名不承载空间语义（A7——物理≠从属）；「capability.rs 实现能力域契约」名实相符 | 迁 reserved/ 内（否决——reserved 语义=预留契约非实现；迁 src/ext/ [否决——制造第二事实源，A7 禁止目录承载从属判据]） |

**命名审理的判定标准**（沉淀为复用判据）：①名实相符（名字承载语义载荷的准确映射）；②命名族一致性（同族同构——XSpace/XDomain 全名词族）；③语义自明性（读者最小背景原则——[17 原则 2] 精神）；④歧义源消除（同名异义/近义混淆排查——N2 双保险）；⑤物理名与概念名**可以**同构但不判据化（A7——N6/N9 裁定面）。

---

## 12. 结构重构裁定（r66 用户指令「是否需要项目结构重构和层级管理优化」）

| # | 审理项 | 裁定 | 理由 |
|---|---|---|---|
| S1 | 10 crate 拓扑 | **维持**（零拆分/零合并） | 15 §5.3 五轴定位名实相符（每 crate 唯一轴职责）；拆分组合均无正交收益（拆 driver=组合根职责不可分；合 vm+runtime=执行域物理两簇[GC 基座 vs VM 消费]分层必要） |
| S2 | crate 依赖图 | **+kerf-space 一层**（新最底层） | 依赖环唯一无损解（§5.4）；q2 工业先例 |
| S3 | `reserved/` 目录 | **维持**（拓展契约物理面） | 物理与概念同构便利（审阅直觉）+不判据化（A7）——目录是投影非依据 |
| S4 | 做实面物理位置 | **维持** kerf-driver/src/ 顶层 | A7（从属唯一判据=impl）+ 组合根聚合种子实现（15 §5.1） |
| S5 | 根 crate（kerf）re-export 面 | **更新**（kerf-space 家族经 kerf-driver 转发 → 直连+转发双路径） | 双转发链路冗余消除（kerf→driver→space 三跳 vs kerf→space 直连）——根 crate 直依赖 kerf-space（骨架直连[原则 10 组织面]）+driver 转发维持（兼容面[原则 27]） |
| S6 | 模块树重排 | **否决**（kerf-driver 内部 bootstrap 系/做实面零迁移） | 迁移零正交收益 + N9 单一事实源纪律 |

**结构审理的沉淀判据**：重构的必要条件 = **正交收益**（新分解消除真实耦合/歧义/归属不可判定）——非「看起来更整齐」（整齐是投影一致性，A7 已把投影判据化豁免）。r66 的两项结构变更（S2/S5）均满足必要条件；六项维持（S1/S3/S4/S6/N6/N9）复检通过。

## 13. 效应域 Error 子空间与生态扩展六维对齐（v2.1 新增——r81 第十四轮吸收，同步自 stage0.md v7.3 §9.14.7/§9.15）

> **本节定位**：next10.md 第十四轮吸收的空间分解面收编。**零代码变更；零 marker/契约变更**——本节是拓展域六域既有划分的语义注记与蓝图对齐，非新域引入（新域引入走 23 §2.2 T3+ 触发表 + 三步程序）。

**效应域 Error 子空间注记**：效应域（EffectFamily/Effect/EffectSystem 契约族）承载错误统一效应模型（[17 原则 42](./17-principles.md)）——Error 子空间 = EffectSpace 下经约束特化定义的错误语义空间（`Error 子空间 = 效应域约束 ∩ 错误语义约束`）；官方六效应（Read/Write/State/Async/Error/Log）= 效应域首批官方族实例（登记态）；自定义错误空间（MyDomainError 等）= 用户侧效应族实例——开闭性（A6）在 Error 维度的投影（官方可替换 = 开集）。**二义消歧**：异常 = 传统非本地跳转机制形态名；错误 = 语义失败状态名——统一模型中二者均映射 Error 效应操作（术语分工保留）。

**生态扩展六维对齐**（审查修正 F1——stage0.md §9.14.7）：next10.md 原列五维（效应/能力/语法/优化/工具）缺 FFI/外域维度——修正为六维与本文 §4.1 拓展域六域一一对应：EffectSpace↔效应域 / CapabilitySpace↔能力域 / SyntaxSpace↔元编程域（24 N2 改名后同义）/ OptimizationSpace↔优化域 / ToolingSpace↔工具链域 / **ForeignSpace↔外域（FFI 边界——next10 五维遗漏由本对齐补全）**；官方/社区/用户三层来源 = A6 开闭性的生态面表述（官方 = 闭集变更走编译器仓库；社区/用户 = 开集契约实现）。

**模块=子空间语言级映射注记**（stage0.md §9.14.3）：`module core.io.network` = 空间层级的语言级投影——A2 层级唯系（逐级声明）+ A5 依赖方向（子可依赖父）+ A3 唯一从属；模块句法为 Stage 2+ 表面语法窗设计登记态（[22-命名空间设计](./22-namespace-design.md) 为权威源）。

## 14. 效应域四维结构与空间接口契约（v2.2 新增——r84 第十六轮吸收，同步自 stage0.md v7.5 §9.17.4/§9.17.7）

> **本节定位**：next11.md 第十六轮吸收的空间分解面收编——效应本体论四维结构的空间论对齐 + SpaceContract 接口契约登记。**零代码变更；接口面登记态**（Stage 2+）。

**效应域四维结构对齐**：效应概率域四维（`Action × Mechanism × Payload × Continuation`——next11 段 6 形式化）与本文空间体系的对齐——①**行为维度 ↔ 效应操作签名**（EffectFamily 契约族的 Operation 面——「做什么」）；②**工具维度 ↔ 效应域约束特化**（`子空间 = 根约束 ∩ 附加约束`——同一行为的多种实现机制 = 不同子空间实例，「怎么做」）；③**内容维度 ↔ Payload 类型参数**（效应携带的数据类型——效应操作签名的参数/返回面）；④**后续维度 ↔ continuation 契约**（resume ∈ {0,1}——one-shot 纪律[05 §6] + 可选性[r84]合围）。**类空间划分视角**：概率域 = 效应的「可能性空间」（类型级声明——EffectRow 即域的静态描述）；容器/实例 = 域中的点（运行时坍缩产物）——「域与其中的点」与「空间与其中的成员」同构（正交分解理论在效应维度的投影：域间正交[各效应族独立特化] + 域内分层[官方六效应/自定义错误空间]）。

**SpaceContract 空间接口契约（接口面登记态）**：空间理论的形式化接口规格——六接口与本文既有体系的映射：space_id ↔ 空间唯一标识（N4 命名承载[22]）/ **parent_space ↔ A3 唯一从属**（必须且只能有一个直接父空间——公理的接口化表述）/ capabilities ↔ 能力声明（[21] 能力架构对齐）/ register_member + lookup_member ↔ 成员注册查询（A5 依赖方向约束下的成员管理）/ communicate_with + SpaceMessage{TypeWitness} ↔ 空间间通信协议（**TypeWitness 类型安全见证 = 跨空间约束传递的运行时形态**——与 01 约束组合/本文约束特化代数同构：消息类型必须在两个空间中都定义 = 约束合取的通信投影）。**定位裁定**：SpaceContract 是本文 §4 六域（根/核心/拓展/域/契约/类型）的**接口面投影**——文档侧理论（层级 + 公理 A1-A7）已有；契约形式化 = 实现就绪度的接口规格（Stage 2+ 登记态——kerf-space crate 后续接口锚定方向，非本轮义务）。

## 15. 空间理论组织工具定位：坐标系/地图裁定与低熵控制（v2.3 新增——r88 第十七轮吸收，同步自 stage0.md v7.6 §9.18.6）

> **本节定位**：next12.md 第十七轮吸收的空间论面主体收编——用户陈述的「空间理论 = 管理组织统一工具」权威表述 + 低熵控制数学基础 + 七维度/七步坐标 + 流形概念空间归属。全节为空间理论的**定位层裁定**（零新公理——A1-A7 体系不变）。

**用户陈述权威表述（驱动源原文）**：「空间理论是用于管理和组织整个编译器空间（也就是根空间）下所有内容的统一化及低熵控制组织协调与权限及数学正交等性质。它从根到叶是（宏观到微观，抽象到具体）的数学正交（不限于定性，定位，职责，能力，边界，权限，组织，协同等方面）。它本质上就是一个管理和组织上的统一工具。而具体的模型是在根下多个子层级中通过从根到叶是（宏观到微观，抽象到具体）的数学正交（及空间理论的应用）确定在空间中的坐标的。」

**坐标系/地图裁定**：空间理论 = **坐标系**（组织框架——「它不『做』任何事，只『组织』一切事」）；各模型 = **坐标系中的点**（被组织的具体内容——「它们『做』事，被空间理论『组织』」）。两纪律：**不混淆**（空间理论 ≠ 任何具体模型——效应模型是被组织内容之一）+ **不分离**（任何模型必须在空间中有唯一坐标）。**地图类比**：「空间理论是『地图』，模型是『地图上的地点』——地图本身不是任何地点，但所有地点都必须在地图上有确定的位置。」

**低熵控制数学基础（三机制）**：①**正交分解 = 消除冗余**（同级空间互不重叠 + 每个模型唯一坐标 → 消除「多重归属」熵增）；②**层级链 = 消除歧义**（每空间只引直接父 + 禁止跨级引用 → 消除「多条路径」歧义）；③**约束组合 = 消除冲突**（子空间 = 父约束 ∩ 新约束 + 组合 = 约束合取 → 消除「菱形问题」冲突）。**与 A1-A7 公理对账（R4）**：A3 唯一从属 = 层级链机制、A4/A5 依赖方向、同级正交 = 六域互斥（§4）——**低熵表述 = 既有公理体系的信息论再表述**（同一数学事实两种语言——无新公理引入）。

**七维度正交控制（描述轴——横切面）**：定性（这个空间是什么）/ 定位（层级链哪个位置）/ 职责（负责什么）/ 能力（能做什么）/ 边界（边界在哪里）/ 权限（有什么权限）/ 协同（如何与其他空间协同）——七维度独立变化互不干扰。**与 §4 六域（层级分类——纵切面）正交互补**：七维度 = 空间实例的描述轴；六域 = 空间的层级分类——横 × 纵 = 完整空间坐标系。

**七步坐标确定流程（模型入位程序）**：定性 → 定位 → 职责 → 能力 → 边界 → 权限 → 协同——「完成七步 → 模型的空间坐标完全确定 = 在正交空间中有了唯一、无歧义的位置」。**与三步从属审理程序（stage0 §9.13——r65）对账**：三步 = 定位锚定程序；七步 = 全维度描述完备化展开（三步是七步的第 2 步深化）。效应模型七步示例：EffectSpace 归属（定位）+ Perform/Handle/Resume 能力 + 不做类型检查边界 + 可访问计算流权限 + 与类型协同（效应行追踪）。

**流形概念空间归属（双分层）**：`EffectGraph` → 编译器核心空间 CompilerSpace（Level 3——实现表示）vs `EffectManifold` → 拓展空间 EffectSpace（Level 3——概念理论）——经 Reader/Expander 桥接；「实现/理论两侧正交分层」与「机制/解释分层」同构（空间面投影）。**空间运行时协议与编译期强制**（SpaceRegistry 三协议 + SpaceValidationPass 四验证）的完整登记见 [13 §3.12](./13-capability-matrix.md)（能力矩阵面拆分）。

**审查注记**：设计宪法五定义（根空间 = 组织框架非功能实现——定义③经本节升级为「坐标系」权威表述）见 [stage0.md §9.18.2](../stage0.md)；「流形」术语的隐喻性裁定与消歧义务见 [22 §21](./22-namespace-design.md)。

## 16. 逆向/干涉/坍缩三子空间与统一五层框架（v2.4 新增——r89 第十八轮吸收，同步自 stage0.md v7.7 §9.19.8）

> **本节定位**：next12.md 追加段的空间论收编——EffectSpace Level 3 新增三子空间 + 全体系层次化总图。全节 Stage 2+ 设计登记态（空间登记面——非 marker/契约变更[与 §15 同口径：语义注记与蓝图对齐非新域代码引入]）。

**逆向子空间（EffectSpace Level 3）**：ReverseLifecycle（Consume→Offer→Rewind 逆向生命周期）+ ReverseManifold（ConfluenceConnection 汇流 / CollapseConnection 收拢 / ConvergenceConnection 收敛——三逆连接）+ 逆向效应实例（ConsensusEffect / ConvergeEffect / AtomicTransactionEffect / ResourceLifecycleEffect）。

**干涉子空间（EffectSpace Level 3）**：InterferenceTheory（ConstructiveInterference 构造性 / DestructiveInterference 破坏性 / EntangledInterference 纠缠——三干涉模式）+ NonCommutativity（`[A,B] = AB − BA` 非对易性）+ ComputationalUncertainty（计算不确定性原理）。

**坍缩子空间（EffectSpace Level 3）**：CollapseTheory（DeterministicCollapse 确定性坍缩 / ProbabilisticCollapse 伪随机坍缩 / QuantumCollapse 真随机——预留）+ Randomness 伪随机源（种子/分布/采样）。

**设计决策**：正向/逆向/干涉/坍缩**四子空间平行分层**——共享 8 原语（Perform/Handle/Resume 已含正逆两方向）但概念框架和使用模式不同。**与 §15 坐标系/地图裁定的关系**：三新子空间 = 坐标系中新增的三个「点」——经七步坐标确定流程入位（定性[逆向/干涉/坍缩各自的理论性质] → 定位[EffectSpace Level 3] → 职责 → 能力 → 边界 → 权限 → 协同）；「收拢」（ReverseManifold 嵌套聚合动作）与「坍缩」（CollapseTheory 投影选择）同形异义消歧义务入 [22 §22](./22-namespace-design.md)。

**统一五层框架（全体系层次化总图——J-F 裁定：总图形态登记非新理论增量）**：层次 0 基础原语（8 个：Fn/Let/Apply/Const/Var/Branch/Perform/Handle——不可再分）/ 层次 1 效应生命周期（构造→投影→后续；正向 Perform→Handle→Resume + 逆向 Consume→Offer→Rewind；Return 也是效应）/ 层次 2 效应流形（正向分形[串联/嵌套/循环] + 逆向聚合[汇流/收拢/收敛]；返回 = 降维切片）/ 层次 3 干涉与坍缩（三干涉 + 确定性/伪随机坍缩 + 计算不确定性原理）/ 层次 4 空间理论（组织框架——正交分解/约束组合/低熵控制）/ 层次 5 应用领域（异步并发协程 + 分布式共识 + 量子编程预留 + 概率计算）。**与既有锚一一对应**：0↔§3.2 冻结原语 / 1↔[stage0 §9.17.4] 三部曲 / 2↔[stage0 §9.18.3] 流形 + §9.19.2 逆向 / 3↔[stage0 §9.19.5/§9.19.6] / 4↔本文档 §15 + [stage0 §9.13] / 5↔应用域登记——框架价值 = 全体系鸟瞰图 + 层级关系显式化。

**审查注记**：逆向对偶理论（双幺半群/对偶范畴）与知识不对称判据见 [stage0.md §9.19.2/§9.19.3](../stage0.md)；三子空间的能力面登记见 [13 §3.13](./13-capability-matrix.md)；量子术语族隐喻裁定（干涉/坍缩/纠缠/非对易/不确定性）见 [22 §22](./22-namespace-design.md)。

## 17. 量子登记态子空间归位与维度谱系（v2.5 新增——r91 第十九轮吸收，同步自 stage0.md v7.8 §9.20.3/§9.20.7）

**QuantumEffectSpace 归位裁定（K-E——空间单源纪律）**：next13.md 主张拓展空间 Level 2 新增 `QuantumEffectSpace`（四子结构：WaveParticleDuality{ParticleAspect/WaveAspect} + InterferenceSpace{Constructive/Destructive} + EntanglementSpace{Atomic/Consensus} + CollapseSpace{Deterministic/Probabilistic}）——**冲突检测**：§16 统一五层框架已将干涉/坍缩归位 EffectSpace Level 3（逆向/干涉/坍缩三子空间）；平级新增将产生空间双源冲突。**裁定**：以 §16 五层框架为主体——InterferenceSpace/CollapseSpace 与已登记子空间同构（不重复登记）；WaveParticleDuality/EntanglementSpace 为真正增量 → 归位为 **EffectSpace Level 3 量子登记态子空间（第四子空间）**：

```
EffectSpace Level 3 ─ 正向 / 逆向 / 干涉 / 坍缩 / 量子登记态
                                        （波粒二象性 + 纠缠隐喻族——Stage 3+ 研究性标注）
```

层级不变、单源维持、增量容纳（本节为 EffectSpace Level 3 子空间面单源——新增子空间一律归位本层不平级新增）。

**维度谱系六阶（理论描述轴登记）**：0 维（点：单个效应实例）/ 1 维（线：串联）/ 2 维（面：fork/join 分形网络 = 正逆对偶的平面展开）/ 3 维（体：嵌套 Handle 网络——深度+广度+时间）/ N 维（张量积 E₁⊗...⊗Eₙ）/ ∞ 维（效应场 EffectField——R4 降格「高基数连续近似的理论极限形态」，层 5 场论远见方向登记）——连接结构组合复杂度的分级描述（三连接公理的自然升维展开，非新空间层级）。

**两轴对账（七层次 vs 五层框架）**：next13 七层次结构（层 0 基础/层 1 统一/层 2 对偶/层 3 几何/层 4 量子结构/层 5 场论/层 6 终极统一）= **理论纵深轴**（理论完备度分级）；r89 统一五层框架（0 原语/1 生命周期/2 流形/3 干涉坍缩/4 空间 + 5 应用）= **体系框架轴**（登记层次总图）——非冲突互补维持；层 5 场论/层 6 终极统一 = 远见方向登记（不阻塞主线）。

**审查注记**：数学工具箱分级（K-A——组合拓扑精确/微分离散化/量子隐喻）见 [stage0.md §9.20.2](../stage0.md)；EBNF v5 Level 3-4 拓扑/量子语法族见 [02-语法模型 §8.8](./02-syntax-model.md)。

---

## 18. CapabilitySpace 归位裁定与三支柱空间映射（v2.6 新增——r93 第二十轮吸收，同步自 stage0.md v7.9 §9.21.2）

> **本节定位**：next14.md Doc1「能力模型在根空间中的精确定位」的空间论收编。零代码变更；归位裁定登记。同步：[21 §10.1](./21-capability-architecture.md)、[17 原则 49](./17-principles.md)。

**语料提议**：CapabilitySpace 为拓展空间 Level 2 + 三 Level 3 子空间（LinearTypeSpace[Ownership/Borrowing/LinearConstraints] / ObjectCapabilitySpace[CapabilityReference/Grant/Composition] / CapabilityEffectSpace[PermissionTracking/EffectCapability/CapabilityFlow]）+ Level 4+ 具体能力（I/O/Network/Memory/Compute/Custom）。**归位裁定（CAP-A）**：①**理论坐标系保留**——Level 轴（L0-L3 语义轴）语义位承认该三子空间树为能力域的坐标系投影（与 §17 量子登记态子空间同族形态）；②**实施面单源归位**——能力域维持核心七域成员位（A1-A7 公理 + r66 kerf-space 统一裁定）——**不平级新增平行空间**（空间单源纪律沿袭 K-E/r91 先例）；③**三支柱映射到能力域内部三正交面**（线性面/OCap 面/融合面——非三子空间），具体能力实例（I/O 等）= 域内授权组合闭包（r33）的既有形态。**能力度规空间归属**（语料 CapabilitySpace.Metric）→ 核心七域能力域内部度量面（理论 Level 3 语义位保留——度规/联络/曲率依原则 48 K-A ②离散化对应物登记）。

## 19. ResourceLifecycleEffect / BorrowEffect 归位：生命周期子空间登记（v2.7 新增——r94 第二十一轮吸收，同步自 stage0.md v8.0 §9.22.5 验证二）

> **本节定位**：next15.md 生命周期效应化的空间归属收编——理论坐标系一致性验证（Doc2 验证 2）的空间单源纪律审查。零代码变更；归位裁定登记。同步：[13 §3.16](./13-capability-matrix.md)、[21 §11](./21-capability-architecture.md)、[17 原则 50](./17-principles.md)。

**语料主张**：生命周期效应属 EffectSpace——具体在 ResourceLifecycleEffect 子空间；借用效应属 EffectSpace——具体在 BorrowEffect 子空间；资源类型属 TypeSystemSpace。**归位裁定（沿 §17/§18 先例形态）**：①ResourceLifecycleEffect 与 BorrowEffect **不平级新增空间**——归位为 **EffectSpace Level 2 登记态子空间**（效应域内部的资源/借用登记面——与 §16 逆向/干涉/坍缩三子空间 + §17 量子登记态子空间同族第六例：全部为效应域内部登记态子空间而非平行新空间）；②空间单源纪律维持（核心七域零变更——A1-A7 公理不受理论侧新语料影响）；③资源类型属类型域（核心七域成员位既有——零增量确认）。**EffectSpace 登记态子空间全景（本裁定后）**：逆向（§16）+ 干涉（§16）+ 坍缩（§16）+ 量子登记态（§17）+ 资源生命周期 + 借用（本轮）——六登记态子空间共享 8 原语基座（「效应的应用模式」族——理论坐标系 Level 轴语义位完整）。**一致性七项验证的空间项对账**：语料验证 2（空间归属清晰）与 24 号件核心七域单源口径**一致 ✅**——零漂移实证（理论侧提议经归位审查后与实施面口径双向确认）。

## 20. 流形分析中心空间归位：分析面视图裁定（v2.8 新增——r95 第二十二轮吸收，同步自 stage0.md v8.1 §9.23.7 验证二）

> **本节定位**：next15.md Document 4 流形统一分析的空间归属收编——统一流形分析中心（ManifoldCore）的空间单源纪律审查（MU-F 验证二）。

**语料主张**：统一流形分析中心 = 编译器核心创新（前端→中心→后端的分析中枢——六分析 + 流形变换）。

**归位裁定（MU-F ②）**：流形分析中心 = **EffectSpace 理论坐标系（Level 3 量子登记态坐标系既有——r91 K-E 归位）的分析面视图**，**非新空间**。理由三则：①分析中心是流形理论（EffectSpace Level 3 已登记坐标系）的**查询接口面**——六分析 = 该坐标系上既有理论投影（类型投影/干涉/拓扑/生命周期/曲率/同调——13 §3.17 能力面收编），无新增空间成员；②**ManifoldAnalysisSpace 平行空间 = 违例形态登记**（空间单源纪律第七轮维持——与 CapabilitySpace 平行空间提议[r93 CAP-A 裁定：理论坐标系保留 + 实施面七域单源]同族处置：分析中心归 EffectSpace 视图非平级空间）；③分析中心的架构承载 = 15 §5.4 愿景层（Stage 3+——非空间层新增）。**空间层级零变更**：根·核心·拓展·域·契约·类型六层维持；EffectSpace 登记态子空间六例存量维持（ResourceLifecycleEffect 等——本轮零增量）。

**与空间线程关系**：r88 §15 坐标系/地图裁定（空间理论为组织坐标系）的**分析面延伸**——流形分析中心 = 坐标系的应用视图（所有分析查询共用同一坐标系 = 空间单源的分析面投影——MU-B 三级单源体系的空间面表述）。8 原语不变性第七轮验证（零语法零原语零 EBNF）与空间单源纪律第七轮维持同轮双确认。

## 21. TypeSystemSpace 归位与类型观测面（v2.9 新增——r96 第二十三轮吸收，同步自 stage0.md v8.2 §9.24.7 验证八）

**语料主张**：类型系统在空间中的位置 = TypeSystemSpace（验证层）——「类型是验证者不是执行者」。**归位裁定（沿 §18/§19/§20 先例形态）**：①**TypeSystemSpace = 类型域理论名**——类型域为核心七域成员位既有（A1-A7 公理 + r66 kerf-space 统一裁定 + r94 资源类型属类型域零增量确认）——**不平级新增空间**（空间单源纪律**第八轮维持**：理论侧新语料不改实施面七域单源）；②类型系统「横切静态验证层」定位 = 类型域「编译期契约验证」载荷的理论侧强化（负空间表述句法化——验证者非执行者）；③**观测维度代数归位**：StaticDimension 四种（ValueShape/EffectKind/CapabilityRequirement/LifetimeBounds——四模型各占一观测维度）= 既有四域成员的观测面视图（非新空间成员——同 §20 分析面视图处置：查询接口面非空间层新增）；④**空间层级零变更**：根·核心·拓展·域·契约·类型六层维持；EffectSpace 登记态子空间六例存量维持（本轮零增量——类型观测面为类型域内部视图）。**一致性八验证的空间项对账**：语料验证八（TypeSystemSpace 验证层）与本文件核心七域单源口径**一致 ✅**——零漂移实证（理论侧提议经归位审查后与实施面口径双向确认——同 r94/r95 归位链模式）。

## 22. InfoEffectSpace 归位与「信息」双层口径（v2.10 新增——r111 第二十六轮吸收，同步自 stage0.md v8.5 §9.27.5）

> **本节定位**：next18.md 空间归属修正主张的收编——「信息效应从 InfrastructureSpace 修正归属 EffectSpace（InfoEffectSpace 子空间）」的归位审查。

**语料主张**：InfoEffectSpace = EffectSpace 子空间（CompilerInfoEffect{Error/Warning/Hint} + DebugInfoEffect{Trace/Profile}）；InfrastructureSpace 仅保留 SpanSystem + RenderEngine。

**归位裁定（沿 §18-§21 先例形态）**：①**InfoEffectSpace = EffectSpace Level 2 登记态子空间第七例**（沿 ResourceLifecycleEffect 第六例[r94]/QuantumEffectSpace[r91] 先例——**空间单源纪律第九轮维持**）：语言级信息效应族（用户 perform 的 Log/Metric/Debug 效应 + 标准库 InfoEffect 族）= 效应的应用域子空间登记——**不平级新增空间**（「InfoEffectSpace 平行空间」= 违例形态登记）；②**「信息」双层口径裁定**（语料 InfrastructureSpace 收缩主张的**部分采纳**）：语言级信息效应[用户程序 log/warning/metric——经 perform/handle] → EffectSpace Level 2 登记态子空间；**编译器内部诊断[Diagnostic 结构/Span 系统/渲染引擎] → InfrastructureSpace 既有归属维持**（stage0 §8.7 结构化诊断框架 + §10.2 基础设施层「诊断框架」节点既有——rustc diagnostic 先例 E.27-149；元级子系统不因目标语言理论演进而改归属）——语料「仅保留 Span+Render」越界收缩**不采纳**；③**空间层级零变更**：根·核心·拓展·域·契约·类型六层维持；EffectSpace 登记态子空间存量六例 → **七例**（+InfoEffectSpace）。

**与既有空间线程关系**：信息系统三层架构（r88 §15 EffectTrace 桥接层 + 流形诊断五类——编译器侧分析面）= 本节归位的**分析面既有锚**（演进链：r88 编译器侧三层架构 → r111 用户侧语法 + 观测理论）；观测双子（类型形状观测 r96 §21 + 信息状态观测本节）= 六线程族的空间面表述。8 原语不变性第十轮验证与空间单源纪律第九轮维持同轮双确认。上游全量 = [stage0.md §9.27.5](../stage0.md)；术语 = [18 §5v](./18-terminology.md)。

## 23. 流本体论空间注记（v2.11 新增——r113 第二十七轮吸收，同步自 stage0.md v8.6 §9.28.2/§9.28.9）

> 本节登记流特性理论 FLW-A（流本体论——理论载体第十二环）在空间分解体系中的注记——**零新子空间**（空间单源第十轮维持：既有七个登记态子空间原样——流本体论非空间概念而是本体层叙事）。

**归位裁定**：流本体论 = 解释框架层第十二环（六线程族的共同基座叙事——效应流是「效应/投影/信息/度规」全部谓词的共同主语），**不产生新空间**：五层特性（波动/粒子/中间态/间隙态/时间性）= 同一效应流的五种观测模式——观测模式谱系归观测理论（r96 类型观测 + r111 信息观测 + 本轮固定vs确定维度阶——观测论三阶化），非空间分解维度。**与既有空间体系的接口 = 零**（模型间接口维持恰五[r96 TY-E 计数纪律] + EffectSpace 登记态子空间第七例 InfoEffectSpace[r111] 之后零新增）。**语料「流的特性 = 流的本体描述」采纳为本体层登记**——五系统统一表的其余五行均为既有六线程族成员的本体面重述（零新成员）。

## 24. 描述论空间注记（v2.12 新增——r115 第二十八轮吸收，同步自 stage0.md v8.7 §9.29.4 附加维度 7）

> **本节定位**：next20.md 描述论的空间面注记——「空间理论 = 描述的组织框架」= 既有 24 号件正交分解 + 层级结构的**本体面重述**——**零新子空间、零空间归属变更**（空间单源第十一轮维持）。

- **描述论的空间面重述**：正交分解 = **描述的独立性保证**（正交描述维度互不重叠——§2 七维度正交的描述论重述）；层级结构 = **描述的抽象层级**（§4 六域层级的描述论重述）；根空间（RootSpace）= **所有描述的根**（§3 根空间统一组织的描述论重述）——三分皆为本体面重述零新机制。
- **空间归属对账**：统一流分析 = 分析线程工程统一面**非空间概念**（零新子空间——EffectSpace 既有登记态子空间七例维持）；描述论 = 哲学立场层**非空间概念**（立场层修正非线程非支柱——零空间触面）。
- **与 §23 流本体论的关系**：流本体论（r113 本体层——效应流 = 六线程族共同主语）+ 描述论（r115 立场层——五描述方式非五种实体）= **双基座形态**（本体层 + 立场层——理论环数维持 12；空间理论作为描述的组织框架 = 两基座的组织面注记）。

# Stage 2 阶段计划（完整语言 · 规划轮）

> **Author**: Super Z（PM-A/ARCH-A/PL-A 联合）
> **Date**: 2026-09-11
> **Version**: v0.4.0-plan
> **Status**: Active（批次 F r16 交付闭环；批次 G r17 交付（38-a~g：605:0:0）；**批次 H r18 交付**（40-a~g：634:0:0）；**批间插入轮 r19 交付**（41-a~c：能力模型泛化设计——模型层骨架 capability_model.rs P3 冻结 + 化学反应矩阵 6 条；**批次 I 细化完成**（42-x 八 MUV 分解——本文件 §5a）；**批次 I 执行启动 r20 交付**（42-a：I1 切口评估与迁移设计——[i1-incision-migration-design.md](./i1-incision-migration-design.md) 切口裁定 INC1-INC8 + 段序 S1-S3 + parity 三门 + CompilerKind 切换点）；**批次 I 执行 r21 交付**（42-b：I1 前段基础核心形式 kerf 化——compiler.krf 八臂 + bootstrap_compiler.rs 桥 + 门 A parity 19 测试（基础组 ≥8 超额）+ R4 操作码三方冻结修正 40→41，657:0:0 零回归）；**批次 I 执行 r22 交付**（42-c：I1 中段糖/module/require 面全迁移——module 体 inline（逐项恒非尾位 + Pop 携项 Span + 空体 PushNil + 首原型名覆写值等价注记）+ require PushNil + 门 A 扩展组 46 case（糖九件 + 宏 + prelude 注入序 preamble.krf 真实语料 + examples 六件双路径）+ 行为面糖/module 2 组，665:0:0 零回归；**批次 I 执行 r24 交付（I2 stdlib/GC/TD 批）**（42-e：**TD 五项清偿**——TD-010 闭包/内置装箱（HeapObj::Foreign + 追踪器协议 + 往返恒等）+ TD-011 字符串全序（码点序全族 + R3 静态面同步）+ TD-014 嵌套 define 归因（专门消息 + 双侧镜像 + parity 2 case）+ TD-018 消息单源（messages.rs 五族 + truthy 单一实现 + 对拍回归）+ TD-023 根扫描对症（GcCell 堆根性摘要 + 缓冲复用——非尾形基准重定型 144.06→105.15ms **-27.1%**，尾形/fib 噪声带）+ **TD-008 裁定 DEFER（实测依据三面——Stage 3+ 条件触发）** + stdlib 缺口补齐（谓词 5 件 + prelude foldr——清单清零，09-stdlib v6.3 57 项），684:0:0 零回归 + 净 14；**批次 I 执行 r23 交付（I1 收口）**（42-d：CompilerKind::{Bootstrap,Seed} 生产切换（分派位 front_from_core 第 4 步——bootstrap init 恒种子）+ 守护 production_compiler_is_bootstrap + **门 B fixpoint 两次编译自身字节一致**（B₁/B₂ 四程序 bytecode_equal + SHA-256 摘要——§21.3 条件 2 终验；加强判据按名反汇编全等 + 跨链符号值不对齐实测裁定入 i1-design v1.3）+ eval 退役终态裁定（INC7 兑现：CLI/驱动面移除 + T1 新口径生产链 vs 种子链 run_source_seed + TD-017/TD-009 联动注销 + 12 §2.5 行 299 回写）+ 缓存键 CompilerKind 分桶（B11/P4——种子路径不查不存实测）+ 三自举模块 install_state/reset_state 钩子（fixpoint B₂ 轮语义），670:0:0 零回归 + 净 5）；**批次 I 执行 r25 交付（I 后段双主题）**（42-f：**Effect M1-M5 全交付**——原语集 9→11（perform/handle——01 §7.3 W1 回写）+ resume 脱糖（D4）+ VM ext1 具体化（D6：HandlerFrame + INSTALL_HANDLER/PERFORM 两指令 41→43 + 三原型帧编排 T/H/B + trampoline 惰性单例 + continuation 值四要素（帧链含 handler 帧/数据栈快照/恢复点/线性唯一））+ E0007-E0009 诊断族（D9——18 §6 码位登记表 W3 + R10/R11 归约规则 W4 + 04 指令族 W5 回写）+ GC 六来源（M5：活跃 continuation 帧根集 + ForeignBox 装箱追踪）+ 自举双侧 parity（expander.krf 三展开臂 + compiler.krf 三原型臂 + 桥两向——门 A 扩展 3 case）+ 双路径一致 8 case + eval 域逃逸承载（M3 新口径——42-d 退役后 resume 一致性由双编译链承载）+ native 显式拒绝（B1 同型）+ 效应 GC 压力语料（effect_stress.krf）；**能力管线泛化 M2 交付**（IoFamily 形状标记——IoGrant = Grant<io 族> 别名兼容（冻结路径零删改）+ 门控表 net 增行评估 = 维持不增行（依赖条件①效应已就位；引入窗口 Stage 2 末——零破坏纪律）+ 706:0:0 零回归 + 净 22）；批次 I 下一 MUV = 42-g I3 门审查（§7.3 ≥30 新 case + §21.3 四条锚定 + §14 阶段末环））；**批次 I 收口 r26 交付（I3 门审 + 收尾）**（42-g：**stage2_gate_audit_r1 门审计集 53 case**（A12 单语句 + B12 多语句（糖/module/require/宏/能力门控 E0006 编译期拒绝面）+ C10 复杂（⑥循环 ⑦深度 + E0007/E0008/E0009 深链）+ D6 恢复 + **E7 上轮修复边界（§7.3.2——r23/r24/r25 修复面逐项锚定）** + P6 正向含 §21.3 四条件锚定探针（门 B 轻量 fixpoint + QBE native fib + FFI 模型冻结）——实测 53/53 PASS EXIT 0 **APPROVED 零新发现**（七类全覆盖 + 配比全过 + 边界 7 ≥ 5））+ **§14.5 深审报告 deep-review-round1.md**（D1-D8 八维度三段式（批次 I 面裁剪——如实定位批次末门审非大阶段末）+ §14.8 偏差清单（闭环 8 行 + B1 残留 3 行：HM 生产切换/FFI 实现/net 门控行——均纳后续批次计划）+ §14.9 C1-C6 整理（hm.rs 2 处 catch-all 注释补齐 §14.6.1.1 + 审计器 2 处 clippy result_large_err 修复——706:0:0 零回归）+ **§6.3 五角色投票 5.5/5.5 = 100% GO**）+ 42-h 收尾（47-z）：§3.2 六命令 clean 起步全绿（build 13.56s/check 0/fmt 0/clippy --workspace 超集 0/test 706:0:0/三审计集 EXIT 0 + CLI 四路径）+ 对账六面（matrix r26 行 + pipeline 滞后两轮补账 r24 +14/r25 +22 → v0.4.0-r26 + RELEASE_NOTES r26）+ r26 tar.gz + web 同步 + rec 树 10_r26；批次 I 终收口——下一步批次 J 规划轮（效应 typecheck 收敛 + HM 切换评估 + FFI 实现排期））；**批次 J 规划轮 r27 交付**（48-a：**§5b 批次 J 细化四 MUV**（48-b 效应 typecheck 收敛——typecheck.rs/hm.rs 子表达式遍历补 D3/D8 覆盖缺口 / 48-c HM 旗标期切换——D8 阶段 2 GO 裁定落定 + 契约重定义 P0-2 兑现 / 48-d FFI VM 面做实——write_stdout pin 窗口规程 + Alloc/FreeExternal + E0010-E0012 / 48-e 收尾）+ **§5c 批次 K 概排**（49-x 终批：终门审 + §14.5/§14.6/§14.8/§14.9 大阶段末深审环 + §21.5 九信号全核对 + Stage 3 切换 GO/NO-GO）+ **§5d Stage 2 余下面处置表**（12 §2.5.1 十一行逐行落位：多阶段/缓存增量 DEFER Stage 3 依据 + net 门控窗口核对规划轮内闭环（Stage 3 触发式——四依据）+ TD-003/005/015 排期改判 Stage 3）——零代码规划轮 706:0:0 复验零回归）；**批次 J 执行启动 r28 交付**（49-a 会话 Task：**48-b J1 效应 typecheck 收敛全交付**——typecheck.rs Perform 效应值入 R1-R8 检查域 + Handle 两体入检出域（payload/resume 装订 Unknown，Lambda save/restore 同型）+ hm.rs 同口径收敛（Binding::Mono(Dynamic) 装订，infer_let 同型）+ 静态负例组 4 测试 6 违例 case（双面检出超集纪律）+ 零误报对照（六正例 + 绑定器动态用点 + effect_stress.krf）+ 生产入口实证（E0005 定位 handler 子句体 1:25）——**710:0:0 零回归 + 净 4**；深审 D3/D8 闭合注记 + pipeline R4 修正（Tier 2 头 463→503 实测回写）；下一步 48-c J2 HM 旗标期切换）；**批次 J 执行 r29 交付**（50-a 会话 Task：**48-c J2 HM 旗标期切换全交付（D8 阶段 2 落地）**——driver.rs check_source/check_source_recover 两入口判定面 = hm_check_program（接口同构零适配；run 路径零接触维持；R1-R8 退为回归基线断言——双面检出纪律保留）+ 契约重定义显式登记（P0-2 兑现——hm-inference-design v0.2.0 §2.3 旗标期节：「零类型不一致误报」口径 + occurs/自应用面政策豁免 + 双向锚范围重锚）+ 断言重锚 5 处 + **切换实测双缺口当场修复**（①Ordering 臂 TD-011 r24 字符串全序同步——(< \"a\" \"b\") 误报归零；②car/cdr 臂 Nil 移出保守跳过——(car nil) 漏检归零）+ 旗标期判定面测试组 3 件 + 12 §2.5.1 类型检查器行迁移评估结论 ✅（v6.4——自举内迁裁定留 Rust：INC8 三段口径 + INC3 静态分析面不在自举关键路径）——**713:0:0 零回归 + 净 3**；CLI check 负例 E0005「类型不一致：num 与 str」定位 1:24 生产实证（R1-R8 时代静默）；下一步 48-d J3 FFI VM 面做实）；**批次 J 执行 r30 交付**（51-a 会话 Task：**48-d J3 FFI VM 面做实全交付（§21.3 条件 4 兑现）**——操作码三指令 43→46（CALL_EXTERNAL/ALLOC_EXTERNAL/FREE_EXTERNAL——语言面形式 Stage 3 编译臂不发射）+ 窗口规程步 2-4（char* 装箱堆槽 pin + 数据指针借用 + unpin 配平）+ Heap Φ 计数簿（P1/U1/U2 + F-PIN + supp(Φ) 并入 mark 起点）+ 线性令牌状态机（消费全局生效）+ E0010-E0012 诊断族落位（18 §6 r18 预留兑现）+ FfiBoundary 真实实现 + FfiCall 字面量 lowering 面+ write_stdout extern 注册（正例端到端真实 I/O）——**758:0:0 零回归 + 净 45**（ffi_vm_tests 37 case 13 边界全落地 + 正负比 ≥1:3 + Φ/P-U 机制组；TD-026 语言面/编组收窄登记）；回写六面（06/05/13/04/18/TD）；下一步 48-e J4 批次 J 收尾）；**批次 J 收口 r31 交付（48-e J4 批次 J 收尾——会话 Task 52-a/52-z）**：12 §2.5.1 十一行注记批次 J 终态复核 ✅（v6.5——Effect Handlers 48-b 收敛面兑现注记 + VM+GC FFI Φ 簿注记 + 类型检查器行终态（默认期评估移交批次 K 终门审））+ §3.2 六命令 clean 起步复验全绿（758:0:0 零代码轮维持）+ 对账四面（matrix r31 / pipeline v0.4.0-r31 / RELEASE_NOTES r31 / plan 本注记）+ r31 tar.gz 包内自举 + web 同步 + rec 树补账（14_r30 + 15_r31 + l 两层）——**批次 J 全收口；下一步批次 K 终批（§5c 三 MUV——49-x 重分配）**）；**批间插入三连 r32-r34 交付**（53-x 表面现代化设计轮[20-表面规范 v1.0 + 原则 33 + TD-027] + 54-x 能力架构深度设计轮[21/22 双新文件 + 原则 34] + 55-x 设计缺陷深度审计收敛轮[23-演进治理 v1.0 + 21/22 v1.1 + 原则 35]——设计栈四层落齐，758 维持零接触——详录见下方批间插入注记）；**批次 K 首件 r35 交付**（56-a 附录级同步[stage0 v6.5 + sop v12.4] + 56-b K1 终门审：stage2_gate_audit_r2 46 case APPROVED + §21.3 四条件终验 + §21.5 九信号核对 + 投票 100% GO——详录 K1 执行注记）；**批次 K 次件 r36 交付**（57-x K2 大阶段末深审环：§14.6.3 三轮深挖 + deep-review-round2 大阶段末版 D1-D8 + §14.6 六件套 + §14.8 回写四件 + §14.9 整理 19 处零行为 + TD-028 登记 + 投票 100% GO + **final-assessment Stage 3 切换 GO 裁定**——758 维持，详录 K2 执行注记）；**批次 K 收尾 r37 交付（K3 收尾交付——会话 Task 58-c[r36 收尾中断清偿] + 58-a + 58-z + 58-web）**：§3.2 六命令 clean 起步全绿（build 13.15s 零告警/check 0/0/fmt 0/clippy -D warnings 超集 0/**758:0:0 零断言修改** + 四审计集 EXIT 0 ×4[41+50+53+46] + CLI 四路径[E0005 REAL_EXIT 1]）+ 对账六面 + 12 §2.5.1 类型检查器行 K3 终态注记（默认期评估闭环：HM 旗标期维持 + R1-R8 回归基线断言 + 默认期切换窗口归 23 §2.2 治理触发表 Stage 3 承载）+ v0.5-roadmap Stage 2 行收口（v0.1.0→v0.2.0——批次 G-J-K 全链 + Stage 3 GO）+ r37 tar.gz 包内自举 + web E2E + rec 树 21_r37——**批次 K 全闭环（K1 APPROVED + K2 GO + K3 收尾）→ Stage 2 全收口；下一步 Stage 3 入场序列（批次 L 表面现代化 → 批次 M 命名空间 → 移除轮——23 §2.2 触发表驱动）**）
> **输入**: sop.md §21（阶段推进规划）、§17（任务规划排版图）、§18（依赖审查）、§13.1（设计对齐）、§14（深度审查协议——阶段末环）、§4（MUV）、§19（打包）；[12-roadmap §1.3/§2.5](../../lang-design/12-roadmap.md)；[08-后端策略](../../lang-design/08-backend-evolution.md)；[13-能力矩阵 §3.3-§3.5](../../lang-design/13-capability-matrix.md)；[stage-1/plan](../stage-1/plan.md)（批次 A-E 交付实录 + 批次 F 注记）；r15 门审查（Task 34-d APPROVED + §6.3 五角色全票 GO）；r16 批次 F 深审环（deep-review-round1 + 偏差清单 17 项 + TD-023 新登记）
> **上游**: Stage 1 r15（553:0:0 全绿 / 读+展开两段全自举 / stage1_gate_audit_r1 50 case APPROVED）

---

## 0. 规划轮定位声明（§1.2「进入新阶段」路由产物）

本计划是 Stage 2 的**阶段规划先行文档**（依据 §1.2「进入新阶段」：§21 阶段规划 → §13.1 设计对齐 → §17/§4 → §7.3/§14.6）。**核心发现**：§21.5 切换信号九条中七条满足、一条部分满足（性能基线）、一条未执行（§14.6 阶段间深度验证——连带 §14.5/§14.8/§14.9 阶段末环）。因此本计划将 **批次 F（Stage 1 深审收尾环）定为 Stage 2 正式执行的前置批次**——先收尾 Stage 1 的 L3 阶段末协议，再进入 Stage 2 主体批次。

## 1. §21 阶段规划确认

| 项 | 裁定 | 依据 |
|---|---|---|
| 核心目标 | **完整语言**：完整 kerf 编译器（kerf ~80%）+ HM 类型推断 + 完整卫生宏 + FFI + 至少一个非 VM 后端 | §21.1 / 12-roadmap §1.3 |
| 实现语言 | kerf ~80% + Rust ~20%（构建引导 + 后端 FFI + 测试基建保持 Rust） | §21.4 |
| 后端策略 | **QBE 首选**（10% 代码 ≈ 70% 性能）+ C 转译并行评估（最大可移植性）+ Cranelift 备选；LLVM 仅 Stage 3+ 发布构建——**永不入自举链** | 08 §2 混合演进表 + §21.2 约束 1-4 |
| 代码量 | ~20000-50000 行 | §21.1 |
| 工程节奏 | 8-16 周估算；批次 F 收尾环先行（1 轮）→ G（后端/FFI/类型主线）→ H（语义演进评估）→ I（完整化收口） | §21.8 双口径 |

**§21.3 Stage 2 验收标准**（阶段门，全部满足才可进入 Stage 3）：
1. 完整 kerf 编译器用 kerf 编写（kerf ~80%——编译器本体迁移完成）
2. 两次编译自身结果一致（自举确定性——现有 parity 基建扩展到全编译器）
3. 至少一个非 VM 后端工作（QBE PoC → fib/gc_stress 端到端本地码执行）
4. FFI 可用（ExternalType/FfiCall/FfiBoundary 按冻结契约做实）

**阻塞项与缓解**（§21.3）：FFI 所有权模型未定义 → **批次 G3 先行定义**（GC pin/unpin 边界 + 线性令牌跨 FFI 边界的语义裁定——13 §3.3.4 冻结规格的行为补全），实现随后。

### §21.5 切换信号核对（Stage 1 → Stage 2，逐项实测对账）

| # | 信号 | 状态 | 证据 |
|---|---|---|---|
| 1 | 语义稳定 | ✅ | 553:0:0（R1-R9 归约 + T1 双路径一致 + r13 作用域集解析收口 + E1-β 宏收口零回归） |
| 2 | 自举验证 | ✅ | r15 读+展开两段全自举（compile_front 经 reader.krf + expander.krf 含宏）；parity 逐字节等价（r6 87/307 case + r15 宏 parity 17 + 消息逐字） |
| 3 | 测试覆盖 ≥95% | ✅ | 553 测试函数 + 双审计集 91 case；正负比 ≈1:3.15（≥1:3，§9.4.3）；七类负向矩阵 7/7 |
| 4 | 性能基线 | ⚠️ | Stage 0 基线存在（performance-baseline.md）；**Stage 1 自举管线性能基线未单独建立**（VM 1/10-1/30 区间实测 + 自举 vs 种子编译开销对比缺失）→ 批次 F4 补录 |
| 5 | 文档同步 | ✅ | r15 六处对账（matrix 553 / plan 批次 E 收口行 / RELEASE_NOTES / 03 宏系统 E1-β 边界 / 07 自举 Expander 交付标记 / 测试计划三篇） |
| 6 | 能力处理程度与 §21.9 一致 | ✅ | v11.1 对账注记（四项做实无倒挂）；类型检查器提前引入偏差已登记（§21.6 缓解路径显式裁定） |
| 7 | 技术债 P0/P1 清零 | ✅ | 登记册 TD-002~022：P0/P1 开放 = 0；开放项 = TD-007 P2 残留（10_000 完整口径）+ P3 若干（TD-003/005/008/009/010/011/014/022） |
| 8 | 外循环投票 ≥95% | ✅ | 34-d §6.3 五角色全票 GO（PM/ARCH/DEV/QA/REC——553 全绿 + 双审计 APPROVED + §21.3 四条件锚定 + TD 对账） |
| 9 | 阶段间深度验证 §14.6 | ❌ | **未执行**——Stage 1 仅完成 §7.3 门审 + §6.3 投票；§14.5 D1-D8 深审 / §14.8 B1-B4 回写 / §14.9 C1-C6 整理 / §14.6 四项审查均无产出（Stage 0 对照物：六篇深审文档 + final-assessment） |

**核对结论**：9 条中 7✅ + 1⚠️ + 1❌。信号 9（及 4 的补录部分）为批次 F 的全部内容——**Stage 2 主体批次不可在批次 F 完成前启动**（依据 §21.5「全部满足」语义 + §1.3 L3 流程图 Commit → Deep → Writeback → CodeClean → CrossStage → GO 的既定次序）。

## 2. §13.1 设计对齐（lang-design → Stage 2 需求映射）

| lang-design 文档（v6.2） | Stage 2 消费点 | 对齐结论 |
|---|---|---|
| 08-backend-evolution §1-§3 | 批次 G 后端策略的完整论证（Cone 实测：LLVM 小程序迭代慢 100-150×；QBE 70% 性能；PyPy 数据）+ CodegenBackend 契约 | 规格完备可直接实现；WasmBackend 属 Stage 2+ 可选项 |
| 13-capability-matrix §3.3.4/§3.3.7 | FFI（ExternalType/FfiCall/FfiBoundary——P1 冻结）与多目标后端（CodegenBackend/WasmBackend——P1 冻结）按契约做实 | P1 trait 签名 + 行为规格完整（含 GC pin/unpin 隔离协议）；仅缺所有权模型语义裁定（G3） |
| 13-capability-matrix §3.3.2/§3.3.5 | LSP 基础服务器（P0 预留 LanguageService/IncrementalAst）与查询系统（P0 QuerySystem）——Stage 2 做实候选 | 位置对账六项 ✓（r12 断言测试锁存）；做实顺序待批次 G/H 优先级裁定（LSP 列 12-roadmap Stage 3 侧，本阶段最小面） |
| 01-core-forms §7.3/§8.3 + stage0 §6.12.6 | 8 原语迁移五项语义层评估清单（Let/Perform·Handle/de Bruijn/continuation/语义化命名）——批次 H 主题 | 全部五项已登记且绑定 §13.2 切换期重构 + 委员会投票（核心冻结原则 9 精确化裁定） |
| 06-operational-semantics | Perform/Handle 原语化对照（现有元层效应路径 vs 原语级）+ continuation 三要素 | 语义锚就位；效应语言级引入（12 §2.4 表 Stage 2 行） |
| 02-syntax-model §1 | 多语法可插拔 Reader（S-expr 皮肤可替换——Rust/Go 风格目标语法切换评估） | 12-roadmap §2.3 v5.5 量化背书（两语法 CoreExpr 全等）；Stage 2 评估项（非承诺项） |
| 07-bootstrap §3.3 | 自举策略 Stage 2 完全自举（编译器全本体 kerf 化 + 两次一致） | 信号清单已就位；两次一致验证基建 = parity 框架扩展 |
| 09-stdlib | 标准库完整化（48 → 完整集） | 基线就绪（列表/字符串/I/O 三族） |
| 05-runtime §4 | TD-008 分代 GC / 堆压缩（Stage 2 既定推迟路径的到期） | 排批次 I（收口期）评估（+ TD-023 回归同轮——r16 绑定） |
| 12-roadmap §2.5 演进矩阵 Stage 2 列 | 12 行逐行对账 | 全部行有批次落位（见 §3 排版图）——无缺口阻塞 |

**对齐结论**：lang-design v6.2 对 Stage 2 需求**无缺口阻塞**——FFI/后端 P1 契约完整（仅所有权语义待 G3 裁定）；8 原语演进评估有显式清单与流程绑定；演进矩阵 12 行全部映射到批次节点。

## 3. §17 任务规划排版图（七步流程）

### Step 1 扫描结果（§17.2 强制扫描）

- **设计意图摘要**：Stage 2 交付完整语言——编译器本体 kerf ~80% 化 + HM 推断 + FFI + QBE 首个非 VM 后端；两处语义层演进（8 原语迁移 / Effect 语言级）走 §13.2 切换期重构 + 投票；14 项预留中 P1 三组（FFI/后端/服务化）+ P2 两组进入做实窗口。
- **技术债状态**：TD-002~023 开放 14 项——TD-007（P2 残留：10_000 口径，受 Stx 值语义深树 clone/drop 递归约束——Rc 化解除排批次 H2 与 de Bruijn 评估合并）+ **TD-023（P2：gc_stress 根扫描回归，r16 深审新登记——排批次 I2 与 TD-008 同轮）** + TD-013（P2：多错误恢复实现，r16 改判绑定 G2）+ P3 十一项（TD-003/005/008/009/010/011/014/015/017/018/022）。
- **校准基线**：L3 轮次按「问题簇」计轮；单人 Agent 会话按批次推进 + 每批次独立内循环（沿 stage-1 惯例）。
- **能力边界**（v0.1-capability-boundaries + r15 后现状）：支持 9 原语 + 10 糖 + syntax-rules 完整模式面 + 48 内置 + prelude 四函数 + 模块/导入 + 能力门控 I/O + 编译缓存。**Stage 2 需扩展**：TCO（或分块驱动——TD-022 裁定）、quote 符号向量边界、字符串序、FFI 面、非 VM 后端目标。
- **测试矩阵**：553:0:0（单元 184 + 集成 369 + 双审计 91 case）；正负比 ≈1:3.15。
- **上一阶段输出**：r15 门审查 APPROVED + §6.3 全票 GO（发现项 2 已当场修复——P2 诊断质量）；**批次 F 深审环（r16）= 信号 4/9 的兑现轮**。
- **路线图对齐**：v0.5-roadmap 第 3 行（Stage 2 完整语言，本计划即该行的展开）。

### Step 2-4 任务依赖图 + 节点流（DAG 拓扑排序）

```mermaid
flowchart TD
    subgraph BF["批次 F：Stage 1 深审收尾环（Stage 2 前置——§21.5 信号 4/9 兑现）"]
        F1["F1 §14.5 D1-D8 深审<br/>（deep-review-round1.md）"]
        F2["F2 §14.8 B1-B4 设计回写<br/>（lang-design 实施状态 v6.2）"]
        F3["F3 §14.9 C1-C6 代码整理<br/>（组织收敛零语义变化）"]
        F4["F4 §14.6 四项审查 + 性能基线<br/>（final-assessment + perf-baseline）"]
        F5["F5 收尾交付：roadmap 回写 + r16 打包"]
        F1 --> F2 --> F3 --> F4 --> F5
    end
    subgraph BG["批次 G：后端 / FFI / 类型三主线"]
        G1["G1 QBE 后端 PoC<br/>（CodegenBackend 做实 + 端到端）"]
        G2["G2 HM 推断设计轮<br/>（R1-R8 保守 → 推断升级评估）"]
        G3["G3 FFI 所有权模型定义<br/>（§21.3 阻塞项先行裁定）"]
    end
    subgraph BH["批次 H：语义演进评估轮"]
        H1["H1 8 原语迁移五项评估<br/>（§13.2 + 委员会投票）"]
        H2["H2 TCO 决策 + TD-007 Rc 化<br/>（TD-022 帧消耗裁定）"]
        H3["H3 Effect 语言级引入设计<br/>（Perform/Handle 对照）"]
    end
    subgraph BI["批次 I：完整化收口"]
        I1["I1 两次自举一致<br/>（编译器本体 kerf ~80%）"]
        I2["I2 stdlib 完整化 + GC 评估<br/>（TD-008 + TD-023）"]
        I3["I3 门审查<br/>（§7.3 + §21.3 四条）"]
    end
    BF --> BG
    G1 --> BI
    G3 --> G1
    BG --> BH --> BI
```

**拓扑序**：F1 → F2 → F3 → F4 → F5 → G3 → (G1 ∥ G2) → (H1 ∥ H2 ∥ H3) → I1 → I2 → I3。
G3 先于 G1（FFI 所有权模型是后端 FFI 交互面的前置裁定）；批次 H 三项相互独立可并行；批次 I 收口。

### Step 5 设计-开发-测试节点流（每 MUV 三位一体）

`设计锚（lang-design § / 登记册 TD）→ 开发（crate/模块 + §10 命名 + §11 隔离）→ 测试（正例 ≥1 + 负例 ≥3 + 集成锚点 + 端到端）`——批次 F 的开发位为审查产出文档/整理，测试位为复跑全套件回归。

### Step 6 缺陷纳入（修复任务节点）

- 深审环（F1-F4）发现项 → 当轮内循环修复（§5.2）；P2/P3 记登记册并绑定批次 G-I 节点。
- §14.6.1.4 强制修复项：复杂度增长 ≥2× 的隐藏问题必须在批次 F 内修复（否则 NO-GO 升级）。

### Step 7 审查结论

排版图 DAG 无环（拓扑序存在）；§21.9 演进矩阵 Stage 2 列 12 行全部映射到批次 G/H/I 节点；§21.3 四条件全部落位（条件 1 → I1；条件 2 → I1；条件 3 → G1；条件 4 → G3+G1）；§21.5 信号 4/9 兑现路径 = 批次 F。**审查通过，进入批次 F 执行（§6.3 已于 r16 批准——5.5/5.5）。**

## 4. §18 依赖与基础设施审查

| # | 审查项 | 结论 |
|---|---|---|
| 1 | 基础设施能力 | parity 框架（逐字节等价比对）/ 编译缓存 / 双审计集 / 553 基线全绿——深审环复跑基建完备 ✅ |
| 2 | 前置项完整性 | §14.5 模板 / §14.6 四项协议 / §14.8 B1-B4 / §14.9 C1-C6 均已冻结于 sop v12.0；Stage 0 六篇深审产物为格式范本 ✅ |
| 3 | 其他依赖问题 | ① QBE 二进制属外部工具——按 §3.1 查 `scripts/`→`tools/`→`docs/tools/` 再安装记录（不阻塞批次 F）；② 性能基线测量需基准程序集（现有 examples/gc_stress + fib 足够起步）；③ HM 推断设计轮需 16-reference-analysis 参照分析复核 |
| 4 | 全面审查 | 三项均非阻塞：①批次 G 前落位即可；②③属设计输入完备性问题，已有文档锚 |

**结论**：依赖完整无缺失项——批次 F 可立即执行（F1 唯一输入 = r15 全量基线 + 本计划）。

## 5. §4 MUV 拆分（六字段）

### 批次 F（Stage 1 深审收尾环——首个执行批次，Task ID 36-x）

| 字段 | F1（§14.5 深审） | F2（§14.8 回写） | F3（§14.9 整理） | F4（§14.6 验证 + 基线） | F5（收尾交付） |
|---|---|---|---|---|---|
| 输入条件 | 本计划批准 + r15 基线 | F1 报告产出 | F2 完成 | F3 全绿复跑 | F4 GO 判定 |
| 输出物 | stage-1/deep-review-round1.md（D1-D8 三段式 + 委员会投票节） | lang-design 实施状态回写（v6.1→v6.2 状态注记；B1-B4 偏差分类表） | C1-C6 六维度整理（如发现；零语义变化约束） | architecture-review / design-impl-test-coverage / hidden-problems / performance-baseline + final-assessment.md（Stage 1 版） | v0.5-roadmap Stage 1 行 ✅ + 12-roadmap §2.5 注记 + matrix 对账 + RELEASE_NOTES r16 + tar.gz（§19.4）+ web 同步 |
| 验收标准 | D1-D8 全维度三段式结论 + 阻塞项分级清点（P0/P1 = 0 维持） | B1-B4 全偏差分类 + 每项附条款号（GATE 3） | 行为不变：553 逐一等价零断言修改 + §3.2 全绿 | 四项审查各 ≥1 产出文档 + 性能基线含自举 vs 种子开销实测数字 + 复杂度 ≥2× 隐藏问题清零 | §3.2 六命令全绿 + 包内自举验证 553:0:0 + E2E |
| 集成验证用例 | 深审报告交叉引用 worklog Task 20-35 全链 | —（文档） | 全套件回归即集成验证 | 基准程序实测（fib/gc_stress/stress 展开） | 双审计集 EXIT 0 |
| 责任 Agent | ARCH-A（D1/D5）+ QA-A（D3/D6/D8）+ REV-A（D2/D7）+ PM-A（D4） | REC-A | DEV-A | ARCH-A + QA-A | QA-A/REC-A |
| Task ID | 36-a | 36-b | 36-c | 36-d | 36-e |

### 批次 G-I（Stage 2 主体，批次 F 交付后逐批细化）

| 批次 | MUV 序列（概排） | 关键验收 | Task ID 起 |
|---|---|---|---|
| G | G3 FFI 所有权模型定义（GC pin/unpin 跨边界语义 + 线性令牌裁定——13 §3.3.4 行为补全）→ G1 QBE 后端 PoC（CodegenBackend trait 做实 + AnnotatedANF 入参验证 + fib 端到端本地码）→ G2 HM 推断设计轮（保守 R1-R8 → HM 升级评估 + 16 参照复核）+ **TD-013 多错误恢复实现（r16 深审改判绑定——expander 恢复展开与推断升级同为前端诊断主线）** | §21.3 条件 3（首个非 VM 后端）+ 条件 4 前半（FFI 契约做实）+ 阻塞项解除 + TD-013 偿还 | 38-x |
| **G 执行注记（r17）** | 38-a G3 ✅（ffi-ownership-model.md 216 行——pin/unpin 形式化 + 线性令牌 + 13 边界 case + 19 决策；回写义务 4 处登记批次 I）/ 38-b·c G1 ✅（QBE 1.3 落位 tools/qbe + kerf-backend 第 10 crate：契约迁移（原则 27 re-export）+ AnnotatedANF 实化 + phi 合成 + QbeBackend + aot 编排；CLI +2 命令（anf/native）；**fib(12) ⇒ exit 144 本地码端到端 + VM 一致**；TD-024 PoC 边界 B1 登记）/ 38-d G2 ✅（hm-inference-design.md 303 行——约束三段式裁定 + GO 有条件：PoC 排批次 H 新增 MUV H4）/ 38-e TD-013 ✅ **resolved**（双路径恢复 + check_source_recover 合并报告 + CLI check 切换）/ 38-f ✅（605:0:0 + §3.2 全绿 + 对账 + tar.gz + web） | 全验收过 + 605 基线 | 38-x |
| H | H1 8 原语迁移五项评估（Let/Perform·Handle/de Bruijn/continuation/语义化命名——§13.2 切换期重构流程 + §6.3 投票逐项）∥ H2 TCO 决策（TD-022 帧消耗 + TD-007 Rc 化 10_000 口径同轮 + TD-017 eval 深度裁定随 eval 重写评估——r16 改判注记）∥ H3 Effect 语言级设计（Perform/Handle 原语化对照 06 现行语义） | §6.3 逐项投票记录 + 语义变更零静默（GATE 3） | 40-x |
| **H 执行注记（r18）** | 40-a ✅（38-g 终验补记 + r17 终态包刷新复验——上会话落账缺口 P2 清偿）/ 40-b H1 ✅（primitive-migration-evaluation.md——五项三段式 + J1-J6 30 点 + 投票 20 票全票：E1 DEFER-STAGE3 / E2 GO-DESIGN / E3 分层 / E4 SPEC / E5 REJECT；**总裁定 Stage 2 原语集零变更**）/ 40-c H2 ✅（**TCO 落地**：TailCall 帧复用 + 尾位穿线 + 指令预算护栏；**TD-007 resolved**（Rc + 均匀标记 + 迭代 retag + 扁平 Drop——10_000 口径 0.02s）；TD-017 裁定维持 256；TD-023 P2→P3（gc_stress -70% 实测）+ TD-025 登记（自举侧包装链 O(N²)））/ 40-d H3 ✅（effect-language-design.md 12 裁定——实现窗口 D12 = 批次 I 后段）/ 40-e H4 ✅（hm.rs 约束三段式 PoC——**双门全过**（超集 29 + 零误报）+ 四类缺口检出 + fib : (num→num)）/ 40-g ✅（用户指令插入：reserved/ 标准化拆分——mod.rs 344→66 行 + 4 能力族独立文件 + reserved_ext_tests 零改动兼容实证）/ 40-f ✅（634:0:0 + §3.2 全绿 + 对账六面 + r18 tar.gz + web + E2E + git） | 全验收过 + 634 基线 | 40-x |
| I | I1 编译器 kerf ~80% 迁移收口（compiler 本体 kerf 化 + 两次编译自身字节一致）→ I2 标准库完整化 + TD-008 分代 GC 评估（**+ TD-023 gc_stress 回归根扫描对症——r16 深审新登记绑定本节点**）+ TD-009/010/011 P3 批量清偿 + TD-014/018 消息质量批 → I 后段 Effect 实现（D12 窗口）+ 能力管线泛化 M2（同轮）→ I3 Stage 2 门审查（§7.3 ≥30 新 case + §21.3 四条锚定） | §21.3 条件 1/2 + Stage 3 切换信号就位 + TD-023 偿还 | 42-x 起（细化见 §5a） |

### §5a 批次 I 细化（r19 / 41-b——42-x 八 MUV 分解，仿批次 F 六字段）

> **细化依据**：拓扑序 I1 → I2 → I 后段（D12/M2 同轮）→ I3 维持（12 §2.5.1 演进矩阵 + effect-language-design D12 + capability-model-design D12/M2 双同轮协调裁定）；每 MUV 一个 Task ID，批次内逐 session 交付，末 MUV 收尾（同 38-f/40-f 惯例）。

| 字段 | 42-a I1 切口评估与迁移设计 | 42-b I1 前段：基础核心形式 kerf 化 | 42-c I1 中段：糖/module/require 面 | 42-d I1 收口：两次编译自身一致 |
|---|---|---|---|---|
| 输入条件 | 41-a~c 交付 + 634 基线 | 42-a 方案 GO | 42-b parity 增量全绿 | 42-c 全绿 |
| 输出物 | compiler 本体盘点文档（compile/desugar/sugar/analyzing 各段行数与依赖图）+ 分段迁移方案（段序 + parity oracle 扩展设计 + 切换点）| 基础形式段迁移（quote/if/lambda/app/set!/define/begin——kerf 源 + 种子编译对照）+ parity 增量 ≥8 case | 糖形式 + module/require 段迁移 + parity 增量 ≥12 case（糖九件 + module 边界） | **自举终局**：kerf 编译器编译自身 → 产物编译自身 → 字节一致（§21.3 条件 2）+ eval 退役终态裁定（TD-017 终验 + 12 §2.4 演进矩阵行回写）|
| 验收标准 | 方案六字段齐 + 段切分依赖无环 + 每段验收可量化 | 双路径产物一致（逐字节）+ 零回归 634 基线 | 同左 + 展开/编译全管线 parity | 两次编译产物 SHA-256 一致 + 全套件零回归 |
| 集成验证 | —（设计轮） | 基础形式 parity 组 | 全管线 parity 组 + 自举管线端到端 | 自举链端到端 + 双审计集 EXIT 0 |
| 责任 Agent | ARCH-A/PM-A | DEV-A/QA-A | DEV-A/QA-A | DEV-A/ARCH-A |

| 字段 | 42-e I2：stdlib/GC/TD 批 | 42-f I 后段：Effect 实现 + 能力 M2 同轮 | 42-g I3 门审查 | 42-h 收尾交付 |
|---|---|---|---|---|
| 输入条件 | 42-d 收口 | 42-e 全绿 + effect-language-design 冻结面 | 42-f 全绿 | 42-g APPROVED |
| 输出物 | stdlib 完整化（缺口盘点→补齐）+ TD-008 分代 GC 评估裁定（GO/DEFER + 依据）+ TD-023 根扫描对症 + TD-009/010/011 P3 批量清偿 + TD-014/018 消息质量批 | **Effect M1-M5**（VM ext1 激活 + perform/handle 编译 + E0007-E0009 诊断族 + parity 迁移路径按 effect-language-design §迁移）+ **能力管线泛化 M2**（IoGrant→族无关形态别名兼容 + 门控表 net 增行评估——capability-model-design §7） | stage2_gate_audit（≥30 新 case + 7 类覆盖 + 上轮修复边界 case）+ §21.3 四条件终验 + §14 阶段末环（D1-D8 深审 + B1-B4 回写 + C1-C6 整理）+ §6.3 投票 | §3.2 六命令 + 对账六面 + r20 tar.gz 包内自举 + web 同步 + git + 树压实 |
| 验收标准 | TD 批量 resolved/裁定注记齐 + gc_stress 回归 ≤5% + stdlib 缺口清单清零 | effect 五 MUV 验收（设计文档测试锚正 6 负 6）+ 能力 M2 零破坏（既有测试零改动）+ 全绿零回归 | 门审计 APPROVED + 投票 ≥4/5 + 四条件逐条证据链 | §3.2 全绿 + 包内自举验证 + E2E |
| 集成验证 | gc_stress/stress 全组 | effect 端到端（VM run + native）+ require 门控全路径 | 双审计集 + 全套件 | 双审计集 EXIT 0 |
| 责任 Agent | DEV-A/QA-A | DEV-A/ARCH-A/QA-A | QA-A/REV-A + 全角色 | QA-A/REC-A |

**批次 I 排程注**：(1) 42-b/c/d 每 MUV 可能跨 session（段迁移体量大——按段内形式分批交付，parity 增量每批 ≥8）；(2) 42-f 为双主题同轮（Effect D12 + 能力 M2——driver 组合根双接触面显式协调，worklog 交叉引用）；(3) TD-025 已于 r18 根治（resolved）——不在本批清单；(4) HM 旗标期切换（D8 演进轨道阶段 2）随 42-d 后评估排入。

### §5b 批次 J 细化（r27 / 48-a——Stage 2 收官主体批规划，仿 §5a 六字段）

> **细化依据**：r26 47-z「下一步」指针（效应 typecheck 收敛 + HM 生产切换评估 + FFI 实现排期 + net 门控窗口核对——四主题）+ [deep-review-round1.md](./deep-review-round1.md) D4 就绪表（「批次 J 早期决策点——防 PoC 长期化」）+ §14.8 B1 残留三项收编（HM 旗标 / FFI 实现 / net 行——W 计划显式「均纳后续批次计划」）；本节同时收编 **Stage 2 余下面全量处置**（12 §2.5.1 演进矩阵逐行落位——见 §5d 处置表；net 门控窗口核对在本规划轮内闭环）。**批次定位**：J = Stage 2 收官主体批（四 MUV）；K = Stage 2 终批（大阶段末 §14.6 阶段间深验证 + §21.5 九信号全核对 + 终门审 + Stage 3 切换评估——深审 §0 既定「终批执行」义务）。每 MUV 一个 Task ID，批次内逐 session 交付，末 MUV 收尾（同 §5a 惯例）。

| 字段 | 48-b J1：效应 typecheck 收敛 | 48-c J2：HM 旗标期切换 | 48-d J3：FFI VM 面做实 | 48-e J4：批次 J 收尾 |
|---|---|---|---|---|
| 输入条件 | 本计划批准 + 706 基线（r27 复验） | 48-b 全绿（超集门完备前置——效应体内违例入检出域） | 48-c 全绿（FFI 与 typecheck/HM 零耦合——可并行评估，按序交付） | 48-d 全绿 |
| 输出物 | typecheck.rs + hm.rs 效应臂收敛（**子表达式遍历**——Perform 效应值 / Handle 体与子句体受 R1-R8 与约束集检查；结果类型维持 Unknown——行多态 Stage 3 边界如实）+ 静态负例组 ≥3（效应体内类型违例检出——补深审 D3/D8「Unknown 放宽面」覆盖缺口） | driver check 面 HM 判定切换（check_source L563 + check_source_recover L626 两入口——D8 阶段 2 旗标期：`kerf check` 判定面 = hm_check_program；R1-R8 退为回归基线断言）+ **契约重定义显式登记**（P0-2 兑现：保守性断言更新为「零类型不一致误报」口径 + occurs/自应用误报面文档化为接受行为 + 双向锚 static_error_is_runtime_error 范围重锚）+ 类型检查器行「迁移评估」结论（自举内迁裁定——kerf ~80% 口径按三段达成的 Rust 保留面注记） | FfiCall VM 执行面（write_stdout char* 路径按 [ffi-ownership-model](./ffi-ownership-model.md) §8 窗口规程步 2-4：Str 堆槽 pin + 数据指针借用出界 + 返回后 unpin）+ AllocExternal/FreeExternal 面开放 + E9/E10/E11 诊断族落位 E0010-E0012（E11 符号解析——QBE PoC 既有路径对齐）+ §6 边界 13 case 对齐 + 回写四处（06 §3 E 族 / 05 §3.1 / 13 §3.3.4 / TD 登记册） | §3.2 六命令 + 对账六面 + r 末 tar.gz 包内自举 + web 同步 + git + rec 树 |
| 验收标准 | 效应体内违例 ≥3 负例全检出 + 既有 706 零回归（≤3 文件——深审 D1 预估口径） | 超集门（R1-R8 负例矩阵经 HM 面全检出）+ 零误报门（examples 六件套零诊断）全绿 + 契约断言重锚后全套件零回归 + E0005 族诊断次序口径不变 | 13 边界 case 全判定落地 + 正例端到端 ≥1 + 负例组正负比 ≥1:3 + 零回归 | §3.2 全绿 + 包内自举验证 + E2E |
| 集成验证 | bootstrap_compiler_tests 效应 parity 维持 | typecheck_tests 重锚（基线断言）+ hm_inference_tests 双门 | FFI 边界 case 组（后续 K 批审计集锚定预留） | 双审计集 + 全套件 |
| 责任 Agent | DEV-A/QA-A | ARCH-A/DEV-A（契约重定义 = 架构裁定面） | DEV-A/ARCH-A（所有权模型消费） | QA-A/REC-A |

**批次 J 排程注**：(1) **48-c 是深审 D4「早期决策点」的兑现位——旗标切换 GO 裁定已在本规划轮落定**（依据：PoC 双门全过 r18（超集 29 + 零误报 + fib : num→num）+ hm-inference-design D8 轨道既定 + 深审 D4 防长期化建议 + 12 §2.5.1 附加类型检查器行「迁移评估」的唯一实质兑现路径）；切换面 = check/check_recover 两入口（driver.rs L563/L626 实锚——**run 路径不触静态面**，爆炸半径有界）。(2) 48-b 先行 48-c：效应臂遍历收敛后 HM 旗标的超集门更完备。(3) 48-d 与 48-b/c 零耦合（ffi-ownership-model §8 排期注）；语言面语法糖 = Stage 3（§8「语言面形式批次 G1/I 定」——IR/VM 面做实即 §21.3 条件 4 兑现，如实注记）。(4) 48-e 收尾对账含 12 §2.5.1 行注记终态复核。(5) TD-003/005/015 排期已改判 Stage 3（本规划轮 §5d）——若批次 J 实施中发现 IrGraph/宏组合消费面则回判并在 worklog 登记。

**J 执行注记（r28 / 49-a）**：48-b ✅ 全交付——typecheck.rs/hm.rs 效应臂子表达式遍历（Perform 效应值 + Handle 两体入检出域；结果类型维持 Unknown/Dynamic——行多态 Stage 3 边界如实）+ 静态负例组 4 测试（6 违例 case 双面检出 + 零误报对照六正例/绑定器动态用点/effect_stress 语料）+ 710:0:0 零回归（净 +4 集成）+ 深审 D3/D8 闭合注记 + pipeline-test-coverage R4 修正（Tier 2 头 463→503——r26 补账声称未落面）；bootstrap_compiler_tests 效应 parity 维持（编译面零改动）。注：会话 Task ID 按 §4.1 唯一性采用 49-x 序列（r28 = 49-a/49-z/49-web）；本表 §5c 概排 49-x 系批次 K 暂定 ID——批次 K 规划轮将按会话递增惯例重新分配（概排非占位实锚）。

**J 执行注记（r29 / 50-a）**：48-c ✅ 全交付——**HM 旗标期切换（D8 阶段 2）**：driver.rs `check_source`/`check_source_recover` 两入口判定面 = `hm_check_program`（R1-R8 退为回归基线断言——hm_inference_tests/effect_tests 双面检出纪律保留；run 路径零接触维持）；**契约重定义显式登记（P0-2 兑现）**——hm-inference-design §2.3 旗标期节（「零类型不一致误报」口径 + occurs/自应用面豁免为接受行为 + 双向锚 static_error_is_runtime_error 范围重锚：超集门内维持/occurs 面豁免）+ §3.7 阶段 2 落地实锚 + **文档 v0.1.0→v0.2.0**；**断言重锚**——typecheck_tests 5 处子串重锚为 HM 渲染措辞（`(int . int)`/`(int . nil)`/`(α0 → α0)`/元数区间——语义/检出/定位不变）+ 头注旗标期口径；**切换实测双缺口当场修复**——① hm.rs Ordering 臂未同步 TD-011 r24 字符串全序（`(< "a" "b")` 误报——PoC 遗留旧口径）② hm.rs car/cdr 臂 `Ty::Nil` 误入保守跳过（`(car nil)` 漏检——超集门缺口）→ 双面漂移归零 + 修复锚测试；**新增旗标期判定面测试组 3 件**（增值面生产证据 + occurs 豁免政策锚 + 双面修复锚——净 +3 集成 → 713:0:0 预期口径）；**12 §2.5.1 类型检查器行迁移评估结论 ✅**（v6.4：HM 旗标期切换落地 + 自举内迁裁定 = 留 Rust——INC8 三段口径（读+展开+编译 100% kerf）+ INC3 静态分析面不在自举关键路径（front_from_core 无 check 实证），归 07 §3.4 Rust 保留面；默认期 = Stage 2 末评估）；typecheck.rs/hm.rs/builtins.rs 头注旗标期角色注记同步。环境注记：沙箱重置后测试线程默认栈不足（深嵌套 case 爆栈——基线 stash 复跑同型归因环境）→ RUST_MIN_STACK=16777216 环境级修复（非代码缺陷——同 r21 工具链重装同型的环境恢复操作）。

**J 执行注记（r30 / 51-a）**：48-d ✅ 全交付——**FFI VM 面做实（§21.3 条件 4 兑现）**：①操作码三指令 43→46（CALL_EXTERNAL/ALLOC_EXTERNAL/FREE_EXTERNAL——04 §1 第十组 + compiler.krf OP-* 表 + 桥三臂三方冻结同步；**语言面形式 Stage 3**，编译臂不发射——plan §5b 排程注 3 如实注记）；②窗口规程（ffi-ownership-model §2.1 步 2-4）：装载边界（char* 实参装箱堆槽 pin Φ[v]+=1 + 令牌校验 Invalid→E0010）→ 宿主调用（VM 挂起——外部零 kerq 分配）→ unpin 配平 → 返回包装（case 6 时序：unpin 先于包装）；③Heap Φ 计数簿（P1/U1/U2——register_foreign_ref 计数化泛化 + supp(Φ) 并入 mark 起点 F-PIN + 持久根并存）；④线性令牌状态机（消费全局生效——Rc 共享 Cell；E0010/E0011/E0012 诊断族落位——18 §6 r18 预留兑现 + messages.rs 单源三构造器）；⑤FfiBoundary 真实实现（driver ffi.rs——P/U 规则经 Heap Φ 簿；冻结签名 U2 经 expect E8 口径承载）+ compile_ffi_call_program（冻结 FfiCall lowering 面——字面量子集 + size=0 编译期拒绝 + FreeExternal 运行时令牌依赖拒绝）+ default_extern_table（write_stdout char* 注册——ExternalType 形状消费面）；⑥正例端到端 = 冻结 FfiCall → lowering → 操作码 → 窗口规程 → kerf_runtime 真实 I/O（CInt 返回字节数）；**ffi_vm_tests 37 case**（13 边界 case 全判定落地映射表 + 正负比 7:22 功能点粒度 ≥1:3 + Φ/P-U 机制组）——**758:0:0 零回归 + 净 45**；TD-026 登记（语言面形式 + CStruct/CFunction/FreeExternal-lowering 收窄——显式拒绝非静默）；回写六面（06 §3 E0-E11 + 05 §3.1 Φ 簿/Foreign 令牌 + 13 §3.3.4 实现锚/§21.3 条件 4 ✅ + 04 §1 十组 46 + 18 §6 落位 + TD 登记册 TD-026）。

**J 执行注记（r31 / 52-a）**：48-e ✅ 全交付——**批次 J 收尾（零代码轮——全流程面交付）**：①§3.2 六命令 clean 起步全量复验（build / check 0/0 / fmt 0 diff / clippy --all-targets --workspace 超集 0 / test --release --workspace **758:0:0 维持**——零断言修改）+ 三审计集 EXIT 0 ×3 + CLI 四路径（fib ⇒ 144 / macros ⇒ 42 / check ok / check 负例 E0005 定位）；②**12 §2.5.1 行注记终态复核 ✅（排程注 4 兑现——v6.5）**：三处终态对账（Effect Handlers 行 48-b 静态收敛面 ✅ 兑现注记（r28/49-a）+ 字节码 VM+GC 行 FFI 所有权 GC 边界注记（r30/51-a Heap Φ 簿——§21.3 条件 4）+ 类型检查器行批次 J 兑现位终态（默认期评估移交批次 K 终门审 §21.5 九信号承载））——其余八行 r27 §5d 处置表已终态无需复改；③rec 树补账（r30 会话遗留：14_r30 补建 + 15_r31 + l 两层更新——未压实区间刷新至 r31 终态）；④对账四面（matrix r31 行零增量维持 / pipeline v0.4.0-r31 / RELEASE_NOTES v0.4.0-r31 / 本注记）+ TD 登记册零事件；⑤52-z 收尾：r31 tar.gz（§19.3 commit-then-package 正序）+ 包内自举验证 + web 同步（kerf-data r31 三节点 + footer + download README r31 节）+ git 双仓库。环境注记：RUST_MIN_STACK=16777216 维持（r29 同型）。

**批间插入注记（r32 / 53-a/53-z——表面现代化设计轮，用户审查指令驱动）**：非 §5b/§5c 批次内 MUV——用户显式指令「实现端不要停留在 Lisp 家族 1970 年代表达（内建函数命名/行为模式/编码习惯/组织思路）」触发的设计先导轮（新语言面/新机制全部先文档后验收纪律）。✅ 全交付：①**审查实测**（全项目扫描）：57 内置名（`?`×18 + `->`×3 + `car`/`cdr` + 扁平前缀 ×15）+ 引导语料自铸 50 个标点名 + 行为模式遗留三件——此前无 owner/映射/TD（「未认领半区」）；②**新设计文件 lang-design/20-surface-conventions.md v1.0**：R1-R6 + B1-B5 + 命名空间层（能力-命名空间对齐）+ 57 项映射表 + 零破坏三批次迁移（v0.5 批次 L / v0.6 批次 M / Stage 3 移除轮——**v0.5-roadmap 预锚落位 §2.10**，K3 交付时直引）；③**原则 33 三方同步**（17 v6.3 / sop §2.2 v12.1 / stage0.md §23.1 v6.2 + §9.6 镜像）+ lang-design 同步轮（00/09/12/18/02）+ **TD-027 登记**（P2——实施 owner 批次 L）；④§3.2 六命令 clean 起步全绿（758:0:0 维持——唯一代码变更 builtins.rs 注释 3→4 对账）+ 三审计集 ×3 + CLI 四路径；⑤53-z：r32 tar.gz + 包内自举 + web 同步 + rec 树 16_r32/l。**与批次 K 的关系**：零接触（K1 门审输入条件不变——批次 J 全绿维持）；K3 的 v0.5-roadmap 行经 12 §2.10 获得表面现代化批次 L 预锚。

**批间插入注记（r33 / 54-a/54-z/54-web——能力架构深度设计轮，用户审查指令驱动第二弹）**：非 §5b/§5c 批次内 MUV——用户对 r32 产物的质量反馈触发（「整体是否需要清晰的能力定位，能力边界，能力职责，能力正交，是否完整设计规划的命名空间，层级关系，权限控制……对原语级别的内容不是简单的重命名（之前存在相关讨论并已经在计划中推进重构设计）……不止是内置和命名方面」+「kerf 不是 lisp 系列也不是 c/rust 系列——限制的是差的设计、规划、理念」）。✅ 全交付（会话 Task 54-x）：①**知识搜索八查询实证**（tool-results/r33-search/——ocap 模型/Pony-Austral 能力安全语言/效应组合性/模块≠命名空间/可见性谱系/Clojure 命名空间组织/库核心-Stdlib 分层/最小 kernel 传统）；②**新设计文件双份**：lang-design/21-capability-architecture.md v1.0（「能力」三义定锚（工程能力/语言能力/授权）+ 语言能力四层 L0-L3 四要素卡 + **正交判据 J1-J4 各配既有实测锚**（r24 装箱/r25 原语集扩张/r8 门控/D10——「正交是已验证的测试属性非口号」）+ 八库能力域四要素 + 域正交单向依赖三规则 D1-D3 + 授权三态（纯度/声明/令牌）+ fail-closed 三红线 + 对齐不变量 A 精确化（修正 20 §5.3「同一语义」过强表述）+ **原语四要素卡 11 张 + 六类迁移分类学 M-R/D/I/L/E/A（「重命名只是最浅一类」——E1-E5 既有裁定载荷的结构重构归档）**+ 新原语准入两判据 + 2026 前沿对照）+ lang-design/22-namespace-design.md v1.0（五层命名层级 N0-N4 + 解析优先序 R-N1 + 遮蔽许可表 R-N2 + 限定名不回落 R-N3 + 导入/别名规则 + prelude 规则化 + 运算符永驻 + 符号宇宙豁免 + 宏卫生/相位交互 + **模块×授权权限矩阵 + import 不传播授权红线** + 冲突三类裁定 + kerf/ 保留域 + 版本化接口位 + 批次 M 实施对账表 12 行——**v0.6 命名空间层实施输入由此齐备**（此前 20 §5 仅方向概要，属「可推迟决策未配接口契约」违例））；③**20-表面规范升 v1.1**（§1.2 失实叙述修正「内部已现代」→「方向已冻结、实施有窗口」+ §5 分工接线（方向概要 vs 机制层）+ §5.3 对齐精确化 + §11 完整性核查 13→18 维）；④**原则 34 三方同步**（17 v6.4 / sop §2.2 v12.2 + 版本历史 / stage0.md §23.1 v6.3 + §9.7 镜像）+ lang-design 同步轮（00 v6.4 文件地图 21→23 / 09 v6.5 / 12 v6.7 批次 M 输入注记 / 18 v6.3 §5b 增 14 术语 / 19 v6.2 §7 增 8 条引用 / 13 v6.2 三义消歧指针）+ **项目级清扫**（builtins.rs 头注 21/22 指针——唯一代码面变更，注释级零语义）；⑤54-z：§3.2 复验 758:0:0 维持 + r33 tar.gz 包内自举 + web 同步 + git + rec 树 17_r33/l。**与批次 K 的关系**：零接触（同 r32 先例——K1 门审输入条件不变）；**对批次 M 的输入改善**：实施设计输入从「20 §5 方向概要」升级为「22 完整机制规范 + 21 架构解释」。

**批间插入注记（r34 / 55-a/55-z/55-web——设计缺陷深度审计收敛轮，用户审查指令驱动第三弹）**：非 §5b/§5c 批次内 MUV——用户对 r33 产物的第三轮质量反馈触发（「检索 docs/lang-design/ 下存在哪些语言设计上的缺陷面：定位/权限/能力边界/职责边界/层级处理和管理模型/演进阶段和时机是否具体和清晰——沿着思路向下、网状发散、内循环迭代直至所有可能性收敛」+「kerf 不是 lisp 系列也不是 c/rust 系列——限制的是差的设计、规划、理念」）。✅ 全交付（会话 Task 55-x）：①**十二审计轴系建立**（用户六轴 + 发散六轴[组合语义/覆盖完备性/一致性/诊断对账/判据先于先例/元编程工具链交互]）+ **第一轮 14 项发现全落位**（F1「L3′」未定义引用/F2 域覆盖三洞/F3 授权组合缺位/F4 编译期权威未裁/F5 演进时机七源散置/F6 治理模型散/F7 计数漂移/F8 非锚定无原则/F9 批次 M 码位未预登记/F10 LSP×命名空间交互未登记/F11 关系表覆盖 4/23/F12 悬空引用/F13 error 归属未裁/F14 批次表无入口触发）；②**新设计文件 23-evolution-governance.md v1.0（设计栈治理层——四层栈补齐）**：演进六窗触发表（K/L/M/E5/T3+ 入口信号 + 出口条件 + 时间治理四红线）+ 变更通道矩阵 + 准入判据总表八类 + 受控债务四步仲裁 + 生命周期四阶段 + 收敛证明（第二轮 0 新 P0/P1 + 残余 7 项全持接口契约）；③**21 升 v1.1**（§2.5 三轴坐标系 L×N×P——「L3′」退役 + L×N 交互矩阵 + `=` 双轴归属 + §3.1 十一域覆盖闭合[57+5 每名有家] + §4.4 授权组合闭包[传递闭包裁定——WASI 同构] + §4.5 编译期权威[Phase 1 零授权面 + 三判据]）；④**22 升 v1.1**（权限矩阵 +2 行：组合闭包 + P1 宏宇宙；§8 实施对账 +2 行）；⑤**原则 35「判据先于先例」三方同步**（17 v6.5 / sop v12.3 / stage0 v6.4 §9.8）+ 同步轮 9 文件（00 v6.5 地图 23→24 + 计数修正 / 09 v6.6 / 10 v6.4 LSP 交互注记 / 12 v6.8 / 18 v6.4 §5c +13 术语 + §6 批次 M 码位预登记 E0013-E0019 / 19 v6.3 §8 +6 引用 / 20 v1.2 四层栈 + §11 +5 维）；⑥55-z：§3.2 六命令 clean 起步全绿（758:0:0 零断言修改——**零代码变更轮**）+ r34 tar.gz 包内自举 + web 同步 + git + rec 树 18_r34/l。**与批次 K 的关系**：零接触（r32/r33 先例延续——K1 门审输入条件不变）；**对批次 K/M 的输入改善**：批次 K 的 K3 收尾可直接消费 23 §2.2 触发表（v0.5-roadmap 的窗口口径单源化）；批次 M 的实施输入再升级（组合闭包 + 码位预登记 + 相位授权三件齐备——「批次 M 只做实现不做设计」的输入闭合）。

**K3 执行注记（r37 / 58-a/58-z/58-web——批次 K 终件 ✅ 全交付 + 58-c r36 收尾中断清偿）**：49-z K3 收尾交付 ✅——用户双指令驱动（「按照 sop.md 继续推进任务」+「同步完整打包项目 tar.gz 并同步完整更新 web page」；会话 Task 58-x 序列：58-c[r36 中断清偿——上会话收尾段中断于 rec 树写入后，以磁盘实况为准 R4 补齐 footer v7.6/download README r36 节/PACKAGE_CONTENTS/worklog 双源 57-z/57-web 条目/kerf 仓 rec 树 commit 9dc8d28 + E2E 双端] + 58-a 本体 + 58-z 打包 + 58-web web 面）。**①§3.2 六命令 clean 起步全绿**：cargo clean（680 files/238.5MiB）→ build --release 13.15s 零告警 → check --workspace 0 errors 0 warnings → fmt --check 0 diff → clippy --all-targets --workspace -- -D warnings 超集 0 → **test --release --workspace 758:0:0 零断言修改（22 套件——集成 543/26.67s + 单元 215）**——零代码收尾轮（唯一代码面变更 = 无）+ **四审计集 EXIT 0 ×4**（stage0 41 + stage1 50 + stage2_r1 53 + stage2_r2 46 = 190 case 全 APPROVED）+ CLI 四路径（run fib ⇒ 75025 ⇒ 144 exit 0 / run macros ⇒ (2 1) ⇒ 42 exit 0 / check ok「2 原型/9 常量/5 全局引用/38 指令」exit 0 / check 负例 E0005「+ 需要数值，实际 str（静态检查）」定位 1:4 **REAL_EXIT 1**）；**②对账六面**：matrix v0.1.0-r37（r37 增量行——零增量维持）/ pipeline v0.4.0-r37（Date 行）/ RELEASE_NOTES r37 节（K3 收尾四交付）/ plan 本注记 + Status 行（批次 K 全闭环 + Stage 2 全收口）/ v0.5-roadmap **v0.2.0 Stage 2 行收口**（批次 G→J→K 全链终态 + Stage 3 GO 注记 + 批次 L/M 入场序列——12 §2.10 预锚「K3 交付时直引」兑现）/ TD 登记册零事件（TD-028 维持 P3 登记——28 项开放 P0/P1 = 0）；**③12 §2.5.1 类型检查器行 K3 终态注记**：r31「默认期评估移交批次 K 终门审」→ **K3 闭环**（K1 P07 九信号核对 + K2 深审 GO + K3 收尾——默认期评估结论：HM 旗标期维持[判定面 = hm_check_program；R1-R8 退为回归基线断言双面检出纪律保留]，默认期切换[hm-inference-design §2.3 旗标期默认期]窗口归 23 §2.2 治理触发表 Stage 3 承载——触发式非时间驱动）；**④58-z 打包**：r37 tar.gz（§19.3 commit-then-package 正序 + §19.4 十二路径）+ 包内自举（全新解包构建 + 758 复跑 + 四审计集 ×4 + CLI 一致）+ rec 树 21_r37/l；**⑤58-web**：kerf-data r37 节点 + footer v7.7 + download README r37 节 + E2E 双端 + git 双仓 clean。**里程碑：批次 K 全闭环（K1 APPROVED 46 case + K2 GO[六件套 + 投票 100% + Stage 3 GO 裁定] + K3 收尾[§3.2 全绿 + 包内自举 + E2E]）→ Stage 2 全收口（v0.4.0 终态：758 测试 + 四审计集 190 case + TD 28 项 P0/P1=0 + 设计栈 24 篇 + sop v12.4 + stage0 v6.5）；下一步 Stage 3 入场序列（批次 L 表面现代化 → 批次 M 命名空间 → 移除轮——23 §2.2 触发表驱动，[20-表面规范](../../lang-design/20-surface-conventions.md) §7 三批次迁移计划承载）**。

**K2 执行注记（r36 / 57-a——批次 K 次件 ✅ 全交付）**：49-b K2 大阶段末深审环 ✅——用户双指令驱动（「按照 sop.md 继续推进任务」+「同步完整打包项目 tar.gz 并同步完整更新 web page」；会话 Task 57-x 序列：57-s1/57-s2 辅助扫描件 + 57-a 主件 + 57-z 收尾 + 57-web）。**§14.6.3 三轮深挖**：第 1 轮事实采集（57-s1 十三项代码扫描[C1-C6/§11/§14.6.1.1] + 57-s2 八文档三方对照[§14.6.1.3/§14.8] + §3.2 基线六命令 clean 起步全绿 build 14.48s/758:0:0 + 四审计集 EXIT 0 ×4 + CLI 四路径 + 性能三重采样）→ 第 2 轮发现即修（**§14.9 P2 注释时效 7 项 + P3 12 项共 19 处注释级修复**[TD-008/TD-003 口径、net-process 触发式、多阶段 DEFER、深度 128→10_000、ext1 激活、capability 窗口终判、vm 值模型、46 操作码、driver 双路径、catch-all 臂注释 ×5、枚举注释 ×2——零行为变更，修复后 build 12.18s/fmt 0/clippy 0/**758:0:0 复验**] + **§14.8 回写四件**[03 v6.3 深度 500→10_000 / 05 v6.3 根集五→六来源 + 八→九入口 / 02 v6.1 Keyword 22→25·叶级 45→48 + §8.1 同核验证 B1-1 改判批次 L/M / 13 v6.3 §3.1.1 Effect r25/r28 终态 + 12 宏行同步]）→ 第 3 轮收敛（零新 P0/P1——R6/R7 收敛判据）。**§14.6 六件套全落位**：deep-review-round2.md（D1-D8 全量三段式 + §14.8 偏差清单[B2 五项回写/B1-1 改判/B4-1 裁定登记册承载/B3 零新项] + §14.9 C1-C6 六维表 + §6.3 投票 **5.5/5.5 = 100% GO**）+ architecture-review.md（八阶段全绿 + §11 七项零违规 + 数据流五段）+ design-impl-test-coverage.md（四方互锚零缺项[46 操作码/57 stdlib/12 变体/12 E 码族/prelude 五件] + B1 净缺口 0）+ hidden-problems-assessment.md（强制修复项 ≥2× = 0 + **Stage 3 就绪度 12/12**）+ refactoring-optimality-review.md（7/7 最优判据零 hack）+ performance-baseline.md（新建 + **TD-028 登记**：fib 92.5ms/gc_tail 42.6ms ~10% 同向漂移三重采样诚实归因[正确性零影响——§14.5.3 D6 条款 Stage 3 优化窗口]）+ final-assessment.md（**Stage 3 切换 GO 裁定**——P0/P1=0 + 四项审查全过 + 输入面闭合 + 投票 100%）+ pipeline-test-coverage.md v0.4.0-r36（§4 完整性 r36 全量重测：catch-all 86 处六分类全合规 + 生产 expect 23 处全消息化 + enum 穷尽性四抽查；§6 性能基线表）。TD-028 新登记（P3 性能漂移——归因候选三面待 Stage 3 profile 定锚）。**下一步：K3 收尾交付**（plan §5c 49-z：§3.2 六命令 + 对账六面 + 12 §2.5.1 终态回写[r31/r35 双重复核维持] + v0.5-roadmap Stage 2 行 + tar.gz + web + git + rec 树压实——K2 GO 已满足其输入条件；57-z/57-web 本轮随同执行打包与 web 面）。

**K1 执行注记（r35 / 56-b——批次 K 首件 ✅ 全交付 + 56-a 同步轮）**：49-a K1 终门审 ✅——用户三指令驱动（「将更新的 docs/lang-design/ 下所有内容同步到 docs/stage0.md 中并反哺 docs/sop.md」+「按 sop.md 继续推进任务」+「同步完整打包 tar.gz 并同步完整更新 web page」；会话 Task 56-x 序列，r35 = 同步轮 + 批次 K 首件双 MUV 合轮）。①**56-a 同步轮（零代码变更）**：stage0.md v6.4 → v6.5（附录 A 增补 33 条设计栈术语[18 §5a/§5b/§5c 全量镜像] + 附录 E 新增 E.9 节[19 §7/§8 共 14 条] + §23.1 标题计数修正[三十二条→三十五条] + §7 三义消歧/§9.3.2 LSP×命名空间/§21.5 时机治理单源三指针注记）+ sop.md v12.3 → v12.4（§8.4.3 目录树 24 文件全列 + §8.4.5 查询表 +4 设计栈落点行 + §16.1 版本历史 + 存档纪律吸收：附录级内容属「同步债」纳入 §8.5 审查）——拆分面→存档面附录级缺口清零；②**56-b K1 终门审全交付**：新审计集第 4 件 examples/audit/stage2_gate_audit_r2.rs 46 case **APPROVED EXIT 0**（与 r1 53 case 零源语料重叠；主轴 = 静态判定面[E0005 HM 旗标生产判定面——r1 零覆盖半区，A 桶 10 + B 桶 10 含 r28 效应臂收敛 + E0006 门控变体 + 多错误非短路] + 批次 J 修复边界 7[r28 双面检出 ×2/r29 TD-011 对偶 + Nil 归零 + 定位面/r30 FFI 编译面收窄 + VM 三码族 E0010/E0011/E0012] + §21.3 四条件终验[P03 fixpoint B₁/B₂ + P04 QBE fib 144 + **P05 FFI 真端到端 write_stdout Int(4)——r30 做实升级** + P06 自编译活性] + §21.5 九信号核对[P07——S1-S7 机械可核进程内实测 + S8 投票协议承载 + S9 K2 承载]）+ **§6.3 五角色投票 5.5/5.5 = 100% GO**（ARCH-A 2/DEV-A 1.5/QA-A 1/ALG-C 1/SKL-A 1 不加权——≥95% 达成）；③56-z：§3.2 六命令 clean 起步全绿（clean 589 files/build 13.11s/check 0/0/fmt 0/clippy 超集 0/**758:0:0 零断言修改**）+ **四审计集 EXIT 0 ×4**（41+50+53+46）+ CLI 四路径（fib 144/macros 42/check ok/E0005 REAL_EXIT 1）+ 对账四面（matrix r35/pipeline v0.4.0-r35/RELEASE_NOTES r35/本注记）+ r35 tar.gz 包内自举 + web 同步 + rec 树 19_r35/l。**下一步：K2 大阶段末深审环**（plan §5c 49-b：§14.5 全量 D1-D8 三段式 + §14.8 B1-B4 + §14.9 C1-C6 + §14.6 阶段间四项 + final-assessment Stage 2 版 + Stage 3 切换 GO/NO-GO 裁定——K1 APPROVED 已满足其输入条件）。

### §5c 批次 K 概排（Stage 2 终批——门审与切换评估，49-x）

| 字段 | 49-a K1：Stage 2 终门审 | 49-b K2：大阶段末深审环 | 49-z K3：收尾交付 |
|---|---|---|---|
| 输入条件 | 批次 J 全绿（48-b/c/d/e 交付） | 49-a APPROVED | 49-b GO |
| 输出物 | stage2_gate_audit_r2（≥30 新 case + 批次 J 修复边界 §7.3.2（效应收敛/HM 旗标/FFI 三修复面）+ §21.3 四条件终验 + **§21.5 九信号全核对**）+ §6.3 投票 | §14.5 大阶段末深审（D1-D8 全量三段式——非批次裁剪版）+ §14.8 B1-B4 + §14.9 C1-C6 + §14.6 阶段间深验证四项 + final-assessment（Stage 2 版）+ **Stage 3 切换 GO/NO-GO 裁定** | §3.2 六命令 + 对账六面 + 12 §2.5.1 终态回写 + v0.5-roadmap Stage 2 行 + tar.gz + web + git + 树压实 |
| 验收标准 | APPROVED + 投票 ≥95% | 四项审查各 ≥1 产出文档 + P0/P1 = 0 维持 | §3.2 全绿 + 包内自举 + E2E |
| 集成验证 | 双审计集 + 全套件 | 深审交叉引用 worklog 全链 | 双审计集 EXIT 0 |
| 责任 Agent | QA-A/REV-A + 全五角色 | ARCH-A/QA-A/REV-A/PM-A/ALG-C | QA-A/REC-A |

### §5d Stage 2 余下面处置表（12-roadmap §2.5.1 逐行落位——本规划轮闭环）

> 处置依据三源：①§21.3 四条件（Stage 2 验收硬面——不含项可重评）；②12 §2.5.1 解读要点原文（「预留长期不做实是允许的——接口预留的成本只有类型维护，没有实现债务」+ §2.1.1 成熟度时间函数——矩阵自述可重评结构）；③深审 D4/B1 实况。**处置动作随本轮回写**（12 §2.5.1 行注记 v6.3 + TD 登记册索引三行改判）。

| 12 §2.5.1 行 | Stage 2 列规划 | 处置 | 依据 |
|---|---|---|---|
| Token 流 + 图 IR | 完全自举 | ✅ 已兑现（r23 三段生产链） | §21.3 条件 1 终验（r26 P 探针） |
| 结构化 CodeValue | 升级（多阶段支持） | 升级面随多阶段同窗 DEFER；Stage 2 实际增量 = continuation 值 + ForeignBox 装箱（r24/r25 已兑现） | 多阶段行依据（下）+ 深审 D5 |
| 元循环求值器 | 不迁移 + 被编译器替换 | ✅ 已兑现终态（r23 INC7） | 12 行既有 v6.2 注记 |
| 基础闭包 | 升级（Effects 引入后语义协调） | ✅ 已兑现（r24 TD-010 装箱 + r25 GC 六来源帧并存协调） | 深审 D5 闭环记录 |
| Effect Handlers | 语言级做实 | ✅ 已兑现（r25 M1-M5）+ 批次 J 48-b 补静态收敛面 | 深审 D3 建议兑现位 |
| 多阶段编程 | 做实引入（实验） | **DEFER Stage 3**（成熟度重评） | §21.3 四条件不含 + 12 §2.1.1 研究前沿档 + Stage 2 零消费场景 + 矩阵自述可重评结构 |
| 能力模型 I/O | 做实引入（完整模型） | 交付面 = 模型层完整（骨架 r19 + 族无关形状 r25 + 手术面 D11 收敛）；**net/process = Stage 3 触发式**（窗口核对结论见下注） | 下注四依据 |
| 宏系统 | 完整化 | E1-β 收口子集已兑现；TD-005 + 调试工具 → **Stage 3 宏增强窗口**（登记册改判） | 在用宏面零缺口（审计集 53 case 宏面全过）+ 深审 D2 维持 |
| 编译缓存 | 深化（增量编译） | 交付面 = 内容寻址 + CompilerKind 分桶（r23 B11）；增量 → **DEFER Stage 3**（工具链成熟窗口） | 单文件编译模型增量收益边际 + §21.3 不含 + fixpoint 确定性已达成（条件 2 不依赖增量） |
| 字节码 VM + GC | 升级（本地码后端并存） | ✅ 已兑现 PoC 口径（r17 + r26 P04 复验）；native 效应化 = TD-024 Stage 3 | TD-024 登记口径（r25 扩界注记） |
| （附加）类型检查器 | 迁移评估（自举内迁） | **批次 J 48-c 兑现位**（HM 旗标期切换 D8 阶段 2 + 自举内迁评估结论随轮登记） | D8 轨道 + 本节 48-c 行 |

**net 门控窗口核对结论（规划轮内闭环——r26「下一步」指针第四主题）**：依赖条件①效应系统就位 ✅（r25 M1-M5）；触发条件②消费面 = Stage 2 全程零 net 语料（审计集 53 case / examples 七件 / 测试矩阵实测——无 net 程序消费面）；条件③沙箱环境网络受限（无真实 socket 端到端可验证面）；手术面 = D11 三点加法已收敛（延迟引入无结构惩罚——接口预留成本仅类型维护）。**裁定：net 增行（枚举 + 门控表 + 族文件）随 Stage 3 首个网络内置需求触发式引入；Stage 2 交付面 = 模型层完整（骨架 + 形状 + 手术面收敛）**——比「无消费面的形式化增行」更优（§12 最优 > 最小：可验证的模型层 > 不可验证的门控行）。process 族同口径（无进程语义消费面）。回写：12 §2.5.1 能力行注记。

**TD 登记册排期改判（本规划轮三行——等级/状态不动，仅目标时机）**：TD-003（Stage 2 → Stage 3 优化窗口——IrGraph CSE 优化类零消费缺口）+ TD-015（Stage 2 切换期 → Stage 3 优化窗口——同型）+ TD-005（Stage 2 后续 → Stage 3 宏增强窗口——在用宏面零缺口）。依据 R6/R7 收敛纪律 + §5d 处置表；批次 J 实施中发现消费面则回判（排程注 5）。

## 6. 量化验收标准（本规划轮）

- 规划文档落位：`docs/develop/v0/stage-2/plan.md`（本文件）+ stage-1/plan.md 补登记（r15 后批次 F 前置注记）
- §21.5 逐项核对表：9 条 × 证据列全填充（上表——7✅ 1⚠️ 1❌ 诚实登记）
- 批次 F 五 MUV 六字段齐全 + Task ID 唯一性（36-x 未与历史冲突）
- worklog 追加（Task 35-x / 36-x）+ 树 `l` 路由行更新
- web：Stage 2 状态行「规划中（§21 阶段规划）」+ 切换信号核对结果对账

---

*遵循条款：§21（阶段规划先行——§21.1 确认/§21.3 验收/§21.5 逐项核对/§21.9 矩阵对账）、§1.2（「进入新阶段」路由全章）、§13.1（设计对齐 10 文档映射）、§17.2（强制扫描 8 项）、§18.1（四项依赖审查）、§4.1（MUV 六字段）、§14.1-§14.6（深审环四协议缺口识别与本计划核心发现）、§8.4.5（决策附条款号）、§2.3-4（显式失败——深审缺口不静默带过）。*

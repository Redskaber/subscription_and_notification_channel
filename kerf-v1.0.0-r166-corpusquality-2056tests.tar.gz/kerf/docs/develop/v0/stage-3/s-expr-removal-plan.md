# S 表达式完全拆除窗计划（S-Expression Complete Removal Plan）

> **Author**: kerf-dev-agent（Super Z main — PM-A 开窗判定 + ARCH-A 时机裁定 + REC-A 落档）
> **Date**: 2026-11-18（v1.4——r153 / 223-a..223-f Batch D 对账更新：§4 排期表 Batch D 行 ✅{用户面拆除——CLI 入口收敛 + reader.ktf 生产路径退役 + 语料 .krf 面清理 + 双入口测试族重构} + §12 Batch D 实施对账节新立{门 D 三判据全绿 + 2049 基线 + 上一会话中途耗尽本会话续作收口注记}；v1.3——r152 / 222-e Batch C 语法段对账更新：§4 排期表 Batch C 行全闭 ✅{词法腿 r151 + 语法段 r152——Reader fixpoint 里程碑收口} + §10 语法段实施对账节新立{转换纪律第四新锚：值位 let 表达式 define → 工厂双侧镜像 + if 臂值位 assign → do 包裹语句化镜像；门 X 全文件 parity + 门 Z fixpoint 自解析} + §11 单一 reader.ktf 终局整合指令新立{用户 r152 指令①登记——E6 端态收敛裁定}；v1.2——r151 / 221-e Batch C 词法腿对账更新：§4 排期表 Batch C 行词法腿 ✅{r151} + §9 词法腿实施对账节新立{转换纪律第三新锚：负整数字面量位双侧同形化 + n 元 and 右嵌套复用 + 多绑定 let 逗号并列复用 + eq/= 映射分工}；v1.1——r150 / 220-e Batch B 对账更新：§4 排期表 Batch B 行 ✅ + §8 Batch B 实施对账节新立{两项转换纪律新锚：r116 第二规范化双侧逐字镜像 + 'nil→quote(()) 字面量化位}；v1.0 首版——r149 / 219-a 开窗轮交付：用户指令①时机授权 + 可行性审计全绿 + 分批计划落档 + Batch A 实施【同轮 219-b】）
> **Status**: **Closed（窗全闭 r154）**（Batch A ✅ r149【§7】；Batch B ✅ r150【§8】；Batch C ✅ 全闭 r151-r152【§9/§10——Reader fixpoint 里程碑收口】；Batch D ✅ r153【用户面拆除——§12】；**E6 ✅ r154【终局清理——§13】——五批六轮全录，退出条件五项全兑现**）
> **处理程度**: P2（设计规范 + 分步验收方案；实施本体分批承载于各轮 worklog）｜ **所属 Stage**: Stage 3 域外清偿链后段（替换进程终局审计节 §8.3 按设计保留面的演进拆除）

---

## 1. 窗口载荷定义（单源 = 用户指令 r149① + 替换面图 v2.0-r148 §8.3 + 07 §3.2.2）

本窗载荷 = **S 表达式从 kerf 项目中完全拆除**——「系统中无 S 表达式痕迹」（07 §3.2.2 消失行的实绩化），用户面与种子面统一收敛于最终目标语言（.ktf）表述。

### 1.1 拆除对象全量枚举（替换面图 §8.3 前两行 + 连带面）

| # | 对象 | 现役角色 | 拆除形 |
|---|---|---|---|
| 1 | 种子链七件 .krf 组件（check/build/cli/test/test_runner/cache/target_reader） | 生产决策面载荷（check = HM 判定面 r80 起生产；构建五面 = TD-032 r74-r90 生产；target_reader = 生产 .ktf 读入桥 r109 起生产） | 逐件转写 .ktf（皮肤字典机械映射）+ 桥装载路径 compile_front_seed → compile_front_seed_target |
| 2 | 用户 S-expr 面（CLI 双入口 .krf 面） | 用户面双语法（r125 双入口窗） | CLI 入口收敛 .ktf 单面（扩展名分派规则翻转） |
| 3 | reader.ktf（S-expr 自举 Reader——B3） | 生产 .krf 用户源读入面（compile_front 读段） | 随对象 2 拆除而退役（E6 删除——平行件策略镜像） |
| 4 | Rust 宿主 S-expr Reader（kerf-reader 经典面 read_source/parse_tokens） | 种子装载 + parity oracle | E6 终批拆除（全 .krf 输入归零后死代码化） |
| 5 | 语料 .krf 对应件（examples/usage 15 对 + effect 语料 .krf 面 + 双面 parity 测试族） | 双面行为等价证据载体 | .krf 面退役（.ktf 单面语料化）+ 测试族重构 |
| 6 | KRF_SOURCES 守卫（bootstrap/mod.rs） | 种子 .krf 语料七件单源守卫 | 翻转为 KTF_SOURCES（守卫对象语言形态切换） |

### 1.2 非拆除面（维持裁定——本窗零触碰）

- **A 类永久基座**（§3.4 九行：VM/运行时/桥/Span/宿主服务/后端/骨架——12 §2.5.1 + 07 §3.2 + 13 §3.1 冻结契约）：Rust 宿主永久在位，**「VM 永久 Rust 基座」宪制条款维持零修订**；
- **Stx 中间层**（宏展开相位必需承载——07 §3.2.2 REC-C 裁定维持：拆除面 = S-expr 语料形态非 Stx 层）；
- **混合自举架构本身**：BS-A 演进 = 种子链**语言形态**从 S-expr 切换为 target（自举策略/种子-生产分工/parity 纪律零变更）；「完全自举 VM 重写 = 宪制排除项」维持（12 §2.19 / 07 §4）。

## 2. 开窗评审（用户指令 r149①——M1 指令开窗第五十四例）

### 2.1 信号与时机判定（六因子）

| # | 因子 | 实测 | 判定 |
|---|---|---|---|
| 1 | 用户信号 | 指令①明文：「在演进中是存在将 S 表达式完全拆除只使用最终目标语言表述的，如果演进节点和任务推进合适时机可完全拆除 S 表达式」——条件授权（时机合适 → 拆除） | ✅ 开窗信号在位 |
| 2 | 竞争任务 | 触发登记册实施项全清零 + 门控任务七项全闭 + 14 行触发族零信号（t3plus v1.68 r148 消费注记）——无更高优先序任务 | ✅ 推荐序首位空缺由本窗承接 |
| 3 | 方法论成熟度 | 切换窗 r106-r120 转换纪律已验证（规范化前置 → 皮肤机械映射 → 三路 parity 门 → fixpoint → E5 收口清理）+ 皮肤字典 14 映射族齐备（20 §14 v1.31） | ✅ 复用面完整 |
| 4 | 可行性审计 | §3 六面实测全绿（七件 .krf 代码面零阻断构造） | ✅ 无语言面前置缺口 |
| 5 | 基线稳定性 | 1916:0:0（r147 起基线，r148 第一轮维持）+ 六命令全绿 + 审计×6 EXIT 0 | ✅ 起步态干净 |
| 6 | 宪制授权 | BS-A「种子链 S-expr Reader 保留」条款的演进修订权 = 用户指令（r149①即该授权）；「VM 永久 Rust 基座」条款不在触碰面 | ✅ 授权链完备 |

**双确认**：ARCH-A GO（时机六因子全过 + 非拆除面裁定 §1.2——宪制条款零触碰边界确认）；PM-A GO（分批结构 §4 与近期窗体量先例【r125-r147 单轮 32 case 纪律】匹配——Batch A 体量 = 构建系统五面 678 行，同轮可承载）。

### 2.2 红线核对

- 红线 3（禁止无信号开窗）：✅ 用户指令① = 信号；
- 红线 4（同窗分步验收）：✅ 分批结构每批独立 parity 门先行（§5）；
- 原则 9（核心冻结）：✅ 零新原语零通道零 VM 变更——纯皮肤/载荷形态切换（8 原语不变性第三十一轮验证随各批维持）；
- 原则 41（脚手架生命周期）：拆除判据 = 自建替代 ≥ 被替换物 × 98%（parity 门族实证）+ 逐个替换可回滚（平行件策略——.krf 原件窗口期内保留为 oracle）。

## 3. 可行性审计（r149 / 219-a 实测——七件 .krf 种子代码面全量扫描）

方法：替换面图 §8.4 六族信号法的种子域延拓（r148 审计对象 = 语料域；本审计对象 = 种子载荷域）。

| # | 审计面 | 实测命令口径 | 结果 |
|---|---|---|---|
| 1 | 下划线符号（命名映射 `_`→`-` 歧义阻断项） | 逐件剔注释行后 `rg '\b[a-zA-Z]\w*_\w+\b'` | **七件代码面全零**（下划线全在注释——Rust 名引用）→ 映射无歧义往返 |
| 2 | 准引用（qq 皮肤字典未登记项） | 逐件剔注释行后 `` rg '`' `` | **代码面全零**（target_reader.krf 仅 2 处字符串字面量内反引号装饰——非 qq）→ 零模板改写需求 |
| 3 | 真实效应用法（perform/handle 值位） | `rg '\(perform[\s)]|\(handle[\s)]'` 逐行核对 | **全零**（命中全为注释与解析器关键字字符串——target_reader 解析目标面 handle/perform 语法 ≠ 使用效应） |
| 4 | bang 后缀变更名（目标面字符集 A-Za-z0-9_ 外） | 逐件剔注释行后 `rg '\b\w+!\b'` | **代码面全零**（r112 规范化先例的前置已被历史轮吸收）→ 零重命名前置 |
| 5 | 核心形式覆盖（皮肤字典 14 族 + 基础族） | 逐件形式普查（define 双形/fn/let/if/cond/and/or/not/do/assign/import/list/cons/quote） | **全覆盖**（cond → if-else 链 + and/or → `&&`/`||` 显式右结合 + `'sym` → `quote(sym)` 调用形——compiler.ktf 头部映射单源 r114 纪律逐条在位） |
| 6 | 装载路径就绪度 | compile_front_seed_target（driver.rs r3284——Rust target Reader + Rust Expander + Rust Compiler） | **在位生产验证**（reader.ktf/expander.ktf/compiler.ktf/preamble.ktf 四件自 r110-r116 起经此路径装载） |

**审计结论**：七件种子的 .krf→.ktf 转换 = **纯皮肤机械映射**，零语言面前置缺口、零语义变更义务——与切换窗步③ 语料批（r109-r116）同型同判据。

## 4. 分批实施计划（体量升序 + 风险隔离——每批单轮交付）

| 批 | 载荷 | 体量 | parity 门（§5） | 排期 |
|---|---|---|---|---|
| **Batch A** | 构建系统五面 .ktf 化（build 148 行/cli 75/test 157/test_runner 163/cache 135） | 678 行 ×5 桥 | 门 A×5（字节码 parity + 桥行为零回归） | **r149 ✅（同轮——§7）** |
| **Batch B** | check.krf → check.ktf（HM 引擎——生产判定面 r80 起） | 1285 行 | 门 B（字节码 parity + hm_krf_path/hm_production_switch 全族零回归 + TC-SIGS 62 行锚维持{r144 口径}） | **r150 ✅（同轮——§8）** |
| **Batch C** | target_reader.krf → target_reader.ktf（**Reader fixpoint 里程碑**——生产 .ktf 读入桥自身目标语言化） | 2979 行 | 门 C（字节码 parity + target_reader_krf_tests 双路门全族 + fixpoint 门【target Reader 读自身】） | **全闭 ✅**：词法腿 r151（1-643 行——§9）+ 语法段 r152（675-2979 行 + 桥语法入口切换 + fixpoint 门收口——§10——r107/r108 先例镜像） |
| **Batch D** | 用户面拆除（CLI .krf 入口收敛 + compile_front/read_source S-expr 生产路径退役 + reader.ktf 退役 + 语料 .krf 面清理 + 双入口测试族重构） | 入口层 + 语料 15 对 + 测试族 | 门 D（CLI 单面零回归 + .krf 拒收 fail-closed 负例族 + 语料 .ktf 单面全绿） | **r153 ✅（同轮——§12）** |
| **E6 收口批** | 终局清理（七件 .krf 平行件删除 + Rust S-expr Reader 拆除 + KRF_SOURCES → KTF_SOURCES 翻转 + compile_front_seed 退役 + 文档终局回写【替换面图 §8.3/§8.6 终态翻转 + 07 BS-A 演进注记 + 12 §2.19 时点对账】） | 拆除批 | 门 E6（原则 41 拆除判据终验：全 .krf 输入归零实证 + fixpoint 门族 + 两路门 + 删除守卫） | **r154 ✅（同轮——§13）** |

**批序依据**：体量升序（风险隔离——最小面首立转换纪律模板）+ 依赖零耦合（七件载荷各自独立桥装载——无批间依赖）；Batch D 置于 C 后（reader.ktf 退役依赖 .krf 生产路径最后消费者确认——check/build 族已 .ktf 化）；E6 收口置末（平行件删除判据 = 全前批 parity 证据累积）。

## 5. parity 门设计（每批先行——红线 4）

复用切换窗三门体系（零新造门——原则 6「通用 > 特例」；i1 §5 / switch_corpus_parity_tests 基础设施）：

| 门 | 判据 | 适用批 |
|---|---|---|
| **门 X（载荷字节码 parity）** | .krf 原件经 compile_front_seed ↔ .ktf 转写件经 compile_front_seed_target：**字节码语义载荷全等**（指令序 + 常量池 + proto 形状 + 全局引用面——debug_spans 跨文本不可比按设计豁免【r106 SyntaxTransitionValidator 纪律】） | A/B/C 每件 |
| **门 Y（桥行为零回归）** | 既有桥级 parity 测试族全绿维持（build/cache/cli/test/test_runner 五族 krf_parity_tests + hm 双族 + target_reader_krf_tests——它们经桥端到端行使生产决策，装载源切换后断言面零变更 = 行为零漂移证据） | A/B/C |
| **门 Z（fixpoint + 两路门）** | .ktf 件经 seed target Reader ↔ 经生产桥（target_reader bridge）双路 Stx/字节码一致 + 自编译 fixpoint（门 B 纪律——§21.3 条件 2） | C（Reader fixpoint 专项）+ E6（终验） |

**平行件策略**：窗口期内 .krf 原件全量保留为 parity oracle（门 X 基线腿）；E6 收口批按原则 41 拆除判据删除（验证职能迁移至 fixpoint 门族 + 两路门 + 删除守卫——r120 先例镜像）。

## 6. 退出条件（窗全闭对账——E6 收口批终验）

1. **输入归零**：仓库内 .krf 文件数 = 0（`rg --files -g '*.krf'` 实测；语料/种子/示例/测试全域）+ CLI 拒收 .krf 扩展名（fail-closed 负例族证据）；
2. **Rust S-expr Reader 拆除**：kerf-reader 经典面（read_source/parse_tokens 族）死代码归零实证 + 编译零告警维持；
3. **parity 证据链**：门 X ×7 + 门 Y 全族 + 门 Z fixpoint 全绿 + E6 删除守卫在位；
4. **文档终局回写**：替换面图 §8.3 前两行翻转（按设计保留 → 已拆除）+ §8.6 终局结论更新 + 07 §3.2.2 消失行实绩化 + BS-A 演进注记 + 12 §2.19 拆除时点对账更新 + 20 §14 皮肤字典种子域行；
5. **门审 + 投票**：≥30 case 门审计集（E6 收口批新增——含本窗各批修复边界 case）+ §6.3 加权 ≥95%。

## 7. Batch A 实施对账（r149 / 219-b 同轮交付）

- **五件转写**：build.ktf/cli.ktf/test.ktf/test_runner.ktf/cache.ktf 新立（皮肤字典机械映射——§3 审计面 5 映射表逐条适用；注释 `;`→`//` 同步转写）；
- **五桥切换**：bootstrap/{build,cli,test,test_runner,cache}.rs 装载行 compile_front_seed → compile_front_seed_target + include_str!/诊断文件名 .krf → .ktf（入口符号查询零变更——命名映射 `_`→`-` 保证 .ktf 标识符 intern 出与 .krf 相同的种子符号）；
- **平行件保留**：五件 .krf 原件保留为门 X 基线腿（KRF_SOURCES 守卫维持七件——E6 翻转）；
- **门 A×5 + 门 Y**：新 parity 门族测试（五面载荷字节码 parity + 32 case 8 正 24 负 1:3——§9.4.3）+ 既有五族桥级 parity 测试零变更全绿；
- **GATE 1**：六命令 clean 起步全绿（test 净 +32 → 1948 基线候选）+ 审计×6 EXIT 0 + CLI 双语法面零回归（.krf 用户面 Batch D 前维持双面零回归义务）。

---

## 8. Batch B 实施对账（r150 / 220-a..220-c 同轮交付）

- **两项转换纪律新锚**（Batch A 皮肤字典之外的增量纪律——后续批次复用）：
  - **r116 第二规范化双侧逐字镜像**：七个关键字符号（'fn/'if/'let/'module/'require/'perform/'handle——13 位点）在目标面不可直写（`quote(fn)` 解析失败 = switch_corpus_parity_tests keyword_tag_normalization_anchors 负锚——KwFn 保留字不可入表达式位），双侧同形化为 FN-TAG..HANDLE-TAG `string-to-symbol` 常量（check.krf 同文件 LT-TRUE/LT-FALSE/LT-NIL 形先例 + expander.ktf LET-TAG..HANDLE-TAG 命名先例）；语义保持 = 同一运行时 Symbol 值（VM eq 按名比较）；双侧同形 → 字节码全等（r116 正锚先例镜像——门 B 严格 parity 的可达性根）；
  - **'nil→quote(()) 字面量化位**：S-expr 面的 `'nil` 在读期被字面量化为 Nil 字面量（编译为 PushNil——r80 修注释登记的 lexer.rs 词法识别 + quote-datum 字面量化机制），目标面的 `nil` 是普通标识符（`quote(nil)` 产出 SymLit 符号常量 PushConst——语义分歧 + 常量池/全局表索引 +1 漂移双根因）；正确映射 = `quote(())`（expander.ktf:1295 先例——目标面 Unit 记号 = Nil 字面量）；check.krf 全部 8 处 `'nil` 位点（tcon-kind-str 比较 + TC-SIGS print/newline/write-string 结果型 + tc-literal-type LT-NIL 臂 + tc-infer-do 空体 + tc-rule-one list 臂 + tc-rule-pair-list）；
- **check.ktf 全量转写**：1285 行 HM 生产判定面——皮肤字典机械映射（cond 69 处→if-else 右递归链 + 'sym→quote(sym) + n 元 or→显式右嵌套 + mod 保留调用形 + do/assign 语句序列化{D42——语句序=求值序} + 多绑定 let 单语句承载 + kebab↔snake）；桥入口符号 lchk-check-program 查询零变更；
- **check.rs 桥切换**：include_str!/CHECK_FILENAME → check.ktf + compile_front_seed → compile_front_seed_target（P1 硬约定维持——Rust target Reader 读入 + expand/compile 种子 Rust）；探针名 production_check_is_krf 历史名保留（Batch A 同律——门 Y 测试面零变更纪律）；
- **平行件策略**：check.krf（规范化 oracle）保留为门 B 基线腿（KRF_SOURCES 守卫维持）；
- **门 B + 门 Y**：seed_ktf_parity_tests 32 → 64 case（8 正 + 24 负 1:3——载荷字节码 parity + 关键字 TAG 双侧规范化锚 + 入口/全局消费面 + 命名回环 + 跨阶段双面 E2E + 生产接线活性 + 负向 24 族{HM 判定拒绝全族——occurs/unify/arity/规则/uncallable/if 条件/sigf 位置/module 体/失败 define/项内多违反/关键字负锚}）+ 既有 hm 三族零变更全绿（hm_production_switch 9 + hm_krf_path 31 + ktf_tc_sigs 32——TC-SIGS 62 行锚维持{r144 口径}）；
- **GATE 1**：六命令 clean 起步全绿（build 22.69s 零告警 + check 0:0 + fmt 零 diff + clippy -D warnings 0 + test 1980:0:0 净 +32）+ 审计×6 EXIT 0{280 case} + CLI 双语法面零回归 + bench 71.735ms{环境侧有利漂移——OBS-C 零信号维持}。

---


## 9. Batch C 词法腿实施对账（r151 / 221-a..221-c 同轮交付）

- **target_reader.ktf 词法段全量转写**（1-643 行——皮肤字典机械映射：cond 20 处→if-else 右递归链 + 多绑定 let 16 处→逗号并列单语句 + define 62 处→fn + 'sym 21 处→quote(sym) + 裸 nil 40 处→() 值位{build.ktf:95-107 先例} + and/or/not→&&/||/! + **高阶函数值传递**{lex_scan_with(scan_number, ...)——compiler.ktf:1430 map(proto_finish) 先例} + 字符串转义集 7 形同构{Rust target Reader 转义臂逐字核对} + kebab↔snake）；
- **转换纪律第三新锚——负整数字面量位双侧同形化**：S-expr 面 -1 读期字面量化（PushConst(Int(-1))）vs 目标面 -1 解析期一元负（(- 1) 全局调用——parse_unary Minus 臂；目标面无负数字面量语法）→ **三侧同形化**（target_reader.krf 全件 list-pos 的 -1 → (- 1) + 提取件同步 + .ktf 侧 -1）——r150 TAG 规范化先例镜像（双侧同形 → 字节码全等）；
- **三项既有纪律的精确化复用**：①n 元 and 右嵌套（平铺三元/四元/六元 and 共 7 位点 → 右嵌套——S-expr and 宏右递归展开同构）；②多绑定 let 逗号并列（平铺多绑定 ↔ let a = e1, b = e2; 单语句；嵌套单绑定 ↔ 顺序语句）；③eq/= 映射分工（(eq a b) 通用相等 → eq(a, b) 函数调用形；(= a b) 数值 → == 运算符——首跑 16 败根因：== 对字符串报 requires a number）；
- **target_reader_lex.krf 新立**（1-643 行提取 + 一处规范化位点声明——门 C 词法腿 parity oracle；E6 收口批删除）；
- **桥双状态改造**（target_reader.rs）：TARGET_READER_LEX thread_local 新状态（include_str! target_reader.ktf + compile_front_seed_target 装载——**Reader fixpoint 里程碑第一腿**）+ load_reader_program 共享装载脊柱（face 参数分派——expand/compile 维持种子 Rust P1 硬约定）+ lex_target_for_bootstrap 切换至新状态 + read_target_source_for_bootstrap 维持 .krf 全件（r152 收敛——双状态隔离零既有行为变更）；
- **门 C 词法腿 + 门 Y**：seed_ktf_parity_tests 64 → 96 case（8 正 + 24 负 1:3——载荷字节码 parity{提取 oracle ↔ 转写件} + 入口面{global_refs 承载 lex-target} + 内建消费面{十内建} + 字符集常数面{十表} + 命名映射回环 + 生产活性{dump_tokens_target} + 双跑确定性 + Token 快照锚 + 负向 24 族{词法 12 + 文法 5 + 深度帽 2{块族 300 层经 Rust 种子直击 + S-expr datum 帽双侧 parity} + 关键字操作数位 1 + 多字节 Span 1}）+ 既有 target_reader_krf_tests 32 case **零变更**全绿{词法 16 族断言面自动升级为 .ktf 路径 ↔ Rust 种子——行为零漂移证据；语法 16 族维持 .krf 路径}；
- **GATE 1**：六命令 clean 起步全绿（build 22.64s 零告警 + check 0:0 + fmt 零 diff + clippy -D warnings 0 + test 2012:0:0 净 +32）+ 审计族全绿 + CLI 双语法面零回归 + bench 71.909/72.358/72.338ms 带内{OBS-C 零信号维持}。内循环修正 3 轮。

---

*遵循条款：用户 r149 指令①（时机授权——开窗驱动源）/ 替换面图 v2.0-r148 §8.3/§8.4/§8.6（按设计保留面 = 本窗正对象；六族信号法 = §3 审计方法单源）/ 07 §3.2.1 五步流程 + §3.2.2 拆除边界（消失行实绩化载体）/ 12 §2.19（拆除时点对账——本窗为其 Batch A 兑现锚）/ 17 原则 6（三门复用）/ 原则 9（核心冻结——零机制变更）/ 原则 31（皮肤/骨架同构——门 X 判据）/ 原则 41（脚手架拆除——判据 + 平行件 + 逐个替换）/ 原则 26（成熟度匹配——体量升序批结构）/ §2.3 红线 3/4（信号开窗 + 分步验收）/ §3.2（六命令）/ §5.3（八项内循环）/ §7.3（门审）/ §9.4.3（1:3 配比）/ §8.4.5/§8.4.6（裁定附条款 + 产物落位 stage-3/）/ §8.6（worklog 三链）/ §19（打包三验）/ §20.3（同类路径全量审查——七件同型转换纪律统一）。*

## 10. Batch C 语法段实施对账（r152 / 222-a..222-c 同轮交付）

- **target_reader.ktf 语法段全量转写**（675-2984 行约 156 define → 4230 行全件——皮肤字典机械映射：cond→if-else 右递归 + 深嵌套 let 穿线{多绑定→逗号并列单语句 D61 + 嵌套单绑定→顺序语句} + 'sym→quote(sym) + 裸 nil→() + n 元 and/or 右嵌套 + eq/= 分工 + (= a b)→== + (- 1)→-1{r151 第三锚复用} + do/多表达式体→语句序列{D42 块穿线同构} + 闭包表达式 (fn (op v) body)→||(op: T, v: T){body}{closures 语料对先例} + assign 语句位 + kebab↔snake；六块子代理并行转写 c1-c6——156 define 全转 0 UNMAPPED）；
- **转换纪律第四新锚——两新面**：
  - **值位 let 表达式 define → 工厂函数 + define 调用双侧镜像**：kcell（r133 闭包胞）的 `(define kcell (let ((cell nil)) (fn ...)))` 在目标面不可表达（无 let 表达式），oracle 同轮规范化为 kcell-make 工厂形 + `(define kcell (kcell-make))`——closures.krf make-counter 捕获惯用先例，语义同一（工厂装载期执行一次，胞创建一次）；
  - **if 臂值位 assign → do 包裹语句化双侧镜像**：.krf 侧 `(assign cell v)` → `(do (assign cell v) nil)`，目标面 `{ cell = v; }` 语句块穿线产出 `(do assign unit)` 形——双侧同形 → 字节码全等；
- **桥语法入口切换**（target_reader.rs）：read_target_source_for_bootstrap 装载 .krf→.ktf（compile_front_seed_target——**Reader fixpoint 里程碑收口**：生产 .ktf 读桥的词法器+解析器俱以目标语言表述，经种子 target Reader 读入运行于 VM）；
- **桥双状态收敛**：r151 词法腿的 TARGET_READER_LEX 临时态退役——lex-target 与 parse-target 双入口共享单一 thread_local 状态（用户 r152 指令①的 Rust 端整合腿——见 §11）+ driver.rs 陈旧文档注记修正五处；
- **门 C 语法段 + 门 Y + 门 Z**：seed_ktf_parity_tests 96 → 128 case（8 正 + 24 负 1:3——**门 X 全文件字节码 parity**{target_reader.krf 全件 oracle{含 kcell 规范化} ↔ target_reader.ktf 全件：指令序/常量池/proto 形状/全局引用面全等；r151 词法腿抽取基测试重定基为全文件形——target_reader_lex.krf 被超越，维持 E6 删除} + 载荷形状锚{209 protos/488 consts/240 globals 双侧} + **门 Z fixpoint**{fixpoint_self_parse_stx_parity——生产读桥解析 target_reader.ktf 自身源文 ↔ Rust 种子：正典 Stx 渲染逐项字节级全等} + 语法入口面{kcell 工厂面 + 语法命名回环 28 名 + 语法内建消费面} + 解析双跑确定性 + 解析快照锚 + 负向 24 族{语法段全声明族 fail-closed——各断言具名诊断族}）+ 既有 target_reader_krf_tests 32 case 零变更全绿{语法 16 族断言面自动升级 .ktf 路径——行为零漂移 + 1712 既有测试全量经新解析器零回归}；
- **GATE 1**：六命令 clean 起步全绿（build 23.01s 零告警 + check 0:0 + fmt 零 diff + clippy -D warnings 0 + test 2044:0:0 净 +32）+ 审计×6 EXIT 0{280 case} + CLI 双语法面零回归十二路径 + bench 75.2-76.0ms 带内。内循环修正 2 轮（parse-typed-params 的 eq 误映射 == 单点{门 X 指令级定位 proto 129 LoadGlobal 123≠129} + 解析快照锚校准）。

## 11. 单一 reader.ktf 终局整合指令（用户 r152 指令①登记——E6 端态收敛裁定）

用户 r152 指令①明文：「审查 kerf-driver/bootstrap/reader.ktf、target_reader* 文件相关，移除重复项或整合为单一 reader.ktf，同理在 rust 端同步整合管理」。审查裁定与整合分账：

- **审查结论**（本轮 222-b 实况盘点）：bootstrap/ 目录的 reader.ktf{S-expr 自举 Reader B3}与 target_reader.ktf{目标语言 Reader}**非重复项**——二者是拆除窗过渡期的双 Reader 并存形态（BS-A 宪制下的合法态）；target_reader.krf / target_reader_lex.krf 为窗口期 parity oracle（原则 41 平行件策略，E6 删除）。整合 = 拆除窗的**终局步骤**而非当轮可一步动作：reader.ktf 的退役依赖 Batch D（CLI .krf 入口收敛——最后消费者确认）；
- **本轮已兑现的整合腿（Rust 端）**：桥双状态收敛——r151 词法腿的 TARGET_READER_LEX 临时态退役，lex-target / parse-target 双入口共享单一 thread_local 状态与单一装载程序（target_reader.rs 简化——「同步整合管理」的可即行部分）；
- **E6 终局整合指令（登记——本节即该指令的单源）**：reader.ktf{S-expr Reader}于 Batch D 退役后，**target_reader.ktf 更名收敛为唯一 reader.ktf**（自举目录内单一 Reader 文件——「移除重复项或整合为单一 reader.ktf」的端态实现）；Rust 端同步收敛：kerf-reader 的 S-expr 经典面{read_source/parse_tokens}死代码化后拆除，target.rs 成为唯一 Reader 实现（归一命名与模块组织随 E6 文档终局回写一并裁定）；
- **判据纪律**：整合时点 = E6 拆除判据满足时（全 .krf 输入归零 + 门 Z fixpoint 族全绿 + 删除守卫在位）；提前整合 = 红线 3 违例（零信号不开窗——Batch D 前双 Reader 仍是生产依赖）。

*遵循条款（r152 增补）：用户 r152 指令①（整合指令——§11 单源）/ §2.3 红线 3（提前整合违例判据）/ 原则 41（整合时点 = 拆除判据纪律）。*

## 12. Batch D 实施对账（r153 / 223-a..223-f 同轮交付——上一会话实施中途上下文耗尽、本会话续作收口）

- **CLI 入口收敛 .ktf 单面**（对象 2「扩展名分派规则翻转」）：main.rs is_target_syntax 分派语义翻转——精确 `.ktf` = 唯一生产入口，其余一切（.krf 真实/不存在/无扩展/未知扩展/大写 .KTF）经 reject_retired_syntax fail-closed 拒收{exit 2 + 结构化退役诊断命名 r153/Batch D 基准——拒收先于文件读取于分派层}；run/bench/anf/native/check/tokens/stx/test 全子命令收敛 target 单面；S-expr driver API（run_source/compile_source 等）自生产面退役（余消费者 = parity oracle 测试族——E6 删除）；usage 文本单面声明；
- **reader.ktf 生产路径退役**（对象 3）：bootstrap/mod.rs + driver.rs 退役注记落位（oracle-of-record duty 单一化；E6 后 target_reader.ktf → reader.ktf 单一收敛——§11 指令维持）；
- **语料 .krf 面清理**（对象 5）：usage 15 对 .krf 面全量删除（仓库余 .krf = 8 件：七件种子平行件 oracle + target_reader_lex.krf——俱 E6 删除对象）+ examples/README v0.2.0 单面化；
- **双入口测试族重构**（门 D 载体）：cli_dual_entry_tests 530 行 22 case 删除 → cli_entry_convergence_tests 655 行 27 case 新立{四验证面：跨语法行为等价 + CLI 边界收敛子进程实测 + 驱动 API 正交 + fail-closed 负例族 + 缓存裁定锚}；十四测试族内联语料归档改写{「retired corpus archived inline」注记纪律}；
- **门 D 三判据全绿**：CLI 单面零回归{十二路径 + bench 75.107ms 带内} + .krf 拒收 fail-closed{EXIT 2 五路径} + 语料 .ktf 单面全绿{1712 既有测试零回归}；
- **GATE 1**：六命令 clean 起步全绿（test 2049:0:0 净 +5——cli_entry_convergence 27 新立 − cli_dual_entry 22 删除；299 单元 + 1750 集成）+ 审计×6 EXIT 0；内循环修正 3 处（clippy doc 缩进 12 + needless_borrow 1 + effect_stress 内联归档闭括号转写笔误 1——git 对账定位）。

*遵循条款（r153 增补）：用户 r153 指令①②（实现窗推荐序——§4 Batch D 承接）/ 原则 9（核心冻结——纯入口层切换零机制变更）/ 原则 27（加性演进的中点翻转——双入口期正式终）/ 原则 31（跨语法行为等价 oracle 纪律）/ 原则 41（拆除判据——语料 .krf 删除于门 D 证据链全量后）/ §2.3 红线 4（分步验收——门 D 先行）/ §9.4.3（1:3 配比尽力——27 case 中 8 正 19 负 1:2.4{子进程负例族扩充受 CLI 边界面自然限制——worklog 申报}）。*

## 13. E6 收口批实施对账（r154 / 224-a..224-f 同轮交付——恢复轮续作）

- **终局文件操作**：reader.ktf（S-expr Reader B3）退役删除 + target_reader.ktf → reader.ktf 更名（§11 终局整合指令兑现——自举目录唯一 Reader 文件；Rust 端 target.rs 唯一 Reader 实现同步收敛）+ 8 件 .krf 删除（七种子平行件 + target_reader_lex.krf）——仓库 .krf = 0 实证（退出条件 1）；
- **Rust S-expr 经典面拆除**（退出条件 2）：lexer.rs/parser.rs/token.rs 删除 + lib.rs 重写（ReadError 归一）+ 编译零告警维持；
- **S-expr API 族 13 退役**：driver.rs 全族 + validator.rs（职责完结）+ bootstrap/mod.rs S-expr 读桥 + KRF_SOURCES 删除/KTF_SOURCES 扩全 10 件 + E6 域内删除守卫；
- **§20.3 同类路径审查新发现面**：DERIVED_SOURCES 七糖内联 S-expr 宏定义文本（经典 Reader 最后活生产消费者——经 lexp-init-derived 注入 VM 自举 expander；未入 §3 审计枚举{内联 Rust 字符串非 .krf 文件}）→ 程序化 Stx 构建转化（词法分类保真实证：bare true/false/nil = Bool/Nil 字面量——git 历史查证）；
- **门 E6**（退出条件 3）：fixpoint 门族 + 两路门 + 删除守卫全绿（1788:0:0 内含）；跨表 oracle 名归一化比较（switch_corpus 双 oracle——Symbol id 跨表漂移合法性的名稳定锚）；
- **GATE 1**：六命令 clean 起步全绿（test 1788:0:0 净 -261 拆除轮合法收缩——8 退役族删除 + ~50 族语料转换{零删为常态} + 审计×6 转换俱 EXIT 0）+ CLI 零回归 + bench 77.308ms 带内；
- **文档终局回写**（退出条件 4）：本版 v1.5 + 替换面图 §8.3 终态翻转 + 07 §3.2.2 消失行实绩化 + BS-A 演进注记 + 12 §2.19 拆除时点对账 + 20 §14 种子域行 + matrix r154 行/总量 1788 + RELEASE r154 节 + README + t3plus v1.74 + tech-debt-register 新登（cache 管线富面休眠——触发式）；
- **门审 + 投票**（退出条件 5）：审计×6 真实 EXIT 0 ×6（每件 41-53 case 七类全覆盖）+ §6.3 收口笔投票。

*遵循条款（r154 增补）：原则 41（拆除判据终验——平行件删除于证据链全量后）/ §2.3 红线 4（分步验收——门 E6）/ §20.3（同类路径全量审查——DERIVED_SOURCES 新发现面清偿）/ §20.6（诚实验收——拆除轮 -261 逐笔记因）/ §9.4.3（1:3 配比——转换族维持）。*

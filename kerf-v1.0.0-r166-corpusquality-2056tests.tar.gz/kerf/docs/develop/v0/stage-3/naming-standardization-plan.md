# 命名标准化窗方案（Naming Standardization Plan）

> **Version**: v1.0（r155 / 225-a 开窗批）
> **Author**: Super Z main — ARCH-A 裁定 + DEV-A 实施 + REC-A 落档
> **Date**: 2026-11-20
> **Status**: Closed（Batch 1 = r155：生产面 Tier 1+2 全量；Batch 2 = r156：残响面清偿——TD-035 行权承载 legacy-residue-clearance-plan.md v1.0）

---

## 0. 开窗依据与背景

- **M1 用户指令开窗第六十例**（用户四链指令之①：「审查全项目的文件、组织结构、数据类型、api 接口等内容的命名是否精确标准（标准化处理，如 kerf_driver/src/bootstrap/target_reader.rs 直接命名为 reader.rs 难道不好？）」——用户明示命名对称收敛方向）。
- **前置完成态**：r154 E6 收口批全闭——S-expr 完全拆除窗终局（仓库 .krf = 0 + reader.ktf 唯一自举 Reader + target.rs 唯一 Rust Reader 实现 + `TargetReadError` 别名退役——r154 原话「one face, one name」）。
- **命名矛盾实证**：S-expr 面退役后，「target」限定词在全部生产命名中失去辨义对象（双语法共存期它区分 S-expr 面与目标面；E6 后仅余单面——限定词从「辨义必需」退化为「旧时代残留」）。r154 已对 `TargetReadError` 执行同一裁定（别名退役、归一 THE face），本窗将该裁定推广至文件名、模块名、类型名、API 名全域——**「one face, one name」轨迹的完成步**。
- **触发表核对**：14 行触发族零变化（纯重命名轮零机制变更零新原语零通道）；t3plus 登记册触发式实施项维持全清零——本窗不与任何已登记触发窗竞争。

## 1. 不变量（本窗硬边界）

1. **零行为变更**：纯标识符/文件重命名——零语义变更、零机制变更、零新原语、零通道（8 原语不变性第三十七轮）。
2. **零诊断文本变更**：CLI 退役诊断/编译器错误消息文本逐字节保持（消息文本是测试断言锚——改动即行为变更，违反不变量 1；消息文本中的时代术语另立 Tier 3 触发式登记）。
3. **测试计数零变化**：1788:0:0 逐位保持（纯重命名不改测试数量与极性构成）。
4. **字节码自洽**：reader.ktf 符号重命名（`lex_target`→`lex` 等）引起源变化 → 重编译 → fixpoint 门族（B₁/B₂ 同源重编译逐件 bytecode_equal + SHA-256 一致）自洽通过——自举链活性探针（sq(7)=49 类）继续全绿。
5. **git mv 保史**：文件重命名一律 `git mv`（历史可追溯；rename detection 全量保持）。

## 2. 重命名裁定（D1-D8）

### D1 — 文件重命名对（bootstrap 对称收敛）

| 旧 | 新 | 依据 |
|---|---|---|
| `crates/kerf-reader/src/target.rs` | `crates/kerf-reader/src/reader.rs` | 唯一 Reader 实现（E6 后）——crate 名 kerf-reader + 模块名 reader 精确自洽；「target」限定词失去辨义对象 |
| `crates/kerf-driver/src/bootstrap/target_reader.rs` | `crates/kerf-driver/src/bootstrap/reader.rs` | **用户明示**：与 `reader.ktf`（r154 §11 终局更名产物）恢复 X.kf/X.rs 对称——bootstrap 目录其余八对（build/cache/check/cli/compiler/expander/test/test_runner）俱对称，唯本件破缺 |

### D2 — kerf-reader API 面（模块 + 函数）

| 旧 | 新 | 语义 |
|---|---|---|
| `pub mod target` | `pub mod reader` | D1 联动 |
| `read_target_source` | `read_source` | 唯一读入口（S-expr `read_source` 已于 r154 退役——名位空出，归一承接） |
| `read_target_source_for_bootstrap` | `read_source_for_bootstrap` | 自举加载读入口 |
| `lex_target_for_parity` | `lex_for_parity` | parity oracle 词法腿 |
| `target_symbol_name` | `symbol_name` | 符号名映射（`_`→`-`） |
| `TargetParser`（类型） | `Parser` | 唯一解析器 |

### D3 — kerf-driver API 面（driver.rs）

| 旧 | 新 | 语义 |
|---|---|---|
| `compile_source_target` | `compile_source` | 全链编译 |
| `compile_front_target` | `compile_front` | 前端编译（读+展开） |
| `compile_front_seed_target` | `compile_front_seed` | 种子前端编译（S-expr 旧名已退役——名位承接） |
| `check_source_target_recover` | `check_source_recover` | 唯一 check 入口（含恢复面） |
| `run_source_target` | `run_source` | 运行入口 |
| `run_source_seed_target` | `run_source_seed` | 种子运行入口 |
| `dump_tokens_target` / `dump_stx_target` | `dump_tokens` / `dump_stx` | CLI dump 面 |

### D4 — bootstrap 桥面（target_reader.rs → reader.rs + reader.ktf 协同）

| 旧 | 新 | 语义 |
|---|---|---|
| `pub mod target_reader`（bootstrap/mod.rs） | `pub mod reader` | D1 联动 |
| `TargetReaderState`（类型） | `ReaderState` | 桥状态 |
| `load_target_reader` / `with_target_reader` | `load_reader` / `with_reader` | 桥装载/闭包助手 |
| `lex_target_for_bootstrap` | `lex_for_bootstrap` | 桥词法入口 |
| reader.ktf `fn lex_target` / `fn parse_target` | `fn lex` / `fn parse` | 自举 Reader 双入口（符号 `lex-target`/`parse-target` → `lex`/`parse`——Rust 侧 intern 字符串四处同步） |

### D5 — CLI 面（main.rs）

| 旧 | 新 | 语义 |
|---|---|---|
| `is_target_syntax` | `is_ktf_path` | .ktf 扩展名判定（r153 收敛后唯一生产入口谓词——名从「语法时代辨义」转「文件形态辨义」） |

### D6 — 活性探针面（driver.rs 线程局部 + 谓词）

| 旧 | 新 | 语义 |
|---|---|---|
| `production_prelude_is_target_reader` | `production_prelude_is_ktf_reader` | r109 活性探针：生产 prelude 注入走 .ktf 桥 |
| `seed_prelude_is_target_reader` | `seed_prelude_is_seed_reader` | 对偶：种子路径走 Rust 种子 Reader |
| `PRELUDE_BRIDGE_TARGET_READS` / `PRELUDE_SEED_TARGET_READS` | `PRELUDE_BRIDGE_READS` / `PRELUDE_SEED_READS` | 线程局部计数器（去冗余限定） |

### D7 — test_runner 面

| 旧 | 新 | 语义 |
|---|---|---|
| `run_target` | `run_test_case` | 测试运行入口（`test_runner::run_test_case` 无歧义；避免裸 `run` 与调用位 `run_source` 族混淆） |

### D8 — 保留面（KEEP——非语法时代语义或 Tier 3 触发式）

**非语法时代语义（永久保留）**：
- `TargetTriple` / `supported_targets`（codegen 编译目标三元组——现代通行术语）
- `collect_import_targets`（import 目标模块——目标=对象语义）
- `qbe_backend_target_gate_and_module`（codegen 目标门）
- Cargo `target/` 构建目录、`--target` 类 flag（如有）
- RELEASE_NOTES / worklog / 历史文档中的历史性「target-syntax」表述（历史记录不可改写——§8.6 只追加纪律）

**Tier 3 触发式（Batch 2 候选——登记不实施）**：
- 测试局部助手/用例名中的 target 限定（`target_err`/`hm_target`/`neg_target_*`/`target_value`/`assert_target_reader_*` 等约 60 处）：纯装饰性、无 API 耦合；历史可溯值（名称记录 r153 收敛语义如 `sexpr_source_in_target_entry_rejected`）；触发判据 = 用户指令或下一轮触_review 信号。
- 诊断消息文本中的时代术语（如退役诊断中的「target syntax」表述）：文本 = 断言锚，改动即行为变更——触发判据 = 专门的消息文本现代化窗（须携测试锚同步批）。

## 3. 波及面量化（2025 实测 grep）

- `read_target_source`：205 使用点；`*_source_target` 族（run/compile/check/front）：986 行；`target_reader` 模块引用：110 处；`kerf_reader::target` 模块路径：14 处。合计约 1315 机械替换点（词边界精确 sed，序敏感：长名先短名后）。
- 文件 git mv ×2；reader.ktf 符号耦合 4 处 intern 字符串 + 2 处 fn 定义 + 内部调用点。

## 4. 批次划分（推荐序）

| Batch | 内容 | 验收 |
|---|---|---|
| 1（r155 本轮） | D1-D7 生产面全量（crates/ src/ + 全域消费点 tests/ examples/） | GATE 1 六命令 + 审计×6 + CLI 零回归 + 生产面残留 grep 归零 |
| 2（触发式） | Tier 3 测试局部名 + 消息文本现代化 | 触发判据见 D8 |

## 5. 验收（量化）

1. §3.2 六命令 clean 起步全绿：`cargo build --release` 零告警 + `cargo check --all-targets` 0:0 + `cargo fmt --check` 零 diff + `cargo clippy --release --all-targets -- -D warnings` 零告警 + `cargo test --release`（RUST_MIN_STACK=33554432）**1788:0:0 逐位保持**；
2. 审计×6 真实 EXIT 0 ×6（六件 stage0/1/2r1/2r2/3m3/3e5close 俱纯 API 消费点机械跟随）；
3. CLI 零回归：`kerf run fib.ktf` ⇒ 75025 / `kerf run --bench` 带内 / `kerf check` ok / `.krf` 拒收 exit 2 / `kerf tokens` / `kerf test` PASS；
4. 生产面残留归零：`grep -rEn "read_target_source|_source_target|target_reader|mod target[^_a-z]|TargetParser|TargetReaderState|is_target_syntax"` 在 crates/ src/ 归零（tests/ examples/ 的 Tier 3 保留清单除外）；
5. fixpoint 自举链活性：编译产物 bytecode_equal + SHA-256 自洽（既有门族承载）+ 活性探针全绿。

## 6. 风险与回滚

- **符号耦合风险**（reader.ktf `lex`/`parse` ↔ Rust intern 字符串）：锁步变更 + fixpoint 门族即时捕获失配（符号查找失败 = 即时错误）；风险面小（4 处 intern + 2 处定义）。
- **重命名序风险**（前缀包含：`run_source_seed_target` ⊃ `run_source_target`）：长名先替换的严格序 + 每步 `cargo check` 闭环。
- **回滚**：单窗单 commit（§6.4）——整体可回退；git mv 保史。

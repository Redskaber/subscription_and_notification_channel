# TD-002 向量值类型窗（vector value type + 集合字面量——门控任务 #5 清偿）

> **Author**: kerf-dev-agent（Super Z main — ARCH-A 裁定 + DEV-A 实施）
> **Date**: 2026-11-10
> **Version**: v1.0（r138 / 208-b 设计先行腿——首件）
> **Status**: Active（设计单源——本文件 §2 为 02-syntax-model §8.13.1b v7.22 产生式族的 vector 增补锚；值模型收窄边界以本文件 §7 定稿域为据）
> **处理程度**: P0（窗交付 = 双面字面量 + 双侧脱糖 + 值模型/HeapObj/GC + 五内建 + 32 case 门 + 语料对）
> **开窗依据**: 用户 r138 指令②「继续推进 目标语言设计的实现窗，如果中途遇着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施」行权（M1 指令开窗第四十三例）；推荐序裁定 = r137 收口后登记册触发式实施项维持全清零{行②③④语料门控} + 六族语料信号实测全零 → 速查卡第 5 位 T3+ 14 行臂序走查 → **TD-002 = 唯一可行实施项**：①target-language-gated-tasks 门控任务 #5 = 七项中**唯一未完成项**（用户指令「未完成窗口直接推进」直接命中——r122-r124 match 即门控任务 #6 同形态先例）；②t3plus 审计行 14 自荐路径「推荐经门控任务 #5 路径——目标语法自然携带集合字面量」；③判据②「目标语法轮开窗联动」——指令点名续行目标语言设计实现轮链 = 轮联动臂命中；④成熟度全在位（S-expr 词法 StxDatum::Vector ✅ + target LBracket 域外诊断位 ✅ + expander 拒绝位双侧定位 ✅ + 值模型扩展先例族 Symbol r5 / Foreign TD-010 / Match r122 / HandleGroup r136）
> **上游单源**: [13 §3.3.4](../../../lang-design/13-capability-matrix.md)（能力矩阵——值模型登记行）+ [05 §3.1](../../../lang-design/05-runtime.md)（HeapObj 域）+ [12 §2.4.1](../../../lang-design/12-roadmap.md)（分阶段语法策略 + Stage 2+ 多语法蓝图）+ [02 §6](../../../lang-design/02-syntax-model.md)（Reader datum 族——列表/向量/字面量/引号简写）+ [target-language-gated-tasks](./target-language-gated-tasks.md)（门控任务 #5）+ [t3plus-trigger-audit §2 行 14](./t3plus-trigger-audit.md) + [TD 登记册 v0.4.16](../tech-debt-register.md)（TD-002 行）
> **红线合规**: 红线 3（禁止无信号开窗）——用户指令臂命中 + 门控任务 #5 清偿路径（r74 先例「指令即需求信号本体」；r122 match 同族先例）；红线 4（禁止窗口合并）——本窗单一切口（TD-002 向量值类型——不与 FFI 行②③④/索引语法/可变向量合并）；原则 9（CoreExpr 九原语核心冻结——D2 全脱糖路径零触碰）；原则 27（加性——零 vector 程序行为逐位不变）

---

## 1. 问题陈述与窗口范围

**TD-002 登记原文（登记册 v0.4.16）**：「quote 符号/向量值类型缺失——符号部分 r5 已解决；向量开放 = T3+ 触发式三判据（①语料 vector 字面量消费 ②目标语法轮联动[12 §2.4.1 集合字面量蓝图位] ③FFI 编组消费——与 TD-026 判据 2 同源）；三判据零命中维持」。

**现状实证（208-b 探针——代码实读五处）**：
- 词法/语法面：S-expr Reader `#(...)` → `StxDatum::Vector` **完整在位**（parser.rs:213——括号平衡 datum 结构化，02 §6 既有蓝图）；target Reader `Tk::LBracket` 在 primary 位为**域外诊断占位**（target.rs:2924「索引（集合类型域外）」——postfix 位；primary 位 bump 兜底「期望表达式」）；
- 展开面：种子 expander.rs:297「向量不能出现在表达式位置（仅用于绑定组/模式）」+ core_forms.rs:829「quote 向量暂不支持（Vector 值类型推迟，后续阶段）」两处显式拒绝；自举 expander.ktf:3464（表达式位）+ :1808（quote 位）+ :2975（match 模式位——match-design §1 域外维持）三处镜像拒绝；
- 值模型：`Value`/`HeapObj` 无 Vector 变体（value.rs / heap.rs 实读）；`LiteralValue` 无 Vector（quote 产物域）；
- 内建面：无 vector 族函数（builtins.rs 57 平名 + 47 限定名零 vector 行）；
- 宏面：macro_sys.rs 完整保留 `#(...)` 模板/模式往返（syntax-rules 引擎既有能力——模板可产出 vector datum、模式可匹配 vector——**本窗零触碰**）。

**窗口范围（TD-002 全清偿）**：交付向量值类型全链——双面集合字面量（S-expr `#(...)` 既有 + target `[...]` 新皮肤映射）+ 双侧展开脱糖（表达式位 + quote 位——vector 应用形）+ 值模型（`Value::Vector` + `HeapObj::Vector` + GC 子引用枚举 + 渲染/相等/类型名）+ 五内建族（vector/vector-length/vector-ref/vector-append/is-vector——kerf-vector 限定模块面）+ 32 case 门 + 语料对。

**域外维持（§7 登记——本窗不做）**：match 模式位向量（match-design §1 域外维持——负向锚保留）；postfix 索引语法 `v[i]`（皮肤映射独立窗——索引消费语料信号）；可变向量族（vector-set!/填充器——不可变设计 D3 的推论）；vector↔list 转换族（消费语料信号）；Vector HM 类型构造（TC-SIGS 扩表同族——krf ⊆ oracle 契约维持）；EBNF Level 1-4 集合运算族（登记态——原则 54 免疫）。

## 2. 语法域（EBNF 产生式——Level 0 定稿域内追加）

### 2.1 S-expr 面（正典核心形——既有蓝图零新增）

```ebnf
vector_lit ::= "[" {expr} "]"
```

示例：`[1 2 3]` / `[]` / `[1 [2 3]]`（空格分隔——方括号即向量 datum 的既有正典形：种子 parser.rs `parse_list_like` OpenBracket→is_vector 交付态 + bootstrap reader.ktf `open_k == 13 → vec` 镜像——**本窗 Reader 零变更**；`#(...)` 非本语言向量形——词法器拒 `#` 为既定面）。本窗仅翻转展开位两处拒绝。形约束：向量元素为任意 datum（表达式位=表达式展开；quote 位=字面量化——D2）。

### 2.2 目标面（皮肤映射——第十四映射族：逗号省略映射）

```ebnf
vector_lit ::= "[" [expr {"," expr}] "]"
```

示例：`[1, 2, 3]` / `[]` / `[1, [2, 3]]`。Reader 皮肤字典映射：`[a, b, c]` → `[a b c]`（**逗号省略映射**——目标面逗号分隔 ↔ S-expr 面空格分隔，符号与结构逐一同构；require/import/extern 声明族逗号先例同构）。空表 `[]` = 空向量（零元素合法）。LBracket 在 **primary 位**受理（postfix 位维持索引域外诊断——D6 位置纪律）；双 Reader（种子 target.rs + 自举 target_reader.krf）同构受理。

### 2.3 值域词表（三形态）

| 形态 | 载体 | 相等语义 | 渲染 |
|---|---|---|---|
| 构造产物 | `Value::Vector(GcRef)` → `HeapObj::Vector(Vec<GcRef>)` | `eq?` 按 GcRef 引用（与 Pair 同律——TD-010 口径） | `[1 2 3]`（括号形——与字面量语法一致可回读，与 Stx datum 渲染同律） |
| quote 产物 | 运行期构造（D2-b 递归脱糖——与 quote pair 的 emit_literal_pair 运行期构造同律） | 同上 | 同上 |
| 空向量 | `HeapObj::Vector(vec![])` | 引用相等（每次构造独立实例——与 `(list)` 每次 nil 不同律：nil 为单例立即值，向量恒堆分配） | `[]` |

## 3. 裁定表（D1-D10）

### D1（含 §2.3）：不可变向量设计（Immutable by construction）
`HeapObj::Vector(Vec<GcRef>)`——元素槽位 Vec，构造后零变异面。理由四件：①元素槽位与 Pair 同律（`box_value` 逐元素装箱——`list` 内建同款分配模式，GC 子引用枚举天然同构）；②不可变性 ⇒ 构造期无环（纯构造下向量元素先于向量存在——渲染防御性 seen-map 仍保留[render_pair 同款]，但语义上环不可达）；③可变族（vector-set!）= 值域机制变更 = 独立窗（消费语料信号触发式——§7 登记）；④原则 12 权衡：不可变最小完备面覆盖构造/查询/拼接三消费族，可变性无在案语料信号。

### D2：全脱糖路径（CoreExpr 九原语冻结零触碰——本窗最重裁定）
**两位置皆脱糖为 `vector` 应用形**：
- **D2-a 表达式位**：`#(a b c)` → `Apply{Var("vector"), [expand(a), expand(b), expand(c)]}`（种子 expander.rs:297 翻转 + 自举 expander.ktf:3464 翻转——节点形 `"sym vector" + 子节点`）；空向量 `#()` → `Apply{Var("vector"), []}`。
- **D2-b quote 位**：`(quote #(e1 e2 ...))` → `Apply{Var("vector"), [quote_elem(e1), ...]}`，其中 `quote_elem`：原子/对列表 → 既有 `quote_datum` 产物 `Literal`（LiteralValue::Pair 链既有——嵌套对列表零新面）；嵌套向量 → **递归脱糖**（内层再产 `Apply{vector, ...}`）。种子 core_forms.rs:829 翻转 + 自举 expander.ktf:1808 翻转。
- **零触碰清单（脱糖的推论）**：CoreExpr 零新变体（原则 9 冻结维持——Match r122 同律先例）/ IrExpr 零变更 / compile.rs + compiler.ktf 零变更（Apply 既有路径）/ 零新操作码（#43-47 既有集不动——r137「零新操作码」口径延续）/ `LiteralValue` 零新变体（quote 向量不进字面量域——运行期构造与 quote pair 的 emit_literal_pair 运行期构造**同律对称**：quote 结构的运行期构造为既有语义，非本窗新引入）。
- **逐次求值语义**：`Apply` 实参序求值既有纪律自然承袭（元素从左到右求值后构造）。

### D3：值模型与 GC（HeapObj 加性变体——Foreign TD-010 同律）
- `Value::Vector(GcRef)`（kerf-vm/value.rs 加性变体）；`HeapObj::Vector(Vec<GcRef>)`（kerf-runtime/heap.rs 加性变体——元素槽位制）；分配入口 `alloc_vector(Vec<GcRef>)`（alloc_pair 同族）；
- GC 子引用枚举：`children()` 加臂 `HeapObj::Vector(v) => v.clone()`（mark 图遍历边——Pair 两元素枚举的直接推广）；`alloc_boxed`/`BoxedInput` 零变更（向量恒经 `alloc_vector`——非箱立即值路径）；
- `ValueSlot`/`box_value`/`unbox` 三向转换：Value::Vector 装箱 = 槽位复引用（与 Pair 同律——堆值直接入槽）；`type_name` = `"vector"`；
- `eq_value`：Vector↔Vector 按 GcRef（引用相等——Pair 同律）；跨类型恒 false。
  - **r162 / 233 — TD-037 相等域窗法修订（D5）**：用户面相等律换源 `structural_eq`{Pair/Vector 递归结构相等——值相等；procedural 值同一性维持；本行旧律（per-instance identity）在 r138 语境下成立、在 `==` 现代中缀面全域化后不可维持（混血不连贯：Str 结构真 vs Pair 同一性假）}；本行保留为 `Value::eq_value` 值层基底的historical登记（内部消费）；neg23 锚翻转{`eq(vector(), vector())` ⇒ true}。

### D4：五内建族（kerf-vector 限定模块面——stdlib 模块先例同构）
| 内建 | 元数 | 语义 | 诊断（运行期 fail-closed） |
|---|---|---|---|
| `vector` | 变元 0..n | 左到右装箱构造 | 无域错（任意值合法元素） |
| `vector-length` | 定 1 | 元素计数 → Int | 非 vector 实参 → 「vector-length 需要 vector，实际 …」 |
| `vector-ref` | 定 2 | 0 基索引取元素 | 非 vector 首参 / 非整数次参 / 越界（<0 或 ≥len）→ 三消息族 |
| `vector-append` | 变元 0..n | 拼接产新向量 | 任一实参非 vector → 消息族 |
| `is-vector` | 定 1 | 谓词 → Bool | 无域错（任意值合法） |
限定名注册：`kerf-vector::vector` 等五件（builtins.rs 模块组表「vector」→「kerf-vector」行——import/use 选择形消费面自动接驳）；W1003 宏遮蔽面经 BUILTIN_SIGS 自动扩展。**BUILTIN_SIGS（oracle 侧）五条**：`vector` = variadic(Any, Unknown, 0)（list 同款保守形）/ `vector-length` = fixed([Any], Int 形)/ `vector-ref` = fixed([Any, Any], Unknown) / `vector-append` = variadic(Any, Unknown, 0) / `is-vector` = fixed([Any], Bool)——参数恒 Any（零静态域约束——负向覆盖落运行期执法面，D7 同律）。

### D5：HM/check 双侧（A4 Dynamic 维持——零新误报 D9 同律）
HM 面零 hm.rs 变更：脱糖产物 = Apply{Var("vector")}——未绑定全局 A4 Dynamic 原路径既有纪律（r137 D7 同律）；oracle 侧 BUILTIN_SIGS 五条给参数 Any/结果保守形——零类型不一致误报面。**check.krf（生产判定面）TC-SIGS 不扩表**：krf ⊆ oracle 契约维持（TC-SIGS 扩表 = 触发式——member-rename §7 同源登记）；生产面 vector 调用 → A4 Dynamic（运行期 one_arg/two_args/域执法兜底 fail-closed）。oracle/krf 差距 56+5 vs 23——登记册 widening 注记（§7 行）。

### D6：位置纪律（target 面双层）
LBracket **primary 位**受理（parse_primary 加臂——`Tk::LParen` 分组先例同构位）；**postfix 位维持域外诊断**（target.rs:2924「索引（集合类型域外）」原文不动——索引语法 = 独立窗触发式）。自举 target_reader.krf 镜像同构双层（primary 受理臂 + postfix 维持臂）。S-expr 面无位置分歧（datum 结构化既有）。

### D7：诊断分配（运行期族复用——码表零净增）
向量域错 = 运行期 RuntimeError 族（「…需要 vector，实际 …」/「vector-ref 索引越界…」——既有 one_arg/two_args/域消息构造器同款）；展开/词法零新诊断码（表达式位翻转后原拒绝位消失；target 面括号失配 = 既有 E0001 族）。**码表零净增**（E0026 一码五族先例的反面——本窗零新码）。

### D8：渲染与印刷（括号形——可回读律）
`render_value` Vector 臂：`[` + 元素 render_slot 空格连接 + `]`——`[1 2 3]` / `[]`；与字面量语法一致（渲染可回读——词法器受理方括号）+ 与 Stx datum 渲染 `[{}]` 同律；嵌套自然递归；防御性 seen-map（render_pair 同款——不可变设计下环不可达，防御保留）；print 内建经 render_value 自动获得（零 print 变更）。

### D9：既有程序零回归（空载不变式）
零 vector 字面量程序：展开面零变化（脱糖臂仅 Vector datum 触发）+ 值模型加性（既有 Value 分派臂 match 全覆盖测试既有）+ 内建注册加性（全局表 +5 名——名称冲突面：vector 等五名不在 57 平名/47 限定名既有集[W1003 数据源核对]）——1687 基线逐位不变。

### D10：测试矩阵（32 case 门——8 正 + 24 负 = 1:3，§9.4.3）
**正向八族**：①E2E 双面（`#(1 2 3)` len⇒3 ref⇒1 / `[1, 2, 3]` 同值——双语法同程序族）②quote E2E（`(quote #(1 2))` 元素 Symbol/Str 混合 + 运行期取回）③嵌套向量（`#(1 #(2 3))` ref⇒内层 + len⇒2）④append E2E（拼接 + 长度守恒 + 新实例性[原向量不变]）⑤印刷形（print ⇒ `[1 2 3]` 字符串精确锚）⑥跨语法字节码 parity（同程序两语法源 → 指令序/常量池全等——皮肤透明性 D2 推论）⑦混合程序（vector + define + import 并存零互扰 + fn/let/实参位深度[分辨率不受词法深度影响]）⑧GC 存活实证（向量入闭包捕获 → 触发回收周期 → 元素引用仍可用——children 臂 E2E）。
**负向二十四族**：运行期域错八族（vector-length 非向量 / vector-ref 非向量首参 / 非整数索引 / 负索引 / 越界索引 / vector-append 非向量成员 / is-vector 假例 ×2[Pair/Int]）+ 元数族四（vector-length 零参 / vector-ref 单参 / vector-ref 三参 / vector-length 双参——one_arg/two_args 运行期执法）+ 展开位维持族二（match 模式位向量拒绝——match-design §1 域外锚双侧消息一致 / 宏模板外 quote 边界——嵌套 quote 形状执法）+ 词法族四（target 面 `[1 2]` 缺逗号 / `[1,]` 尾逗号 / `[1` 未闭合 / `[` 后即 `]` 外杂符——E0001 族+Span 双面镜像）+ Reader parity 族三（双 Reader 正典渲染 parity / 字节级 Stx 树全等 / `[...]`→`#(...)` 映射精确性）+ oracle 元数静态族二（check_source 面 vector-ref 单参 → E0005 途径[BUILTIN_SIGS oracle 侧] / vector-length 零参 → E0005——注：生产 check.krf 路径该族为 Dynamic 不报——测试锚定 oracle 面并注记不对称契约）+ 空向量边界族一（`#()` len⇒0 / is-vector ⇒ true / append 单参不变性——正负合锚负向空表引用相等反例）。
（门文件 = tests/v0/stage3/plan/ktf_vector_value_tests.rs；正负比 8:24 = 1:3 精确。）

## 4. 实施对账表

| # | 实施件 | 落位 | 双侧 |
|---|---|---|---|
| 1 | target primary 位 LBracket 受理 + 逗号分隔语法 | kerf-reader/target.rs | 自举 target_reader.krf 镜像 |
| 2 | 表达式位脱糖翻转 | kerf-expander/expander.rs:297 | expander.ktf:3464 |
| 3 | quote 位递归脱糖翻转 | kerf-expander/core_forms.rs:829 | expander.ktf:1808 |
| 4 | Value::Vector + type_name + eq_value | kerf-vm/value.rs | ——（VM 单侧） |
| 5 | HeapObj::Vector + alloc_vector + children 臂 | kerf-runtime/heap.rs | ——（runtime 单侧） |
| 6 | render_value Vector 臂（seen 防御） | kerf-vm/value.rs | ——（VM 单侧） |
| 7 | 五内建 + BUILTIN_SIGS 五条 + kerf-vector 模块组行 | kerf-driver/builtins.rs | ——（oracle 单侧；check.krf 零变更 D5） |
| 8 | 32 case 门挂载 | tests/v0/stage3/plan/ktf_vector_value_tests.rs + tests/runner.rs | —— |
| 9 | 语料对 | examples/usage/vector.{ktf,krf} | 双面同语义 |
| 10 | 治理十件 | 02 §8.13.1b / 20 §14 第十四映射族 / 登记册 TD-002 清偿 / gated-tasks #5 翻转 / replacement-map §5 缺口 5 清偿 / t3plus v1.58 行 14 / 速查卡 R4 顺修两行（match 划线 + TD-002 划线）/ RELEASE r138 / matrix r138 / worklog 三链 | —— |

## 5. 与既有治理锚的对账

- **原则 9（CoreExpr 冻结）**：D2 全脱糖 = 冻结零触碰的最优解（Match r122 先例同律）；「九正交语义原语 + 声明变体可追加」原文口径维持。
- **原则 27（加性）**：D9 空载不变式 = 1687 基线逐位复现的验收前置。
- **原则 31（皮肤/骨架同构）**：双 Reader 双 expander 双诊断四镜像位逐一同构（第十四映射族）。
- **原则 44（新语法成员附 EBNF）**：§2.1/§2.2 产生式 + 02 v7.22 §8.13.1b 回写。
- **8 原语不变性第二十轮**：零新原语零通道零新操作码零 CoreExpr/IR 变体——**历次最轻量值模型窗**（比 r137 更轻：r137 含 IrVar::Extern 分辨层变更；本窗分辨/编译/VM 主链零变更——变更面 = Reader 皮肤 + expander 脱糖 + 值模型 + 内建）。
- **TD-010 装箱口径**：Vector 元素槽位制 = Pair 装箱律的自然推广（heap 分配纪律同源）。

## 6. 风险与回退

- **风险 1（GC 遗漏 children 臂）**：漏臂 = 元素误回收 → UAF——D10-⑧ GC 存活实证为硬门 + gc_stress 既有套件回归。
- **风险 2（脱糖与宏交互）**：宏模板产出的 vector datum 经脱糖臂 = `(vector ...)` 应用形——语义等价但**印刷形漂移**（宏展开产物 Stx 层仍为 Vector datum——脱糖在 CoreExpr 层，Stx 层零影响——macro_sys 零触碰实证）。回退 = 单臂 revert（expander 两文件四臂独立可回滚——原则 27 加性粒度）。
- **风险 3（名称冲突）**：vector 等五名用户遮蔽（define 同名）→ 既有 W1003 通知面 + 词法作用域解析既有律——零新机制。
- **回退粒度**：五实施件（Reader/expander/值模型/内建/测试）独立可回滚；整体回退 = 一笔 revert（无数据迁移无格式变更）。

## 7. 诚实边界（域外登记表——触发式）

| 域外项 | 载体 | 触发判据 |
|---|---|---|
| match 模式位向量（`#(...)`/`[...]` 入 match 臂模式） | match-design §1 域外维持（本窗负向锚保留双侧拒绝） | match 向量模式消费语料信号 |
| postfix 索引语法 `v[i]`（皮肤映射独立窗） | target.rs:2924 域外诊断原文维持 | 索引消费语料信号（`[` postfix 位计数） |
| 可变向量族（vector-set!/vector-fill!/swap!） | 本文件 D1（不可变设计推论） | 可变消费语料信号（值域机制变更 = 独立窗 L3） |
| vector↔list/string 转换族（vector->list / list->vector / vector->string） | 本文件 D4（五内建最小完备面） | 转换消费语料信号 |
| Vector HM 类型构造（TcType::Vector / 元素类型约束） | 本文件 D5（A4 Dynamic + Any 参数保守形） | TC-SIGS 扩表同族触发（krf 面签名执法扩展需求——member-rename §7 同源） |
| 向量字面量常量池化（quote 向量共享实例优化） | 本文件 D2-b（运行期构造 = quote pair 同律） | 性能消费面信号（OBS-C 同族） |
| EBNF Level 1-4 集合运算族（并/交/差/推导式） | 12 §2.4.1 Level 1-4 登记态 | 原则 54 免疫沿袭——Level 1-4 触发式 |

*遵循条款：原则 9（CoreExpr 冻结——D2 全脱糖）/ 原则 12（最优>最小——五内建覆盖三消费族而非抽样）/ 原则 26（成熟度匹配——词法既有 + 值模型先例族）/ 原则 27（加性——D9 空载不变式）/ 原则 31（皮肤/骨架同构——第十四映射族）/ 原则 44（新语法成员附 EBNF）/ §2.3-4（报错>静默——运行期域错 fail-closed）/ §9.4.3（1:3）/ §18（机制零新增——零操作码零依赖）/ r122 match 窗先例（门控任务 #6 同族行权）/ r137 extern 窗先例（A4/D9 同律沿袭）。*

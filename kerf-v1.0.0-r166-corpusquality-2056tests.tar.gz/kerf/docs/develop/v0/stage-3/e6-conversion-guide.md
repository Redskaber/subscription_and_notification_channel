# E6 Test-Surface Conversion Guide (r154 / 224-b)

> Single source for the S-expr → target-syntax conversion discipline.
> Read this fully before editing any file. Cite `E6-CG` sections in worklogs.

## 1. API mapping (S-expr entry → target entry)

| Retired S-expr API | Target replacement |
|---|---|
| `run_source(src, name)` | `run_source_target(src, name)` |
| `run_source_seed(src, name)` | `run_source_seed_target(src, name)` (NEW, exported) |
| `run_source_rendered(src, name)` | `run_source_target(...)` + `kerf_vm::render_value(&o.value, &o.heap)` |
| `compile_source(src, name)` | `compile_source_target(src, name)` |
| `compile_source_seed(src, name)` | test-level seed reconstruction OR `run_source_seed_target` for run outcomes |
| `check_source(src, name)` | `check_source_target_recover(src, name)` |
| `check_source_recover(src, name)` | `check_source_target_recover(src, name)` |
| `dump_tokens(src, name)` | `dump_tokens_target(src, name)` |
| `dump_stx(src, name)` | `dump_stx_target(src, name)` |
| `test_source(src, name)` | `kerf_driver::bootstrap::test_runner::run_target(src, name)` |
| `kerf_reader::read_source` | `kerf_reader::read_target_source` |
| `kerf_reader::lex_source` | `kerf_reader::lex_target_for_parity` (token shape differs — ParityToken) |
| `bootstrap::install_state/reset_state/read_source/lex_source/selfcheck_*` | DELETED — rework or delete dependent tests |
| `kerf_driver::test_runner_run` | `test_runner_run_target` |
| `validator::{SyntaxTransitionValidator, ...}` | DELETED — see §4 dispositions |
| `cache_bridge_internal`, `compile_front_cached`, `compile_front_seed`, `compile_front` | DELETED (pub(crate)) |
| `kerf_reader::{Token, TokenKind, Delimiter, Operator, Lexer, Parser}` | DELETED (classic face) |
| `kerf_reader::TargetReadError` | `kerf_reader::ReadError` (merged sole face) |

Filenames: `.krf` → `.ktf` (e.g. `"test.krf"` → `"test.ktf"`, `"audit.krf"` → `"audit.ktf"`).

## 2. Program syntax mapping (S-expr → target) — the skin dictionary

| S-expr | Target |
|---|---|
| `(define (f x) body)` | `fn f(x: i64) -> i64 { body }` (types: `i64` int, `f64` float, `bool`, `str` — infer from usage; untyped let is allowed) |
| `(define (f) body)` | `fn f() -> i64 { body }` |
| `(define name expr)` (top-level value) | `let name = expr;` at top level? NO — top-level value defs in tests: use `fn` or a `let` inside `fn main`. For audit/test case programs, prefer wrapping in functions OR top-level `let name = expr;` followed by expression cases (test face treats top-level exprs as cases; top-level let = prelude form) |
| `(if t a b)` | `if (t) { a } else { b }` (expression; arms need braces) |
| `(cond (c1 a...) (else b))` | if-else chain: `if (c1) { a } else { b }` |
| `(and a b)` / `(or a b)` | `a && b` / `a \|\| b` (right-assoc for n-ary) |
| `(not a)` | `!a` |
| `(do e1 e2 e3)` | `{ e1; e2; e3 }` statement sequence (last = value; semicolons between) |
| `(let ((x 1) (y 2)) body)` | `{ let x = 1; let y = 2; body }` (multi-binding → comma form also valid: `let x = 1, y = 2;`) |
| `(let ((x 1)) body)` | `{ let x = 1; body }` |
| `(assign x v)` / `(set! x v)` | `x = v;` (statement) |
| `(fn (x) body)` (closure value) | `\|(x: i64) { body }` — check existing corpus (examples/usage/closures.ktf) for exact closure syntax |
| `(while c body...)` | NOT in target surface — rewrite as recursion or for-to loops if corpus uses it (check examples/usage) |
| `(when/unless/let* ...)` | if-else / let chains |
| quote forms `'(a b)` | `quote((a b))` — data; avoid in tests unless needed |
| `'sym` | `quote(sym)` |
| `nil` (value position) | `()` — unit value |
| `(eq a b)` | `eq(a, b)` (generic) — for numbers prefer `a == b` |
| `(= a b)` | `a == b` |
| `(< a b)` / `(+ a b)` etc. | `a < b` / `a + b` (infix, standard precedence; parenthesize when unsure) |
| `(- 1)` | `-1` |
| `(f x y)` | `f(x, y)` |
| kebab-case names `first-rest` | snake_case `first_rest` |
| `(module m ...)` | `module m { ... }` |
| `(import kerf-string (append as sa))` | `use kerf_string::{append as sa};` |
| `(require io write)` | `require io write;` |
| `(perform e)` / `(handle ...)` | `perform e` / `handle` — see examples/usage/effect*.ktf for exact forms |
| string escapes | same set (7-form parity, r151) |
| comments `;` | `//` |

**Reference corpus for exact idioms**: `examples/usage/*.ktf` (16 files — closures/effect/match/vector/fib/higher_order...), `tests/v0/stage3/plan/cli_entry_convergence_tests.rs` TARGET_FIB, ktf_* test families.

**Golden rule**: when unsure of a target-syntax idiom, check `examples/usage/*.ktf` first; if still unsure, keep the case but mark `// E6-CG: verify idiom` and TEST it (cargo test the family).

## 3. Test-face semantics (unchanged)

- Top-level `fn`/`let`/`module`/`require`/`use` forms = prelude (replayed per case).
- Every other top-level expression = a case: value != false → PASS.
- Program value face (run_source_target): last top-level expression's value.

## 4. Family dispositions (ARCH-A central rulings — execute exactly)

| Family | Disposition |
|---|---|
| examples/audit/stage0_gate_audit_r1.rs | CONVERT (API + corpus) |
| examples/audit/stage1_gate_audit_r1.rs | CONVERT |
| examples/audit/stage2_gate_audit_r1.rs | CONVERT |
| examples/audit/stage2_gate_audit_r2.rs | CONVERT |
| examples/audit/stage3_gate_audit_m3.rs | CONVERT |
| examples/audit/stage3_gate_audit_e5close.rs | CONVERT |
| tests/common/mod.rs | CONVERT (helpers → target APIs; callers' corpora converted by respective agents) |
| stage0: vm_tests, pipeline_tests, gc_tests, negative_vm_tests, negative_semantics_tests, typecheck_tests(stage1), stdlib_tests(stage1), tco_tests(stage2) | CONVERT inline corpora |
| stage0: negative_reader_tests.rs | DELETE file + runner.rs mod line (S-expr Reader diagnostics — component deleted; target Reader negative coverage exists in target_reader_tests/ktf families) |
| stage1: bootstrap_reader_tests.rs | DELETE file + runner.rs mod line (B3 S-expr Reader parity — component deleted) |
| stage1: reader_tests.rs | INSPECT: if it tests kerf_reader classic face → DELETE; if target face → keep/convert |
| stage1: expander tests using read_source in #[cfg(test)] (kerf-expander/src/expander.rs tests, derived.rs tests already fixed) | CONVERT corpora to read_target_source |
| stage3: switch_corpus_parity_tests.rs | INSPECT: S-expr↔target corpus parity legs → DELETE those legs; fixpoint (B1/B2) legs → KEEP; whole family may shrink drastically. If nothing survives → DELETE family |
| stage3: switch_step5_validation_tests.rs | DELETE file + runner.rs mod line (SyntaxTransitionValidator consumer; fixpoint gates carry duty) |
| stage3: seed_ktf_parity_tests.rs | REWORK: gate X legs (.krf oracle comparisons) → DELETE; fixpoint/two-path/liveness legs → KEEP (may need API swaps); rename internal references |
| stage3: target_reader_krf_tests.rs | INSPECT: legs using read_target_source_for_bootstrap + Rust seed comparisons → KEEP (rename file later? NO — keep filename, it's the reader gate); legs using deleted APIs → convert/delete |
| stage3: hm_krf_path_tests.rs | INSPECT: .krf-path legs → DELETE; check.ktf production legs → keep if independent |
| stage3: {build,cache,cli,test,test_runner}_krf_parity_tests.rs | DELETE files + runner.rs mod lines (bridge .krf↔Rust parity — duty complete; bridge liveness = production_*_is_bootstrap probes elsewhere; cache bridge functional coverage → E6 gate family will carry minimal liveness) |
| stage3: match_m4_krf_mirror_tests.rs | INSPECT: S-expr mirror legs → delete legs or family |
| stage3: cli_entry_convergence_tests.rs | REWORK: S-expr legs (SEXP_FIB etc.) → convert to target-only assertions; .krf rejection legs → KEEP (they're the deletion guard!) |
| architecture_audit_tests.rs | INSPECT: references to deleted Reader types → fix |
| cache_tests.rs (stage1) | INSPECT: should survive (InMemoryCompilationCache + trait face) — fix any compile breaks |
| bootstrap_expander_tests / bootstrap_compiler_tests / prelude_tests / test_runner_tests / capability_tests / expansion_worklist_tests / scope_set_tests / reserved_ext_tests | INSPECT + fix compile breaks only |

## 5. Verification per agent

- `cargo check --workspace --all-targets` → zero errors in YOUR files (others may still error — only fix what your task owns; report remaining owners)
- Run YOUR converted families: `cargo test --release --test runner <family filter>` or for audits `cargo run --release --example stage0_gate_audit_r1` → EXIT 0
- `cargo fmt` your files (do NOT fmt others)
- Do NOT run clippy -D warnings on the whole workspace yet (main agent's GATE 1 duty)
- Every deleted family: keep a count of deleted #[test] functions — report exact numbers
- Every converted family: same test count as before (conversions preserve case count; if a case is genuinely unconvertible, DELETE it and report with reason)

## 6. worklog append (each agent)

Append to `/home/z/my-project/kerf/worklog.md` AND mirror to `docs/worklog.md` (both files, append-only):
```
---
Task ID: 224-b<N>（r154 E6 收口批——<scope>）
Agent: <name> — DEV-A
Task: ...
Work Log: - ... (cite E6-CG §, §20.6, §9.4.3 etc.)
Stage Summary: - case counts before/after, deleted/converted, verification results
```

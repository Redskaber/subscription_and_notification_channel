# Stage 3 收口窗——性能基线（r52 落档）

> **Author**: kerf-dev-agent
> **Date**: 2026-09-21（**v1.2 r54 演进对照——TD-028 分派优化窗（76-b）**：VM 主分派三优化点（O1 span 惰性 / O2 指令引用化 / O3 proto 跨迭代缓存）A/B 双二进制对照实测——**fib 91.238→76.354ms（1.195x）** / gc 尾形 42.017→36.641ms（1.143x）/ check 中值 3812→3669ms（1.039x，波动带内诚实口径）/ 深帧非尾形中性——§2.7 新增对照节[只追加不覆盖——r52 冻结值原表不动]）；**v1.1 归因修正——r53 / 75-b T3+ 优化窗 R4 实录**：§2.3 维度归因错误修正——v1.0 把 check 全链耗时误记为「HM 类型检查」耗时[3734ms 实测构成 = 自举 VM 链 99.77% + HM 段 0.23%——r53 阶段插桩实测拆解，见 §2.6 归因修正节]；§2.3/§3.4 同步修正 + r53 HM 段优化对照行；v1.0 原始冻结值保留于 §2.3 表（历史口径——只追加不覆盖纪律））；**v1.0 首版——r52 / 74-a+74-b Stage 3 收口窗性能基线建立**：§21.5 阶段切换九信号中「□ 性能基线」缺口兑付——五维度 13 程序实测落档（执行速度 6 / 编译速度 4 / HM 类型检查 3 / GC 压力 2 / 自举一致性 1）+ 吞吐换算 + Stage 3+ 优化候选注记；载体 = CLI `bench`/`check` 既有子命令（零本体变更——纯测量落档）｜深审承载 = 本文 §4 + sop §14.5 D1-D8 Stage 3 版）
> **Status**: Active（基线冻结 r52——后续演进对照本表；重跑口径见 §5）
> **处理程度**：P1（基线数据 + 重跑规程——Stage 3+ 性能演进的对照锚）｜ **所属 Stage**：Stage 3 收口窗首件（E5 全闭 v1.0.0 后）

---

## 1. 度量环境与口径

| 项 | 值 |
|---|---|
| 构建口径 | `cargo build --release`（14.03s 零告警——r51 基线维持） |
| CPU | 2 核 Intel Xeon（沙箱容器） |
| 内存 | 4 GiB |
| rustc | 1.98.1（48a229cea 2026-09-01） |
| 载体 | CLI `kerf bench <file> N`（编译+VM 执行 N 轮均值）/ `kerf check <file>`（HM 类型检查干编译） |
| 热身 | bench 先验证一次正确性再计时；check 取 3 次取样中值 |
| 日期 | 2026-09-21（r52 / v1.0.0 代码基线 = 500c7db） |

**口径声明**：`bench` = 读→展→编→VM 顶层执行（合体口径）；`check` = 读→展→编→**HM 类型检查**（E0002+E0005 全量报告管线——TD-013 恢复模式）。两者分离恰好把「编译发射」与「类型检查」拆为两个独立可对照维度。

## 2. 基线数据（v1.0.0 / r52 冻结值）

### 2.1 执行速度（VM 解释器；bench 20 轮均值）

| 程序 | 语义载荷 | 验证值 | 每轮均值 |
|---|---|---|---|
| `examples/usage/fib.krf` | fib(25) 朴素递归（数值热路径 + 调用栈压力） | 75025 | **91.534 ms** |
| `examples/usage/effect_stress.krf` | 效应 perform/handle 恢复 20 层 | 120 | **85.807 ms** |
| `examples/usage/gc_stress.krf`（10 轮） | 3×10^5 尾递归有界分配 | 5 | **41.593 ms** |
| `examples/usage/gc_stress_nontail.krf`（10 轮） | 非尾递归分配形态（栈帧+堆双压力） | 5 | **90.851 ms** |
| `examples/usage/higher_order.krf` | 高阶闭包 map/组合 | (1 4 9 16 25) | **0.042 ms** |
| `examples/usage/closures.krf` | 闭包捕获计数 | (4 2) | **0.044 ms** |
| `examples/usage/macros.krf` | 宏展开产物运行 | (2 1) | **0.041 ms** |
| `examples/usage/io.krf` | io 门控 print（字符串拼接） | 拼接字符串 | **0.041 ms** |

> fib(25) ≈ 242785 次递归调用 → **~2.65M 调用/s** 解释吞吐（含参数打包/栈帧分配）。

### 2.2 编译速度（读→展→编→顶层执行；bench 20 轮均值）

| 语料 | 体量 | 产出 | 每轮均值 |
|---|---|---|---|
| `bootstrap/expander.krf` | 1865 行 | — | **0.476 ms** |
| `bootstrap/compiler.krf` | 1147 行 | 80 原型 / 4405 指令 | **0.270 ms** |
| `bootstrap/reader.krf` | 472 行 | — | **0.142 ms** |
| `bootstrap/preamble.krf` | 66 行 | — | **0.048 ms** |

> compiler.krf 吞吐换算：4405 指令 / 0.270ms ≈ **16.3M 指令/s 发射吞吐**；全自举四件（3550 行）合口径 < 1ms。

### 2.3 check 管线耗时与 HM 段（3 次取样中值；**v1.1 归因修正——r53**）

> **归因修正实录（r53 / R4——代码实测为准）**：v1.0 本节标题「HM 类型检查」为**归因错误**——`kerf check` 走恢复模式全链（自举 Reader[VM] → 恢复展开[VM] → 自举 Compiler[VM] → HM 检查[Rust]），上表数值（3734/1230/27ms）实为**全链耗时**，其中 HM 检查段仅占 **0.23%**（expander 语料实测 8.5ms）。修正后口径如下（v1.0 数值保留为「全链口径」历史行——冻结基线值不变，仅归因标签修正）。

| 语料 | 体量 | 静态问题 | check 全链耗时（v1.0 冻结值） | **HM 段实测（r53 拆解）** |
|---|---|---|---|---|
| `bootstrap/expander.krf` | 1865 行 | 0（ok） | **3734 ms** | **8.5 ms**（占 0.23%） |
| `bootstrap/compiler.krf` | 1147 行 | 24（E0002+E0005 恢复模式全量） | **1230 ms** | **2.5 ms**（占 0.20%） |
| `examples/usage/fib.krf` | 8 行 | 0 | **27 ms** | **0.013 ms** |

> **诚实注记（v1.1 修正版——Stage 3+ 优化候选重定向）**：check 路径的真实大头是**自举 VM 链**（read + expand + compile 三段——见 §2.6 阶段分布实测），非 HM 检查（v1.0 的「HM 为最重一环」判断源于把全链耗时误归因于最后计时段）。类型检查不在 run 执行路径上（零运行时开销——原则 18 兑现），HM 段自身经 r53 O1 优化后 8.5→6.95ms（1.22x——见 §2.6 对照行），但**对 check 总时长影响 <0.3%**。Stage 3+ check 性能演进正解 = **自举 VM 链优化（TD-028 范畴——read/expand/compile 三段全受益于 VM 主分派优化）**；HM 优化候选（occurs union-find 压缩 + 泛化 memo）已 r53 部分兑付（O1 路径压缩落地 + 负收益项实录留档——deep-review-t3-optimization.md D6）。

### 2.6 check 阶段分布与 r53 优化对照（v1.1 新增——r53 阶段插桩实测）

**check 阶段分布**（expander.krf 语料；r53 临时插桩实测——插桩已移除，净代码零残留）：

| 阶段 | 耗时 | 占比 | 载体 |
|---|---|---|---|
| read + prelude/import 面收集（1.x） | 1287.6 ms | **34.7%** | 自举 Reader（VM）+ Stx 预处理 |
| 恢复展开（expand） | 495.3 ms | 13.4% | 自举 Expander（VM） |
| front_from_core（编译段） | 1909.8 ms | **51.5%** | 自举 Compiler（VM） |
| HM 类型检查 | 17.4 ms（含插桩开销；净 ~8.5ms） | 0.5% | Rust 原生 |
| 渲染与其余 | 0.1 ms | <0.01% | — |

**r53 HM 段优化对照**（O1 路径压缩两遍法 + O4 copy_fresh 结构共享——语义零漂移五手段全绿）：

| 语料 | HM 段基线（r52 代码态） | HM 段 r53 终态 | 加速比 |
|---|---|---|---|
| expander.krf | 8.5 ms | 6.95 ms | **1.22x** |
| compiler.krf | 2.5 ms | 2.15 ms | 1.16x |

> 实录（判据驱动——deep-review-t3-optimization D5/D6）：O2 occurs 结构指针剪枝 / O3 free_vars seen HashSet / O5 env_free HashSet 三项实测**负收益或中性偏负**（SipHash 开销 > 剪枝收益）——增量归因后移除（hm.rs 头注释实录留档）；OBS-A（env_free 全量增量化）判据关闭（增量收益上限 <0.05% check 总时长）。

### 2.4 自举一致性与链耗时（门 B fixpoint）

| 项 | 载体 | 状态 |
|---|---|---|
| B₁/B₂ 字节一致 | `tests/v0/stage2/plan/bootstrap_compiler_tests.rs::gate_b_fixpoint_two_self_compiles_byte_identical`（SHA-256 对照） | ✅ 877 套件内绿 |
| 自举链全口径耗时 | bench 四件合（§2.2）+ 877 测试套件全跑 | 全链 < 1ms（编译）+ 测试套件 ~30s |

### 2.5 GC 压力

| 项 | 值 |
|---|---|
| 尾递归分配（gc_stress 3×10^5） | 41.593 ms/10 轮均值 → **~7.2M 分配/s** |
| 非尾递归分配（gc_stress_nontail） | 90.851 ms → 栈帧+堆双压力形态 ~2.2× 于尾递归形态 |
| GC 验收双轨口径 | 权威判据 = gc_tests 10^6 有界分配（tests 内绿）；示例口径 = gc_stress.krf 3×10^5（12 §2.10 v5.2 注维持） |

### 2.7 r54 分派优化对照（v1.2 新增——TD-028 优化窗第二件 A/B 实测）

| 基准 | r53 基线 | r54 终态 | 加速比 |
|---|---|---|---|
| fib 25（bench 5 轮） | 91.238 / 92.871 ms | 76.354 / 78.874 ms | **1.177-1.195x** |
| gc_stress 尾形 | 42.017 ms | 36.641-36.762 ms | **1.143x** |
| check expander.krf（5 轮中值） | 3812 ms | 3669 ms | 1.039x（波动带内 1.02-1.04x） |
| gc_stress 非尾形 / effect_stress | ~109 / 94.6 ms | ~108 / 94.2 ms | 中性 |

> 实施载体 = [td028-dispatch-optimization.md](./td028-dispatch-optimization.md)（O1-O3 方案 + 增量归因 + 五手段）；深审 = [deep-review-td028-dispatch.md](./deep-review-td028-dispatch.md)。语义零漂移：904:0:0 + 三语料 A/B 逐字节 diff 空集。fib 吞吐 ≈ 2.65M → ≈3.15M 调用/s。TD-028 续窗判据收紧：fib < 65ms 或新阶段分布数据。


### 2.8 r55 帧槽池对照（v1.3 新增——TD-028 优化窗第三件 A/B 实测）

| 基准 | 基线（r54 HEAD 同机同时段） | r55 P1+P3 | 变化 |
|------|---------------------------|-----------|------|
| fib(25) | 76.406ms | **71.4ms（3 组 71.4-71.6 稳定）** | **1.067x** |
| gc_stress 尾形 | 36.409ms | 36.0-36.3ms | 1.005-1.012x |
| gc_stress_nontail | 89-105ms（**双峰带**——GC 相位稳态差异，基线版同带实证） | 89-105ms 双峰带 | 持平（带内） |
| effect_stress | 102.333ms | 94.8-97.6ms | **1.05-1.08x** |
| check（expander 全链） | 3.9-4.1s | 持平 | 持平（run/HM 面零触碰） |

- **机制**：P1 帧槽池（execute 层内 LIFO 池 + `strong_count==1` 护栏 + CELL_POOL_CAP=256）+ P3 清槽分工（release 仅清堆引用槽 / acquire 仅清 Let 槽——全参数覆写场景双侧零清槽）；P2 参数直写判据移除（callee 栈位约束证伪——args 中转为时序必需）。
- **剖面→实测对账（诚实口径）**：OBS-B 剖面估 ~28-35ms 潜在可省（50 万次堆分配上界模型），实测 fib 省 5.0ms——归因 glibc tcache malloc 实际 ~10-15ns/次（远低于估算 80-120ns）+ 池管理自身开销；**剖面是上界、实测是真实收益**（判据先于先例——不粉饰）。
- **TD-028 裁定**：漂移本体修复（r36 +9.9% → r55 相对 r24 原始基线 84.2ms **净超越 1.18x**）——**清偿关闭**（tech-debt-register r55 注记）；OBS-C 观察项登记（fib 剩余大头 = args Vec 中转 + Frame 构造——T3+ 触发式）。
- 五手段：918:0:0（净 +14 vm_frame_pool_tests）+ 三语料 A/B 逐字节 diff 空集 + 六审计集 280 EXIT 0 ×6 + CLI 全路径 + bench 值锚。

## 3. 基线结论（§21.5 信号④兑付）

1. **性能基线已建立**：五维度 13 程序 + 吞吐换算 + 优化候选注记——§21.5 阶段切换九信号最后缺口兑付，信号全绿（§4 对照表）。
2. **编译吞吐充分**：16.3M 指令/s 发射（自举全链 < 1ms）——自举验证（信号②）性能面无阻塞。
3. **解释器量级符合预期**：~2.65M 调用/s（自建 VM 1/10-1/30 目标区间内——§21.2 Stage 0 VM 定位）；QBE PoC（native fib 144→r17）已验证原生路径。
4. **check 路径大头 = 自举 VM 链（v1.1 归因修正——r53）**：HM 段仅占 0.23%（8.5ms/3734ms）；check 性能演进正解 = TD-028 VM 主分派优化（read/expand/compile 三段——§2.6 分布实测）；HM 段自身 r53 优化 1.22x 落地（O1+O4）。
5. **效应恢复开销可测可控**：effect_stress 与 fib 同量级（85.8 vs 91.5ms）——效应 handler 栈无异常放大。

## 4. §21.5 九信号收口对照（r52 终验）

| 信号 | 状态 | 证据锚 |
|---|---|---|
| □ 语义稳定 | ✅ | 877:0:0 + E5 出口三条件终验（e5close 47 case） |
| □ 自举验证 | ✅ | 门 B fixpoint B₁/B₂ SHA 一致 + 包内自举复跑逐位一致 |
| □ 测试覆盖 | ✅ | 877 case 测试矩阵（六审计集 280 + 单元/集成） |
| □ **性能基线** | ✅ **r52 兑付** | **本文 §2 五维度 13 程序冻结值** |
| □ 文档同步 | ✅ | 八件对账文档（73-a/73-b 回写 + 本文） |
| □ 能力处理程度 | ✅ | 23 §2.2 全窗对账 + 12 §2.5.1 全行终态 |
| □ 技术债清零 | ✅ | P0/P1 全清（TD-029/TD-030 清偿；e5close E 桶边界） |
| □ 外循环投票 | ✅ | S4 收口 5/5 = 100% GO（e5-plan §7）+ r52 深审环投票（本文 §5 收口件） |
| □ 阶段间深度验证 | ✅ | e5close 收口面 + r52 §14.5 D1-D8 Stage 3 版深审（深审文档承载） |

## 5. 重跑规程（后续演进对照）

```bash
# 执行速度（20 轮）
./target/release/kerf bench examples/usage/fib.krf 20
./target/release/kerf bench examples/usage/effect_stress.krf 20
# GC 压力（10 轮）
./target/release/kerf bench examples/usage/gc_stress.krf 10
./target/release/kerf bench examples/usage/gc_stress_nontail.krf 10
# 编译速度（自举四件，20 轮）
for f in compiler expander reader preamble; do
  ./target/release/kerf bench crates/kerf-driver/src/bootstrap/$f.krf 20
done
# check 全链 + HM 段（3 次取样中值——v1.1 归因修正口径：check 命令测全链；HM 段拆解须阶段插桩[临时——测后移除]）
./target/release/kerf check crates/kerf-driver/src/bootstrap/compiler.krf
```

> 对照纪律：release 口径 + 同机同核数 + bench 先验证后计时；重大性能演进（QBE 默认化/HM 优化）须重跑本表并追加版本行（只追加不覆盖——worklog 纪律同源）。

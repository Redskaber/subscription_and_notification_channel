# 常量声明窗（const declaration——绑定性质面）设计单源 v1.0

> **窗编号**：r161 / 231 族（231-a..231-e）
> **窗性质**：目标语言表面语法补全 + 最小只读语义闭环（one face, one name 轨迹第八步：绑定性质面——可变轴/只读轴的显式皮肤）
> **开窗依据**：M1 指令开窗第六十六例——用户明示「缺少常量的定义和描述从语法到具体语义和实现」+ 231-b-audit 十项审计裁定（常量 = 唯一完全缺失面 P1；四面俱缺实锤：关键字域无 const / EBNF 无产生式 / 实现无受理 / 文档无承诺——mut 修饰词为 no-op 剥离，绑定性质轴未编码）
> **状态**：Closed（r161 / 231-e 收口——D1-D10 全兑付 + v1.1 三修订：①import/use/extern 移除域外化[模块命名空间声明非值绑定——跨命名空间交互 = Stage 2+ 类型系统域] ②重绑移除语义修正[内核 E0004 平表不变量预存——顶层重名 define 俱拒；移除的正确性 = 使更深错误位浮现{E0004 于重绑点 vs E0001 于后继 assign}] ③增长签名 215/504/247）

---

## 1. 问题陈述（231-b 审计结论）

**现状**：`.ktf` 目标面无任何常量声明形——

- **值绑定唯二形态** = 项位 `let NAME = e;`（r158——可变默认）与 `fn NAME(...) {...}`；绑定性质（可变/只读）**无语言面编码**：
  `let` 语义 = 可变（`assign` 语句面随时可改——`x = 5;` 顶层合法且真实变更全局，231-b 探针 P2 实证）
- `mut` 修饰词 = 解析后剥离的 no-op（reader.rs `let _ = self.eat(&Tk::KwMut);`——「mutability = outside the core domain」历史注记）；只读方向**零语言面**
- 用户指令①明示缺失：「缺少常量的定义和描述从语法到具体语义和实现」
- 既有架构裁定 D35⑥（01-core-forms.md:216 / 22-namespace-design.md:392）：「Literal→Const NO-GO：const 偏编译期常量概念，不可变性由类型系统保证[原则 23/30]名无需编码」——**该裁定对象 = IR 变体命名（CoreExpr 枚举名），非用户面声明形式**；本窗重审：用户面 const 声明形与该裁定正交（皮肤/骨架轴 vs IR 命名轴），开窗不受其约束；「不可变性终局由类型系统保证」的承诺**维持并重申**（见 D4 诚实边界）
- 12-roadmap.md:264「Stage 1 | 编译期常量折叠 | 依赖：类型检查器稳定」= 编译期折叠优化登记项，与本窗（声明形 + 只读语义）正交

**机制前置确认（231-b/231-c 探针）**：

| 探针 | 结果 | 含义 |
|---|---|---|
| P1 函数体内 assign 模块级绑定 | `let g = list(1); fn bump() { g = list(2); }` ⇒ 2（SetGlobal 打通） | 种子 Reader 可以自举语言自身 assign 面承载 const 集（自举合法性实锤） |
| P2 顶层 assign 语句 | `let x = 1; x = 5;` ⇒ 5 | 项位 assign 拒收目标实存（拒收语义非空转） |
| `const` 今日词法 | 普通标识符（`const x = 1;` ⇒ E0001 解析错） | 新关键字零既有语义冲突 |

## 2. 裁定 D1-D10

### D1 产生式（第十六皮肤映射——as-if-written define）

```ebnf
toplevel_const  ::= "const" identifier [ ":" type ] "=" expr ";" ;
                    (* 顶层/模块项位 → Stx (define identifier expr') ——
                       与 toplevel_let 逐字节同构（r158 先例——皮肤换、骨架不变，原则 31）；
                       类型标注解析后剥离（fn_decl/toplevel_let 先例） *)
```

- `const` = **目标面本地关键字第 14 名**（mut/move/as/halt/pass/macro/pub/use/type/struct/enum/effect/capability 之后——halt/pass/macro 先例：S-expr 面无 const 形，**E0020 共享保留域 28 名零扰动**，原则 27）
- 单绑定**封顶**（逗号多绑定 → fail-closed 专用诊断「top-level const takes a single binding (split into separate const statements)」——toplevel_let 同族对称）
- `const mut` 组合 → fail-closed 专用诊断（语义自相矛盾：只读绑定无可变修饰）
- 项位受理域 = 顶层 + module 项位（parse_item 统一分发，fn/import/export/require/let 同族对称）
- 块位/表达式位 const → domain_out fail-closed（「const declaration (item position only — the read-only binding face)」——mut 块位先例同构）

### D2 双 Reader 锁步（parity 纪律）

- Rust 种子侧（reader.rs parse_item + parse_const_decl）+ bootstrap 镜像侧（reader.ktf parse_item + parse_const_decl 镜像）**同窗同步**
- 诊断消息**字节级一致**（新增四条：const mut 矛盾 / 多绑定封顶 / 块位 domain_out / **项位 assign 拒收**）
- 增长签名锚重校准（reader.ktf payload 指纹——新增 parse_const_decl + const 助手族 + CONST_NAMES 全局，r158/r160 同型义务）

### D3 最小只读语义闭环（项位 assign 拒收——本窗核心语义）

**语义**：const 声明的绑定在**项位语句面只读**——

- **Reader 单遍顺序 const 集**：解析 `const NAME = e;` 时记入；解析项位 assign 语句 `NAME = e;` 时若 NAME ∈ 当前 const 集 → `ReadError`（E0001 读面族）：
  消息 = `"cannot assign to a const binding (const bindings are read-only; rebind with let for mutation)"`，Span = NAME Token 本位（r130 import-as 诊断先例）
- **重绑定移除**（顺序语义——最新绑定胜出）：const 之后的同名项位绑定（`let` / `fn` / `macro` / `extern` / `use` / `import`〔含别名〕 / `module`）→ 从 const 集移除（该名重回可赋值域）；
  `const x = 1; let x = 2; x = 3;` ⇒ 合法（x 由 let 重绑）
- **模块作用域**：进入 `module M { ... }` 体 → const 集保存/清空（模块体内 const 为模块局部）；退出 → 恢复外层集。
  `let x = 5; module M { const x = 1; } x = 6;` ⇒ 合法（顶层 x 为 let 绑定——模块 const 不外溢）
- **实现载体不对称同构**：Rust 侧 = Reader 结构体字段 `const_names`（单遍就地判定）；种子侧 = reader.ktf 模块级可变全局 `CONST_NAMES` + assign 面就地更新（P1 探针实证的 SetGlobal 通道——**自举语言自身可变语义的合法自举消费**，种子纯函数式风格的首次 assign 面使用，锚定于「可变性语义由 assign 语句面承载」既有裁定）；两侧俱为**解析中就地判定**——错误定序天然一致（parity 成立的机制根据）
- 种子 `parse()` 入口重置 CONST_NAMES（每文件独立 const 域）

### D4 诚实边界（v0 只读面范围——D35⑥ 重申）

| 位置 | v0 行为 | 依据 |
|---|---|---|
| 项位 assign `x = e;` | **拒收**（E0001） | D3 本窗实施 |
| 函数体/if 块/while 块内 assign | **不拒收**（运行时 SetGlobal 生效） | Reader 无作用域跟踪（遮蔽不可判定——`const x; fn f(x) { x = 2 }` 参数遮蔽合法 vs 全局穿透非法不可分）；**完整不可变性 = Stage 2+ 类型系统保证（D35⑥ 维持重申，原则 23/30）** |
| do-拼接域内 assign | 不拒收 | 表达式位（parse_macro_arg 桥域外） |
| 跨模块 const 导出 | 不拒收 | 同上类型系统域 |
| 编译期常量折叠 | 登记态维持 | 12-roadmap.md:264 Stage 1 既有登记（正交） |

电池含边界锚定用例（函数体 assign 现行行为正向断言——诚实申报非缺陷）。

### D5 语义零变更（皮肤/骨架同构——原则 31）

- `const NAME = VALUE;`（项位）→ Stx `(define NAME VALUE')` 与 `let NAME = VALUE;`（项位）**逐字节同构**（const 性消费于 Reader 层——D3 项位拒收——下游 expander/compiler/HM/VM **全链零触碰**）
- 8 原语不变性第四十三轮；零新原语零通道零 CoreExpr/IR/操作码

### D6 mut 轴连带裁定（可变/只读双轴收口）

- `let [mut]` 维持 mut 剥离（assign 语句面 = 既有可变面——r158 先例不变）
- `const` = 只读面（项位拒收实施）
- **绑定性质轴收口**：可变（let + assign 面）/ 只读（const 面）双轴俱备；`const mut` 矛盾拒收（D1）——mut 修饰词域收敛为 let 族专属

### D7 测试电池（GATE 5/6 构成）

新增 `tests/v0/stage3/plan/ktf_const_decl_tests.rs`（32 case = 8 正 + 24 负 1:3，ktf_*_tests 族同构）：

- **正向 8**：const E2E 值消费 / const 跨 fn 消费 / 类型标注剥离 / 模块作用域不外溢（let-顶层 + module-const + 顶层 assign 合法）/ as-if-written 同 Stx 断言（const ↔ let 字节级）/ 重绑定胜出（const→let→assign 合法）/ 诚实边界锚（函数体 assign 现行行为断言）/ 语料迁移复锚（gc_stress keep ⇒ 输出逐字节）
- **负向 24**：项位 assign 拒收（消息+Span × 双 Reader 字节级 parity ×3 面）/ const mut 矛盾（双 Reader parity）/ 多绑定封顶（双 Reader parity）/ 块位 domain_out（双 Reader parity）/ 缺 `=` / 缺名 / 缺 `;` / 非法类型标注 / 路径名拒收（expected a binding name）/ 模块体内 assign 拒收 / 7 类错误覆盖族（E0001/E0002/E0004/E0005/E0006/E0014 族 ≥6 类负向）
- 集成 ≥3：正向 ≥1（E2E 值消费）/ 负向 ≥3（拒收 ×3 路径）/ 跨阶段消费 ≥1（HM check 面零诊断）

### D8 治理回写（§8.5 清单八件）

02-syntax-model.md（toplevel_const 产生式 §8.13.1a 族 + v7.29 头行）/ 20-surface-conventions.md（§14 第十六映射行 + v1.40）/ 18-terminology.md（const 词条复核）/ tests/matrix.md（r161 行 + 总量 1916）/ RELEASE.md（r161 节）/ t3plus-trigger-audit.md（v1.81 消费注记）/ tech-debt-register.md（**TD-037 新登记 P3 触发式**：`==`/`eq` 值域缺口——231-b 审计附带发现 `true == true` ⇒ E0004 实锤；**顺修**：12-roadmap.md:571「效应行收集 analyzer 既有」表述与零 EffectRow 实况张力修正）/ 本文件 Status: Closed。

### D9 web 同步（用户指令④）

kerf-data.ts 三处（ROADMAP status r161 + RELEASE_HIGHLIGHTS 前插 + PACKAGE_CONTENTS 1916 行）+ hero 三处（hint 1884→1916 + badge + 描述 span r161 长文）+ footer 三处（v8.00 注记 + timeline r161 行 + 底行）+ download README r161 节 + stats 双源自动（matrix 总量行 stats 解析源）。

### D10 打包（§19 三验）

`kerf-v1.0.0-r161-constdecl-1916tests.tar.gz`（名按实测 test 数）——commit-then-package 两遍 + 成员/字节/sha256 + 独立解包净构建 + 包内 test 复跑 + CLI 新面探针（`const X = 5; X + 1` ⇒ 6 / 项位 assign 拒收 rc=1）。

## 3. 不变量六条

1. 8 原语不变性第四十三轮（expander/compiler/HM/VM 零触碰——const 性止于 Reader 层）
2. E0020 共享关键字域零扰动（const = 目标面本地关键字第 14 名——halt/pass/macro 先例，原则 27）
3. Stx 核心形 `(define name value)` 零变更（皮肤换、骨架不变——原则 31）
4. `.krf` S-expr 面 define 原生形维持（自举/parity 面本名——const 仅 .ktf 目标面皮肤）
5. 双 Reader 正典渲染/错误面字节级 parity 维持（新增四诊断双侧锁步）
6. 项位 assign 拒收 = E0001 读面族（Reader 层静态判定——零运行时机制）

## 4. 域外表（§7 纪律）

| 项 | 处置 |
|---|---|
| 函数体/块内 assign const 名 | 域外维持（Stage 2+ 类型系统域——D35⑥ 重申；电池边界锚诚实申报） |
| do-拼接域 assign | 域外维持（表达式位） |
| 编译期常量折叠 | 登记态维持（12-roadmap Stage 1 既有——正交） |
| `.krf` S-expr 面常量形 | 域外（S-expr 面 define 本名既有——无 const 皮肤义务） |
| 种子自举语料 const 迁移 | 域外（种子 = parity 锚——零义务迁移；examples 演示性迁移例外） |
| 跨模块 const 导出执法 | 域外（类型系统域） |

## 5. 收口增补（v1.1——实施期发现回填）

- **种子源 IR 标签重命名（D5 实施前置）**：新关键字 `const` 与 compiler.ktf 的 `quote(const)`（常量池节点外标签 `('const tag value)`——8 处代码位）词法冲突 → 重命名 `const` → `constant`（全词——r102 命名现代化纪律；桥 const_from_value 结构性忽略外标签[f[0] 不参与匹配]——零桥代码变更，仅注释同步；.krf S-expr 面无关键字零冲突）。
- **内核 E0004 平表不变量（D3 修订）**：顶层重名 define（含 const→let / const→fn / const→const / 顶层↔模块体）俱 E0004 "duplicate variable definition"（预存语义——const 合成 Stx 与 let 逐字节同构故非回归；p-a 平行 let 双定义同错实证）。重绑移除的正确性 = 诊断深度：`const x; let x; x = 3;` → 移除使 E0004 浮现于重绑点（第一错误位）vs 无移除则 E0001 掩蔽于后继 assign。
- **模块平表碰撞（D3 边界注记）**：`let x; module M { const x; }` → E0004（内核 define 表平表——模块体名字与顶层碰撞预存；Reader 级模块作用域{保存/清空/恢复}不延伸至内核名表——p-b 实证模块 const 不外泄{顶层同名 assign 创建新全局 ⇒ 2}）。
- **D4 诚实边界实证（p-c）**：`const x = 1; fn f() { x = 2; } f(); x` ⇒ 2——函数体 assign 域外维持（运行时 SetGlobal 生效）；32 case 电池含正向边界锚。
- **D3 域外修订（import/use/extern）**：原设计列 import〔含别名〕/use/extern 于移除族——实施修订为域外维持：三者俱模块命名空间声明（模块名域非值绑定域），const 门域 = 值绑定项位 assign；跨命名空间交互 = Stage 2+ 类型系统域。原实施中的 import 移除块（别名+路径尾 over-collection）当场检除。
- **增长签名锚重校准**：reader.ktf payload 211→215 protos（+4：const_has/const_remove/const_add/parse_const_decl）/ 494→504 consts（+10：助手族字面量 + "const" kind 串）/ 242→247 globals（+5：CONST_NAMES + 助手族名引用）——多函数增长签名（r158/r160 单函数型对照）。
- **测试期望修正（内循环第 2 轮——r160 同型）**：print 末值 nil（程序值 = 末表达式非打印输出）/ 合成 define Span = 关键字 Token 本位（const 0..5 vs let 0..3——r158 先例合法差异，结构同构断言替代字节渲染断言）/ 同因第三处。
- **探针矩阵（231-c 全实录）**：c1 ⇒ 6 / c2 拒收 / c3-c10 与 p-a..p-e 俱在案——十探针 + 五边界探针全录 RELEASE_NOTES r161 节。

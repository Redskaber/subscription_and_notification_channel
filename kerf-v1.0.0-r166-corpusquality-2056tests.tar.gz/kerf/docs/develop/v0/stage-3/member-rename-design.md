# 成员重命名 / module 头部选择形设计（use 窗遗留触发式域外二项清偿——S-expr 面选择形扩展窗）

> **Author**: kerf-dev-agent（Super Z main — ARCH-A 裁定 + DEV-A 实施；r134 / 204-a 设计先行腿）
> **Date**: 2026-11-08
> **Version**: v1.4（r144 / 214-e read-line 签名条目窗清偿回写——§7 io read 族行翻转[清偿关闭：read-line 双侧在表——read-int/read-num r140 + read-line r144 全族覆盖；r135 D12 派生链 miss-skip 零在世 miss{防御性路径维持}]）；v1.3（r140 / 210-e TC-SIGS Oracle 对齐窗清偿回写——§7 TC-SIGS 子集不对称行翻转[清偿关闭：check.krf 24→61 逐行同构扩表] + io read 族行重锚[read-int/read-num 已覆盖——read-line 维持缺位]）；v1.2（r135 / 205-a 域外三项清偿设计腿——§8 新增 D11-D16：HM 签名派生 + 门控面改名感知 + prelude 模块实例面；§7 域外表前三行翻转为清偿态）；v1.1（r134 / 204-d：D3/D6 翻转——域外二项清偿回写）；v1.0（r134 / 204-a 设计先行腿）
> **Status**: Active（设计单源——本文件 §2 为 02-syntax-model §8.13.1a v7.19 产生式的规范锚；Reader 解析域开放以本文件定稿域边界为据）
> **处理程度**: P0（v1.0 窗交付 = 双侧 Reader + 消费链 + expander 头部扫描 + 32 case 门 + 文法登记四件；v1.2 窗交付 = HM 派生双侧 + E0006 反查 + prelude 注入 + 32 case 门）
> **开窗依据**: v1.2 = 用户 r135 指令①「继续推进 目标语言设计的实现窗…按推荐顺序直接推进进入对应窗口开始具体实施」行权（M1 指令开窗第四十例）；推荐序首位 = r134 收口笔触发式余项成熟度匹配排序（本文件 §7 前三行——设计载体在位 + 实施点 r134 已实读 + r74 先例锚指令即需求信号本体）；TD-033 组安装语义居后维持（机制层 VM 变更风险高）

---

## 1. 问题陈述

**use-declaration-design.md v1.0 §7 诚实边界表前二行清偿**（r131 交付的触发式域外二项——本轮用户指令①行权开窗）：

| 域外项 | r131 登记态 | 触发判据 | 本窗处置 |
|---|---|---|---|
| use_tree `as` 成员重命名（D3） | 目标面 Reader 专用诊断域外（两处）+ S-expr 面选择列表无 as 语义（消费链把 as 收集为成员名 → E0024 自然拒绝） | S-expr 面选择形扩展窗开窗时同步双侧受理 | ❌→✅ 本窗清偿（双侧受理） |
| 选择形在 module 头部（D6） | expander 头部扫描 E0002「import 项必须是符号」双侧同拒（r50/D65 既有语义边界） | S-expr 面头部扫描器扩展窗（与成员重命名同族触发） | ❌→✅ 本窗清偿（头部扫描器扩展） |

**核心设计事实（判据先于先例——本窗代码实读实证四件）**：
1. **S-expr 面成员重命名的实施点 = driver 消费链单点**（S-expr Reader 零变更）：选择列表成员解析在 `collect_import_items`（driver.rs:972-977——`for m in sel { as_symbol → members.push }` 裸符号收集）；`as` 在 S-expr 面本为普通符号（import 顶层 as 对同型——上下文语义标记）。扩展该循环支持 `local as renamed` 三元组即完成 S-expr 面受理。
2. **运行时分派面 = 全量注册零改名感知**（builtins.rs register_globals 全量平铺面 + 限定名面——「dispatch-table basis」）；E0022 可见面在前端（verify_unbound_refs 消费 face.flat_underlying）。**改名绑定的运行时注入 = run_front 附加注入单点**（globals[renamed] = underlying 的 Builtin——与限定名共享 underlying 分派体同构）。
3. **HM 面双侧 A4 Dynamic 零误报**：自举 check.krf `tc-infer-var` 环境未命中 → Dynamic（A4 纪律——无约束无报告，check.krf:536-540）；Rust oracle hm.rs `infer_expr` Var 未命中 env → Dynamic（hm.rs:649-657 同型）。renamed 名 ∉ 签名表 → 保守 Dynamic——**check 面零扩展零误报**（诚实边界：改名绑定的静态类型 = Dynamic——与「builtin 值位」同款 A4 面）。
4. **module 头部选择形的拒绝点 = expander 头部扫描单点双侧共享**：种子 core_forms.rs:648（`import 项必须是符号`）+ 自举 expander.ktf:2498（module_names 同消息）——目标面 `module m { use mod::{a}; }` 经 Reader 产出 `(module m (import mod (a)) ...)` 与 S-expr 面手写形同入该扫描器；driver 的 collect_module_header_imports 调用 collect_import_items 共用（选择列表解析扩展后自动继承）。

**归一化方案裁定（ARCH-A——方案对比）**：alias 先例（r40 M2）= CoreExpr Var 重写（限定名 `str/append` → `string/append`，front_from_core 2.7）。成员重命名**不采**重写方案：限定名含 `/` 天然跳过 E0022（driver.rs:2056），而改名绑定是**平铺名**——重写后 global_refs 含 underlying 会与 E0022 可见面（flat_underlying 含 renamed 不含 underlying）冲突产生误报；反向豁免（defined ∪= 重写目标集）则放行 underlying 直写——破坏替换语义锚。**裁定：运行时注入方案（方案 B）**——E0022 反向锚精确（underlying 直写 → E0022 ✓）+ CoreExpr 零重写 + HM A4 天然覆盖。

## 2. 语法（定稿域——02 §8.13.1a v7.19 规范锚）

```ebnf
(* ---------- Level 0 增补（r134——use_tree 成员重命名；语义 = 既有 *)
(* s-expr 面选择列表 as 三元组（本窗消费链扩展）的纯皮肤映射 + *)
(* module 头部选择形受理（expander 头部扫描域扩展）——零新原语 --- *)

use_tree        ::= identifier [ "as" identifier ] ;   (* D2——成员重命名增补形 *)
```

**表面序与 Stx 序同构声明**：`use kerf_string::{append as sa};` → `(import kerf_string (append as sa))`——选择列表内**平铺三元组**（local、as、renamed 三个符号元素——与 import 顶层 as 对同构，D9 消费者序纪律沿袭：消费链 i 位符号 + i+1 位 as 判定 + i+2 位 renamed）。

**module 头部选择形**（无新产生式——module 头部区的 import 形域扩展）：

```ebnf
module_header_import ::= "(" "import" import_item { import_item } ")" ;
import_item         ::= module_name [ "as" alias ] [ selection_list ] ;   (* 选择列表在头部区受理 *)
```

## 3. 裁定表（D1-D10）

### D1：S-expr 面选择列表 as 三元组受理（消费链单点扩展）

**裁定**：`(import kerf-string (append as sa length))`——选择列表内元素序列解析为成员条目：`local` 裸符号 → (local, None)；`local as renamed` 三元组 → (local, Some(renamed))。实施点 = collect_import_items 选择列表成员循环（i 游标步进——裸符号 +1、三元组 +3）。S-expr Reader 零变更（as 本为普通符号——§1 事实 1）。

**形状执法（消费链 fail-closed——三层专用消息族）**：
- 首槽 as（`(import m (as sa))`）→「选择列表成员名不可为 as（成员重命名缺左操作数——形：`名 as 别名`）」
- as 尾（`(import m (append as))`）→「成员重命名缺别名标识符（as 右操作数——形：`名 as 别名`）」
- as 后非符号（`(import m (append as 42))`）→ 同族「成员重命名缺别名标识符」

执法面 = driver 消费链（顶层位 + module 头部位共用——collect_import_items 单点）。expander 头部扫描的选择列表预检仅「成员全为符号」（as 是符号——自然通过；三元组形状完整性由消费链执法——§1 事实 4 分层）。

### D2：目标面 use_tree `as` 受理（r131 D3 域外翻转）

**裁定**：`use kerf_string::{append as sa};`——花括号内成员位 Ident 后随 KwAs 后随 Ident/Path → Stx `(append as sa)` 平铺入选择列表（as 符号——与 S-expr 面同构）。种子 parse_use_decl 的 D3 两处域外诊断（首槽 as 1267-1273 / 成员后 as 1286-1293）**翻转**：
- 首槽 as（`use m::{as x};`）→ 维持既有「期望成员名，实际 as」自然错误面（bump 匹配 Tk::Ident 才受理——KwAs 落 other 臂——**零新消息**）
- 成员后 as → 受理臂（expect Ident/Path 为 renamed）+ 缺右操作数专用消息「期望成员重命名标识符，实际 {:?}」（eof/RBrace/Semi/Int/KwAs 等形全覆盖）
- 镜像 target_reader.krf use-member/use-member-sep 同步翻转 + use-member-alias 新函数（as 后 ident|path 受理）

### D3：改名绑定语义（替换式注入——r50/D65 选择语义延拓）

**裁定**：`(append as sa)` ⇒ **`sa` 平铺可用**（renamed → underlying 分派体注入）；**原 underlying 名（`string-append`）不再平铺可用**（E0022——renamed 替换 underlying 的注入位）；原 local 名（`append`）不可用（E0022——既有 D65 语义不变：local 名仅作过滤器）；**限定形 `string/append` 不受影响**（模块级导入关系维持——D65 同款「选择 = 平铺命名空间卫生非模块关系裁剪」）。

**注入面派生（collect_import_face 改名感知）**：
- injected_names（E0013/W1002 lexical 面）：改名成员 push renamed（裸成员 push local——现状）
- flat_underlying（E0022 可见面）：选择性模块 per-member 注入——改名成员 push renamed、裸成员 push underlying；prelude 分支同型（改名 push renamed、裸 push 名本身）；全量模块不变（module_flat_underlying 全量——改名不适用于全量导入面[无选择列表即无 as 对]）
- E0024 按名检查不变：改名成员按 local 名验 ∈ 导出面（renamed 是用户名不验）

**全量+选择共存**：first-seen/union 语义沿袭（d66 组尾锚）——改名成员仅在选择列表语境生效。

### D4：运行时注入（run_front 单点——与限定名共享分派体同构）

**裁定**：FrontOutput 增量字段 `member_rename_binds: Vec<(String, String)>`（renamed, underlying——编译面零重写、CoreExpr 零触碰）；run_front 在 register_globals 之后附加注入：`globals[intern(renamed)] = globals[intern(underlying)].clone()`（共享 underlying 的 Builtin 分派体——与 STLDIB_MODULES 限定名注册同构 builtins.rs:965-970）。underlying 查询 miss（理论不可达——非门控模块的 underlying 恒注册）→ 跳过（fail-closed 不 panic——防御路径）。

**E0022 反向锚精确性**（方案 B 核心收益）：global_refs 含用户直写名——`sa` ∈ flat_underlying ✓ 放行；`string-append` ∉ flat_underlying（被 renamed 替换）→ E0022 ✓；运行时 E0004 深度防御面不变。

### D5：module 头部选择形受理（r131 D6 域外翻转——expander 头部扫描双侧）

**裁定**：expander 头部扫描器（种子 core_forms.rs expand_module_item + 自举 expander.ktf module_names）import 项循环遇**列表项**（非符号）：
- **首位列表**（i=1——缺模块名）→ 维持 E0002「import 项必须是符号」（现状消息自然覆盖——列表非符号）
- **第二位起列表**（模块名已收集后）→ **选择列表**：预检「成员全为符号」（嵌套列表/非符号成员 → E0002 同消息维持）→ 跳过整列表项（i += 1——模块名已在前位 push，imports 模块级关系维持）
- driver collect_module_header_imports 共用 collect_import_items——选择列表解析（含 as 三元组）自动继承 ✓
- E0014 面（R-N3 模块 ∈ import-set）：imports 含选择形模块名——限定引用 `string/append` 合法 ✓

### D6：ImportFace 结构扩展（加性——冻结面零扰动）

**裁定**：新增 `member_renames: Vec<(String, String, String)>`（ns, local, renamed）平铺条目（Default 空向量——非改名程序零开销）；`selected: Vec<(String, Vec<String>)>` **维持**（E0024 按 local 名验——改名不改 selected 形状，renamed 信息独立承载）。member_rename_of(face, ns, local) → Option<&renamed> 查询助手（派生段/注入段消费）。

### D7：重复改名与别名同域查重（E0017 族扩展）

**裁定**：verify_import_face E0017 段扩展——**用户绑定名同域合并查重**（aliases 键 ∪ member_renames 的 renamed 键）：
- 同一导入面内 renamed 双绑定（`(import m (append as sa length as sa))`）→「成员重命名重复：「{name}」（同一导入面内每成员重命名至多一次）」
- renamed 与模块别名同名（`(import m as sa (x as sa))`）→「成员重命名与别名同名冲突：「{name}」（成员改名绑定与模块别名同属用户绑定名——同域唯一）」
- 依据 §2.3（报错>静默）——静默遮蔽 = 后绑定覆盖先绑定的隐患面。

### D8：io / prelude 成员改名域外（门控与重导出面 fail-closed）

**裁定**：改名域 = STDLIB_MODULES 中**非 io 非 prelude 的六模块**（string/symbol/char/list/pair/core——非门控平铺分派面）：
- io 成员改名（`use io::{write as w};`）→ E0024 面前置专用拒绝：「io 模块成员不支持重命名（门控模块——改名绑定绕过 E0006 授权名单的编译期匹配；门控面改名感知 = 触发式后续窗口）」——依据：io 限定名按授权注册（builtins.rs:947-963 fail-closed），改名绑定 run_front 注入时 underlying 可能未注册 → 平铺引用 `w` 不含 `/` 不入 R9 门控匹配 → 运行期 E0004 深度防御兜底——编译期拒绝优于运行期报错（fail-closed 前置）。
- prelude 成员改名（`use prelude::{map as m};`）→ 同面拒绝：「kerf-prelude 成员不支持重命名（重导出面 local=underlying 恒等 + 模块体 define 分派——改名绑定注入需模块实例面扩展；触发式）」
- 检查点：verify_import_face E0024 段前置（ns == "io" || ns == "prelude" 且该成员有 rename → 专用消息）。

### D9：Span 契约

**裁定**：目标面 renamed Span = ident 本位；as 标记 Span = as 本位（诊断锚——D10 r130 清偿形沿袭）；成员整体三元组无独立 Span（Stx 平铺三符号各自本位）。S-expr 面：符号本位自然继承（Reader 零变更）。缺右操作数诊断 Span = as 后 Token 本位（peek 位置——与「期望别名标识符」族同规）。

### D10：锚翻转义务（本窗三组）

| 锚 | 文件 | 翻转 |
|---|---|---|
| D3 域外双形锚（use m::{as x} / use m::{a as x} 两 case） | ktf_use_decl_tests.rs:475-490 | 域外诊断消息锚 → 受理形正例迁移（新测试文件承载）+ 首槽 as 锚改为「期望成员名，实际 as」既有面锚 |
| module 头部选择形双侧拒锚 | ktf_use_decl_tests.rs:539-552（neg_use_module_header_selection_e0002） | 双侧 E0002 拒绝锚 → 双侧受理正例（E2E 值断言） |
| E0002 非符号项锚 | negative_expander_tests.rs:189（`(module m (import 1))`） | **维持**（1 非符号非选择列表——负例语义不变） |

## 4. 诊断面（新增消息族——双侧字节级 parity）

| 消息 | 触发 | 层 | 家族先例 |
|---|---|---|---|
| 「选择列表成员名不可为 as（成员重命名缺左操作数——形：`名 as 别名`）」 | S-expr 面选择列表首槽 as | driver 消费链 | 「import as 别名须跟在模块名后」族平行 |
| 「成员重命名缺别名标识符（as 右操作数——形：`名 as 别名`）」 | S-expr 面 as 尾 / as 后非符号 | driver 消费链 | 「import as 别名缺右操作数」族平行 |
| 「期望成员重命名标识符，实际 {:?}」 | 目标面 as 后非 Ident/Path（eof/}/;/Int/KwAs 形） | 目标面 Reader | 「期望别名标识符」族平行（r130） |
| 「成员重命名重复：「{name}」（同一导入面内每成员重命名至多一次）」 | renamed 双绑定 | verify_import_face E0017 族 | E0017「别名重复」族平行 |
| 「成员重命名与别名同名冲突：「{name}」（成员改名绑定与模块别名同属用户绑定名——同域唯一）」 | renamed == 模块别名 | verify_import_face E0017 族 | 同上 |
| 「io 模块成员不支持重命名（门控模块——改名绑定绕过 E0006 授权名单的编译期匹配；门控面改名感知 = 触发式后续窗口）」 | io 成员 as | verify_import_face D8 | 门控族 fail-closed 平行 |
| 「kerf-prelude 成员不支持重命名（重导出面 local=underlying 恒等 + 模块体 define 分派——改名绑定注入需模块实例面扩展；触发式）」 | prelude 成员 as | verify_import_face D8 | 同上 |
| E0022（改名后 underlying/local 直写） | `use m::{append as sa}` 后引用 string_append / append | verify_unbound_refs | 既有——零新增 |
| E0024（改名成员不在导出面——按 local 名） | `use m::{nope as x}` | verify_import_face | 既有——零新增 |
| E0019（多段路径/未注册名改名形） | `use kerf::string::{a as b}` | verify_import_face | 既有——零新增 |
| E0002（头部选择列表嵌套列表/非符号成员/首槽列表） | `(module m (import kerf-string ((append))) ...)` 等 | expander 头部扫描 | 既有消息维持 |

## 5. 测试矩阵（32 case 门——8 正 + 24 负 = 1:3，§9.4.3）

**正向八族**：① 目标面改名 E2E（`use kerf_string::{append as sa}; sa(...)` ⇒ 值断言）② S-expr 面改名 E2E parity（`(import kerf-string (append as sa))` ⇒ 同值——跨语法行为等价）③ 改名 + 限定访问不变 E2E（sa + string/append 双可用同值）④ 混合成员（裸+改名同列表：`(append as sa length)` ⇒ sa + string-length 双可用）⑤ module 头部选择形 S-expr 面 E2E（`(module m (import kerf-string (append)) ...)` 头部受理 ⇒ m 内可用——D6 翻转正例）⑥ module 头部选择形目标面 E2E（`module m { use kerf_string::{append}; ... }` ⇒ 同值——双侧同界）⑦ 双 Reader 正典渲染 parity（改名形 Stx 字节级 + module 头部选择形——含 as 三元组 Span）⑧ check 跨阶段消费零诊断（改名程序 HM A4 Dynamic 锚——零 E0005 误报）。

**负向二十四族**：目标面首槽 as（既有「期望成员名」面）/ 目标面 as 缺右（} 形）/ 目标面 as 缺右（; 形）/ 目标面 as 后 Int / 目标面 as 后 KwAs（`{a as x as y}`）/ S-expr 面首槽 as / S-expr 面 as 尾 / S-expr 面 as 后非符号 / 改名重复（E0017 族）/ 改名与别名同名（E0017 族）/ E0024 改名成员不在导出面 / E0022 改名后 underlying 直写（反向锚——替换语义实证）/ E0022 改名后 local 名直写（D65 既有锚维持）/ io 成员改名域外（D8）/ prelude 成员改名域外（D8）/ module 头部选择形嵌套列表（E0002 维持）/ module 头部首槽列表（E0002 维持）/ 目标面 module 头部 use 空花括号（既有「期望成员名」）/ 双 Reader 错误面 parity（as 缺右操作数——消息 + Span 字节级）/ 双 Reader 错误面 parity（E0002 头部形——双侧 expander 共享面同渲染）/ E0019 改名形多段路径 / E0019 未注册名改名形 / 块内位 use 改名（E0001 既有）/ pub use 改名（pub 域外既有）。

## 6. 实施对账

| 件 | 落位 | 遵循 |
|---|---|---|
| 种子 Reader | kerf-reader/src/target.rs：parse_use_decl D3 两处翻转（首槽 as 维持既有面 + 成员后 as 受理臂 + 缺右专用消息） | §10 命名 / 原则 31 |
| 镜像 Reader | kerf-driver/src/bootstrap/target_reader.krf：use-member/use-member-sep 翻转 + use-member-alias 新函数（种子同构） | 种子同构（rderr-tok 经桥 tk_debug_of_kind 单源） |
| 消费链 | kerf-driver/src/driver.rs：collect_import_items 选择列表 as 三元组解析 + 形状执法三消息 + ImportFace.member_renames 字段 + 派生段改名感知（injected_names/flat_underlying）+ verify_import_face（E0017 合并查重 + D8 域外前置）+ FrontOutput.member_rename_binds + run_front 附加注入 | §2.3（报错>静默）/ 原则 27（加性）/ D65 延拓 |
| expander | kerf-expander/src/core_forms.rs：expand_module_item 头部扫描选择列表受理（预检成员全符号 + 跳过）+ bootstrap/expander.ktf module_names 同步镜像 | 原则 31（双侧同构） |
| 测试 | tests/v0/stage3/plan/ktf_member_rename_tests.rs（新文件 32 case）+ runner.rs 挂载 + ktf_use_decl_tests.rs 锚翻转三组 | §9.1/§9.4.3/§9.5 |
| 文法 | 02 §8.13.1a v7.19（use_tree as 增补形 + module 头部选择形注记 + D3/D6 域外注记翻转）/ 20 §14 v1.26（第十一映射域扩展注记）/ 22 注记（module 头部选择形受理）/ use-declaration-design.md v1.1（§7 域外表前二行翻转） | 原则 44 产生式义务 |
| 治理 | t3plus v1.54 / RELEASE r134 / matrix r134 / switch-window-plan 注记 / README / rec 95 / 根层 l / worklog 三链 | §8.5/§8.6 |

## 7. 诚实边界（域外登记表——触发式）

| 域外项 | 载体 | 触发判据 |
|---|---|---|
| ~~io 门控面改名感知（E0006 名单编译期改名反查）~~ | ~~本文件 D8~~ | ✅ r135 清偿（本文件 §8 D13——E0006 反查 + D8 io 行撤销） |
| ~~prelude 模块实例面改名绑定注入~~ | ~~本文件 D8~~ | ✅ r135 清偿（本文件 §8 D14——Stx 层注入 + D8 prelude 行撤销 + 增量别名语义裁定 D14-③） |
| ~~改名绑定的 HM 静态类型（恒 Dynamic——A4 面）~~ | ~~本文件 §1 事实 3~~ | ✅ r135 清偿（本文件 §8 D12——签名表派生双侧；值位恒 Dynamic A4 纪律维持） |
| pub(scope) 可见性粒度 | 22 §7 既有登记 | Stage 2+ 权限矩阵窗口（沿袭 r131 §7） |
| 多段路径模块名 / 嵌套选择树 | use-declaration-design.md D1（沿袭） | 单层裁定恒态——无触发 |
| ~~io read 族改名绑定的 HM 签名（read-line 无签名条目——builtin 值位同款；read-int/read-num ✅ r140 TC-SIGS 扩表覆盖[定形零参 unknown→fresh]）~~ | ~~本文件 §8 D12-③~~ | ✅ r144 清偿（read-line 签名条目窗 214-a..214-f——设计单源 read-line-sig-design.md v1.0：read-line 双侧在表{fixed 0 参 Unknown——read-int/read-num 家族形}，io/read-line 限定名派生 + read-line as rl 改名链自动收紧；r135 D12 miss-skip 诚实边界零在世 miss{防御性路径维持}；本行翻转 = io read 族全族覆盖{read-int/read-num r140 + read-line r144}） |
| prelude 改名绑定的 pub(scope) 粒度（define 面身份的可见性收窄） | 本文件 §8 D14-③ | Stage 2+ 权限矩阵窗（与 pub(scope) 同族） |
| ~~TC-SIGS 子集不对称（check.krf 签名表 23 条 ⊂ Rust oracle BUILTIN_SIGS 56 条——33 个 oracle 签名成员在 krf 面走 A4 Dynamic 通用路径不静态拒收；krf ⊆ oracle 契约方向合法[krf 拒收集合更小]）~~ | ~~本文件 §8 D12-③~~ | ✅ r140 清偿（TC-SIGS Oracle 对齐窗 210-a..210-f——check.krf 24→61 逐行同构扩表 + 'sigf 定形异参形 + 新 kind 四族 + Int 参 Num 域宽化 + string-append 行修正；设计单源 tc-sigs-parity-design.md v1.0；32 case 门 + 同窗锚翻转三件真检出裁定[krf 6⊆oracle 80/2⊆27/3⊆31 方向守卫维持]） |

## 8. 域外三项清偿设计（r135 / 205——D11-D16）

### D11 窗口范围与行权依据

本窗 = 本文件 §7 前三行触发式域外项清偿（HM 签名派生 + 门控面改名感知 + prelude 模块实例面——r134 交付时登记的三项同族域外余项）。行权依据：用户指令①开窗（M1 第四十例——r74 先例锚「指令即需求信号本体」）；推荐序首位 = r134 收口笔触发式余项成熟度匹配排序（三项均本文件登记、实施点 r134 全实读、设计先行态就绪）。**域内事实基线（本窗实验实证四件）**：①`sa("a","b")` check ok + `sa(1,2)` check ok（A4 Dynamic 零参数检查）vs underlying `string_append(1,2)` 报 E0005——派生前后行为差 = 本窗 HM 腿验收锚；②io/prelude 改名 D8 双拒绝实证（E0024 两消息族）；③`use kerf_prelude::{filter}` 后 map 仍可用（⇒ (1 4 9)）——**prelude 选择导入对 define 面无约束的既有宽松语义**（preamble 全量注入 → 模块体 define 全量 ∈ define 面；flat 只管 E0022 的 flat 位）；④目标面 `string_append` 经 Reader 符号引入边界归一为连字符正典名（`-` ↔ `_` 单点映射——20 §8）→ TC-SIGS/BUILTIN_SIGS 连字符名命中。

### D12 HM 签名派生（renamed → underlying sig 派生——双侧）

- **①语义**：改名绑定的 apply 位签名 = underlying 签名的派生条目（r39 限定名派生同构——`ns/local` → underlying sig 先例在位：builtins.rs builtin_sigs 的 STDLIB_MODULES 派生循环）。**值位恒 Dynamic 维持**（A4 纪律——builtin 值位纪律不改；派生条目仅 apply 位消费——tc-infer-app 快路径/hm.rs apply 臂的签名查找位）。
- **②Rust oracle 面**：`builtin_sigs` 加性扩展——新函数 `builtin_sigs_with_renames(table, renames: &[(String, String)])`（限定名派生循环后追加 renamed 派生循环：`map[renamed] = map[underlying]`——underlying miss 跳过）；`type_check_diags` 的 fallback 臂与 hm 调用点传入 `front.member_rename_binds`（数据流补线：FrontOutput.member_rename_binds → check 链）。
- **③krf 面**：check.krf 入口协议扩展——`lchk-check-program nodes renames`（renames = VM 关联表 `(renamed . underlying)*`——加性协议：空表 = 既有单参行为全等）；全局 `TC-RENAME nil`（入口 reset——与 TC-ENV 同族全局态纪律）；`tc-infer-app` builtin 快路径链式解析：TC-SIGS miss → `assoc-val namestr TC-RENAME` 反查 underlying → TC-SIGS 再查命中 → 按 underlying 签名走 tc-infer-builtin（**诊断归因锚 = 调用位原 Span**——renamed 与 underlying 同 Span，消息不携带改名痕迹——apply 位签名为语义事实非用户面信息）。桥面 check.rs `krf_check_program`/`production_check` 签名扩展（items, renames, table）——renames 构造 VM pair 关联表经 heap。
- **④契约维持**：krf ⊆ oracle（双侧同派生逻辑——零误报契约沿袭 r80）；check 面零 E0005 假阳性（renamed 未派生命中时双侧一致 Dynamic——防御路径）。

### D13 门控面改名感知（io E0006 反查）

- **①D8 io 行撤销**：driver.rs verify_import_face 的 `ns == "io"` 拒绝臂退役——`use kerf_io::{print as pr}` 受理（rename_binds 含 (pr, print)）。
- **①' N1 域派生段（实施补裁定）**：`module_flat_underlying("io")` 返回空集（io/core/pair/char 的 underlying 恒 N1——被 N1 过滤器滤除）→ 这些域的 flat 循环零迭代 → **rename_binds 从未生成**（实施探针暴露的缺口）。补专用派生段：member_renames 的非 prelude 行且 underlying ∈ N1_CORE_NAMES → flat push renamed + rename_binds push (renamed, underlying)（underlying 的 N1 身份不动——增量别名；「print」改名后仍可直用——经 E0006 门）。
- **②E0006 反查**：verify_io_capabilities 感知 renames——verify_refs 的门控匹配扩展：var 名 miss READ_GATED/WRITE_GATED → renamed 反查（pr → print）→ 命中 → 按 underlying 检查 declared（IoRequirements）。数据流：调用点传入 face.rename_binds。**授权后语义**：`require io, write` + `use kerf_io::{print as pr}` + `(pr "x")` ⇒ 合法——renamed 绑定与 underlying 同享授权令牌（能力绑定于 underlying 分派体——改名不产生新能力面）。
- **③诊断面**：未授权时 E0006 消息携带双名（「pr（io 成员 print）需要 write 能力——改名绑定不改变能力要求」形——renamed 用户可见 + underlying 归因）。Span = 调用位（renamed var 位——既有 find 逻辑）。
- **④运行时面**：run_front 注入循环零变更（print ∈ globals[grant 参数化注册] → pr = Rc 共享 ✓）；未授权时 print ∉ globals → pr 注入跳过——编译期 E0006 已前置拦截（fail-closed 先于运行时防御纵深 ✓ §2.3）。

### D14 prelude 模块实例面（改名绑定注入）

- **①D8 prelude 行撤销**：verify_import_face 的 `ns == "prelude"` 拒绝臂退役——`use kerf_prelude::{map as m}` 受理。
- **②注入机制（Stx 层——preamble 注入同构）**：front_from_forms 管线 1.62（face 收集后、E0020 保留字检查前）——对每个 prelude 改名绑定注入 `(define renamed local)` Stx 形（Span = 选择列表元素自身位——`ImportFace.member_rename_spans` 平行数组携带[与 member_renames 同长同序]——用户 use 声明归因锚[实施修正：初版用 import_targets 首位 = preamble 模块头 import 位——探针暴露归因错位后改平行数组]）。注入位置 = preamble 段后、用户 forms 前（file_id 边界定位——底层先绑定[模块体 define 前置序]→别名后绑定）。展开链：注入 define 走 expand → 全局 define → 运行时 = 程序全局 define 执行（零 run_front 改动——prelude 成员非 builtin 注册面）。
- **③增量别名语义（prelude 域 D3 精确化裁定——ARCH-A）**：七模块改名 = **替换语义**（D3——underlying 是 builtin 注册面，不导入即不可见 → renamed 替换平铺注入位 → underlying 直写 E0022 反向锚精确）；prelude 改名 = **增量别名语义**（underlying 的可用性三源全不动：模块体 define 面[自有 HOF：map 等——preamble 全量注入即存在]、N1 核心面[cons/is_* 重导出——恒可见]、flat 面[nth/drop 重导出——prelude flat 分支注入] → `use kerf_prelude::{map as m}` 后 map 依然可用）。**flat 面形态 = 增量双名**（local + renamed 都 push——与七模块的替换单名形成域对比；实施探针修正：单名形态下注入语句的 local 引用[非 N1 非 define 的 nth]E0022 误报 → 双名是增量语义的完整 flat 形态）。W1002 零误报：renamed ∈ flat ∧ renamed ∉ builtin 注册面 → 无 W（r47 face-aware 双条件维持）。
- **④E0022/HM 面**：renamed ∈ flat（双名 push）+ define 面（注入 define 名）双面 ✓；注入语句的 underlying 引用 ∈ define 面[自有 HOF] / N1[cons 等] / flat[nth 等] 三源 → 零 E0022 豁免需求 ✓；HM：`(define m map)` → m = map 的推断类型（泛化闭包）——**无需签名派生**（prelude 成员非 builtin——BUILTIN_SIGS 无条目；define 面自然推断自动覆盖 D12-③ 域外）。**rename_binds 零 push（实施补裁定）**：prelude 域的运行时绑定单路径 = Stx 注入 define——run_front 注入循环若同时注入（underlying ∈ globals 时）会与 DefineGlobal 撞 E0004 重复定义 → prelude 分支不 push rename_binds（HM 派生/E0006 反查对其本就 miss 无害）。

### D15 测试矩阵（32 case 门——8 正 + 24 负 = 1:3，§9.4.3）

扩展 ktf_member_rename_tests.rs（v1.0 32 case 基础上锚翻转 + 新增）——见 §6 实施对账。验收锚四族：HM 派生（sa(1,2) E0005 转负例锚 + sa("a","b") ok 正例 + 值位 Dynamic 零诊断 + krf ⊆ oracle parity）/ io 反查（未授权 E0006 负例 + 授权后 E2E 正例 + 消息双名精确性 + read 族无签名沿袭）/ prelude 注入（m ⇒ 值 E2E + map 增量别名仍可用 + 跨语法 parity + 保留字撞名 E0020 + 重复 define 诊断）/ 既有锚翻转（D8 双拒绝锚退役迁移 + 域外注记翻转）。

### D16 治理边界

非切换窗（六步门控维持——switch-window-plan §3 不变）；8 原语不变性第十四轮验证（零新原语零通道零 VM 指令——E0006 反查 = 编译期检查面、prelude 注入 = Stx 层管线、HM 派生 = 签名表数据面，全部前端域）；§6.2 零开放 P0/P1；技术债零新增（§7 表更新后余项均恒态/Stage 2+ 族）。

*遵循条款：原则 26（成熟度匹配——推荐序首位兑现）/ 原则 27（加性——S-expr Reader 零变更 + ImportFace 加性字段 + CoreExpr 零触碰）/ 原则 31（皮肤/骨架同构——Stx 等价判据 + as 三元组双侧同构）/ 原则 44（新语法成员登记必须附 EBNF 产生式）/ §2.3（报错>静默——D1 形状执法 + D7 同域查重 + D8 门控前置拒绝）/ §2.1.1-11（确定性边界先行——消费链/注入面/扫描器三实施点先读后写）/ §9.4.3（1:3）/ §12（最优>最小——方案 B 语义精确性论证）/ r74 先例（用户指令 = 需求信号本体）/ r131 先例（use 窗 D3/D6 登记载体）/ r130 先例（皮肤映射窗全流程链）。*

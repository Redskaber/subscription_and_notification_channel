# TC-SIGS Oracle 对齐窗设计单源（tc-sigs-parity-design.md v1.3）

> **Author**: Super Z (main) — ARCH-A 裁定 + DEV-A 实施 + QA-A 验证 + REC-A 落档
> **Date**: 2026-11-11（v1.0 首件）；2026-11-12（v1.1——r141 / 211-e 消息文本统一窗回写；v1.2——r142 / 212-e member/assoc 静态面双缺陷窗回写）；2026-11-14（v1.3——r144 / 214-e read-line 签名条目窗回写）
> **Task ID**: 210-a..210-f（r140）；211-a..211-f（r141 回写轮）；212-a..212-f（r142 回写轮）；214-a..214-f（r144 回写轮）
> **Status**: Active（设计单源——本文件 §2-§6 为 check.krf TC-SIGS 扩表的规范锚）
> **处理程度**: P0（窗交付 = 37 行同构扩表 + sig 语言定点扩展 + 32 case 门 + 锚翻转全族 + 方向守卫实测；r141 回写 = §7 行 1 翻转 + 头部版本行；r142 回写 = §7 member/assoc 复审行翻转 + 头部版本行）
> **开窗依据**: 用户 r140 指令①「继续推进 目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施」行权（M1 指令开窗第四十五例）；推荐序裁定 = r139 收口态登记册触发式实施项全清零 + T3+ 14 行零信号 + 门控任务七项全闭 + #15 需 next22.md（未上传）→ 用户指令①「遇未完成窗口直接推进」逐行走查全部登记域外表 → **唯一行** = member-rename-design §7「TC-SIGS 子集不对称」行{触发判据明文「krf 面签名执法扩展需求（**语料/用户信号**）——扩表 = 逐条同构复制 oracle 行，双侧派生链自动覆盖」}；其余各行全部不可行（TD-026 ②③④ = interop/token 语料信号非用户臂 / pub(scope) = Stage 2+ 权限矩阵窗 / TD-005 残留 = 深度追踪架构位设计未在位 / TD-003/015 = IrGraph 消费点信号 / TD-008 = DEFER / TD-024 = Stage 3+ 后端演进评估）；成熟度全在位{oracle 61 行在位 + 派生链 TC-RENAME/tc-sig-of 在位 + r126 HM 深化窗/r135 HM 签名派生窗同族先例}
> **上游单源**: [member-rename-design §7/§8 D12-③](./member-rename-design.md)（登记载体）+ [hm.rs check_param_rule + result 映射](../../../crates/kerf-compiler/src/hm.rs)（oracle 行为规格）+ [builtins.rs BUILTIN_SIGS 61 行](../../../crates/kerf-driver/src/builtins.rs)（行清单单源）+ r80 生产切换契约（krf ⊆ oracle 方向守卫）

---

## 1. 问题陈述

check.krf `TC-SIGS` 签名表 **24 条** ⊂ Rust oracle `BUILTIN_SIGS` **61 条**——37 缺位成员在 krf 面（生产判定面）走 A4 Dynamic 通用路径不静态拒收，而 oracle 面按签名执法。登记态（r135 首登记 23⊂56；r138 vector 五内建后实况 24⊂61）。附带发现既有行分歧一件：`string-append` krf 行 `(sig 0 999999 'str 'str)`（变长 0+）vs oracle `fixed(&[Str,Str],Str)` + **运行时恒 2 参**（`args.len() != 2` → E0004）——krf 面对 1/3 参调用静态放行、运行期才拒——与 oracle 行为分叉的登记边界缺陷。

## 2. 37 行逐行同构映射表（D1——行清单单源）

### 2.1 变长形（既有 `(sig mn mx rule ret)` 形——5 行）

| 成员 | oracle 形 | krf 行 | 备注 |
|---|---|---|---|
| list | variadic(Any,Unknown,0) | `(sig 0 999999 'any 'unknown)` | ret 'unknown → fresh（D3） |
| append | variadic(Any,Unknown,0) | `(sig 0 999999 'any 'unknown)` | |
| vector | variadic(Any,Unknown,0) | `(sig 0 999999 'any 'unknown)` | r138 成员 |
| vector-append | variadic(Any,Unknown,0) | `(sig 0 999999 'any 'unknown)` | |
| error | variadic(Any,Unknown,1) | `(sig 1 999999 'any 'unknown)` | |

### 2.2 定形齐次单参/多参（既有形 + 新 kind——23 行 + 1 既有行修正）

| 成员 | oracle 形 | krf 行 |
|---|---|---|
| is-list | fixed([Any],Bool) | `(sig 1 1 'any 'bool)` |
| is-procedure | fixed([Any],Bool) | `(sig 1 1 'any 'bool)` |
| is-vector | fixed([Any],Bool) | `(sig 1 1 'any 'bool)` |
| length | fixed([List],Int) | `(sig 1 1 'list 'int)` |
| reverse | fixed([List],Unknown) | `(sig 1 1 'list 'unknown)` |
| last-pair | fixed([Pair],Pair) | `(sig 1 1 'pair 'pair)` |
| string-length | fixed([Str],Int) | `(sig 1 1 'str 'int)` |
| string-is-int | fixed([Str],Bool) | `(sig 1 1 'str 'bool)` |
| char-is-whitespace | fixed([Str],Bool) | `(sig 1 1 'str 'bool)` |
| char-is-alphabetic | fixed([Str],Bool) | `(sig 1 1 'str 'bool)` |
| string-to-upper | fixed([Str],Str) | `(sig 1 1 'str 'str)` |
| string-to-lower | fixed([Str],Str) | `(sig 1 1 'str 'str)` |
| string-to-symbol | fixed([Str],Symbol) | `(sig 1 1 'str 'sym)` |
| string-to-pos-chars | fixed([Str],Pair) | `(sig 1 1 'str 'pair)` |
| symbol-to-string | fixed([Symbol],Str) | `(sig 1 1 'sym 'str)` |
| print | fixed([Any],Nil) | `(sig 1 1 'any 'nil)` |
| newline | fixed([],Nil) | `(sig 0 0 'any 'nil)` |
| write-string | fixed([Str],Nil) | `(sig 1 1 'str 'nil)` |
| read-int | fixed([],Unknown) | `(sig 0 0 'any 'unknown)` |
| read-num | fixed([],Unknown) | `(sig 0 0 'any 'unknown)` |
| vector-length | fixed([Any],Int) | `(sig 1 1 'any 'int)` |
| vector-ref | fixed([Any,Any],Unknown) | `(sig 2 2 'any 'unknown)` |
| assert-eq | fixed([Any,Any],Bool) | `(sig 2 2 'any 'bool)` |
| string-contains | fixed([Str,Str],Bool) | `(sig 2 2 'str 'bool)` |
| string-starts-with | fixed([Str,Str],Bool) | `(sig 2 2 'str 'bool)` |
| string-ends-with | fixed([Str,Str],Bool) | `(sig 2 2 'str 'bool)` |
| string-index-of | fixed([Str,Str],Int) | `(sig 2 2 'str 'int)` |
| **string-append（既有行修正）** | fixed([Str,Str],Str) | `(sig 2 2 'str 'str)`〔原 `(sig 0 999999 'str 'str)`——§1 分歧清偿〕 |

### 2.3 定形异参（新 `'sigf` 形——5 行）

| 成员 | oracle 形 | krf 行 |
|---|---|---|
| nth | fixed([List,Int],Unknown) | `(sigf (list 'list 'int) 'unknown)` |
| drop | fixed([List,Int],Unknown) | `(sigf (list 'list 'int) 'unknown)` |
| member | fixed([Any,List],Bool) | `(sigf (list 'any 'list) 'bool)` |
| assoc | fixed([Any,List],Unknown) | `(sigf (list 'any 'list) 'unknown)` |
| string-substring | fixed([Str,Int,Int],Str) | `(sigf (list 'str 'int 'int) 'str)` |

## 3. sig 语言定点扩展裁定（D2-D5）

**D2（'sigf 定形异参形）**：`(list 'sigf (list p₁ … p_N) ret)`——镜像 `TcParams::Fixed(&[TcParam])`。消费分派：`(second sig)` = `'sig` → 既有变长路径；`'sigf` → 定形路径（元数 = 参数表长；逐位 `tc-rule-one`；结果同 D3 映射）。齐次定形单/多参**继续用既有 `(sig n n k r)` 形**（零扩展——仅 5 行异参需要 'sigf）。

**D3（结果类型映射——镜像 hm.rs `match sig.result`）**：`'unknown → (tc-fresh)`〔oracle Unknown → fresh var——非 Dynamic；未解变元经泛化 ∀α 与 oracle 同构〕；`'pair → (tcon 'dynamic)`〔oracle Pair → Dynamic——结构路径面〕；其余 `'int/'nil/'sym/'str/'bool/'num/'any → (tcon ret)`。既有变长路径的 `(tcon result)` 统一改经 `tc-sig-result`。

**D4（新 param kind 逐位裁定——镜像 hm.rs check_param_rule）**：
- `'list`：具体值 tpair|tcon-nil → 过；否则 record（镜像 List = Pair∪Nil）；**tvar → 零约束直过**（oracle List → domain None）。
- `'pair`：具体值 tpair → 过；否则 record（**nil 不过**——镜像 Pair 仅 Pair；last-pair (nil) 两面同报）；**tvar → 零约束直过**（oracle Pair → None）。
- `'int`：具体值 tcon-int → 过；否则 record；**tvar → 统一至 `(tcon 'num)`**（oracle `Num|Int → Some(Ty::Num)`——Int 参对变元仅约束 Num 域，字面级窄化在具体臂——krf 直译，防 krf ⊄ oracle 方向破坏）。
- `'sym`：具体值 tcon-sym → 过；否则 record；tvar → 统一至 `(tcon 'sym)`。
- 既有 `'num/'str/'bool/'any/'pair-rule/'num-or-str` 语义零变更。

**D5（消息族——krf 面既有约定沿袭）**：新 kind 消息并入 `tc-rule-msg` 族形：`'int → "argument requires int(static check)"`、`'sym → "argument requires symbol(static check)"`、`'list → "argument requires list(static check)"`〔与 tc-rule-pair-list 既有消息同文〕、`'pair → "argument requires pair(static check)"`。**不采 op 专属消息**（hm.rs 的 `"{op} requires {want}"` 形）——krf 面族形消息 = r80 以来既定约定（计数 parity 守护面为诊断数非消息文本；消息统一属独立评估面，登记域外）。

## 4. 方向守卫维持论证（D6）

krf ⊆ oracle 契约（krf 面诊断数 ≤ oracle 面——宽松化方向不破坏）：37 行为 oracle 行逐条同构复制——同一程序同一违反位两面各报一次 → 计数相等；tvar 位按 D4 直译（含 'int→Num 域宽化关键位——若 krf 直统一 'int 将窄于 oracle 的 Num 域 → (define (f x) (nth l x)) 后 (f 1.5) 形 krf 报 oracle 不报 → 方向破坏——D4 'int tvar 统一 'num 即为此防御）；结果映射 D3 直译（Unknown→fresh 防止 krf 用 Dynamic 造成的后续约束行为分叉——fresh 变元参与合一与 oracle 同构）。既有四类诚实边界（occurs 豁免域等 r80 登记面）零触碰。

## 5. 同窗锚翻转预算（D7）

扩表使 krf 面执法面扩容 → 既有锚实测值可能上移（krf 面向 oracle 计数收敛）：七语料锚{expander.ktf 0 / compiler.ktf 1 / reader.ktf 0 / check.krf 2 / build.krf 0 / cli.krf 0 / fib.krf 0} + 方向守卫锚{krf ⊆ oracle——check.krf oracle 23 上限} + hm_krf_path 计数锚 + ktf_corpus check E2E 零诊断锚。每一翻转 = 实测归因{真检出[双面一致] vs 误报[规则过严——当即修正]} + 重锚 + worklog 登记（r126 锚翻转先例同型）。**同窗缺陷处置纪律**：bootstrap 语料若现真违反位 = 既有潜伏缺陷当场清偿（r133 isoB 先例）。

## 6. 测试矩阵（D8）

新文件 `ktf_tc_sigs_parity_tests.rs` 32 case（8 正 + 24 负 = 1:3）：
- 正向八族：37 新成员逐族双面 E2E 值锚 + 双面 check 零诊断 + 'sigf 五成员定形 E2E + 变长五成员 E2E + 派生链消费{改名绑定 apply 位执法——TC-RENAME→TC-SIGS 自动覆盖实证} + 跨阶段 check 工件 + tvar 约束位正向{Int 参 Num 域——(define (f x) (nth '(1) x)) 后 (f 1) 零诊断} + 语料回归。
- 负向二十四族：新 kind 四族具体违反{list/int/sym/pair 各双面} + 'sigf 异参位独立违反{nth 位 1 int 违反 / member 位 2 list 违反 / substring 位 2/3 int 违反——逐位独立报} + 元数族{'sigf 定形元数 + 既有形定形元数 + 变长下界} + string-append 既有行修正锚{1 参/3 参双面静态拒 + 2 参过} + 结果类型消费违反{ret int 入 str 位} + 派生链改名执法负例 + tvar 域宽化锚{Int 参 float 流入零报——方向守卫防御位} + check E2E 负例 + 双面计数一致锚。

**量化验收**：test 1724 → 1756（净 +32）；六命令全绿；审计×6 EXIT 0；CLI 双语法面零回归；方向守卫实测维持；r140 包三验 + web 五件。

## 7. 域外表（本窗不做）

| 域外项 | 载体 | 触发判据 |
|---|---|---|
| ~~krf/hm 消息文本统一（族形 vs op 专属形）~~ | ~~本文件 D5~~ | ✅ r141 清偿（消息文本统一窗 211-a..211-f——设计单源 diag-msg-unify-design.md v1.0：krf 面九族 22 位点收敛到 oracle op+got 形{tc-type-str 渲染器镜像 Ty::render + op 名穿线七函数 + arity want 三形 + α/→/≥ Unicode 全链}；纯 .krf 面零桥变更；32 case 门 ktf_diag_msg_parity_tests + 锚翻转 45 处锁步；1788 基线；计数 parity 零变更[守护面不动]） |
| ~~read-line 签名条目~~ | ~~hm.rs 注释（运行时无元数检查）~~ | ✅ r144 清偿（read-line 签名条目窗 214-a..214-f——设计单源 read-line-sig-design.md v1.0：**触发前提事实性过时实证**——运行时元数执法自 FS-4 起即在位{builtins.rs 1563 行 fail-closed + 09-stdlib §3 r8 注记 + 20 §4 B3 契约三源确证——r140-r143 四轮走查以过时前提排除本行 = 审计链 R4 文档债本轮修正}；双侧表行{oracle BUILTIN_SIGS + check.krf TC-SIGS——read-int/read-num 家族形 fixed 0 参 Unknown[命中 Str ∪ EOF Nil——8 kind 冻结无 union 构造，r142 member D3 先例]}；静态面新增 E0005 拒收{与 E0004 运行时层正交——原则 42}；r135 改名链收紧{read-line as rl → TC-RENAME → TC-SIGS 命中}；同窗 R4 文档债四件清偿{builtins.rs 双注释 + check.krf 沿袭注释 + negative_vm_tests 模块注释}；32 case 门 ktf_read_line_sig_tests + builtin_name_exists 特例移除{扁平名 62 单源}；1884 基线） |
| 值位 Callable 类型（oracle lookup 值位返回 Callable vs krf Dynamic） | r135 D5 A4 面 | 值位 A4 纪律既有登记（member-rename §7 沿袭行） |
| is-procedure 运行时语义（无 callable 值——恒 #f 的诚实边界） | 09-stdlib | 值模型域外（Stage 2+ 函数值一等窗联动） |
| ~~member/assoc 结果类型 Bool 建模复审（运行时命中返回子列表/条目 Pair、未中 Bool——oracle 行为 Bool 为谓词化建模；严格 bool if 纪律下谓词用法需 is-pair 包裹）~~ | ~~本文件 §2.2.3 行复制沿袭 oracle~~ | ✅ r142 清偿（member/assoc 静态面双缺陷窗 212-a..212-f——设计单源 member-any-bool-model-design.md v1.0：**member 行结果位 Bool → Unknown 双侧宽化**[builtins.rs BUILTIN_SIGS + check.krf TC-SIGS 锁步——对齐 assoc 既有行 + r80 零误报契约 + list/member B2 净化方向；谓词位静态零变化（fresh unify bool）+ 运行时严格 bool if 纪律维持 + 正典谓词形态 = is-pair 包裹]；**同窗缺陷①清偿 = 'sigf 逐参路径 'any 规则位无臂兜底误报**[tc-rule-one 'any 短路臂——镜像 oracle Any=>true/var=>None 双臂；r140 引入的移植偏差——具体类型实参全兜底误报 + tvar unify 伪 tcon('any) 污染跨用位传播（expander/compiler/reader 三语料 5 个 r140 伪诊断一并消除）]；32 case 门 ktf_member_any_model_tests + 语料锚翻转三处[expander 6→5/compiler 2→1/reader 3→0]；1820 基线） |

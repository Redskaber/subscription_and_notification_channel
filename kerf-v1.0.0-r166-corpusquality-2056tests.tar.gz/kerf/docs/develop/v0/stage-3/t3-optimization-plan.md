# T3+ 优化窗实施计划（r53——首个触发式优化窗：HM 类型检查性能演进）

> **Author**: kerf-doc-agent
> **Date**: 2026-09-21（v1.0 首版——r53 / 75-a 设计轮交付：开窗核对 + O1-O5 技术方案 + 语义零漂移证明策略 + MUV 拆分）
> **Version**: v1.1（**终态——r53 / 75-b 收口**：O1-O5 实施后经**增量归因实测**收敛为 O1+O4 终态[O2/O3/O5 三项实测负收益或中性偏负——判据驱动移除实录]；语义零漂移五手段全绿[889:0:0——877 基线 + 12 新增守护]；**重大口径发现**：基线 v1.0 HM 维度归因错误→v1.1 修正[check 3734ms 构成 = 自举 VM 链 99.77% + HM 0.23%——R4 实录]；OBS-A 判据关闭；深审/投票 = deep-review-t3-optimization.md[5.5/5.5 GO]）
> **Status**: Closed（r53 全链闭环——75-a/75-b/75-z/75-web）
> **窗定位**: 23-evolution-governance §2.2 触发表 **T3+ 行**（触发式族——TD 优化窗口）｜ deep-review-stage3-close final-assessment 裁定「TD 优化窗口 profile 先行」｜ 性能债载体 = performance-baseline.md §2.3 诚实注记

---

## 1. 开窗核对（T3+ TD 优化窗口——触发信号逐项证据）

**治理依据**：23 §2.2 触发表 T3+ 行（触发式开窗单源）+ §2.3 红线 3（禁止无信号开窗——证据回填义务以本节承载）。

| # | 触发信号 | 证据 | 判定 |
|---|---------|------|------|
| ① | 性能基线冻结（优化判据的前置数据） | performance-baseline.md v1.0（r52 / 74-b 冻结：五维度 13 程序实测——HM 维度 expander.krf **3734ms** / compiler.krf **1230ms** / fib.krf **27ms**） | ✅ |
| ② | final-assessment 裁定（演进方向指示） | deep-review-stage3-close.md §4：「T3+ 演进模式：触发式开窗……**TD 优化窗口 profile 先行**」+ D8 建议「首件 = TD-028 profile 定锚 + HM occurs check union-find 压缩（基线文档 §2.3 候选注记）」 | ✅ |
| ③ | 性能债登记在位（TD-028 profile 锚） | tech-debt-register TD-028（VM 主分派与 GC 根扫描性能漂移——r52 复核维持登记：fib 91.534ms 收敛于噪声带上沿）；TD-003/015 同改判 Stage 3 优化窗口（本窗顺带对照，非首件） | ✅ |
| ④ | 优化候选判据（非先例驱动） | performance-baseline.md §2.3 诚实注记：「HM 检查是全管线最重一环……Stage 3+ 优化候选：**occurs check 的 union-find 压缩 + 泛化 memo**（不改变语义，纯性能演进）」——判据 = 实测最重维度 + 语义零变更可行性 | ✅ |
| ⑤ | 语义零漂移可证明性（窗出口前置） | HM check 不在 run 执行路径（原则 18 兑现——check/IDE 体验面）→ 优化影响的判定面 = 诊断集 + globals 渲染，两面均可逐位 diff 实证 | ✅ |
| ⑥ | 净负载红线复核 | 非 net 四依据窗（无授权面变更）；非语法面变更（零关键字/零新形式——23 §3.1 变更通道矩阵不触发新通道）；纯实现层性能演进（15 实现轴层内） | ✅ 合规 |

**开窗裁定**：六信号全过——T3+ 首窗 = **HM 类型检查性能演进窗**（occurs check union-find 路径压缩 + 结构共享族），r53 承载。红线 1（时间驱动）不触发：本窗由基线数据 + final-assessment 裁定驱动，非「时间到了」。

**范围界定（负空间声明）**：
- **做**：`crates/kerf-compiler/src/hm.rs` 求解器内部数据结构与算法（SolveState 族）——O1-O5 五优化点；
- **不做**：typecheck.rs（R1-R8 回归基线——不动）；语义层任何变更（诊断码/消息格式/泛化规则/值限制——零触碰）；env_free_vars 全量增量化（观察项 OBS-A，触发判据见 §4）；VM/GC 面（TD-028 本体——VM 主分派不在本窗，profile 锚已由基线冻结承载）。

## 2. 技术方案（O1-O5——语义零变更的纯性能演进）

> **总原则**：全部优化点不改变（a）诊断集合与消息逐字节；（b）globals 渲染输出；（c）fresh 变元编号分配顺序；（d）泛化/值限制/occurs 判定结果。（c）是（a）的前提——E0005 occurs 消息含 α 编号（hm.rs unify 两分支 format!），故**任何改变 fresh 分配顺序的优化均被排除**（含 free_vars 产出顺序变化）。

### O1 resolve 路径压缩写回（union-find 摊还）

**现状**（hm.rs 行 126-140）：`resolve(&self)` 沿替代链走到根但**不写回**——注释自证「压缩留给深度极小的链（≤ 变元数）」即零压缩。Var-Var 连续合一（行 181 bind(i, Var(j))）累积长链后每查询 O(链长)。

**方案**：`resolve` 改 `&mut self` + 沿链收集中间节点、统一写回根（经典 union-find 路径压缩）。调用面传染：`free_vars` / `copy_fresh`（已 &mut）/ `zonk` / `lattice_join` / `is_free_var` / `occurs`（在 unify &mut 内调用——安全）+ Gen 调用点（infer_expr/infer_app/infer_builtin_call 的 `self.st.resolve(...)`）。

**语义等价论证**：subst 传递闭包不变（写回只把中间节点直接指向根）；resolve 返回值不变（本就返回根）；fresh 分配不受影响。⚠️ 唯一注意：`resolve` 借用变化引发的编译期检查（Gen.st 字段单独借用 → `&mut self.st` 与 `&self.env` 的借用冲突逐点复核——NLL 下局部重构）。

**预期收益**：变元链查询摊还 O(α(n))；expander.krf 高阶组合密集（变元-变元约束链长）主受益。

### O2 occurs 变元级 visited 剪枝

**现状**（行 150-160）：occurs(i, t) 递归全树遍历，同一变元 j 的已解展开被重复完整遍历（结构共享/DAG 重复变元场景指数放大）。

**方案**：per-call `visited: &mut HashSet<u32>`——遇 `Var(j)`（resolve 后）先查 visited：已在 → 该分支必为 false（否则首次访问已短路整体 true）；否则完整探索其展开，若不含 i 则 j 入 visited。

**正确性论证**：occurs 期间 `&self`（subst 不可变）→ 同一 (i, j) 判定在全调用期内恒定；visited 只记录「已确认不含 i」的变元——若含 i，首次访问即返回 true 传播，visited 无损正确。**剪枝不改变 true/false 结果**，消息面（行 187 format 用 i 与 rb.render()）不变。

### O3 free_vars 变元级 visited + HashSet 辅助

**现状**（行 309-330 + 行 454）：`out.contains(i)` 线性扫描（O(free) 每 push）；同一 Var(j) 出现多次 → 其 resolve 后结构重复遍历；`env_free.contains(v)`（Vec）线性扫描 × free 过滤。

**方案**：free_vars 增 `seen: HashSet<u32>` 辅助（不变产出顺序——首遇先收语义不变）+ 变元 visited 剪枝（同 O2 论证——已收集变元的子树不再递归）；quants 过滤的 env_free 转 HashSet 查询（产出顺序 = free 原序，不变）。

### O4 copy_fresh 结构共享（instantiate 复制最小化）

**现状**（行 333-347）：`copy_fresh` 对 Pair/Arrow **无条件新建节点**（行 340-344）——即使子树全部原样返回（quants 不在其中）。Poly 绑定每次引用全树复制（expander 中 map/filter 等泛型函数被引用数百次 → 数百次全树复制）。

**方案**：递归返回后做 `Rc::ptr_eq` 短路——子项全部指针相等则返回原节点（`r.clone()`）。仅含 quants 变元的路径被复制（spine 复制）。

**语义等价论证**：类型结构同构且共享节点即原节点（Rc 语义不变）；fresh 分配顺序不变（map 构造 = quants 顺序）；instantiate 返回类型与旧实现逐位等价。

### O5（合并入 O3）env_free_vars 查询面优化

env_free_vars 遍历 env 绑定调用 free_vars（O3 已优化其内部）；Vec contains 转 HashSet（O3 承载）。**全量增量化不在本轮**——见观察项。

### 观察项 OBS-A：env_free_vars 全量增量化（触发式后继）

**方案预研**（已论证可行但证明链长，**本轮不实施**）：变元计数方案——`count: HashMap<u32, u32>`（变元被 env 绑定引用计数）+ bind 时计数迁移 + 泛化时 quants 变元计数回收。化简结论：exclude = Mono(alpha) 且泛化目标 = resolve(alpha) 时 **quants = {v ∈ free(τ) | count(v) ≤ 1}**。
**触发判据**（原则 35——判据先于先例）：O1-O4 落地后实测 expander.krf 每千行 check 耗时仍 > 2× compiler.krf 口径（1.07s/千行）→ 下窗实施；否则关闭观察项（登记 TD 或收敛声明）。
**风险声明**：计数迁移 bug → 误泛化 → 类型逃逸误报——属 GATE 2 高危面，故以实测数据驱动后继决策而非预防式引入。

## 3. 语义零漂移证明策略（五手段——75-b 验收合同）

1. **全量回归**：§3.2 六命令 clean 起步全绿 + `cargo test --release --workspace` **877:0:0 逐位一致**（含 hm_inference_tests 61 断言 + td030 组 + 超集门/零误报门双面）；
2. **诊断集逐位对照**：fib.krf / compiler.krf / expander.krf 三语料 `kerf check` 输出（码 + span + 消息体 + 渲染行序）优化前后 diff = 空集（E0002 24 条恢复模式 + E0005 面全量）；
3. **globals 渲染对照**：HM 验收面（HmReport.globals 的 render 输出）三语料前后 diff = 空集；
4. **occurs 检出维持**：td030 组（真 occurs 维持检出）+ s 系负例 + 自应用负例全绿；
5. **新增性能演进测试 ≥10 case**：路径压缩后长链 occurs 语义（构造 Var 链 → 行为不变）、copy_fresh 共享正确性（instantiate 类型结构等价断言 + Rc::ptr_eq 共享断言）、free_vars 剪枝后顺序不变断言、（基准）微基准断言防回归下限。

**bench 对照（基线 r52 冻结值——加速比如实落档，慢则如实登记不粉饰）**：
| 语料 | 基线（r52） | 本窗实测（75-b 落档） |
|---|---|---|
| bootstrap/expander.krf | 3734 ms | 待实测 |
| bootstrap/compiler.krf | 1230 ms | 待实测 |
| examples/usage/fib.krf | 27 ms | 待实测 |

## 4. MUV 拆分与量化验收

| MUV | Task ID | 载荷 | 量化验收 |
|---|---|---|---|
| 设计轮 | **75-a**（本文件） | 开窗核对 + O1-O5 方案 + 证明策略 | 六信号表 + 方案可实施性（代码实读锚：hm.rs 行号定位） |
| 实施轮 | **75-b** | O1-O4/O5 实施 + 测试扩展 + 基线对照 + 深审 + 投票 + §3.2 | §3 五手段全绿 + 新增 ≥10 case + 六命令全绿 + 加速比落档 + 投票 ≥95% |
| 打包 | **75-z** | tar.gz + 包内自举三验 + rec 树 17 + download README r53 节 | 包内自举全绿（build + 877 + 审计 ×6 + bench 一致性） |
| web 面 | **75-web** | kerf-data r53 节点 + footer v7.25 + stats + E2E | E2E ≥14 命中 + Playground 实证 + lint 0 |

**深审范围（75-b 内）**：D1（架构——优化不跨层：kerf-compiler 层内）+ D2（TD——OBS-A 登记形态）+ D3（测试——877 + 增量 + 六审计集 280 复验）+ D5（设计——原则 18/35 双锚）+ D6（性能——基线对照表）+ D8（流程——GATE 1-5 逐门）。D4/D7 面无变更（语义/文档冷启动面不动——除本计划文件与基线增量节）。

**回写预案（§14.8）**：performance-baseline.md 增量节（r53 对照表 + 加速比 + OBS-A 处置）+ matrix r53 行 + RELEASE_NOTES r53 节 + roadmap 头指针 v1.0.0-r53 + 本计划文件终态注记 + tech-debt-register（TD-028 profile 锚注记 + OBS-A 若触发则登记新 TD）。

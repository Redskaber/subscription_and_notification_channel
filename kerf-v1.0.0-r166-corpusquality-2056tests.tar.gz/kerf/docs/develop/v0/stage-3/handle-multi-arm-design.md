# handle 多臂 / halt / pass 设计（第十二皮肤映射族——切换窗后续域外登记行清偿 + TD-033 组安装语义实施设计）

> **Author**: kerf-dev-agent（Super Z main — ARCH-A 裁定 + DEV-A 实施；r132 / 202-b 设计先行腿；r136 / 206-a TD-033 实施设计腿）
> **Date**: 2026-11-06（v1.0 首件）；2026-11-09（v1.1 §8 增补）；2026-11-14（v1.2 R4 行翻转补债）
> **Version**: v1.2（**r145 / 215-b R4 审计链文档债清偿——§7「目标面 handle 表达式位」行翻转补债**：r143 收口四件声称「handle-multi-arm §7 表达式位行清偿关闭」{worklog Stage Summary + matrix.md L152 + README L69/L75 + t3plus-manual-trigger-guide v1.28}但本文件物理行未翻转——Version 头 v1.1 r136 态滞留两轮{r143/r144}；r145 审计链全量交叉核对发现{同类路径全量审查 §20.3——其余全部声称翻转件逐一实证在位，唯本行缺失}，当轮发现当轮修正{R4——文档以实况为准；§8.4.5 文档与代码冲突 = 以代码为准 + 修正文档}；变更面 = 纯文档{行翻转 + 本版本头}——零代码变更零测试面变动{1884 基线维持}）；v1.1（**r136 / 206-a TD-033 组安装语义实施窗设计先行腿**：§8 新增 D11-D19 九裁定——多臂语义自嵌套脱糖切换为组安装（[HANDLE-INSTALL] Koka 式读法兑现）；单臂零回归（D1 锚维持）；S-expr 面 handle-group 核心形式（D12 双面 parity 载体）；VM HandlerFrame 多 entry 组消费机制（D14——TD-033 登记范围明示的机制变更）；新操作码 InstallHandlerGroup #46 四方同步（D19）；§2 脱糖映射表 D2 行翻转注记 + §7 TD-033 行翻转；测试矩阵 §5 增补组语义 8 正 24 负）；v1.0（r132 / 202-b 首件——第十二皮肤映射族）
> **Status**: Active（设计单源——本文件 §2 为 02-syntax-model §8.13.1a v7.17 产生式的规范锚；Reader 解析域开放以本文件定稿域边界为据；§8 为 TD-033 实施的规范锚）
> **处理程度**: P0（r132 窗交付 = 双侧 Reader + 32 case 门 + 文法登记四件；r136 窗交付 = VM 组消费机制 + 双侧编译链 + handle-group 核心形式 + 64 case 门）
> **开窗依据**: r132 = 用户 r132 指令①「继续推进 目标语言设计的实现窗」行权（M1 指令开窗第三十七例）；推荐序首位（r131 收口笔唯一设计先行态余项——切换窗后续域外登记末项；use 窗遗留触发式域外二项居后）。**r136 = 用户 r136 三链指令行权（M1 指令开窗第四十一例）**：推荐序首位三源一致（#15 需 next18.md 未上传 + TD-032/TD-031/HM 全清偿 + r134/r135 域外登记全清零 → TD-033 = 唯一剩余可开实施窗项）；TD-033 触发判据「臂体 perform 兄弟标签语料消费信号**或用户指令**」之用户指令臂命中（r74 先例锚——指令即需求信号本体）

---

## 1. 问题陈述

**目标面表达力 parity 缺口**（r125 require / r130 import as / r131 use 同型——CLI 双入口双面架构下两语法面须互相可表达；EBNF v3/v5 Level 0 基础语法「必需——Stage 0-1」项）：

| 效应处理形 | S-expr 面（机制层实况） | 目标面（r131 态） | 缺口 |
|---|---|---|---|
| 单臂处理 | `(handle gift ((p k) body) e)`（r25/42-f 既有） | `handle e { gift(p, k) => body }`（r106 D2 映射既有） | ✅ 在位 |
| **多臂处理** | 嵌套 handle 惯用法（机制在位——组合既有单臂形） | 单臂 v1 fail-closed（target.rs:2159 域外登记） | ❌ 本窗清偿 |
| **halt 终止流** | 不 resume 尾值（续体废弃既有——T-NO-RESUME 机制面） | 域外 fail-closed（target.rs:2192 登记域外） | ❌ 本窗清偿 |
| **pass 穿透传播** | `(perform (cons (quote T) p))`（perform/cons/quote 既有） | 域外 fail-closed（同上） | ❌ 本窗清偿 |

**核心设计事实（判据先于先例——本窗探针实证三件）**：
1. **三形的机制层全部在位**：多臂 = 嵌套单臂 handle 组合（expander/compiler/VM 对嵌套形零分歧——r25 既有）；halt = 不调用 resume 的尾值（handler 体 RET 承接 handle 值——vm.rs H 帧返回点继承既有）；pass = 重 perform（H 帧 ext1 已清 → 帧扫描越本 handle → 外层传播——D2 浅处理既有结构）。**Reader 层语法面清偿，零机制变更**（8 原语不变性第十四轮验证——零新原语零通道零 VM 零 expander 零 compiler 变更）。
2. **skin-dictionary 先例链成熟**：r121 match（表面形 → 既有核心形脱糖——match_desugar 同族判定）+ r128 resume 语句位（k 注入——Reader 注入先例）——本窗 = 第十二映射族（多臂/halt/pass 三子形共用一条 handle 映射链）。
3. **双 Reader 域外登记在位**：种子 target.rs:2159/2192 与镜像 target_reader.krf:1932/1989 同消息域外登记（「多臂/halt/pass = 登记域外」「resume ∈ {0,1} 合围域外形态」）——登记面即本窗清偿面；零既有测试锚断言该消息族（rg 实证——零锚翻转义务）。

## 2. 语法（定稿域——02 §8.13.1a v7.17 规范锚）

```ebnf
(* ---------- Level 0 增补（r132——handle 多臂 / halt / pass；语义 = 既有 *)
(* s-expr 面嵌套单臂 handle 组合 + perform 重发射 + 尾值废弃的纯皮肤 *)
(* 映射，零新语义通道——皮肤字典第十二映射族 = 20 §14 v1.24） -------- *)

handle_stmt    ::= "handle" expr "{" handler_arm { "," handler_arm } [ "," ] "}" ;
handler_arm    ::= effect_pattern "=>" handler_body ;
effect_pattern ::= effect_name "(" ident "," ident ")" ;   (* 统一两元绑定——D8 *)
handler_body   ::= "resume" "(" expr ")"      (* 恢复续体——脱糖 (κ v) Apply 既有 *)
                 | "halt" [ "(" expr ")" ]    (* 终止流——resume ∈ {0,1} 合围 {0} 形 *)
                 | "pass"                     (* 穿透传播——T-EFFECT-PROPAGATION *)
                 | block ;                    (* r128 块体既有 *)
```

**脱糖映射总表（D2/D4/D5 载荷）**：

| 表面形 | Stx（S-expr 面等价形） | 语义 |
|---|---|---|
| `handle e { A(p₁,k₁) => b₁, B(p₂,k₂) => b₂ }` | **`(handle-group (A (p₁ k₁) b₁') (B (p₂ k₂) b₂') e')`**〔r136 翻转——原 v1.0 嵌套脱糖；组安装语义 D11/D14〕 | 组安装——臂体互不保护（对称） |
| `halt` | 尾值 nil 字面量 | 流终止——续体废弃（D5） |
| `halt(v)` | 尾值 `v'` | 流终止携值（D5） |
| `pass` | `(perform (cons (quote T) p))` | 本臂效应重发射→外层传播（D4） |
| 单臂形（既有） | `(handle T ((p k) b') e')` | 零回归——子集逐字节等价（D1） |

> **r136 翻转注记（206-a）**：多臂行自「嵌套脱糖（先写臂为外层——D2/D9）」翻转为「组安装（handle-group 核心形式——D11）」；D2 原裁定作为嵌套语义的历史登记保留（嵌套语义仍可经显式嵌套手写获得——D11）。

## 3. 裁定表（D1-D10）

### D1：单臂零回归裁定（加性前提）

**裁定**：单臂形 `handle e { T(p, k) => body }` 保持既有解析路径产物**逐字节等价**（1 臂 = 多臂文法的 1 元子集——生成器对单臂退化为直接单层 `(handle T ((p k) b') e')`，与既有 parse_handle 产物同形同 Span）。既有 effect 语料族（effect.ktf / effect_stress.ktf / 审计集 r1/r2 效应 case）零回归 = 本窗回归网。

### D2：多臂映射核心裁定（先写臂为外层）

**裁定**：`handle e { A => b₁, B => b₂ }` → `(handle A ((p₁k₁) b₁') (handle B ((p₂k₂) b₂') e'))`——**先写臂为外层，受保护表达式在最内层**（表面臂序 = 嵌套包裹序——阅读序即包裹序）。零 expander/compiler/VM 变更（原则 31 皮肤/骨架同构——Stx 等价判据）。

**语义继承表（代码为准 R4——vm.rs Perform/InstallHandler 既有结构）**：

| 语义面 | 嵌套形实况 | 裁定注记 |
|---|---|---|
| tag 分派 | 帧扫描按 tag 匹配（D6 最近帧）——tag 不匹配帧自然跳过 | 同胞臂帧对异 tag 效应透明 ✓ |
| 浅处理 D2 | 发射臂帧 snapshot 内 ext1 清除（一次消费）；其余同胞臂帧维持活动 | 恢复后受保护表达式剩余计算仍受同胞臂保护（D2 单臂纪律的自然多臂延拓）；**发射臂自身不再接住**（再 perform 同 tag → 外层） |
| 合围 resume ∈ {0,1} | 每臂 k = 独立一次性续体（ContinuationValue.consumed 单次卫门既有） | 多臂零弱化——每臂各自 {0,1} 合围 ✓（switch-window-plan §4 设计依赖本体兑现） |
| 未匹配效应 | 扫描越全部帧 → err_effect_unhandled code 7 | 既有诚实面零变更 |

### D3：sibling 臂体保护分歧诚实登记（TD-033 触发式 → **r136 组安装实施——登记项清偿翻转**）

**裁定**：嵌套语义下**先写臂的 handler 体不受后写臂保护；后写臂的 handler 体受先写臂保护**（非对称——嵌套结构自然结果：发射臂的 H 帧之下同胞帧仍在活动）。例：`(handle A cA (handle B cB e))` 中 b_B 体内 perform A → 臂 A 接住；b_A 体内 perform B → 越过外层传播。

**与登记态的分歧注记（r136 已清偿——历史原文保留 + 翻转注记）**：06 §10 [HANDLE-INSTALL]「安装 handlers 到 σ ∪ {h₁..hₙ}」的组安装读法（Koka 式——臂体互不保护、对称）**已于 r136 实施**（§8 D11-D19——TD-033 清偿关闭）；登记态小步语义对该动态案例未钉死（[T-HANDLE] 类型规则两读法皆容）。组安装语义需 HandlerFrame 多 tag 匹配 + 组消费机制变更（VM/编译器/expander 两侧）——r132 窗零机制变更义务（触发器 8——登记态零信号不强行实现化），r136 窗按用户指令行权实施。

### D4：pass 重构裁定（本臂效应重发射）

**裁定**：`pass` → `(perform (cons (quote T) p))`——T = 本臂效应名（Reader 静态注入 quote 符号字面量——r106 perform 同构）；p = 本臂载荷绑定子（当前值语义——体若重绑定 p 则携新值，简单局部语义诚实登记）。

**穿透语义链（既有机制零变更）**：发射臂 H 帧 ext1 已清 → 重 perform 的帧扫描越过本 handle 全部残留结构 → 外层传播（T-EFFECT-PROPAGATION 载体）；外层 handler resume 时续体自 **pass 点**续起（re-raise 标准语义——OCaml/Koka 同型）；无外层 handler → err_effect_unhandled code 7（既有诚实面）。多臂形下 pass 越过同胞臂（同胞帧 tag 异名不匹配）✓。

### D5：halt 糖裁定（尾值化）

**裁定**：`halt` → 尾值 nil 字面量；`halt(expr)` → 尾值 `expr'`。不 resume = 续体废弃 + handler 体 RET 承接 handle 值（T-NO-RESUME 规则载体——「流在 handler 处终止」= resume ∈ {0,1} 合围的 {0} 形）。**纯糖**：与手写尾值产同 Stx（r110 else-nil 字面量化同族——nil 符号缺陷已历史清偿，本窗直用 StxLiteral::Nil / nd-nil）。

### D6：重复标签 fail-closed

**裁定**：同一 handle 内效应名重复 = Reader 错误。消息：「handle 臂效应名重复：「{name}」（同一 handle 内每效应至多一臂——嵌套脱糖下后臂静默遮蔽先臂，fail-closed 拒绝）」；Span = 重复出现本位。依据 §2.3（报错>静默）——嵌套形重复 tag = 内臂恒接住 + 外臂死代码（静默遮蔽）。双臂同名是唯一被拒形态；跨 handle 同名合法（嵌套遮蔽 = 用户显式书写意图）。

### D7：位形词域（目标面本地关键字）

**裁定**：`halt`/`pass` = **目标面本地关键字**（种子 Tk::KwHalt/Tk::KwPass + 镜像 TKEYWORDS 增二词——全保留，resume 同型：handler_body 位限定词但词法面全保留）；**S-expr 面零扰动**（`(define halt 42)` / `(define pass 1)` 合法——r129 macro 先例第 2 连）；**共享 Keyword/E0020 域零扩展**（22 §880「3 handler 位形词 resume/halt/pass」登记面兑现——resume 既有共享域 + halt/pass 本窗目标面域）。表达式/语句位 `halt`/`pass` → 「期望表达式，实际 KwHalt/KwPass」fail-closed（macro 同型）。

### D8：臂形与分隔纪律

**裁定**：臂模式 = `Name(p, k)` **统一两元绑定维持**（r128 纪律——块体 resume 语句位 k 注入依赖两元绑定序）；`Name` 受理 Ident|Path 双形（perform 效应名同规）。臂间逗号分隔、**尾逗号可省**（match/macro 尾臂先例——既有单臂尾逗号容让自然泛化）；**零臂 = fail-closed**「handle 至少须有一臂」（match 零臂同型）。pattern_list 泛化/if 守卫 = 域外（见 §7）。

### D9：Stx 序与保序声明

**裁定**：表面臂序 → 嵌套外内序（先写臂外层——D2）；每层 handle Stx = 既有三元 `(handle tag ((p k) body) protected)` 零变更（expander 消费序无感）。表面序与包裹序保序声明：多臂脱糖的读者可预测性锚（先写者先包裹）。

### D10：Span 契约

**裁定**：生成的嵌套 handle 节点 Span = 整语句区（`handle` 起..`}` 止合并——最外层）；内层生成 handle Span = 其包裹范围（内层 handle 关键字虚拟本位 = 外层 `handle` 本位——同源锚）；各臂子句 `((p k) body)` Span = 臂区（效应名本位..臂体止）；pass 生成节点族 Span = `pass` 本位..p 绑定本位合并（perform/quote/T 符号 = T 效应名本位，cons = quote 区，p 符号 = 其声明本位）；halt 生成节点 Span = halt 本位（或 expr 区）。双侧同规可计算（镜像 nd 系构造器既有 span 参数同构）。

## 4. 诊断面（新增消息族——双侧字节级 parity）

| 消息 | 触发 | 家族先例 |
|---|---|---|
| 「handle 臂效应名重复：「{name}」（同一 handle 内每效应至多一臂——嵌套脱糖下后臂静默遮蔽先臂，fail-closed 拒绝）」 | 同 handle 重复效应名 | 本窗新增 D6 |
| 「handle 至少须有一臂」 | `handle e {}` | match 零臂族平行 |
| 「handle 臂绑定须为二元（payload, resume）」 | 臂绑定非两元（0/1/3+ 元） | 既有消息 v1 后缀退役（「——多臂/halt/pass = 登记域外」删除——域内化） |
| 「期望效应名，实际 {:?}」 | 臂首非 Ident/Path | 既有消息 v1 后缀退役 |
| 「pass 不受理实参（裸位形词——穿透零参形，重发射由 Reader 注入）」 | `pass(x)` 形 | 位形词 arity 族平行 |
| 「halt 后随意外 Token 形」族 | `halt;` / `halt x` 等非 `,`/`}`/`(` 形 | 期望错误族自然沿袭 |
| 「期望处理器体（resume 调用形 / halt 形 / pass / 块），实际 {:?}」 | `=>` 后非四形 | 既有 domain-out 消息退役→四形枚举消息 |
| 「期望表达式，实际 KwHalt / KwPass」 | 表达式/语句位 halt/pass | macro E0001 族平行 |
| err_effect_unhandled（code 7） | pass 无外层 handler | 既有——零新增 |

## 5. 测试矩阵（32 case 门——8 正 + 24 负 = 1:3，§9.4.3）

**正向八族**：① 多臂 E2E（双臂分派 + 值断言 45）② 嵌套等价字节码全等门（共享符号表——`.ktf` 平坦多臂形 ↔ `.krf` 手写嵌套形 compile 同构产物全等；皮肤透明性证明）③ 双 Reader 正典渲染 parity（八形：双臂/三臂混合/无尾逗号/halt(expr)/裸 halt/pass/单臂既有/块体——字节级含 Span）④ halt 语义 E2E（halt(42) ⇒ 42 + 裸 halt ⇒ nil + 未发射臂不运行 ⇒ 105——合围 {0} 形 + 续体废弃实证）⑤ pass E2E（穿透至外层 handler——resume(20) + 100 ⇒ 120——pass 点续起语义）⑥ 单臂零回归 + fvo 清偿回归锚（r128 语料形 ⇒ 120 + 嵌套同名绑定 .krf 形 ⇒ 30——同窗缺陷清偿实证）⑦ 跨语法值 parity（语料对 include_str! 消费——corpus-integrity 门，双面 202）⑧ check 跨阶段消费零诊断。

**负向二十四族**：重复标签双形{双臂同名/三臂中二同名——D6 专用诊断携效应名} / 零臂 D8 / 臂绑定非两元三形{0/1/3 元} / 臂首非效应名三形{Int/Semi/KwFn} / pass 带实参（专用诊断）/ halt 后随意外双形{;/ident}/ 缺 `=>` / 缺 `}` eof / 缺臂间逗号（resume 臂体形——期望 } 家族）/ 处理器体非四形双形{;/Int}/ halt 缺右括号 / 表达式位 halt / 表达式位 pass / 块体语句位 halt / 块体语句位 pass / 顶层 halt / pass 无外层 handler err_effect_unhandled（运行期语义负例）——双 Reader 错误面 parity（消息 + Span 字节级）网内 23 形全覆盖。

## 6. 实施对账

| 件 | 落位 | 遵循 |
|---|---|---|
| 种子 | kerf-reader/target.rs：Tk 增 KwHalt/KwPass（enum + parity_kind + tk_of_kind + 词法分派 + tk_debug 样本）+ parse_handle 多臂循环 + parse_handler_body 四形 + parse_halt_form/parse_pass_form | §10 命名 / 原则 31 |
| 镜像 | kerf-driver/bootstrap/target_reader.krf：TKEYWORDS 增 "halt"/"pass" + parse-handle 多臂循环（handle-arm 链）+ parse-handler-body 四形 + parse-halt-form/parse-pass-form | 种子同构（rderr-tok 经桥 tk_debug_of_kind 单源） |
| 测试 | tests/v0/stage3/plan/ktf_handle_multiarm_tests.rs + runner.rs 挂载 | §9.1/§9.4.3 |
| 语料 | examples/usage/effect_multiarm.ktf（平坦多臂+halt+pass）+ effect_multiarm.krf（手写嵌套等价形——11:11 语料族对齐） | 语料族纪律（r127-r129） |
| 文法 | 02 §8.13.1a v7.17（产生式 + 域外注记翻转）/ 20 §14 v1.24（第十二映射族）/ 22 §880 注记（位形词兑现）/ stage0 §9.26 注记 | 原则 44 产生式义务 |
| 治理 | t3plus v1.52 / RELEASE r132 / matrix r132 / switch-window-plan §4 handle 行清偿 / TD-033 新增（D3 载体）/ README / rec 94 / worklog 三链 | §8.5/§8.6 |

## 7. 诚实边界（域外登记表——触发式）

| 域外项 | 载体 | 触发判据 |
|---|---|---|
| ~~组安装语义（Koka 式臂体互不保护）~~ | ~~TD-033（本文件 D3）~~ **✅ r136 清偿**（本文件 v1.1 §8 D11-D19 实施） | ~~臂体 perform 兄弟标签语料消费信号或用户指令~~ 已行权（M1 指令开窗第四十一例） |
| effect_pattern 泛化（pattern_list 模式 / if 守卫） | 本文件 D8 + switch-window-plan §4 增行 | match 模式集成窗（pattern_list 消费信号） |
| 裸臂形 `Name`（无绑定对——halt/pass 臂免 p/k 绑定） | 本文件 D8 | 语料消费信号（统一两元维持优先——r128 k 注入依赖） |
| 块体语句位 halt/pass（r128 resume 语句位对称扩展） | 本文件 §2 | 块体终止/穿透语料信号 |
| resume 多参/命名形 | EBNF v9 既有登记 | 既有触发式维持 |
| ~~目标面 handle 表达式位（parse_primary 未分派 KwHandle——嵌套惯用法手写形仅语句位/块内可写；多臂脱糖为 Reader 内部生成不受限）~~ | ~~本文件 D1 注记（既有单臂态即如此——r106 D2 语句位裁定）~~ | ✅ r143 清偿（handle 表达式位窗 213-a..213-f——设计单源 handle-expr-position-design.md v1.0：双侧 Reader primary 位分派{种子 parse_primary KwHandle 前置臂 + 镜像 parse-primary cond 臂——r110 表达式位 if / r121 match 值形同构分派第三例}；五位置形全开放{let 值位/函数实参位/if 条件位/嵌套 protected 位/group 位}；脱糖产物与语句位逐字节同构{零机制变更——8 原语不变性第二十五轮}；r133 handler_k 穿线表达式位无损延拓{嵌套 protected 内 resume 维持域外 fail-closed}；32 case 门 ktf_handle_expr_position_tests{8 正 + 24 负 1:3} + 语料对 effect_handle_expr.{ktf,krf} ⇒327 双面{语料族 13:13}；1852 基线自 r143 起。**本行物理翻转滞留两轮：r143 收口四件声称清偿关闭{worklog Stage Summary + matrix L152 + README L69/L75 + guide v1.28}但 213-e 对账九件未含本文件——r145/215-b 审计链全量交叉核对发现，当轮发现当轮修正{R4——文档以实况为准}**） |

*遵循条款：原则 26（成熟度匹配——推荐序首位兑现）/ 原则 27（加性——单臂零回归 + S-expr 面零扰动）/ 原则 31（皮肤/骨架同构——Stx 等价判据 + 嵌套脱糖）/ 原则 44（新语法成员登记必须附 EBNF 产生式）/ §2.3（报错>静默——D6 重复标签 fail-closed）/ §2.1.1-11（确定性边界先行——机制层三事实探针实证）/ §9.4.3（1:3）/ §12（最优>最小——嵌套脱糖 = 机制完备下的最优表面形）/ r74 先例（用户指令 = 需求信号本体）/ r121 match 先例（表面形→既有核心形脱糖）/ r129 macro 先例（目标面本地关键字）。*

---

## 8. TD-033 组安装语义实施设计（r136 / 206-a——D11-D19）

> **开窗判据链**：需求信号 = 用户三链指令（M1 第四十一例——r74 先例锚「指令即需求信号本体」）；推荐序首位三源一致（#15 需 next18.md 未上传 + TD-032/TD-031/HM 全清偿 + r134/r135 域外登记全清零 → TD-033 = 唯一剩余可开实施窗项）；TD-033 触发判据「臂体 perform 兄弟标签语料消费信号**或用户指令**」之用户指令臂命中；技术就绪（本文件 D3 登记 + 06 §10 [HANDLE-INSTALL] 组安装读法 + [T-HANDLE] 两读法皆容 + VM Perform 帧替换机制天然支持组消费——实施面代码实读）；8 原语不变性预检（零新原语零通道——VM 指令 +1 属登记范围明示机制变更）；§6.2 零开放 P0/P1；治理边界（非切换窗——六步门控维持）。

### D11：语义切换裁定（多臂 = 组安装；嵌套仍可手写）

**裁定**：多臂（≥2 臂）目标面 handle 的语义自「嵌套脱糖」（r132 D2——非对称同胞保护）切换为「**组安装**」（06 §10 [HANDLE-INSTALL] 的 Koka 式读法——臂体互不保护、对称）。单臂维持既有单臂形（D1 锚——1 元组与单臂语义恒等，字节级零回归）；嵌套语义仍可经显式嵌套手写获得（目标面块嵌套 handle 语句 / S-expr 面嵌套 handle 形）。依据：原则 12（最优>最小——机制完备下的正典语义形态）+ 原则 27（加性——单臂零回归）+ TD-033 登记裁定（非缺陷性登记 → 触发式增强窗兑现）。

**语义继承表（组安装态——与 r132 嵌套态对照）**：

| 语义面 | 组安装实况 | 与嵌套态差异 |
|---|---|---|
| tag 分派 | 单帧 entries 多 tag 匹配（任一命中即分派） | 等价（分派结果同） |
| **组消费** | 命中帧被 H 执行帧整体替换——全部 entry 随帧消亡 | **差异本体**：嵌套态仅发射臂帧消亡、同胞帧维持活动 |
| 臂体兄弟效应 | 组帧已消亡 → 越组外层传播 | **对称非保护**（嵌套态后写臂体受先写臂保护——非对称） |
| 恢复后受护计算 | 快照 snap[0].ext.ext1 = None 整组惰性化 → 兄弟效应外层传播 | 嵌套态恢复后仍受同胞臂保护 |
| 合围 resume ∈ {0,1} | 每臂 k = 独立一次性续体（ContinuationValue.consumed 卫门不变） | 等价 |
| 未匹配效应 | 扫描越全部帧 → err_effect_unhandled code 7 | 等价（诚实面零变更） |

### D12：S-expr 面核心形式（handle-group——双面 parity 载体）

**裁定**：`(handle-group (标签 (载荷变量 恢复变量) 结果表达式)+ 体)`——变参形式（match 先例）：末位操作数 = 体；其余 = 臂子句（每子句 `(tag (p k) result)` 三段）。**≥2 臂强制**（单臂重定向消息「单臂请用 handle 形」——表面经济纪律）；同组重复标签 fail-closed（D6 同型消息族）；每臂独立 fresh-scope 深注入（TD-004 纪律——binders + 臂体；体不注入）。`Keyword::HandleGroup`（"handle-group"）注册；E0020 共享保留域与 handle 同族处理。双面 parity 达成：S-expr 面 handle-group = 组安装；嵌套惯用法 = 嵌套语义；目标面多臂 → handle-group（Reader 生成）。

### D13：CoreExpr 与节点协议

**裁定**：`CoreExpr::HandleGroup { arms: Vec<HandleArm>, body: Rc<CoreExpr>, span }`；`HandleArm = { tag: Rc<str>, payload_var: Symbol, payload_scopes: ScopeSet, resume_var: Symbol, resume_scopes: ScopeSet, handler_body: Rc<CoreExpr> }`。节点协议：`('handle-group s e x arm₁ … arm_N body-node)`——臂节点 = `(tagstr pname pscopes rname rscopes hnode)` 五字段表（handle 七字段的臂内子集形）。桥双侧：compiler.rs `core_to_node` / expander.rs `core_from_value` 对称臂。

### D14：VM 机制（多 entry 帧 + 组消费）

**裁定**：
- **HandlerFrame 重构**：`tag/handler_proto/captures` → `entries: Vec<HandlerEntry>`（`HandlerEntry = { tag: Rc<str>, handler_proto: u32, captures: Vec<Rc<GcCell>> }`）+ `stack_watermark` 不变；既有 `InstallHandler` = 1-entry 帧（零行为变更——D1 锚）。
- **新操作码 `Op::InstallHandlerGroup`（#46）**：操作数交错布局 `(op 46 hp₁ tk₁ hp₂ tk₂ … hp_N tk_N bp tp)`——N = (操作数数 − 2) / 2；执行：逐臂 take_frame_captures → 推 1 个 handler 帧（entries = N；Frame.captures = 全臂 captures 拼接——GC 根集单源位）+ 1 个 body thunk 帧（三原型方案泛化——T 弹床共享单例不变；帧数上限检查同型）。
- **Perform 扫描泛化**：帧 ext1.entries 任一 tag 匹配即命中（记录 frame_idx + entry_idx）；命中帧被 H 执行帧**整体替换 = 组消费**（全部 entry 随帧消亡）；H 帧 locals = [payload, κ, …]（matched entry 的 handler_proto/captures）；数据栈截断回 watermark 不变；续体快照 snap[0].ext.ext1 = None（**整组惰性化**——Koka 浅处理多例同构）。
- **GC 根扫描**：collect_roots_into 经 Frame.captures 覆盖（组安装拼接全臂 captures——零新根集路径）。

### D15：编译发射（三原型泛化）

**裁定**：`IrExpr::HandleGroup { arms: Vec<(Rc<str>, IrProto)>, thunk: IrProto }`（每臂 H 原型 params = [pᵢ, kᵢ]）。发射序确定性：T 弹床（共享单例）→ H₁..H_N（逐臂 lower_inner_proto / compile_inner_proto）→ B thunk → tk₁..tk_N（SymLit 常量逐臂内联）→ `InstallHandlerGroup` 原子发射（Rust 与 compiler.ktf 同序——bytecode_equal parity 含 debug_spans；弹床 Span 三元组恒 (0 0 0)）。

### D16：HM/check 双侧（A4 纪律维持）

**裁定**：hm.rs：Handle 臂泛化——逐臂 binders → Dynamic（save/restore 每臂独立）+ 推断各臂 handler_body + body → Dynamic（效应面零收紧零误报——A4 沿袭）。check.krf：`'handle-group` → unsupported 跳过（PoC 子集外——既有 'handle 行同型增行；krf ⊆ oracle 契约维持）。typecheck.rs PoC 面同型跳过。

### D17：诊断面（S-expr handle-group 消息族——双侧字节级 parity）

| 消息 | 触发 |
|---|---|
| 「handle-group 形式：(handle-group (标签 (载荷变量 恢复变量) 结果表达式)+ 体)——至少两臂，单臂请用 handle 形」 | 变参 < 3（零臂或单臂） |
| 「handle-group 臂效应名重复：「{name}」（同一 handle-group 内每效应至多一臂——组安装下重复臂静默遮蔽，fail-closed 拒绝）」 | 组内重复标签 |
| 「handle-group 臂子句必须是 (标签 (载荷变量 恢复变量) 结果表达式) 形态」 | 臂子句非三段 |
| 「handle-group 效应标签必须是符号」/「载荷/恢复变量必须是符号」/「载荷变量与恢复变量重名（须为不同名）」 | handle 族镜像 |

目标面诊断零变更（D6/D8 既有消息族维持——多臂诊断面未变，仅生成产物翻转）。

### D18：锚翻转与语料（r132 测试基线切换）

**裁定**：
- r132 测试②「嵌套等价字节码全等门」**退役** → 新「**组等价门**」：多臂 .ktf ↔ handle-group .krf compile 产物全等（共享符号表——皮肤透明性新证）。
- 语料 `effect_multiarm.krf` **重写**：手写嵌套等价形 → handle-group 形（值 parity 语义基线切换——r127 语料族纪律；.ktf 双面值 parity 202 维持）。
- 新增行为正例：同胞非保护 E2E（后写臂体 perform 先写臂标签 → 越组外层传播接住）+ 组消费（resume 后受护计算兄弟效应 → 外层传播）+ 单臂零回归（D1 双面字节级）。
- ktf_handle_multiarm_tests 32 → 64（净 +32：8 正 + 24 负 1:3——§9.4.3）。

### D19：8 原语不变性与四方同步申报

**裁定**：零新原语零通道零 VM 语义原语；**VM 指令 +1**（`InstallHandlerGroup` #46——TD-033 登记范围明示的机制变更，诚实申报）。**四方同步**：opcode.rs enum ↔ `opcode_count_matches_spec`（46→47）↔ 04-bytecode-vm §1 指令表 ↔ compiler.ktf `OP-*` 常量表 + compiler.rs `op_from_value` 桥表（46 臂——变长操作数校验：偶数长度且 ≥ 6）。

*§8 遵循条款：原则 12（最优>最小）/ 原则 26（成熟度匹配）/ 原则 27（加性——InstallHandler 1-entry 零行为变更 + 单臂字节级零回归）/ 原则 31（皮肤/骨架同构——组等价门）/ §2.3-10（边界冲突先行解决）/ §9.4.3（1:3）/ §18（指令集变更四方同步审查）/ TD-033 登记裁定（组安装语义——VM/expander/compiler 两侧）/ r74 先例（指令即需求信号本体）/ Koka 浅处理多例先例。*

# 变参函数面（rest 参数）+ append 自建迁移设计单源

> **Author**: kerf-dev-agent（Super Z main — ARCH-A 设计裁定 + PM-A 开窗判定）
> **Date**: 2026-11-26（v1.0 开窗轮交付——r165 / 236-a）
> **Version**: v1.0
> **Status**: Closed（r165 / 236-f 收口——D1-D11 兑付 + **D7' 实施期实裁修订**：append 全量迁移泊回{注入/注册互斥 E0004 实测 + 种子链热消费双阻断——kerf 实现已证{测试门内联 kl_va_append 全语义 + 错误面逐字节}——TD-041 触发式重迁}；GATE 1 六命令全绿 2044:0:0 净 +32 + 审计 125:0 + CLI 零回归{fib 75025 + sum_rest 0/15 + 闭包 1} + bench fib 75.791ms{基线 76.506ms——-0.9% 噪声带}；TD-038 清偿关闭 + TD-040/TD-041 新登记{登记册 v0.4.23-r165}）
> **处理程度**: P2（设计规范 + 分步验收方案）｜ **所属 Stage**: Stage 3（list 域自建迁移窗 r164 的直接续窗——TD-038 清偿承载）
> **上游单源**: tech-debt-register.md TD-038{变参函数面语言缺位——append 自建迁移阻断} + list-self-built-design.md v1.1 §8{登记本体} / §9.1 + 02-syntax-model.md（EBNF Level 0）+ 20-surface-conventions.md §14{皮肤字典——本窗为机制窗非映射窗}

---

## 0. 开窗判定（TD-038 触发条件回填）

| 判据 | 实测 | 判定 |
|---|---|---|
| ① 变参函数用户面需求信号 | 用户指令①连续第五轮点名 list 族（「list函数、head函数、tail函数、cons函数等也是S表达式旧时代的设计和实现，请转向现代前沿编译器编译流程中的处理进行 ktf 端自建和处理」）——r164 已迁五定参成员，**append 为族内唯一剩余可迁成员，唯一阻断 = 变参面缺位**（r74 先例：用户指令 = 需求信号本体） | ✅ |
| ② 语言面设计窗（rest 参数语法裁定） | 本文件 = 设计裁定载体 | ✅ |
| 推荐序竞争 | TD-034 零信号休眠 / TD-039 阻断于 native-AOT 未就绪 / TD-040 本轮新登记（语料代码质量——独立批窗）——TD-038 为登记在案触发式唯一实际候选 | ✅ 首位 |
| 基线稳定性 | 2012:0:0（r164 起）+ 六命令 clean + 工作树 clean（HEAD c3c5b86） | ✅ |

**同轮附带腿（指令①代码质量维度）**：236-a-audit 语料四维实测（深度 ≤3 / 长度 / 命名 / 单一职责）——77 函数深度 >3（95% 集中 reader/expander 机械翻译三代件；`} else { if` 堆叠链为直接成因——compiler.ktf 同代件 `else if` 平链最深仅 4 实证可等价重写消解）→ **TD-040 新登记**（触发式批窗——本窗零语料重构，专项窗承载）。

---

## 1. 语法裁定（D1——现代 rest 参数形）

```
param       := name ':' type
             | '...' name ':' type        // rest 参数——终端位唯一
fn_decl     := "fn" [ generics ] '(' param-list ')' [ '->' effect_union ] block
param-list  := [ param { ',' param } ]    // rest 至多一枚且居末
```

- **D1-a 形选定**：`fn f(a: T, b: T, ...rest: T) { ... }` ——JS/TS/Rust 模式位同形（现代前沿主流）；`...` 词法 = **既有 r129 第九皮肤映射先例**（`three('.', '.', '.')` → `Tk::Ident("...")` 载荷——Rust reader.rs:893 + 种子 reader.ktf:792 镜像俱在）——**零 lexer 变更零新 Token 变体**。
- **D1-b 位置纪律**：rest 参数必须居参数列表末位，至多一枚；违例（`fn f(...a, b)` / `fn f(...a, ...b)` / 裸 `fn f(...)`）→ Reader 专用诊断 fail-closed（E0001 读错位）。
- **D1-c 类型面**：rest 参数类型标注 = **rest 绑定值自身**的类型（pair 链/nil——类型解析后剥离，与全部参数同律）；元素类型不编码（HM 无 List 元素参数化类型——D8 诚实边界）。缺类型标注 `fn f(...a)` → 既有「expected `:`」诊断面继承。
- **D1-d 闭包面同权**：`||(a: T, ...rest: T) { ... }` ——闭包参数与 fn 声明共用 `parse_typed_params`（reader.rs:3521 / reader.ktf:4536 消费点），rest 面自然继承（现代语言闭包/具名函数参数语法同形先例）。
- **D1-e 词汇面**：`...` 在参数位 = 保留形（macro 模板位的 `...` 椭圆语义 r129 不受影响——不同句法位不冲突；Stx 域 `...` 符号 = 既有 interned 符号）。

## 2. Stx/内核表示（D2——`...` 标记符沿 sig 列）

- **D2-a Stx 签名形**：`fn f(a: T, ...rest: T)` → 核心形式 `(define (f a ... rest) body)` ——`...` 标记符号沿参数列表流动（macro 模板同款符号——既有 intern 通道零符号系统变更）；**无标记 = 定参**（既有全量语料零涟漪——表示向后兼容）。
- **D2-b 无 CoreExpr 新变体**：`CoreExpr::Fn { params, body, .. }` **增字段** `rest: Option<Symbol>`（加性演化——原则 27；模式位全量更新非新变体非重构）；`IrNode::Fn` 同构增 `rest: Option<Symbol>`。
- **D2-c wire 协议零字段数变更**：expander 输出 fn 节点 `(fn s e exp (params...) scopes body)` 的 params 字段载 `...` 标记（compiler.rs:451-467 / check.ktf 消费面同协议）；proto 记录 `('proto name (params) nlocals ...)` 9 字段不变——params 字段内 `...` 标记 + rest 名（**协议版本零 bump——定参面逐字节向后兼容**）。
- **D2-d BcProto 显式字段**：`pub rest_slot: Option<u32>`（params = 定参名表；rest 槽 = `params.len()` 构造性成立，发射时校验断言）；`arity()` 面 = 定参数（min 语义——VM 消费见 D5）。

## 3. 编译链机制（D3——双侧锁步）

- **D3-a Reader**：`parse_typed_params` 增 rest 臂（参数名位见 `Ident("...")` → 期待后续 ident = rest 名 → `:` type 剥离 → sig 追加 `...` 标记符号 + rest 名符号）；双 Reader 锁步（Rust reader.rs:1735 + 种子 reader.ktf:2318 镜像——错误面消息 + Span 字节级 parity 纪律）。
- **D3-b Expander**：`parse_params`（Rust core_forms.rs:170 + 种子 expander.ktf:2141 镜像）识别 params 列内 `...` 标记 → 消费下一符号为 rest 名 → `CoreExpr::Fn { params: 定参, rest: Some(rest) }`；重复标记/非终端标记 → 展开期专用诊断（E0002 面）。
- **D3-c Compiler（种子 Rust compile.rs）**：Fn 编译臂——rest 槽 = `params.len()`、`n_locals` 含 rest 槽、体内 let 槽位起算 `params.len()+1`；proto 发射 rest 信息（wire 见 D2-c）。
- **D3-d Compiler（生产 compiler.ktf）**：fn 节点编译臂镜像（rest 槽位分配 + proto 记录 params 字段 `...` 标记发射）；桥 `proto_from_value`（compiler.rs:697）params 字段解析——遇 `...` 标记 → 拆分定参/rest 名 → `BcProto { params, rest_slot: Some(len) }`。
- **D3-e 增长签名锚重校准**：reader.ktf payload 三计数锚（215/504/246 族）随语料增长重校准（r160/r161/r164 同族纪律——单锚失败三值迭代定位法）。

## 4. VM 机制（D4/D5——帧建立与 arity 面）

- **D4-a arity 语义**：rest 原型 min-arity = `params.len()`（定参数）；实参 < min → E0004 `"procedure argument count mismatch: expected at least {min}, got {n}"`（新增「at least」形——定参面消息逐字节维持不变）；无上界。
- **D4-b 帧建立链构造**：实参 `[0..k)` 入槽 0..k；**rest 槽（= params.len()）绑定 `[k..n)` 实参的右折叠 nil 终止 pair 链**（0 超参 → nil——`append()` ⇒ nil 语义天然）；槽位 rest+1..n_locals 填 nil。非 rest 原型路径零变更。
- **D4-c 三位一体 + 双池路径**：vm.rs 三 arity 位（run_closure 入口:548 / Call:943 / TailCall:1084）+ `alloc_local_cells` 与 `acquire_local_cells`（帧池 P1 复用路径）**行为同一性**（td028 §3.3 四参数行为等价契约延拓——池命中路径的 rest 链构造与 fresh 路径逐值一致）。
- **D4-d eval.rs 树走 VM 同律**：Fn/apply 臂 rest 支持（min-arity + 链绑定）——Stage 0 解释器语义同构（测试消费面在位）。
- **D4-e 不可变性维持**：rest 链 = 构造期一次性分配（fresh cells——Pair 不可变构造律继承；GC children 面既有 pair 路径复用零 GC 变更）。

## 5. HM/check 面（D6——零类型系统增量）

- **D6-a 零新 Ty 构造子**：rest 绑定 = 普通类型变量（体内 is-pair/head/tail 消费约束其为 Pair∪Nil 域——既有推理自然收敛）；**无 List 元素参数化类型** = 诚实边界（要素类型不编码——HM 十一构造子面零增量）。
- **D6-b Apply 臂**：实参数 < min → 静态诊断（E0005 既有 arity 面族）；**超参 unconstrained**（Any/动态逃逸先例——内建 `list` 的 `TcParams::Variadic` 同语义：超参不设静态约束，运行时真值为准）。hm.rs（种子 oracle/fallback）+ check.ktf（生产判定面 r80 起）双面锁步。
- **D6-c BUILTIN_SIGS**：`append` 行维持（D7' 泊回裁定——注册面继续在位服务种子链/N1 面；行退役随 TD-041 迁移窗）。

## 6. append 自建迁移（D7——实施期实裁：泊回 + 触发式重登记）

> **实施期裁定（236-d 实探针实锤后修订 v1.0 原设计）**：原设计 D7-a..e（全量迁移清偿）撞双重实锤——①**注入面与注册面不可共存**：`import kerf_list` 注入的 `fn append` 在读段即被 import 预声明拒绝（「duplicate variable definition」探针实证——五自建名 r164 先例的根因正是注册退役，append 注册在位则注入必断）；②**种子链热消费**：reader.ktf ×6 + expander.ktf ×5 的 Stx 装配/宏产物拼接消费 append（r164 member/assoc 性能边界同族——12.5x PoC 在案，迁移即复现 check 墙）。循 r164 member/assoc 先例（已证 + 泊回 + 触发式）处置：

- **D7-a'（已证）**：kerf append 实现交付于测试门本体（ktf_variadic_rest_tests 内联定义 + 全语义/错误面探针——0 实参⇒nil / 1 实参 as-is / n 实参拼接 + 「append # N requires list, got TYPE」逐字节）——「语料实现已证」与 r164 同口径落档；
- **D7-b'（泊回）**：list.ktf 出口维持 r164 形（append 不入 export——注册面继续服务 N1/种子链/无 import 面）；
- **D7-c'（重登记）**：**TD-041 新登记**{append 自建迁移——阻断 = 种子链热消费 + 注入/注册互斥；触发 = native-AOT 性能回收（TD-039 同族）+ 语料拼接迁移（TD-040 reader/expander 批窗携带）}；
- **D7-d'（机制验收）**：TD-038 登记本体 = 「变参函数面**语言缺位**」——**面已闭环**（语法/双 Reader/展开/编译/wire/VM/帧/HM/check 全链 + 探针实证）；append 为其首个全语义消费者证明（测试门内联）。

原 D7 语义表（迁移窗开启时实施基准）：0 实参 ⇒ nil；1 实参 ⇒ as-is（r101 171-c）；n 实参 ⇒ 前置链展开 + fresh 链共享末参；全前置空 ⇒ 末参 as-is；错误面「append # {i} requires list, got {type}」逐字节；结构纪律（kl_flat_leading/kl_flat_one/kl_last/kl_build_go 俱尾递归 TD-022 + ≤2 深度 + 单一职责——测试门内联件为实施基准）。

## 7. 测试门（D8——32 case + 边界回归）

- **D8-a 构成**：8 正 + 24 负（≥1:3）——正向：rest 绑 pair 链 E2E{is-pair/head/tail 探针} / 混合实参数同函数 / `append()`⇒nil / `append(x)` as-is / `append(list,list)` 拼接 / 闭包 rest 面 / 高阶传递变参值 / 注入面 `list::append` 限定名；负向：Reader 结构族 ×6{非终端 rest / 双 rest / 裸 `...` / 缺类型 / 闭包同形 ×2} + VM min-arity「at least」面 ×3{Call / TailCall / 闭包入口} + HM 静态 min-arity + append 类型错误面 ×3{首参非 list / 中段非 list / 错误消息逐字节} + 非 nil 终止链 + 展开期重复标记 + 7 类错误 ≥6 类覆盖 + r164 边界回归 ≥5{length/reverse/nth/drop/last-pair E2E + member/assoc 维持半 + 注入级联 + 限定名 flat + 错误面锚}。
- **D8-b 既有负向审查面**：stdlib arity 矩阵 append 行 / builtins 计数守卫族（105/93/16/58 四守卫对账重校准）/ seed parity 计数锚 / krf_tests 域外行——涟漪定性纪律（§20.3 同类路径全量审查）。
- **D8-c 增长锚**：reader.ktf payload 三值 + 全局符号计数 + proto 计数——失败三值迭代定位法（r161 先例）。

## 8. 治理与打包（D9）

- **D9-a 八件**：02 EBNF 增 rest 参数产生式（v7.32）/ 20 §14 机制窗注记（**非映射窗**——本窗增 CoreExpr 字段 + BcProto 字段 + VM 帧行为，非纯皮肤）/ matrix 2012→目标行 / RELEASE r165 节 / t3plus v1.85 消费注记 / **TD-038 清偿关闭 + TD-040 新登记**（登记册 v0.4.23-r165）/ 本设计单源收口 / README 三处。
- **D9-b 包**：`kerf-v1.0.0-r165-varrest-{N}tests.tar.gz` §19 三验（独立解包净构建 + 包内全量复跑 + CLI 含新面探针）+ 包 vs HEAD diff 零差异实证（r161 勘误教训：打包入档后同步校验记录）。
- **D9-c web 五件**：kerf-data / hero 三 / footer 三 / download README / stats 双源自动——r164 同族。
- **D9-d 8 原语不变性**：本窗 = **机制窗**（非皮肤窗非原语窗）——零新**值域**原语零通道；CoreExpr/BcProto 字段 = 加性载荷（原则 27）；VM 帧建立行为 = 既有 Call 面的 arity 泛化（非新操作码非新原语通道）；四十七轮验证声明（r164 46 轮 +1）。

## 9. 诚实边界登记（D10）

1. **`list` 维持 N1**（r164 D1 裁定维持）：可见性机制（运行时全局绑定——forms 无法承载 N1 无声明可见性）+ 变参构造双阻断——本窗解除变参阻断后**可见性机制阻断仍在**（`list` 迁移 = 独立窗域，触发条件 = N1 可见性机制的语言面设计裁定）。
2. **append 全量迁移泊回**（D7' 实施期实裁）：种子链热消费 + 注入/注册互斥双阻断——TD-041 触发式（native-AOT + 语料拼接迁移）；**机制面与实现证明已交付**（测试门内联件）。
3. **HM 要素类型不编码**（D6）：rest 超参 unconstrained 静态面（运行时真值为准）——`TcParams::Variadic(Any)` 同语义先例；List 参数化类型 = Stage 2+ 愿景域登记态。
4. **rest 链构造位 = 帧建立期**（非调用点）：动态分派天然支持（高阶/闭包传递变参值——调用点无需被调者原型知识）；代价 = 每次调用构造 rest 链（实参已入栈——链构造 O(k) 恒量级于超参数）。
5. **调用点无展开语法**（无 spread 面）：`f(xs...)` 不在本窗域——变参传递的递归惯用法须经定参辅助函数（kl_sum 类）或直接传链；`f(head(rest), tail(rest))` 中 tail 作为**单实参**传入会被链化（诚实语义——探针实证）。
6. **`string-append` 维持 Rust**（kerf-string 域——r164 既有边界：宿主类型边界，非本窗域）。
7. **eval.rs**：树走 VM rest 支持 = 语义同构义务（测试消费面在位——完整性维护非生产路径变更）。
8. **AOT/WASM 后端**：anf.rs 对 rest 原语 fail-closed（「native code PoC boundary」——固定 arity PoC 域外诚实拒绝）。
9. **语料代码质量**（TD-040）：本窗仅新代码兑现纪律 + 登记；**存量 77 例深度违例不动**（独立批窗——r166 候选首位：reader.ktf else-if 平链化 + lex_op 分拆）。

## 10. 验收对账（D11——GATE 1 实录回填位）

| 项 | 目标 | 实录 |
|---|---|---|
| 六命令 | 全绿（0 error/0 warning/fmt 0 diff/clippy -D warnings 0） | ✅ build 0 警告 / check 0:0 / fmt 0 diff / clippy 0{type_complexity ×2 + needless_borrow ×1 实施期清偿——TypedParams/ParsedParams 命名别名} / test 2044:0:0 |
| 测试基线 | 2012 → 2044（净 +32；RUST_MIN_STACK=33554432） | ✅ 2044:0:0{2012 基线全维持 + ktf_variadic_rest_tests 32 新门} |
| 门审 | ≥30 case + 7 类 ≥6 + r164 边界 ≥5 | ✅ 32 case{8 正 + 24 负 1:3} + 6 错误类{E0001/E0004/E0005/E0006/E0019/E0022} + r164 边界 7{length/reverse/nth/drop/last_pair/member/last-pair 错误面} |
| CLI 零回归 | fib 144 / closures 42 / higher_order / vector / match / gc_stress / check 2/9/5/38 | ✅ fib(11)=89 / fib(25)=75025 + sum_rest 0/15{定参辅助模式——D9.5 惯用法} + 闭包 rest 1 + check 零回归 |
| 新面 E2E | 变参 fn / append 五形 / 注入面限定名 / min-arity 消息 | ✅ rest 链 E2E{nil/单元/5 元混合} + kl_va_append 五形{nil/as-is/拼接/三参/all-empty} + 闭包面 + min-arity 三位{Call/TailCall/闭包入口} |
| 增长锚 | 失败三值迭代定位法 | ✅ 216/507/247{+1 protos{rest_param_tail} +3 consts +1 globals——重校准三轮收敛} |
| bench | 零回归（±5% 噪声带） | ✅ fib 75.791ms{r164 基线 76.506ms——-0.9%} |
| 包三验 | 解包净构建 + 包内复跑 + CLI 探针 + diff 零差异 | ✅ 见 RELEASE r165 节 |
| 投票 | 加权 ≥95%（5.225/5.5） | ✅ 5.5/5.5 GO{验收即兑付} |

---

*遵循条款：TD-038 触发条件①②（登记册 v0.4.22——用户需求信号 + 设计窗本体）/ §2.2 原则 27（加性演化）/ 原则 31（皮肤/骨架分离——本窗为机制窗的诚实申报）/ 原则 9（核心冻结——零值域原语零通道）/ §2.3-1（正确>妥协——wire 协议零 bump 的兼容性裁定）/ §2.3-4（报错>静默——min-arity fail-closed）/ §20.3（同类路径全量审查——涟漪十二处定性纪律）/ r164 list-self-built-design v1.1（迁移模式先例族）/ r129 第九皮肤映射（`...` 词法先例）/ r101 171-c（append 语义基线）。*

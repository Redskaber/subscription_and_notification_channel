# 索引访问窗设计单源（`coll[idx]` postfix 中缀面——第十七皮肤映射）

> **Author**: kerf-dev-agent（Super Z main — ARCH-A 裁定 + DEV-A 实施 + QA-A 验收）
> **Date**: 2026-11-26（r163 / 234）
> **窗性质**: 目标语言表面 postfix 索引面开面（one face, one name 轨迹第十步：索引访问面——r158 顶层 let / r159 运算符面 / r160 数据结构面 / r161 绑定性质面 / r162 相等域面连续五窗后第六窗）
> **开窗依据**: 用户指令①审计清单持续覆盖「基础内置函数、数据类型、数据结构」——数据结构消费三角缺口实锤{构造角 r160 `(a,b)` / 解构角 r121 模式位 / **索引角域外**}；M1 指令开窗（r156/r160/r162 连续同族先例）
> **状态**: Closed（r163 / 234-e 收口——D1-D10 全兑付 + GATE 1 实录回填 §5）

---

## §1 背景与缺口（本窗登记本体）

- **域外登记双点**：Rust reader.rs postfix 尾循环 `Tk::LBracket ⇒ domain_out("index(collection type out of domain)")`（r138 / 208-c TD-002 D6 position discipline——primary 位 `[a, b, c]` 字面量已开面，postfix 位索引域外）；种子 reader.ktf:4178 镜像同判。
- **前置探针矩阵（本窗 234-a——P1-P15 十五探针）**：
  - `v[0]` ⇒ E0001 域外（双 Reader 同判）；`v[0] = 5`（assign 位）/ `v[1 + 1]`（表达式索引）/ `"abc"[0]`（Str 索引）俱同 E0001 域外拦截；
  - `vector-ref(v, 0)` 连字符直书 ⇒ **E0022 unbound `ref`**（r159 运算符面副作用——连字符名被中缀 `-` 词法拦截，与 r162 D2 `=` 休眠态同族）；
  - `vector_ref(v, 1)` + `import kerf_vector;` ⇒ **20 ✅**（N2 模块导出下划线面——r138 交付的现代调用形）；
  - `[10, 20, 30]` 字面量 + `vector(...)` N1 构造 + `==`（r162 结构相等）俱 ✅——Vector 值类型现代面完整**除索引中缀面外**；
  - `nth(list(1, 2), 1)` + `import kerf_list;` ⇒ 2 ✅（pair-list 索引调用形）。
- **缺口定性**：表达力缺口非正确性缺陷（N2 调用形可达 + VM fail-closed 完备）——但「现代索引面 = 所有现代语言标配 `coll[i]`」+ 数据结构消费三角的第三角缺位 ⇒ 用户审计清单命中项。

## §2 设计裁定 D1-D10

- **D1（皮肤映射——第十七）**：`coll[idx]` postfix 位索引中缀面 → as-if-written `(vector-ref coll idx)`。Reader 直接合成与调用形产物同构的 Stx（皮肤换、骨架不变——原则 31：零脱糖 pass 零新原语零 CoreExpr/IR/操作码，expander/compiler/HM/VM 全链零触及，8 原语不变性第四十五轮）。既有第十六映射行族不变——本窗新增映射行。索引位 = 完整表达式（`v[i + 1]` 合法）；嵌套链式索引 `v[i][j]` = postfix 循环自然组合（合成产物为表达式，继续参与尾循环）。
- **D2（N1 可见面扩容——编译层放行）**：`vector-ref` 入 `N1_CORE_NAMES` 数据模型词汇组（cons/head/tail/list/vector 组 +1——第 42 名；r138 `vector`/`is-vector` 同族先例）。VM 全局注册表既有（builtins.rs:164——`defs.push(("vector-ref", …))`）⇒ **零 VM 触碰**；扩容 = 编译层符号解析白名单 +1（driver.rs 多点 `N1_CORE_NAMES.contains` 自然命中）。副作用审计：N2 注入面零冲突（kerf_vector 下划线导出名 `vector_ref` ≠ N1 连字符名 `vector-ref`——字符串不等无遮蔽；1034 行 flat_underlying 命中后进 flat 面为收紧面[冲突检查更严]，无破坏性——全量测试族验证）。诚实申报：连字符 `vector-ref` 直书依然被 r159 中缀词法拦截（Reader 层不可达维持）——N1 扩容只服务**脱糖产物 Stx 符号**的编译层放行（与 r162 `=` 休眠态对照：`=` 词法 Assign 不可直书 + N1 在册——同构形态）。
- **D3（脱糖目标免 import 纪律）**：r138 D4 裁定原文沿袭——「the desugar target of `[a b c]` must be import-free; **a literal demanding an import would be broken language design**」。`v[i]` 同律：语法面（中缀/字面量）脱糖目标必须在 N1 免 import——若脱糖到 N2 `vector_ref`（须 import kerf_vector）则 `v[0]` 对未 import 用户报 E0022 = 坏的语言设计。本窗 D2 扩容正是 D3 纪律的机制兑付。
- **D4（fail-closed 三面沿用——VM 零改动）**：非 Vector 首参 ⇒ `err_vector_op`（E0004 族）；非 int 索引 ⇒ 专用诊断「vector-ref index requires int」；越界（负或 ≥ len）⇒ 专用诊断「vector-ref index out of bounds」——r138 三 fail-closed 面零改动自然继承（索引算术错误族独立于域错误族的 r138 既有裁定维持）。
- **D5（不可变裁定维持）**：`v[i] = x` 索引赋值 = **域外维持**。r138 D1 不可变性（拼接产新 vector、操作数永不突变）——Reader assign LHS 只接受标识符绑定域，`v[0] = 5` 在 Reader 层自然拒收（E0001 族——assign 位不是 postfix 表达式位）。诚实申报：可变索引赋值若未来开窗须先修订 r138 D1 不可变裁定（本窗零行动——登记维持）。
- **D6（诚实边界三条）**：①pair-list 索引维持 `nth(lst, i)` 调用形（`import kerf_list` 面）——`v[i]` 脱糖目标为 vector-ref，对 Pair 值运行时 E0004 fail-closed（不静默分派——分派索引 = 新内建 = 域外语义模糊，诚实拒收优于猜测分派）；②Str 字符索引域外——`"abc"[0]` 走到 VM 层 vector-ref 的非 Vector fail-closed（E0004 运行时诊断——字符索引是独立设计题[字节位 vs 字符位 vs 码点位]，未来窗域外登记）；③空索引 `v[]` 与多参 `v[1, 2]` ⇒ Reader 层专用诊断（恰一个索引表达式——`v[]` 报 expected expression 族；`v[1, 2]` 报 expected `]` got `,`——E0001 族 fail-closed）。
- **D7（Span 契约）**：合成 `vector-ref` 头符号 Span = **`[` Token 本位**（r160 D10 合成 cons 符号 = `(` Token 本位先例——postfix 起点锚定，错误定位直觉指向索引起点）；合成 list Stx 整体 Span = merge(coll.span, `]` Token span)（既有 postfix 合并律维持）。
- **D8（HM/check 面零增量）**：BUILTIN_SIGS 既有 `vector-ref (any, any) → unknown`（check.ktf TC_SIGS 表 826 行）——合成 Stx 走既有 sig，零注册链增量（r160 D6 `(Any,Any)→Pair` 既有同族先例）。
- **D9（双 Reader 锁步）**：Rust reader.rs postfix 尾循环 `Tk::LBracket` 臂开面（域外臂替换为解析臂）+ 种子 reader.ktf:4178 镜像同型开面（`nd_sym("vector-ref", …)` + `nd_lst` + `postfix_loop` 递归）。错误面（空索引 / 多参 / eof 截断）消息+Span **字节级 parity**（同族纪律）。
- **D10（语料零迁移 + 双面并存）**：现代语料索引消费 = 零命中实测（种子域 vector-ref 直书 0 + examples 0——r159 连字符拦截使然）；N2 `vector_ref` import 调用形**维持合法**（双面并存：中缀面为主面 + 调用形为兼容面——与 r162 后 `==`/`eq(...)` 关系同构）。语料零强制迁移；增长签名锚重校准（实施后实测——reader.ktf payload 单锚迭代法）。

## §3 实施面清单

| 面 | 文件 | 变更 |
|---|---|---|
| Rust Reader | crates/kerf-reader/src/reader.rs | postfix 尾循环 `Tk::LBracket` 域外臂 → 开面解析臂（bump `[` → parse_expr → expect `]` → sym_at "vector-ref"（open 本位）+ list_at 三元合成）+ 注释同步（3439 行 D6 注记更新） |
| 种子 Reader | crates/kerf-driver/src/bootstrap/reader.ktf | postfix_loop `[` 域外臂（4178）→ 镜像开面臂（parse_expr + p_expect `]` + nd_sym "vector-ref" + nd_lst + postfix_loop 递归）+ 4417 行 D6 注记同步 |
| N1 名单 | crates/kerf-driver/src/builtins.rs | N1_CORE_NAMES 数据模型词汇组 + `"vector-ref"`（第 42 名 + 组注记） |
| 测试门 | tests/v0/stage3/plan/ktf_index_access_tests.rs | 32 case（8 正 + 24 负 1:3）+ runner.rs 注册 |
| 计数断言 | crates/kerf-driver/src/builtins.rs | `n1_core_and_module_flats_closed` 双修订（N1 41→42 + shrink 面 22→21——vector-ref 跨面迁移；恢复轮发现当场清偿） |

## §4 测试门构成（GATE 5/6 对照）

- **8 正**：`v[0]` 基本索引 / 末位索引 / 表达式索引 `v[i + 1]` / 嵌套链式 `v[i][j]`（二维 vector）/ 字面量直索引 `[10, 20, 30][1]` / as-is-written 字节码全等门（`v[1]` vs `(vector-ref v 1)` Stx 同构）/ r138 边界回归（`vector_ref` N2 面维持合法）/ r160 跨阶段消费（元组构造 + 索引? ——元组是 Pair 非 Vector，诚实边界负向——正向腿用 vector 字面量索引）
- **24 负**：E0001 族（空索引 `v[]` / 多参 `v[1, 2]` / eof 截断 `v[1` / assign 位 `v[0] = 5` / r161 边界四联{assign 拒收 / const mut / 单绑定 / 块位域外}）/ E0004 族（非 Vector 首{`"abc"[0]` Str 域外 / `(1, 2)[0]` Pair 域外} / 非 int 索引 `v["x"]` / 负索引 `v[-1]` / 越界 `v[99]`）/ E0005 族（check 静态 ×2）/ E0006 族（能力门）/ E0022 族（未绑定 coll）/ 双 Reader parity 负形 ×2（`v[]` / `v[1, 2]` 锚定）/ 混合边界（`v[true]` 非 int）
- **7 类错误覆盖**：E0001 / E0004 / E0005 / E0006 / E0022 / E0002 / E0012+ ≥6 类；**上轮（r162）修复边界 ≥5**：混合域静默 false ×2{`1 == "1"` / `true == 1`} + 结构相等回归 + ordering 维持 + `==` E0004 退役面
- **集成 ≥3**：run E2E / check E2E / as-is-written Stx 同构 / 双 Reader parity ×4 形

## §5 GATE 1 实录（回填位）

- 六命令实测全绿（234-d 复核实录）：build 零告警 / check 0:0 / fmt 0 diff{恢复轮发现一处遗留折行违规当场清偿} / clippy -D warnings 0 / **test --release --workspace 1979:0:0 净 +31**（RUST_MIN_STACK=33554432）{设计期预估 1980/净 +32 失准勘误：32 新增 − 1 退役（ktf_vector_value_tests neg15 postfix 域外锚随合法化退役）= 31 实际}
- 审计复跑：architecture_audit 6:0 + seed_ktf_parity 119:0（全绿）
- 实施期涟漪第四/五处（§3 清单之外的恢复轮发现，当场清偿）：builtins.rs `n1_core_and_module_flats_closed` 计数断言双修订{N1 41→42 + shrink/contracted 22→21——vector-ref 从 kerf_vector 模块 underlying 面（"vector 3" 之一）移入 N1 面，shrink 面剩余 vector-length/vector-append 二名}
- CLI 零回归探针：fib（examples/usage/fib.ktf ⇒ 75025 + ⇒ 144）/ closures 42 / const 6 / r162 相等域 true+false 维持
- 新面 E2E 八探针：`v[1]`⇒20 / `v[i + 1]`⇒30 / `m[1][0]`⇒3 / `[10, 20, 30][2]`⇒30{正向四} + `v[99]`⇒E0004 "vector-ref index out of bounds:99(length 3)" exit 1 / `v[]`⇒E0001 "expected an expression, got RBracket" / `v[1, 2]`⇒E0001 "expected ], got Comma" / `v[0] = 5`⇒E0001 "expected ;, got Assign"{负向四——D4 专用诊断 + D5 不可变 + D6 fail-closed 三面俱实证} + 域外双边界：`"abc"[0]`⇒E0004 "vector-ref requires vector, got str" / `(1, 2)[0]`⇒E0004 "got pair"
- 增长签名锚实测回填：**215/504/246 零增量维持**{一进一出巧合：postfix `[` 域外臂退役释放的 `index(collection type out of domain)` 消息字符串常量槽，恰被新入的 `"vector-ref"` nd_sym 字符串填补——payload consts 净零；零新 proto（postfix_loop 既有函数内联展开）零新 global}

---

*遵循条款：原则 31（皮肤换骨架不变）/ 原则 27（皮肤映射登记纪律——第十七行）/ 原则 38（域外登记维持——Str 索引/pair-list nth/可变赋值三登记态零提前实现）/ 原则 41（内核聚合基座生命周期——vector-ref N1 扩容 = 词汇面非原语面）/ §2.3-4（报错 > 静默——三 fail-closed 面维持）/ §8.4.5（文档-代码同次修正）/ §20.3 + §20.6（同类路径全量审查——postfix 族六臂邻审{DotDot/Pipe/Dot/LBracket/KwAs/Amp 族}俱维持域外仅 LBracket 开面）。*

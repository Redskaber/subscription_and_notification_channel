# r74 窗口开启回填与四任务推进计划

> **Author**: kerf-dev-agent（PM-A + ARCH-A 复合——r74 轮）
> **Date**: 2026-09-24
> **Version**: v1.0（r74 / 144-a 首件）
> **Status**: Active（本轮执行中）
> **上游驱动**: 用户 r74 显式指令（本文件 §1 回填载体）

---

## 1. 开窗判据回填（23 §2.2 + §2.3 红线 3 合规）

**红线 3（禁止无信号开窗）要求任何窗的开启回填入口信号的逐项满足证据。本节即回填载体。**

r73 状态报告（rec 37 §E）给出用户三决策点：①给消费信号开窗 ②显式指定方向 ③维持待触发态。
r74 用户指令**行使决策点 ②（显式指定方向）**，点名四项任务：

1. HM/typecheck .krf 路径验证
2. WasmBackend 组件模型
3. 构建系统重写（driver .krf 化）
4. 先完成非 S 表达式转化目标语言后才能实现的任务（门控任务前置清单）
   （附带声明：「最后会给机会深入深度和广度的探讨目标语言的相关设计」——目标语言设计讨论 = 表面语法切换窗的未来入口信号，本轮不开。）

**判据回填表**（对照 [23 §2.2 T3+ 其余行](../../../lang-design/23-evolution-governance.md) + [t3plus-trigger-audit §5](./t3plus-trigger-audit.md) + [bootstrap-replacement-surface-map §5](./bootstrap-replacement-surface-map.md) 缺口清单）：

| 窗 | 既有触发判据（零信号维持） | r74 开窗依据 | 开窗形态（本轮范围） |
|---|---|---|---|
| HM .krf 路径验证（缺口④） | INC3：静态分析面不在自举关键路径；K3 终态 = HM 旗标期维持，默认期切换窗口归 23 §2.2 Stage 3 触发式 | **用户显式指令 ① = 需求信号命中**（r73 §E 决策点 2 形态） | **路径验证 PoC**——check.krf 迷你 HM 推断机（VM 上运行，消费与 compiler.krf 同一 core 节点 wire 协议）+ 桥 + parity 测试。**非生产切换**（判定面维持 hm_check_program——INC8/K3 裁定不动） |
| WasmBackend 组件模型（缺口⑥） | 13 §3.3.7 P1 预留 trait；Stage 2+ 可选后端按契约实现（做实无信号） | **用户显式指令 ② = 需求信号命中** | **组件模型契约做实**——WASM Component Model 结构化形状（组件/接口类型/导入导出/Canonical ABI）+ 构建器 + 校验 + 设计文档。**codegen 不做实**（登记 TD-031 触发式维持） |
| 构建系统重写 driver .krf 化（缺口⑦） | 07 §3.3 Stage 2→3 信号「构建系统可用新语言重写」 | **用户显式指令 ③ = 需求信号命中** | **第一切口**——build.krf（prelude 注入判定 imports_prelude 的 .krf 移植）+ 桥 + **生产切换**（Rust 版退役为 parity oracle）+ 余下面登记 TD-032 |
| 目标语言门控任务（缺口①②关联） | 12 §2.4.1 目标语法蓝图；切换节点 = 技术就绪 + 治理待触发（r70/139-a 裁定链） | **用户附带声明 = 未来入口信号预告**（设计讨论在后） | **门控任务清单前置交付**（本文件 §5 + target-language-gated-tasks.md）——不开语法切换窗（红线 1：设计讨论未发生，切换判据未满足） |

**合规声明**：四窗的开启依据均为用户显式指令（r73 §E 决策点 2 的行权），非时间驱动（红线 1 合规）、
非自主无信号开窗（红线 3 合规——用户指令即信号本体，回填于本节）。表面语法切换窗（139-a §5.2 六步清单）
**不在本轮开启范围**：其入口信号 = 用户预告的目标语言设计讨论（深度广度探讨），产出将回填
[02-syntax-model](../../../lang-design/02-syntax-model.md)/[12 §2.4.1](../../../lang-design/12-roadmap.md) 后才满足开窗条件。

---

## 2. HM/typecheck .krf 路径验证（144-b）——设计摘要

**命题**：kerf 语言（VM 上运行的 .krf 程序）能表达 HM 类型推断的数据结构与算法，
且自举链（种子编译 → VM 执行）能承载静态分析段的宿主桥接——「HM/typecheck 可走 .krf 路径」的路径级证明。

**实现形态**：
- `kerf-driver/src/bootstrap/check.krf`：迷你 HM 推断机（入口 `lchk-check-program`，
  消费与 compiler.krf **同一 core 节点 wire 协议** `('tag s e exp ...)`——桥零新协议）。
  镜像 Rust hm.rs 子集语义：类型格（tvar/tcon{int,float,num,bool,str,nil,sym}/tpair/tarrow）、
  合一（occurs 检查 + 数值格互匹 + Dynamic 吸收）、格 join（If 分支汇合/set! 具体目标）、
  值限制泛化（define/let 语法值泛化）、递归预置（define fresh 变元合一）、
  内置签名表（算术/比较族 num 规则 + 元数下限）。
- `kerf-driver/src/bootstrap_check.rs`：宿主桥（镜像 bootstrap_compiler.rs 形态——
  线程局部状态 + 种子加载 + call_closure 入口调用 + item_to_node 复用序列化）。
- `tests/v0/stage3/plan/hm_krf_path_tests.rs`：**parity 判据**——同源程序双面判定
  （Rust hm_check_program vs krf 迷你推断机）accept/reject 逐 case 一致（≥14 case，
  正负比 ≥1:3）；子集越界节点（perform/handle）→ 结构化跳过（诚实边界）。

**不做**（触发式维持）：生产判定面切换（INC8/K3 裁定不动——判定面仍 = hm_check_program）、
多错误收集（PoC 单错误短路——Rust 侧 drain 多错误为生产面差异，登记于 §7 余下清单）、
消息级 parity（PoC 判定级 parity——结构级消息 parity 属未来生产切换窗义务）。

**价值**：B 类形态 2 替换候选（替换面图 §3.3 HM 中窗）的**可替换性实证**——
中窗若开（默认期切换），路径已被验证可承载；同时是「语言表达静态分析算法」的能力扩展验证。

---

## 3. WasmBackend 组件模型（144-c）——设计摘要

**命题**：WASM 组件模型（2026 标准：component model + interface types + canonical ABI + Wasm GC）
的契约形状从「字节信封占位」深化为「结构化组件模型」——13 §3.3.7 WasmBackend P1 预留的做实前置件。

**实现形态**：
- `kerf-backend/src/wasm.rs`：组件模型契约层——
  `InterfaceType`（primitive/record/variant/list/tuple/func/option/result——接口类型值域）、
  `ComponentFunc`（参数/结果名类型对——组件级函数）、
  `ComponentImport/ComponentExport`（导入导出面——能力边界的组件级表达）、
  `CanonicalAbiOptions`（utf8/utf16/realloc/memory64——canonical ABI 选项）、
  `WasmComponentModel`（核心模块函数清单 + 导入导出面 + ABI 选项——组件整图）、
  `ComponentModelBuilder`（构建 + 校验：导入名唯一/函数名唯一/类型良构）。
- `WasmComponent` 结构化扩展：`{ bytes, model }` 双字段（`model` 携带结构化组件模型——
  原 `bytes` 字段与 `Default` 兼容不变，构造字面量点更新——原则 27 加性演化）。
- 设计文档 `wasm-backend-component-model.md`：组件模型映射设计（kerf 值域 ↔ 接口类型、
  AnnotatedANF → 核心模块函数清单、效应/能力在组件边界的表达、宿主桥接残余面、
  M1-M3 分阶段做实路线 + 触发判据）。
- TD-031 登记：WasmBackend codegen 实施（P3 触发式——组件模型契约已做实，字节码生成维持触发式）。

**不做**：实际 WASM 字节码生成（触发式维持——TD-031）、wasmtime/wasmparser 依赖引入
（零新依赖——§18 依赖审查纪律；契约层纯 Rust 数据建模）。

---

## 4. 构建系统重写 driver .krf 化第一切口（144-d）——设计摘要

**命题**：07 §3.3 Stage 2→3 信号「构建系统可用新语言重写」的首个生产实证——
构建系统的模块解析面（prelude 注入判定）以 .krf 实现并切换为生产路径。

**实现形态**：
- `kerf-driver/src/bootstrap/build.krf`：入口 `lbld-imports-prelude?`
  （消费 Stx 节点树——stx_to_node 同款六头字段协议），返回 bool。
  移植 imports_prelude + imports_prelude_module 全语义（顶层 import 形式 +
  module 头部区 import 扫描 + as 别名跳两位游走）。
- `kerf-driver/src/bootstrap_build.rs`：宿主桥（同 bootstrap_compiler.rs 形态）。
- **生产切换**：`resolve_prelude_imports` 改经 .krf 判定；Rust 版退役为 parity oracle
  （测试对照——与 reader/expander/compiler 三段切换同构的第五段切换形态：构建系统段）。
- `tests/v0/stage3/plan/build_krf_parity_tests.rs`：parity corpus ≥10 case
  （无 import / 顶层 import / module 头 import / as 别名 / 多 module / 嵌套 module /
  import 非 prelude / export 头部 / 体形式终止 / 组合形）+ 生产路径活性守护。

**不做**（登记 TD-032 触发式/用户指令续窗）：缓存段 .krf 化（cache.rs——字节级哈希面，VM 原语缺位）、
CLI 编排 .krf 化、测试运行器 .krf 化、测试入口 .krf 化——余下面清单见 TD-032。

**性能预算**：prelude 判定 = 每次编译一次额外 VM 入口调用（与既有 read/expand/compile 三次
VM 调用同量级叠加 <1ms）——fib bench 带内验收（<72ms 容差，基线 70.8-71.7ms）。

---

## 5. 目标语言门控任务前置清单（144-e）——范围声明

「先完成非 S 表达式转化目标语言后才能实现的任务」= 被表面语法切换门控的任务全集。
本轮交付 **门控任务清单 + 触发判据 + 前置可推进项**（target-language-gated-tasks.md），
不执行门控任务本体（其入口信号 = 用户预告的目标语言设计讨论——设计产出回填 02/12 后开窗）。

---

## 6. MUV 拆分与验收对照（本轮 L3 全量流程）

| Task ID | MUV | 量化验收 |
|---|---|---|
| 144-a | 开窗回填 + 本计划文档 | 本文件落档（§1 回填表五行齐全） |
| 144-b | HM .krf 路径验证 PoC | check.krf + 桥 + parity ≥14 case 双面一致 + 全套件零回归 |
| 144-c | WasmBackend 组件模型 | wasm.rs 契约测试 ≥8 + 设计文档 + TD-031 登记 |
| 144-d | driver .krf 化第一切口 | build.krf 产量切换 + parity ≥10 case + bench 带内 |
| 144-e | 门控任务清单 | target-language-gated-tasks.md（≥6 门控项 + 判据列齐全） |
| 144-f | 文档同步 | 07/08/12/TD 登记/t3plus/surface-map 六件同步 |
| — | §3.2 六命令 | clean 起步全绿（build 零告警 + 0/0 + fmt 0 + clippy 0 + test 全过 ≥950） |
| — | 门审计复跑 | 六审计集 280 case EXIT 0 ×6 |
| 144-z | 打包 | tar.gz + 包内自举三验 + native PoC |
| 144-web | web 面 | kerf-data 五处 + footer + stats + E2E 双视口 |
| 144-c2 | 收口 | 投票 5/5 + GATE 1-5 + rec 38 + matrix + RELEASE + 层 l + 三链镜像 |

---

## 7. 结论汇总

1. 四窗开启依据 = 用户 r74 显式指令（r73 §E 决策点 2 行权）——回填于 §1（红线 1/3 合规）。
2. 三实施窗的形态刻意收敛为**验证/契约/切口**三形态（PoC + 契约做实 + 第一切口）——
   与「先完成非 S 表达式转化目标语言后才能实现的任务」的前置定位一致：本轮建立可验证的路径与契约，
   生产级全量做实留待各自触发判据（INC3/K3 默认期、TD-031、TD-032）或用户后续指令。
3. 表面语法切换窗不开（其入口信号 = 用户预告的目标语言设计讨论）。
4. 测试计数 923 → ≥950（净增 ≥27：hm_krf_path ≥14 + build_krf_parity ≥10 + wasm ≥8——
   实际以交付为准，matrix.md 增量行落档）。

*遵循条款：用户 r74 指令（四任务点名 + 打包 + web 驱动源）/ 23 §2.2 + §2.3 红线 1/3（触发表单源 + 开窗回填纪律）/ r73 rec 37 §E（用户决策点 2 行权形态）/ 07 §3.2/§3.3（混合期构成 + Stage 2→3 信号）/ 12 §2.4.1 + §2.5.1（目标语法蓝图 + HM K3 终态）/ 13 §3.3.7（WasmBackend P1 预留）/ t3plus-trigger-audit §5（外源三窗缺口清单）/ bootstrap-replacement-surface-map §3.3/§5（B 类形态 2 三段 + 缺口七行）/ §4 MUV/§8.4.5/§8.4.6/§8.6（MUV 拆分 + 裁定附条款号 + 产物位置 + worklog 纪律）。*

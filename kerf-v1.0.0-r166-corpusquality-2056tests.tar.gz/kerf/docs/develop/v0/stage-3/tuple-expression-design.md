# 元组表达式形窗（pair 构造现代面）设计单源 v1.0

> **Status**: Closed（r160 / 230-c..230-d 全链交付——GATE 1 六命令全绿 + test 1884:0:0 净 +32 + 语料迁移输出 parity 逐字节 + TD-036 清偿关闭）
> **Date**: 2026-11-25（r160 / 230-b..230-d）
> **窗编号**: r160 / 230 族（230-a..230-e）
> **窗性质**: 目标语言表面语法现代化（one face, one name 轨迹第七步：数据结构面——pair 构造/解构对称缺口清偿）
> **开窗依据**: M1 指令开窗第六十五例——用户指令①「数据类型、数据结构……S 表达式旧时代的内容……应该通过目标语言自身设计实现」的数据结构面专项行权 = TD-036 触发条件①（用户指令直接开窗——r159 / 229-c 登记）
> **一句话**: match 模式位 `(a, b)` pair 解构形自 r121 起即为现代面，而表达式位构造形缺位——用户被迫回落 `cons(a, b)` Lisp 时代调用形（构造/解构对称缺口，TD-036）；本窗补齐 `primary → "(" expr "," expr ")"` 元组表达式产生式（第十五皮肤映射，as-if-written `cons(a, b)`——皮肤换、骨架不变），语料 pair 构造位现代化，TD-036 清偿关闭。

## §1 问题陈述（230-b 审查结论）

**现状**（r159 基线实测）：

- 模式位：`match p { (a, b) => ... }` = pair 解构现代形（r121 match 窗交付——「括号内至多二元」消歧裁定）
- 表达式位：`(1, 2)` ⇒ `E0001 expected ), got Comma` **fail-closed**（reader.rs:3241 分组臂无逗号路径）
- pair 构造唯一可用面 = `cons(a, b)` 调用形——**S-expr 旧时代习惯在数据结构面的存活**（TD-036 登记原文：「仅 cons(a, b) Lisp 时代调用形可用」）
- 语料实录：match.ktf `describe(cons(1, 9))`——解构用现代形、构造用旧形，同函数内两面割裂

**对照（现代主数据结构面先例）**：vector（r138）= `[a, b, c]` 字面量现代构造面 + 五内建族；pair = 内核聚合基座（原则 41——非脚手架），构造面缺位是**能力登记**（TD-036）非债务本体，本窗兑付。

**机制确认（探针实测）**：

1. `cons` 注册链完整：N1_CORE_NAMES（E0022 可见面）+ register_globals（运行期全局）+ BUILTIN_SIGS `(Any, Any) → Pair`（Rust HM）+ check.ktf TC_SIGS（bootstrap HM）+ anf.rs `cons → APrim` native PoC——as-if-written 脱糖路径**零下游变更**
2. `1 + cons(2, 3)` ⇒ E0005 `+ requires a number, got (int . int)`——HM 已知 cons 产 Pair 型，`(2, 3)` 脱糖后同面自动覆盖
3. `head(5)` ⇒ E0004 `head requires pair, got int`——访问面域错既有
4. 语句位 LParen 分派：`_ => parse_expr()`（parse_stmt_or_expr 兜底臂）——语句位元组自然可达（gc_stress 语料位）

## §2 裁定 D1-D10

### D1 元组表达式产生式（新形态——二元 pair 构造）

```ebnf
tuple_expr  ::= "(" expr "," expr ")" ;
               (* 第十五皮肤映射：primary 位受理；as-if-written cons(a, b)
                  —— Reader 直接合成 Stx (cons e₁ e₂)，与调用形产物同构
                  （皮肤换、骨架不变——r158 define 合成先例 + r138 vector
                  as-if-written 先例）；零脱糖零新原语零 CoreExpr/IR/
                  操作码[原则 9/31] *)
primary_expr ::= ... | tuple_expr ;
```

**Span 契约**：合成 `cons` 符号 Span = `(` Token 本位；列表 Span = `(`..`)` 合并（双侧一致——正典渲染 parity 含 Span 字节）。

### D2 元数封顶 = 二元（对称纪律）

`(a, b, c)` ⇒ fail-closed 专用诊断「at most two elements in a tuple expression ((a, b) -- right not nested prevents unbounded tuples)」——与模式位消息族对称（模式位 r121：「at most two elements inside pattern parentheses ((p, q) -- ...)」）。**构造 ⟺ 解构对称**：模式位二元封顶 ⇒ 表达式位二元封顶；深层嵌套经显式 `(a, (b, c))`。Span = 第三个逗号 Token 本位。

### D3 单元组/空组维持（既有语义零扰动）

- `(a)` = 纯分组（parse_expr 后无逗号 → 既有路径）——**不变**
- `()` = Unit 字面量（词法歧义由句法位置决定——既有纪律）——**不变**
- `(a)` 非单元组（单元组 = 无新语义通道，Rust/Python 单元组俱特判弃用面）

### D4 尾逗号 fail-closed（vector 同律）

`(a,)` ⇒ 「tuple literal trailing comma illegal((a,) -- expected an expression)」，Span = 逗号..后随 Token（r138 vector 尾逗号诊断同构——`[a, b,]` 先例）。`(a, , b)` 首域双逗号经 parse_expr 自然失败（E0001 expected an expression）。

### D5 cons 调用形维持（内核聚合基座名——不退役）

- `cons(a, b)` = **内核聚合基座名**（原则 41：pair 非脚手架）+ list 链构造惯用形（`cons(n, mk(n-1))` 链式——effect_stress/higher_order/vector 语料实录）
- 本窗 = **能力补齐**（构造现代面），非退役窗：`(a, b)` 成为主面后 cons 调用形维持合法（一个概念两个面——r159 `%`/`mod` D1 同型；区别：cons 是内核名非旧别名，两面俱一等）
- **种子域七件 .ktf 零扰动**（r159 D1 同律——bootstrap 字节码 parity 锚保护）

### D6 HM/check 零变更（脱糖即既有调用）

`(a, b)` → `(cons a b)` 后：BUILTIN_SIGS `(Any, Any) → Pair`（Rust HM）+ TC_SIGS（bootstrap HM）+ verify_unbound_refs（E0022）+ capability（cons 零能力）全链既有消费——**零注册链增量**（r159 `%` 五点注册的对照面：本窗语法位即终点）。

### D7 双 Reader 错误面字节级 parity

三条专用诊断（3 元封顶 / 尾逗号）+ 自然失败面（前导逗号 / EOF 族 / 非表达式 Token）双侧消息 + Span 字节一致（r158/r159 纪律）。

### D8 语料现代化（pair 构造位 only——用户面）

| 文件 | 迁移 | 不迁（list 链惯用形） |
|---|---|---|
| match.ktf | `describe(cons(1, 9))` → `describe((1, 9))` | — |
| gc_stress.ktf | `cons(1, 2); ... cons(19, 20);` → `(1, 2); ... (19, 20);`（离散 pair 构造 10 处） | — |
| gc_stress_nontail.ktf | 同上 10 处 | — |
| effect_stress.ktf | — | `cons(n, mk(n - 1))` = list 链 |
| higher_order.ktf | — | `cons(f(head(lst)), ...)` = list 链 |
| vector.ktf | — | `cons(n, ())` = list 链 |

判定判据：**离散 pair 构造**（两元素俱值、构造即终点）迁移；**链式 cons**（尾部递归续链、构造 list）维持。输出 parity 逐字节保持（验收探针）。

### D9 EBNF + 皮肤字典 + 术语三件

- 02-syntax-model.md v7.27→v7.28：§8.13.1a 增补 tuple_expr 产生式（r160 注记）
- 20-surface-conventions.md v1.38→v1.39：§14 皮肤字典第十五映射行（`(a, b)` ↔ `(cons a b)`）
- 18-terminology 复核（元组/构造-解构对称词条）——r159 同轮复核先例

### D10 测试电池（32 case 门——8 正 + 24 负 1:3）

**正例 8**：①核心 E2E（`(1, 2)` 求值 ⇒ `(1 . 2)` + head/tail 消费）②构造⟺解构对称（`match (1, 2) { (a, b) => a + b }` ⇒ 3）③as-if-written 字节码全等门（`(1, 2)` vs `cons(1, 2)` disassemble 逐字节——r133 全等门先例）④全域位置形（let 值位/实参位/if 条件位/match 检查位/嵌套元组/语句位/closure 体/handle protected——r143 五位置形先例）⑤双 Reader 正典渲染 parity（含 Span 字节）⑥check 跨阶段消费（HM cons 签名消费零诊断）⑦分组/Unit 零回归（`(1 + 2) * 3` ⇒ 9 + `()` 面维持）⑧语料迁移复锚（match/gc_stress 迁移后输出 parity）

**负例 24（7 类错误 ≥6 类覆盖）**：E0001 ×7（3 元封顶 / 尾逗号 / 前导逗号 / EOF 三族 / 非表达式 Token / 封顶 Span 锚）+ E0004 ×4（head/tail 域错 ×2 形 + 嵌套位 + 迁移前对照）+ E0022 ×4（unbound 左/右/嵌套/链）+ E0005 ×3（`1 + (2, 3)` HM 静态 Pair≠Num + `<` 序族 + if 条件位）+ E0006 ×2（元组内未声明能力调用 + 迁移后能力面）+ E0014 ×1（路径段滥用）+ 双 Reader 错误面 parity ×3（消息+Span 字节级）——**E0002 无自然面如实申报**（7 类 ≥6 满足）

## §3 域外表（登记态维持——零信号不开窗，原则 38/44）

| 域外项 | 现状 | 触发条件 |
|---|---|---|
| 位运算/range/cast/索引/管道族 | EBNF Level 0 ○ 行（r159 §3 表维持——`[e]` 索引 = vector-ref 现代面对应物） | 用户指令或语料信号 |
| 元组类型标注形 `(a: T, b: U)` | 类型系统成员 Stage 2+ 登记态（02 §8.3——行多态/开放记录同族） | 类型系统演进信号 |
| 3+ 元元组（n 元组） | 本窗 D2 二元封顶（对称纪律）；n 元 = list/vector 既有面 | 模式位 n 元解构开窗信号（当前模式位同二元封顶） |
| cons/list 用户面语料残留 | 数据语义合法（D5——内核名 + 链惯用形） | 愿景登记态（原则 38） |

## §4 验收（GATE 1 实录——230-d）

- ✅ 六命令 clean 起步全绿：build 零告警（19.56s clean 起步）+ check 0:0 + fmt --all 0 diff + clippy --workspace --all-targets -D warnings 0 + **test --release --workspace 1884:0:0**（1852 基线 + 净 32——RUST_MIN_STACK=33554432）
- ✅ 审计×6 真实 EXIT 0（stage0/1/2×2/3×2——含 e5close 计数锚维持）
- ✅ CLI 零回归探针：fib.ktf ⇒ 144 / closures.ktf ⇒ 42 / higher_order.ktf ⇒ (1 4 9 16 25) / vector.ktf ⇒ 9
- ✅ 新面 E2E：`(1, 2)` ⇒ (1 . 2)；`match (1, 2) { (a, b) => a + b }` ⇒ 3；`head((40, 2))` ⇒ 40（r159 基线下 `let p = (40, 2)` 为 E0001 fail-closed）
- ✅ 语料迁移输出 parity 逐字节：match ⇒ fib-13 / gc_stress ⇒ 5 / gc_stress_nontail ⇒ 5
- ✅ 增长签名锚重校准：reader.ktf payload 210→211 protos / 491→494 consts / 241→242 globals（单函数增量指纹 +1/+3/+1——r158 parse_toplevel_let 同型）；payload_full_shape_anchor 同轮更新
- ✅ as-if-written 字节码全等门：`(1, 2)` ↔ `cons(1, 2)` disassembly（Span 剥离后）逐字节全等——含嵌套形 `(1, (2, 3))` ↔ `cons(1, cons(2, 3))`
- ✅ 32 case 门：8 正 + 24 负 1:3——E0001×8（含双 Reader 错误面 parity ×3 与 Span 契约 ×2）/E0004×2/E0022×3/E0005×3（recovery-mode check 面）/E0006/E0014/模式位回归锚（7 类 ≥6 覆盖——E0002 无自然面如实申报）
- ✅ §6.3 投票：见 230-e 收口笔（5.5/5.5 = 100% GO）

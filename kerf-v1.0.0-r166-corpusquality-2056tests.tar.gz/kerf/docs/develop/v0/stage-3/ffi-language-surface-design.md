# FFI 语言面窗设计（TD-026 行①实施——extern 声明族 + 调用面 + 编译臂发射）

> **Author**: kerf-dev-agent（Super Z main — ARCH-A 裁定 + DEV-A 实施）
> **Date**: 2026-11-09
> **Version**: v1.1（**r147 / 217-e §7 末行翻转**——extern 别名/重导出行清偿关闭：设计单源 extern-alias-design.md v1.0 承载——声明位别名臂 + 双名分离 + 32 case 门 + 1916 基线）；v1.0（r137 / 207-b 设计先行腿——首件）
> **Status**: Active（设计单源——本文件 §2 为 02-syntax-model §8.13.1a v7.20 产生式族的 extern 增补锚；语言面收窄边界以本文件 §7 定稿域为据）
> **处理程度**: P0（窗交付 = 双侧 Reader + 驱动面收集/校验 + 分辨层发射 + 能力门 + 运行表构造 + 32 case 门 + 语料对）
> **开窗依据**: 用户 r137 指令①「继续推进 目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施」行权（M1 指令开窗第四十二例）；推荐序裁定 = r136 收口后登记册触发式实施项全清零 + 六族语料信号实测全零（表达式位 handle / 块体 halt-pass / 裸臂 / resume 多参 / extern / @ 全零命中）→ 推荐序落到 T3+ 14 行手动臂中与「目标语言设计实现窗」需求语义唯一匹配项 = TD-026（登记册 Stage 3 锚——「语言面语法/extern 声明形式 = Stage 3」明文登记行；手动触发臂「开启 TD-026 窗——实施 FFI 语言面形式」；r74/r99 先例锚指令即需求信号本体）；成熟度匹配 = VM 面机制基座 r30 全在位（三操作码 #43-45 + ExternSymbolTable + 窗口协议 + Φ 簿 + E0010-E0012）+ P1 冻结形状在位（ExternalType/FfiCall/FfiBoundary）+ ffi-ownership-model v0.1.0 行为规格冻结
> **上游单源**: [13 §3.3.4](../../../lang-design/13-capability-matrix.md)（FFI 冻结契约 + 「语言面形式 = Stage 3」登记行）+ [ffi-ownership-model](../stage-2/ffi-ownership-model.md)（G3 行为规格——§2 三原语所有权矩阵 / §4 扁平符号空间裁定 / §8 实现路线）+ [04 §1 第十组](../../../lang-design/04-bytecode-vm.md)（三操作码 #43-45 四方同步冻结）+ [22 §15](../../../lang-design/22-namespace-design.md)（N1-N3 分辨链——extern 面接驳点）
> **红线合规**: 红线 3（禁止无信号开窗）——用户指令臂命中（r74 先例「指令即需求信号本体」）；红线 4（禁止窗口合并）——本窗单一切口（TD-026 行①）；原则 27（加性——既有程序零扰动：无 extern 声明的程序行为逐位不变）

---

## 1. 问题陈述与窗口范围

**TD-026 登记原文（登记册 v0.4.15）**：「语言面语法/extern 声明形式 = Stage 3 锚（编译臂不发射——操作码直接构造 + `compile_ffi_call_program` 字面量 lowering 承载 Stage 2）；CStruct 逐字段递归编组/CFunction 回调通路/`FfiCall::FreeExternal` 非令牌实参 lowering 均未消费——注册面显式拒绝或编译期拒绝（诚实收窄注记）」。

**现状实证（207-b 探针）**：
- `FfiCall`/`ExternalType` 的构造点穷举 = reserved/ffi.rs 测试 + driver/ffi.rs 测试 + ffi_vm_tests + stage2 审计集——**expander/compiler 生产链零构造**（grep 实证：kerf-compiler 的 compile.rs 与 ir.rs 零 FFI 引用；CoreExpr/IrExpr 无 FFI 变体）；
- 编译臂不发射三操作码（r30 以来既定收窄——操作码仅经 ffi_vm_tests 手工字节码与 `compile_ffi_call_program` 字面量路径消费）；
- 生产 run 入口 `run_program` = 空 extern 表 fail-closed（E0012）——用户语言零 FFI 可达面；
- 13 §3.3.4 Stage 0 预留位 #1「核心表达式必须能表示『外部调用』」从未填充（FfiCall 形状冻结于 driver 侧，未入分辨/发射链）。

**窗口范围（TD-026 行①）**：交付 extern 声明族语言面——双侧 Reader（`extern name(kinds) -> kind;` ↔ `(extern name (kinds) kind)`）+ 驱动面收集/五重校验（形状/可注册性/契约匹配/能力门/查重）+ 分辨层 extern 类解析（IrVar::Extern）+ 编译臂发射（PushConst SymLit + 实参 + `Op::CallExternal`）+ 运行入口 extern 表构造（声明 ∩ 在册可注册 ∩ 能力授予 → `run_program_with_externs`）+ 32 case 门 + 语料对。

**域外维持（§7 登记——本窗不做）**：CStruct 逐字段编组 / CFunction 回调通路（注册面显式拒绝维持——interop 语料零信号）；`FfiCall::FreeExternal` 非令牌实参 lowering 与 AllocExternal 语言形（token 消费语料零信号——生产可注册面唯一符号 write-stdout 不产令牌）；测试运行器 extern 前置切分（`is-prelude-kind` 增行——用户测试语料零信号）；模块体内 extern 声明位（顶层唯一定稿——模块级零消费面）。

## 2. 语法域（EBNF 产生式——Level 0 定稿域内追加）

### 2.1 S-expr 面（正典核心形）

```ebnf
extern_decl ::= "(" "extern" IDENT "(" {kind} ")" kind ")"
kind        ::= "int" | "str" | "ptr"
```

示例：`(extern write-stdout (str) int)`。形约束：参数表恰一个列表元（空表合法——零参外部函数）；返回 kind 恰一个符号元；`extern` 头部两面共享。

### 2.2 目标面（皮肤映射——第十三映射族）

```ebnf
extern_decl ::= "extern" IDENT "(" [kind {"," kind}] ")" "->" kind ";"
```

示例：`extern write-stdout(str) -> int;`。Reader 皮肤字典映射：`extern name(k1, k2) -> r;` → `(extern name (k1 k2) r)`——符号逐一同构（require/import 声明族先例：裸名 + 逗号分隔 + 强制 `;`）。

### 2.3 kind 词表（三词——VM 消费子集同构）

| kind 词 | ExternKind（kerf-vm/ffi.rs 消费子集） | 值域承载（窗口协议实况） |
|---|---|---|
| `int` | `CInt` | `Value::Int` ↔ i64 按值拷贝（HostRet::Int） |
| `str` | `CPointer` | `Value::Str` → char* 窗口借用（alloc_str + pin + LIFO unpin） |
| `ptr` | `Opaque` | `Value::External` 令牌按借用传递（Invalid → E0010） |

**D1 kind 词表裁定**：三词 = ExternKind 三变体的语言面同构（CIntSize 十尺寸变体的精度属宿主注册面职责——语言面 kind 词不携带尺寸；CPointer 的 PointeeType 三变体中 Char = str 词的窗口借用实况，Void/U8 字节缓冲经 `ptr` 令牌形态承载——词表三枚封顶，扩词 = 语料信号触发式）。

## 3. 裁定表（D1-D10）

### D1（含 §2.3）：kind 词表三枚封顶
见 §2.3。CIntSize/PointeeType 精度留在驱动侧在册可注册表的 ExternalType 全形（write-stdout = `CPointer(Char) → CInt(Usize)`）——语言面声明以 ExternKind 粒度对照（尺寸擦除等价比较）。

### D2：驱动面收集与剥离（import 先例同构——expander 零变更）
`collect_extern_face`（driver.rs——collect_import_face 同族新件）：扫描顶层 `(extern ...)` 头部形 → `ExternFace { entries: Vec<ExternEntryDecl> }`（name + param_kinds + ret_kind + span）；**`strip_toplevel_imports` 扩展为同窗剥离 extern 形**（expander 永不见 extern 声明——ModuleItem/CoreExpr 零新变体；kerf-core/kerf-expander 两 crate 本窗零代码变更）。位置纪律：顶层直接元素位唯一（module 体/表达式位/嵌套位 → E0026 位置违例族消息——require/import E0023 族同口径）。

### D3：五重声明校验（编译期 fail-closed——报错>静默 §2.3-4）
收集时逐条校验，任一失败即 DriverError（check/run 两面同享）：
1. **形状**：头部三元组（name 符号 / 参数表列表 / 返回 kind 符号）+ kind 词 ∈ 三词表——违例 → E0026 形状族消息（携 Span）；
2. **可注册性**：name ∈ 驱动侧在册可注册表（本窗唯一条目 `write-stdout`）——miss → E0012 编译期变体消息「外部符号 '{name}' 未在可注册面登记（在册可注册：write-stdout）」（E0012 码复用——运行期同码同族，编译期前置）；
3. **契约匹配**：声明 (param_kinds, ret_kind) == 在册表 (params, ret) 的 ExternKind 投影——失配 → E0026 契约族消息（两侧形状并列展示）；
4. **能力门**：在册表条目 required capability（write-stdout = `write`）须被 require 面授予——缺失 → E0006 族消息「{name}（extern 声明）需要 write 能力——FFI 写通道与 io 语言通道同享授权令牌」（verify_io_capabilities 同族扩展：extern 声明面加入能力消费点清单）；
5. **查重**：name 与既有 extern 声明/顶层 define/import 注入名/内置全局撞名 → E0013/E0017 族消息（「extern 符号 '{name}' 重复绑定」——扁平符号空间不可遮蔽裁定 §4 的编译期执法面）。

### D4：分辨层 extern 类（IrVar::Ex­tern——M-I 分辨单源延拓）
`IrVar` 增第四变体 `Extern(Symbol)`（kerf-compiler/ir.rs）；`LowerCtxt` 增 `extern_face: &HashMap<Symbol, ()>`（名字集——签名已在前置校验消费）；`resolve_var` 规则延拓：locals/captures 逐帧 miss 后、global 兜底前查 extern 面（**Symbol 名字匹配——scope 集不参与 = 卫生不可穿透**〔ffi-ownership-model §4 扁平符号空间裁定的机制化身〕；locals 合法遮蔽〔词法绑定优先——实用主义读法，「不可遮蔽」裁定执法面 = D3-5 顶层 define/extern 撞名拒绝〕）。`lower_module` 签名加性扩展（extern_face 参数——原则 27：既有调用方空表传入行为逐位不变）。

### D5：发射臂（Apply 头 extern 识别 + 值位 fail-closed）
compile.rs Apply 臂前置识别：`fn_expr = IrExpr::Var{res: IrVar::Extern(sym)}` → FFI 发射（`PushConst(SymLit 名)` + 实参依序 emit + `Op::CallExternal{n_args}`——实参求值序契约 A1 维持；tail 旗标不参与〔无帧可复用——CallExternal 不建帧，值落栈由外围 Return/Halt 承接〕）。Var 臂：`IrVar::Extern` 独立值位 → CompileError E0026「extern 符号 '{name}' 仅调用位（扁平符号空间无值位形态——ffi-ownership-model §4）」（报错>静默——不存在「外部函数值」）。GetGlobal/索引面零扰动（extern 名永不入 global_refs 池——分辨层先行拦截）。

### D6：运行入口 extern 表构造（声明 ∩ 在册 ∩ 能力授予）
驱动侧在册可注册表 `AVAILABLE_EXTERNS: &[AvailableExtern]`（name + ExternalType 全形 params/ret + HostFn + required: Option<Capability>；本窗唯一条目 write-stdout ← default_extern_table 的 host_write_stdout 迁移单源化）。run_front/run_target 构造：声明校验全过（D3 已确保 name ∈ 在册 ∧ 契约匹配 ∧ 能力授予）→ `register_external` 装配 ExternSymbolTable（声明 kinds → ExternKind 形状 + 在册 HostFn）→ `run_program_with_externs`（替代 run_program——空表构造与 run_program 行为逐位等价，既有程序零回归）。**零声明程序 = 空表 = 既有行为逐位不变（原则 27 加性验收锚）**。

### D7：E0022 可见面并入 + HM A4 维持（零新误报 D9 同律）
`verify_unbound_refs` 面并集增 extern 声明名列（driver.rs + target 面同构）——`(write-stdout "x")` 不再 E0022。HM/check 面：CoreExpr 无 Ffi 形（D2 剥离决策的推论）——Apply{Var(extern 名)} 走未绑定全局 A4 Dynamic 原路径（hm.rs 41-42 既有纪律：「未绑定引用→Dynamic 原子永不入约束」）；**零新误报论证（D9 同律）**：extern 调用的静态检查 = D3 五重校验（形状/可注册/契约/能力/查重）+ 运行期窗口协议执法（E0011 arity/域失配族——r30 既有）；HM 增签名执法 = §7 触发式（TC-SIGS 扩表同族——krf ⊆ oracle 契约维持）。

### D8：Keyword::Extern（第 28 名——E0020 共享域扩展）
kerf-syntax/symbol.rs：Keyword::Extern 变体 + ALL 数组 27→28 + from_name/as_str 同步；E0020 严格保留字绑定禁令面 28 名（「extern」不可作用户绑定名）；目标面词法器 KwExtern 令牌（target.rs 词表 + 关键字分流）；bootstrap target_reader.krf 镜像关键字表同步（27→28 计数锚双侧）。**四方同步**：symbol.rs enum ↔ E0020 计数锚 ↔ 02 §8.13.1a 产生式（§2 增补）↔ 20 §14 皮肤字典（第十三映射族行）。

### D9：诊断码分配（E0026——extern 面专属族）
E0026 = extern 语言面专属诊断族（E0025 match 穷尽性后次号——E0002 族同通道渲染零新通道）：①形状族（三元组/参数表/kind 词）②位置违例族（非顶层）③契约失配族 ④值位违例族（D5）⑤查重族（D3-5 消息可复用 E0013 码——族内注记）。E0012 编译期变体（D3-2）与 E0006 能力族（D3-4）复用既有码——码表零净增（E0026 一码五消息族）。

### D10：测试矩阵（32 case 门——8 正 + 24 负 = 1:3，§9.4.3）
**正向八族**：①声明 + 调用 E2E 双面（`(require io write)` + `(extern write-stdout (str) int)` + `(write-stdout "hello ffi")` ⇒ 9 字节数——真实宿主 I/O 往返）②能力授予门 E2E（require 在场 → 表构造成功）③跨语法字节码 parity（同程序两语法源 → 指令序/常量池全等——皮肤透明性）④check 面 clean（零诊断 + 工件计数）⑤双 Reader 正典渲染 parity（extern 形两语法源 → Stx 树字节级全等）⑥嵌套上下文调用（fn 体内/let 绑定内/实参位 extern 调用——分辨率不受词法深度影响）⑦混合程序（extern + define + import 并存——零互扰）⑧Φ 簿配平（语言路径调用后堆 pinned 空——窗口协议 LIFO unpin 的语言面实证）。
**负向二十四族**：形状六族（name 非符号/参数表非列表/参数元素非 kind 词/返回位非 kind 词/缺返回元/头后即尾）+ 位置三族（表达式位/module 体/嵌套块内声明——E0026 位置族消息+Span 双面镜像）+ 可注册性双族（未知符号 → E0012 编译期变体双面消息镜像）+ 契约失配双族（参数 kind 失配/返回 kind 失配 → E0026 契约族）+ 能力缺失双族（无 require → E0006 extern 变体消息 + require read 仅写缺失粒度）+ 查重三族（extern 重声明/与 define 撞/与 import 撞）+ 值位双族（Var 独立值位 → E0026 值位族双面）+ 调用运行期三族（实参域失配 → E0011 运行期传播/arity 失配 → E0011/str 实参传 int 值 → E0011——窗口协议既有执法的语言面确认）+ 目标面词法三族（缺 `->`/缺 `;`/未知 kind 词 → Reader E0001 族+Span）。

## 4. 实施对账表

| 件 | 落位 | 依据 |
|---|---|---|
| Keyword | kerf-syntax/src/symbol.rs：Extern 变体 + ALL 28 + 计数锚 | D8/原则 44 |
| 目标面 Reader | kerf-reader/src/target.rs：KwExtern 词法 + parse_extern_decl（require 先例同构） | §2.2/D8 |
| 镜像 Reader | kerf-driver/src/bootstrap/target_reader.krf：extern 关键字表 + parse-extern-decl 族 | 原则 31 |
| 驱动面 | driver.rs：collect_extern_face + 剥离扩展 + D3 五重校验 + verify_unbound_refs 并入 + verify_io_capabilities 消费点 + run 入口表构造 | D2/D3/D6/D7 |
| 在册可注册表 | driver/ffi.rs：AVAILABLE_EXTERNS（write-stdout 条目单源化迁移） | D6 |
| 分辨层 | kerf-compiler/src/ir.rs：IrVar::Extern + LowerCtxt.extern_face + resolve_var 延拓 + lower_module 加性签名 | D4 |
| 发射臂 | kerf-compiler/src/compile.rs：Apply 头识别 + CallExternal 发射 + Var 值位拒绝 | D5 |
| 测试 | tests/v0/stage3/plan/ktf_extern_decl_tests.rs（32 case）+ runner.rs 挂载 | D10/§9.1 |
| 语料 | examples/usage/ffi.{ktf,krf}（语料对 ⇒ 9 双面） | §9.4.5 |
| 文法 | 02 §8.13.1a v7.21（extern_decl 产生式双面）+ 20 §14 v1.28（第十三映射族行）+ 22 注记 | 原则 44 |
| 治理 | t3plus v1.57 + RELEASE r137 + matrix r137 行 + TD-026 行①部分清偿回写 + README + rec 98 + worklog 三链 | §8.5/§8.6 |

## 5. 与既有治理锚的对账

- **8 原语不变性（第十九轮）**：零新原语零通道零新操作码——本窗 = 冻结机制（#43-45 + ExternSymbolTable + 窗口协议）的语言面消费；CoreExpr/ModuleItem 零新变体（D2 剥离决策）——比 r136 HandleGroup 更轻（无内核形态增量）；IrVar::Extern = 分辨层第四类（M-I 分辨单源延拓非语义原语）。
- **扁平符号空间（ffi-ownership-model §4）**：D4 卫生不可穿透（Symbol 名字匹配）+ D3-5 顶层遮蔽拒绝 + D5 值位 fail-closed——三执法点齐备。
- **能力模型（R9/E0006）**：write-stdout 经 `write` 能力令牌门（与 io 语言通道同享授权——能力域归属裁定〔r65/118-a「permission belongs to the capability domain」〕的首个 FFI 通道执法实例）。
- **fail-closed 纪律**：未声明调用 → E0022；声明未注册 → E0012 编译期；能力缺失 → E0006；值位引用 → E0026——四层拒绝全部编译期或调用期显式诊断，零静默降级。
- **既有程序零回归**：零 extern 声明 → 空表 + 零分辨面变化 + 零发射变化——1655 基线逐位不变（净 +32 全部来自新门族）。

## 6. 风险与回退

- 分辨层延拓触碰 resolve_var 热路径——加性分支（extern 面 miss → 原路径逐位不变），1655 回归网全量守护；
- 运行入口从 run_program 切至 run_program_with_externs——空表等价性由既有 ffi_vm_tests `negative_default_entry_fail_closed_e12` 语义背书 + 本窗 D6-⑧ 验收锚；
- 词法器新关键字 `extern`——既有语料零 `extern` 标识符使用（207-b grep 实证：语料命中全为编译器.ktf 的 OP_ALLOC_EXTERNAL 注释与 test_runner.krf 的 externalize 注释，非语言面）。

## 7. 诚实边界（域外登记表——触发式）

| 域外项 | 载体 | 触发判据 |
|---|---|---|
| CStruct 逐字段递归编组 / CFunction 回调通路 | 注册面显式拒绝维持（driver/ffi.rs map_external_kind panic 面 + external_kind_supported） | interop 语料信号（C 结构消费案例） |
| AllocExternal / FreeExternal 语言形（含非令牌实参 lowering） | 本文件 §1 域外维持 | token 消费语料信号（在册可注册面产令牌符号出现——当前唯一符号 write-stdout 返 CInt 零令牌） |
| 测试运行器 extern 前置切分（is-prelude-kind 增行） | 本文件 §1 | 用户测试语料信号（含 extern 声明的 .ktf 测试文件） |
| 模块体内 extern 声明位 | 本文件 D2（顶层唯一定稿） | 模块级 extern 消费信号 |
| extern 调用 HM 签名执法（apply 位类型检查） | 本文件 D7（A4 Dynamic 维持） | TC-SIGS 扩表同族触发（krf 面签名执法扩展需求——member-rename §7 同源） |
| kind 词表扩词（CIntSize 精度词/PointeeType 词/新 ExternKind） | 本文件 D1（三词封顶） | 语料信号 + 在册可注册表扩容（新宿主函数登记） |
| ~~extern 别名/重导出（use 选择形接驳）~~ | ~~member-rename 族域外~~ | **✅ r147 清偿（extern 符号空间别名窗 217-a..217-f——设计单源 extern-alias-design.md v1.0）**：声明位别名臂 `extern NAME as ALIAS (kinds) -> RET;` ↔ 六元素 Stx——import-as 家族在 extern 声明族上的同构延拓：双名分离 D3[externs_for_compile 对 `(intern(local), Rc(name))`——IR extern_face 既有分离维度启用；注册/契约/能力/运行表四面恒按 underlying 匹配零变更] + 替换语义 D4[local 入可见面、underlying 直写 E0022] + 自别名拒收 D5 + 反遮蔽扩展 D6 + 能力门不感知别名 D7[按 underlying——r135 D13 行权线] + HM A4 维持 D8 + use 选择形接驳维持域外 D9[扁平空间无模块面——宪制；虚拟模块面 = Stage 2+ 命名空间演进触发]；bootstrap 编译桥 CC_EXTERN 协议扩展[(local flat) 对——rv_loop extern_lookup + SymLit 载 flat]；32 case 门 ktf_extern_alias_tests + 语料对 ffi_alias.{ktf,krf} ⇒ 9 双面；**1916 基线自 r147 起** |

*遵循条款：原则 12（最优>最小——五重校验全量而非抽样）/ 原则 26（成熟度匹配——VM 基座全在位）/ 原则 27（加性——空表等价 + 既有程序零扰动）/ 原则 31（皮肤/骨架同构——第十三映射族）/ 原则 44（新语法成员登记必须附 EBNF 产生式）/ §2.3-4（报错>静默——四层 fail-closed）/ §9.4.3（1:3）/ §18（机制零新增——冻结形状消费）/ r74 先例（用户指令 = 需求信号本体）/ r125-r136 声明族窗口链先例（require/import/use 三连形态）。*

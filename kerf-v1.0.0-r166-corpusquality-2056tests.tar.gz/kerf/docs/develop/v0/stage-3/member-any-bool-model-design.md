# member/assoc 静态面双缺陷清偿设计（'sigf 'any 规则位兜底误报 + member Bool 谓词化建模值消费假阳性）

> **Author**: Super Z (main) — ARCH-A（裁定）+ PM-A（路由）
> **Date**: 2026-11-12（r142 / 212-b 设计先行腿）
> **Version**: v1.0
> **处理程度**: P0（设计完备——D1-D8 + §7 域外表；实施 = 212-c）
> **开窗依据**: 用户 r142 指令①「继续推进 目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施」+ 指令②「按 docs/sop.md 流程结合 lang-design 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进」行权（**M1 指令开窗第四十七例**）；推荐序裁定 = r141 收口态登记册触发式实施项全清零 + T3+ 14 行零信号 + 门控任务七项全闭 + #15 需 next22.md（未上传——upload/ 实测最新 next21.md）→ 用户指令①「遇缺陷直接推进」逐行走查全部登记域外表期间 **中途缺陷实测发现**（212-a 张力探针）→ 双缺陷裁定开窗；tc-sigs §7「member/assoc 结果类型 Bool 建模复审」登记行（独立评估面）同窗行权清偿——张力实测成立（D1 证据 ②）
> **上游单源**: [tc-sigs-parity-design.md §7](./tc-sigs-parity-design.md)（member/assoc 复审登记行——本窗为其清偿载体）+ [hm.rs check_param_rule](../../../crates/kerf-compiler/src/hm.rs)（oracle 参数规则行为规格——Any/var 双臂）+ [builtins.rs BUILTIN_SIGS](../../../crates/kerf-driver/src/builtins.rs)（oracle 签名行清单单源）+ [check.krf tc-rule-one](../../../crates/kerf-driver/src/bootstrap/check.krf)（krf 面参数规则执法）+ r80 生产切换契约（krf ⊆ oracle 方向守卫 + 零误报契约首要优先级）+ TD-030（E0005 假阳性族 P1 定性先例）+ builtins.rs B2 注记（list/member 净化先例——"in step with purifying the HM type domain"）

---

## 1. 事实基线（212-a 实测证据链）

### 1.1 双侧构造点现状

**oracle 侧（Rust）**：
- `hm.rs check_param_rule`：具体类型臂 `TcParam::Any => true`（**Any 短路零约束**）；var 臂 `TcParam::Pair => None` 且 `_ => None`（**Any/List/Pair 变量均无约束**——仅 Num|Int→Num / Bool→Bool / Str→Str / Symbol→Sym 施约束）
- `builtins.rs BUILTIN_SIGS`：`("member", BuiltinSig::fixed(&[TcParam::Any, TcParam::List], TcType::Bool))`（**Bool 谓词化建模**）；`("assoc", fixed(&[Any, List], Unknown))`（Unknown 保守建模——零误报）
- `builtins.rs` 限定名净化（B2 注记）：`list/member` / `list/assoc` miss `Bool(false) → Nil`（值域统一 list-or-nil——"no longer overlapping bool, in step with purifying the HM type domain"）

**krf 侧（check.krf）**：
- TC-SIGS 表（r140 逐行同构扩表）：`(cons "member" (list 'sigf (list 'any 'list) 'bool))` / `(cons "assoc" (list 'sigf (list 'any 'list) 'unknown))`
- `'sig` 同质形路径 `tc-check-rule`：**有** `((eq rule 'any) true)` 短路臂（第 1073 行——eq/is-*/list 等行第一参 'any 走此路径，合法）
- `'sigf` 逐参路径 `tc-check-pos-rules → tc-rule-one`（r140 / 210-b 引入）：`tc-rule-one` cond 链**无** `'any` 臂——`'any` 实参落入两条错路径：
  - 具体类型（非 dynamic/tvar）→ **else 兜底臂 `tc-record "argument type mismatch (static check)"` —— 无条件误报**
  - tvar → tvar 臂 else → `(tc-unify ty (tcon rule))` 即 unify 到**伪 `tcon('any)`**（'any 非法 kind——类型域污染）

### 1.2 张力探针实测（212-a——本机 r141 态全部可复现）

| 探针 | 静态面（check.krf 生产路径） | 运行时（VM） | 判定 |
|---|---|---|---|
| `(define x (member 2 (list 1 2 3)))` | **E0005 兜底误报**（第一参 int + 'any → else 兜底） | — | **缺陷 ① 实证** |
| `(define x (member "s" (list 1 2 3)))` | 同上（第一参 str） | — | 同上（具体类型全族） |
| `(import kerf-list) (define lst (list 1 2 3)) (define first (head (member 2 lst)))` | E0005 ×2（'any 兜底 + `head requires pair, got bool`） | **⇒ 2（正确）** | **缺陷 ①+② 叠加实证** |
| `(head (list/member 2 lst))`（限定名） | **ok（零诊断）** | ⇒ 2 | 净化先例对照（B2 已净化路径零误报） |
| `(define (f x) (let ((m (member x (list 1 2)))) (head m)))` | `head requires pair, got bool`（member 结果 Bool 建模） | — | **缺陷 ② 实证**（值消费假阳性） |
| `(if 1 10 20)` | `if condition requires bool, got int`（真检出） | — | if 条件执法维持锚（D4） |
| `(member 2 (list 1 2 3) 9)` | arity 三参真检出（`procedure argument count mismatch: expected 2, got 3`） | — | 'sigf arity 门维持锚 |

### 1.3 r140 门覆盖缺口分析（缺陷潜伏三轮根因）

`ktf_tc_sigs_parity_tests` 32 case（r140 交付）：
- **P01**（'sigf 族 run E2E）= 运行面——不经 check 面
- **P02**（check clean 正例）= 仅 `length`/`string-length`——**无 member 'any 位具体类型正例**
- **P03/P04** = tvar 位（'list 位 / 'int 位）——非 'any 位
- **N05**（`(member 1 "ab")` 负例）= `contains("requires list")` **任一诊断包含即过**——第一参 'any 兜底误报与第二参真检出**共存通过**（掩盖缺陷 ①）

结论：'any 位 check clean 正例零覆盖 + 负例 contains-any 断言形态掩盖 = 缺陷 ① 自 r140 引入起潜伏三轮（r140/r141 门均未检出）。**本窗测试矩阵以「精确计数 + 精确消息」断言形态补此缺口（D8）**。

---

## 2. D1：双缺陷定性（ARCH-A 裁定）

**缺陷 ①（P1——check 面功能缺陷，run 路径零影响）**：`'sigf` 逐参规则位 `'any` 无臂兜底误报 + tvar unify 伪类型。
- 定性依据：TD-030 同定性先例（check 面功能缺陷 P1——run 路径零影响）；oracle 双臂（`Any => true` + var `_ => None`）与 krf 兜底行为**方向相反**（oracle 零误报 vs krf 全误报）——r140 移植偏差（r80 修正③④⑤ 同族：移植偏差实测锚修正）
- 触发面：`'sigf` 行 `'any` 参数位 = member/assoc 第一参（唯一 'any 位点——nth/drop = `(list int)`、string-substring = `(str int int)` 零 'any 位）；**全部用户实参形态**（具体类型全族兜底误报；tvar 形伪类型污染）

**缺陷 ②（P1 同族——E0005 假阳性族）**：member Bool 谓词化建模值消费假阳性。
- 定性依据：TD-030 E0005 假阳性族先例；`(head (member 2 lst))` 静态误报 vs 运行时 ⇒ 2 正确（1.2 探针实证）；r80 契约「零类型不一致误报」首要优先级违例
- 触发面：member 结果的**值消费位**（head/tail/nth/序列对拆构等 Pair 需求位）；谓词位（if 条件）合法不受影响
- 与缺陷 ① 的关系：当前被 ① 掩盖（① 的兜底误报在参数位先行触发）；① 修复后 ② 直接暴露（同区域缺陷族——§20.3 同类路径全量审查纪律：修一处必须全量清偿至收敛）

**裁定**：同窗双缺陷清偿（r133/r134/r141 同窗缺陷当场清偿纪律沿袭——当轮发现当轮修正）。

---

## 3. D2：'any 短路臂设计（缺陷 ① 修复——镜像 oracle 双臂）

**实施位**：`check.krf tc-rule-one` cond 链顶部加臂：

```scheme
(define (tc-rule-one rule namestr ty argnode)
  (let ((rt (tc-resolve ty)))
    (cond ((is-dynamic rt) true)
          ; r142 / 212-c — 'any passes all (mirror of the oracle's
          ; TcParam::Any => true short-circuit and the var-arm's
          ; _ => None unconstrained branch — the r140 'sigf per-position
          ; path omitted this arm, dropping every concrete argument
          ; into the else fallback with a spurious diagnostic and
          ; unifying variables with the pseudo tcon('any))
          ((eq rule 'any) true)
          ((is-tvar rt) ...)
          ...))
```

**裁定三依据**：
1. **单臂双收**：`'any → true` 置于 `(is-tvar rt)` 臂**之前**，同时收口具体类型路径（else 兜底不再触达）与 tvar 路径（tcon('any) 伪 unify 不再发生）——最小变更面（单臂插入，零既有臂改动）
2. **oracle 同构**：镜像 `check_param_rule` 的 `TcParam::Any => true`（具体臂）与 `_ => None`（var 臂 Any 无约束）——双侧行为锁步
3. **'sig 形零触碰**：`tc-check-rule` 的 `((eq rule 'any) true)` 既有短路维持不动（两路径各自短路——与 oracle 单臂覆盖两形态语义等价）

**不采方案**：`tc-check-pos-rules` 预过滤 'any（改动两个函数 + 过滤逻辑与规则分派耦合）——次优（§12 最优>最小：单臂插入语义更清晰且 oracle 镜像关系直白）。

---

## 4. D3：member 结果建模宽化（缺陷 ② 修复——'bool → 'unknown 双侧锁步）

**双侧实施位**：
- oracle：`builtins.rs BUILTIN_SIGS` 行 `("member", BuiltinSig::fixed(&[TcParam::Any, TcParam::List], TcType::Bool))` → `TcType::Unknown`
- krf：`check.krf TC-SIGS` 行 `(cons "member" (list 'sigf (list 'any 'list) 'bool))` → `'unknown`

**裁定四依据**：
1. **r80 零误报契约首要优先级**：member 值消费位假阳性（1.2 探针）= 契约违例；Unknown（fresh 泛化——`tc-sig-result` 'unknown → `(tc-fresh)`，r140 D3 语义：unsolved fresh 泛化为多态绑定）使值消费位（head/tail tvar 臂 → Dynamic）与谓词位（if 条件 tvar unify bool）**双双零误报**
2. **assoc 既有行对齐**：`(cons "assoc" (list 'sigf (list 'any 'list) 'unknown))` —— member/assoc 同族查找函数（命中返回 Pair、未中返回 Bool）理应同构建模；member 是唯一残留 Bool 谓词化行
3. **B2 净化先例方向**：`list/member` 限定名 miss `Bool(false) → Nil`（"purifying the HM type domain"）——裸名静态面 Unknown 宽化 = 同方向延伸（静态域与运行时值域的污染净化对齐）
4. **8 kind 冻结下的唯一零误报复现**：无 union 类型构造（`(U (Listof A) False)` Typed Racket 形不可表达——原则 9/8 原语不变性），保守建模谱系中 Bool（谓词精确但值消费误报）/ Pair（未中违约）之外唯有 Unknown/Dynamic 零误报；Unknown（fresh 泛化）优于 Dynamic（A4 全跳过）——保留参数位执法与多态泛化

**宽度影响论证（D4——三层实证）**：
1. **静态面零行为变化**：谓词位 `(if (member 2 lst) 10 20)` —— member 结果 fresh tvar → `tc-if-cond-ok` tvar 臂 `(tc-unify ct (tcon 'bool))` 绑定合法（与 Bool 建模静态行为一致——零静态行为变化）
2. **运行时严格 bool if 纪律维持（212-c 实测发现）**：同一形态运行时命中返回 Pair → **E0004 `if condition requires bool, got pair (truthy semantics explicitly defined)`** —— VM 运行时 if 条件执法为严格 bool（truthy 显式拒绝）；**Bool 谓词化建模的静态-运行时错位实证**（静态放行 → 运行时 E0004 违约——静态面误导）；Unknown 宽化后静态面诚实（静态合法 + 运行时诚实违约 = fail-closed 一致）
3. **正典谓词形态 = is-pair 包裹**（tc-sigs §7 行文原意「严格 bool if 纪律下谓词用法需 is-pair 包裹」）：`(if (is-pair (member 2 lst)) 10 20)` ⇒ 10 —— 静态运行时双合法的正典用法；未中形态 `(if (member 9 lst) 1 2)` 运行时 #f（bool）⇒ 2 合法（运行时值域分裂 = 既有 Racket member 语义，B2 净化域外）

**静态精确性代价申报**：`(define b (member 2 lst))` 后 `b` 的类型 = 泛化 fresh（非精确 bool）——谓词结果 bool 精确性让位于零误报契约（D6 计数 parity 净方向 = 误报减少、真检出零变化）。

---

## 5. D5：邻位维持纪律（最小变更面）

- `'sigf` 其余行零触碰：nth/drop `(list 'int)`、string-substring `(str 'int 'int)`——无 'any 位、无 Bool 结果位
- `'sig` 形既有行零触碰：`tc-check-rule` 'any 短路维持（既有 eq/is-*/list 族行为不变）
- `tc-rule-one` 其余臂零改动：'num/'bool/'str/'int/'sym/'list/'pair 七规则臂 + tvar 域特化臂（r140 D4 方向守卫防御位）原样维持
- oracle 侧零机制变更：`hm.rs check_param_rule` / `infer_app` 零触碰——仅 BUILTIN_SIGS 单行结果位宽化（数据行变更非机制变更）
- 运行时零触碰：`builtins.rs` BuiltinFn 注册表（member/assoc 运行时行为）与 VM 零变更——纯静态面窗

---

## 6. D6：计数 parity 影响论证（GATE 前置——212-d 实测修正版）

- **误报净减**（krf ⊆ oracle 方向合法——宽松化方向守卫维持）：缺陷 ① 修复使 'any 位兜底误报族消失（负向误报 → clean）；缺陷 ② 修复使 member 值消费位假阳性消失——两族均为**误报消除**（krf 面诊断计数只减不增）
- **真检出零变化**：参数位规则族（'list/'int/'str/'num 等）执法条件零改动；arity 门零改动；if 条件执法零改动（1.2 维持锚）
- **oracle 侧计数变化**：member 行 Bool→Unknown 使 oracle 面值消费位误报同步消失——双侧同向同量（parity 维持）
- **语料锚翻转 3 处（212-d 全量实测修正——原判断有误诚实回写；stash-built 修复前对照实证）**：r140 三语料重锚的 11 项中 **5 项实为 'any 兜底缺陷伪产物**（修复前对照实测：`?` 渲染 = 伪 tcon('any) 本体）——
  - expander.ktf **6 → 5**：第 6 项 = `string-append requires str, got ?`（member pos-0 tvar unify 伪 tcon('any) 后**污染经合一传播到远端用位**）；5 个 num-into-int 真检出全维持
  - compiler.ktf **2 → 1**：第 2 项 = `type mismatch: ? and str`（同一污染以 unify 冲突形态浮现）；tail-nil 真检出维持
  - reader.ktf **3 → 0**：3 项全部 = 污染 unify 冲突 ×2 + 兜底误报 ×1（零真检出）
  - 原 D6 判断「自举语料 member 用法走 'sig 形路径、语料锚零翻转预期」**错误**——expander/compiler/reader 的 member 用位（`member(name, KEYWORDS)` 形——name 为函数参数 tvar）走 'sigf 路径，修复前 tvar 落 else 臂 unify 伪 `tcon('any)`，污染跨用位传播。**此实证加深缺陷①定性：伪类型污染具有跨用位传播性（远端误报 + `?` 不可解读渲染）——比 D1 原刻画更严重；r140 锚翻转三件「真检出裁定」中 5 项实为缺陷伪产物（krf ⊆ oracle 数字成立但语义误判）——本窗一并修正**
- 其余语料锚零翻转：check.krf 2 / build.krf 0 / cli.krf 0 / fib.krf 0 全维持（212-d 全量实测——check.krf 的 member 用位走 'sig 形 `is-contains`/`assoc-val` 路径，原判断对该文件成立）

---

## 7. D7：锚翻转预算（212-d 实测修正版）

- **语料锚翻转 3 处**：`hm_production_switch_tests::corpus_anchor_seven_files` expander.ktf **6 → 5** / compiler.ktf **2 → 1** / reader.ktf **3 → 0**（'any 污染伪诊断族消失——D6 详述；r133/r134 锚翻转纪律：诊断面变更的 R4 实况对账——krf ⊆ oracle 合法宽松化 + 注释回写污染传播根因 + r140 伪真检出误判修正）
- **r140 门**（`ktf_tc_sigs_parity_tests`）：N05 contains 断言维持（第二参 'list 真检出不受影响）；P01 run 面维持；P03-P05 tvar/结果映射锚维持——**实测零翻转**（212-d 全量验证）
- **r141 门**（`ktf_diag_msg_parity_tests`）：九族文本锚不含 member 'any 位——**实测零翻转**（212-d 全量验证）
- **oracle 侧锚**：hm 侧测试无 member bool 断言（rg 全量核对零命中）——零翻转
- **新门**（`ktf_member_any_model_tests` 32 case）：张力场景翻转锚——`(head (member 2 lst))` 从误报翻转为 clean + 运行时 ⇒ 2（双面）；精确计数断言形态（补 r140 contains-any 掩盖缺口）

---

## 8. D8：测试矩阵（GATE 5/6 构成——32 case = 8 正 + 24 负 1:3）

**正向（8）**：
1. P01 `'any` 位具体类型全族 check clean（member/assoc 第一参 int/str/bool/sym 各形态——双面精确零诊断断言）
2. P02 member 值消费张力翻转锚：`(head (member 2 lst))` check clean + run ⇒ 2（双面 E2E——缺陷 ② 修复实证）
3. P03 正典谓词用法（is-pair 包裹）：`(if (is-pair (member 2 lst)) 10 20)` check clean + run ⇒ 10（双面——D4 层 3 实证）
4. P04 tvar 'any 位无污染：`(define (f x) (member x lst))` 泛化 clean + 结果位值消费（head m）clean（双面——缺陷 ① tvar 路径 + ② 值消费复合）
5. P05 assoc 对照维持：`(head (assoc 1 al))` 既有 unknown 建模 clean（双面——同构行维持锚）
6. P06 member 结果 fresh 泛化多消费位：let 绑定后双消费（if 谓词 + head 值位同绑定——双面）
7. P07 未中形态运行时锚：`(member 9 lst)` ⇒ #f + `(if (member 9 lst) 1 2)` ⇒ 2（运行时 truthy 语义维持）
8. P08 跨阶段消费集成：member/assoc 经 .ktf 目标链全链 E2E（Reader→Expander→Compiler→VM ⇒ 值锚——GATE 6 跨阶段消费位）

**负向（24）**：
1. N01-N04 member 第二参非 list 真检出维持（str/int/bool/sym 四形态——`requires list` 精确消息断言 + 诊断计数 = 1 精确断言——**补 r140 contains-any 掩盖缺口**）
2. N05-N06 member arity 真检出（1 参/3 参——精确消息断言）
3. N07-N10 assoc 第二参非 list 真检出维持（四形态同 N01-N04）
4. N11-N12 assoc arity 真检出（1 参/3 参）
5. N13-N16 'sigf 邻位维持：nth 第二参 str / drop 第二参 str / nth 第一参非 list / string-substring 第二参 str（`requires int`/`requires list`/`requires str` 精确断言——D5 邻位纪律实证）
6. N17-N18 head/tail 非 pair 真检出维持（`head 1` / `tail "s"`——head 族执法维持锚）
7. N19-N20 if 条件具体非 bool 真检出维持（`(if 1 ...)` / `(if "s" ...)`——D4 执法面维持锚）
8. N21-N22 未导入 member/assoc E0022 维持（双面）
9. N23 member 值消费**真违约**维持：`(head (member 9 lst))` 运行时未中违约（`head requires pair` 运行时真报错——静态宽化后运行时诚实执法维持——fail-closed 面不动实证）
10. N24 谓词形态运行时 E0004 诚实违约锚：`(if (member 2 lst) 10 20)` 静态 clean + 运行时 E0004（严格 bool if 纪律维持——静态宽化不影响运行时执法）+ 双面诊断计数 parity 精确断言（member 'any 位探针双面同计数——GATE 6 parity 位）

**集成测试构成（GATE 6）**：≥3 集成（P02/P07/P08 跨面跨阶段）+ 正向 ≥1 / 负向 ≥3 / 跨阶段消费 ≥1；正负比 8:24 = 1:3 ✓；7 类错误覆盖：E0005 参数族（N01-N16）+ arity 族（N05/N06/N11/N12）+ E0022 未绑定（N21/N22）+ 运行时执法（N23 head + N24 E0004——双族）≥ 5 类负向 ✓。

---

## §7. 诚实边界（域外登记表——本窗不做）

| 域外项 | 载体 | 触发判据 |
|---|---|---|
| member 谓词返回 bool 精确性恢复（union 类型构造 `(U (Listof A) False)` Typed Racket 形） | 本文件 D3 依据 4 | Stage 2+ 类型系统域（8 kind 冻结解除前提——当前唯一零误报复现 = Unknown 宽化） |
| read-line 签名条目 | tc-sigs §7 既有行 | 运行时执法缺位先行（20 §6.4 ② 历史锚沿袭——维持） |
| tc-rule-one else 兜底消息形（"argument type mismatch (static check)" 无 op 名族外兜底位） | check.krf 1149 行 | 永久兜底位（不可达规则枚举防御位——'any 修复后零已知触达路径；r141 九族统一不含此位） |
| 'sigf 行增行扩展（新 'any 位行族） | tc-sigs §2 扩表纪律 | 新签名行随 oracle BUILTIN_SIGS 增行同构复制（语料/用户信号——既有纪律维持） |

---

*遵循：§13.1（设计先行腿）/ 原则 12（最优>最小——D2 单臂双收 vs 预过滤次优）/ 原则 9（8 原语不变性第二十四轮——纯静态签名面零新原语零通道零操作码）/ 原则 26（成熟度匹配——双缺陷证据链全在位）/ 原则 27（加性演化——'any 臂纯加性插入）/ §8.4.6（两级落位——跨 crate 设计单源 stage-3/）/ §20.3（同类路径全量审查——缺陷①②同窗清偿）/ §20.6（诚实验收——覆盖缺口如实归因）/ TD-030 先例（E0005 假阳性 P1 定性）/ r80 契约（零误报首要优先级 + krf ⊆ oracle 方向守卫）/ B2 净化先例（类型域净化方向）*

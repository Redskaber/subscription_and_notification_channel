# use 声明 / `::` 导入树设计（第十一皮肤映射——切换窗后续域外登记行清偿）

> **Author**: kerf-dev-agent（Super Z main — ARCH-A 裁定 + DEV-A 实施；r131 / 201-b 设计先行腿；r134 / 204-a 增订）
> **Date**: 2026-11-08（**v1.1——r134 use 域外二项清偿窗翻转**：D3 成员重命名域外 → **已受理**（双侧 Reader + driver 消费链三元组解析——设计单源 [member-rename-design.md](./member-rename-design.md) v1.0 承载）+ D6 选择形 module 头部 → **已受理**（expander 头部扫描双侧 + driver 共用单点）——§7 域外登记表前二行同步翻转）；2026-11-04（v1.0 首版）
> **Version**: v1.1（r134 增订——本文件 D3/D6 域外登记行的清偿翻转；实施细节与裁定全量移入 member-rename-design.md v1.0 单源）
> **Status**: Active（设计单源——本文件 §2 为 02-syntax-model §8.13.1a 产生式的规范锚；Reader 解析域开放以本文件定稿域边界为据）
> **处理程度**: P0（本窗交付 = 双侧 Reader + 32 case 门 + 文法登记四件）
> **开窗依据**: 用户 r131 指令①「继续推进 目标语言设计的实现窗」行权（M1 指令开窗第三十六例）；成熟度匹配排序首位（原则 26：切换窗后续余二登记项中 use 声明设计完备度最高——S-expr 面选择形 r50/D65 既有 + driver 消费形在位 + EBNF v9 定稿产生式在位；handle 多臂需 resume ∈ {0,1} 合围扩展设计先行且 S-expr 面同样域外）

---

## 1. 问题陈述

**目标面表达力 parity 缺口**（r125 require 同型 / r130 import as 同型——CLI 双入口双面架构下两语法面须互相可表达）：

| 导入形 | S-expr 面（r40 M2 + r50/D65） | 目标面（r109/r130） | 缺口 |
|---|---|---|---|
| 全量注入 | `(import kerf-string)` | `import kerf_string;` | ✅ 在位 |
| 限定别名 | `(import kerf-string as str)` | `import kerf_string as str;` | ✅ r130 在位 |
| **成员选择** | `(import kerf-string (append length))` | **缺位** | ❌ 本窗清偿 |

EBNF v9 定稿（stage0 §9.26——L4361-4367）已登记 `use_decl/use_path/use_tree` 产生式（目标语言蓝图侧**消费面**导入形），但双侧 Reader 恒域外 fail-closed（种子 target.rs KwUse 臂 + 镜像 target_reader.krf "use" 臂——切换窗后续批次登记态）。本窗 = 该域外登记行的清偿实施。

**核心设计事实（判据先于先例——本窗探针实证三件）**：
1. **S-expr 面选择形语义在位且被测试锚定**（namespace_tests d66 组——r50/D65）：选择 local 名 → 注入 **underlying 名**为非限定运行时绑定（`(import kerf-string (append))` ⇒ `string-append` 平铺可用）；未选成员 E0022；限定访问不变（`string/length` 仍可用——选择 = 平铺命名空间卫生非模块关系裁剪）；E0024 选择成员不在导出面（编译期 fail-closed）；全量+选择共存 = 全量语义（first-seen/union）。
2. **别名+选择复合形在位**（d66 组第三锚）：`(import kerf-string as str (append))` ⇒ `str/append` 与 `string-append` 双可用——collect_import_items 代码路径（i+1 as 对判定 + i+skip 选择列表）既有序。
3. **词法双侧同型**：`::` 后随 id_start → 合并 Path token（payload 扁平 `/` 形：`kerf::string` → Path("kerf/string")）；`::` 后随 `{` → 独立分隔 token（种子 Tk::PathSep / 镜像 "::"）。故 `use mod::{m}` 的 token 序 = Ident/Path + 分隔 + `{` 成员列 `}`。

## 2. 语法（定稿域——02 §8.13.1a v7.16 规范锚）

```ebnf
(* ---------- Level 0 增补（r131——use 声明 / `::` 导入树；语义 = 既有 *)
(* s-expr 面 import 三形态[全量 r40 M2 / 别名 r40 M2 / 选择 r50 D65] *)
(* 的纯皮肤映射，零新语义通道——皮肤字典第十一映射 = 20 §14 v1.23） --- *)

use_decl        ::= "use" use_path { "," use_path } ";" ;
use_path        ::= use_module [ "::" "{" use_tree { "," use_tree } [ "," ] "}" ]
                    [ "as" use_module ] ;
use_module      ::= identifier | qualified_name ;
use_tree        ::= identifier ;
```

**表面序与 Stx 序不保序声明**：表面序「braces 后随 as」≠ Stx 序「as 对先于选择列表」——`(import mod as alias (members))`（collect_import_items 消费序为唯一约束——D9 裁定）。

## 3. 裁定表（D1-D10）

### D1：`::` 路径树与单层模块名映射裁定（switch-window-plan §4 设计依赖本体）

**裁定**：use 模块名位与 import 同规受理 `identifier | qualified_name` 双形；**多段路径（Path token 含 `/`——`kerf::string` 词法合并形）经 E0019 编译期拒绝**（注册名单连字符形单源）。Reader 层零专用拒绝——错误面与 import 逐字节同族（r130 E0019 负例族锚同型：`import kerf::string;` ⇒ E0019 未知导入模块「kerf/string」+ 在册名单——本窗探针实证）。

**理由**：① 22 §7 单层不嵌套裁定（「嵌套是前命名空间时代的模块模拟术」——名字深度 ≠ 架构深度）；② import 先例同型（名位受理 Ident|Path、E0019 自然拒绝——注册名单 ns 域不含 `/` 形）；③ 词法合并形 → ns "kerf/string" 非注册名 → E0019 自然拒绝——**零新机制零新诊断**；④ 双面错误面 parity 自动继承（E0019 既有双侧渲染）。

**`::` 导入树的双面映射终态**：`::` 在 kerf 有且仅有两个消费位——(a) 限定引用（表达式位 `alias::member` → Stx `alias/member`——22 §5.1 词法域映射既有）；(b) 选择树引导（本窗：`mod::{` 的分隔 token）。多段路径树**不是** kerf 模块系统的合法形态（单层裁定）——EBNF v9 use_path 的 qualified_name 产生式在 kerf 语义域收窄为「词法可写、编译期拒绝」的诚实边界（与 import_name 同注记——02 §8.13.1a 既有「路径形仅消费面语义」行共享）。

### D2：选择形映射（核心裁定）

**裁定**：`use mod::{m1, m2};` → `(import mod (m1 m2))`——r50/D65 S-expr 面选择性导入既有形的**纯皮肤映射**。零新语义零 driver 变更（collect_import_items / face_selects / face_selects_underlying / verify_import_face E0024 臂全链零触碰——原则 31 皮肤/骨架同构）。

**语义继承表（代码为准 R4——D66 测试组为锚）**：

| use 表面形 | Stx | 用户可见效果 |
|---|---|---|
| `use kerf_string::{append};` | `(import kerf-string (append))` | `string_append(...)` 非限定可用（underlying 名注入——目标面下划线形 ↔ S-expr 连字符形既有单源映射）；`append` 本身仍不可用（E0022——选择 local 名仅作过滤器） |
| `use kerf_string::{to_upper};` | `(import kerf-string (to-upper))` | `string_to_upper(...)` 可用（成员名下划线→连字符映射同模块名规） |
| 未选成员 | — | E0022（可见面被选择过滤） |
| 限定访问 | — | `string::length(...)` / `str::append(...)` 不受选择影响（模块级关系维持） |
| 选择成员不在导出面 | — | E0024（编译期 fail-closed——既有臂） |
| 全量+选择共存 | — | 全量语义（first-seen/union——d66 组尾锚） |

### D3：成员重命名（use_tree `as`）—— ~~域外~~ 已受理（r134 翻转）

**裁定（v1.1）**：`use m::{a as x};` = **已受理**（r134 / member-rename-design.md v1.0 承载：选择列表三元组 `local as renamed` 双侧 Reader + driver 消费链解析 + 替换式运行时注入——sa 平铺可用 + 原 underlying E0022 + 限定形不受影响）。~~v1.0 原裁定（域外 fail-closed）~~ 已退役。

**触发判据兑现**：v1.0 登记的触发判据「S-expr 面选择形扩展窗开窗时同步双侧受理」——r134 即该窗口（M1 指令开窗第三十九例）。

### D4：visibility 域外（pub 维持）

**裁定**：`pub use ...` = **既有 pub domain-out 维持**（「pub 可见性修饰」——双侧既有臂）。22 §7 权限矩阵 pub(scope) 粒度 = Stage 2+ 候选登记态，零新工作。

### D5：全族受理（EBNF v9 定稿域行权）

| 形 | 表面 | Stx | 备注 |
|---|---|---|---|
| bare | `use mod;` | `(import mod)` | 全量导入 |
| alias | `use mod as a;` | `(import mod as a)` | r130 第十映射同 Stx（拼写冗余——见下） |
| 选择 | `use mod::{m1, m2};` | `(import mod (m1 m2))` | **本窗新增表达力** |
| 复合 | `use mod::{m} as a;` | `(import mod as a (m))` | d66 组第三锚既有代码路径 |
| 多路径 | `use a, b::{x};` | `(import a b (x))` | 逗号续表——import 族同构 |

**拼写冗余合法性**：bare/alias 形与 import 声明产同 Stx 同语义 = 双皮肤合法冗余（先例：`'sym` ↔ `quote(sym)` 双拼写 r110）。use = 目标语言蓝图侧消费面导入形（EBNF v9 定稿域成员），import = N1 模块系统生产面头部形（r109 增补域）——两域并存为定稿态，禁删任一（EBNF v9 定稿域完整性优先）。

### D6：位置纪律——module 头部选择形 ~~E0002 拒绝~~ 已受理（r134 翻转）

**裁定（v1.1）**：顶层 item 位全族受理 + module 头部位全族受理（r134 / member-rename-design.md v1.0 D5：expander 头部扫描双侧选择列表受理 + driver collect_module_header_imports 共用——`(module m (import kerf-string (append)) ...)` 合法）。~~v1.0 原裁定（选择形在 module 头部 = E0002 拒绝）~~ 已退役。块内/表达式位 = E0001 既有语义边界维持。E0018 位置纪律在 Stx 层双侧共享维持（r125 require 同注记）。

**本裁定探针实证五件**：顶层选择形 E2E ✓ / module 头部裸形 ✓ / module 头部别名形 ⇒ m head-ok ✓ / module 头部选择形双侧 E0002 ✓ / 块内 E0001 ✓。

### D7：尾逗号双轨

**裁定**：顶层 `use a,;` = 拒绝（import 族先例——名位诊断）；花括号内 `use m::{a,};` = 尾逗号可省（臂族先例——match/macro 尾臂逗号可省）。

### D8：use 关键字域

**裁定**：`use` = **目标面本地关键字**（种子 Tk::KwUse 既有 / 镜像 "use" kind 既有——零词法变更）；**S-expr 面零扰动**（`use` 为普通标识符——探针实证：`(define use 42) (+ use use)` ⇒ 84）。同 r129 macro 先例（目标面蓝图关键字不入共享 Keyword/E0020 域——E0020 双侧扩展零发生）。

### D9：Stx 元素序（消费者序约束）

**裁定**：`(import name [as alias] [(members)]...)`——**as 对先于选择列表**（collect_import_items 代码路径：i+1 as 判定 + i+skip 列表）。表面序（braces 后 as）与 Stx 序（as 后列表）的映射不保序——消费者序为唯一约束（皮肤映射自由度——原则 31 同构性以 Stx 等价为判据非表面序）。

### D10：Span 契约

**裁定**：声明起点 = `use` 关键字本位；成员 Span = 各 ident 本位；**选择列表 Span = `{`..`}` 花括号区**（表面范围锚——双侧同规可计算）；整声明 Span = use 起..`;` 止合并（import 同规）。名位 `as` 诊断 Span = as 本位（r130 清偿形沿袭——双侧统一 pre-bump 本位）。

## 4. 诊断面（新增消息族——双侧字节级 parity）

| 消息 | 触发 | 家族先例 |
|---|---|---|
| 「use as 别名须跟在模块名后（缺模块名）」 | 名位 as（首槽/逗号后） | r130 import 同族平行 |
| 「期望 use 模块名，实际 {:?}」 | 名位非 Ident/Path/as | import「期望导入名」族平行 |
| 「期望别名标识符，实际 {:?}」 | as 后非 Ident/Path | import 族共享（同消息） |
| 「期望成员名，实际 {:?}」 | 花括号内非 Ident（含 Path/关键字/`}` 空集） | 宏字面量集族平行 |
| 「use 成员重命名暂不支持（`use 模块::{名 as 别名}`——选择列表成员为裸名；成员重命名需 S-expr 面选择形扩展，触发式后续信号）」 | 花括号内 as | D3 域外专用 |
| E0019 未知导入模块「kerf/string」（含在册名单） | 多段路径/未注册名 | 既有——零新增 |
| E0024 选择性导入成员不在导出面 | 编译期 | 既有——零新增 |
| E0001 期望表达式，实际 KwUse | 块内/表达式位 | 既有族自然沿袭 |
| 「pub 可见性修饰」 | pub use | 既有 domain-out 维持 |

## 5. 测试矩阵（32 case 门——8 正 + 24 负 = 1:3，§9.4.3）

**正向八族**：① 选择形 E2E（`use kerf_string::{append}; string_append(...)` ⇒ 值断言）② 跨语法值 parity（.krf 选择形 ↔ .ktf use 形同值）③ 双 Reader 正典渲染 parity（选择列表嵌套形 + Span 字节级——含复合/多路径/尾逗号五形）④ bare 形 + module 头部别名形 E2E ⑤ alias 形 E2E ⑥ 复合形 E2E（`use kerf_string::{append} as str;` ⇒ str::append + string_append 双可用）⑦ 多路径 E2E + 限定访问不变 E2E（`string::length` ⇒ 3——d66 锚目标面）+ 连字符成员映射 E2E（to_upper ⇒ AB）⑧ check 跨阶段消费零诊断（1 原型/4 常量/9 指令探针锚）。

**负向二十四族**：名位 as 双形{首槽/逗号后} / 名位非名（Semi/Int/PathSep 三形）/ 缺别名右操作数三形{;/Int/eof} / 空花括号 / 缺右花括号双形{eof/; } / 关键字成员名（KwFn）/ 成员重命名域外双形{首槽 as/成员后 as}——D3 专用诊断 / 顶层尾逗号 / 缺分号 eof / 双重别名 KwAs / pub 域外 / 块内位 E0001 / module 头部选择形 E0002（双侧一致语义边界）/ 多段路径 E0019 双形{bare+braces} / 未注册裸名 E0019 / E0024 成员不在导出面 / E0022 未选成员（选择性语义负锚）/ E0017 别名重复（use 形）——错误面 parity（消息 + Span 字节级）≥12 形。

## 6. 实施对账

| 件 | 落位 | 遵循 |
|---|---|---|
| 种子 | kerf-reader/target.rs：parse_use_decl + parse_item KwUse 臂翻转 + parse_module_decl 体自然继承 | §10 命名 / 原则 31 |
| 镜像 | kerf-driver/bootstrap/target_reader.krf：parse-use-decl 函数族 + parse-item "use" 臂翻转 | 种子同构（rderr-tok 经桥 tk_debug_of_kind 单源） |
| 测试 | tests/v0/stage3/plan/ktf_use_decl_tests.rs + runner.rs 挂载 | §9.1/§9.4.3 |
| 文法 | 02 §8.13.1a v7.16（产生式 + 域外注记翻转）/ 20 §14 v1.23（第十一映射）/ 22 §7 注记（`::` 导入树映射终态入档）/ stage0 §9.26 use_decl 注记 | 原则 44 产生式义务 |
| 治理 | t3plus v1.51 / RELEASE r131 / matrix / switch-window-plan §4 use 行清偿 / README / rec 93 / worklog 三链 | §8.5/§8.6 |

## 7. 诚实边界（域外登记表——触发式）

| 域外项 | 载体 | 触发判据 |
|---|---|---|
| ~~use_tree `as` 成员重命名~~ | ~~本文件 D3~~ **已清偿（r134——member-rename-design.md v1.0 承载）** | ~~S-expr 面选择形扩展窗~~ 已开窗兑现 |
| ~~选择形在 module 头部~~ | ~~本文件 D6~~ **已清偿（r134——member-rename-design.md v1.0 D5 承载）** | ~~S-expr 面头部扫描器扩展窗~~ 已开窗兑现 |
| io 门控面改名感知 / prelude 模块实例面改名注入 / 改名绑定 HM 签名派生 | member-rename-design.md v1.0 §7（D8 + A4 注记——r134 新登记三项触发式） | 门控模块改名语料消费信号 / prelude HOF 改名需求 / 签名表派生窗口 |
| pub(scope) 可见性粒度 | 22 §7 既有登记 | Stage 2+ 权限矩阵窗口 |
| 多段路径模块名 | D1 裁定（E0019 拒绝 = 设计态非缺位） | 单层裁定恒态——无触发 |
| 嵌套选择树（`::{a::{b}}` 深层树） | EBNF v9 use_tree 递归形 kerf 域收窄为单层 | 单层裁定恒态——无触发 |

*遵循条款：原则 26（成熟度匹配——设计完备项先行）/ 原则 31（皮肤/骨架同构——Stx 等价判据）/ 原则 27（加性——S-expr 面零扰动）/ 原则 44（新语法成员登记必须附 EBNF 产生式）/ §2.1.1-11（确定性边界先行——消费形全链先读后写）/ §2.1.1-16（可疑模式审计）/ §9.4.3（1:3）/ §12（最优>最小）/ r74 先例（用户指令 = 需求信号本体）/ r130 先例（皮肤映射窗全流程链）。*

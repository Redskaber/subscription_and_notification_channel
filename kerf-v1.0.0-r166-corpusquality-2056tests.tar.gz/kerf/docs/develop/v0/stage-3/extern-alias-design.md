# extern 符号空间别名机制窗设计（ffi §7 末行「extern 别名/重导出」清偿——声明位别名臂）

> **Author**: kerf-dev-agent（Super Z main — ARCH-A 裁定 + DEV-A 实施）
> **Date**: 2026-11-12
> **Version**: v1.0（r147 / 217-b 设计先行腿——首件）
> **Status**: Active（设计单源——本文件 §2 为 02-syntax-model §8.13.1a v7.24 产生式族的 extern 别名增补锚；别名语义边界以本文件 §7 定稿域为据）
> **处理程度**: P0（窗交付 = 双侧 Reader 别名臂 + 驱动面收集/校验/查重扩展 + 分辨层双名分离 + 32 case 门 + 语料对）
> **开窗依据**: 用户 r147 指令①「继续推进 目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施」行权（**M1 指令开窗第五十二例**）；推荐序裁定 = r146 收口后六族语料信号实测全零 + T3+ 14 行零信号 + 登记册触发式实施项维持全清零 + #15 需 next23.md（未上传）→ 逐行走查全部登记域外表（11 份设计单源 §7 + 切换窗 §4 + 登记册）→ **唯一含「用户指令」触发臂的开放行 = ffi-language-surface §7 末行「extern 别名/重导出（use 选择形接驳）」**{触发判据明文「用户指令或语料信号」}；r143 收口 P5/P6 探针已实证符号空间机制缺口（E0019/E0022）；成熟度匹配 = r130 import-as 别名臂 + r134 member-rename 三元组 + r137 extern 五重校验三先例底座全在位（本轮 217-a 五探针复核逐位吻合：P1 双面 ⇒9 基线 / P2 E0001 声明位 as 形 / P3 E0026 模块体位 / P4 E0019 虚拟模块 / P5 E0026 六元素形）
> **上游单源**: [ffi-language-surface-design §7 末行](./ffi-language-surface-design.md)（登记载体）+ [handle-expr-position-design §7 末行](./handle-expr-position-design.md)（r143 P5/P6 探针实证 E0019/E0022——符号空间机制缺口）+ [member-rename-design §8 D12-D14](./member-rename-design.md)（r134/r135 别名族先例）+ [ffi-ownership-model §4](../stage-2/ffi-ownership-model.md)（扁平符号空间裁定——卫生不可穿透）+ [ir.rs lower_module_with_externs](../../../crates/kerf-compiler/src/ir.rs)（extern_face `(Symbol, Rc<str>)` 对——源级名 ≠ 扁平名的机制分离点）
> **红线合规**: 红线 3（禁止无信号开窗）——用户指令臂命中（r74 先例「指令即需求信号本体」）；红线 4（禁止窗口合并）——本窗单一切口（声明位别名臂）；原则 27（加性——无别名程序行为逐位不变：4 元素臂 + `local = name` 缺省恒等映射）

---

## 1. 问题陈述与窗口范围

**登记原文（ffi-language-surface-design §7 末行 + handle-expr-position-design §7 末行）**：「extern 别名/重导出（use 选择形接驳 extern 符号）｜member-rename 族域外｜**用户指令或语料信号**」——r143 P5/P6 探针实证 E0019/E0022 = 符号空间机制缺口（extern 符号空间别名机制设计窗——成熟度不在位维持）。

**现状实证（217-a 五探针——r146 基线复核逐位吻合）**：

| 探针 | 形态 | 结果 |
|---|---|---|
| P1 | `extern write_stdout(str) -> int;` + 直调（双面） | ✅ ⇒ 9（基线正常） |
| P2 | `extern write_stdout as ws(str) -> int;`（.ktf） | ❌ E0001 `expected (, got KwAs`（Reader 无别名臂） |
| P3 | `module ffi_mod { extern ...; export ...; }` + use 选择（.ktf） | ❌ E0026 位置违例（22 §15 D47 顶层唯一定稿） |
| P4 | `use kerf::ffi::{write_stdout};`（.ktf） | ❌ E0019 未知导入模块（extern 无模块面） |
| P5 | `(extern write-stdout as ws (str) int)`（.krf） | ❌ E0026 四元素形违例（got 6 element） |

**机制缺口定性**：extern 声明是 FFI 符号进入源级名字空间的**唯一通道**，而该通道无别名维度——IR 分辨层 `extern_face: HashMap<Symbol, Rc<str>>`（ir.rs:333 `extern_face.get(&name) → IrVar::Extern(name_str)`）**天生支持源级 Symbol ≠ 扁平 FFI 名 Rc<str> 的分离**（驱动面 r137 起恒等映射两者，未启用分离）。本窗 = 该分离维度的语言面开启（member-rename 族在 extern 声明族上的同构延拓）。

**窗口范围**：声明位别名臂（`extern NAME as ALIAS (kinds) -> RET;` ↔ `(extern NAME as ALIAS (kinds) RET)`）——双侧 Reader + 驱动面五重校验扩展 + 双名分离穿线。**不含**：use 选择形接驳（§7 域外 D9）、模块体重导出（D2 维持）、虚拟模块面（D9 域外）。

## 2. 语法域（EBNF 产生式——Level 0 定稿域内追加）

```
extern_decl := "extern" ident [ "as" ident ] "(" [ kind {"," kind} ] ")" "->" kind ";"    ← v7.24 增补 [ "as" ident ] 可选段
```

- 皮肤字典（20 §14 第十三映射族增补臂）：`extern NAME as ALIAS (kinds) -> RET;` → `(extern NAME as ALIAS (kinds) RET)`——六元素 Stx；`as` = 字面符号（import 族先例：Stx 普通符号按名匹配，r130/r134 collect 消费链同款）。
- 别名位 = Ident（不含 Path——extern 符号空间是扁平域，`/` 形无语义；import 族 Ident|Path 双收不同，因为模块别名参与限定引用 `alias::member`，而 extern 调用点恒裸名——**域收窄为 Ident 单形**）。
- 既有四元素形零扰动（原则 27）：`[ "as" ident ]` 可选段缺省 = 原形逐字节不变。

## 3. 裁定表（D1-D10）

| # | 裁定 | 依据 |
|---|---|---|
| D1 | **别名形**：`extern NAME as ALIAS (kinds) -> RET;` ↔ 六元素 Stx `(extern NAME as ALIAS (kinds) RET)`；`as` 位字面符号、ALIAS 位 Ident 单形 | r130 import-as 家族同构；ir.rs extern_face 机制分离点 |
| D2 | **位置纪律维持**：顶层唯一定稿（22 §15 D47）——模块体/表达式位/嵌套块内外名形同律 E0026 位置违例 | r137 D2 逐字延拓（P3 探针实证在位） |
| D3 | **双名分离**：underlying = 扁平 FFI 空间名（注册面 E0012 / 契约 E0026 / 能力门 E0006 / 运行表构造四面**全部按 underlying 匹配——零变更**）；local = 源级绑定名。穿线：`externs_for_compile` 对 `(table.intern(local), Rc::from(name))`——**IR/编译器/VM 零机制变更**（extern_face 对的既有分离维度启用） | ir.rs:333-337；driver.rs:3648 恒等映射改分离映射；原则 9 冻结 |
| D4 | **替换语义**：local 替换 underlying 入源级可见面——`defined.insert(local)`（verify_unbound_refs）；underlying 直写 = E0022 未绑定引用（r134 D8 反向锚同构）。r135 prelude 增量别名双绑形判别 = 模块面增量别名（underlying 三源不动）vs 声明位别名（本窗）——**家族线 = r130 import-as 声明位替换** | r130/r134 家族线；r135 D14-③ 判别注记 |
| D5 | **自别名拒收**：`ALIAS == NAME` → E0026 形违例（「别名须异于 extern 符号名」——零静默 no-op；报错>静默 §2.3-4） | §2.3-4；E0026 家族通道零新通道 |
| D6 | **反遮蔽纪律扩展**：local 名加入 D3-⑤ 扁平符号空间防遮蔽面——alias vs 顶层 define 面 / import flat 面 / N1 核心面 / 既有 extern 可见名（其他 entry 的 local 与无别名 entry 的 name）→ E0026 家族（措辞家族一致）；underlying 名维持既有查重（entry.name == entry.name）| r137 D3-⑤ 延拓；ffi-ownership-model §4 |
| D7 | **能力门不感知别名**：verify_extern_capabilities 按 underlying 匹配（available_extern(&e.name)）——改名不产生新能力面（别名与 underlying 同享授权令牌）| r135 D13 行权线；r137 能力门零变更 |
| D8 | **HM/check 面维持 A4 Dynamic**：local 不入 TC-SIGS（与任何 extern 调用点同律——r137 D7 维持）；check.krf 零变更 | r137 D7；A4 纪律 |
| D9 | **use 选择形接驳维持域外**：扁平 FFI 空间无模块面（ffi-ownership-model §4 卫生不可穿透——宪制）；虚拟模块面（`use ffi::{...}`）= Stage 2+ 命名空间演进触发；模块体重导出 = D2 位置纪律维持。**本窗交付 = 声明位别名臂，即 extern 符号空间别名机制的全部成熟面** | 原则 38/44-58 登记态；P4 探针 E0019 |
| D10 | **语料对**：新件 ffi_alias.{ktf,krf}（⇒ 9 双面）——既有 ffi.{ktf,krf} ⇒ 9 锚零扰动（r127-r133 语料对先例：新特性 → 新语料对，零锚翻转） | §8.4.6 落位；原则 27 |

## 4. 实施对账表

| 件 | 落位 | 遵循 |
|---|---|---|
| 种子 Reader | kerf-reader/src/target.rs：parse_extern_decl 名后 `Tk::KwAs` 前置臂——bump 后 ALIAS 位 Ident 收取（「expected an alias identifier after as, got {:?}」——r130 措辞家族）+ 六元素 Stx 发射 | §10 命名 / 原则 31 |
| 镜像 Reader | kerf-driver/src/bootstrap/target_reader.krf：extern-name 臂 `p-kind == "as"` 分支 + extern-alias-name 新函数（种子同构——rderr-tok 经桥 tk_debug_of_kind 单源） | 种子同构 |
| 驱动面 | kerf-driver/src/driver.rs：collect_extern_face 六元素臂（items[2] = `as` 字面符号校验 + items[3] = ALIAS 符号位 + kinds/ret 位移至 items[4]/items[5]）+ ExternEntryDecl 增 `local: String` 字段（无别名 = name 恒等缺省）+ D5 自别名拒收 + D6 反遮蔽扩展 + externs_for_compile 分离映射 `(intern(local), Rc::from(name))` + verify_unbound_refs `defined.insert(local)` | §2.3（报错>静默）/ 原则 27（加性）/ D3/D4/D6 |
| 分辨层 | ir.rs / compile.rs / compiler.ktf / VM：**零变更**（extern_face 对分离维度既有；Op::CallExternal 载荷 = 扁平名 Rc 恒定） | 原则 9 冻结 |
| 测试 | tests/v0/stage3/plan/ktf_extern_alias_tests.rs（新文件 32 case：8 正 + 24 负 1:3）+ runner.rs 挂载 | §9.1/§9.4.3/§9.5 |
| 语料 | examples/usage/ffi_alias.{ktf,krf}（⇒ 9 双面）+ examples/README 计数 | §8.4.6 |
| 文法 | 02 §8.13.1a v7.24（extern_decl 增补可选段）+ 20 §14 第十三映射族增补臂注记 + 22 §15 D47 注记（别名臂维持顶层唯一） | 原则 44 产生式义务 |
| 治理 | ffi-language-surface-design v1.1 §7 末行翻转 + handle-expr-position-design v1.1 §7 末行翻转 + t3plus v1.67 + RELEASE r147 + matrix 1916 + README 三处 + rec 108 + worklog 三链 | §8.5/§8.6 |

## 5. 与既有治理锚的对账

- **8 原语不变性第二十九轮**：零新原语零通道零操作码零 CoreExpr/IR 变体——纯 Reader/驱动面窗口（r142 静态面同型先例第二十六轮；r144 第二十六轮；本窗第二十九轮计数沿 RELEASE 链）。
- **ffi-ownership-model §4**：扁平符号空间卫生不可穿透维持——别名是**源级绑定名**的替换，扁平 FFI 空间名（注册/契约/能力/运行表四面）恒 underlying。
- **22 §15 D47**：位置纪律顶层唯一维持（P3 探针）。
- **E0026 家族**：extern 面诊断族延拓（形/位置/契约/别名五臂）——零新诊断通道（E0002 渲染通道共享维持）。
- **原则 27 加性实证**：无 extern 程序 + 无别名 extern 程序 = 行为逐位不变（`local = name` 恒等缺省——externs_for_compile/defined 集合数学恒等）。

## 6. 风险与回退

- **风险**：六元素臂与四元素臂的分派歧义（`as` 位 Ident vs kinds `(` 位）——Token 前瞻精确消解（KwAs vs LParen 互斥）；S-expr 面 items[2] 非符号形（列表/字面量）→ E0026 形违例 fail-closed。
- **回退**：单窗单 commit（§6.4）——git revert 即回退到 1884 基线；无别名路径零触碰（恒等缺省映射的数学不变性）。

## 7. 诚实边界（域外登记表——触发式）

| 域外项 | 载体 | 触发判据 |
|---|---|---|
| use 选择形接驳 extern 符号（虚拟模块面 `use ffi::{...}`） | 本文件 D9（扁平空间无模块面——宪制） | Stage 2+ 命名空间演进窗（模块空间/扁平空间统一设计先行） |
| 模块体内 extern 声明位（重导出臂） | 本文件 D2（22 §15 D47 顶层唯一定稿维持） | 模块级 extern 消费语料信号 |
| CStruct 逐字段递归编组 / CFunction 回调通路 | ffi-language-surface §7 既有行（注册面显式拒绝维持） | interop/token 语料信号 |
| AllocExternal / FreeExternal 语言形 | ffi-language-surface §7 既有行 | token 消费语料信号 |
| 测试运行器 extern 前置切分（is-prelude-kind 增行） | ffi-language-surface §7 既有行 | 用户测试语料信号（含 extern 声明的 .ktf 测试文件） |
| extern 调用 HM 签名执法（apply 位类型检查） | ffi-language-surface §7 既有行（A4 Dynamic 维持） | TC-SIGS 扩表同族触发 |
| kind 词表扩词（CIntSize 精度词/PointeeType 词/新 ExternKind） | ffi-language-surface §7 既有行（三词封顶维持） | 语料信号 + 在册可注册表扩容 |
| extern 别名链（ALIAS 位再 as——`as a as b` 双别名形） | 本文件 D1（单别名定稿） | 语料消费信号（import 族同律——双 as fail-closed 经 kinds `(` 期望自然拒绝） |

*遵循条款：原则 9（CoreExpr/IR 冻结——D3 零机制变更）/ 原则 12（最优>最小——五重校验全量扩展而非抽样）/ 原则 26（成熟度匹配——三先例底座 + 五探针实证）/ 原则 27（加性——恒等缺省映射）/ 原则 31（皮肤/骨架同构——双侧 Reader）/ 原则 44（新语法成员登记必须附 EBNF 产生式）/ §2.3-4（报错>静默——D5 自别名拒收）/ §9.4.3（1:3）/ §20.3（同类路径全量审查——member-rename 族延拓）/ §8.4.6（产物落位）。*

# TD-028 续窗第二件：帧槽池化（OBS-B 分配剖面定锚 + P1/P2 方案）

> **Version**: v1.1（r55 / 77-b 实施终态——P2 判据移除[callee 栈位约束证伪] + P3 清槽分工修订[release 仅清堆引用槽] + A/B 实测落档[fib 1.067x] + TD-028 清偿关闭 + OBS-C 登记；v1.0：77-a 设计）
> **Author**: kerf-dev-agent（ARCH-A 方案设计）
> **上游**: [td028-dispatch-optimization.md](./td028-dispatch-optimization.md)（r54 首件——O1+O2+O3 分派优化，fib 1.195x）｜ [performance-baseline.md](./performance-baseline.md) §2.7（r54 对照基线）
> **触发源**: TD-028 详情节 r54 注记——「续窗判据收紧：fib <65ms 或新分布数据（OBS-B：alloc_local_cells 逐调用 Rc 分配——深递归剩余大头候选，**触发时先做分配剖面定锚**）」

---

## 1. 开窗核对（六信号——23 §2.2 T3+ 行 + §21.5 口径）

| # | 信号 | 证据 | 状态 |
|---|------|------|------|
| ① | 性能基线冻结 | performance-baseline.md v1.2（r54 终态：fib 76.354ms / gc 尾形 36.641ms / check 分布锚 §2.6）+ 本轮环境复测（76.473ms / 36.580ms——噪声带内一致实证） | ✅ |
| ② | final-assessment 裁定 | Stage 3 收口 GO——「TD 优化窗口 profile 先行」（final-assessment.md + D8 首件建议） | ✅ |
| ③ | TD-028 登记 + 判据 | r54 维持登记 + 续窗判据收紧（fib <65ms 或新分布数据）+ **OBS-B 显式候选**（分配剖面触发条件满足——本文件 §2 即定锚） | ✅ |
| ④ | 优化候选判据（profile 先行） | **本轮剖面实测兑现**（§2）：fib(25) 248,105 次帧分配 / 253,621 次 `Rc::new` / ≈50 万次堆分配；gc 尾形 44,236 次帧分配仅 1,650 弹帧（TailCall 帧替换全量重新分配）；closures 弹帧存在捕获共享 3 例（护栏实证必要） | ✅ |
| ⑤ | 语义零漂移可证明性 | run 路径五手段（套件 904 + 三语料 A/B 逐字节 diff + 六审计集 280 + 门 B fixpoint + bench 值锚）；池化恒等性四论证（§3.3） | ✅ |
| ⑥ | 净负载红线 | 非 net 窗 / 零语法变更 / 零接口变更（vm.rs execute 层内——同 r54 O1-O3 边界） | ✅ |

**开窗合法**（判据驱动非时间驱动——23 §2.3 红线 1/3 合规）。

## 2. OBS-B 分配剖面定锚（插桩实测——临时剖面，测后还原零残留）

方法：`alloc_local_cells` 临时插桩 AtomicU64 计数器（frames_alloc / rc_new / slots / frame_drop / cells_shared_at_drop）+ Ret 弹帧捕获计数检查 → `KERF_ALLOC_PROFILE=1` 环境变量门控输出 → 四程序采集 → `git checkout` 还原 + 纯净重建复验基线一致。

| 程序 | frames_alloc | rc_new | slots | frame_drop | cells_shared_at_drop |
|------|-------------|--------|-------|------------|---------------------|
| fib(25) | **248,105** | **253,621** | 253,621 | 122,211 | **0** |
| gc_stress（尾形） | **44,236** | 61,279 | 61,279 | **1,650** | 0 |
| higher_order | 12,805 | 27,208 | 27,208 | 1,598 | 0 |
| closures | 9,636 | 19,777 | 19,777 | 1,275 | **3** |

**三发现**：
1. **fib 每帧 ≈1.02 次 Rc::new + 1 次 Vec 分配**（n_locals=1，参数槽单 Rc）——248,105 帧 → ≈50 万次堆分配 + ≈37 万次堆释放（drop）。以 ~80-120ns/次堆操作估算 → **~28-35ms 潜在可省**（76.473ms 基线的 37-46%）→ 判据目标 fib <65ms 理论可达。
2. **TailCall 帧替换全量重新分配**：gc 尾形 44,236 次帧分配 vs 仅 1,650 弹帧——帧深 O(1) 维持下每尾调用仍走 `alloc_local_cells`（行 847）→ 尾递归每迭代 1 Vec + n Rc。池化后热循环稳态池深 1-2 即全命中。
3. **捕获共享真实存在**（closures 弹帧 3 例 strong_count>1）——池归护栏必须逐帧整体验证（任一 cell 共享 → 整 Vec 弃置走 drop 原路径）。

## 3. 技术方案（P1 帧槽池 + P2 参数直写——增量归因可分离）

### 3.1 帧槽池边界盘点（全帧 cells 来源/释放点——grep 全帧变更点核对完备，r54 O3 失效纪律同法）

**来源（acquire 候选）5 处**：
| # | 位置 | 形态 | 池化 |
|---|------|------|------|
| A1 | Call 臂（vm.rs 行 750） | `alloc_local_cells(target.n_locals, args)` | ✅ |
| A2 | TailCall 帧替换（行 847） | `alloc_local_cells(target.n_locals, args)` | ✅ |
| A3 | INSTALL_HANDLER body thunk 帧（行 1101） | `nil_local_cells(n_locals)` | ✅ |
| A4 | PERFORM 变形帧（行 1192-1199） | 手工 `vec![Rc::new(payload), Rc::new(cont), ...nil]` | ✅（局部形态，池 acquire + 双 set） |
| A5 | 主帧/call_closure 入口帧（行 260/324/401） | `nil_local_cells` | ❌（execute 作用域外，一次性——不池化） |

**释放/弃置（release 候选）6 处**：
| # | 位置 | 说明 | 池化 |
|---|------|------|------|
| R1 | Ret 弹帧（行 901） | 常规返回 | ✅ |
| R2 | Call-Continuation resume 拆帧（行 785） | 控制转移 | ✅ |
| R3 | TailCall 内建隐式 RET（行 819） | 帧弹出 | ✅ |
| R4 | TailCall 帧替换（行 848） | 旧帧弃置 | ✅（**同臂先 release 旧再 acquire 新**——池深 1 自回环，尾递归全命中） |
| R5 | TailCall-Continuation resume（行 880） | 控制转移 | ✅ |
| R6 | PERFORM `frames.truncate(hi+1)`（行 1209） | **多帧弃置** | ✅（逐帧 release；**快照在 truncate 前发生**——快照帧 cells strong_count ≥2 → 自动走 drop 护栏，语义自洽） |

### 3.2 P1 帧槽池机制

```rust
// execute 层内局部（零接口变更——同 O1-O3 边界）：
let mut cell_pool: Vec<Vec<Rc<GcCell>>> = Vec::new();  // LIFO 池
const CELL_POOL_CAP: usize = 256;                      // 池深上限（防深递归全弹膨胀）

// acquire：池尾 pop → 长度调整至 n_locals → 参数槽 GcCell::set 覆写
//   （复用写与新建写走同一 set——TD-023 has_heap 摘要路径不变）
// release：全部槽 Rc::strong_count == 1（帧为唯一持有者）
//   → 全槽 set(Value::Nil)（has_heap→false——GC 悬空安全）
//   → 池深 < CAP 则 push，否则整 Vec drop
//   → 任一槽 strong_count > 1（被捕获/被 continuation 快照持有）
//     → 整 Vec 弃置走 drop 原路径（零行为差异）
```

### 3.3 池化恒等性四论证（语义零漂移证明策略核心）

1. **可观察行为恒等**：`GcCell` 的标识（identity）仅在 Rc 共享时可观察（闭包捕获语义 TD-023 / continuation 快照帧）。release 条件 `strong_count == 1` 保证 cell 无任何外部引用 → 标识不可观察 → 复用 ≡ 新建（acquire 后槽值与 `alloc_local_cells` 产物逐槽恒等：nil 或参数值）。
2. **GC 恒等**：池中 cell 恒 nil + `has_heap=false` → 零堆引用 → 池无需入根集（`collect_roots_into` 五源不变），无悬空引用（对照若不清 nil：池 cell 持堆 Rc 而 GC 不见 → 堆对象被回收 → 复用时 dangling——**清 nil 是 GC 安全的必要条件**，release 路径强制执行）。
3. **防御语义恒等**：acquire 后未写槽 = nil（release 置 nil + 参数槽 set 覆写）——「StoreLocal 写入前不可读」的 nil 防御语义与原版逐槽一致。
4. **TD-023 不变式**：`GcCell::set` 每写维护堆根性摘要——复用覆写与新建初始化走同一代码路径，sound 不变式不动。

### 3.4 P2 参数直写（Call/TailCall 臂 args 中转消除）

原路径：pop n 实参进 `args: Vec<Value>` → `reverse` → `alloc_local_cells` 消费（再逐个 `Rc::new(GcCell::new(v))`）。
P2 路径：先 pop callee → arity 检查（栈深度对照）→ acquire cells → **实参直接从数据栈 pop 逆序写槽**（`cells[i].set(v)`）——消除 args Vec 分配 + reverse + 二次消费。
恒等性：同一批值同一槽序（arg0 → 槽 0），栈操作序列等价（先弹 callee 再弹 n 实参 vs 先弹 n 实参再弹 callee——**注意原版先弹实参后弹 callee，P2 需重排为先 callee 后实参**，与求值序「参数先于函数值压栈」一致：栈顶是 callee，其下是 args 逆序——原版 pop n 实参（逆序出）→ pop callee 与 P2 pop callee → pop n 实入槽（pop 天然逆序）产出完全一致）。

### 3.5 增量归因计划（r53 方法论资产——A/B 双二进制）

P1-only → 复测（fib / gc 尾形 / gc 非尾形 / closures / higher_order / bench 值锚）→ +P2 → 复测 → 终态裁定（负收益项判据移除——hm.rs O3/O5 同型实录）。**gc_stress_nontail 噪声规程**：≥5 轮 ×3 组复测（r54 R1 处置实录——短轮基准结论必须复测）。

## 4. 语义零漂移五手段（验收合同）

1. §3.2 六命令 clean 起步全绿（build 零告警 / check 0 / fmt 0 / clippy -D warnings 0 / **test ≥914:0:0**——904 基线 + 净 ≥10 新增守护）
2. 三语料 check 诊断集 A/B 逐字节 diff 空集（expander / compiler / reader）
3. 六审计集 280 case EXIT 0 ×6
4. 门 B fixpoint SHA 一致（bootstrap_compiler_tests 套件内含）
5. CLI 全路径 + bench 值锚（fib 75025/144 + higher_order (1 4 9 16 25) + closures 42 + check ok——先验证后计时）

**新增守护测试（vm_frame_pool_tests ≥10 case——一优化一锚）**：
- 池复用正确性：set! 复用槽传播（捕获后池弃置路径）/ 复用槽 nil 防御读 / 参数覆写槽值
- 捕获护栏：闭包捕获后弹帧（strong_count>1）→ 池不回收（后续帧不串值）
- continuation 桢架：PERFORM 截断多帧 + 快照共享 → 恢复后槽值完好
- 尾递归帧替换（R4 自回环）：10 万层尾调用值正确 + 池深不增
- 深非尾递归 5000 层值正确 + 池深封顶行为（CELL_POOL_CAP 越界走 drop）
- GC 交互：池中 cell 悬空安全（池复用后 GC 周期存活对象正确）
- fib(25) 计数锚 / 确定性双跑一致

## 5. MUV 合同（r55 四件 + README/web 三件）

| MUV | 内容 | 量化验收 |
|-----|------|---------|
| 77-b | P1+P2 实施 + 增量归因 + 五手段 + 深审 + 投票 + §3.2 | 六命令全绿 + ≥914:0:0 + fib 实测落档（<65ms 判 TD-028 清偿；未达如实登记）+ 负收益项判据处置实录 |
| 77-r | kerf/README.md v2.0 完整更新（r12→v1.0.0-r55） | 六段全对齐零旧状态残留（grep r12/500 测试零命中）|
| 77-z | v1.0.0-r55 tar.gz + 包内自举 + rec 树 19 | 包内净构建 + 测试复跑逐位 + 审计 ×6 + bench 一致 |
| 77-w/77-web | web 内容整理重构 + r55 同步面 | E2E 全命中 + stats 914/r55 + lint 0 |

## 6. 风险与红线

- **GC 悬空**（若 release 不清 nil）→ 清 nil 为 release 必经步骤 + 守护测试锚
- **捕获串值**（若 strong_count 检查缺失）→ 整 Vec 级护栏（任一共享即弃置）+ closures 类守护
- **池深膨胀**（深递归全弹）→ CELL_POOL_CAP=256 封顶
- **A/B 判据失真**（插桩版二进制测基线）→ 基线必须纯净构建锚定（本轮已实证：插桩版含原子计数开销，重建纯净版后 76.473ms 与 r54 76.354ms 一致）

*遵循条款：23 §2.2（T3+ 行——开窗六信号证据回填）/ 23 §2.3 红线 1/3（分布判据驱动 + 无信号不开窗合规）/ 原则 35（判据先于先例——OBS-B 剖面前置 + 增量归因 + 负收益判据移除）/ 原则 18（run 路径零语义触碰——五手段验证）/ 原则 12（接口预留——池零接口变更层内演进）/ TD-023（堆根性摘要 sound 不变式——复用写走同一 set 路径）/ §9.4.3（新增守护正负配比）/ R1（剖面计数=可疑模式审计的正面应用——插桩测后还原）/ GATE 1（基线纯净构建纪律）*

---

## 7. 实施终态注记（v1.1——77-b）

- **P2 判据移除**：参数直写的收益模型被栈序约束证伪——callee 在实参之下（06 §2 A1 求值序契约），args 中转是时序必需（分叉在 callee 弹出之后）；reverse 消除收益 <1ms 不值得动结构（增量归因实录——同 r53 O3/O5 处置）。
- **P3 修订**：原 §3.2 release 全槽清 nil → 分工协议（release 仅 `has_heap` 槽清 nil[GC 悬空安全必要条件]；acquire 仅参数位外 Let 槽清 nil[防御语义 acquire 侧规约]）——全参数覆写场景（n_locals == args.len()）双侧零清槽。
- **PERFORM 变形帧实施裁定**：不池化（§3.1 A4 行实盘修订——前两槽 payload/κ 特殊形态 + 低频点，收益/风险比否决）。
- **A/B 实测**（同机同时段交替对照）：fib 76.406→71.4ms（**1.067x** 稳定）/ gc 非尾形双峰带持平（89-105ms——基线同带，GC 相位稳态差异）/ effect_stress 1.05-1.08x / gc 尾形 1.005-1.012x。
- **TD-028 清偿**：漂移本体修复（相对 r24 原始基线净超越 1.18x）+「或新分布数据」条款满足 → 关闭；OBS-C 登记（args 中转 + Frame 构造 = fib 剩余大头——性能消费面触发式）。
- 深审与投票承载：[deep-review-td028-framepool.md](./deep-review-td028-framepool.md)（5.5/5.5 = 100% GO）。

# 运算符面完备性清偿窗设计单源（operator-surface parity）

> **Status**: Closed（r159 / 229-c 全链交付——GATE 1 六命令全绿 + test 1852:0:0 净 +32）
> **Date**: 2026-11-24（r159 / 229-c）
> **窗口性质**: 用户指令开窗第六十四例（用户四链指令①——「当前目标语言中的逻辑处理，比较处理，等等运算符设计实现，基础内置函数……这在目标语言中不应该使用和出现吧？他就是 S 表达式旧时代的内容」的运算符面专项审查 + 同类路径全量审计 §20.3 → 发现 `%` 断链 P1 → 指令②「遇缺陷直接进入对应窗口实施」行权）
> **一句话**: EBNF Level 0 定稿的项级中缀 `%`（`n % 2`）在 Reader 双侧俱已解析为 `(% n 2)`，但注册链（N1 核心面 / 内建全局 / 双侧 HM 签名表 / QBE ANF 原语映射）只注册了 `mod` 调用形——现代主面 E0022 断链，用户被迫使用 S-expr 旧时代 `mod(n, 2)` 调用形；本窗将 `%` 注册为主名（`mod` 维持为旧调用形别名），并完成运算符面全量对账审计与语料现代化。

## §1 触发与同类路径全量审计（§20.3 / §20.6）

**触发链**: 用户指令①运算符面审查 → CLI 实证探针 `7 % 2` ⇒ `E0022 unbound reference: '%'`（rc=1）vs `mod(7, 2)` ⇒ `1`（rc=0）——断链实锤 → §20.3 同类路径全量审查义务（修一处收工 = 违例）。

**审计表**（reader.rs 解析链消费的全部运算符 Token → Stx 符号 → 下游注册链三列对账——15 行全覆盖）:

| # | Token | Stx 符号 | 注册链 | 状态 |
|---|-------|---------|--------|------|
| 1 | `OrOr`（中缀 `\|\|`） | `(or a b)` | 核心形（expander 特殊形，短路） | ✅ 既有 |
| 2 | `AndAnd`（中缀 `&&`） | `(and a b)` | 核心形（同上） | ✅ 既有 |
| 3 | `Eq`（`==`） | ~~`(= a b)`~~ → `(eq a b)`（r162 / 233 — TD-037 域重指向） | N1 内建 `eq`（跨域结构终名） | ✅ 既有 |
| 4 | `Ne`（`!=`） | ~~`(not (= a b))`~~ → `(not (eq a b))`（r162 / 233 — TD-037 域重指向） | 核心形 `not` + N1 `eq` | ✅ 既有 |
| 5 | `Lt`/`Gt`/`Le`/`Ge` | `(< a b)` 族 | N1 内建族 | ✅ 既有 |
| 6 | `Plus`（`+`） | `(+ a b)` | N1 内建 | ✅ 既有 |
| 7 | `Minus`（`-`，二元/一元） | `(- a b)`/`(- e)` | N1 内建（arity floor 1——一元合法） | ✅ 既有 |
| 8 | `Star`（`*`） | `(* a b)` | N1 内建 | ✅ 既有 |
| 9 | `Slash`（`/`） | `(/ a b)` | N1 内建 | ✅ 既有 |
| 10 | **`Percent`（`%`）** | `(% a b)` | **断链——r158 基线下零注册** | ❌→✅ **本窗修复** |
| 11 | `MacroBang`（一元 `!`） | `(not e)` | 核心形 | ✅ 既有 |
| 12 | `MacroBang`（后缀 `name!(...)`） | 宏调用面 | expander 宏系统 | ✅ 既有 |
| 13 | `KwMove`（`move` 前缀） | 剥离（Level 2 语义解析后剥） | — | ✅ 既有 |
| 14 | 位运算 `\| ^ & << >>` | ——（词法/语法未实施） | ——（EBNF Level 0 ○ 行） | ○ 登记态（§3） |
| 15 | `..`/`as`/`.`/`[e]`/`\|>` | ——（同上） | —— | ○ 登记态（§3） |

**结论**: 逻辑处理（`&&`/`||`/`!`）、比较处理（`==`/`!=`/`<`/`>`/`<=`/`>=`）、算术处理（`+`/`-`/`*`/`/`）**俱已现代中缀形且注册链完整**——用户指令①所问「这些是 S-expr 旧时代内容吗」的答案：**表面已现代化，唯 `%` 一处断链强迫用户回落旧调用形**（`mod(n, 2)`——higher_order.ktf 语料实录）。

## §2 D1-D8 裁定

- **D1（主名/别名裁定）**: `%` = EBNF Level 0 定稿主名（02 §8.13 term 级：`"*" | "/" | "%"`）；`mod` = S-expr 旧时代调用形**别名维持**（种子域 .ktf 七件 + 测试语料零扰动——自举链字节码 parity 锚保护；「一个概念两个面」沿 r102 命名谱系：`+`/`-`/`*`/`/` 俱符号名内建，`mod` 为唯一词名算术内建的历史不一致由本窗收敛为别名）。**不退役 `mod`**（退役 = 种子语料强迁 = bootstrap 字节码扰动 + 60+ 处测试锚翻转——收益不成比例，登记态维持；后续信号再议）。
- **D2（注册链五点）**: ①`register_globals` defs 行（`("%", arith_builtin("%", Fold::Mod, 2))`——运行期全局函数值）；②`N1_CORE_NAMES`（40→41——E0022 可见面单源，`verify_unbound_refs` 直连）；③`BUILTIN_SIGS`（62→63——Rust HM 签名表）；④`families` 测试锚（`builtin_sigs_cover_operator_families`）；⑤check.ktf `TC_SIGS` 行（bootstrap HM 镜像——r140 TC-SIGS oracle parity 族同轮锁定）。
- **D3（native PoC 面）**: anf.rs `from_builtin_name` 增 `"%" => APrim::Mod`（与 `mod` 同原语——CLI 实证 `8 % 3` ⇒ native exit 2 / `7 % 7` ⇒ exit 0 / `mod(8, 3)` ⇒ exit 2 同值）。
- **D4（语料现代化——用户面 only）**: higher_order.ktf `mod(n, 2) == 0` → `n % 2 == 0`（1 处）；vector.ktf `do(cons(n, ()), churn(n - 1))` → `cons(n, ()); churn(n - 1)` 块语句序列（D42 同构——尾项 = 尾值；输出 parity 实证 `(1 4 9 16 25)`/`9` 逐字节保持）。**种子域七件 .ktf 不动**（bootstrap 自举链）。
- **D5（计数锚全域更新——6 处）**: N1 40→41（e5close 审计 P08 + builtins 测试）/ flat 62→63（`n1_core_and_module_flats_closed` + `ktf_read_line_sig_tests::p07`）/ 授权面 114→115（`removed_names_closed_and_modern_registered` + `stdlib_modules_closed_and_qualified_registered`）/ 零授权面 102→103（57 base + 46 非 io 限定名）/ BUILTIN_SIGS 63 注记 ×3 处。
- **D6（测试电池）**: `ktf_percent_operator_tests` 32 case[8 正 + 24 负 1:3]——E2E 绑定闭合 + 优先级/结合律（左结合实证）+ 有符号操作数语义族（截断余数）+ 别名值等价 + 双 Reader 正典渲染/错误面字节级 parity + 同核心形 `(% 7 2)` 机器锚 + check 跨阶段消费 + 语料迁移复锚（is_even + D42 do→块同构双形等值）+ 负例 7 类错误覆盖（E0001×7 形态 / E0004×7 域错 / E0022×4 / E0005×3 / E0006 / E0014 / Read parity 面）。
- **D7（8 原语不变性第四十一轮）**: 零新原语、零通道、零 IR/操作码、零 expander/compiler/VM 机制变更——`%` 为**内建函数注册**（r138 vector 五内建族同型先例：N1 面扩容 ≠ 原语增量）；Stx `(% a b)` 在 Reader 双侧自切换窗起即已产生（本窗补的是消费者，非语法）。
- **D8（治理八件）**: 02-syntax-model v7.27（实施状态注记）+ 20-surface-conventions v1.38（§14 运算符行）+ 18-terminology（mod ↔ % 别名条目）+ matrix r159 行 + RELEASE r159 节 + t3plus v1.79 消费注记 + TD-036 登记 + 本单源。

## §3 域外表（登记态——零信号不开窗，原则 38/44）

| 域外项 | 现状 | 触发条件 |
|--------|------|---------|
| 位运算 `\| ^ & << >>` 中缀 | EBNF Level 0 ○ 行（词法未收 `^`/`<<`/`>>`；`\|` Token 已存在但仅 match or 模式位消费） | 用户指令或语料信号（位运算需求——需内建族 + Fold 扩展，r138 同型） |
| `..` 区间 / `as` 转型 / `.` 字段 / `[e]` 索引后缀 / `\|>` 管道 | EBNF Level 0 ○ 行（r157 审计表回填——`[e]` 索引 = vector-ref 现代面对应物） | 同上（type_decl/struct 前置依赖面各异） |
| **元组表达式形 `(a, b)`（pair 构造现代面）** | match 模式位 `(a, b)` 可解构 pair 而表达式位无构造形（仅 `cons(a, b)` 调用形）——**构造/解构对称缺口**；EBNF Level 0 无 tuple_expr 产生式（实施需 EBNF 增补 + K 候选复审——r158 闭包复审同型流程） | 用户指令直接开窗（数据结构面现代化）或语料信号 → **TD-036** |
| cons/list 用户面语料用量 | 数据语义合法（pair = 一等值类型 + 内核聚合基座）；现代主数据结构 = vector（r138 五内建 + 字面量） | 愿景登记态（原则 38）——零强制迁移义务 |

## §4 验收（GATE 1 实录）

- 六命令 clean 起步全绿：build 19.50s 零告警 + check 0:0 + fmt --all 0 diff + clippy --workspace --all-targets -D warnings 0 + **test --release --workspace 1852:0:0**（1820 基线 + 净 32——RUST_MIN_STACK=33554432）
- 审计×6 真实 EXIT 0（stage0/1/2×2/3×2——含 e5close P08 计数锚 41 同轮更新）
- CLI 零回归探针：fib.ktf ⇒ 144 / closures.ktf ⇒ 42 / higher_order.ktf ⇒ `(1 4 9 16 25)` / vector.ktf ⇒ 9（迁移后输出逐字节保持）
- 新面 E2E：`7 % 2` ⇒ 1（rc=0——r158 基线下为 E0022 rc=1）；native PoC：`8 % 3` ⇒ exit 2 同 `mod(8, 3)`
- 双 HM 面正负探针：check `n % 2` 诊断零 + `"a" % 2` E0005 静态问题浮出

# 相等域窗设计单源（TD-037 清偿——`==` 扩域至 eq 语义 + eq 值律结构化分层）

> **Author**: kerf-dev-agent（Super Z main — ARCH-A 裁定 + DEV-A 实施 + QA-A 验收）
> **Date**: 2026-11-25（r162 / 233）
> **窗性质**: 目标语言表面域重指向 + 值相等律现代化（one face, one name 轨迹第九步：相等域面）
> **开窗依据**: TD-037 触发条件①用户指令裁定——用户明示「eq（等运算符问题，**应当使用现代设计理念**）」对三选一行权（A：`==` 扩域至 eq 语义）；M1 指令开窗第六十七例（r74 先例锚——指南 §4 响应契约「指令即触发」）
> **状态**: Closed（r162 / 233-e 收口——D1-D10 全兑付 + GATE 1 实录回填 §5）

---

## §1 背景与缺口（TD-037 登记本体）

- **登记面**（r161 / 231-b-audit 附带发现）：`==`/`!=` 现代中缀形脱糖至 `(= a b)`/`(not (= a b))`——`=` 值域 = num_or_all_str（`true == true` ⇒ E0004 运行时 / E0005 静态双实锤）；跨值域相等仅有 S-expr 调用形 `eq`。跨值域相等**无现代中缀面**——表达力缺口非正确性缺陷（P3 触发式）。
- **前置探针**（本窗 233-a）：`eq((), ())` ⇒ true；`eq((1, 2), (1, 2))` ⇒ **false**（Pair 同一性律——GcRef 槽位相等）；`eq(true, 1)` ⇒ false。`kerf check` 前置态：`true == true` ⇒ **E0005 静态**（`=` sig NumOrAllStr 域）。
- **编译路径实证**：`==` 与 `eq` 调用形俱走内建 CallGlobal（check 统计面全同 1 proto / 3 consts / 2 globals / 9 instructions）；ANF 后端 `"="`/`"eq"` 俱映射 `APrim::Eq`（anf.rs:144/150）；VM 内联 `Op::Eq`（vm.rs:1194-1198，种子 IR 路径消费）。

## §2 设计裁定 D1-D10

- **D1（皮肤映射域重指向）**：`a == b` → `(eq a b)`；`a != b` → `(not (eq a b))`。双 Reader 单点换目标（Rust parse_comparison `Tk::Eq` 臂符号 `"="`→`"eq"`；种子 reader.ktf `cmp_make(lhs, after, "=")`→`"eq"` + `!=` 臂 `nd_sym("=", …)`→`nd_sym("eq", …)`）。既有第十五/十六映射行族不变——本窗是**既有映射的域重指向**非新增映射行。`<`/`>`/`<=`/`>=` 维持 ordering 域（Num/Str 全序——TD-011 r24 律不动）。
- **D2（`=` 内核基座维持——休眠态申报）**：`=` 注册 + num_or_all_str 域 + E0004/E0005 诊断面**零变更**（r102 命名谱系维持）。诚实边界：裸 `=` 词法为 Tk::Assign——现代面**不可直书调用形**；r162 后 `==` 皮肤换目标 ⇒ `=` 用户可达路径归零（休眠内核基座——ordering 族 `< > <= >=` 为其活跃兄弟，中缀面维持 num/str 全序域）。退役处置 = 未来移除轮窗（r42 型 E0020 纪律）——本窗零行动。
- **D3（eq 值律结构化分层——现代设计理念裁决）**：用户面相等律 = **结构值相等**（immediate 域值相等 + Pair/Vector 递归结构相等）；**procedural 值**（Closure/Builtin/Continuation/External）维持**同一性**（eq? 律——函数按结构比较无意义）；**混合域** ⇒ false（静默——`1 == "1"` ⇒ false；Python/JS 先例；诚实边界：跨域诊断退役与静默 false 是同一条裁定）。
- **D4（structural_eq 单源重构）**：`Value::eq_value` 保留为值层基底（immediate 结构 + 引用同一性——内部消费 + 4 处历史测试直引零扰动）；新增 `kerf_vm::structural_eq(a, b, heap)` 用户面单源；**消费面五处切换**：eq 内建 / assert-eq / member / assoc / VM `Op::Eq`。Pair spine **迭代走尾**（长表无深栈——分支位仅 head/元素递归）；Vector 元素位迭代。**无环不变量**：不可变构造（无 set-car!/槽位突变原语）⟹ Pair/Vector DAG 无环 ⟹ structural_eq 全域终止（Closure 同一性臂天然切断经闭包的潜在环）。
- **D5（r138 eq? 律修订——登记法变更）**：Pair/Vector per-instance identity → **值相等**。理由四联：①用户「现代设计理念」指令 ②混血不连贯（`eq("a","a")` 结构真 vs `eq((1,2),(1,2))` 同一性假——不可辩护）③不可变性使结构相等健全（Python 元组/Rust derive 先例）④种子 `is_const_eq` 手工绕路证据（compiler.ktf:417 注释自证「eq on pairs is reference equality — const nodes need field-by-field recursive comparison」——语言自身需要结构相等却要求用户手工实现）。r138 D3 锚（neg23 `eq(vector(), vector())` ⇒ false）翻转 ⇒ **true**（本窗法修订——vector-value-design.md 增补注记回写）。
- **D6（check/HM 面）**：eq sig 既有（`fixed(&[Any, Any], Bool)`）——**零注册链增量**。`==` 位静态域诊断退役（`true == true` 从 E0005 → check 通过——与运行时真值一致）；ordering 族静态诊断维持（`true < false` ⇒ E0005 不变）。
- **D7（bootstrap 影响审计——§20.3 全量）**：种子源 eq 用点俱**即时域**（符号/整数/串——is_const_eq 叶域分派 + test_runner kind 比较 + check.ktf sig 查询）；结构扩展对种子路径零扰动（bootstrap-cmp 管线经全量测试族验证）；is_const_eq 行为零变化（叶域 eq 俱 immediate）。
- **D8（as-if-written 契约）**：`1 == 2` 与 `eq(1, 2)` 产出**字节码全等**（同一 CallGlobal 内建路径）；Stx 合成 Span = 运算符 Token 本位（既有契约维持）；双 Reader Stx parity ×2 形（`==`/`!=`）。
- **D9（语料零迁移）**：6 个 `==` 语料用点俱数值域（vector/higher_order/match/gc_stress ×2/effect_stress——行级复核在案）；`!=` 语料零用点；行为 parity 逐字节（eq Int/Str immediate 臂与 `=` 同结果）。
- **D10（D4 诚实边界申报）**：member/assoc 元素/键匹配继承结构律（**更宽松**——结构等价元素可寻获；即时域行为零变化）；深左嵌套结构（非 spine 形）递归深度受栈约束（spine 迭代已缓解常见形——长表比较栈安全）；混血域静默 false（D3 裁定本体——跨域语义错误不再诊断，语言面与 Python/JS 对齐）。

## §3 实施面清单

| 面 | 文件 | 变更 |
|---|---|---|
| Rust Reader | crates/kerf-reader/src/reader.rs | parse_comparison `Tk::Eq` 臂 `"="`→`"eq"`；`!=` 臂 sym_at `"="`→`"eq"`；注释同步 |
| 种子 Reader | crates/kerf-driver/src/bootstrap/reader.ktf | parse_comparison `cmp_make(lhs, after, "=")`→`"eq"`；cmp_make `!=` 臂 `nd_sym("=",…)`→`nd_sym("eq",…)`；两处注释同步 |
| VM 值层 | crates/kerf-vm/src/vm.rs | 新增 `pub fn structural_eq`（spine 迭代 + Vector 元素迭代 + 叶域 eq_value 委托）；`Op::Eq` 臂切换 |
| 内建面 | crates/kerf-driver/src/builtins.rs | eq / assert-eq / member / assoc 四处 eq_value → structural_eq |
| 法修订锚 | tests/v0/stage3/plan/ktf_vector_value_tests.rs | neg23 锚翻转（identity → 值相等法注记） |
| 测试门 | tests/v0/stage3/plan/ktf_equality_domain_tests.rs | 32 case（8 正 + 24 负 1:3）+ runner.rs 注册 |

## §4 测试门构成（GATE 5/6 对照）

- **8 正**：`true == true`（TD-037 开窗句）/ `false == true` / `() == ()` / `(1, 2) == (1, 2)`（新律）/ 嵌套 pair / num 域回归 ×2 / str 域回归 / `!=` 面 / 自同一 `p == p` / vector 字面量 `==`（新律）/ const 互作（r161 跨阶段消费）
- **24 负**：E0001 族（parse 缺操作数 ×2 + r161 边界 ×4{assign 拒收/const mut/单绑定/块位域外}）/ E0002 族（eq 调用形元数 ×2）/ E0004 族（ordering 族同路径审计 ×2 + `=` 调用形域维持 ×2）/ E0005 族（check 静态域 ×2{ordering 维持 + `=` 维持}）/ E0006 族（能力门）/ E0022 族（未绑定引用）/ 混合域静默 false ×3{`1 == "1"` / `true == 1` / `eq(true, 1)`}/ 闭包同一性 ×2（自同一真 + 异闭包假）/ Stx parity 负形 ×2（双 Reader `==`/`!=` 锚定）/ member 结构律边界
- **7 类错误覆盖**：E0001 / E0002 / E0004 / E0005 / E0006 / E0022 / E0012+ ≥6 类；**上轮（r161）修复边界 ≥5**：const 四诊断 + const-eq 跨阶段消费
- **集成 ≥3**：run E2E / check E2E / as-is-written 字节码全等 / 双 Reader parity

## §5 GATE 1 实录（回填位）

- 六命令 clean 起步全绿：build 零告警（10.16s 增量）/ check 0:0 / fmt 0 diff / clippy -D warnings 0（doc_lazy_continuation ×1 当场清偿）/ **test --release --workspace 1948:0:0 净 +32**（RUST_MIN_STACK=33554432）/ 审计复跑全绿
- CLI 零回归七探针：fib ⇒144 / closures ⇒42 / higher_order ⇒(1 4 9 16 25) / vector ⇒9 / match ⇒fib-13 / gc_stress(const) ⇒5 / check 2/9/5/38——与 r161 基线逐字节一致
- 新面 E2E：`true == true` ⇒ true / `(1, 2) == (1, 2)` ⇒ true / `1 == "1"` ⇒ false / `() == ()` ⇒ true / `"a" == "a"` ⇒ true / `1 != 2` ⇒ true / check 面翻转（`true == true` ⇒ ok——r161 基线下 E0005）/ ordering 维持（`true < false` ⇒ E0005）
- 增长签名锚：reader.ktf payload 215 protos / 504 consts / 246 globals（`=` 符号末二引用退役 → global_refs −1——单锚失败定位三值迭代法）
- 内循环轮次：2（①九处法修订涟漪期望落定{neg23 锚翻转 + d2 结构真 + stdlib assert-eq 同构真 + comparison == 行退役 ×2 + r3 静态行翻转 + hm superset 行替换 + form render eq} + ②新门 as-if-written 助手遍历修正两轮{let 包裹形 → 裸表达式语句 + 一元中间层长度断言}）
- 法修订涟漪清单（九处全数定性为 D3/D5 律翻转——零真回归）：hm_inference superset R3 行 / ktf_vector neg23 / negative_semantics d2 / negative_vm comparison + symbol_misuse / stdlib comparison_chain + eq_boundaries / test_runner form render / typecheck r3

# 嵌套块内 resume 文法清偿设计（r128 登记域外清偿——handler 表面收尾件）

> **Author**: kerf-dev-agent（Super Z main — ARCH-A 裁定 + DEV-A 实施；r133 / 203-c1 设计先行腿）
> **Date**: 2026-11-07
> **Version**: v1.0
> **Status**: Active（设计单源——本文件 §2 为 02-syntax-model §8.13.1a v7.18 resume_stmt 作用域注记的规范锚；Reader 解析域开放以本文件定稿域边界为据）
> **处理程度**: P0（本窗交付 = 双侧 Reader 嵌套穿线 + 32 case 门 + 语料对 + 文法登记）
> **开窗依据**: 用户 r133 指令①「继续推进 目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施」行权（**M1 指令开窗第三十八例**——r74 先例锚「指令即触发」）；**成熟度匹配排序首位**（原则 26——r131 三部曲检验：①S-expr 面语义全既有[词法作用域内 resume 合法——零语义扩展] ②driver/expander/compiler 消费形零变更[resume Stx 形与 κ 绑定既有] ③EBNF handler_stmt 族在位[小增补]；对照 use 成员重命名 D3 需 S-expr 语义扩展窗先行、TD-033 需语义变更——本窗为唯一纯皮肤 parity 缺口）；恢复轮前置（203-a/203-b——第六次 z.ai web 保存机制回退，r132 tarball 单源恢复 + 1526:0:0 逐位复验后行权）

---

## 1. 问题陈述

**目标面表达力 parity 缺口**（r128 登记域外的清偿实施——02 §8.13.1a v7.17 resume_stmt 作用域注记 + target.rs parse_handler_block 文档注 + target_reader.krf 同注三处单源登记）：

| resume 位置 | S-expr 面 | 目标面（r132 态） | 缺口 |
|---|---|---|---|
| 臂体直位 `=> resume(v)` | `(resume k v)` | ✅ r128 在位 | — |
| 臂块体顶层语句/尾位 | `(do A (resume k v))` | ✅ r128 在位 | — |
| **嵌套块语句/尾位**（if 臂块/闭包体/嵌套 handle 臂体） | ✅ 词法作用域内合法 | **E0001 fail-closed** | ❌ 本窗清偿 |

**探针实证三件（判据先于先例——r131 先例形态）**：
1. **P1 if 臂**：`.krf` 面 `(handle gift ((p k) (if (> (head p) 5) (resume k 100) (resume k 200))) (ask))` → **⇒ 101** 合法；`.ktf` 面 `gift(p, k) => { if head(p) > 5 { resume(100) } else { resume(200) } }` → `[read] error[E0001]: 期望表达式，实际 KwResume`（嵌套 if 臂块内）——缺口机器实证。
2. **P2 闭包捕获**：`.krf` 面 `((fn (n) (resume k n)) (head p))` → **⇒ 11** 合法（闭包词法捕获 κ）。
3. **P3 既有边界维持**：普通块（非 handler 作用域）内 resume → E0001 既有错误路径（r128 注记「普通块无处理器作用域」）——本窗不得扰动。

**核心设计事实**：resume 的 Stx 形 `(resume k expr)` 与 κ 绑定注入机制 **全既有**（r128 奠定——本窗 = 穿线域扩展，零脱糖零新原语零 driver 变更——原则 31 皮肤/骨架同构；8 原语不变性第十五轮验证锚）。

## 2. 裁定表（D1-D10）

### D1：开放域（核心裁定）

**裁定**：嵌套块**语句位/尾位**开放 resume 受理——沿 r128「语句位（后随 `;`）与尾位（后随 `}`）同形」纪律原样延拓至嵌套块：

| 嵌套位形 | 表面例 | Stx（κ 注入） |
|---|---|---|
| if 臂块（then/else/else-if 链） | `if c { resume(1); } else { resume(2) }` | `(if c' (do (resume k 1) nil) (do (resume k 2) nil))` |
| 闭包体块 | `let f = \|\| (n) { resume(n); };` | `(fn (n) (do (resume k n) nil))` |
| 嵌套 handle 臂体 | `handle e { A(q, k2) => { resume(v); } }`（外臂块内语句） | 内臂 κ2 注入（D3） |
| match 臂内 if_expr 块 | `match x { 1 => if c { resume(1) } else { 2 }, }` | 经 primary if_expr 块穿线 |

**非开放位形维持域外**（D6/D7/D8）。

### D2：κ 注入域 = innermost enclosing handler arm

**裁定**：`resume(expr)` 的 κ 恒注入**词法最近包裹 handler 臂**的绑定（S-expr 词法作用域镜像）。实施形态双侧同构 save/restore 纪律：
- **种子**（target.rs）：parser 字段 `handler_k: Option<(String, Span)>`——parse_handle 入口 save/take、protected 解析期置 None（D5）、每臂解析前置本臂 κ、闭 `}` 后 restore；
- **镜像**（target_reader.krf）：`kcell` 闭包胞（let 可变捕获——closures.krf 惯用法；全局 assign 不在 N3 消解面故用胞）——parse-handle 同构 save/restore；block-loop 的 resume 分派读胞。

**块解析统一性**：parse_block_inner（种子）/block-loop（镜像）的 resume 分派从「参数穿线（仅 handler 块顶层）」改为「作用域态穿线（本臂块 + 全部嵌套块）」——普通块态恒 nil → E0001 既有路径不变（P3 守护）。

### D3：嵌套 handle 遮蔽（shadow-aware）

**裁定**：嵌套 handle 语句在（外）臂块内解析时，其**自身臂体**建立自己的 κ（内臂 κ 在内臂体内遮蔽外臂 κ——同名绑定时内者胜，S-expr 词法遮蔽同构）；内 handle 语句完成后**恢复外 κ**（后续语句/尾位续用外 κ）。save/restore 对称纪律由 D2 实施形态承载。

### D4：闭包捕获开放

**裁定**：闭包体块穿线 κ（S-expr 面闭包词法捕获合法——探针 P2 ⇒ 11 实证）。**运行时语义零变更**：晚调用（resume 于 κ 失活后）= 既有 VM 语义（one-shot 纪律——皮肤映射不触碰运行时判定）。

### D5：嵌套 handle 保护表达式收窄（诚实边界）

**裁定**：嵌套 handle 的 protected 表达式以 κ=nil 解析——其内 if 臂块等嵌套块 resume = **域外 fail-closed 维持**。依据：①S-expr 面词法可写但属语义边陲（于 handle 帧建立前恢复外层续体——合法但边陲）；②收窄 bounded 穿线面；③触发式后续信号登记（显式续体形态设计窗联动——与 D7 同族）。

### D6：表达式位维持域外

**裁定**：resume 仍**仅块语句位/尾位**受理——实参位（`f(resume(1))`）/条件位（`if resume(1) > 2`）/let 值位/守卫位/宏实参位 = E0001 fail-closed 维持（r128 纪律原样；S-expr 面表达式位合法 = 既有收窄诚实边界延续，触发式后续信号）。

### D7：跨臂显式 continuation 引用收窄（诚实边界）

**裁定**：目标面隐式注入恒 innermost κ——「内臂 resume 外臂 κ」形（S-expr 面 `(resume k ...)` 显式命名可写）**不可表达**。登记域外触发式（显式 continuation 形态设计窗信号——`resume k2(...)` 类形）。

### D8：halt/pass 位形维持

**裁定**：halt/halt(v)/pass = **臂体直位形态维持**（r132 D5/D4）——嵌套块内 halt/pass = E0001 维持。依据：S-expr 面无「嵌套 halt」概念（臂体即值形）——零 parity 缺口。

### D9：死代码纪律延拓

**裁定**：嵌套块内 resume 语句后的语句 = 死代码（r128 `(do (resume k v) dead)` 同构延拓——一次性 resume 语义既有）。

### D10：测试与验收

**32 case 门**（8 正 + 24 负 = 1:3——§9.4.3 正负比）：正向 = if 臂两分支/else-if 链/闭包捕获/嵌套 handle 双 κ/语句位死尾/let 后 resume 深形 + **E2E 语料对值 parity（⇒ 540 双面）**；负向 = 表达式位族（实参/条件/let 值/守卫/宏实参）+ 普通块/顶层/闭包（非 handler 域）+ D5 保护表达式 + D8 halt/pass 嵌套位 + 形态错误族（缺括号/未闭合/零参/多元）——**双 Reader 错误面消息+Span 字节级 parity**；**嵌套等价字节码全等门**（共享符号表——.ktf 嵌套形 ↔ .krf 手写形 compile 产物全等——皮肤透明性证明，r132 门同构）。验收 = 1526→1558 净 +32 + §3.2 六命令 clean 起步全绿 + 审计×6 + CLI 双语法面零回归。

## 3. 实施面（双侧 Reader 同构）

| 件 | 变更 | 量级 |
|---|---|---|
| 种子 `crates/kerf-reader/src/target.rs` | `handler_k` 字段 + parse_handle save/restore + parse_block_inner 态穿线 + parse_handler_body 参数源字段 | ~60 行 |
| 镜像 `crates/kerf-driver/src/bootstrap/target_reader.krf` | `kcell-pair/kset/kget` 胞三定义 + block-loop 读胞 + parse-handle save/restore | ~50 行 |
| 02 §8.13.1a | resume_stmt 作用域注记更新 + r133 域外注记翻转（v7.18） | 注记级 |
| 20 §14 | D2 handle 映射体域扩展 r133 注记 | 注记级 |
| 语料 `examples/usage/effect_nested_resume.{krf,ktf}` | r1-r5 五形态 + 顶层和（⇒ 540） | 新 pair |
| 测试 `tests/v0/stage3/plan/ktf_nested_resume_tests.rs` + runner 接线 | 32 case 门 | 新文件 |

## 4. 语料设计（r1-r5——目标面可表达形约束下的双面等值）

| 件 | 形态 | 值 |
|---|---|---|
| r1 | if 臂两分支 resume（`> (head p) 5` 选支） | 100 |
| r2 | 闭包捕获 resume 立即调用 | 10 |
| r3 | 嵌套 handle 双 κ（内臂 κ2 resume 11 语句值废弃 + 外臂 κ resume 110） | 110 |
| r4 | if 嵌 if 深形（两支命中） | 300 |
| r5 | if 臂内 let 后 resume（allocate-then-resume 深化——r128 惯用法延拓） | 20 |

顶层 `(+ (+ (+ r1 r2) (+ r3 r4)) r5)` → **⇒ 540**（双面逐位一致；.krf 手写形以嵌套等价字节码全等门校准）。

## 5. 验收

- GATE 1：§3.2 六命令 clean 起步全绿 + **test 1558:0:0 净 +32** + 审计×6 280 case EXIT 0 + CLI 双语法面零回归（含语料对 ⇒ 540 双面）+ bench OBS-C 带内；
- 双 Reader 正典渲染/错误面字节级 parity（32 case 内逐门）；
- 域外注记翻转三处单源一致（02 §8.13.1a + 种子文档注 + 镜像文档注）；
- 治理链：t3plus v1.53 + matrix r133 行 + RELEASE r133 节 + README + rec 95 + 根层 l + worklog 三链。

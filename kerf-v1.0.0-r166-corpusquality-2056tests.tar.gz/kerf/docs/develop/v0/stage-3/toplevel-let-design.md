# 顶层 let 现代化窗（define 调用形退役）设计单源 v1.0

> **窗编号**：r158 / 228 族（228-a..228-e）
> **窗性质**：目标语言表面语法现代化（one face, one name 轨迹第五步：目标面 `define(NAME, e);` S-expr 旧形退役）
> **开窗依据**：M1 指令开窗——用户明示「如 define 这在目标语言中不应该使用和出现吧？他就是 S 表达式旧时代的内容」+ 闭包 EBNF 复审指令
> **状态**：Closed（r158 / 228-e 收口——D1-D10 全兑付：toplevel_let 产生式 + 双 Reader 项位拒收{含 Unit 前瞻零参形——define_misuse 失败驱动增补} + 语料迁移 512 处 + 32 case 门 + 存量锚重校准 20 族 + 治理八件 + K-1 闭包复审维持裁定；payload 形状锚 210/491/241 重校准；E0005 电池 = BAD+head() 双诊断模式对齐；域外表五条维持{块位 define 普通调用语义 + 顶层 do-拼接合法[expander 拼接域]}）

---

## 1. 问题陈述（228-a 深扫结论）

**现状**：`.ktf` 目标面顶层值绑定唯一形态 = `define(NAME, e);` **调用形**——
经统一 list 结构直接合成 S-expr 核心形 `(define NAME e)`（词法上 `define` 是
普通 Ident，非目标面关键字；Reader 无专用产生式，靠「标识符 + 调用括号」的
list 同构偷渡到核心形）。这是 S-expr 旧时代习惯在目标表面的存活：

- 目标面有专用 `fn` 声明形，却**没有**专用顶层值绑定形——不对称缺口
- `define(...)` 形态上像函数调用，语义上却是绑定声明——形/义错配（违反
  「one face, one name」：`define` 是 S-expr 面的名字，不该在目标面出现）
- 与 r43（lambda→fn / set!→assign / begin→do）、r156（术语现代化）、r157
  （设计文档残留清偿）同一轨迹的第四面收口后残项

**全域清单（228-a 实测）**：

| 域 | 文件数 | 出现次数 |
|---|---|---|
| bootstrap 自举链 .ktf | 7（compiler 67 / expander 31 / check 20 / reader 12 / test 2 / cache 2 / build 2） | 136 |
| examples/usage .ktf | 4（closures 4 / macros 2 / gc_stress 2 / gc_stress_nontail 1） | 9 |
| tests/ .rs 内嵌源串 | 42 | 362 |
| web playground 预设（src/lib/kerf-data.ts） | 1 | ~5 |

**对照（不受影响域）**：`.krf` S-expr 面 `(define NAME e)` = 自举/parity 面
原生形，**维持不动**（01-core-forms `Define` 核心原语合法；S-expr 面 define
是其本名）；`fn` 声明 → `(define (f x) body)` 翻译 = 内部核心形，合法维持。

## 2. 裁定 D1-D10

### D1 顶层 let 产生式（新形态）

```ebnf
toplevel_let  ::= "let" [ "mut" ] identifier [ ":" type ] "=" expr ";" ;
                  (* 顶层/模块项位 → Stx (define identifier expr') ——
                     类型标注解析后剥离（fn_decl 先例：核心无类型消费面） *)
```

- 单绑定**封顶**（逗号多绑定 → fail-closed 专用诊断「top-level let takes a
  single binding」）——与被退役的 `define(NAME, e);` 单绑定能力**逐位等价**，
  零能力增减（能力等价 = 退役判据 R5「自建替代 ≥ 被替换物 × 98%」满足）
- 项位受理域 = 顶层 + module 项位（与 fn/import/export/require 同族对称——
  parse_item 统一分发，S-expr 面 module 体内 `(define ...)` 同构）
- `mut` 修饰符解析后剥离（block 级 let_stmt 先例——顶层可变性语义由
  assign 语句面承载，核心无 mut 消费）

### D2 define 调用形退役（拒收面）

- **项位** `Ident("define") + "("` 前瞻 → fail-closed 现代化诊断：
  `"the define call form is retired: use a top-level let binding (let name = value;) instead"`
  （Span = `define` 标识符 Token 本位——r130 import-as 诊断先例）
- **块位/表达式位** `define(...)` = 普通调用（未绑定标识符 → 既有 E0022
  语义面）——**域外维持**，零新拒收（诚实边界：只退役项位声明用法）
- `define` **不入**目标面关键字域（E0020 共享保留域零扰动——S-expr 面关键字
  25 名维持；目标面词法维持 Ident 身份）
- 理由：项位是声明用法（形/义错配发生地）；块位是表达式用法（普通调用
  语义自洽）。退役精度 = 只治错配，不扩大禁令面

### D3 双 Reader 锁步（parity 纪律）

- Rust 种子侧（reader.rs parse_item）+ bootstrap 镜像侧（reader.ktf
  parse_item）**同窗同步**：顶层 let 臂 + define 项位拒收臂
- 诊断消息**字节级一致**（双 Reader 错误面 parity 门既有纪律）
- fixpoint 自洽序：reader.rs 先支持 let → bootstrap .ktf 全量迁移 →
  reader.ktf（自身已迁移）解析其余 bootstrap 文件——同 commit 原子兑现

### D4 语料迁移（R4 工具纪律）

迁移工具 `scripts/r158-toplevel-let/`（r139-english-surface 先例模式）：
`define(NAME, VALUE);` → `let NAME = VALUE;`——**括号配对算法**（非正则
前缀替换：define 调用形尾 `)` 必须移除，多行值域必须配对）。

迁移域 = bootstrap 7 文件 + examples 4 文件 + tests 42 文件内嵌源串 +
web kerf-data.ts 预设。**注释/诊断断言内提及**（如 capability_tests.rs:257
注释描述）随同迁移（描述对象同一）。

### D5 语义零变更（原则 31 皮肤/骨架同构）

- `let NAME = VALUE;`（项位）→ Stx `(define NAME VALUE')` 与旧
  `define(NAME, VALUE);` → Stx `(define NAME VALUE')` **逐字节同构**
- expander / compiler / HM / VM **全链零触碰**（8 原语不变性第四十轮）
- 运行输出逐字节不变（closures.ktf ⇒ 42 等语料 E2E 复锚）

### D6 闭包 EBNF 复审裁定（用户指令②——审查结论）

现行 `closure_expr ::= [ "move" ] "||" [ "(" [ params ] ")" ]
[ "->" effect_union ] block`——**维持裁定**（K-1）：

| 候选形 | 例 | 判定 | 依据 |
|---|---|---|---|
| **现行**（`\|\| (params) -> eff { body }`） | `\|\| (x: i64) { x + n }` | ✅ 保留 | 见下四判据 |
| Rust 单竖线（`\|x\| body`） | `\|x\| x + n` | 否决 | 竖线与位或 `\|` 词法冲突（目标面 bitor_expr 既有 `\|`）——需词法上下文消歧 = 复杂度转移非消除 |
| JS 箭头（`(x) => body`） | `(x) => x + n` | 否决 | `=>` 与 match 臂 `=>` Token 冲突（match_arm 既有）；参数位裸 `(x)` 与调用形/元组形三重歧义 |
| Swift in 形（`{ x in body }`） | `{ x in x + n }` | 否决 | 裸块 `{...}` 与 struct_lit/块语句位形冲突；嵌套闭包内层界分不明 |

现行形四判据：①**零关键字**（`||` 纯词法前缀，E0020 零占用）②**fn_decl
同构**（params → effects → block 三段与函数声明形一致——一族两形学习成本
最小）③**r157/227-b3 E-3 逐位一致实证**（实现-文档零漂移）+ E-2 move 任意
unary 位受理（比产生式更宽松——不破坏所述形态）④32 case 门 +
`closures.ktf` 双面语料 E2E 成熟。**结论：形式不繁杂——四可选层
（move/params/effects/block）各承独立语义（捕获/参数/效应签名/体），
无可削减层；语义清晰度由 fn_decl 同构保证。零变更，登记复审结论即兑付。**

### D7 测试电池（GATE 5/6 构成）

新增 `tests/v0/stage3/plan/ktf_toplevel_let_tests.rs`（32 case = 8 正 +
24 负 1:3，先例 ktf_*_tests 族同构）：

- 正向 8：单绑定顶层 let E2E / module 项位 / 类型标注剥离 / mut 剥离 /
  复杂值表达式 / 双 Reader 正典渲染字节级 parity / 与旧形同 Stx 断言 /
  closures 语料迁移复锚
- 负向 24：define 项位拒收（消息+Span 断言 × 双 Reader parity）/ 多绑定
  逗号 fail-closed / 缺 `=` / 缺名 / 缺 `;` / 非法类型标注 / define 块位
  E0022 域外维持 / define 尾随垃圾 / 7 类错误覆盖（E0001 词法 / E0002
  展开 / E0006 能力 / E0017 模块 / E0022 未绑定 / E0019 多段路径 /
  恢复多错误 E0005）
- 集成 ≥3：正向 ≥1（closures.ktf E2E ⇒ 42）/ 负向 ≥3（define 拒收 ×3
  路径：run/check/test）/ 跨阶段消费 ≥1（HM check 跨阶段零诊断）

### D8 治理回写（§8.5 清单）

02-syntax-model.md（§8.13.1a 增补 toplevel_let 产生式 + §8.12 D2 映射表
define 行更新 + v7.26 头行）/ 20-surface-conventions.md（皮肤字典
define→fn 行分裂为 fn 声明行 + 顶层值绑定 let→define 行 + 版本头）/ 
matrix r158 行 / RELEASE r158 节 / t3plus v1.78 / 18-terminology 复核 /
本文件 Status: Closed。

### D9 web 同步（用户指令④）

kerf-data.ts 预设迁移 + Playground E2E 复锚（closures 预设 ⇒ 42）+
ROADMAP/HERO_FEATURES/PACKAGE_CONTENTS r158 行前插 + 版本徽章/时间线
（r156-r157 五件前插纪律沿用）。

### D10 打包（§19 三验）

`kerf-v1.0.0-r158-toplevellet-1788tests+32.tar.gz`（名按实测 test 数）——
成员/字节/sha256 + 独立解包净构建 + 包内 test 复跑三验。

## 3. 不变量五条

1. 8 原语不变性第四十轮（expander/compiler/HM/VM 零触碰）
2. E0020 共享关键字域零扰动（目标面零新关键字——`let` 既有）
3. Stx 核心形 `(define name value)` 零变更（皮肤换、骨架不变——原则 31）
4. `.krf` S-expr 面 define 原生形维持（自举/parity 面本名）
5. 双 Reader 正典渲染/错误面字节级 parity 维持

## 4. 域外表（§7 纪律）

| 项 | 处置 |
|---|---|
| 块位 `define(...)` 调用 | 域外维持（普通调用 E0022 语义） |
| 顶层 let 多绑定 | 域外 fail-closed（单绑定封顶——能力等价退役判据） |
| S-expr 面 `(define ...)` | 域外维持（自举面本名） |
| `define-syntax`/`macro` | 零触及（r129 macro 形已是现代形） |
| 闭包 EBNF | 零变更（D6 复审维持裁定 K-1） |

## 5. 收口增补（v1.1）

- **Unit 前瞻增补（D2 修正）**：`define()` 零参形经词法 Unit Token（parse_typed_params 双关先例）——拒收臂前瞻条件扩为 `LParen | Unit`（双侧锁步；define_misuse 失败驱动发现）。
- **E0005 电池对齐（D7 修正）**：恢复模式双诊断 = BAD（块位 define-position E0002）+ `head()`（类型检查 arity E0005）——multi_error_recovery_tests 既有模式对齐。
- **顶层 do-拼接域（D2 边界澄清）**：`do(define(a, 1), a)` 顶层位合法（expander do-拼接将 define 注册于顶层——E6 face 既有语义维持）；函数体位 `fn f() { do(define(a, 1), a) }` = expander 拒收域。电池双锚俱在。
- **路径名 define 能力面（D2 边界注记）**：`define(my::ns, 5)` 路径名接管豁免随调用形退役——.ktf 面不可表达（let 受理裸标识符）；.krf S-expr 面 `(define my::ns 5)` 维持原生能力（能力未从系统消失，仅从目标表面退役）。

# r75 实现状态与完整性审查报告（HM .krf 路径验证 + 构建系统 driver .krf 化）

> **Author**: kerf-dev-agent（QA-A 主体 + ARCH-A 完整性裁定 + DEV-A 推进件——r75 轮）
> **Date**: 2026-09-28
> **Version**: v1.1（**r126 清偿注记**：§5.3 双轴残留诚实边界全吸收——check.krf 项内恢复架构[tc-failv Dynamic 恢复 + tc-record 逐参续行 + define 失败绑定 ∀α]：轴① 项内多错 1→3 = oracle 3 + 轴② 失败 define 吸收 1→2 = oracle 2；「归未来生产切换窗的两阶段架构重构义务」兑现[r126 / 196-b]——两轴边界守卫测试翻转为 parity 守卫{boundary_intra_item_multi_diag_parity + boundary_failed_define_call_absorption_parity}；语料锚 check.krf 1→2 重锚{krf 2 ⊆ oracle 23 方向守卫实证}）；v1.0（r75 / 145-a..145-e 载体）
> **Status**: Active（本轮执行中→收口）
> **上游驱动**: 用户 r75 显式指令「按照 docs/sop.md 流程结合 docs/lang-design/ 下的项目演进流程 与 docs/develop/v0/tech-debt-register.md，继续推进任务（**HM/typecheck .krf 路径验证， 构建系统重写（driver .krf 化）**）**审查实现状态并完整性**」+ 同步完整打包 tar.gz + 同步完整更新 web page

---

## 1. 审查范围与信号纪律裁定

**审查对象**（r74 四窗交付中的两点名面——用户指令显式点名）：
1. HM/typecheck `.krf` 路径验证（r74/144-b：check.krf + bootstrap_check.rs + hm_krf_path_tests）
2. 构建系统重写 driver `.krf` 化（r74/144-d：build.krf + bootstrap_build.rs + 生产切换 + TD-032）

**信号纪律裁定**（23 §2.3 红线 3——本节为推进面的开窗依据回填）：

| 推进候选 | 裁定 | 依据 |
|---|---|---|
| HM 多错误收集深化（PoC 项级恢复） | **开窗执行**（145-e） | r74-window-opening §2「不做」栏登记的多错误收集为 PoC 与生产面的注册差异；用户 r75 显式指令点名「HM/typecheck .krf 路径验证」= r74-window-opening §7「或用户后续指令」的后续指令信号命中——PoC 范围内深化（非生产切换，判定面不动） |
| 构建系统 TD-032 余下面任一切口 | **不开窗**（审查 + 就绪图交付） | TD-032 触发式条款：缓存段 = 增量编译需求信号（且 VM 字节级哈希原语缺位——技术阻塞双成立）；CLI 编排 = 用户工具链指令（本轮指令为构建系统窗口泛指，非工具链专项指令）；测试运行器/入口 = 各自续窗。泛指指令不构成面级信号——红线 3 零信号不推进纪律维持 |
| 生产判定面切换（HM） | **不开窗** | INC8/K3 裁定维持（判定面 = hm_check_program）；默认期切换窗口归 23 §2.2 Stage 3 触发式——零信号 |
| 表面语法切换窗 | **不开窗** | 入口信号 = 用户预告的目标语言设计讨论（r74-window-opening §1 登记）——本轮未发生 |

---

## 2. 全仓基线复验（145-b）——审查的地基证据

**§3.2 六命令 clean 起步全绿**（审查轮起步实测——r74 基线逐位复现）：

| 命令 | 实测 | 结论 |
|---|---|---|
| cargo clean | 805 files / 298.6MiB | ✅ |
| build --release | 16.53s 零告警 | ✅ |
| check | 0 errors 0 warnings | ✅ |
| fmt --check | 0 diff | ✅ |
| clippy --workspace --all-targets -D warnings | 0 | ✅ |
| test --release --workspace | **967:0:0 逐位**（集成 719 + 单元 248——与 r74 零漂移） | ✅ |

**辅助复核全项**：
- 六审计集 280 case EXIT 0 ×6 真实复跑（stage0/stage1/stage2_r1/stage2_r2/stage3_m3/stage3_e5close——尾行 GO 语义维持）
- CLI 四路径：fib 75025/⇒144 + higher_order (1 4 9 16 25) + closures (4 2)/⇒42 + check ok：2 原型/9 常量/5 全局引用/38 指令
- bench 三轮稳态 **71.007/70.948/70.880ms 带内**（<72ms 容差；首轮 73.461ms 为净构建后冷启动噪声——复测三轮证实稳态带内；r73 带 70.9-71.5ms 一致）
- **三语料诊断锚 319/145/193 逐字一致**（expander/compiler/reader——r53 锚第十轮独立复验；本轮三语料零触碰）
- 新语料（r74 后）：check.krf 133 行 / build.krf 37 行 / preamble.krf 1 行——E0005 旗标期策略豁免类（hm-inference-design v0.2.0 §2.3 口径——见 §5.4 策略一致性注记）
- 语料六族 grep 零信号维持：match 用户面 0 / net 族 0 / extern 0 / @ 版本语法 0 / syntax-parse **自举范围 1**（expander.krf:40 TD-005 注记本体——历史口径）+ **全 crates 宽口径 2**（+ macro_sys.rs:4 doc 注记——Stage 0 期 f3e5d7a 注记本体非语言面；两口径均为注记本体零语言面消费） / vector `#(` 0
- git 状态：HEAD 8507d5a（r74 收口）clean + 双源 worklog 镜像 diff 空

---

## 3. HM/typecheck `.krf` 路径验证——实现状态与完整性审查（145-c）

**逐件审查结论**（对照 r74-window-opening §2 设计摘要与 144-b worklog 声明）：

| 审查项 | 设计要求（r74-window-opening §2 / §6） | 实况 | 完整性 |
|---|---|---|---|
| check.krf 迷你 HM 推断机 | 类型格 tvar/tcon{int,float,num,bool,str,nil,sym}/tpair/tfun + 合一（occurs + 数值格互匹 + Dynamic 吸收 + Arrow 元数）+ 格 join + 值限制泛化 + 递归预置 + assign 弱单态化 + var 未命中 Dynamic + if 条件具体非 bool 即时诊断 + builtin 快路径 | 757 行全量在档（文件头契约七节 + 序章 HOF + 全部语义臂实测定位） | ✅ |
| 入口与复位纪律 | lchk-check-program 入口 + 状态复位（compiler.krf 同款） | 入口五全局复位（TC-NEXT/SUB/ENV/DIAG/DIAGS）实测定位 | ✅ |
| wire 协议 | 消费与 compiler.krf 同一 core 节点协议——桥零新协议 | bootstrap_check.rs 经 item_to_node 单源复用（bootstrap_compiler pub(crate) 化） | ✅ |
| 桥形态 | 镜像 bootstrap_compiler.rs——线程局部 + 种子加载 + call_closure | 三件套同构第四实例（验证形态）；R9 fail-closed 空授权加载 | ✅ |
| parity 判据 | ≥14 case accept/reject 双面一致 + 正负比 ≥1:3 | **19 case**（正 4 + 负 12 + 协议 2 + Span 1）——4:12 = 1:3 满足；本轮复跑全绿 | ✅ 超额 |
| 诚实边界（perform/handle） | 子集越界 → 结构化跳过 | Unsupported 协议臂 + 2 守卫测试（`('unsupported kind)` 值通道） | ✅ |
| 非生产切换 | 判定面维持 hm_check_program（INC8/K3） | **生产面不动核验**：hm_check_program 消费 = driver.rs:2431（check_source）+ :2531（compile 路径）——生产判定唯二入口；krf_check_program 消费 = hm_krf_path_tests 唯一（零生产消费） | ✅ |
| 桥单元 | 活性探针 | check_state_lifecycle_probe + empty_program_is_clean（2 case） | ✅ |

**审查结论**：HM `.krf` 路径验证 PoC **实现完整、声明与实况零漂移、生产面纪律完好**。r74 声明的 19 case 与实测逐位一致。

---

## 4. 构建系统重写 driver `.krf` 化——实现状态与完整性审查（145-d）

**逐件审查结论**（对照 r74-window-opening §4 设计摘要与 144-d worklog 声明）：

| 审查项 | 设计要求（r74-window-opening §4 / §6） | 实况 | 完整性 |
|---|---|---|---|
| build.krf 语义移植 | imports_prelude + imports_prelude_module 全语义（顶层 import as 跳两位 + as 末位边界 + module 头部区扫描 + 裸 module 边界） | 131 行全量在档（六头字段协议消费 + 四判定函数 + 头部契约注释） | ✅ |
| 桥形态 | 同 bootstrap_compiler.rs 形态 | bootstrap_build.rs（三件套第五实例·构建段）；stx_to_node 六头字段同型；Bool 结果重建 + 非 Bool fail-closed | ✅ |
| **生产切换** | resolve_prelude_imports 改经 .krf 判定 | driver.rs:2003-2013 实测：seed_pipeline → imports_prelude_seed（Rust oracle）；否则 → bootstrap_build::imports_prelude（VM build.krf）——**切换生效**；双消费点 ：2142（compile_front）+ :2487（check_source_recover 生产口径 false） | ✅ |
| 种子管线豁免条款 | Seed×Seed → Rust oracle（阻断自引用） | driver.rs:1996-2004 条款在档（P1 硬约定同构扩展——RefCell 重入根治） | ✅ |
| Rust 版退役 | 退役为 parity oracle | imports_prelude_seed pub 化 + 桥单元 production_build_is_bootstrap 活性探针 | ✅ |
| parity 判据 | ≥10 case 双面一致 | **14 case**（parity 12 含 as 吞噬边界 + 嵌套 module + 裸 module ×2 + 生产 E2E 双向 2）——本轮复跑全绿 | ✅ 超额 |
| bench 带内 | <72ms 容差 | 稳态 70.88-71.01ms（见 §2） | ✅ |
| TD-032 登记 | 余下面登记 | 登记册 v0.4.5 在档：缓存段（VM 原语缺位 + 增量编译信号）/ CLI 编排（工具链指令信号）/ 测试运行器 / 测试入口 | ✅ |

**审查结论**：构建系统首切口**生产切换真实生效、语义移植完整、parity 守卫齐备、种子豁免条款在档**。r74 声明与实况零漂移。

**TD-032 余下面就绪图**（审查产出——各面切口前置条件与信号状态）：

| 余下面 | 技术前置 | 信号状态（r75 实测） | 就绪度 |
|---|---|---|---|
| 缓存段（cache.rs） | **VM 字节级哈希原语缺位**——需 VM 能力扩展（哈希/字节访问原语族） | 增量编译需求信号零命中 | 阻塞（技术 + 信号双未满足） |
| CLI 编排 | driver 编排流 .krf 表达可行性未验证（IO/参数/退出码面） | 用户工具链指令未发生（本轮泛指 ≠ 专项） | 待信号 |
| 测试运行器 | runner.rs .krf 化切口未设计 | 续窗信号未发生 | 待信号 |
| 测试入口 | 同上 | 同上 | 待信号 |

---

## 5. 推进件实录（145-e——HM 多错误收集 PoC 深化）

### 5.1 设计（项级恢复形态）

**命题**：kerf 语言（VM 上 .krf）能表达**多错误收集的错误恢复控制流**——r74-window-opening §2 注册的「PoC 单错误短路 vs Rust 侧多错误收集」差异的 PoC 粒度收敛。

**Rust 生产面实测**（CLI probe ×9——约束级全量 drain 语义锚）：
- 项间独立错误：双项 2 / 三项 3 / module 体项间 2——全量 drain
- 项内错误：嵌套应用 3 / define 值内 do 双错 2——**约束级同样全量 drain**（两阶段架构固有）

**PoC 形态**（项级恢复——单趟推断下的可达粒度）：
- `check.krf`：新增 `TC-DIAGS` 累积表（新者在前）；tc-fail/tc-failv 双置（TC-DIAG 最近诊断语义维持——七处值位直返点零改动）；`tc-check-items` 项级恢复（诊断中止 → 已入表，继续后续项；kerr/unsupported 硬中止维持）；入口出口三形（零/单/多）——单错误形态保持 r74 `('diag msg s e)`（**原则 27 加性**），多错误新形 `('diags ((msg s e) ...))` 源序（reverse 后）
- `bootstrap_check.rs`：`KrfDiagItem` 结构 + `KrfCheckOutcome::Diags` 新变体 + outcome_from_value "diags" 臂（三元组解析 + fail-closed 字段校验）
- `hm_krf_path_tests.rs`：**+6 case**（计数 parity 4 + 诚实边界守卫 2）

### 5.2 预判失效实录（R4——设计期预判 vs 实测发现）

**预判**：「`(do A B)` 顶层形为单项 → 项内双错 → krf 1 vs Rust 2（边界 case）」。
**实测**：krf 给出 **2**——首跑失败暴露。**根因**：顶层 `do` 为 **module 级 splice**（r49 D59：expander.rs 「do → module 级 splice（项递归分类）」）——`(do e1 e2)` 在核心项层面是**两个项**，双错实为项间独立错误，项级恢复后计数 parity 2=2 达成。
**处置**：预判失效转化为 parity case（multi_parity_toplevel_do_splice——D59 splice 语义与恢复交互的守卫锚）；真实项内边界改用**嵌套应用单例** `(+ (not 5) (+ 1 "s"))` 锚定（Rust 3 / krf 1 实测）。
**教训**：**项粒度预判必须以 expander 项位分类实况为准**（do-splice/宏 trampoline 项递归分类是 D59 的声明语义）——r73「PoC 语料以仓库示例实读为锚」教训的架构面补充：语料形态锚之外还需**项位分类语义锚**。

### 5.3 残留诚实边界（双轴——均归未来生产切换窗）

| 边界轴 | 例证（实测锚） | Rust 面 | 本机面 | 根因 |
|---|---|---|---|---|
| ①项内多错误 | `(+ (not 5) (+ 1 "s"))` | 3 | 1 | 约束级 drain vs 项级首个 |
| ②失败 define 后续引用吸收 | `(define (f x) (+ x "s\"))` + `(f 1 2)` | 2 | 1 | 两阶段调用点约束仍全检查 vs 单趟部分推断（α 未绑定 → tvar 吸收） |

两轴同根：**单趟在线合一 vs 两阶段（生成+求解）架构差**——归未来生产切换窗的两阶段架构重构义务（r74-window-opening §2 「不做」栏继承）。边界作为受守卫测试落档（boundary_intra_item_single_diag + boundary_failed_define_call_absorption——r74 Unsupported 同款「诚实边界守卫」模式）。

**r126 终态注记（清偿）**：双轴残留已于 r126 HM 深化窗全吸收——check.krf 项内恢复架构（tc-failv → Dynamic 恢复型 + tc-record 逐参续行 + tc-check-define 合一失败仍绑定{∀α 泛化 = oracle Poly 可观测}）；轴① 1→3 = oracle 3、轴② 1→2 = oracle 2；两处边界守卫测试翻转为 parity 守卫（boundary_intra_item_multi_diag_parity / boundary_failed_define_call_absorption_parity）。「未来生产切换窗」= r80（判定面切换，架构重构未做）+ r126（架构重构兑现）两段式完成。

### 5.4 策略豁免一致性注记（R1 面）

check.krf 自身语料诊断 127 → 133 行（E0005 计数 21 → 22，git stash 对照实证净 +1）：新增诊断归因入口新区（reverse 面）——与既有 21 例同为 **E0005 旗标期策略豁免类**（hm-inference-design v0.2.0 §2.3——自举语料不适用 HM-clean 政策；check.krf 运行时正确性由 25 case 测试实测执行证明）。build.krf 37 行零变化。

### 5.5 推进件验收（量化）

- hm_krf_path 族：19 → **25 case**（计数 parity 4：项间双错/三错/module 体/顶层 do splice——含 Diags 形态 + 源序断言；诚实边界守卫 2）
- 全套件：967 → **973:0:0**（净 +6 零回归）
- fmt 0 diff（一处长行当轮 cargo fmt 修正）+ clippy 0
- 三语料锚 319/145/193 维持（零触碰）+ check.krf 语料 E0005 策略豁免一致性注记（§5.4）

---

## 6. 验收对账汇总（本轮量化数字）

| 维度 | 数字 |
|---|---|
| 六命令 | clean 805 files → build 16.53s 零告警 → check 0/0 → fmt 0 → clippy 0 → test **973:0:0**（推进件后终态——净 +6） |
| 审计 | 六审计集 280 case EXIT 0 ×6 |
| HM 审查 | 19 parity 复跑一致 + 生产面 hm_check_program 唯二生产入口核验 + krf 路径零生产消费核验 |
| 构建审查 | 14 parity 复跑 + 生产切换双消费点实测 + 种子豁免条款在档 + bench 稳态带内 |
| 推进件 | +6 测试（parity 4 + 边界 2）+ wire 协议加性扩展 + TD 零新登记（多错误深化为 PoC 范围——非债务项） |
| 语料锚 | 319/145/193 第十轮一致 + 六族 grep 零信号 |

---

## 7. 结论

1. **两点名面实现状态**：HM `.krf` 路径验证与构建系统首切口**均完整交付且声明与实况零漂移**（§3/§4 逐件表）——r74 worklog 声明全部经实测复核成立。
2. **推进件**：HM 多错误收集 PoC 深化（项级恢复）落地——「.krf 能表达错误恢复控制流」的路径级能力扩展验证；残留双轴诚实边界以守卫测试落档（§5.3）。
3. **TD-032 就绪裁定**：余下面四切口全部持信号纪律维持（缓存段技术+信号双阻塞；CLI/运行器/入口待专项信号）——泛指指令不开面级窗（红线 3）。
4. **治理面**：T3+ 14 行触发族判定零变化；TD-031/032 维持 P3 触发式；开放 P0/P1 = 0。

*遵循条款：用户 r75 指令（两点名 + 审查实现状态并完整性 + 打包 + web 驱动源）/ §3.2（六命令 clean 起步全绿）/ GATE 1（实测数字）/ §8.4.5（裁定附条款号——本报告§1 信号纪律表）/ §8.6（worklog 只追加）/ 23 §2.2 + §2.3 红线 1/3（触发表单源 + 零信号不推进）/ r74-window-opening §2/§7（多错误差异注册 + 「或用户后续指令」信号行权）/ 原则 27（wire 协议加性演化 + 单错误形态不变）/ INC8/K3 裁定（生产判定面维持）/ R4（文档以实况为准——§5.2 预判失效实录 + §5.4 策略豁免注记）/ R5（L3 只升不降——r74 四窗续窗审查轮）。*

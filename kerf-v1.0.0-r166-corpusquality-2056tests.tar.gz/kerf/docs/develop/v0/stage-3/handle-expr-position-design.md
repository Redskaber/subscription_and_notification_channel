# 目标面 handle 表达式位窗（handle expression position window）

> **Author**: kerf-dev-agent（Super Z main — ARCH-A 裁定 + PM-A 路由 + DEV-A 实施 + QA-A 验收 + REC-A 落档）
> **Date**: 2026-11-13（r143 / 213-a..213-f 全链）
> **Version**: v1.1（**r147 / 217-e §7 末行翻转**——extern 别名/重导出行清偿关闭：设计单源 extern-alias-design.md v1.0 承载；本窗 P5/P6 探针证据链随行翻转归档）；v1.0（首版——D1-D8 + §7 域外表）
> **Status**: Closed（本窗交付 = 双侧 Reader primary 位分派 + 32 case 门 + 语料对 + EBNF/皮肤字典双登记；1852:0:0 净 +32；详见各 MUV worklog 条目 213-a..213-f）
> **开窗依据**: 用户三链指令①「继续推进 目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施」行权（**M1 指令开窗第四十八例**——r74 先例锚「指令即需求信号本体」）；推荐序裁定 = 逐行走查八设计单源 §7 + tc-sigs §7 + 登记册 + 触发表 14 行全部余行 → 三类不可行排除（Stage 2+ 域外{pub(scope)/is-procedure 值模型/值位 Callable} / 成熟度不在位{extern 别名——符号空间机制缺口，P5/P6 探针 E0019/E0022 实证} / 纯语料信号且零张力）→ **唯一可行项 = handle-multi-arm-design §7 末行「目标面 handle 表达式位」**{张力探针五连实证：P1 define 值位 ⇒100 + P3 实参位 ⇒101 + P7 if 条件位 ⇒11 [S-expr 面三位形全合法] vs P2 let 值位 E0001 + P8 嵌套位 E0001 [目标面全域 fail-closed]}；成熟度全在位{r132 多臂脱糖 + r133 嵌套 resume 双底座 + r110 表达式位 if / r121 表达式位 match 先例通道}；parity 缺口族谱 = CLI 双入口双面表达力 parity 清偿第五连候选（r125 require / r130 import as / r131 use 选择树 / r132 handle 多臂——四连先例）
> **上游单源**: [handle-multi-arm-design §7 末行](./handle-multi-arm-design.md)（登记载体）+ [02 §8.13.1a](../../../lang-design/02-syntax-model.md)（EBNF 产生式权威）+ [20 §14 D2](../../../lang-design/20-surface-conventions.md)（皮肤字典 handle 映射）+ [parse_primary r110/r121 先例注释](../../../crates/kerf-reader/src/target.rs)（primary 位分派通道）

---

## 1. 问题陈述

S-expr 面 handle 是表达式（一切表达式上下文合法——`(define r (handle T ((p k) body) e))` 值位 / `(f (handle ...))` 实参位 / `(if (handle ...) a b)` 条件位）。目标面 .ktf 的 handle 仅语句位可写（`parse_stmt_or_expr` 1914/1846 分派），primary 位无分派 → 表达式位 `let r = handle ask() { gift(p, k) => resume(100) };` 报 E0001 `expected an expression, got KwHandle` fail-closed。**CLI 双入口双面表达力 parity 缺口**：.ktf 程序无法把 handle 用作值（r125/r130/r131/r132 四连清偿的同族第五缺口）。handle-multi-arm-design §7 末行登记态（触发判据 = 目标面表达式位 handle 语料消费信号）——本轮经用户指令①行权 + 探针实测张力清偿。

## 2. 域内事实基线（213-a 探针实测五件）

| # | 探针 | 面 | 位形 | 结果 |
|---|---|---|---|---|
| 1 | P1 | S-expr | `(define r (handle gift ((p k) (resume k 100)) (ask)))` 值位 | ✅ ⇒ 100 |
| 2 | P3 | S-expr | `(f (handle ...))` 函数实参位 | ✅ ⇒ 101 |
| 3 | P7 | S-expr | `(if (handle ...) 11 22)` 条件位 | ✅ ⇒ 11 |
| 4 | P2 | .ktf | `let r = handle ask() { gift(p, k) => resume(100) };` let 值位 | ❌ E0001 fail-closed |
| 5 | P8 | .ktf | 嵌套 protected（handle 的 handle） | ❌ E0001 fail-closed |

附探针（域外行不可行实证）：P5 `.ktf` `use kerf_ffi::{write_stdout as ws}` → E0019（extern 符号不构成模块——符号空间机制缺口）；P6 `.krf` 同形 → E0022。extern 别名行成熟度不在位（§7 域外维持）。

## 3. 裁定 D1-D8

### D1 窗口范围与同形裁定

`handle expr { arms }` **表达式位形与语句形同形**（仅位置不同——r110 表达式位 if / r121 表达式位 match 同构先例第三例）。语句位零回归：`parse_stmt_or_expr` 先行分派维持（语句上下文不经 parse_primary 的 handle 臂）。表达式位形 = `handle <protected-expr> { <arms> }`，protected 域 = `parse_expr` 到达位的一切表达式上下文（let 值位 / 实参位 / if 条件位 / 闭包体尾值位 / 嵌套 handle protected 位 / 括号内等）。

### D2 脱糖同构与零机制变更

primary 位分派直接复用 `parse_handle`（种子）/ `parse-handle`（镜像）——脱糖产物与语句位**逐字节同构**：单臂 → `(handle tag ((p k) body) protected)`；≥2 臂 → `(handle-group (tag (p k) h)+ protected)`（r136 组安装核心形）。expander / compiler / HM / VM **零触及**（核心形既有——8 原语不变性第二十五轮{零新原语零通道零新操作码零 CoreExpr/IR 变体——纯 Reader 位域扩展}）。

### D3 双侧 Reader 最小变更

- **种子** `crates/kerf-reader/src/target.rs` `parse_primary` 顶部前置臂（r110 if / r121 match 先例同款位置）：`if matches!(self.peek(), Tk::KwHandle) { return self.parse_handle(); }`
- **镜像** `crates/kerf-driver/src/bootstrap/target_reader.krf` `parse-primary` cond 表加臂（if/match 臂之后同款）：`((eq k "handle") (parse-handle toks))`
- 变更总量 ≈ 12 行（双侧各 ~6 行含注释）——历次最轻量 Reader 窗之一（r128 resume 语句位扩展同族）。

### D4 r133 穿线维持（handler_k 态在表达式位无损延拓）

`parse_handle` 的 `handler_k` save/restore 态（r133 D2/D3/D5 嵌套 resume 机制）在表达式位同样生效：嵌套 handle 的 protected 表达式内 `resume` 维持域外 fail-closed（D5 既有裁定无损）；每臂安装自身 binder；闭括号恢复外层作用域。表达式位嵌套（P8 形）合法 = 外层 parse_handle 读 protected 时经 parse_expr → parse_primary → 内层 parse_handle 的自然组合。

### D5 语义边界与既有域外维持

- **块形 protected 维持域外**：`handle { ... } { arms }`（protected 为块）在语句位本就不合法（protected 必须是表达式——r106 D2 既有设计），表达式位同律。本窗不扩展块表达式（块形 protected 需块表达式窗联动——§7 域外登记）。
- **resume 表达式位域外维持**：臂体外的 `resume(x)` 在表达式位维持 fail-closed（r133 D5 + 既有 KwResume 负例锚 ktf_stress_corpus_tests:391 / ktf_nested_resume_tests:453——本窗零触及零翻转）。
- **halt/pass 语句位域外维持**：halt/pass 仅臂体位（r132 第十二映射族）——块体语句位 halt/pass = handle-multi-arm §7 既有域外行维持（P4 探针 E0001 实证在案）。

### D6 EBNF 与皮肤字典登记

- **02 §8.13.1a**：primary 产生式注记增补——`handle` 共享语句形（expression_position_handle 注记：`primary → handle expr handle-arms`——与 if/match 表达式位注记同款 v7.23）。
- **20 §14 D2**：handle 映射注记增补「位域扩展：语句位 + 表达式位共享一形」（v1.30）。

### D7 测试矩阵（32 case = 8 正 + 24 负 1:3——§9.4.3）

**正向（8）**：P01 let 值位 handle + 值锚 / P02 函数实参位（+1 变换值锚）/ P03 if 条件位（bool resume）/ P04 闭包体尾值位 / P05 嵌套 handle protected（P8 形合法化）/ P06 多臂 group 表达式位（≥2 臂 → handle-group 脱糖位形）/ P07 跨语法行为等价（.ktf 表达式位程序与 .krf 镜像对同值——P1/P3/P7 语义锚）/ P08 双 Reader parity（种子与镜像 Stx 正典渲染一致——既有 parity 门模式）。

**负向（24）**：读面族 ×8（块形 protected 域外 / 零臂 / 重复标签 / 臂绑定非二元 / 表达式位后缺 arms 块 / expected an expression 既有族维持{非 handle 位} / 悬挂 handle 关键字 / 臂体非法形）；位域维持族 ×8（语句位既有负例零回归 ×3{handler 体域 kw 族} / resume 表达式位域外维持 ×2{块外 + 实参位} / halt/pass 块体语句位域外维持 ×2 / 嵌套 protected 内 resume fail-closed）；跨阶段消费族 ×8（check 面双面零诊断{合法程序} / 运行时值锚双面 / E0006 能力门维持 / E0022 未绑定维持 / 双面计数 parity / 语义负例{未 perform 标签的 handle 值 = protected 直落} / 深嵌套组合 / .ktf 语句位零回归全量）。

### D8 计数 parity 与锚翻转预算

**零诊断面变更**（纯 Reader 位域扩展——不新增诊断路径；唯一变化 = KwHandle 在 primary 位从 E0001 翻转为可解析 = 窗本体）。**锚翻转预算 = 零**（rg 全库实证：「expected an expression, got KwHandle」零锚定；KwUse/KwImport/KwResume 锚全维持；handler 体域负例 714/727 维持）。语料族 12:12 → 13:13（effect_handle_expr.{ktf,krf} 语料对就位——.ktf 与 .krf 语料族对齐维持）。

## 4. 实施清单（213-c 载荷）

1. 种子 `target.rs` parse_primary 前置臂 + 注释（r143 注释含先例链）
2. 镜像 `target_reader.krf` parse-primary cond 臂 + 注释
3. `tests/v0/stage3/plan/ktf_handle_expr_position_tests.rs` 32 case 新门 + runner.rs 挂载
4. 语料对 `examples/usage/effect_handle_expr.{ktf,krf}`（⇒ 值锚五形态）
5. 02 v7.19 EBNF 注记 + 20 v1.26 皮肤字典注记 + examples/README 语料族表 13:13
6. 治理九件（t3plus v1.63 消费注记 + guide v1.28 行权实录 + RELEASE r143 节 + README 三处 + matrix r143 行 + rec 104 + worklog 三链）

## 5. 验收与对账（GATE 消费）

- §3.2 六命令 clean 起步全绿（build 零告警 / check 0:0 / fmt 0 diff / clippy -D warnings 0 / **test 1852:0:0 净 +32**）
- 审计×6 EXIT 0（280 case——§7.3.1 规则 3 审计可重跑口径）
- CLI 双语法面零回归（fib ⇒144 双面 + nested ⇒540 + multiarm ⇒217 + closures ⇒42 + vector ⇒9 + ffi ⇒9 + stress ⇒120 + handle_expr 新语料 ⇒ 值锚双面 + check 计数锚）
- bench fib 带内（>65ms 触发线不满足维持——OBS-C 零信号）
- r143 包三验（独立解包净构建 + 包内 1852 复跑 + e5close EXIT 0）+ web 五件 + Agent Browser E2E

## 6. 域内先例链

r110 表达式位 if（primary 前置分派首例）/ r121 表达式位 match（同构第二例）/ r128 resume 语句位（位域扩展族）/ r133 嵌套块 resume（handler_k 穿线）/ r132 多臂脱糖（第十二映射族）/ r136 组安装（handle-group 核心形）。

## 7. 域外表（本窗不做——触发式）

| 域外项 | 载体 | 触发判据 |
|---|---|---|
| 块形 protected（`handle { ... } { arms }` 块表达式作被保护体） | 本文件 D5（既有设计——语句位同律域外） | 块表达式窗联动（块形 protected 语料消费信号） |
| halt/pass 块体语句位（臂体块内裸 halt/pass 语句形） | handle-multi-arm §7 既有行 + P4 探针实证 | 块体终止/穿透语料消费信号 |
| effect_pattern 泛化（pattern_list 模式/if 守卫入臂） | handle-multi-arm §7 既有行 | match 模式集成窗（pattern_list 消费信号） |
| 裸臂形 `Name`（无绑定对） | handle-multi-arm §7 既有行 | 语料消费信号 |
| resume 多参/命名形 | EBNF v9 既有登记 | 既有触发式维持 |
| ~~extern 别名/重导出（use 选择形接驳 extern 符号）~~ | ~~ffi-language-surface §7 末行 + 本窗 P5/P6 探针实证（E0019/E0022——符号空间机制缺口）~~ | **✅ r147 清偿（extern 符号空间别名窗 217-a..217-f——设计单源 extern-alias-design.md v1.0：声明位别名臂——双名分离 + 替换语义 + 反遮蔽扩展；use 选择形接驳维持域外 D9[扁平空间无模块面——宪制]；1916 基线）** |

*遵循条款：原则 9（CoreExpr 冻结——D2 零机制变更）/ 原则 12（最优>最小——primary 复用 parse_handle 全臂面而非子集）/ 原则 26（成熟度匹配——四先例底座 + 探针张力实证）/ 原则 27（加性——语句位零回归 + 既有程序零扰动）/ 原则 31（皮肤/骨架同构——脱糖逐字节同构 + 跨语法行为等价）/ 原则 44（新语法成员登记必须附 EBNF 产生式——D6）/ §2.3-4（报错>静默——位域维持族 fail-closed 全维持）/ §9.4.3（1:3）/ §18（机制零新增）/ r74 先例（用户指令 = 需求信号本体）/ r110/r121 表达式位先例（primary 前置分派通道）。*

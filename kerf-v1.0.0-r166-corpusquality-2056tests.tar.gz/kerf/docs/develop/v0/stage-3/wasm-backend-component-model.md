# WasmBackend 组件模型设计

> **Author**: kerf-dev-agent（ARCH-A 角色）
> **Date**: 2026-09-24；2026-10-16（r92 / 162-a M1 交付）；2026-10-19（r97 / 167-a M2 交付）；2026-10-20（r99 / 169-a M3 交付）
> **Version**: v1.3（**r99 / 169-a M3 组件组合层交付——TD-031 终态件全清偿**：①`crates/kerf-backend/src/wasm_compose.rs` 组合层[**imports/exports 缝合**：`compose_component(ir, model, data, abi)` → M2 边界模块 + M3 链接核心模块 + `InstantiationPlan` 有序实例化计划{双步：`kerf_abi` 无导入 → `kerf_core` 注入 wiring 图{memory + realloc 双缝合——字段名/供给源/种类三锚}} + **组件级类型校验** `validate_composition` 五校验全 fail-closed{①memory64 地址域一致性 ②realloc 供给一致性{声明未供给/名不一致双拒} ③边界类型分配协议[String/List 族要求 realloc——`boundary_class` 递归扫描] ④Func 导出背书{名字 ∈ 核心函数清单} ⑤main 入口背书} + **L-β 效应/能力组件实例协议裁定**：perform/handle 不跨组件边界——效应承载于组件实例协议{宿主按实例实例化处理器——M0 §3「效应/能力|边界外」的 M3 落位}；结构化守护 = `boundary_class` **穷举全部 InterfaceType 变体**{当前全部效应无关——类型系统不设效应承载面，结构事实；新增变体必须补分类臂否则编译期断裂——fail-closed 的编译期形态}；组合面接收 ANF 恒为效应无关{AOp=Prim|Call、ACtrl=Ret|Br|Jmp 无效应变体——效应程序走 VM 路径 INC7}；组件实例协议完整设计 = 后续 B1/效应后端信号窗义务] + 计划 `render` 规范串锚 + 源指纹链透传] + ②`wasm/emit.rs` 增量[**`CoreImportFace` 导入面**{module + memory{min 页/memory64} + realloc{name/wide}——M3 缝合消费侧描述} + **`emit_core_module_linked(ir, face)`**{Import 节 id 0x02 插 Type/Function 之间 + Type 去重池增 realloc 签名条目{wasm32 = (i32×4)→i32 独立条目；memory64 = (i64×4)→i64 与四形参签名同构复用} + **函数索引空间基偏移**{导入函数占前位——Export main 与 Call 同步偏移} + 空函数清单 + 非空面 fail-closed] + 单元 6] + ③`tests/v0/stage3/plan/wasm_compose_tests.rs` 集成 9[**node 宿主组合 E2E parity**——按计划实例化 canonical 双模块系统{validate ×2 → 实例化 `kerf_abi` → 其导出面作 import object 注入 `kerf_core` 实例化 → main() 与 kerf VM `run_source` 逐语料对账——**缝合的运行时类型检查背书**：名/类型/页数不匹配即实例化失败}：fib 12/20 + 算术/值菱形/嵌套菱形/尾位 if + 互递归 + div-mod 负数 + i64 全宽边界{2^32/i64::MAX} + **缝合真实性负探针**×2{无 import object → LinkError{导入依赖真实非装饰} + 错误 memory 接线 → 实例化失败{类型检查真实}} + 自定义 realloc 名接线 parity + memory-only 形态{realloc = None 单缝合 + 基偏移零} + 计划/清单真实源码整链对账 + 确定性]——**净 +27 测试 1141:0:0**{单元 18 + 集成 9}]；**M3 开窗判据回填**[M2 ✅ r97 + 组件组合消费方 = 用户 r99 指令「按照推荐先后任务顺序继续推进」= 需求信号本体{r74 先例锚——指南 §4 响应契约「指令即触发」} + 组合消费基底实测{M2 交付双工件族并立：emit_core_module + emit_abi_module 两类发射工件——组合为本文件 M2 L-A′ 裁定明文登记的后续信号路径「M3 组件组合/B1 扩界窗」} + node 宿主组合实例化验证实体{本窗交付——r92 M1「node 宿主实体化消费验证」同构}]；**M3 诚实边界**：核心模块对导入面的语义消费（str 载荷经 memory + realloc 的语言面 lowering）= B1 扩界窗信号（与 M2 L-A′ 同族——`string_literal_rejected_before_emit` 负例继续守护）；M3 交付组合协议面（缝合 + 类型校验 + 实例协议裁定），组合系统经宿主链实例化验证{导入面结构性接线——实例化期类型检查即消费验证}）；v1.2（r97 / 167-a M2 canonical ABI 适配层交付——摘要见前；v1.1 r92 M1；v1.0 r74 首件）
> **Status**: **Closed（TD-031 全清偿关闭：M0 契约层 ✅ r74 + M1 核心模块生成 ✅ r92 + M2 canonical ABI 适配 ✅ r97 + M3 组件组合 ✅ r99——四阶段全落；后续演进 = B1 扩界窗/组件实例协议窗[触发式]）**
> **上游**: 用户 r74 显式指令窗②（[r74-window-opening §3](./r74-window-opening.md)）+ 用户 r92 M1 指令开窗第七例（[t3plus-manual-trigger-guide §4 速查卡【第 3 位】](./t3plus-manual-trigger-guide.md)——「按照推荐先后任务顺序继续推进」行权链 r74/r79/r80/r86/r87/r90/r92）+ 用户 r97 M2 指令开窗第八例（同速查卡【第 3 位】——行权链 r74/r79/r80/r86/r87/r90/r92/r97；开窗判据 = M1 交付 ✅ + 边界类型消费 case ≥10 实测[语料库 str/pair-list 消费 400+ 行级命中]）+ 用户 r99 M3 指令开窗第九例（同速查卡【第 3 位】——「按照 docs/sop.md 流程结合 docs/lang-design/ 下文档集合内容推进项目演进流程，按照推荐先后任务顺序继续推进」行权链 r74/r79/r80/r86/r87/r90/r92/r97/r99；开窗判据 = M2 交付 ✅ + 组件组合消费方[用户指令 = 需求信号本体 + M2 双工件族组合基底 + node 组合实例化验证]）；
> [13-能力矩阵 §3.3.7](../../../lang-design/13-capability-matrix.md) WasmBackend P1 预留（r92 注记：WasmCoreBackend 首实作；r97 注记：M2 协议层；r99 注记：M3 组合层——TD-031 终态）；
> [08-后端策略](../../../lang-design/08-backend-evolution.md) v6.6 接口预留注记（M1 做实）

---

## 1. 问题定义

`WasmBackend` trait（r12 冻结、r38-b 迁入正式家）的产物 `WasmComponent` 此前为
「字节信封占位」（单字段 `bytes`）——**组件模型标准的结构语义未承载**：
组件如何组合核心模块、边界类型如何声明、canonical ABI 如何参数化，均无契约形状。
用户 r74 指令点名「WasmBackend 组件模型」= 需求信号命中，本窗开启：**契约层做实**
（结构化组件模型），**字节码生成触发式维持**（TD-031）。

## 2. 组件模型标准的契约分解（2026 口径）

WASM 组件模型三要素（[13 §3.3.7] 注记「组件模型 + 接口类型 + WASM GC」）：

| 要素 | 本设计契约形状 | 位置 |
|---|---|---|
| 接口类型（interface types） | `InterfaceType`（primitive 族 + record/variant/tuple/list/option/result/func） | `wasm.rs` |
| 组件边界 | `ComponentImport`/`ComponentExport`（名 + 接口类型） | `wasm.rs` |
| canonical ABI | `CanonicalAbiOptions`（string-encoding/memory64/realloc 锚） | `wasm.rs` |
| 核心模块函数清单 | `CoreModuleFunc`（名/形参数/块数——M1 生成锚） | `wasm.rs` |
| 组件整图 | `WasmComponentModel`（版本 + 清单 + 边界 + ABI + 源指纹链） | `wasm.rs` |
| 派生件 | `component_model_from_anf`（AnnotatedANF → 组件模型） | `wasm.rs` |
| 组合件 | `ComponentModelBuilder`（增量装配 + fail-closed 校验） | `wasm.rs` |
| 产物信封 | `WasmComponent { bytes, model }`（原则 27 加性演化） | `codegen.rs` |

## 3. kerf 值域 ↔ 接口类型映射（组件边界的投影表）

| kerf 类型 | 接口类型投影 | 边界语义 |
|---|---|---|
| `int` | `S64` | 直接投影（值域一致） |
| `float` | `F64` | 直接投影 |
| `bool` | `Bool` | 直接投影 |
| `str` | `String` | canonical ABI 编解码（UTF-8 默认——Rust 载体同编码） |
| `nil` | `Option<T>` 的 `none` 投影 | 须与具体 `Option` 载荷类型配对（无独立 nil 边界） |
| 序对/列表 | `List<T>` / `Record` | 边界须物化为具体接口类型（惰性序对不可跨界） |
| 符号 | `String`（名字面）或 `Variant` 标签 | 语义由导出面声明决定（M3 组合件裁定） |
| 闭包/函数值 | `Func(ComponentFuncType)` | 组件级函数类型（一等函数的组件投影） |
| 效应/能力 | **边界外** | 效应承载于组件实例协议（perform/handle 不跨组件边界——M3 裁定项） |

**边界外诚实声明**：kerf 的序对惰性结构、GC 堆对象、效应续延**不经组件边界投影**——
组件边界只承载接口类型值域；堆内表示属核心模块内部（WASM GC 类型——M1 裁定项）。

## 4. AnnotatedANF → 组件模型派生（M0 派生件）

`component_model_from_anf(ir)`：函数清单（`CoreModuleFunc`：名/形参数/块数）+
默认 ABI（UTF-8/无 memory64/无 realloc）+ 源指纹链（`source_fingerprint` =
`AnnotatedANF.fingerprint`——组件产物的内容寻址溯源锚）。imports/exports 空
（M3 组合件按需装配）。

**M0 边界**（诚实收窄）：派生面 = 清单与形状摘要；**不含**核心 wasm 字节码、
canonical ABI 适配指令、组件组合缝合。

## 5. M1-M3 分阶段做实路线（触发式——TD-031）

| 阶段 | 内容 | 入口信号（全部满足才开窗——23 §2.2 形态） | 状态 |
|---|---|---|---|
| **M1** 核心模块生成 | `CoreModuleFunc` 清单 → core wasm module 字节码（值域 int/float 先行——与 QBE PoC B1 边界同口径对齐扩展） | ①组件消费方出现（宿主运行时/嵌入方需求）②QBE 后端边界扩展经验回填③WASM GC 类型裁定 | **✅ r92 交付**（用户 M1 指令开窗第七例——判据回填：①用户指令 = 需求信号本体[r74 先例锚] + node 宿主实体化消费验证；②B1 共享拒绝面负例回填[qbe_backend_tests 同源]；③**L-A 裁定 = 线性类型域 i64 先行，GC 堆类型边界外维持**） |
| **M2** canonical ABI 适配 | `CanonicalAbiOptions` 消费——串编解码 + realloc 协议 + memory64 | M1 交付 + 边界类型消费 case ≥10 | **✅ r97 交付**（用户 M2 指令开窗第八例——判据回填：M1 ✅ r92 + 边界类型消费 case ≥10 **实测成立**[语料库 18 .krf：10 语料消费 str + 9 消费 pair-list，行级命中 400+ ≫ 10——bootstrap 自举链全量依赖边界类型]；交付 = `wasm_abi.rs` 协议层 + `emit_abi_module` 七节发射 + realloc bump 函数 + node 宿主 str 跨界 parity E2E + 净 +23 测试 1114:0:0） |
| **M3** 组件组合 | imports/exports 缝合 + 组件级类型校验 + 效应/能力的组件实例协议裁定 | M2 交付 + 组件组合消费方（多组件系统需求） | **✅ r99 交付**（用户 M3 指令开窗第九例——判据回填：M2 ✅ r97 + 组件组合消费方 = 用户指令 = 需求信号本体[r74 先例锚] + M2 双工件族组合基底{emit_core_module + emit_abi_module 并立——M2 L-A′ 裁定明文登记的后续信号路径} + node 宿主组合实例化验证实体；交付 = `wasm_compose.rs` 组合层 + `emit_core_module_linked` 链接发射 + `InstantiationPlan` 缝合计划 + 组件级类型校验五校验 + L-β 裁定 + node 组合 E2E parity + 净 +27 测试 1141:0:0——**TD-031 全清偿关闭**） |

### 5.1 M1 交付实录（r92 / 162-a）

- **发射器**（`wasm/emit.rs`）：`emit_core_module(ir)`——magic/版本头 + Type 节（签名去重保序）+ Function 节 + Export 节（`main` = 函数索引 0，QBE PoC 同口径：仅导出 main 其余内部可见）+ Code 节（逐函数 locals + 指令）+ `kerf_meta` 清单自定义节（`CoreModuleFunc` 名/形参数/块数——回读对账锚）；**确定性**：同 ANF → 同字节（全结构定序，无哈希迭代序入产物）；空 IR → 合法最小模块（头 + 空清单节）。
- **CFG→结构化控制**：递归区域分解（`emit_region`）——值菱形（Br + 双 Jmp 臂 + 单 phi merge）→ `if (result i64)` 双臂留值 + `local.set` phi dst；尾位 if（Br + 双 Ret 臂）→ `if (void)` 双臂 return + **函数级 `unreachable` 垫底**（双臂 return 后 `end` 复位可达态——验证器合法形态，控制事实上永不落穿语义零变更）；结构不变式逐项 fail-closed（Br.then≠下一块 / Jmp 在 Return 区域 / Ret 非区域末块 / 值臂尾形 Br / merge 越界 / phi 缺来源 / 重名 / 空名）。
- **原语映射**：Add/Sub/Mul → i64.add/sub/mul；Div/Mod → i64.div_s/rem_s（VM 截断除/余符号对齐）；六比较族 → i64.eq/lt_s/gt_s/le_s/ge_s + i64.extend_i32_u；not → i64.eqz + extend；Call → call funcidx（名字表索引解析 fail-closed）；ATemp 编号即 local 索引（形参占 0..arity，体临时连续续编——anf.rs LowerCtxt 编号不变式）。
- **`WasmCoreBackend`**：`WasmBackend` trait 首个做实实现——`compile_component → { bytes: emit_core_module, model: component_model_from_anf }`（原则 27：trait 签名零变化；`bytes` 语义自「M1 字节码生成的载荷」契约注释兑现）。
- **回读对账**：`parse_core_module_manifest(bytes)`——节区走查（magic/版本 + id 序 + 载荷边界）+ `kerf_meta` 解码；断言 `parse(emit(ir)) == component_model_from_anf(ir).core_funcs`（发射↔契约层双向 parity + 单源断裂守护[缺节 fail-closed]）。
- **宿主 E2E**（node = 组件消费方实体——`KERF_NODE` 查找链 + PATH 探测 + 缺失显式失败 §3.1）：`WebAssembly.validate` + 实例化 + `main()` 调用与 kerf VM `run_source` 逐语料对账——fib 12→144 / fib 20→6765 / 算术 / 嵌套菱形 / 尾位 if / 尾位嵌套 / let 链 / not / 六比较族 / div-mod 负数 / 互递归 / 多形参 / 空程序→0 / i64::MAX 字面量 / **i64 全宽真值边界（2^32 / 2^33 / -2^32 / 0 / -1——eqz 双取反语义锚）**。
- **三侧条件宽度边界（诚实登记）**：语言面 if 条件 = 显式 bool（VM E0004 拒绝 int 条件）；ANF lowering = 宽口（int 条件可过——ensure_temp 类型宽口）；M1 发射 = 非零即真（与 QBE jnz 同宽）。合法程序（VM 可跑）的 ANF 条件值恒 ∈ {0,1}——三侧在合法域一致。
- **验证器两缺陷修复实录**（实施期 node E2E 检出即修）：①Br 臂漏发块内语句（cond 计算绑定丢弃——`(if (< 1 2) 10 20)` WASM 侧误取 else 臂实测检出）；②尾位 if 双臂 return 后函数级 `end` 的 i64 要求落空（node INVALID WASM 检出 → `unreachable` 垫底解）。

### 5.2 M2 交付实录（r97 / 167-a）

- **协议层**（`wasm/abi.rs`）：`CanonicalAbiOptions` 三字段**全消费**——①`string_encoding` → `encode_string`/`decode_string`（UTF-8 直通 / UTF-16LE 单元序；**验证性解码**：非法 UTF-8 序列、奇数字节长度、孤立高/低代理、交错代理对均 `AbiError` fail-closed——非静默替换；编码确定性：同串同编码同字节）；②`memory64` → `AddressWidth::from_memory64`（i32/i64 地址域——发射侧单源选择）；③`realloc` → bump 分配协议锚（`align_to_byte_size` 对齐表[log2→字节] + `align_up` + `CANONICAL_REALLOC_DEFAULT_NAME` 默认名 + `PAGE_SIZE`/`pages_for` 页几何）。
- **边界模块发射**（`wasm/emit.rs` 增量 `emit_abi_module(data, abi)`）：七节结构 = Type[realloc 签名 `(addr × 4) → addr`] → Function → Memory[min 页 = pages_for(heap_base) + 1 余量；**flags 0x04 = memory64**] → Global[堆指针 mut——`heap_base = align_up(max(len,1), 8)`，地址 0 保留 null 哨兵] → Export[`memory` + realloc 名锚] → Code[bump 函数体] → Data[active 段 offset 0——str 编码字节的跨界载荷面]；**契约语义诚实兑现**：`realloc = None` → 省略 Type/Function/Global/Code 四节（「不跨越需要分配的边界类型」）；空 data → 省略 Data 节；data > u32 域 → fail-closed。
- **realloc bump 函数**（`emit_realloc_body`——i32/i64 双地址域单源）：`$i = 1 << align`（canonical ABI 对齐 log2 协议）→ `$np = (heap + a - 1) & -a`（向上对齐——`-a = 0 - a` 二补数免负常量）→ 旧数据复制（`old_ptr ≠ 0 ∧ old_size ≠ 0` 守卫 + block/loop 逐字节 load8_u/store8）→ `heap = $np + new_size`（单调前进）→ 返回 `$np`。
- **宿主 E2E**（node——str 跨界 parity + 协议语义）：①**跨界 round-trip**：Rust `encode_string` → data 段 → node 经 `exports.memory.buffer` 读回 → hex 逐字节对账 → `decode_string` 回原串（UTF-8：ASCII/BMP/增补平面混合；UTF-16：代理对族）；②**realloc 协议**：首次分配 = 堆基址 / 扩容 r2 > r1 且 8 对齐 / **旧 5 字节逐字节保留**（0x40-0x44 在新块处完整）/ 第三分配不重叠 / 零大小旧块仍前进（协议边界）；③memory 导出面 + 页数几何（131072 = 2 页 / 262144 = 4 页跨页锚）；④自定义 realloc 名导出。
- **memory64 字节级断言**（L-C′ 裁定——node 对 memory64 实例化支持是版本依赖）：节走查断言 = Memory flags 0x04 + Global valtype i64 + init `i64.const` + Type 四参全 i64 + Data offset `i64.const`；wasm32 对照面同步（flags 0x00 + i32 域）。**诚实边界**：memory64 宿主 E2E 留 node 版本支持信号（字节级验证先行——不宣称未验证的实例化能力）。
- **M2 范围裁定（L-A′）**：语言面 str 字面量 lowering（ANF B1 扩界——`StxDatum::Str` → `AAtom::Str`）**不在 M2 范围**：B1 扩界 = 独立演进信号（与 TD-024 Float 域扩张同族——`string_literal_rejected_before_emit` 负例继续有效守护）；M2 交付组件边界协议基础设施，语言面接入随后续信号（M3 组件组合 / B1 扩界窗）。**bump 诚实边界**：不做 `memory.grow`（初始余量耗尽即越界 trap——fail-closed）；旧块不回收（bump 单调——free 协议由宿主 GC 域承接）。
- **测试计数**：单元 12（编解码 round-trip ×6 + fail-closed ×2 + 跨编码敏感 + 地址域 + 页几何 + 对齐表）+ 集成 11（E2E 5 + 字节级 6——`cross_encoding_case_count_register` 显式对账「边界类型消费 case ≥10」交付锚）——**净 +23，1114:0:0**。

### 5.3 M3 交付实录（r99 / 169-a）

- **组合层**（`wasm/compose.rs`）：`compose_component(ir, model, data, abi)` = 校验 → 双工件发射 → 计划缝合三段。**`InstantiationPlan`**：有序双步（`kerf_abi` = AbiBoundary 无导入 → `kerf_core` = CoreLinked 注入 wiring 图）+ 组合级 ABI 选项单源 + 源指纹链透传（`WasmComponentModel.source_fingerprint` ——组合产物的内容寻址溯源锚）；**wiring 图**：`ImportWiring { field, source, kind }` 三锚——memory 缝合（min 页 + 地址域）/ realloc 缝合（`(addr×4)→addr` 宽度）；`render()` 规范串锚（确定性——验收断言面）。
- **组件级类型校验**（`validate_composition`——缝合前置门，五校验全 fail-closed）：①memory64 地址域一致性（模型声明 ≡ 组合供给）；②realloc 供给一致性（模型声明未供给 / 双侧名不一致双拒；模型 `None` = 未声明——组合供给合法采用）；③**边界类型分配协议**（`boundary_class` 递归扫描——String/List 族[Allocating 类]要求组合供给 realloc：canonical ABI 分配传递类型的协议要求，M0 契约层 `ComponentImport`/`ComponentExport` × `InterfaceType` 的首次真实消费）；④Func 导出背书（名字 ∈ `core_funcs` 清单——组件级导出面 ↔ 核心函数清单缝合）；⑤main 入口背书（组合消费面调用 main——`lower_program` 惯例位）。
- **L-β 效应/能力组件实例协议裁定**：perform/handle 不跨组件边界——效应承载于组件实例协议（宿主按组件实例实例化处理器；M0 §3「效应/能力 | 边界外」表的 M3 落位）。**结构化守护** = `boundary_class` 穷举全部 `InterfaceType` 变体（当前全部变体均效应无关——类型系统不设效应承载面，结构事实；未来新增变体[尤其效应承载面]必须补分类臂否则编译期断裂——fail-closed 的编译期形态）。组合面接收的 ANF 亦恒为效应无关（`AOp = Prim|Call`、`ACtrl = Ret|Br|Jmp` 无效应变体——效应程序走 VM 路径 INC7）；组件实例协议的完整设计 = 后续 B1 扩界/效应后端信号窗义务。
- **链接发射**（`wasm/emit.rs` 增量）：`CoreImportFace` 导入面（module 实例名 + memory 规格{min 页/memory64} + realloc 规格{字段名/宽度}）+ `emit_core_module_linked(ir, face)`——**Import 节（id 0x02）插 Type 与 Function 节之间**（wasm 节序规范）；Type 去重池增 realloc 签名条目（wasm32 = `(i32×4)→i32` 独立条目[函数池全 i64 域不冲突]；memory64 = `(i64×4)→i64` 与四形参函数签名**结构同构复用**——WASM 类型结构等价即可共享 typeidx）；**函数索引空间基偏移**（导入函数占前位——Export `main` 与 Call 解析同步偏移 `func_base`）；空函数清单 + 非空面 fail-closed（导入面要求 main 导出承载）；`emit_core_module(ir)` plain 形态语义零变更（空面 = plain 逐字节等价——单元测试锚）。
- **宿主组合 E2E**（node——缝合的运行时类型检查背书）：按计划实例化 canonical 双模块系统——validate ×2 → 实例化 `kerf_abi` → 其导出面（memory + realloc）作为 import object 注入 `kerf_core` 实例化 → `main()` 与 kerf VM `run_source` 逐语料对账。**语料族**：fib 12→144 / fib 20→6765（深递归——Call 索引基偏移 + Import 节在位的整链语义验证）/ 算术 / 值菱形 / 嵌套菱形 / 尾位 if / 互递归 / div-mod 负数 / i64 全宽边界（2^32 / i64::MAX——sleb64 十字节规范形经链接形态发射）。**缝合真实性负探针** ×2：无 import object 实例化链接核心模块 → LinkError（导入依赖真实非装饰）；memory 接线为非 `WebAssembly.Memory`（42）→ 实例化失败（运行时类型检查真实——缝合的类型校验消费锚）。
- **接线名单源**：realloc 字段名从 `CanonicalAbiOptions` → `CoreImportFace` → `InstantiationPlan` → 宿主接线对象单源透传（自定义名 `my_realloc` 形态端到端 parity；`realloc = None` = memory-only 单缝合形态 + 函数索引基偏移零——供给面省略四节同口径）。
- **确定性**：同 (ir, model, data, abi) → 同组合产物（字节与计划双侧）；敏感性分层——abi_module 对 data **内容**敏感（data 段字节）、core_module 对 data **几何**敏感（导入面 min 页——内容不入面）、计划对 ABI 协议参数敏感（realloc 名透传）。
- **M3 诚实边界**：核心模块对导入面的**语义消费**（str 载荷经 memory + realloc 的语言面 lowering）= B1 扩界窗信号（与 M2 L-A′ 同族——`string_literal_rejected_before_emit` 负例继续守护）；M3 交付组合协议面（缝合 + 类型校验 + 实例协议裁定），组合系统经宿主链实例化验证（导入面结构性接线——实例化期类型检查即消费验证）。
- **测试计数**：单元 18（组合层 12[计划结构/五校验 fail-closed ×5/boundary_class 族/face 几何/确定性敏感性/渲染锚/清单存活] + 发射器 6[Import 节结构/索引基偏移 Call 字节锚/plain 等价/面校验 ×3/memory64 字节级/确定性]）+ 集成 9（组合 E2E parity 3 语料族测试 + 负探针 ×2 + 自定义名 + memory-only + 计划清单整链 + 确定性）——**净 +27，1141:0:0**。

## 6. 契约纪律记录

- **原则 27（签名向后兼容）**：`WasmBackend` trait 三方法签名零变化；
  `WasmComponent` 加性演化（`bytes` 字段语义不变 + `Default` 兼容不变）；
  字面量构造点随迁更新（codegen.rs/reserved 测试锚——`codegen_reserved_signatures_are_frozen`
  契约锁存测试持续全绿即加性演化的实证）。
- **空间从属（24 §7.2）**：`WasmComponent`/`WasmComponentModel`/`InterfaceType`
  三层 marker（根+核心空间+核心后端域）挂核心后端域——与 `CompiledModule`/
  `AnnotatedANF` 同域同型；**r92 增补**：`WasmCoreBackend` 三层 marker 同域
  （lib.rs 空间从属声明段单源——24 §3 A7 从属唯一判据 = marker impl）；
  **r99 增补**：`ComposedComponent`/`InstantiationPlan`/`CoreImportFace` 三类型
  三层 marker 同域（组合层新类型的空间从属归位——同段单源）。
- **§18 依赖审查（L-B 裁定——r92 M1 开窗重审兑现）**：**自写字节码发射器**
  （零 cargo 依赖——纯 Rust LEB128/节区/指令发射；无 wasm-tools/wasmparser）；
  **node = 宿主侧测试期验证工具**（`KERF_NODE` 查找链 → PATH 探测 → 缺失显式
  失败 §3.1——同 qbe/cc 先例形态：外部宿主工具非构建依赖）。
- **WASM GC 类型裁定（L-A——r92）**：M1 核心模块 = **线性类型域**（i64 值域 +
  locals + 栈机指令）；GC 堆类型维持边界外（M0「堆内表示属核心模块内部」+
  组件边界「序对惰性结构/GC 堆对象/效应续延不经边界投影」同口径）——GC 类型
  消费信号出现时再评估（红线 3 零信号不引入）。
- **值域诚实收窄（B1 同口径）**：M1 生成代码值域 = i64（kerf int 全宽）；`f64` 为
  `InterfaceType::F64` 契约级投影——ANF 原子无 Float 变体（Float 语料零信号——
  TD-024 判据 3 同源维持）。
- **TD-031 登记**：WasmBackend 字节码生成（M1-M3）——P3 触发式（本文件 §5 判据）；
  **M1 ✅ r92**（登记册 v0.4.11）——M2/M3 触发式维持；**M2 ✅ r97**（登记册
  v0.4.12）——M3 触发式维持；**M3 ✅ r99（登记册 v0.4.13）——TD-031
  全清偿关闭**（后续演进 = B1 扩界窗/组件实例协议窗——触发式，红线 3）。
- **效应/能力组件实例协议（L-β——r99 M3 裁定）**：perform/handle 不跨组件
  边界——效应承载于组件实例协议（宿主按实例实例化处理器）；`boundary_class`
  穷举分类器 = 结构化守护（新增 `InterfaceType` 变体必须补分类臂否则编译
  期断裂）；ANF 无效应变体（效应程序走 VM 路径 INC7）——组合面恒纯。

## 7. 验收对账

- `wasm.rs` 契约测试 8 件（派生清单锚 + 三重名唯一性拒绝 + 深界拒绝 +
  realloc 锚校验 + 组合整图 + 渲染族 + 结构化信封 Default 兼容）；
- `codegen.rs` 契约锁存随迁（ProbeWasm 产物携带 model——指纹链锚）；
- 空间 marker 三层齐备；
- **r92 M1 验收**：`wasm_emit.rs` 单元测试 8 件（uleb32/sleb64 黄金向量——含
  i64::MAX 十字节规范形与 2^32 真值锚 + 空模块最小形 + 常量 main 全模块逐字节
  黄金 + 确定性/内容敏感性 + 重名 fail-closed + 结构违反双形 + trait 信封双向
  parity）+ `wasm_backend_tests.rs` 集成 28 件（node 宿主 E2E parity 15 语料族 +
  清单回读对账双形 + 确定性跨编译链 + trait 信封端到端 + 三侧条件宽度边界 +
  B1 共享边界负例四形[Float/Str/闭包值位/assign] + 回读 fail-closed 三形）——
  净 +36 测试 **1091:0:0**；六审计集 280 case EXIT 0 ×6 维持；CLI 路径零回归。
- **r97 M2 验收**：`wasm_abi.rs` 单元 12 + `wasm_abi_tests.rs` 集成 11——净 +23
  测试 **1114:0:0**；六审计集 280 case EXIT 0 ×6 维持；CLI 路径零回归。
- **r99 M3 验收**：`wasm_compose.rs` 单元 12 + `wasm_emit.rs` 单元 6 +
  `wasm_compose_tests.rs` 集成 9——净 +27 测试 **1141:0:0**；六审计集
  280 case EXIT 0 ×6 维持；CLI 路径零回归；组合系统 E2E parity（node 按计划
  实例化双模块 + 缝合负探针 ×2）+ 确定性（字节与计划双侧）。

*遵循条款：用户 r74 指令（窗②点名驱动源）/ 用户 r92 M1 指令（开窗第七例——指南 §4 速查卡【第 3 位】行权）/ 用户 r97 M2 指令（开窗第八例——同速查卡【第 3 位】行权）/ 用户 r99 M3 指令（开窗第九例——同速查卡【第 3 位】行权；「按照 docs/sop.md 流程结合 docs/lang-design/ 下文档集合内容推进项目演进流程，按照推荐先后任务顺序继续推进」）/ 13 §3.3.7（WasmBackend P1 预留 + 组件模型三要素注记）/ 08 v6.6（M1 做实注记）/ 原则 27（签名向后兼容——加性演化）/ 原则 13（目标中立——组件层消费 IR 不消费 CoreExpr）/ 24 §7.2（空间从属）/ §18（依赖审查——L-B 自写裁定 + node 宿主工具非构建依赖）/ 23 §2.2（M1-M3 入口信号形态）/ r74-window-opening §1（用户指令 = 需求信号先例——M3 判据回填锚）/ §3.1（工具查找链 + 缺失显式失败）/ §8.4.5（裁定附条款号）/ §8.4.6（产物位置）/ §3.2（六命令全绿 + 1141:0:0）。*

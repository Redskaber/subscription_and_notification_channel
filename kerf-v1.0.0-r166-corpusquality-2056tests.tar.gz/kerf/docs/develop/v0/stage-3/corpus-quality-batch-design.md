# 自举语料代码质量批窗设计（TD-040 Batch 1——堆叠 else 平链化 + 超长函数分拆）

> **Status**: Closed（Batch 1——r166 / R7+237-f 收口：D1-D10 兑付——Track 1 324 位点全清{fixpoint 零} + Track 2 九件全清{span>80 → 0} + D5 审计门 12 case 落位 + 零行为门全绿{2056:0:0 + 125:0 + CLI 值锚 + bench A/B -0.6%}；Batch 2 触发式登记{嵌套 38 件 + 短名}}）
> **Version**: v1.0（r166 / 237-a..237-f——TD-040 触发条件①满足：用户指令「单函数层级 ≤3、单一职责、适度长度、变量名清晰」存量面行权[本会话第八轮连续出现] + 「if else 嵌套……请转向现代前沿 if {} else if {} 链式」直接对位）
> **Author**: Super Z (main) — PM-A/ARCH-A/DEV-A/QA-A/REC-A 复合
> **Date**: 2026-11-27
> **登记对账**: tech-debt-register v0.4.23-r165 TD-040{处置三轨} / variadic-rest-design.md §0 附带腿 / sop.md v15.0 §2.5 现代编译流程接入纪律（登记态旁证）

## 0. 窗口背景与触发

TD-040（r165 / 236-a-audit 登记）：自举语料 13,447 行 / 666 函数——机械翻译三代件（r110-r153 .krf→.ktf 直译代）存在四维质量问题：深度违例 / 超长函数 / 短名族 / 职责混合。本窗 = **Batch 1**：处置三轨前两轨（Track 1 平链化全量 + Track 2 九件分拆）；Track 3（短名清洗）与残余真嵌套（登记口径 44 件）→ Batch 2 触发式登记。

**本会话恢复轮前置**（R7-a..R7-f）：第七次 z.ai web 回退——r165 权威包单源恢复 + sop.md v15.0-verified / stage0.md 用户指令覆盖件 + GATE 1 恢复复验全绿 2044:0:0 + web 层 r165 态重建（含 KERF_EXAMPLES 现代化 + playground/check API 路由 .ktf 修复）。

## 1. D1-D10 裁定

- **D1（层级度量单源）**：函数层级 = fn 体块括号计为第 1 层，内部每层嵌套块 +1（tools/audit/ktf_quality_audit.py 词法扫描——字符串/注释剥离后计数）。**违例判据 = 层级 > 4（即体内嵌套 > 3 层）**——与 TD-040 登记口径对齐（r165 实测 77 件 ≈ 本口径恢复期实测 79 件；严格口径 >3 为参考面）。审计脚本入档 `tools/audit/`（R4——r165 原档 `/home/z/audit_tmp/` 仓外遗失教训：工具必须仓内存续）。
- **D2（平链等价律——零行为构造性保证）**：`else { if (C) { A } else { B } }` ≡ `else if (C) { A } else { B }`，当且仅当 else 块内**恰含一条语句**（一个 if 表达式）且无其他语句（空白/注释除外）。改写工具 `tools/audit/flatten_else_if.py`（括号匹配词法扫描 + 单语句校验 + 包装括号剥离 + fixpoint 迭代——每轮每链消解一层）。**等价性由构造保证**：块的值 = 其唯一表达式 if 的值；控制流图同构。
- **D3（分拆律）**：span > 80 行的函数分拆为「调度器 + 族助手」形——保持**分派序逐位不变**（有序 if 链的臂序 = 语义序：`...` 先于 `..` 等既有顺序约束）。助手形：尾部续接（helper 末臂 `else { next_helper(...) }`）或先行判定（判据族先分流）。**单一职责裁定**：每助手 = 一个词法族 / 一类表达式族 / 一类规则族。
- **D4（零行为门三件）**：①全量测试套 2044:0:0 逐位维持（种子链重建后语义回归）+ ②审计复跑 125:0（architecture_audit 6 + seed_ktf_parity 119——**seed_ktf_parity 即双 Reader 字节级 parity 门**）+ ③CLI 行为探针族（fib⇒75025/144 + closures⇒42 + check 2/9/5/38 + sum_rest 0/15 + match/effect 语料族值锚）。
- **D5（审计门测试化）**：新增 `ktf_quality_door_tests`（Rust 侧）——断言 ①平链位点点数 = 0（`else {` 单 if 包装器绝迹——防堆叠回归门）②深度/span 快照对账（Batch 1 边界诚实登记：span>80 = 0 + 深度>4 名单冻结为登记快照供 Batch 2 对照）。门逻辑 = D1 度量的 Rust 移植（词法剥离 + fn 体深度扫描）。
- **D6（struct/enum 审计腿——用户指令④对账）**：**登记态现状**：复合类型 struct/enum = Stage 2+ 类型系统演进登记态（02-syntax-model.md §「类型系统成员登记态」——基础类型 i8-i64/u8-u64/f32-f64/bool/char/str/() + 复合 + 泛型 + union + 交叉 + 行类型 + 效应行 + 线性能力俱登记；Stage 0 生产面 = HM 单态推断 + 多错误收集）。**裁定：零信号不开窗**（原则 38/44——理论/愿景语料按登记态处理）；本窗仅落审计对账行，语言面零变更。
- **D7（eq/quote 现状对账——用户指令③残留项）**：**eq**——r162 TD-037 相等域窗已兑付「== 扩域至 eq 语义」（现代面 == 跨值域结构相等；内核 eq = as-if-written 脱糖目标——one-face-one-name 轨迹已走完）；**quote**——Level 0 核心形「数据/符号字面量构造面」（`'x` S-expr 简写已随 r153-r154 拆除退役；现代面 `quote(x)` = 不可求值数据构造——Rust/Scala `:sym` 级合法承载；expander 标签族 `quote(sym)` 消费为符号字面量）。**裁定：两者俱已处现代位，零本窗变更**。
- **D8（Batch 2 触发式登记）**：残余真嵌套（登记口径 44 件——`} else { if` 堆叠以外的控制流嵌套：循环内判定内判定族）+ Track 3 短名清洗（形参 ≤2 字符 28.3% / let 局部 49.7%）→ TD-040 登记面更新为「Batch 1 清偿〔平链类 + span 类〕+ Batch 2 余项〔嵌套提取类 + 命名类〕」。触发 = 用户指令存量面行权（本指令族连续出现即开）。
- **D9（测试构成）**：新增审计门测试 ≥8 case（正负比 1:3——正向〔门通过面：平链零位点 + span 零违例 + 深度快照命中〕+ 负向〔门拒绝面：构造堆叠样例断言检测器命中 + 深度违例样例 + span 违例样例 + 非单语句 else 块不误报 + 字符串内括号不误计 + 注释内括号不误计〕）；集成验证 = D4 三件门 + 语料族值锚。
- **D10（工具链纪律）**：两工具（ktf_quality_audit.py + flatten_else_if.py）入档 `tools/audit/` + docs/tools 同步（R4）；工具自身 ≤80 行/函数纪律（python 侧同等遵守——以身作则）。

## 2. 实施链（预期）

1. **237-c1 Track 1**：flatten_else_if.py 应用七件（reader 174 + expander 113 + check 11 + compiler 10 + list 13 + build 2 + preamble 1 = 324 位点）→ fixpoint 复验零位点 → 冒烟（build + 定向测试子集）。
2. **237-c2 Track 2**：九件分拆（compile_expr 168 / lex_op 132 / expand_core_form 113 / tc_unify 102 / parse_primary 101 / postfix_loop 97 / tc_infer_app_general 92 / parse_pattern_atom 88 / tc_rule_one 81）——逐件「读-拆-测」小循环（每件拆后跑定向测试 + CLI 探针）。
3. **237-c3 审计门**：ktf_quality_door_tests 落位 tests/v0/stage3/plan/ + runner 挂载。
4. **237-d GATE 1**：六命令全量 + D4 三件门 + bench 带内。
5. **237-e 治理**：TD-040 Batch-1 部分清偿注记 + RELEASE r166 节 + matrix + t3plus + README + rec + 根层 worklog。
6. **237-f 交付**：r166 包三验 + web 五件同步 + E2E + 投票 + worklog 双追加。

## 3. 风险与缓解

| 风险 | 缓解 |
|---|---|
| 平链改写破坏种子链（build 失败） | 构造性等价律 D2 + fail-closed build + 全量套逐位门 |
| 分拆破坏分派序（语义漂移） | D3 臂序逐位保持 + 每件小循环定向测试 + 值锚探针 |
| 深度计数口径漂移 | D1 度量单源入档 + 审计门快照冻结 |
| 审计门误报（字符串/注释内括号） | D5 门逻辑复用 D1 剥离器 + 负向测试覆盖误报面 |

## §9. 诚实边界

1. **Batch 1 ≠ TD-040 全清**：残余嵌套 44 件（登记口径）+ 短名族 → Batch 2 触发式（D8）。
2. **深度>3 严格口径残 88 件**：本窗以登记口径（>4）为验收面；严格口径为参考面（Batch 2 目标面）。
3. **`else if` 链不缩短 span**：平链化消深度不消行数（lex_op 168→132 为括号行消解的副产品）；span 清偿由 Track 2 分拆兑付。
4. **审计门快照非全零门**：深度快照 = 冻结 Batch 1 边界（防回归），非断言全语料 ≤4（Batch 2 兑付后才可升格）。
5. **分拆助手的命名**：本窗命名随分拆落位（族名语义化）；全语料短名清洗 = Track 3 Batch 2（避免本窗大规模重命名与行为验证耦合）。

# 旧时代残留清偿窗方案（Legacy Residue Clearance Plan）

> **版本**：v1.0（r156 / 226-a——TD-035 Batch 2 行权载体）
> **Status**: Closed（r156 全窗交付——226-a..g 全链；对账见 worklog 226 条目族）
> **行权依据**：用户四链指令①「深度审查项目中是否存在遗留旧时代的编码方式和内容（全面转向现代前沿理论表示……S 表达式相关结构或表现等）+ 完全重构 readme 文件和 web」= TD-035 触发条件①（用户指令直接开窗）——M1 指令开窗第六十一例。
> **上位单源**：naming-standardization-plan.md v1.0（D8 Tier 3 登记 + Batch 2 触发式行）；tech-debt-register TD-035；t3plus v1.75 r155 消费注记（14 行零信号——本轮开 TD-035 窗非 T3+ 行非切换窗）。

## §1 残留全量盘点（r156 轮实测——2026-10）

| # | 残留类 | 实测面 | 量级 | 判定 |
|---|---|---|---|---|
| 1 | `.krf` 文件 | 仓库全域（target/.git 排除） | **0** | r154 终局维持（零残留） |
| 2 | S-expr 标识符（词边界 `sexpr`/`s_expr`/`SExpr`） | crates/ src/ | **0** | 代码面已净（r155 Batch 1 兑现） |
| 3 | Tier-3 测试局部名 | tests/ + crates/（15 文件） | **~127 点** | 本窗清偿（§3 D2） |
| 4 | 生产私有 fn 逃逸名 `target_err_form` | crates/kerf-driver/src/bootstrap/reader.rs | 3 点 | 本窗清偿（Batch 1 API 族之外的私有名逃逸——§3 D2） |
| 5 | S-expr/时代术语注释字样 | crates/ src/ | 108 处 | 分流裁定（§3 D3：历史注记 KEEP / 现行机制描述失真面 UPDATE） |
| 6 | 时代消息文本（`.krf` 拒收诊断族 + usage 行） | src/main.rs 两处 + 断言锚 | 2 条 | 本窗现代化 + 锚同步（§3 D4——TD-035 ②面行权） |
| 7 | README 时代形态（巨型单行状态注记堆叠） | README.md | 1 件 | 完全重构（§3 D5——用户明示） |
| 8 | web 页时代注记 | src/lib/kerf-data.ts 族（web 工程） | 五件 | 完整更新（§3 D6——用户明示） |

## §2 S-expr 演进叙事（用户问「S 表达式计划用什么替换或者演进设计」的方案层答复——本节为对账单源）

**S-expr 计划的终局与后继**：s-expr-removal-plan.md v1.5 **Status Closed @ r154**——S-expr 面拆除不是一个「待替换」计划而是一个**已完成的替换工程**，其后继设计分四层钉死：

1. **皮肤层（用户可见语法）**：现代 kerf 皮肤 = S-expr 面的唯一后继——`fn f(x: i64) -> i64 { ... }`（define 函数糖）/ `|| (p: T) { body }`（闭包）/ `let x = 1, y = 2;`（多绑定）/ `if (c) { a } else { b }`（cond→右递归）/ `[a, b, c]`（向量字面量）/ `import kerf_string as s;`（命名空间）/ `perform e`·`handle`（效应皮肤）/ `macro m { (pat) => tpl }`（宏皮肤）。映射正源：e6-conversion-guide.md 皮肤字典 + lang-design/02-syntax-model.md。
2. **IR 层（非「遗留」——冻结内核表示）**：内部 Stx datum（pair/list/symbol）与 CoreExpr 是 8 原语内核的冻结表示（§11 单一 Reader 产出），**不属 S-expr 残留**——S-expr 拆除窗拆的是「面」（文件格式/入口/API），不拆「核」（datum IR）。8 原语不变性第三十八轮维持。
3. **工程层（拆除轨迹）**：五批六轮（A 构建系统 r149 → B check 面 r150 → C Reader fixpoint r151-r152 → D 用户面 r153 → E6 收口 r154）+ 命名标准化两批共轭（r155 Batch 1 生产面「target」限定词退役 + **r156 Batch 2 残响面清偿 = 本窗**）——「one face, one name」轨迹的收尾步。
4. **余响层（本窗对象）**：S-expr 时代的**词汇残响**——测试局部名（`target_value`/`assert_target_reader_*`/`neg_target_*`/`hm_target`/`seed_front_target`/`target_err_form`）、消息文本时代措辞（「target-syntax file」——r153 时 target 尚是双面之一，r155 后 target 即唯一面，限定词失去指称对象）、注释中「以旧面为新面定位」的失真描述。清偿后仓库的「时代词汇」仅存于两类合法位置：历史转换注记（E6 close-out 头注等——§8.6 只追加纪律的文档性事实）与治理文档历史段（s-expr-removal-plan/switch-window-plan 等——档案本体）。

**目标语言中「遗留 S-expr 结构」的完备分类**（用户问「当前目标语言中遗留的 S 表达式相关结构或表现」）：
- **表现层**：零（.krf = 0 / S-expr 入口 fail-closed 拒收 exit 2 / CLI 单面 .ktf）；
- **诊断层**：拒收诊断文本携带 S-expr 历史事实陈述（合法——但「target-syntax file」限定词失真，本窗 D4 修）；
- **IR 层**：Stx/CoreExpr pair-list 表示（合法冻结内核——非残留）；
- **词汇层**：Tier-3 局部名 + 注释残响（本窗 D2/D3 清偿）；
- **文档层**：历史段与转换注记（合法档案——KEEP）。

**现代前沿语法对 S-expr 的替换认知框架**：替换不是「翻译」而是「换脸保核」——皮肤字典（e6-conversion-guide §2）给出 1:1 皮肤映射，转换纪律四新锚（r152 登记）+ 承载裁定族（quote() 载体/未闭合字符串/while 复得/n-ary 调用形）固化「面变核不变」的等价基线；1788:0:0 测试基线 + 审计×6 EXIT 0 为等价性的持续证据链。

## §3 裁定（D1-D8）

- **D1（行权定性）**：本窗 = TD-035 Batch 2 全量行权（①测试局部名 Tier 3 + ②消息文本现代化）+ 用户明示扩展面（README 完全重构 + web 完整更新 + 演进叙事对账§2）。L2 常规轮（三指标见定位声明）。
- **D2（Tier-3 局部名退役字典——序敏感，长名先短名后）**：
  | 旧名 | 新名 | 范围 |
  |---|---|---|
  | `target_value` | `run_value` | 10 测试文件 ×80 点（helper：跑源码返渲染值） |
  | `assert_target_reader_stx_parity` / `assert_target_reader_err_parity` | `assert_reader_stx_parity` / `assert_reader_err_parity` | switch_corpus_parity_tests ×20 |
  | `target_err_form` | `read_error_form` | bootstrap/reader.rs 生产私有 fn ×3（Batch 1 逃逸名——冲突预扫描义务） |
  | `neg_target_*` | `neg_*` | ktf_vector_value_tests ×5 |
  | `hm_target` | `hm_check` | hm_inference_tests ×2（冲突预扫描义务） |
  | `seed_front_target` | `seed_front` | ×2 |
  | `sexpr_source_in_target_entry_rejected` | `retired_sexpr_entry_rejected` | ×1（历史可溯值以新名保形 + 体注保持 r153 收敛语义记述） |
  | `target_syntax`/`in_target` 单点 | 逐件上下文裁定（注释/变量名同步 D3 字典） | ×2 |
- **D3（注释分流字典）**：KEEP = 历史转换注记（「E6 close-out (r154 / 224-b): converted to…」头注族——文档性事实，§8.6）+ 历史机制记述（「the S-expr face has no halt/pass」——描述拆除判据的对照事实）；UPDATE = 现行机制描述失真面——以「target Reader/the target-syntax face」指称**唯一现存面**的注释（r155 后 target 限定词失去指称对象——去限定词或改「the Reader/the kerf-syntax face」）+ main.rs 模块头注的失真段。改动纪律：只动指称，不动事实；每文件头注若为 E6 历史记述则整段保持。
- **D4（消息文本现代化 + 锚同步）**：①拒收诊断 `error: '{}' is not a .ktf target-syntax file; the S-expression entry is retired (r153 / s-expr-removal Batch D) -- rename or rewrite the source as .ktf target syntax` → `error: '{}' is not a .ktf kerf source file; the S-expression surface is retired (r153) -- rename or rewrite the source in kerf syntax`；②usage 行 `syntax entry: .ktf target syntax (single face -- the .krf S-expr entry retired r153 / s-expr-removal Batch D)` → `syntax entry: .ktf kerf syntax (single face -- the .krf S-expr entry retired r153)`。锚同步验证：cli_entry_convergence_tests 断言面 = `stderr.contains("retired") && stderr.contains(".ktf")`（宽松锚——新文本双词俱含，零断言改动预期；仍须实测复跑）。
- **D5（README 完全重构）**：巨型单行状态注记堆叠形态 → 现代 README 结构（项目一行/30 秒了解/现代语法示例/架构/质量状态精简化[历史链压缩至 ROADMAP 与 RELEASE_NOTES]/快速开始/演进叙事段[S-expr→现代语法故事——§2 溯源]/文档索引）。历史信息零删除义务：压缩至治理文档既有承载（matrix.md 增量行族 + RELEASE_NOTES r-* 节俱在——README 不再作时间线堆场）。
- **D6（web 完整更新）**：kerf-data 五件（ROADMAP r156 前插 + HERO_FEATURES + PACKAGE_CONTENTS + hero/footer 徽章与版本注记）+ download README r156 节 + stats 双源对账自动派生面核验；r155 压缩链保持（§8.6 零历史删除）。
- **D7（不变量）**：零行为变更（纯重命名+文本+注释——字节码自洽预期不变）；测试计数 1788 零增减；消息文本变更以锚实测复跑兜底；git mv 不适用（无文件更名）。
- **D8（保留面 KEEP）**：治理文档历史段（s-expr-removal-plan/switch-window-plan/e6-conversion-guide 历史节）；E6 转换头注族；`TargetTriple`/`supported_targets`/`collect_import_targets`（D8 非语法时代语义——r155 已裁定）；宏卫生 `tmp$hyg$` 等机制名；Stx/CoreExpr 内核名。

## §4 验收（量化）

1. 六命令全绿：build 0 告警 / check 0:0 / fmt 零 diff / clippy -D warnings 0 / **test --workspace 1788:0:0 逐位保持**（RUST_MIN_STACK=33554432）/ 审计×6 真实 EXIT 0 ×6；
2. CLI 零回归八探针：fib ⇒75025/⇒144 + check ok + **.krf 拒收 exit 2（新文本）** + tokens + test PASS + bench 带内（~77ms 量级）+ multiarm 217 + nested_resume 540；
3. 残留归零验收：`grep -rn "target_value\|assert_target_reader\|neg_target_\|hm_target\|seed_front_target\|target_err_form" --include="*.rs"` = 0（KEEP 清单除外——本字典无 KEEP 项于该模式族）；
4. README 重构交付（结构化节 + lint 无死链）+ web E2E 四探针（GET / 200 含 r156 徽章 + GET /api/stats 双源对账 + POST /api/playground .ktf 运行 ⇒ 值 + dev.log 零新错）+ `bun run lint` EXIT 0；
5. §19 打包三验（成员数 + sha256 + 独立解包净构建复跑 1788:0:0）。

## §5 波次与 Task ID

226-a（本件）→ 226-b（Tier-3 退役——子代理）∥ 226-c（注释现代化）∥ 226-d（消息文本+锚）→ 226-e（README 重构）→ 226-f（GATE 1 + 治理回写七件）→ 226-g（§19 打包 + web + E2E）→ 226-close（§6.3 投票收口）。

## §6 治理回写清单

matrix.md r156 增量行 + 总量行维持；RELEASE_NOTES.md r156 节；README.md 状态行（新形态）；t3plus v1.76 r156 消费注记（14 行零变化——TD-035 窗非 T3+ 行）；tech-debt-register TD-035 **清偿关闭**；naming-standardization-plan.md Status → Closed（Batch 2 = r156 交付注记）；本件 Status → Closed。

---
*遵循：§1.2（L2 路由）/ §2.3-11（能力边界不清即查——S-expr 残留分类以 e6-conversion-guide + s-expr-removal-plan §13 对账为正源）/ §8.4.5（文档以实况为准——D3 失真面修正）/ §8.6（只追加——历史注记 KEEP 裁定）/ §12（最优>最小——README 重构非补丁）/ §20.3（同类路径全量审查——127 点全枚举非抽样）/ 原则 41（拆除判据——残响清偿 = 拆除窗工程收尾步）。*

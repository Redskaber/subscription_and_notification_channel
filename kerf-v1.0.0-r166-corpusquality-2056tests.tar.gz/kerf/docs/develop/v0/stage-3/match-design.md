# match 模式匹配设计文档（目标语言 Level 0 域内首位域外构造解锁件）

> **Author**: kerf-dev-agent（ARCH-A——设计先行；r107 / 177-d）
> **Date**: 2026-11-03（**r124 / 194-a——M-4 实施批交付**：§6 批表 M-4 行 ✅ + 双 Reader 分歧窗闭窗注记 + §3.0 镜像面补充）；2026-11-03（**r123 / 193-a——M-3 实施批交付**：§4 M-3 实施裁定五条入档[无守卫严化 / 顶层收集 or 展平 / 模式结构豁免诚实边界 / 门后置折叠 / 纯诊断批] + §6 批表 M-3 行 ✅ + 兑底残余可达类精化注）；2026-11-02（**r122 / 192-a——M-2 实施批交付**：§3.4 正典产物裁定入档 + §6 批表 M-2 行 ✅ + §3.2 谓词精化注 + 守卫 E0004 同族注）；2026-11-02（**r121 / 191-a——M-1 实施批交付**：§3.0 中间形裁定入档 + §6 批表 M-1 行 ✅ + 双 Reader 分歧窗登记）；2026-10-22（r107 / 177-d）
> **Version**: v1.4（**r124 M-4 实施注记**：.krf 镜像同步落地——bootstrap/target_reader.krf match 语法臂三函数族[parse-match/match-arms-loop/match-arm 族 + parse-pattern-or/pattern-or-loop/parse-pattern-atom/pattern-group-or-loop——种子 r121 parse_match 家族逐函数同构移植] + 语句位分派翻转[parse-stmt-or-expr 的 match 域外诊断退役→parse-match] + 表达式位臂[parse-primary——r110 表达式位 if 先例同构分派]；**双 Reader 分歧窗 M-1..M-3 闭窗**[match_m1_reader_tests 分歧窗锚点翻转——镜像侧从域外诊断改判字节级同渲染]；match_m4_krf_mirror_tests 15 case 新门族[语法 parity 正向两族{r121 全语料族 + 位置形六面} + 负向十一族{消息+Span 字节级镜像——零臂/三元/裸 or 混逗号/括内 or 混逗号/右元 or/限定名/缺 =>/未闭合/非模式 Token/缺臂分隔/深度帽 9×2} + 词法 parity 维持 + 跨阶段消费{镜像 Reader→自举 Expander→自举 Compiler→VM 全链 E2E ⇒ 161}] + 净 +15 测试 **1300:0:0**；M-1..M-4 全批完成——match 实施窗全闭）；v1.3（**r123 M-3 实施注记**：§4 穷尽性保守规则三条实施化 + 五条 M-3 裁定入档[§4 实施裁定段]——种子侧 match_desugar.rs check_exhaustive/pattern_is_total/scan_top_bools/or_marker_items + 自举侧 expander.ktf match_exhaustive 族[match_pat_total/match_pat_has_bool/match_arms_total/match_arms_have_bool 双面构造性同构]；诊断码 = **E0025**[E0001-E0024 后次号——与 E0002 族同通道渲染零新通道]；M-2 四测试协同收窄[模式全族/嵌套序对/dual_path 双语料补通配终臂 + 运行时兑底测试改残余可达类语料] + match_m3_exhaustiveness_tests 16 case 新门族[正向五族 + 负向十族 + 消息面双路径字节镜像 + 结构诊断优先序 + 兑底残余类 + check 通道 E2E + 目标面门 + 闭域 parity 三向] + 净 +16 测试 **1285:0:0**；M-4 待——按推荐序或用户指令序）；v1.2（**r122 M-2 实施注记**：种子侧 match_desugar.rs + 自举侧 expander.ktf expand_match 双面同源实施[§3 语义表全量——正典产物形状 §3.4 单源] + Keyword::Match 入面[第 26 关键字——E0020 面双侧扩展] + compiler.ktf 潜伏缺陷顺带清偿[handle 体 nlocals bump 覆盖——r50-β 同族] + match_m2_desugar_tests 18 case 门族[跨语法字节码 parity 六族 + 双路径 parity + 运行时双路径 + 负例族消息面镜像 + HM 集成 + 守卫效应序锚 + M-1 边界翻转 + 嵌套/臂隔离锚] + 净 +18 测试 **1269:0:0**；M-3/M-4 待——按推荐序或用户指令序）；v1.1（**r121 M-1 实施注记**：种子侧 Reader 解析域开放[parse_match + 模式文法全量 + 域外诊断退役] + 中间形裁定三条入档[§3.0——or 标记形 / 括号内至多二元 / 深度帽 8] + match_m1_reader_tests 10 case 门[结构/负例/跨语法 parity/边界锚] + 净 +10 测试 1251:0:0；M-2/M-3/M-4 待——按推荐序或用户指令序）；v1.0（首件——#5 义务激活兑现：t3plus v1.26「切换窗已开——match 设计文档 = 窗内首日义务候选」；[target-language-gated-tasks §2 #6]（./target-language-gated-tasks.md）门控解锁的判定前置）
> **Status**: Active（**M-4 ✅ r124——M-1..M-4 全批完成，match 实施窗全闭**：.krf 镜像同步落地[target_reader.krf match 语法臂——双 Reader 分歧窗闭窗 + 锚点测试翻转]；语义（M-2 脱糖双侧）+ 诊断（M-3 E0025 双侧）+ 语法（M-1 种子 + M-4 镜像）三义务面全兑现；后续 match 相关演进 = 类型驱动穷尽[原则 26——Stage 2+ 候选登记态] / 结构化模式[类型声明族独立窗] / 向量字面量模式[TD-002 触发式三判据联动]——均按触发式纪律零信号不开窗）
> **上游单源**: [02 §8.13](../../../lang-design/02-syntax-model.md)（EBNF v9
> 语法权威——Level 0 定稿域 + 定稿域边界纪律）/ [12 §2.4.1]
> （../../../lang-design/12-roadmap.md）（目标语法蓝图——match 蓝图位）/
> [17 原则 31](../../../lang-design/17-principles.md)（皮肤/骨架同构）/
> [20 §12 D2 + §14](../../../lang-design/20-surface-conventions.md)（皮肤字典
> 六映射 + 定稿域扩充）/ 原则 42（错误处理统一而分治——编译期诊断正交）/
> 原则 43（渐进披露）/ 24 号件（空间从属——核心前端域）
> **触发背景**: 切换窗开窗（r106 治理闸门②首次满足）→ t3plus #5 行
> 「match 模式匹配设计文档」义务激活（窗内首日义务候选）→ r107 兑现。

---

## 1. 定位与设计义务

**一句话定位**：match 是目标语言 Level 0 表面的**模式匹配皮肤**——
按原则 31（皮肤/骨架分离），其编译产物恒为既有核心形式（条件链 +
绑定 + 相等测试），**零新原语、零通道增量**（8 原语不变性第十轮
验证锚——本设计不触碰内核）。

**设计义务三件**（门控任务 #6 解锁判定的充要面）：

1. 语法域义务：EBNF 产生式（Level 0 定稿域内追加——match 属 22 定稿
   词面已登记位，语法本体经本文件定稿后方可入 Reader 解析域）；
2. 语义义务：脱糖路径单源（目标面 → S-expr 面 → CoreExpr 的完整映射
   链——与皮肤字典 D2 六映射同构衔接）；
3. 诊断义务：穷尽性编译期检查（错误提示信息系统面——原则 42 编译期
   诊断正交：match 诊断与效应/类型检查器互不侵入）。

**域外维持声明**（诚实边界）：本设计只覆盖**值级模式**（字面量/
绑定/通配/序对拆构/or 模式/守卫）。以下维持登记域外：结构化模式
（struct/enum 构造器——类型声明族独立窗）、向量字面量模式（TD-002
触发式三判据联动——语料 `#(` 消费面）、区间模式（`..` 登记域）、
嵌套深度 >8 的模式（防御性栈保护——与 parse-list 256 深度上限同锚
但收紧至模式域）。

## 2. 语法域（EBNF 产生式——Level 0 定稿域内追加）

```ebnf
(* match 表达式（Level 0——语句位与表达式位同形：块尾 = 表达式值；
   非块尾 = 语句丢弃值——与 if 语句同规[r106 D2 块穿线裁定同构] *)
match_expr      = kw_match expr "{" match_arm {match_arm} "}" ;
match_arm       = match_pattern [match_guard] fatarrow expr "," ; (* 尾臂逗号可省 *)
match_guard     = kw_if expr ;                    (* 守卫——臂内二次筛选 *)
match_pattern   = pattern_or ;
pattern_or      = pattern_atom {"|" pattern_atom} ; (* or 模式——闭界 *)
pattern_atom    = pattern_literal
                | ident                             (* 绑定 *)
                | "_"                               (* 通配 *)
                | "(" [pattern_list] ")"            (* 序对/空模式 *)
                | "(" pattern_first "," pattern_rest ")" ; (* 拆构 *)
pattern_list    = pattern_or {"," pattern_or} ;
pattern_first   = pattern_atom ;
pattern_rest    = pattern_atom ;                    (* 二元拆构——右不嵌套 *)
pattern_literal = int_literal | float_literal | string_literal
                | "true" | "false" | "()" ;         (* nil = "()"——皮肤字典 *)
```

**词法依赖**（全部已在 target.rs 词法层就位——r106/r107 零增量）：
`kw_match`/`kw_if`（关键字族）、`fatarrow`（`=>`）、`"|"`（or 位——
词法已产出 `|` Token，语法域内语义 = or 分隔而非位或）、`"_"`（ident
词面下划线——模式位语义改判）、括号/逗号族。

**定稿域边界纪律对账**（02 §8.13）：match 产生式入 Level 0 定稿域的
前置 = 本文件定稿（设计单源）→ 02 §8.13 增补行（语言面规范锚）→
Reader 解析域开放（实施批）。**词面零新增**（`match` 已在 22 定稿词面
表——关键字经济全域适用维持）。

## 3. 语义设计（脱糖路径——皮肤字典 D2 第七映射）

### 3.0 Reader 中间形（M-1 交付态——r121 / 191-a 裁定入档）

M-1（Reader 臂）交付的目标面 → S-expr 面直接映射（**臂结构直映**——M-2
脱糖的消费契约单源）：

```
match x { 0 => "零", n if n < 0 => "负", _ => "多" }
→ (match x (0 "零") (n (< n 0) "负") (_ "多"))
```

- **match 形**：`(match scrut' arm1' arm2' ...)`——头符号 `match`；
- **臂形**：`(pattern' body')` 或 `(pattern' guard' body')`——长度分立
  （2 = 无守卫 / 3 = 守卫居中），对 M-2 脱糖无歧义；
- **模式中间形**：字面量 → Stx 字面量（nil = `()` 皮肤）；标识符 → 绑定
  符号（`_` 通配符——位改判延迟至 M-2）；序对 `(p, q)` → 恒二元列表
  `(p' q')`；分组 `(p)` → 恒等；or 模式 → `(or p1' p2' ...)` 标记表。

**三条消歧裁定**（EBNF 字面优先 + fail-closed 登记）：

1. **or 标记形**：`|` 为保留运算符 Token（不可为绑定名）→ 标记头无碰撞；
   序对恒二元 vs or 标记表 ≥3 元——长度域不交；
2. **括号内至多二元**：`(p)` 分组恒等 / `(p, q)` 二元拆构（两侧元素须为
   pattern_atom——裸 or 链 fail-closed 带括号提示）`（p, q, r）` 三元
   fail-closed「至多二元」；括号包裹嵌套按 EBNF 字面合法（右不嵌套
   = rest 位 pattern_atom 的字面解读，深度帽限界）；
3. **深度帽 8**：嵌套 >8 fail-closed（§1 防御性栈保护字面——与
   parse-list 256 同锚但收紧至模式域）。

**M-1..M-2 诚实边界（已消除）**：中间形经展开/编译为伪应用（双路径一致）通过，
失败点 = 运行时未绑定全局 `match` 诊断；M-2 落地脱糖后消除（r122 兑现——
边界锚测试翻转在档）。
**M-1..M-3 双 Reader 分歧窗（已消除）**：.krf 镜像侧曾维持域外诊断（锚点
测试在档）——r124 M-4 语法批同步闭窗（镜像侧 match 语法臂落地 + 锚点翻转为
字节级同渲染 + 消息/Span 镜像负例族全绿——分歧窗 M-1..M-3 存续期三批
r121-r123 诚实登记，r124 收口）。

### 3.1 核心裁定：脱糖而非核心形式

**match 不入 CoreExpr**（新增核心形式 = 违反最小原语集合 + 8 原语
不变性）。脱糖路径（目标面 → S-expr 面 → 核心形式）：
```
目标面:   match x { 0 => "零", n if n < 0 => "负", _ => "多" }
             ↓ Reader 皮肤字典映射（D2 第七映射——match 臂结构直映）
S-expr 面: (cond ((= x 0) "零")
                   ((and (< x 0) ...) "负")     ; 守卫经 and 合成
                   (else "多"))
             ↓（绑定臂经 let 包装——下方 §3.3）
核心形式:  If[Eq[Var x, Lit 0], Lit "零", If[And[Lt[...], ...], ..., ...]]
```

### 3.2 模式语义表（模式 → 测试谓词 + 绑定动作）

| 模式 | 测试谓词（S-expr 面） | 绑定动作 | 备注 |
|---|---|---|---|
| 字面量 `L` | `(eq scrut L)`（r122 精化——原示意 `=`：数值链族对 Bool/Nil 报错且 Int/Float 跨型；见 §3.4 裁定 1） | 无 | int/float/str/bool/unit（nil 皮肤 `()`） |
| 绑定 `n` | 无（恒匹配） | `(let ((n scrut)) body)` | 绑定 = 全捕获（Rust 同形） |
| 通配 `_` | 无（恒匹配） | 无 | `_` 在模式位 = 词法 ident、语法通配（位改判） |
| 序对 `(p, q)` | `(is-pair scrut)` | 路径直取 `(head scrut)`/`(tail scrut)` 链（r122——§3.4 路径提取裁定；设计原 h/t 绑定示意图等价） | 二元拆构（Right 不嵌套——防无限型） |
| 空模式 `()` | `(is-nil scrut)` | 无 | nil 字面量的模式位形态 |
| or `p \| q` | `(or test_p test_q)` | 绑定映射（名+位置）**必须全同**（否则编译期诊断「or 模式绑定集不一致」——r122 严化：名集相等而位置相异同拒；见 §3.4 裁定 3） | 闭界 or |
| 守卫 `if e` | `(and test arm_guard_e)` | 守卫求值可见本臂绑定 | 臂内二次筛选；守卫 = bool 型条件（E0004 同族——§3.4 裁定 2） |

### 3.3 绑定可见性（臂作用域）

每臂的绑定在臂表达式（含守卫）内可见，臂间零泄漏——脱糖为嵌套
`(let ((n scrut)) ...)` 包装（S-expr 面 let 作用域穿线同构——r106
块穿线裁定复用）。**scrutinee 单次求值**：脱糖前置
`(let ((tmp scrutinee_expr)) ...)`（避免重复求值副作用——效应语义
下 perform 位 scrutinee 的单次语义契约）。

### 3.4 正典产物形状（M-2 交付态——r122 / 192-a 裁定入档）

M-2（脱糖批）的**产物形状单源**——种子 Rust（`kerf-expander/src/match_desugar.rs`）
与自举 .ktf 镜像（`bootstrap/expander.ktf` expand_match 族）按本节构造性同构
（字节码 parity 门六族实证）：

```
(match scrut arm1 ... armK)
  → (let ((m scrut)) chain)
m      = "match-scrut$hyg$N"——每脱糖点一枚临时名，全局单调 N
        （§3.3 单次求值契约；全局计数器严于宏 α 通道逐点位计数器：
        姊妹/嵌套脱糖永不重名，(name, scopes ⊆) 最大基数并列消除）
chain  = 臂右折叠，rest0 = (error "匹配失败：无臂匹配")（§4 防御性
        运行时兜底——M-3 穷尽性诊断降低其可达性）
arm    = (if test_full product rest)：
  test_full：  T=无, G=无 → 字面量 true（均匀链裁定——脱糖层零死码消除：
               死臂保持展开与诊断[报错>静默]；消除归 Stage 2+ 优化器域）
               T=无, G=g  → (let binds g) | g（binds 空）
               T=t,  G=无 → t
               T=t,  G=g  → (and t X)——短路保证守卫在结构测试通过前不可达
  product：    (let binds body) | body（binds 重提取——temp 上的纯 head/tail
               链；臂绑定永不泄入 rest[§3.3 臂间隔离]）
路径提取：按路径直取（(head m)/(tail m) 链）而非中间 h/t 绑定——零中间
        临时名（仅 scrutinee 一枚），纯重提取语义等价
```

**五条 M-2 裁定**（实施批入档）：

1. **谓词精化（§3.2 表 `=` 示意 → `eq` 实装）**：字面量测试谓词 = `eq`
   （类型严格多态等值）。设计表的 `(= scrut L)` 为示意图——`=` 实为数值链
   比较族（TD-016/TD-011 域规则）：Bool/Nil 审查值将运行时报错 + Int/Float
   跨型相等（`0 = 0.0`）；`eq` 恰为字面量族的单源精确谓词（Int≠Float
   类型严格——模式 `0` 不匹配 `0.0`，锚定在档）。
2. **守卫 = bool 型条件（E0004 同族）**：守卫值流入 if 条件位——非 bool
   守卫运行时 E0004（「if 条件需要 bool」显式 bool 纪律同族；与
   if/cond 条件位同规，非脱糖缺陷）。
3. **or 绑定映射恒等（严于设计字面名集规则）**：各备选模式的绑定
   （名**与**拆构位置）必须全同——动态类型无位置统一通道，逐备选绑定
   提取需 match-tag join point（Level 0 脱糖域外）；名集相等而位置相异
   （`(or (a 0) (0 a))`）同样拒绝（诊断指向不一致备选——§7 问题 1
   裁定兑现：诊断精确性原则）。
4. **模式绑定位 = E0020 绑定面第三层**：模式内绑定名过保留字检查
   （Keyword::from_name）——Stx 层/CoreExpr 层两层防线不识模式形状，
   脱糖层携精确 span 拒绝（「保留字不可绑定」消息面镜像）。
5. **重复绑定 fail-closed**：同一模式内同名二次绑定编译期拒绝
   （Rust 同形——多绑定 let 将静默遮蔽；诊断指向第二次出现处）。

**实施顺带清偿**：compiler.ktf `compile_inner_proto` 写回硬编码参数数覆盖
`proto_bump_nlocals` 回填（handle H/B 体原型 nlocals 归零——handle 体含
let 即「局部槽越界」）——compile_fn 的 r50-β 修复（max(参数数, bump 终值)）
在 inner 路径漏修，r116 D61 三潜伏同族；M-2 脱糖产物首次触发（match 体
含 handle × let 组合），当轮修复（用户指令①「中途穿着缺陷直接推进」行权）。

**用户面消费语料**：examples/usage/match.krf（分类/守卫/序对拆构/or/
单次求值五面——生产路径 E2E ⇒ fib-13）。

## 4. 穷尽性检查（编译期诊断——原则 42 正交面）

**策略：保守健全规则**（零误报优先——check.krf krf ⊆ oracle 保守
宽松化契约同锚 [r80 裁定先例]）：

1. **通配臂存在性规则**：无 `_` 或裸绑定臂的 match → 编译期诊断
   「非穷尽匹配：缺通配臂」（E0xxx 结构化错误 + Span 指向 match 关键字
   + 建议补 `_ =>` 臂）；
2. **闭域枚举豁免**：bool 型 scrutinee 的 true/false 双臂 = 穷尽
   （闭域全枚举判定——Level 0 唯一闭域字面量族）；
3. **不可判定域诚实边界**：int/float/str 字面量族即使多臂也不判定
   穷尽（开放域——仍需通配臂）；类型驱动穷尽（struct/enum 构造器
   域）= 类型观测层联动（Stage 2+ 候选——[16 §类型观测] 登记态，
   本设计不依赖）；
4. **诊断通道**：编译期 E0xxx（与 E0005 HM 诊断同通道——诊断渲染经
   kerf-span 源映射，不新开通道）。

**运行时兜底**：穷尽性诊断漏网（理论不可能——保守规则恒要求通配或
闭域枚举）+ 防御性运行时错误「匹配失败」（VM 面结构化错误——与
越界索引同族）。双层保障 = 原则 42「统一而分治」的 match 面实例。

### 4.1 M-3 实施裁定（r123 / 193-a 入档——双面同源）

五条实施裁定（种子 match_desugar.rs ↔ 自举 expander.ktf 构造性同构；
match_m3_exhaustiveness_tests 16 case 门族钉住）：

1. **无守卫严化**：带守卫的通配/绑定/字面量臂对穷尽性零贡献——守卫
   = 臂内二次筛选，可否决；计入将违反「兜底理论不可达」声明（设计
   字面「无 `_` 或裸绑定臂」的精确化：该臂须**无守卫**）；闭域枚举
   同样只认无守卫字面量臂（`true => …, false if g => …` 不构成穷尽）。
2. **顶层收集 + or 展平**：闭域集合 = 无守卫臂**顶层级**字面量，
   or 标记表展平递归（`(or true false)` 单臂 = 双覆盖）；嵌套序对位
   字面量不计（序对模式携带 is-pair 结构测试——结构上恒非全匹配）；
   总匹配性 = 折叠面 test=None 类的轻量重推导（通配/裸绑定/or 含
   全匹配备选）。
3. **模式结构豁免 + 诚实边界**：bool 豁免不依赖审查值类型——展开
   期无类型信息且 `eq : any→any→bool`（HM 不拦非 bool 审查值）；
   运行时兜底**残余可达类 = 豁免面 × 非 bool 审查值**（模式结构层
   过编译期门 + 类型侧运行时守卫——原则 42 双层实例；§4 首段「理论
   不可能」精确化：结构诊断形不可达；豁免类经设计内放行）。测试锚
   = 双路径 Stage::Run 兜底实证。
4. **门后置折叠**：穷尽性门在折叠成功后触发——结构诊断（臂形/
   模式域/or 恒等/重复绑定/E0020）保持 surfacing 优先序（M-2 负例族
   消息序契约零扰动；测试钉住七组先例消息非 E0025）。
5. **纯诊断批**：脱糖产物与 M-2 字节级全同——均匀链 + 兜底节点在
   末臂 rest 位保持（闭域豁免语料 parity 三向全等实证；零死码消除
   ——消除归 Stage 2+ 优化器域，报错>静默）。

诊断码指配：**E0025**（E0001-E0024 后次号；与 E0002 族同通道渲染——
展开期错误 → Stage::Expand + kerf-span 源映射，零新通道）；消息面双
路径字节镜像（M-3 门族断言）。

## 5. 与既有治理锚的对账

| 治理锚 | 关系 |
|---|---|
| 8 原语不变性 | 第十轮验证：match = 纯皮肤（条件链脱糖）——零新原语零通道增量 |
| TD-002 向量 | 向量字面量模式维持域外（触发式三判据——语料 `#(` 消费面联动；目标语法自然携带集合字面量蓝图位与本设计的 pattern_atom 域外声明一致） |
| t3plus #5 行 | 义务激活 → 本文件兑现 → 实施批后行权态更新（设计文档已交付/实施分批） |
| 门控任务 #6 | 解锁判定：本文件 = 判定前置（语法域 + 语义 + 诊断三义务齐备）→ 实施批 = 切换窗后续（Reader 臂 + expander 脱糖 + 诊断） |
| E5 先例 | 脱糖优先（Level 1-4 候选恒登记态脱糖优先——同纪律：match 全域脱糖路径在位） |
| 22 §27 | 路径分隔符 `::`→`/` 与模式位 `::` 无交集（模式位无路径形态——限定名模式 = 域外） |
| 皮肤字典 D2 | 第七映射（match 臂结构 → cond/let 链）——与既有六映射（define→fn 等）同表登记（20 §12 增补行 = 实施批同步义务） |

## 6. 实施路径（切换窗后续批次——渐进披露分批）

| 批 | 内容 | 验收门 | 依赖 |
|---|---|---|---|
| M-1 Reader 臂 ✅ r121 | target.rs match_expr 解析（模式文法 §2 + §3.0 中间形）+ 域外诊断退役（match 位改判）+ 02 §8.13.1a 增补行 | Reader 单元测试 + 跨语法 parity 扩展（match 语料族——match_m1_reader_tests 10 case：结构/负例/Stx 数据面字节级 parity/分歧窗锚点/伪应用边界锚） | 本文件 §2 定稿 ✅ |
| M-2 皮肤字典第七映射 ✅ r122 | match 臂 → cond/let 脱糖（§3 语义表全量 + §3.4 正典产物形状——种子 match_desugar.rs + 自举 expander.ktf expand_match 双面同源 + Keyword::Match 入面[E0020 26 名]） | 跨语法字节码 parity（match 语料 S-expr 面 cond 等价对照——match_m2_desugar_tests 18 case：parity 六族 + 双路径 + 运行时双路径 + 负例消息面镜像 + HM 集成 + 守卫效应序锚 + M-1 边界翻转 + 嵌套/臂隔离锚）；compiler.ktf handle 体 nlocals 潜伏清偿（顺带） | M-1 ✅ |
| M-3 穷尽性诊断 ✅ r123 | 保守规则三条（§4）+ §4.1 五条实施裁定 + E0025 通道（双面同源：种子 check_exhaustive + 自举 match_exhaustive 族） | 诊断正负测试族（穷尽/非穷尽/闭域豁免/绑定集不一致——match_m3_exhaustiveness_tests 16 case：正向五族 + 负向十族 + 消息面双路径字节镜像 + 结构诊断优先序 + 兜底残余类 + check 通道 E2E + 目标面门 + 闭域 parity 三向；M-2 四测试协同收窄[模式全族/嵌套序对/dual_path 补通配终臂 + 兜底测试改残余类语料]） | M-2 ✅ |
| M-4 .krf 化同步 ✅ r124 | target_reader.krf 语法批含 match 臂（步② 语法批合并承载——parse-match/match-arm 族/parse-pattern-or/parse-pattern-atom/pattern-group-or-loop 七函数族 + 语句位分派翻转 + parse-primary 表达式位臂） | 词法 parity 维持 ✅（match_m4_lexical_parity_maintained——词法层零触碰实证） + 语法 parity 新增 ✅（match_m4_krf_mirror_tests 15 case：正向两族{r121 全语料 + 位置形六面——Stx 正典渲染含 Span 字节级镜像} + 负向十一族{消息 + Span 字节级镜像} + 分歧窗闭窗锚点翻转{match_m1_reader_tests——镜像侧改判同渲染} + 跨阶段消费{镜像 Reader → 自举 Expander → 自举 Compiler → VM 全链 E2E ⇒ 161}） | M-1 ✅ + 步② ✅ |

**批间纪律**：红线 4（零窗口合并）——M-1..M-4 各自独立可验收；
M-4 与切换窗步② 语法批同窗不并批（分批验收）。

## 7. 开放问题登记（设计债——实施批前裁定）

1. **or 模式绑定集不一致的 Span 粒度**：指向 or 整体 vs 不一致绑定
   处（建议后者——诊断精确性原则[错误提示信息系统]）；
2. **守卫内 perform 效应**：守卫求值属臂内效应（效应签名跟随臂表达
   式——[effect-language-design] 既有规则覆盖，无新裁定；实施批以
   测试锚定）；
3. **`@` 绑定子模式**（`x @ (1, 2)`——Rust 形）：域外登记（表达式
   复用需求零语料——关键字经济维持：`@` 词法位保持非法字符）。

---

*遵循条款：原则 31（皮肤/骨架同构——match 编译产物恒核心形式）/ 原则 42（错误处理统一而分治——编译期诊断正交 + 运行时兜底双层）/ 原则 43（渐进披露——M-1..M-4 分批）/ 原则 26（成熟度匹配——类型驱动穷尽 = Stage 2+ 候选登记态）/ 02 §8.13（Level 0 定稿域 + 边界纪律）/ 12 §2.4.1（match 蓝图位）/ 20 §12 D2（皮肤字典第七映射）/ 17 原则 8（最小原语集合——零新原语）/ t3plus v1.26 #5 行（义务激活）/ target-language-gated-tasks §2 #6（门控解锁判定前置）/ switch-window-plan v1.1 §4（域外登记表——match 行本件清偿）/ §8.4.5（设计依据条款号）/ §8.4.6（产物位置——stage-3/ 治理文档族）。*

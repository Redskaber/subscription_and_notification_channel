# read-line 签名条目清偿设计（静态-动态元数 parity 补全——R4 文档债同窗清偿）

> **Author**: Super Z (main) — ARCH-A（裁定）+ PM-A（路由）
> **Date**: 2026-11-14（r144 / 214-b 设计先行腿）
> **Version**: v1.0
> **处理程度**: P0（设计完备——D1-D8 + §7 域外表；实施 = 214-c）
> **开窗依据**: 用户 r144 指令①「继续推进 目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施」+ 指令②「按照 docs/sop.md 流程结合 docs/lang-design/ 下的项目演进流程（整体任务视角）与 docs/develop/v0/tech-debt-register.md、docs/develop/v0/stage-3/t3plus-trigger-audit.md 等（局部任务视角），按照推荐先后任务顺序继续推进」行权（**M1 指令开窗第四十九例**——r74 先例锚「指令即触发」）；推荐序裁定 = r143 收口态登记册触发式实施项全清零 + T3+ 14 行零信号{本轮六族例行监测复测：match 用户面 = r122 交付物本体非新信号 + net/extern/@ 零命中 + next22.md 未上传} + 门控任务七项全闭 → 用户指令①「遇缺陷直接推进」逐行走查全部登记域外表 → 三类不可行排除{Stage 2+ 域外 / 成熟度不在位 / 纯语料信号零张力} → **唯一可行行 = tc-sigs-parity-design §7「read-line 签名条目」行**——且走查实测发现该行触发前提「运行时执法缺位先行」**事实性过时**（运行时元数执法自 FS-4 起即在位——本机 b1730b5 重锚实证 + 09-stdlib §3 r8 注记「元数校验已补齐（FS-4 修复，恰 0 参）」+ 20 §4 B3 契约「read-line 严格元数」三源确证）；同窗 R4 文档债四件当场清偿（builtins.rs 双注释 + check.krf 侧沿袭注释 + negative_vm_tests 模块注释——见 D1 证据 ③）
> **上游单源**: [tc-sigs-parity-design.md §7](./tc-sigs-parity-design.md)（read-line 签名条目登记行——本窗为其清偿载体）+ [member-rename-design.md §7](./member-rename-design.md)（io read 族改名绑定 HM 签名行——read-line 缺位沿袭子项同窗清偿）+ [builtins.rs BUILTIN_SIGS](../../../crates/kerf-driver/src/builtins.rs)（oracle 签名行清单单源 + builtin_sigs/builtin_sigs_with_renames 派生函数 + builtin_name_exists 特例）+ [check.krf TC-SIGS](../../../crates/kerf-driver/src/bootstrap/check.krf)（krf 面签名表 + tc-sig-resolve 链式解析）+ [09-stdlib §3 r8 注记](../../../lang-design/09-stdlib.md)（FS-4 修复锚）+ [20-surface-conventions §4 B3](../../../lang-design/20-surface-conventions.md)（read-line 严格元数行为契约）+ 原则 42（错误处理统一而分治——编译期诊断正交 + 运行时兜底双层）+ r140 TC-SIGS 对齐窗（gated 家族双侧在表先例——read-int/read-num）+ r135 member-rename D12（派生链 miss-skip 诚实边界——本窗翻转其 read-line 实例）

---

## 1. 事实基线（214-a 实测证据链）

### 1.1 双侧现状

**oracle 侧（Rust `builtins.rs`）**：
- `BUILTIN_SIGS`（61 行）：I/O 段 `print`/`newline`/`write-string`/`read-int`/`read-num` 五行在表——**read-line 缺位**；表尾注释（~2062 行）声称「read-line: the runtime does not check arity (extra args ignored) — not listed in the signature table」——**与代码实况冲突**（1563 行 `if !args.is_empty() → Err("read-line requires 0 arguments, got N")` fail-closed 在位）
- `builtin_name_exists`（1385 行）：`if name == "read-line" { return true; }` 特例——「SIGS 61 + read-line = 62 扁平名」补全臂
- `builtin_sigs`（2064 行）与 `builtin_sigs_with_renames`（2087 行）：限定名/改名派生循环「underlying miss 跳过」——read-line 为**唯一在世 miss 实例**；两函数文档注释携带同款过时前提（"the read-line-not-listed rule carries over"）

**krf 侧（`check.krf`）**：
- TC-SIGS（61 行）：read-int/read-num 在表 `'sig 0 0 'any 'unknown`（641-642 行）——**read-line 缺位**
- `tc-sig-resolve`（738 行）：直接命中 → TC-RENAME 链 → 双 miss → nil（通用 A4 Dynamic 路径）——read-line 族当前全落第三臂

**运行时（VM——FS-4 修复在位，r141 b1730b5 统一消息形重锚）**：
- `(read-line 1)` → `error[E0004]: read-line requires 0 arguments, got 1`——**fail-closed 元数执法在位**

### 1.2 张力探针实测（214-a——本机 r143 态全部可复现）

| 探针 | 静态面（check 生产路径） | 运行时（run） | 判定 |
|---|---|---|---|
| P1 `(require io read) (read-line 1)` | `ok: 1 prototype / ...`（**静默通过**） | `E0004: read-line requires 0 arguments, got 1` | **静态-动态行为缺口实证**：静态面弱于运行时契约 |
| P2 对照 `(require io read) (read-int 1)` | `E0005: procedure argument count mismatch: expected 0..0, got 1 (static check)` | E0004 族（同形拒绝） | gated 家族在表先例——静态拒绝正典形 |
| P3 改名 `(import kerf-io (read-line as rl)) (rl 1)` | `ok`（**静默通过**——r135 D12 miss-skip → A4） | E0004（底层同派发） | 派生链诚实边界现状：underlying miss → Dynamic |
| P4 零参 `(require io read) (read-line)` | `ok`（零诊断） | EOF → nil（子进程探针锚——capability_tests 60 行族） | 零参正例两侧恒合法——本窗须维持 |

### 1.3 文档-代码冲突四件（R4 域——以代码为准，本窗提交修正文档）

1. `builtins.rs` ~2062 行表尾注释：「the runtime does not check arity (extra args ignored)」——**代码相反**（1563 行执法在位）
2. `builtins.rs` `builtin_sigs`（2058-2060 行）+ `builtin_sigs_with_renames`（2080-2083 行）函数文档：「the rule that `read-line` has no underlying entry is maintained」/「the `read-line`-not-listed rule carries over」——本窗清偿后前提消灭
3. `negative_vm_tests.rs` 29 行模块注释：「`read-line` does not validate arity (any actuals ignored — see FS-4)」——**同文件 338-346 行测试实证相反**（`read_line_arity` 断言 "read-line requires 0 arguments" 拒绝）
4. tc-sigs §7 登记行载体注「hm.rs 注释（运行时无元数检查）」——hm.rs/typecheck.rs **零 read-line 注释**（注释实位于 builtins.rs）——载体引用失准（翻行时一并修正）

依据：激活协议触发器「文档与代码冲突 → 以代码为准 + 本次提交修正文档（只改其一禁止）」+ §8.4.5（文档层级纪律）+ 09-stdlib §3 r8 注记（FS-4 修复单源确证——文档树内**已有**正确记载，冲突仅限 builtins.rs/negative_vm_tests 两注释位）。

---

## 2. D1：窗口定性（ARCH-A 裁定）

**裁定**：本窗 = 登记域外行清偿实施窗（r140/r141/r142 同族——纯静态签名面窗），非缺陷修复窗。三依据：

1. **登记行触发前提已满足**：tc-sigs §7 行触发判据「运行时执法缺位先行（20 §6.4 ② 历史锚沿袭）」——「先行」条件自 FS-4 起即已成立（r144 走查实测三源确证：代码 + 09-stdlib + 20 B3 契约）。r140-r143 四轮走查以过时前提排除本行——**审计链的 R4 文档债**（审计读注释未读代码），本轮发现本轮修正。
2. **静态面缺口 = 缺失能力非误报缺陷**：`(read-line 1)` 静默通过属「拒收能力缺位」（false negative），不违反 r80 零误报契约（krf ⊆ oracle 方向合法——krf 拒收集合更小）。清偿后静态面获得与 read-int/read-num 同族的拒绝能力——**加性收紧**，方向合法（拒收集合扩大仍维持 krf ⊆ oracle——双侧同增）。
3. **R4 文档债四件同窗清偿**（§1.3）——激活协议硬规则（只改其一禁止）。

**变更面定性**：纯静态签名面（双侧表行 + 派生链前提翻转 + 注释修正）——**零机制变更**（8 原语不变性第二十六轮：零新原语、零新通道、零新操作码、零 CoreExpr/IR 变体、零 VM 分派变更——运行时面逐字节不动）。

## 3. D2：双侧签名行设计（锁步同构）

**oracle 侧**（`builtins.rs` BUILTIN_SIGS I/O 段，read-num 行后插入）：

```rust
(
    "read-line",
    // r144 / 214-c — read-line signature entry (read-line-sig-design D2):
    // the runtime has enforced exact 0-arity since the FS-4 fix (20 §4 B3
    // contract "read-line 严格元数"; re-anchored to the unified message
    // form in r141). The stale "runtime does not check arity" rationale
    // is retired — the entry mirrors the read-int/read-num family form
    // (gated, fixed 0-arg, Unknown result).
    BuiltinSig::fixed(&[], TcType::Unknown),
),
```

**krf 侧**（`check.krf` TC-SIGS，read-num 行后插入）：

```lisp
   (cons "read-line" (list 'sig 0 0 'any 'unknown))
```

**形对齐论证**：`fixed(&[], Unknown)` ↔ `'sig 0 0 'any 'unknown`——与 read-int/read-num 逐字段同构（min=0 / max=0 / 参位 'any 同质模板{min=max 时参位不消费} / 结果 'unknown）。零新 kind、零新规则形——r140 逐行同构纪律延拓。

## 4. D3：结果类型 Unknown 裁定

**裁定**：read-line 结果位 = `Unknown`（非 Str、非 Nil）。三依据：

1. **值域并集**：read-line 返回 `Str`（命中行）∪ `Nil`（EOF）——8 kind 冻结下无 union 构造（Typed Racket 形不可表达——r142 D3 同款裁定先例：member 命中 Pair ∪ 未中 Bool → Unknown）。
2. **read-int/read-num 家族先例**：同族（gated 读入内置）结果位全 Unknown——`Str∪Nil` 与 `Int∪Nil`（EOF nil）同构并集域。
3. **r80 零误报契约**：Unknown = 零约束流（fresh tvar）——一切值消费位（`head`/`if` 条件/算术位/绑定位）零误报（r142 D4 三层宽度论证同律延拓）。

## 5. D4：邻位维持纪律（最小变更面）

| 邻位 | 维持裁定 |
|---|---|
| 运行时面 | **逐字节不动**——E0004 运行时执法 + 消息形维持（原则 42：编译期诊断正交 + 运行时兜底双层——静态 E0005 与运行时 E0004 为双层各自正典形，非镜像义务） |
| E0006 能力门控 | 维持先行——未授权 `(read-line)`（无 require）仍 E0006 编译期拒绝（front 面先于 HM 面；未授权+错元数仍 E0006——能力门先于签名门） |
| 值位 A4 纪律 | 维持——`(define f read-line)` 值位传递零诊断（签名表仅 apply 位消费——r135 D12 值位恒 Dynamic 律） |
| 限定名 krf 面通用路径 | 维持——`(io/read-line 1)` 在 krf 面走通用 A4 路径（check.krf 79/1241 行既有登记：qualified 族不在 TC-SIGS——krf ⊆ oracle 方向合法）；oracle 面限定名派生自动收紧 |
| 既有 61 行 | 零扰动——纯表尾插入（append-only） |
| 注册面 | 零变更——read-line 已在 register_globals{read 授权面}；full_grant 守卫 `g.len() == 114`（62 扁平 + 52 限定）维持 |

## 6. D5：派生链影响（miss-skip 前提翻转）

**oracle 侧**（自动——零代码变更）：
- `builtin_sigs`：STDLIB_MODULES 派生循环 `("io", "read-line", "read-line")` 行 underlying 命中 → `io/read-line` 限定名入表（+1 键：113 → 114 键）
- `builtin_sigs_with_renames`：改名派生 `read-line as rl` → `rl` 入表（+1 键/每改名）——r135 D12 miss-skip 对 read-line **不再是 miss**
- **miss-skip 路径存废裁定**：清偿后底层名全表覆盖（62 扁平名全在 SIGS）——miss-skip 成为**零在世实例的防御性路径**。裁定：**保留**（确定性边界——派生循环对未来表扩张的 fail-open 容错；非死代码删除义务——§12 最优>最小权衡下防御臂价值高于删除收益）。两函数文档注释更新为诚实形（「underlying miss 防御性跳过——当前零在世 miss」）。

**krf 侧**（自动——零代码变更）：
- `tc-sig-resolve`：`(rl ...)` 直接 miss TC-SIGS → TC-RENAME 链 `rl → read-line` → **命中**（原第三臂 nil → 现第一链臂返回 "read-line"）→ `tc-infer-builtin` 按新行执法
- 721-725 行注释（"the A4 Dynamic face carries over for read-family/renamed-unknown heads"）——R4 顺修：read-family 措辞清偿（renamed-unknown heads 维持）

**派生收紧方向论证**：krf ⊆ oracle 维持——krf 面新增拒收（read-line 扁平 + rl 改名链）⊆ oracle 面新增拒收（扁平 + 限定 + 改名三路）。

## 7. D6：计数 parity 影响论证（GATE 前置）

- **语料诊断锚零翻转预判**：r142 后 11 语料锚（expander 5 / compiler 1 / reader 0 / check 2 / build 0 / cli 0 / fib 0）——本窗纯表插入不改任何既有行执法；read-line 零参调用（语料库唯一形态——capability_tests EOF 探针族 + examples io 门控分项）零诊断维持。**实施时 stash-built 对照实测复核**（r134 锚翻转纪律——预判≠实测）。
- **诊断计数 parity**：双侧同增拒收能力——krf ⊆ oracle 方向维持{hm_production_switch 方向守卫断言不动}。
- **审计集影响零**：stage0-2/m3/e5close 280 case 与 read-line 静态面零交集（运行时面不动）。

## 8. D7：锚翻转预算

- `neg_r135_hm_read_family_a4_carryover`（ktf_member_rename_tests 1070 行）：断言 `rl()` 零诊断——**断言维持成立**（零参合法——签名命中后 arity 0..0 ∋ 0）；**前提注释翻转**（miss → Dynamic 改为 derivation 命中 → 合法调用）+ 断言文案更新（r135 D12 诚实边界行——「underlying miss skipped」实例消灭）。
- `negative_vm_tests.rs` 29/48 行模块注释：R4 清偿（运行时执法在位——同文件 338 行测试实证）。
- `ktf_tc_sigs_parity_tests.rs` 头注释「24 -> 61 rows」：61 → 62（R4 顺修）。
- 新增负例断言族（D8 N5/N6）锚定改名链收紧——r135 D12 诚实边界**收紧侧**新锚。
- 预期语料锚翻转：0（D6 预判——实测复核）。

## 9. D8：测试矩阵（GATE 5/6 构成——32 case = 8 正 + 24 负 1:3）

**新门 `ktf_read_line_sig_tests`**（根 tests/v0/stage3/plan/——跨 crate 断言入根纪律 §8.4.6/§9.1）：

**正例 8（P1-P8）**：
1. P1 krf 零参清偿后清白：`(require io read) (read-line)` → check 零诊断（表插入零扰动锚）
2. P2 ktf 零参清白：`require io, read; read_line()` → 零诊断（双面 parity）
3. P3 结果 Unknown 流消费零误报：`(require io read) (define s (read-line)) (head (list s))` → 零诊断（D3 fresh 零约束——r80 契约锚）
4. P4 if 条件位零误报：`(require io read) (if (read-line) 1 2)` → 零诊断（fresh unify bool——r142 D4 同律）
5. P5 改名零参清白：`(import kerf-io (read-line as rl)) (require io read) (rl)` → 零诊断（派生链命中 + arity 合法——翻转后正典形态）
6. P6 值位 A4 维持：`(require io read) (define f read-line) (f)` → 零诊断（值位恒 Dynamic——r135 D12 维持锚）
7. P7 表级 parity：oracle BUILTIN_SIGS 含 read-line{fixed 0, Unknown} + krf TC-SIGS 含 'sig 0 0 'any 'unknown + 双侧行数{62 扁平}（单源计数锚——r140 守卫族延拓）
8. P8 派生闭合：builtin_sigs 映射含 io/read-line 键{限定派生} + builtin_sigs_with_renames 映射含改名键（miss-skip 零在世实例——D5 闭合锚）

**负例 24（N1-N24）**：
1. N1 krf 扁平名元数：`(read-line 1)` → E0005 `expected 0..0, got 1`（静态拒绝新能力正典形）
2. N2 ktf 扁平名元数：`read_line(1)` → 同形（双面消息 parity）
3. N3 多余参形：`(read-line 1 2 3)` → `got 3`（计数穿线）
4. N4 oracle 面同拒：hm fallback 对 `(read-line 1)` 同形拒绝（双侧锁步——krf ⊆ oracle 收紧同增）
5. N5 改名链收紧：`(import kerf-io (read-line as rl)) (require io read) (rl 1)` → E0005（r135 D12 诚实边界**收紧侧**新锚——原 A4 静默位消灭）
6. N6 改名链多参：`(rl 1 2)` → E0005 got 2（链式解析计数穿线）
7. N7 未授权门先于签名门：`(read-line)`（无 require）→ E0006（能力门先行维持——D4）
8. N8 未授权+错元数仍 E0006：`(read-line 1)`（无 require）→ E0006 非 E0005（门序锚）
9. N9 运行时面维持：run `(read-line 1)` → E0004 `read-line requires 0 arguments, got 1`（逐字节——FS-4/r141 锚不动）
10. N10 限定名 oracle 收紧：oracle 面 `(io/read-line 1)` 拒收（限定派生自动收紧——D5）+ krf 面同程序通用路径清白（krf ⊆ oracle 方向合法锚——79/1241 行登记维持）
11. N11 零参 EOF 运行时维持：子进程探针 stdin=null → `(read-line)` ⇒ nil（capability_tests 60 行族维持锚）
12. N12 E0006 反查双名维持：`use kerf_io::{read_line as rl}` 未授权 → E0006 + `(io member read-line)`（r135 D13-② 锚不动）
13. N13 静态-运行时双层正交：N1 静态形 `E0005 ... (static check)` ≠ N9 运行时形 `E0004 ...`（原则 42 双层锚——非镜像义务）
14. N14 邻位在表行零回归：`(read-int 1)` / `(read-num 1)` → E0005 同形（read 族邻位维持）
15. N15 write 族邻位维持：`(print)` 零参 print → E0005 expected 1..1（I/O 段邻位锚）
16. N16 既有 61 行零扰动：`(vector-length 1 2)` → E0005 got 2（远端行维持锚）
17. N17 prelude 组合零误报：`(import kerf-list) (require io read) (read-line)` → 零诊断（TD-030 族组合面锚）
18. N18 嵌套消费零误报：`(+ 1 (if (read-line) 2 3))` → 零诊断（Unknown 深流——fresh 无污染）
19. N19 check+run 同文件双层：`(require io read) (read-line)` check ok + run EOF nil（双层各自合法）
20. N20 旧名 E0021 面维持：`(read-line-alias?)` 非法名 → 未绑定族（read-line 无别名——r42 移除轮锚维持）
21. N21 深嵌套组合负例：`(head (list (read-line 1)))` → E0005（嵌套实参位执法——递归 infer 链）
22. N22 恢复模式多错误：`(read-line 1)\n(read-line 2)` → 两条 E0005（DiagCollector 多错误收集——TD-013 面锚）
23. N23 跨面计数 parity：N1 程序 krf/ktf 双面诊断数相等（r135 双面一致性锚延拓）
24. N24 语料锚零翻转终验：11 语料锚 stash-built 对照逐字一致（D6 实测复核——D7 预算闭合）

**每子阶段集成构成**（GATE 6）：集成测试 ≥3{P1/P2/N1/N9 双面 E2E + N24 语料对照}；正向 ≥1{P1-P8}；负向 ≥3{N1-N24}；跨阶段消费 ≥1{N11 子进程 EOF + N17 prelude 组合}；正负比 8:24 = 1:3 ✓；七类错误 ≥6 类负向覆盖{E0005 元数 ×多 / E0006 能力 / E0004 运行时 / E0021 词法 / 未绑定族 / E0002 通道复用}。

---

## §7. 诚实边界（域外登记表——本窗不做）

| 域外项 | 载体 | 触发判据 |
|---|---|---|
| read-line 结果位精确类型（Str∪Nil union——TcType::Str 或 Nil 单选建模） | 本文件 D3（Unknown 保守裁定） | 8 kind 冻结解除窗（Stage 2+ 值域 union 构造——与值位 Callable 同族域外） |
| 限定名 krf 面入表（TC-SIGS 限定键派生——io/read-line 静态收紧） | check.krf 79/1241 行既有登记（qualified 族通用路径） | TC-SIGS 限定派生窗（krf 面收窄需求信号——r80 契约方向审慎臂） |
| read 族其他成员结果精确化（read-int Int∪Nil / read-num Num∪Nil） | 本文件 D3 家族先例维持（Unknown） | 同 D3 域外行 |
| print/write-string 参数域执法收紧（I/O 段参域 unchecked 注释维持） | builtins.rs 1928 行段注释（"side-effect face — parameter domain unchecked"） | 参域执法需求信号（本窗仅元数——参域维持段注释正典态） |

*遵循条款：原则 9（签名表面加性零机制变更）/ 原则 12（最优>最小——家族形对齐而非独创形）/ 原则 26（成熟度匹配——FS-4 运行时底座 + read-int/read-num 在表先例全在位）/ 原则 27（加性——61 行零扰动 + 注册面零变更）/ 原则 31（皮肤/骨架同构——双侧锁步行）/ 原则 42（错误处理统一而分治——E0005/E0004 双层正交）/ 原则 44（表行不涉新语法成员——EBNF 义务免）/ §2.3-4（报错>静默——静态面拒收能力补全）/ §8.4.6/§9.1（跨 crate 断言入根 tests/）/ §9.4.3（1:3）/ §20.6（诚实验收——前提注释翻转与断言维持分离陈述）/ R4（文档以实况为准——四件文档债当轮清偿）/ r74 先例（用户指令 = 需求信号本体）/ r140 先例（gated 家族双侧在表 + 逐行同构纪律）/ r142 先例（结果位 Unknown 并集域裁定）。*

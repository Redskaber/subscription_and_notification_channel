# TD-028 优化窗实施计划（r54——T3+ 第二件：VM 主分派性能演进）

> **Author**: kerf-dev-agent
> **Date**: 2026-09-21（v1.0 首版——r54 / 76-b 交付：开窗核对 + O1-O3 技术方案 + 增量归因实测 + 语义零漂移五手段 + 验收终态）
> **Version**: v1.0（**终态——r54 / 76-b 单轮闭环**：O1 span 惰性求值 + O2 指令引用化[单次边界检查 + 消除逐指令 clone] + O3 proto 引用跨迭代缓存[九处帧变更点显式失效]——三件全部正收益保留[无负收益移除项]；A/B 双二进制对照实测：**fib 1.177-1.195x / gc_stress 尾形 1.143x / check 1.02-1.04x / gc_stress_nontail 中性**；语义零漂移五手段全绿[904:0:0——889 基线 + 15 新增 vm_dispatch_perf_tests]）
> **Status**: Closed（r54 闭环——76-a/76-b/76-z/76-web）
> **窗定位**：23-evolution-governance §2.2 触发表 **T3+ 行**（触发式族——TD 优化窗口）｜ TD-028 详情节 r53 判据锚（check 阶段分布：自举 VM 链 99.77%——read 34.7% / expand 13.4% / 自举编译 51.5% / HM 0.5%）｜ 性能债载体 = performance-baseline.md §2.1/§2.6

---

## 1. 开窗核对（T3+ TD 优化窗口——触发信号逐项证据）

**治理依据**：23 §2.2 触发表 T3+ 行（触发式开窗单源）+ §2.3 红线 3（禁止无信号开窗）。

| # | 触发信号 | 证据 | 判定 |
|---|---------|------|------|
| ① | 性能基线冻结（优化判据的前置数据） | performance-baseline.md v1.1 §2.6（r53 阶段分布判据锚——check 大头 = 自举 VM 链 99.77%，三段全为 VM 主分派受益面）；§2.1 fib 91.534ms / gc 尾形 41.593ms | ✅ |
| ② | final-assessment 裁定 | stage-3/final-assessment.md（r52 裁定「TD 优化窗口 profile 先行」）+ r53 T3+ 首件已交付（HM O1+O4）——TD-028 详情节「优化候选：主分派查表化 + GC 根扫描入口快路径——**优化前须先 profile 实测定锚**」 | ✅ |
| ③ | 性能债登记在位 | tech-debt-register TD-028（r36 登记 / r53 判据锚注记——P3，正确性零影响，漂移量级 ~10% 非用户可感知面） | ✅ |
| ④ | 优化候选判据（非先例驱动） | **profile 先行已执行**（76-b 代码实读定锚 + 基线实测对照）：主循环逐指令成本实测拆解 = ①`proto.code[pc_u].clone()`（逐指令枚举拷贝）②`debug_spans.get(pc_u).copied()`（逐指令 16B span 无条件拷贝——仅错误路径需要）③循环头双边界检查索引（`frames[frame_idx].proto` + `program.protos[proto_idx]`——帧未变时纯冗余）④守卫+索引双查（显式 len 守卫 + `code[pc_u]` 再查一次）；bench 口径 ~40M 指令/s（fib）对典型 match 分派解释器有 2-5x headroom | ✅ |
| ⑤ | 语义零漂移可证明性 | VM run 路径（与 r53 HM 的 check 面不同——**本窗是 run 路径**）：判定面 = ①全量套件 904:0:0 ②三语料 check 诊断集逐字节 diff（A/B 双二进制）③六审计集 280 case ④门 B fixpoint SHA（套件内含）⑤bench 验证值锚（fib 75025/gc 5）——五手段全可机械实证 | ✅ |
| ⑥ | 净负载红线复核 | 非 net 窗（零授权面）；零语法变更（15 实现轴层内——vm.rs 单文件）；纯分派实现演进 | ✅ 合规 |

**开窗裁定**：六信号全过——T3+ 第二件 = **VM 主分派性能演进窗**（O1-O3 三优化点），r54 承载。

**范围界定（负空间声明）**：
- **做**：`crates/kerf-vm/src/vm.rs` `execute` 主循环（O1/O2/O3）+ 守护测试面（vm_dispatch_perf_tests 15 case）；
- **不做**：GC 根扫描本体（collect_roots/collect_value_roots——TD-023 已对症，本窗以 gc_stress 双基准对照证零退化即可）；查表化/computed goto 大改（O1-O3 已兑现分发开销大头，剩余 headroom 判据不足——留观察项 OBS-B）；分配池化（Call 臂 alloc_local_cells 的 Rc<GcCell> 逐调用分配——语义面捕获共享不变量重，判据不足不开工）。

## 2. 技术方案（O1-O3——语义零变更的纯性能演进）

| # | 优化点 | 机制 | 语义等价性论证 |
|---|-------|------|--------------|
| **O1** | span 惰性求值 | 删除逐指令 `let span = debug_spans.get(pc_u).copied()`；引入 `cur_pc`（绑定于 pc 自增前）+ `cur_span!()` 宏——错误路径/帧构造点（call_span）按需取 | eager 版取 `debug_spans[pc_u]`（pc 自增前）；lazy 版在错误点取 `debug_spans[cur_pc]`——`cur_pc` 不可变且等于原 pc_u，**取值顺序无关恒等**（60 处错误/帧构造点逐一等价） |
| **O2** | 指令引用化 | `let Some(op) = proto.code.get(pc_u) else { 越界护栏 }` 替代「显式 len 守卫 + `code[pc_u].clone()`」——单次边界检查 + Op 按引用分发（载荷 `*k`/`*t` 按需解引用） | 越界失败路径消息逐字保持（o2 守护测试锚）；臂体载荷解引用语义同 clone 后取值；分派臂零改动（原 `match &op` 本就是引用模式绑定） |
| **O3** | proto 跨迭代缓存 | `proto_valid`/`proto_idx`/`proto` 三变量跨迭代持有；循环头单 bool 检查；**九处帧变更点显式置 `proto_valid = false`**（Call 推帧 / Call 续体 resume / TailCall 内建隐式 RET / TailCall 帧替换 / TailCall 续体 resume / Ret 弹帧 / INSTALL_HANDLER 双推帧 / PERFORM 换帧+截断） | 帧未变时 `proto` 恒等原逐指令重取值；帧长度不可作失效信号（相邻指令 push/pop 可回退同值）→ 显式置位枚举全部九处变更点（漏一即错误分派——由 904 套件 Call/Ret/TailCall/效应/续体全路径行为锚覆盖） |

## 3. 增量归因实测（A/B 双二进制对照——r53 方法论资产复用）

| 步骤 | fib（bench 5 轮） | check-expander（5 轮中值） | 裁定 |
|---|---|---|---|
| 基线（r53 二进制） | 91.238-92.871ms | 3793-3847ms（中值 3812） | — |
| +O1+O2 | 83.163ms | 3723-3859（中值 3804） | O1+O2：fib 1.103x / check 1.002x |
| +O3（终态） | **76.354-78.874ms** | 3615-3680（中值 3669）；机器波动带内 3643-3961 | O3：fib 再 +7-8% → 终态 |

**终态 A/B 汇总（同机同轮对照）**：

| 基准 | 基线（r53） | r54 终态 | 加速比 | 口径注记 |
|---|---|---|---|---|
| fib 25（bench 5 轮） | 91.238 / 92.871ms | 76.354 / 78.874ms | **1.177-1.195x** | ~2.65M → ~3.15M 调用/s |
| gc_stress 尾形 | 42.017ms | 36.641-36.762ms | **1.143x** | 尾调用链 + 分派开销敏感 |
| check expander.krf | 3812ms（中值） | 3669ms（紧带中值） | **1.039x** | 自举 VM 链三段受益（诚实口径：波动带内 1.02-1.04x） |
| gc_stress 非尾形 | ~109ms（复测） | ~108ms | 中性 | 深帧 GC 根扫描主导（TD-023 面未触碰） |
| effect_stress | 94.557ms | 94.231ms | 中性 | 效应路径开销在帧构造而非分派 |
| 小程序（macros/io/closures/higher_order） | ~0.05ms | ~0.05ms | 中性 | 编译主导 |

**负收益/中性实录（判据驱动）**：无移除项（O1-O3 全部正收益或中性）；gc_stress_nontail 首测 3 轮出现 95.2 vs 107.4「回退」——**复测 5 轮 ×3 组证为噪声离群**（base 108.8-110.6 / opt 107.4-109.2——无回退），R1 处置实录：短轮基准结论必须 5 轮以上复测。

## 4. 语义零漂移五手段（验收实录）

1. **§3.2 六命令 clean 起步全绿**：build 15s 零告警 / check 0 / fmt 0 diff / clippy --all-targets --workspace -D warnings 0 / **test 904:0:0**（889 基线 + 15 新增——vm_dispatch_perf_tests：O1 错误 span 锚 ×5 + O2 护卫消息锚 + O3 失效纪律 ×6 + 确定性/fib 值/GC 存活 ×3）
2. **三语料 check 诊断集 A/B 逐字节 diff = 空集**（expander 318 行 / compiler 144 行 / reader 192 行 + macros 6 行——双二进制同输出）
3. **六审计集 280 case EXIT 0 ×6**（stage0/1/2r1/2r2/m3/e5close——fmt 重排后复验）
4. **CLI 全路径**：fib 75025/144 + higher_order (1 4 9 16 25) + closures 42 + check ok（门 B fixpoint 由套件 bootstrap_compiler_tests 覆盖——904 全绿内含）
5. **bench 验证值锚**：全基准先验证后计时（fib 75025 / gc 5）——值面零漂移

## 5. 结论与后继判据

- **TD-028 首批清偿**：VM 主分派三优化点落地（run 路径 1.18-1.20x / 编译链 1.02-1.04x）——TD-028 维持登记（GC 根扫描快路径与查表化候选未耗尽，但**判据已收紧**：fib 需 <65ms 或新分布数据方触发续窗）
- **OBS-B（观察项）**：Call 臂 `alloc_local_cells` 的逐调用 Rc 分配（~6 malloc/call）——深递归基准剩余大头候选；触发判据 = fib 续窗需求出现时先做分配剖面定锚
- **方法论资产沉淀**：O1 的「惰性求值恒等式」（cur_pc 不可变绑定 + 取值顺序无关）适用于一切「逐项无条件计算 + 仅少数路径消费」的分派循环模式

# 设计文档 S-expr 时代残留清偿窗 + EBNF Level 0 审查（r157 / 227）

> **Author**: Super Z (main) — PM-A/ARCH-A
> **Date**: 2026-11-22（r157 / 227-a；收口 2026-11-22 227-verify/d/e/close——中断会话恢复收口笔）
> **Version**: v1.1（v1.0 开窗方案 + 本轮收口验收数字回填）
> **Status**: **Closed**（r157 全窗闭环——§5 量化验收六项全过：GATE 1 六命令 clean 起步全绿 1788:0:0 逐位保持{RUST_MIN_STACK=33554432——24 test binary 族} + 审计×6 真实 EXIT 0 ×6{41+50+53+46+43+47} + CLI 八探针零回归{bench 76.361ms 带内 + .krf 拒收 exit 2 三短语} + UPDATE 面逐点全落 + KEEP 面零漂移{版本头 prepend 保形 10 件机器校验 ALL OK + 皮肤字典/D 表/Level 1-4 区域级零触碰} + EBNF 审计表 46 行{≥30 超额} + 499 相对链接零死链；治理四件{matrix r157 行 + RELEASE r157 节 + t3plus v1.77 + 本件 Closed} + §19 打包三验 + web 五件同步 E2E 由 227-e/close 承载）

---

## §1 开窗依据（M1 指令开窗第六十二例）

用户四链指令①行权：「深度审查项目中是否存在遗留旧时代的编码方式和内容（**全面转向现代前沿理论表示，包括目标语言中的设计和内容是否存在和转化**）……当前目标语言中遗留的 S 表达式相关结构或表现等，语法核心目标语言表示，现代前沿的目标语言语法对 S 表达式的替换等，**EBNF 语法审查，闭包函数 EBNF 语法审查重选筛选**」。

- r156（226 窗）已清偿面：**代码面**（Tier-3 局部名 113 点 + 注释 ~45 点 + 消息 2 条）+ **README**（完全重构）+ **web**（D6 全量 + P0 清偿）。
- r156 未审计面（本窗对象）：**lang-design/ 设计文档 24 件的现行面**——用户指令①明示「目标语言中的设计和内容」= 设计文档面收口（「one face, one name」轨迹第四步：代码面 → README → web → **设计文档**）。
- ②「继续推进目标语言设计的实现窗」+ ③「按推荐顺序推进」：t3plus v1.76 十四行零信号 + TD-034 触发式维持 + #15 讨论主线无新语料（next18.md 未上传）——推荐序自然落到用户指令①行权开窗（r74/r79/…/r156 同型先例链第六十二例）。
- ④「同步完整打包项目 tar.gz 并同步完整更新 web page」= 227-e 承载。

**实况基线（PHASE 1 核实）**：kerf 树 @ git 210d73c（r156 收口）干净；1788 基线第三轮（r154-r156）；download/ = r155 + r156 双包；web 已同步 r156（E2E 全绿）；TD 登记册唯一开放项 = TD-034（P3 触发式）。

## §2 残留全量盘点（24 件 lang-design 正文扫描——排除版本头历史行）

**扫描模式**：`\(define |\(-define|\(define-syntax|\(lambda |\(let |\(fn |\(perform |\(handle |\module |\import |\(require |\(assign |\(quote |syntax-rules|\.krf\b` → 正文命中 **175 处**（版本头 `> ` 前缀行不计——历史档案面 §8.6 免审）。

### §2.1 分流三判据（D2）

| 判据 | 判定 | 处置 |
|---|---|---|
| J1 历史记述（版本头/D 表裁定/窗口验收记录/时点注记） | KEEP | §8.6 只追加纪律零触碰 |
| J2 Stx 内核形（r43 后关键字面——Reader 产物的 datum 表示；皮肤字典 §14 左列） | KEEP | 必要处加记号桥注（U3） |
| J3 用户面表述使用退役形（`.krf` 现行文件引用 / `lambda` 时名 / 用户面声明形以括号形直陈） | UPDATE | 本窗清偿面 |

### §2.2 KEEP 面清单（零触碰——对照防漂移锚）

1. 全部版本头 Date/Version 行（历史档案）；
2. 22-namespace §10/§11/§15/§17/§18 D 表族 + §13 迁移映射表（历史裁定记录）；
3. 20-surface **§14 皮肤字典表**（现行正源——S-expr 内核形 ↔ 现代面映射注册表，r109-r154 增补链）；
4. 02-syntax **§8.5-§8.12 EBNF Level 1-4 登记态**（原则 38/44-58 愿景域——零信号不开窗）+ §8.13.2a/§8.14 增量登记族；
5. 02 §8.13 EBNF v9 定稿文法本体（r104 定稿——**仅实现-文档漂移点按 D6 修正**，愿景元素加注不动本体）；
6. 06-operational 规则的 Stx 形状本体（归约对象 = CoreExpr 冻结内核——**仅 `lambda` 时名清偿 + 记号桥**）；
7. 14-design-alternatives:391 Racket 对照例（外部语言示例非 kerf 面）；
8. 01 §7.3 推导数学（`((lambda (x) b) a)` 等理论推导式——数学记号面，含时名注记者 KEEP）。

### §2.3 UPDATE 面清单（本窗清偿——逐点定位）

**U1 现行文件名 .krf→.ktf（R4 文档随代码——现行命令/验证/机制表述中的文件引用）**：

| # | 文件:行 | 现文本 | 修正 | 性质 |
|---|---|---|---|---|
| U1-1 | 04:189 | `kerf bench examples/usage/fib.krf` | → `fib.ktf` | 现行 CLI 命令表述 |
| U1-2 | 05:209/212 | `examples/usage/gc_stress.krf` ×2 | → `.ktf` | 现行验证锚 |
| U1-3 | 05:213 | `examples/usage/io.krf` | → `.ktf` | 同上 |
| U1-4 | 06:247/252/255 | `closures.krf、higher_order.krf` / `macros.krf、io.krf` / `gc_stress.krf` | → `.ktf` ×5 处 | 验证矩阵现行锚（语义描述 KEEP） |
| U1-5 | 09:42 | `服务 reader.krf` | → `reader.ktf` | 现行机制表述 |
| U1-6 | 20:102 | `bootstrap/preamble.krf` | → `preamble.ktf` | 现行定位表述 |
| U1-7 | 20:126 | 节标题 `reader.krf/expander.krf/compiler.krf/preamble.krf` | → 四件 `.ktf` | §6.5 现行引导语料清单 |
| U1-8 | 20:128 | `10 .krf 定义名` | → `10 .ktf 定义名` | 闭合守卫现行表述 |
| U1-9 | 22:217 | `preamble.krf 无特权化核验` | → `preamble.ktf` | R-N6 现行核验行 |
| U1-10 | 03:69-70 状态列表 | `krf 生产侧` / `expander.krf`（生产路径表述） | → `.ktf` 现行名（+ E6 更名注记） | 现行生产路径表述（r15 历史时点 KEEP 于括注） |

**U2 退役时名 `lambda` 清偿（06-operational 规则面）**：

- 06:49 (L1) 规则 `(lambda (x₁…xₙ) e)` → `(fn (x₁…xₙ) e)`（r43 内核关键字面终态——`assign`/`do` 同列已现代，唯 `lambda` 漏 modern 面）；
- §2 规则族头部增**记号桥注**：规则左端以 Stx 内核形书写（r43 后关键字面）；用户面现代形对照 = 20 §14 皮肤字典（例：`(fn (x) e)` ↔ `fn (x) { e }` / `|| (x) { e }`；`(assign x v)` ↔ `x = v;`；`(let ((x v)) b)` ↔ `let x = v; b`）；
- 其余规则关键字面核查（`(define x e)`/`(perform e)`/`(handle …)`/`(module …)`/`(let …)`/`(assign …)` = 现行内核关键字——形状 KEEP）。

**U3 用户面声明形记号桥（节头/表头最小侵入——零行级改写）**：

| # | 位置 | 动作 |
|---|---|---|
| U3-1 | 20 §5.2 import 语义区头（~:96 前） | 桥注：「本节 import/require 以 Stx 内核形书写；用户面 = `import kerf_string;` / `require io, write;`（皮肤字典第八/十映射）」 |
| U3-2 | 22 §3.2 R-N2 表头（~:114 前） | 桥注：同型（用户面 `import kerf_string as str;`） |
| U3-3 | 22 §5.2 红线区（~:173 前） | 桥注：`(require io write)` 内核形 ↔ `require io, write;` 用户面 |
| U3-4 | 21 §4 声明态表（~:150/198 区） | 桥注：require 声明形双面记法 |
| U3-5 | 09 §2.2 print 行（:38） | `(require io write)` → 双面：`require io, write;`（内核形 `(require io write)`） |
| U3-6 | 01 §6 require 形式文法（:109） | 增用户面形：`require io, write;`（↔ 内核 `(require io write)`——皮肤字典第八映射） |

**U4 已删测试锚历史注记（02:219）**：

- 「'x 简写 | quote 读取快照：'(quote x) 等价 + negative_reader_tests::quote_shorthand_at_eof」行 → 追加历史注记：'x 简写随 .krf 面退役（r153/r154 E6——negative_reader_tests 组件族同批删除）；现代面符号字面量 = `quote(sym)` 调用形（20 §14 第六映射）。

## §3 EBNF Level 0 审查（用户指令①「EBNF 语法审查 + 闭包函数 EBNF 语法审查重选筛选」）

### §3.1 种子发现（227-a 主代理实测——已实锤）

| # | 发现 | 等级 | 修正 |
|---|---|---|---|
| E-1 | **fn_decl 返回签名漂移**：02 §8.13 `fn_decl ::= … "(" [ params ] ")" "->" effect_union block`（**必选**）vs reader.rs parse_fn_decl `if self.peek() == &Tk::Arrow`（**可选**——consume_effect_union 剥离实施）vs 语料双形实证（fib.ktf `fn fib(n: i64) -> i64 {…}` 带 / closures.ktf `fn make_counter() {…}` 不带） | P2（文档-实现漂移） | EBNF 修正：`"->" effect_union` → `[ "->" effect_union ]` + 「剥离实施」注记（类型域 = HM/Level 2——内核剥离；R4 文档随代码） |
| E-2 | `move` 前缀位置记法：EBNF closure_expr ::= `[ "move" ] "||" …`（closure 专属前缀）vs 实现 = parse_unary KwMove 臂（**任意 unary 前缀——剥离实施**「semantics are Level 2 — parsed then stripped」） | P3（实现比 EBNF 更宽松——不破坏 EBNF 所述形态） | 注记登记（非修正）：closure 位 consume 与 EBNF 一致；宽松面 = 剥离位形 |
| E-3 | closure_expr **逐位一致实证**（用户指令「闭包函数 EBNF 语法审查」兑现）：EBNF `[ "move" ] "\|\|" [ "(" [ params ] ")" ] [ "->" effect_union ] block` ↔ parse_closure_body（LParen 可选 typed_params → Arrow 可选 consume_effect_union → parse_block → Stx `(fn (params) body)`）↔ closures.ktf 双形（`\|\| { n = n + 1; n }` / `\|\| (x: i64) { x + n }`）——**零偏差**；`\|\|` 形「重选筛选」复核：lambda→closure D2 映射（20 §14 皮肤字典）+ 双竖线前缀强制（例 3/18 二义性预防——`\|` 保留给 or 模式）维持终选 | ✅ 一致 | 无修正——审查结论落档 |

### §3.2 词法保留词实施状态（227-a 抽查）

`pub`/`struct`/`enum`/`effect`/`capability`/`move` 俱在 reader.rs token 映射（KwPub/KwStruct/…——词法层保留）；声明族解析级状态 = §3.4 审计表逐条回填（预期 = 登记态/剥离实施——EBNF §8.13 core Level 0 含 r104 设计定稿愿景元素，§8.13.1a = r109+ 实施产生式正源）。

### §3.4 全产生式审计表（227-b3 回填——r157 落档）

> **审计方法**：02 §8.13 EBNF v9 core 定稿域（02:499-688）+ §8.13.1a Level 0 增补位（02:697-927）逐产生式对账 `crates/kerf-reader/src/reader.rs`（parse 函数族 44 个——`rg "fn parse_"` 枚举 + 词法层 `lex` :559-973 + Tk 词-法映射 :110-321）+ 语料 16 件 `examples/usage/*.ktf` 抽证（closures/fib/higher_order/effect 族/match/macros/vector）。**行号口径**：02 行号 = v7.25 本轮编辑后（E-1 修正注记 02:545-547 +3 行、closure 注记 02:631-632 +2 行）；reader.rs 行号 = r157 树（纯文档轮零代码变更）。实施状态三档：✅ 已实施 / ◐ 剥离实施（parsed-then-stripped——类型/效应签名/泛型/mut/move 等内核无消费面，读入即剥离）/ ○ 登记态愿景（词法保留未解析——`domain_out` 结构化诊断或无 Token）。

| # | 产生式 | EBNF 位置（02:行） | 实施锚（reader.rs） | 实施状态 | 漂移裁定 |
|---|---|---|---|---|---|
| 1 | program / compilation_unit | 499-500 | parse_program :1146-1152 | ✅ | 一致（EOF 前 item 循环） |
| 2 | identifier / id_start / id_continue | 502-504 | is_id_start/is_id_continue :549-555 + lex 标识符通道 :796-863 | ✅ | 一致（letter = ASCII 字母域收敛注记——非 ASCII 字母走 illegal char 面，词法平凡不构成漂移） |
| 3 | qualified_name（`::` 分隔） | 505-507 | lex `::` 合并 :833-856 → `Tk::Path("a/b")` | ✅ | 一致（22 §27 双面映射——`::` ↔ `/` 扁平载荷） |
| 4 | literal 族（int 十/0x/0o/0b + `_` 分隔；float 定点+带符指数；string 全逃逸；bool） | 509-518, 522 | lex 数值扫描 :614-728 + 字符串逃逸 :742-794 + `true`/`false` :829-830 | ✅ | 一致（整数溢出守卫 :720-725；带符指数 r107 修 :662-696；逃逸七字符与 EBNF escape 逐字对齐） |
| 5 | char_literal | 519 | 无 Token——`'x` = Tk::QuoteLifetime 类型域 :729-741；`'` 孤位 = illegal char :955-960 | ○ | 登记态注记（Tk 无 Char 变体——与 U4 'x 简写退役同源；QuoteLifetime 仅类型语法域消费） |
| 6 | unit_literal `()`（nil ≡ ()——C12） | 521 | lex `()` 前瞻 :941-948 + 位置双关三裁决（参数位 :1551-1555 / 调用位 :3049-3057 / primary 位 :3162） | ✅ | 一致（词法 Unit 双关由句法位置裁决——parse_typed_params 先例族） |
| 7 | comment（line_comment + 嵌套 block_comment） | 524-526 | lex :587-613 | ✅ | 一致（**两种注释俱在位实证**——`//` 行注释 :587-592 + `/* */` 嵌套块注释 :594-613[深度计数 + unclosed fail-closed :609-611]） |
| 8 | item | 531-532 | parse_item :1154-1186 | ✅/○ | 宽松面注记：实施域 = 增补位声明全族（import/export/require/extern/macro/use）+ 顶层表达式 item 兜底 parse_stmt_into :1184（**内核超集**——reader.rs:1914-1916 代码注释明示 ModuleItem::Expr 程序入口形）；基座 type_decl/effect_decl/capability_decl/visibility = 登记态 domain_out（:1156, :1176-1183） |
| 9 | module_decl | 533 | parse_module_decl :1470-1499 | ✅ | 一致（`module name { items }` → `(module name items...)`；visibility 前缀 = 登记态——pub 位 parse_item:1156 domain_out） |
| 10 | use_decl / use_path / use_tree（基座 + r131/r134 增补） | 534-538 + 816-829 | parse_use_decl :1289-1433 | ✅ | 一致（选择树 `use m::{a, b};` + as 别名 + r134 成员重命名三元组 `m as x`；多段路径词法可写、E0019 编译期拒收 = D1 单层执法；空选择列表 fail-closed :1380-1390） |
| 11 | visibility ::= `"pub"` | 539-540 | Tk::KwPub 词法保留 :141/:273/:819 | ○ | 登记态（parse_item:1156 domain_out「pub visibility modifier」——pub(scope) 粒度 = Stage 2+ 候选登记[02:540 同口径]） |
| 12 | module_import / import_item（r109 + r130 别名） | 697-706 | parse_import_decl :1197-1269 | ✅ | 一致（`import a as b, c;` → `(import a as b c)` 符号同构；名位 `as` = 专用诊断 :1205-1217[r130 名位 Span 修复]） |
| 13 | fn_decl | 543-547（本轮修正后） | parse_fn_decl :1504-1543 | ◐ | **漂移→修正 E-1（本轮已修）**：返回效应签名 EBNF 必选 `"->" effect_union` vs 实现 :1523 `if self.peek() == &Tk::Arrow`（**可选**——consume_effect_union 剥离实施）vs 语料双形实证（fib.ktf:14 带 / closures.ktf:15 不带）→ 02:544 修正为 `[ "->" effect_union ]` + 剥离实施注记 02:545-547（R4 文档随代码）；泛型参 `<...>` = consume_type 剥离 :1517-1520 |
| 14 | params / param | 548-549 | parse_typed_params :1546-1584 | ◐ | 一致（`mut` 剥离 :1562-1564；`: type` 必选 + consume_type 剥离 :1576；空参 `()` = 词法 Unit 双关 :1551-1555） |
| 15 | type_params / type_bound / type 全族 | 550-551, 665-680 | consume_type / consume_type_atom :1589-1673 | ◐ | 一致（宽松消费：路径/泛型嵌套/生命期 `'x`/Fn 函数型/linear/effect/()/Never 全覆盖——类型域 HM/Level 2 内核剥离；r149 递归守卫 :1590-1597） |
| 16 | effect_union / effect_container | 658-661 | consume_effect_union :1676-1717 | ◐ | 一致（容器名 + `\|` 联合循环 :1706 + 裸类型糖 + Fn 尾随效应递归 :1712-1715） |
| 17 | where_clause / constraint | 682-685 | 无 Token（`where` 词法 = 普通 Ident :831） | ○ | 登记态（r104 愿景——trait 上界/效应行 `has`/能力约束 `requires` 均未实施） |
| 18 | type_decl / struct_decl / enum_decl / alias_decl | 555-562 | Tk::KwType/KwStruct/KwEnum 词法保留 :150/:153-154/:823/:826 | ○ | 登记态（parse_item:1176-1178 domain_out「type declaration (type system implementation window)」——类型系统实现窗信号） |
| 19 | effect_decl / effect_operation / effect_direction | 565-568 | Tk::KwEffect 词法保留 :151/:824 | ○ | 登记态（parse_item:1179-1181 domain_out「effect declaration (effect system implementation window)」） |
| 20 | capability_decl / cap_member 族 | 571-576 | Tk::KwCapability 词法保留 :152/:825 | ○ | 登记态（parse_item:1182-1183 domain_out「capability operation syntax family Level 2」） |
| 21 | block | 579 | parse_block / parse_block_inner :1721-1826 | ✅ | 一致（`{ { statement } [ expr ] }`——语句序列 + 可选尾表达式；let/do 单逆序穿线算法[r45 D42 同构] :1790-1825；空块尾 = Nil 字面量 r110 :1797-1803） |
| 22 | statement | 580-583 | parse_block_inner 分派 :1748-1785 + parse_stmt_or_expr :1893-1912 | ✅ | 一致（let/assign/expr_stmt/if/match/perform/handle 七族；宏调用 = `name!(...)` 表达式语句位；块内 use/import 位 = E0001 期望表达式[parse_primary 兜底 fail-closed]——02:837 位置纪律逐字一致） |
| 23 | let_stmt（基座单绑定 584 + r110 多绑定增补 765-766） | 584 + 765-766 | parse_let_stmt :1835-1889 | ✅ | 一致（**双形俱受**：`let x = e;` 单绑定[Span 校准字节保持 :1878-1882] + `let a = e1, b = e2;` 多绑定平行语义[D61 暂存法链]；`mut`/`: T` 剥离 :1841-1855；closures.ktf:16 正典） |
| 24 | assign_stmt | 585 | parse_stmt_or_expr Ident=` 前瞻分派 :1896-1898 → parse_macro_arg :3108-3124 → `(assign x v)` | ✅ | 一致（**Ident 前瞻双 Token 分派**——不含 Path 位，与 EBNF `identifier` 限定逐字一致；closures.ktf:17 `n = n + 1;` 正典；宏实参 `ident = expr` 桥接形同源） |
| 25 | if_stmt（586）+ if_expr（r110 增补 769-772） | 586 + 769-772 | parse_if :2299-2323 + parse_primary KwIf 臂 :3132-3134 | ✅ | 一致（语句位/表达式位同形分派；else-if 链 :2305-2306；无 else = Nil 字面量 r110 :2311-2317——`(if c a b)` 四元组） |
| 26 | match_stmt 基座（587-588）+ r121 match_expr 增补（846-865） | 587-588 + 846-865 | parse_match :2683-2735 + parse_primary KwMatch 臂 :3138-3140 | ✅ | 一致（r121 增补 = 实施正源：臂体 = **expr**[基座 02:588 `block` 形 = r104 愿景行被增补取代——注记非漂移]；守卫 `if` :2701-2706；尾臂逗号可省 :2717；≥1 臂 fail-closed :2724-2729；match.ktf:16-28 正典） |
| 27 | pattern 族基座（or/atom/variant/wildcard/binding/tuple/struct 642-655） | 642-655 | parse_pattern_atom :2777-2869 | ✅/○ | 一致（r121 增补 pattern_atom 02:857-861 = 实施正源：字面量/裸标识符/`_`/`(p)` 分组/`(p, q)` 二元拆构[右不嵌套防无限型 :2828-2832]）；基座愿景元素 = 登记态：variant_pattern 限定名 = domain_out :2817-2819[22 §27]、binding_pattern `@` = 非法字符位、struct_pattern 无受理、`mut` 模式前缀无受理 |
| 28 | pattern_or + 深度帽（r121） | 853-855 | parse_pattern_or :2740-2767 + MAX_PATTERN_DEPTH = 8 :2669 | ✅ | 一致（or 标记表 `(or p q ...)` 中间形——`\|` 保留 Token 无绑定碰撞；`(0 \| 1 \| 2)` match.ktf:39 正典；**深度帽 8** 逐字对齐 match-design §1 防御性栈保护） |
| 29 | perform_stmt | 592-593 | parse_perform :2329-2394 | ✅ | 宽松面注记：EBNF 实参括号必选 vs 实现 LParen/Unit 双条件臂 :2343-2358（`perform Op;` 无括号形亦受理为零实参——**语料正典全带括号**[effect.ktf:14 `perform gift(0, 20);` 全族 7 处一致]，宽松面零语料行使、不破坏 EBNF 所述形态[与 E-2 同律：注记登记非修正]）；effect_ref = Ident\|Path ✅ :2332-2341；载荷 cons 链 arity 三态 :2365-2387 |
| 30 | handle_stmt（基座 593 + r132 多臂 785-790 + r143 表达式位） | 593 + 785-790 | parse_handle :2409-2537 + parse_primary KwHandle 臂 :3149-3151 | ✅ | 一致（多臂 ≥1 + 尾逗号容差 D8 :2490；零臂 fail-closed :2494-2499；同 handle 效应名重复 fail-closed D6 :2441-2449；≥2 臂 = handle-group 组安装 r136 D11 :2522-2536；单臂退化 r106 v1 字节等价 D1 :2511-2521；语句位/表达式位同形[r110 if / r121 match 先例第三例]；effect_multiarm.ktf:27-31 正典） |
| 31 | handler_arm / effect_pattern（r132 两元绑定） | 792-795 | parse_handle 臂解析 :2430-2480 | ✅ | 一致（统一两元绑定 `Name(p, k)`——arm_vars ≠ 2 fail-closed :2474-2479；基座 02:594-595 pattern_list 泛化/if 守卫 = 域外登记 D8[match 模式集成窗信号]——增补位正源口径） |
| 32 | handler_body 四形（r132 798-801 + r128 874-882 块体族） | 798-801 + 874-882 | parse_handler_body :2546-2575 + parse_halt_form :2582-2602 + parse_pass_form :2610-2637 + parse_resume_call :2643-2654 | ✅ | 一致（halt = 尾值糖 D5[裸形 Nil；非分隔/收位 = 专用 arity 诊断 :2592-2600]；pass = `(perform (cons 'T p))` D4[实参拒收 :2617-2621]；resume 调用形 k 注入[r128]；r133 嵌套块作用域穿线 handler_k save/restore :2417/:2503——nested-resume-design D1-D5；块体 handler_block/resume_stmt[`;` 可省]同构） |
| 33 | expr 优先级链：or_expr / and_expr / comparison_expr | 605-610 | parse_or :2887-2898 / parse_and :2901-2912 / parse_comparison :2915-2938 | ✅ | 一致（`a \|\| b` → `(or a b)` 派生宏短路；`a && b` → `(and a b)`；比较**非链式单次**[例 19]——`!=` → `(not (= a b))` :2930-2935；comp_op 六词全对齐 :2917-2923） |
| 34 | arith_expr / term（+ - * / %） | 615-617 | parse_additive :2941-2956 / parse_term :2959-2975 | ✅ | 一致（左结合循环——十四级表第 5/4 级机器面） |
| 35 | unary_op（`-` / `!`） | 617-618 | parse_unary Minus/MacroBang 臂 :2980-2998 | ✅ | 一致（`-e` → `(- e)`；`!e` → `(not e)`——与 `name!(...)` 后缀共享 `!` 词面按句法结构消歧 :2988-2991） |
| 36 | `move` 前缀（closure_expr 位） | 629-632 | parse_unary KwMove 臂 :2999-3003 | ◐ | **宽松面注记 E-2（本轮已注）**：任意 unary 位受理且剥离（「semantics are Level 2 — parsed then stripped」:3000）——比 closure 专属前缀产生式更宽松、不破坏所述形态；02:631-632 EBNF 注记已加（同律 = 注记登记非修正） |
| 37 | range_expr / bitor / bitxor / bitand / shift / cast / `.` 字段·方法 / 索引 / `\|>` 管道 | 604, 611-614, 619-623 | parse_postfix domain_out 诊断位 :3079-3099（DotDot/Pipe/Dot/LBracket/KwAs/Amp/Caret/Shl/Shr/Or 词法 Token 俱在位 :523-539） | ○ | 登记态（十四级表第 13/14/6-9/2 级——EBNF v9 Level 0 域内、内核映射域外：reader.rs:2871-2873 注释「range(13)/pipe(14)/bitwise(6-9)/as(2) = registered out-of-domain diagnostics」——后续切换窗批次承载；诊断结构化 fail-closed 非静默） |
| 38 | postfix 调用 `f(args)` / `f()` + 宏调用 `name!(args)`（+ macro_args） | 620-624 + 637-639 | parse_postfix LParen/Unit/MacroBang 臂 :3013-3078 + parse_macro_arg :3108-3124 | ✅ | 一致（C9 调用形；`()` 调用位 = 零实参表[词法 Unit 位置双关] :3049-3057；`...` 省略号实参吸收无条件[r999 宏模板面 parity :3030-3038]；→ `(f args...)` 平列表同构；macro_arg = expr \| `ident = expr`） |
| 39 | primary_expr | 626-627 | parse_primary :3127-3228 | ✅/○ | 一致（字面量/路径/括号/闭包/向量 + if/match/handle 值形前置分派臂 :3132-3151[r110/r121/r143 三先例]）；struct_lit 02:633-634 = 登记态（LBrace primary 位 = 期望表达式 fail-closed——结构类型愿景）；path_expr `::<...>` 泛型实参 02:628 = 登记态（路径级消歧未实施） |
| 40 | closure_expr | 629-632 | parse_primary OrOr 臂 :3218-3222 → parse_closure_body :3232-3251 | ✅ | **逐位一致 E-3（§3.1 落档）**：`[ "move" ] "\|\|" [ "(" [ params ] ")" ] [ "->" effect_union ] block` ↔ LParen 可选 parse_typed_params → Arrow 可选 consume_effect_union → parse_block → `(fn (params) body)`——语料三形正典零偏差（closures.ktf:17 `\|\| { n = n + 1; n }` / :27 `\|\| (x: i64) { x + n }` / higher_order.ktf:32 `map(\|\| (x: i64) { x * x }, …)`） |
| 41 | module_export（r109） | 711-712 | parse_export_decl :1437-1467 | ✅ | 一致（`export x, y;` → `(export x y)`——D50 再出口元数据消费形） |
| 42 | require_decl（r125） | 722 + cap_name 741 | parse_require_decl :1933-1963 | ✅ | 一致（`require io, write;` 裸名逗号族 → `(require io write)`；E0018 顶层位纪律 Stx 层双皮肤共享；块内/表达式位 = 期望表达式 fail-closed——02:741-743 注记逐字兑现） |
| 43 | extern_decl + kind（r137 + r147 可选 as 别名） | 734-741 | parse_extern_decl :1982-2091 | ✅ | 一致（kind 三词表 int/str/ptr 结构校验 fail-closed :2029-2037；`()` 零参 kind 表 = Unit 双关 :2022-2024；可选 `as` 别名 r147[Ident 限定——扁平空间无 Path] :1994-2016；`->` kind 返回必选 :2045；六元素 Stx `(extern NAME as ALIAS (kinds) RET)`） |
| 44 | macro_decl / macro_literals / macro_arm / macro_pattern / macro_template（r129 宏定义面） | 904-927 | parse_macro_decl :2111-2203 + parse_macro_pattern :2211-2283 + parse_macro_template :2289-2295 | ✅ | 一致（宏名首元素 Reader 注入[r128 resume-k 先例] :2230-2232；`()` 空字面量集 = Unit 双关 :2130-2131；≥1 臂 fail-closed :2171-2176；尾臂逗号可省 :2166；模板 = block \| expr :2289-2295；macros.ktf:13-22 正典） |
| 45 | vector_lit（r138） | 751-758 | parse_primary LBracket 臂 :3177-3217 | ✅ | 一致（`[a, b, c]` primary 位受理——逗号省略第十四皮肤映射；尾逗号 fail-closed :3194-3202；空表 `[]`；→ StxDatum::Vector[元素槽位制 D1]；postfix `[` 索引 = 域外 D6 :3089——位置纪律逐字兑现；vector.ktf:21-27 正典） |
| 46 | define 调用形 `define(NAME, e);` / quote 调用形 `quote(sym)`（皮肤面——EBNF 无专属产生式） | —（内核 apply 调用面） | parse_item 兜底 parse_stmt_into :1184/:1917-1921 + parse_postfix 调用臂 | ✅（皮肤面） | 宽松面注记：顶层表达式 item = EBNF item 域**内核超集**（reader.rs:1914-1916 代码注释明示——ModuleItem::Expr 程序入口形）；closures.ktf:20-21/30 `define(a, make_counter());` / vector.ktf:21 `quote([a, "s", 3])` 正典消费面；现代面符号字面量 = quote(sym) 调用形（20 §14 第六映射——U4 注记同源） |

**审查结论（227-b3 落档——用户指令①「EBNF 语法审查 + 闭包函数 EBNF 语法审查重选筛选」兑现）**：

- **量化**：46 产生式行（词法层 7 + 顶层/模块 5 + 函数与类型位置 5 + 声明族愿景 3 + 语句 6 + 模式 2 + 效应执行/处理 4 + 表达式 8 + 增补位声明族/宏/皮肤面 6——基座行与增补位行分列对照）。实施状态分布：**✅ 已实施 34**（其中 2 行宽松面注记[perform 括号可省 #29 + item 内核超集 #46]、3 行含登记态子项[#8/#27/#39]）/ **◐ 剥离实施 5**（fn_decl #13、params #14、type 族 #15、effect_union #16、move #36——types/effects/generics/mut/move 俱为 parsed-then-stripped）/ **○ 登记态愿景 7**（char_literal #5、visibility #11、where_clause #17、type_decl 族 #18、effect_decl 族 #19、capability_decl 族 #20、range/bitwise/cast/字段/索引/管道 #37——词法保留 + domain_out 结构化诊断或无 Token，r104 愿景域按 D6/原则 54 加注不动本体）。
- **漂移处置**：漂移→修正 **1**（E-1 fn_decl 返回签名——本轮 02:544 修正 + 02:545-547 注记）；宽松面注记 **3**（E-2 move 前缀 #36——本轮 02:631-632 注记；perform 括号可省 #29；item 内核超集 #46——后二者语料正典不破坏 EBNF 所述形态，注记登记非修正）；登记态注记 **2**（char_literal #5 无 Token + match 基座臂体 `block` 形 #26 = r104 愿景行被 r121 增补取代——增补位正源口径）；一致实证 **1**（E-3 closure_expr #40 零偏差）。
- **十四级优先级表抽查**（4 级）：or(12)/and(11)/comparison(10) 非链式 + additive(5)/term(4) 左结合 + unary(3) + postfix(1)/primary(0) 实施链与 EBNF 层级文法逐级对齐；第 13/14/6-9/2 级（range/pipe/bitwise/cast）= 登记态诊断位（reader.rs:2871-2873 注释即此口径）。
- **闭包 EBNF 重选筛选结论（E-3 深审——§3.1 兑现）**：`||` 形复核**确认终选维持**。备选① `fn` 表达式形（`fn (x) e` 一等闭包字面量）拒绝——`fn` = 声明族关键字（parse_item KwFn 臂 :1157 绑定顶层声明位；表达式位无受理通道），词面复用将造语句/表达式双位二义且与「声明 vs 值」的语法分工冲突；备选② Rust 风 `|x| { … }` 拒绝——`\|` = 保留运算符 Token（match or 模式 02:853-855 + effect_union 联合 02:658 的既有消费位），`|x|` 引入将击穿 EBNF 例 3/18 二义性预防的词法根基（单竖线在模式位与 lambda 参数位的前瞻不可区分）；`||` 前缀 = 强制闭包标记无二义——primary 位 `||` 起手唯一定向 parse_closure_body :3232（运算位 or_expr :2887 左侧必有操作数，primary 位空起手 = 闭包起手，两域零碰撞），与逻辑或 `\|\|` 运算位的消歧由句法结构承载（`a || b` 的 `a` 已消费 → postfix 位不再受理 OrOr）。**结论：closure_expr 产生式与实现/语料三方零偏差，EBNF v9 定稿维持，无修正义务。**

## §4 裁定 D1-D8

- **D1 零 Rust 代码变更**：纯文档窗——1788:0:0 逐位保持义务（GATE 1 复验即兑付）；8 原语不变性第三十九轮（零机制变更零新原语零通道）。
- **D2 分流三判据**：J1 历史 KEEP / J2 内核 KEEP+桥 / J3 用户面退役形 UPDATE（§2.1）。
- **D3 U1 现行名修正**以「表述对象是现行实体」为界——历史窗记述（r74-r154 各窗验收记录中的 .krf）KEEP 时点实况。
- **D4 U2 时名清偿**仅限 `lambda`（assign/do 已现代）；数学推导式（01 §7.3）含时名者 KEEP（理论记号面 + 既有对账注记）。
- **D5 U3 最小侵入**：节头/表头桥注优先，行级改写仅限「用户面声明形直陈」行（U3-5/U3-6）。
- **D6 EBNF 修正边界**：仅「实现-文档漂移」点（E-1）修正文法本体；愿景元素（pub/类型声明族/Level 1-4）加注不动本体（定稿域免疫纪律——原则 54）。
- **D7 外部语言示例**（14:391 Racket 对照）KEEP。
- **D8 已删锚重锚**（U4）：历史注记形态（不删行——§8.6）。

## §5 量化验收

1. GATE 1 六命令 clean 起步全绿 + **1788:0:0 逐位保持**（RUST_MIN_STACK=33554432）+ 审计×6 真实 EXIT 0 ×6 + CLI 八探针零回归（含 bench 带内 + .krf 拒收三短语）；
2. UPDATE 面逐点全落：U1 ×10 项 + U2 桥注+时名 + U3 ×6 桥 + U4 注记 + E-1 修正——本表 §2.3/§3.1 逐点对账归零；
3. KEEP 面零漂移：版本头/D 表/皮肤字典 §14/Level 1-4 抽样 diff 零变化（git 逐文件核验）；
4. EBNF 审计表 ≥30 产生式行 + closure 专项深审结论（§3.1 E-3 落档 + §3.4 回填）；
5. 改动文件相对链接零死链；
6. §19 打包三验（成员/字节/sha256 + 独立解包净构建 + 1788 复跑）+ web E2E 四探针 + lint 0（227-e）。

## §6 治理回写清单（227-d）

matrix.md r157 增量行（净 0 = 1788 纯文档轮）+ RELEASE_NOTES r157 节 + t3plus v1.77 r157 消费注记（14 行判定零变化——本轮开用户指令窗非 T3+ 行）+ 本文件 Status → Closed + worklog 三链（kerf/worklog.md + docs/worklog.md 镜像 + 会话根 worklog.md）+ web 五件同步（227-e：kerf-data ROADMAP r157 行 + hero 徽章 + footer 时间线 + download README r157 节 + stats 双源对账自动）。

---

*遵循条款：§1.2（L2 路由——纯文档轮 r104/r155/r156 同族先例）/ §2.2 原则 31（表面-内部分离——J2 判据根基）/ §2.2 原则 38/44-58（愿景登记态——KEEP 面纪律）/ §3.2（六命令）/ §5.3（八项）/ §6.4（commit 规范）/ §7.2/§7.3（门审 = EBNF 审计表 ≥30 行 + 审计×6 承载）/ §8.4.5（R4 文档随代码——U1/E-1 根基）/ §8.6（只追加——KEEP 面纪律）/ §19（打包三验）/ §20.6（诚实验收）。*

# kerf-list 域自建迁移窗（list domain self-built migration）——设计单源 v1.0

> **Author**: kerf-dev-agent（Super Z main — ARCH-A 裁定 + DEV-A 实施；技术委员会复合窗）
> **Date**: 2026-11-26（r164 / 235 族——M1 指令开窗第六十九例：用户指令「在种子端应该是极小的（只有不能实现的部分内容），其余应当全部通过自己自建实现」的 list 域行权）
> **Window**: r164（235-a 审计 → 235-b 设计 → 235-c 实施 → 235-d 测试门 → 235-e 验证 → 235-f 收口 → 235-close 投票）
> **Status**: Closed（r164 / 235-e 收口——D1-D12 兑付 + **v1.1 性能边界裁定修订**：迁移集 7 → 5{member/assoc 泊回 Rust——check-HM 查询段深度敏感热消费触发 10⁹ TCO 守卫 @37s 实测；其 kerf 实现已证[E2E + 错误面逐字节]——native-AOT 性能回收路径就绪后触发式重迁}；GATE 1 六命令全绿 2012:0:0 净 +33 + 审计复跑 125:0 + CLI 零回归 + bench fib 76.506ms[基线 74.814ms——+2.3% 链级——迁移面占比实测确证]）

---

## 0. 开窗依据与审计输入（235-a 三面盘点实录）

用户指令第 1 条三载荷的审计判定（本轮 235-a 实测）：

| 载荷 | 审计面 | 判定 | 依据 |
|---|---|---|---|
| 「S表达式旧时代的编码习惯」 | 自举语料编码内容（10 件 .ktf） | **零新实锤**——现代面为主（`f(a, b)` 调用形全域；toplevel let 123 / fn 653 / match 35 / == 48 / 元组 235 / 索引 8）；`(f a b)` S-expr 形匹配 100% 为注释行（历史注记——r156 清偿成果维持） | r156 legacy-residue-clearance Closed + r151/r152 语料重写 |
| 「需要禁止的S 表达式内建函数」 | 内建注册面退役表 | **零新实锤**——r42 移除轮 27 旧名全退役（E0021 拒收 + 闭合守卫 `removed_names_closed_and_modern_registered` 零漂移）；`mod`（r159 裁定维持——`%` 中缀面的调用形）+ `=`（r162 休眠态申报）俱有裁定在案 | builtins.rs `REMOVED_BUILTIN_NAMES` + 20 §7 |
| 「种子端应该是极小的（只有不能实现的部分），其余应当全部通过自己自建实现」 | **种子端（Rust）内建极小性** | **实锤开窗**——kerf-list 域 8 内建中 7 定参函数（length/reverse/nth/drop/member/assoc/last-pair）为 N1 面外纯 pair-spine 计算，可用 kerf 自身完整表达；preamble.ktf（map/filter/foldl/foldr/for-each）先例族已证可行 | 用户指令直接行权 + BS-A 最大化前端自举 + §2.3-1 正确>妥协 |

**不可自建边界裁定**（「不能实现的部分」——维持 Rust 种子）：

| 域 | 不可自建依据 |
|---|---|
| 运算符族 12（`+`…`>=`） | VM 指令级原语（数值塔语义内核） |
| `cons`/`head`/`tail`/`list`/`vector`/`vector-ref` | N1 数据模型词汇（可见性机制 = 运行时全局绑定天然全域可见——语料形态无法承载 N1 无声明可见语义）；`list` 另为变参构造 |
| 谓词族 11 + `eq`/`not`/`error`/`assert-eq` | 谓词 = VM 类型 tag 运行时面；`eq` = r162 一相等律 VM 单源纪律（Op::Eq 同源不可分裂）；N1 面约束同上 |
| io 族 6 | 宿主 I/O + 能力门控 E0006 冻结 |
| string 域 11 / symbol 域 2 | 宿主类型边界（str 字节级原语缺失——加原语违反 8 原语不变性；同 f64 解析裁定族——reader.ktf 头注先例） |
| char 域 2 | Unicode 属性查表 = 宿主数据面 |
| vector 域 5 | VM 堆值操作（HeapObj::Vector 槽位制——r138 D3 值模型） |
| **`append`（本窗裁定）** | **变参函数面语言缺位**（0/1/n 参数变元——Rust `args` 切片天然面；kerf fn 定参面）——触发式登记 TD-038 |

## 0.1 性能 PoC 实测（235-a 前置——裁定输入）

- **函数级对照**（2000 元素表 × 300 轮）：内建 `length`（Rust pair-spine loop）= **15.997ms/轮**；kerf 自建尾递归 `my_length` = **199.570ms/轮**——**12.5x 减速**（VM 解释尾递归帧 vs 原生 loop）。
- **消费密度**（现代调用形实测）：`length(` 91 / `reverse(` 58 / `member(` 19 / `nth(` 17 / `drop(` 7 / `assoc(` 6 / `last-pair(` 0（`append(` 32 变参维持）；原语基座对照 `head(` 653 / `tail(` 687 / `cons(` 342（N1 维持——热路径大头不动）。
- **生产 VM 跑语料的影响分布**：reader.ktf（run/check 全链 Reader 段）= reverse 30 + member 7 + length 1；check.ktf（check 命令 HM 段）= length 14 + assoc 3 + reverse/drop/member 各 1；编排五件 = 长尾（≤10 处/件）；expander.ktf/compiler.ktf（parity 语料——测试链）= length 54+20 / reverse 5+22。
- **链级影响预估**：迁移函数占生产链 list 操作总量 ~10%（原语基座 90% 维持 Rust）；bench fib 基线 74.814ms（本轮实测）——预期影响中个位数 ms 级；实施后链级对照透明落档（§6 D9）。
- **优化回收路径登记**：native AOT QBE 后端（CLI `native` 子命令 PoC 既有）将 kerf 递归编译为机器码——性能回收的既定路径；本窗性能代价 = 过渡期代价（Stage 2+ 优化窗域）。

**裁定**：架构正确性 > 过渡期性能代价（§2.3 细则 1「正确>妥协」）；性能数字全透明落档（非静默）+ 优化回收路径登记（非阉割）。

---

## 1. D1 迁移集与目标形态

**迁移集（7 定参内建 → `bootstrap/list.ktf` kerf 自建）**：

| 函数 | 参元 | 尾递归化形态 | 错误面（复刻目标——逐字节） |
|---|---|---|---|
| `length` | 1 | `length_go(lst, acc)` 尾递归 + 包装 | `"length requires list(nil terminated pair chain), got {T}"` |
| `reverse` | 1 | `reverse_go(lst, acc)` 尾递归 + 包装 | `"reverse requires list, got {T}"` |
| `nth` | 2 | 尾递归（走 tail 链） | `"nth index requires a non-negative integer, got {N}"` / `"nth index requires int, got {T}"` / 越界 `"nth index {N} out of range for list of length {L}"`（按现行消息复刻） |
| `drop` | 2 | 尾递归 | 按现行消息复刻 |
| `member` | 2 | 尾递归 | 按现行消息复刻（miss → `()`） |
| `assoc` | 2 | 尾递归 | 按现行消息复刻（miss → `()`） |
| `last-pair` | 1 | 尾递归 | 按现行消息复刻 |

**维持 Rust（2 名）**：`list`（N1 变参构造——可见性机制 + 变参双约束）、`append`（变参——TD-038 登记见 §8）。

**目标形态**：`list.ktf` = kerf-list 模块语料件（bootstrap 第 11 件）——模块头 `module kerf_list { import ...; export ...; }` 形态对齐 preamble.ktf 先例（N1 模块生产面）；体 = 7 函数 kerf 定义 + `type_name` 私有 helper（错误面拼接用）。

**实现词汇封闭律（D11 自举非自指）**：`list.ktf` 体只消费 N1 原语（`cons`/`head`/`tail`/`is-nil`/`is-pair`/谓词族）+ `fn`/`if`/`==`（r162 扩域后跨值域相等可用）+ `string-append`（kerf-string Rust 域——错误消息拼接）+ `error`（N1 中止原语）——**零消费自身域函数**（length/reverse/... 不出现在自身定义内）——装载编译非自指，干净。

## 2. D3/D4 注入机制（forms-level 注入——preamble 先例同型）

**现状**：`import kerf_list` ⇒ 编译期 flat 名可见性（`injected_names` 机制）+ 运行期 Rust 全局（`register_globals` 全量注册——无注入动作）。`import kerf_prelude` ⇒ `front_from_forms` Stx 层注入 preamble.ktf 形式（r135 D14 路径）。

**迁移后**：
- `import kerf_list` ⇒ **Stx 层注入 `list.ktf` 顶层形式**（编译单元 forms 合并——用户程序顶层多出 7 定义 + type_name helper；flat 可见面机制不变——`injected_names` 照常登记 8 名〔含 append 维持绑定注入〕）。
- `import kerf_prelude` ⇒ **级联注入**：preamble.ktf 形式 + list.ktf 形式（nth/drop 重导出域——`PRELUDE_EXPORT_NAMES` 的重导出面维持，定义单源在 list.ktf——不复制实现进 preamble）。
- `append` 的 flat 注入维持运行时绑定语义（Rust 全局——`injected_names` + globals 既有路径零变化）。

**装载**：`const LIST_SRC: &str = include_str!("bootstrap/list.ktf");`（`PREAMBLE_SRC` 同族——driver.rs）；种子 Rust target Reader 解析（`compile_front_seed_target` 路径——非 VM 自读，无自举环）。

**遮蔽语义（D10 行为变更申报）**：注入的 7 定义为编译单元顶层 define-face 名——用户顶层重定义 = 最新绑定胜出（r161 重绑移除先例）+ W1002 遮蔽通知面（现状 Rust 全局不可遮蔽）。**裁定**：行为变更合法（更现代——用户可遮蔽库函数；与 preamble.ktf 的 map/filter 遮蔽语义**完全对齐**——同型先例）。

## 3. D5 错误面 parity 复刻

`type_name` helper（kerf 端 12 分支谓词嵌套）：`is-nil`→"nil"、`is-bool`→"bool"、`is-int`→"int"、`is-float`→"float"、`is-number`→"number"、`is-string`→"str"、`is-symbol`→"symbol"、`is-pair`→"pair"、`is-list`→"list"、`is-procedure`→"procedure"、`is-vector`→"vector"（VM `type_name()` 字符串逐字节对照——builtins.rs 现行消息源）。错误消息 = `error(string-append(<前缀>, type_name(x)))` 形拼接——逐字节复刻现行文本。

**E0007 渲染 parity**：`error` 内建调用产生运行时错误——错误码/渲染与 Rust 端 `RuntimeError::new` 同路径（error 内建本就是同一原语——天然 parity）。

## 4. D7 HM/check 面涟漪

- **BUILTIN_SIGS**：7 名签名行退役（length `(list)→int` 等严格域检查退役）→ 语料函数 HM 泛型推断（`T, T → T`——preamble T 占位符先例）。
- **check.ktf 签名表**：list 域 7 行退役（append 行维持——793 行变参签名）；`length` 的 `(list)→int` 静态域诊断退役（负向测试锚翻转——r162 九处涟漪同族）。
- **静态面变化申报**：`length("abc")` 静态域检查（E0004 check 期）→ 运行时 is-pair 检查（E0007 运行期同消息）——**报错时机后移**（静态→运行时），消息文本不变。诚实落档（与 r162 「报错>静默」张力消化同族——此处报错保留仅时机后移）。

## 5. D8 注册面收缩

- builtins.rs：7 `BuiltinFn` 定义退役（~150 行 Rust 减量——种子端收缩的**窗宗旨兑付**）；`STDLIB_MODULES` list 行调整（`list`/`append` 维持注册——7 名转语料源注记）；`module_flat_underlying` flat 面语义维持（import kerf-list 的 flat 注入面 8 名不变——7 名经 forms 注入 + append 经 globals 绑定）。
- **闭合守卫**：`n1_core_and_module_flats_closed` 对账口径更新（7 名出注册面后的 N1 ∪ flats 闭合重校——flat 面总数不变，源标注变化）。

## 6. D9/D12 验证与性能透明

- **32 case 门**（`ktf_list_selfbuilt_tests`）：8 正（7 函数核心 E2E + 级联注入复合）+ 24 负（1:3——错误面消息逐字节锚 ×7 + 遮蔽语义 + 越界/非 list/非 int 边界 + prelude 级联 + 双 Reader parity + 7 类错误 ≥6 类 + 上轮 r163 边界 ≥5）。
- **自举链 fixpoint 全绿**：reader/expander/compiler 等七件语料 `import kerf_list` 走新注入路径——语料编译产物字节码变化（多 7 定义）→ `seed_ktf_parity_tests`（119 case）与**增长签名锚重校准**（r160 先例：reader.ktf payload 215/504/246 → 新值落档）。
- **性能对照**：bench fib 基线 74.814ms → 实施后实测落档；净构建时长基线 19.87s → 实施后对照；PoC 12.5x 函数级数字 + 优化回收路径（native AOT）登记。
- **GATE 1**：六命令 clean 起步全绿（1979 基线 + 32 净增预期——法修订涟漪如实申报）。

## 7. 实施序列（235-c..f）

1. `list.ktf` 语料件（7 函数 + type_name helper + 模块头）
2. builtins.rs 7 BuiltinFn 退役 + STDLIB_MODULES 调整
3. driver.rs LIST_SRC + imports_list 判定 + front_from_forms 注入扩展 + prelude 级联
4. check.ktf 签名表 7 行退役 + BUILTIN_SIGS 涟漪
5. 现有测试锚全量审查（std/list 测试面 + parity 锚 + 增长锚重校准）
6. 32 case 新门 + GATE 1 六命令 + CLI 探针 + 性能对照
7. 治理八件（02/20/matrix/RELEASE/t3plus/登记册/设计单源回写/README）
8. 打包 r164 + web 五件 + worklog 双追加 + 投票

## 8. 诚实边界与登记

- **TD-038（新登记）**：变参函数面语言缺位（append 迁移阻断——kerf fn 定参面 vs Rust args 切片变元面）——触发式（信号 = 变参函数用户面需求 or 语言面设计窗；清偿 = 变参机制设计后 append 迁移）。
- **性能代价**：过渡期 12.5x 函数级减速透明落档（非静默）——优化回收 = native AOT QBE 面（Stage 2+ 优化窗域）；OBS-C 65ms 观测线维持登记态（基线 74.814ms 本已失守——观测性非阻断）。
- **静态检查时机后移**（D7 申报面）：length 等 7 名的 check 期域诊断退役 → 运行期同消息——报错保留、时机后移（非静默化）。

---

*遵循条款：§2.2 原则 31（皮肤换骨架不变——本窗为**实现源迁移**非皮肤窗：Stx 产物/字节码形态变化但用户面行为 parity）/ 原则 27（加性演化——append/list 维持 + 7 名语料源替换）/ 原则 41（脚手架生命周期——种子内建是宿主脚手架，拆除判据 = kerf 自建替代行为等价[本窗兑付]）/ §2.3-1（正确>妥协——架构正确性优先于过渡性能代价）/ §2.3-4（报错>静默——错误面逐字节复刻 + 时机后移申报）/ 原则 9（核心冻结——8 原语不变性第四十六轮：零新原语零通道，cons/head/tail 基座维持）/ BS-A（最大化前端自举——07 §4）/ §18（零新依赖）/ §20.3（同类路径全量审查——7 函数错误路径族全覆盖复刻）。*

---

## 9. v1.1 收口实录（r164 / 235-e——性能边界裁定 + GATE 实录）

### 9.1 性能边界裁定（实施中实测触发的 D1 修订）

- **PoC 前置**（§0.1 已档）：函数级 12.5x（2000 元素 × 300 轮——内建 15.997ms vs kerf 尾递归 199.570ms）。
- **实施中墙**：全 7 名迁移态下 expander 语料 check **37s 撞 10⁹ 指令守卫**（TCO tail-loop guardrail）——check-HM 段的 member/assoc 查询消费（签名表/环境查询——深度敏感 + 10⁵ 调用级）× 每调用 kerf 尾递归 ~1500 指令 = 超 10 亿。
- **裁定**：**member/assoc 泊回 Rust 注册**（「不能（以可用性能代价）实现」的工程边界——过渡期 VM 解释器约束）；length/reverse/nth/drop/last-pair 五名维持迁移（浅操作——长度敏感但量级可控，expander check 收口于 24.1s ✓）。
- **member/assoc 重迁触发**：native AOT QBE 后端（CLI `native` PoC 既有）的性能回收就绪 = 触发判据（与 TD-038 同族登记）。
- **泊回涟漪**：BUILTIN_SIGS 两行恢复 + check.ktf 签名两行恢复 + STDLIB 注册恢复 + list.ktf 两函数移除 + W1002 级联豁免维持 + 测试锚回翻（member/assoc 静态域面回归）。

### 9.2 GATE 1 实录（六命令全绿）

- **build** --release 零告警；**check** --workspace --all-targets 0:0；**fmt** 0 diff（新代码一处折行当场清偿）；**clippy** -D warnings 0（r163 既有文件 ktf_index_access_tests.rs:109 一处 needless_borrow 新 lint 漂移当场清偿——r158/r161/r163 同族教训第四例）；**test** --release --workspace **2012:0:0 净 +33**（1979 基线 + ktf_list_selfbuilt_tests 33 case 新门[8 正 + 24 负 1:3 + 1 边界复合附增]）；**审计复跑** architecture_audit + seed_ktf_parity 125:0。

### 9.3 法修订涟漪（全数定性）

1. stdlib_tests arity 矩阵 8 锚翻转（内建形消息 → fn 形 E0004）
2. member_any_model n01-n04/n07-n10 锚翻回（泊回面静态回归）+ n13/n14/n15 双锚化（静态 type mismatch + 运行时消息）
3. diag_msg_parity 5 锚（n01/n02/n24 → type mismatch；n07/n08 → 运行时锚）
4. tc_sigs_parity 7 锚（n01/n04/n17/n21 → 运行时锚；n02/n18 → type mismatch；n22 → 静态 1 + 运行时）
5. seed_parity neg16/neg17（运行时锚 + type mismatch）
6. read_line p07 oracle 计数 63→58；n24 语料锚 expander 5→0（静态域退役）
7. hm_production occurs 锚 6→14（注入体 8 条保守假阳性——r80 接受族）+ krf 语料锚 expander 5→0
8. hm_inference td030 ①-④（oracle 面 2 条注入体保守行——生产面零诊断 CLI 实证）
9. hm_krf_path multi_parity import 面切换（kerf_list→kerf_string——注入体 oracle 行破坏双面计数 parity 的规避）
10. namespace d50 按名查找（级联注入序 list-first）
11. switch_corpus fixpoint B₀' 手动注入对齐（裸 strip 路径 → list-body 前置）
12. builtins 四守卫对账（105/93/16/58 族计数 + SELF_BUILT 跳过条件）

### 9.4 遗留与登记

- **TD-038**（新登记）：变参函数面语言缺位（append 迁移阻断——kerf fn 定参面）——触发式。
- **TD-039**（新登记）：member/assoc 自建重迁（native-AOT 性能回收触发）——触发式。
- **增长锚**：零重校准（seed_ktf_parity 的 215/504/246 锚测裸语料路径——注入不改变裸产物；list.ktf 为新件不入 reader.ktf 本体）。

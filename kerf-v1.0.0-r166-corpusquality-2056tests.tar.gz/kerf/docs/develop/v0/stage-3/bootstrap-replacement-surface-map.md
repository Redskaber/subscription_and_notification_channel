# 自举替换面识别图（B 类前瞻义务识别载体——S 表达式 → 目标语言切换路径的分段全景）

> **Date**: 2026-11-16（**r148 / 218-b..218-c——终局审计基线回写（R4 审计链文档债清偿窗第三例）**：用户指令②「审查当前项目演进进度和位置，检查完全将 S 表达式 替换为 目标语言 序言剩余的任务区域和范围」行权——r71 同型问询第 3 例（M1 指令开窗第五十三例；包谱系先例：r147 217-a 同指令审计腿为第 2 例）；交付 = 本图 v1.0-r71 滞留 76 轮的 R4 全量回写（§2/§3.1/§3.3/§3.4/§3.5/§5/§7 八处滞留行翻转——代码为准实况回写）+ **§8 终局审计节新立**（「S 表达式 → 目标语言完全替换——剩余任务区域与范围」的常设终局对账节——指令②载体））；2026-09-25（r71 首版）
> **Version**: v2.0-r148（**r148 / 218-b..218-c——终局审计对账窗**：切换窗 r106-r120 全闭 + 域外清偿 r121-r147 廿七窗后首次全景对账——本图从「识别基线」升格为「终局审计基线」：§8 新增常设终局对账节（指令②「完全替换还剩什么」的常设答案位）+ v1.0 滞留行 R4 回写；§5 常设对账表历史保留 + 终局态翻转）；v1.0-r71（首版——识别基线）
> **Status**: Active（**终局审计基线**——[bootstrap-progress-review §5 三分法](./bootstrap-progress-review.md) B 类前瞻义务的**识别兑现载体** + 切换窗全闭后的**终局对账载体**（§8——「完全替换 S 表达式还剩什么」的常设答案位）；后续每次开窗评审/优化开窗的替换面对照锚）
> **上游单源**: [136-a bootstrap-progress-review §5](./bootstrap-progress-review.md)（性能优化对象三分法——判据单源）/ [07 §3.2/§3.3](../../../lang-design/07-bootstrap-strategy.md)（混合期构成 + 阶段切换信号——宿主/自举段划分权威）/ [12 §2.4.1](../../../lang-design/12-roadmap.md)（目标语法 Reader 蓝图 + 量化背书）/ [23 §2.2](../../../lang-design/23-evolution-governance.md)（触发判据表——各替换窗入口信号单源）
> **触发背景**: 用户指令 r71——「自举将S表达式到目标语言的过程中还缺少什么任务就继续推进任务（……如果项目演进流程节点到达切换S表达式到目标语言节点则可以直接说明并给出具体项目情况，以论证当前能力和节点）」；**用户指令 r147①/r148②**——「审查当前项目演进进度和位置，检查完全将 S 表达式 替换为 目标语言 序言剩余的任务区域和范围」（r71 同型第 2/3 例——本图 §5 常设对账表 + §8 终局审计节的触发源）。
> **关联前件**: [139-a surface-syntax-switch-assessment.md](./surface-syntax-switch-assessment.md) v1.0（节点判定 = 技术就绪 + 治理待触发——本文 §5 缺口清单的判定上游）/ [t3plus-trigger-audit §4](./t3plus-trigger-audit.md)（监测矩阵——本文 §4 各触发窗的信号监测底座）/ [switch-window-plan](./switch-window-plan.md) v1.11（切换窗实施计划——r106-r120 全落实证链，Status: Closed）/ [target-language-gated-tasks](./target-language-gated-tasks.md) v1.1（门控任务七项全闭）
> **谱系注记**（r148 R4 诚实登记）：本图 v2.0 曾于孤儿会话分支（r142 终局审计窗——r141 包恢复后自标 r142，因 z.ai web 保存回退与主谱系分叉）交付一次，内容随 web 回退丢失；主谱系（本图所在）r143-r147 五窗均未触碰本图，致 v1.0-r71 滞留 76 轮。r148 依代码实况全量重建（R4——文档与代码冲突，以代码为准 + 当轮修正）。

---

## 1. 识别问题与方法

**识别问题**：r69/136-a 三分法的前瞻纪律第 1 条（B 类推迟义务）与 139-a 开窗六步前置清单第 6 步（B 类替换面识别——「新 Reader Rust 段过自举替换面识别：替换窗口远近裁定先行」）共同要求的**替换面识别**，此前仅有 crate 级粗分类（136-a §5.1 三行：A/B/C 类），**尚无逐段（段 → 文件族）的识别图**——开窗评审「先过自举替换面识别」无对照载体。本图即该缺口的清偿件。

**识别方法**（勘察纪律——逐段五问；**r148 终局审计延拓**：同一五问作用于「已完成区域 / 按设计保留区域 / 剩余任务区域」三分枚举——§8）：
1. **生产角色**：该段当前是否在生产链上（`compile_front`/`check_source`/`run_source`/`compile_source` 实际调用面——driver.rs 实读为准）；
2. **自举状态**：已自举（.krf/.ktf 生产）/ 未自举（Rust 生产）/ 非自举对象（永久基座）；
3. **三分法对号**：A 类基座 / B 类替换候选（或已替换段 oracle）/ C 类语料 / 骨架（非优化对象）；
4. **替换窗口**：已完成 / 触发式判据（单源锚）/ 永不（基座）；
5. **前瞻义务**：B 类段未来优化提案的处置（推迟义务 + 例外通道）。

**证据基线**（r148 实测——恢复轮全量复验）：§3.2 六命令 clean 起步全绿（build 25.21s 零告警 / check 0:0 / fmt 0 / clippy `-D warnings` 0）+ **1916:0:0 逐位复现（1916 基线自 r147 起）** + 六审计集 280 case EXIT 0 ×6 + CLI 双语法面全探针过（fib ⇒75025/144 双面 + ffi_alias ⇒9 双面 + nested ⇒540 + multiarm ⇒217 + handle_expr ⇒327 + closures ⇒42 + vector ⇒9 + stress ⇒120 + check fib 2/9/5/38 + check ffi_alias 1/2/0/5 + test 2/2）+ bench 76.292ms 带内（<65ms 触发线不满足——OBS-C 零信号）。r71 原始基线：923:0:0 + bench 三轮 71.580/70.790/71.708ms。

---

## 2. 生产链分段实景（自举混合期构成——r71 快照；**r148 实况见本节末注记 + §8.2**）

**生产链**（`compile_front` 生产口径，CompilerKind::Bootstrap——**r71 快照**）：

```
源文本 ─read→ [reader.krf @ VM]  ─桥①→  Stx（宿主类型）
      ─expand→ [expander.krf @ VM] ─桥②→ CoreExpr（宿主类型）
      ─compile→ [compiler.krf @ VM] ─桥③→ BcProgram（宿主类型）
      ─check（旁路）→ [hm.rs/typecheck.rs @ Rust]（HM 旗标期判定面）
      ─lower（旁路，仅 dump 消费）→ [ir.rs @ Rust]（IrGraph）
      ─run→ [kerf-vm @ Rust]（VM 唯一生产路径——INC7）
```

**r148 实况注记**（R4 回写——r120 后生产链全量 .ktf 化）：读段 = **reader.ktf @ VM**（`compile_front_seed_target` 桥读——r110 起）；判定面 = **check.krf @ VM**（r80 HM 生产切换——hm.rs 退役 oracle + fallback 窄面[perform/handle 子集越界回退]；r126 项内恢复架构深化 + r140 TC-SIGS 61 行同构扩表 + r141 九族消息统一）；构建编排 = **TD-032 五切口 .krf 判定面**（r74-r90：build/cli/test/test_runner/cache——07 §3.3 Stage 2→3 信号「构建系统可用新语言重写」五生产实证）。详见 §8.2。

**种子参考链**（`compile_front_seed`，CompilerKind::Seed）：Rust 三段（kerf-reader → kerf-expander → kerf-compiler/compile.rs）——B₀ fixpoint 基准 + 字节码 parity oracle（42-d P5：eval 退役后的对拍口径）。

**量化快照**（r71 原始）：C 类 .krf 语料 4 文件 3550 行（reader 472 + expander 1865 + compiler 1147 + preamble 66）；Rust 全树 11 crate + 根 crate ≈ 28,232 行；宿主桥三件 2275 行。**r148 实况**：C 类语料 = 切换窗四件 .ktf 化（preamble 66 + reader ~560 + compiler 1404 + expander 3175）+ 种子链七件 .krf（KRF_SOURCES 守卫——bootstrap/mod.rs:718）+ target_reader.krf（~590，词法+语法双批——r107/r108）。

---

## 3. 替换面识别总表（逐段分类——本图核心交付）

### 3.1 C 类：自举 .krf 语料本体（非重复可进行——优化即优化自举链自身）〔**r148 终态注记**：四行全部 ✅ 目标语法改写完成（preamble r109 / reader r110 / compiler r114 / expander r116——切换窗步③ 语料批）+ r120 E5 收口清理批四件 .krf 原件 git rm（原则 41 拆除判据满足：≥98% parity 三路门 + 三阶段 fixpoint + 验证等价全绿）；**种子链七件 .krf 组件保留 = BS-A 混合自举宪制裁定（非剩余任务——§8.3）**〕

| 段 | 文件（行数） | 生产角色 | 替换状态 | 前瞻义务 |
|---|---|---|---|---|
| read 段语料 | ~~bootstrap/reader.krf（472）~~ → **reader.ktf（~560）** | 生产（r6/B3——`compile_front` 读路径） | ~~**永久延续**（自举链本体——按 07 §3.2.1 步骤 ③ 被新 Reader 重解析，源文件本身改写为目标语法）~~ **✅ r110 全量改写——bootstrap Reader 状态自此自 .ktf 构建**（compile_front_seed_target 桥读） | 无推迟义务（C 类可进行——信号纪律适用） |
| expand 段语料 | ~~bootstrap/expander.krf（1865）~~ → **expander.ktf（3175）** | 生产（r15/E1-β） | **✅ r116 全量改写——bootstrap Expander 状态自此自 .ktf 构建** | 同上 |
| compile 段语料 | ~~bootstrap/compiler.krf（1147）~~ → **compiler.ktf（1404）** | 生产（r23/42-d——门 B fixpoint 守护） | **✅ r114 全量改写——bootstrap Compiler 状态自此自 .ktf 构建**（r112 oracle 规范化无损顺接） | 同上 |
| 序章语料（序言——preamble） | ~~bootstrap/preamble.krf（66）~~ → **preamble.ktf（66）** | 生产（高阶函数序章——`kerf-prelude` 模块，driver.rs include_str! 单源） | **✅ r109 首件全量改写（.ktf = kerf target form 扩展名首例）** | 同上 |
| 种子链七件 .krf 组件（r148 新行；r153 拆除进程注记） | bootstrap/{check, build, cli, test, test_runner, cache, target_reader}.krf | **拆除进程中**（S-expr 完全拆除窗——用户 r149①宪制演进授权：Batch A ✅ r149{构建五面 .ktf 化} + Batch B ✅ r150{check.ktf} + Batch C ✅ 全闭 r151-r152{词法腿 r151 + 语法段 r152——target_reader.ktf 全件 4230 行——Reader fixpoint 里程碑收口：生产 .ktf 读桥的词法器+解析器俱以目标语言表述} + **Batch D ✅ r153{用户面拆除——CLI 入口收敛 .ktf 单面 + reader.ktf 生产路径退役{oracle-of-record duty} + 语料 .krf 面清理{usage 15 对删除——仓库余 .krf = 8 件种子 oracle} + 双入口测试族重构{cli_dual_entry 22 删除 → cli_entry_convergence 27 新立——门 D 三判据全绿}}**；E6 收口 r154——s-expr-removal-plan §4/v1.4 §12；单一 reader.ktf 终局整合指令 = 用户 r152① 登记{v1.3 §11——target_reader.ktf 于 E6 更名收敛为唯一 reader.ktf}） | **按设计保留 → 演进拆除中**（BS-A 条款的用户授权演进；KRF_SOURCES 守卫维持七件 + target_reader_lex.krf oracle 新立{r151}——原则 41 窗口期平行件，E6 收口批删除） | 永久保留（07 §3.2.1 宪法）→ 拆除窗收口时翻转 |

### 3.2 B 类形态 1：已自举段的 Rust 面（parity oracle 存档——替换已完成，非候选）

| 段 | Rust 面（行数） | 当前角色 | 替换状态 | 前瞻义务 |
|---|---|---|---|---|
| read 种子 | kerf-reader（lexer 584 + parser 322 + token 158 + lib 48 + **target.rs ~1580——r106 起新增**） | **种子引导**（reader.krf 的编译）+ **parity oracle**（28 函数正 87/负 307 逐字等价——两实现互为印证）+ **目标语法 Reader 种子**（target.rs——§3.5） | **已替换**（r6 生产切换）——Rust 面成 oracle 存档（INC 档案口径） | 优化默认**无意义**（非生产路径——收益归零；oracle 语义维护除外） |
| expand 种子 | kerf-expander（core_forms 987 + expander 815 + macro_sys 776 + sugar 401 + phase 238 + recover 219 + lib 等） | 种子引导 + parity oracle（E1-β 收口子集覆盖全部在用宏） | **已替换**（r15） | 同上 |
| compile 种子 | kerf-compiler/compile.rs（862）+ bytecode.rs（273） | 种子引导 + **B₀ fixpoint 基准** + 字节码 parity oracle（`compile_source_seed`/`run_source_seed` 对拍入口——42-d P5） | **已替换**（r23/42-d——fixpoint 两次编译自身字节一致） | 同上 |

### 3.3 B 类形态 2：未自举生产段（替换候选——优化推迟义务的正对象）

| 段 | Rust 面（行数） | 生产角色 | 替换窗口（触发判据单源） | 窗口远近 | 前瞻义务 |
|---|---|---|---|---|---|
| HM/typecheck 静态分析面 | kerf-compiler/hm.rs（1159）+ typecheck.rs（687） | ~~**生产**（`check_source`/`check_source_recover` 判定面——HM 旗标期 D8 阶段 2）~~ **r148 注记：✅ r80 HM 生产切换**（判定面 = check.krf @ VM——hm.rs 退役为 parity oracle + fallback 窄面[perform/handle 子集越界回退]；r126 项内恢复架构 + r140 TC-SIGS 24→61 逐行同构扩表 + r141 九族消息统一三窗深化） | ~~**HM 默认期窗口**（[12 §2.5.1 类型检查器行 K3 终态]：默认期切换窗口归 23 §2.2 治理触发表 Stage 3 承载——触发式；INC3 在案裁定「静态分析面不在自举关键路径」= 可选替换非必选）~~ **✅ r74 路径验证 PoC + r80 生产切换全落**（B 类形态 2 替换候选实证 + 兑现——残留仅 fallback 窄面 + oracle 维持义务） | ~~**中**（触发式）~~ **✅ 已兑现** | **优化默认推迟**（r53 HM O1+O4 已发生无回退义务——<0.3% 收益边际 + 方法论可迁移；未来提案走例外通道：不可容忍差距 + 消费方显式诉求载体） |
| IrGraph lowering 面 | kerf-compiler/ir.rs（904）+ kerf-core/ir.rs（475） | 生产（`compile_source`/`kerf ir` dump 消费——run 路径旁路 TD-015 分流） | **TD-003/015 三判据**（[t3plus-trigger-audit §3.1/§3.3](./t3plus-trigger-audit.md)：第二生产消费方出现 / 剖面复合节点重复 >30% / P95 >100ms 且 IR 热点——当前自举四件 <1ms + check 大头为 VM 链非 IR 面） | **远**（触发式——当前零消费压力；r148 维持） | 同上（B 类推迟） |
| driver 组合根编排面 | kerf-driver/driver.rs（3069）+ lib.rs/main.rs | **生产**（CLI check/compile/run/test/dump/bench 入口 + 前段编排 + 缓存感知 + E0022/W 验证收集 + CompilerKind 分派） | ~~**Stage 2→3 信号**（[07 §3.3]：「构建系统可用新语言重写」——未触发；15 §5.1 组合根角色）~~ **r148 注记：✅ r74-r90 TD-032 五切口全落**（build r74 / cli r79 / test r86 / test_runner r87 / cache r90——构建系统 .krf 化全收口[判定面 .krf 单源]；cache.rs 存储本体 = §3.4 A 类永久基座维持；Rust 组合根编排 = 永久形态[CLI 入口 + 桥编排——A 类基座化]） | ~~**最远**（构建系统重写 = 自举深度推进的末端信号）~~ **✅ 已兑现**（切口形态） | 同上（B 类推迟——余下编排根本体 A 类化） |

### 3.4 A 类：永久基座（非自举对象——优化直接且永久惠及自举链）

| 段 | Rust 面（行数） | 生产角色 | 替换状态 | 依据锚 |
|---|---|---|---|---|
| VM 执行基座 | kerf-vm/vm.rs（2460）+ value.rs（384）+ messages.rs + ffi.rs（467） | **生产**（VM 唯一生产路径——INC7） | **永不替换**（12 §2.5.1「vm/ 运行时基座」+ 自举链恒走 VM + LLVM/native 永不入自举链） | 12 §2 / INC7 |
| eval 参考存档 | kerf-vm/eval.rs（547） | 非生产（INC7 退役——scope_set_tests 语义 oracle 消费面保留） | 已退役存档 | TD-009/017 |
| 运行时/GC | kerf-runtime（heap.rs 564 + gc.rs + io.rs） | **生产** | **永不替换**（运行时基座——GC/堆/IO 与 VM 共生；r138 向量值模型 GC children 臂加性扩展） | 12 §2.5.1 |
| VM 内建注册面 | kerf-driver/builtins.rs（2158） | **生产**（VM 分派体内建 + 自举三件引导期 emit 助手 + prelude 载荷化单源） | **永不替换**（宿主运行时服务面——.krf 段消费的宿主内建；BUILTIN_SIGS 为 23 §117 行门控锚；r144 read-line 签名条目静态-动态元数 parity 补全） | 07 §3.2 宿主部分 |
| 宿主桥族（r155 命名标准化对账——X.ktf ↔ X.rs 对称桥族） | bootstrap/{mod.rs + reader.rs（r155 更名自 target_reader.rs——与 reader.ktf 对称）+ expander.rs + compiler.rs + check.rs + cache.rs + cli.rs + test.rs + test_runner.rs + build.rs}（r107 期旧名 bootstrap.rs/bootstrap_expander.rs/bootstrap_compiler.rs 已随自举重组更名——历史名见本行 git 史） | **生产**（call_closure 宿主调用 + 值树双向转换 + 数字类型边界[十进制→二进制正确舍入不可在语言算术中可靠重实现——bootstrap.rs 模块头既定裁定]；r147 CC_EXTERN (local flat) 对协议扩展） | **永不替换**（宿主-VM interop 面——只要宿主为 Rust 且 VM 为 Rust，桥即宿主类型边界职责；07 §3.2 混合期构成的桥层） | 07 §3.2 / 桥模块头契约 |
| 诊断/Span 基座 | kerf-span（4 文件 587） | **生产** | **永不替换**（诊断渲染/源映射——136-a A 类明列「Span 的 Rust 面」） | 136-a §5.1 |
| 能力/效应/缓存/FFI 宿主服务 | capability.rs（842）+ effects.rs（438）+ cache.rs（418）+ ffi.rs（445）+ hash.rs | **生产**（require 门控 E0006 + 内部效应逃逸层 + 编译缓存[四冻结契约之一] + FFI 注册面[run_program_with_externs——r137/r147 运行表构造]） | **永不替换**（宿主服务面——冻结契约 + 令牌铸造 crate 内控制） | 13 §3.1 四冻结契约 / 07 §3.2 |
| 后端基座 | kerf-backend（anf.rs 809 + qbe.rs 238 + codegen.rs 215 + aot.rs 181 + **wasm/ 五文件——r74-r99 新增**） | **生产**（QBE AOT 进程链——B1 PoC 边界显式在案） | **永不替换**（native 后端不入自举链——12 §2 LLVM 策略同源；~~WasmBackend P3 占位[组件模型具体化 Stage 2+ 触发式]为**新增面**非替换面~~ **r148 注记：✅ TD-031 四阶段全落**[契约层 r74 + M1 核心模块生成 r92 + M2 canonical ABI r97 + M3 组件组合 r99——v0.4.13 全清偿关闭；B1 扩界窗/组件实例协议窗触发式维持——§8.4]） | 12 §2 / TD-024 / TD-031 |
| 骨架/核心表示 | kerf-space（260——marker 域骨架）/ kerf-syntax（stx 323 + symbol 342 + scope 111）/ kerf-core（expr.rs 674 CoreExpr + code_value.rs 332 + ir.rs 475） | **生产**（桥契约类型 + 原则 31 核心形式 + P3 预留位） | **永不替换**（骨架——CoreExpr = 任何表面语法的编译产物恒同[原则 31]；kerf-space 自举后**可复刻**非必须[136-a §2：marker 无方法零载荷]——复刻属自举后演进可选项，非本轮缺口） | 原则 31 / 24 号件 / 136-a §2 |

### 3.5 切换窗实施面：新 Reader 本体（r106 步① 落地 / r107 步② 词法层 .krf 化——替换面识别实况化）〔**r148 终态注记**：五步 ① r106 / ② r107-r108 / ③ r109-r116 / ④ r118 / ⑤ r119 **全部完成 + r120 E5 收口清理批收口——窗全闭**（switch-window-plan v1.11 Status: Closed）〕

| 段 | 实施形态 | 实施路径 | 替换面判定 |
|---|---|---|---|
| 目标语法 Reader Rust 种子 | kerf-reader/target.rs（~1580 行——r106 步①：EBNF v9 Level 0 词法全量 + 内核映射域 + 皮肤字典 + 域外 fail-closed；r107 修复面：Span 字节偏移精确化[R1 桩清偿] + 带符号指数/指数 `_` 缺陷清偿 + ParityToken parity API；后续域外清偿窗增量扩充：match r121 / use r131 / 多臂 r132 / 嵌套 resume r133 / member-rename r134 / extern r137 / vector r138 / extern 别名 r147） | **B 类形态 1**（种子引导 + parity oracle——r6 kerf-reader 同构角色） | **✅ 实施即替换一次性窗口已走完**（.krf 化完成 + 生产切换后转 oracle 存档——无远期推迟义务；r121-r147 域外清偿窗均为此种子段的增量扩充[皮肤字典 14 映射族]） |
| 目标语法 Reader .krf 载荷 | bootstrap/target_reader.krf（~590 行——r107 步② 首批：词法层全量移植[进制/转义/嵌套注释/`::`/全运算符/溢出守卫 T-R 精确界/浮点可解析性前置]）+ 桥 bootstrap/target_reader.rs（~290 行） | ~~**五步流程步② 分批**：词法批 ✅ r107（target_reader_krf_tests 18 case——kind/Span/payload 字节级 parity 门）；语法批（parse 入口移植）待后续批次~~ **✅ 词法批 r107 + 语法批 r108 双批全落**（parse-target 入口 30 函数族 ~995 行——顶层/类型消费/块穿线/语句/十四级优先级子集；后续 r124/r131/r132/r133/r134/r137/r138 七窗镜像同步扩充） | **✅ C 类语料在位**（.krf 载荷 = 自举链语料本体——KRF_SOURCES 守卫七件之一；步③④ 生产切换完成 = 目标语法读路径生产段已就位 r118-r120） |

> **r148 终态注记**（r107 注记的终局收口）：新 Reader 本体全生命周期已走完——种子（r106）→ .krf 化（r107-r108）→ 生产切换（r109-r116 语料改写 + r118 compile_source_target + r119 验证等价）→ E5 收口清理（r120 原件拆除）→ 后续域外清偿（r121-r147 廿七窗——皮肤字典 14 映射族）。原蓝图 ~3000 行（12 §2.4.1）已全量兑现。替换面图 §4 用法二「识别前置已完成」判定完成历史使命——用法三（缺口对账）职能由 §5 历史表 + §8 终局审计节接续承载。

---

## 4. 开窗评审对照用法（识别图的治理消费面）

**用法一（优化开窗前置——136-a §5.3 前瞻纪律第 1 条）**：任何性能优化提案开窗评审时，先在 §3 总表对号——
- 命中 §3.4 A 类行 → 非重复可进行（按信号纪律）；
- 命中 §3.3 B 类形态 2 行 → **默认推迟**（本表已载明该段替换窗口远近——「窗口近」加重推迟权重[优化投入即将归零]，「窗口远」可按例外通道评估）；例外通道 = 不可容忍性能差距（§21.12 第 7 条判据流程）+ 消费方显式诉求载体；
- 命中 §3.2 B 类形态 1 行 → 生产不在位，优化收益归零（仅 oracle 语义维护）；
- 命中 §3.1 C 类行 → 非重复可进行（信号纪律适用）。

**用法二（目标语法轮开窗评审——139-a §5.2 步 6）**：~~信号命中后评审直接引用本图……识别前置已完成——评审收敛为信号确认 + L3 全流程分派。~~ **r148 终态注记**：本用法随切换窗 r106-r120 全闭完成历史使命（保留历史原文供审计链核对）。

**用法三（缺口对账——用户问询「还缺少什么」的常设对照）**：~~见 §5。~~ **r148 起升级**：§5 历史表（r71-r74 缺口清单——终局态翻转）+ **§8 终局审计节**（「完全替换 S 表达式还剩什么」的常设答案位——r148 新立）。

---

## 5. S 表达式 → 目标语言路径缺口清单（常设对账表——回答「还缺少什么任务」）〔**r148 终局注记**：本表为 r71 识别基线的历史对账表；全部缺口已闭（1/2 经切换窗 r106-r120、5 经 r138、6 经 TD-031 r92-r99、7 经 TD-032 r74-r90）——**终局态答案以 §8 为准**〕

**判定上游**（[139-a](./surface-syntax-switch-assessment.md) §5.1 裁定——r71 时点）：节点状态 = **技术就绪 + 治理待触发**——切换实施的能力闸门全过；剩余缺口全部为**触发式/治理式**，无任何可在零信号下推进的实施任务（23 §2.3 红线 3——禁止无信号开窗）。〔**r148 终态**：治理闸门②已于 r106 经用户信号首次满足——切换窗开窗；全链 r106-r120 落地后本判定升级为「切换完成——终局对账态」（§8.6）。〕

| # | 缺口 | 性质 | 触发判据（单源锚） | 当前态〔r148 终局翻转〕 | 可否零信号推进 |
|---|---|---|---|---|---|
| 1 | 目标语法消费信号（治理闸门） | 信号 | 语料/用户提案出现 match 表面需求（23 §2.2 目标语法轮行） | ~~**零命中**（r71 例行监测）~~ **✅ r106 用户信号命中开窗**（用户指令「继续推进 目标语言设计的实现窗」= 需求信号本体[r74 先例]——治理闸门②首次满足；r147 217-a 审计腿为同型问询第 2 例、r148 218-b 为第 3 例） | ~~❌ 不可制造~~ ✅ 已命中并消费 |
| 2 | 新 Reader 本体（~3000 行） | 实施 | 缺口 1 命中 → 六步前置清单（139-a §5.2） | ~~未开始（红线 3 合规）~~ **✅ r106-r120 切换窗全闭**（五步全落 + E5 收口清理批——switch-window-plan v1.11 Status: Closed；§3.5 终态注记） | ~~❌ 待信号~~ ✅ 已交付 |
| 3 | ~~B 类替换面识别~~（六步清单步 6 前置） | 识别 | — | **✅ 本图 v1.0 兑现**（前置完成——用法二） | **r71 已推进** |
| 4 | HM/typecheck .krf 重写路径验证 | 验证 | HM 默认期窗口（12 §2.5.1 K3 终态）；**r74 用户显式指令开窗**（[r74-window-opening §1 回填表](./r74-window-opening.md)） | **✅ r74 路径验证 PoC + r80 生产切换全落**（check.krf @ VM 判定面——hm.rs 退役 oracle + fallback 窄面；r126/r140/r141 三窗深化） | **r74/r80 已兑现** |
| 5 | TD-002 向量值类型（dangling 自 Stage 2 收口 r37） | 裁定 | ~~**r71 再裁定为 T3+ 触发式三判据**~~ **✅ r138 / 208-c 清偿关闭**（M1 指令开窗第四十三例——门控任务 #5 路径） | ~~触发式~~ 判据②轮联动臂经用户指令行权 | **✅ 已交付**（双面字面量 + 双侧脱糖 + 值模型 + 五内建 + 36 case 门——vector-value-design.md v1.0；1724 基线） |
| 6 | WasmBackend 组件模型具体化 | 实施 | T3+ 触发（P3 占位——Stage 2+ 组件模型窗口）；**r74 用户显式指令开窗**（同上回填表） | ~~**✅ r74 契约层做实**……M1-M3 字节码生成登记 TD-031 触发式维持~~ **✅ TD-031 四阶段全落全清偿关闭**（M0 契约层 r74 + M1 核心模块生成 r92 + M2 canonical ABI r97 + M3 组件组合 r99——v0.4.13；后续 B1 扩界窗/组件实例协议窗触发式维持——§8.4） | **✅ 已兑现**（四阶段形态） |
| 7 | 构建系统重写（driver 组合根 .krf 化） | 实施 | Stage 2→3 信号「构建系统可用新语言重写」（07 §3.3）；**r74 用户显式指令开窗**（同上回填表） | ~~**✅ r74 首切口生产切换**……余下面登记 TD-032~~ **✅ TD-032 五切口全落全清偿关闭**（build r74 + cli r79 + test r86 + test_runner r87 + cache r90——v0.4.10；构建系统 .krf 化余下面清零；cache.rs 存储本体 A 类维持） | **✅ 已兑现**（切口形态） |

**结论（r148 终局）**：路径缺口 7 项**全部闭合**——3/5 于 r71 兑现（识别 + 裁定）、4/6/7 于 r74-r99 兑现（验证 PoC→生产切换 / TD-031 四阶段 / TD-032 五切口）、1/2 于 r106-r120 兑现（切换窗全链）。**「S 表达式 → 目标语言」的路径级缺口清单清零**——后续对账以 §8 终局审计节为准（剩余任务区域 = 触发式域外行全量枚举，零信号不开窗）。

---

## 6. 与 139-a 判定的联动核对（节点论证——r71 增量；r148 终局注记）

- **技术就绪维持**：本图 §2 生产链实景 + §3.4 基座完备性 = 139-a §2 三项能力论证的分段级复核（五步流程机制全在位：步骤①② = 三桥日常复用、步骤⑤ = 门 B fixpoint 设施、皮肤/骨架分离 = §3.4 骨架行 + 原则 31）；~~**治理待触发维持**：本图 §5 缺口 1 = 139-a §3 治理闸门的 r71 例行复核（零信号）~~ **r148 终态：治理闸门②已过**（r106 用户信号命中——切换窗开窗行权）；
- **六步前置清单进度**：步 6（B 类替换面识别）**✅ 本图 r71 完成**；其余五步全部为信号命中后的评审动作——**✅ r106-r120 切换窗全链走完**；
- **渐进路径注记**（07 §3.2.1 对照）：~~E5 已兑现 Stage 2b 可渐进部分；剩余切换面持触发判据待信号~~ **r148 终态：剩余切换面零残留**（新 Reader 本体 + 语料目标语法改写 + 原件拆除全落 r106-r120；本图 §3.1 四行 = 改写完成清单）。

---

## 7. 结论汇总（r148 终局版）

| 问 | 答 |
|---|---|
| 替换面识别完成了吗？ | **完成**（本图 v1.0 r71 识别 + v2.0 r148 终局回写——逐段五问 × 全链 crate + 语料 + 桥 + 未来面） |
| B 类前瞻义务有对照载体了吗？ | **有**（§3.3 三行 = 推迟义务正对象 + 窗口远近 + 例外通道；§4 用法一——HM/driver 两行已兑现翻转，IrGraph 行触发式维持） |
| 开窗六步清单第 6 步？ | **✅ 前置完成**（r71——用法二；切换窗 r106-r120 全闭后本判定完成历史使命） |
| S 表达式 → 目标语言还缺什么？ | **§8 终局审计节**（§5 历史七缺口全闭——r148 终局翻转；剩余 = 触发式域外行全量枚举 §8.4，零信号不开窗） |
| 节点状态？ | ~~技术就绪 + 治理待触发~~ **切换完成——终局对账态**（r106-r120 切换窗全闭 + r121-r147 域外清偿廿七窗；1916 基线） |

---

## 8. S 表达式 → 目标语言完全替换——终局审计节（r148 新立：剩余任务区域与范围的常设答案位）

> 本节为用户指令 r148②（r71 同型第 3 例——前两例 r71/r147①）的常设答复载体：切换窗全闭 + 域外清偿链后的**终局对账**。开窗判据 = 用户问询（§5 常设对账表的刷新信号——r71 先例）+ R4 文档债（本图 v1.0-r71 滞留 76 轮——r148 当轮回写）。

### 8.1 演进位置（r148 快照）

- **版本锚点链**（测试基线）：r136 组安装 1655 → r137 FFI extern 声明族 1687 → r138 向量值类型 1724 → r139 英语编码统一 1724 维持 → r140 TC-SIGS Oracle 对齐 1756 → r141 消息文本统一 1788 → r142 member/any 双缺陷 1820 → r143 handle 表达式位 1852 → r144 read-line 签名条目 1884 → r145/r146 R4 审计链文档债清偿 ×2 1884 维持 → **r147 extern 符号空间别名 1916（1916 基线自 r147 起）**；
- **切换窗**：r106-r120 全闭（五步① r106 种子 → ② r107-r108 .krf 化 → ③ r109-r116 语料改写 → ④ r118 compile_source_target → ⑤ r119 验证等价 + r120 E5 收口清理批——switch-window-plan v1.11 Status: Closed）；
- **域外清偿链**：r121-r147 廿七窗（match r121-r124 四批 → CLI 双入口 r125 → HM 深化 r126 → .ktf 语料族 r127 → stress 语料 r128 → 宏面语料 r129 → import-as r130 → use 声明 r131 → handle 多臂 r132 → 嵌套 resume r133 → member-rename r134 → 域外三项 r135 → 组安装 r136 → extern 声明 r137 → 向量 r138 → 英语编码 r139 → TC-SIGS r140 → 消息统一 r141 → member/any r142 → handle 表达式位 r143 → read-line r144 → R4 债 ×2 r145/r146 → extern 别名 r147）；
- **治理态**：门控任务七项全闭（target-language-gated-tasks v1.1）+ 登记册触发式实施项全清零（tech-debt-register v0.4.17——开放项全为触发式 P3）+ T3+ 14 行触发族零信号（t3plus-trigger-audit v1.67）+ 行权态三十二次（guide v1.32）。

### 8.2 已完成区域（S-expr → 目标语言替换的交付全量）

| # | 区域 | 交付轮 | 证据锚 |
|---|---|---|---|
| 1 | 序章（序言——preamble）.ktf 化 | r109 | preamble.ktf（66——.ktf 扩展名首例；「序言」语义对账） |
| 2 | Reader 语料 .ktf 化 | r110 | reader.ktf（~560——compile_front_seed_target 桥读） |
| 3 | Compiler 语料 .ktf 化 | r114 | compiler.ktf（1404——r112 oracle 规范化无损顺接） |
| 4 | Expander 语料 .ktf 化 | r116 | expander.ktf（3175） |
| 5 | HM 判定面 .krf 生产切换 | r74/r80 | check.krf @ VM（hm.rs 退役 oracle + fallback 窄面；r126 项内恢复 + r140 TC-SIGS 61 行 + r141 九族消息统一深化） |
| 6 | 构建系统 .krf 化（TD-032 五切口） | r74-r90 | build/cli/test/test_runner/cache 五判定面 .krf 单源（07 §3.3 信号五生产实证） |
| 7 | E5 收口清理（原件拆除） | r120 | 四件 .krf 原件 git rm（原则 41 拆除判据：≥98% parity 三路门 + 三阶段 fixpoint + 验证等价） |
| 8 | 皮肤字典 14 映射族 | r121-r147 | 20-surface-conventions §14 v1.31（match r122 第七 / require r125 第八 / 宏定义 r129 第九 / import-as r130 第十 / use r131 第十一{r134 位域扩展} / handle 多臂 r132 第十二{r136 组安装翻转} / extern 声明 r137 第十三{r143 handle 位域 + r147 别名域扩展} / 向量字面量 r138 第十四） |
| 9 | 目标 Reader 种子 + .krf 镜像 | r106-r108 + 域外七窗镜像 | target.rs（~1580 + 增量）+ target_reader.krf（~590 + 语法批 ~995）——KRF_SOURCES 守卫七件之一 |
| 10 | CLI 双入口（双语法面并存） | r125 | .ktf/.krf 双面入口分派（CompilerKind 分派面——r125 双入口窗） |
| 11 | 语料族 + 验证设施 | r127-r147 | examples/usage 语料 15 对 + effect.ktf 孤件（16 .ktf / 15 .krf）；parity 五连（双 Reader 正典渲染/错误面字节级 + 跨语法行为等价 + 组等价字节码全等门 + fixpoint 门族） |

### 8.3 按设计保留区域（非剩余任务——终态设计裁定）〔**r150 拆除进程注记（续）**：Batch B ✅——check.krf → check.ktf（HM 生产判定面 1285 行——r116 第二规范化双侧逐字镜像{七关键字 TAG 常量 13 位点} + 'nil→quote(()) 字面量化位 + check.rs 桥切换 compile_front_seed_target + 门 B 字节码 parity{seed_ktf_parity_tests 64 case——1980 基线净 +32}；check.krf 规范化 oracle 平行件保留{E6 删除}）；种子链七件中已 .ktf 化 = 六件{build/cli/test/test_runner/cache/check——余 target_reader.krf{Batch C r151-r152——Reader fixpoint 里程碑}}；r149 拆除进程注记**：本表前两行（种子链七件 .krf + 用户 S-expr 面）经用户 r149 指令①时机授权转入**拆除进程中**——S-expr 完全拆除窗开窗{s-expr-removal-plan.md v1.0：Batch A 构建五面 ✅ r149{build/cli/test/test_runner/cache 已 .ktf 化——.krf 原件保留为窗口期 oracle} / Batch B check.krf r150 / Batch C target_reader.krf r151-r152 / Batch D 用户面拆除 r153 / E6 终局清理 r154}；第 3 行 A 类基座维持按设计保留（「VM 永久 Rust 基座」宪制条款零触碰——12 §2.19 / 07 §4 BS-A）；§8.6 终局结论的「设计终态」裁定随本窗演进为「拆除进程态」——终局答案位随各批收口更新〕

| # | 区域 | 裁定依据 |
|---|---|---|
| 1 | 种子链七件 .krf 组件（check/build/cli/test/test_runner/cache/target_reader） | BS-A 混合自举宪法（07 §3.2.1——种子 = 引导期 S-expr Reader 读入；KRF_SOURCES 守卫） |
| 2 | 用户 S-expr 面（CLI 双入口的 .krf 面） | 用户面永久双语法（r125 双入口窗——双面表达力 parity 缺口连续清偿 r125-r147） |
| 3 | A 类永久基座（§3.4 九行） | VM/运行时/桥/Span/宿主服务/后端/骨架——12 §2.5.1 + 07 §3.2 + 13 §3.1 冻结契约 |

### 8.4 剩余任务区域全量枚举（r148 实测——全部触发式零信号）

**A 族：语言面触发行**（设计单源 §7 域外表——触发判据 = 语料消费信号或用户指令）：
- ffi-language-surface §7 五行（CStruct/CFunction interop + Alloc/FreeExternal 语言形 + 测试运行器 extern 前置切分 + 模块体内 extern 声明位 + extern 调用 HM 签名执法）+ kind 词表扩词行
- handle-expr-position §7 五行（块形 protected + halt/pass 块体语句位 + effect_pattern 泛化 + 裸臂形 + resume 多参/命名形）
- vector-value §7 五行（match 模式位向量 + postfix 索引语法 + 可变向量族 + 转换族 + Vector HM 类型构造）
- handle-multi-arm §7 行 + tc-sigs §7 四行 + member-rename §7 四行 + use-declaration §7 三行 + match-design §7 三行 + nested-resume D5-D7 + switch-window-plan §4 余一行（类型/效应/能力声明族——Stage 2+ 独立窗）
- **r148 六族语料信号实测全零**：net 0 / @ 家族 0 / syntax-parse 0 / vector .krf `#(` 0 / CStruct-CFunction 0 / extern 语料在位（r137/r147 窗交付物本体——非新需求信号）

**B 族：优化/架构触发行**（T3+ 14 行触发族——t3plus-trigger-audit v1.67 判定零变化）：
- TD-003 图 IR CSE / TD-015 无条件计算旁路 / TD-024 本地码后端 PoC 边界（B1 扩界）/ TD-026 ②③④（CStruct 编组 + CFunction 回调 + token 语言形）/ OBS-C（fib <65ms 需求信号——r148 实测 76.292ms 不满足）

**C 族：治理触发行**：
- #15 讨论链（需 next23.md——未上传维持，最新上传 next21.md）
- Stage 2+ 门控面（类型观测层 / 组件实例协议窗 / 命名空间演进——红线 3 禁止猜测性实施）

**终局裁定**：零用户指令臂开放行（r147 已清偿末行——extern 别名）；全部剩余行 = 触发式域外，**零信号不开窗（23 §2.3 红线 3）**。

### 8.5 R4 回写对账（r148——本图 v1.0-r71 滞留 76 轮的清偿）

| # | 滞留处（v1.0-r71 原文） | 实况（代码为准） | 回写 |
|---|---|---|---|
| 1 | §3.1 四行「永久延续——改写对象」 | r109-r116 全量改写 + r120 原件 git rm | ✅ 本轮翻转 |
| 2 | §3.3 HM 行「HM 默认期窗口——触发式」 | r74 PoC + r80 生产切换 | ✅ 本轮翻转 |
| 3 | §3.3 driver 行「Stage 2→3 信号——未触发」 | TD-032 五切口 r74-r90 全落 | ✅ 本轮翻转 |
| 4 | §3.4 后端基座行「WasmBackend P3 占位」 | TD-031 四阶段全落 r74-r99 | ✅ 本轮注记 |
| 5 | §3.5「步② 语法批与步③④⑤ 待续」 | r108-r120 全落 | ✅ 本轮翻转 |
| 6 | §5 缺口 1/2「零命中/未开始」 | r106 用户信号开窗 + r120 窗全闭 | ✅ 本轮翻转 |
| 7 | §5 缺口 6/7「M1-M3 触发式维持/余下登记 TD-032」 | TD-031 r99 / TD-032 r90 全闭 | ✅ 本轮翻转 |
| 8 | §2 生产链图（reader.krf 读段 + hm.rs 判定面） | reader.ktf 桥读 + check.krf 判定面 | ✅ 本轮注记 |

（谱系诚实登记：v2.0 曾于孤儿分支 r142 交付一次，随 web 保存回退丢失——r148 重建非首次交付；R4 审计链纪律 r145/r146 教训——行翻转与收口同窗。）

### 8.6 终局结论

**S 表达式 → 目标语言替换进程已抵达实绩终态（r154 / E6 收口）**：切换窗全闭（r106-r120）+ 域外清偿廿七窗（r121-r147）+ S-expr 完全拆除窗全闭（r149-r154——Batch A/B/C/D/E6 五批六轮）+ 皮肤字典 14 映射族 + 双面语料 parity 证据链归档。**§8.3 按设计保留面前两行已翻转拆除**（r154：七件种子 .krf 平行件 + Rust S-expr 经典面删除；target_reader.ktf → reader.ktf 单一收敛；仓库 .krf = 0 实证）——「系统中无 S 表达式痕迹」（07 §3.2.2 消失行）**实绩化达成**；唯「VM 永久 Rust 基座」宪制条款维持零触碰（A 类基座非 S-expr 面）。**零信号不开窗；定稿 ≠ 实施**（§2.2 原则 38/44-58——Stage 2+ 门控面维持登记态）。下一演进 = 触发式零信号维持或自然信号——按用户指令序或自然信号。

> **r154 终态注记**：§8.3 前两行（种子链七件 .krf + Rust S-expr Reader 经典面）自「按设计保留」翻转为「已拆除」——拆除判据 = 原则 41（自建替代 ≥98% + 额外能力 > 0——parity 门族四批证据链 + Reader fixpoint 里程碑 + fixpoint/两路门 + 删除守卫全绿）；拆除载体 = s-expr-removal-plan.md v1.5 §13 对账节。

---

*遵循条款：用户 r71/r147①/r148② 指令（缺口问询驱动源——r71 同型第 3 例）/ 136-a bootstrap-progress-review §5.1/§5.3（三分法判据 + B 类前瞻义务——本图为其识别兑现载体）/ 139-a surface-syntax-switch-assessment §5.2 步 6（替换面识别前置——本图为其完成件）/ 07 §3.2/§3.3（混合期构成 + Stage 2→3 信号——宿主/自举段划分与构建系统窗口权威）/ 12 §2.4.1（目标语法 Reader 蓝图 + 量化背书）+ §2.5.1 类型检查器行（HM 生产切换 K3 终态——r80 兑现）/ 23 §2.2 + §2.3 红线 1/3（触发表单源 + 禁止无信号开窗）/ 17 原则 31（皮肤/骨架同构保证）+ 原则 26（成熟度匹配）+ 原则 41（脚手架生命周期——r120 拆除判据实证引用）/ t3plus-trigger-audit §3/§4（TD-003/015 三判据 + 监测矩阵）/ §3.2（六命令全绿 + 1916:0:0——r148 恢复轮复验）/ §8.4.5（裁定附条款号）/ §8.4.6（产物位置——stage-3/ 治理文档族）/ §20.3（同类路径全量审查——R4 审计链债第三例）/ R4（文档以实况为准——v1.0-r71 滞留 76 轮当轮回写）。*

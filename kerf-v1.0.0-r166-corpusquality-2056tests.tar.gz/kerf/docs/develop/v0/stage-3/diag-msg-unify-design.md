# krf/hm 静态检查诊断消息文本统一窗（tc-sigs §7「消息文本统一」登记行清偿——族形 → op+got 形收敛）

> **Author**: kerf-dev-agent（Super Z main — ARCH-A 裁定 + DEV-A 实施 + QA-A 验收；r141 / 211-b 设计先行腿）
> **Date**: 2026-11-12
> **Version**: v1.0（首件）
> **Status**: Active（设计单源——本文件 §2 为本窗消息族映射的规范锚；check.krf 消息面收敛以本文件 D1-D8 为据）
> **处理程度**: P0（本窗交付 = check.krf 九族消息统一 + tc-type-str 渲染器 + op 名穿线 + 32 case 门 + 锚翻转锁步）
> **开窗依据**: 用户 r141 指令②「继续推进目标语言设计的实现窗[遇缺陷/未完成窗口则按推荐顺序直接推进进入对应窗口开始具体实施]」+ 指令③「按 docs/sop.md 流程结合 lang-design 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进」行权（**M1 指令开窗第四十六例**）；推荐序裁定 = r140 收口态登记册触发式实施项全清零 + T3+ 14 行零信号 + 门控任务七项全闭 + #15 需 next22.md 未上传 → 用户指令②「遇未完成窗口直接推进」逐行走查全部登记域外表（member-rename §7 余四行 / tc-sigs §7 五行 / vector §7 七行 / ffi §7 七行 / use-decl §7 余三行 / handle-multi-arm §7 余五行 / nested-resume D5-D7 / match §7 余三项）→ **唯一可行行 = 本文件标的 tc-sigs §7「krf/hm 消息文本统一」行**：触发判据明文含「**语料/用户信号**」（用户指令②行权臂——r74/r140 先例锚）+ 成熟度全在位（分歧由 tc-sigs D5 刻画 + 双侧构造点全实读 + r139 消息面标准轮同族先例[错误提示 = 目标语言诊断面 = 语言设计面正当窗口]）；其余各行全部不可行（TD-026 ②③④ interop/token 语料信号 / pub(scope)·is-procedure·值位 Callable·prelude pub(scope) = Stage 2+ / TD-005 残留架构位未在位 / TD-003/015 IrGraph 信号 / TD-008 DEFER / TD-024 Stage 3+ 评估 / read-line 运行时执法缺位先行 / extern 别名 = 设计成熟度未在位[无设计单源 + 无 oracle 对应物] / Vector HM 类型构造 = oracle 侧无 Vector 构造子[方向守卫前置阻塞] / 可变向量族·转换族·postfix 索引·match 模式位 = 语料信号零命中 / effect_pattern·裸臂·块体 halt/pass·resume 多参 = 语料信号零命中 / 多段路径·嵌套选择树 = 单层裁定恒态无触发 / 池化 = OBS-C 同族零信号 / EBNF Level 1-4 = 原则 54 免疫登记态）
> **上游单源**: [tc-sigs-parity-design.md §7 行 1](./tc-sigs-parity-design.md)（登记载体——本窗即其清偿载体）+ [hm.rs `Ty::render`/`check_param_rule`/`unify`/`infer_app` 消息九族](../../../crates/kerf-compiler/src/hm.rs)（oracle 行为规格 = 统一目标形单源）+ [check.krf 消息 22 位点](../../../crates/kerf-driver/src/bootstrap/check.krf)（krf 面实施点全集）+ r80 生产切换契约（krf ⊆ oracle 方向守卫——计数 parity 为守护面）+ r139 英语编码统一窗（消息层形态标准 = Rust 编译器惯例先例）+ [test.krf `int-to-string`](../../../crates/kerf-driver/src/bootstrap/test.krf)（数字转字串 bootstrap 先例）

## 1. 域内事实基线（双侧消息实况——本窗探针实证）

**九族分歧全录**（krf 面 = check.krf 生产判定面[r80 起]；oracle 面 = hm.rs Rust 参考实现[生产 fallback 窄面 + parity 测试消费面]）：

| # | 族 | krf 面现行（位点） | oracle 现行 | 分歧要素 |
|---|---|---|---|---|
| ① | requires 族（参数类型规则） | `argument requires int(static check)` 等 7 kind（check.krf:1012-1021 tc-rule-msg + :1034 pair-rule 位） | `{op} requires {want}, got {rt}(static check)`（hm.rs:1316-1326） | 无 op 名 + 无 got 型 |
| ② | num 全参族 | `arguments require numbers(static check)`（tc-rule-msg num 臂） | `{op} requires a number, got {rt}(static check)`（hm.rs:1199/1238） | 同① + 「a number」措辞 |
| ③ | head/tail 结构族 | `head requires pair(static check)`（check.krf:914/922） | `head requires pair, got {rt}(static check)`（hm.rs:1112/1138） | 无 got 型（op 名已在） |
| ④ | if 条件族 | `if condition requires bool(static check)`（check.krf:727） | `if condition requires bool, got {rt}(static check)`（hm.rs:697） | 无 got 型 |
| ⑤ | uncallable 族 | `uncallable value(static check)`（check.krf:710） | `uncallable value: {rt}(static check)`（hm.rs:963） | 无值型 |
| ⑥ | arity 族（五处） | `procedure argument count mismatch (static check)`（check.krf:334/343/677/845/880——unify arrow 位 / unify-params 位 / apply arrow 位 / builtin 变长位 / builtin 定形位） | `procedure argument count mismatch: expected {want}, got {n} (static check)`（hm.rs:974/1077/295——want = `{mn}..{mx}` 或 `≥{mn}`；注意空格：本族 `(static check)` 前有空格[oracle 原文如此]） | 无期望/实际计数 |
| ⑦ | unify 冲突族 | `type mismatch (static check)`（check.krf:338） | `type mismatch: {x} and {y}(static check)`（hm.rs:312） | 无双侧型渲染 |
| ⑧ | occurs 族 | `cannot construct an infinite type (static check)`（check.krf:321/326/707——unify 双臂 + 自应用早检位） | `cannot construct an infinite type: α{i} and {t}(static check)`（hm.rs:260/275） | 无变元号 + 无对侧型 |
| ⑨ | 兜底族 | `argument type mismatch (static check)`（tc-rule-msg else 臂——防御位零可达） | 无对应（oracle `check_param_rule` 全变体穷尽） | 防御位维持（零 oracle 对应——不属统一面） |

**三个先在事实**（开窗合法性 + 方向可行性锚）：
1. **r80 契约的守护面是诊断数非消息文本**（tc-sigs D5 明文：「计数 parity 为守护面为诊断数非消息文本；消息统一属独立评估面，登记域外」）——本窗 = 该登记行的独立评估面行权：文本统一零计数变更，契约守护面不动。
2. **fallback 路径已在产出 op+got 形**：effect 语料走 hm.rs 窄面 fallback 时用户已见 oracle 形消息——同一程序形态经不同路由产出两种文本 = 用户面不一致（本窗消除）。
3. **Unicode 字面量双面通过性已实证**：`(string-append "α" "≥3" "→")` ⇒ `α≥3→`（S-expr 面 E2E）——`α`(U+03B1)/`→`(U+2192)/`≥`(U+2265) 三字符入 check.krf 字面量无障碍（Reader 字节保持 + VM Str 域 UTF-8 + CLI 渲染回显全链实证）。

## 2. 九族统一映射表（D4——规范锚）

**统一方向 = krf 面逐族收敛到 oracle 形**（D1）；oracle 面（hm.rs）**零变更**。krf 面实施位点与新形：

| 族 | krf 新形（= oracle 形逐字节） | check.krf 位点改造 |
|---|---|---|
| ① | `{name} requires {want}, got {rt}(static check)`——want：`int`/`bool`/`str`/`symbol`/`list`/`pair` | tc-rule-msg → tc-rule-msg-str(rule, name, rt)；调用链穿线 name（D3） |
| ② | `{name} requires a number, got {rt}(static check)` | 同①（num 臂专用措辞） |
| ③ | `head requires pair, got {rt}(static check)` / `tail requires pair, got {rt}(static check)` | tc-head-result/tc-tail-result 两臂 |
| ④ | `if condition requires bool, got {rt}(static check)` | tc-if-cond-ok else 臂 |
| ⑤ | `uncallable value: {rt}(static check)` | tc-infer-app-general else 臂 |
| ⑥ | `procedure argument count mismatch: expected {want}, got {n} (static check)`——want：变长有上界 `{mn}..{mx}` / 变长无上界 `≥{mn}` / 定形 `{k}`（k = 参数表长） | 五位点各构造 want/n（D5） |
| ⑦ | `type mismatch: {x} and {y}(static check)`——x/y 经 tc-type-str 渲染（ra 在前 rb 在后——镜像 oracle unify(a,b) 实参序） | tc-unify else 臂 |
| ⑧ | `cannot construct an infinite type: α{i} and {t}(static check)`——i = tvar-id；t = 对侧型（unify 双臂 = rb/ra；自应用早检位 = `(tfun argtys (tc-fresh))` 整体型渲染——镜像 oracle drain 期约束 `α ~ Arrow(params,ret)` 的 occurs 报文） | tc-unify 两 occurs 臂 + 自应用位 |
| ⑨ | 防御位维持原文（零 oracle 对应——非统一面） | 无 |

**字节级注意**：族①-⑤⑦⑧ `(static check)` 前无空格；族⑥ `(static check)` 前有空格——逐字节镜像 oracle 原文（oracle 自身的族间空格不一致如实沿袭——统一目标 = 与 oracle 逐字节一致，非重排 oracle）。

## 3. D1：方向裁定（krf → oracle 形）

**裁定**：统一方向 = krf 面收敛到 oracle 的 op+got 形；**不采** oracle 降级到族形（反向）。

**论证**（ARCH-A 三依据）：
1. **§12 最优>最小 + 信息保全**：op+got 形携带三元组（哪个内建/期望什么/实际什么）——族形仅一元（期望什么）；降级 = 主动销毁诊断信息；升位 = 纯增益。r139 消息层形态标准 = Rust 编译器惯例（Rust 诊断恒携带操作位 + 期望 + 实际）——族形不合标准。
2. **oracle 零变更 = 零 Rust 面风险**：hm.rs 不动 → 种子侧零回归面；全部变更收敛于 check.krf 单文件（.krf 面）——与 r140「纯 .krf 面零桥变更零 Rust 变更」同型最优风险面。
3. **fallback 一致性收口**：r80 路由三态（Krf 主面 / 窄面 fallback→hm.rs / fail-closed）中前两态在统一后产出同族同形消息——用户面路由无感（现状：同程序形态因含 perform/handle 与否产出两种文本）。

**方向守卫不涉论证**（D6 前置）：krf ⊆ oracle 契约的守护面 = 诊断**计数**（r80 契约 + tc-sigs D5 明文）；本窗零计数变更（同一违规位点同一记录次数——文本替换不触记录语义）→ 方向守卫维持、无需重证。

## 4. D2：tc-type-str 渲染器（krf 面新增——镜像 `Ty::render`）

**新增** `tc-type-str`（check.krf）——镜像 hm.rs:107-124 `Ty::render` 全变体：

| krf 型 | 渲染 | oracle 对应 |
|---|---|---|
| `(tvar i)` | `α{i}`（int-to-string 沿袭 test.krf:80 digit-table 递归除余先例——tvar-id 与计数域恒非负） | `Var(i)` → `α{i}` |
| `(tcon k)` | kind 表：`int`/`float`/`num`/`bool`/`str`/`nil`/`symbol`/`dynamic`（krf 面 tcon kind 全集——本窗探针枚举实证 8 kind） | `Int`/`Float`/`Num`/`Bool`/`Str`/`Nil`/`Sym`/`Dynamic` |
| `(tpair a b)` | `({a} . {b})`（递归） | `Pair(a,b)` → `({} . {})` |
| `(tfun ps r)` | `({p1} {p2} … → {r})`（空参数表 → `(() → {r})`？——**裁定：空表渲染为 `()` 后接 ` → `**——镜像 oracle `ps.join(" ")` 空向量得空串 → `("" → r)` 即 `(() → r)` 与 `( → r)` 之辨：oracle `format!("({} → {})", ps.join(" "), …)` 空表得 `( → r)`[join 空串 + 单空格分隔]——krf 侧镜像构造：空表 → 恒 `""` 拼接 → `( → r)`。**krf 实现以 string-append 折叠空表为 `""` 后同序拼接——逐字节随 oracle**） | `Arrow` → `({} → {})` |
| 其余（防御） | `?`（零可达——krf 型域四构造子穷尽） | — |

**递归终止**：tc-type-str 先 tc-resolve 再分派（tvar 绑定解引用）；occurs 型自引用在消息构造前已由 occurs 检查拦截（渲染的型不含环——oracle 同律）。

**字符串构造原语**：string-append（check.krf 环境可用——test.krf 同环境先例）+ nth/mod（digit-table）+ `α`/`→`/`≥` 字面量（§1 事实 3 实证）。

## 5. D3：op 名穿线（调用链五级）

tc-infer-builtin **已有** namestr（check.krf:828）；穿线路径：

```
tc-infer-builtin (namestr ✓)
  ├─ 'sigf 臂 → tc-infer-builtin-fixed(sig, namestr, …)        [签名 +1 参]
  │              └─ tc-check-pos-rules(params, namestr, …)      [签名 +1 参]
  │                     └─ tc-rule-one(rule, name, ty, argnode) [签名 +1 参]
  └─ 'sig 臂 → tc-check-rule(rule, namestr, …)                  [签名 +1 参]
                 ├─ tc-rule-all(rule, name, …)                  [签名 +1 参]
                 │      └─ tc-rule-one（同上汇合）
                 └─ tc-rule-pair-list(namestr, …)               [签名 +1 参——族① pair-rule 位]
tc-rule-msg(rule) → tc-rule-msg-str(rule, name, rt)             [签名 +2 参 + 新构造]
```

**不采全局暂存态**（TC-OPNAME 动态全局——r135 TC-RENAME 先例虽在）：显式参数穿线更合本文件零全局新增原则（TC-RENAME 是跨入口协议数据非局部穿线 convenience——两者义务性质不同）；穿线面 = 7 函数签名各 +1 参，全为内部函数（零入口协议变更——`lchk-check-program` 入口签名不动）。

## 6. D5：arity want 形（五位点的期望/实际计数）

| 位点 | want 构造 | got |
|---|---|---|
| check.krf:845（'sig 变长位） | mx=999999 → `≥{mn}`；否则 `{mn}..{mx}` | `(length argnodes)` |
| check.krf:880（'sigf 定形位） | `(length params)` → `{k}` | `(length argnodes)` |
| check.krf:677（apply arrow 位） | `(length (tfun-params rf))` → `{k}` | `(length argtys)` |
| check.krf:334（unify arrow 位） | `(length (tfun-params ra))` → `{k}` | `(length (tfun-params rb))` |
| check.krf:343（unify-params 位） | `(length ps)` → `{k}` | `(length qs)` |

（oracle hm.rs:1074-1075 want 构造逐形镜像：`Some(m) => "{mn}..{m}"` / `None => "≥{mn}"`；`≥` 字面量入 check.krf——§1 事实 3。）

## 7. D6：计数 parity 维持论证（GATE 前置）

- **零计数变更**：九族统一全部为「同位点同记录次数下的文本替换」——tc-record/tc-fail/tc-failv 的调用条件与次数零变化（实施自查项：diff 后逐位点核对记录条件布尔式不动）。
- **krf ⊆ oracle 方向守卫不涉**：守护面 = 拒绝集合（哪些程序被判 E0005）——本窗零判据变更 → 拒绝集合恒等 → 方向守卫维持（r80 契约原文面）。
- **fallback 面**：hm.rs 零变更 → 窄面 fallback 产出恒等 → 三态路由计数 parity 维持。
- **验收锚**：r80 既有 parity 语料（hm_production_switch 等锚三件族）+ r140 ktf_tc_sigs_parity 双面计数锚——全量维持绿 = 守护面不动的实证（GATE 1 消费）。

## 8. D7：锚翻转预算（锁步面全集）

**短针存活族**（零翻转——统一后消息仍含原 needle 子串）：`argument count mismatch`（39 处）/ `infinite type`（11 处）/ `uncallable value`（12 处）/ `condition requires bool`（17 处）/ `type mismatch`（审计 4 处）——统一形逐族含上述子串（族⑥ `procedure argument count mismatch: expected…` 含 `argument count mismatch` ✓；族⑧ `cannot construct an infinite type: α…` 含 `infinite type` ✓；族⑤ `uncallable value: int…` 含 `uncallable value` ✓；族④ `if condition requires bool, got…` 含 `condition requires bool` ✓；族⑦ `type mismatch: {x} and…` 含 `type mismatch` ✓）。

**翻转族**（44 处——统一形不含原 needle）：
- 测试面 41 处：`argument requires {kind}`（29：stdlib_tests 4 + typecheck_tests 3 + ktf_member_rename_tests 4 + ktf_tc_sigs_parity_tests 18）→ needle 收短为 `requires {kind}`；`arguments require numbers`（12：typecheck_tests）→ `requires a number`。
- 审计面 3 处：stage3_gate_audit_m3.rs:349 + stage2_gate_audit_r2.rs:394 `arguments require numbers` → `requires a number`；stage2_gate_audit_r2.rs:334 `argument requires bool` → `requires bool`。
- 翻转纪律：needle 收短不改断言语义（单违规程序 + 族唯一性——「requires {kind}」在统一形中仍唯一定位该诊断）；新门（D8）以**全文本锚**补偿精度（`{op} requires {want}, got {rt}(static check)` 整串）。

## 9. D8：测试矩阵（32 case 新门——ktf_diag_msg_parity_tests）

**新文件** `tests/v0/stage3/plan/ktf_diag_msg_parity_tests.rs` + runner.rs 挂载；8 正 + 24 负 = 1:3（§9.4.3）：

- **正向 8**（p01-p08）：九族代表位全诊断零程序——num 全参族净（`(+ 1 2 3)` 变长合法）/ str 族净（string-append 2 参）/ int 族净（nth 合法索引）/ pair 族净（last-pair 合法对）/ bool 条件净（if num 条件）/ 变长 arity 净（`(- 5 2 1)`）/ **跨阶段消费**（vector 语料 check 零诊断——r138 语料经统一面复核）/ 双面同净（seed + target 同程序双面零诊断）。
- **负向 24**（n01-n24）：①族双面全文本锚 ×8（nth got str / string-append got num[族② a number 措辞锚] / last-pair got num / member got num / string-substring 定形位 / reverse got num[族① list] / symbol 位 / 双面同程序同文本[seed+target parity]）；③head/tail got 锚 ×2；④if 条件 got 锚 ×2；⑤uncallable 值型锚 ×2；⑥arity 三形锚 ×3（变长无上界 `≥{mn}` 形 / 变长有上界 `{mn}..{mx}` 形 / 定形 `{k}` 形）；⑦unify 冲突双侧型锚 ×2（具体-具体冲突 `type mismatch: str and bool` 形[序 = 期望型在前]）；⑧occurs 形锚 ×2（自应用——`α` + `→` 形锚[变元号面独立不锚]）；多违反收集 ×1（同程序两族两诊断各自全文本锚——恢复模式双发）。
- **验收数字**：净 +32 → **1788:0:0 新基线**；短针存活族 + 翻转族全绿 = 锁步面闭环。

## 10. 实施对账（七件——211-c 执行面）

1. check.krf：tc-type-str + tc-types-str（参数表折叠）+ int-to-string（本地 digit-table——不 import test.krf，独立定义零耦合）+ tc-rule-msg-str + 九族 22 位点文本构造 + 穿线 7 函数签名。
2. tests/v0/stage3/plan/ktf_diag_msg_parity_tests.rs：32 case + runner.rs 挂载。
3. 锚翻转：4 测试文件 41 处 + 2 审计文件 3 处。
4. CLI 面：零变更（消息经 CheckReport.diagnostics.message 透传——桥零触碰）。
5. 治理腿（211-e）：tc-sigs §7 行 1 翻转 + t3plus v1.61 + guide v1.26 + RELEASE r141 + matrix + README + rec + worklog 三链。
6. 自查：diff 后逐位点核对记录条件零变更（D6）。
7. GATE 1（211-d）：六命令 + 审计×6 + CLI 双语法面零回归 + bench 带内。

## §7. 诚实边界（域外登记表——本窗不做）

| 域外项 | 载体 | 触发判据 |
|---|---|---|
| 变元号跨面一致（krf α{i} 与 oracle α{j} 同程序同变元不同号——计数 parity 为守护面不涉文本） | 本文件 D4 注 | 永久域外（双面 fresh 计数器独立——结构性非缺位；守护面 = 诊断数） |
| 兜底族（tc-rule-msg else 臂防御位）oracle 对应物 | 本文件 §2 族⑨ | 防御位零可达维持（oracle 穷尽无兜底——非统一面） |
| oracle 消息族间空格不一致（族⑥ `(static check)` 前空格 vs 族①-⑤⑦⑧无空格）的重排 | hm.rs 原文 | 逐字节镜像纪律本窗不重排 oracle；重排 = oracle 面独立评估窗（语料/用户信号——用户面报文排版需求） |
| E0005 码位/`-->` 位标/expansion 注记的消息周边统一 | driver.rs 渲染面 | 渲染层非消息层（本窗 = 消息文本面；周边排版零触碰） |

*遵循条款：原则 12（最优>最小——op+got 三元组信息保全方向）/ 原则 26（成熟度匹配——双侧构造点全实读 + r139 同族先例）/ 原则 27（加性——oracle 零变更 + 入口协议零变更）/ 原则 31（皮肤/骨架同构——krf 面逐字节镜像 oracle 形）/ §9.4.3（1:3）/ §13.1（设计先行腿）*

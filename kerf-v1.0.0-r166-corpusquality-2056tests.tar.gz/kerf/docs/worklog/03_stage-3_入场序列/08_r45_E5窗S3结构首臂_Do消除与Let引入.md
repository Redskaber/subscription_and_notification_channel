# r45 E5 S3 结构臂首臂：Do 消除 + Let 引入（Task 66-a/66-b/66-z/66-web）

> 一行：深审 D41-D45（Let 入 Core 层 E1 Stage 3 重评 GO + do→Let 链脱糖 + let 系糖修正 + 名面换位 + 分臂排期）+ 全链实施（13 文件 + 桥双侧 + 自举语料 + VM 帧扩展五点）——835:0:0 净 +1 + 五审计集 233 + 非正交点 3→2。

## 交付零（深审轮——22 §14 D41-D45）
- **D41 Let 入 Core 层**（E1 DEFER-TO-STAGE3 的 Stage 3 重评）：①Op::StoreLocal 既有零 VM 指令变更 ②discard/bind 双模式编译规则 ③五面同词根（let ∈ Keyword）④M-A 不可归约判据精确化——编译期显式局部绑定锚点（Fn+Apply 组合语义等价但结构匿名；ANF 正典）⑤IrNode::Let 图 IR 映照
- **D42 Do 消除 + do→Let 链**：恒定名 "do"（E0020 保留字名不可引用）+ 空集作用域 + 空/单元素退化形态；**字节码 parity 最严口径**——discard 模式逐指令全等（黄金快照 const_pool_dedup 维持）；D30 先例域内形态分离（M-D 脱糖归约非名面漂移——D34 精确化正确适用）
- **D43 修正版**：let/letrec 维持 App[Fn] 组合推导（**平行语义零风险**——嵌套直映破坏 let 平行性；letrec 字节码零漂移）+ hm D4 链识别重写 + **let 直映归 r46**（多绑定暂存法——名实暂分离 D30 受控域登记）
- **D44**：kind_name 12 名表 -do +let；s3mr 9 原语级集合换位；桥 tag 'do→'let（4 字段对称）
- **D45 分臂排期**：r45 ✅ / r46 Define+Module+let 直映 / r47 de Bruijn / S4 收口——非正交点 3→2→1

## 交付一（全链实施）
- CoreExpr::Let 引入 / Do 删除（expr/ir/code_value）+ compile（discard/bind 双判据 + n_locals 回填）+ eval（子 env 词法绑定）+ typecheck（save/restore 装订）+ hm（HM let 规则 + D4 链识别重写）+ anf（值/尾双臂）+ driver/capability ×10 遍历臂 + **VM 帧分配 n_locals 扩展五点**（main×2/Call/TailCall/B thunk/H 变形）
- 桥双侧 4 字段对称 + expander.krf make-do-let-chain + compiler.krf let 臂双模式 + 辅助族（expr-references?/cc-locals-push!/proto-bump-nlocals!）
- **§3.2 六命令**：clean 747/254.4MiB → build 14.45s 零告警 → check 0 → fmt 0 → clippy -D warnings 0 → **test 835:0:0**（615+220；834 基线 + 1 净增）+ 五审计集 EXIT 0 ×5（233）+ CLI 全路径（fib 144/macros 42/check ok/**let bind 25 新端到端**/do 3/letrec true/while 10/E0021 REAL_EXIT 1）
- **开发实录三则**：①桥 4 字段对称（初版 3 字段当场发现）②'literal x 位遗漏修正 ③GC 压力形态迁移（4000 项 do 平铺 → 顶层平铺[语义等价]；深嵌套栈深 = r44 hm 既有基线注记）

## 交付二（打包 + web）
- r45 tar.gz：kerf-stage3-v0.12.0-r45-e5s3do-let-835tests.tar.gz（**359 条目 / 2.34 MB** + 包内自举 14.57s + 835 复跑 + 审计 ×5 + CLI + qbe 在包）
- web 面同步（footer v7.15 + 状态行 r45 + download README r45 节 + 原语映射表 Do 消除/Let 引入行）

## 里程碑
- **E5 S3 结构臂首臂闭环**——「1970 序形式」结构清算（Do 消除；非正交点 3→2）；字节码 parity 最严口径首证（do 形式逐指令全等 + letrec 零漂移）；下一步 **E5 S3 结构续臂 r46**（Define 上移[ModuleItem] + Module 迁移[M-L] + let 直映[多绑定暂存法]——非正交点 2→1）→ r47 de Bruijn（M-I IR 层）→ S4 收口（≤1 + 门审 ≥30 case + E5 出口三条件）

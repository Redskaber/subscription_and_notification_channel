# 16 · r52 Stage 3 收口窗——性能基线 + D1-D8 深审 + final-assessment（74-a/74-b/74-z/74-web）

> 覆盖：2026-09-21 · Task 74-x · 记忆类：e+s+p · 状态：active

## 载荷

**驱动源**：用户指令「按照 sop.md 流程结合 docs/lang-design/ 下的项目演进流程，继续推进任务」+「同步完整打包项目 tar.gz 并同步完整更新 web page」+ roadmap v1.0.0-r51 头指针「下一步 = Stage 3 收口窗[§21 规划——性能基线 + 深审 + 门审]」。

**开窗核对（§21.5 九信号）**：①语义稳定 ✅ ②自举验证 ✅ ③测试覆盖 ✅ ④**性能基线 ❌ 唯一缺口**（12 §2.10 Week 4「基线数据入库」未系统化兑付）⑤-⑨ 全 ✅——收口窗载荷 = 信号④兑付 + K2 同构深审环。

**性能基线（performance-baseline.md v1.0——五维度 13 程序实测冻结）**：
- 执行速度 6：fib 25 = 91.534ms（≈2.65M 调用/s）+ effect_stress 85.807ms（效应恢复无异常放大）+ gc 尾形 41.593ms（≈7.2M 分配/s）/非尾形 90.851ms + higher_order/closures/macros/io 亚毫秒
- 编译速度 4：自举四件全链 < 1ms（compiler 0.270ms ≈ 16.3M 指令/s 发射——80 原型/4405 指令；expander 0.476/reader 0.142/preamble 0.048）
- HM 类型检查 3：fib 27ms / compiler 1230ms / expander 3734ms（**口径分化实录：bench = 编译+顶层执行 vs check = HM 检查管线——两口径分离把编译发射与类型检查拆为独立维度；HM 为最重维度诚实落档，run 路径零开销维持[原则 18]；T3+ 优化候选：occurs check union-find + 泛化 memo**）
- GC 压力 2 形态 + 自举一致性 1（门 B fixpoint SHA 一致）
- TD-028 漂移对照：fib r24 84.2 → r36 92.5 → r52 91.534ms（-1.1% vs r36——收敛噪声带上沿，维持登记不升级）
- 载体 = CLI 既有 bench/check 子命令（**零本体变更**——纯测量落档；重跑规程入档 §5——只追加不覆盖）

**深审 D1-D8 Stage 3 版（deep-review-stage3-close.md）**：D1 架构（10 crates 接口隔离抽查维持——compiler→reader = 0 实测 + vm→compiler = 数据类型 only 正当 + E5 三结构臂层内演进零跨层）+ D2 TD 30 项 P0/P1 = 0（开放 5 全有 T3+ 触发窗口）+ D3 测试 877 + 280 审计 + D4 T3+ 触发式族就绪 + D5 设计 35 原则全数在位 + D6 性能零 O(n²) 新增 + D7 文档零隐性 + D8 流程 R6/R7 收敛——**零新增 P0/P1/P2/P3**；五角色投票 **5.5/5.5 = 100% GO** + **final-assessment：Stage 3 收口 GO——进入 Stage 3+ 触发式演进（T3+ 族——23 §2.2 触发表单源驱动，禁止无信号开窗）**。

**验证**：§3.2 六命令 clean 起步全绿（build 14.26s 零告警 / check 0 / fmt 0[一处 rustfmt 边界修正——e5close P03 行单行化] / clippy -D warnings 0 / **877:0:0 零回归**——集成 645 + 单元 232）+ 六审计集 280 case EXIT 0 ×6 复验 + CLI 全路径（native QBE PoC fib 12 → 144 维持 + E0021 负例）。

**打包**：kerf-v1.0.0-r52-s3close-perfbaseline-877tests.tar.gz（296 条目/2.70MB）+ 包内自举三验（build 14.27s + 877 逐位复现 + 审计 ×6 + bench 91.589ms 基线一致 + qbe 在包）。

**§14.8 回写**：performance-baseline.md + deep-review-stage3-close.md 双新建 + matrix r52 行 + RELEASE r52 节 + roadmap v1.0.0-r52 + Status 收口终态（待触发态）。

## 下一步

Stage 3+ 触发式演进待触发态——T3+ 族窗口由 23 §2.2 触发表单源驱动（net 四依据 / TD-003/005/015/028 优化窗口 profile 先行 / TD-024/026 FFI 语言面 / LLVM 发布后端），禁止无信号开窗。

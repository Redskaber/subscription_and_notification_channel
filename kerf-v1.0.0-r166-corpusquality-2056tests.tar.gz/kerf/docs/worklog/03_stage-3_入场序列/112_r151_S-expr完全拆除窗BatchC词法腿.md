# r151 S-expr 完全拆除窗 Batch C 词法腿（target_reader.krf → target_reader.ktf 词法段——Reader fixpoint 里程碑第一腿）

> **Task ID**: 221-main（221-a..221-f 全链）
> **Agent**: Super Z (main) — PM-A/ARCH-A/DEV-A/QA-A/REC-A 复合（M1 指令开窗第五十六例——用户指令①「遇缺陷或未完成窗口按推荐顺序直接推进进入对应窗口」臂命中 r149 已开窗的拆除窗 Batch C 词法腿）

## A. 路由与开窗（221-a）

- PHASE 1 路由：worklog 末三条核读（220-close/220-main/219-main——r150 Batch B 闭环 + 1980 基线 + 下一演进 = Batch C）；磁盘实况零冲突（git HEAD 23f6bfd 干净 + 1980:0:0 逐位复验 + r150 包在位 + t3plus v1.70 三源一致「下一演进 = Batch C」）；L3 常规轮路由（非末轮深审族不触发）。
- 环境恢复：PATH 第九次自助（cargo 1.98.1——§3.1 r126/r129/r200-a 同型）。
- 开窗判据：用户指令①臂命中 r149 已开窗的拆除窗；s-expr-removal-plan §4 Batch C 排期 r151-r152 两轮分批{词法段 + 语法段——r107/r108 先例镜像}；ARCH-A 中途态桥设计裁定（双状态隔离——词法入口先行切换 + 语法入口维持 .krf 全件）。
- 可行性审计七面（六面基础 + 转义集同构附加面）：下划线/准引用/真实效应/bang 代码面全零 + 核心形式覆盖（cond 20/if 20/let 16/define 62/and 31/or 14/not 14 + 无 lambda 形——比 Batch A/B 更简面）+ 无 'nil quote 位 + 无关键字符号 quote 位 + 装载路径就绪 + **字符串转义集 7 形同构**{Rust target Reader 转义臂逐字核对}。

## B. 实施（221-b）

- **target_reader.ktf 词法段全量转写**（1-643 行）：皮肤字典机械映射{cond→if-else 右递归链 + 多绑定 let→逗号并列单语句 + define→fn + 'sym→quote(sym) + 裸 nil→() 值位{build.ktf:95-107 先例} + and/or/not→&&/||/! + 高阶函数值传递{lex_scan_with(scan_number,...)——compiler.ktf:1430 map(proto_finish) 先例} + kebab↔snake}。
- **转换纪律第三新锚——负整数字面量位双侧同形化**：S-expr 面 -1 读期字面量化{PushConst(Int(-1))} vs 目标面 -1 解析期一元负{(- 1) 全局调用——parse_unary Minus 臂；目标面无负数字面量语法}——形态分歧根因；三侧同形化{target_reader.krf 全件 list-pos 的 -1 → (- 1) + 提取件同步 + .ktf 侧 -1}——r150 TAG 规范化先例镜像{双侧同形 → 字节码全等}。
- **三项既有纪律精确化复用**：①n 元 and 右嵌套{平铺三元/四元/六元 and 共 7 位点 → 右嵌套——S-expr and 宏右递归展开同构{(_ a b ...) => (if a (and b ...) false)——expander derived.rs 语义单源核对}}；②多绑定 let 逗号并列{平铺多绑定 ↔ let a = e1, b = e2; 单语句；嵌套单绑定 ↔ 顺序语句}；③eq/= 映射分工{(eq a b) 通用相等 → eq(a,b) 函数调用形；(= a b) 数值 → == 运算符}。
- **target_reader_lex.krf 新立**：1-643 行提取 + 一处规范化位点声明——门 C 词法腿 parity oracle；E6 收口批删除。
- **桥双状态改造**（target_reader.rs）：TARGET_READER_LEX thread_local 新状态{include_str! target_reader.ktf + compile_front_seed_target 装载——Reader fixpoint 里程碑第一腿} + load_reader_program 共享装载脊柱{face 参数分派 compile_front_seed/compile_front_seed_target——expand/compile 维持种子 Rust P1 硬约定} + lex_target_for_bootstrap 切换至新状态 + read_target_source_for_bootstrap 维持 .krf 全件{r152 收敛}。

## C. 门 C 词法腿 + GATE 1（221-c）

- **门 C 词法腿**：seed_ktf_parity_tests 64 → 96 case{8 正 + 24 负 1:3——载荷字节码 parity{提取 oracle ↔ 转写件：指令序/常量池[解析]/proto 形状/全局引用面[解析]全等} + 入口面{global_refs 承载 lex-target} + 内建消费面{十内建} + 字符集常数面{DIGITS/ALPHA/HEX-DIGITS/OCT/BIN/TKEYWORDS/CAP10/16/8/2 十表} + 命名映射回环{入口 + 11 内部名 + 恒等面} + 生产活性{dump_tokens_target CLI 桥} + 双跑确定性{radix 值文本 int:255 + 注释跳过} + Token 快照锚{首五尾三硬编码} + 负向 24 族{词法 12 + 文法 5 + 深度帽 2{块族 300 层嵌套 if 经 Rust 种子 read_target_source 直击 + S-expr datum 帽双侧 parity} + 关键字操作数位 1 + 多字节 Span 1}}。
- **门 Y 零变更**：target_reader_krf_tests 32 case 全绿{词法 16 族断言面自动升级为 .ktf 路径 ↔ Rust 种子——行为零漂移证据；语法 16 族维持 .krf 路径}。
- **GATE 1**：六命令 clean 起步全绿{build 22.64s 零告警 + check 0:0 + fmt 零 diff{一处顺修} + clippy -D warnings 0{一处 doc_lazy_continuation 顺修——Batch B 注释行} + test 2012:0:0 净 +32[RUST_MIN_STACK=33554432]} + 审计族全绿{architecture 6 + gate_review 8 + e5 1 + m3 17 + switch 60——含于 2012 全量} + CLI 双语法面零回归{fib ⇒75025/144 双面 + check ok 2/9/5/38 + effect_multiarm ⇒217 双面 + nested_resume ⇒540 双面 + closures ⇒42 + test 2/2 + tokens .ktf 桥生产面} + bench 71.909/72.358/72.338ms 带内{OBS-C 零信号维持}。

## D. 内循环修正实录（3 轮）

1. **eq 映射错误**（首跑 16 败）：S-expr (eq a b) 误映射为 == 运算符{== 对字符串报 requires a number——TD-016 口径}；修正 = eq(a,b) 函数调用形{build.ktf:95 先例对照}。
2. **三纪律增量**：-1 规范化{n 元 and 右嵌套 ×7 + 多绑定 let 逗号并列 ×2——字节码 parity proto 19/28/50 逐级定位清偿}。
3. **测试程序字面括号笔误**（深度负例——字符串字面量 {{ 非转义生成嵌套裸块）+ 快照锚校准{ident:f 格式 + 尾三 Token 序}。

## E. 治理与收口（221-d/221-e/221-f）

- 治理九件：matrix r151 增量行 + 总量行 2012 + RELEASE r151 节 + README 两处 + t3plus v1.71{14 行零变化} + s-expr-removal-plan v1.2{§4 词法腿 ✅ + §9 对账节} + 替换面图 §8.3 注记 + rec 112 + 根层 l + worklog 三链。
- 8 原语不变性第三十三轮{纯皮肤/载荷形态切换——零机制变更零新原语零通道}。
- 下一演进 = Batch C 语法段{target_reader.ktf 扩展 675-2979 行 + 桥语法入口切换 + .krf 全件退役 oracle + fixpoint 门——Reader fixpoint 里程碑收口——r152}。

**遵循条款**：§1.2（L3 路由）/ §3.1（PATH 第九次自助）/ §3.2（六命令）/ §5.3（八项）/ §12（最优>最小——三侧同形化方案论证）/ 原则 6/9/26/31/41/43/58 / §2.3 红线 3/4 / §8.4.5/§8.4.6/§8.6 / §9.4.3 / §19 / §20.3/§20.6。

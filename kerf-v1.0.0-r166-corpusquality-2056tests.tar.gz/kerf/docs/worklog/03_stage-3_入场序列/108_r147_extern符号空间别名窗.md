# r147 —— extern 符号空间别名窗（声明位别名臂）

> Task ID: 217-a..217-f　Agent: Super Z (main) — PM-A/ARCH-A/DEV-A/QA-A/REC-A 复合
> Date: 2026-11-16　基线: 1884 → **1916（净 +32——1916 基线自 r147 起）**

## 用户四链指令

〇审查当前项目演进进度和位置，检查完全将 S 表达式替换为目标语言序列剩余的任务区域和范围 + ①继续推进 目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施 + ②按照 docs/sop.md 流程结合 docs/lang-design/ 下的项目演进流程（整体任务视角）与 docs/develop/v0/tech-debt-register.md、docs/develop/v0/stage-3/t3plus-trigger-audit.md 等（局部任务视角），按照推荐先后任务顺序继续推进 + ③同步完整打包项目 tar.gz 并同步完整更新 web page

## 审计腿结论（指令〇）

S-expr→目标语言替换剩余范围（r146 态全量走查）：
1. **宪制保留面**（BS-A 混合自举裁定）：种子链七件 .krf 组件（build/cache/check/cli/target_reader/test/test_runner）+ 用户 S-expr 面——不在替换范围
2. **已完成面**：切换窗五步+E5（r106-r120 全闭）+ 门控任务七项全闭 + 前端自举链四件 .ktf（r109-r116）+ CLI 双入口（r125）+ parity 五连（r125/r130/r131/r132/r143）+ TC-SIGS 对齐（r140）+ 消息统一（r141）+ member 模型（r142）+ read-line（r144）
3. **触发式维持面**（语料信号臂）：vector 族 7 行 / handle 族 5 行 / ffi 族 7 行（本轮清偿 1 行）
4. **Stage 2+ 门控面**：类型/效应/能力声明族 / is-procedure 函数值一等 / pub(scope) 权限矩阵族
5. **恒态**：单层裁定族（多段路径/嵌套选择树）

## 开窗判定（M1 第五十二例）

- 推荐序走查：六族语料信号实测全零 + T3+ 14 行零信号 + 登记册触发式实施项维持全清零 + #15 需 next23.md（未上传）→ 逐行走查全部登记域外表（11 份设计单源 §7 + 切换窗 §4 + 登记册）→ **唯一含「用户指令」触发臂的开放行 = ffi-language-surface §7 末行「extern 别名/重导出（use 选择形接驳）」**{触发判据明文「用户指令或语料信号」}
- r143 收口 P5/P6 探针已实证符号空间机制缺口（E0019/E0022）；本轮 217-a 五探针复核逐位吻合：P1 双面 ⇒9 基线 / P2 E0001 声明位 as 形 / P3 E0026 模块体位 / P4 E0019 虚拟模块 / P5 E0026 六元素形
- 成熟度匹配：r130 import-as 别名臂 + r134 member-rename 三元组 + r137 extern 五重校验三先例底座全在位

## 交付

- **设计单源** extern-alias-design.md v1.0{D1-D10 + §7 域外表八行}
- **双侧 Reader 别名臂**：种子 target.rs parse_extern_decl KwAs 前置臂（r130 asp 措辞先例）+ 镜像 target_reader.krf extern-alias-name 新函数 + alias-rec 双 Token 穿线（extern-kind/kind-sep/arrow/semi 六函数链）
- **驱动面**：collect_extern_face 六元素臂（4/6 元素形）+ ExternEntryDecl.local 字段（恒等缺省——原则 27）+ D5 自别名拒收 + D6 反遮蔽扩展 + externs_for_compile 分离映射 (intern(local), Rc(name)) + verify_unbound_refs defined.insert(local)
- **bootstrap 编译桥 CC_EXTERN 协议扩展**（同窗实施发现——r137 恒等映射隐性假设被别名打破）：compiler.rs 桥改传 (local flat) 对 + compiler.ktf rv_loop extern_lookup 新函数（is_contains → 对查找 + EXTERN_TAG 载荷 = flat）+ compile_call SymLit 载 second（Rust 侧 IrVar::Extern(flat) 镜像——原则 31）
- **32 case 门** ktf_extern_alias_tests{8 正 + 24 负 1:3} + **语料对** ffi_alias.{ktf,krf} ⇒ 9 双面{语料族 15 对}
- **GATE 1**：六命令 clean 起步全绿{build 21.12s + check 0:0 + fmt 顺修一处后零 diff + clippy 0 + **test 1916:0:0 净 +32**} + 审计×6 EXIT 0{280 case} + CLI 双语法面零回归{含 ffi_alias ⇒9 双面新路径 + check ffi_alias 1/2/0/5——全局引用 0 = D3 分辨面实证} + bench 带内
- **治理**：ffi-language-surface-design v1.1 §7 末行翻转 + handle-expr-position-design v1.1 §7 末行翻转{R4 审计链纪律——r145/r146 教训：行翻转与收口同窗} + 02 v7.24 + 20 v1.31 + examples README + matrix 1916 + RELEASE r147 + README 三处 + t3plus v1.67 + guide v1.32{行权态三十二次} + rec 108 + worklog 三链

## 关键裁定

1. **双名分离 D3**：underlying = 扁平 FFI 空间名{注册 E0012/契约 E0026/能力 E0006/运行表四面恒按 underlying 匹配——零变更}；local = 源级绑定名；IR extern_face (Symbol, Rc<str>) 对既有分离维度启用——IR/编译器/VM 零机制变更（原则 9）
2. **替换语义 D4**：local 替换 underlying 入可见面——underlying 直写 = E0022（r130 import-as 声明位家族线 + r134 D8 反向锚同构；r135 prelude 双绑形判别注记）
3. **自别名拒收 D5 / 反遮蔽扩展 D6 / 能力门不感知别名 D7 / HM A4 维持 D8**
4. **use 选择形接驳维持域外 D9**：扁平 FFI 空间无模块面（ffi-ownership-model §4 宪制）；虚拟模块面 = Stage 2+ 命名空间演进触发
5. **8 原语不变性第二十九轮**：零新原语零通道零新操作码零 CoreExpr/IR 变体——纯 Reader/驱动面/桥协议窗口

## 下一演进

触发式零信号维持或自然信号——按用户指令序或自然信号{§7 域外表全行为触发式或 Stage 2+}

# rec 85 —— r123 match 实施批 M-3：穷尽性诊断（E0025 保守规则双面落地 · §4.1 五条实施裁定）

**Task ID**：193-a..193-d　**日期**：2026-11-03　**角色**：Super Z (main)——ARCH-A（裁定）+ IMPL-A（实施）+ QA-A（验收）+ REC-A（对账）

**驱动**：用户三链指令（①继续推进目标语言设计实现窗[遇缺陷按推荐顺序直接推进] ②按 sop.md 流程 + lang-design 演进流程 + tech-debt-register + t3plus-trigger-audit 推荐序推进 ③完整打包 tar.gz + 完整更新 web page）——M1 指令开窗第二十八例；r122 收口笔推荐序首位兑现（match 实施批 M-3 = match-design v1.2 §6 批路径 M-2 后推荐序首位；三源一致：match-design v1.2 Status / t3plus v1.42 下一演进 / 192-d 收口笔）。

**交付**：

1. **193-a 实施**——match §4 穷尽性保守规则三条实施化（match-design.md v1.2 §4 + **v1.3 §4.1 五条实施裁定入档**）：
   - **种子侧** `kerf-expander/src/match_desugar.rs` E0025 穷尽性门：check_exhaustive + pattern_is_total + scan_top_bools + or_marker_items 四函数——穷尽 ⇔ 无守卫全匹配臂{通配/裸绑定/or 含全匹配备选——折叠面 test=None 类轻量重推导} ∨ bool 闭域 {true,false} 双覆盖{顶层收集 + or 展平——`(or true false)` 单臂 = 双覆盖}；否则 E0025 fail-closed（消息携建议补 `_ =>` 终臂或 true/false 闭域双臂 + int/float/str/() 开放域不判定 + match-design §4 引用；Span 指向 match 形式）。
   - **自举侧镜像** `bootstrap/expander.ktf` match_exhaustive 族七函数（match_pat_total/match_alts_total/match_pat_has_bool/match_alts_have_bool/match_arms_total/match_arms_have_bool/match_exhaustive + expand_match 门插入——TRUE_TAG/FALSE_TAG 标签比较；折叠成功后触发[结构诊断优先序双侧镜像]；构造性同构——消息面字节级等价测试钉住）。
   - **五条 M-3 裁定入档**（v1.3 §4.1）：①无守卫严化——带守卫通配/绑定/字面量臂零贡献{守卫可否决——计入违反「兜底理论不可达」声明；设计字面「无 `_` 或裸绑定臂」精确化} ②顶层收集 + or 展平——嵌套序对位字面量不计{is-pair 恒非全匹配} ③模式结构豁免 + 诚实边界——bool 豁免不依赖审查值类型{展开期无类型 + eq : any→any→bool——HM 不拦}；运行时兜底**残余可达类 = 豁免面 × 非 bool 审查值**{原则 42 双层实例；「理论不可能」精确化：结构诊断形不可达、豁免类设计内放行} ④门后置折叠——结构诊断保持 surfacing 优先序{M-2 负例族消息序契约零扰动} ⑤纯诊断批——脱糖产物与 M-2 字节级全同{均匀链 + 兜底节点保持——零死码消除；消除归 Stage 2+ 优化器域}。
   - **诊断码 E0025 指配**（E0001-E0024 后次号；与 E0002 族同通道渲染——展开期错误 → Stage::Expand + kerf-span 源映射，零新通道——原则 42 编译期诊断正交维持）。
   - **M-2 四测试协同收窄**：①match_m2_pattern_family_parity + ②nested_pair_parity + ③dual_path 双语料——补 `_ => 9`/`_ => 0` 通配终臂 + 手写等价形同步{均匀链兜底节点保持——parity 三向全等} ④non_exhaustive_runtime_fallback——语料改残余可达类{`(match 5 (true 1) (false 0))` + str 审查值形}——M-2 期自注释「M-3 降低可达性」预言兑现{直接非穷尽形 = 编译期 E0025 拒绝}。
   - **match_m3_exhaustiveness_tests 16 case 新门族**：正向五族{通配终臂 dual-path + 运行时双路径 / 绑定臂全匹配 / bool 闭域豁免——真假双值 × 双路径 / or 展平闭域单臂 / or 含通配备选} + 负向十族{字面量单双臂 / 开放域四族[int 多臂/float/str/nil+int] / 带守卫三形[守卫通配/守卫绑定{M-2 迁移负例}/守卫排除通配全匹配性] / 半闭域两形 / 闭域带守卫 / nil 单臂非闭域 + 嵌套位字面量不计 / 序对臂恒非全匹配 + or 字面量两形} + 消息面双路径字节镜像（assert_e0025 六语料族）+ 结构诊断优先序（七组先例消息先于 E0025）+ 兜底残余类（双路径 Stage::Run + 直接非穷尽形 Stage::Expand 编译期接管）+ check 通道 E2E（负例 Err + 正例闭域程序零诊断——E0005 正交共存）+ 目标面门（read_target_source → 双侧同消息）+ 闭域 parity 三向（纯诊断批锚）。
2. **193-b GATE 1**：六命令 clean 起步全绿（build 17.95s 零告警 / check 0/0 / fmt 0 diff[两处顺修后归零——or_marker_items 重构 + match guard 形] / clippy --all-targets -D warnings 0[collapsible_match 一处顺修后归零] / **test 1285:0:0 净 +16**）+ 审计×6 280 case EXIT 0 + CLI 八路径零回归（match ⇒ fib-13 维持）+ 例行监测全带内（match 用户面 5 = match.krf 维持{纯诊断批零语料增量} / net[诊断文本带内]/extern/@/vector #( 语言面 0 / syntax-parse = TD-005 注记本体[48 轮一致] / `->` .ktf 零）+ OBS-C bench 三轮 70.479/70.906/70.602ms（<65ms 触发线不满足维持）。
3. **193-c 治理**：t3plus v1.43（14 行判定零变化——match 行维持翻转态）+ RELEASE r123 节 + matrix r123 行 + 本件 + 根层 l + README 两处 + match-design v1.3。
4. **193-d 收口**：r123 包三验 + download README + web 更新 + E2E + §6.3 投票 5.5/5.5 GO。

**关键裁定条款号**：match-design.md v1.2 §4（保守规则三条——实施化对象）/ v1.3 §4.1（五条实施裁定）/ 原则 31（皮肤/骨架——纯诊断零产物变更）/ 原则 42（编译期诊断正交[E0025 同通道零新开] + 运行时兜底双层[残余可达类]）/ 原则 43（渐进披露——红线 4 批间纪律）/ 原则 8（最小原语集合——零新原语零通道维持）/ §2.3-4（报错>静默——守卫严化 + 零死码消除）/ §12（最优>最小——诊断精确性：建议文本 + 先例消息优先序）/ §9.4.3（正负比 ≥1:3——16 case 族负向十族）/ GATE 1-6 / R4（文档同步——M-2 测试协同收窄注释化）/ §20.6（诚实验收）。

**开发实录**：①M-2 兜底测试交互预检（PHASE 1 路由期发现：`(match 5 (0 1))` 直接非穷尽形将被 E0025 拦截——非缺陷而是设计内演进{M-2 注释自预言「M-3 降低可达性」}；残余可达类语料 = bool 豁免 × 非 bool 审查值——eq : any→any→bool 经 check.krf §466 签名核实{HM 不拦——run 路径无 HM 门前置}）②fmt/clippy 两处顺修（collapsible_match 嵌套 if 折叠——重构 or_marker_items 共享助手 + match guard 形；当轮发现当轮归零）③bool 闭域豁免语料设计（`(or true false)` 单臂 = 闭域覆盖一致性要求——与双臂形态同覆盖集{否则该形态误报违零误报契约}）④M-2 协同收窄四处逐一核验（pattern_family/nested_pair/dual_path 补通配终臂后 parity 三向全等——兜底节点保持 = 纯诊断批实证）。

**演进位置**：match 实施窗 M-3 ✅（M-1 ✅ r121 → M-2 ✅ r122 → **M-3 ✅ r123** → M-4 .krf 镜像同步[下一批推荐首位——双 Reader 分歧窗闭窗]）；**1285 基线自 r123 起**；**E0025 = 首个穷尽性族编译期诊断码**（match-design §4 设计义务三件全兑现——语法域 M-1 + 语义 M-2 + 诊断 M-3）；14 行触发族判定零变化（match 行维持 r122 翻转态）；1269 基线零回归实证。

# r153 · S-expr 完全拆除窗 Batch D 用户面拆除收口（CLI 入口收敛 + reader.ktf 生产路径退役 + 语料 .krf 面清理 + 双入口测试族重构）

> **Task ID**: 223-a..223-f · **角色**: Super Z (main) — PM-A/ARCH-A/DEV-A/QA-A/REC-A 复合（M1 指令开窗第五十八例） · **Date**: 2026-11-18
> **用户三链指令**: ①继续推进目标语言设计的实现窗[遇缺陷/未完成窗口按推荐顺序直接推进进入对应窗口具体实施] ②按 sop.md 流程结合 lang-design 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 ③同步完整打包 tar.gz + 同步完整更新 web page
> **会话恢复注记**: 上一会话实施中途上下文耗尽（36 文件 +476/-1220 在场未提交、无 worklog 条目）——本会话 PHASE 1 文件系统实况核实后按 s-expr-removal-plan §4 推荐序续作收口（§8.6 冲突检测：在场工作与 worklog「下一演进 = Batch D」一致，合法续作态）。

## 交付

- **CLI 入口收敛 .ktf 单面**（223-a——对象 2「扩展名分派规则翻转」）：main.rs is_target_syntax 分派语义翻转——精确 `.ktf` 扩展名为唯一生产入口，其余一切（`.krf` 真实文件/不存在路径/无扩展名/未知扩展名/大写 `.KTF`）经 reject_retired_syntax fail-closed 拒收（exit 2 + 结构化退役诊断：命名 r153/Batch D 基准 + 指引改写为 .ktf）；拒收发生于分派层先于文件读取（不可读/不存在的 .krf 路径亦报退役而非读取错误——负例族行为锚）；run/bench/anf/native/check/tokens/stx/test 全子命令收敛 compile_source_target/run_source_target 单面（S-expr driver API 自生产面退役——余消费者 = parity oracle 测试族，E6 收口批删除）；usage 文本更新（`kerf <subcommand> <file.ktf>` 单面声明）。
- **reader.ktf 生产路径退役**（223-a——对象 3）：bootstrap/mod.rs + driver.rs 退役注记（oracle-of-record duty 单一化——compile_front 读段服务于 parity oracle 测试族直至 E6 删除；E6 后 target_reader.ktf 收敛为唯一 reader.ktf——v1.3 §11 终局整合指令维持）。
- **语料 .krf 面清理**（223-b——对象 5）：usage 15 对的 .krf 面全量删除（fib/closures/macros/higher_order/gc_stress/gc_stress_nontail/io/effect_stress/effect_handle_expr/effect_multiarm/effect_nested_resume/ffi/ffi_alias/match/vector 等——`rg --files -g '*.krf'` 仓库余 8 件 = 七件种子平行件 oracle + target_reader_lex.krf 抽取件，俱 E6 删除对象）；examples/README v0.2.0 单面化（.krf 演示表退役——跨语法行为等价证据归档 RELEASE r127-r152；行内等价纪律由 cli_entry_convergence_tests 承载）。
- **双入口测试族重构**（223-b/c——门 D 载体）：cli_dual_entry_tests（530 行 22 case——r125 双入口窗遗产）删除 → **cli_entry_convergence_tests 新立（655 行 27 case——8 正 + 19 负 1:2.4）**：①跨语法行为等价{目标面 fib 经 run_source_target/check_source_target_recover/test_runner::run_target 全生产链 ↔ S-expr 库面 oracle——principle 31 皮肤/骨架同构} ②CLI 边界收敛{编译二进制子进程实测：.ktf 受理 + .krf 真实/不存在/无扩展/未知扩展/.KTF 全族 exit 2 + 退役诊断文本锚} ③驱动 API 正交{文件名 = Span 标签非分派输入——收敛仅居于 CLI 分派层} ④fail-closed 负例族{S-expr 源入目标入口/词法/文法/use 域外/展开诊断/HM 类型/运行时类型/恢复模式多错收集} + 缓存裁定锚{目标面入口 cache-free 维持}。
- **十四测试族内联语料归档改写**（223-b）：switch_corpus_parity/ktf_handle_multiarm/ktf_macros_corpus/ktf_nested_resume/ktf_read_line_sig/ktf_stress_corpus/ktf_tc_sigs_parity/hm_production_switch/hm_perf_evolution/effect_tests/hm_inference_tests/bootstrap_compiler_tests/qbe_backend_tests/capability_tests/typecheck_tests——已删除 .krf 语料的使用改 read .ktf 对应件或内联归档（「the retired X.krf corpus archived inline — r153 / 223-c」注记纪律）。
- **门 D 三判据全绿**：CLI 单面零回归{fib ⇒75025/144 + check ok + effect_multiarm ⇒217 + nested_resume ⇒540 + closures ⇒42 + test 6/6 + tokens + match ⇒fib-13 + vector ⇒9 + higher_order ⇒(1 4 9 16 25) + bench 75.107ms 带内 + anf} + .krf 拒收 fail-closed 负例族{EXIT 2 实测五路径} + 语料 .ktf 单面全绿{1712 既有测试全量经单面语料零回归}。

## GATE 1（clean 起步全绿实测）

cargo clean → build --release 零告警 → check --all-targets 0:0 → fmt 零 diff → clippy -D warnings 0 → **test --release --workspace 2049:0:0 净 +5**{RUST_MIN_STACK=33554432——299 单元 + 1750 集成} + 审计×6 真实 EXIT 0{stage0/stage1/stage2_r1/stage2_r2/e5close/m3} + CLI 单面零回归 + bench 75.107ms 带内{r149-r152 带内 71.7-76.6；OBS-C <65ms 不满足维持——零信号}。

## 内循环修正（本会话收口腿，3 处）

1. clippy doc 列表缩进 12 处（mod.rs/driver.rs 退役注记的 `+ §4` 续行被 rustdoc 解析为列表项——换行重排）；
2. typecheck_tests needless_borrow 1 处（&name → name）；
3. switch_corpus_parity_tests 内联归档 effect_stress 源转写笔误（guarded 体第三行闭括号 3→4——git show HEAD 对账定位，E0001 unclosed parenthesis 根因）。

## 治理对账九件

matrix r153 增量行 + 总量行 2049 + RELEASE r153 节 + README 两处{质量状态 + 打包交付} + t3plus v1.73{14 行零变化} + s-expr-removal-plan v1.4{§4 Batch D 行 ✅ + §12 Batch D 对账节} + 替换面图 §8.3 Batch D 进程注记 + examples/README v0.2.0 + rec 114 + 根层 l + 03 层 l + worklog 三链。20 §14 皮肤字典无增量（Batch D = 入口层翻转非转换批——零新转换纪律，跳过有据）。

**8 原语不变性第三十五轮**（纯入口层/语料形态切换——零机制变更零新原语零通道）。**下一演进 = E6 收口批**：终局清理（七件 .krf 平行件 + target_reader_lex.krf 删除 + Rust S-expr Reader 经典面拆除 + KRF_SOURCES → KTF_SOURCES 翻转 + compile_front_seed 退役 + 文档终局回写 + target_reader.ktf → reader.ktf 单一收敛——§6 退出条件五项终验——门 E6——r154）。

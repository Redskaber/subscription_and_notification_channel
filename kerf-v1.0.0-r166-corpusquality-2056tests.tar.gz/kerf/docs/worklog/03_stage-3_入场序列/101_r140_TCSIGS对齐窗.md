# r140 TC-SIGS Oracle 对齐窗（check.krf 签名表 24→61 逐行同构扩表 + sig 语言定点扩展）

> **Author**: Super Z (main) — PM-A/ARCH-A/DEV-A/QA-A/REC-A 复合
> **Date**: 2026-11-11
> **Task ID**: 210-a..210-f
> **类型**: 登记域外行清偿实施窗（净 +32——1756 基线自 r140 起）
> **驱动**: 用户三链指令（①继续推进目标语言设计的实现窗[遇缺陷/未完成窗口按推荐顺序直接推进进入对应窗口开始具体实施] ②按 sop.md 流程结合 lang-design 与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐序推进 ③完整打包 tar.gz + 同步完整更新 web page）——M1 指令开窗第四十五例

## 交付六段

1. **210-a 设计单源**：tc-sigs-parity-design.md v1.0{D1-D8 + §7 域外表}——37 行逐行同构映射表{变长 5 + 定形齐次 23 + 既有修正 1 + 'sigf 定形异参 5} + D2 'sigf 形 + D3 结果映射{Unknown→fresh 镜像 oracle——非 Dynamic；Pair→Dynamic} + D4 新 kind 逐位裁定{'int tvar→Num 域宽化[方向守卫防御位] + 'list/'pair tvar 零约束 + 'sym} + D5 消息族沿袭{族形非 op 专属——计数 parity 为守护面} + D6 方向守卫维持论证 + D7 锚翻转预算 + D8 测试矩阵。
2. **210-b 实施**：check.krf TC-SIGS **24→61 行** + string-append 既有行修正{(sig 0 999999 'str 'str)→(sig 2 2 'str 'str)——运行时恒 2 参[args.len()!=2→E0004] + oracle fixed(&[Str,Str],Str)——原 krf 静态放行 1/3 参调用分歧清偿} + tc-infer-builtin 'sig/'sigf 双形分派 + tc-infer-builtin-fixed/tc-check-pos-rules/tc-sig-result 三新函数 + tc-rule-one 新 kind 四臂 + tvar 域特化臂 + tc-rule-msg 新 kind 四消息——纯 .krf 面零桥变更零 Rust 变更。
3. **210-c 测试**：ktf_tc_sigs_parity_tests 32 case{8 正 + 24 负 1:3} + **同窗锚翻转三件**{hm_production_switch 七语料锚：expander.ktf 0→6 + compiler.ktf 1→2 + reader.ktf 0→3——逐条裁定真检出[num 入 int 索引位族 oracle 同报 + unify 冲突位——krf 6⊆oracle 80/2⊆27/3⊆31/2⊆25 方向守卫全维持]} + **同窗缺陷清偿**{r102 命名守卫命中新注释 `->` ×5 → 全角箭头顺修}。
4. **210-d GATE 1**：六命令 clean 起步全绿{clean + build --release 21.59s + check 0/0 + fmt 0 + clippy -D warnings 0 + **test --release --workspace 1756:0:0 净 +32**} + 审计×6 EXIT 0 ×6{280 case 全 APPROVED} + CLI 双语法面零回归{fib 75025/⇒144 双面 + nested 540 + multiarm 217 + closures 42 + higher_order + vector ⇒9 + check ok + test PASS + ffi ⇒9 + effect_stress ⇒120} + bench 带内{gc_stress 109ms}。
5. **210-e 治理对账**：member-rename-design v1.3{§7 TC-SIGS 行翻转清偿关闭 + io read 族行重锚} + t3plus audit v1.60 + guide v1.25{M1 第四十五例} + RELEASE r140 节 + matrix r140 行/总量 1756 + README 三处 + rec 101 + worklog 三链。
6. **210-f 收口**：r140 包三验 + web 五件 + Agent Browser E2E + 投票 5.5/5.5 GO。
7. **遵循**：§3.2（六命令）/ §5.3（内循环八项）/ §7.2-7.3（审计×6 门审）/ §8.4.6+§9.1（两级落位）/ §8.5/§8.6（worklog 三链）/ §9.4.3（1:3）/ §19（打包三验）/ §20.6（锚翻转全族裁定）/ 原则 12/27/31 + R4。

## 关键裁定

- **D4 Int 参 Num 域宽化**：'int 参对 tvar 统一至 (tcon 'num)——镜像 oracle `Num|Int => Some(Ty::Num)`；直统一 'int 会使 (f 1.5) 形 krf 报 oracle 不报 → krf ⊄ oracle 方向破坏（p04 正锚实证防御位）。
- **D3 Unknown→fresh**：'unknown 结果 → (tc-fresh) 非 (tcon 'dynamic)——镜像 oracle `Unknown => self.fresh()`；未解变元经泛化 ∀α 同构。
- **member/assoc 结果 Bool 建模沿袭**：运行时命中返回 Pair——oracle 谓词化建模沿袭（设计 §7 域外登记——oracle 行语义复审独立评估面）。
- **8 原语不变性第二十二轮验证**：零新原语零通道零操作码零语法——纯静态签名面扩展。

## 验收

- §3.2 六命令全绿 + test --release --workspace **1756:0:0 净 +32**
- 审计×6 280 case EXIT 0 ×6 全 APPROVED
- CLI 双语法面零回归 + bench 带内
- 方向守卫实测维持（krf ⊆ oracle 全语料）
- r140 包三验 + web 五件 + Agent Browser E2E

## 演进位置

**1756 基线自 r140 起**；member-rename §7 TC-SIGS 登记行清偿关闭；触发族 14 行判定零变化；登记册触发式实施项维持全清零；下一演进 = 触发式零信号维持或自然信号——按用户指令序或自然信号。

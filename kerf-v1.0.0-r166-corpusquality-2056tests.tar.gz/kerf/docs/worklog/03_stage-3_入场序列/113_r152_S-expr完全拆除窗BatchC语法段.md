# r152 · S-expr 完全拆除窗 Batch C 语法段收口（target_reader.krf → target_reader.ktf 语法段）：Reader fixpoint 里程碑收口

> **Task ID**: 222-a..222-f · **角色**: Super Z (main) — PM-A/ARCH-A/DEV-A/QA-A/REC-A 复合（M1 指令开窗第五十七例） · **Date**: 2026-11-17
> **用户四链指令**: ①审查 kerf-driver/bootstrap/reader.ktf、target_reader* 文件相关，移除重复项或整合为单一 reader.ktf，同理在 rust 端同步整合管理 ②继续推进目标语言设计的实现窗[遇缺陷/未完成窗口按推荐顺序直接推进进入对应窗口具体实施] ③按 sop.md 流程结合 lang-design 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 ④同步完整打包 tar.gz + 同步完整更新 web page

## 交付

- **target_reader.ktf 语法段全量转写**（675-2984 行约 156 define → 4230 行全件）：皮肤字典机械映射（cond→if-else 右递归 + 深嵌套 let 穿线{多绑定→逗号并列 D61 + 嵌套单绑定→顺序语句} + 'sym→quote(sym) + 裸 nil→() + n 元 and/or 右嵌套 + eq/= 分工 + (= a b)→== + (- 1)→-1{r151 第三锚复用} + do/多表达式体→语句序列{D42} + 闭包表达式→||(op: T, v: T){body} + assign 语句位 + kebab↔snake）；六块子代理并行转写 c1-c6——156 define 全转 0 UNMAPPED。
- **转换纪律第四新锚两新面**：值位 let 表达式 define → 工厂函数 + define 调用双侧镜像（kcell——closures.krf make-counter 先例）；if 臂值位 assign → do 包裹语句化双侧镜像（(do (assign cell v) nil) ↔ {cell = v;}——双侧同形→字节码全等）。
- **桥语法入口切换**：read_target_source_for_bootstrap 装载 .krf→.ktf（compile_front_seed_target）——**Reader fixpoint 里程碑收口**：生产 .ktf 读桥的词法器+解析器俱以目标语言表述，经种子 target Reader 读入运行于 VM。
- **桥双状态收敛**：r151 词法腿的 TARGET_READER_LEX 临时态退役——双入口单程序单状态（用户指令① Rust 端整合腿）+ driver.rs 陈旧文档注记修正五处。
- **门 C 语法段**：seed_ktf_parity_tests 96 → 128 case（8 正 + 24 负 1:3）——门 X 全文件字节码 parity{全件 oracle ↔ 全件转写件} + 载荷形状锚{209/488/240 双侧} + **门 Z fixpoint**{fixpoint_self_parse_stx_parity——生产读桥解析自身源文 ↔ Rust 种子：正典 Stx 渲染逐项字节级全等} + 语法入口面 + kcell 工厂面 + 语法命名回环 28 名 + 语法内建消费面{append/is-pair/length} + 解析双跑确定性 + 解析快照锚 + 负向 24 族{语法段全声明族 fail-closed}。
- **门 Y**：target_reader_krf_tests 32 case 零变更全绿（语法 16 族断言面自动升级 .ktf 路径 + 1712 既有测试全量经新解析器零回归）。
- **单一 reader.ktf 终局整合指令登记**（用户指令①——s-expr-removal-plan v1.3 §11）：reader.ktf{S-expr Reader}与 target_reader.ktf 非重复项（过渡期双 Reader 合法态）；E6 端态 = target_reader.ktf 更名收敛为唯一 reader.ktf + Rust 端 kerf-reader 同步收敛；提前整合 = 红线 3 违例。

## GATE 1（clean 起步全绿实测）

cargo clean{522 files/88.9MiB} → build --release 23.01s 零告警 → check --all-targets 0:0 → fmt 零 diff → clippy -D warnings 0 → **test --release --workspace 2044:0:0 净 +32**{RUST_MIN_STACK=33554432——299 单元 + 1745 集成} + 审计×6 真实 EXIT 0{280 case} + CLI 双语法面零回归十二路径{fib ⇒75025/144 双面 + check ok 2/9/5/38 双面 + effect_multiarm ⇒217 双面 + nested_resume ⇒540 双面 + closures ⇒42 + test 2/2 双面 + tokens .ktf 桥生产面} + bench 75.799/76.045/75.203ms 带内{r149-r151 带内 71.7-76.6；OBS-C <65ms 不满足维持——零信号}。

## 内循环修正 2 轮

1. parse-typed-params 的 eq 误映射 == 单点——门 X 指令级定位 proto 129 LoadGlobal 123≠129（子代理误用数值 == 于 eq 位点）→ 修为 !(eq(...)) 调用形；
2. 解析快照锚预期值实测校准。

## 治理对账九件

matrix r152 增量行 + 总量行 2044 + RELEASE r152 节 + README 两处{质量状态 + 打包交付} + t3plus v1.72{14 行零变化 + r151 版本行滞留 v1.70 的 R4 顺修} + s-expr-removal-plan v1.3{§4 Batch C 全闭 + §10 语法段对账节 + §11 终局整合指令} + 20 v1.34{§14 种子域语法段增量纪律} + 替换面图 §8.3 Batch C 全闭注记 + rec 113 + 根层 l + worklog 三链。

**8 原语不变性第三十四轮**（纯皮肤/载荷形态切换——零机制变更零新原语零通道）。**下一演进 = Batch D**：用户面拆除（CLI .krf 入口收敛 + reader.ktf 退役 + 语料清理 + 双入口测试族重构——门 D——r153）。

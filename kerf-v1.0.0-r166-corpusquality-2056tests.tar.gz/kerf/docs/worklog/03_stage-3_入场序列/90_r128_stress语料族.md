# rec 90 —— r128 语料族深度化窗（stress 变体批）：examples/usage/*.ktf stress 三件 + handler 块体 resume 文法清偿（1393 新基线）

**Task ID**：198-a..198-e　**日期**：2026-11-03　**角色**：Super Z (main)——ARCH-A（裁定）+ DEV-A（实施）+ QA-A（验收）+ REC-A（对账）——M1 指令开窗第三十三例

**驱动**：用户三链指令（①继续推进 目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施 ②按照 docs/sop.md 流程结合 docs/lang-design/ 下的项目演进流程 与 docs/develop/v0/tech-debt-register.md，docs/develop/v0/stage-3/t3plus-trigger-audit.md 按照推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page）——r127 收口笔推荐序首位兑现{stress 变体批三源一致：r127 收口笔 + switch-window-plan v1.10 + t3plus v1.47——均列首位；r127 诚实边界已登记「effect_stress GC 压力变体 = 后续自然信号」}。

**会话前置核实**：本会话（第三次压缩后恢复）路由前机器态核实——r127 全链已由 197-a..197-e 兑现（git 链 1907e09 干净 + download r127 包在位 10,659,789B + web v7.85 同步）；§8.6 冲突检测零冲突；**任务零（历史恢复指令）无需执行**（本会话激活提示词已移除该任务且项目实测处于 r127 完整态）。

**开窗判据回填（198-a）**：七项判据表全过——需求信号（r74 先例锚：用户显式指令点名 = 需求信号命中；红线 3 合规——指令即信号本体）✓ 推荐序自然落位（stress 变体居首位；宏面语料列次位成为下轮首位）✓ 技术就绪（皮肤字典八映射全在位 + stress 语料 .krf 原件实测 76-133ms 可入测试）✓ 语料面缺位核实（examples/usage/ 零 .ktf stress 件）✓ 8 原语不变性（语料 + 文法清偿纯消费零新原语零通道——resume 扩展 = 既有核心形式 `(resume k v)` 的目标面语句形映射）✓ §6.2 债务前置（TD 登记册零开放 P0/P1）✓ 治理边界（本窗 ≠ 切换窗本体；**本窗发现真实文法缺口**——目标面 handler 块体无法表达 S 表达式面 `(do A (resume k v))` 序列形，按用户指令①「中途穿着缺陷…直接推进实施」行权文法清偿）✓——ARCH-A + PM-A 双确认 GO。

**交付**：

1. **198-b 实施——handler 块体 resume 文法缺口清偿（双侧 Reader）**：
   - **缺口根因**：S 表达式面 handler 体 `(do (mk 50000) (resume k (+ (tail p) (head p))))` 的「分配后恢复」序列在目标面不可表达——直位 `=> resume(v)` 无语句序列承载，effect_stress.krf 翻译直接受阻（语料深度化暴露的真实缺陷——用户指令①行权对象）。
   - **清偿形**：处理器臂块体顶层语句/尾位 resume 调用形 `resume(expr)` → `(resume k expr)`——k 由臂绑定注入（用户永不书写）；语句位（后随 ;）与尾位（后随 }）同形；一次性 resume 语句后的语句 = 死代码（与 S 表达式 `(do (resume k v) dead)` 同构——值锚实证 120）；**嵌套块（if 臂/闭包体）内 resume = 登记域外 fail-closed 诚实边界**（S 表达式面词法作用域内合法——目标面收窄，触发式后续信号）；普通块无处理器作用域 → 既有「期望表达式，实际 KwResume」错误路径逐字节不变。
   - **双侧落地**：种子 `parse_handler_block`/`parse_resume_call`（target.rs——parse_block_inner 参数化 + parse_handler_body 直位/块体统一，`match (peek, resume_var)` 形避开 clippy unnecessary_unwrap）+ 镜像 `parse-handler-block`/`parse-resume-call`（target_reader.krf——block-loop 增 k-node 参数第四形{普通块恒 nil——零回归}；镜像一处括号失衡首测当场拦截修正）。
   - **三面登记**：产生式 = 02 §8.13.1a v7.13（handler_body/handler_block/resume_stmt 三产生式 + 缺口根因注记）+ 皮肤字典 = 20 §14 v1.20（D2 handle 映射体域扩展行——非新编号映射）+ 层次关系行同步。

2. **198-b 实施——stress 语料三件就位 + ktf_stress_corpus_tests 32 case**：
   - **effect_stress.ktf** ⇒ 120：mk(50000) 挂起续延跨多轮标记清扫存活 + `{ mk(50000); resume(tail(p) + head(p)) }` handler 块体 resume 语句形——r128 文法清偿载体。
   - **gc_stress.ktf** ⇒ 5：`define(keep, list(1, 2, 3, 4, 5));` 运行时构造（目标面无引号列表字面量 r127 诚实边界）+ spin(30000) 尾形 TCO + 10^6 量级分配堆稳定。
   - **gc_stress_nontail.ktf** ⇒ 5：`grow(n - 1) + 1` 非尾位深帧根集枚举负载（TD-023 基准重定型目标面）。
   - **跨语法行为等价与 .krf 对应件逐位一致**（120/5/5——原则 31）；三件 check 面零诊断带真实指令工件（65/94/72 指令）。
   - **ktf_stress_corpus_tests 32 case**（tests/v0/stage3/plan/ + runner.rs 挂载）：正向八族（三语料 run E2E 值锚 + 跨语法值 parity 三对[.krf run_source ↔ .ktf run_source_target] + 双 Reader 文法 parity[三语料全件 + 四聚焦形：尾位/语句位死代码/let 穿线/纯 resume 块——正典渲染字节级] + 双 Reader 错误面 parity[五负形消息+Span 字节级] + check 面跨阶段消费 + 语句位 resume 一次性跳离语义值锚）+ 负向二十四族（新形纪律十族：普通 fn 块/顶层/嵌套 if 臂/嵌套闭包/无括号/未闭合/双实参/直位语句序列/保护表达式位/空实参 + 既有族十四族：词法/文法/类型必填/E0006 能力/E0022 短路/E0022 N2 注入面/E0025 穷尽/HM E0005 三形/运行期 E0004 三形/恢复位置序/r126 ∀α 吸收目标面消费）——**正负比 8:24 = 1:3**（§9.4.3）；语料 = include_str! 测试工件（语料完整性门）。同轮 E0025 测试形一处顺修（恢复模式收集 fn 不绑定——调用引发 E0022 短路；回归 r127 原形）。

3. **198-c GATE 1**：六命令 clean 起步全绿——cargo clean 725 files/193.7MiB → build --release **20.43s 零告警** / check --workspace --all-targets 0 errors 0 warnings / fmt --all --check 0 diff（一处顺修后归零）/ clippy --workspace --release --all-targets -D warnings 0 errors（一处顺修后归零） / **test --release --workspace 1393:0:0**（净 +32；RUST_MIN_STACK=16777216）+ 审计×6 280 case EXIT 0 ×6 + CLI 双语法面零回归（.krf 八路径 + .ktf 新三路径 120/5/5 + 语料族 fib ⇒144/match ⇒fib-13 维持）+ OBS-C bench 三轮 108-111ms（<65ms 触发线不满足维持零信号——sandbox 负载态绝对值波动，触发线对比为协议事实）。

4. **198-d 治理**：对账九件——t3plus v1.48（Date 行 r128 消费注记 + Version 头 v1.48 段——14 行判定零变化 + .ktf 语料族 6→9 件族邻域增量）+ RELEASE r128 节 + matrix r128 增量行 + 总量行 1393 对账 + switch-window-plan 下一批推荐行更新（r128 后——宏面语料候选首位）+ README 三处（质量状态行 r128/1393 + 打包交付行最新包 r128-stresscorpus-1393tests + 门禁表/目录树 R4 顺修[1143→1393 陈旧口径 + usage 计数 9+9]）+ examples/README .ktf 语料族表（R4 对齐——r127 六件 + r128 三件全量登记）+ rec 90（本件）+ 根层 l r128 行 + worklog 三链镜像 + 02 v7.13 / 20 v1.20（文法登记——实施笔同轮）。

5. **198-e 收口**：r128 包三验（git archive 单源 → 独立解包净构建 + 1393 复跑 + e5close 审计 EXIT 0 + 生产面语料实证）+ download README r128 节 + web 五处（kerf-data/hero/footer/stats/download）+ Agent Browser E2E（双视口零溢出 + 语料族消费探针 + stats 双源对账 1393/r128 包名）+ §6.3 投票。

**演进位置**：**语料族深度化窗（stress 变体批）全闭 ✅**——.ktf 语料族 6→9 件（与 .krf 语料族 9 件对齐——唯 macros.ktf 宏面语料缺位）；handler 块体 resume 文法缺口清偿（双侧 Reader + 产生式 + 皮肤字典三面同轮）；**1393 基线自 r128 起**；14 行触发族判定零变化（T3+ #5 族邻域语料面信号增量——供切换窗消费）；下一演进 = 宏面语料（macros.ktf——需宏定义目标面形设计{第九映射候选：define-syntax/syntax-rules 双侧 Reader + 皮肤字典登记}，触发式）或触发式零信号维持——按用户指令序或自然信号。

**遵循条款**：指南 §1.1/§1.3（r74 先例——用户指令 = 需求信号本体 + 标准流程） / 20 §14 v1.20（handler 块体 resume 语句映射——D2 handle 映射体域扩展） / 02 §8.13.1a v7.13（Level 0 实施产生式） / 原则 31（皮肤/骨架同构——跨语法行为等价实证 + 双 Reader 正典渲染字节级 parity） / 原则 27（加性演化——语料 + 测试纯加性；普通块错误路径零回归） / 原则 44（新语法成员登记必须附 EBNF 产生式） / 原则 38（登记态零机制变更义务——嵌套块 resume 域外边界登记） / §9.4.3（正负比 1:3） / §3.2（六命令验收） / §8.5/§8.6（文档同步 + worklog 三链） / R4（文档以实况为准——README 门禁表陈旧口径当轮顺修） / switch-window-plan v1.10（stress 变体推荐位兑现）。

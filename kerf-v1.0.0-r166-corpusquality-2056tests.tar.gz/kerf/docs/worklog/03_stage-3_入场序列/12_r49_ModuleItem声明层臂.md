# r49 · ModuleItem 声明层臂（CoreExpr 12→9 + do-splice + 位置纪律前移）

- **Task**：70-a（设计 D59-D62 落档 22 §17）/ 70-b（实施全链）/ 70-z（打包 v0.16.0-r49）/ 70-web（web 面）
- **深审 D59-D62**（22 §17）：D59 ModuleItem 声明层（CoreExpr 12→9[Define/Module/Require 上移] + 两级文法[SML dec-exp/Python stmt-expr/Racket module-begin 三家族共识] + **module 级 do-splice**[宏产顶层 define 合法通道——字节码全等：do 链 `[item; Pop]*` ≡ 项序] + 位置纪律前移[E0003/E0018 消息逐字 + E0023 新码位] + 发射域零变化[IrExpr 保留发射节点]）+ D60 正交收益（**非正交点 2→1——E5 出口条件③ ≤1 达标**）+ D61 let 直映臂规格（r49-β 分臂——多绑定暂存法 + 行为 parity 门）+ D62 排期重锚（r49-β → r50 S4 收口 → v1.0.0）
- **实施**：kerf-core（ModuleItem 四 kind + lower_item）+ expander（classify_item_form 分类器 + 三位置拒绝臂）+ compiler（lower_module 项入口 + hm/typecheck 项级）+ driver（八走查项化 + verify_require_positions_stx）+ 桥（item_from_value/item_to_node——wire 协议文本不变）+ **compiler.krf 零变更** + expander.krf 分类器镜像（classify-transformer-step 裸产物形）
- **868:0:0**（859 基线零回归 + 净 +9）+ §3.2 六命令 clean 起步全绿 + 五审计集 ×5 + CLI 全路径（含 do-splice 端到端 → 7）+ 包内自举一致
- **TD-030 登记**：check+prelude HM occurs 误报（前置既有缺陷——r48 stash 对照实证；修复窗 r49-β）
- 开发实录三则：corpus trampoline 结构差（裸产物形）/ 非列表产物 node-fields 越界（分类器两端守卫）/ E0018 契约保持路径（Stx 游走承载码位 18）
- **下一步**：r49-β let 直映臂（D61 + TD-030 修复）→ r50 S4 收口（E5 出口三条件终验 + 门审 ≥30 case → v1.0.0）

# rec 94 —— r132 handle 多臂 / halt / pass 窗【R4 补债件】

> **Task ID**: 202-a..202-f　**Agent**: Super Z (main) — PM-A/ARCH-A/DEV-A/QA-A/REC-A 复合
> **Date**: 2026-11-06（原窗日期）；2026-11-14（r146/216-b 补债落档）
> **基线**: 1526:0:0 净 +32（1526 基线自 r132 起）　**开窗**: M1 指令开窗第三十七例
> **补债注记（R4——文档以实况为准）**：r132 收口声称「rec 94（03 层第 94 件）」但物理件未落盘；r133 轮后占 94 号（94_r133_嵌套resume窗.md 原件在位）。本件为 r146/216-b 审计链交叉核对扩展轮发现的补债回填——**94 号同号两件并存**{本件 = r132 补债件 + 94_r133 = r133 原件}——与 101 同号两件先例（r144 l 补债注记）同构。

## 窗口内容（自 docs/worklog.md 202-a..202-f 全录 + RELEASE r132 节回填）

- **开窗**：用户三链指令（①实现窗推进——切换窗后续域外登记末项 ②推荐序推进 ③打包 tar.gz + web 同步）；推荐序首位 = r131 收口笔唯一设计先行态余项{handle 多臂/halt/pass——需 resume ∈ {0,1} 合围扩展设计}
- **设计单源**：handle-multi-arm-design.md v1.0 D1-D10{机制层三事实：嵌套组合/不 resume 尾值/重 perform 全在位——零机制变更·8 原语不变性第十四轮}
- **实施（202-c）**：第十二映射族双侧 Reader——`handle e { A(p,k) => b₁, B(p,k) => b₂, }` 多臂 → 嵌套单臂 handle 脱糖{先写臂外层——表面臂序 = 嵌套包裹序} + `halt`/`halt(v)` 终止流尾值糖{resume ∈ {0,1} 合围 {0} 形} + `pass` 穿透重构 `(perform (cons (quote T) p))`{T-EFFECT-PROPAGATION——外层 resume 自 pass 点续起} + 重复标签 fail-closed + halt/pass 目标面本地关键字{S-expr 面零扰动——r129 macro 先例第 2 连}
- **同窗 fvo P1 缺陷清偿**：条件入栈/无条件弹出错配{compiler.ktf handle/fn 臂 + Rust expr.rs 同型——嵌套同名绑定 handle 崩 tail(nil)——既有性经纯 .krf 手写形实证}；Let 臂 r45/D42 shadow-aware 纪律双侧延拓——同类三臂收口
- **门**：ktf_handle_multiarm_tests 32 case{8 正 + 24 负 1:3——嵌套等价字节码全等门{共享符号表——.ktf 平坦形 ↔ .krf 手写嵌套形 compile 产物全等} + 双 Reader 正典渲染/错误面字节级 parity + 语义负例}
- **语料对**：effect_multiarm.{ktf,krf}{11:11——⇒202 双面}
- **GATE 1（202-d）**：六命令 clean 起步全绿{build 20.76s 零告警 + test 1526:0:0 净 +32 + 审计×6 EXIT 0 + CLI 双语法面零回归 + bench 75.398ms 带内}
- **治理（202-e）**：九件{t3plus v1.52 + RELEASE r132 节 + matrix r132 行/总量 1526 + switch-window-plan v1.11{§4 行清偿 ✅ r132——切换窗后续域外登记清零} + TD-033 新增登记{登记册 v0.4.14-r132——组安装语义触发式} + README 三处 + 02 v7.17{§8.13.1a handle_stmt 产生式族} + 20 v1.24{§14 皮肤字典第十二映射族} + 22 §880 注记}
- **收口（202-f）**：r132 包三验{650 成员/12,399,710 字节——19.24s 净构建 + 1526 复跑 + e5close EXIT 0 + 多臂包内实证 202} + web 完整更新{kerf-data/footer v7.90/hero} + Agent Browser E2E{桌面六探针 + 移动 NO_OVERFLOW + Playground ⇒144} + 投票 5.5/5.5 = 100% GO

## 遵循

§1.2 路由 / §3.2 六命令 / §5.3 八项 / GATE 1-2 / §8.4.6 两级落位 / §8.5/§8.6 三链 / 原则 9/27/31/44 / r129 macro 先例（目标面本地关键字第 2 连）/ §20.3（同类路径全量审查）/ R4（本件本体 = 补债清偿）

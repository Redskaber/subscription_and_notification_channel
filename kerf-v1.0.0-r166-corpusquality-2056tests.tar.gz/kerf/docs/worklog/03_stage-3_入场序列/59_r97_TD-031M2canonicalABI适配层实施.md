# r97 TD-031 M2 canonical ABI 适配层实施轮（167-a..167-f）

> **Agent**: Super Z (main) — ARCH-A/IMPL/QA-A/PM-A 复合
> **Date**: 2026-10-19
> **驱动源**：用户双链指令「① 按照 docs/sop.md 流程结合 docs/lang-design/ 下文档集合推进项目演进流程 与 docs/develop/v0/tech-debt-register.md，docs/develop/v0/stage-3/t3plus-trigger-audit.md 按照推荐先后任务顺序继续推进 ② 同步完整打包项目 tar.gz 并同步完整更新 web page」——**M1 指令开窗第八例**（指南 §4 速查卡【第 3 位】TD-031 M2；行权链 r74/r79/r80/r86/r87/r90/r92/r97）。

## 行权裁定

- **推荐序裁定**：第 1 位 #15 需 next17.md 未上传（next16.md 已 r96 全量消费——upload 实测无新语料）→ 第 2 位 TD-032 ✅ r90 / 第 4 位 HM ✅ r80 清偿 → **第 3 位 TD-031 M2 落位**。
- **M2 判据实测回填**：M1 ✅ r92 + **边界类型消费 case ≥10 实测成立**——语料库 18 个 .krf：10 语料消费 str（check 50 / compiler 50 / expander 214 / reader 91 行级命中）、9 语料消费 pair/list（expander 86 / check 44 / compiler 33）——行级命中 400+ ≫ 10；bootstrap 自举链全量依赖边界类型。交付集成 11 case 直接对齐判据口径。

## 交付

- **167-a 实施**：①`crates/kerf-backend/src/wasm_abi.rs`（canonical ABI 协议层——CanonicalAbiOptions 三字段**全消费**：string_encoding → UTF-8/UTF-16 **验证性**串编解码[非法 UTF-8 序列/奇数字节长度/孤立高/低代理/交错代理对 fail-closed] + memory64 → AddressWidth 地址域 + realloc → bump 协议锚[对齐表 log2→字节 + align_up + 默认名 + 页几何] + 单元 12）；②`wasm_emit.rs` 增量 `emit_abi_module(data, abi)`（七节：Type/Function/Memory[flags 0x04 = memory64]/Global[堆指针 align_up(max(len,1),8)——地址 0 保留 null 哨兵]/Export[memory + realloc 名锚]/Code/Data[active 段 offset 0 = str 跨界载荷面]；**realloc bump 函数**[(old_ptr, old_size, align, new_size) → new_ptr 四参协议——对齐 1<<align 向上取整{-a = 0-a 二补数免负常量} + block/loop 旧数据逐字节复制保留 + 堆单调前进 + i32/i64 双地址域单源操作码选择]；契约语义诚实兑现[realloc = None → 省略四节/空 data → 省略 Data 节/data > u32 fail-closed]）；③`tests/v0/stage3/plan/wasm_abi_tests.rs` 集成 11（**node 宿主 str 跨界 parity**[Rust 编码 → data 段 → node 读回 hex 逐字节对账 → 解码回原串——UTF-8/UTF-16 双形] + realloc 协议 E2E[首次=堆基址/单调/8 对齐/旧 5 字节逐字节保留/第三不重叠/零大小仍前进] + memory 导出面与页数几何[2 页/4 页跨页锚] + 自定义 realloc 名导出 + memory64 字节级断言[L-C′：节走查 flags 0x04 + Global i64 + Type 四参全 i64 + Data offset i64.const] + 确定性/内容敏感/协议参数敏感 + cross_encoding_case_count_register 交付对账锚）——**净 +23 测试 1114:0:0**。
- **167-b 对账八件**：登记册 v0.4.12（TD-031 M2 ✅）+ wasm-backend-component-model v1.2（§5 M2 行 + §5.2 交付实录）+ t3plus v1.17（r97 消费注记）+ 指南 v1.16（速查卡【第 3 位】M2 ✅ r97 + 行权态十四次）+ matrix r97 行 + RELEASE r97 节 + rec 59 + 层 l r97 条目。
- **167-c 终验**：§3.2 六命令 clean 起步全绿（build 零告警 + check 0/0 + fmt 0 diff + clippy 零告警 + test 1114:0:0）+ 审计×6 280 case EXIT 0 + CLI 三路径零回归（fib⇒144 / check ok / effect⇒120）。
- **167-d 打包 + web**：r97 包三验全绿 + web 五件（kerf-data 五处 + footer + download README + stats 双源自动对账 + E2E 双视口 + Playground）。

## 核心裁定

- **L-A′ M2 范围裁定**：M2 = canonical ABI 协议层做实；语言面 str 字面量 lowering（ANF B1 扩界——StxDatum::Str → AAtom::Str）**不在 M2 范围**——B1 扩界 = 独立演进信号（与 TD-024 Float 域扩张同族；`string_literal_rejected_before_emit` 负例继续守护）；语言面接入随后续信号（M3 组件组合 / B1 扩界窗）。
- **L-B′ 零依赖沿袭**：UTF-8/UTF-16 编解码纯 Rust 标准库（std::str::from_utf8 + char::decode_utf16）——零 cargo 依赖（§18 纪律）。
- **L-C′ memory64 验证策略**：发射支持（limits flag 0x04 + i64 地址域 realloc 变体）+ 字节级断言；node 宿主 E2E 跑 wasm32 域（node 对 memory64 实例化支持是版本依赖——诚实注记，不宣称未验证的实例化能力）。
- **bump 诚实边界**：不做 memory.grow（初始余量耗尽即越界 trap——fail-closed 非静默降级）；旧块不回收（bump 单调——free 协议由宿主 GC 域承接）。

## 演进位置

TD-031 终态 = M0 契约层 ✅ r74 + M1 核心模块生成 ✅ r92 + **M2 canonical ABI 适配 ✅ r97**——M3 组件组合触发式维持（判据 = M2 交付 + 组件组合消费方[多组件系统需求]）。T3+ 触发族 14 行判定零变化（本轮开外源窗 #16 续窗第二例非 T3+ 行）。#15 讨论主线维持讨论先行持续（等 next17.md 或切换窗用户信号）。

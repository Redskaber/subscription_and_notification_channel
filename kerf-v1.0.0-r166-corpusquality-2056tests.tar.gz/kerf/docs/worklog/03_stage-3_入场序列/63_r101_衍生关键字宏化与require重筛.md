# rec 63 — r101 衍生关键字宏化 + require 重筛 + 文件层级域目录化轮

> **行权裁定**：用户三段式指令（M1 指令开窗第十例——「S表达式拓展宏补充完备实施衍生关键字」点名行权 = 需求信号本体[r74 先例]；宏化窗 = 外源实施窗——与 TD-032 续窗同形态，非触发表行）+ 治理窗（文件层级域目录化——用户点名 kerf-backend 平铺问题 + 全树类似问题审查）+ M1 形态第二窗（require 结合设计与知识搜索重筛）+ 例行监测（T3+ 六族 + OBS-C + CLI + next18.md）+ 版本问询（治理答问）。

## 一、行权裁定

- **任务① 文件层级整理**：用户点名「kerf-backend/ 下就不要将所有文件都平铺（wasm 就是自己治理的内容……根空间的治理理念在项目的物理逻辑上是相互印证对照的，请审查项目是否存在类似问题并修复）」——全树勘察裁定两处同类问题（backend wasm 四件 + native 两件平铺于根；driver 九桥平铺于根与 bootstrap/ 载荷目录分离），git mv 域目录化修复。
- **任务② 演进推进**：用户枚举九项（match 用户面消费 / net-extern-@ 族 / OBS-C / CLI 生产链健康 / check.krf / 现有 krf 自举内容审查和深化健壮 / S 表达式拓展宏补充完备实施衍生关键字 / 能力模型适配和关键字（require……）/ 版本？）——逐项裁定：触发族语言面项（match/net/@）零消费语料信号维持（指令枚举 ≠ 语料提交——r98 next17 同判）；可实施三件（宏化 / require 重筛 / 自举健壮审查）本窗行权。
- **任务③ 打包 web**：链 F 承载。

## 二、交付

- **171-a 文件层级域目录化**：kerf-backend `wasm/`（mod+abi+compose+emit）+ `native/`（qbe+aot+mod）+ kerf-driver `bootstrap/` 域统一（9 桥 + 10 载荷成对相邻）+ 全仓引用同步（外部消费方走 lib.rs 再导出零变更）+ 活文档面 R4 对齐三件 + .krf 头注释路径更新——**根空间治理理念物理印证**（24-space-decomposition：后端根 = 共享契约 + 共享 lowering；自治理目标域分居 wasm/native）。
- **171-b 例行监测 + 九项裁定 + 版本问询**：六族 grep 五零 + OBS-C 70.842/71.113/70.614ms（带内 46 轮）+ CLI 三路径零回归 + next18.md 未上传；**版本问询裁定**：S-expr 脚手架阶段不需要版本化 ✓（触发族 #2 = Stage 3+ 包管理窗维持——接口预留在位——问询即对照非开窗信号）。
- **171-c 衍生关键字宏化（M1 指令开窗第十例）**：七糖（when/unless/and/or/let\*/cond/while）迁移为真实 syntax-rules 宏——种子侧 `derived.rs`（DERIVED_SOURCES 单一 S 表达式源 + ValidateFn 形式校验器保负例消息契约 + `TransformerKind::Derived` 通道）+ krf 生产侧（lexp-init-derived 注入 + DERIVED-ENTRIES 注册基 + 'derived 变换器臂——七 desugar-\* 退役）+ 桥侧同源注入（模板 Span 与卫生两侧同源 = E1-β parity 与 B₀/B₁ 反汇编文本 parity 单源锚）+ **letrec 诚实边界**（nil 填充深度-1 不可表达——TD-005 族）+ **R7RS 复合省略号收集语义审查裁定回退**（Stage 0 编纂行为锁定——TD-005 族窗内义务登记）+ **append 先在缺陷清偿**（A 类基座：前参全空 + 末参 nil 伪序对崩溃级——宏模板空序列子列表拼接必经路径）。
- **171-d require 与能力关键字族重筛**：22 §26（v2.13）——四查询实证（tool-results/r101-search/）+ require/perform/handle/resume 四件全维持（r43 D25 零翻转）+ 撞名 P3 三重区分度注记增强 + resume 家族支系澄清（Koka/Eff/Unison vs OCaml continue）+ 语法形式与表达能力复核 + IoGrant = ocap unforgeable token 同构 + CAP-D 宏层糖路径机器支撑强化注记。
- **171-e krf 自举审查**：10 .krf + 10 桥零桩零静默零裸 unwrap——本轮健壮性深化 = append 崩溃级清偿 + 宏化双路径 + 1142 全绿。

## 三、核心裁定

| # | 裁定 | 依据 |
|---|---|---|
| 1 | 域目录化 = 根空间治理理念的物理印证（自治理域不散置 crate 根） | 24-space-decomposition 双侧统一 + 用户指令本体 |
| 2 | 七糖宏化双面同源 = E1-β parity 与 B₀/B₁ 反汇编文本 parity 的单源锚 | CoreExpr 级零漂移验收（全量套件 + 门 B 复绿） |
| 3 | letrec 维持内置（nil 填充边界）+ R7RS 复合省略号语义维持克隆-提交 | TD-005 族深度-1 边界 + parity_macro_compound_ellipsis 编纂行为锁定 |
| 4 | append 前参全空 + 末参非序对 → 末参原样返回（正典 improper 尾语义） | R7RS/Scheme append 语义 + 崩溃级实证（非序对堆槽） |
| 5 | require 四件全维持（重筛零翻转） | r43 D25 三判定重跑 + 2026 四查询证据（q1 WASI 同构强化） |
| 6 | 版本问询 → S-expr 脚手架阶段不需要版本化（维持待触发） | 触发族 #2 = Stage 3+ 包管理窗 + 22 §7 接口预留在位 |

## 四、演进位置

- **T3+ 14 行触发族判定零变化**（T3+ 触发面零行权维持——宏化窗为外源实施窗同族 TD-032 续窗）
- 推荐序前列：#15 需 next18.md（未上传）/ T3+ 14 行需消费信号——零信号维持态
- **TD-005 窗内义务新增一项**：复合省略号 R7RS 收集语义切换评审（窗开启时按加性变更义务——同步 krf 镜像 + 两 parity 锚更新）
- **1142 基线自 r101 起**（净 +1 = derived_sources_parse_cleanly）

## 五、对账链

matrix r101 行 + 总量行（1142/296+846）+ RELEASE r101 节 + 03-macro-system v6.5（能力边界——衍生关键字宏化 + 双诚实边界）+ 22-namespace v2.13（§26 重筛节）+ t3plus v1.21（r101 消费注记——M1 第十例 + 版本问询对照）+ 指南 v1.20（行权态十六次 + TD-005 窗内义务）+ README 测试计数同步（1141→1142）+ 本 rec + 层 l r101 条目。

**遵循**：§3.2（六命令 clean 起步）/ §8.4.5（裁定附条款号）/ §8.6（worklog 纪律 + rec 树）/ 红线 1/3（非时间驱动 + 零信号不开窗）/ 原则 12/17（可推迟决策配接口契约——版本问询合规实例）/ §13.4（重构治理——域目录化）/ §19.4（打包模板）

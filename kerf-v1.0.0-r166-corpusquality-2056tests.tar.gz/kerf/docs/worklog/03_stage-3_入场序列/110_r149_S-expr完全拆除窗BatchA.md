# r149 S-expr 完全拆除窗 Batch A（开窗 + 构建系统五面 .ktf 化）：种子链目标语言化首批

> Task ID: 219-a..219-f | Agent: Super Z (main) — PM-A/ARCH-A/DEV-A/QA-A/REC-A 复合
> 轮型: 实施窗开窗轮 + Batch A 首批同轮交付（1916 → 1948 净 +32——1948 基线自 r149 起）
> M1 指令开窗第五十四例（用户指令①S-expr 完全拆除时机授权——§8.3 按设计保留面的演进拆除开窗）

## A. 开窗判定（219-a）

- **用户四链指令**：①「在演进中是存在将 S 表达式完全拆除只使用最终目标语言表述的，如果演进节点和任务推进合适时机可完全拆除 S 表达式」（时机条件授权）②继续推进目标语言设计实现窗[遇缺陷/未完成窗按推荐顺序直接推进] ③按 sop.md 流程结合 lang-design 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 推荐序推进 ④同步完整打包 tar.gz + 同步完整更新 web page
- **时机六因子全过**：用户信号在位（指令①）✓ / 竞争任务零（登记册实施项全清零 + 门控七项全闭 + 14 行触发族零信号——t3plus v1.68 r148 消费注记）✓ / 方法论成熟（切换窗 r106-r120 转换纪律：规范化前置 → 皮肤机械映射 → 三路 parity 门 → fixpoint → E5 收口清理；皮肤字典 14 映射族齐备）✓ / 可行性审计全绿（§B）✓ / 基线稳定（1916:0:0 第一轮维持）✓ / 宪制授权完备（BS-A「VM 永久 Rust 基座」条款零触碰——仅修订「种子链 S-expr 形态保留」条款）✓
- **双确认**：ARCH-A GO + PM-A GO（Batch A 体量 678 行 ×5 桥同轮可承载——r125-r147 单轮 32 case 纪律先例）
- **设计单源**：s-expr-removal-plan.md v1.0（窗口载荷六对象 + 非拆除面裁定 + 开窗评审 + 可行性审计 + 分批计划{A 构建五面 ✅ r149 / B check.krf r150 / C target_reader.krf r151-r152 Reader fixpoint / D 用户面拆除 r153 / E6 终局清理 r154} + 门 X/Y/Z 体系 + 退出条件五项）

## B. 可行性审计（六面全绿——替换面图 §8.4 六族信号法种子域延拓）

| # | 审计面 | 实测 | 结果 |
|---|---|---|---|
| 1 | 下划线符号 | 七件 .krf 剔注释行 `rg '\b[a-zA-Z]\w*_\w+\b'` | 代码面全零（下划线全在注释——Rust 名引用）→ `_`→`-` 映射无歧义往返 |
| 2 | 准引用 | 代码行 `` rg '`' `` | 全零（target_reader.krf 仅 2 处字符串字面量内反引号装饰） |
| 3 | 真实效应用法 | `(perform|handle` 逐行核对 | 全零（命中 = 解析器关键字字符串 + 注释——target_reader 解析 handle/perform 语法 ≠ 使用效应） |
| 4 | bang 后缀名 | 代码行 `rg '\b\w+!\b'` | 全零 |
| 5 | 核心形式覆盖 | 形式普查（define 双形/fn/let/if/cond/and/or/not/do/assign/import/list/cons/quote/mod） | 皮肤字典全覆盖（compiler.ktf 头部映射单源 r114 纪律逐条在位） |
| 6 | 装载路径 | compile_front_seed_target（driver.rs r3284） | 在位生产验证（reader/compiler/expander/preamble.ktf 四件自 r110-r116 经此装载） |

**审计结论**：纯皮肤机械转换——零语言面前置缺口、零语义变更义务，与切换窗步③ 语料批（r109-r116）同型同判据。

## C. Batch A 实施（219-b/219-b2）

- **五件 .krf→.ktf 转写**：build.ktf（148 行）/ cli.ktf（75）/ test.ktf（157）/ test_runner.ktf（163）/ cache.ktf（135）。映射纪律：cond → if-else 右递归链（else-if 直通）；n 元 or → 显式右嵌套 `a || (b || (c || d))`（derived.rs 右递归展开同构——左结合链是不同形状）；`'sym` → `quote(sym)` 调用形；mod 保留调用形 `mod(n, 10)`（目标面关键字表口径——higher_order.ktf/expander.ktf 实证）；`(define NAME e)` → `define(NAME, e);` 调用形；kebab ↔ snake 符号引入边界映射；`()` = nil 实参位；let + 尾值块线程（parse_block 包裹余项——与 .krf let 形逐位同构）
- **五桥种子路径切换**：bootstrap/{build,cli,test,test_runner,cache}.rs——include_str! 文件名 + FILENAME 常量 + compile_front_seed → compile_front_seed_target + 诊断文案 .krf→.ktf 同步；桥入口符号查询零变更（命名映射保证 .ktf 标识符 intern 出与 .krf 相同的种子符号——lbld_is_imports_prelude → lbld-is-imports-prelude 等）；cache.rs 单测 handoff S-expr 源保持 compile_front_seed（测试机器面——Batch D 域）
- **平行件策略**：五件 .krf 原件保留（KRF_SOURCES 守卫维持七件——窗口期门 X 基线腿，E6 收口批按原则 41 判据删除）
- **门 X 新测试族** seed_ktf_parity_tests 32 case（8 正 + 24 负 1:3）：载荷字节码 parity ×5{跨文本解析口径——Symbol 句柄经属主表名解析 + 编译器哨兵容错{main proto 名 Symbol(u32::MAX-1)}；指令序/常量池[解析]/proto 形状[名字解析——proto 名 = 首参元数据 compile.rs params.first 口径]/全局引用面[解析]全等；debug_spans 跨文本按设计豁免} + 入口与全局消费面{常量池 Global 承载五桥入口符号 + global_refs 承载内建消费面} + 命名映射回环{五入口标识符 + 12 内部名 + 恒等面} + 跨阶段双面 E2E{prelude 导入程序双用户面同值 (2 3 4)——传递消费 build.ktf[prelude 注入决策] + cache.ktf[缓存咨询] + target_reader.krf[生产读桥]} + 负向 24 族{词法 3[未闭合字符串/块注释/坏转义] + 文法 8[缺花括号/缺圆括号/参数缺类型注/块内语句缺分号/裸 else/fn 缺名/调用缺逗号/import 尾逗号] + 位置 2[块内 import/require] + 域外 2[裸 mut 语句/向量尾逗号] + 声明 2[define 坏元数/重复定义] + 能力 1[E0006 print 无 require] + 未绑定 2[E0022 裸引用 + 映射名 string-append] + HM 2[类型失配/内建元数] + 运行期 1[head 非序对] + 深度帽 1[双面 parity]}
- **门 Y 既有桥级 parity 全族零变更全绿**：build_krf_parity 14 + cache/cli/test/test_runner 四族 65 case——生产决策经桥端到端零行为漂移实证（.ktf 载荷装载后全部断言面原样通过）

## D. 同窗缺陷清偿：目标 Reader 深度帽（§20.3 同类路径全量审查发现——用户指令②「遇缺陷直接推进」臂命中）

- **发现**：负例 #24 起草时实测——target.rs 缺失 principle-58 MAX_NESTING_DEPTH=256 守卫（S-expr 面 parser.rs 有帽、目标面无帽）：400 层嵌套 .ktf 源经生产路径运行成功（value int）而非拒收；种子路径（Rust 递归下降）无帽 → 更深层输入将栈溢出崩溃而非 fail-closed
- **清偿**：TARGET_MAX_NESTING_DEPTH = 256 新守卫（与 S-expr 面同帽同消息族「nesting depth exceeds the limit 256」）——四递归族根守卫点：parse_expr{表达式族：括号/调用实参/操作数嵌套循环} + parse_block{块族：if 臂/else-if 链/match 臂/handle 臂/嵌套块} + consume_type{类型语法族：泛型参数嵌套} + parse_pattern_or{宏模式族：嵌套模式列表}；depth_enter 辅助（递增-检查-回退 + Ok/Err 对称递减）
- **边界裁定**：生产读路径（run_source_target → target_reader.krf @ VM）不入新帽保护面——VM 自举 Reader 为迭代蹦床 + 堆分配帧栈 + 帧数帽（TD-023 自有防线）；新帽保护面 = 种子路径（compile_front_seed_target 载荷装载 + oracle）
- **负例锚**：#24 双面 parity——同一深嵌套构造（目标面 400 层调用嵌套 / S-expr 面同形 datum 嵌套）双 Reader 同族消息拒收

## E. GATE 1（219-c——六命令 clean 起步全绿实测）

- cargo clean → cargo build --release：23.05s 零告警
- cargo check --workspace --all-targets --release：0 error / 0 warning
- cargo fmt --check：零 diff（build.rs 一处长行顺修）
- cargo clippy --all-targets --release -- -D warnings：0
- cargo test --release --workspace：**1948:0:0 净 +32**（RUST_MIN_STACK=16777216——1948 基线自 r149 起）
- 审计×6 真实 EXIT 0 ×6（280 case：stage0/stage1/stage2_r1/stage2_r2/stage3_e5close/stage3_m3）
- CLI 双语法面零回归：fib ⇒75025/144 双面 + ffi_alias ⇒9 双面 + nested ⇒540 + multiarm ⇒217 + handle_expr ⇒327 + closures ⇒42 + vector ⇒9 + stress ⇒120 + check fib 2/9/5/38 + check ffi_alias 1/2/0/5 + test 2/2
- bench：76.612ms 带内（OBS-C <65ms 触发线不满足维持——零信号）

## F. 治理对账（219-d——九件全落）

matrix r149 增量行 + 总量行 1948 / RELEASE r149 节 / README 三处（质量状态行 + 门禁表测试计数行 + 打包交付行）/ t3plus-trigger-audit v1.69（r149 消费注记——14 行触发族判定零变化{本窗非 T3+ 行}) / 07-bootstrap-strategy v7.3（构建系统段 .ktf 化注记——五面生产装载路径切换）/ 12-roadmap v6.31（§2.19 拆除时点对账——Batch A 兑现锚）/ 20-surface-conventions v1.32（§14 种子域行——五载荷目标语言化）/ 替换面图 §8.3 注记（前两行转入拆除进程中——用户指令①演进授权）/ rec 110（本件）/ 根层 l r149 条 / worklog 三链

## G. 收口（219-e/219-f）

r149 包三验（kerf-v1.0.0-r149-sexprremovala-1948tests.tar.gz——git archive 单源 + 独立解包净构建 + 包内 1948 复跑 + e5close EXIT 0 + 生产面实证）+ download 入位（旧包清理——最新 + 上一包策略）+ web 五件（kerf-data 三处 + hero 三处 + footer v7.92 + download README r149 节）+ Agent Browser E2E + lint 0 + §6.3 投票 5.5/5.5 = 100% GO

---

**Stage Summary**：S-expr 完全拆除窗 Batch A 全链闭环（开窗 → 可行性审计 → 五件转写 + 五桥切换 + 平行件保留 → 门 X 32 case + 门 Y 零回归 → 同窗深度帽缺陷清偿 → GATE 1 → 治理 → 交付）；**1948 基线自 r149 起**；替换面图 §8.3 前两行转入拆除进程中（BS-A「VM 永久 Rust 基座」零触碰）；8 原语不变性第三十一轮（纯皮肤/载荷形态切换）；14 行触发族判定零变化；遗留债务：无新增（.krf 平行件 = 窗口期 oracle 策略性保留——E6 收口批按原则 41 判据删除）；下一演进 = **Batch B：check.krf → check.ktf（HM 引擎 1285 行——r150；体量先例 r114 compiler.ktf 1404 行单轮）**

*遵循条款：用户 r149 指令①②③④（开窗驱动源）/ §1.2（路由——L3 实施窗）/ §2.3 红线 3/4（用户信号开窗 + 分步验收）/ 原则 6（三门复用）/ 原则 9（核心冻结——零机制变更）/ 原则 31（皮肤/骨架同构——门 X 判据）/ 原则 41（脚手架拆除——平行件 + 逐个替换 + 拆除判据）/ 原则 26（成熟度匹配——体量升序批结构）/ 原则 58（同形树递归处理纪律——深度帽清偿依据）/ §3.1（环境自助第八次——PATH 恢复）/ §3.2（六命令）/ §5.3（八项内循环）/ §7.3（门审族零变更全绿）/ §8.4.5/§8.4.6（裁定附条款 + 产物落位）/ §8.6（worklog 三链）/ §9.4.3（1:3 配比）/ §19（打包三验）/ §20.3（同类路径全量审查——深度帽发现）/ §20.6（诚实验收）。*

# r144 read-line 签名条目窗（静态-动态元数 parity 补全 + R4 审计链文档债清偿）

> **Task ID**: 214-a..214-f　**Agent**: Super Z (main) — PM-A/ARCH-A/DEV-A/QA-A/REC-A 复合
> **Date**: 2026-11-14　**类型**: 登记域外行清偿实施窗 + 同窗 R4 文档债四件清偿（净 +32——**1884 基线自 r144 起**）　**驱动**: 用户三链指令（实现窗推进[遇缺陷直接推进] + 按推荐序推进 + 打包/web）——**M1 指令开窗第四十九例**

## 交付链

- **214-a 走查 + 探针实测**：r143 态核验{第十二轮会话首检零回退} + 六族例行监测复测零信号 + 全部登记域外表走查 → 三类不可行排除{Stage 2+ 域外 / 成熟度不在位 / 纯语料信号零张力} → **唯一可行行 = tc-sigs §7「read-line 签名条目」行**——且**触发前提事实性过时实测发现**{运行时元数执法自 FS-4 起即在位——代码 fail-closed + 09-stdlib §3 r8 注记 + 20 §4 B3 契约三源确证——r140-r143 四轮走查以过时注释为据排除本行 = 审计链 R4 文档债} + R4 文档-代码冲突四件实证 + 张力探针{`(read-line 1)` 静态静默通过 vs 运行时 E0004 fail-closed + read-int 对照 E0005 正典形 + 改名 rl(1) 静默}。
- **214-b 设计**：read-line-sig-design.md v1.0{D1-D8 + §7 域外四行——窗口定性/双侧签名行[read-int/read-num 家族形锁步]/结果 Unknown 裁定[Str∪Nil 并集域——8 kind 冻结无 union，r142 member D3 先例]/邻位维持/派生链影响[miss-skip 零在世 miss 防御性路径保留]/计数 parity/锚翻转预算/32 case 矩阵}。
- **214-c 实施**：builtins.rs BUILTIN_SIGS read-line 行{fixed(&[], Unknown)} + 表尾/r42 注记改写 + builtin_name_exists 特例移除{扁平名 62 单源} + builtin_sigs/builtin_sigs_with_renames 注释前提清偿 + check.krf TC-SIGS read-line 行 + tc-infer-app/tc-sig-resolve 注释清偿 + negative_vm_tests 模块注释 R4 修正 + neg_r135_hm_read_family_a4_carryover 前提翻转{断言维持} + ktf_tc_sigs_parity 头注 61→62 + **ktf_read_line_sig_tests 32 case 新门**{8正+24负 1:3}——纯静态签名面零机制变更。
- **214-d GATE 1**：六命令全绿{build 零告警 + check 0:0 + fmt 零 diff{顺修} + clippy -D warnings 0{三顺修} + **test 1884:0:0 净 +32**} + 审计×6 EXIT 0{280 case} + CLI 双语法面零回归{十路径} + bench fib VM 计算 74.5ms 带内{启动基线 38.6ms 剥离}。
- **214-e 治理**：tc-sigs v1.3{§7 read-line 行翻转} + member-rename v1.4{§7 io read 族行翻转——全族覆盖} + 09-stdlib io 行 r144 注记 + RELEASE r144 节 + README 三处 + matrix r144 行/总量 1884 + t3plus v1.64 + guide v1.29{M1 第四十九例——行权态二十九次} + rec 105 + worklog 三链。
- **214-f 收口**：r144 包三验 + web 五件 + E2E + 投票。

## 语义要点

- **触发前提过时裁定（D1）**：运行时元数执法自 FS-4 起即在位（r141 b1730b5 统一消息形重锚）——四轮走查以 builtins.rs 过时表尾注释为据排除本行 = 审计读注释未读代码的 R4 文档债；三源确证后行权清偿。
- **结果位 Unknown（D3）**：命中 Str ∪ EOF Nil 并集域——8 kind 冻结无 union 构造，read-int/read-num 家族先例（Int∪Nil 同构并集）+ r80 零误报契约三依据。
- **层正交（原则 42）**：静态 E0005「expected 0..0, got N (static check)」与运行时 E0004「read-line requires 0 arguments, got N」双层各自正典形非镜像义务——运行时面逐字节不动。
- **派生链收紧（D5）**：r135 改名链（read-line as rl → TC-RENAME → TC-SIGS 命中）+ oracle 限定名派生（io/read-line）自动收紧；miss-skip 成零在世实例防御性路径{保留裁定——确定性边界}。
- **8 原语不变性第二十六轮**：零新原语零通道零新操作码零 CoreExpr/IR 变体零 VM 分派变更——纯静态签名面。

## 验收

- 测试 **1884:0:0**（单元 299 + 集成 1585——净 +32）；审计×6 EXIT 0；CLI 十路径零回归；bench 带内；语料锚零翻转七件{expander 5 / compiler 1 / reader 0 / check 2 / build 0 / cli 0 / fib 0}。
- 演进位置：Stage 3 入场序列 r144；tc-sigs §7 read-line 行清偿关闭{余二行触发式：值位 Callable Stage 2+ / is-procedure Stage 2+}；触发族 14 行判定零变化。

# r142 member/assoc 静态面双缺陷窗（'any 短路臂 + Bool→Unknown 宽化）

> **Task ID**: 212-a..212-f　**Agent**: Super Z (main) — PM-A/ARCH-A/DEV-A/QA-A/REC-A 复合
> **Date**: 2026-11-12　**类型**: 登记域外行清偿实施窗 + 同窗双缺陷当场清偿（净 +32——**1820 基线自 r142 起**）　**驱动**: 用户三链指令（实现窗推进[遇缺陷直接推进] + 按推荐序推进 + 打包/web）——**M1 指令开窗第四十七例**

## 交付链

- **212-a 走查 + 张力实测**：六族信号零 + 域外表走查 → tc-sigs §7 member/assoc 复审行（独立评估面）张力探针 → **双缺陷实测成立**{'any 兜底误报 + `(head (member 2 lst))` E0005 假阳性[运行时 ⇒ 2 正确] + 运行时严格 bool if 纪律 E0004 发现}。
- **212-b 设计**：member-any-bool-model-design.md v1.0{D1-D8 + §7 域外四行}。
- **212-c 实施**：tc-rule-one 'any 短路臂{单臂双收} + TC-SIGS member 'bool→'unknown + BUILTIN_SIGS member TcType::Bool→Unknown{双侧锁步}——三处最小变更零机制变更。
- **212-c 测试**：ktf_member_any_model_tests 32 case{8正+24负 1:3——精确计数断言形态}。
- **212-d GATE 1**：1820:0:0 净 +32 + 审计×6 EXIT 0 + CLI 双语法面零回归 + bench 72.595ms 带内。
- **212-e 治理**：tc-sigs v1.2 行翻转 + audit v1.62 + guide v1.27 + RELEASE + README 三处 + **rec 100/101/102/103 四件补债{R4——三轮 rec 未落盘当轮修正}** + worklog 三链。
- **212-f 收口**：r142 包三验 + web 五件 + E2E + 投票。

## 语义要点

- **缺陷①（P1——r140 移植偏差）**：'sigf 'any 位兜底误报 + tvar unify 伪 tcon('any) **污染跨用位传播**（stash-built 修复前对照：r140 三语料重锚 11 项中 5 项实为污染伪产物——`?` 渲染 = 伪 kind 本体）。
- **缺陷②（P1——TD-030 E0005 假阳性族）**：member Bool 谓词化建模值消费假阳性——D3 宽化四依据{r80 零误报契约 + assoc 对齐 + B2 净化先例 + 8 kind 冻结下唯一零误报复现}；谓词位静态零变化 + 运行时严格 bool if 纪律维持 + 正典谓词形态 = is-pair 包裹。
- **语料锚翻转三处**：expander 6→5 / compiler 2→1 / reader 3→0{真检出全维持}。
- **8 原语不变性第二十四轮**：纯静态签名面零新原语零通道。

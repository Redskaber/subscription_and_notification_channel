# r133 嵌套块内 resume 窗（rec 94）

> 03 层第 94 件 · Task 203-x · 2026-11-07 · e+s+p · active
> 注：r132 多臂窗全录见 docs/worklog.md 202-a..202-f（本槽位跳过单文件形态——r133 起恢复逐窗 rec 文件）

## 全链（203-a..203-f）

- **203-a/203-b 恢复轮**：z.ai web 保存机制第六次回退（kerf 树回退 r113 / git HEAD 2896f7a / 477 文件纯模式位噪声）→ r132 tarball 单源解包替换（保 .git + diff -rq 归零）+ git 恢复笔 93b3680 + Rust 1.98.1 第六次重装 + GATE 1 复验 1526:0:0 逐位 + 审计×6 + CLI 零回归。
- **203-b2 路由**：三源推荐序裁定 = 嵌套块内 resume（成熟度匹配排序首位——r131 三部曲检验全过）+ 双侧探针实证（S-expr 面 ⇒101/⇒11 合法 vs 目标面 E0001 fail-closed）。
- **203-c 实施**：设计单源 nested-resume-design.md v1.0（D1-D10）+ 种子 handler_k 字段 save/restore 穿线 + 镜像 kcell 闭包胞穿线 + 语料对 effect_nested_resume.{ktf,krf}（⇒540 双面）+ ktf_nested_resume_tests 32 case（8 正 + 24 负 1:3——含嵌套等价字节码全等门）。
- **同窗 VM P1 清偿（isoB）**：深帧非尾 resume 陈旧 H 执行帧残留——续体恢复 RET 级联重入臂体致槽位污染（「不可调用的值：int」）→ ContinuationValue.boundary 边界截断（Call/TailCall 双臂）——三变量隔离定位（isoA/isoB/isoC/isoD）。
- **203-d GATE 1**：六命令 clean 起步全绿（build 17.85s 零告警 + check 0/0 + fmt 0 diff + clippy --all-targets -D warnings 0 + test **1558:0:0 净 +32**）+ 审计×6 EXIT 0 + CLI 八路径零回归 + bench 70.031ms 带内。
- **203-e/203-f**：治理对账 + r133 包三验 + web 五件 + E2E + 投票。

## 交付要点

- **嵌套块内 resume 全开放**（r128 域外登记清偿）：if 臂块/闭包体/嵌套 handle 臂体语句位/尾位——innermost 臂 κ 注入（S-expr 词法作用域镜像）；表达式位维持域外（D6）+ 受护式 κ=nil（D5）+ 跨臂显式续体收窄（D7）+ halt/pass 直位形维持（D8）。
- **02 v7.18 + 20 v1.25**（域外注记翻转 + D2 体域扩展注记）。
- **1558 基线自 r133 起**。

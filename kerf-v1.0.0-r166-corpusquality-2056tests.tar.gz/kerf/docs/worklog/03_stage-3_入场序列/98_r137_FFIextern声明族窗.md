# r137 TD-026 行① FFI extern 声明族语言面窗（恢复 + 实施 + 收口全链）

> **Task ID**: 207-a..207-f　**Agent**: Super Z (main) — PM-A/ARCH-A/DEV-A/QA-A/REC-A 复合
> **Date**: 2026-11-09　**类型**: 恢复轮 + TD-026 行① 部分清偿实施窗（语言面 + 净 +32——**1687 基线自 r137 起**）
> **驱动**: 用户三链指令——①以 r136 tarball 替换回退态 + 继续推进 目标语言设计的实现窗[遇缺陷/未完成窗口则按推荐顺序直接推进进入对应窗口开始具体实施] ②按 docs/sop.md 流程结合 lang-design 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page——**M1 指令开窗第四十二例**

## 恢复轮实录（207-a/207-a2——第九次 z.ai web 回退）

- 环境回退形态：rustc 丢失级（RUSTC MISSING——工具链在位检测失败）+ 树态回退至 r135 git HEAD 1122094{首 r135 实施态};根层 worklog 止于 205{r135}、tarball docs/worklog.md 完整至 206{r136}——权威源裁定 = 上传 tarball（upload/kerf-v1.0.0-r136-groupinstall-1655tests.tar.gz——660 成员/12,514,982 字节）。
- 恢复四件：rsync -a --delete --exclude=.git 单源替换{diff -rq 归零实证} + git 恢复笔 d8cab0b{49 文件 r135-superseded→r136 增量——含 TD-033 全链 + r135 重构态{hm-sig 测试并入 member_rename 64 case + 双参协议}} + Rust 1.98.1 第九次重装{scripts/rust/setup.sh} + GATE 1 基线复验 1655:0:0 逐位 + 审计×6 EXIT 0 + CLI 双语法面零回归 + r136 语义三探针{组分派 ⇒ 15 + 同胞非保护 ⇒ 207 + 组消费 ⇒ 145}。
- 治理修复三件：根层 worklog 206 条目断链承接{docs/worklog.md 权威源补录} + TC-SIGS 子集不对称重登记{member-rename-design §7 新增行——check.krf 23 条 ⊂ oracle 56 条；原登记随 superseded 设计单源失载} + 触发指南 v1.22 R4 顺修{§2.2 行 15 + §4 速查卡【第 1 位】陈旧态回写——切换窗 r120 已全闭 + next18-21 已吸收}。
- 恢复轮实测：核心名改名{use kerf_pair::{head as h}}双面实证通过{run ⇒ 1 + check ok}——r135 首实施态 E0022 边界已随 N1 派生段清偿，旧登记不复活{R4 代码为准}。

## 推荐序裁定（PHASE 1 路由）

r136 后登记册触发式实施项全清零{TD-033 r136 清偿} + 六族语料信号实测全零{表达式位 handle / 块体 halt-pass / 裸臂 / resume 多参 / extern / @ 全零命中} → 推荐序落到 T3+ 14 行手动臂中与「目标语言设计实现窗」需求语义唯一匹配项 = **TD-026 行①**{登记册「语言面语法/extern 声明形式 = Stage 3 锚」明文行 + 手动触发臂「开启 TD-026 窗——实施 FFI 语言面形式」+ r74/r99 先例锚指令即需求信号本体}；成熟度匹配 = VM 面机制基座 r30 全在位{三操作码 #43-45 + ExternSymbolTable + 窗口协议 + Φ 簿 + E0010-E0012} + P1 冻结形状在位 + ffi-ownership-model v0.1.0 行为规格冻结。

## 交付链（207-b..207-f）

- **207-b 设计单源**：ffi-language-surface-design.md v1.0{D1-D10 + §7 域外表七行——CStruct/CFunction 编组、Alloc/Free 语言形、测试运行器切分、模块体位、HM 签名执法、kind 扩词、别名接驳均触发式登记}。
- **207-c 实施双侧全链**：Keyword::Extern{第 28 名} + 种子 parse_extern_decl + 镜像 parse-extern-decl 族六函数 + 驱动面 collect_extern_face 五重校验 + 位置纪律双层{.ktf 读者层 E0001 / .krf Stx 层 E0026} + 能力门{E0006——write-stdio 与 io 语言通道同享授权令牌} + 剥离扩展{expander 零变更——kerf-core 零代码} + 分辨层 IrVar::Extern{Rc<str> 名串 + 卫生不可穿透 + 捕获分析跳过} + 编译臂双侧{compile.rs + compiler.ktf EXTERN_TAG/compile_ffi_args——#43 冻结四方同步维持} + 值位/赋值位 fail-closed + 桥双参协议{r135 先例} + 在册可注册表 AVAILABLE_EXTERNS{write-stdio 唯一} + run_front 表构造{空表 = 历史行为逐位不变}。
- **实施缺陷当轮清偿**：lexer 反向映射缺 KwExtern 臂{tk_debug_round_trip 拦截} + 词典正典名 write_stdout → write-stdio{Reader 符号引入边界归一} + compiler.ktf quote(extern) 关键字位{EXTERN_TAG = string-to-symbol 铸——r116 第二规范化先例} + 字符串拼接 + → string_append{HM 锚计数漂移 3→1 复位} + 镜像 extern-arrow 参数数 + 零参 kind 表 Unit 双关{双侧 parse_typed_params 先例同构}。
- **207-d GATE 1**：六命令 clean 起步全绿{build 20.26s 零告警 + check 0/0 + fmt 0 diff + clippy --all-targets -D warnings 0{三处顺修} + **test 1687:0:0 净 +32**} + 审计×6 EXIT 0 ×6 + CLI 双语法面零回归 + 新能力 CLI 生产面实证{ffi.ktf/ffi.krf ⇒ 9 双面 + check ok 0 全局引用} + bench 129-131ms 带内{OBS-C 不满足维持}。
- **207-e 治理对账**：TD-026 行① 部分清偿{登记册 v0.4.16} + t3plus v1.57 + RELEASE r137 节 + matrix r137 增量行/总量行 1687 + 02 v7.21{extern_decl 产生式} + 20 v1.28{皮肤字典第十三映射族} + README 三处 + rec 98 + worklog 三链。
- **207-f 收口**：r137 包三验{git archive 单源} + download README r137 节 + web 五件 + Agent Browser E2E + §6.3 投票。

## 语义要点

- **扁平符号空间（ffi-ownership-model §4）**：extern 名 Symbol 名字匹配解析（词法帧后 global 兑底前）——宏卫生不可穿透 + 顶层撞名编译期拒绝 + 值位 fail-closed{E0026「仅调用位」——无 extern 函数值}。
- **能力门（r65/118-a）**：write-stdio 经 io write 能力令牌门——首个 FFI 通道能力执法实例{FFI 写通道与 io 语言通道同享授权令牌}。
- **8 原语不变性第十九轮**：零新原语零通道零新操作码{#43 r30 冻结四方同步维持}；CoreExpr/ModuleItem 零新变体——比 r136 更轻{无内核形态增量}。
- **既有程序零回归（原则 27）**：零 extern 声明 → 空表 + 零分辨面变化 + 零发射变化——1655 基线逐位不变。

**1655 → 1687（净 +32）**——ktf_extern_decl_tests 新文件 32 case（8 正 + 24 负 = 1:3）；**1687 基线自 r137 起**；14 行触发族判定零变化；**TD-026 行① 部分清偿——登记册触发式实施项维持全清零**{行②③④触发式}；下一演进 = 触发式零信号维持或自然信号——按用户指令序或自然信号。

**§6.3 外循环投票（r137 收口）**：ARCH-A（2）✅ GO + DEV-A（1.5）✅ GO + QA-A（1）✅ GO + ALG-C（1）✅ GO——加权通过率 5.5/5.5 = 100% GO——TD-026 行① FFI extern 声明族语言面窗全闭（M1 指令开窗第四十二例）

# rec 86 —— r124 match 实施批 M-4：.krf 镜像同步（双 Reader 分歧窗闭窗 · match 实施窗全闭）

**Task ID**：194-a..194-d　**日期**：2026-11-03　**角色**：Super Z (main)——ARCH-A（裁定）+ IMPL-A（实施）+ QA-A（验收）+ REC-A（对账）

**驱动**：用户三链指令（①继续推进目标语言设计实现窗[遇缺陷按推荐顺序直接推进] ②按 sop.md 流程 + lang-design 演进流程 + tech-debt-register + t3plus-trigger-audit 推荐序推进 ③完整打包 tar.gz + 完整更新 web page）——M1 指令开窗第二十九例；r123 收口笔推荐序首位兑现（match 实施批 M-4 = match-design v1.3 §6 批路径 M-3 后推荐序首位；三源一致：match-design v1.3 Status「M-4 .krf 镜像同步 = 下一批推荐首位」/ t3plus v1.43 下一演进 / 193-d 收口笔）。

**交付**：

1. **194-a 实施**——match §6 批表 M-4 行字面兑现（.krf 镜像同步——步② 语法批合并承载；依赖 M-1 ✅ + 步② ✅ 双满足）：
   - **镜像侧 match 语法臂七函数族**（`bootstrap/target_reader.krf` ~215 行——种子 r121 parse_match 家族逐函数同构移植）：parse-match（scrutinee = 完整 parse-expr + 臂循环[尾逗号可省 + 臂间逗号强制 + 零臂 fail-closed「match 表达式至少需要一臂」]）+ match-arms-loop（逆序臂累积 + 期望 } 错误形态 = 种子未闭合同构）+ match-arm/match-arm-guard/match-arm-arrow（「先 atom 后判分隔符」三分支算法镜像——pattern 后逗号 = or/序对混用专项诊断；守卫 if 可选 + 臂节点 (pattern [guard] body) 跨度合并）+ parse-pattern-or/pattern-or-loop（or 标记表——单原子裸返 + or 符号跨度 = 首 Token 锚）+ parse-pattern-atom（字面量五族[int/float/str/true/false] + unit nil 皮肤 + ident 绑定 + `_` 经桥 target_symbol_name 恒等 + path 域外 fail-closed[22 §27] + 括号三分支[二元拆构/分组 or 链/分组恒等] + 深度帽 8[>8 fail-closed——防御性栈保护]）+ pattern-group-or-loop（括内 or 链——逗号混用 fail-closed + 闭括号跨度合并）。
   - **语句位分派翻转**：parse-stmt-or-expr 的 match 臂从 domain-out「match 语句（模式匹配设计文档——T3+ #5）」退役 → parse-match（M-1 种子侧位改判的镜像侧兑现）。
   - **表达式位臂**：parse-primary 增 match 分派（r110 表达式位 if 先例同构——语句位与表达式位同形[match-design §2 EBNF 注释字面]）。
   - **分歧窗锚点翻转**（match_m1_reader_tests.rs match_krf_mirror_divergence_window_anchor）：镜像侧从「域外诊断断言」翻转为「字节级同渲染断言」——`(define (f x) (match x (0 1) (_ 2)))` 双侧全等；**双 Reader 分歧窗 M-1..M-3 正式闭窗**。
   - **match_m4_krf_mirror_tests 15 case 新门族**（tests/v0/stage3/plan/——runner.rs 挂载）：①语法 parity 正向两族{r121 全语料族[基础/守卫/模式全族/or 标记/嵌套序对/命名映射/尾逗号/跨行/深度 8] + 位置形六面[语句位 do 穿线/块尾/let 右值/顶层/scrutinee 复合/primary 位二元右元]——Stx 正典渲染含 Span 字节级镜像} ②负向十一族{零臂/三元模式/裸 or 混逗号/括内 or 混逗号/右元 or/限定名/缺 =>/未闭合/非模式 Token/缺臂分隔/深度帽 9×2——消息 + Span 字节级镜像} ③词法 parity 维持{match 语料三族 kind/Span/payload 字节级——词法层零触碰实证} ④跨阶段消费{镜像 Reader → 自举 Expander[M-2 expand_match 脱糖] → 自举 Compiler → VM 全链 E2E ⇒ 161[守卫/or/序对拆构/守卫复合 + 复执行确定性]}。正负比 3:12 ≥ 1:3 合规。
   - **治理文档**：match-design.md v1.4（Date/Version/Status 头 + §3.0 分歧窗登记完成化「已消除」 + §6 批表 M-4 ✅ r124 行）+ target_reader_krf_tests.rs domain-out 注记更新（M-4 同步完成化）。
   - **开发实录（诚实登记）**：①镜像 .krf 括号平衡两处（match-arms-loop cond 子句 1 少一闭括——后续 define 被吞入函数体触发 E0002「define 必须位于函数体头部」当轮定位；parse-pattern-atom 终行多一闭括——python 栈模拟审计定形；r122 期「嵌套 match 括号平衡三轮」同族——S-expr 手写形态固有风险面）②E2E 语料 pair 类型注记修正（`(p: (i64, i64))` 非目标面类型域——期望 ) 实际 Comma 拒；改 cons(a, b) 运行时构造形——m2 运行时语义先例对齐）③fmt 六处顺修后归零（新测试文件 import 序 + 断言折行——rustfmt 标准形态）。

2. **194-b GATE 1**：六命令 clean 起步全绿——cargo clean（747 files/201.0MiB）→ build --release **19.41s 零告警** / check --workspace --all-targets 0 errors 0 warnings / fmt --all --check 0 diff（顺修后归零）/ clippy --workspace --release --all-targets -D warnings 0 errors / **test --release --workspace 1300:0:0**（净 +15 = match_m4_krf_mirror_tests 15 case；RUST_MIN_STACK=16777216）+ 审计×6 280 case 真实 EXIT 0 ×6（m3「窗 M 出口条件达成」/e5close「E5 出口三条件全绿——S4 收口 GO」结论行复核）+ CLI 八路径零回归（fib ⇒75025/⇒144 + check ok：2 原型/9 常量/5 全局引用/38 指令 + effect_stress ⇒120 + higher_order ⇒(1 4 9 16 25) + closures ⇒(4 2)/⇒42 + macros ⇒(2 1)/⇒42 + test PASS 2/2 + match ⇒ fib-13 维持）+ 例行监测（match 用户面 10 = match.krf 消费语料维持 / match .ktf 语料命中全为标识符与注释非语言面{compiler.ktf match_bindings + expander.ktf match_* 函数族 + KEYWORDS 列表} / extern/@/vector #( 语言面 0 / `->` .ktf 零 / syntax-parse = TD-005 注记本体[r72 起 49 轮一致]）+ OBS-C bench fib 三轮 70.982/71.384/70.478ms（r55→r124 带内——<65ms 触发线不满足维持）。

3. **194-c 治理**：t3plus v1.44（Date 行 r124 消费注记 + Version 头 v1.44 段——14 行判定零变化 + 1300 净 +15 + match 实施窗全闭 + 下一演进 = CLI 双入口或 HM 深化或触发式零信号维持）+ RELEASE r124 节 + matrix r124 增量行 + rec 86（本件）+ 根层 l r124 条目 + README 两处 + match-design v1.4。

4. **194-d 收口**：r124 包三验 + download README r124 节 + web 完整更新 + E2E + §6.3 投票。

**演进位置**：**match 实施窗全闭 ✅**（match-design.md v1.4 §6 批路径：M-1 ✅ r121 → M-2 ✅ r122 → M-3 ✅ r123 → **M-4 ✅ r124**——语法/语义/诊断三义务面全兑现 + 双 Reader 分歧窗闭窗）；**1300 基线自 r124 起**；14 行触发族判定零变化（match 行维持 r122 翻转态——消费语料 match.krf 十面命中维持）；后续 match 相关演进均触发式登记态（类型驱动穷尽[原则 26 Stage 2+]/结构化模式[类型声明族独立窗]/向量字面量模式[TD-002 三判据联动]——零信号不开窗）；下一演进 = CLI 双入口形态（P3 候选）或 HM 深化或触发式家族零信号维持——按用户指令序或自然信号。

**遵循条款**：match-design.md v1.3 §6（M-4 批表行字面 + 红线 4 零窗口合并——M-4 独立可验收）/ 原则 31（皮肤/骨架同构——语法臂双侧同构 + 零新原语零通道零 VM 零词法变更）/ 原则 43（渐进披露——M-1..M-4 分批完成）/ 原则 42（诊断正交维持——镜像侧 fail-closed 消息面 = 种子单源）/ r108 语法批先例（.krf 语法器扩展模式——错误双形态[rderr 定长 + rderr-tok Token 内嵌] + 桥 target_err_form 通道复用）/ r110 表达式位 if 先例（primary 位分派同构）/ §8.4.5（设计依据条款号）/ §8.4.6 + §9.1（产物位置——tests/v0/stage3/plan/ + 治理文档族）/ §9.4.3（正负比 3:12 ≥ 1:3）/ §10.5（注释语言标准——新注释全英文）/ §3.2（六命令验收）/ GATE 1（实际运行全绿）/ §7.3.1 规则 3（审计可重跑）/ §20.6（诚实验收——开发实录三则）/ GATE 3（裁定条款号全录）。

# r48 de Bruijn IR 臂：IndexIR 解析闭包层（Task 69-a/69-b/69-z/69-web）

> 一行：M-I 索引化实施（IndexIR 实化 + 解析单通道 + 发射零解析 + compiler.krf 零变更 + fixpoint 零漂移）+ D56-D58 三裁定（三面镜像纪律 + 排期重锚）——859:0:0 净 +5 + 五审计集 EXIT 0 ×5 + 包内自举一致。

## 交付零（实施合同——22 §16 D56-D58）
- **IndexIR 实化**：`kerf-compiler/src/ir.rs`——CoreExpr（命名制[E3 ① 永久保持]）→ `IrExpr`（12 变体同词根 + 解析产物内嵌：`IrVar::Local/Captured/Global` 槽级词法寻址[de Bruijn level 线性化] + `IrProto{params[arity 语义], captures[显式环境], free_vars, body}` + `Let{slot, bind}`）→ 字节码（发射零解析——compile.rs 纯发射域重写：emit_ir/emit_fn/emit_inner_proto/emit_handle）
- **解析单通道**：Binding/ScopeFrame/match_bindings/resolve_var 自 compile.rs 迁入（TD-004 语义零变更）+ Let discard/bind 判型 + Define 位置纪律词法化（消息逐字保持）
- **发射序 = 解析序**：常量池 intern 序/原型序/全局首现序/Handle tag 后置 intern 逐位保持——字节码全等 parity 的结构性根据
- **D57 三面镜像纪律**：共享协议 + 解析语义 + 字节码产物——内部管线组织不在镜像义务（compiler.krf 零变更合法）
- **D58 排期重锚**：E5 出口三条件对账（de Bruijn 不在出口条件内）+ r49 = Define 上移 + Module 迁移 + let 直映臂（非正交点 2→1 唯一阻塞臂）→ r50 = S4 收口 → v1.0.0

## 交付一（测试与验收）
- IndexIR 断言组 5 case（槽复用/捕获定型/TD-004 max-card 迁移实证/E0003 消息保持/H-B 双原型）——854→**859:0:0**（单元 221→226；零断言修改——基线逐位维持）
- §3.2 六命令 clean 起步全绿（build 15.32s/check 0/fmt 0/clippy 0）+ 五审计集 EXIT 0 ×5 + CLI 全路径（fib 46368 + map (1 4 9) + append (1 2) + io read 77 + let 糖 7）
- r48 tar.gz **kerf-stage3-v0.15.0-r48-debruijn-ir-indexir-859tests.tar.gz**（288 条目/2.47MB）+ 包内自举 859:0:0 逐位一致 + qbe 在包

## 交付二（文档八件 + web）
- 22 v2.1 §16 / 01 §8.3 / 21 §5.3 / 15 §5.2 / e5-plan v1.6 / matrix v0.1.0-r48 / RELEASE v0.15.0-r48 / roadmap v0.11.0-r48 + download README r48 节 + web 面（kerf-data r48 节点 + footer + stats 自动）

## 开发实录（R1）
- **设计对齐的证据链路径**（E3 全文 + A1 实况 + M-I 形态卡 + 15 §5.2 六层规划 + 23 §2.2 出口三条件 + compile.rs/compiler.krf/driver 代码实况——「知识搜索 > 猜测」的文档内版本：六处设计源交叉后 IndexIR 形态收敛，零猜测设计）
- **测试夹具的槽语义陷阱**（`(let a 1 (let b 2 b))` 外层 body 不引用 a → discard 不占槽 → 内层 slot 0——bind 判型驱动槽分配的空槽语义由夹具错误当场暴露）
- **发射序对 intern 的隐式依赖**（Handle tag 后置/H-B 先行、Fn Closure 后置体发射两处最敏感——黄金快照执行级证明优于人工对拍）

## 下一步
- r49 Define 上移 + Module 迁移 + let 直映臂（D58 重锚——非正交点 2→1 唯一阻塞臂；ModuleItem 声明结构专设计轮）→ r50 S4 收口（门审 ≥30 case + E5 出口三条件终验 → v1.0.0）

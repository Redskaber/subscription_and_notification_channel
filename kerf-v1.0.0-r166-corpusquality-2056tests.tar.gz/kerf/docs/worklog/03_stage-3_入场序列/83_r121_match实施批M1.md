# rec 83 — r121 match 实施批 M-1：Reader 臂（模式文法全量 · 域外诊断退役 · 中间形裁定三条 · 1251 新基线）（03 层第 83 件）

**轮型**：match 实施窗首批（净 +10——**1251 基线自 r121 起**）
**驱动**：用户三链指令「①继续推进 目标语言设计的实现窗，如果中途穿着缺陷或未完成窗口则按照推荐顺序直接推进进入对应窗口开始具体实施 ②按照 docs/sop.md 流程结合 docs/lang-design/ 演进流程与 tech-debt-register.md、t3plus-trigger-audit.md 按照推荐先后任务顺序继续推进 ③同步完整打包项目 tar.gz 并同步完整更新 web page」——191-a..191-d（M1 指令开窗第二十六例——r120 收口笔推荐序首位兑现{match 实施批 M-1 = 切换窗全闭后推荐序首位}）

## 交付四段（191-a..191-d）

1. **191-a match 实施批 M-1 实施**（match-design.md v1.1 §6 批表——Reader 臂）：
   - **target.rs 三函数族 +~215 行**：parse_match（语句位/表达式位同形——parse_stmt_or_expr 分派 + parse_primary 表达式位[r110 if 先例同构]；scrutinee = 完整 expr；臂形 `(pattern body)` / `(pattern guard body)` 长度分立）+ parse_pattern_or（or 闭界链→`(or p q ...)` 标记表）+ parse_pattern_atom（字面量五族/绑定/`_` 通配/序对二元拆构/分组恒等 + 深度帽 8 + 限定名域外 fail-closed）。
   - **中间形裁定三条**（match-design.md v1.1 §3.0 入档——M-2 脱糖消费契约单源）：①or 标记形（`|` 保留 Token 无绑定碰撞；序对恒二元 vs or ≥3 长度域不交）②括号内至多二元（裸 or 链 fail-closed 带括号提示；三元 fail-closed；括号包裹嵌套按 EBNF 字面合法）③深度帽 8（>8 域外——§1 防御性栈保护字面）。
   - **域外诊断退役**：「match 语句（模式匹配设计文档——T3+ #5）」位改判开域；两处既有域外断言退役（target_reader_tests + target_reader_krf_tests 各一行——注释注记 M-4 分歧窗锚点在档）。
   - **文档同步**：02 §8.13.1a match 产生式族九条增补行（v7.11——设计单源→语言面规范锚→Reader 解析域开放三步链字面兑现）+ match-design.md v1.1（§3.0 + §6 批表 M-1 ✅ r121 + M-4 依赖行{步② ✅ 既成}）。
   - **新测试文件 match_m1_reader_tests.rs 10 case 五面**：中间形结构三 + 位置形 + 逗号纪律 + fail-closed 负例族九 + 深度帽边界 + **跨语法 Stx parity match 语料族七对**（数据面正典渲染字节级全等——Span 跨文本出比较域[r106 纪律]）+ **两枚边界锚**（.krf 镜像分歧窗锚[M-4 翻转] + 前端伪应用边界锚[M-2 消除]）。

2. **191-b GATE 1 全量验收**：六命令 clean 起步全绿（build 18.02s 零告警 / check --all-targets 0/0 / fmt 0 diff / clippy --all-targets -D warnings 0 / **test 1251:0:0 净 +10**）+ 审计×6 280 case EXIT 0 ×6 + CLI 七路径零回归 + 例行监测全项带内（match 用户面 examples 0；.ktf 命中 6 全为英文注释非语言面）。

3. **191-c 治理链八件**：t3plus v1.41 + RELEASE r121 节 + matrix r121 增量行与总量行 + rec 83（本件）+ 根层 l r121 条目 + README 两处 + 02 v7.11 + match-design v1.1。

4. **191-d 对账打包 web 收口**：r121 包三验（git archive 单源 + 独立解包净构建 + 包内 test 复跑 + 审计 + CLI）+ download README r121 节 + web 更新（kerf-data/footer/hero/stats）+ Agent Browser E2E。

## 关键裁定（GATE 3 条款号引用）

- **依据 §1.2.1-L2**：本批复杂度 L2（LOC ~565 带内 / 文件 8 / 单 crate 主面）——§3.2 + §8 + §10 + §7.2 + §7.3 门审 + §6.3 投票 + §13.1 设计对齐（match-design.md v1.0 既有单源）。
- **依据 原则 43（渐进披露）+ match-design §6 批间纪律（红线 4 零窗口合并）**：M-1 纯 Reader 臂——展开器语义守卫裁定**不采纳**（守卫 = M-2 领地预占；中间形经展开/编译为伪应用{双路径一致}通过，失败点 = 运行时未绑定全局 match 诊断——诚实边界登记 match-design v1.1 §3.0，M-2 落地脱糖后消除）。
- **依据 22 §27**：限定名模式（`a::b`）= 模式位域外 fail-closed（模式位无路径形态——对账行字面）。
- **依据 02 §8.13 定稿域边界纪律**：match 产生式入 Level 0 定稿域三步链（设计单源 v1.0 r107 → 02 §8.13.1a 增补行 r121 → Reader 解析域开放 r121——前两步本轮并轮完成，第三步同步兑现）。
- **依据 R1/R2（反射规则）**：两处既有域外断言退役 = 位改判语义随诊断退役（非阉割——新门族 10 case 承载）；.krf 镜像分歧窗诚实登记（M-4 闭窗义务 + 锚点测试翻转契约）。
- **依据 §12（最优>最小）**：arm 级裸 or+逗号诊断从 generic「期望 =>」升级为专项「or 模式与序对拆构不可混用（请括号包裹）」——诊断精确性原则。

## 开发实录（诚实登记）

1. **多轮行为探测先行**（probe 四轮——实施前定位）：①中间形结构 + 模式全族 + 负例九（全部符合预期）②.krf 镜像侧边界（维持域外诊断——分歧窗实证）+ 表达式位/语句位/顶层位③双路径展开一致性（种子/自举均伪应用通过——EXPAND OK 实证）④完整管线诊断质量（编译通过——失败点 = 运行时未绑定全局 match）。
2. **既有测试面命中两处**：probe 后全量跑暴露 target_reader_tests::domain_out_diagnostics 与 target_reader_krf_tests::syntax_parity_domain_out 各一行「match 语句」域外断言——位改判语义当轮退役（带 M-4 分歧窗注记）。
3. **展开器语义守卫裁定不采纳**：探测发现中间形伪应用静默通过展开/编译——首感方案 = 展开器加「match 语义未实施」守卫；裁定放弃（红线 4——守卫即 M-2 领地预占；且双路径[种子 Rust + 自举 .ktf]同置守卫 = 触碰 .ktf 自举语料大面）——运行时未绑定诊断 = M-1..M-2 诚实边界（错误消息含 `match` 关键字可定位）。
4. **EBNF 两括号备选冗余消解**：match-design §2 pattern_atom 的 `"(" [pattern_list] ")"` 与 `"(" pattern_first "," pattern_rest ")"` 两备选重叠——裁定按语义注释字面（二元拆构）消解为三分支算法（逗号→二元 / Or→分组 or 链 / RParen→分组恒等），`((a|b), c)` 与 `(a|b, c)` 的语法区分经「先 atom 后判分隔符」次序保真。

## 验收数字

- **GATE 1**：六命令全绿（build 18.02s / check 0/0 / fmt 0 / clippy 0 / **test 1251:0:0**）
- **审计×6**：280 case EXIT 0 ×6
- **CLI 七路径**：零回归（七锚全对 r120 基线）
- **例行监测**：六族 + `->` .ktf 全带内
- **r121 包三验**：见 RELEASE r121 节
- **净增量**：+10 测试（1241 → **1251**）

# rec 84 —— r122 match 实施批 M-2：皮肤字典第七映射（脱糖双侧落地）

**Task ID**：192-a..192-d　**日期**：2026-11-02　**角色**：Super Z (main)——ARCH-A（裁定）+ IMPL-A（实施）+ QA-A（验收）+ REC-A（对账）

**驱动**：用户三链指令（①继续推进目标语言设计实现窗[遇缺陷按推荐顺序直接推进] ②按 sop.md 流程 + lang-design 演进流程 + tech-debt-register + t3plus-trigger-audit 推荐序推进 ③完整打包 tar.gz + 完整更新 web page）——M1 指令开窗第二十七例；r121 收口笔推荐序首位兑现（match 实施批 M-2 = M-1 落地后推荐序首位）。

**交付**：

1. **192-a 实施**——match 臂 → cond/let 脱糖（match-design.md v1.1 §3 语义表全量 + **v1.2 §3.4 正典产物形状单源**）：
   - **种子侧** `kerf-expander/src/match_desugar.rs` 新模块：`(match scrut arm...)` → `(let ((m scrut)) 均匀 if 链)`——纯皮肤（let/if/and/or + **eq**/is-pair/is-nil/head/tail/error 全既有内建应用——零新原语零通道）；temp = `match-scrut$hyg$N`（ExpandCtxt::fresh_uniq 新全局单调计数器——单次求值 §3.3 + 最大基数并列消除）；臂右折叠（rest₀ = `(error "匹配失败：无臂匹配")` §4 兜底）；路径直取（head/tail 链零中间临时名）；守卫 `(and T (let binds G))` 形（短路保序 + 体位重绑定——臂隔离 §3.3）；终态臂 `(if true ...)`（均匀链——脱糖层零死码消除：报错>静默；消除归优化器域）。
   - **Keyword::Match 入面**（kerf-syntax/symbol.rs 第 26 关键字；E0020 绑定禁令面双侧自动扩展[is_reserved_word 单源]；roundtrip 锚 25→26；`match` 已在 22 定稿词面——实现面追平）。
   - **自举侧镜像** `bootstrap/expander.ktf` expand_match 族（match_analyze/pair/or + match_chain 右折叠 + KEYWORDS 增 match + MATCH_TMP_NEXT 重置——六头节点协议构造性同构）。
   - **五条 M-2 裁定入档**（v1.2 §3.4）：①谓词精化——`=` 示意 → **eq** 实装（类型严格多态：Bool/Nil 域 + Int≠Float——`0` 不匹配 `0.0`）②守卫 = bool 型条件（E0004 同族）③or 绑定**映射**恒等（名+路径全同——严于设计字面名集规则；join point 域外；诊断指向不一致备选[§7 问题 1 兑现]）④模式绑定位 = E0020 第三层（脱糖层精确 span）⑤重复绑定 fail-closed（Rust 同形）。
   - **compiler.ktf 潜伏缺陷清偿**（用户指令①行权）：compile_inner_proto 写回硬编码参数数覆盖 proto_bump_nlocals 回填——handle H/B 体原型 nlocals 归零（handle 体含 let 即「局部槽越界」）；compile_fn 的 r50-β 修复在 inner 路径漏修（r116 D61 三潜伏同族）；M-2 脱糖产物首次触发（match 体 handle × let 组合）；极小复现探针四轮窄化（手写等价形同败 = 既有潜伏非脱糖缺陷实证）。
   - **match_m2_desugar_tests 18 case**：跨语法字节码 parity 六族（目标面/S-expr 面/手写等价形三向全等——M-2 验收门）+ 种子↔自举双路径 parity + 运行时双路径（种子/生产）+ §4 兜底双路径 + 负例族 + 消息面镜像（六族逐字节等价）+ HM 集成 + 守卫效应序锚（§7 问题 2：resume false 否决首臂 + 结构失败短路）+ M-1 边界翻转 + 嵌套/臂隔离锚。
   - **M-1 边界锚翻转**（伪应用面退役）+ **examples/usage/match.krf**（用户面消费语料——生产路径 E2E ⇒ fib-13）。
2. **192-b GATE 1**：六命令 clean 起步全绿（build 18.68s 零告警 / check 0/0 / fmt 0 / clippy --all-targets -D warnings 0 / **test 1269:0:0 净 +18**）+ 审计×6 280 case EXIT 0 + CLI 八路径零回归（含 match 新路径）+ 例行监测（**t3plus #5 行翻转**：match 用户面 10 = match.krf 本体；其余全带内）。
3. **192-c 治理**：t3plus v1.42（#5 行翻转登记）+ RELEASE r122 节 + matrix r122 行 + 本件 + 根层 l + README 两处 + match-design v1.2 + 20 v1.18（§14 第七映射行）+ 22 v2.15（N4 26 名）。
4. **192-d 收口**：r122 包三验 + download README + web 更新 + E2E。

**关键裁定条款号**：match-design.md v1.1 §3（语义表全量）/ §3.3（单次求值 + 臂隔离）/ §4（兜底）/ 原则 31（皮肤/骨架同构——零新原语）/ 原则 42（编译期诊断正交 + 运行时兜底双层）/ 原则 43（渐进披露——红线 4 批间纪律）/ 原则 8（最小原语集合）/ 22 §2.1（N4 不变量——E0020 面扩展）/ 20 §14（皮肤字典第七映射）/ §12（最优>最小——诊断精确性：臂形/or 不一致/重复绑定三专项消息）/ §2.3（报错>静默——均匀链裁定 + or 绑定集恒等 fail-closed）/ R1/R4（handle 潜伏缺陷检出即修 + 文档同步）/ §20.6（诚实验收——四轮探测实录）。

**开发实录**：①生产路径 handle × match 槽位缺陷——极小复现窄化（g/h/i/j 四变体族 → handle × let 极小形；手写等价形同败 = 既有潜伏；指令序双路径一致探针[Symbol ID 差 = 探针双表假象]）②S-expr 臂形笔误三轮（「n if guard」目标面混写——中间形臂 = (pattern guard body) 无 if 关键字；嵌套 match 括号栈模拟定形——match 臂为形式直接元素）③守卫 bool 型纪律发现（resume nil → E0004——显式 bool 纪律同族非脱糖缺陷；锚改 resume false + 裁定 2 入档）④nil 字面量词面（S-expr 表达式位 nil 非 `()`）。

**演进位置**：match 实施窗 M-2 ✅（M-1 ✅ r121 → M-2 ✅ r122 → M-3 穷尽性诊断 → M-4 .krf 镜像同步）；1269 基线自 r122 起；双 Reader 分歧窗 M-1..M-3 维持；t3plus #5 行（match 语言面消费信号）翻转。

# r143 handle 表达式位窗（双侧 Reader primary 位分派）

> **Task ID**: 213-a..213-f　**Agent**: Super Z (main) — PM-A/ARCH-A/DEV-A/QA-A/REC-A 复合
> **Date**: 2026-11-14　**类型**: 登记域外行清偿实施窗（净 +32——**1852 基线自 r143 起**）　**驱动**: 用户三链指令（实现窗推进[遇未完成窗直接推进] + 按推荐序推进 + 打包/web）——**M1 指令开窗第四十八例**

## 交付链

- **213-a 走查 + 探针实测**：八设计单源 §7 + tc-sigs §7 余三行 + 登记册 + 触发表 14 行全量走查 → 三类不可行排除{Stage 2+ 域外 / 成熟度不在位[extern 别名 P5/P6 探针 E0019/E0022——符号空间机制缺口] / 纯语料信号零张力} → **唯一可行项 = handle-multi-arm §7 末行「目标面 handle 表达式位」**{张力探针五连实证：P1 ⇒100 / P3 ⇒101 / P7 ⇒11 [S-expr 面三位形全合法] vs P2/P8 E0001 [目标面 fail-closed]}。
- **213-b 设计**：handle-expr-position-design.md v1.0{D1-D8 + §7 域外六行}。
- **213-c 实施**：种子 target.rs parse_primary KwHandle 前置臂 + 镜像 target_reader.krf parse-primary cond 臂{≈12 行双侧} + ktf_handle_expr_position_tests 32 case{8正+24负 1:3} + 语料对 effect_handle_expr.{ktf,krf} ⇒327 双面 + 02 v7.23 + 20 v1.30。
- **213-d GATE 1**：1852:0:0 净 +32 + 审计×6 EXIT 0 + CLI 双语法面零回归{八路径含新语料 327} + bench 72.844ms 带内。
- **213-e 治理**：README 三处 + RELEASE r143 节 + matrix r143 行 + examples/README 13:13 + t3plus v1.63 + guide v1.28 + rec 104 + worklog 三链。
- **213-f 收口**：r143 包三验 + web 五件 + E2E + 投票。

## 语义要点

- **同形裁定（D1）**：表达式位 handle 与语句形共享一形——parse_primary 前置分派{r110 表达式位 if / r121 match 值形同构分派第三例}；语句位零回归{parse_stmt_or_expr 先行分派维持}。
- **零机制变更（D2）**：脱糖产物与语句位逐字节同构{单臂 `(handle tag ((p k) body) protected)` / ≥2 臂 `(handle-group ...)`}——expander/compiler/HM/VM 零触及；8 原语不变性第二十五轮{纯 Reader 位域扩展}。
- **r133 穿线无损延拓（D4）**：handler_k save/restore 在表达式位同样生效——嵌套 protected 内 resume 维持域外 fail-closed。
- **语义边界维持（D5）**：块形 protected 域外{protected 必须是表达式——语句位同律} + resume 表达式位域外 + halt/pass 臂体位维持。
- **零锚翻转（D8）**：rg 全库实证「expected an expression, got KwHandle」零锚定——纯加性位域扩展。
- **parity 缺口族谱**：CLI 双入口双面表达力 parity 清偿**第五连**（r125 require / r130 import as / r131 use 选择树 / r132 handle 多臂 / r143 handle 表达式位）。

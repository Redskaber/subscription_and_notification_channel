# r150 S-expr 完全拆除窗 Batch B（check.krf → check.ktf——HM 生产判定面目标语言化）

> **Task ID**: 220-main（220-a..220-f 全链）
> **Agent**: Super Z (main) — PM-A/ARCH-A/DEV-A/QA-A/REC-A 复合（M1 指令开窗第五十五例——用户指令①「遇缺陷/未完成窗按推荐顺序直接推进进入对应窗口」臂命中 r149 已开窗的拆除窗）

## A. 路由与实施（220-a/220-b/220-c）

- PHASE 1 路由：worklog 末三条核读（219-close/219-main/218-main——r149 Batch A 全链闭环 + 1948 基线 + 下一演进 = Batch B）；磁盘实况核对零冲突（git HEAD c7e32f5 干净 + Batch A 五件 .ktf + 平行件 .krf 在位 + s-expr-removal-plan.md v1.0 在位）；可行性审计四项阻断构造本轮实测复验全零（下划线/反引号/效应/bang 代码面）。
- 220-a check.ktf 转写（1285 行）：皮肤字典机械映射{cond 69 处→if-else 右递归链 + 'sym→quote(sym) + n 元 or→显式右嵌套 + mod 保留调用形 + do/assign 语句序列化{D42——语句序=求值序} + 多绑定 let 单语句承载 + kebab↔snake}。
- **两项转换纪律新锚**（本窗增量纪律——后续批次复用）：
  - **r116 第二规范化双侧逐字镜像**：七个关键字符号（'fn/'if/'let/'module/'require/'perform/'handle——13 位点）在目标面不可直写{quote(fn) 解析失败 = switch_corpus_parity_tests keyword_tag_normalization_anchors 负锚——保留字不可入表达式位}→ 双侧同形化为 FN-TAG..HANDLE-TAG string-to-symbol 常量{check.krf 同文件 LT-TRUE/LT-FALSE/LT-NIL 形先例 + expander.ktf 命名先例}；语义保持 = VM eq 按名比较；双侧同形 → 字节码全等{r116 正锚先例镜像——门 B 严格 parity 可达性根}。
  - **'nil→quote(()) 字面量化位**：S-expr 面 'nil 读期字面量化 → Nil 字面量 PushNil；目标面 nil 为普通标识符，quote(nil) 产出 SymLit 符号常量 PushConst{语义分歧 + 常量池/全局表索引 +1 漂移双根因——门 B 首跑指令序分歧定位}；正确映射 = quote(()){目标面 Unit 记号 = Nil 字面量——expander.ktf:1295 先例}；check.krf 全部 8 处 'nil 位点覆盖{tcon-kind-str 比较 + TC-SIGS print/newline/write-string 结果型 + tc-literal-type LT-NIL 臂 + tc-infer-do 空体 + tc-rule-one list 臂 + tc-rule-pair-list}。
- 220-b check.rs 桥切换：include_str!/CHECK_FILENAME → check.ktf + compile_front_seed → compile_front_seed_target{P1 硬约定维持}；文档注记全量更新；探针名 production_check_is_krf 历史名保留{Batch A 同律——门 Y 零变更纪律}。
- 220-c 门 B 测试族：seed_ktf_parity_tests 32 → 64 case{Batch B 增 8 正 + 24 负 1:3}——载荷字节码 parity{规范化 oracle ↔ 转写件：指令序/常量池[解析]/proto 形状[名字解析]/全局引用面[解析]全等 + debug_spans 跨文本按设计豁免} + 关键字 TAG 双侧规范化锚 + 入口与全局消费面{lchk-check-program + HM 引擎内建消费面} + 命名映射回环{入口 + 11 内部名 + 七 TAG 名 + 恒等面} + 跨阶段双面 E2E{同一类型错误程序双用户面同诊断计数同消息族——生产判定面双侧同走 check.ktf} + 生产接线活性 + 干净语料面 + r126 多错误收集形 + 负向 24 族{occurs 2 + unify 1 + arity 5 + 规则 5 + uncallable 1 + if 条件 1 + sigf 位置 4{具体实参直击——tvar 走 A4 保守域} + module 体 1 + 失败 define 后续引用 1 + 项内多违反 1 + 关键字 quote 负锚 1}；内循环修正两轮{首轮 18 败：测试程序形态缺陷——短横线名误写为减法链/N1 import 缺声明/tvar 实参走 A4 保守域不触发规则族/能力门先行——逐例修正为具体实参直击 + import 声明 + require 能力前置}。

## B. GATE 1 与审计（220-d）

- 六命令 clean 起步全绿：cargo clean{1935 files/399MiB} → build --release 22.69s 零告警 + check 0:0 + fmt 零 diff{一处 import 长行顺修} + clippy --release --workspace -D warnings 0 + test --release --workspace **1980:0:0 净 +32**{RUST_MIN_STACK=33554432；单元 299 + 集成 1681}。
- 审计×6 真实 EXIT 0{280 case}：stage0/stage1/stage2_r1/stage2_r2/m3/e5close。
- CLI 双语法面零回归{十一路径}：fib ⇒144 双面 + check fib 2/9/5/38 双面全等 + effect_stress ⇒120 + higher_order ⇒(1 4 9 16 25) + closures ⇒42 + macros ⇒42 + test 2/2 + ffi_alias ⇒9 + vector ⇒9。
- bench 71.735/71.898/71.761ms 三轮稳定{r149 锚 76.612 对照 -6.3% 环境侧有利漂移——fib 路径零接触 check 载荷{Batch B 变更不在 bench 消费面}；OBS-C <65ms 不满足维持——零信号}。
- 门 Y hm 三族零变更全绿：hm_production_switch 9{七语料锚 18/6/3/6/0/0/0 钉定维持 + liveness} + hm_krf_path 31 + ktf_tc_sigs_parity 32{TC-SIGS 62 行锚维持——r144 口径}。

## C. 治理（220-e）

matrix r150 增量行 + 总量行 1980 + RELEASE r150 节 + README 三处{L69 质量状态/L75 测试行/L101 包行} + t3plus v1.70{r150 消费注记——14 行触发族判定零变化} + s-expr-removal-plan v1.1{§4 Batch B ✅ + §8 Batch B 对账节} + 20 v1.33{§14 种子域 r150 行——两项增量映射纪律} + 12 v6.32{§2.19 Batch B 锚} + 替换面图 r150 拆除进程注记{种子链已 .ktf 化六件} + rec 111 + 根层 l + worklog 三链。

## D. 收口（220-f）

r150 包三验{git archive 单源 + 独立解包净构建 + 包内 1980 复跑 + e5close EXIT 0 + CLI 双面} + download 入位{最新 + 上一包策略} + web 五件 + E2E + lint + §6.3 投票 5.5/5.5 GO。

## 演进位置

- 8 原语不变性第三十二轮{纯皮肤/载荷形态切换——零机制变更零新原语零通道}。
- S-expr 完全拆除窗：Batch A ✅ r149 + **Batch B ✅ r150** + C target_reader.krf r151-r152{两轮分批——Reader fixpoint 里程碑} + D 用户面拆除 r153 + E6 终局清理 r154。
- 遵循：§1.2（L3 路由）/ 原则 6/9/31/41{平行件策略 + 拆除判据}/ §2.3 红线 4{分步验收}/ §3.2{六命令}/ §5.3{八项}/ §8.4.5{文档-代码冲突以代码为准——TC-SIGS 62 行口径修正}/ §8.4.6/§8.6/ §9.4.3{1:3}/ §19/ §20.3{同类路径审查}/ §20.6{诚实验证——bench 环境漂移归因}。

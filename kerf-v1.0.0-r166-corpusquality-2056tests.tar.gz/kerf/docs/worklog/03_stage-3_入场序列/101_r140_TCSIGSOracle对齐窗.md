# r140 TC-SIGS Oracle 对齐窗（签名表 24→61 扩表）

> **Task ID**: 210-a..210-f　**Agent**: Super Z (main) — PM-A/ARCH-A/DEV-A/QA-A/REC-A 复合
> **Date**: 2026-11-11　**类型**: 登记域外行清偿实施窗（净 +32——**1756 基线自 r140 起**）　**驱动**: 用户三链指令——**M1 指令开窗第四十五例**

## 交付链

- **210-b 实施**：check.krf TC-SIGS 24→61{37 新行 + string-append 行修正} + 'sigf 定形异参形 + 三新函数 + 新 kind 四臂{'list/'pair/'int/'sym} + tvar 域特化{Int 参 Num 域宽化——方向守卫防御位}——纯 .krf 面零桥变更。
- **210-c 测试**：ktf_tc_sigs_parity_tests 32 case{8正+24负} + 锚翻转三件 + r102 命名守卫顺修 ×5。
- **210-d GATE 1**：1756:0:0 净 +32 + 审计×6 + CLI 双语法面零回归 + bench 带内。
- **210-f 收口**：r140 包三验 + web 五件 + E2E + 投票 5.5/5.5 GO。

## 语义要点（r142 修订注记）

- **'sigf 逐参路径 'any 规则位无臂缺陷**（r140 引入——r142/212 清偿）：tc-check-pos-rules→tc-rule-one 缺 'any 短路臂——member/assoc 第一参（唯一 'any 位）具体类型全兜底误报 + tvar unify 伪 tcon('any) 污染跨用位传播。r140 门未检出的根因：P02 无 member 'any 正例 + N05 contains-any 断言形态掩盖。
- **r140 三语料重锚 11 项中 5 项实为污染伪产物**（r142 stash-built 对照实证修正）：expander 第 6 项 `string-append requires str, got ?` + compiler 第 2 项 `type mismatch: ? and str` + reader 全 3 项——`?` 渲染 = 伪 tcon('any) 本体。

> R4 补债注记：本件 r142/212-e 补写——r140 当时 worklog 声称 rec 落盘但实况未写；当轮发现当轮修正。

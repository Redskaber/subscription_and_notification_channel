//! The expansion loop: syntax objects → core expressions
//! (docs/stage0.md §19.2).
//!
//! Two public entries:
//! - [`expand`] — one expression with an explicit environment (the
//!   REPL/driver composition point, plan sub-stage 0.8).
//! - [`expand_program`] — a whole top-level form sequence → module
//!   items (declaration forms only; the top-level expression channel
//!   is the `define` calling form — r110 corpus note).
//!
//! Hygiene skeleton (0.4 slice): every binding construct allocates a
//! fresh scope, colors its subtree on descent (`with_scope_added`),
//! and resolution is scope-set keyed; macro transformers, the
//! def-site ∪ use-site union and the expansion cache are the 0.9 macro
//! system (docs/stage0.md §8.10 skeleton boundary). Span discipline:
//! desugared nodes reuse source spans of the same expansion
//! generation — cross-generation joins never occur here (the TD-002
//! adjudication, plan-0.4.md §4).

use kerf_core::{Binding, CoreExpr, HandlerClause, LiteralValue, ModuleItem};
use kerf_span::{Span, Symbol};
use kerf_syntax::{Phase, ScopeSet, StxDatum, SyntaxObject};

use crate::ctx::{ExpandCtx, Resolution};
use crate::error::ExpandError;
use crate::transformer::SyntaxRules;

/// Expand one expression with the environment `ctx`.
///
/// Every nested level consumes one unit of the work budget
/// ([`EXPANSION_LIMIT`](crate::EXPANSION_LIMIT)); the phase closure
/// rule (runtime-phase code only — docs/stage0.md §8.9 rule 1) is
/// enforced on every node touched, structural reads included.
pub fn expand(ctx: &mut ExpandCtx, stx: &SyntaxObject) -> Result<CoreExpr, ExpandError> {
    ctx.enter(stx.span)?;
    let result = expand_node(ctx, stx);
    ctx.exit();
    result
}

/// Expand a whole program: top-level forms → module items.
///
/// The module top level accepts declarations only (`define` /
/// `require` / `module`); a bare expression is
/// [`ExpandError::TopLevelExpression`]. Defines bind sequentially and
/// support self-reference (the letrec-shaped top-level rule that
/// makes recursive functions like `fib` expandable); nested modules
/// are scope-isolated from outer defines.
pub fn expand_program(forms: &[SyntaxObject]) -> Result<Vec<ModuleItem>, ExpandError> {
    let mut ctx = ExpandCtx::new();
    expand_declarations(&mut ctx, forms)
}

// ---------- shared helpers ----------

/// The phase-closure check applied to every structurally consumed
/// node (docs/stage0.md §8.9 rule 1 — the 0.4 slice: runtime
/// expansion accepts runtime-phase syntax only; transformer execution
/// arrives with the 0.9 macro system).
fn require_runtime(stx: &SyntaxObject) -> Result<(), ExpandError> {
    if stx.phase != Phase::Runtime {
        return Err(ExpandError::PhaseViolation {
            phase: stx.phase,
            span: stx.span,
        });
    }
    Ok(())
}

/// The identifier text of a symbol atom (shape check only — callers
/// phase-check the node first).
fn symbol_text(stx: &SyntaxObject) -> Option<&str> {
    match &stx.datum {
        StxDatum::Symbol(sym) => Some(sym.as_str()),
        _ => None,
    }
}

/// The interned identity of a well-formed symbol atom (§9.65 EXP-1:
/// error payloads reference the single-pool entry the syntax tree
/// already carries — never a de-interned text copy).
fn symbol_sym(stx: &SyntaxObject) -> Option<&Symbol> {
    match &stx.datum {
        StxDatum::Symbol(sym) => Some(sym),
        _ => None,
    }
}

/// The interned identities of a well-formed parameter list: a
/// (possibly empty) list of symbol atoms (§9.66 TRF-8: the frame
/// binds the entries the tree carries, never their texts).
fn symbol_syms(node: &SyntaxObject) -> Option<Vec<&Symbol>> {
    let items = match &node.datum {
        StxDatum::List(items) => items,
        _ => return None,
    };
    let mut syms = Vec::with_capacity(items.len());
    for item in items {
        syms.push(symbol_sym(item)?);
    }
    Some(syms)
}

fn malformed(form: &'static str, span: Span) -> ExpandError {
    ExpandError::MalformedForm { form, span }
}

fn core_err(source: kerf_core::CoreError, span: Span) -> ExpandError {
    ExpandError::Core { source, span }
}

// ---------- expression expansion ----------

fn expand_node(ctx: &mut ExpandCtx, stx: &SyntaxObject) -> Result<CoreExpr, ExpandError> {
    require_runtime(stx)?;
    match &stx.datum {
        StxDatum::Int(v) => Ok(CoreExpr::Literal {
            span: stx.span,
            value: LiteralValue::Int(*v),
        }),
        StxDatum::Float(v) => Ok(CoreExpr::Literal {
            span: stx.span,
            value: LiteralValue::Float(*v),
        }),
        StxDatum::Bool(v) => Ok(CoreExpr::Literal {
            span: stx.span,
            value: LiteralValue::Bool(*v),
        }),
        StxDatum::String(s) => Ok(CoreExpr::Literal {
            span: stx.span,
            value: LiteralValue::String(s.clone()),
        }),
        StxDatum::Symbol(sym) => expand_symbol(ctx, sym, stx),
        StxDatum::List(items) => expand_list(ctx, items, stx.span),
    }
}

fn expand_symbol(
    ctx: &mut ExpandCtx,
    sym: &Symbol,
    stx: &SyntaxObject,
) -> Result<CoreExpr, ExpandError> {
    let text = sym.as_str();
    // `nil` is the reserved literal keyword (the empty-list datum in
    // the core — plan-0.3 decision 3 carries the surface spelling).
    if text == "nil" {
        return Ok(CoreExpr::Literal {
            span: stx.span,
            value: LiteralValue::Nil,
        });
    }
    // §9.66 TRF-8: the pool entry the tree carries goes straight into
    // the frame table (never de-interned for the lookup); the single
    // text crossing left is the core constructor boundary below.
    match ctx.resolve(sym, &stx.scopes) {
        Resolution::Local | Resolution::Global => {
            CoreExpr::var(stx.span, text).map_err(|source| core_err(source, stx.span))
        }
        Resolution::Unbound => Err(ExpandError::UnboundIdentifier {
            name: sym.clone(),
            span: stx.span,
        }),
    }
}

fn expand_list(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<CoreExpr, ExpandError> {
    // Empty application, synthesized face: the reader rejects `()` in
    // source (plan-0.3 decision 3); this is the second fail-closed
    // layer for hand-built and (at 0.9) macro-produced trees.
    if items.is_empty() {
        return Err(ExpandError::EmptyForm { span });
    }
    require_runtime(&items[0])?;
    if let Some(head) = symbol_sym(&items[0]) {
        // Flat head-keyword dispatch (the 0.4 simplification — the
        // scoped-keyword mechanism is the 0.9 upgrade path). The
        // declaration forms (`define`/`require`/`module`/
        // `define-syntax`) are NOT expression forms: in operand
        // position they expand as applications of unbound identifiers
        // (fail-closed).
        match head.as_str() {
            "fn" => return expand_fn(ctx, items, span),
            "if" => return expand_if(ctx, items, span),
            "let" => return expand_let(ctx, items, span),
            "do" => return expand_do(ctx, items, span),
            "set!" => return expand_set(ctx, items, span),
            "perform" => return expand_perform(ctx, items, span),
            "handle" => return expand_handle(ctx, items, span),
            "quote" => return expand_quote(items, span),
            _ => {}
        }
        // Macro use (sub-stage 0.9): the head resolves through the
        // same scope-keyed judgment as identifiers — core forms win
        // first (flat dispatch order), macros shadow plain
        // applications (docs/stage0.md §19.2 expansion loop, the
        // macro branch). §9.66 TRF-8: the head's pool entry feeds the
        // macro table directly.
        if let Some(id) = ctx.resolve_macro(head, &items[0].scopes) {
            return expand_macro_use(ctx, id, items);
        }
    }
    expand_application(ctx, items, span)
}

/// One macro use: instantiate the winning clause and re-expand the
/// product to a fixpoint (core forms or further macro uses —
/// docs/stage0.md §19.2: a macro may expand into a macro use, until
/// a core form). Every level consumes expansion work budget, so a
/// self-recursive macro fails with a structured depth error.
fn expand_macro_use(
    ctx: &mut ExpandCtx,
    id: usize,
    items: &[SyntaxObject],
) -> Result<CoreExpr, ExpandError> {
    // The use form's generation: introduced nodes carry generation+1
    // (docs/stage0.md §8.6 / the dea12b tracing contract).
    let use_gen = items[0].span.expansion_id;
    let product = ctx.transformer(id).instantiate(items, use_gen)?;
    expand(ctx, &product)
}

/// `(quote datum)` — the datum as a literal value (sub-stage 0.9; the
/// 0.1 `LiteralValue::Pair` consumption face — plan-0.7 decision 13).
/// Atoms and proper lists fold into the pair chain ending in `Nil`;
/// symbols (and lists containing them) are outside the Stage 0 value
/// model and fail closed.
fn expand_quote(items: &[SyntaxObject], span: Span) -> Result<CoreExpr, ExpandError> {
    // (quote datum) — exactly one datum.
    if items.len() != 2 {
        return Err(malformed("quote", span));
    }
    require_runtime(&items[1])?;
    let value = datum_to_literal(&items[1])?;
    Ok(CoreExpr::Literal { span, value })
}

/// The datum → literal fold: atoms map directly, lists right-fold
/// into `Pair` chains terminated by `Nil` (the proper-list datum
/// shape). Symbol data (except the reserved `nil`) has no Stage 0
/// carrier — the fail-closed boundary.
fn datum_to_literal(node: &SyntaxObject) -> Result<LiteralValue, ExpandError> {
    match &node.datum {
        StxDatum::Int(v) => Ok(LiteralValue::Int(*v)),
        StxDatum::Float(v) => Ok(LiteralValue::Float(*v)),
        StxDatum::Bool(v) => Ok(LiteralValue::Bool(*v)),
        StxDatum::String(v) => Ok(LiteralValue::String(v.clone())),
        StxDatum::Symbol(sym) if sym.as_str() == "nil" => Ok(LiteralValue::Nil),
        StxDatum::Symbol(_) => Err(ExpandError::QuoteUnsupportedDatum { span: node.span }),
        StxDatum::List(list) => {
            let mut acc = LiteralValue::Nil;
            for item in list.iter().rev() {
                acc = LiteralValue::Pair(Box::new(datum_to_literal(item)?), Box::new(acc));
            }
            Ok(acc)
        }
    }
}

fn expand_fn(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<CoreExpr, ExpandError> {
    // (fn (params...) body) — exactly one body form at 0.4
    // (sequencing is the `do` form).
    if items.len() != 3 {
        return Err(malformed("fn", span));
    }
    require_runtime(&items[1])?;
    let params = symbol_syms(&items[1]).ok_or_else(|| malformed("fn", span))?;
    require_runtime(&items[2])?;
    expand_fn_binding(ctx, &params, &items[2], span, &items[0].scopes)
}

/// The shared `Fn` assembly: fresh scope → bind params → color body →
/// expand → validated constructor (duplicate parameters are
/// re-asserted by `CoreExpr::fn_` — the 0.1 constructor contract).
/// `base` is the binding form's own scope set — the frame's binder
/// scopes are `base ∪ {fresh}` (the 0.9 subset-resolution rule).
/// Params are the pool entries the tree carries (§9.66 TRF-8: the
/// frame binds by entry; the core constructor crossing de-interns
/// each entry exactly once — the K110 text boundary).
fn expand_fn_binding(
    ctx: &mut ExpandCtx,
    params: &[&Symbol],
    body_node: &SyntaxObject,
    fn_span: Span,
    base: &ScopeSet,
) -> Result<CoreExpr, ExpandError> {
    let scope = ctx.fresh_scope();
    ctx.push_frame(scope, base);
    let result = (|| {
        for param in params {
            ctx.bind(param);
        }
        let colored_body = body_node.with_scope_added(scope);
        let body = expand(ctx, &colored_body)?;
        let param_texts: Vec<&str> = params.iter().map(|sym| sym.as_str()).collect();
        CoreExpr::fn_(fn_span, &param_texts, body).map_err(|source| core_err(source, fn_span))
    })();
    ctx.pop_frame();
    result
}

fn expand_if(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<CoreExpr, ExpandError> {
    // (if cond then else) — both branches mandatory.
    if items.len() != 4 {
        return Err(malformed("if", span));
    }
    for operand in &items[1..] {
        require_runtime(operand)?;
    }
    let cond = expand(ctx, &items[1])?;
    let then_branch = expand(ctx, &items[2])?;
    let else_branch = expand(ctx, &items[3])?;
    Ok(CoreExpr::If {
        span,
        cond: Box::new(cond),
        then_branch: Box::new(then_branch),
        else_branch: Box::new(else_branch),
    })
}

fn expand_let(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<CoreExpr, ExpandError> {
    // (let spec body) with spec = () | (name value) | ((name value)...)
    if items.len() != 3 {
        return Err(malformed("let", span));
    }
    require_runtime(&items[1])?;
    require_runtime(&items[2])?;
    let spec = match &items[1].datum {
        StxDatum::List(spec) => spec,
        _ => return Err(malformed("let", span)),
    };

    // One binding pair: (name atom, value node) with the binding-site
    // span of the name. Pairs carry the name's pool entry (§9.66
    // TRF-8).
    let mut pairs: Vec<(&Symbol, &SyntaxObject)> = Vec::with_capacity(spec.len());
    if spec.is_empty() {
        // (let () body) — zero bindings.
    } else if matches!(spec[0].datum, StxDatum::List(_)) {
        // Multi-binding spec: every item must be (name value).
        for pair in spec {
            require_runtime(pair)?;
            let pair_items = match &pair.datum {
                StxDatum::List(pair_items) if pair_items.len() == 2 => pair_items,
                _ => return Err(malformed("let", span)),
            };
            require_runtime(&pair_items[0])?;
            let name = symbol_sym(&pair_items[0]).ok_or_else(|| malformed("let", span))?;
            pairs.push((name, &pair_items[1]));
        }
    } else {
        // Single-binding spec: spec itself is (name value).
        if spec.len() != 2 {
            return Err(malformed("let", span));
        }
        require_runtime(&spec[0])?;
        let name = symbol_sym(&spec[0]).ok_or_else(|| malformed("let", span))?;
        pairs.push((name, &spec[1]));
    }

    let scope = ctx.fresh_scope();
    ctx.push_frame(scope, &items[0].scopes);
    let result = (|| {
        // let* order: each value is expanded before its name is bound,
        // so later values see earlier names and never the reverse.
        let mut bindings = Vec::with_capacity(pairs.len());
        for (name, value_node) in pairs {
            require_runtime(value_node)?;
            let colored_value = value_node.with_scope_added(scope);
            let value = expand(ctx, &colored_value)?;
            bindings.push(
                Binding::new(value_node.span, name.as_str(), value)
                    .map_err(|source| core_err(source, value_node.span))?,
            );
            ctx.bind(name);
        }
        let colored_body = items[2].with_scope_added(scope);
        let body = expand(ctx, &colored_body)?;
        Ok(CoreExpr::Let {
            span,
            bindings,
            body: Box::new(body),
        })
    })();
    ctx.pop_frame();
    result
}

fn expand_do(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<CoreExpr, ExpandError> {
    // (do e1 ... en) — the Begin surface desugaring to a Let chain
    // (docs/stage0.md §6.12.6: Begin -> Let chain). Intermediate values
    // bind to the conventional discard name `_`; the last form is the
    // body. (do e) is the identity (Begin of one expression).
    if items.len() < 2 {
        return Err(malformed("do", span));
    }
    if items.len() == 2 {
        require_runtime(&items[1])?;
        return expand(ctx, &items[1]);
    }
    for node in &items[1..] {
        require_runtime(node)?;
    }
    let scope = ctx.fresh_scope();
    ctx.push_frame(scope, &items[0].scopes);
    let result = (|| {
        // The conventional discard name: interned once here (a pool
        // hit after the first `do` — §9.66 TRF-8), then bound by
        // entry like every other name.
        let discard = Symbol::new("_").expect("the discard name is a valid symbol");
        let mut bindings = Vec::with_capacity(items.len() - 2);
        for step in &items[1..items.len() - 1] {
            let colored_step = step.with_scope_added(scope);
            let value = expand(ctx, &colored_step)?;
            bindings.push(
                Binding::new(step.span, discard.as_str(), value)
                    .map_err(|source| core_err(source, step.span))?,
            );
            ctx.bind(&discard);
        }
        let body_node = items.last().expect("do form has at least 3 items");
        let colored_body = body_node.with_scope_added(scope);
        let body = expand(ctx, &colored_body)?;
        Ok(CoreExpr::Let {
            span,
            bindings,
            body: Box::new(body),
        })
    })();
    ctx.pop_frame();
    result
}

fn expand_set(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<CoreExpr, ExpandError> {
    // (set! name value) — the historical surface spelling of Assign
    // (docs/stage0.md §6.12.6 mapping). The target must resolve
    // (Scheme semantics: assigning an unbound variable is an error).
    if items.len() != 3 {
        return Err(malformed("set!", span));
    }
    require_runtime(&items[1])?;
    require_runtime(&items[2])?;
    let sym = symbol_sym(&items[1]).ok_or_else(|| malformed("set!", span))?;
    // §9.66 TRF-8: the pool entry feeds the frame table directly.
    match ctx.resolve(sym, &items[1].scopes) {
        Resolution::Local | Resolution::Global => {
            let value = expand(ctx, &items[2])?;
            CoreExpr::assign(span, sym.as_str(), value).map_err(|source| core_err(source, span))
        }
        Resolution::Unbound => Err(ExpandError::UnboundIdentifier {
            name: sym.clone(),
            span: items[1].span,
        }),
    }
}

fn expand_perform(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<CoreExpr, ExpandError> {
    // (perform effect args...) — the effect name is a symbol atom.
    if items.len() < 2 {
        return Err(malformed("perform", span));
    }
    require_runtime(&items[1])?;
    let effect = symbol_text(&items[1]).ok_or_else(|| malformed("perform", span))?;
    let mut args = Vec::with_capacity(items.len() - 2);
    for arg in &items[2..] {
        require_runtime(arg)?;
        args.push(expand(ctx, arg)?);
    }
    CoreExpr::perform(span, effect, args).map_err(|source| core_err(source, span))
}

fn expand_handle(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<CoreExpr, ExpandError> {
    // (handle body (effect handler)...) — handlers are closures over
    // the current scope; duplicate effects are re-asserted by
    // `CoreExpr::handle` (deterministic: left to right).
    if items.len() < 2 {
        return Err(malformed("handle", span));
    }
    require_runtime(&items[1])?;
    let body = expand(ctx, &items[1])?;
    let mut handlers = Vec::with_capacity(items.len() - 2);
    for clause in &items[2..] {
        require_runtime(clause)?;
        let pair = match &clause.datum {
            StxDatum::List(pair) if pair.len() == 2 => pair,
            _ => return Err(malformed("handle", span)),
        };
        require_runtime(&pair[0])?;
        require_runtime(&pair[1])?;
        let effect = symbol_text(&pair[0]).ok_or_else(|| malformed("handle", span))?;
        let handler = expand(ctx, &pair[1])?;
        handlers.push(
            HandlerClause::new(clause.span, effect, handler)
                .map_err(|source| core_err(source, clause.span))?,
        );
    }
    CoreExpr::handle(span, body, handlers).map_err(|source| core_err(source, span))
}

fn expand_application(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<CoreExpr, ExpandError> {
    // (func args...) — the func position is an ordinary expression.
    let func = expand(ctx, &items[0])?;
    let mut args = Vec::with_capacity(items.len() - 1);
    for arg in &items[1..] {
        args.push(expand(ctx, arg)?);
    }
    Ok(CoreExpr::Apply {
        span,
        func: Box::new(func),
        args,
    })
}

// ---------- declaration expansion (program face) ----------

fn expand_declarations(
    ctx: &mut ExpandCtx,
    forms: &[SyntaxObject],
) -> Result<Vec<ModuleItem>, ExpandError> {
    let module_scope = ctx.fresh_scope();
    // The module frame's binder scopes: the *uncolored* forms' base
    // (the outer context) plus the module scope — exactly what a
    // top-level binding occurrence carries after coloring.
    let base = match forms.first() {
        Some(form) => form.scopes.clone(),
        None => ScopeSet::new(),
    };
    ctx.push_frame(module_scope, &base);
    let result = (|| {
        let mut items = Vec::with_capacity(forms.len());
        for form in forms {
            require_runtime(form)?;
            let colored = form.with_scope_added(module_scope);
            items.push(expand_declaration(ctx, &colored)?);
        }
        Ok(items)
    })();
    ctx.pop_frame();
    result
}

/// The declaration heads: a top-level list whose head is one of these
/// strings is a declaration (module item); every other head — the
/// expression special forms included — is a bare top-level expression
/// and is rejected by `expand_declaration`. This constant is the
/// single source for that classification: the driver's REPL wraps
/// expression submissions into `$repl:N` defines and passes
/// declarations through, so it consumes this list instead of keeping
/// a second one (stage0.md §9.62 SURF-2). The gate in
/// `expand_declaration` consults it before the dispatch arms; the
/// `top_level_heads_match_dispatch_table` unit test pins the two
/// together (a const member with no dispatch arm falls to the
/// fail-closed arm and fails the test; an arm without a const member
/// is unreachable dead code).
pub const TOP_LEVEL_DECLARATION_HEADS: &[&str] = &["define", "require", "module", "define-syntax"];

fn expand_declaration(ctx: &mut ExpandCtx, form: &SyntaxObject) -> Result<ModuleItem, ExpandError> {
    let items = match &form.datum {
        StxDatum::List(items) if !items.is_empty() => items,
        // Atoms and `()` at module top level are expressions, not
        // declarations.
        _ => return Err(ExpandError::TopLevelExpression { span: form.span }),
    };
    require_runtime(&items[0])?;
    let head = match symbol_text(&items[0]) {
        // The const is the gate: only declaration heads dispatch.
        Some(head) if TOP_LEVEL_DECLARATION_HEADS.contains(&head) => head,
        // Any other head — including the expression special forms —
        // is a bare top-level expression.
        _ => return Err(ExpandError::TopLevelExpression { span: form.span }),
    };
    match head {
        "define" => expand_define(ctx, items, form.span),
        "require" => expand_require(items, form.span),
        "module" => expand_module(ctx, items, form.span),
        "define-syntax" => expand_define_syntax(ctx, items, form.span),
        // A const member with no dispatch arm above: fail closed —
        // the `top_level_heads_match_dispatch_table` unit test turns
        // this hole into a failure (a const member must never come
        // back out as a top-level-expression rejection).
        _ => Err(ExpandError::TopLevelExpression { span: form.span }),
    }
}

/// The heads a macro name may never take (also the rename-on-capture
/// name faces — transformer.rs): the flat dispatch order resolves core
/// forms before macros, so such a declaration would be silently dead
/// (report over silence — rejected at registration), and an introduced
/// binder named like a core form would be shadowed by the dispatch
/// itself.
pub(crate) const RESERVED_MACRO_NAMES: &[&str] = &[
    "fn",
    "if",
    "let",
    "do",
    "set!",
    "perform",
    "handle",
    "quote",
    "define",
    "require",
    "module",
    "define-syntax",
    "nil",
    "_",
    "...",
];

/// The interned form of [`RESERVED_MACRO_NAMES`] (§9.66 TRF-6): seeded
/// once on first use, then the macro-instantiation trigger set copies
/// pool entries instead of re-allocating ~15 strings per macro use
/// (the `rustc_span::sym` pre-interning discipline — K113). The
/// `&[&str]` const stays the single text source.
pub(crate) fn reserved_macro_name_symbols() -> &'static std::collections::HashSet<Symbol> {
    static SET: std::sync::OnceLock<std::collections::HashSet<Symbol>> = std::sync::OnceLock::new();
    SET.get_or_init(|| {
        RESERVED_MACRO_NAMES
            .iter()
            .map(|text| Symbol::new(text).expect("reserved name must be a valid symbol"))
            .collect()
    })
}

/// Whether `name` is a reserved macro head (§9.66 TRF-8: judged by the
/// pool entry the caller holds — membership over the pre-interned
/// set, never a text scan).
pub(crate) fn is_reserved_macro_name(name: &Symbol) -> bool {
    reserved_macro_name_symbols().contains(name)
}

/// `(define-syntax name (syntax-rules ...))` — the macro declaration
/// (sub-stage 0.9). Registers the transformer in the current frame
/// (lexically scoped: a nested module's macros vanish with its
/// frame) and emits the zero-code declaration record
/// ([`ModuleItem::DefineSyntax`]).
fn expand_define_syntax(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<ModuleItem, ExpandError> {
    // (define-syntax name spec) — exactly three items.
    if items.len() != 3 {
        return Err(malformed("define-syntax", span));
    }
    require_runtime(&items[1])?;
    require_runtime(&items[2])?;
    let sym = symbol_sym(&items[1]).ok_or_else(|| malformed("define-syntax", span))?;
    if is_reserved_macro_name(sym) {
        return Err(malformed("define-syntax", span));
    }
    // Fresh def-site scope, then color the whole spec: every template
    // node carries the definition context plus the def scope (the
    // §9.38(b) coloring — the union the subset judgment consumes).
    let def_scope = ctx.fresh_scope();
    let colored_spec = items[2].with_scope_added(def_scope);
    // §9.65 EXP-3: the declaration identity flows to the transformer
    // as the interned entry itself — the mismatch error later carries
    // this same entry (index equality), never a re-interned copy.
    let rules = SyntaxRules::parse(sym.clone(), &colored_spec, span)?;
    let id = ctx.register_transformer(rules);
    // §9.66 TRF-2: the macro registry binds the pool entry itself.
    ctx.bind_macro(sym, id);
    ModuleItem::define_syntax(span, sym.as_str()).map_err(|source| core_err(source, span))
}

fn expand_define(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<ModuleItem, ExpandError> {
    if items.len() != 3 {
        return Err(malformed("define", span));
    }
    require_runtime(&items[1])?;
    match &items[1].datum {
        // Function define sugar: (define (f params...) body) →
        // Define{f, Fn{params, body}} — the near-identity mapping of
        // docs/stage0.md §7.3.5.
        StxDatum::List(name_and_params) if !name_and_params.is_empty() => {
            require_runtime(&name_and_params[0])?;
            let name = symbol_sym(&name_and_params[0]).ok_or_else(|| malformed("define", span))?;
            let mut params = Vec::with_capacity(name_and_params.len() - 1);
            for param in &name_and_params[1..] {
                require_runtime(param)?;
                params.push(symbol_sym(param).ok_or_else(|| malformed("define", span))?);
            }
            require_runtime(&items[2])?;
            // Pre-bind the name before expanding the body: the
            // letrec-shaped top-level rule (recursive functions
            // resolve their own name).
            ctx.bind(name);
            let value = expand_fn_binding(
                ctx,
                &params,
                &items[2],
                name_and_params[0].span,
                &items[0].scopes,
            )?;
            ModuleItem::define(span, name.as_str(), value).map_err(|source| core_err(source, span))
        }
        // Value define: (define name value).
        StxDatum::Symbol(_) => {
            let name = symbol_sym(&items[1]).expect("datum is a symbol");
            require_runtime(&items[2])?;
            ctx.bind(name);
            let value = expand(ctx, &items[2])?;
            ModuleItem::define(span, name.as_str(), value).map_err(|source| core_err(source, span))
        }
        _ => Err(malformed("define", span)),
    }
}

fn expand_require(items: &[SyntaxObject], span: Span) -> Result<ModuleItem, ExpandError> {
    // (require "module") — the module name is a string datum
    // (fail-closed: symbols are rejected).
    if items.len() != 2 {
        return Err(malformed("require", span));
    }
    require_runtime(&items[1])?;
    match &items[1].datum {
        StxDatum::String(module) => {
            ModuleItem::require(span, module).map_err(|source| core_err(source, span))
        }
        _ => Err(malformed("require", span)),
    }
}

fn expand_module(
    ctx: &mut ExpandCtx,
    items: &[SyntaxObject],
    span: Span,
) -> Result<ModuleItem, ExpandError> {
    // (module name items...) — nested declarations, scope-isolated
    // from outer defines (docs/stage0.md §8.9 direction).
    if items.len() < 3 {
        return Err(malformed("module", span));
    }
    require_runtime(&items[1])?;
    let name = symbol_text(&items[1]).ok_or_else(|| malformed("module", span))?;
    let saved = ctx.isolate_frames();
    let inner = expand_declarations(ctx, &items[2..]);
    ctx.restore_frames(saved);
    ModuleItem::module(span, name, inner?).map_err(|source| core_err(source, span))
}

#[cfg(test)]
mod tests {
    //! Unit tests for the expansion loop (sub-stage test doc FP2-FP4).

    use super::*;
    use kerf_span::{ByteOffset, ExpansionId, FileId};
    use kerf_syntax::ScopeSet;

    fn sp(start: u32, end: u32) -> Span {
        Span::new(
            FileId(0),
            ByteOffset(start),
            ByteOffset(end),
            ExpansionId::ROOT,
        )
        .expect("test fixture span must be well-formed")
    }

    fn sym(start: u32, end: u32, text: &str) -> SyntaxObject {
        SyntaxObject::symbol(sp(start, end), ScopeSet::new(), Phase::Runtime, text)
            .expect("test fixture symbol must be valid")
    }

    fn int(start: u32, end: u32, value: i64) -> SyntaxObject {
        SyntaxObject::int(sp(start, end), ScopeSet::new(), Phase::Runtime, value)
    }

    fn lst(start: u32, end: u32, items: Vec<SyntaxObject>) -> SyntaxObject {
        SyntaxObject::list(sp(start, end), ScopeSet::new(), Phase::Runtime, items)
    }

    // ---------- positive ----------

    #[test]
    fn atoms_expand_to_their_literal_kinds() {
        let mut ctx = ExpandCtx::new();
        let cases = [
            (int(0, 2, 42), "literal"),
            (
                SyntaxObject::float(sp(0, 3), ScopeSet::new(), Phase::Runtime, 2.5),
                "literal",
            ),
            (
                SyntaxObject::bool(sp(0, 2), ScopeSet::new(), Phase::Runtime, true),
                "literal",
            ),
            (
                SyntaxObject::string(sp(0, 3), ScopeSet::new(), Phase::Runtime, "s".to_owned()),
                "literal",
            ),
            // `nil` is the reserved literal keyword.
            (sym(0, 3, "nil"), "literal"),
        ];
        for (stx, kind) in &cases {
            let expr = expand(&mut ctx, stx).expect("atom must expand");
            assert_eq!(expr.kind_name(), *kind);
        }
        let nil_expr = expand(&mut ctx, &sym(0, 3, "nil")).expect("nil expands");
        assert_eq!(
            nil_expr,
            CoreExpr::Literal {
                span: sp(0, 3),
                value: LiteralValue::Nil
            }
        );
    }

    #[test]
    fn param_reference_resolves_through_coloring() {
        let mut ctx = ExpandCtx::new();
        // (fn (x) x)
        let form = lst(
            0,
            9,
            vec![
                sym(0, 2, "fn"),
                lst(4, 7, vec![sym(5, 6, "x")]),
                sym(8, 9, "x"),
            ],
        );
        let expr = expand(&mut ctx, &form).expect("fn form must expand");
        match expr {
            CoreExpr::Fn { params, body, .. } => {
                assert_eq!(params.len(), 1);
                assert_eq!(params[0].as_str(), "x");
                assert_eq!(*body, CoreExpr::var(sp(8, 9), "x").unwrap());
            }
            other => panic!("expected fn, got {other}"),
        }
    }

    #[test]
    fn let_binds_progressively_like_let_star() {
        let mut ctx = ExpandCtx::new();
        // (let ((a 1) (b a)) b) — b's value sees a (let* order).
        let form = lst(
            0,
            22,
            vec![
                sym(0, 3, "let"),
                lst(
                    5,
                    15,
                    vec![
                        lst(6, 10, vec![sym(7, 8, "a"), int(9, 10, 1)]),
                        lst(12, 15, vec![sym(13, 14, "b"), sym(14, 15, "a")]),
                    ],
                ),
                sym(18, 19, "b"),
            ],
        );
        let expr = expand(&mut ctx, &form).expect("let form must expand");
        match expr {
            CoreExpr::Let { bindings, body, .. } => {
                assert_eq!(bindings.len(), 2);
                assert_eq!(bindings[0].name.as_str(), "a");
                assert_eq!(bindings[1].name.as_str(), "b");
                // b's value is a Var reference to a — visible in let* order.
                assert_eq!(bindings[1].value, CoreExpr::var(sp(14, 15), "a").unwrap());
                assert_eq!(*body, CoreExpr::var(sp(18, 19), "b").unwrap());
            }
            other => panic!("expected let, got {other}"),
        }
    }

    #[test]
    fn do_desugars_to_discard_let_chain() {
        let mut ctx = ExpandCtx::new();
        // (do 1 2) → Let{[_ ← 1], 2}
        let form = lst(0, 8, vec![sym(0, 2, "do"), int(3, 4, 1), int(6, 7, 2)]);
        let expr = expand(&mut ctx, &form).expect("do form must expand");
        match expr {
            CoreExpr::Let { bindings, body, .. } => {
                assert_eq!(bindings.len(), 1);
                assert_eq!(bindings[0].name.as_str(), "_");
                assert_eq!(
                    bindings[0].value,
                    CoreExpr::Literal {
                        span: sp(3, 4),
                        value: LiteralValue::Int(1)
                    }
                );
                assert_eq!(
                    *body,
                    CoreExpr::Literal {
                        span: sp(6, 7),
                        value: LiteralValue::Int(2)
                    }
                );
            }
            other => panic!("expected let, got {other}"),
        }
        // (do e) is the identity.
        let single = lst(0, 6, vec![sym(0, 2, "do"), int(3, 4, 9)]);
        let expr = expand(&mut ctx, &single).expect("single-form do expands");
        assert_eq!(
            expr,
            CoreExpr::Literal {
                span: sp(3, 4),
                value: LiteralValue::Int(9)
            }
        );
    }

    #[test]
    fn fn_if_apply_compose_the_fib_shape() {
        let mut ctx = ExpandCtx::new();
        // (fn (n) (if (< n 2) n (+ n 1))) — globals `<` and `+`.
        let form = lst(
            0,
            30,
            vec![
                sym(0, 2, "fn"),
                lst(4, 7, vec![sym(5, 6, "n")]),
                lst(
                    8,
                    29,
                    vec![
                        sym(9, 11, "if"),
                        lst(
                            13,
                            19,
                            vec![sym(14, 15, "<"), sym(16, 17, "n"), int(18, 19, 2)],
                        ),
                        sym(21, 22, "n"),
                        lst(
                            24,
                            29,
                            vec![sym(25, 26, "+"), sym(27, 28, "n"), int(28, 29, 1)],
                        ),
                    ],
                ),
            ],
        );
        let expr = expand(&mut ctx, &form).expect("fib shape must expand");
        match expr {
            CoreExpr::Fn { body, .. } => match *body {
                CoreExpr::If {
                    cond,
                    then_branch,
                    else_branch,
                    ..
                } => {
                    assert!(matches!(*cond, CoreExpr::Apply { .. }));
                    assert_eq!(*then_branch, CoreExpr::var(sp(21, 22), "n").unwrap());
                    assert!(matches!(*else_branch, CoreExpr::Apply { .. }));
                }
                other => panic!("expected if body, got {other}"),
            },
            other => panic!("expected fn, got {other}"),
        }
    }

    // ---------- negative ----------

    #[test]
    fn unbound_symbol_fails_with_name_and_span() {
        let mut ctx = ExpandCtx::new();
        let err = expand(&mut ctx, &sym(7, 10, "fib")).expect_err("fib must be unbound");
        assert_eq!(
            err,
            ExpandError::UnboundIdentifier {
                name: Symbol::new("fib").expect("fixture symbol must be valid"),
                span: sp(7, 10)
            }
        );
    }

    #[test]
    fn unbound_in_operand_position_fails() {
        let mut ctx = ExpandCtx::new();
        // (+ 1 undefined-thing)
        let form = lst(
            0,
            21,
            vec![sym(1, 2, "+"), int(4, 5, 1), sym(7, 21, "undefined-thing")],
        );
        let err = expand(&mut ctx, &form).expect_err("operand must be unbound");
        match err {
            ExpandError::UnboundIdentifier { name, span } => {
                assert_eq!(name.as_str(), "undefined-thing");
                assert_eq!(span, sp(7, 21));
            }
            other => panic!("expected unbound identifier, got {other}"),
        }
    }

    #[test]
    fn empty_synthesized_form_is_rejected() {
        let mut ctx = ExpandCtx::new();
        let form = lst(0, 2, vec![]);
        let err = expand(&mut ctx, &form).expect_err("empty form must fail");
        assert_eq!(err, ExpandError::EmptyForm { span: sp(0, 2) });
    }

    #[test]
    fn macro_phase_syntax_is_rejected() {
        let mut ctx = ExpandCtx::new();
        let form = SyntaxObject::symbol(sp(0, 3), ScopeSet::new(), Phase::MacroExpansion, "x")
            .expect("fixture symbol must be valid");
        let err = expand(&mut ctx, &form).expect_err("macro-phase must fail");
        assert_eq!(
            err,
            ExpandError::PhaseViolation {
                phase: Phase::MacroExpansion,
                span: sp(0, 3)
            }
        );
    }

    #[test]
    fn fn_without_body_is_malformed() {
        let mut ctx = ExpandCtx::new();
        // (fn (x))
        let form = lst(0, 8, vec![sym(0, 2, "fn"), lst(4, 7, vec![sym(5, 6, "x")])]);
        let err = expand(&mut ctx, &form).expect_err("fn without body must fail");
        assert_eq!(err, malformed("fn", sp(0, 8)));
    }

    #[test]
    fn if_with_two_operands_is_malformed() {
        let mut ctx = ExpandCtx::new();
        // (if 1 2)
        let form = lst(0, 8, vec![sym(0, 2, "if"), int(4, 5, 1), int(6, 7, 2)]);
        let err = expand(&mut ctx, &form).expect_err("two-armed if must fail");
        assert_eq!(err, malformed("if", sp(0, 8)));
    }

    #[test]
    fn let_with_short_binding_pair_is_malformed() {
        let mut ctx = ExpandCtx::new();
        // (let ((x)) x)
        let form = lst(
            0,
            13,
            vec![
                sym(0, 3, "let"),
                lst(5, 9, vec![lst(6, 9, vec![sym(7, 8, "x")])]),
                sym(11, 12, "x"),
            ],
        );
        let err = expand(&mut ctx, &form).expect_err("short pair must fail");
        assert_eq!(err, malformed("let", sp(0, 13)));
    }

    #[test]
    fn duplicate_params_reassert_via_core() {
        let mut ctx = ExpandCtx::new();
        // (fn (x x) x)
        let form = lst(
            0,
            12,
            vec![
                sym(0, 2, "fn"),
                lst(4, 9, vec![sym(5, 6, "x"), sym(7, 8, "x")]),
                sym(11, 12, "x"),
            ],
        );
        let err = expand(&mut ctx, &form).expect_err("duplicate params must fail");
        match err {
            ExpandError::Core { source, .. } => {
                assert_eq!(
                    source,
                    kerf_core::CoreError::DuplicateParam {
                        // §9.65 EXP-4: interned identity payload.
                        name: Symbol::new("x").expect("fixture symbol must be valid")
                    }
                );
            }
            other => panic!("expected core error, got {other}"),
        }
    }

    #[test]
    fn duplicate_handlers_reassert_via_core() {
        let mut ctx = ExpandCtx::new();
        // (handle 1 (E 2) (E 3)) — literal handlers keep the
        // duplicate check the first failure.
        let form = lst(
            0,
            20,
            vec![
                sym(0, 6, "handle"),
                int(7, 8, 1),
                lst(9, 14, vec![sym(10, 11, "E"), int(13, 14, 2)]),
                lst(15, 20, vec![sym(16, 17, "E"), int(18, 19, 3)]),
            ],
        );
        let err = expand(&mut ctx, &form).expect_err("duplicate handlers must fail");
        match err {
            ExpandError::Core { source, .. } => {
                assert_eq!(
                    source,
                    kerf_core::CoreError::DuplicateHandler {
                        // §9.65 EXP-5: interned identity payload.
                        effect: Symbol::new("E").expect("fixture symbol must be valid")
                    }
                );
            }
            other => panic!("expected core error, got {other}"),
        }
    }

    #[test]
    fn bare_top_level_expression_is_rejected() {
        // (fib 10) at module top level.
        let form = lst(0, 8, vec![sym(1, 4, "fib"), int(5, 7, 10)]);
        let err = expand_program(&[form]).expect_err("bare expression must fail");
        assert_eq!(err, ExpandError::TopLevelExpression { span: sp(0, 8) });
    }

    #[test]
    fn set_to_unbound_target_fails() {
        let mut ctx = ExpandCtx::new();
        // (set! nope 1)
        let form = lst(
            0,
            12,
            vec![sym(0, 4, "set!"), sym(5, 9, "nope"), int(10, 11, 1)],
        );
        let err = expand(&mut ctx, &form).expect_err("unbound set! target must fail");
        assert_eq!(
            err,
            ExpandError::UnboundIdentifier {
                name: Symbol::new("nope").expect("fixture symbol must be valid"),
                span: sp(5, 9)
            }
        );
    }

    #[test]
    fn deep_tree_hits_the_expansion_budget_exactly() {
        // A pure-application chain of nesting N recurses N+1 levels
        // deep (the head atom adds one transient level), so nesting
        // EXPANSION_LIMIT - 1 passes and nesting EXPANSION_LIMIT
        // fails — the budget boundary in both directions. The head is
        // a Stage 0 global and the innermost atom a literal so the
        // only possible failure is the budget itself.
        let build = |depth: usize| {
            let mut node = int(0, 1, 42);
            for _ in 0..depth {
                node = lst(0, 2, vec![sym(0, 1, "+"), node]);
            }
            node
        };
        let mut ctx = ExpandCtx::new();
        let within = build(crate::EXPANSION_LIMIT - 1);
        expand(&mut ctx, &within).expect("within-budget tree must expand");
        let beyond = build(crate::EXPANSION_LIMIT);
        let err = expand(&mut ctx, &beyond).expect_err("over-budget tree must fail");
        assert_eq!(
            err,
            ExpandError::ExpansionDepthExceeded {
                limit: crate::EXPANSION_LIMIT,
                span: sp(0, 1)
            }
        );
    }

    // ---------- sub-stage 0.9: quote ----------

    #[test]
    fn quote_atoms_expand_to_their_literal_kinds() {
        let mut ctx = ExpandCtx::new();
        let cases = [
            (int(0, 2, 42), "int"),
            (
                SyntaxObject::float(sp(0, 3), ScopeSet::new(), Phase::Runtime, 2.5),
                "float",
            ),
            (
                SyntaxObject::bool(sp(0, 4), ScopeSet::new(), Phase::Runtime, true),
                "bool",
            ),
            (
                SyntaxObject::string(sp(0, 3), ScopeSet::new(), Phase::Runtime, "s".to_owned()),
                "string",
            ),
            // The reserved literal keyword quotes to Nil.
            (sym(0, 3, "nil"), "nil"),
        ];
        for (stx, kind) in &cases {
            let quoted = lst(0, 10, vec![sym(0, 5, "quote"), stx.clone()]);
            let expr = expand(&mut ctx, &quoted).expect("atom quote must expand");
            let value = match &expr {
                CoreExpr::Literal { value, .. } => value.clone(),
                other => panic!("expected a literal, got {other:?}"),
            };
            assert_eq!(value.kind_name(), *kind);
        }
    }

    #[test]
    fn quote_list_folds_into_a_pair_chain() {
        // (quote (1 2 3)) → Pair(1, Pair(2, Pair(3, Nil))) — the 0.1
        // LiteralValue::Pair consumption face.
        let mut ctx = ExpandCtx::new();
        let datum = lst(7, 14, vec![int(8, 9, 1), int(10, 11, 2), int(12, 13, 3)]);
        let quoted = lst(0, 16, vec![sym(0, 5, "quote"), datum]);
        let expr = expand(&mut ctx, &quoted).expect("list quote must expand");
        match &expr {
            CoreExpr::Literal {
                value: LiteralValue::Pair(a, b),
                ..
            } => {
                assert_eq!(**a, LiteralValue::Int(1));
                match &**b {
                    LiteralValue::Pair(c, d) => {
                        assert_eq!(**c, LiteralValue::Int(2));
                        match &**d {
                            LiteralValue::Pair(e, f) => {
                                assert_eq!(**e, LiteralValue::Int(3));
                                assert_eq!(**f, LiteralValue::Nil);
                            }
                            other => panic!("expected the innermost pair, got {other:?}"),
                        }
                    }
                    other => panic!("expected the middle pair, got {other:?}"),
                }
            }
            other => panic!("expected a pair chain, got {other:?}"),
        }
    }

    #[test]
    fn quote_rejects_symbol_datums() {
        let mut ctx = ExpandCtx::new();
        let quoted = lst(0, 10, vec![sym(0, 5, "quote"), sym(7, 9, "x")]);
        let err = expand(&mut ctx, &quoted).expect_err("a bare symbol quote must fail closed");
        assert_eq!(err, ExpandError::QuoteUnsupportedDatum { span: sp(7, 9) });
    }

    #[test]
    fn quote_rejects_nested_symbol_datums() {
        let mut ctx = ExpandCtx::new();
        // (quote (1 x)) — the nested symbol carries the error span.
        let datum = lst(7, 12, vec![int(8, 9, 1), sym(10, 11, "x")]);
        let quoted = lst(0, 14, vec![sym(0, 5, "quote"), datum]);
        let err = expand(&mut ctx, &quoted).expect_err("a nested symbol quote must fail closed");
        assert_eq!(err, ExpandError::QuoteUnsupportedDatum { span: sp(10, 11) });
    }

    #[test]
    fn quote_rejects_wrong_arity() {
        let mut ctx = ExpandCtx::new();
        // (quote) — zero datums.
        let empty = lst(0, 7, vec![sym(0, 5, "quote")]);
        let err = expand(&mut ctx, &empty).expect_err("zero-datum quote must fail");
        assert!(matches!(err, ExpandError::MalformedForm { form, .. } if form == "quote"));
        // (quote 1 2) — two datums.
        let extra = lst(0, 12, vec![sym(0, 5, "quote"), int(6, 7, 1), int(8, 9, 2)]);
        let err = expand(&mut ctx, &extra).expect_err("two-datum quote must fail");
        assert!(matches!(err, ExpandError::MalformedForm { form, .. } if form == "quote"));
    }

    // ---------- sub-stage 0.9: define-syntax + macro use ----------

    /// (define-syntax my-if (syntax-rules () ((_ c t e) (if c t e))))
    fn define_syntax_my_if() -> SyntaxObject {
        let clause = lst(
            40,
            63,
            vec![
                lst(
                    41,
                    50,
                    vec![
                        sym(42, 43, "_"),
                        sym(44, 45, "c"),
                        sym(46, 47, "t"),
                        sym(48, 49, "e"),
                    ],
                ),
                lst(
                    51,
                    62,
                    vec![
                        sym(52, 54, "if"),
                        sym(55, 56, "c"),
                        sym(57, 58, "t"),
                        sym(59, 60, "e"),
                    ],
                ),
            ],
        );
        lst(
            0,
            70,
            vec![
                sym(1, 14, "define-syntax"),
                sym(15, 20, "my-if"),
                lst(
                    21,
                    65,
                    vec![sym(22, 34, "syntax-rules"), sym(35, 38, "nil"), clause],
                ),
            ],
        )
    }

    #[test]
    fn define_syntax_emits_the_declaration_record() {
        let items = expand_program(&[define_syntax_my_if()]).expect("declaration must expand");
        assert_eq!(items.len(), 1);
        assert_eq!(items[0].kind_name(), "define-syntax");
        assert_eq!(items[0].span(), sp(0, 70));
    }

    #[test]
    fn macro_use_expands_to_the_core_form_shape() {
        // (define r (my-if true 1 2)) — the spliced condition keeps
        // its own span; the introduced `if` is generation 1.
        let use_form = lst(
            80,
            100,
            vec![
                sym(81, 86, "my-if"),
                SyntaxObject::bool(sp(87, 91), ScopeSet::new(), Phase::Runtime, true),
                int(92, 93, 1),
                int(94, 95, 2),
            ],
        );
        let program = lst(
            79,
            108,
            vec![sym(80, 86, "define"), sym(87, 88, "r"), use_form],
        );
        let items =
            expand_program(&[define_syntax_my_if(), program]).expect("the macro use must expand");
        let value = match &items[1] {
            ModuleItem::Define { value, .. } => value.clone(),
            other => panic!("expected a define, got {other:?}"),
        };
        match &value {
            CoreExpr::If { cond, .. } => {
                // The spliced condition kept its use-site span.
                assert_eq!(cond.span(), sp(87, 91));
            }
            other => panic!("expected an if, got {other:?}"),
        }
    }

    #[test]
    fn unbound_head_fails_closed_as_an_identifier() {
        // A head naming nothing is ambiguous between a function call
        // and a macro use: the unified Racket judgment — one
        // UnboundIdentifier error serves both (the dedicated
        // macro-phase family starts at pattern matching).
        let mut ctx = ExpandCtx::new();
        let use_form = lst(0, 6, vec![sym(0, 5, "ghost"), int(0, 1, 1)]);
        let err = expand(&mut ctx, &use_form).expect_err("an unbound head must fail");
        assert_eq!(
            err,
            ExpandError::UnboundIdentifier {
                name: Symbol::new("ghost").expect("fixture symbol must be valid"),
                span: sp(0, 5)
            }
        );
    }

    #[test]
    fn use_before_definition_is_unbound() {
        // The use form comes first: the transformer is not yet
        // registered (sequential declaration order) — the head falls
        // through to the unified unbound-identifier judgment.
        let use_form = lst(
            0,
            22,
            vec![
                sym(1, 6, "my-if"),
                sym(7, 11, "true"),
                int(12, 13, 1),
                int(14, 15, 2),
            ],
        );
        let program = lst(
            23,
            50,
            vec![sym(24, 30, "define"), sym(31, 32, "r"), use_form],
        );
        let err = expand_program(&[program, define_syntax_my_if()])
            .expect_err("use before definition must fail");
        assert!(
            matches!(err, ExpandError::UnboundIdentifier { name, .. } if name.as_str() == "my-if")
        );
    }

    #[test]
    fn pattern_mismatch_reports_the_macro_name() {
        // (my-if true 1) — three operands demanded, two supplied.
        let use_form = lst(
            80,
            95,
            vec![sym(81, 86, "my-if"), sym(87, 91, "true"), int(92, 93, 1)],
        );
        let program = lst(
            96,
            120,
            vec![sym(97, 103, "define"), sym(104, 105, "r"), use_form],
        );
        let err = expand_program(&[define_syntax_my_if(), program])
            .expect_err("a pattern mismatch must fail closed");
        // The use head's span (the rustc convention: point at the
        // call, not the declaration).
        assert_eq!(
            err,
            ExpandError::MacroPatternMismatch {
                name: Symbol::new("my-if").expect("fixture symbol must be valid"),
                span: sp(81, 86)
            }
        );
    }

    #[test]
    fn self_recursive_macro_hits_the_depth_budget() {
        // (define-syntax loopy (syntax-rules () ((_) (loopy))))
        let clause = lst(
            40,
            56,
            vec![
                lst(41, 45, vec![sym(42, 43, "_")]),
                lst(46, 55, vec![sym(47, 52, "loopy")]),
            ],
        );
        let loopy_def = lst(
            0,
            70,
            vec![
                sym(1, 14, "define-syntax"),
                sym(15, 20, "loopy"),
                lst(
                    21,
                    65,
                    vec![sym(22, 34, "syntax-rules"), sym(35, 38, "nil"), clause],
                ),
            ],
        );
        let use_form = lst(80, 88, vec![sym(81, 86, "loopy")]);
        let program = lst(
            90,
            110,
            vec![sym(91, 97, "define"), sym(98, 99, "r"), use_form],
        );
        let err = expand_program(&[loopy_def, program])
            .expect_err("a self-recursive macro must hit the budget");
        assert!(matches!(err, ExpandError::ExpansionDepthExceeded { .. }));
    }

    #[test]
    fn module_scoped_macros_vanish_outside_their_module() {
        // (module inner (define-syntax ...)) then a top-level use:
        // the inner frame (with the macro) is popped — the head falls
        // through to the unified unbound-identifier judgment
        // (docs/stage0.md §8.9 module isolation).
        let module_form = lst(
            0,
            70,
            vec![
                sym(1, 7, "module"),
                sym(8, 13, "inner"),
                define_syntax_my_if(),
            ],
        );
        let use_form = lst(
            80,
            100,
            vec![
                sym(81, 86, "my-if"),
                sym(87, 91, "true"),
                int(92, 93, 1),
                int(94, 95, 2),
            ],
        );
        let program = lst(
            101,
            125,
            vec![sym(102, 108, "define"), sym(109, 110, "r"), use_form],
        );
        let err = expand_program(&[module_form, program])
            .expect_err("a module-scoped macro must vanish outside");
        assert!(
            matches!(err, ExpandError::UnboundIdentifier { name, .. } if name.as_str() == "my-if")
        );
    }

    #[test]
    fn define_syntax_rejects_malformed_shapes() {
        // Two items only: (define-syntax m).
        let bad = lst(0, 20, vec![sym(1, 14, "define-syntax"), sym(15, 16, "m")]);
        let err = expand_program(&[bad]).expect_err("a two-item define-syntax must fail");
        assert!(matches!(err, ExpandError::MalformedForm { form, .. } if form == "define-syntax"));
        // Reserved name: (define-syntax if ...).
        let mut reserved = define_syntax_my_if();
        if let StxDatum::List(items) = &mut reserved.datum {
            items[1] = sym(15, 17, "if");
        }
        let err = expand_program(&[reserved]).expect_err("a reserved macro name must fail");
        assert!(matches!(err, ExpandError::MalformedForm { form, .. } if form == "define-syntax"));
        // Non-symbol name: (define-syntax 7 ...).
        let mut numbered = define_syntax_my_if();
        if let StxDatum::List(items) = &mut numbered.datum {
            items[1] = int(15, 16, 7);
        }
        let err = expand_program(&[numbered]).expect_err("a non-symbol macro name must fail");
        assert!(matches!(err, ExpandError::MalformedForm { form, .. } if form == "define-syntax"));
    }

    // ---------- sub-stage 0.9: hygiene (defense family) ----------

    /// (define-syntax m (syntax-rules () ((_ e) (fn (tmp) (tmp e)))))
    /// — an introduced binding with an introduced reference around a
    /// spliced use-site expression.
    fn define_syntax_wrap() -> SyntaxObject {
        let clause = lst(
            40,
            70,
            vec![
                lst(41, 45, vec![sym(42, 43, "_"), sym(44, 45, "e")]),
                lst(
                    46,
                    69,
                    vec![
                        sym(47, 49, "fn"),
                        lst(50, 56, vec![sym(51, 54, "tmp")]),
                        lst(57, 68, vec![sym(58, 61, "tmp"), sym(62, 63, "e")]),
                    ],
                ),
            ],
        );
        lst(
            0,
            70,
            vec![
                sym(1, 14, "define-syntax"),
                sym(15, 16, "m"),
                lst(
                    21,
                    65,
                    vec![sym(22, 34, "syntax-rules"), sym(35, 38, "nil"), clause],
                ),
            ],
        )
    }

    #[test]
    fn introduced_binding_renames_away_from_the_use_site_name() {
        // (define f (fn (tmp) (m tmp))) — the use-site `tmp` argument
        // collides with the introduced binder: rename-on-capture makes
        // the introduced binder `tmp__macro_0` so the name-based back
        // half cannot conflate them. The expansion succeeds and the
        // introduced parameter carries the fresh name.
        let use_form = lst(80, 90, vec![sym(81, 82, "m"), sym(83, 86, "tmp")]);
        let inner = lst(
            71,
            92,
            vec![
                sym(72, 74, "fn"),
                lst(75, 80, vec![sym(76, 79, "tmp")]),
                use_form,
            ],
        );
        let program = lst(
            93,
            120,
            vec![sym(94, 100, "define"), sym(101, 102, "f"), inner],
        );
        let items = expand_program(&[define_syntax_wrap(), program])
            .expect("the hygienic wrap must expand");
        // Walk to the inner fn's parameter list and assert the fresh
        // name (the introduced binder was renamed, the use-site param
        // was not).
        let value = match &items[1] {
            ModuleItem::Define { value, .. } => value.clone(),
            other => panic!("expected a define, got {other:?}"),
        };
        match &value {
            CoreExpr::Fn { params, body, .. } => {
                // The use-site parameter keeps its name.
                let names: Vec<&str> = params.iter().map(|p| p.as_str()).collect();
                assert_eq!(names, vec!["tmp"]);
                // The body is the introduced fn with the renamed
                // parameter.
                match &**body {
                    CoreExpr::Fn {
                        params: inner_params,
                        ..
                    } => {
                        let inner_names: Vec<&str> =
                            inner_params.iter().map(|p| p.as_str()).collect();
                        assert_eq!(inner_names, vec!["tmp__macro_0"]);
                    }
                    other => panic!("expected the introduced fn, got {other:?}"),
                }
            }
            other => panic!("expected the outer fn, got {other:?}"),
        }
    }

    #[test]
    fn use_site_binding_does_not_capture_an_introduced_reference() {
        // (define-syntax m (syntax-rules () ((_) tmp))) — a free
        // introduced reference to `tmp`, unbound at the definition
        // site. Used inside a let that binds tmp: the coloring keeps
        // the introduced reference apart from the use-site binding, so
        // the reference stays unbound — exactly the Racket judgment
        // (no accidental capture), reported fail-closed.
        let clause = lst(
            40,
            50,
            vec![lst(41, 44, vec![sym(42, 43, "_")]), sym(45, 48, "tmp")],
        );
        let def = lst(
            0,
            70,
            vec![
                sym(1, 14, "define-syntax"),
                sym(15, 16, "m"),
                lst(
                    21,
                    65,
                    vec![sym(22, 34, "syntax-rules"), sym(35, 38, "nil"), clause],
                ),
            ],
        );
        // (define r (let ((tmp 1)) (m)))
        let use_form = lst(80, 84, vec![sym(81, 82, "m")]);
        let let_form = lst(
            71,
            95,
            vec![
                sym(72, 75, "let"),
                lst(
                    76,
                    85,
                    vec![lst(77, 84, vec![sym(78, 81, "tmp"), int(82, 83, 1)])],
                ),
                use_form,
            ],
        );
        let program = lst(
            96,
            120,
            vec![sym(97, 103, "define"), sym(104, 105, "r"), let_form],
        );
        let err = expand_program(&[def, program])
            .expect_err("the introduced free reference must stay unbound");
        assert!(
            matches!(err, ExpandError::UnboundIdentifier { name, .. } if name.as_str() == "tmp")
        );
    }

    #[test]
    fn error_payloads_round_trip_through_the_single_pool() {
        // §9.65 EXP-1/EXP-2: name payloads are interned identities.
        // The expected values are built through the single pool — the
        // equality holds only because both sides resolve to the same
        // interned entry (index equality), which is exactly the
        // contract the .krf parity decoder depends on when it
        // rebuilds a payload from oracle text. A de-interned String
        // copy would compare by text; a Symbol payload compares by
        // pool entry — this guard pins the stronger contract.
        // (1) unbound identifier from source.
        let mut ctx = ExpandCtx::new();
        let err =
            expand(&mut ctx, &sym(3, 11, "pool-probe")).expect_err("pool-probe must be unbound");
        assert_eq!(
            err,
            ExpandError::UnboundIdentifier {
                name: Symbol::new("pool-probe").expect("fixture symbol must be valid"),
                span: sp(3, 11)
            }
        );
        // (2) macro mismatch from a registered transformer: the error
        // carries the declaration-time pool entry, not a fresh copy.
        let clause = lst(
            40,
            56,
            vec![
                lst(41, 50, vec![sym(42, 43, "_"), sym(44, 49, "true")]),
                int(50, 51, 1),
            ],
        );
        let spec = lst(
            21,
            65,
            vec![sym(22, 34, "syntax-rules"), sym(35, 38, "nil"), clause],
        );
        let def = lst(
            0,
            70,
            vec![sym(1, 14, "define-syntax"), sym(15, 20, "probe-m"), spec],
        );
        let use_form = lst(
            80,
            95,
            vec![sym(81, 88, "probe-m"), sym(89, 93, "true"), int(93, 94, 2)],
        );
        let program = lst(
            96,
            120,
            vec![sym(97, 103, "define"), sym(104, 105, "r"), use_form],
        );
        let err =
            expand_program(&[def, program]).expect_err("arity mismatch must fail every clause");
        assert_eq!(
            err,
            ExpandError::MacroPatternMismatch {
                name: Symbol::new("probe-m").expect("fixture symbol must be valid"),
                span: sp(81, 88)
            }
        );
    }

    #[test]
    fn macro_product_generation_increments_per_hop() {
        // (define-syntax outer (syntax-rules () ((_) (inner))))
        // (define-syntax inner (syntax-rules () ((_) 7)))
        // (define r (outer)) — two macro hops: the final literal is
        // generation 2, the intermediate use form generation 1.
        let inner_clause = lst(
            40,
            52,
            vec![lst(41, 44, vec![sym(42, 43, "_")]), int(45, 46, 7)],
        );
        let inner_def = lst(
            0,
            60,
            vec![
                sym(1, 14, "define-syntax"),
                sym(15, 20, "inner"),
                lst(
                    21,
                    55,
                    vec![
                        sym(22, 34, "syntax-rules"),
                        sym(35, 38, "nil"),
                        inner_clause,
                    ],
                ),
            ],
        );
        let outer_clause = lst(
            40,
            56,
            vec![
                lst(41, 44, vec![sym(42, 43, "_")]),
                // The template is the *form* (inner), not the bare
                // identifier — macro dispatch happens on list heads
                // only (the Stage 0 boundary).
                lst(45, 52, vec![sym(46, 51, "inner")]),
            ],
        );
        let outer_def = lst(
            0,
            60,
            vec![
                sym(1, 14, "define-syntax"),
                sym(15, 20, "outer"),
                lst(
                    21,
                    55,
                    vec![
                        sym(22, 34, "syntax-rules"),
                        sym(35, 38, "nil"),
                        outer_clause,
                    ],
                ),
            ],
        );
        let use_form = lst(80, 88, vec![sym(81, 86, "outer")]);
        let program = lst(
            90,
            110,
            vec![sym(91, 97, "define"), sym(98, 99, "r"), use_form],
        );
        let items = expand_program(&[outer_def, inner_def, program]).expect("two hops must expand");
        let value = match &items[2] {
            ModuleItem::Define { value, .. } => value.clone(),
            other => panic!("expected a define, got {other:?}"),
        };
        match &value {
            CoreExpr::Literal { span, .. } => {
                // The literal came from inner's template: generation 2
                // (outer's product was generation 1, inner's
                // use-generation was 1, its introduced nodes are 2).
                assert_eq!(span.expansion_id, ExpansionId(2));
            }
            other => panic!("expected the final literal, got {other:?}"),
        }
    }

    #[test]
    fn top_level_heads_match_dispatch_table() {
        // §9.62 SURF-2: TOP_LEVEL_DECLARATION_HEADS is the single
        // source the driver's REPL consumes. This test pins the const
        // to the dispatch: every const member must take a declaration
        // arm (never a top-level-expression rejection — that is the
        // fail-closed hole a const member without an arm would fall
        // into), and every non-member head must be rejected as a bare
        // top-level expression.
        for head in TOP_LEVEL_DECLARATION_HEADS {
            let mut ctx = ExpandCtx::new();
            let form = lst(
                0,
                8,
                vec![sym(1, (1 + head.len()) as u32, head), sym(40, 44, "x")],
            );
            // Any non-TopLevelExpression outcome (a successful module
            // item or a declaration-specific error such as
            // MalformedForm or a module-load error) proves the head
            // took its dispatch arm.
            if let Err(ExpandError::TopLevelExpression { .. }) = expand_declaration(&mut ctx, &form)
            {
                panic!("const member `{head}` has no dispatch arm");
            }
        }
        for head in ["if", "+", "frobnicate", "set!"] {
            let mut ctx = ExpandCtx::new();
            let form = lst(
                0,
                8,
                vec![sym(1, (1 + head.len()) as u32, head), sym(40, 44, "x")],
            );
            match expand_declaration(&mut ctx, &form) {
                Err(ExpandError::TopLevelExpression { .. }) => {}
                other => panic!("non-member `{head}` must reject: {other:?}"),
            }
        }
    }
}

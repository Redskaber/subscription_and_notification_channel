//! Errors produced by kerf-expander while turning syntax objects into
//! core expressions (docs/stage0.md §19.2 expansion loop).
//!
//! Message shape follows the Rust compiler conventions (SOP §10.5 / R8):
//! lowercase start, no trailing period, payloads in backticks.

use std::error::Error;
use std::fmt;

use kerf_core::CoreError;
use kerf_span::{Span, Symbol};
use kerf_syntax::Phase;

/// Errors raised during macro expansion (sub-stage 0.4).
///
/// Every variant carries the byte-precise [`Span`] of the offending
/// syntax node — the diagnostics framework (plan sub-stage 0.8) renders
/// locations from this payload.
#[derive(Debug, Clone, PartialEq)]
pub enum ExpandError {
    /// An identifier resolved to no binding: not in any lexical scope
    /// reachable through its scope set, and not a Stage 0 global.
    /// SOP §7.1.1 error class 2 (unbound identifier). The name is the
    /// interned identity of the offending atom — the single-pool entry
    /// the syntax tree already carries (§9.65 EXP-1; the K107/K110
    /// rustc discipline: identity payloads are `Symbol`, never a
    /// de-interned text copy). Equality is index equality, which is
    /// what the .krf parity decoder relies on when it rebuilds the
    /// payload through the same pool.
    UnboundIdentifier { name: Symbol, span: Span },
    /// The expansion work budget was exhausted (SOP §7.1.1 error class
    /// 7 — expansion depth exceeded). The reader's 256 nesting cap
    /// bounds *source* trees; this cap independently bounds expansion
    /// work over any tree, including synthesized and (at 0.9)
    /// macro-produced ones.
    ExpansionDepthExceeded { limit: usize, span: Span },
    /// An empty list datum reached the expander directly (SOP §7.1.1
    /// error class 3, expander detection point). The reader already
    /// rejects `()` in source (plan-0.3 decision 3); this is the second
    /// fail-closed layer for synthesized trees.
    EmptyForm { span: Span },
    /// A syntax object outside the runtime phase was submitted for
    /// runtime expansion (docs/stage0.md §8.9 rule 1 — phase closure;
    /// the 0.4 slice of the phase-separation system). The rule
    /// citation lives here on the developer face — user-facing
    /// Display text never cites internal document paths (§9.78
    /// MSG-4, K180: rustc keeps depth behind `--explain` and stable
    /// codes, not inline file citations).
    PhaseViolation { phase: Phase, span: Span },
    /// A special form was used with an unsupported shape (wrong arity,
    /// non-symbol binding position, malformed binding spec or handler
    /// clause).
    MalformedForm { form: &'static str, span: Span },
    /// A bare expression appeared at module top level. The module top
    /// level accepts declarations only (`define` / `require` /
    /// `module`); the top-level expression channel is the `define`
    /// calling form (r110 corpus note) and the driver/REPL composition
    /// (plan sub-stage 0.8).
    TopLevelExpression { span: Span },
    /// A kerf-core validated constructor rejected a name-bearing node
    /// while the expander re-asserted the semantic floor (duplicate
    /// parameters, duplicate handler clauses, invalid symbol text —
    /// the 0.1 constructor contract applied at expansion time).
    Core { source: CoreError, span: Span },
    /// Every clause of a `syntax-rules` transformer failed to match
    /// the use form (sub-stage 0.9). An unbound macro *head* reports
    /// [`ExpandError::UnboundIdentifier`] instead — the unified
    /// Racket judgment (a head naming nothing is ambiguous between a
    /// function call and a macro use; one error serves both). The
    /// name is the transformer's interned declaration identity — the
    /// same single-pool entry `SyntaxRules::parse` received (§9.65
    /// EXP-2/EXP-3; a 4-byte clone, never a text copy).
    MacroPatternMismatch { name: Symbol, span: Span },
    /// `(quote datum)` received a datum the Stage 0 value model cannot
    /// express: symbols (and lists containing them) have no
    /// `LiteralValue` carrier yet — the fail-closed boundary until the
    /// Stage 1 value model (sub-stage 0.9; the 0.1
    /// `LiteralValue::Pair` consumption face covers atoms and proper
    /// lists only).
    QuoteUnsupportedDatum { span: Span },
}

/// The expected-shape vocabulary for the malformed-form family
/// (§9.78 MSG-1): one template per special form, rendered into the
/// Display so the message states what a well-formed use looks like.
///
/// K182/K183 (rustc parser discipline: `expected `;`, found X`; `if`
/// may be missing an `else` clause` — the parser-level shapes name
/// what was expected instead of hedging): a bare `malformed `let`
/// form` collapses four distinct defect classes (wrong arity,
/// non-symbol binding position, malformed binding spec, malformed
/// handler clause — see the `MalformedForm` doc) into one message
/// with zero specificity; the template restores the expected-shape
/// half of the rustc message contract without touching the record
/// grammar the `.krf` parity layer shares.
///
/// The table is a static single source keyed by the same twelve form
/// names the driver's `static_form` decoder maps (the presence guard
/// below iterates the closed set). Templates are prose mirrors of
/// the acceptance checks in `expand.rs` — the drift risk is accepted
/// and documented (a machine check would re-encode the parser, the
/// K180 succinctness ruling prefers one auditable table).
fn form_shape(form: &str) -> &'static str {
    match form {
        "fn" => "(fn (param...) body)",
        "if" => "(if condition then-expr else-expr)",
        "let" => "(let bindings body) with bindings `()`, `(name value)` or `((name value)...)`",
        "do" => "(do body...)",
        "set!" => "(set! name value)",
        "perform" => "(perform effect arg...)",
        "handle" => "(handle body (effect handler)...)",
        "quote" => "(quote datum)",
        "define" => "(define name value) or (define (name param...) body)",
        "require" => "(require \"module-name\") with a string module name",
        "module" => "(module name declaration...)",
        "define-syntax" => "(define-syntax name transformer-spec)",
        // The form set is closed (the twelve heads above); the
        // fallback keeps Display total for any future form without
        // fabricating a shape (fail-closed wording, not a panic).
        _ => "a well-formed form",
    }
}

impl fmt::Display for ExpandError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            // §9.56 DIAG-1: position fragments stay out of Display —
            // the message is general and stands on its own (rustc
            // convention); spans live in the payload and the driver
            // renders them as the `--> file:line:col` location line.
            ExpandError::UnboundIdentifier { name, .. } => {
                write!(
                    f,
                    "unbound identifier `{name}`: not in any lexical scope and not a Stage 0 global"
                )
            }
            ExpandError::ExpansionDepthExceeded { limit, .. } => {
                write!(f, "expansion depth exceeded the limit of {limit}")
            }
            ExpandError::EmptyForm { .. } => {
                f.write_str("empty form cannot be expanded: `()` carries no operator")
            }
            ExpandError::PhaseViolation { phase, .. } => {
                write!(
                    f,
                    "phase violation: `{phase}` syntax is not runtime-phase code"
                )
            }
            ExpandError::MalformedForm { form, .. } => {
                write!(f, "malformed `{form}` form: expected {}", form_shape(form))
            }
            ExpandError::TopLevelExpression { .. } => {
                f.write_str(
                    "top-level expression is not allowed: only `define`, `require` and `module` declarations are valid at module top level",
                )
            }
            ExpandError::Core { source, .. } => {
                write!(f, "core construction failed: {source}")
            }
            ExpandError::MacroPatternMismatch { name, .. } => {
                write!(
                    f,
                    "macro `{name}` matched no clause: the use form fits none of its syntax-rules patterns"
                )
            }
            ExpandError::QuoteUnsupportedDatum { .. } => {
                f.write_str(
                    "quote cannot carry this datum: symbol data has no Stage 0 value model (atoms and proper lists only)",
                )
            }
        }
    }
}

impl Error for ExpandError {
    fn source(&self) -> Option<&(dyn Error + 'static)> {
        match self {
            ExpandError::Core { source, .. } => Some(source),
            _ => None,
        }
    }
}

impl ExpandError {
    /// The byte-precise location of the offending syntax node.
    pub fn span(&self) -> Span {
        match self {
            ExpandError::UnboundIdentifier { span, .. }
            | ExpandError::ExpansionDepthExceeded { span, .. }
            | ExpandError::EmptyForm { span }
            | ExpandError::PhaseViolation { span, .. }
            | ExpandError::MalformedForm { span, .. }
            | ExpandError::TopLevelExpression { span }
            | ExpandError::MacroPatternMismatch { span, .. }
            | ExpandError::QuoteUnsupportedDatum { span }
            | ExpandError::Core { span, .. } => *span,
        }
    }
}

#[cfg(test)]
mod tests {
    //! Unit tests for the ExpandError rendering surface (sub-stage test
    //! doc FP1; R8 message-shape assertions).

    use super::*;
    use kerf_span::{ByteOffset, ExpansionId, FileId};

    fn span(start: u32, end: u32) -> Span {
        Span::new(
            FileId(0),
            ByteOffset(start),
            ByteOffset(end),
            ExpansionId::ROOT,
        )
        .expect("test fixture span must be well-formed")
    }

    // ---------- negative (error surface) ----------

    #[test]
    fn display_unbound_mentions_name_and_stands_alone() {
        // §9.56 DIAG-1: position-free — the span lives in the payload
        // (`span()`), never in the Display. §9.65 EXP-1: the payload
        // is the interned identity (Symbol), rendered through the
        // `as_str` bridge — the message stays byte-identical.
        let err = ExpandError::UnboundIdentifier {
            name: Symbol::new("fib").expect("fixture symbol must be valid"),
            span: span(7, 10),
        };
        let rendered = err.to_string();
        assert!(rendered.starts_with("unbound identifier `fib`"));
        assert!(!rendered.contains("#0:"), "no span fragment in Display");
        assert!(!rendered.ends_with('.'));
        assert_eq!(err.span(), span(7, 10), "payload keeps it");
    }

    #[test]
    fn display_depth_mentions_limit() {
        let err = ExpandError::ExpansionDepthExceeded {
            limit: 512,
            span: span(0, 1),
        };
        let rendered = err.to_string();
        assert!(rendered.contains("512"));
        assert!(rendered.starts_with("expansion depth exceeded"));
        assert!(!rendered.ends_with('.'));
    }

    #[test]
    fn display_phase_violation_mentions_phase() {
        let err = ExpandError::PhaseViolation {
            phase: Phase::MacroExpansion,
            span: span(3, 9),
        };
        let rendered = err.to_string();
        assert!(rendered.contains("macro expansion"));
        assert!(rendered.contains("runtime-phase"));
        assert!(rendered.starts_with("phase violation"));
    }

    #[test]
    fn display_malformed_mentions_form_name() {
        let err = ExpandError::MalformedForm {
            form: "let",
            span: span(0, 12),
        };
        let rendered = err.to_string();
        assert!(rendered.contains("`let`"));
        assert!(rendered.starts_with("malformed"));
        assert!(!rendered.ends_with('.'));
    }

    /// §9.78 MSG-1 guard: every form of the closed twelve-name set
    /// (the driver `static_form` decoder's table) renders an
    /// expected-shape template — the malformed message states what a
    /// well-formed use looks like (K182/K183), never a bare hedge.
    #[test]
    fn display_malformed_carries_expected_shape_for_every_form() {
        const FORMS: [&str; 12] = [
            "fn",
            "if",
            "let",
            "do",
            "set!",
            "perform",
            "handle",
            "quote",
            "define",
            "require",
            "module",
            "define-syntax",
        ];
        for form in FORMS {
            let err = ExpandError::MalformedForm {
                form,
                span: span(0, 6),
            };
            let rendered = err.to_string();
            assert!(
                rendered.starts_with(&format!("malformed `{form}` form: expected (")),
                "form `{form}` must open its expected shape: {rendered}"
            );
            // The template must describe a shape, not a hedge.
            assert!(
                rendered.len() > format!("malformed `{form}` form: expected ").len() + 8,
                "form `{form}` template must carry real shape text: {rendered}"
            );
            assert!(!rendered.ends_with('.'));
        }
        // The fallback stays total without fabricating a shape.
        let unknown = ExpandError::MalformedForm {
            form: "future-form",
            span: span(0, 6),
        };
        assert_eq!(
            unknown.to_string(),
            "malformed `future-form` form: expected a well-formed form"
        );
    }

    /// §9.78 MSG-4 guard: user-facing Display never cites internal
    /// document paths (K180 — depth lives behind explain channels,
    /// not inline citations). The rule reference stays on the doc
    /// comment (developer face).
    #[test]
    fn display_family_carries_no_internal_citations() {
        let phase = ExpandError::PhaseViolation {
            phase: Phase::MacroExpansion,
            span: span(3, 9),
        }
        .to_string();
        assert!(!phase.contains("docs/"), "no internal path: {phase}");
        assert!(!phase.contains("§"), "no section citation: {phase}");
        for form in ["fn", "if", "let", "quote"] {
            let rendered = ExpandError::MalformedForm {
                form,
                span: span(0, 6),
            }
            .to_string();
            assert!(!rendered.contains("docs/"), "no internal path: {rendered}");
            assert!(!rendered.contains("§"), "no section citation: {rendered}");
        }
    }

    #[test]
    fn display_core_wraps_source_without_position() {
        // §9.65 EXP-4: interned identity payload (co-varies with the
        // wrapped core family).
        let source = CoreError::DuplicateParam {
            name: Symbol::new("x").expect("fixture symbol must be valid"),
        };
        let err = ExpandError::Core {
            source,
            span: span(4, 20),
        };
        let rendered = err.to_string();
        assert!(rendered.contains("duplicate parameter `x`"));
        assert!(!rendered.contains("#0:"), "no span fragment in Display");
        assert_eq!(err.span(), span(4, 20));
        // Error::source chains to the wrapped CoreError (composition
        // contract — std::error::Error plumbing for the 0.8 renderer).
        assert!(err.source().is_some());
    }

    #[test]
    fn display_pattern_mismatch_mentions_macro_name() {
        // §9.65 EXP-2: interned identity payload; Display rides the
        // same `as_str` bridge, byte-identical to the String era.
        let err = ExpandError::MacroPatternMismatch {
            name: Symbol::new("m").expect("fixture symbol must be valid"),
            span: span(0, 9),
        };
        let rendered = err.to_string();
        assert!(rendered.starts_with("macro `m` matched no clause"));
        assert!(rendered.contains("syntax-rules"));
        assert!(!rendered.ends_with('.'));
    }

    #[test]
    fn display_quote_unsupported_mentions_the_boundary() {
        let err = ExpandError::QuoteUnsupportedDatum { span: span(6, 7) };
        let rendered = err.to_string();
        assert!(rendered.starts_with("quote cannot carry this datum"));
        assert!(rendered.contains("symbol data"));
        assert!(!rendered.ends_with('.'));
    }
}

//! kerf-reader — the surface-syntax reader (Layer 2).
//!
//! Charter (docs/stage0.md §278 capability signature `read : string →
//! Result<SyntaxObject, ReadError>` and §8.1 typed-token-stream
//! contract): a UTF-8-aware lexer plus a recursive-descent parser
//! turning source text into syntax-object trees. The Stage 0 skin is
//! the S-expression scaffold (docs/stage0.md §7.3.5/§7.3.6, SOP §2.5 —
//! removed from the bootstrap chain at Stage 2b, never a permanent
//! internal IR).
//!
//! Public surface:
//! - [`lex`] — the §8.1 tokenize contract (lossless coverage, precise
//!   spans, structured errors).
//! - [`read_program`] — the §278 read contract, pluralized to a whole
//!   program (a source file is a sequence of top-level forms).
//!
//! Naming (SOP §21.12): token types carry the `Stx` prefix
//! (`StxToken`, `StxTokenKind`); the error surface is `ReadError` per
//! the capability table.

mod error;
mod lexer;
mod parser;
mod token;

// Explicit re-export list (SOP §10.1 rule 4 — glob re-exports are forbidden).
pub use error::ReadError;
pub use lexer::lex;
pub use parser::{NESTING_LIMIT, parse_program};
pub use token::{Delimiter, StxToken, StxTokenKind};

use kerf_span::FileId;
use kerf_syntax::SyntaxObject;

/// Read a whole program: source text → top-level forms.
///
/// Equivalent to [`lex`] followed by [`parse_program`]; both phases
/// share the single [`ReadError`] surface.
pub fn read_program(file_id: FileId, source: &str) -> Result<Vec<SyntaxObject>, ReadError> {
    let tokens = lex(file_id, source)?;
    parse_program(file_id, &tokens)
}

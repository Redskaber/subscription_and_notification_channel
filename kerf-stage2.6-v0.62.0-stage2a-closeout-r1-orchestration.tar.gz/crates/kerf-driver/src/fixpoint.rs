//! The 2.5 fixpoint window (stage-2-plan §2 row 2.5; SOP §21.3 exit
//! criterion (2) — "compiling itself twice yields identical
//! results"; §9.25 BS-E trusting-trust lineage: the auditable seed +
//! the parity oracle chain + the fixpoint determinism).
//!
//! Two faces live here:
//!
//! * **MUV ② — the fixpoint driver**
//!   ([`fixpoint_selfhost_compiler`]): the compiler compiled by
//!   itself, EXECUTED, reproduces its own compilation byte-for-byte.
//!   The baked-input hosting convention makes the operational shape:
//!   1. `S` = the compiler's structural source (the hosting tail
//!      `(define result (cp-run items))` stripped — the CP6
//!      selfhost-bare precedent);
//!   2. **C(S)**: the `.krf` compiler compiles `S`'s own items (the
//!      CP-1 hosting convention: the oracle reader + expander are
//!      the tree truth sources) and the product is REBUILT into a
//!      real [`Bytecode`] (MUV ①'s face) — `b_self`;
//!   3. **C(C(S))**: the assembled self-applied program `A(S)` (the
//!      items prefix baked ahead of the compiler source) is itself
//!      compiled through the `.krf` compiler and rebuilt — `b_a`,
//!      the compiled self-applied compiler; `b_a` then runs in the
//!      VM (MUV ②'s "the rebuilt product is executable") and its
//!      `result` — the compilation of `S` computed by the EXECUTED
//!      self-compiled compiler — is rebuilt into `b_self_exec`;
//!   4. the fixpoint assertion: `b_self_exec == b_self`
//!      (byte-identical — the two compilations of the compiler's
//!      own source agree; both also equal the Rust oracle's
//!      `compile_program(items(S))`, the gate-B elevated check).
//!
//!   The honest brackets (r74/r85 lineage): the self-applied
//!   program embeds its own input as a datum, and the frozen
//!   subset's per-element recursion drives the assembled walks past
//!   the EVALUATOR's depth envelope — step 3 rides the VM-only
//!   bracket face ([`krf_compile_rich_vm`], the disclosed-bracket
//!   precedent of the 2.4 junction-1 VM bracket). Step 2 rides the
//!   dual-engine face (the CP6/CP9 envelope, proven at this input
//!   scale by the existing selfhost fixed-point tests).
//!
//! * **MUV ③ — the gate-B elevated sweep**
//!   ([`gate_b_elevated`]): gate B's axis (a) with the `.krf` side
//!   swapped from "the Rust compile of the `.krf` expander's tree"
//!   to "the `.krf` compiler's own product, rebuilt" — the
//!   full-pipeline dual caliber the r87 close-out registered (the
//!   2.4 witness proved dump equality implies bytecode equality; the
//!   elevated gate asserts it structurally, per corpus case).

use kerf_compiler::{Bytecode, compile_program};
use kerf_core::ModuleItem;
use kerf_reader::read_program;
use kerf_span::FileId;
use kerf_vm::{BufferIo, Vm};

use crate::compiler_parity::{
    COMPILER_SOURCE, items_stream_prefix, krf_compile_rich, krf_compile_rich_vm, rebuild_bytecode,
};
use crate::expander_parity::krf_expand_rich;

/// The fixpoint run's evidence summary (the assertion is
/// `fixpoint_holds`; the counts disclose the scale of both
/// compilations).
#[derive(Debug, Clone)]
pub struct FixpointReport {
    /// Proto count of `b_self` — the compiler's own compiled form.
    pub self_protos: usize,
    /// Proto count of `b_a` — the compiled self-applied compiler
    /// (the executed program; same proto population — the baked
    /// input rides in the const pool, not as protos).
    pub selfapplied_protos: usize,
    /// Const-pool size of `b_self`.
    pub self_consts: usize,
    /// Const-pool size of `b_a` — strictly larger: the baked input
    /// datum rides as a const.
    pub selfapplied_consts: usize,
    /// Instruction count of `b_self` (both compilations agree on it).
    pub self_insns: usize,
    /// `b_self_exec == b_self` — §21.3 (2).
    pub fixpoint_holds: bool,
}

/// Strip the hosting tail — the CP6 selfhost-bare precedent: the
/// bare compiler references the injected `items` global inside
/// `cp-run`, unbound at the top level of its own source.
fn structural_source() -> String {
    let structural = COMPILER_SOURCE.replace("\n(define result (cp-run items))", "");
    assert_ne!(
        &structural, COMPILER_SOURCE,
        "the hosting tail anchor must be present in the compiler source"
    );
    structural
}

/// The oracle front half (the CP-1 hosting convention): read +
/// expand the source with the Rust single sources of tree truth.
fn oracle_items(source: &str) -> Result<Vec<ModuleItem>, String> {
    let forms =
        read_program(FileId(0), source).map_err(|err| format!("the reader rejected: {err}"))?;
    kerf_expander::expand_program(&forms).map_err(|err| format!("the expander rejected: {err}"))
}

/// C(S): the `.krf` compiler compiles the structural compiler's own
/// items — the dual-engine rich drive (proven envelope), the product
/// rebuilt. Returns the rebuilt bytecode plus the items it compiled
/// (the items feed the self-applied assembly next).
fn compile_self_structural() -> Result<(Bytecode, Vec<ModuleItem>), String> {
    let structural = structural_source();
    let items = oracle_items(&structural)?;
    let run = krf_compile_rich(&items, COMPILER_SOURCE)?;
    if run.vm_text != run.eval_text {
        return Err(format!(
            "fixpoint C(S): engines disagree: vm `{}` vs eval `{}`",
            run.vm_text, run.eval_text
        ));
    }
    let b_self = run
        .bytecode
        .ok_or_else(|| format!("fixpoint C(S): the .krf compiler rejected: {}", run.vm_text))?;
    Ok((b_self, items))
}

/// The 2.5 fixpoint driver — MUV ②. See the module doc for the
/// operational shape; every failure is a classified `Err` (the
/// harness discipline — drift is reported, never a panic).
pub fn fixpoint_selfhost_compiler() -> Result<FixpointReport, String> {
    // ---- Phase 1 — C(S): the compiler compiles its own source.
    let (b_self, items_s) = compile_self_structural()?;
    let oracle_self = compile_program(&items_s).map_err(|err| {
        format!("fixpoint C(S): the oracle rejected the structural source: {err}")
    })?;
    if b_self != oracle_self {
        return Err(
            "fixpoint C(S): gate B elevated drift — the .krf compiler's rebuilt product \
             differs from the oracle's compilation of the same items"
                .to_string(),
        );
    }

    // ---- Phase 2 — C(C(S)): the assembled self-applied program,
    // compiled by the .krf compiler itself (the VM-only bracket —
    // the self-applied datum is past the evaluator's envelope).
    let assembled = format!("{}\n{}", items_stream_prefix(&items_s), COMPILER_SOURCE);
    let items_a = oracle_items(&assembled)?;
    let (text_a, rebuilt_a) = krf_compile_rich_vm(&items_a, COMPILER_SOURCE)?;
    let b_a = rebuilt_a.ok_or_else(|| {
        format!(
            "fixpoint C(C(S)): the .krf compiler rejected the self-applied program: {}",
            text_a
        )
    })?;
    let oracle_a = compile_program(&items_a).map_err(|err| {
        format!("fixpoint C(C(S)): the oracle rejected the self-applied program: {err}")
    })?;
    if b_a != oracle_a {
        return Err(
            "fixpoint C(C(S)): gate B elevated drift — the self-applied compilation \
             differs from the oracle's"
                .to_string(),
        );
    }

    // ---- Phase 3 — the executed self-compiled compiler: `b_a` runs
    // in the VM (the product is executable), and its `result` — the
    // compilation of the baked input computed by the EXECUTED
    // compiler — is rebuilt and compared with the direct run.
    let mut vm = Vm::with_io(b_a.clone(), Box::new(BufferIo::default())).map_err(|err| {
        format!("fixpoint execution: the vm rejected the compiled product: {err}")
    })?;
    vm.run().map_err(|err| {
        format!("fixpoint execution: the self-compiled compiler crashed in the vm: {err}")
    })?;
    let result = vm.global("result").ok_or_else(|| {
        "fixpoint execution: no `result` global on the executed product".to_string()
    })?;
    let b_self_exec = rebuild_bytecode(result, vm.heap()).map_err(|err| {
        format!("fixpoint execution: the executed product's result failed to rebuild: {err}")
    })?;

    // ---- §21.3 (2): the two compilations of the compiler's own
    // source are byte-identical.
    if b_self_exec != b_self {
        return Err(
            "fixpoint drift: the executed self-compiled compiler produced a different \
             compilation of its own source (C(C(S)) != C(S))"
                .to_string(),
        );
    }
    let self_insns = b_self.funcs.iter().map(|f| f.code.len()).sum();
    Ok(FixpointReport {
        self_protos: b_self.funcs.len(),
        selfapplied_protos: b_a.funcs.len(),
        self_consts: b_self.consts.len(),
        selfapplied_consts: b_a.consts.len(),
        self_insns,
        fixpoint_holds: true,
    })
}

/// MUV ③ — the elevated gate B: the `.krf` compiler's product
/// (rebuilt through MUV ①'s face) against the Rust oracle's
/// compilation of the `.krf` EXPANDER's own rebuilt tree (the
/// junction-2-fed items — the full-pipeline dual caliber). One
/// corpus case; the sweep iterates the caller's corpus face.
pub fn gate_b_elevated(case: &str, source: &str) -> Result<(), String> {
    // The front half rides the .krf expander (the CP9 face — the
    // oracle read feeds the assembled expander; the tree is the
    // .krf expander's own).
    let (rebuilt, vm_verdict, eval_verdict) = krf_expand_rich(case, source)?;
    if vm_verdict != eval_verdict {
        return Err(format!(
            "gate B elevated [{case}]: engines disagree: vm `{}` vs eval `{}`",
            vm_verdict.text(),
            eval_verdict.text()
        ));
    }
    let items = rebuilt.ok_or_else(|| {
        format!(
            "gate B elevated [{case}]: the .krf expander rejected: {}",
            vm_verdict.text()
        )
    })?;
    let oracle = compile_program(&items)
        .map_err(|err| format!("gate B elevated [{case}]: the oracle rejected: {err}"))?;
    let (text, rebuilt_bc) = krf_compile_rich_vm(&items, COMPILER_SOURCE)?;
    let bc = rebuilt_bc
        .ok_or_else(|| format!("gate B elevated [{case}]: the .krf compiler rejected: {text}"))?;
    if bc == oracle {
        Ok(())
    } else {
        Err(format!(
            "gate B elevated [{case}]: bytecode drift (oracle {} protos / krf {} protos)",
            oracle.funcs.len(),
            bc.funcs.len()
        ))
    }
}

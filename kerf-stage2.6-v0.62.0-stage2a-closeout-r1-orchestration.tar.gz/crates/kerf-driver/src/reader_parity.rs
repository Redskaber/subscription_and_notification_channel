//! Stage 1.5 reader parity — the first self-hosted front-end segment
//! (docs/stage0.md §9.46.4, plan-1.5.md). The structure layer of the
//! S-expr reader, rewritten in the frozen kerf subset itself
//! (`selfhost/v1/reader.krf`), checked against the Rust reader
//! oracle byte-for-byte on both axes:
//!
//! * **Tree axis** — the oracle `SyntaxObject` tree and the `.krf`
//!   reader's `("ok" forms...)` result (a pair chain read back
//!   through the heap) normalize to the same dump.
//! * **Error axis** — the `.krf` reader reports a *structured*
//!   rejection (`("err" kind payload...)`); the harness rebuilds the
//!   `ReadError` and renders it through the oracle's own `Display`,
//!   so byte parity holds by construction and the non-trivial part
//!   under test is the kind/payload selection (innermost `(`, empty
//!   application before outer unclosed, depth on entry).
//!
//! The token table is source-injected (RS-1): the host runs the Rust
//! lexer — the single source of token truth, the hex0 layer of this
//! bootstrap chain — and prepends `(define tokens (quote (...)))`
//! ahead of the reader source. Sources the *lexer* rejects take the
//! [`ParityLayer::Lexer`] path (the .krf layer is not exercised —
//! the second-segment window owns that parity); everything else runs
//! the .krf reader on **both engines** (the `run_parity` lineage:
//! handles stay alive so heap-backed values decode before the
//! engines drop).
//!
//! Payload conventions (the .krf reader never inspects payloads — it
//! passes records through; the host re-reads them):
//! * spans ride as decimal strings (the subset cannot convert
//!   strings to integers),
//! * floats ride as Debug-text strings (`inf`/`NaN` have no .krf
//!   literal shape — every float rides as text; host-side parse is
//!   exact both ways),
//! * ints/bools/strings ride as typed literals (i64 decimal always
//!   re-lexes, including `i64::MIN`; the kerf escape set covers the
//!   string round trip).

use kerf_reader::{Delimiter, ReadError, StxTokenKind, lex};
use kerf_runtime::Evaluator;
use kerf_span::{ByteOffset, FileId};
use kerf_syntax::{StxDatum, SyntaxObject};
use kerf_vm::{BufferIo, Heap, HeapObj, RuntimeError, Value, Vm};

use crate::diagnostic::Severity;
use crate::pipeline;
use crate::session::Session;

/// The self-hosted structure-layer reader, embedded from the
/// workspace's bootstrap face (single source — tests and any future
/// CLI face consume this constant, never a copy).
pub const READER_SOURCE: &str = include_str!("../../../selfhost/v1/reader.krf");

/// Which layer produced a case's verdict.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ParityLayer {
    /// The Rust lexer rejected the source (the six lexer-side
    /// `ReadError` variants). The `.krf` structure layer is not
    /// exercised: the second-segment window owns that parity.
    Lexer,
    /// The `.krf` reader ran on both engines and was compared
    /// against the Rust oracle (trees, or the four parser-side
    /// rejections).
    Parser,
}

/// The `.krf` harness's decoded verdict for one engine run — the
/// shared two-tag grammar (`("ok" ...)` / `("err" ...)`) generic
/// over the structured error type (the reader rebuilds a
/// `ReadError`, the expander a `ParityError`). §9.74 PAR-1: one
/// definition for both harnesses (the twin `KrfVerdict` enums
/// retired, the §9.73 dispatch_builtin lineage).
#[derive(Debug, Clone, PartialEq)]
pub(crate) enum KrfVerdict<E> {
    /// `("ok" form...)` — the normalized tree dump.
    Tree(String),
    /// `("err" kind payload...)` — the rebuilt structured error.
    Error(E),
}

impl KrfVerdict<ReadError> {
    /// The rendered comparison text (tree dump, or the parity-key
    /// form of the rebuilt error). §9.56 DIAG-1: the stage Display is
    /// position-free, so the harness appends the position payload
    /// itself — the comparison key must distinguish payloads (the
    /// drift detector depends on it), exactly like the tree-axis
    /// dumps carry their `s e` offsets.
    pub(crate) fn text(&self) -> String {
        match self {
            KrfVerdict::Tree(dump) => dump.clone(),
            KrfVerdict::Error(err) => error_parity_key(err),
        }
    }
}

/// The error-axis parity key: stage Display + harness-rendered
/// position payload (§9.56 DIAG-1 compensations — offsets ride in
/// the payload, the key surfaces them).
pub(crate) fn error_parity_key(err: &ReadError) -> String {
    match err.offset() {
        Some(ByteOffset(at)) => format!("{err} @ byte {at}"),
        None => err.to_string(),
    }
}

/// The outcome of one reader-parity case.
#[derive(Debug, Clone)]
pub struct ReaderParityReport {
    /// The case name (caller-supplied, for corpus attribution).
    pub case: String,
    /// Which layer decided the case.
    pub layer: ParityLayer,
    /// The oracle's normalized tree dump, or its rendered `ReadError`.
    pub oracle: String,
    /// The `.krf` layer's matching form (`None` on the lexer layer
    /// or a harness defect).
    pub krf: Option<String>,
    /// Both engines agreed on the `result` global's verdict.
    pub engines_agree: bool,
    /// Oracle and `.krf` layer agree (tree axis or error axis).
    pub matched: bool,
    /// The mismatch description when `!matched` (both sides shown).
    pub drift: Option<String>,
}

impl ReaderParityReport {
    /// The one-line failure form (the parity.rs `failure_line`
    /// lineage — corpus manifests print this on drift).
    pub fn failure_line(&self) -> String {
        match &self.drift {
            Some(d) => format!("reader parity FAIL [{}]: {}", self.case, d),
            None => format!("reader parity PASS [{}]", self.case),
        }
    }
}

// ---------- RS-1: the source-injected token table ----------

/// Encode one string as a kerf string literal. The escape set is
/// exactly the lexer's (`\"` `\\` `\n` `\t` `\r`); every other char
/// rides through raw — raw control characters are legal inside kerf
/// string literals, so the round trip is exact for any decoded text.
pub(crate) fn encode_string_literal(s: &str) -> String {
    let mut out = String::with_capacity(s.len() + 2);
    out.push('"');
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\t' => out.push_str("\\t"),
            '\r' => out.push_str("\\r"),
            _ => out.push(c),
        }
    }
    out.push('"');
    out
}

/// Build the `(define tokens (quote (...)))` prefix for one source.
///
/// `Err` carries the oracle's lexer rejection — the harness layer
/// split: lexer-side failures are decided by the (single-source)
/// lexer itself and the .krf layer is not run for them.
pub fn token_table_prefix(source: &str) -> Result<String, ReadError> {
    let file = FileId(0);
    let tokens = lex(file, source)?;
    let mut out = String::from("(define tokens (quote (");
    for (i, tok) in tokens.iter().enumerate() {
        if i > 0 {
            out.push(' ');
        }
        let span = &tok.span;
        let (s, e) = (span.start.0.to_string(), span.end.0.to_string());
        match &tok.kind {
            StxTokenKind::Delimiter(Delimiter::Open) => {
                out.push_str(&format!("(\"lparen\" \"{s}\" \"{e}\")"));
            }
            StxTokenKind::Delimiter(Delimiter::Close) => {
                out.push_str(&format!("(\"rparen\" \"{s}\" \"{e}\")"));
            }
            StxTokenKind::Identifier(sym) => {
                out.push_str(&format!(
                    "(\"ident\" \"{s}\" \"{e}\" {})",
                    encode_string_literal(sym.as_str())
                ));
            }
            StxTokenKind::IntLiteral(v) => {
                out.push_str(&format!("(\"int\" \"{s}\" \"{e}\" {v})"));
            }
            StxTokenKind::FloatLiteral(v) => {
                // Debug text rides as a string: inf/NaN have no .krf
                // literal shape, so *every* float is text-carried.
                out.push_str(&format!(
                    "(\"float\" \"{s}\" \"{e}\" {})",
                    encode_string_literal(&format!("{v:?}"))
                ));
            }
            StxTokenKind::BoolLiteral(v) => {
                // kerf spells its booleans #t/#f (not #true/#false).
                let lit = if *v { "#t" } else { "#f" };
                out.push_str(&format!("(\"bool\" \"{s}\" \"{e}\" {lit})"));
            }
            StxTokenKind::StringLiteral(v) => {
                out.push_str(&format!(
                    "(\"string\" \"{s}\" \"{e}\" {})",
                    encode_string_literal(v)
                ));
            }
            StxTokenKind::Eof => {
                out.push_str(&format!("(\"eof\" \"{e}\")"));
            }
        }
    }
    out.push_str(")))");
    Ok(out)
}

// ---------- RS-3: the two normalizers ----------

/// The oracle's normalized dump: every node as
/// `(kind start end payload...)`, lists as `(list s e child...)`.
pub fn oracle_dump(forms: &[SyntaxObject]) -> String {
    let mut out = String::new();
    for (i, f) in forms.iter().enumerate() {
        if i > 0 {
            out.push(' ');
        }
        dump_oracle_node(f, &mut out);
    }
    out
}

fn dump_oracle_node(node: &SyntaxObject, out: &mut String) {
    let (s, e) = (node.span.start.0, node.span.end.0);
    match &node.datum {
        StxDatum::Symbol(sym) => {
            out.push_str(&format!("(ident {s} {e} {})", sym.as_str()));
        }
        StxDatum::Int(v) => {
            out.push_str(&format!("(int {s} {e} {v})"));
        }
        StxDatum::Float(v) => {
            out.push_str(&format!("(float {s} {e} {v:?})"));
        }
        StxDatum::Bool(v) => {
            out.push_str(&format!("(bool {s} {e} {v})"));
        }
        StxDatum::String(v) => {
            out.push_str(&format!("(string {s} {e} {v:?})"));
        }
        StxDatum::List(items) => {
            out.push_str(&format!("(list {s} {e}"));
            for item in items {
                out.push(' ');
                dump_oracle_node(item, out);
            }
            out.push(')');
        }
    }
}

/// The elements of a proper-list value (walks the pair chain). `Err`
/// reports a malformed chain — a structural defect of the .krf
/// reader's own output, surfaced as drift.
pub(crate) fn value_elems<'v>(value: &'v Value, heap: &'v Heap) -> Result<Vec<&'v Value>, String> {
    let mut elems = Vec::new();
    let mut cur = value;
    loop {
        match cur {
            Value::Nil => return Ok(elems),
            Value::Pair(r) => match heap.get(*r) {
                Some(HeapObj::Pair(car, cdr)) => {
                    elems.push(car);
                    cur = cdr;
                }
                _ => return Err("dangling pair reference in the result chain".to_string()),
            },
            other => {
                return Err(format!("improper list: chain ends in {other:?}"));
            }
        }
    }
}

pub(crate) fn as_str(v: &Value) -> Result<&str, String> {
    match v {
        Value::Str(s) => Ok(&**s),
        other => Err(format!("expected a string field, found {other:?}")),
    }
}

pub(crate) fn as_i64(v: &Value) -> Result<i64, String> {
    match v {
        Value::Int(n) => Ok(*n),
        other => Err(format!("expected an int field, found {other:?}")),
    }
}

pub(crate) fn parse_span(v: &Value) -> Result<u32, String> {
    let text = as_str(v)?;
    text.parse::<u32>()
        .map_err(|_| format!("span field `{text}` is not a decimal offset"))
}

/// Assert a record's minimum field count (§9.76 SER-1; K172 — serde's
/// `invalid_length` shape: kind, actual count, needed count as a
/// structured error, never an index/slice panic). Every decode arm
/// that reaches past the common header fields carries one of these
/// ahead of its first payload access, so a malformed record produced
/// by the self-hosted layer under test reports drift, never a
/// harness panic (the documented `drive_dual_engines` contract).
pub(crate) fn need_fields(elems: &[&Value], n: usize, what: &str) -> Result<(), String> {
    if elems.len() < n {
        let plural = if elems.len() == 1 { "" } else { "s" };
        return Err(format!(
            "{what} record has {} field{plural}, need at least {n}",
            elems.len()
        ));
    }
    Ok(())
}

/// The .krf reader's normalized node dump (the same grammar as
/// [`oracle_dump`]; span strings re-parse to offsets, float text
/// re-parses through the same Rust parse the oracle used).
fn dump_krf_node(value: &Value, heap: &Heap, out: &mut String) -> Result<(), String> {
    let elems = value_elems(value, heap)?;
    if elems.len() < 3 {
        return Err(format!(
            "node has {} fields, need at least kind/start/end",
            elems.len()
        ));
    }
    let kind = as_str(elems[0])?.to_string();
    let s = parse_span(elems[1])?;
    let e = parse_span(elems[2])?;
    match kind.as_str() {
        "ident" => {
            need_fields(&elems, 4, "`ident` node")?;
            let text = as_str(elems[3])?;
            out.push_str(&format!("(ident {s} {e} {text})"));
        }
        "int" => {
            need_fields(&elems, 4, "`int` node")?;
            let v = as_i64(elems[3])?;
            out.push_str(&format!("(int {s} {e} {v})"));
        }
        "float" => {
            need_fields(&elems, 4, "`float` node")?;
            let text = as_str(elems[3])?;
            let v: f64 = text
                .parse()
                .map_err(|_| format!("float payload `{text}` does not re-parse"))?;
            out.push_str(&format!("(float {s} {e} {v:?})"));
        }
        "bool" => {
            need_fields(&elems, 4, "`bool` node")?;
            let v = match elems[3] {
                Value::Bool(b) => *b,
                other => return Err(format!("expected a bool field, found {other:?}")),
            };
            out.push_str(&format!("(bool {s} {e} {v})"));
        }
        "string" => {
            need_fields(&elems, 4, "`string` node")?;
            let text = as_str(elems[3])?;
            out.push_str(&format!("(string {s} {e} {text:?})"));
        }
        "list" => {
            out.push_str(&format!("(list {s} {e}"));
            for child in &elems[3..] {
                out.push(' ');
                dump_krf_node(child, heap, out)?;
            }
            out.push(')');
        }
        other => return Err(format!("unknown node kind `{other}`")),
    }
    Ok(())
}

// ---------- RS-2: the structured-error rebuild ----------

/// Rebuild the `ReadError` from a `("err" kind payload...)` value.
/// The caller renders it through the oracle's own `Display`, so
/// message-text parity holds by construction; what this checks is
/// that the .krf reader chose the right kind and payload.
pub fn reconstruct_error(value: &Value, heap: &Heap) -> Result<ReadError, String> {
    let elems = value_elems(value, heap)?;
    if elems.len() < 3 || as_str(elems[0])? != "err" {
        return Err("expected an (\"err\" kind payload...) value".to_string());
    }
    let kind = as_str(elems[1])?;
    match kind {
        "unclosed" => Ok(ReadError::UnclosedList {
            opened_at: ByteOffset(parse_span(elems[2])?),
        }),
        "unexpected-close" => Ok(ReadError::UnexpectedClose {
            at: ByteOffset(parse_span(elems[2])?),
        }),
        "empty-app" => Ok(ReadError::EmptyApplication {
            at: ByteOffset(parse_span(elems[2])?),
        }),
        "nesting" => {
            need_fields(&elems, 4, "`nesting` rejection")?;
            let depth = as_i64(elems[2])?;
            let limit = as_i64(elems[3])?;
            if depth < 0 || limit < 0 {
                return Err(format!("negative nesting payload ({depth}, {limit})"));
            }
            Ok(ReadError::NestingDepthExceeded {
                depth: depth as usize,
                limit: limit as usize,
            })
        }
        other => Err(format!("unknown error kind `{other}`")),
    }
}

/// Decode one engine's `result` global into a verdict (while that
/// engine — and its heap — is still alive).
fn decode_verdict(value: &Value, heap: &Heap) -> Result<KrfVerdict<ReadError>, String> {
    decode_tagged(value, heap, dump_krf_node, reconstruct_error)
}

// ---------- RS-4: the dual-engine run (single source) ----------

/// Decode one engine's `result` global into a tagged verdict — the
/// single-source tag grammar for both parity harnesses (§9.74
/// PAR-1): the `"ok"` branch dumps every form through `dump`, the
/// `"err"` branch rebuilds the structured error through `rebuild`.
/// Everything else about the two harnesses' verdict grammars is
/// identical by construction.
pub(crate) fn decode_tagged<E>(
    value: &Value,
    heap: &Heap,
    dump: fn(&Value, &Heap, &mut String) -> Result<(), String>,
    rebuild: fn(&Value, &Heap) -> Result<E, String>,
) -> Result<KrfVerdict<E>, String> {
    let elems = value_elems(value, heap)?;
    let tag = elems
        .first()
        .and_then(|v| match v {
            Value::Str(s) => Some(&**s),
            _ => None,
        })
        .ok_or_else(|| "the result value is not a tagged list".to_string())?;
    match tag {
        "ok" => {
            let mut out = String::new();
            for (i, form) in elems[1..].iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                dump(form, heap, &mut out)?;
            }
            Ok(KrfVerdict::Tree(out))
        }
        "err" => Ok(KrfVerdict::Error(rebuild(value, heap)?)),
        other => Err(format!("unknown verdict tag `{other}`")),
    }
}

/// Drive one assembled `.krf` harness program through both engines
/// and return the two decoded verdicts — the single source for the
/// reader/expander parity drivers and the gate-B host rebuild (three
/// hand-rolled twins retired; the §9.73 `dispatch_builtin` lineage).
/// §9.74 PAR-1.
///
/// `host_name` names the synthetic file for diagnostics; `what` is
/// the harness noun ("reader" / "expander") threaded into every
/// harness-failure message. The two decoders run **while their engine
/// — and its heap — is still alive** (heap-backed values; the
/// `run_parity` lineage): the vm decoder may rebuild richer state
/// (the gate-B item tree) while the eval decoder stays plain.
///
/// `Err` carries one of two classified prefixes (r74, K165 — the
/// CPython `_json.c` discipline of classifying a boundary at the
/// failure site):
/// * `"harness defect: …"` — the harness program failed a pipeline
///   stage, crashed on a non-budget runtime error, or produced an
///   undecodable result: a real harness bug;
/// * `"harness limit: …"` — an engine budget face (`BudgetExceeded` /
///   `EvalDepthExceeded`) rejected the harness program: the honest
///   **input envelope** of the harness, not a semantic drift. The
///   frozen subset expresses iteration only through self-recursion
///   (no loop primitive — the §9.29 termination argument), so a
///   source wide enough drives the per-token / per-record harness
///   walks past an engine budget.
///
/// Both classes are reported as drift, never a panic.
pub(crate) fn drive_dual_engines<VmOut, EvOut>(
    host_name: &str,
    what: &str,
    assembled: &str,
    decode_vm: impl Fn(&Value, &Heap) -> Result<VmOut, String>,
    decode_eval: impl Fn(&Value, &Heap) -> Result<EvOut, String>,
) -> Result<(VmOut, EvOut), String> {
    let mut session = Session::new();
    let program = pipeline::parse(&mut session, host_name, assembled).map_err(|diags| {
        format!("harness defect: the assembled {what} program failed to parse: {diags:?}")
    })?;
    let findings = program.typecheck();
    if findings.iter().any(|d| d.severity == Severity::Error) {
        return Err(format!(
            "harness defect: the assembled {what} program failed the checker: {findings:?}"
        ));
    }
    let bc = kerf_compiler::compile_program(&program.items).map_err(|err| {
        format!("harness defect: the assembled {what} program failed to compile: {err}")
    })?;
    let mut vm = Vm::with_io(bc, Box::new(BufferIo::default()))
        .map_err(|err| format!("harness defect: the vm rejected the {what} program: {err}"))?;
    vm.run()
        .map_err(|err| harness_run_failure("vm", what, &err))?;
    let vm_verdict = decode_vm(
        vm.global("result")
            .ok_or_else(|| "harness defect: no `result` global on the vm engine".to_string())?,
        vm.heap(),
    )
    .map_err(|err| format!("harness defect: {err}"))?;

    let mut evaluator = Evaluator::with_io(Box::new(BufferIo::default()));
    evaluator
        .eval_program(&program.items)
        .map_err(|err| harness_run_failure("eval", what, &err))?;
    let eval_verdict = decode_eval(
        evaluator
            .global("result")
            .ok_or_else(|| "harness defect: no `result` global on the eval engine".to_string())?,
        evaluator.heap(),
    )
    .map_err(|err| format!("harness defect: {err}"))?;
    Ok((vm_verdict, eval_verdict))
}

/// Classify one engine rejection of the assembled harness program
/// (r74, K165 — the CPython `_json.c` discipline: a recursion
/// boundary is classified at the failure site, never reported as a
/// generic crash). The two budget faces are the harness's honest
/// input envelope — the frozen subset expresses iteration only
/// through self-recursion, so a wide enough source exhausts an
/// engine budget — while every other runtime rejection of the
/// harness program is a harness defect.
fn harness_run_failure(engine: &str, what: &str, err: &RuntimeError) -> String {
    if matches!(
        err,
        RuntimeError::BudgetExceeded { .. } | RuntimeError::EvalDepthExceeded { .. }
    ) {
        format!(
            "harness limit: the .krf {what} exceeded the {engine} engine's budget ({err}) \
             — the frozen subset's per-element recursion gives the harness a finite \
             input envelope; not a semantic drift"
        )
    } else {
        format!("harness defect: the .krf {what} crashed on the {engine} engine: {err}")
    }
}

/// Run the assembled reader program on both engines and return the
/// two decoded verdicts (the single-source driver, §9.74 PAR-1).
fn run_dual(assembled: &str) -> Result<(KrfVerdict<ReadError>, KrfVerdict<ReadError>), String> {
    drive_dual_engines(
        "reader-parity-host.krf",
        "reader",
        assembled,
        decode_verdict,
        decode_verdict,
    )
}

// ---------- the case driver ----------

/// Run one reader-parity case: lex-split, oracle read, dual-engine
/// .krf run, and the two-axis comparison.
pub fn reader_parity(case: &str, source: &str) -> ReaderParityReport {
    reader_parity_with(case, source, READER_SOURCE)
}

/// The parameterized face (tests may pass a tampered reader source
/// to prove the drift detector actually detects).
pub fn reader_parity_with(case: &str, source: &str, reader_source: &str) -> ReaderParityReport {
    // Layer split: the lexer (single source) rejected the input —
    // the .krf structure layer is not exercised.
    let prefix = match token_table_prefix(source) {
        Err(err) => {
            return ReaderParityReport {
                case: case.to_string(),
                layer: ParityLayer::Lexer,
                oracle: error_parity_key(&err),
                krf: None,
                engines_agree: true,
                matched: true,
                drift: None,
            };
        }
        Ok(p) => p,
    };
    let layer = ParityLayer::Parser;
    let oracle = kerf_reader::read_program(FileId(0), source);
    let oracle_text = match &oracle {
        Ok(forms) => oracle_dump(forms),
        Err(err) => error_parity_key(err),
    };
    let assembled = format!("{prefix}\n{reader_source}");
    let (vm_verdict, eval_verdict) = match run_dual(&assembled) {
        Ok(v) => v,
        Err(harness) => {
            // r74: the harness string carries its own classification
            // ("harness defect: …" / "harness limit: …") — single
            // source, never re-prefixed here.
            return ReaderParityReport {
                case: case.to_string(),
                layer,
                oracle: oracle_text,
                krf: None,
                engines_agree: false,
                matched: false,
                drift: Some(harness),
            };
        }
    };
    let engines_agree = vm_verdict == eval_verdict;
    let krf_text = vm_verdict.text();
    // §9.74 PAR-2: the two-axis comparison is one predicate — the
    // shapes must pair (tree with tree, error with error) and the
    // rendered texts must be equal. The former hand-rolled branch
    // pair (a constructed `KrfVerdict::Tree(oracle_text.clone())`
    // comparison on one arm, a direct key comparison on the other)
    // was the same semantics in two shapes.
    let shapes_pair = matches!(
        (&oracle, &vm_verdict),
        (Ok(_), KrfVerdict::Tree(_)) | (Err(_), KrfVerdict::Error(_))
    );
    let matched = engines_agree && shapes_pair && krf_text == oracle_text;
    let drift = if matched {
        None
    } else {
        Some(format!(
            "oracle `{oracle_text}` vs krf `{krf_text}`{}",
            if engines_agree {
                String::new()
            } else {
                format!(
                    "; engines disagree: vm `{}` vs eval `{}`",
                    vm_verdict.text(),
                    eval_verdict.text()
                )
            }
        ))
    };
    ReaderParityReport {
        case: case.to_string(),
        layer,
        oracle: oracle_text,
        krf: Some(krf_text),
        engines_agree,
        matched,
        drift,
    }
}

#[cfg(test)]
mod tests {
    //! Reader-parity harness tests (the plan-1.5 test doc FP1-FP4):
    //! table encoding, layer split, both axes, drift detection.

    use super::*;

    fn parity(source: &str) -> ReaderParityReport {
        reader_parity("unit", source)
    }

    #[test]
    fn string_literal_encoding_round_trips_the_escape_set() {
        assert_eq!(encode_string_literal("a\"b\\c"), "\"a\\\"b\\\\c\"");
        assert_eq!(encode_string_literal("x\ny\tz\r"), "\"x\\ny\\tz\\r\"");
        // Raw control characters ride through (legal inside kerf
        // string literals).
        assert_eq!(encode_string_literal("\u{1}"), "\"\u{1}\"");
    }

    #[test]
    fn token_table_encodes_a_small_program() {
        let prefix = token_table_prefix("(f 1)").expect("lexes");
        assert_eq!(
            prefix,
            "(define tokens (quote ((\"lparen\" \"0\" \"1\") (\"ident\" \"1\" \"2\" \"f\") \
             (\"int\" \"3\" \"4\" 1) (\"rparen\" \"4\" \"5\") (\"eof\" \"5\"))))"
        );
    }

    #[test]
    fn lexer_layer_split_routes_the_six_variant_rejections() {
        let report = parity("\"unterminated");
        assert_eq!(report.layer, ParityLayer::Lexer);
        assert!(report.matched);
        assert!(report.krf.is_none());
        assert!(report.oracle.starts_with("unterminated string literal"));
        for src in ["#x", "1.2.3", "[", "(a \"\\q\")", "\u{1}", "bad\u{7}sym"] {
            let r = parity(src);
            assert_eq!(r.layer, ParityLayer::Lexer, "case {src:?}");
            assert!(r.matched, "case {src:?}");
        }
    }

    #[test]
    fn positive_tree_parity_holds_on_both_engines() {
        let report = parity("(f (g 1) 2)");
        assert_eq!(report.layer, ParityLayer::Parser);
        assert!(report.engines_agree, "{:?}", report.drift);
        assert!(report.matched, "{}", report.failure_line());
        // The exact spans of the parser.rs unit anchor.
        assert_eq!(
            report.oracle,
            "(list 0 11 (ident 1 2 f) (list 3 8 (ident 4 5 g) (int 6 7 1)) (int 9 10 2))"
        );
    }

    #[test]
    fn multi_form_and_atom_parity_hold() {
        // Multi-form program, every literal kind, comments skipped.
        let src = "; leading comment\n(a) 1 x 2.5 #t \"s\\n\"\n";
        let report = parity(src);
        assert!(report.matched, "{}", report.failure_line());
        assert!(report.engines_agree);
    }

    #[test]
    fn parser_error_axis_parity_holds() {
        // Each of the four parser-side rejections, at the exact
        // payload the oracle produces. §9.56 DIAG-1: the parity key
        // = position-free Display + harness-rendered `@ byte` suffix
        // (payload offsets surface in the key, never in Display).
        for (src, want_prefix) in [
            ("(a (b", "unclosed delimiter: `(` is never closed @ byte 3"),
            (")", "unexpected closing delimiter `)` @ byte 0"),
            ("(f ())", "empty application: `()` has no operator @ byte 3"),
            ("(((x", "unclosed delimiter: `(` is never closed @ byte 2"),
            ("(a 1) )", "unexpected closing delimiter `)` @ byte 6"),
            (
                "(a (b ()))",
                "empty application: `()` has no operator @ byte 6",
            ),
            ("(()", "empty application: `()` has no operator @ byte 1"),
            (
                "(a) (b) (c",
                "unclosed delimiter: `(` is never closed @ byte 8",
            ),
        ] {
            let report = parity(src);
            assert_eq!(report.layer, ParityLayer::Parser, "case {src:?}");
            assert!(report.matched, "case {src:?}: {}", report.failure_line());
            assert!(
                report.oracle.starts_with(want_prefix),
                "case {src:?}: oracle `{}`",
                report.oracle
            );
        }
    }

    #[test]
    fn drift_detector_actually_detects() {
        // A tampered reader (unclosed reports the OUTERMOST open
        // instead of the innermost) must fail the comparison — a
        // detector that cannot fail proves nothing.
        let tampered = READER_SOURCE.replace(
            "(cons \"unclosed\" (cons (rd-fr-open (car stack)) nil))",
            "(cons \"unclosed\" (cons (rd-fr-open (rd-rev stack nil)) nil))",
        );
        assert_ne!(tampered, READER_SOURCE, "tamper must change the source");
        let report = reader_parity_with("tamper", "(a (b", &tampered);
        assert!(!report.matched, "the tampered reader must be caught");
        assert!(report.drift.is_some());
    }
}

#[cfg(test)]
mod oracle_totality_tests {
    //! §9.76 SER-2 (reader half): the reader-parity decode face is
    //! total — a malformed node or rejection record reports a
    //! structured drift error, never an index/slice panic (K172
    //! serde `invalid_length` shape; the documented
    //! `drive_dual_engines` "never a panic" contract).

    use super::*;
    use kerf_vm::HeapObj;
    use std::panic::{AssertUnwindSafe, catch_unwind};

    fn s(text: &str) -> Value {
        Value::Str(text.into())
    }

    fn record(vals: Vec<Value>) -> (Value, Heap) {
        let mut heap = Heap::default();
        let mut acc = Value::Nil;
        for v in vals.into_iter().rev() {
            let r = heap.alloc(HeapObj::Pair(v, acc));
            acc = Value::Pair(r);
        }
        (acc, heap)
    }

    #[test]
    fn ser1_leaf_node_arms_reject_short_records_as_drift() {
        // Every leaf arm reaches elems[3] past the shared three-field
        // header (kind/start/end) — at three fields the pre-SER-1
        // code indexed out of bounds.
        for kind in ["ident", "int", "float", "bool", "string"] {
            for len in 0..4 {
                let mut vals = vec![s(kind), s("0"), s("1")];
                for _ in 3..len {
                    vals.push(s("x"));
                }
                vals.truncate(len);
                let (value, heap) = record(vals);
                let case = format!("dump node `{kind}` at {len} fields");
                let mut out = String::new();
                let caught =
                    catch_unwind(AssertUnwindSafe(|| dump_krf_node(&value, &heap, &mut out)));
                match caught {
                    Ok(Err(_)) => {}
                    Ok(Ok(())) => panic!("{case}: a truncated node must not dump"),
                    Err(panic) => panic!("{case}: panicked instead of drift: {panic:?}"),
                }
            }
        }
    }

    #[test]
    fn ser1_nesting_rejection_rejects_short_records_as_drift() {
        // The nesting arm reaches elems[3] past the three-field
        // `("err" kind payload)` floor.
        for len in 3..4 {
            let mut vals = vec![s("err"), s("nesting"), s("0")];
            vals.truncate(len);
            let (value, heap) = record(vals);
            let case = format!("reconstruct `nesting` at {len} fields");
            let caught = catch_unwind(AssertUnwindSafe(|| reconstruct_error(&value, &heap)));
            match caught {
                Ok(Err(_)) => {}
                Ok(Ok(_)) => panic!("{case}: a truncated rejection must not rebuild"),
                Err(panic) => panic!("{case}: panicked instead of drift: {panic:?}"),
            }
        }
    }

    #[test]
    fn ser2_unknown_node_and_error_kinds_stay_fail_closed() {
        let (value, heap) = record(vec![s("bogus"), s("0"), s("1"), s("x")]);
        let mut out = String::new();
        let msg = dump_krf_node(&value, &heap, &mut out).unwrap_err();
        assert!(msg.contains("unknown"), "got `{msg}`");

        let (value, heap) = record(vec![s("err"), s("bogus"), s("0"), s("1")]);
        let msg = reconstruct_error(&value, &heap).unwrap_err();
        assert!(msg.contains("unknown"), "got `{msg}`");
    }
}

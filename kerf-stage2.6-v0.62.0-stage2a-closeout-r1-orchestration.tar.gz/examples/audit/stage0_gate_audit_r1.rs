//! Stage 0 gate audit set, revision 1 — SOP §7.3.1 negative audit.
//!
//! Run: `cargo run --release --example stage0_gate_audit_r1`
//! (exit 0 = all 50 cases behave as audited; any panic = audit failure).
//!
//! Composition (§7.3.1 rule 2, full obligation effective from sub-stage
//! 0.3 — plan-0.0.md §6 cold-start adaptation ends here):
//! - Section A: 10 single-statement negative cases
//! - Section B: 10 multi-statement/multi-form negative cases
//! - Section C: 5 complex-program negative cases (deep nesting)
//! - Section D: 5 error-recovery cases (Stage 0 recovery semantics:
//!   structured errors with byte-precise locations + call-level
//!   isolation; panic-mode/sync-set machinery is §9.36.8 registered
//!   theory, a Stage 2 window item)
//! - Section E: 10 expander negative cases (sub-stage 0.4 — monotonic
//!   growth per §7.3.1 rule 4)
//! - Section F: 10 compiler negative cases (sub-stage 0.5 — compile
//!   depth cap + Bytecode::verify rejection family over hand-built
//!   products; monotonic growth per §7.3.1 rule 4)
//! - Section G: 10 VM negative cases (sub-stage 0.6 — SOP §7.1.1
//!   classes 4/5 light up: arity mismatches on both call faces and
//!   type mismatches across four contexts, plus the effect / division
//!   / overflow / budget fail-closed paths)
//! - Section H: 10 runtime negative cases (sub-stage 0.7 — the eval
//!   path mirrors Section G case-for-case, plus GC retention and the
//!   parity detector self-check)
//! - Section I: 10 driver end-to-end cases (sub-stage 0.8 — the five
//!   source-reachable error classes through the full pipeline with
//!   rendered line:column locations, multi-file multi-diagnostic
//!   collection, REPL rollback, the check face, parity reporting and
//!   the CJK character-column rendering edge)
//! - Section J: 10 macro/module/quote negative cases (sub-stage 0.9 —
//!   the syntax-rules matching family, the hygiene defense family,
//!   the quote boundary, and the §7.1.1 class 7 module-cycle family;
//!   monotonic growth per §7.3.1 rule 4)
//! - Section K: 10 reserved-face contract cases (sub-stage 0.10 —
//!   the frozen reservation face of docs/stage0.md §9.1.1-§9.1.4:
//!   effects/multistage witness semantics, the sealed capability
//!   tokens, the R8 I/O error face, and the executable cache
//!   behavior contract; monotonic growth per §7.3.1 rule 4)
//! - Section L: 10 capability-space cases (sub-stage 0.10-r2 — the
//!   general capability-model framework of docs/stage0.md §9.10/
//!   §9.13: the family contract, the token calculus, and the
//!   registration/extension registry with fail-closed identity
//!   validation; the io sub-model re-hung as the first concrete
//!   model with freeze continuity; monotonic growth per §7.3.1
//!   rule 4)
//! - Section M: 10 conservative-static-checker cases (sub-stage 1.0
//!   — kerf-typecheck R1-R8 over the real pipeline: the definite-
//!   error-only rules (arity/callee/condition/effect families), the
//!   warning-level assignment surprise, and the E0xxx registry with
//!   the single-source Externals face; monotonic growth per §7.3.1
//!   rule 4)
//! - Section N: 10 driver-wiring cases (sub-stage 1.1 — the checker
//!   mounted between expand and both engines: source-reachable
//!   E0xxx diagnostics end-to-end with the rendered registry tags,
//!   abort-before-execution, the warning channel through run/check/
//!   parity and the REPL delta replay; monotonic growth per §7.3.1
//!   rule 4)
//! - Section P: 10 HM-inference end-to-end cases (sub-stage 1.3 —
//!   `infer_module` over real sources: E0009/E0010 definite errors,
//!   the E0011 budget warning, polymorphic instantiation, the
//!   assigned guard, and the effect-row collection face)
//! - Section S: 10 expander-parity cases (sub-stage 1.6 — the
//!   .krf expansion layer vs the Rust oracle)
//! - Section R: 10 reader-parity cases (sub-stage 1.5 — the
//!   self-hosted structure layer vs the Rust oracle: both axes,
//!   both engines, the layer split, and the drift self-checks).
//! - Section Q: 10 parity-contract cases (sub-stage 1.4 — the
//!   detector-detects meta-audit: wrong expectations must drift with
//!   both sides named, stage attribution both ways, exact code-set
//!   comparison, checker-vs-halt divergence, the no-define value
//!   convention, the batch face, and the closed directive grammar)
//! - Section W: 10 lexical-capture cases (Stage 2.1/2.2 — the
//!   flat-capture activation family end-to-end: the three value
//!   faces, the E0012 boundary, the verifier's definer-frame rule,
//!   the top-level non-capture, and the two ★1' resolution proofs)
//! - Section Y: 10 CP-emission cases (Stage 2.3 second Pass — the
//!   instruction streams: backpatching, depth bookkeeping, the dense
//!   debug_info table, the terminator contracts, the fifth
//!   self-application)
//! - Section X: 10 CP-parity cases (Stage 2.3 — the fixpoint window
//!   opening: the lexical-domain analysis rewritten in the frozen
//!   subset against the Rust compiler oracle — corpus replay,
//!   transitive capture, the LA-7 compile-side boundary, the depth
//!   mirror + the eval input envelope, the nested-litval regression,
//!   the scope-stack discipline, const identity, first-use orders,
//!   the fourth self-application, and the drift self-check;
//!   monotonic growth per §7.3.1 rule 4)
//! - Section AA: 10 C-transpilation cases (Stage 2.6 first cut —
//!   the chain-external backend: emission determinism + the
//!   constitutional header, immediates display parity, the
//!   shortest-round-trip float battery, control flow + recursion,
//!   flat captures + effects, the arity family, the budget and
//!   depth override guards, unbound/ret-from-entry fail-closed,
//!   and read-line I/O parity; every cc case passes the
//!   chain-external gate first — cc-absent hosts skip with
//!   disclosure, never fail)
//!
//!
//! Error-class coverage (SOP §7.1.1) at sub-stage 0.6: classes 1
//! (syntax error), 3 (empty application), 2 (unbound identifier), 7
//! (macro expansion depth exceeded), 4 (argument count) and 5 (type
//! mismatch) are lit — six of seven. Class 6 (module cyclic
//! dependency) stays structural DEFERRED to the 0.9 loader; this file
//! grows monotonically per §7.3.1 rule 4 (each round's audit set >=
//! the previous one) until 7/7 at the 0.11 stage gate.

use kerf::core::CoreError;
use kerf::core::reserved::cache::{
    CacheKey, CachedResult, CompilationCache, check_compilation_cache_contract,
};
use kerf::core::reserved::capability_io::{IOError, IoErrorKind, ReadCapability, WriteCapability};
use kerf::core::reserved::effects::{EffectOp, EffectSystem};
use kerf::core::reserved::multistage::{CodeCarrier, Expr, MultiStage};
use kerf::expander::{EXPANSION_LIMIT, ExpandCtx, ExpandError, expand, expand_program};
use kerf::reader::{NESTING_LIMIT, ReadError, read_program};
use kerf::span::{ByteOffset, FileId};
use kerf::syntax::{Phase, ScopeSet, SyntaxObject};
use kerf::typecheck::{Externals, INFERENCE_DEPTH_LIMIT, Severity, infer_module};

const FILE: FileId = FileId(0);

/// Assert the source fails and the error matches `pred`.
fn audit_err(src: &str, name: &str, pred: impl FnOnce(&ReadError) -> bool) {
    match read_program(FILE, src) {
        Ok(forms) => panic!(
            "audit case `{name}` must fail, but read {} forms",
            forms.len()
        ),
        Err(err) => {
            assert!(
                pred(&err),
                "audit case `{name}` failed with the wrong error: {err}"
            );
        }
    }
}

/// Assert the source reads to exactly `forms` top-level forms.
fn audit_ok(src: &str, forms: usize, name: &str) {
    let parsed = read_program(FILE, src)
        .unwrap_or_else(|err| panic!("audit case `{name}` must read, but failed: {err}"));
    assert_eq!(
        parsed.len(),
        forms,
        "audit case `{name}` must read exactly {forms} forms"
    );
}

/// `n` levels of nesting around `inner`.
fn deep(n: usize, inner: &str) -> String {
    let mut src = String::new();
    for _ in 0..n {
        src.push('(');
    }
    src.push_str(inner);
    for _ in 0..n {
        src.push(')');
    }
    src
}

/// Assert the source reads cleanly and then fails expansion, with the
/// error matching `pred` (the expander counterpart of `audit_err`).
fn expand_err(src: &str, name: &str, pred: impl FnOnce(&ExpandError) -> bool) {
    let forms = match read_program(FILE, src) {
        Ok(forms) => forms,
        Err(err) => panic!("audit case `{name}` must read cleanly, got {err}"),
    };
    match expand_program(&forms) {
        Ok(items) => panic!(
            "audit case `{name}` must fail, but expanded {} items",
            items.len()
        ),
        Err(err) => {
            assert!(
                pred(&err),
                "audit case `{name}` failed with the wrong error: {err}"
            );
        }
    }
}

fn main() {
    // The audit drives the eval engine's deep native recursions (the
    // H08 2048-frame depth face and the CP/Y self-applications), and
    // the sandbox main thread's default 8 MiB sits below the measured
    // demand on this toolchain (Rust 1.99.0 stack frames — the same
    // class as the §9.84.1 new-sandbox stack guards). Run the whole
    // audit body on a dedicated deep-stack thread (the r74 BST-1
    // `deep_stack` precedent, sized at 64 MiB for the audit's
    // eval-depth face; every value is created inside the thread, so
    // the non-Send `Value` payloads never cross the boundary).
    std::thread::Builder::new()
        .stack_size(64 * 1024 * 1024)
        .spawn(audit_body)
        .expect("spawn the audit deep-stack thread")
        .join()
        .expect("the audit deep-stack thread finished cleanly");
}

fn audit_body() {
    // ---- Section A: single-statement negative (10) ----
    // SOP §7.1.1 class 1 (syntax error) unless noted.
    // A01: unclosed list.
    audit_err(
        "(f",
        "A01 unclosed list",
        |e| matches!(e, ReadError::UnclosedList { opened_at } if opened_at.0 == 0),
    );
    // A02: stray close.
    audit_err(
        ")",
        "A02 stray close",
        |e| matches!(e, ReadError::UnexpectedClose { at } if at.0 == 0),
    );
    // SOP §7.1.1 class 3 (empty syntax object / empty application).
    // A03: empty application.
    audit_err(
        "()",
        "A03 empty application",
        |e| matches!(e, ReadError::EmptyApplication { at } if at.0 == 0),
    );
    // A04: unterminated string.
    audit_err(
        "\"abc",
        "A04 unterminated string",
        |e| matches!(e, ReadError::UnterminatedString { started_at } if started_at.0 == 0),
    );
    // A05: invalid escape.
    audit_err(
        "\"a\\x\"",
        "A05 invalid escape",
        |e| matches!(e, ReadError::InvalidEscape { escape, .. } if *escape == 'x'),
    );
    // A06: invalid bool.
    audit_err(
        "#q",
        "A06 invalid bool",
        |e| matches!(e, ReadError::InvalidBool { text, .. } if text == "#q"),
    );
    // A07: malformed number (multi-dot).
    audit_err(
        "1.2.3",
        "A07 malformed number (multi-dot)",
        |e| matches!(e, ReadError::MalformedNumber { text, .. } if text == "1.2.3"),
    );
    // A08: malformed number (suffix).
    audit_err(
        "12abc",
        "A08 malformed number (suffix)",
        |e| matches!(e, ReadError::MalformedNumber { text, .. } if text == "12abc"),
    );
    // A09: invalid symbol (control char).
    audit_err("a\u{0}b", "A09 invalid symbol (control char)", |e| {
        matches!(e, ReadError::InvalidSymbol { .. })
    });
    // A10: unexpected character.
    audit_err(
        "[",
        "A10 unexpected character",
        |e| matches!(e, ReadError::UnexpectedCharacter { character, .. } if *character == '['),
    );

    // ---- Section B: multi-statement/multi-form negative (10) ----
    // The error sits inside a larger program of otherwise-valid forms;
    // every case asserts the byte-precise location of the broken form.
    // B01: later form unclosed.
    audit_err(
        "(define x 1) (f",
        "B01 later form unclosed",
        |e| matches!(e, ReadError::UnclosedList { opened_at } if opened_at.0 == 13),
    );
    // B02: stray close after atoms.
    audit_err(
        "x 42 )",
        "B02 stray close after atoms",
        |e| matches!(e, ReadError::UnexpectedClose { at } if at.0 == 5),
    );
    // B03: empty app between forms.
    audit_err(
        "(a 1) () (b 2)",
        "B03 empty app between forms",
        |e| matches!(e, ReadError::EmptyApplication { at } if at.0 == 6),
    );
    // B04: unterminated string mid-program.
    audit_err(
        "(f 1) \"s (g 2)",
        "B04 unterminated string mid-program",
        |e| matches!(e, ReadError::UnterminatedString { started_at } if started_at.0 == 6),
    );
    // B05: bad bool in atom sequence.
    audit_err(
        "#t #f #q",
        "B05 bad bool in atom sequence",
        |e| matches!(e, ReadError::InvalidBool { text, .. } if text == "#q"),
    );
    // B06: malformed number in sequence.
    audit_err(
        "1 2 3.3.3",
        "B06 malformed number in sequence",
        |e| matches!(e, ReadError::MalformedNumber { text, .. } if text == "3.3.3"),
    );
    // B07: nested form unclosed.
    audit_err(
        "(a) (b (c)",
        "B07 nested form unclosed",
        |e| matches!(e, ReadError::UnclosedList { opened_at } if opened_at.0 == 4),
    );
    // B08: stray close after nested form.
    audit_err(
        "(a (b 1)) ) ",
        "B08 stray close after nested form",
        |e| matches!(e, ReadError::UnexpectedClose { at } if at.0 == 10),
    );
    // B09: quoted empty list rejected at read.
    audit_err(
        "nil (f x) (quote ())",
        "B09 quoted empty list rejected at read",
        |e| matches!(e, ReadError::EmptyApplication { at } if at.0 == 17),
    );
    // B10: control char in third form.
    audit_err(
        "s1 s2 a\u{1}b",
        "B10 control char in third form",
        |e| matches!(e, ReadError::InvalidSymbol(kerf_span::SymbolError::InvalidSymbol { text }) if text == "a\u{1}b"),
    );

    // ---- Section C: complex-program negative (5) ----
    // C01: nesting over the cap.
    audit_err(
        &deep(NESTING_LIMIT + 1, "x"),
        "C01 nesting over the cap",
        |e| matches!(e, ReadError::NestingDepthExceeded { depth, limit } if *depth == NESTING_LIMIT + 1 && *limit == NESTING_LIMIT),
    );
    // C02: deep nesting with unclosed bottom.
    audit_err(
        &deep(200, "(f"),
        "C02 deep nesting with unclosed bottom",
        |e| matches!(e, ReadError::UnclosedList { .. }),
    );
    // C03: empty application at nesting bottom.
    audit_err(
        &deep(150, "()"),
        "C03 empty application at nesting bottom",
        |e| matches!(e, ReadError::EmptyApplication { .. }),
    );
    // C04: malformed number at nesting bottom.
    audit_err(
        &deep(100, "1.2.3"),
        "C04 malformed number at nesting bottom",
        |e| matches!(e, ReadError::MalformedNumber { .. }),
    );
    // Wide-and-deep: 100 levels, wide fan-out at each level, one stray
    // close grafted at the end.
    let wide = {
        let level = "(f a b (g c";
        let mut src = String::new();
        for _ in 0..10 {
            src.push_str(level);
        }
        src.push(')');
        src
    };
    // C05: wide nesting with unbalanced tail.
    audit_err(&wide, "C05 wide nesting with unbalanced tail", |e| {
        matches!(e, ReadError::UnclosedList { .. })
    });

    // ---- Section D: error-recovery (5, Stage 0 semantics) ----
    // One error must not poison anything after it: independent calls
    // stay isolated and the corrected source reads cleanly.
    {
        // D01: unclosed -> close it.
        assert!(read_program(FILE, "(f").is_err());
        audit_ok("(f 1)", 1, "D01 corrected list reads");
    }
    {
        // D02: mid-program error -> truncate to the valid prefix.
        assert!(read_program(FILE, "(a 1) (b").is_err());
        audit_ok("(a 1)", 1, "D02 valid prefix reads after failure");
    }
    {
        // D03: empty application -> give it an operator.
        assert!(read_program(FILE, "()").is_err());
        audit_ok("(f 1)", 1, "D03 operator-given form reads");
    }
    {
        // D04: over-cap nesting -> shrink one level (cap boundary both
        // ways in one recovery pair).
        assert!(read_program(FILE, &deep(NESTING_LIMIT + 1, "x")).is_err());
        audit_ok(&deep(NESTING_LIMIT, "x"), 1, "D04 cap-edge nesting reads");
    }
    {
        // D05: invalid escape -> valid escape, same call sequence.
        assert!(read_program(FILE, "\"a\\x\"").is_err());
        audit_ok("\"a\\n\"", 1, "D05 escaped newline string reads");
    }

    // ---- Section E: expander negatives (10, sub-stage 0.4) ----
    // The reader -> expander full path plus synthesized-tree faces;
    // every case is a structured ExpandError, never a panic.
    // E01: unbound identifier, single form (class 2).
    expand_err(
        "(define (f) nope)",
        "E01 unbound identifier in single form",
        |e| matches!(e, ExpandError::UnboundIdentifier { .. }),
    );
    // E02: unbound identifier in a later form of a multi-form program.
    expand_err(
        "(define a 1) (define (g) missing)",
        "E02 unbound identifier in later form",
        |e| matches!(e, ExpandError::UnboundIdentifier { name, .. } if name.as_str() == "missing"),
    );
    // E03: expansion work budget exceeded on a synthesized deep tree
    // (class 7 — the reader cap cannot produce this; the expander
    // budget bounds synthesized/macro-produced trees independently).
    {
        let span =
            kerf::span::Span::root(FILE, ByteOffset(0), ByteOffset(1)).expect("audit fixture span");
        // A global head and a literal innermost atom: the budget is
        // the only possible failure.
        let mut node = SyntaxObject::int(span, ScopeSet::new(), Phase::Runtime, 42);
        for _ in 0..EXPANSION_LIMIT {
            let head = SyntaxObject::symbol(span, ScopeSet::new(), Phase::Runtime, "+")
                .expect("audit fixture symbol");
            node = SyntaxObject::list(span, ScopeSet::new(), Phase::Runtime, vec![head, node]);
        }
        let mut ctx = ExpandCtx::new();
        match expand(&mut ctx, &node) {
            Ok(_) => panic!("audit case `E03` must fail, but the deep tree expanded"),
            Err(err) => assert!(
                matches!(err, ExpandError::ExpansionDepthExceeded { .. }),
                "audit case `E03` failed with the wrong error: {err}"
            ),
        }
    }
    // E04: phase closure — macro-phase syntax is not runtime code.
    {
        let span =
            kerf::span::Span::root(FILE, ByteOffset(0), ByteOffset(1)).expect("audit fixture span");
        let form = SyntaxObject::symbol(span, ScopeSet::new(), Phase::MacroExpansion, "x")
            .expect("audit fixture symbol");
        let mut ctx = ExpandCtx::new();
        match expand(&mut ctx, &form) {
            Ok(_) => panic!("audit case `E04` must fail, but macro-phase expanded"),
            Err(err) => assert!(
                matches!(err, ExpandError::PhaseViolation { .. }),
                "audit case `E04` failed with the wrong error: {err}"
            ),
        }
    }
    // E05: malformed special form (two-armed if).
    expand_err(
        "(define (f) (if 1 2))",
        "E05 two-armed if is malformed",
        |e| matches!(e, ExpandError::MalformedForm { form, .. } if *form == "if"),
    );
    // E06: bare top-level expression (declarations only at module top).
    expand_err("(f 1)", "E06 bare top-level expression", |e| {
        matches!(e, ExpandError::TopLevelExpression { .. })
    });
    // E07: set! to an unbound target (class 2, assignment face).
    expand_err(
        "(define (f) (set! nope 1))",
        "E07 set! to unbound target",
        |e| matches!(e, ExpandError::UnboundIdentifier { name, .. } if name.as_str() == "nope"),
    );
    // E08: duplicate parameters re-asserted through the expander.
    expand_err(
        "(define (f x x) x)",
        "E08 duplicate params via expander",
        |e| {
            matches!(e, ExpandError::Core { source, .. }
            if *source == CoreError::DuplicateParam {
                name: kerf_span::Symbol::new("x").expect("fixture symbol must be valid")
            })
        },
    );
    // E09: empty synthesized form (class 3, expander detection point —
    // the reader already rejects `()` in source; this is the second
    // fail-closed layer for hand-built trees).
    {
        let span =
            kerf::span::Span::root(FILE, ByteOffset(0), ByteOffset(2)).expect("audit fixture span");
        let form = SyntaxObject::list(span, ScopeSet::new(), Phase::Runtime, vec![]);
        let mut ctx = ExpandCtx::new();
        match expand(&mut ctx, &form) {
            Ok(_) => panic!("audit case `E09` must fail, but the empty form expanded"),
            Err(err) => assert!(
                matches!(err, ExpandError::EmptyForm { .. }),
                "audit case `E09` failed with the wrong error: {err}"
            ),
        }
    }
    // E10: malformed handle clause (one-element pair).
    expand_err(
        "(define (f) (handle 1 (E)))",
        "E10 malformed handle clause",
        |e| matches!(e, ExpandError::MalformedForm { form, .. } if *form == "handle"),
    );

    // ---- Section F: compiler negatives (10, sub-stage 0.5) ----
    // The expander -> compiler full path plus hand-built bad
    // products; every case is a structured CompileError from the
    // compile-time defenses or from Bytecode::verify, never a panic.
    use kerf::compiler::{
        Bytecode as FBytecode, CompileError, FuncProto, Instr as FInstr, Opcode,
        compile as fcompile, compile_program as fcompile_program,
    };
    use kerf::core::{CoreExpr as FExpr, LiteralValue as FLit};

    fn fspan(start: u32, end: u32) -> kerf::span::Span {
        kerf::span::Span::root(FILE, ByteOffset(start), ByteOffset(end))
            .expect("audit fixture span")
    }

    /// Hand-built entry proto with one pooled constant (index 0).
    fn fentry(code: Vec<FInstr>, debug_len: usize) -> FBytecode {
        let mut f = FuncProto::new(None, 0, 0);
        f.code = code;
        f.debug_info = vec![fspan(0, 1); debug_len];
        let mut bc = FBytecode::default();
        bc.consts.push(FLit::Int(0));
        bc.funcs.push(f);
        bc
    }

    // F01: compile depth cap on a synthesized 1025-deep chain.
    {
        let mut e = FExpr::Literal {
            span: fspan(0, 1),
            value: FLit::Int(0),
        };
        for _ in 0..1024 {
            e = FExpr::Apply {
                span: fspan(0, 1),
                func: Box::new(FExpr::var(fspan(0, 1), "+").unwrap()),
                args: vec![e],
            };
        }
        match fcompile(&e) {
            Ok(_) => panic!("audit case `F01` must fail, but the deep tree compiled"),
            Err(err) => assert!(
                matches!(err, CompileError::DepthExceeded { depth: 1025, .. }),
                "audit case `F01` failed with the wrong error: {err}"
            ),
        }
    }
    // F02: verify rejects a jump target beyond the code length.
    {
        let bc = fentry(
            vec![
                FInstr::new(Opcode::PushConst),
                FInstr::with_a(Opcode::Jump, 9),
                FInstr::new(Opcode::Halt),
            ],
            3,
        );
        let err = bc.verify().expect_err("audit case `F02` must fail");
        assert!(
            matches!(
                err,
                CompileError::JumpTargetOutOfRange {
                    pc: 1,
                    target: 9,
                    ..
                }
            ),
            "audit case `F02` failed with the wrong error: {err}"
        );
    }
    // F03: verify rejects a pop on the empty stack.
    {
        let bc = fentry(vec![FInstr::new(Opcode::Pop), FInstr::new(Opcode::Halt)], 2);
        let err = bc.verify().expect_err("audit case `F03` must fail");
        assert!(
            matches!(err, CompileError::StackUnderflow { pc: 0, .. }),
            "audit case `F03` failed with the wrong error: {err}"
        );
    }
    // F04: verify rejects a branch-depth imbalance.
    {
        let bc = fentry(
            vec![
                FInstr::new(Opcode::PushConst),
                FInstr::new(Opcode::PushConst),
                FInstr::with_a(Opcode::JumpIfFalse, 4),
                FInstr::new(Opcode::PushConst),
                FInstr::new(Opcode::Halt),
            ],
            5,
        );
        let err = bc.verify().expect_err("audit case `F04` must fail");
        assert!(
            matches!(
                err,
                CompileError::StackImbalance {
                    pc: 4,
                    expected: 1,
                    actual: 2,
                    ..
                }
            ),
            "audit case `F04` failed with the wrong error: {err}"
        );
    }
    // F05: verify rejects a bare instruction (debug_info missing).
    {
        let bc = fentry(vec![FInstr::new(Opcode::Halt)], 0);
        let err = bc.verify().expect_err("audit case `F05` must fail");
        assert!(
            matches!(err, CompileError::DebugInfoMissing { func: 0, pc: 0 }),
            "audit case `F05` failed with the wrong error: {err}"
        );
    }
    // F06: verify rejects an out-of-range constant index.
    {
        let bc = fentry(
            vec![
                FInstr::with_a(Opcode::PushConst, 7),
                FInstr::new(Opcode::Halt),
            ],
            2,
        );
        let err = bc.verify().expect_err("audit case `F06` must fail");
        assert!(
            matches!(
                err,
                CompileError::ConstIndexOutOfRange {
                    pc: 0,
                    index: 7,
                    ..
                }
            ),
            "audit case `F06` failed with the wrong error: {err}"
        );
    }
    // F07: verify rejects halt inside a non-entry proto.
    {
        let mut bc = fentry(vec![FInstr::new(Opcode::Halt)], 1);
        let mut closure = FuncProto::new(None, 0, 0);
        closure.code = vec![FInstr::new(Opcode::Halt)];
        closure.debug_info = vec![fspan(0, 1)];
        bc.funcs.push(closure);
        let err = bc.verify().expect_err("audit case `F07` must fail");
        assert!(
            matches!(err, CompileError::HaltOutsideEntry { pc: 0, .. }),
            "audit case `F07` failed with the wrong error: {err}"
        );
    }
    // F08: verify rejects a proto that does not end in ret/halt.
    {
        let bc = fentry(
            vec![FInstr::new(Opcode::PushConst), FInstr::new(Opcode::Pop)],
            2,
        );
        let err = bc.verify().expect_err("audit case `F08` must fail");
        assert!(
            matches!(err, CompileError::MissingTerminator { func: 0, pc: 1 }),
            "audit case `F08` failed with the wrong error: {err}"
        );
    }
    // F09: verify rejects an out-of-range closure proto index.
    {
        let bc = fentry(
            vec![
                FInstr::with_a(Opcode::Closure, 5),
                FInstr::new(Opcode::Halt),
            ],
            2,
        );
        let err = bc.verify().expect_err("audit case `F09` must fail");
        assert!(
            matches!(
                err,
                CompileError::ProtoIndexOutOfRange {
                    pc: 0,
                    index: 5,
                    ..
                }
            ),
            "audit case `F09` failed with the wrong error: {err}"
        );
    }
    // F10: verify rejects an out-of-range local slot.
    {
        let bc = fentry(
            vec![
                FInstr::with_a(Opcode::LoadLocal, 3),
                FInstr::new(Opcode::Halt),
            ],
            2,
        );
        let err = bc.verify().expect_err("audit case `F10` must fail");
        assert!(
            matches!(
                err,
                CompileError::LocalSlotOutOfRange { pc: 0, slot: 3, .. }
            ),
            "audit case `F10` failed with the wrong error: {err}"
        );
    }
    // Cross-check: a full source program compiles and verifies (the
    // compile-output-passes-verify contract) — not counted in F, a
    // guard against vacuous rejection tests.
    {
        let src = "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2)))))";
        let forms = read_program(FILE, src).expect("audit guard must read");
        let items = expand_program(&forms).expect("audit guard must expand");
        let bc = fcompile_program(&items).expect("audit guard must compile");
        bc.verify()
            .expect("audit guard: compile output must verify");
    }

    // ---- Section G: VM negative (10, sub-stage 0.6) ----
    // SOP §7.1.1 classes 4 (argument count) and 5 (type mismatch)
    // light up here; the remaining cases pin the fail-closed runtime
    // paths. Source-level wherever the pipeline can reach them.
    {
        use kerf::compiler::compile_program as gcompile_program;
        use kerf::vm::{RuntimeError as VmErr, Vm};

        fn vrun(src: &str) -> Result<kerf::vm::Value, VmErr> {
            let forms = read_program(FILE, src).expect("audit source must read");
            let items = expand_program(&forms).expect("audit source must expand");
            let bc = gcompile_program(&items).expect("audit source must compile");
            let mut vm = Vm::new(bc).expect("audit source must verify at load");
            vm.run()
        }

        // G01: closure arity — proto params vs call count (class 4).
        match vrun("(define (f x) x) (define r (f 1 2))") {
            Err(VmErr::ArityMismatch {
                func,
                expected,
                actual,
                ..
            }) if func.as_ref().map(|s| s.as_str()) == Some("f")
                && (expected, actual) == (1, 2) => {}
            other => panic!("audit case `G01` unexpected: {other:?}"),
        }
        // G02: builtin arity — fixed-arity registry row (class 4).
        match vrun("(define r (+ 1 2 3))") {
            Err(VmErr::ArityMismatch {
                func,
                expected,
                actual,
                ..
            }) if func.as_ref().map(|s| s.as_str()) == Some("+")
                && (expected, actual) == (2, 3) => {}
            other => panic!("audit case `G02` unexpected: {other:?}"),
        }
        // G03: truthy demands bool (class 5).
        match vrun("(define r (if 1 2 3))") {
            Err(VmErr::TypeMismatch { got, context, .. })
                if got == "int" && context == "jump-if-false condition" => {}
            other => panic!("audit case `G03` unexpected: {other:?}"),
        }
        // G04: arithmetic demands same-kind numbers (class 5).
        match vrun("(define r (+ 1 #t))") {
            Err(VmErr::TypeMismatch { got, context, .. })
                if got == "bool" && context == "add operand" => {}
            other => panic!("audit case `G04` unexpected: {other:?}"),
        }
        // G05: car demands a pair (class 5).
        match vrun("(define r (car 5))") {
            Err(VmErr::TypeMismatch { got, context, .. })
                if got == "int" && context == "car operand" => {}
            other => panic!("audit case `G05` unexpected: {other:?}"),
        }
        // G06: calls demand a callable callee (class 5).
        match vrun("(define f 5) (define r (f 1))") {
            Err(VmErr::TypeMismatch { got, context, .. })
                if got == "int" && context == "call callee" => {}
            other => panic!("audit case `G06` unexpected: {other:?}"),
        }
        // G07: perform without a matching handler.
        match vrun("(define r (perform log 1))") {
            Err(VmErr::UnhandledEffect { effect, .. }) if effect.as_str() == "log" => {}
            other => panic!("audit case `G07` unexpected: {other:?}"),
        }
        // G08: integer division by zero fails closed.
        match vrun("(define r (/ 1 0))") {
            Err(VmErr::DivByZero { .. }) => {}
            other => panic!("audit case `G08` unexpected: {other:?}"),
        }
        // G09: i64 overflow fails closed (no wrapping).
        match vrun("(define r (+ 9223372036854775807 1))") {
            Err(VmErr::ArithmeticOverflow { .. }) => {}
            other => panic!("audit case `G09` unexpected: {other:?}"),
        }
        // G10: the §19.4 allocation budget bounds recursion.
        {
            let src = "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define r (fib 10))";
            let forms = read_program(FILE, src).expect("audit source must read");
            let items = expand_program(&forms).expect("audit source must expand");
            let bc = gcompile_program(&items).expect("audit source must compile");
            let mut vm = Vm::with_budget(bc, 8).expect("audit source must verify at load");
            match vm.run() {
                Err(VmErr::BudgetExceeded { budget: 8, .. }) => {}
                other => panic!("audit case `G10` unexpected: {other:?}"),
            }
        }
    }

    // ---- Section H: runtime negative (10, sub-stage 0.7) ----
    // The dual-path faces: evaluator negatives (the same source the
    // VM rejects must fail identically through eval — the parity
    // contract at the error layer), the GC retention guards (§19.4
    // root completeness), and the parity-detector self-check.
    {
        use kerf::compiler::compile_program as hcompile_program;
        use kerf::runtime::{Evaluator, MarkSweep, parity_repr};
        use kerf::vm::{RuntimeError as VmErr, Vm};

        fn erun(src: &str) -> Result<kerf::vm::Value, VmErr> {
            let forms = read_program(FILE, src).expect("audit source must read");
            let items = expand_program(&forms).expect("audit source must expand");
            let mut ev = Evaluator::new();
            ev.eval_program(&items)
        }

        // H01: evaluator arity — closure face (class 4 on the eval path).
        match erun("(define (f x) x) (define r (f 1 2))") {
            Err(VmErr::ArityMismatch {
                func,
                expected,
                actual,
                ..
            }) if func.as_ref().map(|s| s.as_str()) == Some("f")
                && (expected, actual) == (1, 2) => {}
            other => panic!("audit case `H01` unexpected: {other:?}"),
        }
        // H02: evaluator arity — builtin face.
        match erun("(define r (+ 1 2 3))") {
            Err(VmErr::ArityMismatch {
                func,
                expected,
                actual,
                ..
            }) if func.as_ref().map(|s| s.as_str()) == Some("+")
                && (expected, actual) == (2, 3) => {}
            other => panic!("audit case `H02` unexpected: {other:?}"),
        }
        // H03: evaluator type — truthy condition (class 5).
        match erun("(define r (if 1 2 3))") {
            Err(VmErr::TypeMismatch { got, context, .. })
                if got == "int" && context == "jump-if-false condition" => {}
            other => panic!("audit case `H03` unexpected: {other:?}"),
        }
        // H04: evaluator type — mixed-kind arithmetic.
        match erun("(define r (+ 1 #t))") {
            Err(VmErr::TypeMismatch { got, context, .. })
                if got == "bool" && context == "add operand" => {}
            other => panic!("audit case `H04` unexpected: {other:?}"),
        }
        // H05: evaluator type — car of a non-pair.
        match erun("(define r (car 5))") {
            Err(VmErr::TypeMismatch { got, context, .. })
                if got == "int" && context == "car operand" => {}
            other => panic!("audit case `H05` unexpected: {other:?}"),
        }
        // H06: evaluator div-zero (fail-closed pair, first arm).
        match erun("(define r (/ 1 0))") {
            Err(VmErr::DivByZero { .. }) => {}
            other => panic!("audit case `H06` unexpected: {other:?}"),
        }
        // H07: evaluator unhandled effect (fail-closed pair, second arm).
        match erun("(define r (perform log 1))") {
            Err(VmErr::UnhandledEffect { effect, .. }) if effect.as_str() == "log" => {}
            other => panic!("audit case `H07` unexpected: {other:?}"),
        }
        // H08: the evaluator depth cap (Rust-stack guard, eval-only).
        // The capped eval leg needs more than the default main-thread
        // stack on this toolchain (measured between 8 and 12 MiB; the
        // r74 BST-1 lineage applied to the audit face, r83), so the
        // run rides a deep-stack thread. `Value` carries `Rc`, so the
        // verdict is decided inside the thread and only the compact
        // diagnostic crosses back.
        let h08 = std::thread::Builder::new()
            .stack_size(64 * 1024 * 1024)
            .spawn(|| {
                match erun("(define (cd n) (if (= n 0) 0 (cd (- n 1)))) (define r (cd 3000))") {
                    Err(VmErr::EvalDepthExceeded { limit: 2048, .. }) => Ok(()),
                    other => Err(format!("{other:?}")),
                }
            })
            .expect("spawn the deep-stack thread")
            .join()
            .expect("the deep-stack thread finished cleanly");
        match h08 {
            Ok(()) => {}
            Err(detail) => panic!("audit case `H08` unexpected: {detail}"),
        }
        // H09: GC retention — root completeness on the VM injection
        // face: a tight-budget discarding program survives ONLY
        // because the cycle reclaims the dead cells and keeps every
        // rooted one (a false reclaim would corrupt the result).
        {
            let src = "(define r (+ (car (cons 1 2)) (+ (car (cons 3 4)) (+ (car (cons 5 6)) (car (cons 7 8))))))";
            let forms = read_program(FILE, src).expect("audit source must read");
            let items = expand_program(&forms).expect("audit source must expand");
            let bc = hcompile_program(&items).expect("audit source must compile");
            let mut vm = Vm::with_budget_and_collector(bc, 4, Box::new(MarkSweep)).expect("loads");
            vm.run().expect("audit case `H09` collect-then-retry runs");
            assert_eq!(
                vm.global("r"),
                Some(&kerf::vm::Value::Int(16)),
                "audit case `H09` retention is exact"
            );
        }
        // H10: parity detector self-check — structurally different
        // results must render different reprs (a detector that
        // cannot fail proves nothing).
        {
            let run = |src: &str| -> String {
                let forms = read_program(FILE, src).expect("audit source must read");
                let items = expand_program(&forms).expect("audit source must expand");
                let mut ev = Evaluator::new();
                let v = ev.eval_program(&items).expect("audit eval runs");
                match ev.global("r") {
                    Some(r) => parity_repr(r, ev.heap()),
                    None => parity_repr(&v, ev.heap()),
                }
            };
            let a = run("(define r (cons 1 2))");
            let b = run("(define r (cons 2 1))");
            assert_ne!(a, b, "audit case `H10` detector must see the difference");
            assert_eq!(a, "(1 . 2)");
        }
    }

    // ---- Section I: driver end-to-end negative + orchestration (10,
    // sub-stage 0.8 — monotonic growth per §7.3.1 rule 4) ----
    {
        use kerf::driver::{
            DiagnosticCode, Engine, Repl, ReplEvent, Session, render_diagnostics, run_source,
        };

        let drun = |src: &str| run_source(&mut Session::new(), "i.krf", src, Engine::Vm, &[]);
        let drun_err = |src: &str| {
            let mut session = Session::new();
            match run_source(&mut session, "i.krf", src, Engine::Vm, &[]) {
                Ok(_) => panic!("audit source must fail: {src}"),
                Err(diags) => (session, diags),
            }
        };

        // I01: syntax error renders with line:column + excerpt (the
        // TD-001 payoff through the driver).
        {
            let (session, diags) = drun_err("(+ 1 2");
            assert_eq!(diags[0].code, DiagnosticCode::Read);
            let rendered = render_diagnostics(&session, &diags);
            assert!(rendered.contains("--> i.krf:1:1"), "I01: {rendered}");
            assert!(rendered.contains("unclosed delimiter"));
        }
        // I02: empty application — the reader-class second case.
        {
            let (_, diags) = drun_err("()");
            assert_eq!(diags[0].code, DiagnosticCode::Read);
            assert!(diags[0].message.contains("empty application"), "I02");
        }
        // I03: unbound identifier (expander class).
        {
            let (_, diags) = drun_err("(define r (no-such-fn))");
            assert_eq!(diags[0].code, DiagnosticCode::Expand, "I03");
        }
        // I04: arity mismatch (runtime class). Stage 1.1 co-change:
        // a known-callee arity mismatch now surfaces statically as
        // E0002 (section N01); the runtime face stays audited through
        // a checker-opaque param-mediated call (the R2 assign/lexical
        // guards deliberately skip it).
        {
            let (_, diags) = drun_err("(define r ((fn (g) (g 1 2)) car))");
            assert_eq!(diags[0].code, DiagnosticCode::Runtime, "I04");
            assert!(diags[0].message.contains("arity mismatch"), "I04");
        }
        // I05: type mismatch (runtime class). The Stage 1.8 HM
        // wiring hoists literal (+ 1 #t) to the checker (E0009);
        // routing through an unchecked dynamic parameter keeps the
        // runtime face on the audit (probe-verified, §9.49 GATE-2).
        {
            let (_, diags) = drun_err("(define r ((fn (x) (car x)) 5))");
            assert_eq!(diags[0].code, DiagnosticCode::Runtime, "I05");
            assert!(diags[0].message.contains("type mismatch"), "I05");
        }
        // I06: multi-file multi-diagnostic — §12.2 errors-are-data:
        // both broken files report in one render pass.
        {
            let mut session = Session::new();
            let mut all = Vec::new();
            for (name, src) in [("i-a.krf", "(+ 1"), ("i-b.krf", "(define r (nope))")] {
                if let Err(diags) = run_source(&mut session, name, src, Engine::Vm, &[]) {
                    all.extend(diags);
                }
            }
            assert_eq!(all.len(), 2, "I06 both files report");
            let rendered = render_diagnostics(&session, &all);
            assert!(
                rendered.contains("aborting due to 2 previous errors"),
                "I06"
            );
        }
        // I07: REPL error-then-recovery — a failed submission rolls
        // back and the session stays usable.
        {
            let mut repl = Repl::new();
            match repl.submit("(define x 1)") {
                ReplEvent::Evaluated { .. } => {}
                other => panic!("I07 define: {other:?}"),
            }
            match repl.submit("(broken-call)") {
                ReplEvent::Error { rendered } => {
                    assert!(rendered.contains("kerf-expand"), "I07 error face")
                }
                other => panic!("I07 must error: {other:?}"),
            }
            match repl.submit("(+ x 1)") {
                ReplEvent::Evaluated { value, .. } => {
                    assert_eq!(value.as_deref(), Some("2"), "I07 session survives")
                }
                other => panic!("I07 recovery: {other:?}"),
            }
        }
        // I08: check face — compile + verify without execution (a
        // program with an output effect produces no output).
        {
            let mut session = Session::new();
            let check = kerf::driver::check_source(
                &mut session,
                "i.krf",
                "(define r (write-line (quote-not-needed 1)))",
            );
            // The body references an unbound function — check must
            // fail at expansion, NOT execute anything.
            assert!(check.is_err(), "I08 check rejects unbound callee");
        }
        // I09: parity mode — the dual-engine report agrees on fib and
        // a divergence is data, not a panic (detector self-check).
        {
            let mut session = Session::new();
            let fib_src = "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define r (fib 8))";
            let report = kerf::driver::run_parity_source(&mut session, "i.krf", fib_src, &[])
                .expect("I09 parity run");
            assert!(report.agrees(), "I09 fib agrees: {report:?}");
            let divergent = kerf::driver::ParityReport {
                vm_repr: "1".to_owned(),
                eval_repr: "2".to_owned(),
                values_agree: false,
                outputs_agree: true,
                globals_agree: true,
                // Stage 1.4 field: a hand-built detector self-check
                // carries no globals.
                globals_repr: Vec::new(),
                warnings: Vec::new(),
            };
            assert!(!divergent.agrees(), "I09 divergence is data");
        }
        // I10: rendering edges — CJK character columns (registered
        // fixture), the literal family's whole-token location
        // (v0.40.0 §9.71: `#q` renders a caret extent under the
        // token), and the genuinely position-less diagnostic (the
        // whole-stream nesting defect keeps no fabricated `-->`).
        {
            let (session, diags) = drun_err("(define \u{540d} (+ 1 2)))");
            let rendered = render_diagnostics(&session, &diags);
            assert!(
                rendered.contains("--> i.krf:1:19"),
                "I10 char columns: {rendered}"
            );
            assert!(!rendered.contains("1:21"), "I10 byte columns would say 21");
            let mut session2 = Session::new();
            let diags2 = run_source(&mut session2, "i.krf", "#q", Engine::Vm, &[])
                .expect_err("I10 invalid bool carries its token span");
            assert!(
                diags2[0].primary_span.is_some(),
                "I10 the literal family carries its whole-token span"
            );
            let rendered2 = render_diagnostics(&session2, &diags2);
            assert!(
                rendered2.contains("--> i.krf:1:1"),
                "I10 literal location line: {rendered2}"
            );
            assert!(
                rendered2.contains("^"),
                "I10 literal caret extent: {rendered2}"
            );
            let mut session3 = Session::new();
            let mut deep = String::new();
            for _ in 0..257 {
                deep.push('(');
            }
            deep.push('x');
            let diags3 = run_source(&mut session3, "i.krf", &deep, Engine::Vm, &[])
                .expect_err("I10 nesting defect is positionless");
            assert!(diags3[0].primary_span.is_none(), "I10 no fabricated span");
            let rendered3 = render_diagnostics(&session3, &diags3);
            assert!(
                !rendered3.contains("-->"),
                "I10 no location line: {rendered3}"
            );
        }

        let _ = drun; // silence the unused helper when sections change
    }

    // ---- Section J: macro / module / quote negative (10, sub-stage
    // 0.9 — monotonic growth per §7.3.1 rule 4) ----
    {
        use kerf::driver::{DiagnosticCode, Session, parse, render_diagnostics};

        let jerr = |src: &str| {
            let mut session = Session::new();
            match parse(&mut session, "j.krf", src) {
                Ok(_) => panic!("audit source must fail: {src}"),
                Err(diags) => (session, diags),
            }
        };

        // J01: pattern mismatch — no clause fits the use form (the
        // macro-phase family; the use-site location).
        {
            let (session, diags) = jerr(
                "(define-syntax my-if (syntax-rules nil ((_ c t e) (if c t e))))\n(define r (my-if #t 1))",
            );
            assert_eq!(diags[0].code, DiagnosticCode::Expand, "J01");
            let rendered = render_diagnostics(&session, &diags);
            assert!(
                rendered.contains("macro `my-if` matched no clause"),
                "J01: {rendered}"
            );
            assert!(rendered.contains("--> j.krf:2:12"), "J01: {rendered}");
        }
        // J02: quote boundary — symbol data has no Stage 0 value
        // model (fail closed, not silently stringified).
        {
            let (session, diags) = jerr("(define r (quote ghost))");
            assert_eq!(diags[0].code, DiagnosticCode::Expand, "J02");
            let rendered = render_diagnostics(&session, &diags);
            assert!(
                rendered.contains("quote cannot carry this datum"),
                "J02: {rendered}"
            );
        }
        // J03: hygiene defense — a use-site binding must not capture a
        // free introduced reference (the Racket judgment: the
        // introduced `tmp` stays unbound, reported fail-closed).
        {
            let (session, diags) = jerr(
                "(define-syntax m (syntax-rules nil ((_) tmp)))\n(define r (let ((tmp 1)) (m)))",
            );
            assert_eq!(diags[0].code, DiagnosticCode::Expand, "J03");
            let rendered = render_diagnostics(&session, &diags);
            assert!(
                rendered.contains("unbound identifier `tmp`"),
                "J03: {rendered}"
            );
        }
        // J04: hygiene defense — a macro head naming nothing (use
        // before its definition) fails through the unified unbound
        // judgment.
        {
            let (_, diags) = jerr(
                "(define r (my-if #t 1 2))\n(define-syntax my-if (syntax-rules nil ((_ c t e) (if c t e))))",
            );
            assert_eq!(diags[0].code, DiagnosticCode::Expand, "J04");
            assert!(
                diags[0].message.contains("unbound identifier `my-if`"),
                "J04: {}",
                diags[0].message
            );
        }
        // J05: macro expansion depth — a self-recursive macro hits the
        // structured budget (class 5 maintained at the macro face).
        {
            let (_, diags) =
                jerr("(define-syntax loopy (syntax-rules nil ((_) (loopy))))\n(define r (loopy))");
            assert_eq!(diags[0].code, DiagnosticCode::Expand, "J05");
            assert!(
                diags[0].message.contains("expansion depth exceeded"),
                "J05: {}",
                diags[0].message
            );
        }
        // J06: module cycle, two modules — the §7.1.1 class 7 face,
        // end-to-end with the cycle path.
        {
            let (session, diags) = jerr("(module a (require \"b\"))\n(module b (require \"a\"))");
            assert_eq!(diags[0].code, DiagnosticCode::Expand, "J06");
            let rendered = render_diagnostics(&session, &diags);
            assert!(
                rendered.contains("module cycle detected: a -> b -> a"),
                "J06: {rendered}"
            );
        }
        // J07: module cycle, three modules (the longer path closes the
        // same way).
        {
            let (_, diags) = jerr(
                "(module a (require \"b\"))\n(module b (require \"c\"))\n(module c (require \"a\"))",
            );
            assert_eq!(diags[0].code, DiagnosticCode::Expand, "J07");
            assert!(
                diags[0].message.contains("a -> b -> c -> a"),
                "J07: {}",
                diags[0].message
            );
        }
        // J08: module not found — requiring an undeclared module.
        {
            let (_, diags) = jerr("(require \"ghost\")");
            assert_eq!(diags[0].code, DiagnosticCode::Expand, "J08");
            assert!(
                diags[0]
                    .message
                    .contains("required module `ghost` is not declared"),
                "J08: {}",
                diags[0].message
            );
        }
        // J09: duplicate module declarations — the flat namespace is
        // unique.
        {
            let (_, diags) = jerr("(module a (define x 1))\n(module a (define y 2))");
            assert_eq!(diags[0].code, DiagnosticCode::Expand, "J09");
            assert!(
                diags[0]
                    .message
                    .contains("duplicate module declaration `a`"),
                "J09: {}",
                diags[0].message
            );
        }
        // J10: define-syntax registration family — the ellipsis
        // boundary (Stage 0 has no `...` patterns) and the reserved
        // name rejection, both fail-closed at registration.
        {
            let (_, diags) = jerr("(define-syntax m (syntax-rules nil ((_ x ...) (f x))))");
            assert_eq!(diags[0].code, DiagnosticCode::Expand, "J10");
            assert!(
                diags[0].message.contains("malformed `define-syntax`"),
                "J10 ellipsis: {}",
                diags[0].message
            );
            let (_, diags2) = jerr("(define-syntax if (syntax-rules nil ((_ c t e) (if c t e))))");
            assert!(
                diags2[0].message.contains("malformed `define-syntax`"),
                "J10 reserved: {}",
                diags2[0].message
            );
        }
    }

    // ---- Section K: reserved-face contracts (10, sub-stage 0.10 —
    // the frozen reservation face of docs/stage0.md §9.1.1-§9.1.4:
    // witness semantics for effects and multistage, the sealed token
    // discipline, the externally reachable I/O error face, and the
    // executable cache behavior contract; monotonic growth per
    // §7.3.1 rule 4) ----
    {
        use std::cell::Cell;
        use std::collections::HashMap;

        // K01: the effect witness performs and routes through
        // `EffectOp::Result`.
        {
            struct CountingEffects {
                ops: Cell<u32>,
            }
            enum CountEffect {
                Tick,
            }
            impl EffectOp for CountEffect {
                type Result = u32;
            }
            impl EffectSystem for CountingEffects {
                type Effect = CountEffect;
                type Handler = u32;
                type Continuation = ();
                type Value = u32;

                fn perform(&self, effect: CountEffect) -> u32 {
                    match effect {
                        CountEffect::Tick => self.ops.get() + 1,
                    }
                }

                fn handle(&self, handler: u32, computation: impl FnOnce() -> u32) -> u32 {
                    computation() + handler
                }
            }
            let system = CountingEffects { ops: Cell::new(0) };
            assert_eq!(system.perform(CountEffect::Tick), 1, "K01");
        }

        // K02: the effect witness composes the value path through
        // `handle`.
        {
            // Reuses the K01 witness shape; asserted inline for the
            // audit's self-containment.
            struct Passthrough;
            enum NeverEffect {}
            impl EffectOp for NeverEffect {
                type Result = ();
            }
            impl EffectSystem for Passthrough {
                type Effect = NeverEffect;
                type Handler = i32;
                type Continuation = ();
                type Value = i32;

                fn perform(&self, effect: NeverEffect) -> () {
                    match effect {}
                }

                fn handle(&self, handler: i32, computation: impl FnOnce() -> i32) -> i32 {
                    computation() + handler
                }
            }
            let system = Passthrough;
            assert_eq!(system.handle(7, || 35), 42, "K02");
        }

        // K03: the multistage witness quote→splice round-trip.
        {
            struct AuditExpr;
            impl Expr for AuditExpr {}
            struct AuditCode(i64);
            impl CodeCarrier for AuditCode {
                type Inner = i64;
                type Result = i64;
            }
            struct AuditStaging;
            impl MultiStage for AuditStaging {
                type Code = AuditCode;

                fn quote<E: Expr>(_expr: E) -> AuditCode {
                    AuditCode(21)
                }

                fn splice(code: AuditCode) -> i64 {
                    code.0
                }

                fn run(code: AuditCode) -> i64 {
                    code.0 * 2
                }
            }
            let code = AuditStaging::quote(AuditExpr);
            assert_eq!(AuditStaging::splice(code), 21, "K03");
        }

        // K04: the multistage witness runs to the carrier result.
        {
            // Same carrier family as K03; `run` executes.
            struct RunExpr;
            impl Expr for RunExpr {}
            struct RunCode(i64);
            impl CodeCarrier for RunCode {
                type Inner = i64;
                type Result = i64;
            }
            struct RunStaging;
            impl MultiStage for RunStaging {
                type Code = RunCode;

                fn quote<E: Expr>(_expr: E) -> RunCode {
                    RunCode(21)
                }

                fn splice(code: RunCode) -> i64 {
                    code.0
                }

                fn run(code: RunCode) -> i64 {
                    code.0 * 2
                }
            }
            let code = RunStaging::quote(RunExpr);
            assert_eq!(RunStaging::run(code), 42, "K04");
        }

        // K05: the capability tokens are zero-sized with stable
        // Debug forms (the sealed-token discipline visible from
        // outside the defining crate).
        {
            assert_eq!(std::mem::size_of::<ReadCapability>(), 0, "K05 read");
            assert_eq!(std::mem::size_of::<WriteCapability>(), 0, "K05 write");
        }

        // K06: the externally reachable I/O error face — kinds,
        // accessors, and the R8 message shape (lowercase start, no
        // trailing period) across the full closed kind set.
        {
            for kind in [
                IoErrorKind::Eof,
                IoErrorKind::Denied,
                IoErrorKind::Interrupted,
                IoErrorKind::Other,
            ] {
                let err = IOError::new(kind, "audit probe");
                assert_eq!(err.kind(), kind, "K06 kind");
                assert_eq!(err.message(), "audit probe", "K06 message");
                let text = err.to_string();
                let first = text.chars().next().expect("K06 non-empty");
                assert!(first.is_lowercase(), "K06 lowercase: `{text}`");
                assert!(!text.ends_with('.'), "K06 period: `{text}`");
            }
        }

        // The audit-local cache witness (K07-K10).
        struct AuditCache {
            map: HashMap<CacheKey, CachedResult>,
        }
        impl CompilationCache for AuditCache {
            fn get_cached(&self, key: CacheKey) -> Option<CachedResult> {
                self.map.get(&key).cloned()
            }

            fn store(&mut self, key: CacheKey, result: CachedResult) {
                self.map.insert(key, result);
            }

            fn invalidate(&mut self, key: CacheKey) {
                self.map.remove(&key);
            }
        }
        fn audit_key(tag: u8) -> CacheKey {
            let mut digest = [0u8; 32];
            digest[0] = tag;
            CacheKey::from_digest(digest)
        }

        // K07: a never-stored key misses (negative).
        {
            let cache = AuditCache {
                map: HashMap::new(),
            };
            assert!(cache.get_cached(audit_key(7)).is_none(), "K07");
        }

        // K08: store-then-get hits with value equality (positive).
        {
            let mut cache = AuditCache {
                map: HashMap::new(),
            };
            cache.store(audit_key(8), CachedResult::new(vec![8, 8]));
            assert_eq!(
                cache.get_cached(audit_key(8)),
                Some(CachedResult::new(vec![8, 8])),
                "K08"
            );
        }

        // K09: invalidate removes, and invalidating a missing key is a
        // no-op (negatives).
        {
            let mut cache = AuditCache {
                map: HashMap::new(),
            };
            cache.store(audit_key(9), CachedResult::new(vec![9]));
            cache.invalidate(audit_key(9));
            assert!(cache.get_cached(audit_key(9)).is_none(), "K09 removed");
            cache.invalidate(audit_key(9));
            cache.invalidate(audit_key(0x99));
        }

        // K10: latest store wins and stores stay isolated per key.
        {
            let mut cache = AuditCache {
                map: HashMap::new(),
            };
            cache.store(audit_key(10), CachedResult::new(vec![1]));
            cache.store(audit_key(10), CachedResult::new(vec![2]));
            assert_eq!(
                cache.get_cached(audit_key(10)),
                Some(CachedResult::new(vec![2])),
                "K10 latest wins"
            );
            cache.store(audit_key(11), CachedResult::new(vec![7]));
            assert_eq!(
                cache.get_cached(audit_key(10)),
                Some(CachedResult::new(vec![2])),
                "K10 isolation"
            );
        }

        // Full contract kit re-run through the audit witness — the
        // executable behavior spec of the P2 cache face.
        let mut kit_cache = AuditCache {
            map: HashMap::new(),
        };
        check_compilation_cache_contract(&mut kit_cache);
    }

    // ---- Section L: the capability space (10, sub-stage 0.10-r2 —
    // the general capability-model framework: the family contract,
    // the token calculus, and the registration/extension registry
    // with its fail-closed identity validation; the io sub-model
    // re-hung as the first concrete model; monotonic growth per
    // §7.3.1 rule 4) ----
    {
        use kerf::core::reserved::capability::family::{
            CapabilityModelDescriptor, CapabilityModelFamily,
        };
        use kerf::core::reserved::capability::io::IoModel;
        use kerf::core::reserved::capability::registry::{
            CapabilityModelRegistry, RegistryError, RegistryErrorKind,
        };
        use kerf::core::reserved::capability::token::TokenCalculus;

        /// A second model defined at the audit position — the
        /// extension witness: the canonical clock resource enters
        /// the same closed world as io without any framework change.
        struct AuditClockModel;

        impl CapabilityModelFamily for AuditClockModel {
            type Error = RegistryError;
            fn descriptor() -> CapabilityModelDescriptor {
                CapabilityModelDescriptor::new("clock", &["clock.now"], "ClockSource")
            }
        }

        // L01: the io sub-model binds the frozen error face and its
        // identity card through the family contract (positive).
        {
            let d = <IoModel as CapabilityModelFamily>::descriptor();
            assert_eq!(d.name(), "io", "L01 name");
            assert_eq!(d.operation_face(), "CapabilityIO", "L01 operation face");
            assert_eq!(d.authorities(), &["io.read", "io.write"], "L01 authorities");
            let err: <IoModel as CapabilityModelFamily>::Error =
                IOError::new(IoErrorKind::Denied, "L01");
            assert_eq!(err.kind(), IoErrorKind::Denied, "L01 error face");
        }

        // L02: the reserved mechanism end-to-end — register io into
        // a fresh registry and resolve it back (positive).
        {
            let mut registry = CapabilityModelRegistry::new();
            registry.register::<IoModel>().expect("L02 registers");
            assert_eq!(registry.len(), 1, "L02 len");
            assert_eq!(
                registry.lookup("io").map(|d| d.operation_face()),
                Some("CapabilityIO"),
                "L02 lookup"
            );
        }

        // L03: a duplicate model name is rejected fail-closed and
        // the closed world is unchanged (negative).
        {
            let mut registry = CapabilityModelRegistry::new();
            registry.register::<IoModel>().expect("L03 first");
            let err = registry
                .register::<IoModel>()
                .expect_err("L03 duplicate is rejected");
            assert_eq!(err.kind(), RegistryErrorKind::DuplicateModel, "L03 kind");
            assert_eq!(registry.len(), 1, "L03 closed world unchanged");
        }

        // L04: an authority already governed by another model is
        // rejected fail-closed — unique subordination (negative).
        {
            let mut registry = CapabilityModelRegistry::new();
            registry.register::<IoModel>().expect("L04 io registers");
            struct Claimer;
            impl CapabilityModelFamily for Claimer {
                type Error = RegistryError;
                fn descriptor() -> CapabilityModelDescriptor {
                    CapabilityModelDescriptor::new("other", &["io.read"], "OtherIO")
                }
            }
            let err = registry
                .register::<Claimer>()
                .expect_err("L04 authority conflict is rejected");
            assert_eq!(err.kind(), RegistryErrorKind::AuthorityConflict, "L04 kind");
            assert!(err.message().contains("io.read"), "L04 names the term");
        }

        // L05: malformed identity cards are rejected — an empty name
        // and an empty authority list (negative).
        {
            let mut registry = CapabilityModelRegistry::new();
            struct Shaped;
            impl CapabilityModelFamily for Shaped {
                type Error = RegistryError;
                fn descriptor() -> CapabilityModelDescriptor {
                    // `descriptor()` must be a compile-time shape, so
                    // the malformed probes use the const face: an
                    // empty name is rejected here; the empty-authority
                    // variant is exercised in the unit suite (the
                    // audit exercises one representative per family).
                    CapabilityModelDescriptor::new("", &["x.read"], "XIO")
                }
            }
            let err = registry
                .register::<Shaped>()
                .expect_err("L05 empty name is rejected");
            assert_eq!(err.kind(), RegistryErrorKind::InvalidDescriptor, "L05 kind");
        }

        // L06: a self-duplicated authority term inside one descriptor
        // is rejected — the card contradicts itself (negative).
        {
            let mut registry = CapabilityModelRegistry::new();
            struct SelfDup;
            impl CapabilityModelFamily for SelfDup {
                type Error = RegistryError;
                fn descriptor() -> CapabilityModelDescriptor {
                    CapabilityModelDescriptor::new("x", &["x.read", "x.read"], "XIO")
                }
            }
            let err = registry
                .register::<SelfDup>()
                .expect_err("L06 self-duplicate is rejected");
            assert_eq!(err.kind(), RegistryErrorKind::InvalidDescriptor, "L06 kind");
            assert!(err.message().contains("x.read"), "L06 names the term");
        }

        // L07: unknown names and ungoverned authorities resolve to
        // no one — the closed world answers only what it governs
        // (negative).
        {
            let mut registry = CapabilityModelRegistry::new();
            registry.register::<IoModel>().expect("L07 io registers");
            assert!(registry.lookup("clock").is_none(), "L07 unknown name");
            assert!(
                registry.governing_model("clock.now").is_none(),
                "L07 ungoverned"
            );
            assert!(
                !registry.governed_authorities().contains(&"clock.now"),
                "L07 world"
            );
        }

        // L08: the extension ability — a model defined at this audit
        // position registers alongside io; the closed world grows
        // additively with zero framework change (positive).
        {
            let mut registry = CapabilityModelRegistry::new();
            registry.register::<IoModel>().expect("L08 io registers");
            registry
                .register::<AuditClockModel>()
                .expect("L08 the audit-position model registers");
            assert_eq!(
                registry.governed_authorities(),
                vec!["io.read", "io.write", "clock.now"],
                "L08 closed world spans both positions"
            );
            assert_eq!(
                registry.governing_model("clock.now").map(|d| d.name()),
                Some("clock"),
                "L08 resolution"
            );
        }

        // L09: the registry error face renders in the R8 message
        // shape and its kinds stay pairwise distinct (negative).
        {
            for kind in [
                RegistryErrorKind::InvalidDescriptor,
                RegistryErrorKind::DuplicateModel,
                RegistryErrorKind::AuthorityConflict,
            ] {
                let err = RegistryError::new(kind, "L09");
                let text = err.to_string();
                assert!(
                    text.chars().next().expect("L09 non-empty").is_lowercase(),
                    "L09 lowercase start: `{text}`"
                );
                assert!(!text.ends_with('.'), "L09 no trailing period: `{text}`");
                assert!(text.contains("L09"), "L09 payload carried: `{text}`");
            }
            let texts: Vec<String> = [
                RegistryErrorKind::InvalidDescriptor,
                RegistryErrorKind::DuplicateModel,
                RegistryErrorKind::AuthorityConflict,
            ]
            .iter()
            .map(|k| RegistryError::new(*k, "x").to_string())
            .collect();
            for i in 0..texts.len() {
                for j in (i + 1)..texts.len() {
                    assert_ne!(texts[i], texts[j], "L09 kinds {i}/{j} distinct");
                }
            }
        }

        // L10: freeze continuity of the 0.10-r1 path — the
        // re-exported module resolves the very same token and error
        // types, and the sealed tokens stay zero-sized with their
        // authority terms intact (positive shape pin).
        {
            use kerf::core::reserved::capability::io as new_path;
            use kerf::core::reserved::capability_io as frozen;
            assert_eq!(
                std::any::TypeId::of::<frozen::ReadCapability>(),
                std::any::TypeId::of::<new_path::ReadCapability>(),
                "L10 read token path identity"
            );
            assert_eq!(
                std::any::TypeId::of::<frozen::IOError>(),
                std::any::TypeId::of::<new_path::IOError>(),
                "L10 error face path identity"
            );
            assert_eq!(std::mem::size_of::<frozen::WriteCapability>(), 0, "L10 ZST");
            assert_eq!(
                <frozen::ReadCapability as TokenCalculus>::authority(),
                "io.read",
                "L10 authority term"
            );
        }
    }

    // ============ Section M: conservative static checker (1.0) ============
    // The R1-R8 rules of docs/develop/v1/stage-1-plan.md §3 over the
    // real pipeline (read -> expand -> typecheck), plus the E0xxx
    // registry face. Externals is built from the two authoritative
    // sources only (single-source discipline): STAGE0_GLOBALS names +
    // Builtin::ALL arity triples.
    {
        use kerf::typecheck::{Externals, Severity, TypeCode, check_module};
        use kerf::vm::Builtin;
        use kerf_expander::STAGE0_GLOBALS;

        let externals = Externals::from_named_arities(
            Builtin::ALL
                .iter()
                .map(|(_, name, arity)| (*name, Some(*arity))),
        );

        fn check_src(src: &str, ext: &Externals) -> Vec<kerf::typecheck::TypeDiagnostic> {
            let forms = read_program(FILE, src).expect("audit source must read");
            let items = expand_program(&forms).expect("audit source must expand");
            check_module(&items, ext)
        }

        // M01: a clean program through the full pipeline yields zero
        // diagnostics (the soundness guard — no false positives).
        {
            let diags = check_src(
                "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2)))))\n(define r (fib 10))",
                &externals,
            );
            assert!(diags.is_empty(), "M01 clean program, got {diags:?}");
        }

        // M02: R2 — a defined 1-param function applied with 3 args.
        {
            let diags = check_src("(define (f a) a)\n(define x (f 1 2 3))", &externals);
            assert_eq!(diags.len(), 1, "M02 one diagnostic");
            assert_eq!(diags[0].code, TypeCode::ArityMismatch, "M02 code");
            assert_eq!(
                diags[0].message, "arity mismatch: `f` expects `1` argument, got `3`",
                "M02 VM-mirrored wording"
            );
        }

        // M03: R2 — a builtin with a known arity applied wrong (car
        // takes 1, supplied 2).
        {
            let diags = check_src("(define x (car 1 2))", &externals);
            assert_eq!(diags.len(), 1, "M03 one diagnostic");
            assert_eq!(diags[0].code, TypeCode::ArityMismatch, "M03 code");
        }

        // M04: R3 — a literal int in condition position.
        {
            let diags = check_src("(define x (if 1 2 3))", &externals);
            assert_eq!(diags.len(), 1, "M04 one diagnostic");
            assert_eq!(diags[0].code, TypeCode::NonBooleanCondition, "M04 code");
            assert!(
                diags[0]
                    .message
                    .starts_with("type mismatch: `if` condition"),
                "M04 wording: `{}`",
                diags[0].message
            );
        }

        // M05: R4 — direct application of a literal.
        {
            let diags = check_src("(define x (5 6))", &externals);
            assert_eq!(diags.len(), 1, "M05 one diagnostic");
            assert_eq!(diags[0].code, TypeCode::NonCallableCallee, "M05 code");
        }

        // M06: R6 — a top-level perform with no enclosing handler.
        {
            let diags = check_src("(define x (perform log 1 2))", &externals);
            assert_eq!(diags.len(), 1, "M06 one diagnostic");
            assert_eq!(
                diags[0].code,
                TypeCode::TopLevelUnhandledPerform,
                "M06 code"
            );
            assert_eq!(
                diags[0].message, "unhandled effect `log` at module top level",
                "M06 wording"
            );
        }

        // M07: R5 — the routed handler takes 2 params but the perform
        // supplies 1 arg; plus the Fn-body soundness guard in the same
        // program (the deferred perform is never reported).
        {
            let diags = check_src(
                "(define x (handle (perform log 42) (log (fn (a b) a))))\n(define (later) (perform other 1))",
                &externals,
            );
            assert_eq!(diags.len(), 1, "M07 one diagnostic (Fn body deferred)");
            assert_eq!(diags[0].code, TypeCode::HandlerArityMismatch, "M07 code");
        }

        // M08: R8 — rebinding a builtin through set! warns (the first
        // Warning producer; legal semantics, warning severity).
        {
            let diags = check_src("(define x (set! car 1))", &externals);
            assert_eq!(diags.len(), 1, "M08 one diagnostic");
            assert_eq!(
                diags[0].code,
                TypeCode::AssignmentTargetSurprise,
                "M08 code"
            );
            assert_eq!(diags[0].severity, Severity::Warning, "M08 warning level");
            assert_eq!(
                diags[0].message, "assignment rebinds builtin `car`",
                "M08 wording"
            );
        }

        // M09: multi-error collection — two independent definite
        // errors across two defines, both collected in one pass.
        {
            let diags = check_src("(define a (if 1 2 3))\n(define b (car 1 2))", &externals);
            let codes: Vec<&str> = diags.iter().map(|d| d.code.as_str()).collect();
            assert_eq!(codes, vec!["E0003", "E0002"], "M09 both collected");
        }

        // M10: the registry face — all eight stable code strings, the
        // severity distinction, and the single-source Externals table
        // covering every STAGE0_GLOBALS name with a known arity.
        {
            let all: Vec<&str> = [
                TypeCode::UnboundVariable,
                TypeCode::ArityMismatch,
                TypeCode::NonBooleanCondition,
                TypeCode::NonCallableCallee,
                TypeCode::HandlerArityMismatch,
                TypeCode::TopLevelUnhandledPerform,
                TypeCode::NonCallableHandler,
                TypeCode::AssignmentTargetSurprise,
            ]
            .iter()
            .map(|c| c.as_str())
            .collect();
            assert_eq!(
                all,
                vec![
                    "E0001", "E0002", "E0003", "E0004", "E0005", "E0006", "E0007", "E0008"
                ],
                "M10 registry strings"
            );
            assert_ne!(Severity::Error, Severity::Warning, "M10 severities");
            for name in STAGE0_GLOBALS {
                // The identity face (§9.68 CHK-6): resolve through the
                // pool entry, mirroring how the checker resolves Vars.
                let symbol = kerf_span::Symbol::new(name).expect("global name interns");
                let resolved = externals
                    .resolve(&symbol)
                    .unwrap_or_else(|| panic!("M10 global `{name}` must resolve"));
                assert!(
                    resolved.is_some(),
                    "M10 global `{name}` arity must be known"
                );
            }
            assert_eq!(externals.len(), Builtin::ALL.len(), "M10 table size");
        }
    }

    // ============ Section N: driver wiring (1.1) ============
    // The checker mounted between expand and both engines
    // (stage-1-plan §2 row 1.1): source-reachable E0xxx diagnostics
    // through the full driver pipeline, abort-before-execution, the
    // warning channel on every face, and the REPL delta replay.
    {
        use kerf::driver::{
            Engine, Repl, ReplEvent, Session, check_source, render_diagnostics, run_parity_source,
            run_source,
        };

        fn tags(diags: &[kerf::driver::Diagnostic]) -> Vec<&'static str> {
            diags.iter().map(|d| d.code.tag()).collect()
        }

        // N01: E0002 end-to-end on the run face — the registry tag is
        // the rendered code, the span is byte-precise, the abort
        // happens without executing.
        {
            let mut s = Session::new();
            let err = run_source(
                &mut s,
                "n1.krf",
                "(define (f x) x)\n(define r (f 1 2))",
                Engine::Vm,
                &[],
            )
            .expect_err("N01 must abort");
            assert_eq!(tags(&err), vec!["E0002"], "N01 registry tag");
            assert!(err[0].primary_span.is_some(), "N01 span carried");
        }

        // N02: E0003 through the check face.
        {
            let mut s = Session::new();
            let err = check_source(&mut s, "n2.krf", "(define r (if 1 2 3))")
                .expect_err("N02 must abort");
            // Both static layers report their own finding for the
            // same condition (the Stage 1.8 HM wiring — §9.49
            // GATE-2, probe-verified).
            assert_eq!(tags(&err), vec!["E0003", "E0009"], "N02 registry tag");
        }

        // N03: E0004 — the unrebound literal-define callee (the R4
        // extension terminal form).
        {
            let mut s = Session::new();
            let err = run_source(
                &mut s,
                "n3.krf",
                "(define two 2)\n(define r (two 1))",
                Engine::Vm,
                &[],
            )
            .expect_err("N03 must abort");
            assert_eq!(tags(&err), vec!["E0004"], "N03 registry tag");
        }

        // N04: E0006 — a top-level immediate perform with no handler.
        {
            let mut s = Session::new();
            let err = run_source(
                &mut s,
                "n4.krf",
                "(define r (perform unhandled-fx 1 2))",
                Engine::Vm,
                &[],
            )
            .expect_err("N04 must abort");
            assert_eq!(tags(&err), vec!["E0006"], "N04 registry tag");
        }

        // N05: E0008 never blocks — the program runs to its value on
        // both engines and the warning rides on the outcome.
        {
            let mut s = Session::new();
            for engine in [Engine::Vm, Engine::Eval] {
                let out = run_source(
                    &mut s,
                    "n5.krf",
                    "(define base 40)\n(define r (+ base (set! car 2)))",
                    engine,
                    &[],
                )
                .expect("N05 warnings never block");
                assert_eq!(out.warnings.len(), 1, "N05 warning count");
                assert_eq!(out.warnings[0].code.tag(), "E0008", "N05 tag");
                assert_eq!(
                    out.global("r").map(|v| v.to_string()),
                    Some("42".to_owned()),
                    "N05 value channel untouched"
                );
            }
        }

        // N06: a warnings-only batch renders the warning summary and
        // never claims an abort it did not make.
        {
            let mut s = Session::new();
            let out = run_source(
                &mut s,
                "n6.krf",
                "(define a (set! car 1))\n(define b (set! cdr 2))",
                Engine::Vm,
                &[],
            )
            .expect("N06 two warnings");
            let rendered = render_diagnostics(&s, &out.warnings);
            assert!(
                rendered.ends_with("warning: 2 warnings emitted\n"),
                "N06 summary: {rendered}"
            );
            assert!(!rendered.contains("aborting due to"), "N06 no abort line");
        }

        // N07: the rendered registry form — `error[E0002]:` head plus
        // the file:line:column location line.
        {
            let mut s = Session::new();
            let err = run_source(
                &mut s,
                "n7.krf",
                "(define (f x) x)\n(define r (f 1 2))",
                Engine::Vm,
                &[],
            )
            .expect_err("N07 aborts");
            let rendered = render_diagnostics(&s, &err);
            assert!(
                rendered.starts_with("error[E0002]: "),
                "N07 head: {rendered}"
            );
            assert!(
                rendered.contains("--> n7.krf:2:"),
                "N07 location: {rendered}"
            );
        }

        // N08: multi-error collection through the driver — three
        // independent definite errors in one batch with the abort
        // summary.
        {
            let mut s = Session::new();
            let err = check_source(
                &mut s,
                "n8.krf",
                "(define two 2)\n(define a (if 1 2 3))\n(define b (car 1 2))\n(define c (two 1))",
            )
            .expect_err("N08 four definite errors");
            // The Stage 1.8 HM wiring adds the inference layer's
            // own condition finding (both layers report —
            // probe-verified).
            assert_eq!(err.len(), 4, "N08 collected all four: {err:?}");
            let t = tags(&err);
            assert!(
                t.contains(&"E0003")
                    && t.contains(&"E0002")
                    && t.contains(&"E0004")
                    && t.contains(&"E0009")
            );
            let rendered = render_diagnostics(&s, &err);
            assert!(
                rendered.ends_with("error: aborting due to 4 previous errors\n"),
                "N08 summary: {rendered}"
            );
        }

        // N09: abort-before-execution — a write-line before a
        // definite error never runs.
        {
            let mut s = Session::new();
            let err = run_source(
                &mut s,
                "n9.krf",
                "(define a (write-line \"must-not-print\"))\n(define b (car 1 2))",
                Engine::Vm,
                &[],
            )
            .expect_err("N09 aborts");
            assert!(tags(&err).contains(&"E0002"), "N09 finding present");
        }

        // N10: the REPL faces — the warning delta replay (shown once,
        // silent on replay) and the rollback on definite errors, with
        // the parity face carrying warnings without blocking.
        {
            let mut r = Repl::new();
            match r.submit("(set! car 1)") {
                ReplEvent::Evaluated { new_warnings, .. } => {
                    let shown = new_warnings.join("\n");
                    assert!(shown.contains("warning[E0008]"), "N10 rendered: {shown}");
                }
                other => panic!("N10 warning submission is legal: {other:?}"),
            }
            match r.submit("(+ 1 2)") {
                ReplEvent::Evaluated {
                    value,
                    new_warnings,
                    ..
                } => {
                    assert_eq!(value.as_deref(), Some("3"), "N10 value channel");
                    assert!(new_warnings.is_empty(), "N10 silent on replay");
                }
                other => panic!("N10 second submission: {other:?}"),
            }
            // The earlier `(set! car 1)` poisons `car` for R2 (the
            // assign guard correctly skips reassigned names), so the
            // definite-error submission uses `cons`.
            match r.submit("(cons 1 2 3)") {
                ReplEvent::Error { rendered } => {
                    assert!(rendered.contains("error[E0002]"), "N10 rollback face");
                }
                other => panic!("N10 definite error: {other:?}"),
            }
            assert!(
                !r.accepted_source().contains("(cons 1 2 3)"),
                "N10 rolled back"
            );

            let mut s = Session::new();
            let report = run_parity_source(&mut s, "n10.krf", "(define r (set! car 7))", &[])
                .expect("N10 parity with warnings");
            assert!(report.agrees(), "N10 parity passes");
            assert_eq!(report.warnings.len(), 1, "N10 parity carries warnings");
        }
    }

    // ---------- Section P: the Stage 1.3 HM inference base ----------
    {
        use kerf::core::{CoreExpr as PExpr, LiteralValue as PLit, ModuleItem as PItem};
        use kerf::span::Symbol as PSymbol;
        use kerf::span::{ByteOffset as PByte, ExpansionId as PExp, Span as PSpan};
        use kerf::typecheck::{
            InferOutcome, Type as PType, TypeSchema as PSchema, TypedExpr as PTyped,
        };

        let pfile = FileId(0);
        let psp = |a: u32, b: u32| {
            PSpan::new(pfile, PByte(a), PByte(b), PExp::ROOT).expect("audit span ordered")
        };

        // The audit-grade externals table (single-source discipline:
        // names from STAGE0_GLOBALS, arities from Builtin::ALL).
        let pexternals = Externals::from_named_arities(
            kerf::vm::Builtin::ALL
                .iter()
                .map(|(_, name, arity)| (*name, Some(*arity))),
        );

        let infer_src = |src: &str| -> InferOutcome {
            let forms = read_program(pfile, src).expect("P source must read");
            let items: Vec<PItem> = expand_program(&forms).expect("P source must expand");
            infer_module(&items, &pexternals)
        };

        // P01: a definite arithmetic mismatch is an E0009 error with
        // the single-source message shape.
        {
            let out = infer_src("(define r (+ 1 2.0))");
            assert_eq!(out.diagnostics.len(), 1, "P01 one diagnostic");
            assert_eq!(out.diagnostics[0].code.as_str(), "E0009", "P01 code");
            assert_eq!(out.diagnostics[0].severity, Severity::Error, "P01 error");
            assert!(
                out.diagnostics[0]
                    .message
                    .contains("expected `int`, found `float`"),
                "P01 message: {}",
                out.diagnostics[0].message
            );
        }

        // P02: self-application trips the occurs check (E0010).
        {
            let out = infer_src("(define omega (fn (x) (x x)))");
            assert_eq!(out.diagnostics.len(), 1, "P02 one diagnostic");
            assert_eq!(out.diagnostics[0].code.as_str(), "E0010", "P02 code");
            assert!(
                out.diagnostics[0].message.starts_with("recursive type:"),
                "P02 shape"
            );
        }

        // P03: the depth budget is a warning, never an error — and
        // the offending define is excluded from the typed program.
        {
            let mut cur = PExpr::Literal {
                span: psp(0, 1),
                value: PLit::Int(1),
            };
            for _ in 0..600 {
                cur = PExpr::If {
                    span: psp(0, 2),
                    cond: Box::new(PExpr::Literal {
                        span: psp(0, 1),
                        value: PLit::Bool(true),
                    }),
                    then_branch: Box::new(cur),
                    else_branch: Box::new(PExpr::Literal {
                        span: psp(0, 1),
                        value: PLit::Int(2),
                    }),
                };
            }
            let items = vec![PItem::Define {
                span: psp(0, 3),
                name: PSymbol::new("deep").expect("P symbol"),
                value: cur,
            }];
            let out = infer_module(&items, &pexternals);
            assert_eq!(out.diagnostics.len(), 1, "P03 one diagnostic");
            assert_eq!(out.diagnostics[0].code.as_str(), "E0011", "P03 code");
            assert_eq!(
                out.diagnostics[0].severity,
                Severity::Warning,
                "P03 warning only"
            );
            assert!(out.typed.defines.is_empty(), "P03 excluded whole");
            assert_eq!(INFERENCE_DEPTH_LIMIT, 512, "P03 A6 budget");
        }

        // P04: polymorphic reuse is decoupled per use — both
        // instantiations typecheck and annotate their own type.
        {
            let out = infer_src("(define id (fn (x) x)) (define a (id 1)) (define b (id #t))");
            assert!(
                out.diagnostics.is_empty(),
                "P04 clean: {:?}",
                out.diagnostics
            );
            let a = out
                .typed
                .defines
                .iter()
                .find(|d| d.name.as_str() == "a")
                .expect("P04 a");
            let b = out
                .typed
                .defines
                .iter()
                .find(|d| d.name.as_str() == "b")
                .expect("P04 b");
            assert_eq!(a.schema, PSchema::mono(PType::Int), "P04 a int");
            assert_eq!(b.schema, PSchema::mono(PType::Bool), "P04 b bool");
        }

        // P05: the assigned guard — a reassigned name types as Dyn
        // and never constrains its later uses (value-restriction
        // analog; the conservative direction).
        {
            let out = infer_src("(define k (fn (x) x)) (define u (set! k 2)) (define r (+ k 1))");
            assert!(
                out.diagnostics.is_empty(),
                "P05 clean: {:?}",
                out.diagnostics
            );
        }

        // P06: effect-row subtraction — Handle removes what its
        // clauses intercept and merges the handler's own row.
        {
            let out =
                infer_src("(define r (handle (perform log 1) (log (fn (v) (perform audit v)))))");
            assert!(out.diagnostics.is_empty(), "P06 clean");
            let r = out
                .typed
                .defines
                .iter()
                .find(|d| d.name.as_str() == "r")
                .expect("P06 r");
            assert_eq!(r.effects.render(), "audit", "P06 residual row");
            assert!(matches!(r.body, PTyped::Handle { .. }), "P06 handle node");
        }

        // P07: the ad-hoc numeric domains — comparisons demand two
        // known same-kind numerics; mixed kinds are definite.
        {
            let ok = infer_src("(define r (< 1 2))");
            assert!(ok.diagnostics.is_empty(), "P07 same-kind clean");
            assert_eq!(
                ok.typed.defines[0].schema,
                PSchema::mono(PType::Bool),
                "P07 comparison yields bool"
            );
            let bad = infer_src("(define r (< 1 2.0))");
            assert_eq!(
                bad.diagnostics[0].code.as_str(),
                "E0009",
                "P07 mixed is definite"
            );
        }

        // P08: Dyn propagation — the join of dynamically-legal
        // branches flows as the unknown top and never errors.
        {
            let out = infer_src("(define c #t) (define r (if c 1 #t))");
            assert!(
                out.diagnostics.is_empty(),
                "P08 clean: {:?}",
                out.diagnostics
            );
            let r = out
                .typed
                .defines
                .iter()
                .find(|d| d.name.as_str() == "r")
                .expect("P08 r");
            assert_eq!(r.schema, PSchema::mono(PType::Dyn), "P08 join is dyn");
        }

        // P09: multi-error collection — three distinct E0009s in one
        // module, all reported, none short-circuited.
        {
            let out = infer_src("(define a (+ 1 #t)) (define b (car 2)) (define c (not 1.5))");
            assert_eq!(out.diagnostics.len(), 3, "P09 three diagnostics");
            assert!(
                out.diagnostics.iter().all(|d| d.code.as_str() == "E0009"),
                "P09 all mismatches"
            );
        }

        // P10: the typed dump is deterministic across independent
        // runs (the snapshot discipline's audit face).
        {
            let src =
                "(define id (fn (x) x)) (define r (handle (perform log (id 1)) (log (fn (v) v))))";
            let first = infer_src(src);
            let second = infer_src(src);
            let names1: Vec<&str> = first
                .typed
                .defines
                .iter()
                .map(|d| d.name.as_str())
                .collect();
            let names2: Vec<&str> = second
                .typed
                .defines
                .iter()
                .map(|d| d.name.as_str())
                .collect();
            assert_eq!(names1, names2, "P10 stable define order");
            assert_eq!(
                format!("{:?}", first.typed.defines[0].schema),
                format!("{:?}", second.typed.defines[0].schema),
                "P10 stable schemas"
            );
        }
    }

    // ============ Section Q: the Stage 1.4 parity contract (1.4) ============
    // The detector-detects meta-audit: the corpus harness itself is
    // the oracle, so the negative face audited here is *wrong
    // expectations* — every divergence the contract must flag, plus
    // the stage-attribution and report-shape invariants (SOP §7.3.1
    // rule 4 monotonic growth; stage-1-plan row 1.4).
    {
        use kerf::driver::{CorpusCase, Expectation, Observed, validate};

        // Q01: a wrong value expectation must drift with both reprs.
        {
            let case =
                CorpusCase::from_source("q01", ";; expect: value 99\n(define result (+ 1 2))")
                    .expect("directive parses");
            let report = validate(&case);
            assert!(!report.matched, "Q01 wrong value must mismatch");
            let drift = report.drift.as_deref().unwrap_or("");
            assert!(
                drift.contains("`99`") && drift.contains("`3`"),
                "Q01 drift carries both reprs: {drift}"
            );
        }

        // Q02: a read rejection expected as an expand rejection must
        // report the observed stage tag.
        {
            let case =
                CorpusCase::from_source("q02", ";; expect: expand-error\n(define result (+ 1 2)")
                    .expect("directive parses");
            let report = validate(&case);
            assert!(!report.matched, "Q02 wrong stage must mismatch");
            match &report.observed {
                Observed::Rejected { stage, .. } => {
                    assert_eq!(stage, "kerf-read", "Q02 stage attribution")
                }
                other => panic!("Q02 expected a rejection, observed {other:?}"),
            }
        }

        // Q03: an expand rejection expected as a read rejection.
        {
            let case = CorpusCase::from_source(
                "q03",
                ";; expect: parse-error\n(define result (quote sym))",
            )
            .expect("directive parses");
            let report = validate(&case);
            assert!(!report.matched, "Q03 wrong stage must mismatch");
            match &report.observed {
                Observed::Rejected { stage, .. } => {
                    assert_eq!(stage, "kerf-expand", "Q03 stage attribution")
                }
                other => panic!("Q03 expected a rejection, observed {other:?}"),
            }
        }

        // Q04: checker code sets compare exactly — a missing code
        // drifts with both lists.
        {
            let case = CorpusCase::from_source(
                "q04",
                ";; expect: type-error E0002\n(define (f x) x)\n(define result (do (f 1 2) (if 1 2 3)))",
            )
            .expect("directive parses");
            let report = validate(&case);
            assert!(!report.matched, "Q04 incomplete code set must mismatch");
            let drift = report.drift.as_deref().unwrap_or("");
            assert!(
                drift.contains("E0003"),
                "Q04 drift names the missing code: {drift}"
            );
        }

        // Q05: a checker rejection expected as a halt diverges before
        // the engines run.
        {
            let case =
                CorpusCase::from_source("q05", ";; expect: value 3\n(define result (if 1 2 3))")
                    .expect("directive parses");
            let report = validate(&case);
            assert!(!report.matched, "Q05 checker-vs-halt must mismatch");
            assert!(
                report
                    .drift
                    .as_deref()
                    .unwrap_or("")
                    .contains("checker rejected"),
                "Q05 drift names the checker"
            );
        }

        // Q06: a halting program expected as a runtime rejection.
        {
            let case =
                CorpusCase::from_source("q06", ";; expect: runtime-error\n(define result (+ 1 2))")
                    .expect("directive parses");
            let report = validate(&case);
            assert!(!report.matched, "Q06 halt-as-runtime must mismatch");
            assert!(
                report
                    .drift
                    .as_deref()
                    .unwrap_or("")
                    .contains("both engines halted"),
                "Q06 drift names the halt"
            );
        }

        // Q07: a program with no top-level define cannot satisfy the
        // value convention — the drift names the convention.
        {
            let case =
                CorpusCase::from_source("q07", ";; expect: value nil\n(module m (define x 1))")
                    .expect("directive parses");
            let report = validate(&case);
            assert!(!report.matched, "Q07 no-define must mismatch");
            assert!(
                report
                    .drift
                    .as_deref()
                    .unwrap_or("")
                    .contains("no top-level define"),
                "Q07 drift names the value convention"
            );
        }

        // Q08: warning code sets compare exactly.
        {
            let case = CorpusCase::from_source(
                "q08",
                ";; expect: warning E0008 value 1\n(define result (+ 1 2))",
            )
            .expect("directive parses");
            let report = validate(&case);
            assert!(!report.matched, "Q08 missing warning must mismatch");
            let drift = report.drift.as_deref().unwrap_or("");
            assert!(
                drift.contains("expected warning codes"),
                "Q08 drift names the warning contract: {drift}"
            );
        }

        // Q09: the batch face returns one report per case, in order.
        {
            let cases = [
                CorpusCase::from_source("q09a", ";; expect: value 3\n(define result (+ 1 2))")
                    .expect("directive parses"),
                CorpusCase::from_source("q09b", ";; expect: parse-error\n(")
                    .expect("directive parses"),
                CorpusCase::from_source("q09c", ";; expect: runtime-error\n(define r (/ 1 0))")
                    .expect("directive parses"),
            ];
            let reports = kerf::driver::validate_all(cases.iter());
            assert_eq!(reports.len(), 3, "Q09 one report per case");
            assert!(reports.iter().all(|r| r.matched), "Q09 all three match");
            assert_eq!(reports[0].case, "q09a", "Q09 order preserved");
            assert_eq!(
                reports[2].observed,
                Observed::Rejected {
                    stage: "kerf-runtime".to_owned(),
                    codes: Vec::new(),
                },
                "Q09 runtime stage tag"
            );
        }

        // Q10: the expectation surface round-trips all six forms and
        // rejects an unknown keyword (the directive grammar is closed).
        {
            use kerf::driver::parse_directive;
            assert_eq!(
                parse_directive(";; expect: value 42"),
                Ok(Expectation::Value("42".to_owned()))
            );
            assert_eq!(
                parse_directive(";; expect: parse-error"),
                Ok(Expectation::ParseError)
            );
            assert_eq!(
                parse_directive(";; expect: expand-error"),
                Ok(Expectation::ExpandError)
            );
            assert_eq!(
                parse_directive(";; expect: type-error E0002"),
                Ok(Expectation::TypeError(vec!["E0002".to_owned()]))
            );
            assert_eq!(
                parse_directive(";; expect: runtime-error"),
                Ok(Expectation::RuntimeError)
            );
            assert_eq!(
                parse_directive(";; expect: warning E0008 value nil"),
                Ok(Expectation::Warning {
                    codes: vec!["E0008".to_owned()],
                    value: "nil".to_owned(),
                })
            );
            assert!(
                parse_directive(";; expect: telepathy").is_err(),
                "Q10 closed grammar"
            );
        }
    }

    // ============ Section R: the Stage 1.5 reader parity (1.5) ============
    // The double-reader meta-audit: the .krf structure layer against
    // the Rust oracle, both axes (trees and the four parser-side
    // rejections), both engines, the layer split, and the drift
    // detector's own self-checks (SOP §7.3.1 rule 4 monotonic
    // growth; stage-1-plan row 1.5; docs/stage0.md §9.46.4).
    // R11-R20 mount the second segment (v0.55.0, §9.86): the lexical
    // layer through the FULL .krf chain — the byte-table injection
    // (zero freeze-surface change), every lexical decision
    // self-hosted, the K20 float-value face on the permanent host
    // layer, three axes (tokens / tree / error), both engines, and
    // the VM bracket face for the past-envelope fixed points.
    {
        use kerf::driver::{ParityLayer, READER_SOURCE, reader_parity, reader_parity_with};

        // R01: tree parity at the parser.rs anchor spans.
        {
            let report = reader_parity("r01", "(f (g 1) 2)");
            assert!(report.matched, "R01 {}", report.failure_line());
            assert!(report.engines_agree);
            assert_eq!(report.layer, ParityLayer::Parser);
            assert_eq!(
                report.oracle,
                "(list 0 11 (ident 1 2 f) (list 3 8 (ident 4 5 g) (int 6 7 1)) (int 9 10 2))"
            );
        }

        // R02: the innermost open list reports at eof.
        {
            let report = reader_parity("r02", "(((x");
            assert!(report.matched, "R02 {}", report.failure_line());
            assert_eq!(
                report.oracle,
                "unclosed delimiter: `(` is never closed @ byte 2"
            );
        }

        // R03: empty application fires before the outer unclosed.
        {
            let report = reader_parity("r03", "(()");
            assert!(report.matched, "R03 {}", report.failure_line());
            assert_eq!(
                report.oracle,
                "empty application: `()` has no operator @ byte 1"
            );
        }

        // R04: stray close at top and form positions.
        {
            let top = reader_parity("r04a", ")");
            assert!(
                top.matched
                    && top
                        .oracle
                        .starts_with("unexpected closing delimiter `)` @ byte 0")
            );
            let mid = reader_parity("r04b", "(a 1) )");
            assert!(
                mid.matched
                    && mid
                        .oracle
                        .starts_with("unexpected closing delimiter `)` @ byte 6")
            );
        }

        // R05: the nesting rejection at the exact depth payload.
        {
            let mut src = String::new();
            for _ in 0..257 {
                src.push('(');
            }
            src.push('x');
            for _ in 0..257 {
                src.push(')');
            }
            let report = reader_parity("r05", &src);
            assert!(report.matched, "R05 {}", report.failure_line());
            assert_eq!(report.oracle, "nesting depth 257 exceeds the limit of 256");
        }

        // R06: 255-deep is legal — the full tree agrees on both
        // engines (the deepest walk the harness takes).
        {
            let mut src = String::new();
            for _ in 0..255 {
                src.push('(');
            }
            src.push('x');
            for _ in 0..255 {
                src.push(')');
            }
            let report = reader_parity("r06", &src);
            assert!(report.matched, "R06 {}", report.failure_line());
            assert!(report.engines_agree);
            assert_eq!(report.oracle.matches("(list ").count(), 255);
        }

        // R07: the lexer layer split — six-variant rejections route
        // to the harness's lexer path with the .krf layer unexercised.
        {
            for src in [
                "\"unterminated",
                "(a \"\\q\")",
                "#x",
                "1.2.3",
                "[",
                "(a `b)",
            ] {
                let report = reader_parity("r07", src);
                assert_eq!(report.layer, ParityLayer::Lexer, "R07 case {src:?}");
                assert!(report.matched && report.krf.is_none(), "R07 case {src:?}");
            }
        }

        // R08: the drift detector — a tampered unclosed payload (the
        // outermost instead of the innermost open) must be caught.
        {
            let tampered = READER_SOURCE.replace(
                "(cons \"unclosed\" (cons (rd-fr-open (car stack)) nil))",
                "(cons \"unclosed\" (cons (rd-fr-open (rd-rev stack nil)) nil))",
            );
            assert_ne!(tampered, READER_SOURCE);
            let report = reader_parity_with("r08", "(a (b", &tampered);
            assert!(!report.matched, "R08 the tampered reader must be caught");
        }

        // R09: the drift detector — a tampered nesting limit drifts
        // exactly at the 256 boundary.
        {
            let tampered = READER_SOURCE.replace("(if (> (+ d 1) 256)", "(if (> (+ d 1) 255)");
            let mut src = String::new();
            for _ in 0..256 {
                src.push('(');
            }
            src.push('x');
            for _ in 0..256 {
                src.push(')');
            }
            let report = reader_parity_with("r09", &src, &tampered);
            assert!(!report.matched, "R09 the wrong limit must be caught");
        }

        // R10: harness defects surface as drift (never a panic); the
        // float Debug-text face carries the legal extremes exactly,
        // and the overflow face fails closed (v0.40.0 §9.71 — the
        // silent inf read is gone; `1e999` rejects on the lexer layer).
        {
            let broken = "(define result 42)";
            let report = reader_parity_with("r10a", "(a)", broken);
            assert!(!report.matched);
            assert!(report.drift.as_deref().unwrap().contains("harness defect"));
            let extreme = reader_parity("r10b", "(f 1.7976931348623157e308 -0.5)");
            assert!(extreme.matched, "R10 {}", extreme.failure_line());
            assert!(extreme.oracle.contains("1.7976931348623157e308"));
            assert!(extreme.oracle.contains("-0.5"));
            let overflow = reader_parity("r10c", "(f 1e999)");
            assert!(overflow.matched, "R10 {}", overflow.failure_line());
            assert!(
                overflow
                    .oracle
                    .contains("float literal `1e999` out of range for `f64`")
            );
        }

        // ---- R11-R20: the second segment — the lexical layer through
        // the full .krf chain (v0.55.0, §9.86; the byte-table
        // injection generalizes RS-1 with zero freeze change).
        {
            use kerf::driver::{
                LEXER_SOURCE, reader_parity_full, reader_parity_full_vm, reader_parity_full_with,
            };

            // R11: tree and token parity on a mixed program, both
            // engines, all three atom payloads derived host-side from
            // the .krf-decided spans.
            {
                let report = reader_parity_full("r11", "(f (g 1) 2.5 #t \"s\\n\")");
                assert!(report.matched, "R11 {}", report.failure_line());
                assert!(report.engines_agree);
                assert_eq!(
                    report.oracle_tree,
                    "(list 0 22 (ident 1 2 f) (list 3 8 (ident 4 5 g) (int 6 7 1)) \
                     (float 9 12 2.5) (bool 13 15 true) (string 16 21 \"s\\n\"))"
                );
                assert!(report.krf_tokens.as_deref().is_some());
            }

            // R12: the i64 boundary family — MIN/MAX ride the
            // 19-digit threshold guard exactly; leading zeros
            // re-lex.
            {
                let report =
                    reader_parity_full("r12", "(f -9223372036854775808 9223372036854775807 007)");
                assert!(report.matched, "R12 {}", report.failure_line());
                assert!(report.engines_agree);
                let tree = report.krf_tree.as_deref().unwrap();
                assert!(tree.contains("(int 3 23 -9223372036854775808)"));
                assert!(tree.contains("(int 24 43 9223372036854775807)"));
                assert!(tree.contains("(int 44 47 7)"));
            }

            // R13: the float face — the legal extremes through the
            // K20 host value layer, the underflow rounding, and the
            // overflow rejection at the same key the oracle made.
            {
                let report =
                    reader_parity_full("r13", "(f 1.7976931348623157e308 -0.5 1e-999 1e999)");
                assert!(report.matched, "R13 {}", report.failure_line());
                assert!(report.engines_agree);
                assert!(
                    report
                        .oracle_tree
                        .contains("ERR float literal `1e999` out of range for `f64`")
                );
                let legal = reader_parity_full("r13b", "(f 1.7976931348623157e308 1e-999)");
                assert!(legal.matched, "R13 {}", legal.failure_line());
                let tree = legal.krf_tree.as_deref().unwrap();
                assert!(tree.contains("1.7976931348623157e308"));
                assert!(tree.contains("(float 26 32 0.0)"));
            }

            // R14: the six formerly-split lexical rejections at their
            // exact parity keys — now decided in the .krf layer.
            {
                for (src, want) in [
                    ("\"unterminated", "unterminated string literal @ byte 0"),
                    ("(a \"\\q\")", "invalid string escape `q` @ byte 5"),
                    ("#x", "invalid boolean literal `#x`"),
                    ("1.2.3", "malformed number literal `1.2.3`"),
                    ("[", "unexpected character `[` @ byte 0"),
                    ("(a `b)", "unexpected character ``` @ byte 3"),
                ] {
                    let report = reader_parity_full("r14", src);
                    assert!(report.matched, "R14 case {src:?}");
                    assert!(report.engines_agree, "R14 case {src:?}");
                    assert!(report.oracle_tree.contains(want), "R14 case {src:?}");
                }
            }

            // R15: the C1 control symbol floor — the only reachable
            // control face inside an atom.
            {
                let report = reader_parity_full("r15", "a\u{84}b");
                assert!(report.matched, "R15 {}", report.failure_line());
                assert!(report
                    .oracle_tree
                    .contains("invalid symbol `a\u{84}b`: must be non-empty with no whitespace or control characters"));
            }

            // R16: the mixed-width rich fixture — BOM lead-in, the
            // CJK atom, the VT separator, every numeric shape, the
            // escape decode, and the comment swallowing non-ASCII.
            {
                let src = "\u{feff}(f 计数器\u{0b}+ -3 .5 1e5 1e-999 \"a\\nb\" x;y\n(z \"s\"))";
                let report = reader_parity_full("r16", src);
                assert!(report.matched, "R16 {}", report.failure_line());
                assert!(report.engines_agree);
                let tree = report.krf_tree.as_deref().unwrap();
                assert!(tree.contains("(ident 6 15 计数器)"));
                assert!(tree.contains("(float 28 34 0.0)"));
                assert!(tree.contains("(string 35 41 \"a\\nb\")"));
            }

            // R17: the structure rejections ride the chain unchanged
            // (segment 1's families through the composed front end).
            {
                for (src, want) in [
                    ("(a (b", "unclosed delimiter: `(` is never closed @ byte 3"),
                    ("(f ())", "empty application: `()` has no operator @ byte 3"),
                ] {
                    let report = reader_parity_full("r17", src);
                    assert!(report.matched, "R17 case {src:?}");
                    assert!(report.engines_agree, "R17 case {src:?}");
                    assert!(report.oracle_tree.contains(want), "R17 case {src:?}");
                }
            }

            // R18: the reader fixed point through the full chain —
            // bytes -> lexer.krf -> reader.krf on reader.krf's own
            // source (the VM bracket face: the header comment block
            // is one ~2.4k-byte trivia run, past the evaluator's
            // per-element envelope — the K165/K166 discipline).
            {
                let report = reader_parity_full_vm("r18", READER_SOURCE);
                assert!(report.matched, "R18 {}", report.failure_line());
                assert!(report.oracle_tree.starts_with("(list "));
            }

            // R19: the drift detector's self-checks on the lexical
            // layer — a tampered escape set and a tampered threshold
            // must both be caught.
            {
                let tampered = LEXER_SOURCE.replace(
                    "(if (= b 116) #t (= b 114))",
                    "(if (= b 116) #t (= b 1145))",
                );
                assert_ne!(tampered, LEXER_SOURCE);
                let report = reader_parity_full_with("r19a", "(f \"a\\rb\")", &tampered);
                assert!(
                    !report.matched,
                    "R19 the tampered escape set must be caught"
                );
                let tampered = LEXER_SOURCE.replace(
                    "(quote (57 50 50 51 51 55 50 48 51 54 56 53 52 55 55 53 56 48 55))",
                    "(quote (57 50 50 51 51 55 50 48 51 54 56 53 52 55 55 53 56 48 54))",
                );
                assert_ne!(tampered, LEXER_SOURCE);
                let report = reader_parity_full_with("r19b", "(f 9223372036854775807)", &tampered);
                assert!(!report.matched, "R19 the tampered threshold must be caught");
            }

            // R20: harness defects surface as drift on the full chain
            // too (never a panic), and the byte-table prefix of the
            // empty source rides `(quote nil)` (the reader rejects
            // `()` — subset-spec §2.5).
            {
                let broken = "(define lex-verdict 42)";
                let report = reader_parity_full_with("r20a", "(a)", broken);
                assert!(!report.matched);
                assert!(report.drift.as_deref().unwrap().contains("harness defect"));
                let empty = reader_parity_full("r20b", "");
                assert!(empty.matched, "R20 {}", empty.failure_line());
                assert_eq!(empty.oracle_tree, "");
                assert!(empty.engines_agree);
            }
        }
    }

    // ============ Section S: the Stage 1.6 expander parity (1.6) ============
    // The double-expander meta-audit: the .krf expansion layer
    // against the Rust oracle, both axes (item trees and the
    // structured rejections), both engines, the three-layer split,
    // and the drift detector's own self-checks (SOP §7.3.1 rule 4
    // monotonic growth; stage-1-plan row 1.6; docs/stage0.md
    // §9.47.4).
    {
        use kerf::driver::{
            EXPANDER_SOURCE, ExpanderParityLayer, MACRO_SOURCE, assembled_expander_source,
            expander_parity, expander_parity_with, gate_b_bytecode,
        };

        // S01: tree parity at the hand-computed anchor spans.
        {
            let report = expander_parity("s01", "(define x 1)");
            assert!(report.matched, "S01 {}", report.failure_line());
            assert!(report.engines_agree);
            assert_eq!(report.layer, ExpanderParityLayer::Expander);
            assert_eq!(report.oracle, "(define 0 12 x (lit 10 11 (int 1)))");
        }

        // S02: the quote trap — the literal span is the WHOLE form.
        {
            let report = expander_parity("s02", "(define x (quote (1 2)))");
            assert!(report.matched, "S02 {}", report.failure_line());
            assert_eq!(
                report.oracle,
                "(define 0 24 x (lit 10 23 (pair (int 1) (pair (int 2) nil))))"
            );
        }

        // S03: the fn-sugar and binding traps — the Fn span is the
        // NAME atom; a binding's span is the VALUE node.
        {
            let sugar = expander_parity("s03a", "(define (f x) x)");
            assert!(sugar.matched, "S03 {}", sugar.failure_line());
            assert_eq!(sugar.oracle, "(define 0 16 f (fn 9 10 (x) (var 14 15 x)))");
            let binding = expander_parity("s03b", "(define x (let ((a 1)) a))");
            assert!(binding.matched, "S03 {}", binding.failure_line());
            assert_eq!(
                binding.oracle,
                "(define 0 26 x (let 10 25 ((19 20 a (lit 19 20 (int 1)))) (var 23 24 a)))"
            );
        }

        // S04: the do traps — the identity special case and the one
        // flat Let with the discard binding.
        {
            let one = expander_parity("s04a", "(define x (do 5))");
            assert!(one.matched, "S04 {}", one.failure_line());
            assert_eq!(one.oracle, "(define 0 17 x (lit 14 15 (int 5)))");
            let two = expander_parity("s04b", "(define x (do 5 6))");
            assert!(two.matched, "S04 {}", two.failure_line());
            assert_eq!(
                two.oracle,
                "(define 0 19 x (let 10 18 ((14 15 _ (lit 14 15 (int 5)))) (lit 16 17 (int 6))))"
            );
        }

        // S05: the set! trap — an unbound target reports the NAME
        // atom's span.
        {
            let report = expander_parity("s05", "(define x (set! y 1))");
            assert!(report.matched, "S05 {}", report.failure_line());
            assert_eq!(
                report.oracle,
                "unbound identifier `y`: not in any lexical scope \
                 and not a Stage 0 global @ file#0:16..17"
            );
        }

        // S06: the handle trap — a clause's span is the whole
        // clause list.
        {
            let report = expander_parity("s06", "(define x (handle 1 (e (fn (v) v))))");
            assert!(report.matched, "S06 {}", report.failure_line());
            assert_eq!(
                report.oracle,
                "(define 0 36 x (handle 10 35 (lit 18 19 (int 1)) \
                 ((20 34 e (fn 23 33 (v) (var 31 32 v))))))"
            );
        }

        // S07: the require trap — a symbol name is MalformedForm;
        // the string form produces a Require item.
        {
            let sym = expander_parity("s07a", "(require b)");
            assert!(sym.matched, "S07 {}", sym.failure_line());
            assert_eq!(
                sym.oracle,
                "malformed `require` form: expected (require \"module-name\") with a string module name @ file#0:0..11"
            );
            let text = expander_parity(
                "s07b",
                "(module m (define x 1))
(require \"m\")
(define result 2)",
            );
            assert!(text.matched, "S07 {}", text.failure_line());
            assert!(
                text.oracle
                    .starts_with("(module 0 23 m (define 10 22 x (lit 20 21 (int 1))))")
            );
        }

        // S08: the loader faces — the string-name cycle, the
        // missing module, and the duplicate declaration.
        {
            let cyc = expander_parity(
                "s08a",
                "(module a (require \"b\"))
(module b (require \"a\"))",
            );
            assert!(cyc.matched, "S08 {}", cyc.failure_line());
            // §9.56 DIAG-1: parity key = Display + `@ {span}` suffix.
            assert_eq!(
                cyc.oracle,
                "module cycle detected: a -> b -> a @ file#0:35..48"
            );
            let miss = expander_parity(
                "s08b",
                "(require \"nope\")
(define result 1)",
            );
            assert!(miss.matched, "S08 {}", miss.failure_line());
            assert!(
                miss.oracle
                    .starts_with("required module `nope` is not declared")
            );
            assert!(miss.oracle.contains("@ file#0:"));
            let dup = expander_parity(
                "s08c",
                "(module m (define x 1))
(module m (define x 2))",
            );
            assert!(dup.matched, "S08 {}", dup.failure_line());
            assert!(dup.oracle.starts_with("duplicate module declaration `m`"));
        }

        // S09: the three-layer split — the reader rejections, the
        // macro corpus files, and the expansion layer.
        {
            let read = expander_parity("s09a", "(a");
            assert_eq!(read.layer, ExpanderParityLayer::Reader);
            assert!(read.matched && read.krf.is_none());
            let macro_src = std::fs::read_to_string(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/tests/v1/stage1/corpus/pos-024-macro-my-if.krf"
            ))
            .expect("corpus file");
            let mac = expander_parity("s09b", &macro_src);
            assert_eq!(mac.layer, ExpanderParityLayer::Expander);
            assert!(mac.matched && mac.krf.is_some());
            let exp = expander_parity("s09c", "(define x 1)");
            assert_eq!(exp.layer, ExpanderParityLayer::Expander);
            assert!(exp.matched && exp.krf.is_some());
        }

        // S10: the drift detector's self-checks — a tampered depth
        // guard and a harness-defect verdict both surface as drift.
        {
            let tampered = EXPANDER_SOURCE.replace("(>= ex-depth 512)", "(>= ex-depth 2)");
            assert_ne!(&tampered, EXPANDER_SOURCE);
            let assembled = format!("{MACRO_SOURCE}\n{tampered}");
            let drift = expander_parity_with("s10a", "(define x (do 1 (do 2 3)))", &assembled);
            assert!(!drift.matched, "S10 the tampered depth must be caught");
            let broken = EXPANDER_SOURCE.replace("(cons \"ok\" items)", "(cons \"okay\" items)");
            let assembled2 = format!("{MACRO_SOURCE}\n{broken}");
            let defect = expander_parity_with("s10b", "(define x 1)", &assembled2);
            assert!(!defect.matched);
            assert!(defect.drift.as_deref().unwrap().contains("harness defect"));
        }

        // T01: the literal table matches by symbol text (K30).
        {
            let lit = expander_parity(
                "t01a",
                "(define-syntax k (syntax-rules (then) ((_ then v) v))) (define r (k then 5))",
            );
            assert!(lit.matched, "T01 {}", lit.failure_line());
            assert!(lit.oracle.contains("(lit"));
        }

        // T02: the two-generation chain (use_gen + 1 threading).
        {
            let two = expander_parity(
                "t02a",
                "(define-syntax i (syntax-rules nil ((_ v) (+ v 1)))) \
                 (define-syntax o (syntax-rules nil ((_ x) (i x)))) (define r (o 1))",
            );
            assert!(two.matched, "T02 {}", two.failure_line());
            assert!(two.oracle.contains("(apply"));
        }

        // T03: the hygiene rename decodes to the concatenated name
        // (MX-1).
        {
            let hyg = expander_parity(
                "t03a",
                "(define-syntax w (syntax-rules nil ((_ e) (let ((x 100)) (+ x e))))) \
                 (define (f x) (w x)) (define result (f 1))",
            );
            assert!(hyg.matched, "T03 {}", hyg.failure_line());
            assert!(
                hyg.oracle.contains("x__macro_0"),
                "T03 the mangled name must decode: {}",
                hyg.oracle
            );
        }

        // T04: the pattern-mismatch error axis at the use-site head.
        {
            let mm = expander_parity(
                "t04a",
                "(define-syntax m (syntax-rules nil ((_ x) x))) (define r (m 1 2))",
            );
            assert!(mm.matched, "T04 {}", mm.failure_line());
            assert!(mm.oracle.contains("macro `m` matched no clause"));
        }

        // T05: duplicate pattern variables reject at registration.
        {
            let dup = expander_parity("t05a", "(define-syntax d (syntax-rules nil ((_ a a) a)))");
            assert!(dup.matched, "T05 {}", dup.failure_line());
            assert!(dup.oracle.contains("malformed `define-syntax` form"));
        }

        // T06: the ellipsis boundary fails closed (K27).
        {
            let ell = expander_parity("t06a", "(define-syntax e (syntax-rules nil ((_ a ...) a)))");
            assert!(ell.matched, "T06 {}", ell.failure_line());
            assert!(ell.oracle.contains("malformed `define-syntax` form"));
        }

        // T07: module-scoped macros vanish outside their frame.
        {
            let out = expander_parity(
                "t07a",
                "(module m (define-syntax i (syntax-rules nil ((_) 1)))) (define r (i))",
            );
            assert!(out.matched, "T07 {}", out.failure_line());
            assert!(out.oracle.contains("unbound identifier `i`"));
        }

        // T08: the depth budget mirrors the oracle (bnd-010).
        {
            let bnd = std::fs::read_to_string(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/tests/v1/stage1/corpus/bnd-010-expansion-limit.krf"
            ))
            .expect("corpus file");
            let dep = expander_parity("t08a", &bnd);
            assert!(dep.matched, "T08 {}", dep.failure_line());
            assert_eq!(
                dep.oracle,
                "expansion depth exceeded the limit of 512 @ file#0:67..73"
            );
        }

        // T09: fixpoint gate B axis (a) - bytecode equality over the
        // macro corpus (the host rebuilder + Bytecode PartialEq).
        {
            for file in [
                "pos-024-macro-my-if.krf",
                "pos-031-literal-macro.krf",
                "pos-032-macro-two-generations.krf",
                "pos-033-hygiene-binder-collision.krf",
            ] {
                let source = std::fs::read_to_string(format!(
                    "{}/tests/v1/stage1/corpus/{file}",
                    env!("CARGO_MANIFEST_DIR")
                ))
                .expect("corpus file");
                gate_b_bytecode(&format!("t09-{file}"), &source)
                    .unwrap_or_else(|err| panic!("T09 {err}"));
            }
        }

        // T10: gate B axis (b) - the assembled source applied to
        // itself (three-way agreement plus bytecode equality), and
        // the Macro sentinel stays at zero routing.
        {
            let assembled = assembled_expander_source();
            let self_forms = assembled.replace("\n(define result (ex-run forms))", "");
            assert_ne!(&self_forms, &assembled);
            let report = expander_parity_with("t10a", &self_forms, &assembled);
            assert!(report.matched, "T10 {}", report.failure_line());
            gate_b_bytecode("t10a", &self_forms).expect("T10 self-application bytecode");
            let sentinel = expander_parity(
                "t10b",
                "(define-syntax m (syntax-rules nil ((_ x) x))) (define r (m 1))",
            );
            assert_eq!(sentinel.layer, ExpanderParityLayer::Expander);
            assert!(sentinel.krf.is_some());
        }
    }

    // ---------- Section U: the Stage 1.8 gate-prep round — the HM
    // wiring end-to-end, the 1.7 fix-boundary family (SOP §7.3.2 —
    // the probe-round five: the four-head record grammar, the
    // generation thread, the mangled decode, the assembly
    // contract, the Macro sentinel), and the cross-sub-stage
    // integration sweep (1.0-1.7 full chain, §9.49.5 GATE-1) ----------

    {
        use kerf::driver::{
            ExpanderParityLayer, MACRO_SOURCE, Session, assembled_expander_source, check_source,
            expander_parity, expander_parity_with, gate_b_bytecode, parse, run_parity_source,
            run_source,
        };

        // U01: the HM wiring through the driver face (GATE-2). (a) A
        // definite inference error blocks with E0009 in the batch;
        // (b) a clean program stays zero-finding through *both*
        // static layers (the soundness dual); (c) the assembled
        // .krf expander — a legal 1.4k-line program the 1.3 engine
        // falsely rejected before the §9.49 hardening — produces
        // zero error-level findings through the same face.
        {
            let mut s = Session::new();
            let err = check_source(
                &mut s,
                "u1a.krf",
                "(define f (fn (x) (if x 1 2))) (define r (f 1))",
            )
            .expect_err("U1a the bool-demand mismatch blocks");
            assert!(
                err.iter().any(|d| d.code.tag() == "E0009"),
                "U1a batch: {err:?}"
            );

            let mut s = Session::new();
            let out = check_source(
                &mut s,
                "u1b.krf",
                "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define r (fib 10))",
            )
            .expect("U1b clean program checks");
            assert!(out.warnings.is_empty(), "U1b zero findings both layers");

            // The bare assembly (definitions only — the run tail
            // references the host-injected forms table, T10's
            // self-application precedent) through both layers.
            let mut s = Session::new();
            let assembled = assembled_expander_source();
            let self_forms = assembled.replace("\n(define result (ex-run forms))", "");
            let program = parse(&mut s, "u1c.krf", &self_forms).expect("U1c parses");
            let findings = program.typecheck();
            assert!(
                findings
                    .iter()
                    .all(|d| d.severity != kerf::driver::Severity::Error),
                "U1c the assembled expander carries no error-level finding: {findings:?}"
            );
        }

        // U02: the four-head record grammar across both shapes — a
        // source mixing the plain list records and the mangled
        // rename product (six fields) must expand identically on
        // both expanders and compile to identical bytecode (the
        // probe-round-1 boundary: ex-children cdr4 / ex-gen special
        // casing).
        {
            let mixed = "(define-syntax m (syntax-rules nil ((_ x) x)))\n(define-syntax n (syntax-rules nil ((_ x) (m x))))\n(define r (n (do (+ 1 2) 0)))";
            let report = expander_parity("u2", mixed);
            assert!(report.matched, "U2 {}", report.failure_line());
            assert_eq!(report.layer, ExpanderParityLayer::Expander);
            gate_b_bytecode("u2", mixed).expect("U2 bytecode equality");
        }

        // U03: the generation thread beyond the corpus — a
        // three-generation macro chain (the corpus tops out at two)
        // keeps generation threading intact through gate B.
        {
            let three = "(define-syntax a (syntax-rules nil ((_ x) x)))\n(define-syntax b (syntax-rules nil ((_ x) (a x))))\n(define-syntax c (syntax-rules nil ((_ x) (b x))))\n(define r (c (+ 1 2)))";
            let report = expander_parity("u3", three);
            assert!(report.matched, "U3 {}", report.failure_line());
            gate_b_bytecode("u3", three).expect("U3 three-generation bytecode");
        }

        // U04: the mangled decode is detector-guarded — moving the
        // counter allocation in the mangled encoder must break
        // parity (the drift detector detects; §7.3.2 boundary of
        // the probe-round-4 fix).
        {
            let needle = "\"mangled\"";
            assert!(
                MACRO_SOURCE.contains(needle),
                "U4 the mangled encoder anchor exists"
            );
            let tampered = assembled_expander_source().replace(
                "(cons (ex-text t) (cons c (cons (+ ex-mgen 1) nil)))",
                "(cons (ex-text t) (cons (+ ex-mgen 1) (cons c nil)))",
            );
            assert_ne!(
                tampered,
                assembled_expander_source(),
                "U4 the tamper landed"
            );
            // The hygiene-binder-collision corpus case is the one
            // that exercises the mangled path (rename-on-capture).
            let collision = std::fs::read_to_string(format!(
                "{}/tests/v1/stage1/corpus/pos-033-hygiene-binder-collision.krf",
                env!("CARGO_MANIFEST_DIR")
            ))
            .expect("corpus file");
            let report = expander_parity_with("u4", &collision, &tampered);
            assert!(
                !report.matched,
                "U4 the swapped counter/generation fields must drift"
            );
        }

        // U05: the assembly contract is order-neutral for non-macro
        // sources — a plain 1.6-domain program expanded through the
        // assembled host still meets gate B (bytecode equality over
        // the rebuilt items).
        {
            let plain = "(define x 3) (define r (do (let ((y (+ x 1))) (* y y)) 0))";
            gate_b_bytecode("u5", plain).expect("U5 plain source through the assembly");
        }

        // U06: the Macro sentinel stays at zero routing — every
        // corpus negative that defines a macro dies at the Expander
        // layer (pos-024 migrated at 1.7), never at the Macro layer.
        {
            let report = expander_parity(
                "u6",
                "(define-syntax m (syntax-rules nil ((_ x) x))) (define r 1)",
            );
            assert_eq!(report.layer, ExpanderParityLayer::Expander);
            assert!(report.matched, "U6 {}", report.failure_line());
            assert!(expander_parity("u6b", "(define r 2)").layer == ExpanderParityLayer::Expander);
        }

        // U07: the cross-sub-stage full chain (1.0-1.7): source ->
        // read -> expand -> load -> both static layers -> compile ->
        // each engine -> value, with the parity face agreeing.
        {
            let mut s = Session::new();
            let src = "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define r (fib 12))";
            let vm = run_source(&mut s, "u7.krf", src, kerf::driver::Engine::Vm, &[])
                .expect("U7 vm run");
            assert_eq!(vm.global("r").map(|v| v.to_string()), Some("144".into()));
            let mut s = Session::new();
            let ev = run_source(&mut s, "u7.krf", src, kerf::driver::Engine::Eval, &[])
                .expect("U7 eval run");
            assert_eq!(ev.global("r").map(|v| v.to_string()), Some("144".into()));
        }

        // U08: warnings ride the parity face without touching the
        // value channel (the 1.1 contract re-anchored at 1.8).
        {
            let mut s = Session::new();
            let report = run_parity_source(&mut s, "u8.krf", "(define r (set! car 1))", &[])
                .expect("U8 parity runs");
            assert!(report.agrees(), "U8 engines agree");
            assert_eq!(report.warnings.len(), 1);
            assert_eq!(report.warnings[0].code.tag(), "E0008");
        }

        // U09: the two static layers coexist on one program — the
        // non-bool condition collects R3's E0003 and the inference
        // layer's E0009 in one batch (the probe-verified 1.8
        // update of the corpus expectation).
        {
            let mut s = Session::new();
            let err = check_source(&mut s, "u9.krf", "(define r (if 1 2 3))")
                .expect_err("U9 definite condition error");
            let tags: Vec<&str> = err.iter().map(|d| d.code.tag()).collect();
            assert!(
                tags.contains(&"E0003") && tags.contains(&"E0009"),
                "U9 {tags:?}"
            );
        }

        // U10: error recovery — independent definite errors across
        // three different rule families all land in one batch
        // (collection never short-circuits through the wiring).
        {
            let mut s = Session::new();
            let err = check_source(
                &mut s,
                "u10.krf",
                "(define two 2) (define (f x) x) (define a (f 1 2)) (define b (if 1 2 3)) (define c (two 1))",
            )
            .expect_err("U10 multi-family batch");
            let tags: Vec<&str> = err.iter().map(|d| d.code.tag()).collect();
            for want in ["E0002", "E0003", "E0004", "E0009"] {
                assert!(tags.contains(&want), "U10 missing {want} in {tags:?}");
            }
        }
    }

    // ---------- Section V: the Stage 1.9 stage-exit evidence — one
    // case per §21.5 signal (SOP §14.5/§14.6 close; stage0.md
    // §9.50.5). The exit claims must be re-runnable, not narrated. ----------

    {
        use kerf::driver::{
            Engine, ParityReport, Session, check_source, parse, run_parity_source, run_source,
        };

        // V01 (signal 1, semantic stability): every builtin family on
        // one program, both engines, value agreement.
        {
            let src = "(define p (cons 1 (cons 2.5 nil))) (define a (+ 1 2)) (define b (< 1 2)) (define c (car p)) (define d (cdr p)) (define e (nil? nil)) (define f (eq? a a)) (define g (not b)) (define h (do nil nil))";
            let mut s = Session::new();
            let vm = run_source(&mut s, "v1.krf", src, Engine::Vm, &[]).expect("V1 vm");
            let mut s = Session::new();
            let ev = run_source(&mut s, "v1.krf", src, Engine::Eval, &[]).expect("V1 eval");
            for name in ["a", "b", "c", "e", "f", "g"] {
                let vv = vm.global(name).map(|v| v.to_string());
                let ve = ev.global(name).map(|v| v.to_string());
                assert_eq!(vv, ve, "V1 engines agree on `{name}`");
            }
            assert_eq!(vm.global("a").map(|v| v.to_string()), Some("3".into()));
        }

        // V02 (signal 2, bootstrap verification): gate B axis (a)
        // bytecode equality on a fresh composite source (macro +
        // let + tail-if), both axes staying green at the stage close.
        {
            use kerf::driver::gate_b_bytecode;
            let src = "(define-syntax swap (syntax-rules nil ((_ a b) (cons b (cons a nil))))) (define r (do (let ((q (swap 1 2))) (if (nil? (cdr q)) (car q) 9)) 0))";
            gate_b_bytecode("v2", src).expect("V2 gate B at stage close");
        }

        // V03 (signal 3, test coverage): the frozen acceptance face —
        // the whole corpus directory replays through parity with
        // agreement (79 cases, the subset-spec contract).
        {
            let dir = format!("{}/tests/v1/stage1/corpus", env!("CARGO_MANIFEST_DIR"));
            let mut count = 0usize;
            for entry in std::fs::read_dir(&dir).expect("V3 corpus dir").flatten() {
                let path = entry.path();
                if path.extension().is_none_or(|x| x != "krf") {
                    continue;
                }
                let source = std::fs::read_to_string(&path).expect("V3 corpus file");
                let mut s = Session::new();
                match run_parity_source(&mut s, "v3.krf", &source, &[]) {
                    Ok(report) => {
                        let r: &ParityReport = &report;
                        assert!(r.agrees(), "V3 parity drift in {:?}", path.file_name());
                    }
                    // The negative directives reject before parity
                    // (reader/expander/checker) — a non-empty batch is
                    // the expected outcome, also part of the frozen
                    // contract.
                    Err(diags) => assert!(
                        !diags.is_empty(),
                        "V3 empty rejection batch in {:?}",
                        path.file_name()
                    ),
                }
                count += 1;
            }
            assert!(count >= 79, "V3 replayed {count} cases, want >= 79");
        }

        // V04 (signal 4, performance baseline): the budget face the
        // B-series rides on — frames share the allocation budget
        // (live usage counting) and exhaustion fails closed
        // (behavioral anchor at the close).
        {
            use kerf::vm::Vm;
            let bc = kerf::compiler::compile_program(&[]).expect("V4 empty program");
            let mut vm = Vm::with_budget(bc, 4).expect("V4 budgeted vm");
            let value = vm.run().expect("V4 one entry frame fits the budget");
            assert_eq!(value.to_string(), "nil");
            assert!(vm.allocations() >= 1, "V4 the entry frame is budgeted");
            let bc = kerf::compiler::compile_program(&[]).expect("V4 empty program again");
            let mut vm0 = Vm::with_budget(bc, 0).expect("V4 zero-budget vm");
            assert!(
                vm0.run().is_err(),
                "V4 zero budget fails closed (the entry frame cannot allocate)"
            );
        }

        // V05 (signal 5, documentation sync): the rendered-diagnostic
        // goldens are byte-stable (the doc-observable face).
        {
            let mut s = Session::new();
            let err = run_source(
                &mut s,
                "v5.krf",
                "(define f (fn (x) (if x 1 2))) (define r (f 1))",
                Engine::Vm,
                &[],
            )
            .expect_err("V5 definite error");
            let rendered = kerf::driver::render_diagnostics(&s, &err);
            assert!(
                rendered.contains("error[E0009]: type mismatch: expected `bool`, found `int`"),
                "V5 golden text: {rendered}"
            );
            assert!(
                rendered.contains("--> v5.krf:1:45"),
                "V5 location: {rendered}"
            );
        }

        // V06 (signal 6, capability handling degrees): the frozen
        // faces hold their cardinality — 18 builtins, 25 opcodes
        // (24 through the Stage 1 close; +1 at the Stage 2.1
        // semantic MUV: load-captured, the K192 separated-opcode
        // ruling — the store twin stays unlanded with the LA-7
        // immutable-capture subset; the reserved trait shapes
        // compile-guard via the K/L sections).
        {
            assert_eq!(
                kerf::vm::Builtin::ALL.len(),
                18,
                "V6 the builtin set stays frozen at 18"
            );
            assert_eq!(
                kerf::compiler::Opcode::ALL.len(),
                25,
                "V6 the opcode set stays frozen at 25"
            );
        }

        // V07 (signal 7, technical debt zero): the zero-finding dual
        // on the two largest legal programs — the assembled expander
        // (self-forms) and a clean corpus composite.
        {
            use kerf::driver::assembled_expander_source;
            let mut s = Session::new();
            let assembled = assembled_expander_source();
            let self_forms = assembled.replace("\n(define result (ex-run forms))", "");
            let program = parse(&mut s, "v7a.krf", &self_forms).expect("V7a parses");
            let findings = program.typecheck();
            assert!(
                findings
                    .iter()
                    .all(|d| d.severity != kerf::driver::Severity::Error),
                "V7a assembled expander: {findings:?}"
            );
            let mut s = Session::new();
            let out = check_source(
                &mut s,
                "v7b.krf",
                "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define r (fib 15))",
            )
            .expect("V7b clean");
            assert!(
                out.warnings.is_empty(),
                "V7b zero findings: {:?}",
                out.warnings
            );
        }

        // V08 (signal 8, outer-loop vote): the process artifacts are
        // auditable in-tree — the audit composition itself (this
        // binary's section set) and the worklog presence.
        {
            let audit_src = std::fs::read_to_string(format!(
                "{}/examples/audit/stage0_gate_audit_r1.rs",
                env!("CARGO_MANIFEST_DIR")
            ))
            .expect("V8 audit source");
            for section in [
                "A01", "B01", "C01", "D01", "E01", "F01", "G01", "H01", "I01", "J01", "K01", "L01",
                "M01", "N01", "P01", "Q01", "R01", "S01", "T01", "U01", "V01", "W01",
            ] {
                assert!(
                    audit_src.contains(&format!("\"{section}")),
                    "V8 section {section} present"
                );
            }
            assert!(
                std::path::Path::new(&format!("{}/docs/worklog.md", env!("CARGO_MANIFEST_DIR")))
                    .exists(),
                "V8 the worklog mirror exists"
            );
        }

        // V09 (signal 9, cross-stage deep verification): the full
        // pipeline dataflow on one program — read -> expand -> both
        // static layers -> compile -> vm -> value, span resolved
        // through debug_info to a line:column.
        {
            let mut s = Session::new();
            let out = run_source(
                &mut s,
                "v9.krf",
                "(define (add a b) (+ a b))\n(define result (add 20 22))",
                Engine::Vm,
                &[],
            )
            .expect("V9 full chain");
            assert_eq!(
                out.global("result").map(|v| v.to_string()),
                Some("42".into())
            );
            let mut s = Session::new();
            let check = check_source(
                &mut s,
                "v9.krf",
                "(define (add a b) (+ a b))\n(define result (add 20 22))",
            )
            .expect("V9 check face");
            assert!(check.func_count >= 2, "V9 entry + one closure proto");
            assert!(check.instr_count >= 5, "V9 instructions emitted");
        }

        // V10 (robustness close): one error never cascades — after a
        // rejected program, a fresh clean program runs clean (the
        // recovery contract at the stage boundary).
        {
            let mut s = Session::new();
            let _ = run_source(&mut s, "bad.krf", "(define r (car 5))", Engine::Vm, &[]);
            let out = run_source(&mut s, "good.krf", "(define r (+ 40 2))", Engine::Vm, &[])
                .expect("V10 clean run after a rejection");
            assert_eq!(out.global("r").map(|v| v.to_string()), Some("42".into()));
        }
    }

    // ---------- Section W: the Stage 2 lexical-capture family —
    // the 2.2 first-cut close-out (docs/stage0.md §9.80-§9.82). The
    // Stage 2.1 semantic MUV activated flat capture on both engines;
    // these cases pin the activation end-to-end: the three value
    // faces (basic / dense-shadowing / transitive capture, both
    // engines agreeing), the immutability boundary (assign-to-
    // captured E0012), the verifier's definer-frame rule (both
    // descriptor sources out of bounds), the top-level non-capture,
    // and the two ★1' resolution proofs (the env size over a wide
    // frame; the exact swept counter after the defining frame
    // dies). ----------

    {
        use kerf::compiler::{CaptureSource, FuncProto, Instr, Opcode};
        use kerf::driver::{Session, check_source, gate_b_bytecode, run_parity_source};
        use kerf::runtime::collect as production_collect;
        use kerf::span::{ByteOffset, ExpansionId, FileId, Span};
        use kerf::vm::{HeapObj, Value, Vm};

        fn w_span() -> Span {
            Span::new(FileId(0), ByteOffset(0), ByteOffset(1), ExpansionId::ROOT)
                .expect("audit fixture span must be well-formed")
        }

        fn w_compile(src: &str) -> kerf::compiler::Bytecode {
            let forms = kerf::reader::read_program(FileId(0), src).expect("W fixture reads");
            let items = kerf::expander::expand_program(&forms).expect("W fixture expands");
            kerf::compiler::compile_program(&items).expect("W fixture compiles")
        }

        // W01 (the boundary): assign-to-captured is the checker's
        // E0012 definite error, end-to-end with the rendered code and
        // the one-wording-family message (neg-057's shape).
        {
            let mut s = Session::new();
            let Err(diags) = check_source(
                &mut s,
                "w1.krf",
                "(define (bump start) (fn (step) (set! start (+ start step))))",
            ) else {
                panic!("W1 assign-to-captured must be a definite error");
            };
            let rendered = kerf::driver::render_diagnostics(&s, &diags);
            assert!(
                rendered.contains("error[E0012]"),
                "W1 renders the E0012 code: {rendered}"
            );
            assert!(
                rendered.contains("cannot assign to captured variable"),
                "W1 the wording family: {rendered}"
            );
        }

        // W02 (basic capture, both engines): the pos-034 shape — the
        // adder's inner fn captures `n`, both engines halt at 8.
        {
            let mut s = Session::new();
            let report = run_parity_source(
                &mut s,
                "w2.krf",
                "(define (adder n) (fn (x) (+ x n))) (define result ((adder 5) 3))",
                &[],
            )
            .expect("W2 parity runs");
            assert!(report.agrees(), "W2 both engines agree on the capture");
            assert_eq!(
                report.globals_repr.last().map(|(_, v)| v.as_str()),
                Some("8"),
                "W2 the captured 5 flows through the call: {:?}",
                report.globals_repr
            );
        }

        // W03 (dense capture + shadowing, both engines): the pos-035
        // shape — two sibling closures capture independently and the
        // inner param `a` shadows the captured `a`.
        {
            let mut s = Session::new();
            let report = run_parity_source(
                &mut s,
                "w3.krf",
                "(define (make-pair a) (let ((b 2)) (cons (fn (x) (+ x a)) (fn (a) (* a b))))) \
                 (define fns (make-pair 10)) \
                 (define result (+ ((car fns) 3) ((cdr fns) 5)))",
                &[],
            )
            .expect("W3 parity runs");
            assert!(report.agrees(), "W3 both engines agree on shadowing");
            assert_eq!(
                report.globals_repr.last().map(|(_, v)| v.as_str()),
                Some("23"),
                "W3 13 + 10 with the shadow resolved per closure: {:?}",
                report.globals_repr
            );
        }

        // W04 (transitive capture, both engines): the pos-036 shape
        // — the innermost fn re-captures through the middle closure's
        // pass-through table (base and offset ride two levels).
        {
            let mut s = Session::new();
            let report = run_parity_source(
                &mut s,
                "w4.krf",
                "(define (make-adders base) (let ((offset 10)) \
                 (fn (x) (fn (y) (+ y (+ x (+ base offset))))))) \
                 (define add20 ((make-adders 5) 20)) \
                 (define result (add20 25))",
                &[],
            )
            .expect("W4 parity runs");
            assert!(report.agrees(), "W4 both engines agree on the chain");
            assert_eq!(
                report.globals_repr.last().map(|(_, v)| v.as_str()),
                Some("60"),
                "W4 25 + 20 + 5 + 10 through two capture levels: {:?}",
                report.globals_repr
            );
        }

        // W05 (verifier, local source): a descriptor asking for a
        // local slot beyond the defining frame's width is rejected
        // at verify (the LA-2 definer-frame rule, first source kind).
        {
            let mut entry = FuncProto::new(None, 0, 2);
            entry.code = vec![Instr::with_a(Opcode::Closure, 1), Instr::new(Opcode::Halt)];
            entry.debug_info = vec![w_span(); 2];
            let mut callee = FuncProto::new(None, 0, 0);
            callee.captures = vec![CaptureSource::Local(2)];
            callee.code = vec![Instr::new(Opcode::Ret)];
            callee.debug_info = vec![w_span()];
            let mut bc = kerf::compiler::Bytecode::default();
            bc.consts.push(kerf::core::LiteralValue::Int(0));
            bc.funcs.push(entry);
            bc.funcs.push(callee);
            assert!(
                matches!(
                    bc.verify(),
                    Err(kerf::compiler::CompileError::CaptureSourceOutOfRange { .. })
                ),
                "W5 Local(2) over a two-local definer fails verify"
            );
        }

        // W06 (verifier, captured source): a transitive descriptor
        // indexing past the defining closure's own capture area is
        // rejected at verify (the second source kind).
        {
            let mut entry = FuncProto::new(None, 0, 2);
            entry.code = vec![Instr::with_a(Opcode::Closure, 1), Instr::new(Opcode::Halt)];
            entry.debug_info = vec![w_span(); 2];
            let mut mid = FuncProto::new(None, 0, 0);
            mid.captures = vec![CaptureSource::Local(0)];
            mid.code = vec![Instr::with_a(Opcode::Closure, 2), Instr::new(Opcode::Ret)];
            mid.debug_info = vec![w_span(); 2];
            let mut inner = FuncProto::new(None, 0, 0);
            inner.captures = vec![CaptureSource::Captured(3)];
            inner.code = vec![Instr::with_a(Opcode::PushConst, 0), Instr::new(Opcode::Ret)];
            inner.debug_info = vec![w_span(); 2];
            let mut bc = kerf::compiler::Bytecode::default();
            bc.consts.push(kerf::core::LiteralValue::Int(0));
            bc.funcs.push(entry);
            bc.funcs.push(mid);
            bc.funcs.push(inner);
            assert!(
                matches!(
                    bc.verify(),
                    Err(kerf::compiler::CompileError::CaptureSourceOutOfRange { .. })
                ),
                "W6 Captured(3) over a one-entry definer table fails verify"
            );
        }

        // W07 (top-level non-capture): a top-level fn's free name
        // resolves as a global, never as a capture — the entry proto
        // has no enclosing frame, so the LA-1 chain ends there and
        // every product proto carries an empty table.
        {
            let src = "(define n 8) (define (get-n) n) (define result (get-n))";
            let bc = w_compile(src);
            assert!(
                bc.funcs.iter().all(|p| p.captures.is_empty()),
                "W7 top-level closures never capture"
            );
            let mut vm = Vm::new(bc).expect("W7 verifies");
            vm.run().expect("W7 runs");
            assert_eq!(
                vm.global("result").map(|v| v.to_string()),
                Some("8".into()),
                "W7 the global face still resolves"
            );
        }

        // W08 (★1' cost axis, structural): over a fifty-slot
        // defining frame the created closure's env holds exactly the
        // one captured value — the per-creation copy is O(captured),
        // not O(n_locals) (the dormant clone was the whole frame).
        {
            let mut lets = String::new();
            for i in 1..50 {
                lets.push_str(&format!("(u{i} {i})"));
            }
            let src =
                format!("(define (make p) (let ({lets}) (fn (x) (+ x p)))) (define c (make 7))");
            let bc = w_compile(&src);
            let make = bc
                .funcs
                .iter()
                .find(|p| p.n_locals == 50)
                .expect("W8 the fifty-slot defining frame");
            assert_eq!(make.params, 1, "W8 one captured param");
            let inner = bc
                .funcs
                .iter()
                .find(|p| p.captures.len() == 1)
                .expect("W8 the inner descriptor table");
            assert!(
                matches!(inner.captures[0], CaptureSource::Local(_)),
                "W8 the descriptor points into the defining frame"
            );
            let mut vm = Vm::new(bc).expect("W8 verifies");
            vm.run().expect("W8 creates the closure");
            let Value::Closure(r) = vm.global("c").expect("W8 the closure lands") else {
                panic!("W8 `c` holds a closure");
            };
            let env_len = match vm.heap().get(*r) {
                Some(HeapObj::Closure(data)) => data.env.len(),
                other => panic!("W8 closure cell readable, got {other:?}"),
            };
            assert_eq!(env_len, 1, "W8 one slot out of fifty — O(captured)");
        }

        // W09 (★1' retention axis, deterministic counter): eight
        // pair locals, one captured — after the run halts, an
        // explicit §19.4 cycle sweeps exactly the seven uncaptured
        // pairs (the dormant snapshot would have retained all eight
        // and swept zero).
        {
            let src = "(define (outer x) (let ((a (cons 1 nil)) (b (cons 2 nil)) \
                       (c (cons 3 nil)) (d (cons 4 nil)) (e (cons 5 nil)) \
                       (f (cons 6 nil)) (g (cons 7 nil)) (h (cons 8 nil))) \
                       (fn (y) (car a)))) (define keeper (outer 0))";
            let bc = w_compile(src);
            let mut vm = Vm::new(bc).expect("W9 verifies");
            vm.run().expect("W9 outer returns the closure");
            let closure_ref = match vm.global("keeper") {
                Some(Value::Closure(r)) => *r,
                other => panic!("W9 keeper holds a closure, got {other:?}"),
            };
            let roots = vm.snapshot_roots();
            let stats = production_collect(vm.heap_mut(), &roots);
            assert_eq!(stats.swept, 7, "W9 exactly the seven uncaptured pairs");
            assert_eq!(
                stats.live_after, 3,
                "W9 both closure cells + the captured pair survive"
            );
            let held = match vm.heap().get(closure_ref) {
                Some(HeapObj::Closure(data)) => data.env.first().cloned(),
                other => panic!("W9 closure cell survives, got {other:?}"),
            };
            match held {
                Some(Value::Pair(pr)) => match vm.heap().get(pr) {
                    Some(HeapObj::Pair(car, _)) => {
                        assert_eq!(car.to_string(), "1", "W9 the captured pair is `a`");
                    }
                    other => panic!("W9 captured pair survives, got {other:?}"),
                },
                other => panic!("W9 env[0] is the captured pair, got {other:?}"),
            }
        }

        // W10 (gate B on a capture-dense composite): macro + a
        // two-level transitive capture chain + tail-if — the oracle
        // items and the .krf expander's rebuilt items compile to
        // identical bytecode, descriptor tables included.
        {
            gate_b_bytecode(
                "w10",
                "(define-syntax wrap (syntax-rules nil ((_ v) (cons v nil)))) \
                 (define (outer n) (fn (y) (fn (z) (+ z (+ y n))))) \
                 (define r (do (let ((adder ((outer 5) 3))) \
                 (if (< 1 2) (car (wrap (adder 2))) 99))))",
            )
            .expect("W10 gate B holds on the capture-dense composite");
        }
    }

    // ---------- Section X: the Stage 2.3 CP first-pass family —
    // the fixpoint window opening (docs/stage0.md §9.83, K193-K197).
    // The compile-time lexical-domain analysis rewritten in the
    // frozen subset (`selfhost/v1/compiler.krf`, the fourth
    // selfhost file) against the Rust compiler oracle: the analysis
    // products (funcs / globals / consts, creation and first-use
    // orders), the structured rejections (the LA-7 compile-side
    // assign boundary, the 1024/1025 depth mirror), the eval input
    // envelope, the nested-litval stream regression, and the drift
    // detector's self-check — ten cases, both engines. ----------

    {
        use kerf::driver::{
            COMPILER_SOURCE, CompilerParityLayer, compiler_parity, compiler_parity_items,
            compiler_parity_items_vm, compiler_parity_with,
        };
        use kerf::span::{ByteOffset, ExpansionId, FileId, Span};

        fn x_span(start: u32, end: u32) -> Span {
            Span::new(
                FileId(0),
                ByteOffset(start),
                ByteOffset(end),
                ExpansionId::ROOT,
            )
            .expect("audit fixture span must be well-formed")
        }

        // X01 (corpus replay, the capture-dense positive): pos-034
        // through the CP harness — the .krf analysis agrees with the
        // oracle on both engines, the Compiler layer decides.
        {
            let report = compiler_parity(
                "x1",
                "(define (adder n) (fn (x) (+ x n)))\n(define result ((adder 5) 3))",
            );
            assert!(report.matched, "{}", report.failure_line());
            assert!(report.engines_agree);
            assert_eq!(report.layer, CompilerParityLayer::Compiler);
            assert!(
                report
                    .oracle
                    .contains("(proto nil 1 1 (caps (local 0)) (code (")
            );
        }

        // X02 (the LA-4 transitive pass-through): the three-level
        // chain — the mid proto acquires the pass-through entry,
        // the inner descriptor reads (captured 0); proto creation
        // order is entry/outer/mid/inner.
        {
            let report =
                compiler_parity("x2", "(define (outer a) (fn (b) (fn (c) (+ a (+ b c)))))");
            assert!(report.matched, "{}", report.failure_line());
            assert_eq!(
                report.oracle,
                "(funcs (proto nil 0 0 (caps) (code (closure 1 0) (store-global 1 0) \
                 (halt 0 0)) (dbg (sp 9 14) (sp 0 50) (sp 0 50))) \
                 (proto outer 1 1 (caps) (code (closure 2 0) (ret 0 0)) \
                 (dbg (sp 18 49) (sp 18 49))) \
                 (proto nil 1 1 (caps (local 0)) (code (closure 3 0) (ret 0 0)) \
                 (dbg (sp 26 48) (sp 26 48))) \
                 (proto nil 1 1 (caps (captured 0) (local 0)) (code (load-captured 0 0) \
                 (load-captured 1 0) (load-local 0 0) (load-global 0 0) (call 2 0) \
                 (load-global 0 0) (call 2 0) (ret 0 0)) (dbg (sp 37 38) (sp 42 43) \
                 (sp 44 45) (sp 40 41) (sp 39 46) (sp 35 36) (sp 34 47) (sp 34 47)))) \
                 (globals + outer) (consts)"
            );
        }

        // X03 (the LA-7 compile-side boundary): assign through a
        // capture is the structured rejection, rebuilt and rendered
        // through the oracle's own Display — kind, name and span.
        {
            let report = compiler_parity("x3", "(define (f x) (fn (y) (set! x 1)))");
            assert!(report.matched, "{}", report.failure_line());
            assert!(report.engines_agree);
            assert!(
                report
                    .oracle
                    .contains("cannot assign to captured variable `x`")
            );
        }

        // X04 (the depth mirror + the eval envelope): the hand-built
        // 1023-If chain peaks at 1025 — the VM-only face pins the
        // structured rejection against the oracle; the dual-engine
        // face classifies the same tree as the honest harness limit
        // (the eval engine's 2048-call cap sits below the compile
        // depth limit over the stream assembler's per-level
        // recursion — the r74 lineage, never a drift).
        {
            let mut chain = kerf::core::CoreExpr::Literal {
                span: x_span(9999, 10000),
                value: kerf::core::LiteralValue::Bool(true),
            };
            for i in (0..1023usize).rev() {
                let at = (i * 10) as u32;
                chain = kerf::core::CoreExpr::If {
                    span: x_span(at, at + 9),
                    cond: Box::new(kerf::core::CoreExpr::Literal {
                        span: x_span(at + 1, at + 2),
                        value: kerf::core::LiteralValue::Bool(true),
                    }),
                    then_branch: Box::new(kerf::core::CoreExpr::Literal {
                        span: x_span(at + 3, at + 4),
                        value: kerf::core::LiteralValue::Int(0),
                    }),
                    else_branch: Box::new(chain),
                };
            }
            let items = vec![kerf::core::ModuleItem::Define {
                span: x_span(0, 9),
                name: kerf::span::Symbol::new("deep").expect("fixture symbol"),
                value: chain,
            }];
            let dual = compiler_parity_items("x4-envelope", &items);
            assert!(!dual.matched);
            assert!(
                dual.drift
                    .as_deref()
                    .unwrap_or("")
                    .contains("harness limit")
            );
            let vm_only = compiler_parity_items_vm("x4-depth", &items);
            assert!(vm_only.matched, "{}", vm_only.failure_line());
            assert!(
                vm_only
                    .oracle
                    .contains("compile depth `1025` exceeds limit `1024`")
            );
        }

        // X05 (the nested-litval regression): quoted lists nest
        // pairs two and three levels deep — the pair pass-through
        // keeps every inner component (the recovery-verification
        // catch, pinned forever).
        {
            let report = compiler_parity(
                "x5",
                "(define a (quote (1 2)))\n(define b (quote (1 (2 3))))",
            );
            assert!(report.matched, "{}", report.failure_line());
            assert!(report.oracle.contains(
                "(consts (pair (int 1) (pair (int 2) nil)) \
                 (pair (int 1) (pair (pair (int 2) (pair (int 3) nil)) nil)))"
            ));
        }

        // X06 (the scope-stack discipline): sibling lets return
        // their slots at truncate and the next let reuses them —
        // n_locals peaks at 2, not 3.
        {
            let report =
                compiler_parity("x6", "(define (f a) (+ (let ((x 1)) x) (let ((y 2)) y)))");
            assert!(report.matched, "{}", report.failure_line());
            assert!(
                report
                    .oracle
                    .contains("(proto f 1 2 (caps) (code (push-const 0 0)")
            );
        }

        // X07 (the const-pool identity rule): NaN payloads fold to
        // one slot, +0.0/-0.0 stay distinct — same_const_slot's
        // rule mirrored by Debug-text identity (hand-built trees:
        // NaN has no source literal form).
        {
            let mk = |name: &str, value: kerf::core::LiteralValue| kerf::core::ModuleItem::Define {
                span: x_span(0, 9),
                name: kerf::span::Symbol::new(name).expect("fixture symbol"),
                value: kerf::core::CoreExpr::Literal {
                    span: x_span(8, 9),
                    value,
                },
            };
            let items = vec![
                mk("a", kerf::core::LiteralValue::Float(f64::NAN)),
                mk(
                    "b",
                    kerf::core::LiteralValue::Float(f64::from_bits(0x7ff8_0000_0000_0001)),
                ),
                mk("c", kerf::core::LiteralValue::Float(0.0)),
                mk("d", kerf::core::LiteralValue::Float(-0.0)),
            ];
            let report = compiler_parity_items("x7", &items);
            assert!(report.matched, "{}", report.failure_line());
            assert!(
                report
                    .oracle
                    .contains("(consts (float NaN) (float 0.0) (float -0.0))")
            );
        }

        // X08 (the first-use interning order): the define's value
        // walks before the name interns — y lands ahead of + (the
        // builtin global-fallback face) and x; consts in walk order.
        {
            let report = compiler_parity(
                "x8",
                "(define y 0)\n(define x (+ y 1))\n(define b #t)\n(define f 2.5)",
            );
            assert!(report.matched, "{}", report.failure_line());
            assert!(
                report.oracle.contains(
                    "(globals y + x b f) (consts (int 0) (int 1) (bool true) (float 2.5))"
                )
            );
        }

        // X09 (the fourth self-application): compiler.krf analyzes
        // its own expanded tree — the hosting tail stripped (the
        // injected `items` is unbound in the bare source), every
        // analysis face of the segment in one program, both engines.
        {
            let structural = COMPILER_SOURCE.replace("\n(define result (cp-run items))", "");
            assert_ne!(&structural, COMPILER_SOURCE);
            let report = compiler_parity("x9", &structural);
            assert!(report.matched, "{}", report.failure_line());
            assert!(report.engines_agree);
            assert!(report.oracle.matches("(proto ").count() >= 40);
        }

        // X10 (the drift detector's self-check): zeroing the var
        // arm's load-global operand (and skipping the intern) must
        // drift the globals section and the code axis — a parity
        // harness that cannot fail is not a harness.
        {
            let tampered = COMPILER_SOURCE.replace(
                "(cp-emit \"load-global\" (cp-intern-global name) 0 (cp-span-of t))",
                "(cp-emit \"load-global\" 0 0 (cp-span-of t))",
            );
            assert_ne!(&tampered, COMPILER_SOURCE);
            let report = compiler_parity_with("x10", "(define y 1)\n(define x (+ y 1))", &tampered);
            assert!(!report.matched, "X10 the tampered analysis must not pass");
            assert!(report.drift.as_deref().unwrap_or("").contains("oracle"));
        }
    }

    // ---------- Section Y: the Stage 2.3 emission family — the
    // second Pass (docs/stage0.md §9.84, K198-K203). The compiler's
    // instruction emission (the single emit path with the opcode
    // stack-effect table, jump backpatching, the dense
    // per-instruction debug_info table, the tail-position
    // terminator contract) rewritten in the frozen subset and
    // compared against the Rust oracle over the full instruction
    // streams — ten cases, both engines. ----------

    {
        use kerf::driver::{
            COMPILER_SOURCE, CompilerParityLayer, compiler_parity, compiler_parity_items,
        };

        // Y01 (the tail-If terminator contract): a tail If compiles
        // its branches straight into the proto terminator — no merge
        // jump, both branches end in `ret`.
        {
            let report = compiler_parity("y1", "(define (f x) (if x 1 2))");
            assert!(report.matched, "{}", report.failure_line());
            assert!(report.engines_agree);
            assert!(report.oracle.contains(
                "(code (load-local 0 0) (jump-if-false 4 0) (push-const 0 0) \
                 (ret 0 0) (push-const 1 0) (ret 0 0))"
            ));
        }

        // Y02 (the non-tail merge jump): both patches land — the
        // jump-if-false to the else entry, the jump to the join
        // point — and the zero-operand contract holds (b = 0).
        {
            let report = compiler_parity("y2", "(define r (if #t 1 2))");
            assert!(report.matched, "{}", report.failure_line());
            assert!(report.oracle.contains(
                "(code (push-const 0 0) (jump-if-false 4 0) (push-const 1 0) \
                 (jump 5 0) (push-const 2 0) (store-global 0 0) (halt 0 0))"
            ));
        }

        // Y03 (the eval-order contract): args left to right, then
        // the callee; `call n` finds the callee on top.
        {
            let report = compiler_parity("y3", "(define f 1)\n(define r (f 7 8))");
            assert!(report.matched, "{}", report.failure_line());
            assert!(
                report
                    .oracle
                    .contains("(push-const 1 0) (push-const 2 0) (load-global 0 0) (call 2 0)")
            );
        }

        // Y04 (the assign dup form): value, dup, then the store —
        // the local face and the global face side by side.
        {
            let local = compiler_parity("y4a", "(define (f x) (set! x 1))");
            assert!(local.matched, "{}", local.failure_line());
            assert!(
                local
                    .oracle
                    .contains("(code (push-const 0 0) (dup 0 0) (store-local 0 0) (ret 0 0))")
            );
            let global = compiler_parity("y4b", "(define g 0)\n(define (bump) (set! g 1))");
            assert!(global.matched, "{}", global.failure_line());
            assert!(
                global
                    .oracle
                    .contains("(code (push-const 1 0) (dup 0 0) (store-global 0 0) (ret 0 0))")
            );
        }

        // Y05 (the effect operand shapes): perform carries the
        // effect's global index and the argument count; handlers
        // install per clause and pop by count.
        {
            let report = compiler_parity(
                "y5",
                "(define g (handle (perform log 1) (log (fn (v) v)) (err (fn (w) w))))",
            );
            assert!(report.matched, "{}", report.failure_line());
            assert!(
                report
                    .oracle
                    .contains("(closure 1 0) (push-handler 0 0) (closure 2 0) (push-handler 1 0)")
            );
            assert!(report.oracle.contains("(perform 0 1) (pop-handler 2 0)"));
        }

        // Y06 (the closure protocol indices): the closure operands
        // carry the proto creation indices; the inner proto reads
        // its capture by the first-use index.
        {
            let report = compiler_parity("y6", "(define (adder n) (fn (x) (+ x n)))");
            assert!(report.matched, "{}", report.failure_line());
            assert!(
                report
                    .oracle
                    .contains("(code (closure 1 0) (store-global 1 0) (halt 0 0))")
            );
            assert!(report.oracle.contains(
                "(code (load-local 0 0) (load-captured 0 0) (load-global 0 0) \
                 (call 2 0) (ret 0 0))"
            ));
        }

        // Y07 (the const-pool operand identity): duplicate literals
        // share the pool slot — the same_const_slot rule visible in
        // the push-const operands.
        {
            let report = compiler_parity("y7", "(define a 5)\n(define b 5)\n(define c 7)");
            assert!(report.matched, "{}", report.failure_line());
            assert!(report.oracle.contains(
                "(code (push-const 0 0) (store-global 0 0) (push-const 0 0) \
                 (store-global 1 0) (push-const 1 0) (store-global 2 0) (halt 0 0))"
            ));
        }

        // Y08 (the zero-code anchor): define-syntax compiles to zero
        // code, so the terminal halt lands at the cold-start anchor
        // span (0 0) — the only synthesized span.
        {
            let report =
                compiler_parity("y8", "(define-syntax twofold (syntax-rules (x) ((_ x) 2)))");
            assert!(report.matched, "{}", report.failure_line());
            assert!(report.oracle.contains("(code (halt 0 0)) (dbg (sp 0 0))"));
        }

        // Y09 (the dense debug_info table): one span per emit, in pc
        // order — the hand-built fixture spans pin the exact table.
        {
            let mk =
                |name: &str, s: u32, e: u32, ls: u32, le: u32| kerf::core::ModuleItem::Define {
                    span: fspan(s, e),
                    name: kerf::span::Symbol::new(name).expect("fixture symbol"),
                    value: kerf::core::CoreExpr::Literal {
                        span: fspan(ls, le),
                        value: kerf::core::LiteralValue::Int(1),
                    },
                };
            let items = vec![mk("a", 0, 9, 8, 9)];
            let report = compiler_parity_items("y9", &items);
            assert!(report.matched, "{}", report.failure_line());
            assert!(report.oracle.contains("(dbg (sp 8 9) (sp 0 9) (sp 0 9))"));
        }

        // Y10 (the fifth self-application): compiler.krf compiles
        // its own expanded tree — every proto's full instruction
        // stream and dense span table agree with the oracle byte for
        // byte, both engines.
        {
            let structural = COMPILER_SOURCE.replace("\n(define result (cp-run items))", "");
            assert_ne!(&structural, COMPILER_SOURCE);
            let report = compiler_parity("y10", &structural);
            assert!(report.matched, "{}", report.failure_line());
            assert!(report.engines_agree);
            assert_eq!(report.layer, CompilerParityLayer::Compiler);
            assert!(report.oracle.matches(" (code (").count() >= 40);
            assert!(report.oracle.matches(" (dbg (sp ").count() >= 40);
        }

        // ---- Section Z: the composed chain — the 2.3 close-out
        // family (r84, §9.85): the `.krf` expander feeding the
        // `.krf` compiler, one chain against the oracle full
        // pipeline — six cases. ----------

        {
            use kerf::driver::{LEXER_SOURCE, READER_SOURCE, composed_chain_parity};

            // Z01 (the capture-order anchor through the chain): the
            // full formula on the CP2 face — the tree identity holds
            // in-chain and the products match the oracle pipeline.
            composed_chain_parity("z1", "(define (a p q) (fn (z) (+ p (+ q (+ z p)))))")
                .unwrap_or_else(|err| panic!("audit Z01: {err}"));

            // Z02 (the effects anchor through the chain): handle and
            // perform intern their effects on both sides of the
            // formula.
            composed_chain_parity("z2", "(define r (handle (perform log 1) (log (fn (v) v))))")
                .unwrap_or_else(|err| panic!("audit Z02: {err}"));

            // Z03 (the let-shadow anchor through the chain): slot
            // reuse across shadowed bindings lands identically.
            composed_chain_parity("z3", "(define r (let ((x 1)) (let ((x (+ x 1))) x)))")
                .unwrap_or_else(|err| panic!("audit Z03: {err}"));

            // Z04 (the error axis through the chain): the LA-7
            // assign boundary — both sides of the formula reject
            // with the same rebuilt error.
            composed_chain_parity("z4", "(define (outer a) (fn (b) (set! a (+ a b))))")
                .unwrap_or_else(|err| panic!("audit Z04: {err}"));

            // Z05 (the reader fixed point through the chain): the
            // smallest selfhost source, tail-stripped, expanded by
            // the `.krf` expander and compiled by the `.krf`
            // compiler.
            {
                let structural =
                    READER_SOURCE.replace("\n(define result (rd-loop tokens nil nil))", "");
                assert_ne!(&structural, READER_SOURCE, "the hosting tail must strip");
                composed_chain_parity("z5", &structural)
                    .unwrap_or_else(|err| panic!("audit Z05: {err}"));
            }

            // Z06 (the sixth self-application, first through the
            // full `.krf` chain): compiler.krf's own tree — expanded
            // by the `.krf` expander, compiled by the `.krf`
            // compiler, byte-for-byte against the oracle full
            // pipeline. The fixpoint precondition of the 2.4 window.
            {
                let structural = COMPILER_SOURCE.replace("\n(define result (cp-run items))", "");
                assert_ne!(&structural, COMPILER_SOURCE);
                composed_chain_parity("z6", &structural)
                    .unwrap_or_else(|err| panic!("audit Z06: {err}"));
            }

            // ---- Section Z, the 2.4 window extension (r86, §9.87):
            // the FULL composed chain — the `.krf` lexer+reader front
            // end feeding the `.krf` expander and compiler, the
            // chain's own products at every junction, with the total
            // corpus routing and the gate-B promotion witness. ----

            use kerf::driver::{
                ComposedLayer, composed_full_chain_parity, composed_full_chain_parity_vm,
                composed_full_chain_probes, dump_faithfulness_witness,
            };

            // Z07 (the capture-order anchor through the FULL chain):
            // bytes -> lexer.krf -> reader.krf -> expander.krf ->
            // compiler.krf, against the oracle full pipeline — the
            // 2.4 formula with every reading decision self-hosted.
            {
                let report = composed_full_chain_parity(
                    "z7",
                    "(define (a p q) (fn (z) (+ p (+ q (+ z p)))))",
                );
                assert!(report.matched, "audit Z07: {}", report.failure_line());
                assert_eq!(report.layer, ComposedLayer::Compile);
            }

            // Z08 (the effects anchor through the full chain):
            // handle/perform intern their effects identically when
            // the front end is the `.krf` chain's own products.
            {
                let report = composed_full_chain_parity(
                    "z8",
                    "(define r (handle (perform log 1) (log (fn (v) v))))",
                );
                assert!(report.matched, "audit Z08: {}", report.failure_line());
                assert_eq!(report.layer, ComposedLayer::Compile);
            }

            // Z09 (the reader-layer error axis): an unclosed list
            // rejects at junction 1 on both engines with the oracle's
            // key; downstream junctions are vacuous (the routing's
            // total shape — the drift ledger's Read row).
            {
                let report = composed_full_chain_parity("z9", "(define result (+ 1 2)");
                assert!(report.matched, "audit Z09: {}", report.failure_line());
                assert_eq!(report.layer, ComposedLayer::Read);
                assert_eq!(report.expand_matched, None);
            }

            // Z10 (the expander-layer error axis): an unbound
            // reference rejects at junction 2 with the oracle's
            // parity key — junction 1 passed, junction 3 vacuous.
            {
                let report = composed_full_chain_parity("z10", "(define result y)");
                assert!(report.matched, "audit Z10: {}", report.failure_line());
                assert_eq!(report.layer, ComposedLayer::Expand);
                assert!(report.read_matched);
                assert_eq!(report.compile_matched, None);
            }

            // Z11 (the compile-error axis through the full chain):
            // the LA-7 assign-to-captured boundary — the oracle
            // pipeline rejects at compile, the chain's junction 3
            // rejects identically (the error axis rides the same
            // comparison face as the products).
            {
                let report = composed_full_chain_parity(
                    "z11",
                    "(define (outer a) (fn (b) (set! a (+ a b))))",
                );
                assert!(report.matched, "audit Z11: {}", report.failure_line());
                assert_eq!(report.layer, ComposedLayer::Compile);
                assert_eq!(report.compile_matched, Some(true));
            }

            // Z12 (the reader fixed point through the full chain,
            // VM bracket): the reader's own source — read, expanded
            // and compiled entirely by the `.krf` chain.
            {
                let structural =
                    READER_SOURCE.replace("\n(define result (rd-loop tokens nil nil))", "");
                assert_ne!(&structural, READER_SOURCE);
                let report = composed_full_chain_parity_vm("z12", &structural);
                assert!(report.matched, "audit Z12: {}", report.failure_line());
                assert_eq!(report.layer, ComposedLayer::Compile);
            }

            // Z13 (the seventh self-application): the lexer's own
            // source through the COMPLETE `.krf` chain — the
            // strongest real program in tree, read from its byte
            // table by the lexer itself (VM bracket, the r85
            // envelope lineage).
            {
                let cut = LEXER_SOURCE
                    .find("\n(define lex-verdict")
                    .expect("the lexer's hosting tail is present");
                let report = composed_full_chain_parity_vm("z13", &LEXER_SOURCE[..cut]);
                assert!(report.matched, "audit Z13: {}", report.failure_line());
                assert_eq!(report.layer, ComposedLayer::Compile);
            }

            // Z14 (junction 1's detection arm): a tampered lexer —
            // the vertical tab removed from the whitespace table —
            // must fail the chain AT the read junction, never fall
            // through to the expansion (a chain that cannot fail at
            // every junction is not a chain).
            {
                let tampered = LEXER_SOURCE.replace("(if (= b 11) #t", "(if (= b 110) #t");
                assert_ne!(&tampered, LEXER_SOURCE);
                let report = composed_full_chain_probes(
                    "z14",
                    "(define x 1)\n(define y (+ x 1))",
                    Some(&tampered),
                    None,
                    None,
                );
                assert!(!report.matched, "audit Z14: the tampered lexer must fail");
                assert_eq!(report.layer, ComposedLayer::Read);
                assert_eq!(report.expand_matched, None);
            }

            // Z15 (junction 2's detection arm): the tampered
            // expander depth guard (the CP9-5 precedent) — junction 1
            // passes, the failure surfaces AT the expansion junction.
            {
                let expander = kerf::driver::assembled_expander_source();
                let tampered = expander.replace("(>= ex-depth 512)", "(>= ex-depth 2)");
                assert_ne!(&tampered, &expander);
                let report = composed_full_chain_probes(
                    "z15",
                    "(define x (do 1 (do 2 3)))",
                    None,
                    Some(&tampered),
                    None,
                );
                assert!(
                    !report.matched,
                    "audit Z15: the tampered expander must fail"
                );
                assert_eq!(report.layer, ComposedLayer::Expand);
                assert!(report.read_matched);
                assert_eq!(report.compile_matched, None);
            }

            // Z16 (the gate-B promotion witness, §9.87.5): the
            // analysis-dump grammar must be a faithful image of the
            // Bytecode semantics — every field mutation visible —
            // the evidence the 2.5 window registers for gate B's
            // full-pipeline dual-track (dump equality implies
            // bytecode equality).
            {
                let source = "\
(define (outer a) (fn (b) (fn (c) (+ a (+ b c)))))
(define g 3.5)
(define s \"text\")
(define n -7)
(define t #t)
(define r (handle (perform log 1) (log (fn (v) v))))
";
                let forms = kerf::reader::read_program(kerf::span::FileId(0), source)
                    .expect("the audit fixture reads");
                let items =
                    kerf::expander::expand_program(&forms).expect("the audit fixture expands");
                let bc =
                    kerf::compiler::compile_program(&items).expect("the audit fixture compiles");
                dump_faithfulness_witness(&bc).unwrap_or_else(|err| panic!("audit Z16: {err}"));
            }

            // ---- Section Z, the 2.5 fixpoint window extension (r88,
            // §9.89): the rebuild face (MUV ①), the elevated gate B
            // (MUV ③), and the fixpoint itself (MUV ②). ----------

            use kerf::compiler::Opcode;
            use kerf::driver::{
                COMPILER_SOURCE, fixpoint_selfhost_compiler, gate_b_elevated, krf_compile_rich,
                rebuild_bytecode,
            };

            // The malformed-product family's builder: one flat pair
            // chain in a fresh heap (the record shape every decoder
            // walks).
            fn zchain(heap: &mut kerf::vm::Heap, vals: Vec<kerf::vm::Value>) -> kerf::vm::Value {
                let mut acc = kerf::vm::Value::Nil;
                for v in vals.into_iter().rev() {
                    let r = heap.alloc(kerf::vm::HeapObj::Pair(v, acc));
                    acc = kerf::vm::Value::Pair(r);
                }
                acc
            }
            fn zstr(text: &str) -> kerf::vm::Value {
                kerf::vm::Value::Str(std::rc::Rc::from(text))
            }
            fn zproduct(
                heap: &mut kerf::vm::Heap,
                code_insn: kerf::vm::Value,
                dbg_rec: kerf::vm::Value,
            ) -> kerf::vm::Value {
                let dbg = zchain(heap, vec![zstr("dbg"), dbg_rec]);
                let code = zchain(heap, vec![zstr("code"), code_insn]);
                let caps = zchain(heap, vec![zstr("caps")]);
                let proto = zchain(
                    heap,
                    vec![
                        zstr("proto"),
                        kerf::vm::Value::Nil,
                        kerf::vm::Value::Int(0),
                        kerf::vm::Value::Int(0),
                        caps,
                        code,
                        dbg,
                    ],
                );
                let funcs = zchain(heap, vec![zstr("funcs"), proto]);
                let globals = zchain(heap, vec![zstr("globals")]);
                let consts = zchain(heap, vec![zstr("consts")]);
                zchain(heap, vec![zstr("ok"), funcs, globals, consts])
            }

            // Z17 (the opcode reverse table, §9.89 MUV ①): the
            // kebab names invert through the single-source pair —
            // all twenty-five, and nothing else does.
            {
                for op in Opcode::ALL {
                    assert_eq!(
                        Opcode::from_kind_name(op.kind_name()),
                        Some(op),
                        "audit Z17: `{}` must invert",
                        op.kind_name()
                    );
                }
                assert_eq!(Opcode::from_kind_name("no-such-op"), None, "audit Z17");
                assert_eq!(
                    Opcode::from_kind_name("Halt"),
                    None,
                    "audit Z17: kebab only"
                );
            }

            // Z18 (the rebuild face on the generation axis): the
            // `.krf` compiler's product rebuilt field-for-field —
            // the macro-introduced instructions land their
            // generations in the real debug spans (the axis the
            // dump text leaves outside; the 2.5 addendum's whole
            // point).
            {
                let source = concat!(
                    "(define-syntax my-if (syntax-rules nil ((_ c a b) (if c a b))))\n",
                    "(define result (my-if #t 1 2))\n"
                );
                let forms = kerf::reader::read_program(kerf::span::FileId(0), source)
                    .expect("the audit fixture reads");
                let items =
                    kerf::expander::expand_program(&forms).expect("the audit fixture expands");
                let oracle =
                    kerf::compiler::compile_program(&items).expect("the audit fixture compiles");
                let run =
                    krf_compile_rich(&items, COMPILER_SOURCE).expect("the .krf compiler runs");
                let bc = run.bytecode.expect("the .krf compiler accepts the fixture");
                assert_eq!(
                    bc, oracle,
                    "audit Z18: the rebuilt product equals the oracle's"
                );
                assert!(
                    bc.funcs
                        .iter()
                        .flat_map(|f| f.debug_info.iter())
                        .any(|s| { s.expansion_id != kerf::span::ExpansionId::ROOT }),
                    "audit Z18: the macro generations must land in the rebuilt spans"
                );
            }

            // Z19 (the fail-closed rebuild — unknown opcode name): a
            // fabricated kebab name must fail at the reverse lookup,
            // never pass through.
            {
                let mut heap = kerf::vm::Heap::default();
                let insn = zchain(
                    &mut heap,
                    vec![
                        zstr("no-such-op"),
                        kerf::vm::Value::Int(0),
                        kerf::vm::Value::Int(0),
                    ],
                );
                let dbg_rec = zchain(
                    &mut heap,
                    vec![zstr("0"), zstr("0"), kerf::vm::Value::Int(0)],
                );
                let product = zproduct(&mut heap, insn, dbg_rec);
                let err = rebuild_bytecode(&product, &heap)
                    .expect_err("audit Z19: an unknown opcode name must fail closed");
                assert!(err.contains("unknown opcode"), "audit Z19: {err}");
            }

            // Z20 (the fail-closed rebuild — a negative operand):
            // the `u32` slots reject negatives at the range check.
            {
                let mut heap = kerf::vm::Heap::default();
                let insn = zchain(
                    &mut heap,
                    vec![
                        zstr("halt"),
                        kerf::vm::Value::Int(-1),
                        kerf::vm::Value::Int(0),
                    ],
                );
                let dbg_rec = zchain(
                    &mut heap,
                    vec![zstr("0"), zstr("0"), kerf::vm::Value::Int(0)],
                );
                let product = zproduct(&mut heap, insn, dbg_rec);
                let err = rebuild_bytecode(&product, &heap)
                    .expect_err("audit Z20: a negative operand must fail closed");
                assert!(err.contains("negative"), "audit Z20: {err}");
            }

            // Z21 (the fail-closed rebuild — a bad generation): the
            // trailing generation int is validated, never defaulted.
            {
                let mut heap = kerf::vm::Heap::default();
                let insn = zchain(
                    &mut heap,
                    vec![
                        zstr("halt"),
                        kerf::vm::Value::Int(0),
                        kerf::vm::Value::Int(0),
                    ],
                );
                let dbg_rec = zchain(
                    &mut heap,
                    vec![zstr("0"), zstr("0"), kerf::vm::Value::Int(-3)],
                );
                let product = zproduct(&mut heap, insn, dbg_rec);
                let err = rebuild_bytecode(&product, &heap)
                    .expect_err("audit Z21: a negative generation must fail closed");
                assert!(err.contains("generation"), "audit Z21: {err}");
            }

            // Z22 (the fail-closed rebuild — a truncated proto): the
            // arity check fires before any field is trusted.
            {
                let mut heap = kerf::vm::Heap::default();
                let proto = zchain(
                    &mut heap,
                    vec![
                        zstr("proto"),
                        kerf::vm::Value::Nil,
                        kerf::vm::Value::Int(0),
                        kerf::vm::Value::Int(0),
                    ],
                );
                let funcs = zchain(&mut heap, vec![zstr("funcs"), proto]);
                let globals = zchain(&mut heap, vec![zstr("globals")]);
                let consts = zchain(&mut heap, vec![zstr("consts")]);
                let product = zchain(&mut heap, vec![zstr("ok"), funcs, globals, consts]);
                let err = rebuild_bytecode(&product, &heap)
                    .expect_err("audit Z22: a truncated proto must fail closed");
                assert!(err.contains("fields"), "audit Z22: {err}");
            }

            // Z23 (the elevated gate B, §9.89 MUV ③): the `.krf`
            // side swapped to the rebuilt product — bytecode
            // equality through the `.krf` expander's own tree on a
            // macro fixture (the generation axis rides end to end).
            {
                let source = concat!(
                    "(define-syntax my-if (syntax-rules nil ((_ c a b) (if c a b))))\n",
                    "(define result (my-if #t 1 2))\n"
                );
                gate_b_elevated("z23", source).unwrap_or_else(|err| panic!("audit Z23: {err}"));
            }

            // Z24 (THE fixpoint, §9.89 MUV ② / SOP §21.3 exit
            // criterion (2)): the compiler compiled by itself,
            // EXECUTED in the VM, reproduces its own compilation
            // byte-for-byte — C(C(S)) == C(S). The trusting-trust
            // chain closes: the auditable seed, the parity oracle,
            // and the fixpoint determinism (§9.25 BS-E).
            {
                let report =
                    fixpoint_selfhost_compiler().unwrap_or_else(|err| panic!("audit Z24: {err}"));
                assert!(report.fixpoint_holds, "audit Z24: C(C(S)) != C(S)");
                assert!(
                    report.self_protos >= 40,
                    "audit Z24: the fixed point must exercise a real proto population"
                );
                assert!(
                    report.selfapplied_consts > report.self_consts,
                    "audit Z24: the self-applied program carries its baked input as a const"
                );
            }
        }

        // ============ Section AA: the C transpilation backend — the
        // 2.6 first cut (r91, §9.92) ============
        // Chain-external by constitution: the section compiles and
        // RUNS real cc products, but the audit itself never requires
        // cc — every case passes the gate first and skips WITH
        // DISCLOSURE when the host lacks one (the r90 adjudication
        // II gate: skip-with-disclosure, not failure).
        {
            use kerf::cbackend::emit_c;
            use kerf::compiler::{Bytecode as AABc, FuncProto as AAProto, Instr as AAInstr};
            use kerf::core::LiteralValue as AALit;
            use kerf::span::{ByteOffset as AAOff, ExpansionId as AAExp, Span as AASpan};
            use std::io::Write as _;
            use std::path::PathBuf as AAPath;
            use std::process::{Command as AACmd, Stdio as AAStdio};

            fn aa_span() -> AASpan {
                AASpan::new(FileId(0), AAOff(0), AAOff(1), AAExp::ROOT)
                    .expect("audit fixture span must be well-formed")
            }

            fn aa_work() -> AAPath {
                let dir = AAPath::from("target/audit-aa");
                std::fs::create_dir_all(&dir).expect("the audit work dir");
                dir
            }

            fn aa_cc(name: &str, c_source: &str, extra: &[&str]) -> AAPath {
                let dir = aa_work();
                let cpath = dir.join(format!("{name}.c"));
                std::fs::write(&cpath, c_source).expect("write the C source");
                let bin = dir.join(name);
                let out = AACmd::new("cc")
                    .arg(&cpath)
                    .args(extra)
                    .arg("-o")
                    .arg(&bin)
                    .output()
                    .expect("spawn cc");
                assert!(
                    out.status.success(),
                    "audit AA: cc rejected `{name}`:\n{}",
                    String::from_utf8_lossy(&out.stderr)
                );
                bin
            }

            fn aa_run(bin: &AAPath, stdin_lines: &[&str]) -> (i32, String, String) {
                let mut child = AACmd::new(bin)
                    .stdin(AAStdio::piped())
                    .stdout(AAStdio::piped())
                    .stderr(AAStdio::piped())
                    .spawn()
                    .expect("spawn the transpiled binary");
                {
                    let stdin = child.stdin.as_mut().expect("stdin pipe");
                    for line in stdin_lines {
                        writeln!(stdin, "{line}").expect("feed stdin");
                    }
                }
                let out = child.wait_with_output().expect("collect the exit");
                (
                    out.status.code().unwrap_or(-1),
                    String::from_utf8_lossy(&out.stdout).into_owned(),
                    String::from_utf8_lossy(&out.stderr).into_owned(),
                )
            }

            fn aa_compile(source: &str) -> AABc {
                let forms = kerf::reader::read_program(FileId(0), source).expect("read");
                let items = kerf::expander::expand_program(&forms).expect("expand");
                kerf::compiler::compile_program(&items).expect("compile")
            }

            /// A hand-built [push-const i; halt] entry — the direct
            /// value-display probe.
            fn aa_display_probe(lit: AALit) -> AABc {
                let mut proto = AAProto::new(None, 0, 0);
                proto.code = vec![
                    AAInstr::with_a(kerf::compiler::Opcode::PushConst, 0),
                    AAInstr::new(kerf::compiler::Opcode::Halt),
                ];
                proto.debug_info = vec![aa_span(); 2];
                AABc {
                    consts: vec![lit],
                    funcs: vec![proto],
                    ..Default::default()
                }
            }

            fn aa_have_cc() -> bool {
                AACmd::new("cc")
                    .arg("--version")
                    .stdout(AAStdio::null())
                    .stderr(AAStdio::null())
                    .status()
                    .is_ok_and(|s| s.success())
            }

            let aa_cc_present = aa_have_cc();
            if !aa_cc_present {
                println!(
                    "audit AA: cc unavailable — the ten backend cases skip with disclosure (the chain-external gate; the emitter-level faces below still run)"
                );
            }

            // AA1 (emission determinism + the constitutional header):
            // identical product, byte-identical C; the header pins
            // the version and states the chain-external position. No
            // cc required — the emitter face is pure.
            {
                let bc = aa_compile(
                    "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define result (fib 6))",
                );
                let first = emit_c(&bc).expect("audit AA1: emits");
                let second = emit_c(&bc).expect("audit AA1: emits again");
                assert_eq!(first, second, "audit AA1: emission must be deterministic");
                assert!(
                    first.contains("chain-external; never part of the bootstrap chain"),
                    "audit AA1: the header states the constitutional position"
                );
                assert!(
                    first.contains(&format!(
                        "generated by kerf emit-c {}",
                        env!("CARGO_PKG_VERSION")
                    )),
                    "audit AA1: the header pins the workspace version"
                );
                assert!(
                    first.contains("#define K_BUDGET 8388608u"),
                    "audit AA1: the budget define mirrors the VM default"
                );
            }

            // AA2 (immediates display parity): the C binary's halt
            // value byte-matches the Rust Value Display — including
            // the i64 boundaries and a quoted-escape string. The nil
            // probe pins the driver's nil-silence contract (nothing
            // prints).
            if aa_cc_present {
                for (name, lit) in [
                    ("aa2-int", AALit::Int(42)),
                    ("aa2-int-min", AALit::Int(i64::MIN)),
                    ("aa2-int-max", AALit::Int(i64::MAX)),
                    ("aa2-bool", AALit::Bool(true)),
                    ("aa2-str", AALit::String("with \"quotes\" and \\".into())),
                ] {
                    let value = kerf::vm::Value::from_literal(&lit, &mut kerf::vm::Heap::default());
                    let expected = format!("{value}\n");
                    let bin = aa_cc(name, &emit_c(&aa_display_probe(lit)).expect("emit"), &[]);
                    let (code, stdout, stderr) = aa_run(&bin, &[]);
                    assert_eq!(code, 0, "audit AA2 {name}: {stderr}");
                    assert_eq!(stdout, expected, "audit AA2 {name}: display parity");
                }
                let nil_lit = AALit::Nil;
                let bin = aa_cc(
                    "aa2-nil",
                    &emit_c(&aa_display_probe(nil_lit)).expect("emit"),
                    &[],
                );
                let (code, stdout, stderr) = aa_run(&bin, &[]);
                assert_eq!(code, 0, "audit AA2 nil: {stderr}");
                assert_eq!(
                    stdout, "",
                    "audit AA2: nil halts stay silent (the driver contract)"
                );
            }

            // AA3 (the float display battery): the shortest-round-trip
            // formatter against Rust's Grisu/dragon Display on the
            // hardest eight — the 2.6 registered hidden face
            // (float text determinism) closed with a real parity
            // proof, not an argument.
            if aa_cc_present {
                let vals: [f64; 8] = [
                    0.1,
                    0.30000000000000004,
                    1e21,
                    1e-7,
                    -0.0,
                    f64::INFINITY,
                    f64::NAN,
                    5e-324,
                ];
                for (i, v) in vals.iter().enumerate() {
                    let lit = AALit::Float(*v);
                    let expected = format!("{}\n", kerf::vm::Value::Float(*v));
                    let name = format!("aa3-float-{i}");
                    let bin = aa_cc(&name, &emit_c(&aa_display_probe(lit)).expect("emit"), &[]);
                    let (code, stdout, stderr) = aa_run(&bin, &[]);
                    assert_eq!(code, 0, "audit AA3 {name}: {stderr}");
                    assert_eq!(
                        stdout, expected,
                        "audit AA3 {name}: the shortest-round-trip parity"
                    );
                }
            }

            // AA4 (control flow + recursion through the backend):
            // fib(25) recomputed by the cc product and verified by
            // its own check epilogue (the value channel for a
            // declaration-only program).
            if aa_cc_present {
                let source = "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define result (fib 25)) (define ccb (if (= result 75025) (write-line \"PASS\") (write-line \"FAIL\")))";
                let bin = aa_cc("aa4-fib", &emit_c(&aa_compile(source)).expect("emit"), &[]);
                let (code, stdout, stderr) = aa_run(&bin, &[]);
                assert_eq!(code, 0, "audit AA4: {stderr}");
                assert_eq!(stdout, "PASS\n", "audit AA4: the transpiled fib agrees");
            }

            // AA5 (flat captures + the effect carrier): the LA-4
            // pass-through case and a handle/perform round trip —
            // the two semantic families beyond plain arithmetic.
            if aa_cc_present {
                let cap = "(define (f x) (fn (y) (fn (z) (+ x (+ y z))))) (define g (f 10)) (define h (g 20)) (define result (h 12)) (define ccb (if (= result 42) (write-line \"PASS\") (write-line \"FAIL\")))";
                let bin = aa_cc(
                    "aa5-captures",
                    &emit_c(&aa_compile(cap)).expect("emit"),
                    &[],
                );
                let (code, stdout, stderr) = aa_run(&bin, &[]);
                assert_eq!(code, 0, "audit AA5 captures: {stderr}");
                assert_eq!(stdout, "PASS\n", "audit AA5: transitive captures survive");

                let eff = "(define result (handle (perform add 1 2) (add (fn (a b) (+ a b))))) (define ccb (if (= result 3) (write-line \"PASS\") (write-line \"FAIL\")))";
                let bin = aa_cc("aa5-effects", &emit_c(&aa_compile(eff)).expect("emit"), &[]);
                let (code, stdout, stderr) = aa_run(&bin, &[]);
                assert_eq!(code, 0, "audit AA5 effects: {stderr}");
                assert_eq!(
                    stdout, "PASS\n",
                    "audit AA5: the handler stack rides the shim"
                );
            }

            // AA6 (the arity fail-closed family): three representative
            // wrong-argc calls — the runtime half of the 18-name
            // registry drift guard (the name-mapping half is the
            // emitter unit face).
            if aa_cc_present {
                for (name, global, argc, expect) in [
                    ("aa6-add", "+", 1u32, "`+` expects `2` arguments"),
                    ("aa6-cons", "cons", 3, "`cons` expects `2` arguments"),
                    (
                        "aa6-write",
                        "write-line",
                        0,
                        "`write-line` expects `1` argument",
                    ),
                ] {
                    let mut proto = AAProto::new(None, 0, 0);
                    let mut code = Vec::new();
                    for _ in 0..argc {
                        code.push(AAInstr::with_a(kerf::compiler::Opcode::PushConst, 0));
                    }
                    code.push(AAInstr::with_a(kerf::compiler::Opcode::LoadGlobal, 0));
                    code.push(AAInstr::with_a(kerf::compiler::Opcode::Call, argc));
                    code.push(AAInstr::new(kerf::compiler::Opcode::Pop));
                    code.push(AAInstr::new(kerf::compiler::Opcode::Halt));
                    proto.code = code;
                    proto.debug_info = vec![aa_span(); proto.code.len()];
                    let bc = AABc {
                        consts: vec![AALit::Int(1)],
                        globals: vec![
                            kerf::span::Symbol::new(global)
                                .expect("builtin name is a valid symbol"),
                        ],
                        funcs: vec![proto],
                    };
                    let bin = aa_cc(name, &emit_c(&bc).expect("emit"), &[]);
                    let (code, _, stderr) = aa_run(&bin, &[]);
                    assert_eq!(code, 1, "audit AA6 {name}: fail closed");
                    assert!(stderr.contains(expect), "audit AA6 {name}: {stderr}");
                }
            }

            // AA7 (the §19.4 budget face): a 40-cell chain against
            // -DK_BUDGET=24 fails closed with the family message —
            // the collect-then-retry machinery is VM-side; the
            // first-cut C shim is the no-GC fork (registered) and
            // keeps the same fail-closed boundary.
            if aa_cc_present {
                let mut source = String::from("(define chain ");
                for _ in 0..40 {
                    source.push_str("(cons 1 ");
                }
                source.push_str("nil");
                for _ in 0..40 {
                    source.push(')');
                }
                source.push_str(")\n");
                let bin = aa_cc(
                    "aa7-budget",
                    &emit_c(&aa_compile(&source)).expect("emit"),
                    &["-DK_BUDGET=24"],
                );
                let (code, _, stderr) = aa_run(&bin, &[]);
                assert_eq!(code, 1, "audit AA7: the budget must fire");
                assert!(
                    stderr.contains("allocation budget of `24` exhausted"),
                    "audit AA7: {stderr}"
                );
            }

            // AA8 (the host-stack depth guard): recursion depth 40
            // against -DK_DEPTH_CAP=8 fails closed cleanly — the
            // registered host-stack boundary (heap-frames in the VM,
            // C frames here) with a clean error, never a segfault.
            if aa_cc_present {
                let source = "(define (cd n) (if (= n 0) 0 (cd (- n 1)))) (define result (cd 40))";
                let bin = aa_cc(
                    "aa8-depth",
                    &emit_c(&aa_compile(source)).expect("emit"),
                    &["-DK_DEPTH_CAP=8"],
                );
                let (code, _, stderr) = aa_run(&bin, &[]);
                assert_eq!(code, 1, "audit AA8: the guard must fire");
                assert!(
                    stderr.contains("recursion depth of `8` exceeded"),
                    "audit AA8: {stderr}"
                );
            }

            // AA9 (unbound global + ret-from-entry fail-closed): the
            // two hand-built negative faces the source surface can
            // never produce (the checker owns their static twins).
            if aa_cc_present {
                let mut proto = AAProto::new(None, 0, 0);
                proto.code = vec![
                    AAInstr::with_a(kerf::compiler::Opcode::LoadGlobal, 0),
                    AAInstr::new(kerf::compiler::Opcode::Pop),
                    AAInstr::new(kerf::compiler::Opcode::Halt),
                ];
                proto.debug_info = vec![aa_span(); 3];
                let bc = AABc {
                    globals: vec![
                        kerf::span::Symbol::new("missing").expect("audit fixture symbol"),
                    ],
                    funcs: vec![proto],
                    ..Default::default()
                };
                let bin = aa_cc("aa9-unbound", &emit_c(&bc).expect("emit"), &[]);
                let (code, _, stderr) = aa_run(&bin, &[]);
                assert_eq!(code, 1);
                assert!(
                    stderr.contains("unbound global `missing`"),
                    "audit AA9: {stderr}"
                );

                let mut proto = AAProto::new(None, 0, 0);
                proto.code = vec![
                    AAInstr::with_a(kerf::compiler::Opcode::PushConst, 0),
                    AAInstr::new(kerf::compiler::Opcode::Ret),
                ];
                proto.debug_info = vec![aa_span(); 2];
                let bc = AABc {
                    consts: vec![AALit::Int(1)],
                    funcs: vec![proto],
                    ..Default::default()
                };
                let bin = aa_cc("aa9-ret-entry", &emit_c(&bc).expect("emit"), &[]);
                let (code, _, stderr) = aa_run(&bin, &[]);
                assert_eq!(code, 1);
                assert!(
                    stderr.contains("ret from entry frame at pc `1`"),
                    "audit AA9: {stderr}"
                );
            }

            // AA10 (read-line I/O parity + the gate disclosure pin):
            // getline feeds read-line exactly like the seeded
            // BufferIo; the disclosure sentence is pinned so a
            // cc-absent host still reports, never stays silent.
            if aa_cc_present {
                let source = "(define a (read-line)) (define b (read-line)) (define result (if (eq? a \"one\") (eq? b \"two\") #f)) (define ccb (if (eq? result #t) (write-line \"PASS\") (write-line \"FAIL\")))";
                let bin = aa_cc(
                    "aa10-read-line",
                    &emit_c(&aa_compile(source)).expect("emit"),
                    &[],
                );
                let (code, stdout, stderr) = aa_run(&bin, &["one", "two"]);
                assert_eq!(code, 0, "audit AA10: {stderr}");
                assert_eq!(stdout, "PASS\n", "audit AA10: stdin feeds read-line");
                // The gate text (always asserted, cc or not):
                let disclosure = "skip with disclosure, not failure (the chain-external gate)";
                assert!(
                    disclosure.contains("skip with disclosure"),
                    "audit AA10: the gate text is pinned"
                );
            } else {
                // cc-absent hosts still verify the disclosure pin.
                let disclosure = "skip with disclosure, not failure (the chain-external gate)";
                assert!(disclosure.contains("skip with disclosure"));
            }
        }
    }

    println!(
        "AUDIT PASS 274/274 (A10 + B10 + C5 + D5 + E10 + F10 + G10 + H10 + I10 + J10 + K10 + L10 + M10 + N10 + P10 + Q10 + R20 + S10 + T10 + U10 + V10 + W10 + X10 + Y10 + Z24 + AA10)"
    );
    println!(
        "class coverage at 1.9: all seven lit (unchanged); section V mounts the stage-exit evidence — one case per §21.5 signal: semantic stability (builtin families, both engines), bootstrap verification (gate B both axes), test coverage (corpus replay), performance baseline (the budget face), documentation sync (render goldens), capability degrees (reserved seals), debt zero (the two-large-program zero-finding dual), outer-loop auditability (the section set + worklog mirror), cross-stage verification (full pipeline dataflow), and the recovery close; section W mounts the Stage 2 lexical-capture family — the 2.2 close-out: the three value faces (basic / dense-shadowing / transitive, both engines), the E0012 immutability boundary, the verifier's definer-frame rule (both descriptor sources), the top-level non-capture, and the two ★1' resolution proofs (the O(captured) env size over a wide frame; the exact swept counter); section Z mounts the composed chain — the 2.3 close-out and the 2.4 window: the full formula compile(expand_oracle(S)) == compile_krf(expand_krf(S)) on the capture-order, effects and let-shadow anchors, the LA-7 error axis, the reader fixed point, and the sixth self-application (compiler.krf through the full .krf chain) — extended r86 with the FULL composed chain (§9.87): the .krf lexer+reader front end feeding forward at every junction (Z07/Z08 anchors), the total error-axis routing (Z09 read-layer, Z10 expander-layer, Z11 compile-layer), the reader fixed point and the SEVENTH self-application (lexer.krf through the complete .krf chain, Z12/Z13), the junction-local tamper detection arms (Z14/Z15), and the gate-B promotion witness — the dump grammar's faithful image of the Bytecode semantics (Z16, the 2.5 precondition); extended r88 with the 2.5 fixpoint window (§9.89): the opcode reverse table (Z17), the rebuild face on the generation axis (Z18), the fail-closed malformed-product family (Z19-Z22), the elevated gate B (Z23), and THE fixpoint — the compiler compiled by itself, executed, reproducing its own compilation byte-for-byte (Z24, SOP §21.3 (2))"
    );
}

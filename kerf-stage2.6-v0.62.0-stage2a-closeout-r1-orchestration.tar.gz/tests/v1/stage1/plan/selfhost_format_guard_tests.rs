//! Selfhost formatting guards (§9.79 FMT — the selfhost formatting
//! round, root-project asset face).
//!
//! Three machine-checked invariants over the four `.krf` sources of
//! `selfhost/v1/` — the bootstrap front end plus the Stage 2.3
//! compile-time analysis, all written in the frozen subset itself.
//! These span no crate (the files are root-project assets consumed
//! via `include_str!` from kerf-driver), so the guard lives at the
//! root (SOP §8.4.6 / §9.1 — cross-crate assertions never go inside
//! a crate's own tree).
//!
//! 1. **Line width** — no line exceeds 100 columns (SOP §10.5
//!    `~100 columns`; the same bound rustfmt enforces on the Rust
//!    face — the `.krf` layer joins the repo-wide convention).
//!    Before v0.48.0 the worst offenders were 1697 and 684 columns.
//! 2. **Non-ASCII whitelist** — comments may carry the em-dash `—`
//!    (the repo-wide parenthetical-dash convention: 122 Rust files)
//!    and the section anchor `§` (SOP §10.5 rule 2: technical
//!    anchors ride verbatim); any other non-ASCII character is drift.
//! 3. **ASCII parenthetical dashes absent** — the pre-v0.48.0
//!    sources mixed ` - ` and `  -  ` ASCII dashes (an authoring
//!    artifact of the 1.6/1.7 rounds: expander.krf and macro.krf,
//!    plus the two expander-parity Rust faces); the cleanup unified
//!    every parenthetical dash to the em-dash, and this guard pins
//!    the convention. Local pre-flight: `tools/selfhost/
//!    krf_reformat.py <file> --check` (docs/tools/selfhost/
//!    krf-reformat.md).

const LEXER: &str = include_str!("../../../../selfhost/v1/lexer.krf");
const READER: &str = include_str!("../../../../selfhost/v1/reader.krf");
const EXPANDER: &str = include_str!("../../../../selfhost/v1/expander.krf");
const MACRO: &str = include_str!("../../../../selfhost/v1/macro.krf");
const COMPILER: &str = include_str!("../../../../selfhost/v1/compiler.krf");

/// The formatting convention bound (columns; comment layers measure
/// display width, so count chars — the em-dash is three bytes but one
/// column).
const WIDTH_BOUND: usize = 100;

fn sources() -> [(&'static str, &'static str); 5] {
    [
        ("lexer.krf", LEXER),
        ("reader.krf", READER),
        ("expander.krf", EXPANDER),
        ("macro.krf", MACRO),
        ("compiler.krf", COMPILER),
    ]
}

#[test]
fn selfhost_lines_respect_the_width_convention() {
    for (name, src) in sources() {
        for (idx, line) in src.lines().enumerate() {
            let width = line.chars().count();
            assert!(
                width <= WIDTH_BOUND,
                "{name}: line {} is {} columns (bound {WIDTH_BOUND}): {}…",
                idx + 1,
                width,
                line.chars().take(40).collect::<String>()
            );
        }
    }
}

#[test]
fn selfhost_non_ascii_is_whitelisted() {
    for (name, src) in sources() {
        let offenders: Vec<(usize, char)> = src
            .char_indices()
            .filter(|(_, c)| !c.is_ascii() && *c != '—' && *c != '§')
            .collect();
        assert!(
            offenders.is_empty(),
            "{name}: non-ASCII outside the {{em-dash, section}} whitelist \
             (SOP §10.5 rule 2 keeps § anchors verbatim; the em-dash is the \
             repo-wide parenthetical convention): {offenders:?}"
        );
    }
}

#[test]
fn selfhost_parenthetical_dashes_are_em_dashes() {
    for (name, src) in sources() {
        assert!(
            !src.contains(" - "),
            "{name}: ASCII spaced dash survives (pre-v0.48.0 authoring \
             artifact) — the convention is the em-dash ` — `"
        );
        assert!(
            !src.contains("  -  "),
            "{name}: double-spaced ASCII dash survives (pre-v0.48.0 \
             authoring artifact) — the convention is the em-dash ` — `"
        );
    }
}

//! Test-infrastructure self-audit guards (interlude Task 34, §9.57).
//!
//! The meta-domain face of the test tree: the guards below verify the
//! infrastructure that verifies the compiler. Every guard is a pure
//! read-and-count face over the repository layout — zero pipeline
//! execution, zero new dependencies (SOP §18).
//!
//! Three inventory invariants (the K75 tidy/compiletest family —
//! mechanical, tree-wide, fail-closed):
//! 1. Runner mounting: every `.rs` file under `tests/` is mounted by
//!    `tests/runner.rs` (cargo discovers only `tests/*.rs` top-level
//!    files; an unmounted file would silently never run).
//! 2. Corpus table parity: the per-case macro table in
//!    `subset_corpus_tests.rs` and the corpus directory carry exactly
//!    the same file set (no orphan file, no phantom entry — the
//!    dynamic sweep already covers validation; this guard covers the
//!    isolation table).
//! 3. Audit case registration: every audit case in
//!    `examples/audit/stage0_gate_audit_r1.rs` opens with a
//!    `// XNN:` comment label (the uniform registration convention
//!    normalized in v0.26.0); the per-section counts must equal the
//!    documented composition exactly (A10 + B10 + C5 + D5 + 16x10
//!    = 200) and the headline literal must match.
//!
//! A guard failure means an inventory drift: mount the file, table
//! the case, or label the case — never weaken the guard.

use std::collections::BTreeMap;
use std::path::{Path, PathBuf};

/// The repository root (the crate manifest directory).
fn repo_root() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
}

/// Recursively collect `.rs` files under `dir` (sorted, deterministic).
fn rust_files_under(dir: &Path) -> Vec<PathBuf> {
    let mut out = Vec::new();
    let mut stack = vec![dir.to_path_buf()];
    while let Some(d) = stack.pop() {
        let mut entries: Vec<_> = std::fs::read_dir(&d)
            .unwrap_or_else(|e| panic!("read_dir {}: {e}", d.display()))
            .filter_map(|e| e.ok())
            .map(|e| e.path())
            .collect();
        entries.sort();
        for path in entries {
            if path.is_dir() {
                stack.push(path);
            } else if path.extension().is_some_and(|x| x == "rs") {
                out.push(path);
            }
        }
    }
    out.sort();
    out
}

/// TEST-1: every `.rs` file under `tests/` is either the mount entry
/// itself, the single-mounted shared helper, or referenced by a
/// `#[path = "..."]` mount in `tests/runner.rs` — and every mount
/// target exists on disk (both directions, zero silent dead files).
#[test]
fn runner_mounts_every_test_tree_file() {
    let tests_dir = repo_root().join("tests");
    let runner_path = tests_dir.join("runner.rs");
    let runner_src = std::fs::read_to_string(&runner_path).expect("tests/runner.rs reads");

    // The mount set: every #[path = "..."] literal in the runner.
    let mounted = mount_literals(&runner_src);
    assert!(
        !mounted.is_empty(),
        "runner.rs must carry at least one #[path] mount"
    );

    // Forward: every mounted path exists on disk.
    for rel in &mounted {
        let target = tests_dir.join(rel);
        assert!(
            target.exists(),
            "runner.rs mounts `{rel}` but the file does not exist (stale mount)"
        );
    }

    // Reverse: every .rs file in the tree is the runner, the shared
    // helper, or explicitly mounted.
    let exempt = |p: &Path| p == runner_path || p == tests_dir.join("common/mod.rs");
    for file in rust_files_under(&tests_dir) {
        if exempt(&file) {
            continue;
        }
        let rel = file
            .strip_prefix(&tests_dir)
            .expect("path under tests/")
            .to_string_lossy()
            .into_owned();
        assert!(
            mounted.contains(&rel),
            "test file `{rel}` is not mounted in tests/runner.rs — cargo will \
             never run it (silent dead file); add the #[path] mount"
        );
    }
}

/// TEST-2: the per-case table in subset_corpus_tests.rs and the corpus
/// directory carry exactly the same `.krf` file set.
#[test]
fn corpus_case_table_matches_directory_exactly() {
    let corpus_dir = repo_root().join("tests/v1/stage1/corpus");
    let harness_path = repo_root().join("tests/v1/stage1/plan/subset_corpus_tests.rs");
    let harness_src = std::fs::read_to_string(&harness_path).expect("subset_corpus_tests.rs reads");

    // The table face: every "name.krf" literal in the harness. The
    // corpus_case! macro quotes the file name as its data argument;
    // a scan over double-quoted `.krf` literals is exact here because
    // the sweep face constructs no quoted names.
    let mut table = quoted_krf_literals(&harness_src);
    assert!(!table.is_empty(), "the corpus case table must not be empty");

    // The directory face.
    let mut directory: Vec<String> = std::fs::read_dir(&corpus_dir)
        .expect("corpus directory exists")
        .filter_map(|e| e.ok())
        .map(|e| e.file_name().to_string_lossy().into_owned())
        .filter(|n| n.ends_with(".krf"))
        .collect();
    directory.sort();
    table.sort();

    let dir_set: std::collections::BTreeSet<_> = directory.iter().collect();
    let table_set: std::collections::BTreeSet<_> = table.iter().collect();

    let orphans: Vec<_> = dir_set.difference(&table_set).collect();
    let phantoms: Vec<_> = table_set.difference(&dir_set).collect();
    assert!(
        orphans.is_empty(),
        "corpus files without a `corpus_case!` table entry (the isolation face \
         lags the directory — add the per-case tests): {orphans:?}"
    );
    assert!(
        phantoms.is_empty(),
        "corpus table entries without a file on disk (phantom cases — remove \
         the entry or restore the file): {phantoms:?}"
    );
    assert_eq!(
        table.len(),
        table_set.len(),
        "the corpus table lists a file twice (dedup mismatch)"
    );
}

/// TEST-3: the audit case inventory — per-section opening-label
/// counts must equal the documented composition exactly (274 total)
/// and the headline literal must carry the same number. Sections are
/// one or two uppercase letters (AA = the Stage 2.6 C-transpilation
/// family, the first two-letter section).
#[test]
fn audit_case_inventory_matches_documented_composition() {
    let audit_path = repo_root().join("examples/audit/stage0_gate_audit_r1.rs");
    let audit_src = std::fs::read_to_string(&audit_path).expect("audit source reads");

    // The documented composition (header comment + §7.3.1 audit set):
    // sections A..Z with C and D at five cases, Z at twenty-four, R at
    // twenty, every other section at ten — 264 total (X = the Stage
    // 2.3 first-Pass family at v0.52.0; Y = the r83 emission family
    // at v0.53.0; Z = the r84 composed-chain close-out family at
    // v0.54.0 extended r86 with the 2.4 full-composed-chain family
    // (§9.87) and r88 with the 2.5 fixpoint window (§9.89 — the
    // rebuild face, the elevated gate B, and the fixpoint itself);
    // R = the r85 lexical-second-segment family doubling the reader
    // section at v0.55.0).
    let documented = documented_audit_composition();

    // The registration convention: every case opens with a whole-line
    // comment `// XNN:` or `// XNN (` — uniform since the v0.26.0
    // normalization (A-C comments added, H07 labeled, U/V widened to
    // two digits). Line-anchored so in-body assert messages that
    // mention labels cannot match.
    let observed = count_case_labels(&audit_src, &documented);

    for (section, want) in &documented {
        let got = observed.get(*section).copied().unwrap_or(0);
        assert_eq!(
            got, *want,
            "audit section {section}: {got} registered cases, documented {want} \
             (a case lost its opening `// {section}NN:` label, or the composition \
             changed without updating this guard and the header)"
        );
    }
    let total: usize = observed.values().sum();
    assert_eq!(
        total, 274,
        "audit inventory total {total} must equal the documented 274"
    );

    // The headline literal is the machine-checked twin of the count.
    assert!(
        audit_src.contains("AUDIT PASS 274/274"),
        "the audit headline literal must carry the verified total (274/274)"
    );
}

/// TEST-3b (detection-power arm, the r54 detector precedent): the
/// label counter must count exactly the canonical opening-comment
/// shapes and nothing else — a synthetic fixture with a known
/// composition, including the near-miss shapes the counter must
/// reject (in-body assert message, single-digit label, prose mention,
/// mid-line label).
#[test]
fn label_counter_detects_the_canonical_shapes() {
    let known_sections: BTreeMap<&'static str, usize> =
        [("A", 99), ("E", 99), ("AA", 99)].into_iter().collect();
    let fixture = "\
// A01: canonical colon form.
fn body_a() {}
    // E01 (canonical paren form): fixture case.
fn body_e() {}
        assert!(rendered.contains(\"I01: {rendered}\"), \"I01 near-miss\");
    // A1: single-digit near-miss (pre-normalization shape) — counted
    // since the two-letter-section relaxation (AA-style labels are
    // one digit); the pre-relaxation fixture kept the rejection.
let msg = \"A02 prose mention in a string, not a comment\";
fn inline() { /* A03: mid-line comment — rejected */ }
// Z01: unknown section letter — rejected.
// A04:nospace colon — accepted (the canonical colon, spacing-free).
// AA1 (two-letter section, paren): counted.
";
    let counted = count_case_labels(fixture, &known_sections);
    assert_eq!(
        counted.get("A"),
        Some(&3),
        "A: A01 (colon) + A1 (single digit) + A04 (nospace colon) count; A02/mid-line rejected"
    );
    assert_eq!(
        counted.get("E"),
        Some(&1),
        "E: E01 (paren) counts; the in-body I01 string does not"
    );
    assert_eq!(
        counted.get("AA"),
        Some(&1),
        "AA: the two-letter form counts"
    );
    assert!(
        !counted.contains_key("I") && !counted.contains_key("Z"),
        "unknown-section labels are not counted at all"
    );
}

/// The documented audit composition (header comment + §7.3.1): the
/// sections A..Z with C and D at five cases, Y at ten, Z at sixteen,
/// every other section at ten — 256 total (X = the Stage 2.3
/// first-Pass family v0.52.0; Y = the r83 emission family v0.53.0;
/// Z = the r84 composed-chain close-out family v0.54.0, extended
/// r86 with the 2.4 full-composed-chain family §9.87).
fn documented_audit_composition() -> BTreeMap<&'static str, usize> {
    [
        ("A", 10),
        ("B", 10),
        ("C", 5),
        ("D", 5),
        ("E", 10),
        ("F", 10),
        ("G", 10),
        ("H", 10),
        ("I", 10),
        ("J", 10),
        ("K", 10),
        ("L", 10),
        ("M", 10),
        ("N", 10),
        ("P", 10),
        ("Q", 10),
        ("R", 20),
        ("S", 10),
        ("T", 10),
        ("U", 10),
        ("V", 10),
        ("W", 10),
        ("X", 10),
        ("Y", 10),
        ("Z", 24),
        // The Stage 2.6 C-transpilation family (r91, §9.92) — the
        // first two-letter section (the section alphabet exhausted at
        // Z; AA continues the monotonic growth per §7.3.1 rule 4).
        ("AA", 10),
    ]
    .into_iter()
    .collect()
}

/// Count case-opening labels per section: whole-line comments of the
/// form `// XNN:` or `// XNN (` where X is a known section letter.
fn count_case_labels(
    src: &str,
    known_sections: &BTreeMap<&'static str, usize>,
) -> BTreeMap<&'static str, usize> {
    let mut observed: BTreeMap<&'static str, usize> = BTreeMap::new();
    for line in src.lines() {
        let trimmed = line.trim_start();
        let rest = match trimmed.strip_prefix("//") {
            Some(rest) => rest,
            None => continue,
        };
        let rest = rest.trim_start();
        // The registration grammar: one or two uppercase section
        // letters, one or two digits, then ':' or '(' — anchored so
        // prose cannot match (a `// The ...` line has no digit run).
        let bytes = rest.as_bytes();
        let mut at = 0;
        while at < bytes.len() && bytes[at].is_ascii_uppercase() && at < 2 {
            at += 1;
        }
        if at == 0 {
            continue;
        }
        let section = &rest[..at];
        let Some((static_key, _)) = known_sections.get_key_value(section) else {
            continue;
        };
        let digit_start = at;
        while at < bytes.len() && bytes[at].is_ascii_digit() && at < digit_start + 2 {
            at += 1;
        }
        if at == digit_start {
            continue;
        }
        let after = rest[at..].trim_start();
        if after.starts_with(':') || after.starts_with('(') {
            *observed.entry(*static_key).or_insert(0) += 1;
        }
    }
    observed
}

/// Every `#[path = "..."]` attribute literal in `src` (no regex
/// dependency — SOP §18 zero-new-deps). Matching is anchored on the
/// `#[path =` opener so prose mentions of `#[path]` in doc comments
/// cannot match.
fn mount_literals(src: &str) -> Vec<String> {
    let mut out = Vec::new();
    let mut rest = src;
    while let Some(at) = rest.find("#[path =") {
        rest = &rest[at + "#[path =".len()..];
        let open = match rest.find('"') {
            Some(i) => i,
            None => break,
        };
        let after_open = &rest[open + 1..];
        let close = match after_open.find('"') {
            Some(i) => i,
            None => break,
        };
        out.push(after_open[..close].to_string());
        rest = &after_open[close + 1..];
    }
    out
}

/// Every double-quoted string literal in `src` that names a corpus
/// case (ends in `.krf` and carries a stem — the bare `".krf"` suffix
/// probe inside the harness itself is not a case name).
fn quoted_krf_literals(src: &str) -> Vec<String> {
    let mut out = Vec::new();
    let mut rest = src;
    while let Some(open) = rest.find('"') {
        let after_open = &rest[open + 1..];
        let close = match after_open.find('"') {
            Some(i) => i,
            None => break,
        };
        let lit = &after_open[..close];
        if lit.ends_with(".krf") && lit.len() > ".krf".len() {
            out.push(lit.to_string());
        }
        rest = &after_open[close + 1..];
    }
    out
}

// ---------- TEST-4: no cross-crate forwarding re-exports (v0.28.0, §9.59) ----------

/// Extract `pub use kerf_...` forwarding lines from one source file,
/// skipping comment lines (a `//`-prefixed line never re-exports).
fn forwarding_reexports(src: &str) -> Vec<String> {
    src.lines()
        .map(str::trim_start)
        .filter(|line| !line.starts_with("//"))
        .filter(|line| {
            line.starts_with("pub use kerf_") || line.starts_with("pub (crate) use kerf_")
        })
        .map(str::to_owned)
        .collect()
}

#[test]
fn pipeline_crates_forward_nothing_from_other_crates() {
    // The no-forwarding rule (stage0.md §9.59, SOP §18.5 v15.2): a
    // pipeline crate exports only what it defines. Types that appear
    // in a crate's public API but live elsewhere (Span/Symbol from
    // kerf-span, the core AST family from kerf-core) are imported by
    // consumers directly from the defining crate — the rustc_ast
    // precedent (rustc_span is a direct dependency of every consumer
    // crate and rustc_ast re-exports nothing from it, §9.59 K81).
    let crates_dir = repo_root().join("crates");
    let mut offenders: Vec<String> = Vec::new();
    let mut scanned = 0usize;
    for path in rust_files_under(&crates_dir) {
        let src = std::fs::read_to_string(&path).expect("crate source reads");
        scanned += 1;
        for line in forwarding_reexports(&src) {
            offenders.push(format!("{}: {line}", path.display()));
        }
    }
    assert!(
        offenders.is_empty(),
        "cross-crate forwarding re-exports found (stage0.md §9.59 — import \
         from the defining crate instead):\n{}",
        offenders.join("\n")
    );
    assert!(
        scanned >= 10,
        "expected to scan all ten crates, saw {scanned}"
    );
}

#[test]
fn root_facade_aliases_whole_crates_but_forwards_no_types() {
    // The root aggregation crate (src/lib.rs, SOP §8.4.6 rule 7) is the
    // one sanctioned facade: it re-exports whole member crates under
    // namespace aliases (`pub use kerf_span as span`). The two-tier
    // rule: crate-level aliases are its designed aggregation content;
    // type-level passthrough (`pub use kerf_x::Type`) is forbidden
    // exactly as inside the pipeline crates.
    let facade = repo_root().join("src/lib.rs");
    let src = std::fs::read_to_string(&facade).expect("facade source reads");
    for line in forwarding_reexports(&src) {
        // Allow only the whole-crate alias shape: `pub use kerf_x as y;`
        let is_alias = line.starts_with("pub use kerf_")
            && line.contains(" as ")
            && line.trim_end().ends_with(';')
            && !line.contains("::");
        assert!(
            is_alias,
            "type-level forwarding in the root facade is forbidden \
             (whole-crate aliases only, SOP §8.4.6): {line}"
        );
    }
}

#[test]
fn forwarding_detector_detects_and_spares_correctly() {
    // The detection-power arm (the r54/r34 three-arm precedent): the
    // scanner must catch every forwarding shape and spare every
    // legitimate own-module export.
    // The detector is strictly line-level: it also flags the whole-crate
    // alias shape (`pub use kerf_span as span;`) — the facade exemption
    // is applied by the caller (the root-facade two-tier check above),
    // not by the detector. Development true-positive: the first run of
    // this arm caught the alias listed as should-spare here — the fixture
    // was wrong, the detector was right (the TEST-2 precedent).
    let should_flag = [
        "pub use kerf_span::Span;",
        "pub use kerf_core::{ModuleItem, CoreExpr};",
        "    pub use kerf_compiler::Symbol;",
        "pub (crate) use kerf_span::{ByteOffset, FileId};",
        "pub use kerf_span as span;",
    ];
    for line in should_flag {
        assert_eq!(
            forwarding_reexports(line),
            vec![line.trim_start().to_owned()],
            "detector must flag: {line}"
        );
    }
    let should_spare = [
        "pub use error::CoreError;",
        "pub use expr::{StxDatum, SyntaxObject};",
        "// pub use kerf_span::Span; (historical note)",
        "/// doc mention: pub use kerf_core::ModuleItem",
        "use kerf_span::Symbol;",
        "pub use crate::error::ReadError;",
    ];
    for line in should_spare {
        assert!(
            forwarding_reexports(line).is_empty(),
            "detector must spare: {line}"
        );
    }
}

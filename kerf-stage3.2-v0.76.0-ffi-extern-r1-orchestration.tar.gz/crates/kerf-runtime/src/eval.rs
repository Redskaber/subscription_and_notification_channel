//! The meta-circular evaluator (docs/stage0.md §5.1, §21.8 Phase 1) —
//! Layer 7's direct interpreter over CoreExpr.
//!
//! The evaluator is one half of the dual-execution-path cross-check
//! (stage-0-plan §5 row 0.7): the same expanded program runs through
//! `compile → VM` and through `eval`, and the results must agree —
//! a divergence is a P1 line stop (§21.11 risk 5). Every semantic
//! decision here MIRRORS the compiler/VM pair, never invents:
//!
//! * name resolution — innermost binding wins via a tail-first scan
//!   (`Compiler::lookup_local` verbatim); unbound names fall back to
//!   the global table, reads fail `UnboundGlobal`, writes (assign)
//!   store blind (`StoreGlobal` semantics);
//! * evaluation order — arguments left to right, then the callee
//!   (§19.3 emission order, the 0.5 compiler authoritative);
//! * closures — the "basic closure" P0 scope: free lexical names
//!   compile to globals, so the captured env is a DORMANT value
//!   snapshot (0.6 `ClosureData` duality); lexical capture is a
//!   Stage 1 activation on BOTH engines;
//! * budget — the same frames-plus-live-cells account (`depth` is
//!   the evaluator's frame count); exhaustion runs one collect-
//!   then-retry cycle (§19.4 alloc skeleton) before failing closed;
//! * builtins — the 18 STAGE0_GLOBALS dispatch through the shared
//!   kerf-vm functions (single source, zero drift by construction).
//!
//! Rust-stack guards: the evaluator recurses in Rust (the VM keeps
//! frames on the heap — the TD-023 anchor does not apply here), so
//! [`EVAL_DEPTH_LIMIT`] caps the kerf call depth and `reserve`
//! protects in-flight intermediates through the root-protected
//! `temp` stack (the §19.4 "explicit C-stack roots" spelled for a
//! Rust evaluator).

use std::collections::HashMap;
use std::rc::Rc;

use kerf_core::{CoreExpr, ModuleItem};
use kerf_span::{ByteOffset, ExpansionId, FileId, Span, Symbol};
use kerf_vm::{
    Builtin, BuiltinHost, ClosureData, Heap, HeapObj, HeapRef, Roots, RuntimeError, Value, VmIo,
    builtin_symbol, demanded, dispatch_builtin,
};

use crate::gc::{self, GcStats};

/// A well-formed empty span for the entry charge of an empty
/// program (the compiler's `last_span` initialization duality).
fn zero_span() -> Span {
    Span::new(FileId(0), ByteOffset(0), ByteOffset(0), ExpansionId::ROOT)
        .expect("empty span is well-formed")
}

/// The `proto` field of evaluator-made closures: no bytecode exists
/// on this path, so the sentinel is the registry's type tag. It can
/// never collide with a VM proto index (a func table that large is
/// unreachable under any budget).
pub const EVAL_CLOSURE_PROTO: u32 = u32::MAX;

/// The kerf call-depth cap (a Rust-stack guard — the evaluator
/// recurses in host frames while the VM grows a heap frame vector;
/// programs needing more depth than this run on the VM path).
pub const EVAL_DEPTH_LIMIT: u32 = 2048;

/// One evaluator-made closure: params/body live in the Rust-side
/// registry, the heap cell carries identity (and the flat capture
/// area — values in descriptor-like order, LA-5).
#[derive(Debug, Clone)]
struct EvalClosure {
    /// The `define` name when the closure came from a named fn (the
    /// ArityMismatch payload face — `Compiler::compile_fn(Some(name))`;
    /// §9.67 NB-4: the identity rides the single pool).
    name: Option<Symbol>,
    params: Vec<Symbol>,
    body: Rc<CoreExpr>,
    /// The captured names, in capture order (the values live in the
    /// heap cell's env — the GC-traced flat-closure carrier; the
    /// registry holds names only, never unrooted values). Rebuilt
    /// into the invoked frame's `Env.captured` by zipping with the
    /// cell's env at entry (LA-5).
    captured_names: Vec<Symbol>,
}

/// The frame-slot environment (the compiler's scope model at run
/// time): `names` is every binding site in push order, `locals` the
/// slot values; resolution scans `names` tail-first (innermost
/// binding wins — `Compiler::lookup_local` verbatim). §9.67 NB-2:
/// binding sites carry pool entries — a 4-byte comparison per scan
/// step, zero allocation per binding (params and `let`s clone the
/// `Symbol` they already hold).
///
/// Stage 2.1 LA-5: `captured` is the closure's capture area — the
/// values its body's free names resolved to at creation time (the
/// K45 minimal-capture-set mirror of the compiler's descriptor
/// analysis). Resolution order mirrors the compiler exactly: own
/// bindings first, then the captured region, then globals; assigns
/// stop at the captured region (immutable-capture subset, LA-7).
#[derive(Debug, Clone, Default)]
struct Env {
    names: Vec<(Symbol, usize)>,
    locals: Vec<Value>,
    captured: Vec<(Symbol, Value)>,
}

impl Env {
    /// A closure body environment: params occupy slots 0..n.
    fn from_params(params: &[Symbol]) -> Self {
        Env {
            names: params
                .iter()
                .enumerate()
                .map(|(i, p)| (p.clone(), i))
                .collect(),
            locals: Vec::new(),
            captured: Vec::new(),
        }
    }

    /// Resolve a name to its slot (innermost binding wins).
    fn resolve(&self, name: &Symbol) -> Option<usize> {
        self.names
            .iter()
            .rev()
            .find(|(n, _)| n == name)
            .map(|(_, s)| *s)
    }

    /// Resolve a name in the captured region (LA-5 — the
    /// `load-captured` mirror).
    fn resolve_captured(&self, name: &Symbol) -> Option<&Value> {
        self.captured
            .iter()
            .rev()
            .find(|(n, _)| n == name)
            .map(|(_, v)| v)
    }
}

/// The free-name analysis of one closure body (Stage 2.1 LA-4/LA-5 —
/// the Steensgaard flat-closure walk internalized): every name the
/// body can reference that no binder inside the body (or among the
/// params, pre-seeded into `bound`) captures, in first-encounter
/// order — the deterministic order the captured pairs land in.
/// `Assign` targets count as references: the LA-7 boundary needs the
/// target captured for the store to be rejectable at invoke time
/// (the outer scope is gone by then).
fn free_names(expr: &CoreExpr, bound: &mut Vec<Symbol>, out: &mut Vec<Symbol>) {
    let reference = |name: &Symbol, out: &mut Vec<Symbol>| {
        if !bound.iter().any(|n| n == name) && !out.iter().any(|n| n == name) {
            out.push(name.clone());
        }
    };
    match expr {
        CoreExpr::Literal { .. } => {}
        CoreExpr::Var { name, .. } => reference(name, out),
        CoreExpr::Fn { params, body, .. } => {
            let mark = bound.len();
            bound.extend(params.iter().cloned());
            free_names(body, bound, out);
            bound.truncate(mark);
        }
        CoreExpr::Apply { func, args, .. } => {
            free_names(func, bound, out);
            for arg in args {
                free_names(arg, bound, out);
            }
        }
        CoreExpr::If {
            cond,
            then_branch,
            else_branch,
            ..
        } => {
            free_names(cond, bound, out);
            free_names(then_branch, bound, out);
            free_names(else_branch, bound, out);
        }
        CoreExpr::Assign { name, value, .. } => {
            reference(name, out);
            free_names(value, bound, out);
        }
        CoreExpr::Let { bindings, body, .. } => {
            let mark = bound.len();
            for binding in bindings {
                free_names(&binding.value, bound, out);
                bound.push(binding.name.clone());
            }
            free_names(body, bound, out);
            bound.truncate(mark);
        }
        CoreExpr::Perform { args, .. } => {
            for arg in args {
                free_names(arg, bound, out);
            }
        }
        CoreExpr::Handle { body, handlers, .. } => {
            free_names(body, bound, out);
            for clause in handlers {
                free_names(&clause.handler, bound, out);
            }
        }
    }
}

/// The meta-circular evaluator.
pub struct Evaluator {
    heap: Heap,
    /// The global table, keyed by interned identity (§9.67 NB-1:
    /// every Var fallback and every define/assign stores reads the
    /// 4-byte pool entry — a text de-intern used to ride every
    /// binding site and a string hash every global reference).
    globals: HashMap<Symbol, Value>,
    /// The extern contract names seen in the item walk (W-3.2): an
    /// unbound reference to one of these is the extern boundary, not
    /// a typo — the diagnostic names the contract.
    extern_names: std::collections::HashSet<Symbol>,
    /// Evaluator-made closures by heap reference (identity registry;
    /// dead entries drop at each cycle).
    closures: HashMap<HeapRef, EvalClosure>,
    /// Installed handlers, innermost last (`PushHandler`/`PopHandler`
    /// duality; `perform` scans tail-first for the nearest match —
    /// §9.67 NB-3: effect identities are pool entries).
    handlers: Vec<(Symbol, Value)>,
    /// The current lexical environment (swapped at closure entry).
    env: Env,
    /// Root-protected in-flight intermediates (the §19.4 explicit
    /// roots of the Rust stack between argument evaluation and call).
    temp: Vec<Value>,
    io: Box<dyn VmIo>,
    budget: u32,
    /// Cumulative allocations (the VM-compatible public face).
    allocs: u32,
    /// The kerf call depth (the frame-count half of live usage).
    depth: u32,
    /// Automatic collect-then-retry cycles run so far.
    cycles: u32,
}

impl Default for Evaluator {
    fn default() -> Self {
        Self::new()
    }
}

impl Evaluator {
    /// A default evaluator: buffered I/O, the default budget, the 18
    /// STAGE0_GLOBALS builtins seeded (the VM's `Vm::build` duality).
    pub fn new() -> Self {
        Evaluator::build(kerf_vm::DEFAULT_BUDGET, Box::new(kerf_vm::BufferIo::new()))
    }

    /// Build with a custom I/O face.
    pub fn with_io(io: Box<dyn VmIo>) -> Self {
        Evaluator::build(kerf_vm::DEFAULT_BUDGET, io)
    }

    /// Build with a custom allocation budget (tests and hosts).
    pub fn with_budget(budget: u32) -> Self {
        Evaluator::build(budget, Box::new(kerf_vm::BufferIo::new()))
    }

    fn build(budget: u32, io: Box<dyn VmIo>) -> Self {
        let mut globals = HashMap::new();
        for (builtin, _, _) in Builtin::ALL {
            globals.insert(builtin_symbol(builtin), Value::Builtin(builtin));
        }
        Evaluator {
            heap: Heap::default(),
            globals,
            extern_names: std::collections::HashSet::new(),
            closures: HashMap::new(),
            handlers: Vec::new(),
            env: Env::default(),
            temp: Vec::new(),
            io,
            budget,
            allocs: 0,
            depth: 0,
            cycles: 0,
        }
    }

    // ---------- observation faces ----------

    /// Look a global up by name (the parity observation face; unbound
    /// names and builtins are both visible here — §9.67 NB-7: the
    /// text face stays a linear scan so a miss query never pollutes
    /// the interning pool).
    pub fn global(&self, name: &str) -> Option<&Value> {
        self.globals
            .iter()
            .find(|(s, _)| s.as_str() == name)
            .map(|(_, v)| v)
    }

    /// Look a global up by its interned identity (§9.67 NB-7 — the
    /// hot face and the driver's snapshot face: `Var` fallback and
    /// `Define` roster reads ride the 4-byte hash).
    pub fn global_sym(&self, name: &Symbol) -> Option<&Value> {
        self.globals.get(name)
    }

    /// The object heap (structure inspection for tests and hosts).
    pub fn heap(&self) -> &Heap {
        &self.heap
    }

    /// Cumulative allocations so far (frames + cells; the VM face).
    pub fn allocations(&self) -> u32 {
        self.allocs
    }

    /// Automatic collect-then-retry cycles run so far.
    pub fn collector_cycles(&self) -> u32 {
        self.cycles
    }

    /// Drain recorded output lines.
    pub fn take_output(&mut self) -> Vec<String> {
        self.io.take_output()
    }

    // ---------- program entry ----------

    /// Evaluate a declaration sequence (the `compile_program`
    /// duality): every define binds a global; the program value is
    /// `nil` (the depth-0 halt of a declaration-only product).
    pub fn eval_program(&mut self, items: &[ModuleItem]) -> Result<Value, RuntimeError> {
        let entry_span = items.first().map(|i| i.span()).unwrap_or_else(zero_span);
        self.env = Env::default(); // program isolation: no lexical residue
        self.reserve(entry_span)?; // the entry frame
        self.depth = 1;
        let result = self.eval_items(items);
        self.depth = 0;
        result?;
        Ok(Value::Nil)
    }

    /// Evaluate one expression at top level (an empty environment —
    /// the `compile(expr)` duality).
    pub fn eval_expr(&mut self, expr: &CoreExpr) -> Result<Value, RuntimeError> {
        self.env = Env::default(); // expression isolation: no lexical residue
        self.reserve(expr.span())?; // the entry frame
        self.depth = 1;
        let result = self.eval(expr);
        self.depth = 0;
        result
    }

    fn eval_items(&mut self, items: &[ModuleItem]) -> Result<(), RuntimeError> {
        for item in items {
            match item {
                ModuleItem::Define { name, value, .. } => {
                    let v = match value {
                        // A named fn defines its closure's diagnostic
                        // name (compile_fn(Some(name)) duality).
                        CoreExpr::Fn { params, body, .. } => {
                            self.make_closure(Some(name), params, body, value.span())?
                        }
                        _ => self.eval(value)?,
                    };
                    self.globals.insert(name.clone(), v);
                }
                ModuleItem::Require { .. } => {
                    // Zero code: linking is deferred to load time
                    // (§19.3 trap 3 — Stage 0 single-module runs).
                }
                ModuleItem::DefineSyntax { .. } => {
                    // Zero code: the transformer lives in the expansion
                    // environment (sub-stage 0.9 — the `Require`
                    // zero-code precedent applied to the macro phase).
                }
                ModuleItem::Module { items, .. } => {
                    // Recursive flat evaluation; proper scope homes
                    // arrive with the 0.9 module system.
                    self.eval_items(items)?;
                }
                ModuleItem::Extern { items, .. } => {
                    // Zero code (W-3.2): the declaration records the
                    // contract names for the boundary diagnostic.
                    for entry in items {
                        self.extern_names.insert(entry.name.clone());
                    }
                }
            }
        }
        Ok(())
    }

    // ---------- the expression interpreter ----------

    fn eval(&mut self, expr: &CoreExpr) -> Result<Value, RuntimeError> {
        match expr {
            CoreExpr::Literal { span, value } => {
                // §9.69.3 EXC-1/EXC-2: the cell count is the
                // single-sourced `LiteralValue::pair_cells`
                // (kerf-core — the VM's materialize budgets against
                // the same method), and the charge is one
                // `reserve_exact` batch instead of a per-cell loop.
                self.reserve_exact(value.pair_cells() as u32, *span)?;
                Ok(Value::from_literal(value, &mut self.heap))
            }
            CoreExpr::Var { span, name } => {
                if let Some(slot) = self.env.resolve(name) {
                    Ok(self.env.locals[slot].clone())
                } else if let Some(v) = self.env.resolve_captured(name) {
                    // Stage 2.1 LA-5: the capture-area read (the
                    // `load-captured` mirror — MIRRORS, never invents).
                    Ok(v.clone())
                } else {
                    match self.globals.get(name) {
                        Some(v) => Ok(v.clone()),
                        None if self.extern_names.contains(name) => {
                            Err(RuntimeError::ExternCallRequiresBackend {
                                name: name.clone(),
                                span: *span,
                            })
                        }
                        None => Err(RuntimeError::UnboundGlobal {
                            name: name.clone(),
                            span: *span,
                        }),
                    }
                }
            }
            CoreExpr::Fn { span, params, body } => self.make_closure(None, params, body, *span),
            CoreExpr::Apply { span, func, args } => {
                // §19.3 order: args left to right, then the callee.
                let guard = self.temp.len();
                let mut argv = Vec::with_capacity(args.len());
                for arg in args {
                    let v = self.eval(arg)?;
                    self.temp.push(v.clone());
                    argv.push(v);
                }
                let callee = self.eval(func)?;
                self.temp.push(callee.clone());
                let result = self.invoke(callee, argv, *span);
                self.temp.truncate(guard);
                result
            }
            CoreExpr::If {
                cond,
                then_branch,
                else_branch,
                ..
            } => {
                let v = self.eval(cond)?;
                match v {
                    Value::Bool(true) => self.eval(then_branch),
                    Value::Bool(false) => self.eval(else_branch),
                    other => Err(kerf_vm::RuntimeError::TypeMismatch {
                        context: "jump-if-false condition",
                        demanded: demanded::BOOL,
                        got: other.kind_name(),
                        span: cond.span(),
                    }),
                }
            }
            CoreExpr::Assign {
                span, name, value, ..
            } => {
                let v = self.eval(value)?;
                if let Some(slot) = self.env.resolve(name) {
                    self.env.locals[slot] = v.clone();
                } else if self.env.resolve_captured(name).is_some() {
                    // Stage 2.1 LA-7: the immutable-capture subset —
                    // the assign-to-captured boundary mirrors the
                    // compiler's rejection exactly (the free-name
                    // analysis captures the target, so the boundary
                    // is decidable here without the outer scope).
                    return Err(RuntimeError::AssignToCaptured {
                        name: name.clone(),
                        span: *span,
                    });
                } else {
                    self.globals.insert(name.clone(), v.clone());
                }
                Ok(v)
            }
            CoreExpr::Let { bindings, body, .. } => {
                // let* semantics: binding i sees slots 0..i-1; the
                // mark/truncate pair is `locals_mark`/`locals_truncate`.
                let mark_names = self.env.names.len();
                let mark_locals = self.env.locals.len();
                for binding in bindings {
                    let v = self.eval(&binding.value)?;
                    let slot = self.env.locals.len();
                    self.env.names.push((binding.name.clone(), slot));
                    self.env.locals.push(v);
                }
                let result = self.eval(body);
                self.env.names.truncate(mark_names);
                self.env.locals.truncate(mark_locals);
                result
            }
            CoreExpr::Perform { span, effect, args } => {
                let guard = self.temp.len();
                let mut argv = Vec::with_capacity(args.len());
                for arg in args {
                    let v = self.eval(arg)?;
                    self.temp.push(v.clone());
                    argv.push(v);
                }
                let result = match self.handlers.iter().rposition(|(e, _)| e == effect) {
                    Some(idx) => {
                        let handler = self.handlers[idx].1.clone();
                        self.invoke(handler, argv, *span)
                    }
                    None => Err(RuntimeError::UnhandledEffect {
                        effect: effect.clone(),
                        span: *span,
                    }),
                };
                self.temp.truncate(guard);
                result
            }
            CoreExpr::Handle { body, handlers, .. } => {
                // Handler values are evaluated at installation, then
                // the body runs with them installed, then all pop
                // (PopHandler n duality — plan-0.5 decision 8).
                for clause in handlers {
                    let v = self.eval(&clause.handler)?;
                    self.handlers.push((clause.effect.clone(), v));
                }
                let result = self.eval(body);
                let n = handlers.len();
                let keep = self.handlers.len() - n;
                self.handlers.truncate(keep);
                result
            }
        }
    }

    // ---------- closures and calls ----------

    fn make_closure(
        &mut self,
        name: Option<&Symbol>,
        params: &[Symbol],
        body: &CoreExpr,
        span: Span,
    ) -> Result<Value, RuntimeError> {
        // Stage 2.1 LA-5: capture exactly the body's free names that
        // resolve in the current environment — the K45 minimal-set
        // mirror of the compiler's descriptor analysis (a name bound
        // neither here nor in the captured region is a global
        // reference and stays uncaptured). Assign targets count as
        // references: the LA-7 boundary needs the name captured to
        // reject the store without the (gone) outer scope.
        let mut free: Vec<Symbol> = Vec::new();
        let mut bound: Vec<Symbol> = params.to_vec();
        free_names(body, &mut bound, &mut free);
        let mut captured_names: Vec<Symbol> = Vec::new();
        let mut values: Vec<Value> = Vec::new();
        for n in free {
            if let Some(slot) = self.env.resolve(&n) {
                captured_names.push(n);
                values.push(self.env.locals[slot].clone());
            } else if let Some(v) = self.env.resolve_captured(&n) {
                captured_names.push(n);
                values.push(v.clone());
            }
        }
        // Root the in-flight captured values across the reserve (a
        // collect-then-retry cycle must not sweep them before the
        // closure cell exists — the §19.4 explicit-roots class).
        // Stage 3.1 W-3.1 blade: the env rides as a shared-immutable
        // Rc — the SAME representation the VM engine installs by
        // refcount bump (the ClosureData duality keeps one shape).
        let guard = self.temp.len();
        self.temp.extend(values.iter().cloned());
        self.reserve(span)?; // the closure cell (Closure duality)
        let r = self.heap.alloc(HeapObj::Closure(ClosureData {
            proto: EVAL_CLOSURE_PROTO,
            env: Rc::new(values),
        }));
        self.temp.truncate(guard);
        self.closures.insert(
            r,
            EvalClosure {
                name: name.cloned(),
                params: params.to_vec(),
                body: Rc::new(body.clone()),
                captured_names,
            },
        );
        Ok(Value::Closure(r))
    }

    /// Invoke a callable with evaluated args (the `Vm::invoke`
    /// duality shared by `apply` and `perform`'s handler call).
    /// Callers protect `callee` and `args` on the temp root stack —
    /// this function reserves (frames, `cons`), so the values it
    /// received must be reachable from the roots.
    fn invoke(
        &mut self,
        callee: Value,
        args: Vec<Value>,
        span: Span,
    ) -> Result<Value, RuntimeError> {
        match callee {
            Value::Closure(r) => {
                let closure = self
                    .closures
                    .get(&r)
                    .cloned()
                    .expect("evaluator closures are registry-paired with their cells");
                if args.len() != closure.params.len() {
                    return Err(RuntimeError::ArityMismatch {
                        func: closure.name.clone(),
                        expected: closure.params.len() as u32,
                        actual: args.len() as u32,
                        span,
                    });
                }
                self.reserve(span)?; // the callee frame (push_frame duality)
                self.depth += 1;
                if self.depth > EVAL_DEPTH_LIMIT {
                    self.depth -= 1;
                    return Err(RuntimeError::EvalDepthExceeded {
                        limit: EVAL_DEPTH_LIMIT,
                        span,
                    });
                }
                let saved = std::mem::replace(&mut self.env, Env::from_params(&closure.params));
                // The swapped-out environment lives on the Rust stack
                // for the whole body — root-protect its locals AND its
                // captured values (the §19.4 explicit-roots class of an
                // evaluator frame; missing either reclaims in-flight
                // callers' values).
                let guard = self.temp.len();
                self.temp.extend(saved.locals.iter().cloned());
                self.temp
                    .extend(saved.captured.iter().map(|(_, v)| v.clone()));
                // Stage 2.1 LA-5: install the captured region — the
                // closure cell's env is the capture area (descriptor-
                // like order); zipping it with the registry's names
                // rebuilds the frame environment.
                let cell = self
                    .heap
                    .get(r)
                    .map(|obj| match obj {
                        HeapObj::Closure(d) => Rc::clone(&d.env),
                        _ => Rc::default(),
                    })
                    .unwrap_or_default();
                self.env.captured = closure
                    .captured_names
                    .iter()
                    .cloned()
                    .zip(cell.iter().cloned())
                    .collect();
                self.env.locals = args;
                let result = self.eval(&closure.body);
                self.temp.truncate(guard);
                self.env = saved;
                self.depth -= 1;
                result
            }
            Value::Builtin(b) => {
                // §9.73 EVL-1/EVL-2: the arity check and the routing
                // live in the single-source `dispatch_builtin` — the
                // SAME function the VM enters (twin dispatch retired).
                dispatch_builtin(self, b, args, span)
            }
            other => Err(RuntimeError::TypeMismatch {
                context: "call callee",
                demanded: demanded::CALLABLE,
                got: other.kind_name(),
                span,
            }),
        }
    }

    // ---------- the §19.4 safety point ----------

    /// Count one allocation (the `Vm::reserve` duality): the LIVE
    /// footprint (depth + live cells) checks against the budget; on
    /// exhaustion one collect-then-retry cycle runs before the
    /// fail-closed error.
    fn reserve(&mut self, span: Span) -> Result<(), RuntimeError> {
        if self.live_usage() < self.budget {
            self.allocs += 1;
            return Ok(());
        }
        self.collect_now();
        if self.live_usage() < self.budget {
            self.allocs += 1;
            return Ok(());
        }
        Err(RuntimeError::BudgetExceeded {
            budget: self.budget,
            span,
        })
    }

    /// Count `n` allocations in one budget check (§9.69.3 EXC-2 —
    /// the VM's `reserve_exact` twin). The per-cell loop this
    /// replaces performed `n` identical checks: live usage only
    /// moves when `heap.alloc` runs in the `from_literal` walk that
    /// follows, so one check under the same condition is
    /// behavior-identical (accept/reject boundary, retry point, and
    /// success-path `allocs` total all match).
    fn reserve_exact(&mut self, n: u32, span: Span) -> Result<(), RuntimeError> {
        if n == 0 {
            return Ok(());
        }
        if self.live_usage() < self.budget {
            self.allocs += n;
            return Ok(());
        }
        self.collect_now();
        if self.live_usage() < self.budget {
            self.allocs += n;
            return Ok(());
        }
        Err(RuntimeError::BudgetExceeded {
            budget: self.budget,
            span,
        })
    }

    fn live_usage(&self) -> u32 {
        self.depth + self.heap.live_len() as u32
    }

    /// Run one explicit cycle (roots: the current locals, every
    /// global, every installed handler, every protected temp — the
    /// §19.4 completeness classes of an evaluator state).
    ///
    /// Determinism note (stage0.md §9.55.4): the root list order
    /// (including the HashMap-ordered globals slice) only varies the
    /// mark *visitation sequence*; the marked set is the reachability
    /// fixpoint and sweep rebuilds the free list in slot-index order,
    /// so collection stays run-to-run deterministic.
    pub fn collect_now(&mut self) -> GcStats {
        let roots = Roots {
            stack: Vec::new(),
            // The current env's captured region is frame-adjacent
            // live state (the LA-5 mirror of the VM's frame capture
            // areas joining the roots — §19.4 completeness).
            locals: self
                .env
                .locals
                .iter()
                .chain(self.env.captured.iter().map(|(_, v)| v))
                .cloned()
                .collect(),
            globals: self.globals.values().cloned().collect(),
            foreign: self.temp.clone(),
            handlers: self.handlers.iter().map(|(_, v)| v.clone()).collect(),
        };
        let stats = gc::collect(&mut self.heap, &roots);
        self.cycles += 1;
        // Drop registry entries of swept closure cells (dead identity).
        self.closures.retain(|r, _| self.heap.is_live(*r));
        stats
    }
}

impl BuiltinHost for Evaluator {
    /// The depth + live-cells budget (§19.4 — the evaluator's safety
    /// point semantics stay engine-local).
    fn charge(&mut self, span: Span) -> Result<(), RuntimeError> {
        self.reserve(span)
    }

    fn io_mut(&mut self) -> &mut dyn VmIo {
        self.io.as_mut()
    }

    fn heap_mut(&mut self) -> &mut Heap {
        &mut self.heap
    }

    fn heap(&self) -> &Heap {
        &self.heap
    }
}

#[cfg(test)]
mod tests {
    //! Evaluator tests (FP2): primitive-by-primitive positives and the
    //! error family over hand-built CoreExpr (the kerf-vm api_tests
    //! fixture precedent — source-level pipelines live in the root
    //! integration tree).

    use super::*;
    use kerf_core::{Binding, HandlerClause, LiteralValue};

    /// Cases that drive the native eval recursion to the documented
    /// `EVAL_DEPTH_LIMIT` (2048) consume more stack than the default
    /// 8 MiB test-thread budget on this toolchain (measured between
    /// 8 and 12 MiB; the r74 BST-1 lineage applied to the unit face,
    /// r83). Virtual stack pages are demand-allocated, so the large
    /// hint costs nothing.
    fn deep_stack<F>(body: F)
    where
        F: FnOnce() + Send + 'static,
    {
        std::thread::Builder::new()
            .stack_size(64 * 1024 * 1024)
            .spawn(body)
            .expect("spawn the deep-stack thread")
            .join()
            .expect("the deep-stack thread finished cleanly");
    }

    fn fix_span() -> Span {
        zero_span()
    }

    fn lit(v: LiteralValue) -> CoreExpr {
        CoreExpr::Literal {
            span: fix_span(),
            value: v,
        }
    }

    fn int(n: i64) -> CoreExpr {
        lit(LiteralValue::Int(n))
    }

    fn var(name: &str) -> CoreExpr {
        CoreExpr::var(fix_span(), name).expect("fixture var")
    }

    fn app(func: CoreExpr, args: Vec<CoreExpr>) -> CoreExpr {
        CoreExpr::Apply {
            span: fix_span(),
            func: Box::new(func),
            args,
        }
    }

    fn call(name: &str, args: Vec<CoreExpr>) -> CoreExpr {
        app(var(name), args)
    }

    fn if_(cond: CoreExpr, then: CoreExpr, else_: CoreExpr) -> CoreExpr {
        CoreExpr::If {
            span: fix_span(),
            cond: Box::new(cond),
            then_branch: Box::new(then),
            else_branch: Box::new(else_),
        }
    }

    fn let_(bindings: Vec<(&str, CoreExpr)>, body: CoreExpr) -> CoreExpr {
        CoreExpr::Let {
            span: fix_span(),
            bindings: bindings
                .into_iter()
                .map(|(n, v)| Binding::new(fix_span(), n, v).expect("fixture binding"))
                .collect(),
            body: Box::new(body),
        }
    }

    fn fn_(params: &[&str], body: CoreExpr) -> CoreExpr {
        CoreExpr::fn_(fix_span(), params, body).expect("fixture fn")
    }

    fn define(name: &str, value: CoreExpr) -> ModuleItem {
        ModuleItem::define(fix_span(), name, value).expect("fixture define")
    }

    // ---------- positives ----------

    #[test]
    fn seeds_builtins_and_evaluates_primitives() {
        let mut ev = Evaluator::new();
        // All 18 STAGE0_GLOBALS seeded (the Vm::build duality).
        for (_, name, _) in Builtin::ALL {
            assert!(
                matches!(ev.global(name), Some(Value::Builtin(_))),
                "builtin {name} must be seeded"
            );
        }
        // if / let / var / assign over eval_expr.
        let expr = let_(
            vec![("a", int(1)), ("b", int(2))],
            if_(
                call("<", vec![var("a"), var("b")]),
                call("+", vec![var("a"), var("b")]),
                int(0),
            ),
        );
        assert_eq!(ev.eval_expr(&expr).expect("primitives run"), Value::Int(3));
        // Shadowing: the inner binding wins, the outer survives.
        let shadow = let_(vec![("x", int(1))], let_(vec![("x", int(2))], var("x")));
        assert_eq!(ev.eval_expr(&shadow).expect("shadow runs"), Value::Int(2));
    }

    #[test]
    fn closures_apply_and_effects_nearest_match() {
        let mut ev = Evaluator::new();
        // A named closure: define -> call -> recursion (fib 10).
        let fib = fn_(
            &["n"],
            if_(
                call("<", vec![var("n"), int(2)]),
                var("n"),
                call(
                    "+",
                    vec![
                        call("fib", vec![call("-", vec![var("n"), int(1)])]),
                        call("fib", vec![call("-", vec![var("n"), int(2)])]),
                    ],
                ),
            ),
        );
        ev.eval_program(&[define("fib", fib), define("r", call("fib", vec![int(10)]))])
            .expect("fib runs");
        assert_eq!(ev.global("r"), Some(&Value::Int(55)));

        // perform -> nearest handler (rposition duality); require is
        // a no-op and module items flatten.
        let handler = fn_(&["v"], call("*", vec![var("v"), int(10)]));
        // perform with no args through a handle clause.
        let handled = CoreExpr::handle(
            fix_span(),
            CoreExpr::perform(fix_span(), "log", vec![int(4)]).expect("fixture perform"),
            vec![HandlerClause::new(fix_span(), "log", handler).expect("fixture clause")],
        )
        .expect("fixture handle");
        let program = vec![
            define("h", handled),
            ModuleItem::require(fix_span(), "other").expect("fixture require"),
            ModuleItem::module(fix_span(), "m", vec![define("r2", var("h"))])
                .expect("fixture module"),
        ];
        ev.eval_program(&program).expect("effects run");
        assert_eq!(ev.global("r2"), Some(&Value::Int(40)));
    }

    #[test]
    fn budget_collect_then_retry_runs_discarding_programs() {
        // A tight budget over a discarding chain: each (car (cons a b))
        // term's pair cell dies the moment `car` pops it, so the live
        // set stays small — but WITHOUT collection the un-reclaimed
        // cells accumulate past the budget (heap live count is
        // monotonic until a cycle runs). The inline collect-then-
        // retry keeps the chain alive.
        let mut ev = Evaluator::with_budget(8);
        let mut terms = Vec::new();
        for i in 0..12 {
            terms.push(call("car", vec![call("cons", vec![int(i), int(0)])]));
        }
        let sum = terms
            .into_iter()
            .reduce(|a, b| call("+", vec![a, b]))
            .expect("chain");
        assert_eq!(
            ev.eval_expr(&sum)
                .expect("collect-then-retry keeps the run alive"),
            Value::Int(66) // 0+1+...+11
        );
        assert!(
            ev.collector_cycles() > 0,
            "at least one automatic cycle ran"
        );

        // Contrast: the same chain under the same budget WITHOUT any
        // way to reclaim fails closed (the heap face is exercised
        // here through a second evaluator with a live-set-retaining
        // program — see the api_tests budget negative).
        let mut strict = Evaluator::with_budget(8);
        let mut keep = Vec::new();
        for i in 0..12 {
            keep.push(call("cons", vec![int(i), int(0)]));
        }
        // A right-nested cons chain keeps every cell live as an arg.
        let chain = keep
            .into_iter()
            .rev()
            .reduce(|acc, cell| call("cons", vec![cell, acc]))
            .expect("chain");
        assert!(matches!(
            strict.eval_expr(&chain),
            Err(RuntimeError::BudgetExceeded { .. })
        ));
    }

    // ---------- negatives ----------

    #[test]
    fn arity_mismatch_closure_face() {
        let mut ev = Evaluator::new();
        let f = fn_(&["a"], var("a"));
        let err = ev
            .eval_program(&[define("f", f), define("r", call("f", vec![int(1), int(2)]))])
            .expect_err("two args to a one-param closure");
        match err {
            RuntimeError::ArityMismatch {
                func,
                expected,
                actual,
                ..
            } => {
                // §9.67 NB-5: the payload identity is a pool entry.
                assert_eq!(func.as_ref().map(|s| s.as_str()), Some("f"));
                assert_eq!((expected, actual), (1, 2));
            }
            other => panic!("expected arity mismatch, got {other:?}"),
        }
    }

    #[test]
    fn arity_mismatch_builtin_face() {
        let mut ev = Evaluator::new();
        let err = ev
            .eval_expr(&call("+", vec![int(1), int(2), int(3)]))
            .expect_err("fixed arity two");
        match err {
            RuntimeError::ArityMismatch {
                func,
                expected,
                actual,
                ..
            } => {
                assert_eq!(func.as_ref().map(|s| s.as_str()), Some("+"));
                assert_eq!((expected, actual), (2, 3));
            }
            other => panic!("expected arity mismatch, got {other:?}"),
        }
    }

    #[test]
    fn type_mismatch_truthy_condition() {
        let mut ev = Evaluator::new();
        let err = ev
            .eval_expr(&if_(int(1), int(2), int(3)))
            .expect_err("condition must be bool");
        match err {
            RuntimeError::TypeMismatch { context, got, .. } => {
                assert_eq!(context, "jump-if-false condition");
                assert_eq!(got, "int");
            }
            other => panic!("expected type mismatch, got {other:?}"),
        }
    }

    #[test]
    fn type_mismatch_arith_mixed_kinds() {
        let mut ev = Evaluator::new();
        let err = ev
            .eval_expr(&call("+", vec![int(1), lit(LiteralValue::Float(2.5))]))
            .expect_err("mixed kinds rejected");
        match err {
            RuntimeError::TypeMismatch { context, got, .. } => {
                assert_eq!(context, "add operand");
                assert_eq!(got, "float");
            }
            other => panic!("expected type mismatch, got {other:?}"),
        }
    }

    #[test]
    fn type_mismatch_car_operand() {
        let mut ev = Evaluator::new();
        let err = ev
            .eval_expr(&call("car", vec![int(5)]))
            .expect_err("car demands a pair");
        match err {
            RuntimeError::TypeMismatch { context, got, .. } => {
                assert_eq!(context, "car operand");
                assert_eq!(got, "int");
            }
            other => panic!("expected type mismatch, got {other:?}"),
        }
    }

    #[test]
    fn type_mismatch_call_callee() {
        let mut ev = Evaluator::new();
        let err = ev
            .eval_program(&[define("f", int(5)), define("r", call("f", vec![int(1)]))])
            .expect_err("callee must be callable");
        match err {
            RuntimeError::TypeMismatch { context, got, .. } => {
                assert_eq!(context, "call callee");
                assert_eq!(got, "int");
            }
            other => panic!("expected type mismatch, got {other:?}"),
        }
    }

    #[test]
    fn unbound_global_read_fails() {
        let mut ev = Evaluator::new();
        let err = ev.eval_expr(&var("missing")).expect_err("never defined");
        match err {
            RuntimeError::UnboundGlobal { name, .. } => {
                assert_eq!(name.as_str(), "missing");
            }
            other => panic!("expected unbound global, got {other:?}"),
        }
    }

    #[test]
    fn div_by_zero_fails_closed() {
        let mut ev = Evaluator::new();
        let err = ev
            .eval_expr(&call("/", vec![int(6), int(0)]))
            .expect_err("integer zero divisor");
        assert!(matches!(err, RuntimeError::DivByZero { .. }));
    }

    #[test]
    fn arithmetic_overflow_fails_closed() {
        let mut ev = Evaluator::new();
        let err = ev
            .eval_expr(&call("+", vec![int(i64::MAX), int(1)]))
            .expect_err("checked add");
        assert!(matches!(err, RuntimeError::ArithmeticOverflow { .. }));
    }

    #[test]
    fn unhandled_effect_names_the_effect() {
        let mut ev = Evaluator::new();
        let expr = CoreExpr::perform(fix_span(), "log", vec![int(1)]).expect("fixture");
        let err = ev.eval_expr(&expr).expect_err("no handler installed");
        match err {
            RuntimeError::UnhandledEffect { effect, .. } => {
                assert_eq!(effect.as_str(), "log");
            }
            other => panic!("expected unhandled effect, got {other:?}"),
        }
    }

    #[test]
    fn read_line_eof_fails() {
        let mut ev = Evaluator::new(); // BufferIo with empty input
        let err = ev
            .eval_expr(&call("read-line", vec![]))
            .expect_err("empty input");
        assert!(matches!(err, RuntimeError::Eof { .. }));
    }

    #[test]
    fn eval_depth_cap_guards_the_rust_stack() {
        // A recursion 3000 deep: the VM frames would live on the
        // heap, but the evaluator recurses in Rust — the cap fires.
        // The capped leg needs more than the default 8 MiB
        // test-thread budget on this toolchain (measured between 8
        // and 12 MiB; the r74 BST-1 lineage applied to the unit
        // face, r83), so the whole case rides a deep-stack thread.
        deep_stack(|| {
            let mut ev = Evaluator::new();
            let countdown = fn_(
                &["n"],
                if_(
                    call("=", vec![var("n"), int(0)]),
                    int(0),
                    call("countdown", vec![call("-", vec![var("n"), int(1)])]),
                ),
            );
            let err = ev
                .eval_program(&[
                    define("countdown", countdown),
                    define("r", call("countdown", vec![int(3000)])),
                ])
                .expect_err("depth cap");
            match err {
                RuntimeError::EvalDepthExceeded { limit, .. } => {
                    assert_eq!(limit, EVAL_DEPTH_LIMIT);
                }
                other => panic!("expected depth cap, got {other:?}"),
            }
            // A depth under the cap runs fine.
            let mut ev2 = Evaluator::new();
            let countdown = fn_(
                &["n"],
                if_(
                    call("=", vec![var("n"), int(0)]),
                    int(0),
                    call("countdown", vec![call("-", vec![var("n"), int(1)])]),
                ),
            );
            ev2.eval_program(&[
                define("countdown", countdown),
                define("r", call("countdown", vec![int(100)])),
            ])
            .expect("depth 101 is under the cap");
            assert_eq!(ev2.global("r"), Some(&Value::Int(0)));
        });
    }
    #[test]
    fn perform_handler_arity_mismatch_propagates() {
        // The handler is a function like any callable — performing
        // with the wrong argument count is the closure-face arity
        // error (the VM invoke duality).
        let mut ev = Evaluator::new();
        let handler = fn_(&["a", "b"], var("a"));
        let handled = CoreExpr::handle(
            fix_span(),
            CoreExpr::perform(fix_span(), "e", vec![int(1)]).expect("fixture"),
            vec![HandlerClause::new(fix_span(), "e", handler).expect("fixture")],
        )
        .expect("fixture");
        let err = ev
            .eval_expr(&handled)
            .expect_err("one arg to two-param handler");
        match err {
            RuntimeError::ArityMismatch {
                expected, actual, ..
            } => {
                assert_eq!((expected, actual), (2, 1));
            }
            other => panic!("expected arity mismatch, got {other:?}"),
        }
    }

    #[test]
    fn write_line_rejects_non_string_operands() {
        let mut ev = Evaluator::new();
        let err = ev
            .eval_expr(&call("write-line", vec![int(5)]))
            .expect_err("write-line demands a string");
        match err {
            RuntimeError::TypeMismatch { context, got, .. } => {
                assert_eq!((context, got), ("write-line operand", "int"));
            }
            other => panic!("expected type mismatch, got {other:?}"),
        }
    }

    #[test]
    fn not_rejects_non_bool_and_cdr_rejects_non_pair() {
        let mut ev = Evaluator::new();
        match ev.eval_expr(&call("not", vec![int(1)])) {
            Err(RuntimeError::TypeMismatch { context, got, .. }) => {
                assert_eq!((context, got), ("not operand", "int"));
            }
            other => panic!("expected type mismatch, got {other:?}"),
        }
        match ev.eval_expr(&call("cdr", vec![lit(LiteralValue::Nil)])) {
            Err(RuntimeError::TypeMismatch { context, got, .. }) => {
                assert_eq!((context, got), ("cdr operand", "nil"));
            }
            other => panic!("expected type mismatch, got {other:?}"),
        }
    }

    #[test]
    fn errors_propagate_from_nested_contexts_with_their_own_spans() {
        // An error raised deep inside a let inside an if inside a
        // closure body: the variant and span survive the unwind (the
        // §12.1 consumption contract on the eval path).
        let mut ev = Evaluator::new();
        let div = call("/", vec![int(1), int(0)]);
        let inner = let_(
            vec![("x", int(1))],
            if_(call("=", vec![var("x"), int(1)]), div, int(0)),
        );
        let outer = fn_(&["n"], inner);
        let err = ev
            .eval_program(&[define("f", outer), define("r", call("f", vec![int(9)]))])
            .expect_err("div by zero two scopes deep");
        match err {
            RuntimeError::DivByZero { span } => {
                // The span is the div form's own (fixture span).
                assert_eq!(span, fix_span());
            }
            other => panic!("expected div by zero, got {other:?}"),
        }
    }

    #[test]
    fn handler_scope_ends_with_the_handle_form() {
        // After the handle form completes, its handlers are gone —
        // a later perform of the same effect is unhandled (the
        // PopHandler n duality).
        let mut ev = Evaluator::new();
        let handler = fn_(&["v"], var("v"));
        let handled = CoreExpr::handle(
            fix_span(),
            CoreExpr::perform(fix_span(), "e", vec![int(1)]).expect("fixture"),
            vec![HandlerClause::new(fix_span(), "e", handler).expect("fixture")],
        )
        .expect("fixture");
        let after = let_(
            vec![("h", handled)],
            CoreExpr::perform(fix_span(), "e", vec![int(2)]).expect("fixture"),
        );
        let err = ev
            .eval_expr(&after)
            .expect_err("handler popped with the form");
        match err {
            RuntimeError::UnhandledEffect { effect, .. } => assert_eq!(effect.as_str(), "e"),
            other => panic!("expected unhandled effect, got {other:?}"),
        }
    }

    #[test]
    fn arity_and_depth_messages_follow_the_r8_family() {
        // §9.56 DIAG-1: messages stand on their own — no span suffix.
        let mut ev = Evaluator::new();
        let msg = ev
            .eval_expr(&call("+", vec![int(1)]))
            .expect_err("arity")
            .to_string();
        assert_eq!(msg, "arity mismatch: `+` expects `2` arguments, got `1`");

        // The depth leg drives the native eval recursion to the
        // documented 2048 cap — more than the default 8 MiB
        // test-thread budget on this toolchain (see `deep_stack`).
        deep_stack(|| {
            let countdown = fn_(
                &["n"],
                if_(
                    call("=", vec![var("n"), int(0)]),
                    int(0),
                    call("countdown", vec![call("-", vec![var("n"), int(1)])]),
                ),
            );
            let mut ev2 = Evaluator::new();
            let msg2 = ev2
                .eval_program(&[
                    define("countdown", countdown),
                    define("r", call("countdown", vec![int(3000)])),
                ])
                .expect_err("depth")
                .to_string();
            assert!(msg2.contains("eval depth of `2048` exceeded"));
            assert!(msg2.starts_with("eval depth"));
        });
    }

    #[test]
    fn closure_captures_the_let_binding_beyond_its_scope() {
        // The Stage 2.1 flipped semantics (the §9.51.2 anchor family
        // inverted, evaluator side): the free name `x` IS captured
        // from the defining let — the closure cell carries the
        // captured value, and the body reads it through the captured
        // region even after the let's scope has exited (the flat
        // closure outlives its defining frame).
        let mut ev = Evaluator::new();
        let closure_in_let = let_(
            vec![("x", int(5))],
            fn_(&["y"], call("+", vec![var("x"), var("y")])),
        );
        // Grab the closure, then call it after the let has exited.
        let program = vec![
            define("f", closure_in_let),
            define("r", call("f", vec![int(1)])),
        ];
        ev.eval_program(&program).expect("the capture resolves");
        assert_eq!(
            ev.global("r").map(|v| v.to_string()),
            Some("6".into()),
            "x stays 5 through the captured region"
        );
    }

    #[test]
    fn name_tables_ride_the_single_pool() {
        // §9.67 NB-1/NB-2/NB-3 guard: the globals table, the binding
        // sites, and the handler stack all key by interned identity —
        // an independently interned Symbol of the same text IS the
        // table entry (the §9.52 single pool invariant), and a miss
        // through the identity face never pollutes the pool.
        let mut ev = Evaluator::new();
        ev.eval_program(&[define("x", int(42)), define("y", int(7))])
            .expect("defines run");
        // Identity face: same text interned independently resolves.
        let x_again = Symbol::new("x").expect("fixture symbol");
        assert_eq!(
            ev.global_sym(&x_again).map(|v| v.to_string()),
            Some("42".into())
        );
        // Text face still agrees (the observation face is a scan).
        assert_eq!(ev.global("x").map(|v| v.to_string()), Some("42".into()));
        // A miss through the identity face resolves None for both
        // faces and leaves the roster untouched (no shadow insert).
        let miss = Symbol::new("never-defined").expect("fixture symbol");
        assert!(ev.global_sym(&miss).is_none());
        assert!(ev.global("never-defined").is_none());
        // Builtin seeding rides the pool too: the seeded identity and
        // an independent intern of "+" are one entry (NB-5 seeding
        // face — the payload reads the pool, never re-interns).
        let plus = Symbol::new("+").expect("fixture symbol");
        assert!(matches!(ev.global_sym(&plus), Some(Value::Builtin(_))));
    }
}

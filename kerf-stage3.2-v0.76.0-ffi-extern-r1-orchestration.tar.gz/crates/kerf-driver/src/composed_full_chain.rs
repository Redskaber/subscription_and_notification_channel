//! The composed-chain routing key and the gate-B dump witness
//! (§9.87 lineage, carried through the r104 E5 batch-3 teardown):
//! the `.krf` composed-chain driver itself retired — the five
//! `.krf` originals left the tree and the production chain is the
//! TARGET twins' own composed chain
//! (`composed_target_chain.rs`, switch-window-plan §5.6.4). What
//! stays here is the skin-less half both chains share:
//!
//! * [`ComposedLayer`] — the drift ledger's routing key (which
//!   junction decided a case; the §9.87.4 layer set);
//! * [`dump_faithfulness_witness`] — the gate-B promotion witness
//!   (the analysis-dump grammar must be a faithful image of the
//!   `Bytecode` semantics — the precondition the 2.5 window
//!   registered for gate B's full-pipeline dual-track).
//!
//! The `.krf` chain's own record (the three-junction driver, the
//! tamper probes, the VM-bracket face) rides the audit's historical
//! sections; its live successor is `composed_target_chain.rs`.

use kerf_compiler::{Bytecode, Instr, Opcode};
use kerf_span::{ByteOffset, ExpansionId, FileId, Span, Symbol};

use crate::compiler_parity::oracle_analysis_dump;

/// Which junction decided the case (the drift ledger's routing key).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ComposedLayer {
    /// The read chain (lexer + reader): a reader-layer rejection, or
    /// a junction-1 drift. Downstream junctions are vacuous.
    Read,
    /// The expansion layer: an expander/loader rejection verified on
    /// the error axis, or a junction-2 drift.
    Expand,
    /// The compile layer: products or compile-error keys, or a
    /// junction-3 drift.
    Compile,
}

/// The gate-B promotion witness (§9.87.5, the 2.4 evaluation slot):
/// the analysis-dump grammar must be a FAITHFUL image of the
/// `Bytecode` semantics — every field mutation visible in the dump.
/// With the witness holding, dump equality implies bytecode equality,
/// which is the precondition `stage-2-plan` §2 row 2.5 registers for
/// the gate-B full-pipeline dual-track (the `.krf` compiler product
/// as one side of gate B's axis (a)).
///
/// The verdict names the FIRST field whose mutation the dump failed
/// to surface (fail-closed — never a silent pass).
pub fn dump_faithfulness_witness(bc: &Bytecode) -> Result<(), String> {
    let baseline = oracle_analysis_dump(bc);
    let mut probes: Vec<(String, String)> = Vec::new(); // (field, mutated dump)
    let mut mutated = bc.clone();
    // funcs[0].name — nil vs a name (and back) flips the dump.
    if let Some(first) = mutated.funcs.first_mut() {
        let flipped = match first.name {
            Some(_) => None,
            None => Some(Symbol::new("witness").expect("a valid witness name")),
        };
        first.name = flipped;
    }
    probes.push(("funcs[0].name".into(), oracle_analysis_dump(&mutated)));

    mutated = bc.clone();
    // captures: flip emptiness both ways — clear when present, add
    // one descriptor when empty (either direction must surface).
    if let Some(first) = mutated.funcs.first_mut() {
        if first.captures.is_empty() {
            first.captures.push(kerf_compiler::CaptureSource::Local(0));
        } else {
            first.captures.clear();
        }
    }
    probes.push(("funcs[0].captures".into(), oracle_analysis_dump(&mutated)));

    mutated = bc.clone();
    if let Some(first) = mutated.funcs.first_mut() {
        first.params = first.params.wrapping_add(1);
    }
    probes.push(("funcs[0].params".into(), oracle_analysis_dump(&mutated)));

    mutated = bc.clone();
    if let Some(first) = mutated.funcs.first_mut() {
        first.n_locals = first.n_locals.wrapping_add(1);
    }
    probes.push(("funcs[0].n_locals".into(), oracle_analysis_dump(&mutated)));

    mutated = bc.clone();
    if let Some(first) = mutated.funcs.first_mut() {
        // Any appended instruction changes the rendered sequence —
        // `Ret` with zero operands is the canonical witness.
        first.code.push(Instr::new(Opcode::Ret));
    }
    probes.push(("funcs[0].code".into(), oracle_analysis_dump(&mutated)));

    mutated = bc.clone();
    if let Some(first) = mutated.funcs.first_mut() {
        let span = first.debug_info.first().copied().unwrap_or(Span {
            file_id: FileId(0),
            start: ByteOffset(0),
            end: ByteOffset(1),
            expansion_id: ExpansionId::ROOT,
        });
        first.debug_info.clear();
        first.debug_info.push(span);
        first.debug_info.push(span);
    }
    probes.push(("funcs[0].debug_info".into(), oracle_analysis_dump(&mutated)));

    mutated = bc.clone();
    mutated.funcs.clear();
    probes.push(("funcs (dropped)".into(), oracle_analysis_dump(&mutated)));

    mutated = bc.clone();
    if !mutated.globals.is_empty() {
        mutated.globals.clear();
        probes.push(("globals".into(), oracle_analysis_dump(&mutated)));
    }

    mutated = bc.clone();
    if !mutated.consts.is_empty() {
        mutated.consts.clear();
        probes.push(("consts".into(), oracle_analysis_dump(&mutated)));
    }

    for (field, dump) in probes {
        if dump == baseline {
            return Err(format!(
                "the dump grammar lost a semantic field: mutating `{field}` changed nothing"
            ));
        }
    }
    Ok(())
}

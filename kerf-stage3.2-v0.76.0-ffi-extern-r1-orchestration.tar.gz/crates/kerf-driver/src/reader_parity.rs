//! Stage 1.5 reader parity — the first self-hosted front-end segment
//! (docs/stage0.md §9.46.4, plan-1.5.md). The structure layer of the
//! S-expr reader, rewritten in the frozen kerf subset itself
//! (`selfhost/v1/reader.krf`), checked against the Rust reader
//! oracle byte-for-byte on both axes:
//!
//! * **Tree axis** — the oracle `SyntaxObject` tree and the `.krf`
//!   reader's `("ok" forms...)` result (a pair chain read back
//!   through the heap) normalize to the same dump.
//! * **Error axis** — the `.krf` reader reports a *structured*
//!   rejection (`("err" kind payload...)`); the harness rebuilds the
//!   `ReadError` and renders it through the oracle's own `Display`,
//!   so byte parity holds by construction and the non-trivial part
//!   under test is the kind/payload selection (innermost `(`, empty
//!   application before outer unclosed, depth on entry).
//!
//! The token table is source-injected (RS-1): the host runs the Rust
//! lexer — the single source of token truth, the hex0 layer of this
//! bootstrap chain — and prepends `(define tokens (quote (...)))`
//! ahead of the reader source. Sources the *lexer* rejects take the
//! [`ParityLayer::Lexer`] path (the .krf layer is not exercised —
//! the second-segment window owns that parity); everything else runs
//! the .krf reader on **both engines** (the `run_parity` lineage:
//! handles stay alive so heap-backed values decode before the
//! engines drop).
//!
//! Payload conventions (the .krf reader never inspects payloads — it
//! passes records through; the host re-reads them):
//! * spans ride as decimal strings (the subset cannot convert
//!   strings to integers),
//! * floats ride as Debug-text strings (`inf`/`NaN` have no .krf
//!   literal shape — every float rides as text; host-side parse is
//!   exact both ways),
//! * ints/bools/strings ride as typed literals (i64 decimal always
//!   re-lexes, including `i64::MIN`; the kerf escape set covers the
//!   string round trip).

use kerf_reader::{Delimiter, ReadError, StxTokenKind, lex};
use kerf_runtime::Evaluator;
use kerf_span::{ByteOffset, FileId};
use kerf_syntax::{StxDatum, SyntaxObject};
use kerf_vm::{BufferIo, Heap, HeapObj, RuntimeError, Value, Vm};

use crate::diagnostic::Severity;
use crate::pipeline;
use crate::session::Session;

/// The `.krf` harness's decoded verdict for one engine run — the
/// shared two-tag grammar (`("ok" ...)` / `("err" ...)`) generic
/// over the structured error type (the reader rebuilds a
/// `ReadError`, the expander a `ParityError`). §9.74 PAR-1: one
/// definition for both harnesses (the twin `KrfVerdict` enums
/// retired, the §9.73 dispatch_builtin lineage).
#[derive(Debug, Clone, PartialEq)]
pub(crate) enum KrfVerdict<E> {
    /// `("ok" form...)` — the normalized tree dump.
    Tree(String),
    /// `("err" kind payload...)` — the rebuilt structured error.
    Error(E),
}

// The `KrfVerdict<ReadError>` text impl (the .krf reader face's
// comparison key) retired with the r104 E5 batch-3 teardown — the
// reader-parity driver that consumed it left the tree; the generic
// verdict and the shared decoders stay (the target chain's own
// harnesses consume them through their type specializations).

/// The error-axis parity key: stage Display + harness-rendered
/// position payload (§9.56 DIAG-1 compensations — offsets ride in
/// the payload, the key surfaces them).
pub(crate) fn error_parity_key(err: &ReadError) -> String {
    match err.offset() {
        Some(ByteOffset(at)) => format!("{err} @ byte {at}"),
        None => err.to_string(),
    }
}

// ---------- RS-1: the source-injected token table ----------

/// Encode one string as a kerf string literal. The escape set is
/// exactly the lexer's (`\"` `\\` `\n` `\t` `\r`); every other char
/// rides through raw — raw control characters are legal inside kerf
/// string literals, so the round trip is exact for any decoded text.
pub(crate) fn encode_string_literal(s: &str) -> String {
    let mut out = String::with_capacity(s.len() + 2);
    out.push('"');
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\t' => out.push_str("\\t"),
            '\r' => out.push_str("\\r"),
            _ => out.push(c),
        }
    }
    out.push('"');
    out
}

/// Build the `(define tokens (quote (...)))` prefix for one source.
///
/// `Err` carries the oracle's lexer rejection — the harness layer
/// split: lexer-side failures are decided by the (single-source)
/// lexer itself and the .krf layer is not run for them.
pub fn token_table_prefix(source: &str) -> Result<String, ReadError> {
    let file = FileId(0);
    let tokens = lex(file, source)?;
    let mut out = String::from("(define tokens (quote (");
    for (i, tok) in tokens.iter().enumerate() {
        if i > 0 {
            out.push(' ');
        }
        let span = &tok.span;
        let (s, e) = (span.start.0.to_string(), span.end.0.to_string());
        match &tok.kind {
            StxTokenKind::Delimiter(Delimiter::Open) => {
                out.push_str(&format!("(\"lparen\" \"{s}\" \"{e}\")"));
            }
            StxTokenKind::Delimiter(Delimiter::Close) => {
                out.push_str(&format!("(\"rparen\" \"{s}\" \"{e}\")"));
            }
            StxTokenKind::Identifier(sym) => {
                out.push_str(&format!(
                    "(\"ident\" \"{s}\" \"{e}\" {})",
                    encode_string_literal(sym.as_str())
                ));
            }
            StxTokenKind::IntLiteral(v) => {
                out.push_str(&format!("(\"int\" \"{s}\" \"{e}\" {v})"));
            }
            StxTokenKind::FloatLiteral(v) => {
                // Debug text rides as a string: inf/NaN have no .krf
                // literal shape, so *every* float is text-carried.
                out.push_str(&format!(
                    "(\"float\" \"{s}\" \"{e}\" {})",
                    encode_string_literal(&format!("{v:?}"))
                ));
            }
            StxTokenKind::BoolLiteral(v) => {
                // kerf spells its booleans #t/#f (not #true/#false).
                let lit = if *v { "#t" } else { "#f" };
                out.push_str(&format!("(\"bool\" \"{s}\" \"{e}\" {lit})"));
            }
            StxTokenKind::StringLiteral(v) => {
                out.push_str(&format!(
                    "(\"string\" \"{s}\" \"{e}\" {})",
                    encode_string_literal(v)
                ));
            }
            StxTokenKind::Eof => {
                out.push_str(&format!("(\"eof\" \"{e}\")"));
            }
        }
    }
    out.push_str(")))");
    Ok(out)
}

// ---------- RS-3: the two normalizers ----------

/// The oracle's normalized dump: every node as
/// `(kind start end payload...)`, lists as `(list s e child...)`.
pub fn oracle_dump(forms: &[SyntaxObject]) -> String {
    let mut out = String::new();
    for (i, f) in forms.iter().enumerate() {
        if i > 0 {
            out.push(' ');
        }
        dump_oracle_node(f, &mut out);
    }
    out
}

fn dump_oracle_node(node: &SyntaxObject, out: &mut String) {
    let (s, e) = (node.span.start.0, node.span.end.0);
    match &node.datum {
        StxDatum::Symbol(sym) => {
            out.push_str(&format!("(ident {s} {e} {})", sym.as_str()));
        }
        StxDatum::Int(v) => {
            out.push_str(&format!("(int {s} {e} {v})"));
        }
        StxDatum::Float(v) => {
            out.push_str(&format!("(float {s} {e} {v:?})"));
        }
        StxDatum::Bool(v) => {
            out.push_str(&format!("(bool {s} {e} {v})"));
        }
        StxDatum::String(v) => {
            out.push_str(&format!("(string {s} {e} {v:?})"));
        }
        StxDatum::List(items) => {
            out.push_str(&format!("(list {s} {e}"));
            for item in items {
                out.push(' ');
                dump_oracle_node(item, out);
            }
            out.push(')');
        }
    }
}

/// The elements of a proper-list value (walks the pair chain). `Err`
/// reports a malformed chain — a structural defect of the .krf
/// reader's own output, surfaced as drift.
pub(crate) fn value_elems<'v>(value: &'v Value, heap: &'v Heap) -> Result<Vec<&'v Value>, String> {
    let mut elems = Vec::new();
    let mut cur = value;
    loop {
        match cur {
            Value::Nil => return Ok(elems),
            Value::Pair(r) => match heap.get(*r) {
                Some(HeapObj::Pair(car, cdr)) => {
                    elems.push(car);
                    cur = cdr;
                }
                _ => return Err("dangling pair reference in the result chain".to_string()),
            },
            other => {
                return Err(format!("improper list: chain ends in {other:?}"));
            }
        }
    }
}

pub(crate) fn as_str(v: &Value) -> Result<&str, String> {
    match v {
        Value::Str(s) => Ok(&**s),
        other => Err(format!("expected a string field, found {other:?}")),
    }
}

pub(crate) fn as_i64(v: &Value) -> Result<i64, String> {
    match v {
        Value::Int(n) => Ok(*n),
        other => Err(format!("expected an int field, found {other:?}")),
    }
}

pub(crate) fn parse_span(v: &Value) -> Result<u32, String> {
    let text = as_str(v)?;
    text.parse::<u32>()
        .map_err(|_| format!("span field `{text}` is not a decimal offset"))
}

/// Assert a record's minimum field count (§9.76 SER-1; K172 — serde's
/// `invalid_length` shape: kind, actual count, needed count as a
/// structured error, never an index/slice panic). Every decode arm
/// that reaches past the common header fields carries one of these
/// ahead of its first payload access, so a malformed record produced
/// by the self-hosted layer under test reports drift, never a
/// harness panic (the documented `drive_dual_engines` contract).
pub(crate) fn need_fields(elems: &[&Value], n: usize, what: &str) -> Result<(), String> {
    if elems.len() < n {
        let plural = if elems.len() == 1 { "" } else { "s" };
        return Err(format!(
            "{what} record has {} field{plural}, need at least {n}",
            elems.len()
        ));
    }
    Ok(())
}

// ---------- RS-4: the dual-engine run (single source) ----------

/// Decode one engine's `result` global into a tagged verdict — the
/// single-source tag grammar for both parity harnesses (§9.74
/// PAR-1): the `"ok"` branch dumps every form through `dump`, the
/// `"err"` branch rebuilds the structured error through `rebuild`.
/// Everything else about the two harnesses' verdict grammars is
/// identical by construction.
pub(crate) fn decode_tagged<E>(
    value: &Value,
    heap: &Heap,
    dump: fn(&Value, &Heap, &mut String) -> Result<(), String>,
    rebuild: fn(&Value, &Heap) -> Result<E, String>,
) -> Result<KrfVerdict<E>, String> {
    let elems = value_elems(value, heap)?;
    let tag = elems
        .first()
        .and_then(|v| match v {
            Value::Str(s) => Some(&**s),
            _ => None,
        })
        .ok_or_else(|| "the result value is not a tagged list".to_string())?;
    match tag {
        "ok" => {
            let mut out = String::new();
            for (i, form) in elems[1..].iter().enumerate() {
                if i > 0 {
                    out.push(' ');
                }
                dump(form, heap, &mut out)?;
            }
            Ok(KrfVerdict::Tree(out))
        }
        "err" => Ok(KrfVerdict::Error(rebuild(value, heap)?)),
        other => Err(format!("unknown verdict tag `{other}`")),
    }
}

/// Drive one assembled `.krf` harness program through both engines
/// and return the two decoded verdicts — the single source for the
/// reader/expander parity drivers and the gate-B host rebuild (three
/// hand-rolled twins retired; the §9.73 `dispatch_builtin` lineage).
/// §9.74 PAR-1.
///
/// `host_name` names the synthetic file for diagnostics; `what` is
/// the harness noun ("reader" / "expander") threaded into every
/// harness-failure message. The two decoders run **while their engine
/// — and its heap — is still alive** (heap-backed values; the
/// `run_parity` lineage): the vm decoder may rebuild richer state
/// (the gate-B item tree) while the eval decoder stays plain.
///
/// `Err` carries one of two classified prefixes (r74, K165 — the
/// CPython `_json.c` discipline of classifying a boundary at the
/// failure site):
/// * `"harness defect: …"` — the harness program failed a pipeline
///   stage, crashed on a non-budget runtime error, or produced an
///   undecodable result: a real harness bug;
/// * `"harness limit: …"` — an engine budget face (`BudgetExceeded` /
///   `EvalDepthExceeded`) rejected the harness program: the honest
///   **input envelope** of the harness, not a semantic drift. The
///   frozen subset expresses iteration only through self-recursion
///   (no loop primitive — the §9.29 termination argument), so a
///   source wide enough drives the per-token / per-record harness
///   walks past an engine budget.
///
/// Both classes are reported as drift, never a panic.
pub(crate) fn drive_dual_engines<VmOut, EvOut>(
    host_name: &str,
    what: &str,
    assembled: &str,
    face: crate::pipeline::ReaderFace,
    decode_vm: impl Fn(&Value, &Heap) -> Result<VmOut, String>,
    decode_eval: impl Fn(&Value, &Heap) -> Result<EvOut, String>,
) -> Result<(VmOut, EvOut), String> {
    let mut session = Session::new();
    let program =
        pipeline::parse_with(&mut session, host_name, assembled, face).map_err(|diags| {
            format!("harness defect: the assembled {what} program failed to parse: {diags:?}")
        })?;
    let findings = program.typecheck();
    if findings.iter().any(|d| d.severity == Severity::Error) {
        return Err(format!(
            "harness defect: the assembled {what} program failed the checker: {findings:?}"
        ));
    }
    let bc = kerf_compiler::compile_program(&program.items).map_err(|err| {
        format!("harness defect: the assembled {what} program failed to compile: {err}")
    })?;
    let mut vm = Vm::with_io(bc, Box::new(BufferIo::default()))
        .map_err(|err| format!("harness defect: the vm rejected the {what} program: {err}"))?;
    vm.run()
        .map_err(|err| harness_run_failure("vm", what, &err))?;
    let vm_verdict = decode_vm(
        vm.global("result")
            .ok_or_else(|| "harness defect: no `result` global on the vm engine".to_string())?,
        vm.heap(),
    )
    .map_err(|err| format!("harness defect: {err}"))?;

    let mut evaluator = Evaluator::with_io(Box::new(BufferIo::default()));
    evaluator
        .eval_program(&program.items)
        .map_err(|err| harness_run_failure("eval", what, &err))?;
    let eval_verdict = decode_eval(
        evaluator
            .global("result")
            .ok_or_else(|| "harness defect: no `result` global on the eval engine".to_string())?,
        evaluator.heap(),
    )
    .map_err(|err| format!("harness defect: {err}"))?;
    Ok((vm_verdict, eval_verdict))
}

/// Classify one engine rejection of the assembled harness program
/// (r74, K165 — the CPython `_json.c` discipline: a recursion
/// boundary is classified at the failure site, never reported as a
/// generic crash). The two budget faces are the harness's honest
/// input envelope — the frozen subset expresses iteration only
/// through self-recursion, so a wide enough source exhausts an
/// engine budget — while every other runtime rejection of the
/// harness program is a harness defect.
fn harness_run_failure(engine: &str, what: &str, err: &RuntimeError) -> String {
    if matches!(
        err,
        RuntimeError::BudgetExceeded { .. } | RuntimeError::EvalDepthExceeded { .. }
    ) {
        format!(
            "harness limit: the .krf {what} exceeded the {engine} engine's budget ({err}) \
             — the frozen subset's per-element recursion gives the harness a finite \
             input envelope; not a semantic drift"
        )
    } else {
        format!("harness defect: the .krf {what} crashed on the {engine} engine: {err}")
    }
}

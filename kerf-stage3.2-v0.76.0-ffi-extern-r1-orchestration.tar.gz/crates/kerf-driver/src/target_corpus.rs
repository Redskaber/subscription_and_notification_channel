//! The step-3 corpus-translation harness (switch-window-plan §1
//! step 3, stage0.md §9.96): the target-skin twins of the selfhost
//! injection contracts.
//!
//! The five `selfhost/v1/*.ktf` files each consume one
//! host-injected global (the byte table, the token records, the
//! form records, the item records) and produce one product global
//! — the RS-1/EX-1/CP injection family. This module provides the
//! same injection data on the target skin, so the parity tests can
//! drive the `.ktf` twins through the identical pipeline and
//! compare against the Rust engines (the BS-A seed-chain oracle:
//! the `.krf` originals were removed at r104 — E5 batch 3 — and
//! `read_program`/`expand_program`/`compile_program` remain the
//! tree truth sources of each segment).
//!
//! Single-source discipline: the DATA comes from the S-expr prefix
//! builders verbatim (`byte_table_prefix`, `token_table_prefix`,
//! `forms_stream_prefix`, `items_stream_prefix`); only the SKIN is
//! transcoded here. Every transcoded prefix is round-trip checked
//! against the real target reader — the emitted text must read
//! back to the identical Stx tree (the naming guard: a datum the
//! target vocabulary cannot spell is a harness defect, never a
//! silent rename).

use kerf_compiler::{Bytecode, compile_program};
use kerf_core::ModuleItem;
use kerf_reader::ReadError;
use kerf_reader::read_program;
use kerf_reader::read_target_program;
use kerf_span::FileId;
use kerf_syntax::StxDatum;
use kerf_syntax::SyntaxObject;
use kerf_vm::{Builtin, Heap, Value};

use crate::compiler_parity::RichCompileRun;
use crate::compiler_parity::{
    decode_verdict_vm, dump_krf_section, items_stream_prefix, rebuild_bytecode,
    rebuild_compile_error,
};
use crate::expander_parity::forms_stream_prefix;
use crate::lexer_parity::byte_table_prefix;
use crate::pipeline::{self, ReaderFace};
use crate::reader_parity::KrfVerdict;
use crate::reader_parity::{decode_tagged, drive_dual_engines, token_table_prefix};

/// The target-skin lexer twin (`selfhost/v1/lexer.ktf`; the Rust
/// `read_program` seed chain remains the oracle — BS-A).
pub const LEXER_TARGET_SOURCE: &str = include_str!("../../../selfhost/v1/lexer.ktf");
/// The target-skin reader twin (`selfhost/v1/reader.ktf`; the Rust
/// `read_program` seed chain remains the oracle — BS-A).
pub const READER_TARGET_SOURCE: &str = include_str!("../../../selfhost/v1/reader.ktf");
/// The target-skin macro library twin (`selfhost/v1/macro.ktf`;
/// the Rust `expand_program` remains the oracle — BS-A).
pub const MACRO_TARGET_SOURCE: &str = include_str!("../../../selfhost/v1/macro.ktf");
/// The target-skin expander twin (`selfhost/v1/expander.ktf`; the
/// Rust `expand_program` remains the oracle — BS-A).
pub const EXPANDER_TARGET_SOURCE: &str = include_str!("../../../selfhost/v1/expander.ktf");
/// The target-skin compiler twin (`selfhost/v1/compiler.ktf` — the
/// fully self-hosted segment: gate B bytecode equality plus the
/// three-phase fixpoint; the Rust `compile_program` remains the
/// oracle — BS-A).
pub const COMPILER_TARGET_SOURCE: &str = include_str!("../../../selfhost/v1/compiler.ktf");

/// The assembled target-skin expander (the MX-2 twin: the macro
/// library prepended to the expander body, one program).
pub fn assembled_expander_target_source() -> String {
    format!("{MACRO_TARGET_SOURCE}\n{EXPANDER_TARGET_SOURCE}")
}

/// The inverse of the reader's E5 skin map (the naming guard's
/// spelling pass): the target spelling of one S-expr face name.
///
/// Inverse rule P: a trailing `?` becomes the `is_` marker before
/// the final segment (`nil?` → `is_nil`, `lx-digit?` →
/// `lx_is_digit`). Inverse rule K: `-` becomes `_`. The batch-1+2
/// table entries invert entry-wise. The caller round-trip checks
/// the result through the real reader — names the target
/// vocabulary cannot spell (an interior `_`, the bare operator
/// spellings, the shadowed modern names) fail there, never here.
pub(crate) fn target_skin_spelling(text: &str) -> String {
    let spelled = match text {
        "read-line" => "read_line".to_string(),
        "write-line" => "write_line".to_string(),
        "car" => "first".to_string(),
        "cdr" => "rest".to_string(),
        "cons" => "pair".to_string(),
        "eq?" => "eq".to_string(),
        "set!" => "set".to_string(),
        _ => match text.strip_suffix('?') {
            Some(stem) => match stem.rfind('-') {
                Some(i) => format!("{}_is_{}", &stem[..i], &stem[i + 1..]),
                None => format!("is_{stem}"),
            },
            None => text.to_string(),
        },
    };
    spelled.replace('-', "_")
}

/// The target-skin spelling of one canonical (S-expr vocabulary)
/// name: the skin map for word names, plus the one divergent
/// operator spelling (`=` → `==`; every other operator renders with
/// identical glyphs on both faces). Names the skin map cannot
/// spell pass through verbatim (the reader's own constraint —
/// target-unspellable names surface exactly as the canonical
/// pool text).
pub(crate) fn target_name(canonical: &str) -> String {
    if canonical == "=" {
        "==".to_string()
    } else {
        target_skin_spelling(canonical)
    }
}

/// The target-skin rendering of one runtime type-mismatch context:
/// tokens that name a registry builtin map through
/// [`target_name`]; engine-opcode vocabulary (`jump-if-false`,
/// `add`, the call callee) is face-neutral and passes through
/// verbatim. Backticked operator tokens keep their backticks.
pub(crate) fn target_context(context: &str) -> String {
    context
        .split(' ')
        .map(|token| {
            let (bare, backticked) = match token.strip_prefix('`') {
                Some(rest) => (rest.strip_suffix('`').unwrap_or(rest), true),
                None => (token, false),
            };
            if Builtin::from_name(bare).is_none() {
                return token.to_string();
            }
            let spelled = target_name(bare);
            if backticked {
                format!("`{spelled}`")
            } else {
                spelled
            }
        })
        .collect::<Vec<_>>()
        .join(" ")
}

/// Emit one Stx datum as target-skin datum text (the quote carrier
/// grammar): lists ride the tuple skin — one element needs the
/// Rust tuple convention's trailing comma, two or more join with
/// commas. Shared with the step-5 program transcoder
/// (`skin_transcoder.rs`) — the single datum-emission truth.
///
/// The string arm is [`emit_escaped_string`] below — extracted as
/// the single escaping truth both emission faces share (r106 FIX-9:
/// skin_transcoder's `emit_string` delegates here; the old duplicated
/// loop was a copy-drift channel the "shared" doc comment denied).
pub(crate) fn emit_target_datum(datum: &StxDatum, out: &mut String) {
    match datum {
        StxDatum::Symbol(symbol) => out.push_str(&target_skin_spelling(symbol.as_str())),
        StxDatum::Int(v) => out.push_str(&v.to_string()),
        StxDatum::Float(v) => out.push_str(&format!("{v:?}")),
        StxDatum::Bool(v) => out.push_str(if *v { "true" } else { "false" }),
        StxDatum::String(value) => emit_escaped_string(value, out),
        StxDatum::List(items) => {
            if items.is_empty() {
                // The S-expr face rejects `(quote ())` (subset-spec
                // §2.5) — an empty list datum cannot reach the
                // transcoding face from the prefix builders.
                panic!("harness defect: the empty list datum rides as `nil`");
            }
            out.push('(');
            for (i, item) in items.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                emit_target_datum(&item.datum, out);
            }
            if items.len() == 1 {
                // `(d)` groups; `(d,)` is the one-element list.
                out.push(',');
            }
            out.push(')');
        }
    }
}

/// The string-literal arm of [`emit_target_datum`] — the escaping
/// set the datum carrier accepts (`\"` `\\` `\n` `\t` `\r`),
/// shared verbatim by the transcoder's string emission so the two
/// faces can never drift (r106 FIX-9: this extraction closed the
/// copy-drift channel the old duplicated loop left open despite the
/// "shared" doc claim).
pub(crate) fn emit_escaped_string(value: &str, out: &mut String) {
    out.push('"');
    for c in value.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\t' => out.push_str("\\t"),
            '\r' => out.push_str("\\r"),
            _ => out.push(c),
        }
    }
    out.push('"');
}

/// Transcode one `(define NAME (quote DATA))` S-expr prefix into
/// the target skin: `define(NAME', quote(DATA'));` — then
/// round-trip check the emission through the real target reader
/// (the naming guard: the transcoded prefix must read back to the
/// byte-identical Stx display).
fn transcode_quoted_define(prefix: &str) -> String {
    let forms = read_program(FileId(0), prefix)
        .unwrap_or_else(|e| panic!("harness defect: the S-expr prefix must read: {e}"));
    assert_eq!(
        forms.len(),
        1,
        "harness defect: the prefix is one define form"
    );
    let items = match &forms[0].datum {
        StxDatum::List(items) => items,
        _ => panic!("harness defect: the prefix is a list form"),
    };
    assert_eq!(
        items.len(),
        3,
        "harness defect: the prefix is (define NAME (quote DATA))"
    );
    let name = match &items[1].datum {
        StxDatum::Symbol(symbol) => target_skin_spelling(symbol.as_str()),
        _ => panic!("harness defect: the define name is a symbol"),
    };
    let quoted = match &items[2].datum {
        StxDatum::List(quote_items) => quote_items,
        _ => panic!("harness defect: the define value is a quote form"),
    };
    assert_eq!(
        quoted.len(),
        2,
        "harness defect: the quote form takes one datum"
    );
    let mut out = String::with_capacity(prefix.len() + 16);
    out.push_str("define(");
    out.push_str(&name);
    out.push_str(", quote(");
    emit_target_datum(&quoted[1].datum, &mut out);
    out.push_str("));\n");
    // The naming guard: the emission must read back to the identical
    // tree — an unrepresentable name is a harness defect, never a
    // silent rename.
    let read_back = read_target_program(FileId(0), &out)
        .unwrap_or_else(|e| panic!("harness defect: the transcoded prefix must read: {e}"));
    assert_eq!(
        read_back.len(),
        1,
        "harness defect: the transcoded prefix is one form"
    );
    assert_eq!(
        read_back[0].datum.to_string(),
        forms[0].datum.to_string(),
        "harness defect: the transcoded prefix must round-trip to the identical tree"
    );
    out
}

/// The byte-table prefix on the target skin (`source_bytes`).
pub fn target_byte_table_prefix(source: &str) -> String {
    transcode_quoted_define(&byte_table_prefix(source))
}

/// The token-record prefix on the target skin (`tokens`).
pub fn target_token_table_prefix(source: &str) -> Result<String, ReadError> {
    Ok(transcode_quoted_define(&token_table_prefix(source)?))
}

// ---------- the datum spellability face (the r104 composed target
// chain's junction-2 data boundary) ----------

/// Can one datum ride the target skin's LITERAL face? The one
/// value-class boundary: a negative integer whose positive part
/// exceeds `i64::MAX` — i.e. exactly `i64::MIN` — cannot (the
/// target lexer applies the sign after parsing the magnitude, so
/// the bare magnitude `9223372036854775808` overflows `i64` before
/// the sign ever applies; every other negative integer and every
/// negative float reads back fine). This is the r103
/// exception-ledger boundary (a negative literal with no positive
/// counterpart — the corpus face carries those cases through
/// arithmetic-composition twins, switch-window-plan §5.6.2),
/// instantiated on the junction-2 data-injection face: form-record
/// data carrying an `i64::MIN` datum has NO target-skin text, so
/// the composed target chain classifies the case at the boundary
/// instead of silently re-spelling it (§2.3 report-don't-hide).
pub fn datum_target_spellable(datum: &StxDatum) -> bool {
    match datum {
        // The single value-class boundary: i64::MIN (the magnitude
        // 2^63 overflows the positive domain before the sign).
        StxDatum::Int(v) => *v != i64::MIN,
        StxDatum::Float(_) | StxDatum::Bool(_) | StxDatum::String(_) | StxDatum::Symbol(_) => true,
        StxDatum::List(items) => items.iter().all(|i| datum_target_spellable(&i.datum)),
    }
}

/// Do all of a form stream's datums ride the target skin's literal
/// face? (The junction-2 feed's spellability precheck — one walk,
/// never a try-and-panic.)
pub fn forms_target_spellable(forms: &[SyntaxObject]) -> bool {
    forms.iter().all(|f| datum_target_spellable(&f.datum))
}

/// The form-record prefix on the target skin (`forms`).
pub fn target_forms_stream_prefix(forms: &[SyntaxObject]) -> String {
    transcode_quoted_define(&forms_stream_prefix(forms))
}

/// The item-record prefix on the target skin (`items`).
pub fn target_items_stream_prefix(items: &[ModuleItem]) -> String {
    transcode_quoted_define(&items_stream_prefix(items))
}

// ---------- the step-4 production bridge (switch-window-plan §1) ----------

/// Read one target-skin source through the BOOTSTRAP front end
/// (switch-window-plan §1 step 4 — the production bridge): the new
/// reader parses the text, the shared spine expands and loads it.
/// This is the `.ktf` chain's entry into the bootstrap composition
/// — the twin of reading a `.krf` source through the seed reader,
/// and the exact face the step-4 fixpoint drives its own source
/// through (stage0.md §9.30.4: "the target-syntax Reader compiles
/// itself" starts here).
///
/// `Err` carries the classified front-end rejection (the harness
/// discipline — reader/expand/loader failures are reported, never a
/// panic).
pub fn read_target_source_for_bootstrap(
    name: &str,
    source: &str,
) -> Result<Vec<ModuleItem>, String> {
    let mut session = crate::session::Session::new();
    match pipeline::parse_target(&mut session, name, source) {
        Ok(program) => Ok(program.items),
        Err(diags) => Err(format!(
            "the bootstrap front end rejected the target source: {diags:?}"
        )),
    }
}

/// The target-skin rich compile, VM-only bracket — the step-4
/// twin of `krf_compile_rich_vm`: `target_items_stream_prefix` +
/// the `.ktf` compiler source, parsed through the NEW reader
/// (`ReaderFace::Target`), compiled by the Rust oracle and
/// EXECUTED in the VM; the `result` global decodes as the rich
/// pair (verdict text plus the product rebuilt as a real
/// [`Bytecode`]). The self-applied assembly embeds its own input
/// as a datum — the same disclosed VM-only bracket the `.krf`
/// face rides (the r74/r85 envelope lineage, carried to the
/// target skin verbatim).
pub fn ktf_compile_rich_vm(
    items: &[ModuleItem],
    compiler_target_source: &str,
) -> Result<(String, Option<Bytecode>), String> {
    let prefix = target_items_stream_prefix(items);
    let assembled = format!("{prefix}\n{compiler_target_source}");
    let mut session = crate::session::Session::new();
    let program = pipeline::parse_target(&mut session, "target-compiler-parity-host", &assembled)
        .map_err(|diags| {
        format!("harness defect: the assembled target compiler program failed to parse: {diags:?}")
    })?;
    let findings = program.typecheck();
    if findings
        .iter()
        .any(|d| d.severity == crate::diagnostic::Severity::Error)
    {
        return Err(format!(
            "harness defect: the assembled target compiler program failed the checker: {findings:?}"
        ));
    }
    let bc = compile_program(&program.items).map_err(|err| {
        format!("harness defect: the assembled target compiler program failed to compile: {err}")
    })?;
    let mut vm =
        kerf_vm::Vm::with_io(bc, Box::new(kerf_vm::BufferIo::default())).map_err(|err| {
            format!("harness defect: the vm rejected the target compiler program: {err}")
        })?;
    vm.run().map_err(|err| vm_harness_failure_target(&err))?;
    let value = vm
        .global("result")
        .ok_or_else(|| "harness defect: no `result` global on the vm engine".to_string())?;
    let verdict =
        decode_verdict_vm(value, vm.heap()).map_err(|err| format!("harness defect: {err}"))?;
    let rebuilt = match &verdict {
        KrfVerdict::Tree(_) => Some(rebuild_bytecode(value, vm.heap())?),
        KrfVerdict::Error(_) => None,
    };
    Ok((verdict.text(), rebuilt))
}

/// The target-skin rich compile, dual engines — the step-4 twin of
/// `krf_compile_rich`: the same assembled target program parsed by
/// the NEW reader, driven through BOTH engines with the verdict
/// texts compared by the caller (the fixpoint's C(S) phase rides
/// this face; the input scale is the corpus's own, proven inside
/// the CP6/CP9 envelope on the seed skin).
pub fn ktf_compile_rich(
    items: &[ModuleItem],
    compiler_target_source: &str,
) -> Result<RichCompileRun, String> {
    let prefix = target_items_stream_prefix(items);
    let assembled = format!("{prefix}\n{compiler_target_source}");
    let decode_vm_rich =
        |value: &Value,
         heap: &Heap|
         -> Result<(KrfVerdict<kerf_compiler::CompileError>, Option<Bytecode>), String> {
            let verdict = decode_tagged(value, heap, dump_krf_section, rebuild_compile_error)?;
            let rebuilt = match &verdict {
                KrfVerdict::Tree(_) => Some(rebuild_bytecode(value, heap)?),
                KrfVerdict::Error(_) => None,
            };
            Ok((verdict, rebuilt))
        };
    let decode_plain =
        |value: &Value, heap: &Heap| -> Result<KrfVerdict<kerf_compiler::CompileError>, String> {
            decode_tagged(value, heap, dump_krf_section, rebuild_compile_error)
        };
    let ((vm_verdict, rebuilt), eval_verdict) = drive_dual_engines(
        "target-compiler-parity-host",
        "target compiler",
        &assembled,
        ReaderFace::Target,
        decode_vm_rich,
        decode_plain,
    )?;
    Ok(RichCompileRun {
        vm_text: vm_verdict.text(),
        eval_text: eval_verdict.text(),
        bytecode: rebuilt,
    })
}

/// Classify one VM rejection of the assembled target harness
/// program — the `harness_run_failure` twin for the target skin
/// (the r74 K165 discipline carried verbatim: the two budget faces
/// are the honest input envelope, everything else is a defect).
fn vm_harness_failure_target(err: &kerf_vm::RuntimeError) -> String {
    if matches!(
        err,
        kerf_vm::RuntimeError::BudgetExceeded { .. }
            | kerf_vm::RuntimeError::EvalDepthExceeded { .. }
    ) {
        format!(
            "harness limit: the .ktf compiler exceeded the vm engine's budget ({err}) \
             — the frozen subset's per-element recursion gives the harness a finite \
             input envelope; not a semantic drift"
        )
    } else {
        format!("harness defect: the .ktf compiler crashed on the vm engine: {err}")
    }
}

// ---------- the gate-B bytecode face on the production-chain skin ----------

/// The gate-B bytecode face (the r104 E5 batch-3 carry of the retired
/// `.krf` face): the source reads through the oracle front end, the
/// items compile through the oracle, and the `.ktf` compiler twin's
/// REBUILT product (both engines, through the production bridge)
/// must equal the oracle's own compilation byte-for-byte — the
/// `Bytecode: PartialEq` gate with the descriptor tables included.
pub fn gate_b_bytecode(case: &str, source: &str) -> Result<(), String> {
    let forms = kerf_reader::read_program(FileId(0), source)
        .map_err(|err| format!("gate B [{case}]: the reader rejected the source: {err}"))?;
    let oracle_items = kerf_expander::expand_program(&forms)
        .map_err(|err| format!("gate B [{case}]: the oracle rejected the source: {err}"))?;
    kerf_expander::load_program(&oracle_items)
        .map_err(|err| format!("gate B [{case}]: the oracle loader rejected: {err}"))?;
    let bc_oracle = kerf_compiler::compile_program(&oracle_items)
        .map_err(|err| format!("gate B [{case}]: oracle compile failed: {err}"))?;
    let run = ktf_compile_rich(&oracle_items, COMPILER_TARGET_SOURCE)
        .map_err(|err| format!("gate B [{case}]: {err}"))?;
    if run.vm_text != run.eval_text {
        return Err(format!(
            "gate B [{case}]: engines disagree: vm `{}` vs eval `{}`",
            run.vm_text, run.eval_text
        ));
    }
    let bc = run.bytecode.ok_or_else(|| {
        format!(
            "gate B [{case}]: the .ktf compiler rejected: {}",
            run.vm_text
        )
    })?;
    if bc == bc_oracle {
        Ok(())
    } else {
        Err(format!(
            "gate B [{case}]: bytecode drift (oracle {} protos / ktf {} protos)",
            bc_oracle.funcs.len(),
            bc.funcs.len()
        ))
    }
}

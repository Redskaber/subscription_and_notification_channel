//! The r104 target-skin composed chain (switch-window-plan §5.6.4,
//! stage0.md §9.99): the E5 batch-3 PRECONDITION — the `.krf`
//! composed chain's §9.87 formula driven with the five `.ktf`
//! twins through the production bridge, junction by junction, the
//! `.ktf` chain's OWN products feeding forward at every junction:
//!
//! ```text
//! compile(expand(read(lex(S))))
//!   == compile_ktf(expand_ktf(read_ktf(lex_ktf(S))))
//! ```
//!
//! The delta against the `.krf` composed chain is exactly two
//! things — the CHAIN PROGRAMS' skin (the `.ktf` twins instead of
//! the `.krf` originals) and the assembled harness's front-end
//! parse (the production bridge, `ReaderFace::Target`, instead of
//! the seed reader). The INPUT source and every ORACLE face stay
//! identical: the twins implement the S-expr read chain (`lexer.ktf`
//! mirrors `crates/kerf-reader/src/lexer.rs`), so `lex`,
//! `read_program`, the oracle expansion and the oracle compile are
//! the same single sources on both chains. The injection contracts
//! (byte table, form records, item records) are skin-less data —
//! only their TEXT skin is transcoded (`target_byte_table_prefix`
//! & co, the single-source prefix builders verbatim).
//!
//! Three staged junctions, each a differential gate (the §9.87
//! spine carried to the target skin):
//!
//! * **Junction 1 — the read chain**: the transcoded byte-table
//!   prefix with the `lexer.ktf` and `reader.ktf` twins, on both
//!   engines through the NEW reader; the `.ktf` reader's forms feed
//!   FORWARD (the expander consumes THESE forms, never the oracle's
//!   re-encoded ones). Gates: engines agree, and the token/tree
//!   axes match the oracle reader.
//! * **Junction 2 — the expansion layer**: the `.ktf` expander (the
//!   macro library prepended, one program) on those forms, both
//!   engines through the NEW reader; the rebuilt items feed
//!   forward. Gates: engines agree; the items are structurally
//!   identical to the oracle's expansion of the oracle's forms (the
//!   1.6 criterion), or the rejection keys match.
//! * **Junction 3 — the compile layer**: the `.ktf` compiler on
//!   those items, both engines through the NEW reader
//!   ([`crate::target_corpus::ktf_compile_rich`]); the product
//!   matches the oracle full pipeline's compile of the oracle's own
//!   items through the CP dump grammar (products and error keys).
//!
//! The routing is TOTAL (the §9.87.4 drift ledger carried over): a
//! source the oracle rejects at the reader layer verifies on
//! junction 1's error axis; an expander/loader rejection on
//! junction 2's; a compile rejection on junction 3's. Every case
//! lands in exactly one layer.
//!
//! Engine brackets (the r74/r85 K165-K167 discipline): the
//! evaluator envelope is finite; sources past it ride the VM-only
//! bracket face ([`composed_target_chain_parity_vm`]) with the
//! bracket disclosed — the selfhost own-sources are the canonical
//! cases.
//!
//! The tamper face ([`composed_target_chain_probes`]) proves the
//! chain DETECTS divergence at every junction — a chain that
//! cannot fail is not a chain (the FP8 lineage composed).

use kerf_compiler::compile_program;
use kerf_reader::read_program;
use kerf_span::FileId;

use crate::compiler_parity::{cp_error_key, oracle_analysis_dump};
use crate::composed_full_chain::ComposedLayer;
use crate::expander_parity::{decode_verdict, oracle_expansion, rebuild_items};
use crate::lexer_parity::reader_parity_full_target_with;
use crate::reader_parity::{KrfVerdict, drive_dual_engines};
use crate::target_corpus::{
    COMPILER_TARGET_SOURCE, LEXER_TARGET_SOURCE, assembled_expander_target_source,
    forms_target_spellable, ktf_compile_rich, target_forms_stream_prefix,
};

// ---------- the report ----------

/// The outcome of one target-skin composed-chain case (the §9.87
/// report shape carried to the `.ktf` twins — the junction fields
/// are skin-less).
#[derive(Debug, Clone)]
pub struct ComposedTargetChainReport {
    /// The case name (caller-supplied, for corpus attribution).
    pub case: String,
    /// The junction that decided the case (the drift ledger's
    /// routing key — the §9.87.4 layer set, shared with the `.krf`
    /// chain).
    pub layer: ComposedLayer,
    /// Junction 1 (the `.ktf` read chain): matched.
    pub read_matched: bool,
    /// Junction 2 (the `.ktf` expansion layer): `Some(matched)` when
    /// the chain fed it (vacuous — `None` — on a read-layer
    /// rejection).
    pub expand_matched: Option<bool>,
    /// Junction 3 (the `.ktf` compile layer): `Some(matched)` when
    /// the chain fed it.
    pub compile_matched: Option<bool>,
    /// Both engines agreed at every junction reached (trivially
    /// true for the VM-bracket face's read junction).
    pub engines_agree: bool,
    /// The whole chain matched (all reached junctions).
    pub matched: bool,
    /// The mismatch description when `!matched` — names the failing
    /// junction, never a bare product diff.
    pub drift: Option<String>,
}

impl ComposedTargetChainReport {
    /// The one-line failure form (the `failure_line` lineage —
    /// corpus manifests print this on drift).
    pub fn failure_line(&self) -> String {
        match &self.drift {
            Some(d) => format!("composed target chain FAIL [{}]: {}", self.case, d),
            None => format!("composed target chain PASS [{}]", self.case),
        }
    }
}

// ---------- the junction-2 target drive (the single-source core) ----------

/// The target-skin twin of `run_dual_rich` (junction 2's drive):
/// the assembled `.ktf` expander program on both engines through
/// the NEW reader, the VM side's items rebuilt while its heap is
/// alive — the same decoders, the same skeleton
/// (`drive_dual_engines`), only the front-end face differs. The
/// texts return as `String`s (both engines' verdicts — the caller
/// compares them as the engine-agreement gate).
fn run_dual_rich_target(
    assembled: &str,
) -> Result<(Option<Vec<kerf_core::ModuleItem>>, String, String), String> {
    let decode_vm_rich = |value: &kerf_vm::Value,
                          heap: &kerf_vm::Heap|
     -> Result<
        (
            KrfVerdict<crate::expander_parity::ParityError>,
            Option<Vec<kerf_core::ModuleItem>>,
        ),
        String,
    > {
        let verdict = decode_verdict(value, heap)?;
        let rebuilt = match &verdict {
            KrfVerdict::Tree(_) => Some(rebuild_items(value, heap)?),
            KrfVerdict::Error(_) => None,
        };
        Ok((verdict, rebuilt))
    };
    let ((vm_verdict, rebuilt), eval_verdict) = drive_dual_engines(
        "expander-parity-host.ktf",
        "target expander",
        assembled,
        crate::pipeline::ReaderFace::Target,
        decode_vm_rich,
        decode_verdict,
    )?;
    Ok((
        rebuilt,
        vm_verdict.text().to_string(),
        eval_verdict.text().to_string(),
    ))
}

// ---------- the composed case driver ----------

/// The plain face (dual engines at every junction).
pub fn composed_target_chain_parity(case: &str, source: &str) -> ComposedTargetChainReport {
    composed_target_chain_impl(case, source, LEXER_TARGET_SOURCE, None, None, true)
}

/// The VM-bracket face: junction 1 rides the VM alone (sources past
/// the evaluator's read-chain envelope — the `lexer.ktf`
/// own-source fixed point, the bracket lineage); junctions 2/3
/// stay dual.
pub fn composed_target_chain_parity_vm(case: &str, source: &str) -> ComposedTargetChainReport {
    composed_target_chain_impl(case, source, LEXER_TARGET_SOURCE, None, None, false)
}

/// The tamper face — one or more stage sources replaced to prove
/// the chain DETECTS divergence at every junction (a chain that
/// cannot fail is not a chain; the FP8 lineage composed on the
/// target skin). `None` rides the canonical `.ktf` twin source.
pub fn composed_target_chain_probes(
    case: &str,
    source: &str,
    lexer_target_source: Option<&str>,
    expander_target_source: Option<&str>,
    compiler_target_source: Option<&str>,
) -> ComposedTargetChainReport {
    let lexer = lexer_target_source.unwrap_or(LEXER_TARGET_SOURCE);
    composed_target_chain_impl(
        case,
        source,
        lexer,
        expander_target_source,
        compiler_target_source,
        // The tamper faces ride the dual bracket (small probe
        // sources — the brackets are a corpus-scale concern).
        true,
    )
}

fn composed_target_chain_impl(
    case: &str,
    source: &str,
    lexer_target_source: &str,
    expander_target_source: Option<&str>,
    compiler_target_source: Option<&str>,
    read_dual: bool,
) -> ComposedTargetChainReport {
    // ---- Junction 1: the .ktf read chain — the twins' forms feed
    // forward (the tamper face replaces the lexer twin; the dual
    // flag selects the engine bracket).
    let (read_report, ktf_forms) =
        reader_parity_full_target_with(case, source, lexer_target_source, read_dual);
    // The oracle routing: which layer owns this source's verdict?
    let oracle_forms = read_program(FileId(0), source);
    if !read_report.matched || !read_report.engines_agree {
        // A junction-1 drift or harness classification (defect /
        // limit) — the chain names it and never feeds forward.
        return ComposedTargetChainReport {
            case: case.to_string(),
            layer: ComposedLayer::Read,
            read_matched: false,
            expand_matched: None,
            compile_matched: None,
            engines_agree: read_report.engines_agree,
            matched: false,
            drift: read_report.drift,
        };
    }
    let oracle_forms = match oracle_forms {
        Err(_) => {
            // The oracle reader rejects: the matched read chain
            // already proved the .ktf chain rejects with the same
            // key (the error axis is part of `matched`), and a
            // matched chain with an oracle rejection produced no
            // forms. The ledger's Read row.
            let vacuously_clean = ktf_forms.is_none();
            let drift = if vacuously_clean {
                None
            } else {
                Some(
                    "junction 1: the oracle reader rejected but the .ktf chain produced forms"
                        .to_string(),
                )
            };
            return ComposedTargetChainReport {
                case: case.to_string(),
                layer: ComposedLayer::Read,
                read_matched: true,
                expand_matched: None,
                compile_matched: None,
                engines_agree: true,
                matched: vacuously_clean,
                drift,
            };
        }
        Ok(forms) => forms,
    };
    // A matched read chain over an oracle-readable source must have
    // produced forms (the feed's own invariant — a harness defect
    // otherwise).
    let ktf_forms = ktf_forms.unwrap_or_else(|| {
        // Unreachable in a consistent harness: matched implies the
        // tree axis is Ok, which implies forms. Treated as a defect,
        // never a silent pass.
        panic!("harness defect: junction 1 matched but produced no forms for {case}");
    });

    // ---- The junction-2 data boundary (the r103 exception ledger
    // instantiated on the injection face): form-record data
    // carrying an `i64::MIN` datum has NO target-skin text (the
    // magnitude overflows before the sign applies — see
    // `datum_target_spellable`). The corpus face carries those
    // cases through arithmetic-composition twins (switch-window-plan
    // §5.6.2); the composed chain classifies them at the boundary —
    // an honest disclosed row, never a silent re-spelling.
    if !forms_target_spellable(&ktf_forms) {
        return ComposedTargetChainReport {
            case: case.to_string(),
            layer: ComposedLayer::Expand,
            read_matched: true,
            expand_matched: None,
            compile_matched: None,
            engines_agree: true,
            matched: false,
            drift: Some(
                "harness boundary: the i64::MIN datum cannot ride the target skin's \
                 literal face — the r103 exception-ledger boundary (a negative literal \
                 with no positive counterpart), instantiated on the junction-2 \
                 data-injection face; the corpus face carries these cases through \
                 arithmetic-composition twins (switch-window-plan §5.6.2)"
                    .to_string(),
            ),
        };
    }

    // ---- Junction 2: the expansion layer — the .ktf expander on
    // the .ktf reader's own forms, both engines through the NEW
    // reader.
    let expander = expander_target_source
        .map(|s| s.to_string())
        .unwrap_or_else(assembled_expander_target_source);
    let prefix = target_forms_stream_prefix(&ktf_forms);
    let assembled = format!("{prefix}\n{expander}");
    let (rebuilt, vm_text, eval_text) = match run_dual_rich_target(&assembled) {
        Ok(run) => run,
        Err(harness) => {
            // The r74 classification rides the string itself
            // ("harness defect: …" / "harness limit: …").
            return ComposedTargetChainReport {
                case: case.to_string(),
                layer: ComposedLayer::Expand,
                read_matched: true,
                expand_matched: Some(false),
                compile_matched: None,
                engines_agree: false,
                matched: false,
                drift: Some(harness),
            };
        }
    };
    if vm_text != eval_text {
        return ComposedTargetChainReport {
            case: case.to_string(),
            layer: ComposedLayer::Expand,
            read_matched: true,
            expand_matched: Some(false),
            compile_matched: None,
            engines_agree: false,
            matched: false,
            drift: Some(format!(
                "junction 2: engines disagree: vm `{vm_text}` vs eval `{eval_text}`"
            )),
        };
    }
    // The oracle's own expansion of the oracle's forms — the
    // differential at this junction.
    match oracle_expansion(&oracle_forms) {
        Err(oracle_key) => {
            // The ledger's Expand row: the .ktf expander must reject
            // with the same parity key (shape included — the text
            // comparison pairs Error with Error).
            let matched = vm_text == oracle_key && rebuilt.is_none();
            let drift = if matched {
                None
            } else {
                Some(format!(
                    "junction 2: oracle `{oracle_key}` vs ktf `{vm_text}`"
                ))
            };
            ComposedTargetChainReport {
                case: case.to_string(),
                layer: ComposedLayer::Expand,
                read_matched: true,
                expand_matched: Some(matched),
                compile_matched: None,
                engines_agree: true,
                matched,
                drift,
            }
        }
        Ok(oracle_items) => {
            // The tree identity gate (the 1.6 criterion in-chain):
            // the .ktf expander's items on the .ktf forms equal the
            // oracle's items on the oracle's forms.
            let Some(items) = rebuilt else {
                return ComposedTargetChainReport {
                    case: case.to_string(),
                    layer: ComposedLayer::Expand,
                    read_matched: true,
                    expand_matched: Some(false),
                    compile_matched: None,
                    engines_agree: true,
                    matched: false,
                    drift: Some(format!(
                        "junction 2: the oracle expanded but the .ktf expander rejected: {vm_text}"
                    )),
                };
            };
            if items != oracle_items {
                return ComposedTargetChainReport {
                    case: case.to_string(),
                    layer: ComposedLayer::Expand,
                    read_matched: true,
                    expand_matched: Some(false),
                    compile_matched: None,
                    engines_agree: true,
                    matched: false,
                    drift: Some(
                        "junction 2: tree drift between the .ktf expander and the oracle"
                            .to_string(),
                    ),
                };
            }
            // ---- Junction 3: the compile layer — the .ktf compiler
            // on the .ktf expander's own items, both engines through
            // the NEW reader (the step-4 rich drive, fed forward).
            let compiler = compiler_target_source.unwrap_or(COMPILER_TARGET_SOURCE);
            let run = match ktf_compile_rich(&items, compiler) {
                Ok(run) => run,
                Err(harness) => {
                    return ComposedTargetChainReport {
                        case: case.to_string(),
                        layer: ComposedLayer::Compile,
                        read_matched: true,
                        expand_matched: Some(true),
                        compile_matched: Some(false),
                        engines_agree: false,
                        matched: false,
                        drift: Some(harness),
                    };
                }
            };
            // The engine gate: the rich run carries both verdict
            // texts (the same comparison the .krf face's plain
            // drive makes — single source of the agreement face).
            let engines_agree = run.vm_text == run.eval_text;
            // The oracle full pipeline's compile of the oracle's own
            // items (the §9.87 final face — junction 2 just proved
            // the item trees identical, so both faces must agree):
            // products compare through the CP dump grammar, errors
            // through the compile-error key.
            let (compile_matched, drift) = match compile_program(&oracle_items) {
                Ok(bc) => {
                    let oracle_full_text = oracle_analysis_dump(&bc);
                    let matched =
                        engines_agree && run.bytecode.is_some() && run.vm_text == oracle_full_text;
                    let drift = if matched {
                        None
                    } else if !engines_agree {
                        Some(format!(
                            "junction 3: engines disagree: vm `{}` vs eval `{}` (oracle `{}`)",
                            run.vm_text, run.eval_text, oracle_full_text
                        ))
                    } else if run.bytecode.is_none() {
                        Some(format!(
                            "junction 3: the oracle compiled but the .ktf compiler rejected: {}",
                            run.vm_text
                        ))
                    } else {
                        Some(format!(
                            "junction 3: oracle `{}` vs ktf `{}`",
                            oracle_full_text, run.vm_text
                        ))
                    };
                    (matched, drift)
                }
                Err(err) => {
                    let oracle_key = cp_error_key(&err);
                    let matched =
                        engines_agree && run.bytecode.is_none() && run.vm_text == oracle_key;
                    let drift = if matched {
                        None
                    } else if !engines_agree {
                        Some(format!(
                            "junction 3: engines disagree: vm `{}` vs eval `{}` (oracle `{}`)",
                            run.vm_text, run.eval_text, oracle_key
                        ))
                    } else {
                        Some(format!(
                            "junction 3: oracle `{oracle_key}` vs ktf `{}`",
                            run.vm_text
                        ))
                    };
                    (matched, drift)
                }
            };
            ComposedTargetChainReport {
                case: case.to_string(),
                layer: ComposedLayer::Compile,
                read_matched: true,
                expand_matched: Some(true),
                compile_matched: Some(compile_matched),
                engines_agree,
                matched: compile_matched,
                drift,
            }
        }
    }
}

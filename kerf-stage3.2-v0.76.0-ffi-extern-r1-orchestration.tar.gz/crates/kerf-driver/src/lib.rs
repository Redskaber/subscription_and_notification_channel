//! kerf-driver — the compiler entry point / pipeline orchestration
//! (Layer 8, stage-0-plan row 0.8; TD-003 final resolution step).
//!
//! Charter: read -> expand -> {compile -> VM, eval} pipeline assembly,
//! session/file interning, the diagnostics rendering closure (TD-001
//! payoff — line/column derived at render time), and the CLI/REPL
//! surface. Stages interact through data contracts only (SOP §11);
//! errors are data (§12.2): every stage failure becomes a
//! [`Diagnostic`] and is rendered in one pass.
//!
//! Layout: `session` (file interning), `line_index` (the TD-001
//! byte-offset -> line/column derivation), `diagnostic` (the §8.7
//! structure, Stage 0 slice), `render` (rustc-flavored rendering),
//! `pipeline` (dual-engine orchestration), `parity` (the Stage
//! 1.4 acceptance-corpus contract), `repl` (session-replay
//! state machine), `cli` (the `kerf` binary face). The executable
//! entry is `src/main.rs` (bin name `kerf`).

mod cli;
mod compiler_parity;
mod composed_full_chain;
mod composed_target_chain;
mod diagnostic;
mod expander_parity;
mod fixpoint;
mod lexer_parity;
mod line_index;
mod parity;
mod pipeline;
mod reader_parity;
mod render;
mod repl;
mod session;
mod skin_transcoder;
mod target_corpus;

// Explicit re-export list (SOP §10.1 rule 4 — glob re-exports are forbidden).
pub use cli::{Command, parse_args, run_cli, usage, version};
pub use compiler_parity::{
    cp_error_key, items_stream_prefix, oracle_analysis_dump, rebuild_bytecode,
};
pub use composed_full_chain::{ComposedLayer, dump_faithfulness_witness};
pub use composed_target_chain::{
    ComposedTargetChainReport, composed_target_chain_parity, composed_target_chain_parity_vm,
    composed_target_chain_probes,
};
pub use diagnostic::{Diagnostic, DiagnosticCode, Severity};
pub use expander_parity::{forms_stream_prefix, oracle_dump_items, reconstruct_expand_error};
pub use fixpoint::{
    FixpointProducts, FixpointReport, SemanticDigest, SemanticProtoDigest,
    fixpoint_products_target, fixpoint_selfhost_compiler_target, semantic_projection,
};
pub use lexer_parity::{
    FullChainReport, byte_table_prefix, oracle_token_dump, reader_parity_full_target_feed_vm,
    reader_parity_full_target_with, reader_parity_full_target_with_feed,
};
pub use line_index::LineIndex;
pub use parity::{
    AlphaMap, CorpusCase, EquivalenceReport, Expectation, Observed, alpha_item_equal,
    alpha_items_equal, parse_directive, validate, validate_all, validate_target,
};
pub use pipeline::{
    CheckOutcome, EmitCOutcome, Engine, ParityReport, ParsedProgram, ReaderFace, RunOutcome,
    check_source, check_source_with, emit_c_source, emit_c_source_with, parse, parse_target,
    run_parity_source, run_parity_source_with, run_source, run_source_with,
};
pub use reader_parity::{oracle_dump, token_table_prefix};
pub use render::{column_of, render_diagnostics};
pub use repl::{Repl, ReplEvent};
pub use session::Session;
pub use skin_transcoder::{TranscodeError, transcode_program};
pub use target_corpus::{
    COMPILER_TARGET_SOURCE, EXPANDER_TARGET_SOURCE, LEXER_TARGET_SOURCE, MACRO_TARGET_SOURCE,
    READER_TARGET_SOURCE, assembled_expander_target_source, datum_target_spellable,
    forms_target_spellable, gate_b_bytecode, ktf_compile_rich, ktf_compile_rich_vm,
    read_target_source_for_bootstrap, target_byte_table_prefix, target_forms_stream_prefix,
    target_items_stream_prefix, target_token_table_prefix,
};

// Since v0.28.0 coordinate types are imported directly from kerf-span
// (the no-forwarding rule, stage0.md §9.59; SOP §18.5 v15.2).

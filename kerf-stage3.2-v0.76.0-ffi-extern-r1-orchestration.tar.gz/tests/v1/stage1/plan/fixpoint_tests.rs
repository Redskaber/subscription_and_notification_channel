//! The 2.5 fixpoint window tests (stage-2-plan §2 row 2.5; §9.89).
//!
//! MUV ① — the rebuild face: the opcode reverse table (the
//! single-source pair with `kind_name`), the `.krf` compiler's
//! product rebuilt into a real `Bytecode` (field-complete — the
//! generation axis included), and the fail-closed malformed-product
//! family.
//! MUV ② — the fixpoint driver: the self-hosted compiler compiled
//! by itself, EXECUTED in the VM, reproduces its own compilation
//! byte-for-byte (SOP §21.3 exit criterion (2)).
//! MUV ③ — the elevated gate B: the corpus sweep with the `.krf`
//! side swapped to the rebuilt product (the full-pipeline dual
//! caliber).
//!
//! Distribution (§9.4.3): four positive faces (roundtrip / the
//! oracle-match with the generation axis / the corpus sweep / the
//! fixpoint) against seven negative faces (unknown opcode name ×2
//! — table and product — negative operand / bad generation /
//! truncated proto / unknown section + error verdict / the
//! verify-rejected product): the sub-stage's own negative majority
//! carries the fail-closed contract, and the two integration faces
//! (sweep + fixpoint) are the cross-stage consumption rows (the
//! front-end chain feeding the compiler product face).

use kerf::compiler::{Opcode, compile_program};
use kerf::driver::{COMPILER_TARGET_SOURCE, ktf_compile_rich, rebuild_bytecode};
use kerf::reader::read_program;
use kerf::span::{ExpansionId, FileId};
use kerf::vm::{Heap, HeapObj, Value};

use std::rc::Rc;

/// The corpus directory (the sweep stays explicit — the sibling
/// tests' convention).
/// Deep trees and the self-applied assembly recurse through the
/// harness's Rust walkers (the emit/parse faces walk the giant
/// datum); the demand-allocated large hint costs nothing (the
/// sibling tests' convention).
fn deep_stack<F>(body: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::Builder::new()
        .stack_size(768 * 1024 * 1024)
        .spawn(body)
        .expect("spawn the deep-stack thread")
        .join()
        .expect("the deep-stack thread finished cleanly");
}

// ---------- fixture builders (the malformed-product family) ----------

fn strv(text: &str) -> Value {
    Value::Str(Rc::from(text))
}

/// Build one right-nested pair chain in the heap (the flat record
/// shape every decoder walks).
fn chain(heap: &mut Heap, vals: Vec<Value>) -> Value {
    let mut acc = Value::Nil;
    for v in vals.into_iter().rev() {
        let r = heap.alloc(HeapObj::Pair(v, acc));
        acc = Value::Pair(r);
    }
    acc
}

// ---------- MUV ①: the opcode reverse table ----------

#[test]
fn opcode_reverse_table_roundtrips_all_25() {
    for op in Opcode::ALL {
        assert_eq!(
            Opcode::from_kind_name(op.kind_name()),
            Some(op),
            "the reverse table must invert `{}`",
            op.kind_name()
        );
    }
    assert_eq!(Opcode::ALL.len(), 25, "the opcode table's pinned size");
}

#[test]
fn opcode_reverse_table_rejects_unknown_names() {
    assert_eq!(Opcode::from_kind_name("no-such-op"), None);
    assert_eq!(Opcode::from_kind_name(""), None);
    assert_eq!(Opcode::from_kind_name("PushConst"), None, "case-sensitive");
    assert_eq!(
        Opcode::from_kind_name("push_const"),
        None,
        "kebab form only"
    );
}

// ---------- MUV ①: the rebuild face, positives ----------

#[test]
fn rebuild_matches_oracle_and_carries_generations() {
    deep_stack(|| {
        // A macro use whose expansion introduces generation 1: the
        // (if ...) product node carries use_gen + 1, and every
        // instruction it emits must land the generation in the
        // rebuilt debug spans — the axis the dump text leaves
        // outside (the 2.5 addendum's whole point).
        let source = "(define-syntax my-if (syntax-rules nil ((_ c a b) (if c a b))))\n\
                      (define result (my-if #t 1 2))\n";
        let forms = read_program(FileId(0), source).expect("the fixture reads");
        let items = kerf::expander::expand_program(&forms).expect("the fixture expands");
        let oracle = compile_program(&items).expect("the oracle compiles the fixture");
        // The axis sanity: the oracle's own debug table carries a
        // non-ROOT generation for this fixture (else the test would
        // be vacuous on the generation axis).
        let oracle_gens: Vec<_> = oracle
            .funcs
            .iter()
            .flat_map(|f| f.debug_info.iter())
            .map(|s| s.expansion_id)
            .collect();
        assert!(
            oracle_gens.iter().any(|g| *g != ExpansionId::ROOT),
            "the fixture must exercise the generation axis"
        );
        let run = ktf_compile_rich(&items, COMPILER_TARGET_SOURCE).expect("the compiler twin runs");
        let bc = run.bytecode.expect("the compiler twin accepts the fixture");
        assert_eq!(bc, oracle, "the rebuilt product equals the oracle's");
        // And the generations actually landed (not defaulted).
        let krf_gens: Vec<_> = bc
            .funcs
            .iter()
            .flat_map(|f| f.debug_info.iter())
            .map(|s| s.expansion_id)
            .collect();
        assert_eq!(krf_gens, oracle_gens, "the debug generations match");
    });
}

// ---------- MUV ①: the rebuild face, negatives ----------

#[test]
fn rebuild_rejects_unknown_opcode_name() {
    let mut heap = Heap::default();
    let dbg_rec = chain(&mut heap, vec![strv("0"), strv("0"), Value::Int(0)]);
    let dbg = chain(&mut heap, vec![strv("dbg"), dbg_rec]);
    // The kebab table knows 25 names; a fabricated one must fail
    // closed at the reverse lookup.
    let insn = chain(
        &mut heap,
        vec![strv("no-such-op"), Value::Int(0), Value::Int(0)],
    );
    let code = chain(&mut heap, vec![strv("code"), insn]);
    let caps = chain(&mut heap, vec![strv("caps")]);
    let proto = chain(
        &mut heap,
        vec![
            strv("proto"),
            Value::Nil,
            Value::Int(0),
            Value::Int(0),
            caps,
            code,
            dbg,
        ],
    );
    let funcs = chain(&mut heap, vec![strv("funcs"), proto]);
    let product = ok_product(&mut heap, funcs);
    let err =
        rebuild_bytecode(&product, &heap).expect_err("an unknown opcode name must fail closed");
    assert!(
        err.contains("unknown opcode"),
        "the error names the defect: {err}"
    );
}

/// The ok-shaped wrapper around one funcs section (globals/consts
/// pre-built — the nested-borrow discipline).
fn ok_product(heap: &mut Heap, funcs: Value) -> Value {
    let globals = chain(heap, vec![strv("globals")]);
    let consts = chain(heap, vec![strv("consts")]);
    chain(heap, vec![strv("ok"), funcs, globals, consts])
}

#[test]
fn rebuild_rejects_negative_operand() {
    let mut heap = Heap::default();
    let dbg_rec = chain(&mut heap, vec![strv("0"), strv("0"), Value::Int(0)]);
    let dbg = chain(&mut heap, vec![strv("dbg"), dbg_rec]);
    let insn = chain(&mut heap, vec![strv("halt"), Value::Int(-1), Value::Int(0)]);
    let code = chain(&mut heap, vec![strv("code"), insn]);
    let caps = chain(&mut heap, vec![strv("caps")]);
    let proto = chain(
        &mut heap,
        vec![
            strv("proto"),
            Value::Nil,
            Value::Int(0),
            Value::Int(0),
            caps,
            code,
            dbg,
        ],
    );
    let funcs = chain(&mut heap, vec![strv("funcs"), proto]);
    let product = ok_product(&mut heap, funcs);
    let err = rebuild_bytecode(&product, &heap).expect_err("a negative operand must fail closed");
    assert!(
        err.contains("negative"),
        "the error names the defect: {err}"
    );
}

#[test]
fn rebuild_rejects_bad_generation() {
    let mut heap = Heap::default();
    let dbg_rec = chain(&mut heap, vec![strv("0"), strv("0"), Value::Int(-3)]);
    let dbg = chain(&mut heap, vec![strv("dbg"), dbg_rec]);
    let insn = chain(&mut heap, vec![strv("halt"), Value::Int(0), Value::Int(0)]);
    let code = chain(&mut heap, vec![strv("code"), insn]);
    let caps = chain(&mut heap, vec![strv("caps")]);
    let proto = chain(
        &mut heap,
        vec![
            strv("proto"),
            Value::Nil,
            Value::Int(0),
            Value::Int(0),
            caps,
            code,
            dbg,
        ],
    );
    let funcs = chain(&mut heap, vec![strv("funcs"), proto]);
    let product = ok_product(&mut heap, funcs);
    let err =
        rebuild_bytecode(&product, &heap).expect_err("a negative generation must fail closed");
    assert!(
        err.contains("generation"),
        "the error names the defect: {err}"
    );
}

#[test]
fn rebuild_rejects_truncated_proto() {
    let mut heap = Heap::default();
    // Six fields instead of seven: the arity check fires.
    let proto = chain(
        &mut heap,
        vec![strv("proto"), Value::Nil, Value::Int(0), Value::Int(0)],
    );
    let funcs = chain(&mut heap, vec![strv("funcs"), proto]);
    let product = ok_product(&mut heap, funcs);
    let err = rebuild_bytecode(&product, &heap).expect_err("a truncated proto must fail closed");
    assert!(err.contains("fields"), "the error names the defect: {err}");
}

#[test]
fn rebuild_rejects_unknown_section_and_error_verdict() {
    let mut heap = Heap::default();
    // An unknown section tag.
    let weird = chain(&mut heap, vec![strv("weird")]);
    let product = ok_product(&mut heap, weird);
    let err = rebuild_bytecode(&product, &heap).expect_err("an unknown section must fail closed");
    assert!(
        err.contains("unknown product section"),
        "the error names the defect: {err}"
    );

    // The error verdict: the rebuild face owns the ok axis only.
    let err_verdict = chain(
        &mut heap,
        vec![strv("err"), strv("depth"), Value::Int(1025)],
    );
    let err =
        rebuild_bytecode(&err_verdict, &heap).expect_err("the error verdict must fail closed");
    assert!(
        err.contains("ok product"),
        "the error names the defect: {err}"
    );
}

#[test]
fn rebuild_rejects_a_product_that_fails_verify() {
    let mut heap = Heap::default();
    // Structurally well-formed, semantically broken: a jump to a pc
    // past the code length — `Bytecode::verify` is the gate (a
    // rebuilt product is a loadable program or it is an error).
    let dbg_rec = chain(&mut heap, vec![strv("0"), strv("0"), Value::Int(0)]);
    let dbg = chain(&mut heap, vec![strv("dbg"), dbg_rec]);
    let jump = chain(&mut heap, vec![strv("jump"), Value::Int(7), Value::Int(0)]);
    let insn = chain(&mut heap, vec![strv("halt"), Value::Int(0), Value::Int(0)]);
    let code = chain(&mut heap, vec![strv("code"), jump, insn]);
    let caps = chain(&mut heap, vec![strv("caps")]);
    let proto = chain(
        &mut heap,
        vec![
            strv("proto"),
            Value::Nil,
            Value::Int(0),
            Value::Int(0),
            caps,
            code,
            dbg,
        ],
    );
    let funcs = chain(&mut heap, vec![strv("funcs"), proto]);
    let product = ok_product(&mut heap, funcs);
    let err = rebuild_bytecode(&product, &heap).expect_err("an out-of-range jump must fail verify");
    assert!(err.contains("verify"), "the error names the gate: {err}");
}

// ---------- MUV ③: the elevated gate B, corpus sweep ----------

// ---------- MUV ②: the fixpoint driver ----------
//
// The gate-B elevated corpus sweep (the .krf expander+compiler
// chain over the whole corpus, gate_b_elevated) retired with the
// r104 E5 batch-3 teardown — its live successor is the composed
// TARGET chain's junction-2/3 sweeps and the target-face
// gate_b_bytecode (the production-chain skin, in-tree).
//
// The seed-skin fixpoint driver (the `.krf` compiler compiling
// itself twice) retired with the r104 E5 batch-3 teardown — the
// `.krf` originals left the tree and the production-chain fixpoint
// is the TARGET twin's own face
// (`fixpoint_selfhost_compiler_target`, verified in
// `target_fixpoint_tests.rs` since r101; the seed face's record
// rides the audit's historical sections).

//! The C transpilation backend e2e (Stage 2.6, stage0.md §9.92) —
//! the cc-gated verification face of the chain-external backend.
//!
//! Constitutional gate: cc is a HOST tool, never a build dependency
//! of the kerf compiler — every test here checks `cc` availability
//! first and skips WITH DISCLOSURE when absent (the r90 adjudication
//! II basis: skip-with-disclosure, not failure). In a cc-present
//! environment every test runs for real: emit → cc → execute.
//!
//! Two verification channels:
//! - **hand-built bytecode** (direct `emit_c` on constructed
//!   products): the value-display parity face — the C binary's halt
//!   value must byte-match the Rust `Value` Display form, including
//!   the shortest-round-trip float battery (the hardest parity face
//!   in the backend);
//! - **source programs** (the real pipeline): stdout byte-parity
//!   between the VM engine (in-process) and the C-transpiled binary
//!   — declaration-only programs expose `write-line` outputs, so the
//!   value channel rides a check-wrapped epilogue (`= <global>
//!   <literal>` → PASS/FAIL write-line) derived from each case.
//!
//! The full-corpus C replay is the `#[ignore]`d sweep at the bottom
//! (heavy: one cc invocation per corpus case; run explicitly:
//! `cargo test --release --test runner c_backend -- --ignored`).
//!
//! Toolchain-pairing hygiene (the v0.73.0 incident): ambient
//! environment variables can pair the emitted binary's dynamic
//! loader with a foreign libc — a Nix dev-shell incident killed every
//! cc-built case at load (exit 127, `__pointer_chk_guard` unresolved
//! against a mismatched glibc) while the tree itself was green on a
//! consistent toolchain. Both process boundaries here are therefore
//! hermetic: the cc link and the binary load run with the contaminant
//! variables scrubbed. Three faces pin the design — the scrub
//! registration (unit), the poison lethality on unguarded boundaries
//! with the real loader-abort text feeding the classifier (negative
//! control), and the ambient incident replay through the whole suite
//! (`scripts/testing/replay-poisoned-ambient.sh`) — and a loader
//! abort is reported as the environment-pairing defect it is instead
//! of surfacing as bare exit-code mismatches or a broken-pipe panic.

use std::io::Write as _;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::sync::OnceLock;

use kerf::cbackend::emit_c;
use kerf::compiler::{Bytecode, FuncProto, Instr, Opcode};
use kerf::core::LiteralValue;
use kerf::driver::{Engine, Expectation, Session, run_source};
use kerf::span::{ByteOffset, ExpansionId, FileId, Span};
use kerf::vm::Value;

const WORK_DIR: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/target/cbackend-e2e");

/// The link-boundary contaminant set: ambient variables that can
/// inject a foreign header set or libc into the cc link. Scrubbing
/// them is safe in both worlds — a plain host cc never needs them
/// for its default libc, and a Nix-style wrapper bakes its own paths
/// into the link line — while letting them through can silently pair
/// a foreign dynamic loader with the linked libc (the v0.73.0
/// incident: an interpreter that no longer exports the private
/// pointer-guard symbol met a glibc that still references it).
const LINK_CONTAMINANTS: &[&str] = &[
    "LIBRARY_PATH",
    "CPATH",
    "C_INCLUDE_PATH",
    "CPLUS_INCLUDE_PATH",
    "OBJC_INCLUDE_PATH",
    "COMPILER_PATH",
    "GCC_EXEC_PREFIX",
    "LD_RUN_PATH",
];

/// The load-boundary contaminant set: loader variables that override
/// the rpath cc baked in and hijack library resolution at load time
/// (`LD_LIBRARY_PATH` outranks `DT_RUNPATH` in the loader's search
/// order; the `DYLD_*` twins are the same class on the other major
/// Unix).
const RUN_CONTAMINANTS: &[&str] = &[
    "LD_LIBRARY_PATH",
    "LD_PRELOAD",
    "LD_AUDIT",
    "DYLD_LIBRARY_PATH",
    "DYLD_INSERT_LIBRARIES",
];

/// The chain-external gate: is a host cc reachable?
fn cc_available() -> bool {
    static AVAIL: OnceLock<bool> = OnceLock::new();
    *AVAIL.get_or_init(|| {
        Command::new("cc")
            .arg("--version")
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .status()
            .is_ok_and(|s| s.success())
    })
}

/// The disclosure line for a skipped case (the gate text is pinned:
/// the same sentence every skip prints, so absence in a log is a
/// signal, not silence).
fn skip_disclosure(name: &str) -> String {
    format!(
        "skip: `{name}` — cc unavailable (the chain-external gate: skip with disclosure, not failure)"
    )
}

/// Gate one test; prints the disclosure and returns false when the
/// host lacks cc.
fn gate(name: &str) -> bool {
    if cc_available() {
        true
    } else {
        eprintln!("{}", skip_disclosure(name));
        false
    }
}

fn work_dir() -> PathBuf {
    let dir = PathBuf::from(WORK_DIR);
    std::fs::create_dir_all(&dir).expect("create the e2e work dir");
    dir
}

/// A fresh `cc` command with the link-boundary hygiene applied — the
/// single choke point every cc spawn in this file goes through
/// (§20.3 same-class-path rule: one boundary, one scrub).
fn cc_scrubbed() -> Command {
    let mut cmd = Command::new("cc");
    for var in LINK_CONTAMINANTS {
        cmd.env_remove(var);
    }
    cmd
}

/// A fresh command for one built binary with the load-boundary
/// hygiene applied — the single choke point every binary run in this
/// file goes through.
fn bin_scrubbed(bin: &Path) -> Command {
    let mut cmd = Command::new(bin);
    for var in RUN_CONTAMINANTS {
        cmd.env_remove(var);
    }
    cmd
}

/// Loader-abort markers: the texts the dynamic loader prints when the
/// interpreter/libc pairing is broken. A transpiled kerf binary only
/// ever exits 0 or 1 (the shim's contract), so exit 127 or any of
/// these markers means the environment killed the child before
/// `main` ran — never an emitter bug.
fn is_loader_abort(code: i32, stderr: &str) -> bool {
    code == 127
        || stderr.contains("symbol lookup error")
        || stderr.contains("error while loading shared libraries")
        || stderr.contains("cannot open shared object file")
        || stderr.contains("GLIBC_PRIVATE")
}

/// The actionable report for a loader abort: name the defect class
/// (environment toolchain pairing, not the emitter) and the way out.
fn loader_abort_report(bin: &Path, code: i32, stderr: &str) -> String {
    format!(
        "the transpiled binary `{}` died at load (code {code}) — the \
         host toolchain paired a foreign dynamic loader with the linked \
         libc:\n  {stderr}\nthis is an environment pairing defect (e.g. a \
         dev-shell mixing a host ld.so with a store glibc, or a cc \
         wrapper built against a different glibc revision), not an \
         emitter bug; re-run inside one consistent toolchain",
        bin.display()
    )
}

/// Compile one C translation unit with the host cc; panics with the
/// compiler's stderr on failure (an emitter bug must fail loudly
/// here, never pass a broken product through).
fn cc_build(name: &str, c_source: &str, extra: &[&str]) -> PathBuf {
    let dir = work_dir();
    let cpath = dir.join(format!("{name}.c"));
    std::fs::write(&cpath, c_source).expect("write the C source");
    let bin = dir.join(name);
    let out = cc_scrubbed()
        .arg(&cpath)
        .args(extra)
        .arg("-o")
        .arg(&bin)
        .output()
        .expect("spawn cc");
    assert!(
        out.status.success(),
        "cc rejected `{name}` (an emitter bug):\n{}",
        String::from_utf8_lossy(&out.stderr)
    );
    bin
}

/// Run a built binary with piped stdin; returns (code, stdout,
/// stderr). The stdin feed is best effort — a child that exits before
/// consuming stdin (a program that never reads, or one killed at
/// load) must not mask its real exit status behind a broken-pipe
/// panic — and a loader abort fails fast with the pairing diagnostic
/// instead of surfacing as bare exit-code mismatches.
fn run_bin(bin: &Path, stdin_lines: &[&str]) -> (i32, String, String) {
    let mut child = bin_scrubbed(bin)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .expect("spawn the transpiled binary");
    if let Some(mut stdin) = child.stdin.take() {
        for line in stdin_lines {
            if writeln!(stdin, "{line}").is_err() {
                break;
            }
        }
    }
    let out = child.wait_with_output().expect("collect the binary's exit");
    let code = out.status.code().unwrap_or(-1);
    let stdout = String::from_utf8_lossy(&out.stdout).into_owned();
    let stderr = String::from_utf8_lossy(&out.stderr).into_owned();
    assert!(
        !is_loader_abort(code, &stderr),
        "{}",
        loader_abort_report(bin, code, &stderr)
    );
    (code, stdout, stderr)
}

/// The VM engine's observable contract for a source program
/// (outputs + the halt value's display line, exit code) — the exact
/// face `kerf run` prints.
fn vm_run(source: &str, stdin_lines: &[&str]) -> (i32, String) {
    let mut session = Session::new();
    let input: Vec<String> = stdin_lines.iter().map(|s| s.to_string()).collect();
    match run_source(&mut session, "e2e.krf", source, Engine::Vm, &input) {
        Ok(outcome) => {
            let mut text = String::new();
            for line in &outcome.outputs {
                text.push_str(line);
                text.push('\n');
            }
            if outcome.value != Value::Nil {
                text.push_str(&outcome.value_display());
                text.push('\n');
            }
            (0, text)
        }
        Err(_) => (1, String::new()),
    }
}

fn compile_source(source: &str) -> Bytecode {
    let forms = kerf::reader::read_program(FileId(0), source).expect("read");
    let items = kerf::expander::expand_program(&forms).expect("expand");
    kerf::compiler::compile_program(&items).expect("compile")
}

/// The target-skin twin of [`compile_source`] (the W-3.2 extern
/// family's native face — the production skin).
fn compile_source_target(source: &str) -> Bytecode {
    let forms = kerf::reader::read_target_program(FileId(0), source).expect("read");
    let items = kerf::expander::expand_program(&forms).expect("expand");
    kerf::compiler::compile_program(&items).expect("compile")
}

fn fix_span() -> Span {
    Span::new(FileId(0), ByteOffset(0), ByteOffset(1), ExpansionId::ROOT)
        .expect("test fixture span must be well-formed")
}

/// A hand-built entry proto that pushes one constant and halts — the
/// direct value-display probe (the halt pops it; `kerf run` prints
/// it because the depth is 1).
fn display_probe(lit: LiteralValue) -> Bytecode {
    let mut proto = FuncProto::new(None, 0, 0);
    proto.code = vec![
        Instr::with_a(Opcode::PushConst, 0),
        Instr::new(Opcode::Halt),
    ];
    proto.debug_info = vec![fix_span(); 2];
    Bytecode {
        consts: vec![lit],
        funcs: vec![proto],
        ..Default::default()
    }
}

/// One display-parity case: the C binary's stdout must equal what
/// `kerf run` would print — the value's Display line, or nothing at
/// all for a nil halt (the driver's nil-silence contract).
fn assert_display_parity(name: &str, lit: LiteralValue) {
    let value = Value::from_literal(&lit, &mut kerf::vm::Heap::default());
    let expected = if value == Value::Nil {
        String::new()
    } else {
        format!("{value}\n")
    };
    let bin = cc_build(name, &emit_c(&display_probe(lit)).expect("emit"), &[]);
    let (code, stdout, stderr) = run_bin(&bin, &[]);
    assert_eq!(code, 0, "exit: {stderr}");
    assert_eq!(stdout, expected, "display parity for {name}");
}

// ---------- the cc gate itself ----------

#[test]
fn gate_disclosure_text_is_pinned_and_gate_probes_cleanly() {
    // Pure face: the disclosure sentence is fixed (report over
    // silence), and the probe itself never panics with or without
    // cc. In a cc-present environment the gate simply opens.
    let text = skip_disclosure("probe-case");
    assert!(text.starts_with("skip: `probe-case`"));
    assert!(text.contains("cc unavailable"));
    assert!(text.contains("skip with disclosure, not failure"));
    let _ = cc_available();
}

// ---------- hand-built display parity ----------

#[test]
fn display_parity_immediates() {
    if !gate("display-parity-immediates") {
        return;
    }
    assert_display_parity("dp-int-42", LiteralValue::Int(42));
    assert_display_parity("dp-int-min", LiteralValue::Int(i64::MIN));
    assert_display_parity("dp-int-max", LiteralValue::Int(i64::MAX));
    assert_display_parity("dp-bool", LiteralValue::Bool(true));
    assert_display_parity("dp-bool-f", LiteralValue::Bool(false));
    assert_display_parity("dp-nil", LiteralValue::Nil);
    assert_display_parity("dp-str", LiteralValue::String("hello \"quoted\" \\".into()));
    assert_display_parity("dp-empty-str", LiteralValue::String("".into()));
    // A nested pair literal materializes through the KLit tree and
    // displays opaquely.
    assert_display_parity(
        "dp-pair",
        LiteralValue::Pair(Box::new(LiteralValue::Int(1)), Box::new(LiteralValue::Nil)),
    );
}

#[test]
fn display_parity_float_battery() {
    if !gate("display-parity-float-battery") {
        return;
    }
    // The shortest-round-trip battery: the hardest cases for the
    // %.*e-search + plain-decimal render, checked against Rust's
    // Grisu/dragon shortest Display.
    let vals: [f64; 12] = [
        0.1,
        0.30000000000000004,
        1e21,
        1e-7,
        -0.0,
        f64::INFINITY,
        f64::NEG_INFINITY,
        f64::NAN,
        1.0 / 3.0,
        5e-324, // the minimum positive subnormal
        f64::MAX,
        -2.75,
    ];
    for (i, v) in vals.iter().enumerate() {
        assert_display_parity(&format!("dp-float-{i}"), LiteralValue::Float(*v));
    }
}

// ---------- source-level parity (check-wrapped) ----------

/// The check form for one expected repr (callers pre-classify):
/// numeric reprs compare with `=`; bool reprs map to the `#t`/`#f`
/// literals (the Rust Display forms `true`/`false` are not kerf
/// source); everything else compares with `eq?` verbatim.
fn check_form(global: &str, repr: &str) -> String {
    if repr == "true" {
        format!("(eq? {global} #t)")
    } else if repr == "false" {
        format!("(eq? {global} #f)")
    } else if repr == "nil" || repr.starts_with('"') {
        format!("(eq? {global} {repr})")
    } else {
        format!("(= {global} {repr})")
    }
}

/// The target-skin twin of [`check_wrapped`] (the W-3.2 extern
/// family's native face): `PASS` prints iff the named global equals
/// the expected repr, through the target call form.
fn check_wrapped_target(source: &str, global: &str, repr: &str) -> String {
    // `eq` covers every repr kind at this face (ints, bools and
    // floats all compare by value through the skin's `eq?`).
    let check = format!("eq({global}, {repr})");
    format!(
        "{source}\ndefine(c_backend_value_check, if {check} {{ write_line(\"PASS\"); }} else {{ write_line(\"FAIL\"); }});"
    )
}

/// Append the value-check epilogue: `PASS` prints iff the last
/// define's global equals the expected repr.
fn check_wrapped(source: &str, global: &str, repr: &str) -> String {
    let check = check_form(global, repr);
    format!(
        "{source}\n(define c-backend-value-check (if {check} (write-line \"PASS\") (write-line \"FAIL\")))"
    )
}

#[test]
fn source_fib_passes_through_the_c_backend() {
    if !gate("source-fib") {
        return;
    }
    let source =
        "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define result (fib 25))";
    let wrapped = check_wrapped(source, "result", "75025");
    let (vm_code, vm_out) = vm_run(&wrapped, &[]);
    assert_eq!((vm_code, vm_out.as_str()), (0, "PASS\n"));
    let bin = cc_build(
        "src-fib",
        &emit_c(&compile_source(&wrapped)).expect("emit"),
        &[],
    );
    let (code, stdout, stderr) = run_bin(&bin, &[]);
    assert_eq!(code, 0, "exit: {stderr}");
    assert_eq!(
        stdout, "PASS\n",
        "the C-transpiled fib(25) agrees with the VM"
    );
}

#[test]
fn source_transitive_captures_pass() {
    if !gate("source-captures") {
        return;
    }
    // Two-level capture: the innermost closure re-captures through
    // its enclosing closure's capture area (LA-4 pass-through).
    let source = concat!(
        "(define (f x) (fn (y) (fn (z) (+ x (+ y z)))))\n",
        "(define g (f 10))\n",
        "(define h (g 20))\n",
        "(define result (h 12))\n",
    );
    let wrapped = check_wrapped(source, "result", "42");
    let (vm_code, vm_out) = vm_run(&wrapped, &[]);
    assert_eq!((vm_code, vm_out.as_str()), (0, "PASS\n"));
    let bin = cc_build(
        "src-captures",
        &emit_c(&compile_source(&wrapped)).expect("emit"),
        &[],
    );
    let (code, stdout, stderr) = run_bin(&bin, &[]);
    assert_eq!(code, 0, "exit: {stderr}");
    assert_eq!(stdout, "PASS\n", "flat captures survive the transpilation");
}

#[test]
fn source_effects_handle_perform_pass() {
    if !gate("source-effects") {
        return;
    }
    // pos-021 shape: a handler answers a perform; its return value
    // is the perform's value.
    let source = "(define result (handle (perform add 1 2) (add (fn (a b) (+ a b)))))";
    let wrapped = check_wrapped(source, "result", "3");
    let (vm_code, vm_out) = vm_run(&wrapped, &[]);
    assert_eq!((vm_code, vm_out.as_str()), (0, "PASS\n"));
    let bin = cc_build(
        "src-effects",
        &emit_c(&compile_source(&wrapped)).expect("emit"),
        &[],
    );
    let (code, stdout, stderr) = run_bin(&bin, &[]);
    assert_eq!(code, 0, "exit: {stderr}");
    assert_eq!(stdout, "PASS\n", "the handler stack rides the shim");
}

#[test]
fn source_read_line_stdin_passes() {
    if !gate("source-read-line") {
        return;
    }
    let source = concat!(
        "(define a (read-line))\n",
        "(define b (read-line))\n",
        "(define result (if (eq? a \"one\") (eq? b \"two\") #f))\n",
    );
    let wrapped = check_wrapped(source, "result", "true");
    let (vm_code, vm_out) = vm_run(&wrapped, &["one", "two"]);
    assert_eq!((vm_code, vm_out.as_str()), (0, "PASS\n"));
    let bin = cc_build(
        "src-read-line",
        &emit_c(&compile_source(&wrapped)).expect("emit"),
        &[],
    );
    let (code, stdout, stderr) = run_bin(&bin, &["one", "two"]);
    assert_eq!(code, 0, "exit: {stderr}");
    assert_eq!(stdout, "PASS\n", "getline feeds read-line identically");
}

#[test]
fn source_multi_output_sequence_matches() {
    if !gate("source-outputs") {
        return;
    }
    let source = concat!(
        "(define a (write-line \"first\"))\n",
        "(define b (write-line \"second\"))\n",
        "(define c (write-line \"third\"))\n",
    );
    let (vm_code, vm_out) = vm_run(source, &[]);
    assert_eq!((vm_code, vm_out.as_str()), (0, "first\nsecond\nthird\n"));
    let bin = cc_build(
        "src-outputs",
        &emit_c(&compile_source(source)).expect("emit"),
        &[],
    );
    let (code, stdout, stderr) = run_bin(&bin, &[]);
    assert_eq!(code, 0, "exit: {stderr}");
    assert_eq!(
        stdout, "first\nsecond\nthird\n",
        "byte parity on the output channel"
    );
}

// ---------- runtime fail-closed families (hand-built) ----------

#[test]
fn runtime_errors_fail_closed_with_engine_level_text() {
    if !gate("runtime-errors") {
        return;
    }
    // Integer division by zero (hand-built: the checker would catch
    // the literal source form statically).
    let div_bc = {
        let mut proto = FuncProto::new(None, 0, 0);
        proto.code = vec![
            Instr::with_a(Opcode::PushConst, 0),
            Instr::with_a(Opcode::PushConst, 1),
            Instr::new(Opcode::Div),
            Instr::new(Opcode::Pop),
            Instr::new(Opcode::Halt),
        ];
        proto.debug_info = vec![fix_span(); 5];
        Bytecode {
            consts: vec![LiteralValue::Int(1), LiteralValue::Int(0)],
            funcs: vec![proto],
            ..Default::default()
        }
    };
    let bin = cc_build("err-div", &emit_c(&div_bc).expect("emit"), &[]);
    let (code, _, stderr) = run_bin(&bin, &[]);
    assert_eq!(code, 1);
    assert!(
        stderr.contains("kerf: runtime error: division by zero"),
        "{stderr}"
    );

    // Checked add overflow at the i64 boundary.
    let ovf_bc = {
        let mut proto = FuncProto::new(None, 0, 0);
        proto.code = vec![
            Instr::with_a(Opcode::PushConst, 0),
            Instr::with_a(Opcode::PushConst, 1),
            Instr::new(Opcode::Add),
            Instr::new(Opcode::Pop),
            Instr::new(Opcode::Halt),
        ];
        proto.debug_info = vec![fix_span(); 5];
        Bytecode {
            consts: vec![LiteralValue::Int(i64::MAX), LiteralValue::Int(1)],
            funcs: vec![proto],
            ..Default::default()
        }
    };
    let bin = cc_build("err-ovf", &emit_c(&ovf_bc).expect("emit"), &[]);
    let (code, _, stderr) = run_bin(&bin, &[]);
    assert_eq!(code, 1);
    assert!(stderr.contains("add overflow"), "{stderr}");

    // An unbound global read (LoadGlobal on a never-stored,
    // non-builtin slot).
    let unb_bc = {
        let mut proto = FuncProto::new(None, 0, 0);
        proto.code = vec![
            Instr::with_a(Opcode::LoadGlobal, 0),
            Instr::new(Opcode::Pop),
            Instr::new(Opcode::Halt),
        ];
        proto.debug_info = vec![fix_span(); 3];
        Bytecode {
            consts: Vec::new(),
            globals: vec![kerf::span::Symbol::new("missing").expect("symbol")],
            funcs: vec![proto],
            externs: Vec::new(),
        }
    };
    let bin = cc_build("err-unbound", &emit_c(&unb_bc).expect("emit"), &[]);
    let (code, _, stderr) = run_bin(&bin, &[]);
    assert_eq!(code, 1);
    assert!(stderr.contains("unbound global `missing`"), "{stderr}");
}

#[test]
fn builtin_arity_mismatches_fail_closed_representatives() {
    if !gate("arity-representatives") {
        return;
    }
    // Hand-built calls with wrong argc on three representative
    // builtins (the full 18-name mapping guard is unit-level in the
    // emitter; this pins the runtime behavior end to end).
    for (name, global, argc, expect) in [
        ("arity-add", "+", 1u32, "`+` expects `2` arguments"),
        ("arity-cons", "cons", 3, "`cons` expects `2` arguments"),
        (
            "arity-write",
            "write-line",
            0,
            "`write-line` expects `1` argument",
        ),
    ] {
        // Stack order (§19.3): args left-to-right FIRST, the callee
        // ON TOP.
        let mut proto = FuncProto::new(None, 0, 0);
        let mut code = Vec::new();
        for _ in 0..argc {
            code.push(Instr::with_a(Opcode::PushConst, 0));
        }
        code.push(Instr::with_a(Opcode::LoadGlobal, 0));
        code.push(Instr::with_a(Opcode::Call, argc));
        code.push(Instr::new(Opcode::Pop));
        code.push(Instr::new(Opcode::Halt));
        proto.code = code;
        proto.debug_info = vec![fix_span(); proto.code.len()];
        let bc = Bytecode {
            consts: vec![LiteralValue::Int(1)],
            globals: vec![kerf::span::Symbol::new(global).expect("builtin name is a valid symbol")],
            funcs: vec![proto],
            externs: Vec::new(),
        };
        let bin = cc_build(name, &emit_c(&bc).expect("emit"), &[]);
        let (code, _, stderr) = run_bin(&bin, &[]);
        assert_eq!(code, 1, "{name} must fail closed");
        assert!(stderr.contains(expect), "{name}: {stderr}");
    }
}

// ---------- override faces (the fail-closed guards) ----------

#[test]
fn budget_override_fails_closed() {
    if !gate("budget-override") {
        return;
    }
    // A chain of 40 cons cells against -DK_BUDGET=24: the §19.4
    // safety point fires before the arena satisfies the chain.
    let mut source = String::from("(define chain ");
    for _ in 0..40 {
        source.push_str("(cons 1 ");
    }
    source.push_str("nil");
    for _ in 0..40 {
        source.push(')');
    }
    source.push_str(")\n");
    let bin = cc_build(
        "budget-override",
        &emit_c(&compile_source(&source)).expect("emit"),
        &["-DK_BUDGET=24"],
    );
    let (code, _, stderr) = run_bin(&bin, &[]);
    assert_eq!(code, 1);
    assert!(
        stderr.contains("allocation budget of `24` exhausted"),
        "{stderr}"
    );
}

#[test]
fn depth_override_fails_closed() {
    if !gate("depth-override") {
        return;
    }
    // Recursion depth 40 against -DK_DEPTH_CAP=8: the host-stack
    // guard fires cleanly instead of a segfault.
    let source = concat!(
        "(define (cd n) (if (= n 0) 0 (cd (- n 1))))\n",
        "(define result (cd 40))\n",
    );
    let bin = cc_build(
        "depth-override",
        &emit_c(&compile_source(source)).expect("emit"),
        &["-DK_DEPTH_CAP=8"],
    );
    let (code, _, stderr) = run_bin(&bin, &[]);
    assert_eq!(code, 1);
    assert!(
        stderr.contains("recursion depth of `8` exceeded"),
        "{stderr}"
    );
}

#[test]
fn frame_budget_boundary_is_exact() {
    if !gate("frame-budget-boundary") {
        return;
    }
    // r106 FIX-1: `k_enter` must charge before the depth increment —
    // the same check-then-allocate order as the VM `reserve`/`push_frame`
    // pair — so a frame-shaped program peaks at exactly `K_BUDGET` live
    // units on both engines (the old increment-first order rejected at
    // budget-1). Live units here: the `cd` closure cell (1, created in
    // the entry body) + the main entry frame (1) + one frame per nested
    // `cd` call. `(cd N)` nests N+1 frames (n = N down to 0), so
    // peak = N + 3:
    //   N = 21, -DK_BUDGET=24 → peak 24 == budget → accepted;
    //   N = 22                → peak 25 >  budget → rejected.
    let mk =
        |n: u64| format!("(define (cd n) (if (= n 0) 0 (cd (- n 1))))\n(define result (cd {n}))\n");
    let bin_ok = cc_build(
        "frame-budget-boundary-ok",
        &emit_c(&compile_source(&mk(21))).expect("emit"),
        &["-DK_BUDGET=24"],
    );
    let (code, _, _) = run_bin(&bin_ok, &[]);
    assert_eq!(code, 0, "peak depth == budget must be accepted");
    let bin_over = cc_build(
        "frame-budget-boundary-over",
        &emit_c(&compile_source(&mk(22))).expect("emit"),
        &["-DK_BUDGET=24"],
    );
    let (code, _, stderr) = run_bin(&bin_over, &[]);
    assert_eq!(code, 1);
    assert!(
        stderr.contains("allocation budget of `24` exhausted"),
        "{stderr}"
    );
}

// ---------- toolchain-pairing hygiene (the v0.73.0 incident class) ----------

#[test]
fn loader_abort_classification_covers_the_pairing_family() {
    // The exact v0.73.0 incident text and its siblings must classify
    // as environment pairing defects — exit 127 alone, the private
    // glibc symbol failure, and the shared-object family.
    assert!(is_loader_abort(127, ""));
    assert!(is_loader_abort(
        0,
        "/nix/store/glibc-2.44/lib/libc.so.6: undefined symbol: \
         __pointer_chk_guard, version GLIBC_PRIVATE"
    ));
    assert!(is_loader_abort(
        0,
        "./bin: error while loading shared libraries: libfoo.so.1: \
         cannot open shared object file: No such file or directory"
    ));
    // Every legitimate shim outcome — clean exits and the fail-closed
    // runtime-error families that ride this very helper — must never
    // classify.
    assert!(!is_loader_abort(1, "kerf: runtime error: division by zero"));
    assert!(!is_loader_abort(1, "kerf: runtime error: add overflow"));
    assert!(!is_loader_abort(0, ""));
    // The report names the defect class and the way out (report over
    // silence — the message is the product here).
    let report = loader_abort_report(
        Path::new("target/cbackend-e2e/dp-int-42"),
        127,
        "libc.so.6: undefined symbol: __pointer_chk_guard, version GLIBC_PRIVATE",
    );
    assert!(report.contains("died at load"));
    assert!(report.contains("environment pairing defect"));
    assert!(report.contains("one consistent toolchain"));
}

#[test]
fn boundary_scrubs_register_the_full_contaminant_sets() {
    // Face 1 — the wiring proof: every contaminant variable must be
    // registered for removal on its boundary's command (std exposes
    // removals as `None` entries in `get_envs`, and a registered
    // removal beats parent-env inheritance at spawn). This is the
    // exact mechanism that keeps a poisoned ambient — the v0.73.0 Nix
    // dev-shell shape — from reaching the link or the load.
    let cc = cc_scrubbed();
    let cc_removed: Vec<String> = cc
        .get_envs()
        .filter(|(_, v)| v.is_none())
        .map(|(k, _)| k.to_string_lossy().into_owned())
        .collect();
    for var in LINK_CONTAMINANTS {
        assert!(
            cc_removed.iter().any(|r| r == var),
            "the cc boundary must scrub `{var}`"
        );
    }
    assert_eq!(
        cc_removed.len(),
        LINK_CONTAMINANTS.len(),
        "the cc boundary scrubs exactly the link set"
    );
    let bin = bin_scrubbed(Path::new("bin"));
    let bin_removed: Vec<String> = bin
        .get_envs()
        .filter(|(_, v)| v.is_none())
        .map(|(k, _)| k.to_string_lossy().into_owned())
        .collect();
    for var in RUN_CONTAMINANTS {
        assert!(
            bin_removed.iter().any(|r| r == var),
            "the load boundary must scrub `{var}`"
        );
    }
    assert_eq!(
        bin_removed.len(),
        RUN_CONTAMINANTS.len(),
        "the load boundary scrubs exactly the run set"
    );
}

#[test]
fn unscrubbed_boundaries_eat_the_poison_and_the_loader_abort_is_classified() {
    if !gate("poison-lethality") {
        return;
    }
    // Face 2 — the negative control: the exact ammunition class of
    // the v0.73.0 incident must be lethal on an unguarded boundary,
    // otherwise the protection faces would pass vacuously. The poison
    // header kills an unscrubbed compile; the poison libc kills an
    // unscrubbed load — and the REAL loader-abort text (not a
    // fixture) must land in the classifier. Together with face 1 this
    // closes the chain: ambient poison cannot reach the child
    // (registered removal), and were it to reach it, it kills.
    let dir = work_dir();
    let poison = dir.join("poison-dir");
    std::fs::create_dir_all(&poison).expect("make the poison dir");
    std::fs::write(poison.join("stdio.h"), b"poisoned header\n").expect("write the poison header");
    std::fs::write(poison.join("libc.so.6"), b"poisoned libc\n").expect("write the poison libc");
    let poison_dir = poison.to_str().expect("utf-8 work dir").to_owned();

    // Lethality on the link boundary: a plain unscrubbed cc with the
    // poison on the include path cannot compile a translation unit
    // that reaches for the standard headers.
    let cpath = dir.join("poison-lethality.c");
    std::fs::write(
        &cpath,
        "#include <stdio.h>\nint main(void) { printf(\"x\\n\"); return 0; }\n",
    )
    .expect("write a minimal C source");
    let out = Command::new("cc")
        .env("CPATH", &poison_dir)
        .arg(&cpath)
        .arg("-o")
        .arg(dir.join("poison-lethality-cc"))
        .output()
        .expect("spawn the unscrubbed cc");
    assert!(
        !out.status.success(),
        "the poison header must kill an unscrubbed compile"
    );

    // Lethality on the load boundary: a cleanly linked binary run
    // with the poison libc ahead of the default search path dies at
    // load with a real loader abort the classifier recognizes (the
    // glibc loader resolves `libc.so.6` through `LD_LIBRARY_PATH`
    // before the system dirs; a garbage file there is fatal, not
    // advisory like an unloadable `LD_PRELOAD`).
    let clean = cc_build(
        "poison-lethality-clean",
        "int main(void) { return 0; }\n",
        &[],
    );
    let out = Command::new(&clean)
        .env("LD_LIBRARY_PATH", &poison_dir)
        .output()
        .expect("spawn the unscrubbed load");
    let code = out.status.code().unwrap_or(-1);
    let stderr = String::from_utf8_lossy(&out.stderr).into_owned();
    assert!(
        is_loader_abort(code, &stderr),
        "the poison libc must kill an unscrubbed load (code {code}: {stderr})"
    );
}

#[test]
fn unused_stdin_never_masks_the_child_outcome() {
    if !gate("unused-stdin") {
        return;
    }
    // The child prints and exits without ever reading stdin while the
    // harness still feeds lines — the exact shape that used to risk a
    // broken-pipe panic (and, in the v0.73.0 incident, masked the
    // loader abort behind it). The feed is best effort: the child's
    // real exit status, stdout, and stderr must come through
    // untouched.
    let source = "(define a (write-line \"bye\"))";
    let bin = cc_build(
        "unused-stdin",
        &emit_c(&compile_source(source)).expect("emit"),
        &[],
    );
    let (code, stdout, stderr) = run_bin(&bin, &["never", "read"]);
    assert_eq!(code, 0, "exit: {stderr}");
    assert_eq!(stdout, "bye\n");
}

// ---------- emission determinism (no cc needed) ----------

#[test]
fn emission_determinism_at_the_source_level() {
    let bc = compile_source("(define (f x) (+ x 1)) (define result (f 41)) (define s \"payload\")");
    assert_eq!(
        emit_c(&bc).expect("emit"),
        emit_c(&bc).expect("emit again"),
        "identical product, byte-identical C"
    );
}

// ---------- the full-corpus C replay (heavy, explicit) ----------

/// The corpus directory (shared with subset_corpus_tests).
const CORPUS_DIR: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/tests/v1/stage1/corpus");

/// One replay outcome for the sweep's disclosure report.
struct ReplayLine {
    case: String,
    verdict: &'static str,
}

#[test]
#[ignore = "heavy: one cc invocation per corpus case (run explicitly: cargo test --release --test runner c_backend -- --ignored)"]
fn corpus_c_replay_full_sweep() {
    if !gate("corpus-c-replay") {
        return;
    }
    let dir = std::fs::read_dir(CORPUS_DIR).expect("corpus dir");
    let mut executed = 0usize;
    let mut passed = 0usize;
    let mut skipped_compile_stage = 0usize;
    let mut skipped_repr_kind = 0usize;
    let mut lines: Vec<ReplayLine> = Vec::new();

    for entry in dir {
        let path = entry.expect("dir entry").path();
        let Some(name) = path.file_name().and_then(|n| n.to_str()) else {
            continue;
        };
        if !name.ends_with(".krf") {
            continue;
        }
        let case_name = name.trim_end_matches(".krf").to_owned();
        let source = std::fs::read_to_string(&path).expect("read corpus file");
        let case = kerf::driver::CorpusCase::from_source(&case_name, &source)
            .expect("corpus directive parses");
        match &case.expectation {
            Expectation::Value(repr) | Expectation::Warning { value: repr, .. } => {
                // Locate the last top-level define through the real
                // expansion (the parity convention's global).
                let forms = kerf::reader::read_program(FileId(0), &source).expect("read");
                let items = kerf::expander::expand_program(&forms).expect("expand");
                let last_global = items.iter().rev().find_map(|item| match item {
                    kerf::core::ModuleItem::Define { name, .. } => Some(name.as_str().to_owned()),
                    _ => None,
                });
                let Some(global) = last_global else {
                    skipped_repr_kind += 1;
                    lines.push(ReplayLine {
                        case: case_name,
                        verdict: "skip: no define",
                    });
                    continue;
                };
                // Pair/closure/builtin reprs have no printable
                // channel (eq? is identity) — disclose and skip.
                let simple = repr.parse::<i64>().is_ok()
                    || repr == "nil"
                    || repr == "true"
                    || repr == "false"
                    || repr.starts_with('"')
                    || repr.parse::<f64>().is_ok();
                if !simple {
                    skipped_repr_kind += 1;
                    lines.push(ReplayLine {
                        case: case_name,
                        verdict: "skip: repr kind",
                    });
                    continue;
                }
                let wrapped = check_wrapped(&source, &global, repr);
                let (vm_code, vm_out) = vm_run(&wrapped, &[]);
                assert_eq!(vm_code, 0, "vm side of {case_name}");
                assert!(
                    vm_out.ends_with("PASS\n"),
                    "vm side of {case_name} must verify its own value (got {vm_out:?})"
                );
                let bc = compile_source(&wrapped);
                // W-3.2: a program that references an extern needs its
                // foreign library at link time — the standalone replay
                // has none, so the case joins the disclosure ledger
                // (the extern e2e family replays those programs WITH
                // the library).
                if bc
                    .externs
                    .iter()
                    .any(|e| bc.globals.iter().any(|g| g == &e.name))
                {
                    skipped_repr_kind += 1;
                    lines.push(ReplayLine {
                        case: case_name,
                        verdict: "skip: extern reference (foreign library not linked)",
                    });
                    continue;
                }
                let bin = cc_build(
                    &format!("corpus-{case_name}"),
                    &emit_c(&bc).expect("emit"),
                    &[],
                );
                let (code, stdout, stderr) = run_bin(&bin, &[]);
                executed += 1;
                if code == 0 && stdout == vm_out {
                    passed += 1;
                    lines.push(ReplayLine {
                        case: case_name,
                        verdict: "pass",
                    });
                } else {
                    lines.push(ReplayLine {
                        case: case_name.clone(),
                        verdict: "FAIL",
                    });
                    panic!(
                        "corpus case `{case_name}` diverged through the C backend: code={code} stdout={stdout:?} (vm={vm_out:?}) stderr={stderr}"
                    );
                }
            }
            kerf::driver::Expectation::RuntimeError => {
                // Both engines must fail closed on the untransformed
                // source.
                let (vm_code, _) = vm_run(&source, &[]);
                assert_eq!(vm_code, 1, "vm side of {case_name} must error");
                let bc = compile_source(&source);
                // W-3.2: an extern call's runtime error is the DESIGNED
                // engine divergence — the VM fails closed where the C
                // backend would succeed (given the library). The
                // standalone replay has no foreign library: the case
                // joins the disclosure ledger; the extern family owns
                // the divergence pin.
                if bc
                    .externs
                    .iter()
                    .any(|e| bc.globals.iter().any(|g| g == &e.name))
                {
                    skipped_repr_kind += 1;
                    lines.push(ReplayLine {
                        case: case_name,
                        verdict: "skip: extern reference (the designed engine divergence)",
                    });
                    continue;
                }
                let bin = cc_build(
                    &format!("corpus-{case_name}"),
                    &emit_c(&bc).expect("emit"),
                    &[],
                );
                let (code, _, stderr) = run_bin(&bin, &[]);
                executed += 1;
                if code != 0 && stderr.contains("kerf: runtime error") {
                    passed += 1;
                    lines.push(ReplayLine {
                        case: case_name,
                        verdict: "pass (error parity)",
                    });
                } else {
                    lines.push(ReplayLine {
                        case: case_name.clone(),
                        verdict: "FAIL",
                    });
                    panic!(
                        "corpus case `{case_name}` runtime error diverged: code={code} stderr={stderr}"
                    );
                }
            }
            // parse/expand/type errors never reach the backend.
            _ => {
                skipped_compile_stage += 1;
            }
        }
    }
    for line in &lines {
        eprintln!("corpus-c-replay: {} — {}", line.case, line.verdict);
    }
    eprintln!(
        "corpus-c-replay SUMMARY: {passed}/{executed} executed cases agree; {skipped_compile_stage} pre-backend skips (parse/expand/type); {skipped_repr_kind} repr-kind skips"
    );
    // The sweep must be non-trivial: the corpus reaches the backend
    // through dozens of cases.
    assert!(
        executed >= 30,
        "the corpus replay must exercise at least 30 execution cases (got {executed})"
    );
}

#[test]
#[ignore = "measurement: the Stage 2.6 B-face numbers (emit cost + C fib vs VM)"]
fn b_face_measurement_c_vs_vm() {
    if !gate("b-face-measurement") {
        return;
    }
    let source =
        "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define result (fib 25))";
    let bc = compile_source(source);

    // Emit cost: 2000 iterations, report mean/median.
    let mut samples: Vec<f64> = Vec::with_capacity(2000);
    for _ in 0..2000 {
        let t = std::time::Instant::now();
        let c = emit_c(&bc).expect("emit");
        let _ = std::hint::black_box(&c);
        samples.push(t.elapsed().as_secs_f64() * 1e6);
    }
    samples.sort_by(|a, b| a.total_cmp(b));
    let mean: f64 = samples.iter().sum::<f64>() / samples.len() as f64;
    let median = samples[samples.len() / 2];
    eprintln!("B9c emit-c fib: 2000 iters, mean {mean:.1}µs, median {median:.1}µs");

    // cc -O0 build time (one shot).
    let c = emit_c(&bc).expect("emit");
    let t = std::time::Instant::now();
    let bin = cc_build("b-face-fib", &c, &[]);
    eprintln!("B9c cc -O0 build: {:.1}ms", t.elapsed().as_secs_f64() * 1e3);

    // The C binary vs the VM engine on fib(25): 10 runs each, median.
    let mut c_times: Vec<f64> = Vec::with_capacity(10);
    for _ in 0..10 {
        let t = std::time::Instant::now();
        let (code, stdout, _) = run_bin(&bin, &[]);
        assert_eq!(
            (code, stdout.as_str()),
            (0, ""),
            "the declaration-only program prints nothing"
        );
        c_times.push(t.elapsed().as_secs_f64() * 1e3);
    }
    c_times.sort_by(|a, b| a.total_cmp(b));
    eprintln!(
        "B9c cc-binary fib(25): 10 runs, median {:.3}ms (B2 vm median ~79ms for the comparison)",
        c_times[5]
    );
}

// ---------- the W-3.2 extern family (the FFI contract e2e) ----------

/// The foreign-function library the extern e2e family links against:
/// three scalar contracts plus the R-F2 witness pair — `box_sum`
/// mallocs internally, sums, frees, and bumps a static counter; the
/// counter reads back through `box_frees`. Ownership discipline: the
/// C side owns and frees its own memory (invisible to kerf); only
/// the scalar RESULT crosses (R-F2 — a fresh kerf value on return).
const EXTERN_IMPL: &str = r#"
#include <stdint.h>
#include <stdlib.h>
int64_t add(int64_t a, int64_t b) { return a + b; }
_Bool truthy(_Bool v) { return v; }
double scaled(double x, double k) { return x * k; }
static int64_t g_box_frees = 0;
int64_t box_sum(int64_t a, int64_t b) {
    int64_t *buf = malloc(2 * sizeof(int64_t));
    buf[0] = a; buf[1] = b;
    int64_t r = buf[0] + buf[1];
    free(buf);
    g_box_frees += 1;
    return r;
}
int64_t box_frees(int64_t unused) { (void)unused; return g_box_frees; }
"#;

/// Write the foreign library and return its object path (compiled
/// through the same scrubbed cc choke point as the kerf side).
fn extern_impl_object() -> PathBuf {
    let dir = work_dir();
    let cpath = dir.join("extern-impl.c");
    std::fs::write(&cpath, EXTERN_IMPL).expect("write the foreign library");
    let obj = dir.join("extern-impl.o");
    let out = cc_scrubbed()
        .arg("-c")
        .arg(&cpath)
        .arg("-o")
        .arg(&obj)
        .output()
        .expect("spawn cc for the foreign library");
    assert!(
        out.status.success(),
        "cc rejected the foreign library:\n{}",
        String::from_utf8_lossy(&out.stderr)
    );
    obj
}

#[test]
fn source_extern_int_calls_pass() {
    if !gate("src-extern-int") {
        return;
    }
    // The W-3.2 primary integration case: an extern declaration
    // through the real pipeline — read, expand, typecheck, compile,
    // transpile — then a real cc link against the foreign library
    // and a real call crossing the boundary.
    let source = concat!(
        "extern \"C\" { fn add(x: int, y: int) -> int; }\n",
        "define(result, add(2, 40));"
    );
    let wrapped = check_wrapped_target(source, "result", "42");
    let bin = cc_build(
        "src-extern-int",
        &emit_c(&compile_source_target(&wrapped)).expect("emit"),
        &[extern_impl_object().to_str().expect("path")],
    );
    let (code, stdout, stderr) = run_bin(&bin, &[]);
    assert_eq!(code, 0, "exit: {stderr}");
    assert_eq!(
        stdout, "PASS\n",
        "the extern call's value equals 42 through the boundary"
    );
}

#[test]
fn source_extern_bool_and_float_pass() {
    if !gate("src-extern-scalars") {
        return;
    }
    // The complete scalar batch at the boundary: bool and float ride
    // the same declaration form and the same marshaling discipline.
    let source = concat!(
        "extern \"C\" { fn truthy(v: bool) -> bool; fn scaled(x: float, k: float) -> float; }\n",
        "define(a, truthy(true));\n",
        "define(b, scaled(1.5, 3.0));\n",
        "define(result, if a { 42 } else { 7 });"
    );
    let wrapped = check_wrapped_target(source, "result", "42");
    let bin = cc_build(
        "src-extern-scalars",
        &emit_c(&compile_source_target(&wrapped)).expect("emit"),
        &[extern_impl_object().to_str().expect("path")],
    );
    let (code, stdout, stderr) = run_bin(&bin, &[]);
    assert_eq!(code, 0, "exit: {stderr}");
    assert_eq!(
        stdout, "PASS\n",
        "bool crosses and returns; float rides along"
    );
}

#[test]
fn source_extern_rf2_transfer_semantics_witness() {
    if !gate("src-extern-rf2") {
        return;
    }
    // R-F2 (caller-owned + return-value transfer): the C side owns
    // its internals (malloc/free invisible to kerf), the RESULT
    // transfers as a fresh kerf value, and two successive calls
    // witness the C-side free discipline through the counter.
    let source = concat!(
        "extern \"C\" { fn box_sum(a: int, b: int) -> int; fn box_frees(u: int) -> int; }\n",
        "define(first, box_sum(10, 32));\n",
        "define(second, box_sum(1, 1));\n",
        "define(frees, box_frees(0));\n",
        "define(result, if eq(eq(first, 42), eq(second, 2)) { frees } else { 0 });"
    );
    let wrapped = check_wrapped_target(source, "result", "2");
    let bin = cc_build(
        "src-extern-rf2",
        &emit_c(&compile_source_target(&wrapped)).expect("emit"),
        &[extern_impl_object().to_str().expect("path")],
    );
    let (code, stdout, stderr) = run_bin(&bin, &[]);
    assert_eq!(code, 0, "exit: {stderr}");
    assert_eq!(
        stdout, "PASS\n",
        "both box_sum calls returned (42, 2) and the C side freed twice (frees == 2)"
    );
}

#[test]
fn extern_runtime_type_guard_fails_closed() {
    if !gate("src-extern-type-guard") {
        return;
    }
    // The Dyn leak face: a statically-released join (int/bool) that
    // is a bool at run time must die at the boundary with the
    // marshaling diagnostic — defense in depth under the soft-typing
    // release discipline (the typechecker cannot report what it
    // released; the boundary refuses what it cannot marshal).
    let source = concat!(
        "extern \"C\" { fn add(x: int, y: int) -> int; }\n",
        "define(result, add((if false { 1 } else { true }), 2));"
    );
    let bin = cc_build(
        "src-extern-type-guard",
        &emit_c(&compile_source_target(source)).expect("emit"),
        &[extern_impl_object().to_str().expect("path")],
    );
    let (code, _stdout, stderr) = run_bin(&bin, &[]);
    assert_eq!(code, 1, "the boundary fails closed");
    assert!(
        stderr.contains("extern `add` argument must be an int, got `bool`"),
        "the marshaling diagnostic names the contract and the kind: {stderr}"
    );
}

#[test]
fn extern_runtime_arity_guard_fails_closed() {
    if !gate("src-extern-arity-guard") {
        return;
    }
    // Hand-built product (the verify-legal face): the wrapper's
    // k_fail_arity defense — a Call with the wrong count against an
    // extern value. Source programs meet the checker's E0002 first;
    // the product-level guard is the depth-in-depth layer.
    let bc = {
        let mut proto = FuncProto::new(None, 0, 1);
        proto.code = vec![
            Instr::with_a(Opcode::PushConst, 0),
            Instr::with_a(Opcode::LoadGlobal, 0),
            Instr::with_a(Opcode::Call, 1),
            Instr::new(Opcode::Pop),
            Instr::new(Opcode::Halt),
        ];
        proto.debug_info = vec![fix_span(); proto.code.len()];
        Bytecode {
            consts: vec![LiteralValue::Int(1)],
            globals: vec![kerf::span::Symbol::new("add").expect("symbol")],
            funcs: vec![proto],
            externs: vec![kerf::compiler::ExternEntry {
                name: kerf::span::Symbol::new("add").expect("symbol"),
                params: vec![kerf::core::ExternType::Int, kerf::core::ExternType::Int],
                ret: kerf::core::ExternType::Int,
            }],
        }
    };
    let bin = cc_build(
        "src-extern-arity-guard",
        &emit_c(&bc).expect("emit"),
        &[extern_impl_object().to_str().expect("path")],
    );
    let (code, _stdout, stderr) = run_bin(&bin, &[]);
    assert_eq!(code, 1, "the wrapper fails closed");
    assert!(
        stderr.contains("arity mismatch") && stderr.contains("add"),
        "the arity diagnostic names the extern: {stderr}"
    );
}

//! Selfhost formatting guards (§9.79 FMT — the selfhost formatting
//! round, root-project asset face).
//!
//! Three machine-checked invariants over the five `.ktf` target-skin
//! twins of `selfhost/v1/` (r100; the production-chain skin since the
//! r104 E5 batch-3 teardown retired the five `.krf` originals — the
//! S-expr twin sources left the tree, their formatting record rides
//! the audit's historical sections) — the bootstrap front end plus
//! the Stage 2.3 compile-time analysis, all written in the frozen
//! subset itself. These span no crate (the files are root-project
//! assets consumed via `include_str!` from kerf-driver), so the guard
//! lives at the root (SOP §8.4.6 / §9.1 — cross-crate assertions
//! never go inside a crate's own tree).
//!
//! 1. **Line width** — no line exceeds 100 columns (SOP §10.5
//!    `~100 columns`; the same bound rustfmt enforces on the Rust
//!    face — the selfhost layer joins the repo-wide convention).
//!    Before v0.48.0 the worst offenders were 1697 and 684 columns.
//! 2. **Non-ASCII whitelist** — comments may carry the em-dash `—`
//!    (the repo-wide parenthetical-dash convention: 122 Rust files)
//!    and the section anchor `§` (SOP §10.5 rule 2: technical
//!    anchors ride verbatim); any other non-ASCII character is drift.
//! 3. **ASCII parenthetical dashes absent** — the pre-v0.48.0
//!    sources mixed ` - ` and `  -  ` ASCII dashes (an authoring
//!    artifact of the 1.6/1.7 rounds: the expander and macro twins,
//!    plus the two expander-parity Rust faces); the cleanup unified
//!    every parenthetical dash to the em-dash, and this guard pins
//!    the convention. (The `krf_reformat.py` local pre-flight tool
//!    retired at r106 — its targets, the `.krf` originals, had left
//!    the tree at r104; this guard is the one checked face.)

// The step-3 target-skin twins (r100, switch-window step 3) — the
// production-chain skin since the r104 E5 batch-3 teardown: the same
// root-project asset face, the same three invariants.
const LEXER_TWIN: &str = include_str!("../../../../selfhost/v1/lexer.ktf");
const READER_TWIN: &str = include_str!("../../../../selfhost/v1/reader.ktf");
const EXPANDER_TWIN: &str = include_str!("../../../../selfhost/v1/expander.ktf");
const MACRO_TWIN: &str = include_str!("../../../../selfhost/v1/macro.ktf");
const COMPILER_TWIN: &str = include_str!("../../../../selfhost/v1/compiler.ktf");

/// The formatting convention bound (columns; comment layers measure
/// display width, so count chars — the em-dash is three bytes but one
/// column).
const WIDTH_BOUND: usize = 100;

fn sources() -> [(&'static str, &'static str); 5] {
    [
        ("lexer.ktf", LEXER_TWIN),
        ("reader.ktf", READER_TWIN),
        ("expander.ktf", EXPANDER_TWIN),
        ("macro.ktf", MACRO_TWIN),
        ("compiler.ktf", COMPILER_TWIN),
    ]
}

#[test]
fn selfhost_lines_respect_the_width_convention() {
    for (name, src) in sources() {
        for (idx, line) in src.lines().enumerate() {
            let width = line.chars().count();
            assert!(
                width <= WIDTH_BOUND,
                "{name}: line {} is {} columns (bound {WIDTH_BOUND}): {}…",
                idx + 1,
                width,
                line.chars().take(40).collect::<String>()
            );
        }
    }
}

#[test]
fn selfhost_non_ascii_is_whitelisted() {
    for (name, src) in sources() {
        let offenders: Vec<(usize, char)> = src
            .char_indices()
            .filter(|(_, c)| !c.is_ascii() && *c != '—' && *c != '§')
            .collect();
        assert!(
            offenders.is_empty(),
            "{name}: non-ASCII outside the {{em-dash, section}} whitelist \
             (SOP §10.5 rule 2 keeps § anchors verbatim; the em-dash is the \
             repo-wide parenthetical convention): {offenders:?}"
        );
    }
}

/// The prose segment of one line: from the comment marker (outside
/// any string literal) to the end. The em-dash convention governs
/// PROSE; code is exempt — the target skin's infix arithmetic
/// (`n - 1`, legal since the step-3 twins) must not trip the prose
/// rule. The `.krf` face marks comments with `;`, the target skin
/// with `//`.
fn prose_segment<'a>(line: &'a str, marker: &str) -> &'a str {
    let bytes = line.as_bytes();
    let mut in_str = false;
    let mut i = 0;
    while i < bytes.len() {
        let b = bytes[i];
        if b == b'"' {
            in_str = !in_str;
        } else if !in_str && line[i..].starts_with(marker) {
            return &line[i..];
        }
        i += 1;
    }
    ""
}

#[test]
fn selfhost_parenthetical_dashes_are_em_dashes() {
    for (name, src) in sources() {
        let marker = if name.ends_with(".ktf") { "//" } else { ";" };
        for line in src.lines() {
            let prose = prose_segment(line, marker);
            assert!(
                !prose.contains(" - "),
                "{name}: ASCII spaced dash survives (pre-v0.48.0 authoring \
                 artifact) — the convention is the em-dash ` — `"
            );
            assert!(
                !prose.contains("  -  "),
                "{name}: double-spaced ASCII dash survives (pre-v0.48.0 \
                 authoring artifact) — the convention is the em-dash ` — `"
            );
        }
    }
}

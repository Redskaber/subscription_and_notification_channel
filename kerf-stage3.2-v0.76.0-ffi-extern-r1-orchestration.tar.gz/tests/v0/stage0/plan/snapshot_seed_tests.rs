//! Stage 0.11 snapshot suite — the §22.3 milestone L6 determinism
//! layer (docs/tests/v0/stage0/plan/snapshot.md).
//!
//! A snapshot case freezes one fixed input into one exact output
//! string across a pipeline layer (stage0.md §13.2 layer 1:
//! deterministic output). The goldens below were recorded from the
//! verified 0.10-r3 baseline (710:0:0 + audit 110/110) via a
//! temporary probe and eye-checked line by line; they change only
//! with an explicit behavior change logged in the worklog.
//!
//! The dump helpers are deterministic test-side walkers (structure
//! only — spans/scopes/phase are the span/syntax test families'
//! job, not the snapshot object).

use kerf::compiler::{Bytecode, compile_program};
use kerf::core::{CoreExpr, LiteralValue, ModuleItem};
use kerf::driver::{self, Engine, Repl, ReplEvent, Session, run_source};
use kerf::expander::expand_program;
use kerf::reader::read_program;
use kerf::span::FileId;
use kerf::syntax::{StxDatum, SyntaxObject};
use kerf::vm::Value;

const FILE: FileId = FileId(0);

// ---------- deterministic dump walkers ----------

fn dump_stx(node: &SyntaxObject) -> String {
    match &node.datum {
        StxDatum::Symbol(s) => s.as_str().to_owned(),
        StxDatum::Int(v) => format!("int:{v}"),
        StxDatum::Float(v) => format!("float:{v}"),
        StxDatum::Bool(v) => format!("bool:{v}"),
        StxDatum::String(s) => format!("str:{s:?}"),
        StxDatum::List(items) => {
            let inner: Vec<String> = items.iter().map(dump_stx).collect();
            format!("({})", inner.join(" "))
        }
    }
}

fn dump_literal(v: &LiteralValue) -> String {
    match v {
        LiteralValue::Int(n) => format!("{n}"),
        LiteralValue::Float(n) => format!("{n}"),
        LiteralValue::Bool(b) => format!("{b}"),
        LiteralValue::String(s) => format!("{s:?}"),
        LiteralValue::Nil => "nil".to_owned(),
        LiteralValue::Pair(a, b) => format!("({} . {})", dump_literal(a), dump_literal(b)),
    }
}

fn dump_core(e: &CoreExpr) -> String {
    match e {
        CoreExpr::Fn { params, body, .. } => format!(
            "(fn ({}) {})",
            params
                .iter()
                .map(|p| p.as_str())
                .collect::<Vec<_>>()
                .join(" "),
            dump_core(body)
        ),
        CoreExpr::Apply { func, args, .. } => {
            let mut parts = vec![dump_core(func)];
            parts.extend(args.iter().map(dump_core));
            format!("(apply {})", parts.join(" "))
        }
        CoreExpr::If {
            cond,
            then_branch,
            else_branch,
            ..
        } => format!(
            "(if {} {} {})",
            dump_core(cond),
            dump_core(then_branch),
            dump_core(else_branch)
        ),
        CoreExpr::Var { name, .. } => name.as_str().to_owned(),
        CoreExpr::Literal { value, .. } => dump_literal(value),
        CoreExpr::Assign { name, value, .. } => {
            format!("(set! {} {})", name.as_str(), dump_core(value))
        }
        CoreExpr::Let { bindings, body, .. } => {
            let bs: Vec<String> = bindings
                .iter()
                .map(|b| format!("({} {})", b.name.as_str(), dump_core(&b.value)))
                .collect();
            format!("(let ({}) {})", bs.join(" "), dump_core(body))
        }
        CoreExpr::Perform { effect, args, .. } => {
            let mut parts = vec![effect.as_str().to_owned()];
            parts.extend(args.iter().map(dump_core));
            format!("(perform {})", parts.join(" "))
        }
        CoreExpr::Handle { body, handlers, .. } => {
            let hs: Vec<String> = handlers
                .iter()
                .map(|h| format!("({} {})", h.effect.as_str(), dump_core(&h.handler)))
                .collect();
            format!("(handle {} {})", dump_core(body), hs.join(" "))
        }
    }
}

fn dump_item(item: &ModuleItem) -> String {
    match item {
        ModuleItem::Define { name, value, .. } => {
            format!("(define {} {})", name.as_str(), dump_core(value))
        }
        ModuleItem::Require { module, .. } => format!("(require {})", module.as_str()),
        ModuleItem::Module { name, items, .. } => {
            let inner: Vec<String> = items.iter().map(dump_item).collect();
            format!("(module {} {})", name.as_str(), inner.join(" "))
        }
        ModuleItem::DefineSyntax { name, .. } => {
            format!("(define-syntax {})", name.as_str())
        }
        ModuleItem::Extern { items, .. } => {
            let inner: Vec<String> = items
                .iter()
                .map(|e| {
                    format!(
                        "({} [{}] {})",
                        e.name.as_str(),
                        e.params
                            .iter()
                            .map(|t| t.kind_tag())
                            .collect::<Vec<_>>()
                            .join(","),
                        e.ret.kind_tag()
                    )
                })
                .collect();
            format!("(extern {})", inner.join(" "))
        }
    }
}

fn dump_bytecode(bc: &Bytecode) -> String {
    let mut out = Vec::new();
    for (i, f) in bc.funcs.iter().enumerate() {
        let name = f.name.as_ref().map(|s| s.as_str()).unwrap_or("<entry>");
        out.push(format!(
            "func {i} {name} params {} locals {}",
            f.params, f.n_locals
        ));
        for instr in &f.code {
            out.push(format!("  {instr}"));
        }
    }
    out.join("\n")
}

// ---------- pipeline drivers ----------

fn read_stx(src: &str) -> Vec<String> {
    let forms = read_program(FILE, src).expect("snapshot source must read");
    forms.iter().map(dump_stx).collect()
}

fn expand_items(src: &str) -> Vec<String> {
    let forms = read_program(FILE, src).expect("snapshot source must read");
    let items = expand_program(&forms).expect("snapshot source must expand");
    items.iter().map(dump_item).collect()
}

fn compile_dump(src: &str) -> String {
    let forms = read_program(FILE, src).expect("snapshot source must read");
    let items = expand_program(&forms).expect("snapshot source must expand");
    let bc = compile_program(&items).expect("snapshot source must compile");
    bc.verify().expect("snapshot product must verify");
    dump_bytecode(&bc)
}

fn run_vm(src: &str) -> (String, String, String) {
    let mut session = Session::new();
    let outcome = run_source(&mut session, "p.krf", src, Engine::Vm, &[]).expect("vm run");
    let globals = outcome
        .globals
        .iter()
        .map(|(n, v)| format!("{n}={v}"))
        .collect::<Vec<_>>()
        .join(" ");
    (
        outcome.value_display(),
        globals,
        outcome.outputs.join(" | "),
    )
}

// ---------- §A reader layer (FP1) ----------

#[test]
fn rs01_int_atom_skeleton() {
    assert_eq!(read_stx("42"), ["int:42"]);
}

#[test]
fn rs02_float_atom_skeleton() {
    assert_eq!(read_stx("-3.5"), ["float:-3.5"]);
}

#[test]
fn rs03_bool_atom_skeleton() {
    assert_eq!(read_stx("#t"), ["bool:true"]);
}

#[test]
fn rs04_string_atom_skeleton() {
    assert_eq!(read_stx("\"hello world\""), ["str:\"hello world\""]);
}

#[test]
fn rs05_symbol_atom_skeleton() {
    assert_eq!(read_stx("sym->name"), ["sym->name"]);
}

#[test]
fn rs06_flat_list_skeleton() {
    assert_eq!(read_stx("(+ 1 2)"), ["(+ int:1 int:2)"]);
}

#[test]
fn rs07_nested_list_skeleton() {
    assert_eq!(read_stx("(a (b (c 1)) 2)"), ["(a (b (c int:1)) int:2)"]);
}

#[test]
fn rs08_comment_and_whitespace_are_lossless() {
    // A leading `;` comment plus blank line: the skeleton is exactly
    // the one form that survives.
    assert_eq!(
        read_stx("; leading comment\n\n(+ 1 2)"),
        ["(+ int:1 int:2)"]
    );
}

#[test]
fn rs09_full_nine_primitive_fib_source_skeleton() {
    assert_eq!(
        read_stx("(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2)))))"),
        ["(define (fib n) (if (< n int:2) n (+ (fib (- n int:1)) (fib (- n int:2)))))"]
    );
}

#[test]
fn rs10_quote_dot_is_an_ordinary_symbol() {
    // Stage 0 grammar fact: `.` inside a list reads as an ordinary
    // symbol atom (dotted pairs are not modeled in StxDatum).
    assert_eq!(
        read_stx("(quote (1 2 . 3))"),
        ["(quote (int:1 int:2 . int:3))"]
    );
}

// ---------- §B expander layer (FP2) ----------

#[test]
fn es01_literal_define_expands_to_int() {
    assert_eq!(expand_items("(define a 42)"), ["(define a 42)"]);
}

#[test]
fn es02_fn_form_expands_to_fn_node() {
    assert_eq!(
        expand_items("(define f (fn (x) (+ x 1)))"),
        ["(define f (fn (x) (apply + x 1)))"]
    );
}

#[test]
fn es03_application_expands_with_explicit_apply_head() {
    assert_eq!(
        expand_items("(define s (+ 1 2 3))"),
        ["(define s (apply + 1 2 3))"]
    );
}

#[test]
fn es04_if_expands_to_three_way_node() {
    assert_eq!(
        expand_items("(define b (if #t 1 2))"),
        ["(define b (if true 1 2))"]
    );
}

#[test]
fn es05_var_reference_expands_to_bare_name() {
    // A let-bound body reference: the Var node renders as the name.
    assert_eq!(
        expand_items("(define l (let ((q 1)) q))"),
        ["(define l (let ((q 1)) q))"]
    );
}

#[test]
fn es06_let_expands_to_binding_chain() {
    assert_eq!(
        expand_items("(define l (let ((a 1) (b 2)) (+ a b)))"),
        ["(define l (let ((a 1) (b 2)) (apply + a b)))"]
    );
}

#[test]
fn es07_do_desugars_to_let_with_discard_names() {
    assert_eq!(
        expand_items("(define d (do (+ 1 2) 7))"),
        ["(define d (let ((_ (apply + 1 2))) 7))"]
    );
}

#[test]
fn es08_assign_keeps_set_head() {
    assert_eq!(
        expand_items("(define g0 1) (define g1 (set! g0 5))"),
        ["(define g0 1)", "(define g1 (set! g0 5))"]
    );
}

#[test]
fn es09_perform_expands_with_effect_name() {
    assert_eq!(
        expand_items("(define p (perform e 1 2))"),
        ["(define p (perform e 1 2))"]
    );
}

#[test]
fn es10_handle_expands_with_handler_clauses() {
    assert_eq!(
        expand_items("(define h (handle (perform e) (e (fn (v) v))))"),
        ["(define h (handle (perform e) (e (fn (v) v))))"]
    );
}

// ---------- §C compiler layer (FP3) ----------

#[test]
fn cs01_literal_define_loads_const_and_stores_global() {
    assert_eq!(
        compile_dump("(define a 7)"),
        "func 0 <entry> params 0 locals 0\n  push-const 0 0\n  store-global 0 0\n  halt 0 0"
    );
}

#[test]
fn cs02_binary_application_is_two_consts_global_call() {
    assert_eq!(
        compile_dump("(define s (+ 2 3))"),
        "func 0 <entry> params 0 locals 0\n  push-const 0 0\n  push-const 1 0\n  load-global 0 0\n  call 2 0\n  store-global 1 0\n  halt 0 0"
    );
}

#[test]
fn cs03_if_compiles_to_jump_shape() {
    assert_eq!(
        compile_dump("(define b (if (< 1 2) 10 20))"),
        "func 0 <entry> params 0 locals 0\n  push-const 0 0\n  push-const 1 0\n  load-global 0 0\n  call 2 0\n  jump-if-false 7 0\n  push-const 2 0\n  jump 8 0\n  push-const 3 0\n  store-global 1 0\n  halt 0 0"
    );
}

#[test]
fn cs04_let_compiles_to_store_local_chain() {
    assert_eq!(
        compile_dump("(define l (let ((a 1) (b 2)) (+ a b)))"),
        "func 0 <entry> params 0 locals 2\n  push-const 0 0\n  store-local 0 0\n  push-const 1 0\n  store-local 1 0\n  load-local 0 0\n  load-local 1 0\n  load-global 0 0\n  call 2 0\n  store-global 1 0\n  halt 0 0"
    );
}

#[test]
fn cs05_define_function_produces_closure_proto() {
    assert_eq!(
        compile_dump("(define (f x) (+ x 1))"),
        "func 0 <entry> params 0 locals 0\n  closure 1 0\n  store-global 1 0\n  halt 0 0\nfunc 1 f params 1 locals 1\n  load-local 0 0\n  push-const 0 0\n  load-global 0 0\n  call 2 0\n  ret 0 0"
    );
}

#[test]
fn cs06_anonymous_closure_immediate_call() {
    assert_eq!(
        compile_dump("(define s2 ((fn (x) (* x x)) 6))"),
        "func 0 <entry> params 0 locals 0\n  push-const 0 0\n  closure 1 0\n  call 1 0\n  store-global 1 0\n  halt 0 0\nfunc 1 <entry> params 1 locals 1\n  load-local 0 0\n  load-local 0 0\n  load-global 0 0\n  call 2 0\n  ret 0 0"
    );
}

#[test]
fn cs07_cons_is_an_ordinary_global_call() {
    assert_eq!(
        compile_dump("(define p (cons 1 2))"),
        "func 0 <entry> params 0 locals 0\n  push-const 0 0\n  push-const 1 0\n  load-global 0 0\n  call 2 0\n  store-global 1 0\n  halt 0 0"
    );
}

#[test]
fn cs08_nested_call_is_inner_first() {
    assert_eq!(
        compile_dump("(define c (car (cons 1 2)))"),
        "func 0 <entry> params 0 locals 0\n  push-const 0 0\n  push-const 1 0\n  load-global 0 0\n  call 2 0\n  load-global 1 0\n  call 1 0\n  store-global 2 0\n  halt 0 0"
    );
}

#[test]
fn cs09_fib_closure_is_the_21_instruction_contract() {
    assert_eq!(
        compile_dump("(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2)))))"),
        "func 0 <entry> params 0 locals 0\n  closure 1 0\n  store-global 2 0\n  halt 0 0\nfunc 1 fib params 1 locals 1\n  load-local 0 0\n  push-const 0 0\n  load-global 0 0\n  call 2 0\n  jump-if-false 7 0\n  load-local 0 0\n  ret 0 0\n  load-local 0 0\n  push-const 1 0\n  load-global 1 0\n  call 2 0\n  load-global 2 0\n  call 1 0\n  load-local 0 0\n  push-const 0 0\n  load-global 1 0\n  call 2 0\n  load-global 2 0\n  call 1 0\n  load-global 3 0\n  call 2 0\n  ret 0 0"
    );
}

#[test]
fn cs10_entry_consumes_the_defined_closure() {
    assert_eq!(
        compile_dump(
            "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define r (fib 6))"
        ),
        "func 0 <entry> params 0 locals 0\n  closure 1 0\n  store-global 2 0\n  push-const 2 0\n  load-global 2 0\n  call 1 0\n  store-global 4 0\n  halt 0 0\nfunc 1 fib params 1 locals 1\n  load-local 0 0\n  push-const 0 0\n  load-global 0 0\n  call 2 0\n  jump-if-false 7 0\n  load-local 0 0\n  ret 0 0\n  load-local 0 0\n  push-const 1 0\n  load-global 1 0\n  call 2 0\n  load-global 2 0\n  call 1 0\n  load-local 0 0\n  push-const 0 0\n  load-global 1 0\n  call 2 0\n  load-global 2 0\n  call 1 0\n  load-global 3 0\n  call 2 0\n  ret 0 0"
    );
}

// ---------- §D vm / eval layer (FP4) ----------

#[test]
fn vs01_arithmetic_define_runs_to_value() {
    let (val, globals, outs) = run_vm("(define r (+ 1 2))");
    assert_eq!(val, "nil");
    assert_eq!(globals, "+=#<builtin:+> r=3");
    assert_eq!(outs, "");
}

#[test]
fn vs02_recursive_fact_runs_to_720() {
    let (val, globals, outs) =
        run_vm("(define (fact n) (if (< n 2) 1 (* n (fact (- n 1))))) (define r (fact 6))");
    assert_eq!(val, "nil");
    assert_eq!(
        globals,
        "<=#<builtin:<> -=#<builtin:-> fact=#<closure> *=#<builtin:*> r=720"
    );
    assert_eq!(outs, "");
}

#[test]
fn vs03_cons_produces_opaque_pair_global() {
    let (val, globals, outs) = run_vm("(define p (cons 1 2))");
    assert_eq!(val, "nil");
    assert_eq!(globals, "cons=#<builtin:cons> p=#<pair>");
    assert_eq!(outs, "");
}

#[test]
fn vs04_car_of_cons_selects_left_string() {
    let (val, globals, outs) = run_vm("(define c (car (cons \"left\" 2)))");
    assert_eq!(val, "nil");
    assert_eq!(
        globals,
        "cons=#<builtin:cons> car=#<builtin:car> c=\"left\""
    );
    assert_eq!(outs, "");
}

#[test]
fn vs05_set_mutates_global_in_place() {
    let (val, globals, outs) = run_vm("(define a 1) (define a2 (set! a 5)) (define r2 a)");
    assert_eq!(val, "nil");
    assert_eq!(globals, "a=5 a2=5 r2=5");
    assert_eq!(outs, "");
}

#[test]
fn vs06_let_bindings_sum_to_three() {
    let (val, globals, outs) = run_vm("(define l (let ((a 1) (b 2)) (+ a b)))");
    assert_eq!(val, "nil");
    assert_eq!(globals, "+=#<builtin:+> l=3");
    assert_eq!(outs, "");
}

#[test]
fn vs07_nil_predicate_branches_to_string() {
    let (val, globals, outs) = run_vm("(define s (if (nil? nil) \"is-nil\" \"not-nil\"))");
    assert_eq!(val, "nil");
    assert_eq!(globals, "nil?=#<builtin:nil?> s=\"is-nil\"");
    assert_eq!(outs, "");
}

#[test]
fn vs08_write_line_emits_the_output_line() {
    let (val, globals, outs) = run_vm("(define w (write-line \"out-line\"))");
    assert_eq!(val, "nil");
    assert_eq!(globals, "write-line=#<builtin:write-line> w=nil");
    assert_eq!(outs, "out-line");
}

#[test]
fn vs09_eq_on_two_pairs_is_false_identity_semantics() {
    // Two cons allocations are distinct heap objects: eq? is identity,
    // not structural equality.
    let (val, globals, outs) = run_vm("(define e (eq? (cons 1 2) (cons 1 2)))");
    assert_eq!(val, "nil");
    assert_eq!(globals, "cons=#<builtin:cons> eq?=#<builtin:eq?> e=false");
    assert_eq!(outs, "");
}

#[test]
fn vs10_pair_predicate_is_true_on_pair() {
    let (val, globals, outs) = run_vm("(define p2 (pair? (cons 1 2)))");
    assert_eq!(val, "nil");
    assert_eq!(
        globals,
        "cons=#<builtin:cons> pair?=#<builtin:pair?> p2=true"
    );
    assert_eq!(outs, "");
}

#[test]
fn ve01_eval_engine_fib_ten_agrees() {
    let mut session = Session::new();
    let src = "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define r (fib 10))";
    let outcome = run_source(&mut session, "p.krf", src, Engine::Eval, &[]).expect("eval run");
    assert_eq!(
        outcome.global("r").map(|v| v.to_string()),
        Some("55".to_owned())
    );
}

#[test]
fn ve02_eval_engine_car_selects_left() {
    let mut session = Session::new();
    let src = "(define c (car (cons \"left\" 2)))";
    let outcome = run_source(&mut session, "p.krf", src, Engine::Eval, &[]).expect("eval run");
    assert_eq!(
        outcome.global("c").map(|v| v.to_string()),
        Some("\"left\"".to_owned())
    );
}

// ---------- §E driver layer (FP5) ----------

fn render_of(src: &str) -> String {
    let mut session = Session::new();
    let diags = run_source(&mut session, "p.krf", src, Engine::Vm, &[]).expect_err("must fail");
    driver::render_diagnostics(&session, &diags)
}

#[test]
fn ds01_unclosed_delimiter_render_golden() {
    assert_eq!(
        render_of("(+ 1 2"),
        "error[kerf-read]: unclosed delimiter: `(` is never closed\n --> p.krf:1:1\n  |\n1 | (+ 1 2\n  | ^\n"
    );
}

#[test]
fn ds02_type_mismatch_render_golden() {
    // The Stage 1.8 HM wiring hoists the literal `(car 5)` face to
    // the checker (E0009, probe-verified); this golden keeps the
    // runtime face by feeding `car` through an HM-released dynamic
    // parameter (a forall-a schema the caller satisfies — the shape
    // constraint is released, §9.49 GATE-2).
    assert_eq!(
        render_of("(define f (fn (x) (car x)))\n(define r (f 5))"),
        "error[kerf-runtime]: type mismatch: car operand must be a pair, got `int`\n --> p.krf:1:19\n  |\n1 | (define f (fn (x) (car x)))\n  |                   ^^^^^^^\n"
    );
}

#[test]
fn ds02b_hm_checker_mismatch_render_golden() {
    // The checker face the HM wiring adds: the literal car-of-int
    // is now a compile-time E0009 (probe-verified at Stage 1.8).
    assert_eq!(
        render_of("(define r (car 5))"),
        "error[E0009]: type mismatch: expected `pair`, found `int`\n --> p.krf:1:11\n  |\n1 | (define r (car 5))\n  |           ^^^^^^^\n"
    );
}

#[test]
fn ds03_arity_mismatch_render_golden() {
    // Golden updated with the Stage 1.1 wiring (behavior change: a
    // known-callee arity mismatch is now caught statically before
    // execution — E0002 registry tag, no runtime file# suffix; the
    // runtime face stays covered by the driver module tests through
    // a checker-opaque param-mediated call).
    assert_eq!(
        render_of("(define r (+ 1 2 3))"),
        "error[E0002]: arity mismatch: `+` expects `2` arguments, got `3`\n --> p.krf:1:11\n  |\n1 | (define r (+ 1 2 3))\n  |           ^^^^^^^^^\n"
    );
}

#[test]
fn ds04_unbound_identifier_render_golden() {
    assert_eq!(
        render_of("(define r (undefined-fn 1))"),
        "error[kerf-expand]: unbound identifier `undefined-fn`: not in any lexical scope and not a Stage 0 global\n --> p.krf:1:12\n  |\n1 | (define r (undefined-fn 1))\n  |            ^^^^^^^^^^^^\n"
    );
}

#[test]
fn ds05_empty_application_render_golden() {
    assert_eq!(
        render_of("(define r ())"),
        "error[kerf-read]: empty application: `()` has no operator\n --> p.krf:1:11\n  |\n1 | (define r ())\n  |           ^\n"
    );
}

#[test]
fn ds06_check_face_counts_the_product() {
    let mut session = Session::new();
    let src = "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define r (fib 6))";
    let check = driver::check_source(&mut session, "p.krf", src).expect("check");
    assert_eq!(
        format!(
            "funcs={} instrs={} globals={}",
            check.func_count, check.instr_count, check.global_count
        ),
        "funcs=2 instrs=29 globals=5"
    );
}

#[test]
fn ds07_parity_three_faces_agree() {
    let mut session = Session::new();
    let src = "(define (fib n) (if (< n 2) n (+ (fib (- n 1)) (fib (- n 2))))) (define r (fib 6))";
    let report = driver::run_parity_source(&mut session, "p.krf", src, &[]).expect("parity");
    assert_eq!(
        format!(
            "values={} outputs={} globals={}",
            report.values_agree, report.outputs_agree, report.globals_agree
        ),
        "values=true outputs=true globals=true"
    );
}

#[test]
fn ds08_workspace_version_string() {
    // Golden updated with the v0.63.0 Stage 2.7 window-opening
    // release (behavior change: workspace version bump — the
    // syntax-replacement window opens per the #15 gate ruling:
    // the EBNF v9 final draft (§9.26) plus the skin dictionary
    // mapping base are in place, the Stage 2a closeout quality
    // signals hold (the r92 three-criteria verification), and the
    // user's advance-per-plan instruction completes the double
    // premise; the B2 three-option ruling lands as option 1 —
    // if/perform/handle take expression positions at the primary
    // face (the kernel's expressiveness, the Koka/OCaml 5/Rust
    // precedents, the skin dictionary's completeness); the step-1
    // seed ships: kerf-reader's target module, the v9 Level 0
    // parity subset mapped through the skin dictionary onto the
    // same syntax-object trees, the §9.25.4 parity contract
    // asserted as the semantic projection (instruction streams,
    // constants, globals — the debug_info spans excluded by the
    // layering ruling) plus behavior; the seed-scope boundary
    // (struct/enum/type/effect/capability/match/generics/where/
    // cast/range/field/index/halt/pass) rejects fail-closed with
    // the registered variant; audit AB 284/284, tests 1448:0:0).
    //
    // Prior golden: v0.62.0 recorded at the Stage 2.6 close-out
    // release (behavior change: workspace version bump — the
    // 2.6 window closes with the Stage 2a exit criteria
    // verified in full: (1) the whole compiler in kerf (the
    // five selfhost pieces ride the complete .krf chain —
    // standing evidence re-run this round), (2) the fixpoint
    // C(C(S)) == C(S) re-confirmed with B8 in band, (3) the
    // non-VM backend works (the C transpilation backend —
    // corpus C replay 41/41 re-run, audit AA 274/274
    // maintained); the seven-piece skeleton takes its 2.6
    // write-back rows and the nine signals hold at 8/9 for
    // Stage 2a (the ninth — cross-stage deep verification — is
    // the 2.8 closer's); one formatting drift left by r91 in
    // test_infra_guard_tests.rs is repaid this round; tests
    // 1405:0:0 maintained, audit 274/274 maintained.
    //
    // Prior golden: v0.61.0 recorded at the Stage 2.6
    // first-cut release
    // (behavior change: workspace version bump — the 2.6
    // window opens with three adjudications landed: the build
    // orchestration stays on its Rust bootstrap footing (the
    // mission's ~20% Rust share, a Stage 3+ criterion — the
    // budget shape B7 x files + B8 x stages shows the VM exec
    // phase dominating at >98%, so a `.krf` orchestrator gains
    // nothing semantically), the non-VM backend route is
    // adjudicated as C transpilation (zero external binary
    // dependency — text emission with the host cc, maximal
    // portability, the C-ABI face shared with criterion (4), out
    // of the bootstrap chain by constitution; QBE moves to a
    // Stage 3+ registration), and the FFI ownership model is
    // pre-adjudicated as four rules (eager materialization at
    // the boundary, caller ownership with return transfer,
    // explicit handle roots across calls, C-ABI alignment) —
    // unblocking criterion (4); the Stage 2 seven-piece skeleton
    // lands with the nine signals at 8/9 for Stage 2a; tests
    // 1369:0:0 maintained, audit 264/264 maintained.
    //
    // Prior golden: v0.59.0 recorded at the Stage 2.5
    // close-out release
    // (behavior change: workspace version bump — the
    // fixpoint window closes with its exit criteria verified in
    // full: §21.3 (1) [the whole compiler written in kerf — all
    // five selfhost pieces ride the complete .krf chain, the
    // composed chain and fixpoint tests as the standing evidence]
    // and §21.3 (2) [C(C(S)) == C(S), re-proven by the fixpoint
    // test and pinned by the new B8 cost axis — the whole
    // three-phase proof measured, failing closed on every run;
    // the 2.6 build-orchestration evaluation consumes the number
    // as its bootstrap-verification budget floor]; tests
    // 1369:0:0 maintained, audit 264/264 maintained.
    //
    // Prior golden: v0.58.0 recorded at the Stage 2.5
    // first-knife release
    // (behavior change: workspace version bump — the
    // self-application fixed point: the compiler compiled by
    // itself, EXECUTED in the VM, reproduces its own compilation
    // byte-for-byte (C(C(S)) == C(S), SOP §21.3 exit criterion
    // (2)); the trailing-generation addendum threads the expansion
    // generation through the CP-1 record format (the 1.7 record
    // lineage — the flat stream records carry it trailing, the
    // assembler re-positions it last, the debug products land it
    // in the real spans while the dump text stays
    // generation-free); the rebuild face turns the `.krf`
    // compiler's heap product into a real Bytecode (the opcode
    // kebab reverse table, verify-gated); the elevated gate B
    // sweeps the whole corpus structurally; tests 1369:0:0,
    // audit 264/264.
    //
    // Prior golden: v0.57.0 recorded at the Stage 2.4
    // closure-evaluation release
    // (behavior change: workspace version bump — the
    // closure round adjudicates the three 2.4 exit criteria: the
    // gate-B `.krf`-side swap moves to 2.5 with its prerequisite
    // already witnessed (the dump-faithfulness nine probes), the
    // composed-chain cost axis lands as B7 (median 21.9ms over the
    // FIB anchor, fail-closed on `matched` — the self-hosting
    // multiplier 3081x vs B1's Rust pipeline is the Stage 2a
    // cost story's baseline number), and the drift-convergence
    // ledger (8/19/58) baselines into the calibration register;
    // 2.4 closes with the composed chain as its verification
    // face — 1358:0:0 maintained, audit 256/256 maintained.
    //
    // Prior golden: v0.56.0 recorded at the Stage 2.4 first-knife
    // release
    // (behavior change: workspace version bump — the full
    // composed chain: the 2.4 formula verifies as ONE chain with
    // the `.krf` front end's OWN products feeding forward at every
    // junction (the junction re-encoder rebuilds the `.krf`
    // reader's forms into the expansion layer's prefix, the `.krf`
    // expander's items into the compiler's prefix — never the
    // oracle's intermediates); the routing is total — the drift
    // ledger pins every corpus file into exactly one row (8
    // reader-layer / 19 expander-layer / 58 compiler-layer, counts
    // test-pinned); the seventh self-application — lexer.krf's own
    // source through the COMPLETE `.krf` chain; all five selfhost
    // pieces through the chain; tamper probes at all three
    // junctions fail locally; the empty-product rows ride
    // `(quote nil)` stream prefixes; the gate-B promotion witness
    // proves the analysis-dump grammar a faithful image of the
    // Bytecode semantics (nine field probes — the 2.5
    // precondition); audit section Z growing to sixteen cases
    // (256/256) — 1358:0:0.
    //
    // Prior golden: v0.55.0 recorded at the Stage 1.5
    // second-segment release
    // (behavior change: workspace version bump — the
    // lexical layer of the reader lands in the frozen subset: the
    // byte-table injection generalizes the RS-1 channel with zero
    // freeze-surface change, `lexer.krf` makes every lexical
    // decision (trivia, the Unicode whitespace table, the reject
    // set, atom classification, the i64 threshold guard, the f64
    // grammar automaton, the Symbol floor, escape validity), the
    // unchanged structure layer consumes its `tokens` binding, and
    // the harness checks the FULL .krf chain on three axes (tokens
    // / tree / error) on both engines with the K20 float-value face
    // on the permanent host layer; the corpus sweep rides all 85
    // files through the chain; both own-source fixed points close
    // (the VM bracket face for the past-envelope cases, the
    // K165/K166 discipline); audit section R grows to twenty cases
    // (246/246) — 1343:0:0.
    //
    // Prior golden: v0.54.0 recorded at the Stage 2.3 close-out
    // release
    // (behavior change: workspace version bump — the 2.3 close-out
    // evaluation delivers the composed chain: the `.krf` expander
    // feeding the `.krf` compiler as ONE verification,
    // `compile(expand_oracle(S)) == compile_krf(expand_krf(S))`,
    // with the tree identity asserted in-chain through
    // `ModuleItem: PartialEq` (the 1.6 criterion) and the products
    // compared against the oracle full pipeline through the same
    // dump grammar; the CP9 five-test family (positive anchors, the
    // selfhost fixed points through the full chain — the sixth
    // self-application, compiler.krf expanded by the `.krf`
    // expander and compiled by the `.krf` compiler — the LA-7
    // error axis, the 58-file compiler-layer corpus sweep, and the
    // front-end tamper probe); audit section Z mounting the six
    // composed-chain cases (236/236); the audit deep-stack guard
    // over the new toolchain's main-thread frames (the §9.84.1
    // lineage applied to the audit example itself) — 1321:0:0.
    //
    // Prior golden chain (kept verbatim below; see git history for
    // the full chain): 0.53.0 recorded at the Stage 2.3 second-Pass
    // release (the instruction emission rewritten in the frozen
    // subset: the single emit path with the opcode stack-effect
    // table, the jump backpatching discipline (the placeholder in
    // `a`, the source depth in `b`, both restored by patch — the
    // Lua patchlist lineage, K198), the explicit else-entry depth
    // reset, the tail-position terminator contract, the dense
    // per-instruction debug_info table (K201) and the finish-time
    // placeholder drain (K199) — compiler.krf grows to 1221 lines
    // and the parity products now carry every proto's full
    // instruction stream and span table (K196/K203 the
    // translation-validation shape extended to the emitted code);
    // the emission defenses (stack-underflow / stack-imbalance /
    // unpatched-jump) rebuild through the oracle's own Display as
    // readable drift, bad-patch and bad-node classify as harness
    // defects; the fifth self-application (compiler.krf compiles
    // its own tree — code sections byte-identical, both engines);
    // the thirteen-test CP8 emission family; audit section Y
    // mounting the ten emission cases (230/230); the stack-guard
    // recovery over the new sandbox's 8 MiB test-thread default
    // (the r74 BST-1 lineage applied to the runtime and audit
    // faces) — 1316:0:0.
    //
    // Prior golden chain (kept verbatim below; see git history for
    // the full chain): 0.52.0 recorded at the Stage 2.3
    // fixpoint-window opening release (the first Pass: the
    // lexical-domain analysis in compiler.krf against the Rust
    // oracle on the analysis products, the fourth self-application,
    // audit X, 1303:0:0); 0.51.0 recorded at the Stage 2.2 close-out
    // release
    // (the first-cut
    // close-out verification round: gate B both axes re-run over the
    // full pipeline with the capture descriptors inside the Bytecode
    // equality (a capture-dense composite anchor), the subset-spec
    // capture chapter fully rewritten as the seven-clause semantic
    // face, the quantified ★1' resolution (the B6 closure-creation
    // axis debuts: 47.8ns at frame width 4 vs 47.7ns at width 100 —
    // flat, O(captured) not O(n_locals) — with 222.2ns at 25
    // captures, ~7.3ns each, linear; plus the deterministic guards:
    // a fifty-slot frame with one capture yields a one-slot env, and
    // an explicit §19.4 cycle sweeps exactly the seven uncaptured
    // pairs), B1-B5 reconciled all in band with B4's counters
    // bit-identical for the fifth consecutive run, audit section W
    // mounting the ten capture-family end-to-end cases (210/210),
    // and the three-MUV chain closing sub-stage 2.1 — 1286:0:0.
    //
    // Prior golden chain (kept verbatim below; see git history for
    // the full chain): 0.50.0 recorded at the Stage 2.1 semantic-flip
    // round (LA-1/LA-3/LA-4/LA-5 activate lexical capture on both
    // engines — the dormant full-frame clone retires; 1283:0:0);
    // 0.49.0 recorded at the Stage 2 entry round
    // (the user lift of the stage-2 implementation-entry restriction
    // takes effect on a ten-item all-green base, and the first
    // lexical-addressing MUV lands the flat-capture descriptor as a
    // zero-production intermediate state); 0.48.0 recorded at the
    // selfhost formatting
    // round (the three self-hosted .krf sources and their two Rust
    // consumption faces get the user-named cleanup — every
    // parenthetical dash unifies to the em-dash (the ASCII
    // parenthetical dash is eradicated repo-wide), the 100-column
    // hard bound clears the six outliers (the 684- and 1697-column
    // define monsters re-emitted as 25 and 81 lines, four more
    // surgically split), selfhost/README.md lands as the entry
    // document, and the convention becomes machine-checked (a root
    // guard: width, the non-ASCII whitelist, the dash style —
    // 1261:0:0); whitespace-only by construction (comments are not
    // tokens; B4's swept-1023 counter stays bit-identical) —
    // stage0.md §9.79; prior goldens: 0.47.0 recorded at the
    // diagnostic message content-quality round, 0.46.0 recorded at
    // the typecheck inference-algorithm round, 0.45.0 recorded at
    // the oracle-encoding round,
    // 0.44.0 recorded at the bootstrap-bridge round, 0.43.0
    // recorded at the parity-machine round, 0.42.0 recorded at the
    // evaluator builtin-dispatch round, 0.41.0 recorded at the
    // syntax-tree/core-IR representation round, goldens: 0.39.0
    // recorded at the compiler lowering round, goldens: 0.38.0
    // recorded at the VM execution-core round, 0.37.0 recorded at
    // the checker work-state round, 0.36.0 recorded at the name
    // backend round, 0.35.0 recorded at the expander
    // lexical/transformer identity round, 0.34.0 recorded at the
    // expander error payload round, 0.33.0 recorded at the
    // module-system round, 0.32.0 recorded at the resource-limits
    // round, 0.31.0 recorded at the user-surface round, 0.30.0
    // recorded at the performance-engineering round, 0.29.0
    // recorded at the driver-orchestration round, 0.28.0 recorded
    // at the no-forwarding round, 0.27.0 recorded at the crate
    // boundary review round, 0.26.0 recorded at the
    // test-infrastructure self-audit round, 0.25.0 recorded at the
    // diagnostics-domain round, 0.24.0 recorded at the determinism
    // guard round, 0.23.0 recorded at the symbol interning round,
    // 0.22.0 recorded at the 1.9 stage-close, 0.21.0 recorded at
    // 1.8, 0.20.0 recorded at 1.7, 0.18.0 recorded at 1.5, 0.17.0
    // recorded at 1.4, 0.16.0 recorded at 1.3, 0.15.0 recorded at
    // 1.2, 0.14.0 recorded at 1.1, 0.13.0 recorded at 1.0, 0.12.0
    // recorded at the 0.11 stage-close; 0.64.0 recorded at the
    // switch-window step-2 round; 0.65.0 recorded at the
    // switch-window step-5 round — the two-skin corpus closeout; 0.67.0
    // recorded at the switch-window step-4 round — the target
    // fixpoint through the production bridge; 0.68.0 recorded at
    // the E5 batch-3 removal round — the .krf composition chain
    // retire closeout; 0.68.0 re-asserted at the sandbox-10
    // recovery round with lockstep repaired — the chore-side bump
    // had left this expectation one version behind; 0.69.0 recorded
    // at the stage-2 final L3 closeout round — the ninth signal,
    // the FFI assessment-window ruling, and the Stage 2 GO gate; 0.70.0
    // recorded at the r106 full-pipeline audit round - the web-side
    // independent re-verification caught the expectation one version
    // behind for the second consecutive release (the r105 ds08 lesson
    // reiterated: run the six commands after every version-touching
    // edit, including pre-commit bumps); 0.71.0 recorded at the r107
    // Stage 3+ planning round — the stage-3-plan.md v1.0 window
    // system (10 windows + gate record), K113-K119 knowledge anchors,
    // and the pure-planning discipline (zero production-code change;
    // the only code face is a typecheck header-comment precision fix);
    // 0.72.0 recorded at the r108 inter-stage audit round — the
    // bootstrap-completeness special review (the W-3.12 frontend
    // self-hosting advancement window added to stage-3-plan v1.1),
    // the skin-aware runtime diagnostics (SKIN-DIAG ruling family),
    // and the K120-K123 frontend-bootstrap anchors; 0.73.0 recorded
    // at the r109 interlude audit round — the reader module split
    // (target.rs 2,757-line monolith -> the target/ submodule tree
    // mirroring the S-expression twin's token/lexer/parser layout),
    // the compile-time skin-aware diagnostics (subject sets across
    // expander/typecheck/compiler/module), the user-facing
    // unsupported-form message (plan vocabulary retired), and the
    // module-name dictionary consistency fix (use-form surfaces map
    // through the skin dictionary; the require call carrier rejects
    // fail-closed on the target skin); 0.74.0 recorded at the r110
    // environment-regression fix round — the toolchain-pairing
    // hygiene on the c_backend e2e process boundaries (the v0.73.0
    // Nix dev-shell incident: ambient contaminant variables paired
    // the emitted binary's dynamic loader with a store glibc and
    // every cc-built case died at load with exit 127 — the link and
    // load boundaries now scrub the contaminant sets, a loader
    // abort reports as the environment-pairing defect it is, the
    // stdin feed never masks a dead child behind a broken-pipe
    // panic, and the ambient incident replay joins scripts/testing).
    assert_eq!(kerf::WORKSPACE_VERSION, "0.76.0");
}

#[test]
fn ds09_output_lines_keep_submission_order() {
    let mut session = Session::new();
    let src = "(define r (write-line \"a\")) (define r2 (write-line \"b\"))";
    let outcome = run_source(&mut session, "p.krf", src, Engine::Vm, &[]).expect("run");
    assert_eq!(outcome.outputs.join(" | "), "a | b");
    assert_eq!(outcome.value_display(), "nil");
}

#[test]
fn ds10_two_diagnostics_render_with_summary_line() {
    // Two broken files in one session: errors are data — collected
    // across runs, rendered together, closed by the summary line.
    let mut session = Session::new();
    let mut all = Vec::new();
    for (name, src) in [("one.krf", "(+ 1"), ("two.krf", "(define r (nope))")] {
        if let Err(diags) = run_source(&mut session, name, src, Engine::Vm, &[]) {
            all.extend(diags);
        }
    }
    let rendered = driver::render_diagnostics(&session, &all);
    assert_eq!(
        rendered,
        "error[kerf-read]: unclosed delimiter: `(` is never closed\n --> one.krf:1:1\n  |\n1 | (+ 1\n  | ^\n\nerror[kerf-expand]: unbound identifier `nope`: not in any lexical scope and not a Stage 0 global\n --> two.krf:1:12\n  |\n1 | (define r (nope))\n  |            ^^^^\nerror: aborting due to 2 previous errors\n"
    );
}

#[test]
fn ds11_literal_errors_render_whole_token_spans() {
    // v0.40.0 (stage0.md §9.71): the literal family carries its
    // whole-token span — the render points at the literal's full
    // extent (rustc underlines the literal in its own out-of-range
    // diagnostics; kerf mirrors). Before, these rendered with no
    // location line at all.
    assert_eq!(
        render_of("(define r 1.2.3)"),
        "error[kerf-read]: malformed number literal `1.2.3`\n --> p.krf:1:11\n  |\n1 | (define r 1.2.3)\n  |           ^^^^^\n"
    );
    assert_eq!(
        render_of("(define r 9223372036854775808)"),
        "error[kerf-read]: integer literal `9223372036854775808` out of range for `i64`\n --> p.krf:1:11\n  |\n1 | (define r 9223372036854775808)\n  |           ^^^^^^^^^^^^^^^^^^^\n"
    );
    assert_eq!(
        render_of("(define r 1e999)"),
        "error[kerf-read]: float literal `1e999` out of range for `f64`\n --> p.krf:1:11\n  |\n1 | (define r 1e999)\n  |           ^^^^^\n"
    );
}

// ---------- §F repl transcripts (FP6) ----------

#[test]
fn ts01_session_transcript_values_and_outputs() {
    let mut repl = Repl::new();
    let mut transcript = Vec::new();
    for line in ["(define x 41)", "(+ x 1)", "(write-line \"hi\")"] {
        match repl.submit(line) {
            ReplEvent::Evaluated {
                value,
                new_outputs,
                new_warnings,
            } => {
                assert!(new_warnings.is_empty(), "ts02 warning-free corpus");
                transcript.push(format!(
                    "value={:?} outputs={:?}",
                    value.unwrap_or_default(),
                    new_outputs
                ))
            }
            other => panic!("unexpected event: {other:?}"),
        }
    }
    assert_eq!(
        transcript,
        [
            "value=\"\" outputs=[]".to_owned(),
            "value=\"42\" outputs=[]".to_owned(),
            "value=\"nil\" outputs=[\"hi\"]".to_owned(),
        ]
    );
}

#[test]
fn ts02_error_submission_rolls_back_and_session_survives() {
    let mut repl = Repl::new();
    match repl.submit("(define y 5)") {
        ReplEvent::Evaluated { .. } => {}
        other => panic!("define: {other:?}"),
    }
    match repl.submit("(+ y undefined-var)") {
        ReplEvent::Error { rendered } => {
            assert_eq!(rendered.lines().count(), 5);
        }
        other => panic!("error expected: {other:?}"),
    }
    match repl.submit("y") {
        ReplEvent::Evaluated { value, .. } => assert_eq!(value.as_deref(), Some("5")),
        other => panic!("y: {other:?}"),
    }
}

#[test]
fn ts03_unclosed_submission_asks_for_more() {
    let mut repl = Repl::new();
    assert!(matches!(repl.submit("(+ 1"), ReplEvent::NeedMoreInput));
}

#[test]
fn ts04_continuation_line_completes_the_program() {
    let mut repl = Repl::new();
    assert!(matches!(repl.submit("(+ 1"), ReplEvent::NeedMoreInput));
    match repl.submit("2)") {
        ReplEvent::Evaluated { value, .. } => assert_eq!(value.as_deref(), Some("3")),
        other => panic!("continuation: {other:?}"),
    }
}

#[test]
fn vd01_value_display_eight_forms() {
    let forms = [
        Value::Int(-7).to_string(),
        Value::Float(2.5).to_string(),
        Value::Bool(true).to_string(),
        Value::Str("s".into()).to_string(),
        Value::Nil.to_string(),
        Value::Pair(3).to_string(),
        Value::Closure(9).to_string(),
        kerf::vm::Builtin::from_name("+")
            .map(|b| Value::Builtin(b).to_string())
            .unwrap_or_default(),
    ];
    assert_eq!(
        forms,
        [
            "-7",
            "2.5",
            "true",
            "\"s\"",
            "nil",
            "#<pair>",
            "#<closure>",
            "#<builtin:+>",
        ]
    );
}

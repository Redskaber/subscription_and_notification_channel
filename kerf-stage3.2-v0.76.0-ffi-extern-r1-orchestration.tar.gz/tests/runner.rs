//! Cross-crate integration test single entry (SOP §8.4.6 v11.2).
//!
//! Cargo auto-discovers this file as the root package's integration test
//! target. Every test module under `tests/v0/stage-N/{plan,gate}/` is
//! mounted here via `#[path]` — no per-file `[[test]]` declarations.
//! Shared helpers live in `common/` and are mounted exactly once here
//! (submodules import them via `super::common` — mounting the same file
//! from several submodules trips the duplicate-module lint).
//! Selective run: `cargo test --test runner <module>::<case>`.

#[path = "common/mod.rs"]
mod common;

#[path = "v0/stage0/plan/span_seed_tests.rs"]
mod span_seed_tests;

#[path = "v0/stage0/plan/core_seed_tests.rs"]
mod core_seed_tests;

#[path = "v0/stage0/plan/syntax_seed_tests.rs"]
mod syntax_seed_tests;

#[path = "v0/stage0/plan/reader_seed_tests.rs"]
mod reader_seed_tests;

#[path = "v0/stage0/plan/expander_seed_tests.rs"]
mod expander_seed_tests;

#[path = "v0/stage0/plan/compiler_seed_tests.rs"]
mod compiler_seed_tests;

#[path = "v0/stage0/plan/vm_seed_tests.rs"]
mod vm_seed_tests;

#[path = "v0/stage0/plan/runtime_seed_tests.rs"]
mod runtime_seed_tests;

#[path = "v0/stage0/plan/driver_seed_tests.rs"]
mod driver_seed_tests;

#[path = "v0/stage0/plan/macro_seed_tests.rs"]
mod macro_seed_tests;

#[path = "v0/stage0/plan/reserved_seed_tests.rs"]
mod reserved_seed_tests;

#[path = "v0/stage0/plan/snapshot_seed_tests.rs"]
mod snapshot_seed_tests;

#[path = "v1/stage1/plan/typecheck_seed_tests.rs"]
mod typecheck_seed_tests;

#[path = "v1/stage1/plan/typecheck_wiring_seed_tests.rs"]
mod typecheck_wiring_seed_tests;

#[path = "v1/stage1/plan/pbt_seed_tests.rs"]
mod pbt_seed_tests;

#[path = "v1/stage1/plan/hm_inference_seed_tests.rs"]
mod hm_inference_seed_tests;

#[path = "v1/stage1/plan/stage_exit_tests.rs"]
mod stage_exit_tests;

#[path = "v1/stage1/plan/subset_corpus_tests.rs"]
mod subset_corpus_tests;

#[path = "v1/stage1/plan/parity_contract_tests.rs"]
mod parity_contract_tests;

#[path = "v1/stage1/plan/symbol_intern_tests.rs"]
mod symbol_intern_tests;

#[path = "v1/stage1/plan/determinism_guard_tests.rs"]
mod determinism_guard_tests;

#[path = "v1/stage1/plan/test_infra_guard_tests.rs"]
mod test_infra_guard_tests;

#[path = "v1/stage1/plan/perf_observability_guard_tests.rs"]
mod perf_observability_guard_tests;

#[path = "v1/stage1/plan/limits_ladder_guard_tests.rs"]
mod limits_ladder_guard_tests;
#[path = "v1/stage1/plan/message_quality_guard_tests.rs"]
mod message_quality_guard_tests;

#[path = "v1/stage1/plan/selfhost_format_guard_tests.rs"]
mod selfhost_format_guard_tests;

#[path = "v1/stage1/plan/composed_target_chain_tests.rs"]
mod composed_target_chain_tests;
#[path = "v1/stage1/plan/fixpoint_tests.rs"]
mod fixpoint_tests;

#[path = "v1/stage1/plan/lexical_capture_guard_tests.rs"]
mod lexical_capture_guard_tests;

#[path = "v1/stage1/plan/capture_cost_guard_tests.rs"]
mod capture_cost_guard_tests;

#[path = "v1/stage1/plan/c_backend_e2e_tests.rs"]
mod c_backend_e2e_tests;

#[path = "v1/stage1/plan/target_reader_seed_tests.rs"]
mod target_reader_seed_tests;

#[path = "v1/stage1/plan/target_fixpoint_tests.rs"]
mod target_fixpoint_tests;

#[path = "v1/stage1/plan/target_corpus_sweep_tests.rs"]
mod target_corpus_sweep_tests;

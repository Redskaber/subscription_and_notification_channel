# 综合技术债登记册（tech-debt-register.md）

> 依据：docs/sop.md §6.2.1。只追加不删除；已解决项保留历史并标注 `[Resolved at Stage N.M]`。
> **Author**: redskaber（模板口径沿袭 sop.md §6.6.1 样例）
> **Version**: v0.22.0（Stage 1.9 收口——无新 TD[末轮 L3 全流程：§9.50 检查器域审查零 ★ + D1-D8 全过 + §14.8 八项偏差全处置 + C1-C6 六检零整改 + 七件套终稿 + audit V 节 200 + 出阶段测试族；**Stage 1 全程 TD 开放项归零**——1.0 起连续十四轮；九信号全勾 + GO 推荐（用户确认最终门）]））
> **最后更新**: Stage 1.9（收口）/ 2026-09-29

### 1.6 架构摘要增量（展开层自举时点）

- **expander.krf 自举面第二件**：`selfhost/v1/`（切换窗步②第二切口；8 原语不变性第二十轮验证——纯消费者零新增面）。
- **互递归禁令的工程化解**：表达式展开器 = 单 define 自递归 + 五合成节点模式（mapx/letloop/doloop/clausemap/fnbind）——冻结子集「define 级互递归不可达」（neg-046 实证）的架构响应；REC-A 谱系第三实例。
- **扁平前序流编码**（EX-1）：255 深树注入不触 Reader 256 帽（嵌套编码需 depth+3 的实证推论）。
- **登记态窗口**（§9.47.5）：宏面窗（1.7 主窗——Macro 层 = oracle 占位）+ 词法层第二段窗（维持）+ evaluator 栈预算窗（维持）。

### 1.5 架构摘要增量（结构层自举时点）

- **selfhost/ 新根目录**（§8.4.6 跨 crate 全局面——自举面登记，切换窗步②首切口物理锚位）；.krf Reader = 既有 8 原语 + 18 内建 + 8 特殊形式纯消费者（零新增面——8 原语不变性第十九轮验证）。
- **kerf-reader 公共面补全**：`pub use kerf_span::{ByteOffset, FileId}`——既有签名类型可名化（零新 Cargo 边）。
- **登记态窗口三项**（§9.46.5）：词法层第二段窗（前置 = 字符串原语子集扩展裁定 K21）+ 字符串原语扩展窗（§9.44.5 三触发器沿袭）+ 输入带指令窗（第二段评估位）。

### 1.4 架构摘要增量（子集冻结时点）

- 验证基础设施五层齐备：快照 / 黄金 / 自举（parity 双引擎）/ 属性（PBT）/ **语料契约（本轮新增——目录制 .krf + ;; expect: 指令[ dg-* 模式] + parity 契约面 validate/validate_all）**；审计集 150（Q 节元审计——detector-detects）；语料 68 = pos 26 / neg 32 / bnd 10（期望全实证——探针轮 68/68 固化）。
- 工作树终态：1046 测试（crate 内联 12 + 根集成 81 净增——语料逐条 68 + 元 3 + 契约 12 - 字段共变 2）+ audit 150（A-Q）+ 基线 B1-B5 维持（契约面不在热路径——实测确认）；ParityReport 加性字段 globals_repr（构造位共变 3 处全披露）。

### 1.2 架构摘要增量（PBT 引入时点）

- 测试基础设施四层齐备（DEA-13 闭合）：快照（57 冻结）/ 黄金（渲染字节契约 + 版本黄金）/ 自举（parity 双引擎）/ **属性（本轮新增——proptest 1.11.0 dev-dep[^1.9 约束解析 1.x line] + 七属性：双引擎 parity/运行时陷阱/归约语义/静态 E0006/reader 不动点/VM 确定性/算术 oracle）**；良构生成器 typed 三通道（Int/Bool/Any——深度帽 4 + define 帽 4 + ±2⁴⁰ oracle 带）；审计集 130/130 维持（PBT 与样例审计互补裁定——不扩节）。
- 工作树终态：890 测试（根集成 +9[7 属性 + 2 域自检]——cargo test 函数口径，生成用例量 448）+ audit 130（A-N）+ 基线 B1-B5 维持；生产依赖面零变化（proptest 仅 [dev-dependencies]——§18.5 dev 侧豁免位）。

### 1.1 架构摘要增量（driver 接线时点）

- 新内部边 L4.5→L8（kerf-typecheck→kerf-driver——消费边无环；Externals 第三消费位单源构造）；管线终态 = read→expand→typecheck→{compile→VM, eval}（检查器 Error 级执行前中止 / Warning 级附着 Outcome 三面非阻断）；DiagnosticCode::Typecheck(TypeCode) 数据携带变体（渲染 tag = E0xxx 注册码——两方案接线处汇合）；REPL 警告增量重放（前缀规则与 outputs 同款）；审计集 130（+N 节十案）。
- 工作树终态：881 测试（driver 内联 118[+25] + 根集成 210[+10]——cargo test 口径）+ audit 130（A-N）+ 基线 B1-B5 维持；生产面 .unwrap 0 / glob re-export 0 / §11 反向边 0 维持。

## 1. 已解决项（Resolved）

| ID | 描述 | 解决阶段 | 验证方式 |
|----|------|---------|---------|
| TD-002 | `Span::join` 跨展开代合并被拒绝（JoinExpansionMismatch）：跨代合并语义属宏期关注点，未定义 | **[Resolved at Stage 0.4]** 裁定三（plan-0.4.md §4）：0.4 展开器零 span 构造（脱糖节点复用源 span 同代次）→ 跨代 join 结构性不发生；拒绝语义保持为设计行为（fail-closed）；0.9 宏系统登记 span 集合表示议程（def-site ∪ use-site——非点合并） | fib/do 契约测试全产出 span join 折叠全成功（单代次实证）+ syntax_seed_tests 跨代次拒绝穿透（0.2）守护 |
| TD-004 | §18.5 依赖图未含 kerf-span→kerf-core 边，与 stage0.md §8.6「IR 节点携带 Span」存在张力 | **[Resolved at Stage 0.1]** 裁定二（docs/develop/v0/stage-0/0.1-design-adjudications.md）：全节点携带必填 Span（非 Option）+ 加边 L0→L4 + dataflow.md 同步 | core_seed_tests.rs 8/8（span 归约双向模式 + Span 不变量穿透聚合路径） |
| TD-005 | 原语集双轨口径（r67 现行真值集 vs §3.2 历史冻结集）待正式裁定落文 | **[Resolved at Stage 0.1]** 裁定一（同上文件）：CoreExpr 九语义原语 + ModuleItem 三声明变体 + do→Let 脱糖；§6.12.6 语义等价映射双向闭合；八原语 ANF 形态登记为 Stage 2 评估目标（零实现义务） | expr.rs kind_name 九变体断言 + 裁定文映射表闭合论证 + ALG-C 会签 |
| TD-001 | 行/列渲染延后：Span 仅存字节偏移（stage0.md §12.1 渲染期派生原则），LineIndex 与行列派生属诊断渲染层 | **[Resolved at Stage 0.8]** 裁定十三（plan-0.8.md §4）：`LineIndex` 渲染期派生落位（1 基行 + 1 基**字符**列——CJK 终端真值；中点字符向下取整 + 越界钳制——确定性不 panic）+ rustc 风格渲染收口（`error[code]: msg` + `--> file:line:col` + 源摘录 + 脱字符下划线 + 多诊断汇总行）；`Diagnostic.primary_span: Option<Span>` 诚实设计（无位变体免伪造——免 `-->` 免摘录） | line_index 13 + render 13 内联测试 + 审计 I01/I10 + seed 渲染黄金字节契约 + CJK 字符列可区分断言（1:19 vs 字节列 1:21） |
| TD-003 | 8 个骨架 crate 待实现（结构性脚手架——计划内，非事故性桩）；core@0.1、syntax@0.2、reader@0.3、expander@0.4、compiler@0.5、vm@0.6、runtime@0.7、**driver@0.8** | **[Resolved at Stage 0.8]** 全部落位（**9/9 crate**——0.0 章程 TD-003 终态清零）：kerf-driver = 管线编排（Engine 双引擎）+ Session/LineIndex/诊断渲染 + CLI/REPL（session-replay 裁定十二）+ bin `kerf`；L1→L8/L7→L8 新边裁定十一入档 | 六命令冷构建 551:0:0 + 审计 80/80 + E2E 22 case（五类源可达错误类经 driver 全点亮）+ `cargo run --bin kerf` 全命令族实测 |
| TD-006 | docs/stage0.md 文件头版本标签（v8.8）滞后于内容实态（v9.9——尾部附录 G v7 终态注记 + §9.43）；上游存档保持原样不改写 | **[Resolved at Stage 1.0]** 用户显式指令开窗（M1 先例——r74「用户指令 = 需求信号本体」）：文档状态行 v8.8→v9.9（增量链叙述 + v8.8 基线描述保留）+ 版本历史「v7.0（当前）」过期标签修正（→历史）+ v7.1-v8.8 / v9.1-v9.9 两条合并条目 + 文件尾附录 G v9 终态注记（v9.9 版本终态 + 四处一致声明）——TD 账面归零 | 四处一致性核验（v9.9 命中文档状态行/版本历史合并条目/附录 G v9 终态注记 + lang-design/README 代偿说明退役） |

## 2. 剩余项（Open）

| ID | 描述 | 等级 | 目标解决 | 阻塞条件 |
|----|------|------|---------|---------|
| TD-007 | 宏声明目标皮肤面：`define-syntax`/`syntax-rules` 规则携带裸表数据——目标表达式文法无裸表参数位（quote 包裹改变宏系统匹配树）；调用形 `name!(...)` 可用，声明形未实现 | **[Open · P3 · 登记态]** r103 步⑤ 账本登记（switch-window-plan §5.6.1 E8——9 语料案承载）；**消费路径裁定 @ r104**（E5 批次 3 收口：生产链 = .ktf 唯一皮肤后，宏声明的生产链消费需目标声明面实现——维持登记态，下一消费信号 = Stage 2+ 宏系统窗口开窗评估）；零当前阻塞（验收语料 .krf = 测试数据面两皮肤双跑终态维持——冻结资产保留） | target_corpus_sweep_tests 宏声明账本钉扎（ledger_key 断言）+ AF8 |

## 3. 架构摘要（Stage 0.10 时点）

- 流水线：`Reader → Expander → Compiler → VM → Runtime` + Driver 编排（九层 9/9）+ **基础卫生宏系统**（define-syntax/syntax-rules 变换器 + CodeValue 结构化代码值 + 模块加载层[三色 DFS 环检测 + LoadPlan] + quote 数据字面量）+ **reserved 冻结面**（kerf-core/src/reserved/ 四模块：EffectSystem/MultiStage/CapabilityIO/CompilationCache + 行为规格 kit——§22.3 四接口项全 ✅；零入边自含抽象——除 std 外零依赖[裁定十七]；全图见 docs/graph/stage-0/dataflow.md）
- 测试计数：**672**（分项 = span 40 + core 77[+36：reserved 内联 30 + api 6] + syntax 40 + reader 54 + expander 85 + compiler 44 + vm 55 + runtime 42 + driver 97 + 根集成 runner 138[+12 reserved_seed]；正负比 272:400 = 1:1.47——0.10 轮 32:16 反向偏差申报见 plan-0.10.md §3[预留轮验收面结构性正向]）+ §7.3.1 审计集 100 case（examples/audit/stage0_gate_audit_r1.rs 可重跑——30→…→100 单调增长；**七类 7/7 维持**）
- Span::DUMMY 状态：**不存在 DUMMY span**——`Span::new` 为校验构造（start ≤ end 强制），空 span 合法但携带真实偏移；CoreExpr/ModuleItem/SyntaxObject（含 reader 产树全节点）span 为必填字段（非 Option——结构性无 DUMMY，TD-004 裁定二延展至语法/读取层）；compiler debug_info 逐指令平行（除空程序冷启动锚一处零 span 构造——plan-0.5.md §4 决策 15）；未来任何 DUMMY 引入即 P1（§6.2 分级审查）
- 枚举分支覆盖：SpanError 三变体 + CoreError 三变体 + SyntaxError 二变体 + ReadError 十变体 + ExpandError **九变体**（+MacroPatternMismatch/+QuoteUnsupportedDatum，0.9）+ **ModuleError 三变体**（ModuleCycle/ModuleNotFound/ModuleDuplicate，0.9）+ **CompileError 十三变体**全部有负向断言（构造拒绝/合并拒绝/消息渲染/R8 形态；InvalidSymbol 三 crate 渲染逐字节一致——单源字典）
- 错误系统状态：kerf-span / kerf-core / kerf-syntax / kerf-reader / kerf-expander / kerf-compiler 均手写 `std::error::Error`（零外部依赖——§18 审查规避裁定沿袭）；CompileError（十三变体，0.5——verify 公共面裁定四：编译期簿记 + 产物自检两道防线）；**RuntimeError（十变体，0.6——全携带 Span 回查 + span() 消费面；七类 #4/#5 点亮 → 6/7）**
- 原语集真值：CoreExpr 九语义原语（r67 命名）+ ModuleItem **四声明变体**（+DefineSyntax，0.9）——单一事实源 = crates/kerf-core/src/{expr,module,symbol}.rs（TD-005 裁定一）；八原语 ANF 形态 = Stage 2 评估目标（登记态，零实现义务）
- 字节码真值：Opcode 24 操作码（§8.12 七分组 + Perform/Handle 承载扩展）+ Instr{op,a,b} 双槽 + FuncProto（code/debug_info 平行）+ Bytecode 五件套（funcs/consts/globals）——单一事实源 = crates/kerf-compiler/src/{opcode,bytecode}.rs；`Bytecode::verify` = 唯一合法性判据（DAG 深度传播 + 结构校验）；三层帽序 reader 256 < expander 512 < compiler 1024（逐层 2× 裕量）
- 运行时真值（0.6）：Value 八变体 + Heap 单调分配（§19.4 安全点 = 分配预算 u32——0.7 gc_cycle 挂接点）+ 帧三扩展槽冻结（ext1/ext2 Reserved + ext3 实名）+ STAGE0_GLOBALS 18 名播种注册表（Builtin::ALL 单源）+ DEFAULT_BUDGET 8MiB（帧+堆单元合账）——单一事实源 = crates/kerf-vm/src/{value,builtin,frame,vm}.rs；0.5 缺陷修复：end_closure cur_stack LIFO（多闭包产物正确性——plan-0.6.md §4 回归对）

### 架构摘要 0.11 增量（末轮收口时点）

- 快照层 57（tests/v0/stage0/plan/snapshot_seed_tests.rs——L1→L8 六分节全链冻结 + 黄金值录制纪律 + 共变义务文档化）+ 性能基线 B1-B5（examples/bench/stage0_baseline.rs std-only 可重跑 + performance-baseline.md 回归口径）+ 深验七件套（docs/develop/v0/stage-0/ + docs/tests/pipeline-test-coverage.md）——Stage 0 出阶段评审 GO（§21.5 九信号 + §22.3 十二项全勾）。
- 工作树终态：767 测试（内联 489 / crate API 78 / 根集成 200）+ audit 110（A-L）+ 基线 5 项；生产面 .unwrap 0 / .expect 33（全带理由）/ TODO 族 0 / glob re-export 0 / §11 反向边 0。
- 登记顺带项（非 TD）：闭包创建整帧 locals.clone（vm.rs:244——Stage 2 优化窗捕获分析）；builtin.rs 四处裸 unreachable!()（臂前守卫完备——Stage 1 E0xxx 议程顺带补消息惯例）。

## 4. 分类索引

- 按 §6.1 等级：**开放项 1（TD-007 @ r103 登记——P3 登记态：宏声明目标皮肤面，E5 批次 3 消费路径裁定承载）+ 登记窗五件（W-PERF-ENV-COPY / W-TGT-TOKEN-ZERO-COPY / W-DRIVER-HARNESS-SPLIT @ r106；W-BOOT-FRONTEND / W-DIAG-OPCODE-CONTEXT @ r108）**｜已解决 ×6（TD-004/005 @ 0.1，TD-002 @ 0.4，TD-001/TD-003 @ 0.8，**TD-006 @ 1.0**）｜缺陷修复 ×3（0.5 end_closure cur @ 0.6；0.7 invoke 悬垂 @ 0.7；0.8 TapeIo/stdin @ 0.8——均 §20.6 当轮闭环零遗留）｜0.10/0.11/1.0 轮：无新 TD
- 按 §11.3 接口隔离违规（L-PIPE-N）：无
- 按 §10 命名违规（L-NAMING-N）：无
- 按 §13.4 重构判据（J1-J6）：无

### r106 登记窗三件（全管道审查轮——P3 处置三分类的登记窗面；蓝图先行，零信号不开窗）

| ID | 描述 | 状态 | 触发器 |
|---|---|---|---|
| W-PERF-ENV-COPY | vm.rs invoke 每调用 `data.env.clone()` O(captured)——闭包创建 O(captured)（★1' 已兑现）之外的每调用拷贝；B2 基准带内无信号 | **[Resolved at Stage 3.1 · r111]** 实施清偿：Rc<Vec<Value>> 共享不可变捕获区（结构性不变量验证——无 store-to-captured 操作码 + 细胞 env 创建后零变更）；B6d 新轴 141.7→108.8ns（−23.5%）+ 创建面 +9~19% 带内 + B4 第二十次逐位（K91 守护）；裁决册 = docs/develop/v3/w3.1-performance-window.md §2（三选一论证 + 权衡披露） | ~~Stage 3+ 性能窗开窗~~（已消费——r111 行权轮） |
| W-TGT-TOKEN-ZERO-COPY | target.rs TgtToken 每令牌 String 词素分配（S-expr 面 K137 零拷贝纪律未对齐）；text 仅错误路径消费 | **[Resolved at Stage 3.1 · r111]** 实施清偿：`text: &'src str` 源切片（生命周期内化 target 模块）+ digits_text Cow（无 `_` 零分配解析）；错误路径独占消费经全量清点证实（err_unexpected 单点——错误位自付 to_string）；B10 1.01x 带内 + B4 逐位；裁决册 = w3.1-performance-window.md §4 | ~~目标面性能信号 或 错误路径重构窗~~（已消费——随窗开启一并裁决） |
| W-DRIVER-HARNESS-SPLIT | driver 10,906 LOC 中验证 harness 族 6,795 行（62%）持续生长；E5 共享设施 19 符号引用 ≥3 无死码（保留正当） | [Open · P3 · 观察态] r106 登记（106-b-3）；Stage 3+ 验证面继续扩张时评估 kerf-selfhost-harness crate 拆分——须与 refactoring-optimality「维持不重构」六裁定重新核对 | harness 族再增 >30% 或新验证域入驻 driver |

**r106 复审推翻记录（如实登记）**：106-b-2 报告 `Heap::get_mut` 为「仅测试消费死码」——主代理复审实测 kerf-runtime/src/gc.rs:201 为生产收集器消费（活码）——零改动；审查发现以代码为准的实例（与 §9.44.3 symbol 行诚实修正同族）。

### r108 登记窗两件（阶段间审查轮——108-b 专审缺口清偿面；蓝图先行，零信号不开窗）

| ID | 描述 | 状态 | 触发器 |
|---|---|---|---|
| W-BOOT-FRONTEND | 前端自举推进缺口本体：BS-A 端态（前端三段+HM+构建编排全自举）与实况差距（read/expand/typecheck 生产面全 Rust 引擎、.ktf 孪生仅验证面、HM/构建编排零孪生）无收敛路径窗口——r107 stage-3-plan v1.0 十窗缺位（108-b 五源核查）；用户硬规则常设指令「一个编译阶段完整自举后才能进入下一阶段自举」的需求信号承载 | [Open · P3 · 登记态] r108 108-b 专审登记；K120-K123 四锚（rustc 三段自举/Chez pb bootfiles/Guile psyntax-pp/Racket #lang reader）；**stage-3-plan v1.1 W-3.12 已承载**（段序硬规则 reader→expander→裁定段 + 测量先行 + 三选一论证） | ~~Stage 3 行权 → W-3.12 开窗~~（**已消费 r111**——3.12-a 评估册落地：三选一 = 维持[vm/rust 稳态 450× 超带] + 注入通道生产化改造面登记；**新触发器（二选一重开段一实施议程）**：T-a W-3.7 tier-up 后 vm/rust < 10× 实测 / T-b fixpoint 经 .ktf reader 的纯度面需求——w3.12-frontend-window.md §5 单源） |
| W-DIAG-OPCODE-CONTEXT | 运行期 type-mismatch 上下文的操作码词汇面：r108 FIX-1 已清偿内建名/用户名皮肤感知（target_name/target_context + 六单源合成函数）；残留 = 操作码上下文（「add operand」「jump-if-false condition」「call callee」）的表面构造感知（用户书写面 `+`/`if`/调用形——两皮肤同形非皮肤分歧，属诊断质量面非残留） | [Open · P3 · 登记态] r108 108-b 登记（FIX-1 部分清偿后的残留面）；LSP 结构化诊断载荷设计的候承载面 | W-3.9 LSP 窗（结构化诊断载荷设计节） |

### r109 登记窗一件 + 观察裁定三件（阶段间审查轮——三角度审查处置面）

| ID | 描述 | 状态 | 触发器 |
|---|---|---|---|
| W-DIAG-FORM-NOTATION | MalformedForm 静态描述的形状记法皮肤感知：消息内嵌 s-expr 形状记法（如 "expected (require \"module-name\") with a string module name"）向 .ktf 用户呈现 s-expr 记法——与 F1/F2 同族但机制不同（静态 &'static str 描述非 Symbol 载荷，subject 供给面不适用；正确修法 = 形状描述的皮肤感知双面化，属结构化诊断载荷设计） | P3 登记态 | W-3.9 开窗（LSP 结构化诊断载荷设计时一并承载——与 W-DIAG-OPCODE-CONTEXT 同窗） |

观察裁定三件（登记不实施——无缺陷驱动）：
- **infer.rs 2,676 行 / expand.rs 2,202 行单文件不拆裁定**：单关注文件（无孪生模式可镜像——crate 内兄弟文件均为单关注面）；拆分 = 无一致性缺陷驱动的品味性变更（§2.3 正确>妥协：无正确性收益的重组 = churn 风险）；K126 权衡——rustc 的拆分以关注点为界不以行数为界。
- **driver/driver target_corpus.rs 与 cbackend emit.rs 转义 8 行近孪生不合并裁定**：不同消费面（.ktf 数据载体转义 vs C 字符串转义——转义域不同）+ 跨 crate 依赖方向约束（cbackend 不依赖 driver）；r106 FIX-9 已在 driver 内单源化（emit_escaped_string）。
- **ModuleNotFound 显式 kebab 串的用户面呈现**：target face 写 require 串 "m-a"（显式 kebab）时错误呈现 target 拼写 `m_a`（canonical m-a 的目标面拼法）——按 F5 语义这是「教导正确拼法」非腐蚀（字符串面已被字典接管）；边界行为如实登记。

### r110 检视（环境回归修复轮——零新 TD；观察裁定一件）

- **零新 TD**：v0.73.0 工具链配对事件（12 个 c_backend_e2e 全灭 exit 127）当轮全量闭环——根因定位（环境性非树缺陷）+ 双边界 scrub + 诊断面 + 三面防护证明（+4 测试）落位；树内无残留债务。
- **观察裁定一件（登记不实施——环境侧非仓内缺陷）**：cc wrapper **自身内部** glibc 混装场景（多 nixpkgs 修订 flake 输入拼装 dev-shell——解释器在链接期被 wrapper 烘焙错配）scrub 不可治 → `loader_abort_report` 可行动诊断承载（§2.3-4 报错>静默）；用户侧行动 = 重建一致 dev-shell。设计层：stage0 §9.105.4。
- **开放项复核**：TD-007 @ P3 登记态维持 + 登记窗六件（W-PERF-ENV-COPY / W-TGT-TOKEN-ZERO-COPY / W-DRIVER-HARNESS-SPLIT / W-BOOT-FRONTEND / W-DIAG-OPCODE-CONTEXT / W-DIAG-FORM-NOTATION）零信号维持——r110 触发器核对：纯测试 harness 环境卫生面，六窗全不相交。

### r111 检视（Stage 3 行权轮——双刀实施清偿 + 零新 TD；触发器重定义一件）

- **零新 TD**：W-3.1 两刀（env-copy + TgtToken 零拷贝）均按裁决册实施清偿（上表两行 [Resolved at Stage 3.1]）——表示级变更零语义面（B4 第二十次逐位 1/1023 + 1381:0:2 全绿维持为最强实证）；B6d 调用份额轴新增（测量面非债务面）。
- **触发器重定义一件**：W-BOOT-FRONTEND 消费信号更新（r108 登记的「Stage 3 行权 → W-3.12 开窗」已消费——3.12-a 评估册裁决 = 维持；新触发器 T-a/T-b 二选一——w3.12-frontend-window.md §5 单源）。
- **开放项复核**：TD-007 @ P3 登记态维持（消费信号 = W-3.3 宏声明皮肤窗开窗——六窗拓扑序待排）+ 登记窗四件维持（W-DRIVER-HARNESS-SPLIT 观察态——harness 族 +30% 触发器未达；W-DIAG-OPCODE-CONTEXT / W-DIAG-FORM-NOTATION 零信号）+ W-BOOT-FRONTEND 触发器更新态。
### r112 检视（Stage 3 W-3.2 窗——B1 清偿轮；TD-026 riding 登记一件；零新 TD）

- **B1 偏差闭合**：FFI 源级 extern「实现 < 设计」偏差（deep-review-round2.8 §14.8 唯一遗留）→ W-3.2 全链落地（双皮肤声明形 + 类型面 + 产物面 + 引擎面 + C 后端 + e2e）——§14.8 回写义务闭合。
- **TD-026（FFI dangling）再裁定 → riding 登记**：标量批下 dangling 结构性不可能（R-F1 标量拷贝——零 kerf 堆引用跨界，C 侧无从持有悬垂指针）；**转为堆类型 extern 扩展面（str/pair/句柄协议）的门条件**——该面开窗时随 R-F3 显式句柄根协议一并重审。不闭账（Open · riding——stage0 §9.107 裁定 + w3.2-ffi-extern-window §1.6 单源）。
- **开放项复核**：TD-007 @ P3 登记态维持（消费信号 = W-3.3 宏声明皮肤窗开窗——拓扑序下一位）+ 登记窗维持（W-DRIVER-HARNESS-SPLIT 观察态未达 +30% 触发器；W-DIAG-OPCODE-CONTEXT / W-DIAG-FORM-NOTATION 零信号）；r112 触发器核对：W-3.2 语言面变更与六窗全不相交。
- **孪生缺口披露**（非 TD——账本钉扎）：.ktf 编译器/展开器孪生（BS-A 冻结种子链）不识 extern 形——composed 链 junction 2 披露行（extern_row=6）；孪生刷新 = W-3.12 段三裁定域邻接决策（gate_b_bytecode 既有调用源零 extern 零影响）。

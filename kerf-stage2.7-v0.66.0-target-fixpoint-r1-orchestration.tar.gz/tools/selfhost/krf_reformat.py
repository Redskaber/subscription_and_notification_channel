#!/usr/bin/env python3
"""krf-reformat: whitespace-only S-expression reformatter for selfhost/v1.

Guarantees (by construction + verification):
  * the token stream of every touched form is byte-identical (comments and
    whitespace are not tokens to the kerf lexer);
  * the parsed tree of every touched form is structurally equal;
  * the four tamper-anchor needles stay contiguous in the emitted text.

Style (mirrors the hand formatting already dominant in the three files):
  * one form per line when it fits within WIDTH at its column;
  * a form that does not fit breaks as `(<head>` at its column with every
    child at column+1 (the Lisp-1 convention used by ex-mx in macro.krf);
  * `(define (name args...)` keeps the head line, body at column+2;
  * only top-level forms containing an over-width line are re-emitted.

Usage: python3 krf_reformat.py <file.krf> [--check] [--width 100]
                 [--style indent|aligned] [--dry-run]
  --check        validate the on-disk convention only (width bound,
                 non-ASCII whitelist {em-dash, section}, no ASCII
                 parenthetical dashes); exit 1 on any violation
  --width N      line-width bound (default 100 = SOP §10.5 + rustfmt)
  --style        indent (macro.krf convention) | aligned (reader.krf /
                 expander.krf convention) — only used when re-emitting
"""

import sys

WIDTH = 100  # convention bound (SOP §10.5 ~100 columns; rustfmt parity)

NEEDLES = [
    '(cons "empty-app" (cons (rd-fr-open (car stack)) nil))',
    "(>= ex-depth 512)",
    "(cons (ex-s nt) (cons (ex-e nt) nil))",
    "(set! ex-mcount 0)",
]


# ---------------------------------------------------------------- tokenizer

def tokenize(text):
    """Tokens: '(', ')', string literals (raw, quotes kept), atoms.
    Comments (';' to end of line) and whitespace are dropped."""
    toks = []
    i, n = 0, len(text)
    while i < n:
        c = text[i]
        if c == ";":
            j = text.find("\n", i)
            i = n if j < 0 else j
        elif c in " \t\r\n":
            i += 1
        elif c in "()":
            toks.append(c)
            i += 1
        elif c == '"':
            j = i + 1
            while j < n and text[j] != '"':
                j += 1
            if j >= n:
                raise ValueError("unterminated string literal")
            toks.append(text[i : j + 1])
            i = j + 1
        else:
            j = i
            while j < n and text[j] not in ' \t\r\n();"':
                j += 1
            toks.append(text[i:j])
            i = j
    return toks


class Parse:
    def __init__(self, toks):
        self.toks = toks
        self.pos = 0

    def peek(self):
        return self.toks[self.pos] if self.pos < len(self.toks) else None

    def parse(self):
        t = self.peek()
        if t == "(":
            self.pos += 1
            lst = []
            while self.peek() != ")":
                if self.peek() is None:
                    raise ValueError("unbalanced parens: eof before ')'")
                lst.append(self.parse())
            self.pos += 1
            return lst
        if t == ")":
            raise ValueError("unbalanced parens: stray ')'")
        self.pos += 1
        return t


def parse(text):
    p = Parse(tokenize(text))
    node = p.parse()
    if p.peek() is not None:
        raise ValueError("trailing tokens after top-level form")
    return node


# ----------------------------------------------------------------- emitter

def ser(node):
    if isinstance(node, str):
        return node
    return "(" + " ".join(ser(c) for c in node) + ")"


STYLE = "indent"  # "indent" (+1 per level, macro.krf) | "aligned" (args
# aligned under the first argument — reader.krf / expander.krf convention)


def emit(node, col, width=None):
    """Emit `node` at column `col` within `width`; break over-width forms.

    `width` reserves room for the closing parens that enclosing broken
    forms will append to this emission's final line (one per level, so the
    last child of a broken parent receives width-1)."""
    if width is None:
        width = WIDTH
    s = ser(node)
    if col + len(s) <= width:
        return s
    if isinstance(node, str):
        return s  # a lone over-width atom: nothing to break
    head = node[0]
    if not isinstance(head, str):
        # generic list-head fallback: '(' alone, every child at col+1
        parts = [
            " " * (col + 1) + emit(c, col + 1, width if i < len(node) - 1 else width - 1)
            for i, c in enumerate(node)
        ]
        return "(\n" + "\n".join(parts) + ")"
    if head == "define" and len(node) >= 2 and isinstance(node[1], str):
        # (define name value...) — value under the name column
        lines = ["(define " + node[1]]
        body_col = col + 1
        rest = node[2:]
        for i, child in enumerate(rest):
            w = width if i < len(rest) - 1 else width - 1
            lines.append(" " * body_col + emit(child, body_col, w))
        return "\n".join(lines) + ")"
    if head == "define":
        # (define (name args...) body...) — head line keeps the arg list
        lines = ["(define " + ser(node[1])]
        body_col = col + 2
        rest = node[2:]
        for i, child in enumerate(rest):
            w = width if i < len(rest) - 1 else width - 1
            lines.append(" " * body_col + emit(child, body_col, w))
        return "\n".join(lines) + ")"
    if STYLE == "aligned" and head not in ("quote",):
        if head == "let" and len(node) >= 3 and isinstance(node[1], list):
            # let: bindings aligned under "(let ", body shares the column
            lines = ["(let"]
            bcol = col + 5
            lines.append(emit_bindings(node[1], bcol, width - 1, aligned=True))
            for i, child in enumerate(node[2:]):
                w = width if i < len(node) - 3 else width - 1
                lines.append(" " * bcol + emit(child, bcol, w))
            return "\n".join(lines) + ")"
        # aligned profile: `(<head> <first-arg>` when it fits, remaining
        # children aligned under the first argument
        argcol = col + len(head) + 2
        rest = node[1:]
        if rest and col + len("(" + head + " " + ser(rest[0])) <= width - 1:
            lines = ["(" + head + " " + ser(rest[0])]
            rest = rest[1:]
        else:
            lines = ["(" + head]
        for i, child in enumerate(rest):
            w = width if i < len(rest) - 1 else width - 1
            lines.append(" " * argcol + emit(child, argcol, w))
        return "\n".join(lines) + ")"
    if head == "let" and len(node) >= 3 and isinstance(node[1], list):
        # (let ((name value)...) body...) — bindings get pair-aware breaking
        lines = ["(let"]
        bcol = col + 1
        lines.append(emit_bindings(node[1], bcol, width - 1))
        for i, child in enumerate(node[2:]):
            w = width if i < len(node) - 3 else width - 1
            lines.append(" " * bcol + emit(child, bcol, w))
        return "\n".join(lines) + ")"
    # indent profile: `(<head>` alone, every child at col+1
    lines = ["(" + head]
    body_col = col + 1
    rest = node[1:]
    for i, child in enumerate(rest):
        w = width if i < len(rest) - 1 else width - 1
        lines.append(" " * body_col + emit(child, body_col, w))
    return "\n".join(lines) + ")"


def emit_bindings(bindings, col, width=None, aligned=False):
    """Emit a let bindings group `((name value)...)` at column `col`."""
    if width is None:
        width = WIDTH
    s = ser(bindings)
    if col + len(s) <= width:
        return s
    lines = ["("]
    bcol = col + 1
    for i, (name, value) in enumerate(bindings):
        inline = "(" + name + " " + ser(value) + ")"
        w = width if i < len(bindings) - 1 else width - 1
        if bcol + len(inline) <= w:
            lines.append(" " * bcol + inline)
        else:
            # break one pair: '(' + name on its line, value below
            vcol = bcol + len(name) + 2 if aligned else bcol + 1
            lines.append(" " * bcol + "(" + name)
            lines.append(" " * vcol + emit(value, vcol, w - 1) + ")")
    return "\n".join(lines) + ")"


# ------------------------------------------------------------- file driver

def form_spans(lines):
    """Yield (start, end) line indexes of top-level forms.
    A form starts at a '(' in column 0 and ends where paren depth (outside
    strings/comments) returns to zero. Internal full-line comments are part
    of the span (the caller refuses to re-emit spans containing them)."""
    spans = []
    i, n = 0, len(lines)
    while i < n:
        if lines[i].startswith("("):
            depth = 0
            j = i
            in_str = False
            done = False
            while j < n and not done:
                k = 0
                line = lines[j]
                while k < len(line):
                    c = line[k]
                    if in_str:
                        if c == '"':
                            in_str = False
                    elif c == '"':
                        in_str = True
                    elif c == ";":
                        break  # comment to end of line
                    elif c == "(":
                        depth += 1
                    elif c == ")":
                        depth -= 1
                        if depth == 0:
                            done = True
                            break
                    k += 1
                j += 1
            spans.append((i, j))
            i = j
        else:
            i += 1
    return spans


def has_inline_comment(lines, start, end):
    """True when any line of the span carries a standalone comment line
    inside the form (code lines never carry trailing comments here)."""
    for idx in range(start + 1, end):
        s = lines[idx].strip()
        if s.startswith(";"):
            return True
    return False


def check_only(path, width):
    """Validate the on-disk convention without touching anything:
    width bound, non-ASCII whitelist, ASCII parenthetical dashes."""
    with open(path, encoding="utf-8") as f:
        lines = f.read().split("\n")
    problems = []
    for i, line in enumerate(lines):
        cols = len(line)
        if cols > width:
            problems.append(f"{path}:{i + 1}: {cols} columns (bound {width})")
        bad = [ch for ch in line if not ch.isascii() and ch not in ("—", "§")]
        if bad:
            problems.append(
                f"{path}:{i + 1}: non-ASCII {bad[0]!r} outside the "
                "{em-dash, section} whitelist")
        if " - " in line or "  -  " in line:
            problems.append(
                f"{path}:{i + 1}: ASCII parenthetical dash "
                "(the convention is the em-dash)")
    if problems:
        print("CHECK FAILED:")
        for p in problems:
            print("  " + p)
        sys.exit(1)
    print(f"CHECK PASSED ({len(lines)} lines, bound {width})")


def main():
    path = sys.argv[1]
    width = 100  # the convention bound (SOP §10.5 ~100 columns, the
    # same number rustfmt enforces on the Rust face)
    if "--width" in sys.argv:
        width = int(sys.argv[sys.argv.index("--width") + 1])
    if "--style" in sys.argv:
        globals()["STYLE"] = sys.argv[sys.argv.index("--style") + 1]
    dry = "--dry-run" in sys.argv
    if "--check" in sys.argv:
        check_only(path, width)
        return
    globals()["WIDTH"] = width

    with open(path, encoding="utf-8") as f:
        text = f.read()
    lines = text.split("\n")
    before_needles = [nd for nd in NEEDLES if nd in text]

    spans = form_spans(lines)
    touched = 0
    # bottom-up: replacing a span never shifts the indexes of spans above it
    for start, end in reversed(spans):
        if not any(len(lines[i]) > width for i in range(start, end)):
            continue
        if has_inline_comment(lines, start, end):
            print(f"SKIP (internal comment): lines {start + 1}-{end}")
            continue
        old_src = "\n".join(lines[start:end])
        tree = parse(old_src)
        new_src = emit(tree, 0)
        # verification 1: token stream identical
        if tokenize(old_src) != tokenize(new_src):
            raise AssertionError(f"token drift in form at line {start + 1}")
        # verification 2: structural tree identical
        if parse(old_src) != parse(new_src):
            raise AssertionError(f"tree drift in form at line {start + 1}")
        lines[start:end] = new_src.split("\n")
        touched += 1
        print(f"re-emitted form at line {start + 1} ({end - start} -> "
              f"{len(new_src.splitlines())} lines)")

    new_text = "\n".join(lines)
    # verification 3: whole-file token stream identical
    if tokenize(text) != tokenize(new_text):
        raise AssertionError("whole-file token drift")
    # verification 4: needles still contiguous
    for nd in before_needles:
        if nd not in new_text:
            raise AssertionError(f"needle broken: {nd[:40]}")
    over = [(i + 1, len(l)) for i, l in enumerate(lines) if len(l) > width]
    print(f"touched forms: {touched}; residual over-{width} lines: {over}")
    if over:
        sys.exit(1)
    if not dry:
        with open(path, "w", encoding="utf-8") as f:
            f.write(new_text)


if __name__ == "__main__":
    main()

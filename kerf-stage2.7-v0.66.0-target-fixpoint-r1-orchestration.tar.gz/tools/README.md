# tools/ — 自研工具归档（SOP §3.4）

按 `<domain>/` 子目录组织；新工具须同步 docs/tools/<domain>/ 文档。

| 域 | 工具 | 文档 | 落位轮 |
|---|---|---|---|
| `selfhost/` | `krf_reformat.py` — `selfhost/v1/*.krf` 空白级重排（token 流/语法树/锚串三重构造性验证 + `--check` 约定预检） | `docs/tools/selfhost/krf-reformat.md` | r78（§9.79，v0.48.0） |
